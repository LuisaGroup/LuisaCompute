; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

@convergence.targets = private unnamed_addr constant [13 x i32] [i32 5, i32 8, i32 10, i32 13, i32 15, i32 18, i32 20, i32 23, i32 25, i32 28, i32 30, i32 33, i32 35], align 4

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %live.mask = alloca <8 x i1>, align 1
  %runnable.mask = alloca <8 x i1>, align 1
  %ready.count = alloca i32, align 4
  %ready.mask = alloca [8 x <8 x i1>], align 1
  %ready.target = alloca [8 x i32], align 4
  %ready.token = alloca [8 x i32], align 4
  %current.mask = alloca <8 x i1>, align 1
  %current.token = alloca i32, align 4
  %frame.active = alloca i8, align 1
  %frame.static.id = alloca <8 x i32>, align 32
  %frame.parent.token = alloca <8 x i32>, align 32
  %frame.expected = alloca [8 x <8 x i1>], align 1
  %frame.arrived = alloca [8 x <8 x i1>], align 1
  store <8 x i1> zeroinitializer, ptr %live.mask, align 1
  store <8 x i1> zeroinitializer, ptr %runnable.mask, align 1
  store i32 0, ptr %ready.count, align 4
  store [8 x <8 x i1>] zeroinitializer, ptr %ready.mask, align 1
  store [8 x i32] zeroinitializer, ptr %ready.target, align 4
  store [8 x i32] zeroinitializer, ptr %ready.token, align 4
  store <8 x i1> zeroinitializer, ptr %current.mask, align 1
  store i32 0, ptr %current.token, align 4
  store i8 0, ptr %frame.active, align 1
  store <8 x i32> zeroinitializer, ptr %frame.static.id, align 32
  store <8 x i32> zeroinitializer, ptr %frame.parent.token, align 32
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.expected, align 1
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.arrived, align 1
  %tile_snapshot.local = alloca [288 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [288 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local4 = alloca [288 x i8], align 4
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local7 = alloca [288 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill10 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill10, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot, align 64
  %.spill11 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill11, align 1
  %.spill12 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill12, align 4
  %.spill13 = alloca i64, align 8
  store i64 0, ptr %.spill13, align 4
  %.slot14 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot14, align 64
  %.slot15 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot15, align 32
  %.slot16 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot16, align 32
  %.slot17 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot17, align 32
  %.slot18 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot18, align 32
  %.slot19 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot19, align 32
  %.spill20 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill20, align 32
  %.spill21 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill21, align 32
  %.spill22 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill22, align 32
  %.spill23 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill23, align 4
  %.spill24 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill24, align 32
  %tile_snapshot.spill25 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill25, align 64
  %.slot26 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot26, align 64
  %.slot27 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot27, align 64
  %.slot28 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot28, align 32
  %.slot29 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot29, align 32
  %.slot30 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot30, align 32
  %.slot31 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot31, align 32
  %.slot32 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot32, align 32
  %.spill33 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill33, align 32
  %tile_snapshot.spill34 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill34, align 64
  %.slot35 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot35, align 64
  %.spill36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill36, align 32
  %tile_snapshot.spill37 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill37, align 64
  %.slot38 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot38, align 64
  %.slot39 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot39, align 64
  %8 = getelementptr i8, ptr %argument_buffer, i64 0
  %9 = load ptr, ptr %8, align 16
  %10 = getelementptr i8, ptr %8, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = insertvalue { ptr, i64 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %11, 1
  %14 = getelementptr i8, ptr %argument_buffer, i64 16
  %15 = load ptr, ptr %14, align 16
  %16 = getelementptr i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = insertvalue { ptr, i64 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i64 } %18, i64 %17, 1
  %20 = getelementptr i8, ptr %argument_buffer, i64 32
  %21 = load ptr, ptr %20, align 16
  %22 = getelementptr i8, ptr %20, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = insertvalue { ptr, i64 } poison, ptr %21, 0
  %25 = insertvalue { ptr, i64 } %24, i64 %23, 1
  %26 = getelementptr i8, ptr %argument_buffer, i64 48
  %27 = load ptr, ptr %26, align 16
  %28 = getelementptr i8, ptr %26, i64 8
  %29 = load i64, ptr %28, align 8
  %30 = insertvalue { ptr, i64 } poison, ptr %27, 0
  %31 = insertvalue { ptr, i64 } %30, i64 %29, 1
  %32 = load i32, ptr %launch_config, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 12
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 4
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 16
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 8
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 20
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 36
  %44 = load i32, ptr %43, align 4
  %.splatinsert40 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat41 = shufflevector <8 x i32> %.splatinsert40, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat41, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %46 = mul i32 %32, 32
  %.splatinsert42 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat43 = shufflevector <8 x i32> %.splatinsert42, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat43, %45
  %48 = mul i32 %36, 1
  %.splatinsert44 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat45 = shufflevector <8 x i32> %.splatinsert44, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat45, zeroinitializer
  %50 = mul i32 %40, 1
  %.splatinsert46 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat47 = shufflevector <8 x i32> %.splatinsert46, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat47, zeroinitializer
  %52 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %47, 0
  %53 = insertvalue [3 x <8 x i32>] %52, <8 x i32> %49, 1
  %54 = insertvalue [3 x <8 x i32>] %53, <8 x i32> %51, 2
  %.splatinsert48 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat49 = shufflevector <8 x i32> %.splatinsert48, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat49
  store <8 x i1> %55, ptr %live.mask, align 1
  %56 = load i32, ptr %current.token, align 4
  %57 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %58 = load i32, ptr %ready.count, align 4
  %59 = icmp uge i32 %58, 8
  %60 = and i1 %57, %59
  br i1 %60, label %ready.overflow.trap, label %ready.overflow.resume

ready.overflow.trap:                              ; preds = %prologue
  call void @llvm.trap()
  unreachable

ready.overflow.resume:                            ; preds = %prologue
  %61 = select i1 %57, i32 %58, i32 0
  %62 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %61
  %63 = load <8 x i1>, ptr %62, align 1
  %64 = select i1 %57, <8 x i1> %55, <8 x i1> %63
  store <8 x i1> %64, ptr %62, align 1
  %65 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %61
  %66 = load i32, ptr %65, align 4
  %67 = select i1 %57, i32 0, i32 %66
  store i32 %67, ptr %65, align 4
  %68 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %61
  %69 = load i32, ptr %68, align 4
  %70 = select i1 %57, i32 %56, i32 %69
  store i32 %70, ptr %68, align 4
  %71 = add i32 %58, 1
  %72 = select i1 %57, i32 %71, i32 %58
  store i32 %72, ptr %ready.count, align 4
  %73 = load <8 x i1>, ptr %runnable.mask, align 1
  %74 = or <8 x i1> %73, %55
  store <8 x i1> %74, ptr %runnable.mask, align 1
  br label %scheduler.loop

scheduler.loop:                                   ; preds = %return.frame.cleanup.done, %convergence.cascade.exit539, %schedule.34, %varying.coherent.false522, %varying.coherent.true521, %convergence.cascade.exit498, %schedule.32, %varying.coherent.false482, %varying.coherent.true481, %convergence.target.30.ready, %convergence.cascade.exit458, %schedule.29, %varying.coherent.false447, %varying.coherent.true446, %convergence.cascade.exit423, %schedule.27, %varying.coherent.false411, %varying.coherent.true410, %convergence.target.25.ready, %convergence.cascade.exit384, %schedule.24, %varying.coherent.false373, %varying.coherent.true372, %convergence.cascade.exit349, %schedule.22, %varying.coherent.false337, %varying.coherent.true336, %convergence.target.20.ready, %convergence.cascade.exit302, %schedule.19, %varying.coherent.false295, %varying.coherent.true294, %convergence.cascade.exit270, %schedule.17, %varying.coherent.false255, %varying.coherent.true254, %convergence.target.15.ready, %convergence.cascade.exit219, %schedule.14, %varying.coherent.false208, %varying.coherent.true207, %convergence.cascade.exit184, %schedule.12, %varying.coherent.false174, %varying.coherent.true173, %convergence.target.10.ready, %convergence.cascade.exit142, %schedule.9, %varying.coherent.false135, %varying.coherent.true134, %convergence.cascade.exit110, %schedule.7, %varying.coherent.false95, %varying.coherent.true94, %convergence.target.5.ready, %convergence.cascade.exit, %schedule.4, %varying.coherent.false, %varying.coherent.true, %schedule.2, %uniform.false, %uniform.true, %schedule.0, %ready.overflow.resume
  %75 = load i32, ptr %ready.count, align 4
  %76 = icmp ne i32 %75, 0
  br i1 %76, label %scheduler.dispatch, label %scheduler.done

scheduler.dispatch:                               ; preds = %scheduler.loop
  %77 = sub i32 %75, 1
  store i32 %77, ptr %ready.count, align 4
  %78 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %77
  %79 = load <8 x i1>, ptr %78, align 1
  store <8 x i1> %79, ptr %current.mask, align 1
  %80 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %77
  %81 = load i32, ptr %80, align 4
  %82 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %77
  %83 = load i32, ptr %82, align 4
  store i32 %83, ptr %current.token, align 4
  %84 = load <8 x i1>, ptr %runnable.mask, align 1
  %85 = xor <8 x i1> %79, splat (i1 true)
  %86 = and <8 x i1> %84, %85
  store <8 x i1> %86, ptr %runnable.mask, align 1
  br label %scheduler.dispatch.route

scheduler.dispatch.route:                         ; preds = %ready.overflow.resume520, %ready.overflow.resume480, %ready.overflow.resume445, %ready.overflow.resume409, %ready.overflow.resume371, %ready.overflow.resume335, %ready.overflow.resume293, %ready.overflow.resume253, %ready.overflow.resume206, %ready.overflow.resume172, %ready.overflow.resume133, %ready.overflow.resume93, %ready.overflow.resume62, %scheduler.dispatch
  %scheduler.dispatch.pc = phi i32 [ %81, %scheduler.dispatch ], [ 5, %ready.overflow.resume62 ], [ 8, %ready.overflow.resume93 ], [ 10, %ready.overflow.resume133 ], [ 13, %ready.overflow.resume172 ], [ 15, %ready.overflow.resume206 ], [ 18, %ready.overflow.resume253 ], [ 20, %ready.overflow.resume293 ], [ 23, %ready.overflow.resume335 ], [ 25, %ready.overflow.resume371 ], [ 28, %ready.overflow.resume409 ], [ 30, %ready.overflow.resume445 ], [ 33, %ready.overflow.resume480 ], [ 35, %ready.overflow.resume520 ]
  switch i32 %scheduler.dispatch.pc, label %scheduler.invalid [
    i32 0, label %schedule.0
    i32 1, label %schedule.1
    i32 2, label %schedule.2
    i32 3, label %schedule.3
    i32 4, label %schedule.4
    i32 5, label %schedule.5
    i32 6, label %schedule.6
    i32 7, label %schedule.7
    i32 8, label %schedule.8
    i32 9, label %schedule.9
    i32 10, label %schedule.10
    i32 11, label %schedule.11
    i32 12, label %schedule.12
    i32 13, label %schedule.13
    i32 14, label %schedule.14
    i32 15, label %schedule.15
    i32 16, label %schedule.16
    i32 17, label %schedule.17
    i32 18, label %schedule.18
    i32 19, label %schedule.19
    i32 20, label %schedule.20
    i32 21, label %schedule.21
    i32 22, label %schedule.22
    i32 23, label %schedule.23
    i32 24, label %schedule.24
    i32 25, label %schedule.25
    i32 26, label %schedule.26
    i32 27, label %schedule.27
    i32 28, label %schedule.28
    i32 29, label %schedule.29
    i32 30, label %schedule.30
    i32 31, label %schedule.31
    i32 32, label %schedule.32
    i32 33, label %schedule.33
    i32 34, label %schedule.34
    i32 35, label %schedule.35
  ]

scheduler.done:                                   ; preds = %scheduler.loop
  %87 = load <8 x i1>, ptr %live.mask, align 1
  %88 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %87)
  br i1 %88, label %scheduler.stalled, label %scheduler.exit

scheduler.exit:                                   ; preds = %scheduler.done
  ret void

scheduler.stalled:                                ; preds = %scheduler.done
  call void @llvm.trap()
  unreachable

scheduler.invalid:                                ; preds = %scheduler.dispatch.route
  call void @llvm.trap()
  unreachable

schedule.0:                                       ; preds = %scheduler.dispatch.route
  %89 = load <8 x i1>, ptr %current.mask, align 1
  %90 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %89)
  %91 = bitcast <8 x i1> %89 to i8
  %92 = call i8 @llvm.cttz.i8(i8 %91, i1 false)
  %93 = zext i8 %92 to i32
  %94 = select i1 %90, i32 %93, i32 0
  %95 = extractvalue [3 x <8 x i32>] %54, 0
  %96 = load <8 x i64>, ptr %.spill, align 64
  %97 = select <8 x i1> %89, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %96
  store <8 x i64> %97, ptr %.spill, align 64
  %98 = sub <8 x i32> %95, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %99 = select <8 x i1> %89, <8 x i32> %98, <8 x i32> zeroinitializer
  %100 = select <8 x i1> %89, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %101 = lshr <8 x i32> %99, %100
  %102 = zext <8 x i32> %101 to <8 x i64>
  %103 = select <8 x i1> %89, <8 x i64> %102, <8 x i64> zeroinitializer
  %104 = select <8 x i1> %89, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %105 = sdiv <8 x i64> %103, %104
  %106 = load <8 x i64>, ptr %.spill10, align 64
  %107 = select <8 x i1> %89, <8 x i64> %105, <8 x i64> %106
  store <8 x i64> %107, ptr %.spill10, align 64
  %108 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %110 = extractvalue { <8 x ptr>, <8 x i64> } %108, 0
  %111 = select <8 x i1> %89, <8 x ptr> %109, <8 x ptr> %110
  %112 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %113 = extractvalue { <8 x ptr>, <8 x i64> } %108, 1
  %114 = select <8 x i1> %89, <8 x i64> %112, <8 x i64> %113
  %115 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %111, 0
  %116 = insertvalue { <8 x ptr>, <8 x i64> } %115, <8 x i64> %114, 1
  store { <8 x ptr>, <8 x i64> } %116, ptr %tile_snapshot.spill, align 64
  %117 = load <8 x i64>, ptr %.slot, align 64
  %118 = select <8 x i1> %89, <8 x i64> zeroinitializer, <8 x i64> %117
  store <8 x i64> %118, ptr %.slot, align 64
  store <8 x i1> %89, ptr %current.mask, align 1
  %119 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %89)
  br i1 %119, label %schedule.1, label %scheduler.loop

schedule.1:                                       ; preds = %schedule.2, %schedule.0, %scheduler.dispatch.route
  %120 = load <8 x i1>, ptr %current.mask, align 1
  %121 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %120)
  %122 = bitcast <8 x i1> %120 to i8
  %123 = call i8 @llvm.cttz.i8(i8 %122, i1 false)
  %124 = zext i8 %123 to i32
  %125 = select i1 %121, i32 %124, i32 0
  %.state = load <8 x i64>, ptr %.slot, align 64
  %126 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %120)
  %127 = bitcast <8 x i1> %120 to i8
  %128 = call i8 @llvm.cttz.i8(i8 %127, i1 false)
  %129 = zext i8 %128 to i32
  %130 = select i1 %126, i32 %129, i32 0
  %131 = extractelement <8 x i64> %.state, i32 %130
  %132 = icmp slt i64 %131, 8
  br i1 %132, label %uniform.true, label %uniform.false

schedule.2:                                       ; preds = %uniform.true, %scheduler.dispatch.route
  %133 = load <8 x i1>, ptr %current.mask, align 1
  %134 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %133)
  %135 = bitcast <8 x i1> %133 to i8
  %136 = call i8 @llvm.cttz.i8(i8 %135, i1 false)
  %137 = zext i8 %136 to i32
  %138 = select i1 %134, i32 %137, i32 0
  %.state50 = load <8 x i64>, ptr %.slot, align 64
  %139 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %133)
  %140 = bitcast <8 x i1> %133 to i8
  %141 = call i8 @llvm.cttz.i8(i8 %140, i1 false)
  %142 = zext i8 %141 to i32
  %143 = select i1 %139, i32 %142, i32 0
  %144 = extractelement <8 x i64> %.state50, i32 %143
  %145 = mul i64 %144, 8
  %.splatinsert51 = insertelement <8 x i64> poison, i64 %145, i64 0
  %.splat52 = shufflevector <8 x i64> %.splatinsert51, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %146 = add <8 x i64> %.splat52, %.spill.load
  %.spill.load53 = load <8 x i64>, ptr %.spill10, align 64
  %147 = add <8 x i64> %.spill.load53, zeroinitializer
  %148 = add <8 x i64> zeroinitializer, %147
  %149 = add <8 x i64> zeroinitializer, %146
  %150 = mul <8 x i64> %148, splat (i64 66)
  %151 = add <8 x i64> %150, %149
  %152 = extractvalue { ptr, i64 } %13, 0
  %153 = extractelement <8 x i64> %151, i32 %138
  %154 = zext i32 %138 to i64
  %155 = sub i64 %153, %154
  %156 = mul i64 %155, 4
  %buffer.contiguous.address = getelementptr i8, ptr %152, i64 %156
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %133, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %157 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %158 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state54 = load <8 x i64>, ptr %.slot, align 64
  %159 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %133)
  %160 = bitcast <8 x i1> %133 to i8
  %161 = call i8 @llvm.cttz.i8(i8 %160, i1 false)
  %162 = zext i8 %161 to i32
  %163 = select i1 %159, i32 %162, i32 0
  %164 = extractelement <8 x i64> %.state54, i32 %163
  %.splatinsert55 = insertelement <8 x i64> poison, i64 %164, i64 0
  %.splat56 = shufflevector <8 x i64> %.splatinsert55, <8 x i64> poison, <8 x i32> zeroinitializer
  %165 = mul <8 x i64> %.splat56, splat (i64 32)
  %166 = add <8 x i64> %158, %165
  %167 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %157, 0
  %168 = insertvalue { <8 x ptr>, <8 x i64> } %167, <8 x i64> %166, 1
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %168, 1
  %171 = extractelement <8 x ptr> %169, i32 0
  %172 = extractelement <8 x i64> %170, i32 %138
  %173 = zext i32 %138 to i64
  %174 = mul i64 %173, 4
  %175 = sub i64 %172, %174
  %176 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %133)
  %177 = select i1 %176, i64 %175, i64 0
  %private.contiguous.address = getelementptr i8, ptr %171, i64 %177
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %178 = select <8 x i1> %133, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %178, ptr %private.contiguous.address, align 4
  %.state57 = load <8 x i64>, ptr %.slot, align 64
  %179 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %133)
  %180 = bitcast <8 x i1> %133 to i8
  %181 = call i8 @llvm.cttz.i8(i8 %180, i1 false)
  %182 = zext i8 %181 to i32
  %183 = select i1 %179, i32 %182, i32 0
  %184 = extractelement <8 x i64> %.state57, i32 %183
  %185 = add i64 %184, 1
  %.splatinsert58 = insertelement <8 x i64> poison, i64 %185, i64 0
  %.splat59 = shufflevector <8 x i64> %.splatinsert58, <8 x i64> poison, <8 x i32> zeroinitializer
  %186 = load <8 x i64>, ptr %.slot, align 64
  %187 = select <8 x i1> %133, <8 x i64> %.splat59, <8 x i64> %186
  store <8 x i64> %187, ptr %.slot, align 64
  store <8 x i1> %133, ptr %current.mask, align 1
  %188 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %133)
  br i1 %188, label %schedule.1, label %scheduler.loop

schedule.3:                                       ; preds = %uniform.false, %scheduler.dispatch.route
  %189 = load <8 x i1>, ptr %current.mask, align 1
  %190 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %189)
  %191 = bitcast <8 x i1> %189 to i8
  %192 = call i8 @llvm.cttz.i8(i8 %191, i1 false)
  %193 = zext i8 %192 to i32
  %194 = select i1 %190, i32 %193, i32 0
  %.spill.load60 = load <8 x i64>, ptr %.spill, align 64
  %195 = icmp slt <8 x i64> %.spill.load60, splat (i64 2)
  %196 = load <8 x i1>, ptr %.spill11, align 1
  %197 = select <8 x i1> %189, <8 x i1> %195, <8 x i1> %196
  store <8 x i1> %197, ptr %.spill11, align 1
  %198 = and <8 x i1> %189, %195
  %199 = xor <8 x i1> %195, splat (i1 true)
  %200 = and <8 x i1> %189, %199
  %201 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %198)
  %202 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %200)
  %203 = and i1 %201, %202
  br i1 %203, label %varying.divergent, label %varying.coherent

schedule.4:                                       ; preds = %varying.coherent.true, %scheduler.dispatch.route
  %204 = load <8 x i1>, ptr %current.mask, align 1
  %205 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %204)
  %206 = bitcast <8 x i1> %204 to i8
  %207 = call i8 @llvm.cttz.i8(i8 %206, i1 false)
  %208 = zext i8 %207 to i32
  %209 = select i1 %205, i32 %208, i32 0
  %.spill.load63 = load <8 x i64>, ptr %.spill, align 64
  %210 = add <8 x i64> splat (i64 64), %.spill.load63
  %.spill.load64 = load <8 x i64>, ptr %.spill10, align 64
  %211 = add <8 x i64> %.spill.load64, zeroinitializer
  %212 = add <8 x i64> zeroinitializer, %211
  %213 = add <8 x i64> zeroinitializer, %210
  %214 = mul <8 x i64> %212, splat (i64 66)
  %215 = add <8 x i64> %214, %213
  %216 = extractvalue { ptr, i64 } %13, 0
  %217 = extractelement <8 x i64> %215, i32 %209
  %218 = zext i32 %209 to i64
  %219 = sub i64 %217, %218
  %220 = mul i64 %219, 4
  %buffer.contiguous.address65 = getelementptr i8, ptr %216, i64 %220
  %buffer.contiguous.load66 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address65, i32 1, <8 x i1> %204, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load67 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load67, 0
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load67, 1
  %223 = add <8 x i64> %222, splat (i64 256)
  %224 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %221, 0
  %225 = insertvalue { <8 x ptr>, <8 x i64> } %224, <8 x i64> %223, 1
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %225, 1
  %228 = extractelement <8 x ptr> %226, i32 0
  %229 = extractelement <8 x i64> %227, i32 %209
  %230 = zext i32 %209 to i64
  %231 = mul i64 %230, 4
  %232 = sub i64 %229, %231
  %233 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %204)
  %234 = select i1 %233, i64 %232, i64 0
  %private.contiguous.address68 = getelementptr i8, ptr %228, i64 %234
  %private.contiguous.preserve69 = load <8 x float>, ptr %private.contiguous.address68, align 4
  %235 = select <8 x i1> %204, <8 x float> %buffer.contiguous.load66, <8 x float> %private.contiguous.preserve69
  store <8 x float> %235, ptr %private.contiguous.address68, align 4
  store <8 x i1> %204, ptr %current.mask, align 1
  %236 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %204)
  br i1 %236, label %schedule.5, label %scheduler.loop

schedule.5:                                       ; preds = %schedule.4, %varying.coherent.false, %scheduler.dispatch.route
  %237 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token = load i32, ptr %current.token, align 4
  %convergence.token.present = icmp ne i32 %convergence.current.token, 0
  br i1 %convergence.token.present, label %convergence.cascade, label %convergence.cascade.exit

schedule.6:                                       ; preds = %schedule.7, %convergence.target.5.ready, %scheduler.dispatch.route
  %238 = load <8 x i1>, ptr %current.mask, align 1
  %239 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %238)
  %240 = bitcast <8 x i1> %238 to i8
  %241 = call i8 @llvm.cttz.i8(i8 %240, i1 false)
  %242 = zext i8 %241 to i32
  %243 = select i1 %239, i32 %242, i32 0
  %.state87 = load <8 x i64>, ptr %.slot14, align 64
  %244 = icmp slt <8 x i64> %.state87, splat (i64 8)
  %245 = and <8 x i1> %238, %244
  %246 = xor <8 x i1> %244, splat (i1 true)
  %247 = and <8 x i1> %238, %246
  %248 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %245)
  %249 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %247)
  %250 = and i1 %248, %249
  br i1 %250, label %varying.divergent88, label %varying.coherent89

schedule.7:                                       ; preds = %varying.coherent.true94, %scheduler.dispatch.route
  %251 = load <8 x i1>, ptr %current.mask, align 1
  %252 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %251)
  %253 = bitcast <8 x i1> %251 to i8
  %254 = call i8 @llvm.cttz.i8(i8 %253, i1 false)
  %255 = zext i8 %254 to i32
  %256 = select i1 %252, i32 %255, i32 0
  %.state96 = load <8 x i64>, ptr %.slot14, align 64
  %257 = add <8 x i64> %.state96, zeroinitializer
  %tile_snapshot.spill.load97 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %258 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load97, 0
  %259 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load97, 1
  %260 = mul <8 x i64> %257, splat (i64 32)
  %261 = add <8 x i64> %259, %260
  %262 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %258, 0
  %263 = insertvalue { <8 x ptr>, <8 x i64> } %262, <8 x i64> %261, 1
  %264 = extractvalue { <8 x ptr>, <8 x i64> } %263, 0
  %265 = extractvalue { <8 x ptr>, <8 x i64> } %263, 1
  %266 = getelementptr i8, <8 x ptr> %264, <8 x i64> %265
  %267 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %266, i32 1, <8 x i1> %251, <8 x float> zeroinitializer)
  %.state98 = load <8 x float>, ptr %.slot15, align 32
  %268 = fadd <8 x float> %.state98, %267
  %.state99 = load <8 x i64>, ptr %.slot14, align 64
  %269 = add <8 x i64> %.state99, splat (i64 1)
  %tile_snapshot.spill.load100 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %270 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load100, 0
  %271 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load100, 1
  %272 = mul <8 x i64> %269, splat (i64 32)
  %273 = add <8 x i64> %271, %272
  %274 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %270, 0
  %275 = insertvalue { <8 x ptr>, <8 x i64> } %274, <8 x i64> %273, 1
  %276 = extractvalue { <8 x ptr>, <8 x i64> } %275, 0
  %277 = extractvalue { <8 x ptr>, <8 x i64> } %275, 1
  %278 = getelementptr i8, <8 x ptr> %276, <8 x i64> %277
  %279 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %278, i32 1, <8 x i1> %251, <8 x float> zeroinitializer)
  %.state101 = load <8 x float>, ptr %.slot16, align 32
  %280 = fadd <8 x float> %.state101, %279
  %.state102 = load <8 x i64>, ptr %.slot14, align 64
  %281 = add <8 x i64> %.state102, splat (i64 2)
  %tile_snapshot.spill.load103 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %282 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load103, 0
  %283 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load103, 1
  %284 = mul <8 x i64> %281, splat (i64 32)
  %285 = add <8 x i64> %283, %284
  %286 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %282, 0
  %287 = insertvalue { <8 x ptr>, <8 x i64> } %286, <8 x i64> %285, 1
  %288 = extractvalue { <8 x ptr>, <8 x i64> } %287, 0
  %289 = extractvalue { <8 x ptr>, <8 x i64> } %287, 1
  %290 = getelementptr i8, <8 x ptr> %288, <8 x i64> %289
  %291 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %290, i32 1, <8 x i1> %251, <8 x float> zeroinitializer)
  %.state104 = load <8 x float>, ptr %.slot17, align 32
  %292 = fadd <8 x float> %.state104, %291
  %.state105 = load <8 x i64>, ptr %.slot14, align 64
  %293 = add <8 x i64> %.state105, splat (i64 3)
  %tile_snapshot.spill.load106 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load106, 0
  %295 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load106, 1
  %296 = mul <8 x i64> %293, splat (i64 32)
  %297 = add <8 x i64> %295, %296
  %298 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %294, 0
  %299 = insertvalue { <8 x ptr>, <8 x i64> } %298, <8 x i64> %297, 1
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %299, 0
  %301 = extractvalue { <8 x ptr>, <8 x i64> } %299, 1
  %302 = getelementptr i8, <8 x ptr> %300, <8 x i64> %301
  %303 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %302, i32 1, <8 x i1> %251, <8 x float> zeroinitializer)
  %.state107 = load <8 x float>, ptr %.slot18, align 32
  %304 = fadd <8 x float> %.state107, %303
  %.state108 = load <8 x i64>, ptr %.slot14, align 64
  %305 = add <8 x i64> %.state108, splat (i64 4)
  %306 = load <8 x i64>, ptr %.slot14, align 64
  %307 = select <8 x i1> %251, <8 x i64> %305, <8 x i64> %306
  store <8 x i64> %307, ptr %.slot14, align 64
  %308 = load <8 x float>, ptr %.slot15, align 32
  %309 = select <8 x i1> %251, <8 x float> %268, <8 x float> %308
  store <8 x float> %309, ptr %.slot15, align 32
  %310 = load <8 x float>, ptr %.slot16, align 32
  %311 = select <8 x i1> %251, <8 x float> %280, <8 x float> %310
  store <8 x float> %311, ptr %.slot16, align 32
  %312 = load <8 x float>, ptr %.slot17, align 32
  %313 = select <8 x i1> %251, <8 x float> %292, <8 x float> %312
  store <8 x float> %313, ptr %.slot17, align 32
  %314 = load <8 x float>, ptr %.slot18, align 32
  %315 = select <8 x i1> %251, <8 x float> %304, <8 x float> %314
  store <8 x float> %315, ptr %.slot18, align 32
  store <8 x i1> %251, ptr %current.mask, align 1
  %316 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %251)
  br i1 %316, label %schedule.6, label %scheduler.loop

schedule.8:                                       ; preds = %varying.coherent.false95, %scheduler.dispatch.route
  %317 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token111 = load i32, ptr %current.token, align 4
  %convergence.token.present112 = icmp ne i32 %convergence.current.token111, 0
  br i1 %convergence.token.present112, label %convergence.cascade109, label %convergence.cascade.exit110

schedule.9:                                       ; preds = %varying.coherent.true134, %scheduler.dispatch.route
  %318 = load <8 x i1>, ptr %current.mask, align 1
  %319 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %318)
  %320 = bitcast <8 x i1> %318 to i8
  %321 = call i8 @llvm.cttz.i8(i8 %320, i1 false)
  %322 = zext i8 %321 to i32
  %323 = select i1 %319, i32 %322, i32 0
  %tile_snapshot.spill.load137 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load137, 0
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load137, 1
  %326 = add <8 x i64> %325, splat (i64 256)
  %327 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %324, 0
  %328 = insertvalue { <8 x ptr>, <8 x i64> } %327, <8 x i64> %326, 1
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %330 = extractvalue { <8 x ptr>, <8 x i64> } %328, 1
  %331 = extractelement <8 x ptr> %329, i32 0
  %332 = extractelement <8 x i64> %330, i32 %323
  %333 = zext i32 %323 to i64
  %334 = mul i64 %333, 4
  %335 = sub i64 %332, %334
  %336 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %318)
  %337 = select i1 %336, i64 %335, i64 0
  %private.contiguous.address138 = getelementptr i8, ptr %331, i64 %337
  %private.contiguous.load139 = load <8 x float>, ptr %private.contiguous.address138, align 4
  %338 = select <8 x i1> %318, <8 x float> %private.contiguous.load139, <8 x float> zeroinitializer
  %.state140 = load <8 x float>, ptr %.slot15, align 32
  %339 = fadd <8 x float> %.state140, %338
  %340 = load <8 x float>, ptr %.slot19, align 32
  %341 = select <8 x i1> %318, <8 x float> %339, <8 x float> %340
  store <8 x float> %341, ptr %.slot19, align 32
  store <8 x i1> %318, ptr %current.mask, align 1
  %342 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %318)
  br i1 %342, label %schedule.10, label %scheduler.loop

schedule.10:                                      ; preds = %schedule.9, %varying.coherent.false135, %scheduler.dispatch.route
  %343 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token143 = load i32, ptr %current.token, align 4
  %convergence.token.present144 = icmp ne i32 %convergence.current.token143, 0
  br i1 %convergence.token.present144, label %convergence.cascade141, label %convergence.cascade.exit142

schedule.11:                                      ; preds = %schedule.12, %convergence.target.10.ready, %scheduler.dispatch.route
  %344 = load <8 x i1>, ptr %current.mask, align 1
  %345 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %344)
  %346 = bitcast <8 x i1> %344 to i8
  %347 = call i8 @llvm.cttz.i8(i8 %346, i1 false)
  %348 = zext i8 %347 to i32
  %349 = select i1 %345, i32 %348, i32 0
  %.state166 = load <8 x i64>, ptr %.slot26, align 64
  %350 = icmp slt <8 x i64> %.state166, splat (i64 8)
  %351 = and <8 x i1> %344, %350
  %352 = xor <8 x i1> %350, splat (i1 true)
  %353 = and <8 x i1> %344, %352
  %354 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %351)
  %355 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %353)
  %356 = and i1 %354, %355
  br i1 %356, label %varying.divergent167, label %varying.coherent168

schedule.12:                                      ; preds = %varying.coherent.true173, %scheduler.dispatch.route
  %357 = load <8 x i1>, ptr %current.mask, align 1
  %358 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %357)
  %359 = bitcast <8 x i1> %357 to i8
  %360 = call i8 @llvm.cttz.i8(i8 %359, i1 false)
  %361 = zext i8 %360 to i32
  %362 = select i1 %358, i32 %361, i32 0
  %tile_snapshot.spill.load175 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %363 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load175, 0
  %364 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load175, 1
  %.state176 = load <8 x i64>, ptr %.slot26, align 64
  %365 = mul <8 x i64> %.state176, splat (i64 32)
  %366 = add <8 x i64> %364, %365
  %367 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %363, 0
  %368 = insertvalue { <8 x ptr>, <8 x i64> } %367, <8 x i64> %366, 1
  %369 = extractvalue { <8 x ptr>, <8 x i64> } %368, 0
  %370 = extractvalue { <8 x ptr>, <8 x i64> } %368, 1
  %371 = getelementptr i8, <8 x ptr> %369, <8 x i64> %370
  %372 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %371, i32 1, <8 x i1> %357, <8 x float> zeroinitializer)
  %.spill.load177 = load <8 x float>, ptr %.spill24, align 32
  %373 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %357)
  %374 = bitcast <8 x i1> %357 to i8
  %375 = call i8 @llvm.cttz.i8(i8 %374, i1 false)
  %376 = zext i8 %375 to i32
  %377 = select i1 %373, i32 %376, i32 0
  %378 = extractelement <8 x float> %.spill.load177, i32 %377
  %.splatinsert178 = insertelement <8 x float> poison, float %378, i64 0
  %.splat179 = shufflevector <8 x float> %.splatinsert178, <8 x float> poison, <8 x i32> zeroinitializer
  %379 = fsub <8 x float> %372, %.splat179
  %tile_snapshot.spill.load180 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %380 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load180, 0
  %381 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load180, 1
  %.state181 = load <8 x i64>, ptr %.slot26, align 64
  %382 = mul <8 x i64> %.state181, splat (i64 32)
  %383 = add <8 x i64> %381, %382
  %384 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %380, 0
  %385 = insertvalue { <8 x ptr>, <8 x i64> } %384, <8 x i64> %383, 1
  %386 = extractvalue { <8 x ptr>, <8 x i64> } %385, 0
  %387 = extractvalue { <8 x ptr>, <8 x i64> } %385, 1
  %388 = getelementptr i8, <8 x ptr> %386, <8 x i64> %387
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %379, <8 x ptr> %388, i32 1, <8 x i1> %357)
  %.state182 = load <8 x i64>, ptr %.slot26, align 64
  %389 = add <8 x i64> %.state182, splat (i64 1)
  %390 = load <8 x i64>, ptr %.slot26, align 64
  %391 = select <8 x i1> %357, <8 x i64> %389, <8 x i64> %390
  store <8 x i64> %391, ptr %.slot26, align 64
  store <8 x i1> %357, ptr %current.mask, align 1
  %392 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %357)
  br i1 %392, label %schedule.11, label %scheduler.loop

schedule.13:                                      ; preds = %varying.coherent.false174, %scheduler.dispatch.route
  %393 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token185 = load i32, ptr %current.token, align 4
  %convergence.token.present186 = icmp ne i32 %convergence.current.token185, 0
  br i1 %convergence.token.present186, label %convergence.cascade183, label %convergence.cascade.exit184

schedule.14:                                      ; preds = %varying.coherent.true207, %scheduler.dispatch.route
  %394 = load <8 x i1>, ptr %current.mask, align 1
  %395 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %394)
  %396 = bitcast <8 x i1> %394 to i8
  %397 = call i8 @llvm.cttz.i8(i8 %396, i1 false)
  %398 = zext i8 %397 to i32
  %399 = select i1 %395, i32 %398, i32 0
  %tile_snapshot.spill.load209 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %400 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load209, 0
  %401 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load209, 1
  %402 = add <8 x i64> %401, splat (i64 256)
  %403 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %400, 0
  %404 = insertvalue { <8 x ptr>, <8 x i64> } %403, <8 x i64> %402, 1
  %405 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %406 = extractvalue { <8 x ptr>, <8 x i64> } %404, 1
  %407 = extractelement <8 x ptr> %405, i32 0
  %408 = extractelement <8 x i64> %406, i32 %399
  %409 = zext i32 %399 to i64
  %410 = mul i64 %409, 4
  %411 = sub i64 %408, %410
  %412 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %394)
  %413 = select i1 %412, i64 %411, i64 0
  %private.contiguous.address210 = getelementptr i8, ptr %407, i64 %413
  %private.contiguous.load211 = load <8 x float>, ptr %private.contiguous.address210, align 4
  %414 = select <8 x i1> %394, <8 x float> %private.contiguous.load211, <8 x float> zeroinitializer
  %.spill.load212 = load <8 x float>, ptr %.spill24, align 32
  %415 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %394)
  %416 = bitcast <8 x i1> %394 to i8
  %417 = call i8 @llvm.cttz.i8(i8 %416, i1 false)
  %418 = zext i8 %417 to i32
  %419 = select i1 %415, i32 %418, i32 0
  %420 = extractelement <8 x float> %.spill.load212, i32 %419
  %.splatinsert213 = insertelement <8 x float> poison, float %420, i64 0
  %.splat214 = shufflevector <8 x float> %.splatinsert213, <8 x float> poison, <8 x i32> zeroinitializer
  %421 = fsub <8 x float> %414, %.splat214
  %tile_snapshot.spill.load215 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %422 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load215, 0
  %423 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load215, 1
  %424 = add <8 x i64> %423, splat (i64 256)
  %425 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %422, 0
  %426 = insertvalue { <8 x ptr>, <8 x i64> } %425, <8 x i64> %424, 1
  %427 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %428 = extractvalue { <8 x ptr>, <8 x i64> } %426, 1
  %429 = extractelement <8 x ptr> %427, i32 0
  %430 = extractelement <8 x i64> %428, i32 %399
  %431 = zext i32 %399 to i64
  %432 = mul i64 %431, 4
  %433 = sub i64 %430, %432
  %434 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %394)
  %435 = select i1 %434, i64 %433, i64 0
  %private.contiguous.address216 = getelementptr i8, ptr %429, i64 %435
  %private.contiguous.preserve217 = load <8 x float>, ptr %private.contiguous.address216, align 4
  %436 = select <8 x i1> %394, <8 x float> %421, <8 x float> %private.contiguous.preserve217
  store <8 x float> %436, ptr %private.contiguous.address216, align 4
  store <8 x i1> %394, ptr %current.mask, align 1
  %437 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %394)
  br i1 %437, label %schedule.15, label %scheduler.loop

schedule.15:                                      ; preds = %schedule.14, %varying.coherent.false208, %scheduler.dispatch.route
  %438 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token220 = load i32, ptr %current.token, align 4
  %convergence.token.present221 = icmp ne i32 %convergence.current.token220, 0
  br i1 %convergence.token.present221, label %convergence.cascade218, label %convergence.cascade.exit219

schedule.16:                                      ; preds = %schedule.17, %convergence.target.15.ready, %scheduler.dispatch.route
  %439 = load <8 x i1>, ptr %current.mask, align 1
  %440 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %439)
  %441 = bitcast <8 x i1> %439 to i8
  %442 = call i8 @llvm.cttz.i8(i8 %441, i1 false)
  %443 = zext i8 %442 to i32
  %444 = select i1 %440, i32 %443, i32 0
  %.state247 = load <8 x i64>, ptr %.slot27, align 64
  %445 = icmp slt <8 x i64> %.state247, splat (i64 8)
  %446 = and <8 x i1> %439, %445
  %447 = xor <8 x i1> %445, splat (i1 true)
  %448 = and <8 x i1> %439, %447
  %449 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %446)
  %450 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %448)
  %451 = and i1 %449, %450
  br i1 %451, label %varying.divergent248, label %varying.coherent249

schedule.17:                                      ; preds = %varying.coherent.true254, %scheduler.dispatch.route
  %452 = load <8 x i1>, ptr %current.mask, align 1
  %453 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %452)
  %454 = bitcast <8 x i1> %452 to i8
  %455 = call i8 @llvm.cttz.i8(i8 %454, i1 false)
  %456 = zext i8 %455 to i32
  %457 = select i1 %453, i32 %456, i32 0
  %.state256 = load <8 x i64>, ptr %.slot27, align 64
  %458 = add <8 x i64> %.state256, zeroinitializer
  %tile_snapshot.spill.load257 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %459 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load257, 0
  %460 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load257, 1
  %461 = mul <8 x i64> %458, splat (i64 32)
  %462 = add <8 x i64> %460, %461
  %463 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %459, 0
  %464 = insertvalue { <8 x ptr>, <8 x i64> } %463, <8 x i64> %462, 1
  %465 = extractvalue { <8 x ptr>, <8 x i64> } %464, 0
  %466 = extractvalue { <8 x ptr>, <8 x i64> } %464, 1
  %467 = getelementptr i8, <8 x ptr> %465, <8 x i64> %466
  %468 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %467, i32 1, <8 x i1> %452, <8 x float> zeroinitializer)
  %469 = fmul <8 x float> %468, %468
  %.state258 = load <8 x float>, ptr %.slot28, align 32
  %470 = fadd <8 x float> %.state258, %469
  %.state259 = load <8 x i64>, ptr %.slot27, align 64
  %471 = add <8 x i64> %.state259, splat (i64 1)
  %tile_snapshot.spill.load260 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %472 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load260, 0
  %473 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load260, 1
  %474 = mul <8 x i64> %471, splat (i64 32)
  %475 = add <8 x i64> %473, %474
  %476 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %472, 0
  %477 = insertvalue { <8 x ptr>, <8 x i64> } %476, <8 x i64> %475, 1
  %478 = extractvalue { <8 x ptr>, <8 x i64> } %477, 0
  %479 = extractvalue { <8 x ptr>, <8 x i64> } %477, 1
  %480 = getelementptr i8, <8 x ptr> %478, <8 x i64> %479
  %481 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %480, i32 1, <8 x i1> %452, <8 x float> zeroinitializer)
  %482 = fmul <8 x float> %481, %481
  %.state261 = load <8 x float>, ptr %.slot29, align 32
  %483 = fadd <8 x float> %.state261, %482
  %.state262 = load <8 x i64>, ptr %.slot27, align 64
  %484 = add <8 x i64> %.state262, splat (i64 2)
  %tile_snapshot.spill.load263 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %485 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load263, 0
  %486 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load263, 1
  %487 = mul <8 x i64> %484, splat (i64 32)
  %488 = add <8 x i64> %486, %487
  %489 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %485, 0
  %490 = insertvalue { <8 x ptr>, <8 x i64> } %489, <8 x i64> %488, 1
  %491 = extractvalue { <8 x ptr>, <8 x i64> } %490, 0
  %492 = extractvalue { <8 x ptr>, <8 x i64> } %490, 1
  %493 = getelementptr i8, <8 x ptr> %491, <8 x i64> %492
  %494 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %493, i32 1, <8 x i1> %452, <8 x float> zeroinitializer)
  %495 = fmul <8 x float> %494, %494
  %.state264 = load <8 x float>, ptr %.slot30, align 32
  %496 = fadd <8 x float> %.state264, %495
  %.state265 = load <8 x i64>, ptr %.slot27, align 64
  %497 = add <8 x i64> %.state265, splat (i64 3)
  %tile_snapshot.spill.load266 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %498 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load266, 0
  %499 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load266, 1
  %500 = mul <8 x i64> %497, splat (i64 32)
  %501 = add <8 x i64> %499, %500
  %502 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %498, 0
  %503 = insertvalue { <8 x ptr>, <8 x i64> } %502, <8 x i64> %501, 1
  %504 = extractvalue { <8 x ptr>, <8 x i64> } %503, 0
  %505 = extractvalue { <8 x ptr>, <8 x i64> } %503, 1
  %506 = getelementptr i8, <8 x ptr> %504, <8 x i64> %505
  %507 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %506, i32 1, <8 x i1> %452, <8 x float> zeroinitializer)
  %508 = fmul <8 x float> %507, %507
  %.state267 = load <8 x float>, ptr %.slot31, align 32
  %509 = fadd <8 x float> %.state267, %508
  %.state268 = load <8 x i64>, ptr %.slot27, align 64
  %510 = add <8 x i64> %.state268, splat (i64 4)
  %511 = load <8 x i64>, ptr %.slot27, align 64
  %512 = select <8 x i1> %452, <8 x i64> %510, <8 x i64> %511
  store <8 x i64> %512, ptr %.slot27, align 64
  %513 = load <8 x float>, ptr %.slot28, align 32
  %514 = select <8 x i1> %452, <8 x float> %470, <8 x float> %513
  store <8 x float> %514, ptr %.slot28, align 32
  %515 = load <8 x float>, ptr %.slot29, align 32
  %516 = select <8 x i1> %452, <8 x float> %483, <8 x float> %515
  store <8 x float> %516, ptr %.slot29, align 32
  %517 = load <8 x float>, ptr %.slot30, align 32
  %518 = select <8 x i1> %452, <8 x float> %496, <8 x float> %517
  store <8 x float> %518, ptr %.slot30, align 32
  %519 = load <8 x float>, ptr %.slot31, align 32
  %520 = select <8 x i1> %452, <8 x float> %509, <8 x float> %519
  store <8 x float> %520, ptr %.slot31, align 32
  store <8 x i1> %452, ptr %current.mask, align 1
  %521 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %452)
  br i1 %521, label %schedule.16, label %scheduler.loop

schedule.18:                                      ; preds = %varying.coherent.false255, %scheduler.dispatch.route
  %522 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token271 = load i32, ptr %current.token, align 4
  %convergence.token.present272 = icmp ne i32 %convergence.current.token271, 0
  br i1 %convergence.token.present272, label %convergence.cascade269, label %convergence.cascade.exit270

schedule.19:                                      ; preds = %varying.coherent.true294, %scheduler.dispatch.route
  %523 = load <8 x i1>, ptr %current.mask, align 1
  %524 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %523)
  %525 = bitcast <8 x i1> %523 to i8
  %526 = call i8 @llvm.cttz.i8(i8 %525, i1 false)
  %527 = zext i8 %526 to i32
  %528 = select i1 %524, i32 %527, i32 0
  %tile_snapshot.spill.load297 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load297, 0
  %530 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load297, 1
  %531 = add <8 x i64> %530, splat (i64 256)
  %532 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %529, 0
  %533 = insertvalue { <8 x ptr>, <8 x i64> } %532, <8 x i64> %531, 1
  %534 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %535 = extractvalue { <8 x ptr>, <8 x i64> } %533, 1
  %536 = extractelement <8 x ptr> %534, i32 0
  %537 = extractelement <8 x i64> %535, i32 %528
  %538 = zext i32 %528 to i64
  %539 = mul i64 %538, 4
  %540 = sub i64 %537, %539
  %541 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %523)
  %542 = select i1 %541, i64 %540, i64 0
  %private.contiguous.address298 = getelementptr i8, ptr %536, i64 %542
  %private.contiguous.load299 = load <8 x float>, ptr %private.contiguous.address298, align 4
  %543 = select <8 x i1> %523, <8 x float> %private.contiguous.load299, <8 x float> zeroinitializer
  %544 = fmul <8 x float> %543, %543
  %.state300 = load <8 x float>, ptr %.slot28, align 32
  %545 = fadd <8 x float> %.state300, %544
  %546 = load <8 x float>, ptr %.slot32, align 32
  %547 = select <8 x i1> %523, <8 x float> %545, <8 x float> %546
  store <8 x float> %547, ptr %.slot32, align 32
  store <8 x i1> %523, ptr %current.mask, align 1
  %548 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %523)
  br i1 %548, label %schedule.20, label %scheduler.loop

schedule.20:                                      ; preds = %schedule.19, %varying.coherent.false295, %scheduler.dispatch.route
  %549 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token303 = load i32, ptr %current.token, align 4
  %convergence.token.present304 = icmp ne i32 %convergence.current.token303, 0
  br i1 %convergence.token.present304, label %convergence.cascade301, label %convergence.cascade.exit302

schedule.21:                                      ; preds = %schedule.22, %convergence.target.20.ready, %scheduler.dispatch.route
  %550 = load <8 x i1>, ptr %current.mask, align 1
  %551 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %550)
  %552 = bitcast <8 x i1> %550 to i8
  %553 = call i8 @llvm.cttz.i8(i8 %552, i1 false)
  %554 = zext i8 %553 to i32
  %555 = select i1 %551, i32 %554, i32 0
  %.state329 = load <8 x i64>, ptr %.slot35, align 64
  %556 = icmp slt <8 x i64> %.state329, splat (i64 8)
  %557 = and <8 x i1> %550, %556
  %558 = xor <8 x i1> %556, splat (i1 true)
  %559 = and <8 x i1> %550, %558
  %560 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %557)
  %561 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %559)
  %562 = and i1 %560, %561
  br i1 %562, label %varying.divergent330, label %varying.coherent331

schedule.22:                                      ; preds = %varying.coherent.true336, %scheduler.dispatch.route
  %563 = load <8 x i1>, ptr %current.mask, align 1
  %564 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %563)
  %565 = bitcast <8 x i1> %563 to i8
  %566 = call i8 @llvm.cttz.i8(i8 %565, i1 false)
  %567 = zext i8 %566 to i32
  %568 = select i1 %564, i32 %567, i32 0
  %.state338 = load <8 x i64>, ptr %.slot35, align 64
  %569 = mul <8 x i64> %.state338, splat (i64 8)
  %.spill.load339 = load <8 x i64>, ptr %.spill, align 64
  %570 = add <8 x i64> %569, %.spill.load339
  %.spill.load340 = load i64, ptr %.spill13, align 4
  %571 = add i64 %.spill.load340, 0
  %572 = add <8 x i64> zeroinitializer, %570
  %573 = mul i64 %571, 66
  %.splatinsert341 = insertelement <8 x i64> poison, i64 %573, i64 0
  %.splat342 = shufflevector <8 x i64> %.splatinsert341, <8 x i64> poison, <8 x i32> zeroinitializer
  %574 = add <8 x i64> %.splat342, %572
  %575 = extractvalue { ptr, i64 } %19, 0
  %576 = extractelement <8 x i64> %574, i32 %568
  %577 = zext i32 %568 to i64
  %578 = sub i64 %576, %577
  %579 = mul i64 %578, 4
  %buffer.contiguous.address343 = getelementptr i8, ptr %575, i64 %579
  %buffer.contiguous.load344 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address343, i32 1, <8 x i1> %563, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load345 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill34, align 64
  %580 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load345, 0
  %581 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load345, 1
  %.state346 = load <8 x i64>, ptr %.slot35, align 64
  %582 = mul <8 x i64> %.state346, splat (i64 32)
  %583 = add <8 x i64> %581, %582
  %584 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %580, 0
  %585 = insertvalue { <8 x ptr>, <8 x i64> } %584, <8 x i64> %583, 1
  %586 = extractvalue { <8 x ptr>, <8 x i64> } %585, 0
  %587 = extractvalue { <8 x ptr>, <8 x i64> } %585, 1
  %588 = getelementptr i8, <8 x ptr> %586, <8 x i64> %587
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %buffer.contiguous.load344, <8 x ptr> %588, i32 1, <8 x i1> %563)
  %.state347 = load <8 x i64>, ptr %.slot35, align 64
  %589 = add <8 x i64> %.state347, splat (i64 1)
  %590 = load <8 x i64>, ptr %.slot35, align 64
  %591 = select <8 x i1> %563, <8 x i64> %589, <8 x i64> %590
  store <8 x i64> %591, ptr %.slot35, align 64
  store <8 x i1> %563, ptr %current.mask, align 1
  %592 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %563)
  br i1 %592, label %schedule.21, label %scheduler.loop

schedule.23:                                      ; preds = %varying.coherent.false337, %scheduler.dispatch.route
  %593 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token350 = load i32, ptr %current.token, align 4
  %convergence.token.present351 = icmp ne i32 %convergence.current.token350, 0
  br i1 %convergence.token.present351, label %convergence.cascade348, label %convergence.cascade.exit349

schedule.24:                                      ; preds = %varying.coherent.true372, %scheduler.dispatch.route
  %594 = load <8 x i1>, ptr %current.mask, align 1
  %595 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %594)
  %596 = bitcast <8 x i1> %594 to i8
  %597 = call i8 @llvm.cttz.i8(i8 %596, i1 false)
  %598 = zext i8 %597 to i32
  %599 = select i1 %595, i32 %598, i32 0
  %.spill.load374 = load <8 x i64>, ptr %.spill, align 64
  %600 = add <8 x i64> splat (i64 64), %.spill.load374
  %.spill.load375 = load i64, ptr %.spill13, align 4
  %601 = add i64 %.spill.load375, 0
  %602 = add <8 x i64> zeroinitializer, %600
  %603 = mul i64 %601, 66
  %.splatinsert376 = insertelement <8 x i64> poison, i64 %603, i64 0
  %.splat377 = shufflevector <8 x i64> %.splatinsert376, <8 x i64> poison, <8 x i32> zeroinitializer
  %604 = add <8 x i64> %.splat377, %602
  %605 = extractvalue { ptr, i64 } %19, 0
  %606 = extractelement <8 x i64> %604, i32 %599
  %607 = zext i32 %599 to i64
  %608 = sub i64 %606, %607
  %609 = mul i64 %608, 4
  %buffer.contiguous.address378 = getelementptr i8, ptr %605, i64 %609
  %buffer.contiguous.load379 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address378, i32 1, <8 x i1> %594, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load380 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill34, align 64
  %610 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load380, 0
  %611 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load380, 1
  %612 = add <8 x i64> %611, splat (i64 256)
  %613 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %610, 0
  %614 = insertvalue { <8 x ptr>, <8 x i64> } %613, <8 x i64> %612, 1
  %615 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %616 = extractvalue { <8 x ptr>, <8 x i64> } %614, 1
  %617 = extractelement <8 x ptr> %615, i32 0
  %618 = extractelement <8 x i64> %616, i32 %599
  %619 = zext i32 %599 to i64
  %620 = mul i64 %619, 4
  %621 = sub i64 %618, %620
  %622 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %594)
  %623 = select i1 %622, i64 %621, i64 0
  %private.contiguous.address381 = getelementptr i8, ptr %617, i64 %623
  %private.contiguous.preserve382 = load <8 x float>, ptr %private.contiguous.address381, align 4
  %624 = select <8 x i1> %594, <8 x float> %buffer.contiguous.load379, <8 x float> %private.contiguous.preserve382
  store <8 x float> %624, ptr %private.contiguous.address381, align 4
  store <8 x i1> %594, ptr %current.mask, align 1
  %625 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %594)
  br i1 %625, label %schedule.25, label %scheduler.loop

schedule.25:                                      ; preds = %schedule.24, %varying.coherent.false373, %scheduler.dispatch.route
  %626 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token385 = load i32, ptr %current.token, align 4
  %convergence.token.present386 = icmp ne i32 %convergence.current.token385, 0
  br i1 %convergence.token.present386, label %convergence.cascade383, label %convergence.cascade.exit384

schedule.26:                                      ; preds = %schedule.27, %convergence.target.25.ready, %scheduler.dispatch.route
  %627 = load <8 x i1>, ptr %current.mask, align 1
  %628 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %627)
  %629 = bitcast <8 x i1> %627 to i8
  %630 = call i8 @llvm.cttz.i8(i8 %629, i1 false)
  %631 = zext i8 %630 to i32
  %632 = select i1 %628, i32 %631, i32 0
  %.state403 = load <8 x i64>, ptr %.slot38, align 64
  %633 = icmp slt <8 x i64> %.state403, splat (i64 8)
  %634 = and <8 x i1> %627, %633
  %635 = xor <8 x i1> %633, splat (i1 true)
  %636 = and <8 x i1> %627, %635
  %637 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %634)
  %638 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %636)
  %639 = and i1 %637, %638
  br i1 %639, label %varying.divergent404, label %varying.coherent405

schedule.27:                                      ; preds = %varying.coherent.true410, %scheduler.dispatch.route
  %640 = load <8 x i1>, ptr %current.mask, align 1
  %641 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %640)
  %642 = bitcast <8 x i1> %640 to i8
  %643 = call i8 @llvm.cttz.i8(i8 %642, i1 false)
  %644 = zext i8 %643 to i32
  %645 = select i1 %641, i32 %644, i32 0
  %.state412 = load <8 x i64>, ptr %.slot38, align 64
  %646 = mul <8 x i64> %.state412, splat (i64 8)
  %.spill.load413 = load <8 x i64>, ptr %.spill, align 64
  %647 = add <8 x i64> %646, %.spill.load413
  %.spill.load414 = load i64, ptr %.spill13, align 4
  %648 = add i64 %.spill.load414, 0
  %649 = add <8 x i64> zeroinitializer, %647
  %650 = mul i64 %648, 66
  %.splatinsert415 = insertelement <8 x i64> poison, i64 %650, i64 0
  %.splat416 = shufflevector <8 x i64> %.splatinsert415, <8 x i64> poison, <8 x i32> zeroinitializer
  %651 = add <8 x i64> %.splat416, %649
  %652 = extractvalue { ptr, i64 } %25, 0
  %653 = extractelement <8 x i64> %651, i32 %645
  %654 = zext i32 %645 to i64
  %655 = sub i64 %653, %654
  %656 = mul i64 %655, 4
  %buffer.contiguous.address417 = getelementptr i8, ptr %652, i64 %656
  %buffer.contiguous.load418 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address417, i32 1, <8 x i1> %640, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load419 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %657 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load419, 0
  %658 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load419, 1
  %.state420 = load <8 x i64>, ptr %.slot38, align 64
  %659 = mul <8 x i64> %.state420, splat (i64 32)
  %660 = add <8 x i64> %658, %659
  %661 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %657, 0
  %662 = insertvalue { <8 x ptr>, <8 x i64> } %661, <8 x i64> %660, 1
  %663 = extractvalue { <8 x ptr>, <8 x i64> } %662, 0
  %664 = extractvalue { <8 x ptr>, <8 x i64> } %662, 1
  %665 = getelementptr i8, <8 x ptr> %663, <8 x i64> %664
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %buffer.contiguous.load418, <8 x ptr> %665, i32 1, <8 x i1> %640)
  %.state421 = load <8 x i64>, ptr %.slot38, align 64
  %666 = add <8 x i64> %.state421, splat (i64 1)
  %667 = load <8 x i64>, ptr %.slot38, align 64
  %668 = select <8 x i1> %640, <8 x i64> %666, <8 x i64> %667
  store <8 x i64> %668, ptr %.slot38, align 64
  store <8 x i1> %640, ptr %current.mask, align 1
  %669 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %640)
  br i1 %669, label %schedule.26, label %scheduler.loop

schedule.28:                                      ; preds = %varying.coherent.false411, %scheduler.dispatch.route
  %670 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token424 = load i32, ptr %current.token, align 4
  %convergence.token.present425 = icmp ne i32 %convergence.current.token424, 0
  br i1 %convergence.token.present425, label %convergence.cascade422, label %convergence.cascade.exit423

schedule.29:                                      ; preds = %varying.coherent.true446, %scheduler.dispatch.route
  %671 = load <8 x i1>, ptr %current.mask, align 1
  %672 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %671)
  %673 = bitcast <8 x i1> %671 to i8
  %674 = call i8 @llvm.cttz.i8(i8 %673, i1 false)
  %675 = zext i8 %674 to i32
  %676 = select i1 %672, i32 %675, i32 0
  %.spill.load448 = load <8 x i64>, ptr %.spill, align 64
  %677 = add <8 x i64> splat (i64 64), %.spill.load448
  %.spill.load449 = load i64, ptr %.spill13, align 4
  %678 = add i64 %.spill.load449, 0
  %679 = add <8 x i64> zeroinitializer, %677
  %680 = mul i64 %678, 66
  %.splatinsert450 = insertelement <8 x i64> poison, i64 %680, i64 0
  %.splat451 = shufflevector <8 x i64> %.splatinsert450, <8 x i64> poison, <8 x i32> zeroinitializer
  %681 = add <8 x i64> %.splat451, %679
  %682 = extractvalue { ptr, i64 } %25, 0
  %683 = extractelement <8 x i64> %681, i32 %676
  %684 = zext i32 %676 to i64
  %685 = sub i64 %683, %684
  %686 = mul i64 %685, 4
  %buffer.contiguous.address452 = getelementptr i8, ptr %682, i64 %686
  %buffer.contiguous.load453 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address452, i32 1, <8 x i1> %671, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load454 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %687 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load454, 0
  %688 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load454, 1
  %689 = add <8 x i64> %688, splat (i64 256)
  %690 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %687, 0
  %691 = insertvalue { <8 x ptr>, <8 x i64> } %690, <8 x i64> %689, 1
  %692 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %693 = extractvalue { <8 x ptr>, <8 x i64> } %691, 1
  %694 = extractelement <8 x ptr> %692, i32 0
  %695 = extractelement <8 x i64> %693, i32 %676
  %696 = zext i32 %676 to i64
  %697 = mul i64 %696, 4
  %698 = sub i64 %695, %697
  %699 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %671)
  %700 = select i1 %699, i64 %698, i64 0
  %private.contiguous.address455 = getelementptr i8, ptr %694, i64 %700
  %private.contiguous.preserve456 = load <8 x float>, ptr %private.contiguous.address455, align 4
  %701 = select <8 x i1> %671, <8 x float> %buffer.contiguous.load453, <8 x float> %private.contiguous.preserve456
  store <8 x float> %701, ptr %private.contiguous.address455, align 4
  store <8 x i1> %671, ptr %current.mask, align 1
  %702 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %671)
  br i1 %702, label %schedule.30, label %scheduler.loop

schedule.30:                                      ; preds = %schedule.29, %varying.coherent.false447, %scheduler.dispatch.route
  %703 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token459 = load i32, ptr %current.token, align 4
  %convergence.token.present460 = icmp ne i32 %convergence.current.token459, 0
  br i1 %convergence.token.present460, label %convergence.cascade457, label %convergence.cascade.exit458

schedule.31:                                      ; preds = %schedule.32, %convergence.target.30.ready, %scheduler.dispatch.route
  %704 = load <8 x i1>, ptr %current.mask, align 1
  %705 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %704)
  %706 = bitcast <8 x i1> %704 to i8
  %707 = call i8 @llvm.cttz.i8(i8 %706, i1 false)
  %708 = zext i8 %707 to i32
  %709 = select i1 %705, i32 %708, i32 0
  %.state474 = load <8 x i64>, ptr %.slot39, align 64
  %710 = icmp slt <8 x i64> %.state474, splat (i64 8)
  %711 = and <8 x i1> %704, %710
  %712 = xor <8 x i1> %710, splat (i1 true)
  %713 = and <8 x i1> %704, %712
  %714 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %711)
  %715 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %713)
  %716 = and i1 %714, %715
  br i1 %716, label %varying.divergent475, label %varying.coherent476

schedule.32:                                      ; preds = %varying.coherent.true481, %scheduler.dispatch.route
  %717 = load <8 x i1>, ptr %current.mask, align 1
  %718 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %717)
  %719 = bitcast <8 x i1> %717 to i8
  %720 = call i8 @llvm.cttz.i8(i8 %719, i1 false)
  %721 = zext i8 %720 to i32
  %722 = select i1 %718, i32 %721, i32 0
  %.state483 = load <8 x i64>, ptr %.slot39, align 64
  %723 = mul <8 x i64> %.state483, splat (i64 8)
  %.spill.load484 = load <8 x i64>, ptr %.spill, align 64
  %724 = add <8 x i64> %723, %.spill.load484
  %.spill.load485 = load <8 x i64>, ptr %.spill10, align 64
  %725 = add <8 x i64> %.spill.load485, zeroinitializer
  %726 = add <8 x i64> zeroinitializer, %725
  %727 = add <8 x i64> zeroinitializer, %724
  %728 = mul <8 x i64> %726, splat (i64 66)
  %729 = add <8 x i64> %728, %727
  %tile_snapshot.spill.load486 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %730 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load486, 0
  %731 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load486, 1
  %.state487 = load <8 x i64>, ptr %.slot39, align 64
  %732 = mul <8 x i64> %.state487, splat (i64 32)
  %733 = add <8 x i64> %731, %732
  %734 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %730, 0
  %735 = insertvalue { <8 x ptr>, <8 x i64> } %734, <8 x i64> %733, 1
  %736 = extractvalue { <8 x ptr>, <8 x i64> } %735, 0
  %737 = extractvalue { <8 x ptr>, <8 x i64> } %735, 1
  %738 = getelementptr i8, <8 x ptr> %736, <8 x i64> %737
  %739 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %738, i32 1, <8 x i1> %717, <8 x float> zeroinitializer)
  %.spill.load488 = load <8 x float>, ptr %.spill36, align 32
  %740 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %717)
  %741 = bitcast <8 x i1> %717 to i8
  %742 = call i8 @llvm.cttz.i8(i8 %741, i1 false)
  %743 = zext i8 %742 to i32
  %744 = select i1 %740, i32 %743, i32 0
  %745 = extractelement <8 x float> %.spill.load488, i32 %744
  %.splatinsert489 = insertelement <8 x float> poison, float %745, i64 0
  %.splat490 = shufflevector <8 x float> %.splatinsert489, <8 x float> poison, <8 x i32> zeroinitializer
  %746 = fdiv <8 x float> %739, %.splat490
  %tile_snapshot.spill.load491 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill34, align 64
  %747 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load491, 0
  %748 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load491, 1
  %.state492 = load <8 x i64>, ptr %.slot39, align 64
  %749 = mul <8 x i64> %.state492, splat (i64 32)
  %750 = add <8 x i64> %748, %749
  %751 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %747, 0
  %752 = insertvalue { <8 x ptr>, <8 x i64> } %751, <8 x i64> %750, 1
  %753 = extractvalue { <8 x ptr>, <8 x i64> } %752, 0
  %754 = extractvalue { <8 x ptr>, <8 x i64> } %752, 1
  %755 = getelementptr i8, <8 x ptr> %753, <8 x i64> %754
  %756 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %755, i32 1, <8 x i1> %717, <8 x float> zeroinitializer)
  %757 = fmul <8 x float> %746, %756
  %tile_snapshot.spill.load493 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %758 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load493, 0
  %759 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load493, 1
  %.state494 = load <8 x i64>, ptr %.slot39, align 64
  %760 = mul <8 x i64> %.state494, splat (i64 32)
  %761 = add <8 x i64> %759, %760
  %762 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %758, 0
  %763 = insertvalue { <8 x ptr>, <8 x i64> } %762, <8 x i64> %761, 1
  %764 = extractvalue { <8 x ptr>, <8 x i64> } %763, 0
  %765 = extractvalue { <8 x ptr>, <8 x i64> } %763, 1
  %766 = getelementptr i8, <8 x ptr> %764, <8 x i64> %765
  %767 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %766, i32 1, <8 x i1> %717, <8 x float> zeroinitializer)
  %768 = fadd <8 x float> %757, %767
  %769 = extractvalue { ptr, i64 } %31, 0
  %770 = extractelement <8 x i64> %729, i32 %722
  %771 = zext i32 %722 to i64
  %772 = sub i64 %770, %771
  %773 = mul i64 %772, 4
  %buffer.contiguous.address495 = getelementptr i8, ptr %769, i64 %773
  call void @llvm.masked.store.v8f32.p0(<8 x float> %768, ptr %buffer.contiguous.address495, i32 1, <8 x i1> %717)
  %.state496 = load <8 x i64>, ptr %.slot39, align 64
  %774 = add <8 x i64> %.state496, splat (i64 1)
  %775 = load <8 x i64>, ptr %.slot39, align 64
  %776 = select <8 x i1> %717, <8 x i64> %774, <8 x i64> %775
  store <8 x i64> %776, ptr %.slot39, align 64
  store <8 x i1> %717, ptr %current.mask, align 1
  %777 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %717)
  br i1 %777, label %schedule.31, label %scheduler.loop

schedule.33:                                      ; preds = %varying.coherent.false482, %scheduler.dispatch.route
  %778 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token499 = load i32, ptr %current.token, align 4
  %convergence.token.present500 = icmp ne i32 %convergence.current.token499, 0
  br i1 %convergence.token.present500, label %convergence.cascade497, label %convergence.cascade.exit498

schedule.34:                                      ; preds = %varying.coherent.true521, %scheduler.dispatch.route
  %779 = load <8 x i1>, ptr %current.mask, align 1
  %780 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %779)
  %781 = bitcast <8 x i1> %779 to i8
  %782 = call i8 @llvm.cttz.i8(i8 %781, i1 false)
  %783 = zext i8 %782 to i32
  %784 = select i1 %780, i32 %783, i32 0
  %.spill.load523 = load <8 x i64>, ptr %.spill, align 64
  %785 = add <8 x i64> splat (i64 64), %.spill.load523
  %.spill.load524 = load <8 x i64>, ptr %.spill10, align 64
  %786 = add <8 x i64> %.spill.load524, zeroinitializer
  %787 = add <8 x i64> zeroinitializer, %786
  %788 = add <8 x i64> zeroinitializer, %785
  %789 = mul <8 x i64> %787, splat (i64 66)
  %790 = add <8 x i64> %789, %788
  %tile_snapshot.spill.load525 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %791 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load525, 0
  %792 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load525, 1
  %793 = add <8 x i64> %792, splat (i64 256)
  %794 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %791, 0
  %795 = insertvalue { <8 x ptr>, <8 x i64> } %794, <8 x i64> %793, 1
  %796 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %797 = extractvalue { <8 x ptr>, <8 x i64> } %795, 1
  %798 = extractelement <8 x ptr> %796, i32 0
  %799 = extractelement <8 x i64> %797, i32 %784
  %800 = zext i32 %784 to i64
  %801 = mul i64 %800, 4
  %802 = sub i64 %799, %801
  %803 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %779)
  %804 = select i1 %803, i64 %802, i64 0
  %private.contiguous.address526 = getelementptr i8, ptr %798, i64 %804
  %private.contiguous.load527 = load <8 x float>, ptr %private.contiguous.address526, align 4
  %805 = select <8 x i1> %779, <8 x float> %private.contiguous.load527, <8 x float> zeroinitializer
  %.spill.load528 = load <8 x float>, ptr %.spill36, align 32
  %806 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %779)
  %807 = bitcast <8 x i1> %779 to i8
  %808 = call i8 @llvm.cttz.i8(i8 %807, i1 false)
  %809 = zext i8 %808 to i32
  %810 = select i1 %806, i32 %809, i32 0
  %811 = extractelement <8 x float> %.spill.load528, i32 %810
  %.splatinsert529 = insertelement <8 x float> poison, float %811, i64 0
  %.splat530 = shufflevector <8 x float> %.splatinsert529, <8 x float> poison, <8 x i32> zeroinitializer
  %812 = fdiv <8 x float> %805, %.splat530
  %tile_snapshot.spill.load531 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill34, align 64
  %813 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load531, 0
  %814 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load531, 1
  %815 = add <8 x i64> %814, splat (i64 256)
  %816 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %813, 0
  %817 = insertvalue { <8 x ptr>, <8 x i64> } %816, <8 x i64> %815, 1
  %818 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %819 = extractvalue { <8 x ptr>, <8 x i64> } %817, 1
  %820 = extractelement <8 x ptr> %818, i32 0
  %821 = extractelement <8 x i64> %819, i32 %784
  %822 = zext i32 %784 to i64
  %823 = mul i64 %822, 4
  %824 = sub i64 %821, %823
  %825 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %779)
  %826 = select i1 %825, i64 %824, i64 0
  %private.contiguous.address532 = getelementptr i8, ptr %820, i64 %826
  %private.contiguous.load533 = load <8 x float>, ptr %private.contiguous.address532, align 4
  %827 = select <8 x i1> %779, <8 x float> %private.contiguous.load533, <8 x float> zeroinitializer
  %828 = fmul <8 x float> %812, %827
  %tile_snapshot.spill.load534 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %829 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load534, 0
  %830 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load534, 1
  %831 = add <8 x i64> %830, splat (i64 256)
  %832 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %829, 0
  %833 = insertvalue { <8 x ptr>, <8 x i64> } %832, <8 x i64> %831, 1
  %834 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %835 = extractvalue { <8 x ptr>, <8 x i64> } %833, 1
  %836 = extractelement <8 x ptr> %834, i32 0
  %837 = extractelement <8 x i64> %835, i32 %784
  %838 = zext i32 %784 to i64
  %839 = mul i64 %838, 4
  %840 = sub i64 %837, %839
  %841 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %779)
  %842 = select i1 %841, i64 %840, i64 0
  %private.contiguous.address535 = getelementptr i8, ptr %836, i64 %842
  %private.contiguous.load536 = load <8 x float>, ptr %private.contiguous.address535, align 4
  %843 = select <8 x i1> %779, <8 x float> %private.contiguous.load536, <8 x float> zeroinitializer
  %844 = fadd <8 x float> %828, %843
  %845 = extractvalue { ptr, i64 } %31, 0
  %846 = extractelement <8 x i64> %790, i32 %784
  %847 = zext i32 %784 to i64
  %848 = sub i64 %846, %847
  %849 = mul i64 %848, 4
  %buffer.contiguous.address537 = getelementptr i8, ptr %845, i64 %849
  call void @llvm.masked.store.v8f32.p0(<8 x float> %844, ptr %buffer.contiguous.address537, i32 1, <8 x i1> %779)
  store <8 x i1> %779, ptr %current.mask, align 1
  %850 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %779)
  br i1 %850, label %schedule.35, label %scheduler.loop

schedule.35:                                      ; preds = %schedule.34, %varying.coherent.false522, %scheduler.dispatch.route
  %851 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token540 = load i32, ptr %current.token, align 4
  %convergence.token.present541 = icmp ne i32 %convergence.current.token540, 0
  br i1 %convergence.token.present541, label %convergence.cascade538, label %convergence.cascade.exit539

uniform.true:                                     ; preds = %schedule.1
  store <8 x i1> %120, ptr %current.mask, align 1
  %852 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %120)
  br i1 %852, label %schedule.2, label %scheduler.loop

uniform.false:                                    ; preds = %schedule.1
  store <8 x i1> %120, ptr %current.mask, align 1
  %853 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %120)
  br i1 %853, label %schedule.3, label %scheduler.loop

varying.divergent:                                ; preds = %schedule.3
  %854 = load i32, ptr %current.token, align 4
  %855 = icmp ne i32 %854, 0
  %856 = sub i32 %854, 1
  %857 = select i1 %855, i32 %856, i32 0
  %858 = load i8, ptr %frame.active, align 1
  %859 = trunc i32 %857 to i8
  %860 = shl i8 1, %859
  %861 = and i8 %858, %860
  %862 = icmp ne i8 %861, 0
  %863 = load <8 x i32>, ptr %frame.static.id, align 32
  %864 = extractelement <8 x i32> %863, i32 %857
  %865 = icmp eq i32 %864, 0
  %866 = and i1 %862, %865
  %867 = and i1 %855, %866
  %868 = xor i1 %867, true
  %869 = and i1 true, %868
  %870 = xor i8 %858, -1
  %871 = icmp ne i8 %870, 0
  %872 = xor i1 %871, true
  %873 = and i1 %869, %872
  br i1 %873, label %convergence.overflow.trap, label %convergence.overflow.resume

varying.coherent:                                 ; preds = %schedule.3
  br i1 %201, label %varying.coherent.true, label %varying.coherent.false

convergence.overflow.trap:                        ; preds = %varying.divergent
  call void @llvm.trap()
  unreachable

convergence.overflow.resume:                      ; preds = %varying.divergent
  %874 = call i8 @llvm.cttz.i8(i8 %870, i1 false)
  %875 = zext i8 %874 to i32
  %876 = select i1 %871, i32 %875, i32 0
  %877 = trunc i32 %876 to i8
  %878 = shl i8 1, %877
  %879 = or i8 %858, %878
  %880 = select i1 %869, i8 %879, i8 %858
  store i8 %880, ptr %frame.active, align 1
  %881 = load <8 x i32>, ptr %frame.static.id, align 32
  %882 = extractelement <8 x i32> %881, i32 %876
  %883 = select i1 %869, i32 0, i32 %882
  %884 = load <8 x i32>, ptr %frame.static.id, align 32
  %885 = insertelement <8 x i32> %884, i32 %883, i32 %876
  store <8 x i32> %885, ptr %frame.static.id, align 32
  %886 = load <8 x i32>, ptr %frame.parent.token, align 32
  %887 = extractelement <8 x i32> %886, i32 %876
  %888 = select i1 %869, i32 %854, i32 %887
  %889 = load <8 x i32>, ptr %frame.parent.token, align 32
  %890 = insertelement <8 x i32> %889, i32 %888, i32 %876
  store <8 x i32> %890, ptr %frame.parent.token, align 32
  %891 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %876
  %892 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %876
  %893 = load <8 x i1>, ptr %891, align 1
  %894 = load <8 x i1>, ptr %892, align 1
  %895 = select i1 %869, <8 x i1> %189, <8 x i1> %893
  store <8 x i1> %895, ptr %891, align 1
  %896 = select i1 %869, <8 x i1> zeroinitializer, <8 x i1> %894
  store <8 x i1> %896, ptr %892, align 1
  %897 = add i32 %876, 1
  %898 = select i1 %867, i32 %854, i32 %897
  %899 = select i1 true, i32 %898, i32 %854
  store i32 %899, ptr %current.token, align 4
  %900 = load i32, ptr %current.token, align 4
  %901 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %198)
  %902 = load i32, ptr %ready.count, align 4
  %903 = icmp uge i32 %902, 8
  %904 = and i1 %901, %903
  br i1 %904, label %ready.overflow.trap61, label %ready.overflow.resume62

ready.overflow.trap61:                            ; preds = %convergence.overflow.resume
  call void @llvm.trap()
  unreachable

ready.overflow.resume62:                          ; preds = %convergence.overflow.resume
  %905 = select i1 %901, i32 %902, i32 0
  %906 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %905
  %907 = load <8 x i1>, ptr %906, align 1
  %908 = select i1 %901, <8 x i1> %198, <8 x i1> %907
  store <8 x i1> %908, ptr %906, align 1
  %909 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %905
  %910 = load i32, ptr %909, align 4
  %911 = select i1 %901, i32 4, i32 %910
  store i32 %911, ptr %909, align 4
  %912 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %905
  %913 = load i32, ptr %912, align 4
  %914 = select i1 %901, i32 %900, i32 %913
  store i32 %914, ptr %912, align 4
  %915 = add i32 %902, 1
  %916 = select i1 %901, i32 %915, i32 %902
  store i32 %916, ptr %ready.count, align 4
  %917 = load <8 x i1>, ptr %runnable.mask, align 1
  %918 = or <8 x i1> %917, %198
  store <8 x i1> %918, ptr %runnable.mask, align 1
  store <8 x i1> %200, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true:                            ; preds = %varying.coherent
  store <8 x i1> %189, ptr %current.mask, align 1
  %919 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %189)
  br i1 %919, label %schedule.4, label %scheduler.loop

varying.coherent.false:                           ; preds = %varying.coherent
  store <8 x i1> %189, ptr %current.mask, align 1
  %920 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %189)
  br i1 %920, label %schedule.5, label %scheduler.loop

convergence.cascade:                              ; preds = %convergence.cascade, %schedule.5
  %convergence.cascade.flow = phi <8 x i1> [ %237, %schedule.5 ], [ %963, %convergence.cascade ]
  %convergence.cascade.depth = phi i32 [ 0, %schedule.5 ], [ %964, %convergence.cascade ]
  %921 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow)
  %922 = load i32, ptr %current.token, align 4
  %923 = icmp ne i32 %922, 0
  %924 = and i1 %921, %923
  %925 = sub i32 %922, 1
  %926 = select i1 %924, i32 %925, i32 0
  %927 = load i8, ptr %frame.active, align 1
  %928 = trunc i32 %926 to i8
  %929 = shl i8 1, %928
  %930 = and i8 %927, %929
  %931 = icmp ne i8 %930, 0
  %932 = load <8 x i32>, ptr %frame.static.id, align 32
  %933 = extractelement <8 x i32> %932, i32 %926
  %convergence.target.pointer = getelementptr inbounds [13 x i32], ptr @convergence.targets, i32 0, i32 %933
  %convergence.dynamic.target = load i32, ptr %convergence.target.pointer, align 4
  %934 = icmp eq i32 %convergence.dynamic.target, 5
  %935 = and i1 %931, %934
  %936 = and i1 %924, %935
  %937 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %926
  %938 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %926
  %939 = load <8 x i1>, ptr %937, align 1
  %940 = load <8 x i1>, ptr %938, align 1
  %941 = or <8 x i1> %940, %convergence.cascade.flow
  %942 = load <8 x i1>, ptr %live.mask, align 1
  %943 = and <8 x i1> %939, %942
  %944 = icmp eq <8 x i1> %941, %943
  %945 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %944)
  %946 = and i1 %936, %945
  %947 = select i1 %946, <8 x i1> zeroinitializer, <8 x i1> %941
  %948 = select i1 %936, <8 x i1> %947, <8 x i1> %940
  store <8 x i1> %948, ptr %938, align 1
  %949 = select i1 %946, <8 x i1> zeroinitializer, <8 x i1> %939
  store <8 x i1> %949, ptr %937, align 1
  %950 = trunc i32 %926 to i8
  %951 = shl i8 1, %950
  %952 = xor i8 %951, -1
  %953 = and i8 %927, %952
  %954 = select i1 %946, i8 %953, i8 %927
  store i8 %954, ptr %frame.active, align 1
  %.splatinsert70 = insertelement <8 x i1> poison, i1 %936, i64 0
  %.splat71 = shufflevector <8 x i1> %.splatinsert70, <8 x i1> poison, <8 x i32> zeroinitializer
  %955 = and <8 x i1> %convergence.cascade.flow, %.splat71
  %956 = load <8 x i1>, ptr %runnable.mask, align 1
  %957 = xor <8 x i1> %955, splat (i1 true)
  %958 = and <8 x i1> %956, %957
  store <8 x i1> %958, ptr %runnable.mask, align 1
  %.splatinsert72 = insertelement <8 x i1> poison, i1 %946, i64 0
  %.splat73 = shufflevector <8 x i1> %.splatinsert72, <8 x i1> poison, <8 x i32> zeroinitializer
  %959 = select <8 x i1> %.splat73, <8 x i1> %941, <8 x i1> zeroinitializer
  %960 = load <8 x i32>, ptr %frame.parent.token, align 32
  %961 = extractelement <8 x i32> %960, i32 %926
  %962 = select i1 %946, i32 %961, i32 %922
  store i32 %962, ptr %current.token, align 4
  %.splatinsert74 = insertelement <8 x i1> poison, i1 %936, i64 0
  %.splat75 = shufflevector <8 x i1> %.splatinsert74, <8 x i1> poison, <8 x i32> zeroinitializer
  %963 = select <8 x i1> %.splat75, <8 x i1> %959, <8 x i1> %convergence.cascade.flow
  %964 = add i32 %convergence.cascade.depth, 1
  %965 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %963)
  %966 = icmp ult i32 %964, 8
  %967 = and i1 %965, %966
  %968 = and i1 %936, %967
  %convergence.parent.token = load i32, ptr %current.token, align 4
  %convergence.parent.present = icmp ne i32 %convergence.parent.token, 0
  %969 = and i1 %968, %convergence.parent.present
  br i1 %969, label %convergence.cascade, label %convergence.cascade.exit

convergence.cascade.exit:                         ; preds = %convergence.cascade, %schedule.5
  %convergence.cascade.result = phi <8 x i1> [ %237, %schedule.5 ], [ %963, %convergence.cascade ]
  %970 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %970, label %convergence.target.5.ready, label %scheduler.loop

convergence.target.5.ready:                       ; preds = %convergence.cascade.exit
  %971 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %972 = bitcast <8 x i1> %convergence.cascade.result to i8
  %973 = call i8 @llvm.cttz.i8(i8 %972, i1 false)
  %974 = zext i8 %973 to i32
  %975 = select i1 %971, i32 %974, i32 0
  store float 0.000000e+00, ptr %.spill12, align 4
  store i64 0, ptr %.spill13, align 4
  %tile_snapshot.spill.load76 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %976 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load76, 0
  %977 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load76, 1
  %978 = add <8 x i64> %977, zeroinitializer
  %979 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %976, 0
  %980 = insertvalue { <8 x ptr>, <8 x i64> } %979, <8 x i64> %978, 1
  %981 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %982 = extractvalue { <8 x ptr>, <8 x i64> } %980, 1
  %983 = extractelement <8 x ptr> %981, i32 0
  %984 = extractelement <8 x i64> %982, i32 %975
  %985 = zext i32 %975 to i64
  %986 = mul i64 %985, 4
  %987 = sub i64 %984, %986
  %988 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %989 = select i1 %988, i64 %987, i64 0
  %private.contiguous.address77 = getelementptr i8, ptr %983, i64 %989
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address77, align 4
  %990 = select <8 x i1> %convergence.cascade.result, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load78 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %991 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load78, 0
  %992 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load78, 1
  %993 = add <8 x i64> %992, splat (i64 32)
  %994 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %991, 0
  %995 = insertvalue { <8 x ptr>, <8 x i64> } %994, <8 x i64> %993, 1
  %996 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %997 = extractvalue { <8 x ptr>, <8 x i64> } %995, 1
  %998 = extractelement <8 x ptr> %996, i32 0
  %999 = extractelement <8 x i64> %997, i32 %975
  %1000 = zext i32 %975 to i64
  %1001 = mul i64 %1000, 4
  %1002 = sub i64 %999, %1001
  %1003 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1004 = select i1 %1003, i64 %1002, i64 0
  %private.contiguous.address79 = getelementptr i8, ptr %998, i64 %1004
  %private.contiguous.load80 = load <8 x float>, ptr %private.contiguous.address79, align 4
  %1005 = select <8 x i1> %convergence.cascade.result, <8 x float> %private.contiguous.load80, <8 x float> zeroinitializer
  %tile_snapshot.spill.load81 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1006 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load81, 0
  %1007 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load81, 1
  %1008 = add <8 x i64> %1007, splat (i64 64)
  %1009 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1006, 0
  %1010 = insertvalue { <8 x ptr>, <8 x i64> } %1009, <8 x i64> %1008, 1
  %1011 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1012 = extractvalue { <8 x ptr>, <8 x i64> } %1010, 1
  %1013 = extractelement <8 x ptr> %1011, i32 0
  %1014 = extractelement <8 x i64> %1012, i32 %975
  %1015 = zext i32 %975 to i64
  %1016 = mul i64 %1015, 4
  %1017 = sub i64 %1014, %1016
  %1018 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1019 = select i1 %1018, i64 %1017, i64 0
  %private.contiguous.address82 = getelementptr i8, ptr %1013, i64 %1019
  %private.contiguous.load83 = load <8 x float>, ptr %private.contiguous.address82, align 4
  %1020 = select <8 x i1> %convergence.cascade.result, <8 x float> %private.contiguous.load83, <8 x float> zeroinitializer
  %tile_snapshot.spill.load84 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1021 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load84, 0
  %1022 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load84, 1
  %1023 = add <8 x i64> %1022, splat (i64 96)
  %1024 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1021, 0
  %1025 = insertvalue { <8 x ptr>, <8 x i64> } %1024, <8 x i64> %1023, 1
  %1026 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1027 = extractvalue { <8 x ptr>, <8 x i64> } %1025, 1
  %1028 = extractelement <8 x ptr> %1026, i32 0
  %1029 = extractelement <8 x i64> %1027, i32 %975
  %1030 = zext i32 %975 to i64
  %1031 = mul i64 %1030, 4
  %1032 = sub i64 %1029, %1031
  %1033 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1034 = select i1 %1033, i64 %1032, i64 0
  %private.contiguous.address85 = getelementptr i8, ptr %1028, i64 %1034
  %private.contiguous.load86 = load <8 x float>, ptr %private.contiguous.address85, align 4
  %1035 = select <8 x i1> %convergence.cascade.result, <8 x float> %private.contiguous.load86, <8 x float> zeroinitializer
  %1036 = load <8 x i64>, ptr %.slot14, align 64
  %1037 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 4), <8 x i64> %1036
  store <8 x i64> %1037, ptr %.slot14, align 64
  %1038 = load <8 x float>, ptr %.slot15, align 32
  %1039 = select <8 x i1> %convergence.cascade.result, <8 x float> %990, <8 x float> %1038
  store <8 x float> %1039, ptr %.slot15, align 32
  %1040 = load <8 x float>, ptr %.slot16, align 32
  %1041 = select <8 x i1> %convergence.cascade.result, <8 x float> %1005, <8 x float> %1040
  store <8 x float> %1041, ptr %.slot16, align 32
  %1042 = load <8 x float>, ptr %.slot17, align 32
  %1043 = select <8 x i1> %convergence.cascade.result, <8 x float> %1020, <8 x float> %1042
  store <8 x float> %1043, ptr %.slot17, align 32
  %1044 = load <8 x float>, ptr %.slot18, align 32
  %1045 = select <8 x i1> %convergence.cascade.result, <8 x float> %1035, <8 x float> %1044
  store <8 x float> %1045, ptr %.slot18, align 32
  store <8 x i1> %convergence.cascade.result, ptr %current.mask, align 1
  %1046 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %1046, label %schedule.6, label %scheduler.loop

varying.divergent88:                              ; preds = %schedule.6
  %1047 = load i32, ptr %current.token, align 4
  %1048 = icmp ne i32 %1047, 0
  %1049 = sub i32 %1047, 1
  %1050 = select i1 %1048, i32 %1049, i32 0
  %1051 = load i8, ptr %frame.active, align 1
  %1052 = trunc i32 %1050 to i8
  %1053 = shl i8 1, %1052
  %1054 = and i8 %1051, %1053
  %1055 = icmp ne i8 %1054, 0
  %1056 = load <8 x i32>, ptr %frame.static.id, align 32
  %1057 = extractelement <8 x i32> %1056, i32 %1050
  %1058 = icmp eq i32 %1057, 1
  %1059 = and i1 %1055, %1058
  %1060 = and i1 %1048, %1059
  %1061 = xor i1 %1060, true
  %1062 = and i1 true, %1061
  %1063 = xor i8 %1051, -1
  %1064 = icmp ne i8 %1063, 0
  %1065 = xor i1 %1064, true
  %1066 = and i1 %1062, %1065
  br i1 %1066, label %convergence.overflow.trap90, label %convergence.overflow.resume91

varying.coherent89:                               ; preds = %schedule.6
  br i1 %248, label %varying.coherent.true94, label %varying.coherent.false95

convergence.overflow.trap90:                      ; preds = %varying.divergent88
  call void @llvm.trap()
  unreachable

convergence.overflow.resume91:                    ; preds = %varying.divergent88
  %1067 = call i8 @llvm.cttz.i8(i8 %1063, i1 false)
  %1068 = zext i8 %1067 to i32
  %1069 = select i1 %1064, i32 %1068, i32 0
  %1070 = trunc i32 %1069 to i8
  %1071 = shl i8 1, %1070
  %1072 = or i8 %1051, %1071
  %1073 = select i1 %1062, i8 %1072, i8 %1051
  store i8 %1073, ptr %frame.active, align 1
  %1074 = load <8 x i32>, ptr %frame.static.id, align 32
  %1075 = extractelement <8 x i32> %1074, i32 %1069
  %1076 = select i1 %1062, i32 1, i32 %1075
  %1077 = load <8 x i32>, ptr %frame.static.id, align 32
  %1078 = insertelement <8 x i32> %1077, i32 %1076, i32 %1069
  store <8 x i32> %1078, ptr %frame.static.id, align 32
  %1079 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1080 = extractelement <8 x i32> %1079, i32 %1069
  %1081 = select i1 %1062, i32 %1047, i32 %1080
  %1082 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1083 = insertelement <8 x i32> %1082, i32 %1081, i32 %1069
  store <8 x i32> %1083, ptr %frame.parent.token, align 32
  %1084 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1069
  %1085 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1069
  %1086 = load <8 x i1>, ptr %1084, align 1
  %1087 = load <8 x i1>, ptr %1085, align 1
  %1088 = select i1 %1062, <8 x i1> %238, <8 x i1> %1086
  store <8 x i1> %1088, ptr %1084, align 1
  %1089 = select i1 %1062, <8 x i1> zeroinitializer, <8 x i1> %1087
  store <8 x i1> %1089, ptr %1085, align 1
  %1090 = add i32 %1069, 1
  %1091 = select i1 %1060, i32 %1047, i32 %1090
  %1092 = select i1 true, i32 %1091, i32 %1047
  store i32 %1092, ptr %current.token, align 4
  %1093 = load i32, ptr %current.token, align 4
  %1094 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %245)
  %1095 = load i32, ptr %ready.count, align 4
  %1096 = icmp uge i32 %1095, 8
  %1097 = and i1 %1094, %1096
  br i1 %1097, label %ready.overflow.trap92, label %ready.overflow.resume93

ready.overflow.trap92:                            ; preds = %convergence.overflow.resume91
  call void @llvm.trap()
  unreachable

ready.overflow.resume93:                          ; preds = %convergence.overflow.resume91
  %1098 = select i1 %1094, i32 %1095, i32 0
  %1099 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1098
  %1100 = load <8 x i1>, ptr %1099, align 1
  %1101 = select i1 %1094, <8 x i1> %245, <8 x i1> %1100
  store <8 x i1> %1101, ptr %1099, align 1
  %1102 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1098
  %1103 = load i32, ptr %1102, align 4
  %1104 = select i1 %1094, i32 7, i32 %1103
  store i32 %1104, ptr %1102, align 4
  %1105 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1098
  %1106 = load i32, ptr %1105, align 4
  %1107 = select i1 %1094, i32 %1093, i32 %1106
  store i32 %1107, ptr %1105, align 4
  %1108 = add i32 %1095, 1
  %1109 = select i1 %1094, i32 %1108, i32 %1095
  store i32 %1109, ptr %ready.count, align 4
  %1110 = load <8 x i1>, ptr %runnable.mask, align 1
  %1111 = or <8 x i1> %1110, %245
  store <8 x i1> %1111, ptr %runnable.mask, align 1
  store <8 x i1> %247, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true94:                          ; preds = %varying.coherent89
  store <8 x i1> %238, ptr %current.mask, align 1
  %1112 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %238)
  br i1 %1112, label %schedule.7, label %scheduler.loop

varying.coherent.false95:                         ; preds = %varying.coherent89
  store <8 x i1> %238, ptr %current.mask, align 1
  %1113 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %238)
  br i1 %1113, label %schedule.8, label %scheduler.loop

convergence.cascade109:                           ; preds = %convergence.cascade109, %schedule.8
  %convergence.cascade.flow113 = phi <8 x i1> [ %317, %schedule.8 ], [ %1156, %convergence.cascade109 ]
  %convergence.cascade.depth114 = phi i32 [ 0, %schedule.8 ], [ %1157, %convergence.cascade109 ]
  %1114 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow113)
  %1115 = load i32, ptr %current.token, align 4
  %1116 = icmp ne i32 %1115, 0
  %1117 = and i1 %1114, %1116
  %1118 = sub i32 %1115, 1
  %1119 = select i1 %1117, i32 %1118, i32 0
  %1120 = load i8, ptr %frame.active, align 1
  %1121 = trunc i32 %1119 to i8
  %1122 = shl i8 1, %1121
  %1123 = and i8 %1120, %1122
  %1124 = icmp ne i8 %1123, 0
  %1125 = load <8 x i32>, ptr %frame.static.id, align 32
  %1126 = extractelement <8 x i32> %1125, i32 %1119
  %convergence.target.pointer115 = getelementptr inbounds [13 x i32], ptr @convergence.targets, i32 0, i32 %1126
  %convergence.dynamic.target116 = load i32, ptr %convergence.target.pointer115, align 4
  %1127 = icmp eq i32 %convergence.dynamic.target116, 8
  %1128 = and i1 %1124, %1127
  %1129 = and i1 %1117, %1128
  %1130 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1119
  %1131 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1119
  %1132 = load <8 x i1>, ptr %1130, align 1
  %1133 = load <8 x i1>, ptr %1131, align 1
  %1134 = or <8 x i1> %1133, %convergence.cascade.flow113
  %1135 = load <8 x i1>, ptr %live.mask, align 1
  %1136 = and <8 x i1> %1132, %1135
  %1137 = icmp eq <8 x i1> %1134, %1136
  %1138 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1137)
  %1139 = and i1 %1129, %1138
  %1140 = select i1 %1139, <8 x i1> zeroinitializer, <8 x i1> %1134
  %1141 = select i1 %1129, <8 x i1> %1140, <8 x i1> %1133
  store <8 x i1> %1141, ptr %1131, align 1
  %1142 = select i1 %1139, <8 x i1> zeroinitializer, <8 x i1> %1132
  store <8 x i1> %1142, ptr %1130, align 1
  %1143 = trunc i32 %1119 to i8
  %1144 = shl i8 1, %1143
  %1145 = xor i8 %1144, -1
  %1146 = and i8 %1120, %1145
  %1147 = select i1 %1139, i8 %1146, i8 %1120
  store i8 %1147, ptr %frame.active, align 1
  %.splatinsert117 = insertelement <8 x i1> poison, i1 %1129, i64 0
  %.splat118 = shufflevector <8 x i1> %.splatinsert117, <8 x i1> poison, <8 x i32> zeroinitializer
  %1148 = and <8 x i1> %convergence.cascade.flow113, %.splat118
  %1149 = load <8 x i1>, ptr %runnable.mask, align 1
  %1150 = xor <8 x i1> %1148, splat (i1 true)
  %1151 = and <8 x i1> %1149, %1150
  store <8 x i1> %1151, ptr %runnable.mask, align 1
  %.splatinsert119 = insertelement <8 x i1> poison, i1 %1139, i64 0
  %.splat120 = shufflevector <8 x i1> %.splatinsert119, <8 x i1> poison, <8 x i32> zeroinitializer
  %1152 = select <8 x i1> %.splat120, <8 x i1> %1134, <8 x i1> zeroinitializer
  %1153 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1154 = extractelement <8 x i32> %1153, i32 %1119
  %1155 = select i1 %1139, i32 %1154, i32 %1115
  store i32 %1155, ptr %current.token, align 4
  %.splatinsert121 = insertelement <8 x i1> poison, i1 %1129, i64 0
  %.splat122 = shufflevector <8 x i1> %.splatinsert121, <8 x i1> poison, <8 x i32> zeroinitializer
  %1156 = select <8 x i1> %.splat122, <8 x i1> %1152, <8 x i1> %convergence.cascade.flow113
  %1157 = add i32 %convergence.cascade.depth114, 1
  %1158 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1156)
  %1159 = icmp ult i32 %1157, 8
  %1160 = and i1 %1158, %1159
  %1161 = and i1 %1129, %1160
  %convergence.parent.token123 = load i32, ptr %current.token, align 4
  %convergence.parent.present124 = icmp ne i32 %convergence.parent.token123, 0
  %1162 = and i1 %1161, %convergence.parent.present124
  br i1 %1162, label %convergence.cascade109, label %convergence.cascade.exit110

convergence.cascade.exit110:                      ; preds = %convergence.cascade109, %schedule.8
  %convergence.cascade.result125 = phi <8 x i1> [ %317, %schedule.8 ], [ %1156, %convergence.cascade109 ]
  %1163 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result125)
  br i1 %1163, label %convergence.target.8.ready, label %scheduler.loop

convergence.target.8.ready:                       ; preds = %convergence.cascade.exit110
  %1164 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result125)
  %1165 = bitcast <8 x i1> %convergence.cascade.result125 to i8
  %1166 = call i8 @llvm.cttz.i8(i8 %1165, i1 false)
  %1167 = zext i8 %1166 to i32
  %1168 = select i1 %1164, i32 %1167, i32 0
  %.spill.load126 = load <8 x i1>, ptr %.spill11, align 1
  %1169 = and <8 x i1> %convergence.cascade.result125, %.spill.load126
  %1170 = xor <8 x i1> %.spill.load126, splat (i1 true)
  %1171 = and <8 x i1> %convergence.cascade.result125, %1170
  %1172 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1169)
  %1173 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1171)
  %1174 = and i1 %1172, %1173
  br i1 %1174, label %varying.divergent127, label %varying.coherent128

varying.divergent127:                             ; preds = %convergence.target.8.ready
  %1175 = load i32, ptr %current.token, align 4
  %1176 = icmp ne i32 %1175, 0
  %1177 = sub i32 %1175, 1
  %1178 = select i1 %1176, i32 %1177, i32 0
  %1179 = load i8, ptr %frame.active, align 1
  %1180 = trunc i32 %1178 to i8
  %1181 = shl i8 1, %1180
  %1182 = and i8 %1179, %1181
  %1183 = icmp ne i8 %1182, 0
  %1184 = load <8 x i32>, ptr %frame.static.id, align 32
  %1185 = extractelement <8 x i32> %1184, i32 %1178
  %1186 = icmp eq i32 %1185, 2
  %1187 = and i1 %1183, %1186
  %1188 = and i1 %1176, %1187
  %1189 = xor i1 %1188, true
  %1190 = and i1 true, %1189
  %1191 = xor i8 %1179, -1
  %1192 = icmp ne i8 %1191, 0
  %1193 = xor i1 %1192, true
  %1194 = and i1 %1190, %1193
  br i1 %1194, label %convergence.overflow.trap129, label %convergence.overflow.resume130

varying.coherent128:                              ; preds = %convergence.target.8.ready
  br i1 %1172, label %varying.coherent.true134, label %varying.coherent.false135

convergence.overflow.trap129:                     ; preds = %varying.divergent127
  call void @llvm.trap()
  unreachable

convergence.overflow.resume130:                   ; preds = %varying.divergent127
  %1195 = call i8 @llvm.cttz.i8(i8 %1191, i1 false)
  %1196 = zext i8 %1195 to i32
  %1197 = select i1 %1192, i32 %1196, i32 0
  %1198 = trunc i32 %1197 to i8
  %1199 = shl i8 1, %1198
  %1200 = or i8 %1179, %1199
  %1201 = select i1 %1190, i8 %1200, i8 %1179
  store i8 %1201, ptr %frame.active, align 1
  %1202 = load <8 x i32>, ptr %frame.static.id, align 32
  %1203 = extractelement <8 x i32> %1202, i32 %1197
  %1204 = select i1 %1190, i32 2, i32 %1203
  %1205 = load <8 x i32>, ptr %frame.static.id, align 32
  %1206 = insertelement <8 x i32> %1205, i32 %1204, i32 %1197
  store <8 x i32> %1206, ptr %frame.static.id, align 32
  %1207 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1208 = extractelement <8 x i32> %1207, i32 %1197
  %1209 = select i1 %1190, i32 %1175, i32 %1208
  %1210 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1211 = insertelement <8 x i32> %1210, i32 %1209, i32 %1197
  store <8 x i32> %1211, ptr %frame.parent.token, align 32
  %1212 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1197
  %1213 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1197
  %1214 = load <8 x i1>, ptr %1212, align 1
  %1215 = load <8 x i1>, ptr %1213, align 1
  %1216 = select i1 %1190, <8 x i1> %convergence.cascade.result125, <8 x i1> %1214
  store <8 x i1> %1216, ptr %1212, align 1
  %1217 = select i1 %1190, <8 x i1> zeroinitializer, <8 x i1> %1215
  store <8 x i1> %1217, ptr %1213, align 1
  %1218 = add i32 %1197, 1
  %1219 = select i1 %1188, i32 %1175, i32 %1218
  %1220 = select i1 true, i32 %1219, i32 %1175
  store i32 %1220, ptr %current.token, align 4
  %.state131 = load <8 x float>, ptr %.slot15, align 32
  %1221 = load <8 x float>, ptr %.slot19, align 32
  %1222 = select <8 x i1> %1171, <8 x float> %.state131, <8 x float> %1221
  store <8 x float> %1222, ptr %.slot19, align 32
  %1223 = load i32, ptr %current.token, align 4
  %1224 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1169)
  %1225 = load i32, ptr %ready.count, align 4
  %1226 = icmp uge i32 %1225, 8
  %1227 = and i1 %1224, %1226
  br i1 %1227, label %ready.overflow.trap132, label %ready.overflow.resume133

ready.overflow.trap132:                           ; preds = %convergence.overflow.resume130
  call void @llvm.trap()
  unreachable

ready.overflow.resume133:                         ; preds = %convergence.overflow.resume130
  %1228 = select i1 %1224, i32 %1225, i32 0
  %1229 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1228
  %1230 = load <8 x i1>, ptr %1229, align 1
  %1231 = select i1 %1224, <8 x i1> %1169, <8 x i1> %1230
  store <8 x i1> %1231, ptr %1229, align 1
  %1232 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1228
  %1233 = load i32, ptr %1232, align 4
  %1234 = select i1 %1224, i32 9, i32 %1233
  store i32 %1234, ptr %1232, align 4
  %1235 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1228
  %1236 = load i32, ptr %1235, align 4
  %1237 = select i1 %1224, i32 %1223, i32 %1236
  store i32 %1237, ptr %1235, align 4
  %1238 = add i32 %1225, 1
  %1239 = select i1 %1224, i32 %1238, i32 %1225
  store i32 %1239, ptr %ready.count, align 4
  %1240 = load <8 x i1>, ptr %runnable.mask, align 1
  %1241 = or <8 x i1> %1240, %1169
  store <8 x i1> %1241, ptr %runnable.mask, align 1
  store <8 x i1> %1171, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true134:                         ; preds = %varying.coherent128
  store <8 x i1> %convergence.cascade.result125, ptr %current.mask, align 1
  %1242 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result125)
  br i1 %1242, label %schedule.9, label %scheduler.loop

varying.coherent.false135:                        ; preds = %varying.coherent128
  %.state136 = load <8 x float>, ptr %.slot15, align 32
  %1243 = load <8 x float>, ptr %.slot19, align 32
  %1244 = select <8 x i1> %convergence.cascade.result125, <8 x float> %.state136, <8 x float> %1243
  store <8 x float> %1244, ptr %.slot19, align 32
  store <8 x i1> %convergence.cascade.result125, ptr %current.mask, align 1
  %1245 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result125)
  br i1 %1245, label %schedule.10, label %scheduler.loop

convergence.cascade141:                           ; preds = %convergence.cascade141, %schedule.10
  %convergence.cascade.flow145 = phi <8 x i1> [ %343, %schedule.10 ], [ %1288, %convergence.cascade141 ]
  %convergence.cascade.depth146 = phi i32 [ 0, %schedule.10 ], [ %1289, %convergence.cascade141 ]
  %1246 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow145)
  %1247 = load i32, ptr %current.token, align 4
  %1248 = icmp ne i32 %1247, 0
  %1249 = and i1 %1246, %1248
  %1250 = sub i32 %1247, 1
  %1251 = select i1 %1249, i32 %1250, i32 0
  %1252 = load i8, ptr %frame.active, align 1
  %1253 = trunc i32 %1251 to i8
  %1254 = shl i8 1, %1253
  %1255 = and i8 %1252, %1254
  %1256 = icmp ne i8 %1255, 0
  %1257 = load <8 x i32>, ptr %frame.static.id, align 32
  %1258 = extractelement <8 x i32> %1257, i32 %1251
  %convergence.target.pointer147 = getelementptr inbounds [13 x i32], ptr @convergence.targets, i32 0, i32 %1258
  %convergence.dynamic.target148 = load i32, ptr %convergence.target.pointer147, align 4
  %1259 = icmp eq i32 %convergence.dynamic.target148, 10
  %1260 = and i1 %1256, %1259
  %1261 = and i1 %1249, %1260
  %1262 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1251
  %1263 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1251
  %1264 = load <8 x i1>, ptr %1262, align 1
  %1265 = load <8 x i1>, ptr %1263, align 1
  %1266 = or <8 x i1> %1265, %convergence.cascade.flow145
  %1267 = load <8 x i1>, ptr %live.mask, align 1
  %1268 = and <8 x i1> %1264, %1267
  %1269 = icmp eq <8 x i1> %1266, %1268
  %1270 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1269)
  %1271 = and i1 %1261, %1270
  %1272 = select i1 %1271, <8 x i1> zeroinitializer, <8 x i1> %1266
  %1273 = select i1 %1261, <8 x i1> %1272, <8 x i1> %1265
  store <8 x i1> %1273, ptr %1263, align 1
  %1274 = select i1 %1271, <8 x i1> zeroinitializer, <8 x i1> %1264
  store <8 x i1> %1274, ptr %1262, align 1
  %1275 = trunc i32 %1251 to i8
  %1276 = shl i8 1, %1275
  %1277 = xor i8 %1276, -1
  %1278 = and i8 %1252, %1277
  %1279 = select i1 %1271, i8 %1278, i8 %1252
  store i8 %1279, ptr %frame.active, align 1
  %.splatinsert149 = insertelement <8 x i1> poison, i1 %1261, i64 0
  %.splat150 = shufflevector <8 x i1> %.splatinsert149, <8 x i1> poison, <8 x i32> zeroinitializer
  %1280 = and <8 x i1> %convergence.cascade.flow145, %.splat150
  %1281 = load <8 x i1>, ptr %runnable.mask, align 1
  %1282 = xor <8 x i1> %1280, splat (i1 true)
  %1283 = and <8 x i1> %1281, %1282
  store <8 x i1> %1283, ptr %runnable.mask, align 1
  %.splatinsert151 = insertelement <8 x i1> poison, i1 %1271, i64 0
  %.splat152 = shufflevector <8 x i1> %.splatinsert151, <8 x i1> poison, <8 x i32> zeroinitializer
  %1284 = select <8 x i1> %.splat152, <8 x i1> %1266, <8 x i1> zeroinitializer
  %1285 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1286 = extractelement <8 x i32> %1285, i32 %1251
  %1287 = select i1 %1271, i32 %1286, i32 %1247
  store i32 %1287, ptr %current.token, align 4
  %.splatinsert153 = insertelement <8 x i1> poison, i1 %1261, i64 0
  %.splat154 = shufflevector <8 x i1> %.splatinsert153, <8 x i1> poison, <8 x i32> zeroinitializer
  %1288 = select <8 x i1> %.splat154, <8 x i1> %1284, <8 x i1> %convergence.cascade.flow145
  %1289 = add i32 %convergence.cascade.depth146, 1
  %1290 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1288)
  %1291 = icmp ult i32 %1289, 8
  %1292 = and i1 %1290, %1291
  %1293 = and i1 %1261, %1292
  %convergence.parent.token155 = load i32, ptr %current.token, align 4
  %convergence.parent.present156 = icmp ne i32 %convergence.parent.token155, 0
  %1294 = and i1 %1293, %convergence.parent.present156
  br i1 %1294, label %convergence.cascade141, label %convergence.cascade.exit142

convergence.cascade.exit142:                      ; preds = %convergence.cascade141, %schedule.10
  %convergence.cascade.result157 = phi <8 x i1> [ %343, %schedule.10 ], [ %1288, %convergence.cascade141 ]
  %1295 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result157)
  br i1 %1295, label %convergence.target.10.ready, label %scheduler.loop

convergence.target.10.ready:                      ; preds = %convergence.cascade.exit142
  %1296 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result157)
  %1297 = bitcast <8 x i1> %convergence.cascade.result157 to i8
  %1298 = call i8 @llvm.cttz.i8(i8 %1297, i1 false)
  %1299 = zext i8 %1298 to i32
  %1300 = select i1 %1296, i32 %1299, i32 0
  %.state158 = load <8 x float>, ptr %.slot19, align 32
  %.state159 = load <8 x float>, ptr %.slot16, align 32
  %1301 = fadd <8 x float> %.state158, %.state159
  %.state160 = load <8 x float>, ptr %.slot17, align 32
  %1302 = fadd <8 x float> %1301, %.state160
  %.state161 = load <8 x float>, ptr %.slot18, align 32
  %1303 = fadd <8 x float> %1302, %.state161
  %.spill.load162 = load <8 x i64>, ptr %.spill, align 64
  %1304 = trunc <8 x i64> %.spill.load162 to <8 x i32>
  %1305 = xor <8 x i32> %1304, splat (i32 1)
  %1306 = load <8 x i32>, ptr %.spill20, align 32
  %1307 = select <8 x i1> %convergence.cascade.result157, <8 x i32> %1305, <8 x i32> %1306
  store <8 x i32> %1307, ptr %.spill20, align 32
  %1308 = extractelement <8 x i32> %1305, i64 0
  %1309 = icmp ult i32 %1308, 8
  %1310 = select i1 %1309, i32 %1308, i32 0
  %1311 = extractelement <8 x i1> %convergence.cascade.result157, i32 %1310
  %1312 = extractelement <8 x i1> %convergence.cascade.result157, i64 0
  %1313 = and i1 %1309, %1311
  %1314 = and i1 %1312, %1313
  %1315 = extractelement <8 x float> %1303, i32 %1310
  %1316 = select i1 %1314, float %1315, float 0.000000e+00
  %1317 = insertelement <8 x float> poison, float %1316, i64 0
  %1318 = xor i1 %1314, true
  %1319 = and i1 %1312, %1318
  %1320 = insertelement <8 x i1> poison, i1 %1319, i64 0
  %1321 = extractelement <8 x i32> %1305, i64 1
  %1322 = icmp ult i32 %1321, 8
  %1323 = select i1 %1322, i32 %1321, i32 0
  %1324 = extractelement <8 x i1> %convergence.cascade.result157, i32 %1323
  %1325 = extractelement <8 x i1> %convergence.cascade.result157, i64 1
  %1326 = and i1 %1322, %1324
  %1327 = and i1 %1325, %1326
  %1328 = extractelement <8 x float> %1303, i32 %1323
  %1329 = select i1 %1327, float %1328, float 0.000000e+00
  %1330 = insertelement <8 x float> %1317, float %1329, i64 1
  %1331 = xor i1 %1327, true
  %1332 = and i1 %1325, %1331
  %1333 = insertelement <8 x i1> %1320, i1 %1332, i64 1
  %1334 = extractelement <8 x i32> %1305, i64 2
  %1335 = icmp ult i32 %1334, 8
  %1336 = select i1 %1335, i32 %1334, i32 0
  %1337 = extractelement <8 x i1> %convergence.cascade.result157, i32 %1336
  %1338 = extractelement <8 x i1> %convergence.cascade.result157, i64 2
  %1339 = and i1 %1335, %1337
  %1340 = and i1 %1338, %1339
  %1341 = extractelement <8 x float> %1303, i32 %1336
  %1342 = select i1 %1340, float %1341, float 0.000000e+00
  %1343 = insertelement <8 x float> %1330, float %1342, i64 2
  %1344 = xor i1 %1340, true
  %1345 = and i1 %1338, %1344
  %1346 = insertelement <8 x i1> %1333, i1 %1345, i64 2
  %1347 = extractelement <8 x i32> %1305, i64 3
  %1348 = icmp ult i32 %1347, 8
  %1349 = select i1 %1348, i32 %1347, i32 0
  %1350 = extractelement <8 x i1> %convergence.cascade.result157, i32 %1349
  %1351 = extractelement <8 x i1> %convergence.cascade.result157, i64 3
  %1352 = and i1 %1348, %1350
  %1353 = and i1 %1351, %1352
  %1354 = extractelement <8 x float> %1303, i32 %1349
  %1355 = select i1 %1353, float %1354, float 0.000000e+00
  %1356 = insertelement <8 x float> %1343, float %1355, i64 3
  %1357 = xor i1 %1353, true
  %1358 = and i1 %1351, %1357
  %1359 = insertelement <8 x i1> %1346, i1 %1358, i64 3
  %1360 = extractelement <8 x i32> %1305, i64 4
  %1361 = icmp ult i32 %1360, 8
  %1362 = select i1 %1361, i32 %1360, i32 0
  %1363 = extractelement <8 x i1> %convergence.cascade.result157, i32 %1362
  %1364 = extractelement <8 x i1> %convergence.cascade.result157, i64 4
  %1365 = and i1 %1361, %1363
  %1366 = and i1 %1364, %1365
  %1367 = extractelement <8 x float> %1303, i32 %1362
  %1368 = select i1 %1366, float %1367, float 0.000000e+00
  %1369 = insertelement <8 x float> %1356, float %1368, i64 4
  %1370 = xor i1 %1366, true
  %1371 = and i1 %1364, %1370
  %1372 = insertelement <8 x i1> %1359, i1 %1371, i64 4
  %1373 = extractelement <8 x i32> %1305, i64 5
  %1374 = icmp ult i32 %1373, 8
  %1375 = select i1 %1374, i32 %1373, i32 0
  %1376 = extractelement <8 x i1> %convergence.cascade.result157, i32 %1375
  %1377 = extractelement <8 x i1> %convergence.cascade.result157, i64 5
  %1378 = and i1 %1374, %1376
  %1379 = and i1 %1377, %1378
  %1380 = extractelement <8 x float> %1303, i32 %1375
  %1381 = select i1 %1379, float %1380, float 0.000000e+00
  %1382 = insertelement <8 x float> %1369, float %1381, i64 5
  %1383 = xor i1 %1379, true
  %1384 = and i1 %1377, %1383
  %1385 = insertelement <8 x i1> %1372, i1 %1384, i64 5
  %1386 = extractelement <8 x i32> %1305, i64 6
  %1387 = icmp ult i32 %1386, 8
  %1388 = select i1 %1387, i32 %1386, i32 0
  %1389 = extractelement <8 x i1> %convergence.cascade.result157, i32 %1388
  %1390 = extractelement <8 x i1> %convergence.cascade.result157, i64 6
  %1391 = and i1 %1387, %1389
  %1392 = and i1 %1390, %1391
  %1393 = extractelement <8 x float> %1303, i32 %1388
  %1394 = select i1 %1392, float %1393, float 0.000000e+00
  %1395 = insertelement <8 x float> %1382, float %1394, i64 6
  %1396 = xor i1 %1392, true
  %1397 = and i1 %1390, %1396
  %1398 = insertelement <8 x i1> %1385, i1 %1397, i64 6
  %1399 = extractelement <8 x i32> %1305, i64 7
  %1400 = icmp ult i32 %1399, 8
  %1401 = select i1 %1400, i32 %1399, i32 0
  %1402 = extractelement <8 x i1> %convergence.cascade.result157, i32 %1401
  %1403 = extractelement <8 x i1> %convergence.cascade.result157, i64 7
  %1404 = and i1 %1400, %1402
  %1405 = and i1 %1403, %1404
  %1406 = extractelement <8 x float> %1303, i32 %1401
  %1407 = select i1 %1405, float %1406, float 0.000000e+00
  %1408 = insertelement <8 x float> %1395, float %1407, i64 7
  %1409 = xor i1 %1405, true
  %1410 = and i1 %1403, %1409
  %1411 = insertelement <8 x i1> %1398, i1 %1410, i64 7
  %1412 = fadd <8 x float> %1303, %1408
  %1413 = xor <8 x i32> %1304, splat (i32 2)
  %1414 = load <8 x i32>, ptr %.spill21, align 32
  %1415 = select <8 x i1> %convergence.cascade.result157, <8 x i32> %1413, <8 x i32> %1414
  store <8 x i32> %1415, ptr %.spill21, align 32
  %1416 = extractelement <8 x i32> %1413, i64 0
  %1417 = icmp ult i32 %1416, 8
  %1418 = select i1 %1417, i32 %1416, i32 0
  %1419 = extractelement <8 x i1> %convergence.cascade.result157, i32 %1418
  %1420 = extractelement <8 x i1> %convergence.cascade.result157, i64 0
  %1421 = and i1 %1417, %1419
  %1422 = and i1 %1420, %1421
  %1423 = extractelement <8 x float> %1412, i32 %1418
  %1424 = select i1 %1422, float %1423, float 0.000000e+00
  %1425 = insertelement <8 x float> poison, float %1424, i64 0
  %1426 = xor i1 %1422, true
  %1427 = and i1 %1420, %1426
  %1428 = insertelement <8 x i1> poison, i1 %1427, i64 0
  %1429 = extractelement <8 x i32> %1413, i64 1
  %1430 = icmp ult i32 %1429, 8
  %1431 = select i1 %1430, i32 %1429, i32 0
  %1432 = extractelement <8 x i1> %convergence.cascade.result157, i32 %1431
  %1433 = extractelement <8 x i1> %convergence.cascade.result157, i64 1
  %1434 = and i1 %1430, %1432
  %1435 = and i1 %1433, %1434
  %1436 = extractelement <8 x float> %1412, i32 %1431
  %1437 = select i1 %1435, float %1436, float 0.000000e+00
  %1438 = insertelement <8 x float> %1425, float %1437, i64 1
  %1439 = xor i1 %1435, true
  %1440 = and i1 %1433, %1439
  %1441 = insertelement <8 x i1> %1428, i1 %1440, i64 1
  %1442 = extractelement <8 x i32> %1413, i64 2
  %1443 = icmp ult i32 %1442, 8
  %1444 = select i1 %1443, i32 %1442, i32 0
  %1445 = extractelement <8 x i1> %convergence.cascade.result157, i32 %1444
  %1446 = extractelement <8 x i1> %convergence.cascade.result157, i64 2
  %1447 = and i1 %1443, %1445
  %1448 = and i1 %1446, %1447
  %1449 = extractelement <8 x float> %1412, i32 %1444
  %1450 = select i1 %1448, float %1449, float 0.000000e+00
  %1451 = insertelement <8 x float> %1438, float %1450, i64 2
  %1452 = xor i1 %1448, true
  %1453 = and i1 %1446, %1452
  %1454 = insertelement <8 x i1> %1441, i1 %1453, i64 2
  %1455 = extractelement <8 x i32> %1413, i64 3
  %1456 = icmp ult i32 %1455, 8
  %1457 = select i1 %1456, i32 %1455, i32 0
  %1458 = extractelement <8 x i1> %convergence.cascade.result157, i32 %1457
  %1459 = extractelement <8 x i1> %convergence.cascade.result157, i64 3
  %1460 = and i1 %1456, %1458
  %1461 = and i1 %1459, %1460
  %1462 = extractelement <8 x float> %1412, i32 %1457
  %1463 = select i1 %1461, float %1462, float 0.000000e+00
  %1464 = insertelement <8 x float> %1451, float %1463, i64 3
  %1465 = xor i1 %1461, true
  %1466 = and i1 %1459, %1465
  %1467 = insertelement <8 x i1> %1454, i1 %1466, i64 3
  %1468 = extractelement <8 x i32> %1413, i64 4
  %1469 = icmp ult i32 %1468, 8
  %1470 = select i1 %1469, i32 %1468, i32 0
  %1471 = extractelement <8 x i1> %convergence.cascade.result157, i32 %1470
  %1472 = extractelement <8 x i1> %convergence.cascade.result157, i64 4
  %1473 = and i1 %1469, %1471
  %1474 = and i1 %1472, %1473
  %1475 = extractelement <8 x float> %1412, i32 %1470
  %1476 = select i1 %1474, float %1475, float 0.000000e+00
  %1477 = insertelement <8 x float> %1464, float %1476, i64 4
  %1478 = xor i1 %1474, true
  %1479 = and i1 %1472, %1478
  %1480 = insertelement <8 x i1> %1467, i1 %1479, i64 4
  %1481 = extractelement <8 x i32> %1413, i64 5
  %1482 = icmp ult i32 %1481, 8
  %1483 = select i1 %1482, i32 %1481, i32 0
  %1484 = extractelement <8 x i1> %convergence.cascade.result157, i32 %1483
  %1485 = extractelement <8 x i1> %convergence.cascade.result157, i64 5
  %1486 = and i1 %1482, %1484
  %1487 = and i1 %1485, %1486
  %1488 = extractelement <8 x float> %1412, i32 %1483
  %1489 = select i1 %1487, float %1488, float 0.000000e+00
  %1490 = insertelement <8 x float> %1477, float %1489, i64 5
  %1491 = xor i1 %1487, true
  %1492 = and i1 %1485, %1491
  %1493 = insertelement <8 x i1> %1480, i1 %1492, i64 5
  %1494 = extractelement <8 x i32> %1413, i64 6
  %1495 = icmp ult i32 %1494, 8
  %1496 = select i1 %1495, i32 %1494, i32 0
  %1497 = extractelement <8 x i1> %convergence.cascade.result157, i32 %1496
  %1498 = extractelement <8 x i1> %convergence.cascade.result157, i64 6
  %1499 = and i1 %1495, %1497
  %1500 = and i1 %1498, %1499
  %1501 = extractelement <8 x float> %1412, i32 %1496
  %1502 = select i1 %1500, float %1501, float 0.000000e+00
  %1503 = insertelement <8 x float> %1490, float %1502, i64 6
  %1504 = xor i1 %1500, true
  %1505 = and i1 %1498, %1504
  %1506 = insertelement <8 x i1> %1493, i1 %1505, i64 6
  %1507 = extractelement <8 x i32> %1413, i64 7
  %1508 = icmp ult i32 %1507, 8
  %1509 = select i1 %1508, i32 %1507, i32 0
  %1510 = extractelement <8 x i1> %convergence.cascade.result157, i32 %1509
  %1511 = extractelement <8 x i1> %convergence.cascade.result157, i64 7
  %1512 = and i1 %1508, %1510
  %1513 = and i1 %1511, %1512
  %1514 = extractelement <8 x float> %1412, i32 %1509
  %1515 = select i1 %1513, float %1514, float 0.000000e+00
  %1516 = insertelement <8 x float> %1503, float %1515, i64 7
  %1517 = xor i1 %1513, true
  %1518 = and i1 %1511, %1517
  %1519 = insertelement <8 x i1> %1506, i1 %1518, i64 7
  %1520 = fadd <8 x float> %1412, %1516
  %1521 = xor <8 x i32> %1304, splat (i32 4)
  %1522 = load <8 x i32>, ptr %.spill22, align 32
  %1523 = select <8 x i1> %convergence.cascade.result157, <8 x i32> %1521, <8 x i32> %1522
  store <8 x i32> %1523, ptr %.spill22, align 32
  %1524 = extractelement <8 x i32> %1521, i64 0
  %1525 = icmp ult i32 %1524, 8
  %1526 = select i1 %1525, i32 %1524, i32 0
  %1527 = extractelement <8 x i1> %convergence.cascade.result157, i32 %1526
  %1528 = extractelement <8 x i1> %convergence.cascade.result157, i64 0
  %1529 = and i1 %1525, %1527
  %1530 = and i1 %1528, %1529
  %1531 = extractelement <8 x float> %1520, i32 %1526
  %1532 = select i1 %1530, float %1531, float 0.000000e+00
  %1533 = insertelement <8 x float> poison, float %1532, i64 0
  %1534 = xor i1 %1530, true
  %1535 = and i1 %1528, %1534
  %1536 = insertelement <8 x i1> poison, i1 %1535, i64 0
  %1537 = extractelement <8 x i32> %1521, i64 1
  %1538 = icmp ult i32 %1537, 8
  %1539 = select i1 %1538, i32 %1537, i32 0
  %1540 = extractelement <8 x i1> %convergence.cascade.result157, i32 %1539
  %1541 = extractelement <8 x i1> %convergence.cascade.result157, i64 1
  %1542 = and i1 %1538, %1540
  %1543 = and i1 %1541, %1542
  %1544 = extractelement <8 x float> %1520, i32 %1539
  %1545 = select i1 %1543, float %1544, float 0.000000e+00
  %1546 = insertelement <8 x float> %1533, float %1545, i64 1
  %1547 = xor i1 %1543, true
  %1548 = and i1 %1541, %1547
  %1549 = insertelement <8 x i1> %1536, i1 %1548, i64 1
  %1550 = extractelement <8 x i32> %1521, i64 2
  %1551 = icmp ult i32 %1550, 8
  %1552 = select i1 %1551, i32 %1550, i32 0
  %1553 = extractelement <8 x i1> %convergence.cascade.result157, i32 %1552
  %1554 = extractelement <8 x i1> %convergence.cascade.result157, i64 2
  %1555 = and i1 %1551, %1553
  %1556 = and i1 %1554, %1555
  %1557 = extractelement <8 x float> %1520, i32 %1552
  %1558 = select i1 %1556, float %1557, float 0.000000e+00
  %1559 = insertelement <8 x float> %1546, float %1558, i64 2
  %1560 = xor i1 %1556, true
  %1561 = and i1 %1554, %1560
  %1562 = insertelement <8 x i1> %1549, i1 %1561, i64 2
  %1563 = extractelement <8 x i32> %1521, i64 3
  %1564 = icmp ult i32 %1563, 8
  %1565 = select i1 %1564, i32 %1563, i32 0
  %1566 = extractelement <8 x i1> %convergence.cascade.result157, i32 %1565
  %1567 = extractelement <8 x i1> %convergence.cascade.result157, i64 3
  %1568 = and i1 %1564, %1566
  %1569 = and i1 %1567, %1568
  %1570 = extractelement <8 x float> %1520, i32 %1565
  %1571 = select i1 %1569, float %1570, float 0.000000e+00
  %1572 = insertelement <8 x float> %1559, float %1571, i64 3
  %1573 = xor i1 %1569, true
  %1574 = and i1 %1567, %1573
  %1575 = insertelement <8 x i1> %1562, i1 %1574, i64 3
  %1576 = extractelement <8 x i32> %1521, i64 4
  %1577 = icmp ult i32 %1576, 8
  %1578 = select i1 %1577, i32 %1576, i32 0
  %1579 = extractelement <8 x i1> %convergence.cascade.result157, i32 %1578
  %1580 = extractelement <8 x i1> %convergence.cascade.result157, i64 4
  %1581 = and i1 %1577, %1579
  %1582 = and i1 %1580, %1581
  %1583 = extractelement <8 x float> %1520, i32 %1578
  %1584 = select i1 %1582, float %1583, float 0.000000e+00
  %1585 = insertelement <8 x float> %1572, float %1584, i64 4
  %1586 = xor i1 %1582, true
  %1587 = and i1 %1580, %1586
  %1588 = insertelement <8 x i1> %1575, i1 %1587, i64 4
  %1589 = extractelement <8 x i32> %1521, i64 5
  %1590 = icmp ult i32 %1589, 8
  %1591 = select i1 %1590, i32 %1589, i32 0
  %1592 = extractelement <8 x i1> %convergence.cascade.result157, i32 %1591
  %1593 = extractelement <8 x i1> %convergence.cascade.result157, i64 5
  %1594 = and i1 %1590, %1592
  %1595 = and i1 %1593, %1594
  %1596 = extractelement <8 x float> %1520, i32 %1591
  %1597 = select i1 %1595, float %1596, float 0.000000e+00
  %1598 = insertelement <8 x float> %1585, float %1597, i64 5
  %1599 = xor i1 %1595, true
  %1600 = and i1 %1593, %1599
  %1601 = insertelement <8 x i1> %1588, i1 %1600, i64 5
  %1602 = extractelement <8 x i32> %1521, i64 6
  %1603 = icmp ult i32 %1602, 8
  %1604 = select i1 %1603, i32 %1602, i32 0
  %1605 = extractelement <8 x i1> %convergence.cascade.result157, i32 %1604
  %1606 = extractelement <8 x i1> %convergence.cascade.result157, i64 6
  %1607 = and i1 %1603, %1605
  %1608 = and i1 %1606, %1607
  %1609 = extractelement <8 x float> %1520, i32 %1604
  %1610 = select i1 %1608, float %1609, float 0.000000e+00
  %1611 = insertelement <8 x float> %1598, float %1610, i64 6
  %1612 = xor i1 %1608, true
  %1613 = and i1 %1606, %1612
  %1614 = insertelement <8 x i1> %1601, i1 %1613, i64 6
  %1615 = extractelement <8 x i32> %1521, i64 7
  %1616 = icmp ult i32 %1615, 8
  %1617 = select i1 %1616, i32 %1615, i32 0
  %1618 = extractelement <8 x i1> %convergence.cascade.result157, i32 %1617
  %1619 = extractelement <8 x i1> %convergence.cascade.result157, i64 7
  %1620 = and i1 %1616, %1618
  %1621 = and i1 %1619, %1620
  %1622 = extractelement <8 x float> %1520, i32 %1617
  %1623 = select i1 %1621, float %1622, float 0.000000e+00
  %1624 = insertelement <8 x float> %1611, float %1623, i64 7
  %1625 = xor i1 %1621, true
  %1626 = and i1 %1619, %1625
  %1627 = insertelement <8 x i1> %1614, i1 %1626, i64 7
  %1628 = fadd <8 x float> %1520, %1624
  %1629 = extractelement <8 x i1> %convergence.cascade.result157, i32 0
  %1630 = extractelement <8 x i1> %convergence.cascade.result157, i64 0
  %1631 = and i1 true, %1629
  %1632 = and i1 %1630, %1631
  %1633 = extractelement <8 x float> %1628, i32 0
  %1634 = select i1 %1632, float %1633, float 0.000000e+00
  %1635 = insertelement <8 x float> poison, float %1634, i64 0
  %1636 = xor i1 %1632, true
  %1637 = and i1 %1630, %1636
  %1638 = insertelement <8 x i1> poison, i1 %1637, i64 0
  %1639 = extractelement <8 x i1> %convergence.cascade.result157, i32 0
  %1640 = extractelement <8 x i1> %convergence.cascade.result157, i64 1
  %1641 = and i1 true, %1639
  %1642 = and i1 %1640, %1641
  %1643 = extractelement <8 x float> %1628, i32 0
  %1644 = select i1 %1642, float %1643, float 0.000000e+00
  %1645 = insertelement <8 x float> %1635, float %1644, i64 1
  %1646 = xor i1 %1642, true
  %1647 = and i1 %1640, %1646
  %1648 = insertelement <8 x i1> %1638, i1 %1647, i64 1
  %1649 = extractelement <8 x i1> %convergence.cascade.result157, i32 0
  %1650 = extractelement <8 x i1> %convergence.cascade.result157, i64 2
  %1651 = and i1 true, %1649
  %1652 = and i1 %1650, %1651
  %1653 = extractelement <8 x float> %1628, i32 0
  %1654 = select i1 %1652, float %1653, float 0.000000e+00
  %1655 = insertelement <8 x float> %1645, float %1654, i64 2
  %1656 = xor i1 %1652, true
  %1657 = and i1 %1650, %1656
  %1658 = insertelement <8 x i1> %1648, i1 %1657, i64 2
  %1659 = extractelement <8 x i1> %convergence.cascade.result157, i32 0
  %1660 = extractelement <8 x i1> %convergence.cascade.result157, i64 3
  %1661 = and i1 true, %1659
  %1662 = and i1 %1660, %1661
  %1663 = extractelement <8 x float> %1628, i32 0
  %1664 = select i1 %1662, float %1663, float 0.000000e+00
  %1665 = insertelement <8 x float> %1655, float %1664, i64 3
  %1666 = xor i1 %1662, true
  %1667 = and i1 %1660, %1666
  %1668 = insertelement <8 x i1> %1658, i1 %1667, i64 3
  %1669 = extractelement <8 x i1> %convergence.cascade.result157, i32 0
  %1670 = extractelement <8 x i1> %convergence.cascade.result157, i64 4
  %1671 = and i1 true, %1669
  %1672 = and i1 %1670, %1671
  %1673 = extractelement <8 x float> %1628, i32 0
  %1674 = select i1 %1672, float %1673, float 0.000000e+00
  %1675 = insertelement <8 x float> %1665, float %1674, i64 4
  %1676 = xor i1 %1672, true
  %1677 = and i1 %1670, %1676
  %1678 = insertelement <8 x i1> %1668, i1 %1677, i64 4
  %1679 = extractelement <8 x i1> %convergence.cascade.result157, i32 0
  %1680 = extractelement <8 x i1> %convergence.cascade.result157, i64 5
  %1681 = and i1 true, %1679
  %1682 = and i1 %1680, %1681
  %1683 = extractelement <8 x float> %1628, i32 0
  %1684 = select i1 %1682, float %1683, float 0.000000e+00
  %1685 = insertelement <8 x float> %1675, float %1684, i64 5
  %1686 = xor i1 %1682, true
  %1687 = and i1 %1680, %1686
  %1688 = insertelement <8 x i1> %1678, i1 %1687, i64 5
  %1689 = extractelement <8 x i1> %convergence.cascade.result157, i32 0
  %1690 = extractelement <8 x i1> %convergence.cascade.result157, i64 6
  %1691 = and i1 true, %1689
  %1692 = and i1 %1690, %1691
  %1693 = extractelement <8 x float> %1628, i32 0
  %1694 = select i1 %1692, float %1693, float 0.000000e+00
  %1695 = insertelement <8 x float> %1685, float %1694, i64 6
  %1696 = xor i1 %1692, true
  %1697 = and i1 %1690, %1696
  %1698 = insertelement <8 x i1> %1688, i1 %1697, i64 6
  %1699 = extractelement <8 x i1> %convergence.cascade.result157, i32 0
  %1700 = extractelement <8 x i1> %convergence.cascade.result157, i64 7
  %1701 = and i1 true, %1699
  %1702 = and i1 %1700, %1701
  %1703 = extractelement <8 x float> %1628, i32 0
  %1704 = select i1 %1702, float %1703, float 0.000000e+00
  %1705 = insertelement <8 x float> %1695, float %1704, i64 7
  %1706 = xor i1 %1702, true
  %1707 = and i1 %1700, %1706
  %1708 = insertelement <8 x i1> %1698, i1 %1707, i64 7
  %1709 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result157)
  %1710 = bitcast <8 x i1> %convergence.cascade.result157 to i8
  %1711 = call i8 @llvm.cttz.i8(i8 %1710, i1 false)
  %1712 = zext i8 %1711 to i32
  %1713 = select i1 %1709, i32 %1712, i32 0
  %1714 = extractelement <8 x float> %1705, i32 %1713
  %.spill.load163 = load float, ptr %.spill12, align 4
  %1715 = fadd float %.spill.load163, %1714
  store float 6.600000e+01, ptr %.spill23, align 4
  %1716 = fdiv float %1715, 6.600000e+01
  %.splatinsert164 = insertelement <8 x float> poison, float %1716, i64 0
  %.splat165 = shufflevector <8 x float> %.splatinsert164, <8 x float> poison, <8 x i32> zeroinitializer
  %1717 = load <8 x float>, ptr %.spill24, align 32
  %1718 = select <8 x i1> %convergence.cascade.result157, <8 x float> %.splat165, <8 x float> %1717
  store <8 x float> %1718, ptr %.spill24, align 32
  %1719 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %1720 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1721 = extractvalue { <8 x ptr>, <8 x i64> } %1719, 0
  %1722 = select <8 x i1> %convergence.cascade.result157, <8 x ptr> %1720, <8 x ptr> %1721
  %1723 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %1724 = extractvalue { <8 x ptr>, <8 x i64> } %1719, 1
  %1725 = select <8 x i1> %convergence.cascade.result157, <8 x i64> %1723, <8 x i64> %1724
  %1726 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1722, 0
  %1727 = insertvalue { <8 x ptr>, <8 x i64> } %1726, <8 x i64> %1725, 1
  store { <8 x ptr>, <8 x i64> } %1727, ptr %tile_snapshot.spill25, align 64
  %1728 = load <8 x i64>, ptr %.slot26, align 64
  %1729 = select <8 x i1> %convergence.cascade.result157, <8 x i64> zeroinitializer, <8 x i64> %1728
  store <8 x i64> %1729, ptr %.slot26, align 64
  store <8 x i1> %convergence.cascade.result157, ptr %current.mask, align 1
  %1730 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result157)
  br i1 %1730, label %schedule.11, label %scheduler.loop

varying.divergent167:                             ; preds = %schedule.11
  %1731 = load i32, ptr %current.token, align 4
  %1732 = icmp ne i32 %1731, 0
  %1733 = sub i32 %1731, 1
  %1734 = select i1 %1732, i32 %1733, i32 0
  %1735 = load i8, ptr %frame.active, align 1
  %1736 = trunc i32 %1734 to i8
  %1737 = shl i8 1, %1736
  %1738 = and i8 %1735, %1737
  %1739 = icmp ne i8 %1738, 0
  %1740 = load <8 x i32>, ptr %frame.static.id, align 32
  %1741 = extractelement <8 x i32> %1740, i32 %1734
  %1742 = icmp eq i32 %1741, 3
  %1743 = and i1 %1739, %1742
  %1744 = and i1 %1732, %1743
  %1745 = xor i1 %1744, true
  %1746 = and i1 true, %1745
  %1747 = xor i8 %1735, -1
  %1748 = icmp ne i8 %1747, 0
  %1749 = xor i1 %1748, true
  %1750 = and i1 %1746, %1749
  br i1 %1750, label %convergence.overflow.trap169, label %convergence.overflow.resume170

varying.coherent168:                              ; preds = %schedule.11
  br i1 %354, label %varying.coherent.true173, label %varying.coherent.false174

convergence.overflow.trap169:                     ; preds = %varying.divergent167
  call void @llvm.trap()
  unreachable

convergence.overflow.resume170:                   ; preds = %varying.divergent167
  %1751 = call i8 @llvm.cttz.i8(i8 %1747, i1 false)
  %1752 = zext i8 %1751 to i32
  %1753 = select i1 %1748, i32 %1752, i32 0
  %1754 = trunc i32 %1753 to i8
  %1755 = shl i8 1, %1754
  %1756 = or i8 %1735, %1755
  %1757 = select i1 %1746, i8 %1756, i8 %1735
  store i8 %1757, ptr %frame.active, align 1
  %1758 = load <8 x i32>, ptr %frame.static.id, align 32
  %1759 = extractelement <8 x i32> %1758, i32 %1753
  %1760 = select i1 %1746, i32 3, i32 %1759
  %1761 = load <8 x i32>, ptr %frame.static.id, align 32
  %1762 = insertelement <8 x i32> %1761, i32 %1760, i32 %1753
  store <8 x i32> %1762, ptr %frame.static.id, align 32
  %1763 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1764 = extractelement <8 x i32> %1763, i32 %1753
  %1765 = select i1 %1746, i32 %1731, i32 %1764
  %1766 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1767 = insertelement <8 x i32> %1766, i32 %1765, i32 %1753
  store <8 x i32> %1767, ptr %frame.parent.token, align 32
  %1768 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1753
  %1769 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1753
  %1770 = load <8 x i1>, ptr %1768, align 1
  %1771 = load <8 x i1>, ptr %1769, align 1
  %1772 = select i1 %1746, <8 x i1> %344, <8 x i1> %1770
  store <8 x i1> %1772, ptr %1768, align 1
  %1773 = select i1 %1746, <8 x i1> zeroinitializer, <8 x i1> %1771
  store <8 x i1> %1773, ptr %1769, align 1
  %1774 = add i32 %1753, 1
  %1775 = select i1 %1744, i32 %1731, i32 %1774
  %1776 = select i1 true, i32 %1775, i32 %1731
  store i32 %1776, ptr %current.token, align 4
  %1777 = load i32, ptr %current.token, align 4
  %1778 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %351)
  %1779 = load i32, ptr %ready.count, align 4
  %1780 = icmp uge i32 %1779, 8
  %1781 = and i1 %1778, %1780
  br i1 %1781, label %ready.overflow.trap171, label %ready.overflow.resume172

ready.overflow.trap171:                           ; preds = %convergence.overflow.resume170
  call void @llvm.trap()
  unreachable

ready.overflow.resume172:                         ; preds = %convergence.overflow.resume170
  %1782 = select i1 %1778, i32 %1779, i32 0
  %1783 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1782
  %1784 = load <8 x i1>, ptr %1783, align 1
  %1785 = select i1 %1778, <8 x i1> %351, <8 x i1> %1784
  store <8 x i1> %1785, ptr %1783, align 1
  %1786 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1782
  %1787 = load i32, ptr %1786, align 4
  %1788 = select i1 %1778, i32 12, i32 %1787
  store i32 %1788, ptr %1786, align 4
  %1789 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1782
  %1790 = load i32, ptr %1789, align 4
  %1791 = select i1 %1778, i32 %1777, i32 %1790
  store i32 %1791, ptr %1789, align 4
  %1792 = add i32 %1779, 1
  %1793 = select i1 %1778, i32 %1792, i32 %1779
  store i32 %1793, ptr %ready.count, align 4
  %1794 = load <8 x i1>, ptr %runnable.mask, align 1
  %1795 = or <8 x i1> %1794, %351
  store <8 x i1> %1795, ptr %runnable.mask, align 1
  store <8 x i1> %353, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true173:                         ; preds = %varying.coherent168
  store <8 x i1> %344, ptr %current.mask, align 1
  %1796 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %344)
  br i1 %1796, label %schedule.12, label %scheduler.loop

varying.coherent.false174:                        ; preds = %varying.coherent168
  store <8 x i1> %344, ptr %current.mask, align 1
  %1797 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %344)
  br i1 %1797, label %schedule.13, label %scheduler.loop

convergence.cascade183:                           ; preds = %convergence.cascade183, %schedule.13
  %convergence.cascade.flow187 = phi <8 x i1> [ %393, %schedule.13 ], [ %1840, %convergence.cascade183 ]
  %convergence.cascade.depth188 = phi i32 [ 0, %schedule.13 ], [ %1841, %convergence.cascade183 ]
  %1798 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow187)
  %1799 = load i32, ptr %current.token, align 4
  %1800 = icmp ne i32 %1799, 0
  %1801 = and i1 %1798, %1800
  %1802 = sub i32 %1799, 1
  %1803 = select i1 %1801, i32 %1802, i32 0
  %1804 = load i8, ptr %frame.active, align 1
  %1805 = trunc i32 %1803 to i8
  %1806 = shl i8 1, %1805
  %1807 = and i8 %1804, %1806
  %1808 = icmp ne i8 %1807, 0
  %1809 = load <8 x i32>, ptr %frame.static.id, align 32
  %1810 = extractelement <8 x i32> %1809, i32 %1803
  %convergence.target.pointer189 = getelementptr inbounds [13 x i32], ptr @convergence.targets, i32 0, i32 %1810
  %convergence.dynamic.target190 = load i32, ptr %convergence.target.pointer189, align 4
  %1811 = icmp eq i32 %convergence.dynamic.target190, 13
  %1812 = and i1 %1808, %1811
  %1813 = and i1 %1801, %1812
  %1814 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1803
  %1815 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1803
  %1816 = load <8 x i1>, ptr %1814, align 1
  %1817 = load <8 x i1>, ptr %1815, align 1
  %1818 = or <8 x i1> %1817, %convergence.cascade.flow187
  %1819 = load <8 x i1>, ptr %live.mask, align 1
  %1820 = and <8 x i1> %1816, %1819
  %1821 = icmp eq <8 x i1> %1818, %1820
  %1822 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1821)
  %1823 = and i1 %1813, %1822
  %1824 = select i1 %1823, <8 x i1> zeroinitializer, <8 x i1> %1818
  %1825 = select i1 %1813, <8 x i1> %1824, <8 x i1> %1817
  store <8 x i1> %1825, ptr %1815, align 1
  %1826 = select i1 %1823, <8 x i1> zeroinitializer, <8 x i1> %1816
  store <8 x i1> %1826, ptr %1814, align 1
  %1827 = trunc i32 %1803 to i8
  %1828 = shl i8 1, %1827
  %1829 = xor i8 %1828, -1
  %1830 = and i8 %1804, %1829
  %1831 = select i1 %1823, i8 %1830, i8 %1804
  store i8 %1831, ptr %frame.active, align 1
  %.splatinsert191 = insertelement <8 x i1> poison, i1 %1813, i64 0
  %.splat192 = shufflevector <8 x i1> %.splatinsert191, <8 x i1> poison, <8 x i32> zeroinitializer
  %1832 = and <8 x i1> %convergence.cascade.flow187, %.splat192
  %1833 = load <8 x i1>, ptr %runnable.mask, align 1
  %1834 = xor <8 x i1> %1832, splat (i1 true)
  %1835 = and <8 x i1> %1833, %1834
  store <8 x i1> %1835, ptr %runnable.mask, align 1
  %.splatinsert193 = insertelement <8 x i1> poison, i1 %1823, i64 0
  %.splat194 = shufflevector <8 x i1> %.splatinsert193, <8 x i1> poison, <8 x i32> zeroinitializer
  %1836 = select <8 x i1> %.splat194, <8 x i1> %1818, <8 x i1> zeroinitializer
  %1837 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1838 = extractelement <8 x i32> %1837, i32 %1803
  %1839 = select i1 %1823, i32 %1838, i32 %1799
  store i32 %1839, ptr %current.token, align 4
  %.splatinsert195 = insertelement <8 x i1> poison, i1 %1813, i64 0
  %.splat196 = shufflevector <8 x i1> %.splatinsert195, <8 x i1> poison, <8 x i32> zeroinitializer
  %1840 = select <8 x i1> %.splat196, <8 x i1> %1836, <8 x i1> %convergence.cascade.flow187
  %1841 = add i32 %convergence.cascade.depth188, 1
  %1842 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1840)
  %1843 = icmp ult i32 %1841, 8
  %1844 = and i1 %1842, %1843
  %1845 = and i1 %1813, %1844
  %convergence.parent.token197 = load i32, ptr %current.token, align 4
  %convergence.parent.present198 = icmp ne i32 %convergence.parent.token197, 0
  %1846 = and i1 %1845, %convergence.parent.present198
  br i1 %1846, label %convergence.cascade183, label %convergence.cascade.exit184

convergence.cascade.exit184:                      ; preds = %convergence.cascade183, %schedule.13
  %convergence.cascade.result199 = phi <8 x i1> [ %393, %schedule.13 ], [ %1840, %convergence.cascade183 ]
  %1847 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result199)
  br i1 %1847, label %convergence.target.13.ready, label %scheduler.loop

convergence.target.13.ready:                      ; preds = %convergence.cascade.exit184
  %1848 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result199)
  %1849 = bitcast <8 x i1> %convergence.cascade.result199 to i8
  %1850 = call i8 @llvm.cttz.i8(i8 %1849, i1 false)
  %1851 = zext i8 %1850 to i32
  %1852 = select i1 %1848, i32 %1851, i32 0
  %.spill.load200 = load <8 x i1>, ptr %.spill11, align 1
  %1853 = and <8 x i1> %convergence.cascade.result199, %.spill.load200
  %1854 = xor <8 x i1> %.spill.load200, splat (i1 true)
  %1855 = and <8 x i1> %convergence.cascade.result199, %1854
  %1856 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1853)
  %1857 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1855)
  %1858 = and i1 %1856, %1857
  br i1 %1858, label %varying.divergent201, label %varying.coherent202

varying.divergent201:                             ; preds = %convergence.target.13.ready
  %1859 = load i32, ptr %current.token, align 4
  %1860 = icmp ne i32 %1859, 0
  %1861 = sub i32 %1859, 1
  %1862 = select i1 %1860, i32 %1861, i32 0
  %1863 = load i8, ptr %frame.active, align 1
  %1864 = trunc i32 %1862 to i8
  %1865 = shl i8 1, %1864
  %1866 = and i8 %1863, %1865
  %1867 = icmp ne i8 %1866, 0
  %1868 = load <8 x i32>, ptr %frame.static.id, align 32
  %1869 = extractelement <8 x i32> %1868, i32 %1862
  %1870 = icmp eq i32 %1869, 4
  %1871 = and i1 %1867, %1870
  %1872 = and i1 %1860, %1871
  %1873 = xor i1 %1872, true
  %1874 = and i1 true, %1873
  %1875 = xor i8 %1863, -1
  %1876 = icmp ne i8 %1875, 0
  %1877 = xor i1 %1876, true
  %1878 = and i1 %1874, %1877
  br i1 %1878, label %convergence.overflow.trap203, label %convergence.overflow.resume204

varying.coherent202:                              ; preds = %convergence.target.13.ready
  br i1 %1856, label %varying.coherent.true207, label %varying.coherent.false208

convergence.overflow.trap203:                     ; preds = %varying.divergent201
  call void @llvm.trap()
  unreachable

convergence.overflow.resume204:                   ; preds = %varying.divergent201
  %1879 = call i8 @llvm.cttz.i8(i8 %1875, i1 false)
  %1880 = zext i8 %1879 to i32
  %1881 = select i1 %1876, i32 %1880, i32 0
  %1882 = trunc i32 %1881 to i8
  %1883 = shl i8 1, %1882
  %1884 = or i8 %1863, %1883
  %1885 = select i1 %1874, i8 %1884, i8 %1863
  store i8 %1885, ptr %frame.active, align 1
  %1886 = load <8 x i32>, ptr %frame.static.id, align 32
  %1887 = extractelement <8 x i32> %1886, i32 %1881
  %1888 = select i1 %1874, i32 4, i32 %1887
  %1889 = load <8 x i32>, ptr %frame.static.id, align 32
  %1890 = insertelement <8 x i32> %1889, i32 %1888, i32 %1881
  store <8 x i32> %1890, ptr %frame.static.id, align 32
  %1891 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1892 = extractelement <8 x i32> %1891, i32 %1881
  %1893 = select i1 %1874, i32 %1859, i32 %1892
  %1894 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1895 = insertelement <8 x i32> %1894, i32 %1893, i32 %1881
  store <8 x i32> %1895, ptr %frame.parent.token, align 32
  %1896 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1881
  %1897 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1881
  %1898 = load <8 x i1>, ptr %1896, align 1
  %1899 = load <8 x i1>, ptr %1897, align 1
  %1900 = select i1 %1874, <8 x i1> %convergence.cascade.result199, <8 x i1> %1898
  store <8 x i1> %1900, ptr %1896, align 1
  %1901 = select i1 %1874, <8 x i1> zeroinitializer, <8 x i1> %1899
  store <8 x i1> %1901, ptr %1897, align 1
  %1902 = add i32 %1881, 1
  %1903 = select i1 %1872, i32 %1859, i32 %1902
  %1904 = select i1 true, i32 %1903, i32 %1859
  store i32 %1904, ptr %current.token, align 4
  %1905 = load i32, ptr %current.token, align 4
  %1906 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1853)
  %1907 = load i32, ptr %ready.count, align 4
  %1908 = icmp uge i32 %1907, 8
  %1909 = and i1 %1906, %1908
  br i1 %1909, label %ready.overflow.trap205, label %ready.overflow.resume206

ready.overflow.trap205:                           ; preds = %convergence.overflow.resume204
  call void @llvm.trap()
  unreachable

ready.overflow.resume206:                         ; preds = %convergence.overflow.resume204
  %1910 = select i1 %1906, i32 %1907, i32 0
  %1911 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1910
  %1912 = load <8 x i1>, ptr %1911, align 1
  %1913 = select i1 %1906, <8 x i1> %1853, <8 x i1> %1912
  store <8 x i1> %1913, ptr %1911, align 1
  %1914 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1910
  %1915 = load i32, ptr %1914, align 4
  %1916 = select i1 %1906, i32 14, i32 %1915
  store i32 %1916, ptr %1914, align 4
  %1917 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1910
  %1918 = load i32, ptr %1917, align 4
  %1919 = select i1 %1906, i32 %1905, i32 %1918
  store i32 %1919, ptr %1917, align 4
  %1920 = add i32 %1907, 1
  %1921 = select i1 %1906, i32 %1920, i32 %1907
  store i32 %1921, ptr %ready.count, align 4
  %1922 = load <8 x i1>, ptr %runnable.mask, align 1
  %1923 = or <8 x i1> %1922, %1853
  store <8 x i1> %1923, ptr %runnable.mask, align 1
  store <8 x i1> %1855, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true207:                         ; preds = %varying.coherent202
  store <8 x i1> %convergence.cascade.result199, ptr %current.mask, align 1
  %1924 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result199)
  br i1 %1924, label %schedule.14, label %scheduler.loop

varying.coherent.false208:                        ; preds = %varying.coherent202
  store <8 x i1> %convergence.cascade.result199, ptr %current.mask, align 1
  %1925 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result199)
  br i1 %1925, label %schedule.15, label %scheduler.loop

convergence.cascade218:                           ; preds = %convergence.cascade218, %schedule.15
  %convergence.cascade.flow222 = phi <8 x i1> [ %438, %schedule.15 ], [ %1968, %convergence.cascade218 ]
  %convergence.cascade.depth223 = phi i32 [ 0, %schedule.15 ], [ %1969, %convergence.cascade218 ]
  %1926 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow222)
  %1927 = load i32, ptr %current.token, align 4
  %1928 = icmp ne i32 %1927, 0
  %1929 = and i1 %1926, %1928
  %1930 = sub i32 %1927, 1
  %1931 = select i1 %1929, i32 %1930, i32 0
  %1932 = load i8, ptr %frame.active, align 1
  %1933 = trunc i32 %1931 to i8
  %1934 = shl i8 1, %1933
  %1935 = and i8 %1932, %1934
  %1936 = icmp ne i8 %1935, 0
  %1937 = load <8 x i32>, ptr %frame.static.id, align 32
  %1938 = extractelement <8 x i32> %1937, i32 %1931
  %convergence.target.pointer224 = getelementptr inbounds [13 x i32], ptr @convergence.targets, i32 0, i32 %1938
  %convergence.dynamic.target225 = load i32, ptr %convergence.target.pointer224, align 4
  %1939 = icmp eq i32 %convergence.dynamic.target225, 15
  %1940 = and i1 %1936, %1939
  %1941 = and i1 %1929, %1940
  %1942 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1931
  %1943 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1931
  %1944 = load <8 x i1>, ptr %1942, align 1
  %1945 = load <8 x i1>, ptr %1943, align 1
  %1946 = or <8 x i1> %1945, %convergence.cascade.flow222
  %1947 = load <8 x i1>, ptr %live.mask, align 1
  %1948 = and <8 x i1> %1944, %1947
  %1949 = icmp eq <8 x i1> %1946, %1948
  %1950 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1949)
  %1951 = and i1 %1941, %1950
  %1952 = select i1 %1951, <8 x i1> zeroinitializer, <8 x i1> %1946
  %1953 = select i1 %1941, <8 x i1> %1952, <8 x i1> %1945
  store <8 x i1> %1953, ptr %1943, align 1
  %1954 = select i1 %1951, <8 x i1> zeroinitializer, <8 x i1> %1944
  store <8 x i1> %1954, ptr %1942, align 1
  %1955 = trunc i32 %1931 to i8
  %1956 = shl i8 1, %1955
  %1957 = xor i8 %1956, -1
  %1958 = and i8 %1932, %1957
  %1959 = select i1 %1951, i8 %1958, i8 %1932
  store i8 %1959, ptr %frame.active, align 1
  %.splatinsert226 = insertelement <8 x i1> poison, i1 %1941, i64 0
  %.splat227 = shufflevector <8 x i1> %.splatinsert226, <8 x i1> poison, <8 x i32> zeroinitializer
  %1960 = and <8 x i1> %convergence.cascade.flow222, %.splat227
  %1961 = load <8 x i1>, ptr %runnable.mask, align 1
  %1962 = xor <8 x i1> %1960, splat (i1 true)
  %1963 = and <8 x i1> %1961, %1962
  store <8 x i1> %1963, ptr %runnable.mask, align 1
  %.splatinsert228 = insertelement <8 x i1> poison, i1 %1951, i64 0
  %.splat229 = shufflevector <8 x i1> %.splatinsert228, <8 x i1> poison, <8 x i32> zeroinitializer
  %1964 = select <8 x i1> %.splat229, <8 x i1> %1946, <8 x i1> zeroinitializer
  %1965 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1966 = extractelement <8 x i32> %1965, i32 %1931
  %1967 = select i1 %1951, i32 %1966, i32 %1927
  store i32 %1967, ptr %current.token, align 4
  %.splatinsert230 = insertelement <8 x i1> poison, i1 %1941, i64 0
  %.splat231 = shufflevector <8 x i1> %.splatinsert230, <8 x i1> poison, <8 x i32> zeroinitializer
  %1968 = select <8 x i1> %.splat231, <8 x i1> %1964, <8 x i1> %convergence.cascade.flow222
  %1969 = add i32 %convergence.cascade.depth223, 1
  %1970 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1968)
  %1971 = icmp ult i32 %1969, 8
  %1972 = and i1 %1970, %1971
  %1973 = and i1 %1941, %1972
  %convergence.parent.token232 = load i32, ptr %current.token, align 4
  %convergence.parent.present233 = icmp ne i32 %convergence.parent.token232, 0
  %1974 = and i1 %1973, %convergence.parent.present233
  br i1 %1974, label %convergence.cascade218, label %convergence.cascade.exit219

convergence.cascade.exit219:                      ; preds = %convergence.cascade218, %schedule.15
  %convergence.cascade.result234 = phi <8 x i1> [ %438, %schedule.15 ], [ %1968, %convergence.cascade218 ]
  %1975 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result234)
  br i1 %1975, label %convergence.target.15.ready, label %scheduler.loop

convergence.target.15.ready:                      ; preds = %convergence.cascade.exit219
  %1976 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result234)
  %1977 = bitcast <8 x i1> %convergence.cascade.result234 to i8
  %1978 = call i8 @llvm.cttz.i8(i8 %1977, i1 false)
  %1979 = zext i8 %1978 to i32
  %1980 = select i1 %1976, i32 %1979, i32 0
  %tile_snapshot.spill.load235 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %1981 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load235, 0
  %1982 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load235, 1
  %1983 = add <8 x i64> %1982, zeroinitializer
  %1984 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1981, 0
  %1985 = insertvalue { <8 x ptr>, <8 x i64> } %1984, <8 x i64> %1983, 1
  %1986 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1987 = extractvalue { <8 x ptr>, <8 x i64> } %1985, 1
  %1988 = extractelement <8 x ptr> %1986, i32 0
  %1989 = extractelement <8 x i64> %1987, i32 %1980
  %1990 = zext i32 %1980 to i64
  %1991 = mul i64 %1990, 4
  %1992 = sub i64 %1989, %1991
  %1993 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result234)
  %1994 = select i1 %1993, i64 %1992, i64 0
  %private.contiguous.address236 = getelementptr i8, ptr %1988, i64 %1994
  %private.contiguous.load237 = load <8 x float>, ptr %private.contiguous.address236, align 4
  %1995 = select <8 x i1> %convergence.cascade.result234, <8 x float> %private.contiguous.load237, <8 x float> zeroinitializer
  %1996 = fmul <8 x float> %1995, %1995
  %tile_snapshot.spill.load238 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %1997 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load238, 0
  %1998 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load238, 1
  %1999 = add <8 x i64> %1998, splat (i64 32)
  %2000 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1997, 0
  %2001 = insertvalue { <8 x ptr>, <8 x i64> } %2000, <8 x i64> %1999, 1
  %2002 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %2003 = extractvalue { <8 x ptr>, <8 x i64> } %2001, 1
  %2004 = extractelement <8 x ptr> %2002, i32 0
  %2005 = extractelement <8 x i64> %2003, i32 %1980
  %2006 = zext i32 %1980 to i64
  %2007 = mul i64 %2006, 4
  %2008 = sub i64 %2005, %2007
  %2009 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result234)
  %2010 = select i1 %2009, i64 %2008, i64 0
  %private.contiguous.address239 = getelementptr i8, ptr %2004, i64 %2010
  %private.contiguous.load240 = load <8 x float>, ptr %private.contiguous.address239, align 4
  %2011 = select <8 x i1> %convergence.cascade.result234, <8 x float> %private.contiguous.load240, <8 x float> zeroinitializer
  %2012 = fmul <8 x float> %2011, %2011
  %tile_snapshot.spill.load241 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %2013 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load241, 0
  %2014 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load241, 1
  %2015 = add <8 x i64> %2014, splat (i64 64)
  %2016 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2013, 0
  %2017 = insertvalue { <8 x ptr>, <8 x i64> } %2016, <8 x i64> %2015, 1
  %2018 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %2019 = extractvalue { <8 x ptr>, <8 x i64> } %2017, 1
  %2020 = extractelement <8 x ptr> %2018, i32 0
  %2021 = extractelement <8 x i64> %2019, i32 %1980
  %2022 = zext i32 %1980 to i64
  %2023 = mul i64 %2022, 4
  %2024 = sub i64 %2021, %2023
  %2025 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result234)
  %2026 = select i1 %2025, i64 %2024, i64 0
  %private.contiguous.address242 = getelementptr i8, ptr %2020, i64 %2026
  %private.contiguous.load243 = load <8 x float>, ptr %private.contiguous.address242, align 4
  %2027 = select <8 x i1> %convergence.cascade.result234, <8 x float> %private.contiguous.load243, <8 x float> zeroinitializer
  %2028 = fmul <8 x float> %2027, %2027
  %tile_snapshot.spill.load244 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %2029 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load244, 0
  %2030 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load244, 1
  %2031 = add <8 x i64> %2030, splat (i64 96)
  %2032 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2029, 0
  %2033 = insertvalue { <8 x ptr>, <8 x i64> } %2032, <8 x i64> %2031, 1
  %2034 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %2035 = extractvalue { <8 x ptr>, <8 x i64> } %2033, 1
  %2036 = extractelement <8 x ptr> %2034, i32 0
  %2037 = extractelement <8 x i64> %2035, i32 %1980
  %2038 = zext i32 %1980 to i64
  %2039 = mul i64 %2038, 4
  %2040 = sub i64 %2037, %2039
  %2041 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result234)
  %2042 = select i1 %2041, i64 %2040, i64 0
  %private.contiguous.address245 = getelementptr i8, ptr %2036, i64 %2042
  %private.contiguous.load246 = load <8 x float>, ptr %private.contiguous.address245, align 4
  %2043 = select <8 x i1> %convergence.cascade.result234, <8 x float> %private.contiguous.load246, <8 x float> zeroinitializer
  %2044 = fmul <8 x float> %2043, %2043
  %2045 = load <8 x i64>, ptr %.slot27, align 64
  %2046 = select <8 x i1> %convergence.cascade.result234, <8 x i64> splat (i64 4), <8 x i64> %2045
  store <8 x i64> %2046, ptr %.slot27, align 64
  %2047 = load <8 x float>, ptr %.slot28, align 32
  %2048 = select <8 x i1> %convergence.cascade.result234, <8 x float> %1996, <8 x float> %2047
  store <8 x float> %2048, ptr %.slot28, align 32
  %2049 = load <8 x float>, ptr %.slot29, align 32
  %2050 = select <8 x i1> %convergence.cascade.result234, <8 x float> %2012, <8 x float> %2049
  store <8 x float> %2050, ptr %.slot29, align 32
  %2051 = load <8 x float>, ptr %.slot30, align 32
  %2052 = select <8 x i1> %convergence.cascade.result234, <8 x float> %2028, <8 x float> %2051
  store <8 x float> %2052, ptr %.slot30, align 32
  %2053 = load <8 x float>, ptr %.slot31, align 32
  %2054 = select <8 x i1> %convergence.cascade.result234, <8 x float> %2044, <8 x float> %2053
  store <8 x float> %2054, ptr %.slot31, align 32
  store <8 x i1> %convergence.cascade.result234, ptr %current.mask, align 1
  %2055 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result234)
  br i1 %2055, label %schedule.16, label %scheduler.loop

varying.divergent248:                             ; preds = %schedule.16
  %2056 = load i32, ptr %current.token, align 4
  %2057 = icmp ne i32 %2056, 0
  %2058 = sub i32 %2056, 1
  %2059 = select i1 %2057, i32 %2058, i32 0
  %2060 = load i8, ptr %frame.active, align 1
  %2061 = trunc i32 %2059 to i8
  %2062 = shl i8 1, %2061
  %2063 = and i8 %2060, %2062
  %2064 = icmp ne i8 %2063, 0
  %2065 = load <8 x i32>, ptr %frame.static.id, align 32
  %2066 = extractelement <8 x i32> %2065, i32 %2059
  %2067 = icmp eq i32 %2066, 5
  %2068 = and i1 %2064, %2067
  %2069 = and i1 %2057, %2068
  %2070 = xor i1 %2069, true
  %2071 = and i1 true, %2070
  %2072 = xor i8 %2060, -1
  %2073 = icmp ne i8 %2072, 0
  %2074 = xor i1 %2073, true
  %2075 = and i1 %2071, %2074
  br i1 %2075, label %convergence.overflow.trap250, label %convergence.overflow.resume251

varying.coherent249:                              ; preds = %schedule.16
  br i1 %449, label %varying.coherent.true254, label %varying.coherent.false255

convergence.overflow.trap250:                     ; preds = %varying.divergent248
  call void @llvm.trap()
  unreachable

convergence.overflow.resume251:                   ; preds = %varying.divergent248
  %2076 = call i8 @llvm.cttz.i8(i8 %2072, i1 false)
  %2077 = zext i8 %2076 to i32
  %2078 = select i1 %2073, i32 %2077, i32 0
  %2079 = trunc i32 %2078 to i8
  %2080 = shl i8 1, %2079
  %2081 = or i8 %2060, %2080
  %2082 = select i1 %2071, i8 %2081, i8 %2060
  store i8 %2082, ptr %frame.active, align 1
  %2083 = load <8 x i32>, ptr %frame.static.id, align 32
  %2084 = extractelement <8 x i32> %2083, i32 %2078
  %2085 = select i1 %2071, i32 5, i32 %2084
  %2086 = load <8 x i32>, ptr %frame.static.id, align 32
  %2087 = insertelement <8 x i32> %2086, i32 %2085, i32 %2078
  store <8 x i32> %2087, ptr %frame.static.id, align 32
  %2088 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2089 = extractelement <8 x i32> %2088, i32 %2078
  %2090 = select i1 %2071, i32 %2056, i32 %2089
  %2091 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2092 = insertelement <8 x i32> %2091, i32 %2090, i32 %2078
  store <8 x i32> %2092, ptr %frame.parent.token, align 32
  %2093 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2078
  %2094 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2078
  %2095 = load <8 x i1>, ptr %2093, align 1
  %2096 = load <8 x i1>, ptr %2094, align 1
  %2097 = select i1 %2071, <8 x i1> %439, <8 x i1> %2095
  store <8 x i1> %2097, ptr %2093, align 1
  %2098 = select i1 %2071, <8 x i1> zeroinitializer, <8 x i1> %2096
  store <8 x i1> %2098, ptr %2094, align 1
  %2099 = add i32 %2078, 1
  %2100 = select i1 %2069, i32 %2056, i32 %2099
  %2101 = select i1 true, i32 %2100, i32 %2056
  store i32 %2101, ptr %current.token, align 4
  %2102 = load i32, ptr %current.token, align 4
  %2103 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %446)
  %2104 = load i32, ptr %ready.count, align 4
  %2105 = icmp uge i32 %2104, 8
  %2106 = and i1 %2103, %2105
  br i1 %2106, label %ready.overflow.trap252, label %ready.overflow.resume253

ready.overflow.trap252:                           ; preds = %convergence.overflow.resume251
  call void @llvm.trap()
  unreachable

ready.overflow.resume253:                         ; preds = %convergence.overflow.resume251
  %2107 = select i1 %2103, i32 %2104, i32 0
  %2108 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2107
  %2109 = load <8 x i1>, ptr %2108, align 1
  %2110 = select i1 %2103, <8 x i1> %446, <8 x i1> %2109
  store <8 x i1> %2110, ptr %2108, align 1
  %2111 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2107
  %2112 = load i32, ptr %2111, align 4
  %2113 = select i1 %2103, i32 17, i32 %2112
  store i32 %2113, ptr %2111, align 4
  %2114 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2107
  %2115 = load i32, ptr %2114, align 4
  %2116 = select i1 %2103, i32 %2102, i32 %2115
  store i32 %2116, ptr %2114, align 4
  %2117 = add i32 %2104, 1
  %2118 = select i1 %2103, i32 %2117, i32 %2104
  store i32 %2118, ptr %ready.count, align 4
  %2119 = load <8 x i1>, ptr %runnable.mask, align 1
  %2120 = or <8 x i1> %2119, %446
  store <8 x i1> %2120, ptr %runnable.mask, align 1
  store <8 x i1> %448, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true254:                         ; preds = %varying.coherent249
  store <8 x i1> %439, ptr %current.mask, align 1
  %2121 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %439)
  br i1 %2121, label %schedule.17, label %scheduler.loop

varying.coherent.false255:                        ; preds = %varying.coherent249
  store <8 x i1> %439, ptr %current.mask, align 1
  %2122 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %439)
  br i1 %2122, label %schedule.18, label %scheduler.loop

convergence.cascade269:                           ; preds = %convergence.cascade269, %schedule.18
  %convergence.cascade.flow273 = phi <8 x i1> [ %522, %schedule.18 ], [ %2165, %convergence.cascade269 ]
  %convergence.cascade.depth274 = phi i32 [ 0, %schedule.18 ], [ %2166, %convergence.cascade269 ]
  %2123 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow273)
  %2124 = load i32, ptr %current.token, align 4
  %2125 = icmp ne i32 %2124, 0
  %2126 = and i1 %2123, %2125
  %2127 = sub i32 %2124, 1
  %2128 = select i1 %2126, i32 %2127, i32 0
  %2129 = load i8, ptr %frame.active, align 1
  %2130 = trunc i32 %2128 to i8
  %2131 = shl i8 1, %2130
  %2132 = and i8 %2129, %2131
  %2133 = icmp ne i8 %2132, 0
  %2134 = load <8 x i32>, ptr %frame.static.id, align 32
  %2135 = extractelement <8 x i32> %2134, i32 %2128
  %convergence.target.pointer275 = getelementptr inbounds [13 x i32], ptr @convergence.targets, i32 0, i32 %2135
  %convergence.dynamic.target276 = load i32, ptr %convergence.target.pointer275, align 4
  %2136 = icmp eq i32 %convergence.dynamic.target276, 18
  %2137 = and i1 %2133, %2136
  %2138 = and i1 %2126, %2137
  %2139 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2128
  %2140 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2128
  %2141 = load <8 x i1>, ptr %2139, align 1
  %2142 = load <8 x i1>, ptr %2140, align 1
  %2143 = or <8 x i1> %2142, %convergence.cascade.flow273
  %2144 = load <8 x i1>, ptr %live.mask, align 1
  %2145 = and <8 x i1> %2141, %2144
  %2146 = icmp eq <8 x i1> %2143, %2145
  %2147 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2146)
  %2148 = and i1 %2138, %2147
  %2149 = select i1 %2148, <8 x i1> zeroinitializer, <8 x i1> %2143
  %2150 = select i1 %2138, <8 x i1> %2149, <8 x i1> %2142
  store <8 x i1> %2150, ptr %2140, align 1
  %2151 = select i1 %2148, <8 x i1> zeroinitializer, <8 x i1> %2141
  store <8 x i1> %2151, ptr %2139, align 1
  %2152 = trunc i32 %2128 to i8
  %2153 = shl i8 1, %2152
  %2154 = xor i8 %2153, -1
  %2155 = and i8 %2129, %2154
  %2156 = select i1 %2148, i8 %2155, i8 %2129
  store i8 %2156, ptr %frame.active, align 1
  %.splatinsert277 = insertelement <8 x i1> poison, i1 %2138, i64 0
  %.splat278 = shufflevector <8 x i1> %.splatinsert277, <8 x i1> poison, <8 x i32> zeroinitializer
  %2157 = and <8 x i1> %convergence.cascade.flow273, %.splat278
  %2158 = load <8 x i1>, ptr %runnable.mask, align 1
  %2159 = xor <8 x i1> %2157, splat (i1 true)
  %2160 = and <8 x i1> %2158, %2159
  store <8 x i1> %2160, ptr %runnable.mask, align 1
  %.splatinsert279 = insertelement <8 x i1> poison, i1 %2148, i64 0
  %.splat280 = shufflevector <8 x i1> %.splatinsert279, <8 x i1> poison, <8 x i32> zeroinitializer
  %2161 = select <8 x i1> %.splat280, <8 x i1> %2143, <8 x i1> zeroinitializer
  %2162 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2163 = extractelement <8 x i32> %2162, i32 %2128
  %2164 = select i1 %2148, i32 %2163, i32 %2124
  store i32 %2164, ptr %current.token, align 4
  %.splatinsert281 = insertelement <8 x i1> poison, i1 %2138, i64 0
  %.splat282 = shufflevector <8 x i1> %.splatinsert281, <8 x i1> poison, <8 x i32> zeroinitializer
  %2165 = select <8 x i1> %.splat282, <8 x i1> %2161, <8 x i1> %convergence.cascade.flow273
  %2166 = add i32 %convergence.cascade.depth274, 1
  %2167 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2165)
  %2168 = icmp ult i32 %2166, 8
  %2169 = and i1 %2167, %2168
  %2170 = and i1 %2138, %2169
  %convergence.parent.token283 = load i32, ptr %current.token, align 4
  %convergence.parent.present284 = icmp ne i32 %convergence.parent.token283, 0
  %2171 = and i1 %2170, %convergence.parent.present284
  br i1 %2171, label %convergence.cascade269, label %convergence.cascade.exit270

convergence.cascade.exit270:                      ; preds = %convergence.cascade269, %schedule.18
  %convergence.cascade.result285 = phi <8 x i1> [ %522, %schedule.18 ], [ %2165, %convergence.cascade269 ]
  %2172 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result285)
  br i1 %2172, label %convergence.target.18.ready, label %scheduler.loop

convergence.target.18.ready:                      ; preds = %convergence.cascade.exit270
  %2173 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result285)
  %2174 = bitcast <8 x i1> %convergence.cascade.result285 to i8
  %2175 = call i8 @llvm.cttz.i8(i8 %2174, i1 false)
  %2176 = zext i8 %2175 to i32
  %2177 = select i1 %2173, i32 %2176, i32 0
  %.spill.load286 = load <8 x i1>, ptr %.spill11, align 1
  %2178 = and <8 x i1> %convergence.cascade.result285, %.spill.load286
  %2179 = xor <8 x i1> %.spill.load286, splat (i1 true)
  %2180 = and <8 x i1> %convergence.cascade.result285, %2179
  %2181 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2178)
  %2182 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2180)
  %2183 = and i1 %2181, %2182
  br i1 %2183, label %varying.divergent287, label %varying.coherent288

varying.divergent287:                             ; preds = %convergence.target.18.ready
  %2184 = load i32, ptr %current.token, align 4
  %2185 = icmp ne i32 %2184, 0
  %2186 = sub i32 %2184, 1
  %2187 = select i1 %2185, i32 %2186, i32 0
  %2188 = load i8, ptr %frame.active, align 1
  %2189 = trunc i32 %2187 to i8
  %2190 = shl i8 1, %2189
  %2191 = and i8 %2188, %2190
  %2192 = icmp ne i8 %2191, 0
  %2193 = load <8 x i32>, ptr %frame.static.id, align 32
  %2194 = extractelement <8 x i32> %2193, i32 %2187
  %2195 = icmp eq i32 %2194, 6
  %2196 = and i1 %2192, %2195
  %2197 = and i1 %2185, %2196
  %2198 = xor i1 %2197, true
  %2199 = and i1 true, %2198
  %2200 = xor i8 %2188, -1
  %2201 = icmp ne i8 %2200, 0
  %2202 = xor i1 %2201, true
  %2203 = and i1 %2199, %2202
  br i1 %2203, label %convergence.overflow.trap289, label %convergence.overflow.resume290

varying.coherent288:                              ; preds = %convergence.target.18.ready
  br i1 %2181, label %varying.coherent.true294, label %varying.coherent.false295

convergence.overflow.trap289:                     ; preds = %varying.divergent287
  call void @llvm.trap()
  unreachable

convergence.overflow.resume290:                   ; preds = %varying.divergent287
  %2204 = call i8 @llvm.cttz.i8(i8 %2200, i1 false)
  %2205 = zext i8 %2204 to i32
  %2206 = select i1 %2201, i32 %2205, i32 0
  %2207 = trunc i32 %2206 to i8
  %2208 = shl i8 1, %2207
  %2209 = or i8 %2188, %2208
  %2210 = select i1 %2199, i8 %2209, i8 %2188
  store i8 %2210, ptr %frame.active, align 1
  %2211 = load <8 x i32>, ptr %frame.static.id, align 32
  %2212 = extractelement <8 x i32> %2211, i32 %2206
  %2213 = select i1 %2199, i32 6, i32 %2212
  %2214 = load <8 x i32>, ptr %frame.static.id, align 32
  %2215 = insertelement <8 x i32> %2214, i32 %2213, i32 %2206
  store <8 x i32> %2215, ptr %frame.static.id, align 32
  %2216 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2217 = extractelement <8 x i32> %2216, i32 %2206
  %2218 = select i1 %2199, i32 %2184, i32 %2217
  %2219 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2220 = insertelement <8 x i32> %2219, i32 %2218, i32 %2206
  store <8 x i32> %2220, ptr %frame.parent.token, align 32
  %2221 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2206
  %2222 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2206
  %2223 = load <8 x i1>, ptr %2221, align 1
  %2224 = load <8 x i1>, ptr %2222, align 1
  %2225 = select i1 %2199, <8 x i1> %convergence.cascade.result285, <8 x i1> %2223
  store <8 x i1> %2225, ptr %2221, align 1
  %2226 = select i1 %2199, <8 x i1> zeroinitializer, <8 x i1> %2224
  store <8 x i1> %2226, ptr %2222, align 1
  %2227 = add i32 %2206, 1
  %2228 = select i1 %2197, i32 %2184, i32 %2227
  %2229 = select i1 true, i32 %2228, i32 %2184
  store i32 %2229, ptr %current.token, align 4
  %.state291 = load <8 x float>, ptr %.slot28, align 32
  %2230 = load <8 x float>, ptr %.slot32, align 32
  %2231 = select <8 x i1> %2180, <8 x float> %.state291, <8 x float> %2230
  store <8 x float> %2231, ptr %.slot32, align 32
  %2232 = load i32, ptr %current.token, align 4
  %2233 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2178)
  %2234 = load i32, ptr %ready.count, align 4
  %2235 = icmp uge i32 %2234, 8
  %2236 = and i1 %2233, %2235
  br i1 %2236, label %ready.overflow.trap292, label %ready.overflow.resume293

ready.overflow.trap292:                           ; preds = %convergence.overflow.resume290
  call void @llvm.trap()
  unreachable

ready.overflow.resume293:                         ; preds = %convergence.overflow.resume290
  %2237 = select i1 %2233, i32 %2234, i32 0
  %2238 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2237
  %2239 = load <8 x i1>, ptr %2238, align 1
  %2240 = select i1 %2233, <8 x i1> %2178, <8 x i1> %2239
  store <8 x i1> %2240, ptr %2238, align 1
  %2241 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2237
  %2242 = load i32, ptr %2241, align 4
  %2243 = select i1 %2233, i32 19, i32 %2242
  store i32 %2243, ptr %2241, align 4
  %2244 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2237
  %2245 = load i32, ptr %2244, align 4
  %2246 = select i1 %2233, i32 %2232, i32 %2245
  store i32 %2246, ptr %2244, align 4
  %2247 = add i32 %2234, 1
  %2248 = select i1 %2233, i32 %2247, i32 %2234
  store i32 %2248, ptr %ready.count, align 4
  %2249 = load <8 x i1>, ptr %runnable.mask, align 1
  %2250 = or <8 x i1> %2249, %2178
  store <8 x i1> %2250, ptr %runnable.mask, align 1
  store <8 x i1> %2180, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true294:                         ; preds = %varying.coherent288
  store <8 x i1> %convergence.cascade.result285, ptr %current.mask, align 1
  %2251 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result285)
  br i1 %2251, label %schedule.19, label %scheduler.loop

varying.coherent.false295:                        ; preds = %varying.coherent288
  %.state296 = load <8 x float>, ptr %.slot28, align 32
  %2252 = load <8 x float>, ptr %.slot32, align 32
  %2253 = select <8 x i1> %convergence.cascade.result285, <8 x float> %.state296, <8 x float> %2252
  store <8 x float> %2253, ptr %.slot32, align 32
  store <8 x i1> %convergence.cascade.result285, ptr %current.mask, align 1
  %2254 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result285)
  br i1 %2254, label %schedule.20, label %scheduler.loop

convergence.cascade301:                           ; preds = %convergence.cascade301, %schedule.20
  %convergence.cascade.flow305 = phi <8 x i1> [ %549, %schedule.20 ], [ %2297, %convergence.cascade301 ]
  %convergence.cascade.depth306 = phi i32 [ 0, %schedule.20 ], [ %2298, %convergence.cascade301 ]
  %2255 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow305)
  %2256 = load i32, ptr %current.token, align 4
  %2257 = icmp ne i32 %2256, 0
  %2258 = and i1 %2255, %2257
  %2259 = sub i32 %2256, 1
  %2260 = select i1 %2258, i32 %2259, i32 0
  %2261 = load i8, ptr %frame.active, align 1
  %2262 = trunc i32 %2260 to i8
  %2263 = shl i8 1, %2262
  %2264 = and i8 %2261, %2263
  %2265 = icmp ne i8 %2264, 0
  %2266 = load <8 x i32>, ptr %frame.static.id, align 32
  %2267 = extractelement <8 x i32> %2266, i32 %2260
  %convergence.target.pointer307 = getelementptr inbounds [13 x i32], ptr @convergence.targets, i32 0, i32 %2267
  %convergence.dynamic.target308 = load i32, ptr %convergence.target.pointer307, align 4
  %2268 = icmp eq i32 %convergence.dynamic.target308, 20
  %2269 = and i1 %2265, %2268
  %2270 = and i1 %2258, %2269
  %2271 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2260
  %2272 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2260
  %2273 = load <8 x i1>, ptr %2271, align 1
  %2274 = load <8 x i1>, ptr %2272, align 1
  %2275 = or <8 x i1> %2274, %convergence.cascade.flow305
  %2276 = load <8 x i1>, ptr %live.mask, align 1
  %2277 = and <8 x i1> %2273, %2276
  %2278 = icmp eq <8 x i1> %2275, %2277
  %2279 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2278)
  %2280 = and i1 %2270, %2279
  %2281 = select i1 %2280, <8 x i1> zeroinitializer, <8 x i1> %2275
  %2282 = select i1 %2270, <8 x i1> %2281, <8 x i1> %2274
  store <8 x i1> %2282, ptr %2272, align 1
  %2283 = select i1 %2280, <8 x i1> zeroinitializer, <8 x i1> %2273
  store <8 x i1> %2283, ptr %2271, align 1
  %2284 = trunc i32 %2260 to i8
  %2285 = shl i8 1, %2284
  %2286 = xor i8 %2285, -1
  %2287 = and i8 %2261, %2286
  %2288 = select i1 %2280, i8 %2287, i8 %2261
  store i8 %2288, ptr %frame.active, align 1
  %.splatinsert309 = insertelement <8 x i1> poison, i1 %2270, i64 0
  %.splat310 = shufflevector <8 x i1> %.splatinsert309, <8 x i1> poison, <8 x i32> zeroinitializer
  %2289 = and <8 x i1> %convergence.cascade.flow305, %.splat310
  %2290 = load <8 x i1>, ptr %runnable.mask, align 1
  %2291 = xor <8 x i1> %2289, splat (i1 true)
  %2292 = and <8 x i1> %2290, %2291
  store <8 x i1> %2292, ptr %runnable.mask, align 1
  %.splatinsert311 = insertelement <8 x i1> poison, i1 %2280, i64 0
  %.splat312 = shufflevector <8 x i1> %.splatinsert311, <8 x i1> poison, <8 x i32> zeroinitializer
  %2293 = select <8 x i1> %.splat312, <8 x i1> %2275, <8 x i1> zeroinitializer
  %2294 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2295 = extractelement <8 x i32> %2294, i32 %2260
  %2296 = select i1 %2280, i32 %2295, i32 %2256
  store i32 %2296, ptr %current.token, align 4
  %.splatinsert313 = insertelement <8 x i1> poison, i1 %2270, i64 0
  %.splat314 = shufflevector <8 x i1> %.splatinsert313, <8 x i1> poison, <8 x i32> zeroinitializer
  %2297 = select <8 x i1> %.splat314, <8 x i1> %2293, <8 x i1> %convergence.cascade.flow305
  %2298 = add i32 %convergence.cascade.depth306, 1
  %2299 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2297)
  %2300 = icmp ult i32 %2298, 8
  %2301 = and i1 %2299, %2300
  %2302 = and i1 %2270, %2301
  %convergence.parent.token315 = load i32, ptr %current.token, align 4
  %convergence.parent.present316 = icmp ne i32 %convergence.parent.token315, 0
  %2303 = and i1 %2302, %convergence.parent.present316
  br i1 %2303, label %convergence.cascade301, label %convergence.cascade.exit302

convergence.cascade.exit302:                      ; preds = %convergence.cascade301, %schedule.20
  %convergence.cascade.result317 = phi <8 x i1> [ %549, %schedule.20 ], [ %2297, %convergence.cascade301 ]
  %2304 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result317)
  br i1 %2304, label %convergence.target.20.ready, label %scheduler.loop

convergence.target.20.ready:                      ; preds = %convergence.cascade.exit302
  %2305 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result317)
  %2306 = bitcast <8 x i1> %convergence.cascade.result317 to i8
  %2307 = call i8 @llvm.cttz.i8(i8 %2306, i1 false)
  %2308 = zext i8 %2307 to i32
  %2309 = select i1 %2305, i32 %2308, i32 0
  %.state318 = load <8 x float>, ptr %.slot32, align 32
  %.state319 = load <8 x float>, ptr %.slot29, align 32
  %2310 = fadd <8 x float> %.state318, %.state319
  %.state320 = load <8 x float>, ptr %.slot30, align 32
  %2311 = fadd <8 x float> %2310, %.state320
  %.state321 = load <8 x float>, ptr %.slot31, align 32
  %2312 = fadd <8 x float> %2311, %.state321
  %.spill.load322 = load <8 x i32>, ptr %.spill20, align 32
  %2313 = extractelement <8 x i32> %.spill.load322, i64 0
  %2314 = icmp ult i32 %2313, 8
  %2315 = select i1 %2314, i32 %2313, i32 0
  %2316 = extractelement <8 x i1> %convergence.cascade.result317, i32 %2315
  %2317 = extractelement <8 x i1> %convergence.cascade.result317, i64 0
  %2318 = and i1 %2314, %2316
  %2319 = and i1 %2317, %2318
  %2320 = extractelement <8 x float> %2312, i32 %2315
  %2321 = select i1 %2319, float %2320, float 0.000000e+00
  %2322 = insertelement <8 x float> poison, float %2321, i64 0
  %2323 = xor i1 %2319, true
  %2324 = and i1 %2317, %2323
  %2325 = insertelement <8 x i1> poison, i1 %2324, i64 0
  %2326 = extractelement <8 x i32> %.spill.load322, i64 1
  %2327 = icmp ult i32 %2326, 8
  %2328 = select i1 %2327, i32 %2326, i32 0
  %2329 = extractelement <8 x i1> %convergence.cascade.result317, i32 %2328
  %2330 = extractelement <8 x i1> %convergence.cascade.result317, i64 1
  %2331 = and i1 %2327, %2329
  %2332 = and i1 %2330, %2331
  %2333 = extractelement <8 x float> %2312, i32 %2328
  %2334 = select i1 %2332, float %2333, float 0.000000e+00
  %2335 = insertelement <8 x float> %2322, float %2334, i64 1
  %2336 = xor i1 %2332, true
  %2337 = and i1 %2330, %2336
  %2338 = insertelement <8 x i1> %2325, i1 %2337, i64 1
  %2339 = extractelement <8 x i32> %.spill.load322, i64 2
  %2340 = icmp ult i32 %2339, 8
  %2341 = select i1 %2340, i32 %2339, i32 0
  %2342 = extractelement <8 x i1> %convergence.cascade.result317, i32 %2341
  %2343 = extractelement <8 x i1> %convergence.cascade.result317, i64 2
  %2344 = and i1 %2340, %2342
  %2345 = and i1 %2343, %2344
  %2346 = extractelement <8 x float> %2312, i32 %2341
  %2347 = select i1 %2345, float %2346, float 0.000000e+00
  %2348 = insertelement <8 x float> %2335, float %2347, i64 2
  %2349 = xor i1 %2345, true
  %2350 = and i1 %2343, %2349
  %2351 = insertelement <8 x i1> %2338, i1 %2350, i64 2
  %2352 = extractelement <8 x i32> %.spill.load322, i64 3
  %2353 = icmp ult i32 %2352, 8
  %2354 = select i1 %2353, i32 %2352, i32 0
  %2355 = extractelement <8 x i1> %convergence.cascade.result317, i32 %2354
  %2356 = extractelement <8 x i1> %convergence.cascade.result317, i64 3
  %2357 = and i1 %2353, %2355
  %2358 = and i1 %2356, %2357
  %2359 = extractelement <8 x float> %2312, i32 %2354
  %2360 = select i1 %2358, float %2359, float 0.000000e+00
  %2361 = insertelement <8 x float> %2348, float %2360, i64 3
  %2362 = xor i1 %2358, true
  %2363 = and i1 %2356, %2362
  %2364 = insertelement <8 x i1> %2351, i1 %2363, i64 3
  %2365 = extractelement <8 x i32> %.spill.load322, i64 4
  %2366 = icmp ult i32 %2365, 8
  %2367 = select i1 %2366, i32 %2365, i32 0
  %2368 = extractelement <8 x i1> %convergence.cascade.result317, i32 %2367
  %2369 = extractelement <8 x i1> %convergence.cascade.result317, i64 4
  %2370 = and i1 %2366, %2368
  %2371 = and i1 %2369, %2370
  %2372 = extractelement <8 x float> %2312, i32 %2367
  %2373 = select i1 %2371, float %2372, float 0.000000e+00
  %2374 = insertelement <8 x float> %2361, float %2373, i64 4
  %2375 = xor i1 %2371, true
  %2376 = and i1 %2369, %2375
  %2377 = insertelement <8 x i1> %2364, i1 %2376, i64 4
  %2378 = extractelement <8 x i32> %.spill.load322, i64 5
  %2379 = icmp ult i32 %2378, 8
  %2380 = select i1 %2379, i32 %2378, i32 0
  %2381 = extractelement <8 x i1> %convergence.cascade.result317, i32 %2380
  %2382 = extractelement <8 x i1> %convergence.cascade.result317, i64 5
  %2383 = and i1 %2379, %2381
  %2384 = and i1 %2382, %2383
  %2385 = extractelement <8 x float> %2312, i32 %2380
  %2386 = select i1 %2384, float %2385, float 0.000000e+00
  %2387 = insertelement <8 x float> %2374, float %2386, i64 5
  %2388 = xor i1 %2384, true
  %2389 = and i1 %2382, %2388
  %2390 = insertelement <8 x i1> %2377, i1 %2389, i64 5
  %2391 = extractelement <8 x i32> %.spill.load322, i64 6
  %2392 = icmp ult i32 %2391, 8
  %2393 = select i1 %2392, i32 %2391, i32 0
  %2394 = extractelement <8 x i1> %convergence.cascade.result317, i32 %2393
  %2395 = extractelement <8 x i1> %convergence.cascade.result317, i64 6
  %2396 = and i1 %2392, %2394
  %2397 = and i1 %2395, %2396
  %2398 = extractelement <8 x float> %2312, i32 %2393
  %2399 = select i1 %2397, float %2398, float 0.000000e+00
  %2400 = insertelement <8 x float> %2387, float %2399, i64 6
  %2401 = xor i1 %2397, true
  %2402 = and i1 %2395, %2401
  %2403 = insertelement <8 x i1> %2390, i1 %2402, i64 6
  %2404 = extractelement <8 x i32> %.spill.load322, i64 7
  %2405 = icmp ult i32 %2404, 8
  %2406 = select i1 %2405, i32 %2404, i32 0
  %2407 = extractelement <8 x i1> %convergence.cascade.result317, i32 %2406
  %2408 = extractelement <8 x i1> %convergence.cascade.result317, i64 7
  %2409 = and i1 %2405, %2407
  %2410 = and i1 %2408, %2409
  %2411 = extractelement <8 x float> %2312, i32 %2406
  %2412 = select i1 %2410, float %2411, float 0.000000e+00
  %2413 = insertelement <8 x float> %2400, float %2412, i64 7
  %2414 = xor i1 %2410, true
  %2415 = and i1 %2408, %2414
  %2416 = insertelement <8 x i1> %2403, i1 %2415, i64 7
  %2417 = fadd <8 x float> %2312, %2413
  %.spill.load323 = load <8 x i32>, ptr %.spill21, align 32
  %2418 = extractelement <8 x i32> %.spill.load323, i64 0
  %2419 = icmp ult i32 %2418, 8
  %2420 = select i1 %2419, i32 %2418, i32 0
  %2421 = extractelement <8 x i1> %convergence.cascade.result317, i32 %2420
  %2422 = extractelement <8 x i1> %convergence.cascade.result317, i64 0
  %2423 = and i1 %2419, %2421
  %2424 = and i1 %2422, %2423
  %2425 = extractelement <8 x float> %2417, i32 %2420
  %2426 = select i1 %2424, float %2425, float 0.000000e+00
  %2427 = insertelement <8 x float> poison, float %2426, i64 0
  %2428 = xor i1 %2424, true
  %2429 = and i1 %2422, %2428
  %2430 = insertelement <8 x i1> poison, i1 %2429, i64 0
  %2431 = extractelement <8 x i32> %.spill.load323, i64 1
  %2432 = icmp ult i32 %2431, 8
  %2433 = select i1 %2432, i32 %2431, i32 0
  %2434 = extractelement <8 x i1> %convergence.cascade.result317, i32 %2433
  %2435 = extractelement <8 x i1> %convergence.cascade.result317, i64 1
  %2436 = and i1 %2432, %2434
  %2437 = and i1 %2435, %2436
  %2438 = extractelement <8 x float> %2417, i32 %2433
  %2439 = select i1 %2437, float %2438, float 0.000000e+00
  %2440 = insertelement <8 x float> %2427, float %2439, i64 1
  %2441 = xor i1 %2437, true
  %2442 = and i1 %2435, %2441
  %2443 = insertelement <8 x i1> %2430, i1 %2442, i64 1
  %2444 = extractelement <8 x i32> %.spill.load323, i64 2
  %2445 = icmp ult i32 %2444, 8
  %2446 = select i1 %2445, i32 %2444, i32 0
  %2447 = extractelement <8 x i1> %convergence.cascade.result317, i32 %2446
  %2448 = extractelement <8 x i1> %convergence.cascade.result317, i64 2
  %2449 = and i1 %2445, %2447
  %2450 = and i1 %2448, %2449
  %2451 = extractelement <8 x float> %2417, i32 %2446
  %2452 = select i1 %2450, float %2451, float 0.000000e+00
  %2453 = insertelement <8 x float> %2440, float %2452, i64 2
  %2454 = xor i1 %2450, true
  %2455 = and i1 %2448, %2454
  %2456 = insertelement <8 x i1> %2443, i1 %2455, i64 2
  %2457 = extractelement <8 x i32> %.spill.load323, i64 3
  %2458 = icmp ult i32 %2457, 8
  %2459 = select i1 %2458, i32 %2457, i32 0
  %2460 = extractelement <8 x i1> %convergence.cascade.result317, i32 %2459
  %2461 = extractelement <8 x i1> %convergence.cascade.result317, i64 3
  %2462 = and i1 %2458, %2460
  %2463 = and i1 %2461, %2462
  %2464 = extractelement <8 x float> %2417, i32 %2459
  %2465 = select i1 %2463, float %2464, float 0.000000e+00
  %2466 = insertelement <8 x float> %2453, float %2465, i64 3
  %2467 = xor i1 %2463, true
  %2468 = and i1 %2461, %2467
  %2469 = insertelement <8 x i1> %2456, i1 %2468, i64 3
  %2470 = extractelement <8 x i32> %.spill.load323, i64 4
  %2471 = icmp ult i32 %2470, 8
  %2472 = select i1 %2471, i32 %2470, i32 0
  %2473 = extractelement <8 x i1> %convergence.cascade.result317, i32 %2472
  %2474 = extractelement <8 x i1> %convergence.cascade.result317, i64 4
  %2475 = and i1 %2471, %2473
  %2476 = and i1 %2474, %2475
  %2477 = extractelement <8 x float> %2417, i32 %2472
  %2478 = select i1 %2476, float %2477, float 0.000000e+00
  %2479 = insertelement <8 x float> %2466, float %2478, i64 4
  %2480 = xor i1 %2476, true
  %2481 = and i1 %2474, %2480
  %2482 = insertelement <8 x i1> %2469, i1 %2481, i64 4
  %2483 = extractelement <8 x i32> %.spill.load323, i64 5
  %2484 = icmp ult i32 %2483, 8
  %2485 = select i1 %2484, i32 %2483, i32 0
  %2486 = extractelement <8 x i1> %convergence.cascade.result317, i32 %2485
  %2487 = extractelement <8 x i1> %convergence.cascade.result317, i64 5
  %2488 = and i1 %2484, %2486
  %2489 = and i1 %2487, %2488
  %2490 = extractelement <8 x float> %2417, i32 %2485
  %2491 = select i1 %2489, float %2490, float 0.000000e+00
  %2492 = insertelement <8 x float> %2479, float %2491, i64 5
  %2493 = xor i1 %2489, true
  %2494 = and i1 %2487, %2493
  %2495 = insertelement <8 x i1> %2482, i1 %2494, i64 5
  %2496 = extractelement <8 x i32> %.spill.load323, i64 6
  %2497 = icmp ult i32 %2496, 8
  %2498 = select i1 %2497, i32 %2496, i32 0
  %2499 = extractelement <8 x i1> %convergence.cascade.result317, i32 %2498
  %2500 = extractelement <8 x i1> %convergence.cascade.result317, i64 6
  %2501 = and i1 %2497, %2499
  %2502 = and i1 %2500, %2501
  %2503 = extractelement <8 x float> %2417, i32 %2498
  %2504 = select i1 %2502, float %2503, float 0.000000e+00
  %2505 = insertelement <8 x float> %2492, float %2504, i64 6
  %2506 = xor i1 %2502, true
  %2507 = and i1 %2500, %2506
  %2508 = insertelement <8 x i1> %2495, i1 %2507, i64 6
  %2509 = extractelement <8 x i32> %.spill.load323, i64 7
  %2510 = icmp ult i32 %2509, 8
  %2511 = select i1 %2510, i32 %2509, i32 0
  %2512 = extractelement <8 x i1> %convergence.cascade.result317, i32 %2511
  %2513 = extractelement <8 x i1> %convergence.cascade.result317, i64 7
  %2514 = and i1 %2510, %2512
  %2515 = and i1 %2513, %2514
  %2516 = extractelement <8 x float> %2417, i32 %2511
  %2517 = select i1 %2515, float %2516, float 0.000000e+00
  %2518 = insertelement <8 x float> %2505, float %2517, i64 7
  %2519 = xor i1 %2515, true
  %2520 = and i1 %2513, %2519
  %2521 = insertelement <8 x i1> %2508, i1 %2520, i64 7
  %2522 = fadd <8 x float> %2417, %2518
  %.spill.load324 = load <8 x i32>, ptr %.spill22, align 32
  %2523 = extractelement <8 x i32> %.spill.load324, i64 0
  %2524 = icmp ult i32 %2523, 8
  %2525 = select i1 %2524, i32 %2523, i32 0
  %2526 = extractelement <8 x i1> %convergence.cascade.result317, i32 %2525
  %2527 = extractelement <8 x i1> %convergence.cascade.result317, i64 0
  %2528 = and i1 %2524, %2526
  %2529 = and i1 %2527, %2528
  %2530 = extractelement <8 x float> %2522, i32 %2525
  %2531 = select i1 %2529, float %2530, float 0.000000e+00
  %2532 = insertelement <8 x float> poison, float %2531, i64 0
  %2533 = xor i1 %2529, true
  %2534 = and i1 %2527, %2533
  %2535 = insertelement <8 x i1> poison, i1 %2534, i64 0
  %2536 = extractelement <8 x i32> %.spill.load324, i64 1
  %2537 = icmp ult i32 %2536, 8
  %2538 = select i1 %2537, i32 %2536, i32 0
  %2539 = extractelement <8 x i1> %convergence.cascade.result317, i32 %2538
  %2540 = extractelement <8 x i1> %convergence.cascade.result317, i64 1
  %2541 = and i1 %2537, %2539
  %2542 = and i1 %2540, %2541
  %2543 = extractelement <8 x float> %2522, i32 %2538
  %2544 = select i1 %2542, float %2543, float 0.000000e+00
  %2545 = insertelement <8 x float> %2532, float %2544, i64 1
  %2546 = xor i1 %2542, true
  %2547 = and i1 %2540, %2546
  %2548 = insertelement <8 x i1> %2535, i1 %2547, i64 1
  %2549 = extractelement <8 x i32> %.spill.load324, i64 2
  %2550 = icmp ult i32 %2549, 8
  %2551 = select i1 %2550, i32 %2549, i32 0
  %2552 = extractelement <8 x i1> %convergence.cascade.result317, i32 %2551
  %2553 = extractelement <8 x i1> %convergence.cascade.result317, i64 2
  %2554 = and i1 %2550, %2552
  %2555 = and i1 %2553, %2554
  %2556 = extractelement <8 x float> %2522, i32 %2551
  %2557 = select i1 %2555, float %2556, float 0.000000e+00
  %2558 = insertelement <8 x float> %2545, float %2557, i64 2
  %2559 = xor i1 %2555, true
  %2560 = and i1 %2553, %2559
  %2561 = insertelement <8 x i1> %2548, i1 %2560, i64 2
  %2562 = extractelement <8 x i32> %.spill.load324, i64 3
  %2563 = icmp ult i32 %2562, 8
  %2564 = select i1 %2563, i32 %2562, i32 0
  %2565 = extractelement <8 x i1> %convergence.cascade.result317, i32 %2564
  %2566 = extractelement <8 x i1> %convergence.cascade.result317, i64 3
  %2567 = and i1 %2563, %2565
  %2568 = and i1 %2566, %2567
  %2569 = extractelement <8 x float> %2522, i32 %2564
  %2570 = select i1 %2568, float %2569, float 0.000000e+00
  %2571 = insertelement <8 x float> %2558, float %2570, i64 3
  %2572 = xor i1 %2568, true
  %2573 = and i1 %2566, %2572
  %2574 = insertelement <8 x i1> %2561, i1 %2573, i64 3
  %2575 = extractelement <8 x i32> %.spill.load324, i64 4
  %2576 = icmp ult i32 %2575, 8
  %2577 = select i1 %2576, i32 %2575, i32 0
  %2578 = extractelement <8 x i1> %convergence.cascade.result317, i32 %2577
  %2579 = extractelement <8 x i1> %convergence.cascade.result317, i64 4
  %2580 = and i1 %2576, %2578
  %2581 = and i1 %2579, %2580
  %2582 = extractelement <8 x float> %2522, i32 %2577
  %2583 = select i1 %2581, float %2582, float 0.000000e+00
  %2584 = insertelement <8 x float> %2571, float %2583, i64 4
  %2585 = xor i1 %2581, true
  %2586 = and i1 %2579, %2585
  %2587 = insertelement <8 x i1> %2574, i1 %2586, i64 4
  %2588 = extractelement <8 x i32> %.spill.load324, i64 5
  %2589 = icmp ult i32 %2588, 8
  %2590 = select i1 %2589, i32 %2588, i32 0
  %2591 = extractelement <8 x i1> %convergence.cascade.result317, i32 %2590
  %2592 = extractelement <8 x i1> %convergence.cascade.result317, i64 5
  %2593 = and i1 %2589, %2591
  %2594 = and i1 %2592, %2593
  %2595 = extractelement <8 x float> %2522, i32 %2590
  %2596 = select i1 %2594, float %2595, float 0.000000e+00
  %2597 = insertelement <8 x float> %2584, float %2596, i64 5
  %2598 = xor i1 %2594, true
  %2599 = and i1 %2592, %2598
  %2600 = insertelement <8 x i1> %2587, i1 %2599, i64 5
  %2601 = extractelement <8 x i32> %.spill.load324, i64 6
  %2602 = icmp ult i32 %2601, 8
  %2603 = select i1 %2602, i32 %2601, i32 0
  %2604 = extractelement <8 x i1> %convergence.cascade.result317, i32 %2603
  %2605 = extractelement <8 x i1> %convergence.cascade.result317, i64 6
  %2606 = and i1 %2602, %2604
  %2607 = and i1 %2605, %2606
  %2608 = extractelement <8 x float> %2522, i32 %2603
  %2609 = select i1 %2607, float %2608, float 0.000000e+00
  %2610 = insertelement <8 x float> %2597, float %2609, i64 6
  %2611 = xor i1 %2607, true
  %2612 = and i1 %2605, %2611
  %2613 = insertelement <8 x i1> %2600, i1 %2612, i64 6
  %2614 = extractelement <8 x i32> %.spill.load324, i64 7
  %2615 = icmp ult i32 %2614, 8
  %2616 = select i1 %2615, i32 %2614, i32 0
  %2617 = extractelement <8 x i1> %convergence.cascade.result317, i32 %2616
  %2618 = extractelement <8 x i1> %convergence.cascade.result317, i64 7
  %2619 = and i1 %2615, %2617
  %2620 = and i1 %2618, %2619
  %2621 = extractelement <8 x float> %2522, i32 %2616
  %2622 = select i1 %2620, float %2621, float 0.000000e+00
  %2623 = insertelement <8 x float> %2610, float %2622, i64 7
  %2624 = xor i1 %2620, true
  %2625 = and i1 %2618, %2624
  %2626 = insertelement <8 x i1> %2613, i1 %2625, i64 7
  %2627 = fadd <8 x float> %2522, %2623
  %2628 = extractelement <8 x i1> %convergence.cascade.result317, i32 0
  %2629 = extractelement <8 x i1> %convergence.cascade.result317, i64 0
  %2630 = and i1 true, %2628
  %2631 = and i1 %2629, %2630
  %2632 = extractelement <8 x float> %2627, i32 0
  %2633 = select i1 %2631, float %2632, float 0.000000e+00
  %2634 = insertelement <8 x float> poison, float %2633, i64 0
  %2635 = xor i1 %2631, true
  %2636 = and i1 %2629, %2635
  %2637 = insertelement <8 x i1> poison, i1 %2636, i64 0
  %2638 = extractelement <8 x i1> %convergence.cascade.result317, i32 0
  %2639 = extractelement <8 x i1> %convergence.cascade.result317, i64 1
  %2640 = and i1 true, %2638
  %2641 = and i1 %2639, %2640
  %2642 = extractelement <8 x float> %2627, i32 0
  %2643 = select i1 %2641, float %2642, float 0.000000e+00
  %2644 = insertelement <8 x float> %2634, float %2643, i64 1
  %2645 = xor i1 %2641, true
  %2646 = and i1 %2639, %2645
  %2647 = insertelement <8 x i1> %2637, i1 %2646, i64 1
  %2648 = extractelement <8 x i1> %convergence.cascade.result317, i32 0
  %2649 = extractelement <8 x i1> %convergence.cascade.result317, i64 2
  %2650 = and i1 true, %2648
  %2651 = and i1 %2649, %2650
  %2652 = extractelement <8 x float> %2627, i32 0
  %2653 = select i1 %2651, float %2652, float 0.000000e+00
  %2654 = insertelement <8 x float> %2644, float %2653, i64 2
  %2655 = xor i1 %2651, true
  %2656 = and i1 %2649, %2655
  %2657 = insertelement <8 x i1> %2647, i1 %2656, i64 2
  %2658 = extractelement <8 x i1> %convergence.cascade.result317, i32 0
  %2659 = extractelement <8 x i1> %convergence.cascade.result317, i64 3
  %2660 = and i1 true, %2658
  %2661 = and i1 %2659, %2660
  %2662 = extractelement <8 x float> %2627, i32 0
  %2663 = select i1 %2661, float %2662, float 0.000000e+00
  %2664 = insertelement <8 x float> %2654, float %2663, i64 3
  %2665 = xor i1 %2661, true
  %2666 = and i1 %2659, %2665
  %2667 = insertelement <8 x i1> %2657, i1 %2666, i64 3
  %2668 = extractelement <8 x i1> %convergence.cascade.result317, i32 0
  %2669 = extractelement <8 x i1> %convergence.cascade.result317, i64 4
  %2670 = and i1 true, %2668
  %2671 = and i1 %2669, %2670
  %2672 = extractelement <8 x float> %2627, i32 0
  %2673 = select i1 %2671, float %2672, float 0.000000e+00
  %2674 = insertelement <8 x float> %2664, float %2673, i64 4
  %2675 = xor i1 %2671, true
  %2676 = and i1 %2669, %2675
  %2677 = insertelement <8 x i1> %2667, i1 %2676, i64 4
  %2678 = extractelement <8 x i1> %convergence.cascade.result317, i32 0
  %2679 = extractelement <8 x i1> %convergence.cascade.result317, i64 5
  %2680 = and i1 true, %2678
  %2681 = and i1 %2679, %2680
  %2682 = extractelement <8 x float> %2627, i32 0
  %2683 = select i1 %2681, float %2682, float 0.000000e+00
  %2684 = insertelement <8 x float> %2674, float %2683, i64 5
  %2685 = xor i1 %2681, true
  %2686 = and i1 %2679, %2685
  %2687 = insertelement <8 x i1> %2677, i1 %2686, i64 5
  %2688 = extractelement <8 x i1> %convergence.cascade.result317, i32 0
  %2689 = extractelement <8 x i1> %convergence.cascade.result317, i64 6
  %2690 = and i1 true, %2688
  %2691 = and i1 %2689, %2690
  %2692 = extractelement <8 x float> %2627, i32 0
  %2693 = select i1 %2691, float %2692, float 0.000000e+00
  %2694 = insertelement <8 x float> %2684, float %2693, i64 6
  %2695 = xor i1 %2691, true
  %2696 = and i1 %2689, %2695
  %2697 = insertelement <8 x i1> %2687, i1 %2696, i64 6
  %2698 = extractelement <8 x i1> %convergence.cascade.result317, i32 0
  %2699 = extractelement <8 x i1> %convergence.cascade.result317, i64 7
  %2700 = and i1 true, %2698
  %2701 = and i1 %2699, %2700
  %2702 = extractelement <8 x float> %2627, i32 0
  %2703 = select i1 %2701, float %2702, float 0.000000e+00
  %2704 = insertelement <8 x float> %2694, float %2703, i64 7
  %2705 = xor i1 %2701, true
  %2706 = and i1 %2699, %2705
  %2707 = insertelement <8 x i1> %2697, i1 %2706, i64 7
  %2708 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result317)
  %2709 = bitcast <8 x i1> %convergence.cascade.result317 to i8
  %2710 = call i8 @llvm.cttz.i8(i8 %2709, i1 false)
  %2711 = zext i8 %2710 to i32
  %2712 = select i1 %2708, i32 %2711, i32 0
  %2713 = extractelement <8 x float> %2704, i32 %2712
  %.spill.load325 = load float, ptr %.spill12, align 4
  %2714 = fadd float %.spill.load325, %2713
  %.spill.load326 = load float, ptr %.spill23, align 4
  %2715 = fdiv float %2714, %.spill.load326
  %.splatinsert327 = insertelement <8 x float> poison, float %2715, i64 0
  %.splat328 = shufflevector <8 x float> %.splatinsert327, <8 x float> poison, <8 x i32> zeroinitializer
  %2716 = load <8 x float>, ptr %.spill33, align 32
  %2717 = select <8 x i1> %convergence.cascade.result317, <8 x float> %.splat328, <8 x float> %2716
  store <8 x float> %2717, ptr %.spill33, align 32
  %2718 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill34, align 64
  %2719 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %2720 = extractvalue { <8 x ptr>, <8 x i64> } %2718, 0
  %2721 = select <8 x i1> %convergence.cascade.result317, <8 x ptr> %2719, <8 x ptr> %2720
  %2722 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %2723 = extractvalue { <8 x ptr>, <8 x i64> } %2718, 1
  %2724 = select <8 x i1> %convergence.cascade.result317, <8 x i64> %2722, <8 x i64> %2723
  %2725 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2721, 0
  %2726 = insertvalue { <8 x ptr>, <8 x i64> } %2725, <8 x i64> %2724, 1
  store { <8 x ptr>, <8 x i64> } %2726, ptr %tile_snapshot.spill34, align 64
  %2727 = load <8 x i64>, ptr %.slot35, align 64
  %2728 = select <8 x i1> %convergence.cascade.result317, <8 x i64> zeroinitializer, <8 x i64> %2727
  store <8 x i64> %2728, ptr %.slot35, align 64
  store <8 x i1> %convergence.cascade.result317, ptr %current.mask, align 1
  %2729 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result317)
  br i1 %2729, label %schedule.21, label %scheduler.loop

varying.divergent330:                             ; preds = %schedule.21
  %2730 = load i32, ptr %current.token, align 4
  %2731 = icmp ne i32 %2730, 0
  %2732 = sub i32 %2730, 1
  %2733 = select i1 %2731, i32 %2732, i32 0
  %2734 = load i8, ptr %frame.active, align 1
  %2735 = trunc i32 %2733 to i8
  %2736 = shl i8 1, %2735
  %2737 = and i8 %2734, %2736
  %2738 = icmp ne i8 %2737, 0
  %2739 = load <8 x i32>, ptr %frame.static.id, align 32
  %2740 = extractelement <8 x i32> %2739, i32 %2733
  %2741 = icmp eq i32 %2740, 7
  %2742 = and i1 %2738, %2741
  %2743 = and i1 %2731, %2742
  %2744 = xor i1 %2743, true
  %2745 = and i1 true, %2744
  %2746 = xor i8 %2734, -1
  %2747 = icmp ne i8 %2746, 0
  %2748 = xor i1 %2747, true
  %2749 = and i1 %2745, %2748
  br i1 %2749, label %convergence.overflow.trap332, label %convergence.overflow.resume333

varying.coherent331:                              ; preds = %schedule.21
  br i1 %560, label %varying.coherent.true336, label %varying.coherent.false337

convergence.overflow.trap332:                     ; preds = %varying.divergent330
  call void @llvm.trap()
  unreachable

convergence.overflow.resume333:                   ; preds = %varying.divergent330
  %2750 = call i8 @llvm.cttz.i8(i8 %2746, i1 false)
  %2751 = zext i8 %2750 to i32
  %2752 = select i1 %2747, i32 %2751, i32 0
  %2753 = trunc i32 %2752 to i8
  %2754 = shl i8 1, %2753
  %2755 = or i8 %2734, %2754
  %2756 = select i1 %2745, i8 %2755, i8 %2734
  store i8 %2756, ptr %frame.active, align 1
  %2757 = load <8 x i32>, ptr %frame.static.id, align 32
  %2758 = extractelement <8 x i32> %2757, i32 %2752
  %2759 = select i1 %2745, i32 7, i32 %2758
  %2760 = load <8 x i32>, ptr %frame.static.id, align 32
  %2761 = insertelement <8 x i32> %2760, i32 %2759, i32 %2752
  store <8 x i32> %2761, ptr %frame.static.id, align 32
  %2762 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2763 = extractelement <8 x i32> %2762, i32 %2752
  %2764 = select i1 %2745, i32 %2730, i32 %2763
  %2765 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2766 = insertelement <8 x i32> %2765, i32 %2764, i32 %2752
  store <8 x i32> %2766, ptr %frame.parent.token, align 32
  %2767 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2752
  %2768 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2752
  %2769 = load <8 x i1>, ptr %2767, align 1
  %2770 = load <8 x i1>, ptr %2768, align 1
  %2771 = select i1 %2745, <8 x i1> %550, <8 x i1> %2769
  store <8 x i1> %2771, ptr %2767, align 1
  %2772 = select i1 %2745, <8 x i1> zeroinitializer, <8 x i1> %2770
  store <8 x i1> %2772, ptr %2768, align 1
  %2773 = add i32 %2752, 1
  %2774 = select i1 %2743, i32 %2730, i32 %2773
  %2775 = select i1 true, i32 %2774, i32 %2730
  store i32 %2775, ptr %current.token, align 4
  %2776 = load i32, ptr %current.token, align 4
  %2777 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %557)
  %2778 = load i32, ptr %ready.count, align 4
  %2779 = icmp uge i32 %2778, 8
  %2780 = and i1 %2777, %2779
  br i1 %2780, label %ready.overflow.trap334, label %ready.overflow.resume335

ready.overflow.trap334:                           ; preds = %convergence.overflow.resume333
  call void @llvm.trap()
  unreachable

ready.overflow.resume335:                         ; preds = %convergence.overflow.resume333
  %2781 = select i1 %2777, i32 %2778, i32 0
  %2782 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2781
  %2783 = load <8 x i1>, ptr %2782, align 1
  %2784 = select i1 %2777, <8 x i1> %557, <8 x i1> %2783
  store <8 x i1> %2784, ptr %2782, align 1
  %2785 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2781
  %2786 = load i32, ptr %2785, align 4
  %2787 = select i1 %2777, i32 22, i32 %2786
  store i32 %2787, ptr %2785, align 4
  %2788 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2781
  %2789 = load i32, ptr %2788, align 4
  %2790 = select i1 %2777, i32 %2776, i32 %2789
  store i32 %2790, ptr %2788, align 4
  %2791 = add i32 %2778, 1
  %2792 = select i1 %2777, i32 %2791, i32 %2778
  store i32 %2792, ptr %ready.count, align 4
  %2793 = load <8 x i1>, ptr %runnable.mask, align 1
  %2794 = or <8 x i1> %2793, %557
  store <8 x i1> %2794, ptr %runnable.mask, align 1
  store <8 x i1> %559, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true336:                         ; preds = %varying.coherent331
  store <8 x i1> %550, ptr %current.mask, align 1
  %2795 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %550)
  br i1 %2795, label %schedule.22, label %scheduler.loop

varying.coherent.false337:                        ; preds = %varying.coherent331
  store <8 x i1> %550, ptr %current.mask, align 1
  %2796 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %550)
  br i1 %2796, label %schedule.23, label %scheduler.loop

convergence.cascade348:                           ; preds = %convergence.cascade348, %schedule.23
  %convergence.cascade.flow352 = phi <8 x i1> [ %593, %schedule.23 ], [ %2839, %convergence.cascade348 ]
  %convergence.cascade.depth353 = phi i32 [ 0, %schedule.23 ], [ %2840, %convergence.cascade348 ]
  %2797 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow352)
  %2798 = load i32, ptr %current.token, align 4
  %2799 = icmp ne i32 %2798, 0
  %2800 = and i1 %2797, %2799
  %2801 = sub i32 %2798, 1
  %2802 = select i1 %2800, i32 %2801, i32 0
  %2803 = load i8, ptr %frame.active, align 1
  %2804 = trunc i32 %2802 to i8
  %2805 = shl i8 1, %2804
  %2806 = and i8 %2803, %2805
  %2807 = icmp ne i8 %2806, 0
  %2808 = load <8 x i32>, ptr %frame.static.id, align 32
  %2809 = extractelement <8 x i32> %2808, i32 %2802
  %convergence.target.pointer354 = getelementptr inbounds [13 x i32], ptr @convergence.targets, i32 0, i32 %2809
  %convergence.dynamic.target355 = load i32, ptr %convergence.target.pointer354, align 4
  %2810 = icmp eq i32 %convergence.dynamic.target355, 23
  %2811 = and i1 %2807, %2810
  %2812 = and i1 %2800, %2811
  %2813 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2802
  %2814 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2802
  %2815 = load <8 x i1>, ptr %2813, align 1
  %2816 = load <8 x i1>, ptr %2814, align 1
  %2817 = or <8 x i1> %2816, %convergence.cascade.flow352
  %2818 = load <8 x i1>, ptr %live.mask, align 1
  %2819 = and <8 x i1> %2815, %2818
  %2820 = icmp eq <8 x i1> %2817, %2819
  %2821 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2820)
  %2822 = and i1 %2812, %2821
  %2823 = select i1 %2822, <8 x i1> zeroinitializer, <8 x i1> %2817
  %2824 = select i1 %2812, <8 x i1> %2823, <8 x i1> %2816
  store <8 x i1> %2824, ptr %2814, align 1
  %2825 = select i1 %2822, <8 x i1> zeroinitializer, <8 x i1> %2815
  store <8 x i1> %2825, ptr %2813, align 1
  %2826 = trunc i32 %2802 to i8
  %2827 = shl i8 1, %2826
  %2828 = xor i8 %2827, -1
  %2829 = and i8 %2803, %2828
  %2830 = select i1 %2822, i8 %2829, i8 %2803
  store i8 %2830, ptr %frame.active, align 1
  %.splatinsert356 = insertelement <8 x i1> poison, i1 %2812, i64 0
  %.splat357 = shufflevector <8 x i1> %.splatinsert356, <8 x i1> poison, <8 x i32> zeroinitializer
  %2831 = and <8 x i1> %convergence.cascade.flow352, %.splat357
  %2832 = load <8 x i1>, ptr %runnable.mask, align 1
  %2833 = xor <8 x i1> %2831, splat (i1 true)
  %2834 = and <8 x i1> %2832, %2833
  store <8 x i1> %2834, ptr %runnable.mask, align 1
  %.splatinsert358 = insertelement <8 x i1> poison, i1 %2822, i64 0
  %.splat359 = shufflevector <8 x i1> %.splatinsert358, <8 x i1> poison, <8 x i32> zeroinitializer
  %2835 = select <8 x i1> %.splat359, <8 x i1> %2817, <8 x i1> zeroinitializer
  %2836 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2837 = extractelement <8 x i32> %2836, i32 %2802
  %2838 = select i1 %2822, i32 %2837, i32 %2798
  store i32 %2838, ptr %current.token, align 4
  %.splatinsert360 = insertelement <8 x i1> poison, i1 %2812, i64 0
  %.splat361 = shufflevector <8 x i1> %.splatinsert360, <8 x i1> poison, <8 x i32> zeroinitializer
  %2839 = select <8 x i1> %.splat361, <8 x i1> %2835, <8 x i1> %convergence.cascade.flow352
  %2840 = add i32 %convergence.cascade.depth353, 1
  %2841 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2839)
  %2842 = icmp ult i32 %2840, 8
  %2843 = and i1 %2841, %2842
  %2844 = and i1 %2812, %2843
  %convergence.parent.token362 = load i32, ptr %current.token, align 4
  %convergence.parent.present363 = icmp ne i32 %convergence.parent.token362, 0
  %2845 = and i1 %2844, %convergence.parent.present363
  br i1 %2845, label %convergence.cascade348, label %convergence.cascade.exit349

convergence.cascade.exit349:                      ; preds = %convergence.cascade348, %schedule.23
  %convergence.cascade.result364 = phi <8 x i1> [ %593, %schedule.23 ], [ %2839, %convergence.cascade348 ]
  %2846 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result364)
  br i1 %2846, label %convergence.target.23.ready, label %scheduler.loop

convergence.target.23.ready:                      ; preds = %convergence.cascade.exit349
  %2847 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result364)
  %2848 = bitcast <8 x i1> %convergence.cascade.result364 to i8
  %2849 = call i8 @llvm.cttz.i8(i8 %2848, i1 false)
  %2850 = zext i8 %2849 to i32
  %2851 = select i1 %2847, i32 %2850, i32 0
  %.spill.load365 = load <8 x i1>, ptr %.spill11, align 1
  %2852 = and <8 x i1> %convergence.cascade.result364, %.spill.load365
  %2853 = xor <8 x i1> %.spill.load365, splat (i1 true)
  %2854 = and <8 x i1> %convergence.cascade.result364, %2853
  %2855 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2852)
  %2856 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2854)
  %2857 = and i1 %2855, %2856
  br i1 %2857, label %varying.divergent366, label %varying.coherent367

varying.divergent366:                             ; preds = %convergence.target.23.ready
  %2858 = load i32, ptr %current.token, align 4
  %2859 = icmp ne i32 %2858, 0
  %2860 = sub i32 %2858, 1
  %2861 = select i1 %2859, i32 %2860, i32 0
  %2862 = load i8, ptr %frame.active, align 1
  %2863 = trunc i32 %2861 to i8
  %2864 = shl i8 1, %2863
  %2865 = and i8 %2862, %2864
  %2866 = icmp ne i8 %2865, 0
  %2867 = load <8 x i32>, ptr %frame.static.id, align 32
  %2868 = extractelement <8 x i32> %2867, i32 %2861
  %2869 = icmp eq i32 %2868, 8
  %2870 = and i1 %2866, %2869
  %2871 = and i1 %2859, %2870
  %2872 = xor i1 %2871, true
  %2873 = and i1 true, %2872
  %2874 = xor i8 %2862, -1
  %2875 = icmp ne i8 %2874, 0
  %2876 = xor i1 %2875, true
  %2877 = and i1 %2873, %2876
  br i1 %2877, label %convergence.overflow.trap368, label %convergence.overflow.resume369

varying.coherent367:                              ; preds = %convergence.target.23.ready
  br i1 %2855, label %varying.coherent.true372, label %varying.coherent.false373

convergence.overflow.trap368:                     ; preds = %varying.divergent366
  call void @llvm.trap()
  unreachable

convergence.overflow.resume369:                   ; preds = %varying.divergent366
  %2878 = call i8 @llvm.cttz.i8(i8 %2874, i1 false)
  %2879 = zext i8 %2878 to i32
  %2880 = select i1 %2875, i32 %2879, i32 0
  %2881 = trunc i32 %2880 to i8
  %2882 = shl i8 1, %2881
  %2883 = or i8 %2862, %2882
  %2884 = select i1 %2873, i8 %2883, i8 %2862
  store i8 %2884, ptr %frame.active, align 1
  %2885 = load <8 x i32>, ptr %frame.static.id, align 32
  %2886 = extractelement <8 x i32> %2885, i32 %2880
  %2887 = select i1 %2873, i32 8, i32 %2886
  %2888 = load <8 x i32>, ptr %frame.static.id, align 32
  %2889 = insertelement <8 x i32> %2888, i32 %2887, i32 %2880
  store <8 x i32> %2889, ptr %frame.static.id, align 32
  %2890 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2891 = extractelement <8 x i32> %2890, i32 %2880
  %2892 = select i1 %2873, i32 %2858, i32 %2891
  %2893 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2894 = insertelement <8 x i32> %2893, i32 %2892, i32 %2880
  store <8 x i32> %2894, ptr %frame.parent.token, align 32
  %2895 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2880
  %2896 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2880
  %2897 = load <8 x i1>, ptr %2895, align 1
  %2898 = load <8 x i1>, ptr %2896, align 1
  %2899 = select i1 %2873, <8 x i1> %convergence.cascade.result364, <8 x i1> %2897
  store <8 x i1> %2899, ptr %2895, align 1
  %2900 = select i1 %2873, <8 x i1> zeroinitializer, <8 x i1> %2898
  store <8 x i1> %2900, ptr %2896, align 1
  %2901 = add i32 %2880, 1
  %2902 = select i1 %2871, i32 %2858, i32 %2901
  %2903 = select i1 true, i32 %2902, i32 %2858
  store i32 %2903, ptr %current.token, align 4
  %2904 = load i32, ptr %current.token, align 4
  %2905 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2852)
  %2906 = load i32, ptr %ready.count, align 4
  %2907 = icmp uge i32 %2906, 8
  %2908 = and i1 %2905, %2907
  br i1 %2908, label %ready.overflow.trap370, label %ready.overflow.resume371

ready.overflow.trap370:                           ; preds = %convergence.overflow.resume369
  call void @llvm.trap()
  unreachable

ready.overflow.resume371:                         ; preds = %convergence.overflow.resume369
  %2909 = select i1 %2905, i32 %2906, i32 0
  %2910 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2909
  %2911 = load <8 x i1>, ptr %2910, align 1
  %2912 = select i1 %2905, <8 x i1> %2852, <8 x i1> %2911
  store <8 x i1> %2912, ptr %2910, align 1
  %2913 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2909
  %2914 = load i32, ptr %2913, align 4
  %2915 = select i1 %2905, i32 24, i32 %2914
  store i32 %2915, ptr %2913, align 4
  %2916 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2909
  %2917 = load i32, ptr %2916, align 4
  %2918 = select i1 %2905, i32 %2904, i32 %2917
  store i32 %2918, ptr %2916, align 4
  %2919 = add i32 %2906, 1
  %2920 = select i1 %2905, i32 %2919, i32 %2906
  store i32 %2920, ptr %ready.count, align 4
  %2921 = load <8 x i1>, ptr %runnable.mask, align 1
  %2922 = or <8 x i1> %2921, %2852
  store <8 x i1> %2922, ptr %runnable.mask, align 1
  store <8 x i1> %2854, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true372:                         ; preds = %varying.coherent367
  store <8 x i1> %convergence.cascade.result364, ptr %current.mask, align 1
  %2923 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result364)
  br i1 %2923, label %schedule.24, label %scheduler.loop

varying.coherent.false373:                        ; preds = %varying.coherent367
  store <8 x i1> %convergence.cascade.result364, ptr %current.mask, align 1
  %2924 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result364)
  br i1 %2924, label %schedule.25, label %scheduler.loop

convergence.cascade383:                           ; preds = %convergence.cascade383, %schedule.25
  %convergence.cascade.flow387 = phi <8 x i1> [ %626, %schedule.25 ], [ %2967, %convergence.cascade383 ]
  %convergence.cascade.depth388 = phi i32 [ 0, %schedule.25 ], [ %2968, %convergence.cascade383 ]
  %2925 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow387)
  %2926 = load i32, ptr %current.token, align 4
  %2927 = icmp ne i32 %2926, 0
  %2928 = and i1 %2925, %2927
  %2929 = sub i32 %2926, 1
  %2930 = select i1 %2928, i32 %2929, i32 0
  %2931 = load i8, ptr %frame.active, align 1
  %2932 = trunc i32 %2930 to i8
  %2933 = shl i8 1, %2932
  %2934 = and i8 %2931, %2933
  %2935 = icmp ne i8 %2934, 0
  %2936 = load <8 x i32>, ptr %frame.static.id, align 32
  %2937 = extractelement <8 x i32> %2936, i32 %2930
  %convergence.target.pointer389 = getelementptr inbounds [13 x i32], ptr @convergence.targets, i32 0, i32 %2937
  %convergence.dynamic.target390 = load i32, ptr %convergence.target.pointer389, align 4
  %2938 = icmp eq i32 %convergence.dynamic.target390, 25
  %2939 = and i1 %2935, %2938
  %2940 = and i1 %2928, %2939
  %2941 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2930
  %2942 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2930
  %2943 = load <8 x i1>, ptr %2941, align 1
  %2944 = load <8 x i1>, ptr %2942, align 1
  %2945 = or <8 x i1> %2944, %convergence.cascade.flow387
  %2946 = load <8 x i1>, ptr %live.mask, align 1
  %2947 = and <8 x i1> %2943, %2946
  %2948 = icmp eq <8 x i1> %2945, %2947
  %2949 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2948)
  %2950 = and i1 %2940, %2949
  %2951 = select i1 %2950, <8 x i1> zeroinitializer, <8 x i1> %2945
  %2952 = select i1 %2940, <8 x i1> %2951, <8 x i1> %2944
  store <8 x i1> %2952, ptr %2942, align 1
  %2953 = select i1 %2950, <8 x i1> zeroinitializer, <8 x i1> %2943
  store <8 x i1> %2953, ptr %2941, align 1
  %2954 = trunc i32 %2930 to i8
  %2955 = shl i8 1, %2954
  %2956 = xor i8 %2955, -1
  %2957 = and i8 %2931, %2956
  %2958 = select i1 %2950, i8 %2957, i8 %2931
  store i8 %2958, ptr %frame.active, align 1
  %.splatinsert391 = insertelement <8 x i1> poison, i1 %2940, i64 0
  %.splat392 = shufflevector <8 x i1> %.splatinsert391, <8 x i1> poison, <8 x i32> zeroinitializer
  %2959 = and <8 x i1> %convergence.cascade.flow387, %.splat392
  %2960 = load <8 x i1>, ptr %runnable.mask, align 1
  %2961 = xor <8 x i1> %2959, splat (i1 true)
  %2962 = and <8 x i1> %2960, %2961
  store <8 x i1> %2962, ptr %runnable.mask, align 1
  %.splatinsert393 = insertelement <8 x i1> poison, i1 %2950, i64 0
  %.splat394 = shufflevector <8 x i1> %.splatinsert393, <8 x i1> poison, <8 x i32> zeroinitializer
  %2963 = select <8 x i1> %.splat394, <8 x i1> %2945, <8 x i1> zeroinitializer
  %2964 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2965 = extractelement <8 x i32> %2964, i32 %2930
  %2966 = select i1 %2950, i32 %2965, i32 %2926
  store i32 %2966, ptr %current.token, align 4
  %.splatinsert395 = insertelement <8 x i1> poison, i1 %2940, i64 0
  %.splat396 = shufflevector <8 x i1> %.splatinsert395, <8 x i1> poison, <8 x i32> zeroinitializer
  %2967 = select <8 x i1> %.splat396, <8 x i1> %2963, <8 x i1> %convergence.cascade.flow387
  %2968 = add i32 %convergence.cascade.depth388, 1
  %2969 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2967)
  %2970 = icmp ult i32 %2968, 8
  %2971 = and i1 %2969, %2970
  %2972 = and i1 %2940, %2971
  %convergence.parent.token397 = load i32, ptr %current.token, align 4
  %convergence.parent.present398 = icmp ne i32 %convergence.parent.token397, 0
  %2973 = and i1 %2972, %convergence.parent.present398
  br i1 %2973, label %convergence.cascade383, label %convergence.cascade.exit384

convergence.cascade.exit384:                      ; preds = %convergence.cascade383, %schedule.25
  %convergence.cascade.result399 = phi <8 x i1> [ %626, %schedule.25 ], [ %2967, %convergence.cascade383 ]
  %2974 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result399)
  br i1 %2974, label %convergence.target.25.ready, label %scheduler.loop

convergence.target.25.ready:                      ; preds = %convergence.cascade.exit384
  %2975 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result399)
  %2976 = bitcast <8 x i1> %convergence.cascade.result399 to i8
  %2977 = call i8 @llvm.cttz.i8(i8 %2976, i1 false)
  %2978 = zext i8 %2977 to i32
  %2979 = select i1 %2975, i32 %2978, i32 0
  %.spill.load400 = load <8 x float>, ptr %.spill33, align 32
  %2980 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result399)
  %2981 = bitcast <8 x i1> %convergence.cascade.result399 to i8
  %2982 = call i8 @llvm.cttz.i8(i8 %2981, i1 false)
  %2983 = zext i8 %2982 to i32
  %2984 = select i1 %2980, i32 %2983, i32 0
  %2985 = extractelement <8 x float> %.spill.load400, i32 %2984
  %2986 = fadd float %2985, 0x3EE4F8B580000000
  %2987 = call float @llvm.sqrt.f32(float %2986)
  %.splatinsert401 = insertelement <8 x float> poison, float %2987, i64 0
  %.splat402 = shufflevector <8 x float> %.splatinsert401, <8 x float> poison, <8 x i32> zeroinitializer
  %2988 = load <8 x float>, ptr %.spill36, align 32
  %2989 = select <8 x i1> %convergence.cascade.result399, <8 x float> %.splat402, <8 x float> %2988
  store <8 x float> %2989, ptr %.spill36, align 32
  %2990 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %2991 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %2992 = extractvalue { <8 x ptr>, <8 x i64> } %2990, 0
  %2993 = select <8 x i1> %convergence.cascade.result399, <8 x ptr> %2991, <8 x ptr> %2992
  %2994 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %2995 = extractvalue { <8 x ptr>, <8 x i64> } %2990, 1
  %2996 = select <8 x i1> %convergence.cascade.result399, <8 x i64> %2994, <8 x i64> %2995
  %2997 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2993, 0
  %2998 = insertvalue { <8 x ptr>, <8 x i64> } %2997, <8 x i64> %2996, 1
  store { <8 x ptr>, <8 x i64> } %2998, ptr %tile_snapshot.spill37, align 64
  %2999 = load <8 x i64>, ptr %.slot38, align 64
  %3000 = select <8 x i1> %convergence.cascade.result399, <8 x i64> zeroinitializer, <8 x i64> %2999
  store <8 x i64> %3000, ptr %.slot38, align 64
  store <8 x i1> %convergence.cascade.result399, ptr %current.mask, align 1
  %3001 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result399)
  br i1 %3001, label %schedule.26, label %scheduler.loop

varying.divergent404:                             ; preds = %schedule.26
  %3002 = load i32, ptr %current.token, align 4
  %3003 = icmp ne i32 %3002, 0
  %3004 = sub i32 %3002, 1
  %3005 = select i1 %3003, i32 %3004, i32 0
  %3006 = load i8, ptr %frame.active, align 1
  %3007 = trunc i32 %3005 to i8
  %3008 = shl i8 1, %3007
  %3009 = and i8 %3006, %3008
  %3010 = icmp ne i8 %3009, 0
  %3011 = load <8 x i32>, ptr %frame.static.id, align 32
  %3012 = extractelement <8 x i32> %3011, i32 %3005
  %3013 = icmp eq i32 %3012, 9
  %3014 = and i1 %3010, %3013
  %3015 = and i1 %3003, %3014
  %3016 = xor i1 %3015, true
  %3017 = and i1 true, %3016
  %3018 = xor i8 %3006, -1
  %3019 = icmp ne i8 %3018, 0
  %3020 = xor i1 %3019, true
  %3021 = and i1 %3017, %3020
  br i1 %3021, label %convergence.overflow.trap406, label %convergence.overflow.resume407

varying.coherent405:                              ; preds = %schedule.26
  br i1 %637, label %varying.coherent.true410, label %varying.coherent.false411

convergence.overflow.trap406:                     ; preds = %varying.divergent404
  call void @llvm.trap()
  unreachable

convergence.overflow.resume407:                   ; preds = %varying.divergent404
  %3022 = call i8 @llvm.cttz.i8(i8 %3018, i1 false)
  %3023 = zext i8 %3022 to i32
  %3024 = select i1 %3019, i32 %3023, i32 0
  %3025 = trunc i32 %3024 to i8
  %3026 = shl i8 1, %3025
  %3027 = or i8 %3006, %3026
  %3028 = select i1 %3017, i8 %3027, i8 %3006
  store i8 %3028, ptr %frame.active, align 1
  %3029 = load <8 x i32>, ptr %frame.static.id, align 32
  %3030 = extractelement <8 x i32> %3029, i32 %3024
  %3031 = select i1 %3017, i32 9, i32 %3030
  %3032 = load <8 x i32>, ptr %frame.static.id, align 32
  %3033 = insertelement <8 x i32> %3032, i32 %3031, i32 %3024
  store <8 x i32> %3033, ptr %frame.static.id, align 32
  %3034 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3035 = extractelement <8 x i32> %3034, i32 %3024
  %3036 = select i1 %3017, i32 %3002, i32 %3035
  %3037 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3038 = insertelement <8 x i32> %3037, i32 %3036, i32 %3024
  store <8 x i32> %3038, ptr %frame.parent.token, align 32
  %3039 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3024
  %3040 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3024
  %3041 = load <8 x i1>, ptr %3039, align 1
  %3042 = load <8 x i1>, ptr %3040, align 1
  %3043 = select i1 %3017, <8 x i1> %627, <8 x i1> %3041
  store <8 x i1> %3043, ptr %3039, align 1
  %3044 = select i1 %3017, <8 x i1> zeroinitializer, <8 x i1> %3042
  store <8 x i1> %3044, ptr %3040, align 1
  %3045 = add i32 %3024, 1
  %3046 = select i1 %3015, i32 %3002, i32 %3045
  %3047 = select i1 true, i32 %3046, i32 %3002
  store i32 %3047, ptr %current.token, align 4
  %3048 = load i32, ptr %current.token, align 4
  %3049 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %634)
  %3050 = load i32, ptr %ready.count, align 4
  %3051 = icmp uge i32 %3050, 8
  %3052 = and i1 %3049, %3051
  br i1 %3052, label %ready.overflow.trap408, label %ready.overflow.resume409

ready.overflow.trap408:                           ; preds = %convergence.overflow.resume407
  call void @llvm.trap()
  unreachable

ready.overflow.resume409:                         ; preds = %convergence.overflow.resume407
  %3053 = select i1 %3049, i32 %3050, i32 0
  %3054 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3053
  %3055 = load <8 x i1>, ptr %3054, align 1
  %3056 = select i1 %3049, <8 x i1> %634, <8 x i1> %3055
  store <8 x i1> %3056, ptr %3054, align 1
  %3057 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3053
  %3058 = load i32, ptr %3057, align 4
  %3059 = select i1 %3049, i32 27, i32 %3058
  store i32 %3059, ptr %3057, align 4
  %3060 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3053
  %3061 = load i32, ptr %3060, align 4
  %3062 = select i1 %3049, i32 %3048, i32 %3061
  store i32 %3062, ptr %3060, align 4
  %3063 = add i32 %3050, 1
  %3064 = select i1 %3049, i32 %3063, i32 %3050
  store i32 %3064, ptr %ready.count, align 4
  %3065 = load <8 x i1>, ptr %runnable.mask, align 1
  %3066 = or <8 x i1> %3065, %634
  store <8 x i1> %3066, ptr %runnable.mask, align 1
  store <8 x i1> %636, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true410:                         ; preds = %varying.coherent405
  store <8 x i1> %627, ptr %current.mask, align 1
  %3067 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %627)
  br i1 %3067, label %schedule.27, label %scheduler.loop

varying.coherent.false411:                        ; preds = %varying.coherent405
  store <8 x i1> %627, ptr %current.mask, align 1
  %3068 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %627)
  br i1 %3068, label %schedule.28, label %scheduler.loop

convergence.cascade422:                           ; preds = %convergence.cascade422, %schedule.28
  %convergence.cascade.flow426 = phi <8 x i1> [ %670, %schedule.28 ], [ %3111, %convergence.cascade422 ]
  %convergence.cascade.depth427 = phi i32 [ 0, %schedule.28 ], [ %3112, %convergence.cascade422 ]
  %3069 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow426)
  %3070 = load i32, ptr %current.token, align 4
  %3071 = icmp ne i32 %3070, 0
  %3072 = and i1 %3069, %3071
  %3073 = sub i32 %3070, 1
  %3074 = select i1 %3072, i32 %3073, i32 0
  %3075 = load i8, ptr %frame.active, align 1
  %3076 = trunc i32 %3074 to i8
  %3077 = shl i8 1, %3076
  %3078 = and i8 %3075, %3077
  %3079 = icmp ne i8 %3078, 0
  %3080 = load <8 x i32>, ptr %frame.static.id, align 32
  %3081 = extractelement <8 x i32> %3080, i32 %3074
  %convergence.target.pointer428 = getelementptr inbounds [13 x i32], ptr @convergence.targets, i32 0, i32 %3081
  %convergence.dynamic.target429 = load i32, ptr %convergence.target.pointer428, align 4
  %3082 = icmp eq i32 %convergence.dynamic.target429, 28
  %3083 = and i1 %3079, %3082
  %3084 = and i1 %3072, %3083
  %3085 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3074
  %3086 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3074
  %3087 = load <8 x i1>, ptr %3085, align 1
  %3088 = load <8 x i1>, ptr %3086, align 1
  %3089 = or <8 x i1> %3088, %convergence.cascade.flow426
  %3090 = load <8 x i1>, ptr %live.mask, align 1
  %3091 = and <8 x i1> %3087, %3090
  %3092 = icmp eq <8 x i1> %3089, %3091
  %3093 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3092)
  %3094 = and i1 %3084, %3093
  %3095 = select i1 %3094, <8 x i1> zeroinitializer, <8 x i1> %3089
  %3096 = select i1 %3084, <8 x i1> %3095, <8 x i1> %3088
  store <8 x i1> %3096, ptr %3086, align 1
  %3097 = select i1 %3094, <8 x i1> zeroinitializer, <8 x i1> %3087
  store <8 x i1> %3097, ptr %3085, align 1
  %3098 = trunc i32 %3074 to i8
  %3099 = shl i8 1, %3098
  %3100 = xor i8 %3099, -1
  %3101 = and i8 %3075, %3100
  %3102 = select i1 %3094, i8 %3101, i8 %3075
  store i8 %3102, ptr %frame.active, align 1
  %.splatinsert430 = insertelement <8 x i1> poison, i1 %3084, i64 0
  %.splat431 = shufflevector <8 x i1> %.splatinsert430, <8 x i1> poison, <8 x i32> zeroinitializer
  %3103 = and <8 x i1> %convergence.cascade.flow426, %.splat431
  %3104 = load <8 x i1>, ptr %runnable.mask, align 1
  %3105 = xor <8 x i1> %3103, splat (i1 true)
  %3106 = and <8 x i1> %3104, %3105
  store <8 x i1> %3106, ptr %runnable.mask, align 1
  %.splatinsert432 = insertelement <8 x i1> poison, i1 %3094, i64 0
  %.splat433 = shufflevector <8 x i1> %.splatinsert432, <8 x i1> poison, <8 x i32> zeroinitializer
  %3107 = select <8 x i1> %.splat433, <8 x i1> %3089, <8 x i1> zeroinitializer
  %3108 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3109 = extractelement <8 x i32> %3108, i32 %3074
  %3110 = select i1 %3094, i32 %3109, i32 %3070
  store i32 %3110, ptr %current.token, align 4
  %.splatinsert434 = insertelement <8 x i1> poison, i1 %3084, i64 0
  %.splat435 = shufflevector <8 x i1> %.splatinsert434, <8 x i1> poison, <8 x i32> zeroinitializer
  %3111 = select <8 x i1> %.splat435, <8 x i1> %3107, <8 x i1> %convergence.cascade.flow426
  %3112 = add i32 %convergence.cascade.depth427, 1
  %3113 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3111)
  %3114 = icmp ult i32 %3112, 8
  %3115 = and i1 %3113, %3114
  %3116 = and i1 %3084, %3115
  %convergence.parent.token436 = load i32, ptr %current.token, align 4
  %convergence.parent.present437 = icmp ne i32 %convergence.parent.token436, 0
  %3117 = and i1 %3116, %convergence.parent.present437
  br i1 %3117, label %convergence.cascade422, label %convergence.cascade.exit423

convergence.cascade.exit423:                      ; preds = %convergence.cascade422, %schedule.28
  %convergence.cascade.result438 = phi <8 x i1> [ %670, %schedule.28 ], [ %3111, %convergence.cascade422 ]
  %3118 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result438)
  br i1 %3118, label %convergence.target.28.ready, label %scheduler.loop

convergence.target.28.ready:                      ; preds = %convergence.cascade.exit423
  %3119 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result438)
  %3120 = bitcast <8 x i1> %convergence.cascade.result438 to i8
  %3121 = call i8 @llvm.cttz.i8(i8 %3120, i1 false)
  %3122 = zext i8 %3121 to i32
  %3123 = select i1 %3119, i32 %3122, i32 0
  %.spill.load439 = load <8 x i1>, ptr %.spill11, align 1
  %3124 = and <8 x i1> %convergence.cascade.result438, %.spill.load439
  %3125 = xor <8 x i1> %.spill.load439, splat (i1 true)
  %3126 = and <8 x i1> %convergence.cascade.result438, %3125
  %3127 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3124)
  %3128 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3126)
  %3129 = and i1 %3127, %3128
  br i1 %3129, label %varying.divergent440, label %varying.coherent441

varying.divergent440:                             ; preds = %convergence.target.28.ready
  %3130 = load i32, ptr %current.token, align 4
  %3131 = icmp ne i32 %3130, 0
  %3132 = sub i32 %3130, 1
  %3133 = select i1 %3131, i32 %3132, i32 0
  %3134 = load i8, ptr %frame.active, align 1
  %3135 = trunc i32 %3133 to i8
  %3136 = shl i8 1, %3135
  %3137 = and i8 %3134, %3136
  %3138 = icmp ne i8 %3137, 0
  %3139 = load <8 x i32>, ptr %frame.static.id, align 32
  %3140 = extractelement <8 x i32> %3139, i32 %3133
  %3141 = icmp eq i32 %3140, 10
  %3142 = and i1 %3138, %3141
  %3143 = and i1 %3131, %3142
  %3144 = xor i1 %3143, true
  %3145 = and i1 true, %3144
  %3146 = xor i8 %3134, -1
  %3147 = icmp ne i8 %3146, 0
  %3148 = xor i1 %3147, true
  %3149 = and i1 %3145, %3148
  br i1 %3149, label %convergence.overflow.trap442, label %convergence.overflow.resume443

varying.coherent441:                              ; preds = %convergence.target.28.ready
  br i1 %3127, label %varying.coherent.true446, label %varying.coherent.false447

convergence.overflow.trap442:                     ; preds = %varying.divergent440
  call void @llvm.trap()
  unreachable

convergence.overflow.resume443:                   ; preds = %varying.divergent440
  %3150 = call i8 @llvm.cttz.i8(i8 %3146, i1 false)
  %3151 = zext i8 %3150 to i32
  %3152 = select i1 %3147, i32 %3151, i32 0
  %3153 = trunc i32 %3152 to i8
  %3154 = shl i8 1, %3153
  %3155 = or i8 %3134, %3154
  %3156 = select i1 %3145, i8 %3155, i8 %3134
  store i8 %3156, ptr %frame.active, align 1
  %3157 = load <8 x i32>, ptr %frame.static.id, align 32
  %3158 = extractelement <8 x i32> %3157, i32 %3152
  %3159 = select i1 %3145, i32 10, i32 %3158
  %3160 = load <8 x i32>, ptr %frame.static.id, align 32
  %3161 = insertelement <8 x i32> %3160, i32 %3159, i32 %3152
  store <8 x i32> %3161, ptr %frame.static.id, align 32
  %3162 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3163 = extractelement <8 x i32> %3162, i32 %3152
  %3164 = select i1 %3145, i32 %3130, i32 %3163
  %3165 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3166 = insertelement <8 x i32> %3165, i32 %3164, i32 %3152
  store <8 x i32> %3166, ptr %frame.parent.token, align 32
  %3167 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3152
  %3168 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3152
  %3169 = load <8 x i1>, ptr %3167, align 1
  %3170 = load <8 x i1>, ptr %3168, align 1
  %3171 = select i1 %3145, <8 x i1> %convergence.cascade.result438, <8 x i1> %3169
  store <8 x i1> %3171, ptr %3167, align 1
  %3172 = select i1 %3145, <8 x i1> zeroinitializer, <8 x i1> %3170
  store <8 x i1> %3172, ptr %3168, align 1
  %3173 = add i32 %3152, 1
  %3174 = select i1 %3143, i32 %3130, i32 %3173
  %3175 = select i1 true, i32 %3174, i32 %3130
  store i32 %3175, ptr %current.token, align 4
  %3176 = load i32, ptr %current.token, align 4
  %3177 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3124)
  %3178 = load i32, ptr %ready.count, align 4
  %3179 = icmp uge i32 %3178, 8
  %3180 = and i1 %3177, %3179
  br i1 %3180, label %ready.overflow.trap444, label %ready.overflow.resume445

ready.overflow.trap444:                           ; preds = %convergence.overflow.resume443
  call void @llvm.trap()
  unreachable

ready.overflow.resume445:                         ; preds = %convergence.overflow.resume443
  %3181 = select i1 %3177, i32 %3178, i32 0
  %3182 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3181
  %3183 = load <8 x i1>, ptr %3182, align 1
  %3184 = select i1 %3177, <8 x i1> %3124, <8 x i1> %3183
  store <8 x i1> %3184, ptr %3182, align 1
  %3185 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3181
  %3186 = load i32, ptr %3185, align 4
  %3187 = select i1 %3177, i32 29, i32 %3186
  store i32 %3187, ptr %3185, align 4
  %3188 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3181
  %3189 = load i32, ptr %3188, align 4
  %3190 = select i1 %3177, i32 %3176, i32 %3189
  store i32 %3190, ptr %3188, align 4
  %3191 = add i32 %3178, 1
  %3192 = select i1 %3177, i32 %3191, i32 %3178
  store i32 %3192, ptr %ready.count, align 4
  %3193 = load <8 x i1>, ptr %runnable.mask, align 1
  %3194 = or <8 x i1> %3193, %3124
  store <8 x i1> %3194, ptr %runnable.mask, align 1
  store <8 x i1> %3126, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true446:                         ; preds = %varying.coherent441
  store <8 x i1> %convergence.cascade.result438, ptr %current.mask, align 1
  %3195 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result438)
  br i1 %3195, label %schedule.29, label %scheduler.loop

varying.coherent.false447:                        ; preds = %varying.coherent441
  store <8 x i1> %convergence.cascade.result438, ptr %current.mask, align 1
  %3196 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result438)
  br i1 %3196, label %schedule.30, label %scheduler.loop

convergence.cascade457:                           ; preds = %convergence.cascade457, %schedule.30
  %convergence.cascade.flow461 = phi <8 x i1> [ %703, %schedule.30 ], [ %3239, %convergence.cascade457 ]
  %convergence.cascade.depth462 = phi i32 [ 0, %schedule.30 ], [ %3240, %convergence.cascade457 ]
  %3197 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow461)
  %3198 = load i32, ptr %current.token, align 4
  %3199 = icmp ne i32 %3198, 0
  %3200 = and i1 %3197, %3199
  %3201 = sub i32 %3198, 1
  %3202 = select i1 %3200, i32 %3201, i32 0
  %3203 = load i8, ptr %frame.active, align 1
  %3204 = trunc i32 %3202 to i8
  %3205 = shl i8 1, %3204
  %3206 = and i8 %3203, %3205
  %3207 = icmp ne i8 %3206, 0
  %3208 = load <8 x i32>, ptr %frame.static.id, align 32
  %3209 = extractelement <8 x i32> %3208, i32 %3202
  %convergence.target.pointer463 = getelementptr inbounds [13 x i32], ptr @convergence.targets, i32 0, i32 %3209
  %convergence.dynamic.target464 = load i32, ptr %convergence.target.pointer463, align 4
  %3210 = icmp eq i32 %convergence.dynamic.target464, 30
  %3211 = and i1 %3207, %3210
  %3212 = and i1 %3200, %3211
  %3213 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3202
  %3214 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3202
  %3215 = load <8 x i1>, ptr %3213, align 1
  %3216 = load <8 x i1>, ptr %3214, align 1
  %3217 = or <8 x i1> %3216, %convergence.cascade.flow461
  %3218 = load <8 x i1>, ptr %live.mask, align 1
  %3219 = and <8 x i1> %3215, %3218
  %3220 = icmp eq <8 x i1> %3217, %3219
  %3221 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3220)
  %3222 = and i1 %3212, %3221
  %3223 = select i1 %3222, <8 x i1> zeroinitializer, <8 x i1> %3217
  %3224 = select i1 %3212, <8 x i1> %3223, <8 x i1> %3216
  store <8 x i1> %3224, ptr %3214, align 1
  %3225 = select i1 %3222, <8 x i1> zeroinitializer, <8 x i1> %3215
  store <8 x i1> %3225, ptr %3213, align 1
  %3226 = trunc i32 %3202 to i8
  %3227 = shl i8 1, %3226
  %3228 = xor i8 %3227, -1
  %3229 = and i8 %3203, %3228
  %3230 = select i1 %3222, i8 %3229, i8 %3203
  store i8 %3230, ptr %frame.active, align 1
  %.splatinsert465 = insertelement <8 x i1> poison, i1 %3212, i64 0
  %.splat466 = shufflevector <8 x i1> %.splatinsert465, <8 x i1> poison, <8 x i32> zeroinitializer
  %3231 = and <8 x i1> %convergence.cascade.flow461, %.splat466
  %3232 = load <8 x i1>, ptr %runnable.mask, align 1
  %3233 = xor <8 x i1> %3231, splat (i1 true)
  %3234 = and <8 x i1> %3232, %3233
  store <8 x i1> %3234, ptr %runnable.mask, align 1
  %.splatinsert467 = insertelement <8 x i1> poison, i1 %3222, i64 0
  %.splat468 = shufflevector <8 x i1> %.splatinsert467, <8 x i1> poison, <8 x i32> zeroinitializer
  %3235 = select <8 x i1> %.splat468, <8 x i1> %3217, <8 x i1> zeroinitializer
  %3236 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3237 = extractelement <8 x i32> %3236, i32 %3202
  %3238 = select i1 %3222, i32 %3237, i32 %3198
  store i32 %3238, ptr %current.token, align 4
  %.splatinsert469 = insertelement <8 x i1> poison, i1 %3212, i64 0
  %.splat470 = shufflevector <8 x i1> %.splatinsert469, <8 x i1> poison, <8 x i32> zeroinitializer
  %3239 = select <8 x i1> %.splat470, <8 x i1> %3235, <8 x i1> %convergence.cascade.flow461
  %3240 = add i32 %convergence.cascade.depth462, 1
  %3241 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3239)
  %3242 = icmp ult i32 %3240, 8
  %3243 = and i1 %3241, %3242
  %3244 = and i1 %3212, %3243
  %convergence.parent.token471 = load i32, ptr %current.token, align 4
  %convergence.parent.present472 = icmp ne i32 %convergence.parent.token471, 0
  %3245 = and i1 %3244, %convergence.parent.present472
  br i1 %3245, label %convergence.cascade457, label %convergence.cascade.exit458

convergence.cascade.exit458:                      ; preds = %convergence.cascade457, %schedule.30
  %convergence.cascade.result473 = phi <8 x i1> [ %703, %schedule.30 ], [ %3239, %convergence.cascade457 ]
  %3246 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result473)
  br i1 %3246, label %convergence.target.30.ready, label %scheduler.loop

convergence.target.30.ready:                      ; preds = %convergence.cascade.exit458
  %3247 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result473)
  %3248 = bitcast <8 x i1> %convergence.cascade.result473 to i8
  %3249 = call i8 @llvm.cttz.i8(i8 %3248, i1 false)
  %3250 = zext i8 %3249 to i32
  %3251 = select i1 %3247, i32 %3250, i32 0
  %3252 = load <8 x i64>, ptr %.slot39, align 64
  %3253 = select <8 x i1> %convergence.cascade.result473, <8 x i64> zeroinitializer, <8 x i64> %3252
  store <8 x i64> %3253, ptr %.slot39, align 64
  store <8 x i1> %convergence.cascade.result473, ptr %current.mask, align 1
  %3254 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result473)
  br i1 %3254, label %schedule.31, label %scheduler.loop

varying.divergent475:                             ; preds = %schedule.31
  %3255 = load i32, ptr %current.token, align 4
  %3256 = icmp ne i32 %3255, 0
  %3257 = sub i32 %3255, 1
  %3258 = select i1 %3256, i32 %3257, i32 0
  %3259 = load i8, ptr %frame.active, align 1
  %3260 = trunc i32 %3258 to i8
  %3261 = shl i8 1, %3260
  %3262 = and i8 %3259, %3261
  %3263 = icmp ne i8 %3262, 0
  %3264 = load <8 x i32>, ptr %frame.static.id, align 32
  %3265 = extractelement <8 x i32> %3264, i32 %3258
  %3266 = icmp eq i32 %3265, 11
  %3267 = and i1 %3263, %3266
  %3268 = and i1 %3256, %3267
  %3269 = xor i1 %3268, true
  %3270 = and i1 true, %3269
  %3271 = xor i8 %3259, -1
  %3272 = icmp ne i8 %3271, 0
  %3273 = xor i1 %3272, true
  %3274 = and i1 %3270, %3273
  br i1 %3274, label %convergence.overflow.trap477, label %convergence.overflow.resume478

varying.coherent476:                              ; preds = %schedule.31
  br i1 %714, label %varying.coherent.true481, label %varying.coherent.false482

convergence.overflow.trap477:                     ; preds = %varying.divergent475
  call void @llvm.trap()
  unreachable

convergence.overflow.resume478:                   ; preds = %varying.divergent475
  %3275 = call i8 @llvm.cttz.i8(i8 %3271, i1 false)
  %3276 = zext i8 %3275 to i32
  %3277 = select i1 %3272, i32 %3276, i32 0
  %3278 = trunc i32 %3277 to i8
  %3279 = shl i8 1, %3278
  %3280 = or i8 %3259, %3279
  %3281 = select i1 %3270, i8 %3280, i8 %3259
  store i8 %3281, ptr %frame.active, align 1
  %3282 = load <8 x i32>, ptr %frame.static.id, align 32
  %3283 = extractelement <8 x i32> %3282, i32 %3277
  %3284 = select i1 %3270, i32 11, i32 %3283
  %3285 = load <8 x i32>, ptr %frame.static.id, align 32
  %3286 = insertelement <8 x i32> %3285, i32 %3284, i32 %3277
  store <8 x i32> %3286, ptr %frame.static.id, align 32
  %3287 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3288 = extractelement <8 x i32> %3287, i32 %3277
  %3289 = select i1 %3270, i32 %3255, i32 %3288
  %3290 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3291 = insertelement <8 x i32> %3290, i32 %3289, i32 %3277
  store <8 x i32> %3291, ptr %frame.parent.token, align 32
  %3292 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3277
  %3293 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3277
  %3294 = load <8 x i1>, ptr %3292, align 1
  %3295 = load <8 x i1>, ptr %3293, align 1
  %3296 = select i1 %3270, <8 x i1> %704, <8 x i1> %3294
  store <8 x i1> %3296, ptr %3292, align 1
  %3297 = select i1 %3270, <8 x i1> zeroinitializer, <8 x i1> %3295
  store <8 x i1> %3297, ptr %3293, align 1
  %3298 = add i32 %3277, 1
  %3299 = select i1 %3268, i32 %3255, i32 %3298
  %3300 = select i1 true, i32 %3299, i32 %3255
  store i32 %3300, ptr %current.token, align 4
  %3301 = load i32, ptr %current.token, align 4
  %3302 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %711)
  %3303 = load i32, ptr %ready.count, align 4
  %3304 = icmp uge i32 %3303, 8
  %3305 = and i1 %3302, %3304
  br i1 %3305, label %ready.overflow.trap479, label %ready.overflow.resume480

ready.overflow.trap479:                           ; preds = %convergence.overflow.resume478
  call void @llvm.trap()
  unreachable

ready.overflow.resume480:                         ; preds = %convergence.overflow.resume478
  %3306 = select i1 %3302, i32 %3303, i32 0
  %3307 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3306
  %3308 = load <8 x i1>, ptr %3307, align 1
  %3309 = select i1 %3302, <8 x i1> %711, <8 x i1> %3308
  store <8 x i1> %3309, ptr %3307, align 1
  %3310 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3306
  %3311 = load i32, ptr %3310, align 4
  %3312 = select i1 %3302, i32 32, i32 %3311
  store i32 %3312, ptr %3310, align 4
  %3313 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3306
  %3314 = load i32, ptr %3313, align 4
  %3315 = select i1 %3302, i32 %3301, i32 %3314
  store i32 %3315, ptr %3313, align 4
  %3316 = add i32 %3303, 1
  %3317 = select i1 %3302, i32 %3316, i32 %3303
  store i32 %3317, ptr %ready.count, align 4
  %3318 = load <8 x i1>, ptr %runnable.mask, align 1
  %3319 = or <8 x i1> %3318, %711
  store <8 x i1> %3319, ptr %runnable.mask, align 1
  store <8 x i1> %713, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true481:                         ; preds = %varying.coherent476
  store <8 x i1> %704, ptr %current.mask, align 1
  %3320 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %704)
  br i1 %3320, label %schedule.32, label %scheduler.loop

varying.coherent.false482:                        ; preds = %varying.coherent476
  store <8 x i1> %704, ptr %current.mask, align 1
  %3321 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %704)
  br i1 %3321, label %schedule.33, label %scheduler.loop

convergence.cascade497:                           ; preds = %convergence.cascade497, %schedule.33
  %convergence.cascade.flow501 = phi <8 x i1> [ %778, %schedule.33 ], [ %3364, %convergence.cascade497 ]
  %convergence.cascade.depth502 = phi i32 [ 0, %schedule.33 ], [ %3365, %convergence.cascade497 ]
  %3322 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow501)
  %3323 = load i32, ptr %current.token, align 4
  %3324 = icmp ne i32 %3323, 0
  %3325 = and i1 %3322, %3324
  %3326 = sub i32 %3323, 1
  %3327 = select i1 %3325, i32 %3326, i32 0
  %3328 = load i8, ptr %frame.active, align 1
  %3329 = trunc i32 %3327 to i8
  %3330 = shl i8 1, %3329
  %3331 = and i8 %3328, %3330
  %3332 = icmp ne i8 %3331, 0
  %3333 = load <8 x i32>, ptr %frame.static.id, align 32
  %3334 = extractelement <8 x i32> %3333, i32 %3327
  %convergence.target.pointer503 = getelementptr inbounds [13 x i32], ptr @convergence.targets, i32 0, i32 %3334
  %convergence.dynamic.target504 = load i32, ptr %convergence.target.pointer503, align 4
  %3335 = icmp eq i32 %convergence.dynamic.target504, 33
  %3336 = and i1 %3332, %3335
  %3337 = and i1 %3325, %3336
  %3338 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3327
  %3339 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3327
  %3340 = load <8 x i1>, ptr %3338, align 1
  %3341 = load <8 x i1>, ptr %3339, align 1
  %3342 = or <8 x i1> %3341, %convergence.cascade.flow501
  %3343 = load <8 x i1>, ptr %live.mask, align 1
  %3344 = and <8 x i1> %3340, %3343
  %3345 = icmp eq <8 x i1> %3342, %3344
  %3346 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3345)
  %3347 = and i1 %3337, %3346
  %3348 = select i1 %3347, <8 x i1> zeroinitializer, <8 x i1> %3342
  %3349 = select i1 %3337, <8 x i1> %3348, <8 x i1> %3341
  store <8 x i1> %3349, ptr %3339, align 1
  %3350 = select i1 %3347, <8 x i1> zeroinitializer, <8 x i1> %3340
  store <8 x i1> %3350, ptr %3338, align 1
  %3351 = trunc i32 %3327 to i8
  %3352 = shl i8 1, %3351
  %3353 = xor i8 %3352, -1
  %3354 = and i8 %3328, %3353
  %3355 = select i1 %3347, i8 %3354, i8 %3328
  store i8 %3355, ptr %frame.active, align 1
  %.splatinsert505 = insertelement <8 x i1> poison, i1 %3337, i64 0
  %.splat506 = shufflevector <8 x i1> %.splatinsert505, <8 x i1> poison, <8 x i32> zeroinitializer
  %3356 = and <8 x i1> %convergence.cascade.flow501, %.splat506
  %3357 = load <8 x i1>, ptr %runnable.mask, align 1
  %3358 = xor <8 x i1> %3356, splat (i1 true)
  %3359 = and <8 x i1> %3357, %3358
  store <8 x i1> %3359, ptr %runnable.mask, align 1
  %.splatinsert507 = insertelement <8 x i1> poison, i1 %3347, i64 0
  %.splat508 = shufflevector <8 x i1> %.splatinsert507, <8 x i1> poison, <8 x i32> zeroinitializer
  %3360 = select <8 x i1> %.splat508, <8 x i1> %3342, <8 x i1> zeroinitializer
  %3361 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3362 = extractelement <8 x i32> %3361, i32 %3327
  %3363 = select i1 %3347, i32 %3362, i32 %3323
  store i32 %3363, ptr %current.token, align 4
  %.splatinsert509 = insertelement <8 x i1> poison, i1 %3337, i64 0
  %.splat510 = shufflevector <8 x i1> %.splatinsert509, <8 x i1> poison, <8 x i32> zeroinitializer
  %3364 = select <8 x i1> %.splat510, <8 x i1> %3360, <8 x i1> %convergence.cascade.flow501
  %3365 = add i32 %convergence.cascade.depth502, 1
  %3366 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3364)
  %3367 = icmp ult i32 %3365, 8
  %3368 = and i1 %3366, %3367
  %3369 = and i1 %3337, %3368
  %convergence.parent.token511 = load i32, ptr %current.token, align 4
  %convergence.parent.present512 = icmp ne i32 %convergence.parent.token511, 0
  %3370 = and i1 %3369, %convergence.parent.present512
  br i1 %3370, label %convergence.cascade497, label %convergence.cascade.exit498

convergence.cascade.exit498:                      ; preds = %convergence.cascade497, %schedule.33
  %convergence.cascade.result513 = phi <8 x i1> [ %778, %schedule.33 ], [ %3364, %convergence.cascade497 ]
  %3371 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result513)
  br i1 %3371, label %convergence.target.33.ready, label %scheduler.loop

convergence.target.33.ready:                      ; preds = %convergence.cascade.exit498
  %3372 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result513)
  %3373 = bitcast <8 x i1> %convergence.cascade.result513 to i8
  %3374 = call i8 @llvm.cttz.i8(i8 %3373, i1 false)
  %3375 = zext i8 %3374 to i32
  %3376 = select i1 %3372, i32 %3375, i32 0
  %.spill.load514 = load <8 x i1>, ptr %.spill11, align 1
  %3377 = and <8 x i1> %convergence.cascade.result513, %.spill.load514
  %3378 = xor <8 x i1> %.spill.load514, splat (i1 true)
  %3379 = and <8 x i1> %convergence.cascade.result513, %3378
  %3380 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3377)
  %3381 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3379)
  %3382 = and i1 %3380, %3381
  br i1 %3382, label %varying.divergent515, label %varying.coherent516

varying.divergent515:                             ; preds = %convergence.target.33.ready
  %3383 = load i32, ptr %current.token, align 4
  %3384 = icmp ne i32 %3383, 0
  %3385 = sub i32 %3383, 1
  %3386 = select i1 %3384, i32 %3385, i32 0
  %3387 = load i8, ptr %frame.active, align 1
  %3388 = trunc i32 %3386 to i8
  %3389 = shl i8 1, %3388
  %3390 = and i8 %3387, %3389
  %3391 = icmp ne i8 %3390, 0
  %3392 = load <8 x i32>, ptr %frame.static.id, align 32
  %3393 = extractelement <8 x i32> %3392, i32 %3386
  %3394 = icmp eq i32 %3393, 12
  %3395 = and i1 %3391, %3394
  %3396 = and i1 %3384, %3395
  %3397 = xor i1 %3396, true
  %3398 = and i1 true, %3397
  %3399 = xor i8 %3387, -1
  %3400 = icmp ne i8 %3399, 0
  %3401 = xor i1 %3400, true
  %3402 = and i1 %3398, %3401
  br i1 %3402, label %convergence.overflow.trap517, label %convergence.overflow.resume518

varying.coherent516:                              ; preds = %convergence.target.33.ready
  br i1 %3380, label %varying.coherent.true521, label %varying.coherent.false522

convergence.overflow.trap517:                     ; preds = %varying.divergent515
  call void @llvm.trap()
  unreachable

convergence.overflow.resume518:                   ; preds = %varying.divergent515
  %3403 = call i8 @llvm.cttz.i8(i8 %3399, i1 false)
  %3404 = zext i8 %3403 to i32
  %3405 = select i1 %3400, i32 %3404, i32 0
  %3406 = trunc i32 %3405 to i8
  %3407 = shl i8 1, %3406
  %3408 = or i8 %3387, %3407
  %3409 = select i1 %3398, i8 %3408, i8 %3387
  store i8 %3409, ptr %frame.active, align 1
  %3410 = load <8 x i32>, ptr %frame.static.id, align 32
  %3411 = extractelement <8 x i32> %3410, i32 %3405
  %3412 = select i1 %3398, i32 12, i32 %3411
  %3413 = load <8 x i32>, ptr %frame.static.id, align 32
  %3414 = insertelement <8 x i32> %3413, i32 %3412, i32 %3405
  store <8 x i32> %3414, ptr %frame.static.id, align 32
  %3415 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3416 = extractelement <8 x i32> %3415, i32 %3405
  %3417 = select i1 %3398, i32 %3383, i32 %3416
  %3418 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3419 = insertelement <8 x i32> %3418, i32 %3417, i32 %3405
  store <8 x i32> %3419, ptr %frame.parent.token, align 32
  %3420 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3405
  %3421 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3405
  %3422 = load <8 x i1>, ptr %3420, align 1
  %3423 = load <8 x i1>, ptr %3421, align 1
  %3424 = select i1 %3398, <8 x i1> %convergence.cascade.result513, <8 x i1> %3422
  store <8 x i1> %3424, ptr %3420, align 1
  %3425 = select i1 %3398, <8 x i1> zeroinitializer, <8 x i1> %3423
  store <8 x i1> %3425, ptr %3421, align 1
  %3426 = add i32 %3405, 1
  %3427 = select i1 %3396, i32 %3383, i32 %3426
  %3428 = select i1 true, i32 %3427, i32 %3383
  store i32 %3428, ptr %current.token, align 4
  %3429 = load i32, ptr %current.token, align 4
  %3430 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3377)
  %3431 = load i32, ptr %ready.count, align 4
  %3432 = icmp uge i32 %3431, 8
  %3433 = and i1 %3430, %3432
  br i1 %3433, label %ready.overflow.trap519, label %ready.overflow.resume520

ready.overflow.trap519:                           ; preds = %convergence.overflow.resume518
  call void @llvm.trap()
  unreachable

ready.overflow.resume520:                         ; preds = %convergence.overflow.resume518
  %3434 = select i1 %3430, i32 %3431, i32 0
  %3435 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3434
  %3436 = load <8 x i1>, ptr %3435, align 1
  %3437 = select i1 %3430, <8 x i1> %3377, <8 x i1> %3436
  store <8 x i1> %3437, ptr %3435, align 1
  %3438 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3434
  %3439 = load i32, ptr %3438, align 4
  %3440 = select i1 %3430, i32 34, i32 %3439
  store i32 %3440, ptr %3438, align 4
  %3441 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3434
  %3442 = load i32, ptr %3441, align 4
  %3443 = select i1 %3430, i32 %3429, i32 %3442
  store i32 %3443, ptr %3441, align 4
  %3444 = add i32 %3431, 1
  %3445 = select i1 %3430, i32 %3444, i32 %3431
  store i32 %3445, ptr %ready.count, align 4
  %3446 = load <8 x i1>, ptr %runnable.mask, align 1
  %3447 = or <8 x i1> %3446, %3377
  store <8 x i1> %3447, ptr %runnable.mask, align 1
  store <8 x i1> %3379, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true521:                         ; preds = %varying.coherent516
  store <8 x i1> %convergence.cascade.result513, ptr %current.mask, align 1
  %3448 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result513)
  br i1 %3448, label %schedule.34, label %scheduler.loop

varying.coherent.false522:                        ; preds = %varying.coherent516
  store <8 x i1> %convergence.cascade.result513, ptr %current.mask, align 1
  %3449 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result513)
  br i1 %3449, label %schedule.35, label %scheduler.loop

convergence.cascade538:                           ; preds = %convergence.cascade538, %schedule.35
  %convergence.cascade.flow542 = phi <8 x i1> [ %851, %schedule.35 ], [ %3492, %convergence.cascade538 ]
  %convergence.cascade.depth543 = phi i32 [ 0, %schedule.35 ], [ %3493, %convergence.cascade538 ]
  %3450 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow542)
  %3451 = load i32, ptr %current.token, align 4
  %3452 = icmp ne i32 %3451, 0
  %3453 = and i1 %3450, %3452
  %3454 = sub i32 %3451, 1
  %3455 = select i1 %3453, i32 %3454, i32 0
  %3456 = load i8, ptr %frame.active, align 1
  %3457 = trunc i32 %3455 to i8
  %3458 = shl i8 1, %3457
  %3459 = and i8 %3456, %3458
  %3460 = icmp ne i8 %3459, 0
  %3461 = load <8 x i32>, ptr %frame.static.id, align 32
  %3462 = extractelement <8 x i32> %3461, i32 %3455
  %convergence.target.pointer544 = getelementptr inbounds [13 x i32], ptr @convergence.targets, i32 0, i32 %3462
  %convergence.dynamic.target545 = load i32, ptr %convergence.target.pointer544, align 4
  %3463 = icmp eq i32 %convergence.dynamic.target545, 35
  %3464 = and i1 %3460, %3463
  %3465 = and i1 %3453, %3464
  %3466 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3455
  %3467 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3455
  %3468 = load <8 x i1>, ptr %3466, align 1
  %3469 = load <8 x i1>, ptr %3467, align 1
  %3470 = or <8 x i1> %3469, %convergence.cascade.flow542
  %3471 = load <8 x i1>, ptr %live.mask, align 1
  %3472 = and <8 x i1> %3468, %3471
  %3473 = icmp eq <8 x i1> %3470, %3472
  %3474 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3473)
  %3475 = and i1 %3465, %3474
  %3476 = select i1 %3475, <8 x i1> zeroinitializer, <8 x i1> %3470
  %3477 = select i1 %3465, <8 x i1> %3476, <8 x i1> %3469
  store <8 x i1> %3477, ptr %3467, align 1
  %3478 = select i1 %3475, <8 x i1> zeroinitializer, <8 x i1> %3468
  store <8 x i1> %3478, ptr %3466, align 1
  %3479 = trunc i32 %3455 to i8
  %3480 = shl i8 1, %3479
  %3481 = xor i8 %3480, -1
  %3482 = and i8 %3456, %3481
  %3483 = select i1 %3475, i8 %3482, i8 %3456
  store i8 %3483, ptr %frame.active, align 1
  %.splatinsert546 = insertelement <8 x i1> poison, i1 %3465, i64 0
  %.splat547 = shufflevector <8 x i1> %.splatinsert546, <8 x i1> poison, <8 x i32> zeroinitializer
  %3484 = and <8 x i1> %convergence.cascade.flow542, %.splat547
  %3485 = load <8 x i1>, ptr %runnable.mask, align 1
  %3486 = xor <8 x i1> %3484, splat (i1 true)
  %3487 = and <8 x i1> %3485, %3486
  store <8 x i1> %3487, ptr %runnable.mask, align 1
  %.splatinsert548 = insertelement <8 x i1> poison, i1 %3475, i64 0
  %.splat549 = shufflevector <8 x i1> %.splatinsert548, <8 x i1> poison, <8 x i32> zeroinitializer
  %3488 = select <8 x i1> %.splat549, <8 x i1> %3470, <8 x i1> zeroinitializer
  %3489 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3490 = extractelement <8 x i32> %3489, i32 %3455
  %3491 = select i1 %3475, i32 %3490, i32 %3451
  store i32 %3491, ptr %current.token, align 4
  %.splatinsert550 = insertelement <8 x i1> poison, i1 %3465, i64 0
  %.splat551 = shufflevector <8 x i1> %.splatinsert550, <8 x i1> poison, <8 x i32> zeroinitializer
  %3492 = select <8 x i1> %.splat551, <8 x i1> %3488, <8 x i1> %convergence.cascade.flow542
  %3493 = add i32 %convergence.cascade.depth543, 1
  %3494 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3492)
  %3495 = icmp ult i32 %3493, 8
  %3496 = and i1 %3494, %3495
  %3497 = and i1 %3465, %3496
  %convergence.parent.token552 = load i32, ptr %current.token, align 4
  %convergence.parent.present553 = icmp ne i32 %convergence.parent.token552, 0
  %3498 = and i1 %3497, %convergence.parent.present553
  br i1 %3498, label %convergence.cascade538, label %convergence.cascade.exit539

convergence.cascade.exit539:                      ; preds = %convergence.cascade538, %schedule.35
  %convergence.cascade.result554 = phi <8 x i1> [ %851, %schedule.35 ], [ %3492, %convergence.cascade538 ]
  %3499 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result554)
  br i1 %3499, label %convergence.target.35.ready, label %scheduler.loop

convergence.target.35.ready:                      ; preds = %convergence.cascade.exit539
  %3500 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result554)
  %3501 = bitcast <8 x i1> %convergence.cascade.result554 to i8
  %3502 = call i8 @llvm.cttz.i8(i8 %3501, i1 false)
  %3503 = zext i8 %3502 to i32
  %3504 = select i1 %3500, i32 %3503, i32 0
  %3505 = load <8 x i1>, ptr %live.mask, align 1
  %3506 = xor <8 x i1> %convergence.cascade.result554, splat (i1 true)
  %3507 = and <8 x i1> %3505, %3506
  store <8 x i1> %3507, ptr %live.mask, align 1
  %3508 = load <8 x i1>, ptr %runnable.mask, align 1
  %3509 = xor <8 x i1> %convergence.cascade.result554, splat (i1 true)
  %3510 = and <8 x i1> %3508, %3509
  store <8 x i1> %3510, ptr %runnable.mask, align 1
  %return.active.frames = load i8, ptr %frame.active, align 1
  %return.frames.present = icmp ne i8 %return.active.frames, 0
  br i1 %return.frames.present, label %return.frame.cleanup, label %return.frame.cleanup.done

return.frame.cleanup:                             ; preds = %convergence.target.35.ready
  %3511 = load i8, ptr %frame.active, align 1
  %3512 = and i8 %3511, 1
  %3513 = icmp ne i8 %3512, 0
  %3514 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 0
  %3515 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 0
  %3516 = load <8 x i1>, ptr %3514, align 1
  %3517 = load <8 x i1>, ptr %3515, align 1
  %3518 = and <8 x i1> %3516, %3507
  %3519 = icmp eq <8 x i1> %3517, %3518
  %3520 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3519)
  %3521 = and i1 %3513, %3520
  %.splatinsert555 = insertelement <8 x i1> poison, i1 %3521, i64 0
  %.splat556 = shufflevector <8 x i1> %.splatinsert555, <8 x i1> poison, <8 x i32> zeroinitializer
  %3522 = select <8 x i1> %.splat556, <8 x i1> %3517, <8 x i1> zeroinitializer
  %3523 = select i1 %3521, <8 x i1> zeroinitializer, <8 x i1> %3518
  store <8 x i1> %3523, ptr %3514, align 1
  %3524 = select i1 %3521, <8 x i1> zeroinitializer, <8 x i1> %3517
  store <8 x i1> %3524, ptr %3515, align 1
  %3525 = and i8 %3511, -2
  %3526 = select i1 %3521, i8 %3525, i8 %3511
  store i8 %3526, ptr %frame.active, align 1
  %3527 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3528 = extractelement <8 x i32> %3527, i32 0
  %3529 = load <8 x i32>, ptr %frame.static.id, align 32
  %3530 = extractelement <8 x i32> %3529, i32 0
  %convergence.target.pointer557 = getelementptr inbounds [13 x i32], ptr @convergence.targets, i32 0, i32 %3530
  %convergence.dynamic.target558 = load i32, ptr %convergence.target.pointer557, align 4
  %3531 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3522)
  %3532 = load i32, ptr %ready.count, align 4
  %3533 = icmp uge i32 %3532, 8
  %3534 = and i1 %3531, %3533
  br i1 %3534, label %ready.overflow.trap559, label %ready.overflow.resume560

return.frame.cleanup.done:                        ; preds = %ready.overflow.resume602, %convergence.target.35.ready
  br label %scheduler.loop

ready.overflow.trap559:                           ; preds = %return.frame.cleanup
  call void @llvm.trap()
  unreachable

ready.overflow.resume560:                         ; preds = %return.frame.cleanup
  %3535 = select i1 %3531, i32 %3532, i32 0
  %3536 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3535
  %3537 = load <8 x i1>, ptr %3536, align 1
  %3538 = select i1 %3531, <8 x i1> %3522, <8 x i1> %3537
  store <8 x i1> %3538, ptr %3536, align 1
  %3539 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3535
  %3540 = load i32, ptr %3539, align 4
  %3541 = select i1 %3531, i32 %convergence.dynamic.target558, i32 %3540
  store i32 %3541, ptr %3539, align 4
  %3542 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3535
  %3543 = load i32, ptr %3542, align 4
  %3544 = select i1 %3531, i32 %3528, i32 %3543
  store i32 %3544, ptr %3542, align 4
  %3545 = add i32 %3532, 1
  %3546 = select i1 %3531, i32 %3545, i32 %3532
  store i32 %3546, ptr %ready.count, align 4
  %3547 = load <8 x i1>, ptr %runnable.mask, align 1
  %3548 = or <8 x i1> %3547, %3522
  store <8 x i1> %3548, ptr %runnable.mask, align 1
  %3549 = load i8, ptr %frame.active, align 1
  %3550 = and i8 %3549, 2
  %3551 = icmp ne i8 %3550, 0
  %3552 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 1
  %3553 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 1
  %3554 = load <8 x i1>, ptr %3552, align 1
  %3555 = load <8 x i1>, ptr %3553, align 1
  %3556 = and <8 x i1> %3554, %3507
  %3557 = icmp eq <8 x i1> %3555, %3556
  %3558 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3557)
  %3559 = and i1 %3551, %3558
  %.splatinsert561 = insertelement <8 x i1> poison, i1 %3559, i64 0
  %.splat562 = shufflevector <8 x i1> %.splatinsert561, <8 x i1> poison, <8 x i32> zeroinitializer
  %3560 = select <8 x i1> %.splat562, <8 x i1> %3555, <8 x i1> zeroinitializer
  %3561 = select i1 %3559, <8 x i1> zeroinitializer, <8 x i1> %3556
  store <8 x i1> %3561, ptr %3552, align 1
  %3562 = select i1 %3559, <8 x i1> zeroinitializer, <8 x i1> %3555
  store <8 x i1> %3562, ptr %3553, align 1
  %3563 = and i8 %3549, -3
  %3564 = select i1 %3559, i8 %3563, i8 %3549
  store i8 %3564, ptr %frame.active, align 1
  %3565 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3566 = extractelement <8 x i32> %3565, i32 1
  %3567 = load <8 x i32>, ptr %frame.static.id, align 32
  %3568 = extractelement <8 x i32> %3567, i32 1
  %convergence.target.pointer563 = getelementptr inbounds [13 x i32], ptr @convergence.targets, i32 0, i32 %3568
  %convergence.dynamic.target564 = load i32, ptr %convergence.target.pointer563, align 4
  %3569 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3560)
  %3570 = load i32, ptr %ready.count, align 4
  %3571 = icmp uge i32 %3570, 8
  %3572 = and i1 %3569, %3571
  br i1 %3572, label %ready.overflow.trap565, label %ready.overflow.resume566

ready.overflow.trap565:                           ; preds = %ready.overflow.resume560
  call void @llvm.trap()
  unreachable

ready.overflow.resume566:                         ; preds = %ready.overflow.resume560
  %3573 = select i1 %3569, i32 %3570, i32 0
  %3574 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3573
  %3575 = load <8 x i1>, ptr %3574, align 1
  %3576 = select i1 %3569, <8 x i1> %3560, <8 x i1> %3575
  store <8 x i1> %3576, ptr %3574, align 1
  %3577 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3573
  %3578 = load i32, ptr %3577, align 4
  %3579 = select i1 %3569, i32 %convergence.dynamic.target564, i32 %3578
  store i32 %3579, ptr %3577, align 4
  %3580 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3573
  %3581 = load i32, ptr %3580, align 4
  %3582 = select i1 %3569, i32 %3566, i32 %3581
  store i32 %3582, ptr %3580, align 4
  %3583 = add i32 %3570, 1
  %3584 = select i1 %3569, i32 %3583, i32 %3570
  store i32 %3584, ptr %ready.count, align 4
  %3585 = load <8 x i1>, ptr %runnable.mask, align 1
  %3586 = or <8 x i1> %3585, %3560
  store <8 x i1> %3586, ptr %runnable.mask, align 1
  %3587 = load i8, ptr %frame.active, align 1
  %3588 = and i8 %3587, 4
  %3589 = icmp ne i8 %3588, 0
  %3590 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 2
  %3591 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 2
  %3592 = load <8 x i1>, ptr %3590, align 1
  %3593 = load <8 x i1>, ptr %3591, align 1
  %3594 = and <8 x i1> %3592, %3507
  %3595 = icmp eq <8 x i1> %3593, %3594
  %3596 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3595)
  %3597 = and i1 %3589, %3596
  %.splatinsert567 = insertelement <8 x i1> poison, i1 %3597, i64 0
  %.splat568 = shufflevector <8 x i1> %.splatinsert567, <8 x i1> poison, <8 x i32> zeroinitializer
  %3598 = select <8 x i1> %.splat568, <8 x i1> %3593, <8 x i1> zeroinitializer
  %3599 = select i1 %3597, <8 x i1> zeroinitializer, <8 x i1> %3594
  store <8 x i1> %3599, ptr %3590, align 1
  %3600 = select i1 %3597, <8 x i1> zeroinitializer, <8 x i1> %3593
  store <8 x i1> %3600, ptr %3591, align 1
  %3601 = and i8 %3587, -5
  %3602 = select i1 %3597, i8 %3601, i8 %3587
  store i8 %3602, ptr %frame.active, align 1
  %3603 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3604 = extractelement <8 x i32> %3603, i32 2
  %3605 = load <8 x i32>, ptr %frame.static.id, align 32
  %3606 = extractelement <8 x i32> %3605, i32 2
  %convergence.target.pointer569 = getelementptr inbounds [13 x i32], ptr @convergence.targets, i32 0, i32 %3606
  %convergence.dynamic.target570 = load i32, ptr %convergence.target.pointer569, align 4
  %3607 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3598)
  %3608 = load i32, ptr %ready.count, align 4
  %3609 = icmp uge i32 %3608, 8
  %3610 = and i1 %3607, %3609
  br i1 %3610, label %ready.overflow.trap571, label %ready.overflow.resume572

ready.overflow.trap571:                           ; preds = %ready.overflow.resume566
  call void @llvm.trap()
  unreachable

ready.overflow.resume572:                         ; preds = %ready.overflow.resume566
  %3611 = select i1 %3607, i32 %3608, i32 0
  %3612 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3611
  %3613 = load <8 x i1>, ptr %3612, align 1
  %3614 = select i1 %3607, <8 x i1> %3598, <8 x i1> %3613
  store <8 x i1> %3614, ptr %3612, align 1
  %3615 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3611
  %3616 = load i32, ptr %3615, align 4
  %3617 = select i1 %3607, i32 %convergence.dynamic.target570, i32 %3616
  store i32 %3617, ptr %3615, align 4
  %3618 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3611
  %3619 = load i32, ptr %3618, align 4
  %3620 = select i1 %3607, i32 %3604, i32 %3619
  store i32 %3620, ptr %3618, align 4
  %3621 = add i32 %3608, 1
  %3622 = select i1 %3607, i32 %3621, i32 %3608
  store i32 %3622, ptr %ready.count, align 4
  %3623 = load <8 x i1>, ptr %runnable.mask, align 1
  %3624 = or <8 x i1> %3623, %3598
  store <8 x i1> %3624, ptr %runnable.mask, align 1
  %3625 = load i8, ptr %frame.active, align 1
  %3626 = and i8 %3625, 8
  %3627 = icmp ne i8 %3626, 0
  %3628 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 3
  %3629 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 3
  %3630 = load <8 x i1>, ptr %3628, align 1
  %3631 = load <8 x i1>, ptr %3629, align 1
  %3632 = and <8 x i1> %3630, %3507
  %3633 = icmp eq <8 x i1> %3631, %3632
  %3634 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3633)
  %3635 = and i1 %3627, %3634
  %.splatinsert573 = insertelement <8 x i1> poison, i1 %3635, i64 0
  %.splat574 = shufflevector <8 x i1> %.splatinsert573, <8 x i1> poison, <8 x i32> zeroinitializer
  %3636 = select <8 x i1> %.splat574, <8 x i1> %3631, <8 x i1> zeroinitializer
  %3637 = select i1 %3635, <8 x i1> zeroinitializer, <8 x i1> %3632
  store <8 x i1> %3637, ptr %3628, align 1
  %3638 = select i1 %3635, <8 x i1> zeroinitializer, <8 x i1> %3631
  store <8 x i1> %3638, ptr %3629, align 1
  %3639 = and i8 %3625, -9
  %3640 = select i1 %3635, i8 %3639, i8 %3625
  store i8 %3640, ptr %frame.active, align 1
  %3641 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3642 = extractelement <8 x i32> %3641, i32 3
  %3643 = load <8 x i32>, ptr %frame.static.id, align 32
  %3644 = extractelement <8 x i32> %3643, i32 3
  %convergence.target.pointer575 = getelementptr inbounds [13 x i32], ptr @convergence.targets, i32 0, i32 %3644
  %convergence.dynamic.target576 = load i32, ptr %convergence.target.pointer575, align 4
  %3645 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3636)
  %3646 = load i32, ptr %ready.count, align 4
  %3647 = icmp uge i32 %3646, 8
  %3648 = and i1 %3645, %3647
  br i1 %3648, label %ready.overflow.trap577, label %ready.overflow.resume578

ready.overflow.trap577:                           ; preds = %ready.overflow.resume572
  call void @llvm.trap()
  unreachable

ready.overflow.resume578:                         ; preds = %ready.overflow.resume572
  %3649 = select i1 %3645, i32 %3646, i32 0
  %3650 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3649
  %3651 = load <8 x i1>, ptr %3650, align 1
  %3652 = select i1 %3645, <8 x i1> %3636, <8 x i1> %3651
  store <8 x i1> %3652, ptr %3650, align 1
  %3653 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3649
  %3654 = load i32, ptr %3653, align 4
  %3655 = select i1 %3645, i32 %convergence.dynamic.target576, i32 %3654
  store i32 %3655, ptr %3653, align 4
  %3656 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3649
  %3657 = load i32, ptr %3656, align 4
  %3658 = select i1 %3645, i32 %3642, i32 %3657
  store i32 %3658, ptr %3656, align 4
  %3659 = add i32 %3646, 1
  %3660 = select i1 %3645, i32 %3659, i32 %3646
  store i32 %3660, ptr %ready.count, align 4
  %3661 = load <8 x i1>, ptr %runnable.mask, align 1
  %3662 = or <8 x i1> %3661, %3636
  store <8 x i1> %3662, ptr %runnable.mask, align 1
  %3663 = load i8, ptr %frame.active, align 1
  %3664 = and i8 %3663, 16
  %3665 = icmp ne i8 %3664, 0
  %3666 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 4
  %3667 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 4
  %3668 = load <8 x i1>, ptr %3666, align 1
  %3669 = load <8 x i1>, ptr %3667, align 1
  %3670 = and <8 x i1> %3668, %3507
  %3671 = icmp eq <8 x i1> %3669, %3670
  %3672 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3671)
  %3673 = and i1 %3665, %3672
  %.splatinsert579 = insertelement <8 x i1> poison, i1 %3673, i64 0
  %.splat580 = shufflevector <8 x i1> %.splatinsert579, <8 x i1> poison, <8 x i32> zeroinitializer
  %3674 = select <8 x i1> %.splat580, <8 x i1> %3669, <8 x i1> zeroinitializer
  %3675 = select i1 %3673, <8 x i1> zeroinitializer, <8 x i1> %3670
  store <8 x i1> %3675, ptr %3666, align 1
  %3676 = select i1 %3673, <8 x i1> zeroinitializer, <8 x i1> %3669
  store <8 x i1> %3676, ptr %3667, align 1
  %3677 = and i8 %3663, -17
  %3678 = select i1 %3673, i8 %3677, i8 %3663
  store i8 %3678, ptr %frame.active, align 1
  %3679 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3680 = extractelement <8 x i32> %3679, i32 4
  %3681 = load <8 x i32>, ptr %frame.static.id, align 32
  %3682 = extractelement <8 x i32> %3681, i32 4
  %convergence.target.pointer581 = getelementptr inbounds [13 x i32], ptr @convergence.targets, i32 0, i32 %3682
  %convergence.dynamic.target582 = load i32, ptr %convergence.target.pointer581, align 4
  %3683 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3674)
  %3684 = load i32, ptr %ready.count, align 4
  %3685 = icmp uge i32 %3684, 8
  %3686 = and i1 %3683, %3685
  br i1 %3686, label %ready.overflow.trap583, label %ready.overflow.resume584

ready.overflow.trap583:                           ; preds = %ready.overflow.resume578
  call void @llvm.trap()
  unreachable

ready.overflow.resume584:                         ; preds = %ready.overflow.resume578
  %3687 = select i1 %3683, i32 %3684, i32 0
  %3688 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3687
  %3689 = load <8 x i1>, ptr %3688, align 1
  %3690 = select i1 %3683, <8 x i1> %3674, <8 x i1> %3689
  store <8 x i1> %3690, ptr %3688, align 1
  %3691 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3687
  %3692 = load i32, ptr %3691, align 4
  %3693 = select i1 %3683, i32 %convergence.dynamic.target582, i32 %3692
  store i32 %3693, ptr %3691, align 4
  %3694 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3687
  %3695 = load i32, ptr %3694, align 4
  %3696 = select i1 %3683, i32 %3680, i32 %3695
  store i32 %3696, ptr %3694, align 4
  %3697 = add i32 %3684, 1
  %3698 = select i1 %3683, i32 %3697, i32 %3684
  store i32 %3698, ptr %ready.count, align 4
  %3699 = load <8 x i1>, ptr %runnable.mask, align 1
  %3700 = or <8 x i1> %3699, %3674
  store <8 x i1> %3700, ptr %runnable.mask, align 1
  %3701 = load i8, ptr %frame.active, align 1
  %3702 = and i8 %3701, 32
  %3703 = icmp ne i8 %3702, 0
  %3704 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 5
  %3705 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 5
  %3706 = load <8 x i1>, ptr %3704, align 1
  %3707 = load <8 x i1>, ptr %3705, align 1
  %3708 = and <8 x i1> %3706, %3507
  %3709 = icmp eq <8 x i1> %3707, %3708
  %3710 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3709)
  %3711 = and i1 %3703, %3710
  %.splatinsert585 = insertelement <8 x i1> poison, i1 %3711, i64 0
  %.splat586 = shufflevector <8 x i1> %.splatinsert585, <8 x i1> poison, <8 x i32> zeroinitializer
  %3712 = select <8 x i1> %.splat586, <8 x i1> %3707, <8 x i1> zeroinitializer
  %3713 = select i1 %3711, <8 x i1> zeroinitializer, <8 x i1> %3708
  store <8 x i1> %3713, ptr %3704, align 1
  %3714 = select i1 %3711, <8 x i1> zeroinitializer, <8 x i1> %3707
  store <8 x i1> %3714, ptr %3705, align 1
  %3715 = and i8 %3701, -33
  %3716 = select i1 %3711, i8 %3715, i8 %3701
  store i8 %3716, ptr %frame.active, align 1
  %3717 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3718 = extractelement <8 x i32> %3717, i32 5
  %3719 = load <8 x i32>, ptr %frame.static.id, align 32
  %3720 = extractelement <8 x i32> %3719, i32 5
  %convergence.target.pointer587 = getelementptr inbounds [13 x i32], ptr @convergence.targets, i32 0, i32 %3720
  %convergence.dynamic.target588 = load i32, ptr %convergence.target.pointer587, align 4
  %3721 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3712)
  %3722 = load i32, ptr %ready.count, align 4
  %3723 = icmp uge i32 %3722, 8
  %3724 = and i1 %3721, %3723
  br i1 %3724, label %ready.overflow.trap589, label %ready.overflow.resume590

ready.overflow.trap589:                           ; preds = %ready.overflow.resume584
  call void @llvm.trap()
  unreachable

ready.overflow.resume590:                         ; preds = %ready.overflow.resume584
  %3725 = select i1 %3721, i32 %3722, i32 0
  %3726 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3725
  %3727 = load <8 x i1>, ptr %3726, align 1
  %3728 = select i1 %3721, <8 x i1> %3712, <8 x i1> %3727
  store <8 x i1> %3728, ptr %3726, align 1
  %3729 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3725
  %3730 = load i32, ptr %3729, align 4
  %3731 = select i1 %3721, i32 %convergence.dynamic.target588, i32 %3730
  store i32 %3731, ptr %3729, align 4
  %3732 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3725
  %3733 = load i32, ptr %3732, align 4
  %3734 = select i1 %3721, i32 %3718, i32 %3733
  store i32 %3734, ptr %3732, align 4
  %3735 = add i32 %3722, 1
  %3736 = select i1 %3721, i32 %3735, i32 %3722
  store i32 %3736, ptr %ready.count, align 4
  %3737 = load <8 x i1>, ptr %runnable.mask, align 1
  %3738 = or <8 x i1> %3737, %3712
  store <8 x i1> %3738, ptr %runnable.mask, align 1
  %3739 = load i8, ptr %frame.active, align 1
  %3740 = and i8 %3739, 64
  %3741 = icmp ne i8 %3740, 0
  %3742 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 6
  %3743 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 6
  %3744 = load <8 x i1>, ptr %3742, align 1
  %3745 = load <8 x i1>, ptr %3743, align 1
  %3746 = and <8 x i1> %3744, %3507
  %3747 = icmp eq <8 x i1> %3745, %3746
  %3748 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3747)
  %3749 = and i1 %3741, %3748
  %.splatinsert591 = insertelement <8 x i1> poison, i1 %3749, i64 0
  %.splat592 = shufflevector <8 x i1> %.splatinsert591, <8 x i1> poison, <8 x i32> zeroinitializer
  %3750 = select <8 x i1> %.splat592, <8 x i1> %3745, <8 x i1> zeroinitializer
  %3751 = select i1 %3749, <8 x i1> zeroinitializer, <8 x i1> %3746
  store <8 x i1> %3751, ptr %3742, align 1
  %3752 = select i1 %3749, <8 x i1> zeroinitializer, <8 x i1> %3745
  store <8 x i1> %3752, ptr %3743, align 1
  %3753 = and i8 %3739, -65
  %3754 = select i1 %3749, i8 %3753, i8 %3739
  store i8 %3754, ptr %frame.active, align 1
  %3755 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3756 = extractelement <8 x i32> %3755, i32 6
  %3757 = load <8 x i32>, ptr %frame.static.id, align 32
  %3758 = extractelement <8 x i32> %3757, i32 6
  %convergence.target.pointer593 = getelementptr inbounds [13 x i32], ptr @convergence.targets, i32 0, i32 %3758
  %convergence.dynamic.target594 = load i32, ptr %convergence.target.pointer593, align 4
  %3759 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3750)
  %3760 = load i32, ptr %ready.count, align 4
  %3761 = icmp uge i32 %3760, 8
  %3762 = and i1 %3759, %3761
  br i1 %3762, label %ready.overflow.trap595, label %ready.overflow.resume596

ready.overflow.trap595:                           ; preds = %ready.overflow.resume590
  call void @llvm.trap()
  unreachable

ready.overflow.resume596:                         ; preds = %ready.overflow.resume590
  %3763 = select i1 %3759, i32 %3760, i32 0
  %3764 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3763
  %3765 = load <8 x i1>, ptr %3764, align 1
  %3766 = select i1 %3759, <8 x i1> %3750, <8 x i1> %3765
  store <8 x i1> %3766, ptr %3764, align 1
  %3767 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3763
  %3768 = load i32, ptr %3767, align 4
  %3769 = select i1 %3759, i32 %convergence.dynamic.target594, i32 %3768
  store i32 %3769, ptr %3767, align 4
  %3770 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3763
  %3771 = load i32, ptr %3770, align 4
  %3772 = select i1 %3759, i32 %3756, i32 %3771
  store i32 %3772, ptr %3770, align 4
  %3773 = add i32 %3760, 1
  %3774 = select i1 %3759, i32 %3773, i32 %3760
  store i32 %3774, ptr %ready.count, align 4
  %3775 = load <8 x i1>, ptr %runnable.mask, align 1
  %3776 = or <8 x i1> %3775, %3750
  store <8 x i1> %3776, ptr %runnable.mask, align 1
  %3777 = load i8, ptr %frame.active, align 1
  %3778 = and i8 %3777, -128
  %3779 = icmp ne i8 %3778, 0
  %3780 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 7
  %3781 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 7
  %3782 = load <8 x i1>, ptr %3780, align 1
  %3783 = load <8 x i1>, ptr %3781, align 1
  %3784 = and <8 x i1> %3782, %3507
  %3785 = icmp eq <8 x i1> %3783, %3784
  %3786 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3785)
  %3787 = and i1 %3779, %3786
  %.splatinsert597 = insertelement <8 x i1> poison, i1 %3787, i64 0
  %.splat598 = shufflevector <8 x i1> %.splatinsert597, <8 x i1> poison, <8 x i32> zeroinitializer
  %3788 = select <8 x i1> %.splat598, <8 x i1> %3783, <8 x i1> zeroinitializer
  %3789 = select i1 %3787, <8 x i1> zeroinitializer, <8 x i1> %3784
  store <8 x i1> %3789, ptr %3780, align 1
  %3790 = select i1 %3787, <8 x i1> zeroinitializer, <8 x i1> %3783
  store <8 x i1> %3790, ptr %3781, align 1
  %3791 = and i8 %3777, 127
  %3792 = select i1 %3787, i8 %3791, i8 %3777
  store i8 %3792, ptr %frame.active, align 1
  %3793 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3794 = extractelement <8 x i32> %3793, i32 7
  %3795 = load <8 x i32>, ptr %frame.static.id, align 32
  %3796 = extractelement <8 x i32> %3795, i32 7
  %convergence.target.pointer599 = getelementptr inbounds [13 x i32], ptr @convergence.targets, i32 0, i32 %3796
  %convergence.dynamic.target600 = load i32, ptr %convergence.target.pointer599, align 4
  %3797 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3788)
  %3798 = load i32, ptr %ready.count, align 4
  %3799 = icmp uge i32 %3798, 8
  %3800 = and i1 %3797, %3799
  br i1 %3800, label %ready.overflow.trap601, label %ready.overflow.resume602

ready.overflow.trap601:                           ; preds = %ready.overflow.resume596
  call void @llvm.trap()
  unreachable

ready.overflow.resume602:                         ; preds = %ready.overflow.resume596
  %3801 = select i1 %3797, i32 %3798, i32 0
  %3802 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3801
  %3803 = load <8 x i1>, ptr %3802, align 1
  %3804 = select i1 %3797, <8 x i1> %3788, <8 x i1> %3803
  store <8 x i1> %3804, ptr %3802, align 1
  %3805 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3801
  %3806 = load i32, ptr %3805, align 4
  %3807 = select i1 %3797, i32 %convergence.dynamic.target600, i32 %3806
  store i32 %3807, ptr %3805, align 4
  %3808 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3801
  %3809 = load i32, ptr %3808, align 4
  %3810 = select i1 %3797, i32 %3794, i32 %3809
  store i32 %3810, ptr %3808, align 4
  %3811 = add i32 %3798, 1
  %3812 = select i1 %3797, i32 %3811, i32 %3798
  store i32 %3812, ptr %ready.count, align 4
  %3813 = load <8 x i1>, ptr %runnable.mask, align 1
  %3814 = or <8 x i1> %3813, %3788
  store <8 x i1> %3814, ptr %runnable.mask, align 1
  br label %return.frame.cleanup.done
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), i32 immarg, <8 x i1>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.and.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #4

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.sqrt.f32(float) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), i32 immarg, <8 x i1>) #5

define dso_local void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

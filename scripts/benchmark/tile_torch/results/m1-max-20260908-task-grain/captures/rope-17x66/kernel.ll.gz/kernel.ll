; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

@convergence.targets = private unnamed_addr constant [6 x i32] [i32 2, i32 4, i32 6, i32 8, i32 10, i32 12], align 4

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %live.mask = alloca <8 x i1>, align 1
  %runnable.mask = alloca <8 x i1>, align 1
  %ready.count = alloca i32, align 4
  %ready.mask = alloca [8 x <8 x i1>], align 1
  %ready.target = alloca [8 x i32], align 4
  %ready.token = alloca [8 x i32], align 4
  %current.mask = alloca <8 x i1>, align 1
  %current.token = alloca i32, align 4
  %frame.active = alloca i8, align 1
  %frame.static.id = alloca <8 x i32>, align 32
  %frame.parent.token = alloca <8 x i32>, align 32
  %frame.expected = alloca [8 x <8 x i1>], align 1
  %frame.arrived = alloca [8 x <8 x i1>], align 1
  store <8 x i1> zeroinitializer, ptr %live.mask, align 1
  store <8 x i1> zeroinitializer, ptr %runnable.mask, align 1
  store i32 0, ptr %ready.count, align 4
  store [8 x <8 x i1>] zeroinitializer, ptr %ready.mask, align 1
  store [8 x i32] zeroinitializer, ptr %ready.target, align 4
  store [8 x i32] zeroinitializer, ptr %ready.token, align 4
  store <8 x i1> zeroinitializer, ptr %current.mask, align 1
  store i32 0, ptr %current.token, align 4
  store i8 0, ptr %frame.active, align 1
  store <8 x i32> zeroinitializer, ptr %frame.static.id, align 32
  store <8 x i32> zeroinitializer, ptr %frame.parent.token, align 32
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.expected, align 1
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.arrived, align 1
  %tile_snapshot.local = alloca [160 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [160 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local4 = alloca [160 x i8], align 4
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local7 = alloca [160 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.spill10 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill10, align 64
  %.spill11 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill11, align 64
  %.spill12 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill12, align 64
  %.spill13 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill13, align 64
  %.spill14 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill14, align 64
  %.spill15 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill15, align 64
  %.spill16 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill16, align 64
  %.spill17 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill17, align 64
  %.spill18 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill18, align 64
  %.spill19 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill19, align 64
  %.spill20 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill20, align 64
  %.spill21 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill21, align 64
  %.spill22 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill22, align 64
  %.spill23 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill23, align 64
  %.spill24 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill24, align 64
  %.spill25 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill25, align 64
  %.spill26 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill26, align 64
  %.spill27 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill27, align 64
  %.spill28 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill28, align 1
  %tile_snapshot.spill29 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill29, align 64
  %.spill30 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill30, align 64
  %.spill31 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill31, align 64
  %.spill32 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill32, align 64
  %.spill33 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill33, align 64
  %.spill34 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill34, align 64
  %.spill35 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill35, align 64
  %.spill36 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill36, align 64
  %.spill37 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill37, align 64
  %tile_snapshot.spill38 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill38, align 64
  %.spill39 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill39, align 64
  %.spill40 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill40, align 64
  %.spill41 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill41, align 64
  %.spill42 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill42, align 64
  %.spill43 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill43, align 64
  %.spill44 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill44, align 64
  %.spill45 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill45, align 64
  %.spill46 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill46, align 64
  %.spill47 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill47, align 64
  %tile_snapshot.spill48 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill48, align 64
  %.spill49 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill49, align 64
  %.spill50 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill50, align 64
  %.spill51 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill51, align 64
  %.spill52 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill52, align 64
  %8 = getelementptr i8, ptr %argument_buffer, i64 0
  %9 = load ptr, ptr %8, align 16
  %10 = getelementptr i8, ptr %8, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = insertvalue { ptr, i64 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %11, 1
  %14 = getelementptr i8, ptr %argument_buffer, i64 16
  %15 = load ptr, ptr %14, align 16
  %16 = getelementptr i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = insertvalue { ptr, i64 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i64 } %18, i64 %17, 1
  %20 = getelementptr i8, ptr %argument_buffer, i64 32
  %21 = load ptr, ptr %20, align 16
  %22 = getelementptr i8, ptr %20, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = insertvalue { ptr, i64 } poison, ptr %21, 0
  %25 = insertvalue { ptr, i64 } %24, i64 %23, 1
  %26 = getelementptr i8, ptr %argument_buffer, i64 48
  %27 = load ptr, ptr %26, align 16
  %28 = getelementptr i8, ptr %26, i64 8
  %29 = load i64, ptr %28, align 8
  %30 = insertvalue { ptr, i64 } poison, ptr %27, 0
  %31 = insertvalue { ptr, i64 } %30, i64 %29, 1
  %32 = load i32, ptr %launch_config, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 12
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 4
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 16
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 8
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 20
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 36
  %44 = load i32, ptr %43, align 4
  %.splatinsert53 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat54 = shufflevector <8 x i32> %.splatinsert53, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat54, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %46 = mul i32 %32, 32
  %.splatinsert55 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat56 = shufflevector <8 x i32> %.splatinsert55, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat56, %45
  %48 = mul i32 %36, 1
  %.splatinsert57 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat58 = shufflevector <8 x i32> %.splatinsert57, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat58, zeroinitializer
  %50 = mul i32 %40, 1
  %.splatinsert59 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat60 = shufflevector <8 x i32> %.splatinsert59, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat60, zeroinitializer
  %52 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %47, 0
  %53 = insertvalue [3 x <8 x i32>] %52, <8 x i32> %49, 1
  %54 = insertvalue [3 x <8 x i32>] %53, <8 x i32> %51, 2
  %.splatinsert61 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat62 = shufflevector <8 x i32> %.splatinsert61, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat62
  store <8 x i1> %55, ptr %live.mask, align 1
  %56 = load i32, ptr %current.token, align 4
  %57 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %58 = load i32, ptr %ready.count, align 4
  %59 = icmp uge i32 %58, 8
  %60 = and i1 %57, %59
  br i1 %60, label %ready.overflow.trap, label %ready.overflow.resume

ready.overflow.trap:                              ; preds = %prologue
  call void @llvm.trap()
  unreachable

ready.overflow.resume:                            ; preds = %prologue
  %61 = select i1 %57, i32 %58, i32 0
  %62 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %61
  %63 = load <8 x i1>, ptr %62, align 1
  %64 = select i1 %57, <8 x i1> %55, <8 x i1> %63
  store <8 x i1> %64, ptr %62, align 1
  %65 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %61
  %66 = load i32, ptr %65, align 4
  %67 = select i1 %57, i32 0, i32 %66
  store i32 %67, ptr %65, align 4
  %68 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %61
  %69 = load i32, ptr %68, align 4
  %70 = select i1 %57, i32 %56, i32 %69
  store i32 %70, ptr %68, align 4
  %71 = add i32 %58, 1
  %72 = select i1 %57, i32 %71, i32 %58
  store i32 %72, ptr %ready.count, align 4
  %73 = load <8 x i1>, ptr %runnable.mask, align 1
  %74 = or <8 x i1> %73, %55
  store <8 x i1> %74, ptr %runnable.mask, align 1
  br label %scheduler.loop

scheduler.loop:                                   ; preds = %return.frame.cleanup.done, %convergence.cascade.exit429, %schedule.11, %varying.coherent.false412, %varying.coherent.true411, %convergence.cascade.exit332, %schedule.9, %varying.coherent.false315, %varying.coherent.true314, %convergence.cascade.exit236, %schedule.7, %varying.coherent.false227, %varying.coherent.true226, %convergence.cascade.exit183, %schedule.5, %varying.coherent.false174, %varying.coherent.true173, %convergence.cascade.exit129, %schedule.3, %varying.coherent.false120, %varying.coherent.true119, %convergence.cascade.exit, %schedule.1, %varying.coherent.false, %varying.coherent.true, %ready.overflow.resume
  %75 = load i32, ptr %ready.count, align 4
  %76 = icmp ne i32 %75, 0
  br i1 %76, label %scheduler.dispatch, label %scheduler.done

scheduler.dispatch:                               ; preds = %scheduler.loop
  %77 = sub i32 %75, 1
  store i32 %77, ptr %ready.count, align 4
  %78 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %77
  %79 = load <8 x i1>, ptr %78, align 1
  store <8 x i1> %79, ptr %current.mask, align 1
  %80 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %77
  %81 = load i32, ptr %80, align 4
  %82 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %77
  %83 = load i32, ptr %82, align 4
  store i32 %83, ptr %current.token, align 4
  %84 = load <8 x i1>, ptr %runnable.mask, align 1
  %85 = xor <8 x i1> %79, splat (i1 true)
  %86 = and <8 x i1> %84, %85
  store <8 x i1> %86, ptr %runnable.mask, align 1
  br label %scheduler.dispatch.route

scheduler.dispatch.route:                         ; preds = %ready.overflow.resume410, %ready.overflow.resume313, %ready.overflow.resume225, %ready.overflow.resume172, %ready.overflow.resume118, %ready.overflow.resume76, %scheduler.dispatch
  %scheduler.dispatch.pc = phi i32 [ %81, %scheduler.dispatch ], [ 2, %ready.overflow.resume76 ], [ 4, %ready.overflow.resume118 ], [ 6, %ready.overflow.resume172 ], [ 8, %ready.overflow.resume225 ], [ 10, %ready.overflow.resume313 ], [ 12, %ready.overflow.resume410 ]
  switch i32 %scheduler.dispatch.pc, label %scheduler.invalid [
    i32 0, label %schedule.0
    i32 1, label %schedule.1
    i32 2, label %schedule.2
    i32 3, label %schedule.3
    i32 4, label %schedule.4
    i32 5, label %schedule.5
    i32 6, label %schedule.6
    i32 7, label %schedule.7
    i32 8, label %schedule.8
    i32 9, label %schedule.9
    i32 10, label %schedule.10
    i32 11, label %schedule.11
    i32 12, label %schedule.12
  ]

scheduler.done:                                   ; preds = %scheduler.loop
  %87 = load <8 x i1>, ptr %live.mask, align 1
  %88 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %87)
  br i1 %88, label %scheduler.stalled, label %scheduler.exit

scheduler.exit:                                   ; preds = %scheduler.done
  ret void

scheduler.stalled:                                ; preds = %scheduler.done
  call void @llvm.trap()
  unreachable

scheduler.invalid:                                ; preds = %scheduler.dispatch.route
  call void @llvm.trap()
  unreachable

schedule.0:                                       ; preds = %scheduler.dispatch.route
  %89 = load <8 x i1>, ptr %current.mask, align 1
  %90 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %89)
  %91 = bitcast <8 x i1> %89 to i8
  %92 = call i8 @llvm.cttz.i8(i8 %91, i1 false)
  %93 = zext i8 %92 to i32
  %94 = select i1 %90, i32 %93, i32 0
  %95 = extractvalue [3 x <8 x i32>] %54, 0
  %96 = load <8 x i64>, ptr %.spill, align 64
  %97 = select <8 x i1> %89, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %96
  store <8 x i64> %97, ptr %.spill, align 64
  %98 = sub <8 x i32> %95, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %99 = select <8 x i1> %89, <8 x i32> %98, <8 x i32> zeroinitializer
  %100 = select <8 x i1> %89, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %101 = lshr <8 x i32> %99, %100
  %102 = zext <8 x i32> %101 to <8 x i64>
  %103 = select <8 x i1> %89, <8 x i64> %102, <8 x i64> zeroinitializer
  %104 = select <8 x i1> %89, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %105 = sdiv <8 x i64> %103, %104
  %106 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %108 = extractvalue { <8 x ptr>, <8 x i64> } %106, 0
  %109 = select <8 x i1> %89, <8 x ptr> %107, <8 x ptr> %108
  %110 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %111 = extractvalue { <8 x ptr>, <8 x i64> } %106, 1
  %112 = select <8 x i1> %89, <8 x i64> %110, <8 x i64> %111
  %113 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %109, 0
  %114 = insertvalue { <8 x ptr>, <8 x i64> } %113, <8 x i64> %112, 1
  store volatile { <8 x ptr>, <8 x i64> } %114, ptr %tile_snapshot.spill, align 64
  %115 = load volatile <8 x i64>, ptr %.spill10, align 64
  %116 = select <8 x i1> %89, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %115
  store volatile <8 x i64> %116, ptr %.spill10, align 64
  %117 = add <8 x i64> %105, zeroinitializer
  %118 = add <8 x i64> zeroinitializer, %117
  %119 = load volatile <8 x i64>, ptr %.spill11, align 64
  %120 = select <8 x i1> %89, <8 x i64> %118, <8 x i64> %119
  store volatile <8 x i64> %120, ptr %.spill11, align 64
  %121 = load volatile <8 x i64>, ptr %.spill12, align 64
  %122 = select <8 x i1> %89, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %121
  store volatile <8 x i64> %122, ptr %.spill12, align 64
  %123 = mul <8 x i64> %118, splat (i64 66)
  %124 = load <8 x i64>, ptr %.spill13, align 64
  %125 = select <8 x i1> %89, <8 x i64> %123, <8 x i64> %124
  store <8 x i64> %125, ptr %.spill13, align 64
  %126 = add <8 x i64> %123, <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>
  %127 = load volatile <8 x i64>, ptr %.spill14, align 64
  %128 = select <8 x i1> %89, <8 x i64> %126, <8 x i64> %127
  store volatile <8 x i64> %128, ptr %.spill14, align 64
  %129 = extractvalue { ptr, i64 } %13, 0
  %130 = extractelement <8 x i64> %126, i32 %94
  %131 = zext i32 %94 to i64
  %132 = sub i64 %130, %131
  %133 = mul i64 %132, 4
  %buffer.contiguous.address = getelementptr i8, ptr %129, i64 %133
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %89, <8 x float> zeroinitializer)
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %135 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %136 = add <8 x i64> %135, zeroinitializer
  %137 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %134, 0
  %138 = insertvalue { <8 x ptr>, <8 x i64> } %137, <8 x i64> %136, 1
  %139 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill15, align 64
  %140 = extractvalue { <8 x ptr>, <8 x i64> } %138, 0
  %141 = extractvalue { <8 x ptr>, <8 x i64> } %139, 0
  %142 = select <8 x i1> %89, <8 x ptr> %140, <8 x ptr> %141
  %143 = extractvalue { <8 x ptr>, <8 x i64> } %138, 1
  %144 = extractvalue { <8 x ptr>, <8 x i64> } %139, 1
  %145 = select <8 x i1> %89, <8 x i64> %143, <8 x i64> %144
  %146 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %142, 0
  %147 = insertvalue { <8 x ptr>, <8 x i64> } %146, <8 x i64> %145, 1
  store volatile { <8 x ptr>, <8 x i64> } %147, ptr %.spill15, align 64
  %148 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %138, 1
  %150 = extractelement <8 x ptr> %148, i32 0
  %151 = extractelement <8 x i64> %149, i32 %94
  %152 = zext i32 %94 to i64
  %153 = mul i64 %152, 4
  %154 = sub i64 %151, %153
  %155 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %89)
  %156 = select i1 %155, i64 %154, i64 0
  %private.contiguous.address = getelementptr i8, ptr %150, i64 %156
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %157 = select <8 x i1> %89, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %157, ptr %private.contiguous.address, align 4
  %158 = load volatile <8 x i64>, ptr %.spill16, align 64
  %159 = select <8 x i1> %89, <8 x i64> <i64 8, i64 9, i64 10, i64 11, i64 12, i64 13, i64 14, i64 15>, <8 x i64> %158
  store volatile <8 x i64> %159, ptr %.spill16, align 64
  %160 = load volatile <8 x i64>, ptr %.spill17, align 64
  %161 = select <8 x i1> %89, <8 x i64> <i64 8, i64 9, i64 10, i64 11, i64 12, i64 13, i64 14, i64 15>, <8 x i64> %160
  store volatile <8 x i64> %161, ptr %.spill17, align 64
  %162 = add <8 x i64> %123, <i64 8, i64 9, i64 10, i64 11, i64 12, i64 13, i64 14, i64 15>
  %163 = load volatile <8 x i64>, ptr %.spill18, align 64
  %164 = select <8 x i1> %89, <8 x i64> %162, <8 x i64> %163
  store volatile <8 x i64> %164, ptr %.spill18, align 64
  %165 = extractvalue { ptr, i64 } %13, 0
  %166 = extractelement <8 x i64> %162, i32 %94
  %167 = zext i32 %94 to i64
  %168 = sub i64 %166, %167
  %169 = mul i64 %168, 4
  %buffer.contiguous.address63 = getelementptr i8, ptr %165, i64 %169
  %buffer.contiguous.load64 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address63, i32 1, <8 x i1> %89, <8 x float> zeroinitializer)
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %172 = add <8 x i64> %171, splat (i64 32)
  %173 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %170, 0
  %174 = insertvalue { <8 x ptr>, <8 x i64> } %173, <8 x i64> %172, 1
  %175 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill19, align 64
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %174, 0
  %177 = extractvalue { <8 x ptr>, <8 x i64> } %175, 0
  %178 = select <8 x i1> %89, <8 x ptr> %176, <8 x ptr> %177
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %174, 1
  %180 = extractvalue { <8 x ptr>, <8 x i64> } %175, 1
  %181 = select <8 x i1> %89, <8 x i64> %179, <8 x i64> %180
  %182 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %178, 0
  %183 = insertvalue { <8 x ptr>, <8 x i64> } %182, <8 x i64> %181, 1
  store volatile { <8 x ptr>, <8 x i64> } %183, ptr %.spill19, align 64
  %184 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %185 = extractvalue { <8 x ptr>, <8 x i64> } %174, 1
  %186 = extractelement <8 x ptr> %184, i32 0
  %187 = extractelement <8 x i64> %185, i32 %94
  %188 = zext i32 %94 to i64
  %189 = mul i64 %188, 4
  %190 = sub i64 %187, %189
  %191 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %89)
  %192 = select i1 %191, i64 %190, i64 0
  %private.contiguous.address65 = getelementptr i8, ptr %186, i64 %192
  %private.contiguous.preserve66 = load <8 x float>, ptr %private.contiguous.address65, align 4
  %193 = select <8 x i1> %89, <8 x float> %buffer.contiguous.load64, <8 x float> %private.contiguous.preserve66
  store <8 x float> %193, ptr %private.contiguous.address65, align 4
  %194 = load volatile <8 x i64>, ptr %.spill20, align 64
  %195 = select <8 x i1> %89, <8 x i64> <i64 16, i64 17, i64 18, i64 19, i64 20, i64 21, i64 22, i64 23>, <8 x i64> %194
  store volatile <8 x i64> %195, ptr %.spill20, align 64
  %196 = load volatile <8 x i64>, ptr %.spill21, align 64
  %197 = select <8 x i1> %89, <8 x i64> <i64 16, i64 17, i64 18, i64 19, i64 20, i64 21, i64 22, i64 23>, <8 x i64> %196
  store volatile <8 x i64> %197, ptr %.spill21, align 64
  %198 = add <8 x i64> %123, <i64 16, i64 17, i64 18, i64 19, i64 20, i64 21, i64 22, i64 23>
  %199 = load volatile <8 x i64>, ptr %.spill22, align 64
  %200 = select <8 x i1> %89, <8 x i64> %198, <8 x i64> %199
  store volatile <8 x i64> %200, ptr %.spill22, align 64
  %201 = extractvalue { ptr, i64 } %13, 0
  %202 = extractelement <8 x i64> %198, i32 %94
  %203 = zext i32 %94 to i64
  %204 = sub i64 %202, %203
  %205 = mul i64 %204, 4
  %buffer.contiguous.address67 = getelementptr i8, ptr %201, i64 %205
  %buffer.contiguous.load68 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address67, i32 1, <8 x i1> %89, <8 x float> zeroinitializer)
  %206 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %207 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %208 = add <8 x i64> %207, splat (i64 64)
  %209 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %206, 0
  %210 = insertvalue { <8 x ptr>, <8 x i64> } %209, <8 x i64> %208, 1
  %211 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill23, align 64
  %212 = extractvalue { <8 x ptr>, <8 x i64> } %210, 0
  %213 = extractvalue { <8 x ptr>, <8 x i64> } %211, 0
  %214 = select <8 x i1> %89, <8 x ptr> %212, <8 x ptr> %213
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %210, 1
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %211, 1
  %217 = select <8 x i1> %89, <8 x i64> %215, <8 x i64> %216
  %218 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %214, 0
  %219 = insertvalue { <8 x ptr>, <8 x i64> } %218, <8 x i64> %217, 1
  store volatile { <8 x ptr>, <8 x i64> } %219, ptr %.spill23, align 64
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %210, 1
  %222 = extractelement <8 x ptr> %220, i32 0
  %223 = extractelement <8 x i64> %221, i32 %94
  %224 = zext i32 %94 to i64
  %225 = mul i64 %224, 4
  %226 = sub i64 %223, %225
  %227 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %89)
  %228 = select i1 %227, i64 %226, i64 0
  %private.contiguous.address69 = getelementptr i8, ptr %222, i64 %228
  %private.contiguous.preserve70 = load <8 x float>, ptr %private.contiguous.address69, align 4
  %229 = select <8 x i1> %89, <8 x float> %buffer.contiguous.load68, <8 x float> %private.contiguous.preserve70
  store <8 x float> %229, ptr %private.contiguous.address69, align 4
  %230 = load volatile <8 x i64>, ptr %.spill24, align 64
  %231 = select <8 x i1> %89, <8 x i64> <i64 24, i64 25, i64 26, i64 27, i64 28, i64 29, i64 30, i64 31>, <8 x i64> %230
  store volatile <8 x i64> %231, ptr %.spill24, align 64
  %232 = load volatile <8 x i64>, ptr %.spill25, align 64
  %233 = select <8 x i1> %89, <8 x i64> <i64 24, i64 25, i64 26, i64 27, i64 28, i64 29, i64 30, i64 31>, <8 x i64> %232
  store volatile <8 x i64> %233, ptr %.spill25, align 64
  %234 = add <8 x i64> %123, <i64 24, i64 25, i64 26, i64 27, i64 28, i64 29, i64 30, i64 31>
  %235 = load volatile <8 x i64>, ptr %.spill26, align 64
  %236 = select <8 x i1> %89, <8 x i64> %234, <8 x i64> %235
  store volatile <8 x i64> %236, ptr %.spill26, align 64
  %237 = extractvalue { ptr, i64 } %13, 0
  %238 = extractelement <8 x i64> %234, i32 %94
  %239 = zext i32 %94 to i64
  %240 = sub i64 %238, %239
  %241 = mul i64 %240, 4
  %buffer.contiguous.address71 = getelementptr i8, ptr %237, i64 %241
  %buffer.contiguous.load72 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address71, i32 1, <8 x i1> %89, <8 x float> zeroinitializer)
  %242 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %243 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %244 = add <8 x i64> %243, splat (i64 96)
  %245 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %242, 0
  %246 = insertvalue { <8 x ptr>, <8 x i64> } %245, <8 x i64> %244, 1
  %247 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill27, align 64
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %246, 0
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %247, 0
  %250 = select <8 x i1> %89, <8 x ptr> %248, <8 x ptr> %249
  %251 = extractvalue { <8 x ptr>, <8 x i64> } %246, 1
  %252 = extractvalue { <8 x ptr>, <8 x i64> } %247, 1
  %253 = select <8 x i1> %89, <8 x i64> %251, <8 x i64> %252
  %254 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %250, 0
  %255 = insertvalue { <8 x ptr>, <8 x i64> } %254, <8 x i64> %253, 1
  store volatile { <8 x ptr>, <8 x i64> } %255, ptr %.spill27, align 64
  %256 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %257 = extractvalue { <8 x ptr>, <8 x i64> } %246, 1
  %258 = extractelement <8 x ptr> %256, i32 0
  %259 = extractelement <8 x i64> %257, i32 %94
  %260 = zext i32 %94 to i64
  %261 = mul i64 %260, 4
  %262 = sub i64 %259, %261
  %263 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %89)
  %264 = select i1 %263, i64 %262, i64 0
  %private.contiguous.address73 = getelementptr i8, ptr %258, i64 %264
  %private.contiguous.preserve74 = load <8 x float>, ptr %private.contiguous.address73, align 4
  %265 = select <8 x i1> %89, <8 x float> %buffer.contiguous.load72, <8 x float> %private.contiguous.preserve74
  store <8 x float> %265, ptr %private.contiguous.address73, align 4
  %266 = load <8 x i1>, ptr %.spill28, align 1
  %267 = select <8 x i1> %89, <8 x i1> <i1 true, i1 false, i1 false, i1 false, i1 false, i1 false, i1 false, i1 false>, <8 x i1> %266
  store <8 x i1> %267, ptr %.spill28, align 1
  %268 = and <8 x i1> %89, <i1 true, i1 false, i1 false, i1 false, i1 false, i1 false, i1 false, i1 false>
  %269 = and <8 x i1> %89, <i1 false, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true>
  %270 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %268)
  %271 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %269)
  %272 = and i1 %270, %271
  br i1 %272, label %varying.divergent, label %varying.coherent

schedule.1:                                       ; preds = %varying.coherent.true, %scheduler.dispatch.route
  %273 = load <8 x i1>, ptr %current.mask, align 1
  %274 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %273)
  %275 = bitcast <8 x i1> %273 to i8
  %276 = call i8 @llvm.cttz.i8(i8 %275, i1 false)
  %277 = zext i8 %276 to i32
  %278 = select i1 %274, i32 %277, i32 0
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %279 = add <8 x i64> splat (i64 32), %.spill.load
  %280 = add <8 x i64> zeroinitializer, %279
  %.spill.load77 = load <8 x i64>, ptr %.spill13, align 64
  %281 = add <8 x i64> %.spill.load77, %280
  %282 = extractvalue { ptr, i64 } %13, 0
  %283 = extractelement <8 x i64> %281, i32 %278
  %284 = zext i32 %278 to i64
  %285 = sub i64 %283, %284
  %286 = mul i64 %285, 4
  %buffer.contiguous.address78 = getelementptr i8, ptr %282, i64 %286
  %buffer.contiguous.load79 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address78, i32 1, <8 x i1> %273, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %288 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %289 = add <8 x i64> %288, splat (i64 128)
  %290 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %287, 0
  %291 = insertvalue { <8 x ptr>, <8 x i64> } %290, <8 x i64> %289, 1
  %292 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %291, 1
  %294 = extractelement <8 x ptr> %292, i32 0
  %295 = extractelement <8 x i64> %293, i32 %278
  %296 = zext i32 %278 to i64
  %297 = mul i64 %296, 4
  %298 = sub i64 %295, %297
  %299 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %273)
  %300 = select i1 %299, i64 %298, i64 0
  %private.contiguous.address80 = getelementptr i8, ptr %294, i64 %300
  %private.contiguous.preserve81 = load <8 x float>, ptr %private.contiguous.address80, align 4
  %301 = select <8 x i1> %273, <8 x float> %buffer.contiguous.load79, <8 x float> %private.contiguous.preserve81
  store <8 x float> %301, ptr %private.contiguous.address80, align 4
  store <8 x i1> %273, ptr %current.mask, align 1
  %302 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %273)
  br i1 %302, label %schedule.2, label %scheduler.loop

schedule.2:                                       ; preds = %schedule.1, %varying.coherent.false, %scheduler.dispatch.route
  %303 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token = load i32, ptr %current.token, align 4
  %convergence.token.present = icmp ne i32 %convergence.current.token, 0
  br i1 %convergence.token.present, label %convergence.cascade, label %convergence.cascade.exit

schedule.3:                                       ; preds = %varying.coherent.true119, %scheduler.dispatch.route
  %304 = load <8 x i1>, ptr %current.mask, align 1
  %305 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %304)
  %306 = bitcast <8 x i1> %304 to i8
  %307 = call i8 @llvm.cttz.i8(i8 %306, i1 false)
  %308 = zext i8 %307 to i32
  %309 = select i1 %305, i32 %308, i32 0
  %.spill.load121 = load <8 x i64>, ptr %.spill, align 64
  %310 = add <8 x i64> splat (i64 32), %.spill.load121
  %311 = add <8 x i64> splat (i64 33), %310
  %.spill.load122 = load <8 x i64>, ptr %.spill13, align 64
  %312 = add <8 x i64> %.spill.load122, %311
  %313 = extractvalue { ptr, i64 } %13, 0
  %314 = extractelement <8 x i64> %312, i32 %309
  %315 = zext i32 %309 to i64
  %316 = sub i64 %314, %315
  %317 = mul i64 %316, 4
  %buffer.contiguous.address123 = getelementptr i8, ptr %313, i64 %317
  %buffer.contiguous.load124 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address123, i32 1, <8 x i1> %304, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load125 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %318 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load125, 0
  %319 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load125, 1
  %320 = add <8 x i64> %319, splat (i64 128)
  %321 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %318, 0
  %322 = insertvalue { <8 x ptr>, <8 x i64> } %321, <8 x i64> %320, 1
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %322, 1
  %325 = extractelement <8 x ptr> %323, i32 0
  %326 = extractelement <8 x i64> %324, i32 %309
  %327 = zext i32 %309 to i64
  %328 = mul i64 %327, 4
  %329 = sub i64 %326, %328
  %330 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %304)
  %331 = select i1 %330, i64 %329, i64 0
  %private.contiguous.address126 = getelementptr i8, ptr %325, i64 %331
  %private.contiguous.preserve127 = load <8 x float>, ptr %private.contiguous.address126, align 4
  %332 = select <8 x i1> %304, <8 x float> %buffer.contiguous.load124, <8 x float> %private.contiguous.preserve127
  store <8 x float> %332, ptr %private.contiguous.address126, align 4
  store <8 x i1> %304, ptr %current.mask, align 1
  %333 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %304)
  br i1 %333, label %schedule.4, label %scheduler.loop

schedule.4:                                       ; preds = %schedule.3, %varying.coherent.false120, %scheduler.dispatch.route
  %334 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token130 = load i32, ptr %current.token, align 4
  %convergence.token.present131 = icmp ne i32 %convergence.current.token130, 0
  br i1 %convergence.token.present131, label %convergence.cascade128, label %convergence.cascade.exit129

schedule.5:                                       ; preds = %varying.coherent.true173, %scheduler.dispatch.route
  %335 = load <8 x i1>, ptr %current.mask, align 1
  %336 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %335)
  %337 = bitcast <8 x i1> %335 to i8
  %338 = call i8 @llvm.cttz.i8(i8 %337, i1 false)
  %339 = zext i8 %338 to i32
  %340 = select i1 %336, i32 %339, i32 0
  %.spill.load175 = load <8 x i64>, ptr %.spill, align 64
  %341 = add <8 x i64> splat (i64 32), %.spill.load175
  %342 = add <8 x i64> zeroinitializer, %341
  %.spill.load176 = load volatile <8 x i64>, ptr %.spill39, align 64
  %343 = add <8 x i64> %.spill.load176, %342
  %344 = extractvalue { ptr, i64 } %19, 0
  %345 = extractelement <8 x i64> %343, i32 %340
  %346 = zext i32 %340 to i64
  %347 = sub i64 %345, %346
  %348 = mul i64 %347, 4
  %buffer.contiguous.address177 = getelementptr i8, ptr %344, i64 %348
  %buffer.contiguous.load178 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address177, i32 1, <8 x i1> %335, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load179 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %349 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load179, 0
  %350 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load179, 1
  %351 = add <8 x i64> %350, splat (i64 128)
  %352 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %349, 0
  %353 = insertvalue { <8 x ptr>, <8 x i64> } %352, <8 x i64> %351, 1
  %354 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %355 = extractvalue { <8 x ptr>, <8 x i64> } %353, 1
  %356 = extractelement <8 x ptr> %354, i32 0
  %357 = extractelement <8 x i64> %355, i32 %340
  %358 = zext i32 %340 to i64
  %359 = mul i64 %358, 4
  %360 = sub i64 %357, %359
  %361 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %335)
  %362 = select i1 %361, i64 %360, i64 0
  %private.contiguous.address180 = getelementptr i8, ptr %356, i64 %362
  %private.contiguous.preserve181 = load <8 x float>, ptr %private.contiguous.address180, align 4
  %363 = select <8 x i1> %335, <8 x float> %buffer.contiguous.load178, <8 x float> %private.contiguous.preserve181
  store <8 x float> %363, ptr %private.contiguous.address180, align 4
  store <8 x i1> %335, ptr %current.mask, align 1
  %364 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %335)
  br i1 %364, label %schedule.6, label %scheduler.loop

schedule.6:                                       ; preds = %schedule.5, %varying.coherent.false174, %scheduler.dispatch.route
  %365 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token184 = load i32, ptr %current.token, align 4
  %convergence.token.present185 = icmp ne i32 %convergence.current.token184, 0
  br i1 %convergence.token.present185, label %convergence.cascade182, label %convergence.cascade.exit183

schedule.7:                                       ; preds = %varying.coherent.true226, %scheduler.dispatch.route
  %366 = load <8 x i1>, ptr %current.mask, align 1
  %367 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %366)
  %368 = bitcast <8 x i1> %366 to i8
  %369 = call i8 @llvm.cttz.i8(i8 %368, i1 false)
  %370 = zext i8 %369 to i32
  %371 = select i1 %367, i32 %370, i32 0
  %.spill.load228 = load <8 x i64>, ptr %.spill, align 64
  %372 = add <8 x i64> splat (i64 32), %.spill.load228
  %373 = add <8 x i64> zeroinitializer, %372
  %.spill.load229 = load volatile <8 x i64>, ptr %.spill39, align 64
  %374 = add <8 x i64> %.spill.load229, %373
  %375 = extractvalue { ptr, i64 } %25, 0
  %376 = extractelement <8 x i64> %374, i32 %371
  %377 = zext i32 %371 to i64
  %378 = sub i64 %376, %377
  %379 = mul i64 %378, 4
  %buffer.contiguous.address230 = getelementptr i8, ptr %375, i64 %379
  %buffer.contiguous.load231 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address230, i32 1, <8 x i1> %366, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load232 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill48, align 64
  %380 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load232, 0
  %381 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load232, 1
  %382 = add <8 x i64> %381, splat (i64 128)
  %383 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %380, 0
  %384 = insertvalue { <8 x ptr>, <8 x i64> } %383, <8 x i64> %382, 1
  %385 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %386 = extractvalue { <8 x ptr>, <8 x i64> } %384, 1
  %387 = extractelement <8 x ptr> %385, i32 0
  %388 = extractelement <8 x i64> %386, i32 %371
  %389 = zext i32 %371 to i64
  %390 = mul i64 %389, 4
  %391 = sub i64 %388, %390
  %392 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %366)
  %393 = select i1 %392, i64 %391, i64 0
  %private.contiguous.address233 = getelementptr i8, ptr %387, i64 %393
  %private.contiguous.preserve234 = load <8 x float>, ptr %private.contiguous.address233, align 4
  %394 = select <8 x i1> %366, <8 x float> %buffer.contiguous.load231, <8 x float> %private.contiguous.preserve234
  store <8 x float> %394, ptr %private.contiguous.address233, align 4
  store <8 x i1> %366, ptr %current.mask, align 1
  %395 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %366)
  br i1 %395, label %schedule.8, label %scheduler.loop

schedule.8:                                       ; preds = %schedule.7, %varying.coherent.false227, %scheduler.dispatch.route
  %396 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token237 = load i32, ptr %current.token, align 4
  %convergence.token.present238 = icmp ne i32 %convergence.current.token237, 0
  br i1 %convergence.token.present238, label %convergence.cascade235, label %convergence.cascade.exit236

schedule.9:                                       ; preds = %varying.coherent.true314, %scheduler.dispatch.route
  %397 = load <8 x i1>, ptr %current.mask, align 1
  %398 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %397)
  %399 = bitcast <8 x i1> %397 to i8
  %400 = call i8 @llvm.cttz.i8(i8 %399, i1 false)
  %401 = zext i8 %400 to i32
  %402 = select i1 %398, i32 %401, i32 0
  %.spill.load316 = load <8 x i64>, ptr %.spill, align 64
  %403 = add <8 x i64> splat (i64 32), %.spill.load316
  %404 = add <8 x i64> zeroinitializer, %403
  %.spill.load317 = load <8 x i64>, ptr %.spill13, align 64
  %405 = add <8 x i64> %.spill.load317, %404
  %tile_snapshot.spill.load318 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %406 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load318, 0
  %407 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load318, 1
  %408 = add <8 x i64> %407, splat (i64 128)
  %409 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %406, 0
  %410 = insertvalue { <8 x ptr>, <8 x i64> } %409, <8 x i64> %408, 1
  %411 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %412 = extractvalue { <8 x ptr>, <8 x i64> } %410, 1
  %413 = extractelement <8 x ptr> %411, i32 0
  %414 = extractelement <8 x i64> %412, i32 %402
  %415 = zext i32 %402 to i64
  %416 = mul i64 %415, 4
  %417 = sub i64 %414, %416
  %418 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %397)
  %419 = select i1 %418, i64 %417, i64 0
  %private.contiguous.address319 = getelementptr i8, ptr %413, i64 %419
  %private.contiguous.load320 = load <8 x float>, ptr %private.contiguous.address319, align 4
  %420 = select <8 x i1> %397, <8 x float> %private.contiguous.load320, <8 x float> zeroinitializer
  %tile_snapshot.spill.load321 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %421 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load321, 0
  %422 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load321, 1
  %423 = add <8 x i64> %422, splat (i64 128)
  %424 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %421, 0
  %425 = insertvalue { <8 x ptr>, <8 x i64> } %424, <8 x i64> %423, 1
  %426 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %427 = extractvalue { <8 x ptr>, <8 x i64> } %425, 1
  %428 = extractelement <8 x ptr> %426, i32 0
  %429 = extractelement <8 x i64> %427, i32 %402
  %430 = zext i32 %402 to i64
  %431 = mul i64 %430, 4
  %432 = sub i64 %429, %431
  %433 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %397)
  %434 = select i1 %433, i64 %432, i64 0
  %private.contiguous.address322 = getelementptr i8, ptr %428, i64 %434
  %private.contiguous.load323 = load <8 x float>, ptr %private.contiguous.address322, align 4
  %435 = select <8 x i1> %397, <8 x float> %private.contiguous.load323, <8 x float> zeroinitializer
  %436 = fmul <8 x float> %420, %435
  %tile_snapshot.spill.load324 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %437 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load324, 0
  %438 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load324, 1
  %439 = add <8 x i64> %438, splat (i64 128)
  %440 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %437, 0
  %441 = insertvalue { <8 x ptr>, <8 x i64> } %440, <8 x i64> %439, 1
  %442 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %443 = extractvalue { <8 x ptr>, <8 x i64> } %441, 1
  %444 = extractelement <8 x ptr> %442, i32 0
  %445 = extractelement <8 x i64> %443, i32 %402
  %446 = zext i32 %402 to i64
  %447 = mul i64 %446, 4
  %448 = sub i64 %445, %447
  %449 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %397)
  %450 = select i1 %449, i64 %448, i64 0
  %private.contiguous.address325 = getelementptr i8, ptr %444, i64 %450
  %private.contiguous.load326 = load <8 x float>, ptr %private.contiguous.address325, align 4
  %451 = select <8 x i1> %397, <8 x float> %private.contiguous.load326, <8 x float> zeroinitializer
  %tile_snapshot.spill.load327 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill48, align 64
  %452 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load327, 0
  %453 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load327, 1
  %454 = add <8 x i64> %453, splat (i64 128)
  %455 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %452, 0
  %456 = insertvalue { <8 x ptr>, <8 x i64> } %455, <8 x i64> %454, 1
  %457 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %458 = extractvalue { <8 x ptr>, <8 x i64> } %456, 1
  %459 = extractelement <8 x ptr> %457, i32 0
  %460 = extractelement <8 x i64> %458, i32 %402
  %461 = zext i32 %402 to i64
  %462 = mul i64 %461, 4
  %463 = sub i64 %460, %462
  %464 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %397)
  %465 = select i1 %464, i64 %463, i64 0
  %private.contiguous.address328 = getelementptr i8, ptr %459, i64 %465
  %private.contiguous.load329 = load <8 x float>, ptr %private.contiguous.address328, align 4
  %466 = select <8 x i1> %397, <8 x float> %private.contiguous.load329, <8 x float> zeroinitializer
  %467 = fmul <8 x float> %451, %466
  %468 = fsub <8 x float> %436, %467
  %469 = extractvalue { ptr, i64 } %31, 0
  %470 = extractelement <8 x i64> %405, i32 %402
  %471 = zext i32 %402 to i64
  %472 = sub i64 %470, %471
  %473 = mul i64 %472, 4
  %buffer.contiguous.address330 = getelementptr i8, ptr %469, i64 %473
  call void @llvm.masked.store.v8f32.p0(<8 x float> %468, ptr %buffer.contiguous.address330, i32 1, <8 x i1> %397)
  store <8 x i1> %397, ptr %current.mask, align 1
  %474 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %397)
  br i1 %474, label %schedule.10, label %scheduler.loop

schedule.10:                                      ; preds = %schedule.9, %varying.coherent.false315, %scheduler.dispatch.route
  %475 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token333 = load i32, ptr %current.token, align 4
  %convergence.token.present334 = icmp ne i32 %convergence.current.token333, 0
  br i1 %convergence.token.present334, label %convergence.cascade331, label %convergence.cascade.exit332

schedule.11:                                      ; preds = %varying.coherent.true411, %scheduler.dispatch.route
  %476 = load <8 x i1>, ptr %current.mask, align 1
  %477 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %476)
  %478 = bitcast <8 x i1> %476 to i8
  %479 = call i8 @llvm.cttz.i8(i8 %478, i1 false)
  %480 = zext i8 %479 to i32
  %481 = select i1 %477, i32 %480, i32 0
  %.spill.load413 = load <8 x i64>, ptr %.spill, align 64
  %482 = add <8 x i64> splat (i64 32), %.spill.load413
  %483 = add <8 x i64> splat (i64 33), %482
  %.spill.load414 = load <8 x i64>, ptr %.spill13, align 64
  %484 = add <8 x i64> %.spill.load414, %483
  %tile_snapshot.spill.load415 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %485 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load415, 0
  %486 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load415, 1
  %487 = add <8 x i64> %486, splat (i64 128)
  %488 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %485, 0
  %489 = insertvalue { <8 x ptr>, <8 x i64> } %488, <8 x i64> %487, 1
  %490 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %491 = extractvalue { <8 x ptr>, <8 x i64> } %489, 1
  %492 = extractelement <8 x ptr> %490, i32 0
  %493 = extractelement <8 x i64> %491, i32 %481
  %494 = zext i32 %481 to i64
  %495 = mul i64 %494, 4
  %496 = sub i64 %493, %495
  %497 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %476)
  %498 = select i1 %497, i64 %496, i64 0
  %private.contiguous.address416 = getelementptr i8, ptr %492, i64 %498
  %private.contiguous.load417 = load <8 x float>, ptr %private.contiguous.address416, align 4
  %499 = select <8 x i1> %476, <8 x float> %private.contiguous.load417, <8 x float> zeroinitializer
  %tile_snapshot.spill.load418 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill48, align 64
  %500 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load418, 0
  %501 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load418, 1
  %502 = add <8 x i64> %501, splat (i64 128)
  %503 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %500, 0
  %504 = insertvalue { <8 x ptr>, <8 x i64> } %503, <8 x i64> %502, 1
  %505 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %506 = extractvalue { <8 x ptr>, <8 x i64> } %504, 1
  %507 = extractelement <8 x ptr> %505, i32 0
  %508 = extractelement <8 x i64> %506, i32 %481
  %509 = zext i32 %481 to i64
  %510 = mul i64 %509, 4
  %511 = sub i64 %508, %510
  %512 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %476)
  %513 = select i1 %512, i64 %511, i64 0
  %private.contiguous.address419 = getelementptr i8, ptr %507, i64 %513
  %private.contiguous.load420 = load <8 x float>, ptr %private.contiguous.address419, align 4
  %514 = select <8 x i1> %476, <8 x float> %private.contiguous.load420, <8 x float> zeroinitializer
  %515 = fmul <8 x float> %499, %514
  %tile_snapshot.spill.load421 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %516 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load421, 0
  %517 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load421, 1
  %518 = add <8 x i64> %517, splat (i64 128)
  %519 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %516, 0
  %520 = insertvalue { <8 x ptr>, <8 x i64> } %519, <8 x i64> %518, 1
  %521 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %522 = extractvalue { <8 x ptr>, <8 x i64> } %520, 1
  %523 = extractelement <8 x ptr> %521, i32 0
  %524 = extractelement <8 x i64> %522, i32 %481
  %525 = zext i32 %481 to i64
  %526 = mul i64 %525, 4
  %527 = sub i64 %524, %526
  %528 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %476)
  %529 = select i1 %528, i64 %527, i64 0
  %private.contiguous.address422 = getelementptr i8, ptr %523, i64 %529
  %private.contiguous.load423 = load <8 x float>, ptr %private.contiguous.address422, align 4
  %530 = select <8 x i1> %476, <8 x float> %private.contiguous.load423, <8 x float> zeroinitializer
  %tile_snapshot.spill.load424 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %531 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load424, 0
  %532 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load424, 1
  %533 = add <8 x i64> %532, splat (i64 128)
  %534 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %531, 0
  %535 = insertvalue { <8 x ptr>, <8 x i64> } %534, <8 x i64> %533, 1
  %536 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %537 = extractvalue { <8 x ptr>, <8 x i64> } %535, 1
  %538 = extractelement <8 x ptr> %536, i32 0
  %539 = extractelement <8 x i64> %537, i32 %481
  %540 = zext i32 %481 to i64
  %541 = mul i64 %540, 4
  %542 = sub i64 %539, %541
  %543 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %476)
  %544 = select i1 %543, i64 %542, i64 0
  %private.contiguous.address425 = getelementptr i8, ptr %538, i64 %544
  %private.contiguous.load426 = load <8 x float>, ptr %private.contiguous.address425, align 4
  %545 = select <8 x i1> %476, <8 x float> %private.contiguous.load426, <8 x float> zeroinitializer
  %546 = fmul <8 x float> %530, %545
  %547 = fadd <8 x float> %515, %546
  %548 = extractvalue { ptr, i64 } %31, 0
  %549 = extractelement <8 x i64> %484, i32 %481
  %550 = zext i32 %481 to i64
  %551 = sub i64 %549, %550
  %552 = mul i64 %551, 4
  %buffer.contiguous.address427 = getelementptr i8, ptr %548, i64 %552
  call void @llvm.masked.store.v8f32.p0(<8 x float> %547, ptr %buffer.contiguous.address427, i32 1, <8 x i1> %476)
  store <8 x i1> %476, ptr %current.mask, align 1
  %553 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %476)
  br i1 %553, label %schedule.12, label %scheduler.loop

schedule.12:                                      ; preds = %schedule.11, %varying.coherent.false412, %scheduler.dispatch.route
  %554 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token430 = load i32, ptr %current.token, align 4
  %convergence.token.present431 = icmp ne i32 %convergence.current.token430, 0
  br i1 %convergence.token.present431, label %convergence.cascade428, label %convergence.cascade.exit429

varying.divergent:                                ; preds = %schedule.0
  %555 = load i32, ptr %current.token, align 4
  %556 = icmp ne i32 %555, 0
  %557 = sub i32 %555, 1
  %558 = select i1 %556, i32 %557, i32 0
  %559 = load i8, ptr %frame.active, align 1
  %560 = trunc i32 %558 to i8
  %561 = shl i8 1, %560
  %562 = and i8 %559, %561
  %563 = icmp ne i8 %562, 0
  %564 = load <8 x i32>, ptr %frame.static.id, align 32
  %565 = extractelement <8 x i32> %564, i32 %558
  %566 = icmp eq i32 %565, 0
  %567 = and i1 %563, %566
  %568 = and i1 %556, %567
  %569 = xor i1 %568, true
  %570 = and i1 true, %569
  %571 = xor i8 %559, -1
  %572 = icmp ne i8 %571, 0
  %573 = xor i1 %572, true
  %574 = and i1 %570, %573
  br i1 %574, label %convergence.overflow.trap, label %convergence.overflow.resume

varying.coherent:                                 ; preds = %schedule.0
  br i1 %270, label %varying.coherent.true, label %varying.coherent.false

convergence.overflow.trap:                        ; preds = %varying.divergent
  call void @llvm.trap()
  unreachable

convergence.overflow.resume:                      ; preds = %varying.divergent
  %575 = call i8 @llvm.cttz.i8(i8 %571, i1 false)
  %576 = zext i8 %575 to i32
  %577 = select i1 %572, i32 %576, i32 0
  %578 = trunc i32 %577 to i8
  %579 = shl i8 1, %578
  %580 = or i8 %559, %579
  %581 = select i1 %570, i8 %580, i8 %559
  store i8 %581, ptr %frame.active, align 1
  %582 = load <8 x i32>, ptr %frame.static.id, align 32
  %583 = extractelement <8 x i32> %582, i32 %577
  %584 = select i1 %570, i32 0, i32 %583
  %585 = load <8 x i32>, ptr %frame.static.id, align 32
  %586 = insertelement <8 x i32> %585, i32 %584, i32 %577
  store <8 x i32> %586, ptr %frame.static.id, align 32
  %587 = load <8 x i32>, ptr %frame.parent.token, align 32
  %588 = extractelement <8 x i32> %587, i32 %577
  %589 = select i1 %570, i32 %555, i32 %588
  %590 = load <8 x i32>, ptr %frame.parent.token, align 32
  %591 = insertelement <8 x i32> %590, i32 %589, i32 %577
  store <8 x i32> %591, ptr %frame.parent.token, align 32
  %592 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %577
  %593 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %577
  %594 = load <8 x i1>, ptr %592, align 1
  %595 = load <8 x i1>, ptr %593, align 1
  %596 = select i1 %570, <8 x i1> %89, <8 x i1> %594
  store <8 x i1> %596, ptr %592, align 1
  %597 = select i1 %570, <8 x i1> zeroinitializer, <8 x i1> %595
  store <8 x i1> %597, ptr %593, align 1
  %598 = add i32 %577, 1
  %599 = select i1 %568, i32 %555, i32 %598
  %600 = select i1 true, i32 %599, i32 %555
  store i32 %600, ptr %current.token, align 4
  %601 = load i32, ptr %current.token, align 4
  %602 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %268)
  %603 = load i32, ptr %ready.count, align 4
  %604 = icmp uge i32 %603, 8
  %605 = and i1 %602, %604
  br i1 %605, label %ready.overflow.trap75, label %ready.overflow.resume76

ready.overflow.trap75:                            ; preds = %convergence.overflow.resume
  call void @llvm.trap()
  unreachable

ready.overflow.resume76:                          ; preds = %convergence.overflow.resume
  %606 = select i1 %602, i32 %603, i32 0
  %607 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %606
  %608 = load <8 x i1>, ptr %607, align 1
  %609 = select i1 %602, <8 x i1> %268, <8 x i1> %608
  store <8 x i1> %609, ptr %607, align 1
  %610 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %606
  %611 = load i32, ptr %610, align 4
  %612 = select i1 %602, i32 1, i32 %611
  store i32 %612, ptr %610, align 4
  %613 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %606
  %614 = load i32, ptr %613, align 4
  %615 = select i1 %602, i32 %601, i32 %614
  store i32 %615, ptr %613, align 4
  %616 = add i32 %603, 1
  %617 = select i1 %602, i32 %616, i32 %603
  store i32 %617, ptr %ready.count, align 4
  %618 = load <8 x i1>, ptr %runnable.mask, align 1
  %619 = or <8 x i1> %618, %268
  store <8 x i1> %619, ptr %runnable.mask, align 1
  store <8 x i1> %269, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true:                            ; preds = %varying.coherent
  store <8 x i1> %89, ptr %current.mask, align 1
  %620 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %89)
  br i1 %620, label %schedule.1, label %scheduler.loop

varying.coherent.false:                           ; preds = %varying.coherent
  store <8 x i1> %89, ptr %current.mask, align 1
  %621 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %89)
  br i1 %621, label %schedule.2, label %scheduler.loop

convergence.cascade:                              ; preds = %convergence.cascade, %schedule.2
  %convergence.cascade.flow = phi <8 x i1> [ %303, %schedule.2 ], [ %664, %convergence.cascade ]
  %convergence.cascade.depth = phi i32 [ 0, %schedule.2 ], [ %665, %convergence.cascade ]
  %622 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow)
  %623 = load i32, ptr %current.token, align 4
  %624 = icmp ne i32 %623, 0
  %625 = and i1 %622, %624
  %626 = sub i32 %623, 1
  %627 = select i1 %625, i32 %626, i32 0
  %628 = load i8, ptr %frame.active, align 1
  %629 = trunc i32 %627 to i8
  %630 = shl i8 1, %629
  %631 = and i8 %628, %630
  %632 = icmp ne i8 %631, 0
  %633 = load <8 x i32>, ptr %frame.static.id, align 32
  %634 = extractelement <8 x i32> %633, i32 %627
  %convergence.target.pointer = getelementptr inbounds [6 x i32], ptr @convergence.targets, i32 0, i32 %634
  %convergence.dynamic.target = load i32, ptr %convergence.target.pointer, align 4
  %635 = icmp eq i32 %convergence.dynamic.target, 2
  %636 = and i1 %632, %635
  %637 = and i1 %625, %636
  %638 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %627
  %639 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %627
  %640 = load <8 x i1>, ptr %638, align 1
  %641 = load <8 x i1>, ptr %639, align 1
  %642 = or <8 x i1> %641, %convergence.cascade.flow
  %643 = load <8 x i1>, ptr %live.mask, align 1
  %644 = and <8 x i1> %640, %643
  %645 = icmp eq <8 x i1> %642, %644
  %646 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %645)
  %647 = and i1 %637, %646
  %648 = select i1 %647, <8 x i1> zeroinitializer, <8 x i1> %642
  %649 = select i1 %637, <8 x i1> %648, <8 x i1> %641
  store <8 x i1> %649, ptr %639, align 1
  %650 = select i1 %647, <8 x i1> zeroinitializer, <8 x i1> %640
  store <8 x i1> %650, ptr %638, align 1
  %651 = trunc i32 %627 to i8
  %652 = shl i8 1, %651
  %653 = xor i8 %652, -1
  %654 = and i8 %628, %653
  %655 = select i1 %647, i8 %654, i8 %628
  store i8 %655, ptr %frame.active, align 1
  %.splatinsert82 = insertelement <8 x i1> poison, i1 %637, i64 0
  %.splat83 = shufflevector <8 x i1> %.splatinsert82, <8 x i1> poison, <8 x i32> zeroinitializer
  %656 = and <8 x i1> %convergence.cascade.flow, %.splat83
  %657 = load <8 x i1>, ptr %runnable.mask, align 1
  %658 = xor <8 x i1> %656, splat (i1 true)
  %659 = and <8 x i1> %657, %658
  store <8 x i1> %659, ptr %runnable.mask, align 1
  %.splatinsert84 = insertelement <8 x i1> poison, i1 %647, i64 0
  %.splat85 = shufflevector <8 x i1> %.splatinsert84, <8 x i1> poison, <8 x i32> zeroinitializer
  %660 = select <8 x i1> %.splat85, <8 x i1> %642, <8 x i1> zeroinitializer
  %661 = load <8 x i32>, ptr %frame.parent.token, align 32
  %662 = extractelement <8 x i32> %661, i32 %627
  %663 = select i1 %647, i32 %662, i32 %623
  store i32 %663, ptr %current.token, align 4
  %.splatinsert86 = insertelement <8 x i1> poison, i1 %637, i64 0
  %.splat87 = shufflevector <8 x i1> %.splatinsert86, <8 x i1> poison, <8 x i32> zeroinitializer
  %664 = select <8 x i1> %.splat87, <8 x i1> %660, <8 x i1> %convergence.cascade.flow
  %665 = add i32 %convergence.cascade.depth, 1
  %666 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %664)
  %667 = icmp ult i32 %665, 8
  %668 = and i1 %666, %667
  %669 = and i1 %637, %668
  %convergence.parent.token = load i32, ptr %current.token, align 4
  %convergence.parent.present = icmp ne i32 %convergence.parent.token, 0
  %670 = and i1 %669, %convergence.parent.present
  br i1 %670, label %convergence.cascade, label %convergence.cascade.exit

convergence.cascade.exit:                         ; preds = %convergence.cascade, %schedule.2
  %convergence.cascade.result = phi <8 x i1> [ %303, %schedule.2 ], [ %664, %convergence.cascade ]
  %671 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %671, label %convergence.target.2.ready, label %scheduler.loop

convergence.target.2.ready:                       ; preds = %convergence.cascade.exit
  %672 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %673 = bitcast <8 x i1> %convergence.cascade.result to i8
  %674 = call i8 @llvm.cttz.i8(i8 %673, i1 false)
  %675 = zext i8 %674 to i32
  %676 = select i1 %672, i32 %675, i32 0
  %677 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %678 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %679 = extractvalue { <8 x ptr>, <8 x i64> } %677, 0
  %680 = select <8 x i1> %convergence.cascade.result, <8 x ptr> %678, <8 x ptr> %679
  %681 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %682 = extractvalue { <8 x ptr>, <8 x i64> } %677, 1
  %683 = select <8 x i1> %convergence.cascade.result, <8 x i64> %681, <8 x i64> %682
  %684 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %680, 0
  %685 = insertvalue { <8 x ptr>, <8 x i64> } %684, <8 x i64> %683, 1
  store volatile { <8 x ptr>, <8 x i64> } %685, ptr %tile_snapshot.spill29, align 64
  %.spill.load88 = load volatile <8 x i64>, ptr %.spill10, align 64
  %686 = add <8 x i64> splat (i64 33), %.spill.load88
  %.spill.load89 = load <8 x i64>, ptr %.spill13, align 64
  %687 = add <8 x i64> %.spill.load89, %686
  %688 = load volatile <8 x i64>, ptr %.spill30, align 64
  %689 = select <8 x i1> %convergence.cascade.result, <8 x i64> %687, <8 x i64> %688
  store volatile <8 x i64> %689, ptr %.spill30, align 64
  %690 = extractvalue { ptr, i64 } %13, 0
  %691 = extractelement <8 x i64> %687, i32 %676
  %692 = zext i32 %676 to i64
  %693 = sub i64 %691, %692
  %694 = mul i64 %693, 4
  %buffer.contiguous.address90 = getelementptr i8, ptr %690, i64 %694
  %buffer.contiguous.load91 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address90, i32 1, <8 x i1> %convergence.cascade.result, <8 x float> zeroinitializer)
  %695 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %696 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %697 = add <8 x i64> %696, zeroinitializer
  %698 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %695, 0
  %699 = insertvalue { <8 x ptr>, <8 x i64> } %698, <8 x i64> %697, 1
  %700 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill31, align 64
  %701 = extractvalue { <8 x ptr>, <8 x i64> } %699, 0
  %702 = extractvalue { <8 x ptr>, <8 x i64> } %700, 0
  %703 = select <8 x i1> %convergence.cascade.result, <8 x ptr> %701, <8 x ptr> %702
  %704 = extractvalue { <8 x ptr>, <8 x i64> } %699, 1
  %705 = extractvalue { <8 x ptr>, <8 x i64> } %700, 1
  %706 = select <8 x i1> %convergence.cascade.result, <8 x i64> %704, <8 x i64> %705
  %707 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %703, 0
  %708 = insertvalue { <8 x ptr>, <8 x i64> } %707, <8 x i64> %706, 1
  store volatile { <8 x ptr>, <8 x i64> } %708, ptr %.spill31, align 64
  %709 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %710 = extractvalue { <8 x ptr>, <8 x i64> } %699, 1
  %711 = extractelement <8 x ptr> %709, i32 0
  %712 = extractelement <8 x i64> %710, i32 %676
  %713 = zext i32 %676 to i64
  %714 = mul i64 %713, 4
  %715 = sub i64 %712, %714
  %716 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %717 = select i1 %716, i64 %715, i64 0
  %private.contiguous.address92 = getelementptr i8, ptr %711, i64 %717
  %private.contiguous.preserve93 = load <8 x float>, ptr %private.contiguous.address92, align 4
  %718 = select <8 x i1> %convergence.cascade.result, <8 x float> %buffer.contiguous.load91, <8 x float> %private.contiguous.preserve93
  store <8 x float> %718, ptr %private.contiguous.address92, align 4
  %.spill.load94 = load volatile <8 x i64>, ptr %.spill16, align 64
  %719 = add <8 x i64> splat (i64 33), %.spill.load94
  %.spill.load95 = load <8 x i64>, ptr %.spill13, align 64
  %720 = add <8 x i64> %.spill.load95, %719
  %721 = load volatile <8 x i64>, ptr %.spill32, align 64
  %722 = select <8 x i1> %convergence.cascade.result, <8 x i64> %720, <8 x i64> %721
  store volatile <8 x i64> %722, ptr %.spill32, align 64
  %723 = extractvalue { ptr, i64 } %13, 0
  %724 = extractelement <8 x i64> %720, i32 %676
  %725 = zext i32 %676 to i64
  %726 = sub i64 %724, %725
  %727 = mul i64 %726, 4
  %buffer.contiguous.address96 = getelementptr i8, ptr %723, i64 %727
  %buffer.contiguous.load97 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address96, i32 1, <8 x i1> %convergence.cascade.result, <8 x float> zeroinitializer)
  %728 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %729 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %730 = add <8 x i64> %729, splat (i64 32)
  %731 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %728, 0
  %732 = insertvalue { <8 x ptr>, <8 x i64> } %731, <8 x i64> %730, 1
  %733 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill33, align 64
  %734 = extractvalue { <8 x ptr>, <8 x i64> } %732, 0
  %735 = extractvalue { <8 x ptr>, <8 x i64> } %733, 0
  %736 = select <8 x i1> %convergence.cascade.result, <8 x ptr> %734, <8 x ptr> %735
  %737 = extractvalue { <8 x ptr>, <8 x i64> } %732, 1
  %738 = extractvalue { <8 x ptr>, <8 x i64> } %733, 1
  %739 = select <8 x i1> %convergence.cascade.result, <8 x i64> %737, <8 x i64> %738
  %740 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %736, 0
  %741 = insertvalue { <8 x ptr>, <8 x i64> } %740, <8 x i64> %739, 1
  store volatile { <8 x ptr>, <8 x i64> } %741, ptr %.spill33, align 64
  %742 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %743 = extractvalue { <8 x ptr>, <8 x i64> } %732, 1
  %744 = extractelement <8 x ptr> %742, i32 0
  %745 = extractelement <8 x i64> %743, i32 %676
  %746 = zext i32 %676 to i64
  %747 = mul i64 %746, 4
  %748 = sub i64 %745, %747
  %749 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %750 = select i1 %749, i64 %748, i64 0
  %private.contiguous.address98 = getelementptr i8, ptr %744, i64 %750
  %private.contiguous.preserve99 = load <8 x float>, ptr %private.contiguous.address98, align 4
  %751 = select <8 x i1> %convergence.cascade.result, <8 x float> %buffer.contiguous.load97, <8 x float> %private.contiguous.preserve99
  store <8 x float> %751, ptr %private.contiguous.address98, align 4
  %.spill.load100 = load volatile <8 x i64>, ptr %.spill20, align 64
  %752 = add <8 x i64> splat (i64 33), %.spill.load100
  %.spill.load101 = load <8 x i64>, ptr %.spill13, align 64
  %753 = add <8 x i64> %.spill.load101, %752
  %754 = load volatile <8 x i64>, ptr %.spill34, align 64
  %755 = select <8 x i1> %convergence.cascade.result, <8 x i64> %753, <8 x i64> %754
  store volatile <8 x i64> %755, ptr %.spill34, align 64
  %756 = extractvalue { ptr, i64 } %13, 0
  %757 = extractelement <8 x i64> %753, i32 %676
  %758 = zext i32 %676 to i64
  %759 = sub i64 %757, %758
  %760 = mul i64 %759, 4
  %buffer.contiguous.address102 = getelementptr i8, ptr %756, i64 %760
  %buffer.contiguous.load103 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address102, i32 1, <8 x i1> %convergence.cascade.result, <8 x float> zeroinitializer)
  %761 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %762 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %763 = add <8 x i64> %762, splat (i64 64)
  %764 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %761, 0
  %765 = insertvalue { <8 x ptr>, <8 x i64> } %764, <8 x i64> %763, 1
  %766 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill35, align 64
  %767 = extractvalue { <8 x ptr>, <8 x i64> } %765, 0
  %768 = extractvalue { <8 x ptr>, <8 x i64> } %766, 0
  %769 = select <8 x i1> %convergence.cascade.result, <8 x ptr> %767, <8 x ptr> %768
  %770 = extractvalue { <8 x ptr>, <8 x i64> } %765, 1
  %771 = extractvalue { <8 x ptr>, <8 x i64> } %766, 1
  %772 = select <8 x i1> %convergence.cascade.result, <8 x i64> %770, <8 x i64> %771
  %773 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %769, 0
  %774 = insertvalue { <8 x ptr>, <8 x i64> } %773, <8 x i64> %772, 1
  store volatile { <8 x ptr>, <8 x i64> } %774, ptr %.spill35, align 64
  %775 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %776 = extractvalue { <8 x ptr>, <8 x i64> } %765, 1
  %777 = extractelement <8 x ptr> %775, i32 0
  %778 = extractelement <8 x i64> %776, i32 %676
  %779 = zext i32 %676 to i64
  %780 = mul i64 %779, 4
  %781 = sub i64 %778, %780
  %782 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %783 = select i1 %782, i64 %781, i64 0
  %private.contiguous.address104 = getelementptr i8, ptr %777, i64 %783
  %private.contiguous.preserve105 = load <8 x float>, ptr %private.contiguous.address104, align 4
  %784 = select <8 x i1> %convergence.cascade.result, <8 x float> %buffer.contiguous.load103, <8 x float> %private.contiguous.preserve105
  store <8 x float> %784, ptr %private.contiguous.address104, align 4
  %.spill.load106 = load volatile <8 x i64>, ptr %.spill24, align 64
  %785 = add <8 x i64> splat (i64 33), %.spill.load106
  %.spill.load107 = load <8 x i64>, ptr %.spill13, align 64
  %786 = add <8 x i64> %.spill.load107, %785
  %787 = load volatile <8 x i64>, ptr %.spill36, align 64
  %788 = select <8 x i1> %convergence.cascade.result, <8 x i64> %786, <8 x i64> %787
  store volatile <8 x i64> %788, ptr %.spill36, align 64
  %789 = extractvalue { ptr, i64 } %13, 0
  %790 = extractelement <8 x i64> %786, i32 %676
  %791 = zext i32 %676 to i64
  %792 = sub i64 %790, %791
  %793 = mul i64 %792, 4
  %buffer.contiguous.address108 = getelementptr i8, ptr %789, i64 %793
  %buffer.contiguous.load109 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address108, i32 1, <8 x i1> %convergence.cascade.result, <8 x float> zeroinitializer)
  %794 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %795 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %796 = add <8 x i64> %795, splat (i64 96)
  %797 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %794, 0
  %798 = insertvalue { <8 x ptr>, <8 x i64> } %797, <8 x i64> %796, 1
  %799 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill37, align 64
  %800 = extractvalue { <8 x ptr>, <8 x i64> } %798, 0
  %801 = extractvalue { <8 x ptr>, <8 x i64> } %799, 0
  %802 = select <8 x i1> %convergence.cascade.result, <8 x ptr> %800, <8 x ptr> %801
  %803 = extractvalue { <8 x ptr>, <8 x i64> } %798, 1
  %804 = extractvalue { <8 x ptr>, <8 x i64> } %799, 1
  %805 = select <8 x i1> %convergence.cascade.result, <8 x i64> %803, <8 x i64> %804
  %806 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %802, 0
  %807 = insertvalue { <8 x ptr>, <8 x i64> } %806, <8 x i64> %805, 1
  store volatile { <8 x ptr>, <8 x i64> } %807, ptr %.spill37, align 64
  %808 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %809 = extractvalue { <8 x ptr>, <8 x i64> } %798, 1
  %810 = extractelement <8 x ptr> %808, i32 0
  %811 = extractelement <8 x i64> %809, i32 %676
  %812 = zext i32 %676 to i64
  %813 = mul i64 %812, 4
  %814 = sub i64 %811, %813
  %815 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %816 = select i1 %815, i64 %814, i64 0
  %private.contiguous.address110 = getelementptr i8, ptr %810, i64 %816
  %private.contiguous.preserve111 = load <8 x float>, ptr %private.contiguous.address110, align 4
  %817 = select <8 x i1> %convergence.cascade.result, <8 x float> %buffer.contiguous.load109, <8 x float> %private.contiguous.preserve111
  store <8 x float> %817, ptr %private.contiguous.address110, align 4
  %.spill.load112 = load <8 x i1>, ptr %.spill28, align 1
  %818 = and <8 x i1> %convergence.cascade.result, %.spill.load112
  %819 = xor <8 x i1> %.spill.load112, splat (i1 true)
  %820 = and <8 x i1> %convergence.cascade.result, %819
  %821 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %818)
  %822 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %820)
  %823 = and i1 %821, %822
  br i1 %823, label %varying.divergent113, label %varying.coherent114

varying.divergent113:                             ; preds = %convergence.target.2.ready
  %824 = load i32, ptr %current.token, align 4
  %825 = icmp ne i32 %824, 0
  %826 = sub i32 %824, 1
  %827 = select i1 %825, i32 %826, i32 0
  %828 = load i8, ptr %frame.active, align 1
  %829 = trunc i32 %827 to i8
  %830 = shl i8 1, %829
  %831 = and i8 %828, %830
  %832 = icmp ne i8 %831, 0
  %833 = load <8 x i32>, ptr %frame.static.id, align 32
  %834 = extractelement <8 x i32> %833, i32 %827
  %835 = icmp eq i32 %834, 1
  %836 = and i1 %832, %835
  %837 = and i1 %825, %836
  %838 = xor i1 %837, true
  %839 = and i1 true, %838
  %840 = xor i8 %828, -1
  %841 = icmp ne i8 %840, 0
  %842 = xor i1 %841, true
  %843 = and i1 %839, %842
  br i1 %843, label %convergence.overflow.trap115, label %convergence.overflow.resume116

varying.coherent114:                              ; preds = %convergence.target.2.ready
  br i1 %821, label %varying.coherent.true119, label %varying.coherent.false120

convergence.overflow.trap115:                     ; preds = %varying.divergent113
  call void @llvm.trap()
  unreachable

convergence.overflow.resume116:                   ; preds = %varying.divergent113
  %844 = call i8 @llvm.cttz.i8(i8 %840, i1 false)
  %845 = zext i8 %844 to i32
  %846 = select i1 %841, i32 %845, i32 0
  %847 = trunc i32 %846 to i8
  %848 = shl i8 1, %847
  %849 = or i8 %828, %848
  %850 = select i1 %839, i8 %849, i8 %828
  store i8 %850, ptr %frame.active, align 1
  %851 = load <8 x i32>, ptr %frame.static.id, align 32
  %852 = extractelement <8 x i32> %851, i32 %846
  %853 = select i1 %839, i32 1, i32 %852
  %854 = load <8 x i32>, ptr %frame.static.id, align 32
  %855 = insertelement <8 x i32> %854, i32 %853, i32 %846
  store <8 x i32> %855, ptr %frame.static.id, align 32
  %856 = load <8 x i32>, ptr %frame.parent.token, align 32
  %857 = extractelement <8 x i32> %856, i32 %846
  %858 = select i1 %839, i32 %824, i32 %857
  %859 = load <8 x i32>, ptr %frame.parent.token, align 32
  %860 = insertelement <8 x i32> %859, i32 %858, i32 %846
  store <8 x i32> %860, ptr %frame.parent.token, align 32
  %861 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %846
  %862 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %846
  %863 = load <8 x i1>, ptr %861, align 1
  %864 = load <8 x i1>, ptr %862, align 1
  %865 = select i1 %839, <8 x i1> %convergence.cascade.result, <8 x i1> %863
  store <8 x i1> %865, ptr %861, align 1
  %866 = select i1 %839, <8 x i1> zeroinitializer, <8 x i1> %864
  store <8 x i1> %866, ptr %862, align 1
  %867 = add i32 %846, 1
  %868 = select i1 %837, i32 %824, i32 %867
  %869 = select i1 true, i32 %868, i32 %824
  store i32 %869, ptr %current.token, align 4
  %870 = load i32, ptr %current.token, align 4
  %871 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %818)
  %872 = load i32, ptr %ready.count, align 4
  %873 = icmp uge i32 %872, 8
  %874 = and i1 %871, %873
  br i1 %874, label %ready.overflow.trap117, label %ready.overflow.resume118

ready.overflow.trap117:                           ; preds = %convergence.overflow.resume116
  call void @llvm.trap()
  unreachable

ready.overflow.resume118:                         ; preds = %convergence.overflow.resume116
  %875 = select i1 %871, i32 %872, i32 0
  %876 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %875
  %877 = load <8 x i1>, ptr %876, align 1
  %878 = select i1 %871, <8 x i1> %818, <8 x i1> %877
  store <8 x i1> %878, ptr %876, align 1
  %879 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %875
  %880 = load i32, ptr %879, align 4
  %881 = select i1 %871, i32 3, i32 %880
  store i32 %881, ptr %879, align 4
  %882 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %875
  %883 = load i32, ptr %882, align 4
  %884 = select i1 %871, i32 %870, i32 %883
  store i32 %884, ptr %882, align 4
  %885 = add i32 %872, 1
  %886 = select i1 %871, i32 %885, i32 %872
  store i32 %886, ptr %ready.count, align 4
  %887 = load <8 x i1>, ptr %runnable.mask, align 1
  %888 = or <8 x i1> %887, %818
  store <8 x i1> %888, ptr %runnable.mask, align 1
  store <8 x i1> %820, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true119:                         ; preds = %varying.coherent114
  store <8 x i1> %convergence.cascade.result, ptr %current.mask, align 1
  %889 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %889, label %schedule.3, label %scheduler.loop

varying.coherent.false120:                        ; preds = %varying.coherent114
  store <8 x i1> %convergence.cascade.result, ptr %current.mask, align 1
  %890 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %890, label %schedule.4, label %scheduler.loop

convergence.cascade128:                           ; preds = %convergence.cascade128, %schedule.4
  %convergence.cascade.flow132 = phi <8 x i1> [ %334, %schedule.4 ], [ %933, %convergence.cascade128 ]
  %convergence.cascade.depth133 = phi i32 [ 0, %schedule.4 ], [ %934, %convergence.cascade128 ]
  %891 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow132)
  %892 = load i32, ptr %current.token, align 4
  %893 = icmp ne i32 %892, 0
  %894 = and i1 %891, %893
  %895 = sub i32 %892, 1
  %896 = select i1 %894, i32 %895, i32 0
  %897 = load i8, ptr %frame.active, align 1
  %898 = trunc i32 %896 to i8
  %899 = shl i8 1, %898
  %900 = and i8 %897, %899
  %901 = icmp ne i8 %900, 0
  %902 = load <8 x i32>, ptr %frame.static.id, align 32
  %903 = extractelement <8 x i32> %902, i32 %896
  %convergence.target.pointer134 = getelementptr inbounds [6 x i32], ptr @convergence.targets, i32 0, i32 %903
  %convergence.dynamic.target135 = load i32, ptr %convergence.target.pointer134, align 4
  %904 = icmp eq i32 %convergence.dynamic.target135, 4
  %905 = and i1 %901, %904
  %906 = and i1 %894, %905
  %907 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %896
  %908 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %896
  %909 = load <8 x i1>, ptr %907, align 1
  %910 = load <8 x i1>, ptr %908, align 1
  %911 = or <8 x i1> %910, %convergence.cascade.flow132
  %912 = load <8 x i1>, ptr %live.mask, align 1
  %913 = and <8 x i1> %909, %912
  %914 = icmp eq <8 x i1> %911, %913
  %915 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %914)
  %916 = and i1 %906, %915
  %917 = select i1 %916, <8 x i1> zeroinitializer, <8 x i1> %911
  %918 = select i1 %906, <8 x i1> %917, <8 x i1> %910
  store <8 x i1> %918, ptr %908, align 1
  %919 = select i1 %916, <8 x i1> zeroinitializer, <8 x i1> %909
  store <8 x i1> %919, ptr %907, align 1
  %920 = trunc i32 %896 to i8
  %921 = shl i8 1, %920
  %922 = xor i8 %921, -1
  %923 = and i8 %897, %922
  %924 = select i1 %916, i8 %923, i8 %897
  store i8 %924, ptr %frame.active, align 1
  %.splatinsert136 = insertelement <8 x i1> poison, i1 %906, i64 0
  %.splat137 = shufflevector <8 x i1> %.splatinsert136, <8 x i1> poison, <8 x i32> zeroinitializer
  %925 = and <8 x i1> %convergence.cascade.flow132, %.splat137
  %926 = load <8 x i1>, ptr %runnable.mask, align 1
  %927 = xor <8 x i1> %925, splat (i1 true)
  %928 = and <8 x i1> %926, %927
  store <8 x i1> %928, ptr %runnable.mask, align 1
  %.splatinsert138 = insertelement <8 x i1> poison, i1 %916, i64 0
  %.splat139 = shufflevector <8 x i1> %.splatinsert138, <8 x i1> poison, <8 x i32> zeroinitializer
  %929 = select <8 x i1> %.splat139, <8 x i1> %911, <8 x i1> zeroinitializer
  %930 = load <8 x i32>, ptr %frame.parent.token, align 32
  %931 = extractelement <8 x i32> %930, i32 %896
  %932 = select i1 %916, i32 %931, i32 %892
  store i32 %932, ptr %current.token, align 4
  %.splatinsert140 = insertelement <8 x i1> poison, i1 %906, i64 0
  %.splat141 = shufflevector <8 x i1> %.splatinsert140, <8 x i1> poison, <8 x i32> zeroinitializer
  %933 = select <8 x i1> %.splat141, <8 x i1> %929, <8 x i1> %convergence.cascade.flow132
  %934 = add i32 %convergence.cascade.depth133, 1
  %935 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %933)
  %936 = icmp ult i32 %934, 8
  %937 = and i1 %935, %936
  %938 = and i1 %906, %937
  %convergence.parent.token142 = load i32, ptr %current.token, align 4
  %convergence.parent.present143 = icmp ne i32 %convergence.parent.token142, 0
  %939 = and i1 %938, %convergence.parent.present143
  br i1 %939, label %convergence.cascade128, label %convergence.cascade.exit129

convergence.cascade.exit129:                      ; preds = %convergence.cascade128, %schedule.4
  %convergence.cascade.result144 = phi <8 x i1> [ %334, %schedule.4 ], [ %933, %convergence.cascade128 ]
  %940 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result144)
  br i1 %940, label %convergence.target.4.ready, label %scheduler.loop

convergence.target.4.ready:                       ; preds = %convergence.cascade.exit129
  %941 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result144)
  %942 = bitcast <8 x i1> %convergence.cascade.result144 to i8
  %943 = call i8 @llvm.cttz.i8(i8 %942, i1 false)
  %944 = zext i8 %943 to i32
  %945 = select i1 %941, i32 %944, i32 0
  %946 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %947 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %948 = extractvalue { <8 x ptr>, <8 x i64> } %946, 0
  %949 = select <8 x i1> %convergence.cascade.result144, <8 x ptr> %947, <8 x ptr> %948
  %950 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %951 = extractvalue { <8 x ptr>, <8 x i64> } %946, 1
  %952 = select <8 x i1> %convergence.cascade.result144, <8 x i64> %950, <8 x i64> %951
  %953 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %949, 0
  %954 = insertvalue { <8 x ptr>, <8 x i64> } %953, <8 x i64> %952, 1
  store volatile { <8 x ptr>, <8 x i64> } %954, ptr %tile_snapshot.spill38, align 64
  %.spill.load145 = load volatile <8 x i64>, ptr %.spill11, align 64
  %955 = mul <8 x i64> %.spill.load145, splat (i64 33)
  %956 = load volatile <8 x i64>, ptr %.spill39, align 64
  %957 = select <8 x i1> %convergence.cascade.result144, <8 x i64> %955, <8 x i64> %956
  store volatile <8 x i64> %957, ptr %.spill39, align 64
  %.spill.load146 = load volatile <8 x i64>, ptr %.spill12, align 64
  %958 = add <8 x i64> %955, %.spill.load146
  %959 = load volatile <8 x i64>, ptr %.spill40, align 64
  %960 = select <8 x i1> %convergence.cascade.result144, <8 x i64> %958, <8 x i64> %959
  store volatile <8 x i64> %960, ptr %.spill40, align 64
  %961 = extractvalue { ptr, i64 } %19, 0
  %962 = extractelement <8 x i64> %958, i32 %945
  %963 = zext i32 %945 to i64
  %964 = sub i64 %962, %963
  %965 = mul i64 %964, 4
  %buffer.contiguous.address147 = getelementptr i8, ptr %961, i64 %965
  %buffer.contiguous.load148 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address147, i32 1, <8 x i1> %convergence.cascade.result144, <8 x float> zeroinitializer)
  %966 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %967 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %968 = add <8 x i64> %967, zeroinitializer
  %969 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %966, 0
  %970 = insertvalue { <8 x ptr>, <8 x i64> } %969, <8 x i64> %968, 1
  %971 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill41, align 64
  %972 = extractvalue { <8 x ptr>, <8 x i64> } %970, 0
  %973 = extractvalue { <8 x ptr>, <8 x i64> } %971, 0
  %974 = select <8 x i1> %convergence.cascade.result144, <8 x ptr> %972, <8 x ptr> %973
  %975 = extractvalue { <8 x ptr>, <8 x i64> } %970, 1
  %976 = extractvalue { <8 x ptr>, <8 x i64> } %971, 1
  %977 = select <8 x i1> %convergence.cascade.result144, <8 x i64> %975, <8 x i64> %976
  %978 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %974, 0
  %979 = insertvalue { <8 x ptr>, <8 x i64> } %978, <8 x i64> %977, 1
  store volatile { <8 x ptr>, <8 x i64> } %979, ptr %.spill41, align 64
  %980 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %981 = extractvalue { <8 x ptr>, <8 x i64> } %970, 1
  %982 = extractelement <8 x ptr> %980, i32 0
  %983 = extractelement <8 x i64> %981, i32 %945
  %984 = zext i32 %945 to i64
  %985 = mul i64 %984, 4
  %986 = sub i64 %983, %985
  %987 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result144)
  %988 = select i1 %987, i64 %986, i64 0
  %private.contiguous.address149 = getelementptr i8, ptr %982, i64 %988
  %private.contiguous.preserve150 = load <8 x float>, ptr %private.contiguous.address149, align 4
  %989 = select <8 x i1> %convergence.cascade.result144, <8 x float> %buffer.contiguous.load148, <8 x float> %private.contiguous.preserve150
  store <8 x float> %989, ptr %private.contiguous.address149, align 4
  %.spill.load151 = load volatile <8 x i64>, ptr %.spill17, align 64
  %990 = add <8 x i64> %955, %.spill.load151
  %991 = load volatile <8 x i64>, ptr %.spill42, align 64
  %992 = select <8 x i1> %convergence.cascade.result144, <8 x i64> %990, <8 x i64> %991
  store volatile <8 x i64> %992, ptr %.spill42, align 64
  %993 = extractvalue { ptr, i64 } %19, 0
  %994 = extractelement <8 x i64> %990, i32 %945
  %995 = zext i32 %945 to i64
  %996 = sub i64 %994, %995
  %997 = mul i64 %996, 4
  %buffer.contiguous.address152 = getelementptr i8, ptr %993, i64 %997
  %buffer.contiguous.load153 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address152, i32 1, <8 x i1> %convergence.cascade.result144, <8 x float> zeroinitializer)
  %998 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %999 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1000 = add <8 x i64> %999, splat (i64 32)
  %1001 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %998, 0
  %1002 = insertvalue { <8 x ptr>, <8 x i64> } %1001, <8 x i64> %1000, 1
  %1003 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill43, align 64
  %1004 = extractvalue { <8 x ptr>, <8 x i64> } %1002, 0
  %1005 = extractvalue { <8 x ptr>, <8 x i64> } %1003, 0
  %1006 = select <8 x i1> %convergence.cascade.result144, <8 x ptr> %1004, <8 x ptr> %1005
  %1007 = extractvalue { <8 x ptr>, <8 x i64> } %1002, 1
  %1008 = extractvalue { <8 x ptr>, <8 x i64> } %1003, 1
  %1009 = select <8 x i1> %convergence.cascade.result144, <8 x i64> %1007, <8 x i64> %1008
  %1010 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1006, 0
  %1011 = insertvalue { <8 x ptr>, <8 x i64> } %1010, <8 x i64> %1009, 1
  store volatile { <8 x ptr>, <8 x i64> } %1011, ptr %.spill43, align 64
  %1012 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1013 = extractvalue { <8 x ptr>, <8 x i64> } %1002, 1
  %1014 = extractelement <8 x ptr> %1012, i32 0
  %1015 = extractelement <8 x i64> %1013, i32 %945
  %1016 = zext i32 %945 to i64
  %1017 = mul i64 %1016, 4
  %1018 = sub i64 %1015, %1017
  %1019 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result144)
  %1020 = select i1 %1019, i64 %1018, i64 0
  %private.contiguous.address154 = getelementptr i8, ptr %1014, i64 %1020
  %private.contiguous.preserve155 = load <8 x float>, ptr %private.contiguous.address154, align 4
  %1021 = select <8 x i1> %convergence.cascade.result144, <8 x float> %buffer.contiguous.load153, <8 x float> %private.contiguous.preserve155
  store <8 x float> %1021, ptr %private.contiguous.address154, align 4
  %.spill.load156 = load volatile <8 x i64>, ptr %.spill21, align 64
  %1022 = add <8 x i64> %955, %.spill.load156
  %1023 = load volatile <8 x i64>, ptr %.spill44, align 64
  %1024 = select <8 x i1> %convergence.cascade.result144, <8 x i64> %1022, <8 x i64> %1023
  store volatile <8 x i64> %1024, ptr %.spill44, align 64
  %1025 = extractvalue { ptr, i64 } %19, 0
  %1026 = extractelement <8 x i64> %1022, i32 %945
  %1027 = zext i32 %945 to i64
  %1028 = sub i64 %1026, %1027
  %1029 = mul i64 %1028, 4
  %buffer.contiguous.address157 = getelementptr i8, ptr %1025, i64 %1029
  %buffer.contiguous.load158 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address157, i32 1, <8 x i1> %convergence.cascade.result144, <8 x float> zeroinitializer)
  %1030 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1031 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1032 = add <8 x i64> %1031, splat (i64 64)
  %1033 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1030, 0
  %1034 = insertvalue { <8 x ptr>, <8 x i64> } %1033, <8 x i64> %1032, 1
  %1035 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill45, align 64
  %1036 = extractvalue { <8 x ptr>, <8 x i64> } %1034, 0
  %1037 = extractvalue { <8 x ptr>, <8 x i64> } %1035, 0
  %1038 = select <8 x i1> %convergence.cascade.result144, <8 x ptr> %1036, <8 x ptr> %1037
  %1039 = extractvalue { <8 x ptr>, <8 x i64> } %1034, 1
  %1040 = extractvalue { <8 x ptr>, <8 x i64> } %1035, 1
  %1041 = select <8 x i1> %convergence.cascade.result144, <8 x i64> %1039, <8 x i64> %1040
  %1042 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1038, 0
  %1043 = insertvalue { <8 x ptr>, <8 x i64> } %1042, <8 x i64> %1041, 1
  store volatile { <8 x ptr>, <8 x i64> } %1043, ptr %.spill45, align 64
  %1044 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1045 = extractvalue { <8 x ptr>, <8 x i64> } %1034, 1
  %1046 = extractelement <8 x ptr> %1044, i32 0
  %1047 = extractelement <8 x i64> %1045, i32 %945
  %1048 = zext i32 %945 to i64
  %1049 = mul i64 %1048, 4
  %1050 = sub i64 %1047, %1049
  %1051 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result144)
  %1052 = select i1 %1051, i64 %1050, i64 0
  %private.contiguous.address159 = getelementptr i8, ptr %1046, i64 %1052
  %private.contiguous.preserve160 = load <8 x float>, ptr %private.contiguous.address159, align 4
  %1053 = select <8 x i1> %convergence.cascade.result144, <8 x float> %buffer.contiguous.load158, <8 x float> %private.contiguous.preserve160
  store <8 x float> %1053, ptr %private.contiguous.address159, align 4
  %.spill.load161 = load volatile <8 x i64>, ptr %.spill25, align 64
  %1054 = add <8 x i64> %955, %.spill.load161
  %1055 = load volatile <8 x i64>, ptr %.spill46, align 64
  %1056 = select <8 x i1> %convergence.cascade.result144, <8 x i64> %1054, <8 x i64> %1055
  store volatile <8 x i64> %1056, ptr %.spill46, align 64
  %1057 = extractvalue { ptr, i64 } %19, 0
  %1058 = extractelement <8 x i64> %1054, i32 %945
  %1059 = zext i32 %945 to i64
  %1060 = sub i64 %1058, %1059
  %1061 = mul i64 %1060, 4
  %buffer.contiguous.address162 = getelementptr i8, ptr %1057, i64 %1061
  %buffer.contiguous.load163 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address162, i32 1, <8 x i1> %convergence.cascade.result144, <8 x float> zeroinitializer)
  %1062 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1063 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1064 = add <8 x i64> %1063, splat (i64 96)
  %1065 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1062, 0
  %1066 = insertvalue { <8 x ptr>, <8 x i64> } %1065, <8 x i64> %1064, 1
  %1067 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill47, align 64
  %1068 = extractvalue { <8 x ptr>, <8 x i64> } %1066, 0
  %1069 = extractvalue { <8 x ptr>, <8 x i64> } %1067, 0
  %1070 = select <8 x i1> %convergence.cascade.result144, <8 x ptr> %1068, <8 x ptr> %1069
  %1071 = extractvalue { <8 x ptr>, <8 x i64> } %1066, 1
  %1072 = extractvalue { <8 x ptr>, <8 x i64> } %1067, 1
  %1073 = select <8 x i1> %convergence.cascade.result144, <8 x i64> %1071, <8 x i64> %1072
  %1074 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1070, 0
  %1075 = insertvalue { <8 x ptr>, <8 x i64> } %1074, <8 x i64> %1073, 1
  store volatile { <8 x ptr>, <8 x i64> } %1075, ptr %.spill47, align 64
  %1076 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1077 = extractvalue { <8 x ptr>, <8 x i64> } %1066, 1
  %1078 = extractelement <8 x ptr> %1076, i32 0
  %1079 = extractelement <8 x i64> %1077, i32 %945
  %1080 = zext i32 %945 to i64
  %1081 = mul i64 %1080, 4
  %1082 = sub i64 %1079, %1081
  %1083 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result144)
  %1084 = select i1 %1083, i64 %1082, i64 0
  %private.contiguous.address164 = getelementptr i8, ptr %1078, i64 %1084
  %private.contiguous.preserve165 = load <8 x float>, ptr %private.contiguous.address164, align 4
  %1085 = select <8 x i1> %convergence.cascade.result144, <8 x float> %buffer.contiguous.load163, <8 x float> %private.contiguous.preserve165
  store <8 x float> %1085, ptr %private.contiguous.address164, align 4
  %.spill.load166 = load <8 x i1>, ptr %.spill28, align 1
  %1086 = and <8 x i1> %convergence.cascade.result144, %.spill.load166
  %1087 = xor <8 x i1> %.spill.load166, splat (i1 true)
  %1088 = and <8 x i1> %convergence.cascade.result144, %1087
  %1089 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1086)
  %1090 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1088)
  %1091 = and i1 %1089, %1090
  br i1 %1091, label %varying.divergent167, label %varying.coherent168

varying.divergent167:                             ; preds = %convergence.target.4.ready
  %1092 = load i32, ptr %current.token, align 4
  %1093 = icmp ne i32 %1092, 0
  %1094 = sub i32 %1092, 1
  %1095 = select i1 %1093, i32 %1094, i32 0
  %1096 = load i8, ptr %frame.active, align 1
  %1097 = trunc i32 %1095 to i8
  %1098 = shl i8 1, %1097
  %1099 = and i8 %1096, %1098
  %1100 = icmp ne i8 %1099, 0
  %1101 = load <8 x i32>, ptr %frame.static.id, align 32
  %1102 = extractelement <8 x i32> %1101, i32 %1095
  %1103 = icmp eq i32 %1102, 2
  %1104 = and i1 %1100, %1103
  %1105 = and i1 %1093, %1104
  %1106 = xor i1 %1105, true
  %1107 = and i1 true, %1106
  %1108 = xor i8 %1096, -1
  %1109 = icmp ne i8 %1108, 0
  %1110 = xor i1 %1109, true
  %1111 = and i1 %1107, %1110
  br i1 %1111, label %convergence.overflow.trap169, label %convergence.overflow.resume170

varying.coherent168:                              ; preds = %convergence.target.4.ready
  br i1 %1089, label %varying.coherent.true173, label %varying.coherent.false174

convergence.overflow.trap169:                     ; preds = %varying.divergent167
  call void @llvm.trap()
  unreachable

convergence.overflow.resume170:                   ; preds = %varying.divergent167
  %1112 = call i8 @llvm.cttz.i8(i8 %1108, i1 false)
  %1113 = zext i8 %1112 to i32
  %1114 = select i1 %1109, i32 %1113, i32 0
  %1115 = trunc i32 %1114 to i8
  %1116 = shl i8 1, %1115
  %1117 = or i8 %1096, %1116
  %1118 = select i1 %1107, i8 %1117, i8 %1096
  store i8 %1118, ptr %frame.active, align 1
  %1119 = load <8 x i32>, ptr %frame.static.id, align 32
  %1120 = extractelement <8 x i32> %1119, i32 %1114
  %1121 = select i1 %1107, i32 2, i32 %1120
  %1122 = load <8 x i32>, ptr %frame.static.id, align 32
  %1123 = insertelement <8 x i32> %1122, i32 %1121, i32 %1114
  store <8 x i32> %1123, ptr %frame.static.id, align 32
  %1124 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1125 = extractelement <8 x i32> %1124, i32 %1114
  %1126 = select i1 %1107, i32 %1092, i32 %1125
  %1127 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1128 = insertelement <8 x i32> %1127, i32 %1126, i32 %1114
  store <8 x i32> %1128, ptr %frame.parent.token, align 32
  %1129 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1114
  %1130 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1114
  %1131 = load <8 x i1>, ptr %1129, align 1
  %1132 = load <8 x i1>, ptr %1130, align 1
  %1133 = select i1 %1107, <8 x i1> %convergence.cascade.result144, <8 x i1> %1131
  store <8 x i1> %1133, ptr %1129, align 1
  %1134 = select i1 %1107, <8 x i1> zeroinitializer, <8 x i1> %1132
  store <8 x i1> %1134, ptr %1130, align 1
  %1135 = add i32 %1114, 1
  %1136 = select i1 %1105, i32 %1092, i32 %1135
  %1137 = select i1 true, i32 %1136, i32 %1092
  store i32 %1137, ptr %current.token, align 4
  %1138 = load i32, ptr %current.token, align 4
  %1139 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1086)
  %1140 = load i32, ptr %ready.count, align 4
  %1141 = icmp uge i32 %1140, 8
  %1142 = and i1 %1139, %1141
  br i1 %1142, label %ready.overflow.trap171, label %ready.overflow.resume172

ready.overflow.trap171:                           ; preds = %convergence.overflow.resume170
  call void @llvm.trap()
  unreachable

ready.overflow.resume172:                         ; preds = %convergence.overflow.resume170
  %1143 = select i1 %1139, i32 %1140, i32 0
  %1144 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1143
  %1145 = load <8 x i1>, ptr %1144, align 1
  %1146 = select i1 %1139, <8 x i1> %1086, <8 x i1> %1145
  store <8 x i1> %1146, ptr %1144, align 1
  %1147 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1143
  %1148 = load i32, ptr %1147, align 4
  %1149 = select i1 %1139, i32 5, i32 %1148
  store i32 %1149, ptr %1147, align 4
  %1150 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1143
  %1151 = load i32, ptr %1150, align 4
  %1152 = select i1 %1139, i32 %1138, i32 %1151
  store i32 %1152, ptr %1150, align 4
  %1153 = add i32 %1140, 1
  %1154 = select i1 %1139, i32 %1153, i32 %1140
  store i32 %1154, ptr %ready.count, align 4
  %1155 = load <8 x i1>, ptr %runnable.mask, align 1
  %1156 = or <8 x i1> %1155, %1086
  store <8 x i1> %1156, ptr %runnable.mask, align 1
  store <8 x i1> %1088, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true173:                         ; preds = %varying.coherent168
  store <8 x i1> %convergence.cascade.result144, ptr %current.mask, align 1
  %1157 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result144)
  br i1 %1157, label %schedule.5, label %scheduler.loop

varying.coherent.false174:                        ; preds = %varying.coherent168
  store <8 x i1> %convergence.cascade.result144, ptr %current.mask, align 1
  %1158 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result144)
  br i1 %1158, label %schedule.6, label %scheduler.loop

convergence.cascade182:                           ; preds = %convergence.cascade182, %schedule.6
  %convergence.cascade.flow186 = phi <8 x i1> [ %365, %schedule.6 ], [ %1201, %convergence.cascade182 ]
  %convergence.cascade.depth187 = phi i32 [ 0, %schedule.6 ], [ %1202, %convergence.cascade182 ]
  %1159 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow186)
  %1160 = load i32, ptr %current.token, align 4
  %1161 = icmp ne i32 %1160, 0
  %1162 = and i1 %1159, %1161
  %1163 = sub i32 %1160, 1
  %1164 = select i1 %1162, i32 %1163, i32 0
  %1165 = load i8, ptr %frame.active, align 1
  %1166 = trunc i32 %1164 to i8
  %1167 = shl i8 1, %1166
  %1168 = and i8 %1165, %1167
  %1169 = icmp ne i8 %1168, 0
  %1170 = load <8 x i32>, ptr %frame.static.id, align 32
  %1171 = extractelement <8 x i32> %1170, i32 %1164
  %convergence.target.pointer188 = getelementptr inbounds [6 x i32], ptr @convergence.targets, i32 0, i32 %1171
  %convergence.dynamic.target189 = load i32, ptr %convergence.target.pointer188, align 4
  %1172 = icmp eq i32 %convergence.dynamic.target189, 6
  %1173 = and i1 %1169, %1172
  %1174 = and i1 %1162, %1173
  %1175 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1164
  %1176 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1164
  %1177 = load <8 x i1>, ptr %1175, align 1
  %1178 = load <8 x i1>, ptr %1176, align 1
  %1179 = or <8 x i1> %1178, %convergence.cascade.flow186
  %1180 = load <8 x i1>, ptr %live.mask, align 1
  %1181 = and <8 x i1> %1177, %1180
  %1182 = icmp eq <8 x i1> %1179, %1181
  %1183 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1182)
  %1184 = and i1 %1174, %1183
  %1185 = select i1 %1184, <8 x i1> zeroinitializer, <8 x i1> %1179
  %1186 = select i1 %1174, <8 x i1> %1185, <8 x i1> %1178
  store <8 x i1> %1186, ptr %1176, align 1
  %1187 = select i1 %1184, <8 x i1> zeroinitializer, <8 x i1> %1177
  store <8 x i1> %1187, ptr %1175, align 1
  %1188 = trunc i32 %1164 to i8
  %1189 = shl i8 1, %1188
  %1190 = xor i8 %1189, -1
  %1191 = and i8 %1165, %1190
  %1192 = select i1 %1184, i8 %1191, i8 %1165
  store i8 %1192, ptr %frame.active, align 1
  %.splatinsert190 = insertelement <8 x i1> poison, i1 %1174, i64 0
  %.splat191 = shufflevector <8 x i1> %.splatinsert190, <8 x i1> poison, <8 x i32> zeroinitializer
  %1193 = and <8 x i1> %convergence.cascade.flow186, %.splat191
  %1194 = load <8 x i1>, ptr %runnable.mask, align 1
  %1195 = xor <8 x i1> %1193, splat (i1 true)
  %1196 = and <8 x i1> %1194, %1195
  store <8 x i1> %1196, ptr %runnable.mask, align 1
  %.splatinsert192 = insertelement <8 x i1> poison, i1 %1184, i64 0
  %.splat193 = shufflevector <8 x i1> %.splatinsert192, <8 x i1> poison, <8 x i32> zeroinitializer
  %1197 = select <8 x i1> %.splat193, <8 x i1> %1179, <8 x i1> zeroinitializer
  %1198 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1199 = extractelement <8 x i32> %1198, i32 %1164
  %1200 = select i1 %1184, i32 %1199, i32 %1160
  store i32 %1200, ptr %current.token, align 4
  %.splatinsert194 = insertelement <8 x i1> poison, i1 %1174, i64 0
  %.splat195 = shufflevector <8 x i1> %.splatinsert194, <8 x i1> poison, <8 x i32> zeroinitializer
  %1201 = select <8 x i1> %.splat195, <8 x i1> %1197, <8 x i1> %convergence.cascade.flow186
  %1202 = add i32 %convergence.cascade.depth187, 1
  %1203 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1201)
  %1204 = icmp ult i32 %1202, 8
  %1205 = and i1 %1203, %1204
  %1206 = and i1 %1174, %1205
  %convergence.parent.token196 = load i32, ptr %current.token, align 4
  %convergence.parent.present197 = icmp ne i32 %convergence.parent.token196, 0
  %1207 = and i1 %1206, %convergence.parent.present197
  br i1 %1207, label %convergence.cascade182, label %convergence.cascade.exit183

convergence.cascade.exit183:                      ; preds = %convergence.cascade182, %schedule.6
  %convergence.cascade.result198 = phi <8 x i1> [ %365, %schedule.6 ], [ %1201, %convergence.cascade182 ]
  %1208 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result198)
  br i1 %1208, label %convergence.target.6.ready, label %scheduler.loop

convergence.target.6.ready:                       ; preds = %convergence.cascade.exit183
  %1209 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result198)
  %1210 = bitcast <8 x i1> %convergence.cascade.result198 to i8
  %1211 = call i8 @llvm.cttz.i8(i8 %1210, i1 false)
  %1212 = zext i8 %1211 to i32
  %1213 = select i1 %1209, i32 %1212, i32 0
  %1214 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill48, align 64
  %1215 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1216 = extractvalue { <8 x ptr>, <8 x i64> } %1214, 0
  %1217 = select <8 x i1> %convergence.cascade.result198, <8 x ptr> %1215, <8 x ptr> %1216
  %1218 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %1219 = extractvalue { <8 x ptr>, <8 x i64> } %1214, 1
  %1220 = select <8 x i1> %convergence.cascade.result198, <8 x i64> %1218, <8 x i64> %1219
  %1221 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1217, 0
  %1222 = insertvalue { <8 x ptr>, <8 x i64> } %1221, <8 x i64> %1220, 1
  store volatile { <8 x ptr>, <8 x i64> } %1222, ptr %tile_snapshot.spill48, align 64
  %.spill.load199 = load volatile <8 x i64>, ptr %.spill40, align 64
  %1223 = extractvalue { ptr, i64 } %25, 0
  %1224 = extractelement <8 x i64> %.spill.load199, i32 %1213
  %1225 = zext i32 %1213 to i64
  %1226 = sub i64 %1224, %1225
  %1227 = mul i64 %1226, 4
  %buffer.contiguous.address200 = getelementptr i8, ptr %1223, i64 %1227
  %buffer.contiguous.load201 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address200, i32 1, <8 x i1> %convergence.cascade.result198, <8 x float> zeroinitializer)
  %1228 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1229 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %1230 = add <8 x i64> %1229, zeroinitializer
  %1231 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1228, 0
  %1232 = insertvalue { <8 x ptr>, <8 x i64> } %1231, <8 x i64> %1230, 1
  %1233 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill49, align 64
  %1234 = extractvalue { <8 x ptr>, <8 x i64> } %1232, 0
  %1235 = extractvalue { <8 x ptr>, <8 x i64> } %1233, 0
  %1236 = select <8 x i1> %convergence.cascade.result198, <8 x ptr> %1234, <8 x ptr> %1235
  %1237 = extractvalue { <8 x ptr>, <8 x i64> } %1232, 1
  %1238 = extractvalue { <8 x ptr>, <8 x i64> } %1233, 1
  %1239 = select <8 x i1> %convergence.cascade.result198, <8 x i64> %1237, <8 x i64> %1238
  %1240 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1236, 0
  %1241 = insertvalue { <8 x ptr>, <8 x i64> } %1240, <8 x i64> %1239, 1
  store volatile { <8 x ptr>, <8 x i64> } %1241, ptr %.spill49, align 64
  %1242 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1243 = extractvalue { <8 x ptr>, <8 x i64> } %1232, 1
  %1244 = extractelement <8 x ptr> %1242, i32 0
  %1245 = extractelement <8 x i64> %1243, i32 %1213
  %1246 = zext i32 %1213 to i64
  %1247 = mul i64 %1246, 4
  %1248 = sub i64 %1245, %1247
  %1249 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result198)
  %1250 = select i1 %1249, i64 %1248, i64 0
  %private.contiguous.address202 = getelementptr i8, ptr %1244, i64 %1250
  %private.contiguous.preserve203 = load <8 x float>, ptr %private.contiguous.address202, align 4
  %1251 = select <8 x i1> %convergence.cascade.result198, <8 x float> %buffer.contiguous.load201, <8 x float> %private.contiguous.preserve203
  store <8 x float> %1251, ptr %private.contiguous.address202, align 4
  %.spill.load204 = load volatile <8 x i64>, ptr %.spill42, align 64
  %1252 = extractvalue { ptr, i64 } %25, 0
  %1253 = extractelement <8 x i64> %.spill.load204, i32 %1213
  %1254 = zext i32 %1213 to i64
  %1255 = sub i64 %1253, %1254
  %1256 = mul i64 %1255, 4
  %buffer.contiguous.address205 = getelementptr i8, ptr %1252, i64 %1256
  %buffer.contiguous.load206 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address205, i32 1, <8 x i1> %convergence.cascade.result198, <8 x float> zeroinitializer)
  %1257 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1258 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %1259 = add <8 x i64> %1258, splat (i64 32)
  %1260 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1257, 0
  %1261 = insertvalue { <8 x ptr>, <8 x i64> } %1260, <8 x i64> %1259, 1
  %1262 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill50, align 64
  %1263 = extractvalue { <8 x ptr>, <8 x i64> } %1261, 0
  %1264 = extractvalue { <8 x ptr>, <8 x i64> } %1262, 0
  %1265 = select <8 x i1> %convergence.cascade.result198, <8 x ptr> %1263, <8 x ptr> %1264
  %1266 = extractvalue { <8 x ptr>, <8 x i64> } %1261, 1
  %1267 = extractvalue { <8 x ptr>, <8 x i64> } %1262, 1
  %1268 = select <8 x i1> %convergence.cascade.result198, <8 x i64> %1266, <8 x i64> %1267
  %1269 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1265, 0
  %1270 = insertvalue { <8 x ptr>, <8 x i64> } %1269, <8 x i64> %1268, 1
  store volatile { <8 x ptr>, <8 x i64> } %1270, ptr %.spill50, align 64
  %1271 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1272 = extractvalue { <8 x ptr>, <8 x i64> } %1261, 1
  %1273 = extractelement <8 x ptr> %1271, i32 0
  %1274 = extractelement <8 x i64> %1272, i32 %1213
  %1275 = zext i32 %1213 to i64
  %1276 = mul i64 %1275, 4
  %1277 = sub i64 %1274, %1276
  %1278 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result198)
  %1279 = select i1 %1278, i64 %1277, i64 0
  %private.contiguous.address207 = getelementptr i8, ptr %1273, i64 %1279
  %private.contiguous.preserve208 = load <8 x float>, ptr %private.contiguous.address207, align 4
  %1280 = select <8 x i1> %convergence.cascade.result198, <8 x float> %buffer.contiguous.load206, <8 x float> %private.contiguous.preserve208
  store <8 x float> %1280, ptr %private.contiguous.address207, align 4
  %.spill.load209 = load volatile <8 x i64>, ptr %.spill44, align 64
  %1281 = extractvalue { ptr, i64 } %25, 0
  %1282 = extractelement <8 x i64> %.spill.load209, i32 %1213
  %1283 = zext i32 %1213 to i64
  %1284 = sub i64 %1282, %1283
  %1285 = mul i64 %1284, 4
  %buffer.contiguous.address210 = getelementptr i8, ptr %1281, i64 %1285
  %buffer.contiguous.load211 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address210, i32 1, <8 x i1> %convergence.cascade.result198, <8 x float> zeroinitializer)
  %1286 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1287 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %1288 = add <8 x i64> %1287, splat (i64 64)
  %1289 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1286, 0
  %1290 = insertvalue { <8 x ptr>, <8 x i64> } %1289, <8 x i64> %1288, 1
  %1291 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill51, align 64
  %1292 = extractvalue { <8 x ptr>, <8 x i64> } %1290, 0
  %1293 = extractvalue { <8 x ptr>, <8 x i64> } %1291, 0
  %1294 = select <8 x i1> %convergence.cascade.result198, <8 x ptr> %1292, <8 x ptr> %1293
  %1295 = extractvalue { <8 x ptr>, <8 x i64> } %1290, 1
  %1296 = extractvalue { <8 x ptr>, <8 x i64> } %1291, 1
  %1297 = select <8 x i1> %convergence.cascade.result198, <8 x i64> %1295, <8 x i64> %1296
  %1298 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1294, 0
  %1299 = insertvalue { <8 x ptr>, <8 x i64> } %1298, <8 x i64> %1297, 1
  store volatile { <8 x ptr>, <8 x i64> } %1299, ptr %.spill51, align 64
  %1300 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1301 = extractvalue { <8 x ptr>, <8 x i64> } %1290, 1
  %1302 = extractelement <8 x ptr> %1300, i32 0
  %1303 = extractelement <8 x i64> %1301, i32 %1213
  %1304 = zext i32 %1213 to i64
  %1305 = mul i64 %1304, 4
  %1306 = sub i64 %1303, %1305
  %1307 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result198)
  %1308 = select i1 %1307, i64 %1306, i64 0
  %private.contiguous.address212 = getelementptr i8, ptr %1302, i64 %1308
  %private.contiguous.preserve213 = load <8 x float>, ptr %private.contiguous.address212, align 4
  %1309 = select <8 x i1> %convergence.cascade.result198, <8 x float> %buffer.contiguous.load211, <8 x float> %private.contiguous.preserve213
  store <8 x float> %1309, ptr %private.contiguous.address212, align 4
  %.spill.load214 = load volatile <8 x i64>, ptr %.spill46, align 64
  %1310 = extractvalue { ptr, i64 } %25, 0
  %1311 = extractelement <8 x i64> %.spill.load214, i32 %1213
  %1312 = zext i32 %1213 to i64
  %1313 = sub i64 %1311, %1312
  %1314 = mul i64 %1313, 4
  %buffer.contiguous.address215 = getelementptr i8, ptr %1310, i64 %1314
  %buffer.contiguous.load216 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address215, i32 1, <8 x i1> %convergence.cascade.result198, <8 x float> zeroinitializer)
  %1315 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1316 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %1317 = add <8 x i64> %1316, splat (i64 96)
  %1318 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1315, 0
  %1319 = insertvalue { <8 x ptr>, <8 x i64> } %1318, <8 x i64> %1317, 1
  %1320 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill52, align 64
  %1321 = extractvalue { <8 x ptr>, <8 x i64> } %1319, 0
  %1322 = extractvalue { <8 x ptr>, <8 x i64> } %1320, 0
  %1323 = select <8 x i1> %convergence.cascade.result198, <8 x ptr> %1321, <8 x ptr> %1322
  %1324 = extractvalue { <8 x ptr>, <8 x i64> } %1319, 1
  %1325 = extractvalue { <8 x ptr>, <8 x i64> } %1320, 1
  %1326 = select <8 x i1> %convergence.cascade.result198, <8 x i64> %1324, <8 x i64> %1325
  %1327 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1323, 0
  %1328 = insertvalue { <8 x ptr>, <8 x i64> } %1327, <8 x i64> %1326, 1
  store volatile { <8 x ptr>, <8 x i64> } %1328, ptr %.spill52, align 64
  %1329 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1330 = extractvalue { <8 x ptr>, <8 x i64> } %1319, 1
  %1331 = extractelement <8 x ptr> %1329, i32 0
  %1332 = extractelement <8 x i64> %1330, i32 %1213
  %1333 = zext i32 %1213 to i64
  %1334 = mul i64 %1333, 4
  %1335 = sub i64 %1332, %1334
  %1336 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result198)
  %1337 = select i1 %1336, i64 %1335, i64 0
  %private.contiguous.address217 = getelementptr i8, ptr %1331, i64 %1337
  %private.contiguous.preserve218 = load <8 x float>, ptr %private.contiguous.address217, align 4
  %1338 = select <8 x i1> %convergence.cascade.result198, <8 x float> %buffer.contiguous.load216, <8 x float> %private.contiguous.preserve218
  store <8 x float> %1338, ptr %private.contiguous.address217, align 4
  %.spill.load219 = load <8 x i1>, ptr %.spill28, align 1
  %1339 = and <8 x i1> %convergence.cascade.result198, %.spill.load219
  %1340 = xor <8 x i1> %.spill.load219, splat (i1 true)
  %1341 = and <8 x i1> %convergence.cascade.result198, %1340
  %1342 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1339)
  %1343 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1341)
  %1344 = and i1 %1342, %1343
  br i1 %1344, label %varying.divergent220, label %varying.coherent221

varying.divergent220:                             ; preds = %convergence.target.6.ready
  %1345 = load i32, ptr %current.token, align 4
  %1346 = icmp ne i32 %1345, 0
  %1347 = sub i32 %1345, 1
  %1348 = select i1 %1346, i32 %1347, i32 0
  %1349 = load i8, ptr %frame.active, align 1
  %1350 = trunc i32 %1348 to i8
  %1351 = shl i8 1, %1350
  %1352 = and i8 %1349, %1351
  %1353 = icmp ne i8 %1352, 0
  %1354 = load <8 x i32>, ptr %frame.static.id, align 32
  %1355 = extractelement <8 x i32> %1354, i32 %1348
  %1356 = icmp eq i32 %1355, 3
  %1357 = and i1 %1353, %1356
  %1358 = and i1 %1346, %1357
  %1359 = xor i1 %1358, true
  %1360 = and i1 true, %1359
  %1361 = xor i8 %1349, -1
  %1362 = icmp ne i8 %1361, 0
  %1363 = xor i1 %1362, true
  %1364 = and i1 %1360, %1363
  br i1 %1364, label %convergence.overflow.trap222, label %convergence.overflow.resume223

varying.coherent221:                              ; preds = %convergence.target.6.ready
  br i1 %1342, label %varying.coherent.true226, label %varying.coherent.false227

convergence.overflow.trap222:                     ; preds = %varying.divergent220
  call void @llvm.trap()
  unreachable

convergence.overflow.resume223:                   ; preds = %varying.divergent220
  %1365 = call i8 @llvm.cttz.i8(i8 %1361, i1 false)
  %1366 = zext i8 %1365 to i32
  %1367 = select i1 %1362, i32 %1366, i32 0
  %1368 = trunc i32 %1367 to i8
  %1369 = shl i8 1, %1368
  %1370 = or i8 %1349, %1369
  %1371 = select i1 %1360, i8 %1370, i8 %1349
  store i8 %1371, ptr %frame.active, align 1
  %1372 = load <8 x i32>, ptr %frame.static.id, align 32
  %1373 = extractelement <8 x i32> %1372, i32 %1367
  %1374 = select i1 %1360, i32 3, i32 %1373
  %1375 = load <8 x i32>, ptr %frame.static.id, align 32
  %1376 = insertelement <8 x i32> %1375, i32 %1374, i32 %1367
  store <8 x i32> %1376, ptr %frame.static.id, align 32
  %1377 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1378 = extractelement <8 x i32> %1377, i32 %1367
  %1379 = select i1 %1360, i32 %1345, i32 %1378
  %1380 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1381 = insertelement <8 x i32> %1380, i32 %1379, i32 %1367
  store <8 x i32> %1381, ptr %frame.parent.token, align 32
  %1382 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1367
  %1383 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1367
  %1384 = load <8 x i1>, ptr %1382, align 1
  %1385 = load <8 x i1>, ptr %1383, align 1
  %1386 = select i1 %1360, <8 x i1> %convergence.cascade.result198, <8 x i1> %1384
  store <8 x i1> %1386, ptr %1382, align 1
  %1387 = select i1 %1360, <8 x i1> zeroinitializer, <8 x i1> %1385
  store <8 x i1> %1387, ptr %1383, align 1
  %1388 = add i32 %1367, 1
  %1389 = select i1 %1358, i32 %1345, i32 %1388
  %1390 = select i1 true, i32 %1389, i32 %1345
  store i32 %1390, ptr %current.token, align 4
  %1391 = load i32, ptr %current.token, align 4
  %1392 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1339)
  %1393 = load i32, ptr %ready.count, align 4
  %1394 = icmp uge i32 %1393, 8
  %1395 = and i1 %1392, %1394
  br i1 %1395, label %ready.overflow.trap224, label %ready.overflow.resume225

ready.overflow.trap224:                           ; preds = %convergence.overflow.resume223
  call void @llvm.trap()
  unreachable

ready.overflow.resume225:                         ; preds = %convergence.overflow.resume223
  %1396 = select i1 %1392, i32 %1393, i32 0
  %1397 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1396
  %1398 = load <8 x i1>, ptr %1397, align 1
  %1399 = select i1 %1392, <8 x i1> %1339, <8 x i1> %1398
  store <8 x i1> %1399, ptr %1397, align 1
  %1400 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1396
  %1401 = load i32, ptr %1400, align 4
  %1402 = select i1 %1392, i32 7, i32 %1401
  store i32 %1402, ptr %1400, align 4
  %1403 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1396
  %1404 = load i32, ptr %1403, align 4
  %1405 = select i1 %1392, i32 %1391, i32 %1404
  store i32 %1405, ptr %1403, align 4
  %1406 = add i32 %1393, 1
  %1407 = select i1 %1392, i32 %1406, i32 %1393
  store i32 %1407, ptr %ready.count, align 4
  %1408 = load <8 x i1>, ptr %runnable.mask, align 1
  %1409 = or <8 x i1> %1408, %1339
  store <8 x i1> %1409, ptr %runnable.mask, align 1
  store <8 x i1> %1341, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true226:                         ; preds = %varying.coherent221
  store <8 x i1> %convergence.cascade.result198, ptr %current.mask, align 1
  %1410 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result198)
  br i1 %1410, label %schedule.7, label %scheduler.loop

varying.coherent.false227:                        ; preds = %varying.coherent221
  store <8 x i1> %convergence.cascade.result198, ptr %current.mask, align 1
  %1411 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result198)
  br i1 %1411, label %schedule.8, label %scheduler.loop

convergence.cascade235:                           ; preds = %convergence.cascade235, %schedule.8
  %convergence.cascade.flow239 = phi <8 x i1> [ %396, %schedule.8 ], [ %1454, %convergence.cascade235 ]
  %convergence.cascade.depth240 = phi i32 [ 0, %schedule.8 ], [ %1455, %convergence.cascade235 ]
  %1412 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow239)
  %1413 = load i32, ptr %current.token, align 4
  %1414 = icmp ne i32 %1413, 0
  %1415 = and i1 %1412, %1414
  %1416 = sub i32 %1413, 1
  %1417 = select i1 %1415, i32 %1416, i32 0
  %1418 = load i8, ptr %frame.active, align 1
  %1419 = trunc i32 %1417 to i8
  %1420 = shl i8 1, %1419
  %1421 = and i8 %1418, %1420
  %1422 = icmp ne i8 %1421, 0
  %1423 = load <8 x i32>, ptr %frame.static.id, align 32
  %1424 = extractelement <8 x i32> %1423, i32 %1417
  %convergence.target.pointer241 = getelementptr inbounds [6 x i32], ptr @convergence.targets, i32 0, i32 %1424
  %convergence.dynamic.target242 = load i32, ptr %convergence.target.pointer241, align 4
  %1425 = icmp eq i32 %convergence.dynamic.target242, 8
  %1426 = and i1 %1422, %1425
  %1427 = and i1 %1415, %1426
  %1428 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1417
  %1429 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1417
  %1430 = load <8 x i1>, ptr %1428, align 1
  %1431 = load <8 x i1>, ptr %1429, align 1
  %1432 = or <8 x i1> %1431, %convergence.cascade.flow239
  %1433 = load <8 x i1>, ptr %live.mask, align 1
  %1434 = and <8 x i1> %1430, %1433
  %1435 = icmp eq <8 x i1> %1432, %1434
  %1436 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1435)
  %1437 = and i1 %1427, %1436
  %1438 = select i1 %1437, <8 x i1> zeroinitializer, <8 x i1> %1432
  %1439 = select i1 %1427, <8 x i1> %1438, <8 x i1> %1431
  store <8 x i1> %1439, ptr %1429, align 1
  %1440 = select i1 %1437, <8 x i1> zeroinitializer, <8 x i1> %1430
  store <8 x i1> %1440, ptr %1428, align 1
  %1441 = trunc i32 %1417 to i8
  %1442 = shl i8 1, %1441
  %1443 = xor i8 %1442, -1
  %1444 = and i8 %1418, %1443
  %1445 = select i1 %1437, i8 %1444, i8 %1418
  store i8 %1445, ptr %frame.active, align 1
  %.splatinsert243 = insertelement <8 x i1> poison, i1 %1427, i64 0
  %.splat244 = shufflevector <8 x i1> %.splatinsert243, <8 x i1> poison, <8 x i32> zeroinitializer
  %1446 = and <8 x i1> %convergence.cascade.flow239, %.splat244
  %1447 = load <8 x i1>, ptr %runnable.mask, align 1
  %1448 = xor <8 x i1> %1446, splat (i1 true)
  %1449 = and <8 x i1> %1447, %1448
  store <8 x i1> %1449, ptr %runnable.mask, align 1
  %.splatinsert245 = insertelement <8 x i1> poison, i1 %1437, i64 0
  %.splat246 = shufflevector <8 x i1> %.splatinsert245, <8 x i1> poison, <8 x i32> zeroinitializer
  %1450 = select <8 x i1> %.splat246, <8 x i1> %1432, <8 x i1> zeroinitializer
  %1451 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1452 = extractelement <8 x i32> %1451, i32 %1417
  %1453 = select i1 %1437, i32 %1452, i32 %1413
  store i32 %1453, ptr %current.token, align 4
  %.splatinsert247 = insertelement <8 x i1> poison, i1 %1427, i64 0
  %.splat248 = shufflevector <8 x i1> %.splatinsert247, <8 x i1> poison, <8 x i32> zeroinitializer
  %1454 = select <8 x i1> %.splat248, <8 x i1> %1450, <8 x i1> %convergence.cascade.flow239
  %1455 = add i32 %convergence.cascade.depth240, 1
  %1456 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1454)
  %1457 = icmp ult i32 %1455, 8
  %1458 = and i1 %1456, %1457
  %1459 = and i1 %1427, %1458
  %convergence.parent.token249 = load i32, ptr %current.token, align 4
  %convergence.parent.present250 = icmp ne i32 %convergence.parent.token249, 0
  %1460 = and i1 %1459, %convergence.parent.present250
  br i1 %1460, label %convergence.cascade235, label %convergence.cascade.exit236

convergence.cascade.exit236:                      ; preds = %convergence.cascade235, %schedule.8
  %convergence.cascade.result251 = phi <8 x i1> [ %396, %schedule.8 ], [ %1454, %convergence.cascade235 ]
  %1461 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result251)
  br i1 %1461, label %convergence.target.8.ready, label %scheduler.loop

convergence.target.8.ready:                       ; preds = %convergence.cascade.exit236
  %1462 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result251)
  %1463 = bitcast <8 x i1> %convergence.cascade.result251 to i8
  %1464 = call i8 @llvm.cttz.i8(i8 %1463, i1 false)
  %1465 = zext i8 %1464 to i32
  %1466 = select i1 %1462, i32 %1465, i32 0
  %.spill.load252 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill15, align 64
  %1467 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1468 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load252, 1
  %1469 = extractelement <8 x ptr> %1467, i32 0
  %1470 = extractelement <8 x i64> %1468, i32 %1466
  %1471 = zext i32 %1466 to i64
  %1472 = mul i64 %1471, 4
  %1473 = sub i64 %1470, %1472
  %1474 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result251)
  %1475 = select i1 %1474, i64 %1473, i64 0
  %private.contiguous.address253 = getelementptr i8, ptr %1469, i64 %1475
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address253, align 4
  %1476 = select <8 x i1> %convergence.cascade.result251, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %.spill.load254 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill41, align 64
  %1477 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1478 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load254, 1
  %1479 = extractelement <8 x ptr> %1477, i32 0
  %1480 = extractelement <8 x i64> %1478, i32 %1466
  %1481 = zext i32 %1466 to i64
  %1482 = mul i64 %1481, 4
  %1483 = sub i64 %1480, %1482
  %1484 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result251)
  %1485 = select i1 %1484, i64 %1483, i64 0
  %private.contiguous.address255 = getelementptr i8, ptr %1479, i64 %1485
  %private.contiguous.load256 = load <8 x float>, ptr %private.contiguous.address255, align 4
  %1486 = select <8 x i1> %convergence.cascade.result251, <8 x float> %private.contiguous.load256, <8 x float> zeroinitializer
  %1487 = fmul <8 x float> %1476, %1486
  %.spill.load257 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill31, align 64
  %1488 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1489 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load257, 1
  %1490 = extractelement <8 x ptr> %1488, i32 0
  %1491 = extractelement <8 x i64> %1489, i32 %1466
  %1492 = zext i32 %1466 to i64
  %1493 = mul i64 %1492, 4
  %1494 = sub i64 %1491, %1493
  %1495 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result251)
  %1496 = select i1 %1495, i64 %1494, i64 0
  %private.contiguous.address258 = getelementptr i8, ptr %1490, i64 %1496
  %private.contiguous.load259 = load <8 x float>, ptr %private.contiguous.address258, align 4
  %1497 = select <8 x i1> %convergence.cascade.result251, <8 x float> %private.contiguous.load259, <8 x float> zeroinitializer
  %.spill.load260 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill49, align 64
  %1498 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1499 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load260, 1
  %1500 = extractelement <8 x ptr> %1498, i32 0
  %1501 = extractelement <8 x i64> %1499, i32 %1466
  %1502 = zext i32 %1466 to i64
  %1503 = mul i64 %1502, 4
  %1504 = sub i64 %1501, %1503
  %1505 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result251)
  %1506 = select i1 %1505, i64 %1504, i64 0
  %private.contiguous.address261 = getelementptr i8, ptr %1500, i64 %1506
  %private.contiguous.load262 = load <8 x float>, ptr %private.contiguous.address261, align 4
  %1507 = select <8 x i1> %convergence.cascade.result251, <8 x float> %private.contiguous.load262, <8 x float> zeroinitializer
  %1508 = fmul <8 x float> %1497, %1507
  %1509 = fsub <8 x float> %1487, %1508
  %.spill.load263 = load volatile <8 x i64>, ptr %.spill14, align 64
  %1510 = extractvalue { ptr, i64 } %31, 0
  %1511 = extractelement <8 x i64> %.spill.load263, i32 %1466
  %1512 = zext i32 %1466 to i64
  %1513 = sub i64 %1511, %1512
  %1514 = mul i64 %1513, 4
  %buffer.contiguous.address264 = getelementptr i8, ptr %1510, i64 %1514
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1509, ptr %buffer.contiguous.address264, i32 1, <8 x i1> %convergence.cascade.result251)
  %.spill.load265 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill19, align 64
  %1515 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1516 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load265, 1
  %1517 = extractelement <8 x ptr> %1515, i32 0
  %1518 = extractelement <8 x i64> %1516, i32 %1466
  %1519 = zext i32 %1466 to i64
  %1520 = mul i64 %1519, 4
  %1521 = sub i64 %1518, %1520
  %1522 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result251)
  %1523 = select i1 %1522, i64 %1521, i64 0
  %private.contiguous.address266 = getelementptr i8, ptr %1517, i64 %1523
  %private.contiguous.load267 = load <8 x float>, ptr %private.contiguous.address266, align 4
  %1524 = select <8 x i1> %convergence.cascade.result251, <8 x float> %private.contiguous.load267, <8 x float> zeroinitializer
  %.spill.load268 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill43, align 64
  %1525 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1526 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load268, 1
  %1527 = extractelement <8 x ptr> %1525, i32 0
  %1528 = extractelement <8 x i64> %1526, i32 %1466
  %1529 = zext i32 %1466 to i64
  %1530 = mul i64 %1529, 4
  %1531 = sub i64 %1528, %1530
  %1532 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result251)
  %1533 = select i1 %1532, i64 %1531, i64 0
  %private.contiguous.address269 = getelementptr i8, ptr %1527, i64 %1533
  %private.contiguous.load270 = load <8 x float>, ptr %private.contiguous.address269, align 4
  %1534 = select <8 x i1> %convergence.cascade.result251, <8 x float> %private.contiguous.load270, <8 x float> zeroinitializer
  %1535 = fmul <8 x float> %1524, %1534
  %.spill.load271 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill33, align 64
  %1536 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1537 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load271, 1
  %1538 = extractelement <8 x ptr> %1536, i32 0
  %1539 = extractelement <8 x i64> %1537, i32 %1466
  %1540 = zext i32 %1466 to i64
  %1541 = mul i64 %1540, 4
  %1542 = sub i64 %1539, %1541
  %1543 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result251)
  %1544 = select i1 %1543, i64 %1542, i64 0
  %private.contiguous.address272 = getelementptr i8, ptr %1538, i64 %1544
  %private.contiguous.load273 = load <8 x float>, ptr %private.contiguous.address272, align 4
  %1545 = select <8 x i1> %convergence.cascade.result251, <8 x float> %private.contiguous.load273, <8 x float> zeroinitializer
  %.spill.load274 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill50, align 64
  %1546 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1547 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load274, 1
  %1548 = extractelement <8 x ptr> %1546, i32 0
  %1549 = extractelement <8 x i64> %1547, i32 %1466
  %1550 = zext i32 %1466 to i64
  %1551 = mul i64 %1550, 4
  %1552 = sub i64 %1549, %1551
  %1553 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result251)
  %1554 = select i1 %1553, i64 %1552, i64 0
  %private.contiguous.address275 = getelementptr i8, ptr %1548, i64 %1554
  %private.contiguous.load276 = load <8 x float>, ptr %private.contiguous.address275, align 4
  %1555 = select <8 x i1> %convergence.cascade.result251, <8 x float> %private.contiguous.load276, <8 x float> zeroinitializer
  %1556 = fmul <8 x float> %1545, %1555
  %1557 = fsub <8 x float> %1535, %1556
  %.spill.load277 = load volatile <8 x i64>, ptr %.spill18, align 64
  %1558 = extractvalue { ptr, i64 } %31, 0
  %1559 = extractelement <8 x i64> %.spill.load277, i32 %1466
  %1560 = zext i32 %1466 to i64
  %1561 = sub i64 %1559, %1560
  %1562 = mul i64 %1561, 4
  %buffer.contiguous.address278 = getelementptr i8, ptr %1558, i64 %1562
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1557, ptr %buffer.contiguous.address278, i32 1, <8 x i1> %convergence.cascade.result251)
  %.spill.load279 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill23, align 64
  %1563 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1564 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load279, 1
  %1565 = extractelement <8 x ptr> %1563, i32 0
  %1566 = extractelement <8 x i64> %1564, i32 %1466
  %1567 = zext i32 %1466 to i64
  %1568 = mul i64 %1567, 4
  %1569 = sub i64 %1566, %1568
  %1570 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result251)
  %1571 = select i1 %1570, i64 %1569, i64 0
  %private.contiguous.address280 = getelementptr i8, ptr %1565, i64 %1571
  %private.contiguous.load281 = load <8 x float>, ptr %private.contiguous.address280, align 4
  %1572 = select <8 x i1> %convergence.cascade.result251, <8 x float> %private.contiguous.load281, <8 x float> zeroinitializer
  %.spill.load282 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill45, align 64
  %1573 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1574 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load282, 1
  %1575 = extractelement <8 x ptr> %1573, i32 0
  %1576 = extractelement <8 x i64> %1574, i32 %1466
  %1577 = zext i32 %1466 to i64
  %1578 = mul i64 %1577, 4
  %1579 = sub i64 %1576, %1578
  %1580 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result251)
  %1581 = select i1 %1580, i64 %1579, i64 0
  %private.contiguous.address283 = getelementptr i8, ptr %1575, i64 %1581
  %private.contiguous.load284 = load <8 x float>, ptr %private.contiguous.address283, align 4
  %1582 = select <8 x i1> %convergence.cascade.result251, <8 x float> %private.contiguous.load284, <8 x float> zeroinitializer
  %1583 = fmul <8 x float> %1572, %1582
  %.spill.load285 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill35, align 64
  %1584 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1585 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load285, 1
  %1586 = extractelement <8 x ptr> %1584, i32 0
  %1587 = extractelement <8 x i64> %1585, i32 %1466
  %1588 = zext i32 %1466 to i64
  %1589 = mul i64 %1588, 4
  %1590 = sub i64 %1587, %1589
  %1591 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result251)
  %1592 = select i1 %1591, i64 %1590, i64 0
  %private.contiguous.address286 = getelementptr i8, ptr %1586, i64 %1592
  %private.contiguous.load287 = load <8 x float>, ptr %private.contiguous.address286, align 4
  %1593 = select <8 x i1> %convergence.cascade.result251, <8 x float> %private.contiguous.load287, <8 x float> zeroinitializer
  %.spill.load288 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill51, align 64
  %1594 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1595 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load288, 1
  %1596 = extractelement <8 x ptr> %1594, i32 0
  %1597 = extractelement <8 x i64> %1595, i32 %1466
  %1598 = zext i32 %1466 to i64
  %1599 = mul i64 %1598, 4
  %1600 = sub i64 %1597, %1599
  %1601 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result251)
  %1602 = select i1 %1601, i64 %1600, i64 0
  %private.contiguous.address289 = getelementptr i8, ptr %1596, i64 %1602
  %private.contiguous.load290 = load <8 x float>, ptr %private.contiguous.address289, align 4
  %1603 = select <8 x i1> %convergence.cascade.result251, <8 x float> %private.contiguous.load290, <8 x float> zeroinitializer
  %1604 = fmul <8 x float> %1593, %1603
  %1605 = fsub <8 x float> %1583, %1604
  %.spill.load291 = load volatile <8 x i64>, ptr %.spill22, align 64
  %1606 = extractvalue { ptr, i64 } %31, 0
  %1607 = extractelement <8 x i64> %.spill.load291, i32 %1466
  %1608 = zext i32 %1466 to i64
  %1609 = sub i64 %1607, %1608
  %1610 = mul i64 %1609, 4
  %buffer.contiguous.address292 = getelementptr i8, ptr %1606, i64 %1610
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1605, ptr %buffer.contiguous.address292, i32 1, <8 x i1> %convergence.cascade.result251)
  %.spill.load293 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill27, align 64
  %1611 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1612 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load293, 1
  %1613 = extractelement <8 x ptr> %1611, i32 0
  %1614 = extractelement <8 x i64> %1612, i32 %1466
  %1615 = zext i32 %1466 to i64
  %1616 = mul i64 %1615, 4
  %1617 = sub i64 %1614, %1616
  %1618 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result251)
  %1619 = select i1 %1618, i64 %1617, i64 0
  %private.contiguous.address294 = getelementptr i8, ptr %1613, i64 %1619
  %private.contiguous.load295 = load <8 x float>, ptr %private.contiguous.address294, align 4
  %1620 = select <8 x i1> %convergence.cascade.result251, <8 x float> %private.contiguous.load295, <8 x float> zeroinitializer
  %.spill.load296 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill47, align 64
  %1621 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1622 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load296, 1
  %1623 = extractelement <8 x ptr> %1621, i32 0
  %1624 = extractelement <8 x i64> %1622, i32 %1466
  %1625 = zext i32 %1466 to i64
  %1626 = mul i64 %1625, 4
  %1627 = sub i64 %1624, %1626
  %1628 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result251)
  %1629 = select i1 %1628, i64 %1627, i64 0
  %private.contiguous.address297 = getelementptr i8, ptr %1623, i64 %1629
  %private.contiguous.load298 = load <8 x float>, ptr %private.contiguous.address297, align 4
  %1630 = select <8 x i1> %convergence.cascade.result251, <8 x float> %private.contiguous.load298, <8 x float> zeroinitializer
  %1631 = fmul <8 x float> %1620, %1630
  %.spill.load299 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill37, align 64
  %1632 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1633 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load299, 1
  %1634 = extractelement <8 x ptr> %1632, i32 0
  %1635 = extractelement <8 x i64> %1633, i32 %1466
  %1636 = zext i32 %1466 to i64
  %1637 = mul i64 %1636, 4
  %1638 = sub i64 %1635, %1637
  %1639 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result251)
  %1640 = select i1 %1639, i64 %1638, i64 0
  %private.contiguous.address300 = getelementptr i8, ptr %1634, i64 %1640
  %private.contiguous.load301 = load <8 x float>, ptr %private.contiguous.address300, align 4
  %1641 = select <8 x i1> %convergence.cascade.result251, <8 x float> %private.contiguous.load301, <8 x float> zeroinitializer
  %.spill.load302 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill52, align 64
  %1642 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1643 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load302, 1
  %1644 = extractelement <8 x ptr> %1642, i32 0
  %1645 = extractelement <8 x i64> %1643, i32 %1466
  %1646 = zext i32 %1466 to i64
  %1647 = mul i64 %1646, 4
  %1648 = sub i64 %1645, %1647
  %1649 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result251)
  %1650 = select i1 %1649, i64 %1648, i64 0
  %private.contiguous.address303 = getelementptr i8, ptr %1644, i64 %1650
  %private.contiguous.load304 = load <8 x float>, ptr %private.contiguous.address303, align 4
  %1651 = select <8 x i1> %convergence.cascade.result251, <8 x float> %private.contiguous.load304, <8 x float> zeroinitializer
  %1652 = fmul <8 x float> %1641, %1651
  %1653 = fsub <8 x float> %1631, %1652
  %.spill.load305 = load volatile <8 x i64>, ptr %.spill26, align 64
  %1654 = extractvalue { ptr, i64 } %31, 0
  %1655 = extractelement <8 x i64> %.spill.load305, i32 %1466
  %1656 = zext i32 %1466 to i64
  %1657 = sub i64 %1655, %1656
  %1658 = mul i64 %1657, 4
  %buffer.contiguous.address306 = getelementptr i8, ptr %1654, i64 %1658
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1653, ptr %buffer.contiguous.address306, i32 1, <8 x i1> %convergence.cascade.result251)
  %.spill.load307 = load <8 x i1>, ptr %.spill28, align 1
  %1659 = and <8 x i1> %convergence.cascade.result251, %.spill.load307
  %1660 = xor <8 x i1> %.spill.load307, splat (i1 true)
  %1661 = and <8 x i1> %convergence.cascade.result251, %1660
  %1662 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1659)
  %1663 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1661)
  %1664 = and i1 %1662, %1663
  br i1 %1664, label %varying.divergent308, label %varying.coherent309

varying.divergent308:                             ; preds = %convergence.target.8.ready
  %1665 = load i32, ptr %current.token, align 4
  %1666 = icmp ne i32 %1665, 0
  %1667 = sub i32 %1665, 1
  %1668 = select i1 %1666, i32 %1667, i32 0
  %1669 = load i8, ptr %frame.active, align 1
  %1670 = trunc i32 %1668 to i8
  %1671 = shl i8 1, %1670
  %1672 = and i8 %1669, %1671
  %1673 = icmp ne i8 %1672, 0
  %1674 = load <8 x i32>, ptr %frame.static.id, align 32
  %1675 = extractelement <8 x i32> %1674, i32 %1668
  %1676 = icmp eq i32 %1675, 4
  %1677 = and i1 %1673, %1676
  %1678 = and i1 %1666, %1677
  %1679 = xor i1 %1678, true
  %1680 = and i1 true, %1679
  %1681 = xor i8 %1669, -1
  %1682 = icmp ne i8 %1681, 0
  %1683 = xor i1 %1682, true
  %1684 = and i1 %1680, %1683
  br i1 %1684, label %convergence.overflow.trap310, label %convergence.overflow.resume311

varying.coherent309:                              ; preds = %convergence.target.8.ready
  br i1 %1662, label %varying.coherent.true314, label %varying.coherent.false315

convergence.overflow.trap310:                     ; preds = %varying.divergent308
  call void @llvm.trap()
  unreachable

convergence.overflow.resume311:                   ; preds = %varying.divergent308
  %1685 = call i8 @llvm.cttz.i8(i8 %1681, i1 false)
  %1686 = zext i8 %1685 to i32
  %1687 = select i1 %1682, i32 %1686, i32 0
  %1688 = trunc i32 %1687 to i8
  %1689 = shl i8 1, %1688
  %1690 = or i8 %1669, %1689
  %1691 = select i1 %1680, i8 %1690, i8 %1669
  store i8 %1691, ptr %frame.active, align 1
  %1692 = load <8 x i32>, ptr %frame.static.id, align 32
  %1693 = extractelement <8 x i32> %1692, i32 %1687
  %1694 = select i1 %1680, i32 4, i32 %1693
  %1695 = load <8 x i32>, ptr %frame.static.id, align 32
  %1696 = insertelement <8 x i32> %1695, i32 %1694, i32 %1687
  store <8 x i32> %1696, ptr %frame.static.id, align 32
  %1697 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1698 = extractelement <8 x i32> %1697, i32 %1687
  %1699 = select i1 %1680, i32 %1665, i32 %1698
  %1700 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1701 = insertelement <8 x i32> %1700, i32 %1699, i32 %1687
  store <8 x i32> %1701, ptr %frame.parent.token, align 32
  %1702 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1687
  %1703 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1687
  %1704 = load <8 x i1>, ptr %1702, align 1
  %1705 = load <8 x i1>, ptr %1703, align 1
  %1706 = select i1 %1680, <8 x i1> %convergence.cascade.result251, <8 x i1> %1704
  store <8 x i1> %1706, ptr %1702, align 1
  %1707 = select i1 %1680, <8 x i1> zeroinitializer, <8 x i1> %1705
  store <8 x i1> %1707, ptr %1703, align 1
  %1708 = add i32 %1687, 1
  %1709 = select i1 %1678, i32 %1665, i32 %1708
  %1710 = select i1 true, i32 %1709, i32 %1665
  store i32 %1710, ptr %current.token, align 4
  %1711 = load i32, ptr %current.token, align 4
  %1712 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1659)
  %1713 = load i32, ptr %ready.count, align 4
  %1714 = icmp uge i32 %1713, 8
  %1715 = and i1 %1712, %1714
  br i1 %1715, label %ready.overflow.trap312, label %ready.overflow.resume313

ready.overflow.trap312:                           ; preds = %convergence.overflow.resume311
  call void @llvm.trap()
  unreachable

ready.overflow.resume313:                         ; preds = %convergence.overflow.resume311
  %1716 = select i1 %1712, i32 %1713, i32 0
  %1717 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1716
  %1718 = load <8 x i1>, ptr %1717, align 1
  %1719 = select i1 %1712, <8 x i1> %1659, <8 x i1> %1718
  store <8 x i1> %1719, ptr %1717, align 1
  %1720 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1716
  %1721 = load i32, ptr %1720, align 4
  %1722 = select i1 %1712, i32 9, i32 %1721
  store i32 %1722, ptr %1720, align 4
  %1723 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1716
  %1724 = load i32, ptr %1723, align 4
  %1725 = select i1 %1712, i32 %1711, i32 %1724
  store i32 %1725, ptr %1723, align 4
  %1726 = add i32 %1713, 1
  %1727 = select i1 %1712, i32 %1726, i32 %1713
  store i32 %1727, ptr %ready.count, align 4
  %1728 = load <8 x i1>, ptr %runnable.mask, align 1
  %1729 = or <8 x i1> %1728, %1659
  store <8 x i1> %1729, ptr %runnable.mask, align 1
  store <8 x i1> %1661, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true314:                         ; preds = %varying.coherent309
  store <8 x i1> %convergence.cascade.result251, ptr %current.mask, align 1
  %1730 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result251)
  br i1 %1730, label %schedule.9, label %scheduler.loop

varying.coherent.false315:                        ; preds = %varying.coherent309
  store <8 x i1> %convergence.cascade.result251, ptr %current.mask, align 1
  %1731 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result251)
  br i1 %1731, label %schedule.10, label %scheduler.loop

convergence.cascade331:                           ; preds = %convergence.cascade331, %schedule.10
  %convergence.cascade.flow335 = phi <8 x i1> [ %475, %schedule.10 ], [ %1774, %convergence.cascade331 ]
  %convergence.cascade.depth336 = phi i32 [ 0, %schedule.10 ], [ %1775, %convergence.cascade331 ]
  %1732 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow335)
  %1733 = load i32, ptr %current.token, align 4
  %1734 = icmp ne i32 %1733, 0
  %1735 = and i1 %1732, %1734
  %1736 = sub i32 %1733, 1
  %1737 = select i1 %1735, i32 %1736, i32 0
  %1738 = load i8, ptr %frame.active, align 1
  %1739 = trunc i32 %1737 to i8
  %1740 = shl i8 1, %1739
  %1741 = and i8 %1738, %1740
  %1742 = icmp ne i8 %1741, 0
  %1743 = load <8 x i32>, ptr %frame.static.id, align 32
  %1744 = extractelement <8 x i32> %1743, i32 %1737
  %convergence.target.pointer337 = getelementptr inbounds [6 x i32], ptr @convergence.targets, i32 0, i32 %1744
  %convergence.dynamic.target338 = load i32, ptr %convergence.target.pointer337, align 4
  %1745 = icmp eq i32 %convergence.dynamic.target338, 10
  %1746 = and i1 %1742, %1745
  %1747 = and i1 %1735, %1746
  %1748 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1737
  %1749 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1737
  %1750 = load <8 x i1>, ptr %1748, align 1
  %1751 = load <8 x i1>, ptr %1749, align 1
  %1752 = or <8 x i1> %1751, %convergence.cascade.flow335
  %1753 = load <8 x i1>, ptr %live.mask, align 1
  %1754 = and <8 x i1> %1750, %1753
  %1755 = icmp eq <8 x i1> %1752, %1754
  %1756 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1755)
  %1757 = and i1 %1747, %1756
  %1758 = select i1 %1757, <8 x i1> zeroinitializer, <8 x i1> %1752
  %1759 = select i1 %1747, <8 x i1> %1758, <8 x i1> %1751
  store <8 x i1> %1759, ptr %1749, align 1
  %1760 = select i1 %1757, <8 x i1> zeroinitializer, <8 x i1> %1750
  store <8 x i1> %1760, ptr %1748, align 1
  %1761 = trunc i32 %1737 to i8
  %1762 = shl i8 1, %1761
  %1763 = xor i8 %1762, -1
  %1764 = and i8 %1738, %1763
  %1765 = select i1 %1757, i8 %1764, i8 %1738
  store i8 %1765, ptr %frame.active, align 1
  %.splatinsert339 = insertelement <8 x i1> poison, i1 %1747, i64 0
  %.splat340 = shufflevector <8 x i1> %.splatinsert339, <8 x i1> poison, <8 x i32> zeroinitializer
  %1766 = and <8 x i1> %convergence.cascade.flow335, %.splat340
  %1767 = load <8 x i1>, ptr %runnable.mask, align 1
  %1768 = xor <8 x i1> %1766, splat (i1 true)
  %1769 = and <8 x i1> %1767, %1768
  store <8 x i1> %1769, ptr %runnable.mask, align 1
  %.splatinsert341 = insertelement <8 x i1> poison, i1 %1757, i64 0
  %.splat342 = shufflevector <8 x i1> %.splatinsert341, <8 x i1> poison, <8 x i32> zeroinitializer
  %1770 = select <8 x i1> %.splat342, <8 x i1> %1752, <8 x i1> zeroinitializer
  %1771 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1772 = extractelement <8 x i32> %1771, i32 %1737
  %1773 = select i1 %1757, i32 %1772, i32 %1733
  store i32 %1773, ptr %current.token, align 4
  %.splatinsert343 = insertelement <8 x i1> poison, i1 %1747, i64 0
  %.splat344 = shufflevector <8 x i1> %.splatinsert343, <8 x i1> poison, <8 x i32> zeroinitializer
  %1774 = select <8 x i1> %.splat344, <8 x i1> %1770, <8 x i1> %convergence.cascade.flow335
  %1775 = add i32 %convergence.cascade.depth336, 1
  %1776 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1774)
  %1777 = icmp ult i32 %1775, 8
  %1778 = and i1 %1776, %1777
  %1779 = and i1 %1747, %1778
  %convergence.parent.token345 = load i32, ptr %current.token, align 4
  %convergence.parent.present346 = icmp ne i32 %convergence.parent.token345, 0
  %1780 = and i1 %1779, %convergence.parent.present346
  br i1 %1780, label %convergence.cascade331, label %convergence.cascade.exit332

convergence.cascade.exit332:                      ; preds = %convergence.cascade331, %schedule.10
  %convergence.cascade.result347 = phi <8 x i1> [ %475, %schedule.10 ], [ %1774, %convergence.cascade331 ]
  %1781 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result347)
  br i1 %1781, label %convergence.target.10.ready, label %scheduler.loop

convergence.target.10.ready:                      ; preds = %convergence.cascade.exit332
  %1782 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result347)
  %1783 = bitcast <8 x i1> %convergence.cascade.result347 to i8
  %1784 = call i8 @llvm.cttz.i8(i8 %1783, i1 false)
  %1785 = zext i8 %1784 to i32
  %1786 = select i1 %1782, i32 %1785, i32 0
  %.spill.load348 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill15, align 64
  %1787 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1788 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load348, 1
  %1789 = extractelement <8 x ptr> %1787, i32 0
  %1790 = extractelement <8 x i64> %1788, i32 %1786
  %1791 = zext i32 %1786 to i64
  %1792 = mul i64 %1791, 4
  %1793 = sub i64 %1790, %1792
  %1794 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result347)
  %1795 = select i1 %1794, i64 %1793, i64 0
  %private.contiguous.address349 = getelementptr i8, ptr %1789, i64 %1795
  %private.contiguous.load350 = load <8 x float>, ptr %private.contiguous.address349, align 4
  %1796 = select <8 x i1> %convergence.cascade.result347, <8 x float> %private.contiguous.load350, <8 x float> zeroinitializer
  %.spill.load351 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill49, align 64
  %1797 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1798 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load351, 1
  %1799 = extractelement <8 x ptr> %1797, i32 0
  %1800 = extractelement <8 x i64> %1798, i32 %1786
  %1801 = zext i32 %1786 to i64
  %1802 = mul i64 %1801, 4
  %1803 = sub i64 %1800, %1802
  %1804 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result347)
  %1805 = select i1 %1804, i64 %1803, i64 0
  %private.contiguous.address352 = getelementptr i8, ptr %1799, i64 %1805
  %private.contiguous.load353 = load <8 x float>, ptr %private.contiguous.address352, align 4
  %1806 = select <8 x i1> %convergence.cascade.result347, <8 x float> %private.contiguous.load353, <8 x float> zeroinitializer
  %1807 = fmul <8 x float> %1796, %1806
  %.spill.load354 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill31, align 64
  %1808 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1809 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load354, 1
  %1810 = extractelement <8 x ptr> %1808, i32 0
  %1811 = extractelement <8 x i64> %1809, i32 %1786
  %1812 = zext i32 %1786 to i64
  %1813 = mul i64 %1812, 4
  %1814 = sub i64 %1811, %1813
  %1815 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result347)
  %1816 = select i1 %1815, i64 %1814, i64 0
  %private.contiguous.address355 = getelementptr i8, ptr %1810, i64 %1816
  %private.contiguous.load356 = load <8 x float>, ptr %private.contiguous.address355, align 4
  %1817 = select <8 x i1> %convergence.cascade.result347, <8 x float> %private.contiguous.load356, <8 x float> zeroinitializer
  %.spill.load357 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill41, align 64
  %1818 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1819 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load357, 1
  %1820 = extractelement <8 x ptr> %1818, i32 0
  %1821 = extractelement <8 x i64> %1819, i32 %1786
  %1822 = zext i32 %1786 to i64
  %1823 = mul i64 %1822, 4
  %1824 = sub i64 %1821, %1823
  %1825 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result347)
  %1826 = select i1 %1825, i64 %1824, i64 0
  %private.contiguous.address358 = getelementptr i8, ptr %1820, i64 %1826
  %private.contiguous.load359 = load <8 x float>, ptr %private.contiguous.address358, align 4
  %1827 = select <8 x i1> %convergence.cascade.result347, <8 x float> %private.contiguous.load359, <8 x float> zeroinitializer
  %1828 = fmul <8 x float> %1817, %1827
  %1829 = fadd <8 x float> %1807, %1828
  %.spill.load360 = load volatile <8 x i64>, ptr %.spill30, align 64
  %1830 = extractvalue { ptr, i64 } %31, 0
  %1831 = extractelement <8 x i64> %.spill.load360, i32 %1786
  %1832 = zext i32 %1786 to i64
  %1833 = sub i64 %1831, %1832
  %1834 = mul i64 %1833, 4
  %buffer.contiguous.address361 = getelementptr i8, ptr %1830, i64 %1834
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1829, ptr %buffer.contiguous.address361, i32 1, <8 x i1> %convergence.cascade.result347)
  %.spill.load362 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill19, align 64
  %1835 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1836 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load362, 1
  %1837 = extractelement <8 x ptr> %1835, i32 0
  %1838 = extractelement <8 x i64> %1836, i32 %1786
  %1839 = zext i32 %1786 to i64
  %1840 = mul i64 %1839, 4
  %1841 = sub i64 %1838, %1840
  %1842 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result347)
  %1843 = select i1 %1842, i64 %1841, i64 0
  %private.contiguous.address363 = getelementptr i8, ptr %1837, i64 %1843
  %private.contiguous.load364 = load <8 x float>, ptr %private.contiguous.address363, align 4
  %1844 = select <8 x i1> %convergence.cascade.result347, <8 x float> %private.contiguous.load364, <8 x float> zeroinitializer
  %.spill.load365 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill50, align 64
  %1845 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1846 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load365, 1
  %1847 = extractelement <8 x ptr> %1845, i32 0
  %1848 = extractelement <8 x i64> %1846, i32 %1786
  %1849 = zext i32 %1786 to i64
  %1850 = mul i64 %1849, 4
  %1851 = sub i64 %1848, %1850
  %1852 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result347)
  %1853 = select i1 %1852, i64 %1851, i64 0
  %private.contiguous.address366 = getelementptr i8, ptr %1847, i64 %1853
  %private.contiguous.load367 = load <8 x float>, ptr %private.contiguous.address366, align 4
  %1854 = select <8 x i1> %convergence.cascade.result347, <8 x float> %private.contiguous.load367, <8 x float> zeroinitializer
  %1855 = fmul <8 x float> %1844, %1854
  %.spill.load368 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill33, align 64
  %1856 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1857 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load368, 1
  %1858 = extractelement <8 x ptr> %1856, i32 0
  %1859 = extractelement <8 x i64> %1857, i32 %1786
  %1860 = zext i32 %1786 to i64
  %1861 = mul i64 %1860, 4
  %1862 = sub i64 %1859, %1861
  %1863 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result347)
  %1864 = select i1 %1863, i64 %1862, i64 0
  %private.contiguous.address369 = getelementptr i8, ptr %1858, i64 %1864
  %private.contiguous.load370 = load <8 x float>, ptr %private.contiguous.address369, align 4
  %1865 = select <8 x i1> %convergence.cascade.result347, <8 x float> %private.contiguous.load370, <8 x float> zeroinitializer
  %.spill.load371 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill43, align 64
  %1866 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1867 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load371, 1
  %1868 = extractelement <8 x ptr> %1866, i32 0
  %1869 = extractelement <8 x i64> %1867, i32 %1786
  %1870 = zext i32 %1786 to i64
  %1871 = mul i64 %1870, 4
  %1872 = sub i64 %1869, %1871
  %1873 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result347)
  %1874 = select i1 %1873, i64 %1872, i64 0
  %private.contiguous.address372 = getelementptr i8, ptr %1868, i64 %1874
  %private.contiguous.load373 = load <8 x float>, ptr %private.contiguous.address372, align 4
  %1875 = select <8 x i1> %convergence.cascade.result347, <8 x float> %private.contiguous.load373, <8 x float> zeroinitializer
  %1876 = fmul <8 x float> %1865, %1875
  %1877 = fadd <8 x float> %1855, %1876
  %.spill.load374 = load volatile <8 x i64>, ptr %.spill32, align 64
  %1878 = extractvalue { ptr, i64 } %31, 0
  %1879 = extractelement <8 x i64> %.spill.load374, i32 %1786
  %1880 = zext i32 %1786 to i64
  %1881 = sub i64 %1879, %1880
  %1882 = mul i64 %1881, 4
  %buffer.contiguous.address375 = getelementptr i8, ptr %1878, i64 %1882
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1877, ptr %buffer.contiguous.address375, i32 1, <8 x i1> %convergence.cascade.result347)
  %.spill.load376 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill23, align 64
  %1883 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1884 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load376, 1
  %1885 = extractelement <8 x ptr> %1883, i32 0
  %1886 = extractelement <8 x i64> %1884, i32 %1786
  %1887 = zext i32 %1786 to i64
  %1888 = mul i64 %1887, 4
  %1889 = sub i64 %1886, %1888
  %1890 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result347)
  %1891 = select i1 %1890, i64 %1889, i64 0
  %private.contiguous.address377 = getelementptr i8, ptr %1885, i64 %1891
  %private.contiguous.load378 = load <8 x float>, ptr %private.contiguous.address377, align 4
  %1892 = select <8 x i1> %convergence.cascade.result347, <8 x float> %private.contiguous.load378, <8 x float> zeroinitializer
  %.spill.load379 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill51, align 64
  %1893 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1894 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load379, 1
  %1895 = extractelement <8 x ptr> %1893, i32 0
  %1896 = extractelement <8 x i64> %1894, i32 %1786
  %1897 = zext i32 %1786 to i64
  %1898 = mul i64 %1897, 4
  %1899 = sub i64 %1896, %1898
  %1900 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result347)
  %1901 = select i1 %1900, i64 %1899, i64 0
  %private.contiguous.address380 = getelementptr i8, ptr %1895, i64 %1901
  %private.contiguous.load381 = load <8 x float>, ptr %private.contiguous.address380, align 4
  %1902 = select <8 x i1> %convergence.cascade.result347, <8 x float> %private.contiguous.load381, <8 x float> zeroinitializer
  %1903 = fmul <8 x float> %1892, %1902
  %.spill.load382 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill35, align 64
  %1904 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1905 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load382, 1
  %1906 = extractelement <8 x ptr> %1904, i32 0
  %1907 = extractelement <8 x i64> %1905, i32 %1786
  %1908 = zext i32 %1786 to i64
  %1909 = mul i64 %1908, 4
  %1910 = sub i64 %1907, %1909
  %1911 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result347)
  %1912 = select i1 %1911, i64 %1910, i64 0
  %private.contiguous.address383 = getelementptr i8, ptr %1906, i64 %1912
  %private.contiguous.load384 = load <8 x float>, ptr %private.contiguous.address383, align 4
  %1913 = select <8 x i1> %convergence.cascade.result347, <8 x float> %private.contiguous.load384, <8 x float> zeroinitializer
  %.spill.load385 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill45, align 64
  %1914 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1915 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load385, 1
  %1916 = extractelement <8 x ptr> %1914, i32 0
  %1917 = extractelement <8 x i64> %1915, i32 %1786
  %1918 = zext i32 %1786 to i64
  %1919 = mul i64 %1918, 4
  %1920 = sub i64 %1917, %1919
  %1921 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result347)
  %1922 = select i1 %1921, i64 %1920, i64 0
  %private.contiguous.address386 = getelementptr i8, ptr %1916, i64 %1922
  %private.contiguous.load387 = load <8 x float>, ptr %private.contiguous.address386, align 4
  %1923 = select <8 x i1> %convergence.cascade.result347, <8 x float> %private.contiguous.load387, <8 x float> zeroinitializer
  %1924 = fmul <8 x float> %1913, %1923
  %1925 = fadd <8 x float> %1903, %1924
  %.spill.load388 = load volatile <8 x i64>, ptr %.spill34, align 64
  %1926 = extractvalue { ptr, i64 } %31, 0
  %1927 = extractelement <8 x i64> %.spill.load388, i32 %1786
  %1928 = zext i32 %1786 to i64
  %1929 = sub i64 %1927, %1928
  %1930 = mul i64 %1929, 4
  %buffer.contiguous.address389 = getelementptr i8, ptr %1926, i64 %1930
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1925, ptr %buffer.contiguous.address389, i32 1, <8 x i1> %convergence.cascade.result347)
  %.spill.load390 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill27, align 64
  %1931 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1932 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load390, 1
  %1933 = extractelement <8 x ptr> %1931, i32 0
  %1934 = extractelement <8 x i64> %1932, i32 %1786
  %1935 = zext i32 %1786 to i64
  %1936 = mul i64 %1935, 4
  %1937 = sub i64 %1934, %1936
  %1938 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result347)
  %1939 = select i1 %1938, i64 %1937, i64 0
  %private.contiguous.address391 = getelementptr i8, ptr %1933, i64 %1939
  %private.contiguous.load392 = load <8 x float>, ptr %private.contiguous.address391, align 4
  %1940 = select <8 x i1> %convergence.cascade.result347, <8 x float> %private.contiguous.load392, <8 x float> zeroinitializer
  %.spill.load393 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill52, align 64
  %1941 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1942 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load393, 1
  %1943 = extractelement <8 x ptr> %1941, i32 0
  %1944 = extractelement <8 x i64> %1942, i32 %1786
  %1945 = zext i32 %1786 to i64
  %1946 = mul i64 %1945, 4
  %1947 = sub i64 %1944, %1946
  %1948 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result347)
  %1949 = select i1 %1948, i64 %1947, i64 0
  %private.contiguous.address394 = getelementptr i8, ptr %1943, i64 %1949
  %private.contiguous.load395 = load <8 x float>, ptr %private.contiguous.address394, align 4
  %1950 = select <8 x i1> %convergence.cascade.result347, <8 x float> %private.contiguous.load395, <8 x float> zeroinitializer
  %1951 = fmul <8 x float> %1940, %1950
  %.spill.load396 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill37, align 64
  %1952 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1953 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load396, 1
  %1954 = extractelement <8 x ptr> %1952, i32 0
  %1955 = extractelement <8 x i64> %1953, i32 %1786
  %1956 = zext i32 %1786 to i64
  %1957 = mul i64 %1956, 4
  %1958 = sub i64 %1955, %1957
  %1959 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result347)
  %1960 = select i1 %1959, i64 %1958, i64 0
  %private.contiguous.address397 = getelementptr i8, ptr %1954, i64 %1960
  %private.contiguous.load398 = load <8 x float>, ptr %private.contiguous.address397, align 4
  %1961 = select <8 x i1> %convergence.cascade.result347, <8 x float> %private.contiguous.load398, <8 x float> zeroinitializer
  %.spill.load399 = load volatile { <8 x ptr>, <8 x i64> }, ptr %.spill47, align 64
  %1962 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1963 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load399, 1
  %1964 = extractelement <8 x ptr> %1962, i32 0
  %1965 = extractelement <8 x i64> %1963, i32 %1786
  %1966 = zext i32 %1786 to i64
  %1967 = mul i64 %1966, 4
  %1968 = sub i64 %1965, %1967
  %1969 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result347)
  %1970 = select i1 %1969, i64 %1968, i64 0
  %private.contiguous.address400 = getelementptr i8, ptr %1964, i64 %1970
  %private.contiguous.load401 = load <8 x float>, ptr %private.contiguous.address400, align 4
  %1971 = select <8 x i1> %convergence.cascade.result347, <8 x float> %private.contiguous.load401, <8 x float> zeroinitializer
  %1972 = fmul <8 x float> %1961, %1971
  %1973 = fadd <8 x float> %1951, %1972
  %.spill.load402 = load volatile <8 x i64>, ptr %.spill36, align 64
  %1974 = extractvalue { ptr, i64 } %31, 0
  %1975 = extractelement <8 x i64> %.spill.load402, i32 %1786
  %1976 = zext i32 %1786 to i64
  %1977 = sub i64 %1975, %1976
  %1978 = mul i64 %1977, 4
  %buffer.contiguous.address403 = getelementptr i8, ptr %1974, i64 %1978
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1973, ptr %buffer.contiguous.address403, i32 1, <8 x i1> %convergence.cascade.result347)
  %.spill.load404 = load <8 x i1>, ptr %.spill28, align 1
  %1979 = and <8 x i1> %convergence.cascade.result347, %.spill.load404
  %1980 = xor <8 x i1> %.spill.load404, splat (i1 true)
  %1981 = and <8 x i1> %convergence.cascade.result347, %1980
  %1982 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1979)
  %1983 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1981)
  %1984 = and i1 %1982, %1983
  br i1 %1984, label %varying.divergent405, label %varying.coherent406

varying.divergent405:                             ; preds = %convergence.target.10.ready
  %1985 = load i32, ptr %current.token, align 4
  %1986 = icmp ne i32 %1985, 0
  %1987 = sub i32 %1985, 1
  %1988 = select i1 %1986, i32 %1987, i32 0
  %1989 = load i8, ptr %frame.active, align 1
  %1990 = trunc i32 %1988 to i8
  %1991 = shl i8 1, %1990
  %1992 = and i8 %1989, %1991
  %1993 = icmp ne i8 %1992, 0
  %1994 = load <8 x i32>, ptr %frame.static.id, align 32
  %1995 = extractelement <8 x i32> %1994, i32 %1988
  %1996 = icmp eq i32 %1995, 5
  %1997 = and i1 %1993, %1996
  %1998 = and i1 %1986, %1997
  %1999 = xor i1 %1998, true
  %2000 = and i1 true, %1999
  %2001 = xor i8 %1989, -1
  %2002 = icmp ne i8 %2001, 0
  %2003 = xor i1 %2002, true
  %2004 = and i1 %2000, %2003
  br i1 %2004, label %convergence.overflow.trap407, label %convergence.overflow.resume408

varying.coherent406:                              ; preds = %convergence.target.10.ready
  br i1 %1982, label %varying.coherent.true411, label %varying.coherent.false412

convergence.overflow.trap407:                     ; preds = %varying.divergent405
  call void @llvm.trap()
  unreachable

convergence.overflow.resume408:                   ; preds = %varying.divergent405
  %2005 = call i8 @llvm.cttz.i8(i8 %2001, i1 false)
  %2006 = zext i8 %2005 to i32
  %2007 = select i1 %2002, i32 %2006, i32 0
  %2008 = trunc i32 %2007 to i8
  %2009 = shl i8 1, %2008
  %2010 = or i8 %1989, %2009
  %2011 = select i1 %2000, i8 %2010, i8 %1989
  store i8 %2011, ptr %frame.active, align 1
  %2012 = load <8 x i32>, ptr %frame.static.id, align 32
  %2013 = extractelement <8 x i32> %2012, i32 %2007
  %2014 = select i1 %2000, i32 5, i32 %2013
  %2015 = load <8 x i32>, ptr %frame.static.id, align 32
  %2016 = insertelement <8 x i32> %2015, i32 %2014, i32 %2007
  store <8 x i32> %2016, ptr %frame.static.id, align 32
  %2017 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2018 = extractelement <8 x i32> %2017, i32 %2007
  %2019 = select i1 %2000, i32 %1985, i32 %2018
  %2020 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2021 = insertelement <8 x i32> %2020, i32 %2019, i32 %2007
  store <8 x i32> %2021, ptr %frame.parent.token, align 32
  %2022 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2007
  %2023 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2007
  %2024 = load <8 x i1>, ptr %2022, align 1
  %2025 = load <8 x i1>, ptr %2023, align 1
  %2026 = select i1 %2000, <8 x i1> %convergence.cascade.result347, <8 x i1> %2024
  store <8 x i1> %2026, ptr %2022, align 1
  %2027 = select i1 %2000, <8 x i1> zeroinitializer, <8 x i1> %2025
  store <8 x i1> %2027, ptr %2023, align 1
  %2028 = add i32 %2007, 1
  %2029 = select i1 %1998, i32 %1985, i32 %2028
  %2030 = select i1 true, i32 %2029, i32 %1985
  store i32 %2030, ptr %current.token, align 4
  %2031 = load i32, ptr %current.token, align 4
  %2032 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1979)
  %2033 = load i32, ptr %ready.count, align 4
  %2034 = icmp uge i32 %2033, 8
  %2035 = and i1 %2032, %2034
  br i1 %2035, label %ready.overflow.trap409, label %ready.overflow.resume410

ready.overflow.trap409:                           ; preds = %convergence.overflow.resume408
  call void @llvm.trap()
  unreachable

ready.overflow.resume410:                         ; preds = %convergence.overflow.resume408
  %2036 = select i1 %2032, i32 %2033, i32 0
  %2037 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2036
  %2038 = load <8 x i1>, ptr %2037, align 1
  %2039 = select i1 %2032, <8 x i1> %1979, <8 x i1> %2038
  store <8 x i1> %2039, ptr %2037, align 1
  %2040 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2036
  %2041 = load i32, ptr %2040, align 4
  %2042 = select i1 %2032, i32 11, i32 %2041
  store i32 %2042, ptr %2040, align 4
  %2043 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2036
  %2044 = load i32, ptr %2043, align 4
  %2045 = select i1 %2032, i32 %2031, i32 %2044
  store i32 %2045, ptr %2043, align 4
  %2046 = add i32 %2033, 1
  %2047 = select i1 %2032, i32 %2046, i32 %2033
  store i32 %2047, ptr %ready.count, align 4
  %2048 = load <8 x i1>, ptr %runnable.mask, align 1
  %2049 = or <8 x i1> %2048, %1979
  store <8 x i1> %2049, ptr %runnable.mask, align 1
  store <8 x i1> %1981, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true411:                         ; preds = %varying.coherent406
  store <8 x i1> %convergence.cascade.result347, ptr %current.mask, align 1
  %2050 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result347)
  br i1 %2050, label %schedule.11, label %scheduler.loop

varying.coherent.false412:                        ; preds = %varying.coherent406
  store <8 x i1> %convergence.cascade.result347, ptr %current.mask, align 1
  %2051 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result347)
  br i1 %2051, label %schedule.12, label %scheduler.loop

convergence.cascade428:                           ; preds = %convergence.cascade428, %schedule.12
  %convergence.cascade.flow432 = phi <8 x i1> [ %554, %schedule.12 ], [ %2094, %convergence.cascade428 ]
  %convergence.cascade.depth433 = phi i32 [ 0, %schedule.12 ], [ %2095, %convergence.cascade428 ]
  %2052 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow432)
  %2053 = load i32, ptr %current.token, align 4
  %2054 = icmp ne i32 %2053, 0
  %2055 = and i1 %2052, %2054
  %2056 = sub i32 %2053, 1
  %2057 = select i1 %2055, i32 %2056, i32 0
  %2058 = load i8, ptr %frame.active, align 1
  %2059 = trunc i32 %2057 to i8
  %2060 = shl i8 1, %2059
  %2061 = and i8 %2058, %2060
  %2062 = icmp ne i8 %2061, 0
  %2063 = load <8 x i32>, ptr %frame.static.id, align 32
  %2064 = extractelement <8 x i32> %2063, i32 %2057
  %convergence.target.pointer434 = getelementptr inbounds [6 x i32], ptr @convergence.targets, i32 0, i32 %2064
  %convergence.dynamic.target435 = load i32, ptr %convergence.target.pointer434, align 4
  %2065 = icmp eq i32 %convergence.dynamic.target435, 12
  %2066 = and i1 %2062, %2065
  %2067 = and i1 %2055, %2066
  %2068 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2057
  %2069 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2057
  %2070 = load <8 x i1>, ptr %2068, align 1
  %2071 = load <8 x i1>, ptr %2069, align 1
  %2072 = or <8 x i1> %2071, %convergence.cascade.flow432
  %2073 = load <8 x i1>, ptr %live.mask, align 1
  %2074 = and <8 x i1> %2070, %2073
  %2075 = icmp eq <8 x i1> %2072, %2074
  %2076 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2075)
  %2077 = and i1 %2067, %2076
  %2078 = select i1 %2077, <8 x i1> zeroinitializer, <8 x i1> %2072
  %2079 = select i1 %2067, <8 x i1> %2078, <8 x i1> %2071
  store <8 x i1> %2079, ptr %2069, align 1
  %2080 = select i1 %2077, <8 x i1> zeroinitializer, <8 x i1> %2070
  store <8 x i1> %2080, ptr %2068, align 1
  %2081 = trunc i32 %2057 to i8
  %2082 = shl i8 1, %2081
  %2083 = xor i8 %2082, -1
  %2084 = and i8 %2058, %2083
  %2085 = select i1 %2077, i8 %2084, i8 %2058
  store i8 %2085, ptr %frame.active, align 1
  %.splatinsert436 = insertelement <8 x i1> poison, i1 %2067, i64 0
  %.splat437 = shufflevector <8 x i1> %.splatinsert436, <8 x i1> poison, <8 x i32> zeroinitializer
  %2086 = and <8 x i1> %convergence.cascade.flow432, %.splat437
  %2087 = load <8 x i1>, ptr %runnable.mask, align 1
  %2088 = xor <8 x i1> %2086, splat (i1 true)
  %2089 = and <8 x i1> %2087, %2088
  store <8 x i1> %2089, ptr %runnable.mask, align 1
  %.splatinsert438 = insertelement <8 x i1> poison, i1 %2077, i64 0
  %.splat439 = shufflevector <8 x i1> %.splatinsert438, <8 x i1> poison, <8 x i32> zeroinitializer
  %2090 = select <8 x i1> %.splat439, <8 x i1> %2072, <8 x i1> zeroinitializer
  %2091 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2092 = extractelement <8 x i32> %2091, i32 %2057
  %2093 = select i1 %2077, i32 %2092, i32 %2053
  store i32 %2093, ptr %current.token, align 4
  %.splatinsert440 = insertelement <8 x i1> poison, i1 %2067, i64 0
  %.splat441 = shufflevector <8 x i1> %.splatinsert440, <8 x i1> poison, <8 x i32> zeroinitializer
  %2094 = select <8 x i1> %.splat441, <8 x i1> %2090, <8 x i1> %convergence.cascade.flow432
  %2095 = add i32 %convergence.cascade.depth433, 1
  %2096 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2094)
  %2097 = icmp ult i32 %2095, 8
  %2098 = and i1 %2096, %2097
  %2099 = and i1 %2067, %2098
  %convergence.parent.token442 = load i32, ptr %current.token, align 4
  %convergence.parent.present443 = icmp ne i32 %convergence.parent.token442, 0
  %2100 = and i1 %2099, %convergence.parent.present443
  br i1 %2100, label %convergence.cascade428, label %convergence.cascade.exit429

convergence.cascade.exit429:                      ; preds = %convergence.cascade428, %schedule.12
  %convergence.cascade.result444 = phi <8 x i1> [ %554, %schedule.12 ], [ %2094, %convergence.cascade428 ]
  %2101 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result444)
  br i1 %2101, label %convergence.target.12.ready, label %scheduler.loop

convergence.target.12.ready:                      ; preds = %convergence.cascade.exit429
  %2102 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result444)
  %2103 = bitcast <8 x i1> %convergence.cascade.result444 to i8
  %2104 = call i8 @llvm.cttz.i8(i8 %2103, i1 false)
  %2105 = zext i8 %2104 to i32
  %2106 = select i1 %2102, i32 %2105, i32 0
  %2107 = load <8 x i1>, ptr %live.mask, align 1
  %2108 = xor <8 x i1> %convergence.cascade.result444, splat (i1 true)
  %2109 = and <8 x i1> %2107, %2108
  store <8 x i1> %2109, ptr %live.mask, align 1
  %2110 = load <8 x i1>, ptr %runnable.mask, align 1
  %2111 = xor <8 x i1> %convergence.cascade.result444, splat (i1 true)
  %2112 = and <8 x i1> %2110, %2111
  store <8 x i1> %2112, ptr %runnable.mask, align 1
  %return.active.frames = load i8, ptr %frame.active, align 1
  %return.frames.present = icmp ne i8 %return.active.frames, 0
  br i1 %return.frames.present, label %return.frame.cleanup, label %return.frame.cleanup.done

return.frame.cleanup:                             ; preds = %convergence.target.12.ready
  %2113 = load i8, ptr %frame.active, align 1
  %2114 = and i8 %2113, 1
  %2115 = icmp ne i8 %2114, 0
  %2116 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 0
  %2117 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 0
  %2118 = load <8 x i1>, ptr %2116, align 1
  %2119 = load <8 x i1>, ptr %2117, align 1
  %2120 = and <8 x i1> %2118, %2109
  %2121 = icmp eq <8 x i1> %2119, %2120
  %2122 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2121)
  %2123 = and i1 %2115, %2122
  %.splatinsert445 = insertelement <8 x i1> poison, i1 %2123, i64 0
  %.splat446 = shufflevector <8 x i1> %.splatinsert445, <8 x i1> poison, <8 x i32> zeroinitializer
  %2124 = select <8 x i1> %.splat446, <8 x i1> %2119, <8 x i1> zeroinitializer
  %2125 = select i1 %2123, <8 x i1> zeroinitializer, <8 x i1> %2120
  store <8 x i1> %2125, ptr %2116, align 1
  %2126 = select i1 %2123, <8 x i1> zeroinitializer, <8 x i1> %2119
  store <8 x i1> %2126, ptr %2117, align 1
  %2127 = and i8 %2113, -2
  %2128 = select i1 %2123, i8 %2127, i8 %2113
  store i8 %2128, ptr %frame.active, align 1
  %2129 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2130 = extractelement <8 x i32> %2129, i32 0
  %2131 = load <8 x i32>, ptr %frame.static.id, align 32
  %2132 = extractelement <8 x i32> %2131, i32 0
  %convergence.target.pointer447 = getelementptr inbounds [6 x i32], ptr @convergence.targets, i32 0, i32 %2132
  %convergence.dynamic.target448 = load i32, ptr %convergence.target.pointer447, align 4
  %2133 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2124)
  %2134 = load i32, ptr %ready.count, align 4
  %2135 = icmp uge i32 %2134, 8
  %2136 = and i1 %2133, %2135
  br i1 %2136, label %ready.overflow.trap449, label %ready.overflow.resume450

return.frame.cleanup.done:                        ; preds = %ready.overflow.resume492, %convergence.target.12.ready
  br label %scheduler.loop

ready.overflow.trap449:                           ; preds = %return.frame.cleanup
  call void @llvm.trap()
  unreachable

ready.overflow.resume450:                         ; preds = %return.frame.cleanup
  %2137 = select i1 %2133, i32 %2134, i32 0
  %2138 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2137
  %2139 = load <8 x i1>, ptr %2138, align 1
  %2140 = select i1 %2133, <8 x i1> %2124, <8 x i1> %2139
  store <8 x i1> %2140, ptr %2138, align 1
  %2141 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2137
  %2142 = load i32, ptr %2141, align 4
  %2143 = select i1 %2133, i32 %convergence.dynamic.target448, i32 %2142
  store i32 %2143, ptr %2141, align 4
  %2144 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2137
  %2145 = load i32, ptr %2144, align 4
  %2146 = select i1 %2133, i32 %2130, i32 %2145
  store i32 %2146, ptr %2144, align 4
  %2147 = add i32 %2134, 1
  %2148 = select i1 %2133, i32 %2147, i32 %2134
  store i32 %2148, ptr %ready.count, align 4
  %2149 = load <8 x i1>, ptr %runnable.mask, align 1
  %2150 = or <8 x i1> %2149, %2124
  store <8 x i1> %2150, ptr %runnable.mask, align 1
  %2151 = load i8, ptr %frame.active, align 1
  %2152 = and i8 %2151, 2
  %2153 = icmp ne i8 %2152, 0
  %2154 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 1
  %2155 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 1
  %2156 = load <8 x i1>, ptr %2154, align 1
  %2157 = load <8 x i1>, ptr %2155, align 1
  %2158 = and <8 x i1> %2156, %2109
  %2159 = icmp eq <8 x i1> %2157, %2158
  %2160 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2159)
  %2161 = and i1 %2153, %2160
  %.splatinsert451 = insertelement <8 x i1> poison, i1 %2161, i64 0
  %.splat452 = shufflevector <8 x i1> %.splatinsert451, <8 x i1> poison, <8 x i32> zeroinitializer
  %2162 = select <8 x i1> %.splat452, <8 x i1> %2157, <8 x i1> zeroinitializer
  %2163 = select i1 %2161, <8 x i1> zeroinitializer, <8 x i1> %2158
  store <8 x i1> %2163, ptr %2154, align 1
  %2164 = select i1 %2161, <8 x i1> zeroinitializer, <8 x i1> %2157
  store <8 x i1> %2164, ptr %2155, align 1
  %2165 = and i8 %2151, -3
  %2166 = select i1 %2161, i8 %2165, i8 %2151
  store i8 %2166, ptr %frame.active, align 1
  %2167 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2168 = extractelement <8 x i32> %2167, i32 1
  %2169 = load <8 x i32>, ptr %frame.static.id, align 32
  %2170 = extractelement <8 x i32> %2169, i32 1
  %convergence.target.pointer453 = getelementptr inbounds [6 x i32], ptr @convergence.targets, i32 0, i32 %2170
  %convergence.dynamic.target454 = load i32, ptr %convergence.target.pointer453, align 4
  %2171 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2162)
  %2172 = load i32, ptr %ready.count, align 4
  %2173 = icmp uge i32 %2172, 8
  %2174 = and i1 %2171, %2173
  br i1 %2174, label %ready.overflow.trap455, label %ready.overflow.resume456

ready.overflow.trap455:                           ; preds = %ready.overflow.resume450
  call void @llvm.trap()
  unreachable

ready.overflow.resume456:                         ; preds = %ready.overflow.resume450
  %2175 = select i1 %2171, i32 %2172, i32 0
  %2176 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2175
  %2177 = load <8 x i1>, ptr %2176, align 1
  %2178 = select i1 %2171, <8 x i1> %2162, <8 x i1> %2177
  store <8 x i1> %2178, ptr %2176, align 1
  %2179 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2175
  %2180 = load i32, ptr %2179, align 4
  %2181 = select i1 %2171, i32 %convergence.dynamic.target454, i32 %2180
  store i32 %2181, ptr %2179, align 4
  %2182 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2175
  %2183 = load i32, ptr %2182, align 4
  %2184 = select i1 %2171, i32 %2168, i32 %2183
  store i32 %2184, ptr %2182, align 4
  %2185 = add i32 %2172, 1
  %2186 = select i1 %2171, i32 %2185, i32 %2172
  store i32 %2186, ptr %ready.count, align 4
  %2187 = load <8 x i1>, ptr %runnable.mask, align 1
  %2188 = or <8 x i1> %2187, %2162
  store <8 x i1> %2188, ptr %runnable.mask, align 1
  %2189 = load i8, ptr %frame.active, align 1
  %2190 = and i8 %2189, 4
  %2191 = icmp ne i8 %2190, 0
  %2192 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 2
  %2193 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 2
  %2194 = load <8 x i1>, ptr %2192, align 1
  %2195 = load <8 x i1>, ptr %2193, align 1
  %2196 = and <8 x i1> %2194, %2109
  %2197 = icmp eq <8 x i1> %2195, %2196
  %2198 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2197)
  %2199 = and i1 %2191, %2198
  %.splatinsert457 = insertelement <8 x i1> poison, i1 %2199, i64 0
  %.splat458 = shufflevector <8 x i1> %.splatinsert457, <8 x i1> poison, <8 x i32> zeroinitializer
  %2200 = select <8 x i1> %.splat458, <8 x i1> %2195, <8 x i1> zeroinitializer
  %2201 = select i1 %2199, <8 x i1> zeroinitializer, <8 x i1> %2196
  store <8 x i1> %2201, ptr %2192, align 1
  %2202 = select i1 %2199, <8 x i1> zeroinitializer, <8 x i1> %2195
  store <8 x i1> %2202, ptr %2193, align 1
  %2203 = and i8 %2189, -5
  %2204 = select i1 %2199, i8 %2203, i8 %2189
  store i8 %2204, ptr %frame.active, align 1
  %2205 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2206 = extractelement <8 x i32> %2205, i32 2
  %2207 = load <8 x i32>, ptr %frame.static.id, align 32
  %2208 = extractelement <8 x i32> %2207, i32 2
  %convergence.target.pointer459 = getelementptr inbounds [6 x i32], ptr @convergence.targets, i32 0, i32 %2208
  %convergence.dynamic.target460 = load i32, ptr %convergence.target.pointer459, align 4
  %2209 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2200)
  %2210 = load i32, ptr %ready.count, align 4
  %2211 = icmp uge i32 %2210, 8
  %2212 = and i1 %2209, %2211
  br i1 %2212, label %ready.overflow.trap461, label %ready.overflow.resume462

ready.overflow.trap461:                           ; preds = %ready.overflow.resume456
  call void @llvm.trap()
  unreachable

ready.overflow.resume462:                         ; preds = %ready.overflow.resume456
  %2213 = select i1 %2209, i32 %2210, i32 0
  %2214 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2213
  %2215 = load <8 x i1>, ptr %2214, align 1
  %2216 = select i1 %2209, <8 x i1> %2200, <8 x i1> %2215
  store <8 x i1> %2216, ptr %2214, align 1
  %2217 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2213
  %2218 = load i32, ptr %2217, align 4
  %2219 = select i1 %2209, i32 %convergence.dynamic.target460, i32 %2218
  store i32 %2219, ptr %2217, align 4
  %2220 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2213
  %2221 = load i32, ptr %2220, align 4
  %2222 = select i1 %2209, i32 %2206, i32 %2221
  store i32 %2222, ptr %2220, align 4
  %2223 = add i32 %2210, 1
  %2224 = select i1 %2209, i32 %2223, i32 %2210
  store i32 %2224, ptr %ready.count, align 4
  %2225 = load <8 x i1>, ptr %runnable.mask, align 1
  %2226 = or <8 x i1> %2225, %2200
  store <8 x i1> %2226, ptr %runnable.mask, align 1
  %2227 = load i8, ptr %frame.active, align 1
  %2228 = and i8 %2227, 8
  %2229 = icmp ne i8 %2228, 0
  %2230 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 3
  %2231 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 3
  %2232 = load <8 x i1>, ptr %2230, align 1
  %2233 = load <8 x i1>, ptr %2231, align 1
  %2234 = and <8 x i1> %2232, %2109
  %2235 = icmp eq <8 x i1> %2233, %2234
  %2236 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2235)
  %2237 = and i1 %2229, %2236
  %.splatinsert463 = insertelement <8 x i1> poison, i1 %2237, i64 0
  %.splat464 = shufflevector <8 x i1> %.splatinsert463, <8 x i1> poison, <8 x i32> zeroinitializer
  %2238 = select <8 x i1> %.splat464, <8 x i1> %2233, <8 x i1> zeroinitializer
  %2239 = select i1 %2237, <8 x i1> zeroinitializer, <8 x i1> %2234
  store <8 x i1> %2239, ptr %2230, align 1
  %2240 = select i1 %2237, <8 x i1> zeroinitializer, <8 x i1> %2233
  store <8 x i1> %2240, ptr %2231, align 1
  %2241 = and i8 %2227, -9
  %2242 = select i1 %2237, i8 %2241, i8 %2227
  store i8 %2242, ptr %frame.active, align 1
  %2243 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2244 = extractelement <8 x i32> %2243, i32 3
  %2245 = load <8 x i32>, ptr %frame.static.id, align 32
  %2246 = extractelement <8 x i32> %2245, i32 3
  %convergence.target.pointer465 = getelementptr inbounds [6 x i32], ptr @convergence.targets, i32 0, i32 %2246
  %convergence.dynamic.target466 = load i32, ptr %convergence.target.pointer465, align 4
  %2247 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2238)
  %2248 = load i32, ptr %ready.count, align 4
  %2249 = icmp uge i32 %2248, 8
  %2250 = and i1 %2247, %2249
  br i1 %2250, label %ready.overflow.trap467, label %ready.overflow.resume468

ready.overflow.trap467:                           ; preds = %ready.overflow.resume462
  call void @llvm.trap()
  unreachable

ready.overflow.resume468:                         ; preds = %ready.overflow.resume462
  %2251 = select i1 %2247, i32 %2248, i32 0
  %2252 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2251
  %2253 = load <8 x i1>, ptr %2252, align 1
  %2254 = select i1 %2247, <8 x i1> %2238, <8 x i1> %2253
  store <8 x i1> %2254, ptr %2252, align 1
  %2255 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2251
  %2256 = load i32, ptr %2255, align 4
  %2257 = select i1 %2247, i32 %convergence.dynamic.target466, i32 %2256
  store i32 %2257, ptr %2255, align 4
  %2258 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2251
  %2259 = load i32, ptr %2258, align 4
  %2260 = select i1 %2247, i32 %2244, i32 %2259
  store i32 %2260, ptr %2258, align 4
  %2261 = add i32 %2248, 1
  %2262 = select i1 %2247, i32 %2261, i32 %2248
  store i32 %2262, ptr %ready.count, align 4
  %2263 = load <8 x i1>, ptr %runnable.mask, align 1
  %2264 = or <8 x i1> %2263, %2238
  store <8 x i1> %2264, ptr %runnable.mask, align 1
  %2265 = load i8, ptr %frame.active, align 1
  %2266 = and i8 %2265, 16
  %2267 = icmp ne i8 %2266, 0
  %2268 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 4
  %2269 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 4
  %2270 = load <8 x i1>, ptr %2268, align 1
  %2271 = load <8 x i1>, ptr %2269, align 1
  %2272 = and <8 x i1> %2270, %2109
  %2273 = icmp eq <8 x i1> %2271, %2272
  %2274 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2273)
  %2275 = and i1 %2267, %2274
  %.splatinsert469 = insertelement <8 x i1> poison, i1 %2275, i64 0
  %.splat470 = shufflevector <8 x i1> %.splatinsert469, <8 x i1> poison, <8 x i32> zeroinitializer
  %2276 = select <8 x i1> %.splat470, <8 x i1> %2271, <8 x i1> zeroinitializer
  %2277 = select i1 %2275, <8 x i1> zeroinitializer, <8 x i1> %2272
  store <8 x i1> %2277, ptr %2268, align 1
  %2278 = select i1 %2275, <8 x i1> zeroinitializer, <8 x i1> %2271
  store <8 x i1> %2278, ptr %2269, align 1
  %2279 = and i8 %2265, -17
  %2280 = select i1 %2275, i8 %2279, i8 %2265
  store i8 %2280, ptr %frame.active, align 1
  %2281 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2282 = extractelement <8 x i32> %2281, i32 4
  %2283 = load <8 x i32>, ptr %frame.static.id, align 32
  %2284 = extractelement <8 x i32> %2283, i32 4
  %convergence.target.pointer471 = getelementptr inbounds [6 x i32], ptr @convergence.targets, i32 0, i32 %2284
  %convergence.dynamic.target472 = load i32, ptr %convergence.target.pointer471, align 4
  %2285 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2276)
  %2286 = load i32, ptr %ready.count, align 4
  %2287 = icmp uge i32 %2286, 8
  %2288 = and i1 %2285, %2287
  br i1 %2288, label %ready.overflow.trap473, label %ready.overflow.resume474

ready.overflow.trap473:                           ; preds = %ready.overflow.resume468
  call void @llvm.trap()
  unreachable

ready.overflow.resume474:                         ; preds = %ready.overflow.resume468
  %2289 = select i1 %2285, i32 %2286, i32 0
  %2290 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2289
  %2291 = load <8 x i1>, ptr %2290, align 1
  %2292 = select i1 %2285, <8 x i1> %2276, <8 x i1> %2291
  store <8 x i1> %2292, ptr %2290, align 1
  %2293 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2289
  %2294 = load i32, ptr %2293, align 4
  %2295 = select i1 %2285, i32 %convergence.dynamic.target472, i32 %2294
  store i32 %2295, ptr %2293, align 4
  %2296 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2289
  %2297 = load i32, ptr %2296, align 4
  %2298 = select i1 %2285, i32 %2282, i32 %2297
  store i32 %2298, ptr %2296, align 4
  %2299 = add i32 %2286, 1
  %2300 = select i1 %2285, i32 %2299, i32 %2286
  store i32 %2300, ptr %ready.count, align 4
  %2301 = load <8 x i1>, ptr %runnable.mask, align 1
  %2302 = or <8 x i1> %2301, %2276
  store <8 x i1> %2302, ptr %runnable.mask, align 1
  %2303 = load i8, ptr %frame.active, align 1
  %2304 = and i8 %2303, 32
  %2305 = icmp ne i8 %2304, 0
  %2306 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 5
  %2307 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 5
  %2308 = load <8 x i1>, ptr %2306, align 1
  %2309 = load <8 x i1>, ptr %2307, align 1
  %2310 = and <8 x i1> %2308, %2109
  %2311 = icmp eq <8 x i1> %2309, %2310
  %2312 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2311)
  %2313 = and i1 %2305, %2312
  %.splatinsert475 = insertelement <8 x i1> poison, i1 %2313, i64 0
  %.splat476 = shufflevector <8 x i1> %.splatinsert475, <8 x i1> poison, <8 x i32> zeroinitializer
  %2314 = select <8 x i1> %.splat476, <8 x i1> %2309, <8 x i1> zeroinitializer
  %2315 = select i1 %2313, <8 x i1> zeroinitializer, <8 x i1> %2310
  store <8 x i1> %2315, ptr %2306, align 1
  %2316 = select i1 %2313, <8 x i1> zeroinitializer, <8 x i1> %2309
  store <8 x i1> %2316, ptr %2307, align 1
  %2317 = and i8 %2303, -33
  %2318 = select i1 %2313, i8 %2317, i8 %2303
  store i8 %2318, ptr %frame.active, align 1
  %2319 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2320 = extractelement <8 x i32> %2319, i32 5
  %2321 = load <8 x i32>, ptr %frame.static.id, align 32
  %2322 = extractelement <8 x i32> %2321, i32 5
  %convergence.target.pointer477 = getelementptr inbounds [6 x i32], ptr @convergence.targets, i32 0, i32 %2322
  %convergence.dynamic.target478 = load i32, ptr %convergence.target.pointer477, align 4
  %2323 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2314)
  %2324 = load i32, ptr %ready.count, align 4
  %2325 = icmp uge i32 %2324, 8
  %2326 = and i1 %2323, %2325
  br i1 %2326, label %ready.overflow.trap479, label %ready.overflow.resume480

ready.overflow.trap479:                           ; preds = %ready.overflow.resume474
  call void @llvm.trap()
  unreachable

ready.overflow.resume480:                         ; preds = %ready.overflow.resume474
  %2327 = select i1 %2323, i32 %2324, i32 0
  %2328 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2327
  %2329 = load <8 x i1>, ptr %2328, align 1
  %2330 = select i1 %2323, <8 x i1> %2314, <8 x i1> %2329
  store <8 x i1> %2330, ptr %2328, align 1
  %2331 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2327
  %2332 = load i32, ptr %2331, align 4
  %2333 = select i1 %2323, i32 %convergence.dynamic.target478, i32 %2332
  store i32 %2333, ptr %2331, align 4
  %2334 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2327
  %2335 = load i32, ptr %2334, align 4
  %2336 = select i1 %2323, i32 %2320, i32 %2335
  store i32 %2336, ptr %2334, align 4
  %2337 = add i32 %2324, 1
  %2338 = select i1 %2323, i32 %2337, i32 %2324
  store i32 %2338, ptr %ready.count, align 4
  %2339 = load <8 x i1>, ptr %runnable.mask, align 1
  %2340 = or <8 x i1> %2339, %2314
  store <8 x i1> %2340, ptr %runnable.mask, align 1
  %2341 = load i8, ptr %frame.active, align 1
  %2342 = and i8 %2341, 64
  %2343 = icmp ne i8 %2342, 0
  %2344 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 6
  %2345 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 6
  %2346 = load <8 x i1>, ptr %2344, align 1
  %2347 = load <8 x i1>, ptr %2345, align 1
  %2348 = and <8 x i1> %2346, %2109
  %2349 = icmp eq <8 x i1> %2347, %2348
  %2350 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2349)
  %2351 = and i1 %2343, %2350
  %.splatinsert481 = insertelement <8 x i1> poison, i1 %2351, i64 0
  %.splat482 = shufflevector <8 x i1> %.splatinsert481, <8 x i1> poison, <8 x i32> zeroinitializer
  %2352 = select <8 x i1> %.splat482, <8 x i1> %2347, <8 x i1> zeroinitializer
  %2353 = select i1 %2351, <8 x i1> zeroinitializer, <8 x i1> %2348
  store <8 x i1> %2353, ptr %2344, align 1
  %2354 = select i1 %2351, <8 x i1> zeroinitializer, <8 x i1> %2347
  store <8 x i1> %2354, ptr %2345, align 1
  %2355 = and i8 %2341, -65
  %2356 = select i1 %2351, i8 %2355, i8 %2341
  store i8 %2356, ptr %frame.active, align 1
  %2357 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2358 = extractelement <8 x i32> %2357, i32 6
  %2359 = load <8 x i32>, ptr %frame.static.id, align 32
  %2360 = extractelement <8 x i32> %2359, i32 6
  %convergence.target.pointer483 = getelementptr inbounds [6 x i32], ptr @convergence.targets, i32 0, i32 %2360
  %convergence.dynamic.target484 = load i32, ptr %convergence.target.pointer483, align 4
  %2361 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2352)
  %2362 = load i32, ptr %ready.count, align 4
  %2363 = icmp uge i32 %2362, 8
  %2364 = and i1 %2361, %2363
  br i1 %2364, label %ready.overflow.trap485, label %ready.overflow.resume486

ready.overflow.trap485:                           ; preds = %ready.overflow.resume480
  call void @llvm.trap()
  unreachable

ready.overflow.resume486:                         ; preds = %ready.overflow.resume480
  %2365 = select i1 %2361, i32 %2362, i32 0
  %2366 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2365
  %2367 = load <8 x i1>, ptr %2366, align 1
  %2368 = select i1 %2361, <8 x i1> %2352, <8 x i1> %2367
  store <8 x i1> %2368, ptr %2366, align 1
  %2369 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2365
  %2370 = load i32, ptr %2369, align 4
  %2371 = select i1 %2361, i32 %convergence.dynamic.target484, i32 %2370
  store i32 %2371, ptr %2369, align 4
  %2372 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2365
  %2373 = load i32, ptr %2372, align 4
  %2374 = select i1 %2361, i32 %2358, i32 %2373
  store i32 %2374, ptr %2372, align 4
  %2375 = add i32 %2362, 1
  %2376 = select i1 %2361, i32 %2375, i32 %2362
  store i32 %2376, ptr %ready.count, align 4
  %2377 = load <8 x i1>, ptr %runnable.mask, align 1
  %2378 = or <8 x i1> %2377, %2352
  store <8 x i1> %2378, ptr %runnable.mask, align 1
  %2379 = load i8, ptr %frame.active, align 1
  %2380 = and i8 %2379, -128
  %2381 = icmp ne i8 %2380, 0
  %2382 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 7
  %2383 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 7
  %2384 = load <8 x i1>, ptr %2382, align 1
  %2385 = load <8 x i1>, ptr %2383, align 1
  %2386 = and <8 x i1> %2384, %2109
  %2387 = icmp eq <8 x i1> %2385, %2386
  %2388 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2387)
  %2389 = and i1 %2381, %2388
  %.splatinsert487 = insertelement <8 x i1> poison, i1 %2389, i64 0
  %.splat488 = shufflevector <8 x i1> %.splatinsert487, <8 x i1> poison, <8 x i32> zeroinitializer
  %2390 = select <8 x i1> %.splat488, <8 x i1> %2385, <8 x i1> zeroinitializer
  %2391 = select i1 %2389, <8 x i1> zeroinitializer, <8 x i1> %2386
  store <8 x i1> %2391, ptr %2382, align 1
  %2392 = select i1 %2389, <8 x i1> zeroinitializer, <8 x i1> %2385
  store <8 x i1> %2392, ptr %2383, align 1
  %2393 = and i8 %2379, 127
  %2394 = select i1 %2389, i8 %2393, i8 %2379
  store i8 %2394, ptr %frame.active, align 1
  %2395 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2396 = extractelement <8 x i32> %2395, i32 7
  %2397 = load <8 x i32>, ptr %frame.static.id, align 32
  %2398 = extractelement <8 x i32> %2397, i32 7
  %convergence.target.pointer489 = getelementptr inbounds [6 x i32], ptr @convergence.targets, i32 0, i32 %2398
  %convergence.dynamic.target490 = load i32, ptr %convergence.target.pointer489, align 4
  %2399 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2390)
  %2400 = load i32, ptr %ready.count, align 4
  %2401 = icmp uge i32 %2400, 8
  %2402 = and i1 %2399, %2401
  br i1 %2402, label %ready.overflow.trap491, label %ready.overflow.resume492

ready.overflow.trap491:                           ; preds = %ready.overflow.resume486
  call void @llvm.trap()
  unreachable

ready.overflow.resume492:                         ; preds = %ready.overflow.resume486
  %2403 = select i1 %2399, i32 %2400, i32 0
  %2404 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2403
  %2405 = load <8 x i1>, ptr %2404, align 1
  %2406 = select i1 %2399, <8 x i1> %2390, <8 x i1> %2405
  store <8 x i1> %2406, ptr %2404, align 1
  %2407 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2403
  %2408 = load i32, ptr %2407, align 4
  %2409 = select i1 %2399, i32 %convergence.dynamic.target490, i32 %2408
  store i32 %2409, ptr %2407, align 4
  %2410 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2403
  %2411 = load i32, ptr %2410, align 4
  %2412 = select i1 %2399, i32 %2396, i32 %2411
  store i32 %2412, ptr %2410, align 4
  %2413 = add i32 %2400, 1
  %2414 = select i1 %2399, i32 %2413, i32 %2400
  store i32 %2414, ptr %ready.count, align 4
  %2415 = load <8 x i1>, ptr %runnable.mask, align 1
  %2416 = or <8 x i1> %2415, %2390
  store <8 x i1> %2416, ptr %runnable.mask, align 1
  br label %return.frame.cleanup.done
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), i32 immarg, <8 x i1>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.and.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), i32 immarg, <8 x i1>) #3

define dso_local void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

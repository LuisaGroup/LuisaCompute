; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

@convergence.targets = private unnamed_addr constant [7 x i32] [i32 5, i32 8, i32 10, i32 13, i32 15, i32 18, i32 20], align 4

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %live.mask = alloca <8 x i1>, align 1
  %runnable.mask = alloca <8 x i1>, align 1
  %ready.count = alloca i32, align 4
  %ready.mask = alloca [8 x <8 x i1>], align 1
  %ready.target = alloca [8 x i32], align 4
  %ready.token = alloca [8 x i32], align 4
  %current.mask = alloca <8 x i1>, align 1
  %current.token = alloca i32, align 4
  %frame.active = alloca i8, align 1
  %frame.static.id = alloca <8 x i32>, align 32
  %frame.parent.token = alloca <8 x i32>, align 32
  %frame.expected = alloca [8 x <8 x i1>], align 1
  %frame.arrived = alloca [8 x <8 x i1>], align 1
  store <8 x i1> zeroinitializer, ptr %live.mask, align 1
  store <8 x i1> zeroinitializer, ptr %runnable.mask, align 1
  store i32 0, ptr %ready.count, align 4
  store [8 x <8 x i1>] zeroinitializer, ptr %ready.mask, align 1
  store [8 x i32] zeroinitializer, ptr %ready.target, align 4
  store [8 x i32] zeroinitializer, ptr %ready.token, align 4
  store <8 x i1> zeroinitializer, ptr %current.mask, align 1
  store i32 0, ptr %current.token, align 4
  store i8 0, ptr %frame.active, align 1
  store <8 x i32> zeroinitializer, ptr %frame.static.id, align 32
  store <8 x i32> zeroinitializer, ptr %frame.parent.token, align 32
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.expected, align 1
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.arrived, align 1
  %tile_snapshot.local = alloca [288 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [288 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot, align 64
  %.spill5 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill5, align 1
  %.spill6 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill6, align 4
  %.spill7 = alloca i64, align 8
  store i64 0, ptr %.spill7, align 4
  %.slot8 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot8, align 64
  %.slot9 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot9, align 32
  %.slot10 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot10, align 32
  %.slot11 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot11, align 32
  %.slot12 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot12, align 32
  %.slot13 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot13, align 32
  %.spill14 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill14, align 32
  %tile_snapshot.spill15 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill15, align 64
  %.slot16 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot16, align 64
  %.spill17 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill17, align 32
  %.slot18 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot18, align 64
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert19 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat20 = shufflevector <8 x i32> %.splatinsert19, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat20, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert21 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat22 = shufflevector <8 x i32> %.splatinsert21, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat22, %41
  %44 = mul i32 %32, 1
  %.splatinsert23 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat24 = shufflevector <8 x i32> %.splatinsert23, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat24, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert25 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat26 = shufflevector <8 x i32> %.splatinsert25, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat26, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert27 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat28 = shufflevector <8 x i32> %.splatinsert27, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat28
  store <8 x i1> %51, ptr %live.mask, align 1
  %52 = load i32, ptr %current.token, align 4
  %53 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %54 = load i32, ptr %ready.count, align 4
  %55 = icmp uge i32 %54, 8
  %56 = and i1 %53, %55
  br i1 %56, label %ready.overflow.trap, label %ready.overflow.resume

ready.overflow.trap:                              ; preds = %prologue
  call void @llvm.trap()
  unreachable

ready.overflow.resume:                            ; preds = %prologue
  %57 = select i1 %53, i32 %54, i32 0
  %58 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %57
  %59 = load <8 x i1>, ptr %58, align 1
  %60 = select i1 %53, <8 x i1> %51, <8 x i1> %59
  store <8 x i1> %60, ptr %58, align 1
  %61 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %57
  %62 = load i32, ptr %61, align 4
  %63 = select i1 %53, i32 0, i32 %62
  store i32 %63, ptr %61, align 4
  %64 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %57
  %65 = load i32, ptr %64, align 4
  %66 = select i1 %53, i32 %52, i32 %65
  store i32 %66, ptr %64, align 4
  %67 = add i32 %54, 1
  %68 = select i1 %53, i32 %67, i32 %54
  store i32 %68, ptr %ready.count, align 4
  %69 = load <8 x i1>, ptr %runnable.mask, align 1
  %70 = or <8 x i1> %69, %51
  store <8 x i1> %70, ptr %runnable.mask, align 1
  br label %scheduler.loop

scheduler.loop:                                   ; preds = %return.frame.cleanup.done, %convergence.cascade.exit293, %schedule.19, %varying.coherent.false279, %varying.coherent.true278, %ready.overflow.resume277, %convergence.cascade.exit253, %schedule.17, %varying.coherent.false239, %varying.coherent.true238, %ready.overflow.resume237, %convergence.target.15.ready, %convergence.cascade.exit210, %schedule.14, %varying.coherent.false199, %varying.coherent.true198, %ready.overflow.resume197, %convergence.cascade.exit173, %schedule.12, %varying.coherent.false161, %varying.coherent.true160, %ready.overflow.resume159, %convergence.target.10.ready, %convergence.cascade.exit127, %schedule.9, %varying.coherent.false120, %varying.coherent.true119, %ready.overflow.resume118, %convergence.cascade.exit93, %schedule.7, %varying.coherent.false78, %varying.coherent.true77, %ready.overflow.resume76, %convergence.target.5.ready, %convergence.cascade.exit, %schedule.4, %varying.coherent.false, %varying.coherent.true, %ready.overflow.resume43, %schedule.2, %uniform.false, %uniform.true, %schedule.0, %ready.overflow.resume
  %71 = load i32, ptr %ready.count, align 4
  %72 = icmp ne i32 %71, 0
  br i1 %72, label %scheduler.dispatch, label %scheduler.done

scheduler.dispatch:                               ; preds = %scheduler.loop
  %73 = sub i32 %71, 1
  store i32 %73, ptr %ready.count, align 4
  %74 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %73
  %75 = load <8 x i1>, ptr %74, align 1
  store <8 x i1> %75, ptr %current.mask, align 1
  %76 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %73
  %77 = load i32, ptr %76, align 4
  %78 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %73
  %79 = load i32, ptr %78, align 4
  store i32 %79, ptr %current.token, align 4
  %80 = load <8 x i1>, ptr %runnable.mask, align 1
  %81 = xor <8 x i1> %75, splat (i1 true)
  %82 = and <8 x i1> %80, %81
  store <8 x i1> %82, ptr %runnable.mask, align 1
  br label %scheduler.dispatch.route

scheduler.dispatch.route:                         ; preds = %scheduler.dispatch
  %scheduler.dispatch.pc = phi i32 [ %77, %scheduler.dispatch ]
  switch i32 %scheduler.dispatch.pc, label %scheduler.invalid [
    i32 0, label %schedule.0
    i32 1, label %schedule.1
    i32 2, label %schedule.2
    i32 3, label %schedule.3
    i32 4, label %schedule.4
    i32 5, label %schedule.5
    i32 6, label %schedule.6
    i32 7, label %schedule.7
    i32 8, label %schedule.8
    i32 9, label %schedule.9
    i32 10, label %schedule.10
    i32 11, label %schedule.11
    i32 12, label %schedule.12
    i32 13, label %schedule.13
    i32 14, label %schedule.14
    i32 15, label %schedule.15
    i32 16, label %schedule.16
    i32 17, label %schedule.17
    i32 18, label %schedule.18
    i32 19, label %schedule.19
    i32 20, label %schedule.20
  ]

scheduler.done:                                   ; preds = %scheduler.loop
  %83 = load <8 x i1>, ptr %live.mask, align 1
  %84 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %83)
  br i1 %84, label %scheduler.stalled, label %scheduler.exit

scheduler.exit:                                   ; preds = %scheduler.done
  ret void

scheduler.stalled:                                ; preds = %scheduler.done
  call void @llvm.trap()
  unreachable

scheduler.invalid:                                ; preds = %scheduler.dispatch.route
  call void @llvm.trap()
  unreachable

schedule.0:                                       ; preds = %scheduler.dispatch.route
  %85 = load <8 x i1>, ptr %current.mask, align 1
  %86 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %85)
  %87 = bitcast <8 x i1> %85 to i8
  %88 = call i8 @llvm.cttz.i8(i8 %87, i1 false)
  %89 = zext i8 %88 to i32
  %90 = select i1 %86, i32 %89, i32 0
  %91 = extractvalue [3 x <8 x i32>] %50, 0
  %92 = load <8 x i64>, ptr %.spill, align 64
  %93 = select <8 x i1> %85, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %92
  store <8 x i64> %93, ptr %.spill, align 64
  %94 = sub <8 x i32> %91, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %95 = select <8 x i1> %85, <8 x i32> %94, <8 x i32> zeroinitializer
  %96 = select <8 x i1> %85, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %97 = lshr <8 x i32> %95, %96
  %98 = zext <8 x i32> %97 to <8 x i64>
  %99 = select <8 x i1> %85, <8 x i64> %98, <8 x i64> zeroinitializer
  %100 = select <8 x i1> %85, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %101 = sdiv <8 x i64> %99, %100
  %102 = load <8 x i64>, ptr %.spill4, align 64
  %103 = select <8 x i1> %85, <8 x i64> %101, <8 x i64> %102
  store <8 x i64> %103, ptr %.spill4, align 64
  %104 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %105 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %106 = extractvalue { <8 x ptr>, <8 x i64> } %104, 0
  %107 = select <8 x i1> %85, <8 x ptr> %105, <8 x ptr> %106
  %108 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %104, 1
  %110 = select <8 x i1> %85, <8 x i64> %108, <8 x i64> %109
  %111 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %107, 0
  %112 = insertvalue { <8 x ptr>, <8 x i64> } %111, <8 x i64> %110, 1
  store { <8 x ptr>, <8 x i64> } %112, ptr %tile_snapshot.spill, align 64
  %113 = load <8 x i64>, ptr %.slot, align 64
  %114 = select <8 x i1> %85, <8 x i64> zeroinitializer, <8 x i64> %113
  store <8 x i64> %114, ptr %.slot, align 64
  store <8 x i1> %85, ptr %current.mask, align 1
  %115 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %85)
  br i1 %115, label %schedule.1, label %scheduler.loop

schedule.1:                                       ; preds = %schedule.2, %schedule.0, %scheduler.dispatch.route
  %116 = load <8 x i1>, ptr %current.mask, align 1
  %117 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %116)
  %118 = bitcast <8 x i1> %116 to i8
  %119 = call i8 @llvm.cttz.i8(i8 %118, i1 false)
  %120 = zext i8 %119 to i32
  %121 = select i1 %117, i32 %120, i32 0
  %.state = load <8 x i64>, ptr %.slot, align 64
  %122 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %116)
  %123 = bitcast <8 x i1> %116 to i8
  %124 = call i8 @llvm.cttz.i8(i8 %123, i1 false)
  %125 = zext i8 %124 to i32
  %126 = select i1 %122, i32 %125, i32 0
  %127 = extractelement <8 x i64> %.state, i32 %126
  %128 = icmp slt i64 %127, 8
  br i1 %128, label %uniform.true, label %uniform.false

schedule.2:                                       ; preds = %uniform.true, %scheduler.dispatch.route
  %129 = load <8 x i1>, ptr %current.mask, align 1
  %130 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %129)
  %131 = bitcast <8 x i1> %129 to i8
  %132 = call i8 @llvm.cttz.i8(i8 %131, i1 false)
  %133 = zext i8 %132 to i32
  %134 = select i1 %130, i32 %133, i32 0
  %.state29 = load <8 x i64>, ptr %.slot, align 64
  %135 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %129)
  %136 = bitcast <8 x i1> %129 to i8
  %137 = call i8 @llvm.cttz.i8(i8 %136, i1 false)
  %138 = zext i8 %137 to i32
  %139 = select i1 %135, i32 %138, i32 0
  %140 = extractelement <8 x i64> %.state29, i32 %139
  %141 = mul i64 %140, 8
  %.splatinsert30 = insertelement <8 x i64> poison, i64 %141, i64 0
  %.splat31 = shufflevector <8 x i64> %.splatinsert30, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %142 = add <8 x i64> %.splat31, %.spill.load
  %.spill.load32 = load <8 x i64>, ptr %.spill4, align 64
  %143 = add <8 x i64> %.spill.load32, zeroinitializer
  %144 = add <8 x i64> zeroinitializer, %143
  %145 = add <8 x i64> zeroinitializer, %142
  %146 = mul <8 x i64> %144, splat (i64 66)
  %147 = add <8 x i64> %146, %145
  %148 = extractvalue { ptr, i64 } %9, 0
  %149 = extractelement <8 x i64> %147, i32 %134
  %150 = zext i32 %134 to i64
  %151 = sub i64 %149, %150
  %152 = mul i64 %151, 4
  %buffer.contiguous.address = getelementptr i8, ptr %148, i64 %152
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %129, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %154 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state33 = load <8 x i64>, ptr %.slot, align 64
  %155 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %129)
  %156 = bitcast <8 x i1> %129 to i8
  %157 = call i8 @llvm.cttz.i8(i8 %156, i1 false)
  %158 = zext i8 %157 to i32
  %159 = select i1 %155, i32 %158, i32 0
  %160 = extractelement <8 x i64> %.state33, i32 %159
  %.splatinsert34 = insertelement <8 x i64> poison, i64 %160, i64 0
  %.splat35 = shufflevector <8 x i64> %.splatinsert34, <8 x i64> poison, <8 x i32> zeroinitializer
  %161 = mul <8 x i64> %.splat35, splat (i64 32)
  %162 = add <8 x i64> %154, %161
  %163 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %153, 0
  %164 = insertvalue { <8 x ptr>, <8 x i64> } %163, <8 x i64> %162, 1
  %165 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %164, 1
  %167 = extractelement <8 x ptr> %165, i32 0
  %168 = extractelement <8 x i64> %166, i32 %134
  %169 = zext i32 %134 to i64
  %170 = mul i64 %169, 4
  %171 = sub i64 %168, %170
  %172 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %129)
  %173 = select i1 %172, i64 %171, i64 0
  %private.contiguous.address = getelementptr i8, ptr %167, i64 %173
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %174 = select <8 x i1> %129, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %174, ptr %private.contiguous.address, align 4
  %.state36 = load <8 x i64>, ptr %.slot, align 64
  %175 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %129)
  %176 = bitcast <8 x i1> %129 to i8
  %177 = call i8 @llvm.cttz.i8(i8 %176, i1 false)
  %178 = zext i8 %177 to i32
  %179 = select i1 %175, i32 %178, i32 0
  %180 = extractelement <8 x i64> %.state36, i32 %179
  %181 = add i64 %180, 1
  %.splatinsert37 = insertelement <8 x i64> poison, i64 %181, i64 0
  %.splat38 = shufflevector <8 x i64> %.splatinsert37, <8 x i64> poison, <8 x i32> zeroinitializer
  %182 = load <8 x i64>, ptr %.slot, align 64
  %183 = select <8 x i1> %129, <8 x i64> %.splat38, <8 x i64> %182
  store <8 x i64> %183, ptr %.slot, align 64
  store <8 x i1> %129, ptr %current.mask, align 1
  %184 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %129)
  br i1 %184, label %schedule.1, label %scheduler.loop

schedule.3:                                       ; preds = %uniform.false, %scheduler.dispatch.route
  %185 = load <8 x i1>, ptr %current.mask, align 1
  %186 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %185)
  %187 = bitcast <8 x i1> %185 to i8
  %188 = call i8 @llvm.cttz.i8(i8 %187, i1 false)
  %189 = zext i8 %188 to i32
  %190 = select i1 %186, i32 %189, i32 0
  %.spill.load39 = load <8 x i64>, ptr %.spill, align 64
  %191 = icmp slt <8 x i64> %.spill.load39, splat (i64 2)
  %192 = load <8 x i1>, ptr %.spill5, align 1
  %193 = select <8 x i1> %185, <8 x i1> %191, <8 x i1> %192
  store <8 x i1> %193, ptr %.spill5, align 1
  %194 = and <8 x i1> %185, %191
  %195 = xor <8 x i1> %191, splat (i1 true)
  %196 = and <8 x i1> %185, %195
  %197 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %194)
  %198 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %196)
  %199 = and i1 %197, %198
  br i1 %199, label %varying.divergent, label %varying.coherent

schedule.4:                                       ; preds = %varying.coherent.true, %scheduler.dispatch.route
  %200 = load <8 x i1>, ptr %current.mask, align 1
  %201 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %200)
  %202 = bitcast <8 x i1> %200 to i8
  %203 = call i8 @llvm.cttz.i8(i8 %202, i1 false)
  %204 = zext i8 %203 to i32
  %205 = select i1 %201, i32 %204, i32 0
  %.spill.load44 = load <8 x i64>, ptr %.spill, align 64
  %206 = add <8 x i64> splat (i64 64), %.spill.load44
  %.spill.load45 = load <8 x i64>, ptr %.spill4, align 64
  %207 = add <8 x i64> %.spill.load45, zeroinitializer
  %208 = add <8 x i64> zeroinitializer, %207
  %209 = add <8 x i64> zeroinitializer, %206
  %210 = mul <8 x i64> %208, splat (i64 66)
  %211 = add <8 x i64> %210, %209
  %212 = extractvalue { ptr, i64 } %9, 0
  %213 = extractelement <8 x i64> %211, i32 %205
  %214 = zext i32 %205 to i64
  %215 = sub i64 %213, %214
  %216 = mul i64 %215, 4
  %buffer.contiguous.address46 = getelementptr i8, ptr %212, i64 %216
  %buffer.contiguous.load47 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address46, i32 1, <8 x i1> %200, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load48 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %217 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load48, 0
  %218 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load48, 1
  %219 = add <8 x i64> %218, splat (i64 256)
  %220 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %217, 0
  %221 = insertvalue { <8 x ptr>, <8 x i64> } %220, <8 x i64> %219, 1
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %221, 1
  %224 = extractelement <8 x ptr> %222, i32 0
  %225 = extractelement <8 x i64> %223, i32 %205
  %226 = zext i32 %205 to i64
  %227 = mul i64 %226, 4
  %228 = sub i64 %225, %227
  %229 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %200)
  %230 = select i1 %229, i64 %228, i64 0
  %private.contiguous.address49 = getelementptr i8, ptr %224, i64 %230
  %private.contiguous.preserve50 = load <8 x float>, ptr %private.contiguous.address49, align 4
  %231 = select <8 x i1> %200, <8 x float> %buffer.contiguous.load47, <8 x float> %private.contiguous.preserve50
  store <8 x float> %231, ptr %private.contiguous.address49, align 4
  store <8 x i1> %200, ptr %current.mask, align 1
  %232 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %200)
  br i1 %232, label %schedule.5, label %scheduler.loop

schedule.5:                                       ; preds = %schedule.4, %varying.coherent.false, %scheduler.dispatch.route
  %233 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token = load i32, ptr %current.token, align 4
  %convergence.token.present = icmp ne i32 %convergence.current.token, 0
  br i1 %convergence.token.present, label %convergence.cascade, label %convergence.cascade.exit

schedule.6:                                       ; preds = %schedule.7, %convergence.target.5.ready, %scheduler.dispatch.route
  %234 = load <8 x i1>, ptr %current.mask, align 1
  %235 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %234)
  %236 = bitcast <8 x i1> %234 to i8
  %237 = call i8 @llvm.cttz.i8(i8 %236, i1 false)
  %238 = zext i8 %237 to i32
  %239 = select i1 %235, i32 %238, i32 0
  %.state68 = load <8 x i64>, ptr %.slot8, align 64
  %240 = icmp slt <8 x i64> %.state68, splat (i64 8)
  %241 = and <8 x i1> %234, %240
  %242 = xor <8 x i1> %240, splat (i1 true)
  %243 = and <8 x i1> %234, %242
  %244 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %241)
  %245 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %243)
  %246 = and i1 %244, %245
  br i1 %246, label %varying.divergent69, label %varying.coherent70

schedule.7:                                       ; preds = %varying.coherent.true77, %scheduler.dispatch.route
  %247 = load <8 x i1>, ptr %current.mask, align 1
  %248 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %247)
  %249 = bitcast <8 x i1> %247 to i8
  %250 = call i8 @llvm.cttz.i8(i8 %249, i1 false)
  %251 = zext i8 %250 to i32
  %252 = select i1 %248, i32 %251, i32 0
  %.state79 = load <8 x i64>, ptr %.slot8, align 64
  %253 = add <8 x i64> %.state79, zeroinitializer
  %tile_snapshot.spill.load80 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load80, 0
  %255 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load80, 1
  %256 = mul <8 x i64> %253, splat (i64 32)
  %257 = add <8 x i64> %255, %256
  %258 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %254, 0
  %259 = insertvalue { <8 x ptr>, <8 x i64> } %258, <8 x i64> %257, 1
  %260 = extractvalue { <8 x ptr>, <8 x i64> } %259, 0
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %259, 1
  %262 = getelementptr i8, <8 x ptr> %260, <8 x i64> %261
  %263 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %262, i32 1, <8 x i1> %247, <8 x float> zeroinitializer)
  %264 = fmul <8 x float> %263, %263
  %.state81 = load <8 x float>, ptr %.slot9, align 32
  %265 = fadd <8 x float> %.state81, %264
  %.state82 = load <8 x i64>, ptr %.slot8, align 64
  %266 = add <8 x i64> %.state82, splat (i64 1)
  %tile_snapshot.spill.load83 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load83, 0
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load83, 1
  %269 = mul <8 x i64> %266, splat (i64 32)
  %270 = add <8 x i64> %268, %269
  %271 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %267, 0
  %272 = insertvalue { <8 x ptr>, <8 x i64> } %271, <8 x i64> %270, 1
  %273 = extractvalue { <8 x ptr>, <8 x i64> } %272, 0
  %274 = extractvalue { <8 x ptr>, <8 x i64> } %272, 1
  %275 = getelementptr i8, <8 x ptr> %273, <8 x i64> %274
  %276 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %275, i32 1, <8 x i1> %247, <8 x float> zeroinitializer)
  %277 = fmul <8 x float> %276, %276
  %.state84 = load <8 x float>, ptr %.slot10, align 32
  %278 = fadd <8 x float> %.state84, %277
  %.state85 = load <8 x i64>, ptr %.slot8, align 64
  %279 = add <8 x i64> %.state85, splat (i64 2)
  %tile_snapshot.spill.load86 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %280 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load86, 0
  %281 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load86, 1
  %282 = mul <8 x i64> %279, splat (i64 32)
  %283 = add <8 x i64> %281, %282
  %284 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %280, 0
  %285 = insertvalue { <8 x ptr>, <8 x i64> } %284, <8 x i64> %283, 1
  %286 = extractvalue { <8 x ptr>, <8 x i64> } %285, 0
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %285, 1
  %288 = getelementptr i8, <8 x ptr> %286, <8 x i64> %287
  %289 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %288, i32 1, <8 x i1> %247, <8 x float> zeroinitializer)
  %290 = fmul <8 x float> %289, %289
  %.state87 = load <8 x float>, ptr %.slot11, align 32
  %291 = fadd <8 x float> %.state87, %290
  %.state88 = load <8 x i64>, ptr %.slot8, align 64
  %292 = add <8 x i64> %.state88, splat (i64 3)
  %tile_snapshot.spill.load89 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load89, 0
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load89, 1
  %295 = mul <8 x i64> %292, splat (i64 32)
  %296 = add <8 x i64> %294, %295
  %297 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %293, 0
  %298 = insertvalue { <8 x ptr>, <8 x i64> } %297, <8 x i64> %296, 1
  %299 = extractvalue { <8 x ptr>, <8 x i64> } %298, 0
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %298, 1
  %301 = getelementptr i8, <8 x ptr> %299, <8 x i64> %300
  %302 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %301, i32 1, <8 x i1> %247, <8 x float> zeroinitializer)
  %303 = fmul <8 x float> %302, %302
  %.state90 = load <8 x float>, ptr %.slot12, align 32
  %304 = fadd <8 x float> %.state90, %303
  %.state91 = load <8 x i64>, ptr %.slot8, align 64
  %305 = add <8 x i64> %.state91, splat (i64 4)
  %306 = load <8 x i64>, ptr %.slot8, align 64
  %307 = select <8 x i1> %247, <8 x i64> %305, <8 x i64> %306
  store <8 x i64> %307, ptr %.slot8, align 64
  %308 = load <8 x float>, ptr %.slot9, align 32
  %309 = select <8 x i1> %247, <8 x float> %265, <8 x float> %308
  store <8 x float> %309, ptr %.slot9, align 32
  %310 = load <8 x float>, ptr %.slot10, align 32
  %311 = select <8 x i1> %247, <8 x float> %278, <8 x float> %310
  store <8 x float> %311, ptr %.slot10, align 32
  %312 = load <8 x float>, ptr %.slot11, align 32
  %313 = select <8 x i1> %247, <8 x float> %291, <8 x float> %312
  store <8 x float> %313, ptr %.slot11, align 32
  %314 = load <8 x float>, ptr %.slot12, align 32
  %315 = select <8 x i1> %247, <8 x float> %304, <8 x float> %314
  store <8 x float> %315, ptr %.slot12, align 32
  store <8 x i1> %247, ptr %current.mask, align 1
  %316 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %247)
  br i1 %316, label %schedule.6, label %scheduler.loop

schedule.8:                                       ; preds = %varying.coherent.false78, %scheduler.dispatch.route
  %317 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token94 = load i32, ptr %current.token, align 4
  %convergence.token.present95 = icmp ne i32 %convergence.current.token94, 0
  br i1 %convergence.token.present95, label %convergence.cascade92, label %convergence.cascade.exit93

schedule.9:                                       ; preds = %varying.coherent.true119, %scheduler.dispatch.route
  %318 = load <8 x i1>, ptr %current.mask, align 1
  %319 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %318)
  %320 = bitcast <8 x i1> %318 to i8
  %321 = call i8 @llvm.cttz.i8(i8 %320, i1 false)
  %322 = zext i8 %321 to i32
  %323 = select i1 %319, i32 %322, i32 0
  %tile_snapshot.spill.load122 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 0
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 1
  %326 = add <8 x i64> %325, splat (i64 256)
  %327 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %324, 0
  %328 = insertvalue { <8 x ptr>, <8 x i64> } %327, <8 x i64> %326, 1
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %330 = extractvalue { <8 x ptr>, <8 x i64> } %328, 1
  %331 = extractelement <8 x ptr> %329, i32 0
  %332 = extractelement <8 x i64> %330, i32 %323
  %333 = zext i32 %323 to i64
  %334 = mul i64 %333, 4
  %335 = sub i64 %332, %334
  %336 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %318)
  %337 = select i1 %336, i64 %335, i64 0
  %private.contiguous.address123 = getelementptr i8, ptr %331, i64 %337
  %private.contiguous.load124 = load <8 x float>, ptr %private.contiguous.address123, align 4
  %338 = select <8 x i1> %318, <8 x float> %private.contiguous.load124, <8 x float> zeroinitializer
  %339 = fmul <8 x float> %338, %338
  %.state125 = load <8 x float>, ptr %.slot9, align 32
  %340 = fadd <8 x float> %.state125, %339
  %341 = load <8 x float>, ptr %.slot13, align 32
  %342 = select <8 x i1> %318, <8 x float> %340, <8 x float> %341
  store <8 x float> %342, ptr %.slot13, align 32
  store <8 x i1> %318, ptr %current.mask, align 1
  %343 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %318)
  br i1 %343, label %schedule.10, label %scheduler.loop

schedule.10:                                      ; preds = %schedule.9, %varying.coherent.false120, %scheduler.dispatch.route
  %344 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token128 = load i32, ptr %current.token, align 4
  %convergence.token.present129 = icmp ne i32 %convergence.current.token128, 0
  br i1 %convergence.token.present129, label %convergence.cascade126, label %convergence.cascade.exit127

schedule.11:                                      ; preds = %schedule.12, %convergence.target.10.ready, %scheduler.dispatch.route
  %345 = load <8 x i1>, ptr %current.mask, align 1
  %346 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %345)
  %347 = bitcast <8 x i1> %345 to i8
  %348 = call i8 @llvm.cttz.i8(i8 %347, i1 false)
  %349 = zext i8 %348 to i32
  %350 = select i1 %346, i32 %349, i32 0
  %.state151 = load <8 x i64>, ptr %.slot16, align 64
  %351 = icmp slt <8 x i64> %.state151, splat (i64 8)
  %352 = and <8 x i1> %345, %351
  %353 = xor <8 x i1> %351, splat (i1 true)
  %354 = and <8 x i1> %345, %353
  %355 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %352)
  %356 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %354)
  %357 = and i1 %355, %356
  br i1 %357, label %varying.divergent152, label %varying.coherent153

schedule.12:                                      ; preds = %varying.coherent.true160, %scheduler.dispatch.route
  %358 = load <8 x i1>, ptr %current.mask, align 1
  %359 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %358)
  %360 = bitcast <8 x i1> %358 to i8
  %361 = call i8 @llvm.cttz.i8(i8 %360, i1 false)
  %362 = zext i8 %361 to i32
  %363 = select i1 %359, i32 %362, i32 0
  %.state162 = load <8 x i64>, ptr %.slot16, align 64
  %364 = mul <8 x i64> %.state162, splat (i64 8)
  %.spill.load163 = load <8 x i64>, ptr %.spill, align 64
  %365 = add <8 x i64> %364, %.spill.load163
  %.spill.load164 = load i64, ptr %.spill7, align 4
  %366 = add i64 %.spill.load164, 0
  %367 = add <8 x i64> zeroinitializer, %365
  %368 = mul i64 %366, 66
  %.splatinsert165 = insertelement <8 x i64> poison, i64 %368, i64 0
  %.splat166 = shufflevector <8 x i64> %.splatinsert165, <8 x i64> poison, <8 x i32> zeroinitializer
  %369 = add <8 x i64> %.splat166, %367
  %370 = extractvalue { ptr, i64 } %15, 0
  %371 = extractelement <8 x i64> %369, i32 %363
  %372 = zext i32 %363 to i64
  %373 = sub i64 %371, %372
  %374 = mul i64 %373, 4
  %buffer.contiguous.address167 = getelementptr i8, ptr %370, i64 %374
  %buffer.contiguous.load168 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address167, i32 1, <8 x i1> %358, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load169 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %375 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load169, 0
  %376 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load169, 1
  %.state170 = load <8 x i64>, ptr %.slot16, align 64
  %377 = mul <8 x i64> %.state170, splat (i64 32)
  %378 = add <8 x i64> %376, %377
  %379 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %375, 0
  %380 = insertvalue { <8 x ptr>, <8 x i64> } %379, <8 x i64> %378, 1
  %381 = extractvalue { <8 x ptr>, <8 x i64> } %380, 0
  %382 = extractvalue { <8 x ptr>, <8 x i64> } %380, 1
  %383 = getelementptr i8, <8 x ptr> %381, <8 x i64> %382
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %buffer.contiguous.load168, <8 x ptr> %383, i32 1, <8 x i1> %358)
  %.state171 = load <8 x i64>, ptr %.slot16, align 64
  %384 = add <8 x i64> %.state171, splat (i64 1)
  %385 = load <8 x i64>, ptr %.slot16, align 64
  %386 = select <8 x i1> %358, <8 x i64> %384, <8 x i64> %385
  store <8 x i64> %386, ptr %.slot16, align 64
  store <8 x i1> %358, ptr %current.mask, align 1
  %387 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %358)
  br i1 %387, label %schedule.11, label %scheduler.loop

schedule.13:                                      ; preds = %varying.coherent.false161, %scheduler.dispatch.route
  %388 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token174 = load i32, ptr %current.token, align 4
  %convergence.token.present175 = icmp ne i32 %convergence.current.token174, 0
  br i1 %convergence.token.present175, label %convergence.cascade172, label %convergence.cascade.exit173

schedule.14:                                      ; preds = %varying.coherent.true198, %scheduler.dispatch.route
  %389 = load <8 x i1>, ptr %current.mask, align 1
  %390 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %389)
  %391 = bitcast <8 x i1> %389 to i8
  %392 = call i8 @llvm.cttz.i8(i8 %391, i1 false)
  %393 = zext i8 %392 to i32
  %394 = select i1 %390, i32 %393, i32 0
  %.spill.load200 = load <8 x i64>, ptr %.spill, align 64
  %395 = add <8 x i64> splat (i64 64), %.spill.load200
  %.spill.load201 = load i64, ptr %.spill7, align 4
  %396 = add i64 %.spill.load201, 0
  %397 = add <8 x i64> zeroinitializer, %395
  %398 = mul i64 %396, 66
  %.splatinsert202 = insertelement <8 x i64> poison, i64 %398, i64 0
  %.splat203 = shufflevector <8 x i64> %.splatinsert202, <8 x i64> poison, <8 x i32> zeroinitializer
  %399 = add <8 x i64> %.splat203, %397
  %400 = extractvalue { ptr, i64 } %15, 0
  %401 = extractelement <8 x i64> %399, i32 %394
  %402 = zext i32 %394 to i64
  %403 = sub i64 %401, %402
  %404 = mul i64 %403, 4
  %buffer.contiguous.address204 = getelementptr i8, ptr %400, i64 %404
  %buffer.contiguous.load205 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address204, i32 1, <8 x i1> %389, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load206 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %405 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load206, 0
  %406 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load206, 1
  %407 = add <8 x i64> %406, splat (i64 256)
  %408 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %405, 0
  %409 = insertvalue { <8 x ptr>, <8 x i64> } %408, <8 x i64> %407, 1
  %410 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %411 = extractvalue { <8 x ptr>, <8 x i64> } %409, 1
  %412 = extractelement <8 x ptr> %410, i32 0
  %413 = extractelement <8 x i64> %411, i32 %394
  %414 = zext i32 %394 to i64
  %415 = mul i64 %414, 4
  %416 = sub i64 %413, %415
  %417 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %389)
  %418 = select i1 %417, i64 %416, i64 0
  %private.contiguous.address207 = getelementptr i8, ptr %412, i64 %418
  %private.contiguous.preserve208 = load <8 x float>, ptr %private.contiguous.address207, align 4
  %419 = select <8 x i1> %389, <8 x float> %buffer.contiguous.load205, <8 x float> %private.contiguous.preserve208
  store <8 x float> %419, ptr %private.contiguous.address207, align 4
  store <8 x i1> %389, ptr %current.mask, align 1
  %420 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %389)
  br i1 %420, label %schedule.15, label %scheduler.loop

schedule.15:                                      ; preds = %schedule.14, %varying.coherent.false199, %scheduler.dispatch.route
  %421 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token211 = load i32, ptr %current.token, align 4
  %convergence.token.present212 = icmp ne i32 %convergence.current.token211, 0
  br i1 %convergence.token.present212, label %convergence.cascade209, label %convergence.cascade.exit210

schedule.16:                                      ; preds = %schedule.17, %convergence.target.15.ready, %scheduler.dispatch.route
  %422 = load <8 x i1>, ptr %current.mask, align 1
  %423 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %422)
  %424 = bitcast <8 x i1> %422 to i8
  %425 = call i8 @llvm.cttz.i8(i8 %424, i1 false)
  %426 = zext i8 %425 to i32
  %427 = select i1 %423, i32 %426, i32 0
  %.state229 = load <8 x i64>, ptr %.slot18, align 64
  %428 = icmp slt <8 x i64> %.state229, splat (i64 8)
  %429 = and <8 x i1> %422, %428
  %430 = xor <8 x i1> %428, splat (i1 true)
  %431 = and <8 x i1> %422, %430
  %432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %429)
  %433 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %431)
  %434 = and i1 %432, %433
  br i1 %434, label %varying.divergent230, label %varying.coherent231

schedule.17:                                      ; preds = %varying.coherent.true238, %scheduler.dispatch.route
  %435 = load <8 x i1>, ptr %current.mask, align 1
  %436 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %435)
  %437 = bitcast <8 x i1> %435 to i8
  %438 = call i8 @llvm.cttz.i8(i8 %437, i1 false)
  %439 = zext i8 %438 to i32
  %440 = select i1 %436, i32 %439, i32 0
  %.state240 = load <8 x i64>, ptr %.slot18, align 64
  %441 = mul <8 x i64> %.state240, splat (i64 8)
  %.spill.load241 = load <8 x i64>, ptr %.spill, align 64
  %442 = add <8 x i64> %441, %.spill.load241
  %.spill.load242 = load <8 x i64>, ptr %.spill4, align 64
  %443 = add <8 x i64> %.spill.load242, zeroinitializer
  %444 = add <8 x i64> zeroinitializer, %443
  %445 = add <8 x i64> zeroinitializer, %442
  %446 = mul <8 x i64> %444, splat (i64 66)
  %447 = add <8 x i64> %446, %445
  %tile_snapshot.spill.load243 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %448 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load243, 0
  %449 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load243, 1
  %.state244 = load <8 x i64>, ptr %.slot18, align 64
  %450 = mul <8 x i64> %.state244, splat (i64 32)
  %451 = add <8 x i64> %449, %450
  %452 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %448, 0
  %453 = insertvalue { <8 x ptr>, <8 x i64> } %452, <8 x i64> %451, 1
  %454 = extractvalue { <8 x ptr>, <8 x i64> } %453, 0
  %455 = extractvalue { <8 x ptr>, <8 x i64> } %453, 1
  %456 = getelementptr i8, <8 x ptr> %454, <8 x i64> %455
  %457 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %456, i32 1, <8 x i1> %435, <8 x float> zeroinitializer)
  %.spill.load245 = load <8 x float>, ptr %.spill17, align 32
  %458 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %435)
  %459 = bitcast <8 x i1> %435 to i8
  %460 = call i8 @llvm.cttz.i8(i8 %459, i1 false)
  %461 = zext i8 %460 to i32
  %462 = select i1 %458, i32 %461, i32 0
  %463 = extractelement <8 x float> %.spill.load245, i32 %462
  %.splatinsert246 = insertelement <8 x float> poison, float %463, i64 0
  %.splat247 = shufflevector <8 x float> %.splatinsert246, <8 x float> poison, <8 x i32> zeroinitializer
  %464 = fdiv <8 x float> %457, %.splat247
  %tile_snapshot.spill.load248 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %465 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 0
  %466 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 1
  %.state249 = load <8 x i64>, ptr %.slot18, align 64
  %467 = mul <8 x i64> %.state249, splat (i64 32)
  %468 = add <8 x i64> %466, %467
  %469 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %465, 0
  %470 = insertvalue { <8 x ptr>, <8 x i64> } %469, <8 x i64> %468, 1
  %471 = extractvalue { <8 x ptr>, <8 x i64> } %470, 0
  %472 = extractvalue { <8 x ptr>, <8 x i64> } %470, 1
  %473 = getelementptr i8, <8 x ptr> %471, <8 x i64> %472
  %474 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %473, i32 1, <8 x i1> %435, <8 x float> zeroinitializer)
  %475 = fmul <8 x float> %464, %474
  %476 = extractvalue { ptr, i64 } %27, 0
  %477 = extractelement <8 x i64> %447, i32 %440
  %478 = zext i32 %440 to i64
  %479 = sub i64 %477, %478
  %480 = mul i64 %479, 4
  %buffer.contiguous.address250 = getelementptr i8, ptr %476, i64 %480
  call void @llvm.masked.store.v8f32.p0(<8 x float> %475, ptr %buffer.contiguous.address250, i32 1, <8 x i1> %435)
  %.state251 = load <8 x i64>, ptr %.slot18, align 64
  %481 = add <8 x i64> %.state251, splat (i64 1)
  %482 = load <8 x i64>, ptr %.slot18, align 64
  %483 = select <8 x i1> %435, <8 x i64> %481, <8 x i64> %482
  store <8 x i64> %483, ptr %.slot18, align 64
  store <8 x i1> %435, ptr %current.mask, align 1
  %484 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %435)
  br i1 %484, label %schedule.16, label %scheduler.loop

schedule.18:                                      ; preds = %varying.coherent.false239, %scheduler.dispatch.route
  %485 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token254 = load i32, ptr %current.token, align 4
  %convergence.token.present255 = icmp ne i32 %convergence.current.token254, 0
  br i1 %convergence.token.present255, label %convergence.cascade252, label %convergence.cascade.exit253

schedule.19:                                      ; preds = %varying.coherent.true278, %scheduler.dispatch.route
  %486 = load <8 x i1>, ptr %current.mask, align 1
  %487 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %486)
  %488 = bitcast <8 x i1> %486 to i8
  %489 = call i8 @llvm.cttz.i8(i8 %488, i1 false)
  %490 = zext i8 %489 to i32
  %491 = select i1 %487, i32 %490, i32 0
  %.spill.load280 = load <8 x i64>, ptr %.spill, align 64
  %492 = add <8 x i64> splat (i64 64), %.spill.load280
  %.spill.load281 = load <8 x i64>, ptr %.spill4, align 64
  %493 = add <8 x i64> %.spill.load281, zeroinitializer
  %494 = add <8 x i64> zeroinitializer, %493
  %495 = add <8 x i64> zeroinitializer, %492
  %496 = mul <8 x i64> %494, splat (i64 66)
  %497 = add <8 x i64> %496, %495
  %tile_snapshot.spill.load282 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %498 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load282, 0
  %499 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load282, 1
  %500 = add <8 x i64> %499, splat (i64 256)
  %501 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %498, 0
  %502 = insertvalue { <8 x ptr>, <8 x i64> } %501, <8 x i64> %500, 1
  %503 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %504 = extractvalue { <8 x ptr>, <8 x i64> } %502, 1
  %505 = extractelement <8 x ptr> %503, i32 0
  %506 = extractelement <8 x i64> %504, i32 %491
  %507 = zext i32 %491 to i64
  %508 = mul i64 %507, 4
  %509 = sub i64 %506, %508
  %510 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %486)
  %511 = select i1 %510, i64 %509, i64 0
  %private.contiguous.address283 = getelementptr i8, ptr %505, i64 %511
  %private.contiguous.load284 = load <8 x float>, ptr %private.contiguous.address283, align 4
  %512 = select <8 x i1> %486, <8 x float> %private.contiguous.load284, <8 x float> zeroinitializer
  %.spill.load285 = load <8 x float>, ptr %.spill17, align 32
  %513 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %486)
  %514 = bitcast <8 x i1> %486 to i8
  %515 = call i8 @llvm.cttz.i8(i8 %514, i1 false)
  %516 = zext i8 %515 to i32
  %517 = select i1 %513, i32 %516, i32 0
  %518 = extractelement <8 x float> %.spill.load285, i32 %517
  %.splatinsert286 = insertelement <8 x float> poison, float %518, i64 0
  %.splat287 = shufflevector <8 x float> %.splatinsert286, <8 x float> poison, <8 x i32> zeroinitializer
  %519 = fdiv <8 x float> %512, %.splat287
  %tile_snapshot.spill.load288 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %520 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load288, 0
  %521 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load288, 1
  %522 = add <8 x i64> %521, splat (i64 256)
  %523 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %520, 0
  %524 = insertvalue { <8 x ptr>, <8 x i64> } %523, <8 x i64> %522, 1
  %525 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %526 = extractvalue { <8 x ptr>, <8 x i64> } %524, 1
  %527 = extractelement <8 x ptr> %525, i32 0
  %528 = extractelement <8 x i64> %526, i32 %491
  %529 = zext i32 %491 to i64
  %530 = mul i64 %529, 4
  %531 = sub i64 %528, %530
  %532 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %486)
  %533 = select i1 %532, i64 %531, i64 0
  %private.contiguous.address289 = getelementptr i8, ptr %527, i64 %533
  %private.contiguous.load290 = load <8 x float>, ptr %private.contiguous.address289, align 4
  %534 = select <8 x i1> %486, <8 x float> %private.contiguous.load290, <8 x float> zeroinitializer
  %535 = fmul <8 x float> %519, %534
  %536 = extractvalue { ptr, i64 } %27, 0
  %537 = extractelement <8 x i64> %497, i32 %491
  %538 = zext i32 %491 to i64
  %539 = sub i64 %537, %538
  %540 = mul i64 %539, 4
  %buffer.contiguous.address291 = getelementptr i8, ptr %536, i64 %540
  call void @llvm.masked.store.v8f32.p0(<8 x float> %535, ptr %buffer.contiguous.address291, i32 1, <8 x i1> %486)
  store <8 x i1> %486, ptr %current.mask, align 1
  %541 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %486)
  br i1 %541, label %schedule.20, label %scheduler.loop

schedule.20:                                      ; preds = %schedule.19, %varying.coherent.false279, %scheduler.dispatch.route
  %542 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token294 = load i32, ptr %current.token, align 4
  %convergence.token.present295 = icmp ne i32 %convergence.current.token294, 0
  br i1 %convergence.token.present295, label %convergence.cascade292, label %convergence.cascade.exit293

uniform.true:                                     ; preds = %schedule.1
  store <8 x i1> %116, ptr %current.mask, align 1
  %543 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %116)
  br i1 %543, label %schedule.2, label %scheduler.loop

uniform.false:                                    ; preds = %schedule.1
  store <8 x i1> %116, ptr %current.mask, align 1
  %544 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %116)
  br i1 %544, label %schedule.3, label %scheduler.loop

varying.divergent:                                ; preds = %schedule.3
  %545 = load i32, ptr %current.token, align 4
  %546 = icmp ne i32 %545, 0
  %547 = sub i32 %545, 1
  %548 = select i1 %546, i32 %547, i32 0
  %549 = load i8, ptr %frame.active, align 1
  %550 = trunc i32 %548 to i8
  %551 = shl i8 1, %550
  %552 = and i8 %549, %551
  %553 = icmp ne i8 %552, 0
  %554 = load <8 x i32>, ptr %frame.static.id, align 32
  %555 = extractelement <8 x i32> %554, i32 %548
  %556 = icmp eq i32 %555, 0
  %557 = and i1 %553, %556
  %558 = and i1 %546, %557
  %559 = xor i1 %558, true
  %560 = and i1 true, %559
  %561 = xor i8 %549, -1
  %562 = icmp ne i8 %561, 0
  %563 = xor i1 %562, true
  %564 = and i1 %560, %563
  br i1 %564, label %convergence.overflow.trap, label %convergence.overflow.resume

varying.coherent:                                 ; preds = %schedule.3
  br i1 %197, label %varying.coherent.true, label %varying.coherent.false

convergence.overflow.trap:                        ; preds = %varying.divergent
  call void @llvm.trap()
  unreachable

convergence.overflow.resume:                      ; preds = %varying.divergent
  %565 = call i8 @llvm.cttz.i8(i8 %561, i1 false)
  %566 = zext i8 %565 to i32
  %567 = select i1 %562, i32 %566, i32 0
  %568 = trunc i32 %567 to i8
  %569 = shl i8 1, %568
  %570 = or i8 %549, %569
  %571 = select i1 %560, i8 %570, i8 %549
  store i8 %571, ptr %frame.active, align 1
  %572 = load <8 x i32>, ptr %frame.static.id, align 32
  %573 = extractelement <8 x i32> %572, i32 %567
  %574 = select i1 %560, i32 0, i32 %573
  %575 = load <8 x i32>, ptr %frame.static.id, align 32
  %576 = insertelement <8 x i32> %575, i32 %574, i32 %567
  store <8 x i32> %576, ptr %frame.static.id, align 32
  %577 = load <8 x i32>, ptr %frame.parent.token, align 32
  %578 = extractelement <8 x i32> %577, i32 %567
  %579 = select i1 %560, i32 %545, i32 %578
  %580 = load <8 x i32>, ptr %frame.parent.token, align 32
  %581 = insertelement <8 x i32> %580, i32 %579, i32 %567
  store <8 x i32> %581, ptr %frame.parent.token, align 32
  %582 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %567
  %583 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %567
  %584 = load <8 x i1>, ptr %582, align 1
  %585 = load <8 x i1>, ptr %583, align 1
  %586 = select i1 %560, <8 x i1> %185, <8 x i1> %584
  store <8 x i1> %586, ptr %582, align 1
  %587 = select i1 %560, <8 x i1> zeroinitializer, <8 x i1> %585
  store <8 x i1> %587, ptr %583, align 1
  %588 = add i32 %567, 1
  %589 = select i1 %558, i32 %545, i32 %588
  %590 = select i1 true, i32 %589, i32 %545
  store i32 %590, ptr %current.token, align 4
  %591 = load i32, ptr %current.token, align 4
  %592 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %194)
  %593 = load i32, ptr %ready.count, align 4
  %594 = icmp uge i32 %593, 8
  %595 = and i1 %592, %594
  br i1 %595, label %ready.overflow.trap40, label %ready.overflow.resume41

ready.overflow.trap40:                            ; preds = %convergence.overflow.resume
  call void @llvm.trap()
  unreachable

ready.overflow.resume41:                          ; preds = %convergence.overflow.resume
  %596 = select i1 %592, i32 %593, i32 0
  %597 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %596
  %598 = load <8 x i1>, ptr %597, align 1
  %599 = select i1 %592, <8 x i1> %194, <8 x i1> %598
  store <8 x i1> %599, ptr %597, align 1
  %600 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %596
  %601 = load i32, ptr %600, align 4
  %602 = select i1 %592, i32 4, i32 %601
  store i32 %602, ptr %600, align 4
  %603 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %596
  %604 = load i32, ptr %603, align 4
  %605 = select i1 %592, i32 %591, i32 %604
  store i32 %605, ptr %603, align 4
  %606 = add i32 %593, 1
  %607 = select i1 %592, i32 %606, i32 %593
  store i32 %607, ptr %ready.count, align 4
  %608 = load <8 x i1>, ptr %runnable.mask, align 1
  %609 = or <8 x i1> %608, %194
  store <8 x i1> %609, ptr %runnable.mask, align 1
  %610 = load i32, ptr %current.token, align 4
  %611 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %196)
  %612 = load i32, ptr %ready.count, align 4
  %613 = icmp uge i32 %612, 8
  %614 = and i1 %611, %613
  br i1 %614, label %ready.overflow.trap42, label %ready.overflow.resume43

ready.overflow.trap42:                            ; preds = %ready.overflow.resume41
  call void @llvm.trap()
  unreachable

ready.overflow.resume43:                          ; preds = %ready.overflow.resume41
  %615 = select i1 %611, i32 %612, i32 0
  %616 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %615
  %617 = load <8 x i1>, ptr %616, align 1
  %618 = select i1 %611, <8 x i1> %196, <8 x i1> %617
  store <8 x i1> %618, ptr %616, align 1
  %619 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %615
  %620 = load i32, ptr %619, align 4
  %621 = select i1 %611, i32 5, i32 %620
  store i32 %621, ptr %619, align 4
  %622 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %615
  %623 = load i32, ptr %622, align 4
  %624 = select i1 %611, i32 %610, i32 %623
  store i32 %624, ptr %622, align 4
  %625 = add i32 %612, 1
  %626 = select i1 %611, i32 %625, i32 %612
  store i32 %626, ptr %ready.count, align 4
  %627 = load <8 x i1>, ptr %runnable.mask, align 1
  %628 = or <8 x i1> %627, %196
  store <8 x i1> %628, ptr %runnable.mask, align 1
  br label %scheduler.loop

varying.coherent.true:                            ; preds = %varying.coherent
  store <8 x i1> %185, ptr %current.mask, align 1
  %629 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %185)
  br i1 %629, label %schedule.4, label %scheduler.loop

varying.coherent.false:                           ; preds = %varying.coherent
  store <8 x i1> %185, ptr %current.mask, align 1
  %630 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %185)
  br i1 %630, label %schedule.5, label %scheduler.loop

convergence.cascade:                              ; preds = %convergence.cascade, %schedule.5
  %convergence.cascade.flow = phi <8 x i1> [ %233, %schedule.5 ], [ %673, %convergence.cascade ]
  %convergence.cascade.depth = phi i32 [ 0, %schedule.5 ], [ %674, %convergence.cascade ]
  %631 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow)
  %632 = load i32, ptr %current.token, align 4
  %633 = icmp ne i32 %632, 0
  %634 = and i1 %631, %633
  %635 = sub i32 %632, 1
  %636 = select i1 %634, i32 %635, i32 0
  %637 = load i8, ptr %frame.active, align 1
  %638 = trunc i32 %636 to i8
  %639 = shl i8 1, %638
  %640 = and i8 %637, %639
  %641 = icmp ne i8 %640, 0
  %642 = load <8 x i32>, ptr %frame.static.id, align 32
  %643 = extractelement <8 x i32> %642, i32 %636
  %convergence.target.pointer = getelementptr inbounds [7 x i32], ptr @convergence.targets, i32 0, i32 %643
  %convergence.dynamic.target = load i32, ptr %convergence.target.pointer, align 4
  %644 = icmp eq i32 %convergence.dynamic.target, 5
  %645 = and i1 %641, %644
  %646 = and i1 %634, %645
  %647 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %636
  %648 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %636
  %649 = load <8 x i1>, ptr %647, align 1
  %650 = load <8 x i1>, ptr %648, align 1
  %651 = or <8 x i1> %650, %convergence.cascade.flow
  %652 = load <8 x i1>, ptr %live.mask, align 1
  %653 = and <8 x i1> %649, %652
  %654 = icmp eq <8 x i1> %651, %653
  %655 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %654)
  %656 = and i1 %646, %655
  %657 = select i1 %656, <8 x i1> zeroinitializer, <8 x i1> %651
  %658 = select i1 %646, <8 x i1> %657, <8 x i1> %650
  store <8 x i1> %658, ptr %648, align 1
  %659 = select i1 %656, <8 x i1> zeroinitializer, <8 x i1> %649
  store <8 x i1> %659, ptr %647, align 1
  %660 = trunc i32 %636 to i8
  %661 = shl i8 1, %660
  %662 = xor i8 %661, -1
  %663 = and i8 %637, %662
  %664 = select i1 %656, i8 %663, i8 %637
  store i8 %664, ptr %frame.active, align 1
  %.splatinsert51 = insertelement <8 x i1> poison, i1 %646, i64 0
  %.splat52 = shufflevector <8 x i1> %.splatinsert51, <8 x i1> poison, <8 x i32> zeroinitializer
  %665 = and <8 x i1> %convergence.cascade.flow, %.splat52
  %666 = load <8 x i1>, ptr %runnable.mask, align 1
  %667 = xor <8 x i1> %665, splat (i1 true)
  %668 = and <8 x i1> %666, %667
  store <8 x i1> %668, ptr %runnable.mask, align 1
  %.splatinsert53 = insertelement <8 x i1> poison, i1 %656, i64 0
  %.splat54 = shufflevector <8 x i1> %.splatinsert53, <8 x i1> poison, <8 x i32> zeroinitializer
  %669 = select <8 x i1> %.splat54, <8 x i1> %651, <8 x i1> zeroinitializer
  %670 = load <8 x i32>, ptr %frame.parent.token, align 32
  %671 = extractelement <8 x i32> %670, i32 %636
  %672 = select i1 %656, i32 %671, i32 %632
  store i32 %672, ptr %current.token, align 4
  %.splatinsert55 = insertelement <8 x i1> poison, i1 %646, i64 0
  %.splat56 = shufflevector <8 x i1> %.splatinsert55, <8 x i1> poison, <8 x i32> zeroinitializer
  %673 = select <8 x i1> %.splat56, <8 x i1> %669, <8 x i1> %convergence.cascade.flow
  %674 = add i32 %convergence.cascade.depth, 1
  %675 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %673)
  %676 = icmp ult i32 %674, 8
  %677 = and i1 %675, %676
  %678 = and i1 %646, %677
  %convergence.parent.token = load i32, ptr %current.token, align 4
  %convergence.parent.present = icmp ne i32 %convergence.parent.token, 0
  %679 = and i1 %678, %convergence.parent.present
  br i1 %679, label %convergence.cascade, label %convergence.cascade.exit

convergence.cascade.exit:                         ; preds = %convergence.cascade, %schedule.5
  %convergence.cascade.result = phi <8 x i1> [ %233, %schedule.5 ], [ %673, %convergence.cascade ]
  %680 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %680, label %convergence.target.5.ready, label %scheduler.loop

convergence.target.5.ready:                       ; preds = %convergence.cascade.exit
  %681 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %682 = bitcast <8 x i1> %convergence.cascade.result to i8
  %683 = call i8 @llvm.cttz.i8(i8 %682, i1 false)
  %684 = zext i8 %683 to i32
  %685 = select i1 %681, i32 %684, i32 0
  store float 0.000000e+00, ptr %.spill6, align 4
  store i64 0, ptr %.spill7, align 4
  %tile_snapshot.spill.load57 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %686 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load57, 0
  %687 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load57, 1
  %688 = add <8 x i64> %687, zeroinitializer
  %689 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %686, 0
  %690 = insertvalue { <8 x ptr>, <8 x i64> } %689, <8 x i64> %688, 1
  %691 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %692 = extractvalue { <8 x ptr>, <8 x i64> } %690, 1
  %693 = extractelement <8 x ptr> %691, i32 0
  %694 = extractelement <8 x i64> %692, i32 %685
  %695 = zext i32 %685 to i64
  %696 = mul i64 %695, 4
  %697 = sub i64 %694, %696
  %698 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %699 = select i1 %698, i64 %697, i64 0
  %private.contiguous.address58 = getelementptr i8, ptr %693, i64 %699
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address58, align 4
  %700 = select <8 x i1> %convergence.cascade.result, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %701 = fmul <8 x float> %700, %700
  %tile_snapshot.spill.load59 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %702 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load59, 0
  %703 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load59, 1
  %704 = add <8 x i64> %703, splat (i64 32)
  %705 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %702, 0
  %706 = insertvalue { <8 x ptr>, <8 x i64> } %705, <8 x i64> %704, 1
  %707 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %708 = extractvalue { <8 x ptr>, <8 x i64> } %706, 1
  %709 = extractelement <8 x ptr> %707, i32 0
  %710 = extractelement <8 x i64> %708, i32 %685
  %711 = zext i32 %685 to i64
  %712 = mul i64 %711, 4
  %713 = sub i64 %710, %712
  %714 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %715 = select i1 %714, i64 %713, i64 0
  %private.contiguous.address60 = getelementptr i8, ptr %709, i64 %715
  %private.contiguous.load61 = load <8 x float>, ptr %private.contiguous.address60, align 4
  %716 = select <8 x i1> %convergence.cascade.result, <8 x float> %private.contiguous.load61, <8 x float> zeroinitializer
  %717 = fmul <8 x float> %716, %716
  %tile_snapshot.spill.load62 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %718 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 0
  %719 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 1
  %720 = add <8 x i64> %719, splat (i64 64)
  %721 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %718, 0
  %722 = insertvalue { <8 x ptr>, <8 x i64> } %721, <8 x i64> %720, 1
  %723 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %724 = extractvalue { <8 x ptr>, <8 x i64> } %722, 1
  %725 = extractelement <8 x ptr> %723, i32 0
  %726 = extractelement <8 x i64> %724, i32 %685
  %727 = zext i32 %685 to i64
  %728 = mul i64 %727, 4
  %729 = sub i64 %726, %728
  %730 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %731 = select i1 %730, i64 %729, i64 0
  %private.contiguous.address63 = getelementptr i8, ptr %725, i64 %731
  %private.contiguous.load64 = load <8 x float>, ptr %private.contiguous.address63, align 4
  %732 = select <8 x i1> %convergence.cascade.result, <8 x float> %private.contiguous.load64, <8 x float> zeroinitializer
  %733 = fmul <8 x float> %732, %732
  %tile_snapshot.spill.load65 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %734 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 0
  %735 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 1
  %736 = add <8 x i64> %735, splat (i64 96)
  %737 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %734, 0
  %738 = insertvalue { <8 x ptr>, <8 x i64> } %737, <8 x i64> %736, 1
  %739 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %740 = extractvalue { <8 x ptr>, <8 x i64> } %738, 1
  %741 = extractelement <8 x ptr> %739, i32 0
  %742 = extractelement <8 x i64> %740, i32 %685
  %743 = zext i32 %685 to i64
  %744 = mul i64 %743, 4
  %745 = sub i64 %742, %744
  %746 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %747 = select i1 %746, i64 %745, i64 0
  %private.contiguous.address66 = getelementptr i8, ptr %741, i64 %747
  %private.contiguous.load67 = load <8 x float>, ptr %private.contiguous.address66, align 4
  %748 = select <8 x i1> %convergence.cascade.result, <8 x float> %private.contiguous.load67, <8 x float> zeroinitializer
  %749 = fmul <8 x float> %748, %748
  %750 = load <8 x i64>, ptr %.slot8, align 64
  %751 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 4), <8 x i64> %750
  store <8 x i64> %751, ptr %.slot8, align 64
  %752 = load <8 x float>, ptr %.slot9, align 32
  %753 = select <8 x i1> %convergence.cascade.result, <8 x float> %701, <8 x float> %752
  store <8 x float> %753, ptr %.slot9, align 32
  %754 = load <8 x float>, ptr %.slot10, align 32
  %755 = select <8 x i1> %convergence.cascade.result, <8 x float> %717, <8 x float> %754
  store <8 x float> %755, ptr %.slot10, align 32
  %756 = load <8 x float>, ptr %.slot11, align 32
  %757 = select <8 x i1> %convergence.cascade.result, <8 x float> %733, <8 x float> %756
  store <8 x float> %757, ptr %.slot11, align 32
  %758 = load <8 x float>, ptr %.slot12, align 32
  %759 = select <8 x i1> %convergence.cascade.result, <8 x float> %749, <8 x float> %758
  store <8 x float> %759, ptr %.slot12, align 32
  store <8 x i1> %convergence.cascade.result, ptr %current.mask, align 1
  %760 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %760, label %schedule.6, label %scheduler.loop

varying.divergent69:                              ; preds = %schedule.6
  %761 = load i32, ptr %current.token, align 4
  %762 = icmp ne i32 %761, 0
  %763 = sub i32 %761, 1
  %764 = select i1 %762, i32 %763, i32 0
  %765 = load i8, ptr %frame.active, align 1
  %766 = trunc i32 %764 to i8
  %767 = shl i8 1, %766
  %768 = and i8 %765, %767
  %769 = icmp ne i8 %768, 0
  %770 = load <8 x i32>, ptr %frame.static.id, align 32
  %771 = extractelement <8 x i32> %770, i32 %764
  %772 = icmp eq i32 %771, 1
  %773 = and i1 %769, %772
  %774 = and i1 %762, %773
  %775 = xor i1 %774, true
  %776 = and i1 true, %775
  %777 = xor i8 %765, -1
  %778 = icmp ne i8 %777, 0
  %779 = xor i1 %778, true
  %780 = and i1 %776, %779
  br i1 %780, label %convergence.overflow.trap71, label %convergence.overflow.resume72

varying.coherent70:                               ; preds = %schedule.6
  br i1 %244, label %varying.coherent.true77, label %varying.coherent.false78

convergence.overflow.trap71:                      ; preds = %varying.divergent69
  call void @llvm.trap()
  unreachable

convergence.overflow.resume72:                    ; preds = %varying.divergent69
  %781 = call i8 @llvm.cttz.i8(i8 %777, i1 false)
  %782 = zext i8 %781 to i32
  %783 = select i1 %778, i32 %782, i32 0
  %784 = trunc i32 %783 to i8
  %785 = shl i8 1, %784
  %786 = or i8 %765, %785
  %787 = select i1 %776, i8 %786, i8 %765
  store i8 %787, ptr %frame.active, align 1
  %788 = load <8 x i32>, ptr %frame.static.id, align 32
  %789 = extractelement <8 x i32> %788, i32 %783
  %790 = select i1 %776, i32 1, i32 %789
  %791 = load <8 x i32>, ptr %frame.static.id, align 32
  %792 = insertelement <8 x i32> %791, i32 %790, i32 %783
  store <8 x i32> %792, ptr %frame.static.id, align 32
  %793 = load <8 x i32>, ptr %frame.parent.token, align 32
  %794 = extractelement <8 x i32> %793, i32 %783
  %795 = select i1 %776, i32 %761, i32 %794
  %796 = load <8 x i32>, ptr %frame.parent.token, align 32
  %797 = insertelement <8 x i32> %796, i32 %795, i32 %783
  store <8 x i32> %797, ptr %frame.parent.token, align 32
  %798 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %783
  %799 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %783
  %800 = load <8 x i1>, ptr %798, align 1
  %801 = load <8 x i1>, ptr %799, align 1
  %802 = select i1 %776, <8 x i1> %234, <8 x i1> %800
  store <8 x i1> %802, ptr %798, align 1
  %803 = select i1 %776, <8 x i1> zeroinitializer, <8 x i1> %801
  store <8 x i1> %803, ptr %799, align 1
  %804 = add i32 %783, 1
  %805 = select i1 %774, i32 %761, i32 %804
  %806 = select i1 true, i32 %805, i32 %761
  store i32 %806, ptr %current.token, align 4
  %807 = load i32, ptr %current.token, align 4
  %808 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %241)
  %809 = load i32, ptr %ready.count, align 4
  %810 = icmp uge i32 %809, 8
  %811 = and i1 %808, %810
  br i1 %811, label %ready.overflow.trap73, label %ready.overflow.resume74

ready.overflow.trap73:                            ; preds = %convergence.overflow.resume72
  call void @llvm.trap()
  unreachable

ready.overflow.resume74:                          ; preds = %convergence.overflow.resume72
  %812 = select i1 %808, i32 %809, i32 0
  %813 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %812
  %814 = load <8 x i1>, ptr %813, align 1
  %815 = select i1 %808, <8 x i1> %241, <8 x i1> %814
  store <8 x i1> %815, ptr %813, align 1
  %816 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %812
  %817 = load i32, ptr %816, align 4
  %818 = select i1 %808, i32 7, i32 %817
  store i32 %818, ptr %816, align 4
  %819 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %812
  %820 = load i32, ptr %819, align 4
  %821 = select i1 %808, i32 %807, i32 %820
  store i32 %821, ptr %819, align 4
  %822 = add i32 %809, 1
  %823 = select i1 %808, i32 %822, i32 %809
  store i32 %823, ptr %ready.count, align 4
  %824 = load <8 x i1>, ptr %runnable.mask, align 1
  %825 = or <8 x i1> %824, %241
  store <8 x i1> %825, ptr %runnable.mask, align 1
  %826 = load i32, ptr %current.token, align 4
  %827 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %243)
  %828 = load i32, ptr %ready.count, align 4
  %829 = icmp uge i32 %828, 8
  %830 = and i1 %827, %829
  br i1 %830, label %ready.overflow.trap75, label %ready.overflow.resume76

ready.overflow.trap75:                            ; preds = %ready.overflow.resume74
  call void @llvm.trap()
  unreachable

ready.overflow.resume76:                          ; preds = %ready.overflow.resume74
  %831 = select i1 %827, i32 %828, i32 0
  %832 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %831
  %833 = load <8 x i1>, ptr %832, align 1
  %834 = select i1 %827, <8 x i1> %243, <8 x i1> %833
  store <8 x i1> %834, ptr %832, align 1
  %835 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %831
  %836 = load i32, ptr %835, align 4
  %837 = select i1 %827, i32 8, i32 %836
  store i32 %837, ptr %835, align 4
  %838 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %831
  %839 = load i32, ptr %838, align 4
  %840 = select i1 %827, i32 %826, i32 %839
  store i32 %840, ptr %838, align 4
  %841 = add i32 %828, 1
  %842 = select i1 %827, i32 %841, i32 %828
  store i32 %842, ptr %ready.count, align 4
  %843 = load <8 x i1>, ptr %runnable.mask, align 1
  %844 = or <8 x i1> %843, %243
  store <8 x i1> %844, ptr %runnable.mask, align 1
  br label %scheduler.loop

varying.coherent.true77:                          ; preds = %varying.coherent70
  store <8 x i1> %234, ptr %current.mask, align 1
  %845 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %234)
  br i1 %845, label %schedule.7, label %scheduler.loop

varying.coherent.false78:                         ; preds = %varying.coherent70
  store <8 x i1> %234, ptr %current.mask, align 1
  %846 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %234)
  br i1 %846, label %schedule.8, label %scheduler.loop

convergence.cascade92:                            ; preds = %convergence.cascade92, %schedule.8
  %convergence.cascade.flow96 = phi <8 x i1> [ %317, %schedule.8 ], [ %889, %convergence.cascade92 ]
  %convergence.cascade.depth97 = phi i32 [ 0, %schedule.8 ], [ %890, %convergence.cascade92 ]
  %847 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow96)
  %848 = load i32, ptr %current.token, align 4
  %849 = icmp ne i32 %848, 0
  %850 = and i1 %847, %849
  %851 = sub i32 %848, 1
  %852 = select i1 %850, i32 %851, i32 0
  %853 = load i8, ptr %frame.active, align 1
  %854 = trunc i32 %852 to i8
  %855 = shl i8 1, %854
  %856 = and i8 %853, %855
  %857 = icmp ne i8 %856, 0
  %858 = load <8 x i32>, ptr %frame.static.id, align 32
  %859 = extractelement <8 x i32> %858, i32 %852
  %convergence.target.pointer98 = getelementptr inbounds [7 x i32], ptr @convergence.targets, i32 0, i32 %859
  %convergence.dynamic.target99 = load i32, ptr %convergence.target.pointer98, align 4
  %860 = icmp eq i32 %convergence.dynamic.target99, 8
  %861 = and i1 %857, %860
  %862 = and i1 %850, %861
  %863 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %852
  %864 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %852
  %865 = load <8 x i1>, ptr %863, align 1
  %866 = load <8 x i1>, ptr %864, align 1
  %867 = or <8 x i1> %866, %convergence.cascade.flow96
  %868 = load <8 x i1>, ptr %live.mask, align 1
  %869 = and <8 x i1> %865, %868
  %870 = icmp eq <8 x i1> %867, %869
  %871 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %870)
  %872 = and i1 %862, %871
  %873 = select i1 %872, <8 x i1> zeroinitializer, <8 x i1> %867
  %874 = select i1 %862, <8 x i1> %873, <8 x i1> %866
  store <8 x i1> %874, ptr %864, align 1
  %875 = select i1 %872, <8 x i1> zeroinitializer, <8 x i1> %865
  store <8 x i1> %875, ptr %863, align 1
  %876 = trunc i32 %852 to i8
  %877 = shl i8 1, %876
  %878 = xor i8 %877, -1
  %879 = and i8 %853, %878
  %880 = select i1 %872, i8 %879, i8 %853
  store i8 %880, ptr %frame.active, align 1
  %.splatinsert100 = insertelement <8 x i1> poison, i1 %862, i64 0
  %.splat101 = shufflevector <8 x i1> %.splatinsert100, <8 x i1> poison, <8 x i32> zeroinitializer
  %881 = and <8 x i1> %convergence.cascade.flow96, %.splat101
  %882 = load <8 x i1>, ptr %runnable.mask, align 1
  %883 = xor <8 x i1> %881, splat (i1 true)
  %884 = and <8 x i1> %882, %883
  store <8 x i1> %884, ptr %runnable.mask, align 1
  %.splatinsert102 = insertelement <8 x i1> poison, i1 %872, i64 0
  %.splat103 = shufflevector <8 x i1> %.splatinsert102, <8 x i1> poison, <8 x i32> zeroinitializer
  %885 = select <8 x i1> %.splat103, <8 x i1> %867, <8 x i1> zeroinitializer
  %886 = load <8 x i32>, ptr %frame.parent.token, align 32
  %887 = extractelement <8 x i32> %886, i32 %852
  %888 = select i1 %872, i32 %887, i32 %848
  store i32 %888, ptr %current.token, align 4
  %.splatinsert104 = insertelement <8 x i1> poison, i1 %862, i64 0
  %.splat105 = shufflevector <8 x i1> %.splatinsert104, <8 x i1> poison, <8 x i32> zeroinitializer
  %889 = select <8 x i1> %.splat105, <8 x i1> %885, <8 x i1> %convergence.cascade.flow96
  %890 = add i32 %convergence.cascade.depth97, 1
  %891 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %889)
  %892 = icmp ult i32 %890, 8
  %893 = and i1 %891, %892
  %894 = and i1 %862, %893
  %convergence.parent.token106 = load i32, ptr %current.token, align 4
  %convergence.parent.present107 = icmp ne i32 %convergence.parent.token106, 0
  %895 = and i1 %894, %convergence.parent.present107
  br i1 %895, label %convergence.cascade92, label %convergence.cascade.exit93

convergence.cascade.exit93:                       ; preds = %convergence.cascade92, %schedule.8
  %convergence.cascade.result108 = phi <8 x i1> [ %317, %schedule.8 ], [ %889, %convergence.cascade92 ]
  %896 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result108)
  br i1 %896, label %convergence.target.8.ready, label %scheduler.loop

convergence.target.8.ready:                       ; preds = %convergence.cascade.exit93
  %897 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result108)
  %898 = bitcast <8 x i1> %convergence.cascade.result108 to i8
  %899 = call i8 @llvm.cttz.i8(i8 %898, i1 false)
  %900 = zext i8 %899 to i32
  %901 = select i1 %897, i32 %900, i32 0
  %.spill.load109 = load <8 x i1>, ptr %.spill5, align 1
  %902 = and <8 x i1> %convergence.cascade.result108, %.spill.load109
  %903 = xor <8 x i1> %.spill.load109, splat (i1 true)
  %904 = and <8 x i1> %convergence.cascade.result108, %903
  %905 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %902)
  %906 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %904)
  %907 = and i1 %905, %906
  br i1 %907, label %varying.divergent110, label %varying.coherent111

varying.divergent110:                             ; preds = %convergence.target.8.ready
  %908 = load i32, ptr %current.token, align 4
  %909 = icmp ne i32 %908, 0
  %910 = sub i32 %908, 1
  %911 = select i1 %909, i32 %910, i32 0
  %912 = load i8, ptr %frame.active, align 1
  %913 = trunc i32 %911 to i8
  %914 = shl i8 1, %913
  %915 = and i8 %912, %914
  %916 = icmp ne i8 %915, 0
  %917 = load <8 x i32>, ptr %frame.static.id, align 32
  %918 = extractelement <8 x i32> %917, i32 %911
  %919 = icmp eq i32 %918, 2
  %920 = and i1 %916, %919
  %921 = and i1 %909, %920
  %922 = xor i1 %921, true
  %923 = and i1 true, %922
  %924 = xor i8 %912, -1
  %925 = icmp ne i8 %924, 0
  %926 = xor i1 %925, true
  %927 = and i1 %923, %926
  br i1 %927, label %convergence.overflow.trap112, label %convergence.overflow.resume113

varying.coherent111:                              ; preds = %convergence.target.8.ready
  br i1 %905, label %varying.coherent.true119, label %varying.coherent.false120

convergence.overflow.trap112:                     ; preds = %varying.divergent110
  call void @llvm.trap()
  unreachable

convergence.overflow.resume113:                   ; preds = %varying.divergent110
  %928 = call i8 @llvm.cttz.i8(i8 %924, i1 false)
  %929 = zext i8 %928 to i32
  %930 = select i1 %925, i32 %929, i32 0
  %931 = trunc i32 %930 to i8
  %932 = shl i8 1, %931
  %933 = or i8 %912, %932
  %934 = select i1 %923, i8 %933, i8 %912
  store i8 %934, ptr %frame.active, align 1
  %935 = load <8 x i32>, ptr %frame.static.id, align 32
  %936 = extractelement <8 x i32> %935, i32 %930
  %937 = select i1 %923, i32 2, i32 %936
  %938 = load <8 x i32>, ptr %frame.static.id, align 32
  %939 = insertelement <8 x i32> %938, i32 %937, i32 %930
  store <8 x i32> %939, ptr %frame.static.id, align 32
  %940 = load <8 x i32>, ptr %frame.parent.token, align 32
  %941 = extractelement <8 x i32> %940, i32 %930
  %942 = select i1 %923, i32 %908, i32 %941
  %943 = load <8 x i32>, ptr %frame.parent.token, align 32
  %944 = insertelement <8 x i32> %943, i32 %942, i32 %930
  store <8 x i32> %944, ptr %frame.parent.token, align 32
  %945 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %930
  %946 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %930
  %947 = load <8 x i1>, ptr %945, align 1
  %948 = load <8 x i1>, ptr %946, align 1
  %949 = select i1 %923, <8 x i1> %convergence.cascade.result108, <8 x i1> %947
  store <8 x i1> %949, ptr %945, align 1
  %950 = select i1 %923, <8 x i1> zeroinitializer, <8 x i1> %948
  store <8 x i1> %950, ptr %946, align 1
  %951 = add i32 %930, 1
  %952 = select i1 %921, i32 %908, i32 %951
  %953 = select i1 true, i32 %952, i32 %908
  store i32 %953, ptr %current.token, align 4
  %.state114 = load <8 x float>, ptr %.slot9, align 32
  %954 = load <8 x float>, ptr %.slot13, align 32
  %955 = select <8 x i1> %904, <8 x float> %.state114, <8 x float> %954
  store <8 x float> %955, ptr %.slot13, align 32
  %956 = load i32, ptr %current.token, align 4
  %957 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %902)
  %958 = load i32, ptr %ready.count, align 4
  %959 = icmp uge i32 %958, 8
  %960 = and i1 %957, %959
  br i1 %960, label %ready.overflow.trap115, label %ready.overflow.resume116

ready.overflow.trap115:                           ; preds = %convergence.overflow.resume113
  call void @llvm.trap()
  unreachable

ready.overflow.resume116:                         ; preds = %convergence.overflow.resume113
  %961 = select i1 %957, i32 %958, i32 0
  %962 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %961
  %963 = load <8 x i1>, ptr %962, align 1
  %964 = select i1 %957, <8 x i1> %902, <8 x i1> %963
  store <8 x i1> %964, ptr %962, align 1
  %965 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %961
  %966 = load i32, ptr %965, align 4
  %967 = select i1 %957, i32 9, i32 %966
  store i32 %967, ptr %965, align 4
  %968 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %961
  %969 = load i32, ptr %968, align 4
  %970 = select i1 %957, i32 %956, i32 %969
  store i32 %970, ptr %968, align 4
  %971 = add i32 %958, 1
  %972 = select i1 %957, i32 %971, i32 %958
  store i32 %972, ptr %ready.count, align 4
  %973 = load <8 x i1>, ptr %runnable.mask, align 1
  %974 = or <8 x i1> %973, %902
  store <8 x i1> %974, ptr %runnable.mask, align 1
  %975 = load i32, ptr %current.token, align 4
  %976 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %904)
  %977 = load i32, ptr %ready.count, align 4
  %978 = icmp uge i32 %977, 8
  %979 = and i1 %976, %978
  br i1 %979, label %ready.overflow.trap117, label %ready.overflow.resume118

ready.overflow.trap117:                           ; preds = %ready.overflow.resume116
  call void @llvm.trap()
  unreachable

ready.overflow.resume118:                         ; preds = %ready.overflow.resume116
  %980 = select i1 %976, i32 %977, i32 0
  %981 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %980
  %982 = load <8 x i1>, ptr %981, align 1
  %983 = select i1 %976, <8 x i1> %904, <8 x i1> %982
  store <8 x i1> %983, ptr %981, align 1
  %984 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %980
  %985 = load i32, ptr %984, align 4
  %986 = select i1 %976, i32 10, i32 %985
  store i32 %986, ptr %984, align 4
  %987 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %980
  %988 = load i32, ptr %987, align 4
  %989 = select i1 %976, i32 %975, i32 %988
  store i32 %989, ptr %987, align 4
  %990 = add i32 %977, 1
  %991 = select i1 %976, i32 %990, i32 %977
  store i32 %991, ptr %ready.count, align 4
  %992 = load <8 x i1>, ptr %runnable.mask, align 1
  %993 = or <8 x i1> %992, %904
  store <8 x i1> %993, ptr %runnable.mask, align 1
  br label %scheduler.loop

varying.coherent.true119:                         ; preds = %varying.coherent111
  store <8 x i1> %convergence.cascade.result108, ptr %current.mask, align 1
  %994 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result108)
  br i1 %994, label %schedule.9, label %scheduler.loop

varying.coherent.false120:                        ; preds = %varying.coherent111
  %.state121 = load <8 x float>, ptr %.slot9, align 32
  %995 = load <8 x float>, ptr %.slot13, align 32
  %996 = select <8 x i1> %convergence.cascade.result108, <8 x float> %.state121, <8 x float> %995
  store <8 x float> %996, ptr %.slot13, align 32
  store <8 x i1> %convergence.cascade.result108, ptr %current.mask, align 1
  %997 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result108)
  br i1 %997, label %schedule.10, label %scheduler.loop

convergence.cascade126:                           ; preds = %convergence.cascade126, %schedule.10
  %convergence.cascade.flow130 = phi <8 x i1> [ %344, %schedule.10 ], [ %1040, %convergence.cascade126 ]
  %convergence.cascade.depth131 = phi i32 [ 0, %schedule.10 ], [ %1041, %convergence.cascade126 ]
  %998 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow130)
  %999 = load i32, ptr %current.token, align 4
  %1000 = icmp ne i32 %999, 0
  %1001 = and i1 %998, %1000
  %1002 = sub i32 %999, 1
  %1003 = select i1 %1001, i32 %1002, i32 0
  %1004 = load i8, ptr %frame.active, align 1
  %1005 = trunc i32 %1003 to i8
  %1006 = shl i8 1, %1005
  %1007 = and i8 %1004, %1006
  %1008 = icmp ne i8 %1007, 0
  %1009 = load <8 x i32>, ptr %frame.static.id, align 32
  %1010 = extractelement <8 x i32> %1009, i32 %1003
  %convergence.target.pointer132 = getelementptr inbounds [7 x i32], ptr @convergence.targets, i32 0, i32 %1010
  %convergence.dynamic.target133 = load i32, ptr %convergence.target.pointer132, align 4
  %1011 = icmp eq i32 %convergence.dynamic.target133, 10
  %1012 = and i1 %1008, %1011
  %1013 = and i1 %1001, %1012
  %1014 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1003
  %1015 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1003
  %1016 = load <8 x i1>, ptr %1014, align 1
  %1017 = load <8 x i1>, ptr %1015, align 1
  %1018 = or <8 x i1> %1017, %convergence.cascade.flow130
  %1019 = load <8 x i1>, ptr %live.mask, align 1
  %1020 = and <8 x i1> %1016, %1019
  %1021 = icmp eq <8 x i1> %1018, %1020
  %1022 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1021)
  %1023 = and i1 %1013, %1022
  %1024 = select i1 %1023, <8 x i1> zeroinitializer, <8 x i1> %1018
  %1025 = select i1 %1013, <8 x i1> %1024, <8 x i1> %1017
  store <8 x i1> %1025, ptr %1015, align 1
  %1026 = select i1 %1023, <8 x i1> zeroinitializer, <8 x i1> %1016
  store <8 x i1> %1026, ptr %1014, align 1
  %1027 = trunc i32 %1003 to i8
  %1028 = shl i8 1, %1027
  %1029 = xor i8 %1028, -1
  %1030 = and i8 %1004, %1029
  %1031 = select i1 %1023, i8 %1030, i8 %1004
  store i8 %1031, ptr %frame.active, align 1
  %.splatinsert134 = insertelement <8 x i1> poison, i1 %1013, i64 0
  %.splat135 = shufflevector <8 x i1> %.splatinsert134, <8 x i1> poison, <8 x i32> zeroinitializer
  %1032 = and <8 x i1> %convergence.cascade.flow130, %.splat135
  %1033 = load <8 x i1>, ptr %runnable.mask, align 1
  %1034 = xor <8 x i1> %1032, splat (i1 true)
  %1035 = and <8 x i1> %1033, %1034
  store <8 x i1> %1035, ptr %runnable.mask, align 1
  %.splatinsert136 = insertelement <8 x i1> poison, i1 %1023, i64 0
  %.splat137 = shufflevector <8 x i1> %.splatinsert136, <8 x i1> poison, <8 x i32> zeroinitializer
  %1036 = select <8 x i1> %.splat137, <8 x i1> %1018, <8 x i1> zeroinitializer
  %1037 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1038 = extractelement <8 x i32> %1037, i32 %1003
  %1039 = select i1 %1023, i32 %1038, i32 %999
  store i32 %1039, ptr %current.token, align 4
  %.splatinsert138 = insertelement <8 x i1> poison, i1 %1013, i64 0
  %.splat139 = shufflevector <8 x i1> %.splatinsert138, <8 x i1> poison, <8 x i32> zeroinitializer
  %1040 = select <8 x i1> %.splat139, <8 x i1> %1036, <8 x i1> %convergence.cascade.flow130
  %1041 = add i32 %convergence.cascade.depth131, 1
  %1042 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1040)
  %1043 = icmp ult i32 %1041, 8
  %1044 = and i1 %1042, %1043
  %1045 = and i1 %1013, %1044
  %convergence.parent.token140 = load i32, ptr %current.token, align 4
  %convergence.parent.present141 = icmp ne i32 %convergence.parent.token140, 0
  %1046 = and i1 %1045, %convergence.parent.present141
  br i1 %1046, label %convergence.cascade126, label %convergence.cascade.exit127

convergence.cascade.exit127:                      ; preds = %convergence.cascade126, %schedule.10
  %convergence.cascade.result142 = phi <8 x i1> [ %344, %schedule.10 ], [ %1040, %convergence.cascade126 ]
  %1047 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result142)
  br i1 %1047, label %convergence.target.10.ready, label %scheduler.loop

convergence.target.10.ready:                      ; preds = %convergence.cascade.exit127
  %1048 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result142)
  %1049 = bitcast <8 x i1> %convergence.cascade.result142 to i8
  %1050 = call i8 @llvm.cttz.i8(i8 %1049, i1 false)
  %1051 = zext i8 %1050 to i32
  %1052 = select i1 %1048, i32 %1051, i32 0
  %.state143 = load <8 x float>, ptr %.slot13, align 32
  %.state144 = load <8 x float>, ptr %.slot10, align 32
  %1053 = fadd <8 x float> %.state143, %.state144
  %.state145 = load <8 x float>, ptr %.slot11, align 32
  %1054 = fadd <8 x float> %1053, %.state145
  %.state146 = load <8 x float>, ptr %.slot12, align 32
  %1055 = fadd <8 x float> %1054, %.state146
  %.spill.load147 = load <8 x i64>, ptr %.spill, align 64
  %1056 = trunc <8 x i64> %.spill.load147 to <8 x i32>
  %1057 = xor <8 x i32> %1056, splat (i32 1)
  %1058 = extractelement <8 x i32> %1057, i64 0
  %1059 = icmp ult i32 %1058, 8
  %1060 = select i1 %1059, i32 %1058, i32 0
  %1061 = extractelement <8 x i1> %convergence.cascade.result142, i32 %1060
  %1062 = extractelement <8 x i1> %convergence.cascade.result142, i64 0
  %1063 = and i1 %1059, %1061
  %1064 = and i1 %1062, %1063
  %1065 = extractelement <8 x float> %1055, i32 %1060
  %1066 = select i1 %1064, float %1065, float 0.000000e+00
  %1067 = insertelement <8 x float> poison, float %1066, i64 0
  %1068 = xor i1 %1064, true
  %1069 = and i1 %1062, %1068
  %1070 = insertelement <8 x i1> poison, i1 %1069, i64 0
  %1071 = extractelement <8 x i32> %1057, i64 1
  %1072 = icmp ult i32 %1071, 8
  %1073 = select i1 %1072, i32 %1071, i32 0
  %1074 = extractelement <8 x i1> %convergence.cascade.result142, i32 %1073
  %1075 = extractelement <8 x i1> %convergence.cascade.result142, i64 1
  %1076 = and i1 %1072, %1074
  %1077 = and i1 %1075, %1076
  %1078 = extractelement <8 x float> %1055, i32 %1073
  %1079 = select i1 %1077, float %1078, float 0.000000e+00
  %1080 = insertelement <8 x float> %1067, float %1079, i64 1
  %1081 = xor i1 %1077, true
  %1082 = and i1 %1075, %1081
  %1083 = insertelement <8 x i1> %1070, i1 %1082, i64 1
  %1084 = extractelement <8 x i32> %1057, i64 2
  %1085 = icmp ult i32 %1084, 8
  %1086 = select i1 %1085, i32 %1084, i32 0
  %1087 = extractelement <8 x i1> %convergence.cascade.result142, i32 %1086
  %1088 = extractelement <8 x i1> %convergence.cascade.result142, i64 2
  %1089 = and i1 %1085, %1087
  %1090 = and i1 %1088, %1089
  %1091 = extractelement <8 x float> %1055, i32 %1086
  %1092 = select i1 %1090, float %1091, float 0.000000e+00
  %1093 = insertelement <8 x float> %1080, float %1092, i64 2
  %1094 = xor i1 %1090, true
  %1095 = and i1 %1088, %1094
  %1096 = insertelement <8 x i1> %1083, i1 %1095, i64 2
  %1097 = extractelement <8 x i32> %1057, i64 3
  %1098 = icmp ult i32 %1097, 8
  %1099 = select i1 %1098, i32 %1097, i32 0
  %1100 = extractelement <8 x i1> %convergence.cascade.result142, i32 %1099
  %1101 = extractelement <8 x i1> %convergence.cascade.result142, i64 3
  %1102 = and i1 %1098, %1100
  %1103 = and i1 %1101, %1102
  %1104 = extractelement <8 x float> %1055, i32 %1099
  %1105 = select i1 %1103, float %1104, float 0.000000e+00
  %1106 = insertelement <8 x float> %1093, float %1105, i64 3
  %1107 = xor i1 %1103, true
  %1108 = and i1 %1101, %1107
  %1109 = insertelement <8 x i1> %1096, i1 %1108, i64 3
  %1110 = extractelement <8 x i32> %1057, i64 4
  %1111 = icmp ult i32 %1110, 8
  %1112 = select i1 %1111, i32 %1110, i32 0
  %1113 = extractelement <8 x i1> %convergence.cascade.result142, i32 %1112
  %1114 = extractelement <8 x i1> %convergence.cascade.result142, i64 4
  %1115 = and i1 %1111, %1113
  %1116 = and i1 %1114, %1115
  %1117 = extractelement <8 x float> %1055, i32 %1112
  %1118 = select i1 %1116, float %1117, float 0.000000e+00
  %1119 = insertelement <8 x float> %1106, float %1118, i64 4
  %1120 = xor i1 %1116, true
  %1121 = and i1 %1114, %1120
  %1122 = insertelement <8 x i1> %1109, i1 %1121, i64 4
  %1123 = extractelement <8 x i32> %1057, i64 5
  %1124 = icmp ult i32 %1123, 8
  %1125 = select i1 %1124, i32 %1123, i32 0
  %1126 = extractelement <8 x i1> %convergence.cascade.result142, i32 %1125
  %1127 = extractelement <8 x i1> %convergence.cascade.result142, i64 5
  %1128 = and i1 %1124, %1126
  %1129 = and i1 %1127, %1128
  %1130 = extractelement <8 x float> %1055, i32 %1125
  %1131 = select i1 %1129, float %1130, float 0.000000e+00
  %1132 = insertelement <8 x float> %1119, float %1131, i64 5
  %1133 = xor i1 %1129, true
  %1134 = and i1 %1127, %1133
  %1135 = insertelement <8 x i1> %1122, i1 %1134, i64 5
  %1136 = extractelement <8 x i32> %1057, i64 6
  %1137 = icmp ult i32 %1136, 8
  %1138 = select i1 %1137, i32 %1136, i32 0
  %1139 = extractelement <8 x i1> %convergence.cascade.result142, i32 %1138
  %1140 = extractelement <8 x i1> %convergence.cascade.result142, i64 6
  %1141 = and i1 %1137, %1139
  %1142 = and i1 %1140, %1141
  %1143 = extractelement <8 x float> %1055, i32 %1138
  %1144 = select i1 %1142, float %1143, float 0.000000e+00
  %1145 = insertelement <8 x float> %1132, float %1144, i64 6
  %1146 = xor i1 %1142, true
  %1147 = and i1 %1140, %1146
  %1148 = insertelement <8 x i1> %1135, i1 %1147, i64 6
  %1149 = extractelement <8 x i32> %1057, i64 7
  %1150 = icmp ult i32 %1149, 8
  %1151 = select i1 %1150, i32 %1149, i32 0
  %1152 = extractelement <8 x i1> %convergence.cascade.result142, i32 %1151
  %1153 = extractelement <8 x i1> %convergence.cascade.result142, i64 7
  %1154 = and i1 %1150, %1152
  %1155 = and i1 %1153, %1154
  %1156 = extractelement <8 x float> %1055, i32 %1151
  %1157 = select i1 %1155, float %1156, float 0.000000e+00
  %1158 = insertelement <8 x float> %1145, float %1157, i64 7
  %1159 = xor i1 %1155, true
  %1160 = and i1 %1153, %1159
  %1161 = insertelement <8 x i1> %1148, i1 %1160, i64 7
  %1162 = fadd <8 x float> %1055, %1158
  %1163 = xor <8 x i32> %1056, splat (i32 2)
  %1164 = extractelement <8 x i32> %1163, i64 0
  %1165 = icmp ult i32 %1164, 8
  %1166 = select i1 %1165, i32 %1164, i32 0
  %1167 = extractelement <8 x i1> %convergence.cascade.result142, i32 %1166
  %1168 = extractelement <8 x i1> %convergence.cascade.result142, i64 0
  %1169 = and i1 %1165, %1167
  %1170 = and i1 %1168, %1169
  %1171 = extractelement <8 x float> %1162, i32 %1166
  %1172 = select i1 %1170, float %1171, float 0.000000e+00
  %1173 = insertelement <8 x float> poison, float %1172, i64 0
  %1174 = xor i1 %1170, true
  %1175 = and i1 %1168, %1174
  %1176 = insertelement <8 x i1> poison, i1 %1175, i64 0
  %1177 = extractelement <8 x i32> %1163, i64 1
  %1178 = icmp ult i32 %1177, 8
  %1179 = select i1 %1178, i32 %1177, i32 0
  %1180 = extractelement <8 x i1> %convergence.cascade.result142, i32 %1179
  %1181 = extractelement <8 x i1> %convergence.cascade.result142, i64 1
  %1182 = and i1 %1178, %1180
  %1183 = and i1 %1181, %1182
  %1184 = extractelement <8 x float> %1162, i32 %1179
  %1185 = select i1 %1183, float %1184, float 0.000000e+00
  %1186 = insertelement <8 x float> %1173, float %1185, i64 1
  %1187 = xor i1 %1183, true
  %1188 = and i1 %1181, %1187
  %1189 = insertelement <8 x i1> %1176, i1 %1188, i64 1
  %1190 = extractelement <8 x i32> %1163, i64 2
  %1191 = icmp ult i32 %1190, 8
  %1192 = select i1 %1191, i32 %1190, i32 0
  %1193 = extractelement <8 x i1> %convergence.cascade.result142, i32 %1192
  %1194 = extractelement <8 x i1> %convergence.cascade.result142, i64 2
  %1195 = and i1 %1191, %1193
  %1196 = and i1 %1194, %1195
  %1197 = extractelement <8 x float> %1162, i32 %1192
  %1198 = select i1 %1196, float %1197, float 0.000000e+00
  %1199 = insertelement <8 x float> %1186, float %1198, i64 2
  %1200 = xor i1 %1196, true
  %1201 = and i1 %1194, %1200
  %1202 = insertelement <8 x i1> %1189, i1 %1201, i64 2
  %1203 = extractelement <8 x i32> %1163, i64 3
  %1204 = icmp ult i32 %1203, 8
  %1205 = select i1 %1204, i32 %1203, i32 0
  %1206 = extractelement <8 x i1> %convergence.cascade.result142, i32 %1205
  %1207 = extractelement <8 x i1> %convergence.cascade.result142, i64 3
  %1208 = and i1 %1204, %1206
  %1209 = and i1 %1207, %1208
  %1210 = extractelement <8 x float> %1162, i32 %1205
  %1211 = select i1 %1209, float %1210, float 0.000000e+00
  %1212 = insertelement <8 x float> %1199, float %1211, i64 3
  %1213 = xor i1 %1209, true
  %1214 = and i1 %1207, %1213
  %1215 = insertelement <8 x i1> %1202, i1 %1214, i64 3
  %1216 = extractelement <8 x i32> %1163, i64 4
  %1217 = icmp ult i32 %1216, 8
  %1218 = select i1 %1217, i32 %1216, i32 0
  %1219 = extractelement <8 x i1> %convergence.cascade.result142, i32 %1218
  %1220 = extractelement <8 x i1> %convergence.cascade.result142, i64 4
  %1221 = and i1 %1217, %1219
  %1222 = and i1 %1220, %1221
  %1223 = extractelement <8 x float> %1162, i32 %1218
  %1224 = select i1 %1222, float %1223, float 0.000000e+00
  %1225 = insertelement <8 x float> %1212, float %1224, i64 4
  %1226 = xor i1 %1222, true
  %1227 = and i1 %1220, %1226
  %1228 = insertelement <8 x i1> %1215, i1 %1227, i64 4
  %1229 = extractelement <8 x i32> %1163, i64 5
  %1230 = icmp ult i32 %1229, 8
  %1231 = select i1 %1230, i32 %1229, i32 0
  %1232 = extractelement <8 x i1> %convergence.cascade.result142, i32 %1231
  %1233 = extractelement <8 x i1> %convergence.cascade.result142, i64 5
  %1234 = and i1 %1230, %1232
  %1235 = and i1 %1233, %1234
  %1236 = extractelement <8 x float> %1162, i32 %1231
  %1237 = select i1 %1235, float %1236, float 0.000000e+00
  %1238 = insertelement <8 x float> %1225, float %1237, i64 5
  %1239 = xor i1 %1235, true
  %1240 = and i1 %1233, %1239
  %1241 = insertelement <8 x i1> %1228, i1 %1240, i64 5
  %1242 = extractelement <8 x i32> %1163, i64 6
  %1243 = icmp ult i32 %1242, 8
  %1244 = select i1 %1243, i32 %1242, i32 0
  %1245 = extractelement <8 x i1> %convergence.cascade.result142, i32 %1244
  %1246 = extractelement <8 x i1> %convergence.cascade.result142, i64 6
  %1247 = and i1 %1243, %1245
  %1248 = and i1 %1246, %1247
  %1249 = extractelement <8 x float> %1162, i32 %1244
  %1250 = select i1 %1248, float %1249, float 0.000000e+00
  %1251 = insertelement <8 x float> %1238, float %1250, i64 6
  %1252 = xor i1 %1248, true
  %1253 = and i1 %1246, %1252
  %1254 = insertelement <8 x i1> %1241, i1 %1253, i64 6
  %1255 = extractelement <8 x i32> %1163, i64 7
  %1256 = icmp ult i32 %1255, 8
  %1257 = select i1 %1256, i32 %1255, i32 0
  %1258 = extractelement <8 x i1> %convergence.cascade.result142, i32 %1257
  %1259 = extractelement <8 x i1> %convergence.cascade.result142, i64 7
  %1260 = and i1 %1256, %1258
  %1261 = and i1 %1259, %1260
  %1262 = extractelement <8 x float> %1162, i32 %1257
  %1263 = select i1 %1261, float %1262, float 0.000000e+00
  %1264 = insertelement <8 x float> %1251, float %1263, i64 7
  %1265 = xor i1 %1261, true
  %1266 = and i1 %1259, %1265
  %1267 = insertelement <8 x i1> %1254, i1 %1266, i64 7
  %1268 = fadd <8 x float> %1162, %1264
  %1269 = xor <8 x i32> %1056, splat (i32 4)
  %1270 = extractelement <8 x i32> %1269, i64 0
  %1271 = icmp ult i32 %1270, 8
  %1272 = select i1 %1271, i32 %1270, i32 0
  %1273 = extractelement <8 x i1> %convergence.cascade.result142, i32 %1272
  %1274 = extractelement <8 x i1> %convergence.cascade.result142, i64 0
  %1275 = and i1 %1271, %1273
  %1276 = and i1 %1274, %1275
  %1277 = extractelement <8 x float> %1268, i32 %1272
  %1278 = select i1 %1276, float %1277, float 0.000000e+00
  %1279 = insertelement <8 x float> poison, float %1278, i64 0
  %1280 = xor i1 %1276, true
  %1281 = and i1 %1274, %1280
  %1282 = insertelement <8 x i1> poison, i1 %1281, i64 0
  %1283 = extractelement <8 x i32> %1269, i64 1
  %1284 = icmp ult i32 %1283, 8
  %1285 = select i1 %1284, i32 %1283, i32 0
  %1286 = extractelement <8 x i1> %convergence.cascade.result142, i32 %1285
  %1287 = extractelement <8 x i1> %convergence.cascade.result142, i64 1
  %1288 = and i1 %1284, %1286
  %1289 = and i1 %1287, %1288
  %1290 = extractelement <8 x float> %1268, i32 %1285
  %1291 = select i1 %1289, float %1290, float 0.000000e+00
  %1292 = insertelement <8 x float> %1279, float %1291, i64 1
  %1293 = xor i1 %1289, true
  %1294 = and i1 %1287, %1293
  %1295 = insertelement <8 x i1> %1282, i1 %1294, i64 1
  %1296 = extractelement <8 x i32> %1269, i64 2
  %1297 = icmp ult i32 %1296, 8
  %1298 = select i1 %1297, i32 %1296, i32 0
  %1299 = extractelement <8 x i1> %convergence.cascade.result142, i32 %1298
  %1300 = extractelement <8 x i1> %convergence.cascade.result142, i64 2
  %1301 = and i1 %1297, %1299
  %1302 = and i1 %1300, %1301
  %1303 = extractelement <8 x float> %1268, i32 %1298
  %1304 = select i1 %1302, float %1303, float 0.000000e+00
  %1305 = insertelement <8 x float> %1292, float %1304, i64 2
  %1306 = xor i1 %1302, true
  %1307 = and i1 %1300, %1306
  %1308 = insertelement <8 x i1> %1295, i1 %1307, i64 2
  %1309 = extractelement <8 x i32> %1269, i64 3
  %1310 = icmp ult i32 %1309, 8
  %1311 = select i1 %1310, i32 %1309, i32 0
  %1312 = extractelement <8 x i1> %convergence.cascade.result142, i32 %1311
  %1313 = extractelement <8 x i1> %convergence.cascade.result142, i64 3
  %1314 = and i1 %1310, %1312
  %1315 = and i1 %1313, %1314
  %1316 = extractelement <8 x float> %1268, i32 %1311
  %1317 = select i1 %1315, float %1316, float 0.000000e+00
  %1318 = insertelement <8 x float> %1305, float %1317, i64 3
  %1319 = xor i1 %1315, true
  %1320 = and i1 %1313, %1319
  %1321 = insertelement <8 x i1> %1308, i1 %1320, i64 3
  %1322 = extractelement <8 x i32> %1269, i64 4
  %1323 = icmp ult i32 %1322, 8
  %1324 = select i1 %1323, i32 %1322, i32 0
  %1325 = extractelement <8 x i1> %convergence.cascade.result142, i32 %1324
  %1326 = extractelement <8 x i1> %convergence.cascade.result142, i64 4
  %1327 = and i1 %1323, %1325
  %1328 = and i1 %1326, %1327
  %1329 = extractelement <8 x float> %1268, i32 %1324
  %1330 = select i1 %1328, float %1329, float 0.000000e+00
  %1331 = insertelement <8 x float> %1318, float %1330, i64 4
  %1332 = xor i1 %1328, true
  %1333 = and i1 %1326, %1332
  %1334 = insertelement <8 x i1> %1321, i1 %1333, i64 4
  %1335 = extractelement <8 x i32> %1269, i64 5
  %1336 = icmp ult i32 %1335, 8
  %1337 = select i1 %1336, i32 %1335, i32 0
  %1338 = extractelement <8 x i1> %convergence.cascade.result142, i32 %1337
  %1339 = extractelement <8 x i1> %convergence.cascade.result142, i64 5
  %1340 = and i1 %1336, %1338
  %1341 = and i1 %1339, %1340
  %1342 = extractelement <8 x float> %1268, i32 %1337
  %1343 = select i1 %1341, float %1342, float 0.000000e+00
  %1344 = insertelement <8 x float> %1331, float %1343, i64 5
  %1345 = xor i1 %1341, true
  %1346 = and i1 %1339, %1345
  %1347 = insertelement <8 x i1> %1334, i1 %1346, i64 5
  %1348 = extractelement <8 x i32> %1269, i64 6
  %1349 = icmp ult i32 %1348, 8
  %1350 = select i1 %1349, i32 %1348, i32 0
  %1351 = extractelement <8 x i1> %convergence.cascade.result142, i32 %1350
  %1352 = extractelement <8 x i1> %convergence.cascade.result142, i64 6
  %1353 = and i1 %1349, %1351
  %1354 = and i1 %1352, %1353
  %1355 = extractelement <8 x float> %1268, i32 %1350
  %1356 = select i1 %1354, float %1355, float 0.000000e+00
  %1357 = insertelement <8 x float> %1344, float %1356, i64 6
  %1358 = xor i1 %1354, true
  %1359 = and i1 %1352, %1358
  %1360 = insertelement <8 x i1> %1347, i1 %1359, i64 6
  %1361 = extractelement <8 x i32> %1269, i64 7
  %1362 = icmp ult i32 %1361, 8
  %1363 = select i1 %1362, i32 %1361, i32 0
  %1364 = extractelement <8 x i1> %convergence.cascade.result142, i32 %1363
  %1365 = extractelement <8 x i1> %convergence.cascade.result142, i64 7
  %1366 = and i1 %1362, %1364
  %1367 = and i1 %1365, %1366
  %1368 = extractelement <8 x float> %1268, i32 %1363
  %1369 = select i1 %1367, float %1368, float 0.000000e+00
  %1370 = insertelement <8 x float> %1357, float %1369, i64 7
  %1371 = xor i1 %1367, true
  %1372 = and i1 %1365, %1371
  %1373 = insertelement <8 x i1> %1360, i1 %1372, i64 7
  %1374 = fadd <8 x float> %1268, %1370
  %1375 = extractelement <8 x i1> %convergence.cascade.result142, i32 0
  %1376 = extractelement <8 x i1> %convergence.cascade.result142, i64 0
  %1377 = and i1 true, %1375
  %1378 = and i1 %1376, %1377
  %1379 = extractelement <8 x float> %1374, i32 0
  %1380 = select i1 %1378, float %1379, float 0.000000e+00
  %1381 = insertelement <8 x float> poison, float %1380, i64 0
  %1382 = xor i1 %1378, true
  %1383 = and i1 %1376, %1382
  %1384 = insertelement <8 x i1> poison, i1 %1383, i64 0
  %1385 = extractelement <8 x i1> %convergence.cascade.result142, i32 0
  %1386 = extractelement <8 x i1> %convergence.cascade.result142, i64 1
  %1387 = and i1 true, %1385
  %1388 = and i1 %1386, %1387
  %1389 = extractelement <8 x float> %1374, i32 0
  %1390 = select i1 %1388, float %1389, float 0.000000e+00
  %1391 = insertelement <8 x float> %1381, float %1390, i64 1
  %1392 = xor i1 %1388, true
  %1393 = and i1 %1386, %1392
  %1394 = insertelement <8 x i1> %1384, i1 %1393, i64 1
  %1395 = extractelement <8 x i1> %convergence.cascade.result142, i32 0
  %1396 = extractelement <8 x i1> %convergence.cascade.result142, i64 2
  %1397 = and i1 true, %1395
  %1398 = and i1 %1396, %1397
  %1399 = extractelement <8 x float> %1374, i32 0
  %1400 = select i1 %1398, float %1399, float 0.000000e+00
  %1401 = insertelement <8 x float> %1391, float %1400, i64 2
  %1402 = xor i1 %1398, true
  %1403 = and i1 %1396, %1402
  %1404 = insertelement <8 x i1> %1394, i1 %1403, i64 2
  %1405 = extractelement <8 x i1> %convergence.cascade.result142, i32 0
  %1406 = extractelement <8 x i1> %convergence.cascade.result142, i64 3
  %1407 = and i1 true, %1405
  %1408 = and i1 %1406, %1407
  %1409 = extractelement <8 x float> %1374, i32 0
  %1410 = select i1 %1408, float %1409, float 0.000000e+00
  %1411 = insertelement <8 x float> %1401, float %1410, i64 3
  %1412 = xor i1 %1408, true
  %1413 = and i1 %1406, %1412
  %1414 = insertelement <8 x i1> %1404, i1 %1413, i64 3
  %1415 = extractelement <8 x i1> %convergence.cascade.result142, i32 0
  %1416 = extractelement <8 x i1> %convergence.cascade.result142, i64 4
  %1417 = and i1 true, %1415
  %1418 = and i1 %1416, %1417
  %1419 = extractelement <8 x float> %1374, i32 0
  %1420 = select i1 %1418, float %1419, float 0.000000e+00
  %1421 = insertelement <8 x float> %1411, float %1420, i64 4
  %1422 = xor i1 %1418, true
  %1423 = and i1 %1416, %1422
  %1424 = insertelement <8 x i1> %1414, i1 %1423, i64 4
  %1425 = extractelement <8 x i1> %convergence.cascade.result142, i32 0
  %1426 = extractelement <8 x i1> %convergence.cascade.result142, i64 5
  %1427 = and i1 true, %1425
  %1428 = and i1 %1426, %1427
  %1429 = extractelement <8 x float> %1374, i32 0
  %1430 = select i1 %1428, float %1429, float 0.000000e+00
  %1431 = insertelement <8 x float> %1421, float %1430, i64 5
  %1432 = xor i1 %1428, true
  %1433 = and i1 %1426, %1432
  %1434 = insertelement <8 x i1> %1424, i1 %1433, i64 5
  %1435 = extractelement <8 x i1> %convergence.cascade.result142, i32 0
  %1436 = extractelement <8 x i1> %convergence.cascade.result142, i64 6
  %1437 = and i1 true, %1435
  %1438 = and i1 %1436, %1437
  %1439 = extractelement <8 x float> %1374, i32 0
  %1440 = select i1 %1438, float %1439, float 0.000000e+00
  %1441 = insertelement <8 x float> %1431, float %1440, i64 6
  %1442 = xor i1 %1438, true
  %1443 = and i1 %1436, %1442
  %1444 = insertelement <8 x i1> %1434, i1 %1443, i64 6
  %1445 = extractelement <8 x i1> %convergence.cascade.result142, i32 0
  %1446 = extractelement <8 x i1> %convergence.cascade.result142, i64 7
  %1447 = and i1 true, %1445
  %1448 = and i1 %1446, %1447
  %1449 = extractelement <8 x float> %1374, i32 0
  %1450 = select i1 %1448, float %1449, float 0.000000e+00
  %1451 = insertelement <8 x float> %1441, float %1450, i64 7
  %1452 = xor i1 %1448, true
  %1453 = and i1 %1446, %1452
  %1454 = insertelement <8 x i1> %1444, i1 %1453, i64 7
  %1455 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result142)
  %1456 = bitcast <8 x i1> %convergence.cascade.result142 to i8
  %1457 = call i8 @llvm.cttz.i8(i8 %1456, i1 false)
  %1458 = zext i8 %1457 to i32
  %1459 = select i1 %1455, i32 %1458, i32 0
  %1460 = extractelement <8 x float> %1451, i32 %1459
  %.spill.load148 = load float, ptr %.spill6, align 4
  %1461 = fadd float %.spill.load148, %1460
  %1462 = fdiv float %1461, 6.600000e+01
  %.splatinsert149 = insertelement <8 x float> poison, float %1462, i64 0
  %.splat150 = shufflevector <8 x float> %.splatinsert149, <8 x float> poison, <8 x i32> zeroinitializer
  %1463 = load <8 x float>, ptr %.spill14, align 32
  %1464 = select <8 x i1> %convergence.cascade.result142, <8 x float> %.splat150, <8 x float> %1463
  store <8 x float> %1464, ptr %.spill14, align 32
  %1465 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %1466 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1467 = extractvalue { <8 x ptr>, <8 x i64> } %1465, 0
  %1468 = select <8 x i1> %convergence.cascade.result142, <8 x ptr> %1466, <8 x ptr> %1467
  %1469 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %1470 = extractvalue { <8 x ptr>, <8 x i64> } %1465, 1
  %1471 = select <8 x i1> %convergence.cascade.result142, <8 x i64> %1469, <8 x i64> %1470
  %1472 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1468, 0
  %1473 = insertvalue { <8 x ptr>, <8 x i64> } %1472, <8 x i64> %1471, 1
  store { <8 x ptr>, <8 x i64> } %1473, ptr %tile_snapshot.spill15, align 64
  %1474 = load <8 x i64>, ptr %.slot16, align 64
  %1475 = select <8 x i1> %convergence.cascade.result142, <8 x i64> zeroinitializer, <8 x i64> %1474
  store <8 x i64> %1475, ptr %.slot16, align 64
  store <8 x i1> %convergence.cascade.result142, ptr %current.mask, align 1
  %1476 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result142)
  br i1 %1476, label %schedule.11, label %scheduler.loop

varying.divergent152:                             ; preds = %schedule.11
  %1477 = load i32, ptr %current.token, align 4
  %1478 = icmp ne i32 %1477, 0
  %1479 = sub i32 %1477, 1
  %1480 = select i1 %1478, i32 %1479, i32 0
  %1481 = load i8, ptr %frame.active, align 1
  %1482 = trunc i32 %1480 to i8
  %1483 = shl i8 1, %1482
  %1484 = and i8 %1481, %1483
  %1485 = icmp ne i8 %1484, 0
  %1486 = load <8 x i32>, ptr %frame.static.id, align 32
  %1487 = extractelement <8 x i32> %1486, i32 %1480
  %1488 = icmp eq i32 %1487, 3
  %1489 = and i1 %1485, %1488
  %1490 = and i1 %1478, %1489
  %1491 = xor i1 %1490, true
  %1492 = and i1 true, %1491
  %1493 = xor i8 %1481, -1
  %1494 = icmp ne i8 %1493, 0
  %1495 = xor i1 %1494, true
  %1496 = and i1 %1492, %1495
  br i1 %1496, label %convergence.overflow.trap154, label %convergence.overflow.resume155

varying.coherent153:                              ; preds = %schedule.11
  br i1 %355, label %varying.coherent.true160, label %varying.coherent.false161

convergence.overflow.trap154:                     ; preds = %varying.divergent152
  call void @llvm.trap()
  unreachable

convergence.overflow.resume155:                   ; preds = %varying.divergent152
  %1497 = call i8 @llvm.cttz.i8(i8 %1493, i1 false)
  %1498 = zext i8 %1497 to i32
  %1499 = select i1 %1494, i32 %1498, i32 0
  %1500 = trunc i32 %1499 to i8
  %1501 = shl i8 1, %1500
  %1502 = or i8 %1481, %1501
  %1503 = select i1 %1492, i8 %1502, i8 %1481
  store i8 %1503, ptr %frame.active, align 1
  %1504 = load <8 x i32>, ptr %frame.static.id, align 32
  %1505 = extractelement <8 x i32> %1504, i32 %1499
  %1506 = select i1 %1492, i32 3, i32 %1505
  %1507 = load <8 x i32>, ptr %frame.static.id, align 32
  %1508 = insertelement <8 x i32> %1507, i32 %1506, i32 %1499
  store <8 x i32> %1508, ptr %frame.static.id, align 32
  %1509 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1510 = extractelement <8 x i32> %1509, i32 %1499
  %1511 = select i1 %1492, i32 %1477, i32 %1510
  %1512 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1513 = insertelement <8 x i32> %1512, i32 %1511, i32 %1499
  store <8 x i32> %1513, ptr %frame.parent.token, align 32
  %1514 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1499
  %1515 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1499
  %1516 = load <8 x i1>, ptr %1514, align 1
  %1517 = load <8 x i1>, ptr %1515, align 1
  %1518 = select i1 %1492, <8 x i1> %345, <8 x i1> %1516
  store <8 x i1> %1518, ptr %1514, align 1
  %1519 = select i1 %1492, <8 x i1> zeroinitializer, <8 x i1> %1517
  store <8 x i1> %1519, ptr %1515, align 1
  %1520 = add i32 %1499, 1
  %1521 = select i1 %1490, i32 %1477, i32 %1520
  %1522 = select i1 true, i32 %1521, i32 %1477
  store i32 %1522, ptr %current.token, align 4
  %1523 = load i32, ptr %current.token, align 4
  %1524 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %352)
  %1525 = load i32, ptr %ready.count, align 4
  %1526 = icmp uge i32 %1525, 8
  %1527 = and i1 %1524, %1526
  br i1 %1527, label %ready.overflow.trap156, label %ready.overflow.resume157

ready.overflow.trap156:                           ; preds = %convergence.overflow.resume155
  call void @llvm.trap()
  unreachable

ready.overflow.resume157:                         ; preds = %convergence.overflow.resume155
  %1528 = select i1 %1524, i32 %1525, i32 0
  %1529 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1528
  %1530 = load <8 x i1>, ptr %1529, align 1
  %1531 = select i1 %1524, <8 x i1> %352, <8 x i1> %1530
  store <8 x i1> %1531, ptr %1529, align 1
  %1532 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1528
  %1533 = load i32, ptr %1532, align 4
  %1534 = select i1 %1524, i32 12, i32 %1533
  store i32 %1534, ptr %1532, align 4
  %1535 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1528
  %1536 = load i32, ptr %1535, align 4
  %1537 = select i1 %1524, i32 %1523, i32 %1536
  store i32 %1537, ptr %1535, align 4
  %1538 = add i32 %1525, 1
  %1539 = select i1 %1524, i32 %1538, i32 %1525
  store i32 %1539, ptr %ready.count, align 4
  %1540 = load <8 x i1>, ptr %runnable.mask, align 1
  %1541 = or <8 x i1> %1540, %352
  store <8 x i1> %1541, ptr %runnable.mask, align 1
  %1542 = load i32, ptr %current.token, align 4
  %1543 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %354)
  %1544 = load i32, ptr %ready.count, align 4
  %1545 = icmp uge i32 %1544, 8
  %1546 = and i1 %1543, %1545
  br i1 %1546, label %ready.overflow.trap158, label %ready.overflow.resume159

ready.overflow.trap158:                           ; preds = %ready.overflow.resume157
  call void @llvm.trap()
  unreachable

ready.overflow.resume159:                         ; preds = %ready.overflow.resume157
  %1547 = select i1 %1543, i32 %1544, i32 0
  %1548 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1547
  %1549 = load <8 x i1>, ptr %1548, align 1
  %1550 = select i1 %1543, <8 x i1> %354, <8 x i1> %1549
  store <8 x i1> %1550, ptr %1548, align 1
  %1551 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1547
  %1552 = load i32, ptr %1551, align 4
  %1553 = select i1 %1543, i32 13, i32 %1552
  store i32 %1553, ptr %1551, align 4
  %1554 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1547
  %1555 = load i32, ptr %1554, align 4
  %1556 = select i1 %1543, i32 %1542, i32 %1555
  store i32 %1556, ptr %1554, align 4
  %1557 = add i32 %1544, 1
  %1558 = select i1 %1543, i32 %1557, i32 %1544
  store i32 %1558, ptr %ready.count, align 4
  %1559 = load <8 x i1>, ptr %runnable.mask, align 1
  %1560 = or <8 x i1> %1559, %354
  store <8 x i1> %1560, ptr %runnable.mask, align 1
  br label %scheduler.loop

varying.coherent.true160:                         ; preds = %varying.coherent153
  store <8 x i1> %345, ptr %current.mask, align 1
  %1561 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %345)
  br i1 %1561, label %schedule.12, label %scheduler.loop

varying.coherent.false161:                        ; preds = %varying.coherent153
  store <8 x i1> %345, ptr %current.mask, align 1
  %1562 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %345)
  br i1 %1562, label %schedule.13, label %scheduler.loop

convergence.cascade172:                           ; preds = %convergence.cascade172, %schedule.13
  %convergence.cascade.flow176 = phi <8 x i1> [ %388, %schedule.13 ], [ %1605, %convergence.cascade172 ]
  %convergence.cascade.depth177 = phi i32 [ 0, %schedule.13 ], [ %1606, %convergence.cascade172 ]
  %1563 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow176)
  %1564 = load i32, ptr %current.token, align 4
  %1565 = icmp ne i32 %1564, 0
  %1566 = and i1 %1563, %1565
  %1567 = sub i32 %1564, 1
  %1568 = select i1 %1566, i32 %1567, i32 0
  %1569 = load i8, ptr %frame.active, align 1
  %1570 = trunc i32 %1568 to i8
  %1571 = shl i8 1, %1570
  %1572 = and i8 %1569, %1571
  %1573 = icmp ne i8 %1572, 0
  %1574 = load <8 x i32>, ptr %frame.static.id, align 32
  %1575 = extractelement <8 x i32> %1574, i32 %1568
  %convergence.target.pointer178 = getelementptr inbounds [7 x i32], ptr @convergence.targets, i32 0, i32 %1575
  %convergence.dynamic.target179 = load i32, ptr %convergence.target.pointer178, align 4
  %1576 = icmp eq i32 %convergence.dynamic.target179, 13
  %1577 = and i1 %1573, %1576
  %1578 = and i1 %1566, %1577
  %1579 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1568
  %1580 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1568
  %1581 = load <8 x i1>, ptr %1579, align 1
  %1582 = load <8 x i1>, ptr %1580, align 1
  %1583 = or <8 x i1> %1582, %convergence.cascade.flow176
  %1584 = load <8 x i1>, ptr %live.mask, align 1
  %1585 = and <8 x i1> %1581, %1584
  %1586 = icmp eq <8 x i1> %1583, %1585
  %1587 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1586)
  %1588 = and i1 %1578, %1587
  %1589 = select i1 %1588, <8 x i1> zeroinitializer, <8 x i1> %1583
  %1590 = select i1 %1578, <8 x i1> %1589, <8 x i1> %1582
  store <8 x i1> %1590, ptr %1580, align 1
  %1591 = select i1 %1588, <8 x i1> zeroinitializer, <8 x i1> %1581
  store <8 x i1> %1591, ptr %1579, align 1
  %1592 = trunc i32 %1568 to i8
  %1593 = shl i8 1, %1592
  %1594 = xor i8 %1593, -1
  %1595 = and i8 %1569, %1594
  %1596 = select i1 %1588, i8 %1595, i8 %1569
  store i8 %1596, ptr %frame.active, align 1
  %.splatinsert180 = insertelement <8 x i1> poison, i1 %1578, i64 0
  %.splat181 = shufflevector <8 x i1> %.splatinsert180, <8 x i1> poison, <8 x i32> zeroinitializer
  %1597 = and <8 x i1> %convergence.cascade.flow176, %.splat181
  %1598 = load <8 x i1>, ptr %runnable.mask, align 1
  %1599 = xor <8 x i1> %1597, splat (i1 true)
  %1600 = and <8 x i1> %1598, %1599
  store <8 x i1> %1600, ptr %runnable.mask, align 1
  %.splatinsert182 = insertelement <8 x i1> poison, i1 %1588, i64 0
  %.splat183 = shufflevector <8 x i1> %.splatinsert182, <8 x i1> poison, <8 x i32> zeroinitializer
  %1601 = select <8 x i1> %.splat183, <8 x i1> %1583, <8 x i1> zeroinitializer
  %1602 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1603 = extractelement <8 x i32> %1602, i32 %1568
  %1604 = select i1 %1588, i32 %1603, i32 %1564
  store i32 %1604, ptr %current.token, align 4
  %.splatinsert184 = insertelement <8 x i1> poison, i1 %1578, i64 0
  %.splat185 = shufflevector <8 x i1> %.splatinsert184, <8 x i1> poison, <8 x i32> zeroinitializer
  %1605 = select <8 x i1> %.splat185, <8 x i1> %1601, <8 x i1> %convergence.cascade.flow176
  %1606 = add i32 %convergence.cascade.depth177, 1
  %1607 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1605)
  %1608 = icmp ult i32 %1606, 8
  %1609 = and i1 %1607, %1608
  %1610 = and i1 %1578, %1609
  %convergence.parent.token186 = load i32, ptr %current.token, align 4
  %convergence.parent.present187 = icmp ne i32 %convergence.parent.token186, 0
  %1611 = and i1 %1610, %convergence.parent.present187
  br i1 %1611, label %convergence.cascade172, label %convergence.cascade.exit173

convergence.cascade.exit173:                      ; preds = %convergence.cascade172, %schedule.13
  %convergence.cascade.result188 = phi <8 x i1> [ %388, %schedule.13 ], [ %1605, %convergence.cascade172 ]
  %1612 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result188)
  br i1 %1612, label %convergence.target.13.ready, label %scheduler.loop

convergence.target.13.ready:                      ; preds = %convergence.cascade.exit173
  %1613 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result188)
  %1614 = bitcast <8 x i1> %convergence.cascade.result188 to i8
  %1615 = call i8 @llvm.cttz.i8(i8 %1614, i1 false)
  %1616 = zext i8 %1615 to i32
  %1617 = select i1 %1613, i32 %1616, i32 0
  %.spill.load189 = load <8 x i1>, ptr %.spill5, align 1
  %1618 = and <8 x i1> %convergence.cascade.result188, %.spill.load189
  %1619 = xor <8 x i1> %.spill.load189, splat (i1 true)
  %1620 = and <8 x i1> %convergence.cascade.result188, %1619
  %1621 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1618)
  %1622 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1620)
  %1623 = and i1 %1621, %1622
  br i1 %1623, label %varying.divergent190, label %varying.coherent191

varying.divergent190:                             ; preds = %convergence.target.13.ready
  %1624 = load i32, ptr %current.token, align 4
  %1625 = icmp ne i32 %1624, 0
  %1626 = sub i32 %1624, 1
  %1627 = select i1 %1625, i32 %1626, i32 0
  %1628 = load i8, ptr %frame.active, align 1
  %1629 = trunc i32 %1627 to i8
  %1630 = shl i8 1, %1629
  %1631 = and i8 %1628, %1630
  %1632 = icmp ne i8 %1631, 0
  %1633 = load <8 x i32>, ptr %frame.static.id, align 32
  %1634 = extractelement <8 x i32> %1633, i32 %1627
  %1635 = icmp eq i32 %1634, 4
  %1636 = and i1 %1632, %1635
  %1637 = and i1 %1625, %1636
  %1638 = xor i1 %1637, true
  %1639 = and i1 true, %1638
  %1640 = xor i8 %1628, -1
  %1641 = icmp ne i8 %1640, 0
  %1642 = xor i1 %1641, true
  %1643 = and i1 %1639, %1642
  br i1 %1643, label %convergence.overflow.trap192, label %convergence.overflow.resume193

varying.coherent191:                              ; preds = %convergence.target.13.ready
  br i1 %1621, label %varying.coherent.true198, label %varying.coherent.false199

convergence.overflow.trap192:                     ; preds = %varying.divergent190
  call void @llvm.trap()
  unreachable

convergence.overflow.resume193:                   ; preds = %varying.divergent190
  %1644 = call i8 @llvm.cttz.i8(i8 %1640, i1 false)
  %1645 = zext i8 %1644 to i32
  %1646 = select i1 %1641, i32 %1645, i32 0
  %1647 = trunc i32 %1646 to i8
  %1648 = shl i8 1, %1647
  %1649 = or i8 %1628, %1648
  %1650 = select i1 %1639, i8 %1649, i8 %1628
  store i8 %1650, ptr %frame.active, align 1
  %1651 = load <8 x i32>, ptr %frame.static.id, align 32
  %1652 = extractelement <8 x i32> %1651, i32 %1646
  %1653 = select i1 %1639, i32 4, i32 %1652
  %1654 = load <8 x i32>, ptr %frame.static.id, align 32
  %1655 = insertelement <8 x i32> %1654, i32 %1653, i32 %1646
  store <8 x i32> %1655, ptr %frame.static.id, align 32
  %1656 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1657 = extractelement <8 x i32> %1656, i32 %1646
  %1658 = select i1 %1639, i32 %1624, i32 %1657
  %1659 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1660 = insertelement <8 x i32> %1659, i32 %1658, i32 %1646
  store <8 x i32> %1660, ptr %frame.parent.token, align 32
  %1661 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1646
  %1662 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1646
  %1663 = load <8 x i1>, ptr %1661, align 1
  %1664 = load <8 x i1>, ptr %1662, align 1
  %1665 = select i1 %1639, <8 x i1> %convergence.cascade.result188, <8 x i1> %1663
  store <8 x i1> %1665, ptr %1661, align 1
  %1666 = select i1 %1639, <8 x i1> zeroinitializer, <8 x i1> %1664
  store <8 x i1> %1666, ptr %1662, align 1
  %1667 = add i32 %1646, 1
  %1668 = select i1 %1637, i32 %1624, i32 %1667
  %1669 = select i1 true, i32 %1668, i32 %1624
  store i32 %1669, ptr %current.token, align 4
  %1670 = load i32, ptr %current.token, align 4
  %1671 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1618)
  %1672 = load i32, ptr %ready.count, align 4
  %1673 = icmp uge i32 %1672, 8
  %1674 = and i1 %1671, %1673
  br i1 %1674, label %ready.overflow.trap194, label %ready.overflow.resume195

ready.overflow.trap194:                           ; preds = %convergence.overflow.resume193
  call void @llvm.trap()
  unreachable

ready.overflow.resume195:                         ; preds = %convergence.overflow.resume193
  %1675 = select i1 %1671, i32 %1672, i32 0
  %1676 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1675
  %1677 = load <8 x i1>, ptr %1676, align 1
  %1678 = select i1 %1671, <8 x i1> %1618, <8 x i1> %1677
  store <8 x i1> %1678, ptr %1676, align 1
  %1679 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1675
  %1680 = load i32, ptr %1679, align 4
  %1681 = select i1 %1671, i32 14, i32 %1680
  store i32 %1681, ptr %1679, align 4
  %1682 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1675
  %1683 = load i32, ptr %1682, align 4
  %1684 = select i1 %1671, i32 %1670, i32 %1683
  store i32 %1684, ptr %1682, align 4
  %1685 = add i32 %1672, 1
  %1686 = select i1 %1671, i32 %1685, i32 %1672
  store i32 %1686, ptr %ready.count, align 4
  %1687 = load <8 x i1>, ptr %runnable.mask, align 1
  %1688 = or <8 x i1> %1687, %1618
  store <8 x i1> %1688, ptr %runnable.mask, align 1
  %1689 = load i32, ptr %current.token, align 4
  %1690 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1620)
  %1691 = load i32, ptr %ready.count, align 4
  %1692 = icmp uge i32 %1691, 8
  %1693 = and i1 %1690, %1692
  br i1 %1693, label %ready.overflow.trap196, label %ready.overflow.resume197

ready.overflow.trap196:                           ; preds = %ready.overflow.resume195
  call void @llvm.trap()
  unreachable

ready.overflow.resume197:                         ; preds = %ready.overflow.resume195
  %1694 = select i1 %1690, i32 %1691, i32 0
  %1695 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1694
  %1696 = load <8 x i1>, ptr %1695, align 1
  %1697 = select i1 %1690, <8 x i1> %1620, <8 x i1> %1696
  store <8 x i1> %1697, ptr %1695, align 1
  %1698 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1694
  %1699 = load i32, ptr %1698, align 4
  %1700 = select i1 %1690, i32 15, i32 %1699
  store i32 %1700, ptr %1698, align 4
  %1701 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1694
  %1702 = load i32, ptr %1701, align 4
  %1703 = select i1 %1690, i32 %1689, i32 %1702
  store i32 %1703, ptr %1701, align 4
  %1704 = add i32 %1691, 1
  %1705 = select i1 %1690, i32 %1704, i32 %1691
  store i32 %1705, ptr %ready.count, align 4
  %1706 = load <8 x i1>, ptr %runnable.mask, align 1
  %1707 = or <8 x i1> %1706, %1620
  store <8 x i1> %1707, ptr %runnable.mask, align 1
  br label %scheduler.loop

varying.coherent.true198:                         ; preds = %varying.coherent191
  store <8 x i1> %convergence.cascade.result188, ptr %current.mask, align 1
  %1708 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result188)
  br i1 %1708, label %schedule.14, label %scheduler.loop

varying.coherent.false199:                        ; preds = %varying.coherent191
  store <8 x i1> %convergence.cascade.result188, ptr %current.mask, align 1
  %1709 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result188)
  br i1 %1709, label %schedule.15, label %scheduler.loop

convergence.cascade209:                           ; preds = %convergence.cascade209, %schedule.15
  %convergence.cascade.flow213 = phi <8 x i1> [ %421, %schedule.15 ], [ %1752, %convergence.cascade209 ]
  %convergence.cascade.depth214 = phi i32 [ 0, %schedule.15 ], [ %1753, %convergence.cascade209 ]
  %1710 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow213)
  %1711 = load i32, ptr %current.token, align 4
  %1712 = icmp ne i32 %1711, 0
  %1713 = and i1 %1710, %1712
  %1714 = sub i32 %1711, 1
  %1715 = select i1 %1713, i32 %1714, i32 0
  %1716 = load i8, ptr %frame.active, align 1
  %1717 = trunc i32 %1715 to i8
  %1718 = shl i8 1, %1717
  %1719 = and i8 %1716, %1718
  %1720 = icmp ne i8 %1719, 0
  %1721 = load <8 x i32>, ptr %frame.static.id, align 32
  %1722 = extractelement <8 x i32> %1721, i32 %1715
  %convergence.target.pointer215 = getelementptr inbounds [7 x i32], ptr @convergence.targets, i32 0, i32 %1722
  %convergence.dynamic.target216 = load i32, ptr %convergence.target.pointer215, align 4
  %1723 = icmp eq i32 %convergence.dynamic.target216, 15
  %1724 = and i1 %1720, %1723
  %1725 = and i1 %1713, %1724
  %1726 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1715
  %1727 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1715
  %1728 = load <8 x i1>, ptr %1726, align 1
  %1729 = load <8 x i1>, ptr %1727, align 1
  %1730 = or <8 x i1> %1729, %convergence.cascade.flow213
  %1731 = load <8 x i1>, ptr %live.mask, align 1
  %1732 = and <8 x i1> %1728, %1731
  %1733 = icmp eq <8 x i1> %1730, %1732
  %1734 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1733)
  %1735 = and i1 %1725, %1734
  %1736 = select i1 %1735, <8 x i1> zeroinitializer, <8 x i1> %1730
  %1737 = select i1 %1725, <8 x i1> %1736, <8 x i1> %1729
  store <8 x i1> %1737, ptr %1727, align 1
  %1738 = select i1 %1735, <8 x i1> zeroinitializer, <8 x i1> %1728
  store <8 x i1> %1738, ptr %1726, align 1
  %1739 = trunc i32 %1715 to i8
  %1740 = shl i8 1, %1739
  %1741 = xor i8 %1740, -1
  %1742 = and i8 %1716, %1741
  %1743 = select i1 %1735, i8 %1742, i8 %1716
  store i8 %1743, ptr %frame.active, align 1
  %.splatinsert217 = insertelement <8 x i1> poison, i1 %1725, i64 0
  %.splat218 = shufflevector <8 x i1> %.splatinsert217, <8 x i1> poison, <8 x i32> zeroinitializer
  %1744 = and <8 x i1> %convergence.cascade.flow213, %.splat218
  %1745 = load <8 x i1>, ptr %runnable.mask, align 1
  %1746 = xor <8 x i1> %1744, splat (i1 true)
  %1747 = and <8 x i1> %1745, %1746
  store <8 x i1> %1747, ptr %runnable.mask, align 1
  %.splatinsert219 = insertelement <8 x i1> poison, i1 %1735, i64 0
  %.splat220 = shufflevector <8 x i1> %.splatinsert219, <8 x i1> poison, <8 x i32> zeroinitializer
  %1748 = select <8 x i1> %.splat220, <8 x i1> %1730, <8 x i1> zeroinitializer
  %1749 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1750 = extractelement <8 x i32> %1749, i32 %1715
  %1751 = select i1 %1735, i32 %1750, i32 %1711
  store i32 %1751, ptr %current.token, align 4
  %.splatinsert221 = insertelement <8 x i1> poison, i1 %1725, i64 0
  %.splat222 = shufflevector <8 x i1> %.splatinsert221, <8 x i1> poison, <8 x i32> zeroinitializer
  %1752 = select <8 x i1> %.splat222, <8 x i1> %1748, <8 x i1> %convergence.cascade.flow213
  %1753 = add i32 %convergence.cascade.depth214, 1
  %1754 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1752)
  %1755 = icmp ult i32 %1753, 8
  %1756 = and i1 %1754, %1755
  %1757 = and i1 %1725, %1756
  %convergence.parent.token223 = load i32, ptr %current.token, align 4
  %convergence.parent.present224 = icmp ne i32 %convergence.parent.token223, 0
  %1758 = and i1 %1757, %convergence.parent.present224
  br i1 %1758, label %convergence.cascade209, label %convergence.cascade.exit210

convergence.cascade.exit210:                      ; preds = %convergence.cascade209, %schedule.15
  %convergence.cascade.result225 = phi <8 x i1> [ %421, %schedule.15 ], [ %1752, %convergence.cascade209 ]
  %1759 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result225)
  br i1 %1759, label %convergence.target.15.ready, label %scheduler.loop

convergence.target.15.ready:                      ; preds = %convergence.cascade.exit210
  %1760 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result225)
  %1761 = bitcast <8 x i1> %convergence.cascade.result225 to i8
  %1762 = call i8 @llvm.cttz.i8(i8 %1761, i1 false)
  %1763 = zext i8 %1762 to i32
  %1764 = select i1 %1760, i32 %1763, i32 0
  %.spill.load226 = load <8 x float>, ptr %.spill14, align 32
  %1765 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result225)
  %1766 = bitcast <8 x i1> %convergence.cascade.result225 to i8
  %1767 = call i8 @llvm.cttz.i8(i8 %1766, i1 false)
  %1768 = zext i8 %1767 to i32
  %1769 = select i1 %1765, i32 %1768, i32 0
  %1770 = extractelement <8 x float> %.spill.load226, i32 %1769
  %1771 = fadd float %1770, 0x3EE4F8B580000000
  %1772 = call float @llvm.sqrt.f32(float %1771)
  %.splatinsert227 = insertelement <8 x float> poison, float %1772, i64 0
  %.splat228 = shufflevector <8 x float> %.splatinsert227, <8 x float> poison, <8 x i32> zeroinitializer
  %1773 = load <8 x float>, ptr %.spill17, align 32
  %1774 = select <8 x i1> %convergence.cascade.result225, <8 x float> %.splat228, <8 x float> %1773
  store <8 x float> %1774, ptr %.spill17, align 32
  %1775 = load <8 x i64>, ptr %.slot18, align 64
  %1776 = select <8 x i1> %convergence.cascade.result225, <8 x i64> zeroinitializer, <8 x i64> %1775
  store <8 x i64> %1776, ptr %.slot18, align 64
  store <8 x i1> %convergence.cascade.result225, ptr %current.mask, align 1
  %1777 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result225)
  br i1 %1777, label %schedule.16, label %scheduler.loop

varying.divergent230:                             ; preds = %schedule.16
  %1778 = load i32, ptr %current.token, align 4
  %1779 = icmp ne i32 %1778, 0
  %1780 = sub i32 %1778, 1
  %1781 = select i1 %1779, i32 %1780, i32 0
  %1782 = load i8, ptr %frame.active, align 1
  %1783 = trunc i32 %1781 to i8
  %1784 = shl i8 1, %1783
  %1785 = and i8 %1782, %1784
  %1786 = icmp ne i8 %1785, 0
  %1787 = load <8 x i32>, ptr %frame.static.id, align 32
  %1788 = extractelement <8 x i32> %1787, i32 %1781
  %1789 = icmp eq i32 %1788, 5
  %1790 = and i1 %1786, %1789
  %1791 = and i1 %1779, %1790
  %1792 = xor i1 %1791, true
  %1793 = and i1 true, %1792
  %1794 = xor i8 %1782, -1
  %1795 = icmp ne i8 %1794, 0
  %1796 = xor i1 %1795, true
  %1797 = and i1 %1793, %1796
  br i1 %1797, label %convergence.overflow.trap232, label %convergence.overflow.resume233

varying.coherent231:                              ; preds = %schedule.16
  br i1 %432, label %varying.coherent.true238, label %varying.coherent.false239

convergence.overflow.trap232:                     ; preds = %varying.divergent230
  call void @llvm.trap()
  unreachable

convergence.overflow.resume233:                   ; preds = %varying.divergent230
  %1798 = call i8 @llvm.cttz.i8(i8 %1794, i1 false)
  %1799 = zext i8 %1798 to i32
  %1800 = select i1 %1795, i32 %1799, i32 0
  %1801 = trunc i32 %1800 to i8
  %1802 = shl i8 1, %1801
  %1803 = or i8 %1782, %1802
  %1804 = select i1 %1793, i8 %1803, i8 %1782
  store i8 %1804, ptr %frame.active, align 1
  %1805 = load <8 x i32>, ptr %frame.static.id, align 32
  %1806 = extractelement <8 x i32> %1805, i32 %1800
  %1807 = select i1 %1793, i32 5, i32 %1806
  %1808 = load <8 x i32>, ptr %frame.static.id, align 32
  %1809 = insertelement <8 x i32> %1808, i32 %1807, i32 %1800
  store <8 x i32> %1809, ptr %frame.static.id, align 32
  %1810 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1811 = extractelement <8 x i32> %1810, i32 %1800
  %1812 = select i1 %1793, i32 %1778, i32 %1811
  %1813 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1814 = insertelement <8 x i32> %1813, i32 %1812, i32 %1800
  store <8 x i32> %1814, ptr %frame.parent.token, align 32
  %1815 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1800
  %1816 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1800
  %1817 = load <8 x i1>, ptr %1815, align 1
  %1818 = load <8 x i1>, ptr %1816, align 1
  %1819 = select i1 %1793, <8 x i1> %422, <8 x i1> %1817
  store <8 x i1> %1819, ptr %1815, align 1
  %1820 = select i1 %1793, <8 x i1> zeroinitializer, <8 x i1> %1818
  store <8 x i1> %1820, ptr %1816, align 1
  %1821 = add i32 %1800, 1
  %1822 = select i1 %1791, i32 %1778, i32 %1821
  %1823 = select i1 true, i32 %1822, i32 %1778
  store i32 %1823, ptr %current.token, align 4
  %1824 = load i32, ptr %current.token, align 4
  %1825 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %429)
  %1826 = load i32, ptr %ready.count, align 4
  %1827 = icmp uge i32 %1826, 8
  %1828 = and i1 %1825, %1827
  br i1 %1828, label %ready.overflow.trap234, label %ready.overflow.resume235

ready.overflow.trap234:                           ; preds = %convergence.overflow.resume233
  call void @llvm.trap()
  unreachable

ready.overflow.resume235:                         ; preds = %convergence.overflow.resume233
  %1829 = select i1 %1825, i32 %1826, i32 0
  %1830 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1829
  %1831 = load <8 x i1>, ptr %1830, align 1
  %1832 = select i1 %1825, <8 x i1> %429, <8 x i1> %1831
  store <8 x i1> %1832, ptr %1830, align 1
  %1833 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1829
  %1834 = load i32, ptr %1833, align 4
  %1835 = select i1 %1825, i32 17, i32 %1834
  store i32 %1835, ptr %1833, align 4
  %1836 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1829
  %1837 = load i32, ptr %1836, align 4
  %1838 = select i1 %1825, i32 %1824, i32 %1837
  store i32 %1838, ptr %1836, align 4
  %1839 = add i32 %1826, 1
  %1840 = select i1 %1825, i32 %1839, i32 %1826
  store i32 %1840, ptr %ready.count, align 4
  %1841 = load <8 x i1>, ptr %runnable.mask, align 1
  %1842 = or <8 x i1> %1841, %429
  store <8 x i1> %1842, ptr %runnable.mask, align 1
  %1843 = load i32, ptr %current.token, align 4
  %1844 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %431)
  %1845 = load i32, ptr %ready.count, align 4
  %1846 = icmp uge i32 %1845, 8
  %1847 = and i1 %1844, %1846
  br i1 %1847, label %ready.overflow.trap236, label %ready.overflow.resume237

ready.overflow.trap236:                           ; preds = %ready.overflow.resume235
  call void @llvm.trap()
  unreachable

ready.overflow.resume237:                         ; preds = %ready.overflow.resume235
  %1848 = select i1 %1844, i32 %1845, i32 0
  %1849 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1848
  %1850 = load <8 x i1>, ptr %1849, align 1
  %1851 = select i1 %1844, <8 x i1> %431, <8 x i1> %1850
  store <8 x i1> %1851, ptr %1849, align 1
  %1852 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1848
  %1853 = load i32, ptr %1852, align 4
  %1854 = select i1 %1844, i32 18, i32 %1853
  store i32 %1854, ptr %1852, align 4
  %1855 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1848
  %1856 = load i32, ptr %1855, align 4
  %1857 = select i1 %1844, i32 %1843, i32 %1856
  store i32 %1857, ptr %1855, align 4
  %1858 = add i32 %1845, 1
  %1859 = select i1 %1844, i32 %1858, i32 %1845
  store i32 %1859, ptr %ready.count, align 4
  %1860 = load <8 x i1>, ptr %runnable.mask, align 1
  %1861 = or <8 x i1> %1860, %431
  store <8 x i1> %1861, ptr %runnable.mask, align 1
  br label %scheduler.loop

varying.coherent.true238:                         ; preds = %varying.coherent231
  store <8 x i1> %422, ptr %current.mask, align 1
  %1862 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %422)
  br i1 %1862, label %schedule.17, label %scheduler.loop

varying.coherent.false239:                        ; preds = %varying.coherent231
  store <8 x i1> %422, ptr %current.mask, align 1
  %1863 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %422)
  br i1 %1863, label %schedule.18, label %scheduler.loop

convergence.cascade252:                           ; preds = %convergence.cascade252, %schedule.18
  %convergence.cascade.flow256 = phi <8 x i1> [ %485, %schedule.18 ], [ %1906, %convergence.cascade252 ]
  %convergence.cascade.depth257 = phi i32 [ 0, %schedule.18 ], [ %1907, %convergence.cascade252 ]
  %1864 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow256)
  %1865 = load i32, ptr %current.token, align 4
  %1866 = icmp ne i32 %1865, 0
  %1867 = and i1 %1864, %1866
  %1868 = sub i32 %1865, 1
  %1869 = select i1 %1867, i32 %1868, i32 0
  %1870 = load i8, ptr %frame.active, align 1
  %1871 = trunc i32 %1869 to i8
  %1872 = shl i8 1, %1871
  %1873 = and i8 %1870, %1872
  %1874 = icmp ne i8 %1873, 0
  %1875 = load <8 x i32>, ptr %frame.static.id, align 32
  %1876 = extractelement <8 x i32> %1875, i32 %1869
  %convergence.target.pointer258 = getelementptr inbounds [7 x i32], ptr @convergence.targets, i32 0, i32 %1876
  %convergence.dynamic.target259 = load i32, ptr %convergence.target.pointer258, align 4
  %1877 = icmp eq i32 %convergence.dynamic.target259, 18
  %1878 = and i1 %1874, %1877
  %1879 = and i1 %1867, %1878
  %1880 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1869
  %1881 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1869
  %1882 = load <8 x i1>, ptr %1880, align 1
  %1883 = load <8 x i1>, ptr %1881, align 1
  %1884 = or <8 x i1> %1883, %convergence.cascade.flow256
  %1885 = load <8 x i1>, ptr %live.mask, align 1
  %1886 = and <8 x i1> %1882, %1885
  %1887 = icmp eq <8 x i1> %1884, %1886
  %1888 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1887)
  %1889 = and i1 %1879, %1888
  %1890 = select i1 %1889, <8 x i1> zeroinitializer, <8 x i1> %1884
  %1891 = select i1 %1879, <8 x i1> %1890, <8 x i1> %1883
  store <8 x i1> %1891, ptr %1881, align 1
  %1892 = select i1 %1889, <8 x i1> zeroinitializer, <8 x i1> %1882
  store <8 x i1> %1892, ptr %1880, align 1
  %1893 = trunc i32 %1869 to i8
  %1894 = shl i8 1, %1893
  %1895 = xor i8 %1894, -1
  %1896 = and i8 %1870, %1895
  %1897 = select i1 %1889, i8 %1896, i8 %1870
  store i8 %1897, ptr %frame.active, align 1
  %.splatinsert260 = insertelement <8 x i1> poison, i1 %1879, i64 0
  %.splat261 = shufflevector <8 x i1> %.splatinsert260, <8 x i1> poison, <8 x i32> zeroinitializer
  %1898 = and <8 x i1> %convergence.cascade.flow256, %.splat261
  %1899 = load <8 x i1>, ptr %runnable.mask, align 1
  %1900 = xor <8 x i1> %1898, splat (i1 true)
  %1901 = and <8 x i1> %1899, %1900
  store <8 x i1> %1901, ptr %runnable.mask, align 1
  %.splatinsert262 = insertelement <8 x i1> poison, i1 %1889, i64 0
  %.splat263 = shufflevector <8 x i1> %.splatinsert262, <8 x i1> poison, <8 x i32> zeroinitializer
  %1902 = select <8 x i1> %.splat263, <8 x i1> %1884, <8 x i1> zeroinitializer
  %1903 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1904 = extractelement <8 x i32> %1903, i32 %1869
  %1905 = select i1 %1889, i32 %1904, i32 %1865
  store i32 %1905, ptr %current.token, align 4
  %.splatinsert264 = insertelement <8 x i1> poison, i1 %1879, i64 0
  %.splat265 = shufflevector <8 x i1> %.splatinsert264, <8 x i1> poison, <8 x i32> zeroinitializer
  %1906 = select <8 x i1> %.splat265, <8 x i1> %1902, <8 x i1> %convergence.cascade.flow256
  %1907 = add i32 %convergence.cascade.depth257, 1
  %1908 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1906)
  %1909 = icmp ult i32 %1907, 8
  %1910 = and i1 %1908, %1909
  %1911 = and i1 %1879, %1910
  %convergence.parent.token266 = load i32, ptr %current.token, align 4
  %convergence.parent.present267 = icmp ne i32 %convergence.parent.token266, 0
  %1912 = and i1 %1911, %convergence.parent.present267
  br i1 %1912, label %convergence.cascade252, label %convergence.cascade.exit253

convergence.cascade.exit253:                      ; preds = %convergence.cascade252, %schedule.18
  %convergence.cascade.result268 = phi <8 x i1> [ %485, %schedule.18 ], [ %1906, %convergence.cascade252 ]
  %1913 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result268)
  br i1 %1913, label %convergence.target.18.ready, label %scheduler.loop

convergence.target.18.ready:                      ; preds = %convergence.cascade.exit253
  %1914 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result268)
  %1915 = bitcast <8 x i1> %convergence.cascade.result268 to i8
  %1916 = call i8 @llvm.cttz.i8(i8 %1915, i1 false)
  %1917 = zext i8 %1916 to i32
  %1918 = select i1 %1914, i32 %1917, i32 0
  %.spill.load269 = load <8 x i1>, ptr %.spill5, align 1
  %1919 = and <8 x i1> %convergence.cascade.result268, %.spill.load269
  %1920 = xor <8 x i1> %.spill.load269, splat (i1 true)
  %1921 = and <8 x i1> %convergence.cascade.result268, %1920
  %1922 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1919)
  %1923 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1921)
  %1924 = and i1 %1922, %1923
  br i1 %1924, label %varying.divergent270, label %varying.coherent271

varying.divergent270:                             ; preds = %convergence.target.18.ready
  %1925 = load i32, ptr %current.token, align 4
  %1926 = icmp ne i32 %1925, 0
  %1927 = sub i32 %1925, 1
  %1928 = select i1 %1926, i32 %1927, i32 0
  %1929 = load i8, ptr %frame.active, align 1
  %1930 = trunc i32 %1928 to i8
  %1931 = shl i8 1, %1930
  %1932 = and i8 %1929, %1931
  %1933 = icmp ne i8 %1932, 0
  %1934 = load <8 x i32>, ptr %frame.static.id, align 32
  %1935 = extractelement <8 x i32> %1934, i32 %1928
  %1936 = icmp eq i32 %1935, 6
  %1937 = and i1 %1933, %1936
  %1938 = and i1 %1926, %1937
  %1939 = xor i1 %1938, true
  %1940 = and i1 true, %1939
  %1941 = xor i8 %1929, -1
  %1942 = icmp ne i8 %1941, 0
  %1943 = xor i1 %1942, true
  %1944 = and i1 %1940, %1943
  br i1 %1944, label %convergence.overflow.trap272, label %convergence.overflow.resume273

varying.coherent271:                              ; preds = %convergence.target.18.ready
  br i1 %1922, label %varying.coherent.true278, label %varying.coherent.false279

convergence.overflow.trap272:                     ; preds = %varying.divergent270
  call void @llvm.trap()
  unreachable

convergence.overflow.resume273:                   ; preds = %varying.divergent270
  %1945 = call i8 @llvm.cttz.i8(i8 %1941, i1 false)
  %1946 = zext i8 %1945 to i32
  %1947 = select i1 %1942, i32 %1946, i32 0
  %1948 = trunc i32 %1947 to i8
  %1949 = shl i8 1, %1948
  %1950 = or i8 %1929, %1949
  %1951 = select i1 %1940, i8 %1950, i8 %1929
  store i8 %1951, ptr %frame.active, align 1
  %1952 = load <8 x i32>, ptr %frame.static.id, align 32
  %1953 = extractelement <8 x i32> %1952, i32 %1947
  %1954 = select i1 %1940, i32 6, i32 %1953
  %1955 = load <8 x i32>, ptr %frame.static.id, align 32
  %1956 = insertelement <8 x i32> %1955, i32 %1954, i32 %1947
  store <8 x i32> %1956, ptr %frame.static.id, align 32
  %1957 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1958 = extractelement <8 x i32> %1957, i32 %1947
  %1959 = select i1 %1940, i32 %1925, i32 %1958
  %1960 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1961 = insertelement <8 x i32> %1960, i32 %1959, i32 %1947
  store <8 x i32> %1961, ptr %frame.parent.token, align 32
  %1962 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1947
  %1963 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1947
  %1964 = load <8 x i1>, ptr %1962, align 1
  %1965 = load <8 x i1>, ptr %1963, align 1
  %1966 = select i1 %1940, <8 x i1> %convergence.cascade.result268, <8 x i1> %1964
  store <8 x i1> %1966, ptr %1962, align 1
  %1967 = select i1 %1940, <8 x i1> zeroinitializer, <8 x i1> %1965
  store <8 x i1> %1967, ptr %1963, align 1
  %1968 = add i32 %1947, 1
  %1969 = select i1 %1938, i32 %1925, i32 %1968
  %1970 = select i1 true, i32 %1969, i32 %1925
  store i32 %1970, ptr %current.token, align 4
  %1971 = load i32, ptr %current.token, align 4
  %1972 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1919)
  %1973 = load i32, ptr %ready.count, align 4
  %1974 = icmp uge i32 %1973, 8
  %1975 = and i1 %1972, %1974
  br i1 %1975, label %ready.overflow.trap274, label %ready.overflow.resume275

ready.overflow.trap274:                           ; preds = %convergence.overflow.resume273
  call void @llvm.trap()
  unreachable

ready.overflow.resume275:                         ; preds = %convergence.overflow.resume273
  %1976 = select i1 %1972, i32 %1973, i32 0
  %1977 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1976
  %1978 = load <8 x i1>, ptr %1977, align 1
  %1979 = select i1 %1972, <8 x i1> %1919, <8 x i1> %1978
  store <8 x i1> %1979, ptr %1977, align 1
  %1980 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1976
  %1981 = load i32, ptr %1980, align 4
  %1982 = select i1 %1972, i32 19, i32 %1981
  store i32 %1982, ptr %1980, align 4
  %1983 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1976
  %1984 = load i32, ptr %1983, align 4
  %1985 = select i1 %1972, i32 %1971, i32 %1984
  store i32 %1985, ptr %1983, align 4
  %1986 = add i32 %1973, 1
  %1987 = select i1 %1972, i32 %1986, i32 %1973
  store i32 %1987, ptr %ready.count, align 4
  %1988 = load <8 x i1>, ptr %runnable.mask, align 1
  %1989 = or <8 x i1> %1988, %1919
  store <8 x i1> %1989, ptr %runnable.mask, align 1
  %1990 = load i32, ptr %current.token, align 4
  %1991 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1921)
  %1992 = load i32, ptr %ready.count, align 4
  %1993 = icmp uge i32 %1992, 8
  %1994 = and i1 %1991, %1993
  br i1 %1994, label %ready.overflow.trap276, label %ready.overflow.resume277

ready.overflow.trap276:                           ; preds = %ready.overflow.resume275
  call void @llvm.trap()
  unreachable

ready.overflow.resume277:                         ; preds = %ready.overflow.resume275
  %1995 = select i1 %1991, i32 %1992, i32 0
  %1996 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1995
  %1997 = load <8 x i1>, ptr %1996, align 1
  %1998 = select i1 %1991, <8 x i1> %1921, <8 x i1> %1997
  store <8 x i1> %1998, ptr %1996, align 1
  %1999 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1995
  %2000 = load i32, ptr %1999, align 4
  %2001 = select i1 %1991, i32 20, i32 %2000
  store i32 %2001, ptr %1999, align 4
  %2002 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1995
  %2003 = load i32, ptr %2002, align 4
  %2004 = select i1 %1991, i32 %1990, i32 %2003
  store i32 %2004, ptr %2002, align 4
  %2005 = add i32 %1992, 1
  %2006 = select i1 %1991, i32 %2005, i32 %1992
  store i32 %2006, ptr %ready.count, align 4
  %2007 = load <8 x i1>, ptr %runnable.mask, align 1
  %2008 = or <8 x i1> %2007, %1921
  store <8 x i1> %2008, ptr %runnable.mask, align 1
  br label %scheduler.loop

varying.coherent.true278:                         ; preds = %varying.coherent271
  store <8 x i1> %convergence.cascade.result268, ptr %current.mask, align 1
  %2009 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result268)
  br i1 %2009, label %schedule.19, label %scheduler.loop

varying.coherent.false279:                        ; preds = %varying.coherent271
  store <8 x i1> %convergence.cascade.result268, ptr %current.mask, align 1
  %2010 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result268)
  br i1 %2010, label %schedule.20, label %scheduler.loop

convergence.cascade292:                           ; preds = %convergence.cascade292, %schedule.20
  %convergence.cascade.flow296 = phi <8 x i1> [ %542, %schedule.20 ], [ %2053, %convergence.cascade292 ]
  %convergence.cascade.depth297 = phi i32 [ 0, %schedule.20 ], [ %2054, %convergence.cascade292 ]
  %2011 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow296)
  %2012 = load i32, ptr %current.token, align 4
  %2013 = icmp ne i32 %2012, 0
  %2014 = and i1 %2011, %2013
  %2015 = sub i32 %2012, 1
  %2016 = select i1 %2014, i32 %2015, i32 0
  %2017 = load i8, ptr %frame.active, align 1
  %2018 = trunc i32 %2016 to i8
  %2019 = shl i8 1, %2018
  %2020 = and i8 %2017, %2019
  %2021 = icmp ne i8 %2020, 0
  %2022 = load <8 x i32>, ptr %frame.static.id, align 32
  %2023 = extractelement <8 x i32> %2022, i32 %2016
  %convergence.target.pointer298 = getelementptr inbounds [7 x i32], ptr @convergence.targets, i32 0, i32 %2023
  %convergence.dynamic.target299 = load i32, ptr %convergence.target.pointer298, align 4
  %2024 = icmp eq i32 %convergence.dynamic.target299, 20
  %2025 = and i1 %2021, %2024
  %2026 = and i1 %2014, %2025
  %2027 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2016
  %2028 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2016
  %2029 = load <8 x i1>, ptr %2027, align 1
  %2030 = load <8 x i1>, ptr %2028, align 1
  %2031 = or <8 x i1> %2030, %convergence.cascade.flow296
  %2032 = load <8 x i1>, ptr %live.mask, align 1
  %2033 = and <8 x i1> %2029, %2032
  %2034 = icmp eq <8 x i1> %2031, %2033
  %2035 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2034)
  %2036 = and i1 %2026, %2035
  %2037 = select i1 %2036, <8 x i1> zeroinitializer, <8 x i1> %2031
  %2038 = select i1 %2026, <8 x i1> %2037, <8 x i1> %2030
  store <8 x i1> %2038, ptr %2028, align 1
  %2039 = select i1 %2036, <8 x i1> zeroinitializer, <8 x i1> %2029
  store <8 x i1> %2039, ptr %2027, align 1
  %2040 = trunc i32 %2016 to i8
  %2041 = shl i8 1, %2040
  %2042 = xor i8 %2041, -1
  %2043 = and i8 %2017, %2042
  %2044 = select i1 %2036, i8 %2043, i8 %2017
  store i8 %2044, ptr %frame.active, align 1
  %.splatinsert300 = insertelement <8 x i1> poison, i1 %2026, i64 0
  %.splat301 = shufflevector <8 x i1> %.splatinsert300, <8 x i1> poison, <8 x i32> zeroinitializer
  %2045 = and <8 x i1> %convergence.cascade.flow296, %.splat301
  %2046 = load <8 x i1>, ptr %runnable.mask, align 1
  %2047 = xor <8 x i1> %2045, splat (i1 true)
  %2048 = and <8 x i1> %2046, %2047
  store <8 x i1> %2048, ptr %runnable.mask, align 1
  %.splatinsert302 = insertelement <8 x i1> poison, i1 %2036, i64 0
  %.splat303 = shufflevector <8 x i1> %.splatinsert302, <8 x i1> poison, <8 x i32> zeroinitializer
  %2049 = select <8 x i1> %.splat303, <8 x i1> %2031, <8 x i1> zeroinitializer
  %2050 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2051 = extractelement <8 x i32> %2050, i32 %2016
  %2052 = select i1 %2036, i32 %2051, i32 %2012
  store i32 %2052, ptr %current.token, align 4
  %.splatinsert304 = insertelement <8 x i1> poison, i1 %2026, i64 0
  %.splat305 = shufflevector <8 x i1> %.splatinsert304, <8 x i1> poison, <8 x i32> zeroinitializer
  %2053 = select <8 x i1> %.splat305, <8 x i1> %2049, <8 x i1> %convergence.cascade.flow296
  %2054 = add i32 %convergence.cascade.depth297, 1
  %2055 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2053)
  %2056 = icmp ult i32 %2054, 8
  %2057 = and i1 %2055, %2056
  %2058 = and i1 %2026, %2057
  %convergence.parent.token306 = load i32, ptr %current.token, align 4
  %convergence.parent.present307 = icmp ne i32 %convergence.parent.token306, 0
  %2059 = and i1 %2058, %convergence.parent.present307
  br i1 %2059, label %convergence.cascade292, label %convergence.cascade.exit293

convergence.cascade.exit293:                      ; preds = %convergence.cascade292, %schedule.20
  %convergence.cascade.result308 = phi <8 x i1> [ %542, %schedule.20 ], [ %2053, %convergence.cascade292 ]
  %2060 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result308)
  br i1 %2060, label %convergence.target.20.ready, label %scheduler.loop

convergence.target.20.ready:                      ; preds = %convergence.cascade.exit293
  %2061 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result308)
  %2062 = bitcast <8 x i1> %convergence.cascade.result308 to i8
  %2063 = call i8 @llvm.cttz.i8(i8 %2062, i1 false)
  %2064 = zext i8 %2063 to i32
  %2065 = select i1 %2061, i32 %2064, i32 0
  %2066 = load <8 x i1>, ptr %live.mask, align 1
  %2067 = xor <8 x i1> %convergence.cascade.result308, splat (i1 true)
  %2068 = and <8 x i1> %2066, %2067
  store <8 x i1> %2068, ptr %live.mask, align 1
  %2069 = load <8 x i1>, ptr %runnable.mask, align 1
  %2070 = xor <8 x i1> %convergence.cascade.result308, splat (i1 true)
  %2071 = and <8 x i1> %2069, %2070
  store <8 x i1> %2071, ptr %runnable.mask, align 1
  %return.active.frames = load i8, ptr %frame.active, align 1
  %return.frames.present = icmp ne i8 %return.active.frames, 0
  br i1 %return.frames.present, label %return.frame.cleanup, label %return.frame.cleanup.done

return.frame.cleanup:                             ; preds = %convergence.target.20.ready
  %2072 = load i8, ptr %frame.active, align 1
  %2073 = and i8 %2072, 1
  %2074 = icmp ne i8 %2073, 0
  %2075 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 0
  %2076 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 0
  %2077 = load <8 x i1>, ptr %2075, align 1
  %2078 = load <8 x i1>, ptr %2076, align 1
  %2079 = and <8 x i1> %2077, %2068
  %2080 = icmp eq <8 x i1> %2078, %2079
  %2081 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2080)
  %2082 = and i1 %2074, %2081
  %.splatinsert309 = insertelement <8 x i1> poison, i1 %2082, i64 0
  %.splat310 = shufflevector <8 x i1> %.splatinsert309, <8 x i1> poison, <8 x i32> zeroinitializer
  %2083 = select <8 x i1> %.splat310, <8 x i1> %2078, <8 x i1> zeroinitializer
  %2084 = select i1 %2082, <8 x i1> zeroinitializer, <8 x i1> %2079
  store <8 x i1> %2084, ptr %2075, align 1
  %2085 = select i1 %2082, <8 x i1> zeroinitializer, <8 x i1> %2078
  store <8 x i1> %2085, ptr %2076, align 1
  %2086 = and i8 %2072, -2
  %2087 = select i1 %2082, i8 %2086, i8 %2072
  store i8 %2087, ptr %frame.active, align 1
  %2088 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2089 = extractelement <8 x i32> %2088, i32 0
  %2090 = load <8 x i32>, ptr %frame.static.id, align 32
  %2091 = extractelement <8 x i32> %2090, i32 0
  %convergence.target.pointer311 = getelementptr inbounds [7 x i32], ptr @convergence.targets, i32 0, i32 %2091
  %convergence.dynamic.target312 = load i32, ptr %convergence.target.pointer311, align 4
  %2092 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2083)
  %2093 = load i32, ptr %ready.count, align 4
  %2094 = icmp uge i32 %2093, 8
  %2095 = and i1 %2092, %2094
  br i1 %2095, label %ready.overflow.trap313, label %ready.overflow.resume314

return.frame.cleanup.done:                        ; preds = %ready.overflow.resume356, %convergence.target.20.ready
  br label %scheduler.loop

ready.overflow.trap313:                           ; preds = %return.frame.cleanup
  call void @llvm.trap()
  unreachable

ready.overflow.resume314:                         ; preds = %return.frame.cleanup
  %2096 = select i1 %2092, i32 %2093, i32 0
  %2097 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2096
  %2098 = load <8 x i1>, ptr %2097, align 1
  %2099 = select i1 %2092, <8 x i1> %2083, <8 x i1> %2098
  store <8 x i1> %2099, ptr %2097, align 1
  %2100 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2096
  %2101 = load i32, ptr %2100, align 4
  %2102 = select i1 %2092, i32 %convergence.dynamic.target312, i32 %2101
  store i32 %2102, ptr %2100, align 4
  %2103 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2096
  %2104 = load i32, ptr %2103, align 4
  %2105 = select i1 %2092, i32 %2089, i32 %2104
  store i32 %2105, ptr %2103, align 4
  %2106 = add i32 %2093, 1
  %2107 = select i1 %2092, i32 %2106, i32 %2093
  store i32 %2107, ptr %ready.count, align 4
  %2108 = load <8 x i1>, ptr %runnable.mask, align 1
  %2109 = or <8 x i1> %2108, %2083
  store <8 x i1> %2109, ptr %runnable.mask, align 1
  %2110 = load i8, ptr %frame.active, align 1
  %2111 = and i8 %2110, 2
  %2112 = icmp ne i8 %2111, 0
  %2113 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 1
  %2114 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 1
  %2115 = load <8 x i1>, ptr %2113, align 1
  %2116 = load <8 x i1>, ptr %2114, align 1
  %2117 = and <8 x i1> %2115, %2068
  %2118 = icmp eq <8 x i1> %2116, %2117
  %2119 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2118)
  %2120 = and i1 %2112, %2119
  %.splatinsert315 = insertelement <8 x i1> poison, i1 %2120, i64 0
  %.splat316 = shufflevector <8 x i1> %.splatinsert315, <8 x i1> poison, <8 x i32> zeroinitializer
  %2121 = select <8 x i1> %.splat316, <8 x i1> %2116, <8 x i1> zeroinitializer
  %2122 = select i1 %2120, <8 x i1> zeroinitializer, <8 x i1> %2117
  store <8 x i1> %2122, ptr %2113, align 1
  %2123 = select i1 %2120, <8 x i1> zeroinitializer, <8 x i1> %2116
  store <8 x i1> %2123, ptr %2114, align 1
  %2124 = and i8 %2110, -3
  %2125 = select i1 %2120, i8 %2124, i8 %2110
  store i8 %2125, ptr %frame.active, align 1
  %2126 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2127 = extractelement <8 x i32> %2126, i32 1
  %2128 = load <8 x i32>, ptr %frame.static.id, align 32
  %2129 = extractelement <8 x i32> %2128, i32 1
  %convergence.target.pointer317 = getelementptr inbounds [7 x i32], ptr @convergence.targets, i32 0, i32 %2129
  %convergence.dynamic.target318 = load i32, ptr %convergence.target.pointer317, align 4
  %2130 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2121)
  %2131 = load i32, ptr %ready.count, align 4
  %2132 = icmp uge i32 %2131, 8
  %2133 = and i1 %2130, %2132
  br i1 %2133, label %ready.overflow.trap319, label %ready.overflow.resume320

ready.overflow.trap319:                           ; preds = %ready.overflow.resume314
  call void @llvm.trap()
  unreachable

ready.overflow.resume320:                         ; preds = %ready.overflow.resume314
  %2134 = select i1 %2130, i32 %2131, i32 0
  %2135 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2134
  %2136 = load <8 x i1>, ptr %2135, align 1
  %2137 = select i1 %2130, <8 x i1> %2121, <8 x i1> %2136
  store <8 x i1> %2137, ptr %2135, align 1
  %2138 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2134
  %2139 = load i32, ptr %2138, align 4
  %2140 = select i1 %2130, i32 %convergence.dynamic.target318, i32 %2139
  store i32 %2140, ptr %2138, align 4
  %2141 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2134
  %2142 = load i32, ptr %2141, align 4
  %2143 = select i1 %2130, i32 %2127, i32 %2142
  store i32 %2143, ptr %2141, align 4
  %2144 = add i32 %2131, 1
  %2145 = select i1 %2130, i32 %2144, i32 %2131
  store i32 %2145, ptr %ready.count, align 4
  %2146 = load <8 x i1>, ptr %runnable.mask, align 1
  %2147 = or <8 x i1> %2146, %2121
  store <8 x i1> %2147, ptr %runnable.mask, align 1
  %2148 = load i8, ptr %frame.active, align 1
  %2149 = and i8 %2148, 4
  %2150 = icmp ne i8 %2149, 0
  %2151 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 2
  %2152 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 2
  %2153 = load <8 x i1>, ptr %2151, align 1
  %2154 = load <8 x i1>, ptr %2152, align 1
  %2155 = and <8 x i1> %2153, %2068
  %2156 = icmp eq <8 x i1> %2154, %2155
  %2157 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2156)
  %2158 = and i1 %2150, %2157
  %.splatinsert321 = insertelement <8 x i1> poison, i1 %2158, i64 0
  %.splat322 = shufflevector <8 x i1> %.splatinsert321, <8 x i1> poison, <8 x i32> zeroinitializer
  %2159 = select <8 x i1> %.splat322, <8 x i1> %2154, <8 x i1> zeroinitializer
  %2160 = select i1 %2158, <8 x i1> zeroinitializer, <8 x i1> %2155
  store <8 x i1> %2160, ptr %2151, align 1
  %2161 = select i1 %2158, <8 x i1> zeroinitializer, <8 x i1> %2154
  store <8 x i1> %2161, ptr %2152, align 1
  %2162 = and i8 %2148, -5
  %2163 = select i1 %2158, i8 %2162, i8 %2148
  store i8 %2163, ptr %frame.active, align 1
  %2164 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2165 = extractelement <8 x i32> %2164, i32 2
  %2166 = load <8 x i32>, ptr %frame.static.id, align 32
  %2167 = extractelement <8 x i32> %2166, i32 2
  %convergence.target.pointer323 = getelementptr inbounds [7 x i32], ptr @convergence.targets, i32 0, i32 %2167
  %convergence.dynamic.target324 = load i32, ptr %convergence.target.pointer323, align 4
  %2168 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2159)
  %2169 = load i32, ptr %ready.count, align 4
  %2170 = icmp uge i32 %2169, 8
  %2171 = and i1 %2168, %2170
  br i1 %2171, label %ready.overflow.trap325, label %ready.overflow.resume326

ready.overflow.trap325:                           ; preds = %ready.overflow.resume320
  call void @llvm.trap()
  unreachable

ready.overflow.resume326:                         ; preds = %ready.overflow.resume320
  %2172 = select i1 %2168, i32 %2169, i32 0
  %2173 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2172
  %2174 = load <8 x i1>, ptr %2173, align 1
  %2175 = select i1 %2168, <8 x i1> %2159, <8 x i1> %2174
  store <8 x i1> %2175, ptr %2173, align 1
  %2176 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2172
  %2177 = load i32, ptr %2176, align 4
  %2178 = select i1 %2168, i32 %convergence.dynamic.target324, i32 %2177
  store i32 %2178, ptr %2176, align 4
  %2179 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2172
  %2180 = load i32, ptr %2179, align 4
  %2181 = select i1 %2168, i32 %2165, i32 %2180
  store i32 %2181, ptr %2179, align 4
  %2182 = add i32 %2169, 1
  %2183 = select i1 %2168, i32 %2182, i32 %2169
  store i32 %2183, ptr %ready.count, align 4
  %2184 = load <8 x i1>, ptr %runnable.mask, align 1
  %2185 = or <8 x i1> %2184, %2159
  store <8 x i1> %2185, ptr %runnable.mask, align 1
  %2186 = load i8, ptr %frame.active, align 1
  %2187 = and i8 %2186, 8
  %2188 = icmp ne i8 %2187, 0
  %2189 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 3
  %2190 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 3
  %2191 = load <8 x i1>, ptr %2189, align 1
  %2192 = load <8 x i1>, ptr %2190, align 1
  %2193 = and <8 x i1> %2191, %2068
  %2194 = icmp eq <8 x i1> %2192, %2193
  %2195 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2194)
  %2196 = and i1 %2188, %2195
  %.splatinsert327 = insertelement <8 x i1> poison, i1 %2196, i64 0
  %.splat328 = shufflevector <8 x i1> %.splatinsert327, <8 x i1> poison, <8 x i32> zeroinitializer
  %2197 = select <8 x i1> %.splat328, <8 x i1> %2192, <8 x i1> zeroinitializer
  %2198 = select i1 %2196, <8 x i1> zeroinitializer, <8 x i1> %2193
  store <8 x i1> %2198, ptr %2189, align 1
  %2199 = select i1 %2196, <8 x i1> zeroinitializer, <8 x i1> %2192
  store <8 x i1> %2199, ptr %2190, align 1
  %2200 = and i8 %2186, -9
  %2201 = select i1 %2196, i8 %2200, i8 %2186
  store i8 %2201, ptr %frame.active, align 1
  %2202 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2203 = extractelement <8 x i32> %2202, i32 3
  %2204 = load <8 x i32>, ptr %frame.static.id, align 32
  %2205 = extractelement <8 x i32> %2204, i32 3
  %convergence.target.pointer329 = getelementptr inbounds [7 x i32], ptr @convergence.targets, i32 0, i32 %2205
  %convergence.dynamic.target330 = load i32, ptr %convergence.target.pointer329, align 4
  %2206 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2197)
  %2207 = load i32, ptr %ready.count, align 4
  %2208 = icmp uge i32 %2207, 8
  %2209 = and i1 %2206, %2208
  br i1 %2209, label %ready.overflow.trap331, label %ready.overflow.resume332

ready.overflow.trap331:                           ; preds = %ready.overflow.resume326
  call void @llvm.trap()
  unreachable

ready.overflow.resume332:                         ; preds = %ready.overflow.resume326
  %2210 = select i1 %2206, i32 %2207, i32 0
  %2211 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2210
  %2212 = load <8 x i1>, ptr %2211, align 1
  %2213 = select i1 %2206, <8 x i1> %2197, <8 x i1> %2212
  store <8 x i1> %2213, ptr %2211, align 1
  %2214 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2210
  %2215 = load i32, ptr %2214, align 4
  %2216 = select i1 %2206, i32 %convergence.dynamic.target330, i32 %2215
  store i32 %2216, ptr %2214, align 4
  %2217 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2210
  %2218 = load i32, ptr %2217, align 4
  %2219 = select i1 %2206, i32 %2203, i32 %2218
  store i32 %2219, ptr %2217, align 4
  %2220 = add i32 %2207, 1
  %2221 = select i1 %2206, i32 %2220, i32 %2207
  store i32 %2221, ptr %ready.count, align 4
  %2222 = load <8 x i1>, ptr %runnable.mask, align 1
  %2223 = or <8 x i1> %2222, %2197
  store <8 x i1> %2223, ptr %runnable.mask, align 1
  %2224 = load i8, ptr %frame.active, align 1
  %2225 = and i8 %2224, 16
  %2226 = icmp ne i8 %2225, 0
  %2227 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 4
  %2228 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 4
  %2229 = load <8 x i1>, ptr %2227, align 1
  %2230 = load <8 x i1>, ptr %2228, align 1
  %2231 = and <8 x i1> %2229, %2068
  %2232 = icmp eq <8 x i1> %2230, %2231
  %2233 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2232)
  %2234 = and i1 %2226, %2233
  %.splatinsert333 = insertelement <8 x i1> poison, i1 %2234, i64 0
  %.splat334 = shufflevector <8 x i1> %.splatinsert333, <8 x i1> poison, <8 x i32> zeroinitializer
  %2235 = select <8 x i1> %.splat334, <8 x i1> %2230, <8 x i1> zeroinitializer
  %2236 = select i1 %2234, <8 x i1> zeroinitializer, <8 x i1> %2231
  store <8 x i1> %2236, ptr %2227, align 1
  %2237 = select i1 %2234, <8 x i1> zeroinitializer, <8 x i1> %2230
  store <8 x i1> %2237, ptr %2228, align 1
  %2238 = and i8 %2224, -17
  %2239 = select i1 %2234, i8 %2238, i8 %2224
  store i8 %2239, ptr %frame.active, align 1
  %2240 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2241 = extractelement <8 x i32> %2240, i32 4
  %2242 = load <8 x i32>, ptr %frame.static.id, align 32
  %2243 = extractelement <8 x i32> %2242, i32 4
  %convergence.target.pointer335 = getelementptr inbounds [7 x i32], ptr @convergence.targets, i32 0, i32 %2243
  %convergence.dynamic.target336 = load i32, ptr %convergence.target.pointer335, align 4
  %2244 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2235)
  %2245 = load i32, ptr %ready.count, align 4
  %2246 = icmp uge i32 %2245, 8
  %2247 = and i1 %2244, %2246
  br i1 %2247, label %ready.overflow.trap337, label %ready.overflow.resume338

ready.overflow.trap337:                           ; preds = %ready.overflow.resume332
  call void @llvm.trap()
  unreachable

ready.overflow.resume338:                         ; preds = %ready.overflow.resume332
  %2248 = select i1 %2244, i32 %2245, i32 0
  %2249 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2248
  %2250 = load <8 x i1>, ptr %2249, align 1
  %2251 = select i1 %2244, <8 x i1> %2235, <8 x i1> %2250
  store <8 x i1> %2251, ptr %2249, align 1
  %2252 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2248
  %2253 = load i32, ptr %2252, align 4
  %2254 = select i1 %2244, i32 %convergence.dynamic.target336, i32 %2253
  store i32 %2254, ptr %2252, align 4
  %2255 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2248
  %2256 = load i32, ptr %2255, align 4
  %2257 = select i1 %2244, i32 %2241, i32 %2256
  store i32 %2257, ptr %2255, align 4
  %2258 = add i32 %2245, 1
  %2259 = select i1 %2244, i32 %2258, i32 %2245
  store i32 %2259, ptr %ready.count, align 4
  %2260 = load <8 x i1>, ptr %runnable.mask, align 1
  %2261 = or <8 x i1> %2260, %2235
  store <8 x i1> %2261, ptr %runnable.mask, align 1
  %2262 = load i8, ptr %frame.active, align 1
  %2263 = and i8 %2262, 32
  %2264 = icmp ne i8 %2263, 0
  %2265 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 5
  %2266 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 5
  %2267 = load <8 x i1>, ptr %2265, align 1
  %2268 = load <8 x i1>, ptr %2266, align 1
  %2269 = and <8 x i1> %2267, %2068
  %2270 = icmp eq <8 x i1> %2268, %2269
  %2271 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2270)
  %2272 = and i1 %2264, %2271
  %.splatinsert339 = insertelement <8 x i1> poison, i1 %2272, i64 0
  %.splat340 = shufflevector <8 x i1> %.splatinsert339, <8 x i1> poison, <8 x i32> zeroinitializer
  %2273 = select <8 x i1> %.splat340, <8 x i1> %2268, <8 x i1> zeroinitializer
  %2274 = select i1 %2272, <8 x i1> zeroinitializer, <8 x i1> %2269
  store <8 x i1> %2274, ptr %2265, align 1
  %2275 = select i1 %2272, <8 x i1> zeroinitializer, <8 x i1> %2268
  store <8 x i1> %2275, ptr %2266, align 1
  %2276 = and i8 %2262, -33
  %2277 = select i1 %2272, i8 %2276, i8 %2262
  store i8 %2277, ptr %frame.active, align 1
  %2278 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2279 = extractelement <8 x i32> %2278, i32 5
  %2280 = load <8 x i32>, ptr %frame.static.id, align 32
  %2281 = extractelement <8 x i32> %2280, i32 5
  %convergence.target.pointer341 = getelementptr inbounds [7 x i32], ptr @convergence.targets, i32 0, i32 %2281
  %convergence.dynamic.target342 = load i32, ptr %convergence.target.pointer341, align 4
  %2282 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2273)
  %2283 = load i32, ptr %ready.count, align 4
  %2284 = icmp uge i32 %2283, 8
  %2285 = and i1 %2282, %2284
  br i1 %2285, label %ready.overflow.trap343, label %ready.overflow.resume344

ready.overflow.trap343:                           ; preds = %ready.overflow.resume338
  call void @llvm.trap()
  unreachable

ready.overflow.resume344:                         ; preds = %ready.overflow.resume338
  %2286 = select i1 %2282, i32 %2283, i32 0
  %2287 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2286
  %2288 = load <8 x i1>, ptr %2287, align 1
  %2289 = select i1 %2282, <8 x i1> %2273, <8 x i1> %2288
  store <8 x i1> %2289, ptr %2287, align 1
  %2290 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2286
  %2291 = load i32, ptr %2290, align 4
  %2292 = select i1 %2282, i32 %convergence.dynamic.target342, i32 %2291
  store i32 %2292, ptr %2290, align 4
  %2293 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2286
  %2294 = load i32, ptr %2293, align 4
  %2295 = select i1 %2282, i32 %2279, i32 %2294
  store i32 %2295, ptr %2293, align 4
  %2296 = add i32 %2283, 1
  %2297 = select i1 %2282, i32 %2296, i32 %2283
  store i32 %2297, ptr %ready.count, align 4
  %2298 = load <8 x i1>, ptr %runnable.mask, align 1
  %2299 = or <8 x i1> %2298, %2273
  store <8 x i1> %2299, ptr %runnable.mask, align 1
  %2300 = load i8, ptr %frame.active, align 1
  %2301 = and i8 %2300, 64
  %2302 = icmp ne i8 %2301, 0
  %2303 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 6
  %2304 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 6
  %2305 = load <8 x i1>, ptr %2303, align 1
  %2306 = load <8 x i1>, ptr %2304, align 1
  %2307 = and <8 x i1> %2305, %2068
  %2308 = icmp eq <8 x i1> %2306, %2307
  %2309 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2308)
  %2310 = and i1 %2302, %2309
  %.splatinsert345 = insertelement <8 x i1> poison, i1 %2310, i64 0
  %.splat346 = shufflevector <8 x i1> %.splatinsert345, <8 x i1> poison, <8 x i32> zeroinitializer
  %2311 = select <8 x i1> %.splat346, <8 x i1> %2306, <8 x i1> zeroinitializer
  %2312 = select i1 %2310, <8 x i1> zeroinitializer, <8 x i1> %2307
  store <8 x i1> %2312, ptr %2303, align 1
  %2313 = select i1 %2310, <8 x i1> zeroinitializer, <8 x i1> %2306
  store <8 x i1> %2313, ptr %2304, align 1
  %2314 = and i8 %2300, -65
  %2315 = select i1 %2310, i8 %2314, i8 %2300
  store i8 %2315, ptr %frame.active, align 1
  %2316 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2317 = extractelement <8 x i32> %2316, i32 6
  %2318 = load <8 x i32>, ptr %frame.static.id, align 32
  %2319 = extractelement <8 x i32> %2318, i32 6
  %convergence.target.pointer347 = getelementptr inbounds [7 x i32], ptr @convergence.targets, i32 0, i32 %2319
  %convergence.dynamic.target348 = load i32, ptr %convergence.target.pointer347, align 4
  %2320 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2311)
  %2321 = load i32, ptr %ready.count, align 4
  %2322 = icmp uge i32 %2321, 8
  %2323 = and i1 %2320, %2322
  br i1 %2323, label %ready.overflow.trap349, label %ready.overflow.resume350

ready.overflow.trap349:                           ; preds = %ready.overflow.resume344
  call void @llvm.trap()
  unreachable

ready.overflow.resume350:                         ; preds = %ready.overflow.resume344
  %2324 = select i1 %2320, i32 %2321, i32 0
  %2325 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2324
  %2326 = load <8 x i1>, ptr %2325, align 1
  %2327 = select i1 %2320, <8 x i1> %2311, <8 x i1> %2326
  store <8 x i1> %2327, ptr %2325, align 1
  %2328 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2324
  %2329 = load i32, ptr %2328, align 4
  %2330 = select i1 %2320, i32 %convergence.dynamic.target348, i32 %2329
  store i32 %2330, ptr %2328, align 4
  %2331 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2324
  %2332 = load i32, ptr %2331, align 4
  %2333 = select i1 %2320, i32 %2317, i32 %2332
  store i32 %2333, ptr %2331, align 4
  %2334 = add i32 %2321, 1
  %2335 = select i1 %2320, i32 %2334, i32 %2321
  store i32 %2335, ptr %ready.count, align 4
  %2336 = load <8 x i1>, ptr %runnable.mask, align 1
  %2337 = or <8 x i1> %2336, %2311
  store <8 x i1> %2337, ptr %runnable.mask, align 1
  %2338 = load i8, ptr %frame.active, align 1
  %2339 = and i8 %2338, -128
  %2340 = icmp ne i8 %2339, 0
  %2341 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 7
  %2342 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 7
  %2343 = load <8 x i1>, ptr %2341, align 1
  %2344 = load <8 x i1>, ptr %2342, align 1
  %2345 = and <8 x i1> %2343, %2068
  %2346 = icmp eq <8 x i1> %2344, %2345
  %2347 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2346)
  %2348 = and i1 %2340, %2347
  %.splatinsert351 = insertelement <8 x i1> poison, i1 %2348, i64 0
  %.splat352 = shufflevector <8 x i1> %.splatinsert351, <8 x i1> poison, <8 x i32> zeroinitializer
  %2349 = select <8 x i1> %.splat352, <8 x i1> %2344, <8 x i1> zeroinitializer
  %2350 = select i1 %2348, <8 x i1> zeroinitializer, <8 x i1> %2345
  store <8 x i1> %2350, ptr %2341, align 1
  %2351 = select i1 %2348, <8 x i1> zeroinitializer, <8 x i1> %2344
  store <8 x i1> %2351, ptr %2342, align 1
  %2352 = and i8 %2338, 127
  %2353 = select i1 %2348, i8 %2352, i8 %2338
  store i8 %2353, ptr %frame.active, align 1
  %2354 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2355 = extractelement <8 x i32> %2354, i32 7
  %2356 = load <8 x i32>, ptr %frame.static.id, align 32
  %2357 = extractelement <8 x i32> %2356, i32 7
  %convergence.target.pointer353 = getelementptr inbounds [7 x i32], ptr @convergence.targets, i32 0, i32 %2357
  %convergence.dynamic.target354 = load i32, ptr %convergence.target.pointer353, align 4
  %2358 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2349)
  %2359 = load i32, ptr %ready.count, align 4
  %2360 = icmp uge i32 %2359, 8
  %2361 = and i1 %2358, %2360
  br i1 %2361, label %ready.overflow.trap355, label %ready.overflow.resume356

ready.overflow.trap355:                           ; preds = %ready.overflow.resume350
  call void @llvm.trap()
  unreachable

ready.overflow.resume356:                         ; preds = %ready.overflow.resume350
  %2362 = select i1 %2358, i32 %2359, i32 0
  %2363 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2362
  %2364 = load <8 x i1>, ptr %2363, align 1
  %2365 = select i1 %2358, <8 x i1> %2349, <8 x i1> %2364
  store <8 x i1> %2365, ptr %2363, align 1
  %2366 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2362
  %2367 = load i32, ptr %2366, align 4
  %2368 = select i1 %2358, i32 %convergence.dynamic.target354, i32 %2367
  store i32 %2368, ptr %2366, align 4
  %2369 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2362
  %2370 = load i32, ptr %2369, align 4
  %2371 = select i1 %2358, i32 %2355, i32 %2370
  store i32 %2371, ptr %2369, align 4
  %2372 = add i32 %2359, 1
  %2373 = select i1 %2358, i32 %2372, i32 %2359
  store i32 %2373, ptr %ready.count, align 4
  %2374 = load <8 x i1>, ptr %runnable.mask, align 1
  %2375 = or <8 x i1> %2374, %2349
  store <8 x i1> %2375, ptr %runnable.mask, align 1
  br label %return.frame.cleanup.done
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), i32 immarg, <8 x i1>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.and.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #4

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.sqrt.f32(float) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), i32 immarg, <8 x i1>) #5

define dso_local void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

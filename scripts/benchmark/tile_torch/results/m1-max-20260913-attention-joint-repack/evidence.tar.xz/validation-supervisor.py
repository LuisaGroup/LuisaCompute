"""Retain one pure-Python protocol_check receipt; no native/build/freeze phase."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

ROOT = Path(__file__).resolve().parent
PYTHON = Path('/tmp/luisa-attention-joint-env.MxOWzT/bin/python')
FILES = ('run.py', 'predeclared.json', 'audit.py', 'protocol_check.py', 'gate.py', 'owned.txt', 'freeze.py')
REFERENCE = ('README.md', 'run.py', 'audit.py', 'predeclared.json')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')


def main():
    label = 'validation-supervisor-1'
    paths = [ROOT / (label + suffix) for suffix in ('.command.json', '.result.json', '.stdout', '.stderr')]
    if any(path.exists() for path in paths):
        raise ValueError('receipt exists; do not overwrite or selectively retry')
    source_hashes = {name: sha(ROOT / name) for name in FILES}
    references = {name: sha(ROOT / 'reference' / name) for name in REFERENCE}
    env = {key: value for key, value in os.environ.items() if not key.startswith(('LUISA_', 'MTL_'))}
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    record = dict(command=[str(PYTHON), '-B', str(ROOT / 'protocol_check.py')], cwd=str(ROOT),
                  started=time.time(), timeout_s=30, process_group_isolated=True,
                  scope='Pure-Python static protocol and in-memory mocked supervisor validation; no native kernel, build, test binary or official freeze',
                  source_sha256=source_hashes, reference_sha256=references,
                  supervisor_sha256=sha(Path(__file__)), python_launcher=str(PYTHON),
                  python_resolved=str(PYTHON.resolve()), python_sha256=sha(PYTHON),
                  environment={'PYTHONDONTWRITEBYTECODE': '1'})
    save(paths[0], record)
    record.update(timed_out=False, termination_reason='not_started')
    process = None
    stdout = stderr = b''
    try:
        process = subprocess.Popen(record['command'], cwd=ROOT, env=env, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, start_new_session=True)
        try:
            stdout, stderr = process.communicate(timeout=30)
        except subprocess.TimeoutExpired:
            record.update(timed_out=True, termination_reason='deadline_exceeded', error='protocol Python process exceeded 30 seconds')
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            stdout, stderr = process.communicate()
        record['returncode'] = process.returncode
        if not record['timed_out']:
            record['termination_reason'] = 'process_exited'
        if process.returncode or record['timed_out'] or stderr:
            raise ValueError('protocol check did not complete cleanly; see retained stdout/stderr')
        result = json.loads(stdout)
        if result.get('status') != 'passed' or result.get('native_execution') is not False or result.get('frozen') is not False:
            raise ValueError('protocol check did not report its declared non-native/non-freeze contract')
        record['source_unchanged'] = source_hashes == {name: sha(ROOT / name) for name in FILES}
        record['reference_unchanged'] = references == {name: sha(ROOT / 'reference' / name) for name in REFERENCE}
        if not record['source_unchanged'] or not record['reference_unchanged']:
            raise ValueError('ready scripts changed during protocol check')
        record['status'] = 'passed'
    except BaseException as error:
        if process is not None and process.poll() is None:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            stdout, stderr = process.communicate()
            record['returncode'] = process.returncode
            if not record['timed_out']:
                record['termination_reason'] = 'supervisor_interrupted'
        record.setdefault('error', str(error))
        record['raised_exception'] = str(error)
        record['status'] = 'error'
        raise
    finally:
        for path, payload in zip(paths[2:], (stdout, stderr)):
            with path.open('xb') as stream:
                stream.write(payload)
        record.update(finished=time.time(), stdout_sha256=sha(paths[2]), stderr_sha256=sha(paths[3]))
        save(paths[1], record)
    print(json.dumps(dict(status=record['status'], receipt=str(paths[1]), sha256=sha(paths[1])), indent=2))


if __name__ == '__main__':
    main()

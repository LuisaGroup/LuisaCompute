	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention.full_packet
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.quad	0                               ; 0x0
	.quad	320                             ; 0x140
lCPI0_3:
	.quad	640                             ; 0x280
	.quad	960                             ; 0x3c0
lCPI0_4:
	.quad	1280                            ; 0x500
	.quad	1600                            ; 0x640
lCPI0_5:
	.quad	1920                            ; 0x780
	.quad	2240                            ; 0x8c0
lCPI0_6:
	.quad	384                             ; 0x180
	.quad	448                             ; 0x1c0
lCPI0_7:
	.quad	256                             ; 0x100
	.quad	320                             ; 0x140
lCPI0_8:
	.quad	128                             ; 0x80
	.quad	192                             ; 0xc0
lCPI0_9:
	.quad	0                               ; 0x0
	.quad	64                              ; 0x40
lCPI0_10:
	.quad	388                             ; 0x184
	.quad	452                             ; 0x1c4
lCPI0_11:
	.quad	260                             ; 0x104
	.quad	324                             ; 0x144
lCPI0_12:
	.quad	132                             ; 0x84
	.quad	196                             ; 0xc4
lCPI0_13:
	.quad	4                               ; 0x4
	.quad	68                              ; 0x44
lCPI0_14:
	.quad	392                             ; 0x188
	.quad	456                             ; 0x1c8
lCPI0_15:
	.quad	264                             ; 0x108
	.quad	328                             ; 0x148
lCPI0_16:
	.quad	136                             ; 0x88
	.quad	200                             ; 0xc8
lCPI0_17:
	.quad	8                               ; 0x8
	.quad	72                              ; 0x48
lCPI0_18:
	.quad	396                             ; 0x18c
	.quad	460                             ; 0x1cc
lCPI0_19:
	.quad	268                             ; 0x10c
	.quad	332                             ; 0x14c
lCPI0_20:
	.quad	140                             ; 0x8c
	.quad	204                             ; 0xcc
lCPI0_21:
	.quad	12                              ; 0xc
	.quad	76                              ; 0x4c
lCPI0_22:
	.quad	400                             ; 0x190
	.quad	464                             ; 0x1d0
lCPI0_23:
	.quad	272                             ; 0x110
	.quad	336                             ; 0x150
lCPI0_24:
	.quad	144                             ; 0x90
	.quad	208                             ; 0xd0
lCPI0_25:
	.quad	16                              ; 0x10
	.quad	80                              ; 0x50
lCPI0_26:
	.quad	404                             ; 0x194
	.quad	468                             ; 0x1d4
lCPI0_27:
	.quad	276                             ; 0x114
	.quad	340                             ; 0x154
lCPI0_28:
	.quad	148                             ; 0x94
	.quad	212                             ; 0xd4
lCPI0_29:
	.quad	20                              ; 0x14
	.quad	84                              ; 0x54
lCPI0_30:
	.quad	408                             ; 0x198
	.quad	472                             ; 0x1d8
lCPI0_31:
	.quad	280                             ; 0x118
	.quad	344                             ; 0x158
lCPI0_32:
	.quad	152                             ; 0x98
	.quad	216                             ; 0xd8
lCPI0_33:
	.quad	24                              ; 0x18
	.quad	88                              ; 0x58
lCPI0_34:
	.quad	412                             ; 0x19c
	.quad	476                             ; 0x1dc
lCPI0_35:
	.quad	284                             ; 0x11c
	.quad	348                             ; 0x15c
lCPI0_36:
	.quad	156                             ; 0x9c
	.quad	220                             ; 0xdc
lCPI0_37:
	.quad	28                              ; 0x1c
	.quad	92                              ; 0x5c
lCPI0_38:
	.quad	416                             ; 0x1a0
	.quad	480                             ; 0x1e0
lCPI0_39:
	.quad	288                             ; 0x120
	.quad	352                             ; 0x160
lCPI0_40:
	.quad	160                             ; 0xa0
	.quad	224                             ; 0xe0
lCPI0_41:
	.quad	32                              ; 0x20
	.quad	96                              ; 0x60
lCPI0_42:
	.quad	420                             ; 0x1a4
	.quad	484                             ; 0x1e4
lCPI0_43:
	.quad	292                             ; 0x124
	.quad	356                             ; 0x164
lCPI0_44:
	.quad	164                             ; 0xa4
	.quad	228                             ; 0xe4
lCPI0_45:
	.quad	36                              ; 0x24
	.quad	100                             ; 0x64
lCPI0_46:
	.quad	424                             ; 0x1a8
	.quad	488                             ; 0x1e8
lCPI0_47:
	.quad	296                             ; 0x128
	.quad	360                             ; 0x168
lCPI0_48:
	.quad	168                             ; 0xa8
	.quad	232                             ; 0xe8
lCPI0_49:
	.quad	40                              ; 0x28
	.quad	104                             ; 0x68
lCPI0_50:
	.quad	428                             ; 0x1ac
	.quad	492                             ; 0x1ec
lCPI0_51:
	.quad	300                             ; 0x12c
	.quad	364                             ; 0x16c
lCPI0_52:
	.quad	172                             ; 0xac
	.quad	236                             ; 0xec
lCPI0_53:
	.quad	44                              ; 0x2c
	.quad	108                             ; 0x6c
lCPI0_54:
	.quad	432                             ; 0x1b0
	.quad	496                             ; 0x1f0
lCPI0_55:
	.quad	304                             ; 0x130
	.quad	368                             ; 0x170
lCPI0_56:
	.quad	176                             ; 0xb0
	.quad	240                             ; 0xf0
lCPI0_57:
	.quad	48                              ; 0x30
	.quad	112                             ; 0x70
lCPI0_58:
	.quad	436                             ; 0x1b4
	.quad	500                             ; 0x1f4
lCPI0_59:
	.quad	308                             ; 0x134
	.quad	372                             ; 0x174
lCPI0_60:
	.quad	180                             ; 0xb4
	.quad	244                             ; 0xf4
lCPI0_61:
	.quad	52                              ; 0x34
	.quad	116                             ; 0x74
lCPI0_62:
	.quad	440                             ; 0x1b8
	.quad	504                             ; 0x1f8
lCPI0_63:
	.quad	312                             ; 0x138
	.quad	376                             ; 0x178
lCPI0_64:
	.quad	184                             ; 0xb8
	.quad	248                             ; 0xf8
lCPI0_65:
	.quad	56                              ; 0x38
	.quad	120                             ; 0x78
lCPI0_66:
	.quad	444                             ; 0x1bc
	.quad	508                             ; 0x1fc
lCPI0_67:
	.quad	316                             ; 0x13c
	.quad	380                             ; 0x17c
lCPI0_68:
	.quad	188                             ; 0xbc
	.quad	252                             ; 0xfc
lCPI0_69:
	.quad	60                              ; 0x3c
	.quad	124                             ; 0x7c
lCPI0_70:
	.quad	0                               ; 0x0
	.quad	5120                            ; 0x1400
lCPI0_71:
	.quad	10240                           ; 0x2800
	.quad	15360                           ; 0x3c00
lCPI0_72:
	.quad	20480                           ; 0x5000
	.quad	25600                           ; 0x6400
lCPI0_73:
	.quad	30720                           ; 0x7800
	.quad	35840                           ; 0x8c00
lCPI0_74:
	.quad	0                               ; 0x0
	.quad	6144                            ; 0x1800
lCPI0_75:
	.quad	12288                           ; 0x3000
	.quad	18432                           ; 0x4800
lCPI0_76:
	.quad	24576                           ; 0x6000
	.quad	30720                           ; 0x7800
lCPI0_77:
	.quad	36864                           ; 0x9000
	.quad	43008                           ; 0xa800
lCPI0_78:
	.quad	0                               ; 0x0
	.quad	384                             ; 0x180
lCPI0_79:
	.quad	768                             ; 0x300
	.quad	1152                            ; 0x480
lCPI0_80:
	.quad	1536                            ; 0x600
	.quad	1920                            ; 0x780
lCPI0_81:
	.quad	2304                            ; 0x900
	.quad	2688                            ; 0xa80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention.full_packet:             ; @llm_attention.full_packet
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #832
	mov	x8, #0                          ; =0x0
	ldr	x20, [x1, #136]
	add	x9, x20, #24, lsl #12           ; =98304
	add	x21, x9, #2048
	add	x9, x20, #22, lsl #12           ; =90112
	add	x9, x9, #2560
	str	x9, [sp, #3752]                 ; 8-byte Spill
	add	x9, x20, #21, lsl #12           ; =86016
	add	x9, x9, #512
	str	x9, [sp, #3744]                 ; 8-byte Spill
	add	x9, x20, #19, lsl #12           ; =77824
	add	x9, x9, #2560
	str	x9, [sp, #3736]                 ; 8-byte Spill
	add	x9, x20, #18, lsl #12           ; =73728
	add	x9, x9, #512
	str	x9, [sp, #3728]                 ; 8-byte Spill
	add	x9, x20, #16, lsl #12           ; =65536
	add	x9, x9, #2560
	str	x9, [sp, #3720]                 ; 8-byte Spill
	ldr	x9, [x0]
	ldr	x10, [x0, #16]
	str	x10, [sp, #3712]                ; 8-byte Spill
	ldr	w10, [x1]
	ldr	w11, [x1, #36]
	add	w10, w11, w10, lsl #5
	ldr	x11, [x0, #32]
	str	x11, [sp, #3704]                ; 8-byte Spill
	ldr	x11, [x0, #48]
	str	x11, [sp, #24]                  ; 8-byte Spill
	dup.4s	v0, w10
Lloh0:
	adrp	x10, lCPI0_0@PAGE
Lloh1:
	ldr	q1, [x10, lCPI0_0@PAGEOFF]
	add.4s	v3, v0, v1
Lloh2:
	adrp	x10, lCPI0_1@PAGE
Lloh3:
	ldr	q1, [x10, lCPI0_1@PAGEOFF]
	add.4s	v2, v0, v1
	ushll2.2d	v1, v2, #0
	ushll2.2d	v0, v3, #0
	stp	q0, q1, [sp, #64]               ; 32-byte Folded Spill
	ushll.2d	v1, v2, #0
	ushll.2d	v0, v3, #0
	stp	q0, q1, [sp, #32]               ; 32-byte Folded Spill
	movi.4s	v1, #80
	umull2.2d	v0, v2, v1
	umull2.2d	v1, v3, v1
	movi.2s	v4, #80
	umull.2d	v2, v2, v4
	umull.2d	v3, v3, v4
	dup.2d	v4, x9
	dup.2d	v5, x20
Lloh4:
	adrp	x9, lCPI0_2@PAGE
Lloh5:
	ldr	q6, [x9, lCPI0_2@PAGEOFF]
Lloh6:
	adrp	x9, lCPI0_3@PAGE
Lloh7:
	ldr	q7, [x9, lCPI0_3@PAGEOFF]
Lloh8:
	adrp	x9, lCPI0_4@PAGE
Lloh9:
	ldr	q16, [x9, lCPI0_4@PAGEOFF]
Lloh10:
	adrp	x9, lCPI0_5@PAGE
Lloh11:
	ldr	q17, [x9, lCPI0_5@PAGEOFF]
LBB0_1:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v18, x8
	add.2d	v19, v18, v0
	add.2d	v20, v18, v2
	add.2d	v21, v18, v1
	add.2d	v22, v18, v3
	shl.2d	v22, v22, #2
	shl.2d	v21, v21, #2
	shl.2d	v20, v20, #2
	shl.2d	v19, v19, #2
	add.2d	v19, v4, v19
	add.2d	v20, v4, v20
	add.2d	v21, v4, v21
	add.2d	v22, v4, v22
	mov.d	x9, v22[1]
	fmov	x10, d22
	ldr	s22, [x10]
	mov.d	x10, v21[1]
	ldr	s23, [x9]
	fmov	x9, d21
	ldr	s21, [x9]
	ldr	s24, [x10]
	mov.d	x9, v20[1]
	fmov	x10, d20
	ldr	s20, [x10]
	ldr	s25, [x9]
	mov.d	x9, v19[1]
	fmov	x10, d19
	ldr	s19, [x10]
	ldr	s26, [x9]
	shl.2d	v18, v18, #2
	add.2d	v18, v18, v5
	add.2d	v27, v18, v17
	add.2d	v28, v18, v16
	add.2d	v29, v18, v7
	add.2d	v18, v18, v6
	mov.d	x9, v18[1]
	fmov	x10, d18
	str	s22, [x10]
	str	s23, [x9]
	mov.d	x9, v29[1]
	fmov	x10, d29
	str	s21, [x10]
	str	s24, [x9]
	mov.d	x9, v28[1]
	fmov	x10, d28
	str	s20, [x10]
	mov.d	x10, v27[1]
	str	s25, [x9]
	fmov	x9, d27
	str	s19, [x9]
	str	s26, [x10]
	add	x8, x8, #1
	cmp	x8, #80
	b.ne	LBB0_1
; %bb.2:                                ; %direct.true131.preheader
	add	x8, x20, #2560
	str	x8, [sp, #16]                   ; 8-byte Spill
	add	x0, x20, #2560
	mov	w1, #3072                       ; =0xc00
	bl	_bzero
	str	xzr, [sp, #4848]                ; 8-byte Spill
	mov	w8, #5632                       ; =0x1600
	add	x8, x20, x8
	str	x8, [sp, #4840]                 ; 8-byte Spill
	mov	w8, #8704                       ; =0x2200
	add	x8, x20, x8
	str	x8, [sp, #3696]                 ; 8-byte Spill
	mov	w8, #49664                      ; =0xc200
	add	x8, x20, x8
	str	x8, [sp, #3688]                 ; 8-byte Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x9, x8, #512
	add	x8, x20, #24, lsl #12           ; =98304
	add	x17, x8, #1024
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #2560
	str	x8, [sp, #3664]                 ; 8-byte Spill
	add	x8, x20, #25, lsl #12           ; =102400
	add	x8, x8, #1536
	str	x8, [sp, #3656]                 ; 8-byte Spill
	ldp	q2, q0, [sp, #64]               ; 32-byte Folded Reload
	shrn.2s	v1, v0, #2
	ldp	q4, q0, [sp, #32]               ; 32-byte Folded Reload
	shrn.2s	v0, v0, #2
	shrn.2s	v2, v2, #2
	mov	w8, #2053                       ; =0x805
	dup.2s	v3, w8
	shrn.2s	v4, v4, #2
	umull.2d	v4, v4, v3
	str	q4, [sp, #3632]                 ; 16-byte Spill
	umull.2d	v2, v2, v3
	str	q2, [sp, #3616]                 ; 16-byte Spill
	umull.2d	v0, v0, v3
	str	q0, [sp, #3600]                 ; 16-byte Spill
	str	x9, [sp, #3680]                 ; 8-byte Spill
	dup.2d	v0, x9
	umull.2d	v1, v1, v3
	str	q1, [sp, #3584]                 ; 16-byte Spill
Lloh12:
	adrp	x8, lCPI0_6@PAGE
Lloh13:
	ldr	q31, [x8, lCPI0_6@PAGEOFF]
	add.2d	v1, v0, v31
	str	q1, [sp, #3552]                 ; 16-byte Spill
Lloh14:
	adrp	x8, lCPI0_7@PAGE
Lloh15:
	ldr	q3, [x8, lCPI0_7@PAGEOFF]
	add.2d	v1, v0, v3
	str	q1, [sp, #3520]                 ; 16-byte Spill
Lloh16:
	adrp	x8, lCPI0_8@PAGE
Lloh17:
	ldr	q29, [x8, lCPI0_8@PAGEOFF]
	add.2d	v1, v0, v29
	str	q1, [sp, #3488]                 ; 16-byte Spill
Lloh18:
	adrp	x8, lCPI0_9@PAGE
Lloh19:
	ldr	q27, [x8, lCPI0_9@PAGEOFF]
	add.2d	v1, v0, v27
	str	q1, [sp, #3456]                 ; 16-byte Spill
Lloh20:
	adrp	x8, lCPI0_10@PAGE
Lloh21:
	ldr	q16, [x8, lCPI0_10@PAGEOFF]
	add.2d	v1, v0, v16
	str	q1, [sp, #3440]                 ; 16-byte Spill
Lloh22:
	adrp	x8, lCPI0_11@PAGE
Lloh23:
	ldr	q4, [x8, lCPI0_11@PAGEOFF]
	add.2d	v1, v0, v4
	str	q1, [sp, #3424]                 ; 16-byte Spill
Lloh24:
	adrp	x8, lCPI0_12@PAGE
Lloh25:
	ldr	q6, [x8, lCPI0_12@PAGEOFF]
	add.2d	v1, v0, v6
	str	q1, [sp, #3408]                 ; 16-byte Spill
Lloh26:
	adrp	x8, lCPI0_13@PAGE
Lloh27:
	ldr	q5, [x8, lCPI0_13@PAGEOFF]
	add.2d	v1, v0, v5
	str	q1, [sp, #3392]                 ; 16-byte Spill
Lloh28:
	adrp	x8, lCPI0_14@PAGE
Lloh29:
	ldr	q18, [x8, lCPI0_14@PAGEOFF]
	add.2d	v1, v0, v18
	str	q1, [sp, #3376]                 ; 16-byte Spill
Lloh30:
	adrp	x8, lCPI0_15@PAGE
Lloh31:
	ldr	q7, [x8, lCPI0_15@PAGEOFF]
	add.2d	v1, v0, v7
	str	q1, [sp, #3360]                 ; 16-byte Spill
Lloh32:
	adrp	x8, lCPI0_16@PAGE
Lloh33:
	ldr	q17, [x8, lCPI0_16@PAGEOFF]
	add.2d	v1, v0, v17
	str	q1, [sp, #3344]                 ; 16-byte Spill
Lloh34:
	adrp	x8, lCPI0_17@PAGE
Lloh35:
	ldr	q1, [x8, lCPI0_17@PAGEOFF]
	str	q1, [sp, #4416]                 ; 16-byte Spill
	add.2d	v1, v0, v1
	str	q1, [sp, #3328]                 ; 16-byte Spill
Lloh36:
	adrp	x8, lCPI0_18@PAGE
Lloh37:
	ldr	q1, [x8, lCPI0_18@PAGEOFF]
	str	q1, [sp, #4400]                 ; 16-byte Spill
	add.2d	v1, v0, v1
	str	q1, [sp, #3312]                 ; 16-byte Spill
Lloh38:
	adrp	x8, lCPI0_19@PAGE
Lloh39:
	ldr	q21, [x8, lCPI0_19@PAGEOFF]
Lloh40:
	adrp	x28, lCPI0_45@PAGE
Lloh41:
	adrp	x30, lCPI0_46@PAGE
Lloh42:
	adrp	x26, lCPI0_47@PAGE
Lloh43:
	adrp	x25, lCPI0_48@PAGE
Lloh44:
	adrp	x24, lCPI0_49@PAGE
Lloh45:
	adrp	x23, lCPI0_50@PAGE
Lloh46:
	adrp	x22, lCPI0_51@PAGE
Lloh47:
	adrp	x19, lCPI0_52@PAGE
Lloh48:
	adrp	x7, lCPI0_53@PAGE
Lloh49:
	adrp	x6, lCPI0_54@PAGE
Lloh50:
	adrp	x5, lCPI0_55@PAGE
Lloh51:
	adrp	x4, lCPI0_56@PAGE
Lloh52:
	adrp	x3, lCPI0_57@PAGE
Lloh53:
	adrp	x2, lCPI0_58@PAGE
Lloh54:
	adrp	x1, lCPI0_59@PAGE
Lloh55:
	adrp	x0, lCPI0_60@PAGE
Lloh56:
	adrp	x16, lCPI0_61@PAGE
Lloh57:
	adrp	x15, lCPI0_62@PAGE
Lloh58:
	adrp	x14, lCPI0_63@PAGE
Lloh59:
	adrp	x13, lCPI0_64@PAGE
Lloh60:
	adrp	x12, lCPI0_65@PAGE
Lloh61:
	adrp	x11, lCPI0_66@PAGE
Lloh62:
	adrp	x10, lCPI0_67@PAGE
Lloh63:
	adrp	x9, lCPI0_68@PAGE
Lloh64:
	adrp	x8, lCPI0_69@PAGE
	add.2d	v1, v0, v21
	str	q1, [sp, #3296]                 ; 16-byte Spill
Lloh65:
	adrp	x27, lCPI0_20@PAGE
Lloh66:
	ldr	q1, [x27, lCPI0_20@PAGEOFF]
	str	q1, [sp, #4336]                 ; 16-byte Spill
	add.2d	v1, v0, v1
	str	q1, [sp, #3280]                 ; 16-byte Spill
Lloh67:
	adrp	x27, lCPI0_21@PAGE
Lloh68:
	ldr	q1, [x27, lCPI0_21@PAGEOFF]
	str	q1, [sp, #4320]                 ; 16-byte Spill
	add.2d	v1, v0, v1
	str	q1, [sp, #3264]                 ; 16-byte Spill
Lloh69:
	adrp	x27, lCPI0_22@PAGE
Lloh70:
	ldr	q1, [x27, lCPI0_22@PAGEOFF]
	str	q1, [sp, #4304]                 ; 16-byte Spill
	add.2d	v1, v0, v1
	str	q1, [sp, #3248]                 ; 16-byte Spill
Lloh71:
	adrp	x27, lCPI0_23@PAGE
Lloh72:
	ldr	q15, [x27, lCPI0_23@PAGEOFF]
	add.2d	v1, v0, v15
	str	q15, [sp, #1568]                ; 16-byte Spill
	str	q1, [sp, #3232]                 ; 16-byte Spill
Lloh73:
	adrp	x27, lCPI0_24@PAGE
Lloh74:
	ldr	q25, [x27, lCPI0_24@PAGEOFF]
	add.2d	v1, v0, v25
	str	q25, [sp, #1552]                ; 16-byte Spill
	str	q1, [sp, #3216]                 ; 16-byte Spill
Lloh75:
	adrp	x27, lCPI0_25@PAGE
Lloh76:
	ldr	q1, [x27, lCPI0_25@PAGEOFF]
	str	q1, [sp, #4288]                 ; 16-byte Spill
	add.2d	v1, v0, v1
	str	q1, [sp, #3200]                 ; 16-byte Spill
Lloh77:
	adrp	x27, lCPI0_26@PAGE
Lloh78:
	ldr	q9, [x27, lCPI0_26@PAGEOFF]
	add.2d	v1, v0, v9
	str	q9, [sp, #1520]                 ; 16-byte Spill
	str	q1, [sp, #3184]                 ; 16-byte Spill
Lloh79:
	adrp	x27, lCPI0_27@PAGE
Lloh80:
	ldr	q1, [x27, lCPI0_27@PAGEOFF]
	str	q1, [sp, #4272]                 ; 16-byte Spill
	add.2d	v1, v0, v1
	str	q1, [sp, #3168]                 ; 16-byte Spill
Lloh81:
	adrp	x27, lCPI0_28@PAGE
Lloh82:
	ldr	q1, [x27, lCPI0_28@PAGEOFF]
	str	q1, [sp, #1488]                 ; 16-byte Spill
	add.2d	v1, v0, v1
	str	q1, [sp, #3152]                 ; 16-byte Spill
Lloh83:
	adrp	x27, lCPI0_29@PAGE
Lloh84:
	ldr	q11, [x27, lCPI0_29@PAGEOFF]
	add.2d	v1, v0, v11
	str	q11, [sp, #1472]                ; 16-byte Spill
	str	q1, [sp, #3136]                 ; 16-byte Spill
Lloh85:
	adrp	x27, lCPI0_30@PAGE
Lloh86:
	ldr	q1, [x27, lCPI0_30@PAGEOFF]
	str	q1, [sp, #1456]                 ; 16-byte Spill
	add.2d	v1, v0, v1
	str	q1, [sp, #3120]                 ; 16-byte Spill
Lloh87:
	adrp	x27, lCPI0_31@PAGE
Lloh88:
	ldr	q1, [x27, lCPI0_31@PAGEOFF]
	str	q1, [sp, #1440]                 ; 16-byte Spill
	add.2d	v1, v0, v1
	str	q1, [sp, #3104]                 ; 16-byte Spill
Lloh89:
	adrp	x27, lCPI0_32@PAGE
Lloh90:
	ldr	q1, [x27, lCPI0_32@PAGEOFF]
	str	q1, [sp, #1424]                 ; 16-byte Spill
	add.2d	v1, v0, v1
	str	q1, [sp, #3088]                 ; 16-byte Spill
Lloh91:
	adrp	x27, lCPI0_33@PAGE
Lloh92:
	ldr	q1, [x27, lCPI0_33@PAGEOFF]
	str	q1, [sp, #1408]                 ; 16-byte Spill
	add.2d	v1, v0, v1
	str	q1, [sp, #3072]                 ; 16-byte Spill
Lloh93:
	adrp	x27, lCPI0_34@PAGE
Lloh94:
	ldr	q1, [x27, lCPI0_34@PAGEOFF]
	str	q1, [sp, #1392]                 ; 16-byte Spill
	add.2d	v24, v0, v1
	str	q24, [sp, #3056]                ; 16-byte Spill
Lloh95:
	adrp	x27, lCPI0_35@PAGE
Lloh96:
	ldr	q1, [x27, lCPI0_35@PAGEOFF]
	str	q1, [sp, #4592]                 ; 16-byte Spill
	add.2d	v24, v0, v1
	str	q24, [sp, #3040]                ; 16-byte Spill
Lloh97:
	adrp	x27, lCPI0_36@PAGE
Lloh98:
	ldr	q1, [x27, lCPI0_36@PAGEOFF]
	str	q1, [sp, #4528]                 ; 16-byte Spill
	add.2d	v26, v0, v1
	str	q26, [sp, #3024]                ; 16-byte Spill
Lloh99:
	adrp	x27, lCPI0_37@PAGE
Lloh100:
	ldr	q1, [x27, lCPI0_37@PAGEOFF]
	str	q1, [sp, #1312]                 ; 16-byte Spill
	add.2d	v26, v0, v1
	str	q26, [sp, #3008]                ; 16-byte Spill
Lloh101:
	adrp	x27, lCPI0_38@PAGE
Lloh102:
	ldr	q1, [x27, lCPI0_38@PAGEOFF]
	str	q1, [sp, #4432]                 ; 16-byte Spill
	add.2d	v28, v0, v1
	str	q28, [sp, #2992]                ; 16-byte Spill
Lloh103:
	adrp	x27, lCPI0_39@PAGE
Lloh104:
	ldr	q1, [x27, lCPI0_39@PAGEOFF]
	str	q1, [sp, #4688]                 ; 16-byte Spill
	add.2d	v28, v0, v1
	str	q28, [sp, #2976]                ; 16-byte Spill
Lloh105:
	adrp	x27, lCPI0_40@PAGE
Lloh106:
	ldr	q1, [x27, lCPI0_40@PAGEOFF]
	str	q1, [sp, #4656]                 ; 16-byte Spill
	add.2d	v30, v0, v1
	str	q30, [sp, #2960]                ; 16-byte Spill
Lloh107:
	adrp	x27, lCPI0_41@PAGE
Lloh108:
	ldr	q1, [x27, lCPI0_41@PAGEOFF]
	str	q1, [sp, #1216]                 ; 16-byte Spill
	add.2d	v30, v0, v1
	str	q30, [sp, #2944]                ; 16-byte Spill
Lloh109:
	adrp	x27, lCPI0_42@PAGE
Lloh110:
	ldr	q1, [x27, lCPI0_42@PAGEOFF]
	str	q1, [sp, #4448]                 ; 16-byte Spill
	add.2d	v8, v0, v1
	str	q8, [sp, #2928]                 ; 16-byte Spill
Lloh111:
	adrp	x27, lCPI0_43@PAGE
Lloh112:
	ldr	q1, [x27, lCPI0_43@PAGEOFF]
	str	q1, [sp, #4784]                 ; 16-byte Spill
	add.2d	v8, v0, v1
	str	q8, [sp, #2912]                 ; 16-byte Spill
Lloh113:
	adrp	x27, lCPI0_44@PAGE
Lloh114:
	ldr	q1, [x27, lCPI0_44@PAGEOFF]
	str	q1, [sp, #4768]                 ; 16-byte Spill
	add.2d	v10, v0, v1
	str	q10, [sp, #2896]                ; 16-byte Spill
Lloh115:
	ldr	q1, [x28, lCPI0_45@PAGEOFF]
	str	q1, [sp, #4816]                 ; 16-byte Spill
	add.2d	v10, v0, v1
	str	q10, [sp, #2880]                ; 16-byte Spill
Lloh116:
	ldr	q1, [x30, lCPI0_46@PAGEOFF]
	str	q1, [sp, #4800]                 ; 16-byte Spill
	add.2d	v12, v0, v1
	str	q12, [sp, #2864]                ; 16-byte Spill
Lloh117:
	ldr	q1, [x26, lCPI0_47@PAGEOFF]
	str	q1, [sp, #4880]                 ; 16-byte Spill
	add.2d	v12, v0, v1
	str	q12, [sp, #2848]                ; 16-byte Spill
Lloh118:
	ldr	q1, [x25, lCPI0_48@PAGEOFF]
	str	q1, [sp, #4864]                 ; 16-byte Spill
	add.2d	v13, v0, v1
	str	q13, [sp, #2832]                ; 16-byte Spill
Lloh119:
	ldr	q1, [x24, lCPI0_49@PAGEOFF]
	str	q1, [sp, #4912]                 ; 16-byte Spill
	add.2d	v14, v0, v1
	str	q14, [sp, #2816]                ; 16-byte Spill
Lloh120:
	ldr	q1, [x23, lCPI0_50@PAGEOFF]
	str	q1, [sp, #4896]                 ; 16-byte Spill
	add.2d	v13, v0, v1
	str	q13, [sp, #2800]                ; 16-byte Spill
Lloh121:
	ldr	q1, [x22, lCPI0_51@PAGEOFF]
	str	q1, [sp, #4752]                 ; 16-byte Spill
	add.2d	v13, v0, v1
	str	q13, [sp, #2784]                ; 16-byte Spill
Lloh122:
	ldr	q1, [x19, lCPI0_52@PAGEOFF]
	str	q1, [sp, #4736]                 ; 16-byte Spill
	add.2d	v13, v0, v1
	str	q13, [sp, #2768]                ; 16-byte Spill
Lloh123:
	ldr	q1, [x7, lCPI0_53@PAGEOFF]
	str	q1, [sp, #4720]                 ; 16-byte Spill
	add.2d	v13, v0, v1
	str	q13, [sp, #2752]                ; 16-byte Spill
Lloh124:
	ldr	q1, [x6, lCPI0_54@PAGEOFF]
	str	q1, [sp, #4704]                 ; 16-byte Spill
	add.2d	v13, v0, v1
	str	q13, [sp, #2736]                ; 16-byte Spill
Lloh125:
	ldr	q1, [x5, lCPI0_55@PAGEOFF]
	str	q1, [sp, #4672]                 ; 16-byte Spill
	add.2d	v13, v0, v1
	str	q13, [sp, #2720]                ; 16-byte Spill
Lloh126:
	ldr	q1, [x4, lCPI0_56@PAGEOFF]
	str	q1, [sp, #4640]                 ; 16-byte Spill
	add.2d	v13, v0, v1
	str	q13, [sp, #2704]                ; 16-byte Spill
Lloh127:
	ldr	q1, [x3, lCPI0_57@PAGEOFF]
	str	q1, [sp, #4624]                 ; 16-byte Spill
	add.2d	v13, v0, v1
	str	q13, [sp, #2688]                ; 16-byte Spill
Lloh128:
	ldr	q1, [x2, lCPI0_58@PAGEOFF]
	str	q1, [sp, #4608]                 ; 16-byte Spill
	add.2d	v13, v0, v1
	str	q13, [sp, #2672]                ; 16-byte Spill
Lloh129:
	ldr	q1, [x1, lCPI0_59@PAGEOFF]
	str	q1, [sp, #4576]                 ; 16-byte Spill
	add.2d	v13, v0, v1
	str	q13, [sp, #2656]                ; 16-byte Spill
Lloh130:
	ldr	q1, [x0, lCPI0_60@PAGEOFF]
	str	q1, [sp, #4560]                 ; 16-byte Spill
	add.2d	v13, v0, v1
	str	q13, [sp, #2640]                ; 16-byte Spill
Lloh131:
	ldr	q8, [x16, lCPI0_61@PAGEOFF]
	add.2d	v13, v0, v8
	str	q8, [sp, #4368]                 ; 16-byte Spill
	str	q13, [sp, #2624]                ; 16-byte Spill
Lloh132:
	ldr	q22, [x15, lCPI0_62@PAGEOFF]
	add.2d	v13, v0, v22
	str	q22, [sp, #4352]                ; 16-byte Spill
	str	q13, [sp, #2608]                ; 16-byte Spill
Lloh133:
	ldr	q1, [x14, lCPI0_63@PAGEOFF]
	str	q1, [sp, #4544]                 ; 16-byte Spill
	add.2d	v13, v0, v1
	str	q13, [sp, #2592]                ; 16-byte Spill
Lloh134:
	ldr	q1, [x13, lCPI0_64@PAGEOFF]
	str	q1, [sp, #4512]                 ; 16-byte Spill
	add.2d	v13, v0, v1
	str	q13, [sp, #2576]                ; 16-byte Spill
Lloh135:
	ldr	q1, [x12, lCPI0_65@PAGEOFF]
	str	q1, [sp, #4496]                 ; 16-byte Spill
	add.2d	v13, v0, v1
	str	q13, [sp, #2560]                ; 16-byte Spill
Lloh136:
	ldr	q1, [x11, lCPI0_66@PAGEOFF]
	str	q1, [sp, #4480]                 ; 16-byte Spill
	add.2d	v13, v0, v1
	str	q13, [sp, #2544]                ; 16-byte Spill
Lloh137:
	ldr	q1, [x10, lCPI0_67@PAGEOFF]
	str	q1, [sp, #4464]                 ; 16-byte Spill
	add.2d	v13, v0, v1
	str	q13, [sp, #2528]                ; 16-byte Spill
Lloh138:
	ldr	q23, [x9, lCPI0_68@PAGEOFF]
	add.2d	v13, v0, v23
	str	q23, [sp, #4384]                ; 16-byte Spill
	str	q13, [sp, #2512]                ; 16-byte Spill
Lloh139:
	ldr	q1, [x8, lCPI0_69@PAGEOFF]
	str	q1, [sp, #608]                  ; 16-byte Spill
	add.2d	v0, v0, v1
	str	q0, [sp, #2496]                 ; 16-byte Spill
	mov	w8, #13824                      ; =0x3600
	add	x4, x20, x8
	add	x8, x20, #24, lsl #12           ; =98304
	add	x5, x8, #576
	add	x8, x20, #24, lsl #12           ; =98304
	add	x6, x8, #1088
	mov	w8, #18944                      ; =0x4a00
	add	x7, x20, x8
	add	x8, x20, #24, lsl #12           ; =98304
	add	x30, x8, #640
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1152
	str	x8, [sp, #2448]                 ; 8-byte Spill
	mov	w8, #24064                      ; =0x5e00
	add	x8, x20, x8
	str	x8, [sp, #2440]                 ; 8-byte Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #704
	str	x8, [sp, #2432]                 ; 8-byte Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1216
	str	x8, [sp, #2424]                 ; 8-byte Spill
	mov	w8, #29184                      ; =0x7200
	add	x8, x20, x8
	str	x8, [sp, #2416]                 ; 8-byte Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #768
	str	x8, [sp, #2408]                 ; 8-byte Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1280
	str	x8, [sp, #2400]                 ; 8-byte Spill
	mov	w8, #34304                      ; =0x8600
	add	x8, x20, x8
	str	x8, [sp, #2392]                 ; 8-byte Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #832
	str	x8, [sp, #2384]                 ; 8-byte Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1344
	str	x8, [sp, #2376]                 ; 8-byte Spill
	mov	w8, #39424                      ; =0x9a00
	add	x8, x20, x8
	str	x8, [sp, #2368]                 ; 8-byte Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #896
	str	x8, [sp, #2360]                 ; 8-byte Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1408
	str	x8, [sp, #2352]                 ; 8-byte Spill
	mov	w8, #44544                      ; =0xae00
	add	x8, x20, x8
	str	x8, [sp, #2344]                 ; 8-byte Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #960
	str	x8, [sp, #2336]                 ; 8-byte Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1472
	str	x8, [sp, #2328]                 ; 8-byte Spill
	str	x17, [sp, #3672]                ; 8-byte Spill
	dup.2d	v0, x17
	add.2d	v13, v0, v31
	str	q13, [sp, #2304]                ; 16-byte Spill
	mov.16b	v30, v3
	add.2d	v1, v0, v3
	str	q1, [sp, #4256]                 ; 16-byte Spill
	add.2d	v13, v0, v29
	str	q13, [sp, #2288]                ; 16-byte Spill
	add.2d	v1, v0, v27
	str	q1, [sp, #4240]                 ; 16-byte Spill
	add.2d	v13, v0, v16
	str	q13, [sp, #2272]                ; 16-byte Spill
	mov.16b	v1, v4
	add.2d	v2, v0, v4
	str	q2, [sp, #4224]                 ; 16-byte Spill
	add.2d	v13, v0, v6
	str	q13, [sp, #2256]                ; 16-byte Spill
	mov.16b	v2, v5
	add.2d	v3, v0, v5
	str	q3, [sp, #4208]                 ; 16-byte Spill
	add.2d	v13, v0, v18
	str	q13, [sp, #2240]                ; 16-byte Spill
	mov.16b	v3, v7
	add.2d	v4, v0, v7
	str	q4, [sp, #4192]                 ; 16-byte Spill
	mov.16b	v7, v17
	add.2d	v13, v0, v17
	str	q13, [sp, #2224]                ; 16-byte Spill
	ldr	q4, [sp, #4416]                 ; 16-byte Reload
	add.2d	v5, v0, v4
	str	q5, [sp, #4176]                 ; 16-byte Spill
	ldr	q17, [sp, #4400]                ; 16-byte Reload
	add.2d	v13, v0, v17
	str	q13, [sp, #2208]                ; 16-byte Spill
	mov.16b	v5, v21
	add.2d	v13, v0, v21
	str	q13, [sp, #4160]                ; 16-byte Spill
	ldr	q19, [sp, #4336]                ; 16-byte Reload
	add.2d	v13, v0, v19
	str	q13, [sp, #2192]                ; 16-byte Spill
	ldr	q20, [sp, #4320]                ; 16-byte Reload
	add.2d	v13, v0, v20
	str	q13, [sp, #4144]                ; 16-byte Spill
	ldr	q21, [sp, #4304]                ; 16-byte Reload
	add.2d	v13, v0, v21
	str	q13, [sp, #2176]                ; 16-byte Spill
	add.2d	v13, v0, v15
	str	q13, [sp, #4128]                ; 16-byte Spill
	add.2d	v13, v0, v25
	str	q13, [sp, #2160]                ; 16-byte Spill
	ldr	q24, [sp, #4288]                ; 16-byte Reload
	add.2d	v13, v0, v24
	str	q13, [sp, #4112]                ; 16-byte Spill
	add.2d	v13, v0, v9
	str	q13, [sp, #2144]                ; 16-byte Spill
	ldr	q25, [sp, #4272]                ; 16-byte Reload
	add.2d	v13, v0, v25
	str	q13, [sp, #4096]                ; 16-byte Spill
	ldr	q26, [sp, #1488]                ; 16-byte Reload
	add.2d	v13, v0, v26
	str	q13, [sp, #2128]                ; 16-byte Spill
	add.2d	v13, v0, v11
	str	q13, [sp, #4080]                ; 16-byte Spill
	ldr	q9, [sp, #1456]                 ; 16-byte Reload
	add.2d	v13, v0, v9
	str	q13, [sp, #2112]                ; 16-byte Spill
	ldr	q10, [sp, #1440]                ; 16-byte Reload
	add.2d	v13, v0, v10
	str	q13, [sp, #4064]                ; 16-byte Spill
	ldr	q11, [sp, #1424]                ; 16-byte Reload
	add.2d	v13, v0, v11
	str	q13, [sp, #2096]                ; 16-byte Spill
	ldr	q12, [sp, #1408]                ; 16-byte Reload
	add.2d	v13, v0, v12
	str	q13, [sp, #4048]                ; 16-byte Spill
	ldr	q14, [sp, #1392]                ; 16-byte Reload
	add.2d	v13, v0, v14
	str	q13, [sp, #2080]                ; 16-byte Spill
	ldr	q28, [sp, #4592]                ; 16-byte Reload
	add.2d	v13, v0, v28
	str	q13, [sp, #4032]                ; 16-byte Spill
	ldr	q28, [sp, #4528]                ; 16-byte Reload
	add.2d	v13, v0, v28
	str	q13, [sp, #2064]                ; 16-byte Spill
	ldr	q15, [sp, #1312]                ; 16-byte Reload
	add.2d	v13, v0, v15
	str	q13, [sp, #4016]                ; 16-byte Spill
	ldr	q28, [sp, #4432]                ; 16-byte Reload
	add.2d	v13, v0, v28
	str	q13, [sp, #2048]                ; 16-byte Spill
	ldr	q28, [sp, #4688]                ; 16-byte Reload
	add.2d	v13, v0, v28
	str	q13, [sp, #4000]                ; 16-byte Spill
	ldr	q28, [sp, #4656]                ; 16-byte Reload
	add.2d	v13, v0, v28
	str	q13, [sp, #2032]                ; 16-byte Spill
	ldr	q28, [sp, #1216]                ; 16-byte Reload
	add.2d	v13, v0, v28
	str	q13, [sp, #3984]                ; 16-byte Spill
	ldr	q13, [sp, #4448]                ; 16-byte Reload
	add.2d	v13, v0, v13
	str	q13, [sp, #2016]                ; 16-byte Spill
	ldr	q13, [sp, #4784]                ; 16-byte Reload
	add.2d	v13, v0, v13
	str	q13, [sp, #3968]                ; 16-byte Spill
	ldr	q13, [sp, #4768]                ; 16-byte Reload
	add.2d	v13, v0, v13
	str	q13, [sp, #2000]                ; 16-byte Spill
	ldr	q13, [sp, #4816]                ; 16-byte Reload
	add.2d	v13, v0, v13
	str	q13, [sp, #3952]                ; 16-byte Spill
	ldr	q13, [sp, #4800]                ; 16-byte Reload
	add.2d	v13, v0, v13
	str	q13, [sp, #1984]                ; 16-byte Spill
	ldr	q13, [sp, #4880]                ; 16-byte Reload
	add.2d	v13, v0, v13
	str	q13, [sp, #3936]                ; 16-byte Spill
	ldr	q13, [sp, #4864]                ; 16-byte Reload
	add.2d	v13, v0, v13
	str	q13, [sp, #1968]                ; 16-byte Spill
	ldr	q13, [sp, #4912]                ; 16-byte Reload
	add.2d	v13, v0, v13
	str	q13, [sp, #3920]                ; 16-byte Spill
	ldr	q13, [sp, #4896]                ; 16-byte Reload
	add.2d	v13, v0, v13
	str	q13, [sp, #1952]                ; 16-byte Spill
	ldr	q13, [sp, #4752]                ; 16-byte Reload
	add.2d	v13, v0, v13
	str	q13, [sp, #3904]                ; 16-byte Spill
	ldr	q13, [sp, #4736]                ; 16-byte Reload
	add.2d	v13, v0, v13
	str	q13, [sp, #1936]                ; 16-byte Spill
	ldr	q13, [sp, #4720]                ; 16-byte Reload
	add.2d	v13, v0, v13
	str	q13, [sp, #3888]                ; 16-byte Spill
	ldr	q13, [sp, #4704]                ; 16-byte Reload
	add.2d	v13, v0, v13
	str	q13, [sp, #1920]                ; 16-byte Spill
	ldr	q13, [sp, #4672]                ; 16-byte Reload
	add.2d	v13, v0, v13
	str	q13, [sp, #3872]                ; 16-byte Spill
	ldr	q13, [sp, #4640]                ; 16-byte Reload
	add.2d	v13, v0, v13
	str	q13, [sp, #1904]                ; 16-byte Spill
	ldr	q13, [sp, #4624]                ; 16-byte Reload
	add.2d	v13, v0, v13
	str	q13, [sp, #3856]                ; 16-byte Spill
	ldr	q13, [sp, #4608]                ; 16-byte Reload
	add.2d	v13, v0, v13
	str	q13, [sp, #1888]                ; 16-byte Spill
	ldr	q13, [sp, #4576]                ; 16-byte Reload
	add.2d	v13, v0, v13
	str	q13, [sp, #3840]                ; 16-byte Spill
	ldr	q13, [sp, #4560]                ; 16-byte Reload
	add.2d	v13, v0, v13
	str	q13, [sp, #1872]                ; 16-byte Spill
	add.2d	v8, v0, v8
	str	q8, [sp, #3824]                 ; 16-byte Spill
	add.2d	v13, v0, v22
	str	q13, [sp, #1856]                ; 16-byte Spill
	ldr	q22, [sp, #4544]                ; 16-byte Reload
	add.2d	v22, v0, v22
	str	q22, [sp, #3808]                ; 16-byte Spill
	ldr	q22, [sp, #4512]                ; 16-byte Reload
	add.2d	v13, v0, v22
	str	q13, [sp, #1840]                ; 16-byte Spill
	ldr	q22, [sp, #4496]                ; 16-byte Reload
	add.2d	v22, v0, v22
	str	q22, [sp, #3792]                ; 16-byte Spill
	ldr	q22, [sp, #4480]                ; 16-byte Reload
	add.2d	v13, v0, v22
	str	q13, [sp, #1824]                ; 16-byte Spill
	ldr	q22, [sp, #4464]                ; 16-byte Reload
	add.2d	v22, v0, v22
	str	q22, [sp, #3776]                ; 16-byte Spill
	add.2d	v13, v0, v23
	str	q13, [sp, #1808]                ; 16-byte Spill
	ldr	q8, [sp, #608]                  ; 16-byte Reload
	add.2d	v0, v0, v8
	str	q0, [sp, #3760]                 ; 16-byte Spill
	dup.2d	v0, x21
	add.2d	v13, v0, v16
	str	q13, [sp, #1776]                ; 16-byte Spill
	add.2d	v13, v0, v1
	str	q13, [sp, #1760]                ; 16-byte Spill
	add.2d	v13, v0, v6
	str	q13, [sp, #1744]                ; 16-byte Spill
	add.2d	v13, v0, v2
	str	q13, [sp, #1728]                ; 16-byte Spill
	add.2d	v13, v0, v18
	str	q13, [sp, #1712]                ; 16-byte Spill
	add.2d	v13, v0, v3
	str	q13, [sp, #1696]                ; 16-byte Spill
	add.2d	v13, v0, v7
	str	q13, [sp, #1680]                ; 16-byte Spill
	add.2d	v13, v0, v4
	str	q13, [sp, #1664]                ; 16-byte Spill
	add.2d	v13, v0, v17
	str	q13, [sp, #1648]                ; 16-byte Spill
	add.2d	v13, v0, v5
	str	q13, [sp, #1632]                ; 16-byte Spill
	add.2d	v23, v0, v19
	str	q23, [sp, #1616]                ; 16-byte Spill
	mov.16b	v23, v27
	add.2d	v22, v0, v20
	str	q22, [sp, #1600]                ; 16-byte Spill
	mov.16b	v22, v29
	add.2d	v21, v0, v21
	str	q21, [sp, #1584]                ; 16-byte Spill
	mov.16b	v21, v30
	ldr	q1, [sp, #1568]                 ; 16-byte Reload
	add.2d	v20, v0, v1
	str	q20, [sp, #1568]                ; 16-byte Spill
	mov.16b	v20, v31
	ldr	q1, [sp, #1552]                 ; 16-byte Reload
	add.2d	v19, v0, v1
	str	q19, [sp, #1552]                ; 16-byte Spill
	add.2d	v18, v0, v24
	str	q18, [sp, #1536]                ; 16-byte Spill
	ldr	q1, [sp, #1520]                 ; 16-byte Reload
	add.2d	v17, v0, v1
	str	q17, [sp, #1520]                ; 16-byte Spill
	add.2d	v16, v0, v25
	str	q16, [sp, #1504]                ; 16-byte Spill
	add.2d	v7, v0, v26
	str	q7, [sp, #1488]                 ; 16-byte Spill
	ldr	q1, [sp, #1472]                 ; 16-byte Reload
	add.2d	v6, v0, v1
	str	q6, [sp, #1472]                 ; 16-byte Spill
	add.2d	v5, v0, v9
	str	q5, [sp, #1456]                 ; 16-byte Spill
	add.2d	v4, v0, v10
	str	q4, [sp, #1440]                 ; 16-byte Spill
	add.2d	v3, v0, v11
	str	q3, [sp, #1424]                 ; 16-byte Spill
	add.2d	v2, v0, v12
	str	q2, [sp, #1408]                 ; 16-byte Spill
	add.2d	v1, v0, v14
	str	q1, [sp, #1392]                 ; 16-byte Spill
	mov	w8, #55808                      ; =0xda00
	add	x8, x20, x8
	str	x8, [sp, #1384]                 ; 8-byte Spill
	ldr	q1, [sp, #4592]                 ; 16-byte Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #1360]                 ; 16-byte Spill
	ldr	q1, [sp, #4528]                 ; 16-byte Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #1344]                 ; 16-byte Spill
	mov.16b	v18, v0
	mov	w8, #61952                      ; =0xf200
	add	x8, x20, x8
	str	x8, [sp, #1336]                 ; 8-byte Spill
	mov	w8, #8720                       ; =0x2210
	add	x8, x20, x8
	str	x8, [sp, #1328]                 ; 8-byte Spill
	add.2d	v0, v0, v15
	str	q0, [sp, #1312]                 ; 16-byte Spill
	ldr	q0, [sp, #4432]                 ; 16-byte Reload
	add.2d	v0, v18, v0
	str	q0, [sp, #1296]                 ; 16-byte Spill
	mov	w8, #13840                      ; =0x3610
	add	x8, x20, x8
	str	x8, [sp, #1288]                 ; 8-byte Spill
	mov	w8, #18960                      ; =0x4a10
	add	x8, x20, x8
	str	x8, [sp, #1280]                 ; 8-byte Spill
	ldr	q0, [sp, #4688]                 ; 16-byte Reload
	add.2d	v0, v18, v0
	str	q0, [sp, #1264]                 ; 16-byte Spill
	ldr	q0, [sp, #4656]                 ; 16-byte Reload
	add.2d	v0, v18, v0
	str	q0, [sp, #1248]                 ; 16-byte Spill
	mov	w8, #24080                      ; =0x5e10
	add	x8, x20, x8
	str	x8, [sp, #1240]                 ; 8-byte Spill
	mov	w8, #29200                      ; =0x7210
	add	x8, x20, x8
	str	x8, [sp, #1232]                 ; 8-byte Spill
	add.2d	v0, v18, v28
	str	q0, [sp, #1216]                 ; 16-byte Spill
	ldr	q0, [sp, #4448]                 ; 16-byte Reload
	add.2d	v0, v18, v0
	str	q0, [sp, #1200]                 ; 16-byte Spill
	mov	w8, #34320                      ; =0x8610
	add	x8, x20, x8
	str	x8, [sp, #1192]                 ; 8-byte Spill
	mov	w8, #39440                      ; =0x9a10
	add	x8, x20, x8
	str	x8, [sp, #1184]                 ; 8-byte Spill
	ldr	q0, [sp, #4784]                 ; 16-byte Reload
	add.2d	v0, v18, v0
	str	q0, [sp, #1168]                 ; 16-byte Spill
	ldr	q0, [sp, #4768]                 ; 16-byte Reload
	add.2d	v0, v18, v0
	str	q0, [sp, #1152]                 ; 16-byte Spill
	mov	w8, #44560                      ; =0xae10
	add	x8, x20, x8
	str	x8, [sp, #1144]                 ; 8-byte Spill
	mov	w8, #51968                      ; =0xcb00
	add	x8, x20, x8
	str	x8, [sp, #1136]                 ; 8-byte Spill
	ldr	q0, [sp, #4816]                 ; 16-byte Reload
	add.2d	v0, v18, v0
	str	q0, [sp, #1120]                 ; 16-byte Spill
	ldr	q0, [sp, #4800]                 ; 16-byte Reload
	add.2d	v0, v18, v0
	str	q0, [sp, #1104]                 ; 16-byte Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1536
	str	x8, [sp, #1096]                 ; 8-byte Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1568
	str	x8, [sp, #1088]                 ; 8-byte Spill
	ldr	q0, [sp, #4880]                 ; 16-byte Reload
	add.2d	v0, v18, v0
	str	q0, [sp, #1072]                 ; 16-byte Spill
	ldr	q0, [sp, #4864]                 ; 16-byte Reload
	add.2d	v0, v18, v0
	str	q0, [sp, #1056]                 ; 16-byte Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1600
	str	x8, [sp, #1048]                 ; 8-byte Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1632
	str	x8, [sp, #1040]                 ; 8-byte Spill
	ldr	q0, [sp, #4912]                 ; 16-byte Reload
	add.2d	v1, v18, v0
	ldr	q0, [sp, #4896]                 ; 16-byte Reload
	add.2d	v0, v18, v0
	stp	q0, q1, [sp, #1008]             ; 32-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1664
	str	x8, [sp, #1000]                 ; 8-byte Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1696
	str	x8, [sp, #992]                  ; 8-byte Spill
	ldr	q0, [sp, #4752]                 ; 16-byte Reload
	add.2d	v1, v18, v0
	ldr	q0, [sp, #4736]                 ; 16-byte Reload
	add.2d	v0, v18, v0
	stp	q0, q1, [sp, #960]              ; 32-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1728
	str	x8, [sp, #952]                  ; 8-byte Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1760
	str	x8, [sp, #944]                  ; 8-byte Spill
	ldr	q0, [sp, #4720]                 ; 16-byte Reload
	add.2d	v1, v18, v0
	ldr	q0, [sp, #4704]                 ; 16-byte Reload
	add.2d	v0, v18, v0
	stp	q0, q1, [sp, #912]              ; 32-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1792
	str	x8, [sp, #904]                  ; 8-byte Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1824
	str	x8, [sp, #896]                  ; 8-byte Spill
	ldr	q0, [sp, #4672]                 ; 16-byte Reload
	add.2d	v1, v18, v0
	ldr	q0, [sp, #4640]                 ; 16-byte Reload
	add.2d	v0, v18, v0
	stp	q0, q1, [sp, #864]              ; 32-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1856
	str	x8, [sp, #856]                  ; 8-byte Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1888
	str	x8, [sp, #848]                  ; 8-byte Spill
	ldr	q0, [sp, #4624]                 ; 16-byte Reload
	add.2d	v1, v18, v0
	ldr	q0, [sp, #4608]                 ; 16-byte Reload
	add.2d	v0, v18, v0
	stp	q0, q1, [sp, #816]              ; 32-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1920
	str	x8, [sp, #808]                  ; 8-byte Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1952
	str	x8, [sp, #800]                  ; 8-byte Spill
	ldr	q0, [sp, #4576]                 ; 16-byte Reload
	add.2d	v1, v18, v0
	ldr	q0, [sp, #4560]                 ; 16-byte Reload
	add.2d	v0, v18, v0
	stp	q0, q1, [sp, #768]              ; 32-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1984
	str	x8, [sp, #760]                  ; 8-byte Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #2016
	str	x8, [sp, #752]                  ; 8-byte Spill
	ldr	q0, [sp, #4368]                 ; 16-byte Reload
	add.2d	v1, v18, v0
	ldr	q0, [sp, #4352]                 ; 16-byte Reload
	add.2d	v0, v18, v0
	stp	q0, q1, [sp, #720]              ; 32-byte Folded Spill
	ldr	q0, [sp, #4544]                 ; 16-byte Reload
	add.2d	v1, v18, v0
	ldr	q0, [sp, #4512]                 ; 16-byte Reload
	add.2d	v0, v18, v0
	stp	q0, q1, [sp, #688]              ; 32-byte Folded Spill
	ldr	q0, [sp, #4496]                 ; 16-byte Reload
	add.2d	v1, v18, v0
	ldr	q0, [sp, #4480]                 ; 16-byte Reload
	add.2d	v0, v18, v0
	stp	q0, q1, [sp, #656]              ; 32-byte Folded Spill
	ldr	q0, [sp, #4464]                 ; 16-byte Reload
	add.2d	v1, v18, v0
	ldr	q0, [sp, #4384]                 ; 16-byte Reload
	add.2d	v0, v18, v0
	stp	q0, q1, [sp, #624]              ; 32-byte Folded Spill
	add.2d	v0, v18, v8
	str	q0, [sp, #608]                  ; 16-byte Spill
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	str	q0, [sp, #4816]                 ; 16-byte Spill
	add	x25, x20, #16
	add	x24, x20, #336
	add	x19, x20, #656
	add	x26, x20, #976
	add	x22, x20, #1296
	add	x27, x20, #1616
	add	x28, x20, #1936
	add	x23, x20, #2256
	mov	w2, #62154                      ; =0xf2ca
	movk	w2, #61769, lsl #16
Lloh140:
	adrp	x8, lCPI0_71@PAGE
Lloh141:
	adrp	x9, lCPI0_72@PAGE
Lloh142:
	adrp	x10, lCPI0_73@PAGE
Lloh143:
	adrp	x11, lCPI0_74@PAGE
Lloh144:
	adrp	x12, lCPI0_75@PAGE
Lloh145:
	adrp	x13, lCPI0_76@PAGE
Lloh146:
	adrp	x14, lCPI0_77@PAGE
	ldr	q0, [sp, #4240]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #600]                 ; 8-byte Spill
	ldr	q0, [sp, #4256]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #592]                 ; 8-byte Spill
	ldr	q0, [sp, #4208]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #584]                 ; 8-byte Spill
	ldr	q0, [sp, #4224]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #576]                 ; 8-byte Spill
	ldr	q0, [sp, #4176]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #568]                 ; 8-byte Spill
	ldr	q0, [sp, #4192]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #560]                 ; 8-byte Spill
	ldr	q0, [sp, #4144]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #552]                 ; 8-byte Spill
	ldr	q0, [sp, #4160]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #544]                 ; 8-byte Spill
	ldr	q0, [sp, #4112]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #536]                 ; 8-byte Spill
	ldr	q0, [sp, #4128]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #528]                 ; 8-byte Spill
	ldr	q0, [sp, #4080]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #520]                 ; 8-byte Spill
	ldr	q0, [sp, #4096]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #512]                 ; 8-byte Spill
	ldr	q0, [sp, #4048]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #504]                 ; 8-byte Spill
	ldr	q0, [sp, #4064]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #496]                 ; 8-byte Spill
	ldr	q0, [sp, #4016]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #488]                 ; 8-byte Spill
	ldr	q0, [sp, #4032]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #480]                 ; 8-byte Spill
	ldr	q0, [sp, #3984]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #472]                 ; 8-byte Spill
	ldr	q0, [sp, #4000]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #464]                 ; 8-byte Spill
	ldr	q0, [sp, #3952]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #456]                 ; 8-byte Spill
	ldr	q0, [sp, #3968]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #448]                 ; 8-byte Spill
	ldr	q0, [sp, #3920]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #440]                 ; 8-byte Spill
	ldr	q0, [sp, #3936]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #432]                 ; 8-byte Spill
	ldr	q0, [sp, #3888]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #424]                 ; 8-byte Spill
	ldr	q0, [sp, #3904]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #416]                 ; 8-byte Spill
	ldr	q0, [sp, #3856]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #408]                 ; 8-byte Spill
	ldr	q0, [sp, #3872]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #400]                 ; 8-byte Spill
	ldr	q0, [sp, #3824]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #392]                 ; 8-byte Spill
	ldr	q0, [sp, #3840]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #384]                 ; 8-byte Spill
	ldr	q0, [sp, #3792]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #376]                 ; 8-byte Spill
	ldr	q0, [sp, #3808]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #368]                 ; 8-byte Spill
	ldr	q0, [sp, #3760]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #360]                 ; 8-byte Spill
	ldr	q0, [sp, #3776]                 ; 16-byte Reload
	fmov	x15, d0
	str	x15, [sp, #352]                 ; 8-byte Spill
Lloh147:
	adrp	x15, lCPI0_78@PAGE
Lloh148:
	adrp	x16, lCPI0_79@PAGE
Lloh149:
	adrp	x17, lCPI0_80@PAGE
Lloh150:
	adrp	x0, lCPI0_81@PAGE
Lloh151:
	adrp	x1, lCPI0_70@PAGE
Lloh152:
	ldr	q25, [x1, lCPI0_70@PAGEOFF]
	ldr	x1, [sp, #4848]                 ; 8-byte Reload
Lloh153:
	ldr	q26, [x8, lCPI0_71@PAGEOFF]
Lloh154:
	ldr	q27, [x9, lCPI0_72@PAGEOFF]
Lloh155:
	ldr	q28, [x10, lCPI0_73@PAGEOFF]
Lloh156:
	ldr	q29, [x11, lCPI0_74@PAGEOFF]
Lloh157:
	ldr	q30, [x12, lCPI0_75@PAGEOFF]
Lloh158:
	ldr	q31, [x13, lCPI0_76@PAGEOFF]
Lloh159:
	ldr	q8, [x14, lCPI0_77@PAGEOFF]
Lloh160:
	ldr	q0, [x15, lCPI0_78@PAGEOFF]
	str	q0, [sp, #208]                  ; 16-byte Spill
Lloh161:
	ldr	q0, [x16, lCPI0_79@PAGEOFF]
	str	q0, [sp, #192]                  ; 16-byte Spill
Lloh162:
	ldr	q0, [x17, lCPI0_80@PAGEOFF]
	str	q0, [sp, #176]                  ; 16-byte Spill
Lloh163:
	ldr	q1, [x0, lCPI0_81@PAGEOFF]
	add.2d	v0, v18, v20
	stp	q0, q1, [sp, #144]              ; 32-byte Folded Spill
	add.2d	v1, v18, v21
	add.2d	v0, v18, v22
	stp	q0, q1, [sp, #112]              ; 32-byte Folded Spill
	add.2d	v0, v18, v23
	str	q0, [sp, #96]                   ; 16-byte Spill
	dup.4s	v0, w2
	movi.2d	v19, #0000000000000000
	movi.2d	v24, #0000000000000000
	str	q0, [sp, #4912]                 ; 16-byte Spill
	str	q0, [sp, #4896]                 ; 16-byte Spill
	str	q20, [sp, #3568]                ; 16-byte Spill
	str	q21, [sp, #3536]                ; 16-byte Spill
	str	q22, [sp, #3504]                ; 16-byte Spill
	str	q23, [sp, #3472]                ; 16-byte Spill
	str	x4, [sp, #2488]                 ; 8-byte Spill
	str	x5, [sp, #2480]                 ; 8-byte Spill
	str	x6, [sp, #2472]                 ; 8-byte Spill
	str	x7, [sp, #2464]                 ; 8-byte Spill
	str	x30, [sp, #2456]                ; 8-byte Spill
	str	q18, [sp, #1792]                ; 16-byte Spill
	stp	q26, q25, [sp, #320]            ; 32-byte Folded Spill
	stp	q28, q27, [sp, #288]            ; 32-byte Folded Spill
	stp	q30, q29, [sp, #256]            ; 32-byte Folded Spill
	stp	q8, q31, [sp, #224]             ; 32-byte Folded Spill
LBB0_3:                                 ; %direct.true139
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_5 Depth 2
                                        ;     Child Loop BB0_9 Depth 2
                                        ;     Child Loop BB0_12 Depth 2
                                        ;       Child Loop BB0_13 Depth 3
                                        ;     Child Loop BB0_16 Depth 2
                                        ;       Child Loop BB0_17 Depth 3
                                        ;     Child Loop BB0_20 Depth 2
                                        ;       Child Loop BB0_21 Depth 3
                                        ;     Child Loop BB0_24 Depth 2
                                        ;       Child Loop BB0_25 Depth 3
                                        ;     Child Loop BB0_28 Depth 2
                                        ;       Child Loop BB0_29 Depth 3
                                        ;     Child Loop BB0_32 Depth 2
                                        ;       Child Loop BB0_33 Depth 3
                                        ;     Child Loop BB0_36 Depth 2
                                        ;       Child Loop BB0_37 Depth 3
                                        ;     Child Loop BB0_40 Depth 2
                                        ;       Child Loop BB0_41 Depth 3
                                        ;     Child Loop BB0_44 Depth 2
                                        ;     Child Loop BB0_46 Depth 2
                                        ;     Child Loop BB0_48 Depth 2
                                        ;     Child Loop BB0_50 Depth 2
                                        ;     Child Loop BB0_52 Depth 2
                                        ;     Child Loop BB0_54 Depth 2
                                        ;     Child Loop BB0_56 Depth 2
                                        ;     Child Loop BB0_58 Depth 2
                                        ;     Child Loop BB0_60 Depth 2
                                        ;     Child Loop BB0_62 Depth 2
                                        ;     Child Loop BB0_64 Depth 2
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	lsl	x8, x1, #4
	ldr	x0, [sp, #3712]                 ; 8-byte Reload
	ldr	x2, [sp, #3696]                 ; 8-byte Reload
	ldr	x3, [sp, #3688]                 ; 8-byte Reload
	ldr	q6, [sp, #3632]                 ; 16-byte Reload
	ldr	q7, [sp, #3616]                 ; 16-byte Reload
	ldr	q16, [sp, #3600]                ; 16-byte Reload
	ldr	q17, [sp, #3584]                ; 16-byte Reload
	b	LBB0_5
LBB0_4:                                 ; %direct.schedule.12
                                        ;   in Loop: Header=BB0_5 Depth=2
	dup.2d	v2, x9
	dup.2d	v3, x2
	add.2d	v2, v2, v3
	add.2d	v3, v2, v26
	add.2d	v4, v2, v25
	mov.d	x11, v4[1]
	fmov	x12, d4
	str	s1, [x12]
	st1.s	{ v1 }[1], [x11]
	mov.d	x11, v3[1]
	add.2d	v4, v2, v27
	fmov	x12, d3
	st1.s	{ v1 }[2], [x12]
	st1.s	{ v1 }[3], [x11]
	mov.d	x11, v4[1]
	fmov	x12, d4
	str	s0, [x12]
	st1.s	{ v0 }[1], [x11]
	add.2d	v1, v2, v28
	mov.d	x11, v1[1]
	fmov	x12, d1
	st1.s	{ v0 }[2], [x12]
	st1.s	{ v0 }[3], [x11]
	add	x10, x10, #1
	add	x9, x9, #4
	cmp	x10, #1280
	b.eq	LBB0_7
LBB0_5:                                 ; %direct.true143
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w11, w10, #0xffff
	mov	w12, #52429                     ; =0xcccd
	mul	w11, w11, w12
	lsr	w11, w11, #22
	add	x12, x8, x11
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	cmp	x12, #2052
	b.hi	LBB0_4
; %bb.6:                                ; %direct.true156
                                        ;   in Loop: Header=BB0_5 Depth=2
	dup.2d	v0, x12
	add.2d	v1, v0, v17
	add.2d	v2, v0, v16
	add.2d	v3, v0, v7
	add.2d	v0, v0, v6
	mov.d	x12, v0[1]
	fmov	x13, d0
	add	x13, x13, x13, lsl #2
	lsl	x13, x13, #4
	fmov	d0, x13
	add	x12, x12, x12, lsl #2
	lsl	x12, x12, #4
	mov.d	v0[1], x12
	mov.d	x12, v3[1]
	fmov	x13, d3
	add	x13, x13, x13, lsl #2
	lsl	x13, x13, #4
	fmov	d3, x13
	add	x12, x12, x12, lsl #2
	lsl	x12, x12, #4
	mov.d	v3[1], x12
	mov.d	x12, v2[1]
	fmov	x13, d2
	add	x13, x13, x13, lsl #2
	lsl	x13, x13, #4
	fmov	d2, x13
	add	x12, x12, x12, lsl #2
	lsl	x12, x12, #4
	mov.d	v2[1], x12
	mov.d	x12, v1[1]
	fmov	x13, d1
	add	x13, x13, x13, lsl #2
	lsl	x13, x13, #4
	fmov	d1, x13
	add	x12, x12, x12, lsl #2
	lsl	x12, x12, #4
	mov.d	v1[1], x12
	mov	w12, #80                        ; =0x50
	msub	w11, w11, w12, w10
	and	x11, x11, #0xffff
	dup.2d	v4, x11
	add.2d	v1, v1, v4
	add.2d	v2, v2, v4
	add.2d	v3, v3, v4
	add.2d	v0, v0, v4
	shl.2d	v0, v0, #2
	shl.2d	v3, v3, #2
	shl.2d	v2, v2, #2
	shl.2d	v1, v1, #2
	dup.2d	v4, x0
	add.2d	v5, v4, v1
	add.2d	v1, v4, v2
	add.2d	v2, v4, v3
	add.2d	v0, v4, v0
	mov.d	x11, v0[1]
	fmov	x12, d0
	mov.d	x13, v2[1]
	fmov	x14, d2
	mov.d	x15, v1[1]
	fmov	x16, d1
	mov.d	x17, v5[1]
	ldr	s1, [x12]
	ld1.s	{ v1 }[1], [x11]
	fmov	x11, d5
	ld1.s	{ v1 }[2], [x14]
	ld1.s	{ v1 }[3], [x13]
	ldr	s0, [x16]
	ld1.s	{ v0 }[1], [x15]
	ld1.s	{ v0 }[2], [x11]
	ld1.s	{ v0 }[3], [x17]
	b	LBB0_4
LBB0_7:                                 ; %direct.true166.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	ldr	x0, [sp, #3704]                 ; 8-byte Reload
	b	LBB0_9
LBB0_8:                                 ; %direct.schedule.17
                                        ;   in Loop: Header=BB0_9 Depth=2
	dup.2d	v2, x9
	dup.2d	v3, x3
	add.2d	v2, v2, v3
	add.2d	v3, v2, v30
	add.2d	v4, v2, v29
	mov.d	x11, v4[1]
	fmov	x12, d4
	str	s1, [x12]
	st1.s	{ v1 }[1], [x11]
	mov.d	x11, v3[1]
	add.2d	v4, v2, v31
	fmov	x12, d3
	st1.s	{ v1 }[2], [x12]
	st1.s	{ v1 }[3], [x11]
	mov.d	x11, v4[1]
	fmov	x12, d4
	str	s0, [x12]
	st1.s	{ v0 }[1], [x11]
	add.2d	v1, v2, v8
	mov.d	x11, v1[1]
	fmov	x12, d1
	st1.s	{ v0 }[2], [x12]
	st1.s	{ v0 }[3], [x11]
	add	x10, x10, #1
	add	x9, x9, #4
	cmp	x10, #1536
	b.eq	LBB0_11
LBB0_9:                                 ; %direct.true166
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w11, w10, #0xffff
	mov	w12, #43691                     ; =0xaaab
	mul	w11, w11, w12
	lsr	w11, w11, #22
	add	x12, x8, x11
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	cmp	x12, #2053
	b.hs	LBB0_8
; %bb.10:                               ; %direct.true179
                                        ;   in Loop: Header=BB0_9 Depth=2
	dup.2d	v0, x12
	add.2d	v1, v0, v17
	add.2d	v2, v0, v16
	add.2d	v3, v0, v7
	add.2d	v0, v0, v6
	mov.d	x12, v0[1]
	fmov	x13, d0
	add	x13, x13, x13, lsl #1
	lsl	x13, x13, #5
	fmov	d0, x13
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #5
	mov.d	v0[1], x12
	mov.d	x12, v3[1]
	fmov	x13, d3
	add	x13, x13, x13, lsl #1
	lsl	x13, x13, #5
	fmov	d3, x13
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #5
	mov.d	v3[1], x12
	mov.d	x12, v2[1]
	fmov	x13, d2
	add	x13, x13, x13, lsl #1
	lsl	x13, x13, #5
	fmov	d2, x13
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #5
	mov.d	v2[1], x12
	mov.d	x12, v1[1]
	fmov	x13, d1
	add	x13, x13, x13, lsl #1
	lsl	x13, x13, #5
	fmov	d1, x13
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #5
	mov.d	v1[1], x12
	mov	w12, #96                        ; =0x60
	msub	w11, w11, w12, w10
	and	x11, x11, #0xffff
	dup.2d	v4, x11
	add.2d	v1, v1, v4
	add.2d	v2, v2, v4
	add.2d	v3, v3, v4
	add.2d	v0, v0, v4
	shl.2d	v0, v0, #2
	shl.2d	v3, v3, #2
	shl.2d	v2, v2, #2
	shl.2d	v1, v1, #2
	dup.2d	v4, x0
	add.2d	v5, v4, v1
	add.2d	v1, v4, v2
	add.2d	v2, v4, v3
	add.2d	v0, v4, v0
	mov.d	x11, v0[1]
	fmov	x12, d0
	mov.d	x13, v2[1]
	fmov	x14, d2
	mov.d	x15, v1[1]
	fmov	x16, d1
	mov.d	x17, v5[1]
	ldr	s1, [x12]
	ld1.s	{ v1 }[1], [x11]
	fmov	x11, d5
	ld1.s	{ v1 }[2], [x14]
	ld1.s	{ v1 }[3], [x13]
	ldr	s0, [x16]
	ld1.s	{ v0 }[1], [x15]
	ld1.s	{ v0 }[2], [x11]
	ld1.s	{ v0 }[3], [x17]
	b	LBB0_8
LBB0_11:                                ; %direct.false167
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q0, [sp, #3456]                 ; 16-byte Reload
	mov.d	x9, v0[1]
	fmov	x10, d0
	str	wzr, [x10]
	str	wzr, [x9]
	ldr	q0, [sp, #3488]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #3520]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #3552]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #3392]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #3408]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #3424]                 ; 16-byte Reload
	fmov	x9, d0
	mov.d	x10, v0[1]
	str	wzr, [x9]
	str	wzr, [x10]
	ldr	q0, [sp, #3440]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #3328]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #3344]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #3360]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #3376]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #3264]                 ; 16-byte Reload
	fmov	x9, d0
	mov.d	x10, v0[1]
	str	wzr, [x9]
	str	wzr, [x10]
	ldr	q0, [sp, #3280]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #3296]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #3312]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #3200]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #3216]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #3232]                 ; 16-byte Reload
	fmov	x9, d0
	mov.d	x10, v0[1]
	str	wzr, [x9]
	str	wzr, [x10]
	ldr	q0, [sp, #3248]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #3136]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #3152]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #3168]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #3184]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #3072]                 ; 16-byte Reload
	fmov	x9, d0
	mov.d	x10, v0[1]
	str	wzr, [x9]
	str	wzr, [x10]
	ldr	q0, [sp, #3088]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #3104]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #3120]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #3008]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #3024]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #3040]                 ; 16-byte Reload
	fmov	x9, d0
	mov.d	x10, v0[1]
	str	wzr, [x9]
	str	wzr, [x10]
	ldr	q0, [sp, #3056]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #2944]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #2960]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #2976]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #2992]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #2880]                 ; 16-byte Reload
	fmov	x9, d0
	mov.d	x10, v0[1]
	str	wzr, [x9]
	str	wzr, [x10]
	ldr	q0, [sp, #2896]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #2912]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #2928]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #2816]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #2832]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #2848]                 ; 16-byte Reload
	fmov	x9, d0
	mov.d	x10, v0[1]
	str	wzr, [x9]
	str	wzr, [x10]
	ldr	q0, [sp, #2864]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #2752]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #2768]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #2784]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #2800]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #2688]                 ; 16-byte Reload
	fmov	x9, d0
	mov.d	x10, v0[1]
	str	wzr, [x9]
	str	wzr, [x10]
	ldr	q0, [sp, #2704]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #2720]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #2736]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #2624]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #2640]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #2656]                 ; 16-byte Reload
	fmov	x9, d0
	mov.d	x10, v0[1]
	str	wzr, [x9]
	str	wzr, [x10]
	ldr	q0, [sp, #2672]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #2560]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #2576]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #2592]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #2608]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #2496]                 ; 16-byte Reload
	fmov	x9, d0
	mov.d	x10, v0[1]
	str	wzr, [x9]
	str	wzr, [x10]
	ldr	q0, [sp, #2512]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #2528]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	q0, [sp, #2544]                 ; 16-byte Reload
	fmov	x9, d0
	str	wzr, [x9]
	mov.d	x9, v0[1]
	str	wzr, [x9]
	ldr	x9, [sp, #1328]                 ; 8-byte Reload
	ldr	x12, [sp, #3680]                ; 8-byte Reload
	ldr	x13, [sp, #3672]                ; 8-byte Reload
	ldr	x17, [sp, #3656]                ; 8-byte Reload
	ldr	x14, [sp, #2424]                ; 8-byte Reload
	mov	w15, #320                       ; =0x140
LBB0_12:                                ; %mma.update.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_13 Depth 3
	mov	x10, #0                         ; =0x0
	ldr	s0, [x12, x8, lsl #2]
	ldr	q1, [x20]
	mul	x11, x8, x15
	ldr	q2, [x2, x11]
	fmul.4s	v1, v1, v2
LBB0_13:                                ; %mma.update2.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_12 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q2, [x25, x10]
	ldr	q3, [x9, x10]
	fmul.4s	v2, v2, v3
	fadd.4s	v1, v1, v2
	add	x10, x10, #16
	cmp	x10, #304
	b.ne	LBB0_13
; %bb.14:                               ; %mma.fold.done3.i
                                        ;   in Loop: Header=BB0_12 Depth=2
	dup.4s	v2, v1[1]
	fadd.4s	v2, v1, v2
	dup.4s	v3, v1[3]
	fadd.4s	v1, v1, v3
	dup.4s	v1, v1[2]
	fadd.4s	v1, v2, v1
	fadd	s0, s0, s1
	str	s0, [x13, x8, lsl #2]
	add	x8, x8, #1
	add	x9, x9, #320
	cmp	x8, #16
	b.ne	LBB0_12
; %bb.15:                               ; %mma.update.i202.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	x9, [sp, #1288]                 ; 8-byte Reload
	ldr	x12, [sp, #2448]                ; 8-byte Reload
	ldr	x13, [sp, #2432]                ; 8-byte Reload
LBB0_16:                                ; %mma.update.i202
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_17 Depth 3
	mov	x10, #0                         ; =0x0
	ldr	s0, [x5, x8, lsl #2]
	ldr	q1, [x20, #320]
	mul	x11, x8, x15
	ldr	q2, [x4, x11]
	fmul.4s	v1, v1, v2
LBB0_17:                                ; %mma.update2.i205
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_16 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q2, [x24, x10]
	ldr	q3, [x9, x10]
	fmul.4s	v2, v2, v3
	fadd.4s	v1, v1, v2
	add	x10, x10, #16
	cmp	x10, #304
	b.ne	LBB0_17
; %bb.18:                               ; %mma.fold.done3.i209
                                        ;   in Loop: Header=BB0_16 Depth=2
	dup.4s	v2, v1[1]
	fadd.4s	v2, v1, v2
	dup.4s	v3, v1[3]
	fadd.4s	v1, v1, v3
	dup.4s	v1, v1[2]
	fadd.4s	v1, v2, v1
	fadd	s0, s0, s1
	str	s0, [x6, x8, lsl #2]
	add	x8, x8, #1
	add	x9, x9, #320
	cmp	x8, #16
	b.ne	LBB0_16
; %bb.19:                               ; %mma.update.i212.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	x9, [sp, #1280]                 ; 8-byte Reload
LBB0_20:                                ; %mma.update.i212
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_21 Depth 3
	mov	x10, #0                         ; =0x0
	ldr	s0, [x30, x8, lsl #2]
	ldr	q1, [x20, #640]
	mul	x11, x8, x15
	ldr	q2, [x7, x11]
	fmul.4s	v1, v1, v2
LBB0_21:                                ; %mma.update2.i215
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_20 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q2, [x19, x10]
	ldr	q3, [x9, x10]
	fmul.4s	v2, v2, v3
	fadd.4s	v1, v1, v2
	add	x10, x10, #16
	cmp	x10, #304
	b.ne	LBB0_21
; %bb.22:                               ; %mma.fold.done3.i219
                                        ;   in Loop: Header=BB0_20 Depth=2
	dup.4s	v2, v1[1]
	fadd.4s	v2, v1, v2
	dup.4s	v3, v1[3]
	fadd.4s	v1, v1, v3
	dup.4s	v1, v1[2]
	fadd.4s	v1, v2, v1
	fadd	s0, s0, s1
	str	s0, [x12, x8, lsl #2]
	add	x8, x8, #1
	add	x9, x9, #320
	cmp	x8, #16
	b.ne	LBB0_20
; %bb.23:                               ; %mma.update.i222.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	x9, [sp, #1240]                 ; 8-byte Reload
	ldr	x12, [sp, #2440]                ; 8-byte Reload
LBB0_24:                                ; %mma.update.i222
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_25 Depth 3
	mov	x10, #0                         ; =0x0
	ldr	s0, [x13, x8, lsl #2]
	ldr	q1, [x20, #960]
	mul	x11, x8, x15
	ldr	q2, [x12, x11]
	fmul.4s	v1, v1, v2
LBB0_25:                                ; %mma.update2.i225
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_24 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q2, [x26, x10]
	ldr	q3, [x9, x10]
	fmul.4s	v2, v2, v3
	fadd.4s	v1, v1, v2
	add	x10, x10, #16
	cmp	x10, #304
	b.ne	LBB0_25
; %bb.26:                               ; %mma.fold.done3.i229
                                        ;   in Loop: Header=BB0_24 Depth=2
	dup.4s	v2, v1[1]
	fadd.4s	v2, v1, v2
	dup.4s	v3, v1[3]
	fadd.4s	v1, v1, v3
	dup.4s	v1, v1[2]
	fadd.4s	v1, v2, v1
	fadd	s0, s0, s1
	str	s0, [x14, x8, lsl #2]
	add	x8, x8, #1
	add	x9, x9, #320
	cmp	x8, #16
	b.ne	LBB0_24
; %bb.27:                               ; %mma.update.i232.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	x9, [sp, #1232]                 ; 8-byte Reload
	ldr	x12, [sp, #2416]                ; 8-byte Reload
	ldr	x13, [sp, #2408]                ; 8-byte Reload
	ldr	x14, [sp, #2400]                ; 8-byte Reload
LBB0_28:                                ; %mma.update.i232
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_29 Depth 3
	mov	x10, #0                         ; =0x0
	ldr	s0, [x13, x8, lsl #2]
	ldr	q1, [x20, #1280]
	mul	x11, x8, x15
	ldr	q2, [x12, x11]
	fmul.4s	v1, v1, v2
LBB0_29:                                ; %mma.update2.i235
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_28 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q2, [x22, x10]
	ldr	q3, [x9, x10]
	fmul.4s	v2, v2, v3
	fadd.4s	v1, v1, v2
	add	x10, x10, #16
	cmp	x10, #304
	b.ne	LBB0_29
; %bb.30:                               ; %mma.fold.done3.i239
                                        ;   in Loop: Header=BB0_28 Depth=2
	dup.4s	v2, v1[1]
	fadd.4s	v2, v1, v2
	dup.4s	v3, v1[3]
	fadd.4s	v1, v1, v3
	dup.4s	v1, v1[2]
	fadd.4s	v1, v2, v1
	fadd	s0, s0, s1
	str	s0, [x14, x8, lsl #2]
	add	x8, x8, #1
	add	x9, x9, #320
	cmp	x8, #16
	b.ne	LBB0_28
; %bb.31:                               ; %mma.update.i242.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	x9, [sp, #1192]                 ; 8-byte Reload
	ldr	x12, [sp, #2392]                ; 8-byte Reload
	ldr	x13, [sp, #2384]                ; 8-byte Reload
	ldr	x14, [sp, #2376]                ; 8-byte Reload
LBB0_32:                                ; %mma.update.i242
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_33 Depth 3
	mov	x10, #0                         ; =0x0
	ldr	s0, [x13, x8, lsl #2]
	ldr	q1, [x20, #1600]
	mul	x11, x8, x15
	ldr	q2, [x12, x11]
	fmul.4s	v1, v1, v2
LBB0_33:                                ; %mma.update2.i245
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_32 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q2, [x27, x10]
	ldr	q3, [x9, x10]
	fmul.4s	v2, v2, v3
	fadd.4s	v1, v1, v2
	add	x10, x10, #16
	cmp	x10, #304
	b.ne	LBB0_33
; %bb.34:                               ; %mma.fold.done3.i249
                                        ;   in Loop: Header=BB0_32 Depth=2
	dup.4s	v2, v1[1]
	fadd.4s	v2, v1, v2
	dup.4s	v3, v1[3]
	fadd.4s	v1, v1, v3
	dup.4s	v1, v1[2]
	fadd.4s	v1, v2, v1
	fadd	s0, s0, s1
	str	s0, [x14, x8, lsl #2]
	add	x8, x8, #1
	add	x9, x9, #320
	cmp	x8, #16
	b.ne	LBB0_32
; %bb.35:                               ; %mma.update.i252.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	x9, [sp, #1184]                 ; 8-byte Reload
	ldr	x12, [sp, #2368]                ; 8-byte Reload
	ldr	x13, [sp, #2360]                ; 8-byte Reload
	ldr	x14, [sp, #2352]                ; 8-byte Reload
LBB0_36:                                ; %mma.update.i252
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_37 Depth 3
	mov	x10, #0                         ; =0x0
	ldr	s0, [x13, x8, lsl #2]
	ldr	q1, [x20, #1920]
	mul	x11, x8, x15
	ldr	q2, [x12, x11]
	fmul.4s	v1, v1, v2
LBB0_37:                                ; %mma.update2.i255
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_36 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q2, [x28, x10]
	ldr	q3, [x9, x10]
	fmul.4s	v2, v2, v3
	fadd.4s	v1, v1, v2
	add	x10, x10, #16
	cmp	x10, #304
	b.ne	LBB0_37
; %bb.38:                               ; %mma.fold.done3.i259
                                        ;   in Loop: Header=BB0_36 Depth=2
	dup.4s	v2, v1[1]
	fadd.4s	v2, v1, v2
	dup.4s	v3, v1[3]
	fadd.4s	v1, v1, v3
	dup.4s	v1, v1[2]
	fadd.4s	v1, v2, v1
	fadd	s0, s0, s1
	str	s0, [x14, x8, lsl #2]
	add	x8, x8, #1
	add	x9, x9, #320
	cmp	x8, #16
	b.ne	LBB0_36
; %bb.39:                               ; %mma.update.i262.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	x9, [sp, #1144]                 ; 8-byte Reload
	ldr	x12, [sp, #2344]                ; 8-byte Reload
	ldr	x13, [sp, #2336]                ; 8-byte Reload
	ldr	x14, [sp, #2328]                ; 8-byte Reload
LBB0_40:                                ; %mma.update.i262
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_41 Depth 3
	mov	x10, #0                         ; =0x0
	ldr	s0, [x13, x8, lsl #2]
	ldr	q1, [x20, #2240]
	mul	x11, x8, x15
	ldr	q2, [x12, x11]
	fmul.4s	v1, v1, v2
LBB0_41:                                ; %mma.update2.i265
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q2, [x23, x10]
	ldr	q3, [x9, x10]
	fmul.4s	v2, v2, v3
	fadd.4s	v1, v1, v2
	add	x10, x10, #16
	cmp	x10, #304
	b.ne	LBB0_41
; %bb.42:                               ; %mma.fold.done3.i269
                                        ;   in Loop: Header=BB0_40 Depth=2
	dup.4s	v2, v1[1]
	fadd.4s	v2, v1, v2
	dup.4s	v3, v1[3]
	fadd.4s	v1, v1, v3
	dup.4s	v1, v1[2]
	fadd.4s	v1, v2, v1
	fadd	s0, s0, s1
	str	s0, [x14, x8, lsl #2]
	add	x8, x8, #1
	add	x9, x9, #320
	cmp	x8, #16
	b.ne	LBB0_40
; %bb.43:                               ; %llm_attention.strided_mma.exit271
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	q24, [sp, #4784]                ; 16-byte Spill
	str	q19, [sp, #4800]                ; 16-byte Spill
	ldr	q0, [sp, #4240]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	mov	x9, #0                          ; =0x0
	ldr	x10, [sp, #600]                 ; 8-byte Reload
	ldr	s1, [x10]
	ld1.s	{ v1 }[1], [x8]
	ldr	q0, [sp, #2288]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v1 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v1 }[3], [x8]
	str	q1, [sp, #4880]                 ; 16-byte Spill
	ldr	q0, [sp, #4256]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldr	x10, [sp, #592]                 ; 8-byte Reload
	ldr	s14, [x10]
	ld1.s	{ v14 }[1], [x8]
	ldr	q0, [sp, #2304]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v14 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v14 }[3], [x8]
	ldr	q0, [sp, #4208]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldr	x10, [sp, #584]                 ; 8-byte Reload
	ldr	s9, [x10]
	ld1.s	{ v9 }[1], [x8]
	ldr	q0, [sp, #2256]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v9 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v9 }[3], [x8]
	ldr	q0, [sp, #4224]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldr	x10, [sp, #576]                 ; 8-byte Reload
	ldr	s8, [x10]
	ld1.s	{ v8 }[1], [x8]
	ldr	q0, [sp, #2272]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v8 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v8 }[3], [x8]
	ldr	q0, [sp, #4176]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldr	x10, [sp, #568]                 ; 8-byte Reload
	ldr	s12, [x10]
	ld1.s	{ v12 }[1], [x8]
	ldr	q0, [sp, #2224]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v12 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v12 }[3], [x8]
	ldr	q0, [sp, #4192]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldr	x10, [sp, #560]                 ; 8-byte Reload
	ldr	s11, [x10]
	ld1.s	{ v11 }[1], [x8]
	ldr	q0, [sp, #2240]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v11 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v11 }[3], [x8]
	ldr	q0, [sp, #4144]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldr	x10, [sp, #552]                 ; 8-byte Reload
	ldr	s30, [x10]
	ld1.s	{ v30 }[1], [x8]
	ldr	q0, [sp, #2192]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v30 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v30 }[3], [x8]
	ldr	q0, [sp, #4160]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldr	x10, [sp, #544]                 ; 8-byte Reload
	ldr	s13, [x10]
	ld1.s	{ v13 }[1], [x8]
	ldr	q0, [sp, #2208]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v13 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v13 }[3], [x8]
	ldr	q0, [sp, #4112]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldr	x10, [sp, #536]                 ; 8-byte Reload
	ldr	s29, [x10]
	ld1.s	{ v29 }[1], [x8]
	ldr	q0, [sp, #2160]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v29 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v29 }[3], [x8]
	ldr	q0, [sp, #4128]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldr	x10, [sp, #528]                 ; 8-byte Reload
	ldr	s27, [x10]
	ld1.s	{ v27 }[1], [x8]
	ldr	q0, [sp, #2176]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v27 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v27 }[3], [x8]
	ldr	q0, [sp, #4096]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldr	x10, [sp, #512]                 ; 8-byte Reload
	ldr	s18, [x10]
	ld1.s	{ v18 }[1], [x8]
	ldr	q0, [sp, #2144]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v18 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
	ldr	q0, [sp, #4080]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldr	x10, [sp, #520]                 ; 8-byte Reload
	ldr	s19, [x10]
	ld1.s	{ v19 }[1], [x8]
	ldr	q0, [sp, #2128]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v19 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v19 }[3], [x8]
	ldr	q0, [sp, #4064]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldp	x11, x10, [sp, #496]            ; 16-byte Folded Reload
	ldr	s20, [x11]
	ld1.s	{ v20 }[1], [x8]
	ldr	q0, [sp, #2112]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v20 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v20 }[3], [x8]
	ldr	q0, [sp, #4048]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldr	s21, [x10]
	ld1.s	{ v21 }[1], [x8]
	ldr	q0, [sp, #2096]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v21 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v21 }[3], [x8]
	ldr	q0, [sp, #4032]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldp	x11, x10, [sp, #480]            ; 16-byte Folded Reload
	ldr	s22, [x11]
	ld1.s	{ v22 }[1], [x8]
	ldr	q0, [sp, #2080]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v22 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v22 }[3], [x8]
	ldr	q0, [sp, #4016]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldr	s23, [x10]
	ld1.s	{ v23 }[1], [x8]
	ldr	q0, [sp, #2064]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v23 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v23 }[3], [x8]
	ldr	q0, [sp, #4000]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldp	x11, x10, [sp, #464]            ; 16-byte Folded Reload
	ldr	s24, [x11]
	ld1.s	{ v24 }[1], [x8]
	ldr	q0, [sp, #2048]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v24 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v24 }[3], [x8]
	ldr	q0, [sp, #3984]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldr	s25, [x10]
	ld1.s	{ v25 }[1], [x8]
	ldr	q0, [sp, #2032]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v25 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v25 }[3], [x8]
	ldr	q0, [sp, #3968]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldp	x11, x10, [sp, #448]            ; 16-byte Folded Reload
	ldr	s26, [x11]
	ld1.s	{ v26 }[1], [x8]
	ldr	q0, [sp, #2016]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v26 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v26 }[3], [x8]
	ldr	q0, [sp, #3952]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldr	s28, [x10]
	ld1.s	{ v28 }[1], [x8]
	ldr	q0, [sp, #2000]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v28 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v28 }[3], [x8]
	ldr	q0, [sp, #3936]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldp	x11, x10, [sp, #432]            ; 16-byte Folded Reload
	ldr	s31, [x11]
	ld1.s	{ v31 }[1], [x8]
	ldr	q0, [sp, #1984]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v31 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v31 }[3], [x8]
	ldr	q0, [sp, #3920]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldr	s10, [x10]
	ld1.s	{ v10 }[1], [x8]
	ldr	q0, [sp, #1968]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v10 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v10 }[3], [x8]
	ldr	q0, [sp, #3904]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldp	x11, x10, [sp, #416]            ; 16-byte Folded Reload
	ldr	s15, [x11]
	ld1.s	{ v15 }[1], [x8]
	ldr	q0, [sp, #1952]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v15 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v15 }[3], [x8]
	ldr	q0, [sp, #3888]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldr	s17, [x10]
	ld1.s	{ v17 }[1], [x8]
	ldr	q0, [sp, #1936]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v17 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v17 }[3], [x8]
	ldr	q0, [sp, #3872]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldp	x11, x10, [sp, #400]            ; 16-byte Folded Reload
	ldr	s16, [x11]
	ld1.s	{ v16 }[1], [x8]
	ldr	q0, [sp, #1920]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v16 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v16 }[3], [x8]
	ldr	q0, [sp, #3856]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldr	s6, [x10]
	ld1.s	{ v6 }[1], [x8]
	ldr	q0, [sp, #1904]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v6 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v6 }[3], [x8]
	ldr	q0, [sp, #3840]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldp	x11, x10, [sp, #384]            ; 16-byte Folded Reload
	ldr	s4, [x11]
	ld1.s	{ v4 }[1], [x8]
	ldr	q0, [sp, #1888]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v4 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v4 }[3], [x8]
	ldr	q0, [sp, #3824]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldr	s5, [x10]
	ld1.s	{ v5 }[1], [x8]
	ldr	q0, [sp, #1872]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v5 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v5 }[3], [x8]
	ldr	q0, [sp, #3808]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldp	x11, x10, [sp, #368]            ; 16-byte Folded Reload
	ldr	s7, [x11]
	ld1.s	{ v7 }[1], [x8]
	ldr	q0, [sp, #1856]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v7 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v7 }[3], [x8]
	ldr	q0, [sp, #3792]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldr	s3, [x10]
	ld1.s	{ v3 }[1], [x8]
	ldr	q0, [sp, #1840]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v3 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v3 }[3], [x8]
	ldr	q0, [sp, #3776]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldp	x11, x10, [sp, #352]            ; 16-byte Folded Reload
	ldr	s2, [x11]
	ld1.s	{ v2 }[1], [x8]
	ldr	q0, [sp, #1824]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v2 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v2 }[3], [x8]
	ldr	q0, [sp, #3760]                 ; 16-byte Reload
	mov.d	x8, v0[1]
	ldr	s1, [x10]
	ld1.s	{ v1 }[1], [x8]
	ldr	q0, [sp, #1808]                 ; 16-byte Reload
	fmov	x8, d0
	ld1.s	{ v1 }[2], [x8]
	mov.d	x8, v0[1]
	ld1.s	{ v1 }[3], [x8]
	mov	w8, #63790                      ; =0xf92e
	movk	w8, #15844, lsl #16
	dup.4s	v0, w8
	fmul.4s	v14, v14, v0
	str	q14, [sp, #4544]                ; 16-byte Spill
	ldr	q14, [sp, #4880]                ; 16-byte Reload
	fmul.4s	v14, v14, v0
	str	q14, [sp, #4656]                ; 16-byte Spill
	fmul.4s	v8, v8, v0
	str	q8, [sp, #4480]                 ; 16-byte Spill
	fmul.4s	v8, v9, v0
	str	q8, [sp, #4640]                 ; 16-byte Spill
	fmul.4s	v14, v11, v0
	str	q14, [sp, #4608]                ; 16-byte Spill
	fmul.4s	v8, v12, v0
	str	q8, [sp, #4592]                 ; 16-byte Spill
	fmul.4s	v8, v13, v0
	str	q8, [sp, #4864]                 ; 16-byte Spill
	fmul.4s	v30, v30, v0
	str	q30, [sp, #4848]                ; 16-byte Spill
	fmul.4s	v8, v27, v0
	str	q8, [sp, #4512]                 ; 16-byte Spill
	fmul.4s	v27, v29, v0
	str	q27, [sp, #4880]                ; 16-byte Spill
	fmul.4s	v30, v19, v0
	fmul.4s	v27, v18, v0
	fmul.4s	v13, v21, v0
	fmul.4s	v20, v20, v0
	fmul.4s	v29, v23, v0
	fmul.4s	v18, v22, v0
	fmul.4s	v25, v25, v0
	fmul.4s	v19, v24, v0
	fmul.4s	v28, v28, v0
	fmul.4s	v21, v26, v0
	fmul.4s	v26, v10, v0
	fmul.4s	v22, v31, v0
	fmul.4s	v17, v17, v0
	fmul.4s	v15, v15, v0
	fmul.4s	v6, v6, v0
	fmul.4s	v16, v16, v0
	fmul.4s	v11, v5, v0
	fmul.4s	v4, v4, v0
	fmul.4s	v9, v3, v0
	fmul.4s	v5, v7, v0
	fmul.4s	v12, v1, v0
	fmul.4s	v1, v2, v0
	cmp	x1, #128
	cset	w8, lo
	dup.4h	v2, w8
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	mov	w8, #62154                      ; =0xf2ca
	movk	w8, #61769, lsl #16
	dup.4s	v0, w8
	cmlt.4s	v10, v2, #0
	str	q10, [sp, #4272]                ; 16-byte Spill
	bif.16b	v27, v0, v10
	str	q27, [sp, #4448]                ; 16-byte Spill
	mov.16b	v24, v10
	bsl.16b	v24, v30, v0
	str	q24, [sp, #4432]                ; 16-byte Spill
	mov.16b	v3, v10
	bsl.16b	v3, v20, v0
	str	q3, [sp, #4400]                 ; 16-byte Spill
	mov.16b	v7, v10
	bsl.16b	v7, v13, v0
	str	q7, [sp, #4384]                 ; 16-byte Spill
	mov.16b	v31, v10
	bsl.16b	v31, v18, v0
	str	q31, [sp, #4336]                ; 16-byte Spill
	mov.16b	v23, v10
	bsl.16b	v23, v29, v0
	str	q23, [sp, #4320]                ; 16-byte Spill
	mov.16b	v29, v10
	bsl.16b	v29, v19, v0
	str	q29, [sp, #4304]                ; 16-byte Spill
	mov.16b	v30, v10
	bsl.16b	v30, v25, v0
	str	q30, [sp, #4288]                ; 16-byte Spill
	mov.16b	v25, v10
	bsl.16b	v25, v21, v0
	str	q25, [sp, #4368]                ; 16-byte Spill
	bif.16b	v28, v0, v10
	str	q28, [sp, #4352]                ; 16-byte Spill
	mov.16b	v21, v10
	bsl.16b	v21, v22, v0
	str	q21, [sp, #4464]                ; 16-byte Spill
	mov.16b	v22, v10
	bsl.16b	v22, v26, v0
	str	q22, [sp, #4416]                ; 16-byte Spill
	mov.16b	v19, v10
	bsl.16b	v19, v15, v0
	str	q19, [sp, #4528]                ; 16-byte Spill
	mov.16b	v20, v10
	bsl.16b	v20, v17, v0
	str	q20, [sp, #4496]                ; 16-byte Spill
	mov.16b	v17, v10
	bsl.16b	v17, v16, v0
	str	q17, [sp, #4576]                ; 16-byte Spill
	mov.16b	v18, v10
	bsl.16b	v18, v6, v0
	str	q18, [sp, #4560]                ; 16-byte Spill
	bif.16b	v4, v0, v10
	str	q4, [sp, #4688]                 ; 16-byte Spill
	mov.16b	v16, v10
	bsl.16b	v16, v11, v0
	str	q16, [sp, #4624]                ; 16-byte Spill
	mov.16b	v2, v10
	bsl.16b	v2, v5, v0
	str	q2, [sp, #4736]                 ; 16-byte Spill
	mov.16b	v6, v10
	bsl.16b	v6, v9, v0
	str	q6, [sp, #4720]                 ; 16-byte Spill
	bif.16b	v1, v0, v10
	str	q1, [sp, #4768]                 ; 16-byte Spill
	mov.16b	v5, v10
	bsl.16b	v5, v12, v0
	str	q5, [sp, #4752]                 ; 16-byte Spill
	mvni.4s	v10, #127, msl #16
	ldr	q13, [sp, #4544]                ; 16-byte Reload
	fmaxnm.4s	v0, v13, v10
	ldr	q26, [sp, #4480]                ; 16-byte Reload
	fmaxnm.4s	v0, v0, v26
	fmaxnm.4s	v0, v0, v14
	ldr	q9, [sp, #4864]                 ; 16-byte Reload
	fmaxnm.4s	v0, v0, v9
	fmaxnm.4s	v0, v0, v8
	fmaxnm.4s	v0, v0, v27
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v0, v0, v31
	fmaxnm.4s	v0, v0, v29
	fmaxnm.4s	v0, v0, v25
	fmaxnm.4s	v0, v0, v21
	fmaxnm.4s	v0, v0, v19
	fmaxnm.4s	v0, v0, v17
	fmaxnm.4s	v0, v0, v4
	fmaxnm.4s	v0, v0, v2
	fmaxnm.4s	v0, v0, v1
	ldr	q1, [sp, #4896]                 ; 16-byte Reload
	fmaxnm.4s	v11, v1, v0
	mov	w8, #-1026555904                ; =0xc2d00000
	dup.4s	v2, w8
	fsub.4s	v0, v13, v11
	fcmge.4s	v1, v0, v2
	mov	w8, #1120403456                 ; =0x42c80000
	dup.4s	v3, w8
	fcmge.4s	v4, v3, v0
	and.16b	v1, v1, v4
	ldr	q27, [sp, #4656]                ; 16-byte Reload
	fmaxnm.4s	v4, v27, v10
	ldr	q9, [sp, #4640]                 ; 16-byte Reload
	fmaxnm.4s	v4, v4, v9
	ldr	q31, [sp, #4592]                ; 16-byte Reload
	fmaxnm.4s	v4, v4, v31
	ldr	q17, [sp, #4848]                ; 16-byte Reload
	fmaxnm.4s	v4, v4, v17
	ldr	q17, [sp, #4880]                ; 16-byte Reload
	fmaxnm.4s	v4, v4, v17
	fmaxnm.4s	v4, v4, v24
	fmaxnm.4s	v4, v4, v7
	fmaxnm.4s	v4, v4, v23
	fmaxnm.4s	v4, v4, v30
	fmaxnm.4s	v4, v4, v28
	fmaxnm.4s	v4, v4, v22
	fmaxnm.4s	v4, v4, v20
	fmaxnm.4s	v4, v4, v18
	fmaxnm.4s	v4, v4, v16
	fmaxnm.4s	v4, v4, v6
	fmaxnm.4s	v4, v4, v5
	ldr	q5, [sp, #4912]                 ; 16-byte Reload
	fmaxnm.4s	v8, v5, v4
	fsub.4s	v4, v27, v8
	fcmge.4s	v5, v4, v2
	fcmge.4s	v6, v3, v4
	and.16b	v5, v5, v6
	and.16b	v6, v5, v4
	mov	w8, #43579                      ; =0xaa3b
	movk	w8, #16312, lsl #16
	dup.4s	v20, w8
	fmul.4s	v7, v6, v20
	movi.4s	v5, #75, lsl #24
	mvni.4s	v17, #128, lsl #24
	mov.16b	v16, v17
	bsl.16b	v16, v5, v7
	fadd.4s	v7, v7, v16
	fsub.4s	v7, v7, v16
	and.16b	v1, v1, v0
	fmul.4s	v16, v1, v20
	bsl.16b	v17, v5, v16
	mvni.4s	v14, #128, lsl #24
	movi.4s	v12, #75, lsl #24
	fadd.4s	v16, v16, v17
	fsub.4s	v16, v16, v17
	fcvtzs.4s	v19, v7
	mov	w8, #29184                      ; =0x7200
	movk	w8, #16177, lsl #16
	dup.4s	v21, w8
	scvtf.4s	v7, v19
	fmul.4s	v17, v7, v21
	fsub.4s	v6, v6, v17
	fcvtzs.4s	v22, v16
	scvtf.4s	v16, v22
	fmul.4s	v17, v16, v21
	fsub.4s	v1, v1, v17
	mov	w8, #48782                      ; =0xbe8e
	movk	w8, #13759, lsl #16
	dup.4s	v15, w8
	fmul.4s	v16, v16, v15
	fsub.4s	v1, v1, v16
	fmul.4s	v7, v7, v15
	fsub.4s	v23, v6, v7
	mov	w8, #11226                      ; =0x2bda
	movk	w8, #14672, lsl #16
	dup.4s	v7, w8
	fmul.4s	v6, v23, v7
	mov	w8, #38601                      ; =0x96c9
	movk	w8, #15030, lsl #16
	dup.4s	v16, w8
	fadd.4s	v6, v6, v16
	fmul.4s	v6, v23, v6
	mov	w8, #34982                      ; =0x88a6
	movk	w8, #15368, lsl #16
	dup.4s	v17, w8
	fadd.4s	v6, v6, v17
	fmul.4s	v24, v23, v6
	mov	w8, #43642                      ; =0xaa7a
	movk	w8, #15658, lsl #16
	dup.4s	v25, w8
	fadd.4s	v24, v24, v25
	fmul.4s	v24, v23, v24
	mov	w8, #43691                      ; =0xaaab
	movk	w8, #15914, lsl #16
	dup.4s	v18, w8
	fadd.4s	v24, v24, v18
	fmul.4s	v24, v23, v24
	movi.4s	v5, #63, lsl #24
	fadd.4s	v24, v24, v5
	movi.4s	v30, #63, lsl #24
	fmul.4s	v28, v23, v23
	fmul.4s	v24, v28, v24
	fmul.4s	v28, v1, v7
	fadd.4s	v28, v28, v16
	fmul.4s	v28, v1, v28
	fadd.4s	v28, v28, v17
	fmul.4s	v28, v1, v28
	fadd.4s	v28, v28, v25
	fmul.4s	v28, v1, v28
	fadd.4s	v28, v28, v18
	fmul.4s	v28, v1, v28
	fadd.4s	v28, v28, v30
	fmul.4s	v29, v1, v1
	fmul.4s	v28, v29, v28
	fadd.4s	v1, v1, v28
	fadd.4s	v23, v23, v24
	fmov.4s	v5, #1.00000000
	fadd.4s	v1, v1, v5
	sshr.4s	v24, v22, #1
	shl.4s	v28, v24, #23
	add.4s	v28, v28, v5
	fmul.4s	v1, v1, v28
	fadd.4s	v23, v23, v5
	sshr.4s	v28, v19, #1
	shl.4s	v29, v28, #23
	add.4s	v29, v29, v5
	fmul.4s	v23, v23, v29
	sub.4s	v22, v22, v24
	sub.4s	v19, v19, v28
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v5
	fmul.4s	v19, v23, v19
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v5
	fmul.4s	v1, v1, v22
	fcmgt.4s	v22, v2, v0
	bic.16b	v1, v1, v22
	fcmgt.4s	v22, v2, v4
	bic.16b	v22, v19, v22
	fcmgt.4s	v23, v4, v3
	fneg.4s	v6, v10
	bit.16b	v22, v6, v23
	fcmgt.4s	v23, v0, v3
	bit.16b	v1, v6, v23
	fcmeq.4s	v0, v0, v0
	ldr	q19, [sp, #4816]                ; 16-byte Reload
	bsl.16b	v0, v1, v19
	str	q0, [sp, #4704]                 ; 16-byte Spill
	fcmeq.4s	v0, v4, v4
	bsl.16b	v0, v22, v19
	str	q0, [sp, #4672]                 ; 16-byte Spill
	fsub.4s	v0, v26, v11
	fcmge.4s	v1, v0, v2
	fcmge.4s	v4, v3, v0
	and.16b	v1, v1, v4
	fsub.4s	v4, v9, v8
	fcmge.4s	v22, v4, v2
	fcmge.4s	v23, v3, v4
	and.16b	v22, v22, v23
	and.16b	v22, v22, v4
	fmul.4s	v23, v22, v20
	mov.16b	v24, v14
	bsl.16b	v24, v12, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v1, v1, v0
	fmul.4s	v24, v1, v20
	mov.16b	v28, v14
	bsl.16b	v28, v12, v24
	fadd.4s	v24, v24, v28
	fsub.4s	v24, v24, v28
	fcvtzs.4s	v23, v23
	scvtf.4s	v28, v23
	fmul.4s	v29, v28, v21
	fsub.4s	v22, v22, v29
	ldr	x8, [sp, #1096]                 ; 8-byte Reload
	stp	q27, q13, [x8]
	fcvtzs.4s	v24, v24
	scvtf.4s	v29, v24
	fmul.4s	v14, v29, v21
	fsub.4s	v1, v1, v14
	ldr	x8, [sp, #1088]                 ; 8-byte Reload
	stp	q9, q26, [x8]
	fmul.4s	v29, v29, v15
	fsub.4s	v1, v1, v29
	fmul.4s	v28, v28, v15
	fsub.4s	v22, v22, v28
	fmul.4s	v28, v22, v7
	fadd.4s	v28, v28, v16
	fmul.4s	v28, v22, v28
	fadd.4s	v28, v28, v17
	fmul.4s	v28, v22, v28
	fadd.4s	v28, v28, v25
	fmul.4s	v28, v22, v28
	fadd.4s	v28, v28, v18
	fmul.4s	v28, v22, v28
	fadd.4s	v28, v28, v30
	fmul.4s	v29, v22, v22
	fmul.4s	v28, v29, v28
	fmul.4s	v29, v1, v7
	fadd.4s	v29, v29, v16
	fmul.4s	v29, v1, v29
	fadd.4s	v29, v29, v17
	fmul.4s	v29, v1, v29
	fadd.4s	v29, v29, v25
	fmul.4s	v29, v1, v29
	fadd.4s	v29, v29, v18
	fmul.4s	v29, v1, v29
	fadd.4s	v29, v29, v30
	fmul.4s	v9, v1, v1
	fmul.4s	v29, v9, v29
	fadd.4s	v1, v1, v29
	fadd.4s	v22, v22, v28
	fadd.4s	v1, v1, v5
	sshr.4s	v28, v24, #1
	shl.4s	v29, v28, #23
	add.4s	v29, v29, v5
	fmul.4s	v1, v1, v29
	fadd.4s	v22, v22, v5
	sshr.4s	v29, v23, #1
	shl.4s	v9, v29, #23
	add.4s	v9, v9, v5
	fmul.4s	v22, v22, v9
	sub.4s	v24, v24, v28
	sub.4s	v23, v23, v29
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v5
	fmul.4s	v22, v22, v23
	shl.4s	v23, v24, #23
	add.4s	v23, v23, v5
	fmul.4s	v1, v1, v23
	fcmgt.4s	v23, v2, v0
	bic.16b	v1, v1, v23
	fcmgt.4s	v23, v2, v4
	bic.16b	v22, v22, v23
	fcmgt.4s	v23, v4, v3
	bit.16b	v22, v6, v23
	fcmgt.4s	v23, v0, v3
	bit.16b	v1, v6, v23
	fcmeq.4s	v0, v0, v0
	bsl.16b	v0, v1, v19
	str	q0, [sp, #4656]                 ; 16-byte Spill
	fcmeq.4s	v0, v4, v4
	bsl.16b	v0, v22, v19
	str	q0, [sp, #4640]                 ; 16-byte Spill
	mov.16b	v9, v11
	ldr	q22, [sp, #4608]                ; 16-byte Reload
	fsub.4s	v0, v22, v11
	fcmge.4s	v1, v0, v2
	fcmge.4s	v4, v3, v0
	and.16b	v4, v1, v4
	ldr	x8, [sp, #1048]                 ; 8-byte Reload
	stp	q31, q22, [x8]
	fsub.4s	v1, v31, v8
	fcmge.4s	v22, v1, v2
	fcmge.4s	v23, v3, v1
	and.16b	v22, v22, v23
	and.16b	v22, v22, v1
	fmul.4s	v23, v22, v20
	mvni.4s	v26, #128, lsl #24
	movi.4s	v28, #75, lsl #24
	mov.16b	v24, v26
	bsl.16b	v24, v28, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v4, v4, v0
	fmul.4s	v24, v4, v20
	bif.16b	v28, v24, v26
	movi.4s	v26, #75, lsl #24
	mvni.4s	v31, #128, lsl #24
	fadd.4s	v24, v24, v28
	fsub.4s	v24, v24, v28
	fcvtzs.4s	v23, v23
	scvtf.4s	v28, v23
	fmul.4s	v29, v28, v21
	fsub.4s	v22, v22, v29
	fcvtzs.4s	v24, v24
	scvtf.4s	v29, v24
	fmul.4s	v11, v29, v21
	fsub.4s	v4, v4, v11
	fmul.4s	v29, v29, v15
	fsub.4s	v4, v4, v29
	fmul.4s	v28, v28, v15
	fsub.4s	v22, v22, v28
	fmul.4s	v28, v22, v7
	fadd.4s	v28, v28, v16
	fmul.4s	v28, v22, v28
	fadd.4s	v28, v28, v17
	fmul.4s	v28, v22, v28
	fadd.4s	v28, v28, v25
	fmul.4s	v28, v22, v28
	fadd.4s	v28, v28, v18
	fmul.4s	v28, v22, v28
	fadd.4s	v28, v28, v30
	fmul.4s	v29, v22, v22
	fmul.4s	v28, v29, v28
	fmul.4s	v29, v4, v7
	fadd.4s	v29, v29, v16
	fmul.4s	v29, v4, v29
	fadd.4s	v29, v29, v17
	fmul.4s	v29, v4, v29
	fadd.4s	v29, v29, v25
	fmul.4s	v29, v4, v29
	fadd.4s	v29, v29, v18
	fmul.4s	v29, v4, v29
	fadd.4s	v29, v29, v30
	fmul.4s	v11, v4, v4
	fmul.4s	v29, v11, v29
	fadd.4s	v4, v4, v29
	fadd.4s	v22, v22, v28
	fadd.4s	v4, v4, v5
	sshr.4s	v28, v24, #1
	shl.4s	v29, v28, #23
	add.4s	v29, v29, v5
	fmul.4s	v4, v4, v29
	fadd.4s	v22, v22, v5
	sshr.4s	v29, v23, #1
	shl.4s	v11, v29, #23
	add.4s	v11, v11, v5
	fmul.4s	v22, v22, v11
	sub.4s	v24, v24, v28
	sub.4s	v23, v23, v29
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v5
	fmul.4s	v22, v22, v23
	shl.4s	v23, v24, #23
	add.4s	v23, v23, v5
	fmul.4s	v4, v4, v23
	fcmgt.4s	v23, v2, v0
	bic.16b	v4, v4, v23
	fcmgt.4s	v23, v2, v1
	bic.16b	v22, v22, v23
	fcmgt.4s	v23, v1, v3
	bit.16b	v22, v6, v23
	fcmgt.4s	v23, v0, v3
	bit.16b	v4, v6, v23
	fcmeq.4s	v0, v0, v0
	bsl.16b	v0, v4, v19
	str	q0, [sp, #4608]                 ; 16-byte Spill
	fcmeq.4s	v0, v1, v1
	bsl.16b	v0, v22, v19
	str	q0, [sp, #4592]                 ; 16-byte Spill
	ldr	q22, [sp, #4864]                ; 16-byte Reload
	fsub.4s	v0, v22, v9
	mov.16b	v11, v9
	fcmge.4s	v1, v0, v2
	fcmge.4s	v4, v3, v0
	and.16b	v4, v1, v4
	ldr	x8, [sp, #1040]                 ; 8-byte Reload
	ldr	q1, [sp, #4848]                 ; 16-byte Reload
	stp	q1, q22, [x8]
	fsub.4s	v1, v1, v8
	fcmge.4s	v22, v1, v2
	fcmge.4s	v23, v3, v1
	and.16b	v22, v22, v23
	and.16b	v22, v22, v1
	fmul.4s	v23, v22, v20
	mov.16b	v24, v31
	bsl.16b	v24, v26, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v4, v4, v0
	fmul.4s	v24, v4, v20
	mov.16b	v29, v31
	bsl.16b	v29, v26, v24
	fadd.4s	v24, v24, v29
	fsub.4s	v24, v24, v29
	fcvtzs.4s	v23, v23
	scvtf.4s	v29, v23
	fmul.4s	v12, v29, v21
	fsub.4s	v22, v22, v12
	fcvtzs.4s	v24, v24
	scvtf.4s	v12, v24
	fmul.4s	v13, v12, v21
	fsub.4s	v4, v4, v13
	fmul.4s	v12, v12, v15
	fsub.4s	v4, v4, v12
	fmul.4s	v29, v29, v15
	fsub.4s	v22, v22, v29
	fmul.4s	v29, v22, v7
	fadd.4s	v29, v29, v16
	fmul.4s	v29, v22, v29
	fadd.4s	v29, v29, v17
	fmul.4s	v29, v22, v29
	fadd.4s	v29, v29, v25
	fmul.4s	v29, v22, v29
	fadd.4s	v29, v29, v18
	fmul.4s	v29, v22, v29
	fadd.4s	v29, v29, v30
	fmul.4s	v12, v22, v22
	fmul.4s	v29, v12, v29
	fmul.4s	v12, v4, v7
	fadd.4s	v12, v12, v16
	fmul.4s	v12, v4, v12
	fadd.4s	v12, v12, v17
	fmul.4s	v12, v4, v12
	fadd.4s	v12, v12, v25
	fmul.4s	v12, v4, v12
	fadd.4s	v12, v12, v18
	fmul.4s	v12, v4, v12
	fadd.4s	v12, v12, v30
	fmul.4s	v13, v4, v4
	fmul.4s	v12, v13, v12
	fadd.4s	v4, v4, v12
	fadd.4s	v22, v22, v29
	fadd.4s	v4, v4, v5
	sshr.4s	v29, v24, #1
	shl.4s	v12, v29, #23
	add.4s	v12, v12, v5
	fmul.4s	v4, v4, v12
	fadd.4s	v22, v22, v5
	sshr.4s	v12, v23, #1
	shl.4s	v13, v12, #23
	add.4s	v13, v13, v5
	fmul.4s	v22, v22, v13
	sub.4s	v24, v24, v29
	sub.4s	v23, v23, v12
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v5
	fmul.4s	v22, v22, v23
	shl.4s	v23, v24, #23
	add.4s	v23, v23, v5
	fmul.4s	v4, v4, v23
	fcmgt.4s	v23, v2, v0
	bic.16b	v4, v4, v23
	fcmgt.4s	v23, v2, v1
	bic.16b	v22, v22, v23
	fcmgt.4s	v23, v1, v3
	bit.16b	v22, v6, v23
	fcmgt.4s	v23, v0, v3
	bit.16b	v4, v6, v23
	fcmeq.4s	v0, v0, v0
	bsl.16b	v0, v4, v19
	str	q0, [sp, #4848]                 ; 16-byte Spill
	fcmeq.4s	v0, v1, v1
	bsl.16b	v0, v22, v19
	str	q0, [sp, #4544]                 ; 16-byte Spill
	ldr	q22, [sp, #4512]                ; 16-byte Reload
	fsub.4s	v0, v22, v9
	fcmge.4s	v1, v0, v2
	fcmge.4s	v4, v3, v0
	and.16b	v4, v1, v4
	ldr	x8, [sp, #1000]                 ; 8-byte Reload
	ldr	q1, [sp, #4880]                 ; 16-byte Reload
	stp	q1, q22, [x8]
	mov.16b	v28, v8
	fsub.4s	v1, v1, v8
	fcmge.4s	v22, v1, v2
	fcmge.4s	v23, v3, v1
	and.16b	v22, v22, v23
	and.16b	v22, v22, v1
	fmul.4s	v23, v22, v20
	mov.16b	v24, v31
	bsl.16b	v24, v26, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v4, v4, v0
	fmul.4s	v24, v4, v20
	mov.16b	v29, v31
	bsl.16b	v29, v26, v24
	movi.4s	v8, #75, lsl #24
	fadd.4s	v24, v24, v29
	fsub.4s	v24, v24, v29
	fcvtzs.4s	v23, v23
	scvtf.4s	v29, v23
	fmul.4s	v14, v29, v21
	fsub.4s	v22, v22, v14
	fcvtzs.4s	v24, v24
	scvtf.4s	v14, v24
	fmul.4s	v9, v14, v21
	fsub.4s	v4, v4, v9
	fmul.4s	v9, v14, v15
	fsub.4s	v4, v4, v9
	fmul.4s	v29, v29, v15
	fsub.4s	v22, v22, v29
	fmul.4s	v29, v22, v7
	fadd.4s	v29, v29, v16
	fmul.4s	v29, v22, v29
	fadd.4s	v29, v29, v17
	fmul.4s	v29, v22, v29
	fadd.4s	v29, v29, v25
	fmul.4s	v29, v22, v29
	fadd.4s	v29, v29, v18
	fmul.4s	v29, v22, v29
	movi.4s	v26, #63, lsl #24
	fadd.4s	v29, v29, v26
	fmul.4s	v9, v22, v22
	fmul.4s	v29, v9, v29
	fmul.4s	v9, v4, v7
	fadd.4s	v9, v9, v16
	fmul.4s	v9, v4, v9
	fadd.4s	v9, v9, v17
	fmul.4s	v9, v4, v9
	fadd.4s	v9, v9, v25
	fmul.4s	v9, v4, v9
	fadd.4s	v9, v9, v18
	fmul.4s	v9, v4, v9
	fadd.4s	v9, v9, v26
	fmul.4s	v14, v4, v4
	fmul.4s	v9, v14, v9
	fadd.4s	v4, v4, v9
	fadd.4s	v22, v22, v29
	fadd.4s	v4, v4, v5
	sshr.4s	v29, v24, #1
	shl.4s	v9, v29, #23
	add.4s	v9, v9, v5
	fmul.4s	v4, v4, v9
	fadd.4s	v22, v22, v5
	sshr.4s	v9, v23, #1
	shl.4s	v14, v9, #23
	add.4s	v14, v14, v5
	fmul.4s	v22, v22, v14
	sub.4s	v24, v24, v29
	sub.4s	v23, v23, v9
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v5
	fmul.4s	v22, v22, v23
	shl.4s	v23, v24, #23
	add.4s	v23, v23, v5
	fmul.4s	v4, v4, v23
	fcmgt.4s	v23, v2, v0
	bic.16b	v4, v4, v23
	fcmgt.4s	v23, v2, v1
	bic.16b	v22, v22, v23
	fcmgt.4s	v23, v1, v3
	bit.16b	v22, v6, v23
	fcmgt.4s	v23, v0, v3
	bit.16b	v4, v6, v23
	fcmeq.4s	v0, v0, v0
	bsl.16b	v0, v4, v19
	str	q0, [sp, #4512]                 ; 16-byte Spill
	fcmeq.4s	v0, v1, v1
	bsl.16b	v0, v22, v19
	str	q0, [sp, #4480]                 ; 16-byte Spill
	ldr	q4, [sp, #4432]                 ; 16-byte Reload
	fsub.4s	v0, v4, v28
	fcmge.4s	v1, v0, v2
	fcmge.4s	v22, v3, v0
	and.16b	v22, v1, v22
	ldr	x8, [sp, #992]                  ; 8-byte Reload
	ldr	q1, [sp, #4448]                 ; 16-byte Reload
	stp	q4, q1, [x8]
	fsub.4s	v1, v1, v11
	fcmge.4s	v24, v1, v2
	fcmge.4s	v26, v3, v1
	and.16b	v24, v24, v26
	and.16b	v24, v24, v1
	fmul.4s	v26, v24, v20
	mov.16b	v29, v31
	bsl.16b	v29, v8, v26
	fadd.4s	v26, v26, v29
	fsub.4s	v26, v26, v29
	and.16b	v22, v22, v0
	fmul.4s	v29, v22, v20
	bsl.16b	v31, v8, v29
	fadd.4s	v29, v29, v31
	fsub.4s	v29, v29, v31
	fcvtzs.4s	v26, v26
	scvtf.4s	v31, v26
	fmul.4s	v9, v31, v21
	fsub.4s	v24, v24, v9
	fcvtzs.4s	v29, v29
	scvtf.4s	v9, v29
	fmul.4s	v14, v9, v21
	fsub.4s	v22, v22, v14
	fmul.4s	v9, v9, v15
	fsub.4s	v22, v22, v9
	fmul.4s	v31, v31, v15
	fsub.4s	v24, v24, v31
	fmul.4s	v31, v24, v7
	fadd.4s	v31, v31, v16
	fmul.4s	v31, v24, v31
	fadd.4s	v31, v31, v17
	fmul.4s	v31, v24, v31
	fadd.4s	v31, v31, v25
	fmul.4s	v31, v24, v31
	fadd.4s	v31, v31, v18
	fmul.4s	v31, v24, v31
	fadd.4s	v31, v31, v30
	fmul.4s	v9, v24, v24
	fmul.4s	v31, v9, v31
	fmul.4s	v9, v22, v7
	fadd.4s	v9, v9, v16
	fmul.4s	v9, v22, v9
	fadd.4s	v9, v9, v17
	fmul.4s	v9, v22, v9
	fadd.4s	v9, v9, v25
	fmul.4s	v9, v22, v9
	fadd.4s	v9, v9, v18
	fmul.4s	v9, v22, v9
	fadd.4s	v9, v9, v30
	fmul.4s	v14, v22, v22
	fmul.4s	v9, v14, v9
	fadd.4s	v22, v22, v9
	fadd.4s	v24, v24, v31
	fadd.4s	v22, v22, v5
	sshr.4s	v31, v29, #1
	shl.4s	v9, v31, #23
	add.4s	v9, v9, v5
	fmul.4s	v22, v22, v9
	fadd.4s	v24, v24, v5
	sshr.4s	v9, v26, #1
	shl.4s	v14, v9, #23
	add.4s	v14, v14, v5
	fmul.4s	v24, v24, v14
	sub.4s	v29, v29, v31
	sub.4s	v26, v26, v9
	shl.4s	v26, v26, #23
	add.4s	v26, v26, v5
	fmul.4s	v24, v24, v26
	shl.4s	v26, v29, #23
	add.4s	v26, v26, v5
	fmul.4s	v22, v22, v26
	fcmgt.4s	v26, v2, v0
	bic.16b	v22, v22, v26
	fcmgt.4s	v26, v2, v1
	bic.16b	v24, v24, v26
	fcmgt.4s	v26, v1, v3
	bit.16b	v24, v6, v26
	fcmgt.4s	v26, v0, v3
	bit.16b	v22, v6, v26
	fcmeq.4s	v0, v0, v0
	bsl.16b	v0, v22, v19
	str	q0, [sp, #4432]                 ; 16-byte Spill
	fcmeq.4s	v0, v1, v1
	bsl.16b	v0, v24, v19
	str	q0, [sp, #4448]                 ; 16-byte Spill
	ldr	q4, [sp, #4384]                 ; 16-byte Reload
	fsub.4s	v0, v4, v28
	fcmge.4s	v1, v0, v2
	fcmge.4s	v22, v3, v0
	and.16b	v22, v1, v22
	ldr	x8, [sp, #952]                  ; 8-byte Reload
	ldr	q1, [sp, #4400]                 ; 16-byte Reload
	stp	q4, q1, [x8]
	mov.16b	v4, v11
	fsub.4s	v1, v1, v11
	fcmge.4s	v24, v1, v2
	fcmge.4s	v26, v3, v1
	and.16b	v24, v24, v26
	and.16b	v24, v24, v1
	fmul.4s	v26, v24, v20
	mvni.4s	v23, #128, lsl #24
	movi.4s	v29, #75, lsl #24
	mov.16b	v27, v23
	bsl.16b	v27, v29, v26
	fadd.4s	v26, v26, v27
	fsub.4s	v26, v26, v27
	and.16b	v22, v22, v0
	fmul.4s	v27, v22, v20
	bif.16b	v29, v27, v23
	movi.4s	v23, #75, lsl #24
	mvni.4s	v13, #128, lsl #24
	fadd.4s	v27, v27, v29
	fsub.4s	v27, v27, v29
	fcvtzs.4s	v26, v26
	scvtf.4s	v29, v26
	fmul.4s	v30, v29, v21
	fsub.4s	v24, v24, v30
	fcvtzs.4s	v27, v27
	scvtf.4s	v30, v27
	fmul.4s	v31, v30, v21
	fsub.4s	v22, v22, v31
	fmul.4s	v30, v30, v15
	fsub.4s	v22, v22, v30
	fmul.4s	v29, v29, v15
	fsub.4s	v24, v24, v29
	fmul.4s	v29, v24, v7
	fadd.4s	v29, v29, v16
	fmul.4s	v29, v24, v29
	fadd.4s	v29, v29, v17
	fmul.4s	v29, v24, v29
	fadd.4s	v29, v29, v25
	fmul.4s	v29, v24, v29
	mov.16b	v31, v18
	fadd.4s	v29, v29, v18
	fmul.4s	v29, v24, v29
	movi.4s	v18, #63, lsl #24
	fadd.4s	v29, v29, v18
	fmul.4s	v30, v24, v24
	fmul.4s	v29, v30, v29
	fmul.4s	v30, v22, v7
	mov.16b	v12, v7
	fadd.4s	v30, v30, v16
	mov.16b	v11, v16
	fmul.4s	v30, v22, v30
	fadd.4s	v30, v30, v17
	mov.16b	v16, v17
	fmul.4s	v30, v22, v30
	fadd.4s	v30, v30, v25
	mov.16b	v17, v25
	fmul.4s	v30, v22, v30
	fadd.4s	v30, v30, v31
	mov.16b	v7, v31
	fmul.4s	v30, v22, v30
	fadd.4s	v30, v30, v18
	movi.4s	v8, #63, lsl #24
	fmul.4s	v31, v22, v22
	fmul.4s	v30, v31, v30
	fadd.4s	v22, v22, v30
	fadd.4s	v24, v24, v29
	fadd.4s	v22, v22, v5
	sshr.4s	v29, v27, #1
	shl.4s	v30, v29, #23
	add.4s	v30, v30, v5
	fmul.4s	v22, v22, v30
	fadd.4s	v24, v24, v5
	sshr.4s	v30, v26, #1
	shl.4s	v31, v30, #23
	add.4s	v31, v31, v5
	fmul.4s	v24, v24, v31
	sub.4s	v27, v27, v29
	sub.4s	v26, v26, v30
	shl.4s	v26, v26, #23
	add.4s	v26, v26, v5
	fmul.4s	v24, v24, v26
	shl.4s	v26, v27, #23
	add.4s	v26, v26, v5
	fmul.4s	v22, v22, v26
	fcmgt.4s	v26, v2, v0
	bic.16b	v22, v22, v26
	fcmgt.4s	v26, v2, v1
	bic.16b	v24, v24, v26
	fcmgt.4s	v26, v1, v3
	bit.16b	v24, v6, v26
	fcmgt.4s	v26, v0, v3
	bit.16b	v22, v6, v26
	fcmeq.4s	v0, v0, v0
	bsl.16b	v0, v22, v19
	str	q0, [sp, #4384]                 ; 16-byte Spill
	fcmeq.4s	v0, v1, v1
	bsl.16b	v0, v24, v19
	str	q0, [sp, #4400]                 ; 16-byte Spill
	ldr	q18, [sp, #4320]                ; 16-byte Reload
	fsub.4s	v0, v18, v28
	fcmge.4s	v1, v0, v2
	fcmge.4s	v22, v3, v0
	and.16b	v22, v1, v22
	ldr	x8, [sp, #944]                  ; 8-byte Reload
	ldr	q1, [sp, #4336]                 ; 16-byte Reload
	stp	q18, q1, [x8]
	fsub.4s	v1, v1, v4
	fcmge.4s	v18, v1, v2
	fcmge.4s	v24, v3, v1
	and.16b	v18, v18, v24
	and.16b	v18, v18, v1
	fmul.4s	v24, v18, v20
	mov.16b	v26, v13
	bsl.16b	v26, v23, v24
	fadd.4s	v24, v24, v26
	fsub.4s	v24, v24, v26
	and.16b	v22, v22, v0
	fmul.4s	v26, v22, v20
	mov.16b	v27, v13
	bsl.16b	v27, v23, v26
	fadd.4s	v26, v26, v27
	fsub.4s	v26, v26, v27
	fcvtzs.4s	v24, v24
	scvtf.4s	v27, v24
	fmul.4s	v29, v27, v21
	fsub.4s	v18, v18, v29
	fcvtzs.4s	v26, v26
	scvtf.4s	v29, v26
	fmul.4s	v30, v29, v21
	fsub.4s	v22, v22, v30
	fmul.4s	v29, v29, v15
	fsub.4s	v22, v22, v29
	fmul.4s	v27, v27, v15
	fsub.4s	v18, v18, v27
	fmul.4s	v27, v18, v12
	fadd.4s	v27, v27, v11
	fmul.4s	v27, v18, v27
	fadd.4s	v27, v27, v16
	fmul.4s	v27, v18, v27
	fadd.4s	v27, v27, v25
	fmul.4s	v27, v18, v27
	fadd.4s	v27, v27, v7
	fmul.4s	v27, v18, v27
	fadd.4s	v27, v27, v8
	fmul.4s	v29, v18, v18
	fmul.4s	v27, v29, v27
	fmul.4s	v29, v22, v12
	fadd.4s	v29, v29, v11
	fmul.4s	v29, v22, v29
	fadd.4s	v29, v29, v16
	fmul.4s	v29, v22, v29
	fadd.4s	v29, v29, v25
	fmul.4s	v29, v22, v29
	fadd.4s	v29, v29, v7
	fmul.4s	v29, v22, v29
	fadd.4s	v29, v29, v8
	fmul.4s	v30, v22, v22
	fmul.4s	v29, v30, v29
	fadd.4s	v22, v22, v29
	fadd.4s	v18, v18, v27
	fadd.4s	v22, v22, v5
	sshr.4s	v27, v26, #1
	shl.4s	v29, v27, #23
	add.4s	v29, v29, v5
	fmul.4s	v22, v22, v29
	fadd.4s	v18, v18, v5
	sshr.4s	v29, v24, #1
	shl.4s	v30, v29, #23
	add.4s	v30, v30, v5
	fmul.4s	v18, v18, v30
	sub.4s	v26, v26, v27
	sub.4s	v24, v24, v29
	shl.4s	v24, v24, #23
	add.4s	v24, v24, v5
	fmul.4s	v18, v18, v24
	shl.4s	v24, v26, #23
	add.4s	v24, v24, v5
	fmul.4s	v22, v22, v24
	fcmgt.4s	v24, v2, v0
	bic.16b	v22, v22, v24
	fcmgt.4s	v24, v2, v1
	bic.16b	v18, v18, v24
	fcmgt.4s	v24, v1, v3
	bit.16b	v18, v6, v24
	fcmgt.4s	v24, v0, v3
	bit.16b	v22, v6, v24
	fcmeq.4s	v0, v0, v0
	bsl.16b	v0, v22, v19
	str	q0, [sp, #4320]                 ; 16-byte Spill
	fcmeq.4s	v0, v1, v1
	bsl.16b	v0, v18, v19
	str	q0, [sp, #4336]                 ; 16-byte Spill
	ldr	q22, [sp, #4288]                ; 16-byte Reload
	fsub.4s	v0, v22, v28
	fcmge.4s	v1, v0, v2
	fcmge.4s	v18, v3, v0
	and.16b	v18, v1, v18
	ldr	x8, [sp, #904]                  ; 8-byte Reload
	ldr	q1, [sp, #4304]                 ; 16-byte Reload
	stp	q22, q1, [x8]
	fsub.4s	v1, v1, v4
	fcmge.4s	v22, v1, v2
	fcmge.4s	v24, v3, v1
	and.16b	v22, v22, v24
	and.16b	v22, v22, v1
	fmul.4s	v24, v22, v20
	mov.16b	v25, v13
	bsl.16b	v25, v23, v24
	fadd.4s	v24, v24, v25
	fsub.4s	v24, v24, v25
	and.16b	v18, v18, v0
	fmul.4s	v25, v18, v20
	mov.16b	v26, v13
	bsl.16b	v26, v23, v25
	fadd.4s	v25, v25, v26
	fsub.4s	v25, v25, v26
	fcvtzs.4s	v24, v24
	scvtf.4s	v26, v24
	fmul.4s	v27, v26, v21
	fsub.4s	v22, v22, v27
	fcvtzs.4s	v25, v25
	scvtf.4s	v27, v25
	fmul.4s	v29, v27, v21
	fsub.4s	v18, v18, v29
	fmul.4s	v27, v27, v15
	fsub.4s	v18, v18, v27
	fmul.4s	v26, v26, v15
	fsub.4s	v22, v22, v26
	fmul.4s	v26, v22, v12
	fadd.4s	v26, v26, v11
	fmul.4s	v26, v22, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v22, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v22, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v22, v26
	fadd.4s	v26, v26, v8
	fmul.4s	v27, v22, v22
	fmul.4s	v26, v27, v26
	fmul.4s	v27, v18, v12
	fadd.4s	v27, v27, v11
	fmul.4s	v27, v18, v27
	fadd.4s	v27, v27, v16
	fmul.4s	v27, v18, v27
	fadd.4s	v27, v27, v17
	fmul.4s	v27, v18, v27
	fadd.4s	v27, v27, v7
	fmul.4s	v27, v18, v27
	fadd.4s	v27, v27, v8
	fmul.4s	v29, v18, v18
	fmul.4s	v27, v29, v27
	fadd.4s	v18, v18, v27
	fadd.4s	v22, v22, v26
	fadd.4s	v18, v18, v5
	sshr.4s	v26, v25, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v5
	fmul.4s	v18, v18, v27
	fadd.4s	v22, v22, v5
	sshr.4s	v27, v24, #1
	shl.4s	v29, v27, #23
	add.4s	v29, v29, v5
	fmul.4s	v22, v22, v29
	sub.4s	v25, v25, v26
	sub.4s	v24, v24, v27
	shl.4s	v24, v24, #23
	add.4s	v24, v24, v5
	fmul.4s	v22, v22, v24
	shl.4s	v24, v25, #23
	add.4s	v24, v24, v5
	fmul.4s	v18, v18, v24
	fcmgt.4s	v24, v2, v0
	bic.16b	v18, v18, v24
	fcmgt.4s	v24, v2, v1
	bic.16b	v22, v22, v24
	fcmgt.4s	v24, v1, v3
	bit.16b	v22, v6, v24
	fcmgt.4s	v24, v0, v3
	bit.16b	v18, v6, v24
	fcmeq.4s	v0, v0, v0
	bsl.16b	v0, v18, v19
	str	q0, [sp, #4288]                 ; 16-byte Spill
	fcmeq.4s	v0, v1, v1
	bsl.16b	v0, v22, v19
	str	q0, [sp, #4304]                 ; 16-byte Spill
	ldr	q22, [sp, #4352]                ; 16-byte Reload
	fsub.4s	v0, v22, v28
	fcmge.4s	v1, v0, v2
	fcmge.4s	v18, v3, v0
	and.16b	v18, v1, v18
	ldr	x8, [sp, #896]                  ; 8-byte Reload
	ldr	q1, [sp, #4368]                 ; 16-byte Reload
	stp	q22, q1, [x8]
	fsub.4s	v1, v1, v4
	fcmge.4s	v22, v1, v2
	fcmge.4s	v24, v3, v1
	and.16b	v22, v22, v24
	and.16b	v22, v22, v1
	fmul.4s	v24, v22, v20
	mov.16b	v25, v13
	bsl.16b	v25, v23, v24
	fadd.4s	v24, v24, v25
	fsub.4s	v24, v24, v25
	and.16b	v18, v18, v0
	fmul.4s	v25, v18, v20
	mov.16b	v26, v13
	bsl.16b	v26, v23, v25
	fadd.4s	v25, v25, v26
	fsub.4s	v25, v25, v26
	fcvtzs.4s	v24, v24
	scvtf.4s	v26, v24
	fmul.4s	v27, v26, v21
	fsub.4s	v22, v22, v27
	fcvtzs.4s	v25, v25
	scvtf.4s	v27, v25
	fmul.4s	v29, v27, v21
	fsub.4s	v18, v18, v29
	fmul.4s	v27, v27, v15
	fsub.4s	v18, v18, v27
	fmul.4s	v26, v26, v15
	fsub.4s	v22, v22, v26
	fmul.4s	v26, v22, v12
	fadd.4s	v26, v26, v11
	fmul.4s	v26, v22, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v22, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v22, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v22, v26
	fadd.4s	v26, v26, v8
	fmul.4s	v27, v22, v22
	fmul.4s	v26, v27, v26
	fmul.4s	v27, v18, v12
	fadd.4s	v27, v27, v11
	fmul.4s	v27, v18, v27
	fadd.4s	v27, v27, v16
	fmul.4s	v27, v18, v27
	fadd.4s	v27, v27, v17
	fmul.4s	v27, v18, v27
	fadd.4s	v27, v27, v7
	fmul.4s	v27, v18, v27
	fadd.4s	v27, v27, v8
	fmul.4s	v29, v18, v18
	fmul.4s	v27, v29, v27
	fadd.4s	v18, v18, v27
	fadd.4s	v22, v22, v26
	fadd.4s	v18, v18, v5
	sshr.4s	v26, v25, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v5
	fmul.4s	v18, v18, v27
	fadd.4s	v22, v22, v5
	sshr.4s	v27, v24, #1
	shl.4s	v29, v27, #23
	add.4s	v29, v29, v5
	fmul.4s	v22, v22, v29
	sub.4s	v25, v25, v26
	sub.4s	v24, v24, v27
	shl.4s	v24, v24, #23
	add.4s	v24, v24, v5
	fmul.4s	v22, v22, v24
	shl.4s	v24, v25, #23
	add.4s	v24, v24, v5
	fmul.4s	v18, v18, v24
	fcmgt.4s	v24, v2, v0
	bic.16b	v18, v18, v24
	fcmgt.4s	v24, v2, v1
	bic.16b	v22, v22, v24
	fcmgt.4s	v24, v1, v3
	bit.16b	v22, v6, v24
	fcmgt.4s	v24, v0, v3
	bit.16b	v18, v6, v24
	fcmeq.4s	v0, v0, v0
	bsl.16b	v0, v18, v19
	str	q0, [sp, #4352]                 ; 16-byte Spill
	fcmeq.4s	v0, v1, v1
	bsl.16b	v0, v22, v19
	str	q0, [sp, #4368]                 ; 16-byte Spill
	ldr	q22, [sp, #4416]                ; 16-byte Reload
	fsub.4s	v0, v22, v28
	fcmge.4s	v1, v0, v2
	fcmge.4s	v18, v3, v0
	and.16b	v18, v1, v18
	ldr	x8, [sp, #856]                  ; 8-byte Reload
	ldr	q1, [sp, #4464]                 ; 16-byte Reload
	stp	q22, q1, [x8]
	fsub.4s	v1, v1, v4
	fcmge.4s	v22, v1, v2
	fcmge.4s	v24, v3, v1
	and.16b	v22, v22, v24
	and.16b	v22, v22, v1
	fmul.4s	v24, v22, v20
	mov.16b	v25, v13
	bsl.16b	v25, v23, v24
	fadd.4s	v24, v24, v25
	fsub.4s	v24, v24, v25
	and.16b	v18, v18, v0
	fmul.4s	v25, v18, v20
	mov.16b	v26, v13
	bsl.16b	v26, v23, v25
	fadd.4s	v25, v25, v26
	fsub.4s	v25, v25, v26
	fcvtzs.4s	v24, v24
	scvtf.4s	v26, v24
	fmul.4s	v27, v26, v21
	fsub.4s	v22, v22, v27
	fcvtzs.4s	v25, v25
	scvtf.4s	v27, v25
	fmul.4s	v29, v27, v21
	fsub.4s	v18, v18, v29
	fmul.4s	v27, v27, v15
	fsub.4s	v18, v18, v27
	fmul.4s	v26, v26, v15
	fsub.4s	v22, v22, v26
	fmul.4s	v26, v22, v12
	fadd.4s	v26, v26, v11
	fmul.4s	v26, v22, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v22, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v22, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v22, v26
	fadd.4s	v26, v26, v8
	fmul.4s	v27, v22, v22
	fmul.4s	v26, v27, v26
	fmul.4s	v27, v18, v12
	fadd.4s	v27, v27, v11
	fmul.4s	v27, v18, v27
	fadd.4s	v27, v27, v16
	fmul.4s	v27, v18, v27
	fadd.4s	v27, v27, v17
	fmul.4s	v27, v18, v27
	fadd.4s	v27, v27, v7
	fmul.4s	v27, v18, v27
	fadd.4s	v27, v27, v8
	fmul.4s	v29, v18, v18
	fmul.4s	v27, v29, v27
	fadd.4s	v18, v18, v27
	fadd.4s	v22, v22, v26
	fadd.4s	v18, v18, v5
	sshr.4s	v26, v25, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v5
	fmul.4s	v18, v18, v27
	fadd.4s	v22, v22, v5
	sshr.4s	v27, v24, #1
	shl.4s	v29, v27, #23
	add.4s	v29, v29, v5
	fmul.4s	v22, v22, v29
	sub.4s	v25, v25, v26
	sub.4s	v24, v24, v27
	shl.4s	v24, v24, #23
	add.4s	v24, v24, v5
	fmul.4s	v22, v22, v24
	shl.4s	v24, v25, #23
	add.4s	v24, v24, v5
	fmul.4s	v18, v18, v24
	fcmgt.4s	v24, v2, v0
	bic.16b	v18, v18, v24
	fcmgt.4s	v24, v2, v1
	bic.16b	v22, v22, v24
	fcmgt.4s	v24, v1, v3
	bit.16b	v22, v6, v24
	fcmgt.4s	v24, v0, v3
	bit.16b	v18, v6, v24
	fcmeq.4s	v0, v0, v0
	bsl.16b	v0, v18, v19
	str	q0, [sp, #4416]                 ; 16-byte Spill
	fcmeq.4s	v0, v1, v1
	bsl.16b	v0, v22, v19
	str	q0, [sp, #4464]                 ; 16-byte Spill
	ldr	q22, [sp, #4496]                ; 16-byte Reload
	fsub.4s	v0, v22, v28
	fcmge.4s	v1, v0, v2
	fcmge.4s	v18, v3, v0
	and.16b	v18, v1, v18
	ldr	x8, [sp, #848]                  ; 8-byte Reload
	ldr	q1, [sp, #4528]                 ; 16-byte Reload
	stp	q22, q1, [x8]
	fsub.4s	v1, v1, v4
	fcmge.4s	v22, v1, v2
	fcmge.4s	v24, v3, v1
	and.16b	v22, v22, v24
	and.16b	v22, v22, v1
	fmul.4s	v24, v22, v20
	mov.16b	v25, v13
	bsl.16b	v25, v23, v24
	fadd.4s	v24, v24, v25
	fsub.4s	v24, v24, v25
	and.16b	v18, v18, v0
	fmul.4s	v25, v18, v20
	mov.16b	v26, v13
	bsl.16b	v26, v23, v25
	fadd.4s	v25, v25, v26
	fsub.4s	v25, v25, v26
	fcvtzs.4s	v24, v24
	scvtf.4s	v26, v24
	fmul.4s	v27, v26, v21
	fsub.4s	v22, v22, v27
	fcvtzs.4s	v25, v25
	scvtf.4s	v27, v25
	fmul.4s	v29, v27, v21
	fsub.4s	v18, v18, v29
	fmul.4s	v27, v27, v15
	fsub.4s	v18, v18, v27
	fmul.4s	v26, v26, v15
	fsub.4s	v22, v22, v26
	fmul.4s	v26, v22, v12
	fadd.4s	v26, v26, v11
	fmul.4s	v26, v22, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v22, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v22, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v22, v26
	fadd.4s	v26, v26, v8
	fmul.4s	v27, v22, v22
	fmul.4s	v26, v27, v26
	fmul.4s	v27, v18, v12
	fadd.4s	v27, v27, v11
	fmul.4s	v27, v18, v27
	fadd.4s	v27, v27, v16
	fmul.4s	v27, v18, v27
	fadd.4s	v27, v27, v17
	fmul.4s	v27, v18, v27
	fadd.4s	v27, v27, v7
	fmul.4s	v27, v18, v27
	fadd.4s	v27, v27, v8
	fmul.4s	v29, v18, v18
	fmul.4s	v27, v29, v27
	fadd.4s	v18, v18, v27
	fadd.4s	v22, v22, v26
	fadd.4s	v18, v18, v5
	sshr.4s	v26, v25, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v5
	fmul.4s	v18, v18, v27
	fadd.4s	v22, v22, v5
	sshr.4s	v27, v24, #1
	shl.4s	v29, v27, #23
	add.4s	v29, v29, v5
	fmul.4s	v22, v22, v29
	sub.4s	v25, v25, v26
	sub.4s	v24, v24, v27
	shl.4s	v24, v24, #23
	add.4s	v24, v24, v5
	fmul.4s	v22, v22, v24
	shl.4s	v24, v25, #23
	add.4s	v24, v24, v5
	fmul.4s	v18, v18, v24
	fcmgt.4s	v24, v2, v0
	bic.16b	v18, v18, v24
	fcmgt.4s	v24, v2, v1
	bic.16b	v22, v22, v24
	fcmgt.4s	v24, v1, v3
	bit.16b	v22, v6, v24
	fcmgt.4s	v24, v0, v3
	bit.16b	v18, v6, v24
	fcmeq.4s	v0, v0, v0
	bsl.16b	v0, v18, v19
	str	q0, [sp, #4496]                 ; 16-byte Spill
	fcmeq.4s	v0, v1, v1
	bsl.16b	v0, v22, v19
	str	q0, [sp, #4528]                 ; 16-byte Spill
	ldr	q22, [sp, #4560]                ; 16-byte Reload
	fsub.4s	v0, v22, v28
	fcmge.4s	v1, v0, v2
	fcmge.4s	v18, v3, v0
	and.16b	v18, v1, v18
	ldr	x8, [sp, #808]                  ; 8-byte Reload
	ldr	q1, [sp, #4576]                 ; 16-byte Reload
	stp	q22, q1, [x8]
	fsub.4s	v1, v1, v4
	fcmge.4s	v22, v1, v2
	fcmge.4s	v24, v3, v1
	and.16b	v22, v22, v24
	and.16b	v22, v22, v1
	fmul.4s	v24, v22, v20
	mov.16b	v27, v13
	bsl.16b	v27, v23, v24
	fadd.4s	v24, v24, v27
	fsub.4s	v24, v24, v27
	and.16b	v18, v18, v0
	fmul.4s	v27, v18, v20
	mov.16b	v29, v13
	bsl.16b	v29, v23, v27
	fadd.4s	v27, v27, v29
	fsub.4s	v27, v27, v29
	fcvtzs.4s	v24, v24
	scvtf.4s	v29, v24
	fmul.4s	v30, v29, v21
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v27, v27
	scvtf.4s	v30, v27
	fmul.4s	v31, v30, v21
	fsub.4s	v18, v18, v31
	fmul.4s	v30, v30, v15
	fsub.4s	v18, v18, v30
	fmul.4s	v29, v29, v15
	fsub.4s	v22, v22, v29
	fmul.4s	v29, v22, v12
	fadd.4s	v29, v29, v11
	fmul.4s	v29, v22, v29
	fadd.4s	v29, v29, v16
	fmul.4s	v29, v22, v29
	fadd.4s	v29, v29, v17
	fmul.4s	v29, v22, v29
	fadd.4s	v29, v29, v7
	fmul.4s	v29, v22, v29
	fadd.4s	v29, v29, v8
	fmul.4s	v30, v22, v22
	fmul.4s	v29, v30, v29
	fmul.4s	v30, v18, v12
	fadd.4s	v30, v30, v11
	fmul.4s	v30, v18, v30
	fadd.4s	v30, v30, v16
	fmul.4s	v30, v18, v30
	fadd.4s	v30, v30, v17
	fmul.4s	v30, v18, v30
	fadd.4s	v30, v30, v7
	fmul.4s	v30, v18, v30
	fadd.4s	v30, v30, v8
	fmul.4s	v31, v18, v18
	fmul.4s	v30, v31, v30
	fadd.4s	v18, v18, v30
	fadd.4s	v22, v22, v29
	fadd.4s	v18, v18, v5
	sshr.4s	v29, v27, #1
	shl.4s	v30, v29, #23
	add.4s	v30, v30, v5
	fmul.4s	v18, v18, v30
	fadd.4s	v22, v22, v5
	sshr.4s	v30, v24, #1
	shl.4s	v31, v30, #23
	add.4s	v31, v31, v5
	fmul.4s	v22, v22, v31
	sub.4s	v27, v27, v29
	sub.4s	v24, v24, v30
	shl.4s	v24, v24, #23
	add.4s	v24, v24, v5
	fmul.4s	v22, v22, v24
	shl.4s	v24, v27, #23
	add.4s	v24, v24, v5
	fmul.4s	v18, v18, v24
	fcmgt.4s	v24, v2, v0
	bic.16b	v18, v18, v24
	fcmgt.4s	v24, v2, v1
	bic.16b	v22, v22, v24
	fcmgt.4s	v24, v1, v3
	bit.16b	v22, v6, v24
	fcmgt.4s	v24, v0, v3
	bit.16b	v18, v6, v24
	fcmeq.4s	v0, v0, v0
	bsl.16b	v0, v18, v19
	str	q0, [sp, #4560]                 ; 16-byte Spill
	fcmeq.4s	v0, v1, v1
	bsl.16b	v0, v22, v19
	str	q0, [sp, #4576]                 ; 16-byte Spill
	ldr	q22, [sp, #4624]                ; 16-byte Reload
	fsub.4s	v0, v22, v28
	fcmge.4s	v1, v0, v2
	fcmge.4s	v18, v3, v0
	and.16b	v18, v1, v18
	ldr	x8, [sp, #800]                  ; 8-byte Reload
	ldr	q1, [sp, #4688]                 ; 16-byte Reload
	stp	q22, q1, [x8]
	fsub.4s	v1, v1, v4
	fcmge.4s	v22, v1, v2
	fcmge.4s	v24, v3, v1
	and.16b	v22, v22, v24
	and.16b	v22, v22, v1
	fmul.4s	v24, v22, v20
	mov.16b	v27, v13
	bsl.16b	v27, v23, v24
	fadd.4s	v24, v24, v27
	fsub.4s	v24, v24, v27
	and.16b	v18, v18, v0
	fmul.4s	v27, v18, v20
	mov.16b	v29, v13
	bsl.16b	v29, v23, v27
	movi.4s	v25, #75, lsl #24
	fadd.4s	v27, v27, v29
	fsub.4s	v27, v27, v29
	fcvtzs.4s	v24, v24
	scvtf.4s	v29, v24
	fmul.4s	v8, v29, v21
	fsub.4s	v22, v22, v8
	fcvtzs.4s	v27, v27
	scvtf.4s	v8, v27
	fmul.4s	v9, v8, v21
	fsub.4s	v18, v18, v9
	fmul.4s	v8, v8, v15
	fsub.4s	v18, v18, v8
	fmul.4s	v29, v29, v15
	fsub.4s	v22, v22, v29
	fmul.4s	v29, v22, v12
	fadd.4s	v29, v29, v11
	fmul.4s	v29, v22, v29
	fadd.4s	v29, v29, v16
	fmul.4s	v29, v22, v29
	fadd.4s	v29, v29, v17
	fmul.4s	v29, v22, v29
	fadd.4s	v29, v29, v7
	fmul.4s	v29, v22, v29
	movi.4s	v26, #63, lsl #24
	fadd.4s	v29, v29, v26
	fmul.4s	v8, v22, v22
	fmul.4s	v29, v8, v29
	fmul.4s	v8, v18, v12
	fadd.4s	v8, v8, v11
	fmul.4s	v8, v18, v8
	fadd.4s	v8, v8, v16
	fmul.4s	v8, v18, v8
	fadd.4s	v8, v8, v17
	fmul.4s	v8, v18, v8
	fadd.4s	v8, v8, v7
	fmul.4s	v8, v18, v8
	fadd.4s	v8, v8, v26
	movi.4s	v23, #63, lsl #24
	fmul.4s	v9, v18, v18
	fmul.4s	v8, v9, v8
	fadd.4s	v18, v18, v8
	fadd.4s	v22, v22, v29
	fadd.4s	v18, v18, v5
	sshr.4s	v29, v27, #1
	shl.4s	v8, v29, #23
	add.4s	v8, v8, v5
	fmul.4s	v18, v18, v8
	fadd.4s	v22, v22, v5
	sshr.4s	v8, v24, #1
	shl.4s	v9, v8, #23
	add.4s	v9, v9, v5
	fmul.4s	v22, v22, v9
	sub.4s	v27, v27, v29
	sub.4s	v24, v24, v8
	shl.4s	v24, v24, #23
	add.4s	v24, v24, v5
	fmul.4s	v22, v22, v24
	shl.4s	v24, v27, #23
	add.4s	v24, v24, v5
	fmul.4s	v18, v18, v24
	fcmgt.4s	v24, v2, v0
	bic.16b	v18, v18, v24
	fcmgt.4s	v24, v2, v1
	bic.16b	v22, v22, v24
	fcmgt.4s	v24, v1, v3
	bit.16b	v22, v6, v24
	fcmgt.4s	v24, v0, v3
	bit.16b	v18, v6, v24
	fcmeq.4s	v0, v0, v0
	bif.16b	v18, v19, v0
	fcmeq.4s	v0, v1, v1
	mov.16b	v24, v0
	bsl.16b	v24, v22, v19
	ldr	q26, [sp, #4720]                ; 16-byte Reload
	fsub.4s	v0, v26, v28
	fcmge.4s	v1, v0, v2
	fcmge.4s	v22, v3, v0
	and.16b	v1, v1, v22
	ldr	x8, [sp, #760]                  ; 8-byte Reload
	ldr	q22, [sp, #4736]                ; 16-byte Reload
	stp	q26, q22, [x8]
	fsub.4s	v22, v22, v4
	fcmge.4s	v27, v22, v2
	fcmge.4s	v29, v3, v22
	and.16b	v27, v27, v29
	and.16b	v27, v27, v22
	fmul.4s	v29, v27, v20
	mov.16b	v8, v13
	bsl.16b	v8, v25, v29
	fadd.4s	v29, v29, v8
	fsub.4s	v29, v29, v8
	and.16b	v8, v1, v0
	fmul.4s	v1, v8, v20
	mov.16b	v9, v13
	bsl.16b	v9, v25, v1
	fadd.4s	v1, v1, v9
	fsub.4s	v9, v1, v9
	fcvtzs.4s	v1, v29
	scvtf.4s	v29, v1
	fmul.4s	v14, v29, v21
	fsub.4s	v27, v27, v14
	fcvtzs.4s	v9, v9
	scvtf.4s	v14, v9
	fmul.4s	v26, v14, v21
	fsub.4s	v26, v8, v26
	fmul.4s	v8, v14, v15
	fsub.4s	v26, v26, v8
	ldr	x8, [sp, #752]                  ; 8-byte Reload
	ldr	q31, [sp, #4752]                ; 16-byte Reload
	ldr	q30, [sp, #4768]                ; 16-byte Reload
	stp	q31, q30, [x8]
	ldr	q8, [sp, #96]                   ; 16-byte Reload
	fmov	x8, d8
	ldr	q14, [sp, #4672]                ; 16-byte Reload
	str	s14, [x8]
	mov.d	x8, v8[1]
	ldr	q8, [sp, #112]                  ; 16-byte Reload
	mov.d	x10, v8[1]
	st1.s	{ v14 }[1], [x8]
	fmov	x8, d8
	st1.s	{ v14 }[2], [x8]
	st1.s	{ v14 }[3], [x10]
	fmul.4s	v29, v29, v15
	fsub.4s	v27, v27, v29
	fmul.4s	v29, v27, v12
	fadd.4s	v29, v29, v11
	fmul.4s	v29, v27, v29
	fadd.4s	v29, v29, v16
	fmul.4s	v29, v27, v29
	fadd.4s	v29, v29, v17
	fmul.4s	v29, v27, v29
	fadd.4s	v29, v29, v7
	fmul.4s	v29, v27, v29
	fadd.4s	v29, v29, v23
	fmul.4s	v8, v27, v27
	fmul.4s	v29, v8, v29
	ldr	q8, [sp, #128]                  ; 16-byte Reload
	fmov	x8, d8
	ldr	q14, [sp, #4704]                ; 16-byte Reload
	str	s14, [x8]
	mov.d	x8, v8[1]
	ldr	q8, [sp, #144]                  ; 16-byte Reload
	fmov	x10, d8
	st1.s	{ v14 }[1], [x8]
	mov.d	x8, v8[1]
	st1.s	{ v14 }[2], [x10]
	st1.s	{ v14 }[3], [x8]
	fmul.4s	v8, v26, v12
	fadd.4s	v8, v8, v11
	fmul.4s	v8, v26, v8
	fadd.4s	v8, v8, v16
	fmul.4s	v8, v26, v8
	fadd.4s	v8, v8, v17
	fmul.4s	v8, v26, v8
	fadd.4s	v8, v8, v7
	fmul.4s	v8, v26, v8
	fadd.4s	v8, v8, v23
	fmul.4s	v14, v26, v26
	fmul.4s	v8, v14, v8
	fadd.4s	v26, v26, v8
	fadd.4s	v27, v27, v29
	fadd.4s	v26, v26, v5
	sshr.4s	v29, v9, #1
	shl.4s	v8, v29, #23
	add.4s	v8, v8, v5
	fmul.4s	v26, v26, v8
	fadd.4s	v27, v27, v5
	sshr.4s	v8, v1, #1
	shl.4s	v14, v8, #23
	add.4s	v14, v14, v5
	fmul.4s	v27, v27, v14
	sub.4s	v29, v9, v29
	sub.4s	v1, v1, v8
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v5
	fmul.4s	v1, v27, v1
	shl.4s	v27, v29, #23
	add.4s	v27, v27, v5
	fmul.4s	v26, v26, v27
	fcmgt.4s	v27, v2, v0
	bic.16b	v26, v26, v27
	fcmgt.4s	v27, v2, v22
	bic.16b	v1, v1, v27
	fcmgt.4s	v27, v22, v3
	bsl.16b	v27, v6, v1
	fcmgt.4s	v1, v0, v3
	bsl.16b	v1, v6, v26
	mov.16b	v14, v6
	fcmeq.4s	v0, v0, v0
	bif.16b	v1, v19, v0
	fcmeq.4s	v0, v22, v22
	mov.16b	v22, v0
	bsl.16b	v22, v27, v19
	ldr	q0, [sp, #1728]                 ; 16-byte Reload
	fmov	x8, d0
	ldr	q6, [sp, #4640]                 ; 16-byte Reload
	str	s6, [x8]
	mov.d	x8, v0[1]
	ldr	q0, [sp, #1744]                 ; 16-byte Reload
	mov.d	x10, v0[1]
	st1.s	{ v6 }[1], [x8]
	fmov	x8, d0
	str	q28, [sp, #4864]                ; 16-byte Spill
	fsub.4s	v0, v31, v28
	st1.s	{ v6 }[2], [x8]
	fcmge.4s	v26, v0, v2
	fcmge.4s	v27, v3, v0
	and.16b	v26, v26, v27
	st1.s	{ v6 }[3], [x10]
	ldr	q27, [sp, #1760]                ; 16-byte Reload
	fmov	x8, d27
	mov.d	x10, v27[1]
	ldr	q6, [sp, #4656]                 ; 16-byte Reload
	str	s6, [x8]
	ldr	q27, [sp, #1776]                ; 16-byte Reload
	fmov	x8, d27
	st1.s	{ v6 }[1], [x10]
	mov.d	x10, v27[1]
	st1.s	{ v6 }[2], [x8]
	st1.s	{ v6 }[3], [x10]
	ldr	q27, [sp, #1664]                ; 16-byte Reload
	fmov	x8, d27
	ldr	q6, [sp, #4592]                 ; 16-byte Reload
	str	s6, [x8]
	mov.d	x8, v27[1]
	ldr	q27, [sp, #1680]                ; 16-byte Reload
	mov.d	x10, v27[1]
	st1.s	{ v6 }[1], [x8]
	fmov	x8, d27
	st1.s	{ v6 }[2], [x8]
	st1.s	{ v6 }[3], [x10]
	str	q4, [sp, #4880]                 ; 16-byte Spill
	fsub.4s	v9, v30, v4
	fcmge.4s	v27, v9, v2
	fcmge.4s	v29, v3, v9
	and.16b	v27, v27, v29
	ldr	q29, [sp, #1696]                ; 16-byte Reload
	fmov	x8, d29
	mov.d	x10, v29[1]
	ldr	q4, [sp, #4608]                 ; 16-byte Reload
	str	s4, [x8]
	ldr	q29, [sp, #1712]                ; 16-byte Reload
	fmov	x8, d29
	st1.s	{ v4 }[1], [x10]
	mov.d	x10, v29[1]
	and.16b	v29, v27, v9
	fmul.4s	v27, v29, v20
	mov.16b	v8, v13
	bsl.16b	v8, v25, v27
	fadd.4s	v27, v27, v8
	st1.s	{ v4 }[2], [x8]
	fsub.4s	v27, v27, v8
	st1.s	{ v4 }[3], [x10]
	ldr	q28, [sp, #1600]                ; 16-byte Reload
	fmov	x8, d28
	mov.d	x10, v28[1]
	ldr	q4, [sp, #4544]                 ; 16-byte Reload
	str	s4, [x8]
	ldr	q28, [sp, #1616]                ; 16-byte Reload
	fmov	x8, d28
	st1.s	{ v4 }[1], [x10]
	mov.d	x10, v28[1]
	st1.s	{ v4 }[2], [x8]
	st1.s	{ v4 }[3], [x10]
	ldr	q28, [sp, #1632]                ; 16-byte Reload
	fmov	x8, d28
	ldr	q4, [sp, #4848]                 ; 16-byte Reload
	str	s4, [x8]
	mov.d	x8, v28[1]
	ldr	q28, [sp, #1648]                ; 16-byte Reload
	mov.d	x10, v28[1]
	st1.s	{ v4 }[1], [x8]
	fmov	x8, d28
	st1.s	{ v4 }[2], [x8]
	st1.s	{ v4 }[3], [x10]
	mov.16b	v31, v20
	ldr	q28, [sp, #1536]                ; 16-byte Reload
	fmov	x8, d28
	ldr	q4, [sp, #4480]                 ; 16-byte Reload
	str	s4, [x8]
	mov.d	x8, v28[1]
	ldr	q28, [sp, #1552]                ; 16-byte Reload
	fmov	x10, d28
	st1.s	{ v4 }[1], [x8]
	mov.d	x8, v28[1]
	st1.s	{ v4 }[2], [x10]
	st1.s	{ v4 }[3], [x8]
	and.16b	v4, v26, v0
	fmul.4s	v26, v4, v20
	mov.16b	v28, v13
	bsl.16b	v28, v25, v26
	fadd.4s	v26, v26, v28
	fsub.4s	v26, v26, v28
	fcvtzs.4s	v27, v27
	scvtf.4s	v28, v27
	fmul.4s	v8, v28, v21
	fsub.4s	v8, v29, v8
	ldr	q29, [sp, #1568]                ; 16-byte Reload
	mov.d	x8, v29[1]
	fmov	x10, d29
	ldr	q6, [sp, #4512]                 ; 16-byte Reload
	str	s6, [x10]
	ldr	q29, [sp, #1584]                ; 16-byte Reload
	mov.d	x10, v29[1]
	st1.s	{ v6 }[1], [x8]
	fmov	x8, d29
	st1.s	{ v6 }[2], [x8]
	st1.s	{ v6 }[3], [x10]
	ldr	q29, [sp, #1472]                ; 16-byte Reload
	fmov	x8, d29
	ldr	q6, [sp, #4432]                 ; 16-byte Reload
	ldr	q10, [sp, #4272]                ; 16-byte Reload
	and.16b	v23, v10, v6
	str	s23, [x8]
	mov.d	x8, v29[1]
	ldr	q29, [sp, #1488]                ; 16-byte Reload
	fmov	x10, d29
	st1.s	{ v23 }[1], [x8]
	mov.d	x8, v29[1]
	st1.s	{ v23 }[2], [x10]
	st1.s	{ v23 }[3], [x8]
	ldr	q29, [sp, #1504]                ; 16-byte Reload
	fmov	x8, d29
	ldr	q6, [sp, #4448]                 ; 16-byte Reload
	and.16b	v23, v10, v6
	str	s23, [x8]
	mov.d	x8, v29[1]
	ldr	q29, [sp, #1520]                ; 16-byte Reload
	fmov	x10, d29
	st1.s	{ v23 }[1], [x8]
	mov.d	x8, v29[1]
	st1.s	{ v23 }[2], [x10]
	st1.s	{ v23 }[3], [x8]
	fcvtzs.4s	v29, v26
	scvtf.4s	v23, v29
	fmul.4s	v21, v23, v21
	fsub.4s	v21, v4, v21
	ldr	q26, [sp, #1408]                ; 16-byte Reload
	fmov	x8, d26
	ldr	q4, [sp, #4384]                 ; 16-byte Reload
	and.16b	v4, v10, v4
	str	s4, [x8]
	mov.d	x8, v26[1]
	ldr	q26, [sp, #1424]                ; 16-byte Reload
	fmov	x10, d26
	st1.s	{ v4 }[1], [x8]
	mov.d	x8, v26[1]
	st1.s	{ v4 }[2], [x10]
	st1.s	{ v4 }[3], [x8]
	fmul.4s	v26, v28, v15
	mov.16b	v28, v7
	mov.16b	v6, v17
	mov.16b	v30, v16
	fmul.4s	v20, v23, v15
	ldr	q23, [sp, #1440]                ; 16-byte Reload
	fmov	x8, d23
	ldr	q4, [sp, #4400]                 ; 16-byte Reload
	and.16b	v4, v10, v4
	str	s4, [x8]
	mov.d	x8, v23[1]
	ldr	q23, [sp, #1456]                ; 16-byte Reload
	fmov	x10, d23
	st1.s	{ v4 }[1], [x8]
	mov.d	x8, v23[1]
	st1.s	{ v4 }[2], [x10]
	st1.s	{ v4 }[3], [x8]
	ldr	q23, [sp, #1312]                ; 16-byte Reload
	fmov	x8, d23
	ldr	q4, [sp, #4320]                 ; 16-byte Reload
	and.16b	v4, v10, v4
	str	s4, [x8]
	mov.d	x8, v23[1]
	ldr	q23, [sp, #1344]                ; 16-byte Reload
	fmov	x10, d23
	st1.s	{ v4 }[1], [x8]
	mov.d	x8, v23[1]
	st1.s	{ v4 }[2], [x10]
	st1.s	{ v4 }[3], [x8]
	ldr	q4, [sp, #1360]                 ; 16-byte Reload
	fmov	x8, d4
	mov.d	x10, v4[1]
	ldr	q4, [sp, #4336]                 ; 16-byte Reload
	and.16b	v4, v10, v4
	str	s4, [x8]
	ldr	q23, [sp, #1392]                ; 16-byte Reload
	fmov	x8, d23
	st1.s	{ v4 }[1], [x10]
	mov.d	x10, v23[1]
	st1.s	{ v4 }[2], [x8]
	st1.s	{ v4 }[3], [x10]
	ldr	q23, [sp, #1216]                ; 16-byte Reload
	fmov	x8, d23
	ldr	q4, [sp, #4288]                 ; 16-byte Reload
	and.16b	v4, v10, v4
	str	s4, [x8]
	mov.d	x8, v23[1]
	ldr	q23, [sp, #1248]                ; 16-byte Reload
	fmov	x10, d23
	st1.s	{ v4 }[1], [x8]
	mov.d	x8, v23[1]
	st1.s	{ v4 }[2], [x10]
	st1.s	{ v4 }[3], [x8]
	ldr	q23, [sp, #1264]                ; 16-byte Reload
	fmov	x8, d23
	ldr	q4, [sp, #4304]                 ; 16-byte Reload
	and.16b	v4, v10, v4
	str	s4, [x8]
	mov.d	x8, v23[1]
	ldr	q23, [sp, #1296]                ; 16-byte Reload
	fmov	x10, d23
	st1.s	{ v4 }[1], [x8]
	mov.d	x8, v23[1]
	st1.s	{ v4 }[2], [x10]
	st1.s	{ v4 }[3], [x8]
	ldr	q4, [sp, #1120]                 ; 16-byte Reload
	fmov	x8, d4
	mov.d	x10, v4[1]
	ldr	q4, [sp, #4352]                 ; 16-byte Reload
	and.16b	v4, v10, v4
	str	s4, [x8]
	ldr	q23, [sp, #1152]                ; 16-byte Reload
	fmov	x8, d23
	st1.s	{ v4 }[1], [x10]
	mov.d	x10, v23[1]
	st1.s	{ v4 }[2], [x8]
	st1.s	{ v4 }[3], [x10]
	ldr	q23, [sp, #1168]                ; 16-byte Reload
	fmov	x8, d23
	ldr	q4, [sp, #4368]                 ; 16-byte Reload
	and.16b	v4, v10, v4
	str	s4, [x8]
	mov.d	x8, v23[1]
	ldr	q23, [sp, #1200]                ; 16-byte Reload
	fmov	x10, d23
	st1.s	{ v4 }[1], [x8]
	mov.d	x8, v23[1]
	st1.s	{ v4 }[2], [x10]
	st1.s	{ v4 }[3], [x8]
	ldr	q23, [sp, #1024]                ; 16-byte Reload
	fmov	x8, d23
	ldr	q4, [sp, #4416]                 ; 16-byte Reload
	and.16b	v4, v10, v4
	str	s4, [x8]
	mov.d	x8, v23[1]
	ldr	q23, [sp, #1056]                ; 16-byte Reload
	fmov	x10, d23
	st1.s	{ v4 }[1], [x8]
	mov.d	x8, v23[1]
	st1.s	{ v4 }[2], [x10]
	fsub.4s	v20, v21, v20
	st1.s	{ v4 }[3], [x8]
	ldr	q21, [sp, #1072]                ; 16-byte Reload
	fmov	x8, d21
	ldr	q4, [sp, #4464]                 ; 16-byte Reload
	and.16b	v4, v10, v4
	str	s4, [x8]
	mov.d	x8, v21[1]
	ldr	q21, [sp, #1104]                ; 16-byte Reload
	mov.d	x10, v21[1]
	st1.s	{ v4 }[1], [x8]
	fmov	x8, d21
	fsub.4s	v21, v8, v26
	fmul.4s	v23, v21, v12
	fadd.4s	v23, v23, v11
	fmul.4s	v23, v21, v23
	ldr	q7, [sp, #4496]                 ; 16-byte Reload
	and.16b	v25, v10, v7
	st1.s	{ v4 }[2], [x8]
	st1.s	{ v4 }[3], [x10]
	ldr	q4, [sp, #928]                  ; 16-byte Reload
	fmov	x8, d4
	str	s25, [x8]
	mov.d	x8, v4[1]
	st1.s	{ v25 }[1], [x8]
	ldr	q4, [sp, #960]                  ; 16-byte Reload
	mov.d	x8, v4[1]
	fmov	x10, d4
	fadd.4s	v4, v23, v16
	fmul.4s	v4, v21, v4
	fadd.4s	v4, v4, v17
	fmul.4s	v4, v21, v4
	fadd.4s	v4, v4, v28
	fmul.4s	v4, v21, v4
	movi.4s	v7, #63, lsl #24
	fadd.4s	v4, v4, v7
	fmul.4s	v23, v21, v21
	fmul.4s	v4, v23, v4
	fmul.4s	v23, v20, v12
	fadd.4s	v23, v23, v11
	fmul.4s	v23, v20, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v20, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v20, v23
	fadd.4s	v23, v23, v28
	fmul.4s	v23, v20, v23
	fadd.4s	v23, v23, v7
	st1.s	{ v25 }[2], [x10]
	st1.s	{ v25 }[3], [x8]
	fmul.4s	v25, v20, v20
	fmul.4s	v23, v25, v23
	ldr	q25, [sp, #976]                 ; 16-byte Reload
	fmov	x8, d25
	mov.d	x10, v25[1]
	ldr	q7, [sp, #4528]                 ; 16-byte Reload
	and.16b	v25, v10, v7
	str	s25, [x8]
	ldr	q26, [sp, #1008]                ; 16-byte Reload
	fmov	x8, d26
	st1.s	{ v25 }[1], [x10]
	mov.d	x10, v26[1]
	st1.s	{ v25 }[2], [x8]
	st1.s	{ v25 }[3], [x10]
	ldr	q26, [sp, #832]                 ; 16-byte Reload
	fmov	x8, d26
	ldr	q7, [sp, #4560]                 ; 16-byte Reload
	and.16b	v25, v10, v7
	str	s25, [x8]
	mov.d	x8, v26[1]
	ldr	q26, [sp, #864]                 ; 16-byte Reload
	fmov	x10, d26
	st1.s	{ v25 }[1], [x8]
	mov.d	x8, v26[1]
	st1.s	{ v25 }[2], [x10]
	st1.s	{ v25 }[3], [x8]
	ldr	q26, [sp, #880]                 ; 16-byte Reload
	fmov	x8, d26
	ldr	q7, [sp, #4576]                 ; 16-byte Reload
	and.16b	v25, v10, v7
	str	s25, [x8]
	mov.d	x8, v26[1]
	ldr	q26, [sp, #912]                 ; 16-byte Reload
	fmov	x10, d26
	st1.s	{ v25 }[1], [x8]
	mov.d	x8, v26[1]
	fadd.4s	v20, v20, v23
	fadd.4s	v4, v21, v4
	fadd.4s	v4, v4, v5
	fadd.4s	v20, v20, v5
	sshr.4s	v21, v29, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v5
	fmul.4s	v20, v20, v23
	sshr.4s	v23, v27, #1
	st1.s	{ v25 }[2], [x10]
	st1.s	{ v25 }[3], [x8]
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v5
	fmul.4s	v4, v4, v25
	sub.4s	v21, v29, v21
	ldr	q25, [sp, #736]                 ; 16-byte Reload
	fmov	x8, d25
	and.16b	v18, v10, v18
	str	s18, [x8]
	mov.d	x8, v25[1]
	ldr	q25, [sp, #768]                 ; 16-byte Reload
	mov.d	x10, v25[1]
	st1.s	{ v18 }[1], [x8]
	sub.4s	v23, v27, v23
	fmov	x8, d25
	mov.16b	v25, v14
	st1.s	{ v18 }[2], [x8]
	st1.s	{ v18 }[3], [x10]
	shl.4s	v18, v23, #23
	add.4s	v18, v18, v5
	fmul.4s	v4, v4, v18
	ldr	q23, [sp, #784]                 ; 16-byte Reload
	fmov	x8, d23
	and.16b	v18, v10, v24
	str	s18, [x8]
	mov.d	x8, v23[1]
	ldr	q23, [sp, #816]                 ; 16-byte Reload
	mov.d	x10, v23[1]
	st1.s	{ v18 }[1], [x8]
	fmov	x8, d23
	st1.s	{ v18 }[2], [x8]
	st1.s	{ v18 }[3], [x10]
	shl.4s	v18, v21, #23
	add.4s	v18, v18, v5
	fmul.4s	v18, v20, v18
	fcmgt.4s	v20, v2, v0
	bic.16b	v18, v18, v20
	fcmgt.4s	v20, v2, v9
	bic.16b	v4, v4, v20
	fcmgt.4s	v20, v9, v3
	bit.16b	v4, v14, v20
	ldr	q20, [sp, #672]                 ; 16-byte Reload
	mov.d	x8, v20[1]
	fmov	x10, d20
	and.16b	v1, v10, v1
	str	s1, [x10]
	ldr	q20, [sp, #688]                 ; 16-byte Reload
	mov.d	x10, v20[1]
	st1.s	{ v1 }[1], [x8]
	fmov	x8, d20
	st1.s	{ v1 }[2], [x8]
	st1.s	{ v1 }[3], [x10]
	fcmgt.4s	v1, v0, v3
	bsl.16b	v1, v14, v18
	fcmeq.4s	v0, v0, v0
	bsl.16b	v0, v1, v19
	ldp	q1, q18, [sp, #704]             ; 32-byte Folded Reload
	mov.d	x8, v1[1]
	fmov	x10, d1
	and.16b	v1, v10, v22
	str	s1, [x10]
	fmov	x10, d18
	st1.s	{ v1 }[1], [x8]
	mov.d	x8, v18[1]
	st1.s	{ v1 }[2], [x10]
	st1.s	{ v1 }[3], [x8]
	fcmeq.4s	v1, v9, v9
	bsl.16b	v1, v4, v19
	ldr	q4, [sp, #608]                  ; 16-byte Reload
	fmov	x8, d4
	and.16b	v0, v10, v0
	str	s0, [x8]
	mov.d	x8, v4[1]
	ldr	q4, [sp, #624]                  ; 16-byte Reload
	fmov	x10, d4
	st1.s	{ v0 }[1], [x8]
	mov.d	x8, v4[1]
	st1.s	{ v0 }[2], [x10]
	st1.s	{ v0 }[3], [x8]
	ldr	q0, [sp, #640]                  ; 16-byte Reload
	fmov	x8, d0
	mov.d	x10, v0[1]
	and.16b	v0, v10, v1
	str	s0, [x8]
	st1.s	{ v0 }[1], [x10]
	ldr	q1, [sp, #656]                  ; 16-byte Reload
	fmov	x8, d1
	st1.s	{ v0 }[2], [x8]
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
	movi.2d	v5, #0000000000000000
	movi.2d	v7, #0000000000000000
	ldr	q20, [sp, #3568]                ; 16-byte Reload
	ldr	q21, [sp, #3536]                ; 16-byte Reload
	ldr	q22, [sp, #3504]                ; 16-byte Reload
	ldr	q23, [sp, #3472]                ; 16-byte Reload
	ldr	q24, [sp, #1792]                ; 16-byte Reload
LBB0_44:                                ; %direct.true381
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v0, x9
	add.2d	v0, v24, v0
	add.2d	v1, v0, v20
	add.2d	v4, v0, v21
	add.2d	v18, v0, v22
	add.2d	v0, v0, v23
	mov.d	x8, v0[1]
	fmov	x10, d0
	mov.d	x11, v18[1]
	fmov	x12, d18
	mov.d	x13, v4[1]
	fmov	x14, d4
	mov.d	x15, v1[1]
	ldr	s0, [x10]
	ld1.s	{ v0 }[1], [x8]
	ld1.s	{ v0 }[2], [x12]
	ld1.s	{ v0 }[3], [x11]
	fmov	x8, d1
	ldr	s1, [x14]
	ld1.s	{ v1 }[1], [x13]
	ld1.s	{ v1 }[2], [x8]
	ld1.s	{ v1 }[3], [x15]
	fadd.4s	v5, v5, v1
	fadd.4s	v7, v7, v0
	add	x9, x9, #4
	cmp	x9, #64
	b.ne	LBB0_44
; %bb.45:                               ; %direct.false382
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	q7, [sp, #4752]                 ; 16-byte Spill
	str	q5, [sp, #4768]                 ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	ldr	q0, [sp, #4912]                 ; 16-byte Reload
	ldr	q1, [sp, #4864]                 ; 16-byte Reload
	fsub.4s	v0, v0, v1
	ldr	q1, [sp, #4896]                 ; 16-byte Reload
	ldr	q4, [sp, #4880]                 ; 16-byte Reload
	fsub.4s	v1, v1, v4
	fcmge.4s	v4, v1, v2
	fcmge.4s	v18, v0, v2
	fcmge.4s	v20, v3, v1
	fcmge.4s	v21, v3, v0
	and.16b	v18, v18, v21
	and.16b	v4, v4, v20
	and.16b	v4, v4, v1
	and.16b	v18, v18, v0
	fmul.4s	v20, v18, v31
	fmul.4s	v5, v4, v31
	movi.4s	v22, #75, lsl #24
	mvni.4s	v23, #128, lsl #24
	mov.16b	v21, v23
	bsl.16b	v21, v22, v5
	bif.16b	v22, v20, v23
	fadd.4s	v20, v20, v22
	fadd.4s	v5, v5, v21
	fsub.4s	v5, v5, v21
	fsub.4s	v20, v20, v22
	fcvtzs.4s	v20, v20
	fcvtzs.4s	v5, v5
	scvtf.4s	v21, v5
	scvtf.4s	v22, v20
	mov	w9, #29184                      ; =0x7200
	movk	w9, #48945, lsl #16
	dup.4s	v23, w9
	fmul.4s	v24, v22, v23
	fmul.4s	v23, v21, v23
	fadd.4s	v4, v4, v23
	fadd.4s	v18, v18, v24
	mov	w9, #48782                      ; =0xbe8e
	movk	w9, #46527, lsl #16
	dup.4s	v23, w9
	fmul.4s	v21, v21, v23
	fmul.4s	v22, v22, v23
	fadd.4s	v18, v18, v22
	fadd.4s	v4, v4, v21
	fmul.4s	v21, v4, v12
	fmul.4s	v16, v18, v12
	fadd.4s	v16, v16, v11
	fadd.4s	v17, v21, v11
	fmul.4s	v17, v4, v17
	fmul.4s	v16, v18, v16
	fadd.4s	v16, v16, v30
	fadd.4s	v7, v17, v30
	fmul.4s	v7, v4, v7
	fmul.4s	v16, v18, v16
	fadd.4s	v16, v16, v6
	fadd.4s	v6, v7, v6
	fmul.4s	v6, v4, v6
	fmul.4s	v7, v18, v16
	fadd.4s	v7, v7, v28
	fadd.4s	v6, v6, v28
	fmul.4s	v6, v4, v6
	fmul.4s	v7, v18, v7
	movi.4s	v16, #63, lsl #24
	fadd.4s	v7, v7, v16
	fadd.4s	v6, v6, v16
	fmul.4s	v16, v18, v18
	fmul.4s	v17, v4, v4
	fmul.4s	v6, v17, v6
	fmul.4s	v7, v16, v7
	fadd.4s	v7, v18, v7
	fadd.4s	v4, v4, v6
	fmov.4s	v21, #1.00000000
	fadd.4s	v4, v4, v21
	fadd.4s	v6, v7, v21
	sshr.4s	v7, v5, #1
	sshr.4s	v16, v20, #1
	shl.4s	v17, v16, #23
	shl.4s	v18, v7, #23
	add.4s	v18, v18, v21
	add.4s	v17, v17, v21
	fmul.4s	v6, v6, v17
	fmul.4s	v4, v4, v18
	sub.4s	v16, v20, v16
	sub.4s	v5, v5, v7
	shl.4s	v5, v5, #23
	shl.4s	v7, v16, #23
	add.4s	v7, v7, v21
	add.4s	v5, v5, v21
	fmul.4s	v4, v4, v5
	fmul.4s	v5, v6, v7
	fcmgt.4s	v6, v2, v0
	bic.16b	v5, v5, v6
	fcmgt.4s	v2, v2, v1
	bic.16b	v2, v4, v2
	fcmgt.4s	v4, v0, v3
	fcmgt.4s	v3, v1, v3
	bit.16b	v2, v25, v3
	mov.16b	v3, v4
	bsl.16b	v3, v25, v5
	fcmeq.4s	v1, v1, v1
	fcmeq.4s	v0, v0, v0
	ldr	q4, [sp, #4816]                 ; 16-byte Reload
	mov.16b	v17, v0
	bsl.16b	v17, v3, v4
	mov.16b	v18, v1
	bsl.16b	v18, v2, v4
	add	x9, x20, #2560
	ldr	x12, [sp, #3664]                ; 8-byte Reload
	ldp	q6, q5, [sp, #192]              ; 32-byte Folded Reload
	ldp	q16, q7, [sp, #160]             ; 32-byte Folded Reload
LBB0_46:                                ; %direct.true393
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q0, q1, [x9], #32
	fmul.4s	v1, v18, v1
	dup.2d	v2, x8
	dup.2d	v3, x12
	fmul.4s	v0, v17, v0
	add.2d	v2, v2, v3
	add.2d	v3, v2, v6
	add.2d	v4, v2, v5
	mov.d	x10, v4[1]
	fmov	x11, d4
	str	s0, [x11]
	st1.s	{ v0 }[1], [x10]
	mov.d	x10, v3[1]
	add.2d	v4, v2, v7
	fmov	x11, d3
	st1.s	{ v0 }[2], [x11]
	st1.s	{ v0 }[3], [x10]
	mov.d	x10, v4[1]
	fmov	x11, d4
	str	s1, [x11]
	st1.s	{ v1 }[1], [x10]
	add.2d	v0, v2, v16
	mov.d	x10, v0[1]
	fmov	x11, d0
	st1.s	{ v1 }[2], [x11]
	st1.s	{ v1 }[3], [x10]
	add	x8, x8, #4
	cmp	x8, #384
	b.ne	LBB0_46
; %bb.47:                               ; %mma.update2.i272.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	x11, [sp, #1136]                ; 8-byte Reload
LBB0_48:                                ; %mma.update2.i272
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x9, x11, x8
	ldr	q0, [x9, #48896]
	add	x10, x20, x8
	ldr	q1, [x10, #49664]
	ldp	s2, s3, [x21]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x10, #50048]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x10, #50432]
	ldp	s2, s3, [x21, #8]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x10, #50816]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x10, #51200]
	ldp	s2, s3, [x21, #16]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x10, #51584]
	fmul.4s	v1, v1, v3[0]
	ldr	q2, [x9]
	fadd.4s	v0, v0, v1
	ldp	s1, s3, [x21, #24]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x9, #384]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x9, #768]
	ldp	s2, s3, [x21, #32]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x9, #1152]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x9, #1536]
	ldp	s2, s3, [x21, #40]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x9, #1920]
	fmul.4s	v1, v1, v3[0]
	ldr	q2, [x9, #2304]
	fadd.4s	v0, v0, v1
	ldp	s1, s3, [x21, #48]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x9, #2688]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x9, #3072]
	ldp	s2, s3, [x21, #56]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x9, #3456]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	str	q0, [x9, #51968]
	add	x8, x8, #16
	cmp	x8, #384
	b.ne	LBB0_48
; %bb.49:                               ; %mma.update2.i274.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #1384]                 ; 8-byte Reload
	mov	w9, #24                         ; =0x18
LBB0_50:                                ; %mma.update2.i274
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x8, #45440]
	ldr	q1, [x8]
	ldp	s2, s3, [x21, #64]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #384]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #768]
	ldp	s2, s3, [x21, #72]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #1152]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #1536]
	ldp	s2, s3, [x21, #80]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #1920]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #2304]
	ldp	s2, s3, [x21, #88]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #2688]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #3072]
	ldp	s2, s3, [x21, #96]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #3456]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #3840]
	ldp	s2, s3, [x21, #104]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #4224]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #4608]
	ldp	s2, s3, [x21, #112]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #4992]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #5376]
	ldp	s2, s3, [x21, #120]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #5760]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	str	q0, [x8, #48512]
	add	x8, x8, #16
	subs	x9, x9, #1
	b.ne	LBB0_50
; %bb.51:                               ; %mma.update2.i310.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #1336]                 ; 8-byte Reload
	mov	w9, #24                         ; =0x18
LBB0_52:                                ; %mma.update2.i310
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x8, #39680]
	ldr	q1, [x8]
	ldp	s2, s3, [x21, #128]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #384]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #768]
	ldp	s2, s3, [x21, #136]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #1152]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #1536]
	ldp	s2, s3, [x21, #144]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #1920]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #2304]
	ldp	s2, s3, [x21, #152]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #2688]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #3072]
	ldp	s2, s3, [x21, #160]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #3456]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #3840]
	ldp	s2, s3, [x21, #168]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #4224]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #4608]
	ldp	s2, s3, [x21, #176]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #4992]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #5376]
	ldp	s2, s3, [x21, #184]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #5760]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	str	q0, [x8, #42752]
	add	x8, x8, #16
	subs	x9, x9, #1
	b.ne	LBB0_52
; %bb.53:                               ; %mma.update2.i346.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #3720]                 ; 8-byte Reload
	mov	w9, #24                         ; =0x18
LBB0_54:                                ; %mma.update2.i346
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x8, #33920]
	ldr	q1, [x8]
	ldp	s2, s3, [x21, #192]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #384]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #768]
	ldp	s2, s3, [x21, #200]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #1152]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #1536]
	ldp	s2, s3, [x21, #208]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #1920]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #2304]
	ldp	s2, s3, [x21, #216]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #2688]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #3072]
	ldp	s2, s3, [x21, #224]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #3456]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #3840]
	ldp	s2, s3, [x21, #232]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #4224]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #4608]
	ldp	s2, s3, [x21, #240]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #4992]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #5376]
	ldp	s2, s3, [x21, #248]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x8, #5760]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	str	q0, [x8, #36992]
	add	x8, x8, #16
	subs	x9, x9, #1
	b.ne	LBB0_54
; %bb.55:                               ; %mma.update2.i382.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #3728]                 ; 8-byte Reload
	mov	w9, #24                         ; =0x18
LBB0_56:                                ; %mma.update2.i382
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x8, #28160]
	ldr	s1, [x21, #256]
	ldr	q2, [x8]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #260]
	ldr	q2, [x8, #384]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #264]
	ldr	q2, [x8, #768]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #268]
	ldr	q2, [x8, #1152]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #272]
	ldr	q2, [x8, #1536]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #276]
	ldr	q2, [x8, #1920]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #280]
	ldr	q2, [x8, #2304]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #284]
	ldr	q2, [x8, #2688]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #288]
	ldr	q2, [x8, #3072]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #292]
	ldr	q2, [x8, #3456]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #296]
	ldr	q2, [x8, #3840]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #300]
	ldr	q2, [x8, #4224]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #304]
	ldr	q2, [x8, #4608]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #308]
	ldr	q2, [x8, #4992]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #312]
	ldr	q2, [x8, #5376]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #316]
	ldr	q2, [x8, #5760]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	str	q0, [x8, #31232]
	add	x8, x8, #16
	subs	x9, x9, #1
	b.ne	LBB0_56
; %bb.57:                               ; %mma.update2.i418.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #3736]                 ; 8-byte Reload
	mov	w9, #24                         ; =0x18
LBB0_58:                                ; %mma.update2.i418
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x8, #22400]
	ldr	s1, [x21, #320]
	ldr	q2, [x8]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #324]
	ldr	q2, [x8, #384]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #328]
	ldr	q2, [x8, #768]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #332]
	ldr	q2, [x8, #1152]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #336]
	ldr	q2, [x8, #1536]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #340]
	ldr	q2, [x8, #1920]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #344]
	ldr	q2, [x8, #2304]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #348]
	ldr	q2, [x8, #2688]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #352]
	ldr	q2, [x8, #3072]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #356]
	ldr	q2, [x8, #3456]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #360]
	ldr	q2, [x8, #3840]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #364]
	ldr	q2, [x8, #4224]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #368]
	ldr	q2, [x8, #4608]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #372]
	ldr	q2, [x8, #4992]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #376]
	ldr	q2, [x8, #5376]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #380]
	ldr	q2, [x8, #5760]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	str	q0, [x8, #25472]
	add	x8, x8, #16
	subs	x9, x9, #1
	b.ne	LBB0_58
; %bb.59:                               ; %mma.update2.i454.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #3744]                 ; 8-byte Reload
	mov	w9, #24                         ; =0x18
LBB0_60:                                ; %mma.update2.i454
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x8, #16640]
	ldr	s1, [x21, #384]
	ldr	q2, [x8]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #388]
	ldr	q2, [x8, #384]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #392]
	ldr	q2, [x8, #768]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #396]
	ldr	q2, [x8, #1152]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #400]
	ldr	q2, [x8, #1536]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #404]
	ldr	q2, [x8, #1920]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #408]
	ldr	q2, [x8, #2304]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #412]
	ldr	q2, [x8, #2688]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #416]
	ldr	q2, [x8, #3072]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #420]
	ldr	q2, [x8, #3456]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #424]
	ldr	q2, [x8, #3840]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #428]
	ldr	q2, [x8, #4224]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #432]
	ldr	q2, [x8, #4608]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #436]
	ldr	q2, [x8, #4992]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #440]
	ldr	q2, [x8, #5376]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #444]
	ldr	q2, [x8, #5760]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	str	q0, [x8, #19712]
	add	x8, x8, #16
	subs	x9, x9, #1
	b.ne	LBB0_60
; %bb.61:                               ; %mma.update2.i490.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #3752]                 ; 8-byte Reload
	mov	w9, #24                         ; =0x18
LBB0_62:                                ; %mma.update2.i490
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x8, #10880]
	ldr	s1, [x21, #448]
	ldr	q2, [x8]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #452]
	ldr	q2, [x8, #384]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #456]
	ldr	q2, [x8, #768]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #460]
	ldr	q2, [x8, #1152]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #464]
	ldr	q2, [x8, #1536]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #468]
	ldr	q2, [x8, #1920]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #472]
	ldr	q2, [x8, #2304]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #476]
	ldr	q2, [x8, #2688]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #480]
	ldr	q2, [x8, #3072]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #484]
	ldr	q2, [x8, #3456]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #488]
	ldr	q2, [x8, #3840]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #492]
	ldr	q2, [x8, #4224]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #496]
	ldr	q2, [x8, #4608]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #500]
	ldr	q2, [x8, #4992]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #504]
	ldr	q2, [x8, #5376]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	ldr	s1, [x21, #508]
	ldr	q2, [x8, #5760]
	fmul.4s	v1, v2, v1[0]
	fadd.4s	v0, v0, v1
	str	q0, [x8, #13952]
	add	x8, x8, #16
	subs	x9, x9, #1
	b.ne	LBB0_62
; %bb.63:                               ; %direct.true427.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	q18, [sp, #4896]                ; 16-byte Spill
	str	q17, [sp, #4912]                ; 16-byte Spill
	str	x1, [sp, #4848]                 ; 8-byte Spill
	mov	x8, #0                          ; =0x0
	ldr	x9, [sp, #4840]                 ; 8-byte Reload
LBB0_64:                                ; %direct.true427
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v0, x8
	dup.2d	v1, x17
	add.2d	v0, v0, v1
	add.2d	v1, v0, v16
	add.2d	v2, v0, v7
	add.2d	v3, v0, v6
	add.2d	v0, v0, v5
	mov.d	x10, v0[1]
	fmov	x11, d0
	mov.d	x12, v3[1]
	fmov	x13, d3
	mov.d	x14, v2[1]
	fmov	x15, d2
	mov.d	x16, v1[1]
	ldr	s0, [x11]
	ld1.s	{ v0 }[1], [x10]
	fmov	x10, d1
	ld1.s	{ v0 }[2], [x13]
	ld1.s	{ v0 }[3], [x12]
	ldr	s1, [x15]
	ld1.s	{ v1 }[1], [x14]
	ld1.s	{ v1 }[2], [x10]
	ld1.s	{ v1 }[3], [x16]
	stp	q0, q1, [x9], #32
	add	x8, x8, #4
	cmp	x8, #384
	b.ne	LBB0_64
; %bb.65:                               ; %direct.true441.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, x20, #2560
	ldr	x1, [sp, #4840]                 ; 8-byte Reload
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	ldr	q0, [sp, #4800]                 ; 16-byte Reload
	ldr	q1, [sp, #4896]                 ; 16-byte Reload
	fmul.4s	v0, v0, v1
	ldr	q1, [sp, #4784]                 ; 16-byte Reload
	ldr	q2, [sp, #4912]                 ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q2, [sp, #4752]                 ; 16-byte Reload
	fadd.4s	v24, v1, v2
	ldr	q1, [sp, #4768]                 ; 16-byte Reload
	fadd.4s	v19, v0, v1
	ldr	x1, [sp, #4848]                 ; 8-byte Reload
	add	x1, x1, #1
	ldr	q0, [sp, #4864]                 ; 16-byte Reload
	str	q0, [sp, #4912]                 ; 16-byte Spill
	ldr	q0, [sp, #4880]                 ; 16-byte Reload
	str	q0, [sp, #4896]                 ; 16-byte Spill
	cmp	x1, #129
	ldr	x4, [sp, #2488]                 ; 8-byte Reload
	ldr	x5, [sp, #2480]                 ; 8-byte Reload
	ldr	x6, [sp, #2472]                 ; 8-byte Reload
	ldr	x7, [sp, #2464]                 ; 8-byte Reload
	ldr	x30, [sp, #2456]                ; 8-byte Reload
	ldp	q26, q25, [sp, #320]            ; 32-byte Folded Reload
	ldp	q28, q27, [sp, #288]            ; 32-byte Folded Reload
	ldp	q30, q29, [sp, #256]            ; 32-byte Folded Reload
	ldp	q8, q31, [sp, #224]             ; 32-byte Folded Reload
	b.ne	LBB0_3
; %bb.66:                               ; %direct.schedule.35.preheader
	mov	x8, #0                          ; =0x0
	ldp	q0, q2, [sp, #32]               ; 32-byte Folded Reload
	xtn.2s	v0, v0
	movi.2s	v3, #96
	umull.2d	v0, v0, v3
	ldp	q1, q4, [sp, #64]               ; 32-byte Folded Reload
	xtn.2s	v1, v1
	umull.2d	v1, v1, v3
	xtn.2s	v2, v2
	umull.2d	v2, v2, v3
	xtn.2s	v4, v4
	umull.2d	v3, v4, v3
	ldp	x11, x9, [sp, #16]              ; 16-byte Folded Reload
	dup.2d	v4, x9
LBB0_67:                                ; %direct.true460
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v5, x8
	add.2d	v6, v5, v3
	add.2d	v7, v5, v2
	add.2d	v16, v5, v1
	add.2d	v5, v5, v0
	add	x9, x11, x8, lsl #5
	ldp	q17, q18, [x9]
	fdiv.4s	v18, v18, v19
	fdiv.4s	v17, v17, v24
	shl.2d	v5, v5, #2
	shl.2d	v16, v16, #2
	shl.2d	v7, v7, #2
	shl.2d	v6, v6, #2
	add.2d	v6, v4, v6
	add.2d	v5, v4, v5
	mov.d	x9, v5[1]
	fmov	x10, d5
	str	s17, [x10]
	st1.s	{ v17 }[1], [x9]
	add.2d	v5, v4, v16
	mov.d	x9, v5[1]
	fmov	x10, d5
	st1.s	{ v17 }[2], [x10]
	add.2d	v5, v4, v7
	st1.s	{ v17 }[3], [x9]
	mov.d	x9, v5[1]
	fmov	x10, d5
	str	s18, [x10]
	st1.s	{ v18 }[1], [x9]
	mov.d	x9, v6[1]
	fmov	x10, d6
	st1.s	{ v18 }[2], [x10]
	st1.s	{ v18 }[3], [x9]
	add	x8, x8, #1
	cmp	x8, #96
	b.ne	LBB0_67
; %bb.68:                               ; %common.ret
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #832
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh151, Lloh152
	.loh AdrpLdr	Lloh150, Lloh163
	.loh AdrpLdr	Lloh149, Lloh162
	.loh AdrpLdr	Lloh148, Lloh161
	.loh AdrpLdr	Lloh147, Lloh160
	.loh AdrpLdr	Lloh146, Lloh159
	.loh AdrpLdr	Lloh145, Lloh158
	.loh AdrpLdr	Lloh144, Lloh157
	.loh AdrpLdr	Lloh143, Lloh156
	.loh AdrpLdr	Lloh142, Lloh155
	.loh AdrpLdr	Lloh141, Lloh154
	.loh AdrpLdr	Lloh140, Lloh153
	.loh AdrpLdr	Lloh113, Lloh114
	.loh AdrpAdrp	Lloh111, Lloh113
	.loh AdrpLdr	Lloh111, Lloh112
	.loh AdrpAdrp	Lloh109, Lloh111
	.loh AdrpLdr	Lloh109, Lloh110
	.loh AdrpAdrp	Lloh107, Lloh109
	.loh AdrpLdr	Lloh107, Lloh108
	.loh AdrpAdrp	Lloh105, Lloh107
	.loh AdrpLdr	Lloh105, Lloh106
	.loh AdrpAdrp	Lloh103, Lloh105
	.loh AdrpLdr	Lloh103, Lloh104
	.loh AdrpAdrp	Lloh101, Lloh103
	.loh AdrpLdr	Lloh101, Lloh102
	.loh AdrpAdrp	Lloh99, Lloh101
	.loh AdrpLdr	Lloh99, Lloh100
	.loh AdrpAdrp	Lloh97, Lloh99
	.loh AdrpLdr	Lloh97, Lloh98
	.loh AdrpAdrp	Lloh95, Lloh97
	.loh AdrpLdr	Lloh95, Lloh96
	.loh AdrpAdrp	Lloh93, Lloh95
	.loh AdrpLdr	Lloh93, Lloh94
	.loh AdrpAdrp	Lloh91, Lloh93
	.loh AdrpLdr	Lloh91, Lloh92
	.loh AdrpAdrp	Lloh89, Lloh91
	.loh AdrpLdr	Lloh89, Lloh90
	.loh AdrpAdrp	Lloh87, Lloh89
	.loh AdrpLdr	Lloh87, Lloh88
	.loh AdrpAdrp	Lloh85, Lloh87
	.loh AdrpLdr	Lloh85, Lloh86
	.loh AdrpAdrp	Lloh83, Lloh85
	.loh AdrpLdr	Lloh83, Lloh84
	.loh AdrpAdrp	Lloh81, Lloh83
	.loh AdrpLdr	Lloh81, Lloh82
	.loh AdrpAdrp	Lloh79, Lloh81
	.loh AdrpLdr	Lloh79, Lloh80
	.loh AdrpAdrp	Lloh77, Lloh79
	.loh AdrpLdr	Lloh77, Lloh78
	.loh AdrpAdrp	Lloh75, Lloh77
	.loh AdrpLdr	Lloh75, Lloh76
	.loh AdrpAdrp	Lloh73, Lloh75
	.loh AdrpLdr	Lloh73, Lloh74
	.loh AdrpAdrp	Lloh71, Lloh73
	.loh AdrpLdr	Lloh71, Lloh72
	.loh AdrpAdrp	Lloh69, Lloh71
	.loh AdrpLdr	Lloh69, Lloh70
	.loh AdrpAdrp	Lloh67, Lloh69
	.loh AdrpLdr	Lloh67, Lloh68
	.loh AdrpAdrp	Lloh65, Lloh67
	.loh AdrpLdr	Lloh65, Lloh66
	.loh AdrpLdr	Lloh64, Lloh139
	.loh AdrpAdrp	Lloh63, Lloh141
	.loh AdrpLdr	Lloh63, Lloh138
	.loh AdrpAdrp	Lloh62, Lloh142
	.loh AdrpLdr	Lloh62, Lloh137
	.loh AdrpAdrp	Lloh61, Lloh143
	.loh AdrpLdr	Lloh61, Lloh136
	.loh AdrpAdrp	Lloh60, Lloh144
	.loh AdrpLdr	Lloh60, Lloh135
	.loh AdrpAdrp	Lloh59, Lloh145
	.loh AdrpLdr	Lloh59, Lloh134
	.loh AdrpAdrp	Lloh58, Lloh146
	.loh AdrpLdr	Lloh58, Lloh133
	.loh AdrpLdr	Lloh57, Lloh132
	.loh AdrpAdrp	Lloh56, Lloh148
	.loh AdrpLdr	Lloh56, Lloh131
	.loh AdrpAdrp	Lloh55, Lloh150
	.loh AdrpLdr	Lloh55, Lloh130
	.loh AdrpAdrp	Lloh54, Lloh151
	.loh AdrpLdr	Lloh54, Lloh129
	.loh AdrpLdr	Lloh53, Lloh128
	.loh AdrpLdr	Lloh52, Lloh127
	.loh AdrpLdr	Lloh51, Lloh126
	.loh AdrpLdr	Lloh50, Lloh125
	.loh AdrpLdr	Lloh49, Lloh124
	.loh AdrpLdr	Lloh48, Lloh123
	.loh AdrpLdr	Lloh47, Lloh122
	.loh AdrpLdr	Lloh46, Lloh121
	.loh AdrpLdr	Lloh45, Lloh120
	.loh AdrpLdr	Lloh44, Lloh119
	.loh AdrpLdr	Lloh43, Lloh118
	.loh AdrpLdr	Lloh42, Lloh117
	.loh AdrpLdr	Lloh41, Lloh116
	.loh AdrpLdr	Lloh40, Lloh115
	.loh AdrpAdrp	Lloh38, Lloh64
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpAdrp	Lloh36, Lloh38
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpAdrp	Lloh34, Lloh36
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpAdrp	Lloh32, Lloh34
	.loh AdrpLdr	Lloh32, Lloh33
	.loh AdrpAdrp	Lloh30, Lloh32
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdrp	Lloh28, Lloh30
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention.packet_batch.blocks
lCPI1_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI1_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI1_2:
	.quad	1920                            ; 0x780
	.quad	2240                            ; 0x8c0
lCPI1_3:
	.quad	640                             ; 0x280
	.quad	960                             ; 0x3c0
lCPI1_4:
	.quad	1280                            ; 0x500
	.quad	1600                            ; 0x640
lCPI1_5:
	.quad	0                               ; 0x0
	.quad	320                             ; 0x140
lCPI1_6:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI1_7:
	.quad	384                             ; 0x180
	.quad	448                             ; 0x1c0
lCPI1_8:
	.quad	256                             ; 0x100
	.quad	320                             ; 0x140
lCPI1_9:
	.quad	128                             ; 0x80
	.quad	192                             ; 0xc0
lCPI1_10:
	.quad	0                               ; 0x0
	.quad	64                              ; 0x40
lCPI1_11:
	.quad	388                             ; 0x184
	.quad	452                             ; 0x1c4
lCPI1_12:
	.quad	260                             ; 0x104
	.quad	324                             ; 0x144
lCPI1_13:
	.quad	132                             ; 0x84
	.quad	196                             ; 0xc4
lCPI1_14:
	.quad	4                               ; 0x4
	.quad	68                              ; 0x44
lCPI1_15:
	.quad	392                             ; 0x188
	.quad	456                             ; 0x1c8
lCPI1_16:
	.quad	264                             ; 0x108
	.quad	328                             ; 0x148
lCPI1_17:
	.quad	136                             ; 0x88
	.quad	200                             ; 0xc8
lCPI1_18:
	.quad	8                               ; 0x8
	.quad	72                              ; 0x48
lCPI1_19:
	.quad	396                             ; 0x18c
	.quad	460                             ; 0x1cc
lCPI1_20:
	.quad	268                             ; 0x10c
	.quad	332                             ; 0x14c
lCPI1_21:
	.quad	140                             ; 0x8c
	.quad	204                             ; 0xcc
lCPI1_22:
	.quad	12                              ; 0xc
	.quad	76                              ; 0x4c
lCPI1_23:
	.quad	400                             ; 0x190
	.quad	464                             ; 0x1d0
lCPI1_24:
	.quad	272                             ; 0x110
	.quad	336                             ; 0x150
lCPI1_25:
	.quad	144                             ; 0x90
	.quad	208                             ; 0xd0
lCPI1_26:
	.quad	16                              ; 0x10
	.quad	80                              ; 0x50
lCPI1_27:
	.quad	404                             ; 0x194
	.quad	468                             ; 0x1d4
lCPI1_28:
	.quad	276                             ; 0x114
	.quad	340                             ; 0x154
lCPI1_29:
	.quad	148                             ; 0x94
	.quad	212                             ; 0xd4
lCPI1_30:
	.quad	20                              ; 0x14
	.quad	84                              ; 0x54
lCPI1_31:
	.quad	408                             ; 0x198
	.quad	472                             ; 0x1d8
lCPI1_32:
	.quad	280                             ; 0x118
	.quad	344                             ; 0x158
lCPI1_33:
	.quad	152                             ; 0x98
	.quad	216                             ; 0xd8
lCPI1_34:
	.quad	24                              ; 0x18
	.quad	88                              ; 0x58
lCPI1_35:
	.quad	412                             ; 0x19c
	.quad	476                             ; 0x1dc
lCPI1_36:
	.quad	284                             ; 0x11c
	.quad	348                             ; 0x15c
lCPI1_37:
	.quad	156                             ; 0x9c
	.quad	220                             ; 0xdc
lCPI1_38:
	.quad	28                              ; 0x1c
	.quad	92                              ; 0x5c
lCPI1_39:
	.quad	416                             ; 0x1a0
	.quad	480                             ; 0x1e0
lCPI1_40:
	.quad	288                             ; 0x120
	.quad	352                             ; 0x160
lCPI1_41:
	.quad	160                             ; 0xa0
	.quad	224                             ; 0xe0
lCPI1_42:
	.quad	32                              ; 0x20
	.quad	96                              ; 0x60
lCPI1_43:
	.quad	420                             ; 0x1a4
	.quad	484                             ; 0x1e4
lCPI1_44:
	.quad	292                             ; 0x124
	.quad	356                             ; 0x164
lCPI1_45:
	.quad	164                             ; 0xa4
	.quad	228                             ; 0xe4
lCPI1_46:
	.quad	36                              ; 0x24
	.quad	100                             ; 0x64
lCPI1_47:
	.quad	424                             ; 0x1a8
	.quad	488                             ; 0x1e8
lCPI1_48:
	.quad	296                             ; 0x128
	.quad	360                             ; 0x168
lCPI1_49:
	.quad	168                             ; 0xa8
	.quad	232                             ; 0xe8
lCPI1_50:
	.quad	40                              ; 0x28
	.quad	104                             ; 0x68
lCPI1_51:
	.quad	428                             ; 0x1ac
	.quad	492                             ; 0x1ec
lCPI1_52:
	.quad	300                             ; 0x12c
	.quad	364                             ; 0x16c
lCPI1_53:
	.quad	172                             ; 0xac
	.quad	236                             ; 0xec
lCPI1_54:
	.quad	44                              ; 0x2c
	.quad	108                             ; 0x6c
lCPI1_55:
	.quad	432                             ; 0x1b0
	.quad	496                             ; 0x1f0
lCPI1_56:
	.quad	304                             ; 0x130
	.quad	368                             ; 0x170
lCPI1_57:
	.quad	176                             ; 0xb0
	.quad	240                             ; 0xf0
lCPI1_58:
	.quad	48                              ; 0x30
	.quad	112                             ; 0x70
lCPI1_59:
	.quad	436                             ; 0x1b4
	.quad	500                             ; 0x1f4
lCPI1_60:
	.quad	308                             ; 0x134
	.quad	372                             ; 0x174
lCPI1_61:
	.quad	180                             ; 0xb4
	.quad	244                             ; 0xf4
lCPI1_62:
	.quad	52                              ; 0x34
	.quad	116                             ; 0x74
lCPI1_63:
	.quad	440                             ; 0x1b8
	.quad	504                             ; 0x1f8
lCPI1_64:
	.quad	312                             ; 0x138
	.quad	376                             ; 0x178
lCPI1_65:
	.quad	184                             ; 0xb8
	.quad	248                             ; 0xf8
lCPI1_66:
	.quad	56                              ; 0x38
	.quad	120                             ; 0x78
lCPI1_67:
	.quad	444                             ; 0x1bc
	.quad	508                             ; 0x1fc
lCPI1_68:
	.quad	316                             ; 0x13c
	.quad	380                             ; 0x17c
lCPI1_69:
	.quad	188                             ; 0xbc
	.quad	252                             ; 0xfc
lCPI1_70:
	.quad	60                              ; 0x3c
	.quad	124                             ; 0x7c
lCPI1_71:
	.quad	30720                           ; 0x7800
	.quad	35840                           ; 0x8c00
lCPI1_72:
	.quad	10240                           ; 0x2800
	.quad	15360                           ; 0x3c00
lCPI1_73:
	.quad	20480                           ; 0x5000
	.quad	25600                           ; 0x6400
lCPI1_74:
	.quad	0                               ; 0x0
	.quad	5120                            ; 0x1400
lCPI1_75:
	.quad	36864                           ; 0x9000
	.quad	43008                           ; 0xa800
lCPI1_76:
	.quad	12288                           ; 0x3000
	.quad	18432                           ; 0x4800
lCPI1_77:
	.quad	24576                           ; 0x6000
	.quad	30720                           ; 0x7800
lCPI1_78:
	.quad	0                               ; 0x0
	.quad	6144                            ; 0x1800
lCPI1_79:
	.quad	768                             ; 0x300
	.quad	1152                            ; 0x480
lCPI1_80:
	.quad	2304                            ; 0x900
	.quad	2688                            ; 0xa80
lCPI1_81:
	.quad	0                               ; 0x0
	.quad	384                             ; 0x180
lCPI1_82:
	.quad	1536                            ; 0x600
	.quad	1920                            ; 0x780
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_attention.packet_batch.blocks
	.p2align	2
_llm_attention.packet_batch.blocks:     ; @llm_attention.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_1030
; %bb.1:                                ; %block.batch.loop.preheader
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #1488
	mov	x23, x3
	mov	x24, x2
	mov	x26, x0
	mov	w20, #0                         ; =0x0
Lloh164:
	adrp	x8, lCPI1_0@PAGE
Lloh165:
	ldr	q29, [x8, lCPI1_0@PAGEOFF]
Lloh166:
	adrp	x8, lCPI1_1@PAGE
Lloh167:
	ldr	q30, [x8, lCPI1_1@PAGEOFF]
Lloh168:
	adrp	x8, lCPI1_2@PAGE
Lloh169:
	ldr	q0, [x8, lCPI1_2@PAGEOFF]
	str	q0, [sp, #64]                   ; 16-byte Spill
Lloh170:
	adrp	x8, lCPI1_3@PAGE
Lloh171:
	ldr	q0, [x8, lCPI1_3@PAGEOFF]
	str	q0, [sp, #48]                   ; 16-byte Spill
Lloh172:
	adrp	x8, lCPI1_4@PAGE
Lloh173:
	ldr	q0, [x8, lCPI1_4@PAGEOFF]
	str	q0, [sp, #32]                   ; 16-byte Spill
Lloh174:
	adrp	x8, lCPI1_5@PAGE
Lloh175:
	ldr	q0, [x8, lCPI1_5@PAGEOFF]
	str	q0, [sp, #16]                   ; 16-byte Spill
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	str	q0, [sp, #4976]                 ; 16-byte Spill
	ldp	w9, w8, [x2, #44]
	stp	w8, w9, [sp, #224]              ; 8-byte Folded Spill
	ldp	w12, w13, [x2]
	ldp	w14, w8, [x2, #8]
	str	x8, [sp, #216]                  ; 8-byte Spill
	mov	w27, #52429                     ; =0xcccd
	mov	w25, #80                        ; =0x50
	mov	w28, #43691                     ; =0xaaab
	mov	w21, #96                        ; =0x60
	mov	w19, #320                       ; =0x140
	str	w3, [sp, #108]                  ; 4-byte Spill
	stp	x0, x2, [sp, #88]               ; 16-byte Folded Spill
	str	q29, [sp, #3728]                ; 16-byte Spill
	str	q30, [sp, #192]                 ; 16-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x24, #36]
	ldr	w20, [sp, #212]                 ; 4-byte Reload
LBB1_3:                                 ; %llm_attention.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w12, #1
	ldp	w10, w9, [sp, #224]             ; 8-byte Folded Reload
	cmp	w8, w9
	cset	w8, eq
	csinc	w12, wzr, w12, eq
	cinc	w9, w11, eq
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w13, wzr, w9, ne
	add	w14, w14, w8
	add	w20, w20, #1
	cmp	w20, w23
	b.eq	LBB1_1029
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_15 Depth 2
                                        ;     Child Loop BB1_48 Depth 2
                                        ;     Child Loop BB1_50 Depth 2
                                        ;       Child Loop BB1_52 Depth 3
                                        ;       Child Loop BB1_87 Depth 3
                                        ;       Child Loop BB1_378 Depth 3
                                        ;         Child Loop BB1_379 Depth 4
                                        ;       Child Loop BB1_383 Depth 3
                                        ;         Child Loop BB1_384 Depth 4
                                        ;       Child Loop BB1_388 Depth 3
                                        ;         Child Loop BB1_389 Depth 4
                                        ;       Child Loop BB1_393 Depth 3
                                        ;         Child Loop BB1_394 Depth 4
                                        ;       Child Loop BB1_398 Depth 3
                                        ;         Child Loop BB1_399 Depth 4
                                        ;       Child Loop BB1_403 Depth 3
                                        ;         Child Loop BB1_404 Depth 4
                                        ;       Child Loop BB1_408 Depth 3
                                        ;         Child Loop BB1_409 Depth 4
                                        ;       Child Loop BB1_413 Depth 3
                                        ;         Child Loop BB1_414 Depth 4
                                        ;       Child Loop BB1_667 Depth 3
                                        ;       Child Loop BB1_830 Depth 3
                                        ;       Child Loop BB1_848 Depth 3
                                        ;       Child Loop BB1_866 Depth 3
                                        ;       Child Loop BB1_869 Depth 3
                                        ;       Child Loop BB1_872 Depth 3
                                        ;       Child Loop BB1_875 Depth 3
                                        ;       Child Loop BB1_878 Depth 3
                                        ;       Child Loop BB1_881 Depth 3
                                        ;       Child Loop BB1_884 Depth 3
                                        ;       Child Loop BB1_887 Depth 3
                                        ;       Child Loop BB1_890 Depth 3
                                        ;       Child Loop BB1_907 Depth 3
                                        ;     Child Loop BB1_1013 Depth 2
	ubfiz	x8, x12, #5, #32
	ldr	x15, [sp, #216]                 ; 8-byte Reload
	cmp	x8, x15
	csel	x9, x8, xzr, ls
	subs	x10, x15, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x15, x9
	str	x12, [sp, #240]                 ; 8-byte Spill
	stp	w12, w13, [x24]
	stp	w14, w13, [sp, #232]            ; 8-byte Folded Spill
	str	w14, [x24, #8]
	str	wzr, [x24, #36]
	ccmp	x8, x15, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.lo	LBB1_6
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x26
	mov	x1, x24
	bl	_llm_attention.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x24, #36]
	mov	x0, x26
	mov	x1, x24
	bl	_llm_attention.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x24, #36]
	mov	x0, x26
	mov	x1, x24
	bl	_llm_attention.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x24, #36]
	mov	x0, x26
	mov	x1, x24
	bl	_llm_attention.full_packet
	ldr	x12, [sp, #240]                 ; 8-byte Reload
	ldp	w14, w11, [sp, #232]            ; 8-byte Folded Reload
	b	LBB1_3
LBB1_6:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	w20, [sp, #212]                 ; 4-byte Spill
	lsr	x20, x22, #3
	cbz	x20, LBB1_11
; %bb.7:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x24, #36]
	mov	x0, x26
	mov	x1, x24
	bl	_llm_attention.full_packet
	cmp	x20, #1
	b.eq	LBB1_11
; %bb.8:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x24, #36]
	mov	x0, x26
	mov	x1, x24
	bl	_llm_attention.full_packet
	cmp	x20, #2
	b.eq	LBB1_11
; %bb.9:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x24, #36]
	mov	x0, x26
	mov	x1, x24
	bl	_llm_attention.full_packet
	cmp	x20, #3
	b.eq	LBB1_11
; %bb.10:                               ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x24, #36]
	mov	x0, x26
	mov	x1, x24
	bl	_llm_attention.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x24, #36]
	mov	x0, x26
	mov	x1, x24
	bl	_llm_attention.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x24, #36]
	mov	x0, x26
	mov	x1, x24
	bl	_llm_attention.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x24, #36]
	mov	x0, x26
	mov	x1, x24
	bl	_llm_attention.full_packet
LBB1_11:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w8, w22, #0x7
	ldr	q29, [sp, #3728]                ; 16-byte Reload
	ldr	q30, [sp, #192]                 ; 16-byte Reload
	ldr	x12, [sp, #240]                 ; 8-byte Reload
	ldp	w14, w11, [sp, #232]            ; 8-byte Folded Reload
	cbz	w8, LBB1_2
; %bb.12:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w9, w20, #3
	dup.4s	v31, w8
	str	w9, [x24, #36]
	cmhi.4s	v0, v31, v30
	cmhi.4s	v2, v31, v29
	uzp1.8h	v18, v2, v0
	umaxv.8h	h1, v18
	fmov	w8, s1
	tbz	w8, #0, LBB1_2
; %bb.13:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	x11, [x24, #136]
	mov	w10, #8704                      ; =0x2200
	add	x10, x11, x10
	dup.2d	v1, x10
	str	q1, [sp, #3600]                 ; 16-byte Spill
	mov	w10, #49664                     ; =0xc200
	add	x10, x11, x10
	dup.2d	v1, x10
	str	q1, [sp, #3584]                 ; 16-byte Spill
	mov	w10, #34816                     ; =0x8800
	movk	w10, #1, lsl #16
	add	x10, x11, x10
	dup.2d	v1, x10
	str	q1, [sp, #3696]                 ; 16-byte Spill
	mov	w10, #35328                     ; =0x8a00
	movk	w10, #1, lsl #16
	add	x10, x11, x10
	dup.2d	v1, x10
	str	q1, [sp, #3568]                 ; 16-byte Spill
	mov	w10, #38400                     ; =0x9600
	movk	w10, #1, lsl #16
	add	x17, x11, x10
	dup.2d	v1, x17
	str	q1, [sp, #3552]                 ; 16-byte Spill
	sshll.2d	v17, v2, #0
	sshll.2d	v5, v0, #0
	sshll2.2d	v8, v2, #0
	sshll2.2d	v10, v0, #0
	orr	w9, w9, w12, lsl #5
	dup.4s	v1, w9
	orr.16b	v3, v1, v30
	orr.16b	v1, v1, v29
	dup.2d	v7, x11
	and.16b	v22, v2, v1
	and.16b	v21, v0, v3
	ushll2.2d	v9, v21, #0
	add	x13, x11, #2560
	ushll2.2d	v11, v22, #0
	mov	w9, #33280                      ; =0x8200
	movk	w9, #1, lsl #16
	add	x9, x11, x9
	str	x9, [sp, #4936]                 ; 8-byte Spill
	ushll.2d	v12, v21, #0
	mov	w9, #33792                      ; =0x8400
	movk	w9, #1, lsl #16
	add	x9, x11, x9
	str	x9, [sp, #4928]                 ; 8-byte Spill
	ushll.2d	v13, v22, #0
	mov	w9, #34304                      ; =0x8600
	movk	w9, #1, lsl #16
	str	x11, [sp, #3720]                ; 8-byte Spill
	add	x14, x11, x9
	ldr	x9, [x26]
	ldr	x15, [x26, #16]
	ldr	x16, [x26, #32]
	ldr	x10, [x26, #48]
	str	x10, [sp, #176]                 ; 8-byte Spill
	and.16b	v1, v10, v7
	and.16b	v6, v8, v7
	and.16b	v4, v5, v7
	and.16b	v16, v17, v7
	ldp	q7, q3, [sp, #48]               ; 32-byte Folded Reload
	and.16b	v3, v10, v3
	and.16b	v7, v8, v7
	ldp	q19, q20, [sp, #16]             ; 32-byte Folded Reload
	and.16b	v5, v5, v20
	and.16b	v17, v17, v19
	movi.4s	v20, #80
	umull2.2d	v19, v21, v20
	umull2.2d	v20, v22, v20
	movi.2s	v23, #80
	umull.2d	v21, v21, v23
	umull.2d	v22, v22, v23
	adrp	x12, lCPI1_6@PAGE
	b	LBB1_15
LBB1_14:                                ; %else506
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x8, x8, #1
	cmp	x8, #80
	b.eq	LBB1_47
LBB1_15:                                ; %direct.true.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q23, [x12, lCPI1_6@PAGEOFF]
	str	q23, [sp, #4416]                ; 16-byte Spill
	and.16b	v23, v18, v23
	addv.8h	h23, v23
	fmov	w10, s23
	dup.2d	v26, x8
	add.2d	v24, v26, v22
	shl.2d	v24, v24, #2
	dup.2d	v27, x9
	add.2d	v28, v27, v24
	movi.2d	v25, #0000000000000000
	movi.2d	v24, #0000000000000000
	tbnz	w10, #0, LBB1_31
; %bb.16:                               ; %else445
                                        ;   in Loop: Header=BB1_15 Depth=2
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB1_32
LBB1_17:                                ; %else448
                                        ;   in Loop: Header=BB1_15 Depth=2
	add.2d	v28, v26, v20
	shl.2d	v28, v28, #2
	add.2d	v28, v27, v28
	tbnz	w10, #2, LBB1_33
LBB1_18:                                ; %else452
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w10, #3, LBB1_34
LBB1_19:                                ; %else456
                                        ;   in Loop: Header=BB1_15 Depth=2
	add.2d	v28, v26, v21
	shl.2d	v28, v28, #2
	add.2d	v28, v27, v28
	tbnz	w10, #4, LBB1_35
LBB1_20:                                ; %else460
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w10, #5, LBB1_36
LBB1_21:                                ; %else464
                                        ;   in Loop: Header=BB1_15 Depth=2
	add.2d	v28, v26, v19
	shl.2d	v28, v28, #2
	add.2d	v27, v27, v28
	tbnz	w10, #6, LBB1_37
LBB1_22:                                ; %else468
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w10, #7, LBB1_38
LBB1_23:                                ; %else472
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	w10, s23
	shl.2d	v26, v26, #2
	add.2d	v27, v16, v17
	add.2d	v27, v27, v26
	tbnz	w10, #0, LBB1_39
LBB1_24:                                ; %else478
                                        ;   in Loop: Header=BB1_15 Depth=2
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB1_40
LBB1_25:                                ; %else482
                                        ;   in Loop: Header=BB1_15 Depth=2
	add.2d	v27, v6, v7
	add.2d	v27, v27, v26
	tbnz	w10, #2, LBB1_41
LBB1_26:                                ; %else486
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w10, #3, LBB1_42
LBB1_27:                                ; %else490
                                        ;   in Loop: Header=BB1_15 Depth=2
	add.2d	v25, v4, v5
	add.2d	v25, v25, v26
	tbnz	w10, #4, LBB1_43
LBB1_28:                                ; %else494
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w10, #5, LBB1_44
LBB1_29:                                ; %else498
                                        ;   in Loop: Header=BB1_15 Depth=2
	add.2d	v25, v1, v3
	add.2d	v25, v25, v26
	tbnz	w10, #6, LBB1_45
LBB1_30:                                ; %else502
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbz	w10, #7, LBB1_14
	b	LBB1_46
LBB1_31:                                ; %cond.load
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	x11, d28
	ldr	s25, [x11]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB1_17
LBB1_32:                                ; %cond.load446
                                        ;   in Loop: Header=BB1_15 Depth=2
	mov.d	x11, v28[1]
	ld1.s	{ v25 }[1], [x11]
	add.2d	v28, v26, v20
	shl.2d	v28, v28, #2
	add.2d	v28, v27, v28
	tbz	w10, #2, LBB1_18
LBB1_33:                                ; %cond.load450
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	x11, d28
	ld1.s	{ v25 }[2], [x11]
	tbz	w10, #3, LBB1_19
LBB1_34:                                ; %cond.load454
                                        ;   in Loop: Header=BB1_15 Depth=2
	mov.d	x11, v28[1]
	ld1.s	{ v25 }[3], [x11]
	add.2d	v28, v26, v21
	shl.2d	v28, v28, #2
	add.2d	v28, v27, v28
	tbz	w10, #4, LBB1_20
LBB1_35:                                ; %cond.load458
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	x11, d28
	ld1.s	{ v24 }[0], [x11]
	tbz	w10, #5, LBB1_21
LBB1_36:                                ; %cond.load462
                                        ;   in Loop: Header=BB1_15 Depth=2
	mov.d	x11, v28[1]
	ld1.s	{ v24 }[1], [x11]
	add.2d	v28, v26, v19
	shl.2d	v28, v28, #2
	add.2d	v27, v27, v28
	tbz	w10, #6, LBB1_22
LBB1_37:                                ; %cond.load466
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	x11, d27
	ld1.s	{ v24 }[2], [x11]
	tbz	w10, #7, LBB1_23
LBB1_38:                                ; %cond.load470
                                        ;   in Loop: Header=BB1_15 Depth=2
	mov.d	x10, v27[1]
	ld1.s	{ v24 }[3], [x10]
	fmov	w10, s23
	shl.2d	v26, v26, #2
	add.2d	v27, v16, v17
	add.2d	v27, v27, v26
	tbz	w10, #0, LBB1_24
LBB1_39:                                ; %cond.store475
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	x11, d27
	str	s25, [x11]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB1_25
LBB1_40:                                ; %cond.store479
                                        ;   in Loop: Header=BB1_15 Depth=2
	mov.d	x11, v27[1]
	st1.s	{ v25 }[1], [x11]
	add.2d	v27, v6, v7
	add.2d	v27, v27, v26
	tbz	w10, #2, LBB1_26
LBB1_41:                                ; %cond.store483
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	x11, d27
	st1.s	{ v25 }[2], [x11]
	tbz	w10, #3, LBB1_27
LBB1_42:                                ; %cond.store487
                                        ;   in Loop: Header=BB1_15 Depth=2
	mov.d	x11, v27[1]
	st1.s	{ v25 }[3], [x11]
	add.2d	v25, v4, v5
	add.2d	v25, v25, v26
	tbz	w10, #4, LBB1_28
LBB1_43:                                ; %cond.store491
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	x11, d25
	str	s24, [x11]
	tbz	w10, #5, LBB1_29
LBB1_44:                                ; %cond.store495
                                        ;   in Loop: Header=BB1_15 Depth=2
	mov.d	x11, v25[1]
	st1.s	{ v24 }[1], [x11]
	add.2d	v25, v1, v3
	add.2d	v25, v25, v26
	tbz	w10, #6, LBB1_30
LBB1_45:                                ; %cond.store499
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	x11, d25
	st1.s	{ v24 }[2], [x11]
	tbz	w10, #7, LBB1_14
LBB1_46:                                ; %cond.store503
                                        ;   in Loop: Header=BB1_15 Depth=2
	mov.d	x10, v25[1]
	st1.s	{ v24 }[3], [x10]
	b	LBB1_14
LBB1_47:                                ; %direct.true131.i.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	x17, [sp, #256]                 ; 8-byte Spill
	mov	x8, #0                          ; =0x0
LBB1_48:                                ; %direct.true131.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x9, x13, x8
	ldp	q19, q20, [x9]
	cmhs.4s	v21, v30, v31
	and.16b	v20, v21, v20
	cmhs.4s	v22, v29, v31
	and.16b	v19, v22, v19
	stp	q19, q20, [x9]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB1_48
; %bb.49:                               ; %direct.false132.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	q22, [sp, #3520]                ; 16-byte Spill
	str	q21, [sp, #3536]                ; 16-byte Spill
	str	q31, [sp, #3616]                ; 16-byte Spill
	ldr	x24, [sp, #3720]                ; 8-byte Reload
	add	x8, x24, #2560
	str	x8, [sp, #184]                  ; 8-byte Spill
	mov	x17, #0                         ; =0x0
	xtn.8b	v25, v18
	sshll.2d	v18, v0, #0
	sshll.2d	v19, v2, #0
	stp	q13, q12, [sp, #112]            ; 32-byte Folded Spill
	ushr.2d	v20, v13, #2
	stp	q11, q9, [sp, #144]             ; 32-byte Folded Spill
	ushr.2d	v21, v11, #2
	ushr.2d	v22, v12, #2
	ushr.2d	v24, v9, #2
	mov.d	x8, v24[1]
	mov	w10, #2053                      ; =0x805
	mul	x8, x8, x10
	fmov	x9, d24
	mul	x9, x9, x10
	fmov	d24, x9
	mov.d	v24[1], x8
	mov.d	x8, v22[1]
	mul	x8, x8, x10
	fmov	x9, d22
	mul	x9, x9, x10
	fmov	d22, x9
	mov.d	v22[1], x8
	mov.d	x8, v21[1]
	mul	x8, x8, x10
	fmov	x9, d21
	mul	x9, x9, x10
	fmov	d21, x9
	mov.d	v21[1], x8
	mov.d	x8, v20[1]
	mul	x8, x8, x10
	fmov	x9, d20
	mul	x9, x9, x10
	fmov	d20, x9
	mov.d	v20[1], x8
	and.16b	v19, v19, v20
	str	q19, [sp, #3504]                ; 16-byte Spill
	and.16b	v19, v8, v21
	str	q19, [sp, #3664]                ; 16-byte Spill
	and.16b	v18, v18, v22
	str	q18, [sp, #3648]                ; 16-byte Spill
	and.16b	v18, v10, v24
	str	q18, [sp, #3632]                ; 16-byte Spill
	ldr	x8, [sp, #4936]                 ; 8-byte Reload
	dup.2d	v24, x8
Lloh176:
	adrp	x8, lCPI1_7@PAGE
Lloh177:
	ldr	q18, [x8, lCPI1_7@PAGEOFF]
	str	q18, [sp, #3792]                ; 16-byte Spill
	add.2d	v18, v24, v18
	str	q18, [sp, #3488]                ; 16-byte Spill
Lloh178:
	adrp	x8, lCPI1_8@PAGE
Lloh179:
	ldr	q18, [x8, lCPI1_8@PAGEOFF]
	str	q18, [sp, #3776]                ; 16-byte Spill
	add.2d	v18, v24, v18
	str	q18, [sp, #3472]                ; 16-byte Spill
Lloh180:
	adrp	x8, lCPI1_9@PAGE
Lloh181:
	ldr	q18, [x8, lCPI1_9@PAGEOFF]
	str	q18, [sp, #3760]                ; 16-byte Spill
	add.2d	v18, v24, v18
	str	q18, [sp, #3456]                ; 16-byte Spill
Lloh182:
	adrp	x8, lCPI1_10@PAGE
Lloh183:
	ldr	q18, [x8, lCPI1_10@PAGEOFF]
	str	q18, [sp, #3744]                ; 16-byte Spill
	add.2d	v18, v24, v18
	str	q18, [sp, #3440]                ; 16-byte Spill
Lloh184:
	adrp	x8, lCPI1_11@PAGE
Lloh185:
	ldr	q18, [x8, lCPI1_11@PAGEOFF]
	str	q18, [sp, #4960]                ; 16-byte Spill
	add.2d	v18, v24, v18
	str	q18, [sp, #3424]                ; 16-byte Spill
Lloh186:
	adrp	x8, lCPI1_12@PAGE
Lloh187:
	ldr	q18, [x8, lCPI1_12@PAGEOFF]
	str	q18, [sp, #4944]                ; 16-byte Spill
	add.2d	v18, v24, v18
	str	q18, [sp, #3408]                ; 16-byte Spill
Lloh188:
	adrp	x8, lCPI1_13@PAGE
Lloh189:
	ldr	q18, [x8, lCPI1_13@PAGEOFF]
	str	q18, [sp, #4912]                ; 16-byte Spill
	add.2d	v18, v24, v18
	str	q18, [sp, #3392]                ; 16-byte Spill
Lloh190:
	adrp	x8, lCPI1_14@PAGE
Lloh191:
	ldr	q18, [x8, lCPI1_14@PAGEOFF]
	str	q18, [sp, #4896]                ; 16-byte Spill
	add.2d	v18, v24, v18
	str	q18, [sp, #3376]                ; 16-byte Spill
Lloh192:
	adrp	x8, lCPI1_15@PAGE
Lloh193:
	ldr	q18, [x8, lCPI1_15@PAGEOFF]
	str	q18, [sp, #4880]                ; 16-byte Spill
	add.2d	v18, v24, v18
	str	q18, [sp, #3360]                ; 16-byte Spill
	umov.b	w8, v25[0]
	str	w8, [sp, #4492]                 ; 4-byte Spill
	umov.b	w8, v25[1]
	str	w8, [sp, #4488]                 ; 4-byte Spill
	umov.b	w8, v25[2]
	str	w8, [sp, #4484]                 ; 4-byte Spill
	umov.b	w8, v25[3]
	str	w8, [sp, #4480]                 ; 4-byte Spill
	umov.b	w8, v25[4]
	str	w8, [sp, #4476]                 ; 4-byte Spill
	umov.b	w8, v25[5]
	str	w8, [sp, #4472]                 ; 4-byte Spill
	umov.b	w8, v25[6]
	str	w8, [sp, #4468]                 ; 4-byte Spill
	umov.b	w8, v25[7]
	str	w8, [sp, #4464]                 ; 4-byte Spill
Lloh194:
	adrp	x8, lCPI1_16@PAGE
Lloh195:
	ldr	q18, [x8, lCPI1_16@PAGEOFF]
	fmov	x8, d16
	mov.d	x9, v16[1]
	add.2d	v16, v24, v18
	str	q16, [sp, #3344]                ; 16-byte Spill
	fmov	x10, d17
	mov.d	x11, v17[1]
Lloh196:
	adrp	x12, lCPI1_17@PAGE
Lloh197:
	ldr	q16, [x12, lCPI1_17@PAGEOFF]
	fmov	x12, d6
	mov.d	x13, v6[1]
	add.2d	v6, v24, v16
	str	q6, [sp, #3328]                 ; 16-byte Spill
	fmov	x1, d7
	mov.d	x0, v7[1]
Lloh198:
	adrp	x2, lCPI1_18@PAGE
Lloh199:
	ldr	q17, [x2, lCPI1_18@PAGEOFF]
	fmov	x2, d4
	mov.d	x3, v4[1]
	add.2d	v4, v24, v17
	str	q4, [sp, #3312]                 ; 16-byte Spill
	fmov	x5, d5
	mov.d	x4, v5[1]
Lloh200:
	adrp	x6, lCPI1_19@PAGE
Lloh201:
	ldr	q26, [x6, lCPI1_19@PAGEOFF]
	fmov	x6, d1
	mov.d	x7, v1[1]
	add.2d	v1, v24, v26
	str	q1, [sp, #3296]                 ; 16-byte Spill
	fmov	x22, d3
	mov.d	x20, v3[1]
Lloh202:
	adrp	x23, lCPI1_20@PAGE
Lloh203:
	ldr	q19, [x23, lCPI1_20@PAGEOFF]
	add.2d	v1, v24, v19
	str	q1, [sp, #3280]                 ; 16-byte Spill
Lloh204:
	adrp	x23, lCPI1_21@PAGE
Lloh205:
	ldr	q20, [x23, lCPI1_21@PAGEOFF]
	add.2d	v1, v24, v20
	str	q1, [sp, #3264]                 ; 16-byte Spill
Lloh206:
	adrp	x23, lCPI1_22@PAGE
Lloh207:
	ldr	q21, [x23, lCPI1_22@PAGEOFF]
	add.2d	v1, v24, v21
	str	q1, [sp, #3248]                 ; 16-byte Spill
Lloh208:
	adrp	x23, lCPI1_23@PAGE
Lloh209:
	ldr	q22, [x23, lCPI1_23@PAGEOFF]
	add.2d	v1, v24, v22
	str	q1, [sp, #3232]                 ; 16-byte Spill
Lloh210:
	adrp	x23, lCPI1_24@PAGE
Lloh211:
	ldr	q25, [x23, lCPI1_24@PAGEOFF]
	add.2d	v1, v24, v25
	str	q1, [sp, #3216]                 ; 16-byte Spill
Lloh212:
	adrp	x23, lCPI1_25@PAGE
Lloh213:
	ldr	q27, [x23, lCPI1_25@PAGEOFF]
	add.2d	v1, v24, v27
	str	q1, [sp, #3200]                 ; 16-byte Spill
Lloh214:
	adrp	x23, lCPI1_26@PAGE
Lloh215:
	ldr	q28, [x23, lCPI1_26@PAGEOFF]
	add.2d	v1, v24, v28
	str	q1, [sp, #3184]                 ; 16-byte Spill
Lloh216:
	adrp	x23, lCPI1_27@PAGE
Lloh217:
	ldr	q29, [x23, lCPI1_27@PAGEOFF]
	add.2d	v1, v24, v29
	str	q1, [sp, #3168]                 ; 16-byte Spill
Lloh218:
	adrp	x23, lCPI1_28@PAGE
Lloh219:
	ldr	q30, [x23, lCPI1_28@PAGEOFF]
	add.2d	v1, v24, v30
	str	q1, [sp, #3152]                 ; 16-byte Spill
Lloh220:
	adrp	x23, lCPI1_29@PAGE
Lloh221:
	ldr	q31, [x23, lCPI1_29@PAGEOFF]
	add.2d	v1, v24, v31
	str	q1, [sp, #3136]                 ; 16-byte Spill
Lloh222:
	adrp	x23, lCPI1_30@PAGE
Lloh223:
	ldr	q9, [x23, lCPI1_30@PAGEOFF]
	add.2d	v1, v24, v9
	str	q1, [sp, #3120]                 ; 16-byte Spill
Lloh224:
	adrp	x23, lCPI1_31@PAGE
Lloh225:
	ldr	q11, [x23, lCPI1_31@PAGEOFF]
	add.2d	v1, v24, v11
	str	q1, [sp, #3104]                 ; 16-byte Spill
Lloh226:
	adrp	x23, lCPI1_32@PAGE
Lloh227:
	ldr	q12, [x23, lCPI1_32@PAGEOFF]
	add.2d	v1, v24, v12
	str	q1, [sp, #3088]                 ; 16-byte Spill
Lloh228:
	adrp	x23, lCPI1_33@PAGE
Lloh229:
	ldr	q13, [x23, lCPI1_33@PAGEOFF]
	add.2d	v1, v24, v13
	str	q1, [sp, #3072]                 ; 16-byte Spill
Lloh230:
	adrp	x23, lCPI1_34@PAGE
Lloh231:
	ldr	q14, [x23, lCPI1_34@PAGEOFF]
	add.2d	v1, v24, v14
	str	q1, [sp, #3056]                 ; 16-byte Spill
Lloh232:
	adrp	x23, lCPI1_35@PAGE
Lloh233:
	ldr	q1, [x23, lCPI1_35@PAGEOFF]
	str	q1, [sp, #4864]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #3040]                 ; 16-byte Spill
Lloh234:
	adrp	x23, lCPI1_36@PAGE
Lloh235:
	ldr	q1, [x23, lCPI1_36@PAGEOFF]
	str	q1, [sp, #4848]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #3024]                 ; 16-byte Spill
Lloh236:
	adrp	x23, lCPI1_37@PAGE
Lloh237:
	ldr	q1, [x23, lCPI1_37@PAGEOFF]
	str	q1, [sp, #4832]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #3008]                 ; 16-byte Spill
Lloh238:
	adrp	x23, lCPI1_38@PAGE
Lloh239:
	ldr	q1, [x23, lCPI1_38@PAGEOFF]
	str	q1, [sp, #5488]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2992]                 ; 16-byte Spill
Lloh240:
	adrp	x23, lCPI1_39@PAGE
Lloh241:
	ldr	q1, [x23, lCPI1_39@PAGEOFF]
	str	q1, [sp, #5456]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2976]                 ; 16-byte Spill
Lloh242:
	adrp	x23, lCPI1_40@PAGE
Lloh243:
	ldr	q1, [x23, lCPI1_40@PAGEOFF]
	str	q1, [sp, #5424]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2960]                 ; 16-byte Spill
Lloh244:
	adrp	x23, lCPI1_41@PAGE
Lloh245:
	ldr	q1, [x23, lCPI1_41@PAGEOFF]
	str	q1, [sp, #5392]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2944]                 ; 16-byte Spill
Lloh246:
	adrp	x23, lCPI1_42@PAGE
Lloh247:
	ldr	q1, [x23, lCPI1_42@PAGEOFF]
	str	q1, [sp, #5360]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2928]                 ; 16-byte Spill
Lloh248:
	adrp	x23, lCPI1_43@PAGE
	str	q10, [sp, #4496]                ; 16-byte Spill
Lloh249:
	ldr	q1, [x23, lCPI1_43@PAGEOFF]
	str	q1, [sp, #5328]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2912]                 ; 16-byte Spill
Lloh250:
	adrp	x23, lCPI1_44@PAGE
Lloh251:
	ldr	q1, [x23, lCPI1_44@PAGEOFF]
	str	q1, [sp, #5504]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2896]                 ; 16-byte Spill
Lloh252:
	adrp	x23, lCPI1_45@PAGE
Lloh253:
	ldr	q1, [x23, lCPI1_45@PAGEOFF]
	str	q1, [sp, #5472]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2880]                 ; 16-byte Spill
Lloh254:
	adrp	x23, lCPI1_46@PAGE
Lloh255:
	ldr	q1, [x23, lCPI1_46@PAGEOFF]
	str	q1, [sp, #5440]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2864]                 ; 16-byte Spill
Lloh256:
	adrp	x23, lCPI1_47@PAGE
	str	q8, [sp, #3680]                 ; 16-byte Spill
Lloh257:
	ldr	q1, [x23, lCPI1_47@PAGEOFF]
	str	q1, [sp, #5408]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2848]                 ; 16-byte Spill
Lloh258:
	adrp	x23, lCPI1_48@PAGE
Lloh259:
	ldr	q1, [x23, lCPI1_48@PAGEOFF]
	str	q1, [sp, #5376]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2832]                 ; 16-byte Spill
Lloh260:
	adrp	x23, lCPI1_49@PAGE
Lloh261:
	ldr	q1, [x23, lCPI1_49@PAGEOFF]
	str	q1, [sp, #5344]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2816]                 ; 16-byte Spill
Lloh262:
	adrp	x23, lCPI1_50@PAGE
Lloh263:
	ldr	q1, [x23, lCPI1_50@PAGEOFF]
	str	q1, [sp, #5312]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2800]                 ; 16-byte Spill
Lloh264:
	adrp	x23, lCPI1_51@PAGE
Lloh265:
	ldr	q1, [x23, lCPI1_51@PAGEOFF]
	str	q1, [sp, #5296]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2784]                 ; 16-byte Spill
Lloh266:
	adrp	x23, lCPI1_52@PAGE
Lloh267:
	ldr	q1, [x23, lCPI1_52@PAGEOFF]
	str	q1, [sp, #5280]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2768]                 ; 16-byte Spill
Lloh268:
	adrp	x23, lCPI1_53@PAGE
Lloh269:
	ldr	q1, [x23, lCPI1_53@PAGEOFF]
	str	q1, [sp, #5264]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2752]                 ; 16-byte Spill
Lloh270:
	adrp	x23, lCPI1_54@PAGE
Lloh271:
	ldr	q1, [x23, lCPI1_54@PAGEOFF]
	str	q1, [sp, #5248]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2736]                 ; 16-byte Spill
Lloh272:
	adrp	x23, lCPI1_55@PAGE
Lloh273:
	ldr	q1, [x23, lCPI1_55@PAGEOFF]
	str	q1, [sp, #5232]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2720]                 ; 16-byte Spill
Lloh274:
	adrp	x23, lCPI1_56@PAGE
Lloh275:
	ldr	q1, [x23, lCPI1_56@PAGEOFF]
	str	q1, [sp, #5216]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2704]                 ; 16-byte Spill
Lloh276:
	adrp	x23, lCPI1_57@PAGE
Lloh277:
	ldr	q1, [x23, lCPI1_57@PAGEOFF]
	str	q1, [sp, #5200]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2688]                 ; 16-byte Spill
Lloh278:
	adrp	x23, lCPI1_58@PAGE
Lloh279:
	ldr	q1, [x23, lCPI1_58@PAGEOFF]
	str	q1, [sp, #5184]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2672]                 ; 16-byte Spill
Lloh280:
	adrp	x23, lCPI1_59@PAGE
Lloh281:
	ldr	q1, [x23, lCPI1_59@PAGEOFF]
	str	q1, [sp, #5168]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2656]                 ; 16-byte Spill
Lloh282:
	adrp	x23, lCPI1_60@PAGE
Lloh283:
	ldr	q1, [x23, lCPI1_60@PAGEOFF]
	str	q1, [sp, #5152]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2640]                 ; 16-byte Spill
Lloh284:
	adrp	x23, lCPI1_61@PAGE
Lloh285:
	ldr	q1, [x23, lCPI1_61@PAGEOFF]
	str	q1, [sp, #5136]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2624]                 ; 16-byte Spill
Lloh286:
	adrp	x23, lCPI1_62@PAGE
Lloh287:
	ldr	q1, [x23, lCPI1_62@PAGEOFF]
	str	q1, [sp, #5120]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2608]                 ; 16-byte Spill
Lloh288:
	adrp	x23, lCPI1_63@PAGE
Lloh289:
	ldr	q1, [x23, lCPI1_63@PAGEOFF]
	str	q1, [sp, #5104]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2592]                 ; 16-byte Spill
Lloh290:
	adrp	x23, lCPI1_64@PAGE
Lloh291:
	ldr	q1, [x23, lCPI1_64@PAGEOFF]
	str	q1, [sp, #5088]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2576]                 ; 16-byte Spill
Lloh292:
	adrp	x23, lCPI1_65@PAGE
Lloh293:
	ldr	q1, [x23, lCPI1_65@PAGEOFF]
	str	q1, [sp, #5072]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2560]                 ; 16-byte Spill
Lloh294:
	adrp	x23, lCPI1_66@PAGE
Lloh295:
	ldr	q1, [x23, lCPI1_66@PAGEOFF]
	str	q1, [sp, #5056]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2544]                 ; 16-byte Spill
Lloh296:
	adrp	x23, lCPI1_67@PAGE
Lloh297:
	ldr	q1, [x23, lCPI1_67@PAGEOFF]
	str	q1, [sp, #5040]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2528]                 ; 16-byte Spill
Lloh298:
	adrp	x23, lCPI1_68@PAGE
Lloh299:
	ldr	q1, [x23, lCPI1_68@PAGEOFF]
	str	q1, [sp, #5024]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2512]                 ; 16-byte Spill
Lloh300:
	adrp	x23, lCPI1_69@PAGE
Lloh301:
	ldr	q1, [x23, lCPI1_69@PAGEOFF]
	str	q1, [sp, #5008]                 ; 16-byte Spill
	add.2d	v1, v24, v1
	str	q1, [sp, #2496]                 ; 16-byte Spill
Lloh302:
	adrp	x23, lCPI1_70@PAGE
Lloh303:
	ldr	q1, [x23, lCPI1_70@PAGEOFF]
	str	q1, [sp, #4992]                 ; 16-byte Spill
	add.2d	v24, v24, v1
	str	q24, [sp, #2480]                ; 16-byte Spill
	ldr	x23, [sp, #4928]                ; 8-byte Reload
	dup.2d	v24, x23
	ldr	q15, [sp, #3792]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #2464]                ; 16-byte Spill
	ldr	q15, [sp, #3776]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #2448]                ; 16-byte Spill
	ldr	q15, [sp, #3760]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #2432]                ; 16-byte Spill
	ldr	q15, [sp, #3744]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #2416]                ; 16-byte Spill
	ldr	q1, [sp, #4960]                 ; 16-byte Reload
	add.2d	v15, v24, v1
	str	q15, [sp, #2400]                ; 16-byte Spill
	ldr	q3, [sp, #4944]                 ; 16-byte Reload
	add.2d	v15, v24, v3
	str	q15, [sp, #2384]                ; 16-byte Spill
	ldr	q4, [sp, #4912]                 ; 16-byte Reload
	add.2d	v15, v24, v4
	str	q15, [sp, #2368]                ; 16-byte Spill
	ldr	q5, [sp, #4896]                 ; 16-byte Reload
	add.2d	v15, v24, v5
	str	q15, [sp, #2352]                ; 16-byte Spill
	ldr	q6, [sp, #4880]                 ; 16-byte Reload
	add.2d	v15, v24, v6
	str	q15, [sp, #2336]                ; 16-byte Spill
	mov.16b	v7, v18
	add.2d	v15, v24, v18
	str	q15, [sp, #2320]                ; 16-byte Spill
	add.2d	v15, v24, v16
	str	q15, [sp, #2304]                ; 16-byte Spill
	add.2d	v15, v24, v17
	str	q15, [sp, #2288]                ; 16-byte Spill
	mov.16b	v18, v26
	add.2d	v15, v24, v26
	str	q15, [sp, #2272]                ; 16-byte Spill
	add.2d	v15, v24, v19
	str	q15, [sp, #2256]                ; 16-byte Spill
	add.2d	v15, v24, v20
	str	q15, [sp, #2240]                ; 16-byte Spill
	add.2d	v15, v24, v21
	str	q15, [sp, #2224]                ; 16-byte Spill
	add.2d	v15, v24, v22
	str	q15, [sp, #2208]                ; 16-byte Spill
	add.2d	v15, v24, v25
	str	q15, [sp, #2192]                ; 16-byte Spill
	mov.16b	v26, v27
	add.2d	v15, v24, v27
	str	q15, [sp, #2176]                ; 16-byte Spill
	mov.16b	v27, v28
	add.2d	v15, v24, v28
	str	q15, [sp, #2160]                ; 16-byte Spill
	mov.16b	v28, v29
	add.2d	v15, v24, v29
	str	q15, [sp, #2144]                ; 16-byte Spill
	mov.16b	v29, v30
	add.2d	v15, v24, v30
	str	q15, [sp, #2128]                ; 16-byte Spill
	mov.16b	v30, v31
	add.2d	v15, v24, v31
	str	q15, [sp, #2112]                ; 16-byte Spill
	mov.16b	v31, v9
	add.2d	v15, v24, v9
	str	q15, [sp, #2096]                ; 16-byte Spill
	mov.16b	v8, v11
	add.2d	v15, v24, v11
	str	q15, [sp, #2080]                ; 16-byte Spill
	mov.16b	v9, v12
	add.2d	v15, v24, v12
	str	q15, [sp, #2064]                ; 16-byte Spill
	mov.16b	v10, v13
	add.2d	v15, v24, v13
	str	q15, [sp, #2048]                ; 16-byte Spill
	mov.16b	v11, v14
	add.2d	v15, v24, v14
	str	q15, [sp, #2032]                ; 16-byte Spill
	ldr	q12, [sp, #4864]                ; 16-byte Reload
	add.2d	v15, v24, v12
	str	q15, [sp, #2016]                ; 16-byte Spill
	ldr	q13, [sp, #4848]                ; 16-byte Reload
	add.2d	v15, v24, v13
	str	q15, [sp, #2000]                ; 16-byte Spill
	ldr	q14, [sp, #4832]                ; 16-byte Reload
	add.2d	v15, v24, v14
	str	q15, [sp, #1984]                ; 16-byte Spill
	ldr	q15, [sp, #5488]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1968]                ; 16-byte Spill
	ldr	q15, [sp, #5456]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1952]                ; 16-byte Spill
	ldr	q15, [sp, #5424]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1936]                ; 16-byte Spill
	ldr	q15, [sp, #5392]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1920]                ; 16-byte Spill
	ldr	q15, [sp, #5360]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1904]                ; 16-byte Spill
	ldr	q15, [sp, #5328]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1888]                ; 16-byte Spill
	ldr	q15, [sp, #5504]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1872]                ; 16-byte Spill
	ldr	q15, [sp, #5472]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1856]                ; 16-byte Spill
	ldr	q15, [sp, #5440]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1840]                ; 16-byte Spill
	ldr	q15, [sp, #5408]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1824]                ; 16-byte Spill
	ldr	q15, [sp, #5376]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1808]                ; 16-byte Spill
	ldr	q15, [sp, #5344]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1792]                ; 16-byte Spill
	ldr	q15, [sp, #5312]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1776]                ; 16-byte Spill
	ldr	q15, [sp, #5296]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1760]                ; 16-byte Spill
	ldr	q15, [sp, #5280]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1744]                ; 16-byte Spill
	ldr	q15, [sp, #5264]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1728]                ; 16-byte Spill
	ldr	q15, [sp, #5248]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1712]                ; 16-byte Spill
	ldr	q15, [sp, #5232]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1696]                ; 16-byte Spill
	ldr	q15, [sp, #5216]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1680]                ; 16-byte Spill
	ldr	q15, [sp, #5200]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1664]                ; 16-byte Spill
	ldr	q15, [sp, #5184]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1648]                ; 16-byte Spill
	ldr	q15, [sp, #5168]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1632]                ; 16-byte Spill
	ldr	q15, [sp, #5152]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1616]                ; 16-byte Spill
	ldr	q15, [sp, #5136]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1600]                ; 16-byte Spill
	ldr	q15, [sp, #5120]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1584]                ; 16-byte Spill
	ldr	q15, [sp, #5104]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1568]                ; 16-byte Spill
	ldr	q15, [sp, #5088]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1552]                ; 16-byte Spill
	ldr	q15, [sp, #5072]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1536]                ; 16-byte Spill
	ldr	q15, [sp, #5056]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1520]                ; 16-byte Spill
	ldr	q15, [sp, #5040]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1504]                ; 16-byte Spill
	ldr	q15, [sp, #5024]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1488]                ; 16-byte Spill
	ldr	q15, [sp, #5008]                ; 16-byte Reload
	add.2d	v15, v24, v15
	str	q15, [sp, #1472]                ; 16-byte Spill
	ldr	q15, [sp, #4992]                ; 16-byte Reload
	add.2d	v24, v24, v15
	str	q24, [sp, #1456]                ; 16-byte Spill
	ldr	q24, [sp, #3696]                ; 16-byte Reload
	add.2d	v15, v24, v1
	str	q15, [sp, #1440]                ; 16-byte Spill
	add.2d	v15, v24, v3
	str	q15, [sp, #1424]                ; 16-byte Spill
	add.2d	v15, v24, v4
	str	q15, [sp, #1408]                ; 16-byte Spill
	add.2d	v15, v24, v5
	str	q15, [sp, #1392]                ; 16-byte Spill
	add.2d	v15, v24, v6
	str	q15, [sp, #1376]                ; 16-byte Spill
	add.2d	v15, v24, v7
	str	q15, [sp, #1360]                ; 16-byte Spill
	add.2d	v15, v24, v16
	str	q15, [sp, #1344]                ; 16-byte Spill
	add.2d	v15, v24, v17
	str	q15, [sp, #1328]                ; 16-byte Spill
	add.2d	v15, v24, v18
	str	q15, [sp, #1312]                ; 16-byte Spill
	add.2d	v15, v24, v19
	str	q15, [sp, #1296]                ; 16-byte Spill
	add.2d	v15, v24, v20
	str	q15, [sp, #1280]                ; 16-byte Spill
	add.2d	v15, v24, v21
	str	q15, [sp, #1264]                ; 16-byte Spill
	add.2d	v15, v24, v22
	str	q15, [sp, #1248]                ; 16-byte Spill
	add.2d	v15, v24, v25
	str	q15, [sp, #1232]                ; 16-byte Spill
	add.2d	v15, v24, v26
	str	q15, [sp, #1216]                ; 16-byte Spill
	add.2d	v15, v24, v27
	str	q15, [sp, #1200]                ; 16-byte Spill
	add.2d	v15, v24, v28
	str	q15, [sp, #1184]                ; 16-byte Spill
	add.2d	v15, v24, v29
	str	q15, [sp, #1168]                ; 16-byte Spill
	add.2d	v15, v24, v30
	str	q15, [sp, #1152]                ; 16-byte Spill
	add.2d	v15, v24, v31
	str	q15, [sp, #1136]                ; 16-byte Spill
	add.2d	v15, v24, v8
	str	q15, [sp, #1120]                ; 16-byte Spill
	add.2d	v15, v24, v9
	str	q15, [sp, #1104]                ; 16-byte Spill
	add.2d	v15, v24, v10
	str	q15, [sp, #1088]                ; 16-byte Spill
	add.2d	v15, v24, v11
	str	q15, [sp, #1072]                ; 16-byte Spill
	add.2d	v15, v24, v12
	str	q15, [sp, #1056]                ; 16-byte Spill
	add.2d	v15, v24, v13
	str	q15, [sp, #1040]                ; 16-byte Spill
	add.2d	v3, v24, v14
	ldr	q1, [sp, #5488]                 ; 16-byte Reload
	add.2d	v15, v24, v1
	stp	q15, q3, [sp, #1008]            ; 32-byte Folded Spill
	ldr	q1, [sp, #5456]                 ; 16-byte Reload
	add.2d	v3, v24, v1
	ldr	q1, [sp, #5424]                 ; 16-byte Reload
	add.2d	v15, v24, v1
	stp	q15, q3, [sp, #976]             ; 32-byte Folded Spill
	ldr	q1, [sp, #5392]                 ; 16-byte Reload
	add.2d	v3, v24, v1
	ldr	q1, [sp, #5360]                 ; 16-byte Reload
	add.2d	v15, v24, v1
	stp	q15, q3, [sp, #944]             ; 32-byte Folded Spill
	ldr	q1, [sp, #5328]                 ; 16-byte Reload
	add.2d	v3, v24, v1
	ldr	q15, [sp, #4496]                ; 16-byte Reload
	ldr	q1, [sp, #5504]                 ; 16-byte Reload
	add.2d	v14, v24, v1
	stp	q14, q3, [sp, #912]             ; 32-byte Folded Spill
	ldr	q1, [sp, #5472]                 ; 16-byte Reload
	add.2d	v13, v24, v1
	ldr	q1, [sp, #5440]                 ; 16-byte Reload
	add.2d	v12, v24, v1
	stp	q12, q13, [sp, #880]            ; 32-byte Folded Spill
	ldr	q1, [sp, #5408]                 ; 16-byte Reload
	add.2d	v3, v24, v1
	ldr	q11, [sp, #3680]                ; 16-byte Reload
	ldr	q1, [sp, #5376]                 ; 16-byte Reload
	add.2d	v10, v24, v1
	stp	q10, q3, [sp, #848]             ; 32-byte Folded Spill
	ldr	q1, [sp, #5344]                 ; 16-byte Reload
	add.2d	v9, v24, v1
	ldr	q1, [sp, #5312]                 ; 16-byte Reload
	add.2d	v8, v24, v1
	stp	q8, q9, [sp, #816]              ; 32-byte Folded Spill
	ldr	q1, [sp, #5296]                 ; 16-byte Reload
	add.2d	v31, v24, v1
	ldr	q1, [sp, #5280]                 ; 16-byte Reload
	add.2d	v30, v24, v1
	stp	q30, q31, [sp, #784]            ; 32-byte Folded Spill
	ldr	q1, [sp, #5264]                 ; 16-byte Reload
	add.2d	v29, v24, v1
	ldr	q1, [sp, #5248]                 ; 16-byte Reload
	add.2d	v28, v24, v1
	stp	q28, q29, [sp, #752]            ; 32-byte Folded Spill
	ldr	q1, [sp, #5232]                 ; 16-byte Reload
	add.2d	v27, v24, v1
	ldr	q1, [sp, #5216]                 ; 16-byte Reload
	add.2d	v26, v24, v1
	stp	q26, q27, [sp, #720]            ; 32-byte Folded Spill
	ldr	q1, [sp, #5200]                 ; 16-byte Reload
	add.2d	v25, v24, v1
	ldr	q1, [sp, #5184]                 ; 16-byte Reload
	add.2d	v22, v24, v1
	stp	q22, q25, [sp, #688]            ; 32-byte Folded Spill
	ldr	q22, [sp, #3648]                ; 16-byte Reload
	ldr	q1, [sp, #5168]                 ; 16-byte Reload
	add.2d	v3, v24, v1
	ldr	q21, [sp, #3664]                ; 16-byte Reload
	ldr	q1, [sp, #5152]                 ; 16-byte Reload
	add.2d	v20, v24, v1
	stp	q20, q3, [sp, #656]             ; 32-byte Folded Spill
	ldr	q1, [sp, #5136]                 ; 16-byte Reload
	add.2d	v19, v24, v1
	ldr	q1, [sp, #5120]                 ; 16-byte Reload
	add.2d	v18, v24, v1
	stp	q18, q19, [sp, #624]            ; 32-byte Folded Spill
	ldr	q1, [sp, #5104]                 ; 16-byte Reload
	add.2d	v17, v24, v1
	ldr	q1, [sp, #5088]                 ; 16-byte Reload
	add.2d	v16, v24, v1
	stp	q16, q17, [sp, #592]            ; 32-byte Folded Spill
	ldr	q1, [sp, #5072]                 ; 16-byte Reload
	add.2d	v7, v24, v1
	ldr	q1, [sp, #5056]                 ; 16-byte Reload
	add.2d	v6, v24, v1
	stp	q6, q7, [sp, #560]              ; 32-byte Folded Spill
	ldr	q1, [sp, #5040]                 ; 16-byte Reload
	add.2d	v5, v24, v1
	ldr	q1, [sp, #5024]                 ; 16-byte Reload
	add.2d	v4, v24, v1
	stp	q4, q5, [sp, #528]              ; 32-byte Folded Spill
	ldr	q1, [sp, #5008]                 ; 16-byte Reload
	add.2d	v3, v24, v1
	ldr	q1, [sp, #4992]                 ; 16-byte Reload
	add.2d	v1, v24, v1
	stp	q1, q3, [sp, #496]              ; 32-byte Folded Spill
	add	x30, x8, x10
	add	x23, x9, x11
	mov	w8, #33344                      ; =0x8240
	movk	w8, #1, lsl #16
	add	x8, x24, x8
	str	x8, [sp, #4912]                 ; 8-byte Spill
	mov	w8, #33856                      ; =0x8440
	movk	w8, #1, lsl #16
	add	x8, x24, x8
	str	x8, [sp, #4896]                 ; 8-byte Spill
	add	x26, x12, x1
	mov	w8, #33408                      ; =0x8280
	movk	w8, #1, lsl #16
	add	x8, x24, x8
	str	x8, [sp, #4880]                 ; 8-byte Spill
	mov	w8, #33920                      ; =0x8480
	movk	w8, #1, lsl #16
	add	x8, x24, x8
	str	x8, [sp, #4864]                 ; 8-byte Spill
	add	x8, x13, x0
	mov	w9, #33472                      ; =0x82c0
	movk	w9, #1, lsl #16
	add	x9, x24, x9
	str	x9, [sp, #4848]                 ; 8-byte Spill
	mov	w9, #33984                      ; =0x84c0
	movk	w9, #1, lsl #16
	add	x9, x24, x9
	str	x9, [sp, #4832]                 ; 8-byte Spill
	add	x2, x2, x5
	mov	w9, #33536                      ; =0x8300
	movk	w9, #1, lsl #16
	add	x9, x24, x9
	str	x9, [sp, #4824]                 ; 8-byte Spill
	mov	w9, #34048                      ; =0x8500
	movk	w9, #1, lsl #16
	add	x9, x24, x9
	str	x9, [sp, #4816]                 ; 8-byte Spill
	add	x5, x3, x4
	mov	w9, #33600                      ; =0x8340
	movk	w9, #1, lsl #16
	add	x9, x24, x9
	str	x9, [sp, #4808]                 ; 8-byte Spill
	mov	w9, #34112                      ; =0x8540
	movk	w9, #1, lsl #16
	add	x9, x24, x9
	str	x9, [sp, #4800]                 ; 8-byte Spill
	add	x10, x6, x22
	mov	w9, #33664                      ; =0x8380
	movk	w9, #1, lsl #16
	add	x22, x24, x9
	mov	w9, #34176                      ; =0x8580
	movk	w9, #1, lsl #16
	add	x9, x24, x9
	str	x9, [sp, #4792]                 ; 8-byte Spill
	add	x13, x7, x20
	mov	w9, #33728                      ; =0x83c0
	movk	w9, #1, lsl #16
	add	x9, x24, x9
	str	x9, [sp, #4784]                 ; 8-byte Spill
	mov	w9, #34240                      ; =0x85c0
	movk	w9, #1, lsl #16
	add	x9, x24, x9
	str	x9, [sp, #4776]                 ; 8-byte Spill
	mov	w9, #38784                      ; =0x9780
	movk	w9, #1, lsl #16
	add	x20, x24, x9
	mov	w9, #39168                      ; =0x9900
	movk	w9, #1, lsl #16
	add	x7, x24, x9
	mov	w9, #39552                      ; =0x9a80
	movk	w9, #1, lsl #16
	add	x0, x24, x9
	mov	w9, #39936                      ; =0x9c00
	movk	w9, #1, lsl #16
	add	x11, x24, x9
	mov	w9, #40320                      ; =0x9d80
	movk	w9, #1, lsl #16
	add	x3, x24, x9
	mov	w9, #40704                      ; =0x9f00
	movk	w9, #1, lsl #16
	add	x4, x24, x9
	mov	w9, #41088                      ; =0xa080
	movk	w9, #1, lsl #16
	add	x6, x24, x9
	mov	w9, #34336                      ; =0x8620
	movk	w9, #1, lsl #16
	add	x9, x24, x9
	str	x9, [sp, #472]                  ; 8-byte Spill
	mov	w9, #34368                      ; =0x8640
	movk	w9, #1, lsl #16
	add	x9, x24, x9
	str	x9, [sp, #464]                  ; 8-byte Spill
	mov	w9, #34400                      ; =0x8660
	movk	w9, #1, lsl #16
	add	x9, x24, x9
	str	x9, [sp, #456]                  ; 8-byte Spill
	mov	w9, #34432                      ; =0x8680
	movk	w9, #1, lsl #16
	add	x9, x24, x9
	str	x9, [sp, #448]                  ; 8-byte Spill
	mov	w9, #34464                      ; =0x86a0
	movk	w9, #1, lsl #16
	add	x9, x24, x9
	str	x9, [sp, #440]                  ; 8-byte Spill
	mov	w9, #34496                      ; =0x86c0
	movk	w9, #1, lsl #16
	add	x9, x24, x9
	str	x9, [sp, #432]                  ; 8-byte Spill
	mov	w9, #34528                      ; =0x86e0
	movk	w9, #1, lsl #16
	add	x9, x24, x9
	str	x9, [sp, #424]                  ; 8-byte Spill
	mov	w9, #34560                      ; =0x8700
	movk	w9, #1, lsl #16
	add	x9, x24, x9
	str	x9, [sp, #416]                  ; 8-byte Spill
	mov	w9, #34592                      ; =0x8720
	movk	w9, #1, lsl #16
	add	x9, x24, x9
	str	x9, [sp, #408]                  ; 8-byte Spill
	mov	w9, #34624                      ; =0x8740
	movk	w9, #1, lsl #16
	add	x9, x24, x9
	str	x9, [sp, #400]                  ; 8-byte Spill
	mov	w9, #34656                      ; =0x8760
	movk	w9, #1, lsl #16
	add	x9, x24, x9
	str	x9, [sp, #392]                  ; 8-byte Spill
	mov	w9, #34688                      ; =0x8780
	movk	w9, #1, lsl #16
	add	x9, x24, x9
	str	x9, [sp, #384]                  ; 8-byte Spill
	mov	w9, #34720                      ; =0x87a0
	movk	w9, #1, lsl #16
	add	x9, x24, x9
	str	x9, [sp, #376]                  ; 8-byte Spill
	mov	w9, #34752                      ; =0x87c0
	movk	w9, #1, lsl #16
	add	x9, x24, x9
	str	x9, [sp, #368]                  ; 8-byte Spill
	mov	w9, #34784                      ; =0x87e0
	movk	w9, #1, lsl #16
	add	x9, x24, x9
	str	x9, [sp, #360]                  ; 8-byte Spill
	mov	x24, x11
	mov	w9, #62154                      ; =0xf2ca
	movk	w9, #61769, lsl #16
	dup.4s	v1, w9
	and.16b	v3, v0, v1
	str	q3, [sp, #4752]                 ; 16-byte Spill
	str	q1, [sp, #336]                  ; 16-byte Spill
	and.16b	v1, v2, v1
	str	q1, [sp, #4736]                 ; 16-byte Spill
	ldr	q1, [sp, #3792]                 ; 16-byte Reload
	add.2d	v3, v24, v1
	ldr	q1, [sp, #3776]                 ; 16-byte Reload
	add.2d	v1, v24, v1
	stp	q1, q3, [sp, #304]              ; 32-byte Folded Spill
	ldr	q1, [sp, #3760]                 ; 16-byte Reload
	add.2d	v3, v24, v1
	ldr	q1, [sp, #3744]                 ; 16-byte Reload
	add.2d	v1, v24, v1
	stp	q1, q3, [sp, #272]              ; 32-byte Folded Spill
	ldr	q24, [sp, #3632]                ; 16-byte Reload
	movi.2d	v1, #0000000000000000
	str	q1, [sp, #4512]                 ; 16-byte Spill
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	str	q1, [sp, #5072]                 ; 16-byte Spill
	str	q1, [sp, #5056]                 ; 16-byte Spill
	str	q1, [sp, #5040]                 ; 16-byte Spill
	str	q1, [sp, #5024]                 ; 16-byte Spill
	str	q1, [sp, #4704]                 ; 16-byte Spill
	str	q1, [sp, #4688]                 ; 16-byte Spill
	str	q1, [sp, #4672]                 ; 16-byte Spill
	str	q1, [sp, #5424]                 ; 16-byte Spill
	str	q1, [sp, #5408]                 ; 16-byte Spill
	str	q1, [sp, #5392]                 ; 16-byte Spill
	str	q1, [sp, #5376]                 ; 16-byte Spill
	movi.2d	v25, #0000000000000000
	movi.2d	v5, #0000000000000000
	str	q1, [sp, #4656]                 ; 16-byte Spill
	str	q1, [sp, #4640]                 ; 16-byte Spill
	str	q1, [sp, #4624]                 ; 16-byte Spill
	str	q1, [sp, #4608]                 ; 16-byte Spill
	str	q1, [sp, #5360]                 ; 16-byte Spill
	str	q1, [sp, #5344]                 ; 16-byte Spill
	str	q1, [sp, #4592]                 ; 16-byte Spill
	str	q1, [sp, #4576]                 ; 16-byte Spill
	str	q1, [sp, #5008]                 ; 16-byte Spill
	str	q1, [sp, #4992]                 ; 16-byte Spill
	movi.2d	v10, #0000000000000000
	movi.2d	v12, #0000000000000000
	str	q1, [sp, #5456]                 ; 16-byte Spill
	str	q1, [sp, #4432]                 ; 16-byte Spill
	str	q1, [sp, #5488]                 ; 16-byte Spill
	str	q1, [sp, #5472]                 ; 16-byte Spill
	movi.2d	v14, #0000000000000000
	str	q1, [sp, #5504]                 ; 16-byte Spill
	str	q1, [sp, #5328]                 ; 16-byte Spill
	str	q1, [sp, #5312]                 ; 16-byte Spill
	str	q1, [sp, #5296]                 ; 16-byte Spill
	str	q1, [sp, #5280]                 ; 16-byte Spill
	str	q1, [sp, #5264]                 ; 16-byte Spill
	str	q1, [sp, #5248]                 ; 16-byte Spill
	str	q1, [sp, #5232]                 ; 16-byte Spill
	str	q1, [sp, #5216]                 ; 16-byte Spill
	movi.2d	v13, #0000000000000000
	movi.2d	v31, #0000000000000000
	str	q1, [sp, #4448]                 ; 16-byte Spill
	str	q1, [sp, #5440]                 ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	movi.2d	v9, #0000000000000000
	str	q1, [sp, #5200]                 ; 16-byte Spill
	str	q1, [sp, #5184]                 ; 16-byte Spill
	str	q1, [sp, #5168]                 ; 16-byte Spill
	str	q1, [sp, #5152]                 ; 16-byte Spill
	str	q1, [sp, #5136]                 ; 16-byte Spill
	str	q1, [sp, #5120]                 ; 16-byte Spill
	str	q1, [sp, #5104]                 ; 16-byte Spill
	str	q1, [sp, #5088]                 ; 16-byte Spill
	movi.2d	v28, #0000000000000000
	movi.2d	v20, #0000000000000000
	stp	x3, x22, [sp, #480]             ; 16-byte Folded Spill
	str	x20, [sp, #248]                 ; 8-byte Spill
	str	x4, [sp, #264]                  ; 8-byte Spill
LBB1_50:                                ; %direct.true139.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB1_52 Depth 3
                                        ;       Child Loop BB1_87 Depth 3
                                        ;       Child Loop BB1_378 Depth 3
                                        ;         Child Loop BB1_379 Depth 4
                                        ;       Child Loop BB1_383 Depth 3
                                        ;         Child Loop BB1_384 Depth 4
                                        ;       Child Loop BB1_388 Depth 3
                                        ;         Child Loop BB1_389 Depth 4
                                        ;       Child Loop BB1_393 Depth 3
                                        ;         Child Loop BB1_394 Depth 4
                                        ;       Child Loop BB1_398 Depth 3
                                        ;         Child Loop BB1_399 Depth 4
                                        ;       Child Loop BB1_403 Depth 3
                                        ;         Child Loop BB1_404 Depth 4
                                        ;       Child Loop BB1_408 Depth 3
                                        ;         Child Loop BB1_409 Depth 4
                                        ;       Child Loop BB1_413 Depth 3
                                        ;         Child Loop BB1_414 Depth 4
                                        ;       Child Loop BB1_667 Depth 3
                                        ;       Child Loop BB1_830 Depth 3
                                        ;       Child Loop BB1_848 Depth 3
                                        ;       Child Loop BB1_866 Depth 3
                                        ;       Child Loop BB1_869 Depth 3
                                        ;       Child Loop BB1_872 Depth 3
                                        ;       Child Loop BB1_875 Depth 3
                                        ;       Child Loop BB1_878 Depth 3
                                        ;       Child Loop BB1_881 Depth 3
                                        ;       Child Loop BB1_884 Depth 3
                                        ;       Child Loop BB1_887 Depth 3
                                        ;       Child Loop BB1_890 Depth 3
                                        ;       Child Loop BB1_907 Depth 3
	str	q20, [sp, #4560]                ; 16-byte Spill
	mov	x1, x7
	mov	x11, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	sshll.2d	v4, v2, #0
	sshll.2d	v6, v0, #0
	lsl	x7, x17, #4
	ldr	q1, [sp, #3600]                 ; 16-byte Reload
	ldr	q3, [sp, #5152]                 ; 16-byte Reload
	bit.16b	v3, v1, v15
	str	q3, [sp, #5152]                 ; 16-byte Spill
	ldr	q3, [sp, #5184]                 ; 16-byte Reload
	bit.16b	v3, v1, v11
	str	q3, [sp, #5184]                 ; 16-byte Spill
	ldr	q3, [sp, #5168]                 ; 16-byte Reload
	bit.16b	v3, v1, v6
	str	q3, [sp, #5168]                 ; 16-byte Spill
	ldr	q3, [sp, #5200]                 ; 16-byte Reload
	bit.16b	v3, v1, v4
	str	q3, [sp, #5200]                 ; 16-byte Spill
Lloh304:
	adrp	x9, lCPI1_71@PAGE
Lloh305:
	ldr	q7, [x9, lCPI1_71@PAGEOFF]
	ldr	q1, [sp, #5088]                 ; 16-byte Reload
	bit.16b	v1, v7, v15
	str	q1, [sp, #5088]                 ; 16-byte Spill
Lloh306:
	adrp	x9, lCPI1_72@PAGE
Lloh307:
	ldr	q7, [x9, lCPI1_72@PAGEOFF]
	ldr	q1, [sp, #5120]                 ; 16-byte Reload
	bit.16b	v1, v7, v11
	str	q1, [sp, #5120]                 ; 16-byte Spill
Lloh308:
	adrp	x9, lCPI1_73@PAGE
Lloh309:
	ldr	q7, [x9, lCPI1_73@PAGEOFF]
	ldr	q1, [sp, #5104]                 ; 16-byte Reload
	bit.16b	v1, v7, v6
	str	q1, [sp, #5104]                 ; 16-byte Spill
Lloh310:
	adrp	x9, lCPI1_74@PAGE
Lloh311:
	ldr	q6, [x9, lCPI1_74@PAGEOFF]
	ldr	q1, [sp, #5136]                 ; 16-byte Reload
	bit.16b	v1, v6, v4
	str	q1, [sp, #5136]                 ; 16-byte Spill
	ldr	q3, [sp, #3504]                 ; 16-byte Reload
	ldr	q1, [sp, #4448]                 ; 16-byte Reload
	b	LBB1_52
LBB1_51:                                ; %else409
                                        ;   in Loop: Header=BB1_52 Depth=3
	add	x12, x12, #1
	add	x11, x11, #4
	cmp	x12, #1280
	b.eq	LBB1_85
LBB1_52:                                ; %direct.true143.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	mov	x3, x24
	and	w9, w12, #0xffff
	mul	w9, w9, w27
	lsr	w22, w9, #22
	add	x9, x7, x22
	dup.2d	v4, x9
	add.2d	v6, v4, v21
	add.2d	v7, v4, v22
	add.2d	v16, v4, v24
	mov.d	x24, v16[1]
	fmov	x20, d16
	add	x20, x20, x20, lsl #2
	lsl	x20, x20, #4
	fmov	d16, x20
	add	x20, x24, x24, lsl #2
	lsl	x20, x20, #4
	mov.d	v16[1], x20
	mov.d	x20, v7[1]
	fmov	x24, d7
	add	x24, x24, x24, lsl #2
	lsl	x24, x24, #4
	fmov	d7, x24
	add	x20, x20, x20, lsl #2
	lsl	x20, x20, #4
	mov.d	v7[1], x20
	mov.d	x20, v6[1]
	add.2d	v4, v4, v3
	fmov	x24, d6
	add	x24, x24, x24, lsl #2
	lsl	x24, x24, #4
	fmov	d6, x24
	add	x20, x20, x20, lsl #2
	lsl	x20, x20, #4
	mov.d	v6[1], x20
	mov.d	x20, v4[1]
	fmov	x24, d4
	add	x24, x24, x24, lsl #2
	lsl	x24, x24, #4
	fmov	d4, x24
	sshll.2d	v18, v2, #0
	msub	w22, w22, w25, w12
	and	x22, x22, #0xffff
	add	x20, x20, x20, lsl #2
	lsl	x20, x20, #4
	mov.d	v4[1], x20
	dup.2d	v19, x22
	sshll.2d	v20, v0, #0
	add.2d	v4, v4, v19
	add.2d	v6, v6, v19
	add.2d	v7, v7, v19
	add.2d	v16, v16, v19
	bit.16b	v9, v16, v15
	bit.16b	v17, v7, v20
	ldr	q19, [sp, #5440]                ; 16-byte Reload
	bit.16b	v19, v6, v11
	bit.16b	v1, v4, v18
	movi.2d	v6, #0000000000000000
	movi.2d	v4, #0000000000000000
	cmp	x9, #2053
	b.hs	LBB1_62
; %bb.53:                               ; %direct.true156.i.i
                                        ;   in Loop: Header=BB1_52 Depth=3
	fmov	w9, s23
	shl.2d	v4, v1, #2
	dup.2d	v7, x15
	add.2d	v16, v7, v4
	movi.2d	v4, #0000000000000000
	tbnz	w9, #0, LBB1_78
; %bb.54:                               ; %else512
                                        ;   in Loop: Header=BB1_52 Depth=3
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_79
LBB1_55:                                ; %else518
                                        ;   in Loop: Header=BB1_52 Depth=3
	shl.2d	v16, v19, #2
	add.2d	v16, v7, v16
	tbnz	w9, #2, LBB1_80
LBB1_56:                                ; %else524
                                        ;   in Loop: Header=BB1_52 Depth=3
	tbnz	w9, #3, LBB1_81
LBB1_57:                                ; %else530
                                        ;   in Loop: Header=BB1_52 Depth=3
	shl.2d	v16, v17, #2
	add.2d	v16, v7, v16
	tbnz	w9, #4, LBB1_82
LBB1_58:                                ; %else536
                                        ;   in Loop: Header=BB1_52 Depth=3
	tbnz	w9, #5, LBB1_83
LBB1_59:                                ; %else542
                                        ;   in Loop: Header=BB1_52 Depth=3
	shl.2d	v16, v9, #2
	add.2d	v7, v7, v16
	tbnz	w9, #6, LBB1_84
LBB1_60:                                ; %else548
                                        ;   in Loop: Header=BB1_52 Depth=3
	tbz	w9, #7, LBB1_62
LBB1_61:                                ; %cond.load550
                                        ;   in Loop: Header=BB1_52 Depth=3
	mov.d	x9, v7[1]
	ld1.s	{ v4 }[3], [x9]
LBB1_62:                                ; %direct.schedule.12.i.i
                                        ;   in Loop: Header=BB1_52 Depth=3
	fmov	w9, s23
	bit.16b	v13, v6, v2
	dup.2d	v6, x11
	ldr	q7, [sp, #5200]                 ; 16-byte Reload
	ldr	q16, [sp, #5136]                ; 16-byte Reload
	add.2d	v7, v7, v16
	add.2d	v7, v7, v6
	tbnz	w9, #0, LBB1_70
; %bb.63:                               ; %else
                                        ;   in Loop: Header=BB1_52 Depth=3
	and	w9, w9, #0xff
	mov	x24, x3
	tbnz	w9, #1, LBB1_71
LBB1_64:                                ; %else397
                                        ;   in Loop: Header=BB1_52 Depth=3
	ldr	q7, [sp, #5184]                 ; 16-byte Reload
	ldr	q16, [sp, #5120]                ; 16-byte Reload
	add.2d	v7, v7, v16
	add.2d	v7, v7, v6
	tbnz	w9, #2, LBB1_72
LBB1_65:                                ; %else399
                                        ;   in Loop: Header=BB1_52 Depth=3
	tbnz	w9, #3, LBB1_73
LBB1_66:                                ; %else401
                                        ;   in Loop: Header=BB1_52 Depth=3
	bit.16b	v31, v4, v0
	ldr	q4, [sp, #5168]                 ; 16-byte Reload
	ldr	q7, [sp, #5104]                 ; 16-byte Reload
	add.2d	v4, v4, v7
	add.2d	v4, v4, v6
	tbnz	w9, #4, LBB1_74
LBB1_67:                                ; %else403
                                        ;   in Loop: Header=BB1_52 Depth=3
	tbnz	w9, #5, LBB1_75
LBB1_68:                                ; %else405
                                        ;   in Loop: Header=BB1_52 Depth=3
	ldr	q4, [sp, #5152]                 ; 16-byte Reload
	ldr	q7, [sp, #5088]                 ; 16-byte Reload
	add.2d	v4, v4, v7
	add.2d	v4, v4, v6
	tbnz	w9, #6, LBB1_76
LBB1_69:                                ; %else407
                                        ;   in Loop: Header=BB1_52 Depth=3
	str	q19, [sp, #5440]                ; 16-byte Spill
	tbz	w9, #7, LBB1_51
	b	LBB1_77
LBB1_70:                                ; %cond.store
                                        ;   in Loop: Header=BB1_52 Depth=3
	fmov	x22, d7
	str	s13, [x22]
	and	w9, w9, #0xff
	mov	x24, x3
	tbz	w9, #1, LBB1_64
LBB1_71:                                ; %cond.store396
                                        ;   in Loop: Header=BB1_52 Depth=3
	mov.d	x22, v7[1]
	st1.s	{ v13 }[1], [x22]
	ldr	q7, [sp, #5184]                 ; 16-byte Reload
	ldr	q16, [sp, #5120]                ; 16-byte Reload
	add.2d	v7, v7, v16
	add.2d	v7, v7, v6
	tbz	w9, #2, LBB1_65
LBB1_72:                                ; %cond.store398
                                        ;   in Loop: Header=BB1_52 Depth=3
	fmov	x22, d7
	st1.s	{ v13 }[2], [x22]
	tbz	w9, #3, LBB1_66
LBB1_73:                                ; %cond.store400
                                        ;   in Loop: Header=BB1_52 Depth=3
	mov.d	x22, v7[1]
	st1.s	{ v13 }[3], [x22]
	bit.16b	v31, v4, v0
	ldr	q4, [sp, #5168]                 ; 16-byte Reload
	ldr	q7, [sp, #5104]                 ; 16-byte Reload
	add.2d	v4, v4, v7
	add.2d	v4, v4, v6
	tbz	w9, #4, LBB1_67
LBB1_74:                                ; %cond.store402
                                        ;   in Loop: Header=BB1_52 Depth=3
	fmov	x22, d4
	str	s31, [x22]
	tbz	w9, #5, LBB1_68
LBB1_75:                                ; %cond.store404
                                        ;   in Loop: Header=BB1_52 Depth=3
	mov.d	x22, v4[1]
	st1.s	{ v31 }[1], [x22]
	ldr	q4, [sp, #5152]                 ; 16-byte Reload
	ldr	q7, [sp, #5088]                 ; 16-byte Reload
	add.2d	v4, v4, v7
	add.2d	v4, v4, v6
	tbz	w9, #6, LBB1_69
LBB1_76:                                ; %cond.store406
                                        ;   in Loop: Header=BB1_52 Depth=3
	fmov	x22, d4
	st1.s	{ v31 }[2], [x22]
	str	q19, [sp, #5440]                ; 16-byte Spill
	tbz	w9, #7, LBB1_51
LBB1_77:                                ; %cond.store408
                                        ;   in Loop: Header=BB1_52 Depth=3
	mov.d	x9, v4[1]
	st1.s	{ v31 }[3], [x9]
	b	LBB1_51
LBB1_78:                                ; %cond.load508
                                        ;   in Loop: Header=BB1_52 Depth=3
	fmov	x20, d16
	ldr	s6, [x20]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_55
LBB1_79:                                ; %cond.load514
                                        ;   in Loop: Header=BB1_52 Depth=3
	mov.d	x20, v16[1]
	ld1.s	{ v6 }[1], [x20]
	shl.2d	v16, v19, #2
	add.2d	v16, v7, v16
	tbz	w9, #2, LBB1_56
LBB1_80:                                ; %cond.load520
                                        ;   in Loop: Header=BB1_52 Depth=3
	fmov	x20, d16
	ld1.s	{ v6 }[2], [x20]
	tbz	w9, #3, LBB1_57
LBB1_81:                                ; %cond.load526
                                        ;   in Loop: Header=BB1_52 Depth=3
	mov.d	x20, v16[1]
	ld1.s	{ v6 }[3], [x20]
	shl.2d	v16, v17, #2
	add.2d	v16, v7, v16
	tbz	w9, #4, LBB1_58
LBB1_82:                                ; %cond.load532
                                        ;   in Loop: Header=BB1_52 Depth=3
	fmov	x20, d16
	ld1.s	{ v4 }[0], [x20]
	tbz	w9, #5, LBB1_59
LBB1_83:                                ; %cond.load538
                                        ;   in Loop: Header=BB1_52 Depth=3
	mov.d	x20, v16[1]
	ld1.s	{ v4 }[1], [x20]
	shl.2d	v16, v9, #2
	add.2d	v7, v7, v16
	tbz	w9, #6, LBB1_60
LBB1_84:                                ; %cond.load544
                                        ;   in Loop: Header=BB1_52 Depth=3
	fmov	x20, d7
	ld1.s	{ v4 }[2], [x20]
	tbnz	w9, #7, LBB1_61
	b	LBB1_62
LBB1_85:                                ; %direct.false144.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	str	q9, [sp, #4320]                 ; 16-byte Spill
	str	q1, [sp, #4448]                 ; 16-byte Spill
	mov	x11, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	sshll.2d	v4, v2, #0
	sshll.2d	v6, v0, #0
	ldr	q1, [sp, #3584]                 ; 16-byte Reload
	ldr	q7, [sp, #5280]                 ; 16-byte Reload
	bit.16b	v7, v1, v15
	str	q7, [sp, #5280]                 ; 16-byte Spill
	ldr	q7, [sp, #5312]                 ; 16-byte Reload
	bit.16b	v7, v1, v11
	str	q7, [sp, #5312]                 ; 16-byte Spill
	ldr	q7, [sp, #5296]                 ; 16-byte Reload
	bit.16b	v7, v1, v6
	str	q7, [sp, #5296]                 ; 16-byte Spill
	ldr	q7, [sp, #5328]                 ; 16-byte Reload
	bit.16b	v7, v1, v4
	str	q7, [sp, #5328]                 ; 16-byte Spill
Lloh312:
	adrp	x9, lCPI1_75@PAGE
Lloh313:
	ldr	q7, [x9, lCPI1_75@PAGEOFF]
	ldr	q1, [sp, #5216]                 ; 16-byte Reload
	bit.16b	v1, v7, v15
	str	q1, [sp, #5216]                 ; 16-byte Spill
Lloh314:
	adrp	x9, lCPI1_76@PAGE
Lloh315:
	ldr	q7, [x9, lCPI1_76@PAGEOFF]
	ldr	q1, [sp, #5248]                 ; 16-byte Reload
	bit.16b	v1, v7, v11
	str	q1, [sp, #5248]                 ; 16-byte Spill
Lloh316:
	adrp	x9, lCPI1_77@PAGE
Lloh317:
	ldr	q7, [x9, lCPI1_77@PAGEOFF]
	ldr	q1, [sp, #5232]                 ; 16-byte Reload
	bit.16b	v1, v7, v6
	str	q1, [sp, #5232]                 ; 16-byte Spill
Lloh318:
	adrp	x9, lCPI1_78@PAGE
Lloh319:
	ldr	q6, [x9, lCPI1_78@PAGEOFF]
	ldr	q1, [sp, #5264]                 ; 16-byte Reload
	bit.16b	v1, v6, v4
	str	q1, [sp, #5264]                 ; 16-byte Spill
	ldr	q20, [sp, #4432]                ; 16-byte Reload
	b	LBB1_87
LBB1_86:                                ; %else442
                                        ;   in Loop: Header=BB1_87 Depth=3
	add	x12, x12, #1
	add	x11, x11, #4
	cmp	x12, #1536
	b.eq	LBB1_120
LBB1_87:                                ; %direct.true166.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	mov.16b	v9, v20
	and	w9, w12, #0xffff
	mul	w9, w9, w28
	lsr	w22, w9, #22
	add	x9, x7, x22
	dup.2d	v4, x9
	add.2d	v6, v4, v21
	add.2d	v7, v4, v22
	add.2d	v16, v4, v24
	mov.d	x20, v16[1]
	fmov	x24, d16
	add	x24, x24, x24, lsl #1
	lsl	x24, x24, #5
	fmov	d16, x24
	add	x20, x20, x20, lsl #1
	lsl	x20, x20, #5
	mov.d	v16[1], x20
	mov.d	x20, v7[1]
	fmov	x24, d7
	add	x24, x24, x24, lsl #1
	lsl	x24, x24, #5
	fmov	d7, x24
	add	x20, x20, x20, lsl #1
	lsl	x20, x20, #5
	mov.d	v7[1], x20
	mov.d	x20, v6[1]
	add.2d	v4, v4, v3
	fmov	x24, d6
	add	x24, x24, x24, lsl #1
	lsl	x24, x24, #5
	fmov	d6, x24
	add	x20, x20, x20, lsl #1
	lsl	x20, x20, #5
	mov.d	v6[1], x20
	mov.d	x20, v4[1]
	fmov	x24, d4
	add	x24, x24, x24, lsl #1
	lsl	x24, x24, #5
	fmov	d4, x24
	sshll.2d	v18, v2, #0
	msub	w22, w22, w21, w12
	and	x22, x22, #0xffff
	add	x20, x20, x20, lsl #1
	lsl	x20, x20, #5
	mov.d	v4[1], x20
	dup.2d	v19, x22
	sshll.2d	v20, v0, #0
	add.2d	v4, v4, v19
	add.2d	v6, v6, v19
	add.2d	v7, v7, v19
	add.2d	v16, v16, v19
	ldr	q1, [sp, #5504]                 ; 16-byte Reload
	bit.16b	v1, v16, v15
	str	q1, [sp, #5504]                 ; 16-byte Spill
	bit.16b	v14, v7, v20
	ldr	q19, [sp, #5472]                ; 16-byte Reload
	bit.16b	v19, v6, v11
	ldr	q1, [sp, #5488]                 ; 16-byte Reload
	bit.16b	v1, v4, v18
	movi.2d	v6, #0000000000000000
	movi.2d	v4, #0000000000000000
	cmp	x9, #2053
	b.hs	LBB1_97
; %bb.88:                               ; %direct.true179.i.i
                                        ;   in Loop: Header=BB1_87 Depth=3
	fmov	w9, s23
	shl.2d	v4, v1, #2
	dup.2d	v7, x16
	add.2d	v16, v7, v4
	movi.2d	v4, #0000000000000000
	tbnz	w9, #0, LBB1_113
; %bb.89:                               ; %else961
                                        ;   in Loop: Header=BB1_87 Depth=3
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_114
LBB1_90:                                ; %else967
                                        ;   in Loop: Header=BB1_87 Depth=3
	shl.2d	v16, v19, #2
	add.2d	v16, v7, v16
	tbnz	w9, #2, LBB1_115
LBB1_91:                                ; %else973
                                        ;   in Loop: Header=BB1_87 Depth=3
	tbnz	w9, #3, LBB1_116
LBB1_92:                                ; %else979
                                        ;   in Loop: Header=BB1_87 Depth=3
	shl.2d	v16, v14, #2
	add.2d	v16, v7, v16
	tbnz	w9, #4, LBB1_117
LBB1_93:                                ; %else985
                                        ;   in Loop: Header=BB1_87 Depth=3
	tbnz	w9, #5, LBB1_118
LBB1_94:                                ; %else991
                                        ;   in Loop: Header=BB1_87 Depth=3
	ldr	q16, [sp, #5504]                ; 16-byte Reload
	shl.2d	v16, v16, #2
	add.2d	v7, v7, v16
	tbnz	w9, #6, LBB1_119
LBB1_95:                                ; %else997
                                        ;   in Loop: Header=BB1_87 Depth=3
	tbz	w9, #7, LBB1_97
LBB1_96:                                ; %cond.load999
                                        ;   in Loop: Header=BB1_87 Depth=3
	mov.d	x9, v7[1]
	ld1.s	{ v4 }[3], [x9]
LBB1_97:                                ; %direct.schedule.17.i.i
                                        ;   in Loop: Header=BB1_87 Depth=3
	fmov	w9, s23
	ldr	q16, [sp, #5456]                ; 16-byte Reload
	bit.16b	v16, v6, v2
	dup.2d	v6, x11
	ldr	q7, [sp, #5328]                 ; 16-byte Reload
	ldr	q18, [sp, #5264]                ; 16-byte Reload
	add.2d	v7, v7, v18
	add.2d	v7, v7, v6
	tbnz	w9, #0, LBB1_105
; %bb.98:                               ; %else414
                                        ;   in Loop: Header=BB1_87 Depth=3
	and	w9, w9, #0xff
	mov.16b	v20, v9
	tbnz	w9, #1, LBB1_106
LBB1_99:                                ; %else418
                                        ;   in Loop: Header=BB1_87 Depth=3
	ldr	q7, [sp, #5312]                 ; 16-byte Reload
	ldr	q18, [sp, #5248]                ; 16-byte Reload
	add.2d	v7, v7, v18
	add.2d	v7, v7, v6
	tbnz	w9, #2, LBB1_107
LBB1_100:                               ; %else422
                                        ;   in Loop: Header=BB1_87 Depth=3
	tbnz	w9, #3, LBB1_108
LBB1_101:                               ; %else426
                                        ;   in Loop: Header=BB1_87 Depth=3
	bit.16b	v20, v4, v0
	ldr	q4, [sp, #5296]                 ; 16-byte Reload
	ldr	q7, [sp, #5232]                 ; 16-byte Reload
	add.2d	v4, v4, v7
	add.2d	v4, v4, v6
	tbnz	w9, #4, LBB1_109
LBB1_102:                               ; %else430
                                        ;   in Loop: Header=BB1_87 Depth=3
	tbnz	w9, #5, LBB1_110
LBB1_103:                               ; %else434
                                        ;   in Loop: Header=BB1_87 Depth=3
	ldr	q4, [sp, #5280]                 ; 16-byte Reload
	ldr	q7, [sp, #5216]                 ; 16-byte Reload
	add.2d	v4, v4, v7
	add.2d	v4, v4, v6
	tbnz	w9, #6, LBB1_111
LBB1_104:                               ; %else438
                                        ;   in Loop: Header=BB1_87 Depth=3
	str	q16, [sp, #5456]                ; 16-byte Spill
	str	q19, [sp, #5472]                ; 16-byte Spill
	str	q1, [sp, #5488]                 ; 16-byte Spill
	tbz	w9, #7, LBB1_86
	b	LBB1_112
LBB1_105:                               ; %cond.store411
                                        ;   in Loop: Header=BB1_87 Depth=3
	fmov	x22, d7
	str	s16, [x22]
	and	w9, w9, #0xff
	mov.16b	v20, v9
	tbz	w9, #1, LBB1_99
LBB1_106:                               ; %cond.store415
                                        ;   in Loop: Header=BB1_87 Depth=3
	mov.d	x22, v7[1]
	st1.s	{ v16 }[1], [x22]
	ldr	q7, [sp, #5312]                 ; 16-byte Reload
	ldr	q18, [sp, #5248]                ; 16-byte Reload
	add.2d	v7, v7, v18
	add.2d	v7, v7, v6
	tbz	w9, #2, LBB1_100
LBB1_107:                               ; %cond.store419
                                        ;   in Loop: Header=BB1_87 Depth=3
	fmov	x22, d7
	st1.s	{ v16 }[2], [x22]
	tbz	w9, #3, LBB1_101
LBB1_108:                               ; %cond.store423
                                        ;   in Loop: Header=BB1_87 Depth=3
	mov.d	x22, v7[1]
	st1.s	{ v16 }[3], [x22]
	bit.16b	v20, v4, v0
	ldr	q4, [sp, #5296]                 ; 16-byte Reload
	ldr	q7, [sp, #5232]                 ; 16-byte Reload
	add.2d	v4, v4, v7
	add.2d	v4, v4, v6
	tbz	w9, #4, LBB1_102
LBB1_109:                               ; %cond.store427
                                        ;   in Loop: Header=BB1_87 Depth=3
	fmov	x22, d4
	str	s20, [x22]
	tbz	w9, #5, LBB1_103
LBB1_110:                               ; %cond.store431
                                        ;   in Loop: Header=BB1_87 Depth=3
	mov.d	x22, v4[1]
	st1.s	{ v20 }[1], [x22]
	ldr	q4, [sp, #5280]                 ; 16-byte Reload
	ldr	q7, [sp, #5216]                 ; 16-byte Reload
	add.2d	v4, v4, v7
	add.2d	v4, v4, v6
	tbz	w9, #6, LBB1_104
LBB1_111:                               ; %cond.store435
                                        ;   in Loop: Header=BB1_87 Depth=3
	fmov	x22, d4
	st1.s	{ v20 }[2], [x22]
	str	q16, [sp, #5456]                ; 16-byte Spill
	str	q19, [sp, #5472]                ; 16-byte Spill
	str	q1, [sp, #5488]                 ; 16-byte Spill
	tbz	w9, #7, LBB1_86
LBB1_112:                               ; %cond.store439
                                        ;   in Loop: Header=BB1_87 Depth=3
	mov.d	x9, v4[1]
	st1.s	{ v20 }[3], [x9]
	b	LBB1_86
LBB1_113:                               ; %cond.load957
                                        ;   in Loop: Header=BB1_87 Depth=3
	fmov	x20, d16
	ldr	s6, [x20]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_90
LBB1_114:                               ; %cond.load963
                                        ;   in Loop: Header=BB1_87 Depth=3
	mov.d	x20, v16[1]
	ld1.s	{ v6 }[1], [x20]
	shl.2d	v16, v19, #2
	add.2d	v16, v7, v16
	tbz	w9, #2, LBB1_91
LBB1_115:                               ; %cond.load969
                                        ;   in Loop: Header=BB1_87 Depth=3
	fmov	x20, d16
	ld1.s	{ v6 }[2], [x20]
	tbz	w9, #3, LBB1_92
LBB1_116:                               ; %cond.load975
                                        ;   in Loop: Header=BB1_87 Depth=3
	mov.d	x20, v16[1]
	ld1.s	{ v6 }[3], [x20]
	shl.2d	v16, v14, #2
	add.2d	v16, v7, v16
	tbz	w9, #4, LBB1_93
LBB1_117:                               ; %cond.load981
                                        ;   in Loop: Header=BB1_87 Depth=3
	fmov	x20, d16
	ld1.s	{ v4 }[0], [x20]
	tbz	w9, #5, LBB1_94
LBB1_118:                               ; %cond.load987
                                        ;   in Loop: Header=BB1_87 Depth=3
	mov.d	x20, v16[1]
	ld1.s	{ v4 }[1], [x20]
	ldr	q16, [sp, #5504]                ; 16-byte Reload
	shl.2d	v16, v16, #2
	add.2d	v7, v7, v16
	tbz	w9, #6, LBB1_95
LBB1_119:                               ; %cond.load993
                                        ;   in Loop: Header=BB1_87 Depth=3
	fmov	x20, d7
	ld1.s	{ v4 }[2], [x20]
	tbnz	w9, #7, LBB1_96
	b	LBB1_97
LBB1_120:                               ; %direct.false167.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	tbnz	w9, #0, LBB1_249
; %bb.121:                              ; %else559
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_250
LBB1_122:                               ; %else562
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	x4, [sp, #3720]                 ; 8-byte Reload
	tbnz	w9, #2, LBB1_251
LBB1_123:                               ; %else565
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	x20, [sp, #488]                 ; 8-byte Reload
	tbnz	w9, #3, LBB1_252
LBB1_124:                               ; %else568
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_253
LBB1_125:                               ; %else571
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_254
LBB1_126:                               ; %else574
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_255
LBB1_127:                               ; %else577
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #7, LBB1_256
LBB1_128:                               ; %else580
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	tbnz	w9, #0, LBB1_257
LBB1_129:                               ; %else584
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_258
LBB1_130:                               ; %else587
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_259
LBB1_131:                               ; %else590
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_260
LBB1_132:                               ; %else593
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_261
LBB1_133:                               ; %else596
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_262
LBB1_134:                               ; %else599
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_263
LBB1_135:                               ; %else602
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #7, LBB1_264
LBB1_136:                               ; %else605
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	tbnz	w9, #0, LBB1_265
LBB1_137:                               ; %else609
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_266
LBB1_138:                               ; %else612
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_267
LBB1_139:                               ; %else615
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_268
LBB1_140:                               ; %else618
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_269
LBB1_141:                               ; %else621
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_270
LBB1_142:                               ; %else624
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_271
LBB1_143:                               ; %else627
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #7, LBB1_272
LBB1_144:                               ; %else630
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	tbnz	w9, #0, LBB1_273
LBB1_145:                               ; %else634
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_274
LBB1_146:                               ; %else637
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_275
LBB1_147:                               ; %else640
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_276
LBB1_148:                               ; %else643
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_277
LBB1_149:                               ; %else646
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_278
LBB1_150:                               ; %else649
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_279
LBB1_151:                               ; %else652
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #7, LBB1_280
LBB1_152:                               ; %else655
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	tbnz	w9, #0, LBB1_281
LBB1_153:                               ; %else659
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_282
LBB1_154:                               ; %else662
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_283
LBB1_155:                               ; %else665
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_284
LBB1_156:                               ; %else668
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_285
LBB1_157:                               ; %else671
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_286
LBB1_158:                               ; %else674
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_287
LBB1_159:                               ; %else677
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #7, LBB1_288
LBB1_160:                               ; %else680
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	tbnz	w9, #0, LBB1_289
LBB1_161:                               ; %else684
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_290
LBB1_162:                               ; %else687
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_291
LBB1_163:                               ; %else690
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_292
LBB1_164:                               ; %else693
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_293
LBB1_165:                               ; %else696
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_294
LBB1_166:                               ; %else699
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_295
LBB1_167:                               ; %else702
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #7, LBB1_296
LBB1_168:                               ; %else705
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	tbnz	w9, #0, LBB1_297
LBB1_169:                               ; %else709
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_298
LBB1_170:                               ; %else712
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_299
LBB1_171:                               ; %else715
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_300
LBB1_172:                               ; %else718
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_301
LBB1_173:                               ; %else721
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_302
LBB1_174:                               ; %else724
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_303
LBB1_175:                               ; %else727
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #7, LBB1_304
LBB1_176:                               ; %else730
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	tbnz	w9, #0, LBB1_305
LBB1_177:                               ; %else734
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_306
LBB1_178:                               ; %else737
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_307
LBB1_179:                               ; %else740
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_308
LBB1_180:                               ; %else743
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_309
LBB1_181:                               ; %else746
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_310
LBB1_182:                               ; %else749
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_311
LBB1_183:                               ; %else752
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #7, LBB1_312
LBB1_184:                               ; %else755
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	tbnz	w9, #0, LBB1_313
LBB1_185:                               ; %else759
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_314
LBB1_186:                               ; %else762
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_315
LBB1_187:                               ; %else765
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_316
LBB1_188:                               ; %else768
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_317
LBB1_189:                               ; %else771
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_318
LBB1_190:                               ; %else774
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_319
LBB1_191:                               ; %else777
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #7, LBB1_320
LBB1_192:                               ; %else780
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	tbnz	w9, #0, LBB1_321
LBB1_193:                               ; %else784
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_322
LBB1_194:                               ; %else787
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_323
LBB1_195:                               ; %else790
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_324
LBB1_196:                               ; %else793
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_325
LBB1_197:                               ; %else796
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_326
LBB1_198:                               ; %else799
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_327
LBB1_199:                               ; %else802
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #7, LBB1_328
LBB1_200:                               ; %else805
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	tbnz	w9, #0, LBB1_329
LBB1_201:                               ; %else809
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_330
LBB1_202:                               ; %else812
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_331
LBB1_203:                               ; %else815
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_332
LBB1_204:                               ; %else818
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_333
LBB1_205:                               ; %else821
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_334
LBB1_206:                               ; %else824
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_335
LBB1_207:                               ; %else827
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #7, LBB1_336
LBB1_208:                               ; %else830
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	tbnz	w9, #0, LBB1_337
LBB1_209:                               ; %else834
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_338
LBB1_210:                               ; %else837
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_339
LBB1_211:                               ; %else840
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_340
LBB1_212:                               ; %else843
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_341
LBB1_213:                               ; %else846
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_342
LBB1_214:                               ; %else849
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_343
LBB1_215:                               ; %else852
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #7, LBB1_344
LBB1_216:                               ; %else855
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	tbnz	w9, #0, LBB1_345
LBB1_217:                               ; %else859
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_346
LBB1_218:                               ; %else862
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_347
LBB1_219:                               ; %else865
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_348
LBB1_220:                               ; %else868
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_349
LBB1_221:                               ; %else871
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_350
LBB1_222:                               ; %else874
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_351
LBB1_223:                               ; %else877
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #7, LBB1_352
LBB1_224:                               ; %else880
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	tbnz	w9, #0, LBB1_353
LBB1_225:                               ; %else884
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_354
LBB1_226:                               ; %else887
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_355
LBB1_227:                               ; %else890
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_356
LBB1_228:                               ; %else893
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_357
LBB1_229:                               ; %else896
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_358
LBB1_230:                               ; %else899
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_359
LBB1_231:                               ; %else902
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #7, LBB1_360
LBB1_232:                               ; %else905
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	tbnz	w9, #0, LBB1_361
LBB1_233:                               ; %else909
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_362
LBB1_234:                               ; %else912
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_363
LBB1_235:                               ; %else915
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_364
LBB1_236:                               ; %else918
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_365
LBB1_237:                               ; %else921
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_366
LBB1_238:                               ; %else924
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_367
LBB1_239:                               ; %else927
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #7, LBB1_368
LBB1_240:                               ; %else930
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	tbnz	w9, #0, LBB1_369
LBB1_241:                               ; %else934
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_370
LBB1_242:                               ; %else937
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_371
LBB1_243:                               ; %else940
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_372
LBB1_244:                               ; %else943
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_373
LBB1_245:                               ; %else946
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_374
LBB1_246:                               ; %else949
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_375
LBB1_247:                               ; %else952
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #7, LBB1_376
LBB1_248:                               ; %else955
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	w9, [sp, #4492]                 ; 4-byte Reload
	tbnz	w9, #0, LBB1_377
	b	LBB1_381
LBB1_249:                               ; %cond.store557
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3440]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_122
LBB1_250:                               ; %cond.store560
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3440]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	ldr	x4, [sp, #3720]                 ; 8-byte Reload
	tbz	w9, #2, LBB1_123
LBB1_251:                               ; %cond.store563
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3456]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	ldr	x20, [sp, #488]                 ; 8-byte Reload
	tbz	w9, #3, LBB1_124
LBB1_252:                               ; %cond.store566
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3456]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #4, LBB1_125
LBB1_253:                               ; %cond.store569
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3472]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #5, LBB1_126
LBB1_254:                               ; %cond.store572
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3472]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #6, LBB1_127
LBB1_255:                               ; %cond.store575
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3488]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #7, LBB1_128
LBB1_256:                               ; %cond.store578
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3488]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	str	wzr, [x9]
	fmov	w9, s23
	tbz	w9, #0, LBB1_129
LBB1_257:                               ; %cond.store582
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3376]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_130
LBB1_258:                               ; %cond.store585
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3376]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #2, LBB1_131
LBB1_259:                               ; %cond.store588
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3392]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #3, LBB1_132
LBB1_260:                               ; %cond.store591
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3392]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #4, LBB1_133
LBB1_261:                               ; %cond.store594
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3408]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #5, LBB1_134
LBB1_262:                               ; %cond.store597
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3408]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #6, LBB1_135
LBB1_263:                               ; %cond.store600
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3424]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #7, LBB1_136
LBB1_264:                               ; %cond.store603
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3424]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	str	wzr, [x9]
	fmov	w9, s23
	tbz	w9, #0, LBB1_137
LBB1_265:                               ; %cond.store607
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3312]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_138
LBB1_266:                               ; %cond.store610
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3312]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #2, LBB1_139
LBB1_267:                               ; %cond.store613
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3328]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #3, LBB1_140
LBB1_268:                               ; %cond.store616
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3328]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #4, LBB1_141
LBB1_269:                               ; %cond.store619
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3344]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #5, LBB1_142
LBB1_270:                               ; %cond.store622
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3344]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #6, LBB1_143
LBB1_271:                               ; %cond.store625
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3360]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #7, LBB1_144
LBB1_272:                               ; %cond.store628
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3360]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	str	wzr, [x9]
	fmov	w9, s23
	tbz	w9, #0, LBB1_145
LBB1_273:                               ; %cond.store632
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3248]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_146
LBB1_274:                               ; %cond.store635
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3248]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #2, LBB1_147
LBB1_275:                               ; %cond.store638
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3264]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #3, LBB1_148
LBB1_276:                               ; %cond.store641
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3264]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #4, LBB1_149
LBB1_277:                               ; %cond.store644
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3280]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #5, LBB1_150
LBB1_278:                               ; %cond.store647
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3280]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #6, LBB1_151
LBB1_279:                               ; %cond.store650
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3296]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #7, LBB1_152
LBB1_280:                               ; %cond.store653
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3296]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	str	wzr, [x9]
	fmov	w9, s23
	tbz	w9, #0, LBB1_153
LBB1_281:                               ; %cond.store657
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3184]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_154
LBB1_282:                               ; %cond.store660
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3184]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #2, LBB1_155
LBB1_283:                               ; %cond.store663
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3200]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #3, LBB1_156
LBB1_284:                               ; %cond.store666
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3200]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #4, LBB1_157
LBB1_285:                               ; %cond.store669
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3216]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #5, LBB1_158
LBB1_286:                               ; %cond.store672
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3216]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #6, LBB1_159
LBB1_287:                               ; %cond.store675
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3232]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #7, LBB1_160
LBB1_288:                               ; %cond.store678
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3232]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	str	wzr, [x9]
	fmov	w9, s23
	tbz	w9, #0, LBB1_161
LBB1_289:                               ; %cond.store682
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3120]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_162
LBB1_290:                               ; %cond.store685
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3120]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #2, LBB1_163
LBB1_291:                               ; %cond.store688
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3136]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #3, LBB1_164
LBB1_292:                               ; %cond.store691
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3136]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #4, LBB1_165
LBB1_293:                               ; %cond.store694
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3152]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #5, LBB1_166
LBB1_294:                               ; %cond.store697
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3152]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #6, LBB1_167
LBB1_295:                               ; %cond.store700
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3168]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #7, LBB1_168
LBB1_296:                               ; %cond.store703
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3168]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	str	wzr, [x9]
	fmov	w9, s23
	tbz	w9, #0, LBB1_169
LBB1_297:                               ; %cond.store707
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3056]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_170
LBB1_298:                               ; %cond.store710
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3056]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #2, LBB1_171
LBB1_299:                               ; %cond.store713
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3072]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #3, LBB1_172
LBB1_300:                               ; %cond.store716
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3072]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #4, LBB1_173
LBB1_301:                               ; %cond.store719
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3088]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #5, LBB1_174
LBB1_302:                               ; %cond.store722
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3088]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #6, LBB1_175
LBB1_303:                               ; %cond.store725
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3104]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #7, LBB1_176
LBB1_304:                               ; %cond.store728
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3104]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	str	wzr, [x9]
	fmov	w9, s23
	tbz	w9, #0, LBB1_177
LBB1_305:                               ; %cond.store732
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2992]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_178
LBB1_306:                               ; %cond.store735
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2992]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #2, LBB1_179
LBB1_307:                               ; %cond.store738
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3008]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #3, LBB1_180
LBB1_308:                               ; %cond.store741
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3008]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #4, LBB1_181
LBB1_309:                               ; %cond.store744
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3024]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #5, LBB1_182
LBB1_310:                               ; %cond.store747
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3024]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #6, LBB1_183
LBB1_311:                               ; %cond.store750
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3040]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #7, LBB1_184
LBB1_312:                               ; %cond.store753
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3040]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	str	wzr, [x9]
	fmov	w9, s23
	tbz	w9, #0, LBB1_185
LBB1_313:                               ; %cond.store757
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2928]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_186
LBB1_314:                               ; %cond.store760
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2928]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #2, LBB1_187
LBB1_315:                               ; %cond.store763
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2944]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #3, LBB1_188
LBB1_316:                               ; %cond.store766
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2944]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #4, LBB1_189
LBB1_317:                               ; %cond.store769
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2960]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #5, LBB1_190
LBB1_318:                               ; %cond.store772
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2960]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #6, LBB1_191
LBB1_319:                               ; %cond.store775
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2976]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #7, LBB1_192
LBB1_320:                               ; %cond.store778
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2976]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	str	wzr, [x9]
	fmov	w9, s23
	tbz	w9, #0, LBB1_193
LBB1_321:                               ; %cond.store782
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2864]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_194
LBB1_322:                               ; %cond.store785
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2864]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #2, LBB1_195
LBB1_323:                               ; %cond.store788
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2880]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #3, LBB1_196
LBB1_324:                               ; %cond.store791
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2880]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #4, LBB1_197
LBB1_325:                               ; %cond.store794
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2896]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #5, LBB1_198
LBB1_326:                               ; %cond.store797
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2896]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #6, LBB1_199
LBB1_327:                               ; %cond.store800
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2912]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #7, LBB1_200
LBB1_328:                               ; %cond.store803
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2912]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	str	wzr, [x9]
	fmov	w9, s23
	tbz	w9, #0, LBB1_201
LBB1_329:                               ; %cond.store807
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2800]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_202
LBB1_330:                               ; %cond.store810
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2800]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #2, LBB1_203
LBB1_331:                               ; %cond.store813
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2816]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #3, LBB1_204
LBB1_332:                               ; %cond.store816
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2816]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #4, LBB1_205
LBB1_333:                               ; %cond.store819
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2832]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #5, LBB1_206
LBB1_334:                               ; %cond.store822
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2832]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #6, LBB1_207
LBB1_335:                               ; %cond.store825
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2848]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #7, LBB1_208
LBB1_336:                               ; %cond.store828
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2848]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	str	wzr, [x9]
	fmov	w9, s23
	tbz	w9, #0, LBB1_209
LBB1_337:                               ; %cond.store832
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2736]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_210
LBB1_338:                               ; %cond.store835
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2736]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #2, LBB1_211
LBB1_339:                               ; %cond.store838
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2752]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #3, LBB1_212
LBB1_340:                               ; %cond.store841
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2752]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #4, LBB1_213
LBB1_341:                               ; %cond.store844
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2768]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #5, LBB1_214
LBB1_342:                               ; %cond.store847
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2768]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #6, LBB1_215
LBB1_343:                               ; %cond.store850
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2784]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #7, LBB1_216
LBB1_344:                               ; %cond.store853
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2784]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	str	wzr, [x9]
	fmov	w9, s23
	tbz	w9, #0, LBB1_217
LBB1_345:                               ; %cond.store857
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2672]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_218
LBB1_346:                               ; %cond.store860
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2672]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #2, LBB1_219
LBB1_347:                               ; %cond.store863
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2688]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #3, LBB1_220
LBB1_348:                               ; %cond.store866
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2688]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #4, LBB1_221
LBB1_349:                               ; %cond.store869
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2704]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #5, LBB1_222
LBB1_350:                               ; %cond.store872
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2704]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #6, LBB1_223
LBB1_351:                               ; %cond.store875
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2720]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #7, LBB1_224
LBB1_352:                               ; %cond.store878
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2720]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	str	wzr, [x9]
	fmov	w9, s23
	tbz	w9, #0, LBB1_225
LBB1_353:                               ; %cond.store882
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2608]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_226
LBB1_354:                               ; %cond.store885
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2608]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #2, LBB1_227
LBB1_355:                               ; %cond.store888
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2624]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #3, LBB1_228
LBB1_356:                               ; %cond.store891
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2624]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #4, LBB1_229
LBB1_357:                               ; %cond.store894
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2640]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #5, LBB1_230
LBB1_358:                               ; %cond.store897
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2640]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #6, LBB1_231
LBB1_359:                               ; %cond.store900
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2656]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #7, LBB1_232
LBB1_360:                               ; %cond.store903
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2656]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	str	wzr, [x9]
	fmov	w9, s23
	tbz	w9, #0, LBB1_233
LBB1_361:                               ; %cond.store907
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2544]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_234
LBB1_362:                               ; %cond.store910
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2544]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #2, LBB1_235
LBB1_363:                               ; %cond.store913
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2560]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #3, LBB1_236
LBB1_364:                               ; %cond.store916
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2560]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #4, LBB1_237
LBB1_365:                               ; %cond.store919
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2576]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #5, LBB1_238
LBB1_366:                               ; %cond.store922
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2576]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #6, LBB1_239
LBB1_367:                               ; %cond.store925
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2592]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #7, LBB1_240
LBB1_368:                               ; %cond.store928
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2592]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	str	wzr, [x9]
	fmov	w9, s23
	tbz	w9, #0, LBB1_241
LBB1_369:                               ; %cond.store932
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2480]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_242
LBB1_370:                               ; %cond.store935
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2480]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #2, LBB1_243
LBB1_371:                               ; %cond.store938
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2496]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #3, LBB1_244
LBB1_372:                               ; %cond.store941
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2496]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #4, LBB1_245
LBB1_373:                               ; %cond.store944
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2512]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #5, LBB1_246
LBB1_374:                               ; %cond.store947
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2512]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	str	wzr, [x11]
	tbz	w9, #6, LBB1_247
LBB1_375:                               ; %cond.store950
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2528]                 ; 16-byte Reload
	fmov	x11, d1
	str	wzr, [x11]
	tbz	w9, #7, LBB1_248
LBB1_376:                               ; %cond.store953
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2528]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	str	wzr, [x9]
	ldr	w9, [sp, #4492]                 ; 4-byte Reload
	tbz	w9, #0, LBB1_381
LBB1_377:                               ; %mma.active.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	mov	x9, #0                          ; =0x0
	ldr	q1, [sp, #5200]                 ; 16-byte Reload
	fmov	x11, d1
	ldr	q1, [sp, #5136]                 ; 16-byte Reload
	fmov	x12, d1
	add	x11, x11, x12
	mov	x12, x11
LBB1_378:                               ; %mma.update.i.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB1_379 Depth 4
	ldr	x7, [sp, #4936]                 ; 8-byte Reload
	ldr	s4, [x7, x9, lsl #2]
	ldr	q6, [x30]
	mul	x7, x9, x19
	ldr	q7, [x11, x7]
	fmul.4s	v6, v6, v7
	mov	w7, #16                         ; =0x10
LBB1_379:                               ; %mma.update2.i.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ;       Parent Loop BB1_378 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	q7, [x30, x7]
	ldr	q16, [x12, x7]
	fmul.4s	v7, v7, v16
	fadd.4s	v6, v6, v7
	add	x7, x7, #16
	cmp	x7, #320
	b.ne	LBB1_379
; %bb.380:                              ; %mma.fold.done3.i.i.i
                                        ;   in Loop: Header=BB1_378 Depth=3
	dup.4s	v7, v6[1]
	fadd.4s	v7, v6, v7
	dup.4s	v16, v6[3]
	fadd.4s	v6, v6, v16
	dup.4s	v6, v6[2]
	fadd.4s	v6, v7, v6
	fadd	s4, s4, s6
	ldr	x7, [sp, #4928]                 ; 8-byte Reload
	str	s4, [x7, x9, lsl #2]
	add	x9, x9, #1
	add	x12, x12, #320
	cmp	x9, #16
	b.ne	LBB1_378
LBB1_381:                               ; %mma.continue.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	w9, [sp, #4488]                 ; 4-byte Reload
	tbz	w9, #0, LBB1_386
; %bb.382:                              ; %mma.active190.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	mov	x9, #0                          ; =0x0
	ldr	q1, [sp, #5200]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ldr	q1, [sp, #5136]                 ; 16-byte Reload
	mov.d	x12, v1[1]
	add	x11, x11, x12
	mov	x12, x11
LBB1_383:                               ; %mma.update.i202.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB1_384 Depth 4
	ldr	x7, [sp, #4912]                 ; 8-byte Reload
	ldr	s4, [x7, x9, lsl #2]
	ldr	q6, [x23]
	mul	x7, x9, x19
	ldr	q7, [x11, x7]
	fmul.4s	v6, v6, v7
	mov	w7, #16                         ; =0x10
LBB1_384:                               ; %mma.update2.i205.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ;       Parent Loop BB1_383 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	q7, [x23, x7]
	ldr	q16, [x12, x7]
	fmul.4s	v7, v7, v16
	fadd.4s	v6, v6, v7
	add	x7, x7, #16
	cmp	x7, #320
	b.ne	LBB1_384
; %bb.385:                              ; %mma.fold.done3.i209.i.i
                                        ;   in Loop: Header=BB1_383 Depth=3
	dup.4s	v7, v6[1]
	fadd.4s	v7, v6, v7
	dup.4s	v16, v6[3]
	fadd.4s	v6, v6, v16
	dup.4s	v6, v6[2]
	fadd.4s	v6, v7, v6
	fadd	s4, s4, s6
	ldr	x7, [sp, #4896]                 ; 8-byte Reload
	str	s4, [x7, x9, lsl #2]
	add	x9, x9, #1
	add	x12, x12, #320
	cmp	x9, #16
	b.ne	LBB1_383
LBB1_386:                               ; %mma.continue191.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	w9, [sp, #4484]                 ; 4-byte Reload
	tbz	w9, #0, LBB1_391
; %bb.387:                              ; %mma.active192.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	mov	x9, #0                          ; =0x0
	ldr	q1, [sp, #5184]                 ; 16-byte Reload
	fmov	x11, d1
	ldr	q1, [sp, #5120]                 ; 16-byte Reload
	fmov	x12, d1
	add	x11, x11, x12
	mov	x12, x11
LBB1_388:                               ; %mma.update.i212.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB1_389 Depth 4
	ldr	x7, [sp, #4880]                 ; 8-byte Reload
	ldr	s4, [x7, x9, lsl #2]
	ldr	q6, [x26]
	mul	x7, x9, x19
	ldr	q7, [x11, x7]
	fmul.4s	v6, v6, v7
	mov	w7, #16                         ; =0x10
LBB1_389:                               ; %mma.update2.i215.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ;       Parent Loop BB1_388 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	q7, [x26, x7]
	ldr	q16, [x12, x7]
	fmul.4s	v7, v7, v16
	fadd.4s	v6, v6, v7
	add	x7, x7, #16
	cmp	x7, #320
	b.ne	LBB1_389
; %bb.390:                              ; %mma.fold.done3.i219.i.i
                                        ;   in Loop: Header=BB1_388 Depth=3
	dup.4s	v7, v6[1]
	fadd.4s	v7, v6, v7
	dup.4s	v16, v6[3]
	fadd.4s	v6, v6, v16
	dup.4s	v6, v6[2]
	fadd.4s	v6, v7, v6
	fadd	s4, s4, s6
	ldr	x7, [sp, #4864]                 ; 8-byte Reload
	str	s4, [x7, x9, lsl #2]
	add	x9, x9, #1
	add	x12, x12, #320
	cmp	x9, #16
	b.ne	LBB1_388
LBB1_391:                               ; %mma.continue193.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	w9, [sp, #4480]                 ; 4-byte Reload
	tbz	w9, #0, LBB1_396
; %bb.392:                              ; %mma.active194.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	mov	x9, #0                          ; =0x0
	ldr	q1, [sp, #5184]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ldr	q1, [sp, #5120]                 ; 16-byte Reload
	mov.d	x12, v1[1]
	add	x11, x11, x12
	mov	x12, x11
LBB1_393:                               ; %mma.update.i222.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB1_394 Depth 4
	ldr	x7, [sp, #4848]                 ; 8-byte Reload
	ldr	s4, [x7, x9, lsl #2]
	ldr	q6, [x8]
	mul	x7, x9, x19
	ldr	q7, [x11, x7]
	fmul.4s	v6, v6, v7
	mov	w7, #16                         ; =0x10
LBB1_394:                               ; %mma.update2.i225.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ;       Parent Loop BB1_393 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	q7, [x8, x7]
	ldr	q16, [x12, x7]
	fmul.4s	v7, v7, v16
	fadd.4s	v6, v6, v7
	add	x7, x7, #16
	cmp	x7, #320
	b.ne	LBB1_394
; %bb.395:                              ; %mma.fold.done3.i229.i.i
                                        ;   in Loop: Header=BB1_393 Depth=3
	dup.4s	v7, v6[1]
	fadd.4s	v7, v6, v7
	dup.4s	v16, v6[3]
	fadd.4s	v6, v6, v16
	dup.4s	v6, v6[2]
	fadd.4s	v6, v7, v6
	fadd	s4, s4, s6
	ldr	x7, [sp, #4832]                 ; 8-byte Reload
	str	s4, [x7, x9, lsl #2]
	add	x9, x9, #1
	add	x12, x12, #320
	cmp	x9, #16
	b.ne	LBB1_393
LBB1_396:                               ; %mma.continue195.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	w9, [sp, #4476]                 ; 4-byte Reload
	tbz	w9, #0, LBB1_401
; %bb.397:                              ; %mma.active196.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	mov	x9, #0                          ; =0x0
	ldr	q1, [sp, #5168]                 ; 16-byte Reload
	fmov	x11, d1
	ldr	q1, [sp, #5104]                 ; 16-byte Reload
	fmov	x12, d1
	add	x11, x11, x12
	mov	x12, x11
LBB1_398:                               ; %mma.update.i232.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB1_399 Depth 4
	ldr	x7, [sp, #4824]                 ; 8-byte Reload
	ldr	s4, [x7, x9, lsl #2]
	ldr	q6, [x2]
	mul	x7, x9, x19
	ldr	q7, [x11, x7]
	fmul.4s	v6, v6, v7
	mov	w7, #16                         ; =0x10
LBB1_399:                               ; %mma.update2.i235.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ;       Parent Loop BB1_398 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	q7, [x2, x7]
	ldr	q16, [x12, x7]
	fmul.4s	v7, v7, v16
	fadd.4s	v6, v6, v7
	add	x7, x7, #16
	cmp	x7, #320
	b.ne	LBB1_399
; %bb.400:                              ; %mma.fold.done3.i239.i.i
                                        ;   in Loop: Header=BB1_398 Depth=3
	dup.4s	v7, v6[1]
	fadd.4s	v7, v6, v7
	dup.4s	v16, v6[3]
	fadd.4s	v6, v6, v16
	dup.4s	v6, v6[2]
	fadd.4s	v6, v7, v6
	fadd	s4, s4, s6
	ldr	x7, [sp, #4816]                 ; 8-byte Reload
	str	s4, [x7, x9, lsl #2]
	add	x9, x9, #1
	add	x12, x12, #320
	cmp	x9, #16
	b.ne	LBB1_398
LBB1_401:                               ; %mma.continue197.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	w9, [sp, #4472]                 ; 4-byte Reload
	tbz	w9, #0, LBB1_406
; %bb.402:                              ; %mma.active198.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	mov	x9, #0                          ; =0x0
	ldr	q1, [sp, #5168]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ldr	q1, [sp, #5104]                 ; 16-byte Reload
	mov.d	x12, v1[1]
	add	x11, x11, x12
	mov	x12, x11
LBB1_403:                               ; %mma.update.i242.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB1_404 Depth 4
	ldr	x7, [sp, #4808]                 ; 8-byte Reload
	ldr	s4, [x7, x9, lsl #2]
	ldr	q6, [x5]
	mul	x7, x9, x19
	ldr	q7, [x11, x7]
	fmul.4s	v6, v6, v7
	mov	w7, #16                         ; =0x10
LBB1_404:                               ; %mma.update2.i245.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ;       Parent Loop BB1_403 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	q7, [x5, x7]
	ldr	q16, [x12, x7]
	fmul.4s	v7, v7, v16
	fadd.4s	v6, v6, v7
	add	x7, x7, #16
	cmp	x7, #320
	b.ne	LBB1_404
; %bb.405:                              ; %mma.fold.done3.i249.i.i
                                        ;   in Loop: Header=BB1_403 Depth=3
	dup.4s	v7, v6[1]
	fadd.4s	v7, v6, v7
	dup.4s	v16, v6[3]
	fadd.4s	v6, v6, v16
	dup.4s	v6, v6[2]
	fadd.4s	v6, v7, v6
	fadd	s4, s4, s6
	ldr	x7, [sp, #4800]                 ; 8-byte Reload
	str	s4, [x7, x9, lsl #2]
	add	x9, x9, #1
	add	x12, x12, #320
	cmp	x9, #16
	b.ne	LBB1_403
LBB1_406:                               ; %mma.continue199.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	w9, [sp, #4468]                 ; 4-byte Reload
	tbz	w9, #0, LBB1_411
; %bb.407:                              ; %mma.active200.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	mov	x9, #0                          ; =0x0
	ldr	q1, [sp, #5152]                 ; 16-byte Reload
	fmov	x11, d1
	ldr	q1, [sp, #5088]                 ; 16-byte Reload
	fmov	x12, d1
	add	x11, x11, x12
	mov	x12, x11
LBB1_408:                               ; %mma.update.i252.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB1_409 Depth 4
	ldr	s4, [x20, x9, lsl #2]
	ldr	q6, [x10]
	mul	x7, x9, x19
	ldr	q7, [x11, x7]
	fmul.4s	v6, v6, v7
	mov	w7, #16                         ; =0x10
LBB1_409:                               ; %mma.update2.i255.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ;       Parent Loop BB1_408 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	q7, [x10, x7]
	ldr	q16, [x12, x7]
	fmul.4s	v7, v7, v16
	fadd.4s	v6, v6, v7
	add	x7, x7, #16
	cmp	x7, #320
	b.ne	LBB1_409
; %bb.410:                              ; %mma.fold.done3.i259.i.i
                                        ;   in Loop: Header=BB1_408 Depth=3
	dup.4s	v7, v6[1]
	fadd.4s	v7, v6, v7
	dup.4s	v16, v6[3]
	fadd.4s	v6, v6, v16
	dup.4s	v6, v6[2]
	fadd.4s	v6, v7, v6
	fadd	s4, s4, s6
	ldr	x7, [sp, #4792]                 ; 8-byte Reload
	str	s4, [x7, x9, lsl #2]
	add	x9, x9, #1
	add	x12, x12, #320
	cmp	x9, #16
	b.ne	LBB1_408
LBB1_411:                               ; %mma.continue201.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	w9, [sp, #4464]                 ; 4-byte Reload
	tbz	w9, #0, LBB1_416
; %bb.412:                              ; %mma.active202.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	mov	x9, #0                          ; =0x0
	ldr	q1, [sp, #5152]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ldr	q1, [sp, #5088]                 ; 16-byte Reload
	mov.d	x12, v1[1]
	add	x11, x11, x12
	mov	x12, x11
LBB1_413:                               ; %mma.update.i262.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB1_414 Depth 4
	ldr	x7, [sp, #4784]                 ; 8-byte Reload
	ldr	s4, [x7, x9, lsl #2]
	ldr	q6, [x13]
	mul	x7, x9, x19
	ldr	q7, [x11, x7]
	fmul.4s	v6, v6, v7
	mov	w7, #16                         ; =0x10
LBB1_414:                               ; %mma.update2.i265.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ;       Parent Loop BB1_413 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	q7, [x13, x7]
	ldr	q16, [x12, x7]
	fmul.4s	v7, v7, v16
	fadd.4s	v6, v6, v7
	add	x7, x7, #16
	cmp	x7, #320
	b.ne	LBB1_414
; %bb.415:                              ; %mma.fold.done3.i269.i.i
                                        ;   in Loop: Header=BB1_413 Depth=3
	dup.4s	v7, v6[1]
	fadd.4s	v7, v6, v7
	dup.4s	v16, v6[3]
	fadd.4s	v6, v6, v16
	dup.4s	v6, v6[2]
	fadd.4s	v6, v7, v6
	fadd	s4, s4, s6
	ldr	x7, [sp, #4776]                 ; 8-byte Reload
	str	s4, [x7, x9, lsl #2]
	add	x9, x9, #1
	add	x12, x12, #320
	cmp	x9, #16
	b.ne	LBB1_413
LBB1_416:                               ; %mma.continue203.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbnz	w9, #0, LBB1_537
; %bb.417:                              ; %else1010
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_538
LBB1_418:                               ; %else1016
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_539
LBB1_419:                               ; %else1022
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_540
LBB1_420:                               ; %else1028
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_541
LBB1_421:                               ; %else1034
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_542
LBB1_422:                               ; %else1040
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_543
LBB1_423:                               ; %else1046
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #7, LBB1_544
LBB1_424:                               ; %else1052
                                        ;   in Loop: Header=BB1_50 Depth=2
	str	q4, [sp, #4288]                 ; 16-byte Spill
	fmov	w9, s23
	movi.2d	v4, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbnz	w9, #0, LBB1_545
LBB1_425:                               ; %else1059
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_546
LBB1_426:                               ; %else1065
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_547
LBB1_427:                               ; %else1071
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_548
LBB1_428:                               ; %else1077
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_549
LBB1_429:                               ; %else1083
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_550
LBB1_430:                               ; %else1089
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_551
LBB1_431:                               ; %else1095
                                        ;   in Loop: Header=BB1_50 Depth=2
	str	q4, [sp, #4944]                 ; 16-byte Spill
	tbnz	w9, #7, LBB1_552
LBB1_432:                               ; %else1101
                                        ;   in Loop: Header=BB1_50 Depth=2
	str	q6, [sp, #4528]                 ; 16-byte Spill
	fmov	w9, s23
	movi.2d	v6, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbnz	w9, #0, LBB1_553
LBB1_433:                               ; %else1108
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_554
LBB1_434:                               ; %else1114
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_555
LBB1_435:                               ; %else1120
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_556
LBB1_436:                               ; %else1126
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_557
LBB1_437:                               ; %else1132
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_558
LBB1_438:                               ; %else1138
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_559
LBB1_439:                               ; %else1144
                                        ;   in Loop: Header=BB1_50 Depth=2
	str	q6, [sp, #4720]                 ; 16-byte Spill
	tbnz	w9, #7, LBB1_560
LBB1_440:                               ; %else1150
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	tbnz	w9, #0, LBB1_561
LBB1_441:                               ; %else1157
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_562
LBB1_442:                               ; %else1163
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_563
LBB1_443:                               ; %else1169
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_564
LBB1_444:                               ; %else1175
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_565
LBB1_445:                               ; %else1181
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_566
LBB1_446:                               ; %else1187
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_567
LBB1_447:                               ; %else1193
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #7, LBB1_568
LBB1_448:                               ; %else1199
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	movi.2d	v16, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB1_569
LBB1_449:                               ; %else1206
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_570
LBB1_450:                               ; %else1212
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_571
LBB1_451:                               ; %else1218
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_572
LBB1_452:                               ; %else1224
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_573
LBB1_453:                               ; %else1230
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_574
LBB1_454:                               ; %else1236
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_575
LBB1_455:                               ; %else1242
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #7, LBB1_576
LBB1_456:                               ; %else1248
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	movi.2d	v21, #0000000000000000
	movi.2d	v24, #0000000000000000
	tbnz	w9, #0, LBB1_577
LBB1_457:                               ; %else1255
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_578
LBB1_458:                               ; %else1261
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_579
LBB1_459:                               ; %else1267
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_580
LBB1_460:                               ; %else1273
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_581
LBB1_461:                               ; %else1279
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_582
LBB1_462:                               ; %else1285
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_583
LBB1_463:                               ; %else1291
                                        ;   in Loop: Header=BB1_50 Depth=2
	str	q3, [sp, #4176]                 ; 16-byte Spill
	tbnz	w9, #7, LBB1_584
LBB1_464:                               ; %else1297
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	movi.2d	v19, #0000000000000000
	movi.2d	v8, #0000000000000000
	tbnz	w9, #0, LBB1_585
LBB1_465:                               ; %else1304
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_586
LBB1_466:                               ; %else1310
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_587
LBB1_467:                               ; %else1316
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_588
LBB1_468:                               ; %else1322
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_589
LBB1_469:                               ; %else1328
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_590
LBB1_470:                               ; %else1334
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_591
LBB1_471:                               ; %else1340
                                        ;   in Loop: Header=BB1_50 Depth=2
	str	q16, [sp, #4128]                ; 16-byte Spill
	tbnz	w9, #7, LBB1_592
LBB1_472:                               ; %else1346
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	movi.2d	v9, #0000000000000000
	movi.2d	v11, #0000000000000000
	tbnz	w9, #0, LBB1_593
LBB1_473:                               ; %else1353
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_594
LBB1_474:                               ; %else1359
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_595
LBB1_475:                               ; %else1365
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_596
LBB1_476:                               ; %else1371
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_597
LBB1_477:                               ; %else1377
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_598
LBB1_478:                               ; %else1383
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_599
LBB1_479:                               ; %else1389
                                        ;   in Loop: Header=BB1_50 Depth=2
	str	q6, [sp, #4144]                 ; 16-byte Spill
	tbnz	w9, #7, LBB1_600
LBB1_480:                               ; %else1395
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	movi.2d	v15, #0000000000000000
	movi.2d	v1, #0000000000000000
	str	q1, [sp, #4960]                 ; 16-byte Spill
	tbnz	w9, #0, LBB1_601
LBB1_481:                               ; %else1402
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_602
LBB1_482:                               ; %else1408
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_603
LBB1_483:                               ; %else1414
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_604
LBB1_484:                               ; %else1420
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_605
LBB1_485:                               ; %else1426
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_606
LBB1_486:                               ; %else1432
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_607
LBB1_487:                               ; %else1438
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #7, LBB1_608
LBB1_488:                               ; %else1444
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	movi.2d	v1, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbnz	w9, #0, LBB1_609
LBB1_489:                               ; %else1451
                                        ;   in Loop: Header=BB1_50 Depth=2
	mov.16b	v3, v28
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_610
LBB1_490:                               ; %else1457
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_611
LBB1_491:                               ; %else1463
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_612
LBB1_492:                               ; %else1469
                                        ;   in Loop: Header=BB1_50 Depth=2
	mov.16b	v28, v3
	mov.16b	v3, v6
	str	q1, [sp, #4192]                 ; 16-byte Spill
	tbnz	w9, #4, LBB1_613
LBB1_493:                               ; %else1475
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_614
LBB1_494:                               ; %else1481
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_615
LBB1_495:                               ; %else1487
                                        ;   in Loop: Header=BB1_50 Depth=2
	str	q28, [sp, #4400]                ; 16-byte Spill
	tbnz	w9, #7, LBB1_616
LBB1_496:                               ; %else1493
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	movi.2d	v28, #0000000000000000
	tbnz	w9, #0, LBB1_617
LBB1_497:                               ; %else1500
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_618
LBB1_498:                               ; %else1506
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_619
LBB1_499:                               ; %else1512
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_620
LBB1_500:                               ; %else1518
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_621
LBB1_501:                               ; %else1524
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_622
LBB1_502:                               ; %else1530
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_623
LBB1_503:                               ; %else1536
                                        ;   in Loop: Header=BB1_50 Depth=2
	str	q11, [sp, #4224]                ; 16-byte Spill
	tbnz	w9, #7, LBB1_624
LBB1_504:                               ; %else1542
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	movi.2d	v16, #0000000000000000
	movi.2d	v11, #0000000000000000
	tbnz	w9, #0, LBB1_625
LBB1_505:                               ; %else1549
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_626
LBB1_506:                               ; %else1555
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_627
LBB1_507:                               ; %else1561
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_628
LBB1_508:                               ; %else1567
                                        ;   in Loop: Header=BB1_50 Depth=2
	str	q16, [sp, #3936]                ; 16-byte Spill
	tbnz	w9, #4, LBB1_629
LBB1_509:                               ; %else1573
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_630
LBB1_510:                               ; %else1579
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_631
LBB1_511:                               ; %else1585
                                        ;   in Loop: Header=BB1_50 Depth=2
	str	q27, [sp, #4336]                ; 16-byte Spill
	str	q7, [sp, #4544]                 ; 16-byte Spill
	tbnz	w9, #7, LBB1_632
LBB1_512:                               ; %else1591
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	movi.2d	v27, #0000000000000000
	movi.2d	v7, #0000000000000000
	tbnz	w9, #0, LBB1_633
LBB1_513:                               ; %else1598
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_634
LBB1_514:                               ; %else1604
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_635
LBB1_515:                               ; %else1610
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_636
LBB1_516:                               ; %else1616
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_637
LBB1_517:                               ; %else1622
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_638
LBB1_518:                               ; %else1628
                                        ;   in Loop: Header=BB1_50 Depth=2
	str	q19, [sp, #4272]                ; 16-byte Spill
	tbnz	w9, #6, LBB1_639
LBB1_519:                               ; %else1634
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q19, [sp, #4176]                ; 16-byte Reload
	str	q29, [sp, #4384]                ; 16-byte Spill
	str	q4, [sp, #4304]                 ; 16-byte Spill
	tbnz	w9, #7, LBB1_640
LBB1_520:                               ; %else1640
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	movi.2d	v29, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbnz	w9, #0, LBB1_641
LBB1_521:                               ; %else1647
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_642
LBB1_522:                               ; %else1653
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_643
LBB1_523:                               ; %else1659
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_644
LBB1_524:                               ; %else1665
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_645
LBB1_525:                               ; %else1671
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_646
LBB1_526:                               ; %else1677
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_647
LBB1_527:                               ; %else1683
                                        ;   in Loop: Header=BB1_50 Depth=2
	str	q3, [sp, #4160]                 ; 16-byte Spill
	str	q8, [sp, #4256]                 ; 16-byte Spill
	str	q24, [sp, #4240]                ; 16-byte Spill
	mov.16b	v3, v21
	mov.16b	v24, v18
	tbnz	w9, #7, LBB1_648
LBB1_528:                               ; %else1689
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov	w9, s23
	movi.2d	v21, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB1_649
LBB1_529:                               ; %else1696
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_650
LBB1_530:                               ; %else1702
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_651
LBB1_531:                               ; %else1708
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_652
LBB1_532:                               ; %else1714
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_653
LBB1_533:                               ; %else1720
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_654
LBB1_534:                               ; %else1726
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_655
LBB1_535:                               ; %else1732
                                        ;   in Loop: Header=BB1_50 Depth=2
	str	q15, [sp, #4208]                ; 16-byte Spill
	mov.16b	v8, v9
	str	q6, [sp, #3984]                 ; 16-byte Spill
	tbz	w9, #7, LBB1_656
LBB1_536:                               ; %cond.load1734
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q9, [sp, #4128]                 ; 16-byte Reload
	ldr	q15, [sp, #4144]                ; 16-byte Reload
	ldr	q1, [sp, #1568]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[3], [x9]
	fmov	w9, s23
	movi.2d	v16, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbnz	w9, #0, LBB1_657
	b	LBB1_658
LBB1_537:                               ; %cond.load1006
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2416]                 ; 16-byte Reload
	fmov	x11, d1
	ldr	s3, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_418
LBB1_538:                               ; %cond.load1012
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2416]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v3 }[1], [x11]
	tbz	w9, #2, LBB1_419
LBB1_539:                               ; %cond.load1018
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2432]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v3 }[2], [x11]
	tbz	w9, #3, LBB1_420
LBB1_540:                               ; %cond.load1024
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2432]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v3 }[3], [x11]
	tbz	w9, #4, LBB1_421
LBB1_541:                               ; %cond.load1030
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2448]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v4 }[0], [x11]
	tbz	w9, #5, LBB1_422
LBB1_542:                               ; %cond.load1036
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2448]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v4 }[1], [x11]
	tbz	w9, #6, LBB1_423
LBB1_543:                               ; %cond.load1042
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2464]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v4 }[2], [x11]
	tbz	w9, #7, LBB1_424
LBB1_544:                               ; %cond.load1048
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2464]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	ld1.s	{ v4 }[3], [x9]
	str	q4, [sp, #4288]                 ; 16-byte Spill
	fmov	w9, s23
	movi.2d	v4, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbz	w9, #0, LBB1_425
LBB1_545:                               ; %cond.load1055
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2352]                 ; 16-byte Reload
	fmov	x11, d1
	ldr	s4, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_426
LBB1_546:                               ; %cond.load1061
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2352]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v4 }[1], [x11]
	tbz	w9, #2, LBB1_427
LBB1_547:                               ; %cond.load1067
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2368]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v4 }[2], [x11]
	tbz	w9, #3, LBB1_428
LBB1_548:                               ; %cond.load1073
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2368]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v4 }[3], [x11]
	tbz	w9, #4, LBB1_429
LBB1_549:                               ; %cond.load1079
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2384]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v6 }[0], [x11]
	tbz	w9, #5, LBB1_430
LBB1_550:                               ; %cond.load1085
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2384]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v6 }[1], [x11]
	tbz	w9, #6, LBB1_431
LBB1_551:                               ; %cond.load1091
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2400]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v6 }[2], [x11]
	str	q4, [sp, #4944]                 ; 16-byte Spill
	tbz	w9, #7, LBB1_432
LBB1_552:                               ; %cond.load1097
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2400]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #4528]                 ; 16-byte Spill
	fmov	w9, s23
	movi.2d	v6, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbz	w9, #0, LBB1_433
LBB1_553:                               ; %cond.load1104
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2288]                 ; 16-byte Reload
	fmov	x11, d1
	ldr	s6, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_434
LBB1_554:                               ; %cond.load1110
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2288]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v6 }[1], [x11]
	tbz	w9, #2, LBB1_435
LBB1_555:                               ; %cond.load1116
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2304]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v6 }[2], [x11]
	tbz	w9, #3, LBB1_436
LBB1_556:                               ; %cond.load1122
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2304]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v6 }[3], [x11]
	tbz	w9, #4, LBB1_437
LBB1_557:                               ; %cond.load1128
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2320]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v4 }[0], [x11]
	tbz	w9, #5, LBB1_438
LBB1_558:                               ; %cond.load1134
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2320]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v4 }[1], [x11]
	tbz	w9, #6, LBB1_439
LBB1_559:                               ; %cond.load1140
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2336]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v4 }[2], [x11]
	str	q6, [sp, #4720]                 ; 16-byte Spill
	tbz	w9, #7, LBB1_440
LBB1_560:                               ; %cond.load1146
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2336]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	ld1.s	{ v4 }[3], [x9]
	fmov	w9, s23
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	tbz	w9, #0, LBB1_441
LBB1_561:                               ; %cond.load1153
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2224]                 ; 16-byte Reload
	fmov	x11, d1
	ldr	s6, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_442
LBB1_562:                               ; %cond.load1159
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2224]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v6 }[1], [x11]
	tbz	w9, #2, LBB1_443
LBB1_563:                               ; %cond.load1165
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2240]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v6 }[2], [x11]
	tbz	w9, #3, LBB1_444
LBB1_564:                               ; %cond.load1171
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2240]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v6 }[3], [x11]
	tbz	w9, #4, LBB1_445
LBB1_565:                               ; %cond.load1177
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2256]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v7 }[0], [x11]
	tbz	w9, #5, LBB1_446
LBB1_566:                               ; %cond.load1183
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2256]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v7 }[1], [x11]
	tbz	w9, #6, LBB1_447
LBB1_567:                               ; %cond.load1189
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2272]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v7 }[2], [x11]
	tbz	w9, #7, LBB1_448
LBB1_568:                               ; %cond.load1195
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2272]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	ld1.s	{ v7 }[3], [x9]
	fmov	w9, s23
	movi.2d	v16, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbz	w9, #0, LBB1_449
LBB1_569:                               ; %cond.load1202
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2160]                 ; 16-byte Reload
	fmov	x11, d1
	ldr	s16, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_450
LBB1_570:                               ; %cond.load1208
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2160]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v16 }[1], [x11]
	tbz	w9, #2, LBB1_451
LBB1_571:                               ; %cond.load1214
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2176]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v16 }[2], [x11]
	tbz	w9, #3, LBB1_452
LBB1_572:                               ; %cond.load1220
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2176]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v16 }[3], [x11]
	tbz	w9, #4, LBB1_453
LBB1_573:                               ; %cond.load1226
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2192]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v18 }[0], [x11]
	tbz	w9, #5, LBB1_454
LBB1_574:                               ; %cond.load1232
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2192]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v18 }[1], [x11]
	tbz	w9, #6, LBB1_455
LBB1_575:                               ; %cond.load1238
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2208]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v18 }[2], [x11]
	tbz	w9, #7, LBB1_456
LBB1_576:                               ; %cond.load1244
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2208]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[3], [x9]
	fmov	w9, s23
	movi.2d	v21, #0000000000000000
	movi.2d	v24, #0000000000000000
	tbz	w9, #0, LBB1_457
LBB1_577:                               ; %cond.load1251
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2096]                 ; 16-byte Reload
	fmov	x11, d1
	ldr	s21, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_458
LBB1_578:                               ; %cond.load1257
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2096]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v21 }[1], [x11]
	tbz	w9, #2, LBB1_459
LBB1_579:                               ; %cond.load1263
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2112]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v21 }[2], [x11]
	tbz	w9, #3, LBB1_460
LBB1_580:                               ; %cond.load1269
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2112]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v21 }[3], [x11]
	tbz	w9, #4, LBB1_461
LBB1_581:                               ; %cond.load1275
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2128]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v24 }[0], [x11]
	tbz	w9, #5, LBB1_462
LBB1_582:                               ; %cond.load1281
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2128]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v24 }[1], [x11]
	tbz	w9, #6, LBB1_463
LBB1_583:                               ; %cond.load1287
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2144]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v24 }[2], [x11]
	str	q3, [sp, #4176]                 ; 16-byte Spill
	tbz	w9, #7, LBB1_464
LBB1_584:                               ; %cond.load1293
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2144]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	ld1.s	{ v24 }[3], [x9]
	fmov	w9, s23
	movi.2d	v19, #0000000000000000
	movi.2d	v8, #0000000000000000
	tbz	w9, #0, LBB1_465
LBB1_585:                               ; %cond.load1300
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2032]                 ; 16-byte Reload
	fmov	x11, d1
	ldr	s19, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_466
LBB1_586:                               ; %cond.load1306
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2032]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v19 }[1], [x11]
	tbz	w9, #2, LBB1_467
LBB1_587:                               ; %cond.load1312
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2048]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v19 }[2], [x11]
	tbz	w9, #3, LBB1_468
LBB1_588:                               ; %cond.load1318
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2048]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v19 }[3], [x11]
	tbz	w9, #4, LBB1_469
LBB1_589:                               ; %cond.load1324
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2064]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v8 }[0], [x11]
	tbz	w9, #5, LBB1_470
LBB1_590:                               ; %cond.load1330
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2064]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v8 }[1], [x11]
	tbz	w9, #6, LBB1_471
LBB1_591:                               ; %cond.load1336
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2080]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v8 }[2], [x11]
	str	q16, [sp, #4128]                ; 16-byte Spill
	tbz	w9, #7, LBB1_472
LBB1_592:                               ; %cond.load1342
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2080]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	ld1.s	{ v8 }[3], [x9]
	fmov	w9, s23
	movi.2d	v9, #0000000000000000
	movi.2d	v11, #0000000000000000
	tbz	w9, #0, LBB1_473
LBB1_593:                               ; %cond.load1349
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1968]                 ; 16-byte Reload
	fmov	x11, d1
	ldr	s9, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_474
LBB1_594:                               ; %cond.load1355
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1968]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v9 }[1], [x11]
	tbz	w9, #2, LBB1_475
LBB1_595:                               ; %cond.load1361
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1984]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v9 }[2], [x11]
	tbz	w9, #3, LBB1_476
LBB1_596:                               ; %cond.load1367
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1984]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v9 }[3], [x11]
	tbz	w9, #4, LBB1_477
LBB1_597:                               ; %cond.load1373
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2000]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v11 }[0], [x11]
	tbz	w9, #5, LBB1_478
LBB1_598:                               ; %cond.load1379
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2000]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v11 }[1], [x11]
	tbz	w9, #6, LBB1_479
LBB1_599:                               ; %cond.load1385
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2016]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v11 }[2], [x11]
	str	q6, [sp, #4144]                 ; 16-byte Spill
	tbz	w9, #7, LBB1_480
LBB1_600:                               ; %cond.load1391
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #2016]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	ld1.s	{ v11 }[3], [x9]
	fmov	w9, s23
	movi.2d	v15, #0000000000000000
	movi.2d	v1, #0000000000000000
	str	q1, [sp, #4960]                 ; 16-byte Spill
	tbz	w9, #0, LBB1_481
LBB1_601:                               ; %cond.load1398
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1904]                 ; 16-byte Reload
	fmov	x11, d1
	ldr	s15, [x11]
	movi.2d	v1, #0000000000000000
	str	q1, [sp, #4960]                 ; 16-byte Spill
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_482
LBB1_602:                               ; %cond.load1404
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1904]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v15 }[1], [x11]
	tbz	w9, #2, LBB1_483
LBB1_603:                               ; %cond.load1410
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1920]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v15 }[2], [x11]
	tbz	w9, #3, LBB1_484
LBB1_604:                               ; %cond.load1416
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1920]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v15 }[3], [x11]
	tbz	w9, #4, LBB1_485
LBB1_605:                               ; %cond.load1422
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1936]                 ; 16-byte Reload
	fmov	x11, d1
	ldr	q1, [sp, #4960]                 ; 16-byte Reload
	ld1.s	{ v1 }[0], [x11]
	str	q1, [sp, #4960]                 ; 16-byte Spill
	tbz	w9, #5, LBB1_486
LBB1_606:                               ; %cond.load1428
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1936]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ldr	q1, [sp, #4960]                 ; 16-byte Reload
	ld1.s	{ v1 }[1], [x11]
	str	q1, [sp, #4960]                 ; 16-byte Spill
	tbz	w9, #6, LBB1_487
LBB1_607:                               ; %cond.load1434
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1952]                 ; 16-byte Reload
	fmov	x11, d1
	ldr	q1, [sp, #4960]                 ; 16-byte Reload
	ld1.s	{ v1 }[2], [x11]
	str	q1, [sp, #4960]                 ; 16-byte Spill
	tbz	w9, #7, LBB1_488
LBB1_608:                               ; %cond.load1440
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1952]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	ldr	q1, [sp, #4960]                 ; 16-byte Reload
	ld1.s	{ v1 }[3], [x9]
	str	q1, [sp, #4960]                 ; 16-byte Spill
	fmov	w9, s23
	movi.2d	v1, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbz	w9, #0, LBB1_489
LBB1_609:                               ; %cond.load1447
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1840]                 ; 16-byte Reload
	fmov	x11, d1
	ldr	s1, [x11]
	mov.16b	v3, v28
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_490
LBB1_610:                               ; %cond.load1453
                                        ;   in Loop: Header=BB1_50 Depth=2
	mov.16b	v28, v1
	ldr	q1, [sp, #1840]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	mov.16b	v1, v28
	ld1.s	{ v1 }[1], [x11]
	tbz	w9, #2, LBB1_491
LBB1_611:                               ; %cond.load1459
                                        ;   in Loop: Header=BB1_50 Depth=2
	mov.16b	v28, v1
	ldr	q1, [sp, #1856]                 ; 16-byte Reload
	fmov	x11, d1
	mov.16b	v1, v28
	ld1.s	{ v1 }[2], [x11]
	tbz	w9, #3, LBB1_492
LBB1_612:                               ; %cond.load1465
                                        ;   in Loop: Header=BB1_50 Depth=2
	mov.16b	v28, v1
	ldr	q1, [sp, #1856]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	mov.16b	v1, v28
	ld1.s	{ v1 }[3], [x11]
	mov.16b	v28, v3
	mov.16b	v3, v6
	str	q1, [sp, #4192]                 ; 16-byte Spill
	tbz	w9, #4, LBB1_493
LBB1_613:                               ; %cond.load1471
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1872]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v3 }[0], [x11]
	tbz	w9, #5, LBB1_494
LBB1_614:                               ; %cond.load1477
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1872]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v3 }[1], [x11]
	tbz	w9, #6, LBB1_495
LBB1_615:                               ; %cond.load1483
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1888]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v3 }[2], [x11]
	str	q28, [sp, #4400]                ; 16-byte Spill
	tbz	w9, #7, LBB1_496
LBB1_616:                               ; %cond.load1489
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1888]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	ld1.s	{ v3 }[3], [x9]
	fmov	w9, s23
	movi.2d	v28, #0000000000000000
	tbz	w9, #0, LBB1_497
LBB1_617:                               ; %cond.load1496
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1776]                 ; 16-byte Reload
	fmov	x11, d1
	ldr	s6, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_498
LBB1_618:                               ; %cond.load1502
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1776]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v6 }[1], [x11]
	tbz	w9, #2, LBB1_499
LBB1_619:                               ; %cond.load1508
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1792]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v6 }[2], [x11]
	tbz	w9, #3, LBB1_500
LBB1_620:                               ; %cond.load1514
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1792]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v6 }[3], [x11]
	tbz	w9, #4, LBB1_501
LBB1_621:                               ; %cond.load1520
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1808]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v28 }[0], [x11]
	tbz	w9, #5, LBB1_502
LBB1_622:                               ; %cond.load1526
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1808]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v28 }[1], [x11]
	tbz	w9, #6, LBB1_503
LBB1_623:                               ; %cond.load1532
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1824]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v28 }[2], [x11]
	str	q11, [sp, #4224]                ; 16-byte Spill
	tbz	w9, #7, LBB1_504
LBB1_624:                               ; %cond.load1538
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1824]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	ld1.s	{ v28 }[3], [x9]
	fmov	w9, s23
	movi.2d	v16, #0000000000000000
	movi.2d	v11, #0000000000000000
	tbz	w9, #0, LBB1_505
LBB1_625:                               ; %cond.load1545
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1712]                 ; 16-byte Reload
	fmov	x11, d1
	ldr	s16, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_506
LBB1_626:                               ; %cond.load1551
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1712]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v16 }[1], [x11]
	tbz	w9, #2, LBB1_507
LBB1_627:                               ; %cond.load1557
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1728]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v16 }[2], [x11]
	tbz	w9, #3, LBB1_508
LBB1_628:                               ; %cond.load1563
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1728]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v16 }[3], [x11]
	str	q16, [sp, #3936]                ; 16-byte Spill
	tbz	w9, #4, LBB1_509
LBB1_629:                               ; %cond.load1569
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1744]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v11 }[0], [x11]
	tbz	w9, #5, LBB1_510
LBB1_630:                               ; %cond.load1575
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1744]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v11 }[1], [x11]
	tbz	w9, #6, LBB1_511
LBB1_631:                               ; %cond.load1581
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1760]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v11 }[2], [x11]
	str	q27, [sp, #4336]                ; 16-byte Spill
	str	q7, [sp, #4544]                 ; 16-byte Spill
	tbz	w9, #7, LBB1_512
LBB1_632:                               ; %cond.load1587
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1760]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	ld1.s	{ v11 }[3], [x9]
	fmov	w9, s23
	movi.2d	v27, #0000000000000000
	movi.2d	v7, #0000000000000000
	tbz	w9, #0, LBB1_513
LBB1_633:                               ; %cond.load1594
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1648]                 ; 16-byte Reload
	fmov	x11, d1
	ldr	s27, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_514
LBB1_634:                               ; %cond.load1600
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1648]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v27 }[1], [x11]
	tbz	w9, #2, LBB1_515
LBB1_635:                               ; %cond.load1606
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1664]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v27 }[2], [x11]
	tbz	w9, #3, LBB1_516
LBB1_636:                               ; %cond.load1612
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1664]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v27 }[3], [x11]
	tbz	w9, #4, LBB1_517
LBB1_637:                               ; %cond.load1618
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1680]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v7 }[0], [x11]
	tbz	w9, #5, LBB1_518
LBB1_638:                               ; %cond.load1624
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1680]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v7 }[1], [x11]
	str	q19, [sp, #4272]                ; 16-byte Spill
	tbz	w9, #6, LBB1_519
LBB1_639:                               ; %cond.load1630
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1696]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v7 }[2], [x11]
	ldr	q19, [sp, #4176]                ; 16-byte Reload
	str	q29, [sp, #4384]                ; 16-byte Spill
	str	q4, [sp, #4304]                 ; 16-byte Spill
	tbz	w9, #7, LBB1_520
LBB1_640:                               ; %cond.load1636
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1696]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	ld1.s	{ v7 }[3], [x9]
	fmov	w9, s23
	movi.2d	v29, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbz	w9, #0, LBB1_521
LBB1_641:                               ; %cond.load1643
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1584]                 ; 16-byte Reload
	fmov	x11, d1
	ldr	s29, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_522
LBB1_642:                               ; %cond.load1649
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1584]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v29 }[1], [x11]
	tbz	w9, #2, LBB1_523
LBB1_643:                               ; %cond.load1655
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1600]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v29 }[2], [x11]
	tbz	w9, #3, LBB1_524
LBB1_644:                               ; %cond.load1661
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1600]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v29 }[3], [x11]
	tbz	w9, #4, LBB1_525
LBB1_645:                               ; %cond.load1667
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1616]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v4 }[0], [x11]
	tbz	w9, #5, LBB1_526
LBB1_646:                               ; %cond.load1673
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1616]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v4 }[1], [x11]
	tbz	w9, #6, LBB1_527
LBB1_647:                               ; %cond.load1679
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1632]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v4 }[2], [x11]
	str	q3, [sp, #4160]                 ; 16-byte Spill
	str	q8, [sp, #4256]                 ; 16-byte Spill
	str	q24, [sp, #4240]                ; 16-byte Spill
	mov.16b	v3, v21
	mov.16b	v24, v18
	tbz	w9, #7, LBB1_528
LBB1_648:                               ; %cond.load1685
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1632]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	ld1.s	{ v4 }[3], [x9]
	fmov	w9, s23
	movi.2d	v21, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbz	w9, #0, LBB1_529
LBB1_649:                               ; %cond.load1692
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1520]                 ; 16-byte Reload
	fmov	x11, d1
	ldr	s21, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_530
LBB1_650:                               ; %cond.load1698
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1520]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v21 }[1], [x11]
	tbz	w9, #2, LBB1_531
LBB1_651:                               ; %cond.load1704
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1536]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v21 }[2], [x11]
	tbz	w9, #3, LBB1_532
LBB1_652:                               ; %cond.load1710
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1536]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v21 }[3], [x11]
	tbz	w9, #4, LBB1_533
LBB1_653:                               ; %cond.load1716
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1552]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v18 }[0], [x11]
	tbz	w9, #5, LBB1_534
LBB1_654:                               ; %cond.load1722
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1552]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v18 }[1], [x11]
	tbz	w9, #6, LBB1_535
LBB1_655:                               ; %cond.load1728
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1568]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v18 }[2], [x11]
	str	q15, [sp, #4208]                ; 16-byte Spill
	mov.16b	v8, v9
	str	q6, [sp, #3984]                 ; 16-byte Spill
	tbnz	w9, #7, LBB1_536
LBB1_656:                               ;   in Loop: Header=BB1_50 Depth=2
	ldr	q9, [sp, #4128]                 ; 16-byte Reload
	ldr	q15, [sp, #4144]                ; 16-byte Reload
	fmov	w9, s23
	movi.2d	v16, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbz	w9, #0, LBB1_658
LBB1_657:                               ; %cond.load1741
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1456]                 ; 16-byte Reload
	fmov	x11, d1
	ldr	s16, [x11]
LBB1_658:                               ; %else1745
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_909
; %bb.659:                              ; %else1751
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_910
LBB1_660:                               ; %else1757
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #3, LBB1_911
LBB1_661:                               ; %else1763
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #4, LBB1_912
LBB1_662:                               ; %else1769
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_913
LBB1_663:                               ; %else1775
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_914
LBB1_664:                               ; %else1781
                                        ;   in Loop: Header=BB1_50 Depth=2
	str	q30, [sp, #4368]                ; 16-byte Spill
	str	q26, [sp, #4352]                ; 16-byte Spill
	str	q20, [sp, #4432]                ; 16-byte Spill
	tbz	w9, #7, LBB1_666
LBB1_665:                               ; %cond.load1783
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1504]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	ld1.s	{ v6 }[3], [x9]
LBB1_666:                               ; %else1787
                                        ;   in Loop: Header=BB1_50 Depth=2
	mov	x11, #0                         ; =0x0
	mov	w9, #63790                      ; =0xf92e
	movk	w9, #15844, lsl #16
	dup.4s	v26, w9
	fmul.4s	v20, v19, v26
	ldr	q1, [sp, #4288]                 ; 16-byte Reload
	fmul.4s	v1, v1, v26
	mov	w9, #34304                      ; =0x8600
	movk	w9, #1, lsl #16
	add	x9, x4, x9
	ldp	q30, q19, [x9]
	str	q1, [sp, #3824]                 ; 16-byte Spill
	bit.16b	v19, v1, v0
	bit.16b	v30, v20, v2
	stp	q30, q19, [x9]
	ldr	q1, [sp, #4944]                 ; 16-byte Reload
	fmul.4s	v22, v1, v26
	ldr	q1, [sp, #4528]                 ; 16-byte Reload
	fmul.4s	v1, v1, v26
	ldr	x9, [sp, #472]                  ; 8-byte Reload
	ldp	q30, q19, [x9]
	str	q1, [sp, #3840]                 ; 16-byte Spill
	bit.16b	v19, v1, v0
	str	q22, [sp, #3808]                ; 16-byte Spill
	bit.16b	v30, v22, v2
	stp	q30, q19, [x9]
	ldr	q1, [sp, #4720]                 ; 16-byte Reload
	fmul.4s	v22, v1, v26
	ldr	q1, [sp, #4304]                 ; 16-byte Reload
	fmul.4s	v1, v1, v26
	ldr	x9, [sp, #464]                  ; 8-byte Reload
	ldp	q30, q19, [x9]
	str	q1, [sp, #3872]                 ; 16-byte Spill
	bit.16b	v19, v1, v0
	str	q22, [sp, #3856]                ; 16-byte Spill
	bit.16b	v30, v22, v2
	stp	q30, q19, [x9]
	fmul.4s	v22, v15, v26
	ldr	q1, [sp, #4544]                 ; 16-byte Reload
	fmul.4s	v1, v1, v26
	ldr	x9, [sp, #456]                  ; 8-byte Reload
	ldp	q30, q19, [x9]
	str	q1, [sp, #3904]                 ; 16-byte Spill
	bit.16b	v19, v1, v0
	str	q22, [sp, #3888]                ; 16-byte Spill
	bit.16b	v30, v22, v2
	stp	q30, q19, [x9]
	fmul.4s	v22, v9, v26
	fmul.4s	v1, v24, v26
	ldr	x9, [sp, #448]                  ; 8-byte Reload
	ldp	q30, q19, [x9]
	str	q1, [sp, #3952]                 ; 16-byte Spill
	bit.16b	v19, v1, v0
	str	q22, [sp, #3920]                ; 16-byte Spill
	bit.16b	v30, v22, v2
	stp	q30, q19, [x9]
	ldr	q1, [sp, #4240]                 ; 16-byte Reload
	fmul.4s	v19, v1, v26
	fmul.4s	v24, v3, v26
	cmp	x17, #128
	cset	w9, lo
	dup.4h	v30, w9
	ushll.4s	v30, v30, #0
	shl.4s	v30, v30, #31
	cmlt.4s	v30, v30, #0
	ldr	q1, [sp, #336]                  ; 16-byte Reload
	mov.16b	v22, v30
	bsl.16b	v22, v24, v1
	mov.16b	v3, v30
	bsl.16b	v3, v19, v1
	ldr	x12, [sp, #440]                 ; 8-byte Reload
	ldp	q24, q19, [x12]
	str	q3, [sp, #4000]                 ; 16-byte Spill
	bit.16b	v19, v3, v0
	str	q22, [sp, #3968]                ; 16-byte Spill
	bit.16b	v24, v22, v2
	stp	q24, q19, [x12]
	ldr	q3, [sp, #4256]                 ; 16-byte Reload
	fmul.4s	v19, v3, v26
	ldr	q3, [sp, #4272]                 ; 16-byte Reload
	fmul.4s	v24, v3, v26
	mov.16b	v22, v30
	bsl.16b	v22, v24, v1
	mov.16b	v3, v30
	bsl.16b	v3, v19, v1
	ldr	x12, [sp, #432]                 ; 8-byte Reload
	ldp	q24, q19, [x12]
	str	q3, [sp, #4032]                 ; 16-byte Spill
	bit.16b	v19, v3, v0
	str	q22, [sp, #4016]                ; 16-byte Spill
	bit.16b	v24, v22, v2
	stp	q24, q19, [x12]
	ldr	q3, [sp, #4224]                 ; 16-byte Reload
	fmul.4s	v19, v3, v26
	fmul.4s	v24, v8, v26
	mov.16b	v22, v30
	bsl.16b	v22, v24, v1
	mov.16b	v3, v30
	bsl.16b	v3, v19, v1
	ldr	x12, [sp, #424]                 ; 8-byte Reload
	ldp	q24, q19, [x12]
	str	q3, [sp, #4064]                 ; 16-byte Spill
	bit.16b	v19, v3, v0
	str	q22, [sp, #4048]                ; 16-byte Spill
	bit.16b	v24, v22, v2
	stp	q24, q19, [x12]
	ldr	q3, [sp, #4960]                 ; 16-byte Reload
	fmul.4s	v19, v3, v26
	ldr	q3, [sp, #4208]                 ; 16-byte Reload
	fmul.4s	v24, v3, v26
	mov.16b	v22, v30
	bsl.16b	v22, v24, v1
	mov.16b	v3, v30
	bsl.16b	v3, v19, v1
	ldr	x12, [sp, #416]                 ; 8-byte Reload
	ldp	q24, q19, [x12]
	str	q3, [sp, #4096]                 ; 16-byte Spill
	bit.16b	v19, v3, v0
	str	q22, [sp, #4080]                ; 16-byte Spill
	bit.16b	v24, v22, v2
	stp	q24, q19, [x12]
	ldr	q3, [sp, #4192]                 ; 16-byte Reload
	fmul.4s	v19, v3, v26
	ldr	q3, [sp, #4160]                 ; 16-byte Reload
	fmul.4s	v24, v3, v26
	mov.16b	v3, v30
	bsl.16b	v3, v24, v1
	mov.16b	v22, v30
	bsl.16b	v22, v19, v1
	ldr	x12, [sp, #408]                 ; 8-byte Reload
	ldp	q19, q24, [x12]
	str	q22, [sp, #4112]                ; 16-byte Spill
	bit.16b	v19, v22, v2
	str	q3, [sp, #4128]                 ; 16-byte Spill
	bit.16b	v24, v3, v0
	stp	q19, q24, [x12]
	ldr	q3, [sp, #3984]                 ; 16-byte Reload
	fmul.4s	v19, v3, v26
	fmul.4s	v24, v28, v26
	mov.16b	v3, v30
	bsl.16b	v3, v24, v1
	mov.16b	v22, v30
	bsl.16b	v22, v19, v1
	ldr	x12, [sp, #400]                 ; 8-byte Reload
	ldp	q19, q24, [x12]
	str	q22, [sp, #4144]                ; 16-byte Spill
	bit.16b	v19, v22, v2
	str	q3, [sp, #4160]                 ; 16-byte Spill
	bit.16b	v24, v3, v0
	stp	q19, q24, [x12]
	ldr	q3, [sp, #3936]                 ; 16-byte Reload
	fmul.4s	v19, v3, v26
	fmul.4s	v24, v11, v26
	fmul.4s	v27, v27, v26
	fmul.4s	v7, v7, v26
	fmul.4s	v4, v4, v26
	fmul.4s	v28, v29, v26
	fmul.4s	v21, v21, v26
	fmul.4s	v18, v18, v26
	fmul.4s	v16, v16, v26
	fmul.4s	v6, v6, v26
	mov.16b	v3, v30
	bsl.16b	v3, v24, v1
	mov.16b	v22, v30
	bsl.16b	v22, v19, v1
	ldr	x12, [sp, #392]                 ; 8-byte Reload
	ldp	q19, q24, [x12]
	str	q22, [sp, #4176]                ; 16-byte Spill
	bit.16b	v19, v22, v2
	str	q3, [sp, #4192]                 ; 16-byte Spill
	bit.16b	v24, v3, v0
	stp	q19, q24, [x12]
	mov.16b	v3, v30
	bsl.16b	v3, v7, v1
	mov.16b	v19, v30
	bsl.16b	v19, v27, v1
	ldr	x12, [sp, #384]                 ; 8-byte Reload
	ldr	q7, [x12]
	str	q19, [sp, #4208]                ; 16-byte Spill
	bit.16b	v7, v19, v2
	ldr	q19, [x12, #16]
	str	q3, [sp, #4224]                 ; 16-byte Spill
	bit.16b	v19, v3, v0
	stp	q7, q19, [x12]
	mov.16b	v22, v30
	bsl.16b	v22, v28, v1
	mov.16b	v19, v30
	bsl.16b	v19, v4, v1
	mov.16b	v7, v30
	bsl.16b	v7, v18, v1
	mov.16b	v18, v30
	bsl.16b	v18, v21, v1
	mov.16b	v3, v30
	bsl.16b	v3, v6, v1
	bit.16b	v1, v16, v30
	ldr	x12, [sp, #376]                 ; 8-byte Reload
	ldp	q6, q4, [x12]
	str	q19, [sp, #4256]                ; 16-byte Spill
	bit.16b	v4, v19, v0
	str	q22, [sp, #4240]                ; 16-byte Spill
	bit.16b	v6, v22, v2
	stp	q6, q4, [x12]
	ldr	x12, [sp, #368]                 ; 8-byte Reload
	ldp	q4, q6, [x12]
	str	q18, [sp, #4272]                ; 16-byte Spill
	bit.16b	v4, v18, v2
	str	q7, [sp, #4288]                 ; 16-byte Spill
	bit.16b	v6, v7, v0
	stp	q4, q6, [x12]
	ldr	x12, [sp, #360]                 ; 8-byte Reload
	ldp	q4, q6, [x12]
	str	q1, [sp, #4304]                 ; 16-byte Spill
	bit.16b	v4, v1, v2
	str	q3, [sp, #4528]                 ; 16-byte Spill
	bit.16b	v6, v3, v0
	stp	q4, q6, [x12]
	mvni.4s	v1, #127, msl #16
	bit.16b	v12, v1, v0
	mvni.4s	v3, #127, msl #16
	bit.16b	v10, v1, v2
	dup.8b	v1, w9
	str	d1, [sp, #4544]                 ; 8-byte Spill
LBB1_667:                               ; %direct.true286.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x9, x14, x11
	ldp	q4, q6, [x9]
	and.16b	v6, v0, v6
	and.16b	v4, v2, v4
	fmaxnm.4s	v4, v10, v4
	fmaxnm.4s	v6, v12, v6
	bit.16b	v12, v6, v0
	bit.16b	v10, v4, v2
	add	x11, x11, #32
	cmp	x11, #512
	b.ne	LBB1_667
; %bb.668:                              ; %direct.false287.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3728]                 ; 16-byte Reload
	ldr	q4, [sp, #3616]                 ; 16-byte Reload
	cmhi.4s	v6, v4, v1
	uzp1.8h	v4, v6, v0
	ldr	q1, [sp, #4416]                 ; 16-byte Reload
	and.16b	v4, v4, v1
	addv.8h	h7, v4
	fmov	w9, s7
	ldr	q1, [sp, #4736]                 ; 16-byte Reload
	fmaxnm.4s	v1, v1, v10
	str	q1, [sp, #4720]                 ; 16-byte Spill
	fsub.4s	v4, v20, v1
	and.16b	v19, v6, v4
	mov	w11, #-1026555904               ; =0xc2d00000
	dup.4s	v11, w11
	fcmge.4s	v4, v19, v11
	mov	w11, #1120403456                ; =0x42c80000
	dup.4s	v21, w11
	fcmge.4s	v16, v21, v19
	and.16b	v4, v4, v16
	mov	w11, #43579                     ; =0xaa3b
	movk	w11, #16312, lsl #16
	dup.4s	v29, w11
	and.16b	v4, v4, v19
	fmul.4s	v16, v4, v29
	mvni.4s	v1, #128, lsl #24
	movi.4s	v18, #75, lsl #24
	bif.16b	v18, v16, v1
	fadd.4s	v16, v16, v18
	fsub.4s	v16, v16, v18
	fcvtzs.4s	v30, v16
	scvtf.4s	v20, v30
	mov	w11, #29184                     ; =0x7200
	movk	w11, #16177, lsl #16
	dup.4s	v16, w11
	fmul.4s	v24, v20, v16
	mov	w11, #48782                     ; =0xbe8e
	movk	w11, #13759, lsl #16
	dup.4s	v18, w11
	fsub.4s	v4, v4, v24
	fmul.4s	v20, v20, v18
	fsub.4s	v4, v4, v20
	mov	w11, #11226                     ; =0x2bda
	movk	w11, #14672, lsl #16
	dup.4s	v27, w11
	fmul.4s	v20, v4, v27
	mov	w11, #38601                     ; =0x96c9
	movk	w11, #15030, lsl #16
	dup.4s	v28, w11
	fadd.4s	v20, v20, v28
	fmul.4s	v20, v4, v20
	mov	w11, #34982                     ; =0x88a6
	movk	w11, #15368, lsl #16
	dup.4s	v26, w11
	fadd.4s	v20, v20, v26
	fmul.4s	v24, v4, v20
	mov	w11, #43642                     ; =0xaa7a
	movk	w11, #15658, lsl #16
	dup.4s	v20, w11
	fadd.4s	v24, v24, v20
	fmul.4s	v22, v4, v24
	mov	w11, #43691                     ; =0xaaab
	movk	w11, #15914, lsl #16
	dup.4s	v1, w11
	str	q1, [sp, #4944]                 ; 16-byte Spill
	fadd.4s	v22, v22, v1
	fmul.4s	v22, v4, v22
	movi.4s	v1, #63, lsl #24
	fadd.4s	v22, v22, v1
	fmul.4s	v1, v4, v4
	fmul.4s	v1, v1, v22
	fadd.4s	v1, v4, v1
	fmov.4s	v15, #1.00000000
	fadd.4s	v1, v1, v15
	sshr.4s	v4, v30, #1
	shl.4s	v22, v4, #23
	add.4s	v22, v22, v15
	fmul.4s	v1, v1, v22
	sub.4s	v4, v30, v4
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v15
	fmul.4s	v1, v1, v4
	fcmgt.4s	v4, v11, v19
	bic.16b	v1, v1, v4
	fcmgt.4s	v22, v19, v21
	fneg.4s	v3, v3
	str	q3, [sp, #4960]                 ; 16-byte Spill
	bit.16b	v1, v3, v22
	fcmeq.4s	v19, v19, v19
	ldr	q3, [sp, #4976]                 ; 16-byte Reload
	bsl.16b	v19, v1, v3
	tbnz	w9, #0, LBB1_915
; %bb.669:                              ; %else1793
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_916
LBB1_670:                               ; %else1797
                                        ;   in Loop: Header=BB1_50 Depth=2
	fmov.4s	v3, #1.00000000
	ldr	q4, [sp, #4720]                 ; 16-byte Reload
	tbnz	w9, #2, LBB1_917
LBB1_671:                               ; %else1801
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #3, LBB1_673
LBB1_672:                               ; %cond.store1802
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #288]                  ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[3], [x11]
LBB1_673:                               ; %else1805
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #4752]                 ; 16-byte Reload
	fmaxnm.4s	v24, v1, v12
	ldr	q1, [sp, #3824]                 ; 16-byte Reload
	fsub.4s	v1, v1, v24
	and.16b	v1, v0, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	mvni.4s	v9, #128, lsl #24
	bif.16b	v30, v22, v9
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	movi.4s	v8, #63, lsl #24
	fadd.4s	v30, v30, v8
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bif.16b	v19, v22, v1
	tbnz	w9, #4, LBB1_918
; %bb.674:                              ; %else1809
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_919
LBB1_675:                               ; %else1813
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_920
LBB1_676:                               ; %else1817
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #7, LBB1_678
LBB1_677:                               ; %cond.store1818
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #320]                  ; 16-byte Reload
	mov.d	x9, v1[1]
	st1.s	{ v19 }[3], [x9]
LBB1_678:                               ; %else1821
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3808]                 ; 16-byte Reload
	fsub.4s	v1, v1, v4
	and.16b	v1, v6, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	bif.16b	v30, v22, v9
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v8
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bif.16b	v19, v22, v1
	fmov	w9, s7
	tbnz	w9, #0, LBB1_921
; %bb.679:                              ; %else1826
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_922
LBB1_680:                               ; %else1830
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_923
LBB1_681:                               ; %else1834
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #3, LBB1_683
LBB1_682:                               ; %cond.store1835
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1408]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[3], [x11]
LBB1_683:                               ; %else1838
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3840]                 ; 16-byte Reload
	fsub.4s	v1, v1, v24
	and.16b	v1, v0, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	bif.16b	v30, v22, v9
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v8
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bif.16b	v19, v22, v1
	tbnz	w9, #4, LBB1_924
; %bb.684:                              ; %else1842
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_925
LBB1_685:                               ; %else1846
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_926
LBB1_686:                               ; %else1850
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #7, LBB1_688
LBB1_687:                               ; %cond.store1851
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1440]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	st1.s	{ v19 }[3], [x9]
LBB1_688:                               ; %else1854
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3856]                 ; 16-byte Reload
	fsub.4s	v1, v1, v4
	and.16b	v1, v6, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	bif.16b	v30, v22, v9
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v8
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bif.16b	v19, v22, v1
	fmov	w9, s7
	tbnz	w9, #0, LBB1_927
; %bb.689:                              ; %else1859
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_928
LBB1_690:                               ; %else1863
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_929
LBB1_691:                               ; %else1867
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #3, LBB1_693
LBB1_692:                               ; %cond.store1868
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1344]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[3], [x11]
LBB1_693:                               ; %else1871
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3872]                 ; 16-byte Reload
	fsub.4s	v1, v1, v24
	and.16b	v1, v0, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	bif.16b	v30, v22, v9
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v8
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bif.16b	v19, v22, v1
	tbnz	w9, #4, LBB1_930
; %bb.694:                              ; %else1875
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_931
LBB1_695:                               ; %else1879
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_932
LBB1_696:                               ; %else1883
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #7, LBB1_698
LBB1_697:                               ; %cond.store1884
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1376]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	st1.s	{ v19 }[3], [x9]
LBB1_698:                               ; %else1887
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3888]                 ; 16-byte Reload
	fsub.4s	v1, v1, v4
	and.16b	v1, v6, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	bif.16b	v30, v22, v9
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v8
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bif.16b	v19, v22, v1
	fmov	w9, s7
	tbnz	w9, #0, LBB1_933
; %bb.699:                              ; %else1892
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_934
LBB1_700:                               ; %else1896
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_935
LBB1_701:                               ; %else1900
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #3, LBB1_703
LBB1_702:                               ; %cond.store1901
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1280]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[3], [x11]
LBB1_703:                               ; %else1904
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3904]                 ; 16-byte Reload
	fsub.4s	v1, v1, v24
	and.16b	v1, v0, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	bif.16b	v30, v22, v9
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v8
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bif.16b	v19, v22, v1
	tbnz	w9, #4, LBB1_936
; %bb.704:                              ; %else1908
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_937
LBB1_705:                               ; %else1912
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_938
LBB1_706:                               ; %else1916
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #7, LBB1_708
LBB1_707:                               ; %cond.store1917
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1312]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	st1.s	{ v19 }[3], [x9]
LBB1_708:                               ; %else1920
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3920]                 ; 16-byte Reload
	fsub.4s	v1, v1, v4
	and.16b	v1, v6, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	bif.16b	v30, v22, v9
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v8
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bif.16b	v19, v22, v1
	fmov	w9, s7
	tbnz	w9, #0, LBB1_939
; %bb.709:                              ; %else1925
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_940
LBB1_710:                               ; %else1929
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_941
LBB1_711:                               ; %else1933
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #3, LBB1_713
LBB1_712:                               ; %cond.store1934
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1216]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[3], [x11]
LBB1_713:                               ; %else1937
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3952]                 ; 16-byte Reload
	fsub.4s	v1, v1, v24
	and.16b	v1, v0, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	bif.16b	v30, v22, v9
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v8
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bif.16b	v19, v22, v1
	tbnz	w9, #4, LBB1_942
; %bb.714:                              ; %else1941
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_943
LBB1_715:                               ; %else1945
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_944
LBB1_716:                               ; %else1949
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #7, LBB1_718
LBB1_717:                               ; %cond.store1950
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1248]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	st1.s	{ v19 }[3], [x9]
LBB1_718:                               ; %else1953
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #3968]                 ; 16-byte Reload
	fsub.4s	v1, v1, v4
	and.16b	v1, v6, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	bif.16b	v30, v22, v9
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v8
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bsl.16b	v1, v19, v22
	ldr	d19, [sp, #4544]                ; 8-byte Reload
	zip1.8b	v19, v19, v0
	ushll.4s	v19, v19, #0
	shl.4s	v19, v19, #31
	cmlt.4s	v19, v19, #0
	mov.16b	v9, v19
	and.16b	v19, v19, v1
	fmov	w9, s7
	tbnz	w9, #0, LBB1_945
; %bb.719:                              ; %else1958
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_946
LBB1_720:                               ; %else1962
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_947
LBB1_721:                               ; %else1966
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #3, LBB1_723
LBB1_722:                               ; %cond.store1967
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1152]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[3], [x11]
LBB1_723:                               ; %else1970
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #4000]                 ; 16-byte Reload
	fsub.4s	v1, v1, v24
	and.16b	v1, v0, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	mvni.4s	v15, #128, lsl #24
	bif.16b	v30, v22, v15
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v8
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bsl.16b	v1, v19, v22
	ldr	d19, [sp, #4544]                ; 8-byte Reload
	zip2.8b	v19, v19, v0
	ushll.4s	v19, v19, #0
	shl.4s	v19, v19, #31
	cmlt.4s	v19, v19, #0
	mov.16b	v8, v19
	and.16b	v19, v19, v1
	tbnz	w9, #4, LBB1_948
; %bb.724:                              ; %else1974
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_949
LBB1_725:                               ; %else1978
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_950
LBB1_726:                               ; %else1982
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #7, LBB1_728
LBB1_727:                               ; %cond.store1983
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1184]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	st1.s	{ v19 }[3], [x9]
LBB1_728:                               ; %else1986
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #4016]                 ; 16-byte Reload
	fsub.4s	v1, v1, v4
	and.16b	v1, v6, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	mvni.4s	v15, #128, lsl #24
	bif.16b	v30, v22, v15
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	movi.4s	v15, #63, lsl #24
	fadd.4s	v30, v30, v15
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bsl.16b	v1, v19, v22
	and.16b	v19, v9, v1
	fmov	w9, s7
	tbnz	w9, #0, LBB1_951
; %bb.729:                              ; %else1991
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_952
LBB1_730:                               ; %else1995
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_953
LBB1_731:                               ; %else1999
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #3, LBB1_733
LBB1_732:                               ; %cond.store2000
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1088]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[3], [x11]
LBB1_733:                               ; %else2003
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #4032]                 ; 16-byte Reload
	fsub.4s	v1, v1, v24
	and.16b	v1, v0, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	mvni.4s	v15, #128, lsl #24
	bif.16b	v30, v22, v15
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	movi.4s	v15, #63, lsl #24
	fadd.4s	v30, v30, v15
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bsl.16b	v1, v19, v22
	and.16b	v19, v8, v1
	tbnz	w9, #4, LBB1_954
; %bb.734:                              ; %else2007
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_955
LBB1_735:                               ; %else2011
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_956
LBB1_736:                               ; %else2015
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #7, LBB1_738
LBB1_737:                               ; %cond.store2016
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1120]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	st1.s	{ v19 }[3], [x9]
LBB1_738:                               ; %else2019
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #4048]                 ; 16-byte Reload
	fsub.4s	v1, v1, v4
	and.16b	v1, v6, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	mvni.4s	v15, #128, lsl #24
	bif.16b	v30, v22, v15
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	movi.4s	v15, #63, lsl #24
	fadd.4s	v30, v30, v15
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bsl.16b	v1, v19, v22
	and.16b	v19, v9, v1
	fmov	w9, s7
	tbnz	w9, #0, LBB1_957
; %bb.739:                              ; %else2024
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_958
LBB1_740:                               ; %else2028
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_959
LBB1_741:                               ; %else2032
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #3, LBB1_743
LBB1_742:                               ; %cond.store2033
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1024]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[3], [x11]
LBB1_743:                               ; %else2036
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #4064]                 ; 16-byte Reload
	fsub.4s	v1, v1, v24
	and.16b	v1, v0, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	mvni.4s	v15, #128, lsl #24
	bif.16b	v30, v22, v15
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	movi.4s	v15, #63, lsl #24
	fadd.4s	v30, v30, v15
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bsl.16b	v1, v19, v22
	and.16b	v19, v8, v1
	tbnz	w9, #4, LBB1_960
; %bb.744:                              ; %else2040
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_961
LBB1_745:                               ; %else2044
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_962
LBB1_746:                               ; %else2048
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #7, LBB1_748
LBB1_747:                               ; %cond.store2049
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1056]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	st1.s	{ v19 }[3], [x9]
LBB1_748:                               ; %else2052
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #4080]                 ; 16-byte Reload
	fsub.4s	v1, v1, v4
	and.16b	v1, v6, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	mvni.4s	v15, #128, lsl #24
	bif.16b	v30, v22, v15
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	movi.4s	v15, #63, lsl #24
	fadd.4s	v30, v30, v15
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bsl.16b	v1, v19, v22
	and.16b	v19, v9, v1
	fmov	w9, s7
	tbnz	w9, #0, LBB1_963
; %bb.749:                              ; %else2057
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_964
LBB1_750:                               ; %else2061
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_965
LBB1_751:                               ; %else2065
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #3, LBB1_753
LBB1_752:                               ; %cond.store2066
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #960]                  ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[3], [x11]
LBB1_753:                               ; %else2069
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #4096]                 ; 16-byte Reload
	fsub.4s	v1, v1, v24
	and.16b	v1, v0, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	mvni.4s	v15, #128, lsl #24
	bif.16b	v30, v22, v15
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	movi.4s	v15, #63, lsl #24
	fadd.4s	v30, v30, v15
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bsl.16b	v1, v19, v22
	and.16b	v19, v8, v1
	tbnz	w9, #4, LBB1_966
; %bb.754:                              ; %else2073
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_967
LBB1_755:                               ; %else2077
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_968
LBB1_756:                               ; %else2081
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #7, LBB1_758
LBB1_757:                               ; %cond.store2082
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #992]                  ; 16-byte Reload
	mov.d	x9, v1[1]
	st1.s	{ v19 }[3], [x9]
LBB1_758:                               ; %else2085
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #4112]                 ; 16-byte Reload
	fsub.4s	v1, v1, v4
	and.16b	v1, v6, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	mvni.4s	v15, #128, lsl #24
	bif.16b	v30, v22, v15
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	movi.4s	v15, #63, lsl #24
	fadd.4s	v30, v30, v15
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bsl.16b	v1, v19, v22
	and.16b	v19, v9, v1
	fmov	w9, s7
	tbnz	w9, #0, LBB1_969
; %bb.759:                              ; %else2090
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_970
LBB1_760:                               ; %else2094
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_971
LBB1_761:                               ; %else2098
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #3, LBB1_763
LBB1_762:                               ; %cond.store2099
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #896]                  ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[3], [x11]
LBB1_763:                               ; %else2102
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #4128]                 ; 16-byte Reload
	fsub.4s	v1, v1, v24
	and.16b	v1, v0, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	mvni.4s	v15, #128, lsl #24
	bif.16b	v30, v22, v15
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	movi.4s	v15, #63, lsl #24
	fadd.4s	v30, v30, v15
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bsl.16b	v1, v19, v22
	and.16b	v19, v8, v1
	tbnz	w9, #4, LBB1_972
; %bb.764:                              ; %else2106
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_973
LBB1_765:                               ; %else2110
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_974
LBB1_766:                               ; %else2114
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #7, LBB1_768
LBB1_767:                               ; %cond.store2115
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #928]                  ; 16-byte Reload
	mov.d	x9, v1[1]
	st1.s	{ v19 }[3], [x9]
LBB1_768:                               ; %else2118
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #4144]                 ; 16-byte Reload
	fsub.4s	v1, v1, v4
	and.16b	v1, v6, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	mvni.4s	v15, #128, lsl #24
	bif.16b	v30, v22, v15
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	movi.4s	v15, #63, lsl #24
	fadd.4s	v30, v30, v15
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bsl.16b	v1, v19, v22
	and.16b	v19, v9, v1
	fmov	w9, s7
	tbnz	w9, #0, LBB1_975
; %bb.769:                              ; %else2123
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_976
LBB1_770:                               ; %else2127
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_977
LBB1_771:                               ; %else2131
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #3, LBB1_773
LBB1_772:                               ; %cond.store2132
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #832]                  ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[3], [x11]
LBB1_773:                               ; %else2135
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #4160]                 ; 16-byte Reload
	fsub.4s	v1, v1, v24
	and.16b	v1, v0, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	mvni.4s	v15, #128, lsl #24
	bif.16b	v30, v22, v15
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	movi.4s	v15, #63, lsl #24
	fadd.4s	v30, v30, v15
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bsl.16b	v1, v19, v22
	and.16b	v19, v8, v1
	tbnz	w9, #4, LBB1_978
; %bb.774:                              ; %else2139
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_979
LBB1_775:                               ; %else2143
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_980
LBB1_776:                               ; %else2147
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #7, LBB1_778
LBB1_777:                               ; %cond.store2148
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #864]                  ; 16-byte Reload
	mov.d	x9, v1[1]
	st1.s	{ v19 }[3], [x9]
LBB1_778:                               ; %else2151
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #4176]                 ; 16-byte Reload
	fsub.4s	v1, v1, v4
	and.16b	v1, v6, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	mvni.4s	v15, #128, lsl #24
	bif.16b	v30, v22, v15
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	movi.4s	v15, #63, lsl #24
	fadd.4s	v30, v30, v15
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bsl.16b	v1, v19, v22
	and.16b	v19, v9, v1
	fmov	w9, s7
	tbnz	w9, #0, LBB1_981
; %bb.779:                              ; %else2156
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_982
LBB1_780:                               ; %else2160
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_983
LBB1_781:                               ; %else2164
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #3, LBB1_783
LBB1_782:                               ; %cond.store2165
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #768]                  ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[3], [x11]
LBB1_783:                               ; %else2168
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #4192]                 ; 16-byte Reload
	fsub.4s	v1, v1, v24
	and.16b	v1, v0, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	mvni.4s	v15, #128, lsl #24
	bif.16b	v30, v22, v15
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	movi.4s	v15, #63, lsl #24
	fadd.4s	v30, v30, v15
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bsl.16b	v1, v19, v22
	and.16b	v19, v8, v1
	tbnz	w9, #4, LBB1_984
; %bb.784:                              ; %else2172
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_985
LBB1_785:                               ; %else2176
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_986
LBB1_786:                               ; %else2180
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #7, LBB1_788
LBB1_787:                               ; %cond.store2181
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #800]                  ; 16-byte Reload
	mov.d	x9, v1[1]
	st1.s	{ v19 }[3], [x9]
LBB1_788:                               ; %else2184
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #4208]                 ; 16-byte Reload
	fsub.4s	v1, v1, v4
	and.16b	v1, v6, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	mvni.4s	v15, #128, lsl #24
	bif.16b	v30, v22, v15
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	movi.4s	v15, #63, lsl #24
	fadd.4s	v30, v30, v15
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bsl.16b	v1, v19, v22
	and.16b	v19, v9, v1
	fmov	w9, s7
	tbnz	w9, #0, LBB1_987
; %bb.789:                              ; %else2189
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_988
LBB1_790:                               ; %else2193
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_989
LBB1_791:                               ; %else2197
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #3, LBB1_793
LBB1_792:                               ; %cond.store2198
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #704]                  ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[3], [x11]
LBB1_793:                               ; %else2201
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #4224]                 ; 16-byte Reload
	fsub.4s	v1, v1, v24
	and.16b	v1, v0, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	mvni.4s	v15, #128, lsl #24
	bif.16b	v30, v22, v15
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	movi.4s	v15, #63, lsl #24
	fadd.4s	v30, v30, v15
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bsl.16b	v1, v19, v22
	and.16b	v19, v8, v1
	tbnz	w9, #4, LBB1_990
; %bb.794:                              ; %else2205
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_991
LBB1_795:                               ; %else2209
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_992
LBB1_796:                               ; %else2213
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #7, LBB1_798
LBB1_797:                               ; %cond.store2214
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #736]                  ; 16-byte Reload
	mov.d	x9, v1[1]
	st1.s	{ v19 }[3], [x9]
LBB1_798:                               ; %else2217
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #4240]                 ; 16-byte Reload
	fsub.4s	v1, v1, v4
	and.16b	v1, v6, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	mvni.4s	v15, #128, lsl #24
	bif.16b	v30, v22, v15
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	movi.4s	v15, #63, lsl #24
	fadd.4s	v30, v30, v15
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bsl.16b	v1, v19, v22
	and.16b	v19, v9, v1
	fmov	w9, s7
	tbnz	w9, #0, LBB1_993
; %bb.799:                              ; %else2222
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_994
LBB1_800:                               ; %else2226
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_995
LBB1_801:                               ; %else2230
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #3, LBB1_803
LBB1_802:                               ; %cond.store2231
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #640]                  ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[3], [x11]
LBB1_803:                               ; %else2234
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #4256]                 ; 16-byte Reload
	fsub.4s	v1, v1, v24
	and.16b	v1, v0, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	mvni.4s	v15, #128, lsl #24
	bif.16b	v30, v22, v15
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	movi.4s	v15, #63, lsl #24
	fadd.4s	v30, v30, v15
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bsl.16b	v1, v19, v22
	and.16b	v19, v8, v1
	tbnz	w9, #4, LBB1_996
; %bb.804:                              ; %else2238
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_997
LBB1_805:                               ; %else2242
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_998
LBB1_806:                               ; %else2246
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #7, LBB1_808
LBB1_807:                               ; %cond.store2247
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #672]                  ; 16-byte Reload
	mov.d	x9, v1[1]
	st1.s	{ v19 }[3], [x9]
LBB1_808:                               ; %else2250
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #4272]                 ; 16-byte Reload
	fsub.4s	v1, v1, v4
	and.16b	v1, v6, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	mvni.4s	v15, #128, lsl #24
	bif.16b	v30, v22, v15
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	movi.4s	v15, #63, lsl #24
	fadd.4s	v30, v30, v15
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bsl.16b	v1, v19, v22
	and.16b	v19, v9, v1
	fmov	w9, s7
	tbnz	w9, #0, LBB1_999
; %bb.809:                              ; %else2255
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_1000
LBB1_810:                               ; %else2259
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_1001
LBB1_811:                               ; %else2263
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #3, LBB1_813
LBB1_812:                               ; %cond.store2264
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #576]                  ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[3], [x11]
LBB1_813:                               ; %else2267
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #4288]                 ; 16-byte Reload
	fsub.4s	v1, v1, v24
	and.16b	v1, v0, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v30, #75, lsl #24
	mvni.4s	v15, #128, lsl #24
	bif.16b	v30, v22, v15
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q15, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v19, v30
	movi.4s	v15, #63, lsl #24
	fadd.4s	v30, v30, v15
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	bit.16b	v19, v30, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bsl.16b	v1, v19, v22
	and.16b	v19, v8, v1
	tbnz	w9, #4, LBB1_1002
; %bb.814:                              ; %else2271
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #5, LBB1_1003
LBB1_815:                               ; %else2275
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #6, LBB1_1004
LBB1_816:                               ; %else2279
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #7, LBB1_818
LBB1_817:                               ; %cond.store2280
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #608]                  ; 16-byte Reload
	mov.d	x9, v1[1]
	st1.s	{ v19 }[3], [x9]
LBB1_818:                               ; %else2283
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #4304]                 ; 16-byte Reload
	fsub.4s	v1, v1, v4
	and.16b	v1, v6, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v4, #75, lsl #24
	mvni.4s	v30, #128, lsl #24
	bsl.16b	v30, v4, v22
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v15, v30, v16
	fsub.4s	v19, v19, v15
	fmul.4s	v30, v30, v18
	fsub.4s	v19, v19, v30
	fmul.4s	v30, v19, v27
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v26
	fmul.4s	v30, v19, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v19, v30
	ldr	q4, [sp, #4944]                 ; 16-byte Reload
	fadd.4s	v30, v30, v4
	fmul.4s	v30, v19, v30
	movi.4s	v4, #63, lsl #24
	fadd.4s	v30, v30, v4
	fmul.4s	v15, v19, v19
	fmul.4s	v30, v15, v30
	fadd.4s	v19, v19, v30
	fadd.4s	v19, v19, v3
	sshr.4s	v30, v22, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v3
	fmul.4s	v19, v19, v15
	sub.4s	v22, v22, v30
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v3
	fmul.4s	v19, v19, v22
	fcmgt.4s	v22, v11, v1
	bic.16b	v19, v19, v22
	fcmgt.4s	v22, v1, v21
	ldr	q4, [sp, #4960]                 ; 16-byte Reload
	bit.16b	v19, v4, v22
	fcmeq.4s	v1, v1, v1
	ldr	q22, [sp, #4976]                ; 16-byte Reload
	bsl.16b	v1, v19, v22
	and.16b	v19, v9, v1
	fmov	w9, s7
	tbnz	w9, #0, LBB1_1005
; %bb.819:                              ; %else2288
                                        ;   in Loop: Header=BB1_50 Depth=2
	and	w9, w9, #0xff
	ldr	q15, [sp, #4496]                ; 16-byte Reload
	tbnz	w9, #1, LBB1_1006
LBB1_820:                               ; %else2292
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbnz	w9, #2, LBB1_1007
LBB1_821:                               ; %else2296
                                        ;   in Loop: Header=BB1_50 Depth=2
	tbz	w9, #3, LBB1_823
LBB1_822:                               ; %cond.store2297
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #512]                  ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[3], [x11]
LBB1_823:                               ; %else2300
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #4528]                 ; 16-byte Reload
	fsub.4s	v1, v1, v24
	and.16b	v1, v0, v1
	fcmge.4s	v19, v1, v11
	fcmge.4s	v22, v21, v1
	and.16b	v19, v19, v22
	and.16b	v19, v19, v1
	fmul.4s	v22, v19, v29
	movi.4s	v4, #75, lsl #24
	mvni.4s	v30, #128, lsl #24
	bsl.16b	v30, v4, v22
	fadd.4s	v22, v22, v30
	fsub.4s	v22, v22, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v16, v30, v16
	fsub.4s	v16, v19, v16
	fmul.4s	v18, v30, v18
	fsub.4s	v16, v16, v18
	fmul.4s	v18, v16, v27
	fadd.4s	v18, v18, v28
	fmul.4s	v18, v16, v18
	fadd.4s	v18, v18, v26
	fmul.4s	v18, v16, v18
	fadd.4s	v18, v18, v20
	fmul.4s	v18, v16, v18
	ldr	q4, [sp, #4944]                 ; 16-byte Reload
	fadd.4s	v18, v18, v4
	fmul.4s	v18, v16, v18
	movi.4s	v4, #63, lsl #24
	fadd.4s	v18, v18, v4
	fmul.4s	v19, v16, v16
	fmul.4s	v18, v19, v18
	fadd.4s	v16, v16, v18
	fadd.4s	v16, v16, v3
	sshr.4s	v18, v22, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v3
	fmul.4s	v16, v16, v19
	sub.4s	v18, v22, v18
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v3
	fmul.4s	v16, v16, v18
	fcmgt.4s	v18, v11, v1
	bic.16b	v16, v16, v18
	fcmgt.4s	v18, v1, v21
	ldr	q3, [sp, #4960]                 ; 16-byte Reload
	bit.16b	v16, v3, v18
	fcmeq.4s	v1, v1, v1
	ldr	q3, [sp, #4976]                 ; 16-byte Reload
	bsl.16b	v1, v16, v3
	and.16b	v16, v8, v1
	tbnz	w9, #4, LBB1_1008
; %bb.824:                              ; %else2304
                                        ;   in Loop: Header=BB1_50 Depth=2
	str	q24, [sp, #4544]                ; 16-byte Spill
	ldr	q18, [sp, #3520]                ; 16-byte Reload
	ldr	q22, [sp, #4656]                ; 16-byte Reload
	ldr	q8, [sp, #4640]                 ; 16-byte Reload
	tbnz	w9, #5, LBB1_1009
LBB1_825:                               ; %else2308
                                        ;   in Loop: Header=BB1_50 Depth=2
	mov.16b	v24, v23
	tbnz	w9, #6, LBB1_1010
LBB1_826:                               ; %else2312
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q23, [sp, #4592]                ; 16-byte Reload
	tbz	w9, #7, LBB1_828
LBB1_827:                               ; %cond.store2313
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #544]                  ; 16-byte Reload
	mov.d	x9, v1[1]
	st1.s	{ v16 }[3], [x9]
LBB1_828:                               ; %else2316
                                        ;   in Loop: Header=BB1_50 Depth=2
	mov	x11, #0                         ; =0x0
	sshll.2d	v1, v0, #0
	sshll.2d	v16, v6, #0
	sshll2.2d	v4, v6, #0
	ldr	q3, [sp, #3696]                 ; 16-byte Reload
	bit.16b	v8, v3, v4
	ldr	q30, [sp, #4608]                ; 16-byte Reload
	bit.16b	v30, v3, v15
	bit.16b	v22, v3, v16
	ldr	q19, [sp, #4624]                ; 16-byte Reload
	bit.16b	v19, v3, v1
	ldr	q3, [sp, #3760]                 ; 16-byte Reload
	ldr	q9, [sp, #5344]                 ; 16-byte Reload
	str	q4, [sp, #4528]                 ; 16-byte Spill
	bit.16b	v9, v3, v4
	str	q9, [sp, #5344]                 ; 16-byte Spill
	ldr	q3, [sp, #3792]                 ; 16-byte Reload
	ldr	q4, [sp, #4576]                 ; 16-byte Reload
	bit.16b	v4, v3, v15
	mov.16b	v15, v30
	ldr	q3, [sp, #3744]                 ; 16-byte Reload
	ldr	q30, [sp, #5360]                ; 16-byte Reload
	bit.16b	v30, v3, v16
	str	q30, [sp, #5360]                ; 16-byte Spill
	ldr	q3, [sp, #3776]                 ; 16-byte Reload
	mov.16b	v9, v1
	bsl.16b	v9, v3, v23
	mov.16b	v3, v19
	ldr	q1, [sp, #3536]                 ; 16-byte Reload
	and.16b	v5, v1, v5
	and.16b	v25, v18, v25
	mov.16b	v23, v24
	ldr	q24, [sp, #4544]                ; 16-byte Reload
	b	LBB1_830
LBB1_829:                               ; %else2364
                                        ;   in Loop: Header=BB1_830 Depth=3
	fadd.4s	v18, v25, v16
	fadd.4s	v16, v5, v30
	bit.16b	v5, v16, v0
	bit.16b	v25, v18, v6
	add	x11, x11, #4
	cmp	x11, #64
	b.eq	LBB1_846
LBB1_830:                               ; %direct.true381.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	w9, s7
	dup.2d	v18, x11
	ldr	q1, [sp, #5360]                 ; 16-byte Reload
	orr.16b	v1, v18, v1
	add.2d	v19, v22, v1
	movi.2d	v16, #0000000000000000
	movi.2d	v30, #0000000000000000
	tbnz	w9, #0, LBB1_838
; %bb.831:                              ; %else2322
                                        ;   in Loop: Header=BB1_830 Depth=3
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_839
LBB1_832:                               ; %else2328
                                        ;   in Loop: Header=BB1_830 Depth=3
	ldr	q1, [sp, #5344]                 ; 16-byte Reload
	orr.16b	v1, v18, v1
	add.2d	v19, v8, v1
	tbnz	w9, #2, LBB1_840
LBB1_833:                               ; %else2334
                                        ;   in Loop: Header=BB1_830 Depth=3
	tbnz	w9, #3, LBB1_841
LBB1_834:                               ; %else2340
                                        ;   in Loop: Header=BB1_830 Depth=3
	orr.16b	v1, v18, v9
	add.2d	v19, v3, v1
	tbnz	w9, #4, LBB1_842
LBB1_835:                               ; %else2346
                                        ;   in Loop: Header=BB1_830 Depth=3
	tbnz	w9, #5, LBB1_843
LBB1_836:                               ; %else2352
                                        ;   in Loop: Header=BB1_830 Depth=3
	orr.16b	v1, v18, v4
	add.2d	v18, v15, v1
	tbnz	w9, #6, LBB1_844
LBB1_837:                               ; %else2358
                                        ;   in Loop: Header=BB1_830 Depth=3
	tbz	w9, #7, LBB1_829
	b	LBB1_845
LBB1_838:                               ; %cond.load2318
                                        ;   in Loop: Header=BB1_830 Depth=3
	fmov	x12, d19
	ldr	s16, [x12]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_832
LBB1_839:                               ; %cond.load2324
                                        ;   in Loop: Header=BB1_830 Depth=3
	mov.d	x12, v19[1]
	ld1.s	{ v16 }[1], [x12]
	ldr	q1, [sp, #5344]                 ; 16-byte Reload
	orr.16b	v1, v18, v1
	add.2d	v19, v8, v1
	tbz	w9, #2, LBB1_833
LBB1_840:                               ; %cond.load2330
                                        ;   in Loop: Header=BB1_830 Depth=3
	fmov	x12, d19
	ld1.s	{ v16 }[2], [x12]
	tbz	w9, #3, LBB1_834
LBB1_841:                               ; %cond.load2336
                                        ;   in Loop: Header=BB1_830 Depth=3
	mov.d	x12, v19[1]
	ld1.s	{ v16 }[3], [x12]
	orr.16b	v1, v18, v9
	add.2d	v19, v3, v1
	tbz	w9, #4, LBB1_835
LBB1_842:                               ; %cond.load2342
                                        ;   in Loop: Header=BB1_830 Depth=3
	fmov	x12, d19
	ld1.s	{ v30 }[0], [x12]
	tbz	w9, #5, LBB1_836
LBB1_843:                               ; %cond.load2348
                                        ;   in Loop: Header=BB1_830 Depth=3
	mov.d	x12, v19[1]
	ld1.s	{ v30 }[1], [x12]
	orr.16b	v1, v18, v4
	add.2d	v18, v15, v1
	tbz	w9, #6, LBB1_837
LBB1_844:                               ; %cond.load2354
                                        ;   in Loop: Header=BB1_830 Depth=3
	fmov	x12, d18
	ld1.s	{ v30 }[2], [x12]
	tbz	w9, #7, LBB1_829
LBB1_845:                               ; %cond.load2360
                                        ;   in Loop: Header=BB1_830 Depth=3
	mov.d	x9, v18[1]
	ld1.s	{ v30 }[3], [x9]
	b	LBB1_829
LBB1_846:                               ; %direct.false382.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	str	q4, [sp, #4576]                 ; 16-byte Spill
	str	q9, [sp, #4592]                 ; 16-byte Spill
	str	q15, [sp, #4608]                ; 16-byte Spill
	str	q3, [sp, #4624]                 ; 16-byte Spill
	str	q8, [sp, #4640]                 ; 16-byte Spill
	str	q22, [sp, #4656]                ; 16-byte Spill
	mov	x11, #0                         ; =0x0
	ldr	q1, [sp, #4736]                 ; 16-byte Reload
	ldr	q3, [sp, #4720]                 ; 16-byte Reload
	fsub.4s	v1, v1, v3
	ldr	q3, [sp, #4752]                 ; 16-byte Reload
	fsub.4s	v19, v3, v24
	and.16b	v30, v0, v19
	and.16b	v19, v6, v1
	fcmge.4s	v1, v19, v11
	fcmge.4s	v22, v30, v11
	fcmge.4s	v15, v21, v19
	fcmge.4s	v8, v21, v30
	and.16b	v22, v22, v8
	and.16b	v1, v1, v15
	and.16b	v1, v1, v19
	and.16b	v22, v22, v30
	fmul.4s	v8, v22, v29
	fmul.4s	v29, v1, v29
	movi.4s	v3, #75, lsl #24
	mvni.4s	v4, #128, lsl #24
	mov.16b	v15, v4
	bsl.16b	v15, v3, v29
	mov.16b	v9, v4
	bsl.16b	v9, v3, v8
	fadd.4s	v8, v8, v9
	fadd.4s	v29, v29, v15
	fsub.4s	v29, v29, v15
	fsub.4s	v8, v8, v9
	fcvtzs.4s	v8, v8
	fcvtzs.4s	v29, v29
	scvtf.4s	v9, v29
	mov	w9, #29184                      ; =0x7200
	movk	w9, #48945, lsl #16
	dup.4s	v15, w9
	scvtf.4s	v3, v8
	fmul.4s	v4, v3, v15
	fmul.4s	v15, v9, v15
	fadd.4s	v1, v1, v15
	mov	w9, #48782                      ; =0xbe8e
	movk	w9, #46527, lsl #16
	dup.4s	v15, w9
	fadd.4s	v4, v22, v4
	fmul.4s	v22, v9, v15
	fmul.4s	v3, v3, v15
	fadd.4s	v3, v4, v3
	fadd.4s	v1, v1, v22
	fmul.4s	v4, v1, v27
	fmul.4s	v22, v3, v27
	fadd.4s	v22, v22, v28
	fadd.4s	v4, v4, v28
	fmul.4s	v4, v1, v4
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v26
	fadd.4s	v4, v4, v26
	fmul.4s	v4, v1, v4
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v20
	fadd.4s	v4, v4, v20
	fmul.4s	v4, v1, v4
	fmul.4s	v20, v3, v22
	ldr	q22, [sp, #4944]                ; 16-byte Reload
	fadd.4s	v20, v20, v22
	fadd.4s	v4, v4, v22
	fmul.4s	v4, v1, v4
	fmul.4s	v20, v3, v20
	movi.4s	v22, #63, lsl #24
	fadd.4s	v20, v20, v22
	fadd.4s	v4, v4, v22
	fmul.4s	v22, v1, v1
	fmul.4s	v4, v22, v4
	fmul.4s	v22, v3, v3
	fmul.4s	v20, v22, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v1, v1, v4
	fmov.4s	v24, #1.00000000
	fadd.4s	v1, v1, v24
	fadd.4s	v3, v3, v24
	sshr.4s	v4, v29, #1
	sshr.4s	v20, v8, #1
	shl.4s	v22, v20, #23
	add.4s	v22, v22, v24
	fmul.4s	v3, v3, v22
	shl.4s	v22, v4, #23
	add.4s	v22, v22, v24
	fmul.4s	v1, v1, v22
	sub.4s	v20, v8, v20
	sub.4s	v4, v29, v4
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v24
	fmul.4s	v1, v1, v4
	shl.4s	v4, v20, #23
	add.4s	v4, v4, v24
	fmul.4s	v3, v3, v4
	fcmgt.4s	v4, v11, v30
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v11, v19
	bic.16b	v1, v1, v4
	fcmgt.4s	v4, v19, v21
	ldr	q20, [sp, #4960]                ; 16-byte Reload
	bit.16b	v1, v20, v4
	fcmgt.4s	v4, v30, v21
	bit.16b	v3, v20, v4
	sshll.2d	v22, v0, #0
	sshll.2d	v26, v6, #0
	fcmeq.4s	v4, v19, v19
	fcmeq.4s	v19, v30, v30
	ldr	q20, [sp, #4976]                ; 16-byte Reload
	mov.16b	v24, v19
	bsl.16b	v24, v3, v20
	mov.16b	v21, v4
	bsl.16b	v21, v1, v20
	ldr	q1, [sp, #5008]                 ; 16-byte Reload
	bit.16b	v1, v21, v6
	str	q1, [sp, #5008]                 ; 16-byte Spill
	ldr	q1, [sp, #4992]                 ; 16-byte Reload
	bit.16b	v1, v24, v0
	str	q1, [sp, #4992]                 ; 16-byte Spill
	ldr	q1, [sp, #3568]                 ; 16-byte Reload
	ldr	q3, [sp, #4704]                 ; 16-byte Reload
	ldr	q4, [sp, #4528]                 ; 16-byte Reload
	bit.16b	v3, v1, v4
	ldr	q15, [sp, #4496]                ; 16-byte Reload
	ldr	q19, [sp, #4672]                ; 16-byte Reload
	bit.16b	v19, v1, v15
	ldr	q8, [sp, #4512]                 ; 16-byte Reload
	bit.16b	v8, v1, v26
	ldr	q9, [sp, #4688]                 ; 16-byte Reload
	bit.16b	v9, v1, v22
Lloh320:
	adrp	x9, lCPI1_79@PAGE
Lloh321:
	ldr	q20, [x9, lCPI1_79@PAGEOFF]
	ldr	q1, [sp, #5408]                 ; 16-byte Reload
	bit.16b	v1, v20, v4
	str	q1, [sp, #5408]                 ; 16-byte Spill
Lloh322:
	adrp	x9, lCPI1_81@PAGE
Lloh323:
	ldr	q4, [x9, lCPI1_81@PAGEOFF]
	ldr	q1, [sp, #5424]                 ; 16-byte Reload
	bit.16b	v1, v4, v26
	str	q1, [sp, #5424]                 ; 16-byte Spill
Lloh324:
	adrp	x9, lCPI1_82@PAGE
Lloh325:
	ldr	q26, [x9, lCPI1_82@PAGEOFF]
	ldr	q1, [sp, #5392]                 ; 16-byte Reload
	bit.16b	v1, v26, v22
	str	q1, [sp, #5392]                 ; 16-byte Spill
	mov.16b	v22, v19
Lloh326:
	adrp	x9, lCPI1_80@PAGE
Lloh327:
	ldr	q27, [x9, lCPI1_80@PAGEOFF]
	ldr	q1, [sp, #5376]                 ; 16-byte Reload
	bit.16b	v1, v27, v15
	str	q1, [sp, #5376]                 ; 16-byte Spill
	add	x9, x4, #2560
	ldr	q11, [sp, #3680]                ; 16-byte Reload
	b	LBB1_848
LBB1_847:                               ; %else2398
                                        ;   in Loop: Header=BB1_848 Depth=3
	add	x11, x11, #4
	add	x9, x9, #32
	cmp	x11, #384
	b.eq	LBB1_864
LBB1_848:                               ; %direct.true393.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	w12, s7
	ldp	q1, q28, [x9]
	and.16b	v1, v6, v1
	ldr	q19, [sp, #5008]                ; 16-byte Reload
	fmul.4s	v29, v19, v1
	dup.2d	v19, x11
	ldr	q1, [sp, #5424]                 ; 16-byte Reload
	add.2d	v1, v19, v1
	add.2d	v30, v8, v1
	tbnz	w12, #0, LBB1_857
; %bb.849:                              ; %else2370
                                        ;   in Loop: Header=BB1_848 Depth=3
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB1_858
LBB1_850:                               ; %else2374
                                        ;   in Loop: Header=BB1_848 Depth=3
	ldr	q1, [sp, #5408]                 ; 16-byte Reload
	add.2d	v1, v19, v1
	add.2d	v30, v3, v1
	tbnz	w12, #2, LBB1_859
LBB1_851:                               ; %else2378
                                        ;   in Loop: Header=BB1_848 Depth=3
	tbz	w12, #3, LBB1_853
LBB1_852:                               ; %cond.store2379
                                        ;   in Loop: Header=BB1_848 Depth=3
	mov.d	x7, v30[1]
	st1.s	{ v29 }[3], [x7]
LBB1_853:                               ; %else2382
                                        ;   in Loop: Header=BB1_848 Depth=3
	and.16b	v1, v0, v28
	ldr	q28, [sp, #4992]                ; 16-byte Reload
	fmul.4s	v28, v28, v1
	ldr	q1, [sp, #5392]                 ; 16-byte Reload
	add.2d	v1, v19, v1
	add.2d	v29, v9, v1
	tbnz	w12, #4, LBB1_860
; %bb.854:                              ; %else2386
                                        ;   in Loop: Header=BB1_848 Depth=3
	tbnz	w12, #5, LBB1_861
LBB1_855:                               ; %else2390
                                        ;   in Loop: Header=BB1_848 Depth=3
	ldr	q1, [sp, #5376]                 ; 16-byte Reload
	add.2d	v1, v19, v1
	add.2d	v19, v22, v1
	tbnz	w12, #6, LBB1_862
LBB1_856:                               ; %else2394
                                        ;   in Loop: Header=BB1_848 Depth=3
	tbz	w12, #7, LBB1_847
	b	LBB1_863
LBB1_857:                               ; %cond.store2367
                                        ;   in Loop: Header=BB1_848 Depth=3
	fmov	x7, d30
	str	s29, [x7]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB1_850
LBB1_858:                               ; %cond.store2371
                                        ;   in Loop: Header=BB1_848 Depth=3
	mov.d	x7, v30[1]
	st1.s	{ v29 }[1], [x7]
	ldr	q1, [sp, #5408]                 ; 16-byte Reload
	add.2d	v1, v19, v1
	add.2d	v30, v3, v1
	tbz	w12, #2, LBB1_851
LBB1_859:                               ; %cond.store2375
                                        ;   in Loop: Header=BB1_848 Depth=3
	fmov	x7, d30
	st1.s	{ v29 }[2], [x7]
	tbnz	w12, #3, LBB1_852
	b	LBB1_853
LBB1_860:                               ; %cond.store2383
                                        ;   in Loop: Header=BB1_848 Depth=3
	fmov	x7, d29
	str	s28, [x7]
	tbz	w12, #5, LBB1_855
LBB1_861:                               ; %cond.store2387
                                        ;   in Loop: Header=BB1_848 Depth=3
	mov.d	x7, v29[1]
	st1.s	{ v28 }[1], [x7]
	ldr	q1, [sp, #5376]                 ; 16-byte Reload
	add.2d	v1, v19, v1
	add.2d	v19, v22, v1
	tbz	w12, #6, LBB1_856
LBB1_862:                               ; %cond.store2391
                                        ;   in Loop: Header=BB1_848 Depth=3
	fmov	x7, d19
	st1.s	{ v28 }[2], [x7]
	tbz	w12, #7, LBB1_847
LBB1_863:                               ; %cond.store2395
                                        ;   in Loop: Header=BB1_848 Depth=3
	mov.d	x12, v19[1]
	st1.s	{ v28 }[3], [x12]
	b	LBB1_847
LBB1_864:                               ; %direct.false394.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	str	q22, [sp, #4672]                ; 16-byte Spill
	str	q9, [sp, #4688]                 ; 16-byte Spill
	str	q3, [sp, #4704]                 ; 16-byte Spill
	ldr	w9, [sp, #4492]                 ; 4-byte Reload
	ldr	q28, [sp, #4400]                ; 16-byte Reload
	ldr	q29, [sp, #4384]                ; 16-byte Reload
	ldr	q30, [sp, #4368]                ; 16-byte Reload
	tbz	w9, #0, LBB1_867
; %bb.865:                              ; %mma.active410.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	mov	x11, #0                         ; =0x0
	ldr	q1, [sp, #4656]                 ; 16-byte Reload
	fmov	x9, d1
	ldr	q1, [sp, #5360]                 ; 16-byte Reload
	fmov	x12, d1
	add	x12, x9, x12
	ldr	q1, [sp, #5328]                 ; 16-byte Reload
	fmov	x9, d1
	ldr	q1, [sp, #5264]                 ; 16-byte Reload
	fmov	x7, d1
	add	x7, x9, x7
	fmov	x9, d8
	ldr	q1, [sp, #5424]                 ; 16-byte Reload
	fmov	x20, d1
	add	x9, x9, x20
	ldr	x20, [sp, #256]                 ; 8-byte Reload
LBB1_866:                               ; %mma.update2.i272.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x22, x11, #4
	ldr	q1, [x9, x22]
	ldr	q3, [x7]
	ldp	s19, s22, [x12]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #384]
	fmul.4s	v3, v3, v22[0]
	ldr	q19, [x7, #768]
	fadd.4s	v1, v1, v3
	ldp	s3, s22, [x12, #8]
	fmul.4s	v3, v19, v3[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #1152]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #1536]
	ldp	s19, s22, [x12, #16]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #1920]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #2304]
	ldp	s19, s22, [x12, #24]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #2688]
	fmul.4s	v3, v3, v22[0]
	ldr	q19, [x7, #3072]
	fadd.4s	v1, v1, v3
	ldp	s3, s22, [x12, #32]
	fmul.4s	v3, v19, v3[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #3456]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #3840]
	ldp	s19, s22, [x12, #40]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #4224]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #4608]
	ldp	s19, s22, [x12, #48]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #4992]
	fmul.4s	v3, v3, v22[0]
	ldr	q19, [x7, #5376]
	fadd.4s	v1, v1, v3
	ldp	s3, s22, [x12, #56]
	fmul.4s	v3, v19, v3[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #5760]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	str	q1, [x20, x22]
	add	x11, x11, #1
	add	x7, x7, #16
	cmp	x11, #24
	b.ne	LBB1_866
LBB1_867:                               ; %mma.continue411.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	str	q8, [sp, #4512]                 ; 16-byte Spill
	mov	x24, x0
	ldr	w9, [sp, #4488]                 ; 4-byte Reload
	ldr	q9, [sp, #4320]                 ; 16-byte Reload
	tbz	w9, #0, LBB1_870
; %bb.868:                              ; %mma.active412.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	mov	x11, #0                         ; =0x0
	ldr	q1, [sp, #4656]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	ldr	q1, [sp, #5360]                 ; 16-byte Reload
	mov.d	x12, v1[1]
	add	x12, x9, x12
	ldr	q1, [sp, #5328]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	ldr	q1, [sp, #5264]                 ; 16-byte Reload
	mov.d	x7, v1[1]
	add	x7, x9, x7
	ldr	q1, [sp, #4512]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	ldr	q1, [sp, #5424]                 ; 16-byte Reload
	mov.d	x20, v1[1]
	add	x9, x9, x20
	ldr	x20, [sp, #248]                 ; 8-byte Reload
LBB1_869:                               ; %mma.update2.i274.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x22, x11, #4
	ldr	q1, [x9, x22]
	ldr	q3, [x7]
	ldp	s19, s22, [x12]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #384]
	fmul.4s	v3, v3, v22[0]
	ldr	q19, [x7, #768]
	fadd.4s	v1, v1, v3
	ldp	s3, s22, [x12, #8]
	fmul.4s	v3, v19, v3[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #1152]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #1536]
	ldp	s19, s22, [x12, #16]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #1920]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #2304]
	ldp	s19, s22, [x12, #24]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #2688]
	fmul.4s	v3, v3, v22[0]
	ldr	q19, [x7, #3072]
	fadd.4s	v1, v1, v3
	ldp	s3, s22, [x12, #32]
	fmul.4s	v3, v19, v3[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #3456]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #3840]
	ldp	s19, s22, [x12, #40]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #4224]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #4608]
	ldp	s19, s22, [x12, #48]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #4992]
	fmul.4s	v3, v3, v22[0]
	ldr	q19, [x7, #5376]
	fadd.4s	v1, v1, v3
	ldp	s3, s22, [x12, #56]
	fmul.4s	v3, v19, v3[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #5760]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	str	q1, [x20, x22]
	add	x11, x11, #1
	add	x7, x7, #16
	cmp	x11, #24
	b.ne	LBB1_869
LBB1_870:                               ; %mma.continue413.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	w9, [sp, #4484]                 ; 4-byte Reload
	tbz	w9, #0, LBB1_873
; %bb.871:                              ; %mma.active414.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	mov	x0, x1
	mov	x11, #0                         ; =0x0
	ldr	q1, [sp, #4640]                 ; 16-byte Reload
	fmov	x9, d1
	ldr	q1, [sp, #5344]                 ; 16-byte Reload
	fmov	x12, d1
	add	x12, x9, x12
	ldr	q1, [sp, #5312]                 ; 16-byte Reload
	fmov	x9, d1
	ldr	q1, [sp, #5248]                 ; 16-byte Reload
	fmov	x7, d1
	add	x7, x9, x7
	ldr	q1, [sp, #4704]                 ; 16-byte Reload
	fmov	x9, d1
	ldr	q1, [sp, #5408]                 ; 16-byte Reload
	fmov	x20, d1
	add	x9, x9, x20
LBB1_872:                               ; %mma.update2.i310.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x22, x11, #4
	ldr	q1, [x9, x22]
	ldr	q3, [x7]
	ldp	s19, s22, [x12]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #384]
	fmul.4s	v3, v3, v22[0]
	ldr	q19, [x7, #768]
	fadd.4s	v1, v1, v3
	ldp	s3, s22, [x12, #8]
	fmul.4s	v3, v19, v3[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #1152]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #1536]
	ldp	s19, s22, [x12, #16]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #1920]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #2304]
	ldp	s19, s22, [x12, #24]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #2688]
	fmul.4s	v3, v3, v22[0]
	ldr	q19, [x7, #3072]
	fadd.4s	v1, v1, v3
	ldp	s3, s22, [x12, #32]
	fmul.4s	v3, v19, v3[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #3456]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #3840]
	ldp	s19, s22, [x12, #40]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #4224]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #4608]
	ldp	s19, s22, [x12, #48]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #4992]
	fmul.4s	v3, v3, v22[0]
	ldr	q19, [x7, #5376]
	fadd.4s	v1, v1, v3
	ldp	s3, s22, [x12, #56]
	fmul.4s	v3, v19, v3[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #5760]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	str	q1, [x0, x22]
	add	x11, x11, #1
	add	x7, x7, #16
	cmp	x11, #24
	b.ne	LBB1_872
LBB1_873:                               ; %mma.continue415.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	w9, [sp, #4480]                 ; 4-byte Reload
	mov	x0, x24
	tbz	w9, #0, LBB1_876
; %bb.874:                              ; %mma.active416.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	mov	x11, #0                         ; =0x0
	ldr	q1, [sp, #4640]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	ldr	q1, [sp, #5344]                 ; 16-byte Reload
	mov.d	x12, v1[1]
	add	x12, x9, x12
	ldr	q1, [sp, #5312]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	ldr	q1, [sp, #5248]                 ; 16-byte Reload
	mov.d	x7, v1[1]
	add	x7, x9, x7
	ldr	q1, [sp, #4704]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	ldr	q1, [sp, #5408]                 ; 16-byte Reload
	mov.d	x20, v1[1]
	add	x9, x9, x20
LBB1_875:                               ; %mma.update2.i346.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x22, x11, #4
	ldr	q1, [x9, x22]
	ldr	q3, [x7]
	ldp	s19, s22, [x12]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #384]
	fmul.4s	v3, v3, v22[0]
	ldr	q19, [x7, #768]
	fadd.4s	v1, v1, v3
	ldp	s3, s22, [x12, #8]
	fmul.4s	v3, v19, v3[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #1152]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #1536]
	ldp	s19, s22, [x12, #16]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #1920]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #2304]
	ldp	s19, s22, [x12, #24]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #2688]
	fmul.4s	v3, v3, v22[0]
	ldr	q19, [x7, #3072]
	fadd.4s	v1, v1, v3
	ldp	s3, s22, [x12, #32]
	fmul.4s	v3, v19, v3[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #3456]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #3840]
	ldp	s19, s22, [x12, #40]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #4224]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #4608]
	ldp	s19, s22, [x12, #48]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #4992]
	fmul.4s	v3, v3, v22[0]
	ldr	q19, [x7, #5376]
	fadd.4s	v1, v1, v3
	ldp	s3, s22, [x12, #56]
	fmul.4s	v3, v19, v3[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #5760]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	str	q1, [x0, x22]
	add	x11, x11, #1
	add	x7, x7, #16
	cmp	x11, #24
	b.ne	LBB1_875
LBB1_876:                               ; %mma.continue417.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	mov	x27, x17
	ldr	w9, [sp, #4476]                 ; 4-byte Reload
	mov	x24, x3
	tbz	w9, #0, LBB1_879
; %bb.877:                              ; %mma.active418.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	mov	x11, #0                         ; =0x0
	ldr	q1, [sp, #4624]                 ; 16-byte Reload
	fmov	x9, d1
	ldr	q1, [sp, #4592]                 ; 16-byte Reload
	fmov	x12, d1
	add	x12, x9, x12
	ldr	q1, [sp, #5296]                 ; 16-byte Reload
	fmov	x9, d1
	ldr	q1, [sp, #5232]                 ; 16-byte Reload
	fmov	x7, d1
	add	x7, x9, x7
	ldr	q1, [sp, #4688]                 ; 16-byte Reload
	fmov	x9, d1
	ldr	q1, [sp, #5392]                 ; 16-byte Reload
	fmov	x20, d1
	add	x9, x9, x20
LBB1_878:                               ; %mma.update2.i382.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x22, x11, #4
	ldr	q1, [x9, x22]
	ldr	q3, [x7]
	ldp	s19, s22, [x12]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #384]
	fmul.4s	v3, v3, v22[0]
	ldr	q19, [x7, #768]
	fadd.4s	v1, v1, v3
	ldp	s3, s22, [x12, #8]
	fmul.4s	v3, v19, v3[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #1152]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #1536]
	ldp	s19, s22, [x12, #16]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #1920]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #2304]
	ldp	s19, s22, [x12, #24]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #2688]
	fmul.4s	v3, v3, v22[0]
	ldr	q19, [x7, #3072]
	fadd.4s	v1, v1, v3
	ldp	s3, s22, [x12, #32]
	fmul.4s	v3, v19, v3[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #3456]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #3840]
	ldp	s19, s22, [x12, #40]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #4224]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #4608]
	ldp	s19, s22, [x12, #48]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #4992]
	fmul.4s	v3, v3, v22[0]
	ldr	q19, [x7, #5376]
	fadd.4s	v1, v1, v3
	ldp	s3, s22, [x12, #56]
	fmul.4s	v3, v19, v3[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #5760]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	str	q1, [x24, x22]
	add	x11, x11, #1
	add	x7, x7, #16
	cmp	x11, #24
	b.ne	LBB1_878
LBB1_879:                               ; %mma.continue419.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	mov	x17, x6
	ldr	w9, [sp, #4472]                 ; 4-byte Reload
	ldr	x3, [sp, #480]                  ; 8-byte Reload
	tbz	w9, #0, LBB1_882
; %bb.880:                              ; %mma.active420.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	mov	x11, #0                         ; =0x0
	ldr	q1, [sp, #4624]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	ldr	q1, [sp, #4592]                 ; 16-byte Reload
	mov.d	x12, v1[1]
	add	x12, x9, x12
	ldr	q1, [sp, #5296]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	ldr	q1, [sp, #5232]                 ; 16-byte Reload
	mov.d	x7, v1[1]
	add	x7, x9, x7
	ldr	q1, [sp, #4688]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	ldr	q1, [sp, #5392]                 ; 16-byte Reload
	mov.d	x20, v1[1]
	add	x9, x9, x20
LBB1_881:                               ; %mma.update2.i418.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x22, x11, #4
	ldr	q1, [x9, x22]
	ldr	q3, [x7]
	ldp	s19, s22, [x12]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #384]
	fmul.4s	v3, v3, v22[0]
	ldr	q19, [x7, #768]
	fadd.4s	v1, v1, v3
	ldp	s3, s22, [x12, #8]
	fmul.4s	v3, v19, v3[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #1152]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #1536]
	ldp	s19, s22, [x12, #16]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #1920]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #2304]
	ldp	s19, s22, [x12, #24]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #2688]
	fmul.4s	v3, v3, v22[0]
	ldr	q19, [x7, #3072]
	fadd.4s	v1, v1, v3
	ldp	s3, s22, [x12, #32]
	fmul.4s	v3, v19, v3[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #3456]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #3840]
	ldp	s19, s22, [x12, #40]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #4224]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #4608]
	ldp	s19, s22, [x12, #48]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #4992]
	fmul.4s	v3, v3, v22[0]
	ldr	q19, [x7, #5376]
	fadd.4s	v1, v1, v3
	ldp	s3, s22, [x12, #56]
	fmul.4s	v3, v19, v3[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #5760]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	str	q1, [x3, x22]
	add	x11, x11, #1
	add	x7, x7, #16
	cmp	x11, #24
	b.ne	LBB1_881
LBB1_882:                               ; %mma.continue421.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	w9, [sp, #4468]                 ; 4-byte Reload
	ldr	x6, [sp, #264]                  ; 8-byte Reload
	tbz	w9, #0, LBB1_885
; %bb.883:                              ; %mma.active422.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	mov	x11, #0                         ; =0x0
	ldr	q1, [sp, #4608]                 ; 16-byte Reload
	fmov	x9, d1
	ldr	q1, [sp, #4576]                 ; 16-byte Reload
	fmov	x12, d1
	add	x12, x9, x12
	ldr	q1, [sp, #5280]                 ; 16-byte Reload
	fmov	x9, d1
	ldr	q1, [sp, #5216]                 ; 16-byte Reload
	fmov	x7, d1
	add	x7, x9, x7
	ldr	q1, [sp, #4672]                 ; 16-byte Reload
	fmov	x9, d1
	ldr	q1, [sp, #5376]                 ; 16-byte Reload
	fmov	x20, d1
	add	x9, x9, x20
LBB1_884:                               ; %mma.update2.i454.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x22, x11, #4
	ldr	q1, [x9, x22]
	ldr	q3, [x7]
	ldp	s19, s22, [x12]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #384]
	fmul.4s	v3, v3, v22[0]
	ldr	q19, [x7, #768]
	fadd.4s	v1, v1, v3
	ldp	s3, s22, [x12, #8]
	fmul.4s	v3, v19, v3[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #1152]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #1536]
	ldp	s19, s22, [x12, #16]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #1920]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #2304]
	ldp	s19, s22, [x12, #24]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #2688]
	fmul.4s	v3, v3, v22[0]
	ldr	q19, [x7, #3072]
	fadd.4s	v1, v1, v3
	ldp	s3, s22, [x12, #32]
	fmul.4s	v3, v19, v3[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #3456]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #3840]
	ldp	s19, s22, [x12, #40]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #4224]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #4608]
	ldp	s19, s22, [x12, #48]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #4992]
	fmul.4s	v3, v3, v22[0]
	ldr	q19, [x7, #5376]
	fadd.4s	v1, v1, v3
	ldp	s3, s22, [x12, #56]
	fmul.4s	v3, v19, v3[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #5760]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	str	q1, [x6, x22]
	add	x11, x11, #1
	add	x7, x7, #16
	cmp	x11, #24
	b.ne	LBB1_884
LBB1_885:                               ; %mma.continue423.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	w9, [sp, #4464]                 ; 4-byte Reload
	mov	x6, x17
	tbz	w9, #0, LBB1_888
; %bb.886:                              ; %mma.active424.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	mov	x11, #0                         ; =0x0
	ldr	q1, [sp, #4608]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	ldr	q1, [sp, #4576]                 ; 16-byte Reload
	mov.d	x12, v1[1]
	add	x12, x9, x12
	ldr	q1, [sp, #5280]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	ldr	q1, [sp, #5216]                 ; 16-byte Reload
	mov.d	x7, v1[1]
	add	x7, x9, x7
	ldr	q1, [sp, #4672]                 ; 16-byte Reload
	mov.d	x9, v1[1]
	ldr	q1, [sp, #5376]                 ; 16-byte Reload
	mov.d	x20, v1[1]
	add	x9, x9, x20
LBB1_887:                               ; %mma.update2.i490.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x22, x11, #4
	ldr	q1, [x9, x22]
	ldr	q3, [x7]
	ldp	s19, s22, [x12]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #384]
	fmul.4s	v3, v3, v22[0]
	ldr	q19, [x7, #768]
	fadd.4s	v1, v1, v3
	ldp	s3, s22, [x12, #8]
	fmul.4s	v3, v19, v3[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #1152]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #1536]
	ldp	s19, s22, [x12, #16]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #1920]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #2304]
	ldp	s19, s22, [x12, #24]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #2688]
	fmul.4s	v3, v3, v22[0]
	ldr	q19, [x7, #3072]
	fadd.4s	v1, v1, v3
	ldp	s3, s22, [x12, #32]
	fmul.4s	v3, v19, v3[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #3456]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #3840]
	ldp	s19, s22, [x12, #40]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #4224]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #4608]
	ldp	s19, s22, [x12, #48]
	fmul.4s	v3, v3, v19[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #4992]
	fmul.4s	v3, v3, v22[0]
	ldr	q19, [x7, #5376]
	fadd.4s	v1, v1, v3
	ldp	s3, s22, [x12, #56]
	fmul.4s	v3, v19, v3[0]
	fadd.4s	v1, v1, v3
	ldr	q3, [x7, #5760]
	fmul.4s	v3, v3, v22[0]
	fadd.4s	v1, v1, v3
	str	q1, [x6, x22]
	add	x11, x11, #1
	add	x7, x7, #16
	cmp	x11, #24
	b.ne	LBB1_887
LBB1_888:                               ; %direct.true427.i.i.preheader
                                        ;   in Loop: Header=BB1_50 Depth=2
	mov	x11, #0                         ; =0x0
	sshll.2d	v1, v6, #0
	sshll.2d	v3, v0, #0
	ldr	q19, [sp, #4560]                ; 16-byte Reload
	fmul.4s	v19, v19, v24
	fmul.4s	v21, v28, v21
	fadd.4s	v18, v21, v18
	fadd.4s	v16, v19, v16
	ldr	q19, [sp, #3552]                ; 16-byte Reload
	ldr	q22, [sp, #4336]                ; 16-byte Reload
	bit.16b	v22, v19, v15
	ldr	q24, [sp, #4528]                ; 16-byte Reload
	bit.16b	v30, v19, v24
	ldr	q21, [sp, #4352]                ; 16-byte Reload
	bit.16b	v21, v19, v3
	bit.16b	v29, v19, v1
	ldr	q19, [sp, #5024]                ; 16-byte Reload
	bit.16b	v19, v27, v15
	str	q19, [sp, #5024]                ; 16-byte Spill
	mov.16b	v27, v22
	ldr	q19, [sp, #5056]                ; 16-byte Reload
	bit.16b	v19, v20, v24
	str	q19, [sp, #5056]                ; 16-byte Spill
	ldr	q19, [sp, #5040]                ; 16-byte Reload
	bit.16b	v19, v26, v3
	str	q19, [sp, #5040]                ; 16-byte Spill
	mov.16b	v26, v21
	mov	w9, #5632                       ; =0x1600
	add	x12, x4, x9
	ldr	q3, [sp, #5072]                 ; 16-byte Reload
	bit.16b	v3, v4, v1
	str	q3, [sp, #5072]                 ; 16-byte Spill
	ldr	q22, [sp, #3648]                ; 16-byte Reload
	ldr	q24, [sp, #3632]                ; 16-byte Reload
	mov	x17, x27
	mov	w27, #52429                     ; =0xcccd
	b	LBB1_890
LBB1_889:                               ; %else2446
                                        ;   in Loop: Header=BB1_890 Depth=3
	ldp	q1, q3, [x12]
	bit.16b	v3, v20, v0
	bit.16b	v1, v4, v6
	stp	q1, q3, [x12], #32
	add	x11, x11, #4
	cmp	x11, #384
	b.eq	LBB1_906
LBB1_890:                               ; %direct.true427.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	w9, s7
	dup.2d	v21, x11
	ldr	q1, [sp, #5072]                 ; 16-byte Reload
	add.2d	v1, v29, v1
	add.2d	v19, v1, v21
	movi.2d	v4, #0000000000000000
	movi.2d	v20, #0000000000000000
	tbnz	w9, #0, LBB1_898
; %bb.891:                              ; %else2404
                                        ;   in Loop: Header=BB1_890 Depth=3
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_899
LBB1_892:                               ; %else2410
                                        ;   in Loop: Header=BB1_890 Depth=3
	ldr	q1, [sp, #5056]                 ; 16-byte Reload
	add.2d	v1, v30, v1
	add.2d	v19, v1, v21
	tbnz	w9, #2, LBB1_900
LBB1_893:                               ; %else2416
                                        ;   in Loop: Header=BB1_890 Depth=3
	tbnz	w9, #3, LBB1_901
LBB1_894:                               ; %else2422
                                        ;   in Loop: Header=BB1_890 Depth=3
	ldr	q1, [sp, #5040]                 ; 16-byte Reload
	add.2d	v1, v26, v1
	add.2d	v19, v1, v21
	tbnz	w9, #4, LBB1_902
LBB1_895:                               ; %else2428
                                        ;   in Loop: Header=BB1_890 Depth=3
	tbnz	w9, #5, LBB1_903
LBB1_896:                               ; %else2434
                                        ;   in Loop: Header=BB1_890 Depth=3
	ldr	q1, [sp, #5024]                 ; 16-byte Reload
	add.2d	v1, v27, v1
	add.2d	v19, v1, v21
	tbnz	w9, #6, LBB1_904
LBB1_897:                               ; %else2440
                                        ;   in Loop: Header=BB1_890 Depth=3
	mov	x7, x1
	tbz	w9, #7, LBB1_889
	b	LBB1_905
LBB1_898:                               ; %cond.load2400
                                        ;   in Loop: Header=BB1_890 Depth=3
	fmov	x7, d19
	ldr	s4, [x7]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_892
LBB1_899:                               ; %cond.load2406
                                        ;   in Loop: Header=BB1_890 Depth=3
	mov.d	x7, v19[1]
	ld1.s	{ v4 }[1], [x7]
	ldr	q1, [sp, #5056]                 ; 16-byte Reload
	add.2d	v1, v30, v1
	add.2d	v19, v1, v21
	tbz	w9, #2, LBB1_893
LBB1_900:                               ; %cond.load2412
                                        ;   in Loop: Header=BB1_890 Depth=3
	fmov	x7, d19
	ld1.s	{ v4 }[2], [x7]
	tbz	w9, #3, LBB1_894
LBB1_901:                               ; %cond.load2418
                                        ;   in Loop: Header=BB1_890 Depth=3
	mov.d	x7, v19[1]
	ld1.s	{ v4 }[3], [x7]
	ldr	q1, [sp, #5040]                 ; 16-byte Reload
	add.2d	v1, v26, v1
	add.2d	v19, v1, v21
	tbz	w9, #4, LBB1_895
LBB1_902:                               ; %cond.load2424
                                        ;   in Loop: Header=BB1_890 Depth=3
	fmov	x7, d19
	ld1.s	{ v20 }[0], [x7]
	tbz	w9, #5, LBB1_896
LBB1_903:                               ; %cond.load2430
                                        ;   in Loop: Header=BB1_890 Depth=3
	mov.d	x7, v19[1]
	ld1.s	{ v20 }[1], [x7]
	ldr	q1, [sp, #5024]                 ; 16-byte Reload
	add.2d	v1, v27, v1
	add.2d	v19, v1, v21
	tbz	w9, #6, LBB1_897
LBB1_904:                               ; %cond.load2436
                                        ;   in Loop: Header=BB1_890 Depth=3
	fmov	x7, d19
	ld1.s	{ v20 }[2], [x7]
	mov	x7, x1
	tbz	w9, #7, LBB1_889
LBB1_905:                               ; %cond.load2442
                                        ;   in Loop: Header=BB1_890 Depth=3
	mov.d	x9, v19[1]
	ld1.s	{ v20 }[3], [x9]
	b	LBB1_889
LBB1_906:                               ; %direct.true441.i.i.preheader
                                        ;   in Loop: Header=BB1_50 Depth=2
	mov	w11, #96                        ; =0x60
	ldr	q21, [sp, #3664]                ; 16-byte Reload
LBB1_907:                               ; %direct.true441.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_50 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q1, [x4, #5632]
	ldr	q3, [x4, #5648]
	ldr	q4, [x4, #2560]
	ldr	q19, [x4, #2576]
	bif.16b	v3, v19, v0
	bif.16b	v1, v4, v6
	str	q1, [x4, #2560]
	str	q3, [x4, #2576]
	add	x4, x4, #32
	subs	x11, x11, #1
	b.ne	LBB1_907
; %bb.908:                              ; %direct.false442.i.i
                                        ;   in Loop: Header=BB1_50 Depth=2
	add	x17, x17, #1
	ldr	q1, [sp, #4752]                 ; 16-byte Reload
	ldr	q3, [sp, #4544]                 ; 16-byte Reload
	bit.16b	v1, v3, v0
	str	q1, [sp, #4752]                 ; 16-byte Spill
	ldr	q1, [sp, #4736]                 ; 16-byte Reload
	ldr	q3, [sp, #4720]                 ; 16-byte Reload
	bit.16b	v1, v3, v6
	str	q1, [sp, #4736]                 ; 16-byte Spill
	ldr	q20, [sp, #4560]                ; 16-byte Reload
	bit.16b	v20, v16, v0
	bit.16b	v28, v18, v6
	cmp	x17, #129
	b.ne	LBB1_50
	b	LBB1_1011
LBB1_909:                               ; %cond.load1747
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1456]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v16 }[1], [x11]
	tbz	w9, #2, LBB1_660
LBB1_910:                               ; %cond.load1753
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1472]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v16 }[2], [x11]
	tbz	w9, #3, LBB1_661
LBB1_911:                               ; %cond.load1759
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1472]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v16 }[3], [x11]
	tbz	w9, #4, LBB1_662
LBB1_912:                               ; %cond.load1765
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1488]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v6 }[0], [x11]
	tbz	w9, #5, LBB1_663
LBB1_913:                               ; %cond.load1771
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1488]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	ld1.s	{ v6 }[1], [x11]
	tbz	w9, #6, LBB1_664
LBB1_914:                               ; %cond.load1777
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1504]                 ; 16-byte Reload
	fmov	x11, d1
	ld1.s	{ v6 }[2], [x11]
	str	q30, [sp, #4368]                ; 16-byte Spill
	str	q26, [sp, #4352]                ; 16-byte Spill
	str	q20, [sp, #4432]                ; 16-byte Spill
	tbnz	w9, #7, LBB1_665
	b	LBB1_666
LBB1_915:                               ; %cond.store1790
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #272]                  ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_670
LBB1_916:                               ; %cond.store1794
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #272]                  ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	fmov.4s	v3, #1.00000000
	ldr	q4, [sp, #4720]                 ; 16-byte Reload
	tbz	w9, #2, LBB1_671
LBB1_917:                               ; %cond.store1798
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #288]                  ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #3, LBB1_672
	b	LBB1_673
LBB1_918:                               ; %cond.store1806
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #304]                  ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	tbz	w9, #5, LBB1_675
LBB1_919:                               ; %cond.store1810
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #304]                  ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #6, LBB1_676
LBB1_920:                               ; %cond.store1814
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #320]                  ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #7, LBB1_677
	b	LBB1_678
LBB1_921:                               ; %cond.store1823
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1392]                 ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_680
LBB1_922:                               ; %cond.store1827
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1392]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #2, LBB1_681
LBB1_923:                               ; %cond.store1831
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1408]                 ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #3, LBB1_682
	b	LBB1_683
LBB1_924:                               ; %cond.store1839
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1424]                 ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	tbz	w9, #5, LBB1_685
LBB1_925:                               ; %cond.store1843
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1424]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #6, LBB1_686
LBB1_926:                               ; %cond.store1847
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1440]                 ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #7, LBB1_687
	b	LBB1_688
LBB1_927:                               ; %cond.store1856
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1328]                 ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_690
LBB1_928:                               ; %cond.store1860
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1328]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #2, LBB1_691
LBB1_929:                               ; %cond.store1864
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1344]                 ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #3, LBB1_692
	b	LBB1_693
LBB1_930:                               ; %cond.store1872
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1360]                 ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	tbz	w9, #5, LBB1_695
LBB1_931:                               ; %cond.store1876
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1360]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #6, LBB1_696
LBB1_932:                               ; %cond.store1880
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1376]                 ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #7, LBB1_697
	b	LBB1_698
LBB1_933:                               ; %cond.store1889
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1264]                 ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_700
LBB1_934:                               ; %cond.store1893
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1264]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #2, LBB1_701
LBB1_935:                               ; %cond.store1897
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1280]                 ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #3, LBB1_702
	b	LBB1_703
LBB1_936:                               ; %cond.store1905
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1296]                 ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	tbz	w9, #5, LBB1_705
LBB1_937:                               ; %cond.store1909
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1296]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #6, LBB1_706
LBB1_938:                               ; %cond.store1913
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1312]                 ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #7, LBB1_707
	b	LBB1_708
LBB1_939:                               ; %cond.store1922
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1200]                 ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_710
LBB1_940:                               ; %cond.store1926
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1200]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #2, LBB1_711
LBB1_941:                               ; %cond.store1930
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1216]                 ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #3, LBB1_712
	b	LBB1_713
LBB1_942:                               ; %cond.store1938
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1232]                 ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	tbz	w9, #5, LBB1_715
LBB1_943:                               ; %cond.store1942
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1232]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #6, LBB1_716
LBB1_944:                               ; %cond.store1946
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1248]                 ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #7, LBB1_717
	b	LBB1_718
LBB1_945:                               ; %cond.store1955
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1136]                 ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_720
LBB1_946:                               ; %cond.store1959
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1136]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #2, LBB1_721
LBB1_947:                               ; %cond.store1963
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1152]                 ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #3, LBB1_722
	b	LBB1_723
LBB1_948:                               ; %cond.store1971
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1168]                 ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	tbz	w9, #5, LBB1_725
LBB1_949:                               ; %cond.store1975
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1168]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #6, LBB1_726
LBB1_950:                               ; %cond.store1979
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1184]                 ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #7, LBB1_727
	b	LBB1_728
LBB1_951:                               ; %cond.store1988
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1072]                 ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_730
LBB1_952:                               ; %cond.store1992
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1072]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #2, LBB1_731
LBB1_953:                               ; %cond.store1996
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1088]                 ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #3, LBB1_732
	b	LBB1_733
LBB1_954:                               ; %cond.store2004
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1104]                 ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	tbz	w9, #5, LBB1_735
LBB1_955:                               ; %cond.store2008
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1104]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #6, LBB1_736
LBB1_956:                               ; %cond.store2012
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1120]                 ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #7, LBB1_737
	b	LBB1_738
LBB1_957:                               ; %cond.store2021
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1008]                 ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_740
LBB1_958:                               ; %cond.store2025
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1008]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #2, LBB1_741
LBB1_959:                               ; %cond.store2029
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1024]                 ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #3, LBB1_742
	b	LBB1_743
LBB1_960:                               ; %cond.store2037
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1040]                 ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	tbz	w9, #5, LBB1_745
LBB1_961:                               ; %cond.store2041
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1040]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #6, LBB1_746
LBB1_962:                               ; %cond.store2045
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #1056]                 ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #7, LBB1_747
	b	LBB1_748
LBB1_963:                               ; %cond.store2054
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #944]                  ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_750
LBB1_964:                               ; %cond.store2058
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #944]                  ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #2, LBB1_751
LBB1_965:                               ; %cond.store2062
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #960]                  ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #3, LBB1_752
	b	LBB1_753
LBB1_966:                               ; %cond.store2070
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #976]                  ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	tbz	w9, #5, LBB1_755
LBB1_967:                               ; %cond.store2074
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #976]                  ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #6, LBB1_756
LBB1_968:                               ; %cond.store2078
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #992]                  ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #7, LBB1_757
	b	LBB1_758
LBB1_969:                               ; %cond.store2087
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #880]                  ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_760
LBB1_970:                               ; %cond.store2091
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #880]                  ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #2, LBB1_761
LBB1_971:                               ; %cond.store2095
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #896]                  ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #3, LBB1_762
	b	LBB1_763
LBB1_972:                               ; %cond.store2103
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #912]                  ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	tbz	w9, #5, LBB1_765
LBB1_973:                               ; %cond.store2107
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #912]                  ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #6, LBB1_766
LBB1_974:                               ; %cond.store2111
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #928]                  ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #7, LBB1_767
	b	LBB1_768
LBB1_975:                               ; %cond.store2120
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #816]                  ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_770
LBB1_976:                               ; %cond.store2124
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #816]                  ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #2, LBB1_771
LBB1_977:                               ; %cond.store2128
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #832]                  ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #3, LBB1_772
	b	LBB1_773
LBB1_978:                               ; %cond.store2136
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #848]                  ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	tbz	w9, #5, LBB1_775
LBB1_979:                               ; %cond.store2140
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #848]                  ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #6, LBB1_776
LBB1_980:                               ; %cond.store2144
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #864]                  ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #7, LBB1_777
	b	LBB1_778
LBB1_981:                               ; %cond.store2153
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #752]                  ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_780
LBB1_982:                               ; %cond.store2157
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #752]                  ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #2, LBB1_781
LBB1_983:                               ; %cond.store2161
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #768]                  ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #3, LBB1_782
	b	LBB1_783
LBB1_984:                               ; %cond.store2169
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #784]                  ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	tbz	w9, #5, LBB1_785
LBB1_985:                               ; %cond.store2173
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #784]                  ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #6, LBB1_786
LBB1_986:                               ; %cond.store2177
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #800]                  ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #7, LBB1_787
	b	LBB1_788
LBB1_987:                               ; %cond.store2186
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #688]                  ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_790
LBB1_988:                               ; %cond.store2190
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #688]                  ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #2, LBB1_791
LBB1_989:                               ; %cond.store2194
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #704]                  ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #3, LBB1_792
	b	LBB1_793
LBB1_990:                               ; %cond.store2202
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #720]                  ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	tbz	w9, #5, LBB1_795
LBB1_991:                               ; %cond.store2206
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #720]                  ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #6, LBB1_796
LBB1_992:                               ; %cond.store2210
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #736]                  ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #7, LBB1_797
	b	LBB1_798
LBB1_993:                               ; %cond.store2219
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #624]                  ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_800
LBB1_994:                               ; %cond.store2223
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #624]                  ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #2, LBB1_801
LBB1_995:                               ; %cond.store2227
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #640]                  ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #3, LBB1_802
	b	LBB1_803
LBB1_996:                               ; %cond.store2235
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #656]                  ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	tbz	w9, #5, LBB1_805
LBB1_997:                               ; %cond.store2239
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #656]                  ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #6, LBB1_806
LBB1_998:                               ; %cond.store2243
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #672]                  ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #7, LBB1_807
	b	LBB1_808
LBB1_999:                               ; %cond.store2252
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #560]                  ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_810
LBB1_1000:                              ; %cond.store2256
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #560]                  ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #2, LBB1_811
LBB1_1001:                              ; %cond.store2260
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #576]                  ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #3, LBB1_812
	b	LBB1_813
LBB1_1002:                              ; %cond.store2268
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #592]                  ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	tbz	w9, #5, LBB1_815
LBB1_1003:                              ; %cond.store2272
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #592]                  ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #6, LBB1_816
LBB1_1004:                              ; %cond.store2276
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #608]                  ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #7, LBB1_817
	b	LBB1_818
LBB1_1005:                              ; %cond.store2285
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #496]                  ; 16-byte Reload
	fmov	x11, d1
	str	s19, [x11]
	and	w9, w9, #0xff
	ldr	q15, [sp, #4496]                ; 16-byte Reload
	tbz	w9, #1, LBB1_820
LBB1_1006:                              ; %cond.store2289
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #496]                  ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v19 }[1], [x11]
	tbz	w9, #2, LBB1_821
LBB1_1007:                              ; %cond.store2293
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #512]                  ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v19 }[2], [x11]
	tbnz	w9, #3, LBB1_822
	b	LBB1_823
LBB1_1008:                              ; %cond.store2301
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #528]                  ; 16-byte Reload
	fmov	x11, d1
	str	s16, [x11]
	str	q24, [sp, #4544]                ; 16-byte Spill
	ldr	q18, [sp, #3520]                ; 16-byte Reload
	ldr	q22, [sp, #4656]                ; 16-byte Reload
	ldr	q8, [sp, #4640]                 ; 16-byte Reload
	tbz	w9, #5, LBB1_825
LBB1_1009:                              ; %cond.store2305
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #528]                  ; 16-byte Reload
	mov.d	x11, v1[1]
	st1.s	{ v16 }[1], [x11]
	mov.16b	v24, v23
	tbz	w9, #6, LBB1_826
LBB1_1010:                              ; %cond.store2309
                                        ;   in Loop: Header=BB1_50 Depth=2
	ldr	q1, [sp, #544]                  ; 16-byte Reload
	fmov	x11, d1
	st1.s	{ v16 }[2], [x11]
	ldr	q23, [sp, #4592]                ; 16-byte Reload
	tbnz	w9, #7, LBB1_827
	b	LBB1_828
LBB1_1011:                              ; %direct.schedule.35.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x8, #0                          ; =0x0
	ldp	q1, q3, [sp, #112]              ; 32-byte Folded Reload
	xtn.2s	v1, v1
	movi.2s	v5, #96
	umull.2d	v1, v1, v5
	ldp	q2, q4, [sp, #144]              ; 32-byte Folded Reload
	xtn.2s	v2, v2
	umull.2d	v2, v2, v5
	xtn.2s	v3, v3
	umull.2d	v3, v3, v5
	xtn.2s	v4, v4
	umull.2d	v4, v4, v5
	ldr	w23, [sp, #108]                 ; 4-byte Reload
	ldp	x26, x24, [sp, #88]             ; 16-byte Folded Reload
	ldr	x12, [sp, #240]                 ; 8-byte Reload
	ldp	w14, w11, [sp, #232]            ; 8-byte Folded Reload
	ldp	x15, x13, [sp, #176]            ; 16-byte Folded Reload
	b	LBB1_1013
LBB1_1012:                              ; %else2480
                                        ;   in Loop: Header=BB1_1013 Depth=2
	add	x8, x8, #1
	cmp	x8, #96
	b.eq	LBB1_2
LBB1_1013:                              ; %direct.true460.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w9, s7
	dup.2d	v5, x8
	add.2d	v16, v5, v1
	add	x10, x13, x8, lsl #5
	ldp	q18, q17, [x10]
	and.16b	v18, v6, v18
	fdiv.4s	v18, v18, v28
	shl.2d	v19, v16, #2
	dup.2d	v16, x15
	add.2d	v19, v16, v19
	tbnz	w9, #0, LBB1_1021
; %bb.1014:                             ; %else2452
                                        ;   in Loop: Header=BB1_1013 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_1022
LBB1_1015:                              ; %else2456
                                        ;   in Loop: Header=BB1_1013 Depth=2
	add.2d	v19, v5, v2
	shl.2d	v19, v19, #2
	add.2d	v19, v16, v19
	tbnz	w9, #2, LBB1_1023
LBB1_1016:                              ; %else2460
                                        ;   in Loop: Header=BB1_1013 Depth=2
	tbnz	w9, #3, LBB1_1024
LBB1_1017:                              ; %else2464
                                        ;   in Loop: Header=BB1_1013 Depth=2
	add.2d	v18, v5, v3
	and.16b	v17, v0, v17
	fdiv.4s	v17, v17, v20
	shl.2d	v18, v18, #2
	add.2d	v18, v16, v18
	tbnz	w9, #4, LBB1_1025
LBB1_1018:                              ; %else2468
                                        ;   in Loop: Header=BB1_1013 Depth=2
	tbnz	w9, #5, LBB1_1026
LBB1_1019:                              ; %else2472
                                        ;   in Loop: Header=BB1_1013 Depth=2
	add.2d	v5, v5, v4
	shl.2d	v5, v5, #2
	add.2d	v5, v16, v5
	tbnz	w9, #6, LBB1_1027
LBB1_1020:                              ; %else2476
                                        ;   in Loop: Header=BB1_1013 Depth=2
	tbz	w9, #7, LBB1_1012
	b	LBB1_1028
LBB1_1021:                              ; %cond.store2449
                                        ;   in Loop: Header=BB1_1013 Depth=2
	fmov	x10, d19
	str	s18, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_1015
LBB1_1022:                              ; %cond.store2453
                                        ;   in Loop: Header=BB1_1013 Depth=2
	mov.d	x10, v19[1]
	st1.s	{ v18 }[1], [x10]
	add.2d	v19, v5, v2
	shl.2d	v19, v19, #2
	add.2d	v19, v16, v19
	tbz	w9, #2, LBB1_1016
LBB1_1023:                              ; %cond.store2457
                                        ;   in Loop: Header=BB1_1013 Depth=2
	fmov	x10, d19
	st1.s	{ v18 }[2], [x10]
	tbz	w9, #3, LBB1_1017
LBB1_1024:                              ; %cond.store2461
                                        ;   in Loop: Header=BB1_1013 Depth=2
	mov.d	x10, v19[1]
	st1.s	{ v18 }[3], [x10]
	add.2d	v18, v5, v3
	and.16b	v17, v0, v17
	fdiv.4s	v17, v17, v20
	shl.2d	v18, v18, #2
	add.2d	v18, v16, v18
	tbz	w9, #4, LBB1_1018
LBB1_1025:                              ; %cond.store2465
                                        ;   in Loop: Header=BB1_1013 Depth=2
	fmov	x10, d18
	str	s17, [x10]
	tbz	w9, #5, LBB1_1019
LBB1_1026:                              ; %cond.store2469
                                        ;   in Loop: Header=BB1_1013 Depth=2
	mov.d	x10, v18[1]
	st1.s	{ v17 }[1], [x10]
	add.2d	v5, v5, v4
	shl.2d	v5, v5, #2
	add.2d	v5, v16, v5
	tbz	w9, #6, LBB1_1020
LBB1_1027:                              ; %cond.store2473
                                        ;   in Loop: Header=BB1_1013 Depth=2
	fmov	x10, d5
	st1.s	{ v17 }[2], [x10]
	tbz	w9, #7, LBB1_1012
LBB1_1028:                              ; %cond.store2477
                                        ;   in Loop: Header=BB1_1013 Depth=2
	mov.d	x9, v5[1]
	st1.s	{ v17 }[3], [x9]
	b	LBB1_1012
LBB1_1029:
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #1488
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
LBB1_1030:                              ; %block.batch.exit
	ret
	.loh AdrpLdr	Lloh174, Lloh175
	.loh AdrpAdrp	Lloh172, Lloh174
	.loh AdrpLdr	Lloh172, Lloh173
	.loh AdrpAdrp	Lloh170, Lloh172
	.loh AdrpLdr	Lloh170, Lloh171
	.loh AdrpAdrp	Lloh168, Lloh170
	.loh AdrpLdr	Lloh168, Lloh169
	.loh AdrpAdrp	Lloh166, Lloh168
	.loh AdrpLdr	Lloh166, Lloh167
	.loh AdrpAdrp	Lloh164, Lloh166
	.loh AdrpLdr	Lloh164, Lloh165
	.loh AdrpLdr	Lloh302, Lloh303
	.loh AdrpAdrp	Lloh300, Lloh302
	.loh AdrpLdr	Lloh300, Lloh301
	.loh AdrpAdrp	Lloh298, Lloh300
	.loh AdrpLdr	Lloh298, Lloh299
	.loh AdrpAdrp	Lloh296, Lloh298
	.loh AdrpLdr	Lloh296, Lloh297
	.loh AdrpAdrp	Lloh294, Lloh296
	.loh AdrpLdr	Lloh294, Lloh295
	.loh AdrpAdrp	Lloh292, Lloh294
	.loh AdrpLdr	Lloh292, Lloh293
	.loh AdrpAdrp	Lloh290, Lloh292
	.loh AdrpLdr	Lloh290, Lloh291
	.loh AdrpAdrp	Lloh288, Lloh290
	.loh AdrpLdr	Lloh288, Lloh289
	.loh AdrpAdrp	Lloh286, Lloh288
	.loh AdrpLdr	Lloh286, Lloh287
	.loh AdrpAdrp	Lloh284, Lloh286
	.loh AdrpLdr	Lloh284, Lloh285
	.loh AdrpAdrp	Lloh282, Lloh284
	.loh AdrpLdr	Lloh282, Lloh283
	.loh AdrpAdrp	Lloh280, Lloh282
	.loh AdrpLdr	Lloh280, Lloh281
	.loh AdrpAdrp	Lloh278, Lloh280
	.loh AdrpLdr	Lloh278, Lloh279
	.loh AdrpAdrp	Lloh276, Lloh278
	.loh AdrpLdr	Lloh276, Lloh277
	.loh AdrpAdrp	Lloh274, Lloh276
	.loh AdrpLdr	Lloh274, Lloh275
	.loh AdrpAdrp	Lloh272, Lloh274
	.loh AdrpLdr	Lloh272, Lloh273
	.loh AdrpAdrp	Lloh270, Lloh272
	.loh AdrpLdr	Lloh270, Lloh271
	.loh AdrpAdrp	Lloh268, Lloh270
	.loh AdrpLdr	Lloh268, Lloh269
	.loh AdrpAdrp	Lloh266, Lloh268
	.loh AdrpLdr	Lloh266, Lloh267
	.loh AdrpAdrp	Lloh264, Lloh266
	.loh AdrpLdr	Lloh264, Lloh265
	.loh AdrpAdrp	Lloh262, Lloh264
	.loh AdrpLdr	Lloh262, Lloh263
	.loh AdrpAdrp	Lloh260, Lloh262
	.loh AdrpLdr	Lloh260, Lloh261
	.loh AdrpAdrp	Lloh258, Lloh260
	.loh AdrpLdr	Lloh258, Lloh259
	.loh AdrpAdrp	Lloh256, Lloh258
	.loh AdrpLdr	Lloh256, Lloh257
	.loh AdrpAdrp	Lloh254, Lloh256
	.loh AdrpLdr	Lloh254, Lloh255
	.loh AdrpAdrp	Lloh252, Lloh254
	.loh AdrpLdr	Lloh252, Lloh253
	.loh AdrpAdrp	Lloh250, Lloh252
	.loh AdrpLdr	Lloh250, Lloh251
	.loh AdrpAdrp	Lloh248, Lloh250
	.loh AdrpLdr	Lloh248, Lloh249
	.loh AdrpAdrp	Lloh246, Lloh248
	.loh AdrpLdr	Lloh246, Lloh247
	.loh AdrpAdrp	Lloh244, Lloh246
	.loh AdrpLdr	Lloh244, Lloh245
	.loh AdrpAdrp	Lloh242, Lloh244
	.loh AdrpLdr	Lloh242, Lloh243
	.loh AdrpAdrp	Lloh240, Lloh242
	.loh AdrpLdr	Lloh240, Lloh241
	.loh AdrpAdrp	Lloh238, Lloh240
	.loh AdrpLdr	Lloh238, Lloh239
	.loh AdrpAdrp	Lloh236, Lloh238
	.loh AdrpLdr	Lloh236, Lloh237
	.loh AdrpAdrp	Lloh234, Lloh236
	.loh AdrpLdr	Lloh234, Lloh235
	.loh AdrpAdrp	Lloh232, Lloh234
	.loh AdrpLdr	Lloh232, Lloh233
	.loh AdrpAdrp	Lloh230, Lloh232
	.loh AdrpLdr	Lloh230, Lloh231
	.loh AdrpAdrp	Lloh228, Lloh230
	.loh AdrpLdr	Lloh228, Lloh229
	.loh AdrpAdrp	Lloh226, Lloh228
	.loh AdrpLdr	Lloh226, Lloh227
	.loh AdrpAdrp	Lloh224, Lloh226
	.loh AdrpLdr	Lloh224, Lloh225
	.loh AdrpAdrp	Lloh222, Lloh224
	.loh AdrpLdr	Lloh222, Lloh223
	.loh AdrpAdrp	Lloh220, Lloh222
	.loh AdrpLdr	Lloh220, Lloh221
	.loh AdrpAdrp	Lloh218, Lloh220
	.loh AdrpLdr	Lloh218, Lloh219
	.loh AdrpAdrp	Lloh216, Lloh218
	.loh AdrpLdr	Lloh216, Lloh217
	.loh AdrpAdrp	Lloh214, Lloh216
	.loh AdrpLdr	Lloh214, Lloh215
	.loh AdrpAdrp	Lloh212, Lloh214
	.loh AdrpLdr	Lloh212, Lloh213
	.loh AdrpAdrp	Lloh210, Lloh212
	.loh AdrpLdr	Lloh210, Lloh211
	.loh AdrpAdrp	Lloh208, Lloh210
	.loh AdrpLdr	Lloh208, Lloh209
	.loh AdrpAdrp	Lloh206, Lloh208
	.loh AdrpLdr	Lloh206, Lloh207
	.loh AdrpAdrp	Lloh204, Lloh206
	.loh AdrpLdr	Lloh204, Lloh205
	.loh AdrpAdrp	Lloh202, Lloh204
	.loh AdrpLdr	Lloh202, Lloh203
	.loh AdrpLdr	Lloh200, Lloh201
	.loh AdrpLdr	Lloh198, Lloh199
	.loh AdrpLdr	Lloh196, Lloh197
	.loh AdrpLdr	Lloh194, Lloh195
	.loh AdrpLdr	Lloh192, Lloh193
	.loh AdrpAdrp	Lloh190, Lloh192
	.loh AdrpLdr	Lloh190, Lloh191
	.loh AdrpAdrp	Lloh188, Lloh190
	.loh AdrpLdr	Lloh188, Lloh189
	.loh AdrpAdrp	Lloh186, Lloh188
	.loh AdrpLdr	Lloh186, Lloh187
	.loh AdrpAdrp	Lloh184, Lloh186
	.loh AdrpLdr	Lloh184, Lloh185
	.loh AdrpAdrp	Lloh182, Lloh184
	.loh AdrpLdr	Lloh182, Lloh183
	.loh AdrpAdrp	Lloh180, Lloh182
	.loh AdrpLdr	Lloh180, Lloh181
	.loh AdrpAdrp	Lloh178, Lloh180
	.loh AdrpLdr	Lloh178, Lloh179
	.loh AdrpAdrp	Lloh176, Lloh178
	.loh AdrpLdr	Lloh176, Lloh177
	.loh AdrpLdr	Lloh310, Lloh311
	.loh AdrpAdrp	Lloh308, Lloh310
	.loh AdrpLdr	Lloh308, Lloh309
	.loh AdrpAdrp	Lloh306, Lloh308
	.loh AdrpLdr	Lloh306, Lloh307
	.loh AdrpAdrp	Lloh304, Lloh306
	.loh AdrpLdr	Lloh304, Lloh305
	.loh AdrpLdr	Lloh318, Lloh319
	.loh AdrpAdrp	Lloh316, Lloh318
	.loh AdrpLdr	Lloh316, Lloh317
	.loh AdrpAdrp	Lloh314, Lloh316
	.loh AdrpLdr	Lloh314, Lloh315
	.loh AdrpAdrp	Lloh312, Lloh314
	.loh AdrpLdr	Lloh312, Lloh313
	.loh AdrpLdr	Lloh326, Lloh327
	.loh AdrpAdrp	Lloh324, Lloh326
	.loh AdrpLdr	Lloh324, Lloh325
	.loh AdrpAdrp	Lloh322, Lloh324
	.loh AdrpLdr	Lloh322, Lloh323
	.loh AdrpAdrp	Lloh320, Lloh322
	.loh AdrpLdr	Lloh320, Lloh321
                                        ; -- End function
.subsections_via_symbols

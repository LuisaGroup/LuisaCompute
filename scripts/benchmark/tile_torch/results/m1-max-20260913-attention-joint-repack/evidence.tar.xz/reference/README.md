# 固定 Tile baseline 的独立 CPU attention 参照

这份补充实验与主目录的 30 组配对实验独立。三个 shape 固定比较新构建的
`m4-c4-simplified`，不是看过数据后挑最快候选；不修改主实验的 freeze 或源码。

执行前由主任务统一确认没有其他 build/capture/native benchmark 并发。
依次用 `/tmp/luisa-attention-joint-env.MxOWzT/bin/python run.py` 执行：

1. `freeze`：要求主 30 captures 全部完成，冻结来源与固定 baseline。
2. `validate`：现成 22 项纯 Python 协议测试，再现成 24 项 validation-only native checks。
3. `prepare`：三组全部 prepare 完成；现成 probe 同时生成 NEON 和 Accelerate 两入口。
4. `replay`：固定 case-major、NEON/Accelerate 顺序，共 6 组 3×ABBA×7 样本。
5. 性能停止后执行 `audit.py`，将 stdout 保存为新审计结果；它不加载 native 代码。

所有阶段和命令拒绝覆盖旧尝试，失败与 stderr 均保留。`native_attention_probe.py`
未修改；本 driver 额外核验每个 Tile visit 与其 own capture 逐 bit 一致，audit 再次核验。
跨 reference 算法只要求完整 FP64 oracle，允许显式重结合、BLAS 内部 FMA/分配与不同
scratch，但不降低 FP32 输入/输出精度。计时包含完整 native entry 与 BLAS 内部工作，
排除 Runtime/Python/JIT/调用方分配和验证。单线程由 BLAS TLS set/query 回执确认，
不把环境变量或这一回执说成独立内部线程 profiling。

benchmark 来源与完整比较边界见 `predeclared.json`。此目录当前只是预声明脚本，
没有执行成绩；build/protocol/selftest/prepare/replay 必须实际通过后才能给出结论。

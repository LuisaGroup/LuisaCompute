#!/usr/bin/env python3
"""Supplemental fixed-baseline attention reference cohort, never executes on import.

Explicit phases: freeze -> validate -> prepare -> replay. The parent task must
serialize these commands with all builds, captures and performance experiments.
Uses native_attention_probe.py unchanged. No production compiler edits or parent
plan mutation. Each external command gets an isolated process group and timeout.
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

ROOT = Path('/Users/mike/CLionProjects/luisa')
OUT = Path(__file__).resolve().parent
PARENT = OUT.parent
PYTHON = Path('/tmp/luisa-attention-joint-env.MxOWzT/bin/python')
BENCH = ROOT / 'scripts/benchmark/tile_torch'
RUNNER = BENCH / 'native_attention_probe.py'
LLVM = Path('/opt/homebrew/opt/llvm/bin')
CASES = [('decode-mha-d64', [1, 8, 8, 1, 2048, 64, 64]),
         ('decode-long-kv', [1, 16, 4, 1, 8193, 128, 128]),
         ('prefill-q8', [1, 4, 2, 64, 129, 32, 48])]
VARIANTS = ('online_neon', 'dense_accelerate')
BASELINE = 'm4-c4-simplified'
SOURCES = [RUNNER, BENCH / 'native_attention_probe.cpp', BENCH / 'test_native_attention_probe.py',
           BENCH / 'native_tile.py', BENCH / 'native_tile_replay.cpp',
           ROOT / 'src/backends/simd/llvm/llvm_schedule_codegen.h']


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def save(path, value, progress=False):
    with Path(path).open('w' if progress else 'x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')


def inventory(directory):
    result = {}
    for path in sorted(directory.rglob('*')):
        require(not path.is_symlink(), 'symlinked evidence')
        if path.is_file():
            result[str(path.relative_to(directory))] = sha(path)
    return result


def probe_module():
    sys.path.insert(0, str(BENCH))
    import native_attention_probe
    return native_attention_probe


def field(text, name, expected):
    matches = re.findall(r'\b' + re.escape(name) + r'=([^;\s]+)', text)
    require(matches == [expected], 'missing/duplicate baseline control: ' + name)


def baseline(case, dims):
    path = PARENT / f'prepared-{case}-{BASELINE}/prepared.json'
    probe = probe_module()
    entry = probe.tile.verify(path)
    probe.verify_files(path.parent, entry['files'])
    require(entry['name'] == BASELINE and probe.baseline_contract(entry)['dimensions'] == dims,
            'wrong fixed baseline')
    text = entry['metadata']['realization']
    for key, value in dict(native_mma_vector_width='4', native_copy_vector_width='4',
                           full_packet_simplification_requested='true', local_lanes='1').items():
        field(text, key, value)
    return path, entry


def freeze(create=False):
    declaration = load(OUT / 'predeclared.json')
    require(declaration['cases'] == [dict(case=c, dimensions=d) for c, d in CASES] and
            declaration['baseline_variant'] == BASELINE and declaration['references'] == list(VARIANTS),
            'predeclared fixed arms changed')
    require([declaration[k] for k in ('cycles', 'samples', 'warmup_ms', 'target_ms')] == [3, 7, 30, 15],
            'predeclared timer changed')
    parent = load(PARENT / 'plan.json')
    captures = load(PARENT / 'captures.json')
    require(captures['status'] == 'complete' and captures['plan_sha256'] == sha(PARENT / 'plan.json'),
            'all parent captures must complete before reference freeze')
    require(len(captures['cases']) == 6 and all(row['status'] == 'OK' and len(row['variants']) == 5
                                              for row in captures['cases']), 'incomplete parent capture matrix')
    identities = {str(path): sha(path) for path in [*SOURCES, PYTHON, LLVM / 'clang++',
                                                   OUT / 'run.py', OUT / 'audit.py', OUT / 'predeclared.json',
                                                   PARENT / 'plan.json', PARENT / 'captures.json']}
    baselines = []
    for case, dims in CASES:
        path, entry = baseline(case, dims)
        identities[str(path)] = sha(path)
        captured = next(row for row in captures['cases'] if row['case'] == case)
        variant = next(row for row in captured['variants'] if row['label'] == case + '-' + BASELINE)
        require(variant['prepared_manifest_sha256'] == sha(path), 'parent capture manifest receipt mismatch')
        baselines.append(dict(case=case, dimensions=dims, original=str(path), manifest_sha256=sha(path),
                              files=entry['files'], captured_output_sha256=entry['files']['captured.f32']))
    expected = dict(declaration=declaration, identities=identities, baselines=baselines,
                    parent_plan_sha256=sha(PARENT / 'plan.json'), parent_captures_sha256=sha(PARENT / 'captures.json'),
                    python_launcher=str(PYTHON), python=sys.version,
                    math=probe_module().MATH, boundary=probe_module().BOUNDARY)
    plan_path = OUT / 'plan.json'
    if create:
        require(not plan_path.exists(), 'reference plan already frozen')
        for source, destination in ((PARENT / 'plan.json', OUT / 'parent-plan.json'),
                                    (PARENT / 'captures.json', OUT / 'parent-captures.json')):
            with destination.open('xb') as stream:
                stream.write(source.read_bytes())
        save(plan_path, dict(**expected, frozen_unix=time.time(),
                            scope='Independent supplemental cohort, no parent timing selection or source mutation.'))
    else:
        actual = load(plan_path)
        require(all(actual.get(k) == v for k, v in expected.items()), 'reference freeze identity/controls changed')
    return sha(plan_path)


def environment():
    result = {k: v for k, v in os.environ.items() if not k.startswith(('LUISA_', 'MTL_'))}
    result.update(OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1',
                  PYTHONDONTWRITEBYTECODE='1')
    return result


def command(argv, stem, timeout):
    argv = list(map(str, argv))
    paths = [OUT / (stem + suffix) for suffix in ('.command.json', '.result.json', '.stdout', '.stderr')]
    require(not any(path.exists() for path in paths), 'attempt exists; no selective retry: ' + stem)
    env = environment()
    record = dict(argv=argv, cwd=str(ROOT), started=time.time(), timeout_s=timeout,
                  process_group_isolated=True, environment={key: env[key] for key in
                    ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS', 'PYTHONDONTWRITEBYTECODE')})
    save(paths[0], record)
    stdout = stderr = b''
    process = None
    try:
        process = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, start_new_session=True)
        try:
            stdout, stderr = process.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            record['error'] = 'process-group timeout'
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            stdout, stderr = process.communicate()
        record['returncode'] = process.returncode
        require(process.returncode == 0 and 'error' not in record, 'failed command: ' + stem)
        return stdout, stderr
    except BaseException as error:
        if process is not None and process.poll() is None:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            stdout, stderr = process.communicate()
            record['returncode'] = process.returncode
        # Keep a specific timeout cause instead of replacing it with the
        # generic nonzero-exit admission error raised immediately afterwards.
        record.setdefault('error', str(error))
        raise
    finally:
        for path, content in zip(paths[2:], (stdout, stderr)):
            with path.open('xb') as stream:
                stream.write(content)
        record.update(finished=time.time(), stdout_sha256=sha(paths[2]), stderr_sha256=sha(paths[3]))
        save(paths[1], record)


def validate():
    plan_hash = freeze()
    require(not (OUT / 'validation.json').exists(), 'validation already attempted')
    report = dict(status='running', started=time.time(), plan_sha256=plan_hash)
    save(OUT / 'validation.json', report)
    try:
        stdout, stderr = command([PYTHON, BENCH / 'test_native_attention_probe.py'], 'protocol-tests', 120)
        require(re.search(rb'Ran 22 tests.*\n\nOK\s*$', stderr, re.S), 'expected complete 22-test protocol suite')
        _, stderr = command([PYTHON, RUNNER, 'selftest', '--output', OUT / 'native-selftest', '--llvm', LLVM],
                            'native-selftest', 300)
        require(not stderr, 'selftest stderr requires review')
        native = load(OUT / 'native-selftest/results.json')
        require(native['status'] == 'passed' and native['expected_checks'] == len(native['checks']) == 24,
                'native validation matrix incomplete')
        require(all(row['valid'] is True and row['samples_us'] == [] and row['repetitions'] == 0
                    for row in native['checks']), 'selftest must be validation-only and complete')
        require(freeze() == plan_hash, 'source changed during validation')
        report.update(status='passed', protocol_tests=22, native_checks=24,
                      selftest_sha256=sha(OUT / 'native-selftest/results.json'))
    except BaseException as error:
        report.update(status='error', error=str(error))
        raise
    finally:
        report['finished'] = time.time()
        save(OUT / 'validation.json', report, True)


def prepare():
    plan_hash = freeze()
    validation = load(OUT / 'validation.json')
    require(validation['status'] == 'passed' and validation['plan_sha256'] == plan_hash,
            'protocol/native validation must precede preparation')
    require(not (OUT / 'preparations.json').exists(), 'preparation already attempted')
    report = dict(status='running', started=time.time(), plan_sha256=plan_hash,
                  cases=[dict(case=case, status='NotRun') for case, _ in CASES])
    save(OUT / 'preparations.json', report)
    try:
        for row, (case, dims) in zip(report['cases'], CASES):
            path, _ = baseline(case, dims)
            row.update(status='running')
            save(OUT / 'preparations.json', report, True)
            _, stderr = command([PYTHON, RUNNER, 'prepare', '--tile', path, '--output', OUT / ('prepared-' + case),
                                 '--llvm', LLVM], 'prepare-' + case, 300)
            require(not stderr, 'prepare stderr requires review')
            bundle = OUT / ('prepared-' + case) / 'probe.json'
            prepared, entry = probe_module().verify(bundle)
            require(prepared['baseline_sha256'] == sha(path) and entry['name'] == BASELINE,
                    'probe changed fixed Tile baseline')
            row.update(status='prepared', bundle_sha256=sha(bundle))
            save(OUT / 'preparations.json', report, True)
        require(freeze() == plan_hash, 'identity changed during preparation')
        report['status'] = 'passed'
    except BaseException as error:
        row.update(status='error', error=str(error))
        report.update(status='error', error=str(error))
        raise
    finally:
        report['finished'] = time.time()
        save(OUT / 'preparations.json', report, True)


def replay():
    plan_hash = freeze()
    preparations = load(OUT / 'preparations.json')
    require(preparations['status'] == 'passed' and preparations['plan_sha256'] == plan_hash,
            'all three preparations must precede any reference timing')
    require(not (OUT / 'replays.json').exists(), 'reference timing already attempted')
    report = dict(status='running', started=time.time(), load_before=os.getloadavg(), plan_sha256=plan_hash,
                  comparisons=[dict(case=case, variant=variant, status='NotRun') for case, _ in CASES for variant in VARIANTS])
    save(OUT / 'replays.json', report)
    try:
        for row in report['comparisons']:
            case, variant = row['case'], row['variant']
            row.update(status='running')
            save(OUT / 'replays.json', report, True)
            bundle = OUT / ('prepared-' + case) / 'probe.json'
            captured = sha(bundle.parent / 'tile/captured.f32')
            directory = OUT / ('replay-' + case + '-' + variant)
            _, stderr = command([PYTHON, RUNNER, 'replay', '--bundle', bundle, '--variant', variant,
                                 '--output', directory, '--cycles', '3', '--samples', '7',
                                 '--warmup-ms', '30', '--target-ms', '15'], 'replay-' + case + '-' + variant, 120)
            require(not stderr, 'replay stderr requires review')
            result = load(directory / 'results.json')
            require(result['status'] == 'passed' and len(result['visits']) == 12, 'incomplete reference ABBA cohort')
            tile_visits = [visit for visit in result['visits'] if visit['variant'] == 'tile']
            require(len(tile_visits) == 6 and all(visit['output_sha256'] == captured and
                    sha(directory / visit['output']) == captured for visit in tile_visits),
                    'Tile reference replay differs from its own captured output')
            row.update(status='passed', results_sha256=sha(directory / 'results.json'),
                       tile_own_capture_bitwise=True, captured_output_sha256=captured)
            save(OUT / 'replays.json', report, True)
            print(case, variant, 'passed', flush=True)
        require(freeze() == plan_hash, 'identity changed during reference timing')
        report['status'] = 'passed'
    except BaseException as error:
        row.update(status='error', error=str(error))
        report.update(status='error', error=str(error))
        raise
    finally:
        report.update(finished=time.time(), load_after=os.getloadavg())
        save(OUT / 'replays.json', report, True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=('freeze', 'validate', 'prepare', 'replay'))
    args = parser.parse_args()
    if args.phase == 'freeze':
        print(freeze(True))
    else:
        globals()[args.phase]()

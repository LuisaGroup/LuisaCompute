#!/usr/bin/env python3
"""Independent offline reference-cohort audit; reads local evidence, loads no native code.

Prints JSON to stdout. Absolute producer, tool and baseline paths in old receipts
are historical identifiers and are never opened. The complete parent compilation
and thirty-candidate capture evidence is audited by the parent cohort separately.
"""
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import statistics

os.environ.update(OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1')
import numpy as np

ROOT = Path(__file__).resolve().parent
CASES = [('decode-mha-d64', [1, 8, 8, 1, 2048, 64, 64]),
         ('decode-long-kv', [1, 16, 4, 1, 8193, 128, 128]),
         ('prefill-q8', [1, 4, 2, 64, 129, 32, 48])]
REFERENCES = ['online_neon', 'dense_accelerate']
BASELINE = 'm4-c4-simplified'
ABI = 'backends/simd/llvm/llvm_schedule_codegen.h'
SELFTEST_SHAPES = [[2, 6, 2, 3, 17, 7, 9], [1, 4, 1, 1, 1, 1, 1],
                   [1, 2, 2, 5, 5, 16, 12], [1, 1, 1, 2, 9, 5, 17]]
PATTERNS = ['random', 'zero', 'alternating_large']


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(path.read_text())


def safe(base, name):
    rel = PurePosixPath(name)
    require(name and not rel.is_absolute() and '..' not in rel.parts and '\\' not in name, 'unsafe artifact path')
    file = base / name
    require(file.is_file() and not any((base / Path(*rel.parts[:i])).is_symlink()
                                      for i in range(1, len(rel.parts) + 1)), 'missing or symlinked artifact')
    return file


def files(base, values):
    require(isinstance(values, dict) and values, 'missing artifact inventory')
    for name, value in values.items():
        require(sha(safe(base, name)) == value, 'artifact changed: ' + str(base / name))


def oracle(base, dims):
    b, h, kh, q, k, d, dv = dims
    require(all(type(x) is int and 0 < x <= 2**26 for x in dims) and q <= k and h % kh == 0, 'shape contract')
    tensors = []
    for i, shape in enumerate(((b, h, q, d), (b, kh, k, d), (b, kh, k, dv))):
        raw = (base / f'input{i}.f32').read_bytes()
        require(len(raw) == math.prod(shape) * 4, 'FP32 input extent')
        value = np.frombuffer(raw, dtype='<f4').astype(np.float64).reshape(shape)
        require(np.isfinite(value).all(), 'nonfinite input')
        tensors.append(value)
    output = np.empty((b, h, q, dv), dtype=np.float64)
    scale = float(np.float32(1) / np.sqrt(np.float32(d)))
    for batch in range(b):
        for head in range(h):
            group = head // (h // kh)
            score = np.einsum('qd,kd->qk', tensors[0][batch, head], tensors[1][batch, group], optimize=False) * scale
            score[np.arange(k)[None, :] > np.arange(q)[:, None] + k - q] = -np.inf
            weights = np.exp(score - score.max(axis=1, keepdims=True))
            weights /= weights.sum(axis=1, keepdims=True)
            output[batch, head] = np.einsum('qk,kd->qd', weights, tensors[2][batch, group], optimize=False)
    require(np.isfinite(output).all(), 'nonfinite independent FP64 oracle')
    return output.ravel()


def numeric(path, expected, dtype='<f4'):
    raw = path.read_bytes()
    require(len(raw) == len(expected) * np.dtype(dtype).itemsize, 'output extent: ' + str(path))
    actual = np.frombuffer(raw, dtype=dtype).astype(np.float64)
    require(np.isfinite(actual).all(), 'nonfinite output')
    error = np.abs(actual - expected)
    tolerance = 1e-11 if dtype == '<f8' else 5e-5
    require(np.all(error <= tolerance * (1 + np.abs(expected))), 'complete FP64 oracle mismatch')
    return float(error.max())


def check_row(base, row, expected):
    require(row['valid'] is True and row['returncode'] == 0 and row['all_guards_passed'] is True and
            row['inputs_unchanged'] is True, 'native guard/input/numerical failure')
    output = safe(base, row['output'])
    require(sha(output) == row['output_sha256'], 'visit output digest')
    check = row['correctness']
    require(check['elements'] == len(expected) and check['atol'] == check['rtol'] == 5e-5, 'check extent or tolerance drift')
    error = numeric(output, expected)
    require(math.isclose(error, check['max_abs_error'], abs_tol=1e-11), 'reported error differs')
    receipt = load(base / (row['output'] + '.json'))
    require(all(row.get(key) == value for key, value in receipt.items()), 'raw visit receipt differs')
    return error


def external(stem, expected_argv, plan_time, timeout, allow_stderr=False):
    initial = load(ROOT / (stem + '.command.json'))
    result = load(ROOT / (stem + '.result.json'))
    require(all(result.get(k) == v for k, v in initial.items()), 'external command changed')
    require(result['argv'][1:] == expected_argv and result['returncode'] == 0 and 'error' not in result,
            'external command/result mismatch: ' + stem)
    require(result['process_group_isolated'] is True and result['timeout_s'] == timeout and
            plan_time <= result['started'] <= result['finished'], 'external supervision/chronology')
    for suffix in ('stdout', 'stderr'):
        require(sha(ROOT / (stem + '.' + suffix)) == result[suffix + '_sha256'], 'external log changed')
    if not allow_stderr:
        require((ROOT / (stem + '.stderr')).read_bytes() == b'', 'unreviewed native stderr')
    require(all(result['environment'][key] == '1' for key in
                ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS')), 'requested host thread environment')
    return result


def source_digest(plan, suffix):
    values = [digest for path, digest in plan['identities'].items() if path.endswith('/' + suffix)]
    require(len(values) == 1, 'ambiguous frozen source: ' + suffix)
    return values[0]


def audit():
    plan = load(ROOT / 'plan.json')
    declaration = load(ROOT / 'predeclared.json')
    require(plan['declaration'] == declaration and declaration['cases'] == [dict(case=c, dimensions=d) for c, d in CASES],
            'case declaration drift')
    require(declaration['baseline_variant'] == BASELINE and declaration['references'] == REFERENCES and
            [declaration[k] for k in ('cycles', 'samples', 'warmup_ms', 'target_ms')] == [3, 7, 30, 15], 'fixed arms/timing drift')
    for name in ('run.py', 'audit.py', 'predeclared.json'):
        candidates = [digest for path, digest in plan['identities'].items() if path.endswith('/reference/' + name)]
        require(candidates == [sha(ROOT / name)], 'reference driver/audit/declaration identity')
    require(sha(ROOT / 'parent-plan.json') == plan['parent_plan_sha256'] and
            sha(ROOT / 'parent-captures.json') == plan['parent_captures_sha256'], 'parent receipt identity')
    parent_captures = load(ROOT / 'parent-captures.json')
    require(parent_captures['status'] == 'complete' and parent_captures['plan_sha256'] == plan['parent_plan_sha256'],
            'parent capture admission')
    validation = load(ROOT / 'validation.json')
    preparations = load(ROOT / 'preparations.json')
    replays = load(ROOT / 'replays.json')
    for stage in (validation, preparations, replays):
        require(stage['status'] == 'passed' and stage['plan_sha256'] == sha(ROOT / 'plan.json'), 'incomplete/error supplemental stage')
    require(plan['frozen_unix'] <= validation['started'] <= validation['finished'] <= preparations['started'] <=
            preparations['finished'] <= replays['started'] <= replays['finished'], 'stage chronology')
    runner = next(path for path in plan['identities'] if path.endswith('/native_attention_probe.py'))
    protocol_path = next(path for path in plan['identities'] if path.endswith('/test_native_attention_probe.py'))
    llvm = str(Path(next(path for path in plan['identities'] if path.endswith('/clang++'))).parent)
    original_root = str(Path(next(path for path in plan['identities'] if path.endswith('/reference/run.py'))).parent)
    protocol = external('protocol-tests', [protocol_path], plan['frozen_unix'], 120, True)
    require(re.search(r'Ran 22 tests.*\n\nOK\s*$', (ROOT / 'protocol-tests.stderr').read_text(), re.S), 'complete protocol tests')
    selftest_cmd = external('native-selftest', [runner, 'selftest', '--output', original_root + '/native-selftest', '--llvm', llvm],
                            protocol['finished'], 300)
    selftest = load(ROOT / 'native-selftest/results.json')
    require(selftest['status'] == 'passed' and selftest['expected_checks'] == len(selftest['checks']) == 24 and
            selftest['shapes'] == SELFTEST_SHAPES and selftest['patterns'] == PATTERNS and selftest['variants'] == REFERENCES,
            'native selftest matrix')
    require(sha(ROOT / 'native-selftest/results.json') == validation['selftest_sha256'], 'native selftest receipt identity')
    files(ROOT / 'native-selftest', selftest['files'])
    require(len({(row['shape'], row['pattern'], row['variant']) for row in selftest['checks']}) == 24, 'duplicate selftest')
    for index, dims in enumerate(SELFTEST_SHAPES):
        prepared_selftest = load(ROOT / 'native-selftest' / f'shape-{index}/selftest-prepared.json')
        threading = prepared_selftest['threading']
        require(prepared_selftest['shape']['dimensions'] == dims and threading['set_status'] == 0 and
                threading['observed_enum'] == threading['expected_enum'] == 1, 'selftest BLAS TLS acknowledgement')
    for row in selftest['checks']:
        require(row['status'] == 'passed' and row['samples_us'] == [] and row['repetitions'] == 0 and row['median_us'] is None,
                'selftest timed work or failed check')
        base = ROOT / 'native-selftest' / row['artifact_directory']
        expected = oracle(base, SELFTEST_SHAPES[row['shape']])
        numeric(base / 'expected.f64', expected, '<f8')
        check_row(base, row, expected)
    require([row['case'] for row in preparations['cases']] == [case for case, _ in CASES], 'preparation coverage')
    require([(row['case'], row['variant']) for row in replays['comparisons']] ==
            [(case, variant) for case, _ in CASES for variant in REFERENCES], 'comparison coverage/order')
    previous_prepare = selftest_cmd['finished']
    previous_replay = replays['started']
    rows = []
    realizations = []
    for ci, (case, dims) in enumerate(CASES):
        baseline = plan['baselines'][ci]
        require(baseline['case'] == case and baseline['dimensions'] == dims, 'baseline declaration')
        parent_case = next(row for row in parent_captures['cases'] if row['case'] == case)
        parent_variant = next(row for row in parent_case['variants'] if row['label'] == case + '-' + BASELINE)
        require(parent_case['status'] == 'OK' and parent_variant['prepared_manifest_sha256'] == baseline['manifest_sha256'],
                'reference baseline not the fixed successfully captured parent candidate')
        bundle = ROOT / ('prepared-' + case)
        prepared = load(bundle / 'probe.json')
        entry = load(bundle / 'tile/prepared.json')
        preparation = external('prepare-' + case, [runner, 'prepare', '--tile', baseline['original'], '--output',
                               original_root + '/prepared-' + case, '--llvm', llvm], previous_prepare, 300)
        previous_prepare = preparation['finished']
        require(preparation['finished'] <= replays['started'], 'preparation overlapped native timing')
        require(prepared['status'] == 'prepared' and prepared['format'] == 'native-attention-probe-v1' and
                prepared['shape']['dimensions'] == dims and prepared['math'] == plan['math'] and prepared['boundary'] == plan['boundary'],
                'probe preparation contract')
        require(sha(bundle / 'probe.json') == preparations['cases'][ci]['bundle_sha256'] and
                preparations['cases'][ci]['status'] == 'prepared', 'prepared bundle identity')
        require(sha(bundle / 'tile/prepared.json') == prepared['baseline_sha256'] == baseline['manifest_sha256'] and
                entry['files'] == baseline['files'], 'unchanged fixed baseline manifest')
        files(bundle, prepared['files']); files(bundle / 'tile', entry['files'])
        require(entry['name'] == BASELINE and entry['metadata']['dimensions'] == dims and
                entry['metadata']['precision'] == 'fp32' and entry['metadata']['fast_math'] is False and
                entry['metadata']['relaxed_precision'] is False, 'fixed Tile precision')
        text = entry['metadata']['realization']
        for key, value in dict(native_mma_vector_width='4', native_copy_vector_width='4',
                               full_packet_simplification_requested='true', local_lanes='1').items():
            require(re.findall(r'\b' + key + r'=([^;\s]+)', text) == [value], 'baseline control ' + key)
        realizations.append(dict(case=case, realization=text, workspace_bytes=entry['workspace_bytes'], abi=entry['abi']))
        for name in ('native_attention_probe.py', 'native_attention_probe.cpp', 'native_tile.py',
                     'test_native_attention_probe.py', 'native_tile_replay.cpp'):
            require(prepared['files'][name] == source_digest(plan, name), 'prepared source drift')
        require(prepared['files'][ABI] == entry['files'][ABI] == source_digest(plan, 'src/' + ABI), 'common ABI source')
        require(prepared['files']['native_tile_replay.cpp'] == entry['files']['native_tile_replay.cpp'], 'common helper source')
        compile_record = load(bundle / 'compile-probe.command.json')
        require(compile_record['returncode'] == 0 and all(flag in compile_record['argv'] for flag in
                    ('-O3', '-fno-fast-math', '-ffp-contract=off', '-framework', 'Accelerate')), 'probe compiler flags')
        require([arg for arg in compile_record['argv'] if arg.startswith('-DATTN_')] ==
                ['-DATTN_' + key + '=' + str(value) for key, value in zip(('B', 'H', 'KH', 'Q', 'K', 'D', 'DV'), dims)],
                'compiled probe dimensions')
        helper_compile = load(bundle / 'compile-helper.command.json')
        require(helper_compile['returncode'] == 0 and helper_compile['argv'][0] == compile_record['argv'][0] and
                all(flag in helper_compile['argv'] for flag in ('-O3', '-fno-fast-math', '-ffp-contract=off')) and
                '-framework' not in helper_compile['argv'], 'unchanged common timer compiler boundary')
        expected = oracle(bundle / 'tile', dims)
        for path in (bundle / 'expected.f64', bundle / 'tile/expected.f64'):
            numeric(path, expected, '<f8')
        numeric(bundle / 'tile/captured.f32', expected)
        require(sha(bundle / 'tile/captured.f32') == baseline['captured_output_sha256'], 'frozen Tile capture identity')
        for vi, variant in enumerate(REFERENCES):
            outer = replays['comparisons'][ci * 2 + vi]
            stem = 'replay-' + case + '-' + variant
            directory = ROOT / stem
            result = load(directory / 'results.json')
            execution = external(stem, [runner, 'replay', '--bundle', original_root + '/prepared-' + case + '/probe.json',
                                        '--variant', variant, '--output', original_root + '/' + stem,
                                        '--cycles', '3', '--samples', '7', '--warmup-ms', '30', '--target-ms', '15'],
                                 previous_replay, 120)
            previous_replay = execution['finished']
            require(execution['started'] <= result['started_unix'] <= result['finished_unix'] <= execution['finished'], 'replay chronology')
            require(outer['status'] == result['status'] == 'passed' and outer['results_sha256'] == sha(directory / 'results.json') and
                    result['bundle_sha256'] == sha(bundle / 'probe.json') and result['artifacts_unchanged'] is True, 'replay result identity')
            require(result['metric'] == 'single_thread_native_entry_host_wall_us' and result['math'] == plan['math'] and
                    result['boundary'] == plan['boundary'], 'replay metric/math contract')
            require(result['runner_sha256'] == prepared['files']['native_attention_probe.py'] and
                    result['common_helper_sha256'] == sha(bundle / 'replay.dylib'), 'actual runner/helper identity')
            require(result['threading']['set_status'] == 0 and result['threading']['observed_enum'] == result['threading']['expected_enum'] == 1,
                    'BLAS same-thread admission acknowledgement')
            require([result['options'][k] for k in ('cycles', 'samples', 'warmup_ms', 'target_ms')] == [3, 7, 30, 15], 'timer drift')
            require(result['entry_contracts']['tile'] == {key: entry[key] for key in
                    ('symbol', 'abi', 'dispatch', 'block', 'packet_width', 'workspace_bytes')} and
                    result['entry_contracts']['probe'] == prepared['variants'][variant], 'entry ABI drift')
            files(directory, result['files'])
            require(len(result['visits']) == 12, 'incomplete ABBA visits')
            hashes, errors = {}, []
            for index, visit in enumerate(result['visits']):
                arm = ('tile', variant, variant, 'tile')[index % 4]
                require((visit['cycle'], visit['position'], visit['variant']) == (index // 4, index % 4, arm) and
                        visit['status'] == 'passed' and visit['blas_threading_after'] == 1, 'ABBA order/status/threading')
                require(len(visit['samples_us']) == 7 and all(math.isfinite(value) and value > 0 for value in visit['samples_us']) and
                        type(visit['repetitions']) is int and visit['repetitions'] > 0, 'invalid timing sample')
                require(statistics.median(visit['samples_us']) == visit['median_us'], 'visit median')
                errors.append(check_row(directory, visit, expected))
                require(hashes.setdefault(arm, visit['output_sha256']) == visit['output_sha256'], 'within-arm nondeterminism')
                if arm == 'tile':
                    require(visit['output_sha256'] == baseline['captured_output_sha256'], 'Tile visit differs from own capture')
            require(hashes == result['deterministic_output_sha256'] and outer['tile_own_capture_bitwise'] is True and
                    outer['captured_output_sha256'] == baseline['captured_output_sha256'], 'output identity acknowledgement')
            medians = {arm: statistics.median(visit['median_us'] for visit in result['visits'] if visit['variant'] == arm)
                       for arm in ('tile', variant)}
            ratios = [result['visits'][a]['median_us'] / result['visits'][b]['median_us'] for cycle in range(3)
                      for a, b in ((4 * cycle + 1, 4 * cycle), (4 * cycle + 2, 4 * cycle + 3))]
            ratio = dict(baseline='tile', candidate=variant, pairs=ratios, median=statistics.median(ratios),
                         minimum=min(ratios), maximum=max(ratios))
            require(result['summary_us'] == medians and result['candidate_over_baseline'] == ratio, 'paired summary')
            rows.append(dict(case=case, variant=variant, tile_us=medians['tile'], reference_us=medians[variant],
                             reference_over_tile=ratio, max_abs_error=max(errors)))
    return dict(status='passed', plan_sha256=sha(ROOT / 'plan.json'), audit_sha256=sha(Path(__file__)),
                protocol_tests=22, native_selftest_checks=24, preparations=3, paired_replays=6,
                external_commands=11, visits=72, samples=504, comparisons=rows, realizations=realizations,
                limitations=[declaration[key] for key in ('independence', 'numerics', 'timer_boundary', 'threading', 'limits')])


if __name__ == '__main__':
    print(json.dumps(audit(), indent=2, allow_nan=False))

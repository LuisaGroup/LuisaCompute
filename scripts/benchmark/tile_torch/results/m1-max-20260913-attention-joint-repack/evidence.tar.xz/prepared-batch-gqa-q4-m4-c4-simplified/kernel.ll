; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

@convergence.targets = private unnamed_addr constant [24 x i32] [i32 2, i32 5, i32 55, i32 9, i32 11, i32 14, i32 17, i32 20, i32 23, i32 26, i32 29, i32 32, i32 35, i32 38, i32 41, i32 44, i32 11, i32 49, i32 9, i32 54, i32 60, i32 59, i32 2, i32 65], align 4

define internal void @llm_attention(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %live.mask = alloca <8 x i1>, align 1
  %runnable.mask = alloca <8 x i1>, align 1
  %ready.count = alloca i32, align 4
  %ready.mask = alloca [8 x <8 x i1>], align 1
  %ready.target = alloca [8 x i32], align 4
  %ready.token = alloca [8 x i32], align 4
  %current.mask = alloca <8 x i1>, align 1
  %current.token = alloca i32, align 4
  %frame.active = alloca i8, align 1
  %frame.static.id = alloca <8 x i32>, align 32
  %frame.parent.token = alloca <8 x i32>, align 32
  %frame.expected = alloca [8 x <8 x i1>], align 1
  %frame.arrived = alloca [8 x <8 x i1>], align 1
  store <8 x i1> zeroinitializer, ptr %live.mask, align 1
  store <8 x i1> zeroinitializer, ptr %runnable.mask, align 1
  store i32 0, ptr %ready.count, align 4
  store [8 x <8 x i1>] zeroinitializer, ptr %ready.mask, align 1
  store [8 x i32] zeroinitializer, ptr %ready.target, align 4
  store [8 x i32] zeroinitializer, ptr %ready.token, align 4
  store <8 x i1> zeroinitializer, ptr %current.mask, align 1
  store i32 0, ptr %current.token, align 4
  store i8 0, ptr %frame.active, align 1
  store <8 x i32> zeroinitializer, ptr %frame.static.id, align 32
  store <8 x i32> zeroinitializer, ptr %frame.parent.token, align 32
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.expected, align 1
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.arrived, align 1
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 640, i64 1280, i64 1920, i64 2560, i64 3200, i64 3840, i64 4480>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 5120
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 11264
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 17408
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 2560, i64 5120, i64 7680, i64 10240, i64 12800, i64 15360, i64 17920>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 37888
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 3072, i64 6144, i64 9216, i64 12288, i64 15360, i64 18432, i64 21504>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 62464
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 256, i64 512, i64 768, i64 1024, i64 1280, i64 1536, i64 1792>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 64512
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 256, i64 512, i64 768, i64 1024, i64 1280, i64 1536, i64 1792>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 66560
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %24 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace29 = load ptr, ptr %24, align 8
  %tile_snapshot.private30 = getelementptr inbounds i8, ptr %private.workspace29, i64 68608
  %.splatinsert31 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private30, i64 0
  %.splat32 = shufflevector <8 x ptr> %.splatinsert31, <8 x ptr> poison, <8 x i32> zeroinitializer
  %25 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat32, 0
  %26 = insertvalue { <8 x ptr>, <8 x i64> } %25, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %27 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace33 = load ptr, ptr %27, align 8
  %tile_snapshot.private34 = getelementptr inbounds i8, ptr %private.workspace33, i64 68736
  %.splatinsert35 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private34, i64 0
  %.splat36 = shufflevector <8 x ptr> %.splatinsert35, <8 x ptr> poison, <8 x i32> zeroinitializer
  %28 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat36, 0
  %29 = insertvalue { <8 x ptr>, <8 x i64> } %28, <8 x i64> <i64 0, i64 256, i64 512, i64 768, i64 1024, i64 1280, i64 1536, i64 1792>, 1
  %30 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace37 = load ptr, ptr %30, align 8
  %tile_snapshot.private38 = getelementptr inbounds i8, ptr %private.workspace37, i64 70784
  %.splatinsert39 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private38, i64 0
  %.splat40 = shufflevector <8 x ptr> %.splatinsert39, <8 x ptr> poison, <8 x i32> zeroinitializer
  %31 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat40, 0
  %32 = insertvalue { <8 x ptr>, <8 x i64> } %31, <8 x i64> <i64 0, i64 768, i64 1536, i64 2304, i64 3072, i64 3840, i64 4608, i64 5376>, 1
  %33 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace41 = load ptr, ptr %33, align 8
  %tile_snapshot.private42 = getelementptr inbounds i8, ptr %private.workspace41, i64 76928
  %.splatinsert43 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private42, i64 0
  %.splat44 = shufflevector <8 x ptr> %.splatinsert43, <8 x ptr> poison, <8 x i32> zeroinitializer
  %34 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat44, 0
  %35 = insertvalue { <8 x ptr>, <8 x i64> } %34, <8 x i64> <i64 0, i64 768, i64 1536, i64 2304, i64 3072, i64 3840, i64 4608, i64 5376>, 1
  %36 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace45 = load ptr, ptr %36, align 8
  %tile_snapshot.private46 = getelementptr inbounds i8, ptr %private.workspace45, i64 83072
  %.splatinsert47 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private46, i64 0
  %.splat48 = shufflevector <8 x ptr> %.splatinsert47, <8 x ptr> poison, <8 x i32> zeroinitializer
  %37 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat48, 0
  %38 = insertvalue { <8 x ptr>, <8 x i64> } %37, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill49 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill49, align 64
  %.spill50 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill50, align 64
  %.spill51 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill51, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %tile_snapshot.spill52 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill52, align 64
  %tile_snapshot.spill53 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill53, align 64
  %.slot = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot, align 64
  %.slot54 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot54, align 64
  %.slot55 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot55, align 32
  %.slot56 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot56, align 32
  %.slot57 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot57, align 32
  %.slot58 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot58, align 32
  %.slot59 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot59, align 32
  %.slot60 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot60, align 32
  %.slot61 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot61, align 32
  %.slot62 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot62, align 32
  %.spill63 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill63, align 64
  %tile_snapshot.spill64 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill64, align 64
  %.spill65 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill65, align 1
  %tile_snapshot.spill66 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill66, align 64
  %.spill67 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill67, align 1
  %.spill68 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill68, align 1
  %.spill69 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill69, align 1
  %.spill70 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill70, align 1
  %.spill71 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill71, align 1
  %.spill72 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill72, align 1
  %.spill73 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill73, align 1
  %.spill74 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill74, align 1
  %.spill75 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill75, align 1
  %.spill76 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill76, align 1
  %.spill77 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill77, align 1
  %.spill78 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill78, align 1
  %.spill79 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill79, align 1
  %.spill80 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill80, align 1
  %.spill81 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill81, align 1
  %.spill82 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill82, align 1
  %.spill83 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill83, align 1
  %.spill84 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill84, align 1
  %.spill85 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill85, align 1
  %.spill86 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill86, align 1
  %.spill87 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill87, align 1
  %.spill88 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill88, align 1
  %.spill89 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill89, align 1
  %.spill90 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill90, align 1
  %.spill91 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill91, align 1
  %.spill92 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill92, align 1
  %.spill93 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill93, align 1
  %.spill94 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill94, align 1
  %.spill95 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill95, align 1
  %.spill96 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill96, align 1
  %.spill97 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill97, align 1
  %.spill98 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill98, align 1
  %.spill99 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill99, align 1
  %.spill100 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill100, align 1
  %.spill101 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill101, align 1
  %.spill102 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill102, align 1
  %.spill103 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill103, align 1
  %.spill104 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill104, align 1
  %.spill105 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill105, align 1
  %.spill106 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill106, align 1
  %.spill107 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill107, align 1
  %.spill108 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill108, align 1
  %.spill109 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill109, align 1
  %.spill110 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill110, align 1
  %.spill111 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill111, align 1
  %.spill112 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill112, align 1
  %.spill113 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill113, align 1
  %.spill114 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill114, align 1
  %.spill115 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill115, align 1
  %.spill116 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill116, align 1
  %.spill117 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill117, align 1
  %.spill118 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill118, align 1
  %.spill119 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill119, align 1
  %.spill120 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill120, align 1
  %.spill121 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill121, align 1
  %.spill122 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill122, align 1
  %.spill123 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill123, align 1
  %.spill124 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill124, align 1
  %.spill125 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill125, align 1
  %.spill126 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill126, align 1
  %.spill127 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill127, align 1
  %.spill128 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill128, align 1
  %.spill129 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill129, align 1
  %.spill130 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill130, align 1
  %.spill131 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill131, align 32
  %.spill132 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill132, align 32
  %.spill133 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill133, align 32
  %.spill134 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill134, align 32
  %.spill135 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill135, align 32
  %.spill136 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill136, align 32
  %.spill137 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill137, align 32
  %.spill138 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill138, align 32
  %.spill139 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill139, align 32
  %.spill140 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill140, align 32
  %.spill141 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill141, align 32
  %.spill142 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill142, align 32
  %.spill143 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill143, align 32
  %.spill144 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill144, align 32
  %.spill145 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill145, align 32
  %.spill146 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill146, align 32
  %.spill147 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill147, align 32
  %.spill148 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill148, align 32
  %.spill149 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill149, align 32
  %.spill150 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill150, align 32
  %.spill151 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill151, align 32
  %.spill152 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill152, align 32
  %.spill153 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill153, align 32
  %.spill154 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill154, align 32
  %.spill155 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill155, align 32
  %.spill156 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill156, align 32
  %.spill157 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill157, align 32
  %.spill158 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill158, align 32
  %.spill159 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill159, align 32
  %.spill160 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill160, align 32
  %.spill161 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill161, align 32
  %.spill162 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill162, align 32
  %.spill163 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill163, align 32
  %.spill164 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill164, align 32
  %.spill165 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill165, align 32
  %.spill166 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill166, align 32
  %.spill167 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill167, align 32
  %.spill168 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill168, align 32
  %.spill169 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill169, align 32
  %.spill170 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill170, align 32
  %.spill171 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill171, align 32
  %.spill172 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill172, align 32
  %.spill173 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill173, align 32
  %.spill174 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill174, align 32
  %.spill175 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill175, align 32
  %.spill176 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill176, align 32
  %.spill177 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill177, align 32
  %.spill178 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill178, align 32
  %.spill179 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill179, align 32
  %.spill180 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill180, align 32
  %.spill181 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill181, align 32
  %.spill182 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill182, align 32
  %.spill183 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill183, align 32
  %.spill184 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill184, align 32
  %.spill185 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill185, align 32
  %.spill186 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill186, align 32
  %.spill187 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill187, align 32
  %.spill188 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill188, align 32
  %.spill189 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill189, align 32
  %.spill190 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill190, align 32
  %.spill191 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill191, align 32
  %.spill192 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill192, align 32
  %.spill193 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill193, align 32
  %.spill194 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill194, align 32
  %tile_snapshot.spill195 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill195, align 64
  %.slot196 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot196, align 64
  %.slot197 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot197, align 32
  %.slot198 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot198, align 64
  %.slot199 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot199, align 32
  %.slot200 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot200, align 64
  %.slot201 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot201, align 32
  %.slot202 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot202, align 64
  %.slot203 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot203, align 32
  %.spill204 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill204, align 32
  %.spill205 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill205, align 32
  %.spill206 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill206, align 32
  %.spill207 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill207, align 32
  %tile_snapshot.spill208 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill208, align 64
  %tile_snapshot.spill209 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill209, align 64
  %.spill210 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill210, align 32
  %.spill211 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill211, align 32
  %.spill212 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill212, align 32
  %.spill213 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill213, align 32
  %.slot214 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot214, align 64
  %.slot215 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot215, align 32
  %.slot216 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot216, align 64
  %.slot217 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot217, align 32
  %.slot218 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot218, align 64
  %.slot219 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot219, align 32
  %.slot220 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot220, align 64
  %.slot221 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot221, align 32
  %.spill222 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill222, align 32
  %.spill223 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill223, align 32
  %.spill224 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill224, align 32
  %.spill225 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill225, align 32
  %tile_snapshot.spill226 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill226, align 64
  %.slot227 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot227, align 64
  %tile_snapshot.spill228 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill228, align 64
  %.slot229 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot229, align 64
  %.slot230 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot230, align 64
  %.slot231 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot231, align 64
  %.spill232 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill232, align 64
  %.slot233 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot233, align 32
  %.slot234 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot234, align 64
  %.spill235 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill235, align 64
  %.slot236 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot236, align 32
  %tile_snapshot.spill237 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill237, align 64
  %.slot238 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot238, align 64
  %.spill239 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill239, align 64
  %.spill240 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill240, align 32
  %.slot241 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot241, align 64
  %.spill242 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill242, align 64
  %.slot243 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot243, align 32
  %39 = getelementptr i8, ptr %argument_buffer, i64 0
  %40 = load ptr, ptr %39, align 16
  %41 = getelementptr i8, ptr %39, i64 8
  %42 = load i64, ptr %41, align 8
  %43 = insertvalue { ptr, i64 } poison, ptr %40, 0
  %44 = insertvalue { ptr, i64 } %43, i64 %42, 1
  %45 = getelementptr i8, ptr %argument_buffer, i64 16
  %46 = load ptr, ptr %45, align 16
  %47 = getelementptr i8, ptr %45, i64 8
  %48 = load i64, ptr %47, align 8
  %49 = insertvalue { ptr, i64 } poison, ptr %46, 0
  %50 = insertvalue { ptr, i64 } %49, i64 %48, 1
  %51 = getelementptr i8, ptr %argument_buffer, i64 32
  %52 = load ptr, ptr %51, align 16
  %53 = getelementptr i8, ptr %51, i64 8
  %54 = load i64, ptr %53, align 8
  %55 = insertvalue { ptr, i64 } poison, ptr %52, 0
  %56 = insertvalue { ptr, i64 } %55, i64 %54, 1
  %57 = getelementptr i8, ptr %argument_buffer, i64 48
  %58 = load ptr, ptr %57, align 16
  %59 = getelementptr i8, ptr %57, i64 8
  %60 = load i64, ptr %59, align 8
  %61 = insertvalue { ptr, i64 } poison, ptr %58, 0
  %62 = insertvalue { ptr, i64 } %61, i64 %60, 1
  %63 = load i32, ptr %launch_config, align 4
  %64 = getelementptr i8, ptr %launch_config, i64 12
  %65 = load i32, ptr %64, align 4
  %66 = getelementptr i8, ptr %launch_config, i64 4
  %67 = load i32, ptr %66, align 4
  %68 = getelementptr i8, ptr %launch_config, i64 16
  %69 = load i32, ptr %68, align 4
  %70 = getelementptr i8, ptr %launch_config, i64 8
  %71 = load i32, ptr %70, align 4
  %72 = getelementptr i8, ptr %launch_config, i64 20
  %73 = load i32, ptr %72, align 4
  %74 = getelementptr i8, ptr %launch_config, i64 36
  %75 = load i32, ptr %74, align 4
  %.splatinsert244 = insertelement <8 x i32> poison, i32 %75, i64 0
  %.splat245 = shufflevector <8 x i32> %.splatinsert244, <8 x i32> poison, <8 x i32> zeroinitializer
  %76 = add <8 x i32> %.splat245, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %77 = mul i32 %63, 32
  %.splatinsert246 = insertelement <8 x i32> poison, i32 %77, i64 0
  %.splat247 = shufflevector <8 x i32> %.splatinsert246, <8 x i32> poison, <8 x i32> zeroinitializer
  %78 = add <8 x i32> %.splat247, %76
  %79 = mul i32 %67, 1
  %.splatinsert248 = insertelement <8 x i32> poison, i32 %79, i64 0
  %.splat249 = shufflevector <8 x i32> %.splatinsert248, <8 x i32> poison, <8 x i32> zeroinitializer
  %80 = add <8 x i32> %.splat249, zeroinitializer
  %81 = mul i32 %71, 1
  %.splatinsert250 = insertelement <8 x i32> poison, i32 %81, i64 0
  %.splat251 = shufflevector <8 x i32> %.splatinsert250, <8 x i32> poison, <8 x i32> zeroinitializer
  %82 = add <8 x i32> %.splat251, zeroinitializer
  %83 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %78, 0
  %84 = insertvalue [3 x <8 x i32>] %83, <8 x i32> %80, 1
  %85 = insertvalue [3 x <8 x i32>] %84, <8 x i32> %82, 2
  %.splatinsert252 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat253 = shufflevector <8 x i32> %.splatinsert252, <8 x i32> poison, <8 x i32> zeroinitializer
  %86 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat253
  store <8 x i1> %86, ptr %live.mask, align 1
  %87 = load i32, ptr %current.token, align 4
  %88 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %86)
  %89 = load i32, ptr %ready.count, align 4
  %90 = icmp uge i32 %89, 8
  %91 = and i1 %88, %90
  br i1 %91, label %ready.overflow.trap, label %ready.overflow.resume

ready.overflow.trap:                              ; preds = %prologue
  call void @llvm.trap()
  unreachable

ready.overflow.resume:                            ; preds = %prologue
  %92 = select i1 %88, i32 %89, i32 0
  %93 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %92
  %94 = load <8 x i1>, ptr %93, align 1
  %95 = select i1 %88, <8 x i1> %86, <8 x i1> %94
  store <8 x i1> %95, ptr %93, align 1
  %96 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %92
  %97 = load i32, ptr %96, align 4
  %98 = select i1 %88, i32 0, i32 %97
  store i32 %98, ptr %96, align 4
  %99 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %92
  %100 = load i32, ptr %99, align 4
  %101 = select i1 %88, i32 %87, i32 %100
  store i32 %101, ptr %99, align 4
  %102 = add i32 %89, 1
  %103 = select i1 %88, i32 %102, i32 %89
  store i32 %103, ptr %ready.count, align 4
  %104 = load <8 x i1>, ptr %runnable.mask, align 1
  %105 = or <8 x i1> %104, %86
  store <8 x i1> %105, ptr %runnable.mask, align 1
  br label %scheduler.loop

scheduler.loop:                                   ; preds = %convergence.target.65.ready, %convergence.cascade.exit1409, %schedule.64, %varying.coherent.false1406, %varying.coherent.true1405, %varying.coherent.false1393, %varying.coherent.true1392, %schedule.61, %return.frame.cleanup.done, %convergence.cascade.exit1321, %convergence.target.59.ready, %convergence.cascade.exit1303, %schedule.58, %varying.coherent.false1299, %varying.coherent.true1298, %varying.coherent.false1284, %varying.coherent.true1283, %convergence.target.55.ready, %convergence.cascade.exit1248, %convergence.target.54.ready, %convergence.cascade.exit1227, %schedule.53, %varying.coherent.false1224, %varying.coherent.true1223, %varying.coherent.false1211, %varying.coherent.true1210, %schedule.50, %convergence.target.49.ready, %convergence.cascade.exit1183, %schedule.48, %varying.coherent.false1180, %varying.coherent.true1179, %varying.coherent.false1167, %varying.coherent.true1166, %schedule.45, %convergence.target.44.ready, %convergence.cascade.exit1134, %schedule.43, %varying.coherent.false1127, %varying.coherent.true1126, %convergence.target.41.ready, %convergence.cascade.exit1103, %schedule.40, %varying.coherent.false1096, %varying.coherent.true1095, %mma.continue1087, %convergence.cascade.exit1053, %schedule.37, %varying.coherent.false1044, %varying.coherent.true1043, %convergence.target.35.ready, %convergence.cascade.exit1012, %schedule.34, %varying.coherent.false1006, %varying.coherent.true1005, %convergence.target.32.ready, %convergence.cascade.exit982, %schedule.31, %varying.coherent.false976, %varying.coherent.true975, %convergence.target.29.ready, %convergence.cascade.exit952, %schedule.28, %varying.coherent.false946, %varying.coherent.true945, %convergence.target.26.ready, %convergence.cascade.exit922, %schedule.25, %varying.coherent.false916, %varying.coherent.true915, %convergence.target.23.ready, %convergence.cascade.exit673, %schedule.22, %varying.coherent.false667, %varying.coherent.true666, %convergence.target.20.ready, %convergence.cascade.exit643, %schedule.19, %varying.coherent.false637, %varying.coherent.true636, %convergence.target.17.ready, %convergence.cascade.exit613, %schedule.16, %varying.coherent.false607, %varying.coherent.true606, %convergence.target.14.ready, %convergence.cascade.exit583, %schedule.13, %varying.coherent.false577, %varying.coherent.true576, %mma.continue422, %convergence.cascade.exit391, %copy.continue389, %varying.coherent.false369, %varying.coherent.true368, %convergence.cascade.exit345, %copy.continue343, %varying.coherent.false323, %varying.coherent.true322, %varying.coherent.false314, %varying.coherent.true313, %convergence.target.5.ready, %convergence.cascade.exit290, %schedule.4, %varying.coherent.false285, %varying.coherent.true284, %convergence.target.2.ready, %convergence.cascade.exit, %copy.continue271, %varying.coherent.false, %varying.coherent.true, %ready.overflow.resume
  %106 = load i32, ptr %ready.count, align 4
  %107 = icmp ne i32 %106, 0
  br i1 %107, label %scheduler.dispatch, label %scheduler.done

scheduler.dispatch:                               ; preds = %scheduler.loop
  %108 = sub i32 %106, 1
  store i32 %108, ptr %ready.count, align 4
  %109 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %108
  %110 = load <8 x i1>, ptr %109, align 1
  store <8 x i1> %110, ptr %current.mask, align 1
  %111 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %108
  %112 = load i32, ptr %111, align 4
  %113 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %108
  %114 = load i32, ptr %113, align 4
  store i32 %114, ptr %current.token, align 4
  %115 = load <8 x i1>, ptr %runnable.mask, align 1
  %116 = xor <8 x i1> %110, splat (i1 true)
  %117 = and <8 x i1> %115, %116
  store <8 x i1> %117, ptr %runnable.mask, align 1
  br label %scheduler.dispatch.route

scheduler.dispatch.route:                         ; preds = %ready.overflow.resume1404, %ready.overflow.resume1391, %ready.overflow.resume1297, %ready.overflow.resume1282, %ready.overflow.resume1222, %ready.overflow.resume1209, %ready.overflow.resume1178, %ready.overflow.resume1165, %ready.overflow.resume1125, %ready.overflow.resume1094, %ready.overflow.resume1042, %ready.overflow.resume1004, %ready.overflow.resume974, %ready.overflow.resume944, %ready.overflow.resume914, %ready.overflow.resume665, %ready.overflow.resume635, %ready.overflow.resume605, %ready.overflow.resume575, %ready.overflow.resume367, %ready.overflow.resume321, %ready.overflow.resume312, %ready.overflow.resume283, %ready.overflow.resume255, %scheduler.dispatch
  %scheduler.dispatch.pc = phi i32 [ %112, %scheduler.dispatch ], [ 61, %ready.overflow.resume255 ], [ 5, %ready.overflow.resume283 ], [ 55, %ready.overflow.resume312 ], [ 50, %ready.overflow.resume321 ], [ 45, %ready.overflow.resume367 ], [ 14, %ready.overflow.resume575 ], [ 17, %ready.overflow.resume605 ], [ 20, %ready.overflow.resume635 ], [ 23, %ready.overflow.resume665 ], [ 26, %ready.overflow.resume914 ], [ 29, %ready.overflow.resume944 ], [ 32, %ready.overflow.resume974 ], [ 35, %ready.overflow.resume1004 ], [ 38, %ready.overflow.resume1042 ], [ 41, %ready.overflow.resume1094 ], [ 44, %ready.overflow.resume1125 ], [ 11, %ready.overflow.resume1165 ], [ 49, %ready.overflow.resume1178 ], [ 9, %ready.overflow.resume1209 ], [ 54, %ready.overflow.resume1222 ], [ 60, %ready.overflow.resume1282 ], [ 59, %ready.overflow.resume1297 ], [ 2, %ready.overflow.resume1391 ], [ 65, %ready.overflow.resume1404 ]
  switch i32 %scheduler.dispatch.pc, label %scheduler.invalid [
    i32 0, label %schedule.0
    i32 1, label %schedule.1
    i32 2, label %schedule.2
    i32 3, label %schedule.3
    i32 4, label %schedule.4
    i32 5, label %schedule.5
    i32 6, label %schedule.6
    i32 7, label %schedule.7
    i32 8, label %schedule.8
    i32 9, label %schedule.9
    i32 10, label %schedule.10
    i32 11, label %schedule.11
    i32 12, label %schedule.12
    i32 13, label %schedule.13
    i32 14, label %schedule.14
    i32 15, label %schedule.15
    i32 16, label %schedule.16
    i32 17, label %schedule.17
    i32 18, label %schedule.18
    i32 19, label %schedule.19
    i32 20, label %schedule.20
    i32 21, label %schedule.21
    i32 22, label %schedule.22
    i32 23, label %schedule.23
    i32 24, label %schedule.24
    i32 25, label %schedule.25
    i32 26, label %schedule.26
    i32 27, label %schedule.27
    i32 28, label %schedule.28
    i32 29, label %schedule.29
    i32 30, label %schedule.30
    i32 31, label %schedule.31
    i32 32, label %schedule.32
    i32 33, label %schedule.33
    i32 34, label %schedule.34
    i32 35, label %schedule.35
    i32 36, label %schedule.36
    i32 37, label %schedule.37
    i32 38, label %schedule.38
    i32 39, label %schedule.39
    i32 40, label %schedule.40
    i32 41, label %schedule.41
    i32 42, label %schedule.42
    i32 43, label %schedule.43
    i32 44, label %schedule.44
    i32 45, label %schedule.45
    i32 46, label %schedule.46
    i32 47, label %schedule.47
    i32 48, label %schedule.48
    i32 49, label %schedule.49
    i32 50, label %schedule.50
    i32 51, label %schedule.51
    i32 52, label %schedule.52
    i32 53, label %schedule.53
    i32 54, label %schedule.54
    i32 55, label %schedule.55
    i32 56, label %schedule.56
    i32 57, label %schedule.57
    i32 58, label %schedule.58
    i32 59, label %schedule.59
    i32 60, label %schedule.60
    i32 61, label %schedule.61
    i32 62, label %schedule.62
    i32 63, label %schedule.63
    i32 64, label %schedule.64
    i32 65, label %schedule.65
  ]

scheduler.done:                                   ; preds = %scheduler.loop
  %118 = load <8 x i1>, ptr %live.mask, align 1
  %119 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %118)
  br i1 %119, label %scheduler.stalled, label %scheduler.exit

scheduler.exit:                                   ; preds = %scheduler.done
  ret void

scheduler.stalled:                                ; preds = %scheduler.done
  call void @llvm.trap()
  unreachable

scheduler.invalid:                                ; preds = %scheduler.dispatch.route
  call void @llvm.trap()
  unreachable

schedule.0:                                       ; preds = %scheduler.dispatch.route
  %120 = load <8 x i1>, ptr %current.mask, align 1
  %121 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %120)
  %122 = bitcast <8 x i1> %120 to i8
  %123 = call i8 @llvm.cttz.i8(i8 %122, i1 false)
  %124 = zext i8 %123 to i32
  %125 = select i1 %121, i32 %124, i32 0
  %126 = extractvalue [3 x <8 x i32>] %85, 0
  %127 = zext <8 x i32> %126 to <8 x i64>
  %128 = select <8 x i1> %120, <8 x i64> %127, <8 x i64> zeroinitializer
  %129 = select <8 x i1> %120, <8 x i64> splat (i64 30), <8 x i64> splat (i64 1)
  %130 = sdiv <8 x i64> %128, %129
  %131 = load <8 x i64>, ptr %.spill, align 64
  %132 = select <8 x i1> %120, <8 x i64> %130, <8 x i64> %131
  store <8 x i64> %132, ptr %.spill, align 64
  %133 = select <8 x i1> %120, <8 x i64> %127, <8 x i64> zeroinitializer
  %134 = select <8 x i1> %120, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %135 = sdiv <8 x i64> %133, %134
  %136 = select <8 x i1> %120, <8 x i64> %135, <8 x i64> zeroinitializer
  %137 = select <8 x i1> %120, <8 x i64> splat (i64 6), <8 x i64> splat (i64 1)
  %138 = srem <8 x i64> %136, %137
  %139 = load volatile <8 x i64>, ptr %.spill49, align 64
  %140 = select <8 x i1> %120, <8 x i64> %138, <8 x i64> %139
  store volatile <8 x i64> %140, ptr %.spill49, align 64
  %141 = select <8 x i1> %120, <8 x i64> %127, <8 x i64> zeroinitializer
  %142 = select <8 x i1> %120, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %143 = sdiv <8 x i64> %141, %142
  %144 = select <8 x i1> %120, <8 x i64> %143, <8 x i64> zeroinitializer
  %145 = select <8 x i1> %120, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %146 = srem <8 x i64> %144, %145
  %147 = mul <8 x i64> %146, splat (i64 4)
  %148 = load <8 x i64>, ptr %.spill50, align 64
  %149 = select <8 x i1> %120, <8 x i64> %147, <8 x i64> %148
  store <8 x i64> %149, ptr %.spill50, align 64
  %150 = select <8 x i1> %120, <8 x i64> %138, <8 x i64> zeroinitializer
  %151 = select <8 x i1> %120, <8 x i64> splat (i64 3), <8 x i64> splat (i64 1)
  %152 = sdiv <8 x i64> %150, %151
  %153 = load <8 x i64>, ptr %.spill51, align 64
  %154 = select <8 x i1> %120, <8 x i64> %152, <8 x i64> %153
  store <8 x i64> %154, ptr %.spill51, align 64
  %155 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %156 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %157 = extractvalue { <8 x ptr>, <8 x i64> } %155, 0
  %158 = select <8 x i1> %120, <8 x ptr> %156, <8 x ptr> %157
  %159 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %160 = extractvalue { <8 x ptr>, <8 x i64> } %155, 1
  %161 = select <8 x i1> %120, <8 x i64> %159, <8 x i64> %160
  %162 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %158, 0
  %163 = insertvalue { <8 x ptr>, <8 x i64> } %162, <8 x i64> %161, 1
  store volatile { <8 x ptr>, <8 x i64> } %163, ptr %tile_snapshot.spill, align 64
  %164 = icmp sge <8 x i64> %147, zeroinitializer
  %165 = and <8 x i1> splat (i1 true), %164
  %166 = icmp sle <8 x i64> %147, splat (i64 13)
  %167 = and <8 x i1> %165, %166
  %168 = and <8 x i1> %120, %167
  %169 = xor <8 x i1> %167, splat (i1 true)
  %170 = and <8 x i1> %120, %169
  %171 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %168)
  %172 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %170)
  %173 = and i1 %171, %172
  br i1 %173, label %varying.divergent, label %varying.coherent

schedule.1:                                       ; preds = %varying.coherent.true, %scheduler.dispatch.route
  %174 = load <8 x i1>, ptr %current.mask, align 1
  %175 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %174)
  %176 = bitcast <8 x i1> %174 to i8
  %177 = call i8 @llvm.cttz.i8(i8 %176, i1 false)
  %178 = zext i8 %177 to i32
  %179 = select i1 %175, i32 %178, i32 0
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %180 = add <8 x i64> zeroinitializer, %.spill.load
  %181 = mul <8 x i64> %180, splat (i64 6)
  %.spill.load256 = load volatile <8 x i64>, ptr %.spill49, align 64
  %182 = add <8 x i64> %181, %.spill.load256
  %183 = mul <8 x i64> %182, splat (i64 17)
  %.spill.load257 = load <8 x i64>, ptr %.spill50, align 64
  %184 = add <8 x i64> %183, %.spill.load257
  %185 = mul <8 x i64> %184, splat (i64 40)
  %186 = add <8 x i64> %185, zeroinitializer
  %tile_snapshot.spill.load = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %187 = extractvalue { ptr, i64 } %44, 0
  %188 = extractelement <8 x i1> %174, i64 0
  br i1 %188, label %copy.active, label %copy.continue

schedule.2:                                       ; preds = %varying.coherent.false1393, %copy.continue271, %scheduler.dispatch.route
  %189 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token = load i32, ptr %current.token, align 4
  %convergence.token.present = icmp ne i32 %convergence.current.token, 0
  br i1 %convergence.token.present, label %convergence.cascade, label %convergence.cascade.exit

schedule.3:                                       ; preds = %schedule.4, %convergence.target.2.ready, %scheduler.dispatch.route
  %190 = load <8 x i1>, ptr %current.mask, align 1
  %191 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %190)
  %192 = bitcast <8 x i1> %190 to i8
  %193 = call i8 @llvm.cttz.i8(i8 %192, i1 false)
  %194 = zext i8 %193 to i32
  %195 = select i1 %191, i32 %194, i32 0
  %.state = load <8 x i64>, ptr %.slot, align 64
  %196 = icmp slt <8 x i64> %.state, splat (i64 192)
  %197 = and <8 x i1> %190, %196
  %198 = xor <8 x i1> %196, splat (i1 true)
  %199 = and <8 x i1> %190, %198
  %200 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %197)
  %201 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %199)
  %202 = and i1 %200, %201
  br i1 %202, label %varying.divergent278, label %varying.coherent279

schedule.4:                                       ; preds = %varying.coherent.true284, %scheduler.dispatch.route
  %203 = load <8 x i1>, ptr %current.mask, align 1
  %204 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %203)
  %205 = bitcast <8 x i1> %203 to i8
  %206 = call i8 @llvm.cttz.i8(i8 %205, i1 false)
  %207 = zext i8 %206 to i32
  %208 = select i1 %204, i32 %207, i32 0
  %tile_snapshot.spill.load286 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %209 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load286, 0
  %210 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load286, 1
  %.state287 = load <8 x i64>, ptr %.slot, align 64
  %211 = mul <8 x i64> %.state287, splat (i64 32)
  %212 = add <8 x i64> %210, %211
  %213 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %209, 0
  %214 = insertvalue { <8 x ptr>, <8 x i64> } %213, <8 x i64> %212, 1
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %214, 0
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %214, 1
  %217 = getelementptr i8, <8 x ptr> %215, <8 x i64> %216
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %217, <8 x i1> %203)
  %.state288 = load <8 x i64>, ptr %.slot, align 64
  %218 = add <8 x i64> %.state288, splat (i64 1)
  %219 = load <8 x i64>, ptr %.slot, align 64
  %220 = select <8 x i1> %203, <8 x i64> %218, <8 x i64> %219
  store <8 x i64> %220, ptr %.slot, align 64
  store <8 x i1> %203, ptr %current.mask, align 1
  %221 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %203)
  br i1 %221, label %schedule.3, label %scheduler.loop

schedule.5:                                       ; preds = %varying.coherent.false285, %scheduler.dispatch.route
  %222 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token291 = load i32, ptr %current.token, align 4
  %convergence.token.present292 = icmp ne i32 %convergence.current.token291, 0
  br i1 %convergence.token.present292, label %convergence.cascade289, label %convergence.cascade.exit290

schedule.6:                                       ; preds = %convergence.target.44.ready, %convergence.target.5.ready, %scheduler.dispatch.route
  %223 = load <8 x i1>, ptr %current.mask, align 1
  %224 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %223)
  %225 = bitcast <8 x i1> %223 to i8
  %226 = call i8 @llvm.cttz.i8(i8 %225, i1 false)
  %227 = zext i8 %226 to i32
  %228 = select i1 %224, i32 %227, i32 0
  %.state306 = load <8 x i64>, ptr %.slot54, align 64
  %229 = icmp slt <8 x i64> %.state306, splat (i64 5)
  %230 = and <8 x i1> %223, %229
  %231 = xor <8 x i1> %229, splat (i1 true)
  %232 = and <8 x i1> %223, %231
  %233 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %230)
  %234 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %232)
  %235 = and i1 %233, %234
  br i1 %235, label %varying.divergent307, label %varying.coherent308

schedule.7:                                       ; preds = %varying.coherent.true313, %scheduler.dispatch.route
  %236 = load <8 x i1>, ptr %current.mask, align 1
  %237 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %236)
  %238 = bitcast <8 x i1> %236 to i8
  %239 = call i8 @llvm.cttz.i8(i8 %238, i1 false)
  %240 = zext i8 %239 to i32
  %241 = select i1 %237, i32 %240, i32 0
  %.state315 = load <8 x i64>, ptr %.slot54, align 64
  %242 = select <8 x i1> %236, <8 x i64> %.state315, <8 x i64> zeroinitializer
  %243 = select <8 x i1> %236, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %244 = sdiv <8 x i64> %242, %243
  %245 = mul <8 x i64> %244, splat (i64 16)
  %246 = load <8 x i64>, ptr %.spill63, align 64
  %247 = select <8 x i1> %236, <8 x i64> %245, <8 x i64> %246
  store <8 x i64> %247, ptr %.spill63, align 64
  %248 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %250 = extractvalue { <8 x ptr>, <8 x i64> } %248, 0
  %251 = select <8 x i1> %236, <8 x ptr> %249, <8 x ptr> %250
  %252 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %248, 1
  %254 = select <8 x i1> %236, <8 x i64> %252, <8 x i64> %253
  %255 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %251, 0
  %256 = insertvalue { <8 x ptr>, <8 x i64> } %255, <8 x i64> %254, 1
  store volatile { <8 x ptr>, <8 x i64> } %256, ptr %tile_snapshot.spill64, align 64
  %257 = icmp sge <8 x i64> %245, zeroinitializer
  %258 = and <8 x i1> splat (i1 true), %257
  %259 = icmp sle <8 x i64> %245, splat (i64 51)
  %260 = and <8 x i1> %258, %259
  %261 = load volatile <8 x i1>, ptr %.spill65, align 1
  %262 = select <8 x i1> %236, <8 x i1> %260, <8 x i1> %261
  store volatile <8 x i1> %262, ptr %.spill65, align 1
  %263 = and <8 x i1> %236, %260
  %264 = xor <8 x i1> %260, splat (i1 true)
  %265 = and <8 x i1> %236, %264
  %266 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %263)
  %267 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %265)
  %268 = and i1 %266, %267
  br i1 %268, label %varying.divergent316, label %varying.coherent317

schedule.8:                                       ; preds = %varying.coherent.true322, %scheduler.dispatch.route
  %269 = load <8 x i1>, ptr %current.mask, align 1
  %270 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %269)
  %271 = bitcast <8 x i1> %269 to i8
  %272 = call i8 @llvm.cttz.i8(i8 %271, i1 false)
  %273 = zext i8 %272 to i32
  %274 = select i1 %270, i32 %273, i32 0
  %.spill.load324 = load <8 x i64>, ptr %.spill, align 64
  %275 = add <8 x i64> zeroinitializer, %.spill.load324
  %276 = mul <8 x i64> %275, splat (i64 2)
  %.spill.load325 = load <8 x i64>, ptr %.spill51, align 64
  %277 = add <8 x i64> %276, %.spill.load325
  %278 = mul <8 x i64> %277, splat (i64 67)
  %.spill.load326 = load <8 x i64>, ptr %.spill63, align 64
  %279 = add <8 x i64> %278, %.spill.load326
  %280 = mul <8 x i64> %279, splat (i64 40)
  %281 = add <8 x i64> %280, zeroinitializer
  %tile_snapshot.spill.load327 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %282 = extractvalue { ptr, i64 } %50, 0
  %283 = extractelement <8 x i1> %269, i64 0
  br i1 %283, label %copy.active328, label %copy.continue329

schedule.9:                                       ; preds = %varying.coherent.false1211, %copy.continue343, %scheduler.dispatch.route
  %284 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token346 = load i32, ptr %current.token, align 4
  %convergence.token.present347 = icmp ne i32 %convergence.current.token346, 0
  br i1 %convergence.token.present347, label %convergence.cascade344, label %convergence.cascade.exit345

schedule.10:                                      ; preds = %varying.coherent.true368, %scheduler.dispatch.route
  %285 = load <8 x i1>, ptr %current.mask, align 1
  %286 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %285)
  %287 = bitcast <8 x i1> %285 to i8
  %288 = call i8 @llvm.cttz.i8(i8 %287, i1 false)
  %289 = zext i8 %288 to i32
  %290 = select i1 %286, i32 %289, i32 0
  %.spill.load370 = load <8 x i64>, ptr %.spill, align 64
  %291 = add <8 x i64> zeroinitializer, %.spill.load370
  %292 = mul <8 x i64> %291, splat (i64 2)
  %.spill.load371 = load <8 x i64>, ptr %.spill51, align 64
  %293 = add <8 x i64> %292, %.spill.load371
  %294 = mul <8 x i64> %293, splat (i64 67)
  %.spill.load372 = load <8 x i64>, ptr %.spill63, align 64
  %295 = add <8 x i64> %294, %.spill.load372
  %296 = mul <8 x i64> %295, splat (i64 48)
  %297 = add <8 x i64> %296, zeroinitializer
  %tile_snapshot.spill.load373 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill66, align 64
  %298 = extractvalue { ptr, i64 } %56, 0
  %299 = extractelement <8 x i1> %285, i64 0
  br i1 %299, label %copy.active374, label %copy.continue375

schedule.11:                                      ; preds = %varying.coherent.false1167, %copy.continue389, %scheduler.dispatch.route
  %300 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token392 = load i32, ptr %current.token, align 4
  %convergence.token.present393 = icmp ne i32 %convergence.current.token392, 0
  br i1 %convergence.token.present393, label %convergence.cascade390, label %convergence.cascade.exit391

schedule.12:                                      ; preds = %schedule.13, %mma.continue422, %scheduler.dispatch.route
  %301 = load <8 x i1>, ptr %current.mask, align 1
  %302 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %301)
  %303 = bitcast <8 x i1> %301 to i8
  %304 = call i8 @llvm.cttz.i8(i8 %303, i1 false)
  %305 = zext i8 %304 to i32
  %306 = select i1 %302, i32 %305, i32 0
  %.state569 = load <8 x i64>, ptr %.slot196, align 64
  %307 = icmp slt <8 x i64> %.state569, splat (i64 16)
  %308 = and <8 x i1> %301, %307
  %309 = xor <8 x i1> %307, splat (i1 true)
  %310 = and <8 x i1> %301, %309
  %311 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %308)
  %312 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %310)
  %313 = and i1 %311, %312
  br i1 %313, label %varying.divergent570, label %varying.coherent571

schedule.13:                                      ; preds = %varying.coherent.true576, %scheduler.dispatch.route
  %314 = load <8 x i1>, ptr %current.mask, align 1
  %315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %314)
  %316 = bitcast <8 x i1> %314 to i8
  %317 = call i8 @llvm.cttz.i8(i8 %316, i1 false)
  %318 = zext i8 %317 to i32
  %319 = select i1 %315, i32 %318, i32 0
  %.state578 = load <8 x i64>, ptr %.slot196, align 64
  %320 = select <8 x i1> %314, <8 x i64> %.state578, <8 x i64> zeroinitializer
  %321 = select <8 x i1> %314, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %322 = sdiv <8 x i64> %320, %321
  %323 = add <8 x i64> zeroinitializer, %322
  %tile_snapshot.spill.load579 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill195, align 64
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load579, 0
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load579, 1
  %326 = mul <8 x i64> %323, splat (i64 32)
  %327 = add <8 x i64> %325, %326
  %328 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %324, 0
  %329 = insertvalue { <8 x ptr>, <8 x i64> } %328, <8 x i64> %327, 1
  %330 = extractvalue { <8 x ptr>, <8 x i64> } %329, 0
  %331 = extractvalue { <8 x ptr>, <8 x i64> } %329, 1
  %332 = getelementptr i8, <8 x ptr> %330, <8 x i64> %331
  %333 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %332, <8 x i1> %314, <8 x float> zeroinitializer)
  %.state580 = load <8 x float>, ptr %.slot197, align 32
  %334 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state580, <8 x float> %333)
  %.state581 = load <8 x i64>, ptr %.slot196, align 64
  %335 = add <8 x i64> %.state581, splat (i64 1)
  %336 = load <8 x i64>, ptr %.slot196, align 64
  %337 = select <8 x i1> %314, <8 x i64> %335, <8 x i64> %336
  store <8 x i64> %337, ptr %.slot196, align 64
  %338 = load <8 x float>, ptr %.slot197, align 32
  %339 = select <8 x i1> %314, <8 x float> %334, <8 x float> %338
  store <8 x float> %339, ptr %.slot197, align 32
  store <8 x i1> %314, ptr %current.mask, align 1
  %340 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %314)
  br i1 %340, label %schedule.12, label %scheduler.loop

schedule.14:                                      ; preds = %varying.coherent.false577, %scheduler.dispatch.route
  %341 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token584 = load i32, ptr %current.token, align 4
  %convergence.token.present585 = icmp ne i32 %convergence.current.token584, 0
  br i1 %convergence.token.present585, label %convergence.cascade582, label %convergence.cascade.exit583

schedule.15:                                      ; preds = %schedule.16, %convergence.target.14.ready, %scheduler.dispatch.route
  %342 = load <8 x i1>, ptr %current.mask, align 1
  %343 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %342)
  %344 = bitcast <8 x i1> %342 to i8
  %345 = call i8 @llvm.cttz.i8(i8 %344, i1 false)
  %346 = zext i8 %345 to i32
  %347 = select i1 %343, i32 %346, i32 0
  %.state599 = load <8 x i64>, ptr %.slot198, align 64
  %348 = icmp slt <8 x i64> %.state599, splat (i64 16)
  %349 = and <8 x i1> %342, %348
  %350 = xor <8 x i1> %348, splat (i1 true)
  %351 = and <8 x i1> %342, %350
  %352 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %349)
  %353 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %351)
  %354 = and i1 %352, %353
  br i1 %354, label %varying.divergent600, label %varying.coherent601

schedule.16:                                      ; preds = %varying.coherent.true606, %scheduler.dispatch.route
  %355 = load <8 x i1>, ptr %current.mask, align 1
  %356 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %355)
  %357 = bitcast <8 x i1> %355 to i8
  %358 = call i8 @llvm.cttz.i8(i8 %357, i1 false)
  %359 = zext i8 %358 to i32
  %360 = select i1 %356, i32 %359, i32 0
  %.state608 = load <8 x i64>, ptr %.slot198, align 64
  %361 = select <8 x i1> %355, <8 x i64> %.state608, <8 x i64> zeroinitializer
  %362 = select <8 x i1> %355, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %363 = sdiv <8 x i64> %361, %362
  %364 = add <8 x i64> splat (i64 16), %363
  %tile_snapshot.spill.load609 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill195, align 64
  %365 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load609, 0
  %366 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load609, 1
  %367 = mul <8 x i64> %364, splat (i64 32)
  %368 = add <8 x i64> %366, %367
  %369 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %365, 0
  %370 = insertvalue { <8 x ptr>, <8 x i64> } %369, <8 x i64> %368, 1
  %371 = extractvalue { <8 x ptr>, <8 x i64> } %370, 0
  %372 = extractvalue { <8 x ptr>, <8 x i64> } %370, 1
  %373 = getelementptr i8, <8 x ptr> %371, <8 x i64> %372
  %374 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %373, <8 x i1> %355, <8 x float> zeroinitializer)
  %.state610 = load <8 x float>, ptr %.slot199, align 32
  %375 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state610, <8 x float> %374)
  %.state611 = load <8 x i64>, ptr %.slot198, align 64
  %376 = add <8 x i64> %.state611, splat (i64 1)
  %377 = load <8 x i64>, ptr %.slot198, align 64
  %378 = select <8 x i1> %355, <8 x i64> %376, <8 x i64> %377
  store <8 x i64> %378, ptr %.slot198, align 64
  %379 = load <8 x float>, ptr %.slot199, align 32
  %380 = select <8 x i1> %355, <8 x float> %375, <8 x float> %379
  store <8 x float> %380, ptr %.slot199, align 32
  store <8 x i1> %355, ptr %current.mask, align 1
  %381 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %355)
  br i1 %381, label %schedule.15, label %scheduler.loop

schedule.17:                                      ; preds = %varying.coherent.false607, %scheduler.dispatch.route
  %382 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token614 = load i32, ptr %current.token, align 4
  %convergence.token.present615 = icmp ne i32 %convergence.current.token614, 0
  br i1 %convergence.token.present615, label %convergence.cascade612, label %convergence.cascade.exit613

schedule.18:                                      ; preds = %schedule.19, %convergence.target.17.ready, %scheduler.dispatch.route
  %383 = load <8 x i1>, ptr %current.mask, align 1
  %384 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %383)
  %385 = bitcast <8 x i1> %383 to i8
  %386 = call i8 @llvm.cttz.i8(i8 %385, i1 false)
  %387 = zext i8 %386 to i32
  %388 = select i1 %384, i32 %387, i32 0
  %.state629 = load <8 x i64>, ptr %.slot200, align 64
  %389 = icmp slt <8 x i64> %.state629, splat (i64 16)
  %390 = and <8 x i1> %383, %389
  %391 = xor <8 x i1> %389, splat (i1 true)
  %392 = and <8 x i1> %383, %391
  %393 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %390)
  %394 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %392)
  %395 = and i1 %393, %394
  br i1 %395, label %varying.divergent630, label %varying.coherent631

schedule.19:                                      ; preds = %varying.coherent.true636, %scheduler.dispatch.route
  %396 = load <8 x i1>, ptr %current.mask, align 1
  %397 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %396)
  %398 = bitcast <8 x i1> %396 to i8
  %399 = call i8 @llvm.cttz.i8(i8 %398, i1 false)
  %400 = zext i8 %399 to i32
  %401 = select i1 %397, i32 %400, i32 0
  %.state638 = load <8 x i64>, ptr %.slot200, align 64
  %402 = select <8 x i1> %396, <8 x i64> %.state638, <8 x i64> zeroinitializer
  %403 = select <8 x i1> %396, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %404 = sdiv <8 x i64> %402, %403
  %405 = add <8 x i64> splat (i64 32), %404
  %tile_snapshot.spill.load639 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill195, align 64
  %406 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load639, 0
  %407 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load639, 1
  %408 = mul <8 x i64> %405, splat (i64 32)
  %409 = add <8 x i64> %407, %408
  %410 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %406, 0
  %411 = insertvalue { <8 x ptr>, <8 x i64> } %410, <8 x i64> %409, 1
  %412 = extractvalue { <8 x ptr>, <8 x i64> } %411, 0
  %413 = extractvalue { <8 x ptr>, <8 x i64> } %411, 1
  %414 = getelementptr i8, <8 x ptr> %412, <8 x i64> %413
  %415 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %414, <8 x i1> %396, <8 x float> zeroinitializer)
  %.state640 = load <8 x float>, ptr %.slot201, align 32
  %416 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state640, <8 x float> %415)
  %.state641 = load <8 x i64>, ptr %.slot200, align 64
  %417 = add <8 x i64> %.state641, splat (i64 1)
  %418 = load <8 x i64>, ptr %.slot200, align 64
  %419 = select <8 x i1> %396, <8 x i64> %417, <8 x i64> %418
  store <8 x i64> %419, ptr %.slot200, align 64
  %420 = load <8 x float>, ptr %.slot201, align 32
  %421 = select <8 x i1> %396, <8 x float> %416, <8 x float> %420
  store <8 x float> %421, ptr %.slot201, align 32
  store <8 x i1> %396, ptr %current.mask, align 1
  %422 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %396)
  br i1 %422, label %schedule.18, label %scheduler.loop

schedule.20:                                      ; preds = %varying.coherent.false637, %scheduler.dispatch.route
  %423 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token644 = load i32, ptr %current.token, align 4
  %convergence.token.present645 = icmp ne i32 %convergence.current.token644, 0
  br i1 %convergence.token.present645, label %convergence.cascade642, label %convergence.cascade.exit643

schedule.21:                                      ; preds = %schedule.22, %convergence.target.20.ready, %scheduler.dispatch.route
  %424 = load <8 x i1>, ptr %current.mask, align 1
  %425 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %424)
  %426 = bitcast <8 x i1> %424 to i8
  %427 = call i8 @llvm.cttz.i8(i8 %426, i1 false)
  %428 = zext i8 %427 to i32
  %429 = select i1 %425, i32 %428, i32 0
  %.state659 = load <8 x i64>, ptr %.slot202, align 64
  %430 = icmp slt <8 x i64> %.state659, splat (i64 16)
  %431 = and <8 x i1> %424, %430
  %432 = xor <8 x i1> %430, splat (i1 true)
  %433 = and <8 x i1> %424, %432
  %434 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %431)
  %435 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %433)
  %436 = and i1 %434, %435
  br i1 %436, label %varying.divergent660, label %varying.coherent661

schedule.22:                                      ; preds = %varying.coherent.true666, %scheduler.dispatch.route
  %437 = load <8 x i1>, ptr %current.mask, align 1
  %438 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %437)
  %439 = bitcast <8 x i1> %437 to i8
  %440 = call i8 @llvm.cttz.i8(i8 %439, i1 false)
  %441 = zext i8 %440 to i32
  %442 = select i1 %438, i32 %441, i32 0
  %.state668 = load <8 x i64>, ptr %.slot202, align 64
  %443 = select <8 x i1> %437, <8 x i64> %.state668, <8 x i64> zeroinitializer
  %444 = select <8 x i1> %437, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %445 = sdiv <8 x i64> %443, %444
  %446 = add <8 x i64> splat (i64 48), %445
  %tile_snapshot.spill.load669 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill195, align 64
  %447 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load669, 0
  %448 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load669, 1
  %449 = mul <8 x i64> %446, splat (i64 32)
  %450 = add <8 x i64> %448, %449
  %451 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %447, 0
  %452 = insertvalue { <8 x ptr>, <8 x i64> } %451, <8 x i64> %450, 1
  %453 = extractvalue { <8 x ptr>, <8 x i64> } %452, 0
  %454 = extractvalue { <8 x ptr>, <8 x i64> } %452, 1
  %455 = getelementptr i8, <8 x ptr> %453, <8 x i64> %454
  %456 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %455, <8 x i1> %437, <8 x float> zeroinitializer)
  %.state670 = load <8 x float>, ptr %.slot203, align 32
  %457 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state670, <8 x float> %456)
  %.state671 = load <8 x i64>, ptr %.slot202, align 64
  %458 = add <8 x i64> %.state671, splat (i64 1)
  %459 = load <8 x i64>, ptr %.slot202, align 64
  %460 = select <8 x i1> %437, <8 x i64> %458, <8 x i64> %459
  store <8 x i64> %460, ptr %.slot202, align 64
  %461 = load <8 x float>, ptr %.slot203, align 32
  %462 = select <8 x i1> %437, <8 x float> %457, <8 x float> %461
  store <8 x float> %462, ptr %.slot203, align 32
  store <8 x i1> %437, ptr %current.mask, align 1
  %463 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %437)
  br i1 %463, label %schedule.21, label %scheduler.loop

schedule.23:                                      ; preds = %varying.coherent.false667, %scheduler.dispatch.route
  %464 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token674 = load i32, ptr %current.token, align 4
  %convergence.token.present675 = icmp ne i32 %convergence.current.token674, 0
  br i1 %convergence.token.present675, label %convergence.cascade672, label %convergence.cascade.exit673

schedule.24:                                      ; preds = %schedule.25, %convergence.target.23.ready, %scheduler.dispatch.route
  %465 = load <8 x i1>, ptr %current.mask, align 1
  %466 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %465)
  %467 = bitcast <8 x i1> %465 to i8
  %468 = call i8 @llvm.cttz.i8(i8 %467, i1 false)
  %469 = zext i8 %468 to i32
  %470 = select i1 %466, i32 %469, i32 0
  %.state908 = load <8 x i64>, ptr %.slot214, align 64
  %471 = icmp slt <8 x i64> %.state908, splat (i64 16)
  %472 = and <8 x i1> %465, %471
  %473 = xor <8 x i1> %471, splat (i1 true)
  %474 = and <8 x i1> %465, %473
  %475 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %472)
  %476 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %474)
  %477 = and i1 %475, %476
  br i1 %477, label %varying.divergent909, label %varying.coherent910

schedule.25:                                      ; preds = %varying.coherent.true915, %scheduler.dispatch.route
  %478 = load <8 x i1>, ptr %current.mask, align 1
  %479 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %478)
  %480 = bitcast <8 x i1> %478 to i8
  %481 = call i8 @llvm.cttz.i8(i8 %480, i1 false)
  %482 = zext i8 %481 to i32
  %483 = select i1 %479, i32 %482, i32 0
  %.state917 = load <8 x i64>, ptr %.slot214, align 64
  %484 = select <8 x i1> %478, <8 x i64> %.state917, <8 x i64> zeroinitializer
  %485 = select <8 x i1> %478, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %486 = sdiv <8 x i64> %484, %485
  %487 = add <8 x i64> zeroinitializer, %486
  %tile_snapshot.spill.load918 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill209, align 64
  %488 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load918, 0
  %489 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load918, 1
  %490 = mul <8 x i64> %487, splat (i64 4)
  %491 = add <8 x i64> %489, %490
  %492 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %488, 0
  %493 = insertvalue { <8 x ptr>, <8 x i64> } %492, <8 x i64> %491, 1
  %494 = extractvalue { <8 x ptr>, <8 x i64> } %493, 0
  %495 = extractvalue { <8 x ptr>, <8 x i64> } %493, 1
  %496 = getelementptr i8, <8 x ptr> %494, <8 x i64> %495
  %497 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %496, <8 x i1> %478, <8 x float> zeroinitializer)
  %.state919 = load <8 x float>, ptr %.slot215, align 32
  %498 = fadd <8 x float> %.state919, %497
  %.state920 = load <8 x i64>, ptr %.slot214, align 64
  %499 = add <8 x i64> %.state920, splat (i64 1)
  %500 = load <8 x i64>, ptr %.slot214, align 64
  %501 = select <8 x i1> %478, <8 x i64> %499, <8 x i64> %500
  store <8 x i64> %501, ptr %.slot214, align 64
  %502 = load <8 x float>, ptr %.slot215, align 32
  %503 = select <8 x i1> %478, <8 x float> %498, <8 x float> %502
  store <8 x float> %503, ptr %.slot215, align 32
  store <8 x i1> %478, ptr %current.mask, align 1
  %504 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %478)
  br i1 %504, label %schedule.24, label %scheduler.loop

schedule.26:                                      ; preds = %varying.coherent.false916, %scheduler.dispatch.route
  %505 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token923 = load i32, ptr %current.token, align 4
  %convergence.token.present924 = icmp ne i32 %convergence.current.token923, 0
  br i1 %convergence.token.present924, label %convergence.cascade921, label %convergence.cascade.exit922

schedule.27:                                      ; preds = %schedule.28, %convergence.target.26.ready, %scheduler.dispatch.route
  %506 = load <8 x i1>, ptr %current.mask, align 1
  %507 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %506)
  %508 = bitcast <8 x i1> %506 to i8
  %509 = call i8 @llvm.cttz.i8(i8 %508, i1 false)
  %510 = zext i8 %509 to i32
  %511 = select i1 %507, i32 %510, i32 0
  %.state938 = load <8 x i64>, ptr %.slot216, align 64
  %512 = icmp slt <8 x i64> %.state938, splat (i64 16)
  %513 = and <8 x i1> %506, %512
  %514 = xor <8 x i1> %512, splat (i1 true)
  %515 = and <8 x i1> %506, %514
  %516 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %513)
  %517 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %515)
  %518 = and i1 %516, %517
  br i1 %518, label %varying.divergent939, label %varying.coherent940

schedule.28:                                      ; preds = %varying.coherent.true945, %scheduler.dispatch.route
  %519 = load <8 x i1>, ptr %current.mask, align 1
  %520 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %519)
  %521 = bitcast <8 x i1> %519 to i8
  %522 = call i8 @llvm.cttz.i8(i8 %521, i1 false)
  %523 = zext i8 %522 to i32
  %524 = select i1 %520, i32 %523, i32 0
  %.state947 = load <8 x i64>, ptr %.slot216, align 64
  %525 = select <8 x i1> %519, <8 x i64> %.state947, <8 x i64> zeroinitializer
  %526 = select <8 x i1> %519, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %527 = sdiv <8 x i64> %525, %526
  %528 = add <8 x i64> splat (i64 16), %527
  %tile_snapshot.spill.load948 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill209, align 64
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load948, 0
  %530 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load948, 1
  %531 = mul <8 x i64> %528, splat (i64 4)
  %532 = add <8 x i64> %530, %531
  %533 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %529, 0
  %534 = insertvalue { <8 x ptr>, <8 x i64> } %533, <8 x i64> %532, 1
  %535 = extractvalue { <8 x ptr>, <8 x i64> } %534, 0
  %536 = extractvalue { <8 x ptr>, <8 x i64> } %534, 1
  %537 = getelementptr i8, <8 x ptr> %535, <8 x i64> %536
  %538 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %537, <8 x i1> %519, <8 x float> zeroinitializer)
  %.state949 = load <8 x float>, ptr %.slot217, align 32
  %539 = fadd <8 x float> %.state949, %538
  %.state950 = load <8 x i64>, ptr %.slot216, align 64
  %540 = add <8 x i64> %.state950, splat (i64 1)
  %541 = load <8 x i64>, ptr %.slot216, align 64
  %542 = select <8 x i1> %519, <8 x i64> %540, <8 x i64> %541
  store <8 x i64> %542, ptr %.slot216, align 64
  %543 = load <8 x float>, ptr %.slot217, align 32
  %544 = select <8 x i1> %519, <8 x float> %539, <8 x float> %543
  store <8 x float> %544, ptr %.slot217, align 32
  store <8 x i1> %519, ptr %current.mask, align 1
  %545 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %519)
  br i1 %545, label %schedule.27, label %scheduler.loop

schedule.29:                                      ; preds = %varying.coherent.false946, %scheduler.dispatch.route
  %546 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token953 = load i32, ptr %current.token, align 4
  %convergence.token.present954 = icmp ne i32 %convergence.current.token953, 0
  br i1 %convergence.token.present954, label %convergence.cascade951, label %convergence.cascade.exit952

schedule.30:                                      ; preds = %schedule.31, %convergence.target.29.ready, %scheduler.dispatch.route
  %547 = load <8 x i1>, ptr %current.mask, align 1
  %548 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %547)
  %549 = bitcast <8 x i1> %547 to i8
  %550 = call i8 @llvm.cttz.i8(i8 %549, i1 false)
  %551 = zext i8 %550 to i32
  %552 = select i1 %548, i32 %551, i32 0
  %.state968 = load <8 x i64>, ptr %.slot218, align 64
  %553 = icmp slt <8 x i64> %.state968, splat (i64 16)
  %554 = and <8 x i1> %547, %553
  %555 = xor <8 x i1> %553, splat (i1 true)
  %556 = and <8 x i1> %547, %555
  %557 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %554)
  %558 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %556)
  %559 = and i1 %557, %558
  br i1 %559, label %varying.divergent969, label %varying.coherent970

schedule.31:                                      ; preds = %varying.coherent.true975, %scheduler.dispatch.route
  %560 = load <8 x i1>, ptr %current.mask, align 1
  %561 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %560)
  %562 = bitcast <8 x i1> %560 to i8
  %563 = call i8 @llvm.cttz.i8(i8 %562, i1 false)
  %564 = zext i8 %563 to i32
  %565 = select i1 %561, i32 %564, i32 0
  %.state977 = load <8 x i64>, ptr %.slot218, align 64
  %566 = select <8 x i1> %560, <8 x i64> %.state977, <8 x i64> zeroinitializer
  %567 = select <8 x i1> %560, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %568 = sdiv <8 x i64> %566, %567
  %569 = add <8 x i64> splat (i64 32), %568
  %tile_snapshot.spill.load978 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill209, align 64
  %570 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load978, 0
  %571 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load978, 1
  %572 = mul <8 x i64> %569, splat (i64 4)
  %573 = add <8 x i64> %571, %572
  %574 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %570, 0
  %575 = insertvalue { <8 x ptr>, <8 x i64> } %574, <8 x i64> %573, 1
  %576 = extractvalue { <8 x ptr>, <8 x i64> } %575, 0
  %577 = extractvalue { <8 x ptr>, <8 x i64> } %575, 1
  %578 = getelementptr i8, <8 x ptr> %576, <8 x i64> %577
  %579 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %578, <8 x i1> %560, <8 x float> zeroinitializer)
  %.state979 = load <8 x float>, ptr %.slot219, align 32
  %580 = fadd <8 x float> %.state979, %579
  %.state980 = load <8 x i64>, ptr %.slot218, align 64
  %581 = add <8 x i64> %.state980, splat (i64 1)
  %582 = load <8 x i64>, ptr %.slot218, align 64
  %583 = select <8 x i1> %560, <8 x i64> %581, <8 x i64> %582
  store <8 x i64> %583, ptr %.slot218, align 64
  %584 = load <8 x float>, ptr %.slot219, align 32
  %585 = select <8 x i1> %560, <8 x float> %580, <8 x float> %584
  store <8 x float> %585, ptr %.slot219, align 32
  store <8 x i1> %560, ptr %current.mask, align 1
  %586 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %560)
  br i1 %586, label %schedule.30, label %scheduler.loop

schedule.32:                                      ; preds = %varying.coherent.false976, %scheduler.dispatch.route
  %587 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token983 = load i32, ptr %current.token, align 4
  %convergence.token.present984 = icmp ne i32 %convergence.current.token983, 0
  br i1 %convergence.token.present984, label %convergence.cascade981, label %convergence.cascade.exit982

schedule.33:                                      ; preds = %schedule.34, %convergence.target.32.ready, %scheduler.dispatch.route
  %588 = load <8 x i1>, ptr %current.mask, align 1
  %589 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %588)
  %590 = bitcast <8 x i1> %588 to i8
  %591 = call i8 @llvm.cttz.i8(i8 %590, i1 false)
  %592 = zext i8 %591 to i32
  %593 = select i1 %589, i32 %592, i32 0
  %.state998 = load <8 x i64>, ptr %.slot220, align 64
  %594 = icmp slt <8 x i64> %.state998, splat (i64 16)
  %595 = and <8 x i1> %588, %594
  %596 = xor <8 x i1> %594, splat (i1 true)
  %597 = and <8 x i1> %588, %596
  %598 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %595)
  %599 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %597)
  %600 = and i1 %598, %599
  br i1 %600, label %varying.divergent999, label %varying.coherent1000

schedule.34:                                      ; preds = %varying.coherent.true1005, %scheduler.dispatch.route
  %601 = load <8 x i1>, ptr %current.mask, align 1
  %602 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %601)
  %603 = bitcast <8 x i1> %601 to i8
  %604 = call i8 @llvm.cttz.i8(i8 %603, i1 false)
  %605 = zext i8 %604 to i32
  %606 = select i1 %602, i32 %605, i32 0
  %.state1007 = load <8 x i64>, ptr %.slot220, align 64
  %607 = select <8 x i1> %601, <8 x i64> %.state1007, <8 x i64> zeroinitializer
  %608 = select <8 x i1> %601, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %609 = sdiv <8 x i64> %607, %608
  %610 = add <8 x i64> splat (i64 48), %609
  %tile_snapshot.spill.load1008 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill209, align 64
  %611 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1008, 0
  %612 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1008, 1
  %613 = mul <8 x i64> %610, splat (i64 4)
  %614 = add <8 x i64> %612, %613
  %615 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %611, 0
  %616 = insertvalue { <8 x ptr>, <8 x i64> } %615, <8 x i64> %614, 1
  %617 = extractvalue { <8 x ptr>, <8 x i64> } %616, 0
  %618 = extractvalue { <8 x ptr>, <8 x i64> } %616, 1
  %619 = getelementptr i8, <8 x ptr> %617, <8 x i64> %618
  %620 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %619, <8 x i1> %601, <8 x float> zeroinitializer)
  %.state1009 = load <8 x float>, ptr %.slot221, align 32
  %621 = fadd <8 x float> %.state1009, %620
  %.state1010 = load <8 x i64>, ptr %.slot220, align 64
  %622 = add <8 x i64> %.state1010, splat (i64 1)
  %623 = load <8 x i64>, ptr %.slot220, align 64
  %624 = select <8 x i1> %601, <8 x i64> %622, <8 x i64> %623
  store <8 x i64> %624, ptr %.slot220, align 64
  %625 = load <8 x float>, ptr %.slot221, align 32
  %626 = select <8 x i1> %601, <8 x float> %621, <8 x float> %625
  store <8 x float> %626, ptr %.slot221, align 32
  store <8 x i1> %601, ptr %current.mask, align 1
  %627 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %601)
  br i1 %627, label %schedule.33, label %scheduler.loop

schedule.35:                                      ; preds = %varying.coherent.false1006, %scheduler.dispatch.route
  %628 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1013 = load i32, ptr %current.token, align 4
  %convergence.token.present1014 = icmp ne i32 %convergence.current.token1013, 0
  br i1 %convergence.token.present1014, label %convergence.cascade1011, label %convergence.cascade.exit1012

schedule.36:                                      ; preds = %schedule.37, %convergence.target.35.ready, %scheduler.dispatch.route
  %629 = load <8 x i1>, ptr %current.mask, align 1
  %630 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %629)
  %631 = bitcast <8 x i1> %629 to i8
  %632 = call i8 @llvm.cttz.i8(i8 %631, i1 false)
  %633 = zext i8 %632 to i32
  %634 = select i1 %630, i32 %633, i32 0
  %.state1036 = load <8 x i64>, ptr %.slot227, align 64
  %635 = icmp slt <8 x i64> %.state1036, splat (i64 192)
  %636 = and <8 x i1> %629, %635
  %637 = xor <8 x i1> %635, splat (i1 true)
  %638 = and <8 x i1> %629, %637
  %639 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %636)
  %640 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %638)
  %641 = and i1 %639, %640
  br i1 %641, label %varying.divergent1037, label %varying.coherent1038

schedule.37:                                      ; preds = %varying.coherent.true1043, %scheduler.dispatch.route
  %642 = load <8 x i1>, ptr %current.mask, align 1
  %643 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %642)
  %644 = bitcast <8 x i1> %642 to i8
  %645 = call i8 @llvm.cttz.i8(i8 %644, i1 false)
  %646 = zext i8 %645 to i32
  %647 = select i1 %643, i32 %646, i32 0
  %.state1045 = load <8 x i64>, ptr %.slot227, align 64
  %648 = select <8 x i1> %642, <8 x i64> %.state1045, <8 x i64> zeroinitializer
  %649 = select <8 x i1> %642, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %650 = srem <8 x i64> %648, %649
  %.state1046 = load <8 x i64>, ptr %.slot227, align 64
  %651 = select <8 x i1> %642, <8 x i64> %.state1046, <8 x i64> zeroinitializer
  %652 = select <8 x i1> %642, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %653 = sdiv <8 x i64> %651, %652
  %654 = add <8 x i64> zeroinitializer, %653
  %655 = mul <8 x i64> %654, splat (i64 48)
  %656 = add <8 x i64> %655, %650
  %tile_snapshot.spill.load1047 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %657 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1047, 0
  %658 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1047, 1
  %659 = mul <8 x i64> %656, splat (i64 32)
  %660 = add <8 x i64> %658, %659
  %661 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %657, 0
  %662 = insertvalue { <8 x ptr>, <8 x i64> } %661, <8 x i64> %660, 1
  %663 = extractvalue { <8 x ptr>, <8 x i64> } %662, 0
  %664 = extractvalue { <8 x ptr>, <8 x i64> } %662, 1
  %665 = getelementptr i8, <8 x ptr> %663, <8 x i64> %664
  %666 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %665, <8 x i1> %642, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1048 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill208, align 64
  %667 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1048, 0
  %668 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1048, 1
  %669 = mul <8 x i64> %654, splat (i64 32)
  %670 = add <8 x i64> %668, %669
  %671 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %667, 0
  %672 = insertvalue { <8 x ptr>, <8 x i64> } %671, <8 x i64> %670, 1
  %673 = extractvalue { <8 x ptr>, <8 x i64> } %672, 0
  %674 = extractvalue { <8 x ptr>, <8 x i64> } %672, 1
  %675 = getelementptr i8, <8 x ptr> %673, <8 x i64> %674
  %676 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %675, <8 x i1> %642, <8 x float> zeroinitializer)
  %677 = fmul <8 x float> %666, %676
  %tile_snapshot.spill.load1049 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill226, align 64
  %678 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1049, 0
  %679 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1049, 1
  %.state1050 = load <8 x i64>, ptr %.slot227, align 64
  %680 = mul <8 x i64> %.state1050, splat (i64 4)
  %681 = add <8 x i64> %679, %680
  %682 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %678, 0
  %683 = insertvalue { <8 x ptr>, <8 x i64> } %682, <8 x i64> %681, 1
  %684 = extractvalue { <8 x ptr>, <8 x i64> } %683, 0
  %685 = extractvalue { <8 x ptr>, <8 x i64> } %683, 1
  %686 = getelementptr i8, <8 x ptr> %684, <8 x i64> %685
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %677, <8 x ptr> align 1 %686, <8 x i1> %642)
  %.state1051 = load <8 x i64>, ptr %.slot227, align 64
  %687 = add <8 x i64> %.state1051, splat (i64 1)
  %688 = load <8 x i64>, ptr %.slot227, align 64
  %689 = select <8 x i1> %642, <8 x i64> %687, <8 x i64> %688
  store <8 x i64> %689, ptr %.slot227, align 64
  store <8 x i1> %642, ptr %current.mask, align 1
  %690 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %642)
  br i1 %690, label %schedule.36, label %scheduler.loop

schedule.38:                                      ; preds = %varying.coherent.false1044, %scheduler.dispatch.route
  %691 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1054 = load i32, ptr %current.token, align 4
  %convergence.token.present1055 = icmp ne i32 %convergence.current.token1054, 0
  br i1 %convergence.token.present1055, label %convergence.cascade1052, label %convergence.cascade.exit1053

schedule.39:                                      ; preds = %schedule.40, %mma.continue1087, %scheduler.dispatch.route
  %692 = load <8 x i1>, ptr %current.mask, align 1
  %693 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %692)
  %694 = bitcast <8 x i1> %692 to i8
  %695 = call i8 @llvm.cttz.i8(i8 %694, i1 false)
  %696 = zext i8 %695 to i32
  %697 = select i1 %693, i32 %696, i32 0
  %.state1088 = load <8 x i64>, ptr %.slot229, align 64
  %698 = icmp slt <8 x i64> %.state1088, splat (i64 192)
  %699 = and <8 x i1> %692, %698
  %700 = xor <8 x i1> %698, splat (i1 true)
  %701 = and <8 x i1> %692, %700
  %702 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %699)
  %703 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %701)
  %704 = and i1 %702, %703
  br i1 %704, label %varying.divergent1089, label %varying.coherent1090

schedule.40:                                      ; preds = %varying.coherent.true1095, %scheduler.dispatch.route
  %705 = load <8 x i1>, ptr %current.mask, align 1
  %706 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %705)
  %707 = bitcast <8 x i1> %705 to i8
  %708 = call i8 @llvm.cttz.i8(i8 %707, i1 false)
  %709 = zext i8 %708 to i32
  %710 = select i1 %706, i32 %709, i32 0
  %tile_snapshot.spill.load1097 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill228, align 64
  %711 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1097, 0
  %712 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1097, 1
  %.state1098 = load <8 x i64>, ptr %.slot229, align 64
  %713 = mul <8 x i64> %.state1098, splat (i64 4)
  %714 = add <8 x i64> %712, %713
  %715 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %711, 0
  %716 = insertvalue { <8 x ptr>, <8 x i64> } %715, <8 x i64> %714, 1
  %717 = extractvalue { <8 x ptr>, <8 x i64> } %716, 0
  %718 = extractvalue { <8 x ptr>, <8 x i64> } %716, 1
  %719 = getelementptr i8, <8 x ptr> %717, <8 x i64> %718
  %720 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %719, <8 x i1> %705, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1099 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill53, align 64
  %721 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1099, 0
  %722 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1099, 1
  %.state1100 = load <8 x i64>, ptr %.slot229, align 64
  %723 = mul <8 x i64> %.state1100, splat (i64 32)
  %724 = add <8 x i64> %722, %723
  %725 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %721, 0
  %726 = insertvalue { <8 x ptr>, <8 x i64> } %725, <8 x i64> %724, 1
  %727 = extractvalue { <8 x ptr>, <8 x i64> } %726, 0
  %728 = extractvalue { <8 x ptr>, <8 x i64> } %726, 1
  %729 = getelementptr i8, <8 x ptr> %727, <8 x i64> %728
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %720, <8 x ptr> align 1 %729, <8 x i1> %705)
  %.state1101 = load <8 x i64>, ptr %.slot229, align 64
  %730 = add <8 x i64> %.state1101, splat (i64 1)
  %731 = load <8 x i64>, ptr %.slot229, align 64
  %732 = select <8 x i1> %705, <8 x i64> %730, <8 x i64> %731
  store <8 x i64> %732, ptr %.slot229, align 64
  store <8 x i1> %705, ptr %current.mask, align 1
  %733 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %705)
  br i1 %733, label %schedule.39, label %scheduler.loop

schedule.41:                                      ; preds = %varying.coherent.false1096, %scheduler.dispatch.route
  %734 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1104 = load i32, ptr %current.token, align 4
  %convergence.token.present1105 = icmp ne i32 %convergence.current.token1104, 0
  br i1 %convergence.token.present1105, label %convergence.cascade1102, label %convergence.cascade.exit1103

schedule.42:                                      ; preds = %schedule.43, %convergence.target.41.ready, %scheduler.dispatch.route
  %735 = load <8 x i1>, ptr %current.mask, align 1
  %736 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %735)
  %737 = bitcast <8 x i1> %735 to i8
  %738 = call i8 @llvm.cttz.i8(i8 %737, i1 false)
  %739 = zext i8 %738 to i32
  %740 = select i1 %736, i32 %739, i32 0
  %.state1119 = load <8 x i64>, ptr %.slot230, align 64
  %741 = icmp slt <8 x i64> %.state1119, splat (i64 192)
  %742 = and <8 x i1> %735, %741
  %743 = xor <8 x i1> %741, splat (i1 true)
  %744 = and <8 x i1> %735, %743
  %745 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %742)
  %746 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %744)
  %747 = and i1 %745, %746
  br i1 %747, label %varying.divergent1120, label %varying.coherent1121

schedule.43:                                      ; preds = %varying.coherent.true1126, %scheduler.dispatch.route
  %748 = load <8 x i1>, ptr %current.mask, align 1
  %749 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %748)
  %750 = bitcast <8 x i1> %748 to i8
  %751 = call i8 @llvm.cttz.i8(i8 %750, i1 false)
  %752 = zext i8 %751 to i32
  %753 = select i1 %749, i32 %752, i32 0
  %tile_snapshot.spill.load1128 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill53, align 64
  %754 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1128, 0
  %755 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1128, 1
  %.state1129 = load <8 x i64>, ptr %.slot230, align 64
  %756 = mul <8 x i64> %.state1129, splat (i64 32)
  %757 = add <8 x i64> %755, %756
  %758 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %754, 0
  %759 = insertvalue { <8 x ptr>, <8 x i64> } %758, <8 x i64> %757, 1
  %760 = extractvalue { <8 x ptr>, <8 x i64> } %759, 0
  %761 = extractvalue { <8 x ptr>, <8 x i64> } %759, 1
  %762 = getelementptr i8, <8 x ptr> %760, <8 x i64> %761
  %763 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %762, <8 x i1> %748, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1130 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %764 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1130, 0
  %765 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1130, 1
  %.state1131 = load <8 x i64>, ptr %.slot230, align 64
  %766 = mul <8 x i64> %.state1131, splat (i64 32)
  %767 = add <8 x i64> %765, %766
  %768 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %764, 0
  %769 = insertvalue { <8 x ptr>, <8 x i64> } %768, <8 x i64> %767, 1
  %770 = extractvalue { <8 x ptr>, <8 x i64> } %769, 0
  %771 = extractvalue { <8 x ptr>, <8 x i64> } %769, 1
  %772 = getelementptr i8, <8 x ptr> %770, <8 x i64> %771
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %763, <8 x ptr> align 1 %772, <8 x i1> %748)
  %.state1132 = load <8 x i64>, ptr %.slot230, align 64
  %773 = add <8 x i64> %.state1132, splat (i64 1)
  %774 = load <8 x i64>, ptr %.slot230, align 64
  %775 = select <8 x i1> %748, <8 x i64> %773, <8 x i64> %774
  store <8 x i64> %775, ptr %.slot230, align 64
  store <8 x i1> %748, ptr %current.mask, align 1
  %776 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %748)
  br i1 %776, label %schedule.42, label %scheduler.loop

schedule.44:                                      ; preds = %varying.coherent.false1127, %scheduler.dispatch.route
  %777 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1135 = load i32, ptr %current.token, align 4
  %convergence.token.present1136 = icmp ne i32 %convergence.current.token1135, 0
  br i1 %convergence.token.present1136, label %convergence.cascade1133, label %convergence.cascade.exit1134

schedule.45:                                      ; preds = %varying.coherent.false369, %scheduler.dispatch.route
  %778 = load <8 x i1>, ptr %current.mask, align 1
  %779 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %778)
  %780 = bitcast <8 x i1> %778 to i8
  %781 = call i8 @llvm.cttz.i8(i8 %780, i1 false)
  %782 = zext i8 %781 to i32
  %783 = select i1 %779, i32 %782, i32 0
  %784 = load <8 x i64>, ptr %.slot231, align 64
  %785 = select <8 x i1> %778, <8 x i64> zeroinitializer, <8 x i64> %784
  store <8 x i64> %785, ptr %.slot231, align 64
  store <8 x i1> %778, ptr %current.mask, align 1
  %786 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %778)
  br i1 %786, label %schedule.46, label %scheduler.loop

schedule.46:                                      ; preds = %convergence.target.49.ready, %schedule.45, %scheduler.dispatch.route
  %787 = load <8 x i1>, ptr %current.mask, align 1
  %788 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %787)
  %789 = bitcast <8 x i1> %787 to i8
  %790 = call i8 @llvm.cttz.i8(i8 %789, i1 false)
  %791 = zext i8 %790 to i32
  %792 = select i1 %788, i32 %791, i32 0
  %.state1159 = load <8 x i64>, ptr %.slot231, align 64
  %793 = icmp slt <8 x i64> %.state1159, splat (i64 768)
  %794 = and <8 x i1> %787, %793
  %795 = xor <8 x i1> %793, splat (i1 true)
  %796 = and <8 x i1> %787, %795
  %797 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %794)
  %798 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %796)
  %799 = and i1 %797, %798
  br i1 %799, label %varying.divergent1160, label %varying.coherent1161

schedule.47:                                      ; preds = %varying.coherent.true1166, %scheduler.dispatch.route
  %800 = load <8 x i1>, ptr %current.mask, align 1
  %801 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %800)
  %802 = bitcast <8 x i1> %800 to i8
  %803 = call i8 @llvm.cttz.i8(i8 %802, i1 false)
  %804 = zext i8 %803 to i32
  %805 = select i1 %801, i32 %804, i32 0
  %.state1168 = load <8 x i64>, ptr %.slot231, align 64
  %806 = select <8 x i1> %800, <8 x i64> %.state1168, <8 x i64> zeroinitializer
  %807 = select <8 x i1> %800, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %808 = srem <8 x i64> %806, %807
  %.state1169 = load <8 x i64>, ptr %.slot231, align 64
  %809 = select <8 x i1> %800, <8 x i64> %.state1169, <8 x i64> zeroinitializer
  %810 = select <8 x i1> %800, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %811 = sdiv <8 x i64> %809, %810
  %.spill.load1170 = load <8 x i64>, ptr %.spill, align 64
  %812 = add <8 x i64> %.spill.load1170, zeroinitializer
  %813 = add <8 x i64> zeroinitializer, %812
  %.spill.load1171 = load <8 x i64>, ptr %.spill51, align 64
  %814 = add <8 x i64> %.spill.load1171, zeroinitializer
  %815 = mul <8 x i64> %813, splat (i64 2)
  %816 = add <8 x i64> %815, %814
  %.spill.load1172 = load <8 x i64>, ptr %.spill63, align 64
  %817 = add <8 x i64> %.spill.load1172, %811
  %818 = mul <8 x i64> %816, splat (i64 67)
  %819 = add <8 x i64> %818, %817
  %820 = icmp sge <8 x i64> %817, zeroinitializer
  %821 = and <8 x i1> splat (i1 true), %820
  %822 = icmp slt <8 x i64> %817, splat (i64 67)
  %823 = and <8 x i1> %821, %822
  %824 = add <8 x i64> zeroinitializer, %808
  %825 = mul <8 x i64> %819, splat (i64 48)
  %826 = add <8 x i64> %825, %824
  %827 = load volatile <8 x i64>, ptr %.spill232, align 64
  %828 = select <8 x i1> %800, <8 x i64> %826, <8 x i64> %827
  store volatile <8 x i64> %828, ptr %.spill232, align 64
  %829 = and <8 x i1> %800, %823
  %830 = xor <8 x i1> %823, splat (i1 true)
  %831 = and <8 x i1> %800, %830
  %832 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %829)
  %833 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %831)
  %834 = and i1 %832, %833
  br i1 %834, label %varying.divergent1173, label %varying.coherent1174

schedule.48:                                      ; preds = %varying.coherent.true1179, %scheduler.dispatch.route
  %835 = load <8 x i1>, ptr %current.mask, align 1
  %836 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %835)
  %837 = bitcast <8 x i1> %835 to i8
  %838 = call i8 @llvm.cttz.i8(i8 %837, i1 false)
  %839 = zext i8 %838 to i32
  %840 = select i1 %836, i32 %839, i32 0
  %.spill.load1181 = load volatile <8 x i64>, ptr %.spill232, align 64
  %841 = extractvalue { ptr, i64 } %56, 0
  %842 = mul <8 x i64> %.spill.load1181, splat (i64 4)
  %843 = getelementptr i8, ptr %841, <8 x i64> %842
  %844 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %843, <8 x i1> %835, <8 x float> zeroinitializer)
  %845 = load <8 x float>, ptr %.slot233, align 32
  %846 = select <8 x i1> %835, <8 x float> %844, <8 x float> %845
  store <8 x float> %846, ptr %.slot233, align 32
  store <8 x i1> %835, ptr %current.mask, align 1
  %847 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %835)
  br i1 %847, label %schedule.49, label %scheduler.loop

schedule.49:                                      ; preds = %schedule.48, %varying.coherent.false1180, %scheduler.dispatch.route
  %848 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1184 = load i32, ptr %current.token, align 4
  %convergence.token.present1185 = icmp ne i32 %convergence.current.token1184, 0
  br i1 %convergence.token.present1185, label %convergence.cascade1182, label %convergence.cascade.exit1183

schedule.50:                                      ; preds = %varying.coherent.false323, %scheduler.dispatch.route
  %849 = load <8 x i1>, ptr %current.mask, align 1
  %850 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %849)
  %851 = bitcast <8 x i1> %849 to i8
  %852 = call i8 @llvm.cttz.i8(i8 %851, i1 false)
  %853 = zext i8 %852 to i32
  %854 = select i1 %850, i32 %853, i32 0
  %855 = load <8 x i64>, ptr %.slot234, align 64
  %856 = select <8 x i1> %849, <8 x i64> zeroinitializer, <8 x i64> %855
  store <8 x i64> %856, ptr %.slot234, align 64
  store <8 x i1> %849, ptr %current.mask, align 1
  %857 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %849)
  br i1 %857, label %schedule.51, label %scheduler.loop

schedule.51:                                      ; preds = %convergence.target.54.ready, %schedule.50, %scheduler.dispatch.route
  %858 = load <8 x i1>, ptr %current.mask, align 1
  %859 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %858)
  %860 = bitcast <8 x i1> %858 to i8
  %861 = call i8 @llvm.cttz.i8(i8 %860, i1 false)
  %862 = zext i8 %861 to i32
  %863 = select i1 %859, i32 %862, i32 0
  %.state1203 = load <8 x i64>, ptr %.slot234, align 64
  %864 = icmp slt <8 x i64> %.state1203, splat (i64 640)
  %865 = and <8 x i1> %858, %864
  %866 = xor <8 x i1> %864, splat (i1 true)
  %867 = and <8 x i1> %858, %866
  %868 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %865)
  %869 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %867)
  %870 = and i1 %868, %869
  br i1 %870, label %varying.divergent1204, label %varying.coherent1205

schedule.52:                                      ; preds = %varying.coherent.true1210, %scheduler.dispatch.route
  %871 = load <8 x i1>, ptr %current.mask, align 1
  %872 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %871)
  %873 = bitcast <8 x i1> %871 to i8
  %874 = call i8 @llvm.cttz.i8(i8 %873, i1 false)
  %875 = zext i8 %874 to i32
  %876 = select i1 %872, i32 %875, i32 0
  %.state1212 = load <8 x i64>, ptr %.slot234, align 64
  %877 = select <8 x i1> %871, <8 x i64> %.state1212, <8 x i64> zeroinitializer
  %878 = select <8 x i1> %871, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %879 = srem <8 x i64> %877, %878
  %.state1213 = load <8 x i64>, ptr %.slot234, align 64
  %880 = select <8 x i1> %871, <8 x i64> %.state1213, <8 x i64> zeroinitializer
  %881 = select <8 x i1> %871, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %882 = sdiv <8 x i64> %880, %881
  %.spill.load1214 = load <8 x i64>, ptr %.spill, align 64
  %883 = add <8 x i64> %.spill.load1214, zeroinitializer
  %884 = add <8 x i64> zeroinitializer, %883
  %.spill.load1215 = load <8 x i64>, ptr %.spill51, align 64
  %885 = add <8 x i64> %.spill.load1215, zeroinitializer
  %886 = mul <8 x i64> %884, splat (i64 2)
  %887 = add <8 x i64> %886, %885
  %.spill.load1216 = load <8 x i64>, ptr %.spill63, align 64
  %888 = add <8 x i64> %.spill.load1216, %882
  %889 = mul <8 x i64> %887, splat (i64 67)
  %890 = add <8 x i64> %889, %888
  %891 = icmp sge <8 x i64> %888, zeroinitializer
  %892 = and <8 x i1> splat (i1 true), %891
  %893 = icmp slt <8 x i64> %888, splat (i64 67)
  %894 = and <8 x i1> %892, %893
  %895 = add <8 x i64> zeroinitializer, %879
  %896 = mul <8 x i64> %890, splat (i64 40)
  %897 = add <8 x i64> %896, %895
  %898 = load volatile <8 x i64>, ptr %.spill235, align 64
  %899 = select <8 x i1> %871, <8 x i64> %897, <8 x i64> %898
  store volatile <8 x i64> %899, ptr %.spill235, align 64
  %900 = and <8 x i1> %871, %894
  %901 = xor <8 x i1> %894, splat (i1 true)
  %902 = and <8 x i1> %871, %901
  %903 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %900)
  %904 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %902)
  %905 = and i1 %903, %904
  br i1 %905, label %varying.divergent1217, label %varying.coherent1218

schedule.53:                                      ; preds = %varying.coherent.true1223, %scheduler.dispatch.route
  %906 = load <8 x i1>, ptr %current.mask, align 1
  %907 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %906)
  %908 = bitcast <8 x i1> %906 to i8
  %909 = call i8 @llvm.cttz.i8(i8 %908, i1 false)
  %910 = zext i8 %909 to i32
  %911 = select i1 %907, i32 %910, i32 0
  %.spill.load1225 = load volatile <8 x i64>, ptr %.spill235, align 64
  %912 = extractvalue { ptr, i64 } %50, 0
  %913 = mul <8 x i64> %.spill.load1225, splat (i64 4)
  %914 = getelementptr i8, ptr %912, <8 x i64> %913
  %915 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %914, <8 x i1> %906, <8 x float> zeroinitializer)
  %916 = load <8 x float>, ptr %.slot236, align 32
  %917 = select <8 x i1> %906, <8 x float> %915, <8 x float> %916
  store <8 x float> %917, ptr %.slot236, align 32
  store <8 x i1> %906, ptr %current.mask, align 1
  %918 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %906)
  br i1 %918, label %schedule.54, label %scheduler.loop

schedule.54:                                      ; preds = %schedule.53, %varying.coherent.false1224, %scheduler.dispatch.route
  %919 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1228 = load i32, ptr %current.token, align 4
  %convergence.token.present1229 = icmp ne i32 %convergence.current.token1228, 0
  br i1 %convergence.token.present1229, label %convergence.cascade1226, label %convergence.cascade.exit1227

schedule.55:                                      ; preds = %varying.coherent.false314, %scheduler.dispatch.route
  %920 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1249 = load i32, ptr %current.token, align 4
  %convergence.token.present1250 = icmp ne i32 %convergence.current.token1249, 0
  br i1 %convergence.token.present1250, label %convergence.cascade1247, label %convergence.cascade.exit1248

schedule.56:                                      ; preds = %convergence.target.59.ready, %convergence.target.55.ready, %scheduler.dispatch.route
  %921 = load <8 x i1>, ptr %current.mask, align 1
  %922 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %921)
  %923 = bitcast <8 x i1> %921 to i8
  %924 = call i8 @llvm.cttz.i8(i8 %923, i1 false)
  %925 = zext i8 %924 to i32
  %926 = select i1 %922, i32 %925, i32 0
  %.state1276 = load <8 x i64>, ptr %.slot238, align 64
  %927 = icmp slt <8 x i64> %.state1276, splat (i64 192)
  %928 = and <8 x i1> %921, %927
  %929 = xor <8 x i1> %927, splat (i1 true)
  %930 = and <8 x i1> %921, %929
  %931 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %928)
  %932 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %930)
  %933 = and i1 %931, %932
  br i1 %933, label %varying.divergent1277, label %varying.coherent1278

schedule.57:                                      ; preds = %varying.coherent.true1283, %scheduler.dispatch.route
  %934 = load <8 x i1>, ptr %current.mask, align 1
  %935 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %934)
  %936 = bitcast <8 x i1> %934 to i8
  %937 = call i8 @llvm.cttz.i8(i8 %936, i1 false)
  %938 = zext i8 %937 to i32
  %939 = select i1 %935, i32 %938, i32 0
  %.state1285 = load <8 x i64>, ptr %.slot238, align 64
  %940 = select <8 x i1> %934, <8 x i64> %.state1285, <8 x i64> zeroinitializer
  %941 = select <8 x i1> %934, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %942 = srem <8 x i64> %940, %941
  %.state1286 = load <8 x i64>, ptr %.slot238, align 64
  %943 = select <8 x i1> %934, <8 x i64> %.state1286, <8 x i64> zeroinitializer
  %944 = select <8 x i1> %934, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %945 = sdiv <8 x i64> %943, %944
  %.spill.load1287 = load <8 x i64>, ptr %.spill, align 64
  %946 = add <8 x i64> %.spill.load1287, zeroinitializer
  %947 = add <8 x i64> zeroinitializer, %946
  %.spill.load1288 = load volatile <8 x i64>, ptr %.spill49, align 64
  %948 = add <8 x i64> %.spill.load1288, zeroinitializer
  %949 = mul <8 x i64> %947, splat (i64 6)
  %950 = add <8 x i64> %949, %948
  %.spill.load1289 = load <8 x i64>, ptr %.spill50, align 64
  %951 = add <8 x i64> %.spill.load1289, %945
  %952 = mul <8 x i64> %950, splat (i64 17)
  %953 = add <8 x i64> %952, %951
  %954 = icmp sge <8 x i64> %951, zeroinitializer
  %955 = and <8 x i1> splat (i1 true), %954
  %956 = icmp slt <8 x i64> %951, splat (i64 17)
  %957 = and <8 x i1> %955, %956
  %958 = add <8 x i64> zeroinitializer, %942
  %959 = mul <8 x i64> %953, splat (i64 48)
  %960 = add <8 x i64> %959, %958
  %961 = load volatile <8 x i64>, ptr %.spill239, align 64
  %962 = select <8 x i1> %934, <8 x i64> %960, <8 x i64> %961
  store volatile <8 x i64> %962, ptr %.spill239, align 64
  %963 = add <8 x i64> zeroinitializer, %945
  %964 = mul <8 x i64> %963, splat (i64 48)
  %965 = add <8 x i64> %964, %942
  %tile_snapshot.spill.load1290 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %966 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1290, 0
  %967 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1290, 1
  %968 = mul <8 x i64> %965, splat (i64 32)
  %969 = add <8 x i64> %967, %968
  %970 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %966, 0
  %971 = insertvalue { <8 x ptr>, <8 x i64> } %970, <8 x i64> %969, 1
  %972 = extractvalue { <8 x ptr>, <8 x i64> } %971, 0
  %973 = extractvalue { <8 x ptr>, <8 x i64> } %971, 1
  %974 = getelementptr i8, <8 x ptr> %972, <8 x i64> %973
  %975 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %974, <8 x i1> %934, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1291 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill237, align 64
  %976 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1291, 0
  %977 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1291, 1
  %978 = mul <8 x i64> %963, splat (i64 32)
  %979 = add <8 x i64> %977, %978
  %980 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %976, 0
  %981 = insertvalue { <8 x ptr>, <8 x i64> } %980, <8 x i64> %979, 1
  %982 = extractvalue { <8 x ptr>, <8 x i64> } %981, 0
  %983 = extractvalue { <8 x ptr>, <8 x i64> } %981, 1
  %984 = getelementptr i8, <8 x ptr> %982, <8 x i64> %983
  %985 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %984, <8 x i1> %934, <8 x float> zeroinitializer)
  %986 = fdiv <8 x float> %975, %985
  %987 = load volatile <8 x float>, ptr %.spill240, align 32
  %988 = select <8 x i1> %934, <8 x float> %986, <8 x float> %987
  store volatile <8 x float> %988, ptr %.spill240, align 32
  %989 = and <8 x i1> %934, %957
  %990 = xor <8 x i1> %957, splat (i1 true)
  %991 = and <8 x i1> %934, %990
  %992 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %989)
  %993 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %991)
  %994 = and i1 %992, %993
  br i1 %994, label %varying.divergent1292, label %varying.coherent1293

schedule.58:                                      ; preds = %varying.coherent.true1298, %scheduler.dispatch.route
  %995 = load <8 x i1>, ptr %current.mask, align 1
  %996 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %995)
  %997 = bitcast <8 x i1> %995 to i8
  %998 = call i8 @llvm.cttz.i8(i8 %997, i1 false)
  %999 = zext i8 %998 to i32
  %1000 = select i1 %996, i32 %999, i32 0
  %.spill.load1300 = load volatile <8 x i64>, ptr %.spill239, align 64
  %.spill.load1301 = load volatile <8 x float>, ptr %.spill240, align 32
  %1001 = extractvalue { ptr, i64 } %62, 0
  %1002 = mul <8 x i64> %.spill.load1300, splat (i64 4)
  %1003 = getelementptr i8, ptr %1001, <8 x i64> %1002
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.spill.load1301, <8 x ptr> align 1 %1003, <8 x i1> %995)
  store <8 x i1> %995, ptr %current.mask, align 1
  %1004 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %995)
  br i1 %1004, label %schedule.59, label %scheduler.loop

schedule.59:                                      ; preds = %schedule.58, %varying.coherent.false1299, %scheduler.dispatch.route
  %1005 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1304 = load i32, ptr %current.token, align 4
  %convergence.token.present1305 = icmp ne i32 %convergence.current.token1304, 0
  br i1 %convergence.token.present1305, label %convergence.cascade1302, label %convergence.cascade.exit1303

schedule.60:                                      ; preds = %varying.coherent.false1284, %scheduler.dispatch.route
  %1006 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1322 = load i32, ptr %current.token, align 4
  %convergence.token.present1323 = icmp ne i32 %convergence.current.token1322, 0
  br i1 %convergence.token.present1323, label %convergence.cascade1320, label %convergence.cascade.exit1321

schedule.61:                                      ; preds = %varying.coherent.false, %scheduler.dispatch.route
  %1007 = load <8 x i1>, ptr %current.mask, align 1
  %1008 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1007)
  %1009 = bitcast <8 x i1> %1007 to i8
  %1010 = call i8 @llvm.cttz.i8(i8 %1009, i1 false)
  %1011 = zext i8 %1010 to i32
  %1012 = select i1 %1008, i32 %1011, i32 0
  %1013 = load <8 x i64>, ptr %.slot241, align 64
  %1014 = select <8 x i1> %1007, <8 x i64> zeroinitializer, <8 x i64> %1013
  store <8 x i64> %1014, ptr %.slot241, align 64
  store <8 x i1> %1007, ptr %current.mask, align 1
  %1015 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1007)
  br i1 %1015, label %schedule.62, label %scheduler.loop

schedule.62:                                      ; preds = %convergence.target.65.ready, %schedule.61, %scheduler.dispatch.route
  %1016 = load <8 x i1>, ptr %current.mask, align 1
  %1017 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1016)
  %1018 = bitcast <8 x i1> %1016 to i8
  %1019 = call i8 @llvm.cttz.i8(i8 %1018, i1 false)
  %1020 = zext i8 %1019 to i32
  %1021 = select i1 %1017, i32 %1020, i32 0
  %.state1385 = load <8 x i64>, ptr %.slot241, align 64
  %1022 = icmp slt <8 x i64> %.state1385, splat (i64 160)
  %1023 = and <8 x i1> %1016, %1022
  %1024 = xor <8 x i1> %1022, splat (i1 true)
  %1025 = and <8 x i1> %1016, %1024
  %1026 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1023)
  %1027 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1025)
  %1028 = and i1 %1026, %1027
  br i1 %1028, label %varying.divergent1386, label %varying.coherent1387

schedule.63:                                      ; preds = %varying.coherent.true1392, %scheduler.dispatch.route
  %1029 = load <8 x i1>, ptr %current.mask, align 1
  %1030 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1029)
  %1031 = bitcast <8 x i1> %1029 to i8
  %1032 = call i8 @llvm.cttz.i8(i8 %1031, i1 false)
  %1033 = zext i8 %1032 to i32
  %1034 = select i1 %1030, i32 %1033, i32 0
  %.state1394 = load <8 x i64>, ptr %.slot241, align 64
  %1035 = select <8 x i1> %1029, <8 x i64> %.state1394, <8 x i64> zeroinitializer
  %1036 = select <8 x i1> %1029, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %1037 = srem <8 x i64> %1035, %1036
  %.state1395 = load <8 x i64>, ptr %.slot241, align 64
  %1038 = select <8 x i1> %1029, <8 x i64> %.state1395, <8 x i64> zeroinitializer
  %1039 = select <8 x i1> %1029, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %1040 = sdiv <8 x i64> %1038, %1039
  %.spill.load1396 = load <8 x i64>, ptr %.spill, align 64
  %1041 = add <8 x i64> %.spill.load1396, zeroinitializer
  %1042 = add <8 x i64> zeroinitializer, %1041
  %.spill.load1397 = load volatile <8 x i64>, ptr %.spill49, align 64
  %1043 = add <8 x i64> %.spill.load1397, zeroinitializer
  %1044 = mul <8 x i64> %1042, splat (i64 6)
  %1045 = add <8 x i64> %1044, %1043
  %.spill.load1398 = load <8 x i64>, ptr %.spill50, align 64
  %1046 = add <8 x i64> %.spill.load1398, %1040
  %1047 = mul <8 x i64> %1045, splat (i64 17)
  %1048 = add <8 x i64> %1047, %1046
  %1049 = icmp sge <8 x i64> %1046, zeroinitializer
  %1050 = and <8 x i1> splat (i1 true), %1049
  %1051 = icmp slt <8 x i64> %1046, splat (i64 17)
  %1052 = and <8 x i1> %1050, %1051
  %1053 = add <8 x i64> zeroinitializer, %1037
  %1054 = mul <8 x i64> %1048, splat (i64 40)
  %1055 = add <8 x i64> %1054, %1053
  %1056 = load volatile <8 x i64>, ptr %.spill242, align 64
  %1057 = select <8 x i1> %1029, <8 x i64> %1055, <8 x i64> %1056
  store volatile <8 x i64> %1057, ptr %.spill242, align 64
  %1058 = and <8 x i1> %1029, %1052
  %1059 = xor <8 x i1> %1052, splat (i1 true)
  %1060 = and <8 x i1> %1029, %1059
  %1061 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1058)
  %1062 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1060)
  %1063 = and i1 %1061, %1062
  br i1 %1063, label %varying.divergent1399, label %varying.coherent1400

schedule.64:                                      ; preds = %varying.coherent.true1405, %scheduler.dispatch.route
  %1064 = load <8 x i1>, ptr %current.mask, align 1
  %1065 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1064)
  %1066 = bitcast <8 x i1> %1064 to i8
  %1067 = call i8 @llvm.cttz.i8(i8 %1066, i1 false)
  %1068 = zext i8 %1067 to i32
  %1069 = select i1 %1065, i32 %1068, i32 0
  %.spill.load1407 = load volatile <8 x i64>, ptr %.spill242, align 64
  %1070 = extractvalue { ptr, i64 } %44, 0
  %1071 = mul <8 x i64> %.spill.load1407, splat (i64 4)
  %1072 = getelementptr i8, ptr %1070, <8 x i64> %1071
  %1073 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1072, <8 x i1> %1064, <8 x float> zeroinitializer)
  %1074 = load <8 x float>, ptr %.slot243, align 32
  %1075 = select <8 x i1> %1064, <8 x float> %1073, <8 x float> %1074
  store <8 x float> %1075, ptr %.slot243, align 32
  store <8 x i1> %1064, ptr %current.mask, align 1
  %1076 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1064)
  br i1 %1076, label %schedule.65, label %scheduler.loop

schedule.65:                                      ; preds = %schedule.64, %varying.coherent.false1406, %scheduler.dispatch.route
  %1077 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1410 = load i32, ptr %current.token, align 4
  %convergence.token.present1411 = icmp ne i32 %convergence.current.token1410, 0
  br i1 %convergence.token.present1411, label %convergence.cascade1408, label %convergence.cascade.exit1409

varying.divergent:                                ; preds = %schedule.0
  %1078 = load i32, ptr %current.token, align 4
  %1079 = icmp ne i32 %1078, 0
  %1080 = sub i32 %1078, 1
  %1081 = select i1 %1079, i32 %1080, i32 0
  %1082 = load i8, ptr %frame.active, align 1
  %1083 = trunc i32 %1081 to i8
  %1084 = shl i8 1, %1083
  %1085 = and i8 %1082, %1084
  %1086 = icmp ne i8 %1085, 0
  %1087 = load <8 x i32>, ptr %frame.static.id, align 32
  %1088 = extractelement <8 x i32> %1087, i32 %1081
  %1089 = icmp eq i32 %1088, 0
  %1090 = and i1 %1086, %1089
  %1091 = and i1 %1079, %1090
  %1092 = xor i1 %1091, true
  %1093 = and i1 true, %1092
  %1094 = xor i8 %1082, -1
  %1095 = icmp ne i8 %1094, 0
  %1096 = xor i1 %1095, true
  %1097 = and i1 %1093, %1096
  br i1 %1097, label %convergence.overflow.trap, label %convergence.overflow.resume

varying.coherent:                                 ; preds = %schedule.0
  br i1 %171, label %varying.coherent.true, label %varying.coherent.false

convergence.overflow.trap:                        ; preds = %varying.divergent
  call void @llvm.trap()
  unreachable

convergence.overflow.resume:                      ; preds = %varying.divergent
  %1098 = call i8 @llvm.cttz.i8(i8 %1094, i1 false)
  %1099 = zext i8 %1098 to i32
  %1100 = select i1 %1095, i32 %1099, i32 0
  %1101 = trunc i32 %1100 to i8
  %1102 = shl i8 1, %1101
  %1103 = or i8 %1082, %1102
  %1104 = select i1 %1093, i8 %1103, i8 %1082
  store i8 %1104, ptr %frame.active, align 1
  %1105 = load <8 x i32>, ptr %frame.static.id, align 32
  %1106 = extractelement <8 x i32> %1105, i32 %1100
  %1107 = select i1 %1093, i32 0, i32 %1106
  %1108 = load <8 x i32>, ptr %frame.static.id, align 32
  %1109 = insertelement <8 x i32> %1108, i32 %1107, i32 %1100
  store <8 x i32> %1109, ptr %frame.static.id, align 32
  %1110 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1111 = extractelement <8 x i32> %1110, i32 %1100
  %1112 = select i1 %1093, i32 %1078, i32 %1111
  %1113 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1114 = insertelement <8 x i32> %1113, i32 %1112, i32 %1100
  store <8 x i32> %1114, ptr %frame.parent.token, align 32
  %1115 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1100
  %1116 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1100
  %1117 = load <8 x i1>, ptr %1115, align 1
  %1118 = load <8 x i1>, ptr %1116, align 1
  %1119 = select i1 %1093, <8 x i1> %120, <8 x i1> %1117
  store <8 x i1> %1119, ptr %1115, align 1
  %1120 = select i1 %1093, <8 x i1> zeroinitializer, <8 x i1> %1118
  store <8 x i1> %1120, ptr %1116, align 1
  %1121 = add i32 %1100, 1
  %1122 = select i1 %1091, i32 %1078, i32 %1121
  %1123 = select i1 true, i32 %1122, i32 %1078
  store i32 %1123, ptr %current.token, align 4
  %1124 = load i32, ptr %current.token, align 4
  %1125 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %168)
  %1126 = load i32, ptr %ready.count, align 4
  %1127 = icmp uge i32 %1126, 8
  %1128 = and i1 %1125, %1127
  br i1 %1128, label %ready.overflow.trap254, label %ready.overflow.resume255

ready.overflow.trap254:                           ; preds = %convergence.overflow.resume
  call void @llvm.trap()
  unreachable

ready.overflow.resume255:                         ; preds = %convergence.overflow.resume
  %1129 = select i1 %1125, i32 %1126, i32 0
  %1130 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1129
  %1131 = load <8 x i1>, ptr %1130, align 1
  %1132 = select i1 %1125, <8 x i1> %168, <8 x i1> %1131
  store <8 x i1> %1132, ptr %1130, align 1
  %1133 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1129
  %1134 = load i32, ptr %1133, align 4
  %1135 = select i1 %1125, i32 1, i32 %1134
  store i32 %1135, ptr %1133, align 4
  %1136 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1129
  %1137 = load i32, ptr %1136, align 4
  %1138 = select i1 %1125, i32 %1124, i32 %1137
  store i32 %1138, ptr %1136, align 4
  %1139 = add i32 %1126, 1
  %1140 = select i1 %1125, i32 %1139, i32 %1126
  store i32 %1140, ptr %ready.count, align 4
  %1141 = load <8 x i1>, ptr %runnable.mask, align 1
  %1142 = or <8 x i1> %1141, %168
  store <8 x i1> %1142, ptr %runnable.mask, align 1
  store <8 x i1> %170, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true:                            ; preds = %varying.coherent
  store <8 x i1> %120, ptr %current.mask, align 1
  %1143 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %120)
  br i1 %1143, label %schedule.1, label %scheduler.loop

varying.coherent.false:                           ; preds = %varying.coherent
  store <8 x i1> %120, ptr %current.mask, align 1
  %1144 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %120)
  br i1 %1144, label %schedule.61, label %scheduler.loop

copy.active:                                      ; preds = %schedule.1
  %1145 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %1146 = extractelement <8 x ptr> %1145, i64 0
  %1147 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %1148 = extractelement <8 x i64> %1147, i64 0
  %1149 = getelementptr i8, ptr %1146, i64 %1148
  %1150 = extractelement <8 x i64> %186, i64 0
  call void @llm_attention.contiguous_copy(ptr %187, i64 %1150, ptr %1149)
  br label %copy.continue

copy.continue:                                    ; preds = %copy.active, %schedule.1
  %1151 = extractelement <8 x i1> %174, i64 1
  br i1 %1151, label %copy.active258, label %copy.continue259

copy.active258:                                   ; preds = %copy.continue
  %1152 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %1153 = extractelement <8 x ptr> %1152, i64 1
  %1154 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %1155 = extractelement <8 x i64> %1154, i64 1
  %1156 = getelementptr i8, ptr %1153, i64 %1155
  %1157 = extractelement <8 x i64> %186, i64 1
  call void @llm_attention.contiguous_copy(ptr %187, i64 %1157, ptr %1156)
  br label %copy.continue259

copy.continue259:                                 ; preds = %copy.active258, %copy.continue
  %1158 = extractelement <8 x i1> %174, i64 2
  br i1 %1158, label %copy.active260, label %copy.continue261

copy.active260:                                   ; preds = %copy.continue259
  %1159 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %1160 = extractelement <8 x ptr> %1159, i64 2
  %1161 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %1162 = extractelement <8 x i64> %1161, i64 2
  %1163 = getelementptr i8, ptr %1160, i64 %1162
  %1164 = extractelement <8 x i64> %186, i64 2
  call void @llm_attention.contiguous_copy(ptr %187, i64 %1164, ptr %1163)
  br label %copy.continue261

copy.continue261:                                 ; preds = %copy.active260, %copy.continue259
  %1165 = extractelement <8 x i1> %174, i64 3
  br i1 %1165, label %copy.active262, label %copy.continue263

copy.active262:                                   ; preds = %copy.continue261
  %1166 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %1167 = extractelement <8 x ptr> %1166, i64 3
  %1168 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %1169 = extractelement <8 x i64> %1168, i64 3
  %1170 = getelementptr i8, ptr %1167, i64 %1169
  %1171 = extractelement <8 x i64> %186, i64 3
  call void @llm_attention.contiguous_copy(ptr %187, i64 %1171, ptr %1170)
  br label %copy.continue263

copy.continue263:                                 ; preds = %copy.active262, %copy.continue261
  %1172 = extractelement <8 x i1> %174, i64 4
  br i1 %1172, label %copy.active264, label %copy.continue265

copy.active264:                                   ; preds = %copy.continue263
  %1173 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %1174 = extractelement <8 x ptr> %1173, i64 4
  %1175 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %1176 = extractelement <8 x i64> %1175, i64 4
  %1177 = getelementptr i8, ptr %1174, i64 %1176
  %1178 = extractelement <8 x i64> %186, i64 4
  call void @llm_attention.contiguous_copy(ptr %187, i64 %1178, ptr %1177)
  br label %copy.continue265

copy.continue265:                                 ; preds = %copy.active264, %copy.continue263
  %1179 = extractelement <8 x i1> %174, i64 5
  br i1 %1179, label %copy.active266, label %copy.continue267

copy.active266:                                   ; preds = %copy.continue265
  %1180 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %1181 = extractelement <8 x ptr> %1180, i64 5
  %1182 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %1183 = extractelement <8 x i64> %1182, i64 5
  %1184 = getelementptr i8, ptr %1181, i64 %1183
  %1185 = extractelement <8 x i64> %186, i64 5
  call void @llm_attention.contiguous_copy(ptr %187, i64 %1185, ptr %1184)
  br label %copy.continue267

copy.continue267:                                 ; preds = %copy.active266, %copy.continue265
  %1186 = extractelement <8 x i1> %174, i64 6
  br i1 %1186, label %copy.active268, label %copy.continue269

copy.active268:                                   ; preds = %copy.continue267
  %1187 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %1188 = extractelement <8 x ptr> %1187, i64 6
  %1189 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %1190 = extractelement <8 x i64> %1189, i64 6
  %1191 = getelementptr i8, ptr %1188, i64 %1190
  %1192 = extractelement <8 x i64> %186, i64 6
  call void @llm_attention.contiguous_copy(ptr %187, i64 %1192, ptr %1191)
  br label %copy.continue269

copy.continue269:                                 ; preds = %copy.active268, %copy.continue267
  %1193 = extractelement <8 x i1> %174, i64 7
  br i1 %1193, label %copy.active270, label %copy.continue271

copy.active270:                                   ; preds = %copy.continue269
  %1194 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %1195 = extractelement <8 x ptr> %1194, i64 7
  %1196 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %1197 = extractelement <8 x i64> %1196, i64 7
  %1198 = getelementptr i8, ptr %1195, i64 %1197
  %1199 = extractelement <8 x i64> %186, i64 7
  call void @llm_attention.contiguous_copy(ptr %187, i64 %1199, ptr %1198)
  br label %copy.continue271

copy.continue271:                                 ; preds = %copy.active270, %copy.continue269
  store <8 x i1> %174, ptr %current.mask, align 1
  %1200 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %174)
  br i1 %1200, label %schedule.2, label %scheduler.loop

convergence.cascade:                              ; preds = %convergence.cascade, %schedule.2
  %convergence.cascade.flow = phi <8 x i1> [ %189, %schedule.2 ], [ %1243, %convergence.cascade ]
  %convergence.cascade.depth = phi i32 [ 0, %schedule.2 ], [ %1244, %convergence.cascade ]
  %1201 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow)
  %1202 = load i32, ptr %current.token, align 4
  %1203 = icmp ne i32 %1202, 0
  %1204 = and i1 %1201, %1203
  %1205 = sub i32 %1202, 1
  %1206 = select i1 %1204, i32 %1205, i32 0
  %1207 = load i8, ptr %frame.active, align 1
  %1208 = trunc i32 %1206 to i8
  %1209 = shl i8 1, %1208
  %1210 = and i8 %1207, %1209
  %1211 = icmp ne i8 %1210, 0
  %1212 = load <8 x i32>, ptr %frame.static.id, align 32
  %1213 = extractelement <8 x i32> %1212, i32 %1206
  %convergence.target.pointer = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %1213
  %convergence.dynamic.target = load i32, ptr %convergence.target.pointer, align 4
  %1214 = icmp eq i32 %convergence.dynamic.target, 2
  %1215 = and i1 %1211, %1214
  %1216 = and i1 %1204, %1215
  %1217 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1206
  %1218 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1206
  %1219 = load <8 x i1>, ptr %1217, align 1
  %1220 = load <8 x i1>, ptr %1218, align 1
  %1221 = or <8 x i1> %1220, %convergence.cascade.flow
  %1222 = load <8 x i1>, ptr %live.mask, align 1
  %1223 = and <8 x i1> %1219, %1222
  %1224 = icmp eq <8 x i1> %1221, %1223
  %1225 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1224)
  %1226 = and i1 %1216, %1225
  %1227 = select i1 %1226, <8 x i1> zeroinitializer, <8 x i1> %1221
  %1228 = select i1 %1216, <8 x i1> %1227, <8 x i1> %1220
  store <8 x i1> %1228, ptr %1218, align 1
  %1229 = select i1 %1226, <8 x i1> zeroinitializer, <8 x i1> %1219
  store <8 x i1> %1229, ptr %1217, align 1
  %1230 = trunc i32 %1206 to i8
  %1231 = shl i8 1, %1230
  %1232 = xor i8 %1231, -1
  %1233 = and i8 %1207, %1232
  %1234 = select i1 %1226, i8 %1233, i8 %1207
  store i8 %1234, ptr %frame.active, align 1
  %.splatinsert272 = insertelement <8 x i1> poison, i1 %1216, i64 0
  %.splat273 = shufflevector <8 x i1> %.splatinsert272, <8 x i1> poison, <8 x i32> zeroinitializer
  %1235 = and <8 x i1> %convergence.cascade.flow, %.splat273
  %1236 = load <8 x i1>, ptr %runnable.mask, align 1
  %1237 = xor <8 x i1> %1235, splat (i1 true)
  %1238 = and <8 x i1> %1236, %1237
  store <8 x i1> %1238, ptr %runnable.mask, align 1
  %.splatinsert274 = insertelement <8 x i1> poison, i1 %1226, i64 0
  %.splat275 = shufflevector <8 x i1> %.splatinsert274, <8 x i1> poison, <8 x i32> zeroinitializer
  %1239 = select <8 x i1> %.splat275, <8 x i1> %1221, <8 x i1> zeroinitializer
  %1240 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1241 = extractelement <8 x i32> %1240, i32 %1206
  %1242 = select i1 %1226, i32 %1241, i32 %1202
  store i32 %1242, ptr %current.token, align 4
  %.splatinsert276 = insertelement <8 x i1> poison, i1 %1216, i64 0
  %.splat277 = shufflevector <8 x i1> %.splatinsert276, <8 x i1> poison, <8 x i32> zeroinitializer
  %1243 = select <8 x i1> %.splat277, <8 x i1> %1239, <8 x i1> %convergence.cascade.flow
  %1244 = add i32 %convergence.cascade.depth, 1
  %1245 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1243)
  %1246 = icmp ult i32 %1244, 8
  %1247 = and i1 %1245, %1246
  %1248 = and i1 %1216, %1247
  %convergence.parent.token = load i32, ptr %current.token, align 4
  %convergence.parent.present = icmp ne i32 %convergence.parent.token, 0
  %1249 = and i1 %1248, %convergence.parent.present
  br i1 %1249, label %convergence.cascade, label %convergence.cascade.exit

convergence.cascade.exit:                         ; preds = %convergence.cascade, %schedule.2
  %convergence.cascade.result = phi <8 x i1> [ %189, %schedule.2 ], [ %1243, %convergence.cascade ]
  %1250 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %1250, label %convergence.target.2.ready, label %scheduler.loop

convergence.target.2.ready:                       ; preds = %convergence.cascade.exit
  %1251 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1252 = bitcast <8 x i1> %convergence.cascade.result to i8
  %1253 = call i8 @llvm.cttz.i8(i8 %1252, i1 false)
  %1254 = zext i8 %1253 to i32
  %1255 = select i1 %1251, i32 %1254, i32 0
  %1256 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %1257 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1258 = extractvalue { <8 x ptr>, <8 x i64> } %1256, 0
  %1259 = select <8 x i1> %convergence.cascade.result, <8 x ptr> %1257, <8 x ptr> %1258
  %1260 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1261 = extractvalue { <8 x ptr>, <8 x i64> } %1256, 1
  %1262 = select <8 x i1> %convergence.cascade.result, <8 x i64> %1260, <8 x i64> %1261
  %1263 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1259, 0
  %1264 = insertvalue { <8 x ptr>, <8 x i64> } %1263, <8 x i64> %1262, 1
  store { <8 x ptr>, <8 x i64> } %1264, ptr %tile_snapshot.spill52, align 64
  %1265 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill53, align 64
  %1266 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1267 = extractvalue { <8 x ptr>, <8 x i64> } %1265, 0
  %1268 = select <8 x i1> %convergence.cascade.result, <8 x ptr> %1266, <8 x ptr> %1267
  %1269 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %1270 = extractvalue { <8 x ptr>, <8 x i64> } %1265, 1
  %1271 = select <8 x i1> %convergence.cascade.result, <8 x i64> %1269, <8 x i64> %1270
  %1272 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1268, 0
  %1273 = insertvalue { <8 x ptr>, <8 x i64> } %1272, <8 x i64> %1271, 1
  store volatile { <8 x ptr>, <8 x i64> } %1273, ptr %tile_snapshot.spill53, align 64
  %1274 = load <8 x i64>, ptr %.slot, align 64
  %1275 = select <8 x i1> %convergence.cascade.result, <8 x i64> zeroinitializer, <8 x i64> %1274
  store <8 x i64> %1275, ptr %.slot, align 64
  store <8 x i1> %convergence.cascade.result, ptr %current.mask, align 1
  %1276 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %1276, label %schedule.3, label %scheduler.loop

varying.divergent278:                             ; preds = %schedule.3
  %1277 = load i32, ptr %current.token, align 4
  %1278 = icmp ne i32 %1277, 0
  %1279 = sub i32 %1277, 1
  %1280 = select i1 %1278, i32 %1279, i32 0
  %1281 = load i8, ptr %frame.active, align 1
  %1282 = trunc i32 %1280 to i8
  %1283 = shl i8 1, %1282
  %1284 = and i8 %1281, %1283
  %1285 = icmp ne i8 %1284, 0
  %1286 = load <8 x i32>, ptr %frame.static.id, align 32
  %1287 = extractelement <8 x i32> %1286, i32 %1280
  %1288 = icmp eq i32 %1287, 1
  %1289 = and i1 %1285, %1288
  %1290 = and i1 %1278, %1289
  %1291 = xor i1 %1290, true
  %1292 = and i1 true, %1291
  %1293 = xor i8 %1281, -1
  %1294 = icmp ne i8 %1293, 0
  %1295 = xor i1 %1294, true
  %1296 = and i1 %1292, %1295
  br i1 %1296, label %convergence.overflow.trap280, label %convergence.overflow.resume281

varying.coherent279:                              ; preds = %schedule.3
  br i1 %200, label %varying.coherent.true284, label %varying.coherent.false285

convergence.overflow.trap280:                     ; preds = %varying.divergent278
  call void @llvm.trap()
  unreachable

convergence.overflow.resume281:                   ; preds = %varying.divergent278
  %1297 = call i8 @llvm.cttz.i8(i8 %1293, i1 false)
  %1298 = zext i8 %1297 to i32
  %1299 = select i1 %1294, i32 %1298, i32 0
  %1300 = trunc i32 %1299 to i8
  %1301 = shl i8 1, %1300
  %1302 = or i8 %1281, %1301
  %1303 = select i1 %1292, i8 %1302, i8 %1281
  store i8 %1303, ptr %frame.active, align 1
  %1304 = load <8 x i32>, ptr %frame.static.id, align 32
  %1305 = extractelement <8 x i32> %1304, i32 %1299
  %1306 = select i1 %1292, i32 1, i32 %1305
  %1307 = load <8 x i32>, ptr %frame.static.id, align 32
  %1308 = insertelement <8 x i32> %1307, i32 %1306, i32 %1299
  store <8 x i32> %1308, ptr %frame.static.id, align 32
  %1309 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1310 = extractelement <8 x i32> %1309, i32 %1299
  %1311 = select i1 %1292, i32 %1277, i32 %1310
  %1312 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1313 = insertelement <8 x i32> %1312, i32 %1311, i32 %1299
  store <8 x i32> %1313, ptr %frame.parent.token, align 32
  %1314 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1299
  %1315 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1299
  %1316 = load <8 x i1>, ptr %1314, align 1
  %1317 = load <8 x i1>, ptr %1315, align 1
  %1318 = select i1 %1292, <8 x i1> %190, <8 x i1> %1316
  store <8 x i1> %1318, ptr %1314, align 1
  %1319 = select i1 %1292, <8 x i1> zeroinitializer, <8 x i1> %1317
  store <8 x i1> %1319, ptr %1315, align 1
  %1320 = add i32 %1299, 1
  %1321 = select i1 %1290, i32 %1277, i32 %1320
  %1322 = select i1 true, i32 %1321, i32 %1277
  store i32 %1322, ptr %current.token, align 4
  %1323 = load i32, ptr %current.token, align 4
  %1324 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %197)
  %1325 = load i32, ptr %ready.count, align 4
  %1326 = icmp uge i32 %1325, 8
  %1327 = and i1 %1324, %1326
  br i1 %1327, label %ready.overflow.trap282, label %ready.overflow.resume283

ready.overflow.trap282:                           ; preds = %convergence.overflow.resume281
  call void @llvm.trap()
  unreachable

ready.overflow.resume283:                         ; preds = %convergence.overflow.resume281
  %1328 = select i1 %1324, i32 %1325, i32 0
  %1329 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1328
  %1330 = load <8 x i1>, ptr %1329, align 1
  %1331 = select i1 %1324, <8 x i1> %197, <8 x i1> %1330
  store <8 x i1> %1331, ptr %1329, align 1
  %1332 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1328
  %1333 = load i32, ptr %1332, align 4
  %1334 = select i1 %1324, i32 4, i32 %1333
  store i32 %1334, ptr %1332, align 4
  %1335 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1328
  %1336 = load i32, ptr %1335, align 4
  %1337 = select i1 %1324, i32 %1323, i32 %1336
  store i32 %1337, ptr %1335, align 4
  %1338 = add i32 %1325, 1
  %1339 = select i1 %1324, i32 %1338, i32 %1325
  store i32 %1339, ptr %ready.count, align 4
  %1340 = load <8 x i1>, ptr %runnable.mask, align 1
  %1341 = or <8 x i1> %1340, %197
  store <8 x i1> %1341, ptr %runnable.mask, align 1
  store <8 x i1> %199, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true284:                         ; preds = %varying.coherent279
  store <8 x i1> %190, ptr %current.mask, align 1
  %1342 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %190)
  br i1 %1342, label %schedule.4, label %scheduler.loop

varying.coherent.false285:                        ; preds = %varying.coherent279
  store <8 x i1> %190, ptr %current.mask, align 1
  %1343 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %190)
  br i1 %1343, label %schedule.5, label %scheduler.loop

convergence.cascade289:                           ; preds = %convergence.cascade289, %schedule.5
  %convergence.cascade.flow293 = phi <8 x i1> [ %222, %schedule.5 ], [ %1386, %convergence.cascade289 ]
  %convergence.cascade.depth294 = phi i32 [ 0, %schedule.5 ], [ %1387, %convergence.cascade289 ]
  %1344 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow293)
  %1345 = load i32, ptr %current.token, align 4
  %1346 = icmp ne i32 %1345, 0
  %1347 = and i1 %1344, %1346
  %1348 = sub i32 %1345, 1
  %1349 = select i1 %1347, i32 %1348, i32 0
  %1350 = load i8, ptr %frame.active, align 1
  %1351 = trunc i32 %1349 to i8
  %1352 = shl i8 1, %1351
  %1353 = and i8 %1350, %1352
  %1354 = icmp ne i8 %1353, 0
  %1355 = load <8 x i32>, ptr %frame.static.id, align 32
  %1356 = extractelement <8 x i32> %1355, i32 %1349
  %convergence.target.pointer295 = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %1356
  %convergence.dynamic.target296 = load i32, ptr %convergence.target.pointer295, align 4
  %1357 = icmp eq i32 %convergence.dynamic.target296, 5
  %1358 = and i1 %1354, %1357
  %1359 = and i1 %1347, %1358
  %1360 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1349
  %1361 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1349
  %1362 = load <8 x i1>, ptr %1360, align 1
  %1363 = load <8 x i1>, ptr %1361, align 1
  %1364 = or <8 x i1> %1363, %convergence.cascade.flow293
  %1365 = load <8 x i1>, ptr %live.mask, align 1
  %1366 = and <8 x i1> %1362, %1365
  %1367 = icmp eq <8 x i1> %1364, %1366
  %1368 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1367)
  %1369 = and i1 %1359, %1368
  %1370 = select i1 %1369, <8 x i1> zeroinitializer, <8 x i1> %1364
  %1371 = select i1 %1359, <8 x i1> %1370, <8 x i1> %1363
  store <8 x i1> %1371, ptr %1361, align 1
  %1372 = select i1 %1369, <8 x i1> zeroinitializer, <8 x i1> %1362
  store <8 x i1> %1372, ptr %1360, align 1
  %1373 = trunc i32 %1349 to i8
  %1374 = shl i8 1, %1373
  %1375 = xor i8 %1374, -1
  %1376 = and i8 %1350, %1375
  %1377 = select i1 %1369, i8 %1376, i8 %1350
  store i8 %1377, ptr %frame.active, align 1
  %.splatinsert297 = insertelement <8 x i1> poison, i1 %1359, i64 0
  %.splat298 = shufflevector <8 x i1> %.splatinsert297, <8 x i1> poison, <8 x i32> zeroinitializer
  %1378 = and <8 x i1> %convergence.cascade.flow293, %.splat298
  %1379 = load <8 x i1>, ptr %runnable.mask, align 1
  %1380 = xor <8 x i1> %1378, splat (i1 true)
  %1381 = and <8 x i1> %1379, %1380
  store <8 x i1> %1381, ptr %runnable.mask, align 1
  %.splatinsert299 = insertelement <8 x i1> poison, i1 %1369, i64 0
  %.splat300 = shufflevector <8 x i1> %.splatinsert299, <8 x i1> poison, <8 x i32> zeroinitializer
  %1382 = select <8 x i1> %.splat300, <8 x i1> %1364, <8 x i1> zeroinitializer
  %1383 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1384 = extractelement <8 x i32> %1383, i32 %1349
  %1385 = select i1 %1369, i32 %1384, i32 %1345
  store i32 %1385, ptr %current.token, align 4
  %.splatinsert301 = insertelement <8 x i1> poison, i1 %1359, i64 0
  %.splat302 = shufflevector <8 x i1> %.splatinsert301, <8 x i1> poison, <8 x i32> zeroinitializer
  %1386 = select <8 x i1> %.splat302, <8 x i1> %1382, <8 x i1> %convergence.cascade.flow293
  %1387 = add i32 %convergence.cascade.depth294, 1
  %1388 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1386)
  %1389 = icmp ult i32 %1387, 8
  %1390 = and i1 %1388, %1389
  %1391 = and i1 %1359, %1390
  %convergence.parent.token303 = load i32, ptr %current.token, align 4
  %convergence.parent.present304 = icmp ne i32 %convergence.parent.token303, 0
  %1392 = and i1 %1391, %convergence.parent.present304
  br i1 %1392, label %convergence.cascade289, label %convergence.cascade.exit290

convergence.cascade.exit290:                      ; preds = %convergence.cascade289, %schedule.5
  %convergence.cascade.result305 = phi <8 x i1> [ %222, %schedule.5 ], [ %1386, %convergence.cascade289 ]
  %1393 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  br i1 %1393, label %convergence.target.5.ready, label %scheduler.loop

convergence.target.5.ready:                       ; preds = %convergence.cascade.exit290
  %1394 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %1395 = bitcast <8 x i1> %convergence.cascade.result305 to i8
  %1396 = call i8 @llvm.cttz.i8(i8 %1395, i1 false)
  %1397 = zext i8 %1396 to i32
  %1398 = select i1 %1394, i32 %1397, i32 0
  %1399 = load <8 x i64>, ptr %.slot54, align 64
  %1400 = select <8 x i1> %convergence.cascade.result305, <8 x i64> zeroinitializer, <8 x i64> %1399
  store <8 x i64> %1400, ptr %.slot54, align 64
  %1401 = load <8 x float>, ptr %.slot55, align 32
  %1402 = select <8 x i1> %convergence.cascade.result305, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %1401
  store <8 x float> %1402, ptr %.slot55, align 32
  %1403 = load <8 x float>, ptr %.slot56, align 32
  %1404 = select <8 x i1> %convergence.cascade.result305, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %1403
  store <8 x float> %1404, ptr %.slot56, align 32
  %1405 = load <8 x float>, ptr %.slot57, align 32
  %1406 = select <8 x i1> %convergence.cascade.result305, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %1405
  store <8 x float> %1406, ptr %.slot57, align 32
  %1407 = load <8 x float>, ptr %.slot58, align 32
  %1408 = select <8 x i1> %convergence.cascade.result305, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %1407
  store <8 x float> %1408, ptr %.slot58, align 32
  %1409 = load <8 x float>, ptr %.slot59, align 32
  %1410 = select <8 x i1> %convergence.cascade.result305, <8 x float> zeroinitializer, <8 x float> %1409
  store <8 x float> %1410, ptr %.slot59, align 32
  %1411 = load <8 x float>, ptr %.slot60, align 32
  %1412 = select <8 x i1> %convergence.cascade.result305, <8 x float> zeroinitializer, <8 x float> %1411
  store <8 x float> %1412, ptr %.slot60, align 32
  %1413 = load <8 x float>, ptr %.slot61, align 32
  %1414 = select <8 x i1> %convergence.cascade.result305, <8 x float> zeroinitializer, <8 x float> %1413
  store <8 x float> %1414, ptr %.slot61, align 32
  %1415 = load <8 x float>, ptr %.slot62, align 32
  %1416 = select <8 x i1> %convergence.cascade.result305, <8 x float> zeroinitializer, <8 x float> %1415
  store <8 x float> %1416, ptr %.slot62, align 32
  store <8 x i1> %convergence.cascade.result305, ptr %current.mask, align 1
  %1417 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  br i1 %1417, label %schedule.6, label %scheduler.loop

varying.divergent307:                             ; preds = %schedule.6
  %1418 = load i32, ptr %current.token, align 4
  %1419 = icmp ne i32 %1418, 0
  %1420 = sub i32 %1418, 1
  %1421 = select i1 %1419, i32 %1420, i32 0
  %1422 = load i8, ptr %frame.active, align 1
  %1423 = trunc i32 %1421 to i8
  %1424 = shl i8 1, %1423
  %1425 = and i8 %1422, %1424
  %1426 = icmp ne i8 %1425, 0
  %1427 = load <8 x i32>, ptr %frame.static.id, align 32
  %1428 = extractelement <8 x i32> %1427, i32 %1421
  %1429 = icmp eq i32 %1428, 2
  %1430 = and i1 %1426, %1429
  %1431 = and i1 %1419, %1430
  %1432 = xor i1 %1431, true
  %1433 = and i1 true, %1432
  %1434 = xor i8 %1422, -1
  %1435 = icmp ne i8 %1434, 0
  %1436 = xor i1 %1435, true
  %1437 = and i1 %1433, %1436
  br i1 %1437, label %convergence.overflow.trap309, label %convergence.overflow.resume310

varying.coherent308:                              ; preds = %schedule.6
  br i1 %233, label %varying.coherent.true313, label %varying.coherent.false314

convergence.overflow.trap309:                     ; preds = %varying.divergent307
  call void @llvm.trap()
  unreachable

convergence.overflow.resume310:                   ; preds = %varying.divergent307
  %1438 = call i8 @llvm.cttz.i8(i8 %1434, i1 false)
  %1439 = zext i8 %1438 to i32
  %1440 = select i1 %1435, i32 %1439, i32 0
  %1441 = trunc i32 %1440 to i8
  %1442 = shl i8 1, %1441
  %1443 = or i8 %1422, %1442
  %1444 = select i1 %1433, i8 %1443, i8 %1422
  store i8 %1444, ptr %frame.active, align 1
  %1445 = load <8 x i32>, ptr %frame.static.id, align 32
  %1446 = extractelement <8 x i32> %1445, i32 %1440
  %1447 = select i1 %1433, i32 2, i32 %1446
  %1448 = load <8 x i32>, ptr %frame.static.id, align 32
  %1449 = insertelement <8 x i32> %1448, i32 %1447, i32 %1440
  store <8 x i32> %1449, ptr %frame.static.id, align 32
  %1450 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1451 = extractelement <8 x i32> %1450, i32 %1440
  %1452 = select i1 %1433, i32 %1418, i32 %1451
  %1453 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1454 = insertelement <8 x i32> %1453, i32 %1452, i32 %1440
  store <8 x i32> %1454, ptr %frame.parent.token, align 32
  %1455 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1440
  %1456 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1440
  %1457 = load <8 x i1>, ptr %1455, align 1
  %1458 = load <8 x i1>, ptr %1456, align 1
  %1459 = select i1 %1433, <8 x i1> %223, <8 x i1> %1457
  store <8 x i1> %1459, ptr %1455, align 1
  %1460 = select i1 %1433, <8 x i1> zeroinitializer, <8 x i1> %1458
  store <8 x i1> %1460, ptr %1456, align 1
  %1461 = add i32 %1440, 1
  %1462 = select i1 %1431, i32 %1418, i32 %1461
  %1463 = select i1 true, i32 %1462, i32 %1418
  store i32 %1463, ptr %current.token, align 4
  %1464 = load i32, ptr %current.token, align 4
  %1465 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %230)
  %1466 = load i32, ptr %ready.count, align 4
  %1467 = icmp uge i32 %1466, 8
  %1468 = and i1 %1465, %1467
  br i1 %1468, label %ready.overflow.trap311, label %ready.overflow.resume312

ready.overflow.trap311:                           ; preds = %convergence.overflow.resume310
  call void @llvm.trap()
  unreachable

ready.overflow.resume312:                         ; preds = %convergence.overflow.resume310
  %1469 = select i1 %1465, i32 %1466, i32 0
  %1470 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1469
  %1471 = load <8 x i1>, ptr %1470, align 1
  %1472 = select i1 %1465, <8 x i1> %230, <8 x i1> %1471
  store <8 x i1> %1472, ptr %1470, align 1
  %1473 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1469
  %1474 = load i32, ptr %1473, align 4
  %1475 = select i1 %1465, i32 7, i32 %1474
  store i32 %1475, ptr %1473, align 4
  %1476 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1469
  %1477 = load i32, ptr %1476, align 4
  %1478 = select i1 %1465, i32 %1464, i32 %1477
  store i32 %1478, ptr %1476, align 4
  %1479 = add i32 %1466, 1
  %1480 = select i1 %1465, i32 %1479, i32 %1466
  store i32 %1480, ptr %ready.count, align 4
  %1481 = load <8 x i1>, ptr %runnable.mask, align 1
  %1482 = or <8 x i1> %1481, %230
  store <8 x i1> %1482, ptr %runnable.mask, align 1
  store <8 x i1> %232, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true313:                         ; preds = %varying.coherent308
  store <8 x i1> %223, ptr %current.mask, align 1
  %1483 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %223)
  br i1 %1483, label %schedule.7, label %scheduler.loop

varying.coherent.false314:                        ; preds = %varying.coherent308
  store <8 x i1> %223, ptr %current.mask, align 1
  %1484 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %223)
  br i1 %1484, label %schedule.55, label %scheduler.loop

varying.divergent316:                             ; preds = %schedule.7
  %1485 = load i32, ptr %current.token, align 4
  %1486 = icmp ne i32 %1485, 0
  %1487 = sub i32 %1485, 1
  %1488 = select i1 %1486, i32 %1487, i32 0
  %1489 = load i8, ptr %frame.active, align 1
  %1490 = trunc i32 %1488 to i8
  %1491 = shl i8 1, %1490
  %1492 = and i8 %1489, %1491
  %1493 = icmp ne i8 %1492, 0
  %1494 = load <8 x i32>, ptr %frame.static.id, align 32
  %1495 = extractelement <8 x i32> %1494, i32 %1488
  %1496 = icmp eq i32 %1495, 3
  %1497 = and i1 %1493, %1496
  %1498 = and i1 %1486, %1497
  %1499 = xor i1 %1498, true
  %1500 = and i1 true, %1499
  %1501 = xor i8 %1489, -1
  %1502 = icmp ne i8 %1501, 0
  %1503 = xor i1 %1502, true
  %1504 = and i1 %1500, %1503
  br i1 %1504, label %convergence.overflow.trap318, label %convergence.overflow.resume319

varying.coherent317:                              ; preds = %schedule.7
  br i1 %266, label %varying.coherent.true322, label %varying.coherent.false323

convergence.overflow.trap318:                     ; preds = %varying.divergent316
  call void @llvm.trap()
  unreachable

convergence.overflow.resume319:                   ; preds = %varying.divergent316
  %1505 = call i8 @llvm.cttz.i8(i8 %1501, i1 false)
  %1506 = zext i8 %1505 to i32
  %1507 = select i1 %1502, i32 %1506, i32 0
  %1508 = trunc i32 %1507 to i8
  %1509 = shl i8 1, %1508
  %1510 = or i8 %1489, %1509
  %1511 = select i1 %1500, i8 %1510, i8 %1489
  store i8 %1511, ptr %frame.active, align 1
  %1512 = load <8 x i32>, ptr %frame.static.id, align 32
  %1513 = extractelement <8 x i32> %1512, i32 %1507
  %1514 = select i1 %1500, i32 3, i32 %1513
  %1515 = load <8 x i32>, ptr %frame.static.id, align 32
  %1516 = insertelement <8 x i32> %1515, i32 %1514, i32 %1507
  store <8 x i32> %1516, ptr %frame.static.id, align 32
  %1517 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1518 = extractelement <8 x i32> %1517, i32 %1507
  %1519 = select i1 %1500, i32 %1485, i32 %1518
  %1520 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1521 = insertelement <8 x i32> %1520, i32 %1519, i32 %1507
  store <8 x i32> %1521, ptr %frame.parent.token, align 32
  %1522 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1507
  %1523 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1507
  %1524 = load <8 x i1>, ptr %1522, align 1
  %1525 = load <8 x i1>, ptr %1523, align 1
  %1526 = select i1 %1500, <8 x i1> %236, <8 x i1> %1524
  store <8 x i1> %1526, ptr %1522, align 1
  %1527 = select i1 %1500, <8 x i1> zeroinitializer, <8 x i1> %1525
  store <8 x i1> %1527, ptr %1523, align 1
  %1528 = add i32 %1507, 1
  %1529 = select i1 %1498, i32 %1485, i32 %1528
  %1530 = select i1 true, i32 %1529, i32 %1485
  store i32 %1530, ptr %current.token, align 4
  %1531 = load i32, ptr %current.token, align 4
  %1532 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %263)
  %1533 = load i32, ptr %ready.count, align 4
  %1534 = icmp uge i32 %1533, 8
  %1535 = and i1 %1532, %1534
  br i1 %1535, label %ready.overflow.trap320, label %ready.overflow.resume321

ready.overflow.trap320:                           ; preds = %convergence.overflow.resume319
  call void @llvm.trap()
  unreachable

ready.overflow.resume321:                         ; preds = %convergence.overflow.resume319
  %1536 = select i1 %1532, i32 %1533, i32 0
  %1537 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1536
  %1538 = load <8 x i1>, ptr %1537, align 1
  %1539 = select i1 %1532, <8 x i1> %263, <8 x i1> %1538
  store <8 x i1> %1539, ptr %1537, align 1
  %1540 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1536
  %1541 = load i32, ptr %1540, align 4
  %1542 = select i1 %1532, i32 8, i32 %1541
  store i32 %1542, ptr %1540, align 4
  %1543 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1536
  %1544 = load i32, ptr %1543, align 4
  %1545 = select i1 %1532, i32 %1531, i32 %1544
  store i32 %1545, ptr %1543, align 4
  %1546 = add i32 %1533, 1
  %1547 = select i1 %1532, i32 %1546, i32 %1533
  store i32 %1547, ptr %ready.count, align 4
  %1548 = load <8 x i1>, ptr %runnable.mask, align 1
  %1549 = or <8 x i1> %1548, %263
  store <8 x i1> %1549, ptr %runnable.mask, align 1
  store <8 x i1> %265, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true322:                         ; preds = %varying.coherent317
  store <8 x i1> %236, ptr %current.mask, align 1
  %1550 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %236)
  br i1 %1550, label %schedule.8, label %scheduler.loop

varying.coherent.false323:                        ; preds = %varying.coherent317
  store <8 x i1> %236, ptr %current.mask, align 1
  %1551 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %236)
  br i1 %1551, label %schedule.50, label %scheduler.loop

copy.active328:                                   ; preds = %schedule.8
  %1552 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load327, 0
  %1553 = extractelement <8 x ptr> %1552, i64 0
  %1554 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load327, 1
  %1555 = extractelement <8 x i64> %1554, i64 0
  %1556 = getelementptr i8, ptr %1553, i64 %1555
  %1557 = extractelement <8 x i64> %281, i64 0
  call void @llm_attention.contiguous_copy.1(ptr %282, i64 %1557, ptr %1556)
  br label %copy.continue329

copy.continue329:                                 ; preds = %copy.active328, %schedule.8
  %1558 = extractelement <8 x i1> %269, i64 1
  br i1 %1558, label %copy.active330, label %copy.continue331

copy.active330:                                   ; preds = %copy.continue329
  %1559 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load327, 0
  %1560 = extractelement <8 x ptr> %1559, i64 1
  %1561 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load327, 1
  %1562 = extractelement <8 x i64> %1561, i64 1
  %1563 = getelementptr i8, ptr %1560, i64 %1562
  %1564 = extractelement <8 x i64> %281, i64 1
  call void @llm_attention.contiguous_copy.1(ptr %282, i64 %1564, ptr %1563)
  br label %copy.continue331

copy.continue331:                                 ; preds = %copy.active330, %copy.continue329
  %1565 = extractelement <8 x i1> %269, i64 2
  br i1 %1565, label %copy.active332, label %copy.continue333

copy.active332:                                   ; preds = %copy.continue331
  %1566 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load327, 0
  %1567 = extractelement <8 x ptr> %1566, i64 2
  %1568 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load327, 1
  %1569 = extractelement <8 x i64> %1568, i64 2
  %1570 = getelementptr i8, ptr %1567, i64 %1569
  %1571 = extractelement <8 x i64> %281, i64 2
  call void @llm_attention.contiguous_copy.1(ptr %282, i64 %1571, ptr %1570)
  br label %copy.continue333

copy.continue333:                                 ; preds = %copy.active332, %copy.continue331
  %1572 = extractelement <8 x i1> %269, i64 3
  br i1 %1572, label %copy.active334, label %copy.continue335

copy.active334:                                   ; preds = %copy.continue333
  %1573 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load327, 0
  %1574 = extractelement <8 x ptr> %1573, i64 3
  %1575 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load327, 1
  %1576 = extractelement <8 x i64> %1575, i64 3
  %1577 = getelementptr i8, ptr %1574, i64 %1576
  %1578 = extractelement <8 x i64> %281, i64 3
  call void @llm_attention.contiguous_copy.1(ptr %282, i64 %1578, ptr %1577)
  br label %copy.continue335

copy.continue335:                                 ; preds = %copy.active334, %copy.continue333
  %1579 = extractelement <8 x i1> %269, i64 4
  br i1 %1579, label %copy.active336, label %copy.continue337

copy.active336:                                   ; preds = %copy.continue335
  %1580 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load327, 0
  %1581 = extractelement <8 x ptr> %1580, i64 4
  %1582 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load327, 1
  %1583 = extractelement <8 x i64> %1582, i64 4
  %1584 = getelementptr i8, ptr %1581, i64 %1583
  %1585 = extractelement <8 x i64> %281, i64 4
  call void @llm_attention.contiguous_copy.1(ptr %282, i64 %1585, ptr %1584)
  br label %copy.continue337

copy.continue337:                                 ; preds = %copy.active336, %copy.continue335
  %1586 = extractelement <8 x i1> %269, i64 5
  br i1 %1586, label %copy.active338, label %copy.continue339

copy.active338:                                   ; preds = %copy.continue337
  %1587 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load327, 0
  %1588 = extractelement <8 x ptr> %1587, i64 5
  %1589 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load327, 1
  %1590 = extractelement <8 x i64> %1589, i64 5
  %1591 = getelementptr i8, ptr %1588, i64 %1590
  %1592 = extractelement <8 x i64> %281, i64 5
  call void @llm_attention.contiguous_copy.1(ptr %282, i64 %1592, ptr %1591)
  br label %copy.continue339

copy.continue339:                                 ; preds = %copy.active338, %copy.continue337
  %1593 = extractelement <8 x i1> %269, i64 6
  br i1 %1593, label %copy.active340, label %copy.continue341

copy.active340:                                   ; preds = %copy.continue339
  %1594 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load327, 0
  %1595 = extractelement <8 x ptr> %1594, i64 6
  %1596 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load327, 1
  %1597 = extractelement <8 x i64> %1596, i64 6
  %1598 = getelementptr i8, ptr %1595, i64 %1597
  %1599 = extractelement <8 x i64> %281, i64 6
  call void @llm_attention.contiguous_copy.1(ptr %282, i64 %1599, ptr %1598)
  br label %copy.continue341

copy.continue341:                                 ; preds = %copy.active340, %copy.continue339
  %1600 = extractelement <8 x i1> %269, i64 7
  br i1 %1600, label %copy.active342, label %copy.continue343

copy.active342:                                   ; preds = %copy.continue341
  %1601 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load327, 0
  %1602 = extractelement <8 x ptr> %1601, i64 7
  %1603 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load327, 1
  %1604 = extractelement <8 x i64> %1603, i64 7
  %1605 = getelementptr i8, ptr %1602, i64 %1604
  %1606 = extractelement <8 x i64> %281, i64 7
  call void @llm_attention.contiguous_copy.1(ptr %282, i64 %1606, ptr %1605)
  br label %copy.continue343

copy.continue343:                                 ; preds = %copy.active342, %copy.continue341
  store <8 x i1> %269, ptr %current.mask, align 1
  %1607 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %269)
  br i1 %1607, label %schedule.9, label %scheduler.loop

convergence.cascade344:                           ; preds = %convergence.cascade344, %schedule.9
  %convergence.cascade.flow348 = phi <8 x i1> [ %284, %schedule.9 ], [ %1650, %convergence.cascade344 ]
  %convergence.cascade.depth349 = phi i32 [ 0, %schedule.9 ], [ %1651, %convergence.cascade344 ]
  %1608 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow348)
  %1609 = load i32, ptr %current.token, align 4
  %1610 = icmp ne i32 %1609, 0
  %1611 = and i1 %1608, %1610
  %1612 = sub i32 %1609, 1
  %1613 = select i1 %1611, i32 %1612, i32 0
  %1614 = load i8, ptr %frame.active, align 1
  %1615 = trunc i32 %1613 to i8
  %1616 = shl i8 1, %1615
  %1617 = and i8 %1614, %1616
  %1618 = icmp ne i8 %1617, 0
  %1619 = load <8 x i32>, ptr %frame.static.id, align 32
  %1620 = extractelement <8 x i32> %1619, i32 %1613
  %convergence.target.pointer350 = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %1620
  %convergence.dynamic.target351 = load i32, ptr %convergence.target.pointer350, align 4
  %1621 = icmp eq i32 %convergence.dynamic.target351, 9
  %1622 = and i1 %1618, %1621
  %1623 = and i1 %1611, %1622
  %1624 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1613
  %1625 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1613
  %1626 = load <8 x i1>, ptr %1624, align 1
  %1627 = load <8 x i1>, ptr %1625, align 1
  %1628 = or <8 x i1> %1627, %convergence.cascade.flow348
  %1629 = load <8 x i1>, ptr %live.mask, align 1
  %1630 = and <8 x i1> %1626, %1629
  %1631 = icmp eq <8 x i1> %1628, %1630
  %1632 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1631)
  %1633 = and i1 %1623, %1632
  %1634 = select i1 %1633, <8 x i1> zeroinitializer, <8 x i1> %1628
  %1635 = select i1 %1623, <8 x i1> %1634, <8 x i1> %1627
  store <8 x i1> %1635, ptr %1625, align 1
  %1636 = select i1 %1633, <8 x i1> zeroinitializer, <8 x i1> %1626
  store <8 x i1> %1636, ptr %1624, align 1
  %1637 = trunc i32 %1613 to i8
  %1638 = shl i8 1, %1637
  %1639 = xor i8 %1638, -1
  %1640 = and i8 %1614, %1639
  %1641 = select i1 %1633, i8 %1640, i8 %1614
  store i8 %1641, ptr %frame.active, align 1
  %.splatinsert352 = insertelement <8 x i1> poison, i1 %1623, i64 0
  %.splat353 = shufflevector <8 x i1> %.splatinsert352, <8 x i1> poison, <8 x i32> zeroinitializer
  %1642 = and <8 x i1> %convergence.cascade.flow348, %.splat353
  %1643 = load <8 x i1>, ptr %runnable.mask, align 1
  %1644 = xor <8 x i1> %1642, splat (i1 true)
  %1645 = and <8 x i1> %1643, %1644
  store <8 x i1> %1645, ptr %runnable.mask, align 1
  %.splatinsert354 = insertelement <8 x i1> poison, i1 %1633, i64 0
  %.splat355 = shufflevector <8 x i1> %.splatinsert354, <8 x i1> poison, <8 x i32> zeroinitializer
  %1646 = select <8 x i1> %.splat355, <8 x i1> %1628, <8 x i1> zeroinitializer
  %1647 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1648 = extractelement <8 x i32> %1647, i32 %1613
  %1649 = select i1 %1633, i32 %1648, i32 %1609
  store i32 %1649, ptr %current.token, align 4
  %.splatinsert356 = insertelement <8 x i1> poison, i1 %1623, i64 0
  %.splat357 = shufflevector <8 x i1> %.splatinsert356, <8 x i1> poison, <8 x i32> zeroinitializer
  %1650 = select <8 x i1> %.splat357, <8 x i1> %1646, <8 x i1> %convergence.cascade.flow348
  %1651 = add i32 %convergence.cascade.depth349, 1
  %1652 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1650)
  %1653 = icmp ult i32 %1651, 8
  %1654 = and i1 %1652, %1653
  %1655 = and i1 %1623, %1654
  %convergence.parent.token358 = load i32, ptr %current.token, align 4
  %convergence.parent.present359 = icmp ne i32 %convergence.parent.token358, 0
  %1656 = and i1 %1655, %convergence.parent.present359
  br i1 %1656, label %convergence.cascade344, label %convergence.cascade.exit345

convergence.cascade.exit345:                      ; preds = %convergence.cascade344, %schedule.9
  %convergence.cascade.result360 = phi <8 x i1> [ %284, %schedule.9 ], [ %1650, %convergence.cascade344 ]
  %1657 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result360)
  br i1 %1657, label %convergence.target.9.ready, label %scheduler.loop

convergence.target.9.ready:                       ; preds = %convergence.cascade.exit345
  %1658 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result360)
  %1659 = bitcast <8 x i1> %convergence.cascade.result360 to i8
  %1660 = call i8 @llvm.cttz.i8(i8 %1659, i1 false)
  %1661 = zext i8 %1660 to i32
  %1662 = select i1 %1658, i32 %1661, i32 0
  %1663 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill66, align 64
  %1664 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1665 = extractvalue { <8 x ptr>, <8 x i64> } %1663, 0
  %1666 = select <8 x i1> %convergence.cascade.result360, <8 x ptr> %1664, <8 x ptr> %1665
  %1667 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %1668 = extractvalue { <8 x ptr>, <8 x i64> } %1663, 1
  %1669 = select <8 x i1> %convergence.cascade.result360, <8 x i64> %1667, <8 x i64> %1668
  %1670 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1666, 0
  %1671 = insertvalue { <8 x ptr>, <8 x i64> } %1670, <8 x i64> %1669, 1
  store volatile { <8 x ptr>, <8 x i64> } %1671, ptr %tile_snapshot.spill66, align 64
  %.spill.load361 = load volatile <8 x i1>, ptr %.spill65, align 1
  %1672 = and <8 x i1> %convergence.cascade.result360, %.spill.load361
  %1673 = xor <8 x i1> %.spill.load361, splat (i1 true)
  %1674 = and <8 x i1> %convergence.cascade.result360, %1673
  %1675 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1672)
  %1676 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1674)
  %1677 = and i1 %1675, %1676
  br i1 %1677, label %varying.divergent362, label %varying.coherent363

varying.divergent362:                             ; preds = %convergence.target.9.ready
  %1678 = load i32, ptr %current.token, align 4
  %1679 = icmp ne i32 %1678, 0
  %1680 = sub i32 %1678, 1
  %1681 = select i1 %1679, i32 %1680, i32 0
  %1682 = load i8, ptr %frame.active, align 1
  %1683 = trunc i32 %1681 to i8
  %1684 = shl i8 1, %1683
  %1685 = and i8 %1682, %1684
  %1686 = icmp ne i8 %1685, 0
  %1687 = load <8 x i32>, ptr %frame.static.id, align 32
  %1688 = extractelement <8 x i32> %1687, i32 %1681
  %1689 = icmp eq i32 %1688, 4
  %1690 = and i1 %1686, %1689
  %1691 = and i1 %1679, %1690
  %1692 = xor i1 %1691, true
  %1693 = and i1 true, %1692
  %1694 = xor i8 %1682, -1
  %1695 = icmp ne i8 %1694, 0
  %1696 = xor i1 %1695, true
  %1697 = and i1 %1693, %1696
  br i1 %1697, label %convergence.overflow.trap364, label %convergence.overflow.resume365

varying.coherent363:                              ; preds = %convergence.target.9.ready
  br i1 %1675, label %varying.coherent.true368, label %varying.coherent.false369

convergence.overflow.trap364:                     ; preds = %varying.divergent362
  call void @llvm.trap()
  unreachable

convergence.overflow.resume365:                   ; preds = %varying.divergent362
  %1698 = call i8 @llvm.cttz.i8(i8 %1694, i1 false)
  %1699 = zext i8 %1698 to i32
  %1700 = select i1 %1695, i32 %1699, i32 0
  %1701 = trunc i32 %1700 to i8
  %1702 = shl i8 1, %1701
  %1703 = or i8 %1682, %1702
  %1704 = select i1 %1693, i8 %1703, i8 %1682
  store i8 %1704, ptr %frame.active, align 1
  %1705 = load <8 x i32>, ptr %frame.static.id, align 32
  %1706 = extractelement <8 x i32> %1705, i32 %1700
  %1707 = select i1 %1693, i32 4, i32 %1706
  %1708 = load <8 x i32>, ptr %frame.static.id, align 32
  %1709 = insertelement <8 x i32> %1708, i32 %1707, i32 %1700
  store <8 x i32> %1709, ptr %frame.static.id, align 32
  %1710 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1711 = extractelement <8 x i32> %1710, i32 %1700
  %1712 = select i1 %1693, i32 %1678, i32 %1711
  %1713 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1714 = insertelement <8 x i32> %1713, i32 %1712, i32 %1700
  store <8 x i32> %1714, ptr %frame.parent.token, align 32
  %1715 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1700
  %1716 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1700
  %1717 = load <8 x i1>, ptr %1715, align 1
  %1718 = load <8 x i1>, ptr %1716, align 1
  %1719 = select i1 %1693, <8 x i1> %convergence.cascade.result360, <8 x i1> %1717
  store <8 x i1> %1719, ptr %1715, align 1
  %1720 = select i1 %1693, <8 x i1> zeroinitializer, <8 x i1> %1718
  store <8 x i1> %1720, ptr %1716, align 1
  %1721 = add i32 %1700, 1
  %1722 = select i1 %1691, i32 %1678, i32 %1721
  %1723 = select i1 true, i32 %1722, i32 %1678
  store i32 %1723, ptr %current.token, align 4
  %1724 = load i32, ptr %current.token, align 4
  %1725 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1672)
  %1726 = load i32, ptr %ready.count, align 4
  %1727 = icmp uge i32 %1726, 8
  %1728 = and i1 %1725, %1727
  br i1 %1728, label %ready.overflow.trap366, label %ready.overflow.resume367

ready.overflow.trap366:                           ; preds = %convergence.overflow.resume365
  call void @llvm.trap()
  unreachable

ready.overflow.resume367:                         ; preds = %convergence.overflow.resume365
  %1729 = select i1 %1725, i32 %1726, i32 0
  %1730 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1729
  %1731 = load <8 x i1>, ptr %1730, align 1
  %1732 = select i1 %1725, <8 x i1> %1672, <8 x i1> %1731
  store <8 x i1> %1732, ptr %1730, align 1
  %1733 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1729
  %1734 = load i32, ptr %1733, align 4
  %1735 = select i1 %1725, i32 10, i32 %1734
  store i32 %1735, ptr %1733, align 4
  %1736 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1729
  %1737 = load i32, ptr %1736, align 4
  %1738 = select i1 %1725, i32 %1724, i32 %1737
  store i32 %1738, ptr %1736, align 4
  %1739 = add i32 %1726, 1
  %1740 = select i1 %1725, i32 %1739, i32 %1726
  store i32 %1740, ptr %ready.count, align 4
  %1741 = load <8 x i1>, ptr %runnable.mask, align 1
  %1742 = or <8 x i1> %1741, %1672
  store <8 x i1> %1742, ptr %runnable.mask, align 1
  store <8 x i1> %1674, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true368:                         ; preds = %varying.coherent363
  store <8 x i1> %convergence.cascade.result360, ptr %current.mask, align 1
  %1743 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result360)
  br i1 %1743, label %schedule.10, label %scheduler.loop

varying.coherent.false369:                        ; preds = %varying.coherent363
  store <8 x i1> %convergence.cascade.result360, ptr %current.mask, align 1
  %1744 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result360)
  br i1 %1744, label %schedule.45, label %scheduler.loop

copy.active374:                                   ; preds = %schedule.10
  %1745 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load373, 0
  %1746 = extractelement <8 x ptr> %1745, i64 0
  %1747 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load373, 1
  %1748 = extractelement <8 x i64> %1747, i64 0
  %1749 = getelementptr i8, ptr %1746, i64 %1748
  %1750 = extractelement <8 x i64> %297, i64 0
  call void @llm_attention.contiguous_copy.2(ptr %298, i64 %1750, ptr %1749)
  br label %copy.continue375

copy.continue375:                                 ; preds = %copy.active374, %schedule.10
  %1751 = extractelement <8 x i1> %285, i64 1
  br i1 %1751, label %copy.active376, label %copy.continue377

copy.active376:                                   ; preds = %copy.continue375
  %1752 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load373, 0
  %1753 = extractelement <8 x ptr> %1752, i64 1
  %1754 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load373, 1
  %1755 = extractelement <8 x i64> %1754, i64 1
  %1756 = getelementptr i8, ptr %1753, i64 %1755
  %1757 = extractelement <8 x i64> %297, i64 1
  call void @llm_attention.contiguous_copy.2(ptr %298, i64 %1757, ptr %1756)
  br label %copy.continue377

copy.continue377:                                 ; preds = %copy.active376, %copy.continue375
  %1758 = extractelement <8 x i1> %285, i64 2
  br i1 %1758, label %copy.active378, label %copy.continue379

copy.active378:                                   ; preds = %copy.continue377
  %1759 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load373, 0
  %1760 = extractelement <8 x ptr> %1759, i64 2
  %1761 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load373, 1
  %1762 = extractelement <8 x i64> %1761, i64 2
  %1763 = getelementptr i8, ptr %1760, i64 %1762
  %1764 = extractelement <8 x i64> %297, i64 2
  call void @llm_attention.contiguous_copy.2(ptr %298, i64 %1764, ptr %1763)
  br label %copy.continue379

copy.continue379:                                 ; preds = %copy.active378, %copy.continue377
  %1765 = extractelement <8 x i1> %285, i64 3
  br i1 %1765, label %copy.active380, label %copy.continue381

copy.active380:                                   ; preds = %copy.continue379
  %1766 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load373, 0
  %1767 = extractelement <8 x ptr> %1766, i64 3
  %1768 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load373, 1
  %1769 = extractelement <8 x i64> %1768, i64 3
  %1770 = getelementptr i8, ptr %1767, i64 %1769
  %1771 = extractelement <8 x i64> %297, i64 3
  call void @llm_attention.contiguous_copy.2(ptr %298, i64 %1771, ptr %1770)
  br label %copy.continue381

copy.continue381:                                 ; preds = %copy.active380, %copy.continue379
  %1772 = extractelement <8 x i1> %285, i64 4
  br i1 %1772, label %copy.active382, label %copy.continue383

copy.active382:                                   ; preds = %copy.continue381
  %1773 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load373, 0
  %1774 = extractelement <8 x ptr> %1773, i64 4
  %1775 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load373, 1
  %1776 = extractelement <8 x i64> %1775, i64 4
  %1777 = getelementptr i8, ptr %1774, i64 %1776
  %1778 = extractelement <8 x i64> %297, i64 4
  call void @llm_attention.contiguous_copy.2(ptr %298, i64 %1778, ptr %1777)
  br label %copy.continue383

copy.continue383:                                 ; preds = %copy.active382, %copy.continue381
  %1779 = extractelement <8 x i1> %285, i64 5
  br i1 %1779, label %copy.active384, label %copy.continue385

copy.active384:                                   ; preds = %copy.continue383
  %1780 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load373, 0
  %1781 = extractelement <8 x ptr> %1780, i64 5
  %1782 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load373, 1
  %1783 = extractelement <8 x i64> %1782, i64 5
  %1784 = getelementptr i8, ptr %1781, i64 %1783
  %1785 = extractelement <8 x i64> %297, i64 5
  call void @llm_attention.contiguous_copy.2(ptr %298, i64 %1785, ptr %1784)
  br label %copy.continue385

copy.continue385:                                 ; preds = %copy.active384, %copy.continue383
  %1786 = extractelement <8 x i1> %285, i64 6
  br i1 %1786, label %copy.active386, label %copy.continue387

copy.active386:                                   ; preds = %copy.continue385
  %1787 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load373, 0
  %1788 = extractelement <8 x ptr> %1787, i64 6
  %1789 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load373, 1
  %1790 = extractelement <8 x i64> %1789, i64 6
  %1791 = getelementptr i8, ptr %1788, i64 %1790
  %1792 = extractelement <8 x i64> %297, i64 6
  call void @llm_attention.contiguous_copy.2(ptr %298, i64 %1792, ptr %1791)
  br label %copy.continue387

copy.continue387:                                 ; preds = %copy.active386, %copy.continue385
  %1793 = extractelement <8 x i1> %285, i64 7
  br i1 %1793, label %copy.active388, label %copy.continue389

copy.active388:                                   ; preds = %copy.continue387
  %1794 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load373, 0
  %1795 = extractelement <8 x ptr> %1794, i64 7
  %1796 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load373, 1
  %1797 = extractelement <8 x i64> %1796, i64 7
  %1798 = getelementptr i8, ptr %1795, i64 %1797
  %1799 = extractelement <8 x i64> %297, i64 7
  call void @llm_attention.contiguous_copy.2(ptr %298, i64 %1799, ptr %1798)
  br label %copy.continue389

copy.continue389:                                 ; preds = %copy.active388, %copy.continue387
  store <8 x i1> %285, ptr %current.mask, align 1
  %1800 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %285)
  br i1 %1800, label %schedule.11, label %scheduler.loop

convergence.cascade390:                           ; preds = %convergence.cascade390, %schedule.11
  %convergence.cascade.flow394 = phi <8 x i1> [ %300, %schedule.11 ], [ %1843, %convergence.cascade390 ]
  %convergence.cascade.depth395 = phi i32 [ 0, %schedule.11 ], [ %1844, %convergence.cascade390 ]
  %1801 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow394)
  %1802 = load i32, ptr %current.token, align 4
  %1803 = icmp ne i32 %1802, 0
  %1804 = and i1 %1801, %1803
  %1805 = sub i32 %1802, 1
  %1806 = select i1 %1804, i32 %1805, i32 0
  %1807 = load i8, ptr %frame.active, align 1
  %1808 = trunc i32 %1806 to i8
  %1809 = shl i8 1, %1808
  %1810 = and i8 %1807, %1809
  %1811 = icmp ne i8 %1810, 0
  %1812 = load <8 x i32>, ptr %frame.static.id, align 32
  %1813 = extractelement <8 x i32> %1812, i32 %1806
  %convergence.target.pointer396 = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %1813
  %convergence.dynamic.target397 = load i32, ptr %convergence.target.pointer396, align 4
  %1814 = icmp eq i32 %convergence.dynamic.target397, 11
  %1815 = and i1 %1811, %1814
  %1816 = and i1 %1804, %1815
  %1817 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1806
  %1818 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1806
  %1819 = load <8 x i1>, ptr %1817, align 1
  %1820 = load <8 x i1>, ptr %1818, align 1
  %1821 = or <8 x i1> %1820, %convergence.cascade.flow394
  %1822 = load <8 x i1>, ptr %live.mask, align 1
  %1823 = and <8 x i1> %1819, %1822
  %1824 = icmp eq <8 x i1> %1821, %1823
  %1825 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1824)
  %1826 = and i1 %1816, %1825
  %1827 = select i1 %1826, <8 x i1> zeroinitializer, <8 x i1> %1821
  %1828 = select i1 %1816, <8 x i1> %1827, <8 x i1> %1820
  store <8 x i1> %1828, ptr %1818, align 1
  %1829 = select i1 %1826, <8 x i1> zeroinitializer, <8 x i1> %1819
  store <8 x i1> %1829, ptr %1817, align 1
  %1830 = trunc i32 %1806 to i8
  %1831 = shl i8 1, %1830
  %1832 = xor i8 %1831, -1
  %1833 = and i8 %1807, %1832
  %1834 = select i1 %1826, i8 %1833, i8 %1807
  store i8 %1834, ptr %frame.active, align 1
  %.splatinsert398 = insertelement <8 x i1> poison, i1 %1816, i64 0
  %.splat399 = shufflevector <8 x i1> %.splatinsert398, <8 x i1> poison, <8 x i32> zeroinitializer
  %1835 = and <8 x i1> %convergence.cascade.flow394, %.splat399
  %1836 = load <8 x i1>, ptr %runnable.mask, align 1
  %1837 = xor <8 x i1> %1835, splat (i1 true)
  %1838 = and <8 x i1> %1836, %1837
  store <8 x i1> %1838, ptr %runnable.mask, align 1
  %.splatinsert400 = insertelement <8 x i1> poison, i1 %1826, i64 0
  %.splat401 = shufflevector <8 x i1> %.splatinsert400, <8 x i1> poison, <8 x i32> zeroinitializer
  %1839 = select <8 x i1> %.splat401, <8 x i1> %1821, <8 x i1> zeroinitializer
  %1840 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1841 = extractelement <8 x i32> %1840, i32 %1806
  %1842 = select i1 %1826, i32 %1841, i32 %1802
  store i32 %1842, ptr %current.token, align 4
  %.splatinsert402 = insertelement <8 x i1> poison, i1 %1816, i64 0
  %.splat403 = shufflevector <8 x i1> %.splatinsert402, <8 x i1> poison, <8 x i32> zeroinitializer
  %1843 = select <8 x i1> %.splat403, <8 x i1> %1839, <8 x i1> %convergence.cascade.flow394
  %1844 = add i32 %convergence.cascade.depth395, 1
  %1845 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1843)
  %1846 = icmp ult i32 %1844, 8
  %1847 = and i1 %1845, %1846
  %1848 = and i1 %1816, %1847
  %convergence.parent.token404 = load i32, ptr %current.token, align 4
  %convergence.parent.present405 = icmp ne i32 %convergence.parent.token404, 0
  %1849 = and i1 %1848, %convergence.parent.present405
  br i1 %1849, label %convergence.cascade390, label %convergence.cascade.exit391

convergence.cascade.exit391:                      ; preds = %convergence.cascade390, %schedule.11
  %convergence.cascade.result406 = phi <8 x i1> [ %300, %schedule.11 ], [ %1843, %convergence.cascade390 ]
  %1850 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  br i1 %1850, label %convergence.target.11.ready, label %scheduler.loop

convergence.target.11.ready:                      ; preds = %convergence.cascade.exit391
  %1851 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %1852 = bitcast <8 x i1> %convergence.cascade.result406 to i8
  %1853 = call i8 @llvm.cttz.i8(i8 %1852, i1 false)
  %1854 = zext i8 %1853 to i32
  %1855 = select i1 %1851, i32 %1854, i32 0
  %1856 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1857 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1858 = add <8 x i64> %1857, zeroinitializer
  %1859 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1856, 0
  %1860 = insertvalue { <8 x ptr>, <8 x i64> } %1859, <8 x i64> %1858, 1
  %1861 = extractvalue { <8 x ptr>, <8 x i64> } %1860, 0
  %1862 = extractvalue { <8 x ptr>, <8 x i64> } %1860, 1
  %1863 = getelementptr i8, <8 x ptr> %1861, <8 x i64> %1862
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1863, <8 x i1> %convergence.cascade.result406)
  %1864 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1865 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1866 = add <8 x i64> %1865, splat (i64 4)
  %1867 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1864, 0
  %1868 = insertvalue { <8 x ptr>, <8 x i64> } %1867, <8 x i64> %1866, 1
  %1869 = extractvalue { <8 x ptr>, <8 x i64> } %1868, 0
  %1870 = extractvalue { <8 x ptr>, <8 x i64> } %1868, 1
  %1871 = getelementptr i8, <8 x ptr> %1869, <8 x i64> %1870
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1871, <8 x i1> %convergence.cascade.result406)
  %1872 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1873 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1874 = add <8 x i64> %1873, splat (i64 8)
  %1875 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1872, 0
  %1876 = insertvalue { <8 x ptr>, <8 x i64> } %1875, <8 x i64> %1874, 1
  %1877 = extractvalue { <8 x ptr>, <8 x i64> } %1876, 0
  %1878 = extractvalue { <8 x ptr>, <8 x i64> } %1876, 1
  %1879 = getelementptr i8, <8 x ptr> %1877, <8 x i64> %1878
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1879, <8 x i1> %convergence.cascade.result406)
  %1880 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1881 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1882 = add <8 x i64> %1881, splat (i64 12)
  %1883 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1880, 0
  %1884 = insertvalue { <8 x ptr>, <8 x i64> } %1883, <8 x i64> %1882, 1
  %1885 = extractvalue { <8 x ptr>, <8 x i64> } %1884, 0
  %1886 = extractvalue { <8 x ptr>, <8 x i64> } %1884, 1
  %1887 = getelementptr i8, <8 x ptr> %1885, <8 x i64> %1886
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1887, <8 x i1> %convergence.cascade.result406)
  %1888 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1889 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1890 = add <8 x i64> %1889, splat (i64 16)
  %1891 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1888, 0
  %1892 = insertvalue { <8 x ptr>, <8 x i64> } %1891, <8 x i64> %1890, 1
  %1893 = extractvalue { <8 x ptr>, <8 x i64> } %1892, 0
  %1894 = extractvalue { <8 x ptr>, <8 x i64> } %1892, 1
  %1895 = getelementptr i8, <8 x ptr> %1893, <8 x i64> %1894
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1895, <8 x i1> %convergence.cascade.result406)
  %1896 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1897 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1898 = add <8 x i64> %1897, splat (i64 20)
  %1899 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1896, 0
  %1900 = insertvalue { <8 x ptr>, <8 x i64> } %1899, <8 x i64> %1898, 1
  %1901 = extractvalue { <8 x ptr>, <8 x i64> } %1900, 0
  %1902 = extractvalue { <8 x ptr>, <8 x i64> } %1900, 1
  %1903 = getelementptr i8, <8 x ptr> %1901, <8 x i64> %1902
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1903, <8 x i1> %convergence.cascade.result406)
  %1904 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1905 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1906 = add <8 x i64> %1905, splat (i64 24)
  %1907 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1904, 0
  %1908 = insertvalue { <8 x ptr>, <8 x i64> } %1907, <8 x i64> %1906, 1
  %1909 = extractvalue { <8 x ptr>, <8 x i64> } %1908, 0
  %1910 = extractvalue { <8 x ptr>, <8 x i64> } %1908, 1
  %1911 = getelementptr i8, <8 x ptr> %1909, <8 x i64> %1910
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1911, <8 x i1> %convergence.cascade.result406)
  %1912 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1913 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1914 = add <8 x i64> %1913, splat (i64 28)
  %1915 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1912, 0
  %1916 = insertvalue { <8 x ptr>, <8 x i64> } %1915, <8 x i64> %1914, 1
  %1917 = extractvalue { <8 x ptr>, <8 x i64> } %1916, 0
  %1918 = extractvalue { <8 x ptr>, <8 x i64> } %1916, 1
  %1919 = getelementptr i8, <8 x ptr> %1917, <8 x i64> %1918
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1919, <8 x i1> %convergence.cascade.result406)
  %1920 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1921 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1922 = add <8 x i64> %1921, splat (i64 32)
  %1923 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1920, 0
  %1924 = insertvalue { <8 x ptr>, <8 x i64> } %1923, <8 x i64> %1922, 1
  %1925 = extractvalue { <8 x ptr>, <8 x i64> } %1924, 0
  %1926 = extractvalue { <8 x ptr>, <8 x i64> } %1924, 1
  %1927 = getelementptr i8, <8 x ptr> %1925, <8 x i64> %1926
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1927, <8 x i1> %convergence.cascade.result406)
  %1928 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1929 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1930 = add <8 x i64> %1929, splat (i64 36)
  %1931 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1928, 0
  %1932 = insertvalue { <8 x ptr>, <8 x i64> } %1931, <8 x i64> %1930, 1
  %1933 = extractvalue { <8 x ptr>, <8 x i64> } %1932, 0
  %1934 = extractvalue { <8 x ptr>, <8 x i64> } %1932, 1
  %1935 = getelementptr i8, <8 x ptr> %1933, <8 x i64> %1934
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1935, <8 x i1> %convergence.cascade.result406)
  %1936 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1937 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1938 = add <8 x i64> %1937, splat (i64 40)
  %1939 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1936, 0
  %1940 = insertvalue { <8 x ptr>, <8 x i64> } %1939, <8 x i64> %1938, 1
  %1941 = extractvalue { <8 x ptr>, <8 x i64> } %1940, 0
  %1942 = extractvalue { <8 x ptr>, <8 x i64> } %1940, 1
  %1943 = getelementptr i8, <8 x ptr> %1941, <8 x i64> %1942
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1943, <8 x i1> %convergence.cascade.result406)
  %1944 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1945 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1946 = add <8 x i64> %1945, splat (i64 44)
  %1947 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1944, 0
  %1948 = insertvalue { <8 x ptr>, <8 x i64> } %1947, <8 x i64> %1946, 1
  %1949 = extractvalue { <8 x ptr>, <8 x i64> } %1948, 0
  %1950 = extractvalue { <8 x ptr>, <8 x i64> } %1948, 1
  %1951 = getelementptr i8, <8 x ptr> %1949, <8 x i64> %1950
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1951, <8 x i1> %convergence.cascade.result406)
  %1952 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1953 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1954 = add <8 x i64> %1953, splat (i64 48)
  %1955 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1952, 0
  %1956 = insertvalue { <8 x ptr>, <8 x i64> } %1955, <8 x i64> %1954, 1
  %1957 = extractvalue { <8 x ptr>, <8 x i64> } %1956, 0
  %1958 = extractvalue { <8 x ptr>, <8 x i64> } %1956, 1
  %1959 = getelementptr i8, <8 x ptr> %1957, <8 x i64> %1958
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1959, <8 x i1> %convergence.cascade.result406)
  %1960 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1961 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1962 = add <8 x i64> %1961, splat (i64 52)
  %1963 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1960, 0
  %1964 = insertvalue { <8 x ptr>, <8 x i64> } %1963, <8 x i64> %1962, 1
  %1965 = extractvalue { <8 x ptr>, <8 x i64> } %1964, 0
  %1966 = extractvalue { <8 x ptr>, <8 x i64> } %1964, 1
  %1967 = getelementptr i8, <8 x ptr> %1965, <8 x i64> %1966
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1967, <8 x i1> %convergence.cascade.result406)
  %1968 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1969 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1970 = add <8 x i64> %1969, splat (i64 56)
  %1971 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1968, 0
  %1972 = insertvalue { <8 x ptr>, <8 x i64> } %1971, <8 x i64> %1970, 1
  %1973 = extractvalue { <8 x ptr>, <8 x i64> } %1972, 0
  %1974 = extractvalue { <8 x ptr>, <8 x i64> } %1972, 1
  %1975 = getelementptr i8, <8 x ptr> %1973, <8 x i64> %1974
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1975, <8 x i1> %convergence.cascade.result406)
  %1976 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1977 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1978 = add <8 x i64> %1977, splat (i64 60)
  %1979 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1976, 0
  %1980 = insertvalue { <8 x ptr>, <8 x i64> } %1979, <8 x i64> %1978, 1
  %1981 = extractvalue { <8 x ptr>, <8 x i64> } %1980, 0
  %1982 = extractvalue { <8 x ptr>, <8 x i64> } %1980, 1
  %1983 = getelementptr i8, <8 x ptr> %1981, <8 x i64> %1982
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1983, <8 x i1> %convergence.cascade.result406)
  %1984 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1985 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1986 = add <8 x i64> %1985, splat (i64 64)
  %1987 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1984, 0
  %1988 = insertvalue { <8 x ptr>, <8 x i64> } %1987, <8 x i64> %1986, 1
  %1989 = extractvalue { <8 x ptr>, <8 x i64> } %1988, 0
  %1990 = extractvalue { <8 x ptr>, <8 x i64> } %1988, 1
  %1991 = getelementptr i8, <8 x ptr> %1989, <8 x i64> %1990
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1991, <8 x i1> %convergence.cascade.result406)
  %1992 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1993 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1994 = add <8 x i64> %1993, splat (i64 68)
  %1995 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1992, 0
  %1996 = insertvalue { <8 x ptr>, <8 x i64> } %1995, <8 x i64> %1994, 1
  %1997 = extractvalue { <8 x ptr>, <8 x i64> } %1996, 0
  %1998 = extractvalue { <8 x ptr>, <8 x i64> } %1996, 1
  %1999 = getelementptr i8, <8 x ptr> %1997, <8 x i64> %1998
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1999, <8 x i1> %convergence.cascade.result406)
  %2000 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2001 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2002 = add <8 x i64> %2001, splat (i64 72)
  %2003 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2000, 0
  %2004 = insertvalue { <8 x ptr>, <8 x i64> } %2003, <8 x i64> %2002, 1
  %2005 = extractvalue { <8 x ptr>, <8 x i64> } %2004, 0
  %2006 = extractvalue { <8 x ptr>, <8 x i64> } %2004, 1
  %2007 = getelementptr i8, <8 x ptr> %2005, <8 x i64> %2006
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2007, <8 x i1> %convergence.cascade.result406)
  %2008 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2009 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2010 = add <8 x i64> %2009, splat (i64 76)
  %2011 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2008, 0
  %2012 = insertvalue { <8 x ptr>, <8 x i64> } %2011, <8 x i64> %2010, 1
  %2013 = extractvalue { <8 x ptr>, <8 x i64> } %2012, 0
  %2014 = extractvalue { <8 x ptr>, <8 x i64> } %2012, 1
  %2015 = getelementptr i8, <8 x ptr> %2013, <8 x i64> %2014
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2015, <8 x i1> %convergence.cascade.result406)
  %2016 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2017 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2018 = add <8 x i64> %2017, splat (i64 80)
  %2019 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2016, 0
  %2020 = insertvalue { <8 x ptr>, <8 x i64> } %2019, <8 x i64> %2018, 1
  %2021 = extractvalue { <8 x ptr>, <8 x i64> } %2020, 0
  %2022 = extractvalue { <8 x ptr>, <8 x i64> } %2020, 1
  %2023 = getelementptr i8, <8 x ptr> %2021, <8 x i64> %2022
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2023, <8 x i1> %convergence.cascade.result406)
  %2024 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2025 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2026 = add <8 x i64> %2025, splat (i64 84)
  %2027 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2024, 0
  %2028 = insertvalue { <8 x ptr>, <8 x i64> } %2027, <8 x i64> %2026, 1
  %2029 = extractvalue { <8 x ptr>, <8 x i64> } %2028, 0
  %2030 = extractvalue { <8 x ptr>, <8 x i64> } %2028, 1
  %2031 = getelementptr i8, <8 x ptr> %2029, <8 x i64> %2030
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2031, <8 x i1> %convergence.cascade.result406)
  %2032 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2033 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2034 = add <8 x i64> %2033, splat (i64 88)
  %2035 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2032, 0
  %2036 = insertvalue { <8 x ptr>, <8 x i64> } %2035, <8 x i64> %2034, 1
  %2037 = extractvalue { <8 x ptr>, <8 x i64> } %2036, 0
  %2038 = extractvalue { <8 x ptr>, <8 x i64> } %2036, 1
  %2039 = getelementptr i8, <8 x ptr> %2037, <8 x i64> %2038
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2039, <8 x i1> %convergence.cascade.result406)
  %2040 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2041 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2042 = add <8 x i64> %2041, splat (i64 92)
  %2043 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2040, 0
  %2044 = insertvalue { <8 x ptr>, <8 x i64> } %2043, <8 x i64> %2042, 1
  %2045 = extractvalue { <8 x ptr>, <8 x i64> } %2044, 0
  %2046 = extractvalue { <8 x ptr>, <8 x i64> } %2044, 1
  %2047 = getelementptr i8, <8 x ptr> %2045, <8 x i64> %2046
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2047, <8 x i1> %convergence.cascade.result406)
  %2048 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2049 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2050 = add <8 x i64> %2049, splat (i64 96)
  %2051 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2048, 0
  %2052 = insertvalue { <8 x ptr>, <8 x i64> } %2051, <8 x i64> %2050, 1
  %2053 = extractvalue { <8 x ptr>, <8 x i64> } %2052, 0
  %2054 = extractvalue { <8 x ptr>, <8 x i64> } %2052, 1
  %2055 = getelementptr i8, <8 x ptr> %2053, <8 x i64> %2054
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2055, <8 x i1> %convergence.cascade.result406)
  %2056 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2057 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2058 = add <8 x i64> %2057, splat (i64 100)
  %2059 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2056, 0
  %2060 = insertvalue { <8 x ptr>, <8 x i64> } %2059, <8 x i64> %2058, 1
  %2061 = extractvalue { <8 x ptr>, <8 x i64> } %2060, 0
  %2062 = extractvalue { <8 x ptr>, <8 x i64> } %2060, 1
  %2063 = getelementptr i8, <8 x ptr> %2061, <8 x i64> %2062
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2063, <8 x i1> %convergence.cascade.result406)
  %2064 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2065 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2066 = add <8 x i64> %2065, splat (i64 104)
  %2067 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2064, 0
  %2068 = insertvalue { <8 x ptr>, <8 x i64> } %2067, <8 x i64> %2066, 1
  %2069 = extractvalue { <8 x ptr>, <8 x i64> } %2068, 0
  %2070 = extractvalue { <8 x ptr>, <8 x i64> } %2068, 1
  %2071 = getelementptr i8, <8 x ptr> %2069, <8 x i64> %2070
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2071, <8 x i1> %convergence.cascade.result406)
  %2072 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2073 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2074 = add <8 x i64> %2073, splat (i64 108)
  %2075 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2072, 0
  %2076 = insertvalue { <8 x ptr>, <8 x i64> } %2075, <8 x i64> %2074, 1
  %2077 = extractvalue { <8 x ptr>, <8 x i64> } %2076, 0
  %2078 = extractvalue { <8 x ptr>, <8 x i64> } %2076, 1
  %2079 = getelementptr i8, <8 x ptr> %2077, <8 x i64> %2078
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2079, <8 x i1> %convergence.cascade.result406)
  %2080 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2081 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2082 = add <8 x i64> %2081, splat (i64 112)
  %2083 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2080, 0
  %2084 = insertvalue { <8 x ptr>, <8 x i64> } %2083, <8 x i64> %2082, 1
  %2085 = extractvalue { <8 x ptr>, <8 x i64> } %2084, 0
  %2086 = extractvalue { <8 x ptr>, <8 x i64> } %2084, 1
  %2087 = getelementptr i8, <8 x ptr> %2085, <8 x i64> %2086
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2087, <8 x i1> %convergence.cascade.result406)
  %2088 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2089 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2090 = add <8 x i64> %2089, splat (i64 116)
  %2091 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2088, 0
  %2092 = insertvalue { <8 x ptr>, <8 x i64> } %2091, <8 x i64> %2090, 1
  %2093 = extractvalue { <8 x ptr>, <8 x i64> } %2092, 0
  %2094 = extractvalue { <8 x ptr>, <8 x i64> } %2092, 1
  %2095 = getelementptr i8, <8 x ptr> %2093, <8 x i64> %2094
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2095, <8 x i1> %convergence.cascade.result406)
  %2096 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2097 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2098 = add <8 x i64> %2097, splat (i64 120)
  %2099 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2096, 0
  %2100 = insertvalue { <8 x ptr>, <8 x i64> } %2099, <8 x i64> %2098, 1
  %2101 = extractvalue { <8 x ptr>, <8 x i64> } %2100, 0
  %2102 = extractvalue { <8 x ptr>, <8 x i64> } %2100, 1
  %2103 = getelementptr i8, <8 x ptr> %2101, <8 x i64> %2102
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2103, <8 x i1> %convergence.cascade.result406)
  %2104 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2105 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2106 = add <8 x i64> %2105, splat (i64 124)
  %2107 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2104, 0
  %2108 = insertvalue { <8 x ptr>, <8 x i64> } %2107, <8 x i64> %2106, 1
  %2109 = extractvalue { <8 x ptr>, <8 x i64> } %2108, 0
  %2110 = extractvalue { <8 x ptr>, <8 x i64> } %2108, 1
  %2111 = getelementptr i8, <8 x ptr> %2109, <8 x i64> %2110
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2111, <8 x i1> %convergence.cascade.result406)
  %2112 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2113 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2114 = add <8 x i64> %2113, splat (i64 128)
  %2115 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2112, 0
  %2116 = insertvalue { <8 x ptr>, <8 x i64> } %2115, <8 x i64> %2114, 1
  %2117 = extractvalue { <8 x ptr>, <8 x i64> } %2116, 0
  %2118 = extractvalue { <8 x ptr>, <8 x i64> } %2116, 1
  %2119 = getelementptr i8, <8 x ptr> %2117, <8 x i64> %2118
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2119, <8 x i1> %convergence.cascade.result406)
  %2120 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2121 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2122 = add <8 x i64> %2121, splat (i64 132)
  %2123 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2120, 0
  %2124 = insertvalue { <8 x ptr>, <8 x i64> } %2123, <8 x i64> %2122, 1
  %2125 = extractvalue { <8 x ptr>, <8 x i64> } %2124, 0
  %2126 = extractvalue { <8 x ptr>, <8 x i64> } %2124, 1
  %2127 = getelementptr i8, <8 x ptr> %2125, <8 x i64> %2126
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2127, <8 x i1> %convergence.cascade.result406)
  %2128 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2129 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2130 = add <8 x i64> %2129, splat (i64 136)
  %2131 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2128, 0
  %2132 = insertvalue { <8 x ptr>, <8 x i64> } %2131, <8 x i64> %2130, 1
  %2133 = extractvalue { <8 x ptr>, <8 x i64> } %2132, 0
  %2134 = extractvalue { <8 x ptr>, <8 x i64> } %2132, 1
  %2135 = getelementptr i8, <8 x ptr> %2133, <8 x i64> %2134
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2135, <8 x i1> %convergence.cascade.result406)
  %2136 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2137 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2138 = add <8 x i64> %2137, splat (i64 140)
  %2139 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2136, 0
  %2140 = insertvalue { <8 x ptr>, <8 x i64> } %2139, <8 x i64> %2138, 1
  %2141 = extractvalue { <8 x ptr>, <8 x i64> } %2140, 0
  %2142 = extractvalue { <8 x ptr>, <8 x i64> } %2140, 1
  %2143 = getelementptr i8, <8 x ptr> %2141, <8 x i64> %2142
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2143, <8 x i1> %convergence.cascade.result406)
  %2144 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2145 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2146 = add <8 x i64> %2145, splat (i64 144)
  %2147 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2144, 0
  %2148 = insertvalue { <8 x ptr>, <8 x i64> } %2147, <8 x i64> %2146, 1
  %2149 = extractvalue { <8 x ptr>, <8 x i64> } %2148, 0
  %2150 = extractvalue { <8 x ptr>, <8 x i64> } %2148, 1
  %2151 = getelementptr i8, <8 x ptr> %2149, <8 x i64> %2150
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2151, <8 x i1> %convergence.cascade.result406)
  %2152 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2153 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2154 = add <8 x i64> %2153, splat (i64 148)
  %2155 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2152, 0
  %2156 = insertvalue { <8 x ptr>, <8 x i64> } %2155, <8 x i64> %2154, 1
  %2157 = extractvalue { <8 x ptr>, <8 x i64> } %2156, 0
  %2158 = extractvalue { <8 x ptr>, <8 x i64> } %2156, 1
  %2159 = getelementptr i8, <8 x ptr> %2157, <8 x i64> %2158
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2159, <8 x i1> %convergence.cascade.result406)
  %2160 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2161 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2162 = add <8 x i64> %2161, splat (i64 152)
  %2163 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2160, 0
  %2164 = insertvalue { <8 x ptr>, <8 x i64> } %2163, <8 x i64> %2162, 1
  %2165 = extractvalue { <8 x ptr>, <8 x i64> } %2164, 0
  %2166 = extractvalue { <8 x ptr>, <8 x i64> } %2164, 1
  %2167 = getelementptr i8, <8 x ptr> %2165, <8 x i64> %2166
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2167, <8 x i1> %convergence.cascade.result406)
  %2168 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2169 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2170 = add <8 x i64> %2169, splat (i64 156)
  %2171 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2168, 0
  %2172 = insertvalue { <8 x ptr>, <8 x i64> } %2171, <8 x i64> %2170, 1
  %2173 = extractvalue { <8 x ptr>, <8 x i64> } %2172, 0
  %2174 = extractvalue { <8 x ptr>, <8 x i64> } %2172, 1
  %2175 = getelementptr i8, <8 x ptr> %2173, <8 x i64> %2174
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2175, <8 x i1> %convergence.cascade.result406)
  %2176 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2177 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2178 = add <8 x i64> %2177, splat (i64 160)
  %2179 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2176, 0
  %2180 = insertvalue { <8 x ptr>, <8 x i64> } %2179, <8 x i64> %2178, 1
  %2181 = extractvalue { <8 x ptr>, <8 x i64> } %2180, 0
  %2182 = extractvalue { <8 x ptr>, <8 x i64> } %2180, 1
  %2183 = getelementptr i8, <8 x ptr> %2181, <8 x i64> %2182
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2183, <8 x i1> %convergence.cascade.result406)
  %2184 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2185 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2186 = add <8 x i64> %2185, splat (i64 164)
  %2187 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2184, 0
  %2188 = insertvalue { <8 x ptr>, <8 x i64> } %2187, <8 x i64> %2186, 1
  %2189 = extractvalue { <8 x ptr>, <8 x i64> } %2188, 0
  %2190 = extractvalue { <8 x ptr>, <8 x i64> } %2188, 1
  %2191 = getelementptr i8, <8 x ptr> %2189, <8 x i64> %2190
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2191, <8 x i1> %convergence.cascade.result406)
  %2192 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2193 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2194 = add <8 x i64> %2193, splat (i64 168)
  %2195 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2192, 0
  %2196 = insertvalue { <8 x ptr>, <8 x i64> } %2195, <8 x i64> %2194, 1
  %2197 = extractvalue { <8 x ptr>, <8 x i64> } %2196, 0
  %2198 = extractvalue { <8 x ptr>, <8 x i64> } %2196, 1
  %2199 = getelementptr i8, <8 x ptr> %2197, <8 x i64> %2198
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2199, <8 x i1> %convergence.cascade.result406)
  %2200 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2201 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2202 = add <8 x i64> %2201, splat (i64 172)
  %2203 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2200, 0
  %2204 = insertvalue { <8 x ptr>, <8 x i64> } %2203, <8 x i64> %2202, 1
  %2205 = extractvalue { <8 x ptr>, <8 x i64> } %2204, 0
  %2206 = extractvalue { <8 x ptr>, <8 x i64> } %2204, 1
  %2207 = getelementptr i8, <8 x ptr> %2205, <8 x i64> %2206
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2207, <8 x i1> %convergence.cascade.result406)
  %2208 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2209 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2210 = add <8 x i64> %2209, splat (i64 176)
  %2211 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2208, 0
  %2212 = insertvalue { <8 x ptr>, <8 x i64> } %2211, <8 x i64> %2210, 1
  %2213 = extractvalue { <8 x ptr>, <8 x i64> } %2212, 0
  %2214 = extractvalue { <8 x ptr>, <8 x i64> } %2212, 1
  %2215 = getelementptr i8, <8 x ptr> %2213, <8 x i64> %2214
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2215, <8 x i1> %convergence.cascade.result406)
  %2216 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2217 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2218 = add <8 x i64> %2217, splat (i64 180)
  %2219 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2216, 0
  %2220 = insertvalue { <8 x ptr>, <8 x i64> } %2219, <8 x i64> %2218, 1
  %2221 = extractvalue { <8 x ptr>, <8 x i64> } %2220, 0
  %2222 = extractvalue { <8 x ptr>, <8 x i64> } %2220, 1
  %2223 = getelementptr i8, <8 x ptr> %2221, <8 x i64> %2222
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2223, <8 x i1> %convergence.cascade.result406)
  %2224 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2225 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2226 = add <8 x i64> %2225, splat (i64 184)
  %2227 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2224, 0
  %2228 = insertvalue { <8 x ptr>, <8 x i64> } %2227, <8 x i64> %2226, 1
  %2229 = extractvalue { <8 x ptr>, <8 x i64> } %2228, 0
  %2230 = extractvalue { <8 x ptr>, <8 x i64> } %2228, 1
  %2231 = getelementptr i8, <8 x ptr> %2229, <8 x i64> %2230
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2231, <8 x i1> %convergence.cascade.result406)
  %2232 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2233 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2234 = add <8 x i64> %2233, splat (i64 188)
  %2235 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2232, 0
  %2236 = insertvalue { <8 x ptr>, <8 x i64> } %2235, <8 x i64> %2234, 1
  %2237 = extractvalue { <8 x ptr>, <8 x i64> } %2236, 0
  %2238 = extractvalue { <8 x ptr>, <8 x i64> } %2236, 1
  %2239 = getelementptr i8, <8 x ptr> %2237, <8 x i64> %2238
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2239, <8 x i1> %convergence.cascade.result406)
  %2240 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2241 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2242 = add <8 x i64> %2241, splat (i64 192)
  %2243 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2240, 0
  %2244 = insertvalue { <8 x ptr>, <8 x i64> } %2243, <8 x i64> %2242, 1
  %2245 = extractvalue { <8 x ptr>, <8 x i64> } %2244, 0
  %2246 = extractvalue { <8 x ptr>, <8 x i64> } %2244, 1
  %2247 = getelementptr i8, <8 x ptr> %2245, <8 x i64> %2246
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2247, <8 x i1> %convergence.cascade.result406)
  %2248 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2249 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2250 = add <8 x i64> %2249, splat (i64 196)
  %2251 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2248, 0
  %2252 = insertvalue { <8 x ptr>, <8 x i64> } %2251, <8 x i64> %2250, 1
  %2253 = extractvalue { <8 x ptr>, <8 x i64> } %2252, 0
  %2254 = extractvalue { <8 x ptr>, <8 x i64> } %2252, 1
  %2255 = getelementptr i8, <8 x ptr> %2253, <8 x i64> %2254
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2255, <8 x i1> %convergence.cascade.result406)
  %2256 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2257 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2258 = add <8 x i64> %2257, splat (i64 200)
  %2259 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2256, 0
  %2260 = insertvalue { <8 x ptr>, <8 x i64> } %2259, <8 x i64> %2258, 1
  %2261 = extractvalue { <8 x ptr>, <8 x i64> } %2260, 0
  %2262 = extractvalue { <8 x ptr>, <8 x i64> } %2260, 1
  %2263 = getelementptr i8, <8 x ptr> %2261, <8 x i64> %2262
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2263, <8 x i1> %convergence.cascade.result406)
  %2264 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2265 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2266 = add <8 x i64> %2265, splat (i64 204)
  %2267 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2264, 0
  %2268 = insertvalue { <8 x ptr>, <8 x i64> } %2267, <8 x i64> %2266, 1
  %2269 = extractvalue { <8 x ptr>, <8 x i64> } %2268, 0
  %2270 = extractvalue { <8 x ptr>, <8 x i64> } %2268, 1
  %2271 = getelementptr i8, <8 x ptr> %2269, <8 x i64> %2270
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2271, <8 x i1> %convergence.cascade.result406)
  %2272 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2273 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2274 = add <8 x i64> %2273, splat (i64 208)
  %2275 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2272, 0
  %2276 = insertvalue { <8 x ptr>, <8 x i64> } %2275, <8 x i64> %2274, 1
  %2277 = extractvalue { <8 x ptr>, <8 x i64> } %2276, 0
  %2278 = extractvalue { <8 x ptr>, <8 x i64> } %2276, 1
  %2279 = getelementptr i8, <8 x ptr> %2277, <8 x i64> %2278
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2279, <8 x i1> %convergence.cascade.result406)
  %2280 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2281 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2282 = add <8 x i64> %2281, splat (i64 212)
  %2283 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2280, 0
  %2284 = insertvalue { <8 x ptr>, <8 x i64> } %2283, <8 x i64> %2282, 1
  %2285 = extractvalue { <8 x ptr>, <8 x i64> } %2284, 0
  %2286 = extractvalue { <8 x ptr>, <8 x i64> } %2284, 1
  %2287 = getelementptr i8, <8 x ptr> %2285, <8 x i64> %2286
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2287, <8 x i1> %convergence.cascade.result406)
  %2288 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2289 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2290 = add <8 x i64> %2289, splat (i64 216)
  %2291 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2288, 0
  %2292 = insertvalue { <8 x ptr>, <8 x i64> } %2291, <8 x i64> %2290, 1
  %2293 = extractvalue { <8 x ptr>, <8 x i64> } %2292, 0
  %2294 = extractvalue { <8 x ptr>, <8 x i64> } %2292, 1
  %2295 = getelementptr i8, <8 x ptr> %2293, <8 x i64> %2294
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2295, <8 x i1> %convergence.cascade.result406)
  %2296 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2297 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2298 = add <8 x i64> %2297, splat (i64 220)
  %2299 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2296, 0
  %2300 = insertvalue { <8 x ptr>, <8 x i64> } %2299, <8 x i64> %2298, 1
  %2301 = extractvalue { <8 x ptr>, <8 x i64> } %2300, 0
  %2302 = extractvalue { <8 x ptr>, <8 x i64> } %2300, 1
  %2303 = getelementptr i8, <8 x ptr> %2301, <8 x i64> %2302
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2303, <8 x i1> %convergence.cascade.result406)
  %2304 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2305 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2306 = add <8 x i64> %2305, splat (i64 224)
  %2307 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2304, 0
  %2308 = insertvalue { <8 x ptr>, <8 x i64> } %2307, <8 x i64> %2306, 1
  %2309 = extractvalue { <8 x ptr>, <8 x i64> } %2308, 0
  %2310 = extractvalue { <8 x ptr>, <8 x i64> } %2308, 1
  %2311 = getelementptr i8, <8 x ptr> %2309, <8 x i64> %2310
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2311, <8 x i1> %convergence.cascade.result406)
  %2312 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2313 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2314 = add <8 x i64> %2313, splat (i64 228)
  %2315 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2312, 0
  %2316 = insertvalue { <8 x ptr>, <8 x i64> } %2315, <8 x i64> %2314, 1
  %2317 = extractvalue { <8 x ptr>, <8 x i64> } %2316, 0
  %2318 = extractvalue { <8 x ptr>, <8 x i64> } %2316, 1
  %2319 = getelementptr i8, <8 x ptr> %2317, <8 x i64> %2318
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2319, <8 x i1> %convergence.cascade.result406)
  %2320 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2321 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2322 = add <8 x i64> %2321, splat (i64 232)
  %2323 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2320, 0
  %2324 = insertvalue { <8 x ptr>, <8 x i64> } %2323, <8 x i64> %2322, 1
  %2325 = extractvalue { <8 x ptr>, <8 x i64> } %2324, 0
  %2326 = extractvalue { <8 x ptr>, <8 x i64> } %2324, 1
  %2327 = getelementptr i8, <8 x ptr> %2325, <8 x i64> %2326
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2327, <8 x i1> %convergence.cascade.result406)
  %2328 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2329 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2330 = add <8 x i64> %2329, splat (i64 236)
  %2331 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2328, 0
  %2332 = insertvalue { <8 x ptr>, <8 x i64> } %2331, <8 x i64> %2330, 1
  %2333 = extractvalue { <8 x ptr>, <8 x i64> } %2332, 0
  %2334 = extractvalue { <8 x ptr>, <8 x i64> } %2332, 1
  %2335 = getelementptr i8, <8 x ptr> %2333, <8 x i64> %2334
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2335, <8 x i1> %convergence.cascade.result406)
  %2336 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2337 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2338 = add <8 x i64> %2337, splat (i64 240)
  %2339 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2336, 0
  %2340 = insertvalue { <8 x ptr>, <8 x i64> } %2339, <8 x i64> %2338, 1
  %2341 = extractvalue { <8 x ptr>, <8 x i64> } %2340, 0
  %2342 = extractvalue { <8 x ptr>, <8 x i64> } %2340, 1
  %2343 = getelementptr i8, <8 x ptr> %2341, <8 x i64> %2342
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2343, <8 x i1> %convergence.cascade.result406)
  %2344 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2345 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2346 = add <8 x i64> %2345, splat (i64 244)
  %2347 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2344, 0
  %2348 = insertvalue { <8 x ptr>, <8 x i64> } %2347, <8 x i64> %2346, 1
  %2349 = extractvalue { <8 x ptr>, <8 x i64> } %2348, 0
  %2350 = extractvalue { <8 x ptr>, <8 x i64> } %2348, 1
  %2351 = getelementptr i8, <8 x ptr> %2349, <8 x i64> %2350
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2351, <8 x i1> %convergence.cascade.result406)
  %2352 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2353 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2354 = add <8 x i64> %2353, splat (i64 248)
  %2355 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2352, 0
  %2356 = insertvalue { <8 x ptr>, <8 x i64> } %2355, <8 x i64> %2354, 1
  %2357 = extractvalue { <8 x ptr>, <8 x i64> } %2356, 0
  %2358 = extractvalue { <8 x ptr>, <8 x i64> } %2356, 1
  %2359 = getelementptr i8, <8 x ptr> %2357, <8 x i64> %2358
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2359, <8 x i1> %convergence.cascade.result406)
  %2360 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2361 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2362 = add <8 x i64> %2361, splat (i64 252)
  %2363 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2360, 0
  %2364 = insertvalue { <8 x ptr>, <8 x i64> } %2363, <8 x i64> %2362, 1
  %2365 = extractvalue { <8 x ptr>, <8 x i64> } %2364, 0
  %2366 = extractvalue { <8 x ptr>, <8 x i64> } %2364, 1
  %2367 = getelementptr i8, <8 x ptr> %2365, <8 x i64> %2366
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2367, <8 x i1> %convergence.cascade.result406)
  %tile_snapshot.spill.load407 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %tile_snapshot.spill.load408 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %2368 = extractelement <8 x i1> %convergence.cascade.result406, i64 0
  br i1 %2368, label %mma.active, label %mma.continue

mma.active:                                       ; preds = %convergence.target.11.ready
  %2369 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 0
  %2370 = extractelement <8 x ptr> %2369, i64 0
  %2371 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 1
  %2372 = extractelement <8 x i64> %2371, i64 0
  %2373 = getelementptr i8, ptr %2370, i64 %2372
  %2374 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 0
  %2375 = extractelement <8 x ptr> %2374, i64 0
  %2376 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 1
  %2377 = extractelement <8 x i64> %2376, i64 0
  %2378 = getelementptr i8, ptr %2375, i64 %2377
  %2379 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2380 = extractelement <8 x ptr> %2379, i64 0
  %2381 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2382 = extractelement <8 x i64> %2381, i64 0
  %2383 = getelementptr i8, ptr %2380, i64 %2382
  %2384 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2385 = extractelement <8 x ptr> %2384, i64 0
  %2386 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2387 = extractelement <8 x i64> %2386, i64 0
  %2388 = getelementptr i8, ptr %2385, i64 %2387
  call void @llm_attention.strided_mma(ptr %2373, ptr %2378, ptr %2383, ptr %2388)
  br label %mma.continue

mma.continue:                                     ; preds = %mma.active, %convergence.target.11.ready
  %2389 = extractelement <8 x i1> %convergence.cascade.result406, i64 1
  br i1 %2389, label %mma.active409, label %mma.continue410

mma.active409:                                    ; preds = %mma.continue
  %2390 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 0
  %2391 = extractelement <8 x ptr> %2390, i64 1
  %2392 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 1
  %2393 = extractelement <8 x i64> %2392, i64 1
  %2394 = getelementptr i8, ptr %2391, i64 %2393
  %2395 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 0
  %2396 = extractelement <8 x ptr> %2395, i64 1
  %2397 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 1
  %2398 = extractelement <8 x i64> %2397, i64 1
  %2399 = getelementptr i8, ptr %2396, i64 %2398
  %2400 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2401 = extractelement <8 x ptr> %2400, i64 1
  %2402 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2403 = extractelement <8 x i64> %2402, i64 1
  %2404 = getelementptr i8, ptr %2401, i64 %2403
  %2405 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2406 = extractelement <8 x ptr> %2405, i64 1
  %2407 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2408 = extractelement <8 x i64> %2407, i64 1
  %2409 = getelementptr i8, ptr %2406, i64 %2408
  call void @llm_attention.strided_mma(ptr %2394, ptr %2399, ptr %2404, ptr %2409)
  br label %mma.continue410

mma.continue410:                                  ; preds = %mma.active409, %mma.continue
  %2410 = extractelement <8 x i1> %convergence.cascade.result406, i64 2
  br i1 %2410, label %mma.active411, label %mma.continue412

mma.active411:                                    ; preds = %mma.continue410
  %2411 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 0
  %2412 = extractelement <8 x ptr> %2411, i64 2
  %2413 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 1
  %2414 = extractelement <8 x i64> %2413, i64 2
  %2415 = getelementptr i8, ptr %2412, i64 %2414
  %2416 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 0
  %2417 = extractelement <8 x ptr> %2416, i64 2
  %2418 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 1
  %2419 = extractelement <8 x i64> %2418, i64 2
  %2420 = getelementptr i8, ptr %2417, i64 %2419
  %2421 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2422 = extractelement <8 x ptr> %2421, i64 2
  %2423 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2424 = extractelement <8 x i64> %2423, i64 2
  %2425 = getelementptr i8, ptr %2422, i64 %2424
  %2426 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2427 = extractelement <8 x ptr> %2426, i64 2
  %2428 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2429 = extractelement <8 x i64> %2428, i64 2
  %2430 = getelementptr i8, ptr %2427, i64 %2429
  call void @llm_attention.strided_mma(ptr %2415, ptr %2420, ptr %2425, ptr %2430)
  br label %mma.continue412

mma.continue412:                                  ; preds = %mma.active411, %mma.continue410
  %2431 = extractelement <8 x i1> %convergence.cascade.result406, i64 3
  br i1 %2431, label %mma.active413, label %mma.continue414

mma.active413:                                    ; preds = %mma.continue412
  %2432 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 0
  %2433 = extractelement <8 x ptr> %2432, i64 3
  %2434 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 1
  %2435 = extractelement <8 x i64> %2434, i64 3
  %2436 = getelementptr i8, ptr %2433, i64 %2435
  %2437 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 0
  %2438 = extractelement <8 x ptr> %2437, i64 3
  %2439 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 1
  %2440 = extractelement <8 x i64> %2439, i64 3
  %2441 = getelementptr i8, ptr %2438, i64 %2440
  %2442 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2443 = extractelement <8 x ptr> %2442, i64 3
  %2444 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2445 = extractelement <8 x i64> %2444, i64 3
  %2446 = getelementptr i8, ptr %2443, i64 %2445
  %2447 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2448 = extractelement <8 x ptr> %2447, i64 3
  %2449 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2450 = extractelement <8 x i64> %2449, i64 3
  %2451 = getelementptr i8, ptr %2448, i64 %2450
  call void @llm_attention.strided_mma(ptr %2436, ptr %2441, ptr %2446, ptr %2451)
  br label %mma.continue414

mma.continue414:                                  ; preds = %mma.active413, %mma.continue412
  %2452 = extractelement <8 x i1> %convergence.cascade.result406, i64 4
  br i1 %2452, label %mma.active415, label %mma.continue416

mma.active415:                                    ; preds = %mma.continue414
  %2453 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 0
  %2454 = extractelement <8 x ptr> %2453, i64 4
  %2455 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 1
  %2456 = extractelement <8 x i64> %2455, i64 4
  %2457 = getelementptr i8, ptr %2454, i64 %2456
  %2458 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 0
  %2459 = extractelement <8 x ptr> %2458, i64 4
  %2460 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 1
  %2461 = extractelement <8 x i64> %2460, i64 4
  %2462 = getelementptr i8, ptr %2459, i64 %2461
  %2463 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2464 = extractelement <8 x ptr> %2463, i64 4
  %2465 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2466 = extractelement <8 x i64> %2465, i64 4
  %2467 = getelementptr i8, ptr %2464, i64 %2466
  %2468 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2469 = extractelement <8 x ptr> %2468, i64 4
  %2470 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2471 = extractelement <8 x i64> %2470, i64 4
  %2472 = getelementptr i8, ptr %2469, i64 %2471
  call void @llm_attention.strided_mma(ptr %2457, ptr %2462, ptr %2467, ptr %2472)
  br label %mma.continue416

mma.continue416:                                  ; preds = %mma.active415, %mma.continue414
  %2473 = extractelement <8 x i1> %convergence.cascade.result406, i64 5
  br i1 %2473, label %mma.active417, label %mma.continue418

mma.active417:                                    ; preds = %mma.continue416
  %2474 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 0
  %2475 = extractelement <8 x ptr> %2474, i64 5
  %2476 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 1
  %2477 = extractelement <8 x i64> %2476, i64 5
  %2478 = getelementptr i8, ptr %2475, i64 %2477
  %2479 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 0
  %2480 = extractelement <8 x ptr> %2479, i64 5
  %2481 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 1
  %2482 = extractelement <8 x i64> %2481, i64 5
  %2483 = getelementptr i8, ptr %2480, i64 %2482
  %2484 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2485 = extractelement <8 x ptr> %2484, i64 5
  %2486 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2487 = extractelement <8 x i64> %2486, i64 5
  %2488 = getelementptr i8, ptr %2485, i64 %2487
  %2489 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2490 = extractelement <8 x ptr> %2489, i64 5
  %2491 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2492 = extractelement <8 x i64> %2491, i64 5
  %2493 = getelementptr i8, ptr %2490, i64 %2492
  call void @llm_attention.strided_mma(ptr %2478, ptr %2483, ptr %2488, ptr %2493)
  br label %mma.continue418

mma.continue418:                                  ; preds = %mma.active417, %mma.continue416
  %2494 = extractelement <8 x i1> %convergence.cascade.result406, i64 6
  br i1 %2494, label %mma.active419, label %mma.continue420

mma.active419:                                    ; preds = %mma.continue418
  %2495 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 0
  %2496 = extractelement <8 x ptr> %2495, i64 6
  %2497 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 1
  %2498 = extractelement <8 x i64> %2497, i64 6
  %2499 = getelementptr i8, ptr %2496, i64 %2498
  %2500 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 0
  %2501 = extractelement <8 x ptr> %2500, i64 6
  %2502 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 1
  %2503 = extractelement <8 x i64> %2502, i64 6
  %2504 = getelementptr i8, ptr %2501, i64 %2503
  %2505 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2506 = extractelement <8 x ptr> %2505, i64 6
  %2507 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2508 = extractelement <8 x i64> %2507, i64 6
  %2509 = getelementptr i8, ptr %2506, i64 %2508
  %2510 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2511 = extractelement <8 x ptr> %2510, i64 6
  %2512 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2513 = extractelement <8 x i64> %2512, i64 6
  %2514 = getelementptr i8, ptr %2511, i64 %2513
  call void @llm_attention.strided_mma(ptr %2499, ptr %2504, ptr %2509, ptr %2514)
  br label %mma.continue420

mma.continue420:                                  ; preds = %mma.active419, %mma.continue418
  %2515 = extractelement <8 x i1> %convergence.cascade.result406, i64 7
  br i1 %2515, label %mma.active421, label %mma.continue422

mma.active421:                                    ; preds = %mma.continue420
  %2516 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 0
  %2517 = extractelement <8 x ptr> %2516, i64 7
  %2518 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 1
  %2519 = extractelement <8 x i64> %2518, i64 7
  %2520 = getelementptr i8, ptr %2517, i64 %2519
  %2521 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 0
  %2522 = extractelement <8 x ptr> %2521, i64 7
  %2523 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 1
  %2524 = extractelement <8 x i64> %2523, i64 7
  %2525 = getelementptr i8, ptr %2522, i64 %2524
  %2526 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2527 = extractelement <8 x ptr> %2526, i64 7
  %2528 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2529 = extractelement <8 x i64> %2528, i64 7
  %2530 = getelementptr i8, ptr %2527, i64 %2529
  %2531 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2532 = extractelement <8 x ptr> %2531, i64 7
  %2533 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2534 = extractelement <8 x i64> %2533, i64 7
  %2535 = getelementptr i8, ptr %2532, i64 %2534
  call void @llm_attention.strided_mma(ptr %2520, ptr %2525, ptr %2530, ptr %2535)
  br label %mma.continue422

mma.continue422:                                  ; preds = %mma.active421, %mma.continue420
  %2536 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2537 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2538 = add <8 x i64> %2537, zeroinitializer
  %2539 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2536, 0
  %2540 = insertvalue { <8 x ptr>, <8 x i64> } %2539, <8 x i64> %2538, 1
  %2541 = extractvalue { <8 x ptr>, <8 x i64> } %2540, 0
  %2542 = extractvalue { <8 x ptr>, <8 x i64> } %2540, 1
  %2543 = getelementptr i8, <8 x ptr> %2541, <8 x i64> %2542
  %2544 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2543, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2545 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2546 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2547 = add <8 x i64> %2546, splat (i64 4)
  %2548 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2545, 0
  %2549 = insertvalue { <8 x ptr>, <8 x i64> } %2548, <8 x i64> %2547, 1
  %2550 = extractvalue { <8 x ptr>, <8 x i64> } %2549, 0
  %2551 = extractvalue { <8 x ptr>, <8 x i64> } %2549, 1
  %2552 = getelementptr i8, <8 x ptr> %2550, <8 x i64> %2551
  %2553 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2552, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2554 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2555 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2556 = add <8 x i64> %2555, splat (i64 8)
  %2557 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2554, 0
  %2558 = insertvalue { <8 x ptr>, <8 x i64> } %2557, <8 x i64> %2556, 1
  %2559 = extractvalue { <8 x ptr>, <8 x i64> } %2558, 0
  %2560 = extractvalue { <8 x ptr>, <8 x i64> } %2558, 1
  %2561 = getelementptr i8, <8 x ptr> %2559, <8 x i64> %2560
  %2562 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2561, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2563 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2564 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2565 = add <8 x i64> %2564, splat (i64 12)
  %2566 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2563, 0
  %2567 = insertvalue { <8 x ptr>, <8 x i64> } %2566, <8 x i64> %2565, 1
  %2568 = extractvalue { <8 x ptr>, <8 x i64> } %2567, 0
  %2569 = extractvalue { <8 x ptr>, <8 x i64> } %2567, 1
  %2570 = getelementptr i8, <8 x ptr> %2568, <8 x i64> %2569
  %2571 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2570, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2572 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2573 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2574 = add <8 x i64> %2573, splat (i64 16)
  %2575 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2572, 0
  %2576 = insertvalue { <8 x ptr>, <8 x i64> } %2575, <8 x i64> %2574, 1
  %2577 = extractvalue { <8 x ptr>, <8 x i64> } %2576, 0
  %2578 = extractvalue { <8 x ptr>, <8 x i64> } %2576, 1
  %2579 = getelementptr i8, <8 x ptr> %2577, <8 x i64> %2578
  %2580 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2579, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2581 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2582 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2583 = add <8 x i64> %2582, splat (i64 20)
  %2584 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2581, 0
  %2585 = insertvalue { <8 x ptr>, <8 x i64> } %2584, <8 x i64> %2583, 1
  %2586 = extractvalue { <8 x ptr>, <8 x i64> } %2585, 0
  %2587 = extractvalue { <8 x ptr>, <8 x i64> } %2585, 1
  %2588 = getelementptr i8, <8 x ptr> %2586, <8 x i64> %2587
  %2589 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2588, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2590 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2591 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2592 = add <8 x i64> %2591, splat (i64 24)
  %2593 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2590, 0
  %2594 = insertvalue { <8 x ptr>, <8 x i64> } %2593, <8 x i64> %2592, 1
  %2595 = extractvalue { <8 x ptr>, <8 x i64> } %2594, 0
  %2596 = extractvalue { <8 x ptr>, <8 x i64> } %2594, 1
  %2597 = getelementptr i8, <8 x ptr> %2595, <8 x i64> %2596
  %2598 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2597, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2599 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2600 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2601 = add <8 x i64> %2600, splat (i64 28)
  %2602 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2599, 0
  %2603 = insertvalue { <8 x ptr>, <8 x i64> } %2602, <8 x i64> %2601, 1
  %2604 = extractvalue { <8 x ptr>, <8 x i64> } %2603, 0
  %2605 = extractvalue { <8 x ptr>, <8 x i64> } %2603, 1
  %2606 = getelementptr i8, <8 x ptr> %2604, <8 x i64> %2605
  %2607 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2606, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2608 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2609 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2610 = add <8 x i64> %2609, splat (i64 32)
  %2611 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2608, 0
  %2612 = insertvalue { <8 x ptr>, <8 x i64> } %2611, <8 x i64> %2610, 1
  %2613 = extractvalue { <8 x ptr>, <8 x i64> } %2612, 0
  %2614 = extractvalue { <8 x ptr>, <8 x i64> } %2612, 1
  %2615 = getelementptr i8, <8 x ptr> %2613, <8 x i64> %2614
  %2616 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2615, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2617 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2618 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2619 = add <8 x i64> %2618, splat (i64 36)
  %2620 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2617, 0
  %2621 = insertvalue { <8 x ptr>, <8 x i64> } %2620, <8 x i64> %2619, 1
  %2622 = extractvalue { <8 x ptr>, <8 x i64> } %2621, 0
  %2623 = extractvalue { <8 x ptr>, <8 x i64> } %2621, 1
  %2624 = getelementptr i8, <8 x ptr> %2622, <8 x i64> %2623
  %2625 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2624, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2626 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2627 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2628 = add <8 x i64> %2627, splat (i64 40)
  %2629 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2626, 0
  %2630 = insertvalue { <8 x ptr>, <8 x i64> } %2629, <8 x i64> %2628, 1
  %2631 = extractvalue { <8 x ptr>, <8 x i64> } %2630, 0
  %2632 = extractvalue { <8 x ptr>, <8 x i64> } %2630, 1
  %2633 = getelementptr i8, <8 x ptr> %2631, <8 x i64> %2632
  %2634 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2633, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2635 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2636 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2637 = add <8 x i64> %2636, splat (i64 44)
  %2638 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2635, 0
  %2639 = insertvalue { <8 x ptr>, <8 x i64> } %2638, <8 x i64> %2637, 1
  %2640 = extractvalue { <8 x ptr>, <8 x i64> } %2639, 0
  %2641 = extractvalue { <8 x ptr>, <8 x i64> } %2639, 1
  %2642 = getelementptr i8, <8 x ptr> %2640, <8 x i64> %2641
  %2643 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2642, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2644 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2645 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2646 = add <8 x i64> %2645, splat (i64 48)
  %2647 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2644, 0
  %2648 = insertvalue { <8 x ptr>, <8 x i64> } %2647, <8 x i64> %2646, 1
  %2649 = extractvalue { <8 x ptr>, <8 x i64> } %2648, 0
  %2650 = extractvalue { <8 x ptr>, <8 x i64> } %2648, 1
  %2651 = getelementptr i8, <8 x ptr> %2649, <8 x i64> %2650
  %2652 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2651, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2653 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2654 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2655 = add <8 x i64> %2654, splat (i64 52)
  %2656 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2653, 0
  %2657 = insertvalue { <8 x ptr>, <8 x i64> } %2656, <8 x i64> %2655, 1
  %2658 = extractvalue { <8 x ptr>, <8 x i64> } %2657, 0
  %2659 = extractvalue { <8 x ptr>, <8 x i64> } %2657, 1
  %2660 = getelementptr i8, <8 x ptr> %2658, <8 x i64> %2659
  %2661 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2660, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2662 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2663 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2664 = add <8 x i64> %2663, splat (i64 56)
  %2665 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2662, 0
  %2666 = insertvalue { <8 x ptr>, <8 x i64> } %2665, <8 x i64> %2664, 1
  %2667 = extractvalue { <8 x ptr>, <8 x i64> } %2666, 0
  %2668 = extractvalue { <8 x ptr>, <8 x i64> } %2666, 1
  %2669 = getelementptr i8, <8 x ptr> %2667, <8 x i64> %2668
  %2670 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2669, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2671 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2672 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2673 = add <8 x i64> %2672, splat (i64 60)
  %2674 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2671, 0
  %2675 = insertvalue { <8 x ptr>, <8 x i64> } %2674, <8 x i64> %2673, 1
  %2676 = extractvalue { <8 x ptr>, <8 x i64> } %2675, 0
  %2677 = extractvalue { <8 x ptr>, <8 x i64> } %2675, 1
  %2678 = getelementptr i8, <8 x ptr> %2676, <8 x i64> %2677
  %2679 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2678, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2680 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2681 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2682 = add <8 x i64> %2681, splat (i64 64)
  %2683 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2680, 0
  %2684 = insertvalue { <8 x ptr>, <8 x i64> } %2683, <8 x i64> %2682, 1
  %2685 = extractvalue { <8 x ptr>, <8 x i64> } %2684, 0
  %2686 = extractvalue { <8 x ptr>, <8 x i64> } %2684, 1
  %2687 = getelementptr i8, <8 x ptr> %2685, <8 x i64> %2686
  %2688 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2687, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2689 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2690 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2691 = add <8 x i64> %2690, splat (i64 68)
  %2692 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2689, 0
  %2693 = insertvalue { <8 x ptr>, <8 x i64> } %2692, <8 x i64> %2691, 1
  %2694 = extractvalue { <8 x ptr>, <8 x i64> } %2693, 0
  %2695 = extractvalue { <8 x ptr>, <8 x i64> } %2693, 1
  %2696 = getelementptr i8, <8 x ptr> %2694, <8 x i64> %2695
  %2697 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2696, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2698 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2699 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2700 = add <8 x i64> %2699, splat (i64 72)
  %2701 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2698, 0
  %2702 = insertvalue { <8 x ptr>, <8 x i64> } %2701, <8 x i64> %2700, 1
  %2703 = extractvalue { <8 x ptr>, <8 x i64> } %2702, 0
  %2704 = extractvalue { <8 x ptr>, <8 x i64> } %2702, 1
  %2705 = getelementptr i8, <8 x ptr> %2703, <8 x i64> %2704
  %2706 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2705, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2707 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2708 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2709 = add <8 x i64> %2708, splat (i64 76)
  %2710 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2707, 0
  %2711 = insertvalue { <8 x ptr>, <8 x i64> } %2710, <8 x i64> %2709, 1
  %2712 = extractvalue { <8 x ptr>, <8 x i64> } %2711, 0
  %2713 = extractvalue { <8 x ptr>, <8 x i64> } %2711, 1
  %2714 = getelementptr i8, <8 x ptr> %2712, <8 x i64> %2713
  %2715 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2714, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2716 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2717 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2718 = add <8 x i64> %2717, splat (i64 80)
  %2719 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2716, 0
  %2720 = insertvalue { <8 x ptr>, <8 x i64> } %2719, <8 x i64> %2718, 1
  %2721 = extractvalue { <8 x ptr>, <8 x i64> } %2720, 0
  %2722 = extractvalue { <8 x ptr>, <8 x i64> } %2720, 1
  %2723 = getelementptr i8, <8 x ptr> %2721, <8 x i64> %2722
  %2724 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2723, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2725 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2726 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2727 = add <8 x i64> %2726, splat (i64 84)
  %2728 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2725, 0
  %2729 = insertvalue { <8 x ptr>, <8 x i64> } %2728, <8 x i64> %2727, 1
  %2730 = extractvalue { <8 x ptr>, <8 x i64> } %2729, 0
  %2731 = extractvalue { <8 x ptr>, <8 x i64> } %2729, 1
  %2732 = getelementptr i8, <8 x ptr> %2730, <8 x i64> %2731
  %2733 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2732, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2734 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2735 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2736 = add <8 x i64> %2735, splat (i64 88)
  %2737 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2734, 0
  %2738 = insertvalue { <8 x ptr>, <8 x i64> } %2737, <8 x i64> %2736, 1
  %2739 = extractvalue { <8 x ptr>, <8 x i64> } %2738, 0
  %2740 = extractvalue { <8 x ptr>, <8 x i64> } %2738, 1
  %2741 = getelementptr i8, <8 x ptr> %2739, <8 x i64> %2740
  %2742 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2741, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2743 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2744 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2745 = add <8 x i64> %2744, splat (i64 92)
  %2746 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2743, 0
  %2747 = insertvalue { <8 x ptr>, <8 x i64> } %2746, <8 x i64> %2745, 1
  %2748 = extractvalue { <8 x ptr>, <8 x i64> } %2747, 0
  %2749 = extractvalue { <8 x ptr>, <8 x i64> } %2747, 1
  %2750 = getelementptr i8, <8 x ptr> %2748, <8 x i64> %2749
  %2751 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2750, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2752 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2753 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2754 = add <8 x i64> %2753, splat (i64 96)
  %2755 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2752, 0
  %2756 = insertvalue { <8 x ptr>, <8 x i64> } %2755, <8 x i64> %2754, 1
  %2757 = extractvalue { <8 x ptr>, <8 x i64> } %2756, 0
  %2758 = extractvalue { <8 x ptr>, <8 x i64> } %2756, 1
  %2759 = getelementptr i8, <8 x ptr> %2757, <8 x i64> %2758
  %2760 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2759, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2761 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2762 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2763 = add <8 x i64> %2762, splat (i64 100)
  %2764 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2761, 0
  %2765 = insertvalue { <8 x ptr>, <8 x i64> } %2764, <8 x i64> %2763, 1
  %2766 = extractvalue { <8 x ptr>, <8 x i64> } %2765, 0
  %2767 = extractvalue { <8 x ptr>, <8 x i64> } %2765, 1
  %2768 = getelementptr i8, <8 x ptr> %2766, <8 x i64> %2767
  %2769 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2768, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2770 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2771 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2772 = add <8 x i64> %2771, splat (i64 104)
  %2773 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2770, 0
  %2774 = insertvalue { <8 x ptr>, <8 x i64> } %2773, <8 x i64> %2772, 1
  %2775 = extractvalue { <8 x ptr>, <8 x i64> } %2774, 0
  %2776 = extractvalue { <8 x ptr>, <8 x i64> } %2774, 1
  %2777 = getelementptr i8, <8 x ptr> %2775, <8 x i64> %2776
  %2778 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2777, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2779 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2780 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2781 = add <8 x i64> %2780, splat (i64 108)
  %2782 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2779, 0
  %2783 = insertvalue { <8 x ptr>, <8 x i64> } %2782, <8 x i64> %2781, 1
  %2784 = extractvalue { <8 x ptr>, <8 x i64> } %2783, 0
  %2785 = extractvalue { <8 x ptr>, <8 x i64> } %2783, 1
  %2786 = getelementptr i8, <8 x ptr> %2784, <8 x i64> %2785
  %2787 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2786, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2788 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2789 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2790 = add <8 x i64> %2789, splat (i64 112)
  %2791 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2788, 0
  %2792 = insertvalue { <8 x ptr>, <8 x i64> } %2791, <8 x i64> %2790, 1
  %2793 = extractvalue { <8 x ptr>, <8 x i64> } %2792, 0
  %2794 = extractvalue { <8 x ptr>, <8 x i64> } %2792, 1
  %2795 = getelementptr i8, <8 x ptr> %2793, <8 x i64> %2794
  %2796 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2795, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2797 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2798 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2799 = add <8 x i64> %2798, splat (i64 116)
  %2800 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2797, 0
  %2801 = insertvalue { <8 x ptr>, <8 x i64> } %2800, <8 x i64> %2799, 1
  %2802 = extractvalue { <8 x ptr>, <8 x i64> } %2801, 0
  %2803 = extractvalue { <8 x ptr>, <8 x i64> } %2801, 1
  %2804 = getelementptr i8, <8 x ptr> %2802, <8 x i64> %2803
  %2805 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2804, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2806 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2807 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2808 = add <8 x i64> %2807, splat (i64 120)
  %2809 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2806, 0
  %2810 = insertvalue { <8 x ptr>, <8 x i64> } %2809, <8 x i64> %2808, 1
  %2811 = extractvalue { <8 x ptr>, <8 x i64> } %2810, 0
  %2812 = extractvalue { <8 x ptr>, <8 x i64> } %2810, 1
  %2813 = getelementptr i8, <8 x ptr> %2811, <8 x i64> %2812
  %2814 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2813, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2815 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2816 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2817 = add <8 x i64> %2816, splat (i64 124)
  %2818 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2815, 0
  %2819 = insertvalue { <8 x ptr>, <8 x i64> } %2818, <8 x i64> %2817, 1
  %2820 = extractvalue { <8 x ptr>, <8 x i64> } %2819, 0
  %2821 = extractvalue { <8 x ptr>, <8 x i64> } %2819, 1
  %2822 = getelementptr i8, <8 x ptr> %2820, <8 x i64> %2821
  %2823 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2822, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2824 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2825 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2826 = add <8 x i64> %2825, splat (i64 128)
  %2827 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2824, 0
  %2828 = insertvalue { <8 x ptr>, <8 x i64> } %2827, <8 x i64> %2826, 1
  %2829 = extractvalue { <8 x ptr>, <8 x i64> } %2828, 0
  %2830 = extractvalue { <8 x ptr>, <8 x i64> } %2828, 1
  %2831 = getelementptr i8, <8 x ptr> %2829, <8 x i64> %2830
  %2832 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2831, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2833 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2834 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2835 = add <8 x i64> %2834, splat (i64 132)
  %2836 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2833, 0
  %2837 = insertvalue { <8 x ptr>, <8 x i64> } %2836, <8 x i64> %2835, 1
  %2838 = extractvalue { <8 x ptr>, <8 x i64> } %2837, 0
  %2839 = extractvalue { <8 x ptr>, <8 x i64> } %2837, 1
  %2840 = getelementptr i8, <8 x ptr> %2838, <8 x i64> %2839
  %2841 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2840, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2842 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2843 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2844 = add <8 x i64> %2843, splat (i64 136)
  %2845 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2842, 0
  %2846 = insertvalue { <8 x ptr>, <8 x i64> } %2845, <8 x i64> %2844, 1
  %2847 = extractvalue { <8 x ptr>, <8 x i64> } %2846, 0
  %2848 = extractvalue { <8 x ptr>, <8 x i64> } %2846, 1
  %2849 = getelementptr i8, <8 x ptr> %2847, <8 x i64> %2848
  %2850 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2849, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2851 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2852 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2853 = add <8 x i64> %2852, splat (i64 140)
  %2854 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2851, 0
  %2855 = insertvalue { <8 x ptr>, <8 x i64> } %2854, <8 x i64> %2853, 1
  %2856 = extractvalue { <8 x ptr>, <8 x i64> } %2855, 0
  %2857 = extractvalue { <8 x ptr>, <8 x i64> } %2855, 1
  %2858 = getelementptr i8, <8 x ptr> %2856, <8 x i64> %2857
  %2859 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2858, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2860 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2861 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2862 = add <8 x i64> %2861, splat (i64 144)
  %2863 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2860, 0
  %2864 = insertvalue { <8 x ptr>, <8 x i64> } %2863, <8 x i64> %2862, 1
  %2865 = extractvalue { <8 x ptr>, <8 x i64> } %2864, 0
  %2866 = extractvalue { <8 x ptr>, <8 x i64> } %2864, 1
  %2867 = getelementptr i8, <8 x ptr> %2865, <8 x i64> %2866
  %2868 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2867, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2869 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2870 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2871 = add <8 x i64> %2870, splat (i64 148)
  %2872 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2869, 0
  %2873 = insertvalue { <8 x ptr>, <8 x i64> } %2872, <8 x i64> %2871, 1
  %2874 = extractvalue { <8 x ptr>, <8 x i64> } %2873, 0
  %2875 = extractvalue { <8 x ptr>, <8 x i64> } %2873, 1
  %2876 = getelementptr i8, <8 x ptr> %2874, <8 x i64> %2875
  %2877 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2876, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2878 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2879 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2880 = add <8 x i64> %2879, splat (i64 152)
  %2881 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2878, 0
  %2882 = insertvalue { <8 x ptr>, <8 x i64> } %2881, <8 x i64> %2880, 1
  %2883 = extractvalue { <8 x ptr>, <8 x i64> } %2882, 0
  %2884 = extractvalue { <8 x ptr>, <8 x i64> } %2882, 1
  %2885 = getelementptr i8, <8 x ptr> %2883, <8 x i64> %2884
  %2886 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2885, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2887 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2888 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2889 = add <8 x i64> %2888, splat (i64 156)
  %2890 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2887, 0
  %2891 = insertvalue { <8 x ptr>, <8 x i64> } %2890, <8 x i64> %2889, 1
  %2892 = extractvalue { <8 x ptr>, <8 x i64> } %2891, 0
  %2893 = extractvalue { <8 x ptr>, <8 x i64> } %2891, 1
  %2894 = getelementptr i8, <8 x ptr> %2892, <8 x i64> %2893
  %2895 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2894, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2896 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2897 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2898 = add <8 x i64> %2897, splat (i64 160)
  %2899 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2896, 0
  %2900 = insertvalue { <8 x ptr>, <8 x i64> } %2899, <8 x i64> %2898, 1
  %2901 = extractvalue { <8 x ptr>, <8 x i64> } %2900, 0
  %2902 = extractvalue { <8 x ptr>, <8 x i64> } %2900, 1
  %2903 = getelementptr i8, <8 x ptr> %2901, <8 x i64> %2902
  %2904 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2903, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2905 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2906 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2907 = add <8 x i64> %2906, splat (i64 164)
  %2908 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2905, 0
  %2909 = insertvalue { <8 x ptr>, <8 x i64> } %2908, <8 x i64> %2907, 1
  %2910 = extractvalue { <8 x ptr>, <8 x i64> } %2909, 0
  %2911 = extractvalue { <8 x ptr>, <8 x i64> } %2909, 1
  %2912 = getelementptr i8, <8 x ptr> %2910, <8 x i64> %2911
  %2913 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2912, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2914 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2915 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2916 = add <8 x i64> %2915, splat (i64 168)
  %2917 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2914, 0
  %2918 = insertvalue { <8 x ptr>, <8 x i64> } %2917, <8 x i64> %2916, 1
  %2919 = extractvalue { <8 x ptr>, <8 x i64> } %2918, 0
  %2920 = extractvalue { <8 x ptr>, <8 x i64> } %2918, 1
  %2921 = getelementptr i8, <8 x ptr> %2919, <8 x i64> %2920
  %2922 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2921, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2923 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2924 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2925 = add <8 x i64> %2924, splat (i64 172)
  %2926 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2923, 0
  %2927 = insertvalue { <8 x ptr>, <8 x i64> } %2926, <8 x i64> %2925, 1
  %2928 = extractvalue { <8 x ptr>, <8 x i64> } %2927, 0
  %2929 = extractvalue { <8 x ptr>, <8 x i64> } %2927, 1
  %2930 = getelementptr i8, <8 x ptr> %2928, <8 x i64> %2929
  %2931 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2930, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2932 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2933 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2934 = add <8 x i64> %2933, splat (i64 176)
  %2935 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2932, 0
  %2936 = insertvalue { <8 x ptr>, <8 x i64> } %2935, <8 x i64> %2934, 1
  %2937 = extractvalue { <8 x ptr>, <8 x i64> } %2936, 0
  %2938 = extractvalue { <8 x ptr>, <8 x i64> } %2936, 1
  %2939 = getelementptr i8, <8 x ptr> %2937, <8 x i64> %2938
  %2940 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2939, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2941 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2942 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2943 = add <8 x i64> %2942, splat (i64 180)
  %2944 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2941, 0
  %2945 = insertvalue { <8 x ptr>, <8 x i64> } %2944, <8 x i64> %2943, 1
  %2946 = extractvalue { <8 x ptr>, <8 x i64> } %2945, 0
  %2947 = extractvalue { <8 x ptr>, <8 x i64> } %2945, 1
  %2948 = getelementptr i8, <8 x ptr> %2946, <8 x i64> %2947
  %2949 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2948, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2950 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2951 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2952 = add <8 x i64> %2951, splat (i64 184)
  %2953 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2950, 0
  %2954 = insertvalue { <8 x ptr>, <8 x i64> } %2953, <8 x i64> %2952, 1
  %2955 = extractvalue { <8 x ptr>, <8 x i64> } %2954, 0
  %2956 = extractvalue { <8 x ptr>, <8 x i64> } %2954, 1
  %2957 = getelementptr i8, <8 x ptr> %2955, <8 x i64> %2956
  %2958 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2957, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2959 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2960 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2961 = add <8 x i64> %2960, splat (i64 188)
  %2962 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2959, 0
  %2963 = insertvalue { <8 x ptr>, <8 x i64> } %2962, <8 x i64> %2961, 1
  %2964 = extractvalue { <8 x ptr>, <8 x i64> } %2963, 0
  %2965 = extractvalue { <8 x ptr>, <8 x i64> } %2963, 1
  %2966 = getelementptr i8, <8 x ptr> %2964, <8 x i64> %2965
  %2967 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2966, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2968 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2969 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2970 = add <8 x i64> %2969, splat (i64 192)
  %2971 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2968, 0
  %2972 = insertvalue { <8 x ptr>, <8 x i64> } %2971, <8 x i64> %2970, 1
  %2973 = extractvalue { <8 x ptr>, <8 x i64> } %2972, 0
  %2974 = extractvalue { <8 x ptr>, <8 x i64> } %2972, 1
  %2975 = getelementptr i8, <8 x ptr> %2973, <8 x i64> %2974
  %2976 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2975, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2977 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2978 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2979 = add <8 x i64> %2978, splat (i64 196)
  %2980 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2977, 0
  %2981 = insertvalue { <8 x ptr>, <8 x i64> } %2980, <8 x i64> %2979, 1
  %2982 = extractvalue { <8 x ptr>, <8 x i64> } %2981, 0
  %2983 = extractvalue { <8 x ptr>, <8 x i64> } %2981, 1
  %2984 = getelementptr i8, <8 x ptr> %2982, <8 x i64> %2983
  %2985 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2984, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2986 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2987 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2988 = add <8 x i64> %2987, splat (i64 200)
  %2989 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2986, 0
  %2990 = insertvalue { <8 x ptr>, <8 x i64> } %2989, <8 x i64> %2988, 1
  %2991 = extractvalue { <8 x ptr>, <8 x i64> } %2990, 0
  %2992 = extractvalue { <8 x ptr>, <8 x i64> } %2990, 1
  %2993 = getelementptr i8, <8 x ptr> %2991, <8 x i64> %2992
  %2994 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2993, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %2995 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2996 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2997 = add <8 x i64> %2996, splat (i64 204)
  %2998 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2995, 0
  %2999 = insertvalue { <8 x ptr>, <8 x i64> } %2998, <8 x i64> %2997, 1
  %3000 = extractvalue { <8 x ptr>, <8 x i64> } %2999, 0
  %3001 = extractvalue { <8 x ptr>, <8 x i64> } %2999, 1
  %3002 = getelementptr i8, <8 x ptr> %3000, <8 x i64> %3001
  %3003 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3002, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %3004 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3005 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3006 = add <8 x i64> %3005, splat (i64 208)
  %3007 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3004, 0
  %3008 = insertvalue { <8 x ptr>, <8 x i64> } %3007, <8 x i64> %3006, 1
  %3009 = extractvalue { <8 x ptr>, <8 x i64> } %3008, 0
  %3010 = extractvalue { <8 x ptr>, <8 x i64> } %3008, 1
  %3011 = getelementptr i8, <8 x ptr> %3009, <8 x i64> %3010
  %3012 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3011, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %3013 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3014 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3015 = add <8 x i64> %3014, splat (i64 212)
  %3016 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3013, 0
  %3017 = insertvalue { <8 x ptr>, <8 x i64> } %3016, <8 x i64> %3015, 1
  %3018 = extractvalue { <8 x ptr>, <8 x i64> } %3017, 0
  %3019 = extractvalue { <8 x ptr>, <8 x i64> } %3017, 1
  %3020 = getelementptr i8, <8 x ptr> %3018, <8 x i64> %3019
  %3021 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3020, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %3022 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3023 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3024 = add <8 x i64> %3023, splat (i64 216)
  %3025 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3022, 0
  %3026 = insertvalue { <8 x ptr>, <8 x i64> } %3025, <8 x i64> %3024, 1
  %3027 = extractvalue { <8 x ptr>, <8 x i64> } %3026, 0
  %3028 = extractvalue { <8 x ptr>, <8 x i64> } %3026, 1
  %3029 = getelementptr i8, <8 x ptr> %3027, <8 x i64> %3028
  %3030 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3029, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %3031 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3032 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3033 = add <8 x i64> %3032, splat (i64 220)
  %3034 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3031, 0
  %3035 = insertvalue { <8 x ptr>, <8 x i64> } %3034, <8 x i64> %3033, 1
  %3036 = extractvalue { <8 x ptr>, <8 x i64> } %3035, 0
  %3037 = extractvalue { <8 x ptr>, <8 x i64> } %3035, 1
  %3038 = getelementptr i8, <8 x ptr> %3036, <8 x i64> %3037
  %3039 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3038, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %3040 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3041 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3042 = add <8 x i64> %3041, splat (i64 224)
  %3043 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3040, 0
  %3044 = insertvalue { <8 x ptr>, <8 x i64> } %3043, <8 x i64> %3042, 1
  %3045 = extractvalue { <8 x ptr>, <8 x i64> } %3044, 0
  %3046 = extractvalue { <8 x ptr>, <8 x i64> } %3044, 1
  %3047 = getelementptr i8, <8 x ptr> %3045, <8 x i64> %3046
  %3048 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3047, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %3049 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3050 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3051 = add <8 x i64> %3050, splat (i64 228)
  %3052 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3049, 0
  %3053 = insertvalue { <8 x ptr>, <8 x i64> } %3052, <8 x i64> %3051, 1
  %3054 = extractvalue { <8 x ptr>, <8 x i64> } %3053, 0
  %3055 = extractvalue { <8 x ptr>, <8 x i64> } %3053, 1
  %3056 = getelementptr i8, <8 x ptr> %3054, <8 x i64> %3055
  %3057 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3056, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %3058 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3059 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3060 = add <8 x i64> %3059, splat (i64 232)
  %3061 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3058, 0
  %3062 = insertvalue { <8 x ptr>, <8 x i64> } %3061, <8 x i64> %3060, 1
  %3063 = extractvalue { <8 x ptr>, <8 x i64> } %3062, 0
  %3064 = extractvalue { <8 x ptr>, <8 x i64> } %3062, 1
  %3065 = getelementptr i8, <8 x ptr> %3063, <8 x i64> %3064
  %3066 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3065, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %3067 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3068 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3069 = add <8 x i64> %3068, splat (i64 236)
  %3070 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3067, 0
  %3071 = insertvalue { <8 x ptr>, <8 x i64> } %3070, <8 x i64> %3069, 1
  %3072 = extractvalue { <8 x ptr>, <8 x i64> } %3071, 0
  %3073 = extractvalue { <8 x ptr>, <8 x i64> } %3071, 1
  %3074 = getelementptr i8, <8 x ptr> %3072, <8 x i64> %3073
  %3075 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3074, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %3076 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3077 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3078 = add <8 x i64> %3077, splat (i64 240)
  %3079 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3076, 0
  %3080 = insertvalue { <8 x ptr>, <8 x i64> } %3079, <8 x i64> %3078, 1
  %3081 = extractvalue { <8 x ptr>, <8 x i64> } %3080, 0
  %3082 = extractvalue { <8 x ptr>, <8 x i64> } %3080, 1
  %3083 = getelementptr i8, <8 x ptr> %3081, <8 x i64> %3082
  %3084 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3083, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %3085 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3086 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3087 = add <8 x i64> %3086, splat (i64 244)
  %3088 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3085, 0
  %3089 = insertvalue { <8 x ptr>, <8 x i64> } %3088, <8 x i64> %3087, 1
  %3090 = extractvalue { <8 x ptr>, <8 x i64> } %3089, 0
  %3091 = extractvalue { <8 x ptr>, <8 x i64> } %3089, 1
  %3092 = getelementptr i8, <8 x ptr> %3090, <8 x i64> %3091
  %3093 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3092, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %3094 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3095 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3096 = add <8 x i64> %3095, splat (i64 248)
  %3097 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3094, 0
  %3098 = insertvalue { <8 x ptr>, <8 x i64> } %3097, <8 x i64> %3096, 1
  %3099 = extractvalue { <8 x ptr>, <8 x i64> } %3098, 0
  %3100 = extractvalue { <8 x ptr>, <8 x i64> } %3098, 1
  %3101 = getelementptr i8, <8 x ptr> %3099, <8 x i64> %3100
  %3102 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3101, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %3103 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3104 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3105 = add <8 x i64> %3104, splat (i64 252)
  %3106 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3103, 0
  %3107 = insertvalue { <8 x ptr>, <8 x i64> } %3106, <8 x i64> %3105, 1
  %3108 = extractvalue { <8 x ptr>, <8 x i64> } %3107, 0
  %3109 = extractvalue { <8 x ptr>, <8 x i64> } %3107, 1
  %3110 = getelementptr i8, <8 x ptr> %3108, <8 x i64> %3109
  %3111 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3110, <8 x i1> %convergence.cascade.result406, <8 x float> zeroinitializer)
  %3112 = fmul <8 x float> %2544, splat (float 0x3FC43D1360000000)
  %3113 = fmul <8 x float> %2553, splat (float 0x3FC43D1360000000)
  %3114 = fmul <8 x float> %2562, splat (float 0x3FC43D1360000000)
  %3115 = fmul <8 x float> %2571, splat (float 0x3FC43D1360000000)
  %3116 = fmul <8 x float> %2580, splat (float 0x3FC43D1360000000)
  %3117 = fmul <8 x float> %2589, splat (float 0x3FC43D1360000000)
  %3118 = fmul <8 x float> %2598, splat (float 0x3FC43D1360000000)
  %3119 = fmul <8 x float> %2607, splat (float 0x3FC43D1360000000)
  %3120 = fmul <8 x float> %2616, splat (float 0x3FC43D1360000000)
  %3121 = fmul <8 x float> %2625, splat (float 0x3FC43D1360000000)
  %3122 = fmul <8 x float> %2634, splat (float 0x3FC43D1360000000)
  %3123 = fmul <8 x float> %2643, splat (float 0x3FC43D1360000000)
  %3124 = fmul <8 x float> %2652, splat (float 0x3FC43D1360000000)
  %3125 = fmul <8 x float> %2661, splat (float 0x3FC43D1360000000)
  %3126 = fmul <8 x float> %2670, splat (float 0x3FC43D1360000000)
  %3127 = fmul <8 x float> %2679, splat (float 0x3FC43D1360000000)
  %3128 = fmul <8 x float> %2688, splat (float 0x3FC43D1360000000)
  %3129 = fmul <8 x float> %2697, splat (float 0x3FC43D1360000000)
  %3130 = fmul <8 x float> %2706, splat (float 0x3FC43D1360000000)
  %3131 = fmul <8 x float> %2715, splat (float 0x3FC43D1360000000)
  %3132 = fmul <8 x float> %2724, splat (float 0x3FC43D1360000000)
  %3133 = fmul <8 x float> %2733, splat (float 0x3FC43D1360000000)
  %3134 = fmul <8 x float> %2742, splat (float 0x3FC43D1360000000)
  %3135 = fmul <8 x float> %2751, splat (float 0x3FC43D1360000000)
  %3136 = fmul <8 x float> %2760, splat (float 0x3FC43D1360000000)
  %3137 = fmul <8 x float> %2769, splat (float 0x3FC43D1360000000)
  %3138 = fmul <8 x float> %2778, splat (float 0x3FC43D1360000000)
  %3139 = fmul <8 x float> %2787, splat (float 0x3FC43D1360000000)
  %3140 = fmul <8 x float> %2796, splat (float 0x3FC43D1360000000)
  %3141 = fmul <8 x float> %2805, splat (float 0x3FC43D1360000000)
  %3142 = fmul <8 x float> %2814, splat (float 0x3FC43D1360000000)
  %3143 = fmul <8 x float> %2823, splat (float 0x3FC43D1360000000)
  %3144 = fmul <8 x float> %2832, splat (float 0x3FC43D1360000000)
  %3145 = fmul <8 x float> %2841, splat (float 0x3FC43D1360000000)
  %3146 = fmul <8 x float> %2850, splat (float 0x3FC43D1360000000)
  %3147 = fmul <8 x float> %2859, splat (float 0x3FC43D1360000000)
  %3148 = fmul <8 x float> %2868, splat (float 0x3FC43D1360000000)
  %3149 = fmul <8 x float> %2877, splat (float 0x3FC43D1360000000)
  %3150 = fmul <8 x float> %2886, splat (float 0x3FC43D1360000000)
  %3151 = fmul <8 x float> %2895, splat (float 0x3FC43D1360000000)
  %3152 = fmul <8 x float> %2904, splat (float 0x3FC43D1360000000)
  %3153 = fmul <8 x float> %2913, splat (float 0x3FC43D1360000000)
  %3154 = fmul <8 x float> %2922, splat (float 0x3FC43D1360000000)
  %3155 = fmul <8 x float> %2931, splat (float 0x3FC43D1360000000)
  %3156 = fmul <8 x float> %2940, splat (float 0x3FC43D1360000000)
  %3157 = fmul <8 x float> %2949, splat (float 0x3FC43D1360000000)
  %3158 = fmul <8 x float> %2958, splat (float 0x3FC43D1360000000)
  %3159 = fmul <8 x float> %2967, splat (float 0x3FC43D1360000000)
  %3160 = fmul <8 x float> %2976, splat (float 0x3FC43D1360000000)
  %3161 = fmul <8 x float> %2985, splat (float 0x3FC43D1360000000)
  %3162 = fmul <8 x float> %2994, splat (float 0x3FC43D1360000000)
  %3163 = fmul <8 x float> %3003, splat (float 0x3FC43D1360000000)
  %3164 = fmul <8 x float> %3012, splat (float 0x3FC43D1360000000)
  %3165 = fmul <8 x float> %3021, splat (float 0x3FC43D1360000000)
  %3166 = fmul <8 x float> %3030, splat (float 0x3FC43D1360000000)
  %3167 = fmul <8 x float> %3039, splat (float 0x3FC43D1360000000)
  %3168 = fmul <8 x float> %3048, splat (float 0x3FC43D1360000000)
  %3169 = fmul <8 x float> %3057, splat (float 0x3FC43D1360000000)
  %3170 = fmul <8 x float> %3066, splat (float 0x3FC43D1360000000)
  %3171 = fmul <8 x float> %3075, splat (float 0x3FC43D1360000000)
  %3172 = fmul <8 x float> %3084, splat (float 0x3FC43D1360000000)
  %3173 = fmul <8 x float> %3093, splat (float 0x3FC43D1360000000)
  %3174 = fmul <8 x float> %3102, splat (float 0x3FC43D1360000000)
  %3175 = fmul <8 x float> %3111, splat (float 0x3FC43D1360000000)
  %.spill.load423 = load <8 x i64>, ptr %.spill63, align 64
  %3176 = add <8 x i64> zeroinitializer, %.spill.load423
  %.spill.load424 = load <8 x i64>, ptr %.spill63, align 64
  %3177 = add <8 x i64> splat (i64 1), %.spill.load424
  %.spill.load425 = load <8 x i64>, ptr %.spill63, align 64
  %3178 = add <8 x i64> splat (i64 2), %.spill.load425
  %.spill.load426 = load <8 x i64>, ptr %.spill63, align 64
  %3179 = add <8 x i64> splat (i64 3), %.spill.load426
  %.spill.load427 = load <8 x i64>, ptr %.spill63, align 64
  %3180 = add <8 x i64> splat (i64 4), %.spill.load427
  %.spill.load428 = load <8 x i64>, ptr %.spill63, align 64
  %3181 = add <8 x i64> splat (i64 5), %.spill.load428
  %.spill.load429 = load <8 x i64>, ptr %.spill63, align 64
  %3182 = add <8 x i64> splat (i64 6), %.spill.load429
  %.spill.load430 = load <8 x i64>, ptr %.spill63, align 64
  %3183 = add <8 x i64> splat (i64 7), %.spill.load430
  %.spill.load431 = load <8 x i64>, ptr %.spill63, align 64
  %3184 = add <8 x i64> splat (i64 8), %.spill.load431
  %.spill.load432 = load <8 x i64>, ptr %.spill63, align 64
  %3185 = add <8 x i64> splat (i64 9), %.spill.load432
  %.spill.load433 = load <8 x i64>, ptr %.spill63, align 64
  %3186 = add <8 x i64> splat (i64 10), %.spill.load433
  %.spill.load434 = load <8 x i64>, ptr %.spill63, align 64
  %3187 = add <8 x i64> splat (i64 11), %.spill.load434
  %.spill.load435 = load <8 x i64>, ptr %.spill63, align 64
  %3188 = add <8 x i64> splat (i64 12), %.spill.load435
  %.spill.load436 = load <8 x i64>, ptr %.spill63, align 64
  %3189 = add <8 x i64> splat (i64 13), %.spill.load436
  %.spill.load437 = load <8 x i64>, ptr %.spill63, align 64
  %3190 = add <8 x i64> splat (i64 14), %.spill.load437
  %.spill.load438 = load <8 x i64>, ptr %.spill63, align 64
  %3191 = add <8 x i64> splat (i64 15), %.spill.load438
  %3192 = icmp slt <8 x i64> %3176, splat (i64 67)
  %3193 = icmp slt <8 x i64> %3177, splat (i64 67)
  %3194 = icmp slt <8 x i64> %3178, splat (i64 67)
  %3195 = icmp slt <8 x i64> %3179, splat (i64 67)
  %3196 = icmp slt <8 x i64> %3180, splat (i64 67)
  %3197 = icmp slt <8 x i64> %3181, splat (i64 67)
  %3198 = icmp slt <8 x i64> %3182, splat (i64 67)
  %3199 = icmp slt <8 x i64> %3183, splat (i64 67)
  %3200 = icmp slt <8 x i64> %3184, splat (i64 67)
  %3201 = icmp slt <8 x i64> %3185, splat (i64 67)
  %3202 = icmp slt <8 x i64> %3186, splat (i64 67)
  %3203 = icmp slt <8 x i64> %3187, splat (i64 67)
  %3204 = icmp slt <8 x i64> %3188, splat (i64 67)
  %3205 = icmp slt <8 x i64> %3189, splat (i64 67)
  %3206 = icmp slt <8 x i64> %3190, splat (i64 67)
  %3207 = icmp slt <8 x i64> %3191, splat (i64 67)
  %.spill.load439 = load <8 x i64>, ptr %.spill50, align 64
  %3208 = add <8 x i64> zeroinitializer, %.spill.load439
  %.spill.load440 = load <8 x i64>, ptr %.spill50, align 64
  %3209 = add <8 x i64> splat (i64 1), %.spill.load440
  %.spill.load441 = load <8 x i64>, ptr %.spill50, align 64
  %3210 = add <8 x i64> splat (i64 2), %.spill.load441
  %.spill.load442 = load <8 x i64>, ptr %.spill50, align 64
  %3211 = add <8 x i64> splat (i64 3), %.spill.load442
  %3212 = add <8 x i64> %3208, splat (i64 67)
  %3213 = add <8 x i64> %3209, splat (i64 67)
  %3214 = add <8 x i64> %3210, splat (i64 67)
  %3215 = add <8 x i64> %3211, splat (i64 67)
  %3216 = sub <8 x i64> %3212, splat (i64 17)
  %3217 = sub <8 x i64> %3213, splat (i64 17)
  %3218 = sub <8 x i64> %3214, splat (i64 17)
  %3219 = sub <8 x i64> %3215, splat (i64 17)
  %3220 = icmp sle <8 x i64> %3176, %3216
  %3221 = icmp sle <8 x i64> %3176, %3217
  %3222 = icmp sle <8 x i64> %3176, %3218
  %3223 = icmp sle <8 x i64> %3176, %3219
  %3224 = icmp sle <8 x i64> %3177, %3216
  %3225 = icmp sle <8 x i64> %3177, %3217
  %3226 = icmp sle <8 x i64> %3177, %3218
  %3227 = icmp sle <8 x i64> %3177, %3219
  %3228 = icmp sle <8 x i64> %3178, %3216
  %3229 = icmp sle <8 x i64> %3178, %3217
  %3230 = icmp sle <8 x i64> %3178, %3218
  %3231 = icmp sle <8 x i64> %3178, %3219
  %3232 = icmp sle <8 x i64> %3179, %3216
  %3233 = icmp sle <8 x i64> %3179, %3217
  %3234 = icmp sle <8 x i64> %3179, %3218
  %3235 = icmp sle <8 x i64> %3179, %3219
  %3236 = icmp sle <8 x i64> %3180, %3216
  %3237 = icmp sle <8 x i64> %3180, %3217
  %3238 = icmp sle <8 x i64> %3180, %3218
  %3239 = icmp sle <8 x i64> %3180, %3219
  %3240 = icmp sle <8 x i64> %3181, %3216
  %3241 = icmp sle <8 x i64> %3181, %3217
  %3242 = icmp sle <8 x i64> %3181, %3218
  %3243 = icmp sle <8 x i64> %3181, %3219
  %3244 = icmp sle <8 x i64> %3182, %3216
  %3245 = icmp sle <8 x i64> %3182, %3217
  %3246 = icmp sle <8 x i64> %3182, %3218
  %3247 = icmp sle <8 x i64> %3182, %3219
  %3248 = icmp sle <8 x i64> %3183, %3216
  %3249 = icmp sle <8 x i64> %3183, %3217
  %3250 = icmp sle <8 x i64> %3183, %3218
  %3251 = icmp sle <8 x i64> %3183, %3219
  %3252 = icmp sle <8 x i64> %3184, %3216
  %3253 = icmp sle <8 x i64> %3184, %3217
  %3254 = icmp sle <8 x i64> %3184, %3218
  %3255 = icmp sle <8 x i64> %3184, %3219
  %3256 = icmp sle <8 x i64> %3185, %3216
  %3257 = icmp sle <8 x i64> %3185, %3217
  %3258 = icmp sle <8 x i64> %3185, %3218
  %3259 = icmp sle <8 x i64> %3185, %3219
  %3260 = icmp sle <8 x i64> %3186, %3216
  %3261 = icmp sle <8 x i64> %3186, %3217
  %3262 = icmp sle <8 x i64> %3186, %3218
  %3263 = icmp sle <8 x i64> %3186, %3219
  %3264 = icmp sle <8 x i64> %3187, %3216
  %3265 = icmp sle <8 x i64> %3187, %3217
  %3266 = icmp sle <8 x i64> %3187, %3218
  %3267 = icmp sle <8 x i64> %3187, %3219
  %3268 = icmp sle <8 x i64> %3188, %3216
  %3269 = icmp sle <8 x i64> %3188, %3217
  %3270 = icmp sle <8 x i64> %3188, %3218
  %3271 = icmp sle <8 x i64> %3188, %3219
  %3272 = icmp sle <8 x i64> %3189, %3216
  %3273 = icmp sle <8 x i64> %3189, %3217
  %3274 = icmp sle <8 x i64> %3189, %3218
  %3275 = icmp sle <8 x i64> %3189, %3219
  %3276 = icmp sle <8 x i64> %3190, %3216
  %3277 = icmp sle <8 x i64> %3190, %3217
  %3278 = icmp sle <8 x i64> %3190, %3218
  %3279 = icmp sle <8 x i64> %3190, %3219
  %3280 = icmp sle <8 x i64> %3191, %3216
  %3281 = icmp sle <8 x i64> %3191, %3217
  %3282 = icmp sle <8 x i64> %3191, %3218
  %3283 = icmp sle <8 x i64> %3191, %3219
  %3284 = and <8 x i1> %3192, %3220
  %3285 = load volatile <8 x i1>, ptr %.spill67, align 1
  %3286 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3284, <8 x i1> %3285
  store volatile <8 x i1> %3286, ptr %.spill67, align 1
  %3287 = and <8 x i1> %3192, %3221
  %3288 = load volatile <8 x i1>, ptr %.spill68, align 1
  %3289 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3287, <8 x i1> %3288
  store volatile <8 x i1> %3289, ptr %.spill68, align 1
  %3290 = and <8 x i1> %3192, %3222
  %3291 = load volatile <8 x i1>, ptr %.spill69, align 1
  %3292 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3290, <8 x i1> %3291
  store volatile <8 x i1> %3292, ptr %.spill69, align 1
  %3293 = and <8 x i1> %3192, %3223
  %3294 = load volatile <8 x i1>, ptr %.spill70, align 1
  %3295 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3293, <8 x i1> %3294
  store volatile <8 x i1> %3295, ptr %.spill70, align 1
  %3296 = and <8 x i1> %3193, %3224
  %3297 = load volatile <8 x i1>, ptr %.spill71, align 1
  %3298 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3296, <8 x i1> %3297
  store volatile <8 x i1> %3298, ptr %.spill71, align 1
  %3299 = and <8 x i1> %3193, %3225
  %3300 = load volatile <8 x i1>, ptr %.spill72, align 1
  %3301 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3299, <8 x i1> %3300
  store volatile <8 x i1> %3301, ptr %.spill72, align 1
  %3302 = and <8 x i1> %3193, %3226
  %3303 = load volatile <8 x i1>, ptr %.spill73, align 1
  %3304 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3302, <8 x i1> %3303
  store volatile <8 x i1> %3304, ptr %.spill73, align 1
  %3305 = and <8 x i1> %3193, %3227
  %3306 = load volatile <8 x i1>, ptr %.spill74, align 1
  %3307 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3305, <8 x i1> %3306
  store volatile <8 x i1> %3307, ptr %.spill74, align 1
  %3308 = and <8 x i1> %3194, %3228
  %3309 = load volatile <8 x i1>, ptr %.spill75, align 1
  %3310 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3308, <8 x i1> %3309
  store volatile <8 x i1> %3310, ptr %.spill75, align 1
  %3311 = and <8 x i1> %3194, %3229
  %3312 = load volatile <8 x i1>, ptr %.spill76, align 1
  %3313 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3311, <8 x i1> %3312
  store volatile <8 x i1> %3313, ptr %.spill76, align 1
  %3314 = and <8 x i1> %3194, %3230
  %3315 = load volatile <8 x i1>, ptr %.spill77, align 1
  %3316 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3314, <8 x i1> %3315
  store volatile <8 x i1> %3316, ptr %.spill77, align 1
  %3317 = and <8 x i1> %3194, %3231
  %3318 = load volatile <8 x i1>, ptr %.spill78, align 1
  %3319 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3317, <8 x i1> %3318
  store volatile <8 x i1> %3319, ptr %.spill78, align 1
  %3320 = and <8 x i1> %3195, %3232
  %3321 = load volatile <8 x i1>, ptr %.spill79, align 1
  %3322 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3320, <8 x i1> %3321
  store volatile <8 x i1> %3322, ptr %.spill79, align 1
  %3323 = and <8 x i1> %3195, %3233
  %3324 = load volatile <8 x i1>, ptr %.spill80, align 1
  %3325 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3323, <8 x i1> %3324
  store volatile <8 x i1> %3325, ptr %.spill80, align 1
  %3326 = and <8 x i1> %3195, %3234
  %3327 = load volatile <8 x i1>, ptr %.spill81, align 1
  %3328 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3326, <8 x i1> %3327
  store volatile <8 x i1> %3328, ptr %.spill81, align 1
  %3329 = and <8 x i1> %3195, %3235
  %3330 = load volatile <8 x i1>, ptr %.spill82, align 1
  %3331 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3329, <8 x i1> %3330
  store volatile <8 x i1> %3331, ptr %.spill82, align 1
  %3332 = and <8 x i1> %3196, %3236
  %3333 = load volatile <8 x i1>, ptr %.spill83, align 1
  %3334 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3332, <8 x i1> %3333
  store volatile <8 x i1> %3334, ptr %.spill83, align 1
  %3335 = and <8 x i1> %3196, %3237
  %3336 = load volatile <8 x i1>, ptr %.spill84, align 1
  %3337 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3335, <8 x i1> %3336
  store volatile <8 x i1> %3337, ptr %.spill84, align 1
  %3338 = and <8 x i1> %3196, %3238
  %3339 = load volatile <8 x i1>, ptr %.spill85, align 1
  %3340 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3338, <8 x i1> %3339
  store volatile <8 x i1> %3340, ptr %.spill85, align 1
  %3341 = and <8 x i1> %3196, %3239
  %3342 = load volatile <8 x i1>, ptr %.spill86, align 1
  %3343 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3341, <8 x i1> %3342
  store volatile <8 x i1> %3343, ptr %.spill86, align 1
  %3344 = and <8 x i1> %3197, %3240
  %3345 = load volatile <8 x i1>, ptr %.spill87, align 1
  %3346 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3344, <8 x i1> %3345
  store volatile <8 x i1> %3346, ptr %.spill87, align 1
  %3347 = and <8 x i1> %3197, %3241
  %3348 = load volatile <8 x i1>, ptr %.spill88, align 1
  %3349 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3347, <8 x i1> %3348
  store volatile <8 x i1> %3349, ptr %.spill88, align 1
  %3350 = and <8 x i1> %3197, %3242
  %3351 = load volatile <8 x i1>, ptr %.spill89, align 1
  %3352 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3350, <8 x i1> %3351
  store volatile <8 x i1> %3352, ptr %.spill89, align 1
  %3353 = and <8 x i1> %3197, %3243
  %3354 = load volatile <8 x i1>, ptr %.spill90, align 1
  %3355 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3353, <8 x i1> %3354
  store volatile <8 x i1> %3355, ptr %.spill90, align 1
  %3356 = and <8 x i1> %3198, %3244
  %3357 = load volatile <8 x i1>, ptr %.spill91, align 1
  %3358 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3356, <8 x i1> %3357
  store volatile <8 x i1> %3358, ptr %.spill91, align 1
  %3359 = and <8 x i1> %3198, %3245
  %3360 = load volatile <8 x i1>, ptr %.spill92, align 1
  %3361 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3359, <8 x i1> %3360
  store volatile <8 x i1> %3361, ptr %.spill92, align 1
  %3362 = and <8 x i1> %3198, %3246
  %3363 = load volatile <8 x i1>, ptr %.spill93, align 1
  %3364 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3362, <8 x i1> %3363
  store volatile <8 x i1> %3364, ptr %.spill93, align 1
  %3365 = and <8 x i1> %3198, %3247
  %3366 = load volatile <8 x i1>, ptr %.spill94, align 1
  %3367 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3365, <8 x i1> %3366
  store volatile <8 x i1> %3367, ptr %.spill94, align 1
  %3368 = and <8 x i1> %3199, %3248
  %3369 = load volatile <8 x i1>, ptr %.spill95, align 1
  %3370 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3368, <8 x i1> %3369
  store volatile <8 x i1> %3370, ptr %.spill95, align 1
  %3371 = and <8 x i1> %3199, %3249
  %3372 = load volatile <8 x i1>, ptr %.spill96, align 1
  %3373 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3371, <8 x i1> %3372
  store volatile <8 x i1> %3373, ptr %.spill96, align 1
  %3374 = and <8 x i1> %3199, %3250
  %3375 = load volatile <8 x i1>, ptr %.spill97, align 1
  %3376 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3374, <8 x i1> %3375
  store volatile <8 x i1> %3376, ptr %.spill97, align 1
  %3377 = and <8 x i1> %3199, %3251
  %3378 = load volatile <8 x i1>, ptr %.spill98, align 1
  %3379 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3377, <8 x i1> %3378
  store volatile <8 x i1> %3379, ptr %.spill98, align 1
  %3380 = and <8 x i1> %3200, %3252
  %3381 = load volatile <8 x i1>, ptr %.spill99, align 1
  %3382 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3380, <8 x i1> %3381
  store volatile <8 x i1> %3382, ptr %.spill99, align 1
  %3383 = and <8 x i1> %3200, %3253
  %3384 = load volatile <8 x i1>, ptr %.spill100, align 1
  %3385 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3383, <8 x i1> %3384
  store volatile <8 x i1> %3385, ptr %.spill100, align 1
  %3386 = and <8 x i1> %3200, %3254
  %3387 = load volatile <8 x i1>, ptr %.spill101, align 1
  %3388 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3386, <8 x i1> %3387
  store volatile <8 x i1> %3388, ptr %.spill101, align 1
  %3389 = and <8 x i1> %3200, %3255
  %3390 = load volatile <8 x i1>, ptr %.spill102, align 1
  %3391 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3389, <8 x i1> %3390
  store volatile <8 x i1> %3391, ptr %.spill102, align 1
  %3392 = and <8 x i1> %3201, %3256
  %3393 = load volatile <8 x i1>, ptr %.spill103, align 1
  %3394 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3392, <8 x i1> %3393
  store volatile <8 x i1> %3394, ptr %.spill103, align 1
  %3395 = and <8 x i1> %3201, %3257
  %3396 = load volatile <8 x i1>, ptr %.spill104, align 1
  %3397 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3395, <8 x i1> %3396
  store volatile <8 x i1> %3397, ptr %.spill104, align 1
  %3398 = and <8 x i1> %3201, %3258
  %3399 = load volatile <8 x i1>, ptr %.spill105, align 1
  %3400 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3398, <8 x i1> %3399
  store volatile <8 x i1> %3400, ptr %.spill105, align 1
  %3401 = and <8 x i1> %3201, %3259
  %3402 = load volatile <8 x i1>, ptr %.spill106, align 1
  %3403 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3401, <8 x i1> %3402
  store volatile <8 x i1> %3403, ptr %.spill106, align 1
  %3404 = and <8 x i1> %3202, %3260
  %3405 = load volatile <8 x i1>, ptr %.spill107, align 1
  %3406 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3404, <8 x i1> %3405
  store volatile <8 x i1> %3406, ptr %.spill107, align 1
  %3407 = and <8 x i1> %3202, %3261
  %3408 = load volatile <8 x i1>, ptr %.spill108, align 1
  %3409 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3407, <8 x i1> %3408
  store volatile <8 x i1> %3409, ptr %.spill108, align 1
  %3410 = and <8 x i1> %3202, %3262
  %3411 = load volatile <8 x i1>, ptr %.spill109, align 1
  %3412 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3410, <8 x i1> %3411
  store volatile <8 x i1> %3412, ptr %.spill109, align 1
  %3413 = and <8 x i1> %3202, %3263
  %3414 = load volatile <8 x i1>, ptr %.spill110, align 1
  %3415 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3413, <8 x i1> %3414
  store volatile <8 x i1> %3415, ptr %.spill110, align 1
  %3416 = and <8 x i1> %3203, %3264
  %3417 = load volatile <8 x i1>, ptr %.spill111, align 1
  %3418 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3416, <8 x i1> %3417
  store volatile <8 x i1> %3418, ptr %.spill111, align 1
  %3419 = and <8 x i1> %3203, %3265
  %3420 = load volatile <8 x i1>, ptr %.spill112, align 1
  %3421 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3419, <8 x i1> %3420
  store volatile <8 x i1> %3421, ptr %.spill112, align 1
  %3422 = and <8 x i1> %3203, %3266
  %3423 = load volatile <8 x i1>, ptr %.spill113, align 1
  %3424 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3422, <8 x i1> %3423
  store volatile <8 x i1> %3424, ptr %.spill113, align 1
  %3425 = and <8 x i1> %3203, %3267
  %3426 = load volatile <8 x i1>, ptr %.spill114, align 1
  %3427 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3425, <8 x i1> %3426
  store volatile <8 x i1> %3427, ptr %.spill114, align 1
  %3428 = and <8 x i1> %3204, %3268
  %3429 = load volatile <8 x i1>, ptr %.spill115, align 1
  %3430 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3428, <8 x i1> %3429
  store volatile <8 x i1> %3430, ptr %.spill115, align 1
  %3431 = and <8 x i1> %3204, %3269
  %3432 = load volatile <8 x i1>, ptr %.spill116, align 1
  %3433 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3431, <8 x i1> %3432
  store volatile <8 x i1> %3433, ptr %.spill116, align 1
  %3434 = and <8 x i1> %3204, %3270
  %3435 = load volatile <8 x i1>, ptr %.spill117, align 1
  %3436 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3434, <8 x i1> %3435
  store volatile <8 x i1> %3436, ptr %.spill117, align 1
  %3437 = and <8 x i1> %3204, %3271
  %3438 = load volatile <8 x i1>, ptr %.spill118, align 1
  %3439 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3437, <8 x i1> %3438
  store volatile <8 x i1> %3439, ptr %.spill118, align 1
  %3440 = and <8 x i1> %3205, %3272
  %3441 = load volatile <8 x i1>, ptr %.spill119, align 1
  %3442 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3440, <8 x i1> %3441
  store volatile <8 x i1> %3442, ptr %.spill119, align 1
  %3443 = and <8 x i1> %3205, %3273
  %3444 = load volatile <8 x i1>, ptr %.spill120, align 1
  %3445 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3443, <8 x i1> %3444
  store volatile <8 x i1> %3445, ptr %.spill120, align 1
  %3446 = and <8 x i1> %3205, %3274
  %3447 = load volatile <8 x i1>, ptr %.spill121, align 1
  %3448 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3446, <8 x i1> %3447
  store volatile <8 x i1> %3448, ptr %.spill121, align 1
  %3449 = and <8 x i1> %3205, %3275
  %3450 = load volatile <8 x i1>, ptr %.spill122, align 1
  %3451 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3449, <8 x i1> %3450
  store volatile <8 x i1> %3451, ptr %.spill122, align 1
  %3452 = and <8 x i1> %3206, %3276
  %3453 = load volatile <8 x i1>, ptr %.spill123, align 1
  %3454 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3452, <8 x i1> %3453
  store volatile <8 x i1> %3454, ptr %.spill123, align 1
  %3455 = and <8 x i1> %3206, %3277
  %3456 = load volatile <8 x i1>, ptr %.spill124, align 1
  %3457 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3455, <8 x i1> %3456
  store volatile <8 x i1> %3457, ptr %.spill124, align 1
  %3458 = and <8 x i1> %3206, %3278
  %3459 = load volatile <8 x i1>, ptr %.spill125, align 1
  %3460 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3458, <8 x i1> %3459
  store volatile <8 x i1> %3460, ptr %.spill125, align 1
  %3461 = and <8 x i1> %3206, %3279
  %3462 = load volatile <8 x i1>, ptr %.spill126, align 1
  %3463 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3461, <8 x i1> %3462
  store volatile <8 x i1> %3463, ptr %.spill126, align 1
  %3464 = and <8 x i1> %3207, %3280
  %3465 = load volatile <8 x i1>, ptr %.spill127, align 1
  %3466 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3464, <8 x i1> %3465
  store volatile <8 x i1> %3466, ptr %.spill127, align 1
  %3467 = and <8 x i1> %3207, %3281
  %3468 = load volatile <8 x i1>, ptr %.spill128, align 1
  %3469 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3467, <8 x i1> %3468
  store volatile <8 x i1> %3469, ptr %.spill128, align 1
  %3470 = and <8 x i1> %3207, %3282
  %3471 = load volatile <8 x i1>, ptr %.spill129, align 1
  %3472 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3470, <8 x i1> %3471
  store volatile <8 x i1> %3472, ptr %.spill129, align 1
  %3473 = and <8 x i1> %3207, %3283
  %3474 = load volatile <8 x i1>, ptr %.spill130, align 1
  %3475 = select <8 x i1> %convergence.cascade.result406, <8 x i1> %3473, <8 x i1> %3474
  store volatile <8 x i1> %3475, ptr %.spill130, align 1
  %3476 = select <8 x i1> %3284, <8 x float> %3112, <8 x float> splat (float 0xC6293E5940000000)
  %3477 = load volatile <8 x float>, ptr %.spill131, align 32
  %3478 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3476, <8 x float> %3477
  store volatile <8 x float> %3478, ptr %.spill131, align 32
  %3479 = select <8 x i1> %3296, <8 x float> %3113, <8 x float> splat (float 0xC6293E5940000000)
  %3480 = load volatile <8 x float>, ptr %.spill132, align 32
  %3481 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3479, <8 x float> %3480
  store volatile <8 x float> %3481, ptr %.spill132, align 32
  %3482 = select <8 x i1> %3308, <8 x float> %3114, <8 x float> splat (float 0xC6293E5940000000)
  %3483 = load volatile <8 x float>, ptr %.spill133, align 32
  %3484 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3482, <8 x float> %3483
  store volatile <8 x float> %3484, ptr %.spill133, align 32
  %3485 = select <8 x i1> %3320, <8 x float> %3115, <8 x float> splat (float 0xC6293E5940000000)
  %3486 = load volatile <8 x float>, ptr %.spill134, align 32
  %3487 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3485, <8 x float> %3486
  store volatile <8 x float> %3487, ptr %.spill134, align 32
  %3488 = select <8 x i1> %3332, <8 x float> %3116, <8 x float> splat (float 0xC6293E5940000000)
  %3489 = load volatile <8 x float>, ptr %.spill135, align 32
  %3490 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3488, <8 x float> %3489
  store volatile <8 x float> %3490, ptr %.spill135, align 32
  %3491 = select <8 x i1> %3344, <8 x float> %3117, <8 x float> splat (float 0xC6293E5940000000)
  %3492 = load volatile <8 x float>, ptr %.spill136, align 32
  %3493 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3491, <8 x float> %3492
  store volatile <8 x float> %3493, ptr %.spill136, align 32
  %3494 = select <8 x i1> %3356, <8 x float> %3118, <8 x float> splat (float 0xC6293E5940000000)
  %3495 = load volatile <8 x float>, ptr %.spill137, align 32
  %3496 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3494, <8 x float> %3495
  store volatile <8 x float> %3496, ptr %.spill137, align 32
  %3497 = select <8 x i1> %3368, <8 x float> %3119, <8 x float> splat (float 0xC6293E5940000000)
  %3498 = load volatile <8 x float>, ptr %.spill138, align 32
  %3499 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3497, <8 x float> %3498
  store volatile <8 x float> %3499, ptr %.spill138, align 32
  %3500 = select <8 x i1> %3380, <8 x float> %3120, <8 x float> splat (float 0xC6293E5940000000)
  %3501 = load volatile <8 x float>, ptr %.spill139, align 32
  %3502 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3500, <8 x float> %3501
  store volatile <8 x float> %3502, ptr %.spill139, align 32
  %3503 = select <8 x i1> %3392, <8 x float> %3121, <8 x float> splat (float 0xC6293E5940000000)
  %3504 = load volatile <8 x float>, ptr %.spill140, align 32
  %3505 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3503, <8 x float> %3504
  store volatile <8 x float> %3505, ptr %.spill140, align 32
  %3506 = select <8 x i1> %3404, <8 x float> %3122, <8 x float> splat (float 0xC6293E5940000000)
  %3507 = load volatile <8 x float>, ptr %.spill141, align 32
  %3508 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3506, <8 x float> %3507
  store volatile <8 x float> %3508, ptr %.spill141, align 32
  %3509 = select <8 x i1> %3416, <8 x float> %3123, <8 x float> splat (float 0xC6293E5940000000)
  %3510 = load volatile <8 x float>, ptr %.spill142, align 32
  %3511 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3509, <8 x float> %3510
  store volatile <8 x float> %3511, ptr %.spill142, align 32
  %3512 = select <8 x i1> %3428, <8 x float> %3124, <8 x float> splat (float 0xC6293E5940000000)
  %3513 = load volatile <8 x float>, ptr %.spill143, align 32
  %3514 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3512, <8 x float> %3513
  store volatile <8 x float> %3514, ptr %.spill143, align 32
  %3515 = select <8 x i1> %3440, <8 x float> %3125, <8 x float> splat (float 0xC6293E5940000000)
  %3516 = load volatile <8 x float>, ptr %.spill144, align 32
  %3517 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3515, <8 x float> %3516
  store volatile <8 x float> %3517, ptr %.spill144, align 32
  %3518 = select <8 x i1> %3452, <8 x float> %3126, <8 x float> splat (float 0xC6293E5940000000)
  %3519 = load volatile <8 x float>, ptr %.spill145, align 32
  %3520 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3518, <8 x float> %3519
  store volatile <8 x float> %3520, ptr %.spill145, align 32
  %3521 = select <8 x i1> %3464, <8 x float> %3127, <8 x float> splat (float 0xC6293E5940000000)
  %3522 = load volatile <8 x float>, ptr %.spill146, align 32
  %3523 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3521, <8 x float> %3522
  store volatile <8 x float> %3523, ptr %.spill146, align 32
  %3524 = select <8 x i1> %3287, <8 x float> %3128, <8 x float> splat (float 0xC6293E5940000000)
  %3525 = load volatile <8 x float>, ptr %.spill147, align 32
  %3526 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3524, <8 x float> %3525
  store volatile <8 x float> %3526, ptr %.spill147, align 32
  %3527 = select <8 x i1> %3299, <8 x float> %3129, <8 x float> splat (float 0xC6293E5940000000)
  %3528 = load volatile <8 x float>, ptr %.spill148, align 32
  %3529 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3527, <8 x float> %3528
  store volatile <8 x float> %3529, ptr %.spill148, align 32
  %3530 = select <8 x i1> %3311, <8 x float> %3130, <8 x float> splat (float 0xC6293E5940000000)
  %3531 = load volatile <8 x float>, ptr %.spill149, align 32
  %3532 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3530, <8 x float> %3531
  store volatile <8 x float> %3532, ptr %.spill149, align 32
  %3533 = select <8 x i1> %3323, <8 x float> %3131, <8 x float> splat (float 0xC6293E5940000000)
  %3534 = load volatile <8 x float>, ptr %.spill150, align 32
  %3535 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3533, <8 x float> %3534
  store volatile <8 x float> %3535, ptr %.spill150, align 32
  %3536 = select <8 x i1> %3335, <8 x float> %3132, <8 x float> splat (float 0xC6293E5940000000)
  %3537 = load volatile <8 x float>, ptr %.spill151, align 32
  %3538 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3536, <8 x float> %3537
  store volatile <8 x float> %3538, ptr %.spill151, align 32
  %3539 = select <8 x i1> %3347, <8 x float> %3133, <8 x float> splat (float 0xC6293E5940000000)
  %3540 = load volatile <8 x float>, ptr %.spill152, align 32
  %3541 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3539, <8 x float> %3540
  store volatile <8 x float> %3541, ptr %.spill152, align 32
  %3542 = select <8 x i1> %3359, <8 x float> %3134, <8 x float> splat (float 0xC6293E5940000000)
  %3543 = load volatile <8 x float>, ptr %.spill153, align 32
  %3544 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3542, <8 x float> %3543
  store volatile <8 x float> %3544, ptr %.spill153, align 32
  %3545 = select <8 x i1> %3371, <8 x float> %3135, <8 x float> splat (float 0xC6293E5940000000)
  %3546 = load volatile <8 x float>, ptr %.spill154, align 32
  %3547 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3545, <8 x float> %3546
  store volatile <8 x float> %3547, ptr %.spill154, align 32
  %3548 = select <8 x i1> %3383, <8 x float> %3136, <8 x float> splat (float 0xC6293E5940000000)
  %3549 = load volatile <8 x float>, ptr %.spill155, align 32
  %3550 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3548, <8 x float> %3549
  store volatile <8 x float> %3550, ptr %.spill155, align 32
  %3551 = select <8 x i1> %3395, <8 x float> %3137, <8 x float> splat (float 0xC6293E5940000000)
  %3552 = load volatile <8 x float>, ptr %.spill156, align 32
  %3553 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3551, <8 x float> %3552
  store volatile <8 x float> %3553, ptr %.spill156, align 32
  %3554 = select <8 x i1> %3407, <8 x float> %3138, <8 x float> splat (float 0xC6293E5940000000)
  %3555 = load volatile <8 x float>, ptr %.spill157, align 32
  %3556 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3554, <8 x float> %3555
  store volatile <8 x float> %3556, ptr %.spill157, align 32
  %3557 = select <8 x i1> %3419, <8 x float> %3139, <8 x float> splat (float 0xC6293E5940000000)
  %3558 = load volatile <8 x float>, ptr %.spill158, align 32
  %3559 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3557, <8 x float> %3558
  store volatile <8 x float> %3559, ptr %.spill158, align 32
  %3560 = select <8 x i1> %3431, <8 x float> %3140, <8 x float> splat (float 0xC6293E5940000000)
  %3561 = load volatile <8 x float>, ptr %.spill159, align 32
  %3562 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3560, <8 x float> %3561
  store volatile <8 x float> %3562, ptr %.spill159, align 32
  %3563 = select <8 x i1> %3443, <8 x float> %3141, <8 x float> splat (float 0xC6293E5940000000)
  %3564 = load volatile <8 x float>, ptr %.spill160, align 32
  %3565 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3563, <8 x float> %3564
  store volatile <8 x float> %3565, ptr %.spill160, align 32
  %3566 = select <8 x i1> %3455, <8 x float> %3142, <8 x float> splat (float 0xC6293E5940000000)
  %3567 = load volatile <8 x float>, ptr %.spill161, align 32
  %3568 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3566, <8 x float> %3567
  store volatile <8 x float> %3568, ptr %.spill161, align 32
  %3569 = select <8 x i1> %3467, <8 x float> %3143, <8 x float> splat (float 0xC6293E5940000000)
  %3570 = load volatile <8 x float>, ptr %.spill162, align 32
  %3571 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3569, <8 x float> %3570
  store volatile <8 x float> %3571, ptr %.spill162, align 32
  %3572 = select <8 x i1> %3290, <8 x float> %3144, <8 x float> splat (float 0xC6293E5940000000)
  %3573 = load volatile <8 x float>, ptr %.spill163, align 32
  %3574 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3572, <8 x float> %3573
  store volatile <8 x float> %3574, ptr %.spill163, align 32
  %3575 = select <8 x i1> %3302, <8 x float> %3145, <8 x float> splat (float 0xC6293E5940000000)
  %3576 = load volatile <8 x float>, ptr %.spill164, align 32
  %3577 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3575, <8 x float> %3576
  store volatile <8 x float> %3577, ptr %.spill164, align 32
  %3578 = select <8 x i1> %3314, <8 x float> %3146, <8 x float> splat (float 0xC6293E5940000000)
  %3579 = load volatile <8 x float>, ptr %.spill165, align 32
  %3580 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3578, <8 x float> %3579
  store volatile <8 x float> %3580, ptr %.spill165, align 32
  %3581 = select <8 x i1> %3326, <8 x float> %3147, <8 x float> splat (float 0xC6293E5940000000)
  %3582 = load volatile <8 x float>, ptr %.spill166, align 32
  %3583 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3581, <8 x float> %3582
  store volatile <8 x float> %3583, ptr %.spill166, align 32
  %3584 = select <8 x i1> %3338, <8 x float> %3148, <8 x float> splat (float 0xC6293E5940000000)
  %3585 = load volatile <8 x float>, ptr %.spill167, align 32
  %3586 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3584, <8 x float> %3585
  store volatile <8 x float> %3586, ptr %.spill167, align 32
  %3587 = select <8 x i1> %3350, <8 x float> %3149, <8 x float> splat (float 0xC6293E5940000000)
  %3588 = load volatile <8 x float>, ptr %.spill168, align 32
  %3589 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3587, <8 x float> %3588
  store volatile <8 x float> %3589, ptr %.spill168, align 32
  %3590 = select <8 x i1> %3362, <8 x float> %3150, <8 x float> splat (float 0xC6293E5940000000)
  %3591 = load volatile <8 x float>, ptr %.spill169, align 32
  %3592 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3590, <8 x float> %3591
  store volatile <8 x float> %3592, ptr %.spill169, align 32
  %3593 = select <8 x i1> %3374, <8 x float> %3151, <8 x float> splat (float 0xC6293E5940000000)
  %3594 = load volatile <8 x float>, ptr %.spill170, align 32
  %3595 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3593, <8 x float> %3594
  store volatile <8 x float> %3595, ptr %.spill170, align 32
  %3596 = select <8 x i1> %3386, <8 x float> %3152, <8 x float> splat (float 0xC6293E5940000000)
  %3597 = load volatile <8 x float>, ptr %.spill171, align 32
  %3598 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3596, <8 x float> %3597
  store volatile <8 x float> %3598, ptr %.spill171, align 32
  %3599 = select <8 x i1> %3398, <8 x float> %3153, <8 x float> splat (float 0xC6293E5940000000)
  %3600 = load volatile <8 x float>, ptr %.spill172, align 32
  %3601 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3599, <8 x float> %3600
  store volatile <8 x float> %3601, ptr %.spill172, align 32
  %3602 = select <8 x i1> %3410, <8 x float> %3154, <8 x float> splat (float 0xC6293E5940000000)
  %3603 = load volatile <8 x float>, ptr %.spill173, align 32
  %3604 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3602, <8 x float> %3603
  store volatile <8 x float> %3604, ptr %.spill173, align 32
  %3605 = select <8 x i1> %3422, <8 x float> %3155, <8 x float> splat (float 0xC6293E5940000000)
  %3606 = load volatile <8 x float>, ptr %.spill174, align 32
  %3607 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3605, <8 x float> %3606
  store volatile <8 x float> %3607, ptr %.spill174, align 32
  %3608 = select <8 x i1> %3434, <8 x float> %3156, <8 x float> splat (float 0xC6293E5940000000)
  %3609 = load volatile <8 x float>, ptr %.spill175, align 32
  %3610 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3608, <8 x float> %3609
  store volatile <8 x float> %3610, ptr %.spill175, align 32
  %3611 = select <8 x i1> %3446, <8 x float> %3157, <8 x float> splat (float 0xC6293E5940000000)
  %3612 = load volatile <8 x float>, ptr %.spill176, align 32
  %3613 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3611, <8 x float> %3612
  store volatile <8 x float> %3613, ptr %.spill176, align 32
  %3614 = select <8 x i1> %3458, <8 x float> %3158, <8 x float> splat (float 0xC6293E5940000000)
  %3615 = load volatile <8 x float>, ptr %.spill177, align 32
  %3616 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3614, <8 x float> %3615
  store volatile <8 x float> %3616, ptr %.spill177, align 32
  %3617 = select <8 x i1> %3470, <8 x float> %3159, <8 x float> splat (float 0xC6293E5940000000)
  %3618 = load volatile <8 x float>, ptr %.spill178, align 32
  %3619 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3617, <8 x float> %3618
  store volatile <8 x float> %3619, ptr %.spill178, align 32
  %3620 = select <8 x i1> %3293, <8 x float> %3160, <8 x float> splat (float 0xC6293E5940000000)
  %3621 = load volatile <8 x float>, ptr %.spill179, align 32
  %3622 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3620, <8 x float> %3621
  store volatile <8 x float> %3622, ptr %.spill179, align 32
  %3623 = select <8 x i1> %3305, <8 x float> %3161, <8 x float> splat (float 0xC6293E5940000000)
  %3624 = load volatile <8 x float>, ptr %.spill180, align 32
  %3625 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3623, <8 x float> %3624
  store volatile <8 x float> %3625, ptr %.spill180, align 32
  %3626 = select <8 x i1> %3317, <8 x float> %3162, <8 x float> splat (float 0xC6293E5940000000)
  %3627 = load volatile <8 x float>, ptr %.spill181, align 32
  %3628 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3626, <8 x float> %3627
  store volatile <8 x float> %3628, ptr %.spill181, align 32
  %3629 = select <8 x i1> %3329, <8 x float> %3163, <8 x float> splat (float 0xC6293E5940000000)
  %3630 = load volatile <8 x float>, ptr %.spill182, align 32
  %3631 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3629, <8 x float> %3630
  store volatile <8 x float> %3631, ptr %.spill182, align 32
  %3632 = select <8 x i1> %3341, <8 x float> %3164, <8 x float> splat (float 0xC6293E5940000000)
  %3633 = load volatile <8 x float>, ptr %.spill183, align 32
  %3634 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3632, <8 x float> %3633
  store volatile <8 x float> %3634, ptr %.spill183, align 32
  %3635 = select <8 x i1> %3353, <8 x float> %3165, <8 x float> splat (float 0xC6293E5940000000)
  %3636 = load volatile <8 x float>, ptr %.spill184, align 32
  %3637 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3635, <8 x float> %3636
  store volatile <8 x float> %3637, ptr %.spill184, align 32
  %3638 = select <8 x i1> %3365, <8 x float> %3166, <8 x float> splat (float 0xC6293E5940000000)
  %3639 = load volatile <8 x float>, ptr %.spill185, align 32
  %3640 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3638, <8 x float> %3639
  store volatile <8 x float> %3640, ptr %.spill185, align 32
  %3641 = select <8 x i1> %3377, <8 x float> %3167, <8 x float> splat (float 0xC6293E5940000000)
  %3642 = load volatile <8 x float>, ptr %.spill186, align 32
  %3643 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3641, <8 x float> %3642
  store volatile <8 x float> %3643, ptr %.spill186, align 32
  %3644 = select <8 x i1> %3389, <8 x float> %3168, <8 x float> splat (float 0xC6293E5940000000)
  %3645 = load volatile <8 x float>, ptr %.spill187, align 32
  %3646 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3644, <8 x float> %3645
  store volatile <8 x float> %3646, ptr %.spill187, align 32
  %3647 = select <8 x i1> %3401, <8 x float> %3169, <8 x float> splat (float 0xC6293E5940000000)
  %3648 = load volatile <8 x float>, ptr %.spill188, align 32
  %3649 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3647, <8 x float> %3648
  store volatile <8 x float> %3649, ptr %.spill188, align 32
  %3650 = select <8 x i1> %3413, <8 x float> %3170, <8 x float> splat (float 0xC6293E5940000000)
  %3651 = load volatile <8 x float>, ptr %.spill189, align 32
  %3652 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3650, <8 x float> %3651
  store volatile <8 x float> %3652, ptr %.spill189, align 32
  %3653 = select <8 x i1> %3425, <8 x float> %3171, <8 x float> splat (float 0xC6293E5940000000)
  %3654 = load volatile <8 x float>, ptr %.spill190, align 32
  %3655 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3653, <8 x float> %3654
  store volatile <8 x float> %3655, ptr %.spill190, align 32
  %3656 = select <8 x i1> %3437, <8 x float> %3172, <8 x float> splat (float 0xC6293E5940000000)
  %3657 = load volatile <8 x float>, ptr %.spill191, align 32
  %3658 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3656, <8 x float> %3657
  store volatile <8 x float> %3658, ptr %.spill191, align 32
  %3659 = select <8 x i1> %3449, <8 x float> %3173, <8 x float> splat (float 0xC6293E5940000000)
  %3660 = load volatile <8 x float>, ptr %.spill192, align 32
  %3661 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3659, <8 x float> %3660
  store volatile <8 x float> %3661, ptr %.spill192, align 32
  %3662 = select <8 x i1> %3461, <8 x float> %3174, <8 x float> splat (float 0xC6293E5940000000)
  %3663 = load volatile <8 x float>, ptr %.spill193, align 32
  %3664 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3662, <8 x float> %3663
  store volatile <8 x float> %3664, ptr %.spill193, align 32
  %3665 = select <8 x i1> %3473, <8 x float> %3175, <8 x float> splat (float 0xC6293E5940000000)
  %3666 = load volatile <8 x float>, ptr %.spill194, align 32
  %3667 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3665, <8 x float> %3666
  store volatile <8 x float> %3667, ptr %.spill194, align 32
  %3668 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill195, align 64
  %3669 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3670 = extractvalue { <8 x ptr>, <8 x i64> } %3668, 0
  %3671 = select <8 x i1> %convergence.cascade.result406, <8 x ptr> %3669, <8 x ptr> %3670
  %3672 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3673 = extractvalue { <8 x ptr>, <8 x i64> } %3668, 1
  %3674 = select <8 x i1> %convergence.cascade.result406, <8 x i64> %3672, <8 x i64> %3673
  %3675 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3671, 0
  %3676 = insertvalue { <8 x ptr>, <8 x i64> } %3675, <8 x i64> %3674, 1
  store { <8 x ptr>, <8 x i64> } %3676, ptr %tile_snapshot.spill195, align 64
  %3677 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3678 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3679 = add <8 x i64> %3678, zeroinitializer
  %3680 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3677, 0
  %3681 = insertvalue { <8 x ptr>, <8 x i64> } %3680, <8 x i64> %3679, 1
  %3682 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3683 = extractvalue { <8 x ptr>, <8 x i64> } %3681, 1
  %3684 = extractelement <8 x ptr> %3682, i32 0
  %3685 = extractelement <8 x i64> %3683, i32 %1855
  %3686 = zext i32 %1855 to i64
  %3687 = mul i64 %3686, 4
  %3688 = sub i64 %3685, %3687
  %3689 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %3690 = select i1 %3689, i64 %3688, i64 0
  %private.contiguous.address = getelementptr i8, ptr %3684, i64 %3690
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %3691 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3476, <8 x float> %private.contiguous.preserve
  store <8 x float> %3691, ptr %private.contiguous.address, align 4
  %3692 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3693 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3694 = add <8 x i64> %3693, splat (i64 32)
  %3695 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3692, 0
  %3696 = insertvalue { <8 x ptr>, <8 x i64> } %3695, <8 x i64> %3694, 1
  %3697 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3698 = extractvalue { <8 x ptr>, <8 x i64> } %3696, 1
  %3699 = extractelement <8 x ptr> %3697, i32 0
  %3700 = extractelement <8 x i64> %3698, i32 %1855
  %3701 = zext i32 %1855 to i64
  %3702 = mul i64 %3701, 4
  %3703 = sub i64 %3700, %3702
  %3704 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %3705 = select i1 %3704, i64 %3703, i64 0
  %private.contiguous.address443 = getelementptr i8, ptr %3699, i64 %3705
  %private.contiguous.preserve444 = load <8 x float>, ptr %private.contiguous.address443, align 4
  %3706 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3479, <8 x float> %private.contiguous.preserve444
  store <8 x float> %3706, ptr %private.contiguous.address443, align 4
  %3707 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3708 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3709 = add <8 x i64> %3708, splat (i64 64)
  %3710 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3707, 0
  %3711 = insertvalue { <8 x ptr>, <8 x i64> } %3710, <8 x i64> %3709, 1
  %3712 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3713 = extractvalue { <8 x ptr>, <8 x i64> } %3711, 1
  %3714 = extractelement <8 x ptr> %3712, i32 0
  %3715 = extractelement <8 x i64> %3713, i32 %1855
  %3716 = zext i32 %1855 to i64
  %3717 = mul i64 %3716, 4
  %3718 = sub i64 %3715, %3717
  %3719 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %3720 = select i1 %3719, i64 %3718, i64 0
  %private.contiguous.address445 = getelementptr i8, ptr %3714, i64 %3720
  %private.contiguous.preserve446 = load <8 x float>, ptr %private.contiguous.address445, align 4
  %3721 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3482, <8 x float> %private.contiguous.preserve446
  store <8 x float> %3721, ptr %private.contiguous.address445, align 4
  %3722 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3723 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3724 = add <8 x i64> %3723, splat (i64 96)
  %3725 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3722, 0
  %3726 = insertvalue { <8 x ptr>, <8 x i64> } %3725, <8 x i64> %3724, 1
  %3727 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3728 = extractvalue { <8 x ptr>, <8 x i64> } %3726, 1
  %3729 = extractelement <8 x ptr> %3727, i32 0
  %3730 = extractelement <8 x i64> %3728, i32 %1855
  %3731 = zext i32 %1855 to i64
  %3732 = mul i64 %3731, 4
  %3733 = sub i64 %3730, %3732
  %3734 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %3735 = select i1 %3734, i64 %3733, i64 0
  %private.contiguous.address447 = getelementptr i8, ptr %3729, i64 %3735
  %private.contiguous.preserve448 = load <8 x float>, ptr %private.contiguous.address447, align 4
  %3736 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3485, <8 x float> %private.contiguous.preserve448
  store <8 x float> %3736, ptr %private.contiguous.address447, align 4
  %3737 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3738 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3739 = add <8 x i64> %3738, splat (i64 128)
  %3740 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3737, 0
  %3741 = insertvalue { <8 x ptr>, <8 x i64> } %3740, <8 x i64> %3739, 1
  %3742 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3743 = extractvalue { <8 x ptr>, <8 x i64> } %3741, 1
  %3744 = extractelement <8 x ptr> %3742, i32 0
  %3745 = extractelement <8 x i64> %3743, i32 %1855
  %3746 = zext i32 %1855 to i64
  %3747 = mul i64 %3746, 4
  %3748 = sub i64 %3745, %3747
  %3749 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %3750 = select i1 %3749, i64 %3748, i64 0
  %private.contiguous.address449 = getelementptr i8, ptr %3744, i64 %3750
  %private.contiguous.preserve450 = load <8 x float>, ptr %private.contiguous.address449, align 4
  %3751 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3488, <8 x float> %private.contiguous.preserve450
  store <8 x float> %3751, ptr %private.contiguous.address449, align 4
  %3752 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3753 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3754 = add <8 x i64> %3753, splat (i64 160)
  %3755 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3752, 0
  %3756 = insertvalue { <8 x ptr>, <8 x i64> } %3755, <8 x i64> %3754, 1
  %3757 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3758 = extractvalue { <8 x ptr>, <8 x i64> } %3756, 1
  %3759 = extractelement <8 x ptr> %3757, i32 0
  %3760 = extractelement <8 x i64> %3758, i32 %1855
  %3761 = zext i32 %1855 to i64
  %3762 = mul i64 %3761, 4
  %3763 = sub i64 %3760, %3762
  %3764 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %3765 = select i1 %3764, i64 %3763, i64 0
  %private.contiguous.address451 = getelementptr i8, ptr %3759, i64 %3765
  %private.contiguous.preserve452 = load <8 x float>, ptr %private.contiguous.address451, align 4
  %3766 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3491, <8 x float> %private.contiguous.preserve452
  store <8 x float> %3766, ptr %private.contiguous.address451, align 4
  %3767 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3768 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3769 = add <8 x i64> %3768, splat (i64 192)
  %3770 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3767, 0
  %3771 = insertvalue { <8 x ptr>, <8 x i64> } %3770, <8 x i64> %3769, 1
  %3772 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3773 = extractvalue { <8 x ptr>, <8 x i64> } %3771, 1
  %3774 = extractelement <8 x ptr> %3772, i32 0
  %3775 = extractelement <8 x i64> %3773, i32 %1855
  %3776 = zext i32 %1855 to i64
  %3777 = mul i64 %3776, 4
  %3778 = sub i64 %3775, %3777
  %3779 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %3780 = select i1 %3779, i64 %3778, i64 0
  %private.contiguous.address453 = getelementptr i8, ptr %3774, i64 %3780
  %private.contiguous.preserve454 = load <8 x float>, ptr %private.contiguous.address453, align 4
  %3781 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3494, <8 x float> %private.contiguous.preserve454
  store <8 x float> %3781, ptr %private.contiguous.address453, align 4
  %3782 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3783 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3784 = add <8 x i64> %3783, splat (i64 224)
  %3785 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3782, 0
  %3786 = insertvalue { <8 x ptr>, <8 x i64> } %3785, <8 x i64> %3784, 1
  %3787 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3788 = extractvalue { <8 x ptr>, <8 x i64> } %3786, 1
  %3789 = extractelement <8 x ptr> %3787, i32 0
  %3790 = extractelement <8 x i64> %3788, i32 %1855
  %3791 = zext i32 %1855 to i64
  %3792 = mul i64 %3791, 4
  %3793 = sub i64 %3790, %3792
  %3794 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %3795 = select i1 %3794, i64 %3793, i64 0
  %private.contiguous.address455 = getelementptr i8, ptr %3789, i64 %3795
  %private.contiguous.preserve456 = load <8 x float>, ptr %private.contiguous.address455, align 4
  %3796 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3497, <8 x float> %private.contiguous.preserve456
  store <8 x float> %3796, ptr %private.contiguous.address455, align 4
  %3797 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3798 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3799 = add <8 x i64> %3798, splat (i64 256)
  %3800 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3797, 0
  %3801 = insertvalue { <8 x ptr>, <8 x i64> } %3800, <8 x i64> %3799, 1
  %3802 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3803 = extractvalue { <8 x ptr>, <8 x i64> } %3801, 1
  %3804 = extractelement <8 x ptr> %3802, i32 0
  %3805 = extractelement <8 x i64> %3803, i32 %1855
  %3806 = zext i32 %1855 to i64
  %3807 = mul i64 %3806, 4
  %3808 = sub i64 %3805, %3807
  %3809 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %3810 = select i1 %3809, i64 %3808, i64 0
  %private.contiguous.address457 = getelementptr i8, ptr %3804, i64 %3810
  %private.contiguous.preserve458 = load <8 x float>, ptr %private.contiguous.address457, align 4
  %3811 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3500, <8 x float> %private.contiguous.preserve458
  store <8 x float> %3811, ptr %private.contiguous.address457, align 4
  %3812 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3813 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3814 = add <8 x i64> %3813, splat (i64 288)
  %3815 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3812, 0
  %3816 = insertvalue { <8 x ptr>, <8 x i64> } %3815, <8 x i64> %3814, 1
  %3817 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3818 = extractvalue { <8 x ptr>, <8 x i64> } %3816, 1
  %3819 = extractelement <8 x ptr> %3817, i32 0
  %3820 = extractelement <8 x i64> %3818, i32 %1855
  %3821 = zext i32 %1855 to i64
  %3822 = mul i64 %3821, 4
  %3823 = sub i64 %3820, %3822
  %3824 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %3825 = select i1 %3824, i64 %3823, i64 0
  %private.contiguous.address459 = getelementptr i8, ptr %3819, i64 %3825
  %private.contiguous.preserve460 = load <8 x float>, ptr %private.contiguous.address459, align 4
  %3826 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3503, <8 x float> %private.contiguous.preserve460
  store <8 x float> %3826, ptr %private.contiguous.address459, align 4
  %3827 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3828 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3829 = add <8 x i64> %3828, splat (i64 320)
  %3830 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3827, 0
  %3831 = insertvalue { <8 x ptr>, <8 x i64> } %3830, <8 x i64> %3829, 1
  %3832 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3833 = extractvalue { <8 x ptr>, <8 x i64> } %3831, 1
  %3834 = extractelement <8 x ptr> %3832, i32 0
  %3835 = extractelement <8 x i64> %3833, i32 %1855
  %3836 = zext i32 %1855 to i64
  %3837 = mul i64 %3836, 4
  %3838 = sub i64 %3835, %3837
  %3839 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %3840 = select i1 %3839, i64 %3838, i64 0
  %private.contiguous.address461 = getelementptr i8, ptr %3834, i64 %3840
  %private.contiguous.preserve462 = load <8 x float>, ptr %private.contiguous.address461, align 4
  %3841 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3506, <8 x float> %private.contiguous.preserve462
  store <8 x float> %3841, ptr %private.contiguous.address461, align 4
  %3842 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3843 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3844 = add <8 x i64> %3843, splat (i64 352)
  %3845 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3842, 0
  %3846 = insertvalue { <8 x ptr>, <8 x i64> } %3845, <8 x i64> %3844, 1
  %3847 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3848 = extractvalue { <8 x ptr>, <8 x i64> } %3846, 1
  %3849 = extractelement <8 x ptr> %3847, i32 0
  %3850 = extractelement <8 x i64> %3848, i32 %1855
  %3851 = zext i32 %1855 to i64
  %3852 = mul i64 %3851, 4
  %3853 = sub i64 %3850, %3852
  %3854 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %3855 = select i1 %3854, i64 %3853, i64 0
  %private.contiguous.address463 = getelementptr i8, ptr %3849, i64 %3855
  %private.contiguous.preserve464 = load <8 x float>, ptr %private.contiguous.address463, align 4
  %3856 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3509, <8 x float> %private.contiguous.preserve464
  store <8 x float> %3856, ptr %private.contiguous.address463, align 4
  %3857 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3858 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3859 = add <8 x i64> %3858, splat (i64 384)
  %3860 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3857, 0
  %3861 = insertvalue { <8 x ptr>, <8 x i64> } %3860, <8 x i64> %3859, 1
  %3862 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3863 = extractvalue { <8 x ptr>, <8 x i64> } %3861, 1
  %3864 = extractelement <8 x ptr> %3862, i32 0
  %3865 = extractelement <8 x i64> %3863, i32 %1855
  %3866 = zext i32 %1855 to i64
  %3867 = mul i64 %3866, 4
  %3868 = sub i64 %3865, %3867
  %3869 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %3870 = select i1 %3869, i64 %3868, i64 0
  %private.contiguous.address465 = getelementptr i8, ptr %3864, i64 %3870
  %private.contiguous.preserve466 = load <8 x float>, ptr %private.contiguous.address465, align 4
  %3871 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3512, <8 x float> %private.contiguous.preserve466
  store <8 x float> %3871, ptr %private.contiguous.address465, align 4
  %3872 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3873 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3874 = add <8 x i64> %3873, splat (i64 416)
  %3875 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3872, 0
  %3876 = insertvalue { <8 x ptr>, <8 x i64> } %3875, <8 x i64> %3874, 1
  %3877 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3878 = extractvalue { <8 x ptr>, <8 x i64> } %3876, 1
  %3879 = extractelement <8 x ptr> %3877, i32 0
  %3880 = extractelement <8 x i64> %3878, i32 %1855
  %3881 = zext i32 %1855 to i64
  %3882 = mul i64 %3881, 4
  %3883 = sub i64 %3880, %3882
  %3884 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %3885 = select i1 %3884, i64 %3883, i64 0
  %private.contiguous.address467 = getelementptr i8, ptr %3879, i64 %3885
  %private.contiguous.preserve468 = load <8 x float>, ptr %private.contiguous.address467, align 4
  %3886 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3515, <8 x float> %private.contiguous.preserve468
  store <8 x float> %3886, ptr %private.contiguous.address467, align 4
  %3887 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3888 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3889 = add <8 x i64> %3888, splat (i64 448)
  %3890 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3887, 0
  %3891 = insertvalue { <8 x ptr>, <8 x i64> } %3890, <8 x i64> %3889, 1
  %3892 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3893 = extractvalue { <8 x ptr>, <8 x i64> } %3891, 1
  %3894 = extractelement <8 x ptr> %3892, i32 0
  %3895 = extractelement <8 x i64> %3893, i32 %1855
  %3896 = zext i32 %1855 to i64
  %3897 = mul i64 %3896, 4
  %3898 = sub i64 %3895, %3897
  %3899 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %3900 = select i1 %3899, i64 %3898, i64 0
  %private.contiguous.address469 = getelementptr i8, ptr %3894, i64 %3900
  %private.contiguous.preserve470 = load <8 x float>, ptr %private.contiguous.address469, align 4
  %3901 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3518, <8 x float> %private.contiguous.preserve470
  store <8 x float> %3901, ptr %private.contiguous.address469, align 4
  %3902 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3903 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3904 = add <8 x i64> %3903, splat (i64 480)
  %3905 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3902, 0
  %3906 = insertvalue { <8 x ptr>, <8 x i64> } %3905, <8 x i64> %3904, 1
  %3907 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3908 = extractvalue { <8 x ptr>, <8 x i64> } %3906, 1
  %3909 = extractelement <8 x ptr> %3907, i32 0
  %3910 = extractelement <8 x i64> %3908, i32 %1855
  %3911 = zext i32 %1855 to i64
  %3912 = mul i64 %3911, 4
  %3913 = sub i64 %3910, %3912
  %3914 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %3915 = select i1 %3914, i64 %3913, i64 0
  %private.contiguous.address471 = getelementptr i8, ptr %3909, i64 %3915
  %private.contiguous.preserve472 = load <8 x float>, ptr %private.contiguous.address471, align 4
  %3916 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3521, <8 x float> %private.contiguous.preserve472
  store <8 x float> %3916, ptr %private.contiguous.address471, align 4
  %3917 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3918 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3919 = add <8 x i64> %3918, splat (i64 512)
  %3920 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3917, 0
  %3921 = insertvalue { <8 x ptr>, <8 x i64> } %3920, <8 x i64> %3919, 1
  %3922 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3923 = extractvalue { <8 x ptr>, <8 x i64> } %3921, 1
  %3924 = extractelement <8 x ptr> %3922, i32 0
  %3925 = extractelement <8 x i64> %3923, i32 %1855
  %3926 = zext i32 %1855 to i64
  %3927 = mul i64 %3926, 4
  %3928 = sub i64 %3925, %3927
  %3929 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %3930 = select i1 %3929, i64 %3928, i64 0
  %private.contiguous.address473 = getelementptr i8, ptr %3924, i64 %3930
  %private.contiguous.preserve474 = load <8 x float>, ptr %private.contiguous.address473, align 4
  %3931 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3524, <8 x float> %private.contiguous.preserve474
  store <8 x float> %3931, ptr %private.contiguous.address473, align 4
  %3932 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3933 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3934 = add <8 x i64> %3933, splat (i64 544)
  %3935 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3932, 0
  %3936 = insertvalue { <8 x ptr>, <8 x i64> } %3935, <8 x i64> %3934, 1
  %3937 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3938 = extractvalue { <8 x ptr>, <8 x i64> } %3936, 1
  %3939 = extractelement <8 x ptr> %3937, i32 0
  %3940 = extractelement <8 x i64> %3938, i32 %1855
  %3941 = zext i32 %1855 to i64
  %3942 = mul i64 %3941, 4
  %3943 = sub i64 %3940, %3942
  %3944 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %3945 = select i1 %3944, i64 %3943, i64 0
  %private.contiguous.address475 = getelementptr i8, ptr %3939, i64 %3945
  %private.contiguous.preserve476 = load <8 x float>, ptr %private.contiguous.address475, align 4
  %3946 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3527, <8 x float> %private.contiguous.preserve476
  store <8 x float> %3946, ptr %private.contiguous.address475, align 4
  %3947 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3948 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3949 = add <8 x i64> %3948, splat (i64 576)
  %3950 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3947, 0
  %3951 = insertvalue { <8 x ptr>, <8 x i64> } %3950, <8 x i64> %3949, 1
  %3952 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3953 = extractvalue { <8 x ptr>, <8 x i64> } %3951, 1
  %3954 = extractelement <8 x ptr> %3952, i32 0
  %3955 = extractelement <8 x i64> %3953, i32 %1855
  %3956 = zext i32 %1855 to i64
  %3957 = mul i64 %3956, 4
  %3958 = sub i64 %3955, %3957
  %3959 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %3960 = select i1 %3959, i64 %3958, i64 0
  %private.contiguous.address477 = getelementptr i8, ptr %3954, i64 %3960
  %private.contiguous.preserve478 = load <8 x float>, ptr %private.contiguous.address477, align 4
  %3961 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3530, <8 x float> %private.contiguous.preserve478
  store <8 x float> %3961, ptr %private.contiguous.address477, align 4
  %3962 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3963 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3964 = add <8 x i64> %3963, splat (i64 608)
  %3965 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3962, 0
  %3966 = insertvalue { <8 x ptr>, <8 x i64> } %3965, <8 x i64> %3964, 1
  %3967 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3968 = extractvalue { <8 x ptr>, <8 x i64> } %3966, 1
  %3969 = extractelement <8 x ptr> %3967, i32 0
  %3970 = extractelement <8 x i64> %3968, i32 %1855
  %3971 = zext i32 %1855 to i64
  %3972 = mul i64 %3971, 4
  %3973 = sub i64 %3970, %3972
  %3974 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %3975 = select i1 %3974, i64 %3973, i64 0
  %private.contiguous.address479 = getelementptr i8, ptr %3969, i64 %3975
  %private.contiguous.preserve480 = load <8 x float>, ptr %private.contiguous.address479, align 4
  %3976 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3533, <8 x float> %private.contiguous.preserve480
  store <8 x float> %3976, ptr %private.contiguous.address479, align 4
  %3977 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3978 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3979 = add <8 x i64> %3978, splat (i64 640)
  %3980 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3977, 0
  %3981 = insertvalue { <8 x ptr>, <8 x i64> } %3980, <8 x i64> %3979, 1
  %3982 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3983 = extractvalue { <8 x ptr>, <8 x i64> } %3981, 1
  %3984 = extractelement <8 x ptr> %3982, i32 0
  %3985 = extractelement <8 x i64> %3983, i32 %1855
  %3986 = zext i32 %1855 to i64
  %3987 = mul i64 %3986, 4
  %3988 = sub i64 %3985, %3987
  %3989 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %3990 = select i1 %3989, i64 %3988, i64 0
  %private.contiguous.address481 = getelementptr i8, ptr %3984, i64 %3990
  %private.contiguous.preserve482 = load <8 x float>, ptr %private.contiguous.address481, align 4
  %3991 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3536, <8 x float> %private.contiguous.preserve482
  store <8 x float> %3991, ptr %private.contiguous.address481, align 4
  %3992 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3993 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3994 = add <8 x i64> %3993, splat (i64 672)
  %3995 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3992, 0
  %3996 = insertvalue { <8 x ptr>, <8 x i64> } %3995, <8 x i64> %3994, 1
  %3997 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3998 = extractvalue { <8 x ptr>, <8 x i64> } %3996, 1
  %3999 = extractelement <8 x ptr> %3997, i32 0
  %4000 = extractelement <8 x i64> %3998, i32 %1855
  %4001 = zext i32 %1855 to i64
  %4002 = mul i64 %4001, 4
  %4003 = sub i64 %4000, %4002
  %4004 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4005 = select i1 %4004, i64 %4003, i64 0
  %private.contiguous.address483 = getelementptr i8, ptr %3999, i64 %4005
  %private.contiguous.preserve484 = load <8 x float>, ptr %private.contiguous.address483, align 4
  %4006 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3539, <8 x float> %private.contiguous.preserve484
  store <8 x float> %4006, ptr %private.contiguous.address483, align 4
  %4007 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4008 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4009 = add <8 x i64> %4008, splat (i64 704)
  %4010 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4007, 0
  %4011 = insertvalue { <8 x ptr>, <8 x i64> } %4010, <8 x i64> %4009, 1
  %4012 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4013 = extractvalue { <8 x ptr>, <8 x i64> } %4011, 1
  %4014 = extractelement <8 x ptr> %4012, i32 0
  %4015 = extractelement <8 x i64> %4013, i32 %1855
  %4016 = zext i32 %1855 to i64
  %4017 = mul i64 %4016, 4
  %4018 = sub i64 %4015, %4017
  %4019 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4020 = select i1 %4019, i64 %4018, i64 0
  %private.contiguous.address485 = getelementptr i8, ptr %4014, i64 %4020
  %private.contiguous.preserve486 = load <8 x float>, ptr %private.contiguous.address485, align 4
  %4021 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3542, <8 x float> %private.contiguous.preserve486
  store <8 x float> %4021, ptr %private.contiguous.address485, align 4
  %4022 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4023 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4024 = add <8 x i64> %4023, splat (i64 736)
  %4025 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4022, 0
  %4026 = insertvalue { <8 x ptr>, <8 x i64> } %4025, <8 x i64> %4024, 1
  %4027 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4028 = extractvalue { <8 x ptr>, <8 x i64> } %4026, 1
  %4029 = extractelement <8 x ptr> %4027, i32 0
  %4030 = extractelement <8 x i64> %4028, i32 %1855
  %4031 = zext i32 %1855 to i64
  %4032 = mul i64 %4031, 4
  %4033 = sub i64 %4030, %4032
  %4034 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4035 = select i1 %4034, i64 %4033, i64 0
  %private.contiguous.address487 = getelementptr i8, ptr %4029, i64 %4035
  %private.contiguous.preserve488 = load <8 x float>, ptr %private.contiguous.address487, align 4
  %4036 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3545, <8 x float> %private.contiguous.preserve488
  store <8 x float> %4036, ptr %private.contiguous.address487, align 4
  %4037 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4038 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4039 = add <8 x i64> %4038, splat (i64 768)
  %4040 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4037, 0
  %4041 = insertvalue { <8 x ptr>, <8 x i64> } %4040, <8 x i64> %4039, 1
  %4042 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4043 = extractvalue { <8 x ptr>, <8 x i64> } %4041, 1
  %4044 = extractelement <8 x ptr> %4042, i32 0
  %4045 = extractelement <8 x i64> %4043, i32 %1855
  %4046 = zext i32 %1855 to i64
  %4047 = mul i64 %4046, 4
  %4048 = sub i64 %4045, %4047
  %4049 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4050 = select i1 %4049, i64 %4048, i64 0
  %private.contiguous.address489 = getelementptr i8, ptr %4044, i64 %4050
  %private.contiguous.preserve490 = load <8 x float>, ptr %private.contiguous.address489, align 4
  %4051 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3548, <8 x float> %private.contiguous.preserve490
  store <8 x float> %4051, ptr %private.contiguous.address489, align 4
  %4052 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4053 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4054 = add <8 x i64> %4053, splat (i64 800)
  %4055 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4052, 0
  %4056 = insertvalue { <8 x ptr>, <8 x i64> } %4055, <8 x i64> %4054, 1
  %4057 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4058 = extractvalue { <8 x ptr>, <8 x i64> } %4056, 1
  %4059 = extractelement <8 x ptr> %4057, i32 0
  %4060 = extractelement <8 x i64> %4058, i32 %1855
  %4061 = zext i32 %1855 to i64
  %4062 = mul i64 %4061, 4
  %4063 = sub i64 %4060, %4062
  %4064 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4065 = select i1 %4064, i64 %4063, i64 0
  %private.contiguous.address491 = getelementptr i8, ptr %4059, i64 %4065
  %private.contiguous.preserve492 = load <8 x float>, ptr %private.contiguous.address491, align 4
  %4066 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3551, <8 x float> %private.contiguous.preserve492
  store <8 x float> %4066, ptr %private.contiguous.address491, align 4
  %4067 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4068 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4069 = add <8 x i64> %4068, splat (i64 832)
  %4070 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4067, 0
  %4071 = insertvalue { <8 x ptr>, <8 x i64> } %4070, <8 x i64> %4069, 1
  %4072 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4073 = extractvalue { <8 x ptr>, <8 x i64> } %4071, 1
  %4074 = extractelement <8 x ptr> %4072, i32 0
  %4075 = extractelement <8 x i64> %4073, i32 %1855
  %4076 = zext i32 %1855 to i64
  %4077 = mul i64 %4076, 4
  %4078 = sub i64 %4075, %4077
  %4079 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4080 = select i1 %4079, i64 %4078, i64 0
  %private.contiguous.address493 = getelementptr i8, ptr %4074, i64 %4080
  %private.contiguous.preserve494 = load <8 x float>, ptr %private.contiguous.address493, align 4
  %4081 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3554, <8 x float> %private.contiguous.preserve494
  store <8 x float> %4081, ptr %private.contiguous.address493, align 4
  %4082 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4083 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4084 = add <8 x i64> %4083, splat (i64 864)
  %4085 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4082, 0
  %4086 = insertvalue { <8 x ptr>, <8 x i64> } %4085, <8 x i64> %4084, 1
  %4087 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4088 = extractvalue { <8 x ptr>, <8 x i64> } %4086, 1
  %4089 = extractelement <8 x ptr> %4087, i32 0
  %4090 = extractelement <8 x i64> %4088, i32 %1855
  %4091 = zext i32 %1855 to i64
  %4092 = mul i64 %4091, 4
  %4093 = sub i64 %4090, %4092
  %4094 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4095 = select i1 %4094, i64 %4093, i64 0
  %private.contiguous.address495 = getelementptr i8, ptr %4089, i64 %4095
  %private.contiguous.preserve496 = load <8 x float>, ptr %private.contiguous.address495, align 4
  %4096 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3557, <8 x float> %private.contiguous.preserve496
  store <8 x float> %4096, ptr %private.contiguous.address495, align 4
  %4097 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4098 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4099 = add <8 x i64> %4098, splat (i64 896)
  %4100 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4097, 0
  %4101 = insertvalue { <8 x ptr>, <8 x i64> } %4100, <8 x i64> %4099, 1
  %4102 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4103 = extractvalue { <8 x ptr>, <8 x i64> } %4101, 1
  %4104 = extractelement <8 x ptr> %4102, i32 0
  %4105 = extractelement <8 x i64> %4103, i32 %1855
  %4106 = zext i32 %1855 to i64
  %4107 = mul i64 %4106, 4
  %4108 = sub i64 %4105, %4107
  %4109 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4110 = select i1 %4109, i64 %4108, i64 0
  %private.contiguous.address497 = getelementptr i8, ptr %4104, i64 %4110
  %private.contiguous.preserve498 = load <8 x float>, ptr %private.contiguous.address497, align 4
  %4111 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3560, <8 x float> %private.contiguous.preserve498
  store <8 x float> %4111, ptr %private.contiguous.address497, align 4
  %4112 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4113 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4114 = add <8 x i64> %4113, splat (i64 928)
  %4115 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4112, 0
  %4116 = insertvalue { <8 x ptr>, <8 x i64> } %4115, <8 x i64> %4114, 1
  %4117 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4118 = extractvalue { <8 x ptr>, <8 x i64> } %4116, 1
  %4119 = extractelement <8 x ptr> %4117, i32 0
  %4120 = extractelement <8 x i64> %4118, i32 %1855
  %4121 = zext i32 %1855 to i64
  %4122 = mul i64 %4121, 4
  %4123 = sub i64 %4120, %4122
  %4124 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4125 = select i1 %4124, i64 %4123, i64 0
  %private.contiguous.address499 = getelementptr i8, ptr %4119, i64 %4125
  %private.contiguous.preserve500 = load <8 x float>, ptr %private.contiguous.address499, align 4
  %4126 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3563, <8 x float> %private.contiguous.preserve500
  store <8 x float> %4126, ptr %private.contiguous.address499, align 4
  %4127 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4128 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4129 = add <8 x i64> %4128, splat (i64 960)
  %4130 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4127, 0
  %4131 = insertvalue { <8 x ptr>, <8 x i64> } %4130, <8 x i64> %4129, 1
  %4132 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4133 = extractvalue { <8 x ptr>, <8 x i64> } %4131, 1
  %4134 = extractelement <8 x ptr> %4132, i32 0
  %4135 = extractelement <8 x i64> %4133, i32 %1855
  %4136 = zext i32 %1855 to i64
  %4137 = mul i64 %4136, 4
  %4138 = sub i64 %4135, %4137
  %4139 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4140 = select i1 %4139, i64 %4138, i64 0
  %private.contiguous.address501 = getelementptr i8, ptr %4134, i64 %4140
  %private.contiguous.preserve502 = load <8 x float>, ptr %private.contiguous.address501, align 4
  %4141 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3566, <8 x float> %private.contiguous.preserve502
  store <8 x float> %4141, ptr %private.contiguous.address501, align 4
  %4142 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4143 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4144 = add <8 x i64> %4143, splat (i64 992)
  %4145 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4142, 0
  %4146 = insertvalue { <8 x ptr>, <8 x i64> } %4145, <8 x i64> %4144, 1
  %4147 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4148 = extractvalue { <8 x ptr>, <8 x i64> } %4146, 1
  %4149 = extractelement <8 x ptr> %4147, i32 0
  %4150 = extractelement <8 x i64> %4148, i32 %1855
  %4151 = zext i32 %1855 to i64
  %4152 = mul i64 %4151, 4
  %4153 = sub i64 %4150, %4152
  %4154 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4155 = select i1 %4154, i64 %4153, i64 0
  %private.contiguous.address503 = getelementptr i8, ptr %4149, i64 %4155
  %private.contiguous.preserve504 = load <8 x float>, ptr %private.contiguous.address503, align 4
  %4156 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3569, <8 x float> %private.contiguous.preserve504
  store <8 x float> %4156, ptr %private.contiguous.address503, align 4
  %4157 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4158 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4159 = add <8 x i64> %4158, splat (i64 1024)
  %4160 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4157, 0
  %4161 = insertvalue { <8 x ptr>, <8 x i64> } %4160, <8 x i64> %4159, 1
  %4162 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4163 = extractvalue { <8 x ptr>, <8 x i64> } %4161, 1
  %4164 = extractelement <8 x ptr> %4162, i32 0
  %4165 = extractelement <8 x i64> %4163, i32 %1855
  %4166 = zext i32 %1855 to i64
  %4167 = mul i64 %4166, 4
  %4168 = sub i64 %4165, %4167
  %4169 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4170 = select i1 %4169, i64 %4168, i64 0
  %private.contiguous.address505 = getelementptr i8, ptr %4164, i64 %4170
  %private.contiguous.preserve506 = load <8 x float>, ptr %private.contiguous.address505, align 4
  %4171 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3572, <8 x float> %private.contiguous.preserve506
  store <8 x float> %4171, ptr %private.contiguous.address505, align 4
  %4172 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4173 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4174 = add <8 x i64> %4173, splat (i64 1056)
  %4175 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4172, 0
  %4176 = insertvalue { <8 x ptr>, <8 x i64> } %4175, <8 x i64> %4174, 1
  %4177 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4178 = extractvalue { <8 x ptr>, <8 x i64> } %4176, 1
  %4179 = extractelement <8 x ptr> %4177, i32 0
  %4180 = extractelement <8 x i64> %4178, i32 %1855
  %4181 = zext i32 %1855 to i64
  %4182 = mul i64 %4181, 4
  %4183 = sub i64 %4180, %4182
  %4184 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4185 = select i1 %4184, i64 %4183, i64 0
  %private.contiguous.address507 = getelementptr i8, ptr %4179, i64 %4185
  %private.contiguous.preserve508 = load <8 x float>, ptr %private.contiguous.address507, align 4
  %4186 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3575, <8 x float> %private.contiguous.preserve508
  store <8 x float> %4186, ptr %private.contiguous.address507, align 4
  %4187 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4188 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4189 = add <8 x i64> %4188, splat (i64 1088)
  %4190 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4187, 0
  %4191 = insertvalue { <8 x ptr>, <8 x i64> } %4190, <8 x i64> %4189, 1
  %4192 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4193 = extractvalue { <8 x ptr>, <8 x i64> } %4191, 1
  %4194 = extractelement <8 x ptr> %4192, i32 0
  %4195 = extractelement <8 x i64> %4193, i32 %1855
  %4196 = zext i32 %1855 to i64
  %4197 = mul i64 %4196, 4
  %4198 = sub i64 %4195, %4197
  %4199 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4200 = select i1 %4199, i64 %4198, i64 0
  %private.contiguous.address509 = getelementptr i8, ptr %4194, i64 %4200
  %private.contiguous.preserve510 = load <8 x float>, ptr %private.contiguous.address509, align 4
  %4201 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3578, <8 x float> %private.contiguous.preserve510
  store <8 x float> %4201, ptr %private.contiguous.address509, align 4
  %4202 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4203 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4204 = add <8 x i64> %4203, splat (i64 1120)
  %4205 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4202, 0
  %4206 = insertvalue { <8 x ptr>, <8 x i64> } %4205, <8 x i64> %4204, 1
  %4207 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4208 = extractvalue { <8 x ptr>, <8 x i64> } %4206, 1
  %4209 = extractelement <8 x ptr> %4207, i32 0
  %4210 = extractelement <8 x i64> %4208, i32 %1855
  %4211 = zext i32 %1855 to i64
  %4212 = mul i64 %4211, 4
  %4213 = sub i64 %4210, %4212
  %4214 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4215 = select i1 %4214, i64 %4213, i64 0
  %private.contiguous.address511 = getelementptr i8, ptr %4209, i64 %4215
  %private.contiguous.preserve512 = load <8 x float>, ptr %private.contiguous.address511, align 4
  %4216 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3581, <8 x float> %private.contiguous.preserve512
  store <8 x float> %4216, ptr %private.contiguous.address511, align 4
  %4217 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4218 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4219 = add <8 x i64> %4218, splat (i64 1152)
  %4220 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4217, 0
  %4221 = insertvalue { <8 x ptr>, <8 x i64> } %4220, <8 x i64> %4219, 1
  %4222 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4223 = extractvalue { <8 x ptr>, <8 x i64> } %4221, 1
  %4224 = extractelement <8 x ptr> %4222, i32 0
  %4225 = extractelement <8 x i64> %4223, i32 %1855
  %4226 = zext i32 %1855 to i64
  %4227 = mul i64 %4226, 4
  %4228 = sub i64 %4225, %4227
  %4229 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4230 = select i1 %4229, i64 %4228, i64 0
  %private.contiguous.address513 = getelementptr i8, ptr %4224, i64 %4230
  %private.contiguous.preserve514 = load <8 x float>, ptr %private.contiguous.address513, align 4
  %4231 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3584, <8 x float> %private.contiguous.preserve514
  store <8 x float> %4231, ptr %private.contiguous.address513, align 4
  %4232 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4233 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4234 = add <8 x i64> %4233, splat (i64 1184)
  %4235 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4232, 0
  %4236 = insertvalue { <8 x ptr>, <8 x i64> } %4235, <8 x i64> %4234, 1
  %4237 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4238 = extractvalue { <8 x ptr>, <8 x i64> } %4236, 1
  %4239 = extractelement <8 x ptr> %4237, i32 0
  %4240 = extractelement <8 x i64> %4238, i32 %1855
  %4241 = zext i32 %1855 to i64
  %4242 = mul i64 %4241, 4
  %4243 = sub i64 %4240, %4242
  %4244 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4245 = select i1 %4244, i64 %4243, i64 0
  %private.contiguous.address515 = getelementptr i8, ptr %4239, i64 %4245
  %private.contiguous.preserve516 = load <8 x float>, ptr %private.contiguous.address515, align 4
  %4246 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3587, <8 x float> %private.contiguous.preserve516
  store <8 x float> %4246, ptr %private.contiguous.address515, align 4
  %4247 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4248 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4249 = add <8 x i64> %4248, splat (i64 1216)
  %4250 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4247, 0
  %4251 = insertvalue { <8 x ptr>, <8 x i64> } %4250, <8 x i64> %4249, 1
  %4252 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4253 = extractvalue { <8 x ptr>, <8 x i64> } %4251, 1
  %4254 = extractelement <8 x ptr> %4252, i32 0
  %4255 = extractelement <8 x i64> %4253, i32 %1855
  %4256 = zext i32 %1855 to i64
  %4257 = mul i64 %4256, 4
  %4258 = sub i64 %4255, %4257
  %4259 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4260 = select i1 %4259, i64 %4258, i64 0
  %private.contiguous.address517 = getelementptr i8, ptr %4254, i64 %4260
  %private.contiguous.preserve518 = load <8 x float>, ptr %private.contiguous.address517, align 4
  %4261 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3590, <8 x float> %private.contiguous.preserve518
  store <8 x float> %4261, ptr %private.contiguous.address517, align 4
  %4262 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4263 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4264 = add <8 x i64> %4263, splat (i64 1248)
  %4265 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4262, 0
  %4266 = insertvalue { <8 x ptr>, <8 x i64> } %4265, <8 x i64> %4264, 1
  %4267 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4268 = extractvalue { <8 x ptr>, <8 x i64> } %4266, 1
  %4269 = extractelement <8 x ptr> %4267, i32 0
  %4270 = extractelement <8 x i64> %4268, i32 %1855
  %4271 = zext i32 %1855 to i64
  %4272 = mul i64 %4271, 4
  %4273 = sub i64 %4270, %4272
  %4274 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4275 = select i1 %4274, i64 %4273, i64 0
  %private.contiguous.address519 = getelementptr i8, ptr %4269, i64 %4275
  %private.contiguous.preserve520 = load <8 x float>, ptr %private.contiguous.address519, align 4
  %4276 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3593, <8 x float> %private.contiguous.preserve520
  store <8 x float> %4276, ptr %private.contiguous.address519, align 4
  %4277 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4278 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4279 = add <8 x i64> %4278, splat (i64 1280)
  %4280 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4277, 0
  %4281 = insertvalue { <8 x ptr>, <8 x i64> } %4280, <8 x i64> %4279, 1
  %4282 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4283 = extractvalue { <8 x ptr>, <8 x i64> } %4281, 1
  %4284 = extractelement <8 x ptr> %4282, i32 0
  %4285 = extractelement <8 x i64> %4283, i32 %1855
  %4286 = zext i32 %1855 to i64
  %4287 = mul i64 %4286, 4
  %4288 = sub i64 %4285, %4287
  %4289 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4290 = select i1 %4289, i64 %4288, i64 0
  %private.contiguous.address521 = getelementptr i8, ptr %4284, i64 %4290
  %private.contiguous.preserve522 = load <8 x float>, ptr %private.contiguous.address521, align 4
  %4291 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3596, <8 x float> %private.contiguous.preserve522
  store <8 x float> %4291, ptr %private.contiguous.address521, align 4
  %4292 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4293 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4294 = add <8 x i64> %4293, splat (i64 1312)
  %4295 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4292, 0
  %4296 = insertvalue { <8 x ptr>, <8 x i64> } %4295, <8 x i64> %4294, 1
  %4297 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4298 = extractvalue { <8 x ptr>, <8 x i64> } %4296, 1
  %4299 = extractelement <8 x ptr> %4297, i32 0
  %4300 = extractelement <8 x i64> %4298, i32 %1855
  %4301 = zext i32 %1855 to i64
  %4302 = mul i64 %4301, 4
  %4303 = sub i64 %4300, %4302
  %4304 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4305 = select i1 %4304, i64 %4303, i64 0
  %private.contiguous.address523 = getelementptr i8, ptr %4299, i64 %4305
  %private.contiguous.preserve524 = load <8 x float>, ptr %private.contiguous.address523, align 4
  %4306 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3599, <8 x float> %private.contiguous.preserve524
  store <8 x float> %4306, ptr %private.contiguous.address523, align 4
  %4307 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4308 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4309 = add <8 x i64> %4308, splat (i64 1344)
  %4310 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4307, 0
  %4311 = insertvalue { <8 x ptr>, <8 x i64> } %4310, <8 x i64> %4309, 1
  %4312 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4313 = extractvalue { <8 x ptr>, <8 x i64> } %4311, 1
  %4314 = extractelement <8 x ptr> %4312, i32 0
  %4315 = extractelement <8 x i64> %4313, i32 %1855
  %4316 = zext i32 %1855 to i64
  %4317 = mul i64 %4316, 4
  %4318 = sub i64 %4315, %4317
  %4319 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4320 = select i1 %4319, i64 %4318, i64 0
  %private.contiguous.address525 = getelementptr i8, ptr %4314, i64 %4320
  %private.contiguous.preserve526 = load <8 x float>, ptr %private.contiguous.address525, align 4
  %4321 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3602, <8 x float> %private.contiguous.preserve526
  store <8 x float> %4321, ptr %private.contiguous.address525, align 4
  %4322 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4323 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4324 = add <8 x i64> %4323, splat (i64 1376)
  %4325 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4322, 0
  %4326 = insertvalue { <8 x ptr>, <8 x i64> } %4325, <8 x i64> %4324, 1
  %4327 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4328 = extractvalue { <8 x ptr>, <8 x i64> } %4326, 1
  %4329 = extractelement <8 x ptr> %4327, i32 0
  %4330 = extractelement <8 x i64> %4328, i32 %1855
  %4331 = zext i32 %1855 to i64
  %4332 = mul i64 %4331, 4
  %4333 = sub i64 %4330, %4332
  %4334 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4335 = select i1 %4334, i64 %4333, i64 0
  %private.contiguous.address527 = getelementptr i8, ptr %4329, i64 %4335
  %private.contiguous.preserve528 = load <8 x float>, ptr %private.contiguous.address527, align 4
  %4336 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3605, <8 x float> %private.contiguous.preserve528
  store <8 x float> %4336, ptr %private.contiguous.address527, align 4
  %4337 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4338 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4339 = add <8 x i64> %4338, splat (i64 1408)
  %4340 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4337, 0
  %4341 = insertvalue { <8 x ptr>, <8 x i64> } %4340, <8 x i64> %4339, 1
  %4342 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4343 = extractvalue { <8 x ptr>, <8 x i64> } %4341, 1
  %4344 = extractelement <8 x ptr> %4342, i32 0
  %4345 = extractelement <8 x i64> %4343, i32 %1855
  %4346 = zext i32 %1855 to i64
  %4347 = mul i64 %4346, 4
  %4348 = sub i64 %4345, %4347
  %4349 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4350 = select i1 %4349, i64 %4348, i64 0
  %private.contiguous.address529 = getelementptr i8, ptr %4344, i64 %4350
  %private.contiguous.preserve530 = load <8 x float>, ptr %private.contiguous.address529, align 4
  %4351 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3608, <8 x float> %private.contiguous.preserve530
  store <8 x float> %4351, ptr %private.contiguous.address529, align 4
  %4352 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4353 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4354 = add <8 x i64> %4353, splat (i64 1440)
  %4355 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4352, 0
  %4356 = insertvalue { <8 x ptr>, <8 x i64> } %4355, <8 x i64> %4354, 1
  %4357 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4358 = extractvalue { <8 x ptr>, <8 x i64> } %4356, 1
  %4359 = extractelement <8 x ptr> %4357, i32 0
  %4360 = extractelement <8 x i64> %4358, i32 %1855
  %4361 = zext i32 %1855 to i64
  %4362 = mul i64 %4361, 4
  %4363 = sub i64 %4360, %4362
  %4364 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4365 = select i1 %4364, i64 %4363, i64 0
  %private.contiguous.address531 = getelementptr i8, ptr %4359, i64 %4365
  %private.contiguous.preserve532 = load <8 x float>, ptr %private.contiguous.address531, align 4
  %4366 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3611, <8 x float> %private.contiguous.preserve532
  store <8 x float> %4366, ptr %private.contiguous.address531, align 4
  %4367 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4368 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4369 = add <8 x i64> %4368, splat (i64 1472)
  %4370 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4367, 0
  %4371 = insertvalue { <8 x ptr>, <8 x i64> } %4370, <8 x i64> %4369, 1
  %4372 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4373 = extractvalue { <8 x ptr>, <8 x i64> } %4371, 1
  %4374 = extractelement <8 x ptr> %4372, i32 0
  %4375 = extractelement <8 x i64> %4373, i32 %1855
  %4376 = zext i32 %1855 to i64
  %4377 = mul i64 %4376, 4
  %4378 = sub i64 %4375, %4377
  %4379 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4380 = select i1 %4379, i64 %4378, i64 0
  %private.contiguous.address533 = getelementptr i8, ptr %4374, i64 %4380
  %private.contiguous.preserve534 = load <8 x float>, ptr %private.contiguous.address533, align 4
  %4381 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3614, <8 x float> %private.contiguous.preserve534
  store <8 x float> %4381, ptr %private.contiguous.address533, align 4
  %4382 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4383 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4384 = add <8 x i64> %4383, splat (i64 1504)
  %4385 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4382, 0
  %4386 = insertvalue { <8 x ptr>, <8 x i64> } %4385, <8 x i64> %4384, 1
  %4387 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4388 = extractvalue { <8 x ptr>, <8 x i64> } %4386, 1
  %4389 = extractelement <8 x ptr> %4387, i32 0
  %4390 = extractelement <8 x i64> %4388, i32 %1855
  %4391 = zext i32 %1855 to i64
  %4392 = mul i64 %4391, 4
  %4393 = sub i64 %4390, %4392
  %4394 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4395 = select i1 %4394, i64 %4393, i64 0
  %private.contiguous.address535 = getelementptr i8, ptr %4389, i64 %4395
  %private.contiguous.preserve536 = load <8 x float>, ptr %private.contiguous.address535, align 4
  %4396 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3617, <8 x float> %private.contiguous.preserve536
  store <8 x float> %4396, ptr %private.contiguous.address535, align 4
  %4397 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4398 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4399 = add <8 x i64> %4398, splat (i64 1536)
  %4400 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4397, 0
  %4401 = insertvalue { <8 x ptr>, <8 x i64> } %4400, <8 x i64> %4399, 1
  %4402 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4403 = extractvalue { <8 x ptr>, <8 x i64> } %4401, 1
  %4404 = extractelement <8 x ptr> %4402, i32 0
  %4405 = extractelement <8 x i64> %4403, i32 %1855
  %4406 = zext i32 %1855 to i64
  %4407 = mul i64 %4406, 4
  %4408 = sub i64 %4405, %4407
  %4409 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4410 = select i1 %4409, i64 %4408, i64 0
  %private.contiguous.address537 = getelementptr i8, ptr %4404, i64 %4410
  %private.contiguous.preserve538 = load <8 x float>, ptr %private.contiguous.address537, align 4
  %4411 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3620, <8 x float> %private.contiguous.preserve538
  store <8 x float> %4411, ptr %private.contiguous.address537, align 4
  %4412 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4413 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4414 = add <8 x i64> %4413, splat (i64 1568)
  %4415 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4412, 0
  %4416 = insertvalue { <8 x ptr>, <8 x i64> } %4415, <8 x i64> %4414, 1
  %4417 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4418 = extractvalue { <8 x ptr>, <8 x i64> } %4416, 1
  %4419 = extractelement <8 x ptr> %4417, i32 0
  %4420 = extractelement <8 x i64> %4418, i32 %1855
  %4421 = zext i32 %1855 to i64
  %4422 = mul i64 %4421, 4
  %4423 = sub i64 %4420, %4422
  %4424 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4425 = select i1 %4424, i64 %4423, i64 0
  %private.contiguous.address539 = getelementptr i8, ptr %4419, i64 %4425
  %private.contiguous.preserve540 = load <8 x float>, ptr %private.contiguous.address539, align 4
  %4426 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3623, <8 x float> %private.contiguous.preserve540
  store <8 x float> %4426, ptr %private.contiguous.address539, align 4
  %4427 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4428 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4429 = add <8 x i64> %4428, splat (i64 1600)
  %4430 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4427, 0
  %4431 = insertvalue { <8 x ptr>, <8 x i64> } %4430, <8 x i64> %4429, 1
  %4432 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4433 = extractvalue { <8 x ptr>, <8 x i64> } %4431, 1
  %4434 = extractelement <8 x ptr> %4432, i32 0
  %4435 = extractelement <8 x i64> %4433, i32 %1855
  %4436 = zext i32 %1855 to i64
  %4437 = mul i64 %4436, 4
  %4438 = sub i64 %4435, %4437
  %4439 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4440 = select i1 %4439, i64 %4438, i64 0
  %private.contiguous.address541 = getelementptr i8, ptr %4434, i64 %4440
  %private.contiguous.preserve542 = load <8 x float>, ptr %private.contiguous.address541, align 4
  %4441 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3626, <8 x float> %private.contiguous.preserve542
  store <8 x float> %4441, ptr %private.contiguous.address541, align 4
  %4442 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4443 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4444 = add <8 x i64> %4443, splat (i64 1632)
  %4445 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4442, 0
  %4446 = insertvalue { <8 x ptr>, <8 x i64> } %4445, <8 x i64> %4444, 1
  %4447 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4448 = extractvalue { <8 x ptr>, <8 x i64> } %4446, 1
  %4449 = extractelement <8 x ptr> %4447, i32 0
  %4450 = extractelement <8 x i64> %4448, i32 %1855
  %4451 = zext i32 %1855 to i64
  %4452 = mul i64 %4451, 4
  %4453 = sub i64 %4450, %4452
  %4454 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4455 = select i1 %4454, i64 %4453, i64 0
  %private.contiguous.address543 = getelementptr i8, ptr %4449, i64 %4455
  %private.contiguous.preserve544 = load <8 x float>, ptr %private.contiguous.address543, align 4
  %4456 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3629, <8 x float> %private.contiguous.preserve544
  store <8 x float> %4456, ptr %private.contiguous.address543, align 4
  %4457 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4458 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4459 = add <8 x i64> %4458, splat (i64 1664)
  %4460 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4457, 0
  %4461 = insertvalue { <8 x ptr>, <8 x i64> } %4460, <8 x i64> %4459, 1
  %4462 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4463 = extractvalue { <8 x ptr>, <8 x i64> } %4461, 1
  %4464 = extractelement <8 x ptr> %4462, i32 0
  %4465 = extractelement <8 x i64> %4463, i32 %1855
  %4466 = zext i32 %1855 to i64
  %4467 = mul i64 %4466, 4
  %4468 = sub i64 %4465, %4467
  %4469 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4470 = select i1 %4469, i64 %4468, i64 0
  %private.contiguous.address545 = getelementptr i8, ptr %4464, i64 %4470
  %private.contiguous.preserve546 = load <8 x float>, ptr %private.contiguous.address545, align 4
  %4471 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3632, <8 x float> %private.contiguous.preserve546
  store <8 x float> %4471, ptr %private.contiguous.address545, align 4
  %4472 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4473 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4474 = add <8 x i64> %4473, splat (i64 1696)
  %4475 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4472, 0
  %4476 = insertvalue { <8 x ptr>, <8 x i64> } %4475, <8 x i64> %4474, 1
  %4477 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4478 = extractvalue { <8 x ptr>, <8 x i64> } %4476, 1
  %4479 = extractelement <8 x ptr> %4477, i32 0
  %4480 = extractelement <8 x i64> %4478, i32 %1855
  %4481 = zext i32 %1855 to i64
  %4482 = mul i64 %4481, 4
  %4483 = sub i64 %4480, %4482
  %4484 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4485 = select i1 %4484, i64 %4483, i64 0
  %private.contiguous.address547 = getelementptr i8, ptr %4479, i64 %4485
  %private.contiguous.preserve548 = load <8 x float>, ptr %private.contiguous.address547, align 4
  %4486 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3635, <8 x float> %private.contiguous.preserve548
  store <8 x float> %4486, ptr %private.contiguous.address547, align 4
  %4487 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4488 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4489 = add <8 x i64> %4488, splat (i64 1728)
  %4490 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4487, 0
  %4491 = insertvalue { <8 x ptr>, <8 x i64> } %4490, <8 x i64> %4489, 1
  %4492 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4493 = extractvalue { <8 x ptr>, <8 x i64> } %4491, 1
  %4494 = extractelement <8 x ptr> %4492, i32 0
  %4495 = extractelement <8 x i64> %4493, i32 %1855
  %4496 = zext i32 %1855 to i64
  %4497 = mul i64 %4496, 4
  %4498 = sub i64 %4495, %4497
  %4499 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4500 = select i1 %4499, i64 %4498, i64 0
  %private.contiguous.address549 = getelementptr i8, ptr %4494, i64 %4500
  %private.contiguous.preserve550 = load <8 x float>, ptr %private.contiguous.address549, align 4
  %4501 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3638, <8 x float> %private.contiguous.preserve550
  store <8 x float> %4501, ptr %private.contiguous.address549, align 4
  %4502 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4503 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4504 = add <8 x i64> %4503, splat (i64 1760)
  %4505 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4502, 0
  %4506 = insertvalue { <8 x ptr>, <8 x i64> } %4505, <8 x i64> %4504, 1
  %4507 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4508 = extractvalue { <8 x ptr>, <8 x i64> } %4506, 1
  %4509 = extractelement <8 x ptr> %4507, i32 0
  %4510 = extractelement <8 x i64> %4508, i32 %1855
  %4511 = zext i32 %1855 to i64
  %4512 = mul i64 %4511, 4
  %4513 = sub i64 %4510, %4512
  %4514 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4515 = select i1 %4514, i64 %4513, i64 0
  %private.contiguous.address551 = getelementptr i8, ptr %4509, i64 %4515
  %private.contiguous.preserve552 = load <8 x float>, ptr %private.contiguous.address551, align 4
  %4516 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3641, <8 x float> %private.contiguous.preserve552
  store <8 x float> %4516, ptr %private.contiguous.address551, align 4
  %4517 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4518 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4519 = add <8 x i64> %4518, splat (i64 1792)
  %4520 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4517, 0
  %4521 = insertvalue { <8 x ptr>, <8 x i64> } %4520, <8 x i64> %4519, 1
  %4522 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4523 = extractvalue { <8 x ptr>, <8 x i64> } %4521, 1
  %4524 = extractelement <8 x ptr> %4522, i32 0
  %4525 = extractelement <8 x i64> %4523, i32 %1855
  %4526 = zext i32 %1855 to i64
  %4527 = mul i64 %4526, 4
  %4528 = sub i64 %4525, %4527
  %4529 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4530 = select i1 %4529, i64 %4528, i64 0
  %private.contiguous.address553 = getelementptr i8, ptr %4524, i64 %4530
  %private.contiguous.preserve554 = load <8 x float>, ptr %private.contiguous.address553, align 4
  %4531 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3644, <8 x float> %private.contiguous.preserve554
  store <8 x float> %4531, ptr %private.contiguous.address553, align 4
  %4532 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4533 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4534 = add <8 x i64> %4533, splat (i64 1824)
  %4535 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4532, 0
  %4536 = insertvalue { <8 x ptr>, <8 x i64> } %4535, <8 x i64> %4534, 1
  %4537 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4538 = extractvalue { <8 x ptr>, <8 x i64> } %4536, 1
  %4539 = extractelement <8 x ptr> %4537, i32 0
  %4540 = extractelement <8 x i64> %4538, i32 %1855
  %4541 = zext i32 %1855 to i64
  %4542 = mul i64 %4541, 4
  %4543 = sub i64 %4540, %4542
  %4544 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4545 = select i1 %4544, i64 %4543, i64 0
  %private.contiguous.address555 = getelementptr i8, ptr %4539, i64 %4545
  %private.contiguous.preserve556 = load <8 x float>, ptr %private.contiguous.address555, align 4
  %4546 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3647, <8 x float> %private.contiguous.preserve556
  store <8 x float> %4546, ptr %private.contiguous.address555, align 4
  %4547 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4548 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4549 = add <8 x i64> %4548, splat (i64 1856)
  %4550 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4547, 0
  %4551 = insertvalue { <8 x ptr>, <8 x i64> } %4550, <8 x i64> %4549, 1
  %4552 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4553 = extractvalue { <8 x ptr>, <8 x i64> } %4551, 1
  %4554 = extractelement <8 x ptr> %4552, i32 0
  %4555 = extractelement <8 x i64> %4553, i32 %1855
  %4556 = zext i32 %1855 to i64
  %4557 = mul i64 %4556, 4
  %4558 = sub i64 %4555, %4557
  %4559 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4560 = select i1 %4559, i64 %4558, i64 0
  %private.contiguous.address557 = getelementptr i8, ptr %4554, i64 %4560
  %private.contiguous.preserve558 = load <8 x float>, ptr %private.contiguous.address557, align 4
  %4561 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3650, <8 x float> %private.contiguous.preserve558
  store <8 x float> %4561, ptr %private.contiguous.address557, align 4
  %4562 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4563 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4564 = add <8 x i64> %4563, splat (i64 1888)
  %4565 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4562, 0
  %4566 = insertvalue { <8 x ptr>, <8 x i64> } %4565, <8 x i64> %4564, 1
  %4567 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4568 = extractvalue { <8 x ptr>, <8 x i64> } %4566, 1
  %4569 = extractelement <8 x ptr> %4567, i32 0
  %4570 = extractelement <8 x i64> %4568, i32 %1855
  %4571 = zext i32 %1855 to i64
  %4572 = mul i64 %4571, 4
  %4573 = sub i64 %4570, %4572
  %4574 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4575 = select i1 %4574, i64 %4573, i64 0
  %private.contiguous.address559 = getelementptr i8, ptr %4569, i64 %4575
  %private.contiguous.preserve560 = load <8 x float>, ptr %private.contiguous.address559, align 4
  %4576 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3653, <8 x float> %private.contiguous.preserve560
  store <8 x float> %4576, ptr %private.contiguous.address559, align 4
  %4577 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4578 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4579 = add <8 x i64> %4578, splat (i64 1920)
  %4580 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4577, 0
  %4581 = insertvalue { <8 x ptr>, <8 x i64> } %4580, <8 x i64> %4579, 1
  %4582 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4583 = extractvalue { <8 x ptr>, <8 x i64> } %4581, 1
  %4584 = extractelement <8 x ptr> %4582, i32 0
  %4585 = extractelement <8 x i64> %4583, i32 %1855
  %4586 = zext i32 %1855 to i64
  %4587 = mul i64 %4586, 4
  %4588 = sub i64 %4585, %4587
  %4589 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4590 = select i1 %4589, i64 %4588, i64 0
  %private.contiguous.address561 = getelementptr i8, ptr %4584, i64 %4590
  %private.contiguous.preserve562 = load <8 x float>, ptr %private.contiguous.address561, align 4
  %4591 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3656, <8 x float> %private.contiguous.preserve562
  store <8 x float> %4591, ptr %private.contiguous.address561, align 4
  %4592 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4593 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4594 = add <8 x i64> %4593, splat (i64 1952)
  %4595 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4592, 0
  %4596 = insertvalue { <8 x ptr>, <8 x i64> } %4595, <8 x i64> %4594, 1
  %4597 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4598 = extractvalue { <8 x ptr>, <8 x i64> } %4596, 1
  %4599 = extractelement <8 x ptr> %4597, i32 0
  %4600 = extractelement <8 x i64> %4598, i32 %1855
  %4601 = zext i32 %1855 to i64
  %4602 = mul i64 %4601, 4
  %4603 = sub i64 %4600, %4602
  %4604 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4605 = select i1 %4604, i64 %4603, i64 0
  %private.contiguous.address563 = getelementptr i8, ptr %4599, i64 %4605
  %private.contiguous.preserve564 = load <8 x float>, ptr %private.contiguous.address563, align 4
  %4606 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3659, <8 x float> %private.contiguous.preserve564
  store <8 x float> %4606, ptr %private.contiguous.address563, align 4
  %4607 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4608 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4609 = add <8 x i64> %4608, splat (i64 1984)
  %4610 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4607, 0
  %4611 = insertvalue { <8 x ptr>, <8 x i64> } %4610, <8 x i64> %4609, 1
  %4612 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4613 = extractvalue { <8 x ptr>, <8 x i64> } %4611, 1
  %4614 = extractelement <8 x ptr> %4612, i32 0
  %4615 = extractelement <8 x i64> %4613, i32 %1855
  %4616 = zext i32 %1855 to i64
  %4617 = mul i64 %4616, 4
  %4618 = sub i64 %4615, %4617
  %4619 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4620 = select i1 %4619, i64 %4618, i64 0
  %private.contiguous.address565 = getelementptr i8, ptr %4614, i64 %4620
  %private.contiguous.preserve566 = load <8 x float>, ptr %private.contiguous.address565, align 4
  %4621 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3662, <8 x float> %private.contiguous.preserve566
  store <8 x float> %4621, ptr %private.contiguous.address565, align 4
  %4622 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4623 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4624 = add <8 x i64> %4623, splat (i64 2016)
  %4625 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4622, 0
  %4626 = insertvalue { <8 x ptr>, <8 x i64> } %4625, <8 x i64> %4624, 1
  %4627 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4628 = extractvalue { <8 x ptr>, <8 x i64> } %4626, 1
  %4629 = extractelement <8 x ptr> %4627, i32 0
  %4630 = extractelement <8 x i64> %4628, i32 %1855
  %4631 = zext i32 %1855 to i64
  %4632 = mul i64 %4631, 4
  %4633 = sub i64 %4630, %4632
  %4634 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %4635 = select i1 %4634, i64 %4633, i64 0
  %private.contiguous.address567 = getelementptr i8, ptr %4629, i64 %4635
  %private.contiguous.preserve568 = load <8 x float>, ptr %private.contiguous.address567, align 4
  %4636 = select <8 x i1> %convergence.cascade.result406, <8 x float> %3665, <8 x float> %private.contiguous.preserve568
  store <8 x float> %4636, ptr %private.contiguous.address567, align 4
  %4637 = load <8 x i64>, ptr %.slot196, align 64
  %4638 = select <8 x i1> %convergence.cascade.result406, <8 x i64> zeroinitializer, <8 x i64> %4637
  store <8 x i64> %4638, ptr %.slot196, align 64
  %4639 = load <8 x float>, ptr %.slot197, align 32
  %4640 = select <8 x i1> %convergence.cascade.result406, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %4639
  store <8 x float> %4640, ptr %.slot197, align 32
  store <8 x i1> %convergence.cascade.result406, ptr %current.mask, align 1
  %4641 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  br i1 %4641, label %schedule.12, label %scheduler.loop

varying.divergent570:                             ; preds = %schedule.12
  %4642 = load i32, ptr %current.token, align 4
  %4643 = icmp ne i32 %4642, 0
  %4644 = sub i32 %4642, 1
  %4645 = select i1 %4643, i32 %4644, i32 0
  %4646 = load i8, ptr %frame.active, align 1
  %4647 = trunc i32 %4645 to i8
  %4648 = shl i8 1, %4647
  %4649 = and i8 %4646, %4648
  %4650 = icmp ne i8 %4649, 0
  %4651 = load <8 x i32>, ptr %frame.static.id, align 32
  %4652 = extractelement <8 x i32> %4651, i32 %4645
  %4653 = icmp eq i32 %4652, 5
  %4654 = and i1 %4650, %4653
  %4655 = and i1 %4643, %4654
  %4656 = xor i1 %4655, true
  %4657 = and i1 true, %4656
  %4658 = xor i8 %4646, -1
  %4659 = icmp ne i8 %4658, 0
  %4660 = xor i1 %4659, true
  %4661 = and i1 %4657, %4660
  br i1 %4661, label %convergence.overflow.trap572, label %convergence.overflow.resume573

varying.coherent571:                              ; preds = %schedule.12
  br i1 %311, label %varying.coherent.true576, label %varying.coherent.false577

convergence.overflow.trap572:                     ; preds = %varying.divergent570
  call void @llvm.trap()
  unreachable

convergence.overflow.resume573:                   ; preds = %varying.divergent570
  %4662 = call i8 @llvm.cttz.i8(i8 %4658, i1 false)
  %4663 = zext i8 %4662 to i32
  %4664 = select i1 %4659, i32 %4663, i32 0
  %4665 = trunc i32 %4664 to i8
  %4666 = shl i8 1, %4665
  %4667 = or i8 %4646, %4666
  %4668 = select i1 %4657, i8 %4667, i8 %4646
  store i8 %4668, ptr %frame.active, align 1
  %4669 = load <8 x i32>, ptr %frame.static.id, align 32
  %4670 = extractelement <8 x i32> %4669, i32 %4664
  %4671 = select i1 %4657, i32 5, i32 %4670
  %4672 = load <8 x i32>, ptr %frame.static.id, align 32
  %4673 = insertelement <8 x i32> %4672, i32 %4671, i32 %4664
  store <8 x i32> %4673, ptr %frame.static.id, align 32
  %4674 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4675 = extractelement <8 x i32> %4674, i32 %4664
  %4676 = select i1 %4657, i32 %4642, i32 %4675
  %4677 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4678 = insertelement <8 x i32> %4677, i32 %4676, i32 %4664
  store <8 x i32> %4678, ptr %frame.parent.token, align 32
  %4679 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4664
  %4680 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4664
  %4681 = load <8 x i1>, ptr %4679, align 1
  %4682 = load <8 x i1>, ptr %4680, align 1
  %4683 = select i1 %4657, <8 x i1> %301, <8 x i1> %4681
  store <8 x i1> %4683, ptr %4679, align 1
  %4684 = select i1 %4657, <8 x i1> zeroinitializer, <8 x i1> %4682
  store <8 x i1> %4684, ptr %4680, align 1
  %4685 = add i32 %4664, 1
  %4686 = select i1 %4655, i32 %4642, i32 %4685
  %4687 = select i1 true, i32 %4686, i32 %4642
  store i32 %4687, ptr %current.token, align 4
  %4688 = load i32, ptr %current.token, align 4
  %4689 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %308)
  %4690 = load i32, ptr %ready.count, align 4
  %4691 = icmp uge i32 %4690, 8
  %4692 = and i1 %4689, %4691
  br i1 %4692, label %ready.overflow.trap574, label %ready.overflow.resume575

ready.overflow.trap574:                           ; preds = %convergence.overflow.resume573
  call void @llvm.trap()
  unreachable

ready.overflow.resume575:                         ; preds = %convergence.overflow.resume573
  %4693 = select i1 %4689, i32 %4690, i32 0
  %4694 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4693
  %4695 = load <8 x i1>, ptr %4694, align 1
  %4696 = select i1 %4689, <8 x i1> %308, <8 x i1> %4695
  store <8 x i1> %4696, ptr %4694, align 1
  %4697 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4693
  %4698 = load i32, ptr %4697, align 4
  %4699 = select i1 %4689, i32 13, i32 %4698
  store i32 %4699, ptr %4697, align 4
  %4700 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4693
  %4701 = load i32, ptr %4700, align 4
  %4702 = select i1 %4689, i32 %4688, i32 %4701
  store i32 %4702, ptr %4700, align 4
  %4703 = add i32 %4690, 1
  %4704 = select i1 %4689, i32 %4703, i32 %4690
  store i32 %4704, ptr %ready.count, align 4
  %4705 = load <8 x i1>, ptr %runnable.mask, align 1
  %4706 = or <8 x i1> %4705, %308
  store <8 x i1> %4706, ptr %runnable.mask, align 1
  store <8 x i1> %310, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true576:                         ; preds = %varying.coherent571
  store <8 x i1> %301, ptr %current.mask, align 1
  %4707 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %301)
  br i1 %4707, label %schedule.13, label %scheduler.loop

varying.coherent.false577:                        ; preds = %varying.coherent571
  store <8 x i1> %301, ptr %current.mask, align 1
  %4708 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %301)
  br i1 %4708, label %schedule.14, label %scheduler.loop

convergence.cascade582:                           ; preds = %convergence.cascade582, %schedule.14
  %convergence.cascade.flow586 = phi <8 x i1> [ %341, %schedule.14 ], [ %4751, %convergence.cascade582 ]
  %convergence.cascade.depth587 = phi i32 [ 0, %schedule.14 ], [ %4752, %convergence.cascade582 ]
  %4709 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow586)
  %4710 = load i32, ptr %current.token, align 4
  %4711 = icmp ne i32 %4710, 0
  %4712 = and i1 %4709, %4711
  %4713 = sub i32 %4710, 1
  %4714 = select i1 %4712, i32 %4713, i32 0
  %4715 = load i8, ptr %frame.active, align 1
  %4716 = trunc i32 %4714 to i8
  %4717 = shl i8 1, %4716
  %4718 = and i8 %4715, %4717
  %4719 = icmp ne i8 %4718, 0
  %4720 = load <8 x i32>, ptr %frame.static.id, align 32
  %4721 = extractelement <8 x i32> %4720, i32 %4714
  %convergence.target.pointer588 = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %4721
  %convergence.dynamic.target589 = load i32, ptr %convergence.target.pointer588, align 4
  %4722 = icmp eq i32 %convergence.dynamic.target589, 14
  %4723 = and i1 %4719, %4722
  %4724 = and i1 %4712, %4723
  %4725 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4714
  %4726 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4714
  %4727 = load <8 x i1>, ptr %4725, align 1
  %4728 = load <8 x i1>, ptr %4726, align 1
  %4729 = or <8 x i1> %4728, %convergence.cascade.flow586
  %4730 = load <8 x i1>, ptr %live.mask, align 1
  %4731 = and <8 x i1> %4727, %4730
  %4732 = icmp eq <8 x i1> %4729, %4731
  %4733 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4732)
  %4734 = and i1 %4724, %4733
  %4735 = select i1 %4734, <8 x i1> zeroinitializer, <8 x i1> %4729
  %4736 = select i1 %4724, <8 x i1> %4735, <8 x i1> %4728
  store <8 x i1> %4736, ptr %4726, align 1
  %4737 = select i1 %4734, <8 x i1> zeroinitializer, <8 x i1> %4727
  store <8 x i1> %4737, ptr %4725, align 1
  %4738 = trunc i32 %4714 to i8
  %4739 = shl i8 1, %4738
  %4740 = xor i8 %4739, -1
  %4741 = and i8 %4715, %4740
  %4742 = select i1 %4734, i8 %4741, i8 %4715
  store i8 %4742, ptr %frame.active, align 1
  %.splatinsert590 = insertelement <8 x i1> poison, i1 %4724, i64 0
  %.splat591 = shufflevector <8 x i1> %.splatinsert590, <8 x i1> poison, <8 x i32> zeroinitializer
  %4743 = and <8 x i1> %convergence.cascade.flow586, %.splat591
  %4744 = load <8 x i1>, ptr %runnable.mask, align 1
  %4745 = xor <8 x i1> %4743, splat (i1 true)
  %4746 = and <8 x i1> %4744, %4745
  store <8 x i1> %4746, ptr %runnable.mask, align 1
  %.splatinsert592 = insertelement <8 x i1> poison, i1 %4734, i64 0
  %.splat593 = shufflevector <8 x i1> %.splatinsert592, <8 x i1> poison, <8 x i32> zeroinitializer
  %4747 = select <8 x i1> %.splat593, <8 x i1> %4729, <8 x i1> zeroinitializer
  %4748 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4749 = extractelement <8 x i32> %4748, i32 %4714
  %4750 = select i1 %4734, i32 %4749, i32 %4710
  store i32 %4750, ptr %current.token, align 4
  %.splatinsert594 = insertelement <8 x i1> poison, i1 %4724, i64 0
  %.splat595 = shufflevector <8 x i1> %.splatinsert594, <8 x i1> poison, <8 x i32> zeroinitializer
  %4751 = select <8 x i1> %.splat595, <8 x i1> %4747, <8 x i1> %convergence.cascade.flow586
  %4752 = add i32 %convergence.cascade.depth587, 1
  %4753 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4751)
  %4754 = icmp ult i32 %4752, 8
  %4755 = and i1 %4753, %4754
  %4756 = and i1 %4724, %4755
  %convergence.parent.token596 = load i32, ptr %current.token, align 4
  %convergence.parent.present597 = icmp ne i32 %convergence.parent.token596, 0
  %4757 = and i1 %4756, %convergence.parent.present597
  br i1 %4757, label %convergence.cascade582, label %convergence.cascade.exit583

convergence.cascade.exit583:                      ; preds = %convergence.cascade582, %schedule.14
  %convergence.cascade.result598 = phi <8 x i1> [ %341, %schedule.14 ], [ %4751, %convergence.cascade582 ]
  %4758 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result598)
  br i1 %4758, label %convergence.target.14.ready, label %scheduler.loop

convergence.target.14.ready:                      ; preds = %convergence.cascade.exit583
  %4759 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result598)
  %4760 = bitcast <8 x i1> %convergence.cascade.result598 to i8
  %4761 = call i8 @llvm.cttz.i8(i8 %4760, i1 false)
  %4762 = zext i8 %4761 to i32
  %4763 = select i1 %4759, i32 %4762, i32 0
  %4764 = load <8 x i64>, ptr %.slot198, align 64
  %4765 = select <8 x i1> %convergence.cascade.result598, <8 x i64> zeroinitializer, <8 x i64> %4764
  store <8 x i64> %4765, ptr %.slot198, align 64
  %4766 = load <8 x float>, ptr %.slot199, align 32
  %4767 = select <8 x i1> %convergence.cascade.result598, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %4766
  store <8 x float> %4767, ptr %.slot199, align 32
  store <8 x i1> %convergence.cascade.result598, ptr %current.mask, align 1
  %4768 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result598)
  br i1 %4768, label %schedule.15, label %scheduler.loop

varying.divergent600:                             ; preds = %schedule.15
  %4769 = load i32, ptr %current.token, align 4
  %4770 = icmp ne i32 %4769, 0
  %4771 = sub i32 %4769, 1
  %4772 = select i1 %4770, i32 %4771, i32 0
  %4773 = load i8, ptr %frame.active, align 1
  %4774 = trunc i32 %4772 to i8
  %4775 = shl i8 1, %4774
  %4776 = and i8 %4773, %4775
  %4777 = icmp ne i8 %4776, 0
  %4778 = load <8 x i32>, ptr %frame.static.id, align 32
  %4779 = extractelement <8 x i32> %4778, i32 %4772
  %4780 = icmp eq i32 %4779, 6
  %4781 = and i1 %4777, %4780
  %4782 = and i1 %4770, %4781
  %4783 = xor i1 %4782, true
  %4784 = and i1 true, %4783
  %4785 = xor i8 %4773, -1
  %4786 = icmp ne i8 %4785, 0
  %4787 = xor i1 %4786, true
  %4788 = and i1 %4784, %4787
  br i1 %4788, label %convergence.overflow.trap602, label %convergence.overflow.resume603

varying.coherent601:                              ; preds = %schedule.15
  br i1 %352, label %varying.coherent.true606, label %varying.coherent.false607

convergence.overflow.trap602:                     ; preds = %varying.divergent600
  call void @llvm.trap()
  unreachable

convergence.overflow.resume603:                   ; preds = %varying.divergent600
  %4789 = call i8 @llvm.cttz.i8(i8 %4785, i1 false)
  %4790 = zext i8 %4789 to i32
  %4791 = select i1 %4786, i32 %4790, i32 0
  %4792 = trunc i32 %4791 to i8
  %4793 = shl i8 1, %4792
  %4794 = or i8 %4773, %4793
  %4795 = select i1 %4784, i8 %4794, i8 %4773
  store i8 %4795, ptr %frame.active, align 1
  %4796 = load <8 x i32>, ptr %frame.static.id, align 32
  %4797 = extractelement <8 x i32> %4796, i32 %4791
  %4798 = select i1 %4784, i32 6, i32 %4797
  %4799 = load <8 x i32>, ptr %frame.static.id, align 32
  %4800 = insertelement <8 x i32> %4799, i32 %4798, i32 %4791
  store <8 x i32> %4800, ptr %frame.static.id, align 32
  %4801 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4802 = extractelement <8 x i32> %4801, i32 %4791
  %4803 = select i1 %4784, i32 %4769, i32 %4802
  %4804 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4805 = insertelement <8 x i32> %4804, i32 %4803, i32 %4791
  store <8 x i32> %4805, ptr %frame.parent.token, align 32
  %4806 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4791
  %4807 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4791
  %4808 = load <8 x i1>, ptr %4806, align 1
  %4809 = load <8 x i1>, ptr %4807, align 1
  %4810 = select i1 %4784, <8 x i1> %342, <8 x i1> %4808
  store <8 x i1> %4810, ptr %4806, align 1
  %4811 = select i1 %4784, <8 x i1> zeroinitializer, <8 x i1> %4809
  store <8 x i1> %4811, ptr %4807, align 1
  %4812 = add i32 %4791, 1
  %4813 = select i1 %4782, i32 %4769, i32 %4812
  %4814 = select i1 true, i32 %4813, i32 %4769
  store i32 %4814, ptr %current.token, align 4
  %4815 = load i32, ptr %current.token, align 4
  %4816 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %349)
  %4817 = load i32, ptr %ready.count, align 4
  %4818 = icmp uge i32 %4817, 8
  %4819 = and i1 %4816, %4818
  br i1 %4819, label %ready.overflow.trap604, label %ready.overflow.resume605

ready.overflow.trap604:                           ; preds = %convergence.overflow.resume603
  call void @llvm.trap()
  unreachable

ready.overflow.resume605:                         ; preds = %convergence.overflow.resume603
  %4820 = select i1 %4816, i32 %4817, i32 0
  %4821 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4820
  %4822 = load <8 x i1>, ptr %4821, align 1
  %4823 = select i1 %4816, <8 x i1> %349, <8 x i1> %4822
  store <8 x i1> %4823, ptr %4821, align 1
  %4824 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4820
  %4825 = load i32, ptr %4824, align 4
  %4826 = select i1 %4816, i32 16, i32 %4825
  store i32 %4826, ptr %4824, align 4
  %4827 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4820
  %4828 = load i32, ptr %4827, align 4
  %4829 = select i1 %4816, i32 %4815, i32 %4828
  store i32 %4829, ptr %4827, align 4
  %4830 = add i32 %4817, 1
  %4831 = select i1 %4816, i32 %4830, i32 %4817
  store i32 %4831, ptr %ready.count, align 4
  %4832 = load <8 x i1>, ptr %runnable.mask, align 1
  %4833 = or <8 x i1> %4832, %349
  store <8 x i1> %4833, ptr %runnable.mask, align 1
  store <8 x i1> %351, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true606:                         ; preds = %varying.coherent601
  store <8 x i1> %342, ptr %current.mask, align 1
  %4834 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %342)
  br i1 %4834, label %schedule.16, label %scheduler.loop

varying.coherent.false607:                        ; preds = %varying.coherent601
  store <8 x i1> %342, ptr %current.mask, align 1
  %4835 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %342)
  br i1 %4835, label %schedule.17, label %scheduler.loop

convergence.cascade612:                           ; preds = %convergence.cascade612, %schedule.17
  %convergence.cascade.flow616 = phi <8 x i1> [ %382, %schedule.17 ], [ %4878, %convergence.cascade612 ]
  %convergence.cascade.depth617 = phi i32 [ 0, %schedule.17 ], [ %4879, %convergence.cascade612 ]
  %4836 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow616)
  %4837 = load i32, ptr %current.token, align 4
  %4838 = icmp ne i32 %4837, 0
  %4839 = and i1 %4836, %4838
  %4840 = sub i32 %4837, 1
  %4841 = select i1 %4839, i32 %4840, i32 0
  %4842 = load i8, ptr %frame.active, align 1
  %4843 = trunc i32 %4841 to i8
  %4844 = shl i8 1, %4843
  %4845 = and i8 %4842, %4844
  %4846 = icmp ne i8 %4845, 0
  %4847 = load <8 x i32>, ptr %frame.static.id, align 32
  %4848 = extractelement <8 x i32> %4847, i32 %4841
  %convergence.target.pointer618 = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %4848
  %convergence.dynamic.target619 = load i32, ptr %convergence.target.pointer618, align 4
  %4849 = icmp eq i32 %convergence.dynamic.target619, 17
  %4850 = and i1 %4846, %4849
  %4851 = and i1 %4839, %4850
  %4852 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4841
  %4853 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4841
  %4854 = load <8 x i1>, ptr %4852, align 1
  %4855 = load <8 x i1>, ptr %4853, align 1
  %4856 = or <8 x i1> %4855, %convergence.cascade.flow616
  %4857 = load <8 x i1>, ptr %live.mask, align 1
  %4858 = and <8 x i1> %4854, %4857
  %4859 = icmp eq <8 x i1> %4856, %4858
  %4860 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4859)
  %4861 = and i1 %4851, %4860
  %4862 = select i1 %4861, <8 x i1> zeroinitializer, <8 x i1> %4856
  %4863 = select i1 %4851, <8 x i1> %4862, <8 x i1> %4855
  store <8 x i1> %4863, ptr %4853, align 1
  %4864 = select i1 %4861, <8 x i1> zeroinitializer, <8 x i1> %4854
  store <8 x i1> %4864, ptr %4852, align 1
  %4865 = trunc i32 %4841 to i8
  %4866 = shl i8 1, %4865
  %4867 = xor i8 %4866, -1
  %4868 = and i8 %4842, %4867
  %4869 = select i1 %4861, i8 %4868, i8 %4842
  store i8 %4869, ptr %frame.active, align 1
  %.splatinsert620 = insertelement <8 x i1> poison, i1 %4851, i64 0
  %.splat621 = shufflevector <8 x i1> %.splatinsert620, <8 x i1> poison, <8 x i32> zeroinitializer
  %4870 = and <8 x i1> %convergence.cascade.flow616, %.splat621
  %4871 = load <8 x i1>, ptr %runnable.mask, align 1
  %4872 = xor <8 x i1> %4870, splat (i1 true)
  %4873 = and <8 x i1> %4871, %4872
  store <8 x i1> %4873, ptr %runnable.mask, align 1
  %.splatinsert622 = insertelement <8 x i1> poison, i1 %4861, i64 0
  %.splat623 = shufflevector <8 x i1> %.splatinsert622, <8 x i1> poison, <8 x i32> zeroinitializer
  %4874 = select <8 x i1> %.splat623, <8 x i1> %4856, <8 x i1> zeroinitializer
  %4875 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4876 = extractelement <8 x i32> %4875, i32 %4841
  %4877 = select i1 %4861, i32 %4876, i32 %4837
  store i32 %4877, ptr %current.token, align 4
  %.splatinsert624 = insertelement <8 x i1> poison, i1 %4851, i64 0
  %.splat625 = shufflevector <8 x i1> %.splatinsert624, <8 x i1> poison, <8 x i32> zeroinitializer
  %4878 = select <8 x i1> %.splat625, <8 x i1> %4874, <8 x i1> %convergence.cascade.flow616
  %4879 = add i32 %convergence.cascade.depth617, 1
  %4880 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4878)
  %4881 = icmp ult i32 %4879, 8
  %4882 = and i1 %4880, %4881
  %4883 = and i1 %4851, %4882
  %convergence.parent.token626 = load i32, ptr %current.token, align 4
  %convergence.parent.present627 = icmp ne i32 %convergence.parent.token626, 0
  %4884 = and i1 %4883, %convergence.parent.present627
  br i1 %4884, label %convergence.cascade612, label %convergence.cascade.exit613

convergence.cascade.exit613:                      ; preds = %convergence.cascade612, %schedule.17
  %convergence.cascade.result628 = phi <8 x i1> [ %382, %schedule.17 ], [ %4878, %convergence.cascade612 ]
  %4885 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result628)
  br i1 %4885, label %convergence.target.17.ready, label %scheduler.loop

convergence.target.17.ready:                      ; preds = %convergence.cascade.exit613
  %4886 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result628)
  %4887 = bitcast <8 x i1> %convergence.cascade.result628 to i8
  %4888 = call i8 @llvm.cttz.i8(i8 %4887, i1 false)
  %4889 = zext i8 %4888 to i32
  %4890 = select i1 %4886, i32 %4889, i32 0
  %4891 = load <8 x i64>, ptr %.slot200, align 64
  %4892 = select <8 x i1> %convergence.cascade.result628, <8 x i64> zeroinitializer, <8 x i64> %4891
  store <8 x i64> %4892, ptr %.slot200, align 64
  %4893 = load <8 x float>, ptr %.slot201, align 32
  %4894 = select <8 x i1> %convergence.cascade.result628, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %4893
  store <8 x float> %4894, ptr %.slot201, align 32
  store <8 x i1> %convergence.cascade.result628, ptr %current.mask, align 1
  %4895 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result628)
  br i1 %4895, label %schedule.18, label %scheduler.loop

varying.divergent630:                             ; preds = %schedule.18
  %4896 = load i32, ptr %current.token, align 4
  %4897 = icmp ne i32 %4896, 0
  %4898 = sub i32 %4896, 1
  %4899 = select i1 %4897, i32 %4898, i32 0
  %4900 = load i8, ptr %frame.active, align 1
  %4901 = trunc i32 %4899 to i8
  %4902 = shl i8 1, %4901
  %4903 = and i8 %4900, %4902
  %4904 = icmp ne i8 %4903, 0
  %4905 = load <8 x i32>, ptr %frame.static.id, align 32
  %4906 = extractelement <8 x i32> %4905, i32 %4899
  %4907 = icmp eq i32 %4906, 7
  %4908 = and i1 %4904, %4907
  %4909 = and i1 %4897, %4908
  %4910 = xor i1 %4909, true
  %4911 = and i1 true, %4910
  %4912 = xor i8 %4900, -1
  %4913 = icmp ne i8 %4912, 0
  %4914 = xor i1 %4913, true
  %4915 = and i1 %4911, %4914
  br i1 %4915, label %convergence.overflow.trap632, label %convergence.overflow.resume633

varying.coherent631:                              ; preds = %schedule.18
  br i1 %393, label %varying.coherent.true636, label %varying.coherent.false637

convergence.overflow.trap632:                     ; preds = %varying.divergent630
  call void @llvm.trap()
  unreachable

convergence.overflow.resume633:                   ; preds = %varying.divergent630
  %4916 = call i8 @llvm.cttz.i8(i8 %4912, i1 false)
  %4917 = zext i8 %4916 to i32
  %4918 = select i1 %4913, i32 %4917, i32 0
  %4919 = trunc i32 %4918 to i8
  %4920 = shl i8 1, %4919
  %4921 = or i8 %4900, %4920
  %4922 = select i1 %4911, i8 %4921, i8 %4900
  store i8 %4922, ptr %frame.active, align 1
  %4923 = load <8 x i32>, ptr %frame.static.id, align 32
  %4924 = extractelement <8 x i32> %4923, i32 %4918
  %4925 = select i1 %4911, i32 7, i32 %4924
  %4926 = load <8 x i32>, ptr %frame.static.id, align 32
  %4927 = insertelement <8 x i32> %4926, i32 %4925, i32 %4918
  store <8 x i32> %4927, ptr %frame.static.id, align 32
  %4928 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4929 = extractelement <8 x i32> %4928, i32 %4918
  %4930 = select i1 %4911, i32 %4896, i32 %4929
  %4931 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4932 = insertelement <8 x i32> %4931, i32 %4930, i32 %4918
  store <8 x i32> %4932, ptr %frame.parent.token, align 32
  %4933 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4918
  %4934 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4918
  %4935 = load <8 x i1>, ptr %4933, align 1
  %4936 = load <8 x i1>, ptr %4934, align 1
  %4937 = select i1 %4911, <8 x i1> %383, <8 x i1> %4935
  store <8 x i1> %4937, ptr %4933, align 1
  %4938 = select i1 %4911, <8 x i1> zeroinitializer, <8 x i1> %4936
  store <8 x i1> %4938, ptr %4934, align 1
  %4939 = add i32 %4918, 1
  %4940 = select i1 %4909, i32 %4896, i32 %4939
  %4941 = select i1 true, i32 %4940, i32 %4896
  store i32 %4941, ptr %current.token, align 4
  %4942 = load i32, ptr %current.token, align 4
  %4943 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %390)
  %4944 = load i32, ptr %ready.count, align 4
  %4945 = icmp uge i32 %4944, 8
  %4946 = and i1 %4943, %4945
  br i1 %4946, label %ready.overflow.trap634, label %ready.overflow.resume635

ready.overflow.trap634:                           ; preds = %convergence.overflow.resume633
  call void @llvm.trap()
  unreachable

ready.overflow.resume635:                         ; preds = %convergence.overflow.resume633
  %4947 = select i1 %4943, i32 %4944, i32 0
  %4948 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4947
  %4949 = load <8 x i1>, ptr %4948, align 1
  %4950 = select i1 %4943, <8 x i1> %390, <8 x i1> %4949
  store <8 x i1> %4950, ptr %4948, align 1
  %4951 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4947
  %4952 = load i32, ptr %4951, align 4
  %4953 = select i1 %4943, i32 19, i32 %4952
  store i32 %4953, ptr %4951, align 4
  %4954 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4947
  %4955 = load i32, ptr %4954, align 4
  %4956 = select i1 %4943, i32 %4942, i32 %4955
  store i32 %4956, ptr %4954, align 4
  %4957 = add i32 %4944, 1
  %4958 = select i1 %4943, i32 %4957, i32 %4944
  store i32 %4958, ptr %ready.count, align 4
  %4959 = load <8 x i1>, ptr %runnable.mask, align 1
  %4960 = or <8 x i1> %4959, %390
  store <8 x i1> %4960, ptr %runnable.mask, align 1
  store <8 x i1> %392, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true636:                         ; preds = %varying.coherent631
  store <8 x i1> %383, ptr %current.mask, align 1
  %4961 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %383)
  br i1 %4961, label %schedule.19, label %scheduler.loop

varying.coherent.false637:                        ; preds = %varying.coherent631
  store <8 x i1> %383, ptr %current.mask, align 1
  %4962 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %383)
  br i1 %4962, label %schedule.20, label %scheduler.loop

convergence.cascade642:                           ; preds = %convergence.cascade642, %schedule.20
  %convergence.cascade.flow646 = phi <8 x i1> [ %423, %schedule.20 ], [ %5005, %convergence.cascade642 ]
  %convergence.cascade.depth647 = phi i32 [ 0, %schedule.20 ], [ %5006, %convergence.cascade642 ]
  %4963 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow646)
  %4964 = load i32, ptr %current.token, align 4
  %4965 = icmp ne i32 %4964, 0
  %4966 = and i1 %4963, %4965
  %4967 = sub i32 %4964, 1
  %4968 = select i1 %4966, i32 %4967, i32 0
  %4969 = load i8, ptr %frame.active, align 1
  %4970 = trunc i32 %4968 to i8
  %4971 = shl i8 1, %4970
  %4972 = and i8 %4969, %4971
  %4973 = icmp ne i8 %4972, 0
  %4974 = load <8 x i32>, ptr %frame.static.id, align 32
  %4975 = extractelement <8 x i32> %4974, i32 %4968
  %convergence.target.pointer648 = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %4975
  %convergence.dynamic.target649 = load i32, ptr %convergence.target.pointer648, align 4
  %4976 = icmp eq i32 %convergence.dynamic.target649, 20
  %4977 = and i1 %4973, %4976
  %4978 = and i1 %4966, %4977
  %4979 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4968
  %4980 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4968
  %4981 = load <8 x i1>, ptr %4979, align 1
  %4982 = load <8 x i1>, ptr %4980, align 1
  %4983 = or <8 x i1> %4982, %convergence.cascade.flow646
  %4984 = load <8 x i1>, ptr %live.mask, align 1
  %4985 = and <8 x i1> %4981, %4984
  %4986 = icmp eq <8 x i1> %4983, %4985
  %4987 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4986)
  %4988 = and i1 %4978, %4987
  %4989 = select i1 %4988, <8 x i1> zeroinitializer, <8 x i1> %4983
  %4990 = select i1 %4978, <8 x i1> %4989, <8 x i1> %4982
  store <8 x i1> %4990, ptr %4980, align 1
  %4991 = select i1 %4988, <8 x i1> zeroinitializer, <8 x i1> %4981
  store <8 x i1> %4991, ptr %4979, align 1
  %4992 = trunc i32 %4968 to i8
  %4993 = shl i8 1, %4992
  %4994 = xor i8 %4993, -1
  %4995 = and i8 %4969, %4994
  %4996 = select i1 %4988, i8 %4995, i8 %4969
  store i8 %4996, ptr %frame.active, align 1
  %.splatinsert650 = insertelement <8 x i1> poison, i1 %4978, i64 0
  %.splat651 = shufflevector <8 x i1> %.splatinsert650, <8 x i1> poison, <8 x i32> zeroinitializer
  %4997 = and <8 x i1> %convergence.cascade.flow646, %.splat651
  %4998 = load <8 x i1>, ptr %runnable.mask, align 1
  %4999 = xor <8 x i1> %4997, splat (i1 true)
  %5000 = and <8 x i1> %4998, %4999
  store <8 x i1> %5000, ptr %runnable.mask, align 1
  %.splatinsert652 = insertelement <8 x i1> poison, i1 %4988, i64 0
  %.splat653 = shufflevector <8 x i1> %.splatinsert652, <8 x i1> poison, <8 x i32> zeroinitializer
  %5001 = select <8 x i1> %.splat653, <8 x i1> %4983, <8 x i1> zeroinitializer
  %5002 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5003 = extractelement <8 x i32> %5002, i32 %4968
  %5004 = select i1 %4988, i32 %5003, i32 %4964
  store i32 %5004, ptr %current.token, align 4
  %.splatinsert654 = insertelement <8 x i1> poison, i1 %4978, i64 0
  %.splat655 = shufflevector <8 x i1> %.splatinsert654, <8 x i1> poison, <8 x i32> zeroinitializer
  %5005 = select <8 x i1> %.splat655, <8 x i1> %5001, <8 x i1> %convergence.cascade.flow646
  %5006 = add i32 %convergence.cascade.depth647, 1
  %5007 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5005)
  %5008 = icmp ult i32 %5006, 8
  %5009 = and i1 %5007, %5008
  %5010 = and i1 %4978, %5009
  %convergence.parent.token656 = load i32, ptr %current.token, align 4
  %convergence.parent.present657 = icmp ne i32 %convergence.parent.token656, 0
  %5011 = and i1 %5010, %convergence.parent.present657
  br i1 %5011, label %convergence.cascade642, label %convergence.cascade.exit643

convergence.cascade.exit643:                      ; preds = %convergence.cascade642, %schedule.20
  %convergence.cascade.result658 = phi <8 x i1> [ %423, %schedule.20 ], [ %5005, %convergence.cascade642 ]
  %5012 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result658)
  br i1 %5012, label %convergence.target.20.ready, label %scheduler.loop

convergence.target.20.ready:                      ; preds = %convergence.cascade.exit643
  %5013 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result658)
  %5014 = bitcast <8 x i1> %convergence.cascade.result658 to i8
  %5015 = call i8 @llvm.cttz.i8(i8 %5014, i1 false)
  %5016 = zext i8 %5015 to i32
  %5017 = select i1 %5013, i32 %5016, i32 0
  %5018 = load <8 x i64>, ptr %.slot202, align 64
  %5019 = select <8 x i1> %convergence.cascade.result658, <8 x i64> zeroinitializer, <8 x i64> %5018
  store <8 x i64> %5019, ptr %.slot202, align 64
  %5020 = load <8 x float>, ptr %.slot203, align 32
  %5021 = select <8 x i1> %convergence.cascade.result658, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %5020
  store <8 x float> %5021, ptr %.slot203, align 32
  store <8 x i1> %convergence.cascade.result658, ptr %current.mask, align 1
  %5022 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result658)
  br i1 %5022, label %schedule.21, label %scheduler.loop

varying.divergent660:                             ; preds = %schedule.21
  %5023 = load i32, ptr %current.token, align 4
  %5024 = icmp ne i32 %5023, 0
  %5025 = sub i32 %5023, 1
  %5026 = select i1 %5024, i32 %5025, i32 0
  %5027 = load i8, ptr %frame.active, align 1
  %5028 = trunc i32 %5026 to i8
  %5029 = shl i8 1, %5028
  %5030 = and i8 %5027, %5029
  %5031 = icmp ne i8 %5030, 0
  %5032 = load <8 x i32>, ptr %frame.static.id, align 32
  %5033 = extractelement <8 x i32> %5032, i32 %5026
  %5034 = icmp eq i32 %5033, 8
  %5035 = and i1 %5031, %5034
  %5036 = and i1 %5024, %5035
  %5037 = xor i1 %5036, true
  %5038 = and i1 true, %5037
  %5039 = xor i8 %5027, -1
  %5040 = icmp ne i8 %5039, 0
  %5041 = xor i1 %5040, true
  %5042 = and i1 %5038, %5041
  br i1 %5042, label %convergence.overflow.trap662, label %convergence.overflow.resume663

varying.coherent661:                              ; preds = %schedule.21
  br i1 %434, label %varying.coherent.true666, label %varying.coherent.false667

convergence.overflow.trap662:                     ; preds = %varying.divergent660
  call void @llvm.trap()
  unreachable

convergence.overflow.resume663:                   ; preds = %varying.divergent660
  %5043 = call i8 @llvm.cttz.i8(i8 %5039, i1 false)
  %5044 = zext i8 %5043 to i32
  %5045 = select i1 %5040, i32 %5044, i32 0
  %5046 = trunc i32 %5045 to i8
  %5047 = shl i8 1, %5046
  %5048 = or i8 %5027, %5047
  %5049 = select i1 %5038, i8 %5048, i8 %5027
  store i8 %5049, ptr %frame.active, align 1
  %5050 = load <8 x i32>, ptr %frame.static.id, align 32
  %5051 = extractelement <8 x i32> %5050, i32 %5045
  %5052 = select i1 %5038, i32 8, i32 %5051
  %5053 = load <8 x i32>, ptr %frame.static.id, align 32
  %5054 = insertelement <8 x i32> %5053, i32 %5052, i32 %5045
  store <8 x i32> %5054, ptr %frame.static.id, align 32
  %5055 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5056 = extractelement <8 x i32> %5055, i32 %5045
  %5057 = select i1 %5038, i32 %5023, i32 %5056
  %5058 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5059 = insertelement <8 x i32> %5058, i32 %5057, i32 %5045
  store <8 x i32> %5059, ptr %frame.parent.token, align 32
  %5060 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5045
  %5061 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5045
  %5062 = load <8 x i1>, ptr %5060, align 1
  %5063 = load <8 x i1>, ptr %5061, align 1
  %5064 = select i1 %5038, <8 x i1> %424, <8 x i1> %5062
  store <8 x i1> %5064, ptr %5060, align 1
  %5065 = select i1 %5038, <8 x i1> zeroinitializer, <8 x i1> %5063
  store <8 x i1> %5065, ptr %5061, align 1
  %5066 = add i32 %5045, 1
  %5067 = select i1 %5036, i32 %5023, i32 %5066
  %5068 = select i1 true, i32 %5067, i32 %5023
  store i32 %5068, ptr %current.token, align 4
  %5069 = load i32, ptr %current.token, align 4
  %5070 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %431)
  %5071 = load i32, ptr %ready.count, align 4
  %5072 = icmp uge i32 %5071, 8
  %5073 = and i1 %5070, %5072
  br i1 %5073, label %ready.overflow.trap664, label %ready.overflow.resume665

ready.overflow.trap664:                           ; preds = %convergence.overflow.resume663
  call void @llvm.trap()
  unreachable

ready.overflow.resume665:                         ; preds = %convergence.overflow.resume663
  %5074 = select i1 %5070, i32 %5071, i32 0
  %5075 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5074
  %5076 = load <8 x i1>, ptr %5075, align 1
  %5077 = select i1 %5070, <8 x i1> %431, <8 x i1> %5076
  store <8 x i1> %5077, ptr %5075, align 1
  %5078 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5074
  %5079 = load i32, ptr %5078, align 4
  %5080 = select i1 %5070, i32 22, i32 %5079
  store i32 %5080, ptr %5078, align 4
  %5081 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5074
  %5082 = load i32, ptr %5081, align 4
  %5083 = select i1 %5070, i32 %5069, i32 %5082
  store i32 %5083, ptr %5081, align 4
  %5084 = add i32 %5071, 1
  %5085 = select i1 %5070, i32 %5084, i32 %5071
  store i32 %5085, ptr %ready.count, align 4
  %5086 = load <8 x i1>, ptr %runnable.mask, align 1
  %5087 = or <8 x i1> %5086, %431
  store <8 x i1> %5087, ptr %runnable.mask, align 1
  store <8 x i1> %433, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true666:                         ; preds = %varying.coherent661
  store <8 x i1> %424, ptr %current.mask, align 1
  %5088 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %424)
  br i1 %5088, label %schedule.22, label %scheduler.loop

varying.coherent.false667:                        ; preds = %varying.coherent661
  store <8 x i1> %424, ptr %current.mask, align 1
  %5089 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %424)
  br i1 %5089, label %schedule.23, label %scheduler.loop

convergence.cascade672:                           ; preds = %convergence.cascade672, %schedule.23
  %convergence.cascade.flow676 = phi <8 x i1> [ %464, %schedule.23 ], [ %5132, %convergence.cascade672 ]
  %convergence.cascade.depth677 = phi i32 [ 0, %schedule.23 ], [ %5133, %convergence.cascade672 ]
  %5090 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow676)
  %5091 = load i32, ptr %current.token, align 4
  %5092 = icmp ne i32 %5091, 0
  %5093 = and i1 %5090, %5092
  %5094 = sub i32 %5091, 1
  %5095 = select i1 %5093, i32 %5094, i32 0
  %5096 = load i8, ptr %frame.active, align 1
  %5097 = trunc i32 %5095 to i8
  %5098 = shl i8 1, %5097
  %5099 = and i8 %5096, %5098
  %5100 = icmp ne i8 %5099, 0
  %5101 = load <8 x i32>, ptr %frame.static.id, align 32
  %5102 = extractelement <8 x i32> %5101, i32 %5095
  %convergence.target.pointer678 = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %5102
  %convergence.dynamic.target679 = load i32, ptr %convergence.target.pointer678, align 4
  %5103 = icmp eq i32 %convergence.dynamic.target679, 23
  %5104 = and i1 %5100, %5103
  %5105 = and i1 %5093, %5104
  %5106 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5095
  %5107 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5095
  %5108 = load <8 x i1>, ptr %5106, align 1
  %5109 = load <8 x i1>, ptr %5107, align 1
  %5110 = or <8 x i1> %5109, %convergence.cascade.flow676
  %5111 = load <8 x i1>, ptr %live.mask, align 1
  %5112 = and <8 x i1> %5108, %5111
  %5113 = icmp eq <8 x i1> %5110, %5112
  %5114 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5113)
  %5115 = and i1 %5105, %5114
  %5116 = select i1 %5115, <8 x i1> zeroinitializer, <8 x i1> %5110
  %5117 = select i1 %5105, <8 x i1> %5116, <8 x i1> %5109
  store <8 x i1> %5117, ptr %5107, align 1
  %5118 = select i1 %5115, <8 x i1> zeroinitializer, <8 x i1> %5108
  store <8 x i1> %5118, ptr %5106, align 1
  %5119 = trunc i32 %5095 to i8
  %5120 = shl i8 1, %5119
  %5121 = xor i8 %5120, -1
  %5122 = and i8 %5096, %5121
  %5123 = select i1 %5115, i8 %5122, i8 %5096
  store i8 %5123, ptr %frame.active, align 1
  %.splatinsert680 = insertelement <8 x i1> poison, i1 %5105, i64 0
  %.splat681 = shufflevector <8 x i1> %.splatinsert680, <8 x i1> poison, <8 x i32> zeroinitializer
  %5124 = and <8 x i1> %convergence.cascade.flow676, %.splat681
  %5125 = load <8 x i1>, ptr %runnable.mask, align 1
  %5126 = xor <8 x i1> %5124, splat (i1 true)
  %5127 = and <8 x i1> %5125, %5126
  store <8 x i1> %5127, ptr %runnable.mask, align 1
  %.splatinsert682 = insertelement <8 x i1> poison, i1 %5115, i64 0
  %.splat683 = shufflevector <8 x i1> %.splatinsert682, <8 x i1> poison, <8 x i32> zeroinitializer
  %5128 = select <8 x i1> %.splat683, <8 x i1> %5110, <8 x i1> zeroinitializer
  %5129 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5130 = extractelement <8 x i32> %5129, i32 %5095
  %5131 = select i1 %5115, i32 %5130, i32 %5091
  store i32 %5131, ptr %current.token, align 4
  %.splatinsert684 = insertelement <8 x i1> poison, i1 %5105, i64 0
  %.splat685 = shufflevector <8 x i1> %.splatinsert684, <8 x i1> poison, <8 x i32> zeroinitializer
  %5132 = select <8 x i1> %.splat685, <8 x i1> %5128, <8 x i1> %convergence.cascade.flow676
  %5133 = add i32 %convergence.cascade.depth677, 1
  %5134 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5132)
  %5135 = icmp ult i32 %5133, 8
  %5136 = and i1 %5134, %5135
  %5137 = and i1 %5105, %5136
  %convergence.parent.token686 = load i32, ptr %current.token, align 4
  %convergence.parent.present687 = icmp ne i32 %convergence.parent.token686, 0
  %5138 = and i1 %5137, %convergence.parent.present687
  br i1 %5138, label %convergence.cascade672, label %convergence.cascade.exit673

convergence.cascade.exit673:                      ; preds = %convergence.cascade672, %schedule.23
  %convergence.cascade.result688 = phi <8 x i1> [ %464, %schedule.23 ], [ %5132, %convergence.cascade672 ]
  %5139 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result688)
  br i1 %5139, label %convergence.target.23.ready, label %scheduler.loop

convergence.target.23.ready:                      ; preds = %convergence.cascade.exit673
  %5140 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result688)
  %5141 = bitcast <8 x i1> %convergence.cascade.result688 to i8
  %5142 = call i8 @llvm.cttz.i8(i8 %5141, i1 false)
  %5143 = zext i8 %5142 to i32
  %5144 = select i1 %5140, i32 %5143, i32 0
  %.state689 = load <8 x float>, ptr %.slot55, align 32
  %.state690 = load <8 x float>, ptr %.slot197, align 32
  %5145 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state689, <8 x float> %.state690)
  %5146 = load volatile <8 x float>, ptr %.spill204, align 32
  %5147 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5145, <8 x float> %5146
  store volatile <8 x float> %5147, ptr %.spill204, align 32
  %.state691 = load <8 x float>, ptr %.slot56, align 32
  %.state692 = load <8 x float>, ptr %.slot199, align 32
  %5148 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state691, <8 x float> %.state692)
  %5149 = load volatile <8 x float>, ptr %.spill205, align 32
  %5150 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5148, <8 x float> %5149
  store volatile <8 x float> %5150, ptr %.spill205, align 32
  %.state693 = load <8 x float>, ptr %.slot57, align 32
  %.state694 = load <8 x float>, ptr %.slot201, align 32
  %5151 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state693, <8 x float> %.state694)
  %5152 = load volatile <8 x float>, ptr %.spill206, align 32
  %5153 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5151, <8 x float> %5152
  store volatile <8 x float> %5153, ptr %.spill206, align 32
  %.state695 = load <8 x float>, ptr %.slot58, align 32
  %.state696 = load <8 x float>, ptr %.slot203, align 32
  %5154 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state695, <8 x float> %.state696)
  %5155 = load volatile <8 x float>, ptr %.spill207, align 32
  %5156 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5154, <8 x float> %5155
  store volatile <8 x float> %5156, ptr %.spill207, align 32
  %.state697 = load <8 x float>, ptr %.slot55, align 32
  %5157 = fsub <8 x float> %.state697, %5145
  %.state698 = load <8 x float>, ptr %.slot56, align 32
  %5158 = fsub <8 x float> %.state698, %5148
  %.state699 = load <8 x float>, ptr %.slot57, align 32
  %5159 = fsub <8 x float> %.state699, %5151
  %.state700 = load <8 x float>, ptr %.slot58, align 32
  %5160 = fsub <8 x float> %.state700, %5154
  %5161 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5157, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5161)
  %5162 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5158, <8 x float> zeroinitializer
  %native.exp701 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5162)
  %5163 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5159, <8 x float> zeroinitializer
  %native.exp702 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5163)
  %5164 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5160, <8 x float> zeroinitializer
  %native.exp703 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5164)
  %5165 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill208, align 64
  %5166 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %5167 = extractvalue { <8 x ptr>, <8 x i64> } %5165, 0
  %5168 = select <8 x i1> %convergence.cascade.result688, <8 x ptr> %5166, <8 x ptr> %5167
  %5169 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %5170 = extractvalue { <8 x ptr>, <8 x i64> } %5165, 1
  %5171 = select <8 x i1> %convergence.cascade.result688, <8 x i64> %5169, <8 x i64> %5170
  %5172 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5168, 0
  %5173 = insertvalue { <8 x ptr>, <8 x i64> } %5172, <8 x i64> %5171, 1
  store volatile { <8 x ptr>, <8 x i64> } %5173, ptr %tile_snapshot.spill208, align 64
  %5174 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %5175 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %5176 = add <8 x i64> %5175, zeroinitializer
  %5177 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5174, 0
  %5178 = insertvalue { <8 x ptr>, <8 x i64> } %5177, <8 x i64> %5176, 1
  %5179 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %5180 = extractvalue { <8 x ptr>, <8 x i64> } %5178, 1
  %5181 = extractelement <8 x ptr> %5179, i32 0
  %5182 = extractelement <8 x i64> %5180, i32 %5144
  %5183 = zext i32 %5144 to i64
  %5184 = mul i64 %5183, 4
  %5185 = sub i64 %5182, %5184
  %5186 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result688)
  %5187 = select i1 %5186, i64 %5185, i64 0
  %private.contiguous.address704 = getelementptr i8, ptr %5181, i64 %5187
  %private.contiguous.preserve705 = load <8 x float>, ptr %private.contiguous.address704, align 4
  %5188 = select <8 x i1> %convergence.cascade.result688, <8 x float> %native.exp, <8 x float> %private.contiguous.preserve705
  store <8 x float> %5188, ptr %private.contiguous.address704, align 4
  %5189 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %5190 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %5191 = add <8 x i64> %5190, splat (i64 32)
  %5192 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5189, 0
  %5193 = insertvalue { <8 x ptr>, <8 x i64> } %5192, <8 x i64> %5191, 1
  %5194 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %5195 = extractvalue { <8 x ptr>, <8 x i64> } %5193, 1
  %5196 = extractelement <8 x ptr> %5194, i32 0
  %5197 = extractelement <8 x i64> %5195, i32 %5144
  %5198 = zext i32 %5144 to i64
  %5199 = mul i64 %5198, 4
  %5200 = sub i64 %5197, %5199
  %5201 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result688)
  %5202 = select i1 %5201, i64 %5200, i64 0
  %private.contiguous.address706 = getelementptr i8, ptr %5196, i64 %5202
  %private.contiguous.preserve707 = load <8 x float>, ptr %private.contiguous.address706, align 4
  %5203 = select <8 x i1> %convergence.cascade.result688, <8 x float> %native.exp701, <8 x float> %private.contiguous.preserve707
  store <8 x float> %5203, ptr %private.contiguous.address706, align 4
  %5204 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %5205 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %5206 = add <8 x i64> %5205, splat (i64 64)
  %5207 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5204, 0
  %5208 = insertvalue { <8 x ptr>, <8 x i64> } %5207, <8 x i64> %5206, 1
  %5209 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %5210 = extractvalue { <8 x ptr>, <8 x i64> } %5208, 1
  %5211 = extractelement <8 x ptr> %5209, i32 0
  %5212 = extractelement <8 x i64> %5210, i32 %5144
  %5213 = zext i32 %5144 to i64
  %5214 = mul i64 %5213, 4
  %5215 = sub i64 %5212, %5214
  %5216 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result688)
  %5217 = select i1 %5216, i64 %5215, i64 0
  %private.contiguous.address708 = getelementptr i8, ptr %5211, i64 %5217
  %private.contiguous.preserve709 = load <8 x float>, ptr %private.contiguous.address708, align 4
  %5218 = select <8 x i1> %convergence.cascade.result688, <8 x float> %native.exp702, <8 x float> %private.contiguous.preserve709
  store <8 x float> %5218, ptr %private.contiguous.address708, align 4
  %5219 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %5220 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %5221 = add <8 x i64> %5220, splat (i64 96)
  %5222 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5219, 0
  %5223 = insertvalue { <8 x ptr>, <8 x i64> } %5222, <8 x i64> %5221, 1
  %5224 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %5225 = extractvalue { <8 x ptr>, <8 x i64> } %5223, 1
  %5226 = extractelement <8 x ptr> %5224, i32 0
  %5227 = extractelement <8 x i64> %5225, i32 %5144
  %5228 = zext i32 %5144 to i64
  %5229 = mul i64 %5228, 4
  %5230 = sub i64 %5227, %5229
  %5231 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result688)
  %5232 = select i1 %5231, i64 %5230, i64 0
  %private.contiguous.address710 = getelementptr i8, ptr %5226, i64 %5232
  %private.contiguous.preserve711 = load <8 x float>, ptr %private.contiguous.address710, align 4
  %5233 = select <8 x i1> %convergence.cascade.result688, <8 x float> %native.exp703, <8 x float> %private.contiguous.preserve711
  store <8 x float> %5233, ptr %private.contiguous.address710, align 4
  %.spill.load712 = load volatile <8 x float>, ptr %.spill131, align 32
  %5234 = fsub <8 x float> %.spill.load712, %5145
  %.spill.load713 = load volatile <8 x float>, ptr %.spill132, align 32
  %5235 = fsub <8 x float> %.spill.load713, %5145
  %.spill.load714 = load volatile <8 x float>, ptr %.spill133, align 32
  %5236 = fsub <8 x float> %.spill.load714, %5145
  %.spill.load715 = load volatile <8 x float>, ptr %.spill134, align 32
  %5237 = fsub <8 x float> %.spill.load715, %5145
  %.spill.load716 = load volatile <8 x float>, ptr %.spill135, align 32
  %5238 = fsub <8 x float> %.spill.load716, %5145
  %.spill.load717 = load volatile <8 x float>, ptr %.spill136, align 32
  %5239 = fsub <8 x float> %.spill.load717, %5145
  %.spill.load718 = load volatile <8 x float>, ptr %.spill137, align 32
  %5240 = fsub <8 x float> %.spill.load718, %5145
  %.spill.load719 = load volatile <8 x float>, ptr %.spill138, align 32
  %5241 = fsub <8 x float> %.spill.load719, %5145
  %.spill.load720 = load volatile <8 x float>, ptr %.spill139, align 32
  %5242 = fsub <8 x float> %.spill.load720, %5145
  %.spill.load721 = load volatile <8 x float>, ptr %.spill140, align 32
  %5243 = fsub <8 x float> %.spill.load721, %5145
  %.spill.load722 = load volatile <8 x float>, ptr %.spill141, align 32
  %5244 = fsub <8 x float> %.spill.load722, %5145
  %.spill.load723 = load volatile <8 x float>, ptr %.spill142, align 32
  %5245 = fsub <8 x float> %.spill.load723, %5145
  %.spill.load724 = load volatile <8 x float>, ptr %.spill143, align 32
  %5246 = fsub <8 x float> %.spill.load724, %5145
  %.spill.load725 = load volatile <8 x float>, ptr %.spill144, align 32
  %5247 = fsub <8 x float> %.spill.load725, %5145
  %.spill.load726 = load volatile <8 x float>, ptr %.spill145, align 32
  %5248 = fsub <8 x float> %.spill.load726, %5145
  %.spill.load727 = load volatile <8 x float>, ptr %.spill146, align 32
  %5249 = fsub <8 x float> %.spill.load727, %5145
  %.spill.load728 = load volatile <8 x float>, ptr %.spill147, align 32
  %5250 = fsub <8 x float> %.spill.load728, %5148
  %.spill.load729 = load volatile <8 x float>, ptr %.spill148, align 32
  %5251 = fsub <8 x float> %.spill.load729, %5148
  %.spill.load730 = load volatile <8 x float>, ptr %.spill149, align 32
  %5252 = fsub <8 x float> %.spill.load730, %5148
  %.spill.load731 = load volatile <8 x float>, ptr %.spill150, align 32
  %5253 = fsub <8 x float> %.spill.load731, %5148
  %.spill.load732 = load volatile <8 x float>, ptr %.spill151, align 32
  %5254 = fsub <8 x float> %.spill.load732, %5148
  %.spill.load733 = load volatile <8 x float>, ptr %.spill152, align 32
  %5255 = fsub <8 x float> %.spill.load733, %5148
  %.spill.load734 = load volatile <8 x float>, ptr %.spill153, align 32
  %5256 = fsub <8 x float> %.spill.load734, %5148
  %.spill.load735 = load volatile <8 x float>, ptr %.spill154, align 32
  %5257 = fsub <8 x float> %.spill.load735, %5148
  %.spill.load736 = load volatile <8 x float>, ptr %.spill155, align 32
  %5258 = fsub <8 x float> %.spill.load736, %5148
  %.spill.load737 = load volatile <8 x float>, ptr %.spill156, align 32
  %5259 = fsub <8 x float> %.spill.load737, %5148
  %.spill.load738 = load volatile <8 x float>, ptr %.spill157, align 32
  %5260 = fsub <8 x float> %.spill.load738, %5148
  %.spill.load739 = load volatile <8 x float>, ptr %.spill158, align 32
  %5261 = fsub <8 x float> %.spill.load739, %5148
  %.spill.load740 = load volatile <8 x float>, ptr %.spill159, align 32
  %5262 = fsub <8 x float> %.spill.load740, %5148
  %.spill.load741 = load volatile <8 x float>, ptr %.spill160, align 32
  %5263 = fsub <8 x float> %.spill.load741, %5148
  %.spill.load742 = load volatile <8 x float>, ptr %.spill161, align 32
  %5264 = fsub <8 x float> %.spill.load742, %5148
  %.spill.load743 = load volatile <8 x float>, ptr %.spill162, align 32
  %5265 = fsub <8 x float> %.spill.load743, %5148
  %.spill.load744 = load volatile <8 x float>, ptr %.spill163, align 32
  %5266 = fsub <8 x float> %.spill.load744, %5151
  %.spill.load745 = load volatile <8 x float>, ptr %.spill164, align 32
  %5267 = fsub <8 x float> %.spill.load745, %5151
  %.spill.load746 = load volatile <8 x float>, ptr %.spill165, align 32
  %5268 = fsub <8 x float> %.spill.load746, %5151
  %.spill.load747 = load volatile <8 x float>, ptr %.spill166, align 32
  %5269 = fsub <8 x float> %.spill.load747, %5151
  %.spill.load748 = load volatile <8 x float>, ptr %.spill167, align 32
  %5270 = fsub <8 x float> %.spill.load748, %5151
  %.spill.load749 = load volatile <8 x float>, ptr %.spill168, align 32
  %5271 = fsub <8 x float> %.spill.load749, %5151
  %.spill.load750 = load volatile <8 x float>, ptr %.spill169, align 32
  %5272 = fsub <8 x float> %.spill.load750, %5151
  %.spill.load751 = load volatile <8 x float>, ptr %.spill170, align 32
  %5273 = fsub <8 x float> %.spill.load751, %5151
  %.spill.load752 = load volatile <8 x float>, ptr %.spill171, align 32
  %5274 = fsub <8 x float> %.spill.load752, %5151
  %.spill.load753 = load volatile <8 x float>, ptr %.spill172, align 32
  %5275 = fsub <8 x float> %.spill.load753, %5151
  %.spill.load754 = load volatile <8 x float>, ptr %.spill173, align 32
  %5276 = fsub <8 x float> %.spill.load754, %5151
  %.spill.load755 = load volatile <8 x float>, ptr %.spill174, align 32
  %5277 = fsub <8 x float> %.spill.load755, %5151
  %.spill.load756 = load volatile <8 x float>, ptr %.spill175, align 32
  %5278 = fsub <8 x float> %.spill.load756, %5151
  %.spill.load757 = load volatile <8 x float>, ptr %.spill176, align 32
  %5279 = fsub <8 x float> %.spill.load757, %5151
  %.spill.load758 = load volatile <8 x float>, ptr %.spill177, align 32
  %5280 = fsub <8 x float> %.spill.load758, %5151
  %.spill.load759 = load volatile <8 x float>, ptr %.spill178, align 32
  %5281 = fsub <8 x float> %.spill.load759, %5151
  %.spill.load760 = load volatile <8 x float>, ptr %.spill179, align 32
  %5282 = fsub <8 x float> %.spill.load760, %5154
  %.spill.load761 = load volatile <8 x float>, ptr %.spill180, align 32
  %5283 = fsub <8 x float> %.spill.load761, %5154
  %.spill.load762 = load volatile <8 x float>, ptr %.spill181, align 32
  %5284 = fsub <8 x float> %.spill.load762, %5154
  %.spill.load763 = load volatile <8 x float>, ptr %.spill182, align 32
  %5285 = fsub <8 x float> %.spill.load763, %5154
  %.spill.load764 = load volatile <8 x float>, ptr %.spill183, align 32
  %5286 = fsub <8 x float> %.spill.load764, %5154
  %.spill.load765 = load volatile <8 x float>, ptr %.spill184, align 32
  %5287 = fsub <8 x float> %.spill.load765, %5154
  %.spill.load766 = load volatile <8 x float>, ptr %.spill185, align 32
  %5288 = fsub <8 x float> %.spill.load766, %5154
  %.spill.load767 = load volatile <8 x float>, ptr %.spill186, align 32
  %5289 = fsub <8 x float> %.spill.load767, %5154
  %.spill.load768 = load volatile <8 x float>, ptr %.spill187, align 32
  %5290 = fsub <8 x float> %.spill.load768, %5154
  %.spill.load769 = load volatile <8 x float>, ptr %.spill188, align 32
  %5291 = fsub <8 x float> %.spill.load769, %5154
  %.spill.load770 = load volatile <8 x float>, ptr %.spill189, align 32
  %5292 = fsub <8 x float> %.spill.load770, %5154
  %.spill.load771 = load volatile <8 x float>, ptr %.spill190, align 32
  %5293 = fsub <8 x float> %.spill.load771, %5154
  %.spill.load772 = load volatile <8 x float>, ptr %.spill191, align 32
  %5294 = fsub <8 x float> %.spill.load772, %5154
  %.spill.load773 = load volatile <8 x float>, ptr %.spill192, align 32
  %5295 = fsub <8 x float> %.spill.load773, %5154
  %.spill.load774 = load volatile <8 x float>, ptr %.spill193, align 32
  %5296 = fsub <8 x float> %.spill.load774, %5154
  %.spill.load775 = load volatile <8 x float>, ptr %.spill194, align 32
  %5297 = fsub <8 x float> %.spill.load775, %5154
  %5298 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5234, <8 x float> zeroinitializer
  %native.exp776 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5298)
  %5299 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5235, <8 x float> zeroinitializer
  %native.exp777 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5299)
  %5300 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5236, <8 x float> zeroinitializer
  %native.exp778 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5300)
  %5301 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5237, <8 x float> zeroinitializer
  %native.exp779 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5301)
  %5302 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5238, <8 x float> zeroinitializer
  %native.exp780 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5302)
  %5303 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5239, <8 x float> zeroinitializer
  %native.exp781 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5303)
  %5304 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5240, <8 x float> zeroinitializer
  %native.exp782 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5304)
  %5305 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5241, <8 x float> zeroinitializer
  %native.exp783 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5305)
  %5306 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5242, <8 x float> zeroinitializer
  %native.exp784 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5306)
  %5307 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5243, <8 x float> zeroinitializer
  %native.exp785 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5307)
  %5308 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5244, <8 x float> zeroinitializer
  %native.exp786 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5308)
  %5309 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5245, <8 x float> zeroinitializer
  %native.exp787 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5309)
  %5310 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5246, <8 x float> zeroinitializer
  %native.exp788 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5310)
  %5311 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5247, <8 x float> zeroinitializer
  %native.exp789 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5311)
  %5312 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5248, <8 x float> zeroinitializer
  %native.exp790 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5312)
  %5313 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5249, <8 x float> zeroinitializer
  %native.exp791 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5313)
  %5314 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5250, <8 x float> zeroinitializer
  %native.exp792 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5314)
  %5315 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5251, <8 x float> zeroinitializer
  %native.exp793 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5315)
  %5316 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5252, <8 x float> zeroinitializer
  %native.exp794 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5316)
  %5317 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5253, <8 x float> zeroinitializer
  %native.exp795 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5317)
  %5318 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5254, <8 x float> zeroinitializer
  %native.exp796 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5318)
  %5319 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5255, <8 x float> zeroinitializer
  %native.exp797 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5319)
  %5320 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5256, <8 x float> zeroinitializer
  %native.exp798 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5320)
  %5321 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5257, <8 x float> zeroinitializer
  %native.exp799 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5321)
  %5322 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5258, <8 x float> zeroinitializer
  %native.exp800 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5322)
  %5323 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5259, <8 x float> zeroinitializer
  %native.exp801 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5323)
  %5324 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5260, <8 x float> zeroinitializer
  %native.exp802 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5324)
  %5325 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5261, <8 x float> zeroinitializer
  %native.exp803 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5325)
  %5326 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5262, <8 x float> zeroinitializer
  %native.exp804 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5326)
  %5327 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5263, <8 x float> zeroinitializer
  %native.exp805 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5327)
  %5328 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5264, <8 x float> zeroinitializer
  %native.exp806 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5328)
  %5329 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5265, <8 x float> zeroinitializer
  %native.exp807 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5329)
  %5330 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5266, <8 x float> zeroinitializer
  %native.exp808 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5330)
  %5331 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5267, <8 x float> zeroinitializer
  %native.exp809 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5331)
  %5332 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5268, <8 x float> zeroinitializer
  %native.exp810 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5332)
  %5333 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5269, <8 x float> zeroinitializer
  %native.exp811 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5333)
  %5334 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5270, <8 x float> zeroinitializer
  %native.exp812 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5334)
  %5335 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5271, <8 x float> zeroinitializer
  %native.exp813 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5335)
  %5336 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5272, <8 x float> zeroinitializer
  %native.exp814 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5336)
  %5337 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5273, <8 x float> zeroinitializer
  %native.exp815 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5337)
  %5338 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5274, <8 x float> zeroinitializer
  %native.exp816 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5338)
  %5339 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5275, <8 x float> zeroinitializer
  %native.exp817 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5339)
  %5340 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5276, <8 x float> zeroinitializer
  %native.exp818 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5340)
  %5341 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5277, <8 x float> zeroinitializer
  %native.exp819 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5341)
  %5342 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5278, <8 x float> zeroinitializer
  %native.exp820 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5342)
  %5343 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5279, <8 x float> zeroinitializer
  %native.exp821 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5343)
  %5344 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5280, <8 x float> zeroinitializer
  %native.exp822 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5344)
  %5345 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5281, <8 x float> zeroinitializer
  %native.exp823 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5345)
  %5346 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5282, <8 x float> zeroinitializer
  %native.exp824 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5346)
  %5347 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5283, <8 x float> zeroinitializer
  %native.exp825 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5347)
  %5348 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5284, <8 x float> zeroinitializer
  %native.exp826 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5348)
  %5349 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5285, <8 x float> zeroinitializer
  %native.exp827 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5349)
  %5350 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5286, <8 x float> zeroinitializer
  %native.exp828 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5350)
  %5351 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5287, <8 x float> zeroinitializer
  %native.exp829 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5351)
  %5352 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5288, <8 x float> zeroinitializer
  %native.exp830 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5352)
  %5353 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5289, <8 x float> zeroinitializer
  %native.exp831 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5353)
  %5354 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5290, <8 x float> zeroinitializer
  %native.exp832 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5354)
  %5355 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5291, <8 x float> zeroinitializer
  %native.exp833 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5355)
  %5356 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5292, <8 x float> zeroinitializer
  %native.exp834 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5356)
  %5357 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5293, <8 x float> zeroinitializer
  %native.exp835 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5357)
  %5358 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5294, <8 x float> zeroinitializer
  %native.exp836 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5358)
  %5359 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5295, <8 x float> zeroinitializer
  %native.exp837 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5359)
  %5360 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5296, <8 x float> zeroinitializer
  %native.exp838 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5360)
  %5361 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5297, <8 x float> zeroinitializer
  %native.exp839 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5361)
  %.spill.load840 = load volatile <8 x i1>, ptr %.spill67, align 1
  %5362 = select <8 x i1> %.spill.load840, <8 x float> %native.exp776, <8 x float> zeroinitializer
  %.spill.load841 = load volatile <8 x i1>, ptr %.spill71, align 1
  %5363 = select <8 x i1> %.spill.load841, <8 x float> %native.exp777, <8 x float> zeroinitializer
  %.spill.load842 = load volatile <8 x i1>, ptr %.spill75, align 1
  %5364 = select <8 x i1> %.spill.load842, <8 x float> %native.exp778, <8 x float> zeroinitializer
  %.spill.load843 = load volatile <8 x i1>, ptr %.spill79, align 1
  %5365 = select <8 x i1> %.spill.load843, <8 x float> %native.exp779, <8 x float> zeroinitializer
  %.spill.load844 = load volatile <8 x i1>, ptr %.spill83, align 1
  %5366 = select <8 x i1> %.spill.load844, <8 x float> %native.exp780, <8 x float> zeroinitializer
  %.spill.load845 = load volatile <8 x i1>, ptr %.spill87, align 1
  %5367 = select <8 x i1> %.spill.load845, <8 x float> %native.exp781, <8 x float> zeroinitializer
  %.spill.load846 = load volatile <8 x i1>, ptr %.spill91, align 1
  %5368 = select <8 x i1> %.spill.load846, <8 x float> %native.exp782, <8 x float> zeroinitializer
  %.spill.load847 = load volatile <8 x i1>, ptr %.spill95, align 1
  %5369 = select <8 x i1> %.spill.load847, <8 x float> %native.exp783, <8 x float> zeroinitializer
  %.spill.load848 = load volatile <8 x i1>, ptr %.spill99, align 1
  %5370 = select <8 x i1> %.spill.load848, <8 x float> %native.exp784, <8 x float> zeroinitializer
  %.spill.load849 = load volatile <8 x i1>, ptr %.spill103, align 1
  %5371 = select <8 x i1> %.spill.load849, <8 x float> %native.exp785, <8 x float> zeroinitializer
  %.spill.load850 = load volatile <8 x i1>, ptr %.spill107, align 1
  %5372 = select <8 x i1> %.spill.load850, <8 x float> %native.exp786, <8 x float> zeroinitializer
  %.spill.load851 = load volatile <8 x i1>, ptr %.spill111, align 1
  %5373 = select <8 x i1> %.spill.load851, <8 x float> %native.exp787, <8 x float> zeroinitializer
  %.spill.load852 = load volatile <8 x i1>, ptr %.spill115, align 1
  %5374 = select <8 x i1> %.spill.load852, <8 x float> %native.exp788, <8 x float> zeroinitializer
  %.spill.load853 = load volatile <8 x i1>, ptr %.spill119, align 1
  %5375 = select <8 x i1> %.spill.load853, <8 x float> %native.exp789, <8 x float> zeroinitializer
  %.spill.load854 = load volatile <8 x i1>, ptr %.spill123, align 1
  %5376 = select <8 x i1> %.spill.load854, <8 x float> %native.exp790, <8 x float> zeroinitializer
  %.spill.load855 = load volatile <8 x i1>, ptr %.spill127, align 1
  %5377 = select <8 x i1> %.spill.load855, <8 x float> %native.exp791, <8 x float> zeroinitializer
  %.spill.load856 = load volatile <8 x i1>, ptr %.spill68, align 1
  %5378 = select <8 x i1> %.spill.load856, <8 x float> %native.exp792, <8 x float> zeroinitializer
  %.spill.load857 = load volatile <8 x i1>, ptr %.spill72, align 1
  %5379 = select <8 x i1> %.spill.load857, <8 x float> %native.exp793, <8 x float> zeroinitializer
  %.spill.load858 = load volatile <8 x i1>, ptr %.spill76, align 1
  %5380 = select <8 x i1> %.spill.load858, <8 x float> %native.exp794, <8 x float> zeroinitializer
  %.spill.load859 = load volatile <8 x i1>, ptr %.spill80, align 1
  %5381 = select <8 x i1> %.spill.load859, <8 x float> %native.exp795, <8 x float> zeroinitializer
  %.spill.load860 = load volatile <8 x i1>, ptr %.spill84, align 1
  %5382 = select <8 x i1> %.spill.load860, <8 x float> %native.exp796, <8 x float> zeroinitializer
  %.spill.load861 = load volatile <8 x i1>, ptr %.spill88, align 1
  %5383 = select <8 x i1> %.spill.load861, <8 x float> %native.exp797, <8 x float> zeroinitializer
  %.spill.load862 = load volatile <8 x i1>, ptr %.spill92, align 1
  %5384 = select <8 x i1> %.spill.load862, <8 x float> %native.exp798, <8 x float> zeroinitializer
  %.spill.load863 = load volatile <8 x i1>, ptr %.spill96, align 1
  %5385 = select <8 x i1> %.spill.load863, <8 x float> %native.exp799, <8 x float> zeroinitializer
  %.spill.load864 = load volatile <8 x i1>, ptr %.spill100, align 1
  %5386 = select <8 x i1> %.spill.load864, <8 x float> %native.exp800, <8 x float> zeroinitializer
  %.spill.load865 = load volatile <8 x i1>, ptr %.spill104, align 1
  %5387 = select <8 x i1> %.spill.load865, <8 x float> %native.exp801, <8 x float> zeroinitializer
  %.spill.load866 = load volatile <8 x i1>, ptr %.spill108, align 1
  %5388 = select <8 x i1> %.spill.load866, <8 x float> %native.exp802, <8 x float> zeroinitializer
  %.spill.load867 = load volatile <8 x i1>, ptr %.spill112, align 1
  %5389 = select <8 x i1> %.spill.load867, <8 x float> %native.exp803, <8 x float> zeroinitializer
  %.spill.load868 = load volatile <8 x i1>, ptr %.spill116, align 1
  %5390 = select <8 x i1> %.spill.load868, <8 x float> %native.exp804, <8 x float> zeroinitializer
  %.spill.load869 = load volatile <8 x i1>, ptr %.spill120, align 1
  %5391 = select <8 x i1> %.spill.load869, <8 x float> %native.exp805, <8 x float> zeroinitializer
  %.spill.load870 = load volatile <8 x i1>, ptr %.spill124, align 1
  %5392 = select <8 x i1> %.spill.load870, <8 x float> %native.exp806, <8 x float> zeroinitializer
  %.spill.load871 = load volatile <8 x i1>, ptr %.spill128, align 1
  %5393 = select <8 x i1> %.spill.load871, <8 x float> %native.exp807, <8 x float> zeroinitializer
  %.spill.load872 = load volatile <8 x i1>, ptr %.spill69, align 1
  %5394 = select <8 x i1> %.spill.load872, <8 x float> %native.exp808, <8 x float> zeroinitializer
  %.spill.load873 = load volatile <8 x i1>, ptr %.spill73, align 1
  %5395 = select <8 x i1> %.spill.load873, <8 x float> %native.exp809, <8 x float> zeroinitializer
  %.spill.load874 = load volatile <8 x i1>, ptr %.spill77, align 1
  %5396 = select <8 x i1> %.spill.load874, <8 x float> %native.exp810, <8 x float> zeroinitializer
  %.spill.load875 = load volatile <8 x i1>, ptr %.spill81, align 1
  %5397 = select <8 x i1> %.spill.load875, <8 x float> %native.exp811, <8 x float> zeroinitializer
  %.spill.load876 = load volatile <8 x i1>, ptr %.spill85, align 1
  %5398 = select <8 x i1> %.spill.load876, <8 x float> %native.exp812, <8 x float> zeroinitializer
  %.spill.load877 = load volatile <8 x i1>, ptr %.spill89, align 1
  %5399 = select <8 x i1> %.spill.load877, <8 x float> %native.exp813, <8 x float> zeroinitializer
  %.spill.load878 = load volatile <8 x i1>, ptr %.spill93, align 1
  %5400 = select <8 x i1> %.spill.load878, <8 x float> %native.exp814, <8 x float> zeroinitializer
  %.spill.load879 = load volatile <8 x i1>, ptr %.spill97, align 1
  %5401 = select <8 x i1> %.spill.load879, <8 x float> %native.exp815, <8 x float> zeroinitializer
  %.spill.load880 = load volatile <8 x i1>, ptr %.spill101, align 1
  %5402 = select <8 x i1> %.spill.load880, <8 x float> %native.exp816, <8 x float> zeroinitializer
  %.spill.load881 = load volatile <8 x i1>, ptr %.spill105, align 1
  %5403 = select <8 x i1> %.spill.load881, <8 x float> %native.exp817, <8 x float> zeroinitializer
  %.spill.load882 = load volatile <8 x i1>, ptr %.spill109, align 1
  %5404 = select <8 x i1> %.spill.load882, <8 x float> %native.exp818, <8 x float> zeroinitializer
  %.spill.load883 = load volatile <8 x i1>, ptr %.spill113, align 1
  %5405 = select <8 x i1> %.spill.load883, <8 x float> %native.exp819, <8 x float> zeroinitializer
  %.spill.load884 = load volatile <8 x i1>, ptr %.spill117, align 1
  %5406 = select <8 x i1> %.spill.load884, <8 x float> %native.exp820, <8 x float> zeroinitializer
  %.spill.load885 = load volatile <8 x i1>, ptr %.spill121, align 1
  %5407 = select <8 x i1> %.spill.load885, <8 x float> %native.exp821, <8 x float> zeroinitializer
  %.spill.load886 = load volatile <8 x i1>, ptr %.spill125, align 1
  %5408 = select <8 x i1> %.spill.load886, <8 x float> %native.exp822, <8 x float> zeroinitializer
  %.spill.load887 = load volatile <8 x i1>, ptr %.spill129, align 1
  %5409 = select <8 x i1> %.spill.load887, <8 x float> %native.exp823, <8 x float> zeroinitializer
  %.spill.load888 = load volatile <8 x i1>, ptr %.spill70, align 1
  %5410 = select <8 x i1> %.spill.load888, <8 x float> %native.exp824, <8 x float> zeroinitializer
  %.spill.load889 = load volatile <8 x i1>, ptr %.spill74, align 1
  %5411 = select <8 x i1> %.spill.load889, <8 x float> %native.exp825, <8 x float> zeroinitializer
  %.spill.load890 = load volatile <8 x i1>, ptr %.spill78, align 1
  %5412 = select <8 x i1> %.spill.load890, <8 x float> %native.exp826, <8 x float> zeroinitializer
  %.spill.load891 = load volatile <8 x i1>, ptr %.spill82, align 1
  %5413 = select <8 x i1> %.spill.load891, <8 x float> %native.exp827, <8 x float> zeroinitializer
  %.spill.load892 = load volatile <8 x i1>, ptr %.spill86, align 1
  %5414 = select <8 x i1> %.spill.load892, <8 x float> %native.exp828, <8 x float> zeroinitializer
  %.spill.load893 = load volatile <8 x i1>, ptr %.spill90, align 1
  %5415 = select <8 x i1> %.spill.load893, <8 x float> %native.exp829, <8 x float> zeroinitializer
  %.spill.load894 = load volatile <8 x i1>, ptr %.spill94, align 1
  %5416 = select <8 x i1> %.spill.load894, <8 x float> %native.exp830, <8 x float> zeroinitializer
  %.spill.load895 = load volatile <8 x i1>, ptr %.spill98, align 1
  %5417 = select <8 x i1> %.spill.load895, <8 x float> %native.exp831, <8 x float> zeroinitializer
  %.spill.load896 = load volatile <8 x i1>, ptr %.spill102, align 1
  %5418 = select <8 x i1> %.spill.load896, <8 x float> %native.exp832, <8 x float> zeroinitializer
  %.spill.load897 = load volatile <8 x i1>, ptr %.spill106, align 1
  %5419 = select <8 x i1> %.spill.load897, <8 x float> %native.exp833, <8 x float> zeroinitializer
  %.spill.load898 = load volatile <8 x i1>, ptr %.spill110, align 1
  %5420 = select <8 x i1> %.spill.load898, <8 x float> %native.exp834, <8 x float> zeroinitializer
  %.spill.load899 = load volatile <8 x i1>, ptr %.spill114, align 1
  %5421 = select <8 x i1> %.spill.load899, <8 x float> %native.exp835, <8 x float> zeroinitializer
  %.spill.load900 = load volatile <8 x i1>, ptr %.spill118, align 1
  %5422 = select <8 x i1> %.spill.load900, <8 x float> %native.exp836, <8 x float> zeroinitializer
  %.spill.load901 = load volatile <8 x i1>, ptr %.spill122, align 1
  %5423 = select <8 x i1> %.spill.load901, <8 x float> %native.exp837, <8 x float> zeroinitializer
  %.spill.load902 = load volatile <8 x i1>, ptr %.spill126, align 1
  %5424 = select <8 x i1> %.spill.load902, <8 x float> %native.exp838, <8 x float> zeroinitializer
  %.spill.load903 = load volatile <8 x i1>, ptr %.spill130, align 1
  %5425 = select <8 x i1> %.spill.load903, <8 x float> %native.exp839, <8 x float> zeroinitializer
  %5426 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill209, align 64
  %5427 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5428 = extractvalue { <8 x ptr>, <8 x i64> } %5426, 0
  %5429 = select <8 x i1> %convergence.cascade.result688, <8 x ptr> %5427, <8 x ptr> %5428
  %5430 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5431 = extractvalue { <8 x ptr>, <8 x i64> } %5426, 1
  %5432 = select <8 x i1> %convergence.cascade.result688, <8 x i64> %5430, <8 x i64> %5431
  %5433 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5429, 0
  %5434 = insertvalue { <8 x ptr>, <8 x i64> } %5433, <8 x i64> %5432, 1
  store { <8 x ptr>, <8 x i64> } %5434, ptr %tile_snapshot.spill209, align 64
  %5435 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5436 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5437 = add <8 x i64> %5436, zeroinitializer
  %5438 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5435, 0
  %5439 = insertvalue { <8 x ptr>, <8 x i64> } %5438, <8 x i64> %5437, 1
  %5440 = extractvalue { <8 x ptr>, <8 x i64> } %5439, 0
  %5441 = extractvalue { <8 x ptr>, <8 x i64> } %5439, 1
  %5442 = getelementptr i8, <8 x ptr> %5440, <8 x i64> %5441
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5362, <8 x ptr> align 1 %5442, <8 x i1> %convergence.cascade.result688)
  %5443 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5444 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5445 = add <8 x i64> %5444, splat (i64 4)
  %5446 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5443, 0
  %5447 = insertvalue { <8 x ptr>, <8 x i64> } %5446, <8 x i64> %5445, 1
  %5448 = extractvalue { <8 x ptr>, <8 x i64> } %5447, 0
  %5449 = extractvalue { <8 x ptr>, <8 x i64> } %5447, 1
  %5450 = getelementptr i8, <8 x ptr> %5448, <8 x i64> %5449
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5363, <8 x ptr> align 1 %5450, <8 x i1> %convergence.cascade.result688)
  %5451 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5452 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5453 = add <8 x i64> %5452, splat (i64 8)
  %5454 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5451, 0
  %5455 = insertvalue { <8 x ptr>, <8 x i64> } %5454, <8 x i64> %5453, 1
  %5456 = extractvalue { <8 x ptr>, <8 x i64> } %5455, 0
  %5457 = extractvalue { <8 x ptr>, <8 x i64> } %5455, 1
  %5458 = getelementptr i8, <8 x ptr> %5456, <8 x i64> %5457
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5364, <8 x ptr> align 1 %5458, <8 x i1> %convergence.cascade.result688)
  %5459 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5460 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5461 = add <8 x i64> %5460, splat (i64 12)
  %5462 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5459, 0
  %5463 = insertvalue { <8 x ptr>, <8 x i64> } %5462, <8 x i64> %5461, 1
  %5464 = extractvalue { <8 x ptr>, <8 x i64> } %5463, 0
  %5465 = extractvalue { <8 x ptr>, <8 x i64> } %5463, 1
  %5466 = getelementptr i8, <8 x ptr> %5464, <8 x i64> %5465
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5365, <8 x ptr> align 1 %5466, <8 x i1> %convergence.cascade.result688)
  %5467 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5468 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5469 = add <8 x i64> %5468, splat (i64 16)
  %5470 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5467, 0
  %5471 = insertvalue { <8 x ptr>, <8 x i64> } %5470, <8 x i64> %5469, 1
  %5472 = extractvalue { <8 x ptr>, <8 x i64> } %5471, 0
  %5473 = extractvalue { <8 x ptr>, <8 x i64> } %5471, 1
  %5474 = getelementptr i8, <8 x ptr> %5472, <8 x i64> %5473
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5366, <8 x ptr> align 1 %5474, <8 x i1> %convergence.cascade.result688)
  %5475 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5476 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5477 = add <8 x i64> %5476, splat (i64 20)
  %5478 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5475, 0
  %5479 = insertvalue { <8 x ptr>, <8 x i64> } %5478, <8 x i64> %5477, 1
  %5480 = extractvalue { <8 x ptr>, <8 x i64> } %5479, 0
  %5481 = extractvalue { <8 x ptr>, <8 x i64> } %5479, 1
  %5482 = getelementptr i8, <8 x ptr> %5480, <8 x i64> %5481
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5367, <8 x ptr> align 1 %5482, <8 x i1> %convergence.cascade.result688)
  %5483 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5484 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5485 = add <8 x i64> %5484, splat (i64 24)
  %5486 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5483, 0
  %5487 = insertvalue { <8 x ptr>, <8 x i64> } %5486, <8 x i64> %5485, 1
  %5488 = extractvalue { <8 x ptr>, <8 x i64> } %5487, 0
  %5489 = extractvalue { <8 x ptr>, <8 x i64> } %5487, 1
  %5490 = getelementptr i8, <8 x ptr> %5488, <8 x i64> %5489
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5368, <8 x ptr> align 1 %5490, <8 x i1> %convergence.cascade.result688)
  %5491 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5492 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5493 = add <8 x i64> %5492, splat (i64 28)
  %5494 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5491, 0
  %5495 = insertvalue { <8 x ptr>, <8 x i64> } %5494, <8 x i64> %5493, 1
  %5496 = extractvalue { <8 x ptr>, <8 x i64> } %5495, 0
  %5497 = extractvalue { <8 x ptr>, <8 x i64> } %5495, 1
  %5498 = getelementptr i8, <8 x ptr> %5496, <8 x i64> %5497
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5369, <8 x ptr> align 1 %5498, <8 x i1> %convergence.cascade.result688)
  %5499 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5500 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5501 = add <8 x i64> %5500, splat (i64 32)
  %5502 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5499, 0
  %5503 = insertvalue { <8 x ptr>, <8 x i64> } %5502, <8 x i64> %5501, 1
  %5504 = extractvalue { <8 x ptr>, <8 x i64> } %5503, 0
  %5505 = extractvalue { <8 x ptr>, <8 x i64> } %5503, 1
  %5506 = getelementptr i8, <8 x ptr> %5504, <8 x i64> %5505
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5370, <8 x ptr> align 1 %5506, <8 x i1> %convergence.cascade.result688)
  %5507 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5508 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5509 = add <8 x i64> %5508, splat (i64 36)
  %5510 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5507, 0
  %5511 = insertvalue { <8 x ptr>, <8 x i64> } %5510, <8 x i64> %5509, 1
  %5512 = extractvalue { <8 x ptr>, <8 x i64> } %5511, 0
  %5513 = extractvalue { <8 x ptr>, <8 x i64> } %5511, 1
  %5514 = getelementptr i8, <8 x ptr> %5512, <8 x i64> %5513
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5371, <8 x ptr> align 1 %5514, <8 x i1> %convergence.cascade.result688)
  %5515 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5516 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5517 = add <8 x i64> %5516, splat (i64 40)
  %5518 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5515, 0
  %5519 = insertvalue { <8 x ptr>, <8 x i64> } %5518, <8 x i64> %5517, 1
  %5520 = extractvalue { <8 x ptr>, <8 x i64> } %5519, 0
  %5521 = extractvalue { <8 x ptr>, <8 x i64> } %5519, 1
  %5522 = getelementptr i8, <8 x ptr> %5520, <8 x i64> %5521
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5372, <8 x ptr> align 1 %5522, <8 x i1> %convergence.cascade.result688)
  %5523 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5524 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5525 = add <8 x i64> %5524, splat (i64 44)
  %5526 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5523, 0
  %5527 = insertvalue { <8 x ptr>, <8 x i64> } %5526, <8 x i64> %5525, 1
  %5528 = extractvalue { <8 x ptr>, <8 x i64> } %5527, 0
  %5529 = extractvalue { <8 x ptr>, <8 x i64> } %5527, 1
  %5530 = getelementptr i8, <8 x ptr> %5528, <8 x i64> %5529
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5373, <8 x ptr> align 1 %5530, <8 x i1> %convergence.cascade.result688)
  %5531 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5532 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5533 = add <8 x i64> %5532, splat (i64 48)
  %5534 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5531, 0
  %5535 = insertvalue { <8 x ptr>, <8 x i64> } %5534, <8 x i64> %5533, 1
  %5536 = extractvalue { <8 x ptr>, <8 x i64> } %5535, 0
  %5537 = extractvalue { <8 x ptr>, <8 x i64> } %5535, 1
  %5538 = getelementptr i8, <8 x ptr> %5536, <8 x i64> %5537
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5374, <8 x ptr> align 1 %5538, <8 x i1> %convergence.cascade.result688)
  %5539 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5540 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5541 = add <8 x i64> %5540, splat (i64 52)
  %5542 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5539, 0
  %5543 = insertvalue { <8 x ptr>, <8 x i64> } %5542, <8 x i64> %5541, 1
  %5544 = extractvalue { <8 x ptr>, <8 x i64> } %5543, 0
  %5545 = extractvalue { <8 x ptr>, <8 x i64> } %5543, 1
  %5546 = getelementptr i8, <8 x ptr> %5544, <8 x i64> %5545
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5375, <8 x ptr> align 1 %5546, <8 x i1> %convergence.cascade.result688)
  %5547 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5548 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5549 = add <8 x i64> %5548, splat (i64 56)
  %5550 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5547, 0
  %5551 = insertvalue { <8 x ptr>, <8 x i64> } %5550, <8 x i64> %5549, 1
  %5552 = extractvalue { <8 x ptr>, <8 x i64> } %5551, 0
  %5553 = extractvalue { <8 x ptr>, <8 x i64> } %5551, 1
  %5554 = getelementptr i8, <8 x ptr> %5552, <8 x i64> %5553
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5376, <8 x ptr> align 1 %5554, <8 x i1> %convergence.cascade.result688)
  %5555 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5556 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5557 = add <8 x i64> %5556, splat (i64 60)
  %5558 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5555, 0
  %5559 = insertvalue { <8 x ptr>, <8 x i64> } %5558, <8 x i64> %5557, 1
  %5560 = extractvalue { <8 x ptr>, <8 x i64> } %5559, 0
  %5561 = extractvalue { <8 x ptr>, <8 x i64> } %5559, 1
  %5562 = getelementptr i8, <8 x ptr> %5560, <8 x i64> %5561
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5377, <8 x ptr> align 1 %5562, <8 x i1> %convergence.cascade.result688)
  %5563 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5564 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5565 = add <8 x i64> %5564, splat (i64 64)
  %5566 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5563, 0
  %5567 = insertvalue { <8 x ptr>, <8 x i64> } %5566, <8 x i64> %5565, 1
  %5568 = extractvalue { <8 x ptr>, <8 x i64> } %5567, 0
  %5569 = extractvalue { <8 x ptr>, <8 x i64> } %5567, 1
  %5570 = getelementptr i8, <8 x ptr> %5568, <8 x i64> %5569
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5378, <8 x ptr> align 1 %5570, <8 x i1> %convergence.cascade.result688)
  %5571 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5572 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5573 = add <8 x i64> %5572, splat (i64 68)
  %5574 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5571, 0
  %5575 = insertvalue { <8 x ptr>, <8 x i64> } %5574, <8 x i64> %5573, 1
  %5576 = extractvalue { <8 x ptr>, <8 x i64> } %5575, 0
  %5577 = extractvalue { <8 x ptr>, <8 x i64> } %5575, 1
  %5578 = getelementptr i8, <8 x ptr> %5576, <8 x i64> %5577
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5379, <8 x ptr> align 1 %5578, <8 x i1> %convergence.cascade.result688)
  %5579 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5580 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5581 = add <8 x i64> %5580, splat (i64 72)
  %5582 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5579, 0
  %5583 = insertvalue { <8 x ptr>, <8 x i64> } %5582, <8 x i64> %5581, 1
  %5584 = extractvalue { <8 x ptr>, <8 x i64> } %5583, 0
  %5585 = extractvalue { <8 x ptr>, <8 x i64> } %5583, 1
  %5586 = getelementptr i8, <8 x ptr> %5584, <8 x i64> %5585
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5380, <8 x ptr> align 1 %5586, <8 x i1> %convergence.cascade.result688)
  %5587 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5588 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5589 = add <8 x i64> %5588, splat (i64 76)
  %5590 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5587, 0
  %5591 = insertvalue { <8 x ptr>, <8 x i64> } %5590, <8 x i64> %5589, 1
  %5592 = extractvalue { <8 x ptr>, <8 x i64> } %5591, 0
  %5593 = extractvalue { <8 x ptr>, <8 x i64> } %5591, 1
  %5594 = getelementptr i8, <8 x ptr> %5592, <8 x i64> %5593
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5381, <8 x ptr> align 1 %5594, <8 x i1> %convergence.cascade.result688)
  %5595 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5596 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5597 = add <8 x i64> %5596, splat (i64 80)
  %5598 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5595, 0
  %5599 = insertvalue { <8 x ptr>, <8 x i64> } %5598, <8 x i64> %5597, 1
  %5600 = extractvalue { <8 x ptr>, <8 x i64> } %5599, 0
  %5601 = extractvalue { <8 x ptr>, <8 x i64> } %5599, 1
  %5602 = getelementptr i8, <8 x ptr> %5600, <8 x i64> %5601
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5382, <8 x ptr> align 1 %5602, <8 x i1> %convergence.cascade.result688)
  %5603 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5604 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5605 = add <8 x i64> %5604, splat (i64 84)
  %5606 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5603, 0
  %5607 = insertvalue { <8 x ptr>, <8 x i64> } %5606, <8 x i64> %5605, 1
  %5608 = extractvalue { <8 x ptr>, <8 x i64> } %5607, 0
  %5609 = extractvalue { <8 x ptr>, <8 x i64> } %5607, 1
  %5610 = getelementptr i8, <8 x ptr> %5608, <8 x i64> %5609
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5383, <8 x ptr> align 1 %5610, <8 x i1> %convergence.cascade.result688)
  %5611 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5612 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5613 = add <8 x i64> %5612, splat (i64 88)
  %5614 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5611, 0
  %5615 = insertvalue { <8 x ptr>, <8 x i64> } %5614, <8 x i64> %5613, 1
  %5616 = extractvalue { <8 x ptr>, <8 x i64> } %5615, 0
  %5617 = extractvalue { <8 x ptr>, <8 x i64> } %5615, 1
  %5618 = getelementptr i8, <8 x ptr> %5616, <8 x i64> %5617
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5384, <8 x ptr> align 1 %5618, <8 x i1> %convergence.cascade.result688)
  %5619 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5620 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5621 = add <8 x i64> %5620, splat (i64 92)
  %5622 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5619, 0
  %5623 = insertvalue { <8 x ptr>, <8 x i64> } %5622, <8 x i64> %5621, 1
  %5624 = extractvalue { <8 x ptr>, <8 x i64> } %5623, 0
  %5625 = extractvalue { <8 x ptr>, <8 x i64> } %5623, 1
  %5626 = getelementptr i8, <8 x ptr> %5624, <8 x i64> %5625
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5385, <8 x ptr> align 1 %5626, <8 x i1> %convergence.cascade.result688)
  %5627 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5628 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5629 = add <8 x i64> %5628, splat (i64 96)
  %5630 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5627, 0
  %5631 = insertvalue { <8 x ptr>, <8 x i64> } %5630, <8 x i64> %5629, 1
  %5632 = extractvalue { <8 x ptr>, <8 x i64> } %5631, 0
  %5633 = extractvalue { <8 x ptr>, <8 x i64> } %5631, 1
  %5634 = getelementptr i8, <8 x ptr> %5632, <8 x i64> %5633
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5386, <8 x ptr> align 1 %5634, <8 x i1> %convergence.cascade.result688)
  %5635 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5636 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5637 = add <8 x i64> %5636, splat (i64 100)
  %5638 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5635, 0
  %5639 = insertvalue { <8 x ptr>, <8 x i64> } %5638, <8 x i64> %5637, 1
  %5640 = extractvalue { <8 x ptr>, <8 x i64> } %5639, 0
  %5641 = extractvalue { <8 x ptr>, <8 x i64> } %5639, 1
  %5642 = getelementptr i8, <8 x ptr> %5640, <8 x i64> %5641
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5387, <8 x ptr> align 1 %5642, <8 x i1> %convergence.cascade.result688)
  %5643 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5644 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5645 = add <8 x i64> %5644, splat (i64 104)
  %5646 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5643, 0
  %5647 = insertvalue { <8 x ptr>, <8 x i64> } %5646, <8 x i64> %5645, 1
  %5648 = extractvalue { <8 x ptr>, <8 x i64> } %5647, 0
  %5649 = extractvalue { <8 x ptr>, <8 x i64> } %5647, 1
  %5650 = getelementptr i8, <8 x ptr> %5648, <8 x i64> %5649
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5388, <8 x ptr> align 1 %5650, <8 x i1> %convergence.cascade.result688)
  %5651 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5652 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5653 = add <8 x i64> %5652, splat (i64 108)
  %5654 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5651, 0
  %5655 = insertvalue { <8 x ptr>, <8 x i64> } %5654, <8 x i64> %5653, 1
  %5656 = extractvalue { <8 x ptr>, <8 x i64> } %5655, 0
  %5657 = extractvalue { <8 x ptr>, <8 x i64> } %5655, 1
  %5658 = getelementptr i8, <8 x ptr> %5656, <8 x i64> %5657
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5389, <8 x ptr> align 1 %5658, <8 x i1> %convergence.cascade.result688)
  %5659 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5660 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5661 = add <8 x i64> %5660, splat (i64 112)
  %5662 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5659, 0
  %5663 = insertvalue { <8 x ptr>, <8 x i64> } %5662, <8 x i64> %5661, 1
  %5664 = extractvalue { <8 x ptr>, <8 x i64> } %5663, 0
  %5665 = extractvalue { <8 x ptr>, <8 x i64> } %5663, 1
  %5666 = getelementptr i8, <8 x ptr> %5664, <8 x i64> %5665
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5390, <8 x ptr> align 1 %5666, <8 x i1> %convergence.cascade.result688)
  %5667 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5668 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5669 = add <8 x i64> %5668, splat (i64 116)
  %5670 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5667, 0
  %5671 = insertvalue { <8 x ptr>, <8 x i64> } %5670, <8 x i64> %5669, 1
  %5672 = extractvalue { <8 x ptr>, <8 x i64> } %5671, 0
  %5673 = extractvalue { <8 x ptr>, <8 x i64> } %5671, 1
  %5674 = getelementptr i8, <8 x ptr> %5672, <8 x i64> %5673
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5391, <8 x ptr> align 1 %5674, <8 x i1> %convergence.cascade.result688)
  %5675 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5676 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5677 = add <8 x i64> %5676, splat (i64 120)
  %5678 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5675, 0
  %5679 = insertvalue { <8 x ptr>, <8 x i64> } %5678, <8 x i64> %5677, 1
  %5680 = extractvalue { <8 x ptr>, <8 x i64> } %5679, 0
  %5681 = extractvalue { <8 x ptr>, <8 x i64> } %5679, 1
  %5682 = getelementptr i8, <8 x ptr> %5680, <8 x i64> %5681
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5392, <8 x ptr> align 1 %5682, <8 x i1> %convergence.cascade.result688)
  %5683 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5684 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5685 = add <8 x i64> %5684, splat (i64 124)
  %5686 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5683, 0
  %5687 = insertvalue { <8 x ptr>, <8 x i64> } %5686, <8 x i64> %5685, 1
  %5688 = extractvalue { <8 x ptr>, <8 x i64> } %5687, 0
  %5689 = extractvalue { <8 x ptr>, <8 x i64> } %5687, 1
  %5690 = getelementptr i8, <8 x ptr> %5688, <8 x i64> %5689
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5393, <8 x ptr> align 1 %5690, <8 x i1> %convergence.cascade.result688)
  %5691 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5692 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5693 = add <8 x i64> %5692, splat (i64 128)
  %5694 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5691, 0
  %5695 = insertvalue { <8 x ptr>, <8 x i64> } %5694, <8 x i64> %5693, 1
  %5696 = extractvalue { <8 x ptr>, <8 x i64> } %5695, 0
  %5697 = extractvalue { <8 x ptr>, <8 x i64> } %5695, 1
  %5698 = getelementptr i8, <8 x ptr> %5696, <8 x i64> %5697
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5394, <8 x ptr> align 1 %5698, <8 x i1> %convergence.cascade.result688)
  %5699 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5700 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5701 = add <8 x i64> %5700, splat (i64 132)
  %5702 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5699, 0
  %5703 = insertvalue { <8 x ptr>, <8 x i64> } %5702, <8 x i64> %5701, 1
  %5704 = extractvalue { <8 x ptr>, <8 x i64> } %5703, 0
  %5705 = extractvalue { <8 x ptr>, <8 x i64> } %5703, 1
  %5706 = getelementptr i8, <8 x ptr> %5704, <8 x i64> %5705
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5395, <8 x ptr> align 1 %5706, <8 x i1> %convergence.cascade.result688)
  %5707 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5708 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5709 = add <8 x i64> %5708, splat (i64 136)
  %5710 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5707, 0
  %5711 = insertvalue { <8 x ptr>, <8 x i64> } %5710, <8 x i64> %5709, 1
  %5712 = extractvalue { <8 x ptr>, <8 x i64> } %5711, 0
  %5713 = extractvalue { <8 x ptr>, <8 x i64> } %5711, 1
  %5714 = getelementptr i8, <8 x ptr> %5712, <8 x i64> %5713
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5396, <8 x ptr> align 1 %5714, <8 x i1> %convergence.cascade.result688)
  %5715 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5716 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5717 = add <8 x i64> %5716, splat (i64 140)
  %5718 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5715, 0
  %5719 = insertvalue { <8 x ptr>, <8 x i64> } %5718, <8 x i64> %5717, 1
  %5720 = extractvalue { <8 x ptr>, <8 x i64> } %5719, 0
  %5721 = extractvalue { <8 x ptr>, <8 x i64> } %5719, 1
  %5722 = getelementptr i8, <8 x ptr> %5720, <8 x i64> %5721
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5397, <8 x ptr> align 1 %5722, <8 x i1> %convergence.cascade.result688)
  %5723 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5724 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5725 = add <8 x i64> %5724, splat (i64 144)
  %5726 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5723, 0
  %5727 = insertvalue { <8 x ptr>, <8 x i64> } %5726, <8 x i64> %5725, 1
  %5728 = extractvalue { <8 x ptr>, <8 x i64> } %5727, 0
  %5729 = extractvalue { <8 x ptr>, <8 x i64> } %5727, 1
  %5730 = getelementptr i8, <8 x ptr> %5728, <8 x i64> %5729
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5398, <8 x ptr> align 1 %5730, <8 x i1> %convergence.cascade.result688)
  %5731 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5732 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5733 = add <8 x i64> %5732, splat (i64 148)
  %5734 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5731, 0
  %5735 = insertvalue { <8 x ptr>, <8 x i64> } %5734, <8 x i64> %5733, 1
  %5736 = extractvalue { <8 x ptr>, <8 x i64> } %5735, 0
  %5737 = extractvalue { <8 x ptr>, <8 x i64> } %5735, 1
  %5738 = getelementptr i8, <8 x ptr> %5736, <8 x i64> %5737
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5399, <8 x ptr> align 1 %5738, <8 x i1> %convergence.cascade.result688)
  %5739 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5740 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5741 = add <8 x i64> %5740, splat (i64 152)
  %5742 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5739, 0
  %5743 = insertvalue { <8 x ptr>, <8 x i64> } %5742, <8 x i64> %5741, 1
  %5744 = extractvalue { <8 x ptr>, <8 x i64> } %5743, 0
  %5745 = extractvalue { <8 x ptr>, <8 x i64> } %5743, 1
  %5746 = getelementptr i8, <8 x ptr> %5744, <8 x i64> %5745
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5400, <8 x ptr> align 1 %5746, <8 x i1> %convergence.cascade.result688)
  %5747 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5748 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5749 = add <8 x i64> %5748, splat (i64 156)
  %5750 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5747, 0
  %5751 = insertvalue { <8 x ptr>, <8 x i64> } %5750, <8 x i64> %5749, 1
  %5752 = extractvalue { <8 x ptr>, <8 x i64> } %5751, 0
  %5753 = extractvalue { <8 x ptr>, <8 x i64> } %5751, 1
  %5754 = getelementptr i8, <8 x ptr> %5752, <8 x i64> %5753
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5401, <8 x ptr> align 1 %5754, <8 x i1> %convergence.cascade.result688)
  %5755 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5756 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5757 = add <8 x i64> %5756, splat (i64 160)
  %5758 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5755, 0
  %5759 = insertvalue { <8 x ptr>, <8 x i64> } %5758, <8 x i64> %5757, 1
  %5760 = extractvalue { <8 x ptr>, <8 x i64> } %5759, 0
  %5761 = extractvalue { <8 x ptr>, <8 x i64> } %5759, 1
  %5762 = getelementptr i8, <8 x ptr> %5760, <8 x i64> %5761
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5402, <8 x ptr> align 1 %5762, <8 x i1> %convergence.cascade.result688)
  %5763 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5764 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5765 = add <8 x i64> %5764, splat (i64 164)
  %5766 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5763, 0
  %5767 = insertvalue { <8 x ptr>, <8 x i64> } %5766, <8 x i64> %5765, 1
  %5768 = extractvalue { <8 x ptr>, <8 x i64> } %5767, 0
  %5769 = extractvalue { <8 x ptr>, <8 x i64> } %5767, 1
  %5770 = getelementptr i8, <8 x ptr> %5768, <8 x i64> %5769
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5403, <8 x ptr> align 1 %5770, <8 x i1> %convergence.cascade.result688)
  %5771 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5772 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5773 = add <8 x i64> %5772, splat (i64 168)
  %5774 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5771, 0
  %5775 = insertvalue { <8 x ptr>, <8 x i64> } %5774, <8 x i64> %5773, 1
  %5776 = extractvalue { <8 x ptr>, <8 x i64> } %5775, 0
  %5777 = extractvalue { <8 x ptr>, <8 x i64> } %5775, 1
  %5778 = getelementptr i8, <8 x ptr> %5776, <8 x i64> %5777
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5404, <8 x ptr> align 1 %5778, <8 x i1> %convergence.cascade.result688)
  %5779 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5780 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5781 = add <8 x i64> %5780, splat (i64 172)
  %5782 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5779, 0
  %5783 = insertvalue { <8 x ptr>, <8 x i64> } %5782, <8 x i64> %5781, 1
  %5784 = extractvalue { <8 x ptr>, <8 x i64> } %5783, 0
  %5785 = extractvalue { <8 x ptr>, <8 x i64> } %5783, 1
  %5786 = getelementptr i8, <8 x ptr> %5784, <8 x i64> %5785
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5405, <8 x ptr> align 1 %5786, <8 x i1> %convergence.cascade.result688)
  %5787 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5788 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5789 = add <8 x i64> %5788, splat (i64 176)
  %5790 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5787, 0
  %5791 = insertvalue { <8 x ptr>, <8 x i64> } %5790, <8 x i64> %5789, 1
  %5792 = extractvalue { <8 x ptr>, <8 x i64> } %5791, 0
  %5793 = extractvalue { <8 x ptr>, <8 x i64> } %5791, 1
  %5794 = getelementptr i8, <8 x ptr> %5792, <8 x i64> %5793
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5406, <8 x ptr> align 1 %5794, <8 x i1> %convergence.cascade.result688)
  %5795 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5796 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5797 = add <8 x i64> %5796, splat (i64 180)
  %5798 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5795, 0
  %5799 = insertvalue { <8 x ptr>, <8 x i64> } %5798, <8 x i64> %5797, 1
  %5800 = extractvalue { <8 x ptr>, <8 x i64> } %5799, 0
  %5801 = extractvalue { <8 x ptr>, <8 x i64> } %5799, 1
  %5802 = getelementptr i8, <8 x ptr> %5800, <8 x i64> %5801
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5407, <8 x ptr> align 1 %5802, <8 x i1> %convergence.cascade.result688)
  %5803 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5804 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5805 = add <8 x i64> %5804, splat (i64 184)
  %5806 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5803, 0
  %5807 = insertvalue { <8 x ptr>, <8 x i64> } %5806, <8 x i64> %5805, 1
  %5808 = extractvalue { <8 x ptr>, <8 x i64> } %5807, 0
  %5809 = extractvalue { <8 x ptr>, <8 x i64> } %5807, 1
  %5810 = getelementptr i8, <8 x ptr> %5808, <8 x i64> %5809
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5408, <8 x ptr> align 1 %5810, <8 x i1> %convergence.cascade.result688)
  %5811 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5812 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5813 = add <8 x i64> %5812, splat (i64 188)
  %5814 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5811, 0
  %5815 = insertvalue { <8 x ptr>, <8 x i64> } %5814, <8 x i64> %5813, 1
  %5816 = extractvalue { <8 x ptr>, <8 x i64> } %5815, 0
  %5817 = extractvalue { <8 x ptr>, <8 x i64> } %5815, 1
  %5818 = getelementptr i8, <8 x ptr> %5816, <8 x i64> %5817
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5409, <8 x ptr> align 1 %5818, <8 x i1> %convergence.cascade.result688)
  %5819 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5820 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5821 = add <8 x i64> %5820, splat (i64 192)
  %5822 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5819, 0
  %5823 = insertvalue { <8 x ptr>, <8 x i64> } %5822, <8 x i64> %5821, 1
  %5824 = extractvalue { <8 x ptr>, <8 x i64> } %5823, 0
  %5825 = extractvalue { <8 x ptr>, <8 x i64> } %5823, 1
  %5826 = getelementptr i8, <8 x ptr> %5824, <8 x i64> %5825
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5410, <8 x ptr> align 1 %5826, <8 x i1> %convergence.cascade.result688)
  %5827 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5828 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5829 = add <8 x i64> %5828, splat (i64 196)
  %5830 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5827, 0
  %5831 = insertvalue { <8 x ptr>, <8 x i64> } %5830, <8 x i64> %5829, 1
  %5832 = extractvalue { <8 x ptr>, <8 x i64> } %5831, 0
  %5833 = extractvalue { <8 x ptr>, <8 x i64> } %5831, 1
  %5834 = getelementptr i8, <8 x ptr> %5832, <8 x i64> %5833
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5411, <8 x ptr> align 1 %5834, <8 x i1> %convergence.cascade.result688)
  %5835 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5836 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5837 = add <8 x i64> %5836, splat (i64 200)
  %5838 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5835, 0
  %5839 = insertvalue { <8 x ptr>, <8 x i64> } %5838, <8 x i64> %5837, 1
  %5840 = extractvalue { <8 x ptr>, <8 x i64> } %5839, 0
  %5841 = extractvalue { <8 x ptr>, <8 x i64> } %5839, 1
  %5842 = getelementptr i8, <8 x ptr> %5840, <8 x i64> %5841
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5412, <8 x ptr> align 1 %5842, <8 x i1> %convergence.cascade.result688)
  %5843 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5844 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5845 = add <8 x i64> %5844, splat (i64 204)
  %5846 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5843, 0
  %5847 = insertvalue { <8 x ptr>, <8 x i64> } %5846, <8 x i64> %5845, 1
  %5848 = extractvalue { <8 x ptr>, <8 x i64> } %5847, 0
  %5849 = extractvalue { <8 x ptr>, <8 x i64> } %5847, 1
  %5850 = getelementptr i8, <8 x ptr> %5848, <8 x i64> %5849
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5413, <8 x ptr> align 1 %5850, <8 x i1> %convergence.cascade.result688)
  %5851 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5852 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5853 = add <8 x i64> %5852, splat (i64 208)
  %5854 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5851, 0
  %5855 = insertvalue { <8 x ptr>, <8 x i64> } %5854, <8 x i64> %5853, 1
  %5856 = extractvalue { <8 x ptr>, <8 x i64> } %5855, 0
  %5857 = extractvalue { <8 x ptr>, <8 x i64> } %5855, 1
  %5858 = getelementptr i8, <8 x ptr> %5856, <8 x i64> %5857
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5414, <8 x ptr> align 1 %5858, <8 x i1> %convergence.cascade.result688)
  %5859 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5860 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5861 = add <8 x i64> %5860, splat (i64 212)
  %5862 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5859, 0
  %5863 = insertvalue { <8 x ptr>, <8 x i64> } %5862, <8 x i64> %5861, 1
  %5864 = extractvalue { <8 x ptr>, <8 x i64> } %5863, 0
  %5865 = extractvalue { <8 x ptr>, <8 x i64> } %5863, 1
  %5866 = getelementptr i8, <8 x ptr> %5864, <8 x i64> %5865
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5415, <8 x ptr> align 1 %5866, <8 x i1> %convergence.cascade.result688)
  %5867 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5868 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5869 = add <8 x i64> %5868, splat (i64 216)
  %5870 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5867, 0
  %5871 = insertvalue { <8 x ptr>, <8 x i64> } %5870, <8 x i64> %5869, 1
  %5872 = extractvalue { <8 x ptr>, <8 x i64> } %5871, 0
  %5873 = extractvalue { <8 x ptr>, <8 x i64> } %5871, 1
  %5874 = getelementptr i8, <8 x ptr> %5872, <8 x i64> %5873
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5416, <8 x ptr> align 1 %5874, <8 x i1> %convergence.cascade.result688)
  %5875 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5876 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5877 = add <8 x i64> %5876, splat (i64 220)
  %5878 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5875, 0
  %5879 = insertvalue { <8 x ptr>, <8 x i64> } %5878, <8 x i64> %5877, 1
  %5880 = extractvalue { <8 x ptr>, <8 x i64> } %5879, 0
  %5881 = extractvalue { <8 x ptr>, <8 x i64> } %5879, 1
  %5882 = getelementptr i8, <8 x ptr> %5880, <8 x i64> %5881
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5417, <8 x ptr> align 1 %5882, <8 x i1> %convergence.cascade.result688)
  %5883 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5884 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5885 = add <8 x i64> %5884, splat (i64 224)
  %5886 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5883, 0
  %5887 = insertvalue { <8 x ptr>, <8 x i64> } %5886, <8 x i64> %5885, 1
  %5888 = extractvalue { <8 x ptr>, <8 x i64> } %5887, 0
  %5889 = extractvalue { <8 x ptr>, <8 x i64> } %5887, 1
  %5890 = getelementptr i8, <8 x ptr> %5888, <8 x i64> %5889
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5418, <8 x ptr> align 1 %5890, <8 x i1> %convergence.cascade.result688)
  %5891 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5892 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5893 = add <8 x i64> %5892, splat (i64 228)
  %5894 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5891, 0
  %5895 = insertvalue { <8 x ptr>, <8 x i64> } %5894, <8 x i64> %5893, 1
  %5896 = extractvalue { <8 x ptr>, <8 x i64> } %5895, 0
  %5897 = extractvalue { <8 x ptr>, <8 x i64> } %5895, 1
  %5898 = getelementptr i8, <8 x ptr> %5896, <8 x i64> %5897
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5419, <8 x ptr> align 1 %5898, <8 x i1> %convergence.cascade.result688)
  %5899 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5900 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5901 = add <8 x i64> %5900, splat (i64 232)
  %5902 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5899, 0
  %5903 = insertvalue { <8 x ptr>, <8 x i64> } %5902, <8 x i64> %5901, 1
  %5904 = extractvalue { <8 x ptr>, <8 x i64> } %5903, 0
  %5905 = extractvalue { <8 x ptr>, <8 x i64> } %5903, 1
  %5906 = getelementptr i8, <8 x ptr> %5904, <8 x i64> %5905
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5420, <8 x ptr> align 1 %5906, <8 x i1> %convergence.cascade.result688)
  %5907 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5908 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5909 = add <8 x i64> %5908, splat (i64 236)
  %5910 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5907, 0
  %5911 = insertvalue { <8 x ptr>, <8 x i64> } %5910, <8 x i64> %5909, 1
  %5912 = extractvalue { <8 x ptr>, <8 x i64> } %5911, 0
  %5913 = extractvalue { <8 x ptr>, <8 x i64> } %5911, 1
  %5914 = getelementptr i8, <8 x ptr> %5912, <8 x i64> %5913
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5421, <8 x ptr> align 1 %5914, <8 x i1> %convergence.cascade.result688)
  %5915 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5916 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5917 = add <8 x i64> %5916, splat (i64 240)
  %5918 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5915, 0
  %5919 = insertvalue { <8 x ptr>, <8 x i64> } %5918, <8 x i64> %5917, 1
  %5920 = extractvalue { <8 x ptr>, <8 x i64> } %5919, 0
  %5921 = extractvalue { <8 x ptr>, <8 x i64> } %5919, 1
  %5922 = getelementptr i8, <8 x ptr> %5920, <8 x i64> %5921
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5422, <8 x ptr> align 1 %5922, <8 x i1> %convergence.cascade.result688)
  %5923 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5924 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5925 = add <8 x i64> %5924, splat (i64 244)
  %5926 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5923, 0
  %5927 = insertvalue { <8 x ptr>, <8 x i64> } %5926, <8 x i64> %5925, 1
  %5928 = extractvalue { <8 x ptr>, <8 x i64> } %5927, 0
  %5929 = extractvalue { <8 x ptr>, <8 x i64> } %5927, 1
  %5930 = getelementptr i8, <8 x ptr> %5928, <8 x i64> %5929
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5423, <8 x ptr> align 1 %5930, <8 x i1> %convergence.cascade.result688)
  %5931 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5932 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5933 = add <8 x i64> %5932, splat (i64 248)
  %5934 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5931, 0
  %5935 = insertvalue { <8 x ptr>, <8 x i64> } %5934, <8 x i64> %5933, 1
  %5936 = extractvalue { <8 x ptr>, <8 x i64> } %5935, 0
  %5937 = extractvalue { <8 x ptr>, <8 x i64> } %5935, 1
  %5938 = getelementptr i8, <8 x ptr> %5936, <8 x i64> %5937
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5424, <8 x ptr> align 1 %5938, <8 x i1> %convergence.cascade.result688)
  %5939 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5940 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5941 = add <8 x i64> %5940, splat (i64 252)
  %5942 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5939, 0
  %5943 = insertvalue { <8 x ptr>, <8 x i64> } %5942, <8 x i64> %5941, 1
  %5944 = extractvalue { <8 x ptr>, <8 x i64> } %5943, 0
  %5945 = extractvalue { <8 x ptr>, <8 x i64> } %5943, 1
  %5946 = getelementptr i8, <8 x ptr> %5944, <8 x i64> %5945
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5425, <8 x ptr> align 1 %5946, <8 x i1> %convergence.cascade.result688)
  %.state904 = load <8 x float>, ptr %.slot59, align 32
  %5947 = fmul <8 x float> %.state904, %native.exp
  %5948 = load volatile <8 x float>, ptr %.spill210, align 32
  %5949 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5947, <8 x float> %5948
  store volatile <8 x float> %5949, ptr %.spill210, align 32
  %.state905 = load <8 x float>, ptr %.slot60, align 32
  %5950 = fmul <8 x float> %.state905, %native.exp701
  %5951 = load volatile <8 x float>, ptr %.spill211, align 32
  %5952 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5950, <8 x float> %5951
  store volatile <8 x float> %5952, ptr %.spill211, align 32
  %.state906 = load <8 x float>, ptr %.slot61, align 32
  %5953 = fmul <8 x float> %.state906, %native.exp702
  %5954 = load volatile <8 x float>, ptr %.spill212, align 32
  %5955 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5953, <8 x float> %5954
  store volatile <8 x float> %5955, ptr %.spill212, align 32
  %.state907 = load <8 x float>, ptr %.slot62, align 32
  %5956 = fmul <8 x float> %.state907, %native.exp703
  %5957 = load volatile <8 x float>, ptr %.spill213, align 32
  %5958 = select <8 x i1> %convergence.cascade.result688, <8 x float> %5956, <8 x float> %5957
  store volatile <8 x float> %5958, ptr %.spill213, align 32
  %5959 = load <8 x i64>, ptr %.slot214, align 64
  %5960 = select <8 x i1> %convergence.cascade.result688, <8 x i64> zeroinitializer, <8 x i64> %5959
  store <8 x i64> %5960, ptr %.slot214, align 64
  %5961 = load <8 x float>, ptr %.slot215, align 32
  %5962 = select <8 x i1> %convergence.cascade.result688, <8 x float> zeroinitializer, <8 x float> %5961
  store <8 x float> %5962, ptr %.slot215, align 32
  store <8 x i1> %convergence.cascade.result688, ptr %current.mask, align 1
  %5963 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result688)
  br i1 %5963, label %schedule.24, label %scheduler.loop

varying.divergent909:                             ; preds = %schedule.24
  %5964 = load i32, ptr %current.token, align 4
  %5965 = icmp ne i32 %5964, 0
  %5966 = sub i32 %5964, 1
  %5967 = select i1 %5965, i32 %5966, i32 0
  %5968 = load i8, ptr %frame.active, align 1
  %5969 = trunc i32 %5967 to i8
  %5970 = shl i8 1, %5969
  %5971 = and i8 %5968, %5970
  %5972 = icmp ne i8 %5971, 0
  %5973 = load <8 x i32>, ptr %frame.static.id, align 32
  %5974 = extractelement <8 x i32> %5973, i32 %5967
  %5975 = icmp eq i32 %5974, 9
  %5976 = and i1 %5972, %5975
  %5977 = and i1 %5965, %5976
  %5978 = xor i1 %5977, true
  %5979 = and i1 true, %5978
  %5980 = xor i8 %5968, -1
  %5981 = icmp ne i8 %5980, 0
  %5982 = xor i1 %5981, true
  %5983 = and i1 %5979, %5982
  br i1 %5983, label %convergence.overflow.trap911, label %convergence.overflow.resume912

varying.coherent910:                              ; preds = %schedule.24
  br i1 %475, label %varying.coherent.true915, label %varying.coherent.false916

convergence.overflow.trap911:                     ; preds = %varying.divergent909
  call void @llvm.trap()
  unreachable

convergence.overflow.resume912:                   ; preds = %varying.divergent909
  %5984 = call i8 @llvm.cttz.i8(i8 %5980, i1 false)
  %5985 = zext i8 %5984 to i32
  %5986 = select i1 %5981, i32 %5985, i32 0
  %5987 = trunc i32 %5986 to i8
  %5988 = shl i8 1, %5987
  %5989 = or i8 %5968, %5988
  %5990 = select i1 %5979, i8 %5989, i8 %5968
  store i8 %5990, ptr %frame.active, align 1
  %5991 = load <8 x i32>, ptr %frame.static.id, align 32
  %5992 = extractelement <8 x i32> %5991, i32 %5986
  %5993 = select i1 %5979, i32 9, i32 %5992
  %5994 = load <8 x i32>, ptr %frame.static.id, align 32
  %5995 = insertelement <8 x i32> %5994, i32 %5993, i32 %5986
  store <8 x i32> %5995, ptr %frame.static.id, align 32
  %5996 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5997 = extractelement <8 x i32> %5996, i32 %5986
  %5998 = select i1 %5979, i32 %5964, i32 %5997
  %5999 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6000 = insertelement <8 x i32> %5999, i32 %5998, i32 %5986
  store <8 x i32> %6000, ptr %frame.parent.token, align 32
  %6001 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5986
  %6002 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5986
  %6003 = load <8 x i1>, ptr %6001, align 1
  %6004 = load <8 x i1>, ptr %6002, align 1
  %6005 = select i1 %5979, <8 x i1> %465, <8 x i1> %6003
  store <8 x i1> %6005, ptr %6001, align 1
  %6006 = select i1 %5979, <8 x i1> zeroinitializer, <8 x i1> %6004
  store <8 x i1> %6006, ptr %6002, align 1
  %6007 = add i32 %5986, 1
  %6008 = select i1 %5977, i32 %5964, i32 %6007
  %6009 = select i1 true, i32 %6008, i32 %5964
  store i32 %6009, ptr %current.token, align 4
  %6010 = load i32, ptr %current.token, align 4
  %6011 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %472)
  %6012 = load i32, ptr %ready.count, align 4
  %6013 = icmp uge i32 %6012, 8
  %6014 = and i1 %6011, %6013
  br i1 %6014, label %ready.overflow.trap913, label %ready.overflow.resume914

ready.overflow.trap913:                           ; preds = %convergence.overflow.resume912
  call void @llvm.trap()
  unreachable

ready.overflow.resume914:                         ; preds = %convergence.overflow.resume912
  %6015 = select i1 %6011, i32 %6012, i32 0
  %6016 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6015
  %6017 = load <8 x i1>, ptr %6016, align 1
  %6018 = select i1 %6011, <8 x i1> %472, <8 x i1> %6017
  store <8 x i1> %6018, ptr %6016, align 1
  %6019 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6015
  %6020 = load i32, ptr %6019, align 4
  %6021 = select i1 %6011, i32 25, i32 %6020
  store i32 %6021, ptr %6019, align 4
  %6022 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6015
  %6023 = load i32, ptr %6022, align 4
  %6024 = select i1 %6011, i32 %6010, i32 %6023
  store i32 %6024, ptr %6022, align 4
  %6025 = add i32 %6012, 1
  %6026 = select i1 %6011, i32 %6025, i32 %6012
  store i32 %6026, ptr %ready.count, align 4
  %6027 = load <8 x i1>, ptr %runnable.mask, align 1
  %6028 = or <8 x i1> %6027, %472
  store <8 x i1> %6028, ptr %runnable.mask, align 1
  store <8 x i1> %474, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true915:                         ; preds = %varying.coherent910
  store <8 x i1> %465, ptr %current.mask, align 1
  %6029 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %465)
  br i1 %6029, label %schedule.25, label %scheduler.loop

varying.coherent.false916:                        ; preds = %varying.coherent910
  store <8 x i1> %465, ptr %current.mask, align 1
  %6030 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %465)
  br i1 %6030, label %schedule.26, label %scheduler.loop

convergence.cascade921:                           ; preds = %convergence.cascade921, %schedule.26
  %convergence.cascade.flow925 = phi <8 x i1> [ %505, %schedule.26 ], [ %6073, %convergence.cascade921 ]
  %convergence.cascade.depth926 = phi i32 [ 0, %schedule.26 ], [ %6074, %convergence.cascade921 ]
  %6031 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow925)
  %6032 = load i32, ptr %current.token, align 4
  %6033 = icmp ne i32 %6032, 0
  %6034 = and i1 %6031, %6033
  %6035 = sub i32 %6032, 1
  %6036 = select i1 %6034, i32 %6035, i32 0
  %6037 = load i8, ptr %frame.active, align 1
  %6038 = trunc i32 %6036 to i8
  %6039 = shl i8 1, %6038
  %6040 = and i8 %6037, %6039
  %6041 = icmp ne i8 %6040, 0
  %6042 = load <8 x i32>, ptr %frame.static.id, align 32
  %6043 = extractelement <8 x i32> %6042, i32 %6036
  %convergence.target.pointer927 = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %6043
  %convergence.dynamic.target928 = load i32, ptr %convergence.target.pointer927, align 4
  %6044 = icmp eq i32 %convergence.dynamic.target928, 26
  %6045 = and i1 %6041, %6044
  %6046 = and i1 %6034, %6045
  %6047 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6036
  %6048 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6036
  %6049 = load <8 x i1>, ptr %6047, align 1
  %6050 = load <8 x i1>, ptr %6048, align 1
  %6051 = or <8 x i1> %6050, %convergence.cascade.flow925
  %6052 = load <8 x i1>, ptr %live.mask, align 1
  %6053 = and <8 x i1> %6049, %6052
  %6054 = icmp eq <8 x i1> %6051, %6053
  %6055 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6054)
  %6056 = and i1 %6046, %6055
  %6057 = select i1 %6056, <8 x i1> zeroinitializer, <8 x i1> %6051
  %6058 = select i1 %6046, <8 x i1> %6057, <8 x i1> %6050
  store <8 x i1> %6058, ptr %6048, align 1
  %6059 = select i1 %6056, <8 x i1> zeroinitializer, <8 x i1> %6049
  store <8 x i1> %6059, ptr %6047, align 1
  %6060 = trunc i32 %6036 to i8
  %6061 = shl i8 1, %6060
  %6062 = xor i8 %6061, -1
  %6063 = and i8 %6037, %6062
  %6064 = select i1 %6056, i8 %6063, i8 %6037
  store i8 %6064, ptr %frame.active, align 1
  %.splatinsert929 = insertelement <8 x i1> poison, i1 %6046, i64 0
  %.splat930 = shufflevector <8 x i1> %.splatinsert929, <8 x i1> poison, <8 x i32> zeroinitializer
  %6065 = and <8 x i1> %convergence.cascade.flow925, %.splat930
  %6066 = load <8 x i1>, ptr %runnable.mask, align 1
  %6067 = xor <8 x i1> %6065, splat (i1 true)
  %6068 = and <8 x i1> %6066, %6067
  store <8 x i1> %6068, ptr %runnable.mask, align 1
  %.splatinsert931 = insertelement <8 x i1> poison, i1 %6056, i64 0
  %.splat932 = shufflevector <8 x i1> %.splatinsert931, <8 x i1> poison, <8 x i32> zeroinitializer
  %6069 = select <8 x i1> %.splat932, <8 x i1> %6051, <8 x i1> zeroinitializer
  %6070 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6071 = extractelement <8 x i32> %6070, i32 %6036
  %6072 = select i1 %6056, i32 %6071, i32 %6032
  store i32 %6072, ptr %current.token, align 4
  %.splatinsert933 = insertelement <8 x i1> poison, i1 %6046, i64 0
  %.splat934 = shufflevector <8 x i1> %.splatinsert933, <8 x i1> poison, <8 x i32> zeroinitializer
  %6073 = select <8 x i1> %.splat934, <8 x i1> %6069, <8 x i1> %convergence.cascade.flow925
  %6074 = add i32 %convergence.cascade.depth926, 1
  %6075 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6073)
  %6076 = icmp ult i32 %6074, 8
  %6077 = and i1 %6075, %6076
  %6078 = and i1 %6046, %6077
  %convergence.parent.token935 = load i32, ptr %current.token, align 4
  %convergence.parent.present936 = icmp ne i32 %convergence.parent.token935, 0
  %6079 = and i1 %6078, %convergence.parent.present936
  br i1 %6079, label %convergence.cascade921, label %convergence.cascade.exit922

convergence.cascade.exit922:                      ; preds = %convergence.cascade921, %schedule.26
  %convergence.cascade.result937 = phi <8 x i1> [ %505, %schedule.26 ], [ %6073, %convergence.cascade921 ]
  %6080 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result937)
  br i1 %6080, label %convergence.target.26.ready, label %scheduler.loop

convergence.target.26.ready:                      ; preds = %convergence.cascade.exit922
  %6081 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result937)
  %6082 = bitcast <8 x i1> %convergence.cascade.result937 to i8
  %6083 = call i8 @llvm.cttz.i8(i8 %6082, i1 false)
  %6084 = zext i8 %6083 to i32
  %6085 = select i1 %6081, i32 %6084, i32 0
  %6086 = load <8 x i64>, ptr %.slot216, align 64
  %6087 = select <8 x i1> %convergence.cascade.result937, <8 x i64> zeroinitializer, <8 x i64> %6086
  store <8 x i64> %6087, ptr %.slot216, align 64
  %6088 = load <8 x float>, ptr %.slot217, align 32
  %6089 = select <8 x i1> %convergence.cascade.result937, <8 x float> zeroinitializer, <8 x float> %6088
  store <8 x float> %6089, ptr %.slot217, align 32
  store <8 x i1> %convergence.cascade.result937, ptr %current.mask, align 1
  %6090 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result937)
  br i1 %6090, label %schedule.27, label %scheduler.loop

varying.divergent939:                             ; preds = %schedule.27
  %6091 = load i32, ptr %current.token, align 4
  %6092 = icmp ne i32 %6091, 0
  %6093 = sub i32 %6091, 1
  %6094 = select i1 %6092, i32 %6093, i32 0
  %6095 = load i8, ptr %frame.active, align 1
  %6096 = trunc i32 %6094 to i8
  %6097 = shl i8 1, %6096
  %6098 = and i8 %6095, %6097
  %6099 = icmp ne i8 %6098, 0
  %6100 = load <8 x i32>, ptr %frame.static.id, align 32
  %6101 = extractelement <8 x i32> %6100, i32 %6094
  %6102 = icmp eq i32 %6101, 10
  %6103 = and i1 %6099, %6102
  %6104 = and i1 %6092, %6103
  %6105 = xor i1 %6104, true
  %6106 = and i1 true, %6105
  %6107 = xor i8 %6095, -1
  %6108 = icmp ne i8 %6107, 0
  %6109 = xor i1 %6108, true
  %6110 = and i1 %6106, %6109
  br i1 %6110, label %convergence.overflow.trap941, label %convergence.overflow.resume942

varying.coherent940:                              ; preds = %schedule.27
  br i1 %516, label %varying.coherent.true945, label %varying.coherent.false946

convergence.overflow.trap941:                     ; preds = %varying.divergent939
  call void @llvm.trap()
  unreachable

convergence.overflow.resume942:                   ; preds = %varying.divergent939
  %6111 = call i8 @llvm.cttz.i8(i8 %6107, i1 false)
  %6112 = zext i8 %6111 to i32
  %6113 = select i1 %6108, i32 %6112, i32 0
  %6114 = trunc i32 %6113 to i8
  %6115 = shl i8 1, %6114
  %6116 = or i8 %6095, %6115
  %6117 = select i1 %6106, i8 %6116, i8 %6095
  store i8 %6117, ptr %frame.active, align 1
  %6118 = load <8 x i32>, ptr %frame.static.id, align 32
  %6119 = extractelement <8 x i32> %6118, i32 %6113
  %6120 = select i1 %6106, i32 10, i32 %6119
  %6121 = load <8 x i32>, ptr %frame.static.id, align 32
  %6122 = insertelement <8 x i32> %6121, i32 %6120, i32 %6113
  store <8 x i32> %6122, ptr %frame.static.id, align 32
  %6123 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6124 = extractelement <8 x i32> %6123, i32 %6113
  %6125 = select i1 %6106, i32 %6091, i32 %6124
  %6126 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6127 = insertelement <8 x i32> %6126, i32 %6125, i32 %6113
  store <8 x i32> %6127, ptr %frame.parent.token, align 32
  %6128 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6113
  %6129 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6113
  %6130 = load <8 x i1>, ptr %6128, align 1
  %6131 = load <8 x i1>, ptr %6129, align 1
  %6132 = select i1 %6106, <8 x i1> %506, <8 x i1> %6130
  store <8 x i1> %6132, ptr %6128, align 1
  %6133 = select i1 %6106, <8 x i1> zeroinitializer, <8 x i1> %6131
  store <8 x i1> %6133, ptr %6129, align 1
  %6134 = add i32 %6113, 1
  %6135 = select i1 %6104, i32 %6091, i32 %6134
  %6136 = select i1 true, i32 %6135, i32 %6091
  store i32 %6136, ptr %current.token, align 4
  %6137 = load i32, ptr %current.token, align 4
  %6138 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %513)
  %6139 = load i32, ptr %ready.count, align 4
  %6140 = icmp uge i32 %6139, 8
  %6141 = and i1 %6138, %6140
  br i1 %6141, label %ready.overflow.trap943, label %ready.overflow.resume944

ready.overflow.trap943:                           ; preds = %convergence.overflow.resume942
  call void @llvm.trap()
  unreachable

ready.overflow.resume944:                         ; preds = %convergence.overflow.resume942
  %6142 = select i1 %6138, i32 %6139, i32 0
  %6143 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6142
  %6144 = load <8 x i1>, ptr %6143, align 1
  %6145 = select i1 %6138, <8 x i1> %513, <8 x i1> %6144
  store <8 x i1> %6145, ptr %6143, align 1
  %6146 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6142
  %6147 = load i32, ptr %6146, align 4
  %6148 = select i1 %6138, i32 28, i32 %6147
  store i32 %6148, ptr %6146, align 4
  %6149 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6142
  %6150 = load i32, ptr %6149, align 4
  %6151 = select i1 %6138, i32 %6137, i32 %6150
  store i32 %6151, ptr %6149, align 4
  %6152 = add i32 %6139, 1
  %6153 = select i1 %6138, i32 %6152, i32 %6139
  store i32 %6153, ptr %ready.count, align 4
  %6154 = load <8 x i1>, ptr %runnable.mask, align 1
  %6155 = or <8 x i1> %6154, %513
  store <8 x i1> %6155, ptr %runnable.mask, align 1
  store <8 x i1> %515, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true945:                         ; preds = %varying.coherent940
  store <8 x i1> %506, ptr %current.mask, align 1
  %6156 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %506)
  br i1 %6156, label %schedule.28, label %scheduler.loop

varying.coherent.false946:                        ; preds = %varying.coherent940
  store <8 x i1> %506, ptr %current.mask, align 1
  %6157 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %506)
  br i1 %6157, label %schedule.29, label %scheduler.loop

convergence.cascade951:                           ; preds = %convergence.cascade951, %schedule.29
  %convergence.cascade.flow955 = phi <8 x i1> [ %546, %schedule.29 ], [ %6200, %convergence.cascade951 ]
  %convergence.cascade.depth956 = phi i32 [ 0, %schedule.29 ], [ %6201, %convergence.cascade951 ]
  %6158 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow955)
  %6159 = load i32, ptr %current.token, align 4
  %6160 = icmp ne i32 %6159, 0
  %6161 = and i1 %6158, %6160
  %6162 = sub i32 %6159, 1
  %6163 = select i1 %6161, i32 %6162, i32 0
  %6164 = load i8, ptr %frame.active, align 1
  %6165 = trunc i32 %6163 to i8
  %6166 = shl i8 1, %6165
  %6167 = and i8 %6164, %6166
  %6168 = icmp ne i8 %6167, 0
  %6169 = load <8 x i32>, ptr %frame.static.id, align 32
  %6170 = extractelement <8 x i32> %6169, i32 %6163
  %convergence.target.pointer957 = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %6170
  %convergence.dynamic.target958 = load i32, ptr %convergence.target.pointer957, align 4
  %6171 = icmp eq i32 %convergence.dynamic.target958, 29
  %6172 = and i1 %6168, %6171
  %6173 = and i1 %6161, %6172
  %6174 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6163
  %6175 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6163
  %6176 = load <8 x i1>, ptr %6174, align 1
  %6177 = load <8 x i1>, ptr %6175, align 1
  %6178 = or <8 x i1> %6177, %convergence.cascade.flow955
  %6179 = load <8 x i1>, ptr %live.mask, align 1
  %6180 = and <8 x i1> %6176, %6179
  %6181 = icmp eq <8 x i1> %6178, %6180
  %6182 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6181)
  %6183 = and i1 %6173, %6182
  %6184 = select i1 %6183, <8 x i1> zeroinitializer, <8 x i1> %6178
  %6185 = select i1 %6173, <8 x i1> %6184, <8 x i1> %6177
  store <8 x i1> %6185, ptr %6175, align 1
  %6186 = select i1 %6183, <8 x i1> zeroinitializer, <8 x i1> %6176
  store <8 x i1> %6186, ptr %6174, align 1
  %6187 = trunc i32 %6163 to i8
  %6188 = shl i8 1, %6187
  %6189 = xor i8 %6188, -1
  %6190 = and i8 %6164, %6189
  %6191 = select i1 %6183, i8 %6190, i8 %6164
  store i8 %6191, ptr %frame.active, align 1
  %.splatinsert959 = insertelement <8 x i1> poison, i1 %6173, i64 0
  %.splat960 = shufflevector <8 x i1> %.splatinsert959, <8 x i1> poison, <8 x i32> zeroinitializer
  %6192 = and <8 x i1> %convergence.cascade.flow955, %.splat960
  %6193 = load <8 x i1>, ptr %runnable.mask, align 1
  %6194 = xor <8 x i1> %6192, splat (i1 true)
  %6195 = and <8 x i1> %6193, %6194
  store <8 x i1> %6195, ptr %runnable.mask, align 1
  %.splatinsert961 = insertelement <8 x i1> poison, i1 %6183, i64 0
  %.splat962 = shufflevector <8 x i1> %.splatinsert961, <8 x i1> poison, <8 x i32> zeroinitializer
  %6196 = select <8 x i1> %.splat962, <8 x i1> %6178, <8 x i1> zeroinitializer
  %6197 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6198 = extractelement <8 x i32> %6197, i32 %6163
  %6199 = select i1 %6183, i32 %6198, i32 %6159
  store i32 %6199, ptr %current.token, align 4
  %.splatinsert963 = insertelement <8 x i1> poison, i1 %6173, i64 0
  %.splat964 = shufflevector <8 x i1> %.splatinsert963, <8 x i1> poison, <8 x i32> zeroinitializer
  %6200 = select <8 x i1> %.splat964, <8 x i1> %6196, <8 x i1> %convergence.cascade.flow955
  %6201 = add i32 %convergence.cascade.depth956, 1
  %6202 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6200)
  %6203 = icmp ult i32 %6201, 8
  %6204 = and i1 %6202, %6203
  %6205 = and i1 %6173, %6204
  %convergence.parent.token965 = load i32, ptr %current.token, align 4
  %convergence.parent.present966 = icmp ne i32 %convergence.parent.token965, 0
  %6206 = and i1 %6205, %convergence.parent.present966
  br i1 %6206, label %convergence.cascade951, label %convergence.cascade.exit952

convergence.cascade.exit952:                      ; preds = %convergence.cascade951, %schedule.29
  %convergence.cascade.result967 = phi <8 x i1> [ %546, %schedule.29 ], [ %6200, %convergence.cascade951 ]
  %6207 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result967)
  br i1 %6207, label %convergence.target.29.ready, label %scheduler.loop

convergence.target.29.ready:                      ; preds = %convergence.cascade.exit952
  %6208 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result967)
  %6209 = bitcast <8 x i1> %convergence.cascade.result967 to i8
  %6210 = call i8 @llvm.cttz.i8(i8 %6209, i1 false)
  %6211 = zext i8 %6210 to i32
  %6212 = select i1 %6208, i32 %6211, i32 0
  %6213 = load <8 x i64>, ptr %.slot218, align 64
  %6214 = select <8 x i1> %convergence.cascade.result967, <8 x i64> zeroinitializer, <8 x i64> %6213
  store <8 x i64> %6214, ptr %.slot218, align 64
  %6215 = load <8 x float>, ptr %.slot219, align 32
  %6216 = select <8 x i1> %convergence.cascade.result967, <8 x float> zeroinitializer, <8 x float> %6215
  store <8 x float> %6216, ptr %.slot219, align 32
  store <8 x i1> %convergence.cascade.result967, ptr %current.mask, align 1
  %6217 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result967)
  br i1 %6217, label %schedule.30, label %scheduler.loop

varying.divergent969:                             ; preds = %schedule.30
  %6218 = load i32, ptr %current.token, align 4
  %6219 = icmp ne i32 %6218, 0
  %6220 = sub i32 %6218, 1
  %6221 = select i1 %6219, i32 %6220, i32 0
  %6222 = load i8, ptr %frame.active, align 1
  %6223 = trunc i32 %6221 to i8
  %6224 = shl i8 1, %6223
  %6225 = and i8 %6222, %6224
  %6226 = icmp ne i8 %6225, 0
  %6227 = load <8 x i32>, ptr %frame.static.id, align 32
  %6228 = extractelement <8 x i32> %6227, i32 %6221
  %6229 = icmp eq i32 %6228, 11
  %6230 = and i1 %6226, %6229
  %6231 = and i1 %6219, %6230
  %6232 = xor i1 %6231, true
  %6233 = and i1 true, %6232
  %6234 = xor i8 %6222, -1
  %6235 = icmp ne i8 %6234, 0
  %6236 = xor i1 %6235, true
  %6237 = and i1 %6233, %6236
  br i1 %6237, label %convergence.overflow.trap971, label %convergence.overflow.resume972

varying.coherent970:                              ; preds = %schedule.30
  br i1 %557, label %varying.coherent.true975, label %varying.coherent.false976

convergence.overflow.trap971:                     ; preds = %varying.divergent969
  call void @llvm.trap()
  unreachable

convergence.overflow.resume972:                   ; preds = %varying.divergent969
  %6238 = call i8 @llvm.cttz.i8(i8 %6234, i1 false)
  %6239 = zext i8 %6238 to i32
  %6240 = select i1 %6235, i32 %6239, i32 0
  %6241 = trunc i32 %6240 to i8
  %6242 = shl i8 1, %6241
  %6243 = or i8 %6222, %6242
  %6244 = select i1 %6233, i8 %6243, i8 %6222
  store i8 %6244, ptr %frame.active, align 1
  %6245 = load <8 x i32>, ptr %frame.static.id, align 32
  %6246 = extractelement <8 x i32> %6245, i32 %6240
  %6247 = select i1 %6233, i32 11, i32 %6246
  %6248 = load <8 x i32>, ptr %frame.static.id, align 32
  %6249 = insertelement <8 x i32> %6248, i32 %6247, i32 %6240
  store <8 x i32> %6249, ptr %frame.static.id, align 32
  %6250 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6251 = extractelement <8 x i32> %6250, i32 %6240
  %6252 = select i1 %6233, i32 %6218, i32 %6251
  %6253 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6254 = insertelement <8 x i32> %6253, i32 %6252, i32 %6240
  store <8 x i32> %6254, ptr %frame.parent.token, align 32
  %6255 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6240
  %6256 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6240
  %6257 = load <8 x i1>, ptr %6255, align 1
  %6258 = load <8 x i1>, ptr %6256, align 1
  %6259 = select i1 %6233, <8 x i1> %547, <8 x i1> %6257
  store <8 x i1> %6259, ptr %6255, align 1
  %6260 = select i1 %6233, <8 x i1> zeroinitializer, <8 x i1> %6258
  store <8 x i1> %6260, ptr %6256, align 1
  %6261 = add i32 %6240, 1
  %6262 = select i1 %6231, i32 %6218, i32 %6261
  %6263 = select i1 true, i32 %6262, i32 %6218
  store i32 %6263, ptr %current.token, align 4
  %6264 = load i32, ptr %current.token, align 4
  %6265 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %554)
  %6266 = load i32, ptr %ready.count, align 4
  %6267 = icmp uge i32 %6266, 8
  %6268 = and i1 %6265, %6267
  br i1 %6268, label %ready.overflow.trap973, label %ready.overflow.resume974

ready.overflow.trap973:                           ; preds = %convergence.overflow.resume972
  call void @llvm.trap()
  unreachable

ready.overflow.resume974:                         ; preds = %convergence.overflow.resume972
  %6269 = select i1 %6265, i32 %6266, i32 0
  %6270 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6269
  %6271 = load <8 x i1>, ptr %6270, align 1
  %6272 = select i1 %6265, <8 x i1> %554, <8 x i1> %6271
  store <8 x i1> %6272, ptr %6270, align 1
  %6273 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6269
  %6274 = load i32, ptr %6273, align 4
  %6275 = select i1 %6265, i32 31, i32 %6274
  store i32 %6275, ptr %6273, align 4
  %6276 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6269
  %6277 = load i32, ptr %6276, align 4
  %6278 = select i1 %6265, i32 %6264, i32 %6277
  store i32 %6278, ptr %6276, align 4
  %6279 = add i32 %6266, 1
  %6280 = select i1 %6265, i32 %6279, i32 %6266
  store i32 %6280, ptr %ready.count, align 4
  %6281 = load <8 x i1>, ptr %runnable.mask, align 1
  %6282 = or <8 x i1> %6281, %554
  store <8 x i1> %6282, ptr %runnable.mask, align 1
  store <8 x i1> %556, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true975:                         ; preds = %varying.coherent970
  store <8 x i1> %547, ptr %current.mask, align 1
  %6283 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %547)
  br i1 %6283, label %schedule.31, label %scheduler.loop

varying.coherent.false976:                        ; preds = %varying.coherent970
  store <8 x i1> %547, ptr %current.mask, align 1
  %6284 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %547)
  br i1 %6284, label %schedule.32, label %scheduler.loop

convergence.cascade981:                           ; preds = %convergence.cascade981, %schedule.32
  %convergence.cascade.flow985 = phi <8 x i1> [ %587, %schedule.32 ], [ %6327, %convergence.cascade981 ]
  %convergence.cascade.depth986 = phi i32 [ 0, %schedule.32 ], [ %6328, %convergence.cascade981 ]
  %6285 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow985)
  %6286 = load i32, ptr %current.token, align 4
  %6287 = icmp ne i32 %6286, 0
  %6288 = and i1 %6285, %6287
  %6289 = sub i32 %6286, 1
  %6290 = select i1 %6288, i32 %6289, i32 0
  %6291 = load i8, ptr %frame.active, align 1
  %6292 = trunc i32 %6290 to i8
  %6293 = shl i8 1, %6292
  %6294 = and i8 %6291, %6293
  %6295 = icmp ne i8 %6294, 0
  %6296 = load <8 x i32>, ptr %frame.static.id, align 32
  %6297 = extractelement <8 x i32> %6296, i32 %6290
  %convergence.target.pointer987 = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %6297
  %convergence.dynamic.target988 = load i32, ptr %convergence.target.pointer987, align 4
  %6298 = icmp eq i32 %convergence.dynamic.target988, 32
  %6299 = and i1 %6295, %6298
  %6300 = and i1 %6288, %6299
  %6301 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6290
  %6302 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6290
  %6303 = load <8 x i1>, ptr %6301, align 1
  %6304 = load <8 x i1>, ptr %6302, align 1
  %6305 = or <8 x i1> %6304, %convergence.cascade.flow985
  %6306 = load <8 x i1>, ptr %live.mask, align 1
  %6307 = and <8 x i1> %6303, %6306
  %6308 = icmp eq <8 x i1> %6305, %6307
  %6309 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6308)
  %6310 = and i1 %6300, %6309
  %6311 = select i1 %6310, <8 x i1> zeroinitializer, <8 x i1> %6305
  %6312 = select i1 %6300, <8 x i1> %6311, <8 x i1> %6304
  store <8 x i1> %6312, ptr %6302, align 1
  %6313 = select i1 %6310, <8 x i1> zeroinitializer, <8 x i1> %6303
  store <8 x i1> %6313, ptr %6301, align 1
  %6314 = trunc i32 %6290 to i8
  %6315 = shl i8 1, %6314
  %6316 = xor i8 %6315, -1
  %6317 = and i8 %6291, %6316
  %6318 = select i1 %6310, i8 %6317, i8 %6291
  store i8 %6318, ptr %frame.active, align 1
  %.splatinsert989 = insertelement <8 x i1> poison, i1 %6300, i64 0
  %.splat990 = shufflevector <8 x i1> %.splatinsert989, <8 x i1> poison, <8 x i32> zeroinitializer
  %6319 = and <8 x i1> %convergence.cascade.flow985, %.splat990
  %6320 = load <8 x i1>, ptr %runnable.mask, align 1
  %6321 = xor <8 x i1> %6319, splat (i1 true)
  %6322 = and <8 x i1> %6320, %6321
  store <8 x i1> %6322, ptr %runnable.mask, align 1
  %.splatinsert991 = insertelement <8 x i1> poison, i1 %6310, i64 0
  %.splat992 = shufflevector <8 x i1> %.splatinsert991, <8 x i1> poison, <8 x i32> zeroinitializer
  %6323 = select <8 x i1> %.splat992, <8 x i1> %6305, <8 x i1> zeroinitializer
  %6324 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6325 = extractelement <8 x i32> %6324, i32 %6290
  %6326 = select i1 %6310, i32 %6325, i32 %6286
  store i32 %6326, ptr %current.token, align 4
  %.splatinsert993 = insertelement <8 x i1> poison, i1 %6300, i64 0
  %.splat994 = shufflevector <8 x i1> %.splatinsert993, <8 x i1> poison, <8 x i32> zeroinitializer
  %6327 = select <8 x i1> %.splat994, <8 x i1> %6323, <8 x i1> %convergence.cascade.flow985
  %6328 = add i32 %convergence.cascade.depth986, 1
  %6329 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6327)
  %6330 = icmp ult i32 %6328, 8
  %6331 = and i1 %6329, %6330
  %6332 = and i1 %6300, %6331
  %convergence.parent.token995 = load i32, ptr %current.token, align 4
  %convergence.parent.present996 = icmp ne i32 %convergence.parent.token995, 0
  %6333 = and i1 %6332, %convergence.parent.present996
  br i1 %6333, label %convergence.cascade981, label %convergence.cascade.exit982

convergence.cascade.exit982:                      ; preds = %convergence.cascade981, %schedule.32
  %convergence.cascade.result997 = phi <8 x i1> [ %587, %schedule.32 ], [ %6327, %convergence.cascade981 ]
  %6334 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result997)
  br i1 %6334, label %convergence.target.32.ready, label %scheduler.loop

convergence.target.32.ready:                      ; preds = %convergence.cascade.exit982
  %6335 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result997)
  %6336 = bitcast <8 x i1> %convergence.cascade.result997 to i8
  %6337 = call i8 @llvm.cttz.i8(i8 %6336, i1 false)
  %6338 = zext i8 %6337 to i32
  %6339 = select i1 %6335, i32 %6338, i32 0
  %6340 = load <8 x i64>, ptr %.slot220, align 64
  %6341 = select <8 x i1> %convergence.cascade.result997, <8 x i64> zeroinitializer, <8 x i64> %6340
  store <8 x i64> %6341, ptr %.slot220, align 64
  %6342 = load <8 x float>, ptr %.slot221, align 32
  %6343 = select <8 x i1> %convergence.cascade.result997, <8 x float> zeroinitializer, <8 x float> %6342
  store <8 x float> %6343, ptr %.slot221, align 32
  store <8 x i1> %convergence.cascade.result997, ptr %current.mask, align 1
  %6344 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result997)
  br i1 %6344, label %schedule.33, label %scheduler.loop

varying.divergent999:                             ; preds = %schedule.33
  %6345 = load i32, ptr %current.token, align 4
  %6346 = icmp ne i32 %6345, 0
  %6347 = sub i32 %6345, 1
  %6348 = select i1 %6346, i32 %6347, i32 0
  %6349 = load i8, ptr %frame.active, align 1
  %6350 = trunc i32 %6348 to i8
  %6351 = shl i8 1, %6350
  %6352 = and i8 %6349, %6351
  %6353 = icmp ne i8 %6352, 0
  %6354 = load <8 x i32>, ptr %frame.static.id, align 32
  %6355 = extractelement <8 x i32> %6354, i32 %6348
  %6356 = icmp eq i32 %6355, 12
  %6357 = and i1 %6353, %6356
  %6358 = and i1 %6346, %6357
  %6359 = xor i1 %6358, true
  %6360 = and i1 true, %6359
  %6361 = xor i8 %6349, -1
  %6362 = icmp ne i8 %6361, 0
  %6363 = xor i1 %6362, true
  %6364 = and i1 %6360, %6363
  br i1 %6364, label %convergence.overflow.trap1001, label %convergence.overflow.resume1002

varying.coherent1000:                             ; preds = %schedule.33
  br i1 %598, label %varying.coherent.true1005, label %varying.coherent.false1006

convergence.overflow.trap1001:                    ; preds = %varying.divergent999
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1002:                  ; preds = %varying.divergent999
  %6365 = call i8 @llvm.cttz.i8(i8 %6361, i1 false)
  %6366 = zext i8 %6365 to i32
  %6367 = select i1 %6362, i32 %6366, i32 0
  %6368 = trunc i32 %6367 to i8
  %6369 = shl i8 1, %6368
  %6370 = or i8 %6349, %6369
  %6371 = select i1 %6360, i8 %6370, i8 %6349
  store i8 %6371, ptr %frame.active, align 1
  %6372 = load <8 x i32>, ptr %frame.static.id, align 32
  %6373 = extractelement <8 x i32> %6372, i32 %6367
  %6374 = select i1 %6360, i32 12, i32 %6373
  %6375 = load <8 x i32>, ptr %frame.static.id, align 32
  %6376 = insertelement <8 x i32> %6375, i32 %6374, i32 %6367
  store <8 x i32> %6376, ptr %frame.static.id, align 32
  %6377 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6378 = extractelement <8 x i32> %6377, i32 %6367
  %6379 = select i1 %6360, i32 %6345, i32 %6378
  %6380 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6381 = insertelement <8 x i32> %6380, i32 %6379, i32 %6367
  store <8 x i32> %6381, ptr %frame.parent.token, align 32
  %6382 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6367
  %6383 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6367
  %6384 = load <8 x i1>, ptr %6382, align 1
  %6385 = load <8 x i1>, ptr %6383, align 1
  %6386 = select i1 %6360, <8 x i1> %588, <8 x i1> %6384
  store <8 x i1> %6386, ptr %6382, align 1
  %6387 = select i1 %6360, <8 x i1> zeroinitializer, <8 x i1> %6385
  store <8 x i1> %6387, ptr %6383, align 1
  %6388 = add i32 %6367, 1
  %6389 = select i1 %6358, i32 %6345, i32 %6388
  %6390 = select i1 true, i32 %6389, i32 %6345
  store i32 %6390, ptr %current.token, align 4
  %6391 = load i32, ptr %current.token, align 4
  %6392 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %595)
  %6393 = load i32, ptr %ready.count, align 4
  %6394 = icmp uge i32 %6393, 8
  %6395 = and i1 %6392, %6394
  br i1 %6395, label %ready.overflow.trap1003, label %ready.overflow.resume1004

ready.overflow.trap1003:                          ; preds = %convergence.overflow.resume1002
  call void @llvm.trap()
  unreachable

ready.overflow.resume1004:                        ; preds = %convergence.overflow.resume1002
  %6396 = select i1 %6392, i32 %6393, i32 0
  %6397 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6396
  %6398 = load <8 x i1>, ptr %6397, align 1
  %6399 = select i1 %6392, <8 x i1> %595, <8 x i1> %6398
  store <8 x i1> %6399, ptr %6397, align 1
  %6400 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6396
  %6401 = load i32, ptr %6400, align 4
  %6402 = select i1 %6392, i32 34, i32 %6401
  store i32 %6402, ptr %6400, align 4
  %6403 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6396
  %6404 = load i32, ptr %6403, align 4
  %6405 = select i1 %6392, i32 %6391, i32 %6404
  store i32 %6405, ptr %6403, align 4
  %6406 = add i32 %6393, 1
  %6407 = select i1 %6392, i32 %6406, i32 %6393
  store i32 %6407, ptr %ready.count, align 4
  %6408 = load <8 x i1>, ptr %runnable.mask, align 1
  %6409 = or <8 x i1> %6408, %595
  store <8 x i1> %6409, ptr %runnable.mask, align 1
  store <8 x i1> %597, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1005:                        ; preds = %varying.coherent1000
  store <8 x i1> %588, ptr %current.mask, align 1
  %6410 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %588)
  br i1 %6410, label %schedule.34, label %scheduler.loop

varying.coherent.false1006:                       ; preds = %varying.coherent1000
  store <8 x i1> %588, ptr %current.mask, align 1
  %6411 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %588)
  br i1 %6411, label %schedule.35, label %scheduler.loop

convergence.cascade1011:                          ; preds = %convergence.cascade1011, %schedule.35
  %convergence.cascade.flow1015 = phi <8 x i1> [ %628, %schedule.35 ], [ %6454, %convergence.cascade1011 ]
  %convergence.cascade.depth1016 = phi i32 [ 0, %schedule.35 ], [ %6455, %convergence.cascade1011 ]
  %6412 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1015)
  %6413 = load i32, ptr %current.token, align 4
  %6414 = icmp ne i32 %6413, 0
  %6415 = and i1 %6412, %6414
  %6416 = sub i32 %6413, 1
  %6417 = select i1 %6415, i32 %6416, i32 0
  %6418 = load i8, ptr %frame.active, align 1
  %6419 = trunc i32 %6417 to i8
  %6420 = shl i8 1, %6419
  %6421 = and i8 %6418, %6420
  %6422 = icmp ne i8 %6421, 0
  %6423 = load <8 x i32>, ptr %frame.static.id, align 32
  %6424 = extractelement <8 x i32> %6423, i32 %6417
  %convergence.target.pointer1017 = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %6424
  %convergence.dynamic.target1018 = load i32, ptr %convergence.target.pointer1017, align 4
  %6425 = icmp eq i32 %convergence.dynamic.target1018, 35
  %6426 = and i1 %6422, %6425
  %6427 = and i1 %6415, %6426
  %6428 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6417
  %6429 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6417
  %6430 = load <8 x i1>, ptr %6428, align 1
  %6431 = load <8 x i1>, ptr %6429, align 1
  %6432 = or <8 x i1> %6431, %convergence.cascade.flow1015
  %6433 = load <8 x i1>, ptr %live.mask, align 1
  %6434 = and <8 x i1> %6430, %6433
  %6435 = icmp eq <8 x i1> %6432, %6434
  %6436 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6435)
  %6437 = and i1 %6427, %6436
  %6438 = select i1 %6437, <8 x i1> zeroinitializer, <8 x i1> %6432
  %6439 = select i1 %6427, <8 x i1> %6438, <8 x i1> %6431
  store <8 x i1> %6439, ptr %6429, align 1
  %6440 = select i1 %6437, <8 x i1> zeroinitializer, <8 x i1> %6430
  store <8 x i1> %6440, ptr %6428, align 1
  %6441 = trunc i32 %6417 to i8
  %6442 = shl i8 1, %6441
  %6443 = xor i8 %6442, -1
  %6444 = and i8 %6418, %6443
  %6445 = select i1 %6437, i8 %6444, i8 %6418
  store i8 %6445, ptr %frame.active, align 1
  %.splatinsert1019 = insertelement <8 x i1> poison, i1 %6427, i64 0
  %.splat1020 = shufflevector <8 x i1> %.splatinsert1019, <8 x i1> poison, <8 x i32> zeroinitializer
  %6446 = and <8 x i1> %convergence.cascade.flow1015, %.splat1020
  %6447 = load <8 x i1>, ptr %runnable.mask, align 1
  %6448 = xor <8 x i1> %6446, splat (i1 true)
  %6449 = and <8 x i1> %6447, %6448
  store <8 x i1> %6449, ptr %runnable.mask, align 1
  %.splatinsert1021 = insertelement <8 x i1> poison, i1 %6437, i64 0
  %.splat1022 = shufflevector <8 x i1> %.splatinsert1021, <8 x i1> poison, <8 x i32> zeroinitializer
  %6450 = select <8 x i1> %.splat1022, <8 x i1> %6432, <8 x i1> zeroinitializer
  %6451 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6452 = extractelement <8 x i32> %6451, i32 %6417
  %6453 = select i1 %6437, i32 %6452, i32 %6413
  store i32 %6453, ptr %current.token, align 4
  %.splatinsert1023 = insertelement <8 x i1> poison, i1 %6427, i64 0
  %.splat1024 = shufflevector <8 x i1> %.splatinsert1023, <8 x i1> poison, <8 x i32> zeroinitializer
  %6454 = select <8 x i1> %.splat1024, <8 x i1> %6450, <8 x i1> %convergence.cascade.flow1015
  %6455 = add i32 %convergence.cascade.depth1016, 1
  %6456 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6454)
  %6457 = icmp ult i32 %6455, 8
  %6458 = and i1 %6456, %6457
  %6459 = and i1 %6427, %6458
  %convergence.parent.token1025 = load i32, ptr %current.token, align 4
  %convergence.parent.present1026 = icmp ne i32 %convergence.parent.token1025, 0
  %6460 = and i1 %6459, %convergence.parent.present1026
  br i1 %6460, label %convergence.cascade1011, label %convergence.cascade.exit1012

convergence.cascade.exit1012:                     ; preds = %convergence.cascade1011, %schedule.35
  %convergence.cascade.result1027 = phi <8 x i1> [ %628, %schedule.35 ], [ %6454, %convergence.cascade1011 ]
  %6461 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1027)
  br i1 %6461, label %convergence.target.35.ready, label %scheduler.loop

convergence.target.35.ready:                      ; preds = %convergence.cascade.exit1012
  %6462 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1027)
  %6463 = bitcast <8 x i1> %convergence.cascade.result1027 to i8
  %6464 = call i8 @llvm.cttz.i8(i8 %6463, i1 false)
  %6465 = zext i8 %6464 to i32
  %6466 = select i1 %6462, i32 %6465, i32 0
  %.spill.load1028 = load volatile <8 x float>, ptr %.spill210, align 32
  %.state1029 = load <8 x float>, ptr %.slot215, align 32
  %6467 = fadd <8 x float> %.spill.load1028, %.state1029
  %6468 = load volatile <8 x float>, ptr %.spill222, align 32
  %6469 = select <8 x i1> %convergence.cascade.result1027, <8 x float> %6467, <8 x float> %6468
  store volatile <8 x float> %6469, ptr %.spill222, align 32
  %.spill.load1030 = load volatile <8 x float>, ptr %.spill211, align 32
  %.state1031 = load <8 x float>, ptr %.slot217, align 32
  %6470 = fadd <8 x float> %.spill.load1030, %.state1031
  %6471 = load volatile <8 x float>, ptr %.spill223, align 32
  %6472 = select <8 x i1> %convergence.cascade.result1027, <8 x float> %6470, <8 x float> %6471
  store volatile <8 x float> %6472, ptr %.spill223, align 32
  %.spill.load1032 = load volatile <8 x float>, ptr %.spill212, align 32
  %.state1033 = load <8 x float>, ptr %.slot219, align 32
  %6473 = fadd <8 x float> %.spill.load1032, %.state1033
  %6474 = load volatile <8 x float>, ptr %.spill224, align 32
  %6475 = select <8 x i1> %convergence.cascade.result1027, <8 x float> %6473, <8 x float> %6474
  store volatile <8 x float> %6475, ptr %.spill224, align 32
  %.spill.load1034 = load volatile <8 x float>, ptr %.spill213, align 32
  %.state1035 = load <8 x float>, ptr %.slot221, align 32
  %6476 = fadd <8 x float> %.spill.load1034, %.state1035
  %6477 = load volatile <8 x float>, ptr %.spill225, align 32
  %6478 = select <8 x i1> %convergence.cascade.result1027, <8 x float> %6476, <8 x float> %6477
  store volatile <8 x float> %6478, ptr %.spill225, align 32
  %6479 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill226, align 64
  %6480 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %6481 = extractvalue { <8 x ptr>, <8 x i64> } %6479, 0
  %6482 = select <8 x i1> %convergence.cascade.result1027, <8 x ptr> %6480, <8 x ptr> %6481
  %6483 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %6484 = extractvalue { <8 x ptr>, <8 x i64> } %6479, 1
  %6485 = select <8 x i1> %convergence.cascade.result1027, <8 x i64> %6483, <8 x i64> %6484
  %6486 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6482, 0
  %6487 = insertvalue { <8 x ptr>, <8 x i64> } %6486, <8 x i64> %6485, 1
  store volatile { <8 x ptr>, <8 x i64> } %6487, ptr %tile_snapshot.spill226, align 64
  %6488 = load <8 x i64>, ptr %.slot227, align 64
  %6489 = select <8 x i1> %convergence.cascade.result1027, <8 x i64> zeroinitializer, <8 x i64> %6488
  store <8 x i64> %6489, ptr %.slot227, align 64
  store <8 x i1> %convergence.cascade.result1027, ptr %current.mask, align 1
  %6490 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1027)
  br i1 %6490, label %schedule.36, label %scheduler.loop

varying.divergent1037:                            ; preds = %schedule.36
  %6491 = load i32, ptr %current.token, align 4
  %6492 = icmp ne i32 %6491, 0
  %6493 = sub i32 %6491, 1
  %6494 = select i1 %6492, i32 %6493, i32 0
  %6495 = load i8, ptr %frame.active, align 1
  %6496 = trunc i32 %6494 to i8
  %6497 = shl i8 1, %6496
  %6498 = and i8 %6495, %6497
  %6499 = icmp ne i8 %6498, 0
  %6500 = load <8 x i32>, ptr %frame.static.id, align 32
  %6501 = extractelement <8 x i32> %6500, i32 %6494
  %6502 = icmp eq i32 %6501, 13
  %6503 = and i1 %6499, %6502
  %6504 = and i1 %6492, %6503
  %6505 = xor i1 %6504, true
  %6506 = and i1 true, %6505
  %6507 = xor i8 %6495, -1
  %6508 = icmp ne i8 %6507, 0
  %6509 = xor i1 %6508, true
  %6510 = and i1 %6506, %6509
  br i1 %6510, label %convergence.overflow.trap1039, label %convergence.overflow.resume1040

varying.coherent1038:                             ; preds = %schedule.36
  br i1 %639, label %varying.coherent.true1043, label %varying.coherent.false1044

convergence.overflow.trap1039:                    ; preds = %varying.divergent1037
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1040:                  ; preds = %varying.divergent1037
  %6511 = call i8 @llvm.cttz.i8(i8 %6507, i1 false)
  %6512 = zext i8 %6511 to i32
  %6513 = select i1 %6508, i32 %6512, i32 0
  %6514 = trunc i32 %6513 to i8
  %6515 = shl i8 1, %6514
  %6516 = or i8 %6495, %6515
  %6517 = select i1 %6506, i8 %6516, i8 %6495
  store i8 %6517, ptr %frame.active, align 1
  %6518 = load <8 x i32>, ptr %frame.static.id, align 32
  %6519 = extractelement <8 x i32> %6518, i32 %6513
  %6520 = select i1 %6506, i32 13, i32 %6519
  %6521 = load <8 x i32>, ptr %frame.static.id, align 32
  %6522 = insertelement <8 x i32> %6521, i32 %6520, i32 %6513
  store <8 x i32> %6522, ptr %frame.static.id, align 32
  %6523 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6524 = extractelement <8 x i32> %6523, i32 %6513
  %6525 = select i1 %6506, i32 %6491, i32 %6524
  %6526 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6527 = insertelement <8 x i32> %6526, i32 %6525, i32 %6513
  store <8 x i32> %6527, ptr %frame.parent.token, align 32
  %6528 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6513
  %6529 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6513
  %6530 = load <8 x i1>, ptr %6528, align 1
  %6531 = load <8 x i1>, ptr %6529, align 1
  %6532 = select i1 %6506, <8 x i1> %629, <8 x i1> %6530
  store <8 x i1> %6532, ptr %6528, align 1
  %6533 = select i1 %6506, <8 x i1> zeroinitializer, <8 x i1> %6531
  store <8 x i1> %6533, ptr %6529, align 1
  %6534 = add i32 %6513, 1
  %6535 = select i1 %6504, i32 %6491, i32 %6534
  %6536 = select i1 true, i32 %6535, i32 %6491
  store i32 %6536, ptr %current.token, align 4
  %6537 = load i32, ptr %current.token, align 4
  %6538 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %636)
  %6539 = load i32, ptr %ready.count, align 4
  %6540 = icmp uge i32 %6539, 8
  %6541 = and i1 %6538, %6540
  br i1 %6541, label %ready.overflow.trap1041, label %ready.overflow.resume1042

ready.overflow.trap1041:                          ; preds = %convergence.overflow.resume1040
  call void @llvm.trap()
  unreachable

ready.overflow.resume1042:                        ; preds = %convergence.overflow.resume1040
  %6542 = select i1 %6538, i32 %6539, i32 0
  %6543 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6542
  %6544 = load <8 x i1>, ptr %6543, align 1
  %6545 = select i1 %6538, <8 x i1> %636, <8 x i1> %6544
  store <8 x i1> %6545, ptr %6543, align 1
  %6546 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6542
  %6547 = load i32, ptr %6546, align 4
  %6548 = select i1 %6538, i32 37, i32 %6547
  store i32 %6548, ptr %6546, align 4
  %6549 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6542
  %6550 = load i32, ptr %6549, align 4
  %6551 = select i1 %6538, i32 %6537, i32 %6550
  store i32 %6551, ptr %6549, align 4
  %6552 = add i32 %6539, 1
  %6553 = select i1 %6538, i32 %6552, i32 %6539
  store i32 %6553, ptr %ready.count, align 4
  %6554 = load <8 x i1>, ptr %runnable.mask, align 1
  %6555 = or <8 x i1> %6554, %636
  store <8 x i1> %6555, ptr %runnable.mask, align 1
  store <8 x i1> %638, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1043:                        ; preds = %varying.coherent1038
  store <8 x i1> %629, ptr %current.mask, align 1
  %6556 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %629)
  br i1 %6556, label %schedule.37, label %scheduler.loop

varying.coherent.false1044:                       ; preds = %varying.coherent1038
  store <8 x i1> %629, ptr %current.mask, align 1
  %6557 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %629)
  br i1 %6557, label %schedule.38, label %scheduler.loop

convergence.cascade1052:                          ; preds = %convergence.cascade1052, %schedule.38
  %convergence.cascade.flow1056 = phi <8 x i1> [ %691, %schedule.38 ], [ %6600, %convergence.cascade1052 ]
  %convergence.cascade.depth1057 = phi i32 [ 0, %schedule.38 ], [ %6601, %convergence.cascade1052 ]
  %6558 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1056)
  %6559 = load i32, ptr %current.token, align 4
  %6560 = icmp ne i32 %6559, 0
  %6561 = and i1 %6558, %6560
  %6562 = sub i32 %6559, 1
  %6563 = select i1 %6561, i32 %6562, i32 0
  %6564 = load i8, ptr %frame.active, align 1
  %6565 = trunc i32 %6563 to i8
  %6566 = shl i8 1, %6565
  %6567 = and i8 %6564, %6566
  %6568 = icmp ne i8 %6567, 0
  %6569 = load <8 x i32>, ptr %frame.static.id, align 32
  %6570 = extractelement <8 x i32> %6569, i32 %6563
  %convergence.target.pointer1058 = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %6570
  %convergence.dynamic.target1059 = load i32, ptr %convergence.target.pointer1058, align 4
  %6571 = icmp eq i32 %convergence.dynamic.target1059, 38
  %6572 = and i1 %6568, %6571
  %6573 = and i1 %6561, %6572
  %6574 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6563
  %6575 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6563
  %6576 = load <8 x i1>, ptr %6574, align 1
  %6577 = load <8 x i1>, ptr %6575, align 1
  %6578 = or <8 x i1> %6577, %convergence.cascade.flow1056
  %6579 = load <8 x i1>, ptr %live.mask, align 1
  %6580 = and <8 x i1> %6576, %6579
  %6581 = icmp eq <8 x i1> %6578, %6580
  %6582 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6581)
  %6583 = and i1 %6573, %6582
  %6584 = select i1 %6583, <8 x i1> zeroinitializer, <8 x i1> %6578
  %6585 = select i1 %6573, <8 x i1> %6584, <8 x i1> %6577
  store <8 x i1> %6585, ptr %6575, align 1
  %6586 = select i1 %6583, <8 x i1> zeroinitializer, <8 x i1> %6576
  store <8 x i1> %6586, ptr %6574, align 1
  %6587 = trunc i32 %6563 to i8
  %6588 = shl i8 1, %6587
  %6589 = xor i8 %6588, -1
  %6590 = and i8 %6564, %6589
  %6591 = select i1 %6583, i8 %6590, i8 %6564
  store i8 %6591, ptr %frame.active, align 1
  %.splatinsert1060 = insertelement <8 x i1> poison, i1 %6573, i64 0
  %.splat1061 = shufflevector <8 x i1> %.splatinsert1060, <8 x i1> poison, <8 x i32> zeroinitializer
  %6592 = and <8 x i1> %convergence.cascade.flow1056, %.splat1061
  %6593 = load <8 x i1>, ptr %runnable.mask, align 1
  %6594 = xor <8 x i1> %6592, splat (i1 true)
  %6595 = and <8 x i1> %6593, %6594
  store <8 x i1> %6595, ptr %runnable.mask, align 1
  %.splatinsert1062 = insertelement <8 x i1> poison, i1 %6583, i64 0
  %.splat1063 = shufflevector <8 x i1> %.splatinsert1062, <8 x i1> poison, <8 x i32> zeroinitializer
  %6596 = select <8 x i1> %.splat1063, <8 x i1> %6578, <8 x i1> zeroinitializer
  %6597 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6598 = extractelement <8 x i32> %6597, i32 %6563
  %6599 = select i1 %6583, i32 %6598, i32 %6559
  store i32 %6599, ptr %current.token, align 4
  %.splatinsert1064 = insertelement <8 x i1> poison, i1 %6573, i64 0
  %.splat1065 = shufflevector <8 x i1> %.splatinsert1064, <8 x i1> poison, <8 x i32> zeroinitializer
  %6600 = select <8 x i1> %.splat1065, <8 x i1> %6596, <8 x i1> %convergence.cascade.flow1056
  %6601 = add i32 %convergence.cascade.depth1057, 1
  %6602 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6600)
  %6603 = icmp ult i32 %6601, 8
  %6604 = and i1 %6602, %6603
  %6605 = and i1 %6573, %6604
  %convergence.parent.token1066 = load i32, ptr %current.token, align 4
  %convergence.parent.present1067 = icmp ne i32 %convergence.parent.token1066, 0
  %6606 = and i1 %6605, %convergence.parent.present1067
  br i1 %6606, label %convergence.cascade1052, label %convergence.cascade.exit1053

convergence.cascade.exit1053:                     ; preds = %convergence.cascade1052, %schedule.38
  %convergence.cascade.result1068 = phi <8 x i1> [ %691, %schedule.38 ], [ %6600, %convergence.cascade1052 ]
  %6607 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1068)
  br i1 %6607, label %convergence.target.38.ready, label %scheduler.loop

convergence.target.38.ready:                      ; preds = %convergence.cascade.exit1053
  %6608 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1068)
  %6609 = bitcast <8 x i1> %convergence.cascade.result1068 to i8
  %6610 = call i8 @llvm.cttz.i8(i8 %6609, i1 false)
  %6611 = zext i8 %6610 to i32
  %6612 = select i1 %6608, i32 %6611, i32 0
  %6613 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill228, align 64
  %6614 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %6615 = extractvalue { <8 x ptr>, <8 x i64> } %6613, 0
  %6616 = select <8 x i1> %convergence.cascade.result1068, <8 x ptr> %6614, <8 x ptr> %6615
  %6617 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %6618 = extractvalue { <8 x ptr>, <8 x i64> } %6613, 1
  %6619 = select <8 x i1> %convergence.cascade.result1068, <8 x i64> %6617, <8 x i64> %6618
  %6620 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6616, 0
  %6621 = insertvalue { <8 x ptr>, <8 x i64> } %6620, <8 x i64> %6619, 1
  store volatile { <8 x ptr>, <8 x i64> } %6621, ptr %tile_snapshot.spill228, align 64
  %tile_snapshot.spill.load1069 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill209, align 64
  %tile_snapshot.spill.load1070 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill66, align 64
  %tile_snapshot.spill.load1071 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill226, align 64
  %6622 = extractelement <8 x i1> %convergence.cascade.result1068, i64 0
  br i1 %6622, label %mma.active1072, label %mma.continue1073

mma.active1072:                                   ; preds = %convergence.target.38.ready
  %6623 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1069, 0
  %6624 = extractelement <8 x ptr> %6623, i64 0
  %6625 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1069, 1
  %6626 = extractelement <8 x i64> %6625, i64 0
  %6627 = getelementptr i8, ptr %6624, i64 %6626
  %6628 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1070, 0
  %6629 = extractelement <8 x ptr> %6628, i64 0
  %6630 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1070, 1
  %6631 = extractelement <8 x i64> %6630, i64 0
  %6632 = getelementptr i8, ptr %6629, i64 %6631
  %6633 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1071, 0
  %6634 = extractelement <8 x ptr> %6633, i64 0
  %6635 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1071, 1
  %6636 = extractelement <8 x i64> %6635, i64 0
  %6637 = getelementptr i8, ptr %6634, i64 %6636
  %6638 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %6639 = extractelement <8 x ptr> %6638, i64 0
  %6640 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %6641 = extractelement <8 x i64> %6640, i64 0
  %6642 = getelementptr i8, ptr %6639, i64 %6641
  call void @llm_attention.strided_mma.3(ptr %6627, ptr %6632, ptr %6637, ptr %6642)
  br label %mma.continue1073

mma.continue1073:                                 ; preds = %mma.active1072, %convergence.target.38.ready
  %6643 = extractelement <8 x i1> %convergence.cascade.result1068, i64 1
  br i1 %6643, label %mma.active1074, label %mma.continue1075

mma.active1074:                                   ; preds = %mma.continue1073
  %6644 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1069, 0
  %6645 = extractelement <8 x ptr> %6644, i64 1
  %6646 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1069, 1
  %6647 = extractelement <8 x i64> %6646, i64 1
  %6648 = getelementptr i8, ptr %6645, i64 %6647
  %6649 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1070, 0
  %6650 = extractelement <8 x ptr> %6649, i64 1
  %6651 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1070, 1
  %6652 = extractelement <8 x i64> %6651, i64 1
  %6653 = getelementptr i8, ptr %6650, i64 %6652
  %6654 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1071, 0
  %6655 = extractelement <8 x ptr> %6654, i64 1
  %6656 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1071, 1
  %6657 = extractelement <8 x i64> %6656, i64 1
  %6658 = getelementptr i8, ptr %6655, i64 %6657
  %6659 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %6660 = extractelement <8 x ptr> %6659, i64 1
  %6661 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %6662 = extractelement <8 x i64> %6661, i64 1
  %6663 = getelementptr i8, ptr %6660, i64 %6662
  call void @llm_attention.strided_mma.3(ptr %6648, ptr %6653, ptr %6658, ptr %6663)
  br label %mma.continue1075

mma.continue1075:                                 ; preds = %mma.active1074, %mma.continue1073
  %6664 = extractelement <8 x i1> %convergence.cascade.result1068, i64 2
  br i1 %6664, label %mma.active1076, label %mma.continue1077

mma.active1076:                                   ; preds = %mma.continue1075
  %6665 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1069, 0
  %6666 = extractelement <8 x ptr> %6665, i64 2
  %6667 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1069, 1
  %6668 = extractelement <8 x i64> %6667, i64 2
  %6669 = getelementptr i8, ptr %6666, i64 %6668
  %6670 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1070, 0
  %6671 = extractelement <8 x ptr> %6670, i64 2
  %6672 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1070, 1
  %6673 = extractelement <8 x i64> %6672, i64 2
  %6674 = getelementptr i8, ptr %6671, i64 %6673
  %6675 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1071, 0
  %6676 = extractelement <8 x ptr> %6675, i64 2
  %6677 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1071, 1
  %6678 = extractelement <8 x i64> %6677, i64 2
  %6679 = getelementptr i8, ptr %6676, i64 %6678
  %6680 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %6681 = extractelement <8 x ptr> %6680, i64 2
  %6682 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %6683 = extractelement <8 x i64> %6682, i64 2
  %6684 = getelementptr i8, ptr %6681, i64 %6683
  call void @llm_attention.strided_mma.3(ptr %6669, ptr %6674, ptr %6679, ptr %6684)
  br label %mma.continue1077

mma.continue1077:                                 ; preds = %mma.active1076, %mma.continue1075
  %6685 = extractelement <8 x i1> %convergence.cascade.result1068, i64 3
  br i1 %6685, label %mma.active1078, label %mma.continue1079

mma.active1078:                                   ; preds = %mma.continue1077
  %6686 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1069, 0
  %6687 = extractelement <8 x ptr> %6686, i64 3
  %6688 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1069, 1
  %6689 = extractelement <8 x i64> %6688, i64 3
  %6690 = getelementptr i8, ptr %6687, i64 %6689
  %6691 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1070, 0
  %6692 = extractelement <8 x ptr> %6691, i64 3
  %6693 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1070, 1
  %6694 = extractelement <8 x i64> %6693, i64 3
  %6695 = getelementptr i8, ptr %6692, i64 %6694
  %6696 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1071, 0
  %6697 = extractelement <8 x ptr> %6696, i64 3
  %6698 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1071, 1
  %6699 = extractelement <8 x i64> %6698, i64 3
  %6700 = getelementptr i8, ptr %6697, i64 %6699
  %6701 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %6702 = extractelement <8 x ptr> %6701, i64 3
  %6703 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %6704 = extractelement <8 x i64> %6703, i64 3
  %6705 = getelementptr i8, ptr %6702, i64 %6704
  call void @llm_attention.strided_mma.3(ptr %6690, ptr %6695, ptr %6700, ptr %6705)
  br label %mma.continue1079

mma.continue1079:                                 ; preds = %mma.active1078, %mma.continue1077
  %6706 = extractelement <8 x i1> %convergence.cascade.result1068, i64 4
  br i1 %6706, label %mma.active1080, label %mma.continue1081

mma.active1080:                                   ; preds = %mma.continue1079
  %6707 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1069, 0
  %6708 = extractelement <8 x ptr> %6707, i64 4
  %6709 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1069, 1
  %6710 = extractelement <8 x i64> %6709, i64 4
  %6711 = getelementptr i8, ptr %6708, i64 %6710
  %6712 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1070, 0
  %6713 = extractelement <8 x ptr> %6712, i64 4
  %6714 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1070, 1
  %6715 = extractelement <8 x i64> %6714, i64 4
  %6716 = getelementptr i8, ptr %6713, i64 %6715
  %6717 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1071, 0
  %6718 = extractelement <8 x ptr> %6717, i64 4
  %6719 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1071, 1
  %6720 = extractelement <8 x i64> %6719, i64 4
  %6721 = getelementptr i8, ptr %6718, i64 %6720
  %6722 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %6723 = extractelement <8 x ptr> %6722, i64 4
  %6724 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %6725 = extractelement <8 x i64> %6724, i64 4
  %6726 = getelementptr i8, ptr %6723, i64 %6725
  call void @llm_attention.strided_mma.3(ptr %6711, ptr %6716, ptr %6721, ptr %6726)
  br label %mma.continue1081

mma.continue1081:                                 ; preds = %mma.active1080, %mma.continue1079
  %6727 = extractelement <8 x i1> %convergence.cascade.result1068, i64 5
  br i1 %6727, label %mma.active1082, label %mma.continue1083

mma.active1082:                                   ; preds = %mma.continue1081
  %6728 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1069, 0
  %6729 = extractelement <8 x ptr> %6728, i64 5
  %6730 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1069, 1
  %6731 = extractelement <8 x i64> %6730, i64 5
  %6732 = getelementptr i8, ptr %6729, i64 %6731
  %6733 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1070, 0
  %6734 = extractelement <8 x ptr> %6733, i64 5
  %6735 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1070, 1
  %6736 = extractelement <8 x i64> %6735, i64 5
  %6737 = getelementptr i8, ptr %6734, i64 %6736
  %6738 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1071, 0
  %6739 = extractelement <8 x ptr> %6738, i64 5
  %6740 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1071, 1
  %6741 = extractelement <8 x i64> %6740, i64 5
  %6742 = getelementptr i8, ptr %6739, i64 %6741
  %6743 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %6744 = extractelement <8 x ptr> %6743, i64 5
  %6745 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %6746 = extractelement <8 x i64> %6745, i64 5
  %6747 = getelementptr i8, ptr %6744, i64 %6746
  call void @llm_attention.strided_mma.3(ptr %6732, ptr %6737, ptr %6742, ptr %6747)
  br label %mma.continue1083

mma.continue1083:                                 ; preds = %mma.active1082, %mma.continue1081
  %6748 = extractelement <8 x i1> %convergence.cascade.result1068, i64 6
  br i1 %6748, label %mma.active1084, label %mma.continue1085

mma.active1084:                                   ; preds = %mma.continue1083
  %6749 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1069, 0
  %6750 = extractelement <8 x ptr> %6749, i64 6
  %6751 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1069, 1
  %6752 = extractelement <8 x i64> %6751, i64 6
  %6753 = getelementptr i8, ptr %6750, i64 %6752
  %6754 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1070, 0
  %6755 = extractelement <8 x ptr> %6754, i64 6
  %6756 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1070, 1
  %6757 = extractelement <8 x i64> %6756, i64 6
  %6758 = getelementptr i8, ptr %6755, i64 %6757
  %6759 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1071, 0
  %6760 = extractelement <8 x ptr> %6759, i64 6
  %6761 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1071, 1
  %6762 = extractelement <8 x i64> %6761, i64 6
  %6763 = getelementptr i8, ptr %6760, i64 %6762
  %6764 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %6765 = extractelement <8 x ptr> %6764, i64 6
  %6766 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %6767 = extractelement <8 x i64> %6766, i64 6
  %6768 = getelementptr i8, ptr %6765, i64 %6767
  call void @llm_attention.strided_mma.3(ptr %6753, ptr %6758, ptr %6763, ptr %6768)
  br label %mma.continue1085

mma.continue1085:                                 ; preds = %mma.active1084, %mma.continue1083
  %6769 = extractelement <8 x i1> %convergence.cascade.result1068, i64 7
  br i1 %6769, label %mma.active1086, label %mma.continue1087

mma.active1086:                                   ; preds = %mma.continue1085
  %6770 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1069, 0
  %6771 = extractelement <8 x ptr> %6770, i64 7
  %6772 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1069, 1
  %6773 = extractelement <8 x i64> %6772, i64 7
  %6774 = getelementptr i8, ptr %6771, i64 %6773
  %6775 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1070, 0
  %6776 = extractelement <8 x ptr> %6775, i64 7
  %6777 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1070, 1
  %6778 = extractelement <8 x i64> %6777, i64 7
  %6779 = getelementptr i8, ptr %6776, i64 %6778
  %6780 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1071, 0
  %6781 = extractelement <8 x ptr> %6780, i64 7
  %6782 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1071, 1
  %6783 = extractelement <8 x i64> %6782, i64 7
  %6784 = getelementptr i8, ptr %6781, i64 %6783
  %6785 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %6786 = extractelement <8 x ptr> %6785, i64 7
  %6787 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %6788 = extractelement <8 x i64> %6787, i64 7
  %6789 = getelementptr i8, ptr %6786, i64 %6788
  call void @llm_attention.strided_mma.3(ptr %6774, ptr %6779, ptr %6784, ptr %6789)
  br label %mma.continue1087

mma.continue1087:                                 ; preds = %mma.active1086, %mma.continue1085
  %6790 = load <8 x i64>, ptr %.slot229, align 64
  %6791 = select <8 x i1> %convergence.cascade.result1068, <8 x i64> zeroinitializer, <8 x i64> %6790
  store <8 x i64> %6791, ptr %.slot229, align 64
  store <8 x i1> %convergence.cascade.result1068, ptr %current.mask, align 1
  %6792 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1068)
  br i1 %6792, label %schedule.39, label %scheduler.loop

varying.divergent1089:                            ; preds = %schedule.39
  %6793 = load i32, ptr %current.token, align 4
  %6794 = icmp ne i32 %6793, 0
  %6795 = sub i32 %6793, 1
  %6796 = select i1 %6794, i32 %6795, i32 0
  %6797 = load i8, ptr %frame.active, align 1
  %6798 = trunc i32 %6796 to i8
  %6799 = shl i8 1, %6798
  %6800 = and i8 %6797, %6799
  %6801 = icmp ne i8 %6800, 0
  %6802 = load <8 x i32>, ptr %frame.static.id, align 32
  %6803 = extractelement <8 x i32> %6802, i32 %6796
  %6804 = icmp eq i32 %6803, 14
  %6805 = and i1 %6801, %6804
  %6806 = and i1 %6794, %6805
  %6807 = xor i1 %6806, true
  %6808 = and i1 true, %6807
  %6809 = xor i8 %6797, -1
  %6810 = icmp ne i8 %6809, 0
  %6811 = xor i1 %6810, true
  %6812 = and i1 %6808, %6811
  br i1 %6812, label %convergence.overflow.trap1091, label %convergence.overflow.resume1092

varying.coherent1090:                             ; preds = %schedule.39
  br i1 %702, label %varying.coherent.true1095, label %varying.coherent.false1096

convergence.overflow.trap1091:                    ; preds = %varying.divergent1089
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1092:                  ; preds = %varying.divergent1089
  %6813 = call i8 @llvm.cttz.i8(i8 %6809, i1 false)
  %6814 = zext i8 %6813 to i32
  %6815 = select i1 %6810, i32 %6814, i32 0
  %6816 = trunc i32 %6815 to i8
  %6817 = shl i8 1, %6816
  %6818 = or i8 %6797, %6817
  %6819 = select i1 %6808, i8 %6818, i8 %6797
  store i8 %6819, ptr %frame.active, align 1
  %6820 = load <8 x i32>, ptr %frame.static.id, align 32
  %6821 = extractelement <8 x i32> %6820, i32 %6815
  %6822 = select i1 %6808, i32 14, i32 %6821
  %6823 = load <8 x i32>, ptr %frame.static.id, align 32
  %6824 = insertelement <8 x i32> %6823, i32 %6822, i32 %6815
  store <8 x i32> %6824, ptr %frame.static.id, align 32
  %6825 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6826 = extractelement <8 x i32> %6825, i32 %6815
  %6827 = select i1 %6808, i32 %6793, i32 %6826
  %6828 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6829 = insertelement <8 x i32> %6828, i32 %6827, i32 %6815
  store <8 x i32> %6829, ptr %frame.parent.token, align 32
  %6830 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6815
  %6831 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6815
  %6832 = load <8 x i1>, ptr %6830, align 1
  %6833 = load <8 x i1>, ptr %6831, align 1
  %6834 = select i1 %6808, <8 x i1> %692, <8 x i1> %6832
  store <8 x i1> %6834, ptr %6830, align 1
  %6835 = select i1 %6808, <8 x i1> zeroinitializer, <8 x i1> %6833
  store <8 x i1> %6835, ptr %6831, align 1
  %6836 = add i32 %6815, 1
  %6837 = select i1 %6806, i32 %6793, i32 %6836
  %6838 = select i1 true, i32 %6837, i32 %6793
  store i32 %6838, ptr %current.token, align 4
  %6839 = load i32, ptr %current.token, align 4
  %6840 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %699)
  %6841 = load i32, ptr %ready.count, align 4
  %6842 = icmp uge i32 %6841, 8
  %6843 = and i1 %6840, %6842
  br i1 %6843, label %ready.overflow.trap1093, label %ready.overflow.resume1094

ready.overflow.trap1093:                          ; preds = %convergence.overflow.resume1092
  call void @llvm.trap()
  unreachable

ready.overflow.resume1094:                        ; preds = %convergence.overflow.resume1092
  %6844 = select i1 %6840, i32 %6841, i32 0
  %6845 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6844
  %6846 = load <8 x i1>, ptr %6845, align 1
  %6847 = select i1 %6840, <8 x i1> %699, <8 x i1> %6846
  store <8 x i1> %6847, ptr %6845, align 1
  %6848 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6844
  %6849 = load i32, ptr %6848, align 4
  %6850 = select i1 %6840, i32 40, i32 %6849
  store i32 %6850, ptr %6848, align 4
  %6851 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6844
  %6852 = load i32, ptr %6851, align 4
  %6853 = select i1 %6840, i32 %6839, i32 %6852
  store i32 %6853, ptr %6851, align 4
  %6854 = add i32 %6841, 1
  %6855 = select i1 %6840, i32 %6854, i32 %6841
  store i32 %6855, ptr %ready.count, align 4
  %6856 = load <8 x i1>, ptr %runnable.mask, align 1
  %6857 = or <8 x i1> %6856, %699
  store <8 x i1> %6857, ptr %runnable.mask, align 1
  store <8 x i1> %701, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1095:                        ; preds = %varying.coherent1090
  store <8 x i1> %692, ptr %current.mask, align 1
  %6858 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %692)
  br i1 %6858, label %schedule.40, label %scheduler.loop

varying.coherent.false1096:                       ; preds = %varying.coherent1090
  store <8 x i1> %692, ptr %current.mask, align 1
  %6859 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %692)
  br i1 %6859, label %schedule.41, label %scheduler.loop

convergence.cascade1102:                          ; preds = %convergence.cascade1102, %schedule.41
  %convergence.cascade.flow1106 = phi <8 x i1> [ %734, %schedule.41 ], [ %6902, %convergence.cascade1102 ]
  %convergence.cascade.depth1107 = phi i32 [ 0, %schedule.41 ], [ %6903, %convergence.cascade1102 ]
  %6860 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1106)
  %6861 = load i32, ptr %current.token, align 4
  %6862 = icmp ne i32 %6861, 0
  %6863 = and i1 %6860, %6862
  %6864 = sub i32 %6861, 1
  %6865 = select i1 %6863, i32 %6864, i32 0
  %6866 = load i8, ptr %frame.active, align 1
  %6867 = trunc i32 %6865 to i8
  %6868 = shl i8 1, %6867
  %6869 = and i8 %6866, %6868
  %6870 = icmp ne i8 %6869, 0
  %6871 = load <8 x i32>, ptr %frame.static.id, align 32
  %6872 = extractelement <8 x i32> %6871, i32 %6865
  %convergence.target.pointer1108 = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %6872
  %convergence.dynamic.target1109 = load i32, ptr %convergence.target.pointer1108, align 4
  %6873 = icmp eq i32 %convergence.dynamic.target1109, 41
  %6874 = and i1 %6870, %6873
  %6875 = and i1 %6863, %6874
  %6876 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6865
  %6877 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6865
  %6878 = load <8 x i1>, ptr %6876, align 1
  %6879 = load <8 x i1>, ptr %6877, align 1
  %6880 = or <8 x i1> %6879, %convergence.cascade.flow1106
  %6881 = load <8 x i1>, ptr %live.mask, align 1
  %6882 = and <8 x i1> %6878, %6881
  %6883 = icmp eq <8 x i1> %6880, %6882
  %6884 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6883)
  %6885 = and i1 %6875, %6884
  %6886 = select i1 %6885, <8 x i1> zeroinitializer, <8 x i1> %6880
  %6887 = select i1 %6875, <8 x i1> %6886, <8 x i1> %6879
  store <8 x i1> %6887, ptr %6877, align 1
  %6888 = select i1 %6885, <8 x i1> zeroinitializer, <8 x i1> %6878
  store <8 x i1> %6888, ptr %6876, align 1
  %6889 = trunc i32 %6865 to i8
  %6890 = shl i8 1, %6889
  %6891 = xor i8 %6890, -1
  %6892 = and i8 %6866, %6891
  %6893 = select i1 %6885, i8 %6892, i8 %6866
  store i8 %6893, ptr %frame.active, align 1
  %.splatinsert1110 = insertelement <8 x i1> poison, i1 %6875, i64 0
  %.splat1111 = shufflevector <8 x i1> %.splatinsert1110, <8 x i1> poison, <8 x i32> zeroinitializer
  %6894 = and <8 x i1> %convergence.cascade.flow1106, %.splat1111
  %6895 = load <8 x i1>, ptr %runnable.mask, align 1
  %6896 = xor <8 x i1> %6894, splat (i1 true)
  %6897 = and <8 x i1> %6895, %6896
  store <8 x i1> %6897, ptr %runnable.mask, align 1
  %.splatinsert1112 = insertelement <8 x i1> poison, i1 %6885, i64 0
  %.splat1113 = shufflevector <8 x i1> %.splatinsert1112, <8 x i1> poison, <8 x i32> zeroinitializer
  %6898 = select <8 x i1> %.splat1113, <8 x i1> %6880, <8 x i1> zeroinitializer
  %6899 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6900 = extractelement <8 x i32> %6899, i32 %6865
  %6901 = select i1 %6885, i32 %6900, i32 %6861
  store i32 %6901, ptr %current.token, align 4
  %.splatinsert1114 = insertelement <8 x i1> poison, i1 %6875, i64 0
  %.splat1115 = shufflevector <8 x i1> %.splatinsert1114, <8 x i1> poison, <8 x i32> zeroinitializer
  %6902 = select <8 x i1> %.splat1115, <8 x i1> %6898, <8 x i1> %convergence.cascade.flow1106
  %6903 = add i32 %convergence.cascade.depth1107, 1
  %6904 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6902)
  %6905 = icmp ult i32 %6903, 8
  %6906 = and i1 %6904, %6905
  %6907 = and i1 %6875, %6906
  %convergence.parent.token1116 = load i32, ptr %current.token, align 4
  %convergence.parent.present1117 = icmp ne i32 %convergence.parent.token1116, 0
  %6908 = and i1 %6907, %convergence.parent.present1117
  br i1 %6908, label %convergence.cascade1102, label %convergence.cascade.exit1103

convergence.cascade.exit1103:                     ; preds = %convergence.cascade1102, %schedule.41
  %convergence.cascade.result1118 = phi <8 x i1> [ %734, %schedule.41 ], [ %6902, %convergence.cascade1102 ]
  %6909 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1118)
  br i1 %6909, label %convergence.target.41.ready, label %scheduler.loop

convergence.target.41.ready:                      ; preds = %convergence.cascade.exit1103
  %6910 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1118)
  %6911 = bitcast <8 x i1> %convergence.cascade.result1118 to i8
  %6912 = call i8 @llvm.cttz.i8(i8 %6911, i1 false)
  %6913 = zext i8 %6912 to i32
  %6914 = select i1 %6910, i32 %6913, i32 0
  %6915 = load <8 x i64>, ptr %.slot230, align 64
  %6916 = select <8 x i1> %convergence.cascade.result1118, <8 x i64> zeroinitializer, <8 x i64> %6915
  store <8 x i64> %6916, ptr %.slot230, align 64
  store <8 x i1> %convergence.cascade.result1118, ptr %current.mask, align 1
  %6917 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1118)
  br i1 %6917, label %schedule.42, label %scheduler.loop

varying.divergent1120:                            ; preds = %schedule.42
  %6918 = load i32, ptr %current.token, align 4
  %6919 = icmp ne i32 %6918, 0
  %6920 = sub i32 %6918, 1
  %6921 = select i1 %6919, i32 %6920, i32 0
  %6922 = load i8, ptr %frame.active, align 1
  %6923 = trunc i32 %6921 to i8
  %6924 = shl i8 1, %6923
  %6925 = and i8 %6922, %6924
  %6926 = icmp ne i8 %6925, 0
  %6927 = load <8 x i32>, ptr %frame.static.id, align 32
  %6928 = extractelement <8 x i32> %6927, i32 %6921
  %6929 = icmp eq i32 %6928, 15
  %6930 = and i1 %6926, %6929
  %6931 = and i1 %6919, %6930
  %6932 = xor i1 %6931, true
  %6933 = and i1 true, %6932
  %6934 = xor i8 %6922, -1
  %6935 = icmp ne i8 %6934, 0
  %6936 = xor i1 %6935, true
  %6937 = and i1 %6933, %6936
  br i1 %6937, label %convergence.overflow.trap1122, label %convergence.overflow.resume1123

varying.coherent1121:                             ; preds = %schedule.42
  br i1 %745, label %varying.coherent.true1126, label %varying.coherent.false1127

convergence.overflow.trap1122:                    ; preds = %varying.divergent1120
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1123:                  ; preds = %varying.divergent1120
  %6938 = call i8 @llvm.cttz.i8(i8 %6934, i1 false)
  %6939 = zext i8 %6938 to i32
  %6940 = select i1 %6935, i32 %6939, i32 0
  %6941 = trunc i32 %6940 to i8
  %6942 = shl i8 1, %6941
  %6943 = or i8 %6922, %6942
  %6944 = select i1 %6933, i8 %6943, i8 %6922
  store i8 %6944, ptr %frame.active, align 1
  %6945 = load <8 x i32>, ptr %frame.static.id, align 32
  %6946 = extractelement <8 x i32> %6945, i32 %6940
  %6947 = select i1 %6933, i32 15, i32 %6946
  %6948 = load <8 x i32>, ptr %frame.static.id, align 32
  %6949 = insertelement <8 x i32> %6948, i32 %6947, i32 %6940
  store <8 x i32> %6949, ptr %frame.static.id, align 32
  %6950 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6951 = extractelement <8 x i32> %6950, i32 %6940
  %6952 = select i1 %6933, i32 %6918, i32 %6951
  %6953 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6954 = insertelement <8 x i32> %6953, i32 %6952, i32 %6940
  store <8 x i32> %6954, ptr %frame.parent.token, align 32
  %6955 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6940
  %6956 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6940
  %6957 = load <8 x i1>, ptr %6955, align 1
  %6958 = load <8 x i1>, ptr %6956, align 1
  %6959 = select i1 %6933, <8 x i1> %735, <8 x i1> %6957
  store <8 x i1> %6959, ptr %6955, align 1
  %6960 = select i1 %6933, <8 x i1> zeroinitializer, <8 x i1> %6958
  store <8 x i1> %6960, ptr %6956, align 1
  %6961 = add i32 %6940, 1
  %6962 = select i1 %6931, i32 %6918, i32 %6961
  %6963 = select i1 true, i32 %6962, i32 %6918
  store i32 %6963, ptr %current.token, align 4
  %6964 = load i32, ptr %current.token, align 4
  %6965 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %742)
  %6966 = load i32, ptr %ready.count, align 4
  %6967 = icmp uge i32 %6966, 8
  %6968 = and i1 %6965, %6967
  br i1 %6968, label %ready.overflow.trap1124, label %ready.overflow.resume1125

ready.overflow.trap1124:                          ; preds = %convergence.overflow.resume1123
  call void @llvm.trap()
  unreachable

ready.overflow.resume1125:                        ; preds = %convergence.overflow.resume1123
  %6969 = select i1 %6965, i32 %6966, i32 0
  %6970 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6969
  %6971 = load <8 x i1>, ptr %6970, align 1
  %6972 = select i1 %6965, <8 x i1> %742, <8 x i1> %6971
  store <8 x i1> %6972, ptr %6970, align 1
  %6973 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6969
  %6974 = load i32, ptr %6973, align 4
  %6975 = select i1 %6965, i32 43, i32 %6974
  store i32 %6975, ptr %6973, align 4
  %6976 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6969
  %6977 = load i32, ptr %6976, align 4
  %6978 = select i1 %6965, i32 %6964, i32 %6977
  store i32 %6978, ptr %6976, align 4
  %6979 = add i32 %6966, 1
  %6980 = select i1 %6965, i32 %6979, i32 %6966
  store i32 %6980, ptr %ready.count, align 4
  %6981 = load <8 x i1>, ptr %runnable.mask, align 1
  %6982 = or <8 x i1> %6981, %742
  store <8 x i1> %6982, ptr %runnable.mask, align 1
  store <8 x i1> %744, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1126:                        ; preds = %varying.coherent1121
  store <8 x i1> %735, ptr %current.mask, align 1
  %6983 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %735)
  br i1 %6983, label %schedule.43, label %scheduler.loop

varying.coherent.false1127:                       ; preds = %varying.coherent1121
  store <8 x i1> %735, ptr %current.mask, align 1
  %6984 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %735)
  br i1 %6984, label %schedule.44, label %scheduler.loop

convergence.cascade1133:                          ; preds = %convergence.cascade1133, %schedule.44
  %convergence.cascade.flow1137 = phi <8 x i1> [ %777, %schedule.44 ], [ %7027, %convergence.cascade1133 ]
  %convergence.cascade.depth1138 = phi i32 [ 0, %schedule.44 ], [ %7028, %convergence.cascade1133 ]
  %6985 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1137)
  %6986 = load i32, ptr %current.token, align 4
  %6987 = icmp ne i32 %6986, 0
  %6988 = and i1 %6985, %6987
  %6989 = sub i32 %6986, 1
  %6990 = select i1 %6988, i32 %6989, i32 0
  %6991 = load i8, ptr %frame.active, align 1
  %6992 = trunc i32 %6990 to i8
  %6993 = shl i8 1, %6992
  %6994 = and i8 %6991, %6993
  %6995 = icmp ne i8 %6994, 0
  %6996 = load <8 x i32>, ptr %frame.static.id, align 32
  %6997 = extractelement <8 x i32> %6996, i32 %6990
  %convergence.target.pointer1139 = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %6997
  %convergence.dynamic.target1140 = load i32, ptr %convergence.target.pointer1139, align 4
  %6998 = icmp eq i32 %convergence.dynamic.target1140, 44
  %6999 = and i1 %6995, %6998
  %7000 = and i1 %6988, %6999
  %7001 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6990
  %7002 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6990
  %7003 = load <8 x i1>, ptr %7001, align 1
  %7004 = load <8 x i1>, ptr %7002, align 1
  %7005 = or <8 x i1> %7004, %convergence.cascade.flow1137
  %7006 = load <8 x i1>, ptr %live.mask, align 1
  %7007 = and <8 x i1> %7003, %7006
  %7008 = icmp eq <8 x i1> %7005, %7007
  %7009 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7008)
  %7010 = and i1 %7000, %7009
  %7011 = select i1 %7010, <8 x i1> zeroinitializer, <8 x i1> %7005
  %7012 = select i1 %7000, <8 x i1> %7011, <8 x i1> %7004
  store <8 x i1> %7012, ptr %7002, align 1
  %7013 = select i1 %7010, <8 x i1> zeroinitializer, <8 x i1> %7003
  store <8 x i1> %7013, ptr %7001, align 1
  %7014 = trunc i32 %6990 to i8
  %7015 = shl i8 1, %7014
  %7016 = xor i8 %7015, -1
  %7017 = and i8 %6991, %7016
  %7018 = select i1 %7010, i8 %7017, i8 %6991
  store i8 %7018, ptr %frame.active, align 1
  %.splatinsert1141 = insertelement <8 x i1> poison, i1 %7000, i64 0
  %.splat1142 = shufflevector <8 x i1> %.splatinsert1141, <8 x i1> poison, <8 x i32> zeroinitializer
  %7019 = and <8 x i1> %convergence.cascade.flow1137, %.splat1142
  %7020 = load <8 x i1>, ptr %runnable.mask, align 1
  %7021 = xor <8 x i1> %7019, splat (i1 true)
  %7022 = and <8 x i1> %7020, %7021
  store <8 x i1> %7022, ptr %runnable.mask, align 1
  %.splatinsert1143 = insertelement <8 x i1> poison, i1 %7010, i64 0
  %.splat1144 = shufflevector <8 x i1> %.splatinsert1143, <8 x i1> poison, <8 x i32> zeroinitializer
  %7023 = select <8 x i1> %.splat1144, <8 x i1> %7005, <8 x i1> zeroinitializer
  %7024 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7025 = extractelement <8 x i32> %7024, i32 %6990
  %7026 = select i1 %7010, i32 %7025, i32 %6986
  store i32 %7026, ptr %current.token, align 4
  %.splatinsert1145 = insertelement <8 x i1> poison, i1 %7000, i64 0
  %.splat1146 = shufflevector <8 x i1> %.splatinsert1145, <8 x i1> poison, <8 x i32> zeroinitializer
  %7027 = select <8 x i1> %.splat1146, <8 x i1> %7023, <8 x i1> %convergence.cascade.flow1137
  %7028 = add i32 %convergence.cascade.depth1138, 1
  %7029 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7027)
  %7030 = icmp ult i32 %7028, 8
  %7031 = and i1 %7029, %7030
  %7032 = and i1 %7000, %7031
  %convergence.parent.token1147 = load i32, ptr %current.token, align 4
  %convergence.parent.present1148 = icmp ne i32 %convergence.parent.token1147, 0
  %7033 = and i1 %7032, %convergence.parent.present1148
  br i1 %7033, label %convergence.cascade1133, label %convergence.cascade.exit1134

convergence.cascade.exit1134:                     ; preds = %convergence.cascade1133, %schedule.44
  %convergence.cascade.result1149 = phi <8 x i1> [ %777, %schedule.44 ], [ %7027, %convergence.cascade1133 ]
  %7034 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1149)
  br i1 %7034, label %convergence.target.44.ready, label %scheduler.loop

convergence.target.44.ready:                      ; preds = %convergence.cascade.exit1134
  %7035 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1149)
  %7036 = bitcast <8 x i1> %convergence.cascade.result1149 to i8
  %7037 = call i8 @llvm.cttz.i8(i8 %7036, i1 false)
  %7038 = zext i8 %7037 to i32
  %7039 = select i1 %7035, i32 %7038, i32 0
  %.state1150 = load <8 x i64>, ptr %.slot54, align 64
  %7040 = add <8 x i64> %.state1150, splat (i64 1)
  %.spill.load1151 = load volatile <8 x float>, ptr %.spill204, align 32
  %.spill.load1152 = load volatile <8 x float>, ptr %.spill205, align 32
  %.spill.load1153 = load volatile <8 x float>, ptr %.spill206, align 32
  %.spill.load1154 = load volatile <8 x float>, ptr %.spill207, align 32
  %.spill.load1155 = load volatile <8 x float>, ptr %.spill222, align 32
  %.spill.load1156 = load volatile <8 x float>, ptr %.spill223, align 32
  %.spill.load1157 = load volatile <8 x float>, ptr %.spill224, align 32
  %.spill.load1158 = load volatile <8 x float>, ptr %.spill225, align 32
  %7041 = load <8 x i64>, ptr %.slot54, align 64
  %7042 = select <8 x i1> %convergence.cascade.result1149, <8 x i64> %7040, <8 x i64> %7041
  store <8 x i64> %7042, ptr %.slot54, align 64
  %7043 = load <8 x float>, ptr %.slot55, align 32
  %7044 = select <8 x i1> %convergence.cascade.result1149, <8 x float> %.spill.load1151, <8 x float> %7043
  store <8 x float> %7044, ptr %.slot55, align 32
  %7045 = load <8 x float>, ptr %.slot56, align 32
  %7046 = select <8 x i1> %convergence.cascade.result1149, <8 x float> %.spill.load1152, <8 x float> %7045
  store <8 x float> %7046, ptr %.slot56, align 32
  %7047 = load <8 x float>, ptr %.slot57, align 32
  %7048 = select <8 x i1> %convergence.cascade.result1149, <8 x float> %.spill.load1153, <8 x float> %7047
  store <8 x float> %7048, ptr %.slot57, align 32
  %7049 = load <8 x float>, ptr %.slot58, align 32
  %7050 = select <8 x i1> %convergence.cascade.result1149, <8 x float> %.spill.load1154, <8 x float> %7049
  store <8 x float> %7050, ptr %.slot58, align 32
  %7051 = load <8 x float>, ptr %.slot59, align 32
  %7052 = select <8 x i1> %convergence.cascade.result1149, <8 x float> %.spill.load1155, <8 x float> %7051
  store <8 x float> %7052, ptr %.slot59, align 32
  %7053 = load <8 x float>, ptr %.slot60, align 32
  %7054 = select <8 x i1> %convergence.cascade.result1149, <8 x float> %.spill.load1156, <8 x float> %7053
  store <8 x float> %7054, ptr %.slot60, align 32
  %7055 = load <8 x float>, ptr %.slot61, align 32
  %7056 = select <8 x i1> %convergence.cascade.result1149, <8 x float> %.spill.load1157, <8 x float> %7055
  store <8 x float> %7056, ptr %.slot61, align 32
  %7057 = load <8 x float>, ptr %.slot62, align 32
  %7058 = select <8 x i1> %convergence.cascade.result1149, <8 x float> %.spill.load1158, <8 x float> %7057
  store <8 x float> %7058, ptr %.slot62, align 32
  store <8 x i1> %convergence.cascade.result1149, ptr %current.mask, align 1
  %7059 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1149)
  br i1 %7059, label %schedule.6, label %scheduler.loop

varying.divergent1160:                            ; preds = %schedule.46
  %7060 = load i32, ptr %current.token, align 4
  %7061 = icmp ne i32 %7060, 0
  %7062 = sub i32 %7060, 1
  %7063 = select i1 %7061, i32 %7062, i32 0
  %7064 = load i8, ptr %frame.active, align 1
  %7065 = trunc i32 %7063 to i8
  %7066 = shl i8 1, %7065
  %7067 = and i8 %7064, %7066
  %7068 = icmp ne i8 %7067, 0
  %7069 = load <8 x i32>, ptr %frame.static.id, align 32
  %7070 = extractelement <8 x i32> %7069, i32 %7063
  %7071 = icmp eq i32 %7070, 16
  %7072 = and i1 %7068, %7071
  %7073 = and i1 %7061, %7072
  %7074 = xor i1 %7073, true
  %7075 = and i1 true, %7074
  %7076 = xor i8 %7064, -1
  %7077 = icmp ne i8 %7076, 0
  %7078 = xor i1 %7077, true
  %7079 = and i1 %7075, %7078
  br i1 %7079, label %convergence.overflow.trap1162, label %convergence.overflow.resume1163

varying.coherent1161:                             ; preds = %schedule.46
  br i1 %797, label %varying.coherent.true1166, label %varying.coherent.false1167

convergence.overflow.trap1162:                    ; preds = %varying.divergent1160
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1163:                  ; preds = %varying.divergent1160
  %7080 = call i8 @llvm.cttz.i8(i8 %7076, i1 false)
  %7081 = zext i8 %7080 to i32
  %7082 = select i1 %7077, i32 %7081, i32 0
  %7083 = trunc i32 %7082 to i8
  %7084 = shl i8 1, %7083
  %7085 = or i8 %7064, %7084
  %7086 = select i1 %7075, i8 %7085, i8 %7064
  store i8 %7086, ptr %frame.active, align 1
  %7087 = load <8 x i32>, ptr %frame.static.id, align 32
  %7088 = extractelement <8 x i32> %7087, i32 %7082
  %7089 = select i1 %7075, i32 16, i32 %7088
  %7090 = load <8 x i32>, ptr %frame.static.id, align 32
  %7091 = insertelement <8 x i32> %7090, i32 %7089, i32 %7082
  store <8 x i32> %7091, ptr %frame.static.id, align 32
  %7092 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7093 = extractelement <8 x i32> %7092, i32 %7082
  %7094 = select i1 %7075, i32 %7060, i32 %7093
  %7095 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7096 = insertelement <8 x i32> %7095, i32 %7094, i32 %7082
  store <8 x i32> %7096, ptr %frame.parent.token, align 32
  %7097 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7082
  %7098 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7082
  %7099 = load <8 x i1>, ptr %7097, align 1
  %7100 = load <8 x i1>, ptr %7098, align 1
  %7101 = select i1 %7075, <8 x i1> %787, <8 x i1> %7099
  store <8 x i1> %7101, ptr %7097, align 1
  %7102 = select i1 %7075, <8 x i1> zeroinitializer, <8 x i1> %7100
  store <8 x i1> %7102, ptr %7098, align 1
  %7103 = add i32 %7082, 1
  %7104 = select i1 %7073, i32 %7060, i32 %7103
  %7105 = select i1 true, i32 %7104, i32 %7060
  store i32 %7105, ptr %current.token, align 4
  %7106 = load i32, ptr %current.token, align 4
  %7107 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %794)
  %7108 = load i32, ptr %ready.count, align 4
  %7109 = icmp uge i32 %7108, 8
  %7110 = and i1 %7107, %7109
  br i1 %7110, label %ready.overflow.trap1164, label %ready.overflow.resume1165

ready.overflow.trap1164:                          ; preds = %convergence.overflow.resume1163
  call void @llvm.trap()
  unreachable

ready.overflow.resume1165:                        ; preds = %convergence.overflow.resume1163
  %7111 = select i1 %7107, i32 %7108, i32 0
  %7112 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7111
  %7113 = load <8 x i1>, ptr %7112, align 1
  %7114 = select i1 %7107, <8 x i1> %794, <8 x i1> %7113
  store <8 x i1> %7114, ptr %7112, align 1
  %7115 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7111
  %7116 = load i32, ptr %7115, align 4
  %7117 = select i1 %7107, i32 47, i32 %7116
  store i32 %7117, ptr %7115, align 4
  %7118 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7111
  %7119 = load i32, ptr %7118, align 4
  %7120 = select i1 %7107, i32 %7106, i32 %7119
  store i32 %7120, ptr %7118, align 4
  %7121 = add i32 %7108, 1
  %7122 = select i1 %7107, i32 %7121, i32 %7108
  store i32 %7122, ptr %ready.count, align 4
  %7123 = load <8 x i1>, ptr %runnable.mask, align 1
  %7124 = or <8 x i1> %7123, %794
  store <8 x i1> %7124, ptr %runnable.mask, align 1
  store <8 x i1> %796, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1166:                        ; preds = %varying.coherent1161
  store <8 x i1> %787, ptr %current.mask, align 1
  %7125 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %787)
  br i1 %7125, label %schedule.47, label %scheduler.loop

varying.coherent.false1167:                       ; preds = %varying.coherent1161
  store <8 x i1> %787, ptr %current.mask, align 1
  %7126 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %787)
  br i1 %7126, label %schedule.11, label %scheduler.loop

varying.divergent1173:                            ; preds = %schedule.47
  %7127 = load i32, ptr %current.token, align 4
  %7128 = icmp ne i32 %7127, 0
  %7129 = sub i32 %7127, 1
  %7130 = select i1 %7128, i32 %7129, i32 0
  %7131 = load i8, ptr %frame.active, align 1
  %7132 = trunc i32 %7130 to i8
  %7133 = shl i8 1, %7132
  %7134 = and i8 %7131, %7133
  %7135 = icmp ne i8 %7134, 0
  %7136 = load <8 x i32>, ptr %frame.static.id, align 32
  %7137 = extractelement <8 x i32> %7136, i32 %7130
  %7138 = icmp eq i32 %7137, 17
  %7139 = and i1 %7135, %7138
  %7140 = and i1 %7128, %7139
  %7141 = xor i1 %7140, true
  %7142 = and i1 true, %7141
  %7143 = xor i8 %7131, -1
  %7144 = icmp ne i8 %7143, 0
  %7145 = xor i1 %7144, true
  %7146 = and i1 %7142, %7145
  br i1 %7146, label %convergence.overflow.trap1175, label %convergence.overflow.resume1176

varying.coherent1174:                             ; preds = %schedule.47
  br i1 %832, label %varying.coherent.true1179, label %varying.coherent.false1180

convergence.overflow.trap1175:                    ; preds = %varying.divergent1173
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1176:                  ; preds = %varying.divergent1173
  %7147 = call i8 @llvm.cttz.i8(i8 %7143, i1 false)
  %7148 = zext i8 %7147 to i32
  %7149 = select i1 %7144, i32 %7148, i32 0
  %7150 = trunc i32 %7149 to i8
  %7151 = shl i8 1, %7150
  %7152 = or i8 %7131, %7151
  %7153 = select i1 %7142, i8 %7152, i8 %7131
  store i8 %7153, ptr %frame.active, align 1
  %7154 = load <8 x i32>, ptr %frame.static.id, align 32
  %7155 = extractelement <8 x i32> %7154, i32 %7149
  %7156 = select i1 %7142, i32 17, i32 %7155
  %7157 = load <8 x i32>, ptr %frame.static.id, align 32
  %7158 = insertelement <8 x i32> %7157, i32 %7156, i32 %7149
  store <8 x i32> %7158, ptr %frame.static.id, align 32
  %7159 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7160 = extractelement <8 x i32> %7159, i32 %7149
  %7161 = select i1 %7142, i32 %7127, i32 %7160
  %7162 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7163 = insertelement <8 x i32> %7162, i32 %7161, i32 %7149
  store <8 x i32> %7163, ptr %frame.parent.token, align 32
  %7164 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7149
  %7165 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7149
  %7166 = load <8 x i1>, ptr %7164, align 1
  %7167 = load <8 x i1>, ptr %7165, align 1
  %7168 = select i1 %7142, <8 x i1> %800, <8 x i1> %7166
  store <8 x i1> %7168, ptr %7164, align 1
  %7169 = select i1 %7142, <8 x i1> zeroinitializer, <8 x i1> %7167
  store <8 x i1> %7169, ptr %7165, align 1
  %7170 = add i32 %7149, 1
  %7171 = select i1 %7140, i32 %7127, i32 %7170
  %7172 = select i1 true, i32 %7171, i32 %7127
  store i32 %7172, ptr %current.token, align 4
  %7173 = load <8 x float>, ptr %.slot233, align 32
  %7174 = select <8 x i1> %831, <8 x float> zeroinitializer, <8 x float> %7173
  store <8 x float> %7174, ptr %.slot233, align 32
  %7175 = load i32, ptr %current.token, align 4
  %7176 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %829)
  %7177 = load i32, ptr %ready.count, align 4
  %7178 = icmp uge i32 %7177, 8
  %7179 = and i1 %7176, %7178
  br i1 %7179, label %ready.overflow.trap1177, label %ready.overflow.resume1178

ready.overflow.trap1177:                          ; preds = %convergence.overflow.resume1176
  call void @llvm.trap()
  unreachable

ready.overflow.resume1178:                        ; preds = %convergence.overflow.resume1176
  %7180 = select i1 %7176, i32 %7177, i32 0
  %7181 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7180
  %7182 = load <8 x i1>, ptr %7181, align 1
  %7183 = select i1 %7176, <8 x i1> %829, <8 x i1> %7182
  store <8 x i1> %7183, ptr %7181, align 1
  %7184 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7180
  %7185 = load i32, ptr %7184, align 4
  %7186 = select i1 %7176, i32 48, i32 %7185
  store i32 %7186, ptr %7184, align 4
  %7187 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7180
  %7188 = load i32, ptr %7187, align 4
  %7189 = select i1 %7176, i32 %7175, i32 %7188
  store i32 %7189, ptr %7187, align 4
  %7190 = add i32 %7177, 1
  %7191 = select i1 %7176, i32 %7190, i32 %7177
  store i32 %7191, ptr %ready.count, align 4
  %7192 = load <8 x i1>, ptr %runnable.mask, align 1
  %7193 = or <8 x i1> %7192, %829
  store <8 x i1> %7193, ptr %runnable.mask, align 1
  store <8 x i1> %831, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1179:                        ; preds = %varying.coherent1174
  store <8 x i1> %800, ptr %current.mask, align 1
  %7194 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %800)
  br i1 %7194, label %schedule.48, label %scheduler.loop

varying.coherent.false1180:                       ; preds = %varying.coherent1174
  %7195 = load <8 x float>, ptr %.slot233, align 32
  %7196 = select <8 x i1> %800, <8 x float> zeroinitializer, <8 x float> %7195
  store <8 x float> %7196, ptr %.slot233, align 32
  store <8 x i1> %800, ptr %current.mask, align 1
  %7197 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %800)
  br i1 %7197, label %schedule.49, label %scheduler.loop

convergence.cascade1182:                          ; preds = %convergence.cascade1182, %schedule.49
  %convergence.cascade.flow1186 = phi <8 x i1> [ %848, %schedule.49 ], [ %7240, %convergence.cascade1182 ]
  %convergence.cascade.depth1187 = phi i32 [ 0, %schedule.49 ], [ %7241, %convergence.cascade1182 ]
  %7198 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1186)
  %7199 = load i32, ptr %current.token, align 4
  %7200 = icmp ne i32 %7199, 0
  %7201 = and i1 %7198, %7200
  %7202 = sub i32 %7199, 1
  %7203 = select i1 %7201, i32 %7202, i32 0
  %7204 = load i8, ptr %frame.active, align 1
  %7205 = trunc i32 %7203 to i8
  %7206 = shl i8 1, %7205
  %7207 = and i8 %7204, %7206
  %7208 = icmp ne i8 %7207, 0
  %7209 = load <8 x i32>, ptr %frame.static.id, align 32
  %7210 = extractelement <8 x i32> %7209, i32 %7203
  %convergence.target.pointer1188 = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %7210
  %convergence.dynamic.target1189 = load i32, ptr %convergence.target.pointer1188, align 4
  %7211 = icmp eq i32 %convergence.dynamic.target1189, 49
  %7212 = and i1 %7208, %7211
  %7213 = and i1 %7201, %7212
  %7214 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7203
  %7215 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7203
  %7216 = load <8 x i1>, ptr %7214, align 1
  %7217 = load <8 x i1>, ptr %7215, align 1
  %7218 = or <8 x i1> %7217, %convergence.cascade.flow1186
  %7219 = load <8 x i1>, ptr %live.mask, align 1
  %7220 = and <8 x i1> %7216, %7219
  %7221 = icmp eq <8 x i1> %7218, %7220
  %7222 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7221)
  %7223 = and i1 %7213, %7222
  %7224 = select i1 %7223, <8 x i1> zeroinitializer, <8 x i1> %7218
  %7225 = select i1 %7213, <8 x i1> %7224, <8 x i1> %7217
  store <8 x i1> %7225, ptr %7215, align 1
  %7226 = select i1 %7223, <8 x i1> zeroinitializer, <8 x i1> %7216
  store <8 x i1> %7226, ptr %7214, align 1
  %7227 = trunc i32 %7203 to i8
  %7228 = shl i8 1, %7227
  %7229 = xor i8 %7228, -1
  %7230 = and i8 %7204, %7229
  %7231 = select i1 %7223, i8 %7230, i8 %7204
  store i8 %7231, ptr %frame.active, align 1
  %.splatinsert1190 = insertelement <8 x i1> poison, i1 %7213, i64 0
  %.splat1191 = shufflevector <8 x i1> %.splatinsert1190, <8 x i1> poison, <8 x i32> zeroinitializer
  %7232 = and <8 x i1> %convergence.cascade.flow1186, %.splat1191
  %7233 = load <8 x i1>, ptr %runnable.mask, align 1
  %7234 = xor <8 x i1> %7232, splat (i1 true)
  %7235 = and <8 x i1> %7233, %7234
  store <8 x i1> %7235, ptr %runnable.mask, align 1
  %.splatinsert1192 = insertelement <8 x i1> poison, i1 %7223, i64 0
  %.splat1193 = shufflevector <8 x i1> %.splatinsert1192, <8 x i1> poison, <8 x i32> zeroinitializer
  %7236 = select <8 x i1> %.splat1193, <8 x i1> %7218, <8 x i1> zeroinitializer
  %7237 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7238 = extractelement <8 x i32> %7237, i32 %7203
  %7239 = select i1 %7223, i32 %7238, i32 %7199
  store i32 %7239, ptr %current.token, align 4
  %.splatinsert1194 = insertelement <8 x i1> poison, i1 %7213, i64 0
  %.splat1195 = shufflevector <8 x i1> %.splatinsert1194, <8 x i1> poison, <8 x i32> zeroinitializer
  %7240 = select <8 x i1> %.splat1195, <8 x i1> %7236, <8 x i1> %convergence.cascade.flow1186
  %7241 = add i32 %convergence.cascade.depth1187, 1
  %7242 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7240)
  %7243 = icmp ult i32 %7241, 8
  %7244 = and i1 %7242, %7243
  %7245 = and i1 %7213, %7244
  %convergence.parent.token1196 = load i32, ptr %current.token, align 4
  %convergence.parent.present1197 = icmp ne i32 %convergence.parent.token1196, 0
  %7246 = and i1 %7245, %convergence.parent.present1197
  br i1 %7246, label %convergence.cascade1182, label %convergence.cascade.exit1183

convergence.cascade.exit1183:                     ; preds = %convergence.cascade1182, %schedule.49
  %convergence.cascade.result1198 = phi <8 x i1> [ %848, %schedule.49 ], [ %7240, %convergence.cascade1182 ]
  %7247 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1198)
  br i1 %7247, label %convergence.target.49.ready, label %scheduler.loop

convergence.target.49.ready:                      ; preds = %convergence.cascade.exit1183
  %7248 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1198)
  %7249 = bitcast <8 x i1> %convergence.cascade.result1198 to i8
  %7250 = call i8 @llvm.cttz.i8(i8 %7249, i1 false)
  %7251 = zext i8 %7250 to i32
  %7252 = select i1 %7248, i32 %7251, i32 0
  %tile_snapshot.spill.load1199 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill66, align 64
  %7253 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1199, 0
  %7254 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1199, 1
  %.state1200 = load <8 x i64>, ptr %.slot231, align 64
  %7255 = mul <8 x i64> %.state1200, splat (i64 4)
  %7256 = add <8 x i64> %7254, %7255
  %7257 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7253, 0
  %7258 = insertvalue { <8 x ptr>, <8 x i64> } %7257, <8 x i64> %7256, 1
  %.state1201 = load <8 x float>, ptr %.slot233, align 32
  %7259 = extractvalue { <8 x ptr>, <8 x i64> } %7258, 0
  %7260 = extractvalue { <8 x ptr>, <8 x i64> } %7258, 1
  %7261 = getelementptr i8, <8 x ptr> %7259, <8 x i64> %7260
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state1201, <8 x ptr> align 1 %7261, <8 x i1> %convergence.cascade.result1198)
  %.state1202 = load <8 x i64>, ptr %.slot231, align 64
  %7262 = add <8 x i64> %.state1202, splat (i64 1)
  %7263 = load <8 x i64>, ptr %.slot231, align 64
  %7264 = select <8 x i1> %convergence.cascade.result1198, <8 x i64> %7262, <8 x i64> %7263
  store <8 x i64> %7264, ptr %.slot231, align 64
  store <8 x i1> %convergence.cascade.result1198, ptr %current.mask, align 1
  %7265 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1198)
  br i1 %7265, label %schedule.46, label %scheduler.loop

varying.divergent1204:                            ; preds = %schedule.51
  %7266 = load i32, ptr %current.token, align 4
  %7267 = icmp ne i32 %7266, 0
  %7268 = sub i32 %7266, 1
  %7269 = select i1 %7267, i32 %7268, i32 0
  %7270 = load i8, ptr %frame.active, align 1
  %7271 = trunc i32 %7269 to i8
  %7272 = shl i8 1, %7271
  %7273 = and i8 %7270, %7272
  %7274 = icmp ne i8 %7273, 0
  %7275 = load <8 x i32>, ptr %frame.static.id, align 32
  %7276 = extractelement <8 x i32> %7275, i32 %7269
  %7277 = icmp eq i32 %7276, 18
  %7278 = and i1 %7274, %7277
  %7279 = and i1 %7267, %7278
  %7280 = xor i1 %7279, true
  %7281 = and i1 true, %7280
  %7282 = xor i8 %7270, -1
  %7283 = icmp ne i8 %7282, 0
  %7284 = xor i1 %7283, true
  %7285 = and i1 %7281, %7284
  br i1 %7285, label %convergence.overflow.trap1206, label %convergence.overflow.resume1207

varying.coherent1205:                             ; preds = %schedule.51
  br i1 %868, label %varying.coherent.true1210, label %varying.coherent.false1211

convergence.overflow.trap1206:                    ; preds = %varying.divergent1204
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1207:                  ; preds = %varying.divergent1204
  %7286 = call i8 @llvm.cttz.i8(i8 %7282, i1 false)
  %7287 = zext i8 %7286 to i32
  %7288 = select i1 %7283, i32 %7287, i32 0
  %7289 = trunc i32 %7288 to i8
  %7290 = shl i8 1, %7289
  %7291 = or i8 %7270, %7290
  %7292 = select i1 %7281, i8 %7291, i8 %7270
  store i8 %7292, ptr %frame.active, align 1
  %7293 = load <8 x i32>, ptr %frame.static.id, align 32
  %7294 = extractelement <8 x i32> %7293, i32 %7288
  %7295 = select i1 %7281, i32 18, i32 %7294
  %7296 = load <8 x i32>, ptr %frame.static.id, align 32
  %7297 = insertelement <8 x i32> %7296, i32 %7295, i32 %7288
  store <8 x i32> %7297, ptr %frame.static.id, align 32
  %7298 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7299 = extractelement <8 x i32> %7298, i32 %7288
  %7300 = select i1 %7281, i32 %7266, i32 %7299
  %7301 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7302 = insertelement <8 x i32> %7301, i32 %7300, i32 %7288
  store <8 x i32> %7302, ptr %frame.parent.token, align 32
  %7303 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7288
  %7304 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7288
  %7305 = load <8 x i1>, ptr %7303, align 1
  %7306 = load <8 x i1>, ptr %7304, align 1
  %7307 = select i1 %7281, <8 x i1> %858, <8 x i1> %7305
  store <8 x i1> %7307, ptr %7303, align 1
  %7308 = select i1 %7281, <8 x i1> zeroinitializer, <8 x i1> %7306
  store <8 x i1> %7308, ptr %7304, align 1
  %7309 = add i32 %7288, 1
  %7310 = select i1 %7279, i32 %7266, i32 %7309
  %7311 = select i1 true, i32 %7310, i32 %7266
  store i32 %7311, ptr %current.token, align 4
  %7312 = load i32, ptr %current.token, align 4
  %7313 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %865)
  %7314 = load i32, ptr %ready.count, align 4
  %7315 = icmp uge i32 %7314, 8
  %7316 = and i1 %7313, %7315
  br i1 %7316, label %ready.overflow.trap1208, label %ready.overflow.resume1209

ready.overflow.trap1208:                          ; preds = %convergence.overflow.resume1207
  call void @llvm.trap()
  unreachable

ready.overflow.resume1209:                        ; preds = %convergence.overflow.resume1207
  %7317 = select i1 %7313, i32 %7314, i32 0
  %7318 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7317
  %7319 = load <8 x i1>, ptr %7318, align 1
  %7320 = select i1 %7313, <8 x i1> %865, <8 x i1> %7319
  store <8 x i1> %7320, ptr %7318, align 1
  %7321 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7317
  %7322 = load i32, ptr %7321, align 4
  %7323 = select i1 %7313, i32 52, i32 %7322
  store i32 %7323, ptr %7321, align 4
  %7324 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7317
  %7325 = load i32, ptr %7324, align 4
  %7326 = select i1 %7313, i32 %7312, i32 %7325
  store i32 %7326, ptr %7324, align 4
  %7327 = add i32 %7314, 1
  %7328 = select i1 %7313, i32 %7327, i32 %7314
  store i32 %7328, ptr %ready.count, align 4
  %7329 = load <8 x i1>, ptr %runnable.mask, align 1
  %7330 = or <8 x i1> %7329, %865
  store <8 x i1> %7330, ptr %runnable.mask, align 1
  store <8 x i1> %867, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1210:                        ; preds = %varying.coherent1205
  store <8 x i1> %858, ptr %current.mask, align 1
  %7331 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %858)
  br i1 %7331, label %schedule.52, label %scheduler.loop

varying.coherent.false1211:                       ; preds = %varying.coherent1205
  store <8 x i1> %858, ptr %current.mask, align 1
  %7332 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %858)
  br i1 %7332, label %schedule.9, label %scheduler.loop

varying.divergent1217:                            ; preds = %schedule.52
  %7333 = load i32, ptr %current.token, align 4
  %7334 = icmp ne i32 %7333, 0
  %7335 = sub i32 %7333, 1
  %7336 = select i1 %7334, i32 %7335, i32 0
  %7337 = load i8, ptr %frame.active, align 1
  %7338 = trunc i32 %7336 to i8
  %7339 = shl i8 1, %7338
  %7340 = and i8 %7337, %7339
  %7341 = icmp ne i8 %7340, 0
  %7342 = load <8 x i32>, ptr %frame.static.id, align 32
  %7343 = extractelement <8 x i32> %7342, i32 %7336
  %7344 = icmp eq i32 %7343, 19
  %7345 = and i1 %7341, %7344
  %7346 = and i1 %7334, %7345
  %7347 = xor i1 %7346, true
  %7348 = and i1 true, %7347
  %7349 = xor i8 %7337, -1
  %7350 = icmp ne i8 %7349, 0
  %7351 = xor i1 %7350, true
  %7352 = and i1 %7348, %7351
  br i1 %7352, label %convergence.overflow.trap1219, label %convergence.overflow.resume1220

varying.coherent1218:                             ; preds = %schedule.52
  br i1 %903, label %varying.coherent.true1223, label %varying.coherent.false1224

convergence.overflow.trap1219:                    ; preds = %varying.divergent1217
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1220:                  ; preds = %varying.divergent1217
  %7353 = call i8 @llvm.cttz.i8(i8 %7349, i1 false)
  %7354 = zext i8 %7353 to i32
  %7355 = select i1 %7350, i32 %7354, i32 0
  %7356 = trunc i32 %7355 to i8
  %7357 = shl i8 1, %7356
  %7358 = or i8 %7337, %7357
  %7359 = select i1 %7348, i8 %7358, i8 %7337
  store i8 %7359, ptr %frame.active, align 1
  %7360 = load <8 x i32>, ptr %frame.static.id, align 32
  %7361 = extractelement <8 x i32> %7360, i32 %7355
  %7362 = select i1 %7348, i32 19, i32 %7361
  %7363 = load <8 x i32>, ptr %frame.static.id, align 32
  %7364 = insertelement <8 x i32> %7363, i32 %7362, i32 %7355
  store <8 x i32> %7364, ptr %frame.static.id, align 32
  %7365 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7366 = extractelement <8 x i32> %7365, i32 %7355
  %7367 = select i1 %7348, i32 %7333, i32 %7366
  %7368 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7369 = insertelement <8 x i32> %7368, i32 %7367, i32 %7355
  store <8 x i32> %7369, ptr %frame.parent.token, align 32
  %7370 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7355
  %7371 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7355
  %7372 = load <8 x i1>, ptr %7370, align 1
  %7373 = load <8 x i1>, ptr %7371, align 1
  %7374 = select i1 %7348, <8 x i1> %871, <8 x i1> %7372
  store <8 x i1> %7374, ptr %7370, align 1
  %7375 = select i1 %7348, <8 x i1> zeroinitializer, <8 x i1> %7373
  store <8 x i1> %7375, ptr %7371, align 1
  %7376 = add i32 %7355, 1
  %7377 = select i1 %7346, i32 %7333, i32 %7376
  %7378 = select i1 true, i32 %7377, i32 %7333
  store i32 %7378, ptr %current.token, align 4
  %7379 = load <8 x float>, ptr %.slot236, align 32
  %7380 = select <8 x i1> %902, <8 x float> zeroinitializer, <8 x float> %7379
  store <8 x float> %7380, ptr %.slot236, align 32
  %7381 = load i32, ptr %current.token, align 4
  %7382 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %900)
  %7383 = load i32, ptr %ready.count, align 4
  %7384 = icmp uge i32 %7383, 8
  %7385 = and i1 %7382, %7384
  br i1 %7385, label %ready.overflow.trap1221, label %ready.overflow.resume1222

ready.overflow.trap1221:                          ; preds = %convergence.overflow.resume1220
  call void @llvm.trap()
  unreachable

ready.overflow.resume1222:                        ; preds = %convergence.overflow.resume1220
  %7386 = select i1 %7382, i32 %7383, i32 0
  %7387 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7386
  %7388 = load <8 x i1>, ptr %7387, align 1
  %7389 = select i1 %7382, <8 x i1> %900, <8 x i1> %7388
  store <8 x i1> %7389, ptr %7387, align 1
  %7390 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7386
  %7391 = load i32, ptr %7390, align 4
  %7392 = select i1 %7382, i32 53, i32 %7391
  store i32 %7392, ptr %7390, align 4
  %7393 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7386
  %7394 = load i32, ptr %7393, align 4
  %7395 = select i1 %7382, i32 %7381, i32 %7394
  store i32 %7395, ptr %7393, align 4
  %7396 = add i32 %7383, 1
  %7397 = select i1 %7382, i32 %7396, i32 %7383
  store i32 %7397, ptr %ready.count, align 4
  %7398 = load <8 x i1>, ptr %runnable.mask, align 1
  %7399 = or <8 x i1> %7398, %900
  store <8 x i1> %7399, ptr %runnable.mask, align 1
  store <8 x i1> %902, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1223:                        ; preds = %varying.coherent1218
  store <8 x i1> %871, ptr %current.mask, align 1
  %7400 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %871)
  br i1 %7400, label %schedule.53, label %scheduler.loop

varying.coherent.false1224:                       ; preds = %varying.coherent1218
  %7401 = load <8 x float>, ptr %.slot236, align 32
  %7402 = select <8 x i1> %871, <8 x float> zeroinitializer, <8 x float> %7401
  store <8 x float> %7402, ptr %.slot236, align 32
  store <8 x i1> %871, ptr %current.mask, align 1
  %7403 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %871)
  br i1 %7403, label %schedule.54, label %scheduler.loop

convergence.cascade1226:                          ; preds = %convergence.cascade1226, %schedule.54
  %convergence.cascade.flow1230 = phi <8 x i1> [ %919, %schedule.54 ], [ %7446, %convergence.cascade1226 ]
  %convergence.cascade.depth1231 = phi i32 [ 0, %schedule.54 ], [ %7447, %convergence.cascade1226 ]
  %7404 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1230)
  %7405 = load i32, ptr %current.token, align 4
  %7406 = icmp ne i32 %7405, 0
  %7407 = and i1 %7404, %7406
  %7408 = sub i32 %7405, 1
  %7409 = select i1 %7407, i32 %7408, i32 0
  %7410 = load i8, ptr %frame.active, align 1
  %7411 = trunc i32 %7409 to i8
  %7412 = shl i8 1, %7411
  %7413 = and i8 %7410, %7412
  %7414 = icmp ne i8 %7413, 0
  %7415 = load <8 x i32>, ptr %frame.static.id, align 32
  %7416 = extractelement <8 x i32> %7415, i32 %7409
  %convergence.target.pointer1232 = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %7416
  %convergence.dynamic.target1233 = load i32, ptr %convergence.target.pointer1232, align 4
  %7417 = icmp eq i32 %convergence.dynamic.target1233, 54
  %7418 = and i1 %7414, %7417
  %7419 = and i1 %7407, %7418
  %7420 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7409
  %7421 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7409
  %7422 = load <8 x i1>, ptr %7420, align 1
  %7423 = load <8 x i1>, ptr %7421, align 1
  %7424 = or <8 x i1> %7423, %convergence.cascade.flow1230
  %7425 = load <8 x i1>, ptr %live.mask, align 1
  %7426 = and <8 x i1> %7422, %7425
  %7427 = icmp eq <8 x i1> %7424, %7426
  %7428 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7427)
  %7429 = and i1 %7419, %7428
  %7430 = select i1 %7429, <8 x i1> zeroinitializer, <8 x i1> %7424
  %7431 = select i1 %7419, <8 x i1> %7430, <8 x i1> %7423
  store <8 x i1> %7431, ptr %7421, align 1
  %7432 = select i1 %7429, <8 x i1> zeroinitializer, <8 x i1> %7422
  store <8 x i1> %7432, ptr %7420, align 1
  %7433 = trunc i32 %7409 to i8
  %7434 = shl i8 1, %7433
  %7435 = xor i8 %7434, -1
  %7436 = and i8 %7410, %7435
  %7437 = select i1 %7429, i8 %7436, i8 %7410
  store i8 %7437, ptr %frame.active, align 1
  %.splatinsert1234 = insertelement <8 x i1> poison, i1 %7419, i64 0
  %.splat1235 = shufflevector <8 x i1> %.splatinsert1234, <8 x i1> poison, <8 x i32> zeroinitializer
  %7438 = and <8 x i1> %convergence.cascade.flow1230, %.splat1235
  %7439 = load <8 x i1>, ptr %runnable.mask, align 1
  %7440 = xor <8 x i1> %7438, splat (i1 true)
  %7441 = and <8 x i1> %7439, %7440
  store <8 x i1> %7441, ptr %runnable.mask, align 1
  %.splatinsert1236 = insertelement <8 x i1> poison, i1 %7429, i64 0
  %.splat1237 = shufflevector <8 x i1> %.splatinsert1236, <8 x i1> poison, <8 x i32> zeroinitializer
  %7442 = select <8 x i1> %.splat1237, <8 x i1> %7424, <8 x i1> zeroinitializer
  %7443 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7444 = extractelement <8 x i32> %7443, i32 %7409
  %7445 = select i1 %7429, i32 %7444, i32 %7405
  store i32 %7445, ptr %current.token, align 4
  %.splatinsert1238 = insertelement <8 x i1> poison, i1 %7419, i64 0
  %.splat1239 = shufflevector <8 x i1> %.splatinsert1238, <8 x i1> poison, <8 x i32> zeroinitializer
  %7446 = select <8 x i1> %.splat1239, <8 x i1> %7442, <8 x i1> %convergence.cascade.flow1230
  %7447 = add i32 %convergence.cascade.depth1231, 1
  %7448 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7446)
  %7449 = icmp ult i32 %7447, 8
  %7450 = and i1 %7448, %7449
  %7451 = and i1 %7419, %7450
  %convergence.parent.token1240 = load i32, ptr %current.token, align 4
  %convergence.parent.present1241 = icmp ne i32 %convergence.parent.token1240, 0
  %7452 = and i1 %7451, %convergence.parent.present1241
  br i1 %7452, label %convergence.cascade1226, label %convergence.cascade.exit1227

convergence.cascade.exit1227:                     ; preds = %convergence.cascade1226, %schedule.54
  %convergence.cascade.result1242 = phi <8 x i1> [ %919, %schedule.54 ], [ %7446, %convergence.cascade1226 ]
  %7453 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1242)
  br i1 %7453, label %convergence.target.54.ready, label %scheduler.loop

convergence.target.54.ready:                      ; preds = %convergence.cascade.exit1227
  %7454 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1242)
  %7455 = bitcast <8 x i1> %convergence.cascade.result1242 to i8
  %7456 = call i8 @llvm.cttz.i8(i8 %7455, i1 false)
  %7457 = zext i8 %7456 to i32
  %7458 = select i1 %7454, i32 %7457, i32 0
  %tile_snapshot.spill.load1243 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %7459 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1243, 0
  %7460 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1243, 1
  %.state1244 = load <8 x i64>, ptr %.slot234, align 64
  %7461 = mul <8 x i64> %.state1244, splat (i64 4)
  %7462 = add <8 x i64> %7460, %7461
  %7463 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7459, 0
  %7464 = insertvalue { <8 x ptr>, <8 x i64> } %7463, <8 x i64> %7462, 1
  %.state1245 = load <8 x float>, ptr %.slot236, align 32
  %7465 = extractvalue { <8 x ptr>, <8 x i64> } %7464, 0
  %7466 = extractvalue { <8 x ptr>, <8 x i64> } %7464, 1
  %7467 = getelementptr i8, <8 x ptr> %7465, <8 x i64> %7466
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state1245, <8 x ptr> align 1 %7467, <8 x i1> %convergence.cascade.result1242)
  %.state1246 = load <8 x i64>, ptr %.slot234, align 64
  %7468 = add <8 x i64> %.state1246, splat (i64 1)
  %7469 = load <8 x i64>, ptr %.slot234, align 64
  %7470 = select <8 x i1> %convergence.cascade.result1242, <8 x i64> %7468, <8 x i64> %7469
  store <8 x i64> %7470, ptr %.slot234, align 64
  store <8 x i1> %convergence.cascade.result1242, ptr %current.mask, align 1
  %7471 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1242)
  br i1 %7471, label %schedule.51, label %scheduler.loop

convergence.cascade1247:                          ; preds = %convergence.cascade1247, %schedule.55
  %convergence.cascade.flow1251 = phi <8 x i1> [ %920, %schedule.55 ], [ %7514, %convergence.cascade1247 ]
  %convergence.cascade.depth1252 = phi i32 [ 0, %schedule.55 ], [ %7515, %convergence.cascade1247 ]
  %7472 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1251)
  %7473 = load i32, ptr %current.token, align 4
  %7474 = icmp ne i32 %7473, 0
  %7475 = and i1 %7472, %7474
  %7476 = sub i32 %7473, 1
  %7477 = select i1 %7475, i32 %7476, i32 0
  %7478 = load i8, ptr %frame.active, align 1
  %7479 = trunc i32 %7477 to i8
  %7480 = shl i8 1, %7479
  %7481 = and i8 %7478, %7480
  %7482 = icmp ne i8 %7481, 0
  %7483 = load <8 x i32>, ptr %frame.static.id, align 32
  %7484 = extractelement <8 x i32> %7483, i32 %7477
  %convergence.target.pointer1253 = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %7484
  %convergence.dynamic.target1254 = load i32, ptr %convergence.target.pointer1253, align 4
  %7485 = icmp eq i32 %convergence.dynamic.target1254, 55
  %7486 = and i1 %7482, %7485
  %7487 = and i1 %7475, %7486
  %7488 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7477
  %7489 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7477
  %7490 = load <8 x i1>, ptr %7488, align 1
  %7491 = load <8 x i1>, ptr %7489, align 1
  %7492 = or <8 x i1> %7491, %convergence.cascade.flow1251
  %7493 = load <8 x i1>, ptr %live.mask, align 1
  %7494 = and <8 x i1> %7490, %7493
  %7495 = icmp eq <8 x i1> %7492, %7494
  %7496 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7495)
  %7497 = and i1 %7487, %7496
  %7498 = select i1 %7497, <8 x i1> zeroinitializer, <8 x i1> %7492
  %7499 = select i1 %7487, <8 x i1> %7498, <8 x i1> %7491
  store <8 x i1> %7499, ptr %7489, align 1
  %7500 = select i1 %7497, <8 x i1> zeroinitializer, <8 x i1> %7490
  store <8 x i1> %7500, ptr %7488, align 1
  %7501 = trunc i32 %7477 to i8
  %7502 = shl i8 1, %7501
  %7503 = xor i8 %7502, -1
  %7504 = and i8 %7478, %7503
  %7505 = select i1 %7497, i8 %7504, i8 %7478
  store i8 %7505, ptr %frame.active, align 1
  %.splatinsert1255 = insertelement <8 x i1> poison, i1 %7487, i64 0
  %.splat1256 = shufflevector <8 x i1> %.splatinsert1255, <8 x i1> poison, <8 x i32> zeroinitializer
  %7506 = and <8 x i1> %convergence.cascade.flow1251, %.splat1256
  %7507 = load <8 x i1>, ptr %runnable.mask, align 1
  %7508 = xor <8 x i1> %7506, splat (i1 true)
  %7509 = and <8 x i1> %7507, %7508
  store <8 x i1> %7509, ptr %runnable.mask, align 1
  %.splatinsert1257 = insertelement <8 x i1> poison, i1 %7497, i64 0
  %.splat1258 = shufflevector <8 x i1> %.splatinsert1257, <8 x i1> poison, <8 x i32> zeroinitializer
  %7510 = select <8 x i1> %.splat1258, <8 x i1> %7492, <8 x i1> zeroinitializer
  %7511 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7512 = extractelement <8 x i32> %7511, i32 %7477
  %7513 = select i1 %7497, i32 %7512, i32 %7473
  store i32 %7513, ptr %current.token, align 4
  %.splatinsert1259 = insertelement <8 x i1> poison, i1 %7487, i64 0
  %.splat1260 = shufflevector <8 x i1> %.splatinsert1259, <8 x i1> poison, <8 x i32> zeroinitializer
  %7514 = select <8 x i1> %.splat1260, <8 x i1> %7510, <8 x i1> %convergence.cascade.flow1251
  %7515 = add i32 %convergence.cascade.depth1252, 1
  %7516 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7514)
  %7517 = icmp ult i32 %7515, 8
  %7518 = and i1 %7516, %7517
  %7519 = and i1 %7487, %7518
  %convergence.parent.token1261 = load i32, ptr %current.token, align 4
  %convergence.parent.present1262 = icmp ne i32 %convergence.parent.token1261, 0
  %7520 = and i1 %7519, %convergence.parent.present1262
  br i1 %7520, label %convergence.cascade1247, label %convergence.cascade.exit1248

convergence.cascade.exit1248:                     ; preds = %convergence.cascade1247, %schedule.55
  %convergence.cascade.result1263 = phi <8 x i1> [ %920, %schedule.55 ], [ %7514, %convergence.cascade1247 ]
  %7521 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1263)
  br i1 %7521, label %convergence.target.55.ready, label %scheduler.loop

convergence.target.55.ready:                      ; preds = %convergence.cascade.exit1248
  %7522 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1263)
  %7523 = bitcast <8 x i1> %convergence.cascade.result1263 to i8
  %7524 = call i8 @llvm.cttz.i8(i8 %7523, i1 false)
  %7525 = zext i8 %7524 to i32
  %7526 = select i1 %7522, i32 %7525, i32 0
  %7527 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill237, align 64
  %7528 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %7529 = extractvalue { <8 x ptr>, <8 x i64> } %7527, 0
  %7530 = select <8 x i1> %convergence.cascade.result1263, <8 x ptr> %7528, <8 x ptr> %7529
  %7531 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %7532 = extractvalue { <8 x ptr>, <8 x i64> } %7527, 1
  %7533 = select <8 x i1> %convergence.cascade.result1263, <8 x i64> %7531, <8 x i64> %7532
  %7534 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7530, 0
  %7535 = insertvalue { <8 x ptr>, <8 x i64> } %7534, <8 x i64> %7533, 1
  store volatile { <8 x ptr>, <8 x i64> } %7535, ptr %tile_snapshot.spill237, align 64
  %7536 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %7537 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %7538 = add <8 x i64> %7537, zeroinitializer
  %7539 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7536, 0
  %7540 = insertvalue { <8 x ptr>, <8 x i64> } %7539, <8 x i64> %7538, 1
  %.state1264 = load <8 x float>, ptr %.slot59, align 32
  %7541 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %7542 = extractvalue { <8 x ptr>, <8 x i64> } %7540, 1
  %7543 = extractelement <8 x ptr> %7541, i32 0
  %7544 = extractelement <8 x i64> %7542, i32 %7526
  %7545 = zext i32 %7526 to i64
  %7546 = mul i64 %7545, 4
  %7547 = sub i64 %7544, %7546
  %7548 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1263)
  %7549 = select i1 %7548, i64 %7547, i64 0
  %private.contiguous.address1265 = getelementptr i8, ptr %7543, i64 %7549
  %private.contiguous.preserve1266 = load <8 x float>, ptr %private.contiguous.address1265, align 4
  %7550 = select <8 x i1> %convergence.cascade.result1263, <8 x float> %.state1264, <8 x float> %private.contiguous.preserve1266
  store <8 x float> %7550, ptr %private.contiguous.address1265, align 4
  %7551 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %7552 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %7553 = add <8 x i64> %7552, splat (i64 32)
  %7554 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7551, 0
  %7555 = insertvalue { <8 x ptr>, <8 x i64> } %7554, <8 x i64> %7553, 1
  %.state1267 = load <8 x float>, ptr %.slot60, align 32
  %7556 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %7557 = extractvalue { <8 x ptr>, <8 x i64> } %7555, 1
  %7558 = extractelement <8 x ptr> %7556, i32 0
  %7559 = extractelement <8 x i64> %7557, i32 %7526
  %7560 = zext i32 %7526 to i64
  %7561 = mul i64 %7560, 4
  %7562 = sub i64 %7559, %7561
  %7563 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1263)
  %7564 = select i1 %7563, i64 %7562, i64 0
  %private.contiguous.address1268 = getelementptr i8, ptr %7558, i64 %7564
  %private.contiguous.preserve1269 = load <8 x float>, ptr %private.contiguous.address1268, align 4
  %7565 = select <8 x i1> %convergence.cascade.result1263, <8 x float> %.state1267, <8 x float> %private.contiguous.preserve1269
  store <8 x float> %7565, ptr %private.contiguous.address1268, align 4
  %7566 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %7567 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %7568 = add <8 x i64> %7567, splat (i64 64)
  %7569 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7566, 0
  %7570 = insertvalue { <8 x ptr>, <8 x i64> } %7569, <8 x i64> %7568, 1
  %.state1270 = load <8 x float>, ptr %.slot61, align 32
  %7571 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %7572 = extractvalue { <8 x ptr>, <8 x i64> } %7570, 1
  %7573 = extractelement <8 x ptr> %7571, i32 0
  %7574 = extractelement <8 x i64> %7572, i32 %7526
  %7575 = zext i32 %7526 to i64
  %7576 = mul i64 %7575, 4
  %7577 = sub i64 %7574, %7576
  %7578 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1263)
  %7579 = select i1 %7578, i64 %7577, i64 0
  %private.contiguous.address1271 = getelementptr i8, ptr %7573, i64 %7579
  %private.contiguous.preserve1272 = load <8 x float>, ptr %private.contiguous.address1271, align 4
  %7580 = select <8 x i1> %convergence.cascade.result1263, <8 x float> %.state1270, <8 x float> %private.contiguous.preserve1272
  store <8 x float> %7580, ptr %private.contiguous.address1271, align 4
  %7581 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %7582 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %7583 = add <8 x i64> %7582, splat (i64 96)
  %7584 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7581, 0
  %7585 = insertvalue { <8 x ptr>, <8 x i64> } %7584, <8 x i64> %7583, 1
  %.state1273 = load <8 x float>, ptr %.slot62, align 32
  %7586 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %7587 = extractvalue { <8 x ptr>, <8 x i64> } %7585, 1
  %7588 = extractelement <8 x ptr> %7586, i32 0
  %7589 = extractelement <8 x i64> %7587, i32 %7526
  %7590 = zext i32 %7526 to i64
  %7591 = mul i64 %7590, 4
  %7592 = sub i64 %7589, %7591
  %7593 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1263)
  %7594 = select i1 %7593, i64 %7592, i64 0
  %private.contiguous.address1274 = getelementptr i8, ptr %7588, i64 %7594
  %private.contiguous.preserve1275 = load <8 x float>, ptr %private.contiguous.address1274, align 4
  %7595 = select <8 x i1> %convergence.cascade.result1263, <8 x float> %.state1273, <8 x float> %private.contiguous.preserve1275
  store <8 x float> %7595, ptr %private.contiguous.address1274, align 4
  %7596 = load <8 x i64>, ptr %.slot238, align 64
  %7597 = select <8 x i1> %convergence.cascade.result1263, <8 x i64> zeroinitializer, <8 x i64> %7596
  store <8 x i64> %7597, ptr %.slot238, align 64
  store <8 x i1> %convergence.cascade.result1263, ptr %current.mask, align 1
  %7598 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1263)
  br i1 %7598, label %schedule.56, label %scheduler.loop

varying.divergent1277:                            ; preds = %schedule.56
  %7599 = load i32, ptr %current.token, align 4
  %7600 = icmp ne i32 %7599, 0
  %7601 = sub i32 %7599, 1
  %7602 = select i1 %7600, i32 %7601, i32 0
  %7603 = load i8, ptr %frame.active, align 1
  %7604 = trunc i32 %7602 to i8
  %7605 = shl i8 1, %7604
  %7606 = and i8 %7603, %7605
  %7607 = icmp ne i8 %7606, 0
  %7608 = load <8 x i32>, ptr %frame.static.id, align 32
  %7609 = extractelement <8 x i32> %7608, i32 %7602
  %7610 = icmp eq i32 %7609, 20
  %7611 = and i1 %7607, %7610
  %7612 = and i1 %7600, %7611
  %7613 = xor i1 %7612, true
  %7614 = and i1 true, %7613
  %7615 = xor i8 %7603, -1
  %7616 = icmp ne i8 %7615, 0
  %7617 = xor i1 %7616, true
  %7618 = and i1 %7614, %7617
  br i1 %7618, label %convergence.overflow.trap1279, label %convergence.overflow.resume1280

varying.coherent1278:                             ; preds = %schedule.56
  br i1 %931, label %varying.coherent.true1283, label %varying.coherent.false1284

convergence.overflow.trap1279:                    ; preds = %varying.divergent1277
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1280:                  ; preds = %varying.divergent1277
  %7619 = call i8 @llvm.cttz.i8(i8 %7615, i1 false)
  %7620 = zext i8 %7619 to i32
  %7621 = select i1 %7616, i32 %7620, i32 0
  %7622 = trunc i32 %7621 to i8
  %7623 = shl i8 1, %7622
  %7624 = or i8 %7603, %7623
  %7625 = select i1 %7614, i8 %7624, i8 %7603
  store i8 %7625, ptr %frame.active, align 1
  %7626 = load <8 x i32>, ptr %frame.static.id, align 32
  %7627 = extractelement <8 x i32> %7626, i32 %7621
  %7628 = select i1 %7614, i32 20, i32 %7627
  %7629 = load <8 x i32>, ptr %frame.static.id, align 32
  %7630 = insertelement <8 x i32> %7629, i32 %7628, i32 %7621
  store <8 x i32> %7630, ptr %frame.static.id, align 32
  %7631 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7632 = extractelement <8 x i32> %7631, i32 %7621
  %7633 = select i1 %7614, i32 %7599, i32 %7632
  %7634 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7635 = insertelement <8 x i32> %7634, i32 %7633, i32 %7621
  store <8 x i32> %7635, ptr %frame.parent.token, align 32
  %7636 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7621
  %7637 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7621
  %7638 = load <8 x i1>, ptr %7636, align 1
  %7639 = load <8 x i1>, ptr %7637, align 1
  %7640 = select i1 %7614, <8 x i1> %921, <8 x i1> %7638
  store <8 x i1> %7640, ptr %7636, align 1
  %7641 = select i1 %7614, <8 x i1> zeroinitializer, <8 x i1> %7639
  store <8 x i1> %7641, ptr %7637, align 1
  %7642 = add i32 %7621, 1
  %7643 = select i1 %7612, i32 %7599, i32 %7642
  %7644 = select i1 true, i32 %7643, i32 %7599
  store i32 %7644, ptr %current.token, align 4
  %7645 = load i32, ptr %current.token, align 4
  %7646 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %928)
  %7647 = load i32, ptr %ready.count, align 4
  %7648 = icmp uge i32 %7647, 8
  %7649 = and i1 %7646, %7648
  br i1 %7649, label %ready.overflow.trap1281, label %ready.overflow.resume1282

ready.overflow.trap1281:                          ; preds = %convergence.overflow.resume1280
  call void @llvm.trap()
  unreachable

ready.overflow.resume1282:                        ; preds = %convergence.overflow.resume1280
  %7650 = select i1 %7646, i32 %7647, i32 0
  %7651 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7650
  %7652 = load <8 x i1>, ptr %7651, align 1
  %7653 = select i1 %7646, <8 x i1> %928, <8 x i1> %7652
  store <8 x i1> %7653, ptr %7651, align 1
  %7654 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7650
  %7655 = load i32, ptr %7654, align 4
  %7656 = select i1 %7646, i32 57, i32 %7655
  store i32 %7656, ptr %7654, align 4
  %7657 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7650
  %7658 = load i32, ptr %7657, align 4
  %7659 = select i1 %7646, i32 %7645, i32 %7658
  store i32 %7659, ptr %7657, align 4
  %7660 = add i32 %7647, 1
  %7661 = select i1 %7646, i32 %7660, i32 %7647
  store i32 %7661, ptr %ready.count, align 4
  %7662 = load <8 x i1>, ptr %runnable.mask, align 1
  %7663 = or <8 x i1> %7662, %928
  store <8 x i1> %7663, ptr %runnable.mask, align 1
  store <8 x i1> %930, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1283:                        ; preds = %varying.coherent1278
  store <8 x i1> %921, ptr %current.mask, align 1
  %7664 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %921)
  br i1 %7664, label %schedule.57, label %scheduler.loop

varying.coherent.false1284:                       ; preds = %varying.coherent1278
  store <8 x i1> %921, ptr %current.mask, align 1
  %7665 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %921)
  br i1 %7665, label %schedule.60, label %scheduler.loop

varying.divergent1292:                            ; preds = %schedule.57
  %7666 = load i32, ptr %current.token, align 4
  %7667 = icmp ne i32 %7666, 0
  %7668 = sub i32 %7666, 1
  %7669 = select i1 %7667, i32 %7668, i32 0
  %7670 = load i8, ptr %frame.active, align 1
  %7671 = trunc i32 %7669 to i8
  %7672 = shl i8 1, %7671
  %7673 = and i8 %7670, %7672
  %7674 = icmp ne i8 %7673, 0
  %7675 = load <8 x i32>, ptr %frame.static.id, align 32
  %7676 = extractelement <8 x i32> %7675, i32 %7669
  %7677 = icmp eq i32 %7676, 21
  %7678 = and i1 %7674, %7677
  %7679 = and i1 %7667, %7678
  %7680 = xor i1 %7679, true
  %7681 = and i1 true, %7680
  %7682 = xor i8 %7670, -1
  %7683 = icmp ne i8 %7682, 0
  %7684 = xor i1 %7683, true
  %7685 = and i1 %7681, %7684
  br i1 %7685, label %convergence.overflow.trap1294, label %convergence.overflow.resume1295

varying.coherent1293:                             ; preds = %schedule.57
  br i1 %992, label %varying.coherent.true1298, label %varying.coherent.false1299

convergence.overflow.trap1294:                    ; preds = %varying.divergent1292
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1295:                  ; preds = %varying.divergent1292
  %7686 = call i8 @llvm.cttz.i8(i8 %7682, i1 false)
  %7687 = zext i8 %7686 to i32
  %7688 = select i1 %7683, i32 %7687, i32 0
  %7689 = trunc i32 %7688 to i8
  %7690 = shl i8 1, %7689
  %7691 = or i8 %7670, %7690
  %7692 = select i1 %7681, i8 %7691, i8 %7670
  store i8 %7692, ptr %frame.active, align 1
  %7693 = load <8 x i32>, ptr %frame.static.id, align 32
  %7694 = extractelement <8 x i32> %7693, i32 %7688
  %7695 = select i1 %7681, i32 21, i32 %7694
  %7696 = load <8 x i32>, ptr %frame.static.id, align 32
  %7697 = insertelement <8 x i32> %7696, i32 %7695, i32 %7688
  store <8 x i32> %7697, ptr %frame.static.id, align 32
  %7698 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7699 = extractelement <8 x i32> %7698, i32 %7688
  %7700 = select i1 %7681, i32 %7666, i32 %7699
  %7701 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7702 = insertelement <8 x i32> %7701, i32 %7700, i32 %7688
  store <8 x i32> %7702, ptr %frame.parent.token, align 32
  %7703 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7688
  %7704 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7688
  %7705 = load <8 x i1>, ptr %7703, align 1
  %7706 = load <8 x i1>, ptr %7704, align 1
  %7707 = select i1 %7681, <8 x i1> %934, <8 x i1> %7705
  store <8 x i1> %7707, ptr %7703, align 1
  %7708 = select i1 %7681, <8 x i1> zeroinitializer, <8 x i1> %7706
  store <8 x i1> %7708, ptr %7704, align 1
  %7709 = add i32 %7688, 1
  %7710 = select i1 %7679, i32 %7666, i32 %7709
  %7711 = select i1 true, i32 %7710, i32 %7666
  store i32 %7711, ptr %current.token, align 4
  %7712 = load i32, ptr %current.token, align 4
  %7713 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %989)
  %7714 = load i32, ptr %ready.count, align 4
  %7715 = icmp uge i32 %7714, 8
  %7716 = and i1 %7713, %7715
  br i1 %7716, label %ready.overflow.trap1296, label %ready.overflow.resume1297

ready.overflow.trap1296:                          ; preds = %convergence.overflow.resume1295
  call void @llvm.trap()
  unreachable

ready.overflow.resume1297:                        ; preds = %convergence.overflow.resume1295
  %7717 = select i1 %7713, i32 %7714, i32 0
  %7718 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7717
  %7719 = load <8 x i1>, ptr %7718, align 1
  %7720 = select i1 %7713, <8 x i1> %989, <8 x i1> %7719
  store <8 x i1> %7720, ptr %7718, align 1
  %7721 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7717
  %7722 = load i32, ptr %7721, align 4
  %7723 = select i1 %7713, i32 58, i32 %7722
  store i32 %7723, ptr %7721, align 4
  %7724 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7717
  %7725 = load i32, ptr %7724, align 4
  %7726 = select i1 %7713, i32 %7712, i32 %7725
  store i32 %7726, ptr %7724, align 4
  %7727 = add i32 %7714, 1
  %7728 = select i1 %7713, i32 %7727, i32 %7714
  store i32 %7728, ptr %ready.count, align 4
  %7729 = load <8 x i1>, ptr %runnable.mask, align 1
  %7730 = or <8 x i1> %7729, %989
  store <8 x i1> %7730, ptr %runnable.mask, align 1
  store <8 x i1> %991, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1298:                        ; preds = %varying.coherent1293
  store <8 x i1> %934, ptr %current.mask, align 1
  %7731 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %934)
  br i1 %7731, label %schedule.58, label %scheduler.loop

varying.coherent.false1299:                       ; preds = %varying.coherent1293
  store <8 x i1> %934, ptr %current.mask, align 1
  %7732 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %934)
  br i1 %7732, label %schedule.59, label %scheduler.loop

convergence.cascade1302:                          ; preds = %convergence.cascade1302, %schedule.59
  %convergence.cascade.flow1306 = phi <8 x i1> [ %1005, %schedule.59 ], [ %7775, %convergence.cascade1302 ]
  %convergence.cascade.depth1307 = phi i32 [ 0, %schedule.59 ], [ %7776, %convergence.cascade1302 ]
  %7733 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1306)
  %7734 = load i32, ptr %current.token, align 4
  %7735 = icmp ne i32 %7734, 0
  %7736 = and i1 %7733, %7735
  %7737 = sub i32 %7734, 1
  %7738 = select i1 %7736, i32 %7737, i32 0
  %7739 = load i8, ptr %frame.active, align 1
  %7740 = trunc i32 %7738 to i8
  %7741 = shl i8 1, %7740
  %7742 = and i8 %7739, %7741
  %7743 = icmp ne i8 %7742, 0
  %7744 = load <8 x i32>, ptr %frame.static.id, align 32
  %7745 = extractelement <8 x i32> %7744, i32 %7738
  %convergence.target.pointer1308 = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %7745
  %convergence.dynamic.target1309 = load i32, ptr %convergence.target.pointer1308, align 4
  %7746 = icmp eq i32 %convergence.dynamic.target1309, 59
  %7747 = and i1 %7743, %7746
  %7748 = and i1 %7736, %7747
  %7749 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7738
  %7750 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7738
  %7751 = load <8 x i1>, ptr %7749, align 1
  %7752 = load <8 x i1>, ptr %7750, align 1
  %7753 = or <8 x i1> %7752, %convergence.cascade.flow1306
  %7754 = load <8 x i1>, ptr %live.mask, align 1
  %7755 = and <8 x i1> %7751, %7754
  %7756 = icmp eq <8 x i1> %7753, %7755
  %7757 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7756)
  %7758 = and i1 %7748, %7757
  %7759 = select i1 %7758, <8 x i1> zeroinitializer, <8 x i1> %7753
  %7760 = select i1 %7748, <8 x i1> %7759, <8 x i1> %7752
  store <8 x i1> %7760, ptr %7750, align 1
  %7761 = select i1 %7758, <8 x i1> zeroinitializer, <8 x i1> %7751
  store <8 x i1> %7761, ptr %7749, align 1
  %7762 = trunc i32 %7738 to i8
  %7763 = shl i8 1, %7762
  %7764 = xor i8 %7763, -1
  %7765 = and i8 %7739, %7764
  %7766 = select i1 %7758, i8 %7765, i8 %7739
  store i8 %7766, ptr %frame.active, align 1
  %.splatinsert1310 = insertelement <8 x i1> poison, i1 %7748, i64 0
  %.splat1311 = shufflevector <8 x i1> %.splatinsert1310, <8 x i1> poison, <8 x i32> zeroinitializer
  %7767 = and <8 x i1> %convergence.cascade.flow1306, %.splat1311
  %7768 = load <8 x i1>, ptr %runnable.mask, align 1
  %7769 = xor <8 x i1> %7767, splat (i1 true)
  %7770 = and <8 x i1> %7768, %7769
  store <8 x i1> %7770, ptr %runnable.mask, align 1
  %.splatinsert1312 = insertelement <8 x i1> poison, i1 %7758, i64 0
  %.splat1313 = shufflevector <8 x i1> %.splatinsert1312, <8 x i1> poison, <8 x i32> zeroinitializer
  %7771 = select <8 x i1> %.splat1313, <8 x i1> %7753, <8 x i1> zeroinitializer
  %7772 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7773 = extractelement <8 x i32> %7772, i32 %7738
  %7774 = select i1 %7758, i32 %7773, i32 %7734
  store i32 %7774, ptr %current.token, align 4
  %.splatinsert1314 = insertelement <8 x i1> poison, i1 %7748, i64 0
  %.splat1315 = shufflevector <8 x i1> %.splatinsert1314, <8 x i1> poison, <8 x i32> zeroinitializer
  %7775 = select <8 x i1> %.splat1315, <8 x i1> %7771, <8 x i1> %convergence.cascade.flow1306
  %7776 = add i32 %convergence.cascade.depth1307, 1
  %7777 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7775)
  %7778 = icmp ult i32 %7776, 8
  %7779 = and i1 %7777, %7778
  %7780 = and i1 %7748, %7779
  %convergence.parent.token1316 = load i32, ptr %current.token, align 4
  %convergence.parent.present1317 = icmp ne i32 %convergence.parent.token1316, 0
  %7781 = and i1 %7780, %convergence.parent.present1317
  br i1 %7781, label %convergence.cascade1302, label %convergence.cascade.exit1303

convergence.cascade.exit1303:                     ; preds = %convergence.cascade1302, %schedule.59
  %convergence.cascade.result1318 = phi <8 x i1> [ %1005, %schedule.59 ], [ %7775, %convergence.cascade1302 ]
  %7782 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1318)
  br i1 %7782, label %convergence.target.59.ready, label %scheduler.loop

convergence.target.59.ready:                      ; preds = %convergence.cascade.exit1303
  %7783 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1318)
  %7784 = bitcast <8 x i1> %convergence.cascade.result1318 to i8
  %7785 = call i8 @llvm.cttz.i8(i8 %7784, i1 false)
  %7786 = zext i8 %7785 to i32
  %7787 = select i1 %7783, i32 %7786, i32 0
  %.state1319 = load <8 x i64>, ptr %.slot238, align 64
  %7788 = add <8 x i64> %.state1319, splat (i64 1)
  %7789 = load <8 x i64>, ptr %.slot238, align 64
  %7790 = select <8 x i1> %convergence.cascade.result1318, <8 x i64> %7788, <8 x i64> %7789
  store <8 x i64> %7790, ptr %.slot238, align 64
  store <8 x i1> %convergence.cascade.result1318, ptr %current.mask, align 1
  %7791 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1318)
  br i1 %7791, label %schedule.56, label %scheduler.loop

convergence.cascade1320:                          ; preds = %convergence.cascade1320, %schedule.60
  %convergence.cascade.flow1324 = phi <8 x i1> [ %1006, %schedule.60 ], [ %7834, %convergence.cascade1320 ]
  %convergence.cascade.depth1325 = phi i32 [ 0, %schedule.60 ], [ %7835, %convergence.cascade1320 ]
  %7792 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1324)
  %7793 = load i32, ptr %current.token, align 4
  %7794 = icmp ne i32 %7793, 0
  %7795 = and i1 %7792, %7794
  %7796 = sub i32 %7793, 1
  %7797 = select i1 %7795, i32 %7796, i32 0
  %7798 = load i8, ptr %frame.active, align 1
  %7799 = trunc i32 %7797 to i8
  %7800 = shl i8 1, %7799
  %7801 = and i8 %7798, %7800
  %7802 = icmp ne i8 %7801, 0
  %7803 = load <8 x i32>, ptr %frame.static.id, align 32
  %7804 = extractelement <8 x i32> %7803, i32 %7797
  %convergence.target.pointer1326 = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %7804
  %convergence.dynamic.target1327 = load i32, ptr %convergence.target.pointer1326, align 4
  %7805 = icmp eq i32 %convergence.dynamic.target1327, 60
  %7806 = and i1 %7802, %7805
  %7807 = and i1 %7795, %7806
  %7808 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7797
  %7809 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7797
  %7810 = load <8 x i1>, ptr %7808, align 1
  %7811 = load <8 x i1>, ptr %7809, align 1
  %7812 = or <8 x i1> %7811, %convergence.cascade.flow1324
  %7813 = load <8 x i1>, ptr %live.mask, align 1
  %7814 = and <8 x i1> %7810, %7813
  %7815 = icmp eq <8 x i1> %7812, %7814
  %7816 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7815)
  %7817 = and i1 %7807, %7816
  %7818 = select i1 %7817, <8 x i1> zeroinitializer, <8 x i1> %7812
  %7819 = select i1 %7807, <8 x i1> %7818, <8 x i1> %7811
  store <8 x i1> %7819, ptr %7809, align 1
  %7820 = select i1 %7817, <8 x i1> zeroinitializer, <8 x i1> %7810
  store <8 x i1> %7820, ptr %7808, align 1
  %7821 = trunc i32 %7797 to i8
  %7822 = shl i8 1, %7821
  %7823 = xor i8 %7822, -1
  %7824 = and i8 %7798, %7823
  %7825 = select i1 %7817, i8 %7824, i8 %7798
  store i8 %7825, ptr %frame.active, align 1
  %.splatinsert1328 = insertelement <8 x i1> poison, i1 %7807, i64 0
  %.splat1329 = shufflevector <8 x i1> %.splatinsert1328, <8 x i1> poison, <8 x i32> zeroinitializer
  %7826 = and <8 x i1> %convergence.cascade.flow1324, %.splat1329
  %7827 = load <8 x i1>, ptr %runnable.mask, align 1
  %7828 = xor <8 x i1> %7826, splat (i1 true)
  %7829 = and <8 x i1> %7827, %7828
  store <8 x i1> %7829, ptr %runnable.mask, align 1
  %.splatinsert1330 = insertelement <8 x i1> poison, i1 %7817, i64 0
  %.splat1331 = shufflevector <8 x i1> %.splatinsert1330, <8 x i1> poison, <8 x i32> zeroinitializer
  %7830 = select <8 x i1> %.splat1331, <8 x i1> %7812, <8 x i1> zeroinitializer
  %7831 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7832 = extractelement <8 x i32> %7831, i32 %7797
  %7833 = select i1 %7817, i32 %7832, i32 %7793
  store i32 %7833, ptr %current.token, align 4
  %.splatinsert1332 = insertelement <8 x i1> poison, i1 %7807, i64 0
  %.splat1333 = shufflevector <8 x i1> %.splatinsert1332, <8 x i1> poison, <8 x i32> zeroinitializer
  %7834 = select <8 x i1> %.splat1333, <8 x i1> %7830, <8 x i1> %convergence.cascade.flow1324
  %7835 = add i32 %convergence.cascade.depth1325, 1
  %7836 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7834)
  %7837 = icmp ult i32 %7835, 8
  %7838 = and i1 %7836, %7837
  %7839 = and i1 %7807, %7838
  %convergence.parent.token1334 = load i32, ptr %current.token, align 4
  %convergence.parent.present1335 = icmp ne i32 %convergence.parent.token1334, 0
  %7840 = and i1 %7839, %convergence.parent.present1335
  br i1 %7840, label %convergence.cascade1320, label %convergence.cascade.exit1321

convergence.cascade.exit1321:                     ; preds = %convergence.cascade1320, %schedule.60
  %convergence.cascade.result1336 = phi <8 x i1> [ %1006, %schedule.60 ], [ %7834, %convergence.cascade1320 ]
  %7841 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1336)
  br i1 %7841, label %convergence.target.60.ready, label %scheduler.loop

convergence.target.60.ready:                      ; preds = %convergence.cascade.exit1321
  %7842 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1336)
  %7843 = bitcast <8 x i1> %convergence.cascade.result1336 to i8
  %7844 = call i8 @llvm.cttz.i8(i8 %7843, i1 false)
  %7845 = zext i8 %7844 to i32
  %7846 = select i1 %7842, i32 %7845, i32 0
  %7847 = load <8 x i1>, ptr %live.mask, align 1
  %7848 = xor <8 x i1> %convergence.cascade.result1336, splat (i1 true)
  %7849 = and <8 x i1> %7847, %7848
  store <8 x i1> %7849, ptr %live.mask, align 1
  %7850 = load <8 x i1>, ptr %runnable.mask, align 1
  %7851 = xor <8 x i1> %convergence.cascade.result1336, splat (i1 true)
  %7852 = and <8 x i1> %7850, %7851
  store <8 x i1> %7852, ptr %runnable.mask, align 1
  %return.active.frames = load i8, ptr %frame.active, align 1
  %return.frames.present = icmp ne i8 %return.active.frames, 0
  br i1 %return.frames.present, label %return.frame.cleanup, label %return.frame.cleanup.done

return.frame.cleanup:                             ; preds = %convergence.target.60.ready
  %7853 = load i8, ptr %frame.active, align 1
  %7854 = and i8 %7853, 1
  %7855 = icmp ne i8 %7854, 0
  %7856 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 0
  %7857 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 0
  %7858 = load <8 x i1>, ptr %7856, align 1
  %7859 = load <8 x i1>, ptr %7857, align 1
  %7860 = and <8 x i1> %7858, %7849
  %7861 = icmp eq <8 x i1> %7859, %7860
  %7862 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7861)
  %7863 = and i1 %7855, %7862
  %.splatinsert1337 = insertelement <8 x i1> poison, i1 %7863, i64 0
  %.splat1338 = shufflevector <8 x i1> %.splatinsert1337, <8 x i1> poison, <8 x i32> zeroinitializer
  %7864 = select <8 x i1> %.splat1338, <8 x i1> %7859, <8 x i1> zeroinitializer
  %7865 = select i1 %7863, <8 x i1> zeroinitializer, <8 x i1> %7860
  store <8 x i1> %7865, ptr %7856, align 1
  %7866 = select i1 %7863, <8 x i1> zeroinitializer, <8 x i1> %7859
  store <8 x i1> %7866, ptr %7857, align 1
  %7867 = and i8 %7853, -2
  %7868 = select i1 %7863, i8 %7867, i8 %7853
  store i8 %7868, ptr %frame.active, align 1
  %7869 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7870 = extractelement <8 x i32> %7869, i32 0
  %7871 = load <8 x i32>, ptr %frame.static.id, align 32
  %7872 = extractelement <8 x i32> %7871, i32 0
  %convergence.target.pointer1339 = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %7872
  %convergence.dynamic.target1340 = load i32, ptr %convergence.target.pointer1339, align 4
  %7873 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7864)
  %7874 = load i32, ptr %ready.count, align 4
  %7875 = icmp uge i32 %7874, 8
  %7876 = and i1 %7873, %7875
  br i1 %7876, label %ready.overflow.trap1341, label %ready.overflow.resume1342

return.frame.cleanup.done:                        ; preds = %ready.overflow.resume1384, %convergence.target.60.ready
  br label %scheduler.loop

ready.overflow.trap1341:                          ; preds = %return.frame.cleanup
  call void @llvm.trap()
  unreachable

ready.overflow.resume1342:                        ; preds = %return.frame.cleanup
  %7877 = select i1 %7873, i32 %7874, i32 0
  %7878 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7877
  %7879 = load <8 x i1>, ptr %7878, align 1
  %7880 = select i1 %7873, <8 x i1> %7864, <8 x i1> %7879
  store <8 x i1> %7880, ptr %7878, align 1
  %7881 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7877
  %7882 = load i32, ptr %7881, align 4
  %7883 = select i1 %7873, i32 %convergence.dynamic.target1340, i32 %7882
  store i32 %7883, ptr %7881, align 4
  %7884 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7877
  %7885 = load i32, ptr %7884, align 4
  %7886 = select i1 %7873, i32 %7870, i32 %7885
  store i32 %7886, ptr %7884, align 4
  %7887 = add i32 %7874, 1
  %7888 = select i1 %7873, i32 %7887, i32 %7874
  store i32 %7888, ptr %ready.count, align 4
  %7889 = load <8 x i1>, ptr %runnable.mask, align 1
  %7890 = or <8 x i1> %7889, %7864
  store <8 x i1> %7890, ptr %runnable.mask, align 1
  %7891 = load i8, ptr %frame.active, align 1
  %7892 = and i8 %7891, 2
  %7893 = icmp ne i8 %7892, 0
  %7894 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 1
  %7895 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 1
  %7896 = load <8 x i1>, ptr %7894, align 1
  %7897 = load <8 x i1>, ptr %7895, align 1
  %7898 = and <8 x i1> %7896, %7849
  %7899 = icmp eq <8 x i1> %7897, %7898
  %7900 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7899)
  %7901 = and i1 %7893, %7900
  %.splatinsert1343 = insertelement <8 x i1> poison, i1 %7901, i64 0
  %.splat1344 = shufflevector <8 x i1> %.splatinsert1343, <8 x i1> poison, <8 x i32> zeroinitializer
  %7902 = select <8 x i1> %.splat1344, <8 x i1> %7897, <8 x i1> zeroinitializer
  %7903 = select i1 %7901, <8 x i1> zeroinitializer, <8 x i1> %7898
  store <8 x i1> %7903, ptr %7894, align 1
  %7904 = select i1 %7901, <8 x i1> zeroinitializer, <8 x i1> %7897
  store <8 x i1> %7904, ptr %7895, align 1
  %7905 = and i8 %7891, -3
  %7906 = select i1 %7901, i8 %7905, i8 %7891
  store i8 %7906, ptr %frame.active, align 1
  %7907 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7908 = extractelement <8 x i32> %7907, i32 1
  %7909 = load <8 x i32>, ptr %frame.static.id, align 32
  %7910 = extractelement <8 x i32> %7909, i32 1
  %convergence.target.pointer1345 = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %7910
  %convergence.dynamic.target1346 = load i32, ptr %convergence.target.pointer1345, align 4
  %7911 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7902)
  %7912 = load i32, ptr %ready.count, align 4
  %7913 = icmp uge i32 %7912, 8
  %7914 = and i1 %7911, %7913
  br i1 %7914, label %ready.overflow.trap1347, label %ready.overflow.resume1348

ready.overflow.trap1347:                          ; preds = %ready.overflow.resume1342
  call void @llvm.trap()
  unreachable

ready.overflow.resume1348:                        ; preds = %ready.overflow.resume1342
  %7915 = select i1 %7911, i32 %7912, i32 0
  %7916 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7915
  %7917 = load <8 x i1>, ptr %7916, align 1
  %7918 = select i1 %7911, <8 x i1> %7902, <8 x i1> %7917
  store <8 x i1> %7918, ptr %7916, align 1
  %7919 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7915
  %7920 = load i32, ptr %7919, align 4
  %7921 = select i1 %7911, i32 %convergence.dynamic.target1346, i32 %7920
  store i32 %7921, ptr %7919, align 4
  %7922 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7915
  %7923 = load i32, ptr %7922, align 4
  %7924 = select i1 %7911, i32 %7908, i32 %7923
  store i32 %7924, ptr %7922, align 4
  %7925 = add i32 %7912, 1
  %7926 = select i1 %7911, i32 %7925, i32 %7912
  store i32 %7926, ptr %ready.count, align 4
  %7927 = load <8 x i1>, ptr %runnable.mask, align 1
  %7928 = or <8 x i1> %7927, %7902
  store <8 x i1> %7928, ptr %runnable.mask, align 1
  %7929 = load i8, ptr %frame.active, align 1
  %7930 = and i8 %7929, 4
  %7931 = icmp ne i8 %7930, 0
  %7932 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 2
  %7933 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 2
  %7934 = load <8 x i1>, ptr %7932, align 1
  %7935 = load <8 x i1>, ptr %7933, align 1
  %7936 = and <8 x i1> %7934, %7849
  %7937 = icmp eq <8 x i1> %7935, %7936
  %7938 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7937)
  %7939 = and i1 %7931, %7938
  %.splatinsert1349 = insertelement <8 x i1> poison, i1 %7939, i64 0
  %.splat1350 = shufflevector <8 x i1> %.splatinsert1349, <8 x i1> poison, <8 x i32> zeroinitializer
  %7940 = select <8 x i1> %.splat1350, <8 x i1> %7935, <8 x i1> zeroinitializer
  %7941 = select i1 %7939, <8 x i1> zeroinitializer, <8 x i1> %7936
  store <8 x i1> %7941, ptr %7932, align 1
  %7942 = select i1 %7939, <8 x i1> zeroinitializer, <8 x i1> %7935
  store <8 x i1> %7942, ptr %7933, align 1
  %7943 = and i8 %7929, -5
  %7944 = select i1 %7939, i8 %7943, i8 %7929
  store i8 %7944, ptr %frame.active, align 1
  %7945 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7946 = extractelement <8 x i32> %7945, i32 2
  %7947 = load <8 x i32>, ptr %frame.static.id, align 32
  %7948 = extractelement <8 x i32> %7947, i32 2
  %convergence.target.pointer1351 = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %7948
  %convergence.dynamic.target1352 = load i32, ptr %convergence.target.pointer1351, align 4
  %7949 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7940)
  %7950 = load i32, ptr %ready.count, align 4
  %7951 = icmp uge i32 %7950, 8
  %7952 = and i1 %7949, %7951
  br i1 %7952, label %ready.overflow.trap1353, label %ready.overflow.resume1354

ready.overflow.trap1353:                          ; preds = %ready.overflow.resume1348
  call void @llvm.trap()
  unreachable

ready.overflow.resume1354:                        ; preds = %ready.overflow.resume1348
  %7953 = select i1 %7949, i32 %7950, i32 0
  %7954 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7953
  %7955 = load <8 x i1>, ptr %7954, align 1
  %7956 = select i1 %7949, <8 x i1> %7940, <8 x i1> %7955
  store <8 x i1> %7956, ptr %7954, align 1
  %7957 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7953
  %7958 = load i32, ptr %7957, align 4
  %7959 = select i1 %7949, i32 %convergence.dynamic.target1352, i32 %7958
  store i32 %7959, ptr %7957, align 4
  %7960 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7953
  %7961 = load i32, ptr %7960, align 4
  %7962 = select i1 %7949, i32 %7946, i32 %7961
  store i32 %7962, ptr %7960, align 4
  %7963 = add i32 %7950, 1
  %7964 = select i1 %7949, i32 %7963, i32 %7950
  store i32 %7964, ptr %ready.count, align 4
  %7965 = load <8 x i1>, ptr %runnable.mask, align 1
  %7966 = or <8 x i1> %7965, %7940
  store <8 x i1> %7966, ptr %runnable.mask, align 1
  %7967 = load i8, ptr %frame.active, align 1
  %7968 = and i8 %7967, 8
  %7969 = icmp ne i8 %7968, 0
  %7970 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 3
  %7971 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 3
  %7972 = load <8 x i1>, ptr %7970, align 1
  %7973 = load <8 x i1>, ptr %7971, align 1
  %7974 = and <8 x i1> %7972, %7849
  %7975 = icmp eq <8 x i1> %7973, %7974
  %7976 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7975)
  %7977 = and i1 %7969, %7976
  %.splatinsert1355 = insertelement <8 x i1> poison, i1 %7977, i64 0
  %.splat1356 = shufflevector <8 x i1> %.splatinsert1355, <8 x i1> poison, <8 x i32> zeroinitializer
  %7978 = select <8 x i1> %.splat1356, <8 x i1> %7973, <8 x i1> zeroinitializer
  %7979 = select i1 %7977, <8 x i1> zeroinitializer, <8 x i1> %7974
  store <8 x i1> %7979, ptr %7970, align 1
  %7980 = select i1 %7977, <8 x i1> zeroinitializer, <8 x i1> %7973
  store <8 x i1> %7980, ptr %7971, align 1
  %7981 = and i8 %7967, -9
  %7982 = select i1 %7977, i8 %7981, i8 %7967
  store i8 %7982, ptr %frame.active, align 1
  %7983 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7984 = extractelement <8 x i32> %7983, i32 3
  %7985 = load <8 x i32>, ptr %frame.static.id, align 32
  %7986 = extractelement <8 x i32> %7985, i32 3
  %convergence.target.pointer1357 = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %7986
  %convergence.dynamic.target1358 = load i32, ptr %convergence.target.pointer1357, align 4
  %7987 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7978)
  %7988 = load i32, ptr %ready.count, align 4
  %7989 = icmp uge i32 %7988, 8
  %7990 = and i1 %7987, %7989
  br i1 %7990, label %ready.overflow.trap1359, label %ready.overflow.resume1360

ready.overflow.trap1359:                          ; preds = %ready.overflow.resume1354
  call void @llvm.trap()
  unreachable

ready.overflow.resume1360:                        ; preds = %ready.overflow.resume1354
  %7991 = select i1 %7987, i32 %7988, i32 0
  %7992 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7991
  %7993 = load <8 x i1>, ptr %7992, align 1
  %7994 = select i1 %7987, <8 x i1> %7978, <8 x i1> %7993
  store <8 x i1> %7994, ptr %7992, align 1
  %7995 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7991
  %7996 = load i32, ptr %7995, align 4
  %7997 = select i1 %7987, i32 %convergence.dynamic.target1358, i32 %7996
  store i32 %7997, ptr %7995, align 4
  %7998 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7991
  %7999 = load i32, ptr %7998, align 4
  %8000 = select i1 %7987, i32 %7984, i32 %7999
  store i32 %8000, ptr %7998, align 4
  %8001 = add i32 %7988, 1
  %8002 = select i1 %7987, i32 %8001, i32 %7988
  store i32 %8002, ptr %ready.count, align 4
  %8003 = load <8 x i1>, ptr %runnable.mask, align 1
  %8004 = or <8 x i1> %8003, %7978
  store <8 x i1> %8004, ptr %runnable.mask, align 1
  %8005 = load i8, ptr %frame.active, align 1
  %8006 = and i8 %8005, 16
  %8007 = icmp ne i8 %8006, 0
  %8008 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 4
  %8009 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 4
  %8010 = load <8 x i1>, ptr %8008, align 1
  %8011 = load <8 x i1>, ptr %8009, align 1
  %8012 = and <8 x i1> %8010, %7849
  %8013 = icmp eq <8 x i1> %8011, %8012
  %8014 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8013)
  %8015 = and i1 %8007, %8014
  %.splatinsert1361 = insertelement <8 x i1> poison, i1 %8015, i64 0
  %.splat1362 = shufflevector <8 x i1> %.splatinsert1361, <8 x i1> poison, <8 x i32> zeroinitializer
  %8016 = select <8 x i1> %.splat1362, <8 x i1> %8011, <8 x i1> zeroinitializer
  %8017 = select i1 %8015, <8 x i1> zeroinitializer, <8 x i1> %8012
  store <8 x i1> %8017, ptr %8008, align 1
  %8018 = select i1 %8015, <8 x i1> zeroinitializer, <8 x i1> %8011
  store <8 x i1> %8018, ptr %8009, align 1
  %8019 = and i8 %8005, -17
  %8020 = select i1 %8015, i8 %8019, i8 %8005
  store i8 %8020, ptr %frame.active, align 1
  %8021 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8022 = extractelement <8 x i32> %8021, i32 4
  %8023 = load <8 x i32>, ptr %frame.static.id, align 32
  %8024 = extractelement <8 x i32> %8023, i32 4
  %convergence.target.pointer1363 = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %8024
  %convergence.dynamic.target1364 = load i32, ptr %convergence.target.pointer1363, align 4
  %8025 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8016)
  %8026 = load i32, ptr %ready.count, align 4
  %8027 = icmp uge i32 %8026, 8
  %8028 = and i1 %8025, %8027
  br i1 %8028, label %ready.overflow.trap1365, label %ready.overflow.resume1366

ready.overflow.trap1365:                          ; preds = %ready.overflow.resume1360
  call void @llvm.trap()
  unreachable

ready.overflow.resume1366:                        ; preds = %ready.overflow.resume1360
  %8029 = select i1 %8025, i32 %8026, i32 0
  %8030 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8029
  %8031 = load <8 x i1>, ptr %8030, align 1
  %8032 = select i1 %8025, <8 x i1> %8016, <8 x i1> %8031
  store <8 x i1> %8032, ptr %8030, align 1
  %8033 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8029
  %8034 = load i32, ptr %8033, align 4
  %8035 = select i1 %8025, i32 %convergence.dynamic.target1364, i32 %8034
  store i32 %8035, ptr %8033, align 4
  %8036 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8029
  %8037 = load i32, ptr %8036, align 4
  %8038 = select i1 %8025, i32 %8022, i32 %8037
  store i32 %8038, ptr %8036, align 4
  %8039 = add i32 %8026, 1
  %8040 = select i1 %8025, i32 %8039, i32 %8026
  store i32 %8040, ptr %ready.count, align 4
  %8041 = load <8 x i1>, ptr %runnable.mask, align 1
  %8042 = or <8 x i1> %8041, %8016
  store <8 x i1> %8042, ptr %runnable.mask, align 1
  %8043 = load i8, ptr %frame.active, align 1
  %8044 = and i8 %8043, 32
  %8045 = icmp ne i8 %8044, 0
  %8046 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 5
  %8047 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 5
  %8048 = load <8 x i1>, ptr %8046, align 1
  %8049 = load <8 x i1>, ptr %8047, align 1
  %8050 = and <8 x i1> %8048, %7849
  %8051 = icmp eq <8 x i1> %8049, %8050
  %8052 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8051)
  %8053 = and i1 %8045, %8052
  %.splatinsert1367 = insertelement <8 x i1> poison, i1 %8053, i64 0
  %.splat1368 = shufflevector <8 x i1> %.splatinsert1367, <8 x i1> poison, <8 x i32> zeroinitializer
  %8054 = select <8 x i1> %.splat1368, <8 x i1> %8049, <8 x i1> zeroinitializer
  %8055 = select i1 %8053, <8 x i1> zeroinitializer, <8 x i1> %8050
  store <8 x i1> %8055, ptr %8046, align 1
  %8056 = select i1 %8053, <8 x i1> zeroinitializer, <8 x i1> %8049
  store <8 x i1> %8056, ptr %8047, align 1
  %8057 = and i8 %8043, -33
  %8058 = select i1 %8053, i8 %8057, i8 %8043
  store i8 %8058, ptr %frame.active, align 1
  %8059 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8060 = extractelement <8 x i32> %8059, i32 5
  %8061 = load <8 x i32>, ptr %frame.static.id, align 32
  %8062 = extractelement <8 x i32> %8061, i32 5
  %convergence.target.pointer1369 = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %8062
  %convergence.dynamic.target1370 = load i32, ptr %convergence.target.pointer1369, align 4
  %8063 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8054)
  %8064 = load i32, ptr %ready.count, align 4
  %8065 = icmp uge i32 %8064, 8
  %8066 = and i1 %8063, %8065
  br i1 %8066, label %ready.overflow.trap1371, label %ready.overflow.resume1372

ready.overflow.trap1371:                          ; preds = %ready.overflow.resume1366
  call void @llvm.trap()
  unreachable

ready.overflow.resume1372:                        ; preds = %ready.overflow.resume1366
  %8067 = select i1 %8063, i32 %8064, i32 0
  %8068 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8067
  %8069 = load <8 x i1>, ptr %8068, align 1
  %8070 = select i1 %8063, <8 x i1> %8054, <8 x i1> %8069
  store <8 x i1> %8070, ptr %8068, align 1
  %8071 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8067
  %8072 = load i32, ptr %8071, align 4
  %8073 = select i1 %8063, i32 %convergence.dynamic.target1370, i32 %8072
  store i32 %8073, ptr %8071, align 4
  %8074 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8067
  %8075 = load i32, ptr %8074, align 4
  %8076 = select i1 %8063, i32 %8060, i32 %8075
  store i32 %8076, ptr %8074, align 4
  %8077 = add i32 %8064, 1
  %8078 = select i1 %8063, i32 %8077, i32 %8064
  store i32 %8078, ptr %ready.count, align 4
  %8079 = load <8 x i1>, ptr %runnable.mask, align 1
  %8080 = or <8 x i1> %8079, %8054
  store <8 x i1> %8080, ptr %runnable.mask, align 1
  %8081 = load i8, ptr %frame.active, align 1
  %8082 = and i8 %8081, 64
  %8083 = icmp ne i8 %8082, 0
  %8084 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 6
  %8085 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 6
  %8086 = load <8 x i1>, ptr %8084, align 1
  %8087 = load <8 x i1>, ptr %8085, align 1
  %8088 = and <8 x i1> %8086, %7849
  %8089 = icmp eq <8 x i1> %8087, %8088
  %8090 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8089)
  %8091 = and i1 %8083, %8090
  %.splatinsert1373 = insertelement <8 x i1> poison, i1 %8091, i64 0
  %.splat1374 = shufflevector <8 x i1> %.splatinsert1373, <8 x i1> poison, <8 x i32> zeroinitializer
  %8092 = select <8 x i1> %.splat1374, <8 x i1> %8087, <8 x i1> zeroinitializer
  %8093 = select i1 %8091, <8 x i1> zeroinitializer, <8 x i1> %8088
  store <8 x i1> %8093, ptr %8084, align 1
  %8094 = select i1 %8091, <8 x i1> zeroinitializer, <8 x i1> %8087
  store <8 x i1> %8094, ptr %8085, align 1
  %8095 = and i8 %8081, -65
  %8096 = select i1 %8091, i8 %8095, i8 %8081
  store i8 %8096, ptr %frame.active, align 1
  %8097 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8098 = extractelement <8 x i32> %8097, i32 6
  %8099 = load <8 x i32>, ptr %frame.static.id, align 32
  %8100 = extractelement <8 x i32> %8099, i32 6
  %convergence.target.pointer1375 = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %8100
  %convergence.dynamic.target1376 = load i32, ptr %convergence.target.pointer1375, align 4
  %8101 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8092)
  %8102 = load i32, ptr %ready.count, align 4
  %8103 = icmp uge i32 %8102, 8
  %8104 = and i1 %8101, %8103
  br i1 %8104, label %ready.overflow.trap1377, label %ready.overflow.resume1378

ready.overflow.trap1377:                          ; preds = %ready.overflow.resume1372
  call void @llvm.trap()
  unreachable

ready.overflow.resume1378:                        ; preds = %ready.overflow.resume1372
  %8105 = select i1 %8101, i32 %8102, i32 0
  %8106 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8105
  %8107 = load <8 x i1>, ptr %8106, align 1
  %8108 = select i1 %8101, <8 x i1> %8092, <8 x i1> %8107
  store <8 x i1> %8108, ptr %8106, align 1
  %8109 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8105
  %8110 = load i32, ptr %8109, align 4
  %8111 = select i1 %8101, i32 %convergence.dynamic.target1376, i32 %8110
  store i32 %8111, ptr %8109, align 4
  %8112 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8105
  %8113 = load i32, ptr %8112, align 4
  %8114 = select i1 %8101, i32 %8098, i32 %8113
  store i32 %8114, ptr %8112, align 4
  %8115 = add i32 %8102, 1
  %8116 = select i1 %8101, i32 %8115, i32 %8102
  store i32 %8116, ptr %ready.count, align 4
  %8117 = load <8 x i1>, ptr %runnable.mask, align 1
  %8118 = or <8 x i1> %8117, %8092
  store <8 x i1> %8118, ptr %runnable.mask, align 1
  %8119 = load i8, ptr %frame.active, align 1
  %8120 = and i8 %8119, -128
  %8121 = icmp ne i8 %8120, 0
  %8122 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 7
  %8123 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 7
  %8124 = load <8 x i1>, ptr %8122, align 1
  %8125 = load <8 x i1>, ptr %8123, align 1
  %8126 = and <8 x i1> %8124, %7849
  %8127 = icmp eq <8 x i1> %8125, %8126
  %8128 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8127)
  %8129 = and i1 %8121, %8128
  %.splatinsert1379 = insertelement <8 x i1> poison, i1 %8129, i64 0
  %.splat1380 = shufflevector <8 x i1> %.splatinsert1379, <8 x i1> poison, <8 x i32> zeroinitializer
  %8130 = select <8 x i1> %.splat1380, <8 x i1> %8125, <8 x i1> zeroinitializer
  %8131 = select i1 %8129, <8 x i1> zeroinitializer, <8 x i1> %8126
  store <8 x i1> %8131, ptr %8122, align 1
  %8132 = select i1 %8129, <8 x i1> zeroinitializer, <8 x i1> %8125
  store <8 x i1> %8132, ptr %8123, align 1
  %8133 = and i8 %8119, 127
  %8134 = select i1 %8129, i8 %8133, i8 %8119
  store i8 %8134, ptr %frame.active, align 1
  %8135 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8136 = extractelement <8 x i32> %8135, i32 7
  %8137 = load <8 x i32>, ptr %frame.static.id, align 32
  %8138 = extractelement <8 x i32> %8137, i32 7
  %convergence.target.pointer1381 = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %8138
  %convergence.dynamic.target1382 = load i32, ptr %convergence.target.pointer1381, align 4
  %8139 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8130)
  %8140 = load i32, ptr %ready.count, align 4
  %8141 = icmp uge i32 %8140, 8
  %8142 = and i1 %8139, %8141
  br i1 %8142, label %ready.overflow.trap1383, label %ready.overflow.resume1384

ready.overflow.trap1383:                          ; preds = %ready.overflow.resume1378
  call void @llvm.trap()
  unreachable

ready.overflow.resume1384:                        ; preds = %ready.overflow.resume1378
  %8143 = select i1 %8139, i32 %8140, i32 0
  %8144 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8143
  %8145 = load <8 x i1>, ptr %8144, align 1
  %8146 = select i1 %8139, <8 x i1> %8130, <8 x i1> %8145
  store <8 x i1> %8146, ptr %8144, align 1
  %8147 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8143
  %8148 = load i32, ptr %8147, align 4
  %8149 = select i1 %8139, i32 %convergence.dynamic.target1382, i32 %8148
  store i32 %8149, ptr %8147, align 4
  %8150 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8143
  %8151 = load i32, ptr %8150, align 4
  %8152 = select i1 %8139, i32 %8136, i32 %8151
  store i32 %8152, ptr %8150, align 4
  %8153 = add i32 %8140, 1
  %8154 = select i1 %8139, i32 %8153, i32 %8140
  store i32 %8154, ptr %ready.count, align 4
  %8155 = load <8 x i1>, ptr %runnable.mask, align 1
  %8156 = or <8 x i1> %8155, %8130
  store <8 x i1> %8156, ptr %runnable.mask, align 1
  br label %return.frame.cleanup.done

varying.divergent1386:                            ; preds = %schedule.62
  %8157 = load i32, ptr %current.token, align 4
  %8158 = icmp ne i32 %8157, 0
  %8159 = sub i32 %8157, 1
  %8160 = select i1 %8158, i32 %8159, i32 0
  %8161 = load i8, ptr %frame.active, align 1
  %8162 = trunc i32 %8160 to i8
  %8163 = shl i8 1, %8162
  %8164 = and i8 %8161, %8163
  %8165 = icmp ne i8 %8164, 0
  %8166 = load <8 x i32>, ptr %frame.static.id, align 32
  %8167 = extractelement <8 x i32> %8166, i32 %8160
  %8168 = icmp eq i32 %8167, 22
  %8169 = and i1 %8165, %8168
  %8170 = and i1 %8158, %8169
  %8171 = xor i1 %8170, true
  %8172 = and i1 true, %8171
  %8173 = xor i8 %8161, -1
  %8174 = icmp ne i8 %8173, 0
  %8175 = xor i1 %8174, true
  %8176 = and i1 %8172, %8175
  br i1 %8176, label %convergence.overflow.trap1388, label %convergence.overflow.resume1389

varying.coherent1387:                             ; preds = %schedule.62
  br i1 %1026, label %varying.coherent.true1392, label %varying.coherent.false1393

convergence.overflow.trap1388:                    ; preds = %varying.divergent1386
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1389:                  ; preds = %varying.divergent1386
  %8177 = call i8 @llvm.cttz.i8(i8 %8173, i1 false)
  %8178 = zext i8 %8177 to i32
  %8179 = select i1 %8174, i32 %8178, i32 0
  %8180 = trunc i32 %8179 to i8
  %8181 = shl i8 1, %8180
  %8182 = or i8 %8161, %8181
  %8183 = select i1 %8172, i8 %8182, i8 %8161
  store i8 %8183, ptr %frame.active, align 1
  %8184 = load <8 x i32>, ptr %frame.static.id, align 32
  %8185 = extractelement <8 x i32> %8184, i32 %8179
  %8186 = select i1 %8172, i32 22, i32 %8185
  %8187 = load <8 x i32>, ptr %frame.static.id, align 32
  %8188 = insertelement <8 x i32> %8187, i32 %8186, i32 %8179
  store <8 x i32> %8188, ptr %frame.static.id, align 32
  %8189 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8190 = extractelement <8 x i32> %8189, i32 %8179
  %8191 = select i1 %8172, i32 %8157, i32 %8190
  %8192 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8193 = insertelement <8 x i32> %8192, i32 %8191, i32 %8179
  store <8 x i32> %8193, ptr %frame.parent.token, align 32
  %8194 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %8179
  %8195 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %8179
  %8196 = load <8 x i1>, ptr %8194, align 1
  %8197 = load <8 x i1>, ptr %8195, align 1
  %8198 = select i1 %8172, <8 x i1> %1016, <8 x i1> %8196
  store <8 x i1> %8198, ptr %8194, align 1
  %8199 = select i1 %8172, <8 x i1> zeroinitializer, <8 x i1> %8197
  store <8 x i1> %8199, ptr %8195, align 1
  %8200 = add i32 %8179, 1
  %8201 = select i1 %8170, i32 %8157, i32 %8200
  %8202 = select i1 true, i32 %8201, i32 %8157
  store i32 %8202, ptr %current.token, align 4
  %8203 = load i32, ptr %current.token, align 4
  %8204 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1023)
  %8205 = load i32, ptr %ready.count, align 4
  %8206 = icmp uge i32 %8205, 8
  %8207 = and i1 %8204, %8206
  br i1 %8207, label %ready.overflow.trap1390, label %ready.overflow.resume1391

ready.overflow.trap1390:                          ; preds = %convergence.overflow.resume1389
  call void @llvm.trap()
  unreachable

ready.overflow.resume1391:                        ; preds = %convergence.overflow.resume1389
  %8208 = select i1 %8204, i32 %8205, i32 0
  %8209 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8208
  %8210 = load <8 x i1>, ptr %8209, align 1
  %8211 = select i1 %8204, <8 x i1> %1023, <8 x i1> %8210
  store <8 x i1> %8211, ptr %8209, align 1
  %8212 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8208
  %8213 = load i32, ptr %8212, align 4
  %8214 = select i1 %8204, i32 63, i32 %8213
  store i32 %8214, ptr %8212, align 4
  %8215 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8208
  %8216 = load i32, ptr %8215, align 4
  %8217 = select i1 %8204, i32 %8203, i32 %8216
  store i32 %8217, ptr %8215, align 4
  %8218 = add i32 %8205, 1
  %8219 = select i1 %8204, i32 %8218, i32 %8205
  store i32 %8219, ptr %ready.count, align 4
  %8220 = load <8 x i1>, ptr %runnable.mask, align 1
  %8221 = or <8 x i1> %8220, %1023
  store <8 x i1> %8221, ptr %runnable.mask, align 1
  store <8 x i1> %1025, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1392:                        ; preds = %varying.coherent1387
  store <8 x i1> %1016, ptr %current.mask, align 1
  %8222 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1016)
  br i1 %8222, label %schedule.63, label %scheduler.loop

varying.coherent.false1393:                       ; preds = %varying.coherent1387
  store <8 x i1> %1016, ptr %current.mask, align 1
  %8223 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1016)
  br i1 %8223, label %schedule.2, label %scheduler.loop

varying.divergent1399:                            ; preds = %schedule.63
  %8224 = load i32, ptr %current.token, align 4
  %8225 = icmp ne i32 %8224, 0
  %8226 = sub i32 %8224, 1
  %8227 = select i1 %8225, i32 %8226, i32 0
  %8228 = load i8, ptr %frame.active, align 1
  %8229 = trunc i32 %8227 to i8
  %8230 = shl i8 1, %8229
  %8231 = and i8 %8228, %8230
  %8232 = icmp ne i8 %8231, 0
  %8233 = load <8 x i32>, ptr %frame.static.id, align 32
  %8234 = extractelement <8 x i32> %8233, i32 %8227
  %8235 = icmp eq i32 %8234, 23
  %8236 = and i1 %8232, %8235
  %8237 = and i1 %8225, %8236
  %8238 = xor i1 %8237, true
  %8239 = and i1 true, %8238
  %8240 = xor i8 %8228, -1
  %8241 = icmp ne i8 %8240, 0
  %8242 = xor i1 %8241, true
  %8243 = and i1 %8239, %8242
  br i1 %8243, label %convergence.overflow.trap1401, label %convergence.overflow.resume1402

varying.coherent1400:                             ; preds = %schedule.63
  br i1 %1061, label %varying.coherent.true1405, label %varying.coherent.false1406

convergence.overflow.trap1401:                    ; preds = %varying.divergent1399
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1402:                  ; preds = %varying.divergent1399
  %8244 = call i8 @llvm.cttz.i8(i8 %8240, i1 false)
  %8245 = zext i8 %8244 to i32
  %8246 = select i1 %8241, i32 %8245, i32 0
  %8247 = trunc i32 %8246 to i8
  %8248 = shl i8 1, %8247
  %8249 = or i8 %8228, %8248
  %8250 = select i1 %8239, i8 %8249, i8 %8228
  store i8 %8250, ptr %frame.active, align 1
  %8251 = load <8 x i32>, ptr %frame.static.id, align 32
  %8252 = extractelement <8 x i32> %8251, i32 %8246
  %8253 = select i1 %8239, i32 23, i32 %8252
  %8254 = load <8 x i32>, ptr %frame.static.id, align 32
  %8255 = insertelement <8 x i32> %8254, i32 %8253, i32 %8246
  store <8 x i32> %8255, ptr %frame.static.id, align 32
  %8256 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8257 = extractelement <8 x i32> %8256, i32 %8246
  %8258 = select i1 %8239, i32 %8224, i32 %8257
  %8259 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8260 = insertelement <8 x i32> %8259, i32 %8258, i32 %8246
  store <8 x i32> %8260, ptr %frame.parent.token, align 32
  %8261 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %8246
  %8262 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %8246
  %8263 = load <8 x i1>, ptr %8261, align 1
  %8264 = load <8 x i1>, ptr %8262, align 1
  %8265 = select i1 %8239, <8 x i1> %1029, <8 x i1> %8263
  store <8 x i1> %8265, ptr %8261, align 1
  %8266 = select i1 %8239, <8 x i1> zeroinitializer, <8 x i1> %8264
  store <8 x i1> %8266, ptr %8262, align 1
  %8267 = add i32 %8246, 1
  %8268 = select i1 %8237, i32 %8224, i32 %8267
  %8269 = select i1 true, i32 %8268, i32 %8224
  store i32 %8269, ptr %current.token, align 4
  %8270 = load <8 x float>, ptr %.slot243, align 32
  %8271 = select <8 x i1> %1060, <8 x float> zeroinitializer, <8 x float> %8270
  store <8 x float> %8271, ptr %.slot243, align 32
  %8272 = load i32, ptr %current.token, align 4
  %8273 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1058)
  %8274 = load i32, ptr %ready.count, align 4
  %8275 = icmp uge i32 %8274, 8
  %8276 = and i1 %8273, %8275
  br i1 %8276, label %ready.overflow.trap1403, label %ready.overflow.resume1404

ready.overflow.trap1403:                          ; preds = %convergence.overflow.resume1402
  call void @llvm.trap()
  unreachable

ready.overflow.resume1404:                        ; preds = %convergence.overflow.resume1402
  %8277 = select i1 %8273, i32 %8274, i32 0
  %8278 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8277
  %8279 = load <8 x i1>, ptr %8278, align 1
  %8280 = select i1 %8273, <8 x i1> %1058, <8 x i1> %8279
  store <8 x i1> %8280, ptr %8278, align 1
  %8281 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8277
  %8282 = load i32, ptr %8281, align 4
  %8283 = select i1 %8273, i32 64, i32 %8282
  store i32 %8283, ptr %8281, align 4
  %8284 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8277
  %8285 = load i32, ptr %8284, align 4
  %8286 = select i1 %8273, i32 %8272, i32 %8285
  store i32 %8286, ptr %8284, align 4
  %8287 = add i32 %8274, 1
  %8288 = select i1 %8273, i32 %8287, i32 %8274
  store i32 %8288, ptr %ready.count, align 4
  %8289 = load <8 x i1>, ptr %runnable.mask, align 1
  %8290 = or <8 x i1> %8289, %1058
  store <8 x i1> %8290, ptr %runnable.mask, align 1
  store <8 x i1> %1060, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1405:                        ; preds = %varying.coherent1400
  store <8 x i1> %1029, ptr %current.mask, align 1
  %8291 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1029)
  br i1 %8291, label %schedule.64, label %scheduler.loop

varying.coherent.false1406:                       ; preds = %varying.coherent1400
  %8292 = load <8 x float>, ptr %.slot243, align 32
  %8293 = select <8 x i1> %1029, <8 x float> zeroinitializer, <8 x float> %8292
  store <8 x float> %8293, ptr %.slot243, align 32
  store <8 x i1> %1029, ptr %current.mask, align 1
  %8294 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1029)
  br i1 %8294, label %schedule.65, label %scheduler.loop

convergence.cascade1408:                          ; preds = %convergence.cascade1408, %schedule.65
  %convergence.cascade.flow1412 = phi <8 x i1> [ %1077, %schedule.65 ], [ %8337, %convergence.cascade1408 ]
  %convergence.cascade.depth1413 = phi i32 [ 0, %schedule.65 ], [ %8338, %convergence.cascade1408 ]
  %8295 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1412)
  %8296 = load i32, ptr %current.token, align 4
  %8297 = icmp ne i32 %8296, 0
  %8298 = and i1 %8295, %8297
  %8299 = sub i32 %8296, 1
  %8300 = select i1 %8298, i32 %8299, i32 0
  %8301 = load i8, ptr %frame.active, align 1
  %8302 = trunc i32 %8300 to i8
  %8303 = shl i8 1, %8302
  %8304 = and i8 %8301, %8303
  %8305 = icmp ne i8 %8304, 0
  %8306 = load <8 x i32>, ptr %frame.static.id, align 32
  %8307 = extractelement <8 x i32> %8306, i32 %8300
  %convergence.target.pointer1414 = getelementptr inbounds [24 x i32], ptr @convergence.targets, i32 0, i32 %8307
  %convergence.dynamic.target1415 = load i32, ptr %convergence.target.pointer1414, align 4
  %8308 = icmp eq i32 %convergence.dynamic.target1415, 65
  %8309 = and i1 %8305, %8308
  %8310 = and i1 %8298, %8309
  %8311 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %8300
  %8312 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %8300
  %8313 = load <8 x i1>, ptr %8311, align 1
  %8314 = load <8 x i1>, ptr %8312, align 1
  %8315 = or <8 x i1> %8314, %convergence.cascade.flow1412
  %8316 = load <8 x i1>, ptr %live.mask, align 1
  %8317 = and <8 x i1> %8313, %8316
  %8318 = icmp eq <8 x i1> %8315, %8317
  %8319 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8318)
  %8320 = and i1 %8310, %8319
  %8321 = select i1 %8320, <8 x i1> zeroinitializer, <8 x i1> %8315
  %8322 = select i1 %8310, <8 x i1> %8321, <8 x i1> %8314
  store <8 x i1> %8322, ptr %8312, align 1
  %8323 = select i1 %8320, <8 x i1> zeroinitializer, <8 x i1> %8313
  store <8 x i1> %8323, ptr %8311, align 1
  %8324 = trunc i32 %8300 to i8
  %8325 = shl i8 1, %8324
  %8326 = xor i8 %8325, -1
  %8327 = and i8 %8301, %8326
  %8328 = select i1 %8320, i8 %8327, i8 %8301
  store i8 %8328, ptr %frame.active, align 1
  %.splatinsert1416 = insertelement <8 x i1> poison, i1 %8310, i64 0
  %.splat1417 = shufflevector <8 x i1> %.splatinsert1416, <8 x i1> poison, <8 x i32> zeroinitializer
  %8329 = and <8 x i1> %convergence.cascade.flow1412, %.splat1417
  %8330 = load <8 x i1>, ptr %runnable.mask, align 1
  %8331 = xor <8 x i1> %8329, splat (i1 true)
  %8332 = and <8 x i1> %8330, %8331
  store <8 x i1> %8332, ptr %runnable.mask, align 1
  %.splatinsert1418 = insertelement <8 x i1> poison, i1 %8320, i64 0
  %.splat1419 = shufflevector <8 x i1> %.splatinsert1418, <8 x i1> poison, <8 x i32> zeroinitializer
  %8333 = select <8 x i1> %.splat1419, <8 x i1> %8315, <8 x i1> zeroinitializer
  %8334 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8335 = extractelement <8 x i32> %8334, i32 %8300
  %8336 = select i1 %8320, i32 %8335, i32 %8296
  store i32 %8336, ptr %current.token, align 4
  %.splatinsert1420 = insertelement <8 x i1> poison, i1 %8310, i64 0
  %.splat1421 = shufflevector <8 x i1> %.splatinsert1420, <8 x i1> poison, <8 x i32> zeroinitializer
  %8337 = select <8 x i1> %.splat1421, <8 x i1> %8333, <8 x i1> %convergence.cascade.flow1412
  %8338 = add i32 %convergence.cascade.depth1413, 1
  %8339 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8337)
  %8340 = icmp ult i32 %8338, 8
  %8341 = and i1 %8339, %8340
  %8342 = and i1 %8310, %8341
  %convergence.parent.token1422 = load i32, ptr %current.token, align 4
  %convergence.parent.present1423 = icmp ne i32 %convergence.parent.token1422, 0
  %8343 = and i1 %8342, %convergence.parent.present1423
  br i1 %8343, label %convergence.cascade1408, label %convergence.cascade.exit1409

convergence.cascade.exit1409:                     ; preds = %convergence.cascade1408, %schedule.65
  %convergence.cascade.result1424 = phi <8 x i1> [ %1077, %schedule.65 ], [ %8337, %convergence.cascade1408 ]
  %8344 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1424)
  br i1 %8344, label %convergence.target.65.ready, label %scheduler.loop

convergence.target.65.ready:                      ; preds = %convergence.cascade.exit1409
  %8345 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1424)
  %8346 = bitcast <8 x i1> %convergence.cascade.result1424 to i8
  %8347 = call i8 @llvm.cttz.i8(i8 %8346, i1 false)
  %8348 = zext i8 %8347 to i32
  %8349 = select i1 %8345, i32 %8348, i32 0
  %tile_snapshot.spill.load1425 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %8350 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1425, 0
  %8351 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1425, 1
  %.state1426 = load <8 x i64>, ptr %.slot241, align 64
  %8352 = mul <8 x i64> %.state1426, splat (i64 4)
  %8353 = add <8 x i64> %8351, %8352
  %8354 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8350, 0
  %8355 = insertvalue { <8 x ptr>, <8 x i64> } %8354, <8 x i64> %8353, 1
  %.state1427 = load <8 x float>, ptr %.slot243, align 32
  %8356 = extractvalue { <8 x ptr>, <8 x i64> } %8355, 0
  %8357 = extractvalue { <8 x ptr>, <8 x i64> } %8355, 1
  %8358 = getelementptr i8, <8 x ptr> %8356, <8 x i64> %8357
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state1427, <8 x ptr> align 1 %8358, <8 x i1> %convergence.cascade.result1424)
  %.state1428 = load <8 x i64>, ptr %.slot241, align 64
  %8359 = add <8 x i64> %.state1428, splat (i64 1)
  %8360 = load <8 x i64>, ptr %.slot241, align 64
  %8361 = select <8 x i1> %convergence.cascade.result1424, <8 x i64> %8359, <8 x i64> %8360
  store <8 x i64> %8361, ptr %.slot241, align 64
  store <8 x i1> %convergence.cascade.result1424, ptr %current.mask, align 1
  %8362 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1424)
  br i1 %8362, label %schedule.62, label %scheduler.loop
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nounwind willreturn
define private void @llm_attention.contiguous_copy(ptr %0, i64 %1, ptr %2) #2 {
entry:
  %3 = getelementptr i32, ptr %0, i64 %1
  br label %copy.loop

copy.loop:                                        ; preds = %copy.chunk, %entry
  %copy.index = phi i64 [ 0, %entry ], [ %10, %copy.chunk ]
  %4 = icmp ult i64 %copy.index, 40
  br i1 %4, label %copy.chunk, label %copy.next

copy.chunk:                                       ; preds = %copy.loop
  %5 = mul i64 %copy.index, 4
  %6 = add i64 0, %5
  %7 = getelementptr i32, ptr %3, i64 %6
  %8 = load <4 x i32>, ptr %7, align 4
  %9 = getelementptr i32, ptr %2, i64 %6
  store <4 x i32> %8, ptr %9, align 4
  %10 = add i64 %copy.index, 1
  br label %copy.loop

copy.next:                                        ; preds = %copy.loop
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.and.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #3

; Function Attrs: nounwind willreturn
define private void @llm_attention.contiguous_copy.1(ptr %0, i64 %1, ptr %2) #2 {
entry:
  %3 = getelementptr i32, ptr %0, i64 %1
  br label %copy.loop

copy.loop:                                        ; preds = %copy.chunk, %entry
  %copy.index = phi i64 [ 0, %entry ], [ %10, %copy.chunk ]
  %4 = icmp ult i64 %copy.index, 160
  br i1 %4, label %copy.chunk, label %copy.next

copy.chunk:                                       ; preds = %copy.loop
  %5 = mul i64 %copy.index, 4
  %6 = add i64 0, %5
  %7 = getelementptr i32, ptr %3, i64 %6
  %8 = load <4 x i32>, ptr %7, align 4
  %9 = getelementptr i32, ptr %2, i64 %6
  store <4 x i32> %8, ptr %9, align 4
  %10 = add i64 %copy.index, 1
  br label %copy.loop

copy.next:                                        ; preds = %copy.loop
  ret void
}

; Function Attrs: nounwind willreturn
define private void @llm_attention.contiguous_copy.2(ptr %0, i64 %1, ptr %2) #2 {
entry:
  %3 = getelementptr i32, ptr %0, i64 %1
  br label %copy.loop

copy.loop:                                        ; preds = %copy.chunk, %entry
  %copy.index = phi i64 [ 0, %entry ], [ %10, %copy.chunk ]
  %4 = icmp ult i64 %copy.index, 192
  br i1 %4, label %copy.chunk, label %copy.next

copy.chunk:                                       ; preds = %copy.loop
  %5 = mul i64 %copy.index, 4
  %6 = add i64 0, %5
  %7 = getelementptr i32, ptr %3, i64 %6
  %8 = load <4 x i32>, ptr %7, align 4
  %9 = getelementptr i32, ptr %2, i64 %6
  store <4 x i32> %8, ptr %9, align 4
  %10 = add i64 %copy.index, 1
  br label %copy.loop

copy.next:                                        ; preds = %copy.loop
  ret void
}

; Function Attrs: nounwind willreturn
define private void @llm_attention.strided_mma(ptr %0, ptr %1, ptr %2, ptr %3) #4 {
entry:
  br label %mma.fold

mma.fold:                                         ; preds = %mma.fold.done3, %entry
  %mma.k = phi i64 [ 0, %entry ], [ %45, %mma.fold.done3 ]
  %mma.acc = phi i64 [ 0, %entry ], [ %mma.acc, %mma.fold.done3 ]
  %4 = icmp ult i64 %mma.k, 64
  br i1 %4, label %mma.update, label %mma.fold.done

mma.update:                                       ; preds = %mma.fold
  %5 = urem i64 %mma.k, 16
  %6 = udiv i64 %mma.k, 16
  %7 = urem i64 %6, 4
  %8 = mul i64 %7, 40
  %9 = add i64 0, %8
  %10 = udiv i64 %6, 4
  %11 = urem i64 %mma.k, 16
  %12 = mul i64 %11, 40
  %13 = add i64 0, %12
  %14 = udiv i64 %mma.k, 16
  %15 = urem i64 %14, 4
  %16 = udiv i64 %14, 4
  %17 = getelementptr float, ptr %2, i64 %mma.k
  %18 = load float, ptr %17, align 4
  %19 = getelementptr float, ptr %0, i64 %9
  %20 = load <4 x float>, ptr %19, align 4
  %21 = getelementptr float, ptr %1, i64 %13
  %22 = load <4 x float>, ptr %21, align 4
  %23 = fmul <4 x float> %20, %22
  br label %mma.fold1

mma.fold.done:                                    ; preds = %mma.fold
  ret void

mma.fold1:                                        ; preds = %mma.update2, %mma.update
  %mma.k4 = phi i64 [ 0, %mma.update ], [ %35, %mma.update2 ]
  %mma.acc5 = phi <4 x float> [ %23, %mma.update ], [ %34, %mma.update2 ]
  %24 = icmp ult i64 %mma.k4, 9
  br i1 %24, label %mma.update2, label %mma.fold.done3

mma.update2:                                      ; preds = %mma.fold1
  %25 = add i64 %mma.k4, 1
  %26 = mul i64 %25, 4
  %27 = add i64 %9, %26
  %28 = getelementptr float, ptr %0, i64 %27
  %29 = load <4 x float>, ptr %28, align 4
  %30 = add i64 %13, %26
  %31 = getelementptr float, ptr %1, i64 %30
  %32 = load <4 x float>, ptr %31, align 4
  %33 = fmul <4 x float> %29, %32
  %34 = fadd <4 x float> %mma.acc5, %33
  %35 = add i64 %mma.k4, 1
  br label %mma.fold1

mma.fold.done3:                                   ; preds = %mma.fold1
  %36 = extractelement <4 x float> %mma.acc5, i64 0
  %37 = extractelement <4 x float> %mma.acc5, i64 1
  %38 = extractelement <4 x float> %mma.acc5, i64 2
  %39 = extractelement <4 x float> %mma.acc5, i64 3
  %40 = fadd float %36, %37
  %41 = fadd float %38, %39
  %42 = fadd float %40, %41
  %43 = fadd float %18, %42
  %44 = getelementptr float, ptr %3, i64 %mma.k
  store float %43, ptr %44, align 4
  %45 = add i64 %mma.k, 1
  br label %mma.fold
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #5

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #6

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #7 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nounwind willreturn
define private void @llm_attention.strided_mma.3(ptr %0, ptr %1, ptr %2, ptr %3) #4 {
entry:
  br label %mma.fold

mma.fold:                                         ; preds = %mma.fold.done3, %entry
  %mma.k = phi i64 [ 0, %entry ], [ %23, %mma.fold.done3 ]
  %mma.acc = phi i64 [ 0, %entry ], [ %mma.acc, %mma.fold.done3 ]
  %4 = icmp ult i64 %mma.k, 4
  br i1 %4, label %mma.update, label %mma.fold.done

mma.update:                                       ; preds = %mma.fold
  %5 = mul i64 %mma.k, 48
  br label %mma.fold1

mma.fold.done:                                    ; preds = %mma.fold
  ret void

mma.fold1:                                        ; preds = %mma.fold.done8, %mma.update
  %mma.k4 = phi i64 [ 0, %mma.update ], [ %37, %mma.fold.done8 ]
  %mma.acc5 = phi i64 [ 0, %mma.update ], [ %mma.acc5, %mma.fold.done8 ]
  %6 = icmp ult i64 %mma.k4, 12
  br i1 %6, label %mma.update2, label %mma.fold.done3

mma.update2:                                      ; preds = %mma.fold1
  %7 = mul i64 %mma.k4, 4
  %8 = add i64 %5, %7
  %9 = urem i64 %8, 48
  %10 = udiv i64 %8, 48
  %11 = urem i64 %10, 4
  %12 = mul i64 %11, 16
  %13 = add i64 0, %12
  %14 = udiv i64 %10, 4
  %15 = urem i64 %8, 48
  %16 = mul i64 %15, 1
  %17 = add i64 0, %16
  %18 = udiv i64 %8, 48
  %19 = urem i64 %18, 4
  %20 = udiv i64 %18, 4
  %21 = getelementptr float, ptr %2, i64 %8
  %22 = load <4 x float>, ptr %21, align 4
  br label %mma.fold6

mma.fold.done3:                                   ; preds = %mma.fold1
  %23 = add i64 %mma.k, 1
  br label %mma.fold

mma.fold6:                                        ; preds = %mma.update7, %mma.update2
  %mma.k9 = phi i64 [ 0, %mma.update2 ], [ %35, %mma.update7 ]
  %mma.acc10 = phi <4 x float> [ %22, %mma.update2 ], [ %34, %mma.update7 ]
  %24 = icmp ult i64 %mma.k9, 16
  br i1 %24, label %mma.update7, label %mma.fold.done8

mma.update7:                                      ; preds = %mma.fold6
  %25 = mul i64 %mma.k9, 1
  %26 = add i64 %13, %25
  %27 = getelementptr float, ptr %0, i64 %26
  %28 = load float, ptr %27, align 4
  %.splatinsert = insertelement <4 x float> poison, float %28, i64 0
  %.splat = shufflevector <4 x float> %.splatinsert, <4 x float> poison, <4 x i32> zeroinitializer
  %29 = mul i64 %mma.k9, 48
  %30 = add i64 %17, %29
  %31 = getelementptr float, ptr %1, i64 %30
  %32 = load <4 x float>, ptr %31, align 4
  %33 = fmul <4 x float> %.splat, %32
  %34 = fadd <4 x float> %mma.acc10, %33
  %35 = add i64 %mma.k9, 1
  br label %mma.fold6

mma.fold.done8:                                   ; preds = %mma.fold6
  %36 = getelementptr float, ptr %3, i64 %8
  store <4 x float> %mma.acc10, ptr %36, align 4
  %37 = add i64 %mma.k4, 1
  br label %mma.fold1
}

define dso_local void @llm_attention.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #2 = { nounwind willreturn }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #4 = { nounwind willreturn "fp-contract"="off" }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #6 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #7 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }

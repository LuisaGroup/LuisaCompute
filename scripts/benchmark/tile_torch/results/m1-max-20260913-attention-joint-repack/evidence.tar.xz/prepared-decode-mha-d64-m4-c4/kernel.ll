; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_attention(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 256, i64 512, i64 768, i64 1024, i64 1280, i64 1536, i64 1792>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 2048
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4096, i64 8192, i64 12288, i64 16384, i64 20480, i64 24576, i64 28672>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 34816
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4096, i64 8192, i64 12288, i64 16384, i64 20480, i64 24576, i64 28672>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 67584
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 64, i64 128, i64 192, i64 256, i64 320, i64 384, i64 448>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 68096
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 64, i64 128, i64 192, i64 256, i64 320, i64 384, i64 448>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 68608
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 69120
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 64, i64 128, i64 192, i64 256, i64 320, i64 384, i64 448>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 69632
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 256, i64 512, i64 768, i64 1024, i64 1280, i64 1536, i64 1792>, 1
  %24 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace29 = load ptr, ptr %24, align 8
  %tile_snapshot.private30 = getelementptr inbounds i8, ptr %private.workspace29, i64 71680
  %.splatinsert31 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private30, i64 0
  %.splat32 = shufflevector <8 x ptr> %.splatinsert31, <8 x ptr> poison, <8 x i32> zeroinitializer
  %25 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat32, 0
  %26 = insertvalue { <8 x ptr>, <8 x i64> } %25, <8 x i64> <i64 0, i64 256, i64 512, i64 768, i64 1024, i64 1280, i64 1536, i64 1792>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill33 = alloca i64, align 8
  store i64 0, ptr %.spill33, align 4
  %.spill34 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill34, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.spill35 = alloca i64, align 8
  store i64 0, ptr %.spill35, align 4
  %.spill36 = alloca i64, align 8
  store i64 0, ptr %.spill36, align 4
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.slot37 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot37, align 32
  %.slot38 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot38, align 32
  %.slot39 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot39, align 32
  %.slot40 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot40, align 32
  %.slot41 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot41, align 32
  %.slot42 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot42, align 32
  %.slot43 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot43, align 32
  %.slot44 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot44, align 32
  %.slot45 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot45, align 32
  %.slot46 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot46, align 32
  %.slot47 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot47, align 32
  %.slot48 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot48, align 32
  %.slot49 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot49, align 32
  %.slot50 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot50, align 32
  %.slot51 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot51, align 32
  %.slot52 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot52, align 32
  %.slot53 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot53, align 32
  %.slot54 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot54, align 32
  %.slot55 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot55, align 32
  %.slot56 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot56, align 32
  %.slot57 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot57, align 32
  %.slot58 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot58, align 32
  %.slot59 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot59, align 32
  %.slot60 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot60, align 32
  %.slot61 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot61, align 32
  %.slot62 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot62, align 32
  %.slot63 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot63, align 32
  %.slot64 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot64, align 32
  %.slot65 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot65, align 32
  %.slot66 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot66, align 32
  %.slot67 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot67, align 32
  %.slot68 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot68, align 32
  %.slot69 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot69, align 32
  %.slot70 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot70, align 32
  %.slot71 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot71, align 32
  %.slot72 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot72, align 32
  %.slot73 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot73, align 32
  %.slot74 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot74, align 32
  %.slot75 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot75, align 32
  %.slot76 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot76, align 32
  %.slot77 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot77, align 32
  %.slot78 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot78, align 32
  %.slot79 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot79, align 32
  %.slot80 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot80, align 32
  %.slot81 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot81, align 32
  %.slot82 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot82, align 32
  %.slot83 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot83, align 32
  %.slot84 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot84, align 32
  %.slot85 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot85, align 32
  %.slot86 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot86, align 32
  %.slot87 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot87, align 32
  %.slot88 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot88, align 32
  %.slot89 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot89, align 32
  %.slot90 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot90, align 32
  %.slot91 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot91, align 32
  %.slot92 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot92, align 32
  %.slot93 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot93, align 32
  %.slot94 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot94, align 32
  %.slot95 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot95, align 32
  %.slot96 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot96, align 32
  %.slot97 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot97, align 32
  %.slot98 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot98, align 32
  %.slot99 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot99, align 32
  %.slot100 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot100, align 32
  %.slot101 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot101, align 32
  %.slot102 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot102, align 32
  %tile_snapshot.spill103 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill103, align 64
  %.spill104 = alloca i1, align 1
  store i1 false, ptr %.spill104, align 1
  %.spill105 = alloca i1, align 1
  store i1 false, ptr %.spill105, align 1
  %.spill106 = alloca i1, align 1
  store i1 false, ptr %.spill106, align 1
  %.spill107 = alloca i1, align 1
  store i1 false, ptr %.spill107, align 1
  %.spill108 = alloca i1, align 1
  store i1 false, ptr %.spill108, align 1
  %.spill109 = alloca i1, align 1
  store i1 false, ptr %.spill109, align 1
  %.spill110 = alloca i1, align 1
  store i1 false, ptr %.spill110, align 1
  %.spill111 = alloca i1, align 1
  store i1 false, ptr %.spill111, align 1
  %.spill112 = alloca i1, align 1
  store i1 false, ptr %.spill112, align 1
  %.spill113 = alloca i1, align 1
  store i1 false, ptr %.spill113, align 1
  %.spill114 = alloca i1, align 1
  store i1 false, ptr %.spill114, align 1
  %.spill115 = alloca i1, align 1
  store i1 false, ptr %.spill115, align 1
  %.spill116 = alloca i1, align 1
  store i1 false, ptr %.spill116, align 1
  %.spill117 = alloca i1, align 1
  store i1 false, ptr %.spill117, align 1
  %.spill118 = alloca i1, align 1
  store i1 false, ptr %.spill118, align 1
  %.spill119 = alloca i1, align 1
  store i1 false, ptr %.spill119, align 1
  %.spill120 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill120, align 32
  %.spill121 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill121, align 32
  %.spill122 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill122, align 32
  %.spill123 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill123, align 32
  %.spill124 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill124, align 32
  %.spill125 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill125, align 32
  %.spill126 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill126, align 32
  %.spill127 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill127, align 32
  %.spill128 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill128, align 32
  %.spill129 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill129, align 32
  %.spill130 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill130, align 32
  %.spill131 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill131, align 32
  %.spill132 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill132, align 32
  %.spill133 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill133, align 32
  %.spill134 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill134, align 32
  %.spill135 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill135, align 32
  %tile_snapshot.spill136 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill136, align 64
  %.slot137 = alloca i64, align 8
  store i64 0, ptr %.slot137, align 4
  %.slot138 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot138, align 32
  %.spill139 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill139, align 32
  %.spill140 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill140, align 32
  %tile_snapshot.spill141 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill141, align 64
  %.spill142 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill142, align 32
  %.slot143 = alloca i64, align 8
  store i64 0, ptr %.slot143, align 4
  %.slot144 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot144, align 32
  %27 = getelementptr i8, ptr %argument_buffer, i64 0
  %28 = load ptr, ptr %27, align 16
  %29 = getelementptr i8, ptr %27, i64 8
  %30 = load i64, ptr %29, align 8
  %31 = insertvalue { ptr, i64 } poison, ptr %28, 0
  %32 = insertvalue { ptr, i64 } %31, i64 %30, 1
  %33 = getelementptr i8, ptr %argument_buffer, i64 16
  %34 = load ptr, ptr %33, align 16
  %35 = getelementptr i8, ptr %33, i64 8
  %36 = load i64, ptr %35, align 8
  %37 = insertvalue { ptr, i64 } poison, ptr %34, 0
  %38 = insertvalue { ptr, i64 } %37, i64 %36, 1
  %39 = getelementptr i8, ptr %argument_buffer, i64 32
  %40 = load ptr, ptr %39, align 16
  %41 = getelementptr i8, ptr %39, i64 8
  %42 = load i64, ptr %41, align 8
  %43 = insertvalue { ptr, i64 } poison, ptr %40, 0
  %44 = insertvalue { ptr, i64 } %43, i64 %42, 1
  %45 = getelementptr i8, ptr %argument_buffer, i64 48
  %46 = load ptr, ptr %45, align 16
  %47 = getelementptr i8, ptr %45, i64 8
  %48 = load i64, ptr %47, align 8
  %49 = insertvalue { ptr, i64 } poison, ptr %46, 0
  %50 = insertvalue { ptr, i64 } %49, i64 %48, 1
  %51 = load i32, ptr %launch_config, align 4
  %52 = getelementptr i8, ptr %launch_config, i64 12
  %53 = load i32, ptr %52, align 4
  %54 = getelementptr i8, ptr %launch_config, i64 4
  %55 = load i32, ptr %54, align 4
  %56 = getelementptr i8, ptr %launch_config, i64 16
  %57 = load i32, ptr %56, align 4
  %58 = getelementptr i8, ptr %launch_config, i64 8
  %59 = load i32, ptr %58, align 4
  %60 = getelementptr i8, ptr %launch_config, i64 20
  %61 = load i32, ptr %60, align 4
  %62 = getelementptr i8, ptr %launch_config, i64 36
  %63 = load i32, ptr %62, align 4
  %.splatinsert145 = insertelement <8 x i32> poison, i32 %63, i64 0
  %.splat146 = shufflevector <8 x i32> %.splatinsert145, <8 x i32> poison, <8 x i32> zeroinitializer
  %64 = add <8 x i32> %.splat146, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %65 = mul i32 %51, 32
  %.splatinsert147 = insertelement <8 x i32> poison, i32 %65, i64 0
  %.splat148 = shufflevector <8 x i32> %.splatinsert147, <8 x i32> poison, <8 x i32> zeroinitializer
  %66 = add <8 x i32> %.splat148, %64
  %67 = mul i32 %55, 1
  %.splatinsert149 = insertelement <8 x i32> poison, i32 %67, i64 0
  %.splat150 = shufflevector <8 x i32> %.splatinsert149, <8 x i32> poison, <8 x i32> zeroinitializer
  %68 = add <8 x i32> %.splat150, zeroinitializer
  %69 = mul i32 %59, 1
  %.splatinsert151 = insertelement <8 x i32> poison, i32 %69, i64 0
  %.splat152 = shufflevector <8 x i32> %.splatinsert151, <8 x i32> poison, <8 x i32> zeroinitializer
  %70 = add <8 x i32> %.splat152, zeroinitializer
  %71 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %66, 0
  %72 = insertvalue [3 x <8 x i32>] %71, <8 x i32> %68, 1
  %73 = insertvalue [3 x <8 x i32>] %72, <8 x i32> %70, 2
  %.splatinsert153 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat154 = shufflevector <8 x i32> %.splatinsert153, <8 x i32> poison, <8 x i32> zeroinitializer
  %74 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat154
  %75 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %74)
  br i1 %75, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %76 = extractvalue [3 x <8 x i32>] %73, 0
  %77 = zext <8 x i32> %76 to <8 x i64>
  %78 = select <8 x i1> %74, <8 x i64> %77, <8 x i64> zeroinitializer
  %79 = select <8 x i1> %74, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %80 = sdiv <8 x i64> %78, %79
  %81 = load <8 x i64>, ptr %.spill, align 64
  %82 = select <8 x i1> %74, <8 x i64> %80, <8 x i64> %81
  store <8 x i64> %82, ptr %.spill, align 64
  store i64 0, ptr %.spill33, align 4
  %83 = select <8 x i1> %74, <8 x i64> %80, <8 x i64> zeroinitializer
  %84 = select <8 x i1> %74, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %85 = sdiv <8 x i64> %83, %84
  %86 = load <8 x i64>, ptr %.spill34, align 64
  %87 = select <8 x i1> %74, <8 x i64> %85, <8 x i64> %86
  store <8 x i64> %87, ptr %.spill34, align 64
  %88 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %89 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %88, 0
  %91 = select <8 x i1> %74, <8 x ptr> %89, <8 x ptr> %90
  %92 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %88, 1
  %94 = select <8 x i1> %74, <8 x i64> %92, <8 x i64> %93
  %95 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %91, 0
  %96 = insertvalue { <8 x ptr>, <8 x i64> } %95, <8 x i64> %94, 1
  store { <8 x ptr>, <8 x i64> } %96, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.spill35, align 4
  store i64 0, ptr %.spill36, align 4
  %97 = add <8 x i64> zeroinitializer, %80
  %98 = mul <8 x i64> %97, splat (i64 1)
  %99 = add <8 x i64> %98, zeroinitializer
  %100 = mul <8 x i64> %99, splat (i64 64)
  %101 = add <8 x i64> %100, zeroinitializer
  %102 = extractvalue { ptr, i64 } %32, 0
  %103 = extractelement <8 x i1> %74, i64 0
  br i1 %103, label %copy.active, label %copy.continue

direct.schedule.1:                                ; preds = %mma.continue536, %copy.continue168
  %.state = load i64, ptr %.slot, align 4
  %104 = icmp slt i64 %.state, 128
  br i1 %104, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state169 = load i64, ptr %.slot, align 4
  %105 = sdiv i64 %.state169, 1
  %106 = mul i64 %105, 16
  %.spill.load = load i64, ptr %.spill36, align 4
  %.splatinsert170 = insertelement <8 x i64> poison, i64 %.spill.load, i64 0
  %.splat171 = shufflevector <8 x i64> %.splatinsert170, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load172 = load <8 x i64>, ptr %.spill34, align 64
  %107 = add <8 x i64> %.splat171, %.spill.load172
  %108 = mul <8 x i64> %107, splat (i64 2048)
  %.splatinsert173 = insertelement <8 x i64> poison, i64 %106, i64 0
  %.splat174 = shufflevector <8 x i64> %.splatinsert173, <8 x i64> poison, <8 x i32> zeroinitializer
  %109 = add <8 x i64> %108, %.splat174
  %110 = mul <8 x i64> %109, splat (i64 64)
  %111 = add <8 x i64> %110, zeroinitializer
  %112 = extractvalue { ptr, i64 } %38, 0
  %113 = extractelement <8 x i1> %74, i64 0
  br i1 %113, label %copy.active175, label %copy.continue176

direct.schedule.3:                                ; preds = %direct.schedule.4, %mma.continue220
  %.state284 = load i64, ptr %.slot137, align 4
  %114 = icmp slt i64 %.state284, 16
  br i1 %114, label %direct.true285, label %direct.false286

direct.schedule.4:                                ; preds = %direct.true285
  %.state287 = load i64, ptr %.slot137, align 4
  %115 = sdiv i64 %.state287, 1
  %.spill.load288 = load i64, ptr %.spill35, align 4
  %116 = mul i64 %.spill.load288, 1
  %117 = add i64 %116, 0
  %118 = mul i64 %117, 1
  %119 = add i64 %118, 0
  %120 = mul i64 %119, 16
  %121 = add i64 %120, %115
  %tile_snapshot.spill.load289 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill136, align 64
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load289, 0
  %123 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load289, 1
  %.splatinsert290 = insertelement <8 x i64> poison, i64 %121, i64 0
  %.splat291 = shufflevector <8 x i64> %.splatinsert290, <8 x i64> poison, <8 x i32> zeroinitializer
  %124 = mul <8 x i64> %.splat291, splat (i64 32)
  %125 = add <8 x i64> %123, %124
  %126 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %122, 0
  %127 = insertvalue { <8 x ptr>, <8 x i64> } %126, <8 x i64> %125, 1
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %127, 1
  %130 = extractelement <8 x ptr> %128, i32 0
  %131 = extractelement <8 x i64> %129, i32 0
  %132 = sub i64 %131, 0
  %133 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %74)
  %134 = select i1 %133, i64 %132, i64 0
  %private.contiguous.address292 = getelementptr i8, ptr %130, i64 %134
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address292, align 4
  %135 = select <8 x i1> %74, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %.state293 = load <8 x float>, ptr %.slot138, align 32
  %136 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state293, <8 x float> %135)
  %.state294 = load i64, ptr %.slot137, align 4
  %137 = add i64 %.state294, 1
  store i64 %137, ptr %.slot137, align 4
  %138 = load <8 x float>, ptr %.slot138, align 32
  %139 = select <8 x i1> %74, <8 x float> %136, <8 x float> %138
  store <8 x float> %139, ptr %.slot138, align 32
  br label %direct.schedule.3

direct.schedule.5:                                ; preds = %direct.false286
  %.state295 = load <8 x float>, ptr %.slot37, align 32
  %.state296 = load <8 x float>, ptr %.slot138, align 32
  %140 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state295, <8 x float> %.state296)
  %141 = load <8 x float>, ptr %.spill139, align 32
  %142 = select <8 x i1> %74, <8 x float> %140, <8 x float> %141
  store <8 x float> %142, ptr %.spill139, align 32
  %.state297 = load <8 x float>, ptr %.slot37, align 32
  %143 = fsub <8 x float> %.state297, %140
  %144 = select <8 x i1> %74, <8 x float> %143, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %144)
  %145 = load <8 x float>, ptr %.spill140, align 32
  %146 = select <8 x i1> %74, <8 x float> %native.exp, <8 x float> %145
  store <8 x float> %146, ptr %.spill140, align 32
  %.spill.load298 = load <8 x float>, ptr %.spill120, align 32
  %147 = fsub <8 x float> %.spill.load298, %140
  %.spill.load299 = load <8 x float>, ptr %.spill121, align 32
  %148 = fsub <8 x float> %.spill.load299, %140
  %.spill.load300 = load <8 x float>, ptr %.spill122, align 32
  %149 = fsub <8 x float> %.spill.load300, %140
  %.spill.load301 = load <8 x float>, ptr %.spill123, align 32
  %150 = fsub <8 x float> %.spill.load301, %140
  %.spill.load302 = load <8 x float>, ptr %.spill124, align 32
  %151 = fsub <8 x float> %.spill.load302, %140
  %.spill.load303 = load <8 x float>, ptr %.spill125, align 32
  %152 = fsub <8 x float> %.spill.load303, %140
  %.spill.load304 = load <8 x float>, ptr %.spill126, align 32
  %153 = fsub <8 x float> %.spill.load304, %140
  %.spill.load305 = load <8 x float>, ptr %.spill127, align 32
  %154 = fsub <8 x float> %.spill.load305, %140
  %.spill.load306 = load <8 x float>, ptr %.spill128, align 32
  %155 = fsub <8 x float> %.spill.load306, %140
  %.spill.load307 = load <8 x float>, ptr %.spill129, align 32
  %156 = fsub <8 x float> %.spill.load307, %140
  %.spill.load308 = load <8 x float>, ptr %.spill130, align 32
  %157 = fsub <8 x float> %.spill.load308, %140
  %.spill.load309 = load <8 x float>, ptr %.spill131, align 32
  %158 = fsub <8 x float> %.spill.load309, %140
  %.spill.load310 = load <8 x float>, ptr %.spill132, align 32
  %159 = fsub <8 x float> %.spill.load310, %140
  %.spill.load311 = load <8 x float>, ptr %.spill133, align 32
  %160 = fsub <8 x float> %.spill.load311, %140
  %.spill.load312 = load <8 x float>, ptr %.spill134, align 32
  %161 = fsub <8 x float> %.spill.load312, %140
  %.spill.load313 = load <8 x float>, ptr %.spill135, align 32
  %162 = fsub <8 x float> %.spill.load313, %140
  %163 = select <8 x i1> %74, <8 x float> %147, <8 x float> zeroinitializer
  %native.exp314 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %163)
  %164 = select <8 x i1> %74, <8 x float> %148, <8 x float> zeroinitializer
  %native.exp315 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %164)
  %165 = select <8 x i1> %74, <8 x float> %149, <8 x float> zeroinitializer
  %native.exp316 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %165)
  %166 = select <8 x i1> %74, <8 x float> %150, <8 x float> zeroinitializer
  %native.exp317 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %166)
  %167 = select <8 x i1> %74, <8 x float> %151, <8 x float> zeroinitializer
  %native.exp318 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %167)
  %168 = select <8 x i1> %74, <8 x float> %152, <8 x float> zeroinitializer
  %native.exp319 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %168)
  %169 = select <8 x i1> %74, <8 x float> %153, <8 x float> zeroinitializer
  %native.exp320 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %169)
  %170 = select <8 x i1> %74, <8 x float> %154, <8 x float> zeroinitializer
  %native.exp321 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %170)
  %171 = select <8 x i1> %74, <8 x float> %155, <8 x float> zeroinitializer
  %native.exp322 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %171)
  %172 = select <8 x i1> %74, <8 x float> %156, <8 x float> zeroinitializer
  %native.exp323 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %172)
  %173 = select <8 x i1> %74, <8 x float> %157, <8 x float> zeroinitializer
  %native.exp324 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %173)
  %174 = select <8 x i1> %74, <8 x float> %158, <8 x float> zeroinitializer
  %native.exp325 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %174)
  %175 = select <8 x i1> %74, <8 x float> %159, <8 x float> zeroinitializer
  %native.exp326 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %175)
  %176 = select <8 x i1> %74, <8 x float> %160, <8 x float> zeroinitializer
  %native.exp327 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %176)
  %177 = select <8 x i1> %74, <8 x float> %161, <8 x float> zeroinitializer
  %native.exp328 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %177)
  %178 = select <8 x i1> %74, <8 x float> %162, <8 x float> zeroinitializer
  %native.exp329 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %178)
  %.spill.load330 = load i1, ptr %.spill104, align 1
  %.splatinsert331 = insertelement <8 x i1> poison, i1 %.spill.load330, i64 0
  %.splat332 = shufflevector <8 x i1> %.splatinsert331, <8 x i1> poison, <8 x i32> zeroinitializer
  %179 = select <8 x i1> %.splat332, <8 x float> %native.exp314, <8 x float> zeroinitializer
  %.spill.load333 = load i1, ptr %.spill105, align 1
  %.splatinsert334 = insertelement <8 x i1> poison, i1 %.spill.load333, i64 0
  %.splat335 = shufflevector <8 x i1> %.splatinsert334, <8 x i1> poison, <8 x i32> zeroinitializer
  %180 = select <8 x i1> %.splat335, <8 x float> %native.exp315, <8 x float> zeroinitializer
  %.spill.load336 = load i1, ptr %.spill106, align 1
  %.splatinsert337 = insertelement <8 x i1> poison, i1 %.spill.load336, i64 0
  %.splat338 = shufflevector <8 x i1> %.splatinsert337, <8 x i1> poison, <8 x i32> zeroinitializer
  %181 = select <8 x i1> %.splat338, <8 x float> %native.exp316, <8 x float> zeroinitializer
  %.spill.load339 = load i1, ptr %.spill107, align 1
  %.splatinsert340 = insertelement <8 x i1> poison, i1 %.spill.load339, i64 0
  %.splat341 = shufflevector <8 x i1> %.splatinsert340, <8 x i1> poison, <8 x i32> zeroinitializer
  %182 = select <8 x i1> %.splat341, <8 x float> %native.exp317, <8 x float> zeroinitializer
  %.spill.load342 = load i1, ptr %.spill108, align 1
  %.splatinsert343 = insertelement <8 x i1> poison, i1 %.spill.load342, i64 0
  %.splat344 = shufflevector <8 x i1> %.splatinsert343, <8 x i1> poison, <8 x i32> zeroinitializer
  %183 = select <8 x i1> %.splat344, <8 x float> %native.exp318, <8 x float> zeroinitializer
  %.spill.load345 = load i1, ptr %.spill109, align 1
  %.splatinsert346 = insertelement <8 x i1> poison, i1 %.spill.load345, i64 0
  %.splat347 = shufflevector <8 x i1> %.splatinsert346, <8 x i1> poison, <8 x i32> zeroinitializer
  %184 = select <8 x i1> %.splat347, <8 x float> %native.exp319, <8 x float> zeroinitializer
  %.spill.load348 = load i1, ptr %.spill110, align 1
  %.splatinsert349 = insertelement <8 x i1> poison, i1 %.spill.load348, i64 0
  %.splat350 = shufflevector <8 x i1> %.splatinsert349, <8 x i1> poison, <8 x i32> zeroinitializer
  %185 = select <8 x i1> %.splat350, <8 x float> %native.exp320, <8 x float> zeroinitializer
  %.spill.load351 = load i1, ptr %.spill111, align 1
  %.splatinsert352 = insertelement <8 x i1> poison, i1 %.spill.load351, i64 0
  %.splat353 = shufflevector <8 x i1> %.splatinsert352, <8 x i1> poison, <8 x i32> zeroinitializer
  %186 = select <8 x i1> %.splat353, <8 x float> %native.exp321, <8 x float> zeroinitializer
  %.spill.load354 = load i1, ptr %.spill112, align 1
  %.splatinsert355 = insertelement <8 x i1> poison, i1 %.spill.load354, i64 0
  %.splat356 = shufflevector <8 x i1> %.splatinsert355, <8 x i1> poison, <8 x i32> zeroinitializer
  %187 = select <8 x i1> %.splat356, <8 x float> %native.exp322, <8 x float> zeroinitializer
  %.spill.load357 = load i1, ptr %.spill113, align 1
  %.splatinsert358 = insertelement <8 x i1> poison, i1 %.spill.load357, i64 0
  %.splat359 = shufflevector <8 x i1> %.splatinsert358, <8 x i1> poison, <8 x i32> zeroinitializer
  %188 = select <8 x i1> %.splat359, <8 x float> %native.exp323, <8 x float> zeroinitializer
  %.spill.load360 = load i1, ptr %.spill114, align 1
  %.splatinsert361 = insertelement <8 x i1> poison, i1 %.spill.load360, i64 0
  %.splat362 = shufflevector <8 x i1> %.splatinsert361, <8 x i1> poison, <8 x i32> zeroinitializer
  %189 = select <8 x i1> %.splat362, <8 x float> %native.exp324, <8 x float> zeroinitializer
  %.spill.load363 = load i1, ptr %.spill115, align 1
  %.splatinsert364 = insertelement <8 x i1> poison, i1 %.spill.load363, i64 0
  %.splat365 = shufflevector <8 x i1> %.splatinsert364, <8 x i1> poison, <8 x i32> zeroinitializer
  %190 = select <8 x i1> %.splat365, <8 x float> %native.exp325, <8 x float> zeroinitializer
  %.spill.load366 = load i1, ptr %.spill116, align 1
  %.splatinsert367 = insertelement <8 x i1> poison, i1 %.spill.load366, i64 0
  %.splat368 = shufflevector <8 x i1> %.splatinsert367, <8 x i1> poison, <8 x i32> zeroinitializer
  %191 = select <8 x i1> %.splat368, <8 x float> %native.exp326, <8 x float> zeroinitializer
  %.spill.load369 = load i1, ptr %.spill117, align 1
  %.splatinsert370 = insertelement <8 x i1> poison, i1 %.spill.load369, i64 0
  %.splat371 = shufflevector <8 x i1> %.splatinsert370, <8 x i1> poison, <8 x i32> zeroinitializer
  %192 = select <8 x i1> %.splat371, <8 x float> %native.exp327, <8 x float> zeroinitializer
  %.spill.load372 = load i1, ptr %.spill118, align 1
  %.splatinsert373 = insertelement <8 x i1> poison, i1 %.spill.load372, i64 0
  %.splat374 = shufflevector <8 x i1> %.splatinsert373, <8 x i1> poison, <8 x i32> zeroinitializer
  %193 = select <8 x i1> %.splat374, <8 x float> %native.exp328, <8 x float> zeroinitializer
  %.spill.load375 = load i1, ptr %.spill119, align 1
  %.splatinsert376 = insertelement <8 x i1> poison, i1 %.spill.load375, i64 0
  %.splat377 = shufflevector <8 x i1> %.splatinsert376, <8 x i1> poison, <8 x i32> zeroinitializer
  %194 = select <8 x i1> %.splat377, <8 x float> %native.exp329, <8 x float> zeroinitializer
  %195 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill141, align 64
  %196 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %197 = extractvalue { <8 x ptr>, <8 x i64> } %195, 0
  %198 = select <8 x i1> %74, <8 x ptr> %196, <8 x ptr> %197
  %199 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %200 = extractvalue { <8 x ptr>, <8 x i64> } %195, 1
  %201 = select <8 x i1> %74, <8 x i64> %199, <8 x i64> %200
  %202 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %198, 0
  %203 = insertvalue { <8 x ptr>, <8 x i64> } %202, <8 x i64> %201, 1
  store { <8 x ptr>, <8 x i64> } %203, ptr %tile_snapshot.spill141, align 64
  %204 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %205 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %206 = add <8 x i64> %205, zeroinitializer
  %207 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %204, 0
  %208 = insertvalue { <8 x ptr>, <8 x i64> } %207, <8 x i64> %206, 1
  %209 = extractvalue { <8 x ptr>, <8 x i64> } %208, 0
  %210 = extractvalue { <8 x ptr>, <8 x i64> } %208, 1
  %211 = getelementptr i8, <8 x ptr> %209, <8 x i64> %210
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %179, <8 x ptr> align 1 %211, <8 x i1> %74)
  %212 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %213 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %214 = add <8 x i64> %213, splat (i64 4)
  %215 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %212, 0
  %216 = insertvalue { <8 x ptr>, <8 x i64> } %215, <8 x i64> %214, 1
  %217 = extractvalue { <8 x ptr>, <8 x i64> } %216, 0
  %218 = extractvalue { <8 x ptr>, <8 x i64> } %216, 1
  %219 = getelementptr i8, <8 x ptr> %217, <8 x i64> %218
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %180, <8 x ptr> align 1 %219, <8 x i1> %74)
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %222 = add <8 x i64> %221, splat (i64 8)
  %223 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %220, 0
  %224 = insertvalue { <8 x ptr>, <8 x i64> } %223, <8 x i64> %222, 1
  %225 = extractvalue { <8 x ptr>, <8 x i64> } %224, 0
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %224, 1
  %227 = getelementptr i8, <8 x ptr> %225, <8 x i64> %226
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %181, <8 x ptr> align 1 %227, <8 x i1> %74)
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %229 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %230 = add <8 x i64> %229, splat (i64 12)
  %231 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %228, 0
  %232 = insertvalue { <8 x ptr>, <8 x i64> } %231, <8 x i64> %230, 1
  %233 = extractvalue { <8 x ptr>, <8 x i64> } %232, 0
  %234 = extractvalue { <8 x ptr>, <8 x i64> } %232, 1
  %235 = getelementptr i8, <8 x ptr> %233, <8 x i64> %234
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %182, <8 x ptr> align 1 %235, <8 x i1> %74)
  %236 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %237 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %238 = add <8 x i64> %237, splat (i64 16)
  %239 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %236, 0
  %240 = insertvalue { <8 x ptr>, <8 x i64> } %239, <8 x i64> %238, 1
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %240, 0
  %242 = extractvalue { <8 x ptr>, <8 x i64> } %240, 1
  %243 = getelementptr i8, <8 x ptr> %241, <8 x i64> %242
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %183, <8 x ptr> align 1 %243, <8 x i1> %74)
  %244 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %245 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %246 = add <8 x i64> %245, splat (i64 20)
  %247 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %244, 0
  %248 = insertvalue { <8 x ptr>, <8 x i64> } %247, <8 x i64> %246, 1
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %248, 0
  %250 = extractvalue { <8 x ptr>, <8 x i64> } %248, 1
  %251 = getelementptr i8, <8 x ptr> %249, <8 x i64> %250
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %184, <8 x ptr> align 1 %251, <8 x i1> %74)
  %252 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %254 = add <8 x i64> %253, splat (i64 24)
  %255 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %252, 0
  %256 = insertvalue { <8 x ptr>, <8 x i64> } %255, <8 x i64> %254, 1
  %257 = extractvalue { <8 x ptr>, <8 x i64> } %256, 0
  %258 = extractvalue { <8 x ptr>, <8 x i64> } %256, 1
  %259 = getelementptr i8, <8 x ptr> %257, <8 x i64> %258
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %185, <8 x ptr> align 1 %259, <8 x i1> %74)
  %260 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %262 = add <8 x i64> %261, splat (i64 28)
  %263 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %260, 0
  %264 = insertvalue { <8 x ptr>, <8 x i64> } %263, <8 x i64> %262, 1
  %265 = extractvalue { <8 x ptr>, <8 x i64> } %264, 0
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %264, 1
  %267 = getelementptr i8, <8 x ptr> %265, <8 x i64> %266
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %186, <8 x ptr> align 1 %267, <8 x i1> %74)
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %269 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %270 = add <8 x i64> %269, splat (i64 32)
  %271 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %268, 0
  %272 = insertvalue { <8 x ptr>, <8 x i64> } %271, <8 x i64> %270, 1
  %273 = extractvalue { <8 x ptr>, <8 x i64> } %272, 0
  %274 = extractvalue { <8 x ptr>, <8 x i64> } %272, 1
  %275 = getelementptr i8, <8 x ptr> %273, <8 x i64> %274
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %187, <8 x ptr> align 1 %275, <8 x i1> %74)
  %276 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %277 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %278 = add <8 x i64> %277, splat (i64 36)
  %279 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %276, 0
  %280 = insertvalue { <8 x ptr>, <8 x i64> } %279, <8 x i64> %278, 1
  %281 = extractvalue { <8 x ptr>, <8 x i64> } %280, 0
  %282 = extractvalue { <8 x ptr>, <8 x i64> } %280, 1
  %283 = getelementptr i8, <8 x ptr> %281, <8 x i64> %282
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %188, <8 x ptr> align 1 %283, <8 x i1> %74)
  %284 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %285 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %286 = add <8 x i64> %285, splat (i64 40)
  %287 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %284, 0
  %288 = insertvalue { <8 x ptr>, <8 x i64> } %287, <8 x i64> %286, 1
  %289 = extractvalue { <8 x ptr>, <8 x i64> } %288, 0
  %290 = extractvalue { <8 x ptr>, <8 x i64> } %288, 1
  %291 = getelementptr i8, <8 x ptr> %289, <8 x i64> %290
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %189, <8 x ptr> align 1 %291, <8 x i1> %74)
  %292 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %294 = add <8 x i64> %293, splat (i64 44)
  %295 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %292, 0
  %296 = insertvalue { <8 x ptr>, <8 x i64> } %295, <8 x i64> %294, 1
  %297 = extractvalue { <8 x ptr>, <8 x i64> } %296, 0
  %298 = extractvalue { <8 x ptr>, <8 x i64> } %296, 1
  %299 = getelementptr i8, <8 x ptr> %297, <8 x i64> %298
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %190, <8 x ptr> align 1 %299, <8 x i1> %74)
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %301 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %302 = add <8 x i64> %301, splat (i64 48)
  %303 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %300, 0
  %304 = insertvalue { <8 x ptr>, <8 x i64> } %303, <8 x i64> %302, 1
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %304, 0
  %306 = extractvalue { <8 x ptr>, <8 x i64> } %304, 1
  %307 = getelementptr i8, <8 x ptr> %305, <8 x i64> %306
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %191, <8 x ptr> align 1 %307, <8 x i1> %74)
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %310 = add <8 x i64> %309, splat (i64 52)
  %311 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %308, 0
  %312 = insertvalue { <8 x ptr>, <8 x i64> } %311, <8 x i64> %310, 1
  %313 = extractvalue { <8 x ptr>, <8 x i64> } %312, 0
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %312, 1
  %315 = getelementptr i8, <8 x ptr> %313, <8 x i64> %314
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %192, <8 x ptr> align 1 %315, <8 x i1> %74)
  %316 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %317 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %318 = add <8 x i64> %317, splat (i64 56)
  %319 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %316, 0
  %320 = insertvalue { <8 x ptr>, <8 x i64> } %319, <8 x i64> %318, 1
  %321 = extractvalue { <8 x ptr>, <8 x i64> } %320, 0
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %320, 1
  %323 = getelementptr i8, <8 x ptr> %321, <8 x i64> %322
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %193, <8 x ptr> align 1 %323, <8 x i1> %74)
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %326 = add <8 x i64> %325, splat (i64 60)
  %327 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %324, 0
  %328 = insertvalue { <8 x ptr>, <8 x i64> } %327, <8 x i64> %326, 1
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %328, 0
  %330 = extractvalue { <8 x ptr>, <8 x i64> } %328, 1
  %331 = getelementptr i8, <8 x ptr> %329, <8 x i64> %330
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %194, <8 x ptr> align 1 %331, <8 x i1> %74)
  %.state378 = load <8 x float>, ptr %.slot38, align 32
  %332 = fmul <8 x float> %.state378, %native.exp
  %333 = load <8 x float>, ptr %.spill142, align 32
  %334 = select <8 x i1> %74, <8 x float> %332, <8 x float> %333
  store <8 x float> %334, ptr %.spill142, align 32
  store i64 0, ptr %.slot143, align 4
  %335 = load <8 x float>, ptr %.slot144, align 32
  %336 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %335
  store <8 x float> %336, ptr %.slot144, align 32
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.7, %direct.schedule.5
  %.state379 = load i64, ptr %.slot143, align 4
  %337 = icmp slt i64 %.state379, 16
  br i1 %337, label %direct.true380, label %direct.false381

direct.schedule.7:                                ; preds = %direct.true380
  %.state382 = load i64, ptr %.slot143, align 4
  %338 = sdiv i64 %.state382, 1
  %.spill.load383 = load i64, ptr %.spill35, align 4
  %339 = mul i64 %.spill.load383, 1
  %340 = add i64 %339, 0
  %341 = mul i64 %340, 1
  %342 = add i64 %341, 0
  %343 = mul i64 %342, 16
  %344 = add i64 %343, %338
  %tile_snapshot.spill.load384 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill141, align 64
  %345 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load384, 0
  %346 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load384, 1
  %.splatinsert385 = insertelement <8 x i64> poison, i64 %344, i64 0
  %.splat386 = shufflevector <8 x i64> %.splatinsert385, <8 x i64> poison, <8 x i32> zeroinitializer
  %347 = mul <8 x i64> %.splat386, splat (i64 4)
  %348 = add <8 x i64> %346, %347
  %349 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %345, 0
  %350 = insertvalue { <8 x ptr>, <8 x i64> } %349, <8 x i64> %348, 1
  %351 = extractvalue { <8 x ptr>, <8 x i64> } %350, 0
  %352 = extractvalue { <8 x ptr>, <8 x i64> } %350, 1
  %353 = getelementptr i8, <8 x ptr> %351, <8 x i64> %352
  %354 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %353, <8 x i1> %74, <8 x float> zeroinitializer)
  %.state387 = load <8 x float>, ptr %.slot144, align 32
  %355 = fadd <8 x float> %.state387, %354
  %.state388 = load i64, ptr %.slot143, align 4
  %356 = add i64 %.state388, 1
  store i64 %356, ptr %.slot143, align 4
  %357 = load <8 x float>, ptr %.slot144, align 32
  %358 = select <8 x i1> %74, <8 x float> %355, <8 x float> %357
  store <8 x float> %358, ptr %.slot144, align 32
  br label %direct.schedule.6

direct.schedule.8:                                ; preds = %direct.false381
  %.spill.load389 = load <8 x float>, ptr %.spill142, align 32
  %.state390 = load <8 x float>, ptr %.slot144, align 32
  %359 = fadd <8 x float> %.spill.load389, %.state390
  %.state391 = load <8 x float>, ptr %.slot39, align 32
  %.spill.load392 = load <8 x float>, ptr %.spill140, align 32
  %360 = fmul <8 x float> %.state391, %.spill.load392
  %.state393 = load <8 x float>, ptr %.slot40, align 32
  %.spill.load394 = load <8 x float>, ptr %.spill140, align 32
  %361 = fmul <8 x float> %.state393, %.spill.load394
  %.state395 = load <8 x float>, ptr %.slot41, align 32
  %.spill.load396 = load <8 x float>, ptr %.spill140, align 32
  %362 = fmul <8 x float> %.state395, %.spill.load396
  %.state397 = load <8 x float>, ptr %.slot42, align 32
  %.spill.load398 = load <8 x float>, ptr %.spill140, align 32
  %363 = fmul <8 x float> %.state397, %.spill.load398
  %.state399 = load <8 x float>, ptr %.slot43, align 32
  %.spill.load400 = load <8 x float>, ptr %.spill140, align 32
  %364 = fmul <8 x float> %.state399, %.spill.load400
  %.state401 = load <8 x float>, ptr %.slot44, align 32
  %.spill.load402 = load <8 x float>, ptr %.spill140, align 32
  %365 = fmul <8 x float> %.state401, %.spill.load402
  %.state403 = load <8 x float>, ptr %.slot45, align 32
  %.spill.load404 = load <8 x float>, ptr %.spill140, align 32
  %366 = fmul <8 x float> %.state403, %.spill.load404
  %.state405 = load <8 x float>, ptr %.slot46, align 32
  %.spill.load406 = load <8 x float>, ptr %.spill140, align 32
  %367 = fmul <8 x float> %.state405, %.spill.load406
  %.state407 = load <8 x float>, ptr %.slot47, align 32
  %.spill.load408 = load <8 x float>, ptr %.spill140, align 32
  %368 = fmul <8 x float> %.state407, %.spill.load408
  %.state409 = load <8 x float>, ptr %.slot48, align 32
  %.spill.load410 = load <8 x float>, ptr %.spill140, align 32
  %369 = fmul <8 x float> %.state409, %.spill.load410
  %.state411 = load <8 x float>, ptr %.slot49, align 32
  %.spill.load412 = load <8 x float>, ptr %.spill140, align 32
  %370 = fmul <8 x float> %.state411, %.spill.load412
  %.state413 = load <8 x float>, ptr %.slot50, align 32
  %.spill.load414 = load <8 x float>, ptr %.spill140, align 32
  %371 = fmul <8 x float> %.state413, %.spill.load414
  %.state415 = load <8 x float>, ptr %.slot51, align 32
  %.spill.load416 = load <8 x float>, ptr %.spill140, align 32
  %372 = fmul <8 x float> %.state415, %.spill.load416
  %.state417 = load <8 x float>, ptr %.slot52, align 32
  %.spill.load418 = load <8 x float>, ptr %.spill140, align 32
  %373 = fmul <8 x float> %.state417, %.spill.load418
  %.state419 = load <8 x float>, ptr %.slot53, align 32
  %.spill.load420 = load <8 x float>, ptr %.spill140, align 32
  %374 = fmul <8 x float> %.state419, %.spill.load420
  %.state421 = load <8 x float>, ptr %.slot54, align 32
  %.spill.load422 = load <8 x float>, ptr %.spill140, align 32
  %375 = fmul <8 x float> %.state421, %.spill.load422
  %.state423 = load <8 x float>, ptr %.slot55, align 32
  %.spill.load424 = load <8 x float>, ptr %.spill140, align 32
  %376 = fmul <8 x float> %.state423, %.spill.load424
  %.state425 = load <8 x float>, ptr %.slot56, align 32
  %.spill.load426 = load <8 x float>, ptr %.spill140, align 32
  %377 = fmul <8 x float> %.state425, %.spill.load426
  %.state427 = load <8 x float>, ptr %.slot57, align 32
  %.spill.load428 = load <8 x float>, ptr %.spill140, align 32
  %378 = fmul <8 x float> %.state427, %.spill.load428
  %.state429 = load <8 x float>, ptr %.slot58, align 32
  %.spill.load430 = load <8 x float>, ptr %.spill140, align 32
  %379 = fmul <8 x float> %.state429, %.spill.load430
  %.state431 = load <8 x float>, ptr %.slot59, align 32
  %.spill.load432 = load <8 x float>, ptr %.spill140, align 32
  %380 = fmul <8 x float> %.state431, %.spill.load432
  %.state433 = load <8 x float>, ptr %.slot60, align 32
  %.spill.load434 = load <8 x float>, ptr %.spill140, align 32
  %381 = fmul <8 x float> %.state433, %.spill.load434
  %.state435 = load <8 x float>, ptr %.slot61, align 32
  %.spill.load436 = load <8 x float>, ptr %.spill140, align 32
  %382 = fmul <8 x float> %.state435, %.spill.load436
  %.state437 = load <8 x float>, ptr %.slot62, align 32
  %.spill.load438 = load <8 x float>, ptr %.spill140, align 32
  %383 = fmul <8 x float> %.state437, %.spill.load438
  %.state439 = load <8 x float>, ptr %.slot63, align 32
  %.spill.load440 = load <8 x float>, ptr %.spill140, align 32
  %384 = fmul <8 x float> %.state439, %.spill.load440
  %.state441 = load <8 x float>, ptr %.slot64, align 32
  %.spill.load442 = load <8 x float>, ptr %.spill140, align 32
  %385 = fmul <8 x float> %.state441, %.spill.load442
  %.state443 = load <8 x float>, ptr %.slot65, align 32
  %.spill.load444 = load <8 x float>, ptr %.spill140, align 32
  %386 = fmul <8 x float> %.state443, %.spill.load444
  %.state445 = load <8 x float>, ptr %.slot66, align 32
  %.spill.load446 = load <8 x float>, ptr %.spill140, align 32
  %387 = fmul <8 x float> %.state445, %.spill.load446
  %.state447 = load <8 x float>, ptr %.slot67, align 32
  %.spill.load448 = load <8 x float>, ptr %.spill140, align 32
  %388 = fmul <8 x float> %.state447, %.spill.load448
  %.state449 = load <8 x float>, ptr %.slot68, align 32
  %.spill.load450 = load <8 x float>, ptr %.spill140, align 32
  %389 = fmul <8 x float> %.state449, %.spill.load450
  %.state451 = load <8 x float>, ptr %.slot69, align 32
  %.spill.load452 = load <8 x float>, ptr %.spill140, align 32
  %390 = fmul <8 x float> %.state451, %.spill.load452
  %.state453 = load <8 x float>, ptr %.slot70, align 32
  %.spill.load454 = load <8 x float>, ptr %.spill140, align 32
  %391 = fmul <8 x float> %.state453, %.spill.load454
  %.state455 = load <8 x float>, ptr %.slot71, align 32
  %.spill.load456 = load <8 x float>, ptr %.spill140, align 32
  %392 = fmul <8 x float> %.state455, %.spill.load456
  %.state457 = load <8 x float>, ptr %.slot72, align 32
  %.spill.load458 = load <8 x float>, ptr %.spill140, align 32
  %393 = fmul <8 x float> %.state457, %.spill.load458
  %.state459 = load <8 x float>, ptr %.slot73, align 32
  %.spill.load460 = load <8 x float>, ptr %.spill140, align 32
  %394 = fmul <8 x float> %.state459, %.spill.load460
  %.state461 = load <8 x float>, ptr %.slot74, align 32
  %.spill.load462 = load <8 x float>, ptr %.spill140, align 32
  %395 = fmul <8 x float> %.state461, %.spill.load462
  %.state463 = load <8 x float>, ptr %.slot75, align 32
  %.spill.load464 = load <8 x float>, ptr %.spill140, align 32
  %396 = fmul <8 x float> %.state463, %.spill.load464
  %.state465 = load <8 x float>, ptr %.slot76, align 32
  %.spill.load466 = load <8 x float>, ptr %.spill140, align 32
  %397 = fmul <8 x float> %.state465, %.spill.load466
  %.state467 = load <8 x float>, ptr %.slot77, align 32
  %.spill.load468 = load <8 x float>, ptr %.spill140, align 32
  %398 = fmul <8 x float> %.state467, %.spill.load468
  %.state469 = load <8 x float>, ptr %.slot78, align 32
  %.spill.load470 = load <8 x float>, ptr %.spill140, align 32
  %399 = fmul <8 x float> %.state469, %.spill.load470
  %.state471 = load <8 x float>, ptr %.slot79, align 32
  %.spill.load472 = load <8 x float>, ptr %.spill140, align 32
  %400 = fmul <8 x float> %.state471, %.spill.load472
  %.state473 = load <8 x float>, ptr %.slot80, align 32
  %.spill.load474 = load <8 x float>, ptr %.spill140, align 32
  %401 = fmul <8 x float> %.state473, %.spill.load474
  %.state475 = load <8 x float>, ptr %.slot81, align 32
  %.spill.load476 = load <8 x float>, ptr %.spill140, align 32
  %402 = fmul <8 x float> %.state475, %.spill.load476
  %.state477 = load <8 x float>, ptr %.slot82, align 32
  %.spill.load478 = load <8 x float>, ptr %.spill140, align 32
  %403 = fmul <8 x float> %.state477, %.spill.load478
  %.state479 = load <8 x float>, ptr %.slot83, align 32
  %.spill.load480 = load <8 x float>, ptr %.spill140, align 32
  %404 = fmul <8 x float> %.state479, %.spill.load480
  %.state481 = load <8 x float>, ptr %.slot84, align 32
  %.spill.load482 = load <8 x float>, ptr %.spill140, align 32
  %405 = fmul <8 x float> %.state481, %.spill.load482
  %.state483 = load <8 x float>, ptr %.slot85, align 32
  %.spill.load484 = load <8 x float>, ptr %.spill140, align 32
  %406 = fmul <8 x float> %.state483, %.spill.load484
  %.state485 = load <8 x float>, ptr %.slot86, align 32
  %.spill.load486 = load <8 x float>, ptr %.spill140, align 32
  %407 = fmul <8 x float> %.state485, %.spill.load486
  %.state487 = load <8 x float>, ptr %.slot87, align 32
  %.spill.load488 = load <8 x float>, ptr %.spill140, align 32
  %408 = fmul <8 x float> %.state487, %.spill.load488
  %.state489 = load <8 x float>, ptr %.slot88, align 32
  %.spill.load490 = load <8 x float>, ptr %.spill140, align 32
  %409 = fmul <8 x float> %.state489, %.spill.load490
  %.state491 = load <8 x float>, ptr %.slot89, align 32
  %.spill.load492 = load <8 x float>, ptr %.spill140, align 32
  %410 = fmul <8 x float> %.state491, %.spill.load492
  %.state493 = load <8 x float>, ptr %.slot90, align 32
  %.spill.load494 = load <8 x float>, ptr %.spill140, align 32
  %411 = fmul <8 x float> %.state493, %.spill.load494
  %.state495 = load <8 x float>, ptr %.slot91, align 32
  %.spill.load496 = load <8 x float>, ptr %.spill140, align 32
  %412 = fmul <8 x float> %.state495, %.spill.load496
  %.state497 = load <8 x float>, ptr %.slot92, align 32
  %.spill.load498 = load <8 x float>, ptr %.spill140, align 32
  %413 = fmul <8 x float> %.state497, %.spill.load498
  %.state499 = load <8 x float>, ptr %.slot93, align 32
  %.spill.load500 = load <8 x float>, ptr %.spill140, align 32
  %414 = fmul <8 x float> %.state499, %.spill.load500
  %.state501 = load <8 x float>, ptr %.slot94, align 32
  %.spill.load502 = load <8 x float>, ptr %.spill140, align 32
  %415 = fmul <8 x float> %.state501, %.spill.load502
  %.state503 = load <8 x float>, ptr %.slot95, align 32
  %.spill.load504 = load <8 x float>, ptr %.spill140, align 32
  %416 = fmul <8 x float> %.state503, %.spill.load504
  %.state505 = load <8 x float>, ptr %.slot96, align 32
  %.spill.load506 = load <8 x float>, ptr %.spill140, align 32
  %417 = fmul <8 x float> %.state505, %.spill.load506
  %.state507 = load <8 x float>, ptr %.slot97, align 32
  %.spill.load508 = load <8 x float>, ptr %.spill140, align 32
  %418 = fmul <8 x float> %.state507, %.spill.load508
  %.state509 = load <8 x float>, ptr %.slot98, align 32
  %.spill.load510 = load <8 x float>, ptr %.spill140, align 32
  %419 = fmul <8 x float> %.state509, %.spill.load510
  %.state511 = load <8 x float>, ptr %.slot99, align 32
  %.spill.load512 = load <8 x float>, ptr %.spill140, align 32
  %420 = fmul <8 x float> %.state511, %.spill.load512
  %.state513 = load <8 x float>, ptr %.slot100, align 32
  %.spill.load514 = load <8 x float>, ptr %.spill140, align 32
  %421 = fmul <8 x float> %.state513, %.spill.load514
  %.state515 = load <8 x float>, ptr %.slot101, align 32
  %.spill.load516 = load <8 x float>, ptr %.spill140, align 32
  %422 = fmul <8 x float> %.state515, %.spill.load516
  %.state517 = load <8 x float>, ptr %.slot102, align 32
  %.spill.load518 = load <8 x float>, ptr %.spill140, align 32
  %423 = fmul <8 x float> %.state517, %.spill.load518
  %424 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %425 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %426 = add <8 x i64> %425, zeroinitializer
  %427 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %424, 0
  %428 = insertvalue { <8 x ptr>, <8 x i64> } %427, <8 x i64> %426, 1
  %429 = extractvalue { <8 x ptr>, <8 x i64> } %428, 0
  %430 = extractvalue { <8 x ptr>, <8 x i64> } %428, 1
  %431 = getelementptr i8, <8 x ptr> %429, <8 x i64> %430
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %360, <8 x ptr> align 1 %431, <8 x i1> %74)
  %432 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %433 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %434 = add <8 x i64> %433, splat (i64 4)
  %435 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %432, 0
  %436 = insertvalue { <8 x ptr>, <8 x i64> } %435, <8 x i64> %434, 1
  %437 = extractvalue { <8 x ptr>, <8 x i64> } %436, 0
  %438 = extractvalue { <8 x ptr>, <8 x i64> } %436, 1
  %439 = getelementptr i8, <8 x ptr> %437, <8 x i64> %438
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %361, <8 x ptr> align 1 %439, <8 x i1> %74)
  %440 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %441 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %442 = add <8 x i64> %441, splat (i64 8)
  %443 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %440, 0
  %444 = insertvalue { <8 x ptr>, <8 x i64> } %443, <8 x i64> %442, 1
  %445 = extractvalue { <8 x ptr>, <8 x i64> } %444, 0
  %446 = extractvalue { <8 x ptr>, <8 x i64> } %444, 1
  %447 = getelementptr i8, <8 x ptr> %445, <8 x i64> %446
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %362, <8 x ptr> align 1 %447, <8 x i1> %74)
  %448 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %449 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %450 = add <8 x i64> %449, splat (i64 12)
  %451 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %448, 0
  %452 = insertvalue { <8 x ptr>, <8 x i64> } %451, <8 x i64> %450, 1
  %453 = extractvalue { <8 x ptr>, <8 x i64> } %452, 0
  %454 = extractvalue { <8 x ptr>, <8 x i64> } %452, 1
  %455 = getelementptr i8, <8 x ptr> %453, <8 x i64> %454
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %363, <8 x ptr> align 1 %455, <8 x i1> %74)
  %456 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %457 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %458 = add <8 x i64> %457, splat (i64 16)
  %459 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %456, 0
  %460 = insertvalue { <8 x ptr>, <8 x i64> } %459, <8 x i64> %458, 1
  %461 = extractvalue { <8 x ptr>, <8 x i64> } %460, 0
  %462 = extractvalue { <8 x ptr>, <8 x i64> } %460, 1
  %463 = getelementptr i8, <8 x ptr> %461, <8 x i64> %462
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %364, <8 x ptr> align 1 %463, <8 x i1> %74)
  %464 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %465 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %466 = add <8 x i64> %465, splat (i64 20)
  %467 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %464, 0
  %468 = insertvalue { <8 x ptr>, <8 x i64> } %467, <8 x i64> %466, 1
  %469 = extractvalue { <8 x ptr>, <8 x i64> } %468, 0
  %470 = extractvalue { <8 x ptr>, <8 x i64> } %468, 1
  %471 = getelementptr i8, <8 x ptr> %469, <8 x i64> %470
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %365, <8 x ptr> align 1 %471, <8 x i1> %74)
  %472 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %473 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %474 = add <8 x i64> %473, splat (i64 24)
  %475 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %472, 0
  %476 = insertvalue { <8 x ptr>, <8 x i64> } %475, <8 x i64> %474, 1
  %477 = extractvalue { <8 x ptr>, <8 x i64> } %476, 0
  %478 = extractvalue { <8 x ptr>, <8 x i64> } %476, 1
  %479 = getelementptr i8, <8 x ptr> %477, <8 x i64> %478
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %366, <8 x ptr> align 1 %479, <8 x i1> %74)
  %480 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %481 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %482 = add <8 x i64> %481, splat (i64 28)
  %483 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %480, 0
  %484 = insertvalue { <8 x ptr>, <8 x i64> } %483, <8 x i64> %482, 1
  %485 = extractvalue { <8 x ptr>, <8 x i64> } %484, 0
  %486 = extractvalue { <8 x ptr>, <8 x i64> } %484, 1
  %487 = getelementptr i8, <8 x ptr> %485, <8 x i64> %486
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %367, <8 x ptr> align 1 %487, <8 x i1> %74)
  %488 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %489 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %490 = add <8 x i64> %489, splat (i64 32)
  %491 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %488, 0
  %492 = insertvalue { <8 x ptr>, <8 x i64> } %491, <8 x i64> %490, 1
  %493 = extractvalue { <8 x ptr>, <8 x i64> } %492, 0
  %494 = extractvalue { <8 x ptr>, <8 x i64> } %492, 1
  %495 = getelementptr i8, <8 x ptr> %493, <8 x i64> %494
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %368, <8 x ptr> align 1 %495, <8 x i1> %74)
  %496 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %497 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %498 = add <8 x i64> %497, splat (i64 36)
  %499 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %496, 0
  %500 = insertvalue { <8 x ptr>, <8 x i64> } %499, <8 x i64> %498, 1
  %501 = extractvalue { <8 x ptr>, <8 x i64> } %500, 0
  %502 = extractvalue { <8 x ptr>, <8 x i64> } %500, 1
  %503 = getelementptr i8, <8 x ptr> %501, <8 x i64> %502
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %369, <8 x ptr> align 1 %503, <8 x i1> %74)
  %504 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %505 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %506 = add <8 x i64> %505, splat (i64 40)
  %507 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %504, 0
  %508 = insertvalue { <8 x ptr>, <8 x i64> } %507, <8 x i64> %506, 1
  %509 = extractvalue { <8 x ptr>, <8 x i64> } %508, 0
  %510 = extractvalue { <8 x ptr>, <8 x i64> } %508, 1
  %511 = getelementptr i8, <8 x ptr> %509, <8 x i64> %510
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %370, <8 x ptr> align 1 %511, <8 x i1> %74)
  %512 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %513 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %514 = add <8 x i64> %513, splat (i64 44)
  %515 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %512, 0
  %516 = insertvalue { <8 x ptr>, <8 x i64> } %515, <8 x i64> %514, 1
  %517 = extractvalue { <8 x ptr>, <8 x i64> } %516, 0
  %518 = extractvalue { <8 x ptr>, <8 x i64> } %516, 1
  %519 = getelementptr i8, <8 x ptr> %517, <8 x i64> %518
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %371, <8 x ptr> align 1 %519, <8 x i1> %74)
  %520 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %521 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %522 = add <8 x i64> %521, splat (i64 48)
  %523 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %520, 0
  %524 = insertvalue { <8 x ptr>, <8 x i64> } %523, <8 x i64> %522, 1
  %525 = extractvalue { <8 x ptr>, <8 x i64> } %524, 0
  %526 = extractvalue { <8 x ptr>, <8 x i64> } %524, 1
  %527 = getelementptr i8, <8 x ptr> %525, <8 x i64> %526
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %372, <8 x ptr> align 1 %527, <8 x i1> %74)
  %528 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %530 = add <8 x i64> %529, splat (i64 52)
  %531 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %528, 0
  %532 = insertvalue { <8 x ptr>, <8 x i64> } %531, <8 x i64> %530, 1
  %533 = extractvalue { <8 x ptr>, <8 x i64> } %532, 0
  %534 = extractvalue { <8 x ptr>, <8 x i64> } %532, 1
  %535 = getelementptr i8, <8 x ptr> %533, <8 x i64> %534
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %373, <8 x ptr> align 1 %535, <8 x i1> %74)
  %536 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %537 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %538 = add <8 x i64> %537, splat (i64 56)
  %539 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %536, 0
  %540 = insertvalue { <8 x ptr>, <8 x i64> } %539, <8 x i64> %538, 1
  %541 = extractvalue { <8 x ptr>, <8 x i64> } %540, 0
  %542 = extractvalue { <8 x ptr>, <8 x i64> } %540, 1
  %543 = getelementptr i8, <8 x ptr> %541, <8 x i64> %542
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %374, <8 x ptr> align 1 %543, <8 x i1> %74)
  %544 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %545 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %546 = add <8 x i64> %545, splat (i64 60)
  %547 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %544, 0
  %548 = insertvalue { <8 x ptr>, <8 x i64> } %547, <8 x i64> %546, 1
  %549 = extractvalue { <8 x ptr>, <8 x i64> } %548, 0
  %550 = extractvalue { <8 x ptr>, <8 x i64> } %548, 1
  %551 = getelementptr i8, <8 x ptr> %549, <8 x i64> %550
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %375, <8 x ptr> align 1 %551, <8 x i1> %74)
  %552 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %553 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %554 = add <8 x i64> %553, splat (i64 64)
  %555 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %552, 0
  %556 = insertvalue { <8 x ptr>, <8 x i64> } %555, <8 x i64> %554, 1
  %557 = extractvalue { <8 x ptr>, <8 x i64> } %556, 0
  %558 = extractvalue { <8 x ptr>, <8 x i64> } %556, 1
  %559 = getelementptr i8, <8 x ptr> %557, <8 x i64> %558
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %376, <8 x ptr> align 1 %559, <8 x i1> %74)
  %560 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %561 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %562 = add <8 x i64> %561, splat (i64 68)
  %563 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %560, 0
  %564 = insertvalue { <8 x ptr>, <8 x i64> } %563, <8 x i64> %562, 1
  %565 = extractvalue { <8 x ptr>, <8 x i64> } %564, 0
  %566 = extractvalue { <8 x ptr>, <8 x i64> } %564, 1
  %567 = getelementptr i8, <8 x ptr> %565, <8 x i64> %566
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %377, <8 x ptr> align 1 %567, <8 x i1> %74)
  %568 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %569 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %570 = add <8 x i64> %569, splat (i64 72)
  %571 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %568, 0
  %572 = insertvalue { <8 x ptr>, <8 x i64> } %571, <8 x i64> %570, 1
  %573 = extractvalue { <8 x ptr>, <8 x i64> } %572, 0
  %574 = extractvalue { <8 x ptr>, <8 x i64> } %572, 1
  %575 = getelementptr i8, <8 x ptr> %573, <8 x i64> %574
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %378, <8 x ptr> align 1 %575, <8 x i1> %74)
  %576 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %577 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %578 = add <8 x i64> %577, splat (i64 76)
  %579 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %576, 0
  %580 = insertvalue { <8 x ptr>, <8 x i64> } %579, <8 x i64> %578, 1
  %581 = extractvalue { <8 x ptr>, <8 x i64> } %580, 0
  %582 = extractvalue { <8 x ptr>, <8 x i64> } %580, 1
  %583 = getelementptr i8, <8 x ptr> %581, <8 x i64> %582
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %379, <8 x ptr> align 1 %583, <8 x i1> %74)
  %584 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %585 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %586 = add <8 x i64> %585, splat (i64 80)
  %587 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %584, 0
  %588 = insertvalue { <8 x ptr>, <8 x i64> } %587, <8 x i64> %586, 1
  %589 = extractvalue { <8 x ptr>, <8 x i64> } %588, 0
  %590 = extractvalue { <8 x ptr>, <8 x i64> } %588, 1
  %591 = getelementptr i8, <8 x ptr> %589, <8 x i64> %590
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %380, <8 x ptr> align 1 %591, <8 x i1> %74)
  %592 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %593 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %594 = add <8 x i64> %593, splat (i64 84)
  %595 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %592, 0
  %596 = insertvalue { <8 x ptr>, <8 x i64> } %595, <8 x i64> %594, 1
  %597 = extractvalue { <8 x ptr>, <8 x i64> } %596, 0
  %598 = extractvalue { <8 x ptr>, <8 x i64> } %596, 1
  %599 = getelementptr i8, <8 x ptr> %597, <8 x i64> %598
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %381, <8 x ptr> align 1 %599, <8 x i1> %74)
  %600 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %601 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %602 = add <8 x i64> %601, splat (i64 88)
  %603 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %600, 0
  %604 = insertvalue { <8 x ptr>, <8 x i64> } %603, <8 x i64> %602, 1
  %605 = extractvalue { <8 x ptr>, <8 x i64> } %604, 0
  %606 = extractvalue { <8 x ptr>, <8 x i64> } %604, 1
  %607 = getelementptr i8, <8 x ptr> %605, <8 x i64> %606
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %382, <8 x ptr> align 1 %607, <8 x i1> %74)
  %608 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %609 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %610 = add <8 x i64> %609, splat (i64 92)
  %611 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %608, 0
  %612 = insertvalue { <8 x ptr>, <8 x i64> } %611, <8 x i64> %610, 1
  %613 = extractvalue { <8 x ptr>, <8 x i64> } %612, 0
  %614 = extractvalue { <8 x ptr>, <8 x i64> } %612, 1
  %615 = getelementptr i8, <8 x ptr> %613, <8 x i64> %614
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %383, <8 x ptr> align 1 %615, <8 x i1> %74)
  %616 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %617 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %618 = add <8 x i64> %617, splat (i64 96)
  %619 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %616, 0
  %620 = insertvalue { <8 x ptr>, <8 x i64> } %619, <8 x i64> %618, 1
  %621 = extractvalue { <8 x ptr>, <8 x i64> } %620, 0
  %622 = extractvalue { <8 x ptr>, <8 x i64> } %620, 1
  %623 = getelementptr i8, <8 x ptr> %621, <8 x i64> %622
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %384, <8 x ptr> align 1 %623, <8 x i1> %74)
  %624 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %625 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %626 = add <8 x i64> %625, splat (i64 100)
  %627 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %624, 0
  %628 = insertvalue { <8 x ptr>, <8 x i64> } %627, <8 x i64> %626, 1
  %629 = extractvalue { <8 x ptr>, <8 x i64> } %628, 0
  %630 = extractvalue { <8 x ptr>, <8 x i64> } %628, 1
  %631 = getelementptr i8, <8 x ptr> %629, <8 x i64> %630
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %385, <8 x ptr> align 1 %631, <8 x i1> %74)
  %632 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %633 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %634 = add <8 x i64> %633, splat (i64 104)
  %635 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %632, 0
  %636 = insertvalue { <8 x ptr>, <8 x i64> } %635, <8 x i64> %634, 1
  %637 = extractvalue { <8 x ptr>, <8 x i64> } %636, 0
  %638 = extractvalue { <8 x ptr>, <8 x i64> } %636, 1
  %639 = getelementptr i8, <8 x ptr> %637, <8 x i64> %638
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %386, <8 x ptr> align 1 %639, <8 x i1> %74)
  %640 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %641 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %642 = add <8 x i64> %641, splat (i64 108)
  %643 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %640, 0
  %644 = insertvalue { <8 x ptr>, <8 x i64> } %643, <8 x i64> %642, 1
  %645 = extractvalue { <8 x ptr>, <8 x i64> } %644, 0
  %646 = extractvalue { <8 x ptr>, <8 x i64> } %644, 1
  %647 = getelementptr i8, <8 x ptr> %645, <8 x i64> %646
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %387, <8 x ptr> align 1 %647, <8 x i1> %74)
  %648 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %649 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %650 = add <8 x i64> %649, splat (i64 112)
  %651 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %648, 0
  %652 = insertvalue { <8 x ptr>, <8 x i64> } %651, <8 x i64> %650, 1
  %653 = extractvalue { <8 x ptr>, <8 x i64> } %652, 0
  %654 = extractvalue { <8 x ptr>, <8 x i64> } %652, 1
  %655 = getelementptr i8, <8 x ptr> %653, <8 x i64> %654
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %388, <8 x ptr> align 1 %655, <8 x i1> %74)
  %656 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %657 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %658 = add <8 x i64> %657, splat (i64 116)
  %659 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %656, 0
  %660 = insertvalue { <8 x ptr>, <8 x i64> } %659, <8 x i64> %658, 1
  %661 = extractvalue { <8 x ptr>, <8 x i64> } %660, 0
  %662 = extractvalue { <8 x ptr>, <8 x i64> } %660, 1
  %663 = getelementptr i8, <8 x ptr> %661, <8 x i64> %662
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %389, <8 x ptr> align 1 %663, <8 x i1> %74)
  %664 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %665 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %666 = add <8 x i64> %665, splat (i64 120)
  %667 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %664, 0
  %668 = insertvalue { <8 x ptr>, <8 x i64> } %667, <8 x i64> %666, 1
  %669 = extractvalue { <8 x ptr>, <8 x i64> } %668, 0
  %670 = extractvalue { <8 x ptr>, <8 x i64> } %668, 1
  %671 = getelementptr i8, <8 x ptr> %669, <8 x i64> %670
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %390, <8 x ptr> align 1 %671, <8 x i1> %74)
  %672 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %673 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %674 = add <8 x i64> %673, splat (i64 124)
  %675 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %672, 0
  %676 = insertvalue { <8 x ptr>, <8 x i64> } %675, <8 x i64> %674, 1
  %677 = extractvalue { <8 x ptr>, <8 x i64> } %676, 0
  %678 = extractvalue { <8 x ptr>, <8 x i64> } %676, 1
  %679 = getelementptr i8, <8 x ptr> %677, <8 x i64> %678
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %391, <8 x ptr> align 1 %679, <8 x i1> %74)
  %680 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %681 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %682 = add <8 x i64> %681, splat (i64 128)
  %683 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %680, 0
  %684 = insertvalue { <8 x ptr>, <8 x i64> } %683, <8 x i64> %682, 1
  %685 = extractvalue { <8 x ptr>, <8 x i64> } %684, 0
  %686 = extractvalue { <8 x ptr>, <8 x i64> } %684, 1
  %687 = getelementptr i8, <8 x ptr> %685, <8 x i64> %686
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %392, <8 x ptr> align 1 %687, <8 x i1> %74)
  %688 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %689 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %690 = add <8 x i64> %689, splat (i64 132)
  %691 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %688, 0
  %692 = insertvalue { <8 x ptr>, <8 x i64> } %691, <8 x i64> %690, 1
  %693 = extractvalue { <8 x ptr>, <8 x i64> } %692, 0
  %694 = extractvalue { <8 x ptr>, <8 x i64> } %692, 1
  %695 = getelementptr i8, <8 x ptr> %693, <8 x i64> %694
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %393, <8 x ptr> align 1 %695, <8 x i1> %74)
  %696 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %697 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %698 = add <8 x i64> %697, splat (i64 136)
  %699 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %696, 0
  %700 = insertvalue { <8 x ptr>, <8 x i64> } %699, <8 x i64> %698, 1
  %701 = extractvalue { <8 x ptr>, <8 x i64> } %700, 0
  %702 = extractvalue { <8 x ptr>, <8 x i64> } %700, 1
  %703 = getelementptr i8, <8 x ptr> %701, <8 x i64> %702
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %394, <8 x ptr> align 1 %703, <8 x i1> %74)
  %704 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %705 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %706 = add <8 x i64> %705, splat (i64 140)
  %707 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %704, 0
  %708 = insertvalue { <8 x ptr>, <8 x i64> } %707, <8 x i64> %706, 1
  %709 = extractvalue { <8 x ptr>, <8 x i64> } %708, 0
  %710 = extractvalue { <8 x ptr>, <8 x i64> } %708, 1
  %711 = getelementptr i8, <8 x ptr> %709, <8 x i64> %710
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %395, <8 x ptr> align 1 %711, <8 x i1> %74)
  %712 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %713 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %714 = add <8 x i64> %713, splat (i64 144)
  %715 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %712, 0
  %716 = insertvalue { <8 x ptr>, <8 x i64> } %715, <8 x i64> %714, 1
  %717 = extractvalue { <8 x ptr>, <8 x i64> } %716, 0
  %718 = extractvalue { <8 x ptr>, <8 x i64> } %716, 1
  %719 = getelementptr i8, <8 x ptr> %717, <8 x i64> %718
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %396, <8 x ptr> align 1 %719, <8 x i1> %74)
  %720 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %721 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %722 = add <8 x i64> %721, splat (i64 148)
  %723 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %720, 0
  %724 = insertvalue { <8 x ptr>, <8 x i64> } %723, <8 x i64> %722, 1
  %725 = extractvalue { <8 x ptr>, <8 x i64> } %724, 0
  %726 = extractvalue { <8 x ptr>, <8 x i64> } %724, 1
  %727 = getelementptr i8, <8 x ptr> %725, <8 x i64> %726
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %397, <8 x ptr> align 1 %727, <8 x i1> %74)
  %728 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %729 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %730 = add <8 x i64> %729, splat (i64 152)
  %731 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %728, 0
  %732 = insertvalue { <8 x ptr>, <8 x i64> } %731, <8 x i64> %730, 1
  %733 = extractvalue { <8 x ptr>, <8 x i64> } %732, 0
  %734 = extractvalue { <8 x ptr>, <8 x i64> } %732, 1
  %735 = getelementptr i8, <8 x ptr> %733, <8 x i64> %734
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %398, <8 x ptr> align 1 %735, <8 x i1> %74)
  %736 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %737 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %738 = add <8 x i64> %737, splat (i64 156)
  %739 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %736, 0
  %740 = insertvalue { <8 x ptr>, <8 x i64> } %739, <8 x i64> %738, 1
  %741 = extractvalue { <8 x ptr>, <8 x i64> } %740, 0
  %742 = extractvalue { <8 x ptr>, <8 x i64> } %740, 1
  %743 = getelementptr i8, <8 x ptr> %741, <8 x i64> %742
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %399, <8 x ptr> align 1 %743, <8 x i1> %74)
  %744 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %745 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %746 = add <8 x i64> %745, splat (i64 160)
  %747 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %744, 0
  %748 = insertvalue { <8 x ptr>, <8 x i64> } %747, <8 x i64> %746, 1
  %749 = extractvalue { <8 x ptr>, <8 x i64> } %748, 0
  %750 = extractvalue { <8 x ptr>, <8 x i64> } %748, 1
  %751 = getelementptr i8, <8 x ptr> %749, <8 x i64> %750
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %400, <8 x ptr> align 1 %751, <8 x i1> %74)
  %752 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %753 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %754 = add <8 x i64> %753, splat (i64 164)
  %755 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %752, 0
  %756 = insertvalue { <8 x ptr>, <8 x i64> } %755, <8 x i64> %754, 1
  %757 = extractvalue { <8 x ptr>, <8 x i64> } %756, 0
  %758 = extractvalue { <8 x ptr>, <8 x i64> } %756, 1
  %759 = getelementptr i8, <8 x ptr> %757, <8 x i64> %758
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %401, <8 x ptr> align 1 %759, <8 x i1> %74)
  %760 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %761 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %762 = add <8 x i64> %761, splat (i64 168)
  %763 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %760, 0
  %764 = insertvalue { <8 x ptr>, <8 x i64> } %763, <8 x i64> %762, 1
  %765 = extractvalue { <8 x ptr>, <8 x i64> } %764, 0
  %766 = extractvalue { <8 x ptr>, <8 x i64> } %764, 1
  %767 = getelementptr i8, <8 x ptr> %765, <8 x i64> %766
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %402, <8 x ptr> align 1 %767, <8 x i1> %74)
  %768 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %769 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %770 = add <8 x i64> %769, splat (i64 172)
  %771 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %768, 0
  %772 = insertvalue { <8 x ptr>, <8 x i64> } %771, <8 x i64> %770, 1
  %773 = extractvalue { <8 x ptr>, <8 x i64> } %772, 0
  %774 = extractvalue { <8 x ptr>, <8 x i64> } %772, 1
  %775 = getelementptr i8, <8 x ptr> %773, <8 x i64> %774
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %403, <8 x ptr> align 1 %775, <8 x i1> %74)
  %776 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %777 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %778 = add <8 x i64> %777, splat (i64 176)
  %779 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %776, 0
  %780 = insertvalue { <8 x ptr>, <8 x i64> } %779, <8 x i64> %778, 1
  %781 = extractvalue { <8 x ptr>, <8 x i64> } %780, 0
  %782 = extractvalue { <8 x ptr>, <8 x i64> } %780, 1
  %783 = getelementptr i8, <8 x ptr> %781, <8 x i64> %782
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %404, <8 x ptr> align 1 %783, <8 x i1> %74)
  %784 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %785 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %786 = add <8 x i64> %785, splat (i64 180)
  %787 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %784, 0
  %788 = insertvalue { <8 x ptr>, <8 x i64> } %787, <8 x i64> %786, 1
  %789 = extractvalue { <8 x ptr>, <8 x i64> } %788, 0
  %790 = extractvalue { <8 x ptr>, <8 x i64> } %788, 1
  %791 = getelementptr i8, <8 x ptr> %789, <8 x i64> %790
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %405, <8 x ptr> align 1 %791, <8 x i1> %74)
  %792 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %793 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %794 = add <8 x i64> %793, splat (i64 184)
  %795 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %792, 0
  %796 = insertvalue { <8 x ptr>, <8 x i64> } %795, <8 x i64> %794, 1
  %797 = extractvalue { <8 x ptr>, <8 x i64> } %796, 0
  %798 = extractvalue { <8 x ptr>, <8 x i64> } %796, 1
  %799 = getelementptr i8, <8 x ptr> %797, <8 x i64> %798
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %406, <8 x ptr> align 1 %799, <8 x i1> %74)
  %800 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %801 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %802 = add <8 x i64> %801, splat (i64 188)
  %803 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %800, 0
  %804 = insertvalue { <8 x ptr>, <8 x i64> } %803, <8 x i64> %802, 1
  %805 = extractvalue { <8 x ptr>, <8 x i64> } %804, 0
  %806 = extractvalue { <8 x ptr>, <8 x i64> } %804, 1
  %807 = getelementptr i8, <8 x ptr> %805, <8 x i64> %806
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %407, <8 x ptr> align 1 %807, <8 x i1> %74)
  %808 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %809 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %810 = add <8 x i64> %809, splat (i64 192)
  %811 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %808, 0
  %812 = insertvalue { <8 x ptr>, <8 x i64> } %811, <8 x i64> %810, 1
  %813 = extractvalue { <8 x ptr>, <8 x i64> } %812, 0
  %814 = extractvalue { <8 x ptr>, <8 x i64> } %812, 1
  %815 = getelementptr i8, <8 x ptr> %813, <8 x i64> %814
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %408, <8 x ptr> align 1 %815, <8 x i1> %74)
  %816 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %817 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %818 = add <8 x i64> %817, splat (i64 196)
  %819 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %816, 0
  %820 = insertvalue { <8 x ptr>, <8 x i64> } %819, <8 x i64> %818, 1
  %821 = extractvalue { <8 x ptr>, <8 x i64> } %820, 0
  %822 = extractvalue { <8 x ptr>, <8 x i64> } %820, 1
  %823 = getelementptr i8, <8 x ptr> %821, <8 x i64> %822
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %409, <8 x ptr> align 1 %823, <8 x i1> %74)
  %824 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %825 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %826 = add <8 x i64> %825, splat (i64 200)
  %827 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %824, 0
  %828 = insertvalue { <8 x ptr>, <8 x i64> } %827, <8 x i64> %826, 1
  %829 = extractvalue { <8 x ptr>, <8 x i64> } %828, 0
  %830 = extractvalue { <8 x ptr>, <8 x i64> } %828, 1
  %831 = getelementptr i8, <8 x ptr> %829, <8 x i64> %830
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %410, <8 x ptr> align 1 %831, <8 x i1> %74)
  %832 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %833 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %834 = add <8 x i64> %833, splat (i64 204)
  %835 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %832, 0
  %836 = insertvalue { <8 x ptr>, <8 x i64> } %835, <8 x i64> %834, 1
  %837 = extractvalue { <8 x ptr>, <8 x i64> } %836, 0
  %838 = extractvalue { <8 x ptr>, <8 x i64> } %836, 1
  %839 = getelementptr i8, <8 x ptr> %837, <8 x i64> %838
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %411, <8 x ptr> align 1 %839, <8 x i1> %74)
  %840 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %841 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %842 = add <8 x i64> %841, splat (i64 208)
  %843 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %840, 0
  %844 = insertvalue { <8 x ptr>, <8 x i64> } %843, <8 x i64> %842, 1
  %845 = extractvalue { <8 x ptr>, <8 x i64> } %844, 0
  %846 = extractvalue { <8 x ptr>, <8 x i64> } %844, 1
  %847 = getelementptr i8, <8 x ptr> %845, <8 x i64> %846
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %412, <8 x ptr> align 1 %847, <8 x i1> %74)
  %848 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %849 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %850 = add <8 x i64> %849, splat (i64 212)
  %851 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %848, 0
  %852 = insertvalue { <8 x ptr>, <8 x i64> } %851, <8 x i64> %850, 1
  %853 = extractvalue { <8 x ptr>, <8 x i64> } %852, 0
  %854 = extractvalue { <8 x ptr>, <8 x i64> } %852, 1
  %855 = getelementptr i8, <8 x ptr> %853, <8 x i64> %854
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %413, <8 x ptr> align 1 %855, <8 x i1> %74)
  %856 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %857 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %858 = add <8 x i64> %857, splat (i64 216)
  %859 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %856, 0
  %860 = insertvalue { <8 x ptr>, <8 x i64> } %859, <8 x i64> %858, 1
  %861 = extractvalue { <8 x ptr>, <8 x i64> } %860, 0
  %862 = extractvalue { <8 x ptr>, <8 x i64> } %860, 1
  %863 = getelementptr i8, <8 x ptr> %861, <8 x i64> %862
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %414, <8 x ptr> align 1 %863, <8 x i1> %74)
  %864 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %865 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %866 = add <8 x i64> %865, splat (i64 220)
  %867 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %864, 0
  %868 = insertvalue { <8 x ptr>, <8 x i64> } %867, <8 x i64> %866, 1
  %869 = extractvalue { <8 x ptr>, <8 x i64> } %868, 0
  %870 = extractvalue { <8 x ptr>, <8 x i64> } %868, 1
  %871 = getelementptr i8, <8 x ptr> %869, <8 x i64> %870
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %415, <8 x ptr> align 1 %871, <8 x i1> %74)
  %872 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %873 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %874 = add <8 x i64> %873, splat (i64 224)
  %875 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %872, 0
  %876 = insertvalue { <8 x ptr>, <8 x i64> } %875, <8 x i64> %874, 1
  %877 = extractvalue { <8 x ptr>, <8 x i64> } %876, 0
  %878 = extractvalue { <8 x ptr>, <8 x i64> } %876, 1
  %879 = getelementptr i8, <8 x ptr> %877, <8 x i64> %878
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %416, <8 x ptr> align 1 %879, <8 x i1> %74)
  %880 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %881 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %882 = add <8 x i64> %881, splat (i64 228)
  %883 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %880, 0
  %884 = insertvalue { <8 x ptr>, <8 x i64> } %883, <8 x i64> %882, 1
  %885 = extractvalue { <8 x ptr>, <8 x i64> } %884, 0
  %886 = extractvalue { <8 x ptr>, <8 x i64> } %884, 1
  %887 = getelementptr i8, <8 x ptr> %885, <8 x i64> %886
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %417, <8 x ptr> align 1 %887, <8 x i1> %74)
  %888 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %889 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %890 = add <8 x i64> %889, splat (i64 232)
  %891 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %888, 0
  %892 = insertvalue { <8 x ptr>, <8 x i64> } %891, <8 x i64> %890, 1
  %893 = extractvalue { <8 x ptr>, <8 x i64> } %892, 0
  %894 = extractvalue { <8 x ptr>, <8 x i64> } %892, 1
  %895 = getelementptr i8, <8 x ptr> %893, <8 x i64> %894
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %418, <8 x ptr> align 1 %895, <8 x i1> %74)
  %896 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %897 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %898 = add <8 x i64> %897, splat (i64 236)
  %899 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %896, 0
  %900 = insertvalue { <8 x ptr>, <8 x i64> } %899, <8 x i64> %898, 1
  %901 = extractvalue { <8 x ptr>, <8 x i64> } %900, 0
  %902 = extractvalue { <8 x ptr>, <8 x i64> } %900, 1
  %903 = getelementptr i8, <8 x ptr> %901, <8 x i64> %902
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %419, <8 x ptr> align 1 %903, <8 x i1> %74)
  %904 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %905 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %906 = add <8 x i64> %905, splat (i64 240)
  %907 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %904, 0
  %908 = insertvalue { <8 x ptr>, <8 x i64> } %907, <8 x i64> %906, 1
  %909 = extractvalue { <8 x ptr>, <8 x i64> } %908, 0
  %910 = extractvalue { <8 x ptr>, <8 x i64> } %908, 1
  %911 = getelementptr i8, <8 x ptr> %909, <8 x i64> %910
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %420, <8 x ptr> align 1 %911, <8 x i1> %74)
  %912 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %913 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %914 = add <8 x i64> %913, splat (i64 244)
  %915 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %912, 0
  %916 = insertvalue { <8 x ptr>, <8 x i64> } %915, <8 x i64> %914, 1
  %917 = extractvalue { <8 x ptr>, <8 x i64> } %916, 0
  %918 = extractvalue { <8 x ptr>, <8 x i64> } %916, 1
  %919 = getelementptr i8, <8 x ptr> %917, <8 x i64> %918
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %421, <8 x ptr> align 1 %919, <8 x i1> %74)
  %920 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %921 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %922 = add <8 x i64> %921, splat (i64 248)
  %923 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %920, 0
  %924 = insertvalue { <8 x ptr>, <8 x i64> } %923, <8 x i64> %922, 1
  %925 = extractvalue { <8 x ptr>, <8 x i64> } %924, 0
  %926 = extractvalue { <8 x ptr>, <8 x i64> } %924, 1
  %927 = getelementptr i8, <8 x ptr> %925, <8 x i64> %926
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %422, <8 x ptr> align 1 %927, <8 x i1> %74)
  %928 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %929 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %930 = add <8 x i64> %929, splat (i64 252)
  %931 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %928, 0
  %932 = insertvalue { <8 x ptr>, <8 x i64> } %931, <8 x i64> %930, 1
  %933 = extractvalue { <8 x ptr>, <8 x i64> } %932, 0
  %934 = extractvalue { <8 x ptr>, <8 x i64> } %932, 1
  %935 = getelementptr i8, <8 x ptr> %933, <8 x i64> %934
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %423, <8 x ptr> align 1 %935, <8 x i1> %74)
  %tile_snapshot.spill.load519 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill141, align 64
  %tile_snapshot.spill.load520 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %936 = extractelement <8 x i1> %74, i64 0
  br i1 %936, label %mma.active521, label %mma.continue522

direct.schedule.9:                                ; preds = %direct.false
  %.state539 = load <8 x float>, ptr %.slot39, align 32
  %.state540 = load <8 x float>, ptr %.slot38, align 32
  %937 = fdiv <8 x float> %.state539, %.state540
  %.state541 = load <8 x float>, ptr %.slot40, align 32
  %.state542 = load <8 x float>, ptr %.slot38, align 32
  %938 = fdiv <8 x float> %.state541, %.state542
  %.state543 = load <8 x float>, ptr %.slot41, align 32
  %.state544 = load <8 x float>, ptr %.slot38, align 32
  %939 = fdiv <8 x float> %.state543, %.state544
  %.state545 = load <8 x float>, ptr %.slot42, align 32
  %.state546 = load <8 x float>, ptr %.slot38, align 32
  %940 = fdiv <8 x float> %.state545, %.state546
  %.state547 = load <8 x float>, ptr %.slot43, align 32
  %.state548 = load <8 x float>, ptr %.slot38, align 32
  %941 = fdiv <8 x float> %.state547, %.state548
  %.state549 = load <8 x float>, ptr %.slot44, align 32
  %.state550 = load <8 x float>, ptr %.slot38, align 32
  %942 = fdiv <8 x float> %.state549, %.state550
  %.state551 = load <8 x float>, ptr %.slot45, align 32
  %.state552 = load <8 x float>, ptr %.slot38, align 32
  %943 = fdiv <8 x float> %.state551, %.state552
  %.state553 = load <8 x float>, ptr %.slot46, align 32
  %.state554 = load <8 x float>, ptr %.slot38, align 32
  %944 = fdiv <8 x float> %.state553, %.state554
  %.state555 = load <8 x float>, ptr %.slot47, align 32
  %.state556 = load <8 x float>, ptr %.slot38, align 32
  %945 = fdiv <8 x float> %.state555, %.state556
  %.state557 = load <8 x float>, ptr %.slot48, align 32
  %.state558 = load <8 x float>, ptr %.slot38, align 32
  %946 = fdiv <8 x float> %.state557, %.state558
  %.state559 = load <8 x float>, ptr %.slot49, align 32
  %.state560 = load <8 x float>, ptr %.slot38, align 32
  %947 = fdiv <8 x float> %.state559, %.state560
  %.state561 = load <8 x float>, ptr %.slot50, align 32
  %.state562 = load <8 x float>, ptr %.slot38, align 32
  %948 = fdiv <8 x float> %.state561, %.state562
  %.state563 = load <8 x float>, ptr %.slot51, align 32
  %.state564 = load <8 x float>, ptr %.slot38, align 32
  %949 = fdiv <8 x float> %.state563, %.state564
  %.state565 = load <8 x float>, ptr %.slot52, align 32
  %.state566 = load <8 x float>, ptr %.slot38, align 32
  %950 = fdiv <8 x float> %.state565, %.state566
  %.state567 = load <8 x float>, ptr %.slot53, align 32
  %.state568 = load <8 x float>, ptr %.slot38, align 32
  %951 = fdiv <8 x float> %.state567, %.state568
  %.state569 = load <8 x float>, ptr %.slot54, align 32
  %.state570 = load <8 x float>, ptr %.slot38, align 32
  %952 = fdiv <8 x float> %.state569, %.state570
  %.state571 = load <8 x float>, ptr %.slot55, align 32
  %.state572 = load <8 x float>, ptr %.slot38, align 32
  %953 = fdiv <8 x float> %.state571, %.state572
  %.state573 = load <8 x float>, ptr %.slot56, align 32
  %.state574 = load <8 x float>, ptr %.slot38, align 32
  %954 = fdiv <8 x float> %.state573, %.state574
  %.state575 = load <8 x float>, ptr %.slot57, align 32
  %.state576 = load <8 x float>, ptr %.slot38, align 32
  %955 = fdiv <8 x float> %.state575, %.state576
  %.state577 = load <8 x float>, ptr %.slot58, align 32
  %.state578 = load <8 x float>, ptr %.slot38, align 32
  %956 = fdiv <8 x float> %.state577, %.state578
  %.state579 = load <8 x float>, ptr %.slot59, align 32
  %.state580 = load <8 x float>, ptr %.slot38, align 32
  %957 = fdiv <8 x float> %.state579, %.state580
  %.state581 = load <8 x float>, ptr %.slot60, align 32
  %.state582 = load <8 x float>, ptr %.slot38, align 32
  %958 = fdiv <8 x float> %.state581, %.state582
  %.state583 = load <8 x float>, ptr %.slot61, align 32
  %.state584 = load <8 x float>, ptr %.slot38, align 32
  %959 = fdiv <8 x float> %.state583, %.state584
  %.state585 = load <8 x float>, ptr %.slot62, align 32
  %.state586 = load <8 x float>, ptr %.slot38, align 32
  %960 = fdiv <8 x float> %.state585, %.state586
  %.state587 = load <8 x float>, ptr %.slot63, align 32
  %.state588 = load <8 x float>, ptr %.slot38, align 32
  %961 = fdiv <8 x float> %.state587, %.state588
  %.state589 = load <8 x float>, ptr %.slot64, align 32
  %.state590 = load <8 x float>, ptr %.slot38, align 32
  %962 = fdiv <8 x float> %.state589, %.state590
  %.state591 = load <8 x float>, ptr %.slot65, align 32
  %.state592 = load <8 x float>, ptr %.slot38, align 32
  %963 = fdiv <8 x float> %.state591, %.state592
  %.state593 = load <8 x float>, ptr %.slot66, align 32
  %.state594 = load <8 x float>, ptr %.slot38, align 32
  %964 = fdiv <8 x float> %.state593, %.state594
  %.state595 = load <8 x float>, ptr %.slot67, align 32
  %.state596 = load <8 x float>, ptr %.slot38, align 32
  %965 = fdiv <8 x float> %.state595, %.state596
  %.state597 = load <8 x float>, ptr %.slot68, align 32
  %.state598 = load <8 x float>, ptr %.slot38, align 32
  %966 = fdiv <8 x float> %.state597, %.state598
  %.state599 = load <8 x float>, ptr %.slot69, align 32
  %.state600 = load <8 x float>, ptr %.slot38, align 32
  %967 = fdiv <8 x float> %.state599, %.state600
  %.state601 = load <8 x float>, ptr %.slot70, align 32
  %.state602 = load <8 x float>, ptr %.slot38, align 32
  %968 = fdiv <8 x float> %.state601, %.state602
  %.state603 = load <8 x float>, ptr %.slot71, align 32
  %.state604 = load <8 x float>, ptr %.slot38, align 32
  %969 = fdiv <8 x float> %.state603, %.state604
  %.state605 = load <8 x float>, ptr %.slot72, align 32
  %.state606 = load <8 x float>, ptr %.slot38, align 32
  %970 = fdiv <8 x float> %.state605, %.state606
  %.state607 = load <8 x float>, ptr %.slot73, align 32
  %.state608 = load <8 x float>, ptr %.slot38, align 32
  %971 = fdiv <8 x float> %.state607, %.state608
  %.state609 = load <8 x float>, ptr %.slot74, align 32
  %.state610 = load <8 x float>, ptr %.slot38, align 32
  %972 = fdiv <8 x float> %.state609, %.state610
  %.state611 = load <8 x float>, ptr %.slot75, align 32
  %.state612 = load <8 x float>, ptr %.slot38, align 32
  %973 = fdiv <8 x float> %.state611, %.state612
  %.state613 = load <8 x float>, ptr %.slot76, align 32
  %.state614 = load <8 x float>, ptr %.slot38, align 32
  %974 = fdiv <8 x float> %.state613, %.state614
  %.state615 = load <8 x float>, ptr %.slot77, align 32
  %.state616 = load <8 x float>, ptr %.slot38, align 32
  %975 = fdiv <8 x float> %.state615, %.state616
  %.state617 = load <8 x float>, ptr %.slot78, align 32
  %.state618 = load <8 x float>, ptr %.slot38, align 32
  %976 = fdiv <8 x float> %.state617, %.state618
  %.state619 = load <8 x float>, ptr %.slot79, align 32
  %.state620 = load <8 x float>, ptr %.slot38, align 32
  %977 = fdiv <8 x float> %.state619, %.state620
  %.state621 = load <8 x float>, ptr %.slot80, align 32
  %.state622 = load <8 x float>, ptr %.slot38, align 32
  %978 = fdiv <8 x float> %.state621, %.state622
  %.state623 = load <8 x float>, ptr %.slot81, align 32
  %.state624 = load <8 x float>, ptr %.slot38, align 32
  %979 = fdiv <8 x float> %.state623, %.state624
  %.state625 = load <8 x float>, ptr %.slot82, align 32
  %.state626 = load <8 x float>, ptr %.slot38, align 32
  %980 = fdiv <8 x float> %.state625, %.state626
  %.state627 = load <8 x float>, ptr %.slot83, align 32
  %.state628 = load <8 x float>, ptr %.slot38, align 32
  %981 = fdiv <8 x float> %.state627, %.state628
  %.state629 = load <8 x float>, ptr %.slot84, align 32
  %.state630 = load <8 x float>, ptr %.slot38, align 32
  %982 = fdiv <8 x float> %.state629, %.state630
  %.state631 = load <8 x float>, ptr %.slot85, align 32
  %.state632 = load <8 x float>, ptr %.slot38, align 32
  %983 = fdiv <8 x float> %.state631, %.state632
  %.state633 = load <8 x float>, ptr %.slot86, align 32
  %.state634 = load <8 x float>, ptr %.slot38, align 32
  %984 = fdiv <8 x float> %.state633, %.state634
  %.state635 = load <8 x float>, ptr %.slot87, align 32
  %.state636 = load <8 x float>, ptr %.slot38, align 32
  %985 = fdiv <8 x float> %.state635, %.state636
  %.state637 = load <8 x float>, ptr %.slot88, align 32
  %.state638 = load <8 x float>, ptr %.slot38, align 32
  %986 = fdiv <8 x float> %.state637, %.state638
  %.state639 = load <8 x float>, ptr %.slot89, align 32
  %.state640 = load <8 x float>, ptr %.slot38, align 32
  %987 = fdiv <8 x float> %.state639, %.state640
  %.state641 = load <8 x float>, ptr %.slot90, align 32
  %.state642 = load <8 x float>, ptr %.slot38, align 32
  %988 = fdiv <8 x float> %.state641, %.state642
  %.state643 = load <8 x float>, ptr %.slot91, align 32
  %.state644 = load <8 x float>, ptr %.slot38, align 32
  %989 = fdiv <8 x float> %.state643, %.state644
  %.state645 = load <8 x float>, ptr %.slot92, align 32
  %.state646 = load <8 x float>, ptr %.slot38, align 32
  %990 = fdiv <8 x float> %.state645, %.state646
  %.state647 = load <8 x float>, ptr %.slot93, align 32
  %.state648 = load <8 x float>, ptr %.slot38, align 32
  %991 = fdiv <8 x float> %.state647, %.state648
  %.state649 = load <8 x float>, ptr %.slot94, align 32
  %.state650 = load <8 x float>, ptr %.slot38, align 32
  %992 = fdiv <8 x float> %.state649, %.state650
  %.state651 = load <8 x float>, ptr %.slot95, align 32
  %.state652 = load <8 x float>, ptr %.slot38, align 32
  %993 = fdiv <8 x float> %.state651, %.state652
  %.state653 = load <8 x float>, ptr %.slot96, align 32
  %.state654 = load <8 x float>, ptr %.slot38, align 32
  %994 = fdiv <8 x float> %.state653, %.state654
  %.state655 = load <8 x float>, ptr %.slot97, align 32
  %.state656 = load <8 x float>, ptr %.slot38, align 32
  %995 = fdiv <8 x float> %.state655, %.state656
  %.state657 = load <8 x float>, ptr %.slot98, align 32
  %.state658 = load <8 x float>, ptr %.slot38, align 32
  %996 = fdiv <8 x float> %.state657, %.state658
  %.state659 = load <8 x float>, ptr %.slot99, align 32
  %.state660 = load <8 x float>, ptr %.slot38, align 32
  %997 = fdiv <8 x float> %.state659, %.state660
  %.state661 = load <8 x float>, ptr %.slot100, align 32
  %.state662 = load <8 x float>, ptr %.slot38, align 32
  %998 = fdiv <8 x float> %.state661, %.state662
  %.state663 = load <8 x float>, ptr %.slot101, align 32
  %.state664 = load <8 x float>, ptr %.slot38, align 32
  %999 = fdiv <8 x float> %.state663, %.state664
  %.state665 = load <8 x float>, ptr %.slot102, align 32
  %.state666 = load <8 x float>, ptr %.slot38, align 32
  %1000 = fdiv <8 x float> %.state665, %.state666
  %.spill.load667 = load i64, ptr %.spill33, align 4
  %1001 = add i64 %.spill.load667, 0
  %.spill.load668 = load <8 x i64>, ptr %.spill, align 64
  %1002 = add <8 x i64> %.spill.load668, zeroinitializer
  %1003 = mul i64 %1001, 8
  %.splatinsert669 = insertelement <8 x i64> poison, i64 %1003, i64 0
  %.splat670 = shufflevector <8 x i64> %.splatinsert669, <8 x i64> poison, <8 x i32> zeroinitializer
  %1004 = add <8 x i64> %.splat670, %1002
  %1005 = mul <8 x i64> %1004, splat (i64 1)
  %.spill.load671 = load i64, ptr %.spill35, align 4
  %.splatinsert672 = insertelement <8 x i64> poison, i64 %.spill.load671, i64 0
  %.splat673 = shufflevector <8 x i64> %.splatinsert672, <8 x i64> poison, <8 x i32> zeroinitializer
  %1006 = add <8 x i64> %1005, %.splat673
  %1007 = mul <8 x i64> %1006, splat (i64 64)
  %1008 = add <8 x i64> %1007, zeroinitializer
  %1009 = extractvalue { ptr, i64 } %50, 0
  %1010 = mul <8 x i64> %1008, splat (i64 4)
  %1011 = getelementptr i8, ptr %1009, <8 x i64> %1010
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %937, <8 x ptr> align 1 %1011, <8 x i1> %74)
  %1012 = add <8 x i64> %1007, splat (i64 1)
  %1013 = extractvalue { ptr, i64 } %50, 0
  %1014 = mul <8 x i64> %1012, splat (i64 4)
  %1015 = getelementptr i8, ptr %1013, <8 x i64> %1014
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %938, <8 x ptr> align 1 %1015, <8 x i1> %74)
  %1016 = add <8 x i64> %1007, splat (i64 2)
  %1017 = extractvalue { ptr, i64 } %50, 0
  %1018 = mul <8 x i64> %1016, splat (i64 4)
  %1019 = getelementptr i8, ptr %1017, <8 x i64> %1018
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %939, <8 x ptr> align 1 %1019, <8 x i1> %74)
  %1020 = add <8 x i64> %1007, splat (i64 3)
  %1021 = extractvalue { ptr, i64 } %50, 0
  %1022 = mul <8 x i64> %1020, splat (i64 4)
  %1023 = getelementptr i8, ptr %1021, <8 x i64> %1022
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %940, <8 x ptr> align 1 %1023, <8 x i1> %74)
  %1024 = add <8 x i64> %1007, splat (i64 4)
  %1025 = extractvalue { ptr, i64 } %50, 0
  %1026 = mul <8 x i64> %1024, splat (i64 4)
  %1027 = getelementptr i8, ptr %1025, <8 x i64> %1026
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %941, <8 x ptr> align 1 %1027, <8 x i1> %74)
  %1028 = add <8 x i64> %1007, splat (i64 5)
  %1029 = extractvalue { ptr, i64 } %50, 0
  %1030 = mul <8 x i64> %1028, splat (i64 4)
  %1031 = getelementptr i8, ptr %1029, <8 x i64> %1030
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %942, <8 x ptr> align 1 %1031, <8 x i1> %74)
  %1032 = add <8 x i64> %1007, splat (i64 6)
  %1033 = extractvalue { ptr, i64 } %50, 0
  %1034 = mul <8 x i64> %1032, splat (i64 4)
  %1035 = getelementptr i8, ptr %1033, <8 x i64> %1034
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %943, <8 x ptr> align 1 %1035, <8 x i1> %74)
  %1036 = add <8 x i64> %1007, splat (i64 7)
  %1037 = extractvalue { ptr, i64 } %50, 0
  %1038 = mul <8 x i64> %1036, splat (i64 4)
  %1039 = getelementptr i8, ptr %1037, <8 x i64> %1038
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %944, <8 x ptr> align 1 %1039, <8 x i1> %74)
  %1040 = add <8 x i64> %1007, splat (i64 8)
  %1041 = extractvalue { ptr, i64 } %50, 0
  %1042 = mul <8 x i64> %1040, splat (i64 4)
  %1043 = getelementptr i8, ptr %1041, <8 x i64> %1042
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %945, <8 x ptr> align 1 %1043, <8 x i1> %74)
  %1044 = add <8 x i64> %1007, splat (i64 9)
  %1045 = extractvalue { ptr, i64 } %50, 0
  %1046 = mul <8 x i64> %1044, splat (i64 4)
  %1047 = getelementptr i8, ptr %1045, <8 x i64> %1046
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %946, <8 x ptr> align 1 %1047, <8 x i1> %74)
  %1048 = add <8 x i64> %1007, splat (i64 10)
  %1049 = extractvalue { ptr, i64 } %50, 0
  %1050 = mul <8 x i64> %1048, splat (i64 4)
  %1051 = getelementptr i8, ptr %1049, <8 x i64> %1050
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %947, <8 x ptr> align 1 %1051, <8 x i1> %74)
  %1052 = add <8 x i64> %1007, splat (i64 11)
  %1053 = extractvalue { ptr, i64 } %50, 0
  %1054 = mul <8 x i64> %1052, splat (i64 4)
  %1055 = getelementptr i8, ptr %1053, <8 x i64> %1054
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %948, <8 x ptr> align 1 %1055, <8 x i1> %74)
  %1056 = add <8 x i64> %1007, splat (i64 12)
  %1057 = extractvalue { ptr, i64 } %50, 0
  %1058 = mul <8 x i64> %1056, splat (i64 4)
  %1059 = getelementptr i8, ptr %1057, <8 x i64> %1058
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %949, <8 x ptr> align 1 %1059, <8 x i1> %74)
  %1060 = add <8 x i64> %1007, splat (i64 13)
  %1061 = extractvalue { ptr, i64 } %50, 0
  %1062 = mul <8 x i64> %1060, splat (i64 4)
  %1063 = getelementptr i8, ptr %1061, <8 x i64> %1062
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %950, <8 x ptr> align 1 %1063, <8 x i1> %74)
  %1064 = add <8 x i64> %1007, splat (i64 14)
  %1065 = extractvalue { ptr, i64 } %50, 0
  %1066 = mul <8 x i64> %1064, splat (i64 4)
  %1067 = getelementptr i8, ptr %1065, <8 x i64> %1066
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %951, <8 x ptr> align 1 %1067, <8 x i1> %74)
  %1068 = add <8 x i64> %1007, splat (i64 15)
  %1069 = extractvalue { ptr, i64 } %50, 0
  %1070 = mul <8 x i64> %1068, splat (i64 4)
  %1071 = getelementptr i8, ptr %1069, <8 x i64> %1070
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %952, <8 x ptr> align 1 %1071, <8 x i1> %74)
  %1072 = add <8 x i64> %1007, splat (i64 16)
  %1073 = extractvalue { ptr, i64 } %50, 0
  %1074 = mul <8 x i64> %1072, splat (i64 4)
  %1075 = getelementptr i8, ptr %1073, <8 x i64> %1074
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %953, <8 x ptr> align 1 %1075, <8 x i1> %74)
  %1076 = add <8 x i64> %1007, splat (i64 17)
  %1077 = extractvalue { ptr, i64 } %50, 0
  %1078 = mul <8 x i64> %1076, splat (i64 4)
  %1079 = getelementptr i8, ptr %1077, <8 x i64> %1078
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %954, <8 x ptr> align 1 %1079, <8 x i1> %74)
  %1080 = add <8 x i64> %1007, splat (i64 18)
  %1081 = extractvalue { ptr, i64 } %50, 0
  %1082 = mul <8 x i64> %1080, splat (i64 4)
  %1083 = getelementptr i8, ptr %1081, <8 x i64> %1082
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %955, <8 x ptr> align 1 %1083, <8 x i1> %74)
  %1084 = add <8 x i64> %1007, splat (i64 19)
  %1085 = extractvalue { ptr, i64 } %50, 0
  %1086 = mul <8 x i64> %1084, splat (i64 4)
  %1087 = getelementptr i8, ptr %1085, <8 x i64> %1086
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %956, <8 x ptr> align 1 %1087, <8 x i1> %74)
  %1088 = add <8 x i64> %1007, splat (i64 20)
  %1089 = extractvalue { ptr, i64 } %50, 0
  %1090 = mul <8 x i64> %1088, splat (i64 4)
  %1091 = getelementptr i8, ptr %1089, <8 x i64> %1090
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %957, <8 x ptr> align 1 %1091, <8 x i1> %74)
  %1092 = add <8 x i64> %1007, splat (i64 21)
  %1093 = extractvalue { ptr, i64 } %50, 0
  %1094 = mul <8 x i64> %1092, splat (i64 4)
  %1095 = getelementptr i8, ptr %1093, <8 x i64> %1094
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %958, <8 x ptr> align 1 %1095, <8 x i1> %74)
  %1096 = add <8 x i64> %1007, splat (i64 22)
  %1097 = extractvalue { ptr, i64 } %50, 0
  %1098 = mul <8 x i64> %1096, splat (i64 4)
  %1099 = getelementptr i8, ptr %1097, <8 x i64> %1098
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %959, <8 x ptr> align 1 %1099, <8 x i1> %74)
  %1100 = add <8 x i64> %1007, splat (i64 23)
  %1101 = extractvalue { ptr, i64 } %50, 0
  %1102 = mul <8 x i64> %1100, splat (i64 4)
  %1103 = getelementptr i8, ptr %1101, <8 x i64> %1102
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %960, <8 x ptr> align 1 %1103, <8 x i1> %74)
  %1104 = add <8 x i64> %1007, splat (i64 24)
  %1105 = extractvalue { ptr, i64 } %50, 0
  %1106 = mul <8 x i64> %1104, splat (i64 4)
  %1107 = getelementptr i8, ptr %1105, <8 x i64> %1106
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %961, <8 x ptr> align 1 %1107, <8 x i1> %74)
  %1108 = add <8 x i64> %1007, splat (i64 25)
  %1109 = extractvalue { ptr, i64 } %50, 0
  %1110 = mul <8 x i64> %1108, splat (i64 4)
  %1111 = getelementptr i8, ptr %1109, <8 x i64> %1110
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %962, <8 x ptr> align 1 %1111, <8 x i1> %74)
  %1112 = add <8 x i64> %1007, splat (i64 26)
  %1113 = extractvalue { ptr, i64 } %50, 0
  %1114 = mul <8 x i64> %1112, splat (i64 4)
  %1115 = getelementptr i8, ptr %1113, <8 x i64> %1114
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %963, <8 x ptr> align 1 %1115, <8 x i1> %74)
  %1116 = add <8 x i64> %1007, splat (i64 27)
  %1117 = extractvalue { ptr, i64 } %50, 0
  %1118 = mul <8 x i64> %1116, splat (i64 4)
  %1119 = getelementptr i8, ptr %1117, <8 x i64> %1118
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %964, <8 x ptr> align 1 %1119, <8 x i1> %74)
  %1120 = add <8 x i64> %1007, splat (i64 28)
  %1121 = extractvalue { ptr, i64 } %50, 0
  %1122 = mul <8 x i64> %1120, splat (i64 4)
  %1123 = getelementptr i8, ptr %1121, <8 x i64> %1122
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %965, <8 x ptr> align 1 %1123, <8 x i1> %74)
  %1124 = add <8 x i64> %1007, splat (i64 29)
  %1125 = extractvalue { ptr, i64 } %50, 0
  %1126 = mul <8 x i64> %1124, splat (i64 4)
  %1127 = getelementptr i8, ptr %1125, <8 x i64> %1126
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %966, <8 x ptr> align 1 %1127, <8 x i1> %74)
  %1128 = add <8 x i64> %1007, splat (i64 30)
  %1129 = extractvalue { ptr, i64 } %50, 0
  %1130 = mul <8 x i64> %1128, splat (i64 4)
  %1131 = getelementptr i8, ptr %1129, <8 x i64> %1130
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %967, <8 x ptr> align 1 %1131, <8 x i1> %74)
  %1132 = add <8 x i64> %1007, splat (i64 31)
  %1133 = extractvalue { ptr, i64 } %50, 0
  %1134 = mul <8 x i64> %1132, splat (i64 4)
  %1135 = getelementptr i8, ptr %1133, <8 x i64> %1134
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %968, <8 x ptr> align 1 %1135, <8 x i1> %74)
  %1136 = add <8 x i64> %1007, splat (i64 32)
  %1137 = extractvalue { ptr, i64 } %50, 0
  %1138 = mul <8 x i64> %1136, splat (i64 4)
  %1139 = getelementptr i8, ptr %1137, <8 x i64> %1138
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %969, <8 x ptr> align 1 %1139, <8 x i1> %74)
  %1140 = add <8 x i64> %1007, splat (i64 33)
  %1141 = extractvalue { ptr, i64 } %50, 0
  %1142 = mul <8 x i64> %1140, splat (i64 4)
  %1143 = getelementptr i8, ptr %1141, <8 x i64> %1142
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %970, <8 x ptr> align 1 %1143, <8 x i1> %74)
  %1144 = add <8 x i64> %1007, splat (i64 34)
  %1145 = extractvalue { ptr, i64 } %50, 0
  %1146 = mul <8 x i64> %1144, splat (i64 4)
  %1147 = getelementptr i8, ptr %1145, <8 x i64> %1146
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %971, <8 x ptr> align 1 %1147, <8 x i1> %74)
  %1148 = add <8 x i64> %1007, splat (i64 35)
  %1149 = extractvalue { ptr, i64 } %50, 0
  %1150 = mul <8 x i64> %1148, splat (i64 4)
  %1151 = getelementptr i8, ptr %1149, <8 x i64> %1150
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %972, <8 x ptr> align 1 %1151, <8 x i1> %74)
  %1152 = add <8 x i64> %1007, splat (i64 36)
  %1153 = extractvalue { ptr, i64 } %50, 0
  %1154 = mul <8 x i64> %1152, splat (i64 4)
  %1155 = getelementptr i8, ptr %1153, <8 x i64> %1154
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %973, <8 x ptr> align 1 %1155, <8 x i1> %74)
  %1156 = add <8 x i64> %1007, splat (i64 37)
  %1157 = extractvalue { ptr, i64 } %50, 0
  %1158 = mul <8 x i64> %1156, splat (i64 4)
  %1159 = getelementptr i8, ptr %1157, <8 x i64> %1158
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %974, <8 x ptr> align 1 %1159, <8 x i1> %74)
  %1160 = add <8 x i64> %1007, splat (i64 38)
  %1161 = extractvalue { ptr, i64 } %50, 0
  %1162 = mul <8 x i64> %1160, splat (i64 4)
  %1163 = getelementptr i8, ptr %1161, <8 x i64> %1162
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %975, <8 x ptr> align 1 %1163, <8 x i1> %74)
  %1164 = add <8 x i64> %1007, splat (i64 39)
  %1165 = extractvalue { ptr, i64 } %50, 0
  %1166 = mul <8 x i64> %1164, splat (i64 4)
  %1167 = getelementptr i8, ptr %1165, <8 x i64> %1166
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %976, <8 x ptr> align 1 %1167, <8 x i1> %74)
  %1168 = add <8 x i64> %1007, splat (i64 40)
  %1169 = extractvalue { ptr, i64 } %50, 0
  %1170 = mul <8 x i64> %1168, splat (i64 4)
  %1171 = getelementptr i8, ptr %1169, <8 x i64> %1170
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %977, <8 x ptr> align 1 %1171, <8 x i1> %74)
  %1172 = add <8 x i64> %1007, splat (i64 41)
  %1173 = extractvalue { ptr, i64 } %50, 0
  %1174 = mul <8 x i64> %1172, splat (i64 4)
  %1175 = getelementptr i8, ptr %1173, <8 x i64> %1174
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %978, <8 x ptr> align 1 %1175, <8 x i1> %74)
  %1176 = add <8 x i64> %1007, splat (i64 42)
  %1177 = extractvalue { ptr, i64 } %50, 0
  %1178 = mul <8 x i64> %1176, splat (i64 4)
  %1179 = getelementptr i8, ptr %1177, <8 x i64> %1178
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %979, <8 x ptr> align 1 %1179, <8 x i1> %74)
  %1180 = add <8 x i64> %1007, splat (i64 43)
  %1181 = extractvalue { ptr, i64 } %50, 0
  %1182 = mul <8 x i64> %1180, splat (i64 4)
  %1183 = getelementptr i8, ptr %1181, <8 x i64> %1182
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %980, <8 x ptr> align 1 %1183, <8 x i1> %74)
  %1184 = add <8 x i64> %1007, splat (i64 44)
  %1185 = extractvalue { ptr, i64 } %50, 0
  %1186 = mul <8 x i64> %1184, splat (i64 4)
  %1187 = getelementptr i8, ptr %1185, <8 x i64> %1186
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %981, <8 x ptr> align 1 %1187, <8 x i1> %74)
  %1188 = add <8 x i64> %1007, splat (i64 45)
  %1189 = extractvalue { ptr, i64 } %50, 0
  %1190 = mul <8 x i64> %1188, splat (i64 4)
  %1191 = getelementptr i8, ptr %1189, <8 x i64> %1190
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %982, <8 x ptr> align 1 %1191, <8 x i1> %74)
  %1192 = add <8 x i64> %1007, splat (i64 46)
  %1193 = extractvalue { ptr, i64 } %50, 0
  %1194 = mul <8 x i64> %1192, splat (i64 4)
  %1195 = getelementptr i8, ptr %1193, <8 x i64> %1194
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %983, <8 x ptr> align 1 %1195, <8 x i1> %74)
  %1196 = add <8 x i64> %1007, splat (i64 47)
  %1197 = extractvalue { ptr, i64 } %50, 0
  %1198 = mul <8 x i64> %1196, splat (i64 4)
  %1199 = getelementptr i8, ptr %1197, <8 x i64> %1198
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %984, <8 x ptr> align 1 %1199, <8 x i1> %74)
  %1200 = add <8 x i64> %1007, splat (i64 48)
  %1201 = extractvalue { ptr, i64 } %50, 0
  %1202 = mul <8 x i64> %1200, splat (i64 4)
  %1203 = getelementptr i8, ptr %1201, <8 x i64> %1202
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %985, <8 x ptr> align 1 %1203, <8 x i1> %74)
  %1204 = add <8 x i64> %1007, splat (i64 49)
  %1205 = extractvalue { ptr, i64 } %50, 0
  %1206 = mul <8 x i64> %1204, splat (i64 4)
  %1207 = getelementptr i8, ptr %1205, <8 x i64> %1206
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %986, <8 x ptr> align 1 %1207, <8 x i1> %74)
  %1208 = add <8 x i64> %1007, splat (i64 50)
  %1209 = extractvalue { ptr, i64 } %50, 0
  %1210 = mul <8 x i64> %1208, splat (i64 4)
  %1211 = getelementptr i8, ptr %1209, <8 x i64> %1210
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %987, <8 x ptr> align 1 %1211, <8 x i1> %74)
  %1212 = add <8 x i64> %1007, splat (i64 51)
  %1213 = extractvalue { ptr, i64 } %50, 0
  %1214 = mul <8 x i64> %1212, splat (i64 4)
  %1215 = getelementptr i8, ptr %1213, <8 x i64> %1214
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %988, <8 x ptr> align 1 %1215, <8 x i1> %74)
  %1216 = add <8 x i64> %1007, splat (i64 52)
  %1217 = extractvalue { ptr, i64 } %50, 0
  %1218 = mul <8 x i64> %1216, splat (i64 4)
  %1219 = getelementptr i8, ptr %1217, <8 x i64> %1218
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %989, <8 x ptr> align 1 %1219, <8 x i1> %74)
  %1220 = add <8 x i64> %1007, splat (i64 53)
  %1221 = extractvalue { ptr, i64 } %50, 0
  %1222 = mul <8 x i64> %1220, splat (i64 4)
  %1223 = getelementptr i8, ptr %1221, <8 x i64> %1222
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %990, <8 x ptr> align 1 %1223, <8 x i1> %74)
  %1224 = add <8 x i64> %1007, splat (i64 54)
  %1225 = extractvalue { ptr, i64 } %50, 0
  %1226 = mul <8 x i64> %1224, splat (i64 4)
  %1227 = getelementptr i8, ptr %1225, <8 x i64> %1226
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %991, <8 x ptr> align 1 %1227, <8 x i1> %74)
  %1228 = add <8 x i64> %1007, splat (i64 55)
  %1229 = extractvalue { ptr, i64 } %50, 0
  %1230 = mul <8 x i64> %1228, splat (i64 4)
  %1231 = getelementptr i8, ptr %1229, <8 x i64> %1230
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %992, <8 x ptr> align 1 %1231, <8 x i1> %74)
  %1232 = add <8 x i64> %1007, splat (i64 56)
  %1233 = extractvalue { ptr, i64 } %50, 0
  %1234 = mul <8 x i64> %1232, splat (i64 4)
  %1235 = getelementptr i8, ptr %1233, <8 x i64> %1234
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %993, <8 x ptr> align 1 %1235, <8 x i1> %74)
  %1236 = add <8 x i64> %1007, splat (i64 57)
  %1237 = extractvalue { ptr, i64 } %50, 0
  %1238 = mul <8 x i64> %1236, splat (i64 4)
  %1239 = getelementptr i8, ptr %1237, <8 x i64> %1238
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %994, <8 x ptr> align 1 %1239, <8 x i1> %74)
  %1240 = add <8 x i64> %1007, splat (i64 58)
  %1241 = extractvalue { ptr, i64 } %50, 0
  %1242 = mul <8 x i64> %1240, splat (i64 4)
  %1243 = getelementptr i8, ptr %1241, <8 x i64> %1242
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %995, <8 x ptr> align 1 %1243, <8 x i1> %74)
  %1244 = add <8 x i64> %1007, splat (i64 59)
  %1245 = extractvalue { ptr, i64 } %50, 0
  %1246 = mul <8 x i64> %1244, splat (i64 4)
  %1247 = getelementptr i8, ptr %1245, <8 x i64> %1246
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %996, <8 x ptr> align 1 %1247, <8 x i1> %74)
  %1248 = add <8 x i64> %1007, splat (i64 60)
  %1249 = extractvalue { ptr, i64 } %50, 0
  %1250 = mul <8 x i64> %1248, splat (i64 4)
  %1251 = getelementptr i8, ptr %1249, <8 x i64> %1250
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %997, <8 x ptr> align 1 %1251, <8 x i1> %74)
  %1252 = add <8 x i64> %1007, splat (i64 61)
  %1253 = extractvalue { ptr, i64 } %50, 0
  %1254 = mul <8 x i64> %1252, splat (i64 4)
  %1255 = getelementptr i8, ptr %1253, <8 x i64> %1254
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %998, <8 x ptr> align 1 %1255, <8 x i1> %74)
  %1256 = add <8 x i64> %1007, splat (i64 62)
  %1257 = extractvalue { ptr, i64 } %50, 0
  %1258 = mul <8 x i64> %1256, splat (i64 4)
  %1259 = getelementptr i8, ptr %1257, <8 x i64> %1258
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %999, <8 x ptr> align 1 %1259, <8 x i1> %74)
  %1260 = add <8 x i64> %1007, splat (i64 63)
  %1261 = extractvalue { ptr, i64 } %50, 0
  %1262 = mul <8 x i64> %1260, splat (i64 4)
  %1263 = getelementptr i8, ptr %1261, <8 x i64> %1262
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1000, <8 x ptr> align 1 %1263, <8 x i1> %74)
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

copy.active:                                      ; preds = %direct.schedule.0
  %1264 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1265 = extractelement <8 x ptr> %1264, i64 0
  %1266 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1267 = extractelement <8 x i64> %1266, i64 0
  %1268 = getelementptr i8, ptr %1265, i64 %1267
  %1269 = extractelement <8 x i64> %101, i64 0
  call void @llm_attention.contiguous_copy(ptr %102, i64 %1269, ptr %1268)
  br label %copy.continue

copy.continue:                                    ; preds = %copy.active, %direct.schedule.0
  %1270 = extractelement <8 x i1> %74, i64 1
  br i1 %1270, label %copy.active155, label %copy.continue156

copy.active155:                                   ; preds = %copy.continue
  %1271 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1272 = extractelement <8 x ptr> %1271, i64 1
  %1273 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1274 = extractelement <8 x i64> %1273, i64 1
  %1275 = getelementptr i8, ptr %1272, i64 %1274
  %1276 = extractelement <8 x i64> %101, i64 1
  call void @llm_attention.contiguous_copy(ptr %102, i64 %1276, ptr %1275)
  br label %copy.continue156

copy.continue156:                                 ; preds = %copy.active155, %copy.continue
  %1277 = extractelement <8 x i1> %74, i64 2
  br i1 %1277, label %copy.active157, label %copy.continue158

copy.active157:                                   ; preds = %copy.continue156
  %1278 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1279 = extractelement <8 x ptr> %1278, i64 2
  %1280 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1281 = extractelement <8 x i64> %1280, i64 2
  %1282 = getelementptr i8, ptr %1279, i64 %1281
  %1283 = extractelement <8 x i64> %101, i64 2
  call void @llm_attention.contiguous_copy(ptr %102, i64 %1283, ptr %1282)
  br label %copy.continue158

copy.continue158:                                 ; preds = %copy.active157, %copy.continue156
  %1284 = extractelement <8 x i1> %74, i64 3
  br i1 %1284, label %copy.active159, label %copy.continue160

copy.active159:                                   ; preds = %copy.continue158
  %1285 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1286 = extractelement <8 x ptr> %1285, i64 3
  %1287 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1288 = extractelement <8 x i64> %1287, i64 3
  %1289 = getelementptr i8, ptr %1286, i64 %1288
  %1290 = extractelement <8 x i64> %101, i64 3
  call void @llm_attention.contiguous_copy(ptr %102, i64 %1290, ptr %1289)
  br label %copy.continue160

copy.continue160:                                 ; preds = %copy.active159, %copy.continue158
  %1291 = extractelement <8 x i1> %74, i64 4
  br i1 %1291, label %copy.active161, label %copy.continue162

copy.active161:                                   ; preds = %copy.continue160
  %1292 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1293 = extractelement <8 x ptr> %1292, i64 4
  %1294 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1295 = extractelement <8 x i64> %1294, i64 4
  %1296 = getelementptr i8, ptr %1293, i64 %1295
  %1297 = extractelement <8 x i64> %101, i64 4
  call void @llm_attention.contiguous_copy(ptr %102, i64 %1297, ptr %1296)
  br label %copy.continue162

copy.continue162:                                 ; preds = %copy.active161, %copy.continue160
  %1298 = extractelement <8 x i1> %74, i64 5
  br i1 %1298, label %copy.active163, label %copy.continue164

copy.active163:                                   ; preds = %copy.continue162
  %1299 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1300 = extractelement <8 x ptr> %1299, i64 5
  %1301 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1302 = extractelement <8 x i64> %1301, i64 5
  %1303 = getelementptr i8, ptr %1300, i64 %1302
  %1304 = extractelement <8 x i64> %101, i64 5
  call void @llm_attention.contiguous_copy(ptr %102, i64 %1304, ptr %1303)
  br label %copy.continue164

copy.continue164:                                 ; preds = %copy.active163, %copy.continue162
  %1305 = extractelement <8 x i1> %74, i64 6
  br i1 %1305, label %copy.active165, label %copy.continue166

copy.active165:                                   ; preds = %copy.continue164
  %1306 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1307 = extractelement <8 x ptr> %1306, i64 6
  %1308 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1309 = extractelement <8 x i64> %1308, i64 6
  %1310 = getelementptr i8, ptr %1307, i64 %1309
  %1311 = extractelement <8 x i64> %101, i64 6
  call void @llm_attention.contiguous_copy(ptr %102, i64 %1311, ptr %1310)
  br label %copy.continue166

copy.continue166:                                 ; preds = %copy.active165, %copy.continue164
  %1312 = extractelement <8 x i1> %74, i64 7
  br i1 %1312, label %copy.active167, label %copy.continue168

copy.active167:                                   ; preds = %copy.continue166
  %1313 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1314 = extractelement <8 x ptr> %1313, i64 7
  %1315 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1316 = extractelement <8 x i64> %1315, i64 7
  %1317 = getelementptr i8, ptr %1314, i64 %1316
  %1318 = extractelement <8 x i64> %101, i64 7
  call void @llm_attention.contiguous_copy(ptr %102, i64 %1318, ptr %1317)
  br label %copy.continue168

copy.continue168:                                 ; preds = %copy.active167, %copy.continue166
  store i64 0, ptr %.slot, align 4
  %1319 = load <8 x float>, ptr %.slot37, align 32
  %1320 = select <8 x i1> %74, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %1319
  store <8 x float> %1320, ptr %.slot37, align 32
  %1321 = load <8 x float>, ptr %.slot38, align 32
  %1322 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1321
  store <8 x float> %1322, ptr %.slot38, align 32
  %1323 = load <8 x float>, ptr %.slot39, align 32
  %1324 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1323
  store <8 x float> %1324, ptr %.slot39, align 32
  %1325 = load <8 x float>, ptr %.slot40, align 32
  %1326 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1325
  store <8 x float> %1326, ptr %.slot40, align 32
  %1327 = load <8 x float>, ptr %.slot41, align 32
  %1328 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1327
  store <8 x float> %1328, ptr %.slot41, align 32
  %1329 = load <8 x float>, ptr %.slot42, align 32
  %1330 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1329
  store <8 x float> %1330, ptr %.slot42, align 32
  %1331 = load <8 x float>, ptr %.slot43, align 32
  %1332 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1331
  store <8 x float> %1332, ptr %.slot43, align 32
  %1333 = load <8 x float>, ptr %.slot44, align 32
  %1334 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1333
  store <8 x float> %1334, ptr %.slot44, align 32
  %1335 = load <8 x float>, ptr %.slot45, align 32
  %1336 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1335
  store <8 x float> %1336, ptr %.slot45, align 32
  %1337 = load <8 x float>, ptr %.slot46, align 32
  %1338 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1337
  store <8 x float> %1338, ptr %.slot46, align 32
  %1339 = load <8 x float>, ptr %.slot47, align 32
  %1340 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1339
  store <8 x float> %1340, ptr %.slot47, align 32
  %1341 = load <8 x float>, ptr %.slot48, align 32
  %1342 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1341
  store <8 x float> %1342, ptr %.slot48, align 32
  %1343 = load <8 x float>, ptr %.slot49, align 32
  %1344 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1343
  store <8 x float> %1344, ptr %.slot49, align 32
  %1345 = load <8 x float>, ptr %.slot50, align 32
  %1346 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1345
  store <8 x float> %1346, ptr %.slot50, align 32
  %1347 = load <8 x float>, ptr %.slot51, align 32
  %1348 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1347
  store <8 x float> %1348, ptr %.slot51, align 32
  %1349 = load <8 x float>, ptr %.slot52, align 32
  %1350 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1349
  store <8 x float> %1350, ptr %.slot52, align 32
  %1351 = load <8 x float>, ptr %.slot53, align 32
  %1352 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1351
  store <8 x float> %1352, ptr %.slot53, align 32
  %1353 = load <8 x float>, ptr %.slot54, align 32
  %1354 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1353
  store <8 x float> %1354, ptr %.slot54, align 32
  %1355 = load <8 x float>, ptr %.slot55, align 32
  %1356 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1355
  store <8 x float> %1356, ptr %.slot55, align 32
  %1357 = load <8 x float>, ptr %.slot56, align 32
  %1358 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1357
  store <8 x float> %1358, ptr %.slot56, align 32
  %1359 = load <8 x float>, ptr %.slot57, align 32
  %1360 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1359
  store <8 x float> %1360, ptr %.slot57, align 32
  %1361 = load <8 x float>, ptr %.slot58, align 32
  %1362 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1361
  store <8 x float> %1362, ptr %.slot58, align 32
  %1363 = load <8 x float>, ptr %.slot59, align 32
  %1364 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1363
  store <8 x float> %1364, ptr %.slot59, align 32
  %1365 = load <8 x float>, ptr %.slot60, align 32
  %1366 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1365
  store <8 x float> %1366, ptr %.slot60, align 32
  %1367 = load <8 x float>, ptr %.slot61, align 32
  %1368 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1367
  store <8 x float> %1368, ptr %.slot61, align 32
  %1369 = load <8 x float>, ptr %.slot62, align 32
  %1370 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1369
  store <8 x float> %1370, ptr %.slot62, align 32
  %1371 = load <8 x float>, ptr %.slot63, align 32
  %1372 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1371
  store <8 x float> %1372, ptr %.slot63, align 32
  %1373 = load <8 x float>, ptr %.slot64, align 32
  %1374 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1373
  store <8 x float> %1374, ptr %.slot64, align 32
  %1375 = load <8 x float>, ptr %.slot65, align 32
  %1376 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1375
  store <8 x float> %1376, ptr %.slot65, align 32
  %1377 = load <8 x float>, ptr %.slot66, align 32
  %1378 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1377
  store <8 x float> %1378, ptr %.slot66, align 32
  %1379 = load <8 x float>, ptr %.slot67, align 32
  %1380 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1379
  store <8 x float> %1380, ptr %.slot67, align 32
  %1381 = load <8 x float>, ptr %.slot68, align 32
  %1382 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1381
  store <8 x float> %1382, ptr %.slot68, align 32
  %1383 = load <8 x float>, ptr %.slot69, align 32
  %1384 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1383
  store <8 x float> %1384, ptr %.slot69, align 32
  %1385 = load <8 x float>, ptr %.slot70, align 32
  %1386 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1385
  store <8 x float> %1386, ptr %.slot70, align 32
  %1387 = load <8 x float>, ptr %.slot71, align 32
  %1388 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1387
  store <8 x float> %1388, ptr %.slot71, align 32
  %1389 = load <8 x float>, ptr %.slot72, align 32
  %1390 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1389
  store <8 x float> %1390, ptr %.slot72, align 32
  %1391 = load <8 x float>, ptr %.slot73, align 32
  %1392 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1391
  store <8 x float> %1392, ptr %.slot73, align 32
  %1393 = load <8 x float>, ptr %.slot74, align 32
  %1394 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1393
  store <8 x float> %1394, ptr %.slot74, align 32
  %1395 = load <8 x float>, ptr %.slot75, align 32
  %1396 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1395
  store <8 x float> %1396, ptr %.slot75, align 32
  %1397 = load <8 x float>, ptr %.slot76, align 32
  %1398 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1397
  store <8 x float> %1398, ptr %.slot76, align 32
  %1399 = load <8 x float>, ptr %.slot77, align 32
  %1400 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1399
  store <8 x float> %1400, ptr %.slot77, align 32
  %1401 = load <8 x float>, ptr %.slot78, align 32
  %1402 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1401
  store <8 x float> %1402, ptr %.slot78, align 32
  %1403 = load <8 x float>, ptr %.slot79, align 32
  %1404 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1403
  store <8 x float> %1404, ptr %.slot79, align 32
  %1405 = load <8 x float>, ptr %.slot80, align 32
  %1406 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1405
  store <8 x float> %1406, ptr %.slot80, align 32
  %1407 = load <8 x float>, ptr %.slot81, align 32
  %1408 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1407
  store <8 x float> %1408, ptr %.slot81, align 32
  %1409 = load <8 x float>, ptr %.slot82, align 32
  %1410 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1409
  store <8 x float> %1410, ptr %.slot82, align 32
  %1411 = load <8 x float>, ptr %.slot83, align 32
  %1412 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1411
  store <8 x float> %1412, ptr %.slot83, align 32
  %1413 = load <8 x float>, ptr %.slot84, align 32
  %1414 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1413
  store <8 x float> %1414, ptr %.slot84, align 32
  %1415 = load <8 x float>, ptr %.slot85, align 32
  %1416 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1415
  store <8 x float> %1416, ptr %.slot85, align 32
  %1417 = load <8 x float>, ptr %.slot86, align 32
  %1418 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1417
  store <8 x float> %1418, ptr %.slot86, align 32
  %1419 = load <8 x float>, ptr %.slot87, align 32
  %1420 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1419
  store <8 x float> %1420, ptr %.slot87, align 32
  %1421 = load <8 x float>, ptr %.slot88, align 32
  %1422 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1421
  store <8 x float> %1422, ptr %.slot88, align 32
  %1423 = load <8 x float>, ptr %.slot89, align 32
  %1424 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1423
  store <8 x float> %1424, ptr %.slot89, align 32
  %1425 = load <8 x float>, ptr %.slot90, align 32
  %1426 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1425
  store <8 x float> %1426, ptr %.slot90, align 32
  %1427 = load <8 x float>, ptr %.slot91, align 32
  %1428 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1427
  store <8 x float> %1428, ptr %.slot91, align 32
  %1429 = load <8 x float>, ptr %.slot92, align 32
  %1430 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1429
  store <8 x float> %1430, ptr %.slot92, align 32
  %1431 = load <8 x float>, ptr %.slot93, align 32
  %1432 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1431
  store <8 x float> %1432, ptr %.slot93, align 32
  %1433 = load <8 x float>, ptr %.slot94, align 32
  %1434 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1433
  store <8 x float> %1434, ptr %.slot94, align 32
  %1435 = load <8 x float>, ptr %.slot95, align 32
  %1436 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1435
  store <8 x float> %1436, ptr %.slot95, align 32
  %1437 = load <8 x float>, ptr %.slot96, align 32
  %1438 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1437
  store <8 x float> %1438, ptr %.slot96, align 32
  %1439 = load <8 x float>, ptr %.slot97, align 32
  %1440 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1439
  store <8 x float> %1440, ptr %.slot97, align 32
  %1441 = load <8 x float>, ptr %.slot98, align 32
  %1442 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1441
  store <8 x float> %1442, ptr %.slot98, align 32
  %1443 = load <8 x float>, ptr %.slot99, align 32
  %1444 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1443
  store <8 x float> %1444, ptr %.slot99, align 32
  %1445 = load <8 x float>, ptr %.slot100, align 32
  %1446 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1445
  store <8 x float> %1446, ptr %.slot100, align 32
  %1447 = load <8 x float>, ptr %.slot101, align 32
  %1448 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1447
  store <8 x float> %1448, ptr %.slot101, align 32
  %1449 = load <8 x float>, ptr %.slot102, align 32
  %1450 = select <8 x i1> %74, <8 x float> zeroinitializer, <8 x float> %1449
  store <8 x float> %1450, ptr %.slot102, align 32
  br label %direct.schedule.1

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.9

copy.active175:                                   ; preds = %direct.schedule.2
  %1451 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1452 = extractelement <8 x ptr> %1451, i64 0
  %1453 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1454 = extractelement <8 x i64> %1453, i64 0
  %1455 = getelementptr i8, ptr %1452, i64 %1454
  %1456 = extractelement <8 x i64> %111, i64 0
  call void @llm_attention.contiguous_copy.1(ptr %112, i64 %1456, ptr %1455)
  br label %copy.continue176

copy.continue176:                                 ; preds = %copy.active175, %direct.schedule.2
  %1457 = extractelement <8 x i1> %74, i64 1
  br i1 %1457, label %copy.active177, label %copy.continue178

copy.active177:                                   ; preds = %copy.continue176
  %1458 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1459 = extractelement <8 x ptr> %1458, i64 1
  %1460 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1461 = extractelement <8 x i64> %1460, i64 1
  %1462 = getelementptr i8, ptr %1459, i64 %1461
  %1463 = extractelement <8 x i64> %111, i64 1
  call void @llm_attention.contiguous_copy.1(ptr %112, i64 %1463, ptr %1462)
  br label %copy.continue178

copy.continue178:                                 ; preds = %copy.active177, %copy.continue176
  %1464 = extractelement <8 x i1> %74, i64 2
  br i1 %1464, label %copy.active179, label %copy.continue180

copy.active179:                                   ; preds = %copy.continue178
  %1465 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1466 = extractelement <8 x ptr> %1465, i64 2
  %1467 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1468 = extractelement <8 x i64> %1467, i64 2
  %1469 = getelementptr i8, ptr %1466, i64 %1468
  %1470 = extractelement <8 x i64> %111, i64 2
  call void @llm_attention.contiguous_copy.1(ptr %112, i64 %1470, ptr %1469)
  br label %copy.continue180

copy.continue180:                                 ; preds = %copy.active179, %copy.continue178
  %1471 = extractelement <8 x i1> %74, i64 3
  br i1 %1471, label %copy.active181, label %copy.continue182

copy.active181:                                   ; preds = %copy.continue180
  %1472 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1473 = extractelement <8 x ptr> %1472, i64 3
  %1474 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1475 = extractelement <8 x i64> %1474, i64 3
  %1476 = getelementptr i8, ptr %1473, i64 %1475
  %1477 = extractelement <8 x i64> %111, i64 3
  call void @llm_attention.contiguous_copy.1(ptr %112, i64 %1477, ptr %1476)
  br label %copy.continue182

copy.continue182:                                 ; preds = %copy.active181, %copy.continue180
  %1478 = extractelement <8 x i1> %74, i64 4
  br i1 %1478, label %copy.active183, label %copy.continue184

copy.active183:                                   ; preds = %copy.continue182
  %1479 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1480 = extractelement <8 x ptr> %1479, i64 4
  %1481 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1482 = extractelement <8 x i64> %1481, i64 4
  %1483 = getelementptr i8, ptr %1480, i64 %1482
  %1484 = extractelement <8 x i64> %111, i64 4
  call void @llm_attention.contiguous_copy.1(ptr %112, i64 %1484, ptr %1483)
  br label %copy.continue184

copy.continue184:                                 ; preds = %copy.active183, %copy.continue182
  %1485 = extractelement <8 x i1> %74, i64 5
  br i1 %1485, label %copy.active185, label %copy.continue186

copy.active185:                                   ; preds = %copy.continue184
  %1486 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1487 = extractelement <8 x ptr> %1486, i64 5
  %1488 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1489 = extractelement <8 x i64> %1488, i64 5
  %1490 = getelementptr i8, ptr %1487, i64 %1489
  %1491 = extractelement <8 x i64> %111, i64 5
  call void @llm_attention.contiguous_copy.1(ptr %112, i64 %1491, ptr %1490)
  br label %copy.continue186

copy.continue186:                                 ; preds = %copy.active185, %copy.continue184
  %1492 = extractelement <8 x i1> %74, i64 6
  br i1 %1492, label %copy.active187, label %copy.continue188

copy.active187:                                   ; preds = %copy.continue186
  %1493 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1494 = extractelement <8 x ptr> %1493, i64 6
  %1495 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1496 = extractelement <8 x i64> %1495, i64 6
  %1497 = getelementptr i8, ptr %1494, i64 %1496
  %1498 = extractelement <8 x i64> %111, i64 6
  call void @llm_attention.contiguous_copy.1(ptr %112, i64 %1498, ptr %1497)
  br label %copy.continue188

copy.continue188:                                 ; preds = %copy.active187, %copy.continue186
  %1499 = extractelement <8 x i1> %74, i64 7
  br i1 %1499, label %copy.active189, label %copy.continue190

copy.active189:                                   ; preds = %copy.continue188
  %1500 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1501 = extractelement <8 x ptr> %1500, i64 7
  %1502 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1503 = extractelement <8 x i64> %1502, i64 7
  %1504 = getelementptr i8, ptr %1501, i64 %1503
  %1505 = extractelement <8 x i64> %111, i64 7
  call void @llm_attention.contiguous_copy.1(ptr %112, i64 %1505, ptr %1504)
  br label %copy.continue190

copy.continue190:                                 ; preds = %copy.active189, %copy.continue188
  %1506 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %1507 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1508 = extractvalue { <8 x ptr>, <8 x i64> } %1506, 0
  %1509 = select <8 x i1> %74, <8 x ptr> %1507, <8 x ptr> %1508
  %1510 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %1511 = extractvalue { <8 x ptr>, <8 x i64> } %1506, 1
  %1512 = select <8 x i1> %74, <8 x i64> %1510, <8 x i64> %1511
  %1513 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1509, 0
  %1514 = insertvalue { <8 x ptr>, <8 x i64> } %1513, <8 x i64> %1512, 1
  store { <8 x ptr>, <8 x i64> } %1514, ptr %tile_snapshot.spill103, align 64
  %1515 = extractvalue { ptr, i64 } %44, 0
  %1516 = extractelement <8 x i1> %74, i64 0
  br i1 %1516, label %copy.active191, label %copy.continue192

copy.active191:                                   ; preds = %copy.continue190
  %1517 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1518 = extractelement <8 x ptr> %1517, i64 0
  %1519 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %1520 = extractelement <8 x i64> %1519, i64 0
  %1521 = getelementptr i8, ptr %1518, i64 %1520
  %1522 = extractelement <8 x i64> %111, i64 0
  call void @llm_attention.contiguous_copy.2(ptr %1515, i64 %1522, ptr %1521)
  br label %copy.continue192

copy.continue192:                                 ; preds = %copy.active191, %copy.continue190
  %1523 = extractelement <8 x i1> %74, i64 1
  br i1 %1523, label %copy.active193, label %copy.continue194

copy.active193:                                   ; preds = %copy.continue192
  %1524 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1525 = extractelement <8 x ptr> %1524, i64 1
  %1526 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %1527 = extractelement <8 x i64> %1526, i64 1
  %1528 = getelementptr i8, ptr %1525, i64 %1527
  %1529 = extractelement <8 x i64> %111, i64 1
  call void @llm_attention.contiguous_copy.2(ptr %1515, i64 %1529, ptr %1528)
  br label %copy.continue194

copy.continue194:                                 ; preds = %copy.active193, %copy.continue192
  %1530 = extractelement <8 x i1> %74, i64 2
  br i1 %1530, label %copy.active195, label %copy.continue196

copy.active195:                                   ; preds = %copy.continue194
  %1531 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1532 = extractelement <8 x ptr> %1531, i64 2
  %1533 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %1534 = extractelement <8 x i64> %1533, i64 2
  %1535 = getelementptr i8, ptr %1532, i64 %1534
  %1536 = extractelement <8 x i64> %111, i64 2
  call void @llm_attention.contiguous_copy.2(ptr %1515, i64 %1536, ptr %1535)
  br label %copy.continue196

copy.continue196:                                 ; preds = %copy.active195, %copy.continue194
  %1537 = extractelement <8 x i1> %74, i64 3
  br i1 %1537, label %copy.active197, label %copy.continue198

copy.active197:                                   ; preds = %copy.continue196
  %1538 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1539 = extractelement <8 x ptr> %1538, i64 3
  %1540 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %1541 = extractelement <8 x i64> %1540, i64 3
  %1542 = getelementptr i8, ptr %1539, i64 %1541
  %1543 = extractelement <8 x i64> %111, i64 3
  call void @llm_attention.contiguous_copy.2(ptr %1515, i64 %1543, ptr %1542)
  br label %copy.continue198

copy.continue198:                                 ; preds = %copy.active197, %copy.continue196
  %1544 = extractelement <8 x i1> %74, i64 4
  br i1 %1544, label %copy.active199, label %copy.continue200

copy.active199:                                   ; preds = %copy.continue198
  %1545 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1546 = extractelement <8 x ptr> %1545, i64 4
  %1547 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %1548 = extractelement <8 x i64> %1547, i64 4
  %1549 = getelementptr i8, ptr %1546, i64 %1548
  %1550 = extractelement <8 x i64> %111, i64 4
  call void @llm_attention.contiguous_copy.2(ptr %1515, i64 %1550, ptr %1549)
  br label %copy.continue200

copy.continue200:                                 ; preds = %copy.active199, %copy.continue198
  %1551 = extractelement <8 x i1> %74, i64 5
  br i1 %1551, label %copy.active201, label %copy.continue202

copy.active201:                                   ; preds = %copy.continue200
  %1552 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1553 = extractelement <8 x ptr> %1552, i64 5
  %1554 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %1555 = extractelement <8 x i64> %1554, i64 5
  %1556 = getelementptr i8, ptr %1553, i64 %1555
  %1557 = extractelement <8 x i64> %111, i64 5
  call void @llm_attention.contiguous_copy.2(ptr %1515, i64 %1557, ptr %1556)
  br label %copy.continue202

copy.continue202:                                 ; preds = %copy.active201, %copy.continue200
  %1558 = extractelement <8 x i1> %74, i64 6
  br i1 %1558, label %copy.active203, label %copy.continue204

copy.active203:                                   ; preds = %copy.continue202
  %1559 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1560 = extractelement <8 x ptr> %1559, i64 6
  %1561 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %1562 = extractelement <8 x i64> %1561, i64 6
  %1563 = getelementptr i8, ptr %1560, i64 %1562
  %1564 = extractelement <8 x i64> %111, i64 6
  call void @llm_attention.contiguous_copy.2(ptr %1515, i64 %1564, ptr %1563)
  br label %copy.continue204

copy.continue204:                                 ; preds = %copy.active203, %copy.continue202
  %1565 = extractelement <8 x i1> %74, i64 7
  br i1 %1565, label %copy.active205, label %copy.continue206

copy.active205:                                   ; preds = %copy.continue204
  %1566 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1567 = extractelement <8 x ptr> %1566, i64 7
  %1568 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %1569 = extractelement <8 x i64> %1568, i64 7
  %1570 = getelementptr i8, ptr %1567, i64 %1569
  %1571 = extractelement <8 x i64> %111, i64 7
  call void @llm_attention.contiguous_copy.2(ptr %1515, i64 %1571, ptr %1570)
  br label %copy.continue206

copy.continue206:                                 ; preds = %copy.active205, %copy.continue204
  %1572 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1573 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %1574 = add <8 x i64> %1573, zeroinitializer
  %1575 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1572, 0
  %1576 = insertvalue { <8 x ptr>, <8 x i64> } %1575, <8 x i64> %1574, 1
  %1577 = extractvalue { <8 x ptr>, <8 x i64> } %1576, 0
  %1578 = extractvalue { <8 x ptr>, <8 x i64> } %1576, 1
  %1579 = getelementptr i8, <8 x ptr> %1577, <8 x i64> %1578
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1579, <8 x i1> %74)
  %1580 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1581 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %1582 = add <8 x i64> %1581, splat (i64 4)
  %1583 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1580, 0
  %1584 = insertvalue { <8 x ptr>, <8 x i64> } %1583, <8 x i64> %1582, 1
  %1585 = extractvalue { <8 x ptr>, <8 x i64> } %1584, 0
  %1586 = extractvalue { <8 x ptr>, <8 x i64> } %1584, 1
  %1587 = getelementptr i8, <8 x ptr> %1585, <8 x i64> %1586
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1587, <8 x i1> %74)
  %1588 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1589 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %1590 = add <8 x i64> %1589, splat (i64 8)
  %1591 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1588, 0
  %1592 = insertvalue { <8 x ptr>, <8 x i64> } %1591, <8 x i64> %1590, 1
  %1593 = extractvalue { <8 x ptr>, <8 x i64> } %1592, 0
  %1594 = extractvalue { <8 x ptr>, <8 x i64> } %1592, 1
  %1595 = getelementptr i8, <8 x ptr> %1593, <8 x i64> %1594
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1595, <8 x i1> %74)
  %1596 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1597 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %1598 = add <8 x i64> %1597, splat (i64 12)
  %1599 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1596, 0
  %1600 = insertvalue { <8 x ptr>, <8 x i64> } %1599, <8 x i64> %1598, 1
  %1601 = extractvalue { <8 x ptr>, <8 x i64> } %1600, 0
  %1602 = extractvalue { <8 x ptr>, <8 x i64> } %1600, 1
  %1603 = getelementptr i8, <8 x ptr> %1601, <8 x i64> %1602
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1603, <8 x i1> %74)
  %1604 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1605 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %1606 = add <8 x i64> %1605, splat (i64 16)
  %1607 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1604, 0
  %1608 = insertvalue { <8 x ptr>, <8 x i64> } %1607, <8 x i64> %1606, 1
  %1609 = extractvalue { <8 x ptr>, <8 x i64> } %1608, 0
  %1610 = extractvalue { <8 x ptr>, <8 x i64> } %1608, 1
  %1611 = getelementptr i8, <8 x ptr> %1609, <8 x i64> %1610
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1611, <8 x i1> %74)
  %1612 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1613 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %1614 = add <8 x i64> %1613, splat (i64 20)
  %1615 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1612, 0
  %1616 = insertvalue { <8 x ptr>, <8 x i64> } %1615, <8 x i64> %1614, 1
  %1617 = extractvalue { <8 x ptr>, <8 x i64> } %1616, 0
  %1618 = extractvalue { <8 x ptr>, <8 x i64> } %1616, 1
  %1619 = getelementptr i8, <8 x ptr> %1617, <8 x i64> %1618
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1619, <8 x i1> %74)
  %1620 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1621 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %1622 = add <8 x i64> %1621, splat (i64 24)
  %1623 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1620, 0
  %1624 = insertvalue { <8 x ptr>, <8 x i64> } %1623, <8 x i64> %1622, 1
  %1625 = extractvalue { <8 x ptr>, <8 x i64> } %1624, 0
  %1626 = extractvalue { <8 x ptr>, <8 x i64> } %1624, 1
  %1627 = getelementptr i8, <8 x ptr> %1625, <8 x i64> %1626
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1627, <8 x i1> %74)
  %1628 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1629 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %1630 = add <8 x i64> %1629, splat (i64 28)
  %1631 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1628, 0
  %1632 = insertvalue { <8 x ptr>, <8 x i64> } %1631, <8 x i64> %1630, 1
  %1633 = extractvalue { <8 x ptr>, <8 x i64> } %1632, 0
  %1634 = extractvalue { <8 x ptr>, <8 x i64> } %1632, 1
  %1635 = getelementptr i8, <8 x ptr> %1633, <8 x i64> %1634
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1635, <8 x i1> %74)
  %1636 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1637 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %1638 = add <8 x i64> %1637, splat (i64 32)
  %1639 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1636, 0
  %1640 = insertvalue { <8 x ptr>, <8 x i64> } %1639, <8 x i64> %1638, 1
  %1641 = extractvalue { <8 x ptr>, <8 x i64> } %1640, 0
  %1642 = extractvalue { <8 x ptr>, <8 x i64> } %1640, 1
  %1643 = getelementptr i8, <8 x ptr> %1641, <8 x i64> %1642
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1643, <8 x i1> %74)
  %1644 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1645 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %1646 = add <8 x i64> %1645, splat (i64 36)
  %1647 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1644, 0
  %1648 = insertvalue { <8 x ptr>, <8 x i64> } %1647, <8 x i64> %1646, 1
  %1649 = extractvalue { <8 x ptr>, <8 x i64> } %1648, 0
  %1650 = extractvalue { <8 x ptr>, <8 x i64> } %1648, 1
  %1651 = getelementptr i8, <8 x ptr> %1649, <8 x i64> %1650
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1651, <8 x i1> %74)
  %1652 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1653 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %1654 = add <8 x i64> %1653, splat (i64 40)
  %1655 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1652, 0
  %1656 = insertvalue { <8 x ptr>, <8 x i64> } %1655, <8 x i64> %1654, 1
  %1657 = extractvalue { <8 x ptr>, <8 x i64> } %1656, 0
  %1658 = extractvalue { <8 x ptr>, <8 x i64> } %1656, 1
  %1659 = getelementptr i8, <8 x ptr> %1657, <8 x i64> %1658
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1659, <8 x i1> %74)
  %1660 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1661 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %1662 = add <8 x i64> %1661, splat (i64 44)
  %1663 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1660, 0
  %1664 = insertvalue { <8 x ptr>, <8 x i64> } %1663, <8 x i64> %1662, 1
  %1665 = extractvalue { <8 x ptr>, <8 x i64> } %1664, 0
  %1666 = extractvalue { <8 x ptr>, <8 x i64> } %1664, 1
  %1667 = getelementptr i8, <8 x ptr> %1665, <8 x i64> %1666
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1667, <8 x i1> %74)
  %1668 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1669 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %1670 = add <8 x i64> %1669, splat (i64 48)
  %1671 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1668, 0
  %1672 = insertvalue { <8 x ptr>, <8 x i64> } %1671, <8 x i64> %1670, 1
  %1673 = extractvalue { <8 x ptr>, <8 x i64> } %1672, 0
  %1674 = extractvalue { <8 x ptr>, <8 x i64> } %1672, 1
  %1675 = getelementptr i8, <8 x ptr> %1673, <8 x i64> %1674
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1675, <8 x i1> %74)
  %1676 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1677 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %1678 = add <8 x i64> %1677, splat (i64 52)
  %1679 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1676, 0
  %1680 = insertvalue { <8 x ptr>, <8 x i64> } %1679, <8 x i64> %1678, 1
  %1681 = extractvalue { <8 x ptr>, <8 x i64> } %1680, 0
  %1682 = extractvalue { <8 x ptr>, <8 x i64> } %1680, 1
  %1683 = getelementptr i8, <8 x ptr> %1681, <8 x i64> %1682
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1683, <8 x i1> %74)
  %1684 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1685 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %1686 = add <8 x i64> %1685, splat (i64 56)
  %1687 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1684, 0
  %1688 = insertvalue { <8 x ptr>, <8 x i64> } %1687, <8 x i64> %1686, 1
  %1689 = extractvalue { <8 x ptr>, <8 x i64> } %1688, 0
  %1690 = extractvalue { <8 x ptr>, <8 x i64> } %1688, 1
  %1691 = getelementptr i8, <8 x ptr> %1689, <8 x i64> %1690
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1691, <8 x i1> %74)
  %1692 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1693 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %1694 = add <8 x i64> %1693, splat (i64 60)
  %1695 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1692, 0
  %1696 = insertvalue { <8 x ptr>, <8 x i64> } %1695, <8 x i64> %1694, 1
  %1697 = extractvalue { <8 x ptr>, <8 x i64> } %1696, 0
  %1698 = extractvalue { <8 x ptr>, <8 x i64> } %1696, 1
  %1699 = getelementptr i8, <8 x ptr> %1697, <8 x i64> %1698
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %1699, <8 x i1> %74)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1700 = extractelement <8 x i1> %74, i64 0
  br i1 %1700, label %mma.active, label %mma.continue

mma.active:                                       ; preds = %copy.continue206
  %1701 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %1702 = extractelement <8 x ptr> %1701, i64 0
  %1703 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %1704 = extractelement <8 x i64> %1703, i64 0
  %1705 = getelementptr i8, ptr %1702, i64 %1704
  %1706 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1707 = extractelement <8 x ptr> %1706, i64 0
  %1708 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1709 = extractelement <8 x i64> %1708, i64 0
  %1710 = getelementptr i8, ptr %1707, i64 %1709
  %1711 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1712 = extractelement <8 x ptr> %1711, i64 0
  %1713 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %1714 = extractelement <8 x i64> %1713, i64 0
  %1715 = getelementptr i8, ptr %1712, i64 %1714
  %1716 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1717 = extractelement <8 x ptr> %1716, i64 0
  %1718 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %1719 = extractelement <8 x i64> %1718, i64 0
  %1720 = getelementptr i8, ptr %1717, i64 %1719
  call void @llm_attention.strided_mma(ptr %1705, ptr %1710, ptr %1715, ptr %1720)
  br label %mma.continue

mma.continue:                                     ; preds = %mma.active, %copy.continue206
  %1721 = extractelement <8 x i1> %74, i64 1
  br i1 %1721, label %mma.active207, label %mma.continue208

mma.active207:                                    ; preds = %mma.continue
  %1722 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %1723 = extractelement <8 x ptr> %1722, i64 1
  %1724 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %1725 = extractelement <8 x i64> %1724, i64 1
  %1726 = getelementptr i8, ptr %1723, i64 %1725
  %1727 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1728 = extractelement <8 x ptr> %1727, i64 1
  %1729 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1730 = extractelement <8 x i64> %1729, i64 1
  %1731 = getelementptr i8, ptr %1728, i64 %1730
  %1732 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1733 = extractelement <8 x ptr> %1732, i64 1
  %1734 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %1735 = extractelement <8 x i64> %1734, i64 1
  %1736 = getelementptr i8, ptr %1733, i64 %1735
  %1737 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1738 = extractelement <8 x ptr> %1737, i64 1
  %1739 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %1740 = extractelement <8 x i64> %1739, i64 1
  %1741 = getelementptr i8, ptr %1738, i64 %1740
  call void @llm_attention.strided_mma(ptr %1726, ptr %1731, ptr %1736, ptr %1741)
  br label %mma.continue208

mma.continue208:                                  ; preds = %mma.active207, %mma.continue
  %1742 = extractelement <8 x i1> %74, i64 2
  br i1 %1742, label %mma.active209, label %mma.continue210

mma.active209:                                    ; preds = %mma.continue208
  %1743 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %1744 = extractelement <8 x ptr> %1743, i64 2
  %1745 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %1746 = extractelement <8 x i64> %1745, i64 2
  %1747 = getelementptr i8, ptr %1744, i64 %1746
  %1748 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1749 = extractelement <8 x ptr> %1748, i64 2
  %1750 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1751 = extractelement <8 x i64> %1750, i64 2
  %1752 = getelementptr i8, ptr %1749, i64 %1751
  %1753 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1754 = extractelement <8 x ptr> %1753, i64 2
  %1755 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %1756 = extractelement <8 x i64> %1755, i64 2
  %1757 = getelementptr i8, ptr %1754, i64 %1756
  %1758 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1759 = extractelement <8 x ptr> %1758, i64 2
  %1760 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %1761 = extractelement <8 x i64> %1760, i64 2
  %1762 = getelementptr i8, ptr %1759, i64 %1761
  call void @llm_attention.strided_mma(ptr %1747, ptr %1752, ptr %1757, ptr %1762)
  br label %mma.continue210

mma.continue210:                                  ; preds = %mma.active209, %mma.continue208
  %1763 = extractelement <8 x i1> %74, i64 3
  br i1 %1763, label %mma.active211, label %mma.continue212

mma.active211:                                    ; preds = %mma.continue210
  %1764 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %1765 = extractelement <8 x ptr> %1764, i64 3
  %1766 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %1767 = extractelement <8 x i64> %1766, i64 3
  %1768 = getelementptr i8, ptr %1765, i64 %1767
  %1769 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1770 = extractelement <8 x ptr> %1769, i64 3
  %1771 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1772 = extractelement <8 x i64> %1771, i64 3
  %1773 = getelementptr i8, ptr %1770, i64 %1772
  %1774 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1775 = extractelement <8 x ptr> %1774, i64 3
  %1776 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %1777 = extractelement <8 x i64> %1776, i64 3
  %1778 = getelementptr i8, ptr %1775, i64 %1777
  %1779 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1780 = extractelement <8 x ptr> %1779, i64 3
  %1781 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %1782 = extractelement <8 x i64> %1781, i64 3
  %1783 = getelementptr i8, ptr %1780, i64 %1782
  call void @llm_attention.strided_mma(ptr %1768, ptr %1773, ptr %1778, ptr %1783)
  br label %mma.continue212

mma.continue212:                                  ; preds = %mma.active211, %mma.continue210
  %1784 = extractelement <8 x i1> %74, i64 4
  br i1 %1784, label %mma.active213, label %mma.continue214

mma.active213:                                    ; preds = %mma.continue212
  %1785 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %1786 = extractelement <8 x ptr> %1785, i64 4
  %1787 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %1788 = extractelement <8 x i64> %1787, i64 4
  %1789 = getelementptr i8, ptr %1786, i64 %1788
  %1790 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1791 = extractelement <8 x ptr> %1790, i64 4
  %1792 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1793 = extractelement <8 x i64> %1792, i64 4
  %1794 = getelementptr i8, ptr %1791, i64 %1793
  %1795 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1796 = extractelement <8 x ptr> %1795, i64 4
  %1797 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %1798 = extractelement <8 x i64> %1797, i64 4
  %1799 = getelementptr i8, ptr %1796, i64 %1798
  %1800 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1801 = extractelement <8 x ptr> %1800, i64 4
  %1802 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %1803 = extractelement <8 x i64> %1802, i64 4
  %1804 = getelementptr i8, ptr %1801, i64 %1803
  call void @llm_attention.strided_mma(ptr %1789, ptr %1794, ptr %1799, ptr %1804)
  br label %mma.continue214

mma.continue214:                                  ; preds = %mma.active213, %mma.continue212
  %1805 = extractelement <8 x i1> %74, i64 5
  br i1 %1805, label %mma.active215, label %mma.continue216

mma.active215:                                    ; preds = %mma.continue214
  %1806 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %1807 = extractelement <8 x ptr> %1806, i64 5
  %1808 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %1809 = extractelement <8 x i64> %1808, i64 5
  %1810 = getelementptr i8, ptr %1807, i64 %1809
  %1811 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1812 = extractelement <8 x ptr> %1811, i64 5
  %1813 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1814 = extractelement <8 x i64> %1813, i64 5
  %1815 = getelementptr i8, ptr %1812, i64 %1814
  %1816 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1817 = extractelement <8 x ptr> %1816, i64 5
  %1818 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %1819 = extractelement <8 x i64> %1818, i64 5
  %1820 = getelementptr i8, ptr %1817, i64 %1819
  %1821 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1822 = extractelement <8 x ptr> %1821, i64 5
  %1823 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %1824 = extractelement <8 x i64> %1823, i64 5
  %1825 = getelementptr i8, ptr %1822, i64 %1824
  call void @llm_attention.strided_mma(ptr %1810, ptr %1815, ptr %1820, ptr %1825)
  br label %mma.continue216

mma.continue216:                                  ; preds = %mma.active215, %mma.continue214
  %1826 = extractelement <8 x i1> %74, i64 6
  br i1 %1826, label %mma.active217, label %mma.continue218

mma.active217:                                    ; preds = %mma.continue216
  %1827 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %1828 = extractelement <8 x ptr> %1827, i64 6
  %1829 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %1830 = extractelement <8 x i64> %1829, i64 6
  %1831 = getelementptr i8, ptr %1828, i64 %1830
  %1832 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1833 = extractelement <8 x ptr> %1832, i64 6
  %1834 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1835 = extractelement <8 x i64> %1834, i64 6
  %1836 = getelementptr i8, ptr %1833, i64 %1835
  %1837 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1838 = extractelement <8 x ptr> %1837, i64 6
  %1839 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %1840 = extractelement <8 x i64> %1839, i64 6
  %1841 = getelementptr i8, ptr %1838, i64 %1840
  %1842 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1843 = extractelement <8 x ptr> %1842, i64 6
  %1844 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %1845 = extractelement <8 x i64> %1844, i64 6
  %1846 = getelementptr i8, ptr %1843, i64 %1845
  call void @llm_attention.strided_mma(ptr %1831, ptr %1836, ptr %1841, ptr %1846)
  br label %mma.continue218

mma.continue218:                                  ; preds = %mma.active217, %mma.continue216
  %1847 = extractelement <8 x i1> %74, i64 7
  br i1 %1847, label %mma.active219, label %mma.continue220

mma.active219:                                    ; preds = %mma.continue218
  %1848 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %1849 = extractelement <8 x ptr> %1848, i64 7
  %1850 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %1851 = extractelement <8 x i64> %1850, i64 7
  %1852 = getelementptr i8, ptr %1849, i64 %1851
  %1853 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1854 = extractelement <8 x ptr> %1853, i64 7
  %1855 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1856 = extractelement <8 x i64> %1855, i64 7
  %1857 = getelementptr i8, ptr %1854, i64 %1856
  %1858 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1859 = extractelement <8 x ptr> %1858, i64 7
  %1860 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %1861 = extractelement <8 x i64> %1860, i64 7
  %1862 = getelementptr i8, ptr %1859, i64 %1861
  %1863 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1864 = extractelement <8 x ptr> %1863, i64 7
  %1865 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %1866 = extractelement <8 x i64> %1865, i64 7
  %1867 = getelementptr i8, ptr %1864, i64 %1866
  call void @llm_attention.strided_mma(ptr %1852, ptr %1857, ptr %1862, ptr %1867)
  br label %mma.continue220

mma.continue220:                                  ; preds = %mma.active219, %mma.continue218
  %1868 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1869 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %1870 = add <8 x i64> %1869, zeroinitializer
  %1871 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1868, 0
  %1872 = insertvalue { <8 x ptr>, <8 x i64> } %1871, <8 x i64> %1870, 1
  %1873 = extractvalue { <8 x ptr>, <8 x i64> } %1872, 0
  %1874 = extractvalue { <8 x ptr>, <8 x i64> } %1872, 1
  %1875 = getelementptr i8, <8 x ptr> %1873, <8 x i64> %1874
  %1876 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1875, <8 x i1> %74, <8 x float> zeroinitializer)
  %1877 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1878 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %1879 = add <8 x i64> %1878, splat (i64 4)
  %1880 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1877, 0
  %1881 = insertvalue { <8 x ptr>, <8 x i64> } %1880, <8 x i64> %1879, 1
  %1882 = extractvalue { <8 x ptr>, <8 x i64> } %1881, 0
  %1883 = extractvalue { <8 x ptr>, <8 x i64> } %1881, 1
  %1884 = getelementptr i8, <8 x ptr> %1882, <8 x i64> %1883
  %1885 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1884, <8 x i1> %74, <8 x float> zeroinitializer)
  %1886 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1887 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %1888 = add <8 x i64> %1887, splat (i64 8)
  %1889 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1886, 0
  %1890 = insertvalue { <8 x ptr>, <8 x i64> } %1889, <8 x i64> %1888, 1
  %1891 = extractvalue { <8 x ptr>, <8 x i64> } %1890, 0
  %1892 = extractvalue { <8 x ptr>, <8 x i64> } %1890, 1
  %1893 = getelementptr i8, <8 x ptr> %1891, <8 x i64> %1892
  %1894 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1893, <8 x i1> %74, <8 x float> zeroinitializer)
  %1895 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1896 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %1897 = add <8 x i64> %1896, splat (i64 12)
  %1898 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1895, 0
  %1899 = insertvalue { <8 x ptr>, <8 x i64> } %1898, <8 x i64> %1897, 1
  %1900 = extractvalue { <8 x ptr>, <8 x i64> } %1899, 0
  %1901 = extractvalue { <8 x ptr>, <8 x i64> } %1899, 1
  %1902 = getelementptr i8, <8 x ptr> %1900, <8 x i64> %1901
  %1903 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1902, <8 x i1> %74, <8 x float> zeroinitializer)
  %1904 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1905 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %1906 = add <8 x i64> %1905, splat (i64 16)
  %1907 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1904, 0
  %1908 = insertvalue { <8 x ptr>, <8 x i64> } %1907, <8 x i64> %1906, 1
  %1909 = extractvalue { <8 x ptr>, <8 x i64> } %1908, 0
  %1910 = extractvalue { <8 x ptr>, <8 x i64> } %1908, 1
  %1911 = getelementptr i8, <8 x ptr> %1909, <8 x i64> %1910
  %1912 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1911, <8 x i1> %74, <8 x float> zeroinitializer)
  %1913 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1914 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %1915 = add <8 x i64> %1914, splat (i64 20)
  %1916 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1913, 0
  %1917 = insertvalue { <8 x ptr>, <8 x i64> } %1916, <8 x i64> %1915, 1
  %1918 = extractvalue { <8 x ptr>, <8 x i64> } %1917, 0
  %1919 = extractvalue { <8 x ptr>, <8 x i64> } %1917, 1
  %1920 = getelementptr i8, <8 x ptr> %1918, <8 x i64> %1919
  %1921 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1920, <8 x i1> %74, <8 x float> zeroinitializer)
  %1922 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1923 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %1924 = add <8 x i64> %1923, splat (i64 24)
  %1925 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1922, 0
  %1926 = insertvalue { <8 x ptr>, <8 x i64> } %1925, <8 x i64> %1924, 1
  %1927 = extractvalue { <8 x ptr>, <8 x i64> } %1926, 0
  %1928 = extractvalue { <8 x ptr>, <8 x i64> } %1926, 1
  %1929 = getelementptr i8, <8 x ptr> %1927, <8 x i64> %1928
  %1930 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1929, <8 x i1> %74, <8 x float> zeroinitializer)
  %1931 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1932 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %1933 = add <8 x i64> %1932, splat (i64 28)
  %1934 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1931, 0
  %1935 = insertvalue { <8 x ptr>, <8 x i64> } %1934, <8 x i64> %1933, 1
  %1936 = extractvalue { <8 x ptr>, <8 x i64> } %1935, 0
  %1937 = extractvalue { <8 x ptr>, <8 x i64> } %1935, 1
  %1938 = getelementptr i8, <8 x ptr> %1936, <8 x i64> %1937
  %1939 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1938, <8 x i1> %74, <8 x float> zeroinitializer)
  %1940 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1941 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %1942 = add <8 x i64> %1941, splat (i64 32)
  %1943 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1940, 0
  %1944 = insertvalue { <8 x ptr>, <8 x i64> } %1943, <8 x i64> %1942, 1
  %1945 = extractvalue { <8 x ptr>, <8 x i64> } %1944, 0
  %1946 = extractvalue { <8 x ptr>, <8 x i64> } %1944, 1
  %1947 = getelementptr i8, <8 x ptr> %1945, <8 x i64> %1946
  %1948 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1947, <8 x i1> %74, <8 x float> zeroinitializer)
  %1949 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1950 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %1951 = add <8 x i64> %1950, splat (i64 36)
  %1952 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1949, 0
  %1953 = insertvalue { <8 x ptr>, <8 x i64> } %1952, <8 x i64> %1951, 1
  %1954 = extractvalue { <8 x ptr>, <8 x i64> } %1953, 0
  %1955 = extractvalue { <8 x ptr>, <8 x i64> } %1953, 1
  %1956 = getelementptr i8, <8 x ptr> %1954, <8 x i64> %1955
  %1957 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1956, <8 x i1> %74, <8 x float> zeroinitializer)
  %1958 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1959 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %1960 = add <8 x i64> %1959, splat (i64 40)
  %1961 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1958, 0
  %1962 = insertvalue { <8 x ptr>, <8 x i64> } %1961, <8 x i64> %1960, 1
  %1963 = extractvalue { <8 x ptr>, <8 x i64> } %1962, 0
  %1964 = extractvalue { <8 x ptr>, <8 x i64> } %1962, 1
  %1965 = getelementptr i8, <8 x ptr> %1963, <8 x i64> %1964
  %1966 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1965, <8 x i1> %74, <8 x float> zeroinitializer)
  %1967 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1968 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %1969 = add <8 x i64> %1968, splat (i64 44)
  %1970 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1967, 0
  %1971 = insertvalue { <8 x ptr>, <8 x i64> } %1970, <8 x i64> %1969, 1
  %1972 = extractvalue { <8 x ptr>, <8 x i64> } %1971, 0
  %1973 = extractvalue { <8 x ptr>, <8 x i64> } %1971, 1
  %1974 = getelementptr i8, <8 x ptr> %1972, <8 x i64> %1973
  %1975 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1974, <8 x i1> %74, <8 x float> zeroinitializer)
  %1976 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1977 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %1978 = add <8 x i64> %1977, splat (i64 48)
  %1979 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1976, 0
  %1980 = insertvalue { <8 x ptr>, <8 x i64> } %1979, <8 x i64> %1978, 1
  %1981 = extractvalue { <8 x ptr>, <8 x i64> } %1980, 0
  %1982 = extractvalue { <8 x ptr>, <8 x i64> } %1980, 1
  %1983 = getelementptr i8, <8 x ptr> %1981, <8 x i64> %1982
  %1984 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1983, <8 x i1> %74, <8 x float> zeroinitializer)
  %1985 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1986 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %1987 = add <8 x i64> %1986, splat (i64 52)
  %1988 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1985, 0
  %1989 = insertvalue { <8 x ptr>, <8 x i64> } %1988, <8 x i64> %1987, 1
  %1990 = extractvalue { <8 x ptr>, <8 x i64> } %1989, 0
  %1991 = extractvalue { <8 x ptr>, <8 x i64> } %1989, 1
  %1992 = getelementptr i8, <8 x ptr> %1990, <8 x i64> %1991
  %1993 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1992, <8 x i1> %74, <8 x float> zeroinitializer)
  %1994 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1995 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %1996 = add <8 x i64> %1995, splat (i64 56)
  %1997 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1994, 0
  %1998 = insertvalue { <8 x ptr>, <8 x i64> } %1997, <8 x i64> %1996, 1
  %1999 = extractvalue { <8 x ptr>, <8 x i64> } %1998, 0
  %2000 = extractvalue { <8 x ptr>, <8 x i64> } %1998, 1
  %2001 = getelementptr i8, <8 x ptr> %1999, <8 x i64> %2000
  %2002 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2001, <8 x i1> %74, <8 x float> zeroinitializer)
  %2003 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2004 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %2005 = add <8 x i64> %2004, splat (i64 60)
  %2006 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2003, 0
  %2007 = insertvalue { <8 x ptr>, <8 x i64> } %2006, <8 x i64> %2005, 1
  %2008 = extractvalue { <8 x ptr>, <8 x i64> } %2007, 0
  %2009 = extractvalue { <8 x ptr>, <8 x i64> } %2007, 1
  %2010 = getelementptr i8, <8 x ptr> %2008, <8 x i64> %2009
  %2011 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2010, <8 x i1> %74, <8 x float> zeroinitializer)
  %2012 = fmul <8 x float> %1876, splat (float 1.250000e-01)
  %2013 = fmul <8 x float> %1885, splat (float 1.250000e-01)
  %2014 = fmul <8 x float> %1894, splat (float 1.250000e-01)
  %2015 = fmul <8 x float> %1903, splat (float 1.250000e-01)
  %2016 = fmul <8 x float> %1912, splat (float 1.250000e-01)
  %2017 = fmul <8 x float> %1921, splat (float 1.250000e-01)
  %2018 = fmul <8 x float> %1930, splat (float 1.250000e-01)
  %2019 = fmul <8 x float> %1939, splat (float 1.250000e-01)
  %2020 = fmul <8 x float> %1948, splat (float 1.250000e-01)
  %2021 = fmul <8 x float> %1957, splat (float 1.250000e-01)
  %2022 = fmul <8 x float> %1966, splat (float 1.250000e-01)
  %2023 = fmul <8 x float> %1975, splat (float 1.250000e-01)
  %2024 = fmul <8 x float> %1984, splat (float 1.250000e-01)
  %2025 = fmul <8 x float> %1993, splat (float 1.250000e-01)
  %2026 = fmul <8 x float> %2002, splat (float 1.250000e-01)
  %2027 = fmul <8 x float> %2011, splat (float 1.250000e-01)
  %2028 = add i64 0, %106
  %2029 = add i64 1, %106
  %2030 = add i64 2, %106
  %2031 = add i64 3, %106
  %2032 = add i64 4, %106
  %2033 = add i64 5, %106
  %2034 = add i64 6, %106
  %2035 = add i64 7, %106
  %2036 = add i64 8, %106
  %2037 = add i64 9, %106
  %2038 = add i64 10, %106
  %2039 = add i64 11, %106
  %2040 = add i64 12, %106
  %2041 = add i64 13, %106
  %2042 = add i64 14, %106
  %2043 = add i64 15, %106
  %2044 = icmp slt i64 %2028, 2048
  %2045 = icmp slt i64 %2029, 2048
  %2046 = icmp slt i64 %2030, 2048
  %2047 = icmp slt i64 %2031, 2048
  %2048 = icmp slt i64 %2032, 2048
  %2049 = icmp slt i64 %2033, 2048
  %2050 = icmp slt i64 %2034, 2048
  %2051 = icmp slt i64 %2035, 2048
  %2052 = icmp slt i64 %2036, 2048
  %2053 = icmp slt i64 %2037, 2048
  %2054 = icmp slt i64 %2038, 2048
  %2055 = icmp slt i64 %2039, 2048
  %2056 = icmp slt i64 %2040, 2048
  %2057 = icmp slt i64 %2041, 2048
  %2058 = icmp slt i64 %2042, 2048
  %2059 = icmp slt i64 %2043, 2048
  %.spill.load221 = load i64, ptr %.spill35, align 4
  %2060 = add i64 %.spill.load221, 2048
  %2061 = sub i64 %2060, 1
  %2062 = icmp sle i64 %2028, %2061
  %2063 = icmp sle i64 %2029, %2061
  %2064 = icmp sle i64 %2030, %2061
  %2065 = icmp sle i64 %2031, %2061
  %2066 = icmp sle i64 %2032, %2061
  %2067 = icmp sle i64 %2033, %2061
  %2068 = icmp sle i64 %2034, %2061
  %2069 = icmp sle i64 %2035, %2061
  %2070 = icmp sle i64 %2036, %2061
  %2071 = icmp sle i64 %2037, %2061
  %2072 = icmp sle i64 %2038, %2061
  %2073 = icmp sle i64 %2039, %2061
  %2074 = icmp sle i64 %2040, %2061
  %2075 = icmp sle i64 %2041, %2061
  %2076 = icmp sle i64 %2042, %2061
  %2077 = icmp sle i64 %2043, %2061
  %2078 = and i1 %2044, %2062
  store i1 %2078, ptr %.spill104, align 1
  %2079 = and i1 %2045, %2063
  store i1 %2079, ptr %.spill105, align 1
  %2080 = and i1 %2046, %2064
  store i1 %2080, ptr %.spill106, align 1
  %2081 = and i1 %2047, %2065
  store i1 %2081, ptr %.spill107, align 1
  %2082 = and i1 %2048, %2066
  store i1 %2082, ptr %.spill108, align 1
  %2083 = and i1 %2049, %2067
  store i1 %2083, ptr %.spill109, align 1
  %2084 = and i1 %2050, %2068
  store i1 %2084, ptr %.spill110, align 1
  %2085 = and i1 %2051, %2069
  store i1 %2085, ptr %.spill111, align 1
  %2086 = and i1 %2052, %2070
  store i1 %2086, ptr %.spill112, align 1
  %2087 = and i1 %2053, %2071
  store i1 %2087, ptr %.spill113, align 1
  %2088 = and i1 %2054, %2072
  store i1 %2088, ptr %.spill114, align 1
  %2089 = and i1 %2055, %2073
  store i1 %2089, ptr %.spill115, align 1
  %2090 = and i1 %2056, %2074
  store i1 %2090, ptr %.spill116, align 1
  %2091 = and i1 %2057, %2075
  store i1 %2091, ptr %.spill117, align 1
  %2092 = and i1 %2058, %2076
  store i1 %2092, ptr %.spill118, align 1
  %2093 = and i1 %2059, %2077
  store i1 %2093, ptr %.spill119, align 1
  %.splatinsert222 = insertelement <8 x i1> poison, i1 %2078, i64 0
  %.splat223 = shufflevector <8 x i1> %.splatinsert222, <8 x i1> poison, <8 x i32> zeroinitializer
  %2094 = select <8 x i1> %.splat223, <8 x float> %2012, <8 x float> splat (float 0xC6293E5940000000)
  %2095 = load <8 x float>, ptr %.spill120, align 32
  %2096 = select <8 x i1> %74, <8 x float> %2094, <8 x float> %2095
  store <8 x float> %2096, ptr %.spill120, align 32
  %.splatinsert224 = insertelement <8 x i1> poison, i1 %2079, i64 0
  %.splat225 = shufflevector <8 x i1> %.splatinsert224, <8 x i1> poison, <8 x i32> zeroinitializer
  %2097 = select <8 x i1> %.splat225, <8 x float> %2013, <8 x float> splat (float 0xC6293E5940000000)
  %2098 = load <8 x float>, ptr %.spill121, align 32
  %2099 = select <8 x i1> %74, <8 x float> %2097, <8 x float> %2098
  store <8 x float> %2099, ptr %.spill121, align 32
  %.splatinsert226 = insertelement <8 x i1> poison, i1 %2080, i64 0
  %.splat227 = shufflevector <8 x i1> %.splatinsert226, <8 x i1> poison, <8 x i32> zeroinitializer
  %2100 = select <8 x i1> %.splat227, <8 x float> %2014, <8 x float> splat (float 0xC6293E5940000000)
  %2101 = load <8 x float>, ptr %.spill122, align 32
  %2102 = select <8 x i1> %74, <8 x float> %2100, <8 x float> %2101
  store <8 x float> %2102, ptr %.spill122, align 32
  %.splatinsert228 = insertelement <8 x i1> poison, i1 %2081, i64 0
  %.splat229 = shufflevector <8 x i1> %.splatinsert228, <8 x i1> poison, <8 x i32> zeroinitializer
  %2103 = select <8 x i1> %.splat229, <8 x float> %2015, <8 x float> splat (float 0xC6293E5940000000)
  %2104 = load <8 x float>, ptr %.spill123, align 32
  %2105 = select <8 x i1> %74, <8 x float> %2103, <8 x float> %2104
  store <8 x float> %2105, ptr %.spill123, align 32
  %.splatinsert230 = insertelement <8 x i1> poison, i1 %2082, i64 0
  %.splat231 = shufflevector <8 x i1> %.splatinsert230, <8 x i1> poison, <8 x i32> zeroinitializer
  %2106 = select <8 x i1> %.splat231, <8 x float> %2016, <8 x float> splat (float 0xC6293E5940000000)
  %2107 = load <8 x float>, ptr %.spill124, align 32
  %2108 = select <8 x i1> %74, <8 x float> %2106, <8 x float> %2107
  store <8 x float> %2108, ptr %.spill124, align 32
  %.splatinsert232 = insertelement <8 x i1> poison, i1 %2083, i64 0
  %.splat233 = shufflevector <8 x i1> %.splatinsert232, <8 x i1> poison, <8 x i32> zeroinitializer
  %2109 = select <8 x i1> %.splat233, <8 x float> %2017, <8 x float> splat (float 0xC6293E5940000000)
  %2110 = load <8 x float>, ptr %.spill125, align 32
  %2111 = select <8 x i1> %74, <8 x float> %2109, <8 x float> %2110
  store <8 x float> %2111, ptr %.spill125, align 32
  %.splatinsert234 = insertelement <8 x i1> poison, i1 %2084, i64 0
  %.splat235 = shufflevector <8 x i1> %.splatinsert234, <8 x i1> poison, <8 x i32> zeroinitializer
  %2112 = select <8 x i1> %.splat235, <8 x float> %2018, <8 x float> splat (float 0xC6293E5940000000)
  %2113 = load <8 x float>, ptr %.spill126, align 32
  %2114 = select <8 x i1> %74, <8 x float> %2112, <8 x float> %2113
  store <8 x float> %2114, ptr %.spill126, align 32
  %.splatinsert236 = insertelement <8 x i1> poison, i1 %2085, i64 0
  %.splat237 = shufflevector <8 x i1> %.splatinsert236, <8 x i1> poison, <8 x i32> zeroinitializer
  %2115 = select <8 x i1> %.splat237, <8 x float> %2019, <8 x float> splat (float 0xC6293E5940000000)
  %2116 = load <8 x float>, ptr %.spill127, align 32
  %2117 = select <8 x i1> %74, <8 x float> %2115, <8 x float> %2116
  store <8 x float> %2117, ptr %.spill127, align 32
  %.splatinsert238 = insertelement <8 x i1> poison, i1 %2086, i64 0
  %.splat239 = shufflevector <8 x i1> %.splatinsert238, <8 x i1> poison, <8 x i32> zeroinitializer
  %2118 = select <8 x i1> %.splat239, <8 x float> %2020, <8 x float> splat (float 0xC6293E5940000000)
  %2119 = load <8 x float>, ptr %.spill128, align 32
  %2120 = select <8 x i1> %74, <8 x float> %2118, <8 x float> %2119
  store <8 x float> %2120, ptr %.spill128, align 32
  %.splatinsert240 = insertelement <8 x i1> poison, i1 %2087, i64 0
  %.splat241 = shufflevector <8 x i1> %.splatinsert240, <8 x i1> poison, <8 x i32> zeroinitializer
  %2121 = select <8 x i1> %.splat241, <8 x float> %2021, <8 x float> splat (float 0xC6293E5940000000)
  %2122 = load <8 x float>, ptr %.spill129, align 32
  %2123 = select <8 x i1> %74, <8 x float> %2121, <8 x float> %2122
  store <8 x float> %2123, ptr %.spill129, align 32
  %.splatinsert242 = insertelement <8 x i1> poison, i1 %2088, i64 0
  %.splat243 = shufflevector <8 x i1> %.splatinsert242, <8 x i1> poison, <8 x i32> zeroinitializer
  %2124 = select <8 x i1> %.splat243, <8 x float> %2022, <8 x float> splat (float 0xC6293E5940000000)
  %2125 = load <8 x float>, ptr %.spill130, align 32
  %2126 = select <8 x i1> %74, <8 x float> %2124, <8 x float> %2125
  store <8 x float> %2126, ptr %.spill130, align 32
  %.splatinsert244 = insertelement <8 x i1> poison, i1 %2089, i64 0
  %.splat245 = shufflevector <8 x i1> %.splatinsert244, <8 x i1> poison, <8 x i32> zeroinitializer
  %2127 = select <8 x i1> %.splat245, <8 x float> %2023, <8 x float> splat (float 0xC6293E5940000000)
  %2128 = load <8 x float>, ptr %.spill131, align 32
  %2129 = select <8 x i1> %74, <8 x float> %2127, <8 x float> %2128
  store <8 x float> %2129, ptr %.spill131, align 32
  %.splatinsert246 = insertelement <8 x i1> poison, i1 %2090, i64 0
  %.splat247 = shufflevector <8 x i1> %.splatinsert246, <8 x i1> poison, <8 x i32> zeroinitializer
  %2130 = select <8 x i1> %.splat247, <8 x float> %2024, <8 x float> splat (float 0xC6293E5940000000)
  %2131 = load <8 x float>, ptr %.spill132, align 32
  %2132 = select <8 x i1> %74, <8 x float> %2130, <8 x float> %2131
  store <8 x float> %2132, ptr %.spill132, align 32
  %.splatinsert248 = insertelement <8 x i1> poison, i1 %2091, i64 0
  %.splat249 = shufflevector <8 x i1> %.splatinsert248, <8 x i1> poison, <8 x i32> zeroinitializer
  %2133 = select <8 x i1> %.splat249, <8 x float> %2025, <8 x float> splat (float 0xC6293E5940000000)
  %2134 = load <8 x float>, ptr %.spill133, align 32
  %2135 = select <8 x i1> %74, <8 x float> %2133, <8 x float> %2134
  store <8 x float> %2135, ptr %.spill133, align 32
  %.splatinsert250 = insertelement <8 x i1> poison, i1 %2092, i64 0
  %.splat251 = shufflevector <8 x i1> %.splatinsert250, <8 x i1> poison, <8 x i32> zeroinitializer
  %2136 = select <8 x i1> %.splat251, <8 x float> %2026, <8 x float> splat (float 0xC6293E5940000000)
  %2137 = load <8 x float>, ptr %.spill134, align 32
  %2138 = select <8 x i1> %74, <8 x float> %2136, <8 x float> %2137
  store <8 x float> %2138, ptr %.spill134, align 32
  %.splatinsert252 = insertelement <8 x i1> poison, i1 %2093, i64 0
  %.splat253 = shufflevector <8 x i1> %.splatinsert252, <8 x i1> poison, <8 x i32> zeroinitializer
  %2139 = select <8 x i1> %.splat253, <8 x float> %2027, <8 x float> splat (float 0xC6293E5940000000)
  %2140 = load <8 x float>, ptr %.spill135, align 32
  %2141 = select <8 x i1> %74, <8 x float> %2139, <8 x float> %2140
  store <8 x float> %2141, ptr %.spill135, align 32
  %2142 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill136, align 64
  %2143 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2144 = extractvalue { <8 x ptr>, <8 x i64> } %2142, 0
  %2145 = select <8 x i1> %74, <8 x ptr> %2143, <8 x ptr> %2144
  %2146 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2147 = extractvalue { <8 x ptr>, <8 x i64> } %2142, 1
  %2148 = select <8 x i1> %74, <8 x i64> %2146, <8 x i64> %2147
  %2149 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2145, 0
  %2150 = insertvalue { <8 x ptr>, <8 x i64> } %2149, <8 x i64> %2148, 1
  store { <8 x ptr>, <8 x i64> } %2150, ptr %tile_snapshot.spill136, align 64
  %2151 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2152 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2153 = add <8 x i64> %2152, zeroinitializer
  %2154 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2151, 0
  %2155 = insertvalue { <8 x ptr>, <8 x i64> } %2154, <8 x i64> %2153, 1
  %2156 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2157 = extractvalue { <8 x ptr>, <8 x i64> } %2155, 1
  %2158 = extractelement <8 x ptr> %2156, i32 0
  %2159 = extractelement <8 x i64> %2157, i32 0
  %2160 = sub i64 %2159, 0
  %2161 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %74)
  %2162 = select i1 %2161, i64 %2160, i64 0
  %private.contiguous.address = getelementptr i8, ptr %2158, i64 %2162
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %2163 = select <8 x i1> %74, <8 x float> %2094, <8 x float> %private.contiguous.preserve
  store <8 x float> %2163, ptr %private.contiguous.address, align 4
  %2164 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2165 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2166 = add <8 x i64> %2165, splat (i64 32)
  %2167 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2164, 0
  %2168 = insertvalue { <8 x ptr>, <8 x i64> } %2167, <8 x i64> %2166, 1
  %2169 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2170 = extractvalue { <8 x ptr>, <8 x i64> } %2168, 1
  %2171 = extractelement <8 x ptr> %2169, i32 0
  %2172 = extractelement <8 x i64> %2170, i32 0
  %2173 = sub i64 %2172, 0
  %2174 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %74)
  %2175 = select i1 %2174, i64 %2173, i64 0
  %private.contiguous.address254 = getelementptr i8, ptr %2171, i64 %2175
  %private.contiguous.preserve255 = load <8 x float>, ptr %private.contiguous.address254, align 4
  %2176 = select <8 x i1> %74, <8 x float> %2097, <8 x float> %private.contiguous.preserve255
  store <8 x float> %2176, ptr %private.contiguous.address254, align 4
  %2177 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2178 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2179 = add <8 x i64> %2178, splat (i64 64)
  %2180 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2177, 0
  %2181 = insertvalue { <8 x ptr>, <8 x i64> } %2180, <8 x i64> %2179, 1
  %2182 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2183 = extractvalue { <8 x ptr>, <8 x i64> } %2181, 1
  %2184 = extractelement <8 x ptr> %2182, i32 0
  %2185 = extractelement <8 x i64> %2183, i32 0
  %2186 = sub i64 %2185, 0
  %2187 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %74)
  %2188 = select i1 %2187, i64 %2186, i64 0
  %private.contiguous.address256 = getelementptr i8, ptr %2184, i64 %2188
  %private.contiguous.preserve257 = load <8 x float>, ptr %private.contiguous.address256, align 4
  %2189 = select <8 x i1> %74, <8 x float> %2100, <8 x float> %private.contiguous.preserve257
  store <8 x float> %2189, ptr %private.contiguous.address256, align 4
  %2190 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2191 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2192 = add <8 x i64> %2191, splat (i64 96)
  %2193 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2190, 0
  %2194 = insertvalue { <8 x ptr>, <8 x i64> } %2193, <8 x i64> %2192, 1
  %2195 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2196 = extractvalue { <8 x ptr>, <8 x i64> } %2194, 1
  %2197 = extractelement <8 x ptr> %2195, i32 0
  %2198 = extractelement <8 x i64> %2196, i32 0
  %2199 = sub i64 %2198, 0
  %2200 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %74)
  %2201 = select i1 %2200, i64 %2199, i64 0
  %private.contiguous.address258 = getelementptr i8, ptr %2197, i64 %2201
  %private.contiguous.preserve259 = load <8 x float>, ptr %private.contiguous.address258, align 4
  %2202 = select <8 x i1> %74, <8 x float> %2103, <8 x float> %private.contiguous.preserve259
  store <8 x float> %2202, ptr %private.contiguous.address258, align 4
  %2203 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2204 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2205 = add <8 x i64> %2204, splat (i64 128)
  %2206 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2203, 0
  %2207 = insertvalue { <8 x ptr>, <8 x i64> } %2206, <8 x i64> %2205, 1
  %2208 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2209 = extractvalue { <8 x ptr>, <8 x i64> } %2207, 1
  %2210 = extractelement <8 x ptr> %2208, i32 0
  %2211 = extractelement <8 x i64> %2209, i32 0
  %2212 = sub i64 %2211, 0
  %2213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %74)
  %2214 = select i1 %2213, i64 %2212, i64 0
  %private.contiguous.address260 = getelementptr i8, ptr %2210, i64 %2214
  %private.contiguous.preserve261 = load <8 x float>, ptr %private.contiguous.address260, align 4
  %2215 = select <8 x i1> %74, <8 x float> %2106, <8 x float> %private.contiguous.preserve261
  store <8 x float> %2215, ptr %private.contiguous.address260, align 4
  %2216 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2217 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2218 = add <8 x i64> %2217, splat (i64 160)
  %2219 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2216, 0
  %2220 = insertvalue { <8 x ptr>, <8 x i64> } %2219, <8 x i64> %2218, 1
  %2221 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2222 = extractvalue { <8 x ptr>, <8 x i64> } %2220, 1
  %2223 = extractelement <8 x ptr> %2221, i32 0
  %2224 = extractelement <8 x i64> %2222, i32 0
  %2225 = sub i64 %2224, 0
  %2226 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %74)
  %2227 = select i1 %2226, i64 %2225, i64 0
  %private.contiguous.address262 = getelementptr i8, ptr %2223, i64 %2227
  %private.contiguous.preserve263 = load <8 x float>, ptr %private.contiguous.address262, align 4
  %2228 = select <8 x i1> %74, <8 x float> %2109, <8 x float> %private.contiguous.preserve263
  store <8 x float> %2228, ptr %private.contiguous.address262, align 4
  %2229 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2230 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2231 = add <8 x i64> %2230, splat (i64 192)
  %2232 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2229, 0
  %2233 = insertvalue { <8 x ptr>, <8 x i64> } %2232, <8 x i64> %2231, 1
  %2234 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2235 = extractvalue { <8 x ptr>, <8 x i64> } %2233, 1
  %2236 = extractelement <8 x ptr> %2234, i32 0
  %2237 = extractelement <8 x i64> %2235, i32 0
  %2238 = sub i64 %2237, 0
  %2239 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %74)
  %2240 = select i1 %2239, i64 %2238, i64 0
  %private.contiguous.address264 = getelementptr i8, ptr %2236, i64 %2240
  %private.contiguous.preserve265 = load <8 x float>, ptr %private.contiguous.address264, align 4
  %2241 = select <8 x i1> %74, <8 x float> %2112, <8 x float> %private.contiguous.preserve265
  store <8 x float> %2241, ptr %private.contiguous.address264, align 4
  %2242 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2243 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2244 = add <8 x i64> %2243, splat (i64 224)
  %2245 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2242, 0
  %2246 = insertvalue { <8 x ptr>, <8 x i64> } %2245, <8 x i64> %2244, 1
  %2247 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2248 = extractvalue { <8 x ptr>, <8 x i64> } %2246, 1
  %2249 = extractelement <8 x ptr> %2247, i32 0
  %2250 = extractelement <8 x i64> %2248, i32 0
  %2251 = sub i64 %2250, 0
  %2252 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %74)
  %2253 = select i1 %2252, i64 %2251, i64 0
  %private.contiguous.address266 = getelementptr i8, ptr %2249, i64 %2253
  %private.contiguous.preserve267 = load <8 x float>, ptr %private.contiguous.address266, align 4
  %2254 = select <8 x i1> %74, <8 x float> %2115, <8 x float> %private.contiguous.preserve267
  store <8 x float> %2254, ptr %private.contiguous.address266, align 4
  %2255 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2256 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2257 = add <8 x i64> %2256, splat (i64 256)
  %2258 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2255, 0
  %2259 = insertvalue { <8 x ptr>, <8 x i64> } %2258, <8 x i64> %2257, 1
  %2260 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2261 = extractvalue { <8 x ptr>, <8 x i64> } %2259, 1
  %2262 = extractelement <8 x ptr> %2260, i32 0
  %2263 = extractelement <8 x i64> %2261, i32 0
  %2264 = sub i64 %2263, 0
  %2265 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %74)
  %2266 = select i1 %2265, i64 %2264, i64 0
  %private.contiguous.address268 = getelementptr i8, ptr %2262, i64 %2266
  %private.contiguous.preserve269 = load <8 x float>, ptr %private.contiguous.address268, align 4
  %2267 = select <8 x i1> %74, <8 x float> %2118, <8 x float> %private.contiguous.preserve269
  store <8 x float> %2267, ptr %private.contiguous.address268, align 4
  %2268 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2269 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2270 = add <8 x i64> %2269, splat (i64 288)
  %2271 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2268, 0
  %2272 = insertvalue { <8 x ptr>, <8 x i64> } %2271, <8 x i64> %2270, 1
  %2273 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2274 = extractvalue { <8 x ptr>, <8 x i64> } %2272, 1
  %2275 = extractelement <8 x ptr> %2273, i32 0
  %2276 = extractelement <8 x i64> %2274, i32 0
  %2277 = sub i64 %2276, 0
  %2278 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %74)
  %2279 = select i1 %2278, i64 %2277, i64 0
  %private.contiguous.address270 = getelementptr i8, ptr %2275, i64 %2279
  %private.contiguous.preserve271 = load <8 x float>, ptr %private.contiguous.address270, align 4
  %2280 = select <8 x i1> %74, <8 x float> %2121, <8 x float> %private.contiguous.preserve271
  store <8 x float> %2280, ptr %private.contiguous.address270, align 4
  %2281 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2282 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2283 = add <8 x i64> %2282, splat (i64 320)
  %2284 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2281, 0
  %2285 = insertvalue { <8 x ptr>, <8 x i64> } %2284, <8 x i64> %2283, 1
  %2286 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2287 = extractvalue { <8 x ptr>, <8 x i64> } %2285, 1
  %2288 = extractelement <8 x ptr> %2286, i32 0
  %2289 = extractelement <8 x i64> %2287, i32 0
  %2290 = sub i64 %2289, 0
  %2291 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %74)
  %2292 = select i1 %2291, i64 %2290, i64 0
  %private.contiguous.address272 = getelementptr i8, ptr %2288, i64 %2292
  %private.contiguous.preserve273 = load <8 x float>, ptr %private.contiguous.address272, align 4
  %2293 = select <8 x i1> %74, <8 x float> %2124, <8 x float> %private.contiguous.preserve273
  store <8 x float> %2293, ptr %private.contiguous.address272, align 4
  %2294 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2295 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2296 = add <8 x i64> %2295, splat (i64 352)
  %2297 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2294, 0
  %2298 = insertvalue { <8 x ptr>, <8 x i64> } %2297, <8 x i64> %2296, 1
  %2299 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2300 = extractvalue { <8 x ptr>, <8 x i64> } %2298, 1
  %2301 = extractelement <8 x ptr> %2299, i32 0
  %2302 = extractelement <8 x i64> %2300, i32 0
  %2303 = sub i64 %2302, 0
  %2304 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %74)
  %2305 = select i1 %2304, i64 %2303, i64 0
  %private.contiguous.address274 = getelementptr i8, ptr %2301, i64 %2305
  %private.contiguous.preserve275 = load <8 x float>, ptr %private.contiguous.address274, align 4
  %2306 = select <8 x i1> %74, <8 x float> %2127, <8 x float> %private.contiguous.preserve275
  store <8 x float> %2306, ptr %private.contiguous.address274, align 4
  %2307 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2308 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2309 = add <8 x i64> %2308, splat (i64 384)
  %2310 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2307, 0
  %2311 = insertvalue { <8 x ptr>, <8 x i64> } %2310, <8 x i64> %2309, 1
  %2312 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2313 = extractvalue { <8 x ptr>, <8 x i64> } %2311, 1
  %2314 = extractelement <8 x ptr> %2312, i32 0
  %2315 = extractelement <8 x i64> %2313, i32 0
  %2316 = sub i64 %2315, 0
  %2317 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %74)
  %2318 = select i1 %2317, i64 %2316, i64 0
  %private.contiguous.address276 = getelementptr i8, ptr %2314, i64 %2318
  %private.contiguous.preserve277 = load <8 x float>, ptr %private.contiguous.address276, align 4
  %2319 = select <8 x i1> %74, <8 x float> %2130, <8 x float> %private.contiguous.preserve277
  store <8 x float> %2319, ptr %private.contiguous.address276, align 4
  %2320 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2321 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2322 = add <8 x i64> %2321, splat (i64 416)
  %2323 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2320, 0
  %2324 = insertvalue { <8 x ptr>, <8 x i64> } %2323, <8 x i64> %2322, 1
  %2325 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2326 = extractvalue { <8 x ptr>, <8 x i64> } %2324, 1
  %2327 = extractelement <8 x ptr> %2325, i32 0
  %2328 = extractelement <8 x i64> %2326, i32 0
  %2329 = sub i64 %2328, 0
  %2330 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %74)
  %2331 = select i1 %2330, i64 %2329, i64 0
  %private.contiguous.address278 = getelementptr i8, ptr %2327, i64 %2331
  %private.contiguous.preserve279 = load <8 x float>, ptr %private.contiguous.address278, align 4
  %2332 = select <8 x i1> %74, <8 x float> %2133, <8 x float> %private.contiguous.preserve279
  store <8 x float> %2332, ptr %private.contiguous.address278, align 4
  %2333 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2334 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2335 = add <8 x i64> %2334, splat (i64 448)
  %2336 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2333, 0
  %2337 = insertvalue { <8 x ptr>, <8 x i64> } %2336, <8 x i64> %2335, 1
  %2338 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2339 = extractvalue { <8 x ptr>, <8 x i64> } %2337, 1
  %2340 = extractelement <8 x ptr> %2338, i32 0
  %2341 = extractelement <8 x i64> %2339, i32 0
  %2342 = sub i64 %2341, 0
  %2343 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %74)
  %2344 = select i1 %2343, i64 %2342, i64 0
  %private.contiguous.address280 = getelementptr i8, ptr %2340, i64 %2344
  %private.contiguous.preserve281 = load <8 x float>, ptr %private.contiguous.address280, align 4
  %2345 = select <8 x i1> %74, <8 x float> %2136, <8 x float> %private.contiguous.preserve281
  store <8 x float> %2345, ptr %private.contiguous.address280, align 4
  %2346 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2347 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2348 = add <8 x i64> %2347, splat (i64 480)
  %2349 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2346, 0
  %2350 = insertvalue { <8 x ptr>, <8 x i64> } %2349, <8 x i64> %2348, 1
  %2351 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2352 = extractvalue { <8 x ptr>, <8 x i64> } %2350, 1
  %2353 = extractelement <8 x ptr> %2351, i32 0
  %2354 = extractelement <8 x i64> %2352, i32 0
  %2355 = sub i64 %2354, 0
  %2356 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %74)
  %2357 = select i1 %2356, i64 %2355, i64 0
  %private.contiguous.address282 = getelementptr i8, ptr %2353, i64 %2357
  %private.contiguous.preserve283 = load <8 x float>, ptr %private.contiguous.address282, align 4
  %2358 = select <8 x i1> %74, <8 x float> %2139, <8 x float> %private.contiguous.preserve283
  store <8 x float> %2358, ptr %private.contiguous.address282, align 4
  store i64 0, ptr %.slot137, align 4
  %2359 = load <8 x float>, ptr %.slot138, align 32
  %2360 = select <8 x i1> %74, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %2359
  store <8 x float> %2360, ptr %.slot138, align 32
  br label %direct.schedule.3

direct.true285:                                   ; preds = %direct.schedule.3
  br label %direct.schedule.4

direct.false286:                                  ; preds = %direct.schedule.3
  br label %direct.schedule.5

direct.true380:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false381:                                  ; preds = %direct.schedule.6
  br label %direct.schedule.8

mma.active521:                                    ; preds = %direct.schedule.8
  %2361 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load519, 0
  %2362 = extractelement <8 x ptr> %2361, i64 0
  %2363 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load519, 1
  %2364 = extractelement <8 x i64> %2363, i64 0
  %2365 = getelementptr i8, ptr %2362, i64 %2364
  %2366 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load520, 0
  %2367 = extractelement <8 x ptr> %2366, i64 0
  %2368 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load520, 1
  %2369 = extractelement <8 x i64> %2368, i64 0
  %2370 = getelementptr i8, ptr %2367, i64 %2369
  %2371 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2372 = extractelement <8 x ptr> %2371, i64 0
  %2373 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2374 = extractelement <8 x i64> %2373, i64 0
  %2375 = getelementptr i8, ptr %2372, i64 %2374
  %2376 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2377 = extractelement <8 x ptr> %2376, i64 0
  %2378 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2379 = extractelement <8 x i64> %2378, i64 0
  %2380 = getelementptr i8, ptr %2377, i64 %2379
  call void @llm_attention.strided_mma.3(ptr %2365, ptr %2370, ptr %2375, ptr %2380)
  br label %mma.continue522

mma.continue522:                                  ; preds = %mma.active521, %direct.schedule.8
  %2381 = extractelement <8 x i1> %74, i64 1
  br i1 %2381, label %mma.active523, label %mma.continue524

mma.active523:                                    ; preds = %mma.continue522
  %2382 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load519, 0
  %2383 = extractelement <8 x ptr> %2382, i64 1
  %2384 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load519, 1
  %2385 = extractelement <8 x i64> %2384, i64 1
  %2386 = getelementptr i8, ptr %2383, i64 %2385
  %2387 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load520, 0
  %2388 = extractelement <8 x ptr> %2387, i64 1
  %2389 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load520, 1
  %2390 = extractelement <8 x i64> %2389, i64 1
  %2391 = getelementptr i8, ptr %2388, i64 %2390
  %2392 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2393 = extractelement <8 x ptr> %2392, i64 1
  %2394 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2395 = extractelement <8 x i64> %2394, i64 1
  %2396 = getelementptr i8, ptr %2393, i64 %2395
  %2397 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2398 = extractelement <8 x ptr> %2397, i64 1
  %2399 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2400 = extractelement <8 x i64> %2399, i64 1
  %2401 = getelementptr i8, ptr %2398, i64 %2400
  call void @llm_attention.strided_mma.3(ptr %2386, ptr %2391, ptr %2396, ptr %2401)
  br label %mma.continue524

mma.continue524:                                  ; preds = %mma.active523, %mma.continue522
  %2402 = extractelement <8 x i1> %74, i64 2
  br i1 %2402, label %mma.active525, label %mma.continue526

mma.active525:                                    ; preds = %mma.continue524
  %2403 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load519, 0
  %2404 = extractelement <8 x ptr> %2403, i64 2
  %2405 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load519, 1
  %2406 = extractelement <8 x i64> %2405, i64 2
  %2407 = getelementptr i8, ptr %2404, i64 %2406
  %2408 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load520, 0
  %2409 = extractelement <8 x ptr> %2408, i64 2
  %2410 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load520, 1
  %2411 = extractelement <8 x i64> %2410, i64 2
  %2412 = getelementptr i8, ptr %2409, i64 %2411
  %2413 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2414 = extractelement <8 x ptr> %2413, i64 2
  %2415 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2416 = extractelement <8 x i64> %2415, i64 2
  %2417 = getelementptr i8, ptr %2414, i64 %2416
  %2418 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2419 = extractelement <8 x ptr> %2418, i64 2
  %2420 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2421 = extractelement <8 x i64> %2420, i64 2
  %2422 = getelementptr i8, ptr %2419, i64 %2421
  call void @llm_attention.strided_mma.3(ptr %2407, ptr %2412, ptr %2417, ptr %2422)
  br label %mma.continue526

mma.continue526:                                  ; preds = %mma.active525, %mma.continue524
  %2423 = extractelement <8 x i1> %74, i64 3
  br i1 %2423, label %mma.active527, label %mma.continue528

mma.active527:                                    ; preds = %mma.continue526
  %2424 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load519, 0
  %2425 = extractelement <8 x ptr> %2424, i64 3
  %2426 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load519, 1
  %2427 = extractelement <8 x i64> %2426, i64 3
  %2428 = getelementptr i8, ptr %2425, i64 %2427
  %2429 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load520, 0
  %2430 = extractelement <8 x ptr> %2429, i64 3
  %2431 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load520, 1
  %2432 = extractelement <8 x i64> %2431, i64 3
  %2433 = getelementptr i8, ptr %2430, i64 %2432
  %2434 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2435 = extractelement <8 x ptr> %2434, i64 3
  %2436 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2437 = extractelement <8 x i64> %2436, i64 3
  %2438 = getelementptr i8, ptr %2435, i64 %2437
  %2439 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2440 = extractelement <8 x ptr> %2439, i64 3
  %2441 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2442 = extractelement <8 x i64> %2441, i64 3
  %2443 = getelementptr i8, ptr %2440, i64 %2442
  call void @llm_attention.strided_mma.3(ptr %2428, ptr %2433, ptr %2438, ptr %2443)
  br label %mma.continue528

mma.continue528:                                  ; preds = %mma.active527, %mma.continue526
  %2444 = extractelement <8 x i1> %74, i64 4
  br i1 %2444, label %mma.active529, label %mma.continue530

mma.active529:                                    ; preds = %mma.continue528
  %2445 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load519, 0
  %2446 = extractelement <8 x ptr> %2445, i64 4
  %2447 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load519, 1
  %2448 = extractelement <8 x i64> %2447, i64 4
  %2449 = getelementptr i8, ptr %2446, i64 %2448
  %2450 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load520, 0
  %2451 = extractelement <8 x ptr> %2450, i64 4
  %2452 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load520, 1
  %2453 = extractelement <8 x i64> %2452, i64 4
  %2454 = getelementptr i8, ptr %2451, i64 %2453
  %2455 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2456 = extractelement <8 x ptr> %2455, i64 4
  %2457 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2458 = extractelement <8 x i64> %2457, i64 4
  %2459 = getelementptr i8, ptr %2456, i64 %2458
  %2460 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2461 = extractelement <8 x ptr> %2460, i64 4
  %2462 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2463 = extractelement <8 x i64> %2462, i64 4
  %2464 = getelementptr i8, ptr %2461, i64 %2463
  call void @llm_attention.strided_mma.3(ptr %2449, ptr %2454, ptr %2459, ptr %2464)
  br label %mma.continue530

mma.continue530:                                  ; preds = %mma.active529, %mma.continue528
  %2465 = extractelement <8 x i1> %74, i64 5
  br i1 %2465, label %mma.active531, label %mma.continue532

mma.active531:                                    ; preds = %mma.continue530
  %2466 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load519, 0
  %2467 = extractelement <8 x ptr> %2466, i64 5
  %2468 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load519, 1
  %2469 = extractelement <8 x i64> %2468, i64 5
  %2470 = getelementptr i8, ptr %2467, i64 %2469
  %2471 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load520, 0
  %2472 = extractelement <8 x ptr> %2471, i64 5
  %2473 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load520, 1
  %2474 = extractelement <8 x i64> %2473, i64 5
  %2475 = getelementptr i8, ptr %2472, i64 %2474
  %2476 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2477 = extractelement <8 x ptr> %2476, i64 5
  %2478 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2479 = extractelement <8 x i64> %2478, i64 5
  %2480 = getelementptr i8, ptr %2477, i64 %2479
  %2481 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2482 = extractelement <8 x ptr> %2481, i64 5
  %2483 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2484 = extractelement <8 x i64> %2483, i64 5
  %2485 = getelementptr i8, ptr %2482, i64 %2484
  call void @llm_attention.strided_mma.3(ptr %2470, ptr %2475, ptr %2480, ptr %2485)
  br label %mma.continue532

mma.continue532:                                  ; preds = %mma.active531, %mma.continue530
  %2486 = extractelement <8 x i1> %74, i64 6
  br i1 %2486, label %mma.active533, label %mma.continue534

mma.active533:                                    ; preds = %mma.continue532
  %2487 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load519, 0
  %2488 = extractelement <8 x ptr> %2487, i64 6
  %2489 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load519, 1
  %2490 = extractelement <8 x i64> %2489, i64 6
  %2491 = getelementptr i8, ptr %2488, i64 %2490
  %2492 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load520, 0
  %2493 = extractelement <8 x ptr> %2492, i64 6
  %2494 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load520, 1
  %2495 = extractelement <8 x i64> %2494, i64 6
  %2496 = getelementptr i8, ptr %2493, i64 %2495
  %2497 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2498 = extractelement <8 x ptr> %2497, i64 6
  %2499 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2500 = extractelement <8 x i64> %2499, i64 6
  %2501 = getelementptr i8, ptr %2498, i64 %2500
  %2502 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2503 = extractelement <8 x ptr> %2502, i64 6
  %2504 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2505 = extractelement <8 x i64> %2504, i64 6
  %2506 = getelementptr i8, ptr %2503, i64 %2505
  call void @llm_attention.strided_mma.3(ptr %2491, ptr %2496, ptr %2501, ptr %2506)
  br label %mma.continue534

mma.continue534:                                  ; preds = %mma.active533, %mma.continue532
  %2507 = extractelement <8 x i1> %74, i64 7
  br i1 %2507, label %mma.active535, label %mma.continue536

mma.active535:                                    ; preds = %mma.continue534
  %2508 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load519, 0
  %2509 = extractelement <8 x ptr> %2508, i64 7
  %2510 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load519, 1
  %2511 = extractelement <8 x i64> %2510, i64 7
  %2512 = getelementptr i8, ptr %2509, i64 %2511
  %2513 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load520, 0
  %2514 = extractelement <8 x ptr> %2513, i64 7
  %2515 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load520, 1
  %2516 = extractelement <8 x i64> %2515, i64 7
  %2517 = getelementptr i8, ptr %2514, i64 %2516
  %2518 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2519 = extractelement <8 x ptr> %2518, i64 7
  %2520 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2521 = extractelement <8 x i64> %2520, i64 7
  %2522 = getelementptr i8, ptr %2519, i64 %2521
  %2523 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2524 = extractelement <8 x ptr> %2523, i64 7
  %2525 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2526 = extractelement <8 x i64> %2525, i64 7
  %2527 = getelementptr i8, ptr %2524, i64 %2526
  call void @llm_attention.strided_mma.3(ptr %2512, ptr %2517, ptr %2522, ptr %2527)
  br label %mma.continue536

mma.continue536:                                  ; preds = %mma.active535, %mma.continue534
  %2528 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2529 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2530 = add <8 x i64> %2529, zeroinitializer
  %2531 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2528, 0
  %2532 = insertvalue { <8 x ptr>, <8 x i64> } %2531, <8 x i64> %2530, 1
  %2533 = extractvalue { <8 x ptr>, <8 x i64> } %2532, 0
  %2534 = extractvalue { <8 x ptr>, <8 x i64> } %2532, 1
  %2535 = getelementptr i8, <8 x ptr> %2533, <8 x i64> %2534
  %2536 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2535, <8 x i1> %74, <8 x float> zeroinitializer)
  %2537 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2538 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2539 = add <8 x i64> %2538, splat (i64 4)
  %2540 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2537, 0
  %2541 = insertvalue { <8 x ptr>, <8 x i64> } %2540, <8 x i64> %2539, 1
  %2542 = extractvalue { <8 x ptr>, <8 x i64> } %2541, 0
  %2543 = extractvalue { <8 x ptr>, <8 x i64> } %2541, 1
  %2544 = getelementptr i8, <8 x ptr> %2542, <8 x i64> %2543
  %2545 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2544, <8 x i1> %74, <8 x float> zeroinitializer)
  %2546 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2547 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2548 = add <8 x i64> %2547, splat (i64 8)
  %2549 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2546, 0
  %2550 = insertvalue { <8 x ptr>, <8 x i64> } %2549, <8 x i64> %2548, 1
  %2551 = extractvalue { <8 x ptr>, <8 x i64> } %2550, 0
  %2552 = extractvalue { <8 x ptr>, <8 x i64> } %2550, 1
  %2553 = getelementptr i8, <8 x ptr> %2551, <8 x i64> %2552
  %2554 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2553, <8 x i1> %74, <8 x float> zeroinitializer)
  %2555 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2556 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2557 = add <8 x i64> %2556, splat (i64 12)
  %2558 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2555, 0
  %2559 = insertvalue { <8 x ptr>, <8 x i64> } %2558, <8 x i64> %2557, 1
  %2560 = extractvalue { <8 x ptr>, <8 x i64> } %2559, 0
  %2561 = extractvalue { <8 x ptr>, <8 x i64> } %2559, 1
  %2562 = getelementptr i8, <8 x ptr> %2560, <8 x i64> %2561
  %2563 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2562, <8 x i1> %74, <8 x float> zeroinitializer)
  %2564 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2565 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2566 = add <8 x i64> %2565, splat (i64 16)
  %2567 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2564, 0
  %2568 = insertvalue { <8 x ptr>, <8 x i64> } %2567, <8 x i64> %2566, 1
  %2569 = extractvalue { <8 x ptr>, <8 x i64> } %2568, 0
  %2570 = extractvalue { <8 x ptr>, <8 x i64> } %2568, 1
  %2571 = getelementptr i8, <8 x ptr> %2569, <8 x i64> %2570
  %2572 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2571, <8 x i1> %74, <8 x float> zeroinitializer)
  %2573 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2574 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2575 = add <8 x i64> %2574, splat (i64 20)
  %2576 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2573, 0
  %2577 = insertvalue { <8 x ptr>, <8 x i64> } %2576, <8 x i64> %2575, 1
  %2578 = extractvalue { <8 x ptr>, <8 x i64> } %2577, 0
  %2579 = extractvalue { <8 x ptr>, <8 x i64> } %2577, 1
  %2580 = getelementptr i8, <8 x ptr> %2578, <8 x i64> %2579
  %2581 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2580, <8 x i1> %74, <8 x float> zeroinitializer)
  %2582 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2583 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2584 = add <8 x i64> %2583, splat (i64 24)
  %2585 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2582, 0
  %2586 = insertvalue { <8 x ptr>, <8 x i64> } %2585, <8 x i64> %2584, 1
  %2587 = extractvalue { <8 x ptr>, <8 x i64> } %2586, 0
  %2588 = extractvalue { <8 x ptr>, <8 x i64> } %2586, 1
  %2589 = getelementptr i8, <8 x ptr> %2587, <8 x i64> %2588
  %2590 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2589, <8 x i1> %74, <8 x float> zeroinitializer)
  %2591 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2592 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2593 = add <8 x i64> %2592, splat (i64 28)
  %2594 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2591, 0
  %2595 = insertvalue { <8 x ptr>, <8 x i64> } %2594, <8 x i64> %2593, 1
  %2596 = extractvalue { <8 x ptr>, <8 x i64> } %2595, 0
  %2597 = extractvalue { <8 x ptr>, <8 x i64> } %2595, 1
  %2598 = getelementptr i8, <8 x ptr> %2596, <8 x i64> %2597
  %2599 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2598, <8 x i1> %74, <8 x float> zeroinitializer)
  %2600 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2601 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2602 = add <8 x i64> %2601, splat (i64 32)
  %2603 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2600, 0
  %2604 = insertvalue { <8 x ptr>, <8 x i64> } %2603, <8 x i64> %2602, 1
  %2605 = extractvalue { <8 x ptr>, <8 x i64> } %2604, 0
  %2606 = extractvalue { <8 x ptr>, <8 x i64> } %2604, 1
  %2607 = getelementptr i8, <8 x ptr> %2605, <8 x i64> %2606
  %2608 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2607, <8 x i1> %74, <8 x float> zeroinitializer)
  %2609 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2610 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2611 = add <8 x i64> %2610, splat (i64 36)
  %2612 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2609, 0
  %2613 = insertvalue { <8 x ptr>, <8 x i64> } %2612, <8 x i64> %2611, 1
  %2614 = extractvalue { <8 x ptr>, <8 x i64> } %2613, 0
  %2615 = extractvalue { <8 x ptr>, <8 x i64> } %2613, 1
  %2616 = getelementptr i8, <8 x ptr> %2614, <8 x i64> %2615
  %2617 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2616, <8 x i1> %74, <8 x float> zeroinitializer)
  %2618 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2619 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2620 = add <8 x i64> %2619, splat (i64 40)
  %2621 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2618, 0
  %2622 = insertvalue { <8 x ptr>, <8 x i64> } %2621, <8 x i64> %2620, 1
  %2623 = extractvalue { <8 x ptr>, <8 x i64> } %2622, 0
  %2624 = extractvalue { <8 x ptr>, <8 x i64> } %2622, 1
  %2625 = getelementptr i8, <8 x ptr> %2623, <8 x i64> %2624
  %2626 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2625, <8 x i1> %74, <8 x float> zeroinitializer)
  %2627 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2628 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2629 = add <8 x i64> %2628, splat (i64 44)
  %2630 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2627, 0
  %2631 = insertvalue { <8 x ptr>, <8 x i64> } %2630, <8 x i64> %2629, 1
  %2632 = extractvalue { <8 x ptr>, <8 x i64> } %2631, 0
  %2633 = extractvalue { <8 x ptr>, <8 x i64> } %2631, 1
  %2634 = getelementptr i8, <8 x ptr> %2632, <8 x i64> %2633
  %2635 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2634, <8 x i1> %74, <8 x float> zeroinitializer)
  %2636 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2637 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2638 = add <8 x i64> %2637, splat (i64 48)
  %2639 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2636, 0
  %2640 = insertvalue { <8 x ptr>, <8 x i64> } %2639, <8 x i64> %2638, 1
  %2641 = extractvalue { <8 x ptr>, <8 x i64> } %2640, 0
  %2642 = extractvalue { <8 x ptr>, <8 x i64> } %2640, 1
  %2643 = getelementptr i8, <8 x ptr> %2641, <8 x i64> %2642
  %2644 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2643, <8 x i1> %74, <8 x float> zeroinitializer)
  %2645 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2646 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2647 = add <8 x i64> %2646, splat (i64 52)
  %2648 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2645, 0
  %2649 = insertvalue { <8 x ptr>, <8 x i64> } %2648, <8 x i64> %2647, 1
  %2650 = extractvalue { <8 x ptr>, <8 x i64> } %2649, 0
  %2651 = extractvalue { <8 x ptr>, <8 x i64> } %2649, 1
  %2652 = getelementptr i8, <8 x ptr> %2650, <8 x i64> %2651
  %2653 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2652, <8 x i1> %74, <8 x float> zeroinitializer)
  %2654 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2655 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2656 = add <8 x i64> %2655, splat (i64 56)
  %2657 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2654, 0
  %2658 = insertvalue { <8 x ptr>, <8 x i64> } %2657, <8 x i64> %2656, 1
  %2659 = extractvalue { <8 x ptr>, <8 x i64> } %2658, 0
  %2660 = extractvalue { <8 x ptr>, <8 x i64> } %2658, 1
  %2661 = getelementptr i8, <8 x ptr> %2659, <8 x i64> %2660
  %2662 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2661, <8 x i1> %74, <8 x float> zeroinitializer)
  %2663 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2664 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2665 = add <8 x i64> %2664, splat (i64 60)
  %2666 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2663, 0
  %2667 = insertvalue { <8 x ptr>, <8 x i64> } %2666, <8 x i64> %2665, 1
  %2668 = extractvalue { <8 x ptr>, <8 x i64> } %2667, 0
  %2669 = extractvalue { <8 x ptr>, <8 x i64> } %2667, 1
  %2670 = getelementptr i8, <8 x ptr> %2668, <8 x i64> %2669
  %2671 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2670, <8 x i1> %74, <8 x float> zeroinitializer)
  %2672 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2673 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2674 = add <8 x i64> %2673, splat (i64 64)
  %2675 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2672, 0
  %2676 = insertvalue { <8 x ptr>, <8 x i64> } %2675, <8 x i64> %2674, 1
  %2677 = extractvalue { <8 x ptr>, <8 x i64> } %2676, 0
  %2678 = extractvalue { <8 x ptr>, <8 x i64> } %2676, 1
  %2679 = getelementptr i8, <8 x ptr> %2677, <8 x i64> %2678
  %2680 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2679, <8 x i1> %74, <8 x float> zeroinitializer)
  %2681 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2682 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2683 = add <8 x i64> %2682, splat (i64 68)
  %2684 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2681, 0
  %2685 = insertvalue { <8 x ptr>, <8 x i64> } %2684, <8 x i64> %2683, 1
  %2686 = extractvalue { <8 x ptr>, <8 x i64> } %2685, 0
  %2687 = extractvalue { <8 x ptr>, <8 x i64> } %2685, 1
  %2688 = getelementptr i8, <8 x ptr> %2686, <8 x i64> %2687
  %2689 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2688, <8 x i1> %74, <8 x float> zeroinitializer)
  %2690 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2691 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2692 = add <8 x i64> %2691, splat (i64 72)
  %2693 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2690, 0
  %2694 = insertvalue { <8 x ptr>, <8 x i64> } %2693, <8 x i64> %2692, 1
  %2695 = extractvalue { <8 x ptr>, <8 x i64> } %2694, 0
  %2696 = extractvalue { <8 x ptr>, <8 x i64> } %2694, 1
  %2697 = getelementptr i8, <8 x ptr> %2695, <8 x i64> %2696
  %2698 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2697, <8 x i1> %74, <8 x float> zeroinitializer)
  %2699 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2700 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2701 = add <8 x i64> %2700, splat (i64 76)
  %2702 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2699, 0
  %2703 = insertvalue { <8 x ptr>, <8 x i64> } %2702, <8 x i64> %2701, 1
  %2704 = extractvalue { <8 x ptr>, <8 x i64> } %2703, 0
  %2705 = extractvalue { <8 x ptr>, <8 x i64> } %2703, 1
  %2706 = getelementptr i8, <8 x ptr> %2704, <8 x i64> %2705
  %2707 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2706, <8 x i1> %74, <8 x float> zeroinitializer)
  %2708 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2709 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2710 = add <8 x i64> %2709, splat (i64 80)
  %2711 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2708, 0
  %2712 = insertvalue { <8 x ptr>, <8 x i64> } %2711, <8 x i64> %2710, 1
  %2713 = extractvalue { <8 x ptr>, <8 x i64> } %2712, 0
  %2714 = extractvalue { <8 x ptr>, <8 x i64> } %2712, 1
  %2715 = getelementptr i8, <8 x ptr> %2713, <8 x i64> %2714
  %2716 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2715, <8 x i1> %74, <8 x float> zeroinitializer)
  %2717 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2718 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2719 = add <8 x i64> %2718, splat (i64 84)
  %2720 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2717, 0
  %2721 = insertvalue { <8 x ptr>, <8 x i64> } %2720, <8 x i64> %2719, 1
  %2722 = extractvalue { <8 x ptr>, <8 x i64> } %2721, 0
  %2723 = extractvalue { <8 x ptr>, <8 x i64> } %2721, 1
  %2724 = getelementptr i8, <8 x ptr> %2722, <8 x i64> %2723
  %2725 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2724, <8 x i1> %74, <8 x float> zeroinitializer)
  %2726 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2727 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2728 = add <8 x i64> %2727, splat (i64 88)
  %2729 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2726, 0
  %2730 = insertvalue { <8 x ptr>, <8 x i64> } %2729, <8 x i64> %2728, 1
  %2731 = extractvalue { <8 x ptr>, <8 x i64> } %2730, 0
  %2732 = extractvalue { <8 x ptr>, <8 x i64> } %2730, 1
  %2733 = getelementptr i8, <8 x ptr> %2731, <8 x i64> %2732
  %2734 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2733, <8 x i1> %74, <8 x float> zeroinitializer)
  %2735 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2736 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2737 = add <8 x i64> %2736, splat (i64 92)
  %2738 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2735, 0
  %2739 = insertvalue { <8 x ptr>, <8 x i64> } %2738, <8 x i64> %2737, 1
  %2740 = extractvalue { <8 x ptr>, <8 x i64> } %2739, 0
  %2741 = extractvalue { <8 x ptr>, <8 x i64> } %2739, 1
  %2742 = getelementptr i8, <8 x ptr> %2740, <8 x i64> %2741
  %2743 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2742, <8 x i1> %74, <8 x float> zeroinitializer)
  %2744 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2745 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2746 = add <8 x i64> %2745, splat (i64 96)
  %2747 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2744, 0
  %2748 = insertvalue { <8 x ptr>, <8 x i64> } %2747, <8 x i64> %2746, 1
  %2749 = extractvalue { <8 x ptr>, <8 x i64> } %2748, 0
  %2750 = extractvalue { <8 x ptr>, <8 x i64> } %2748, 1
  %2751 = getelementptr i8, <8 x ptr> %2749, <8 x i64> %2750
  %2752 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2751, <8 x i1> %74, <8 x float> zeroinitializer)
  %2753 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2754 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2755 = add <8 x i64> %2754, splat (i64 100)
  %2756 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2753, 0
  %2757 = insertvalue { <8 x ptr>, <8 x i64> } %2756, <8 x i64> %2755, 1
  %2758 = extractvalue { <8 x ptr>, <8 x i64> } %2757, 0
  %2759 = extractvalue { <8 x ptr>, <8 x i64> } %2757, 1
  %2760 = getelementptr i8, <8 x ptr> %2758, <8 x i64> %2759
  %2761 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2760, <8 x i1> %74, <8 x float> zeroinitializer)
  %2762 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2763 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2764 = add <8 x i64> %2763, splat (i64 104)
  %2765 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2762, 0
  %2766 = insertvalue { <8 x ptr>, <8 x i64> } %2765, <8 x i64> %2764, 1
  %2767 = extractvalue { <8 x ptr>, <8 x i64> } %2766, 0
  %2768 = extractvalue { <8 x ptr>, <8 x i64> } %2766, 1
  %2769 = getelementptr i8, <8 x ptr> %2767, <8 x i64> %2768
  %2770 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2769, <8 x i1> %74, <8 x float> zeroinitializer)
  %2771 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2772 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2773 = add <8 x i64> %2772, splat (i64 108)
  %2774 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2771, 0
  %2775 = insertvalue { <8 x ptr>, <8 x i64> } %2774, <8 x i64> %2773, 1
  %2776 = extractvalue { <8 x ptr>, <8 x i64> } %2775, 0
  %2777 = extractvalue { <8 x ptr>, <8 x i64> } %2775, 1
  %2778 = getelementptr i8, <8 x ptr> %2776, <8 x i64> %2777
  %2779 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2778, <8 x i1> %74, <8 x float> zeroinitializer)
  %2780 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2781 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2782 = add <8 x i64> %2781, splat (i64 112)
  %2783 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2780, 0
  %2784 = insertvalue { <8 x ptr>, <8 x i64> } %2783, <8 x i64> %2782, 1
  %2785 = extractvalue { <8 x ptr>, <8 x i64> } %2784, 0
  %2786 = extractvalue { <8 x ptr>, <8 x i64> } %2784, 1
  %2787 = getelementptr i8, <8 x ptr> %2785, <8 x i64> %2786
  %2788 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2787, <8 x i1> %74, <8 x float> zeroinitializer)
  %2789 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2790 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2791 = add <8 x i64> %2790, splat (i64 116)
  %2792 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2789, 0
  %2793 = insertvalue { <8 x ptr>, <8 x i64> } %2792, <8 x i64> %2791, 1
  %2794 = extractvalue { <8 x ptr>, <8 x i64> } %2793, 0
  %2795 = extractvalue { <8 x ptr>, <8 x i64> } %2793, 1
  %2796 = getelementptr i8, <8 x ptr> %2794, <8 x i64> %2795
  %2797 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2796, <8 x i1> %74, <8 x float> zeroinitializer)
  %2798 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2799 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2800 = add <8 x i64> %2799, splat (i64 120)
  %2801 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2798, 0
  %2802 = insertvalue { <8 x ptr>, <8 x i64> } %2801, <8 x i64> %2800, 1
  %2803 = extractvalue { <8 x ptr>, <8 x i64> } %2802, 0
  %2804 = extractvalue { <8 x ptr>, <8 x i64> } %2802, 1
  %2805 = getelementptr i8, <8 x ptr> %2803, <8 x i64> %2804
  %2806 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2805, <8 x i1> %74, <8 x float> zeroinitializer)
  %2807 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2808 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2809 = add <8 x i64> %2808, splat (i64 124)
  %2810 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2807, 0
  %2811 = insertvalue { <8 x ptr>, <8 x i64> } %2810, <8 x i64> %2809, 1
  %2812 = extractvalue { <8 x ptr>, <8 x i64> } %2811, 0
  %2813 = extractvalue { <8 x ptr>, <8 x i64> } %2811, 1
  %2814 = getelementptr i8, <8 x ptr> %2812, <8 x i64> %2813
  %2815 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2814, <8 x i1> %74, <8 x float> zeroinitializer)
  %2816 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2817 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2818 = add <8 x i64> %2817, splat (i64 128)
  %2819 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2816, 0
  %2820 = insertvalue { <8 x ptr>, <8 x i64> } %2819, <8 x i64> %2818, 1
  %2821 = extractvalue { <8 x ptr>, <8 x i64> } %2820, 0
  %2822 = extractvalue { <8 x ptr>, <8 x i64> } %2820, 1
  %2823 = getelementptr i8, <8 x ptr> %2821, <8 x i64> %2822
  %2824 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2823, <8 x i1> %74, <8 x float> zeroinitializer)
  %2825 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2826 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2827 = add <8 x i64> %2826, splat (i64 132)
  %2828 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2825, 0
  %2829 = insertvalue { <8 x ptr>, <8 x i64> } %2828, <8 x i64> %2827, 1
  %2830 = extractvalue { <8 x ptr>, <8 x i64> } %2829, 0
  %2831 = extractvalue { <8 x ptr>, <8 x i64> } %2829, 1
  %2832 = getelementptr i8, <8 x ptr> %2830, <8 x i64> %2831
  %2833 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2832, <8 x i1> %74, <8 x float> zeroinitializer)
  %2834 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2835 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2836 = add <8 x i64> %2835, splat (i64 136)
  %2837 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2834, 0
  %2838 = insertvalue { <8 x ptr>, <8 x i64> } %2837, <8 x i64> %2836, 1
  %2839 = extractvalue { <8 x ptr>, <8 x i64> } %2838, 0
  %2840 = extractvalue { <8 x ptr>, <8 x i64> } %2838, 1
  %2841 = getelementptr i8, <8 x ptr> %2839, <8 x i64> %2840
  %2842 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2841, <8 x i1> %74, <8 x float> zeroinitializer)
  %2843 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2844 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2845 = add <8 x i64> %2844, splat (i64 140)
  %2846 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2843, 0
  %2847 = insertvalue { <8 x ptr>, <8 x i64> } %2846, <8 x i64> %2845, 1
  %2848 = extractvalue { <8 x ptr>, <8 x i64> } %2847, 0
  %2849 = extractvalue { <8 x ptr>, <8 x i64> } %2847, 1
  %2850 = getelementptr i8, <8 x ptr> %2848, <8 x i64> %2849
  %2851 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2850, <8 x i1> %74, <8 x float> zeroinitializer)
  %2852 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2853 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2854 = add <8 x i64> %2853, splat (i64 144)
  %2855 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2852, 0
  %2856 = insertvalue { <8 x ptr>, <8 x i64> } %2855, <8 x i64> %2854, 1
  %2857 = extractvalue { <8 x ptr>, <8 x i64> } %2856, 0
  %2858 = extractvalue { <8 x ptr>, <8 x i64> } %2856, 1
  %2859 = getelementptr i8, <8 x ptr> %2857, <8 x i64> %2858
  %2860 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2859, <8 x i1> %74, <8 x float> zeroinitializer)
  %2861 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2862 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2863 = add <8 x i64> %2862, splat (i64 148)
  %2864 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2861, 0
  %2865 = insertvalue { <8 x ptr>, <8 x i64> } %2864, <8 x i64> %2863, 1
  %2866 = extractvalue { <8 x ptr>, <8 x i64> } %2865, 0
  %2867 = extractvalue { <8 x ptr>, <8 x i64> } %2865, 1
  %2868 = getelementptr i8, <8 x ptr> %2866, <8 x i64> %2867
  %2869 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2868, <8 x i1> %74, <8 x float> zeroinitializer)
  %2870 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2871 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2872 = add <8 x i64> %2871, splat (i64 152)
  %2873 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2870, 0
  %2874 = insertvalue { <8 x ptr>, <8 x i64> } %2873, <8 x i64> %2872, 1
  %2875 = extractvalue { <8 x ptr>, <8 x i64> } %2874, 0
  %2876 = extractvalue { <8 x ptr>, <8 x i64> } %2874, 1
  %2877 = getelementptr i8, <8 x ptr> %2875, <8 x i64> %2876
  %2878 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2877, <8 x i1> %74, <8 x float> zeroinitializer)
  %2879 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2880 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2881 = add <8 x i64> %2880, splat (i64 156)
  %2882 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2879, 0
  %2883 = insertvalue { <8 x ptr>, <8 x i64> } %2882, <8 x i64> %2881, 1
  %2884 = extractvalue { <8 x ptr>, <8 x i64> } %2883, 0
  %2885 = extractvalue { <8 x ptr>, <8 x i64> } %2883, 1
  %2886 = getelementptr i8, <8 x ptr> %2884, <8 x i64> %2885
  %2887 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2886, <8 x i1> %74, <8 x float> zeroinitializer)
  %2888 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2889 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2890 = add <8 x i64> %2889, splat (i64 160)
  %2891 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2888, 0
  %2892 = insertvalue { <8 x ptr>, <8 x i64> } %2891, <8 x i64> %2890, 1
  %2893 = extractvalue { <8 x ptr>, <8 x i64> } %2892, 0
  %2894 = extractvalue { <8 x ptr>, <8 x i64> } %2892, 1
  %2895 = getelementptr i8, <8 x ptr> %2893, <8 x i64> %2894
  %2896 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2895, <8 x i1> %74, <8 x float> zeroinitializer)
  %2897 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2898 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2899 = add <8 x i64> %2898, splat (i64 164)
  %2900 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2897, 0
  %2901 = insertvalue { <8 x ptr>, <8 x i64> } %2900, <8 x i64> %2899, 1
  %2902 = extractvalue { <8 x ptr>, <8 x i64> } %2901, 0
  %2903 = extractvalue { <8 x ptr>, <8 x i64> } %2901, 1
  %2904 = getelementptr i8, <8 x ptr> %2902, <8 x i64> %2903
  %2905 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2904, <8 x i1> %74, <8 x float> zeroinitializer)
  %2906 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2907 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2908 = add <8 x i64> %2907, splat (i64 168)
  %2909 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2906, 0
  %2910 = insertvalue { <8 x ptr>, <8 x i64> } %2909, <8 x i64> %2908, 1
  %2911 = extractvalue { <8 x ptr>, <8 x i64> } %2910, 0
  %2912 = extractvalue { <8 x ptr>, <8 x i64> } %2910, 1
  %2913 = getelementptr i8, <8 x ptr> %2911, <8 x i64> %2912
  %2914 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2913, <8 x i1> %74, <8 x float> zeroinitializer)
  %2915 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2916 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2917 = add <8 x i64> %2916, splat (i64 172)
  %2918 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2915, 0
  %2919 = insertvalue { <8 x ptr>, <8 x i64> } %2918, <8 x i64> %2917, 1
  %2920 = extractvalue { <8 x ptr>, <8 x i64> } %2919, 0
  %2921 = extractvalue { <8 x ptr>, <8 x i64> } %2919, 1
  %2922 = getelementptr i8, <8 x ptr> %2920, <8 x i64> %2921
  %2923 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2922, <8 x i1> %74, <8 x float> zeroinitializer)
  %2924 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2925 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2926 = add <8 x i64> %2925, splat (i64 176)
  %2927 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2924, 0
  %2928 = insertvalue { <8 x ptr>, <8 x i64> } %2927, <8 x i64> %2926, 1
  %2929 = extractvalue { <8 x ptr>, <8 x i64> } %2928, 0
  %2930 = extractvalue { <8 x ptr>, <8 x i64> } %2928, 1
  %2931 = getelementptr i8, <8 x ptr> %2929, <8 x i64> %2930
  %2932 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2931, <8 x i1> %74, <8 x float> zeroinitializer)
  %2933 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2934 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2935 = add <8 x i64> %2934, splat (i64 180)
  %2936 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2933, 0
  %2937 = insertvalue { <8 x ptr>, <8 x i64> } %2936, <8 x i64> %2935, 1
  %2938 = extractvalue { <8 x ptr>, <8 x i64> } %2937, 0
  %2939 = extractvalue { <8 x ptr>, <8 x i64> } %2937, 1
  %2940 = getelementptr i8, <8 x ptr> %2938, <8 x i64> %2939
  %2941 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2940, <8 x i1> %74, <8 x float> zeroinitializer)
  %2942 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2943 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2944 = add <8 x i64> %2943, splat (i64 184)
  %2945 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2942, 0
  %2946 = insertvalue { <8 x ptr>, <8 x i64> } %2945, <8 x i64> %2944, 1
  %2947 = extractvalue { <8 x ptr>, <8 x i64> } %2946, 0
  %2948 = extractvalue { <8 x ptr>, <8 x i64> } %2946, 1
  %2949 = getelementptr i8, <8 x ptr> %2947, <8 x i64> %2948
  %2950 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2949, <8 x i1> %74, <8 x float> zeroinitializer)
  %2951 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2952 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2953 = add <8 x i64> %2952, splat (i64 188)
  %2954 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2951, 0
  %2955 = insertvalue { <8 x ptr>, <8 x i64> } %2954, <8 x i64> %2953, 1
  %2956 = extractvalue { <8 x ptr>, <8 x i64> } %2955, 0
  %2957 = extractvalue { <8 x ptr>, <8 x i64> } %2955, 1
  %2958 = getelementptr i8, <8 x ptr> %2956, <8 x i64> %2957
  %2959 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2958, <8 x i1> %74, <8 x float> zeroinitializer)
  %2960 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2961 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2962 = add <8 x i64> %2961, splat (i64 192)
  %2963 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2960, 0
  %2964 = insertvalue { <8 x ptr>, <8 x i64> } %2963, <8 x i64> %2962, 1
  %2965 = extractvalue { <8 x ptr>, <8 x i64> } %2964, 0
  %2966 = extractvalue { <8 x ptr>, <8 x i64> } %2964, 1
  %2967 = getelementptr i8, <8 x ptr> %2965, <8 x i64> %2966
  %2968 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2967, <8 x i1> %74, <8 x float> zeroinitializer)
  %2969 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2970 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2971 = add <8 x i64> %2970, splat (i64 196)
  %2972 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2969, 0
  %2973 = insertvalue { <8 x ptr>, <8 x i64> } %2972, <8 x i64> %2971, 1
  %2974 = extractvalue { <8 x ptr>, <8 x i64> } %2973, 0
  %2975 = extractvalue { <8 x ptr>, <8 x i64> } %2973, 1
  %2976 = getelementptr i8, <8 x ptr> %2974, <8 x i64> %2975
  %2977 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2976, <8 x i1> %74, <8 x float> zeroinitializer)
  %2978 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2979 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2980 = add <8 x i64> %2979, splat (i64 200)
  %2981 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2978, 0
  %2982 = insertvalue { <8 x ptr>, <8 x i64> } %2981, <8 x i64> %2980, 1
  %2983 = extractvalue { <8 x ptr>, <8 x i64> } %2982, 0
  %2984 = extractvalue { <8 x ptr>, <8 x i64> } %2982, 1
  %2985 = getelementptr i8, <8 x ptr> %2983, <8 x i64> %2984
  %2986 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2985, <8 x i1> %74, <8 x float> zeroinitializer)
  %2987 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2988 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2989 = add <8 x i64> %2988, splat (i64 204)
  %2990 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2987, 0
  %2991 = insertvalue { <8 x ptr>, <8 x i64> } %2990, <8 x i64> %2989, 1
  %2992 = extractvalue { <8 x ptr>, <8 x i64> } %2991, 0
  %2993 = extractvalue { <8 x ptr>, <8 x i64> } %2991, 1
  %2994 = getelementptr i8, <8 x ptr> %2992, <8 x i64> %2993
  %2995 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2994, <8 x i1> %74, <8 x float> zeroinitializer)
  %2996 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2997 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2998 = add <8 x i64> %2997, splat (i64 208)
  %2999 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2996, 0
  %3000 = insertvalue { <8 x ptr>, <8 x i64> } %2999, <8 x i64> %2998, 1
  %3001 = extractvalue { <8 x ptr>, <8 x i64> } %3000, 0
  %3002 = extractvalue { <8 x ptr>, <8 x i64> } %3000, 1
  %3003 = getelementptr i8, <8 x ptr> %3001, <8 x i64> %3002
  %3004 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3003, <8 x i1> %74, <8 x float> zeroinitializer)
  %3005 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3006 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %3007 = add <8 x i64> %3006, splat (i64 212)
  %3008 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3005, 0
  %3009 = insertvalue { <8 x ptr>, <8 x i64> } %3008, <8 x i64> %3007, 1
  %3010 = extractvalue { <8 x ptr>, <8 x i64> } %3009, 0
  %3011 = extractvalue { <8 x ptr>, <8 x i64> } %3009, 1
  %3012 = getelementptr i8, <8 x ptr> %3010, <8 x i64> %3011
  %3013 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3012, <8 x i1> %74, <8 x float> zeroinitializer)
  %3014 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3015 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %3016 = add <8 x i64> %3015, splat (i64 216)
  %3017 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3014, 0
  %3018 = insertvalue { <8 x ptr>, <8 x i64> } %3017, <8 x i64> %3016, 1
  %3019 = extractvalue { <8 x ptr>, <8 x i64> } %3018, 0
  %3020 = extractvalue { <8 x ptr>, <8 x i64> } %3018, 1
  %3021 = getelementptr i8, <8 x ptr> %3019, <8 x i64> %3020
  %3022 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3021, <8 x i1> %74, <8 x float> zeroinitializer)
  %3023 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3024 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %3025 = add <8 x i64> %3024, splat (i64 220)
  %3026 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3023, 0
  %3027 = insertvalue { <8 x ptr>, <8 x i64> } %3026, <8 x i64> %3025, 1
  %3028 = extractvalue { <8 x ptr>, <8 x i64> } %3027, 0
  %3029 = extractvalue { <8 x ptr>, <8 x i64> } %3027, 1
  %3030 = getelementptr i8, <8 x ptr> %3028, <8 x i64> %3029
  %3031 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3030, <8 x i1> %74, <8 x float> zeroinitializer)
  %3032 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3033 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %3034 = add <8 x i64> %3033, splat (i64 224)
  %3035 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3032, 0
  %3036 = insertvalue { <8 x ptr>, <8 x i64> } %3035, <8 x i64> %3034, 1
  %3037 = extractvalue { <8 x ptr>, <8 x i64> } %3036, 0
  %3038 = extractvalue { <8 x ptr>, <8 x i64> } %3036, 1
  %3039 = getelementptr i8, <8 x ptr> %3037, <8 x i64> %3038
  %3040 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3039, <8 x i1> %74, <8 x float> zeroinitializer)
  %3041 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3042 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %3043 = add <8 x i64> %3042, splat (i64 228)
  %3044 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3041, 0
  %3045 = insertvalue { <8 x ptr>, <8 x i64> } %3044, <8 x i64> %3043, 1
  %3046 = extractvalue { <8 x ptr>, <8 x i64> } %3045, 0
  %3047 = extractvalue { <8 x ptr>, <8 x i64> } %3045, 1
  %3048 = getelementptr i8, <8 x ptr> %3046, <8 x i64> %3047
  %3049 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3048, <8 x i1> %74, <8 x float> zeroinitializer)
  %3050 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3051 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %3052 = add <8 x i64> %3051, splat (i64 232)
  %3053 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3050, 0
  %3054 = insertvalue { <8 x ptr>, <8 x i64> } %3053, <8 x i64> %3052, 1
  %3055 = extractvalue { <8 x ptr>, <8 x i64> } %3054, 0
  %3056 = extractvalue { <8 x ptr>, <8 x i64> } %3054, 1
  %3057 = getelementptr i8, <8 x ptr> %3055, <8 x i64> %3056
  %3058 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3057, <8 x i1> %74, <8 x float> zeroinitializer)
  %3059 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3060 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %3061 = add <8 x i64> %3060, splat (i64 236)
  %3062 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3059, 0
  %3063 = insertvalue { <8 x ptr>, <8 x i64> } %3062, <8 x i64> %3061, 1
  %3064 = extractvalue { <8 x ptr>, <8 x i64> } %3063, 0
  %3065 = extractvalue { <8 x ptr>, <8 x i64> } %3063, 1
  %3066 = getelementptr i8, <8 x ptr> %3064, <8 x i64> %3065
  %3067 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3066, <8 x i1> %74, <8 x float> zeroinitializer)
  %3068 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3069 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %3070 = add <8 x i64> %3069, splat (i64 240)
  %3071 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3068, 0
  %3072 = insertvalue { <8 x ptr>, <8 x i64> } %3071, <8 x i64> %3070, 1
  %3073 = extractvalue { <8 x ptr>, <8 x i64> } %3072, 0
  %3074 = extractvalue { <8 x ptr>, <8 x i64> } %3072, 1
  %3075 = getelementptr i8, <8 x ptr> %3073, <8 x i64> %3074
  %3076 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3075, <8 x i1> %74, <8 x float> zeroinitializer)
  %3077 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3078 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %3079 = add <8 x i64> %3078, splat (i64 244)
  %3080 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3077, 0
  %3081 = insertvalue { <8 x ptr>, <8 x i64> } %3080, <8 x i64> %3079, 1
  %3082 = extractvalue { <8 x ptr>, <8 x i64> } %3081, 0
  %3083 = extractvalue { <8 x ptr>, <8 x i64> } %3081, 1
  %3084 = getelementptr i8, <8 x ptr> %3082, <8 x i64> %3083
  %3085 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3084, <8 x i1> %74, <8 x float> zeroinitializer)
  %3086 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3087 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %3088 = add <8 x i64> %3087, splat (i64 248)
  %3089 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3086, 0
  %3090 = insertvalue { <8 x ptr>, <8 x i64> } %3089, <8 x i64> %3088, 1
  %3091 = extractvalue { <8 x ptr>, <8 x i64> } %3090, 0
  %3092 = extractvalue { <8 x ptr>, <8 x i64> } %3090, 1
  %3093 = getelementptr i8, <8 x ptr> %3091, <8 x i64> %3092
  %3094 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3093, <8 x i1> %74, <8 x float> zeroinitializer)
  %3095 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3096 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %3097 = add <8 x i64> %3096, splat (i64 252)
  %3098 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3095, 0
  %3099 = insertvalue { <8 x ptr>, <8 x i64> } %3098, <8 x i64> %3097, 1
  %3100 = extractvalue { <8 x ptr>, <8 x i64> } %3099, 0
  %3101 = extractvalue { <8 x ptr>, <8 x i64> } %3099, 1
  %3102 = getelementptr i8, <8 x ptr> %3100, <8 x i64> %3101
  %3103 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3102, <8 x i1> %74, <8 x float> zeroinitializer)
  %.state537 = load i64, ptr %.slot, align 4
  %3104 = add i64 %.state537, 1
  %.spill.load538 = load <8 x float>, ptr %.spill139, align 32
  store i64 %3104, ptr %.slot, align 4
  %3105 = load <8 x float>, ptr %.slot37, align 32
  %3106 = select <8 x i1> %74, <8 x float> %.spill.load538, <8 x float> %3105
  store <8 x float> %3106, ptr %.slot37, align 32
  %3107 = load <8 x float>, ptr %.slot38, align 32
  %3108 = select <8 x i1> %74, <8 x float> %359, <8 x float> %3107
  store <8 x float> %3108, ptr %.slot38, align 32
  %3109 = load <8 x float>, ptr %.slot39, align 32
  %3110 = select <8 x i1> %74, <8 x float> %2536, <8 x float> %3109
  store <8 x float> %3110, ptr %.slot39, align 32
  %3111 = load <8 x float>, ptr %.slot40, align 32
  %3112 = select <8 x i1> %74, <8 x float> %2545, <8 x float> %3111
  store <8 x float> %3112, ptr %.slot40, align 32
  %3113 = load <8 x float>, ptr %.slot41, align 32
  %3114 = select <8 x i1> %74, <8 x float> %2554, <8 x float> %3113
  store <8 x float> %3114, ptr %.slot41, align 32
  %3115 = load <8 x float>, ptr %.slot42, align 32
  %3116 = select <8 x i1> %74, <8 x float> %2563, <8 x float> %3115
  store <8 x float> %3116, ptr %.slot42, align 32
  %3117 = load <8 x float>, ptr %.slot43, align 32
  %3118 = select <8 x i1> %74, <8 x float> %2572, <8 x float> %3117
  store <8 x float> %3118, ptr %.slot43, align 32
  %3119 = load <8 x float>, ptr %.slot44, align 32
  %3120 = select <8 x i1> %74, <8 x float> %2581, <8 x float> %3119
  store <8 x float> %3120, ptr %.slot44, align 32
  %3121 = load <8 x float>, ptr %.slot45, align 32
  %3122 = select <8 x i1> %74, <8 x float> %2590, <8 x float> %3121
  store <8 x float> %3122, ptr %.slot45, align 32
  %3123 = load <8 x float>, ptr %.slot46, align 32
  %3124 = select <8 x i1> %74, <8 x float> %2599, <8 x float> %3123
  store <8 x float> %3124, ptr %.slot46, align 32
  %3125 = load <8 x float>, ptr %.slot47, align 32
  %3126 = select <8 x i1> %74, <8 x float> %2608, <8 x float> %3125
  store <8 x float> %3126, ptr %.slot47, align 32
  %3127 = load <8 x float>, ptr %.slot48, align 32
  %3128 = select <8 x i1> %74, <8 x float> %2617, <8 x float> %3127
  store <8 x float> %3128, ptr %.slot48, align 32
  %3129 = load <8 x float>, ptr %.slot49, align 32
  %3130 = select <8 x i1> %74, <8 x float> %2626, <8 x float> %3129
  store <8 x float> %3130, ptr %.slot49, align 32
  %3131 = load <8 x float>, ptr %.slot50, align 32
  %3132 = select <8 x i1> %74, <8 x float> %2635, <8 x float> %3131
  store <8 x float> %3132, ptr %.slot50, align 32
  %3133 = load <8 x float>, ptr %.slot51, align 32
  %3134 = select <8 x i1> %74, <8 x float> %2644, <8 x float> %3133
  store <8 x float> %3134, ptr %.slot51, align 32
  %3135 = load <8 x float>, ptr %.slot52, align 32
  %3136 = select <8 x i1> %74, <8 x float> %2653, <8 x float> %3135
  store <8 x float> %3136, ptr %.slot52, align 32
  %3137 = load <8 x float>, ptr %.slot53, align 32
  %3138 = select <8 x i1> %74, <8 x float> %2662, <8 x float> %3137
  store <8 x float> %3138, ptr %.slot53, align 32
  %3139 = load <8 x float>, ptr %.slot54, align 32
  %3140 = select <8 x i1> %74, <8 x float> %2671, <8 x float> %3139
  store <8 x float> %3140, ptr %.slot54, align 32
  %3141 = load <8 x float>, ptr %.slot55, align 32
  %3142 = select <8 x i1> %74, <8 x float> %2680, <8 x float> %3141
  store <8 x float> %3142, ptr %.slot55, align 32
  %3143 = load <8 x float>, ptr %.slot56, align 32
  %3144 = select <8 x i1> %74, <8 x float> %2689, <8 x float> %3143
  store <8 x float> %3144, ptr %.slot56, align 32
  %3145 = load <8 x float>, ptr %.slot57, align 32
  %3146 = select <8 x i1> %74, <8 x float> %2698, <8 x float> %3145
  store <8 x float> %3146, ptr %.slot57, align 32
  %3147 = load <8 x float>, ptr %.slot58, align 32
  %3148 = select <8 x i1> %74, <8 x float> %2707, <8 x float> %3147
  store <8 x float> %3148, ptr %.slot58, align 32
  %3149 = load <8 x float>, ptr %.slot59, align 32
  %3150 = select <8 x i1> %74, <8 x float> %2716, <8 x float> %3149
  store <8 x float> %3150, ptr %.slot59, align 32
  %3151 = load <8 x float>, ptr %.slot60, align 32
  %3152 = select <8 x i1> %74, <8 x float> %2725, <8 x float> %3151
  store <8 x float> %3152, ptr %.slot60, align 32
  %3153 = load <8 x float>, ptr %.slot61, align 32
  %3154 = select <8 x i1> %74, <8 x float> %2734, <8 x float> %3153
  store <8 x float> %3154, ptr %.slot61, align 32
  %3155 = load <8 x float>, ptr %.slot62, align 32
  %3156 = select <8 x i1> %74, <8 x float> %2743, <8 x float> %3155
  store <8 x float> %3156, ptr %.slot62, align 32
  %3157 = load <8 x float>, ptr %.slot63, align 32
  %3158 = select <8 x i1> %74, <8 x float> %2752, <8 x float> %3157
  store <8 x float> %3158, ptr %.slot63, align 32
  %3159 = load <8 x float>, ptr %.slot64, align 32
  %3160 = select <8 x i1> %74, <8 x float> %2761, <8 x float> %3159
  store <8 x float> %3160, ptr %.slot64, align 32
  %3161 = load <8 x float>, ptr %.slot65, align 32
  %3162 = select <8 x i1> %74, <8 x float> %2770, <8 x float> %3161
  store <8 x float> %3162, ptr %.slot65, align 32
  %3163 = load <8 x float>, ptr %.slot66, align 32
  %3164 = select <8 x i1> %74, <8 x float> %2779, <8 x float> %3163
  store <8 x float> %3164, ptr %.slot66, align 32
  %3165 = load <8 x float>, ptr %.slot67, align 32
  %3166 = select <8 x i1> %74, <8 x float> %2788, <8 x float> %3165
  store <8 x float> %3166, ptr %.slot67, align 32
  %3167 = load <8 x float>, ptr %.slot68, align 32
  %3168 = select <8 x i1> %74, <8 x float> %2797, <8 x float> %3167
  store <8 x float> %3168, ptr %.slot68, align 32
  %3169 = load <8 x float>, ptr %.slot69, align 32
  %3170 = select <8 x i1> %74, <8 x float> %2806, <8 x float> %3169
  store <8 x float> %3170, ptr %.slot69, align 32
  %3171 = load <8 x float>, ptr %.slot70, align 32
  %3172 = select <8 x i1> %74, <8 x float> %2815, <8 x float> %3171
  store <8 x float> %3172, ptr %.slot70, align 32
  %3173 = load <8 x float>, ptr %.slot71, align 32
  %3174 = select <8 x i1> %74, <8 x float> %2824, <8 x float> %3173
  store <8 x float> %3174, ptr %.slot71, align 32
  %3175 = load <8 x float>, ptr %.slot72, align 32
  %3176 = select <8 x i1> %74, <8 x float> %2833, <8 x float> %3175
  store <8 x float> %3176, ptr %.slot72, align 32
  %3177 = load <8 x float>, ptr %.slot73, align 32
  %3178 = select <8 x i1> %74, <8 x float> %2842, <8 x float> %3177
  store <8 x float> %3178, ptr %.slot73, align 32
  %3179 = load <8 x float>, ptr %.slot74, align 32
  %3180 = select <8 x i1> %74, <8 x float> %2851, <8 x float> %3179
  store <8 x float> %3180, ptr %.slot74, align 32
  %3181 = load <8 x float>, ptr %.slot75, align 32
  %3182 = select <8 x i1> %74, <8 x float> %2860, <8 x float> %3181
  store <8 x float> %3182, ptr %.slot75, align 32
  %3183 = load <8 x float>, ptr %.slot76, align 32
  %3184 = select <8 x i1> %74, <8 x float> %2869, <8 x float> %3183
  store <8 x float> %3184, ptr %.slot76, align 32
  %3185 = load <8 x float>, ptr %.slot77, align 32
  %3186 = select <8 x i1> %74, <8 x float> %2878, <8 x float> %3185
  store <8 x float> %3186, ptr %.slot77, align 32
  %3187 = load <8 x float>, ptr %.slot78, align 32
  %3188 = select <8 x i1> %74, <8 x float> %2887, <8 x float> %3187
  store <8 x float> %3188, ptr %.slot78, align 32
  %3189 = load <8 x float>, ptr %.slot79, align 32
  %3190 = select <8 x i1> %74, <8 x float> %2896, <8 x float> %3189
  store <8 x float> %3190, ptr %.slot79, align 32
  %3191 = load <8 x float>, ptr %.slot80, align 32
  %3192 = select <8 x i1> %74, <8 x float> %2905, <8 x float> %3191
  store <8 x float> %3192, ptr %.slot80, align 32
  %3193 = load <8 x float>, ptr %.slot81, align 32
  %3194 = select <8 x i1> %74, <8 x float> %2914, <8 x float> %3193
  store <8 x float> %3194, ptr %.slot81, align 32
  %3195 = load <8 x float>, ptr %.slot82, align 32
  %3196 = select <8 x i1> %74, <8 x float> %2923, <8 x float> %3195
  store <8 x float> %3196, ptr %.slot82, align 32
  %3197 = load <8 x float>, ptr %.slot83, align 32
  %3198 = select <8 x i1> %74, <8 x float> %2932, <8 x float> %3197
  store <8 x float> %3198, ptr %.slot83, align 32
  %3199 = load <8 x float>, ptr %.slot84, align 32
  %3200 = select <8 x i1> %74, <8 x float> %2941, <8 x float> %3199
  store <8 x float> %3200, ptr %.slot84, align 32
  %3201 = load <8 x float>, ptr %.slot85, align 32
  %3202 = select <8 x i1> %74, <8 x float> %2950, <8 x float> %3201
  store <8 x float> %3202, ptr %.slot85, align 32
  %3203 = load <8 x float>, ptr %.slot86, align 32
  %3204 = select <8 x i1> %74, <8 x float> %2959, <8 x float> %3203
  store <8 x float> %3204, ptr %.slot86, align 32
  %3205 = load <8 x float>, ptr %.slot87, align 32
  %3206 = select <8 x i1> %74, <8 x float> %2968, <8 x float> %3205
  store <8 x float> %3206, ptr %.slot87, align 32
  %3207 = load <8 x float>, ptr %.slot88, align 32
  %3208 = select <8 x i1> %74, <8 x float> %2977, <8 x float> %3207
  store <8 x float> %3208, ptr %.slot88, align 32
  %3209 = load <8 x float>, ptr %.slot89, align 32
  %3210 = select <8 x i1> %74, <8 x float> %2986, <8 x float> %3209
  store <8 x float> %3210, ptr %.slot89, align 32
  %3211 = load <8 x float>, ptr %.slot90, align 32
  %3212 = select <8 x i1> %74, <8 x float> %2995, <8 x float> %3211
  store <8 x float> %3212, ptr %.slot90, align 32
  %3213 = load <8 x float>, ptr %.slot91, align 32
  %3214 = select <8 x i1> %74, <8 x float> %3004, <8 x float> %3213
  store <8 x float> %3214, ptr %.slot91, align 32
  %3215 = load <8 x float>, ptr %.slot92, align 32
  %3216 = select <8 x i1> %74, <8 x float> %3013, <8 x float> %3215
  store <8 x float> %3216, ptr %.slot92, align 32
  %3217 = load <8 x float>, ptr %.slot93, align 32
  %3218 = select <8 x i1> %74, <8 x float> %3022, <8 x float> %3217
  store <8 x float> %3218, ptr %.slot93, align 32
  %3219 = load <8 x float>, ptr %.slot94, align 32
  %3220 = select <8 x i1> %74, <8 x float> %3031, <8 x float> %3219
  store <8 x float> %3220, ptr %.slot94, align 32
  %3221 = load <8 x float>, ptr %.slot95, align 32
  %3222 = select <8 x i1> %74, <8 x float> %3040, <8 x float> %3221
  store <8 x float> %3222, ptr %.slot95, align 32
  %3223 = load <8 x float>, ptr %.slot96, align 32
  %3224 = select <8 x i1> %74, <8 x float> %3049, <8 x float> %3223
  store <8 x float> %3224, ptr %.slot96, align 32
  %3225 = load <8 x float>, ptr %.slot97, align 32
  %3226 = select <8 x i1> %74, <8 x float> %3058, <8 x float> %3225
  store <8 x float> %3226, ptr %.slot97, align 32
  %3227 = load <8 x float>, ptr %.slot98, align 32
  %3228 = select <8 x i1> %74, <8 x float> %3067, <8 x float> %3227
  store <8 x float> %3228, ptr %.slot98, align 32
  %3229 = load <8 x float>, ptr %.slot99, align 32
  %3230 = select <8 x i1> %74, <8 x float> %3076, <8 x float> %3229
  store <8 x float> %3230, ptr %.slot99, align 32
  %3231 = load <8 x float>, ptr %.slot100, align 32
  %3232 = select <8 x i1> %74, <8 x float> %3085, <8 x float> %3231
  store <8 x float> %3232, ptr %.slot100, align 32
  %3233 = load <8 x float>, ptr %.slot101, align 32
  %3234 = select <8 x i1> %74, <8 x float> %3094, <8 x float> %3233
  store <8 x float> %3234, ptr %.slot101, align 32
  %3235 = load <8 x float>, ptr %.slot102, align 32
  %3236 = select <8 x i1> %74, <8 x float> %3103, <8 x float> %3235
  store <8 x float> %3236, ptr %.slot102, align 32
  br label %direct.schedule.1
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nounwind willreturn
define private void @llm_attention.contiguous_copy(ptr %0, i64 %1, ptr %2) #1 {
entry:
  %3 = getelementptr i32, ptr %0, i64 %1
  br label %copy.loop

copy.loop:                                        ; preds = %copy.chunk, %entry
  %copy.index = phi i64 [ 0, %entry ], [ %10, %copy.chunk ]
  %4 = icmp ult i64 %copy.index, 16
  br i1 %4, label %copy.chunk, label %copy.next

copy.chunk:                                       ; preds = %copy.loop
  %5 = mul i64 %copy.index, 4
  %6 = add i64 0, %5
  %7 = getelementptr i32, ptr %3, i64 %6
  %8 = load <4 x i32>, ptr %7, align 4
  %9 = getelementptr i32, ptr %2, i64 %6
  store <4 x i32> %8, ptr %9, align 4
  %10 = add i64 %copy.index, 1
  br label %copy.loop

copy.next:                                        ; preds = %copy.loop
  ret void
}

; Function Attrs: nounwind willreturn
define private void @llm_attention.contiguous_copy.1(ptr %0, i64 %1, ptr %2) #1 {
entry:
  %3 = getelementptr i32, ptr %0, i64 %1
  br label %copy.loop

copy.loop:                                        ; preds = %copy.chunk, %entry
  %copy.index = phi i64 [ 0, %entry ], [ %10, %copy.chunk ]
  %4 = icmp ult i64 %copy.index, 256
  br i1 %4, label %copy.chunk, label %copy.next

copy.chunk:                                       ; preds = %copy.loop
  %5 = mul i64 %copy.index, 4
  %6 = add i64 0, %5
  %7 = getelementptr i32, ptr %3, i64 %6
  %8 = load <4 x i32>, ptr %7, align 4
  %9 = getelementptr i32, ptr %2, i64 %6
  store <4 x i32> %8, ptr %9, align 4
  %10 = add i64 %copy.index, 1
  br label %copy.loop

copy.next:                                        ; preds = %copy.loop
  ret void
}

; Function Attrs: nounwind willreturn
define private void @llm_attention.contiguous_copy.2(ptr %0, i64 %1, ptr %2) #1 {
entry:
  %3 = getelementptr i32, ptr %0, i64 %1
  br label %copy.loop

copy.loop:                                        ; preds = %copy.chunk, %entry
  %copy.index = phi i64 [ 0, %entry ], [ %10, %copy.chunk ]
  %4 = icmp ult i64 %copy.index, 256
  br i1 %4, label %copy.chunk, label %copy.next

copy.chunk:                                       ; preds = %copy.loop
  %5 = mul i64 %copy.index, 4
  %6 = add i64 0, %5
  %7 = getelementptr i32, ptr %3, i64 %6
  %8 = load <4 x i32>, ptr %7, align 4
  %9 = getelementptr i32, ptr %2, i64 %6
  store <4 x i32> %8, ptr %9, align 4
  %10 = add i64 %copy.index, 1
  br label %copy.loop

copy.next:                                        ; preds = %copy.loop
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #2

; Function Attrs: nounwind willreturn
define private void @llm_attention.strided_mma(ptr %0, ptr %1, ptr %2, ptr %3) #3 {
entry:
  br label %mma.fold

mma.fold:                                         ; preds = %mma.fold.done3, %entry
  %mma.k = phi i64 [ 0, %entry ], [ %39, %mma.fold.done3 ]
  %mma.acc = phi i64 [ 0, %entry ], [ %mma.acc, %mma.fold.done3 ]
  %4 = icmp ult i64 %mma.k, 16
  br i1 %4, label %mma.update, label %mma.fold.done

mma.update:                                       ; preds = %mma.fold
  %5 = urem i64 %mma.k, 16
  %6 = udiv i64 %mma.k, 16
  %7 = urem i64 %mma.k, 16
  %8 = mul i64 %7, 64
  %9 = add i64 0, %8
  %10 = udiv i64 %mma.k, 16
  %11 = getelementptr float, ptr %2, i64 %mma.k
  %12 = load float, ptr %11, align 4
  %13 = getelementptr float, ptr %0, i64 0
  %14 = load <4 x float>, ptr %13, align 4
  %15 = getelementptr float, ptr %1, i64 %9
  %16 = load <4 x float>, ptr %15, align 4
  %17 = fmul <4 x float> %14, %16
  br label %mma.fold1

mma.fold.done:                                    ; preds = %mma.fold
  ret void

mma.fold1:                                        ; preds = %mma.update2, %mma.update
  %mma.k4 = phi i64 [ 0, %mma.update ], [ %29, %mma.update2 ]
  %mma.acc5 = phi <4 x float> [ %17, %mma.update ], [ %28, %mma.update2 ]
  %18 = icmp ult i64 %mma.k4, 15
  br i1 %18, label %mma.update2, label %mma.fold.done3

mma.update2:                                      ; preds = %mma.fold1
  %19 = add i64 %mma.k4, 1
  %20 = mul i64 %19, 4
  %21 = add i64 0, %20
  %22 = getelementptr float, ptr %0, i64 %21
  %23 = load <4 x float>, ptr %22, align 4
  %24 = add i64 %9, %20
  %25 = getelementptr float, ptr %1, i64 %24
  %26 = load <4 x float>, ptr %25, align 4
  %27 = fmul <4 x float> %23, %26
  %28 = fadd <4 x float> %mma.acc5, %27
  %29 = add i64 %mma.k4, 1
  br label %mma.fold1

mma.fold.done3:                                   ; preds = %mma.fold1
  %30 = extractelement <4 x float> %mma.acc5, i64 0
  %31 = extractelement <4 x float> %mma.acc5, i64 1
  %32 = extractelement <4 x float> %mma.acc5, i64 2
  %33 = extractelement <4 x float> %mma.acc5, i64 3
  %34 = fadd float %30, %31
  %35 = fadd float %32, %33
  %36 = fadd float %34, %35
  %37 = fadd float %12, %36
  %38 = getelementptr float, ptr %3, i64 %mma.k
  store float %37, ptr %38, align 4
  %39 = add i64 %mma.k, 1
  br label %mma.fold
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #4

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #5

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #6 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nounwind willreturn
define private void @llm_attention.strided_mma.3(ptr %0, ptr %1, ptr %2, ptr %3) #3 {
entry:
  br label %mma.fold

mma.fold:                                         ; preds = %mma.fold.done3, %entry
  %mma.k = phi i64 [ 0, %entry ], [ %17, %mma.fold.done3 ]
  %mma.acc = phi i64 [ 0, %entry ], [ %mma.acc, %mma.fold.done3 ]
  %4 = icmp ult i64 %mma.k, 1
  br i1 %4, label %mma.update, label %mma.fold.done

mma.update:                                       ; preds = %mma.fold
  %5 = mul i64 %mma.k, 64
  br label %mma.fold1

mma.fold.done:                                    ; preds = %mma.fold
  ret void

mma.fold1:                                        ; preds = %mma.fold.done8, %mma.update
  %mma.k4 = phi i64 [ 0, %mma.update ], [ %31, %mma.fold.done8 ]
  %mma.acc5 = phi i64 [ 0, %mma.update ], [ %mma.acc5, %mma.fold.done8 ]
  %6 = icmp ult i64 %mma.k4, 16
  br i1 %6, label %mma.update2, label %mma.fold.done3

mma.update2:                                      ; preds = %mma.fold1
  %7 = mul i64 %mma.k4, 4
  %8 = add i64 %5, %7
  %9 = urem i64 %8, 64
  %10 = udiv i64 %8, 64
  %11 = urem i64 %8, 64
  %12 = mul i64 %11, 1
  %13 = add i64 0, %12
  %14 = udiv i64 %8, 64
  %15 = getelementptr float, ptr %2, i64 %8
  %16 = load <4 x float>, ptr %15, align 4
  br label %mma.fold6

mma.fold.done3:                                   ; preds = %mma.fold1
  %17 = add i64 %mma.k, 1
  br label %mma.fold

mma.fold6:                                        ; preds = %mma.update7, %mma.update2
  %mma.k9 = phi i64 [ 0, %mma.update2 ], [ %29, %mma.update7 ]
  %mma.acc10 = phi <4 x float> [ %16, %mma.update2 ], [ %28, %mma.update7 ]
  %18 = icmp ult i64 %mma.k9, 16
  br i1 %18, label %mma.update7, label %mma.fold.done8

mma.update7:                                      ; preds = %mma.fold6
  %19 = mul i64 %mma.k9, 1
  %20 = add i64 0, %19
  %21 = getelementptr float, ptr %0, i64 %20
  %22 = load float, ptr %21, align 4
  %.splatinsert = insertelement <4 x float> poison, float %22, i64 0
  %.splat = shufflevector <4 x float> %.splatinsert, <4 x float> poison, <4 x i32> zeroinitializer
  %23 = mul i64 %mma.k9, 64
  %24 = add i64 %13, %23
  %25 = getelementptr float, ptr %1, i64 %24
  %26 = load <4 x float>, ptr %25, align 4
  %27 = fmul <4 x float> %.splat, %26
  %28 = fadd <4 x float> %mma.acc10, %27
  %29 = add i64 %mma.k9, 1
  br label %mma.fold6

mma.fold.done8:                                   ; preds = %mma.fold6
  %30 = getelementptr float, ptr %3, i64 %8
  store <4 x float> %mma.acc10, ptr %30, align 4
  %31 = add i64 %mma.k4, 1
  br label %mma.fold1
}

define internal void @llm_attention.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_attention.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_attention.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nounwind willreturn }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #3 = { nounwind willreturn "fp-contract"="off" }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #5 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #6 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }

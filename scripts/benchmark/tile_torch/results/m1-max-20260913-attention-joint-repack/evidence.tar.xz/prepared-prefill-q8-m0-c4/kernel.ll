; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_attention(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 8192
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 20480
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 32768
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 49152
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 73728
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 77824
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 16, i64 32, i64 48, i64 64, i64 80, i64 96, i64 112>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 77952
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %24 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace29 = load ptr, ptr %24, align 8
  %tile_snapshot.private30 = getelementptr inbounds i8, ptr %private.workspace29, i64 78976
  %.splatinsert31 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private30, i64 0
  %.splat32 = shufflevector <8 x ptr> %.splatinsert31, <8 x ptr> poison, <8 x i32> zeroinitializer
  %25 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat32, 0
  %26 = insertvalue { <8 x ptr>, <8 x i64> } %25, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %27 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace33 = load ptr, ptr %27, align 8
  %tile_snapshot.private34 = getelementptr inbounds i8, ptr %private.workspace33, i64 79488
  %.splatinsert35 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private34, i64 0
  %.splat36 = shufflevector <8 x ptr> %.splatinsert35, <8 x ptr> poison, <8 x i32> zeroinitializer
  %28 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat36, 0
  %29 = insertvalue { <8 x ptr>, <8 x i64> } %28, <8 x i64> <i64 0, i64 128, i64 256, i64 384, i64 512, i64 640, i64 768, i64 896>, 1
  %30 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace37 = load ptr, ptr %30, align 8
  %tile_snapshot.private38 = getelementptr inbounds i8, ptr %private.workspace37, i64 80512
  %.splatinsert39 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private38, i64 0
  %.splat40 = shufflevector <8 x ptr> %.splatinsert39, <8 x ptr> poison, <8 x i32> zeroinitializer
  %31 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat40, 0
  %32 = insertvalue { <8 x ptr>, <8 x i64> } %31, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %33 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace41 = load ptr, ptr %33, align 8
  %tile_snapshot.private42 = getelementptr inbounds i8, ptr %private.workspace41, i64 84608
  %.splatinsert43 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private42, i64 0
  %.splat44 = shufflevector <8 x ptr> %.splatinsert43, <8 x ptr> poison, <8 x i32> zeroinitializer
  %34 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat44, 0
  %35 = insertvalue { <8 x ptr>, <8 x i64> } %34, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %36 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace45 = load ptr, ptr %36, align 8
  %tile_snapshot.private46 = getelementptr inbounds i8, ptr %private.workspace45, i64 84864
  %.splatinsert47 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private46, i64 0
  %.splat48 = shufflevector <8 x ptr> %.splatinsert47, <8 x ptr> poison, <8 x i32> zeroinitializer
  %37 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat48, 0
  %38 = insertvalue { <8 x ptr>, <8 x i64> } %37, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %39 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace49 = load ptr, ptr %39, align 8
  %tile_snapshot.private50 = getelementptr inbounds i8, ptr %private.workspace49, i64 85120
  %.splatinsert51 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private50, i64 0
  %.splat52 = shufflevector <8 x ptr> %.splatinsert51, <8 x ptr> poison, <8 x i32> zeroinitializer
  %40 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat52, 0
  %41 = insertvalue { <8 x ptr>, <8 x i64> } %40, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %42 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace53 = load ptr, ptr %42, align 8
  %tile_snapshot.private54 = getelementptr inbounds i8, ptr %private.workspace53, i64 89216
  %.splatinsert55 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private54, i64 0
  %.splat56 = shufflevector <8 x ptr> %.splatinsert55, <8 x ptr> poison, <8 x i32> zeroinitializer
  %43 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat56, 0
  %44 = insertvalue { <8 x ptr>, <8 x i64> } %43, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %45 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace57 = load ptr, ptr %45, align 8
  %tile_snapshot.private58 = getelementptr inbounds i8, ptr %private.workspace57, i64 101504
  %.splatinsert59 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private58, i64 0
  %.splat60 = shufflevector <8 x ptr> %.splatinsert59, <8 x ptr> poison, <8 x i32> zeroinitializer
  %46 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat60, 0
  %47 = insertvalue { <8 x ptr>, <8 x i64> } %46, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill61 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill61, align 64
  %.spill62 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill62, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.spill63 = alloca i64, align 8
  store i64 0, ptr %.spill63, align 4
  %.spill64 = alloca i64, align 8
  store i64 0, ptr %.spill64, align 4
  %tile_snapshot.spill65 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill65, align 64
  %tile_snapshot.spill66 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill66, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.slot67 = alloca i64, align 8
  store i64 0, ptr %.slot67, align 4
  %.slot68 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot68, align 32
  %.slot69 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot69, align 32
  %.slot70 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot70, align 32
  %.slot71 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot71, align 32
  %.slot72 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot72, align 32
  %.slot73 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot73, align 32
  %.slot74 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot74, align 32
  %.slot75 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot75, align 32
  %.slot76 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot76, align 32
  %.slot77 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot77, align 32
  %.slot78 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot78, align 32
  %.slot79 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot79, align 32
  %.slot80 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot80, align 32
  %.slot81 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot81, align 32
  %.slot82 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot82, align 32
  %.slot83 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot83, align 32
  %.spill84 = alloca i64, align 8
  store i64 0, ptr %.spill84, align 4
  %tile_snapshot.spill85 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill85, align 64
  %.spill86 = alloca i1, align 1
  store i1 false, ptr %.spill86, align 1
  %tile_snapshot.spill87 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill87, align 64
  %tile_snapshot.spill88 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill88, align 64
  %.slot89 = alloca i64, align 8
  store i64 0, ptr %.slot89, align 4
  %.spill90 = alloca i64, align 8
  store i64 0, ptr %.spill90, align 4
  %.slot91 = alloca i64, align 8
  store i64 0, ptr %.slot91, align 4
  %tile_snapshot.spill92 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill92, align 64
  %tile_snapshot.spill93 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill93, align 64
  %tile_snapshot.spill94 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill94, align 64
  %tile_snapshot.spill95 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill95, align 64
  %.slot96 = alloca i64, align 8
  store i64 0, ptr %.slot96, align 4
  %tile_snapshot.spill97 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill97, align 64
  %.slot98 = alloca i64, align 8
  store i64 0, ptr %.slot98, align 4
  %.slot99 = alloca i64, align 8
  store i64 0, ptr %.slot99, align 4
  %.slot100 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot100, align 32
  %.slot101 = alloca i64, align 8
  store i64 0, ptr %.slot101, align 4
  %.slot102 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot102, align 32
  %.slot103 = alloca i64, align 8
  store i64 0, ptr %.slot103, align 4
  %.slot104 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot104, align 32
  %.slot105 = alloca i64, align 8
  store i64 0, ptr %.slot105, align 4
  %.slot106 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot106, align 32
  %.slot107 = alloca i64, align 8
  store i64 0, ptr %.slot107, align 4
  %.slot108 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot108, align 32
  %.slot109 = alloca i64, align 8
  store i64 0, ptr %.slot109, align 4
  %.slot110 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot110, align 32
  %.slot111 = alloca i64, align 8
  store i64 0, ptr %.slot111, align 4
  %.slot112 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot112, align 32
  %.slot113 = alloca i64, align 8
  store i64 0, ptr %.slot113, align 4
  %.slot114 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot114, align 32
  %.spill115 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill115, align 32
  %.spill116 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill116, align 32
  %.spill117 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill117, align 32
  %.spill118 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill118, align 32
  %.spill119 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill119, align 32
  %.spill120 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill120, align 32
  %.spill121 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill121, align 32
  %.spill122 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill122, align 32
  %tile_snapshot.spill123 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill123, align 64
  %.spill124 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill124, align 32
  %.spill125 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill125, align 32
  %.spill126 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill126, align 32
  %.spill127 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill127, align 32
  %.spill128 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill128, align 32
  %.spill129 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill129, align 32
  %.spill130 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill130, align 32
  %.spill131 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill131, align 32
  %tile_snapshot.spill132 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill132, align 64
  %tile_snapshot.spill133 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill133, align 64
  %.slot134 = alloca i64, align 8
  store i64 0, ptr %.slot134, align 4
  %.spill135 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill135, align 32
  %.spill136 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill136, align 32
  %.spill137 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill137, align 32
  %.spill138 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill138, align 32
  %.spill139 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill139, align 32
  %.spill140 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill140, align 32
  %.spill141 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill141, align 32
  %.spill142 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill142, align 32
  %.slot143 = alloca i64, align 8
  store i64 0, ptr %.slot143, align 4
  %.slot144 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot144, align 32
  %.slot145 = alloca i64, align 8
  store i64 0, ptr %.slot145, align 4
  %.slot146 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot146, align 32
  %.slot147 = alloca i64, align 8
  store i64 0, ptr %.slot147, align 4
  %.slot148 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot148, align 32
  %.slot149 = alloca i64, align 8
  store i64 0, ptr %.slot149, align 4
  %.slot150 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot150, align 32
  %.slot151 = alloca i64, align 8
  store i64 0, ptr %.slot151, align 4
  %.slot152 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot152, align 32
  %.slot153 = alloca i64, align 8
  store i64 0, ptr %.slot153, align 4
  %.slot154 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot154, align 32
  %.slot155 = alloca i64, align 8
  store i64 0, ptr %.slot155, align 4
  %.slot156 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot156, align 32
  %.slot157 = alloca i64, align 8
  store i64 0, ptr %.slot157, align 4
  %.slot158 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot158, align 32
  %.spill159 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill159, align 32
  %.spill160 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill160, align 32
  %.spill161 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill161, align 32
  %.spill162 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill162, align 32
  %.spill163 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill163, align 32
  %.spill164 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill164, align 32
  %.spill165 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill165, align 32
  %.spill166 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill166, align 32
  %tile_snapshot.spill167 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill167, align 64
  %.slot168 = alloca i64, align 8
  store i64 0, ptr %.slot168, align 4
  %.spill169 = alloca i64, align 8
  store i64 0, ptr %.spill169, align 4
  %.slot170 = alloca i64, align 8
  store i64 0, ptr %.slot170, align 4
  %.slot171 = alloca i64, align 8
  store i64 0, ptr %.slot171, align 4
  %.slot172 = alloca i64, align 8
  store i64 0, ptr %.slot172, align 4
  %.slot173 = alloca i64, align 8
  store i64 0, ptr %.slot173, align 4
  %.spill174 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill174, align 64
  %.slot175 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot175, align 32
  %.slot176 = alloca i64, align 8
  store i64 0, ptr %.slot176, align 4
  %.spill177 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill177, align 64
  %.slot178 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot178, align 32
  %tile_snapshot.spill179 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill179, align 64
  %.slot180 = alloca i64, align 8
  store i64 0, ptr %.slot180, align 4
  %48 = getelementptr i8, ptr %argument_buffer, i64 0
  %49 = load ptr, ptr %48, align 16
  %50 = getelementptr i8, ptr %48, i64 8
  %51 = load i64, ptr %50, align 8
  %52 = insertvalue { ptr, i64 } poison, ptr %49, 0
  %53 = insertvalue { ptr, i64 } %52, i64 %51, 1
  %54 = getelementptr i8, ptr %argument_buffer, i64 16
  %55 = load ptr, ptr %54, align 16
  %56 = getelementptr i8, ptr %54, i64 8
  %57 = load i64, ptr %56, align 8
  %58 = insertvalue { ptr, i64 } poison, ptr %55, 0
  %59 = insertvalue { ptr, i64 } %58, i64 %57, 1
  %60 = getelementptr i8, ptr %argument_buffer, i64 32
  %61 = load ptr, ptr %60, align 16
  %62 = getelementptr i8, ptr %60, i64 8
  %63 = load i64, ptr %62, align 8
  %64 = insertvalue { ptr, i64 } poison, ptr %61, 0
  %65 = insertvalue { ptr, i64 } %64, i64 %63, 1
  %66 = getelementptr i8, ptr %argument_buffer, i64 48
  %67 = load ptr, ptr %66, align 16
  %68 = getelementptr i8, ptr %66, i64 8
  %69 = load i64, ptr %68, align 8
  %70 = insertvalue { ptr, i64 } poison, ptr %67, 0
  %71 = insertvalue { ptr, i64 } %70, i64 %69, 1
  %72 = load i32, ptr %launch_config, align 4
  %73 = getelementptr i8, ptr %launch_config, i64 12
  %74 = load i32, ptr %73, align 4
  %75 = getelementptr i8, ptr %launch_config, i64 4
  %76 = load i32, ptr %75, align 4
  %77 = getelementptr i8, ptr %launch_config, i64 16
  %78 = load i32, ptr %77, align 4
  %79 = getelementptr i8, ptr %launch_config, i64 8
  %80 = load i32, ptr %79, align 4
  %81 = getelementptr i8, ptr %launch_config, i64 20
  %82 = load i32, ptr %81, align 4
  %83 = getelementptr i8, ptr %launch_config, i64 36
  %84 = load i32, ptr %83, align 4
  %.splatinsert181 = insertelement <8 x i32> poison, i32 %84, i64 0
  %.splat182 = shufflevector <8 x i32> %.splatinsert181, <8 x i32> poison, <8 x i32> zeroinitializer
  %85 = add <8 x i32> %.splat182, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %86 = mul i32 %72, 32
  %.splatinsert183 = insertelement <8 x i32> poison, i32 %86, i64 0
  %.splat184 = shufflevector <8 x i32> %.splatinsert183, <8 x i32> poison, <8 x i32> zeroinitializer
  %87 = add <8 x i32> %.splat184, %85
  %88 = mul i32 %76, 1
  %.splatinsert185 = insertelement <8 x i32> poison, i32 %88, i64 0
  %.splat186 = shufflevector <8 x i32> %.splatinsert185, <8 x i32> poison, <8 x i32> zeroinitializer
  %89 = add <8 x i32> %.splat186, zeroinitializer
  %90 = mul i32 %80, 1
  %.splatinsert187 = insertelement <8 x i32> poison, i32 %90, i64 0
  %.splat188 = shufflevector <8 x i32> %.splatinsert187, <8 x i32> poison, <8 x i32> zeroinitializer
  %91 = add <8 x i32> %.splat188, zeroinitializer
  %92 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %87, 0
  %93 = insertvalue [3 x <8 x i32>] %92, <8 x i32> %89, 1
  %94 = insertvalue [3 x <8 x i32>] %93, <8 x i32> %91, 2
  %.splatinsert189 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat190 = shufflevector <8 x i32> %.splatinsert189, <8 x i32> poison, <8 x i32> zeroinitializer
  %95 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat190
  %96 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  br i1 %96, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %97 = extractvalue [3 x <8 x i32>] %94, 0
  %98 = zext <8 x i32> %97 to <8 x i64>
  %99 = select <8 x i1> %95, <8 x i64> %98, <8 x i64> zeroinitializer
  %100 = select <8 x i1> %95, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %101 = sdiv <8 x i64> %99, %100
  %102 = load <8 x i64>, ptr %.spill, align 64
  %103 = select <8 x i1> %95, <8 x i64> %101, <8 x i64> %102
  store <8 x i64> %103, ptr %.spill, align 64
  %104 = select <8 x i1> %95, <8 x i64> %98, <8 x i64> zeroinitializer
  %105 = select <8 x i1> %95, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %106 = sdiv <8 x i64> %104, %105
  %107 = select <8 x i1> %95, <8 x i64> %106, <8 x i64> zeroinitializer
  %108 = select <8 x i1> %95, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %109 = srem <8 x i64> %107, %108
  %110 = mul <8 x i64> %109, splat (i64 8)
  %111 = load <8 x i64>, ptr %.spill61, align 64
  %112 = select <8 x i1> %95, <8 x i64> %110, <8 x i64> %111
  store <8 x i64> %112, ptr %.spill61, align 64
  %113 = select <8 x i1> %95, <8 x i64> %101, <8 x i64> zeroinitializer
  %114 = select <8 x i1> %95, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %115 = sdiv <8 x i64> %113, %114
  %116 = load <8 x i64>, ptr %.spill62, align 64
  %117 = select <8 x i1> %95, <8 x i64> %115, <8 x i64> %116
  store <8 x i64> %117, ptr %.spill62, align 64
  %118 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %119 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %120 = extractvalue { <8 x ptr>, <8 x i64> } %118, 0
  %121 = select <8 x i1> %95, <8 x ptr> %119, <8 x ptr> %120
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %123 = extractvalue { <8 x ptr>, <8 x i64> } %118, 1
  %124 = select <8 x i1> %95, <8 x i64> %122, <8 x i64> %123
  %125 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %121, 0
  %126 = insertvalue { <8 x ptr>, <8 x i64> } %125, <8 x i64> %124, 1
  store { <8 x ptr>, <8 x i64> } %126, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.spill63, align 4
  store i64 0, ptr %.spill64, align 4
  %127 = add <8 x i64> zeroinitializer, %101
  %128 = mul <8 x i64> %127, splat (i64 64)
  %129 = add <8 x i64> %128, %110
  %130 = mul <8 x i64> %129, splat (i64 32)
  %131 = add <8 x i64> %130, zeroinitializer
  %132 = extractvalue { ptr, i64 } %53, 0
  %133 = extractelement <8 x i1> %95, i64 0
  br i1 %133, label %copy.active, label %copy.continue

direct.schedule.1:                                ; preds = %direct.schedule.2, %copy.continue204
  %.state = load i64, ptr %.slot, align 4
  %134 = icmp slt i64 %.state, 384
  br i1 %134, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %135 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %136 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state205 = load i64, ptr %.slot, align 4
  %.splatinsert206 = insertelement <8 x i64> poison, i64 %.state205, i64 0
  %.splat207 = shufflevector <8 x i64> %.splatinsert206, <8 x i64> poison, <8 x i32> zeroinitializer
  %137 = mul <8 x i64> %.splat207, splat (i64 32)
  %138 = add <8 x i64> %136, %137
  %139 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %135, 0
  %140 = insertvalue { <8 x ptr>, <8 x i64> } %139, <8 x i64> %138, 1
  %141 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %140, 1
  %143 = extractelement <8 x ptr> %141, i32 0
  %144 = extractelement <8 x i64> %142, i32 0
  %145 = sub i64 %144, 0
  %146 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %147 = select i1 %146, i64 %145, i64 0
  %private.contiguous.address = getelementptr i8, ptr %143, i64 %147
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %148 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %private.contiguous.preserve
  store <8 x float> %148, ptr %private.contiguous.address, align 4
  %.state208 = load i64, ptr %.slot, align 4
  %149 = add i64 %.state208, 1
  store i64 %149, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store i64 0, ptr %.slot67, align 4
  %150 = load <8 x float>, ptr %.slot68, align 32
  %151 = select <8 x i1> %95, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %150
  store <8 x float> %151, ptr %.slot68, align 32
  %152 = load <8 x float>, ptr %.slot69, align 32
  %153 = select <8 x i1> %95, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %152
  store <8 x float> %153, ptr %.slot69, align 32
  %154 = load <8 x float>, ptr %.slot70, align 32
  %155 = select <8 x i1> %95, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %154
  store <8 x float> %155, ptr %.slot70, align 32
  %156 = load <8 x float>, ptr %.slot71, align 32
  %157 = select <8 x i1> %95, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %156
  store <8 x float> %157, ptr %.slot71, align 32
  %158 = load <8 x float>, ptr %.slot72, align 32
  %159 = select <8 x i1> %95, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %158
  store <8 x float> %159, ptr %.slot72, align 32
  %160 = load <8 x float>, ptr %.slot73, align 32
  %161 = select <8 x i1> %95, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %160
  store <8 x float> %161, ptr %.slot73, align 32
  %162 = load <8 x float>, ptr %.slot74, align 32
  %163 = select <8 x i1> %95, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %162
  store <8 x float> %163, ptr %.slot74, align 32
  %164 = load <8 x float>, ptr %.slot75, align 32
  %165 = select <8 x i1> %95, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %164
  store <8 x float> %165, ptr %.slot75, align 32
  %166 = load <8 x float>, ptr %.slot76, align 32
  %167 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %166
  store <8 x float> %167, ptr %.slot76, align 32
  %168 = load <8 x float>, ptr %.slot77, align 32
  %169 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %168
  store <8 x float> %169, ptr %.slot77, align 32
  %170 = load <8 x float>, ptr %.slot78, align 32
  %171 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %170
  store <8 x float> %171, ptr %.slot78, align 32
  %172 = load <8 x float>, ptr %.slot79, align 32
  %173 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %172
  store <8 x float> %173, ptr %.slot79, align 32
  %174 = load <8 x float>, ptr %.slot80, align 32
  %175 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %174
  store <8 x float> %175, ptr %.slot80, align 32
  %176 = load <8 x float>, ptr %.slot81, align 32
  %177 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %176
  store <8 x float> %177, ptr %.slot81, align 32
  %178 = load <8 x float>, ptr %.slot82, align 32
  %179 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %178
  store <8 x float> %179, ptr %.slot82, align 32
  %180 = load <8 x float>, ptr %.slot83, align 32
  %181 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %180
  store <8 x float> %181, ptr %.slot83, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.84, %direct.schedule.3
  %.state209 = load i64, ptr %.slot67, align 4
  %182 = icmp slt i64 %.state209, 9
  br i1 %182, label %direct.true210, label %direct.false211

direct.schedule.5:                                ; preds = %direct.true210
  %.state212 = load i64, ptr %.slot67, align 4
  %183 = sdiv i64 %.state212, 1
  %184 = mul i64 %183, 16
  store i64 %184, ptr %.spill84, align 4
  %185 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %186 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %185, 0
  %188 = select <8 x i1> %95, <8 x ptr> %186, <8 x ptr> %187
  %189 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %190 = extractvalue { <8 x ptr>, <8 x i64> } %185, 1
  %191 = select <8 x i1> %95, <8 x i64> %189, <8 x i64> %190
  %192 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %188, 0
  %193 = insertvalue { <8 x ptr>, <8 x i64> } %192, <8 x i64> %191, 1
  store { <8 x ptr>, <8 x i64> } %193, ptr %tile_snapshot.spill85, align 64
  %194 = icmp sge i64 %184, 0
  %195 = and i1 true, %194
  %196 = icmp sle i64 %184, 113
  %197 = and i1 %195, %196
  store i1 %197, ptr %.spill86, align 1
  br i1 %197, label %direct.true213, label %direct.false214

direct.schedule.6:                                ; preds = %direct.true213
  %.spill.load = load i64, ptr %.spill64, align 4
  %198 = mul i64 %.spill.load, 2
  %.splatinsert215 = insertelement <8 x i64> poison, i64 %198, i64 0
  %.splat216 = shufflevector <8 x i64> %.splatinsert215, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load217 = load <8 x i64>, ptr %.spill62, align 64
  %199 = add <8 x i64> %.splat216, %.spill.load217
  %200 = mul <8 x i64> %199, splat (i64 129)
  %.spill.load218 = load i64, ptr %.spill84, align 4
  %.splatinsert219 = insertelement <8 x i64> poison, i64 %.spill.load218, i64 0
  %.splat220 = shufflevector <8 x i64> %.splatinsert219, <8 x i64> poison, <8 x i32> zeroinitializer
  %201 = add <8 x i64> %200, %.splat220
  %202 = mul <8 x i64> %201, splat (i64 32)
  %203 = add <8 x i64> %202, zeroinitializer
  %tile_snapshot.spill.load221 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %204 = extractvalue { ptr, i64 } %59, 0
  %205 = extractelement <8 x i1> %95, i64 0
  br i1 %205, label %copy.active222, label %copy.continue223

direct.schedule.7:                                ; preds = %direct.false1896, %copy.continue237
  %206 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %207 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %206, 0
  %209 = select <8 x i1> %95, <8 x ptr> %207, <8 x ptr> %208
  %210 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %211 = extractvalue { <8 x ptr>, <8 x i64> } %206, 1
  %212 = select <8 x i1> %95, <8 x i64> %210, <8 x i64> %211
  %213 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %209, 0
  %214 = insertvalue { <8 x ptr>, <8 x i64> } %213, <8 x i64> %212, 1
  store { <8 x ptr>, <8 x i64> } %214, ptr %tile_snapshot.spill87, align 64
  %.spill.load238 = load i1, ptr %.spill86, align 1
  br i1 %.spill.load238, label %direct.true239, label %direct.false240

direct.schedule.8:                                ; preds = %direct.true239
  %.spill.load241 = load i64, ptr %.spill64, align 4
  %215 = mul i64 %.spill.load241, 2
  %.splatinsert242 = insertelement <8 x i64> poison, i64 %215, i64 0
  %.splat243 = shufflevector <8 x i64> %.splatinsert242, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load244 = load <8 x i64>, ptr %.spill62, align 64
  %216 = add <8 x i64> %.splat243, %.spill.load244
  %217 = mul <8 x i64> %216, splat (i64 129)
  %.spill.load245 = load i64, ptr %.spill84, align 4
  %.splatinsert246 = insertelement <8 x i64> poison, i64 %.spill.load245, i64 0
  %.splat247 = shufflevector <8 x i64> %.splatinsert246, <8 x i64> poison, <8 x i32> zeroinitializer
  %218 = add <8 x i64> %217, %.splat247
  %219 = mul <8 x i64> %218, splat (i64 48)
  %220 = add <8 x i64> %219, zeroinitializer
  %tile_snapshot.spill.load248 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %221 = extractvalue { ptr, i64 } %65, 0
  %222 = extractelement <8 x i1> %95, i64 0
  br i1 %222, label %copy.active249, label %copy.continue250

direct.schedule.9:                                ; preds = %direct.false1869, %copy.continue264
  %223 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill88, align 64
  %224 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %225 = extractvalue { <8 x ptr>, <8 x i64> } %223, 0
  %226 = select <8 x i1> %95, <8 x ptr> %224, <8 x ptr> %225
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %223, 1
  %229 = select <8 x i1> %95, <8 x i64> %227, <8 x i64> %228
  %230 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %226, 0
  %231 = insertvalue { <8 x ptr>, <8 x i64> } %230, <8 x i64> %229, 1
  store { <8 x ptr>, <8 x i64> } %231, ptr %tile_snapshot.spill88, align 64
  store i64 0, ptr %.slot89, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.14, %direct.schedule.9
  %.state265 = load i64, ptr %.slot89, align 4
  %232 = icmp slt i64 %.state265, 4
  br i1 %232, label %direct.true266, label %direct.false267

direct.schedule.11:                               ; preds = %direct.true266
  %.state268 = load i64, ptr %.slot89, align 4
  %233 = mul i64 %.state268, 2
  store i64 %233, ptr %.spill90, align 4
  store i64 0, ptr %.slot91, align 4
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.schedule.13, %direct.schedule.11
  %.state269 = load i64, ptr %.slot91, align 4
  %234 = icmp slt i64 %.state269, 8
  br i1 %234, label %direct.true270, label %direct.false271

direct.schedule.13:                               ; preds = %direct.true270
  %.state272 = load i64, ptr %.slot91, align 4
  %235 = mul i64 %.state272, 2
  %.spill.load273 = load i64, ptr %.spill90, align 4
  %236 = add i64 0, %.spill.load273
  %237 = mul i64 %236, 16
  %238 = add i64 %237, %235
  %239 = add i64 %238, 0
  %240 = srem i64 %239, 16
  %241 = sdiv i64 %239, 16
  %242 = add i64 %238, 1
  %243 = srem i64 %242, 16
  %244 = add i64 %238, 16
  %245 = sdiv i64 %244, 16
  %246 = add i64 %238, 17
  %247 = add i64 0, %241
  %248 = mul i64 %247, 32
  %249 = add i64 %248, 0
  %tile_snapshot.spill.load274 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %250 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load274, 0
  %251 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load274, 1
  %.splatinsert275 = insertelement <8 x i64> poison, i64 %249, i64 0
  %.splat276 = shufflevector <8 x i64> %.splatinsert275, <8 x i64> poison, <8 x i32> zeroinitializer
  %252 = mul <8 x i64> %.splat276, splat (i64 32)
  %253 = add <8 x i64> %251, %252
  %254 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %250, 0
  %255 = insertvalue { <8 x ptr>, <8 x i64> } %254, <8 x i64> %253, 1
  %256 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %257 = extractvalue { <8 x ptr>, <8 x i64> } %255, 1
  %258 = extractelement <8 x ptr> %256, i32 0
  %259 = extractelement <8 x i64> %257, i32 0
  %260 = sub i64 %259, 0
  %261 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %262 = select i1 %261, i64 %260, i64 0
  %private.contiguous.address277 = getelementptr i8, ptr %258, i64 %262
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address277, align 4
  %263 = select <8 x i1> %95, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %264 = add i64 0, %245
  %265 = mul i64 %264, 32
  %266 = add i64 %265, 0
  %tile_snapshot.spill.load278 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load278, 0
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load278, 1
  %.splatinsert279 = insertelement <8 x i64> poison, i64 %266, i64 0
  %.splat280 = shufflevector <8 x i64> %.splatinsert279, <8 x i64> poison, <8 x i32> zeroinitializer
  %269 = mul <8 x i64> %.splat280, splat (i64 32)
  %270 = add <8 x i64> %268, %269
  %271 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %267, 0
  %272 = insertvalue { <8 x ptr>, <8 x i64> } %271, <8 x i64> %270, 1
  %273 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %274 = extractvalue { <8 x ptr>, <8 x i64> } %272, 1
  %275 = extractelement <8 x ptr> %273, i32 0
  %276 = extractelement <8 x i64> %274, i32 0
  %277 = sub i64 %276, 0
  %278 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %279 = select i1 %278, i64 %277, i64 0
  %private.contiguous.address281 = getelementptr i8, ptr %275, i64 %279
  %private.contiguous.load282 = load <8 x float>, ptr %private.contiguous.address281, align 4
  %280 = select <8 x i1> %95, <8 x float> %private.contiguous.load282, <8 x float> zeroinitializer
  %281 = add i64 0, %240
  %282 = mul i64 %281, 32
  %283 = add i64 %282, 0
  %tile_snapshot.spill.load283 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %284 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load283, 0
  %285 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load283, 1
  %.splatinsert284 = insertelement <8 x i64> poison, i64 %283, i64 0
  %.splat285 = shufflevector <8 x i64> %.splatinsert284, <8 x i64> poison, <8 x i32> zeroinitializer
  %286 = mul <8 x i64> %.splat285, splat (i64 32)
  %287 = add <8 x i64> %285, %286
  %288 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %284, 0
  %289 = insertvalue { <8 x ptr>, <8 x i64> } %288, <8 x i64> %287, 1
  %290 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %291 = extractvalue { <8 x ptr>, <8 x i64> } %289, 1
  %292 = extractelement <8 x ptr> %290, i32 0
  %293 = extractelement <8 x i64> %291, i32 0
  %294 = sub i64 %293, 0
  %295 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %296 = select i1 %295, i64 %294, i64 0
  %private.contiguous.address286 = getelementptr i8, ptr %292, i64 %296
  %private.contiguous.load287 = load <8 x float>, ptr %private.contiguous.address286, align 4
  %297 = select <8 x i1> %95, <8 x float> %private.contiguous.load287, <8 x float> zeroinitializer
  %298 = add i64 0, %243
  %299 = mul i64 %298, 32
  %300 = add i64 %299, 0
  %tile_snapshot.spill.load288 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %301 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load288, 0
  %302 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load288, 1
  %.splatinsert289 = insertelement <8 x i64> poison, i64 %300, i64 0
  %.splat290 = shufflevector <8 x i64> %.splatinsert289, <8 x i64> poison, <8 x i32> zeroinitializer
  %303 = mul <8 x i64> %.splat290, splat (i64 32)
  %304 = add <8 x i64> %302, %303
  %305 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %301, 0
  %306 = insertvalue { <8 x ptr>, <8 x i64> } %305, <8 x i64> %304, 1
  %307 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %306, 1
  %309 = extractelement <8 x ptr> %307, i32 0
  %310 = extractelement <8 x i64> %308, i32 0
  %311 = sub i64 %310, 0
  %312 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %313 = select i1 %312, i64 %311, i64 0
  %private.contiguous.address291 = getelementptr i8, ptr %309, i64 %313
  %private.contiguous.load292 = load <8 x float>, ptr %private.contiguous.address291, align 4
  %314 = select <8 x i1> %95, <8 x float> %private.contiguous.load292, <8 x float> zeroinitializer
  %315 = fmul <8 x float> %263, %297
  %316 = fadd <8 x float> zeroinitializer, %315
  %317 = fmul <8 x float> %263, %314
  %318 = fadd <8 x float> zeroinitializer, %317
  %319 = fmul <8 x float> %280, %297
  %320 = fadd <8 x float> zeroinitializer, %319
  %321 = fmul <8 x float> %280, %314
  %322 = fadd <8 x float> zeroinitializer, %321
  %323 = add i64 %248, 1
  %tile_snapshot.spill.load293 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load293, 0
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load293, 1
  %.splatinsert294 = insertelement <8 x i64> poison, i64 %323, i64 0
  %.splat295 = shufflevector <8 x i64> %.splatinsert294, <8 x i64> poison, <8 x i32> zeroinitializer
  %326 = mul <8 x i64> %.splat295, splat (i64 32)
  %327 = add <8 x i64> %325, %326
  %328 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %324, 0
  %329 = insertvalue { <8 x ptr>, <8 x i64> } %328, <8 x i64> %327, 1
  %330 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %331 = extractvalue { <8 x ptr>, <8 x i64> } %329, 1
  %332 = extractelement <8 x ptr> %330, i32 0
  %333 = extractelement <8 x i64> %331, i32 0
  %334 = sub i64 %333, 0
  %335 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %336 = select i1 %335, i64 %334, i64 0
  %private.contiguous.address296 = getelementptr i8, ptr %332, i64 %336
  %private.contiguous.load297 = load <8 x float>, ptr %private.contiguous.address296, align 4
  %337 = select <8 x i1> %95, <8 x float> %private.contiguous.load297, <8 x float> zeroinitializer
  %338 = add i64 %265, 1
  %tile_snapshot.spill.load298 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %339 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load298, 0
  %340 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load298, 1
  %.splatinsert299 = insertelement <8 x i64> poison, i64 %338, i64 0
  %.splat300 = shufflevector <8 x i64> %.splatinsert299, <8 x i64> poison, <8 x i32> zeroinitializer
  %341 = mul <8 x i64> %.splat300, splat (i64 32)
  %342 = add <8 x i64> %340, %341
  %343 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %339, 0
  %344 = insertvalue { <8 x ptr>, <8 x i64> } %343, <8 x i64> %342, 1
  %345 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %346 = extractvalue { <8 x ptr>, <8 x i64> } %344, 1
  %347 = extractelement <8 x ptr> %345, i32 0
  %348 = extractelement <8 x i64> %346, i32 0
  %349 = sub i64 %348, 0
  %350 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %351 = select i1 %350, i64 %349, i64 0
  %private.contiguous.address301 = getelementptr i8, ptr %347, i64 %351
  %private.contiguous.load302 = load <8 x float>, ptr %private.contiguous.address301, align 4
  %352 = select <8 x i1> %95, <8 x float> %private.contiguous.load302, <8 x float> zeroinitializer
  %353 = add i64 %282, 1
  %tile_snapshot.spill.load303 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %354 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load303, 0
  %355 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load303, 1
  %.splatinsert304 = insertelement <8 x i64> poison, i64 %353, i64 0
  %.splat305 = shufflevector <8 x i64> %.splatinsert304, <8 x i64> poison, <8 x i32> zeroinitializer
  %356 = mul <8 x i64> %.splat305, splat (i64 32)
  %357 = add <8 x i64> %355, %356
  %358 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %354, 0
  %359 = insertvalue { <8 x ptr>, <8 x i64> } %358, <8 x i64> %357, 1
  %360 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %361 = extractvalue { <8 x ptr>, <8 x i64> } %359, 1
  %362 = extractelement <8 x ptr> %360, i32 0
  %363 = extractelement <8 x i64> %361, i32 0
  %364 = sub i64 %363, 0
  %365 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %366 = select i1 %365, i64 %364, i64 0
  %private.contiguous.address306 = getelementptr i8, ptr %362, i64 %366
  %private.contiguous.load307 = load <8 x float>, ptr %private.contiguous.address306, align 4
  %367 = select <8 x i1> %95, <8 x float> %private.contiguous.load307, <8 x float> zeroinitializer
  %368 = add i64 %299, 1
  %tile_snapshot.spill.load308 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %369 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load308, 0
  %370 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load308, 1
  %.splatinsert309 = insertelement <8 x i64> poison, i64 %368, i64 0
  %.splat310 = shufflevector <8 x i64> %.splatinsert309, <8 x i64> poison, <8 x i32> zeroinitializer
  %371 = mul <8 x i64> %.splat310, splat (i64 32)
  %372 = add <8 x i64> %370, %371
  %373 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %369, 0
  %374 = insertvalue { <8 x ptr>, <8 x i64> } %373, <8 x i64> %372, 1
  %375 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %376 = extractvalue { <8 x ptr>, <8 x i64> } %374, 1
  %377 = extractelement <8 x ptr> %375, i32 0
  %378 = extractelement <8 x i64> %376, i32 0
  %379 = sub i64 %378, 0
  %380 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %381 = select i1 %380, i64 %379, i64 0
  %private.contiguous.address311 = getelementptr i8, ptr %377, i64 %381
  %private.contiguous.load312 = load <8 x float>, ptr %private.contiguous.address311, align 4
  %382 = select <8 x i1> %95, <8 x float> %private.contiguous.load312, <8 x float> zeroinitializer
  %383 = fmul <8 x float> %337, %367
  %384 = fadd <8 x float> %316, %383
  %385 = fmul <8 x float> %337, %382
  %386 = fadd <8 x float> %318, %385
  %387 = fmul <8 x float> %352, %367
  %388 = fadd <8 x float> %320, %387
  %389 = fmul <8 x float> %352, %382
  %390 = fadd <8 x float> %322, %389
  %391 = add i64 %248, 2
  %tile_snapshot.spill.load313 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %392 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load313, 0
  %393 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load313, 1
  %.splatinsert314 = insertelement <8 x i64> poison, i64 %391, i64 0
  %.splat315 = shufflevector <8 x i64> %.splatinsert314, <8 x i64> poison, <8 x i32> zeroinitializer
  %394 = mul <8 x i64> %.splat315, splat (i64 32)
  %395 = add <8 x i64> %393, %394
  %396 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %392, 0
  %397 = insertvalue { <8 x ptr>, <8 x i64> } %396, <8 x i64> %395, 1
  %398 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %399 = extractvalue { <8 x ptr>, <8 x i64> } %397, 1
  %400 = extractelement <8 x ptr> %398, i32 0
  %401 = extractelement <8 x i64> %399, i32 0
  %402 = sub i64 %401, 0
  %403 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %404 = select i1 %403, i64 %402, i64 0
  %private.contiguous.address316 = getelementptr i8, ptr %400, i64 %404
  %private.contiguous.load317 = load <8 x float>, ptr %private.contiguous.address316, align 4
  %405 = select <8 x i1> %95, <8 x float> %private.contiguous.load317, <8 x float> zeroinitializer
  %406 = add i64 %265, 2
  %tile_snapshot.spill.load318 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %407 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load318, 0
  %408 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load318, 1
  %.splatinsert319 = insertelement <8 x i64> poison, i64 %406, i64 0
  %.splat320 = shufflevector <8 x i64> %.splatinsert319, <8 x i64> poison, <8 x i32> zeroinitializer
  %409 = mul <8 x i64> %.splat320, splat (i64 32)
  %410 = add <8 x i64> %408, %409
  %411 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %407, 0
  %412 = insertvalue { <8 x ptr>, <8 x i64> } %411, <8 x i64> %410, 1
  %413 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %414 = extractvalue { <8 x ptr>, <8 x i64> } %412, 1
  %415 = extractelement <8 x ptr> %413, i32 0
  %416 = extractelement <8 x i64> %414, i32 0
  %417 = sub i64 %416, 0
  %418 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %419 = select i1 %418, i64 %417, i64 0
  %private.contiguous.address321 = getelementptr i8, ptr %415, i64 %419
  %private.contiguous.load322 = load <8 x float>, ptr %private.contiguous.address321, align 4
  %420 = select <8 x i1> %95, <8 x float> %private.contiguous.load322, <8 x float> zeroinitializer
  %421 = add i64 %282, 2
  %tile_snapshot.spill.load323 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %422 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load323, 0
  %423 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load323, 1
  %.splatinsert324 = insertelement <8 x i64> poison, i64 %421, i64 0
  %.splat325 = shufflevector <8 x i64> %.splatinsert324, <8 x i64> poison, <8 x i32> zeroinitializer
  %424 = mul <8 x i64> %.splat325, splat (i64 32)
  %425 = add <8 x i64> %423, %424
  %426 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %422, 0
  %427 = insertvalue { <8 x ptr>, <8 x i64> } %426, <8 x i64> %425, 1
  %428 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %429 = extractvalue { <8 x ptr>, <8 x i64> } %427, 1
  %430 = extractelement <8 x ptr> %428, i32 0
  %431 = extractelement <8 x i64> %429, i32 0
  %432 = sub i64 %431, 0
  %433 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %434 = select i1 %433, i64 %432, i64 0
  %private.contiguous.address326 = getelementptr i8, ptr %430, i64 %434
  %private.contiguous.load327 = load <8 x float>, ptr %private.contiguous.address326, align 4
  %435 = select <8 x i1> %95, <8 x float> %private.contiguous.load327, <8 x float> zeroinitializer
  %436 = add i64 %299, 2
  %tile_snapshot.spill.load328 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %437 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load328, 0
  %438 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load328, 1
  %.splatinsert329 = insertelement <8 x i64> poison, i64 %436, i64 0
  %.splat330 = shufflevector <8 x i64> %.splatinsert329, <8 x i64> poison, <8 x i32> zeroinitializer
  %439 = mul <8 x i64> %.splat330, splat (i64 32)
  %440 = add <8 x i64> %438, %439
  %441 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %437, 0
  %442 = insertvalue { <8 x ptr>, <8 x i64> } %441, <8 x i64> %440, 1
  %443 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %444 = extractvalue { <8 x ptr>, <8 x i64> } %442, 1
  %445 = extractelement <8 x ptr> %443, i32 0
  %446 = extractelement <8 x i64> %444, i32 0
  %447 = sub i64 %446, 0
  %448 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %449 = select i1 %448, i64 %447, i64 0
  %private.contiguous.address331 = getelementptr i8, ptr %445, i64 %449
  %private.contiguous.load332 = load <8 x float>, ptr %private.contiguous.address331, align 4
  %450 = select <8 x i1> %95, <8 x float> %private.contiguous.load332, <8 x float> zeroinitializer
  %451 = fmul <8 x float> %405, %435
  %452 = fadd <8 x float> %384, %451
  %453 = fmul <8 x float> %405, %450
  %454 = fadd <8 x float> %386, %453
  %455 = fmul <8 x float> %420, %435
  %456 = fadd <8 x float> %388, %455
  %457 = fmul <8 x float> %420, %450
  %458 = fadd <8 x float> %390, %457
  %459 = add i64 %248, 3
  %tile_snapshot.spill.load333 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %460 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load333, 0
  %461 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load333, 1
  %.splatinsert334 = insertelement <8 x i64> poison, i64 %459, i64 0
  %.splat335 = shufflevector <8 x i64> %.splatinsert334, <8 x i64> poison, <8 x i32> zeroinitializer
  %462 = mul <8 x i64> %.splat335, splat (i64 32)
  %463 = add <8 x i64> %461, %462
  %464 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %460, 0
  %465 = insertvalue { <8 x ptr>, <8 x i64> } %464, <8 x i64> %463, 1
  %466 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %467 = extractvalue { <8 x ptr>, <8 x i64> } %465, 1
  %468 = extractelement <8 x ptr> %466, i32 0
  %469 = extractelement <8 x i64> %467, i32 0
  %470 = sub i64 %469, 0
  %471 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %472 = select i1 %471, i64 %470, i64 0
  %private.contiguous.address336 = getelementptr i8, ptr %468, i64 %472
  %private.contiguous.load337 = load <8 x float>, ptr %private.contiguous.address336, align 4
  %473 = select <8 x i1> %95, <8 x float> %private.contiguous.load337, <8 x float> zeroinitializer
  %474 = add i64 %265, 3
  %tile_snapshot.spill.load338 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %475 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load338, 0
  %476 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load338, 1
  %.splatinsert339 = insertelement <8 x i64> poison, i64 %474, i64 0
  %.splat340 = shufflevector <8 x i64> %.splatinsert339, <8 x i64> poison, <8 x i32> zeroinitializer
  %477 = mul <8 x i64> %.splat340, splat (i64 32)
  %478 = add <8 x i64> %476, %477
  %479 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %475, 0
  %480 = insertvalue { <8 x ptr>, <8 x i64> } %479, <8 x i64> %478, 1
  %481 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %482 = extractvalue { <8 x ptr>, <8 x i64> } %480, 1
  %483 = extractelement <8 x ptr> %481, i32 0
  %484 = extractelement <8 x i64> %482, i32 0
  %485 = sub i64 %484, 0
  %486 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %487 = select i1 %486, i64 %485, i64 0
  %private.contiguous.address341 = getelementptr i8, ptr %483, i64 %487
  %private.contiguous.load342 = load <8 x float>, ptr %private.contiguous.address341, align 4
  %488 = select <8 x i1> %95, <8 x float> %private.contiguous.load342, <8 x float> zeroinitializer
  %489 = add i64 %282, 3
  %tile_snapshot.spill.load343 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %490 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load343, 0
  %491 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load343, 1
  %.splatinsert344 = insertelement <8 x i64> poison, i64 %489, i64 0
  %.splat345 = shufflevector <8 x i64> %.splatinsert344, <8 x i64> poison, <8 x i32> zeroinitializer
  %492 = mul <8 x i64> %.splat345, splat (i64 32)
  %493 = add <8 x i64> %491, %492
  %494 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %490, 0
  %495 = insertvalue { <8 x ptr>, <8 x i64> } %494, <8 x i64> %493, 1
  %496 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %497 = extractvalue { <8 x ptr>, <8 x i64> } %495, 1
  %498 = extractelement <8 x ptr> %496, i32 0
  %499 = extractelement <8 x i64> %497, i32 0
  %500 = sub i64 %499, 0
  %501 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %502 = select i1 %501, i64 %500, i64 0
  %private.contiguous.address346 = getelementptr i8, ptr %498, i64 %502
  %private.contiguous.load347 = load <8 x float>, ptr %private.contiguous.address346, align 4
  %503 = select <8 x i1> %95, <8 x float> %private.contiguous.load347, <8 x float> zeroinitializer
  %504 = add i64 %299, 3
  %tile_snapshot.spill.load348 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %505 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load348, 0
  %506 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load348, 1
  %.splatinsert349 = insertelement <8 x i64> poison, i64 %504, i64 0
  %.splat350 = shufflevector <8 x i64> %.splatinsert349, <8 x i64> poison, <8 x i32> zeroinitializer
  %507 = mul <8 x i64> %.splat350, splat (i64 32)
  %508 = add <8 x i64> %506, %507
  %509 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %505, 0
  %510 = insertvalue { <8 x ptr>, <8 x i64> } %509, <8 x i64> %508, 1
  %511 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %512 = extractvalue { <8 x ptr>, <8 x i64> } %510, 1
  %513 = extractelement <8 x ptr> %511, i32 0
  %514 = extractelement <8 x i64> %512, i32 0
  %515 = sub i64 %514, 0
  %516 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %517 = select i1 %516, i64 %515, i64 0
  %private.contiguous.address351 = getelementptr i8, ptr %513, i64 %517
  %private.contiguous.load352 = load <8 x float>, ptr %private.contiguous.address351, align 4
  %518 = select <8 x i1> %95, <8 x float> %private.contiguous.load352, <8 x float> zeroinitializer
  %519 = fmul <8 x float> %473, %503
  %520 = fadd <8 x float> %452, %519
  %521 = fmul <8 x float> %473, %518
  %522 = fadd <8 x float> %454, %521
  %523 = fmul <8 x float> %488, %503
  %524 = fadd <8 x float> %456, %523
  %525 = fmul <8 x float> %488, %518
  %526 = fadd <8 x float> %458, %525
  %527 = add i64 %248, 4
  %tile_snapshot.spill.load353 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %528 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load353, 0
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load353, 1
  %.splatinsert354 = insertelement <8 x i64> poison, i64 %527, i64 0
  %.splat355 = shufflevector <8 x i64> %.splatinsert354, <8 x i64> poison, <8 x i32> zeroinitializer
  %530 = mul <8 x i64> %.splat355, splat (i64 32)
  %531 = add <8 x i64> %529, %530
  %532 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %528, 0
  %533 = insertvalue { <8 x ptr>, <8 x i64> } %532, <8 x i64> %531, 1
  %534 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %535 = extractvalue { <8 x ptr>, <8 x i64> } %533, 1
  %536 = extractelement <8 x ptr> %534, i32 0
  %537 = extractelement <8 x i64> %535, i32 0
  %538 = sub i64 %537, 0
  %539 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %540 = select i1 %539, i64 %538, i64 0
  %private.contiguous.address356 = getelementptr i8, ptr %536, i64 %540
  %private.contiguous.load357 = load <8 x float>, ptr %private.contiguous.address356, align 4
  %541 = select <8 x i1> %95, <8 x float> %private.contiguous.load357, <8 x float> zeroinitializer
  %542 = add i64 %265, 4
  %tile_snapshot.spill.load358 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %543 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load358, 0
  %544 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load358, 1
  %.splatinsert359 = insertelement <8 x i64> poison, i64 %542, i64 0
  %.splat360 = shufflevector <8 x i64> %.splatinsert359, <8 x i64> poison, <8 x i32> zeroinitializer
  %545 = mul <8 x i64> %.splat360, splat (i64 32)
  %546 = add <8 x i64> %544, %545
  %547 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %543, 0
  %548 = insertvalue { <8 x ptr>, <8 x i64> } %547, <8 x i64> %546, 1
  %549 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %550 = extractvalue { <8 x ptr>, <8 x i64> } %548, 1
  %551 = extractelement <8 x ptr> %549, i32 0
  %552 = extractelement <8 x i64> %550, i32 0
  %553 = sub i64 %552, 0
  %554 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %555 = select i1 %554, i64 %553, i64 0
  %private.contiguous.address361 = getelementptr i8, ptr %551, i64 %555
  %private.contiguous.load362 = load <8 x float>, ptr %private.contiguous.address361, align 4
  %556 = select <8 x i1> %95, <8 x float> %private.contiguous.load362, <8 x float> zeroinitializer
  %557 = add i64 %282, 4
  %tile_snapshot.spill.load363 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %558 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load363, 0
  %559 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load363, 1
  %.splatinsert364 = insertelement <8 x i64> poison, i64 %557, i64 0
  %.splat365 = shufflevector <8 x i64> %.splatinsert364, <8 x i64> poison, <8 x i32> zeroinitializer
  %560 = mul <8 x i64> %.splat365, splat (i64 32)
  %561 = add <8 x i64> %559, %560
  %562 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %558, 0
  %563 = insertvalue { <8 x ptr>, <8 x i64> } %562, <8 x i64> %561, 1
  %564 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %565 = extractvalue { <8 x ptr>, <8 x i64> } %563, 1
  %566 = extractelement <8 x ptr> %564, i32 0
  %567 = extractelement <8 x i64> %565, i32 0
  %568 = sub i64 %567, 0
  %569 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %570 = select i1 %569, i64 %568, i64 0
  %private.contiguous.address366 = getelementptr i8, ptr %566, i64 %570
  %private.contiguous.load367 = load <8 x float>, ptr %private.contiguous.address366, align 4
  %571 = select <8 x i1> %95, <8 x float> %private.contiguous.load367, <8 x float> zeroinitializer
  %572 = add i64 %299, 4
  %tile_snapshot.spill.load368 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %573 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load368, 0
  %574 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load368, 1
  %.splatinsert369 = insertelement <8 x i64> poison, i64 %572, i64 0
  %.splat370 = shufflevector <8 x i64> %.splatinsert369, <8 x i64> poison, <8 x i32> zeroinitializer
  %575 = mul <8 x i64> %.splat370, splat (i64 32)
  %576 = add <8 x i64> %574, %575
  %577 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %573, 0
  %578 = insertvalue { <8 x ptr>, <8 x i64> } %577, <8 x i64> %576, 1
  %579 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %580 = extractvalue { <8 x ptr>, <8 x i64> } %578, 1
  %581 = extractelement <8 x ptr> %579, i32 0
  %582 = extractelement <8 x i64> %580, i32 0
  %583 = sub i64 %582, 0
  %584 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %585 = select i1 %584, i64 %583, i64 0
  %private.contiguous.address371 = getelementptr i8, ptr %581, i64 %585
  %private.contiguous.load372 = load <8 x float>, ptr %private.contiguous.address371, align 4
  %586 = select <8 x i1> %95, <8 x float> %private.contiguous.load372, <8 x float> zeroinitializer
  %587 = fmul <8 x float> %541, %571
  %588 = fadd <8 x float> %520, %587
  %589 = fmul <8 x float> %541, %586
  %590 = fadd <8 x float> %522, %589
  %591 = fmul <8 x float> %556, %571
  %592 = fadd <8 x float> %524, %591
  %593 = fmul <8 x float> %556, %586
  %594 = fadd <8 x float> %526, %593
  %595 = add i64 %248, 5
  %tile_snapshot.spill.load373 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %596 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load373, 0
  %597 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load373, 1
  %.splatinsert374 = insertelement <8 x i64> poison, i64 %595, i64 0
  %.splat375 = shufflevector <8 x i64> %.splatinsert374, <8 x i64> poison, <8 x i32> zeroinitializer
  %598 = mul <8 x i64> %.splat375, splat (i64 32)
  %599 = add <8 x i64> %597, %598
  %600 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %596, 0
  %601 = insertvalue { <8 x ptr>, <8 x i64> } %600, <8 x i64> %599, 1
  %602 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %603 = extractvalue { <8 x ptr>, <8 x i64> } %601, 1
  %604 = extractelement <8 x ptr> %602, i32 0
  %605 = extractelement <8 x i64> %603, i32 0
  %606 = sub i64 %605, 0
  %607 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %608 = select i1 %607, i64 %606, i64 0
  %private.contiguous.address376 = getelementptr i8, ptr %604, i64 %608
  %private.contiguous.load377 = load <8 x float>, ptr %private.contiguous.address376, align 4
  %609 = select <8 x i1> %95, <8 x float> %private.contiguous.load377, <8 x float> zeroinitializer
  %610 = add i64 %265, 5
  %tile_snapshot.spill.load378 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %611 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load378, 0
  %612 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load378, 1
  %.splatinsert379 = insertelement <8 x i64> poison, i64 %610, i64 0
  %.splat380 = shufflevector <8 x i64> %.splatinsert379, <8 x i64> poison, <8 x i32> zeroinitializer
  %613 = mul <8 x i64> %.splat380, splat (i64 32)
  %614 = add <8 x i64> %612, %613
  %615 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %611, 0
  %616 = insertvalue { <8 x ptr>, <8 x i64> } %615, <8 x i64> %614, 1
  %617 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %618 = extractvalue { <8 x ptr>, <8 x i64> } %616, 1
  %619 = extractelement <8 x ptr> %617, i32 0
  %620 = extractelement <8 x i64> %618, i32 0
  %621 = sub i64 %620, 0
  %622 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %623 = select i1 %622, i64 %621, i64 0
  %private.contiguous.address381 = getelementptr i8, ptr %619, i64 %623
  %private.contiguous.load382 = load <8 x float>, ptr %private.contiguous.address381, align 4
  %624 = select <8 x i1> %95, <8 x float> %private.contiguous.load382, <8 x float> zeroinitializer
  %625 = add i64 %282, 5
  %tile_snapshot.spill.load383 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %626 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load383, 0
  %627 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load383, 1
  %.splatinsert384 = insertelement <8 x i64> poison, i64 %625, i64 0
  %.splat385 = shufflevector <8 x i64> %.splatinsert384, <8 x i64> poison, <8 x i32> zeroinitializer
  %628 = mul <8 x i64> %.splat385, splat (i64 32)
  %629 = add <8 x i64> %627, %628
  %630 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %626, 0
  %631 = insertvalue { <8 x ptr>, <8 x i64> } %630, <8 x i64> %629, 1
  %632 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %633 = extractvalue { <8 x ptr>, <8 x i64> } %631, 1
  %634 = extractelement <8 x ptr> %632, i32 0
  %635 = extractelement <8 x i64> %633, i32 0
  %636 = sub i64 %635, 0
  %637 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %638 = select i1 %637, i64 %636, i64 0
  %private.contiguous.address386 = getelementptr i8, ptr %634, i64 %638
  %private.contiguous.load387 = load <8 x float>, ptr %private.contiguous.address386, align 4
  %639 = select <8 x i1> %95, <8 x float> %private.contiguous.load387, <8 x float> zeroinitializer
  %640 = add i64 %299, 5
  %tile_snapshot.spill.load388 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %641 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load388, 0
  %642 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load388, 1
  %.splatinsert389 = insertelement <8 x i64> poison, i64 %640, i64 0
  %.splat390 = shufflevector <8 x i64> %.splatinsert389, <8 x i64> poison, <8 x i32> zeroinitializer
  %643 = mul <8 x i64> %.splat390, splat (i64 32)
  %644 = add <8 x i64> %642, %643
  %645 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %641, 0
  %646 = insertvalue { <8 x ptr>, <8 x i64> } %645, <8 x i64> %644, 1
  %647 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %648 = extractvalue { <8 x ptr>, <8 x i64> } %646, 1
  %649 = extractelement <8 x ptr> %647, i32 0
  %650 = extractelement <8 x i64> %648, i32 0
  %651 = sub i64 %650, 0
  %652 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %653 = select i1 %652, i64 %651, i64 0
  %private.contiguous.address391 = getelementptr i8, ptr %649, i64 %653
  %private.contiguous.load392 = load <8 x float>, ptr %private.contiguous.address391, align 4
  %654 = select <8 x i1> %95, <8 x float> %private.contiguous.load392, <8 x float> zeroinitializer
  %655 = fmul <8 x float> %609, %639
  %656 = fadd <8 x float> %588, %655
  %657 = fmul <8 x float> %609, %654
  %658 = fadd <8 x float> %590, %657
  %659 = fmul <8 x float> %624, %639
  %660 = fadd <8 x float> %592, %659
  %661 = fmul <8 x float> %624, %654
  %662 = fadd <8 x float> %594, %661
  %663 = add i64 %248, 6
  %tile_snapshot.spill.load393 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %664 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load393, 0
  %665 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load393, 1
  %.splatinsert394 = insertelement <8 x i64> poison, i64 %663, i64 0
  %.splat395 = shufflevector <8 x i64> %.splatinsert394, <8 x i64> poison, <8 x i32> zeroinitializer
  %666 = mul <8 x i64> %.splat395, splat (i64 32)
  %667 = add <8 x i64> %665, %666
  %668 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %664, 0
  %669 = insertvalue { <8 x ptr>, <8 x i64> } %668, <8 x i64> %667, 1
  %670 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %671 = extractvalue { <8 x ptr>, <8 x i64> } %669, 1
  %672 = extractelement <8 x ptr> %670, i32 0
  %673 = extractelement <8 x i64> %671, i32 0
  %674 = sub i64 %673, 0
  %675 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %676 = select i1 %675, i64 %674, i64 0
  %private.contiguous.address396 = getelementptr i8, ptr %672, i64 %676
  %private.contiguous.load397 = load <8 x float>, ptr %private.contiguous.address396, align 4
  %677 = select <8 x i1> %95, <8 x float> %private.contiguous.load397, <8 x float> zeroinitializer
  %678 = add i64 %265, 6
  %tile_snapshot.spill.load398 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %679 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load398, 0
  %680 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load398, 1
  %.splatinsert399 = insertelement <8 x i64> poison, i64 %678, i64 0
  %.splat400 = shufflevector <8 x i64> %.splatinsert399, <8 x i64> poison, <8 x i32> zeroinitializer
  %681 = mul <8 x i64> %.splat400, splat (i64 32)
  %682 = add <8 x i64> %680, %681
  %683 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %679, 0
  %684 = insertvalue { <8 x ptr>, <8 x i64> } %683, <8 x i64> %682, 1
  %685 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %686 = extractvalue { <8 x ptr>, <8 x i64> } %684, 1
  %687 = extractelement <8 x ptr> %685, i32 0
  %688 = extractelement <8 x i64> %686, i32 0
  %689 = sub i64 %688, 0
  %690 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %691 = select i1 %690, i64 %689, i64 0
  %private.contiguous.address401 = getelementptr i8, ptr %687, i64 %691
  %private.contiguous.load402 = load <8 x float>, ptr %private.contiguous.address401, align 4
  %692 = select <8 x i1> %95, <8 x float> %private.contiguous.load402, <8 x float> zeroinitializer
  %693 = add i64 %282, 6
  %tile_snapshot.spill.load403 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %694 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load403, 0
  %695 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load403, 1
  %.splatinsert404 = insertelement <8 x i64> poison, i64 %693, i64 0
  %.splat405 = shufflevector <8 x i64> %.splatinsert404, <8 x i64> poison, <8 x i32> zeroinitializer
  %696 = mul <8 x i64> %.splat405, splat (i64 32)
  %697 = add <8 x i64> %695, %696
  %698 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %694, 0
  %699 = insertvalue { <8 x ptr>, <8 x i64> } %698, <8 x i64> %697, 1
  %700 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %701 = extractvalue { <8 x ptr>, <8 x i64> } %699, 1
  %702 = extractelement <8 x ptr> %700, i32 0
  %703 = extractelement <8 x i64> %701, i32 0
  %704 = sub i64 %703, 0
  %705 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %706 = select i1 %705, i64 %704, i64 0
  %private.contiguous.address406 = getelementptr i8, ptr %702, i64 %706
  %private.contiguous.load407 = load <8 x float>, ptr %private.contiguous.address406, align 4
  %707 = select <8 x i1> %95, <8 x float> %private.contiguous.load407, <8 x float> zeroinitializer
  %708 = add i64 %299, 6
  %tile_snapshot.spill.load408 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %709 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 0
  %710 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 1
  %.splatinsert409 = insertelement <8 x i64> poison, i64 %708, i64 0
  %.splat410 = shufflevector <8 x i64> %.splatinsert409, <8 x i64> poison, <8 x i32> zeroinitializer
  %711 = mul <8 x i64> %.splat410, splat (i64 32)
  %712 = add <8 x i64> %710, %711
  %713 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %709, 0
  %714 = insertvalue { <8 x ptr>, <8 x i64> } %713, <8 x i64> %712, 1
  %715 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %716 = extractvalue { <8 x ptr>, <8 x i64> } %714, 1
  %717 = extractelement <8 x ptr> %715, i32 0
  %718 = extractelement <8 x i64> %716, i32 0
  %719 = sub i64 %718, 0
  %720 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %721 = select i1 %720, i64 %719, i64 0
  %private.contiguous.address411 = getelementptr i8, ptr %717, i64 %721
  %private.contiguous.load412 = load <8 x float>, ptr %private.contiguous.address411, align 4
  %722 = select <8 x i1> %95, <8 x float> %private.contiguous.load412, <8 x float> zeroinitializer
  %723 = fmul <8 x float> %677, %707
  %724 = fadd <8 x float> %656, %723
  %725 = fmul <8 x float> %677, %722
  %726 = fadd <8 x float> %658, %725
  %727 = fmul <8 x float> %692, %707
  %728 = fadd <8 x float> %660, %727
  %729 = fmul <8 x float> %692, %722
  %730 = fadd <8 x float> %662, %729
  %731 = add i64 %248, 7
  %tile_snapshot.spill.load413 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %732 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load413, 0
  %733 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load413, 1
  %.splatinsert414 = insertelement <8 x i64> poison, i64 %731, i64 0
  %.splat415 = shufflevector <8 x i64> %.splatinsert414, <8 x i64> poison, <8 x i32> zeroinitializer
  %734 = mul <8 x i64> %.splat415, splat (i64 32)
  %735 = add <8 x i64> %733, %734
  %736 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %732, 0
  %737 = insertvalue { <8 x ptr>, <8 x i64> } %736, <8 x i64> %735, 1
  %738 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %739 = extractvalue { <8 x ptr>, <8 x i64> } %737, 1
  %740 = extractelement <8 x ptr> %738, i32 0
  %741 = extractelement <8 x i64> %739, i32 0
  %742 = sub i64 %741, 0
  %743 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %744 = select i1 %743, i64 %742, i64 0
  %private.contiguous.address416 = getelementptr i8, ptr %740, i64 %744
  %private.contiguous.load417 = load <8 x float>, ptr %private.contiguous.address416, align 4
  %745 = select <8 x i1> %95, <8 x float> %private.contiguous.load417, <8 x float> zeroinitializer
  %746 = add i64 %265, 7
  %tile_snapshot.spill.load418 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %747 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load418, 0
  %748 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load418, 1
  %.splatinsert419 = insertelement <8 x i64> poison, i64 %746, i64 0
  %.splat420 = shufflevector <8 x i64> %.splatinsert419, <8 x i64> poison, <8 x i32> zeroinitializer
  %749 = mul <8 x i64> %.splat420, splat (i64 32)
  %750 = add <8 x i64> %748, %749
  %751 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %747, 0
  %752 = insertvalue { <8 x ptr>, <8 x i64> } %751, <8 x i64> %750, 1
  %753 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %754 = extractvalue { <8 x ptr>, <8 x i64> } %752, 1
  %755 = extractelement <8 x ptr> %753, i32 0
  %756 = extractelement <8 x i64> %754, i32 0
  %757 = sub i64 %756, 0
  %758 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %759 = select i1 %758, i64 %757, i64 0
  %private.contiguous.address421 = getelementptr i8, ptr %755, i64 %759
  %private.contiguous.load422 = load <8 x float>, ptr %private.contiguous.address421, align 4
  %760 = select <8 x i1> %95, <8 x float> %private.contiguous.load422, <8 x float> zeroinitializer
  %761 = add i64 %282, 7
  %tile_snapshot.spill.load423 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %762 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load423, 0
  %763 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load423, 1
  %.splatinsert424 = insertelement <8 x i64> poison, i64 %761, i64 0
  %.splat425 = shufflevector <8 x i64> %.splatinsert424, <8 x i64> poison, <8 x i32> zeroinitializer
  %764 = mul <8 x i64> %.splat425, splat (i64 32)
  %765 = add <8 x i64> %763, %764
  %766 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %762, 0
  %767 = insertvalue { <8 x ptr>, <8 x i64> } %766, <8 x i64> %765, 1
  %768 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %769 = extractvalue { <8 x ptr>, <8 x i64> } %767, 1
  %770 = extractelement <8 x ptr> %768, i32 0
  %771 = extractelement <8 x i64> %769, i32 0
  %772 = sub i64 %771, 0
  %773 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %774 = select i1 %773, i64 %772, i64 0
  %private.contiguous.address426 = getelementptr i8, ptr %770, i64 %774
  %private.contiguous.load427 = load <8 x float>, ptr %private.contiguous.address426, align 4
  %775 = select <8 x i1> %95, <8 x float> %private.contiguous.load427, <8 x float> zeroinitializer
  %776 = add i64 %299, 7
  %tile_snapshot.spill.load428 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %777 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load428, 0
  %778 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load428, 1
  %.splatinsert429 = insertelement <8 x i64> poison, i64 %776, i64 0
  %.splat430 = shufflevector <8 x i64> %.splatinsert429, <8 x i64> poison, <8 x i32> zeroinitializer
  %779 = mul <8 x i64> %.splat430, splat (i64 32)
  %780 = add <8 x i64> %778, %779
  %781 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %777, 0
  %782 = insertvalue { <8 x ptr>, <8 x i64> } %781, <8 x i64> %780, 1
  %783 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %784 = extractvalue { <8 x ptr>, <8 x i64> } %782, 1
  %785 = extractelement <8 x ptr> %783, i32 0
  %786 = extractelement <8 x i64> %784, i32 0
  %787 = sub i64 %786, 0
  %788 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %789 = select i1 %788, i64 %787, i64 0
  %private.contiguous.address431 = getelementptr i8, ptr %785, i64 %789
  %private.contiguous.load432 = load <8 x float>, ptr %private.contiguous.address431, align 4
  %790 = select <8 x i1> %95, <8 x float> %private.contiguous.load432, <8 x float> zeroinitializer
  %791 = fmul <8 x float> %745, %775
  %792 = fadd <8 x float> %724, %791
  %793 = fmul <8 x float> %745, %790
  %794 = fadd <8 x float> %726, %793
  %795 = fmul <8 x float> %760, %775
  %796 = fadd <8 x float> %728, %795
  %797 = fmul <8 x float> %760, %790
  %798 = fadd <8 x float> %730, %797
  %799 = add i64 %248, 8
  %tile_snapshot.spill.load433 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %800 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load433, 0
  %801 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load433, 1
  %.splatinsert434 = insertelement <8 x i64> poison, i64 %799, i64 0
  %.splat435 = shufflevector <8 x i64> %.splatinsert434, <8 x i64> poison, <8 x i32> zeroinitializer
  %802 = mul <8 x i64> %.splat435, splat (i64 32)
  %803 = add <8 x i64> %801, %802
  %804 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %800, 0
  %805 = insertvalue { <8 x ptr>, <8 x i64> } %804, <8 x i64> %803, 1
  %806 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %807 = extractvalue { <8 x ptr>, <8 x i64> } %805, 1
  %808 = extractelement <8 x ptr> %806, i32 0
  %809 = extractelement <8 x i64> %807, i32 0
  %810 = sub i64 %809, 0
  %811 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %812 = select i1 %811, i64 %810, i64 0
  %private.contiguous.address436 = getelementptr i8, ptr %808, i64 %812
  %private.contiguous.load437 = load <8 x float>, ptr %private.contiguous.address436, align 4
  %813 = select <8 x i1> %95, <8 x float> %private.contiguous.load437, <8 x float> zeroinitializer
  %814 = add i64 %265, 8
  %tile_snapshot.spill.load438 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %815 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load438, 0
  %816 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load438, 1
  %.splatinsert439 = insertelement <8 x i64> poison, i64 %814, i64 0
  %.splat440 = shufflevector <8 x i64> %.splatinsert439, <8 x i64> poison, <8 x i32> zeroinitializer
  %817 = mul <8 x i64> %.splat440, splat (i64 32)
  %818 = add <8 x i64> %816, %817
  %819 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %815, 0
  %820 = insertvalue { <8 x ptr>, <8 x i64> } %819, <8 x i64> %818, 1
  %821 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %822 = extractvalue { <8 x ptr>, <8 x i64> } %820, 1
  %823 = extractelement <8 x ptr> %821, i32 0
  %824 = extractelement <8 x i64> %822, i32 0
  %825 = sub i64 %824, 0
  %826 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %827 = select i1 %826, i64 %825, i64 0
  %private.contiguous.address441 = getelementptr i8, ptr %823, i64 %827
  %private.contiguous.load442 = load <8 x float>, ptr %private.contiguous.address441, align 4
  %828 = select <8 x i1> %95, <8 x float> %private.contiguous.load442, <8 x float> zeroinitializer
  %829 = add i64 %282, 8
  %tile_snapshot.spill.load443 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %830 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load443, 0
  %831 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load443, 1
  %.splatinsert444 = insertelement <8 x i64> poison, i64 %829, i64 0
  %.splat445 = shufflevector <8 x i64> %.splatinsert444, <8 x i64> poison, <8 x i32> zeroinitializer
  %832 = mul <8 x i64> %.splat445, splat (i64 32)
  %833 = add <8 x i64> %831, %832
  %834 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %830, 0
  %835 = insertvalue { <8 x ptr>, <8 x i64> } %834, <8 x i64> %833, 1
  %836 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %837 = extractvalue { <8 x ptr>, <8 x i64> } %835, 1
  %838 = extractelement <8 x ptr> %836, i32 0
  %839 = extractelement <8 x i64> %837, i32 0
  %840 = sub i64 %839, 0
  %841 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %842 = select i1 %841, i64 %840, i64 0
  %private.contiguous.address446 = getelementptr i8, ptr %838, i64 %842
  %private.contiguous.load447 = load <8 x float>, ptr %private.contiguous.address446, align 4
  %843 = select <8 x i1> %95, <8 x float> %private.contiguous.load447, <8 x float> zeroinitializer
  %844 = add i64 %299, 8
  %tile_snapshot.spill.load448 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %845 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load448, 0
  %846 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load448, 1
  %.splatinsert449 = insertelement <8 x i64> poison, i64 %844, i64 0
  %.splat450 = shufflevector <8 x i64> %.splatinsert449, <8 x i64> poison, <8 x i32> zeroinitializer
  %847 = mul <8 x i64> %.splat450, splat (i64 32)
  %848 = add <8 x i64> %846, %847
  %849 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %845, 0
  %850 = insertvalue { <8 x ptr>, <8 x i64> } %849, <8 x i64> %848, 1
  %851 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %852 = extractvalue { <8 x ptr>, <8 x i64> } %850, 1
  %853 = extractelement <8 x ptr> %851, i32 0
  %854 = extractelement <8 x i64> %852, i32 0
  %855 = sub i64 %854, 0
  %856 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %857 = select i1 %856, i64 %855, i64 0
  %private.contiguous.address451 = getelementptr i8, ptr %853, i64 %857
  %private.contiguous.load452 = load <8 x float>, ptr %private.contiguous.address451, align 4
  %858 = select <8 x i1> %95, <8 x float> %private.contiguous.load452, <8 x float> zeroinitializer
  %859 = fmul <8 x float> %813, %843
  %860 = fadd <8 x float> %792, %859
  %861 = fmul <8 x float> %813, %858
  %862 = fadd <8 x float> %794, %861
  %863 = fmul <8 x float> %828, %843
  %864 = fadd <8 x float> %796, %863
  %865 = fmul <8 x float> %828, %858
  %866 = fadd <8 x float> %798, %865
  %867 = add i64 %248, 9
  %tile_snapshot.spill.load453 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %868 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load453, 0
  %869 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load453, 1
  %.splatinsert454 = insertelement <8 x i64> poison, i64 %867, i64 0
  %.splat455 = shufflevector <8 x i64> %.splatinsert454, <8 x i64> poison, <8 x i32> zeroinitializer
  %870 = mul <8 x i64> %.splat455, splat (i64 32)
  %871 = add <8 x i64> %869, %870
  %872 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %868, 0
  %873 = insertvalue { <8 x ptr>, <8 x i64> } %872, <8 x i64> %871, 1
  %874 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %875 = extractvalue { <8 x ptr>, <8 x i64> } %873, 1
  %876 = extractelement <8 x ptr> %874, i32 0
  %877 = extractelement <8 x i64> %875, i32 0
  %878 = sub i64 %877, 0
  %879 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %880 = select i1 %879, i64 %878, i64 0
  %private.contiguous.address456 = getelementptr i8, ptr %876, i64 %880
  %private.contiguous.load457 = load <8 x float>, ptr %private.contiguous.address456, align 4
  %881 = select <8 x i1> %95, <8 x float> %private.contiguous.load457, <8 x float> zeroinitializer
  %882 = add i64 %265, 9
  %tile_snapshot.spill.load458 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %883 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load458, 0
  %884 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load458, 1
  %.splatinsert459 = insertelement <8 x i64> poison, i64 %882, i64 0
  %.splat460 = shufflevector <8 x i64> %.splatinsert459, <8 x i64> poison, <8 x i32> zeroinitializer
  %885 = mul <8 x i64> %.splat460, splat (i64 32)
  %886 = add <8 x i64> %884, %885
  %887 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %883, 0
  %888 = insertvalue { <8 x ptr>, <8 x i64> } %887, <8 x i64> %886, 1
  %889 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %890 = extractvalue { <8 x ptr>, <8 x i64> } %888, 1
  %891 = extractelement <8 x ptr> %889, i32 0
  %892 = extractelement <8 x i64> %890, i32 0
  %893 = sub i64 %892, 0
  %894 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %895 = select i1 %894, i64 %893, i64 0
  %private.contiguous.address461 = getelementptr i8, ptr %891, i64 %895
  %private.contiguous.load462 = load <8 x float>, ptr %private.contiguous.address461, align 4
  %896 = select <8 x i1> %95, <8 x float> %private.contiguous.load462, <8 x float> zeroinitializer
  %897 = add i64 %282, 9
  %tile_snapshot.spill.load463 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %898 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load463, 0
  %899 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load463, 1
  %.splatinsert464 = insertelement <8 x i64> poison, i64 %897, i64 0
  %.splat465 = shufflevector <8 x i64> %.splatinsert464, <8 x i64> poison, <8 x i32> zeroinitializer
  %900 = mul <8 x i64> %.splat465, splat (i64 32)
  %901 = add <8 x i64> %899, %900
  %902 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %898, 0
  %903 = insertvalue { <8 x ptr>, <8 x i64> } %902, <8 x i64> %901, 1
  %904 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %905 = extractvalue { <8 x ptr>, <8 x i64> } %903, 1
  %906 = extractelement <8 x ptr> %904, i32 0
  %907 = extractelement <8 x i64> %905, i32 0
  %908 = sub i64 %907, 0
  %909 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %910 = select i1 %909, i64 %908, i64 0
  %private.contiguous.address466 = getelementptr i8, ptr %906, i64 %910
  %private.contiguous.load467 = load <8 x float>, ptr %private.contiguous.address466, align 4
  %911 = select <8 x i1> %95, <8 x float> %private.contiguous.load467, <8 x float> zeroinitializer
  %912 = add i64 %299, 9
  %tile_snapshot.spill.load468 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %913 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load468, 0
  %914 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load468, 1
  %.splatinsert469 = insertelement <8 x i64> poison, i64 %912, i64 0
  %.splat470 = shufflevector <8 x i64> %.splatinsert469, <8 x i64> poison, <8 x i32> zeroinitializer
  %915 = mul <8 x i64> %.splat470, splat (i64 32)
  %916 = add <8 x i64> %914, %915
  %917 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %913, 0
  %918 = insertvalue { <8 x ptr>, <8 x i64> } %917, <8 x i64> %916, 1
  %919 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %920 = extractvalue { <8 x ptr>, <8 x i64> } %918, 1
  %921 = extractelement <8 x ptr> %919, i32 0
  %922 = extractelement <8 x i64> %920, i32 0
  %923 = sub i64 %922, 0
  %924 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %925 = select i1 %924, i64 %923, i64 0
  %private.contiguous.address471 = getelementptr i8, ptr %921, i64 %925
  %private.contiguous.load472 = load <8 x float>, ptr %private.contiguous.address471, align 4
  %926 = select <8 x i1> %95, <8 x float> %private.contiguous.load472, <8 x float> zeroinitializer
  %927 = fmul <8 x float> %881, %911
  %928 = fadd <8 x float> %860, %927
  %929 = fmul <8 x float> %881, %926
  %930 = fadd <8 x float> %862, %929
  %931 = fmul <8 x float> %896, %911
  %932 = fadd <8 x float> %864, %931
  %933 = fmul <8 x float> %896, %926
  %934 = fadd <8 x float> %866, %933
  %935 = add i64 %248, 10
  %tile_snapshot.spill.load473 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %936 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load473, 0
  %937 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load473, 1
  %.splatinsert474 = insertelement <8 x i64> poison, i64 %935, i64 0
  %.splat475 = shufflevector <8 x i64> %.splatinsert474, <8 x i64> poison, <8 x i32> zeroinitializer
  %938 = mul <8 x i64> %.splat475, splat (i64 32)
  %939 = add <8 x i64> %937, %938
  %940 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %936, 0
  %941 = insertvalue { <8 x ptr>, <8 x i64> } %940, <8 x i64> %939, 1
  %942 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %943 = extractvalue { <8 x ptr>, <8 x i64> } %941, 1
  %944 = extractelement <8 x ptr> %942, i32 0
  %945 = extractelement <8 x i64> %943, i32 0
  %946 = sub i64 %945, 0
  %947 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %948 = select i1 %947, i64 %946, i64 0
  %private.contiguous.address476 = getelementptr i8, ptr %944, i64 %948
  %private.contiguous.load477 = load <8 x float>, ptr %private.contiguous.address476, align 4
  %949 = select <8 x i1> %95, <8 x float> %private.contiguous.load477, <8 x float> zeroinitializer
  %950 = add i64 %265, 10
  %tile_snapshot.spill.load478 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %951 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load478, 0
  %952 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load478, 1
  %.splatinsert479 = insertelement <8 x i64> poison, i64 %950, i64 0
  %.splat480 = shufflevector <8 x i64> %.splatinsert479, <8 x i64> poison, <8 x i32> zeroinitializer
  %953 = mul <8 x i64> %.splat480, splat (i64 32)
  %954 = add <8 x i64> %952, %953
  %955 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %951, 0
  %956 = insertvalue { <8 x ptr>, <8 x i64> } %955, <8 x i64> %954, 1
  %957 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %958 = extractvalue { <8 x ptr>, <8 x i64> } %956, 1
  %959 = extractelement <8 x ptr> %957, i32 0
  %960 = extractelement <8 x i64> %958, i32 0
  %961 = sub i64 %960, 0
  %962 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %963 = select i1 %962, i64 %961, i64 0
  %private.contiguous.address481 = getelementptr i8, ptr %959, i64 %963
  %private.contiguous.load482 = load <8 x float>, ptr %private.contiguous.address481, align 4
  %964 = select <8 x i1> %95, <8 x float> %private.contiguous.load482, <8 x float> zeroinitializer
  %965 = add i64 %282, 10
  %tile_snapshot.spill.load483 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %966 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load483, 0
  %967 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load483, 1
  %.splatinsert484 = insertelement <8 x i64> poison, i64 %965, i64 0
  %.splat485 = shufflevector <8 x i64> %.splatinsert484, <8 x i64> poison, <8 x i32> zeroinitializer
  %968 = mul <8 x i64> %.splat485, splat (i64 32)
  %969 = add <8 x i64> %967, %968
  %970 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %966, 0
  %971 = insertvalue { <8 x ptr>, <8 x i64> } %970, <8 x i64> %969, 1
  %972 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %973 = extractvalue { <8 x ptr>, <8 x i64> } %971, 1
  %974 = extractelement <8 x ptr> %972, i32 0
  %975 = extractelement <8 x i64> %973, i32 0
  %976 = sub i64 %975, 0
  %977 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %978 = select i1 %977, i64 %976, i64 0
  %private.contiguous.address486 = getelementptr i8, ptr %974, i64 %978
  %private.contiguous.load487 = load <8 x float>, ptr %private.contiguous.address486, align 4
  %979 = select <8 x i1> %95, <8 x float> %private.contiguous.load487, <8 x float> zeroinitializer
  %980 = add i64 %299, 10
  %tile_snapshot.spill.load488 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %981 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load488, 0
  %982 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load488, 1
  %.splatinsert489 = insertelement <8 x i64> poison, i64 %980, i64 0
  %.splat490 = shufflevector <8 x i64> %.splatinsert489, <8 x i64> poison, <8 x i32> zeroinitializer
  %983 = mul <8 x i64> %.splat490, splat (i64 32)
  %984 = add <8 x i64> %982, %983
  %985 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %981, 0
  %986 = insertvalue { <8 x ptr>, <8 x i64> } %985, <8 x i64> %984, 1
  %987 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %988 = extractvalue { <8 x ptr>, <8 x i64> } %986, 1
  %989 = extractelement <8 x ptr> %987, i32 0
  %990 = extractelement <8 x i64> %988, i32 0
  %991 = sub i64 %990, 0
  %992 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %993 = select i1 %992, i64 %991, i64 0
  %private.contiguous.address491 = getelementptr i8, ptr %989, i64 %993
  %private.contiguous.load492 = load <8 x float>, ptr %private.contiguous.address491, align 4
  %994 = select <8 x i1> %95, <8 x float> %private.contiguous.load492, <8 x float> zeroinitializer
  %995 = fmul <8 x float> %949, %979
  %996 = fadd <8 x float> %928, %995
  %997 = fmul <8 x float> %949, %994
  %998 = fadd <8 x float> %930, %997
  %999 = fmul <8 x float> %964, %979
  %1000 = fadd <8 x float> %932, %999
  %1001 = fmul <8 x float> %964, %994
  %1002 = fadd <8 x float> %934, %1001
  %1003 = add i64 %248, 11
  %tile_snapshot.spill.load493 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1004 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load493, 0
  %1005 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load493, 1
  %.splatinsert494 = insertelement <8 x i64> poison, i64 %1003, i64 0
  %.splat495 = shufflevector <8 x i64> %.splatinsert494, <8 x i64> poison, <8 x i32> zeroinitializer
  %1006 = mul <8 x i64> %.splat495, splat (i64 32)
  %1007 = add <8 x i64> %1005, %1006
  %1008 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1004, 0
  %1009 = insertvalue { <8 x ptr>, <8 x i64> } %1008, <8 x i64> %1007, 1
  %1010 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1011 = extractvalue { <8 x ptr>, <8 x i64> } %1009, 1
  %1012 = extractelement <8 x ptr> %1010, i32 0
  %1013 = extractelement <8 x i64> %1011, i32 0
  %1014 = sub i64 %1013, 0
  %1015 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1016 = select i1 %1015, i64 %1014, i64 0
  %private.contiguous.address496 = getelementptr i8, ptr %1012, i64 %1016
  %private.contiguous.load497 = load <8 x float>, ptr %private.contiguous.address496, align 4
  %1017 = select <8 x i1> %95, <8 x float> %private.contiguous.load497, <8 x float> zeroinitializer
  %1018 = add i64 %265, 11
  %tile_snapshot.spill.load498 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1019 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load498, 0
  %1020 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load498, 1
  %.splatinsert499 = insertelement <8 x i64> poison, i64 %1018, i64 0
  %.splat500 = shufflevector <8 x i64> %.splatinsert499, <8 x i64> poison, <8 x i32> zeroinitializer
  %1021 = mul <8 x i64> %.splat500, splat (i64 32)
  %1022 = add <8 x i64> %1020, %1021
  %1023 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1019, 0
  %1024 = insertvalue { <8 x ptr>, <8 x i64> } %1023, <8 x i64> %1022, 1
  %1025 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1026 = extractvalue { <8 x ptr>, <8 x i64> } %1024, 1
  %1027 = extractelement <8 x ptr> %1025, i32 0
  %1028 = extractelement <8 x i64> %1026, i32 0
  %1029 = sub i64 %1028, 0
  %1030 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1031 = select i1 %1030, i64 %1029, i64 0
  %private.contiguous.address501 = getelementptr i8, ptr %1027, i64 %1031
  %private.contiguous.load502 = load <8 x float>, ptr %private.contiguous.address501, align 4
  %1032 = select <8 x i1> %95, <8 x float> %private.contiguous.load502, <8 x float> zeroinitializer
  %1033 = add i64 %282, 11
  %tile_snapshot.spill.load503 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1034 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load503, 0
  %1035 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load503, 1
  %.splatinsert504 = insertelement <8 x i64> poison, i64 %1033, i64 0
  %.splat505 = shufflevector <8 x i64> %.splatinsert504, <8 x i64> poison, <8 x i32> zeroinitializer
  %1036 = mul <8 x i64> %.splat505, splat (i64 32)
  %1037 = add <8 x i64> %1035, %1036
  %1038 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1034, 0
  %1039 = insertvalue { <8 x ptr>, <8 x i64> } %1038, <8 x i64> %1037, 1
  %1040 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1041 = extractvalue { <8 x ptr>, <8 x i64> } %1039, 1
  %1042 = extractelement <8 x ptr> %1040, i32 0
  %1043 = extractelement <8 x i64> %1041, i32 0
  %1044 = sub i64 %1043, 0
  %1045 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1046 = select i1 %1045, i64 %1044, i64 0
  %private.contiguous.address506 = getelementptr i8, ptr %1042, i64 %1046
  %private.contiguous.load507 = load <8 x float>, ptr %private.contiguous.address506, align 4
  %1047 = select <8 x i1> %95, <8 x float> %private.contiguous.load507, <8 x float> zeroinitializer
  %1048 = add i64 %299, 11
  %tile_snapshot.spill.load508 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1049 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load508, 0
  %1050 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load508, 1
  %.splatinsert509 = insertelement <8 x i64> poison, i64 %1048, i64 0
  %.splat510 = shufflevector <8 x i64> %.splatinsert509, <8 x i64> poison, <8 x i32> zeroinitializer
  %1051 = mul <8 x i64> %.splat510, splat (i64 32)
  %1052 = add <8 x i64> %1050, %1051
  %1053 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1049, 0
  %1054 = insertvalue { <8 x ptr>, <8 x i64> } %1053, <8 x i64> %1052, 1
  %1055 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1056 = extractvalue { <8 x ptr>, <8 x i64> } %1054, 1
  %1057 = extractelement <8 x ptr> %1055, i32 0
  %1058 = extractelement <8 x i64> %1056, i32 0
  %1059 = sub i64 %1058, 0
  %1060 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1061 = select i1 %1060, i64 %1059, i64 0
  %private.contiguous.address511 = getelementptr i8, ptr %1057, i64 %1061
  %private.contiguous.load512 = load <8 x float>, ptr %private.contiguous.address511, align 4
  %1062 = select <8 x i1> %95, <8 x float> %private.contiguous.load512, <8 x float> zeroinitializer
  %1063 = fmul <8 x float> %1017, %1047
  %1064 = fadd <8 x float> %996, %1063
  %1065 = fmul <8 x float> %1017, %1062
  %1066 = fadd <8 x float> %998, %1065
  %1067 = fmul <8 x float> %1032, %1047
  %1068 = fadd <8 x float> %1000, %1067
  %1069 = fmul <8 x float> %1032, %1062
  %1070 = fadd <8 x float> %1002, %1069
  %1071 = add i64 %248, 12
  %tile_snapshot.spill.load513 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1072 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load513, 0
  %1073 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load513, 1
  %.splatinsert514 = insertelement <8 x i64> poison, i64 %1071, i64 0
  %.splat515 = shufflevector <8 x i64> %.splatinsert514, <8 x i64> poison, <8 x i32> zeroinitializer
  %1074 = mul <8 x i64> %.splat515, splat (i64 32)
  %1075 = add <8 x i64> %1073, %1074
  %1076 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1072, 0
  %1077 = insertvalue { <8 x ptr>, <8 x i64> } %1076, <8 x i64> %1075, 1
  %1078 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1079 = extractvalue { <8 x ptr>, <8 x i64> } %1077, 1
  %1080 = extractelement <8 x ptr> %1078, i32 0
  %1081 = extractelement <8 x i64> %1079, i32 0
  %1082 = sub i64 %1081, 0
  %1083 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1084 = select i1 %1083, i64 %1082, i64 0
  %private.contiguous.address516 = getelementptr i8, ptr %1080, i64 %1084
  %private.contiguous.load517 = load <8 x float>, ptr %private.contiguous.address516, align 4
  %1085 = select <8 x i1> %95, <8 x float> %private.contiguous.load517, <8 x float> zeroinitializer
  %1086 = add i64 %265, 12
  %tile_snapshot.spill.load518 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1087 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load518, 0
  %1088 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load518, 1
  %.splatinsert519 = insertelement <8 x i64> poison, i64 %1086, i64 0
  %.splat520 = shufflevector <8 x i64> %.splatinsert519, <8 x i64> poison, <8 x i32> zeroinitializer
  %1089 = mul <8 x i64> %.splat520, splat (i64 32)
  %1090 = add <8 x i64> %1088, %1089
  %1091 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1087, 0
  %1092 = insertvalue { <8 x ptr>, <8 x i64> } %1091, <8 x i64> %1090, 1
  %1093 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1094 = extractvalue { <8 x ptr>, <8 x i64> } %1092, 1
  %1095 = extractelement <8 x ptr> %1093, i32 0
  %1096 = extractelement <8 x i64> %1094, i32 0
  %1097 = sub i64 %1096, 0
  %1098 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1099 = select i1 %1098, i64 %1097, i64 0
  %private.contiguous.address521 = getelementptr i8, ptr %1095, i64 %1099
  %private.contiguous.load522 = load <8 x float>, ptr %private.contiguous.address521, align 4
  %1100 = select <8 x i1> %95, <8 x float> %private.contiguous.load522, <8 x float> zeroinitializer
  %1101 = add i64 %282, 12
  %tile_snapshot.spill.load523 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1102 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load523, 0
  %1103 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load523, 1
  %.splatinsert524 = insertelement <8 x i64> poison, i64 %1101, i64 0
  %.splat525 = shufflevector <8 x i64> %.splatinsert524, <8 x i64> poison, <8 x i32> zeroinitializer
  %1104 = mul <8 x i64> %.splat525, splat (i64 32)
  %1105 = add <8 x i64> %1103, %1104
  %1106 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1102, 0
  %1107 = insertvalue { <8 x ptr>, <8 x i64> } %1106, <8 x i64> %1105, 1
  %1108 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1109 = extractvalue { <8 x ptr>, <8 x i64> } %1107, 1
  %1110 = extractelement <8 x ptr> %1108, i32 0
  %1111 = extractelement <8 x i64> %1109, i32 0
  %1112 = sub i64 %1111, 0
  %1113 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1114 = select i1 %1113, i64 %1112, i64 0
  %private.contiguous.address526 = getelementptr i8, ptr %1110, i64 %1114
  %private.contiguous.load527 = load <8 x float>, ptr %private.contiguous.address526, align 4
  %1115 = select <8 x i1> %95, <8 x float> %private.contiguous.load527, <8 x float> zeroinitializer
  %1116 = add i64 %299, 12
  %tile_snapshot.spill.load528 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1117 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load528, 0
  %1118 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load528, 1
  %.splatinsert529 = insertelement <8 x i64> poison, i64 %1116, i64 0
  %.splat530 = shufflevector <8 x i64> %.splatinsert529, <8 x i64> poison, <8 x i32> zeroinitializer
  %1119 = mul <8 x i64> %.splat530, splat (i64 32)
  %1120 = add <8 x i64> %1118, %1119
  %1121 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1117, 0
  %1122 = insertvalue { <8 x ptr>, <8 x i64> } %1121, <8 x i64> %1120, 1
  %1123 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1124 = extractvalue { <8 x ptr>, <8 x i64> } %1122, 1
  %1125 = extractelement <8 x ptr> %1123, i32 0
  %1126 = extractelement <8 x i64> %1124, i32 0
  %1127 = sub i64 %1126, 0
  %1128 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1129 = select i1 %1128, i64 %1127, i64 0
  %private.contiguous.address531 = getelementptr i8, ptr %1125, i64 %1129
  %private.contiguous.load532 = load <8 x float>, ptr %private.contiguous.address531, align 4
  %1130 = select <8 x i1> %95, <8 x float> %private.contiguous.load532, <8 x float> zeroinitializer
  %1131 = fmul <8 x float> %1085, %1115
  %1132 = fadd <8 x float> %1064, %1131
  %1133 = fmul <8 x float> %1085, %1130
  %1134 = fadd <8 x float> %1066, %1133
  %1135 = fmul <8 x float> %1100, %1115
  %1136 = fadd <8 x float> %1068, %1135
  %1137 = fmul <8 x float> %1100, %1130
  %1138 = fadd <8 x float> %1070, %1137
  %1139 = add i64 %248, 13
  %tile_snapshot.spill.load533 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1140 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load533, 0
  %1141 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load533, 1
  %.splatinsert534 = insertelement <8 x i64> poison, i64 %1139, i64 0
  %.splat535 = shufflevector <8 x i64> %.splatinsert534, <8 x i64> poison, <8 x i32> zeroinitializer
  %1142 = mul <8 x i64> %.splat535, splat (i64 32)
  %1143 = add <8 x i64> %1141, %1142
  %1144 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1140, 0
  %1145 = insertvalue { <8 x ptr>, <8 x i64> } %1144, <8 x i64> %1143, 1
  %1146 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1147 = extractvalue { <8 x ptr>, <8 x i64> } %1145, 1
  %1148 = extractelement <8 x ptr> %1146, i32 0
  %1149 = extractelement <8 x i64> %1147, i32 0
  %1150 = sub i64 %1149, 0
  %1151 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1152 = select i1 %1151, i64 %1150, i64 0
  %private.contiguous.address536 = getelementptr i8, ptr %1148, i64 %1152
  %private.contiguous.load537 = load <8 x float>, ptr %private.contiguous.address536, align 4
  %1153 = select <8 x i1> %95, <8 x float> %private.contiguous.load537, <8 x float> zeroinitializer
  %1154 = add i64 %265, 13
  %tile_snapshot.spill.load538 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1155 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load538, 0
  %1156 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load538, 1
  %.splatinsert539 = insertelement <8 x i64> poison, i64 %1154, i64 0
  %.splat540 = shufflevector <8 x i64> %.splatinsert539, <8 x i64> poison, <8 x i32> zeroinitializer
  %1157 = mul <8 x i64> %.splat540, splat (i64 32)
  %1158 = add <8 x i64> %1156, %1157
  %1159 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1155, 0
  %1160 = insertvalue { <8 x ptr>, <8 x i64> } %1159, <8 x i64> %1158, 1
  %1161 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1162 = extractvalue { <8 x ptr>, <8 x i64> } %1160, 1
  %1163 = extractelement <8 x ptr> %1161, i32 0
  %1164 = extractelement <8 x i64> %1162, i32 0
  %1165 = sub i64 %1164, 0
  %1166 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1167 = select i1 %1166, i64 %1165, i64 0
  %private.contiguous.address541 = getelementptr i8, ptr %1163, i64 %1167
  %private.contiguous.load542 = load <8 x float>, ptr %private.contiguous.address541, align 4
  %1168 = select <8 x i1> %95, <8 x float> %private.contiguous.load542, <8 x float> zeroinitializer
  %1169 = add i64 %282, 13
  %tile_snapshot.spill.load543 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1170 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load543, 0
  %1171 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load543, 1
  %.splatinsert544 = insertelement <8 x i64> poison, i64 %1169, i64 0
  %.splat545 = shufflevector <8 x i64> %.splatinsert544, <8 x i64> poison, <8 x i32> zeroinitializer
  %1172 = mul <8 x i64> %.splat545, splat (i64 32)
  %1173 = add <8 x i64> %1171, %1172
  %1174 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1170, 0
  %1175 = insertvalue { <8 x ptr>, <8 x i64> } %1174, <8 x i64> %1173, 1
  %1176 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1177 = extractvalue { <8 x ptr>, <8 x i64> } %1175, 1
  %1178 = extractelement <8 x ptr> %1176, i32 0
  %1179 = extractelement <8 x i64> %1177, i32 0
  %1180 = sub i64 %1179, 0
  %1181 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1182 = select i1 %1181, i64 %1180, i64 0
  %private.contiguous.address546 = getelementptr i8, ptr %1178, i64 %1182
  %private.contiguous.load547 = load <8 x float>, ptr %private.contiguous.address546, align 4
  %1183 = select <8 x i1> %95, <8 x float> %private.contiguous.load547, <8 x float> zeroinitializer
  %1184 = add i64 %299, 13
  %tile_snapshot.spill.load548 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1185 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load548, 0
  %1186 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load548, 1
  %.splatinsert549 = insertelement <8 x i64> poison, i64 %1184, i64 0
  %.splat550 = shufflevector <8 x i64> %.splatinsert549, <8 x i64> poison, <8 x i32> zeroinitializer
  %1187 = mul <8 x i64> %.splat550, splat (i64 32)
  %1188 = add <8 x i64> %1186, %1187
  %1189 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1185, 0
  %1190 = insertvalue { <8 x ptr>, <8 x i64> } %1189, <8 x i64> %1188, 1
  %1191 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1192 = extractvalue { <8 x ptr>, <8 x i64> } %1190, 1
  %1193 = extractelement <8 x ptr> %1191, i32 0
  %1194 = extractelement <8 x i64> %1192, i32 0
  %1195 = sub i64 %1194, 0
  %1196 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1197 = select i1 %1196, i64 %1195, i64 0
  %private.contiguous.address551 = getelementptr i8, ptr %1193, i64 %1197
  %private.contiguous.load552 = load <8 x float>, ptr %private.contiguous.address551, align 4
  %1198 = select <8 x i1> %95, <8 x float> %private.contiguous.load552, <8 x float> zeroinitializer
  %1199 = fmul <8 x float> %1153, %1183
  %1200 = fadd <8 x float> %1132, %1199
  %1201 = fmul <8 x float> %1153, %1198
  %1202 = fadd <8 x float> %1134, %1201
  %1203 = fmul <8 x float> %1168, %1183
  %1204 = fadd <8 x float> %1136, %1203
  %1205 = fmul <8 x float> %1168, %1198
  %1206 = fadd <8 x float> %1138, %1205
  %1207 = add i64 %248, 14
  %tile_snapshot.spill.load553 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1208 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load553, 0
  %1209 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load553, 1
  %.splatinsert554 = insertelement <8 x i64> poison, i64 %1207, i64 0
  %.splat555 = shufflevector <8 x i64> %.splatinsert554, <8 x i64> poison, <8 x i32> zeroinitializer
  %1210 = mul <8 x i64> %.splat555, splat (i64 32)
  %1211 = add <8 x i64> %1209, %1210
  %1212 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1208, 0
  %1213 = insertvalue { <8 x ptr>, <8 x i64> } %1212, <8 x i64> %1211, 1
  %1214 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1215 = extractvalue { <8 x ptr>, <8 x i64> } %1213, 1
  %1216 = extractelement <8 x ptr> %1214, i32 0
  %1217 = extractelement <8 x i64> %1215, i32 0
  %1218 = sub i64 %1217, 0
  %1219 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1220 = select i1 %1219, i64 %1218, i64 0
  %private.contiguous.address556 = getelementptr i8, ptr %1216, i64 %1220
  %private.contiguous.load557 = load <8 x float>, ptr %private.contiguous.address556, align 4
  %1221 = select <8 x i1> %95, <8 x float> %private.contiguous.load557, <8 x float> zeroinitializer
  %1222 = add i64 %265, 14
  %tile_snapshot.spill.load558 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1223 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load558, 0
  %1224 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load558, 1
  %.splatinsert559 = insertelement <8 x i64> poison, i64 %1222, i64 0
  %.splat560 = shufflevector <8 x i64> %.splatinsert559, <8 x i64> poison, <8 x i32> zeroinitializer
  %1225 = mul <8 x i64> %.splat560, splat (i64 32)
  %1226 = add <8 x i64> %1224, %1225
  %1227 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1223, 0
  %1228 = insertvalue { <8 x ptr>, <8 x i64> } %1227, <8 x i64> %1226, 1
  %1229 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1230 = extractvalue { <8 x ptr>, <8 x i64> } %1228, 1
  %1231 = extractelement <8 x ptr> %1229, i32 0
  %1232 = extractelement <8 x i64> %1230, i32 0
  %1233 = sub i64 %1232, 0
  %1234 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1235 = select i1 %1234, i64 %1233, i64 0
  %private.contiguous.address561 = getelementptr i8, ptr %1231, i64 %1235
  %private.contiguous.load562 = load <8 x float>, ptr %private.contiguous.address561, align 4
  %1236 = select <8 x i1> %95, <8 x float> %private.contiguous.load562, <8 x float> zeroinitializer
  %1237 = add i64 %282, 14
  %tile_snapshot.spill.load563 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1238 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load563, 0
  %1239 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load563, 1
  %.splatinsert564 = insertelement <8 x i64> poison, i64 %1237, i64 0
  %.splat565 = shufflevector <8 x i64> %.splatinsert564, <8 x i64> poison, <8 x i32> zeroinitializer
  %1240 = mul <8 x i64> %.splat565, splat (i64 32)
  %1241 = add <8 x i64> %1239, %1240
  %1242 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1238, 0
  %1243 = insertvalue { <8 x ptr>, <8 x i64> } %1242, <8 x i64> %1241, 1
  %1244 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1245 = extractvalue { <8 x ptr>, <8 x i64> } %1243, 1
  %1246 = extractelement <8 x ptr> %1244, i32 0
  %1247 = extractelement <8 x i64> %1245, i32 0
  %1248 = sub i64 %1247, 0
  %1249 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1250 = select i1 %1249, i64 %1248, i64 0
  %private.contiguous.address566 = getelementptr i8, ptr %1246, i64 %1250
  %private.contiguous.load567 = load <8 x float>, ptr %private.contiguous.address566, align 4
  %1251 = select <8 x i1> %95, <8 x float> %private.contiguous.load567, <8 x float> zeroinitializer
  %1252 = add i64 %299, 14
  %tile_snapshot.spill.load568 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1253 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load568, 0
  %1254 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load568, 1
  %.splatinsert569 = insertelement <8 x i64> poison, i64 %1252, i64 0
  %.splat570 = shufflevector <8 x i64> %.splatinsert569, <8 x i64> poison, <8 x i32> zeroinitializer
  %1255 = mul <8 x i64> %.splat570, splat (i64 32)
  %1256 = add <8 x i64> %1254, %1255
  %1257 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1253, 0
  %1258 = insertvalue { <8 x ptr>, <8 x i64> } %1257, <8 x i64> %1256, 1
  %1259 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1260 = extractvalue { <8 x ptr>, <8 x i64> } %1258, 1
  %1261 = extractelement <8 x ptr> %1259, i32 0
  %1262 = extractelement <8 x i64> %1260, i32 0
  %1263 = sub i64 %1262, 0
  %1264 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1265 = select i1 %1264, i64 %1263, i64 0
  %private.contiguous.address571 = getelementptr i8, ptr %1261, i64 %1265
  %private.contiguous.load572 = load <8 x float>, ptr %private.contiguous.address571, align 4
  %1266 = select <8 x i1> %95, <8 x float> %private.contiguous.load572, <8 x float> zeroinitializer
  %1267 = fmul <8 x float> %1221, %1251
  %1268 = fadd <8 x float> %1200, %1267
  %1269 = fmul <8 x float> %1221, %1266
  %1270 = fadd <8 x float> %1202, %1269
  %1271 = fmul <8 x float> %1236, %1251
  %1272 = fadd <8 x float> %1204, %1271
  %1273 = fmul <8 x float> %1236, %1266
  %1274 = fadd <8 x float> %1206, %1273
  %1275 = add i64 %248, 15
  %tile_snapshot.spill.load573 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1276 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load573, 0
  %1277 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load573, 1
  %.splatinsert574 = insertelement <8 x i64> poison, i64 %1275, i64 0
  %.splat575 = shufflevector <8 x i64> %.splatinsert574, <8 x i64> poison, <8 x i32> zeroinitializer
  %1278 = mul <8 x i64> %.splat575, splat (i64 32)
  %1279 = add <8 x i64> %1277, %1278
  %1280 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1276, 0
  %1281 = insertvalue { <8 x ptr>, <8 x i64> } %1280, <8 x i64> %1279, 1
  %1282 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1283 = extractvalue { <8 x ptr>, <8 x i64> } %1281, 1
  %1284 = extractelement <8 x ptr> %1282, i32 0
  %1285 = extractelement <8 x i64> %1283, i32 0
  %1286 = sub i64 %1285, 0
  %1287 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1288 = select i1 %1287, i64 %1286, i64 0
  %private.contiguous.address576 = getelementptr i8, ptr %1284, i64 %1288
  %private.contiguous.load577 = load <8 x float>, ptr %private.contiguous.address576, align 4
  %1289 = select <8 x i1> %95, <8 x float> %private.contiguous.load577, <8 x float> zeroinitializer
  %1290 = add i64 %265, 15
  %tile_snapshot.spill.load578 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1291 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load578, 0
  %1292 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load578, 1
  %.splatinsert579 = insertelement <8 x i64> poison, i64 %1290, i64 0
  %.splat580 = shufflevector <8 x i64> %.splatinsert579, <8 x i64> poison, <8 x i32> zeroinitializer
  %1293 = mul <8 x i64> %.splat580, splat (i64 32)
  %1294 = add <8 x i64> %1292, %1293
  %1295 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1291, 0
  %1296 = insertvalue { <8 x ptr>, <8 x i64> } %1295, <8 x i64> %1294, 1
  %1297 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1298 = extractvalue { <8 x ptr>, <8 x i64> } %1296, 1
  %1299 = extractelement <8 x ptr> %1297, i32 0
  %1300 = extractelement <8 x i64> %1298, i32 0
  %1301 = sub i64 %1300, 0
  %1302 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1303 = select i1 %1302, i64 %1301, i64 0
  %private.contiguous.address581 = getelementptr i8, ptr %1299, i64 %1303
  %private.contiguous.load582 = load <8 x float>, ptr %private.contiguous.address581, align 4
  %1304 = select <8 x i1> %95, <8 x float> %private.contiguous.load582, <8 x float> zeroinitializer
  %1305 = add i64 %282, 15
  %tile_snapshot.spill.load583 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1306 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load583, 0
  %1307 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load583, 1
  %.splatinsert584 = insertelement <8 x i64> poison, i64 %1305, i64 0
  %.splat585 = shufflevector <8 x i64> %.splatinsert584, <8 x i64> poison, <8 x i32> zeroinitializer
  %1308 = mul <8 x i64> %.splat585, splat (i64 32)
  %1309 = add <8 x i64> %1307, %1308
  %1310 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1306, 0
  %1311 = insertvalue { <8 x ptr>, <8 x i64> } %1310, <8 x i64> %1309, 1
  %1312 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1313 = extractvalue { <8 x ptr>, <8 x i64> } %1311, 1
  %1314 = extractelement <8 x ptr> %1312, i32 0
  %1315 = extractelement <8 x i64> %1313, i32 0
  %1316 = sub i64 %1315, 0
  %1317 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1318 = select i1 %1317, i64 %1316, i64 0
  %private.contiguous.address586 = getelementptr i8, ptr %1314, i64 %1318
  %private.contiguous.load587 = load <8 x float>, ptr %private.contiguous.address586, align 4
  %1319 = select <8 x i1> %95, <8 x float> %private.contiguous.load587, <8 x float> zeroinitializer
  %1320 = add i64 %299, 15
  %tile_snapshot.spill.load588 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1321 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load588, 0
  %1322 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load588, 1
  %.splatinsert589 = insertelement <8 x i64> poison, i64 %1320, i64 0
  %.splat590 = shufflevector <8 x i64> %.splatinsert589, <8 x i64> poison, <8 x i32> zeroinitializer
  %1323 = mul <8 x i64> %.splat590, splat (i64 32)
  %1324 = add <8 x i64> %1322, %1323
  %1325 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1321, 0
  %1326 = insertvalue { <8 x ptr>, <8 x i64> } %1325, <8 x i64> %1324, 1
  %1327 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1328 = extractvalue { <8 x ptr>, <8 x i64> } %1326, 1
  %1329 = extractelement <8 x ptr> %1327, i32 0
  %1330 = extractelement <8 x i64> %1328, i32 0
  %1331 = sub i64 %1330, 0
  %1332 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1333 = select i1 %1332, i64 %1331, i64 0
  %private.contiguous.address591 = getelementptr i8, ptr %1329, i64 %1333
  %private.contiguous.load592 = load <8 x float>, ptr %private.contiguous.address591, align 4
  %1334 = select <8 x i1> %95, <8 x float> %private.contiguous.load592, <8 x float> zeroinitializer
  %1335 = fmul <8 x float> %1289, %1319
  %1336 = fadd <8 x float> %1268, %1335
  %1337 = fmul <8 x float> %1289, %1334
  %1338 = fadd <8 x float> %1270, %1337
  %1339 = fmul <8 x float> %1304, %1319
  %1340 = fadd <8 x float> %1272, %1339
  %1341 = fmul <8 x float> %1304, %1334
  %1342 = fadd <8 x float> %1274, %1341
  %1343 = add i64 %248, 16
  %tile_snapshot.spill.load593 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1344 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load593, 0
  %1345 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load593, 1
  %.splatinsert594 = insertelement <8 x i64> poison, i64 %1343, i64 0
  %.splat595 = shufflevector <8 x i64> %.splatinsert594, <8 x i64> poison, <8 x i32> zeroinitializer
  %1346 = mul <8 x i64> %.splat595, splat (i64 32)
  %1347 = add <8 x i64> %1345, %1346
  %1348 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1344, 0
  %1349 = insertvalue { <8 x ptr>, <8 x i64> } %1348, <8 x i64> %1347, 1
  %1350 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1351 = extractvalue { <8 x ptr>, <8 x i64> } %1349, 1
  %1352 = extractelement <8 x ptr> %1350, i32 0
  %1353 = extractelement <8 x i64> %1351, i32 0
  %1354 = sub i64 %1353, 0
  %1355 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1356 = select i1 %1355, i64 %1354, i64 0
  %private.contiguous.address596 = getelementptr i8, ptr %1352, i64 %1356
  %private.contiguous.load597 = load <8 x float>, ptr %private.contiguous.address596, align 4
  %1357 = select <8 x i1> %95, <8 x float> %private.contiguous.load597, <8 x float> zeroinitializer
  %1358 = add i64 %265, 16
  %tile_snapshot.spill.load598 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1359 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load598, 0
  %1360 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load598, 1
  %.splatinsert599 = insertelement <8 x i64> poison, i64 %1358, i64 0
  %.splat600 = shufflevector <8 x i64> %.splatinsert599, <8 x i64> poison, <8 x i32> zeroinitializer
  %1361 = mul <8 x i64> %.splat600, splat (i64 32)
  %1362 = add <8 x i64> %1360, %1361
  %1363 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1359, 0
  %1364 = insertvalue { <8 x ptr>, <8 x i64> } %1363, <8 x i64> %1362, 1
  %1365 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1366 = extractvalue { <8 x ptr>, <8 x i64> } %1364, 1
  %1367 = extractelement <8 x ptr> %1365, i32 0
  %1368 = extractelement <8 x i64> %1366, i32 0
  %1369 = sub i64 %1368, 0
  %1370 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1371 = select i1 %1370, i64 %1369, i64 0
  %private.contiguous.address601 = getelementptr i8, ptr %1367, i64 %1371
  %private.contiguous.load602 = load <8 x float>, ptr %private.contiguous.address601, align 4
  %1372 = select <8 x i1> %95, <8 x float> %private.contiguous.load602, <8 x float> zeroinitializer
  %1373 = add i64 %282, 16
  %tile_snapshot.spill.load603 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1374 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load603, 0
  %1375 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load603, 1
  %.splatinsert604 = insertelement <8 x i64> poison, i64 %1373, i64 0
  %.splat605 = shufflevector <8 x i64> %.splatinsert604, <8 x i64> poison, <8 x i32> zeroinitializer
  %1376 = mul <8 x i64> %.splat605, splat (i64 32)
  %1377 = add <8 x i64> %1375, %1376
  %1378 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1374, 0
  %1379 = insertvalue { <8 x ptr>, <8 x i64> } %1378, <8 x i64> %1377, 1
  %1380 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1381 = extractvalue { <8 x ptr>, <8 x i64> } %1379, 1
  %1382 = extractelement <8 x ptr> %1380, i32 0
  %1383 = extractelement <8 x i64> %1381, i32 0
  %1384 = sub i64 %1383, 0
  %1385 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1386 = select i1 %1385, i64 %1384, i64 0
  %private.contiguous.address606 = getelementptr i8, ptr %1382, i64 %1386
  %private.contiguous.load607 = load <8 x float>, ptr %private.contiguous.address606, align 4
  %1387 = select <8 x i1> %95, <8 x float> %private.contiguous.load607, <8 x float> zeroinitializer
  %1388 = add i64 %299, 16
  %tile_snapshot.spill.load608 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1389 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load608, 0
  %1390 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load608, 1
  %.splatinsert609 = insertelement <8 x i64> poison, i64 %1388, i64 0
  %.splat610 = shufflevector <8 x i64> %.splatinsert609, <8 x i64> poison, <8 x i32> zeroinitializer
  %1391 = mul <8 x i64> %.splat610, splat (i64 32)
  %1392 = add <8 x i64> %1390, %1391
  %1393 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1389, 0
  %1394 = insertvalue { <8 x ptr>, <8 x i64> } %1393, <8 x i64> %1392, 1
  %1395 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1396 = extractvalue { <8 x ptr>, <8 x i64> } %1394, 1
  %1397 = extractelement <8 x ptr> %1395, i32 0
  %1398 = extractelement <8 x i64> %1396, i32 0
  %1399 = sub i64 %1398, 0
  %1400 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1401 = select i1 %1400, i64 %1399, i64 0
  %private.contiguous.address611 = getelementptr i8, ptr %1397, i64 %1401
  %private.contiguous.load612 = load <8 x float>, ptr %private.contiguous.address611, align 4
  %1402 = select <8 x i1> %95, <8 x float> %private.contiguous.load612, <8 x float> zeroinitializer
  %1403 = fmul <8 x float> %1357, %1387
  %1404 = fadd <8 x float> %1336, %1403
  %1405 = fmul <8 x float> %1357, %1402
  %1406 = fadd <8 x float> %1338, %1405
  %1407 = fmul <8 x float> %1372, %1387
  %1408 = fadd <8 x float> %1340, %1407
  %1409 = fmul <8 x float> %1372, %1402
  %1410 = fadd <8 x float> %1342, %1409
  %1411 = add i64 %248, 17
  %tile_snapshot.spill.load613 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1412 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load613, 0
  %1413 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load613, 1
  %.splatinsert614 = insertelement <8 x i64> poison, i64 %1411, i64 0
  %.splat615 = shufflevector <8 x i64> %.splatinsert614, <8 x i64> poison, <8 x i32> zeroinitializer
  %1414 = mul <8 x i64> %.splat615, splat (i64 32)
  %1415 = add <8 x i64> %1413, %1414
  %1416 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1412, 0
  %1417 = insertvalue { <8 x ptr>, <8 x i64> } %1416, <8 x i64> %1415, 1
  %1418 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1419 = extractvalue { <8 x ptr>, <8 x i64> } %1417, 1
  %1420 = extractelement <8 x ptr> %1418, i32 0
  %1421 = extractelement <8 x i64> %1419, i32 0
  %1422 = sub i64 %1421, 0
  %1423 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1424 = select i1 %1423, i64 %1422, i64 0
  %private.contiguous.address616 = getelementptr i8, ptr %1420, i64 %1424
  %private.contiguous.load617 = load <8 x float>, ptr %private.contiguous.address616, align 4
  %1425 = select <8 x i1> %95, <8 x float> %private.contiguous.load617, <8 x float> zeroinitializer
  %1426 = add i64 %265, 17
  %tile_snapshot.spill.load618 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1427 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load618, 0
  %1428 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load618, 1
  %.splatinsert619 = insertelement <8 x i64> poison, i64 %1426, i64 0
  %.splat620 = shufflevector <8 x i64> %.splatinsert619, <8 x i64> poison, <8 x i32> zeroinitializer
  %1429 = mul <8 x i64> %.splat620, splat (i64 32)
  %1430 = add <8 x i64> %1428, %1429
  %1431 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1427, 0
  %1432 = insertvalue { <8 x ptr>, <8 x i64> } %1431, <8 x i64> %1430, 1
  %1433 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1434 = extractvalue { <8 x ptr>, <8 x i64> } %1432, 1
  %1435 = extractelement <8 x ptr> %1433, i32 0
  %1436 = extractelement <8 x i64> %1434, i32 0
  %1437 = sub i64 %1436, 0
  %1438 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1439 = select i1 %1438, i64 %1437, i64 0
  %private.contiguous.address621 = getelementptr i8, ptr %1435, i64 %1439
  %private.contiguous.load622 = load <8 x float>, ptr %private.contiguous.address621, align 4
  %1440 = select <8 x i1> %95, <8 x float> %private.contiguous.load622, <8 x float> zeroinitializer
  %1441 = add i64 %282, 17
  %tile_snapshot.spill.load623 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1442 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load623, 0
  %1443 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load623, 1
  %.splatinsert624 = insertelement <8 x i64> poison, i64 %1441, i64 0
  %.splat625 = shufflevector <8 x i64> %.splatinsert624, <8 x i64> poison, <8 x i32> zeroinitializer
  %1444 = mul <8 x i64> %.splat625, splat (i64 32)
  %1445 = add <8 x i64> %1443, %1444
  %1446 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1442, 0
  %1447 = insertvalue { <8 x ptr>, <8 x i64> } %1446, <8 x i64> %1445, 1
  %1448 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1449 = extractvalue { <8 x ptr>, <8 x i64> } %1447, 1
  %1450 = extractelement <8 x ptr> %1448, i32 0
  %1451 = extractelement <8 x i64> %1449, i32 0
  %1452 = sub i64 %1451, 0
  %1453 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1454 = select i1 %1453, i64 %1452, i64 0
  %private.contiguous.address626 = getelementptr i8, ptr %1450, i64 %1454
  %private.contiguous.load627 = load <8 x float>, ptr %private.contiguous.address626, align 4
  %1455 = select <8 x i1> %95, <8 x float> %private.contiguous.load627, <8 x float> zeroinitializer
  %1456 = add i64 %299, 17
  %tile_snapshot.spill.load628 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1457 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load628, 0
  %1458 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load628, 1
  %.splatinsert629 = insertelement <8 x i64> poison, i64 %1456, i64 0
  %.splat630 = shufflevector <8 x i64> %.splatinsert629, <8 x i64> poison, <8 x i32> zeroinitializer
  %1459 = mul <8 x i64> %.splat630, splat (i64 32)
  %1460 = add <8 x i64> %1458, %1459
  %1461 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1457, 0
  %1462 = insertvalue { <8 x ptr>, <8 x i64> } %1461, <8 x i64> %1460, 1
  %1463 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1464 = extractvalue { <8 x ptr>, <8 x i64> } %1462, 1
  %1465 = extractelement <8 x ptr> %1463, i32 0
  %1466 = extractelement <8 x i64> %1464, i32 0
  %1467 = sub i64 %1466, 0
  %1468 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1469 = select i1 %1468, i64 %1467, i64 0
  %private.contiguous.address631 = getelementptr i8, ptr %1465, i64 %1469
  %private.contiguous.load632 = load <8 x float>, ptr %private.contiguous.address631, align 4
  %1470 = select <8 x i1> %95, <8 x float> %private.contiguous.load632, <8 x float> zeroinitializer
  %1471 = fmul <8 x float> %1425, %1455
  %1472 = fadd <8 x float> %1404, %1471
  %1473 = fmul <8 x float> %1425, %1470
  %1474 = fadd <8 x float> %1406, %1473
  %1475 = fmul <8 x float> %1440, %1455
  %1476 = fadd <8 x float> %1408, %1475
  %1477 = fmul <8 x float> %1440, %1470
  %1478 = fadd <8 x float> %1410, %1477
  %1479 = add i64 %248, 18
  %tile_snapshot.spill.load633 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1480 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load633, 0
  %1481 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load633, 1
  %.splatinsert634 = insertelement <8 x i64> poison, i64 %1479, i64 0
  %.splat635 = shufflevector <8 x i64> %.splatinsert634, <8 x i64> poison, <8 x i32> zeroinitializer
  %1482 = mul <8 x i64> %.splat635, splat (i64 32)
  %1483 = add <8 x i64> %1481, %1482
  %1484 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1480, 0
  %1485 = insertvalue { <8 x ptr>, <8 x i64> } %1484, <8 x i64> %1483, 1
  %1486 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1487 = extractvalue { <8 x ptr>, <8 x i64> } %1485, 1
  %1488 = extractelement <8 x ptr> %1486, i32 0
  %1489 = extractelement <8 x i64> %1487, i32 0
  %1490 = sub i64 %1489, 0
  %1491 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1492 = select i1 %1491, i64 %1490, i64 0
  %private.contiguous.address636 = getelementptr i8, ptr %1488, i64 %1492
  %private.contiguous.load637 = load <8 x float>, ptr %private.contiguous.address636, align 4
  %1493 = select <8 x i1> %95, <8 x float> %private.contiguous.load637, <8 x float> zeroinitializer
  %1494 = add i64 %265, 18
  %tile_snapshot.spill.load638 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1495 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load638, 0
  %1496 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load638, 1
  %.splatinsert639 = insertelement <8 x i64> poison, i64 %1494, i64 0
  %.splat640 = shufflevector <8 x i64> %.splatinsert639, <8 x i64> poison, <8 x i32> zeroinitializer
  %1497 = mul <8 x i64> %.splat640, splat (i64 32)
  %1498 = add <8 x i64> %1496, %1497
  %1499 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1495, 0
  %1500 = insertvalue { <8 x ptr>, <8 x i64> } %1499, <8 x i64> %1498, 1
  %1501 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1502 = extractvalue { <8 x ptr>, <8 x i64> } %1500, 1
  %1503 = extractelement <8 x ptr> %1501, i32 0
  %1504 = extractelement <8 x i64> %1502, i32 0
  %1505 = sub i64 %1504, 0
  %1506 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1507 = select i1 %1506, i64 %1505, i64 0
  %private.contiguous.address641 = getelementptr i8, ptr %1503, i64 %1507
  %private.contiguous.load642 = load <8 x float>, ptr %private.contiguous.address641, align 4
  %1508 = select <8 x i1> %95, <8 x float> %private.contiguous.load642, <8 x float> zeroinitializer
  %1509 = add i64 %282, 18
  %tile_snapshot.spill.load643 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1510 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load643, 0
  %1511 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load643, 1
  %.splatinsert644 = insertelement <8 x i64> poison, i64 %1509, i64 0
  %.splat645 = shufflevector <8 x i64> %.splatinsert644, <8 x i64> poison, <8 x i32> zeroinitializer
  %1512 = mul <8 x i64> %.splat645, splat (i64 32)
  %1513 = add <8 x i64> %1511, %1512
  %1514 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1510, 0
  %1515 = insertvalue { <8 x ptr>, <8 x i64> } %1514, <8 x i64> %1513, 1
  %1516 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1517 = extractvalue { <8 x ptr>, <8 x i64> } %1515, 1
  %1518 = extractelement <8 x ptr> %1516, i32 0
  %1519 = extractelement <8 x i64> %1517, i32 0
  %1520 = sub i64 %1519, 0
  %1521 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1522 = select i1 %1521, i64 %1520, i64 0
  %private.contiguous.address646 = getelementptr i8, ptr %1518, i64 %1522
  %private.contiguous.load647 = load <8 x float>, ptr %private.contiguous.address646, align 4
  %1523 = select <8 x i1> %95, <8 x float> %private.contiguous.load647, <8 x float> zeroinitializer
  %1524 = add i64 %299, 18
  %tile_snapshot.spill.load648 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1525 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load648, 0
  %1526 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load648, 1
  %.splatinsert649 = insertelement <8 x i64> poison, i64 %1524, i64 0
  %.splat650 = shufflevector <8 x i64> %.splatinsert649, <8 x i64> poison, <8 x i32> zeroinitializer
  %1527 = mul <8 x i64> %.splat650, splat (i64 32)
  %1528 = add <8 x i64> %1526, %1527
  %1529 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1525, 0
  %1530 = insertvalue { <8 x ptr>, <8 x i64> } %1529, <8 x i64> %1528, 1
  %1531 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1532 = extractvalue { <8 x ptr>, <8 x i64> } %1530, 1
  %1533 = extractelement <8 x ptr> %1531, i32 0
  %1534 = extractelement <8 x i64> %1532, i32 0
  %1535 = sub i64 %1534, 0
  %1536 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1537 = select i1 %1536, i64 %1535, i64 0
  %private.contiguous.address651 = getelementptr i8, ptr %1533, i64 %1537
  %private.contiguous.load652 = load <8 x float>, ptr %private.contiguous.address651, align 4
  %1538 = select <8 x i1> %95, <8 x float> %private.contiguous.load652, <8 x float> zeroinitializer
  %1539 = fmul <8 x float> %1493, %1523
  %1540 = fadd <8 x float> %1472, %1539
  %1541 = fmul <8 x float> %1493, %1538
  %1542 = fadd <8 x float> %1474, %1541
  %1543 = fmul <8 x float> %1508, %1523
  %1544 = fadd <8 x float> %1476, %1543
  %1545 = fmul <8 x float> %1508, %1538
  %1546 = fadd <8 x float> %1478, %1545
  %1547 = add i64 %248, 19
  %tile_snapshot.spill.load653 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1548 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load653, 0
  %1549 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load653, 1
  %.splatinsert654 = insertelement <8 x i64> poison, i64 %1547, i64 0
  %.splat655 = shufflevector <8 x i64> %.splatinsert654, <8 x i64> poison, <8 x i32> zeroinitializer
  %1550 = mul <8 x i64> %.splat655, splat (i64 32)
  %1551 = add <8 x i64> %1549, %1550
  %1552 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1548, 0
  %1553 = insertvalue { <8 x ptr>, <8 x i64> } %1552, <8 x i64> %1551, 1
  %1554 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1555 = extractvalue { <8 x ptr>, <8 x i64> } %1553, 1
  %1556 = extractelement <8 x ptr> %1554, i32 0
  %1557 = extractelement <8 x i64> %1555, i32 0
  %1558 = sub i64 %1557, 0
  %1559 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1560 = select i1 %1559, i64 %1558, i64 0
  %private.contiguous.address656 = getelementptr i8, ptr %1556, i64 %1560
  %private.contiguous.load657 = load <8 x float>, ptr %private.contiguous.address656, align 4
  %1561 = select <8 x i1> %95, <8 x float> %private.contiguous.load657, <8 x float> zeroinitializer
  %1562 = add i64 %265, 19
  %tile_snapshot.spill.load658 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1563 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load658, 0
  %1564 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load658, 1
  %.splatinsert659 = insertelement <8 x i64> poison, i64 %1562, i64 0
  %.splat660 = shufflevector <8 x i64> %.splatinsert659, <8 x i64> poison, <8 x i32> zeroinitializer
  %1565 = mul <8 x i64> %.splat660, splat (i64 32)
  %1566 = add <8 x i64> %1564, %1565
  %1567 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1563, 0
  %1568 = insertvalue { <8 x ptr>, <8 x i64> } %1567, <8 x i64> %1566, 1
  %1569 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1570 = extractvalue { <8 x ptr>, <8 x i64> } %1568, 1
  %1571 = extractelement <8 x ptr> %1569, i32 0
  %1572 = extractelement <8 x i64> %1570, i32 0
  %1573 = sub i64 %1572, 0
  %1574 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1575 = select i1 %1574, i64 %1573, i64 0
  %private.contiguous.address661 = getelementptr i8, ptr %1571, i64 %1575
  %private.contiguous.load662 = load <8 x float>, ptr %private.contiguous.address661, align 4
  %1576 = select <8 x i1> %95, <8 x float> %private.contiguous.load662, <8 x float> zeroinitializer
  %1577 = add i64 %282, 19
  %tile_snapshot.spill.load663 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1578 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load663, 0
  %1579 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load663, 1
  %.splatinsert664 = insertelement <8 x i64> poison, i64 %1577, i64 0
  %.splat665 = shufflevector <8 x i64> %.splatinsert664, <8 x i64> poison, <8 x i32> zeroinitializer
  %1580 = mul <8 x i64> %.splat665, splat (i64 32)
  %1581 = add <8 x i64> %1579, %1580
  %1582 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1578, 0
  %1583 = insertvalue { <8 x ptr>, <8 x i64> } %1582, <8 x i64> %1581, 1
  %1584 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1585 = extractvalue { <8 x ptr>, <8 x i64> } %1583, 1
  %1586 = extractelement <8 x ptr> %1584, i32 0
  %1587 = extractelement <8 x i64> %1585, i32 0
  %1588 = sub i64 %1587, 0
  %1589 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1590 = select i1 %1589, i64 %1588, i64 0
  %private.contiguous.address666 = getelementptr i8, ptr %1586, i64 %1590
  %private.contiguous.load667 = load <8 x float>, ptr %private.contiguous.address666, align 4
  %1591 = select <8 x i1> %95, <8 x float> %private.contiguous.load667, <8 x float> zeroinitializer
  %1592 = add i64 %299, 19
  %tile_snapshot.spill.load668 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1593 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load668, 0
  %1594 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load668, 1
  %.splatinsert669 = insertelement <8 x i64> poison, i64 %1592, i64 0
  %.splat670 = shufflevector <8 x i64> %.splatinsert669, <8 x i64> poison, <8 x i32> zeroinitializer
  %1595 = mul <8 x i64> %.splat670, splat (i64 32)
  %1596 = add <8 x i64> %1594, %1595
  %1597 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1593, 0
  %1598 = insertvalue { <8 x ptr>, <8 x i64> } %1597, <8 x i64> %1596, 1
  %1599 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1600 = extractvalue { <8 x ptr>, <8 x i64> } %1598, 1
  %1601 = extractelement <8 x ptr> %1599, i32 0
  %1602 = extractelement <8 x i64> %1600, i32 0
  %1603 = sub i64 %1602, 0
  %1604 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1605 = select i1 %1604, i64 %1603, i64 0
  %private.contiguous.address671 = getelementptr i8, ptr %1601, i64 %1605
  %private.contiguous.load672 = load <8 x float>, ptr %private.contiguous.address671, align 4
  %1606 = select <8 x i1> %95, <8 x float> %private.contiguous.load672, <8 x float> zeroinitializer
  %1607 = fmul <8 x float> %1561, %1591
  %1608 = fadd <8 x float> %1540, %1607
  %1609 = fmul <8 x float> %1561, %1606
  %1610 = fadd <8 x float> %1542, %1609
  %1611 = fmul <8 x float> %1576, %1591
  %1612 = fadd <8 x float> %1544, %1611
  %1613 = fmul <8 x float> %1576, %1606
  %1614 = fadd <8 x float> %1546, %1613
  %1615 = add i64 %248, 20
  %tile_snapshot.spill.load673 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1616 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load673, 0
  %1617 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load673, 1
  %.splatinsert674 = insertelement <8 x i64> poison, i64 %1615, i64 0
  %.splat675 = shufflevector <8 x i64> %.splatinsert674, <8 x i64> poison, <8 x i32> zeroinitializer
  %1618 = mul <8 x i64> %.splat675, splat (i64 32)
  %1619 = add <8 x i64> %1617, %1618
  %1620 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1616, 0
  %1621 = insertvalue { <8 x ptr>, <8 x i64> } %1620, <8 x i64> %1619, 1
  %1622 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1623 = extractvalue { <8 x ptr>, <8 x i64> } %1621, 1
  %1624 = extractelement <8 x ptr> %1622, i32 0
  %1625 = extractelement <8 x i64> %1623, i32 0
  %1626 = sub i64 %1625, 0
  %1627 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1628 = select i1 %1627, i64 %1626, i64 0
  %private.contiguous.address676 = getelementptr i8, ptr %1624, i64 %1628
  %private.contiguous.load677 = load <8 x float>, ptr %private.contiguous.address676, align 4
  %1629 = select <8 x i1> %95, <8 x float> %private.contiguous.load677, <8 x float> zeroinitializer
  %1630 = add i64 %265, 20
  %tile_snapshot.spill.load678 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1631 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load678, 0
  %1632 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load678, 1
  %.splatinsert679 = insertelement <8 x i64> poison, i64 %1630, i64 0
  %.splat680 = shufflevector <8 x i64> %.splatinsert679, <8 x i64> poison, <8 x i32> zeroinitializer
  %1633 = mul <8 x i64> %.splat680, splat (i64 32)
  %1634 = add <8 x i64> %1632, %1633
  %1635 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1631, 0
  %1636 = insertvalue { <8 x ptr>, <8 x i64> } %1635, <8 x i64> %1634, 1
  %1637 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1638 = extractvalue { <8 x ptr>, <8 x i64> } %1636, 1
  %1639 = extractelement <8 x ptr> %1637, i32 0
  %1640 = extractelement <8 x i64> %1638, i32 0
  %1641 = sub i64 %1640, 0
  %1642 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1643 = select i1 %1642, i64 %1641, i64 0
  %private.contiguous.address681 = getelementptr i8, ptr %1639, i64 %1643
  %private.contiguous.load682 = load <8 x float>, ptr %private.contiguous.address681, align 4
  %1644 = select <8 x i1> %95, <8 x float> %private.contiguous.load682, <8 x float> zeroinitializer
  %1645 = add i64 %282, 20
  %tile_snapshot.spill.load683 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1646 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load683, 0
  %1647 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load683, 1
  %.splatinsert684 = insertelement <8 x i64> poison, i64 %1645, i64 0
  %.splat685 = shufflevector <8 x i64> %.splatinsert684, <8 x i64> poison, <8 x i32> zeroinitializer
  %1648 = mul <8 x i64> %.splat685, splat (i64 32)
  %1649 = add <8 x i64> %1647, %1648
  %1650 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1646, 0
  %1651 = insertvalue { <8 x ptr>, <8 x i64> } %1650, <8 x i64> %1649, 1
  %1652 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1653 = extractvalue { <8 x ptr>, <8 x i64> } %1651, 1
  %1654 = extractelement <8 x ptr> %1652, i32 0
  %1655 = extractelement <8 x i64> %1653, i32 0
  %1656 = sub i64 %1655, 0
  %1657 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1658 = select i1 %1657, i64 %1656, i64 0
  %private.contiguous.address686 = getelementptr i8, ptr %1654, i64 %1658
  %private.contiguous.load687 = load <8 x float>, ptr %private.contiguous.address686, align 4
  %1659 = select <8 x i1> %95, <8 x float> %private.contiguous.load687, <8 x float> zeroinitializer
  %1660 = add i64 %299, 20
  %tile_snapshot.spill.load688 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1661 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load688, 0
  %1662 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load688, 1
  %.splatinsert689 = insertelement <8 x i64> poison, i64 %1660, i64 0
  %.splat690 = shufflevector <8 x i64> %.splatinsert689, <8 x i64> poison, <8 x i32> zeroinitializer
  %1663 = mul <8 x i64> %.splat690, splat (i64 32)
  %1664 = add <8 x i64> %1662, %1663
  %1665 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1661, 0
  %1666 = insertvalue { <8 x ptr>, <8 x i64> } %1665, <8 x i64> %1664, 1
  %1667 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1668 = extractvalue { <8 x ptr>, <8 x i64> } %1666, 1
  %1669 = extractelement <8 x ptr> %1667, i32 0
  %1670 = extractelement <8 x i64> %1668, i32 0
  %1671 = sub i64 %1670, 0
  %1672 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1673 = select i1 %1672, i64 %1671, i64 0
  %private.contiguous.address691 = getelementptr i8, ptr %1669, i64 %1673
  %private.contiguous.load692 = load <8 x float>, ptr %private.contiguous.address691, align 4
  %1674 = select <8 x i1> %95, <8 x float> %private.contiguous.load692, <8 x float> zeroinitializer
  %1675 = fmul <8 x float> %1629, %1659
  %1676 = fadd <8 x float> %1608, %1675
  %1677 = fmul <8 x float> %1629, %1674
  %1678 = fadd <8 x float> %1610, %1677
  %1679 = fmul <8 x float> %1644, %1659
  %1680 = fadd <8 x float> %1612, %1679
  %1681 = fmul <8 x float> %1644, %1674
  %1682 = fadd <8 x float> %1614, %1681
  %1683 = add i64 %248, 21
  %tile_snapshot.spill.load693 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1684 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load693, 0
  %1685 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load693, 1
  %.splatinsert694 = insertelement <8 x i64> poison, i64 %1683, i64 0
  %.splat695 = shufflevector <8 x i64> %.splatinsert694, <8 x i64> poison, <8 x i32> zeroinitializer
  %1686 = mul <8 x i64> %.splat695, splat (i64 32)
  %1687 = add <8 x i64> %1685, %1686
  %1688 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1684, 0
  %1689 = insertvalue { <8 x ptr>, <8 x i64> } %1688, <8 x i64> %1687, 1
  %1690 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1691 = extractvalue { <8 x ptr>, <8 x i64> } %1689, 1
  %1692 = extractelement <8 x ptr> %1690, i32 0
  %1693 = extractelement <8 x i64> %1691, i32 0
  %1694 = sub i64 %1693, 0
  %1695 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1696 = select i1 %1695, i64 %1694, i64 0
  %private.contiguous.address696 = getelementptr i8, ptr %1692, i64 %1696
  %private.contiguous.load697 = load <8 x float>, ptr %private.contiguous.address696, align 4
  %1697 = select <8 x i1> %95, <8 x float> %private.contiguous.load697, <8 x float> zeroinitializer
  %1698 = add i64 %265, 21
  %tile_snapshot.spill.load698 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1699 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load698, 0
  %1700 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load698, 1
  %.splatinsert699 = insertelement <8 x i64> poison, i64 %1698, i64 0
  %.splat700 = shufflevector <8 x i64> %.splatinsert699, <8 x i64> poison, <8 x i32> zeroinitializer
  %1701 = mul <8 x i64> %.splat700, splat (i64 32)
  %1702 = add <8 x i64> %1700, %1701
  %1703 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1699, 0
  %1704 = insertvalue { <8 x ptr>, <8 x i64> } %1703, <8 x i64> %1702, 1
  %1705 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1706 = extractvalue { <8 x ptr>, <8 x i64> } %1704, 1
  %1707 = extractelement <8 x ptr> %1705, i32 0
  %1708 = extractelement <8 x i64> %1706, i32 0
  %1709 = sub i64 %1708, 0
  %1710 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1711 = select i1 %1710, i64 %1709, i64 0
  %private.contiguous.address701 = getelementptr i8, ptr %1707, i64 %1711
  %private.contiguous.load702 = load <8 x float>, ptr %private.contiguous.address701, align 4
  %1712 = select <8 x i1> %95, <8 x float> %private.contiguous.load702, <8 x float> zeroinitializer
  %1713 = add i64 %282, 21
  %tile_snapshot.spill.load703 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1714 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load703, 0
  %1715 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load703, 1
  %.splatinsert704 = insertelement <8 x i64> poison, i64 %1713, i64 0
  %.splat705 = shufflevector <8 x i64> %.splatinsert704, <8 x i64> poison, <8 x i32> zeroinitializer
  %1716 = mul <8 x i64> %.splat705, splat (i64 32)
  %1717 = add <8 x i64> %1715, %1716
  %1718 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1714, 0
  %1719 = insertvalue { <8 x ptr>, <8 x i64> } %1718, <8 x i64> %1717, 1
  %1720 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1721 = extractvalue { <8 x ptr>, <8 x i64> } %1719, 1
  %1722 = extractelement <8 x ptr> %1720, i32 0
  %1723 = extractelement <8 x i64> %1721, i32 0
  %1724 = sub i64 %1723, 0
  %1725 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1726 = select i1 %1725, i64 %1724, i64 0
  %private.contiguous.address706 = getelementptr i8, ptr %1722, i64 %1726
  %private.contiguous.load707 = load <8 x float>, ptr %private.contiguous.address706, align 4
  %1727 = select <8 x i1> %95, <8 x float> %private.contiguous.load707, <8 x float> zeroinitializer
  %1728 = add i64 %299, 21
  %tile_snapshot.spill.load708 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1729 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load708, 0
  %1730 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load708, 1
  %.splatinsert709 = insertelement <8 x i64> poison, i64 %1728, i64 0
  %.splat710 = shufflevector <8 x i64> %.splatinsert709, <8 x i64> poison, <8 x i32> zeroinitializer
  %1731 = mul <8 x i64> %.splat710, splat (i64 32)
  %1732 = add <8 x i64> %1730, %1731
  %1733 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1729, 0
  %1734 = insertvalue { <8 x ptr>, <8 x i64> } %1733, <8 x i64> %1732, 1
  %1735 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1736 = extractvalue { <8 x ptr>, <8 x i64> } %1734, 1
  %1737 = extractelement <8 x ptr> %1735, i32 0
  %1738 = extractelement <8 x i64> %1736, i32 0
  %1739 = sub i64 %1738, 0
  %1740 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1741 = select i1 %1740, i64 %1739, i64 0
  %private.contiguous.address711 = getelementptr i8, ptr %1737, i64 %1741
  %private.contiguous.load712 = load <8 x float>, ptr %private.contiguous.address711, align 4
  %1742 = select <8 x i1> %95, <8 x float> %private.contiguous.load712, <8 x float> zeroinitializer
  %1743 = fmul <8 x float> %1697, %1727
  %1744 = fadd <8 x float> %1676, %1743
  %1745 = fmul <8 x float> %1697, %1742
  %1746 = fadd <8 x float> %1678, %1745
  %1747 = fmul <8 x float> %1712, %1727
  %1748 = fadd <8 x float> %1680, %1747
  %1749 = fmul <8 x float> %1712, %1742
  %1750 = fadd <8 x float> %1682, %1749
  %1751 = add i64 %248, 22
  %tile_snapshot.spill.load713 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1752 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load713, 0
  %1753 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load713, 1
  %.splatinsert714 = insertelement <8 x i64> poison, i64 %1751, i64 0
  %.splat715 = shufflevector <8 x i64> %.splatinsert714, <8 x i64> poison, <8 x i32> zeroinitializer
  %1754 = mul <8 x i64> %.splat715, splat (i64 32)
  %1755 = add <8 x i64> %1753, %1754
  %1756 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1752, 0
  %1757 = insertvalue { <8 x ptr>, <8 x i64> } %1756, <8 x i64> %1755, 1
  %1758 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1759 = extractvalue { <8 x ptr>, <8 x i64> } %1757, 1
  %1760 = extractelement <8 x ptr> %1758, i32 0
  %1761 = extractelement <8 x i64> %1759, i32 0
  %1762 = sub i64 %1761, 0
  %1763 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1764 = select i1 %1763, i64 %1762, i64 0
  %private.contiguous.address716 = getelementptr i8, ptr %1760, i64 %1764
  %private.contiguous.load717 = load <8 x float>, ptr %private.contiguous.address716, align 4
  %1765 = select <8 x i1> %95, <8 x float> %private.contiguous.load717, <8 x float> zeroinitializer
  %1766 = add i64 %265, 22
  %tile_snapshot.spill.load718 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1767 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load718, 0
  %1768 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load718, 1
  %.splatinsert719 = insertelement <8 x i64> poison, i64 %1766, i64 0
  %.splat720 = shufflevector <8 x i64> %.splatinsert719, <8 x i64> poison, <8 x i32> zeroinitializer
  %1769 = mul <8 x i64> %.splat720, splat (i64 32)
  %1770 = add <8 x i64> %1768, %1769
  %1771 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1767, 0
  %1772 = insertvalue { <8 x ptr>, <8 x i64> } %1771, <8 x i64> %1770, 1
  %1773 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1774 = extractvalue { <8 x ptr>, <8 x i64> } %1772, 1
  %1775 = extractelement <8 x ptr> %1773, i32 0
  %1776 = extractelement <8 x i64> %1774, i32 0
  %1777 = sub i64 %1776, 0
  %1778 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1779 = select i1 %1778, i64 %1777, i64 0
  %private.contiguous.address721 = getelementptr i8, ptr %1775, i64 %1779
  %private.contiguous.load722 = load <8 x float>, ptr %private.contiguous.address721, align 4
  %1780 = select <8 x i1> %95, <8 x float> %private.contiguous.load722, <8 x float> zeroinitializer
  %1781 = add i64 %282, 22
  %tile_snapshot.spill.load723 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1782 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load723, 0
  %1783 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load723, 1
  %.splatinsert724 = insertelement <8 x i64> poison, i64 %1781, i64 0
  %.splat725 = shufflevector <8 x i64> %.splatinsert724, <8 x i64> poison, <8 x i32> zeroinitializer
  %1784 = mul <8 x i64> %.splat725, splat (i64 32)
  %1785 = add <8 x i64> %1783, %1784
  %1786 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1782, 0
  %1787 = insertvalue { <8 x ptr>, <8 x i64> } %1786, <8 x i64> %1785, 1
  %1788 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1789 = extractvalue { <8 x ptr>, <8 x i64> } %1787, 1
  %1790 = extractelement <8 x ptr> %1788, i32 0
  %1791 = extractelement <8 x i64> %1789, i32 0
  %1792 = sub i64 %1791, 0
  %1793 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1794 = select i1 %1793, i64 %1792, i64 0
  %private.contiguous.address726 = getelementptr i8, ptr %1790, i64 %1794
  %private.contiguous.load727 = load <8 x float>, ptr %private.contiguous.address726, align 4
  %1795 = select <8 x i1> %95, <8 x float> %private.contiguous.load727, <8 x float> zeroinitializer
  %1796 = add i64 %299, 22
  %tile_snapshot.spill.load728 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1797 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load728, 0
  %1798 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load728, 1
  %.splatinsert729 = insertelement <8 x i64> poison, i64 %1796, i64 0
  %.splat730 = shufflevector <8 x i64> %.splatinsert729, <8 x i64> poison, <8 x i32> zeroinitializer
  %1799 = mul <8 x i64> %.splat730, splat (i64 32)
  %1800 = add <8 x i64> %1798, %1799
  %1801 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1797, 0
  %1802 = insertvalue { <8 x ptr>, <8 x i64> } %1801, <8 x i64> %1800, 1
  %1803 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1804 = extractvalue { <8 x ptr>, <8 x i64> } %1802, 1
  %1805 = extractelement <8 x ptr> %1803, i32 0
  %1806 = extractelement <8 x i64> %1804, i32 0
  %1807 = sub i64 %1806, 0
  %1808 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1809 = select i1 %1808, i64 %1807, i64 0
  %private.contiguous.address731 = getelementptr i8, ptr %1805, i64 %1809
  %private.contiguous.load732 = load <8 x float>, ptr %private.contiguous.address731, align 4
  %1810 = select <8 x i1> %95, <8 x float> %private.contiguous.load732, <8 x float> zeroinitializer
  %1811 = fmul <8 x float> %1765, %1795
  %1812 = fadd <8 x float> %1744, %1811
  %1813 = fmul <8 x float> %1765, %1810
  %1814 = fadd <8 x float> %1746, %1813
  %1815 = fmul <8 x float> %1780, %1795
  %1816 = fadd <8 x float> %1748, %1815
  %1817 = fmul <8 x float> %1780, %1810
  %1818 = fadd <8 x float> %1750, %1817
  %1819 = add i64 %248, 23
  %tile_snapshot.spill.load733 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1820 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load733, 0
  %1821 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load733, 1
  %.splatinsert734 = insertelement <8 x i64> poison, i64 %1819, i64 0
  %.splat735 = shufflevector <8 x i64> %.splatinsert734, <8 x i64> poison, <8 x i32> zeroinitializer
  %1822 = mul <8 x i64> %.splat735, splat (i64 32)
  %1823 = add <8 x i64> %1821, %1822
  %1824 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1820, 0
  %1825 = insertvalue { <8 x ptr>, <8 x i64> } %1824, <8 x i64> %1823, 1
  %1826 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1827 = extractvalue { <8 x ptr>, <8 x i64> } %1825, 1
  %1828 = extractelement <8 x ptr> %1826, i32 0
  %1829 = extractelement <8 x i64> %1827, i32 0
  %1830 = sub i64 %1829, 0
  %1831 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1832 = select i1 %1831, i64 %1830, i64 0
  %private.contiguous.address736 = getelementptr i8, ptr %1828, i64 %1832
  %private.contiguous.load737 = load <8 x float>, ptr %private.contiguous.address736, align 4
  %1833 = select <8 x i1> %95, <8 x float> %private.contiguous.load737, <8 x float> zeroinitializer
  %1834 = add i64 %265, 23
  %tile_snapshot.spill.load738 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1835 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load738, 0
  %1836 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load738, 1
  %.splatinsert739 = insertelement <8 x i64> poison, i64 %1834, i64 0
  %.splat740 = shufflevector <8 x i64> %.splatinsert739, <8 x i64> poison, <8 x i32> zeroinitializer
  %1837 = mul <8 x i64> %.splat740, splat (i64 32)
  %1838 = add <8 x i64> %1836, %1837
  %1839 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1835, 0
  %1840 = insertvalue { <8 x ptr>, <8 x i64> } %1839, <8 x i64> %1838, 1
  %1841 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1842 = extractvalue { <8 x ptr>, <8 x i64> } %1840, 1
  %1843 = extractelement <8 x ptr> %1841, i32 0
  %1844 = extractelement <8 x i64> %1842, i32 0
  %1845 = sub i64 %1844, 0
  %1846 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1847 = select i1 %1846, i64 %1845, i64 0
  %private.contiguous.address741 = getelementptr i8, ptr %1843, i64 %1847
  %private.contiguous.load742 = load <8 x float>, ptr %private.contiguous.address741, align 4
  %1848 = select <8 x i1> %95, <8 x float> %private.contiguous.load742, <8 x float> zeroinitializer
  %1849 = add i64 %282, 23
  %tile_snapshot.spill.load743 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1850 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load743, 0
  %1851 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load743, 1
  %.splatinsert744 = insertelement <8 x i64> poison, i64 %1849, i64 0
  %.splat745 = shufflevector <8 x i64> %.splatinsert744, <8 x i64> poison, <8 x i32> zeroinitializer
  %1852 = mul <8 x i64> %.splat745, splat (i64 32)
  %1853 = add <8 x i64> %1851, %1852
  %1854 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1850, 0
  %1855 = insertvalue { <8 x ptr>, <8 x i64> } %1854, <8 x i64> %1853, 1
  %1856 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1857 = extractvalue { <8 x ptr>, <8 x i64> } %1855, 1
  %1858 = extractelement <8 x ptr> %1856, i32 0
  %1859 = extractelement <8 x i64> %1857, i32 0
  %1860 = sub i64 %1859, 0
  %1861 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1862 = select i1 %1861, i64 %1860, i64 0
  %private.contiguous.address746 = getelementptr i8, ptr %1858, i64 %1862
  %private.contiguous.load747 = load <8 x float>, ptr %private.contiguous.address746, align 4
  %1863 = select <8 x i1> %95, <8 x float> %private.contiguous.load747, <8 x float> zeroinitializer
  %1864 = add i64 %299, 23
  %tile_snapshot.spill.load748 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1865 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load748, 0
  %1866 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load748, 1
  %.splatinsert749 = insertelement <8 x i64> poison, i64 %1864, i64 0
  %.splat750 = shufflevector <8 x i64> %.splatinsert749, <8 x i64> poison, <8 x i32> zeroinitializer
  %1867 = mul <8 x i64> %.splat750, splat (i64 32)
  %1868 = add <8 x i64> %1866, %1867
  %1869 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1865, 0
  %1870 = insertvalue { <8 x ptr>, <8 x i64> } %1869, <8 x i64> %1868, 1
  %1871 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1872 = extractvalue { <8 x ptr>, <8 x i64> } %1870, 1
  %1873 = extractelement <8 x ptr> %1871, i32 0
  %1874 = extractelement <8 x i64> %1872, i32 0
  %1875 = sub i64 %1874, 0
  %1876 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1877 = select i1 %1876, i64 %1875, i64 0
  %private.contiguous.address751 = getelementptr i8, ptr %1873, i64 %1877
  %private.contiguous.load752 = load <8 x float>, ptr %private.contiguous.address751, align 4
  %1878 = select <8 x i1> %95, <8 x float> %private.contiguous.load752, <8 x float> zeroinitializer
  %1879 = fmul <8 x float> %1833, %1863
  %1880 = fadd <8 x float> %1812, %1879
  %1881 = fmul <8 x float> %1833, %1878
  %1882 = fadd <8 x float> %1814, %1881
  %1883 = fmul <8 x float> %1848, %1863
  %1884 = fadd <8 x float> %1816, %1883
  %1885 = fmul <8 x float> %1848, %1878
  %1886 = fadd <8 x float> %1818, %1885
  %1887 = add i64 %248, 24
  %tile_snapshot.spill.load753 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1888 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load753, 0
  %1889 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load753, 1
  %.splatinsert754 = insertelement <8 x i64> poison, i64 %1887, i64 0
  %.splat755 = shufflevector <8 x i64> %.splatinsert754, <8 x i64> poison, <8 x i32> zeroinitializer
  %1890 = mul <8 x i64> %.splat755, splat (i64 32)
  %1891 = add <8 x i64> %1889, %1890
  %1892 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1888, 0
  %1893 = insertvalue { <8 x ptr>, <8 x i64> } %1892, <8 x i64> %1891, 1
  %1894 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1895 = extractvalue { <8 x ptr>, <8 x i64> } %1893, 1
  %1896 = extractelement <8 x ptr> %1894, i32 0
  %1897 = extractelement <8 x i64> %1895, i32 0
  %1898 = sub i64 %1897, 0
  %1899 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1900 = select i1 %1899, i64 %1898, i64 0
  %private.contiguous.address756 = getelementptr i8, ptr %1896, i64 %1900
  %private.contiguous.load757 = load <8 x float>, ptr %private.contiguous.address756, align 4
  %1901 = select <8 x i1> %95, <8 x float> %private.contiguous.load757, <8 x float> zeroinitializer
  %1902 = add i64 %265, 24
  %tile_snapshot.spill.load758 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1903 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load758, 0
  %1904 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load758, 1
  %.splatinsert759 = insertelement <8 x i64> poison, i64 %1902, i64 0
  %.splat760 = shufflevector <8 x i64> %.splatinsert759, <8 x i64> poison, <8 x i32> zeroinitializer
  %1905 = mul <8 x i64> %.splat760, splat (i64 32)
  %1906 = add <8 x i64> %1904, %1905
  %1907 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1903, 0
  %1908 = insertvalue { <8 x ptr>, <8 x i64> } %1907, <8 x i64> %1906, 1
  %1909 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1910 = extractvalue { <8 x ptr>, <8 x i64> } %1908, 1
  %1911 = extractelement <8 x ptr> %1909, i32 0
  %1912 = extractelement <8 x i64> %1910, i32 0
  %1913 = sub i64 %1912, 0
  %1914 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1915 = select i1 %1914, i64 %1913, i64 0
  %private.contiguous.address761 = getelementptr i8, ptr %1911, i64 %1915
  %private.contiguous.load762 = load <8 x float>, ptr %private.contiguous.address761, align 4
  %1916 = select <8 x i1> %95, <8 x float> %private.contiguous.load762, <8 x float> zeroinitializer
  %1917 = add i64 %282, 24
  %tile_snapshot.spill.load763 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1918 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 0
  %1919 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 1
  %.splatinsert764 = insertelement <8 x i64> poison, i64 %1917, i64 0
  %.splat765 = shufflevector <8 x i64> %.splatinsert764, <8 x i64> poison, <8 x i32> zeroinitializer
  %1920 = mul <8 x i64> %.splat765, splat (i64 32)
  %1921 = add <8 x i64> %1919, %1920
  %1922 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1918, 0
  %1923 = insertvalue { <8 x ptr>, <8 x i64> } %1922, <8 x i64> %1921, 1
  %1924 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1925 = extractvalue { <8 x ptr>, <8 x i64> } %1923, 1
  %1926 = extractelement <8 x ptr> %1924, i32 0
  %1927 = extractelement <8 x i64> %1925, i32 0
  %1928 = sub i64 %1927, 0
  %1929 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1930 = select i1 %1929, i64 %1928, i64 0
  %private.contiguous.address766 = getelementptr i8, ptr %1926, i64 %1930
  %private.contiguous.load767 = load <8 x float>, ptr %private.contiguous.address766, align 4
  %1931 = select <8 x i1> %95, <8 x float> %private.contiguous.load767, <8 x float> zeroinitializer
  %1932 = add i64 %299, 24
  %tile_snapshot.spill.load768 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1933 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load768, 0
  %1934 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load768, 1
  %.splatinsert769 = insertelement <8 x i64> poison, i64 %1932, i64 0
  %.splat770 = shufflevector <8 x i64> %.splatinsert769, <8 x i64> poison, <8 x i32> zeroinitializer
  %1935 = mul <8 x i64> %.splat770, splat (i64 32)
  %1936 = add <8 x i64> %1934, %1935
  %1937 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1933, 0
  %1938 = insertvalue { <8 x ptr>, <8 x i64> } %1937, <8 x i64> %1936, 1
  %1939 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1940 = extractvalue { <8 x ptr>, <8 x i64> } %1938, 1
  %1941 = extractelement <8 x ptr> %1939, i32 0
  %1942 = extractelement <8 x i64> %1940, i32 0
  %1943 = sub i64 %1942, 0
  %1944 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1945 = select i1 %1944, i64 %1943, i64 0
  %private.contiguous.address771 = getelementptr i8, ptr %1941, i64 %1945
  %private.contiguous.load772 = load <8 x float>, ptr %private.contiguous.address771, align 4
  %1946 = select <8 x i1> %95, <8 x float> %private.contiguous.load772, <8 x float> zeroinitializer
  %1947 = fmul <8 x float> %1901, %1931
  %1948 = fadd <8 x float> %1880, %1947
  %1949 = fmul <8 x float> %1901, %1946
  %1950 = fadd <8 x float> %1882, %1949
  %1951 = fmul <8 x float> %1916, %1931
  %1952 = fadd <8 x float> %1884, %1951
  %1953 = fmul <8 x float> %1916, %1946
  %1954 = fadd <8 x float> %1886, %1953
  %1955 = add i64 %248, 25
  %tile_snapshot.spill.load773 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1956 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load773, 0
  %1957 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load773, 1
  %.splatinsert774 = insertelement <8 x i64> poison, i64 %1955, i64 0
  %.splat775 = shufflevector <8 x i64> %.splatinsert774, <8 x i64> poison, <8 x i32> zeroinitializer
  %1958 = mul <8 x i64> %.splat775, splat (i64 32)
  %1959 = add <8 x i64> %1957, %1958
  %1960 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1956, 0
  %1961 = insertvalue { <8 x ptr>, <8 x i64> } %1960, <8 x i64> %1959, 1
  %1962 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1963 = extractvalue { <8 x ptr>, <8 x i64> } %1961, 1
  %1964 = extractelement <8 x ptr> %1962, i32 0
  %1965 = extractelement <8 x i64> %1963, i32 0
  %1966 = sub i64 %1965, 0
  %1967 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1968 = select i1 %1967, i64 %1966, i64 0
  %private.contiguous.address776 = getelementptr i8, ptr %1964, i64 %1968
  %private.contiguous.load777 = load <8 x float>, ptr %private.contiguous.address776, align 4
  %1969 = select <8 x i1> %95, <8 x float> %private.contiguous.load777, <8 x float> zeroinitializer
  %1970 = add i64 %265, 25
  %tile_snapshot.spill.load778 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1971 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load778, 0
  %1972 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load778, 1
  %.splatinsert779 = insertelement <8 x i64> poison, i64 %1970, i64 0
  %.splat780 = shufflevector <8 x i64> %.splatinsert779, <8 x i64> poison, <8 x i32> zeroinitializer
  %1973 = mul <8 x i64> %.splat780, splat (i64 32)
  %1974 = add <8 x i64> %1972, %1973
  %1975 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1971, 0
  %1976 = insertvalue { <8 x ptr>, <8 x i64> } %1975, <8 x i64> %1974, 1
  %1977 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1978 = extractvalue { <8 x ptr>, <8 x i64> } %1976, 1
  %1979 = extractelement <8 x ptr> %1977, i32 0
  %1980 = extractelement <8 x i64> %1978, i32 0
  %1981 = sub i64 %1980, 0
  %1982 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1983 = select i1 %1982, i64 %1981, i64 0
  %private.contiguous.address781 = getelementptr i8, ptr %1979, i64 %1983
  %private.contiguous.load782 = load <8 x float>, ptr %private.contiguous.address781, align 4
  %1984 = select <8 x i1> %95, <8 x float> %private.contiguous.load782, <8 x float> zeroinitializer
  %1985 = add i64 %282, 25
  %tile_snapshot.spill.load783 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1986 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load783, 0
  %1987 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load783, 1
  %.splatinsert784 = insertelement <8 x i64> poison, i64 %1985, i64 0
  %.splat785 = shufflevector <8 x i64> %.splatinsert784, <8 x i64> poison, <8 x i32> zeroinitializer
  %1988 = mul <8 x i64> %.splat785, splat (i64 32)
  %1989 = add <8 x i64> %1987, %1988
  %1990 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1986, 0
  %1991 = insertvalue { <8 x ptr>, <8 x i64> } %1990, <8 x i64> %1989, 1
  %1992 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1993 = extractvalue { <8 x ptr>, <8 x i64> } %1991, 1
  %1994 = extractelement <8 x ptr> %1992, i32 0
  %1995 = extractelement <8 x i64> %1993, i32 0
  %1996 = sub i64 %1995, 0
  %1997 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1998 = select i1 %1997, i64 %1996, i64 0
  %private.contiguous.address786 = getelementptr i8, ptr %1994, i64 %1998
  %private.contiguous.load787 = load <8 x float>, ptr %private.contiguous.address786, align 4
  %1999 = select <8 x i1> %95, <8 x float> %private.contiguous.load787, <8 x float> zeroinitializer
  %2000 = add i64 %299, 25
  %tile_snapshot.spill.load788 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %2001 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load788, 0
  %2002 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load788, 1
  %.splatinsert789 = insertelement <8 x i64> poison, i64 %2000, i64 0
  %.splat790 = shufflevector <8 x i64> %.splatinsert789, <8 x i64> poison, <8 x i32> zeroinitializer
  %2003 = mul <8 x i64> %.splat790, splat (i64 32)
  %2004 = add <8 x i64> %2002, %2003
  %2005 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2001, 0
  %2006 = insertvalue { <8 x ptr>, <8 x i64> } %2005, <8 x i64> %2004, 1
  %2007 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2008 = extractvalue { <8 x ptr>, <8 x i64> } %2006, 1
  %2009 = extractelement <8 x ptr> %2007, i32 0
  %2010 = extractelement <8 x i64> %2008, i32 0
  %2011 = sub i64 %2010, 0
  %2012 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2013 = select i1 %2012, i64 %2011, i64 0
  %private.contiguous.address791 = getelementptr i8, ptr %2009, i64 %2013
  %private.contiguous.load792 = load <8 x float>, ptr %private.contiguous.address791, align 4
  %2014 = select <8 x i1> %95, <8 x float> %private.contiguous.load792, <8 x float> zeroinitializer
  %2015 = fmul <8 x float> %1969, %1999
  %2016 = fadd <8 x float> %1948, %2015
  %2017 = fmul <8 x float> %1969, %2014
  %2018 = fadd <8 x float> %1950, %2017
  %2019 = fmul <8 x float> %1984, %1999
  %2020 = fadd <8 x float> %1952, %2019
  %2021 = fmul <8 x float> %1984, %2014
  %2022 = fadd <8 x float> %1954, %2021
  %2023 = add i64 %248, 26
  %tile_snapshot.spill.load793 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %2024 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load793, 0
  %2025 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load793, 1
  %.splatinsert794 = insertelement <8 x i64> poison, i64 %2023, i64 0
  %.splat795 = shufflevector <8 x i64> %.splatinsert794, <8 x i64> poison, <8 x i32> zeroinitializer
  %2026 = mul <8 x i64> %.splat795, splat (i64 32)
  %2027 = add <8 x i64> %2025, %2026
  %2028 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2024, 0
  %2029 = insertvalue { <8 x ptr>, <8 x i64> } %2028, <8 x i64> %2027, 1
  %2030 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %2031 = extractvalue { <8 x ptr>, <8 x i64> } %2029, 1
  %2032 = extractelement <8 x ptr> %2030, i32 0
  %2033 = extractelement <8 x i64> %2031, i32 0
  %2034 = sub i64 %2033, 0
  %2035 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2036 = select i1 %2035, i64 %2034, i64 0
  %private.contiguous.address796 = getelementptr i8, ptr %2032, i64 %2036
  %private.contiguous.load797 = load <8 x float>, ptr %private.contiguous.address796, align 4
  %2037 = select <8 x i1> %95, <8 x float> %private.contiguous.load797, <8 x float> zeroinitializer
  %2038 = add i64 %265, 26
  %tile_snapshot.spill.load798 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %2039 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load798, 0
  %2040 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load798, 1
  %.splatinsert799 = insertelement <8 x i64> poison, i64 %2038, i64 0
  %.splat800 = shufflevector <8 x i64> %.splatinsert799, <8 x i64> poison, <8 x i32> zeroinitializer
  %2041 = mul <8 x i64> %.splat800, splat (i64 32)
  %2042 = add <8 x i64> %2040, %2041
  %2043 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2039, 0
  %2044 = insertvalue { <8 x ptr>, <8 x i64> } %2043, <8 x i64> %2042, 1
  %2045 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %2046 = extractvalue { <8 x ptr>, <8 x i64> } %2044, 1
  %2047 = extractelement <8 x ptr> %2045, i32 0
  %2048 = extractelement <8 x i64> %2046, i32 0
  %2049 = sub i64 %2048, 0
  %2050 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2051 = select i1 %2050, i64 %2049, i64 0
  %private.contiguous.address801 = getelementptr i8, ptr %2047, i64 %2051
  %private.contiguous.load802 = load <8 x float>, ptr %private.contiguous.address801, align 4
  %2052 = select <8 x i1> %95, <8 x float> %private.contiguous.load802, <8 x float> zeroinitializer
  %2053 = add i64 %282, 26
  %tile_snapshot.spill.load803 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %2054 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load803, 0
  %2055 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load803, 1
  %.splatinsert804 = insertelement <8 x i64> poison, i64 %2053, i64 0
  %.splat805 = shufflevector <8 x i64> %.splatinsert804, <8 x i64> poison, <8 x i32> zeroinitializer
  %2056 = mul <8 x i64> %.splat805, splat (i64 32)
  %2057 = add <8 x i64> %2055, %2056
  %2058 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2054, 0
  %2059 = insertvalue { <8 x ptr>, <8 x i64> } %2058, <8 x i64> %2057, 1
  %2060 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2061 = extractvalue { <8 x ptr>, <8 x i64> } %2059, 1
  %2062 = extractelement <8 x ptr> %2060, i32 0
  %2063 = extractelement <8 x i64> %2061, i32 0
  %2064 = sub i64 %2063, 0
  %2065 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2066 = select i1 %2065, i64 %2064, i64 0
  %private.contiguous.address806 = getelementptr i8, ptr %2062, i64 %2066
  %private.contiguous.load807 = load <8 x float>, ptr %private.contiguous.address806, align 4
  %2067 = select <8 x i1> %95, <8 x float> %private.contiguous.load807, <8 x float> zeroinitializer
  %2068 = add i64 %299, 26
  %tile_snapshot.spill.load808 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %2069 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load808, 0
  %2070 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load808, 1
  %.splatinsert809 = insertelement <8 x i64> poison, i64 %2068, i64 0
  %.splat810 = shufflevector <8 x i64> %.splatinsert809, <8 x i64> poison, <8 x i32> zeroinitializer
  %2071 = mul <8 x i64> %.splat810, splat (i64 32)
  %2072 = add <8 x i64> %2070, %2071
  %2073 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2069, 0
  %2074 = insertvalue { <8 x ptr>, <8 x i64> } %2073, <8 x i64> %2072, 1
  %2075 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2076 = extractvalue { <8 x ptr>, <8 x i64> } %2074, 1
  %2077 = extractelement <8 x ptr> %2075, i32 0
  %2078 = extractelement <8 x i64> %2076, i32 0
  %2079 = sub i64 %2078, 0
  %2080 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2081 = select i1 %2080, i64 %2079, i64 0
  %private.contiguous.address811 = getelementptr i8, ptr %2077, i64 %2081
  %private.contiguous.load812 = load <8 x float>, ptr %private.contiguous.address811, align 4
  %2082 = select <8 x i1> %95, <8 x float> %private.contiguous.load812, <8 x float> zeroinitializer
  %2083 = fmul <8 x float> %2037, %2067
  %2084 = fadd <8 x float> %2016, %2083
  %2085 = fmul <8 x float> %2037, %2082
  %2086 = fadd <8 x float> %2018, %2085
  %2087 = fmul <8 x float> %2052, %2067
  %2088 = fadd <8 x float> %2020, %2087
  %2089 = fmul <8 x float> %2052, %2082
  %2090 = fadd <8 x float> %2022, %2089
  %2091 = add i64 %248, 27
  %tile_snapshot.spill.load813 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %2092 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load813, 0
  %2093 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load813, 1
  %.splatinsert814 = insertelement <8 x i64> poison, i64 %2091, i64 0
  %.splat815 = shufflevector <8 x i64> %.splatinsert814, <8 x i64> poison, <8 x i32> zeroinitializer
  %2094 = mul <8 x i64> %.splat815, splat (i64 32)
  %2095 = add <8 x i64> %2093, %2094
  %2096 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2092, 0
  %2097 = insertvalue { <8 x ptr>, <8 x i64> } %2096, <8 x i64> %2095, 1
  %2098 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %2099 = extractvalue { <8 x ptr>, <8 x i64> } %2097, 1
  %2100 = extractelement <8 x ptr> %2098, i32 0
  %2101 = extractelement <8 x i64> %2099, i32 0
  %2102 = sub i64 %2101, 0
  %2103 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2104 = select i1 %2103, i64 %2102, i64 0
  %private.contiguous.address816 = getelementptr i8, ptr %2100, i64 %2104
  %private.contiguous.load817 = load <8 x float>, ptr %private.contiguous.address816, align 4
  %2105 = select <8 x i1> %95, <8 x float> %private.contiguous.load817, <8 x float> zeroinitializer
  %2106 = add i64 %265, 27
  %tile_snapshot.spill.load818 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %2107 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load818, 0
  %2108 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load818, 1
  %.splatinsert819 = insertelement <8 x i64> poison, i64 %2106, i64 0
  %.splat820 = shufflevector <8 x i64> %.splatinsert819, <8 x i64> poison, <8 x i32> zeroinitializer
  %2109 = mul <8 x i64> %.splat820, splat (i64 32)
  %2110 = add <8 x i64> %2108, %2109
  %2111 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2107, 0
  %2112 = insertvalue { <8 x ptr>, <8 x i64> } %2111, <8 x i64> %2110, 1
  %2113 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %2114 = extractvalue { <8 x ptr>, <8 x i64> } %2112, 1
  %2115 = extractelement <8 x ptr> %2113, i32 0
  %2116 = extractelement <8 x i64> %2114, i32 0
  %2117 = sub i64 %2116, 0
  %2118 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2119 = select i1 %2118, i64 %2117, i64 0
  %private.contiguous.address821 = getelementptr i8, ptr %2115, i64 %2119
  %private.contiguous.load822 = load <8 x float>, ptr %private.contiguous.address821, align 4
  %2120 = select <8 x i1> %95, <8 x float> %private.contiguous.load822, <8 x float> zeroinitializer
  %2121 = add i64 %282, 27
  %tile_snapshot.spill.load823 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %2122 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load823, 0
  %2123 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load823, 1
  %.splatinsert824 = insertelement <8 x i64> poison, i64 %2121, i64 0
  %.splat825 = shufflevector <8 x i64> %.splatinsert824, <8 x i64> poison, <8 x i32> zeroinitializer
  %2124 = mul <8 x i64> %.splat825, splat (i64 32)
  %2125 = add <8 x i64> %2123, %2124
  %2126 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2122, 0
  %2127 = insertvalue { <8 x ptr>, <8 x i64> } %2126, <8 x i64> %2125, 1
  %2128 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2129 = extractvalue { <8 x ptr>, <8 x i64> } %2127, 1
  %2130 = extractelement <8 x ptr> %2128, i32 0
  %2131 = extractelement <8 x i64> %2129, i32 0
  %2132 = sub i64 %2131, 0
  %2133 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2134 = select i1 %2133, i64 %2132, i64 0
  %private.contiguous.address826 = getelementptr i8, ptr %2130, i64 %2134
  %private.contiguous.load827 = load <8 x float>, ptr %private.contiguous.address826, align 4
  %2135 = select <8 x i1> %95, <8 x float> %private.contiguous.load827, <8 x float> zeroinitializer
  %2136 = add i64 %299, 27
  %tile_snapshot.spill.load828 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %2137 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load828, 0
  %2138 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load828, 1
  %.splatinsert829 = insertelement <8 x i64> poison, i64 %2136, i64 0
  %.splat830 = shufflevector <8 x i64> %.splatinsert829, <8 x i64> poison, <8 x i32> zeroinitializer
  %2139 = mul <8 x i64> %.splat830, splat (i64 32)
  %2140 = add <8 x i64> %2138, %2139
  %2141 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2137, 0
  %2142 = insertvalue { <8 x ptr>, <8 x i64> } %2141, <8 x i64> %2140, 1
  %2143 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2144 = extractvalue { <8 x ptr>, <8 x i64> } %2142, 1
  %2145 = extractelement <8 x ptr> %2143, i32 0
  %2146 = extractelement <8 x i64> %2144, i32 0
  %2147 = sub i64 %2146, 0
  %2148 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2149 = select i1 %2148, i64 %2147, i64 0
  %private.contiguous.address831 = getelementptr i8, ptr %2145, i64 %2149
  %private.contiguous.load832 = load <8 x float>, ptr %private.contiguous.address831, align 4
  %2150 = select <8 x i1> %95, <8 x float> %private.contiguous.load832, <8 x float> zeroinitializer
  %2151 = fmul <8 x float> %2105, %2135
  %2152 = fadd <8 x float> %2084, %2151
  %2153 = fmul <8 x float> %2105, %2150
  %2154 = fadd <8 x float> %2086, %2153
  %2155 = fmul <8 x float> %2120, %2135
  %2156 = fadd <8 x float> %2088, %2155
  %2157 = fmul <8 x float> %2120, %2150
  %2158 = fadd <8 x float> %2090, %2157
  %2159 = add i64 %248, 28
  %tile_snapshot.spill.load833 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %2160 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load833, 0
  %2161 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load833, 1
  %.splatinsert834 = insertelement <8 x i64> poison, i64 %2159, i64 0
  %.splat835 = shufflevector <8 x i64> %.splatinsert834, <8 x i64> poison, <8 x i32> zeroinitializer
  %2162 = mul <8 x i64> %.splat835, splat (i64 32)
  %2163 = add <8 x i64> %2161, %2162
  %2164 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2160, 0
  %2165 = insertvalue { <8 x ptr>, <8 x i64> } %2164, <8 x i64> %2163, 1
  %2166 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %2167 = extractvalue { <8 x ptr>, <8 x i64> } %2165, 1
  %2168 = extractelement <8 x ptr> %2166, i32 0
  %2169 = extractelement <8 x i64> %2167, i32 0
  %2170 = sub i64 %2169, 0
  %2171 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2172 = select i1 %2171, i64 %2170, i64 0
  %private.contiguous.address836 = getelementptr i8, ptr %2168, i64 %2172
  %private.contiguous.load837 = load <8 x float>, ptr %private.contiguous.address836, align 4
  %2173 = select <8 x i1> %95, <8 x float> %private.contiguous.load837, <8 x float> zeroinitializer
  %2174 = add i64 %265, 28
  %tile_snapshot.spill.load838 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %2175 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load838, 0
  %2176 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load838, 1
  %.splatinsert839 = insertelement <8 x i64> poison, i64 %2174, i64 0
  %.splat840 = shufflevector <8 x i64> %.splatinsert839, <8 x i64> poison, <8 x i32> zeroinitializer
  %2177 = mul <8 x i64> %.splat840, splat (i64 32)
  %2178 = add <8 x i64> %2176, %2177
  %2179 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2175, 0
  %2180 = insertvalue { <8 x ptr>, <8 x i64> } %2179, <8 x i64> %2178, 1
  %2181 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %2182 = extractvalue { <8 x ptr>, <8 x i64> } %2180, 1
  %2183 = extractelement <8 x ptr> %2181, i32 0
  %2184 = extractelement <8 x i64> %2182, i32 0
  %2185 = sub i64 %2184, 0
  %2186 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2187 = select i1 %2186, i64 %2185, i64 0
  %private.contiguous.address841 = getelementptr i8, ptr %2183, i64 %2187
  %private.contiguous.load842 = load <8 x float>, ptr %private.contiguous.address841, align 4
  %2188 = select <8 x i1> %95, <8 x float> %private.contiguous.load842, <8 x float> zeroinitializer
  %2189 = add i64 %282, 28
  %tile_snapshot.spill.load843 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %2190 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load843, 0
  %2191 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load843, 1
  %.splatinsert844 = insertelement <8 x i64> poison, i64 %2189, i64 0
  %.splat845 = shufflevector <8 x i64> %.splatinsert844, <8 x i64> poison, <8 x i32> zeroinitializer
  %2192 = mul <8 x i64> %.splat845, splat (i64 32)
  %2193 = add <8 x i64> %2191, %2192
  %2194 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2190, 0
  %2195 = insertvalue { <8 x ptr>, <8 x i64> } %2194, <8 x i64> %2193, 1
  %2196 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2197 = extractvalue { <8 x ptr>, <8 x i64> } %2195, 1
  %2198 = extractelement <8 x ptr> %2196, i32 0
  %2199 = extractelement <8 x i64> %2197, i32 0
  %2200 = sub i64 %2199, 0
  %2201 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2202 = select i1 %2201, i64 %2200, i64 0
  %private.contiguous.address846 = getelementptr i8, ptr %2198, i64 %2202
  %private.contiguous.load847 = load <8 x float>, ptr %private.contiguous.address846, align 4
  %2203 = select <8 x i1> %95, <8 x float> %private.contiguous.load847, <8 x float> zeroinitializer
  %2204 = add i64 %299, 28
  %tile_snapshot.spill.load848 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %2205 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load848, 0
  %2206 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load848, 1
  %.splatinsert849 = insertelement <8 x i64> poison, i64 %2204, i64 0
  %.splat850 = shufflevector <8 x i64> %.splatinsert849, <8 x i64> poison, <8 x i32> zeroinitializer
  %2207 = mul <8 x i64> %.splat850, splat (i64 32)
  %2208 = add <8 x i64> %2206, %2207
  %2209 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2205, 0
  %2210 = insertvalue { <8 x ptr>, <8 x i64> } %2209, <8 x i64> %2208, 1
  %2211 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2212 = extractvalue { <8 x ptr>, <8 x i64> } %2210, 1
  %2213 = extractelement <8 x ptr> %2211, i32 0
  %2214 = extractelement <8 x i64> %2212, i32 0
  %2215 = sub i64 %2214, 0
  %2216 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2217 = select i1 %2216, i64 %2215, i64 0
  %private.contiguous.address851 = getelementptr i8, ptr %2213, i64 %2217
  %private.contiguous.load852 = load <8 x float>, ptr %private.contiguous.address851, align 4
  %2218 = select <8 x i1> %95, <8 x float> %private.contiguous.load852, <8 x float> zeroinitializer
  %2219 = fmul <8 x float> %2173, %2203
  %2220 = fadd <8 x float> %2152, %2219
  %2221 = fmul <8 x float> %2173, %2218
  %2222 = fadd <8 x float> %2154, %2221
  %2223 = fmul <8 x float> %2188, %2203
  %2224 = fadd <8 x float> %2156, %2223
  %2225 = fmul <8 x float> %2188, %2218
  %2226 = fadd <8 x float> %2158, %2225
  %2227 = add i64 %248, 29
  %tile_snapshot.spill.load853 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %2228 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load853, 0
  %2229 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load853, 1
  %.splatinsert854 = insertelement <8 x i64> poison, i64 %2227, i64 0
  %.splat855 = shufflevector <8 x i64> %.splatinsert854, <8 x i64> poison, <8 x i32> zeroinitializer
  %2230 = mul <8 x i64> %.splat855, splat (i64 32)
  %2231 = add <8 x i64> %2229, %2230
  %2232 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2228, 0
  %2233 = insertvalue { <8 x ptr>, <8 x i64> } %2232, <8 x i64> %2231, 1
  %2234 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %2235 = extractvalue { <8 x ptr>, <8 x i64> } %2233, 1
  %2236 = extractelement <8 x ptr> %2234, i32 0
  %2237 = extractelement <8 x i64> %2235, i32 0
  %2238 = sub i64 %2237, 0
  %2239 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2240 = select i1 %2239, i64 %2238, i64 0
  %private.contiguous.address856 = getelementptr i8, ptr %2236, i64 %2240
  %private.contiguous.load857 = load <8 x float>, ptr %private.contiguous.address856, align 4
  %2241 = select <8 x i1> %95, <8 x float> %private.contiguous.load857, <8 x float> zeroinitializer
  %2242 = add i64 %265, 29
  %tile_snapshot.spill.load858 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %2243 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load858, 0
  %2244 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load858, 1
  %.splatinsert859 = insertelement <8 x i64> poison, i64 %2242, i64 0
  %.splat860 = shufflevector <8 x i64> %.splatinsert859, <8 x i64> poison, <8 x i32> zeroinitializer
  %2245 = mul <8 x i64> %.splat860, splat (i64 32)
  %2246 = add <8 x i64> %2244, %2245
  %2247 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2243, 0
  %2248 = insertvalue { <8 x ptr>, <8 x i64> } %2247, <8 x i64> %2246, 1
  %2249 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %2250 = extractvalue { <8 x ptr>, <8 x i64> } %2248, 1
  %2251 = extractelement <8 x ptr> %2249, i32 0
  %2252 = extractelement <8 x i64> %2250, i32 0
  %2253 = sub i64 %2252, 0
  %2254 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2255 = select i1 %2254, i64 %2253, i64 0
  %private.contiguous.address861 = getelementptr i8, ptr %2251, i64 %2255
  %private.contiguous.load862 = load <8 x float>, ptr %private.contiguous.address861, align 4
  %2256 = select <8 x i1> %95, <8 x float> %private.contiguous.load862, <8 x float> zeroinitializer
  %2257 = add i64 %282, 29
  %tile_snapshot.spill.load863 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %2258 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load863, 0
  %2259 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load863, 1
  %.splatinsert864 = insertelement <8 x i64> poison, i64 %2257, i64 0
  %.splat865 = shufflevector <8 x i64> %.splatinsert864, <8 x i64> poison, <8 x i32> zeroinitializer
  %2260 = mul <8 x i64> %.splat865, splat (i64 32)
  %2261 = add <8 x i64> %2259, %2260
  %2262 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2258, 0
  %2263 = insertvalue { <8 x ptr>, <8 x i64> } %2262, <8 x i64> %2261, 1
  %2264 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2265 = extractvalue { <8 x ptr>, <8 x i64> } %2263, 1
  %2266 = extractelement <8 x ptr> %2264, i32 0
  %2267 = extractelement <8 x i64> %2265, i32 0
  %2268 = sub i64 %2267, 0
  %2269 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2270 = select i1 %2269, i64 %2268, i64 0
  %private.contiguous.address866 = getelementptr i8, ptr %2266, i64 %2270
  %private.contiguous.load867 = load <8 x float>, ptr %private.contiguous.address866, align 4
  %2271 = select <8 x i1> %95, <8 x float> %private.contiguous.load867, <8 x float> zeroinitializer
  %2272 = add i64 %299, 29
  %tile_snapshot.spill.load868 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %2273 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load868, 0
  %2274 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load868, 1
  %.splatinsert869 = insertelement <8 x i64> poison, i64 %2272, i64 0
  %.splat870 = shufflevector <8 x i64> %.splatinsert869, <8 x i64> poison, <8 x i32> zeroinitializer
  %2275 = mul <8 x i64> %.splat870, splat (i64 32)
  %2276 = add <8 x i64> %2274, %2275
  %2277 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2273, 0
  %2278 = insertvalue { <8 x ptr>, <8 x i64> } %2277, <8 x i64> %2276, 1
  %2279 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2280 = extractvalue { <8 x ptr>, <8 x i64> } %2278, 1
  %2281 = extractelement <8 x ptr> %2279, i32 0
  %2282 = extractelement <8 x i64> %2280, i32 0
  %2283 = sub i64 %2282, 0
  %2284 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2285 = select i1 %2284, i64 %2283, i64 0
  %private.contiguous.address871 = getelementptr i8, ptr %2281, i64 %2285
  %private.contiguous.load872 = load <8 x float>, ptr %private.contiguous.address871, align 4
  %2286 = select <8 x i1> %95, <8 x float> %private.contiguous.load872, <8 x float> zeroinitializer
  %2287 = fmul <8 x float> %2241, %2271
  %2288 = fadd <8 x float> %2220, %2287
  %2289 = fmul <8 x float> %2241, %2286
  %2290 = fadd <8 x float> %2222, %2289
  %2291 = fmul <8 x float> %2256, %2271
  %2292 = fadd <8 x float> %2224, %2291
  %2293 = fmul <8 x float> %2256, %2286
  %2294 = fadd <8 x float> %2226, %2293
  %2295 = add i64 %248, 30
  %tile_snapshot.spill.load873 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %2296 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load873, 0
  %2297 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load873, 1
  %.splatinsert874 = insertelement <8 x i64> poison, i64 %2295, i64 0
  %.splat875 = shufflevector <8 x i64> %.splatinsert874, <8 x i64> poison, <8 x i32> zeroinitializer
  %2298 = mul <8 x i64> %.splat875, splat (i64 32)
  %2299 = add <8 x i64> %2297, %2298
  %2300 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2296, 0
  %2301 = insertvalue { <8 x ptr>, <8 x i64> } %2300, <8 x i64> %2299, 1
  %2302 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %2303 = extractvalue { <8 x ptr>, <8 x i64> } %2301, 1
  %2304 = extractelement <8 x ptr> %2302, i32 0
  %2305 = extractelement <8 x i64> %2303, i32 0
  %2306 = sub i64 %2305, 0
  %2307 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2308 = select i1 %2307, i64 %2306, i64 0
  %private.contiguous.address876 = getelementptr i8, ptr %2304, i64 %2308
  %private.contiguous.load877 = load <8 x float>, ptr %private.contiguous.address876, align 4
  %2309 = select <8 x i1> %95, <8 x float> %private.contiguous.load877, <8 x float> zeroinitializer
  %2310 = add i64 %265, 30
  %tile_snapshot.spill.load878 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %2311 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load878, 0
  %2312 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load878, 1
  %.splatinsert879 = insertelement <8 x i64> poison, i64 %2310, i64 0
  %.splat880 = shufflevector <8 x i64> %.splatinsert879, <8 x i64> poison, <8 x i32> zeroinitializer
  %2313 = mul <8 x i64> %.splat880, splat (i64 32)
  %2314 = add <8 x i64> %2312, %2313
  %2315 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2311, 0
  %2316 = insertvalue { <8 x ptr>, <8 x i64> } %2315, <8 x i64> %2314, 1
  %2317 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %2318 = extractvalue { <8 x ptr>, <8 x i64> } %2316, 1
  %2319 = extractelement <8 x ptr> %2317, i32 0
  %2320 = extractelement <8 x i64> %2318, i32 0
  %2321 = sub i64 %2320, 0
  %2322 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2323 = select i1 %2322, i64 %2321, i64 0
  %private.contiguous.address881 = getelementptr i8, ptr %2319, i64 %2323
  %private.contiguous.load882 = load <8 x float>, ptr %private.contiguous.address881, align 4
  %2324 = select <8 x i1> %95, <8 x float> %private.contiguous.load882, <8 x float> zeroinitializer
  %2325 = add i64 %282, 30
  %tile_snapshot.spill.load883 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %2326 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load883, 0
  %2327 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load883, 1
  %.splatinsert884 = insertelement <8 x i64> poison, i64 %2325, i64 0
  %.splat885 = shufflevector <8 x i64> %.splatinsert884, <8 x i64> poison, <8 x i32> zeroinitializer
  %2328 = mul <8 x i64> %.splat885, splat (i64 32)
  %2329 = add <8 x i64> %2327, %2328
  %2330 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2326, 0
  %2331 = insertvalue { <8 x ptr>, <8 x i64> } %2330, <8 x i64> %2329, 1
  %2332 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2333 = extractvalue { <8 x ptr>, <8 x i64> } %2331, 1
  %2334 = extractelement <8 x ptr> %2332, i32 0
  %2335 = extractelement <8 x i64> %2333, i32 0
  %2336 = sub i64 %2335, 0
  %2337 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2338 = select i1 %2337, i64 %2336, i64 0
  %private.contiguous.address886 = getelementptr i8, ptr %2334, i64 %2338
  %private.contiguous.load887 = load <8 x float>, ptr %private.contiguous.address886, align 4
  %2339 = select <8 x i1> %95, <8 x float> %private.contiguous.load887, <8 x float> zeroinitializer
  %2340 = add i64 %299, 30
  %tile_snapshot.spill.load888 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %2341 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load888, 0
  %2342 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load888, 1
  %.splatinsert889 = insertelement <8 x i64> poison, i64 %2340, i64 0
  %.splat890 = shufflevector <8 x i64> %.splatinsert889, <8 x i64> poison, <8 x i32> zeroinitializer
  %2343 = mul <8 x i64> %.splat890, splat (i64 32)
  %2344 = add <8 x i64> %2342, %2343
  %2345 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2341, 0
  %2346 = insertvalue { <8 x ptr>, <8 x i64> } %2345, <8 x i64> %2344, 1
  %2347 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2348 = extractvalue { <8 x ptr>, <8 x i64> } %2346, 1
  %2349 = extractelement <8 x ptr> %2347, i32 0
  %2350 = extractelement <8 x i64> %2348, i32 0
  %2351 = sub i64 %2350, 0
  %2352 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2353 = select i1 %2352, i64 %2351, i64 0
  %private.contiguous.address891 = getelementptr i8, ptr %2349, i64 %2353
  %private.contiguous.load892 = load <8 x float>, ptr %private.contiguous.address891, align 4
  %2354 = select <8 x i1> %95, <8 x float> %private.contiguous.load892, <8 x float> zeroinitializer
  %2355 = fmul <8 x float> %2309, %2339
  %2356 = fadd <8 x float> %2288, %2355
  %2357 = fmul <8 x float> %2309, %2354
  %2358 = fadd <8 x float> %2290, %2357
  %2359 = fmul <8 x float> %2324, %2339
  %2360 = fadd <8 x float> %2292, %2359
  %2361 = fmul <8 x float> %2324, %2354
  %2362 = fadd <8 x float> %2294, %2361
  %2363 = add i64 %248, 31
  %tile_snapshot.spill.load893 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %2364 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load893, 0
  %2365 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load893, 1
  %.splatinsert894 = insertelement <8 x i64> poison, i64 %2363, i64 0
  %.splat895 = shufflevector <8 x i64> %.splatinsert894, <8 x i64> poison, <8 x i32> zeroinitializer
  %2366 = mul <8 x i64> %.splat895, splat (i64 32)
  %2367 = add <8 x i64> %2365, %2366
  %2368 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2364, 0
  %2369 = insertvalue { <8 x ptr>, <8 x i64> } %2368, <8 x i64> %2367, 1
  %2370 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %2371 = extractvalue { <8 x ptr>, <8 x i64> } %2369, 1
  %2372 = extractelement <8 x ptr> %2370, i32 0
  %2373 = extractelement <8 x i64> %2371, i32 0
  %2374 = sub i64 %2373, 0
  %2375 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2376 = select i1 %2375, i64 %2374, i64 0
  %private.contiguous.address896 = getelementptr i8, ptr %2372, i64 %2376
  %private.contiguous.load897 = load <8 x float>, ptr %private.contiguous.address896, align 4
  %2377 = select <8 x i1> %95, <8 x float> %private.contiguous.load897, <8 x float> zeroinitializer
  %2378 = add i64 %265, 31
  %tile_snapshot.spill.load898 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %2379 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load898, 0
  %2380 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load898, 1
  %.splatinsert899 = insertelement <8 x i64> poison, i64 %2378, i64 0
  %.splat900 = shufflevector <8 x i64> %.splatinsert899, <8 x i64> poison, <8 x i32> zeroinitializer
  %2381 = mul <8 x i64> %.splat900, splat (i64 32)
  %2382 = add <8 x i64> %2380, %2381
  %2383 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2379, 0
  %2384 = insertvalue { <8 x ptr>, <8 x i64> } %2383, <8 x i64> %2382, 1
  %2385 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %2386 = extractvalue { <8 x ptr>, <8 x i64> } %2384, 1
  %2387 = extractelement <8 x ptr> %2385, i32 0
  %2388 = extractelement <8 x i64> %2386, i32 0
  %2389 = sub i64 %2388, 0
  %2390 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2391 = select i1 %2390, i64 %2389, i64 0
  %private.contiguous.address901 = getelementptr i8, ptr %2387, i64 %2391
  %private.contiguous.load902 = load <8 x float>, ptr %private.contiguous.address901, align 4
  %2392 = select <8 x i1> %95, <8 x float> %private.contiguous.load902, <8 x float> zeroinitializer
  %2393 = add i64 %282, 31
  %tile_snapshot.spill.load903 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %2394 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load903, 0
  %2395 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load903, 1
  %.splatinsert904 = insertelement <8 x i64> poison, i64 %2393, i64 0
  %.splat905 = shufflevector <8 x i64> %.splatinsert904, <8 x i64> poison, <8 x i32> zeroinitializer
  %2396 = mul <8 x i64> %.splat905, splat (i64 32)
  %2397 = add <8 x i64> %2395, %2396
  %2398 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2394, 0
  %2399 = insertvalue { <8 x ptr>, <8 x i64> } %2398, <8 x i64> %2397, 1
  %2400 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2401 = extractvalue { <8 x ptr>, <8 x i64> } %2399, 1
  %2402 = extractelement <8 x ptr> %2400, i32 0
  %2403 = extractelement <8 x i64> %2401, i32 0
  %2404 = sub i64 %2403, 0
  %2405 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2406 = select i1 %2405, i64 %2404, i64 0
  %private.contiguous.address906 = getelementptr i8, ptr %2402, i64 %2406
  %private.contiguous.load907 = load <8 x float>, ptr %private.contiguous.address906, align 4
  %2407 = select <8 x i1> %95, <8 x float> %private.contiguous.load907, <8 x float> zeroinitializer
  %2408 = add i64 %299, 31
  %tile_snapshot.spill.load908 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %2409 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load908, 0
  %2410 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load908, 1
  %.splatinsert909 = insertelement <8 x i64> poison, i64 %2408, i64 0
  %.splat910 = shufflevector <8 x i64> %.splatinsert909, <8 x i64> poison, <8 x i32> zeroinitializer
  %2411 = mul <8 x i64> %.splat910, splat (i64 32)
  %2412 = add <8 x i64> %2410, %2411
  %2413 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2409, 0
  %2414 = insertvalue { <8 x ptr>, <8 x i64> } %2413, <8 x i64> %2412, 1
  %2415 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2416 = extractvalue { <8 x ptr>, <8 x i64> } %2414, 1
  %2417 = extractelement <8 x ptr> %2415, i32 0
  %2418 = extractelement <8 x i64> %2416, i32 0
  %2419 = sub i64 %2418, 0
  %2420 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2421 = select i1 %2420, i64 %2419, i64 0
  %private.contiguous.address911 = getelementptr i8, ptr %2417, i64 %2421
  %private.contiguous.load912 = load <8 x float>, ptr %private.contiguous.address911, align 4
  %2422 = select <8 x i1> %95, <8 x float> %private.contiguous.load912, <8 x float> zeroinitializer
  %2423 = fmul <8 x float> %2377, %2407
  %2424 = fadd <8 x float> %2356, %2423
  %2425 = fmul <8 x float> %2377, %2422
  %2426 = fadd <8 x float> %2358, %2425
  %2427 = fmul <8 x float> %2392, %2407
  %2428 = fadd <8 x float> %2360, %2427
  %2429 = fmul <8 x float> %2392, %2422
  %2430 = fadd <8 x float> %2362, %2429
  %tile_snapshot.spill.load913 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill88, align 64
  %2431 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load913, 0
  %2432 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load913, 1
  %.splatinsert914 = insertelement <8 x i64> poison, i64 %239, i64 0
  %.splat915 = shufflevector <8 x i64> %.splatinsert914, <8 x i64> poison, <8 x i32> zeroinitializer
  %2433 = mul <8 x i64> %.splat915, splat (i64 32)
  %2434 = add <8 x i64> %2432, %2433
  %2435 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2431, 0
  %2436 = insertvalue { <8 x ptr>, <8 x i64> } %2435, <8 x i64> %2434, 1
  %2437 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2438 = extractvalue { <8 x ptr>, <8 x i64> } %2436, 1
  %2439 = extractelement <8 x ptr> %2437, i32 0
  %2440 = extractelement <8 x i64> %2438, i32 0
  %2441 = sub i64 %2440, 0
  %2442 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2443 = select i1 %2442, i64 %2441, i64 0
  %private.contiguous.address916 = getelementptr i8, ptr %2439, i64 %2443
  %private.contiguous.preserve917 = load <8 x float>, ptr %private.contiguous.address916, align 4
  %2444 = select <8 x i1> %95, <8 x float> %2424, <8 x float> %private.contiguous.preserve917
  store <8 x float> %2444, ptr %private.contiguous.address916, align 4
  %tile_snapshot.spill.load918 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill88, align 64
  %2445 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load918, 0
  %2446 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load918, 1
  %.splatinsert919 = insertelement <8 x i64> poison, i64 %242, i64 0
  %.splat920 = shufflevector <8 x i64> %.splatinsert919, <8 x i64> poison, <8 x i32> zeroinitializer
  %2447 = mul <8 x i64> %.splat920, splat (i64 32)
  %2448 = add <8 x i64> %2446, %2447
  %2449 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2445, 0
  %2450 = insertvalue { <8 x ptr>, <8 x i64> } %2449, <8 x i64> %2448, 1
  %2451 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2452 = extractvalue { <8 x ptr>, <8 x i64> } %2450, 1
  %2453 = extractelement <8 x ptr> %2451, i32 0
  %2454 = extractelement <8 x i64> %2452, i32 0
  %2455 = sub i64 %2454, 0
  %2456 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2457 = select i1 %2456, i64 %2455, i64 0
  %private.contiguous.address921 = getelementptr i8, ptr %2453, i64 %2457
  %private.contiguous.preserve922 = load <8 x float>, ptr %private.contiguous.address921, align 4
  %2458 = select <8 x i1> %95, <8 x float> %2426, <8 x float> %private.contiguous.preserve922
  store <8 x float> %2458, ptr %private.contiguous.address921, align 4
  %tile_snapshot.spill.load923 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill88, align 64
  %2459 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load923, 0
  %2460 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load923, 1
  %.splatinsert924 = insertelement <8 x i64> poison, i64 %244, i64 0
  %.splat925 = shufflevector <8 x i64> %.splatinsert924, <8 x i64> poison, <8 x i32> zeroinitializer
  %2461 = mul <8 x i64> %.splat925, splat (i64 32)
  %2462 = add <8 x i64> %2460, %2461
  %2463 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2459, 0
  %2464 = insertvalue { <8 x ptr>, <8 x i64> } %2463, <8 x i64> %2462, 1
  %2465 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2466 = extractvalue { <8 x ptr>, <8 x i64> } %2464, 1
  %2467 = extractelement <8 x ptr> %2465, i32 0
  %2468 = extractelement <8 x i64> %2466, i32 0
  %2469 = sub i64 %2468, 0
  %2470 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2471 = select i1 %2470, i64 %2469, i64 0
  %private.contiguous.address926 = getelementptr i8, ptr %2467, i64 %2471
  %private.contiguous.preserve927 = load <8 x float>, ptr %private.contiguous.address926, align 4
  %2472 = select <8 x i1> %95, <8 x float> %2428, <8 x float> %private.contiguous.preserve927
  store <8 x float> %2472, ptr %private.contiguous.address926, align 4
  %tile_snapshot.spill.load928 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill88, align 64
  %2473 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load928, 0
  %2474 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load928, 1
  %.splatinsert929 = insertelement <8 x i64> poison, i64 %246, i64 0
  %.splat930 = shufflevector <8 x i64> %.splatinsert929, <8 x i64> poison, <8 x i32> zeroinitializer
  %2475 = mul <8 x i64> %.splat930, splat (i64 32)
  %2476 = add <8 x i64> %2474, %2475
  %2477 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2473, 0
  %2478 = insertvalue { <8 x ptr>, <8 x i64> } %2477, <8 x i64> %2476, 1
  %2479 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2480 = extractvalue { <8 x ptr>, <8 x i64> } %2478, 1
  %2481 = extractelement <8 x ptr> %2479, i32 0
  %2482 = extractelement <8 x i64> %2480, i32 0
  %2483 = sub i64 %2482, 0
  %2484 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2485 = select i1 %2484, i64 %2483, i64 0
  %private.contiguous.address931 = getelementptr i8, ptr %2481, i64 %2485
  %private.contiguous.preserve932 = load <8 x float>, ptr %private.contiguous.address931, align 4
  %2486 = select <8 x i1> %95, <8 x float> %2430, <8 x float> %private.contiguous.preserve932
  store <8 x float> %2486, ptr %private.contiguous.address931, align 4
  %.state933 = load i64, ptr %.slot91, align 4
  %2487 = add i64 %.state933, 1
  store i64 %2487, ptr %.slot91, align 4
  br label %direct.schedule.12

direct.schedule.14:                               ; preds = %direct.false271
  %.state934 = load i64, ptr %.slot89, align 4
  %2488 = add i64 %.state934, 1
  store i64 %2488, ptr %.slot89, align 4
  br label %direct.schedule.10

direct.schedule.15:                               ; preds = %direct.false267
  %.spill.load935 = load i64, ptr %.spill84, align 4
  %2489 = add i64 0, %.spill.load935
  %.spill.load936 = load i64, ptr %.spill84, align 4
  %2490 = add i64 1, %.spill.load936
  %.spill.load937 = load i64, ptr %.spill84, align 4
  %2491 = add i64 2, %.spill.load937
  %.spill.load938 = load i64, ptr %.spill84, align 4
  %2492 = add i64 3, %.spill.load938
  %.spill.load939 = load i64, ptr %.spill84, align 4
  %2493 = add i64 4, %.spill.load939
  %.spill.load940 = load i64, ptr %.spill84, align 4
  %2494 = add i64 5, %.spill.load940
  %.spill.load941 = load i64, ptr %.spill84, align 4
  %2495 = add i64 6, %.spill.load941
  %.spill.load942 = load i64, ptr %.spill84, align 4
  %2496 = add i64 7, %.spill.load942
  %.spill.load943 = load i64, ptr %.spill84, align 4
  %2497 = add i64 8, %.spill.load943
  %.spill.load944 = load i64, ptr %.spill84, align 4
  %2498 = add i64 9, %.spill.load944
  %.spill.load945 = load i64, ptr %.spill84, align 4
  %2499 = add i64 10, %.spill.load945
  %.spill.load946 = load i64, ptr %.spill84, align 4
  %2500 = add i64 11, %.spill.load946
  %.spill.load947 = load i64, ptr %.spill84, align 4
  %2501 = add i64 12, %.spill.load947
  %.spill.load948 = load i64, ptr %.spill84, align 4
  %2502 = add i64 13, %.spill.load948
  %.spill.load949 = load i64, ptr %.spill84, align 4
  %2503 = add i64 14, %.spill.load949
  %.spill.load950 = load i64, ptr %.spill84, align 4
  %2504 = add i64 15, %.spill.load950
  %2505 = icmp slt i64 %2489, 129
  %2506 = icmp slt i64 %2490, 129
  %2507 = icmp slt i64 %2491, 129
  %2508 = icmp slt i64 %2492, 129
  %2509 = icmp slt i64 %2493, 129
  %2510 = icmp slt i64 %2494, 129
  %2511 = icmp slt i64 %2495, 129
  %2512 = icmp slt i64 %2496, 129
  %2513 = icmp slt i64 %2497, 129
  %2514 = icmp slt i64 %2498, 129
  %2515 = icmp slt i64 %2499, 129
  %2516 = icmp slt i64 %2500, 129
  %2517 = icmp slt i64 %2501, 129
  %2518 = icmp slt i64 %2502, 129
  %2519 = icmp slt i64 %2503, 129
  %2520 = icmp slt i64 %2504, 129
  %2521 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill92, align 64
  %2522 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2523 = extractvalue { <8 x ptr>, <8 x i64> } %2521, 0
  %2524 = select <8 x i1> %95, <8 x ptr> %2522, <8 x ptr> %2523
  %2525 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2526 = extractvalue { <8 x ptr>, <8 x i64> } %2521, 1
  %2527 = select <8 x i1> %95, <8 x i64> %2525, <8 x i64> %2526
  %2528 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2524, 0
  %2529 = insertvalue { <8 x ptr>, <8 x i64> } %2528, <8 x i64> %2527, 1
  store { <8 x ptr>, <8 x i64> } %2529, ptr %tile_snapshot.spill92, align 64
  %2530 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2531 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2532 = add <8 x i64> %2531, zeroinitializer
  %2533 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2530, 0
  %2534 = insertvalue { <8 x ptr>, <8 x i64> } %2533, <8 x i64> %2532, 1
  %.splatinsert951 = insertelement <8 x i1> poison, i1 %2505, i64 0
  %.splat952 = shufflevector <8 x i1> %.splatinsert951, <8 x i1> poison, <8 x i32> zeroinitializer
  %2535 = extractvalue { <8 x ptr>, <8 x i64> } %2534, 0
  %2536 = extractvalue { <8 x ptr>, <8 x i64> } %2534, 1
  %2537 = getelementptr i8, <8 x ptr> %2535, <8 x i64> %2536
  %2538 = zext <8 x i1> %.splat952 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2538, <8 x ptr> align 1 %2537, <8 x i1> %95)
  %2539 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2540 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2541 = add <8 x i64> %2540, splat (i64 1)
  %2542 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2539, 0
  %2543 = insertvalue { <8 x ptr>, <8 x i64> } %2542, <8 x i64> %2541, 1
  %.splatinsert953 = insertelement <8 x i1> poison, i1 %2506, i64 0
  %.splat954 = shufflevector <8 x i1> %.splatinsert953, <8 x i1> poison, <8 x i32> zeroinitializer
  %2544 = extractvalue { <8 x ptr>, <8 x i64> } %2543, 0
  %2545 = extractvalue { <8 x ptr>, <8 x i64> } %2543, 1
  %2546 = getelementptr i8, <8 x ptr> %2544, <8 x i64> %2545
  %2547 = zext <8 x i1> %.splat954 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2547, <8 x ptr> align 1 %2546, <8 x i1> %95)
  %2548 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2549 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2550 = add <8 x i64> %2549, splat (i64 2)
  %2551 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2548, 0
  %2552 = insertvalue { <8 x ptr>, <8 x i64> } %2551, <8 x i64> %2550, 1
  %.splatinsert955 = insertelement <8 x i1> poison, i1 %2507, i64 0
  %.splat956 = shufflevector <8 x i1> %.splatinsert955, <8 x i1> poison, <8 x i32> zeroinitializer
  %2553 = extractvalue { <8 x ptr>, <8 x i64> } %2552, 0
  %2554 = extractvalue { <8 x ptr>, <8 x i64> } %2552, 1
  %2555 = getelementptr i8, <8 x ptr> %2553, <8 x i64> %2554
  %2556 = zext <8 x i1> %.splat956 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2556, <8 x ptr> align 1 %2555, <8 x i1> %95)
  %2557 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2558 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2559 = add <8 x i64> %2558, splat (i64 3)
  %2560 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2557, 0
  %2561 = insertvalue { <8 x ptr>, <8 x i64> } %2560, <8 x i64> %2559, 1
  %.splatinsert957 = insertelement <8 x i1> poison, i1 %2508, i64 0
  %.splat958 = shufflevector <8 x i1> %.splatinsert957, <8 x i1> poison, <8 x i32> zeroinitializer
  %2562 = extractvalue { <8 x ptr>, <8 x i64> } %2561, 0
  %2563 = extractvalue { <8 x ptr>, <8 x i64> } %2561, 1
  %2564 = getelementptr i8, <8 x ptr> %2562, <8 x i64> %2563
  %2565 = zext <8 x i1> %.splat958 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2565, <8 x ptr> align 1 %2564, <8 x i1> %95)
  %2566 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2567 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2568 = add <8 x i64> %2567, splat (i64 4)
  %2569 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2566, 0
  %2570 = insertvalue { <8 x ptr>, <8 x i64> } %2569, <8 x i64> %2568, 1
  %.splatinsert959 = insertelement <8 x i1> poison, i1 %2509, i64 0
  %.splat960 = shufflevector <8 x i1> %.splatinsert959, <8 x i1> poison, <8 x i32> zeroinitializer
  %2571 = extractvalue { <8 x ptr>, <8 x i64> } %2570, 0
  %2572 = extractvalue { <8 x ptr>, <8 x i64> } %2570, 1
  %2573 = getelementptr i8, <8 x ptr> %2571, <8 x i64> %2572
  %2574 = zext <8 x i1> %.splat960 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2574, <8 x ptr> align 1 %2573, <8 x i1> %95)
  %2575 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2576 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2577 = add <8 x i64> %2576, splat (i64 5)
  %2578 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2575, 0
  %2579 = insertvalue { <8 x ptr>, <8 x i64> } %2578, <8 x i64> %2577, 1
  %.splatinsert961 = insertelement <8 x i1> poison, i1 %2510, i64 0
  %.splat962 = shufflevector <8 x i1> %.splatinsert961, <8 x i1> poison, <8 x i32> zeroinitializer
  %2580 = extractvalue { <8 x ptr>, <8 x i64> } %2579, 0
  %2581 = extractvalue { <8 x ptr>, <8 x i64> } %2579, 1
  %2582 = getelementptr i8, <8 x ptr> %2580, <8 x i64> %2581
  %2583 = zext <8 x i1> %.splat962 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2583, <8 x ptr> align 1 %2582, <8 x i1> %95)
  %2584 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2585 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2586 = add <8 x i64> %2585, splat (i64 6)
  %2587 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2584, 0
  %2588 = insertvalue { <8 x ptr>, <8 x i64> } %2587, <8 x i64> %2586, 1
  %.splatinsert963 = insertelement <8 x i1> poison, i1 %2511, i64 0
  %.splat964 = shufflevector <8 x i1> %.splatinsert963, <8 x i1> poison, <8 x i32> zeroinitializer
  %2589 = extractvalue { <8 x ptr>, <8 x i64> } %2588, 0
  %2590 = extractvalue { <8 x ptr>, <8 x i64> } %2588, 1
  %2591 = getelementptr i8, <8 x ptr> %2589, <8 x i64> %2590
  %2592 = zext <8 x i1> %.splat964 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2592, <8 x ptr> align 1 %2591, <8 x i1> %95)
  %2593 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2594 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2595 = add <8 x i64> %2594, splat (i64 7)
  %2596 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2593, 0
  %2597 = insertvalue { <8 x ptr>, <8 x i64> } %2596, <8 x i64> %2595, 1
  %.splatinsert965 = insertelement <8 x i1> poison, i1 %2512, i64 0
  %.splat966 = shufflevector <8 x i1> %.splatinsert965, <8 x i1> poison, <8 x i32> zeroinitializer
  %2598 = extractvalue { <8 x ptr>, <8 x i64> } %2597, 0
  %2599 = extractvalue { <8 x ptr>, <8 x i64> } %2597, 1
  %2600 = getelementptr i8, <8 x ptr> %2598, <8 x i64> %2599
  %2601 = zext <8 x i1> %.splat966 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2601, <8 x ptr> align 1 %2600, <8 x i1> %95)
  %2602 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2603 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2604 = add <8 x i64> %2603, splat (i64 8)
  %2605 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2602, 0
  %2606 = insertvalue { <8 x ptr>, <8 x i64> } %2605, <8 x i64> %2604, 1
  %.splatinsert967 = insertelement <8 x i1> poison, i1 %2513, i64 0
  %.splat968 = shufflevector <8 x i1> %.splatinsert967, <8 x i1> poison, <8 x i32> zeroinitializer
  %2607 = extractvalue { <8 x ptr>, <8 x i64> } %2606, 0
  %2608 = extractvalue { <8 x ptr>, <8 x i64> } %2606, 1
  %2609 = getelementptr i8, <8 x ptr> %2607, <8 x i64> %2608
  %2610 = zext <8 x i1> %.splat968 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2610, <8 x ptr> align 1 %2609, <8 x i1> %95)
  %2611 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2612 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2613 = add <8 x i64> %2612, splat (i64 9)
  %2614 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2611, 0
  %2615 = insertvalue { <8 x ptr>, <8 x i64> } %2614, <8 x i64> %2613, 1
  %.splatinsert969 = insertelement <8 x i1> poison, i1 %2514, i64 0
  %.splat970 = shufflevector <8 x i1> %.splatinsert969, <8 x i1> poison, <8 x i32> zeroinitializer
  %2616 = extractvalue { <8 x ptr>, <8 x i64> } %2615, 0
  %2617 = extractvalue { <8 x ptr>, <8 x i64> } %2615, 1
  %2618 = getelementptr i8, <8 x ptr> %2616, <8 x i64> %2617
  %2619 = zext <8 x i1> %.splat970 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2619, <8 x ptr> align 1 %2618, <8 x i1> %95)
  %2620 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2621 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2622 = add <8 x i64> %2621, splat (i64 10)
  %2623 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2620, 0
  %2624 = insertvalue { <8 x ptr>, <8 x i64> } %2623, <8 x i64> %2622, 1
  %.splatinsert971 = insertelement <8 x i1> poison, i1 %2515, i64 0
  %.splat972 = shufflevector <8 x i1> %.splatinsert971, <8 x i1> poison, <8 x i32> zeroinitializer
  %2625 = extractvalue { <8 x ptr>, <8 x i64> } %2624, 0
  %2626 = extractvalue { <8 x ptr>, <8 x i64> } %2624, 1
  %2627 = getelementptr i8, <8 x ptr> %2625, <8 x i64> %2626
  %2628 = zext <8 x i1> %.splat972 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2628, <8 x ptr> align 1 %2627, <8 x i1> %95)
  %2629 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2630 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2631 = add <8 x i64> %2630, splat (i64 11)
  %2632 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2629, 0
  %2633 = insertvalue { <8 x ptr>, <8 x i64> } %2632, <8 x i64> %2631, 1
  %.splatinsert973 = insertelement <8 x i1> poison, i1 %2516, i64 0
  %.splat974 = shufflevector <8 x i1> %.splatinsert973, <8 x i1> poison, <8 x i32> zeroinitializer
  %2634 = extractvalue { <8 x ptr>, <8 x i64> } %2633, 0
  %2635 = extractvalue { <8 x ptr>, <8 x i64> } %2633, 1
  %2636 = getelementptr i8, <8 x ptr> %2634, <8 x i64> %2635
  %2637 = zext <8 x i1> %.splat974 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2637, <8 x ptr> align 1 %2636, <8 x i1> %95)
  %2638 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2639 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2640 = add <8 x i64> %2639, splat (i64 12)
  %2641 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2638, 0
  %2642 = insertvalue { <8 x ptr>, <8 x i64> } %2641, <8 x i64> %2640, 1
  %.splatinsert975 = insertelement <8 x i1> poison, i1 %2517, i64 0
  %.splat976 = shufflevector <8 x i1> %.splatinsert975, <8 x i1> poison, <8 x i32> zeroinitializer
  %2643 = extractvalue { <8 x ptr>, <8 x i64> } %2642, 0
  %2644 = extractvalue { <8 x ptr>, <8 x i64> } %2642, 1
  %2645 = getelementptr i8, <8 x ptr> %2643, <8 x i64> %2644
  %2646 = zext <8 x i1> %.splat976 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2646, <8 x ptr> align 1 %2645, <8 x i1> %95)
  %2647 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2648 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2649 = add <8 x i64> %2648, splat (i64 13)
  %2650 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2647, 0
  %2651 = insertvalue { <8 x ptr>, <8 x i64> } %2650, <8 x i64> %2649, 1
  %.splatinsert977 = insertelement <8 x i1> poison, i1 %2518, i64 0
  %.splat978 = shufflevector <8 x i1> %.splatinsert977, <8 x i1> poison, <8 x i32> zeroinitializer
  %2652 = extractvalue { <8 x ptr>, <8 x i64> } %2651, 0
  %2653 = extractvalue { <8 x ptr>, <8 x i64> } %2651, 1
  %2654 = getelementptr i8, <8 x ptr> %2652, <8 x i64> %2653
  %2655 = zext <8 x i1> %.splat978 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2655, <8 x ptr> align 1 %2654, <8 x i1> %95)
  %2656 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2657 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2658 = add <8 x i64> %2657, splat (i64 14)
  %2659 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2656, 0
  %2660 = insertvalue { <8 x ptr>, <8 x i64> } %2659, <8 x i64> %2658, 1
  %.splatinsert979 = insertelement <8 x i1> poison, i1 %2519, i64 0
  %.splat980 = shufflevector <8 x i1> %.splatinsert979, <8 x i1> poison, <8 x i32> zeroinitializer
  %2661 = extractvalue { <8 x ptr>, <8 x i64> } %2660, 0
  %2662 = extractvalue { <8 x ptr>, <8 x i64> } %2660, 1
  %2663 = getelementptr i8, <8 x ptr> %2661, <8 x i64> %2662
  %2664 = zext <8 x i1> %.splat980 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2664, <8 x ptr> align 1 %2663, <8 x i1> %95)
  %2665 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2666 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2667 = add <8 x i64> %2666, splat (i64 15)
  %2668 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2665, 0
  %2669 = insertvalue { <8 x ptr>, <8 x i64> } %2668, <8 x i64> %2667, 1
  %.splatinsert981 = insertelement <8 x i1> poison, i1 %2520, i64 0
  %.splat982 = shufflevector <8 x i1> %.splatinsert981, <8 x i1> poison, <8 x i32> zeroinitializer
  %2670 = extractvalue { <8 x ptr>, <8 x i64> } %2669, 0
  %2671 = extractvalue { <8 x ptr>, <8 x i64> } %2669, 1
  %2672 = getelementptr i8, <8 x ptr> %2670, <8 x i64> %2671
  %2673 = zext <8 x i1> %.splat982 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2673, <8 x ptr> align 1 %2672, <8 x i1> %95)
  %2674 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill93, align 64
  %2675 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2676 = extractvalue { <8 x ptr>, <8 x i64> } %2674, 0
  %2677 = select <8 x i1> %95, <8 x ptr> %2675, <8 x ptr> %2676
  %2678 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2679 = extractvalue { <8 x ptr>, <8 x i64> } %2674, 1
  %2680 = select <8 x i1> %95, <8 x i64> %2678, <8 x i64> %2679
  %2681 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2677, 0
  %2682 = insertvalue { <8 x ptr>, <8 x i64> } %2681, <8 x i64> %2680, 1
  store { <8 x ptr>, <8 x i64> } %2682, ptr %tile_snapshot.spill93, align 64
  %2683 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2684 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2685 = add <8 x i64> %2684, zeroinitializer
  %2686 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2683, 0
  %2687 = insertvalue { <8 x ptr>, <8 x i64> } %2686, <8 x i64> %2685, 1
  %.splatinsert983 = insertelement <8 x i64> poison, i64 %2489, i64 0
  %.splat984 = shufflevector <8 x i64> %.splatinsert983, <8 x i64> poison, <8 x i32> zeroinitializer
  %2688 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2689 = extractvalue { <8 x ptr>, <8 x i64> } %2687, 1
  %2690 = extractelement <8 x ptr> %2688, i32 0
  %2691 = extractelement <8 x i64> %2689, i32 0
  %2692 = sub i64 %2691, 0
  %2693 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2694 = select i1 %2693, i64 %2692, i64 0
  %private.contiguous.address985 = getelementptr i8, ptr %2690, i64 %2694
  %private.contiguous.preserve986 = load <8 x i64>, ptr %private.contiguous.address985, align 8
  %2695 = select <8 x i1> %95, <8 x i64> %.splat984, <8 x i64> %private.contiguous.preserve986
  store <8 x i64> %2695, ptr %private.contiguous.address985, align 8
  %2696 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2697 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2698 = add <8 x i64> %2697, splat (i64 64)
  %2699 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2696, 0
  %2700 = insertvalue { <8 x ptr>, <8 x i64> } %2699, <8 x i64> %2698, 1
  %.splatinsert987 = insertelement <8 x i64> poison, i64 %2490, i64 0
  %.splat988 = shufflevector <8 x i64> %.splatinsert987, <8 x i64> poison, <8 x i32> zeroinitializer
  %2701 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2702 = extractvalue { <8 x ptr>, <8 x i64> } %2700, 1
  %2703 = extractelement <8 x ptr> %2701, i32 0
  %2704 = extractelement <8 x i64> %2702, i32 0
  %2705 = sub i64 %2704, 0
  %2706 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2707 = select i1 %2706, i64 %2705, i64 0
  %private.contiguous.address989 = getelementptr i8, ptr %2703, i64 %2707
  %private.contiguous.preserve990 = load <8 x i64>, ptr %private.contiguous.address989, align 8
  %2708 = select <8 x i1> %95, <8 x i64> %.splat988, <8 x i64> %private.contiguous.preserve990
  store <8 x i64> %2708, ptr %private.contiguous.address989, align 8
  %2709 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2710 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2711 = add <8 x i64> %2710, splat (i64 128)
  %2712 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2709, 0
  %2713 = insertvalue { <8 x ptr>, <8 x i64> } %2712, <8 x i64> %2711, 1
  %.splatinsert991 = insertelement <8 x i64> poison, i64 %2491, i64 0
  %.splat992 = shufflevector <8 x i64> %.splatinsert991, <8 x i64> poison, <8 x i32> zeroinitializer
  %2714 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2715 = extractvalue { <8 x ptr>, <8 x i64> } %2713, 1
  %2716 = extractelement <8 x ptr> %2714, i32 0
  %2717 = extractelement <8 x i64> %2715, i32 0
  %2718 = sub i64 %2717, 0
  %2719 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2720 = select i1 %2719, i64 %2718, i64 0
  %private.contiguous.address993 = getelementptr i8, ptr %2716, i64 %2720
  %private.contiguous.preserve994 = load <8 x i64>, ptr %private.contiguous.address993, align 8
  %2721 = select <8 x i1> %95, <8 x i64> %.splat992, <8 x i64> %private.contiguous.preserve994
  store <8 x i64> %2721, ptr %private.contiguous.address993, align 8
  %2722 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2723 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2724 = add <8 x i64> %2723, splat (i64 192)
  %2725 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2722, 0
  %2726 = insertvalue { <8 x ptr>, <8 x i64> } %2725, <8 x i64> %2724, 1
  %.splatinsert995 = insertelement <8 x i64> poison, i64 %2492, i64 0
  %.splat996 = shufflevector <8 x i64> %.splatinsert995, <8 x i64> poison, <8 x i32> zeroinitializer
  %2727 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2728 = extractvalue { <8 x ptr>, <8 x i64> } %2726, 1
  %2729 = extractelement <8 x ptr> %2727, i32 0
  %2730 = extractelement <8 x i64> %2728, i32 0
  %2731 = sub i64 %2730, 0
  %2732 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2733 = select i1 %2732, i64 %2731, i64 0
  %private.contiguous.address997 = getelementptr i8, ptr %2729, i64 %2733
  %private.contiguous.preserve998 = load <8 x i64>, ptr %private.contiguous.address997, align 8
  %2734 = select <8 x i1> %95, <8 x i64> %.splat996, <8 x i64> %private.contiguous.preserve998
  store <8 x i64> %2734, ptr %private.contiguous.address997, align 8
  %2735 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2736 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2737 = add <8 x i64> %2736, splat (i64 256)
  %2738 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2735, 0
  %2739 = insertvalue { <8 x ptr>, <8 x i64> } %2738, <8 x i64> %2737, 1
  %.splatinsert999 = insertelement <8 x i64> poison, i64 %2493, i64 0
  %.splat1000 = shufflevector <8 x i64> %.splatinsert999, <8 x i64> poison, <8 x i32> zeroinitializer
  %2740 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2741 = extractvalue { <8 x ptr>, <8 x i64> } %2739, 1
  %2742 = extractelement <8 x ptr> %2740, i32 0
  %2743 = extractelement <8 x i64> %2741, i32 0
  %2744 = sub i64 %2743, 0
  %2745 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2746 = select i1 %2745, i64 %2744, i64 0
  %private.contiguous.address1001 = getelementptr i8, ptr %2742, i64 %2746
  %private.contiguous.preserve1002 = load <8 x i64>, ptr %private.contiguous.address1001, align 8
  %2747 = select <8 x i1> %95, <8 x i64> %.splat1000, <8 x i64> %private.contiguous.preserve1002
  store <8 x i64> %2747, ptr %private.contiguous.address1001, align 8
  %2748 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2749 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2750 = add <8 x i64> %2749, splat (i64 320)
  %2751 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2748, 0
  %2752 = insertvalue { <8 x ptr>, <8 x i64> } %2751, <8 x i64> %2750, 1
  %.splatinsert1003 = insertelement <8 x i64> poison, i64 %2494, i64 0
  %.splat1004 = shufflevector <8 x i64> %.splatinsert1003, <8 x i64> poison, <8 x i32> zeroinitializer
  %2753 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2754 = extractvalue { <8 x ptr>, <8 x i64> } %2752, 1
  %2755 = extractelement <8 x ptr> %2753, i32 0
  %2756 = extractelement <8 x i64> %2754, i32 0
  %2757 = sub i64 %2756, 0
  %2758 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2759 = select i1 %2758, i64 %2757, i64 0
  %private.contiguous.address1005 = getelementptr i8, ptr %2755, i64 %2759
  %private.contiguous.preserve1006 = load <8 x i64>, ptr %private.contiguous.address1005, align 8
  %2760 = select <8 x i1> %95, <8 x i64> %.splat1004, <8 x i64> %private.contiguous.preserve1006
  store <8 x i64> %2760, ptr %private.contiguous.address1005, align 8
  %2761 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2762 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2763 = add <8 x i64> %2762, splat (i64 384)
  %2764 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2761, 0
  %2765 = insertvalue { <8 x ptr>, <8 x i64> } %2764, <8 x i64> %2763, 1
  %.splatinsert1007 = insertelement <8 x i64> poison, i64 %2495, i64 0
  %.splat1008 = shufflevector <8 x i64> %.splatinsert1007, <8 x i64> poison, <8 x i32> zeroinitializer
  %2766 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2767 = extractvalue { <8 x ptr>, <8 x i64> } %2765, 1
  %2768 = extractelement <8 x ptr> %2766, i32 0
  %2769 = extractelement <8 x i64> %2767, i32 0
  %2770 = sub i64 %2769, 0
  %2771 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2772 = select i1 %2771, i64 %2770, i64 0
  %private.contiguous.address1009 = getelementptr i8, ptr %2768, i64 %2772
  %private.contiguous.preserve1010 = load <8 x i64>, ptr %private.contiguous.address1009, align 8
  %2773 = select <8 x i1> %95, <8 x i64> %.splat1008, <8 x i64> %private.contiguous.preserve1010
  store <8 x i64> %2773, ptr %private.contiguous.address1009, align 8
  %2774 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2775 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2776 = add <8 x i64> %2775, splat (i64 448)
  %2777 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2774, 0
  %2778 = insertvalue { <8 x ptr>, <8 x i64> } %2777, <8 x i64> %2776, 1
  %.splatinsert1011 = insertelement <8 x i64> poison, i64 %2496, i64 0
  %.splat1012 = shufflevector <8 x i64> %.splatinsert1011, <8 x i64> poison, <8 x i32> zeroinitializer
  %2779 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2780 = extractvalue { <8 x ptr>, <8 x i64> } %2778, 1
  %2781 = extractelement <8 x ptr> %2779, i32 0
  %2782 = extractelement <8 x i64> %2780, i32 0
  %2783 = sub i64 %2782, 0
  %2784 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2785 = select i1 %2784, i64 %2783, i64 0
  %private.contiguous.address1013 = getelementptr i8, ptr %2781, i64 %2785
  %private.contiguous.preserve1014 = load <8 x i64>, ptr %private.contiguous.address1013, align 8
  %2786 = select <8 x i1> %95, <8 x i64> %.splat1012, <8 x i64> %private.contiguous.preserve1014
  store <8 x i64> %2786, ptr %private.contiguous.address1013, align 8
  %2787 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2788 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2789 = add <8 x i64> %2788, splat (i64 512)
  %2790 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2787, 0
  %2791 = insertvalue { <8 x ptr>, <8 x i64> } %2790, <8 x i64> %2789, 1
  %.splatinsert1015 = insertelement <8 x i64> poison, i64 %2497, i64 0
  %.splat1016 = shufflevector <8 x i64> %.splatinsert1015, <8 x i64> poison, <8 x i32> zeroinitializer
  %2792 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2793 = extractvalue { <8 x ptr>, <8 x i64> } %2791, 1
  %2794 = extractelement <8 x ptr> %2792, i32 0
  %2795 = extractelement <8 x i64> %2793, i32 0
  %2796 = sub i64 %2795, 0
  %2797 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2798 = select i1 %2797, i64 %2796, i64 0
  %private.contiguous.address1017 = getelementptr i8, ptr %2794, i64 %2798
  %private.contiguous.preserve1018 = load <8 x i64>, ptr %private.contiguous.address1017, align 8
  %2799 = select <8 x i1> %95, <8 x i64> %.splat1016, <8 x i64> %private.contiguous.preserve1018
  store <8 x i64> %2799, ptr %private.contiguous.address1017, align 8
  %2800 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2801 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2802 = add <8 x i64> %2801, splat (i64 576)
  %2803 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2800, 0
  %2804 = insertvalue { <8 x ptr>, <8 x i64> } %2803, <8 x i64> %2802, 1
  %.splatinsert1019 = insertelement <8 x i64> poison, i64 %2498, i64 0
  %.splat1020 = shufflevector <8 x i64> %.splatinsert1019, <8 x i64> poison, <8 x i32> zeroinitializer
  %2805 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2806 = extractvalue { <8 x ptr>, <8 x i64> } %2804, 1
  %2807 = extractelement <8 x ptr> %2805, i32 0
  %2808 = extractelement <8 x i64> %2806, i32 0
  %2809 = sub i64 %2808, 0
  %2810 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2811 = select i1 %2810, i64 %2809, i64 0
  %private.contiguous.address1021 = getelementptr i8, ptr %2807, i64 %2811
  %private.contiguous.preserve1022 = load <8 x i64>, ptr %private.contiguous.address1021, align 8
  %2812 = select <8 x i1> %95, <8 x i64> %.splat1020, <8 x i64> %private.contiguous.preserve1022
  store <8 x i64> %2812, ptr %private.contiguous.address1021, align 8
  %2813 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2814 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2815 = add <8 x i64> %2814, splat (i64 640)
  %2816 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2813, 0
  %2817 = insertvalue { <8 x ptr>, <8 x i64> } %2816, <8 x i64> %2815, 1
  %.splatinsert1023 = insertelement <8 x i64> poison, i64 %2499, i64 0
  %.splat1024 = shufflevector <8 x i64> %.splatinsert1023, <8 x i64> poison, <8 x i32> zeroinitializer
  %2818 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2819 = extractvalue { <8 x ptr>, <8 x i64> } %2817, 1
  %2820 = extractelement <8 x ptr> %2818, i32 0
  %2821 = extractelement <8 x i64> %2819, i32 0
  %2822 = sub i64 %2821, 0
  %2823 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2824 = select i1 %2823, i64 %2822, i64 0
  %private.contiguous.address1025 = getelementptr i8, ptr %2820, i64 %2824
  %private.contiguous.preserve1026 = load <8 x i64>, ptr %private.contiguous.address1025, align 8
  %2825 = select <8 x i1> %95, <8 x i64> %.splat1024, <8 x i64> %private.contiguous.preserve1026
  store <8 x i64> %2825, ptr %private.contiguous.address1025, align 8
  %2826 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2827 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2828 = add <8 x i64> %2827, splat (i64 704)
  %2829 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2826, 0
  %2830 = insertvalue { <8 x ptr>, <8 x i64> } %2829, <8 x i64> %2828, 1
  %.splatinsert1027 = insertelement <8 x i64> poison, i64 %2500, i64 0
  %.splat1028 = shufflevector <8 x i64> %.splatinsert1027, <8 x i64> poison, <8 x i32> zeroinitializer
  %2831 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2832 = extractvalue { <8 x ptr>, <8 x i64> } %2830, 1
  %2833 = extractelement <8 x ptr> %2831, i32 0
  %2834 = extractelement <8 x i64> %2832, i32 0
  %2835 = sub i64 %2834, 0
  %2836 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2837 = select i1 %2836, i64 %2835, i64 0
  %private.contiguous.address1029 = getelementptr i8, ptr %2833, i64 %2837
  %private.contiguous.preserve1030 = load <8 x i64>, ptr %private.contiguous.address1029, align 8
  %2838 = select <8 x i1> %95, <8 x i64> %.splat1028, <8 x i64> %private.contiguous.preserve1030
  store <8 x i64> %2838, ptr %private.contiguous.address1029, align 8
  %2839 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2840 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2841 = add <8 x i64> %2840, splat (i64 768)
  %2842 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2839, 0
  %2843 = insertvalue { <8 x ptr>, <8 x i64> } %2842, <8 x i64> %2841, 1
  %.splatinsert1031 = insertelement <8 x i64> poison, i64 %2501, i64 0
  %.splat1032 = shufflevector <8 x i64> %.splatinsert1031, <8 x i64> poison, <8 x i32> zeroinitializer
  %2844 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2845 = extractvalue { <8 x ptr>, <8 x i64> } %2843, 1
  %2846 = extractelement <8 x ptr> %2844, i32 0
  %2847 = extractelement <8 x i64> %2845, i32 0
  %2848 = sub i64 %2847, 0
  %2849 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2850 = select i1 %2849, i64 %2848, i64 0
  %private.contiguous.address1033 = getelementptr i8, ptr %2846, i64 %2850
  %private.contiguous.preserve1034 = load <8 x i64>, ptr %private.contiguous.address1033, align 8
  %2851 = select <8 x i1> %95, <8 x i64> %.splat1032, <8 x i64> %private.contiguous.preserve1034
  store <8 x i64> %2851, ptr %private.contiguous.address1033, align 8
  %2852 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2853 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2854 = add <8 x i64> %2853, splat (i64 832)
  %2855 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2852, 0
  %2856 = insertvalue { <8 x ptr>, <8 x i64> } %2855, <8 x i64> %2854, 1
  %.splatinsert1035 = insertelement <8 x i64> poison, i64 %2502, i64 0
  %.splat1036 = shufflevector <8 x i64> %.splatinsert1035, <8 x i64> poison, <8 x i32> zeroinitializer
  %2857 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2858 = extractvalue { <8 x ptr>, <8 x i64> } %2856, 1
  %2859 = extractelement <8 x ptr> %2857, i32 0
  %2860 = extractelement <8 x i64> %2858, i32 0
  %2861 = sub i64 %2860, 0
  %2862 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2863 = select i1 %2862, i64 %2861, i64 0
  %private.contiguous.address1037 = getelementptr i8, ptr %2859, i64 %2863
  %private.contiguous.preserve1038 = load <8 x i64>, ptr %private.contiguous.address1037, align 8
  %2864 = select <8 x i1> %95, <8 x i64> %.splat1036, <8 x i64> %private.contiguous.preserve1038
  store <8 x i64> %2864, ptr %private.contiguous.address1037, align 8
  %2865 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2866 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2867 = add <8 x i64> %2866, splat (i64 896)
  %2868 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2865, 0
  %2869 = insertvalue { <8 x ptr>, <8 x i64> } %2868, <8 x i64> %2867, 1
  %.splatinsert1039 = insertelement <8 x i64> poison, i64 %2503, i64 0
  %.splat1040 = shufflevector <8 x i64> %.splatinsert1039, <8 x i64> poison, <8 x i32> zeroinitializer
  %2870 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2871 = extractvalue { <8 x ptr>, <8 x i64> } %2869, 1
  %2872 = extractelement <8 x ptr> %2870, i32 0
  %2873 = extractelement <8 x i64> %2871, i32 0
  %2874 = sub i64 %2873, 0
  %2875 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2876 = select i1 %2875, i64 %2874, i64 0
  %private.contiguous.address1041 = getelementptr i8, ptr %2872, i64 %2876
  %private.contiguous.preserve1042 = load <8 x i64>, ptr %private.contiguous.address1041, align 8
  %2877 = select <8 x i1> %95, <8 x i64> %.splat1040, <8 x i64> %private.contiguous.preserve1042
  store <8 x i64> %2877, ptr %private.contiguous.address1041, align 8
  %2878 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2879 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2880 = add <8 x i64> %2879, splat (i64 960)
  %2881 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2878, 0
  %2882 = insertvalue { <8 x ptr>, <8 x i64> } %2881, <8 x i64> %2880, 1
  %.splatinsert1043 = insertelement <8 x i64> poison, i64 %2504, i64 0
  %.splat1044 = shufflevector <8 x i64> %.splatinsert1043, <8 x i64> poison, <8 x i32> zeroinitializer
  %2883 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2884 = extractvalue { <8 x ptr>, <8 x i64> } %2882, 1
  %2885 = extractelement <8 x ptr> %2883, i32 0
  %2886 = extractelement <8 x i64> %2884, i32 0
  %2887 = sub i64 %2886, 0
  %2888 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2889 = select i1 %2888, i64 %2887, i64 0
  %private.contiguous.address1045 = getelementptr i8, ptr %2885, i64 %2889
  %private.contiguous.preserve1046 = load <8 x i64>, ptr %private.contiguous.address1045, align 8
  %2890 = select <8 x i1> %95, <8 x i64> %.splat1044, <8 x i64> %private.contiguous.preserve1046
  store <8 x i64> %2890, ptr %private.contiguous.address1045, align 8
  %.spill.load1047 = load <8 x i64>, ptr %.spill61, align 64
  %2891 = add <8 x i64> zeroinitializer, %.spill.load1047
  %.spill.load1048 = load <8 x i64>, ptr %.spill61, align 64
  %2892 = add <8 x i64> splat (i64 1), %.spill.load1048
  %.spill.load1049 = load <8 x i64>, ptr %.spill61, align 64
  %2893 = add <8 x i64> splat (i64 2), %.spill.load1049
  %.spill.load1050 = load <8 x i64>, ptr %.spill61, align 64
  %2894 = add <8 x i64> splat (i64 3), %.spill.load1050
  %.spill.load1051 = load <8 x i64>, ptr %.spill61, align 64
  %2895 = add <8 x i64> splat (i64 4), %.spill.load1051
  %.spill.load1052 = load <8 x i64>, ptr %.spill61, align 64
  %2896 = add <8 x i64> splat (i64 5), %.spill.load1052
  %.spill.load1053 = load <8 x i64>, ptr %.spill61, align 64
  %2897 = add <8 x i64> splat (i64 6), %.spill.load1053
  %.spill.load1054 = load <8 x i64>, ptr %.spill61, align 64
  %2898 = add <8 x i64> splat (i64 7), %.spill.load1054
  %2899 = add <8 x i64> %2891, splat (i64 129)
  %2900 = add <8 x i64> %2892, splat (i64 129)
  %2901 = add <8 x i64> %2893, splat (i64 129)
  %2902 = add <8 x i64> %2894, splat (i64 129)
  %2903 = add <8 x i64> %2895, splat (i64 129)
  %2904 = add <8 x i64> %2896, splat (i64 129)
  %2905 = add <8 x i64> %2897, splat (i64 129)
  %2906 = add <8 x i64> %2898, splat (i64 129)
  %2907 = sub <8 x i64> %2899, splat (i64 64)
  %2908 = sub <8 x i64> %2900, splat (i64 64)
  %2909 = sub <8 x i64> %2901, splat (i64 64)
  %2910 = sub <8 x i64> %2902, splat (i64 64)
  %2911 = sub <8 x i64> %2903, splat (i64 64)
  %2912 = sub <8 x i64> %2904, splat (i64 64)
  %2913 = sub <8 x i64> %2905, splat (i64 64)
  %2914 = sub <8 x i64> %2906, splat (i64 64)
  %2915 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill94, align 64
  %2916 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2917 = extractvalue { <8 x ptr>, <8 x i64> } %2915, 0
  %2918 = select <8 x i1> %95, <8 x ptr> %2916, <8 x ptr> %2917
  %2919 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2920 = extractvalue { <8 x ptr>, <8 x i64> } %2915, 1
  %2921 = select <8 x i1> %95, <8 x i64> %2919, <8 x i64> %2920
  %2922 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2918, 0
  %2923 = insertvalue { <8 x ptr>, <8 x i64> } %2922, <8 x i64> %2921, 1
  store { <8 x ptr>, <8 x i64> } %2923, ptr %tile_snapshot.spill94, align 64
  %2924 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2925 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2926 = add <8 x i64> %2925, zeroinitializer
  %2927 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2924, 0
  %2928 = insertvalue { <8 x ptr>, <8 x i64> } %2927, <8 x i64> %2926, 1
  %2929 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2930 = extractvalue { <8 x ptr>, <8 x i64> } %2928, 1
  %2931 = extractelement <8 x ptr> %2929, i32 0
  %2932 = extractelement <8 x i64> %2930, i32 0
  %2933 = sub i64 %2932, 0
  %2934 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2935 = select i1 %2934, i64 %2933, i64 0
  %private.contiguous.address1055 = getelementptr i8, ptr %2931, i64 %2935
  %private.contiguous.preserve1056 = load <8 x i64>, ptr %private.contiguous.address1055, align 8
  %2936 = select <8 x i1> %95, <8 x i64> %2907, <8 x i64> %private.contiguous.preserve1056
  store <8 x i64> %2936, ptr %private.contiguous.address1055, align 8
  %2937 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2938 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2939 = add <8 x i64> %2938, splat (i64 64)
  %2940 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2937, 0
  %2941 = insertvalue { <8 x ptr>, <8 x i64> } %2940, <8 x i64> %2939, 1
  %2942 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2943 = extractvalue { <8 x ptr>, <8 x i64> } %2941, 1
  %2944 = extractelement <8 x ptr> %2942, i32 0
  %2945 = extractelement <8 x i64> %2943, i32 0
  %2946 = sub i64 %2945, 0
  %2947 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2948 = select i1 %2947, i64 %2946, i64 0
  %private.contiguous.address1057 = getelementptr i8, ptr %2944, i64 %2948
  %private.contiguous.preserve1058 = load <8 x i64>, ptr %private.contiguous.address1057, align 8
  %2949 = select <8 x i1> %95, <8 x i64> %2908, <8 x i64> %private.contiguous.preserve1058
  store <8 x i64> %2949, ptr %private.contiguous.address1057, align 8
  %2950 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2951 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2952 = add <8 x i64> %2951, splat (i64 128)
  %2953 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2950, 0
  %2954 = insertvalue { <8 x ptr>, <8 x i64> } %2953, <8 x i64> %2952, 1
  %2955 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2956 = extractvalue { <8 x ptr>, <8 x i64> } %2954, 1
  %2957 = extractelement <8 x ptr> %2955, i32 0
  %2958 = extractelement <8 x i64> %2956, i32 0
  %2959 = sub i64 %2958, 0
  %2960 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2961 = select i1 %2960, i64 %2959, i64 0
  %private.contiguous.address1059 = getelementptr i8, ptr %2957, i64 %2961
  %private.contiguous.preserve1060 = load <8 x i64>, ptr %private.contiguous.address1059, align 8
  %2962 = select <8 x i1> %95, <8 x i64> %2909, <8 x i64> %private.contiguous.preserve1060
  store <8 x i64> %2962, ptr %private.contiguous.address1059, align 8
  %2963 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2964 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2965 = add <8 x i64> %2964, splat (i64 192)
  %2966 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2963, 0
  %2967 = insertvalue { <8 x ptr>, <8 x i64> } %2966, <8 x i64> %2965, 1
  %2968 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2969 = extractvalue { <8 x ptr>, <8 x i64> } %2967, 1
  %2970 = extractelement <8 x ptr> %2968, i32 0
  %2971 = extractelement <8 x i64> %2969, i32 0
  %2972 = sub i64 %2971, 0
  %2973 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2974 = select i1 %2973, i64 %2972, i64 0
  %private.contiguous.address1061 = getelementptr i8, ptr %2970, i64 %2974
  %private.contiguous.preserve1062 = load <8 x i64>, ptr %private.contiguous.address1061, align 8
  %2975 = select <8 x i1> %95, <8 x i64> %2910, <8 x i64> %private.contiguous.preserve1062
  store <8 x i64> %2975, ptr %private.contiguous.address1061, align 8
  %2976 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2977 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2978 = add <8 x i64> %2977, splat (i64 256)
  %2979 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2976, 0
  %2980 = insertvalue { <8 x ptr>, <8 x i64> } %2979, <8 x i64> %2978, 1
  %2981 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2982 = extractvalue { <8 x ptr>, <8 x i64> } %2980, 1
  %2983 = extractelement <8 x ptr> %2981, i32 0
  %2984 = extractelement <8 x i64> %2982, i32 0
  %2985 = sub i64 %2984, 0
  %2986 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2987 = select i1 %2986, i64 %2985, i64 0
  %private.contiguous.address1063 = getelementptr i8, ptr %2983, i64 %2987
  %private.contiguous.preserve1064 = load <8 x i64>, ptr %private.contiguous.address1063, align 8
  %2988 = select <8 x i1> %95, <8 x i64> %2911, <8 x i64> %private.contiguous.preserve1064
  store <8 x i64> %2988, ptr %private.contiguous.address1063, align 8
  %2989 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2990 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2991 = add <8 x i64> %2990, splat (i64 320)
  %2992 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2989, 0
  %2993 = insertvalue { <8 x ptr>, <8 x i64> } %2992, <8 x i64> %2991, 1
  %2994 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2995 = extractvalue { <8 x ptr>, <8 x i64> } %2993, 1
  %2996 = extractelement <8 x ptr> %2994, i32 0
  %2997 = extractelement <8 x i64> %2995, i32 0
  %2998 = sub i64 %2997, 0
  %2999 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3000 = select i1 %2999, i64 %2998, i64 0
  %private.contiguous.address1065 = getelementptr i8, ptr %2996, i64 %3000
  %private.contiguous.preserve1066 = load <8 x i64>, ptr %private.contiguous.address1065, align 8
  %3001 = select <8 x i1> %95, <8 x i64> %2912, <8 x i64> %private.contiguous.preserve1066
  store <8 x i64> %3001, ptr %private.contiguous.address1065, align 8
  %3002 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3003 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %3004 = add <8 x i64> %3003, splat (i64 384)
  %3005 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3002, 0
  %3006 = insertvalue { <8 x ptr>, <8 x i64> } %3005, <8 x i64> %3004, 1
  %3007 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3008 = extractvalue { <8 x ptr>, <8 x i64> } %3006, 1
  %3009 = extractelement <8 x ptr> %3007, i32 0
  %3010 = extractelement <8 x i64> %3008, i32 0
  %3011 = sub i64 %3010, 0
  %3012 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3013 = select i1 %3012, i64 %3011, i64 0
  %private.contiguous.address1067 = getelementptr i8, ptr %3009, i64 %3013
  %private.contiguous.preserve1068 = load <8 x i64>, ptr %private.contiguous.address1067, align 8
  %3014 = select <8 x i1> %95, <8 x i64> %2913, <8 x i64> %private.contiguous.preserve1068
  store <8 x i64> %3014, ptr %private.contiguous.address1067, align 8
  %3015 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3016 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %3017 = add <8 x i64> %3016, splat (i64 448)
  %3018 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3015, 0
  %3019 = insertvalue { <8 x ptr>, <8 x i64> } %3018, <8 x i64> %3017, 1
  %3020 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3021 = extractvalue { <8 x ptr>, <8 x i64> } %3019, 1
  %3022 = extractelement <8 x ptr> %3020, i32 0
  %3023 = extractelement <8 x i64> %3021, i32 0
  %3024 = sub i64 %3023, 0
  %3025 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3026 = select i1 %3025, i64 %3024, i64 0
  %private.contiguous.address1069 = getelementptr i8, ptr %3022, i64 %3026
  %private.contiguous.preserve1070 = load <8 x i64>, ptr %private.contiguous.address1069, align 8
  %3027 = select <8 x i1> %95, <8 x i64> %2914, <8 x i64> %private.contiguous.preserve1070
  store <8 x i64> %3027, ptr %private.contiguous.address1069, align 8
  %3028 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %3029 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %3030 = extractvalue { <8 x ptr>, <8 x i64> } %3028, 0
  %3031 = select <8 x i1> %95, <8 x ptr> %3029, <8 x ptr> %3030
  %3032 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %3033 = extractvalue { <8 x ptr>, <8 x i64> } %3028, 1
  %3034 = select <8 x i1> %95, <8 x i64> %3032, <8 x i64> %3033
  %3035 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3031, 0
  %3036 = insertvalue { <8 x ptr>, <8 x i64> } %3035, <8 x i64> %3034, 1
  store { <8 x ptr>, <8 x i64> } %3036, ptr %tile_snapshot.spill95, align 64
  store i64 0, ptr %.slot96, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state1071 = load i64, ptr %.slot96, align 4
  %3037 = icmp slt i64 %.state1071, 128
  br i1 %3037, label %direct.true1072, label %direct.false1073

direct.schedule.17:                               ; preds = %direct.true1072
  %.state1074 = load i64, ptr %.slot96, align 4
  %3038 = srem i64 %.state1074, 8
  %.state1075 = load i64, ptr %.slot96, align 4
  %3039 = sdiv i64 %.state1075, 8
  %3040 = add i64 0, %3039
  %tile_snapshot.spill.load1076 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill92, align 64
  %3041 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1076, 0
  %3042 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1076, 1
  %.splatinsert1077 = insertelement <8 x i64> poison, i64 %3040, i64 0
  %.splat1078 = shufflevector <8 x i64> %.splatinsert1077, <8 x i64> poison, <8 x i32> zeroinitializer
  %3043 = add <8 x i64> %3042, %.splat1078
  %3044 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3041, 0
  %3045 = insertvalue { <8 x ptr>, <8 x i64> } %3044, <8 x i64> %3043, 1
  %3046 = extractvalue { <8 x ptr>, <8 x i64> } %3045, 0
  %3047 = extractvalue { <8 x ptr>, <8 x i64> } %3045, 1
  %3048 = getelementptr i8, <8 x ptr> %3046, <8 x i64> %3047
  %3049 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %3048, <8 x i1> %95, <8 x i8> zeroinitializer)
  %3050 = icmp ne <8 x i8> %3049, zeroinitializer
  %3051 = mul i64 %3040, 8
  %3052 = add i64 %3051, %3038
  %3053 = srem i64 %3052, 8
  %3054 = sdiv i64 %3052, 8
  %3055 = add i64 0, %3054
  %tile_snapshot.spill.load1079 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill93, align 64
  %3056 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1079, 0
  %3057 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1079, 1
  %.splatinsert1080 = insertelement <8 x i64> poison, i64 %3055, i64 0
  %.splat1081 = shufflevector <8 x i64> %.splatinsert1080, <8 x i64> poison, <8 x i32> zeroinitializer
  %3058 = mul <8 x i64> %.splat1081, splat (i64 64)
  %3059 = add <8 x i64> %3057, %3058
  %3060 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3056, 0
  %3061 = insertvalue { <8 x ptr>, <8 x i64> } %3060, <8 x i64> %3059, 1
  %3062 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3063 = extractvalue { <8 x ptr>, <8 x i64> } %3061, 1
  %3064 = extractelement <8 x ptr> %3062, i32 0
  %3065 = extractelement <8 x i64> %3063, i32 0
  %3066 = sub i64 %3065, 0
  %3067 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3068 = select i1 %3067, i64 %3066, i64 0
  %private.contiguous.address1082 = getelementptr i8, ptr %3064, i64 %3068
  %private.contiguous.load1083 = load <8 x i64>, ptr %private.contiguous.address1082, align 8
  %3069 = select <8 x i1> %95, <8 x i64> %private.contiguous.load1083, <8 x i64> zeroinitializer
  %3070 = add i64 0, %3053
  %tile_snapshot.spill.load1084 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill94, align 64
  %3071 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1084, 0
  %3072 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1084, 1
  %.splatinsert1085 = insertelement <8 x i64> poison, i64 %3070, i64 0
  %.splat1086 = shufflevector <8 x i64> %.splatinsert1085, <8 x i64> poison, <8 x i32> zeroinitializer
  %3073 = mul <8 x i64> %.splat1086, splat (i64 64)
  %3074 = add <8 x i64> %3072, %3073
  %3075 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3071, 0
  %3076 = insertvalue { <8 x ptr>, <8 x i64> } %3075, <8 x i64> %3074, 1
  %3077 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %3078 = extractvalue { <8 x ptr>, <8 x i64> } %3076, 1
  %3079 = extractelement <8 x ptr> %3077, i32 0
  %3080 = extractelement <8 x i64> %3078, i32 0
  %3081 = sub i64 %3080, 0
  %3082 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3083 = select i1 %3082, i64 %3081, i64 0
  %private.contiguous.address1087 = getelementptr i8, ptr %3079, i64 %3083
  %private.contiguous.load1088 = load <8 x i64>, ptr %private.contiguous.address1087, align 8
  %3084 = select <8 x i1> %95, <8 x i64> %private.contiguous.load1088, <8 x i64> zeroinitializer
  %3085 = icmp sle <8 x i64> %3069, %3084
  %3086 = and <8 x i1> %3050, %3085
  %tile_snapshot.spill.load1089 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %3087 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1089, 0
  %3088 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1089, 1
  %.state1090 = load i64, ptr %.slot96, align 4
  %.splatinsert1091 = insertelement <8 x i64> poison, i64 %.state1090, i64 0
  %.splat1092 = shufflevector <8 x i64> %.splatinsert1091, <8 x i64> poison, <8 x i32> zeroinitializer
  %3089 = add <8 x i64> %3088, %.splat1092
  %3090 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3087, 0
  %3091 = insertvalue { <8 x ptr>, <8 x i64> } %3090, <8 x i64> %3089, 1
  %3092 = extractvalue { <8 x ptr>, <8 x i64> } %3091, 0
  %3093 = extractvalue { <8 x ptr>, <8 x i64> } %3091, 1
  %3094 = getelementptr i8, <8 x ptr> %3092, <8 x i64> %3093
  %3095 = zext <8 x i1> %3086 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %3095, <8 x ptr> align 1 %3094, <8 x i1> %95)
  %.state1093 = load i64, ptr %.slot96, align 4
  %3096 = add i64 %.state1093, 1
  store i64 %3096, ptr %.slot96, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false1073
  %3097 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %3098 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %3099 = extractvalue { <8 x ptr>, <8 x i64> } %3097, 0
  %3100 = select <8 x i1> %95, <8 x ptr> %3098, <8 x ptr> %3099
  %3101 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %3102 = extractvalue { <8 x ptr>, <8 x i64> } %3097, 1
  %3103 = select <8 x i1> %95, <8 x i64> %3101, <8 x i64> %3102
  %3104 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3100, 0
  %3105 = insertvalue { <8 x ptr>, <8 x i64> } %3104, <8 x i64> %3103, 1
  store { <8 x ptr>, <8 x i64> } %3105, ptr %tile_snapshot.spill97, align 64
  store i64 0, ptr %.slot98, align 4
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state1094 = load i64, ptr %.slot98, align 4
  %3106 = icmp slt i64 %.state1094, 128
  br i1 %3106, label %direct.true1095, label %direct.false1096

direct.schedule.20:                               ; preds = %direct.true1095
  %.state1097 = load i64, ptr %.slot98, align 4
  %3107 = srem i64 %.state1097, 16
  %.state1098 = load i64, ptr %.slot98, align 4
  %3108 = sdiv i64 %.state1098, 16
  %3109 = add i64 0, %3107
  %3110 = mul i64 %3109, 8
  %3111 = add i64 %3110, %3108
  %tile_snapshot.spill.load1099 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %3112 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1099, 0
  %3113 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1099, 1
  %.splatinsert1100 = insertelement <8 x i64> poison, i64 %3111, i64 0
  %.splat1101 = shufflevector <8 x i64> %.splatinsert1100, <8 x i64> poison, <8 x i32> zeroinitializer
  %3114 = add <8 x i64> %3113, %.splat1101
  %3115 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3112, 0
  %3116 = insertvalue { <8 x ptr>, <8 x i64> } %3115, <8 x i64> %3114, 1
  %3117 = extractvalue { <8 x ptr>, <8 x i64> } %3116, 0
  %3118 = extractvalue { <8 x ptr>, <8 x i64> } %3116, 1
  %3119 = getelementptr i8, <8 x ptr> %3117, <8 x i64> %3118
  %3120 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %3119, <8 x i1> %95, <8 x i8> zeroinitializer)
  %3121 = icmp ne <8 x i8> %3120, zeroinitializer
  %3122 = add i64 0, %3108
  %3123 = mul i64 %3122, 16
  %3124 = add i64 %3123, %3107
  %3125 = srem i64 %3124, 16
  %3126 = sdiv i64 %3124, 16
  %3127 = add i64 0, %3126
  %3128 = mul i64 %3127, 16
  %3129 = add i64 %3128, %3125
  %tile_snapshot.spill.load1102 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill88, align 64
  %3130 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1102, 0
  %3131 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1102, 1
  %.splatinsert1103 = insertelement <8 x i64> poison, i64 %3129, i64 0
  %.splat1104 = shufflevector <8 x i64> %.splatinsert1103, <8 x i64> poison, <8 x i32> zeroinitializer
  %3132 = mul <8 x i64> %.splat1104, splat (i64 32)
  %3133 = add <8 x i64> %3131, %3132
  %3134 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3130, 0
  %3135 = insertvalue { <8 x ptr>, <8 x i64> } %3134, <8 x i64> %3133, 1
  %3136 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3137 = extractvalue { <8 x ptr>, <8 x i64> } %3135, 1
  %3138 = extractelement <8 x ptr> %3136, i32 0
  %3139 = extractelement <8 x i64> %3137, i32 0
  %3140 = sub i64 %3139, 0
  %3141 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3142 = select i1 %3141, i64 %3140, i64 0
  %private.contiguous.address1105 = getelementptr i8, ptr %3138, i64 %3142
  %private.contiguous.load1106 = load <8 x float>, ptr %private.contiguous.address1105, align 4
  %3143 = select <8 x i1> %95, <8 x float> %private.contiguous.load1106, <8 x float> zeroinitializer
  %3144 = fmul <8 x float> %3143, splat (float 0x3FC6A09E60000000)
  %3145 = select <8 x i1> %3121, <8 x float> %3144, <8 x float> splat (float 0xC6293E5940000000)
  %tile_snapshot.spill.load1107 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %3146 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1107, 0
  %3147 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1107, 1
  %.state1108 = load i64, ptr %.slot98, align 4
  %.splatinsert1109 = insertelement <8 x i64> poison, i64 %.state1108, i64 0
  %.splat1110 = shufflevector <8 x i64> %.splatinsert1109, <8 x i64> poison, <8 x i32> zeroinitializer
  %3148 = mul <8 x i64> %.splat1110, splat (i64 32)
  %3149 = add <8 x i64> %3147, %3148
  %3150 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3146, 0
  %3151 = insertvalue { <8 x ptr>, <8 x i64> } %3150, <8 x i64> %3149, 1
  %3152 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %3153 = extractvalue { <8 x ptr>, <8 x i64> } %3151, 1
  %3154 = extractelement <8 x ptr> %3152, i32 0
  %3155 = extractelement <8 x i64> %3153, i32 0
  %3156 = sub i64 %3155, 0
  %3157 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3158 = select i1 %3157, i64 %3156, i64 0
  %private.contiguous.address1111 = getelementptr i8, ptr %3154, i64 %3158
  %private.contiguous.preserve1112 = load <8 x float>, ptr %private.contiguous.address1111, align 4
  %3159 = select <8 x i1> %95, <8 x float> %3145, <8 x float> %private.contiguous.preserve1112
  store <8 x float> %3159, ptr %private.contiguous.address1111, align 4
  %.state1113 = load i64, ptr %.slot98, align 4
  %3160 = add i64 %.state1113, 1
  store i64 %3160, ptr %.slot98, align 4
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false1096
  store i64 0, ptr %.slot99, align 4
  %3161 = load <8 x float>, ptr %.slot100, align 32
  %3162 = select <8 x i1> %95, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %3161
  store <8 x float> %3162, ptr %.slot100, align 32
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state1114 = load i64, ptr %.slot99, align 4
  %3163 = icmp slt i64 %.state1114, 16
  br i1 %3163, label %direct.true1115, label %direct.false1116

direct.schedule.23:                               ; preds = %direct.true1115
  %.state1117 = load i64, ptr %.slot99, align 4
  %3164 = sdiv i64 %.state1117, 1
  %.spill.load1118 = load i64, ptr %.spill64, align 4
  %3165 = mul i64 %.spill.load1118, 1
  %3166 = add i64 %3165, 0
  %3167 = mul i64 %3166, 8
  %3168 = add i64 %3167, 0
  %3169 = mul i64 %3168, 16
  %3170 = add i64 %3169, %3164
  %tile_snapshot.spill.load1119 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %3171 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1119, 0
  %3172 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1119, 1
  %.splatinsert1120 = insertelement <8 x i64> poison, i64 %3170, i64 0
  %.splat1121 = shufflevector <8 x i64> %.splatinsert1120, <8 x i64> poison, <8 x i32> zeroinitializer
  %3173 = mul <8 x i64> %.splat1121, splat (i64 32)
  %3174 = add <8 x i64> %3172, %3173
  %3175 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3171, 0
  %3176 = insertvalue { <8 x ptr>, <8 x i64> } %3175, <8 x i64> %3174, 1
  %3177 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %3178 = extractvalue { <8 x ptr>, <8 x i64> } %3176, 1
  %3179 = extractelement <8 x ptr> %3177, i32 0
  %3180 = extractelement <8 x i64> %3178, i32 0
  %3181 = sub i64 %3180, 0
  %3182 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3183 = select i1 %3182, i64 %3181, i64 0
  %private.contiguous.address1122 = getelementptr i8, ptr %3179, i64 %3183
  %private.contiguous.load1123 = load <8 x float>, ptr %private.contiguous.address1122, align 4
  %3184 = select <8 x i1> %95, <8 x float> %private.contiguous.load1123, <8 x float> zeroinitializer
  %.state1124 = load <8 x float>, ptr %.slot100, align 32
  %3185 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1124, <8 x float> %3184)
  %.state1125 = load i64, ptr %.slot99, align 4
  %3186 = add i64 %.state1125, 1
  store i64 %3186, ptr %.slot99, align 4
  %3187 = load <8 x float>, ptr %.slot100, align 32
  %3188 = select <8 x i1> %95, <8 x float> %3185, <8 x float> %3187
  store <8 x float> %3188, ptr %.slot100, align 32
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false1116
  store i64 0, ptr %.slot101, align 4
  %3189 = load <8 x float>, ptr %.slot102, align 32
  %3190 = select <8 x i1> %95, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %3189
  store <8 x float> %3190, ptr %.slot102, align 32
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.26, %direct.schedule.24
  %.state1126 = load i64, ptr %.slot101, align 4
  %3191 = icmp slt i64 %.state1126, 16
  br i1 %3191, label %direct.true1127, label %direct.false1128

direct.schedule.26:                               ; preds = %direct.true1127
  %.state1129 = load i64, ptr %.slot101, align 4
  %3192 = sdiv i64 %.state1129, 1
  %.spill.load1130 = load i64, ptr %.spill64, align 4
  %3193 = mul i64 %.spill.load1130, 1
  %3194 = add i64 %3193, 0
  %3195 = mul i64 %3194, 8
  %3196 = add i64 %3195, 1
  %3197 = mul i64 %3196, 16
  %3198 = add i64 %3197, %3192
  %tile_snapshot.spill.load1131 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %3199 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1131, 0
  %3200 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1131, 1
  %.splatinsert1132 = insertelement <8 x i64> poison, i64 %3198, i64 0
  %.splat1133 = shufflevector <8 x i64> %.splatinsert1132, <8 x i64> poison, <8 x i32> zeroinitializer
  %3201 = mul <8 x i64> %.splat1133, splat (i64 32)
  %3202 = add <8 x i64> %3200, %3201
  %3203 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3199, 0
  %3204 = insertvalue { <8 x ptr>, <8 x i64> } %3203, <8 x i64> %3202, 1
  %3205 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %3206 = extractvalue { <8 x ptr>, <8 x i64> } %3204, 1
  %3207 = extractelement <8 x ptr> %3205, i32 0
  %3208 = extractelement <8 x i64> %3206, i32 0
  %3209 = sub i64 %3208, 0
  %3210 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3211 = select i1 %3210, i64 %3209, i64 0
  %private.contiguous.address1134 = getelementptr i8, ptr %3207, i64 %3211
  %private.contiguous.load1135 = load <8 x float>, ptr %private.contiguous.address1134, align 4
  %3212 = select <8 x i1> %95, <8 x float> %private.contiguous.load1135, <8 x float> zeroinitializer
  %.state1136 = load <8 x float>, ptr %.slot102, align 32
  %3213 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1136, <8 x float> %3212)
  %.state1137 = load i64, ptr %.slot101, align 4
  %3214 = add i64 %.state1137, 1
  store i64 %3214, ptr %.slot101, align 4
  %3215 = load <8 x float>, ptr %.slot102, align 32
  %3216 = select <8 x i1> %95, <8 x float> %3213, <8 x float> %3215
  store <8 x float> %3216, ptr %.slot102, align 32
  br label %direct.schedule.25

direct.schedule.27:                               ; preds = %direct.false1128
  store i64 0, ptr %.slot103, align 4
  %3217 = load <8 x float>, ptr %.slot104, align 32
  %3218 = select <8 x i1> %95, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %3217
  store <8 x float> %3218, ptr %.slot104, align 32
  br label %direct.schedule.28

direct.schedule.28:                               ; preds = %direct.schedule.29, %direct.schedule.27
  %.state1138 = load i64, ptr %.slot103, align 4
  %3219 = icmp slt i64 %.state1138, 16
  br i1 %3219, label %direct.true1139, label %direct.false1140

direct.schedule.29:                               ; preds = %direct.true1139
  %.state1141 = load i64, ptr %.slot103, align 4
  %3220 = sdiv i64 %.state1141, 1
  %.spill.load1142 = load i64, ptr %.spill64, align 4
  %3221 = mul i64 %.spill.load1142, 1
  %3222 = add i64 %3221, 0
  %3223 = mul i64 %3222, 8
  %3224 = add i64 %3223, 2
  %3225 = mul i64 %3224, 16
  %3226 = add i64 %3225, %3220
  %tile_snapshot.spill.load1143 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %3227 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1143, 0
  %3228 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1143, 1
  %.splatinsert1144 = insertelement <8 x i64> poison, i64 %3226, i64 0
  %.splat1145 = shufflevector <8 x i64> %.splatinsert1144, <8 x i64> poison, <8 x i32> zeroinitializer
  %3229 = mul <8 x i64> %.splat1145, splat (i64 32)
  %3230 = add <8 x i64> %3228, %3229
  %3231 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3227, 0
  %3232 = insertvalue { <8 x ptr>, <8 x i64> } %3231, <8 x i64> %3230, 1
  %3233 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %3234 = extractvalue { <8 x ptr>, <8 x i64> } %3232, 1
  %3235 = extractelement <8 x ptr> %3233, i32 0
  %3236 = extractelement <8 x i64> %3234, i32 0
  %3237 = sub i64 %3236, 0
  %3238 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3239 = select i1 %3238, i64 %3237, i64 0
  %private.contiguous.address1146 = getelementptr i8, ptr %3235, i64 %3239
  %private.contiguous.load1147 = load <8 x float>, ptr %private.contiguous.address1146, align 4
  %3240 = select <8 x i1> %95, <8 x float> %private.contiguous.load1147, <8 x float> zeroinitializer
  %.state1148 = load <8 x float>, ptr %.slot104, align 32
  %3241 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1148, <8 x float> %3240)
  %.state1149 = load i64, ptr %.slot103, align 4
  %3242 = add i64 %.state1149, 1
  store i64 %3242, ptr %.slot103, align 4
  %3243 = load <8 x float>, ptr %.slot104, align 32
  %3244 = select <8 x i1> %95, <8 x float> %3241, <8 x float> %3243
  store <8 x float> %3244, ptr %.slot104, align 32
  br label %direct.schedule.28

direct.schedule.30:                               ; preds = %direct.false1140
  store i64 0, ptr %.slot105, align 4
  %3245 = load <8 x float>, ptr %.slot106, align 32
  %3246 = select <8 x i1> %95, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %3245
  store <8 x float> %3246, ptr %.slot106, align 32
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.32, %direct.schedule.30
  %.state1150 = load i64, ptr %.slot105, align 4
  %3247 = icmp slt i64 %.state1150, 16
  br i1 %3247, label %direct.true1151, label %direct.false1152

direct.schedule.32:                               ; preds = %direct.true1151
  %.state1153 = load i64, ptr %.slot105, align 4
  %3248 = sdiv i64 %.state1153, 1
  %.spill.load1154 = load i64, ptr %.spill64, align 4
  %3249 = mul i64 %.spill.load1154, 1
  %3250 = add i64 %3249, 0
  %3251 = mul i64 %3250, 8
  %3252 = add i64 %3251, 3
  %3253 = mul i64 %3252, 16
  %3254 = add i64 %3253, %3248
  %tile_snapshot.spill.load1155 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %3255 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1155, 0
  %3256 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1155, 1
  %.splatinsert1156 = insertelement <8 x i64> poison, i64 %3254, i64 0
  %.splat1157 = shufflevector <8 x i64> %.splatinsert1156, <8 x i64> poison, <8 x i32> zeroinitializer
  %3257 = mul <8 x i64> %.splat1157, splat (i64 32)
  %3258 = add <8 x i64> %3256, %3257
  %3259 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3255, 0
  %3260 = insertvalue { <8 x ptr>, <8 x i64> } %3259, <8 x i64> %3258, 1
  %3261 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %3262 = extractvalue { <8 x ptr>, <8 x i64> } %3260, 1
  %3263 = extractelement <8 x ptr> %3261, i32 0
  %3264 = extractelement <8 x i64> %3262, i32 0
  %3265 = sub i64 %3264, 0
  %3266 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3267 = select i1 %3266, i64 %3265, i64 0
  %private.contiguous.address1158 = getelementptr i8, ptr %3263, i64 %3267
  %private.contiguous.load1159 = load <8 x float>, ptr %private.contiguous.address1158, align 4
  %3268 = select <8 x i1> %95, <8 x float> %private.contiguous.load1159, <8 x float> zeroinitializer
  %.state1160 = load <8 x float>, ptr %.slot106, align 32
  %3269 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1160, <8 x float> %3268)
  %.state1161 = load i64, ptr %.slot105, align 4
  %3270 = add i64 %.state1161, 1
  store i64 %3270, ptr %.slot105, align 4
  %3271 = load <8 x float>, ptr %.slot106, align 32
  %3272 = select <8 x i1> %95, <8 x float> %3269, <8 x float> %3271
  store <8 x float> %3272, ptr %.slot106, align 32
  br label %direct.schedule.31

direct.schedule.33:                               ; preds = %direct.false1152
  store i64 0, ptr %.slot107, align 4
  %3273 = load <8 x float>, ptr %.slot108, align 32
  %3274 = select <8 x i1> %95, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %3273
  store <8 x float> %3274, ptr %.slot108, align 32
  br label %direct.schedule.34

direct.schedule.34:                               ; preds = %direct.schedule.35, %direct.schedule.33
  %.state1162 = load i64, ptr %.slot107, align 4
  %3275 = icmp slt i64 %.state1162, 16
  br i1 %3275, label %direct.true1163, label %direct.false1164

direct.schedule.35:                               ; preds = %direct.true1163
  %.state1165 = load i64, ptr %.slot107, align 4
  %3276 = sdiv i64 %.state1165, 1
  %.spill.load1166 = load i64, ptr %.spill64, align 4
  %3277 = mul i64 %.spill.load1166, 1
  %3278 = add i64 %3277, 0
  %3279 = mul i64 %3278, 8
  %3280 = add i64 %3279, 4
  %3281 = mul i64 %3280, 16
  %3282 = add i64 %3281, %3276
  %tile_snapshot.spill.load1167 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %3283 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1167, 0
  %3284 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1167, 1
  %.splatinsert1168 = insertelement <8 x i64> poison, i64 %3282, i64 0
  %.splat1169 = shufflevector <8 x i64> %.splatinsert1168, <8 x i64> poison, <8 x i32> zeroinitializer
  %3285 = mul <8 x i64> %.splat1169, splat (i64 32)
  %3286 = add <8 x i64> %3284, %3285
  %3287 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3283, 0
  %3288 = insertvalue { <8 x ptr>, <8 x i64> } %3287, <8 x i64> %3286, 1
  %3289 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %3290 = extractvalue { <8 x ptr>, <8 x i64> } %3288, 1
  %3291 = extractelement <8 x ptr> %3289, i32 0
  %3292 = extractelement <8 x i64> %3290, i32 0
  %3293 = sub i64 %3292, 0
  %3294 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3295 = select i1 %3294, i64 %3293, i64 0
  %private.contiguous.address1170 = getelementptr i8, ptr %3291, i64 %3295
  %private.contiguous.load1171 = load <8 x float>, ptr %private.contiguous.address1170, align 4
  %3296 = select <8 x i1> %95, <8 x float> %private.contiguous.load1171, <8 x float> zeroinitializer
  %.state1172 = load <8 x float>, ptr %.slot108, align 32
  %3297 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1172, <8 x float> %3296)
  %.state1173 = load i64, ptr %.slot107, align 4
  %3298 = add i64 %.state1173, 1
  store i64 %3298, ptr %.slot107, align 4
  %3299 = load <8 x float>, ptr %.slot108, align 32
  %3300 = select <8 x i1> %95, <8 x float> %3297, <8 x float> %3299
  store <8 x float> %3300, ptr %.slot108, align 32
  br label %direct.schedule.34

direct.schedule.36:                               ; preds = %direct.false1164
  store i64 0, ptr %.slot109, align 4
  %3301 = load <8 x float>, ptr %.slot110, align 32
  %3302 = select <8 x i1> %95, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %3301
  store <8 x float> %3302, ptr %.slot110, align 32
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.38, %direct.schedule.36
  %.state1174 = load i64, ptr %.slot109, align 4
  %3303 = icmp slt i64 %.state1174, 16
  br i1 %3303, label %direct.true1175, label %direct.false1176

direct.schedule.38:                               ; preds = %direct.true1175
  %.state1177 = load i64, ptr %.slot109, align 4
  %3304 = sdiv i64 %.state1177, 1
  %.spill.load1178 = load i64, ptr %.spill64, align 4
  %3305 = mul i64 %.spill.load1178, 1
  %3306 = add i64 %3305, 0
  %3307 = mul i64 %3306, 8
  %3308 = add i64 %3307, 5
  %3309 = mul i64 %3308, 16
  %3310 = add i64 %3309, %3304
  %tile_snapshot.spill.load1179 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %3311 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1179, 0
  %3312 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1179, 1
  %.splatinsert1180 = insertelement <8 x i64> poison, i64 %3310, i64 0
  %.splat1181 = shufflevector <8 x i64> %.splatinsert1180, <8 x i64> poison, <8 x i32> zeroinitializer
  %3313 = mul <8 x i64> %.splat1181, splat (i64 32)
  %3314 = add <8 x i64> %3312, %3313
  %3315 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3311, 0
  %3316 = insertvalue { <8 x ptr>, <8 x i64> } %3315, <8 x i64> %3314, 1
  %3317 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %3318 = extractvalue { <8 x ptr>, <8 x i64> } %3316, 1
  %3319 = extractelement <8 x ptr> %3317, i32 0
  %3320 = extractelement <8 x i64> %3318, i32 0
  %3321 = sub i64 %3320, 0
  %3322 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3323 = select i1 %3322, i64 %3321, i64 0
  %private.contiguous.address1182 = getelementptr i8, ptr %3319, i64 %3323
  %private.contiguous.load1183 = load <8 x float>, ptr %private.contiguous.address1182, align 4
  %3324 = select <8 x i1> %95, <8 x float> %private.contiguous.load1183, <8 x float> zeroinitializer
  %.state1184 = load <8 x float>, ptr %.slot110, align 32
  %3325 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1184, <8 x float> %3324)
  %.state1185 = load i64, ptr %.slot109, align 4
  %3326 = add i64 %.state1185, 1
  store i64 %3326, ptr %.slot109, align 4
  %3327 = load <8 x float>, ptr %.slot110, align 32
  %3328 = select <8 x i1> %95, <8 x float> %3325, <8 x float> %3327
  store <8 x float> %3328, ptr %.slot110, align 32
  br label %direct.schedule.37

direct.schedule.39:                               ; preds = %direct.false1176
  store i64 0, ptr %.slot111, align 4
  %3329 = load <8 x float>, ptr %.slot112, align 32
  %3330 = select <8 x i1> %95, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %3329
  store <8 x float> %3330, ptr %.slot112, align 32
  br label %direct.schedule.40

direct.schedule.40:                               ; preds = %direct.schedule.41, %direct.schedule.39
  %.state1186 = load i64, ptr %.slot111, align 4
  %3331 = icmp slt i64 %.state1186, 16
  br i1 %3331, label %direct.true1187, label %direct.false1188

direct.schedule.41:                               ; preds = %direct.true1187
  %.state1189 = load i64, ptr %.slot111, align 4
  %3332 = sdiv i64 %.state1189, 1
  %.spill.load1190 = load i64, ptr %.spill64, align 4
  %3333 = mul i64 %.spill.load1190, 1
  %3334 = add i64 %3333, 0
  %3335 = mul i64 %3334, 8
  %3336 = add i64 %3335, 6
  %3337 = mul i64 %3336, 16
  %3338 = add i64 %3337, %3332
  %tile_snapshot.spill.load1191 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %3339 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1191, 0
  %3340 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1191, 1
  %.splatinsert1192 = insertelement <8 x i64> poison, i64 %3338, i64 0
  %.splat1193 = shufflevector <8 x i64> %.splatinsert1192, <8 x i64> poison, <8 x i32> zeroinitializer
  %3341 = mul <8 x i64> %.splat1193, splat (i64 32)
  %3342 = add <8 x i64> %3340, %3341
  %3343 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3339, 0
  %3344 = insertvalue { <8 x ptr>, <8 x i64> } %3343, <8 x i64> %3342, 1
  %3345 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %3346 = extractvalue { <8 x ptr>, <8 x i64> } %3344, 1
  %3347 = extractelement <8 x ptr> %3345, i32 0
  %3348 = extractelement <8 x i64> %3346, i32 0
  %3349 = sub i64 %3348, 0
  %3350 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3351 = select i1 %3350, i64 %3349, i64 0
  %private.contiguous.address1194 = getelementptr i8, ptr %3347, i64 %3351
  %private.contiguous.load1195 = load <8 x float>, ptr %private.contiguous.address1194, align 4
  %3352 = select <8 x i1> %95, <8 x float> %private.contiguous.load1195, <8 x float> zeroinitializer
  %.state1196 = load <8 x float>, ptr %.slot112, align 32
  %3353 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1196, <8 x float> %3352)
  %.state1197 = load i64, ptr %.slot111, align 4
  %3354 = add i64 %.state1197, 1
  store i64 %3354, ptr %.slot111, align 4
  %3355 = load <8 x float>, ptr %.slot112, align 32
  %3356 = select <8 x i1> %95, <8 x float> %3353, <8 x float> %3355
  store <8 x float> %3356, ptr %.slot112, align 32
  br label %direct.schedule.40

direct.schedule.42:                               ; preds = %direct.false1188
  store i64 0, ptr %.slot113, align 4
  %3357 = load <8 x float>, ptr %.slot114, align 32
  %3358 = select <8 x i1> %95, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %3357
  store <8 x float> %3358, ptr %.slot114, align 32
  br label %direct.schedule.43

direct.schedule.43:                               ; preds = %direct.schedule.44, %direct.schedule.42
  %.state1198 = load i64, ptr %.slot113, align 4
  %3359 = icmp slt i64 %.state1198, 16
  br i1 %3359, label %direct.true1199, label %direct.false1200

direct.schedule.44:                               ; preds = %direct.true1199
  %.state1201 = load i64, ptr %.slot113, align 4
  %3360 = sdiv i64 %.state1201, 1
  %.spill.load1202 = load i64, ptr %.spill64, align 4
  %3361 = mul i64 %.spill.load1202, 1
  %3362 = add i64 %3361, 0
  %3363 = mul i64 %3362, 8
  %3364 = add i64 %3363, 7
  %3365 = mul i64 %3364, 16
  %3366 = add i64 %3365, %3360
  %tile_snapshot.spill.load1203 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %3367 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1203, 0
  %3368 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1203, 1
  %.splatinsert1204 = insertelement <8 x i64> poison, i64 %3366, i64 0
  %.splat1205 = shufflevector <8 x i64> %.splatinsert1204, <8 x i64> poison, <8 x i32> zeroinitializer
  %3369 = mul <8 x i64> %.splat1205, splat (i64 32)
  %3370 = add <8 x i64> %3368, %3369
  %3371 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3367, 0
  %3372 = insertvalue { <8 x ptr>, <8 x i64> } %3371, <8 x i64> %3370, 1
  %3373 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %3374 = extractvalue { <8 x ptr>, <8 x i64> } %3372, 1
  %3375 = extractelement <8 x ptr> %3373, i32 0
  %3376 = extractelement <8 x i64> %3374, i32 0
  %3377 = sub i64 %3376, 0
  %3378 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3379 = select i1 %3378, i64 %3377, i64 0
  %private.contiguous.address1206 = getelementptr i8, ptr %3375, i64 %3379
  %private.contiguous.load1207 = load <8 x float>, ptr %private.contiguous.address1206, align 4
  %3380 = select <8 x i1> %95, <8 x float> %private.contiguous.load1207, <8 x float> zeroinitializer
  %.state1208 = load <8 x float>, ptr %.slot114, align 32
  %3381 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1208, <8 x float> %3380)
  %.state1209 = load i64, ptr %.slot113, align 4
  %3382 = add i64 %.state1209, 1
  store i64 %3382, ptr %.slot113, align 4
  %3383 = load <8 x float>, ptr %.slot114, align 32
  %3384 = select <8 x i1> %95, <8 x float> %3381, <8 x float> %3383
  store <8 x float> %3384, ptr %.slot114, align 32
  br label %direct.schedule.43

direct.schedule.45:                               ; preds = %direct.false1200
  %.state1210 = load <8 x float>, ptr %.slot68, align 32
  %.state1211 = load <8 x float>, ptr %.slot100, align 32
  %3385 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1210, <8 x float> %.state1211)
  %3386 = load <8 x float>, ptr %.spill115, align 32
  %3387 = select <8 x i1> %95, <8 x float> %3385, <8 x float> %3386
  store <8 x float> %3387, ptr %.spill115, align 32
  %.state1212 = load <8 x float>, ptr %.slot69, align 32
  %.state1213 = load <8 x float>, ptr %.slot102, align 32
  %3388 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1212, <8 x float> %.state1213)
  %3389 = load <8 x float>, ptr %.spill116, align 32
  %3390 = select <8 x i1> %95, <8 x float> %3388, <8 x float> %3389
  store <8 x float> %3390, ptr %.spill116, align 32
  %.state1214 = load <8 x float>, ptr %.slot70, align 32
  %.state1215 = load <8 x float>, ptr %.slot104, align 32
  %3391 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1214, <8 x float> %.state1215)
  %3392 = load <8 x float>, ptr %.spill117, align 32
  %3393 = select <8 x i1> %95, <8 x float> %3391, <8 x float> %3392
  store <8 x float> %3393, ptr %.spill117, align 32
  %.state1216 = load <8 x float>, ptr %.slot71, align 32
  %.state1217 = load <8 x float>, ptr %.slot106, align 32
  %3394 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1216, <8 x float> %.state1217)
  %3395 = load <8 x float>, ptr %.spill118, align 32
  %3396 = select <8 x i1> %95, <8 x float> %3394, <8 x float> %3395
  store <8 x float> %3396, ptr %.spill118, align 32
  %.state1218 = load <8 x float>, ptr %.slot72, align 32
  %.state1219 = load <8 x float>, ptr %.slot108, align 32
  %3397 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1218, <8 x float> %.state1219)
  %3398 = load <8 x float>, ptr %.spill119, align 32
  %3399 = select <8 x i1> %95, <8 x float> %3397, <8 x float> %3398
  store <8 x float> %3399, ptr %.spill119, align 32
  %.state1220 = load <8 x float>, ptr %.slot73, align 32
  %.state1221 = load <8 x float>, ptr %.slot110, align 32
  %3400 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1220, <8 x float> %.state1221)
  %3401 = load <8 x float>, ptr %.spill120, align 32
  %3402 = select <8 x i1> %95, <8 x float> %3400, <8 x float> %3401
  store <8 x float> %3402, ptr %.spill120, align 32
  %.state1222 = load <8 x float>, ptr %.slot74, align 32
  %.state1223 = load <8 x float>, ptr %.slot112, align 32
  %3403 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1222, <8 x float> %.state1223)
  %3404 = load <8 x float>, ptr %.spill121, align 32
  %3405 = select <8 x i1> %95, <8 x float> %3403, <8 x float> %3404
  store <8 x float> %3405, ptr %.spill121, align 32
  %.state1224 = load <8 x float>, ptr %.slot75, align 32
  %.state1225 = load <8 x float>, ptr %.slot114, align 32
  %3406 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1224, <8 x float> %.state1225)
  %3407 = load <8 x float>, ptr %.spill122, align 32
  %3408 = select <8 x i1> %95, <8 x float> %3406, <8 x float> %3407
  store <8 x float> %3408, ptr %.spill122, align 32
  %3409 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill123, align 64
  %3410 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %3411 = extractvalue { <8 x ptr>, <8 x i64> } %3409, 0
  %3412 = select <8 x i1> %95, <8 x ptr> %3410, <8 x ptr> %3411
  %3413 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %3414 = extractvalue { <8 x ptr>, <8 x i64> } %3409, 1
  %3415 = select <8 x i1> %95, <8 x i64> %3413, <8 x i64> %3414
  %3416 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3412, 0
  %3417 = insertvalue { <8 x ptr>, <8 x i64> } %3416, <8 x i64> %3415, 1
  store { <8 x ptr>, <8 x i64> } %3417, ptr %tile_snapshot.spill123, align 64
  %3418 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %3419 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %3420 = add <8 x i64> %3419, zeroinitializer
  %3421 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3418, 0
  %3422 = insertvalue { <8 x ptr>, <8 x i64> } %3421, <8 x i64> %3420, 1
  %3423 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %3424 = extractvalue { <8 x ptr>, <8 x i64> } %3422, 1
  %3425 = extractelement <8 x ptr> %3423, i32 0
  %3426 = extractelement <8 x i64> %3424, i32 0
  %3427 = sub i64 %3426, 0
  %3428 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3429 = select i1 %3428, i64 %3427, i64 0
  %private.contiguous.address1226 = getelementptr i8, ptr %3425, i64 %3429
  %private.contiguous.preserve1227 = load <8 x float>, ptr %private.contiguous.address1226, align 4
  %3430 = select <8 x i1> %95, <8 x float> %3385, <8 x float> %private.contiguous.preserve1227
  store <8 x float> %3430, ptr %private.contiguous.address1226, align 4
  %3431 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %3432 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %3433 = add <8 x i64> %3432, splat (i64 32)
  %3434 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3431, 0
  %3435 = insertvalue { <8 x ptr>, <8 x i64> } %3434, <8 x i64> %3433, 1
  %3436 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %3437 = extractvalue { <8 x ptr>, <8 x i64> } %3435, 1
  %3438 = extractelement <8 x ptr> %3436, i32 0
  %3439 = extractelement <8 x i64> %3437, i32 0
  %3440 = sub i64 %3439, 0
  %3441 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3442 = select i1 %3441, i64 %3440, i64 0
  %private.contiguous.address1228 = getelementptr i8, ptr %3438, i64 %3442
  %private.contiguous.preserve1229 = load <8 x float>, ptr %private.contiguous.address1228, align 4
  %3443 = select <8 x i1> %95, <8 x float> %3388, <8 x float> %private.contiguous.preserve1229
  store <8 x float> %3443, ptr %private.contiguous.address1228, align 4
  %3444 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %3445 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %3446 = add <8 x i64> %3445, splat (i64 64)
  %3447 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3444, 0
  %3448 = insertvalue { <8 x ptr>, <8 x i64> } %3447, <8 x i64> %3446, 1
  %3449 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %3450 = extractvalue { <8 x ptr>, <8 x i64> } %3448, 1
  %3451 = extractelement <8 x ptr> %3449, i32 0
  %3452 = extractelement <8 x i64> %3450, i32 0
  %3453 = sub i64 %3452, 0
  %3454 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3455 = select i1 %3454, i64 %3453, i64 0
  %private.contiguous.address1230 = getelementptr i8, ptr %3451, i64 %3455
  %private.contiguous.preserve1231 = load <8 x float>, ptr %private.contiguous.address1230, align 4
  %3456 = select <8 x i1> %95, <8 x float> %3391, <8 x float> %private.contiguous.preserve1231
  store <8 x float> %3456, ptr %private.contiguous.address1230, align 4
  %3457 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %3458 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %3459 = add <8 x i64> %3458, splat (i64 96)
  %3460 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3457, 0
  %3461 = insertvalue { <8 x ptr>, <8 x i64> } %3460, <8 x i64> %3459, 1
  %3462 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %3463 = extractvalue { <8 x ptr>, <8 x i64> } %3461, 1
  %3464 = extractelement <8 x ptr> %3462, i32 0
  %3465 = extractelement <8 x i64> %3463, i32 0
  %3466 = sub i64 %3465, 0
  %3467 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3468 = select i1 %3467, i64 %3466, i64 0
  %private.contiguous.address1232 = getelementptr i8, ptr %3464, i64 %3468
  %private.contiguous.preserve1233 = load <8 x float>, ptr %private.contiguous.address1232, align 4
  %3469 = select <8 x i1> %95, <8 x float> %3394, <8 x float> %private.contiguous.preserve1233
  store <8 x float> %3469, ptr %private.contiguous.address1232, align 4
  %3470 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %3471 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %3472 = add <8 x i64> %3471, splat (i64 128)
  %3473 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3470, 0
  %3474 = insertvalue { <8 x ptr>, <8 x i64> } %3473, <8 x i64> %3472, 1
  %3475 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %3476 = extractvalue { <8 x ptr>, <8 x i64> } %3474, 1
  %3477 = extractelement <8 x ptr> %3475, i32 0
  %3478 = extractelement <8 x i64> %3476, i32 0
  %3479 = sub i64 %3478, 0
  %3480 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3481 = select i1 %3480, i64 %3479, i64 0
  %private.contiguous.address1234 = getelementptr i8, ptr %3477, i64 %3481
  %private.contiguous.preserve1235 = load <8 x float>, ptr %private.contiguous.address1234, align 4
  %3482 = select <8 x i1> %95, <8 x float> %3397, <8 x float> %private.contiguous.preserve1235
  store <8 x float> %3482, ptr %private.contiguous.address1234, align 4
  %3483 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %3484 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %3485 = add <8 x i64> %3484, splat (i64 160)
  %3486 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3483, 0
  %3487 = insertvalue { <8 x ptr>, <8 x i64> } %3486, <8 x i64> %3485, 1
  %3488 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %3489 = extractvalue { <8 x ptr>, <8 x i64> } %3487, 1
  %3490 = extractelement <8 x ptr> %3488, i32 0
  %3491 = extractelement <8 x i64> %3489, i32 0
  %3492 = sub i64 %3491, 0
  %3493 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3494 = select i1 %3493, i64 %3492, i64 0
  %private.contiguous.address1236 = getelementptr i8, ptr %3490, i64 %3494
  %private.contiguous.preserve1237 = load <8 x float>, ptr %private.contiguous.address1236, align 4
  %3495 = select <8 x i1> %95, <8 x float> %3400, <8 x float> %private.contiguous.preserve1237
  store <8 x float> %3495, ptr %private.contiguous.address1236, align 4
  %3496 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %3497 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %3498 = add <8 x i64> %3497, splat (i64 192)
  %3499 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3496, 0
  %3500 = insertvalue { <8 x ptr>, <8 x i64> } %3499, <8 x i64> %3498, 1
  %3501 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %3502 = extractvalue { <8 x ptr>, <8 x i64> } %3500, 1
  %3503 = extractelement <8 x ptr> %3501, i32 0
  %3504 = extractelement <8 x i64> %3502, i32 0
  %3505 = sub i64 %3504, 0
  %3506 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3507 = select i1 %3506, i64 %3505, i64 0
  %private.contiguous.address1238 = getelementptr i8, ptr %3503, i64 %3507
  %private.contiguous.preserve1239 = load <8 x float>, ptr %private.contiguous.address1238, align 4
  %3508 = select <8 x i1> %95, <8 x float> %3403, <8 x float> %private.contiguous.preserve1239
  store <8 x float> %3508, ptr %private.contiguous.address1238, align 4
  %3509 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %3510 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %3511 = add <8 x i64> %3510, splat (i64 224)
  %3512 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3509, 0
  %3513 = insertvalue { <8 x ptr>, <8 x i64> } %3512, <8 x i64> %3511, 1
  %3514 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %3515 = extractvalue { <8 x ptr>, <8 x i64> } %3513, 1
  %3516 = extractelement <8 x ptr> %3514, i32 0
  %3517 = extractelement <8 x i64> %3515, i32 0
  %3518 = sub i64 %3517, 0
  %3519 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3520 = select i1 %3519, i64 %3518, i64 0
  %private.contiguous.address1240 = getelementptr i8, ptr %3516, i64 %3520
  %private.contiguous.preserve1241 = load <8 x float>, ptr %private.contiguous.address1240, align 4
  %3521 = select <8 x i1> %95, <8 x float> %3406, <8 x float> %private.contiguous.preserve1241
  store <8 x float> %3521, ptr %private.contiguous.address1240, align 4
  %.state1242 = load <8 x float>, ptr %.slot68, align 32
  %3522 = fsub <8 x float> %.state1242, %3385
  %.state1243 = load <8 x float>, ptr %.slot69, align 32
  %3523 = fsub <8 x float> %.state1243, %3388
  %.state1244 = load <8 x float>, ptr %.slot70, align 32
  %3524 = fsub <8 x float> %.state1244, %3391
  %.state1245 = load <8 x float>, ptr %.slot71, align 32
  %3525 = fsub <8 x float> %.state1245, %3394
  %.state1246 = load <8 x float>, ptr %.slot72, align 32
  %3526 = fsub <8 x float> %.state1246, %3397
  %.state1247 = load <8 x float>, ptr %.slot73, align 32
  %3527 = fsub <8 x float> %.state1247, %3400
  %.state1248 = load <8 x float>, ptr %.slot74, align 32
  %3528 = fsub <8 x float> %.state1248, %3403
  %.state1249 = load <8 x float>, ptr %.slot75, align 32
  %3529 = fsub <8 x float> %.state1249, %3406
  %3530 = select <8 x i1> %95, <8 x float> %3522, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3530)
  %3531 = load <8 x float>, ptr %.spill124, align 32
  %3532 = select <8 x i1> %95, <8 x float> %native.exp, <8 x float> %3531
  store <8 x float> %3532, ptr %.spill124, align 32
  %3533 = select <8 x i1> %95, <8 x float> %3523, <8 x float> zeroinitializer
  %native.exp1250 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3533)
  %3534 = load <8 x float>, ptr %.spill125, align 32
  %3535 = select <8 x i1> %95, <8 x float> %native.exp1250, <8 x float> %3534
  store <8 x float> %3535, ptr %.spill125, align 32
  %3536 = select <8 x i1> %95, <8 x float> %3524, <8 x float> zeroinitializer
  %native.exp1251 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3536)
  %3537 = load <8 x float>, ptr %.spill126, align 32
  %3538 = select <8 x i1> %95, <8 x float> %native.exp1251, <8 x float> %3537
  store <8 x float> %3538, ptr %.spill126, align 32
  %3539 = select <8 x i1> %95, <8 x float> %3525, <8 x float> zeroinitializer
  %native.exp1252 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3539)
  %3540 = load <8 x float>, ptr %.spill127, align 32
  %3541 = select <8 x i1> %95, <8 x float> %native.exp1252, <8 x float> %3540
  store <8 x float> %3541, ptr %.spill127, align 32
  %3542 = select <8 x i1> %95, <8 x float> %3526, <8 x float> zeroinitializer
  %native.exp1253 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3542)
  %3543 = load <8 x float>, ptr %.spill128, align 32
  %3544 = select <8 x i1> %95, <8 x float> %native.exp1253, <8 x float> %3543
  store <8 x float> %3544, ptr %.spill128, align 32
  %3545 = select <8 x i1> %95, <8 x float> %3527, <8 x float> zeroinitializer
  %native.exp1254 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3545)
  %3546 = load <8 x float>, ptr %.spill129, align 32
  %3547 = select <8 x i1> %95, <8 x float> %native.exp1254, <8 x float> %3546
  store <8 x float> %3547, ptr %.spill129, align 32
  %3548 = select <8 x i1> %95, <8 x float> %3528, <8 x float> zeroinitializer
  %native.exp1255 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3548)
  %3549 = load <8 x float>, ptr %.spill130, align 32
  %3550 = select <8 x i1> %95, <8 x float> %native.exp1255, <8 x float> %3549
  store <8 x float> %3550, ptr %.spill130, align 32
  %3551 = select <8 x i1> %95, <8 x float> %3529, <8 x float> zeroinitializer
  %native.exp1256 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3551)
  %3552 = load <8 x float>, ptr %.spill131, align 32
  %3553 = select <8 x i1> %95, <8 x float> %native.exp1256, <8 x float> %3552
  store <8 x float> %3553, ptr %.spill131, align 32
  %3554 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill132, align 64
  %3555 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3556 = extractvalue { <8 x ptr>, <8 x i64> } %3554, 0
  %3557 = select <8 x i1> %95, <8 x ptr> %3555, <8 x ptr> %3556
  %3558 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %3559 = extractvalue { <8 x ptr>, <8 x i64> } %3554, 1
  %3560 = select <8 x i1> %95, <8 x i64> %3558, <8 x i64> %3559
  %3561 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3557, 0
  %3562 = insertvalue { <8 x ptr>, <8 x i64> } %3561, <8 x i64> %3560, 1
  store { <8 x ptr>, <8 x i64> } %3562, ptr %tile_snapshot.spill132, align 64
  %3563 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3564 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %3565 = add <8 x i64> %3564, zeroinitializer
  %3566 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3563, 0
  %3567 = insertvalue { <8 x ptr>, <8 x i64> } %3566, <8 x i64> %3565, 1
  %3568 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3569 = extractvalue { <8 x ptr>, <8 x i64> } %3567, 1
  %3570 = extractelement <8 x ptr> %3568, i32 0
  %3571 = extractelement <8 x i64> %3569, i32 0
  %3572 = sub i64 %3571, 0
  %3573 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3574 = select i1 %3573, i64 %3572, i64 0
  %private.contiguous.address1257 = getelementptr i8, ptr %3570, i64 %3574
  %private.contiguous.preserve1258 = load <8 x float>, ptr %private.contiguous.address1257, align 4
  %3575 = select <8 x i1> %95, <8 x float> %native.exp, <8 x float> %private.contiguous.preserve1258
  store <8 x float> %3575, ptr %private.contiguous.address1257, align 4
  %3576 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3577 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %3578 = add <8 x i64> %3577, splat (i64 32)
  %3579 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3576, 0
  %3580 = insertvalue { <8 x ptr>, <8 x i64> } %3579, <8 x i64> %3578, 1
  %3581 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3582 = extractvalue { <8 x ptr>, <8 x i64> } %3580, 1
  %3583 = extractelement <8 x ptr> %3581, i32 0
  %3584 = extractelement <8 x i64> %3582, i32 0
  %3585 = sub i64 %3584, 0
  %3586 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3587 = select i1 %3586, i64 %3585, i64 0
  %private.contiguous.address1259 = getelementptr i8, ptr %3583, i64 %3587
  %private.contiguous.preserve1260 = load <8 x float>, ptr %private.contiguous.address1259, align 4
  %3588 = select <8 x i1> %95, <8 x float> %native.exp1250, <8 x float> %private.contiguous.preserve1260
  store <8 x float> %3588, ptr %private.contiguous.address1259, align 4
  %3589 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3590 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %3591 = add <8 x i64> %3590, splat (i64 64)
  %3592 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3589, 0
  %3593 = insertvalue { <8 x ptr>, <8 x i64> } %3592, <8 x i64> %3591, 1
  %3594 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3595 = extractvalue { <8 x ptr>, <8 x i64> } %3593, 1
  %3596 = extractelement <8 x ptr> %3594, i32 0
  %3597 = extractelement <8 x i64> %3595, i32 0
  %3598 = sub i64 %3597, 0
  %3599 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3600 = select i1 %3599, i64 %3598, i64 0
  %private.contiguous.address1261 = getelementptr i8, ptr %3596, i64 %3600
  %private.contiguous.preserve1262 = load <8 x float>, ptr %private.contiguous.address1261, align 4
  %3601 = select <8 x i1> %95, <8 x float> %native.exp1251, <8 x float> %private.contiguous.preserve1262
  store <8 x float> %3601, ptr %private.contiguous.address1261, align 4
  %3602 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3603 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %3604 = add <8 x i64> %3603, splat (i64 96)
  %3605 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3602, 0
  %3606 = insertvalue { <8 x ptr>, <8 x i64> } %3605, <8 x i64> %3604, 1
  %3607 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3608 = extractvalue { <8 x ptr>, <8 x i64> } %3606, 1
  %3609 = extractelement <8 x ptr> %3607, i32 0
  %3610 = extractelement <8 x i64> %3608, i32 0
  %3611 = sub i64 %3610, 0
  %3612 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3613 = select i1 %3612, i64 %3611, i64 0
  %private.contiguous.address1263 = getelementptr i8, ptr %3609, i64 %3613
  %private.contiguous.preserve1264 = load <8 x float>, ptr %private.contiguous.address1263, align 4
  %3614 = select <8 x i1> %95, <8 x float> %native.exp1252, <8 x float> %private.contiguous.preserve1264
  store <8 x float> %3614, ptr %private.contiguous.address1263, align 4
  %3615 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3616 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %3617 = add <8 x i64> %3616, splat (i64 128)
  %3618 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3615, 0
  %3619 = insertvalue { <8 x ptr>, <8 x i64> } %3618, <8 x i64> %3617, 1
  %3620 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3621 = extractvalue { <8 x ptr>, <8 x i64> } %3619, 1
  %3622 = extractelement <8 x ptr> %3620, i32 0
  %3623 = extractelement <8 x i64> %3621, i32 0
  %3624 = sub i64 %3623, 0
  %3625 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3626 = select i1 %3625, i64 %3624, i64 0
  %private.contiguous.address1265 = getelementptr i8, ptr %3622, i64 %3626
  %private.contiguous.preserve1266 = load <8 x float>, ptr %private.contiguous.address1265, align 4
  %3627 = select <8 x i1> %95, <8 x float> %native.exp1253, <8 x float> %private.contiguous.preserve1266
  store <8 x float> %3627, ptr %private.contiguous.address1265, align 4
  %3628 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3629 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %3630 = add <8 x i64> %3629, splat (i64 160)
  %3631 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3628, 0
  %3632 = insertvalue { <8 x ptr>, <8 x i64> } %3631, <8 x i64> %3630, 1
  %3633 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3634 = extractvalue { <8 x ptr>, <8 x i64> } %3632, 1
  %3635 = extractelement <8 x ptr> %3633, i32 0
  %3636 = extractelement <8 x i64> %3634, i32 0
  %3637 = sub i64 %3636, 0
  %3638 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3639 = select i1 %3638, i64 %3637, i64 0
  %private.contiguous.address1267 = getelementptr i8, ptr %3635, i64 %3639
  %private.contiguous.preserve1268 = load <8 x float>, ptr %private.contiguous.address1267, align 4
  %3640 = select <8 x i1> %95, <8 x float> %native.exp1254, <8 x float> %private.contiguous.preserve1268
  store <8 x float> %3640, ptr %private.contiguous.address1267, align 4
  %3641 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3642 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %3643 = add <8 x i64> %3642, splat (i64 192)
  %3644 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3641, 0
  %3645 = insertvalue { <8 x ptr>, <8 x i64> } %3644, <8 x i64> %3643, 1
  %3646 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3647 = extractvalue { <8 x ptr>, <8 x i64> } %3645, 1
  %3648 = extractelement <8 x ptr> %3646, i32 0
  %3649 = extractelement <8 x i64> %3647, i32 0
  %3650 = sub i64 %3649, 0
  %3651 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3652 = select i1 %3651, i64 %3650, i64 0
  %private.contiguous.address1269 = getelementptr i8, ptr %3648, i64 %3652
  %private.contiguous.preserve1270 = load <8 x float>, ptr %private.contiguous.address1269, align 4
  %3653 = select <8 x i1> %95, <8 x float> %native.exp1255, <8 x float> %private.contiguous.preserve1270
  store <8 x float> %3653, ptr %private.contiguous.address1269, align 4
  %3654 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3655 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %3656 = add <8 x i64> %3655, splat (i64 224)
  %3657 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3654, 0
  %3658 = insertvalue { <8 x ptr>, <8 x i64> } %3657, <8 x i64> %3656, 1
  %3659 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3660 = extractvalue { <8 x ptr>, <8 x i64> } %3658, 1
  %3661 = extractelement <8 x ptr> %3659, i32 0
  %3662 = extractelement <8 x i64> %3660, i32 0
  %3663 = sub i64 %3662, 0
  %3664 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3665 = select i1 %3664, i64 %3663, i64 0
  %private.contiguous.address1271 = getelementptr i8, ptr %3661, i64 %3665
  %private.contiguous.preserve1272 = load <8 x float>, ptr %private.contiguous.address1271, align 4
  %3666 = select <8 x i1> %95, <8 x float> %native.exp1256, <8 x float> %private.contiguous.preserve1272
  store <8 x float> %3666, ptr %private.contiguous.address1271, align 4
  %3667 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3668 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3669 = extractvalue { <8 x ptr>, <8 x i64> } %3667, 0
  %3670 = select <8 x i1> %95, <8 x ptr> %3668, <8 x ptr> %3669
  %3671 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %3672 = extractvalue { <8 x ptr>, <8 x i64> } %3667, 1
  %3673 = select <8 x i1> %95, <8 x i64> %3671, <8 x i64> %3672
  %3674 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3670, 0
  %3675 = insertvalue { <8 x ptr>, <8 x i64> } %3674, <8 x i64> %3673, 1
  store { <8 x ptr>, <8 x i64> } %3675, ptr %tile_snapshot.spill133, align 64
  store i64 0, ptr %.slot134, align 4
  br label %direct.schedule.46

direct.schedule.46:                               ; preds = %direct.schedule.47, %direct.schedule.45
  %.state1273 = load i64, ptr %.slot134, align 4
  %3676 = icmp slt i64 %.state1273, 128
  br i1 %3676, label %direct.true1274, label %direct.false1275

direct.schedule.47:                               ; preds = %direct.true1274
  %.state1276 = load i64, ptr %.slot134, align 4
  %3677 = srem i64 %.state1276, 16
  %.state1277 = load i64, ptr %.slot134, align 4
  %3678 = sdiv i64 %.state1277, 16
  %3679 = add i64 0, %3677
  %3680 = mul i64 %3679, 8
  %3681 = add i64 %3680, %3678
  %tile_snapshot.spill.load1278 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %3682 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1278, 0
  %3683 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1278, 1
  %.splatinsert1279 = insertelement <8 x i64> poison, i64 %3681, i64 0
  %.splat1280 = shufflevector <8 x i64> %.splatinsert1279, <8 x i64> poison, <8 x i32> zeroinitializer
  %3684 = add <8 x i64> %3683, %.splat1280
  %3685 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3682, 0
  %3686 = insertvalue { <8 x ptr>, <8 x i64> } %3685, <8 x i64> %3684, 1
  %3687 = extractvalue { <8 x ptr>, <8 x i64> } %3686, 0
  %3688 = extractvalue { <8 x ptr>, <8 x i64> } %3686, 1
  %3689 = getelementptr i8, <8 x ptr> %3687, <8 x i64> %3688
  %3690 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %3689, <8 x i1> %95, <8 x i8> zeroinitializer)
  %3691 = icmp ne <8 x i8> %3690, zeroinitializer
  %3692 = add i64 0, %3678
  %3693 = mul i64 %3692, 16
  %3694 = add i64 %3693, %3677
  %3695 = srem i64 %3694, 16
  %3696 = sdiv i64 %3694, 16
  %3697 = add i64 0, %3696
  %3698 = mul i64 %3697, 16
  %3699 = add i64 %3698, %3695
  %3700 = srem i64 %3699, 16
  %3701 = sdiv i64 %3699, 16
  %3702 = add i64 0, %3701
  %3703 = mul i64 %3702, 16
  %3704 = add i64 %3703, %3700
  %tile_snapshot.spill.load1281 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %3705 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1281, 0
  %3706 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1281, 1
  %.splatinsert1282 = insertelement <8 x i64> poison, i64 %3704, i64 0
  %.splat1283 = shufflevector <8 x i64> %.splatinsert1282, <8 x i64> poison, <8 x i32> zeroinitializer
  %3707 = mul <8 x i64> %.splat1283, splat (i64 32)
  %3708 = add <8 x i64> %3706, %3707
  %3709 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3705, 0
  %3710 = insertvalue { <8 x ptr>, <8 x i64> } %3709, <8 x i64> %3708, 1
  %3711 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %3712 = extractvalue { <8 x ptr>, <8 x i64> } %3710, 1
  %3713 = extractelement <8 x ptr> %3711, i32 0
  %3714 = extractelement <8 x i64> %3712, i32 0
  %3715 = sub i64 %3714, 0
  %3716 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3717 = select i1 %3716, i64 %3715, i64 0
  %private.contiguous.address1284 = getelementptr i8, ptr %3713, i64 %3717
  %private.contiguous.load1285 = load <8 x float>, ptr %private.contiguous.address1284, align 4
  %3718 = select <8 x i1> %95, <8 x float> %private.contiguous.load1285, <8 x float> zeroinitializer
  %tile_snapshot.spill.load1286 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill123, align 64
  %3719 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1286, 0
  %3720 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1286, 1
  %.splatinsert1287 = insertelement <8 x i64> poison, i64 %3702, i64 0
  %.splat1288 = shufflevector <8 x i64> %.splatinsert1287, <8 x i64> poison, <8 x i32> zeroinitializer
  %3721 = mul <8 x i64> %.splat1288, splat (i64 32)
  %3722 = add <8 x i64> %3720, %3721
  %3723 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3719, 0
  %3724 = insertvalue { <8 x ptr>, <8 x i64> } %3723, <8 x i64> %3722, 1
  %3725 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %3726 = extractvalue { <8 x ptr>, <8 x i64> } %3724, 1
  %3727 = extractelement <8 x ptr> %3725, i32 0
  %3728 = extractelement <8 x i64> %3726, i32 0
  %3729 = sub i64 %3728, 0
  %3730 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3731 = select i1 %3730, i64 %3729, i64 0
  %private.contiguous.address1289 = getelementptr i8, ptr %3727, i64 %3731
  %private.contiguous.load1290 = load <8 x float>, ptr %private.contiguous.address1289, align 4
  %3732 = select <8 x i1> %95, <8 x float> %private.contiguous.load1290, <8 x float> zeroinitializer
  %3733 = fsub <8 x float> %3718, %3732
  %3734 = select <8 x i1> %95, <8 x float> %3733, <8 x float> zeroinitializer
  %native.exp1291 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3734)
  %3735 = select <8 x i1> %3691, <8 x float> %native.exp1291, <8 x float> zeroinitializer
  %tile_snapshot.spill.load1292 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3736 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1292, 0
  %3737 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1292, 1
  %.state1293 = load i64, ptr %.slot134, align 4
  %.splatinsert1294 = insertelement <8 x i64> poison, i64 %.state1293, i64 0
  %.splat1295 = shufflevector <8 x i64> %.splatinsert1294, <8 x i64> poison, <8 x i32> zeroinitializer
  %3738 = mul <8 x i64> %.splat1295, splat (i64 32)
  %3739 = add <8 x i64> %3737, %3738
  %3740 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3736, 0
  %3741 = insertvalue { <8 x ptr>, <8 x i64> } %3740, <8 x i64> %3739, 1
  %3742 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3743 = extractvalue { <8 x ptr>, <8 x i64> } %3741, 1
  %3744 = extractelement <8 x ptr> %3742, i32 0
  %3745 = extractelement <8 x i64> %3743, i32 0
  %3746 = sub i64 %3745, 0
  %3747 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3748 = select i1 %3747, i64 %3746, i64 0
  %private.contiguous.address1296 = getelementptr i8, ptr %3744, i64 %3748
  %private.contiguous.preserve1297 = load <8 x float>, ptr %private.contiguous.address1296, align 4
  %3749 = select <8 x i1> %95, <8 x float> %3735, <8 x float> %private.contiguous.preserve1297
  store <8 x float> %3749, ptr %private.contiguous.address1296, align 4
  %.state1298 = load i64, ptr %.slot134, align 4
  %3750 = add i64 %.state1298, 1
  store i64 %3750, ptr %.slot134, align 4
  br label %direct.schedule.46

direct.schedule.48:                               ; preds = %direct.false1275
  %.state1299 = load <8 x float>, ptr %.slot76, align 32
  %.spill.load1300 = load <8 x float>, ptr %.spill124, align 32
  %3751 = fmul <8 x float> %.state1299, %.spill.load1300
  %3752 = load <8 x float>, ptr %.spill135, align 32
  %3753 = select <8 x i1> %95, <8 x float> %3751, <8 x float> %3752
  store <8 x float> %3753, ptr %.spill135, align 32
  %.state1301 = load <8 x float>, ptr %.slot77, align 32
  %.spill.load1302 = load <8 x float>, ptr %.spill125, align 32
  %3754 = fmul <8 x float> %.state1301, %.spill.load1302
  %3755 = load <8 x float>, ptr %.spill136, align 32
  %3756 = select <8 x i1> %95, <8 x float> %3754, <8 x float> %3755
  store <8 x float> %3756, ptr %.spill136, align 32
  %.state1303 = load <8 x float>, ptr %.slot78, align 32
  %.spill.load1304 = load <8 x float>, ptr %.spill126, align 32
  %3757 = fmul <8 x float> %.state1303, %.spill.load1304
  %3758 = load <8 x float>, ptr %.spill137, align 32
  %3759 = select <8 x i1> %95, <8 x float> %3757, <8 x float> %3758
  store <8 x float> %3759, ptr %.spill137, align 32
  %.state1305 = load <8 x float>, ptr %.slot79, align 32
  %.spill.load1306 = load <8 x float>, ptr %.spill127, align 32
  %3760 = fmul <8 x float> %.state1305, %.spill.load1306
  %3761 = load <8 x float>, ptr %.spill138, align 32
  %3762 = select <8 x i1> %95, <8 x float> %3760, <8 x float> %3761
  store <8 x float> %3762, ptr %.spill138, align 32
  %.state1307 = load <8 x float>, ptr %.slot80, align 32
  %.spill.load1308 = load <8 x float>, ptr %.spill128, align 32
  %3763 = fmul <8 x float> %.state1307, %.spill.load1308
  %3764 = load <8 x float>, ptr %.spill139, align 32
  %3765 = select <8 x i1> %95, <8 x float> %3763, <8 x float> %3764
  store <8 x float> %3765, ptr %.spill139, align 32
  %.state1309 = load <8 x float>, ptr %.slot81, align 32
  %.spill.load1310 = load <8 x float>, ptr %.spill129, align 32
  %3766 = fmul <8 x float> %.state1309, %.spill.load1310
  %3767 = load <8 x float>, ptr %.spill140, align 32
  %3768 = select <8 x i1> %95, <8 x float> %3766, <8 x float> %3767
  store <8 x float> %3768, ptr %.spill140, align 32
  %.state1311 = load <8 x float>, ptr %.slot82, align 32
  %.spill.load1312 = load <8 x float>, ptr %.spill130, align 32
  %3769 = fmul <8 x float> %.state1311, %.spill.load1312
  %3770 = load <8 x float>, ptr %.spill141, align 32
  %3771 = select <8 x i1> %95, <8 x float> %3769, <8 x float> %3770
  store <8 x float> %3771, ptr %.spill141, align 32
  %.state1313 = load <8 x float>, ptr %.slot83, align 32
  %.spill.load1314 = load <8 x float>, ptr %.spill131, align 32
  %3772 = fmul <8 x float> %.state1313, %.spill.load1314
  %3773 = load <8 x float>, ptr %.spill142, align 32
  %3774 = select <8 x i1> %95, <8 x float> %3772, <8 x float> %3773
  store <8 x float> %3774, ptr %.spill142, align 32
  store i64 0, ptr %.slot143, align 4
  %3775 = load <8 x float>, ptr %.slot144, align 32
  %3776 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %3775
  store <8 x float> %3776, ptr %.slot144, align 32
  br label %direct.schedule.49

direct.schedule.49:                               ; preds = %direct.schedule.50, %direct.schedule.48
  %.state1315 = load i64, ptr %.slot143, align 4
  %3777 = icmp slt i64 %.state1315, 16
  br i1 %3777, label %direct.true1316, label %direct.false1317

direct.schedule.50:                               ; preds = %direct.true1316
  %.state1318 = load i64, ptr %.slot143, align 4
  %3778 = sdiv i64 %.state1318, 1
  %.spill.load1319 = load i64, ptr %.spill64, align 4
  %3779 = mul i64 %.spill.load1319, 1
  %3780 = add i64 %3779, 0
  %3781 = mul i64 %3780, 8
  %3782 = add i64 %3781, 0
  %3783 = mul i64 %3782, 16
  %3784 = add i64 %3783, %3778
  %tile_snapshot.spill.load1320 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3785 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1320, 0
  %3786 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1320, 1
  %.splatinsert1321 = insertelement <8 x i64> poison, i64 %3784, i64 0
  %.splat1322 = shufflevector <8 x i64> %.splatinsert1321, <8 x i64> poison, <8 x i32> zeroinitializer
  %3787 = mul <8 x i64> %.splat1322, splat (i64 32)
  %3788 = add <8 x i64> %3786, %3787
  %3789 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3785, 0
  %3790 = insertvalue { <8 x ptr>, <8 x i64> } %3789, <8 x i64> %3788, 1
  %3791 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3792 = extractvalue { <8 x ptr>, <8 x i64> } %3790, 1
  %3793 = extractelement <8 x ptr> %3791, i32 0
  %3794 = extractelement <8 x i64> %3792, i32 0
  %3795 = sub i64 %3794, 0
  %3796 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3797 = select i1 %3796, i64 %3795, i64 0
  %private.contiguous.address1323 = getelementptr i8, ptr %3793, i64 %3797
  %private.contiguous.load1324 = load <8 x float>, ptr %private.contiguous.address1323, align 4
  %3798 = select <8 x i1> %95, <8 x float> %private.contiguous.load1324, <8 x float> zeroinitializer
  %.state1325 = load <8 x float>, ptr %.slot144, align 32
  %3799 = fadd <8 x float> %.state1325, %3798
  %.state1326 = load i64, ptr %.slot143, align 4
  %3800 = add i64 %.state1326, 1
  store i64 %3800, ptr %.slot143, align 4
  %3801 = load <8 x float>, ptr %.slot144, align 32
  %3802 = select <8 x i1> %95, <8 x float> %3799, <8 x float> %3801
  store <8 x float> %3802, ptr %.slot144, align 32
  br label %direct.schedule.49

direct.schedule.51:                               ; preds = %direct.false1317
  store i64 0, ptr %.slot145, align 4
  %3803 = load <8 x float>, ptr %.slot146, align 32
  %3804 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %3803
  store <8 x float> %3804, ptr %.slot146, align 32
  br label %direct.schedule.52

direct.schedule.52:                               ; preds = %direct.schedule.53, %direct.schedule.51
  %.state1327 = load i64, ptr %.slot145, align 4
  %3805 = icmp slt i64 %.state1327, 16
  br i1 %3805, label %direct.true1328, label %direct.false1329

direct.schedule.53:                               ; preds = %direct.true1328
  %.state1330 = load i64, ptr %.slot145, align 4
  %3806 = sdiv i64 %.state1330, 1
  %.spill.load1331 = load i64, ptr %.spill64, align 4
  %3807 = mul i64 %.spill.load1331, 1
  %3808 = add i64 %3807, 0
  %3809 = mul i64 %3808, 8
  %3810 = add i64 %3809, 1
  %3811 = mul i64 %3810, 16
  %3812 = add i64 %3811, %3806
  %tile_snapshot.spill.load1332 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3813 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1332, 0
  %3814 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1332, 1
  %.splatinsert1333 = insertelement <8 x i64> poison, i64 %3812, i64 0
  %.splat1334 = shufflevector <8 x i64> %.splatinsert1333, <8 x i64> poison, <8 x i32> zeroinitializer
  %3815 = mul <8 x i64> %.splat1334, splat (i64 32)
  %3816 = add <8 x i64> %3814, %3815
  %3817 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3813, 0
  %3818 = insertvalue { <8 x ptr>, <8 x i64> } %3817, <8 x i64> %3816, 1
  %3819 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3820 = extractvalue { <8 x ptr>, <8 x i64> } %3818, 1
  %3821 = extractelement <8 x ptr> %3819, i32 0
  %3822 = extractelement <8 x i64> %3820, i32 0
  %3823 = sub i64 %3822, 0
  %3824 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3825 = select i1 %3824, i64 %3823, i64 0
  %private.contiguous.address1335 = getelementptr i8, ptr %3821, i64 %3825
  %private.contiguous.load1336 = load <8 x float>, ptr %private.contiguous.address1335, align 4
  %3826 = select <8 x i1> %95, <8 x float> %private.contiguous.load1336, <8 x float> zeroinitializer
  %.state1337 = load <8 x float>, ptr %.slot146, align 32
  %3827 = fadd <8 x float> %.state1337, %3826
  %.state1338 = load i64, ptr %.slot145, align 4
  %3828 = add i64 %.state1338, 1
  store i64 %3828, ptr %.slot145, align 4
  %3829 = load <8 x float>, ptr %.slot146, align 32
  %3830 = select <8 x i1> %95, <8 x float> %3827, <8 x float> %3829
  store <8 x float> %3830, ptr %.slot146, align 32
  br label %direct.schedule.52

direct.schedule.54:                               ; preds = %direct.false1329
  store i64 0, ptr %.slot147, align 4
  %3831 = load <8 x float>, ptr %.slot148, align 32
  %3832 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %3831
  store <8 x float> %3832, ptr %.slot148, align 32
  br label %direct.schedule.55

direct.schedule.55:                               ; preds = %direct.schedule.56, %direct.schedule.54
  %.state1339 = load i64, ptr %.slot147, align 4
  %3833 = icmp slt i64 %.state1339, 16
  br i1 %3833, label %direct.true1340, label %direct.false1341

direct.schedule.56:                               ; preds = %direct.true1340
  %.state1342 = load i64, ptr %.slot147, align 4
  %3834 = sdiv i64 %.state1342, 1
  %.spill.load1343 = load i64, ptr %.spill64, align 4
  %3835 = mul i64 %.spill.load1343, 1
  %3836 = add i64 %3835, 0
  %3837 = mul i64 %3836, 8
  %3838 = add i64 %3837, 2
  %3839 = mul i64 %3838, 16
  %3840 = add i64 %3839, %3834
  %tile_snapshot.spill.load1344 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3841 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1344, 0
  %3842 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1344, 1
  %.splatinsert1345 = insertelement <8 x i64> poison, i64 %3840, i64 0
  %.splat1346 = shufflevector <8 x i64> %.splatinsert1345, <8 x i64> poison, <8 x i32> zeroinitializer
  %3843 = mul <8 x i64> %.splat1346, splat (i64 32)
  %3844 = add <8 x i64> %3842, %3843
  %3845 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3841, 0
  %3846 = insertvalue { <8 x ptr>, <8 x i64> } %3845, <8 x i64> %3844, 1
  %3847 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3848 = extractvalue { <8 x ptr>, <8 x i64> } %3846, 1
  %3849 = extractelement <8 x ptr> %3847, i32 0
  %3850 = extractelement <8 x i64> %3848, i32 0
  %3851 = sub i64 %3850, 0
  %3852 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3853 = select i1 %3852, i64 %3851, i64 0
  %private.contiguous.address1347 = getelementptr i8, ptr %3849, i64 %3853
  %private.contiguous.load1348 = load <8 x float>, ptr %private.contiguous.address1347, align 4
  %3854 = select <8 x i1> %95, <8 x float> %private.contiguous.load1348, <8 x float> zeroinitializer
  %.state1349 = load <8 x float>, ptr %.slot148, align 32
  %3855 = fadd <8 x float> %.state1349, %3854
  %.state1350 = load i64, ptr %.slot147, align 4
  %3856 = add i64 %.state1350, 1
  store i64 %3856, ptr %.slot147, align 4
  %3857 = load <8 x float>, ptr %.slot148, align 32
  %3858 = select <8 x i1> %95, <8 x float> %3855, <8 x float> %3857
  store <8 x float> %3858, ptr %.slot148, align 32
  br label %direct.schedule.55

direct.schedule.57:                               ; preds = %direct.false1341
  store i64 0, ptr %.slot149, align 4
  %3859 = load <8 x float>, ptr %.slot150, align 32
  %3860 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %3859
  store <8 x float> %3860, ptr %.slot150, align 32
  br label %direct.schedule.58

direct.schedule.58:                               ; preds = %direct.schedule.59, %direct.schedule.57
  %.state1351 = load i64, ptr %.slot149, align 4
  %3861 = icmp slt i64 %.state1351, 16
  br i1 %3861, label %direct.true1352, label %direct.false1353

direct.schedule.59:                               ; preds = %direct.true1352
  %.state1354 = load i64, ptr %.slot149, align 4
  %3862 = sdiv i64 %.state1354, 1
  %.spill.load1355 = load i64, ptr %.spill64, align 4
  %3863 = mul i64 %.spill.load1355, 1
  %3864 = add i64 %3863, 0
  %3865 = mul i64 %3864, 8
  %3866 = add i64 %3865, 3
  %3867 = mul i64 %3866, 16
  %3868 = add i64 %3867, %3862
  %tile_snapshot.spill.load1356 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3869 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1356, 0
  %3870 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1356, 1
  %.splatinsert1357 = insertelement <8 x i64> poison, i64 %3868, i64 0
  %.splat1358 = shufflevector <8 x i64> %.splatinsert1357, <8 x i64> poison, <8 x i32> zeroinitializer
  %3871 = mul <8 x i64> %.splat1358, splat (i64 32)
  %3872 = add <8 x i64> %3870, %3871
  %3873 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3869, 0
  %3874 = insertvalue { <8 x ptr>, <8 x i64> } %3873, <8 x i64> %3872, 1
  %3875 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3876 = extractvalue { <8 x ptr>, <8 x i64> } %3874, 1
  %3877 = extractelement <8 x ptr> %3875, i32 0
  %3878 = extractelement <8 x i64> %3876, i32 0
  %3879 = sub i64 %3878, 0
  %3880 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3881 = select i1 %3880, i64 %3879, i64 0
  %private.contiguous.address1359 = getelementptr i8, ptr %3877, i64 %3881
  %private.contiguous.load1360 = load <8 x float>, ptr %private.contiguous.address1359, align 4
  %3882 = select <8 x i1> %95, <8 x float> %private.contiguous.load1360, <8 x float> zeroinitializer
  %.state1361 = load <8 x float>, ptr %.slot150, align 32
  %3883 = fadd <8 x float> %.state1361, %3882
  %.state1362 = load i64, ptr %.slot149, align 4
  %3884 = add i64 %.state1362, 1
  store i64 %3884, ptr %.slot149, align 4
  %3885 = load <8 x float>, ptr %.slot150, align 32
  %3886 = select <8 x i1> %95, <8 x float> %3883, <8 x float> %3885
  store <8 x float> %3886, ptr %.slot150, align 32
  br label %direct.schedule.58

direct.schedule.60:                               ; preds = %direct.false1353
  store i64 0, ptr %.slot151, align 4
  %3887 = load <8 x float>, ptr %.slot152, align 32
  %3888 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %3887
  store <8 x float> %3888, ptr %.slot152, align 32
  br label %direct.schedule.61

direct.schedule.61:                               ; preds = %direct.schedule.62, %direct.schedule.60
  %.state1363 = load i64, ptr %.slot151, align 4
  %3889 = icmp slt i64 %.state1363, 16
  br i1 %3889, label %direct.true1364, label %direct.false1365

direct.schedule.62:                               ; preds = %direct.true1364
  %.state1366 = load i64, ptr %.slot151, align 4
  %3890 = sdiv i64 %.state1366, 1
  %.spill.load1367 = load i64, ptr %.spill64, align 4
  %3891 = mul i64 %.spill.load1367, 1
  %3892 = add i64 %3891, 0
  %3893 = mul i64 %3892, 8
  %3894 = add i64 %3893, 4
  %3895 = mul i64 %3894, 16
  %3896 = add i64 %3895, %3890
  %tile_snapshot.spill.load1368 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3897 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1368, 0
  %3898 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1368, 1
  %.splatinsert1369 = insertelement <8 x i64> poison, i64 %3896, i64 0
  %.splat1370 = shufflevector <8 x i64> %.splatinsert1369, <8 x i64> poison, <8 x i32> zeroinitializer
  %3899 = mul <8 x i64> %.splat1370, splat (i64 32)
  %3900 = add <8 x i64> %3898, %3899
  %3901 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3897, 0
  %3902 = insertvalue { <8 x ptr>, <8 x i64> } %3901, <8 x i64> %3900, 1
  %3903 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3904 = extractvalue { <8 x ptr>, <8 x i64> } %3902, 1
  %3905 = extractelement <8 x ptr> %3903, i32 0
  %3906 = extractelement <8 x i64> %3904, i32 0
  %3907 = sub i64 %3906, 0
  %3908 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3909 = select i1 %3908, i64 %3907, i64 0
  %private.contiguous.address1371 = getelementptr i8, ptr %3905, i64 %3909
  %private.contiguous.load1372 = load <8 x float>, ptr %private.contiguous.address1371, align 4
  %3910 = select <8 x i1> %95, <8 x float> %private.contiguous.load1372, <8 x float> zeroinitializer
  %.state1373 = load <8 x float>, ptr %.slot152, align 32
  %3911 = fadd <8 x float> %.state1373, %3910
  %.state1374 = load i64, ptr %.slot151, align 4
  %3912 = add i64 %.state1374, 1
  store i64 %3912, ptr %.slot151, align 4
  %3913 = load <8 x float>, ptr %.slot152, align 32
  %3914 = select <8 x i1> %95, <8 x float> %3911, <8 x float> %3913
  store <8 x float> %3914, ptr %.slot152, align 32
  br label %direct.schedule.61

direct.schedule.63:                               ; preds = %direct.false1365
  store i64 0, ptr %.slot153, align 4
  %3915 = load <8 x float>, ptr %.slot154, align 32
  %3916 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %3915
  store <8 x float> %3916, ptr %.slot154, align 32
  br label %direct.schedule.64

direct.schedule.64:                               ; preds = %direct.schedule.65, %direct.schedule.63
  %.state1375 = load i64, ptr %.slot153, align 4
  %3917 = icmp slt i64 %.state1375, 16
  br i1 %3917, label %direct.true1376, label %direct.false1377

direct.schedule.65:                               ; preds = %direct.true1376
  %.state1378 = load i64, ptr %.slot153, align 4
  %3918 = sdiv i64 %.state1378, 1
  %.spill.load1379 = load i64, ptr %.spill64, align 4
  %3919 = mul i64 %.spill.load1379, 1
  %3920 = add i64 %3919, 0
  %3921 = mul i64 %3920, 8
  %3922 = add i64 %3921, 5
  %3923 = mul i64 %3922, 16
  %3924 = add i64 %3923, %3918
  %tile_snapshot.spill.load1380 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3925 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1380, 0
  %3926 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1380, 1
  %.splatinsert1381 = insertelement <8 x i64> poison, i64 %3924, i64 0
  %.splat1382 = shufflevector <8 x i64> %.splatinsert1381, <8 x i64> poison, <8 x i32> zeroinitializer
  %3927 = mul <8 x i64> %.splat1382, splat (i64 32)
  %3928 = add <8 x i64> %3926, %3927
  %3929 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3925, 0
  %3930 = insertvalue { <8 x ptr>, <8 x i64> } %3929, <8 x i64> %3928, 1
  %3931 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3932 = extractvalue { <8 x ptr>, <8 x i64> } %3930, 1
  %3933 = extractelement <8 x ptr> %3931, i32 0
  %3934 = extractelement <8 x i64> %3932, i32 0
  %3935 = sub i64 %3934, 0
  %3936 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3937 = select i1 %3936, i64 %3935, i64 0
  %private.contiguous.address1383 = getelementptr i8, ptr %3933, i64 %3937
  %private.contiguous.load1384 = load <8 x float>, ptr %private.contiguous.address1383, align 4
  %3938 = select <8 x i1> %95, <8 x float> %private.contiguous.load1384, <8 x float> zeroinitializer
  %.state1385 = load <8 x float>, ptr %.slot154, align 32
  %3939 = fadd <8 x float> %.state1385, %3938
  %.state1386 = load i64, ptr %.slot153, align 4
  %3940 = add i64 %.state1386, 1
  store i64 %3940, ptr %.slot153, align 4
  %3941 = load <8 x float>, ptr %.slot154, align 32
  %3942 = select <8 x i1> %95, <8 x float> %3939, <8 x float> %3941
  store <8 x float> %3942, ptr %.slot154, align 32
  br label %direct.schedule.64

direct.schedule.66:                               ; preds = %direct.false1377
  store i64 0, ptr %.slot155, align 4
  %3943 = load <8 x float>, ptr %.slot156, align 32
  %3944 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %3943
  store <8 x float> %3944, ptr %.slot156, align 32
  br label %direct.schedule.67

direct.schedule.67:                               ; preds = %direct.schedule.68, %direct.schedule.66
  %.state1387 = load i64, ptr %.slot155, align 4
  %3945 = icmp slt i64 %.state1387, 16
  br i1 %3945, label %direct.true1388, label %direct.false1389

direct.schedule.68:                               ; preds = %direct.true1388
  %.state1390 = load i64, ptr %.slot155, align 4
  %3946 = sdiv i64 %.state1390, 1
  %.spill.load1391 = load i64, ptr %.spill64, align 4
  %3947 = mul i64 %.spill.load1391, 1
  %3948 = add i64 %3947, 0
  %3949 = mul i64 %3948, 8
  %3950 = add i64 %3949, 6
  %3951 = mul i64 %3950, 16
  %3952 = add i64 %3951, %3946
  %tile_snapshot.spill.load1392 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3953 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1392, 0
  %3954 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1392, 1
  %.splatinsert1393 = insertelement <8 x i64> poison, i64 %3952, i64 0
  %.splat1394 = shufflevector <8 x i64> %.splatinsert1393, <8 x i64> poison, <8 x i32> zeroinitializer
  %3955 = mul <8 x i64> %.splat1394, splat (i64 32)
  %3956 = add <8 x i64> %3954, %3955
  %3957 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3953, 0
  %3958 = insertvalue { <8 x ptr>, <8 x i64> } %3957, <8 x i64> %3956, 1
  %3959 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3960 = extractvalue { <8 x ptr>, <8 x i64> } %3958, 1
  %3961 = extractelement <8 x ptr> %3959, i32 0
  %3962 = extractelement <8 x i64> %3960, i32 0
  %3963 = sub i64 %3962, 0
  %3964 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3965 = select i1 %3964, i64 %3963, i64 0
  %private.contiguous.address1395 = getelementptr i8, ptr %3961, i64 %3965
  %private.contiguous.load1396 = load <8 x float>, ptr %private.contiguous.address1395, align 4
  %3966 = select <8 x i1> %95, <8 x float> %private.contiguous.load1396, <8 x float> zeroinitializer
  %.state1397 = load <8 x float>, ptr %.slot156, align 32
  %3967 = fadd <8 x float> %.state1397, %3966
  %.state1398 = load i64, ptr %.slot155, align 4
  %3968 = add i64 %.state1398, 1
  store i64 %3968, ptr %.slot155, align 4
  %3969 = load <8 x float>, ptr %.slot156, align 32
  %3970 = select <8 x i1> %95, <8 x float> %3967, <8 x float> %3969
  store <8 x float> %3970, ptr %.slot156, align 32
  br label %direct.schedule.67

direct.schedule.69:                               ; preds = %direct.false1389
  store i64 0, ptr %.slot157, align 4
  %3971 = load <8 x float>, ptr %.slot158, align 32
  %3972 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %3971
  store <8 x float> %3972, ptr %.slot158, align 32
  br label %direct.schedule.70

direct.schedule.70:                               ; preds = %direct.schedule.71, %direct.schedule.69
  %.state1399 = load i64, ptr %.slot157, align 4
  %3973 = icmp slt i64 %.state1399, 16
  br i1 %3973, label %direct.true1400, label %direct.false1401

direct.schedule.71:                               ; preds = %direct.true1400
  %.state1402 = load i64, ptr %.slot157, align 4
  %3974 = sdiv i64 %.state1402, 1
  %.spill.load1403 = load i64, ptr %.spill64, align 4
  %3975 = mul i64 %.spill.load1403, 1
  %3976 = add i64 %3975, 0
  %3977 = mul i64 %3976, 8
  %3978 = add i64 %3977, 7
  %3979 = mul i64 %3978, 16
  %3980 = add i64 %3979, %3974
  %tile_snapshot.spill.load1404 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3981 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1404, 0
  %3982 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1404, 1
  %.splatinsert1405 = insertelement <8 x i64> poison, i64 %3980, i64 0
  %.splat1406 = shufflevector <8 x i64> %.splatinsert1405, <8 x i64> poison, <8 x i32> zeroinitializer
  %3983 = mul <8 x i64> %.splat1406, splat (i64 32)
  %3984 = add <8 x i64> %3982, %3983
  %3985 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3981, 0
  %3986 = insertvalue { <8 x ptr>, <8 x i64> } %3985, <8 x i64> %3984, 1
  %3987 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3988 = extractvalue { <8 x ptr>, <8 x i64> } %3986, 1
  %3989 = extractelement <8 x ptr> %3987, i32 0
  %3990 = extractelement <8 x i64> %3988, i32 0
  %3991 = sub i64 %3990, 0
  %3992 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3993 = select i1 %3992, i64 %3991, i64 0
  %private.contiguous.address1407 = getelementptr i8, ptr %3989, i64 %3993
  %private.contiguous.load1408 = load <8 x float>, ptr %private.contiguous.address1407, align 4
  %3994 = select <8 x i1> %95, <8 x float> %private.contiguous.load1408, <8 x float> zeroinitializer
  %.state1409 = load <8 x float>, ptr %.slot158, align 32
  %3995 = fadd <8 x float> %.state1409, %3994
  %.state1410 = load i64, ptr %.slot157, align 4
  %3996 = add i64 %.state1410, 1
  store i64 %3996, ptr %.slot157, align 4
  %3997 = load <8 x float>, ptr %.slot158, align 32
  %3998 = select <8 x i1> %95, <8 x float> %3995, <8 x float> %3997
  store <8 x float> %3998, ptr %.slot158, align 32
  br label %direct.schedule.70

direct.schedule.72:                               ; preds = %direct.false1401
  %.spill.load1411 = load <8 x float>, ptr %.spill135, align 32
  %.state1412 = load <8 x float>, ptr %.slot144, align 32
  %3999 = fadd <8 x float> %.spill.load1411, %.state1412
  %4000 = load <8 x float>, ptr %.spill159, align 32
  %4001 = select <8 x i1> %95, <8 x float> %3999, <8 x float> %4000
  store <8 x float> %4001, ptr %.spill159, align 32
  %.spill.load1413 = load <8 x float>, ptr %.spill136, align 32
  %.state1414 = load <8 x float>, ptr %.slot146, align 32
  %4002 = fadd <8 x float> %.spill.load1413, %.state1414
  %4003 = load <8 x float>, ptr %.spill160, align 32
  %4004 = select <8 x i1> %95, <8 x float> %4002, <8 x float> %4003
  store <8 x float> %4004, ptr %.spill160, align 32
  %.spill.load1415 = load <8 x float>, ptr %.spill137, align 32
  %.state1416 = load <8 x float>, ptr %.slot148, align 32
  %4005 = fadd <8 x float> %.spill.load1415, %.state1416
  %4006 = load <8 x float>, ptr %.spill161, align 32
  %4007 = select <8 x i1> %95, <8 x float> %4005, <8 x float> %4006
  store <8 x float> %4007, ptr %.spill161, align 32
  %.spill.load1417 = load <8 x float>, ptr %.spill138, align 32
  %.state1418 = load <8 x float>, ptr %.slot150, align 32
  %4008 = fadd <8 x float> %.spill.load1417, %.state1418
  %4009 = load <8 x float>, ptr %.spill162, align 32
  %4010 = select <8 x i1> %95, <8 x float> %4008, <8 x float> %4009
  store <8 x float> %4010, ptr %.spill162, align 32
  %.spill.load1419 = load <8 x float>, ptr %.spill139, align 32
  %.state1420 = load <8 x float>, ptr %.slot152, align 32
  %4011 = fadd <8 x float> %.spill.load1419, %.state1420
  %4012 = load <8 x float>, ptr %.spill163, align 32
  %4013 = select <8 x i1> %95, <8 x float> %4011, <8 x float> %4012
  store <8 x float> %4013, ptr %.spill163, align 32
  %.spill.load1421 = load <8 x float>, ptr %.spill140, align 32
  %.state1422 = load <8 x float>, ptr %.slot154, align 32
  %4014 = fadd <8 x float> %.spill.load1421, %.state1422
  %4015 = load <8 x float>, ptr %.spill164, align 32
  %4016 = select <8 x i1> %95, <8 x float> %4014, <8 x float> %4015
  store <8 x float> %4016, ptr %.spill164, align 32
  %.spill.load1423 = load <8 x float>, ptr %.spill141, align 32
  %.state1424 = load <8 x float>, ptr %.slot156, align 32
  %4017 = fadd <8 x float> %.spill.load1423, %.state1424
  %4018 = load <8 x float>, ptr %.spill165, align 32
  %4019 = select <8 x i1> %95, <8 x float> %4017, <8 x float> %4018
  store <8 x float> %4019, ptr %.spill165, align 32
  %.spill.load1425 = load <8 x float>, ptr %.spill142, align 32
  %.state1426 = load <8 x float>, ptr %.slot158, align 32
  %4020 = fadd <8 x float> %.spill.load1425, %.state1426
  %4021 = load <8 x float>, ptr %.spill166, align 32
  %4022 = select <8 x i1> %95, <8 x float> %4020, <8 x float> %4021
  store <8 x float> %4022, ptr %.spill166, align 32
  %4023 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill167, align 64
  %4024 = extractvalue { <8 x ptr>, <8 x i64> } %44, 0
  %4025 = extractvalue { <8 x ptr>, <8 x i64> } %4023, 0
  %4026 = select <8 x i1> %95, <8 x ptr> %4024, <8 x ptr> %4025
  %4027 = extractvalue { <8 x ptr>, <8 x i64> } %44, 1
  %4028 = extractvalue { <8 x ptr>, <8 x i64> } %4023, 1
  %4029 = select <8 x i1> %95, <8 x i64> %4027, <8 x i64> %4028
  %4030 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4026, 0
  %4031 = insertvalue { <8 x ptr>, <8 x i64> } %4030, <8 x i64> %4029, 1
  store { <8 x ptr>, <8 x i64> } %4031, ptr %tile_snapshot.spill167, align 64
  store i64 0, ptr %.slot168, align 4
  br label %direct.schedule.73

direct.schedule.73:                               ; preds = %direct.schedule.77, %direct.schedule.72
  %.state1427 = load i64, ptr %.slot168, align 4
  %4032 = icmp slt i64 %.state1427, 4
  br i1 %4032, label %direct.true1428, label %direct.false1429

direct.schedule.74:                               ; preds = %direct.true1428
  %.state1430 = load i64, ptr %.slot168, align 4
  %4033 = mul i64 %.state1430, 2
  store i64 %4033, ptr %.spill169, align 4
  store i64 0, ptr %.slot170, align 4
  br label %direct.schedule.75

direct.schedule.75:                               ; preds = %direct.schedule.76, %direct.schedule.74
  %.state1431 = load i64, ptr %.slot170, align 4
  %4034 = icmp slt i64 %.state1431, 24
  br i1 %4034, label %direct.true1432, label %direct.false1433

direct.schedule.76:                               ; preds = %direct.true1432
  %.state1434 = load i64, ptr %.slot170, align 4
  %4035 = mul i64 %.state1434, 2
  %.spill.load1435 = load i64, ptr %.spill169, align 4
  %4036 = add i64 0, %.spill.load1435
  %4037 = mul i64 %4036, 48
  %4038 = add i64 %4037, %4035
  %4039 = add i64 %4038, 0
  %4040 = srem i64 %4039, 48
  %4041 = sdiv i64 %4039, 48
  %4042 = add i64 0, %4041
  %4043 = mul i64 %4042, 48
  %4044 = add i64 %4043, %4040
  %tile_snapshot.spill.load1436 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %4045 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1436, 0
  %4046 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1436, 1
  %.splatinsert1437 = insertelement <8 x i64> poison, i64 %4044, i64 0
  %.splat1438 = shufflevector <8 x i64> %.splatinsert1437, <8 x i64> poison, <8 x i32> zeroinitializer
  %4047 = mul <8 x i64> %.splat1438, splat (i64 32)
  %4048 = add <8 x i64> %4046, %4047
  %4049 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4045, 0
  %4050 = insertvalue { <8 x ptr>, <8 x i64> } %4049, <8 x i64> %4048, 1
  %4051 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %4052 = extractvalue { <8 x ptr>, <8 x i64> } %4050, 1
  %4053 = extractelement <8 x ptr> %4051, i32 0
  %4054 = extractelement <8 x i64> %4052, i32 0
  %4055 = sub i64 %4054, 0
  %4056 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4057 = select i1 %4056, i64 %4055, i64 0
  %private.contiguous.address1439 = getelementptr i8, ptr %4053, i64 %4057
  %private.contiguous.load1440 = load <8 x float>, ptr %private.contiguous.address1439, align 4
  %4058 = select <8 x i1> %95, <8 x float> %private.contiguous.load1440, <8 x float> zeroinitializer
  %tile_snapshot.spill.load1441 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill132, align 64
  %4059 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1441, 0
  %4060 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1441, 1
  %.splatinsert1442 = insertelement <8 x i64> poison, i64 %4042, i64 0
  %.splat1443 = shufflevector <8 x i64> %.splatinsert1442, <8 x i64> poison, <8 x i32> zeroinitializer
  %4061 = mul <8 x i64> %.splat1443, splat (i64 32)
  %4062 = add <8 x i64> %4060, %4061
  %4063 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4059, 0
  %4064 = insertvalue { <8 x ptr>, <8 x i64> } %4063, <8 x i64> %4062, 1
  %4065 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %4066 = extractvalue { <8 x ptr>, <8 x i64> } %4064, 1
  %4067 = extractelement <8 x ptr> %4065, i32 0
  %4068 = extractelement <8 x i64> %4066, i32 0
  %4069 = sub i64 %4068, 0
  %4070 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4071 = select i1 %4070, i64 %4069, i64 0
  %private.contiguous.address1444 = getelementptr i8, ptr %4067, i64 %4071
  %private.contiguous.load1445 = load <8 x float>, ptr %private.contiguous.address1444, align 4
  %4072 = select <8 x i1> %95, <8 x float> %private.contiguous.load1445, <8 x float> zeroinitializer
  %4073 = fmul <8 x float> %4058, %4072
  %4074 = add i64 %4038, 1
  %4075 = srem i64 %4074, 48
  %4076 = sdiv i64 %4074, 48
  %4077 = add i64 0, %4076
  %4078 = mul i64 %4077, 48
  %4079 = add i64 %4078, %4075
  %tile_snapshot.spill.load1446 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %4080 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1446, 0
  %4081 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1446, 1
  %.splatinsert1447 = insertelement <8 x i64> poison, i64 %4079, i64 0
  %.splat1448 = shufflevector <8 x i64> %.splatinsert1447, <8 x i64> poison, <8 x i32> zeroinitializer
  %4082 = mul <8 x i64> %.splat1448, splat (i64 32)
  %4083 = add <8 x i64> %4081, %4082
  %4084 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4080, 0
  %4085 = insertvalue { <8 x ptr>, <8 x i64> } %4084, <8 x i64> %4083, 1
  %4086 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %4087 = extractvalue { <8 x ptr>, <8 x i64> } %4085, 1
  %4088 = extractelement <8 x ptr> %4086, i32 0
  %4089 = extractelement <8 x i64> %4087, i32 0
  %4090 = sub i64 %4089, 0
  %4091 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4092 = select i1 %4091, i64 %4090, i64 0
  %private.contiguous.address1449 = getelementptr i8, ptr %4088, i64 %4092
  %private.contiguous.load1450 = load <8 x float>, ptr %private.contiguous.address1449, align 4
  %4093 = select <8 x i1> %95, <8 x float> %private.contiguous.load1450, <8 x float> zeroinitializer
  %tile_snapshot.spill.load1451 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill132, align 64
  %4094 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1451, 0
  %4095 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1451, 1
  %.splatinsert1452 = insertelement <8 x i64> poison, i64 %4077, i64 0
  %.splat1453 = shufflevector <8 x i64> %.splatinsert1452, <8 x i64> poison, <8 x i32> zeroinitializer
  %4096 = mul <8 x i64> %.splat1453, splat (i64 32)
  %4097 = add <8 x i64> %4095, %4096
  %4098 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4094, 0
  %4099 = insertvalue { <8 x ptr>, <8 x i64> } %4098, <8 x i64> %4097, 1
  %4100 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %4101 = extractvalue { <8 x ptr>, <8 x i64> } %4099, 1
  %4102 = extractelement <8 x ptr> %4100, i32 0
  %4103 = extractelement <8 x i64> %4101, i32 0
  %4104 = sub i64 %4103, 0
  %4105 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4106 = select i1 %4105, i64 %4104, i64 0
  %private.contiguous.address1454 = getelementptr i8, ptr %4102, i64 %4106
  %private.contiguous.load1455 = load <8 x float>, ptr %private.contiguous.address1454, align 4
  %4107 = select <8 x i1> %95, <8 x float> %private.contiguous.load1455, <8 x float> zeroinitializer
  %4108 = fmul <8 x float> %4093, %4107
  %4109 = add i64 %4038, 48
  %4110 = srem i64 %4109, 48
  %4111 = sdiv i64 %4109, 48
  %4112 = add i64 0, %4111
  %4113 = mul i64 %4112, 48
  %4114 = add i64 %4113, %4110
  %tile_snapshot.spill.load1456 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %4115 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1456, 0
  %4116 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1456, 1
  %.splatinsert1457 = insertelement <8 x i64> poison, i64 %4114, i64 0
  %.splat1458 = shufflevector <8 x i64> %.splatinsert1457, <8 x i64> poison, <8 x i32> zeroinitializer
  %4117 = mul <8 x i64> %.splat1458, splat (i64 32)
  %4118 = add <8 x i64> %4116, %4117
  %4119 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4115, 0
  %4120 = insertvalue { <8 x ptr>, <8 x i64> } %4119, <8 x i64> %4118, 1
  %4121 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %4122 = extractvalue { <8 x ptr>, <8 x i64> } %4120, 1
  %4123 = extractelement <8 x ptr> %4121, i32 0
  %4124 = extractelement <8 x i64> %4122, i32 0
  %4125 = sub i64 %4124, 0
  %4126 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4127 = select i1 %4126, i64 %4125, i64 0
  %private.contiguous.address1459 = getelementptr i8, ptr %4123, i64 %4127
  %private.contiguous.load1460 = load <8 x float>, ptr %private.contiguous.address1459, align 4
  %4128 = select <8 x i1> %95, <8 x float> %private.contiguous.load1460, <8 x float> zeroinitializer
  %tile_snapshot.spill.load1461 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill132, align 64
  %4129 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1461, 0
  %4130 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1461, 1
  %.splatinsert1462 = insertelement <8 x i64> poison, i64 %4112, i64 0
  %.splat1463 = shufflevector <8 x i64> %.splatinsert1462, <8 x i64> poison, <8 x i32> zeroinitializer
  %4131 = mul <8 x i64> %.splat1463, splat (i64 32)
  %4132 = add <8 x i64> %4130, %4131
  %4133 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4129, 0
  %4134 = insertvalue { <8 x ptr>, <8 x i64> } %4133, <8 x i64> %4132, 1
  %4135 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %4136 = extractvalue { <8 x ptr>, <8 x i64> } %4134, 1
  %4137 = extractelement <8 x ptr> %4135, i32 0
  %4138 = extractelement <8 x i64> %4136, i32 0
  %4139 = sub i64 %4138, 0
  %4140 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4141 = select i1 %4140, i64 %4139, i64 0
  %private.contiguous.address1464 = getelementptr i8, ptr %4137, i64 %4141
  %private.contiguous.load1465 = load <8 x float>, ptr %private.contiguous.address1464, align 4
  %4142 = select <8 x i1> %95, <8 x float> %private.contiguous.load1465, <8 x float> zeroinitializer
  %4143 = fmul <8 x float> %4128, %4142
  %4144 = add i64 %4038, 49
  %4145 = srem i64 %4144, 48
  %4146 = sdiv i64 %4144, 48
  %4147 = add i64 0, %4146
  %4148 = mul i64 %4147, 48
  %4149 = add i64 %4148, %4145
  %tile_snapshot.spill.load1466 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %4150 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1466, 0
  %4151 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1466, 1
  %.splatinsert1467 = insertelement <8 x i64> poison, i64 %4149, i64 0
  %.splat1468 = shufflevector <8 x i64> %.splatinsert1467, <8 x i64> poison, <8 x i32> zeroinitializer
  %4152 = mul <8 x i64> %.splat1468, splat (i64 32)
  %4153 = add <8 x i64> %4151, %4152
  %4154 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4150, 0
  %4155 = insertvalue { <8 x ptr>, <8 x i64> } %4154, <8 x i64> %4153, 1
  %4156 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %4157 = extractvalue { <8 x ptr>, <8 x i64> } %4155, 1
  %4158 = extractelement <8 x ptr> %4156, i32 0
  %4159 = extractelement <8 x i64> %4157, i32 0
  %4160 = sub i64 %4159, 0
  %4161 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4162 = select i1 %4161, i64 %4160, i64 0
  %private.contiguous.address1469 = getelementptr i8, ptr %4158, i64 %4162
  %private.contiguous.load1470 = load <8 x float>, ptr %private.contiguous.address1469, align 4
  %4163 = select <8 x i1> %95, <8 x float> %private.contiguous.load1470, <8 x float> zeroinitializer
  %tile_snapshot.spill.load1471 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill132, align 64
  %4164 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1471, 0
  %4165 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1471, 1
  %.splatinsert1472 = insertelement <8 x i64> poison, i64 %4147, i64 0
  %.splat1473 = shufflevector <8 x i64> %.splatinsert1472, <8 x i64> poison, <8 x i32> zeroinitializer
  %4166 = mul <8 x i64> %.splat1473, splat (i64 32)
  %4167 = add <8 x i64> %4165, %4166
  %4168 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4164, 0
  %4169 = insertvalue { <8 x ptr>, <8 x i64> } %4168, <8 x i64> %4167, 1
  %4170 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %4171 = extractvalue { <8 x ptr>, <8 x i64> } %4169, 1
  %4172 = extractelement <8 x ptr> %4170, i32 0
  %4173 = extractelement <8 x i64> %4171, i32 0
  %4174 = sub i64 %4173, 0
  %4175 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4176 = select i1 %4175, i64 %4174, i64 0
  %private.contiguous.address1474 = getelementptr i8, ptr %4172, i64 %4176
  %private.contiguous.load1475 = load <8 x float>, ptr %private.contiguous.address1474, align 4
  %4177 = select <8 x i1> %95, <8 x float> %private.contiguous.load1475, <8 x float> zeroinitializer
  %4178 = fmul <8 x float> %4163, %4177
  %4179 = mul i64 %4042, 16
  %4180 = add i64 %4179, 0
  %tile_snapshot.spill.load1476 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4181 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1476, 0
  %4182 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1476, 1
  %.splatinsert1477 = insertelement <8 x i64> poison, i64 %4180, i64 0
  %.splat1478 = shufflevector <8 x i64> %.splatinsert1477, <8 x i64> poison, <8 x i32> zeroinitializer
  %4183 = mul <8 x i64> %.splat1478, splat (i64 32)
  %4184 = add <8 x i64> %4182, %4183
  %4185 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4181, 0
  %4186 = insertvalue { <8 x ptr>, <8 x i64> } %4185, <8 x i64> %4184, 1
  %4187 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4188 = extractvalue { <8 x ptr>, <8 x i64> } %4186, 1
  %4189 = extractelement <8 x ptr> %4187, i32 0
  %4190 = extractelement <8 x i64> %4188, i32 0
  %4191 = sub i64 %4190, 0
  %4192 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4193 = select i1 %4192, i64 %4191, i64 0
  %private.contiguous.address1479 = getelementptr i8, ptr %4189, i64 %4193
  %private.contiguous.load1480 = load <8 x float>, ptr %private.contiguous.address1479, align 4
  %4194 = select <8 x i1> %95, <8 x float> %private.contiguous.load1480, <8 x float> zeroinitializer
  %4195 = mul i64 %4112, 16
  %4196 = add i64 %4195, 0
  %tile_snapshot.spill.load1481 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4197 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1481, 0
  %4198 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1481, 1
  %.splatinsert1482 = insertelement <8 x i64> poison, i64 %4196, i64 0
  %.splat1483 = shufflevector <8 x i64> %.splatinsert1482, <8 x i64> poison, <8 x i32> zeroinitializer
  %4199 = mul <8 x i64> %.splat1483, splat (i64 32)
  %4200 = add <8 x i64> %4198, %4199
  %4201 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4197, 0
  %4202 = insertvalue { <8 x ptr>, <8 x i64> } %4201, <8 x i64> %4200, 1
  %4203 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4204 = extractvalue { <8 x ptr>, <8 x i64> } %4202, 1
  %4205 = extractelement <8 x ptr> %4203, i32 0
  %4206 = extractelement <8 x i64> %4204, i32 0
  %4207 = sub i64 %4206, 0
  %4208 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4209 = select i1 %4208, i64 %4207, i64 0
  %private.contiguous.address1484 = getelementptr i8, ptr %4205, i64 %4209
  %private.contiguous.load1485 = load <8 x float>, ptr %private.contiguous.address1484, align 4
  %4210 = select <8 x i1> %95, <8 x float> %private.contiguous.load1485, <8 x float> zeroinitializer
  %4211 = add i64 0, %4040
  %tile_snapshot.spill.load1486 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4212 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1486, 0
  %4213 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1486, 1
  %.splatinsert1487 = insertelement <8 x i64> poison, i64 %4211, i64 0
  %.splat1488 = shufflevector <8 x i64> %.splatinsert1487, <8 x i64> poison, <8 x i32> zeroinitializer
  %4214 = mul <8 x i64> %.splat1488, splat (i64 32)
  %4215 = add <8 x i64> %4213, %4214
  %4216 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4212, 0
  %4217 = insertvalue { <8 x ptr>, <8 x i64> } %4216, <8 x i64> %4215, 1
  %4218 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %4219 = extractvalue { <8 x ptr>, <8 x i64> } %4217, 1
  %4220 = extractelement <8 x ptr> %4218, i32 0
  %4221 = extractelement <8 x i64> %4219, i32 0
  %4222 = sub i64 %4221, 0
  %4223 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4224 = select i1 %4223, i64 %4222, i64 0
  %private.contiguous.address1489 = getelementptr i8, ptr %4220, i64 %4224
  %private.contiguous.load1490 = load <8 x float>, ptr %private.contiguous.address1489, align 4
  %4225 = select <8 x i1> %95, <8 x float> %private.contiguous.load1490, <8 x float> zeroinitializer
  %4226 = add i64 0, %4075
  %tile_snapshot.spill.load1491 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4227 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1491, 0
  %4228 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1491, 1
  %.splatinsert1492 = insertelement <8 x i64> poison, i64 %4226, i64 0
  %.splat1493 = shufflevector <8 x i64> %.splatinsert1492, <8 x i64> poison, <8 x i32> zeroinitializer
  %4229 = mul <8 x i64> %.splat1493, splat (i64 32)
  %4230 = add <8 x i64> %4228, %4229
  %4231 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4227, 0
  %4232 = insertvalue { <8 x ptr>, <8 x i64> } %4231, <8 x i64> %4230, 1
  %4233 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %4234 = extractvalue { <8 x ptr>, <8 x i64> } %4232, 1
  %4235 = extractelement <8 x ptr> %4233, i32 0
  %4236 = extractelement <8 x i64> %4234, i32 0
  %4237 = sub i64 %4236, 0
  %4238 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4239 = select i1 %4238, i64 %4237, i64 0
  %private.contiguous.address1494 = getelementptr i8, ptr %4235, i64 %4239
  %private.contiguous.load1495 = load <8 x float>, ptr %private.contiguous.address1494, align 4
  %4240 = select <8 x i1> %95, <8 x float> %private.contiguous.load1495, <8 x float> zeroinitializer
  %4241 = fmul <8 x float> %4194, %4225
  %4242 = fadd <8 x float> %4073, %4241
  %4243 = fmul <8 x float> %4194, %4240
  %4244 = fadd <8 x float> %4108, %4243
  %4245 = fmul <8 x float> %4210, %4225
  %4246 = fadd <8 x float> %4143, %4245
  %4247 = fmul <8 x float> %4210, %4240
  %4248 = fadd <8 x float> %4178, %4247
  %4249 = add i64 %4179, 1
  %tile_snapshot.spill.load1496 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4250 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1496, 0
  %4251 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1496, 1
  %.splatinsert1497 = insertelement <8 x i64> poison, i64 %4249, i64 0
  %.splat1498 = shufflevector <8 x i64> %.splatinsert1497, <8 x i64> poison, <8 x i32> zeroinitializer
  %4252 = mul <8 x i64> %.splat1498, splat (i64 32)
  %4253 = add <8 x i64> %4251, %4252
  %4254 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4250, 0
  %4255 = insertvalue { <8 x ptr>, <8 x i64> } %4254, <8 x i64> %4253, 1
  %4256 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4257 = extractvalue { <8 x ptr>, <8 x i64> } %4255, 1
  %4258 = extractelement <8 x ptr> %4256, i32 0
  %4259 = extractelement <8 x i64> %4257, i32 0
  %4260 = sub i64 %4259, 0
  %4261 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4262 = select i1 %4261, i64 %4260, i64 0
  %private.contiguous.address1499 = getelementptr i8, ptr %4258, i64 %4262
  %private.contiguous.load1500 = load <8 x float>, ptr %private.contiguous.address1499, align 4
  %4263 = select <8 x i1> %95, <8 x float> %private.contiguous.load1500, <8 x float> zeroinitializer
  %4264 = add i64 %4195, 1
  %tile_snapshot.spill.load1501 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4265 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1501, 0
  %4266 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1501, 1
  %.splatinsert1502 = insertelement <8 x i64> poison, i64 %4264, i64 0
  %.splat1503 = shufflevector <8 x i64> %.splatinsert1502, <8 x i64> poison, <8 x i32> zeroinitializer
  %4267 = mul <8 x i64> %.splat1503, splat (i64 32)
  %4268 = add <8 x i64> %4266, %4267
  %4269 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4265, 0
  %4270 = insertvalue { <8 x ptr>, <8 x i64> } %4269, <8 x i64> %4268, 1
  %4271 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4272 = extractvalue { <8 x ptr>, <8 x i64> } %4270, 1
  %4273 = extractelement <8 x ptr> %4271, i32 0
  %4274 = extractelement <8 x i64> %4272, i32 0
  %4275 = sub i64 %4274, 0
  %4276 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4277 = select i1 %4276, i64 %4275, i64 0
  %private.contiguous.address1504 = getelementptr i8, ptr %4273, i64 %4277
  %private.contiguous.load1505 = load <8 x float>, ptr %private.contiguous.address1504, align 4
  %4278 = select <8 x i1> %95, <8 x float> %private.contiguous.load1505, <8 x float> zeroinitializer
  %4279 = add i64 48, %4040
  %tile_snapshot.spill.load1506 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4280 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1506, 0
  %4281 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1506, 1
  %.splatinsert1507 = insertelement <8 x i64> poison, i64 %4279, i64 0
  %.splat1508 = shufflevector <8 x i64> %.splatinsert1507, <8 x i64> poison, <8 x i32> zeroinitializer
  %4282 = mul <8 x i64> %.splat1508, splat (i64 32)
  %4283 = add <8 x i64> %4281, %4282
  %4284 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4280, 0
  %4285 = insertvalue { <8 x ptr>, <8 x i64> } %4284, <8 x i64> %4283, 1
  %4286 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %4287 = extractvalue { <8 x ptr>, <8 x i64> } %4285, 1
  %4288 = extractelement <8 x ptr> %4286, i32 0
  %4289 = extractelement <8 x i64> %4287, i32 0
  %4290 = sub i64 %4289, 0
  %4291 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4292 = select i1 %4291, i64 %4290, i64 0
  %private.contiguous.address1509 = getelementptr i8, ptr %4288, i64 %4292
  %private.contiguous.load1510 = load <8 x float>, ptr %private.contiguous.address1509, align 4
  %4293 = select <8 x i1> %95, <8 x float> %private.contiguous.load1510, <8 x float> zeroinitializer
  %4294 = add i64 48, %4075
  %tile_snapshot.spill.load1511 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4295 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1511, 0
  %4296 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1511, 1
  %.splatinsert1512 = insertelement <8 x i64> poison, i64 %4294, i64 0
  %.splat1513 = shufflevector <8 x i64> %.splatinsert1512, <8 x i64> poison, <8 x i32> zeroinitializer
  %4297 = mul <8 x i64> %.splat1513, splat (i64 32)
  %4298 = add <8 x i64> %4296, %4297
  %4299 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4295, 0
  %4300 = insertvalue { <8 x ptr>, <8 x i64> } %4299, <8 x i64> %4298, 1
  %4301 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %4302 = extractvalue { <8 x ptr>, <8 x i64> } %4300, 1
  %4303 = extractelement <8 x ptr> %4301, i32 0
  %4304 = extractelement <8 x i64> %4302, i32 0
  %4305 = sub i64 %4304, 0
  %4306 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4307 = select i1 %4306, i64 %4305, i64 0
  %private.contiguous.address1514 = getelementptr i8, ptr %4303, i64 %4307
  %private.contiguous.load1515 = load <8 x float>, ptr %private.contiguous.address1514, align 4
  %4308 = select <8 x i1> %95, <8 x float> %private.contiguous.load1515, <8 x float> zeroinitializer
  %4309 = fmul <8 x float> %4263, %4293
  %4310 = fadd <8 x float> %4242, %4309
  %4311 = fmul <8 x float> %4263, %4308
  %4312 = fadd <8 x float> %4244, %4311
  %4313 = fmul <8 x float> %4278, %4293
  %4314 = fadd <8 x float> %4246, %4313
  %4315 = fmul <8 x float> %4278, %4308
  %4316 = fadd <8 x float> %4248, %4315
  %4317 = add i64 %4179, 2
  %tile_snapshot.spill.load1516 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4318 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1516, 0
  %4319 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1516, 1
  %.splatinsert1517 = insertelement <8 x i64> poison, i64 %4317, i64 0
  %.splat1518 = shufflevector <8 x i64> %.splatinsert1517, <8 x i64> poison, <8 x i32> zeroinitializer
  %4320 = mul <8 x i64> %.splat1518, splat (i64 32)
  %4321 = add <8 x i64> %4319, %4320
  %4322 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4318, 0
  %4323 = insertvalue { <8 x ptr>, <8 x i64> } %4322, <8 x i64> %4321, 1
  %4324 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4325 = extractvalue { <8 x ptr>, <8 x i64> } %4323, 1
  %4326 = extractelement <8 x ptr> %4324, i32 0
  %4327 = extractelement <8 x i64> %4325, i32 0
  %4328 = sub i64 %4327, 0
  %4329 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4330 = select i1 %4329, i64 %4328, i64 0
  %private.contiguous.address1519 = getelementptr i8, ptr %4326, i64 %4330
  %private.contiguous.load1520 = load <8 x float>, ptr %private.contiguous.address1519, align 4
  %4331 = select <8 x i1> %95, <8 x float> %private.contiguous.load1520, <8 x float> zeroinitializer
  %4332 = add i64 %4195, 2
  %tile_snapshot.spill.load1521 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4333 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1521, 0
  %4334 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1521, 1
  %.splatinsert1522 = insertelement <8 x i64> poison, i64 %4332, i64 0
  %.splat1523 = shufflevector <8 x i64> %.splatinsert1522, <8 x i64> poison, <8 x i32> zeroinitializer
  %4335 = mul <8 x i64> %.splat1523, splat (i64 32)
  %4336 = add <8 x i64> %4334, %4335
  %4337 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4333, 0
  %4338 = insertvalue { <8 x ptr>, <8 x i64> } %4337, <8 x i64> %4336, 1
  %4339 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4340 = extractvalue { <8 x ptr>, <8 x i64> } %4338, 1
  %4341 = extractelement <8 x ptr> %4339, i32 0
  %4342 = extractelement <8 x i64> %4340, i32 0
  %4343 = sub i64 %4342, 0
  %4344 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4345 = select i1 %4344, i64 %4343, i64 0
  %private.contiguous.address1524 = getelementptr i8, ptr %4341, i64 %4345
  %private.contiguous.load1525 = load <8 x float>, ptr %private.contiguous.address1524, align 4
  %4346 = select <8 x i1> %95, <8 x float> %private.contiguous.load1525, <8 x float> zeroinitializer
  %4347 = add i64 96, %4040
  %tile_snapshot.spill.load1526 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4348 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1526, 0
  %4349 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1526, 1
  %.splatinsert1527 = insertelement <8 x i64> poison, i64 %4347, i64 0
  %.splat1528 = shufflevector <8 x i64> %.splatinsert1527, <8 x i64> poison, <8 x i32> zeroinitializer
  %4350 = mul <8 x i64> %.splat1528, splat (i64 32)
  %4351 = add <8 x i64> %4349, %4350
  %4352 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4348, 0
  %4353 = insertvalue { <8 x ptr>, <8 x i64> } %4352, <8 x i64> %4351, 1
  %4354 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %4355 = extractvalue { <8 x ptr>, <8 x i64> } %4353, 1
  %4356 = extractelement <8 x ptr> %4354, i32 0
  %4357 = extractelement <8 x i64> %4355, i32 0
  %4358 = sub i64 %4357, 0
  %4359 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4360 = select i1 %4359, i64 %4358, i64 0
  %private.contiguous.address1529 = getelementptr i8, ptr %4356, i64 %4360
  %private.contiguous.load1530 = load <8 x float>, ptr %private.contiguous.address1529, align 4
  %4361 = select <8 x i1> %95, <8 x float> %private.contiguous.load1530, <8 x float> zeroinitializer
  %4362 = add i64 96, %4075
  %tile_snapshot.spill.load1531 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4363 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1531, 0
  %4364 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1531, 1
  %.splatinsert1532 = insertelement <8 x i64> poison, i64 %4362, i64 0
  %.splat1533 = shufflevector <8 x i64> %.splatinsert1532, <8 x i64> poison, <8 x i32> zeroinitializer
  %4365 = mul <8 x i64> %.splat1533, splat (i64 32)
  %4366 = add <8 x i64> %4364, %4365
  %4367 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4363, 0
  %4368 = insertvalue { <8 x ptr>, <8 x i64> } %4367, <8 x i64> %4366, 1
  %4369 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %4370 = extractvalue { <8 x ptr>, <8 x i64> } %4368, 1
  %4371 = extractelement <8 x ptr> %4369, i32 0
  %4372 = extractelement <8 x i64> %4370, i32 0
  %4373 = sub i64 %4372, 0
  %4374 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4375 = select i1 %4374, i64 %4373, i64 0
  %private.contiguous.address1534 = getelementptr i8, ptr %4371, i64 %4375
  %private.contiguous.load1535 = load <8 x float>, ptr %private.contiguous.address1534, align 4
  %4376 = select <8 x i1> %95, <8 x float> %private.contiguous.load1535, <8 x float> zeroinitializer
  %4377 = fmul <8 x float> %4331, %4361
  %4378 = fadd <8 x float> %4310, %4377
  %4379 = fmul <8 x float> %4331, %4376
  %4380 = fadd <8 x float> %4312, %4379
  %4381 = fmul <8 x float> %4346, %4361
  %4382 = fadd <8 x float> %4314, %4381
  %4383 = fmul <8 x float> %4346, %4376
  %4384 = fadd <8 x float> %4316, %4383
  %4385 = add i64 %4179, 3
  %tile_snapshot.spill.load1536 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4386 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1536, 0
  %4387 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1536, 1
  %.splatinsert1537 = insertelement <8 x i64> poison, i64 %4385, i64 0
  %.splat1538 = shufflevector <8 x i64> %.splatinsert1537, <8 x i64> poison, <8 x i32> zeroinitializer
  %4388 = mul <8 x i64> %.splat1538, splat (i64 32)
  %4389 = add <8 x i64> %4387, %4388
  %4390 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4386, 0
  %4391 = insertvalue { <8 x ptr>, <8 x i64> } %4390, <8 x i64> %4389, 1
  %4392 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4393 = extractvalue { <8 x ptr>, <8 x i64> } %4391, 1
  %4394 = extractelement <8 x ptr> %4392, i32 0
  %4395 = extractelement <8 x i64> %4393, i32 0
  %4396 = sub i64 %4395, 0
  %4397 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4398 = select i1 %4397, i64 %4396, i64 0
  %private.contiguous.address1539 = getelementptr i8, ptr %4394, i64 %4398
  %private.contiguous.load1540 = load <8 x float>, ptr %private.contiguous.address1539, align 4
  %4399 = select <8 x i1> %95, <8 x float> %private.contiguous.load1540, <8 x float> zeroinitializer
  %4400 = add i64 %4195, 3
  %tile_snapshot.spill.load1541 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4401 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1541, 0
  %4402 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1541, 1
  %.splatinsert1542 = insertelement <8 x i64> poison, i64 %4400, i64 0
  %.splat1543 = shufflevector <8 x i64> %.splatinsert1542, <8 x i64> poison, <8 x i32> zeroinitializer
  %4403 = mul <8 x i64> %.splat1543, splat (i64 32)
  %4404 = add <8 x i64> %4402, %4403
  %4405 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4401, 0
  %4406 = insertvalue { <8 x ptr>, <8 x i64> } %4405, <8 x i64> %4404, 1
  %4407 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4408 = extractvalue { <8 x ptr>, <8 x i64> } %4406, 1
  %4409 = extractelement <8 x ptr> %4407, i32 0
  %4410 = extractelement <8 x i64> %4408, i32 0
  %4411 = sub i64 %4410, 0
  %4412 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4413 = select i1 %4412, i64 %4411, i64 0
  %private.contiguous.address1544 = getelementptr i8, ptr %4409, i64 %4413
  %private.contiguous.load1545 = load <8 x float>, ptr %private.contiguous.address1544, align 4
  %4414 = select <8 x i1> %95, <8 x float> %private.contiguous.load1545, <8 x float> zeroinitializer
  %4415 = add i64 144, %4040
  %tile_snapshot.spill.load1546 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4416 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1546, 0
  %4417 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1546, 1
  %.splatinsert1547 = insertelement <8 x i64> poison, i64 %4415, i64 0
  %.splat1548 = shufflevector <8 x i64> %.splatinsert1547, <8 x i64> poison, <8 x i32> zeroinitializer
  %4418 = mul <8 x i64> %.splat1548, splat (i64 32)
  %4419 = add <8 x i64> %4417, %4418
  %4420 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4416, 0
  %4421 = insertvalue { <8 x ptr>, <8 x i64> } %4420, <8 x i64> %4419, 1
  %4422 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %4423 = extractvalue { <8 x ptr>, <8 x i64> } %4421, 1
  %4424 = extractelement <8 x ptr> %4422, i32 0
  %4425 = extractelement <8 x i64> %4423, i32 0
  %4426 = sub i64 %4425, 0
  %4427 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4428 = select i1 %4427, i64 %4426, i64 0
  %private.contiguous.address1549 = getelementptr i8, ptr %4424, i64 %4428
  %private.contiguous.load1550 = load <8 x float>, ptr %private.contiguous.address1549, align 4
  %4429 = select <8 x i1> %95, <8 x float> %private.contiguous.load1550, <8 x float> zeroinitializer
  %4430 = add i64 144, %4075
  %tile_snapshot.spill.load1551 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4431 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1551, 0
  %4432 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1551, 1
  %.splatinsert1552 = insertelement <8 x i64> poison, i64 %4430, i64 0
  %.splat1553 = shufflevector <8 x i64> %.splatinsert1552, <8 x i64> poison, <8 x i32> zeroinitializer
  %4433 = mul <8 x i64> %.splat1553, splat (i64 32)
  %4434 = add <8 x i64> %4432, %4433
  %4435 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4431, 0
  %4436 = insertvalue { <8 x ptr>, <8 x i64> } %4435, <8 x i64> %4434, 1
  %4437 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %4438 = extractvalue { <8 x ptr>, <8 x i64> } %4436, 1
  %4439 = extractelement <8 x ptr> %4437, i32 0
  %4440 = extractelement <8 x i64> %4438, i32 0
  %4441 = sub i64 %4440, 0
  %4442 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4443 = select i1 %4442, i64 %4441, i64 0
  %private.contiguous.address1554 = getelementptr i8, ptr %4439, i64 %4443
  %private.contiguous.load1555 = load <8 x float>, ptr %private.contiguous.address1554, align 4
  %4444 = select <8 x i1> %95, <8 x float> %private.contiguous.load1555, <8 x float> zeroinitializer
  %4445 = fmul <8 x float> %4399, %4429
  %4446 = fadd <8 x float> %4378, %4445
  %4447 = fmul <8 x float> %4399, %4444
  %4448 = fadd <8 x float> %4380, %4447
  %4449 = fmul <8 x float> %4414, %4429
  %4450 = fadd <8 x float> %4382, %4449
  %4451 = fmul <8 x float> %4414, %4444
  %4452 = fadd <8 x float> %4384, %4451
  %4453 = add i64 %4179, 4
  %tile_snapshot.spill.load1556 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4454 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1556, 0
  %4455 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1556, 1
  %.splatinsert1557 = insertelement <8 x i64> poison, i64 %4453, i64 0
  %.splat1558 = shufflevector <8 x i64> %.splatinsert1557, <8 x i64> poison, <8 x i32> zeroinitializer
  %4456 = mul <8 x i64> %.splat1558, splat (i64 32)
  %4457 = add <8 x i64> %4455, %4456
  %4458 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4454, 0
  %4459 = insertvalue { <8 x ptr>, <8 x i64> } %4458, <8 x i64> %4457, 1
  %4460 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4461 = extractvalue { <8 x ptr>, <8 x i64> } %4459, 1
  %4462 = extractelement <8 x ptr> %4460, i32 0
  %4463 = extractelement <8 x i64> %4461, i32 0
  %4464 = sub i64 %4463, 0
  %4465 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4466 = select i1 %4465, i64 %4464, i64 0
  %private.contiguous.address1559 = getelementptr i8, ptr %4462, i64 %4466
  %private.contiguous.load1560 = load <8 x float>, ptr %private.contiguous.address1559, align 4
  %4467 = select <8 x i1> %95, <8 x float> %private.contiguous.load1560, <8 x float> zeroinitializer
  %4468 = add i64 %4195, 4
  %tile_snapshot.spill.load1561 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4469 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1561, 0
  %4470 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1561, 1
  %.splatinsert1562 = insertelement <8 x i64> poison, i64 %4468, i64 0
  %.splat1563 = shufflevector <8 x i64> %.splatinsert1562, <8 x i64> poison, <8 x i32> zeroinitializer
  %4471 = mul <8 x i64> %.splat1563, splat (i64 32)
  %4472 = add <8 x i64> %4470, %4471
  %4473 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4469, 0
  %4474 = insertvalue { <8 x ptr>, <8 x i64> } %4473, <8 x i64> %4472, 1
  %4475 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4476 = extractvalue { <8 x ptr>, <8 x i64> } %4474, 1
  %4477 = extractelement <8 x ptr> %4475, i32 0
  %4478 = extractelement <8 x i64> %4476, i32 0
  %4479 = sub i64 %4478, 0
  %4480 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4481 = select i1 %4480, i64 %4479, i64 0
  %private.contiguous.address1564 = getelementptr i8, ptr %4477, i64 %4481
  %private.contiguous.load1565 = load <8 x float>, ptr %private.contiguous.address1564, align 4
  %4482 = select <8 x i1> %95, <8 x float> %private.contiguous.load1565, <8 x float> zeroinitializer
  %4483 = add i64 192, %4040
  %tile_snapshot.spill.load1566 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4484 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1566, 0
  %4485 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1566, 1
  %.splatinsert1567 = insertelement <8 x i64> poison, i64 %4483, i64 0
  %.splat1568 = shufflevector <8 x i64> %.splatinsert1567, <8 x i64> poison, <8 x i32> zeroinitializer
  %4486 = mul <8 x i64> %.splat1568, splat (i64 32)
  %4487 = add <8 x i64> %4485, %4486
  %4488 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4484, 0
  %4489 = insertvalue { <8 x ptr>, <8 x i64> } %4488, <8 x i64> %4487, 1
  %4490 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %4491 = extractvalue { <8 x ptr>, <8 x i64> } %4489, 1
  %4492 = extractelement <8 x ptr> %4490, i32 0
  %4493 = extractelement <8 x i64> %4491, i32 0
  %4494 = sub i64 %4493, 0
  %4495 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4496 = select i1 %4495, i64 %4494, i64 0
  %private.contiguous.address1569 = getelementptr i8, ptr %4492, i64 %4496
  %private.contiguous.load1570 = load <8 x float>, ptr %private.contiguous.address1569, align 4
  %4497 = select <8 x i1> %95, <8 x float> %private.contiguous.load1570, <8 x float> zeroinitializer
  %4498 = add i64 192, %4075
  %tile_snapshot.spill.load1571 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4499 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1571, 0
  %4500 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1571, 1
  %.splatinsert1572 = insertelement <8 x i64> poison, i64 %4498, i64 0
  %.splat1573 = shufflevector <8 x i64> %.splatinsert1572, <8 x i64> poison, <8 x i32> zeroinitializer
  %4501 = mul <8 x i64> %.splat1573, splat (i64 32)
  %4502 = add <8 x i64> %4500, %4501
  %4503 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4499, 0
  %4504 = insertvalue { <8 x ptr>, <8 x i64> } %4503, <8 x i64> %4502, 1
  %4505 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %4506 = extractvalue { <8 x ptr>, <8 x i64> } %4504, 1
  %4507 = extractelement <8 x ptr> %4505, i32 0
  %4508 = extractelement <8 x i64> %4506, i32 0
  %4509 = sub i64 %4508, 0
  %4510 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4511 = select i1 %4510, i64 %4509, i64 0
  %private.contiguous.address1574 = getelementptr i8, ptr %4507, i64 %4511
  %private.contiguous.load1575 = load <8 x float>, ptr %private.contiguous.address1574, align 4
  %4512 = select <8 x i1> %95, <8 x float> %private.contiguous.load1575, <8 x float> zeroinitializer
  %4513 = fmul <8 x float> %4467, %4497
  %4514 = fadd <8 x float> %4446, %4513
  %4515 = fmul <8 x float> %4467, %4512
  %4516 = fadd <8 x float> %4448, %4515
  %4517 = fmul <8 x float> %4482, %4497
  %4518 = fadd <8 x float> %4450, %4517
  %4519 = fmul <8 x float> %4482, %4512
  %4520 = fadd <8 x float> %4452, %4519
  %4521 = add i64 %4179, 5
  %tile_snapshot.spill.load1576 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4522 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1576, 0
  %4523 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1576, 1
  %.splatinsert1577 = insertelement <8 x i64> poison, i64 %4521, i64 0
  %.splat1578 = shufflevector <8 x i64> %.splatinsert1577, <8 x i64> poison, <8 x i32> zeroinitializer
  %4524 = mul <8 x i64> %.splat1578, splat (i64 32)
  %4525 = add <8 x i64> %4523, %4524
  %4526 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4522, 0
  %4527 = insertvalue { <8 x ptr>, <8 x i64> } %4526, <8 x i64> %4525, 1
  %4528 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4529 = extractvalue { <8 x ptr>, <8 x i64> } %4527, 1
  %4530 = extractelement <8 x ptr> %4528, i32 0
  %4531 = extractelement <8 x i64> %4529, i32 0
  %4532 = sub i64 %4531, 0
  %4533 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4534 = select i1 %4533, i64 %4532, i64 0
  %private.contiguous.address1579 = getelementptr i8, ptr %4530, i64 %4534
  %private.contiguous.load1580 = load <8 x float>, ptr %private.contiguous.address1579, align 4
  %4535 = select <8 x i1> %95, <8 x float> %private.contiguous.load1580, <8 x float> zeroinitializer
  %4536 = add i64 %4195, 5
  %tile_snapshot.spill.load1581 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4537 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1581, 0
  %4538 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1581, 1
  %.splatinsert1582 = insertelement <8 x i64> poison, i64 %4536, i64 0
  %.splat1583 = shufflevector <8 x i64> %.splatinsert1582, <8 x i64> poison, <8 x i32> zeroinitializer
  %4539 = mul <8 x i64> %.splat1583, splat (i64 32)
  %4540 = add <8 x i64> %4538, %4539
  %4541 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4537, 0
  %4542 = insertvalue { <8 x ptr>, <8 x i64> } %4541, <8 x i64> %4540, 1
  %4543 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4544 = extractvalue { <8 x ptr>, <8 x i64> } %4542, 1
  %4545 = extractelement <8 x ptr> %4543, i32 0
  %4546 = extractelement <8 x i64> %4544, i32 0
  %4547 = sub i64 %4546, 0
  %4548 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4549 = select i1 %4548, i64 %4547, i64 0
  %private.contiguous.address1584 = getelementptr i8, ptr %4545, i64 %4549
  %private.contiguous.load1585 = load <8 x float>, ptr %private.contiguous.address1584, align 4
  %4550 = select <8 x i1> %95, <8 x float> %private.contiguous.load1585, <8 x float> zeroinitializer
  %4551 = add i64 240, %4040
  %tile_snapshot.spill.load1586 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4552 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1586, 0
  %4553 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1586, 1
  %.splatinsert1587 = insertelement <8 x i64> poison, i64 %4551, i64 0
  %.splat1588 = shufflevector <8 x i64> %.splatinsert1587, <8 x i64> poison, <8 x i32> zeroinitializer
  %4554 = mul <8 x i64> %.splat1588, splat (i64 32)
  %4555 = add <8 x i64> %4553, %4554
  %4556 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4552, 0
  %4557 = insertvalue { <8 x ptr>, <8 x i64> } %4556, <8 x i64> %4555, 1
  %4558 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %4559 = extractvalue { <8 x ptr>, <8 x i64> } %4557, 1
  %4560 = extractelement <8 x ptr> %4558, i32 0
  %4561 = extractelement <8 x i64> %4559, i32 0
  %4562 = sub i64 %4561, 0
  %4563 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4564 = select i1 %4563, i64 %4562, i64 0
  %private.contiguous.address1589 = getelementptr i8, ptr %4560, i64 %4564
  %private.contiguous.load1590 = load <8 x float>, ptr %private.contiguous.address1589, align 4
  %4565 = select <8 x i1> %95, <8 x float> %private.contiguous.load1590, <8 x float> zeroinitializer
  %4566 = add i64 240, %4075
  %tile_snapshot.spill.load1591 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4567 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1591, 0
  %4568 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1591, 1
  %.splatinsert1592 = insertelement <8 x i64> poison, i64 %4566, i64 0
  %.splat1593 = shufflevector <8 x i64> %.splatinsert1592, <8 x i64> poison, <8 x i32> zeroinitializer
  %4569 = mul <8 x i64> %.splat1593, splat (i64 32)
  %4570 = add <8 x i64> %4568, %4569
  %4571 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4567, 0
  %4572 = insertvalue { <8 x ptr>, <8 x i64> } %4571, <8 x i64> %4570, 1
  %4573 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %4574 = extractvalue { <8 x ptr>, <8 x i64> } %4572, 1
  %4575 = extractelement <8 x ptr> %4573, i32 0
  %4576 = extractelement <8 x i64> %4574, i32 0
  %4577 = sub i64 %4576, 0
  %4578 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4579 = select i1 %4578, i64 %4577, i64 0
  %private.contiguous.address1594 = getelementptr i8, ptr %4575, i64 %4579
  %private.contiguous.load1595 = load <8 x float>, ptr %private.contiguous.address1594, align 4
  %4580 = select <8 x i1> %95, <8 x float> %private.contiguous.load1595, <8 x float> zeroinitializer
  %4581 = fmul <8 x float> %4535, %4565
  %4582 = fadd <8 x float> %4514, %4581
  %4583 = fmul <8 x float> %4535, %4580
  %4584 = fadd <8 x float> %4516, %4583
  %4585 = fmul <8 x float> %4550, %4565
  %4586 = fadd <8 x float> %4518, %4585
  %4587 = fmul <8 x float> %4550, %4580
  %4588 = fadd <8 x float> %4520, %4587
  %4589 = add i64 %4179, 6
  %tile_snapshot.spill.load1596 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4590 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1596, 0
  %4591 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1596, 1
  %.splatinsert1597 = insertelement <8 x i64> poison, i64 %4589, i64 0
  %.splat1598 = shufflevector <8 x i64> %.splatinsert1597, <8 x i64> poison, <8 x i32> zeroinitializer
  %4592 = mul <8 x i64> %.splat1598, splat (i64 32)
  %4593 = add <8 x i64> %4591, %4592
  %4594 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4590, 0
  %4595 = insertvalue { <8 x ptr>, <8 x i64> } %4594, <8 x i64> %4593, 1
  %4596 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4597 = extractvalue { <8 x ptr>, <8 x i64> } %4595, 1
  %4598 = extractelement <8 x ptr> %4596, i32 0
  %4599 = extractelement <8 x i64> %4597, i32 0
  %4600 = sub i64 %4599, 0
  %4601 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4602 = select i1 %4601, i64 %4600, i64 0
  %private.contiguous.address1599 = getelementptr i8, ptr %4598, i64 %4602
  %private.contiguous.load1600 = load <8 x float>, ptr %private.contiguous.address1599, align 4
  %4603 = select <8 x i1> %95, <8 x float> %private.contiguous.load1600, <8 x float> zeroinitializer
  %4604 = add i64 %4195, 6
  %tile_snapshot.spill.load1601 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4605 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1601, 0
  %4606 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1601, 1
  %.splatinsert1602 = insertelement <8 x i64> poison, i64 %4604, i64 0
  %.splat1603 = shufflevector <8 x i64> %.splatinsert1602, <8 x i64> poison, <8 x i32> zeroinitializer
  %4607 = mul <8 x i64> %.splat1603, splat (i64 32)
  %4608 = add <8 x i64> %4606, %4607
  %4609 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4605, 0
  %4610 = insertvalue { <8 x ptr>, <8 x i64> } %4609, <8 x i64> %4608, 1
  %4611 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4612 = extractvalue { <8 x ptr>, <8 x i64> } %4610, 1
  %4613 = extractelement <8 x ptr> %4611, i32 0
  %4614 = extractelement <8 x i64> %4612, i32 0
  %4615 = sub i64 %4614, 0
  %4616 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4617 = select i1 %4616, i64 %4615, i64 0
  %private.contiguous.address1604 = getelementptr i8, ptr %4613, i64 %4617
  %private.contiguous.load1605 = load <8 x float>, ptr %private.contiguous.address1604, align 4
  %4618 = select <8 x i1> %95, <8 x float> %private.contiguous.load1605, <8 x float> zeroinitializer
  %4619 = add i64 288, %4040
  %tile_snapshot.spill.load1606 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4620 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1606, 0
  %4621 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1606, 1
  %.splatinsert1607 = insertelement <8 x i64> poison, i64 %4619, i64 0
  %.splat1608 = shufflevector <8 x i64> %.splatinsert1607, <8 x i64> poison, <8 x i32> zeroinitializer
  %4622 = mul <8 x i64> %.splat1608, splat (i64 32)
  %4623 = add <8 x i64> %4621, %4622
  %4624 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4620, 0
  %4625 = insertvalue { <8 x ptr>, <8 x i64> } %4624, <8 x i64> %4623, 1
  %4626 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %4627 = extractvalue { <8 x ptr>, <8 x i64> } %4625, 1
  %4628 = extractelement <8 x ptr> %4626, i32 0
  %4629 = extractelement <8 x i64> %4627, i32 0
  %4630 = sub i64 %4629, 0
  %4631 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4632 = select i1 %4631, i64 %4630, i64 0
  %private.contiguous.address1609 = getelementptr i8, ptr %4628, i64 %4632
  %private.contiguous.load1610 = load <8 x float>, ptr %private.contiguous.address1609, align 4
  %4633 = select <8 x i1> %95, <8 x float> %private.contiguous.load1610, <8 x float> zeroinitializer
  %4634 = add i64 288, %4075
  %tile_snapshot.spill.load1611 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4635 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1611, 0
  %4636 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1611, 1
  %.splatinsert1612 = insertelement <8 x i64> poison, i64 %4634, i64 0
  %.splat1613 = shufflevector <8 x i64> %.splatinsert1612, <8 x i64> poison, <8 x i32> zeroinitializer
  %4637 = mul <8 x i64> %.splat1613, splat (i64 32)
  %4638 = add <8 x i64> %4636, %4637
  %4639 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4635, 0
  %4640 = insertvalue { <8 x ptr>, <8 x i64> } %4639, <8 x i64> %4638, 1
  %4641 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %4642 = extractvalue { <8 x ptr>, <8 x i64> } %4640, 1
  %4643 = extractelement <8 x ptr> %4641, i32 0
  %4644 = extractelement <8 x i64> %4642, i32 0
  %4645 = sub i64 %4644, 0
  %4646 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4647 = select i1 %4646, i64 %4645, i64 0
  %private.contiguous.address1614 = getelementptr i8, ptr %4643, i64 %4647
  %private.contiguous.load1615 = load <8 x float>, ptr %private.contiguous.address1614, align 4
  %4648 = select <8 x i1> %95, <8 x float> %private.contiguous.load1615, <8 x float> zeroinitializer
  %4649 = fmul <8 x float> %4603, %4633
  %4650 = fadd <8 x float> %4582, %4649
  %4651 = fmul <8 x float> %4603, %4648
  %4652 = fadd <8 x float> %4584, %4651
  %4653 = fmul <8 x float> %4618, %4633
  %4654 = fadd <8 x float> %4586, %4653
  %4655 = fmul <8 x float> %4618, %4648
  %4656 = fadd <8 x float> %4588, %4655
  %4657 = add i64 %4179, 7
  %tile_snapshot.spill.load1616 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4658 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1616, 0
  %4659 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1616, 1
  %.splatinsert1617 = insertelement <8 x i64> poison, i64 %4657, i64 0
  %.splat1618 = shufflevector <8 x i64> %.splatinsert1617, <8 x i64> poison, <8 x i32> zeroinitializer
  %4660 = mul <8 x i64> %.splat1618, splat (i64 32)
  %4661 = add <8 x i64> %4659, %4660
  %4662 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4658, 0
  %4663 = insertvalue { <8 x ptr>, <8 x i64> } %4662, <8 x i64> %4661, 1
  %4664 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4665 = extractvalue { <8 x ptr>, <8 x i64> } %4663, 1
  %4666 = extractelement <8 x ptr> %4664, i32 0
  %4667 = extractelement <8 x i64> %4665, i32 0
  %4668 = sub i64 %4667, 0
  %4669 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4670 = select i1 %4669, i64 %4668, i64 0
  %private.contiguous.address1619 = getelementptr i8, ptr %4666, i64 %4670
  %private.contiguous.load1620 = load <8 x float>, ptr %private.contiguous.address1619, align 4
  %4671 = select <8 x i1> %95, <8 x float> %private.contiguous.load1620, <8 x float> zeroinitializer
  %4672 = add i64 %4195, 7
  %tile_snapshot.spill.load1621 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4673 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1621, 0
  %4674 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1621, 1
  %.splatinsert1622 = insertelement <8 x i64> poison, i64 %4672, i64 0
  %.splat1623 = shufflevector <8 x i64> %.splatinsert1622, <8 x i64> poison, <8 x i32> zeroinitializer
  %4675 = mul <8 x i64> %.splat1623, splat (i64 32)
  %4676 = add <8 x i64> %4674, %4675
  %4677 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4673, 0
  %4678 = insertvalue { <8 x ptr>, <8 x i64> } %4677, <8 x i64> %4676, 1
  %4679 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4680 = extractvalue { <8 x ptr>, <8 x i64> } %4678, 1
  %4681 = extractelement <8 x ptr> %4679, i32 0
  %4682 = extractelement <8 x i64> %4680, i32 0
  %4683 = sub i64 %4682, 0
  %4684 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4685 = select i1 %4684, i64 %4683, i64 0
  %private.contiguous.address1624 = getelementptr i8, ptr %4681, i64 %4685
  %private.contiguous.load1625 = load <8 x float>, ptr %private.contiguous.address1624, align 4
  %4686 = select <8 x i1> %95, <8 x float> %private.contiguous.load1625, <8 x float> zeroinitializer
  %4687 = add i64 336, %4040
  %tile_snapshot.spill.load1626 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4688 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1626, 0
  %4689 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1626, 1
  %.splatinsert1627 = insertelement <8 x i64> poison, i64 %4687, i64 0
  %.splat1628 = shufflevector <8 x i64> %.splatinsert1627, <8 x i64> poison, <8 x i32> zeroinitializer
  %4690 = mul <8 x i64> %.splat1628, splat (i64 32)
  %4691 = add <8 x i64> %4689, %4690
  %4692 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4688, 0
  %4693 = insertvalue { <8 x ptr>, <8 x i64> } %4692, <8 x i64> %4691, 1
  %4694 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %4695 = extractvalue { <8 x ptr>, <8 x i64> } %4693, 1
  %4696 = extractelement <8 x ptr> %4694, i32 0
  %4697 = extractelement <8 x i64> %4695, i32 0
  %4698 = sub i64 %4697, 0
  %4699 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4700 = select i1 %4699, i64 %4698, i64 0
  %private.contiguous.address1629 = getelementptr i8, ptr %4696, i64 %4700
  %private.contiguous.load1630 = load <8 x float>, ptr %private.contiguous.address1629, align 4
  %4701 = select <8 x i1> %95, <8 x float> %private.contiguous.load1630, <8 x float> zeroinitializer
  %4702 = add i64 336, %4075
  %tile_snapshot.spill.load1631 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4703 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1631, 0
  %4704 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1631, 1
  %.splatinsert1632 = insertelement <8 x i64> poison, i64 %4702, i64 0
  %.splat1633 = shufflevector <8 x i64> %.splatinsert1632, <8 x i64> poison, <8 x i32> zeroinitializer
  %4705 = mul <8 x i64> %.splat1633, splat (i64 32)
  %4706 = add <8 x i64> %4704, %4705
  %4707 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4703, 0
  %4708 = insertvalue { <8 x ptr>, <8 x i64> } %4707, <8 x i64> %4706, 1
  %4709 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %4710 = extractvalue { <8 x ptr>, <8 x i64> } %4708, 1
  %4711 = extractelement <8 x ptr> %4709, i32 0
  %4712 = extractelement <8 x i64> %4710, i32 0
  %4713 = sub i64 %4712, 0
  %4714 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4715 = select i1 %4714, i64 %4713, i64 0
  %private.contiguous.address1634 = getelementptr i8, ptr %4711, i64 %4715
  %private.contiguous.load1635 = load <8 x float>, ptr %private.contiguous.address1634, align 4
  %4716 = select <8 x i1> %95, <8 x float> %private.contiguous.load1635, <8 x float> zeroinitializer
  %4717 = fmul <8 x float> %4671, %4701
  %4718 = fadd <8 x float> %4650, %4717
  %4719 = fmul <8 x float> %4671, %4716
  %4720 = fadd <8 x float> %4652, %4719
  %4721 = fmul <8 x float> %4686, %4701
  %4722 = fadd <8 x float> %4654, %4721
  %4723 = fmul <8 x float> %4686, %4716
  %4724 = fadd <8 x float> %4656, %4723
  %4725 = add i64 %4179, 8
  %tile_snapshot.spill.load1636 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4726 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1636, 0
  %4727 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1636, 1
  %.splatinsert1637 = insertelement <8 x i64> poison, i64 %4725, i64 0
  %.splat1638 = shufflevector <8 x i64> %.splatinsert1637, <8 x i64> poison, <8 x i32> zeroinitializer
  %4728 = mul <8 x i64> %.splat1638, splat (i64 32)
  %4729 = add <8 x i64> %4727, %4728
  %4730 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4726, 0
  %4731 = insertvalue { <8 x ptr>, <8 x i64> } %4730, <8 x i64> %4729, 1
  %4732 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4733 = extractvalue { <8 x ptr>, <8 x i64> } %4731, 1
  %4734 = extractelement <8 x ptr> %4732, i32 0
  %4735 = extractelement <8 x i64> %4733, i32 0
  %4736 = sub i64 %4735, 0
  %4737 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4738 = select i1 %4737, i64 %4736, i64 0
  %private.contiguous.address1639 = getelementptr i8, ptr %4734, i64 %4738
  %private.contiguous.load1640 = load <8 x float>, ptr %private.contiguous.address1639, align 4
  %4739 = select <8 x i1> %95, <8 x float> %private.contiguous.load1640, <8 x float> zeroinitializer
  %4740 = add i64 %4195, 8
  %tile_snapshot.spill.load1641 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4741 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1641, 0
  %4742 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1641, 1
  %.splatinsert1642 = insertelement <8 x i64> poison, i64 %4740, i64 0
  %.splat1643 = shufflevector <8 x i64> %.splatinsert1642, <8 x i64> poison, <8 x i32> zeroinitializer
  %4743 = mul <8 x i64> %.splat1643, splat (i64 32)
  %4744 = add <8 x i64> %4742, %4743
  %4745 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4741, 0
  %4746 = insertvalue { <8 x ptr>, <8 x i64> } %4745, <8 x i64> %4744, 1
  %4747 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4748 = extractvalue { <8 x ptr>, <8 x i64> } %4746, 1
  %4749 = extractelement <8 x ptr> %4747, i32 0
  %4750 = extractelement <8 x i64> %4748, i32 0
  %4751 = sub i64 %4750, 0
  %4752 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4753 = select i1 %4752, i64 %4751, i64 0
  %private.contiguous.address1644 = getelementptr i8, ptr %4749, i64 %4753
  %private.contiguous.load1645 = load <8 x float>, ptr %private.contiguous.address1644, align 4
  %4754 = select <8 x i1> %95, <8 x float> %private.contiguous.load1645, <8 x float> zeroinitializer
  %4755 = add i64 384, %4040
  %tile_snapshot.spill.load1646 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4756 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1646, 0
  %4757 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1646, 1
  %.splatinsert1647 = insertelement <8 x i64> poison, i64 %4755, i64 0
  %.splat1648 = shufflevector <8 x i64> %.splatinsert1647, <8 x i64> poison, <8 x i32> zeroinitializer
  %4758 = mul <8 x i64> %.splat1648, splat (i64 32)
  %4759 = add <8 x i64> %4757, %4758
  %4760 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4756, 0
  %4761 = insertvalue { <8 x ptr>, <8 x i64> } %4760, <8 x i64> %4759, 1
  %4762 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %4763 = extractvalue { <8 x ptr>, <8 x i64> } %4761, 1
  %4764 = extractelement <8 x ptr> %4762, i32 0
  %4765 = extractelement <8 x i64> %4763, i32 0
  %4766 = sub i64 %4765, 0
  %4767 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4768 = select i1 %4767, i64 %4766, i64 0
  %private.contiguous.address1649 = getelementptr i8, ptr %4764, i64 %4768
  %private.contiguous.load1650 = load <8 x float>, ptr %private.contiguous.address1649, align 4
  %4769 = select <8 x i1> %95, <8 x float> %private.contiguous.load1650, <8 x float> zeroinitializer
  %4770 = add i64 384, %4075
  %tile_snapshot.spill.load1651 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4771 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1651, 0
  %4772 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1651, 1
  %.splatinsert1652 = insertelement <8 x i64> poison, i64 %4770, i64 0
  %.splat1653 = shufflevector <8 x i64> %.splatinsert1652, <8 x i64> poison, <8 x i32> zeroinitializer
  %4773 = mul <8 x i64> %.splat1653, splat (i64 32)
  %4774 = add <8 x i64> %4772, %4773
  %4775 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4771, 0
  %4776 = insertvalue { <8 x ptr>, <8 x i64> } %4775, <8 x i64> %4774, 1
  %4777 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %4778 = extractvalue { <8 x ptr>, <8 x i64> } %4776, 1
  %4779 = extractelement <8 x ptr> %4777, i32 0
  %4780 = extractelement <8 x i64> %4778, i32 0
  %4781 = sub i64 %4780, 0
  %4782 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4783 = select i1 %4782, i64 %4781, i64 0
  %private.contiguous.address1654 = getelementptr i8, ptr %4779, i64 %4783
  %private.contiguous.load1655 = load <8 x float>, ptr %private.contiguous.address1654, align 4
  %4784 = select <8 x i1> %95, <8 x float> %private.contiguous.load1655, <8 x float> zeroinitializer
  %4785 = fmul <8 x float> %4739, %4769
  %4786 = fadd <8 x float> %4718, %4785
  %4787 = fmul <8 x float> %4739, %4784
  %4788 = fadd <8 x float> %4720, %4787
  %4789 = fmul <8 x float> %4754, %4769
  %4790 = fadd <8 x float> %4722, %4789
  %4791 = fmul <8 x float> %4754, %4784
  %4792 = fadd <8 x float> %4724, %4791
  %4793 = add i64 %4179, 9
  %tile_snapshot.spill.load1656 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4794 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1656, 0
  %4795 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1656, 1
  %.splatinsert1657 = insertelement <8 x i64> poison, i64 %4793, i64 0
  %.splat1658 = shufflevector <8 x i64> %.splatinsert1657, <8 x i64> poison, <8 x i32> zeroinitializer
  %4796 = mul <8 x i64> %.splat1658, splat (i64 32)
  %4797 = add <8 x i64> %4795, %4796
  %4798 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4794, 0
  %4799 = insertvalue { <8 x ptr>, <8 x i64> } %4798, <8 x i64> %4797, 1
  %4800 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4801 = extractvalue { <8 x ptr>, <8 x i64> } %4799, 1
  %4802 = extractelement <8 x ptr> %4800, i32 0
  %4803 = extractelement <8 x i64> %4801, i32 0
  %4804 = sub i64 %4803, 0
  %4805 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4806 = select i1 %4805, i64 %4804, i64 0
  %private.contiguous.address1659 = getelementptr i8, ptr %4802, i64 %4806
  %private.contiguous.load1660 = load <8 x float>, ptr %private.contiguous.address1659, align 4
  %4807 = select <8 x i1> %95, <8 x float> %private.contiguous.load1660, <8 x float> zeroinitializer
  %4808 = add i64 %4195, 9
  %tile_snapshot.spill.load1661 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4809 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1661, 0
  %4810 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1661, 1
  %.splatinsert1662 = insertelement <8 x i64> poison, i64 %4808, i64 0
  %.splat1663 = shufflevector <8 x i64> %.splatinsert1662, <8 x i64> poison, <8 x i32> zeroinitializer
  %4811 = mul <8 x i64> %.splat1663, splat (i64 32)
  %4812 = add <8 x i64> %4810, %4811
  %4813 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4809, 0
  %4814 = insertvalue { <8 x ptr>, <8 x i64> } %4813, <8 x i64> %4812, 1
  %4815 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4816 = extractvalue { <8 x ptr>, <8 x i64> } %4814, 1
  %4817 = extractelement <8 x ptr> %4815, i32 0
  %4818 = extractelement <8 x i64> %4816, i32 0
  %4819 = sub i64 %4818, 0
  %4820 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4821 = select i1 %4820, i64 %4819, i64 0
  %private.contiguous.address1664 = getelementptr i8, ptr %4817, i64 %4821
  %private.contiguous.load1665 = load <8 x float>, ptr %private.contiguous.address1664, align 4
  %4822 = select <8 x i1> %95, <8 x float> %private.contiguous.load1665, <8 x float> zeroinitializer
  %4823 = add i64 432, %4040
  %tile_snapshot.spill.load1666 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4824 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1666, 0
  %4825 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1666, 1
  %.splatinsert1667 = insertelement <8 x i64> poison, i64 %4823, i64 0
  %.splat1668 = shufflevector <8 x i64> %.splatinsert1667, <8 x i64> poison, <8 x i32> zeroinitializer
  %4826 = mul <8 x i64> %.splat1668, splat (i64 32)
  %4827 = add <8 x i64> %4825, %4826
  %4828 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4824, 0
  %4829 = insertvalue { <8 x ptr>, <8 x i64> } %4828, <8 x i64> %4827, 1
  %4830 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %4831 = extractvalue { <8 x ptr>, <8 x i64> } %4829, 1
  %4832 = extractelement <8 x ptr> %4830, i32 0
  %4833 = extractelement <8 x i64> %4831, i32 0
  %4834 = sub i64 %4833, 0
  %4835 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4836 = select i1 %4835, i64 %4834, i64 0
  %private.contiguous.address1669 = getelementptr i8, ptr %4832, i64 %4836
  %private.contiguous.load1670 = load <8 x float>, ptr %private.contiguous.address1669, align 4
  %4837 = select <8 x i1> %95, <8 x float> %private.contiguous.load1670, <8 x float> zeroinitializer
  %4838 = add i64 432, %4075
  %tile_snapshot.spill.load1671 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4839 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1671, 0
  %4840 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1671, 1
  %.splatinsert1672 = insertelement <8 x i64> poison, i64 %4838, i64 0
  %.splat1673 = shufflevector <8 x i64> %.splatinsert1672, <8 x i64> poison, <8 x i32> zeroinitializer
  %4841 = mul <8 x i64> %.splat1673, splat (i64 32)
  %4842 = add <8 x i64> %4840, %4841
  %4843 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4839, 0
  %4844 = insertvalue { <8 x ptr>, <8 x i64> } %4843, <8 x i64> %4842, 1
  %4845 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %4846 = extractvalue { <8 x ptr>, <8 x i64> } %4844, 1
  %4847 = extractelement <8 x ptr> %4845, i32 0
  %4848 = extractelement <8 x i64> %4846, i32 0
  %4849 = sub i64 %4848, 0
  %4850 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4851 = select i1 %4850, i64 %4849, i64 0
  %private.contiguous.address1674 = getelementptr i8, ptr %4847, i64 %4851
  %private.contiguous.load1675 = load <8 x float>, ptr %private.contiguous.address1674, align 4
  %4852 = select <8 x i1> %95, <8 x float> %private.contiguous.load1675, <8 x float> zeroinitializer
  %4853 = fmul <8 x float> %4807, %4837
  %4854 = fadd <8 x float> %4786, %4853
  %4855 = fmul <8 x float> %4807, %4852
  %4856 = fadd <8 x float> %4788, %4855
  %4857 = fmul <8 x float> %4822, %4837
  %4858 = fadd <8 x float> %4790, %4857
  %4859 = fmul <8 x float> %4822, %4852
  %4860 = fadd <8 x float> %4792, %4859
  %4861 = add i64 %4179, 10
  %tile_snapshot.spill.load1676 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4862 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1676, 0
  %4863 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1676, 1
  %.splatinsert1677 = insertelement <8 x i64> poison, i64 %4861, i64 0
  %.splat1678 = shufflevector <8 x i64> %.splatinsert1677, <8 x i64> poison, <8 x i32> zeroinitializer
  %4864 = mul <8 x i64> %.splat1678, splat (i64 32)
  %4865 = add <8 x i64> %4863, %4864
  %4866 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4862, 0
  %4867 = insertvalue { <8 x ptr>, <8 x i64> } %4866, <8 x i64> %4865, 1
  %4868 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4869 = extractvalue { <8 x ptr>, <8 x i64> } %4867, 1
  %4870 = extractelement <8 x ptr> %4868, i32 0
  %4871 = extractelement <8 x i64> %4869, i32 0
  %4872 = sub i64 %4871, 0
  %4873 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4874 = select i1 %4873, i64 %4872, i64 0
  %private.contiguous.address1679 = getelementptr i8, ptr %4870, i64 %4874
  %private.contiguous.load1680 = load <8 x float>, ptr %private.contiguous.address1679, align 4
  %4875 = select <8 x i1> %95, <8 x float> %private.contiguous.load1680, <8 x float> zeroinitializer
  %4876 = add i64 %4195, 10
  %tile_snapshot.spill.load1681 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4877 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1681, 0
  %4878 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1681, 1
  %.splatinsert1682 = insertelement <8 x i64> poison, i64 %4876, i64 0
  %.splat1683 = shufflevector <8 x i64> %.splatinsert1682, <8 x i64> poison, <8 x i32> zeroinitializer
  %4879 = mul <8 x i64> %.splat1683, splat (i64 32)
  %4880 = add <8 x i64> %4878, %4879
  %4881 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4877, 0
  %4882 = insertvalue { <8 x ptr>, <8 x i64> } %4881, <8 x i64> %4880, 1
  %4883 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4884 = extractvalue { <8 x ptr>, <8 x i64> } %4882, 1
  %4885 = extractelement <8 x ptr> %4883, i32 0
  %4886 = extractelement <8 x i64> %4884, i32 0
  %4887 = sub i64 %4886, 0
  %4888 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4889 = select i1 %4888, i64 %4887, i64 0
  %private.contiguous.address1684 = getelementptr i8, ptr %4885, i64 %4889
  %private.contiguous.load1685 = load <8 x float>, ptr %private.contiguous.address1684, align 4
  %4890 = select <8 x i1> %95, <8 x float> %private.contiguous.load1685, <8 x float> zeroinitializer
  %4891 = add i64 480, %4040
  %tile_snapshot.spill.load1686 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4892 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1686, 0
  %4893 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1686, 1
  %.splatinsert1687 = insertelement <8 x i64> poison, i64 %4891, i64 0
  %.splat1688 = shufflevector <8 x i64> %.splatinsert1687, <8 x i64> poison, <8 x i32> zeroinitializer
  %4894 = mul <8 x i64> %.splat1688, splat (i64 32)
  %4895 = add <8 x i64> %4893, %4894
  %4896 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4892, 0
  %4897 = insertvalue { <8 x ptr>, <8 x i64> } %4896, <8 x i64> %4895, 1
  %4898 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %4899 = extractvalue { <8 x ptr>, <8 x i64> } %4897, 1
  %4900 = extractelement <8 x ptr> %4898, i32 0
  %4901 = extractelement <8 x i64> %4899, i32 0
  %4902 = sub i64 %4901, 0
  %4903 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4904 = select i1 %4903, i64 %4902, i64 0
  %private.contiguous.address1689 = getelementptr i8, ptr %4900, i64 %4904
  %private.contiguous.load1690 = load <8 x float>, ptr %private.contiguous.address1689, align 4
  %4905 = select <8 x i1> %95, <8 x float> %private.contiguous.load1690, <8 x float> zeroinitializer
  %4906 = add i64 480, %4075
  %tile_snapshot.spill.load1691 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4907 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1691, 0
  %4908 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1691, 1
  %.splatinsert1692 = insertelement <8 x i64> poison, i64 %4906, i64 0
  %.splat1693 = shufflevector <8 x i64> %.splatinsert1692, <8 x i64> poison, <8 x i32> zeroinitializer
  %4909 = mul <8 x i64> %.splat1693, splat (i64 32)
  %4910 = add <8 x i64> %4908, %4909
  %4911 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4907, 0
  %4912 = insertvalue { <8 x ptr>, <8 x i64> } %4911, <8 x i64> %4910, 1
  %4913 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %4914 = extractvalue { <8 x ptr>, <8 x i64> } %4912, 1
  %4915 = extractelement <8 x ptr> %4913, i32 0
  %4916 = extractelement <8 x i64> %4914, i32 0
  %4917 = sub i64 %4916, 0
  %4918 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4919 = select i1 %4918, i64 %4917, i64 0
  %private.contiguous.address1694 = getelementptr i8, ptr %4915, i64 %4919
  %private.contiguous.load1695 = load <8 x float>, ptr %private.contiguous.address1694, align 4
  %4920 = select <8 x i1> %95, <8 x float> %private.contiguous.load1695, <8 x float> zeroinitializer
  %4921 = fmul <8 x float> %4875, %4905
  %4922 = fadd <8 x float> %4854, %4921
  %4923 = fmul <8 x float> %4875, %4920
  %4924 = fadd <8 x float> %4856, %4923
  %4925 = fmul <8 x float> %4890, %4905
  %4926 = fadd <8 x float> %4858, %4925
  %4927 = fmul <8 x float> %4890, %4920
  %4928 = fadd <8 x float> %4860, %4927
  %4929 = add i64 %4179, 11
  %tile_snapshot.spill.load1696 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4930 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1696, 0
  %4931 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1696, 1
  %.splatinsert1697 = insertelement <8 x i64> poison, i64 %4929, i64 0
  %.splat1698 = shufflevector <8 x i64> %.splatinsert1697, <8 x i64> poison, <8 x i32> zeroinitializer
  %4932 = mul <8 x i64> %.splat1698, splat (i64 32)
  %4933 = add <8 x i64> %4931, %4932
  %4934 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4930, 0
  %4935 = insertvalue { <8 x ptr>, <8 x i64> } %4934, <8 x i64> %4933, 1
  %4936 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4937 = extractvalue { <8 x ptr>, <8 x i64> } %4935, 1
  %4938 = extractelement <8 x ptr> %4936, i32 0
  %4939 = extractelement <8 x i64> %4937, i32 0
  %4940 = sub i64 %4939, 0
  %4941 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4942 = select i1 %4941, i64 %4940, i64 0
  %private.contiguous.address1699 = getelementptr i8, ptr %4938, i64 %4942
  %private.contiguous.load1700 = load <8 x float>, ptr %private.contiguous.address1699, align 4
  %4943 = select <8 x i1> %95, <8 x float> %private.contiguous.load1700, <8 x float> zeroinitializer
  %4944 = add i64 %4195, 11
  %tile_snapshot.spill.load1701 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4945 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1701, 0
  %4946 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1701, 1
  %.splatinsert1702 = insertelement <8 x i64> poison, i64 %4944, i64 0
  %.splat1703 = shufflevector <8 x i64> %.splatinsert1702, <8 x i64> poison, <8 x i32> zeroinitializer
  %4947 = mul <8 x i64> %.splat1703, splat (i64 32)
  %4948 = add <8 x i64> %4946, %4947
  %4949 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4945, 0
  %4950 = insertvalue { <8 x ptr>, <8 x i64> } %4949, <8 x i64> %4948, 1
  %4951 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4952 = extractvalue { <8 x ptr>, <8 x i64> } %4950, 1
  %4953 = extractelement <8 x ptr> %4951, i32 0
  %4954 = extractelement <8 x i64> %4952, i32 0
  %4955 = sub i64 %4954, 0
  %4956 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4957 = select i1 %4956, i64 %4955, i64 0
  %private.contiguous.address1704 = getelementptr i8, ptr %4953, i64 %4957
  %private.contiguous.load1705 = load <8 x float>, ptr %private.contiguous.address1704, align 4
  %4958 = select <8 x i1> %95, <8 x float> %private.contiguous.load1705, <8 x float> zeroinitializer
  %4959 = add i64 528, %4040
  %tile_snapshot.spill.load1706 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4960 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1706, 0
  %4961 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1706, 1
  %.splatinsert1707 = insertelement <8 x i64> poison, i64 %4959, i64 0
  %.splat1708 = shufflevector <8 x i64> %.splatinsert1707, <8 x i64> poison, <8 x i32> zeroinitializer
  %4962 = mul <8 x i64> %.splat1708, splat (i64 32)
  %4963 = add <8 x i64> %4961, %4962
  %4964 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4960, 0
  %4965 = insertvalue { <8 x ptr>, <8 x i64> } %4964, <8 x i64> %4963, 1
  %4966 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %4967 = extractvalue { <8 x ptr>, <8 x i64> } %4965, 1
  %4968 = extractelement <8 x ptr> %4966, i32 0
  %4969 = extractelement <8 x i64> %4967, i32 0
  %4970 = sub i64 %4969, 0
  %4971 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4972 = select i1 %4971, i64 %4970, i64 0
  %private.contiguous.address1709 = getelementptr i8, ptr %4968, i64 %4972
  %private.contiguous.load1710 = load <8 x float>, ptr %private.contiguous.address1709, align 4
  %4973 = select <8 x i1> %95, <8 x float> %private.contiguous.load1710, <8 x float> zeroinitializer
  %4974 = add i64 528, %4075
  %tile_snapshot.spill.load1711 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4975 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1711, 0
  %4976 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1711, 1
  %.splatinsert1712 = insertelement <8 x i64> poison, i64 %4974, i64 0
  %.splat1713 = shufflevector <8 x i64> %.splatinsert1712, <8 x i64> poison, <8 x i32> zeroinitializer
  %4977 = mul <8 x i64> %.splat1713, splat (i64 32)
  %4978 = add <8 x i64> %4976, %4977
  %4979 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4975, 0
  %4980 = insertvalue { <8 x ptr>, <8 x i64> } %4979, <8 x i64> %4978, 1
  %4981 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %4982 = extractvalue { <8 x ptr>, <8 x i64> } %4980, 1
  %4983 = extractelement <8 x ptr> %4981, i32 0
  %4984 = extractelement <8 x i64> %4982, i32 0
  %4985 = sub i64 %4984, 0
  %4986 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4987 = select i1 %4986, i64 %4985, i64 0
  %private.contiguous.address1714 = getelementptr i8, ptr %4983, i64 %4987
  %private.contiguous.load1715 = load <8 x float>, ptr %private.contiguous.address1714, align 4
  %4988 = select <8 x i1> %95, <8 x float> %private.contiguous.load1715, <8 x float> zeroinitializer
  %4989 = fmul <8 x float> %4943, %4973
  %4990 = fadd <8 x float> %4922, %4989
  %4991 = fmul <8 x float> %4943, %4988
  %4992 = fadd <8 x float> %4924, %4991
  %4993 = fmul <8 x float> %4958, %4973
  %4994 = fadd <8 x float> %4926, %4993
  %4995 = fmul <8 x float> %4958, %4988
  %4996 = fadd <8 x float> %4928, %4995
  %4997 = add i64 %4179, 12
  %tile_snapshot.spill.load1716 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4998 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1716, 0
  %4999 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1716, 1
  %.splatinsert1717 = insertelement <8 x i64> poison, i64 %4997, i64 0
  %.splat1718 = shufflevector <8 x i64> %.splatinsert1717, <8 x i64> poison, <8 x i32> zeroinitializer
  %5000 = mul <8 x i64> %.splat1718, splat (i64 32)
  %5001 = add <8 x i64> %4999, %5000
  %5002 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4998, 0
  %5003 = insertvalue { <8 x ptr>, <8 x i64> } %5002, <8 x i64> %5001, 1
  %5004 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %5005 = extractvalue { <8 x ptr>, <8 x i64> } %5003, 1
  %5006 = extractelement <8 x ptr> %5004, i32 0
  %5007 = extractelement <8 x i64> %5005, i32 0
  %5008 = sub i64 %5007, 0
  %5009 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5010 = select i1 %5009, i64 %5008, i64 0
  %private.contiguous.address1719 = getelementptr i8, ptr %5006, i64 %5010
  %private.contiguous.load1720 = load <8 x float>, ptr %private.contiguous.address1719, align 4
  %5011 = select <8 x i1> %95, <8 x float> %private.contiguous.load1720, <8 x float> zeroinitializer
  %5012 = add i64 %4195, 12
  %tile_snapshot.spill.load1721 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %5013 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1721, 0
  %5014 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1721, 1
  %.splatinsert1722 = insertelement <8 x i64> poison, i64 %5012, i64 0
  %.splat1723 = shufflevector <8 x i64> %.splatinsert1722, <8 x i64> poison, <8 x i32> zeroinitializer
  %5015 = mul <8 x i64> %.splat1723, splat (i64 32)
  %5016 = add <8 x i64> %5014, %5015
  %5017 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5013, 0
  %5018 = insertvalue { <8 x ptr>, <8 x i64> } %5017, <8 x i64> %5016, 1
  %5019 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %5020 = extractvalue { <8 x ptr>, <8 x i64> } %5018, 1
  %5021 = extractelement <8 x ptr> %5019, i32 0
  %5022 = extractelement <8 x i64> %5020, i32 0
  %5023 = sub i64 %5022, 0
  %5024 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5025 = select i1 %5024, i64 %5023, i64 0
  %private.contiguous.address1724 = getelementptr i8, ptr %5021, i64 %5025
  %private.contiguous.load1725 = load <8 x float>, ptr %private.contiguous.address1724, align 4
  %5026 = select <8 x i1> %95, <8 x float> %private.contiguous.load1725, <8 x float> zeroinitializer
  %5027 = add i64 576, %4040
  %tile_snapshot.spill.load1726 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %5028 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1726, 0
  %5029 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1726, 1
  %.splatinsert1727 = insertelement <8 x i64> poison, i64 %5027, i64 0
  %.splat1728 = shufflevector <8 x i64> %.splatinsert1727, <8 x i64> poison, <8 x i32> zeroinitializer
  %5030 = mul <8 x i64> %.splat1728, splat (i64 32)
  %5031 = add <8 x i64> %5029, %5030
  %5032 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5028, 0
  %5033 = insertvalue { <8 x ptr>, <8 x i64> } %5032, <8 x i64> %5031, 1
  %5034 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %5035 = extractvalue { <8 x ptr>, <8 x i64> } %5033, 1
  %5036 = extractelement <8 x ptr> %5034, i32 0
  %5037 = extractelement <8 x i64> %5035, i32 0
  %5038 = sub i64 %5037, 0
  %5039 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5040 = select i1 %5039, i64 %5038, i64 0
  %private.contiguous.address1729 = getelementptr i8, ptr %5036, i64 %5040
  %private.contiguous.load1730 = load <8 x float>, ptr %private.contiguous.address1729, align 4
  %5041 = select <8 x i1> %95, <8 x float> %private.contiguous.load1730, <8 x float> zeroinitializer
  %5042 = add i64 576, %4075
  %tile_snapshot.spill.load1731 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %5043 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1731, 0
  %5044 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1731, 1
  %.splatinsert1732 = insertelement <8 x i64> poison, i64 %5042, i64 0
  %.splat1733 = shufflevector <8 x i64> %.splatinsert1732, <8 x i64> poison, <8 x i32> zeroinitializer
  %5045 = mul <8 x i64> %.splat1733, splat (i64 32)
  %5046 = add <8 x i64> %5044, %5045
  %5047 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5043, 0
  %5048 = insertvalue { <8 x ptr>, <8 x i64> } %5047, <8 x i64> %5046, 1
  %5049 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %5050 = extractvalue { <8 x ptr>, <8 x i64> } %5048, 1
  %5051 = extractelement <8 x ptr> %5049, i32 0
  %5052 = extractelement <8 x i64> %5050, i32 0
  %5053 = sub i64 %5052, 0
  %5054 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5055 = select i1 %5054, i64 %5053, i64 0
  %private.contiguous.address1734 = getelementptr i8, ptr %5051, i64 %5055
  %private.contiguous.load1735 = load <8 x float>, ptr %private.contiguous.address1734, align 4
  %5056 = select <8 x i1> %95, <8 x float> %private.contiguous.load1735, <8 x float> zeroinitializer
  %5057 = fmul <8 x float> %5011, %5041
  %5058 = fadd <8 x float> %4990, %5057
  %5059 = fmul <8 x float> %5011, %5056
  %5060 = fadd <8 x float> %4992, %5059
  %5061 = fmul <8 x float> %5026, %5041
  %5062 = fadd <8 x float> %4994, %5061
  %5063 = fmul <8 x float> %5026, %5056
  %5064 = fadd <8 x float> %4996, %5063
  %5065 = add i64 %4179, 13
  %tile_snapshot.spill.load1736 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %5066 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1736, 0
  %5067 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1736, 1
  %.splatinsert1737 = insertelement <8 x i64> poison, i64 %5065, i64 0
  %.splat1738 = shufflevector <8 x i64> %.splatinsert1737, <8 x i64> poison, <8 x i32> zeroinitializer
  %5068 = mul <8 x i64> %.splat1738, splat (i64 32)
  %5069 = add <8 x i64> %5067, %5068
  %5070 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5066, 0
  %5071 = insertvalue { <8 x ptr>, <8 x i64> } %5070, <8 x i64> %5069, 1
  %5072 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %5073 = extractvalue { <8 x ptr>, <8 x i64> } %5071, 1
  %5074 = extractelement <8 x ptr> %5072, i32 0
  %5075 = extractelement <8 x i64> %5073, i32 0
  %5076 = sub i64 %5075, 0
  %5077 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5078 = select i1 %5077, i64 %5076, i64 0
  %private.contiguous.address1739 = getelementptr i8, ptr %5074, i64 %5078
  %private.contiguous.load1740 = load <8 x float>, ptr %private.contiguous.address1739, align 4
  %5079 = select <8 x i1> %95, <8 x float> %private.contiguous.load1740, <8 x float> zeroinitializer
  %5080 = add i64 %4195, 13
  %tile_snapshot.spill.load1741 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %5081 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1741, 0
  %5082 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1741, 1
  %.splatinsert1742 = insertelement <8 x i64> poison, i64 %5080, i64 0
  %.splat1743 = shufflevector <8 x i64> %.splatinsert1742, <8 x i64> poison, <8 x i32> zeroinitializer
  %5083 = mul <8 x i64> %.splat1743, splat (i64 32)
  %5084 = add <8 x i64> %5082, %5083
  %5085 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5081, 0
  %5086 = insertvalue { <8 x ptr>, <8 x i64> } %5085, <8 x i64> %5084, 1
  %5087 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %5088 = extractvalue { <8 x ptr>, <8 x i64> } %5086, 1
  %5089 = extractelement <8 x ptr> %5087, i32 0
  %5090 = extractelement <8 x i64> %5088, i32 0
  %5091 = sub i64 %5090, 0
  %5092 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5093 = select i1 %5092, i64 %5091, i64 0
  %private.contiguous.address1744 = getelementptr i8, ptr %5089, i64 %5093
  %private.contiguous.load1745 = load <8 x float>, ptr %private.contiguous.address1744, align 4
  %5094 = select <8 x i1> %95, <8 x float> %private.contiguous.load1745, <8 x float> zeroinitializer
  %5095 = add i64 624, %4040
  %tile_snapshot.spill.load1746 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %5096 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1746, 0
  %5097 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1746, 1
  %.splatinsert1747 = insertelement <8 x i64> poison, i64 %5095, i64 0
  %.splat1748 = shufflevector <8 x i64> %.splatinsert1747, <8 x i64> poison, <8 x i32> zeroinitializer
  %5098 = mul <8 x i64> %.splat1748, splat (i64 32)
  %5099 = add <8 x i64> %5097, %5098
  %5100 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5096, 0
  %5101 = insertvalue { <8 x ptr>, <8 x i64> } %5100, <8 x i64> %5099, 1
  %5102 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %5103 = extractvalue { <8 x ptr>, <8 x i64> } %5101, 1
  %5104 = extractelement <8 x ptr> %5102, i32 0
  %5105 = extractelement <8 x i64> %5103, i32 0
  %5106 = sub i64 %5105, 0
  %5107 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5108 = select i1 %5107, i64 %5106, i64 0
  %private.contiguous.address1749 = getelementptr i8, ptr %5104, i64 %5108
  %private.contiguous.load1750 = load <8 x float>, ptr %private.contiguous.address1749, align 4
  %5109 = select <8 x i1> %95, <8 x float> %private.contiguous.load1750, <8 x float> zeroinitializer
  %5110 = add i64 624, %4075
  %tile_snapshot.spill.load1751 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %5111 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1751, 0
  %5112 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1751, 1
  %.splatinsert1752 = insertelement <8 x i64> poison, i64 %5110, i64 0
  %.splat1753 = shufflevector <8 x i64> %.splatinsert1752, <8 x i64> poison, <8 x i32> zeroinitializer
  %5113 = mul <8 x i64> %.splat1753, splat (i64 32)
  %5114 = add <8 x i64> %5112, %5113
  %5115 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5111, 0
  %5116 = insertvalue { <8 x ptr>, <8 x i64> } %5115, <8 x i64> %5114, 1
  %5117 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %5118 = extractvalue { <8 x ptr>, <8 x i64> } %5116, 1
  %5119 = extractelement <8 x ptr> %5117, i32 0
  %5120 = extractelement <8 x i64> %5118, i32 0
  %5121 = sub i64 %5120, 0
  %5122 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5123 = select i1 %5122, i64 %5121, i64 0
  %private.contiguous.address1754 = getelementptr i8, ptr %5119, i64 %5123
  %private.contiguous.load1755 = load <8 x float>, ptr %private.contiguous.address1754, align 4
  %5124 = select <8 x i1> %95, <8 x float> %private.contiguous.load1755, <8 x float> zeroinitializer
  %5125 = fmul <8 x float> %5079, %5109
  %5126 = fadd <8 x float> %5058, %5125
  %5127 = fmul <8 x float> %5079, %5124
  %5128 = fadd <8 x float> %5060, %5127
  %5129 = fmul <8 x float> %5094, %5109
  %5130 = fadd <8 x float> %5062, %5129
  %5131 = fmul <8 x float> %5094, %5124
  %5132 = fadd <8 x float> %5064, %5131
  %5133 = add i64 %4179, 14
  %tile_snapshot.spill.load1756 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %5134 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1756, 0
  %5135 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1756, 1
  %.splatinsert1757 = insertelement <8 x i64> poison, i64 %5133, i64 0
  %.splat1758 = shufflevector <8 x i64> %.splatinsert1757, <8 x i64> poison, <8 x i32> zeroinitializer
  %5136 = mul <8 x i64> %.splat1758, splat (i64 32)
  %5137 = add <8 x i64> %5135, %5136
  %5138 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5134, 0
  %5139 = insertvalue { <8 x ptr>, <8 x i64> } %5138, <8 x i64> %5137, 1
  %5140 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %5141 = extractvalue { <8 x ptr>, <8 x i64> } %5139, 1
  %5142 = extractelement <8 x ptr> %5140, i32 0
  %5143 = extractelement <8 x i64> %5141, i32 0
  %5144 = sub i64 %5143, 0
  %5145 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5146 = select i1 %5145, i64 %5144, i64 0
  %private.contiguous.address1759 = getelementptr i8, ptr %5142, i64 %5146
  %private.contiguous.load1760 = load <8 x float>, ptr %private.contiguous.address1759, align 4
  %5147 = select <8 x i1> %95, <8 x float> %private.contiguous.load1760, <8 x float> zeroinitializer
  %5148 = add i64 %4195, 14
  %tile_snapshot.spill.load1761 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %5149 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1761, 0
  %5150 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1761, 1
  %.splatinsert1762 = insertelement <8 x i64> poison, i64 %5148, i64 0
  %.splat1763 = shufflevector <8 x i64> %.splatinsert1762, <8 x i64> poison, <8 x i32> zeroinitializer
  %5151 = mul <8 x i64> %.splat1763, splat (i64 32)
  %5152 = add <8 x i64> %5150, %5151
  %5153 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5149, 0
  %5154 = insertvalue { <8 x ptr>, <8 x i64> } %5153, <8 x i64> %5152, 1
  %5155 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %5156 = extractvalue { <8 x ptr>, <8 x i64> } %5154, 1
  %5157 = extractelement <8 x ptr> %5155, i32 0
  %5158 = extractelement <8 x i64> %5156, i32 0
  %5159 = sub i64 %5158, 0
  %5160 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5161 = select i1 %5160, i64 %5159, i64 0
  %private.contiguous.address1764 = getelementptr i8, ptr %5157, i64 %5161
  %private.contiguous.load1765 = load <8 x float>, ptr %private.contiguous.address1764, align 4
  %5162 = select <8 x i1> %95, <8 x float> %private.contiguous.load1765, <8 x float> zeroinitializer
  %5163 = add i64 672, %4040
  %tile_snapshot.spill.load1766 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %5164 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1766, 0
  %5165 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1766, 1
  %.splatinsert1767 = insertelement <8 x i64> poison, i64 %5163, i64 0
  %.splat1768 = shufflevector <8 x i64> %.splatinsert1767, <8 x i64> poison, <8 x i32> zeroinitializer
  %5166 = mul <8 x i64> %.splat1768, splat (i64 32)
  %5167 = add <8 x i64> %5165, %5166
  %5168 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5164, 0
  %5169 = insertvalue { <8 x ptr>, <8 x i64> } %5168, <8 x i64> %5167, 1
  %5170 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %5171 = extractvalue { <8 x ptr>, <8 x i64> } %5169, 1
  %5172 = extractelement <8 x ptr> %5170, i32 0
  %5173 = extractelement <8 x i64> %5171, i32 0
  %5174 = sub i64 %5173, 0
  %5175 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5176 = select i1 %5175, i64 %5174, i64 0
  %private.contiguous.address1769 = getelementptr i8, ptr %5172, i64 %5176
  %private.contiguous.load1770 = load <8 x float>, ptr %private.contiguous.address1769, align 4
  %5177 = select <8 x i1> %95, <8 x float> %private.contiguous.load1770, <8 x float> zeroinitializer
  %5178 = add i64 672, %4075
  %tile_snapshot.spill.load1771 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %5179 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1771, 0
  %5180 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1771, 1
  %.splatinsert1772 = insertelement <8 x i64> poison, i64 %5178, i64 0
  %.splat1773 = shufflevector <8 x i64> %.splatinsert1772, <8 x i64> poison, <8 x i32> zeroinitializer
  %5181 = mul <8 x i64> %.splat1773, splat (i64 32)
  %5182 = add <8 x i64> %5180, %5181
  %5183 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5179, 0
  %5184 = insertvalue { <8 x ptr>, <8 x i64> } %5183, <8 x i64> %5182, 1
  %5185 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %5186 = extractvalue { <8 x ptr>, <8 x i64> } %5184, 1
  %5187 = extractelement <8 x ptr> %5185, i32 0
  %5188 = extractelement <8 x i64> %5186, i32 0
  %5189 = sub i64 %5188, 0
  %5190 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5191 = select i1 %5190, i64 %5189, i64 0
  %private.contiguous.address1774 = getelementptr i8, ptr %5187, i64 %5191
  %private.contiguous.load1775 = load <8 x float>, ptr %private.contiguous.address1774, align 4
  %5192 = select <8 x i1> %95, <8 x float> %private.contiguous.load1775, <8 x float> zeroinitializer
  %5193 = fmul <8 x float> %5147, %5177
  %5194 = fadd <8 x float> %5126, %5193
  %5195 = fmul <8 x float> %5147, %5192
  %5196 = fadd <8 x float> %5128, %5195
  %5197 = fmul <8 x float> %5162, %5177
  %5198 = fadd <8 x float> %5130, %5197
  %5199 = fmul <8 x float> %5162, %5192
  %5200 = fadd <8 x float> %5132, %5199
  %5201 = add i64 %4179, 15
  %tile_snapshot.spill.load1776 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %5202 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1776, 0
  %5203 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1776, 1
  %.splatinsert1777 = insertelement <8 x i64> poison, i64 %5201, i64 0
  %.splat1778 = shufflevector <8 x i64> %.splatinsert1777, <8 x i64> poison, <8 x i32> zeroinitializer
  %5204 = mul <8 x i64> %.splat1778, splat (i64 32)
  %5205 = add <8 x i64> %5203, %5204
  %5206 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5202, 0
  %5207 = insertvalue { <8 x ptr>, <8 x i64> } %5206, <8 x i64> %5205, 1
  %5208 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %5209 = extractvalue { <8 x ptr>, <8 x i64> } %5207, 1
  %5210 = extractelement <8 x ptr> %5208, i32 0
  %5211 = extractelement <8 x i64> %5209, i32 0
  %5212 = sub i64 %5211, 0
  %5213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5214 = select i1 %5213, i64 %5212, i64 0
  %private.contiguous.address1779 = getelementptr i8, ptr %5210, i64 %5214
  %private.contiguous.load1780 = load <8 x float>, ptr %private.contiguous.address1779, align 4
  %5215 = select <8 x i1> %95, <8 x float> %private.contiguous.load1780, <8 x float> zeroinitializer
  %5216 = add i64 %4195, 15
  %tile_snapshot.spill.load1781 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %5217 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1781, 0
  %5218 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1781, 1
  %.splatinsert1782 = insertelement <8 x i64> poison, i64 %5216, i64 0
  %.splat1783 = shufflevector <8 x i64> %.splatinsert1782, <8 x i64> poison, <8 x i32> zeroinitializer
  %5219 = mul <8 x i64> %.splat1783, splat (i64 32)
  %5220 = add <8 x i64> %5218, %5219
  %5221 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5217, 0
  %5222 = insertvalue { <8 x ptr>, <8 x i64> } %5221, <8 x i64> %5220, 1
  %5223 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %5224 = extractvalue { <8 x ptr>, <8 x i64> } %5222, 1
  %5225 = extractelement <8 x ptr> %5223, i32 0
  %5226 = extractelement <8 x i64> %5224, i32 0
  %5227 = sub i64 %5226, 0
  %5228 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5229 = select i1 %5228, i64 %5227, i64 0
  %private.contiguous.address1784 = getelementptr i8, ptr %5225, i64 %5229
  %private.contiguous.load1785 = load <8 x float>, ptr %private.contiguous.address1784, align 4
  %5230 = select <8 x i1> %95, <8 x float> %private.contiguous.load1785, <8 x float> zeroinitializer
  %5231 = add i64 720, %4040
  %tile_snapshot.spill.load1786 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %5232 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1786, 0
  %5233 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1786, 1
  %.splatinsert1787 = insertelement <8 x i64> poison, i64 %5231, i64 0
  %.splat1788 = shufflevector <8 x i64> %.splatinsert1787, <8 x i64> poison, <8 x i32> zeroinitializer
  %5234 = mul <8 x i64> %.splat1788, splat (i64 32)
  %5235 = add <8 x i64> %5233, %5234
  %5236 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5232, 0
  %5237 = insertvalue { <8 x ptr>, <8 x i64> } %5236, <8 x i64> %5235, 1
  %5238 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %5239 = extractvalue { <8 x ptr>, <8 x i64> } %5237, 1
  %5240 = extractelement <8 x ptr> %5238, i32 0
  %5241 = extractelement <8 x i64> %5239, i32 0
  %5242 = sub i64 %5241, 0
  %5243 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5244 = select i1 %5243, i64 %5242, i64 0
  %private.contiguous.address1789 = getelementptr i8, ptr %5240, i64 %5244
  %private.contiguous.load1790 = load <8 x float>, ptr %private.contiguous.address1789, align 4
  %5245 = select <8 x i1> %95, <8 x float> %private.contiguous.load1790, <8 x float> zeroinitializer
  %5246 = add i64 720, %4075
  %tile_snapshot.spill.load1791 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %5247 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1791, 0
  %5248 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1791, 1
  %.splatinsert1792 = insertelement <8 x i64> poison, i64 %5246, i64 0
  %.splat1793 = shufflevector <8 x i64> %.splatinsert1792, <8 x i64> poison, <8 x i32> zeroinitializer
  %5249 = mul <8 x i64> %.splat1793, splat (i64 32)
  %5250 = add <8 x i64> %5248, %5249
  %5251 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5247, 0
  %5252 = insertvalue { <8 x ptr>, <8 x i64> } %5251, <8 x i64> %5250, 1
  %5253 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %5254 = extractvalue { <8 x ptr>, <8 x i64> } %5252, 1
  %5255 = extractelement <8 x ptr> %5253, i32 0
  %5256 = extractelement <8 x i64> %5254, i32 0
  %5257 = sub i64 %5256, 0
  %5258 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5259 = select i1 %5258, i64 %5257, i64 0
  %private.contiguous.address1794 = getelementptr i8, ptr %5255, i64 %5259
  %private.contiguous.load1795 = load <8 x float>, ptr %private.contiguous.address1794, align 4
  %5260 = select <8 x i1> %95, <8 x float> %private.contiguous.load1795, <8 x float> zeroinitializer
  %5261 = fmul <8 x float> %5215, %5245
  %5262 = fadd <8 x float> %5194, %5261
  %5263 = fmul <8 x float> %5215, %5260
  %5264 = fadd <8 x float> %5196, %5263
  %5265 = fmul <8 x float> %5230, %5245
  %5266 = fadd <8 x float> %5198, %5265
  %5267 = fmul <8 x float> %5230, %5260
  %5268 = fadd <8 x float> %5200, %5267
  %tile_snapshot.spill.load1796 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill167, align 64
  %5269 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1796, 0
  %5270 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1796, 1
  %.splatinsert1797 = insertelement <8 x i64> poison, i64 %4039, i64 0
  %.splat1798 = shufflevector <8 x i64> %.splatinsert1797, <8 x i64> poison, <8 x i32> zeroinitializer
  %5271 = mul <8 x i64> %.splat1798, splat (i64 32)
  %5272 = add <8 x i64> %5270, %5271
  %5273 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5269, 0
  %5274 = insertvalue { <8 x ptr>, <8 x i64> } %5273, <8 x i64> %5272, 1
  %5275 = extractvalue { <8 x ptr>, <8 x i64> } %44, 0
  %5276 = extractvalue { <8 x ptr>, <8 x i64> } %5274, 1
  %5277 = extractelement <8 x ptr> %5275, i32 0
  %5278 = extractelement <8 x i64> %5276, i32 0
  %5279 = sub i64 %5278, 0
  %5280 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5281 = select i1 %5280, i64 %5279, i64 0
  %private.contiguous.address1799 = getelementptr i8, ptr %5277, i64 %5281
  %private.contiguous.preserve1800 = load <8 x float>, ptr %private.contiguous.address1799, align 4
  %5282 = select <8 x i1> %95, <8 x float> %5262, <8 x float> %private.contiguous.preserve1800
  store <8 x float> %5282, ptr %private.contiguous.address1799, align 4
  %tile_snapshot.spill.load1801 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill167, align 64
  %5283 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1801, 0
  %5284 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1801, 1
  %.splatinsert1802 = insertelement <8 x i64> poison, i64 %4074, i64 0
  %.splat1803 = shufflevector <8 x i64> %.splatinsert1802, <8 x i64> poison, <8 x i32> zeroinitializer
  %5285 = mul <8 x i64> %.splat1803, splat (i64 32)
  %5286 = add <8 x i64> %5284, %5285
  %5287 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5283, 0
  %5288 = insertvalue { <8 x ptr>, <8 x i64> } %5287, <8 x i64> %5286, 1
  %5289 = extractvalue { <8 x ptr>, <8 x i64> } %44, 0
  %5290 = extractvalue { <8 x ptr>, <8 x i64> } %5288, 1
  %5291 = extractelement <8 x ptr> %5289, i32 0
  %5292 = extractelement <8 x i64> %5290, i32 0
  %5293 = sub i64 %5292, 0
  %5294 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5295 = select i1 %5294, i64 %5293, i64 0
  %private.contiguous.address1804 = getelementptr i8, ptr %5291, i64 %5295
  %private.contiguous.preserve1805 = load <8 x float>, ptr %private.contiguous.address1804, align 4
  %5296 = select <8 x i1> %95, <8 x float> %5264, <8 x float> %private.contiguous.preserve1805
  store <8 x float> %5296, ptr %private.contiguous.address1804, align 4
  %tile_snapshot.spill.load1806 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill167, align 64
  %5297 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1806, 0
  %5298 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1806, 1
  %.splatinsert1807 = insertelement <8 x i64> poison, i64 %4109, i64 0
  %.splat1808 = shufflevector <8 x i64> %.splatinsert1807, <8 x i64> poison, <8 x i32> zeroinitializer
  %5299 = mul <8 x i64> %.splat1808, splat (i64 32)
  %5300 = add <8 x i64> %5298, %5299
  %5301 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5297, 0
  %5302 = insertvalue { <8 x ptr>, <8 x i64> } %5301, <8 x i64> %5300, 1
  %5303 = extractvalue { <8 x ptr>, <8 x i64> } %44, 0
  %5304 = extractvalue { <8 x ptr>, <8 x i64> } %5302, 1
  %5305 = extractelement <8 x ptr> %5303, i32 0
  %5306 = extractelement <8 x i64> %5304, i32 0
  %5307 = sub i64 %5306, 0
  %5308 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5309 = select i1 %5308, i64 %5307, i64 0
  %private.contiguous.address1809 = getelementptr i8, ptr %5305, i64 %5309
  %private.contiguous.preserve1810 = load <8 x float>, ptr %private.contiguous.address1809, align 4
  %5310 = select <8 x i1> %95, <8 x float> %5266, <8 x float> %private.contiguous.preserve1810
  store <8 x float> %5310, ptr %private.contiguous.address1809, align 4
  %tile_snapshot.spill.load1811 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill167, align 64
  %5311 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1811, 0
  %5312 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1811, 1
  %.splatinsert1812 = insertelement <8 x i64> poison, i64 %4144, i64 0
  %.splat1813 = shufflevector <8 x i64> %.splatinsert1812, <8 x i64> poison, <8 x i32> zeroinitializer
  %5313 = mul <8 x i64> %.splat1813, splat (i64 32)
  %5314 = add <8 x i64> %5312, %5313
  %5315 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5311, 0
  %5316 = insertvalue { <8 x ptr>, <8 x i64> } %5315, <8 x i64> %5314, 1
  %5317 = extractvalue { <8 x ptr>, <8 x i64> } %44, 0
  %5318 = extractvalue { <8 x ptr>, <8 x i64> } %5316, 1
  %5319 = extractelement <8 x ptr> %5317, i32 0
  %5320 = extractelement <8 x i64> %5318, i32 0
  %5321 = sub i64 %5320, 0
  %5322 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5323 = select i1 %5322, i64 %5321, i64 0
  %private.contiguous.address1814 = getelementptr i8, ptr %5319, i64 %5323
  %private.contiguous.preserve1815 = load <8 x float>, ptr %private.contiguous.address1814, align 4
  %5324 = select <8 x i1> %95, <8 x float> %5268, <8 x float> %private.contiguous.preserve1815
  store <8 x float> %5324, ptr %private.contiguous.address1814, align 4
  %.state1816 = load i64, ptr %.slot170, align 4
  %5325 = add i64 %.state1816, 1
  store i64 %5325, ptr %.slot170, align 4
  br label %direct.schedule.75

direct.schedule.77:                               ; preds = %direct.false1433
  %.state1817 = load i64, ptr %.slot168, align 4
  %5326 = add i64 %.state1817, 1
  store i64 %5326, ptr %.slot168, align 4
  br label %direct.schedule.73

direct.schedule.78:                               ; preds = %direct.false1429
  store i64 0, ptr %.slot171, align 4
  br label %direct.schedule.79

direct.schedule.79:                               ; preds = %direct.schedule.80, %direct.schedule.78
  %.state1818 = load i64, ptr %.slot171, align 4
  %5327 = icmp slt i64 %.state1818, 384
  br i1 %5327, label %direct.true1819, label %direct.false1820

direct.schedule.80:                               ; preds = %direct.true1819
  %tile_snapshot.spill.load1821 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill167, align 64
  %5328 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1821, 0
  %5329 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1821, 1
  %.state1822 = load i64, ptr %.slot171, align 4
  %.splatinsert1823 = insertelement <8 x i64> poison, i64 %.state1822, i64 0
  %.splat1824 = shufflevector <8 x i64> %.splatinsert1823, <8 x i64> poison, <8 x i32> zeroinitializer
  %5330 = mul <8 x i64> %.splat1824, splat (i64 32)
  %5331 = add <8 x i64> %5329, %5330
  %5332 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5328, 0
  %5333 = insertvalue { <8 x ptr>, <8 x i64> } %5332, <8 x i64> %5331, 1
  %5334 = extractvalue { <8 x ptr>, <8 x i64> } %44, 0
  %5335 = extractvalue { <8 x ptr>, <8 x i64> } %5333, 1
  %5336 = extractelement <8 x ptr> %5334, i32 0
  %5337 = extractelement <8 x i64> %5335, i32 0
  %5338 = sub i64 %5337, 0
  %5339 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5340 = select i1 %5339, i64 %5338, i64 0
  %private.contiguous.address1825 = getelementptr i8, ptr %5336, i64 %5340
  %private.contiguous.load1826 = load <8 x float>, ptr %private.contiguous.address1825, align 4
  %5341 = select <8 x i1> %95, <8 x float> %private.contiguous.load1826, <8 x float> zeroinitializer
  %tile_snapshot.spill.load1827 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill66, align 64
  %5342 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1827, 0
  %5343 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1827, 1
  %.state1828 = load i64, ptr %.slot171, align 4
  %.splatinsert1829 = insertelement <8 x i64> poison, i64 %.state1828, i64 0
  %.splat1830 = shufflevector <8 x i64> %.splatinsert1829, <8 x i64> poison, <8 x i32> zeroinitializer
  %5344 = mul <8 x i64> %.splat1830, splat (i64 32)
  %5345 = add <8 x i64> %5343, %5344
  %5346 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5342, 0
  %5347 = insertvalue { <8 x ptr>, <8 x i64> } %5346, <8 x i64> %5345, 1
  %5348 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %5349 = extractvalue { <8 x ptr>, <8 x i64> } %5347, 1
  %5350 = extractelement <8 x ptr> %5348, i32 0
  %5351 = extractelement <8 x i64> %5349, i32 0
  %5352 = sub i64 %5351, 0
  %5353 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5354 = select i1 %5353, i64 %5352, i64 0
  %private.contiguous.address1831 = getelementptr i8, ptr %5350, i64 %5354
  %private.contiguous.preserve1832 = load <8 x float>, ptr %private.contiguous.address1831, align 4
  %5355 = select <8 x i1> %95, <8 x float> %5341, <8 x float> %private.contiguous.preserve1832
  store <8 x float> %5355, ptr %private.contiguous.address1831, align 4
  %.state1833 = load i64, ptr %.slot171, align 4
  %5356 = add i64 %.state1833, 1
  store i64 %5356, ptr %.slot171, align 4
  br label %direct.schedule.79

direct.schedule.81:                               ; preds = %direct.false1820
  store i64 0, ptr %.slot172, align 4
  br label %direct.schedule.82

direct.schedule.82:                               ; preds = %direct.schedule.83, %direct.schedule.81
  %.state1834 = load i64, ptr %.slot172, align 4
  %5357 = icmp slt i64 %.state1834, 384
  br i1 %5357, label %direct.true1835, label %direct.false1836

direct.schedule.83:                               ; preds = %direct.true1835
  %tile_snapshot.spill.load1837 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill66, align 64
  %5358 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1837, 0
  %5359 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1837, 1
  %.state1838 = load i64, ptr %.slot172, align 4
  %.splatinsert1839 = insertelement <8 x i64> poison, i64 %.state1838, i64 0
  %.splat1840 = shufflevector <8 x i64> %.splatinsert1839, <8 x i64> poison, <8 x i32> zeroinitializer
  %5360 = mul <8 x i64> %.splat1840, splat (i64 32)
  %5361 = add <8 x i64> %5359, %5360
  %5362 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5358, 0
  %5363 = insertvalue { <8 x ptr>, <8 x i64> } %5362, <8 x i64> %5361, 1
  %5364 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %5365 = extractvalue { <8 x ptr>, <8 x i64> } %5363, 1
  %5366 = extractelement <8 x ptr> %5364, i32 0
  %5367 = extractelement <8 x i64> %5365, i32 0
  %5368 = sub i64 %5367, 0
  %5369 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5370 = select i1 %5369, i64 %5368, i64 0
  %private.contiguous.address1841 = getelementptr i8, ptr %5366, i64 %5370
  %private.contiguous.load1842 = load <8 x float>, ptr %private.contiguous.address1841, align 4
  %5371 = select <8 x i1> %95, <8 x float> %private.contiguous.load1842, <8 x float> zeroinitializer
  %tile_snapshot.spill.load1843 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %5372 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1843, 0
  %5373 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1843, 1
  %.state1844 = load i64, ptr %.slot172, align 4
  %.splatinsert1845 = insertelement <8 x i64> poison, i64 %.state1844, i64 0
  %.splat1846 = shufflevector <8 x i64> %.splatinsert1845, <8 x i64> poison, <8 x i32> zeroinitializer
  %5374 = mul <8 x i64> %.splat1846, splat (i64 32)
  %5375 = add <8 x i64> %5373, %5374
  %5376 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5372, 0
  %5377 = insertvalue { <8 x ptr>, <8 x i64> } %5376, <8 x i64> %5375, 1
  %5378 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %5379 = extractvalue { <8 x ptr>, <8 x i64> } %5377, 1
  %5380 = extractelement <8 x ptr> %5378, i32 0
  %5381 = extractelement <8 x i64> %5379, i32 0
  %5382 = sub i64 %5381, 0
  %5383 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5384 = select i1 %5383, i64 %5382, i64 0
  %private.contiguous.address1847 = getelementptr i8, ptr %5380, i64 %5384
  %private.contiguous.preserve1848 = load <8 x float>, ptr %private.contiguous.address1847, align 4
  %5385 = select <8 x i1> %95, <8 x float> %5371, <8 x float> %private.contiguous.preserve1848
  store <8 x float> %5385, ptr %private.contiguous.address1847, align 4
  %.state1849 = load i64, ptr %.slot172, align 4
  %5386 = add i64 %.state1849, 1
  store i64 %5386, ptr %.slot172, align 4
  br label %direct.schedule.82

direct.schedule.84:                               ; preds = %direct.false1836
  %.state1850 = load i64, ptr %.slot67, align 4
  %5387 = add i64 %.state1850, 1
  %.spill.load1851 = load <8 x float>, ptr %.spill115, align 32
  %.spill.load1852 = load <8 x float>, ptr %.spill116, align 32
  %.spill.load1853 = load <8 x float>, ptr %.spill117, align 32
  %.spill.load1854 = load <8 x float>, ptr %.spill118, align 32
  %.spill.load1855 = load <8 x float>, ptr %.spill119, align 32
  %.spill.load1856 = load <8 x float>, ptr %.spill120, align 32
  %.spill.load1857 = load <8 x float>, ptr %.spill121, align 32
  %.spill.load1858 = load <8 x float>, ptr %.spill122, align 32
  %.spill.load1859 = load <8 x float>, ptr %.spill159, align 32
  %.spill.load1860 = load <8 x float>, ptr %.spill160, align 32
  %.spill.load1861 = load <8 x float>, ptr %.spill161, align 32
  %.spill.load1862 = load <8 x float>, ptr %.spill162, align 32
  %.spill.load1863 = load <8 x float>, ptr %.spill163, align 32
  %.spill.load1864 = load <8 x float>, ptr %.spill164, align 32
  %.spill.load1865 = load <8 x float>, ptr %.spill165, align 32
  %.spill.load1866 = load <8 x float>, ptr %.spill166, align 32
  store i64 %5387, ptr %.slot67, align 4
  %5388 = load <8 x float>, ptr %.slot68, align 32
  %5389 = select <8 x i1> %95, <8 x float> %.spill.load1851, <8 x float> %5388
  store <8 x float> %5389, ptr %.slot68, align 32
  %5390 = load <8 x float>, ptr %.slot69, align 32
  %5391 = select <8 x i1> %95, <8 x float> %.spill.load1852, <8 x float> %5390
  store <8 x float> %5391, ptr %.slot69, align 32
  %5392 = load <8 x float>, ptr %.slot70, align 32
  %5393 = select <8 x i1> %95, <8 x float> %.spill.load1853, <8 x float> %5392
  store <8 x float> %5393, ptr %.slot70, align 32
  %5394 = load <8 x float>, ptr %.slot71, align 32
  %5395 = select <8 x i1> %95, <8 x float> %.spill.load1854, <8 x float> %5394
  store <8 x float> %5395, ptr %.slot71, align 32
  %5396 = load <8 x float>, ptr %.slot72, align 32
  %5397 = select <8 x i1> %95, <8 x float> %.spill.load1855, <8 x float> %5396
  store <8 x float> %5397, ptr %.slot72, align 32
  %5398 = load <8 x float>, ptr %.slot73, align 32
  %5399 = select <8 x i1> %95, <8 x float> %.spill.load1856, <8 x float> %5398
  store <8 x float> %5399, ptr %.slot73, align 32
  %5400 = load <8 x float>, ptr %.slot74, align 32
  %5401 = select <8 x i1> %95, <8 x float> %.spill.load1857, <8 x float> %5400
  store <8 x float> %5401, ptr %.slot74, align 32
  %5402 = load <8 x float>, ptr %.slot75, align 32
  %5403 = select <8 x i1> %95, <8 x float> %.spill.load1858, <8 x float> %5402
  store <8 x float> %5403, ptr %.slot75, align 32
  %5404 = load <8 x float>, ptr %.slot76, align 32
  %5405 = select <8 x i1> %95, <8 x float> %.spill.load1859, <8 x float> %5404
  store <8 x float> %5405, ptr %.slot76, align 32
  %5406 = load <8 x float>, ptr %.slot77, align 32
  %5407 = select <8 x i1> %95, <8 x float> %.spill.load1860, <8 x float> %5406
  store <8 x float> %5407, ptr %.slot77, align 32
  %5408 = load <8 x float>, ptr %.slot78, align 32
  %5409 = select <8 x i1> %95, <8 x float> %.spill.load1861, <8 x float> %5408
  store <8 x float> %5409, ptr %.slot78, align 32
  %5410 = load <8 x float>, ptr %.slot79, align 32
  %5411 = select <8 x i1> %95, <8 x float> %.spill.load1862, <8 x float> %5410
  store <8 x float> %5411, ptr %.slot79, align 32
  %5412 = load <8 x float>, ptr %.slot80, align 32
  %5413 = select <8 x i1> %95, <8 x float> %.spill.load1863, <8 x float> %5412
  store <8 x float> %5413, ptr %.slot80, align 32
  %5414 = load <8 x float>, ptr %.slot81, align 32
  %5415 = select <8 x i1> %95, <8 x float> %.spill.load1864, <8 x float> %5414
  store <8 x float> %5415, ptr %.slot81, align 32
  %5416 = load <8 x float>, ptr %.slot82, align 32
  %5417 = select <8 x i1> %95, <8 x float> %.spill.load1865, <8 x float> %5416
  store <8 x float> %5417, ptr %.slot82, align 32
  %5418 = load <8 x float>, ptr %.slot83, align 32
  %5419 = select <8 x i1> %95, <8 x float> %.spill.load1866, <8 x float> %5418
  store <8 x float> %5419, ptr %.slot83, align 32
  br label %direct.schedule.4

direct.schedule.85:                               ; preds = %direct.false240
  store i64 0, ptr %.slot173, align 4
  br label %direct.schedule.86

direct.schedule.86:                               ; preds = %direct.schedule.89, %direct.schedule.85
  %.state1867 = load i64, ptr %.slot173, align 4
  %5420 = icmp slt i64 %.state1867, 768
  br i1 %5420, label %direct.true1868, label %direct.false1869

direct.schedule.87:                               ; preds = %direct.true1868
  %.state1870 = load i64, ptr %.slot173, align 4
  %5421 = srem i64 %.state1870, 48
  %.state1871 = load i64, ptr %.slot173, align 4
  %5422 = sdiv i64 %.state1871, 48
  %.spill.load1872 = load i64, ptr %.spill63, align 4
  %5423 = add i64 %.spill.load1872, 0
  %.spill.load1873 = load <8 x i64>, ptr %.spill62, align 64
  %5424 = add <8 x i64> %.spill.load1873, zeroinitializer
  %5425 = mul i64 %5423, 2
  %.splatinsert1874 = insertelement <8 x i64> poison, i64 %5425, i64 0
  %.splat1875 = shufflevector <8 x i64> %.splatinsert1874, <8 x i64> poison, <8 x i32> zeroinitializer
  %5426 = add <8 x i64> %.splat1875, %5424
  %.spill.load1876 = load i64, ptr %.spill84, align 4
  %5427 = add i64 %.spill.load1876, %5422
  %5428 = mul <8 x i64> %5426, splat (i64 129)
  %.splatinsert1877 = insertelement <8 x i64> poison, i64 %5427, i64 0
  %.splat1878 = shufflevector <8 x i64> %.splatinsert1877, <8 x i64> poison, <8 x i32> zeroinitializer
  %5429 = add <8 x i64> %5428, %.splat1878
  %5430 = icmp sge i64 %5427, 0
  %5431 = and i1 true, %5430
  %5432 = icmp slt i64 %5427, 129
  %5433 = and i1 %5431, %5432
  %5434 = add i64 0, %5421
  %5435 = mul <8 x i64> %5429, splat (i64 48)
  %.splatinsert1879 = insertelement <8 x i64> poison, i64 %5434, i64 0
  %.splat1880 = shufflevector <8 x i64> %.splatinsert1879, <8 x i64> poison, <8 x i32> zeroinitializer
  %5436 = add <8 x i64> %5435, %.splat1880
  %5437 = load <8 x i64>, ptr %.spill174, align 64
  %5438 = select <8 x i1> %95, <8 x i64> %5436, <8 x i64> %5437
  store <8 x i64> %5438, ptr %.spill174, align 64
  br i1 %5433, label %direct.true1881, label %direct.false1882

direct.schedule.88:                               ; preds = %direct.true1881
  %.spill.load1883 = load <8 x i64>, ptr %.spill174, align 64
  %5439 = extractvalue { ptr, i64 } %65, 0
  %5440 = extractelement <8 x i64> %.spill.load1883, i32 0
  %5441 = mul i64 %5440, 4
  %5442 = getelementptr i8, ptr %5439, i64 %5441
  %5443 = load float, ptr %5442, align 4
  %.splatinsert1884 = insertelement <8 x float> poison, float %5443, i64 0
  %.splat1885 = shufflevector <8 x float> %.splatinsert1884, <8 x float> poison, <8 x i32> zeroinitializer
  %5444 = load <8 x float>, ptr %.slot175, align 32
  %5445 = select <8 x i1> %95, <8 x float> %.splat1885, <8 x float> %5444
  store <8 x float> %5445, ptr %.slot175, align 32
  br label %direct.schedule.89

direct.schedule.89:                               ; preds = %direct.schedule.88, %direct.false1882
  %tile_snapshot.spill.load1886 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %5446 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1886, 0
  %5447 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1886, 1
  %.state1887 = load i64, ptr %.slot173, align 4
  %.splatinsert1888 = insertelement <8 x i64> poison, i64 %.state1887, i64 0
  %.splat1889 = shufflevector <8 x i64> %.splatinsert1888, <8 x i64> poison, <8 x i32> zeroinitializer
  %5448 = mul <8 x i64> %.splat1889, splat (i64 32)
  %5449 = add <8 x i64> %5447, %5448
  %5450 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5446, 0
  %5451 = insertvalue { <8 x ptr>, <8 x i64> } %5450, <8 x i64> %5449, 1
  %.state1890 = load <8 x float>, ptr %.slot175, align 32
  %5452 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %5453 = extractvalue { <8 x ptr>, <8 x i64> } %5451, 1
  %5454 = extractelement <8 x ptr> %5452, i32 0
  %5455 = extractelement <8 x i64> %5453, i32 0
  %5456 = sub i64 %5455, 0
  %5457 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5458 = select i1 %5457, i64 %5456, i64 0
  %private.contiguous.address1891 = getelementptr i8, ptr %5454, i64 %5458
  %private.contiguous.preserve1892 = load <8 x float>, ptr %private.contiguous.address1891, align 4
  %5459 = select <8 x i1> %95, <8 x float> %.state1890, <8 x float> %private.contiguous.preserve1892
  store <8 x float> %5459, ptr %private.contiguous.address1891, align 4
  %.state1893 = load i64, ptr %.slot173, align 4
  %5460 = add i64 %.state1893, 1
  store i64 %5460, ptr %.slot173, align 4
  br label %direct.schedule.86

direct.schedule.90:                               ; preds = %direct.false214
  store i64 0, ptr %.slot176, align 4
  br label %direct.schedule.91

direct.schedule.91:                               ; preds = %direct.schedule.94, %direct.schedule.90
  %.state1894 = load i64, ptr %.slot176, align 4
  %5461 = icmp slt i64 %.state1894, 512
  br i1 %5461, label %direct.true1895, label %direct.false1896

direct.schedule.92:                               ; preds = %direct.true1895
  %.state1897 = load i64, ptr %.slot176, align 4
  %5462 = srem i64 %.state1897, 32
  %.state1898 = load i64, ptr %.slot176, align 4
  %5463 = sdiv i64 %.state1898, 32
  %.spill.load1899 = load i64, ptr %.spill63, align 4
  %5464 = add i64 %.spill.load1899, 0
  %.spill.load1900 = load <8 x i64>, ptr %.spill62, align 64
  %5465 = add <8 x i64> %.spill.load1900, zeroinitializer
  %5466 = mul i64 %5464, 2
  %.splatinsert1901 = insertelement <8 x i64> poison, i64 %5466, i64 0
  %.splat1902 = shufflevector <8 x i64> %.splatinsert1901, <8 x i64> poison, <8 x i32> zeroinitializer
  %5467 = add <8 x i64> %.splat1902, %5465
  %.spill.load1903 = load i64, ptr %.spill84, align 4
  %5468 = add i64 %.spill.load1903, %5463
  %5469 = mul <8 x i64> %5467, splat (i64 129)
  %.splatinsert1904 = insertelement <8 x i64> poison, i64 %5468, i64 0
  %.splat1905 = shufflevector <8 x i64> %.splatinsert1904, <8 x i64> poison, <8 x i32> zeroinitializer
  %5470 = add <8 x i64> %5469, %.splat1905
  %5471 = icmp sge i64 %5468, 0
  %5472 = and i1 true, %5471
  %5473 = icmp slt i64 %5468, 129
  %5474 = and i1 %5472, %5473
  %5475 = add i64 0, %5462
  %5476 = mul <8 x i64> %5470, splat (i64 32)
  %.splatinsert1906 = insertelement <8 x i64> poison, i64 %5475, i64 0
  %.splat1907 = shufflevector <8 x i64> %.splatinsert1906, <8 x i64> poison, <8 x i32> zeroinitializer
  %5477 = add <8 x i64> %5476, %.splat1907
  %5478 = load <8 x i64>, ptr %.spill177, align 64
  %5479 = select <8 x i1> %95, <8 x i64> %5477, <8 x i64> %5478
  store <8 x i64> %5479, ptr %.spill177, align 64
  br i1 %5474, label %direct.true1908, label %direct.false1909

direct.schedule.93:                               ; preds = %direct.true1908
  %.spill.load1910 = load <8 x i64>, ptr %.spill177, align 64
  %5480 = extractvalue { ptr, i64 } %59, 0
  %5481 = extractelement <8 x i64> %.spill.load1910, i32 0
  %5482 = mul i64 %5481, 4
  %5483 = getelementptr i8, ptr %5480, i64 %5482
  %5484 = load float, ptr %5483, align 4
  %.splatinsert1911 = insertelement <8 x float> poison, float %5484, i64 0
  %.splat1912 = shufflevector <8 x float> %.splatinsert1911, <8 x float> poison, <8 x i32> zeroinitializer
  %5485 = load <8 x float>, ptr %.slot178, align 32
  %5486 = select <8 x i1> %95, <8 x float> %.splat1912, <8 x float> %5485
  store <8 x float> %5486, ptr %.slot178, align 32
  br label %direct.schedule.94

direct.schedule.94:                               ; preds = %direct.schedule.93, %direct.false1909
  %tile_snapshot.spill.load1913 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %5487 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1913, 0
  %5488 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1913, 1
  %.state1914 = load i64, ptr %.slot176, align 4
  %.splatinsert1915 = insertelement <8 x i64> poison, i64 %.state1914, i64 0
  %.splat1916 = shufflevector <8 x i64> %.splatinsert1915, <8 x i64> poison, <8 x i32> zeroinitializer
  %5489 = mul <8 x i64> %.splat1916, splat (i64 32)
  %5490 = add <8 x i64> %5488, %5489
  %5491 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5487, 0
  %5492 = insertvalue { <8 x ptr>, <8 x i64> } %5491, <8 x i64> %5490, 1
  %.state1917 = load <8 x float>, ptr %.slot178, align 32
  %5493 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %5494 = extractvalue { <8 x ptr>, <8 x i64> } %5492, 1
  %5495 = extractelement <8 x ptr> %5493, i32 0
  %5496 = extractelement <8 x i64> %5494, i32 0
  %5497 = sub i64 %5496, 0
  %5498 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5499 = select i1 %5498, i64 %5497, i64 0
  %private.contiguous.address1918 = getelementptr i8, ptr %5495, i64 %5499
  %private.contiguous.preserve1919 = load <8 x float>, ptr %private.contiguous.address1918, align 4
  %5500 = select <8 x i1> %95, <8 x float> %.state1917, <8 x float> %private.contiguous.preserve1919
  store <8 x float> %5500, ptr %private.contiguous.address1918, align 4
  %.state1920 = load i64, ptr %.slot176, align 4
  %5501 = add i64 %.state1920, 1
  store i64 %5501, ptr %.slot176, align 4
  br label %direct.schedule.91

direct.schedule.95:                               ; preds = %direct.false211
  %5502 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill179, align 64
  %5503 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %5504 = extractvalue { <8 x ptr>, <8 x i64> } %5502, 0
  %5505 = select <8 x i1> %95, <8 x ptr> %5503, <8 x ptr> %5504
  %5506 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %5507 = extractvalue { <8 x ptr>, <8 x i64> } %5502, 1
  %5508 = select <8 x i1> %95, <8 x i64> %5506, <8 x i64> %5507
  %5509 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5505, 0
  %5510 = insertvalue { <8 x ptr>, <8 x i64> } %5509, <8 x i64> %5508, 1
  store { <8 x ptr>, <8 x i64> } %5510, ptr %tile_snapshot.spill179, align 64
  %5511 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %5512 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %5513 = add <8 x i64> %5512, zeroinitializer
  %5514 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5511, 0
  %5515 = insertvalue { <8 x ptr>, <8 x i64> } %5514, <8 x i64> %5513, 1
  %.state1921 = load <8 x float>, ptr %.slot76, align 32
  %5516 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %5517 = extractvalue { <8 x ptr>, <8 x i64> } %5515, 1
  %5518 = extractelement <8 x ptr> %5516, i32 0
  %5519 = extractelement <8 x i64> %5517, i32 0
  %5520 = sub i64 %5519, 0
  %5521 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5522 = select i1 %5521, i64 %5520, i64 0
  %private.contiguous.address1922 = getelementptr i8, ptr %5518, i64 %5522
  %private.contiguous.preserve1923 = load <8 x float>, ptr %private.contiguous.address1922, align 4
  %5523 = select <8 x i1> %95, <8 x float> %.state1921, <8 x float> %private.contiguous.preserve1923
  store <8 x float> %5523, ptr %private.contiguous.address1922, align 4
  %5524 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %5525 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %5526 = add <8 x i64> %5525, splat (i64 32)
  %5527 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5524, 0
  %5528 = insertvalue { <8 x ptr>, <8 x i64> } %5527, <8 x i64> %5526, 1
  %.state1924 = load <8 x float>, ptr %.slot77, align 32
  %5529 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %5530 = extractvalue { <8 x ptr>, <8 x i64> } %5528, 1
  %5531 = extractelement <8 x ptr> %5529, i32 0
  %5532 = extractelement <8 x i64> %5530, i32 0
  %5533 = sub i64 %5532, 0
  %5534 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5535 = select i1 %5534, i64 %5533, i64 0
  %private.contiguous.address1925 = getelementptr i8, ptr %5531, i64 %5535
  %private.contiguous.preserve1926 = load <8 x float>, ptr %private.contiguous.address1925, align 4
  %5536 = select <8 x i1> %95, <8 x float> %.state1924, <8 x float> %private.contiguous.preserve1926
  store <8 x float> %5536, ptr %private.contiguous.address1925, align 4
  %5537 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %5538 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %5539 = add <8 x i64> %5538, splat (i64 64)
  %5540 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5537, 0
  %5541 = insertvalue { <8 x ptr>, <8 x i64> } %5540, <8 x i64> %5539, 1
  %.state1927 = load <8 x float>, ptr %.slot78, align 32
  %5542 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %5543 = extractvalue { <8 x ptr>, <8 x i64> } %5541, 1
  %5544 = extractelement <8 x ptr> %5542, i32 0
  %5545 = extractelement <8 x i64> %5543, i32 0
  %5546 = sub i64 %5545, 0
  %5547 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5548 = select i1 %5547, i64 %5546, i64 0
  %private.contiguous.address1928 = getelementptr i8, ptr %5544, i64 %5548
  %private.contiguous.preserve1929 = load <8 x float>, ptr %private.contiguous.address1928, align 4
  %5549 = select <8 x i1> %95, <8 x float> %.state1927, <8 x float> %private.contiguous.preserve1929
  store <8 x float> %5549, ptr %private.contiguous.address1928, align 4
  %5550 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %5551 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %5552 = add <8 x i64> %5551, splat (i64 96)
  %5553 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5550, 0
  %5554 = insertvalue { <8 x ptr>, <8 x i64> } %5553, <8 x i64> %5552, 1
  %.state1930 = load <8 x float>, ptr %.slot79, align 32
  %5555 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %5556 = extractvalue { <8 x ptr>, <8 x i64> } %5554, 1
  %5557 = extractelement <8 x ptr> %5555, i32 0
  %5558 = extractelement <8 x i64> %5556, i32 0
  %5559 = sub i64 %5558, 0
  %5560 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5561 = select i1 %5560, i64 %5559, i64 0
  %private.contiguous.address1931 = getelementptr i8, ptr %5557, i64 %5561
  %private.contiguous.preserve1932 = load <8 x float>, ptr %private.contiguous.address1931, align 4
  %5562 = select <8 x i1> %95, <8 x float> %.state1930, <8 x float> %private.contiguous.preserve1932
  store <8 x float> %5562, ptr %private.contiguous.address1931, align 4
  %5563 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %5564 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %5565 = add <8 x i64> %5564, splat (i64 128)
  %5566 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5563, 0
  %5567 = insertvalue { <8 x ptr>, <8 x i64> } %5566, <8 x i64> %5565, 1
  %.state1933 = load <8 x float>, ptr %.slot80, align 32
  %5568 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %5569 = extractvalue { <8 x ptr>, <8 x i64> } %5567, 1
  %5570 = extractelement <8 x ptr> %5568, i32 0
  %5571 = extractelement <8 x i64> %5569, i32 0
  %5572 = sub i64 %5571, 0
  %5573 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5574 = select i1 %5573, i64 %5572, i64 0
  %private.contiguous.address1934 = getelementptr i8, ptr %5570, i64 %5574
  %private.contiguous.preserve1935 = load <8 x float>, ptr %private.contiguous.address1934, align 4
  %5575 = select <8 x i1> %95, <8 x float> %.state1933, <8 x float> %private.contiguous.preserve1935
  store <8 x float> %5575, ptr %private.contiguous.address1934, align 4
  %5576 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %5577 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %5578 = add <8 x i64> %5577, splat (i64 160)
  %5579 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5576, 0
  %5580 = insertvalue { <8 x ptr>, <8 x i64> } %5579, <8 x i64> %5578, 1
  %.state1936 = load <8 x float>, ptr %.slot81, align 32
  %5581 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %5582 = extractvalue { <8 x ptr>, <8 x i64> } %5580, 1
  %5583 = extractelement <8 x ptr> %5581, i32 0
  %5584 = extractelement <8 x i64> %5582, i32 0
  %5585 = sub i64 %5584, 0
  %5586 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5587 = select i1 %5586, i64 %5585, i64 0
  %private.contiguous.address1937 = getelementptr i8, ptr %5583, i64 %5587
  %private.contiguous.preserve1938 = load <8 x float>, ptr %private.contiguous.address1937, align 4
  %5588 = select <8 x i1> %95, <8 x float> %.state1936, <8 x float> %private.contiguous.preserve1938
  store <8 x float> %5588, ptr %private.contiguous.address1937, align 4
  %5589 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %5590 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %5591 = add <8 x i64> %5590, splat (i64 192)
  %5592 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5589, 0
  %5593 = insertvalue { <8 x ptr>, <8 x i64> } %5592, <8 x i64> %5591, 1
  %.state1939 = load <8 x float>, ptr %.slot82, align 32
  %5594 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %5595 = extractvalue { <8 x ptr>, <8 x i64> } %5593, 1
  %5596 = extractelement <8 x ptr> %5594, i32 0
  %5597 = extractelement <8 x i64> %5595, i32 0
  %5598 = sub i64 %5597, 0
  %5599 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5600 = select i1 %5599, i64 %5598, i64 0
  %private.contiguous.address1940 = getelementptr i8, ptr %5596, i64 %5600
  %private.contiguous.preserve1941 = load <8 x float>, ptr %private.contiguous.address1940, align 4
  %5601 = select <8 x i1> %95, <8 x float> %.state1939, <8 x float> %private.contiguous.preserve1941
  store <8 x float> %5601, ptr %private.contiguous.address1940, align 4
  %5602 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %5603 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %5604 = add <8 x i64> %5603, splat (i64 224)
  %5605 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5602, 0
  %5606 = insertvalue { <8 x ptr>, <8 x i64> } %5605, <8 x i64> %5604, 1
  %.state1942 = load <8 x float>, ptr %.slot83, align 32
  %5607 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %5608 = extractvalue { <8 x ptr>, <8 x i64> } %5606, 1
  %5609 = extractelement <8 x ptr> %5607, i32 0
  %5610 = extractelement <8 x i64> %5608, i32 0
  %5611 = sub i64 %5610, 0
  %5612 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5613 = select i1 %5612, i64 %5611, i64 0
  %private.contiguous.address1943 = getelementptr i8, ptr %5609, i64 %5613
  %private.contiguous.preserve1944 = load <8 x float>, ptr %private.contiguous.address1943, align 4
  %5614 = select <8 x i1> %95, <8 x float> %.state1942, <8 x float> %private.contiguous.preserve1944
  store <8 x float> %5614, ptr %private.contiguous.address1943, align 4
  store i64 0, ptr %.slot180, align 4
  br label %direct.schedule.96

direct.schedule.96:                               ; preds = %direct.schedule.97, %direct.schedule.95
  %.state1945 = load i64, ptr %.slot180, align 4
  %5615 = icmp slt i64 %.state1945, 384
  br i1 %5615, label %direct.true1946, label %direct.false1947

direct.schedule.97:                               ; preds = %direct.true1946
  %.state1948 = load i64, ptr %.slot180, align 4
  %5616 = srem i64 %.state1948, 48
  %.state1949 = load i64, ptr %.slot180, align 4
  %5617 = sdiv i64 %.state1949, 48
  %.spill.load1950 = load i64, ptr %.spill63, align 4
  %5618 = add i64 %.spill.load1950, 0
  %.spill.load1951 = load <8 x i64>, ptr %.spill, align 64
  %5619 = add <8 x i64> %.spill.load1951, zeroinitializer
  %5620 = mul i64 %5618, 4
  %.splatinsert1952 = insertelement <8 x i64> poison, i64 %5620, i64 0
  %.splat1953 = shufflevector <8 x i64> %.splatinsert1952, <8 x i64> poison, <8 x i32> zeroinitializer
  %5621 = add <8 x i64> %.splat1953, %5619
  %.spill.load1954 = load <8 x i64>, ptr %.spill61, align 64
  %.splatinsert1955 = insertelement <8 x i64> poison, i64 %5617, i64 0
  %.splat1956 = shufflevector <8 x i64> %.splatinsert1955, <8 x i64> poison, <8 x i32> zeroinitializer
  %5622 = add <8 x i64> %.spill.load1954, %.splat1956
  %5623 = mul <8 x i64> %5621, splat (i64 64)
  %5624 = add <8 x i64> %5623, %5622
  %5625 = add i64 0, %5616
  %5626 = mul <8 x i64> %5624, splat (i64 48)
  %.splatinsert1957 = insertelement <8 x i64> poison, i64 %5625, i64 0
  %.splat1958 = shufflevector <8 x i64> %.splatinsert1957, <8 x i64> poison, <8 x i32> zeroinitializer
  %5627 = add <8 x i64> %5626, %.splat1958
  %5628 = add i64 0, %5617
  %5629 = mul i64 %5628, 48
  %5630 = add i64 %5629, %5616
  %tile_snapshot.spill.load1959 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %5631 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1959, 0
  %5632 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1959, 1
  %.splatinsert1960 = insertelement <8 x i64> poison, i64 %5630, i64 0
  %.splat1961 = shufflevector <8 x i64> %.splatinsert1960, <8 x i64> poison, <8 x i32> zeroinitializer
  %5633 = mul <8 x i64> %.splat1961, splat (i64 32)
  %5634 = add <8 x i64> %5632, %5633
  %5635 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5631, 0
  %5636 = insertvalue { <8 x ptr>, <8 x i64> } %5635, <8 x i64> %5634, 1
  %5637 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %5638 = extractvalue { <8 x ptr>, <8 x i64> } %5636, 1
  %5639 = extractelement <8 x ptr> %5637, i32 0
  %5640 = extractelement <8 x i64> %5638, i32 0
  %5641 = sub i64 %5640, 0
  %5642 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5643 = select i1 %5642, i64 %5641, i64 0
  %private.contiguous.address1962 = getelementptr i8, ptr %5639, i64 %5643
  %private.contiguous.load1963 = load <8 x float>, ptr %private.contiguous.address1962, align 4
  %5644 = select <8 x i1> %95, <8 x float> %private.contiguous.load1963, <8 x float> zeroinitializer
  %tile_snapshot.spill.load1964 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill179, align 64
  %5645 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1964, 0
  %5646 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1964, 1
  %.splatinsert1965 = insertelement <8 x i64> poison, i64 %5628, i64 0
  %.splat1966 = shufflevector <8 x i64> %.splatinsert1965, <8 x i64> poison, <8 x i32> zeroinitializer
  %5647 = mul <8 x i64> %.splat1966, splat (i64 32)
  %5648 = add <8 x i64> %5646, %5647
  %5649 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5645, 0
  %5650 = insertvalue { <8 x ptr>, <8 x i64> } %5649, <8 x i64> %5648, 1
  %5651 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %5652 = extractvalue { <8 x ptr>, <8 x i64> } %5650, 1
  %5653 = extractelement <8 x ptr> %5651, i32 0
  %5654 = extractelement <8 x i64> %5652, i32 0
  %5655 = sub i64 %5654, 0
  %5656 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5657 = select i1 %5656, i64 %5655, i64 0
  %private.contiguous.address1967 = getelementptr i8, ptr %5653, i64 %5657
  %private.contiguous.load1968 = load <8 x float>, ptr %private.contiguous.address1967, align 4
  %5658 = select <8 x i1> %95, <8 x float> %private.contiguous.load1968, <8 x float> zeroinitializer
  %5659 = fdiv <8 x float> %5644, %5658
  %5660 = extractvalue { ptr, i64 } %71, 0
  %5661 = mul <8 x i64> %5627, splat (i64 4)
  %5662 = getelementptr i8, ptr %5660, <8 x i64> %5661
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5659, <8 x ptr> align 1 %5662, <8 x i1> %95)
  %.state1969 = load i64, ptr %.slot180, align 4
  %5663 = add i64 %.state1969, 1
  store i64 %5663, ptr %.slot180, align 4
  br label %direct.schedule.96

direct.schedule.98:                               ; preds = %direct.false1947
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

copy.active:                                      ; preds = %direct.schedule.0
  %5664 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %5665 = extractelement <8 x ptr> %5664, i64 0
  %5666 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %5667 = extractelement <8 x i64> %5666, i64 0
  %5668 = getelementptr i8, ptr %5665, i64 %5667
  %5669 = extractelement <8 x i64> %131, i64 0
  call void @llm_attention.contiguous_copy(ptr %132, i64 %5669, ptr %5668)
  br label %copy.continue

copy.continue:                                    ; preds = %copy.active, %direct.schedule.0
  %5670 = extractelement <8 x i1> %95, i64 1
  br i1 %5670, label %copy.active191, label %copy.continue192

copy.active191:                                   ; preds = %copy.continue
  %5671 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %5672 = extractelement <8 x ptr> %5671, i64 1
  %5673 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %5674 = extractelement <8 x i64> %5673, i64 1
  %5675 = getelementptr i8, ptr %5672, i64 %5674
  %5676 = extractelement <8 x i64> %131, i64 1
  call void @llm_attention.contiguous_copy(ptr %132, i64 %5676, ptr %5675)
  br label %copy.continue192

copy.continue192:                                 ; preds = %copy.active191, %copy.continue
  %5677 = extractelement <8 x i1> %95, i64 2
  br i1 %5677, label %copy.active193, label %copy.continue194

copy.active193:                                   ; preds = %copy.continue192
  %5678 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %5679 = extractelement <8 x ptr> %5678, i64 2
  %5680 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %5681 = extractelement <8 x i64> %5680, i64 2
  %5682 = getelementptr i8, ptr %5679, i64 %5681
  %5683 = extractelement <8 x i64> %131, i64 2
  call void @llm_attention.contiguous_copy(ptr %132, i64 %5683, ptr %5682)
  br label %copy.continue194

copy.continue194:                                 ; preds = %copy.active193, %copy.continue192
  %5684 = extractelement <8 x i1> %95, i64 3
  br i1 %5684, label %copy.active195, label %copy.continue196

copy.active195:                                   ; preds = %copy.continue194
  %5685 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %5686 = extractelement <8 x ptr> %5685, i64 3
  %5687 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %5688 = extractelement <8 x i64> %5687, i64 3
  %5689 = getelementptr i8, ptr %5686, i64 %5688
  %5690 = extractelement <8 x i64> %131, i64 3
  call void @llm_attention.contiguous_copy(ptr %132, i64 %5690, ptr %5689)
  br label %copy.continue196

copy.continue196:                                 ; preds = %copy.active195, %copy.continue194
  %5691 = extractelement <8 x i1> %95, i64 4
  br i1 %5691, label %copy.active197, label %copy.continue198

copy.active197:                                   ; preds = %copy.continue196
  %5692 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %5693 = extractelement <8 x ptr> %5692, i64 4
  %5694 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %5695 = extractelement <8 x i64> %5694, i64 4
  %5696 = getelementptr i8, ptr %5693, i64 %5695
  %5697 = extractelement <8 x i64> %131, i64 4
  call void @llm_attention.contiguous_copy(ptr %132, i64 %5697, ptr %5696)
  br label %copy.continue198

copy.continue198:                                 ; preds = %copy.active197, %copy.continue196
  %5698 = extractelement <8 x i1> %95, i64 5
  br i1 %5698, label %copy.active199, label %copy.continue200

copy.active199:                                   ; preds = %copy.continue198
  %5699 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %5700 = extractelement <8 x ptr> %5699, i64 5
  %5701 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %5702 = extractelement <8 x i64> %5701, i64 5
  %5703 = getelementptr i8, ptr %5700, i64 %5702
  %5704 = extractelement <8 x i64> %131, i64 5
  call void @llm_attention.contiguous_copy(ptr %132, i64 %5704, ptr %5703)
  br label %copy.continue200

copy.continue200:                                 ; preds = %copy.active199, %copy.continue198
  %5705 = extractelement <8 x i1> %95, i64 6
  br i1 %5705, label %copy.active201, label %copy.continue202

copy.active201:                                   ; preds = %copy.continue200
  %5706 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %5707 = extractelement <8 x ptr> %5706, i64 6
  %5708 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %5709 = extractelement <8 x i64> %5708, i64 6
  %5710 = getelementptr i8, ptr %5707, i64 %5709
  %5711 = extractelement <8 x i64> %131, i64 6
  call void @llm_attention.contiguous_copy(ptr %132, i64 %5711, ptr %5710)
  br label %copy.continue202

copy.continue202:                                 ; preds = %copy.active201, %copy.continue200
  %5712 = extractelement <8 x i1> %95, i64 7
  br i1 %5712, label %copy.active203, label %copy.continue204

copy.active203:                                   ; preds = %copy.continue202
  %5713 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %5714 = extractelement <8 x ptr> %5713, i64 7
  %5715 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %5716 = extractelement <8 x i64> %5715, i64 7
  %5717 = getelementptr i8, ptr %5714, i64 %5716
  %5718 = extractelement <8 x i64> %131, i64 7
  call void @llm_attention.contiguous_copy(ptr %132, i64 %5718, ptr %5717)
  br label %copy.continue204

copy.continue204:                                 ; preds = %copy.active203, %copy.continue202
  %5719 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %5720 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %5721 = extractvalue { <8 x ptr>, <8 x i64> } %5719, 0
  %5722 = select <8 x i1> %95, <8 x ptr> %5720, <8 x ptr> %5721
  %5723 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %5724 = extractvalue { <8 x ptr>, <8 x i64> } %5719, 1
  %5725 = select <8 x i1> %95, <8 x i64> %5723, <8 x i64> %5724
  %5726 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5722, 0
  %5727 = insertvalue { <8 x ptr>, <8 x i64> } %5726, <8 x i64> %5725, 1
  store { <8 x ptr>, <8 x i64> } %5727, ptr %tile_snapshot.spill65, align 64
  %5728 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill66, align 64
  %5729 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %5730 = extractvalue { <8 x ptr>, <8 x i64> } %5728, 0
  %5731 = select <8 x i1> %95, <8 x ptr> %5729, <8 x ptr> %5730
  %5732 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %5733 = extractvalue { <8 x ptr>, <8 x i64> } %5728, 1
  %5734 = select <8 x i1> %95, <8 x i64> %5732, <8 x i64> %5733
  %5735 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5731, 0
  %5736 = insertvalue { <8 x ptr>, <8 x i64> } %5735, <8 x i64> %5734, 1
  store { <8 x ptr>, <8 x i64> } %5736, ptr %tile_snapshot.spill66, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true210:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false211:                                  ; preds = %direct.schedule.4
  br label %direct.schedule.95

direct.true213:                                   ; preds = %direct.schedule.5
  br label %direct.schedule.6

direct.false214:                                  ; preds = %direct.schedule.5
  br label %direct.schedule.90

copy.active222:                                   ; preds = %direct.schedule.6
  %5737 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 0
  %5738 = extractelement <8 x ptr> %5737, i64 0
  %5739 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 1
  %5740 = extractelement <8 x i64> %5739, i64 0
  %5741 = getelementptr i8, ptr %5738, i64 %5740
  %5742 = extractelement <8 x i64> %203, i64 0
  call void @llm_attention.contiguous_copy.1(ptr %204, i64 %5742, ptr %5741)
  br label %copy.continue223

copy.continue223:                                 ; preds = %copy.active222, %direct.schedule.6
  %5743 = extractelement <8 x i1> %95, i64 1
  br i1 %5743, label %copy.active224, label %copy.continue225

copy.active224:                                   ; preds = %copy.continue223
  %5744 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 0
  %5745 = extractelement <8 x ptr> %5744, i64 1
  %5746 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 1
  %5747 = extractelement <8 x i64> %5746, i64 1
  %5748 = getelementptr i8, ptr %5745, i64 %5747
  %5749 = extractelement <8 x i64> %203, i64 1
  call void @llm_attention.contiguous_copy.1(ptr %204, i64 %5749, ptr %5748)
  br label %copy.continue225

copy.continue225:                                 ; preds = %copy.active224, %copy.continue223
  %5750 = extractelement <8 x i1> %95, i64 2
  br i1 %5750, label %copy.active226, label %copy.continue227

copy.active226:                                   ; preds = %copy.continue225
  %5751 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 0
  %5752 = extractelement <8 x ptr> %5751, i64 2
  %5753 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 1
  %5754 = extractelement <8 x i64> %5753, i64 2
  %5755 = getelementptr i8, ptr %5752, i64 %5754
  %5756 = extractelement <8 x i64> %203, i64 2
  call void @llm_attention.contiguous_copy.1(ptr %204, i64 %5756, ptr %5755)
  br label %copy.continue227

copy.continue227:                                 ; preds = %copy.active226, %copy.continue225
  %5757 = extractelement <8 x i1> %95, i64 3
  br i1 %5757, label %copy.active228, label %copy.continue229

copy.active228:                                   ; preds = %copy.continue227
  %5758 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 0
  %5759 = extractelement <8 x ptr> %5758, i64 3
  %5760 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 1
  %5761 = extractelement <8 x i64> %5760, i64 3
  %5762 = getelementptr i8, ptr %5759, i64 %5761
  %5763 = extractelement <8 x i64> %203, i64 3
  call void @llm_attention.contiguous_copy.1(ptr %204, i64 %5763, ptr %5762)
  br label %copy.continue229

copy.continue229:                                 ; preds = %copy.active228, %copy.continue227
  %5764 = extractelement <8 x i1> %95, i64 4
  br i1 %5764, label %copy.active230, label %copy.continue231

copy.active230:                                   ; preds = %copy.continue229
  %5765 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 0
  %5766 = extractelement <8 x ptr> %5765, i64 4
  %5767 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 1
  %5768 = extractelement <8 x i64> %5767, i64 4
  %5769 = getelementptr i8, ptr %5766, i64 %5768
  %5770 = extractelement <8 x i64> %203, i64 4
  call void @llm_attention.contiguous_copy.1(ptr %204, i64 %5770, ptr %5769)
  br label %copy.continue231

copy.continue231:                                 ; preds = %copy.active230, %copy.continue229
  %5771 = extractelement <8 x i1> %95, i64 5
  br i1 %5771, label %copy.active232, label %copy.continue233

copy.active232:                                   ; preds = %copy.continue231
  %5772 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 0
  %5773 = extractelement <8 x ptr> %5772, i64 5
  %5774 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 1
  %5775 = extractelement <8 x i64> %5774, i64 5
  %5776 = getelementptr i8, ptr %5773, i64 %5775
  %5777 = extractelement <8 x i64> %203, i64 5
  call void @llm_attention.contiguous_copy.1(ptr %204, i64 %5777, ptr %5776)
  br label %copy.continue233

copy.continue233:                                 ; preds = %copy.active232, %copy.continue231
  %5778 = extractelement <8 x i1> %95, i64 6
  br i1 %5778, label %copy.active234, label %copy.continue235

copy.active234:                                   ; preds = %copy.continue233
  %5779 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 0
  %5780 = extractelement <8 x ptr> %5779, i64 6
  %5781 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 1
  %5782 = extractelement <8 x i64> %5781, i64 6
  %5783 = getelementptr i8, ptr %5780, i64 %5782
  %5784 = extractelement <8 x i64> %203, i64 6
  call void @llm_attention.contiguous_copy.1(ptr %204, i64 %5784, ptr %5783)
  br label %copy.continue235

copy.continue235:                                 ; preds = %copy.active234, %copy.continue233
  %5785 = extractelement <8 x i1> %95, i64 7
  br i1 %5785, label %copy.active236, label %copy.continue237

copy.active236:                                   ; preds = %copy.continue235
  %5786 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 0
  %5787 = extractelement <8 x ptr> %5786, i64 7
  %5788 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 1
  %5789 = extractelement <8 x i64> %5788, i64 7
  %5790 = getelementptr i8, ptr %5787, i64 %5789
  %5791 = extractelement <8 x i64> %203, i64 7
  call void @llm_attention.contiguous_copy.1(ptr %204, i64 %5791, ptr %5790)
  br label %copy.continue237

copy.continue237:                                 ; preds = %copy.active236, %copy.continue235
  br label %direct.schedule.7

direct.true239:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false240:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.85

copy.active249:                                   ; preds = %direct.schedule.8
  %5792 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 0
  %5793 = extractelement <8 x ptr> %5792, i64 0
  %5794 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 1
  %5795 = extractelement <8 x i64> %5794, i64 0
  %5796 = getelementptr i8, ptr %5793, i64 %5795
  %5797 = extractelement <8 x i64> %220, i64 0
  call void @llm_attention.contiguous_copy.2(ptr %221, i64 %5797, ptr %5796)
  br label %copy.continue250

copy.continue250:                                 ; preds = %copy.active249, %direct.schedule.8
  %5798 = extractelement <8 x i1> %95, i64 1
  br i1 %5798, label %copy.active251, label %copy.continue252

copy.active251:                                   ; preds = %copy.continue250
  %5799 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 0
  %5800 = extractelement <8 x ptr> %5799, i64 1
  %5801 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 1
  %5802 = extractelement <8 x i64> %5801, i64 1
  %5803 = getelementptr i8, ptr %5800, i64 %5802
  %5804 = extractelement <8 x i64> %220, i64 1
  call void @llm_attention.contiguous_copy.2(ptr %221, i64 %5804, ptr %5803)
  br label %copy.continue252

copy.continue252:                                 ; preds = %copy.active251, %copy.continue250
  %5805 = extractelement <8 x i1> %95, i64 2
  br i1 %5805, label %copy.active253, label %copy.continue254

copy.active253:                                   ; preds = %copy.continue252
  %5806 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 0
  %5807 = extractelement <8 x ptr> %5806, i64 2
  %5808 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 1
  %5809 = extractelement <8 x i64> %5808, i64 2
  %5810 = getelementptr i8, ptr %5807, i64 %5809
  %5811 = extractelement <8 x i64> %220, i64 2
  call void @llm_attention.contiguous_copy.2(ptr %221, i64 %5811, ptr %5810)
  br label %copy.continue254

copy.continue254:                                 ; preds = %copy.active253, %copy.continue252
  %5812 = extractelement <8 x i1> %95, i64 3
  br i1 %5812, label %copy.active255, label %copy.continue256

copy.active255:                                   ; preds = %copy.continue254
  %5813 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 0
  %5814 = extractelement <8 x ptr> %5813, i64 3
  %5815 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 1
  %5816 = extractelement <8 x i64> %5815, i64 3
  %5817 = getelementptr i8, ptr %5814, i64 %5816
  %5818 = extractelement <8 x i64> %220, i64 3
  call void @llm_attention.contiguous_copy.2(ptr %221, i64 %5818, ptr %5817)
  br label %copy.continue256

copy.continue256:                                 ; preds = %copy.active255, %copy.continue254
  %5819 = extractelement <8 x i1> %95, i64 4
  br i1 %5819, label %copy.active257, label %copy.continue258

copy.active257:                                   ; preds = %copy.continue256
  %5820 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 0
  %5821 = extractelement <8 x ptr> %5820, i64 4
  %5822 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 1
  %5823 = extractelement <8 x i64> %5822, i64 4
  %5824 = getelementptr i8, ptr %5821, i64 %5823
  %5825 = extractelement <8 x i64> %220, i64 4
  call void @llm_attention.contiguous_copy.2(ptr %221, i64 %5825, ptr %5824)
  br label %copy.continue258

copy.continue258:                                 ; preds = %copy.active257, %copy.continue256
  %5826 = extractelement <8 x i1> %95, i64 5
  br i1 %5826, label %copy.active259, label %copy.continue260

copy.active259:                                   ; preds = %copy.continue258
  %5827 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 0
  %5828 = extractelement <8 x ptr> %5827, i64 5
  %5829 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 1
  %5830 = extractelement <8 x i64> %5829, i64 5
  %5831 = getelementptr i8, ptr %5828, i64 %5830
  %5832 = extractelement <8 x i64> %220, i64 5
  call void @llm_attention.contiguous_copy.2(ptr %221, i64 %5832, ptr %5831)
  br label %copy.continue260

copy.continue260:                                 ; preds = %copy.active259, %copy.continue258
  %5833 = extractelement <8 x i1> %95, i64 6
  br i1 %5833, label %copy.active261, label %copy.continue262

copy.active261:                                   ; preds = %copy.continue260
  %5834 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 0
  %5835 = extractelement <8 x ptr> %5834, i64 6
  %5836 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 1
  %5837 = extractelement <8 x i64> %5836, i64 6
  %5838 = getelementptr i8, ptr %5835, i64 %5837
  %5839 = extractelement <8 x i64> %220, i64 6
  call void @llm_attention.contiguous_copy.2(ptr %221, i64 %5839, ptr %5838)
  br label %copy.continue262

copy.continue262:                                 ; preds = %copy.active261, %copy.continue260
  %5840 = extractelement <8 x i1> %95, i64 7
  br i1 %5840, label %copy.active263, label %copy.continue264

copy.active263:                                   ; preds = %copy.continue262
  %5841 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 0
  %5842 = extractelement <8 x ptr> %5841, i64 7
  %5843 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 1
  %5844 = extractelement <8 x i64> %5843, i64 7
  %5845 = getelementptr i8, ptr %5842, i64 %5844
  %5846 = extractelement <8 x i64> %220, i64 7
  call void @llm_attention.contiguous_copy.2(ptr %221, i64 %5846, ptr %5845)
  br label %copy.continue264

copy.continue264:                                 ; preds = %copy.active263, %copy.continue262
  br label %direct.schedule.9

direct.true266:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false267:                                  ; preds = %direct.schedule.10
  br label %direct.schedule.15

direct.true270:                                   ; preds = %direct.schedule.12
  br label %direct.schedule.13

direct.false271:                                  ; preds = %direct.schedule.12
  br label %direct.schedule.14

direct.true1072:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false1073:                                 ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true1095:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false1096:                                 ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true1115:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false1116:                                 ; preds = %direct.schedule.22
  br label %direct.schedule.24

direct.true1127:                                  ; preds = %direct.schedule.25
  br label %direct.schedule.26

direct.false1128:                                 ; preds = %direct.schedule.25
  br label %direct.schedule.27

direct.true1139:                                  ; preds = %direct.schedule.28
  br label %direct.schedule.29

direct.false1140:                                 ; preds = %direct.schedule.28
  br label %direct.schedule.30

direct.true1151:                                  ; preds = %direct.schedule.31
  br label %direct.schedule.32

direct.false1152:                                 ; preds = %direct.schedule.31
  br label %direct.schedule.33

direct.true1163:                                  ; preds = %direct.schedule.34
  br label %direct.schedule.35

direct.false1164:                                 ; preds = %direct.schedule.34
  br label %direct.schedule.36

direct.true1175:                                  ; preds = %direct.schedule.37
  br label %direct.schedule.38

direct.false1176:                                 ; preds = %direct.schedule.37
  br label %direct.schedule.39

direct.true1187:                                  ; preds = %direct.schedule.40
  br label %direct.schedule.41

direct.false1188:                                 ; preds = %direct.schedule.40
  br label %direct.schedule.42

direct.true1199:                                  ; preds = %direct.schedule.43
  br label %direct.schedule.44

direct.false1200:                                 ; preds = %direct.schedule.43
  br label %direct.schedule.45

direct.true1274:                                  ; preds = %direct.schedule.46
  br label %direct.schedule.47

direct.false1275:                                 ; preds = %direct.schedule.46
  br label %direct.schedule.48

direct.true1316:                                  ; preds = %direct.schedule.49
  br label %direct.schedule.50

direct.false1317:                                 ; preds = %direct.schedule.49
  br label %direct.schedule.51

direct.true1328:                                  ; preds = %direct.schedule.52
  br label %direct.schedule.53

direct.false1329:                                 ; preds = %direct.schedule.52
  br label %direct.schedule.54

direct.true1340:                                  ; preds = %direct.schedule.55
  br label %direct.schedule.56

direct.false1341:                                 ; preds = %direct.schedule.55
  br label %direct.schedule.57

direct.true1352:                                  ; preds = %direct.schedule.58
  br label %direct.schedule.59

direct.false1353:                                 ; preds = %direct.schedule.58
  br label %direct.schedule.60

direct.true1364:                                  ; preds = %direct.schedule.61
  br label %direct.schedule.62

direct.false1365:                                 ; preds = %direct.schedule.61
  br label %direct.schedule.63

direct.true1376:                                  ; preds = %direct.schedule.64
  br label %direct.schedule.65

direct.false1377:                                 ; preds = %direct.schedule.64
  br label %direct.schedule.66

direct.true1388:                                  ; preds = %direct.schedule.67
  br label %direct.schedule.68

direct.false1389:                                 ; preds = %direct.schedule.67
  br label %direct.schedule.69

direct.true1400:                                  ; preds = %direct.schedule.70
  br label %direct.schedule.71

direct.false1401:                                 ; preds = %direct.schedule.70
  br label %direct.schedule.72

direct.true1428:                                  ; preds = %direct.schedule.73
  br label %direct.schedule.74

direct.false1429:                                 ; preds = %direct.schedule.73
  br label %direct.schedule.78

direct.true1432:                                  ; preds = %direct.schedule.75
  br label %direct.schedule.76

direct.false1433:                                 ; preds = %direct.schedule.75
  br label %direct.schedule.77

direct.true1819:                                  ; preds = %direct.schedule.79
  br label %direct.schedule.80

direct.false1820:                                 ; preds = %direct.schedule.79
  br label %direct.schedule.81

direct.true1835:                                  ; preds = %direct.schedule.82
  br label %direct.schedule.83

direct.false1836:                                 ; preds = %direct.schedule.82
  br label %direct.schedule.84

direct.true1868:                                  ; preds = %direct.schedule.86
  br label %direct.schedule.87

direct.false1869:                                 ; preds = %direct.schedule.86
  br label %direct.schedule.9

direct.true1881:                                  ; preds = %direct.schedule.87
  br label %direct.schedule.88

direct.false1882:                                 ; preds = %direct.schedule.87
  %5847 = load <8 x float>, ptr %.slot175, align 32
  %5848 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %5847
  store <8 x float> %5848, ptr %.slot175, align 32
  br label %direct.schedule.89

direct.true1895:                                  ; preds = %direct.schedule.91
  br label %direct.schedule.92

direct.false1896:                                 ; preds = %direct.schedule.91
  br label %direct.schedule.7

direct.true1908:                                  ; preds = %direct.schedule.92
  br label %direct.schedule.93

direct.false1909:                                 ; preds = %direct.schedule.92
  %5849 = load <8 x float>, ptr %.slot178, align 32
  %5850 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %5849
  store <8 x float> %5850, ptr %.slot178, align 32
  br label %direct.schedule.94

direct.true1946:                                  ; preds = %direct.schedule.96
  br label %direct.schedule.97

direct.false1947:                                 ; preds = %direct.schedule.96
  br label %direct.schedule.98
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nounwind willreturn
define private void @llm_attention.contiguous_copy(ptr %0, i64 %1, ptr %2) #1 {
entry:
  %3 = getelementptr i32, ptr %0, i64 %1
  br label %copy.loop

copy.loop:                                        ; preds = %copy.chunk, %entry
  %copy.index = phi i64 [ 0, %entry ], [ %25, %copy.chunk ]
  %4 = icmp ult i64 %copy.index, 64
  br i1 %4, label %copy.chunk, label %copy.next

copy.chunk:                                       ; preds = %copy.loop
  %5 = mul i64 %copy.index, 4
  %6 = add i64 0, %5
  %7 = getelementptr i32, ptr %3, i64 %6
  %8 = load <4 x i32>, ptr %7, align 4
  %9 = add i64 %6, 0
  %10 = mul i64 %9, 8
  %11 = getelementptr i32, ptr %2, i64 %10
  %12 = extractelement <4 x i32> %8, i64 0
  store i32 %12, ptr %11, align 4
  %13 = add i64 %6, 1
  %14 = mul i64 %13, 8
  %15 = getelementptr i32, ptr %2, i64 %14
  %16 = extractelement <4 x i32> %8, i64 1
  store i32 %16, ptr %15, align 4
  %17 = add i64 %6, 2
  %18 = mul i64 %17, 8
  %19 = getelementptr i32, ptr %2, i64 %18
  %20 = extractelement <4 x i32> %8, i64 2
  store i32 %20, ptr %19, align 4
  %21 = add i64 %6, 3
  %22 = mul i64 %21, 8
  %23 = getelementptr i32, ptr %2, i64 %22
  %24 = extractelement <4 x i32> %8, i64 3
  store i32 %24, ptr %23, align 4
  %25 = add i64 %copy.index, 1
  br label %copy.loop

copy.next:                                        ; preds = %copy.loop
  ret void
}

; Function Attrs: nounwind willreturn
define private void @llm_attention.contiguous_copy.1(ptr %0, i64 %1, ptr %2) #1 {
entry:
  %3 = getelementptr i32, ptr %0, i64 %1
  br label %copy.loop

copy.loop:                                        ; preds = %copy.chunk, %entry
  %copy.index = phi i64 [ 0, %entry ], [ %25, %copy.chunk ]
  %4 = icmp ult i64 %copy.index, 128
  br i1 %4, label %copy.chunk, label %copy.next

copy.chunk:                                       ; preds = %copy.loop
  %5 = mul i64 %copy.index, 4
  %6 = add i64 0, %5
  %7 = getelementptr i32, ptr %3, i64 %6
  %8 = load <4 x i32>, ptr %7, align 4
  %9 = add i64 %6, 0
  %10 = mul i64 %9, 8
  %11 = getelementptr i32, ptr %2, i64 %10
  %12 = extractelement <4 x i32> %8, i64 0
  store i32 %12, ptr %11, align 4
  %13 = add i64 %6, 1
  %14 = mul i64 %13, 8
  %15 = getelementptr i32, ptr %2, i64 %14
  %16 = extractelement <4 x i32> %8, i64 1
  store i32 %16, ptr %15, align 4
  %17 = add i64 %6, 2
  %18 = mul i64 %17, 8
  %19 = getelementptr i32, ptr %2, i64 %18
  %20 = extractelement <4 x i32> %8, i64 2
  store i32 %20, ptr %19, align 4
  %21 = add i64 %6, 3
  %22 = mul i64 %21, 8
  %23 = getelementptr i32, ptr %2, i64 %22
  %24 = extractelement <4 x i32> %8, i64 3
  store i32 %24, ptr %23, align 4
  %25 = add i64 %copy.index, 1
  br label %copy.loop

copy.next:                                        ; preds = %copy.loop
  ret void
}

; Function Attrs: nounwind willreturn
define private void @llm_attention.contiguous_copy.2(ptr %0, i64 %1, ptr %2) #1 {
entry:
  %3 = getelementptr i32, ptr %0, i64 %1
  br label %copy.loop

copy.loop:                                        ; preds = %copy.chunk, %entry
  %copy.index = phi i64 [ 0, %entry ], [ %25, %copy.chunk ]
  %4 = icmp ult i64 %copy.index, 192
  br i1 %4, label %copy.chunk, label %copy.next

copy.chunk:                                       ; preds = %copy.loop
  %5 = mul i64 %copy.index, 4
  %6 = add i64 0, %5
  %7 = getelementptr i32, ptr %3, i64 %6
  %8 = load <4 x i32>, ptr %7, align 4
  %9 = add i64 %6, 0
  %10 = mul i64 %9, 8
  %11 = getelementptr i32, ptr %2, i64 %10
  %12 = extractelement <4 x i32> %8, i64 0
  store i32 %12, ptr %11, align 4
  %13 = add i64 %6, 1
  %14 = mul i64 %13, 8
  %15 = getelementptr i32, ptr %2, i64 %14
  %16 = extractelement <4 x i32> %8, i64 1
  store i32 %16, ptr %15, align 4
  %17 = add i64 %6, 2
  %18 = mul i64 %17, 8
  %19 = getelementptr i32, ptr %2, i64 %18
  %20 = extractelement <4 x i32> %8, i64 2
  store i32 %20, ptr %19, align 4
  %21 = add i64 %6, 3
  %22 = mul i64 %21, 8
  %23 = getelementptr i32, ptr %2, i64 %22
  %24 = extractelement <4 x i32> %8, i64 3
  store i32 %24, ptr %23, align 4
  %25 = add i64 %copy.index, 1
  br label %copy.loop

copy.next:                                        ; preds = %copy.loop
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8i8.v8p0(<8 x i8>, <8 x ptr>, <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr>, <8 x i1>, <8 x i8>) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #4

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #5 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #2

define internal void @llm_attention.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_attention.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_attention.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nounwind willreturn }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }

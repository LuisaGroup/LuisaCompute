	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention.full_packet
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.quad	96                              ; 0x60
	.quad	112                             ; 0x70
lCPI0_3:
	.quad	64                              ; 0x40
	.quad	80                              ; 0x50
lCPI0_4:
	.quad	32                              ; 0x20
	.quad	48                              ; 0x30
lCPI0_5:
	.quad	0                               ; 0x0
	.quad	16                              ; 0x10
lCPI0_6:
	.quad	97                              ; 0x61
	.quad	113                             ; 0x71
lCPI0_7:
	.quad	65                              ; 0x41
	.quad	81                              ; 0x51
lCPI0_8:
	.quad	33                              ; 0x21
	.quad	49                              ; 0x31
lCPI0_9:
	.quad	1                               ; 0x1
	.quad	17                              ; 0x11
lCPI0_10:
	.quad	98                              ; 0x62
	.quad	114                             ; 0x72
lCPI0_11:
	.quad	66                              ; 0x42
	.quad	82                              ; 0x52
lCPI0_12:
	.quad	34                              ; 0x22
	.quad	50                              ; 0x32
lCPI0_13:
	.quad	2                               ; 0x2
	.quad	18                              ; 0x12
lCPI0_14:
	.quad	99                              ; 0x63
	.quad	115                             ; 0x73
lCPI0_15:
	.quad	67                              ; 0x43
	.quad	83                              ; 0x53
lCPI0_16:
	.quad	35                              ; 0x23
	.quad	51                              ; 0x33
lCPI0_17:
	.quad	3                               ; 0x3
	.quad	19                              ; 0x13
lCPI0_18:
	.quad	100                             ; 0x64
	.quad	116                             ; 0x74
lCPI0_19:
	.quad	68                              ; 0x44
	.quad	84                              ; 0x54
lCPI0_20:
	.quad	36                              ; 0x24
	.quad	52                              ; 0x34
lCPI0_21:
	.quad	4                               ; 0x4
	.quad	20                              ; 0x14
lCPI0_22:
	.quad	101                             ; 0x65
	.quad	117                             ; 0x75
lCPI0_23:
	.quad	69                              ; 0x45
	.quad	85                              ; 0x55
lCPI0_24:
	.quad	37                              ; 0x25
	.quad	53                              ; 0x35
lCPI0_25:
	.quad	5                               ; 0x5
	.quad	21                              ; 0x15
lCPI0_26:
	.quad	102                             ; 0x66
	.quad	118                             ; 0x76
lCPI0_27:
	.quad	70                              ; 0x46
	.quad	86                              ; 0x56
lCPI0_28:
	.quad	38                              ; 0x26
	.quad	54                              ; 0x36
lCPI0_29:
	.quad	6                               ; 0x6
	.quad	22                              ; 0x16
lCPI0_30:
	.quad	103                             ; 0x67
	.quad	119                             ; 0x77
lCPI0_31:
	.quad	71                              ; 0x47
	.quad	87                              ; 0x57
lCPI0_32:
	.quad	39                              ; 0x27
	.quad	55                              ; 0x37
lCPI0_33:
	.quad	7                               ; 0x7
	.quad	23                              ; 0x17
lCPI0_34:
	.quad	104                             ; 0x68
	.quad	120                             ; 0x78
lCPI0_35:
	.quad	72                              ; 0x48
	.quad	88                              ; 0x58
lCPI0_36:
	.quad	40                              ; 0x28
	.quad	56                              ; 0x38
lCPI0_37:
	.quad	8                               ; 0x8
	.quad	24                              ; 0x18
lCPI0_38:
	.quad	105                             ; 0x69
	.quad	121                             ; 0x79
lCPI0_39:
	.quad	73                              ; 0x49
	.quad	89                              ; 0x59
lCPI0_40:
	.quad	41                              ; 0x29
	.quad	57                              ; 0x39
lCPI0_41:
	.quad	9                               ; 0x9
	.quad	25                              ; 0x19
lCPI0_42:
	.quad	106                             ; 0x6a
	.quad	122                             ; 0x7a
lCPI0_43:
	.quad	74                              ; 0x4a
	.quad	90                              ; 0x5a
lCPI0_44:
	.quad	42                              ; 0x2a
	.quad	58                              ; 0x3a
lCPI0_45:
	.quad	10                              ; 0xa
	.quad	26                              ; 0x1a
lCPI0_46:
	.quad	107                             ; 0x6b
	.quad	123                             ; 0x7b
lCPI0_47:
	.quad	75                              ; 0x4b
	.quad	91                              ; 0x5b
lCPI0_48:
	.quad	43                              ; 0x2b
	.quad	59                              ; 0x3b
lCPI0_49:
	.quad	11                              ; 0xb
	.quad	27                              ; 0x1b
lCPI0_50:
	.quad	108                             ; 0x6c
	.quad	124                             ; 0x7c
lCPI0_51:
	.quad	76                              ; 0x4c
	.quad	92                              ; 0x5c
lCPI0_52:
	.quad	44                              ; 0x2c
	.quad	60                              ; 0x3c
lCPI0_53:
	.quad	12                              ; 0xc
	.quad	28                              ; 0x1c
lCPI0_54:
	.quad	109                             ; 0x6d
	.quad	125                             ; 0x7d
lCPI0_55:
	.quad	77                              ; 0x4d
	.quad	93                              ; 0x5d
lCPI0_56:
	.quad	45                              ; 0x2d
	.quad	61                              ; 0x3d
lCPI0_57:
	.quad	13                              ; 0xd
	.quad	29                              ; 0x1d
lCPI0_58:
	.quad	110                             ; 0x6e
	.quad	126                             ; 0x7e
lCPI0_59:
	.quad	78                              ; 0x4e
	.quad	94                              ; 0x5e
lCPI0_60:
	.quad	46                              ; 0x2e
	.quad	62                              ; 0x3e
lCPI0_61:
	.quad	14                              ; 0xe
	.quad	30                              ; 0x1e
lCPI0_62:
	.quad	111                             ; 0x6f
	.quad	127                             ; 0x7f
lCPI0_63:
	.quad	79                              ; 0x4f
	.quad	95                              ; 0x5f
lCPI0_64:
	.quad	47                              ; 0x2f
	.quad	63                              ; 0x3f
lCPI0_65:
	.quad	15                              ; 0xf
	.quad	31                              ; 0x1f
lCPI0_66:
	.quad	0                               ; 0x0
	.quad	2048                            ; 0x800
lCPI0_67:
	.quad	4096                            ; 0x1000
	.quad	6144                            ; 0x1800
lCPI0_68:
	.quad	8192                            ; 0x2000
	.quad	10240                           ; 0x2800
lCPI0_69:
	.quad	12288                           ; 0x3000
	.quad	14336                           ; 0x3800
lCPI0_70:
	.quad	0                               ; 0x0
	.quad	3072                            ; 0xc00
lCPI0_71:
	.quad	6144                            ; 0x1800
	.quad	9216                            ; 0x2400
lCPI0_72:
	.quad	12288                           ; 0x3000
	.quad	15360                           ; 0x3c00
lCPI0_73:
	.quad	18432                           ; 0x4800
	.quad	21504                           ; 0x5400
lCPI0_74:
	.quad	0                               ; 0x0
	.quad	512                             ; 0x200
lCPI0_75:
	.quad	1024                            ; 0x400
	.quad	1536                            ; 0x600
lCPI0_76:
	.quad	2048                            ; 0x800
	.quad	2560                            ; 0xa00
lCPI0_77:
	.quad	3072                            ; 0xc00
	.quad	3584                            ; 0xe00
lCPI0_78:
	.quad	0                               ; 0x0
	.quad	128                             ; 0x80
lCPI0_79:
	.quad	256                             ; 0x100
	.quad	384                             ; 0x180
lCPI0_80:
	.quad	512                             ; 0x200
	.quad	640                             ; 0x280
lCPI0_81:
	.quad	768                             ; 0x300
	.quad	896                             ; 0x380
lCPI0_82:
	.quad	0                               ; 0x0
	.quad	1536                            ; 0x600
lCPI0_83:
	.quad	3072                            ; 0xc00
	.quad	4608                            ; 0x1200
lCPI0_84:
	.quad	6144                            ; 0x1800
	.quad	7680                            ; 0x1e00
lCPI0_85:
	.quad	9216                            ; 0x2400
	.quad	10752                           ; 0x2a00
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention.full_packet:             ; @llm_attention.full_packet
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #880
	mov	x9, #0                          ; =0x0
	ldr	x24, [x1, #136]
	add	x8, x24, #25, lsl #12           ; =102400
	add	x8, x8, #128
	str	x8, [sp, #4376]                 ; 8-byte Spill
	add	x8, x24, #23, lsl #12           ; =94208
	add	x12, x8, #3712
	add	x8, x24, #22, lsl #12           ; =90112
	add	x8, x8, #3200
	str	x8, [sp, #3704]                 ; 8-byte Spill
	add	x8, x24, #18, lsl #12           ; =73728
	add	x13, x8, #512
	ldr	x8, [x0]
	ldr	x10, [x0, #16]
	str	x10, [sp, #168]                 ; 8-byte Spill
	ldr	w10, [x1]
	ldr	w11, [x1, #36]
	add	w10, w11, w10, lsl #5
	ldr	x11, [x0, #32]
	str	x11, [sp, #160]                 ; 8-byte Spill
	ldr	x11, [x0, #48]
	dup.4s	v0, w10
Lloh0:
	adrp	x10, lCPI0_0@PAGE
Lloh1:
	ldr	q1, [x10, lCPI0_0@PAGEOFF]
	add.4s	v3, v0, v1
Lloh2:
	adrp	x10, lCPI0_1@PAGE
Lloh3:
	ldr	q1, [x10, lCPI0_1@PAGEOFF]
	add.4s	v1, v0, v1
	ushll2.2d	v0, v1, #0
	str	q0, [sp, #4928]                 ; 16-byte Spill
	ushll2.2d	v0, v3, #0
	str	q0, [sp, #4960]                 ; 16-byte Spill
	ushll.2d	v0, v1, #0
	str	q0, [sp, #4896]                 ; 16-byte Spill
	ushll.2d	v0, v3, #0
	str	q0, [sp, #4912]                 ; 16-byte Spill
	ushll2.2d	v0, v1, #8
	ushll2.2d	v2, v3, #8
	ushll.2d	v1, v1, #8
	ushll.2d	v3, v3, #8
	fmov	x10, d3
	add	x10, x8, x10, lsl #2
LBB0_1:                                 ; %copy.chunk.i
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q4, [x10, x9]
	str	q4, [x24, x9]
	add	x9, x9, #16
	cmp	x9, #1024
	b.ne	LBB0_1
; %bb.2:                                ; %llm_attention.contiguous_copy.exit
	mov	x9, #0                          ; =0x0
	add	x14, x24, #1024
	mov.d	x10, v3[1]
	add	x10, x8, x10, lsl #2
LBB0_3:                                 ; %copy.chunk.i285
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q3, [x10, x9]
	str	q3, [x14, x9]
	add	x9, x9, #16
	cmp	x9, #1024
	b.ne	LBB0_3
; %bb.4:                                ; %llm_attention.contiguous_copy.exit288
	mov	x9, #0                          ; =0x0
	add	x14, x24, #2048
	fmov	x10, d2
	add	x10, x8, x10, lsl #2
LBB0_5:                                 ; %copy.chunk.i289
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q3, [x10, x9]
	str	q3, [x14, x9]
	add	x9, x9, #16
	cmp	x9, #1024
	b.ne	LBB0_5
; %bb.6:                                ; %llm_attention.contiguous_copy.exit292
	mov	x9, #0                          ; =0x0
	add	x14, x24, #3072
	mov.d	x10, v2[1]
	add	x10, x8, x10, lsl #2
LBB0_7:                                 ; %copy.chunk.i293
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q2, [x10, x9]
	str	q2, [x14, x9]
	add	x9, x9, #16
	cmp	x9, #1024
	b.ne	LBB0_7
; %bb.8:                                ; %llm_attention.contiguous_copy.exit296
	mov	x9, #0                          ; =0x0
	add	x14, x24, #1, lsl #12           ; =4096
	fmov	x10, d1
	add	x10, x8, x10, lsl #2
LBB0_9:                                 ; %copy.chunk.i297
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q2, [x10, x9]
	str	q2, [x14, x9]
	add	x9, x9, #16
	cmp	x9, #1024
	b.ne	LBB0_9
; %bb.10:                               ; %llm_attention.contiguous_copy.exit300
	mov	x9, #0                          ; =0x0
	mov	w10, #5120                      ; =0x1400
	add	x14, x24, x10
	mov.d	x10, v1[1]
	add	x10, x8, x10, lsl #2
LBB0_11:                                ; %copy.chunk.i301
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q1, [x10, x9]
	str	q1, [x14, x9]
	add	x9, x9, #16
	cmp	x9, #1024
	b.ne	LBB0_11
; %bb.12:                               ; %llm_attention.contiguous_copy.exit304
	mov	x9, #0                          ; =0x0
	mov	w10, #6144                      ; =0x1800
	add	x15, x24, x10
	fmov	x10, d0
	add	x10, x8, x10, lsl #2
LBB0_13:                                ; %copy.chunk.i305
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q1, [x10, x9]
	str	q1, [x15, x9]
	add	x9, x9, #16
	cmp	x9, #1024
	b.ne	LBB0_13
; %bb.14:                               ; %llm_attention.contiguous_copy.exit308
	str	x15, [sp, #3656]                ; 8-byte Spill
	str	x14, [sp, #3664]                ; 8-byte Spill
	add	x9, x24, #1, lsl #12            ; =4096
	str	x9, [sp, #3672]                 ; 8-byte Spill
	add	x9, x24, #3072
	str	x9, [sp, #3680]                 ; 8-byte Spill
	add	x9, x24, #2048
	str	x9, [sp, #3688]                 ; 8-byte Spill
	add	x9, x24, #1024
	str	x9, [sp, #3696]                 ; 8-byte Spill
	str	x13, [sp, #3728]                ; 8-byte Spill
	str	x12, [sp, #3712]                ; 8-byte Spill
	str	x11, [sp, #88]                  ; 8-byte Spill
	mov	x9, #0                          ; =0x0
	mov	w10, #7168                      ; =0x1c00
	add	x11, x24, x10
	mov.d	x10, v0[1]
	add	x8, x8, x10, lsl #2
LBB0_15:                                ; %copy.chunk.i309
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q0, [x8, x9]
	str	q0, [x11, x9]
	add	x9, x9, #16
	cmp	x9, #1024
	b.ne	LBB0_15
; %bb.16:                               ; %direct.true.preheader
	str	x11, [sp, #3648]                ; 8-byte Spill
	add	x8, x24, #2, lsl #12            ; =8192
	str	x8, [sp, #3720]                 ; 8-byte Spill
	add	x0, x24, #2, lsl #12            ; =8192
	mov	w1, #12288                      ; =0x3000
	bl	_bzero
	mov	w8, #56                         ; =0x38
	mov	x14, #0                         ; =0x0
	ldr	q6, [sp, #4960]                 ; 16-byte Reload
	shl.2d	v4, v6, #3
	mov	w10, #65                        ; =0x41
	mov	w11, #66                        ; =0x42
	ldr	q16, [sp, #4912]                ; 16-byte Reload
	shl.2d	v3, v16, #3
	mov	w12, #67                        ; =0x43
	mov	w13, #68                        ; =0x44
	ldr	q17, [sp, #4896]                ; 16-byte Reload
	shl.2d	v2, v17, #3
	mov	w0, #69                         ; =0x45
	mov	w15, #70                        ; =0x46
	ldr	q7, [sp, #4928]                 ; 16-byte Reload
	shl.2d	v1, v7, #3
	mov	w16, #71                        ; =0x47
	mov	w17, #72                        ; =0x48
	ushr.2d	v0, v16, #4
	fmov	x9, d0
	dup.2d	v0, x8
	stp	q1, q2, [sp, #16]               ; 32-byte Folded Spill
	and.16b	v1, v1, v0
	and.16b	v2, v2, v0
	stp	q3, q4, [sp, #48]               ; 32-byte Folded Spill
	and.16b	v3, v3, v0
	and.16b	v0, v4, v0
	dup.2d	v4, x10
	orr.16b	v5, v0, v4
	str	q5, [sp, #3632]                 ; 16-byte Spill
	orr.16b	v5, v3, v4
	str	q5, [sp, #3616]                 ; 16-byte Spill
	orr.16b	v5, v2, v4
	str	q5, [sp, #3600]                 ; 16-byte Spill
	orr.16b	v4, v1, v4
	str	q4, [sp, #3584]                 ; 16-byte Spill
	dup.2d	v4, x11
	orr.16b	v5, v0, v4
	str	q5, [sp, #3568]                 ; 16-byte Spill
	orr.16b	v5, v3, v4
	str	q5, [sp, #3552]                 ; 16-byte Spill
	orr.16b	v5, v2, v4
	str	q5, [sp, #3536]                 ; 16-byte Spill
	orr.16b	v4, v1, v4
	str	q4, [sp, #3520]                 ; 16-byte Spill
	dup.2d	v4, x12
	orr.16b	v5, v0, v4
	str	q5, [sp, #3504]                 ; 16-byte Spill
	orr.16b	v5, v3, v4
	str	q5, [sp, #3488]                 ; 16-byte Spill
	orr.16b	v5, v2, v4
	str	q5, [sp, #3472]                 ; 16-byte Spill
	orr.16b	v4, v1, v4
	str	q4, [sp, #3456]                 ; 16-byte Spill
	dup.2d	v4, x13
	orr.16b	v5, v0, v4
	str	q5, [sp, #3440]                 ; 16-byte Spill
	orr.16b	v5, v3, v4
	str	q5, [sp, #3424]                 ; 16-byte Spill
	orr.16b	v5, v2, v4
	str	q5, [sp, #3408]                 ; 16-byte Spill
	orr.16b	v4, v1, v4
	str	q4, [sp, #3392]                 ; 16-byte Spill
	dup.2d	v4, x0
	orr.16b	v5, v0, v4
	str	q5, [sp, #3376]                 ; 16-byte Spill
	orr.16b	v5, v3, v4
	str	q5, [sp, #3360]                 ; 16-byte Spill
	orr.16b	v5, v2, v4
	str	q5, [sp, #3344]                 ; 16-byte Spill
	orr.16b	v4, v1, v4
	str	q4, [sp, #3328]                 ; 16-byte Spill
	dup.2d	v4, x15
	orr.16b	v5, v0, v4
	str	q5, [sp, #3312]                 ; 16-byte Spill
	orr.16b	v5, v3, v4
	str	q5, [sp, #3296]                 ; 16-byte Spill
	orr.16b	v5, v2, v4
	str	q5, [sp, #3280]                 ; 16-byte Spill
	orr.16b	v4, v1, v4
	str	q4, [sp, #3264]                 ; 16-byte Spill
	dup.2d	v4, x16
	orr.16b	v5, v0, v4
	str	q5, [sp, #3248]                 ; 16-byte Spill
	orr.16b	v5, v3, v4
	str	q5, [sp, #3232]                 ; 16-byte Spill
	orr.16b	v5, v2, v4
	str	q5, [sp, #3216]                 ; 16-byte Spill
	orr.16b	v4, v1, v4
	str	q4, [sp, #3200]                 ; 16-byte Spill
	dup.2d	v4, x17
	add.2d	v0, v0, v4
	str	q0, [sp, #3184]                 ; 16-byte Spill
	add.2d	v0, v3, v4
	str	q0, [sp, #3168]                 ; 16-byte Spill
	add.2d	v0, v2, v4
	str	q0, [sp, #3152]                 ; 16-byte Spill
	add.2d	v0, v1, v4
	str	q0, [sp, #3136]                 ; 16-byte Spill
	shrn.2s	v0, v7, #4
	shrn.2s	v1, v17, #4
	shrn.2s	v2, v6, #4
	shrn.2s	v3, v16, #4
	movi.2s	v4, #129
	umull.2d	v3, v3, v4
	umull.2d	v2, v2, v4
	stp	q2, q3, [sp, #128]              ; 32-byte Folded Spill
	umull.2d	v1, v1, v4
	umull.2d	v0, v0, v4
	stp	q0, q1, [sp, #96]               ; 32-byte Folded Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #1664
	str	x8, [sp, #3128]                 ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x19, x8, #3200
	add	x8, x24, #25, lsl #12           ; =102400
	add	x8, x8, #3200
	str	x8, [sp, #3120]                 ; 8-byte Spill
	mov	w8, #34816                      ; =0x8800
	add	x17, x24, x8
	mov	w8, #38912                      ; =0x9800
	add	x1, x24, x8
	mov	w8, #43008                      ; =0xa800
	add	x2, x24, x8
	mov	w8, #47104                      ; =0xb800
	add	x3, x24, x8
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #3712
	str	x8, [sp, #3080]                 ; 8-byte Spill
	mov	w8, #52224                      ; =0xcc00
	add	x23, x24, x8
	add	x8, x24, #22, lsl #12           ; =90112
	add	x8, x8, #128
	str	x8, [sp, #3072]                 ; 8-byte Spill
	mov	w8, #55296                      ; =0xd800
	add	x21, x24, x8
	add	x8, x24, #22, lsl #12           ; =90112
	add	x8, x8, #640
	str	x8, [sp, #3064]                 ; 8-byte Spill
	mov	w8, #58368                      ; =0xe400
	add	x22, x24, x8
	add	x8, x24, #22, lsl #12           ; =90112
	add	x8, x8, #1152
	str	x8, [sp, #3056]                 ; 8-byte Spill
	add	x8, x24, #22, lsl #12           ; =90112
	add	x8, x8, #1664
	str	x8, [sp, #3048]                 ; 8-byte Spill
	mov	w8, #64512                      ; =0xfc00
	add	x26, x24, x8
	add	x8, x24, #22, lsl #12           ; =90112
	add	x8, x8, #2176
	str	x8, [sp, #3040]                 ; 8-byte Spill
	add	x8, x24, #16, lsl #12           ; =65536
	add	x28, x8, #2048
	add	x8, x24, #22, lsl #12           ; =90112
	add	x20, x8, #2688
	add	x8, x24, #17, lsl #12           ; =69632
	add	x27, x8, #1024
	mov	w8, #16512                      ; =0x4080
	ldp	x10, x11, [sp, #160]            ; 16-byte Folded Reload
	umaddl	x8, w9, w8, x11
	add	x13, x8, #4, lsl #12            ; =16384
	mov	w8, #24768                      ; =0x60c0
	umaddl	x8, w9, w8, x10
	add	x4, x8, #6, lsl #12             ; =24576
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #192
	str	x8, [sp, #3016]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #256
	str	x8, [sp, #3008]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #320
	str	x8, [sp, #3000]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #384
	str	x8, [sp, #2992]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #448
	str	x8, [sp, #2984]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #512
	str	x8, [sp, #2976]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #576
	str	x8, [sp, #2968]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #640
	str	x8, [sp, #2960]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #704
	str	x8, [sp, #2952]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #768
	str	x8, [sp, #2944]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #832
	str	x8, [sp, #2936]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #896
	str	x8, [sp, #2928]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #960
	str	x8, [sp, #2920]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #1024
	str	x8, [sp, #2912]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #1088
	str	x8, [sp, #2904]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #1216
	str	x8, [sp, #2896]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #1280
	str	x8, [sp, #2888]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #1344
	str	x8, [sp, #2880]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #1408
	str	x8, [sp, #2872]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #1472
	str	x8, [sp, #2864]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #1536
	str	x8, [sp, #2856]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #1600
	str	x8, [sp, #2848]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #2720
	str	x8, [sp, #2840]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #2752
	str	x8, [sp, #2832]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #2784
	str	x8, [sp, #2824]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #2816
	str	x8, [sp, #2816]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #2848
	str	x8, [sp, #2808]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #2880
	str	x8, [sp, #2800]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #2912
	str	x8, [sp, #2792]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #2944
	str	x8, [sp, #2784]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #2976
	str	x8, [sp, #2776]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3008
	str	x8, [sp, #2768]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3040
	str	x8, [sp, #2760]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3072
	str	x8, [sp, #2752]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3104
	str	x8, [sp, #2744]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3136
	str	x8, [sp, #2736]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3168
	str	x8, [sp, #2728]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3200
	str	x8, [sp, #2720]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3232
	str	x8, [sp, #2712]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3264
	str	x8, [sp, #2704]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3296
	str	x8, [sp, #2696]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3328
	str	x8, [sp, #2688]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
Lloh4:
	adrp	x9, lCPI0_6@PAGE
	dup.2d	v17, x8
Lloh5:
	ldr	q0, [x9, lCPI0_6@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #2656]                 ; 16-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3360
	str	x8, [sp, #2648]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3392
	str	x8, [sp, #2640]                 ; 8-byte Spill
Lloh6:
	adrp	x8, lCPI0_7@PAGE
Lloh7:
	ldr	q0, [x8, lCPI0_7@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #2624]                 ; 16-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3424
	str	x8, [sp, #2616]                 ; 8-byte Spill
Lloh8:
	adrp	x8, lCPI0_8@PAGE
Lloh9:
	ldr	q0, [x8, lCPI0_8@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #2592]                 ; 16-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3456
	str	x8, [sp, #2584]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3488
	str	x8, [sp, #2576]                 ; 8-byte Spill
Lloh10:
	adrp	x8, lCPI0_9@PAGE
Lloh11:
	ldr	q0, [x8, lCPI0_9@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #2560]                 ; 16-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3520
	str	x8, [sp, #2552]                 ; 8-byte Spill
Lloh12:
	adrp	x8, lCPI0_10@PAGE
Lloh13:
	ldr	q0, [x8, lCPI0_10@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #2528]                 ; 16-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3552
	str	x8, [sp, #2520]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3584
	str	x8, [sp, #2512]                 ; 8-byte Spill
Lloh14:
	adrp	x8, lCPI0_11@PAGE
Lloh15:
	ldr	q0, [x8, lCPI0_11@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #2496]                 ; 16-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3616
	str	x8, [sp, #2488]                 ; 8-byte Spill
Lloh16:
	adrp	x8, lCPI0_12@PAGE
Lloh17:
	ldr	q0, [x8, lCPI0_12@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #2464]                 ; 16-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3648
	str	x8, [sp, #2456]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3680
	str	x8, [sp, #2448]                 ; 8-byte Spill
Lloh18:
	adrp	x8, lCPI0_13@PAGE
Lloh19:
	ldr	q0, [x8, lCPI0_13@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #2432]                 ; 16-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3712
	str	x8, [sp, #2424]                 ; 8-byte Spill
Lloh20:
	adrp	x8, lCPI0_14@PAGE
Lloh21:
	ldr	q0, [x8, lCPI0_14@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #2400]                 ; 16-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3744
	str	x8, [sp, #2392]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3776
	str	x8, [sp, #2384]                 ; 8-byte Spill
Lloh22:
	adrp	x8, lCPI0_15@PAGE
Lloh23:
	ldr	q0, [x8, lCPI0_15@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #2368]                 ; 16-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3808
	str	x8, [sp, #2360]                 ; 8-byte Spill
Lloh24:
	adrp	x8, lCPI0_16@PAGE
Lloh25:
	ldr	q0, [x8, lCPI0_16@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #2336]                 ; 16-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3840
	str	x8, [sp, #2328]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3872
	str	x8, [sp, #2320]                 ; 8-byte Spill
Lloh26:
	adrp	x8, lCPI0_17@PAGE
Lloh27:
	ldr	q0, [x8, lCPI0_17@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #2304]                 ; 16-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3904
	str	x8, [sp, #2296]                 ; 8-byte Spill
Lloh28:
	adrp	x8, lCPI0_18@PAGE
Lloh29:
	ldr	q0, [x8, lCPI0_18@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #2272]                 ; 16-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3936
	str	x8, [sp, #2264]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #3968
	str	x8, [sp, #2256]                 ; 8-byte Spill
Lloh30:
	adrp	x8, lCPI0_19@PAGE
Lloh31:
	ldr	q0, [x8, lCPI0_19@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #2240]                 ; 16-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #4000
	str	x8, [sp, #2232]                 ; 8-byte Spill
Lloh32:
	adrp	x8, lCPI0_20@PAGE
Lloh33:
	ldr	q0, [x8, lCPI0_20@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #2208]                 ; 16-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #4032
	str	x8, [sp, #2200]                 ; 8-byte Spill
	add	x8, x24, #20, lsl #12           ; =81920
	add	x8, x8, #4064
	str	x8, [sp, #2192]                 ; 8-byte Spill
Lloh34:
	adrp	x8, lCPI0_21@PAGE
Lloh35:
	ldr	q0, [x8, lCPI0_21@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #2176]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #32
	str	x8, [sp, #2168]                 ; 8-byte Spill
Lloh36:
	adrp	x8, lCPI0_22@PAGE
Lloh37:
	ldr	q0, [x8, lCPI0_22@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #2144]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #64
	str	x8, [sp, #2136]                 ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #96
	str	x8, [sp, #2128]                 ; 8-byte Spill
Lloh38:
	adrp	x8, lCPI0_23@PAGE
Lloh39:
	ldr	q0, [x8, lCPI0_23@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #2112]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #128
	str	x8, [sp, #2104]                 ; 8-byte Spill
Lloh40:
	adrp	x8, lCPI0_24@PAGE
Lloh41:
	ldr	q0, [x8, lCPI0_24@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #2080]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #160
	str	x8, [sp, #2072]                 ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #192
	str	x8, [sp, #2064]                 ; 8-byte Spill
Lloh42:
	adrp	x8, lCPI0_25@PAGE
Lloh43:
	ldr	q0, [x8, lCPI0_25@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #2048]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #224
	str	x8, [sp, #2040]                 ; 8-byte Spill
Lloh44:
	adrp	x8, lCPI0_26@PAGE
Lloh45:
	ldr	q0, [x8, lCPI0_26@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #2016]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #256
	str	x8, [sp, #2008]                 ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #288
	str	x8, [sp, #2000]                 ; 8-byte Spill
Lloh46:
	adrp	x8, lCPI0_27@PAGE
Lloh47:
	ldr	q0, [x8, lCPI0_27@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1984]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #320
	str	x8, [sp, #1976]                 ; 8-byte Spill
Lloh48:
	adrp	x8, lCPI0_28@PAGE
Lloh49:
	ldr	q0, [x8, lCPI0_28@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1952]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #352
	str	x8, [sp, #1944]                 ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #384
	str	x8, [sp, #1936]                 ; 8-byte Spill
Lloh50:
	adrp	x8, lCPI0_29@PAGE
Lloh51:
	ldr	q0, [x8, lCPI0_29@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1920]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #416
	str	x8, [sp, #1912]                 ; 8-byte Spill
Lloh52:
	adrp	x8, lCPI0_30@PAGE
Lloh53:
	ldr	q0, [x8, lCPI0_30@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1888]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #448
	str	x8, [sp, #1880]                 ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #480
	str	x8, [sp, #1872]                 ; 8-byte Spill
Lloh54:
	adrp	x8, lCPI0_31@PAGE
Lloh55:
	ldr	q0, [x8, lCPI0_31@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1856]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #512
	str	x8, [sp, #1848]                 ; 8-byte Spill
Lloh56:
	adrp	x8, lCPI0_32@PAGE
Lloh57:
	ldr	q0, [x8, lCPI0_32@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1824]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #544
	str	x8, [sp, #1816]                 ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #576
	str	x8, [sp, #1808]                 ; 8-byte Spill
Lloh58:
	adrp	x8, lCPI0_33@PAGE
Lloh59:
	ldr	q0, [x8, lCPI0_33@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1792]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #608
	str	x8, [sp, #1784]                 ; 8-byte Spill
Lloh60:
	adrp	x8, lCPI0_34@PAGE
Lloh61:
	ldr	q0, [x8, lCPI0_34@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1760]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #640
	str	x8, [sp, #1752]                 ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #672
	str	x8, [sp, #1744]                 ; 8-byte Spill
Lloh62:
	adrp	x8, lCPI0_35@PAGE
Lloh63:
	ldr	q0, [x8, lCPI0_35@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1728]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #704
	str	x8, [sp, #1720]                 ; 8-byte Spill
Lloh64:
	adrp	x8, lCPI0_36@PAGE
Lloh65:
	ldr	q0, [x8, lCPI0_36@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1696]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #736
	str	x8, [sp, #1688]                 ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #768
	str	x8, [sp, #1680]                 ; 8-byte Spill
Lloh66:
	adrp	x8, lCPI0_37@PAGE
Lloh67:
	ldr	q0, [x8, lCPI0_37@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1664]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #800
	str	x8, [sp, #1656]                 ; 8-byte Spill
Lloh68:
	adrp	x8, lCPI0_38@PAGE
Lloh69:
	ldr	q0, [x8, lCPI0_38@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1632]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #832
	str	x8, [sp, #1624]                 ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #864
	str	x8, [sp, #1616]                 ; 8-byte Spill
Lloh70:
	adrp	x8, lCPI0_39@PAGE
Lloh71:
	ldr	q0, [x8, lCPI0_39@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1600]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #896
	str	x8, [sp, #1592]                 ; 8-byte Spill
Lloh72:
	adrp	x8, lCPI0_40@PAGE
Lloh73:
	ldr	q0, [x8, lCPI0_40@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1568]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #928
	str	x8, [sp, #1560]                 ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #960
	str	x8, [sp, #1552]                 ; 8-byte Spill
Lloh74:
	adrp	x8, lCPI0_41@PAGE
Lloh75:
	ldr	q0, [x8, lCPI0_41@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1536]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #992
	str	x8, [sp, #1528]                 ; 8-byte Spill
Lloh76:
	adrp	x8, lCPI0_42@PAGE
Lloh77:
	ldr	q0, [x8, lCPI0_42@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1504]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1024
	str	x8, [sp, #1496]                 ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1056
	str	x8, [sp, #1488]                 ; 8-byte Spill
Lloh78:
	adrp	x8, lCPI0_43@PAGE
Lloh79:
	ldr	q0, [x8, lCPI0_43@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1472]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1088
	str	x8, [sp, #1464]                 ; 8-byte Spill
Lloh80:
	adrp	x8, lCPI0_44@PAGE
Lloh81:
	ldr	q0, [x8, lCPI0_44@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1440]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1120
	str	x8, [sp, #1432]                 ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1152
	str	x8, [sp, #1424]                 ; 8-byte Spill
Lloh82:
	adrp	x8, lCPI0_45@PAGE
Lloh83:
	ldr	q0, [x8, lCPI0_45@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1408]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1184
	str	x8, [sp, #1400]                 ; 8-byte Spill
Lloh84:
	adrp	x8, lCPI0_46@PAGE
Lloh85:
	ldr	q0, [x8, lCPI0_46@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1376]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1216
	str	x8, [sp, #1368]                 ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1248
	str	x8, [sp, #1360]                 ; 8-byte Spill
Lloh86:
	adrp	x8, lCPI0_47@PAGE
Lloh87:
	ldr	q0, [x8, lCPI0_47@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1344]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1280
	str	x8, [sp, #1336]                 ; 8-byte Spill
Lloh88:
	adrp	x8, lCPI0_48@PAGE
Lloh89:
	ldr	q0, [x8, lCPI0_48@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1312]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1312
	str	x8, [sp, #1304]                 ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1344
	str	x8, [sp, #1296]                 ; 8-byte Spill
Lloh90:
	adrp	x8, lCPI0_49@PAGE
Lloh91:
	ldr	q0, [x8, lCPI0_49@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1280]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1376
	str	x8, [sp, #1272]                 ; 8-byte Spill
Lloh92:
	adrp	x8, lCPI0_50@PAGE
Lloh93:
	ldr	q0, [x8, lCPI0_50@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1248]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1408
	str	x8, [sp, #1240]                 ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1440
	str	x8, [sp, #1232]                 ; 8-byte Spill
Lloh94:
	adrp	x8, lCPI0_51@PAGE
Lloh95:
	ldr	q0, [x8, lCPI0_51@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1216]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1472
	str	x8, [sp, #1208]                 ; 8-byte Spill
Lloh96:
	adrp	x8, lCPI0_52@PAGE
Lloh97:
	ldr	q0, [x8, lCPI0_52@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1184]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1504
	str	x8, [sp, #1176]                 ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1536
	str	x8, [sp, #1168]                 ; 8-byte Spill
Lloh98:
	adrp	x8, lCPI0_53@PAGE
Lloh99:
	ldr	q0, [x8, lCPI0_53@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1152]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1568
	str	x8, [sp, #1144]                 ; 8-byte Spill
Lloh100:
	adrp	x8, lCPI0_54@PAGE
Lloh101:
	ldr	q0, [x8, lCPI0_54@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1120]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1600
	str	x8, [sp, #1112]                 ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1632
	str	x8, [sp, #1104]                 ; 8-byte Spill
Lloh102:
	adrp	x8, lCPI0_55@PAGE
Lloh103:
	ldr	q0, [x8, lCPI0_55@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1088]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1664
	str	x8, [sp, #1080]                 ; 8-byte Spill
Lloh104:
	adrp	x8, lCPI0_56@PAGE
Lloh105:
	ldr	q0, [x8, lCPI0_56@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1056]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1696
	str	x8, [sp, #1048]                 ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1728
	str	x8, [sp, #1040]                 ; 8-byte Spill
Lloh106:
	adrp	x8, lCPI0_57@PAGE
Lloh107:
	ldr	q0, [x8, lCPI0_57@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #1024]                 ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1760
	str	x8, [sp, #1016]                 ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1792
	str	x8, [sp, #1008]                 ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1824
	str	x8, [sp, #1000]                 ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1856
	str	x8, [sp, #992]                  ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1888
	str	x8, [sp, #984]                  ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1920
	str	x8, [sp, #976]                  ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1952
	str	x8, [sp, #968]                  ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #1984
	str	x8, [sp, #960]                  ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #2016
	str	x8, [sp, #952]                  ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #2048
	str	x8, [sp, #944]                  ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #2080
	str	x8, [sp, #936]                  ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #2112
	str	x8, [sp, #928]                  ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #2144
	str	x8, [sp, #920]                  ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #2176
	str	x8, [sp, #912]                  ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #2208
	str	x8, [sp, #904]                  ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #2240
	str	x8, [sp, #896]                  ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #2272
	str	x8, [sp, #888]                  ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #2304
	str	x8, [sp, #880]                  ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #2336
	str	x8, [sp, #872]                  ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #2368
	str	x8, [sp, #864]                  ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	movi.2d	v2, #0000000000000000
	movi.2d	v4, #0000000000000000
	add	x8, x8, #2400
	str	x8, [sp, #856]                  ; 8-byte Spill
Lloh108:
	adrp	x8, lCPI0_83@PAGE
Lloh109:
	adrp	x9, lCPI0_84@PAGE
	movi.2d	v1, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v6, #0000000000000000
Lloh110:
	adrp	x10, lCPI0_85@PAGE
	mvni.4s	v0, #63, msl #16
Lloh111:
	ldr	q5, [x8, lCPI0_83@PAGEOFF]
	str	q5, [sp, #832]                  ; 16-byte Spill
Lloh112:
	ldr	q5, [x9, lCPI0_84@PAGEOFF]
	str	q5, [sp, #816]                  ; 16-byte Spill
Lloh113:
	ldr	q5, [x10, lCPI0_85@PAGEOFF]
	str	q5, [sp, #800]                  ; 16-byte Spill
	movi.2d	v5, #0000000000000000
	fneg.4s	v18, v0
Lloh114:
	adrp	x8, lCPI0_82@PAGE
	movi.4s	v26, #63, lsl #24
Lloh115:
	ldr	q0, [x8, lCPI0_82@PAGEOFF]
	str	q0, [sp, #768]                  ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #2432
	str	x8, [sp, #760]                  ; 8-byte Spill
Lloh116:
	adrp	x8, lCPI0_74@PAGE
	movi.8b	v19, #1
	movi.4s	v20, #75, lsl #24
Lloh117:
	adrp	x9, lCPI0_80@PAGE
Lloh118:
	adrp	x10, lCPI0_81@PAGE
Lloh119:
	adrp	x11, lCPI0_79@PAGE
Lloh120:
	ldr	q21, [x11, lCPI0_79@PAGEOFF]
Lloh121:
	ldr	q25, [x9, lCPI0_80@PAGEOFF]
Lloh122:
	ldr	q31, [x10, lCPI0_81@PAGEOFF]
Lloh123:
	adrp	x9, lCPI0_77@PAGE
Lloh124:
	adrp	x10, lCPI0_78@PAGE
Lloh125:
	adrp	x11, lCPI0_76@PAGE
Lloh126:
	ldr	q11, [x11, lCPI0_76@PAGEOFF]
Lloh127:
	ldr	q29, [x9, lCPI0_77@PAGEOFF]
Lloh128:
	ldr	q27, [x10, lCPI0_78@PAGEOFF]
Lloh129:
	adrp	x9, lCPI0_75@PAGE
Lloh130:
	adrp	x10, lCPI0_58@PAGE
Lloh131:
	ldr	q0, [x10, lCPI0_58@PAGEOFF]
	movi.2d	v24, #0000000000000000
Lloh132:
	ldr	q28, [x8, lCPI0_74@PAGEOFF]
Lloh133:
	ldr	q30, [x9, lCPI0_75@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #736]                  ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #2464
	str	x8, [sp, #728]                  ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #2496
	str	x8, [sp, #720]                  ; 8-byte Spill
Lloh134:
	adrp	x8, lCPI0_59@PAGE
Lloh135:
	ldr	q0, [x8, lCPI0_59@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #704]                  ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #2528
	str	x8, [sp, #696]                  ; 8-byte Spill
Lloh136:
	adrp	x8, lCPI0_60@PAGE
Lloh137:
	ldr	q0, [x8, lCPI0_60@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #672]                  ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #2560
	str	x8, [sp, #664]                  ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #2592
	str	x8, [sp, #656]                  ; 8-byte Spill
Lloh138:
	adrp	x8, lCPI0_61@PAGE
Lloh139:
	ldr	q0, [x8, lCPI0_61@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #640]                  ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #2624
	str	x8, [sp, #632]                  ; 8-byte Spill
Lloh140:
	adrp	x8, lCPI0_62@PAGE
Lloh141:
	ldr	q0, [x8, lCPI0_62@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #608]                  ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #2656
	str	x8, [sp, #600]                  ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #2720
	str	x8, [sp, #592]                  ; 8-byte Spill
Lloh142:
	adrp	x8, lCPI0_63@PAGE
Lloh143:
	ldr	q0, [x8, lCPI0_63@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #576]                  ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #2752
	str	x8, [sp, #568]                  ; 8-byte Spill
Lloh144:
	adrp	x8, lCPI0_64@PAGE
Lloh145:
	ldr	q0, [x8, lCPI0_64@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #544]                  ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #2784
	str	x8, [sp, #536]                  ; 8-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #2816
	str	x8, [sp, #528]                  ; 8-byte Spill
Lloh146:
	adrp	x8, lCPI0_65@PAGE
Lloh147:
	ldr	q0, [x8, lCPI0_65@PAGEOFF]
	add.2d	v0, v17, v0
	str	q0, [sp, #512]                  ; 16-byte Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x9, x8, #2848
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #2880
	stp	x8, x9, [sp, #496]              ; 16-byte Folded Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x9, x8, #2912
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #2976
	stp	x8, x9, [sp, #480]              ; 16-byte Folded Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x9, x8, #3008
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #3040
	stp	x8, x9, [sp, #464]              ; 16-byte Folded Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x9, x8, #3072
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #3104
	stp	x8, x9, [sp, #448]              ; 16-byte Folded Spill
	add	x8, x24, #21, lsl #12           ; =86016
	add	x9, x8, #3136
	add	x8, x24, #21, lsl #12           ; =86016
	add	x8, x8, #3168
	stp	x8, x9, [sp, #432]              ; 16-byte Folded Spill
	add	x5, x24, #8, lsl #12            ; =32768
	add	x6, x24, #12, lsl #12           ; =49152
	add	x7, x24, #18, lsl #12           ; =73728
	ldr	x16, [sp, #3728]                ; 8-byte Reload
	add	x9, x16, #3584
	mov	w8, #16512                      ; =0x4080
	movk	w8, #1, lsl #16
	add	x8, x24, x8
	stp	x8, x9, [sp, #400]              ; 16-byte Folded Spill
	mov	w8, #17536                      ; =0x4480
	movk	w8, #1, lsl #16
	add	x8, x24, x8
	str	x8, [sp, #392]                  ; 8-byte Spill
	mov	w8, #19072                      ; =0x4a80
	movk	w8, #1, lsl #16
	add	x8, x24, x8
	str	x8, [sp, #384]                  ; 8-byte Spill
	mov	w8, #23168                      ; =0x5a80
	movk	w8, #1, lsl #16
	add	x8, x24, x8
	str	x8, [sp, #376]                  ; 8-byte Spill
	mov	w8, #23424                      ; =0x5b80
	movk	w8, #1, lsl #16
	add	x8, x24, x8
	str	x8, [sp, #368]                  ; 8-byte Spill
	add	x30, x24, #9, lsl #12           ; =36864
	add	x8, x24, #10, lsl #12           ; =40960
	str	x8, [sp, #3752]                 ; 8-byte Spill
	add	x8, x24, #11, lsl #12           ; =45056
	str	x8, [sp, #3744]                 ; 8-byte Spill
	str	x24, [sp, #4952]                ; 8-byte Spill
	add	x8, x24, #15, lsl #12           ; =61440
	str	x8, [sp, #3736]                 ; 8-byte Spill
	mov	w9, #62154                      ; =0xf2ca
	movk	w9, #61769, lsl #16
Lloh148:
	adrp	x8, lCPI0_4@PAGE
Lloh149:
	ldr	q8, [x8, lCPI0_4@PAGEOFF]
	add.2d	v0, v17, v8
	str	q0, [sp, #320]                  ; 16-byte Spill
	fmov	x8, d0
	str	x8, [sp, #312]                  ; 8-byte Spill
Lloh150:
	adrp	x8, lCPI0_3@PAGE
Lloh151:
	ldr	q9, [x8, lCPI0_3@PAGEOFF]
	add.2d	v0, v17, v9
	str	q0, [sp, #272]                  ; 16-byte Spill
	fmov	x8, d0
	str	x8, [sp, #264]                  ; 8-byte Spill
Lloh152:
	adrp	x8, lCPI0_2@PAGE
Lloh153:
	ldr	q10, [x8, lCPI0_2@PAGEOFF]
	add.2d	v0, v17, v10
	str	q0, [sp, #224]                  ; 16-byte Spill
	fmov	x8, d0
	str	x8, [sp, #216]                  ; 8-byte Spill
	mov	w25, #48                        ; =0x30
	mov	x24, #-6148914691236517206      ; =0xaaaaaaaaaaaaaaaa
	movk	x24, #43691
Lloh154:
	adrp	x8, lCPI0_5@PAGE
Lloh155:
	ldr	q14, [x8, lCPI0_5@PAGEOFF]
	add.2d	v0, v17, v14
	str	q0, [sp, #176]                  ; 16-byte Spill
	dup.4s	v22, w9
	movi.2d	v0, #0000000000000000
	movi.2d	v13, #0000000000000000
	movi.2d	v15, #0000000000000000
	movi.2d	v7, #0000000000000000
	str	q7, [sp, #4448]                 ; 16-byte Spill
	str	q7, [sp, #4432]                 ; 16-byte Spill
	str	q7, [sp, #4416]                 ; 16-byte Spill
	str	q7, [sp, #4400]                 ; 16-byte Spill
	str	q7, [sp, #4384]                 ; 16-byte Spill
	movi.2d	v12, #0000000000000000
	str	q22, [sp, #4208]                ; 16-byte Spill
	str	q22, [sp, #4496]                ; 16-byte Spill
	str	q22, [sp, #4512]                ; 16-byte Spill
	str	q22, [sp, #4560]                ; 16-byte Spill
	str	q22, [sp, #4576]                ; 16-byte Spill
	str	q22, [sp, #4624]                ; 16-byte Spill
	str	q22, [sp, #4640]                ; 16-byte Spill
	str	q22, [sp, #4688]                ; 16-byte Spill
	str	q22, [sp, #4704]                ; 16-byte Spill
	str	q22, [sp, #4752]                ; 16-byte Spill
	str	q22, [sp, #4768]                ; 16-byte Spill
	str	q22, [sp, #4816]                ; 16-byte Spill
	str	q22, [sp, #4832]                ; 16-byte Spill
	mov.16b	v23, v22
	str	q22, [sp, #4224]                ; 16-byte Spill
	str	x17, [sp, #3112]                ; 8-byte Spill
	str	x1, [sp, #3104]                 ; 8-byte Spill
	str	x2, [sp, #3096]                 ; 8-byte Spill
	str	x3, [sp, #3088]                 ; 8-byte Spill
	str	x13, [sp, #3032]                ; 8-byte Spill
	str	x4, [sp, #3024]                 ; 8-byte Spill
	str	q17, [sp, #2672]                ; 16-byte Spill
	str	q18, [sp, #784]                 ; 16-byte Spill
	str	q21, [sp, #4352]                ; 16-byte Spill
	str	q25, [sp, #4336]                ; 16-byte Spill
	str	q31, [sp, #4320]                ; 16-byte Spill
	str	q11, [sp, #4304]                ; 16-byte Spill
	str	q29, [sp, #4288]                ; 16-byte Spill
	str	q27, [sp, #4272]                ; 16-byte Spill
	str	q28, [sp, #4256]                ; 16-byte Spill
	str	q30, [sp, #4960]                ; 16-byte Spill
	stp	x7, x5, [sp, #416]              ; 16-byte Folded Spill
	str	x6, [sp, #4248]                 ; 8-byte Spill
	str	x30, [sp, #360]                 ; 8-byte Spill
	str	q8, [sp, #336]                  ; 16-byte Spill
	str	q9, [sp, #288]                  ; 16-byte Spill
	str	q10, [sp, #240]                 ; 16-byte Spill
	str	q14, [sp, #192]                 ; 16-byte Spill
LBB0_17:                                ; %direct.true216
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_23 Depth 2
                                        ;     Child Loop BB0_25 Depth 2
                                        ;     Child Loop BB0_27 Depth 2
                                        ;     Child Loop BB0_29 Depth 2
                                        ;     Child Loop BB0_31 Depth 2
                                        ;     Child Loop BB0_33 Depth 2
                                        ;     Child Loop BB0_35 Depth 2
                                        ;     Child Loop BB0_37 Depth 2
                                        ;     Child Loop BB0_39 Depth 2
                                        ;     Child Loop BB0_41 Depth 2
                                        ;     Child Loop BB0_43 Depth 2
                                        ;     Child Loop BB0_45 Depth 2
                                        ;     Child Loop BB0_47 Depth 2
                                        ;     Child Loop BB0_49 Depth 2
                                        ;     Child Loop BB0_51 Depth 2
                                        ;     Child Loop BB0_53 Depth 2
                                        ;     Child Loop BB0_20 Depth 2
                                        ;     Child Loop BB0_133 Depth 2
                                        ;     Child Loop BB0_55 Depth 2
                                        ;     Child Loop BB0_57 Depth 2
                                        ;     Child Loop BB0_59 Depth 2
                                        ;     Child Loop BB0_61 Depth 2
                                        ;     Child Loop BB0_63 Depth 2
                                        ;     Child Loop BB0_65 Depth 2
                                        ;     Child Loop BB0_67 Depth 2
                                        ;     Child Loop BB0_69 Depth 2
                                        ;     Child Loop BB0_71 Depth 2
                                        ;     Child Loop BB0_73 Depth 2
                                        ;     Child Loop BB0_75 Depth 2
                                        ;     Child Loop BB0_77 Depth 2
                                        ;     Child Loop BB0_79 Depth 2
                                        ;     Child Loop BB0_81 Depth 2
                                        ;     Child Loop BB0_83 Depth 2
                                        ;     Child Loop BB0_85 Depth 2
                                        ;     Child Loop BB0_87 Depth 2
                                        ;     Child Loop BB0_89 Depth 2
                                        ;     Child Loop BB0_91 Depth 2
                                        ;     Child Loop BB0_93 Depth 2
                                        ;     Child Loop BB0_95 Depth 2
                                        ;     Child Loop BB0_97 Depth 2
                                        ;       Child Loop BB0_98 Depth 3
                                        ;     Child Loop BB0_101 Depth 2
                                        ;       Child Loop BB0_102 Depth 3
                                        ;     Child Loop BB0_105 Depth 2
                                        ;       Child Loop BB0_106 Depth 3
                                        ;     Child Loop BB0_109 Depth 2
                                        ;       Child Loop BB0_110 Depth 3
                                        ;     Child Loop BB0_113 Depth 2
                                        ;       Child Loop BB0_114 Depth 3
                                        ;     Child Loop BB0_117 Depth 2
                                        ;       Child Loop BB0_118 Depth 3
                                        ;     Child Loop BB0_121 Depth 2
                                        ;       Child Loop BB0_122 Depth 3
                                        ;     Child Loop BB0_125 Depth 2
                                        ;       Child Loop BB0_126 Depth 3
                                        ;     Child Loop BB0_129 Depth 2
	str	q0, [sp, #4048]                 ; 16-byte Spill
	str	q24, [sp, #4080]                ; 16-byte Spill
	str	q6, [sp, #4096]                 ; 16-byte Spill
	str	q5, [sp, #4112]                 ; 16-byte Spill
	str	q4, [sp, #4128]                 ; 16-byte Spill
	str	q3, [sp, #4144]                 ; 16-byte Spill
	str	q2, [sp, #4160]                 ; 16-byte Spill
	str	q1, [sp, #4176]                 ; 16-byte Spill
	lsl	x0, x14, #4
	dup.2d	v24, x0
	cmp	x14, #8
	b.ne	LBB0_22
; %bb.18:                               ; %direct.true879.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	ldr	x15, [sp, #4952]                ; 8-byte Reload
	b	LBB0_20
LBB0_19:                                ; %direct.schedule.88
                                        ;   in Loop: Header=BB0_20 Depth=2
	dup.2d	v1, x9
Lloh156:
	adrp	x8, lCPI0_66@PAGE
Lloh157:
	ldr	q2, [x8, lCPI0_66@PAGEOFF]
Lloh158:
	adrp	x8, lCPI0_67@PAGE
Lloh159:
	ldr	q3, [x8, lCPI0_67@PAGEOFF]
Lloh160:
	adrp	x8, lCPI0_68@PAGE
Lloh161:
	ldr	q4, [x8, lCPI0_68@PAGEOFF]
	dup.2d	v5, x5
Lloh162:
	adrp	x8, lCPI0_69@PAGE
Lloh163:
	ldr	q6, [x8, lCPI0_69@PAGEOFF]
	add.2d	v1, v5, v1
	add.2d	v3, v1, v3
	add.2d	v2, v1, v2
	mov.d	x11, v2[1]
	fmov	x12, d2
	str	s0, [x12]
	st1.s	{ v0 }[1], [x11]
	mov.d	x11, v3[1]
	add.2d	v2, v1, v4
	fmov	x12, d3
	st1.s	{ v0 }[2], [x12]
	st1.s	{ v0 }[3], [x11]
	mov.d	x11, v2[1]
	fmov	x12, d2
	str	s0, [x12]
	st1.s	{ v0 }[1], [x11]
	add.2d	v1, v1, v6
	mov.d	x11, v1[1]
	fmov	x12, d1
	st1.s	{ v0 }[2], [x12]
	st1.s	{ v0 }[3], [x11]
	add	x10, x10, #1
	add	x9, x9, #4
	cmp	x9, #2048
	b.eq	LBB0_131
LBB0_20:                                ; %direct.true879
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	movi.2d	v0, #0000000000000000
	cmp	x10, #31
	b.hi	LBB0_19
; %bb.21:                               ; %direct.true892
                                        ;   in Loop: Header=BB0_20 Depth=2
	add	x8, x13, x9
	ld1r.4s	{ v0 }, [x8]
	b	LBB0_19
LBB0_22:                                ; %direct.true219
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	q0, [sp, #144]                  ; 16-byte Reload
	add.2d	v4, v24, v0
	ldp	q2, q0, [sp, #96]               ; 32-byte Folded Reload
	add.2d	v1, v24, v2
	add.2d	v2, v24, v0
	ldr	q0, [sp, #128]                  ; 16-byte Reload
	add.2d	v3, v24, v0
	shl.2d	v0, v3, #5
	shl.2d	v6, v2, #5
	shl.2d	v5, v1, #5
	shl.2d	v7, v4, #5
	fmov	x10, d7
	ldr	x8, [sp, #168]                  ; 8-byte Reload
	add	x10, x8, x10, lsl #2
	ldr	x15, [sp, #4952]                ; 8-byte Reload
LBB0_23:                                ; %copy.chunk.i313
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q16, [x10, x9]
	str	q16, [x5, x9]
	add	x9, x9, #16
	cmp	x9, #2048
	b.ne	LBB0_23
; %bb.24:                               ; %llm_attention.contiguous_copy.1.exit
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
	mov.d	x10, v7[1]
	add	x10, x8, x10, lsl #2
LBB0_25:                                ; %copy.chunk.i316
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q7, [x10, x9]
	str	q7, [x17, x9]
	add	x9, x9, #16
	cmp	x9, #2048
	b.ne	LBB0_25
; %bb.26:                               ; %llm_attention.contiguous_copy.1.exit319
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
	fmov	x10, d0
	add	x10, x8, x10, lsl #2
LBB0_27:                                ; %copy.chunk.i320
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q7, [x10, x9]
	str	q7, [x30, x9]
	add	x9, x9, #16
	cmp	x9, #2048
	b.ne	LBB0_27
; %bb.28:                               ; %llm_attention.contiguous_copy.1.exit323
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
	mov.d	x10, v0[1]
	add	x10, x8, x10, lsl #2
LBB0_29:                                ; %copy.chunk.i324
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x10, x9]
	str	q0, [x1, x9]
	add	x9, x9, #16
	cmp	x9, #2048
	b.ne	LBB0_29
; %bb.30:                               ; %llm_attention.contiguous_copy.1.exit327
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
	fmov	x10, d6
	add	x10, x8, x10, lsl #2
	ldr	x11, [sp, #3752]                ; 8-byte Reload
LBB0_31:                                ; %copy.chunk.i328
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x10, x9]
	str	q0, [x11, x9]
	add	x9, x9, #16
	cmp	x9, #2048
	b.ne	LBB0_31
; %bb.32:                               ; %llm_attention.contiguous_copy.1.exit331
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
	mov.d	x10, v6[1]
	add	x10, x8, x10, lsl #2
LBB0_33:                                ; %copy.chunk.i332
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x10, x9]
	str	q0, [x2, x9]
	add	x9, x9, #16
	cmp	x9, #2048
	b.ne	LBB0_33
; %bb.34:                               ; %llm_attention.contiguous_copy.1.exit335
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
	fmov	x10, d5
	add	x10, x8, x10, lsl #2
	ldr	x11, [sp, #3744]                ; 8-byte Reload
LBB0_35:                                ; %copy.chunk.i336
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x10, x9]
	str	q0, [x11, x9]
	add	x9, x9, #16
	cmp	x9, #2048
	b.ne	LBB0_35
; %bb.36:                               ; %llm_attention.contiguous_copy.1.exit339
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
	mov.d	x10, v5[1]
	add	x10, x8, x10, lsl #2
LBB0_37:                                ; %copy.chunk.i340
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x10, x9]
	str	q0, [x3, x9]
	add	x9, x9, #16
	cmp	x9, #2048
	b.ne	LBB0_37
; %bb.38:                               ; %direct.true245
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
	fmov	x10, d4
	add	x10, x10, x10, lsl #1
	lsl	x11, x10, #4
	fmov	d5, x11
	mov.d	x11, v4[1]
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #4
	mov.d	v5[1], x11
	fmov	x11, d3
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #4
	fmov	d0, x11
	mov.d	x11, v3[1]
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #4
	mov.d	v0[1], x11
	fmov	x11, d2
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #4
	fmov	d3, x11
	mov.d	x11, v2[1]
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #4
	mov.d	v3[1], x11
	fmov	x11, d1
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #4
	mov.d	x12, v1[1]
	fmov	d1, x11
	add	x11, x12, x12, lsl #1
	lsl	x11, x11, #4
	mov.d	v1[1], x11
	ldr	x8, [sp, #160]                  ; 8-byte Reload
	add	x10, x8, x10, lsl #6
LBB0_39:                                ; %copy.chunk.i344
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x10, x9]
	str	q2, [x6, x9]
	add	x9, x9, #16
	cmp	x9, #3072
	b.ne	LBB0_39
; %bb.40:                               ; %llm_attention.contiguous_copy.2.exit
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
	mov.d	x10, v5[1]
	add	x10, x8, x10, lsl #2
LBB0_41:                                ; %copy.chunk.i347
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x10, x9]
	str	q2, [x23, x9]
	add	x9, x9, #16
	cmp	x9, #3072
	b.ne	LBB0_41
; %bb.42:                               ; %llm_attention.contiguous_copy.2.exit350
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
	fmov	x10, d0
	add	x10, x8, x10, lsl #2
LBB0_43:                                ; %copy.chunk.i351
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x10, x9]
	str	q2, [x21, x9]
	add	x9, x9, #16
	cmp	x9, #3072
	b.ne	LBB0_43
; %bb.44:                               ; %llm_attention.contiguous_copy.2.exit354
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
	mov.d	x10, v0[1]
	add	x10, x8, x10, lsl #2
LBB0_45:                                ; %copy.chunk.i355
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x10, x9]
	str	q0, [x22, x9]
	add	x9, x9, #16
	cmp	x9, #3072
	b.ne	LBB0_45
; %bb.46:                               ; %llm_attention.contiguous_copy.2.exit358
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
	fmov	x10, d3
	add	x10, x8, x10, lsl #2
	ldr	x11, [sp, #3736]                ; 8-byte Reload
LBB0_47:                                ; %copy.chunk.i359
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x10, x9]
	str	q0, [x11, x9]
	add	x9, x9, #16
	cmp	x9, #3072
	b.ne	LBB0_47
; %bb.48:                               ; %llm_attention.contiguous_copy.2.exit362
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
	mov.d	x10, v3[1]
	add	x10, x8, x10, lsl #2
LBB0_49:                                ; %copy.chunk.i363
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x10, x9]
	str	q0, [x26, x9]
	add	x9, x9, #16
	cmp	x9, #3072
	b.ne	LBB0_49
; %bb.50:                               ; %llm_attention.contiguous_copy.2.exit366
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
	fmov	x10, d1
	add	x10, x8, x10, lsl #2
LBB0_51:                                ; %copy.chunk.i367
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x10, x9]
	str	q0, [x28, x9]
	add	x9, x9, #16
	cmp	x9, #3072
	b.ne	LBB0_51
; %bb.52:                               ; %llm_attention.contiguous_copy.2.exit370
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
	mov.d	x10, v1[1]
	add	x10, x8, x10, lsl #2
LBB0_53:                                ; %copy.chunk.i371
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x10, x9]
	str	q0, [x27, x9]
	add	x9, x9, #16
	cmp	x9, #3072
	b.ne	LBB0_53
LBB0_54:                                ; %direct.true272.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
LBB0_55:                                ; %direct.true272
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v0, x9
	dup.2d	v1, x7
	add.2d	v0, v1, v0
	add.2d	v1, v0, v29
	add.2d	v2, v0, v11
	add.2d	v3, v0, v30
	add.2d	v0, v0, v28
	mov.d	x10, v0[1]
	fmov	x11, d0
	str	wzr, [x11]
	str	wzr, [x10]
	mov.d	x10, v3[1]
	fmov	x11, d3
	str	wzr, [x11]
	str	wzr, [x10]
	mov.d	x10, v2[1]
	fmov	x11, d2
	str	wzr, [x11]
	mov.d	x11, v1[1]
	str	wzr, [x10]
	fmov	x10, d1
	str	wzr, [x10]
	str	wzr, [x11]
	add	x9, x9, #4
	cmp	x9, #512
	b.ne	LBB0_55
; %bb.56:                               ; %mma.update.i.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	add	x11, x16, #3584
	mov	x8, #-4096                      ; =0xfffffffffffff000
LBB0_57:                                ; %mma.update.i
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	x12, x10, #0xe0
	and	x13, x9, #0x1e0
	add	x12, x15, x12, lsl #2
	add	x13, x5, x13, lsl #2
	ldp	q0, q1, [x12]
	ldp	q2, q3, [x13]
	fmul.4s	v0, v0, v2
	fmul.4s	v1, v1, v3
	fadd.4s	v0, v0, v1
	ldp	q1, q2, [x12, #32]
	ldp	q3, q4, [x13, #32]
	fmul.4s	v1, v1, v3
	fadd.4s	v0, v0, v1
	fmul.4s	v1, v2, v4
	fadd.4s	v0, v0, v1
	ldp	q1, q4, [x13, #64]
	ldp	q2, q3, [x12, #64]
	fmul.4s	v1, v2, v1
	fadd.4s	v0, v0, v1
	fmul.4s	v1, v3, v4
	fadd.4s	v0, v0, v1
	ldp	q2, q1, [x12, #96]
	ldp	q3, q4, [x13, #96]
	fmul.4s	v2, v2, v3
	ldr	s3, [x11, x8]
	fadd.4s	v0, v0, v2
	fmul.4s	v1, v1, v4
	fadd.4s	v0, v0, v1
	dup.4s	v1, v0[1]
	fadd.4s	v1, v0, v1
	dup.4s	v2, v0[3]
	fadd.4s	v0, v0, v2
	dup.4s	v0, v0[2]
	fadd.4s	v0, v1, v0
	fadd	s0, s3, s0
	str	s0, [x11], #4
	add	x10, x10, #2
	add	x9, x9, #32
	cmp	x10, #256
	b.ne	LBB0_57
; %bb.58:                               ; %mma.update.i376.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	mov	x11, x16
	ldr	x8, [sp, #3696]                 ; 8-byte Reload
LBB0_59:                                ; %mma.update.i376
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	x12, x10, #0xe0
	and	x13, x9, #0x1e0
	add	x12, x8, x12, lsl #2
	add	x13, x17, x13, lsl #2
	ldp	q0, q1, [x12]
	ldp	q2, q3, [x13]
	fmul.4s	v0, v0, v2
	fmul.4s	v1, v1, v3
	fadd.4s	v0, v0, v1
	ldp	q1, q2, [x12, #32]
	ldp	q3, q4, [x13, #32]
	fmul.4s	v1, v1, v3
	fadd.4s	v0, v0, v1
	fmul.4s	v1, v2, v4
	ldp	q2, q3, [x12, #64]
	fadd.4s	v0, v0, v1
	ldp	q1, q4, [x13, #64]
	fmul.4s	v1, v2, v1
	fadd.4s	v0, v0, v1
	fmul.4s	v1, v3, v4
	fadd.4s	v0, v0, v1
	ldp	q1, q2, [x12, #96]
	ldp	q3, q4, [x13, #96]
	fmul.4s	v1, v1, v3
	fadd.4s	v0, v0, v1
	ldr	s1, [x11]
	fmul.4s	v2, v2, v4
	fadd.4s	v0, v0, v2
	dup.4s	v2, v0[1]
	fadd.4s	v2, v0, v2
	dup.4s	v3, v0[3]
	fadd.4s	v0, v0, v3
	dup.4s	v0, v0[2]
	fadd.4s	v0, v2, v0
	fadd	s0, s1, s0
	str	s0, [x11, #4096]
	add	x10, x10, #2
	add	x11, x11, #4
	add	x9, x9, #32
	cmp	x10, #256
	b.ne	LBB0_59
; %bb.60:                               ; %mma.update.i380.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	add	x11, x16, #512
	ldr	x8, [sp, #3688]                 ; 8-byte Reload
	ldr	x15, [sp, #3680]                ; 8-byte Reload
LBB0_61:                                ; %mma.update.i380
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	x12, x10, #0xe0
	and	x13, x9, #0x1e0
	add	x12, x8, x12, lsl #2
	add	x13, x30, x13, lsl #2
	ldp	q0, q1, [x12]
	ldp	q2, q3, [x13]
	fmul.4s	v0, v0, v2
	fmul.4s	v1, v1, v3
	fadd.4s	v0, v0, v1
	ldp	q1, q2, [x12, #32]
	ldp	q3, q4, [x13, #32]
	fmul.4s	v1, v1, v3
	fadd.4s	v0, v0, v1
	fmul.4s	v1, v2, v4
	ldp	q2, q3, [x12, #64]
	fadd.4s	v0, v0, v1
	ldp	q1, q4, [x13, #64]
	fmul.4s	v1, v2, v1
	fadd.4s	v0, v0, v1
	fmul.4s	v1, v3, v4
	fadd.4s	v0, v0, v1
	ldp	q1, q2, [x12, #96]
	ldp	q3, q4, [x13, #96]
	fmul.4s	v1, v1, v3
	fadd.4s	v0, v0, v1
	ldr	s1, [x11]
	fmul.4s	v2, v2, v4
	fadd.4s	v0, v0, v2
	dup.4s	v2, v0[1]
	fadd.4s	v2, v0, v2
	dup.4s	v3, v0[3]
	fadd.4s	v0, v0, v3
	dup.4s	v0, v0[2]
	fadd.4s	v0, v2, v0
	fadd	s0, s1, s0
	str	s0, [x11, #4096]
	add	x10, x10, #2
	add	x11, x11, #4
	add	x9, x9, #32
	cmp	x10, #256
	b.ne	LBB0_61
; %bb.62:                               ; %mma.update.i384.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	add	x11, x16, #1024
LBB0_63:                                ; %mma.update.i384
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	x12, x10, #0xe0
	and	x13, x9, #0x1e0
	add	x12, x15, x12, lsl #2
	add	x13, x1, x13, lsl #2
	ldp	q0, q1, [x12]
	ldp	q2, q3, [x13]
	fmul.4s	v0, v0, v2
	fmul.4s	v1, v1, v3
	fadd.4s	v0, v0, v1
	ldp	q1, q2, [x12, #32]
	ldp	q3, q4, [x13, #32]
	fmul.4s	v1, v1, v3
	fadd.4s	v0, v0, v1
	fmul.4s	v1, v2, v4
	ldp	q2, q3, [x12, #64]
	fadd.4s	v0, v0, v1
	ldp	q1, q4, [x13, #64]
	fmul.4s	v1, v2, v1
	fadd.4s	v0, v0, v1
	fmul.4s	v1, v3, v4
	fadd.4s	v0, v0, v1
	ldp	q1, q2, [x12, #96]
	ldp	q3, q4, [x13, #96]
	fmul.4s	v1, v1, v3
	fadd.4s	v0, v0, v1
	ldr	s1, [x11]
	fmul.4s	v2, v2, v4
	fadd.4s	v0, v0, v2
	dup.4s	v2, v0[1]
	fadd.4s	v2, v0, v2
	dup.4s	v3, v0[3]
	fadd.4s	v0, v0, v3
	dup.4s	v0, v0[2]
	fadd.4s	v0, v2, v0
	fadd	s0, s1, s0
	str	s0, [x11, #4096]
	add	x10, x10, #2
	add	x11, x11, #4
	add	x9, x9, #32
	cmp	x10, #256
	b.ne	LBB0_63
; %bb.64:                               ; %mma.update.i388.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	add	x11, x16, #1536
	ldr	x8, [sp, #3672]                 ; 8-byte Reload
	ldr	x15, [sp, #3752]                ; 8-byte Reload
LBB0_65:                                ; %mma.update.i388
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	x12, x10, #0xe0
	and	x13, x9, #0x1e0
	add	x12, x8, x12, lsl #2
	add	x13, x15, x13, lsl #2
	ldp	q0, q1, [x12]
	ldp	q2, q3, [x13]
	fmul.4s	v0, v0, v2
	fmul.4s	v1, v1, v3
	fadd.4s	v0, v0, v1
	ldp	q1, q2, [x12, #32]
	ldp	q3, q4, [x13, #32]
	fmul.4s	v1, v1, v3
	fadd.4s	v0, v0, v1
	fmul.4s	v1, v2, v4
	ldp	q2, q3, [x12, #64]
	fadd.4s	v0, v0, v1
	ldp	q1, q4, [x13, #64]
	fmul.4s	v1, v2, v1
	fadd.4s	v0, v0, v1
	fmul.4s	v1, v3, v4
	fadd.4s	v0, v0, v1
	ldp	q1, q2, [x12, #96]
	ldp	q3, q4, [x13, #96]
	fmul.4s	v1, v1, v3
	fadd.4s	v0, v0, v1
	ldr	s1, [x11]
	fmul.4s	v2, v2, v4
	fadd.4s	v0, v0, v2
	dup.4s	v2, v0[1]
	fadd.4s	v2, v0, v2
	dup.4s	v3, v0[3]
	fadd.4s	v0, v0, v3
	dup.4s	v0, v0[2]
	fadd.4s	v0, v2, v0
	fadd	s0, s1, s0
	str	s0, [x11, #4096]
	add	x10, x10, #2
	add	x11, x11, #4
	add	x9, x9, #32
	cmp	x10, #256
	b.ne	LBB0_65
; %bb.66:                               ; %mma.update.i392.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	add	x11, x16, #2048
	ldr	x8, [sp, #3664]                 ; 8-byte Reload
	ldr	x15, [sp, #3656]                ; 8-byte Reload
LBB0_67:                                ; %mma.update.i392
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	x12, x10, #0xe0
	and	x13, x9, #0x1e0
	add	x12, x8, x12, lsl #2
	add	x13, x2, x13, lsl #2
	ldp	q0, q1, [x12]
	ldp	q2, q3, [x13]
	fmul.4s	v0, v0, v2
	fmul.4s	v1, v1, v3
	fadd.4s	v0, v0, v1
	ldp	q1, q2, [x12, #32]
	ldp	q3, q4, [x13, #32]
	fmul.4s	v1, v1, v3
	fadd.4s	v0, v0, v1
	fmul.4s	v1, v2, v4
	ldp	q2, q3, [x12, #64]
	fadd.4s	v0, v0, v1
	ldp	q1, q4, [x13, #64]
	fmul.4s	v1, v2, v1
	fadd.4s	v0, v0, v1
	fmul.4s	v1, v3, v4
	fadd.4s	v0, v0, v1
	ldp	q1, q2, [x12, #96]
	ldp	q3, q4, [x13, #96]
	fmul.4s	v1, v1, v3
	fadd.4s	v0, v0, v1
	ldr	s1, [x11]
	fmul.4s	v2, v2, v4
	fadd.4s	v0, v0, v2
	dup.4s	v2, v0[1]
	fadd.4s	v2, v0, v2
	dup.4s	v3, v0[3]
	fadd.4s	v0, v0, v3
	dup.4s	v0, v0[2]
	fadd.4s	v0, v2, v0
	fadd	s0, s1, s0
	str	s0, [x11, #4096]
	add	x10, x10, #2
	add	x11, x11, #4
	add	x9, x9, #32
	cmp	x10, #256
	b.ne	LBB0_67
; %bb.68:                               ; %mma.update.i396.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	add	x11, x16, #2560
	ldr	x8, [sp, #3744]                 ; 8-byte Reload
LBB0_69:                                ; %mma.update.i396
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	x12, x10, #0xe0
	and	x13, x9, #0x1e0
	add	x12, x15, x12, lsl #2
	add	x13, x8, x13, lsl #2
	ldp	q0, q1, [x12]
	ldp	q2, q3, [x13]
	fmul.4s	v0, v0, v2
	fmul.4s	v1, v1, v3
	fadd.4s	v0, v0, v1
	ldp	q1, q2, [x12, #32]
	ldp	q3, q4, [x13, #32]
	fmul.4s	v1, v1, v3
	fadd.4s	v0, v0, v1
	fmul.4s	v1, v2, v4
	ldp	q2, q3, [x12, #64]
	fadd.4s	v0, v0, v1
	ldp	q1, q4, [x13, #64]
	fmul.4s	v1, v2, v1
	fadd.4s	v0, v0, v1
	fmul.4s	v1, v3, v4
	fadd.4s	v0, v0, v1
	ldp	q1, q2, [x12, #96]
	ldp	q3, q4, [x13, #96]
	fmul.4s	v1, v1, v3
	fadd.4s	v0, v0, v1
	ldr	s1, [x11]
	fmul.4s	v2, v2, v4
	fadd.4s	v0, v0, v2
	dup.4s	v2, v0[1]
	fadd.4s	v2, v0, v2
	dup.4s	v3, v0[3]
	fadd.4s	v0, v0, v3
	dup.4s	v0, v0[2]
	fadd.4s	v0, v2, v0
	fadd	s0, s1, s0
	str	s0, [x11, #4096]
	add	x10, x10, #2
	add	x11, x11, #4
	add	x9, x9, #32
	cmp	x10, #256
	b.ne	LBB0_69
; %bb.70:                               ; %mma.update.i400.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	str	x14, [sp, #4200]                ; 8-byte Spill
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	add	x11, x16, #3072
	ldr	x8, [sp, #3648]                 ; 8-byte Reload
LBB0_71:                                ; %mma.update.i400
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	x12, x10, #0xe0
	and	x13, x9, #0x1e0
	add	x12, x8, x12, lsl #2
	add	x13, x3, x13, lsl #2
	ldp	q0, q1, [x12]
	ldp	q2, q3, [x13]
	fmul.4s	v0, v0, v2
	fmul.4s	v1, v1, v3
	fadd.4s	v0, v0, v1
	ldp	q1, q2, [x12, #32]
	ldp	q3, q4, [x13, #32]
	fmul.4s	v1, v1, v3
	fadd.4s	v0, v0, v1
	fmul.4s	v1, v2, v4
	ldp	q2, q3, [x12, #64]
	fadd.4s	v0, v0, v1
	ldp	q1, q4, [x13, #64]
	fmul.4s	v1, v2, v1
	fadd.4s	v0, v0, v1
	fmul.4s	v1, v3, v4
	fadd.4s	v0, v0, v1
	ldp	q1, q2, [x12, #96]
	ldp	q3, q4, [x13, #96]
	fmul.4s	v1, v1, v3
	fadd.4s	v0, v0, v1
	ldr	s1, [x11]
	fmul.4s	v2, v2, v4
	fadd.4s	v0, v0, v2
	dup.4s	v2, v0[1]
	fadd.4s	v2, v0, v2
	dup.4s	v3, v0[3]
	fadd.4s	v0, v0, v3
	dup.4s	v0, v0[2]
	fadd.4s	v0, v2, v0
	fadd	s0, s1, s0
	str	s0, [x11, #4096]
	add	x10, x10, #2
	add	x11, x11, #4
	add	x9, x9, #32
	cmp	x10, #256
	b.ne	LBB0_71
; %bb.72:                               ; %llm_attention.strided_mma.exit403
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	mov	x11, #0                         ; =0x0
	ldr	q0, [sp, #176]                  ; 16-byte Reload
	fmov	x12, d0
	mov	w13, #1                         ; =0x1
	strb	w13, [x12]
	mov.d	x12, v0[1]
	strb	w13, [x12]
	orr	x7, x0, #0x1
	ldr	q0, [sp, #320]                  ; 16-byte Reload
	mov.d	x12, v0[1]
	orr	x6, x0, #0x2
	orr	x5, x0, #0x3
	ldr	x8, [sp, #312]                  ; 8-byte Reload
	strb	w13, [x8]
	orr	x4, x0, #0x4
	mov	w8, #5                          ; =0x5
	orr	x3, x0, x8
	strb	w13, [x12]
	orr	x15, x0, #0x6
	orr	x16, x0, #0x7
	ldr	x8, [sp, #264]                  ; 8-byte Reload
	strb	w13, [x8]
	ldr	q0, [sp, #272]                  ; 16-byte Reload
	mov.d	x12, v0[1]
	mov	w8, #9                          ; =0x9
	orr	x2, x0, x8
	mov	w8, #10                         ; =0xa
	orr	x1, x0, x8
	strb	w13, [x12]
	mov	w8, #11                         ; =0xb
	orr	x17, x0, x8
	ldr	q0, [sp, #224]                  ; 16-byte Reload
	mov.d	x30, v0[1]
	mov	w8, #13                         ; =0xd
	orr	x14, x0, x8
	ldr	x8, [sp, #216]                  ; 8-byte Reload
	strb	w13, [x8]
	cmp	x7, #129
	strb	w13, [x30]
	cset	w30, lo
	ldr	q0, [sp, #2560]                 ; 16-byte Reload
	fmov	x12, d0
	strb	w30, [x12]
	cmp	x6, #129
	mov.d	x12, v0[1]
	cset	w8, lo
	cmp	x5, #129
	strb	w30, [x12]
	ldr	q0, [sp, #2592]                 ; 16-byte Reload
	fmov	x12, d0
	strb	w30, [x12]
	mov.d	x12, v0[1]
	strb	w30, [x12]
	ldr	q0, [sp, #2624]                 ; 16-byte Reload
	fmov	x12, d0
	strb	w30, [x12]
	mov.d	x12, v0[1]
	strb	w30, [x12]
	ldr	q0, [sp, #2656]                 ; 16-byte Reload
	fmov	x12, d0
	strb	w30, [x12]
	mov.d	x12, v0[1]
	strb	w30, [x12]
	ldr	q0, [sp, #2432]                 ; 16-byte Reload
	fmov	x12, d0
	strb	w8, [x12]
	mov.d	x12, v0[1]
	strb	w8, [x12]
	ldr	q0, [sp, #2464]                 ; 16-byte Reload
	fmov	x12, d0
	mov.d	x30, v0[1]
	strb	w8, [x12]
	strb	w8, [x30]
	ldr	q0, [sp, #2496]                 ; 16-byte Reload
	fmov	x12, d0
	strb	w8, [x12]
	mov.d	x12, v0[1]
	cset	w30, lo
	strb	w8, [x12]
	ldr	q0, [sp, #2528]                 ; 16-byte Reload
	fmov	x12, d0
	strb	w8, [x12]
	mov.d	x12, v0[1]
	cmp	x4, #129
	strb	w8, [x12]
	ldr	q0, [sp, #2304]                 ; 16-byte Reload
	fmov	x8, d0
	strb	w30, [x8]
	mov.d	x8, v0[1]
	cset	w12, lo
	strb	w30, [x8]
	ldr	q0, [sp, #2336]                 ; 16-byte Reload
	fmov	x8, d0
	strb	w30, [x8]
	mov.d	x8, v0[1]
	cmp	x3, #129
	strb	w30, [x8]
	ldr	q0, [sp, #2368]                 ; 16-byte Reload
	fmov	x8, d0
	strb	w30, [x8]
	mov.d	x8, v0[1]
	strb	w30, [x8]
	ldr	q0, [sp, #2400]                 ; 16-byte Reload
	fmov	x8, d0
	strb	w30, [x8]
	mov.d	x8, v0[1]
	strb	w30, [x8]
	cset	w8, lo
	cmp	x15, #129
	orr	x13, x0, #0x6
	str	x13, [sp, #4928]                ; 8-byte Spill
	ldr	q0, [sp, #2176]                 ; 16-byte Reload
	fmov	x30, d0
	strb	w12, [x30]
	mov.d	x30, v0[1]
	strb	w12, [x30]
	ldr	q0, [sp, #2208]                 ; 16-byte Reload
	fmov	x30, d0
	strb	w12, [x30]
	mov.d	x30, v0[1]
	strb	w12, [x30]
	ldr	q0, [sp, #2240]                 ; 16-byte Reload
	fmov	x30, d0
	strb	w12, [x30]
	mov.d	x30, v0[1]
	strb	w12, [x30]
	ldr	q0, [sp, #2272]                 ; 16-byte Reload
	fmov	x30, d0
	strb	w12, [x30]
	mov.d	x30, v0[1]
	strb	w12, [x30]
	ldr	q0, [sp, #2048]                 ; 16-byte Reload
	fmov	x12, d0
	strb	w8, [x12]
	mov.d	x12, v0[1]
	strb	w8, [x12]
	ldr	q0, [sp, #2080]                 ; 16-byte Reload
	fmov	x12, d0
	mov.d	x30, v0[1]
	strb	w8, [x12]
	strb	w8, [x30]
	ldr	q0, [sp, #2112]                 ; 16-byte Reload
	fmov	x12, d0
	strb	w8, [x12]
	mov.d	x12, v0[1]
	cset	w30, lo
	strb	w8, [x12]
	ldr	q0, [sp, #2144]                 ; 16-byte Reload
	fmov	x12, d0
	strb	w8, [x12]
	mov.d	x12, v0[1]
	cmp	x16, #129
	orr	x13, x0, #0x7
	str	x13, [sp, #4912]                ; 8-byte Spill
	strb	w8, [x12]
	ldr	q0, [sp, #1920]                 ; 16-byte Reload
	fmov	x8, d0
	strb	w30, [x8]
	mov.d	x8, v0[1]
	cset	w12, lo
	strb	w30, [x8]
	ldr	q0, [sp, #1952]                 ; 16-byte Reload
	fmov	x8, d0
	strb	w30, [x8]
	mov.d	x8, v0[1]
	orr	x13, x0, #0x8
	cmp	x13, #129
	orr	x13, x0, #0x8
	str	x13, [sp, #4896]                ; 8-byte Spill
	strb	w30, [x8]
	ldr	q0, [sp, #1984]                 ; 16-byte Reload
	fmov	x8, d0
	strb	w30, [x8]
	mov.d	x8, v0[1]
	strb	w30, [x8]
	ldr	q0, [sp, #2016]                 ; 16-byte Reload
	fmov	x8, d0
	strb	w30, [x8]
	mov.d	x8, v0[1]
	strb	w30, [x8]
	cset	w8, lo
	cmp	x2, #129
	ldr	q0, [sp, #1792]                 ; 16-byte Reload
	fmov	x30, d0
	strb	w12, [x30]
	mov.d	x30, v0[1]
	strb	w12, [x30]
	ldr	q0, [sp, #1824]                 ; 16-byte Reload
	fmov	x30, d0
	strb	w12, [x30]
	mov.d	x30, v0[1]
	strb	w12, [x30]
	ldr	q0, [sp, #1856]                 ; 16-byte Reload
	fmov	x30, d0
	strb	w12, [x30]
	mov.d	x30, v0[1]
	strb	w12, [x30]
	ldr	q0, [sp, #1888]                 ; 16-byte Reload
	fmov	x30, d0
	strb	w12, [x30]
	mov.d	x30, v0[1]
	strb	w12, [x30]
	ldr	q0, [sp, #1664]                 ; 16-byte Reload
	fmov	x12, d0
	strb	w8, [x12]
	mov.d	x12, v0[1]
	strb	w8, [x12]
	ldr	q0, [sp, #1696]                 ; 16-byte Reload
	fmov	x12, d0
	mov.d	x30, v0[1]
	strb	w8, [x12]
	strb	w8, [x30]
	ldr	q0, [sp, #1728]                 ; 16-byte Reload
	fmov	x12, d0
	strb	w8, [x12]
	mov.d	x12, v0[1]
	cset	w30, lo
	strb	w8, [x12]
	ldr	q0, [sp, #1760]                 ; 16-byte Reload
	fmov	x12, d0
	strb	w8, [x12]
	mov.d	x12, v0[1]
	cmp	x1, #129
	strb	w8, [x12]
	ldr	q0, [sp, #1536]                 ; 16-byte Reload
	fmov	x8, d0
	strb	w30, [x8]
	mov.d	x8, v0[1]
	cset	w12, lo
	strb	w30, [x8]
	ldr	q0, [sp, #1568]                 ; 16-byte Reload
	fmov	x8, d0
	strb	w30, [x8]
	mov.d	x8, v0[1]
	cmp	x17, #129
	strb	w30, [x8]
	ldr	q0, [sp, #1600]                 ; 16-byte Reload
	fmov	x8, d0
	strb	w30, [x8]
	mov.d	x8, v0[1]
	strb	w30, [x8]
	ldr	q0, [sp, #1632]                 ; 16-byte Reload
	fmov	x8, d0
	strb	w30, [x8]
	mov.d	x8, v0[1]
	strb	w30, [x8]
	cset	w8, lo
	orr	x13, x0, #0xc
	cmp	x13, #129
	orr	x16, x0, #0xc
	ldr	q0, [sp, #1408]                 ; 16-byte Reload
	fmov	x30, d0
	strb	w12, [x30]
	mov.d	x30, v0[1]
	strb	w12, [x30]
	ldr	q0, [sp, #1440]                 ; 16-byte Reload
	fmov	x30, d0
	strb	w12, [x30]
	mov.d	x30, v0[1]
	strb	w12, [x30]
	ldr	q0, [sp, #1472]                 ; 16-byte Reload
	fmov	x30, d0
	strb	w12, [x30]
	mov.d	x30, v0[1]
	strb	w12, [x30]
	ldr	q0, [sp, #1504]                 ; 16-byte Reload
	fmov	x30, d0
	strb	w12, [x30]
	mov.d	x30, v0[1]
	strb	w12, [x30]
	ldr	q0, [sp, #1280]                 ; 16-byte Reload
	fmov	x12, d0
	strb	w8, [x12]
	mov.d	x12, v0[1]
	strb	w8, [x12]
	ldr	q0, [sp, #1312]                 ; 16-byte Reload
	fmov	x12, d0
	mov.d	x30, v0[1]
	strb	w8, [x12]
	strb	w8, [x30]
	ldr	q0, [sp, #1344]                 ; 16-byte Reload
	fmov	x12, d0
	strb	w8, [x12]
	mov.d	x12, v0[1]
	cset	w30, lo
	strb	w8, [x12]
	ldr	q0, [sp, #1376]                 ; 16-byte Reload
	fmov	x12, d0
	strb	w8, [x12]
	mov.d	x12, v0[1]
	cmp	x14, #129
	mov	x15, x14
	strb	w8, [x12]
	ldr	q0, [sp, #1152]                 ; 16-byte Reload
	fmov	x8, d0
	strb	w30, [x8]
	mov.d	x8, v0[1]
	cset	w12, lo
	strb	w30, [x8]
	ldr	q0, [sp, #1184]                 ; 16-byte Reload
	fmov	x8, d0
	strb	w30, [x8]
	mov.d	x8, v0[1]
	orr	x13, x0, #0xe
	cmp	x13, #129
	strb	w30, [x8]
	ldr	q0, [sp, #1216]                 ; 16-byte Reload
	fmov	x8, d0
	strb	w30, [x8]
	mov.d	x8, v0[1]
	strb	w30, [x8]
	ldr	q0, [sp, #1248]                 ; 16-byte Reload
	fmov	x8, d0
	strb	w30, [x8]
	mov.d	x8, v0[1]
	strb	w30, [x8]
	cset	w30, lo
	ldr	q0, [sp, #1024]                 ; 16-byte Reload
	fmov	x8, d0
	strb	w12, [x8]
	mov.d	x8, v0[1]
	strb	w12, [x8]
	ldr	q0, [sp, #1056]                 ; 16-byte Reload
	fmov	x8, d0
	strb	w12, [x8]
	mov.d	x8, v0[1]
	strb	w12, [x8]
	ldr	q0, [sp, #1088]                 ; 16-byte Reload
	fmov	x8, d0
	strb	w12, [x8]
	mov.d	x8, v0[1]
	strb	w12, [x8]
	ldr	q0, [sp, #1120]                 ; 16-byte Reload
	fmov	x8, d0
	strb	w12, [x8]
	mov.d	x8, v0[1]
	strb	w12, [x8]
	ldr	q0, [sp, #640]                  ; 16-byte Reload
	fmov	x8, d0
	mov.d	x12, v0[1]
	strb	w30, [x8]
	strb	w30, [x12]
	ldr	q0, [sp, #672]                  ; 16-byte Reload
	fmov	x8, d0
	strb	w30, [x8]
	mov.d	x12, v0[1]
	orr	x8, x0, #0xf
	strb	w30, [x12]
	ldr	q0, [sp, #704]                  ; 16-byte Reload
	fmov	x12, d0
	strb	w30, [x12]
	mov.d	x12, v0[1]
	cmp	x8, #129
	strb	w30, [x12]
	ldr	q0, [sp, #736]                  ; 16-byte Reload
	fmov	x12, d0
	strb	w30, [x12]
	mov.d	x12, v0[1]
	strb	w30, [x12]
	cset	w12, lo
	ldr	q0, [sp, #512]                  ; 16-byte Reload
	fmov	x14, d0
	strb	w12, [x14]
	mov.d	x14, v0[1]
	strb	w12, [x14]
	ldr	q0, [sp, #544]                  ; 16-byte Reload
	fmov	x14, d0
	strb	w12, [x14]
	mov.d	x14, v0[1]
	strb	w12, [x14]
	ldr	q0, [sp, #576]                  ; 16-byte Reload
	fmov	x14, d0
	strb	w12, [x14]
	mov.d	x14, v0[1]
	strb	w12, [x14]
	ldr	q0, [sp, #608]                  ; 16-byte Reload
	fmov	x14, d0
	strb	w12, [x14]
	mov.d	x14, v0[1]
	strb	w12, [x14]
	ldr	x30, [sp, #4952]                ; 8-byte Reload
	mov	w12, #16512                     ; =0x4080
	movk	w12, #1, lsl #16
	add	x12, x30, x12
	stp	q24, q24, [x12, #32]
	stp	q24, q24, [x12]
	dup.2d	v0, x7
	ldr	x12, [sp, #3016]                ; 8-byte Reload
	stp	q0, q0, [x12, #32]
	stp	q0, q0, [x12]
	dup.2d	v0, x6
	ldr	x12, [sp, #3008]                ; 8-byte Reload
	stp	q0, q0, [x12, #32]
	stp	q0, q0, [x12]
	dup.2d	v0, x5
	ldr	x12, [sp, #3000]                ; 8-byte Reload
	stp	q0, q0, [x12, #32]
	stp	q0, q0, [x12]
	dup.2d	v0, x4
	ldr	x12, [sp, #2992]                ; 8-byte Reload
	stp	q0, q0, [x12, #32]
	stp	q0, q0, [x12]
	dup.2d	v0, x3
	ldr	x12, [sp, #2984]                ; 8-byte Reload
	stp	q0, q0, [x12, #32]
	stp	q0, q0, [x12]
	ldr	x12, [sp, #4928]                ; 8-byte Reload
	dup.2d	v0, x12
	ldr	x12, [sp, #2976]                ; 8-byte Reload
	stp	q0, q0, [x12, #32]
	stp	q0, q0, [x12]
	ldr	x12, [sp, #4912]                ; 8-byte Reload
	dup.2d	v0, x12
	ldr	x12, [sp, #2968]                ; 8-byte Reload
	stp	q0, q0, [x12, #32]
	stp	q0, q0, [x12]
	ldr	x12, [sp, #4896]                ; 8-byte Reload
	dup.2d	v0, x12
	ldr	x12, [sp, #2960]                ; 8-byte Reload
	stp	q0, q0, [x12, #32]
	stp	q0, q0, [x12]
	dup.2d	v0, x2
	ldr	x12, [sp, #2952]                ; 8-byte Reload
	stp	q0, q0, [x12, #32]
	stp	q0, q0, [x12]
	dup.2d	v0, x1
	ldr	x12, [sp, #2944]                ; 8-byte Reload
	stp	q0, q0, [x12, #32]
	stp	q0, q0, [x12]
	dup.2d	v0, x17
	ldr	x12, [sp, #2936]                ; 8-byte Reload
	stp	q0, q0, [x12, #32]
	stp	q0, q0, [x12]
	dup.2d	v0, x16
	ldr	x12, [sp, #2928]                ; 8-byte Reload
	stp	q0, q0, [x12, #32]
	stp	q0, q0, [x12]
	dup.2d	v0, x15
	ldr	x12, [sp, #2920]                ; 8-byte Reload
	stp	q0, q0, [x12, #32]
	stp	q0, q0, [x12]
	dup.2d	v0, x13
	ldr	x12, [sp, #2912]                ; 8-byte Reload
	stp	q0, q0, [x12, #32]
	stp	q0, q0, [x12]
	dup.2d	v0, x8
	ldr	x8, [sp, #2904]                 ; 8-byte Reload
	stp	q0, q0, [x8, #32]
	stp	q0, q0, [x8]
	mov	w8, #17536                      ; =0x4480
	movk	w8, #1, lsl #16
	add	x8, x30, x8
	ldr	q1, [sp, #3584]                 ; 16-byte Reload
	ldr	q0, [sp, #3600]                 ; 16-byte Reload
	stp	q0, q1, [x8, #32]
	ldr	q1, [sp, #3632]                 ; 16-byte Reload
	ldr	q0, [sp, #3616]                 ; 16-byte Reload
	stp	q0, q1, [x8]
	ldr	q1, [sp, #3520]                 ; 16-byte Reload
	ldr	x8, [sp, #2896]                 ; 8-byte Reload
	ldr	q0, [sp, #3536]                 ; 16-byte Reload
	stp	q0, q1, [x8, #32]
	ldr	q1, [sp, #3568]                 ; 16-byte Reload
	ldr	q0, [sp, #3552]                 ; 16-byte Reload
	stp	q0, q1, [x8]
	ldr	q1, [sp, #3456]                 ; 16-byte Reload
	ldr	x8, [sp, #2888]                 ; 8-byte Reload
	ldr	q0, [sp, #3472]                 ; 16-byte Reload
	stp	q0, q1, [x8, #32]
	ldr	q1, [sp, #3504]                 ; 16-byte Reload
	ldr	q0, [sp, #3488]                 ; 16-byte Reload
	stp	q0, q1, [x8]
	ldr	q1, [sp, #3392]                 ; 16-byte Reload
	ldr	x8, [sp, #2880]                 ; 8-byte Reload
	ldr	q0, [sp, #3408]                 ; 16-byte Reload
	stp	q0, q1, [x8, #32]
	ldr	q1, [sp, #3440]                 ; 16-byte Reload
	ldr	q0, [sp, #3424]                 ; 16-byte Reload
	stp	q0, q1, [x8]
	ldr	q1, [sp, #3328]                 ; 16-byte Reload
	ldr	x8, [sp, #2872]                 ; 8-byte Reload
	ldr	q0, [sp, #3344]                 ; 16-byte Reload
	stp	q0, q1, [x8, #32]
	ldr	q1, [sp, #3376]                 ; 16-byte Reload
	ldr	q0, [sp, #3360]                 ; 16-byte Reload
	stp	q0, q1, [x8]
	ldr	q1, [sp, #3264]                 ; 16-byte Reload
	ldr	x8, [sp, #2864]                 ; 8-byte Reload
	ldr	q0, [sp, #3280]                 ; 16-byte Reload
	stp	q0, q1, [x8, #32]
	ldr	q1, [sp, #3312]                 ; 16-byte Reload
	ldr	q0, [sp, #3296]                 ; 16-byte Reload
	stp	q0, q1, [x8]
	ldr	q1, [sp, #3200]                 ; 16-byte Reload
	ldr	x8, [sp, #2856]                 ; 8-byte Reload
	ldr	q0, [sp, #3216]                 ; 16-byte Reload
	stp	q0, q1, [x8, #32]
	ldr	q1, [sp, #3248]                 ; 16-byte Reload
	ldr	q0, [sp, #3232]                 ; 16-byte Reload
	stp	q0, q1, [x8]
	ldr	q1, [sp, #3136]                 ; 16-byte Reload
	ldr	x8, [sp, #2848]                 ; 8-byte Reload
	ldr	q0, [sp, #3152]                 ; 16-byte Reload
	stp	q0, q1, [x8, #32]
	ldr	q1, [sp, #3184]                 ; 16-byte Reload
	ldr	q0, [sp, #3168]                 ; 16-byte Reload
	stp	q0, q1, [x8]
	ldr	x16, [sp, #3128]                ; 8-byte Reload
	ldp	x0, x17, [sp, #392]             ; 16-byte Folded Reload
LBB0_73:                                ; %direct.true433
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsr	x8, x11, #3
	dup.2d	v0, x8
	add.2d	v0, v17, v0
	add.2d	v1, v0, v10
	add.2d	v2, v0, v8
	add.2d	v3, v0, v14
	mov.d	x8, v3[1]
	add.2d	v0, v0, v9
	fmov	x12, d3
	mov.d	x13, v2[1]
	fmov	x14, d2
	mov.d	x15, v0[1]
	ldr	b2, [x12]
	ld1.b	{ v2 }[1], [x8]
	ld1.b	{ v2 }[2], [x14]
	fmov	x8, d0
	ld1.b	{ v2 }[3], [x13]
	ld1.b	{ v2 }[4], [x8]
	mov.d	x8, v1[1]
	and	x12, x10, #0x3c0
	add	x12, x17, x12
	ldp	q0, q3, [x12]
	ld1.b	{ v2 }[5], [x15]
	ldp	q4, q5, [x12, #32]
	and	x12, x9, #0x1c0
	add	x12, x0, x12
	fmov	x13, d1
	ldp	q1, q6, [x12]
	ldp	q7, q16, [x12, #32]
	ld1.b	{ v2 }[6], [x13]
	cmge.2d	v5, v16, v5
	cmge.2d	v4, v7, v4
	uzp1.4s	v4, v4, v5
	cmge.2d	v3, v6, v3
	ld1.b	{ v2 }[7], [x8]
	cmge.2d	v0, v1, v0
	uzp1.4s	v0, v0, v3
	uzp1.8h	v0, v0, v4
	dup.2d	v1, x11
	cmeq.8b	v2, v2, #0
	xtn.8b	v0, v0
	dup.2d	v24, x16
	add.2d	v1, v24, v1
	add.2d	v3, v1, v25
	bic.8b	v0, v0, v2
	add.2d	v2, v1, v21
	add.2d	v4, v1, v27
	mov.d	x8, v4[1]
	fmov	x12, d4
	and.8b	v0, v0, v19
	str	b0, [x12]
	mov.d	x12, v2[1]
	fmov	x13, d2
	st1.b	{ v0 }[1], [x8]
	st1.b	{ v0 }[2], [x13]
	mov.d	x8, v3[1]
	st1.b	{ v0 }[3], [x12]
	fmov	x12, d3
	st1.b	{ v0 }[4], [x12]
	st1.b	{ v0 }[5], [x8]
	add.2d	v1, v1, v31
	mov.d	x8, v1[1]
	fmov	x12, d1
	st1.b	{ v0 }[6], [x12]
	st1.b	{ v0 }[7], [x8]
	add	x11, x11, #1
	add	x10, x10, #8
	add	x9, x9, #64
	cmp	x11, #128
	b.ne	LBB0_73
; %bb.74:                               ; %direct.true455.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	str	q15, [sp, #4016]                ; 16-byte Spill
	str	q13, [sp, #4032]                ; 16-byte Spill
	str	q12, [sp, #4064]                ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	ldr	x1, [sp, #408]                  ; 8-byte Reload
	ldp	x6, x5, [sp, #376]              ; 16-byte Folded Reload
	mov	w2, #62154                      ; =0xf2ca
	movk	w2, #61769, lsl #16
	mov	w3, #1267                       ; =0x4f3
	movk	w3, #15925, lsl #16
	mov	w7, #29184                      ; =0x7200
	movk	w7, #48945, lsl #16
LBB0_75:                                ; %direct.true455
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	x11, x8, #0x78
	orr	x11, x11, x10, lsr #4
	dup.2d	v0, x11
	add.2d	v0, v24, v0
	add.2d	v1, v0, v31
	add.2d	v2, v0, v25
	add.2d	v3, v0, v21
	add.2d	v0, v0, v27
	mov.d	x11, v0[1]
	fmov	x12, d0
	mov.d	x13, v3[1]
	fmov	x14, d3
	mov.d	x15, v2[1]
	fmov	x16, d2
	mov.d	x17, v1[1]
	fmov	x0, d1
	ldr	b0, [x12]
	ld1.b	{ v0 }[1], [x11]
	ld1.b	{ v0 }[2], [x14]
	dup.2d	v1, x9
	ld1.b	{ v0 }[3], [x13]
	dup.2d	v2, x1
	add.2d	v1, v2, v1
	add.2d	v2, v1, v29
	ld1.b	{ v0 }[4], [x16]
	add.2d	v3, v1, v11
	add.2d	v4, v1, v28
	mov.d	x11, v4[1]
	ld1.b	{ v0 }[5], [x15]
	add.2d	v1, v1, v30
	fmov	x12, d4
	mov.d	x13, v1[1]
	ld1.b	{ v0 }[6], [x0]
	fmov	x14, d1
	mov.d	x15, v3[1]
	fmov	x16, d3
	ld1.b	{ v0 }[7], [x17]
	mov.d	x17, v2[1]
	ldr	s1, [x12]
	ld1.s	{ v1 }[1], [x11]
	cmeq.8b	v0, v0, #0
	fmov	x11, d2
	ld1.s	{ v1 }[2], [x14]
	ld1.s	{ v1 }[3], [x13]
	sshll.8h	v0, v0, #0
	ldr	s2, [x16]
	ld1.s	{ v2 }[1], [x15]
	ld1.s	{ v2 }[2], [x11]
	sshll2.4s	v3, v0, #0
	ld1.s	{ v2 }[3], [x17]
	dup.4s	v4, w3
	fmul.4s	v2, v2, v4
	sshll.4s	v0, v0, #0
	fmul.4s	v1, v1, v4
	dup.4s	v4, w2
	bsl.16b	v0, v4, v1
	add	x11, x5, x10, lsl #5
	mov.16b	v1, v3
	bsl.16b	v1, v4, v2
	stp	q0, q1, [x11]
	add	x10, x10, #1
	add	x9, x9, #4
	add	x8, x8, #8
	cmp	x9, #512
	b.ne	LBB0_75
; %bb.76:                               ; %direct.true473.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	ldr	x12, [sp, #912]                 ; 8-byte Reload
	ldp	q0, q25, [x12]
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	mov	x11, #0                         ; =0x0
	mvni.4s	v5, #127, msl #16
	fmaxnm.4s	v0, v0, v5
	fmaxnm.4s	v1, v25, v5
	ldr	x12, [sp, #904]                 ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #896]                 ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #888]                 ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #880]                 ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #872]                 ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #864]                 ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #856]                 ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #760]                 ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #728]                 ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #720]                 ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #696]                 ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #664]                 ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #656]                 ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #632]                 ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #600]                 ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v1, v1, v3
	str	q1, [sp, #4000]                 ; 16-byte Spill
	fmaxnm.4s	v0, v0, v2
	str	q0, [sp, #3984]                 ; 16-byte Spill
	ldr	x12, [sp, #1080]                ; 8-byte Reload
	ldp	q1, q0, [x12]
	fmaxnm.4s	v1, v1, v5
	fmaxnm.4s	v0, v0, v5
	ldr	x12, [sp, #1048]                ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #1040]                ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #1016]                ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #1008]                ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #1000]                ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #992]                 ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #984]                 ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #976]                 ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #968]                 ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #960]                 ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #952]                 ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #944]                 ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #936]                 ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #928]                 ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #920]                 ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	str	q0, [sp, #4480]                 ; 16-byte Spill
	fmaxnm.4s	v0, v1, v2
	str	q0, [sp, #4464]                 ; 16-byte Spill
	ldr	x12, [sp, #1424]                ; 8-byte Reload
	ldp	q1, q0, [x12]
	fmaxnm.4s	v1, v1, v5
	fmaxnm.4s	v0, v0, v5
	ldr	x12, [sp, #1400]                ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #1368]                ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #1360]                ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #1336]                ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #1304]                ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #1296]                ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #1272]                ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #1240]                ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #1232]                ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #1208]                ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #1176]                ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #1168]                ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #1144]                ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #1112]                ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #1104]                ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	str	q0, [sp, #4544]                 ; 16-byte Spill
	fmaxnm.4s	v0, v1, v2
	str	q0, [sp, #4528]                 ; 16-byte Spill
	ldr	x12, [sp, #1752]                ; 8-byte Reload
	ldp	q1, q0, [x12]
	fmaxnm.4s	v1, v1, v5
	fmaxnm.4s	v0, v0, v5
	ldr	x12, [sp, #1744]                ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #1720]                ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #1688]                ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #1680]                ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #1656]                ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #1624]                ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #1616]                ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #1592]                ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #1560]                ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #1552]                ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #1528]                ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #1496]                ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #1488]                ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #1464]                ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #1432]                ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	str	q0, [sp, #4608]                 ; 16-byte Spill
	fmaxnm.4s	v15, v1, v2
	ldr	x12, [sp, #2104]                ; 8-byte Reload
	ldp	q1, q0, [x12]
	fmaxnm.4s	v1, v1, v5
	fmaxnm.4s	v0, v0, v5
	ldr	x12, [sp, #2072]                ; 8-byte Reload
	ldp	q2, q4, [x12]
	fmaxnm.4s	v0, v0, v4
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #2064]                ; 8-byte Reload
	ldp	q4, q2, [x12]
	fmaxnm.4s	v1, v1, v4
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #2040]                ; 8-byte Reload
	ldp	q2, q4, [x12]
	fmaxnm.4s	v0, v0, v4
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #2008]                ; 8-byte Reload
	ldp	q4, q2, [x12]
	fmaxnm.4s	v1, v1, v4
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #2000]                ; 8-byte Reload
	ldp	q2, q4, [x12]
	fmaxnm.4s	v0, v0, v4
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #1976]                ; 8-byte Reload
	ldp	q4, q2, [x12]
	fmaxnm.4s	v1, v1, v4
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #1944]                ; 8-byte Reload
	ldp	q2, q4, [x12]
	fmaxnm.4s	v0, v0, v4
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #1936]                ; 8-byte Reload
	ldp	q4, q2, [x12]
	fmaxnm.4s	v1, v1, v4
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #1912]                ; 8-byte Reload
	ldp	q2, q4, [x12]
	fmaxnm.4s	v0, v0, v4
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #1880]                ; 8-byte Reload
	ldp	q4, q2, [x12]
	fmaxnm.4s	v1, v1, v4
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #1872]                ; 8-byte Reload
	ldp	q2, q4, [x12]
	fmaxnm.4s	v0, v0, v4
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #1848]                ; 8-byte Reload
	ldp	q4, q2, [x12]
	fmaxnm.4s	v1, v1, v4
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #1816]                ; 8-byte Reload
	ldp	q2, q4, [x12]
	fmaxnm.4s	v0, v0, v4
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #1808]                ; 8-byte Reload
	ldp	q4, q2, [x12]
	fmaxnm.4s	v1, v1, v4
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #1784]                ; 8-byte Reload
	ldp	q2, q4, [x12]
	fmaxnm.4s	v14, v0, v4
	fmaxnm.4s	v4, v1, v2
	ldr	x12, [sp, #2424]                ; 8-byte Reload
	ldp	q1, q0, [x12]
	fmaxnm.4s	v1, v1, v5
	fmaxnm.4s	v0, v0, v5
	ldr	x12, [sp, #2392]                ; 8-byte Reload
	ldp	q2, q6, [x12]
	fmaxnm.4s	v0, v0, v6
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #2384]                ; 8-byte Reload
	ldp	q6, q2, [x12]
	fmaxnm.4s	v1, v1, v6
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #2360]                ; 8-byte Reload
	ldp	q2, q6, [x12]
	fmaxnm.4s	v0, v0, v6
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #2328]                ; 8-byte Reload
	ldp	q6, q2, [x12]
	fmaxnm.4s	v1, v1, v6
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #2320]                ; 8-byte Reload
	ldp	q2, q6, [x12]
	fmaxnm.4s	v0, v0, v6
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #2296]                ; 8-byte Reload
	ldp	q6, q2, [x12]
	fmaxnm.4s	v1, v1, v6
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #2264]                ; 8-byte Reload
	ldp	q2, q6, [x12]
	fmaxnm.4s	v0, v0, v6
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #2256]                ; 8-byte Reload
	ldp	q6, q2, [x12]
	fmaxnm.4s	v1, v1, v6
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #2232]                ; 8-byte Reload
	ldp	q2, q6, [x12]
	fmaxnm.4s	v0, v0, v6
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #2200]                ; 8-byte Reload
	ldp	q6, q2, [x12]
	fmaxnm.4s	v1, v1, v6
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #2192]                ; 8-byte Reload
	ldp	q2, q6, [x12]
	fmaxnm.4s	v0, v0, v6
	fmaxnm.4s	v1, v1, v2
	add	x12, x30, #21, lsl #12          ; =86016
	ldp	q6, q2, [x12]
	fmaxnm.4s	v1, v1, v6
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #2168]                ; 8-byte Reload
	ldp	q2, q6, [x12]
	fmaxnm.4s	v0, v0, v6
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #2136]                ; 8-byte Reload
	ldp	q6, q2, [x12]
	fmaxnm.4s	v1, v1, v6
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #2128]                ; 8-byte Reload
	ldp	q2, q6, [x12]
	fmaxnm.4s	v6, v0, v6
	fmaxnm.4s	v7, v1, v2
	ldr	x12, [sp, #2720]                ; 8-byte Reload
	ldp	q1, q0, [x12]
	fmaxnm.4s	v1, v1, v5
	fmaxnm.4s	v0, v0, v5
	ldr	x12, [sp, #2712]                ; 8-byte Reload
	ldp	q2, q16, [x12]
	fmaxnm.4s	v0, v0, v16
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #2704]                ; 8-byte Reload
	ldp	q16, q2, [x12]
	fmaxnm.4s	v1, v1, v16
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #2696]                ; 8-byte Reload
	ldp	q2, q16, [x12]
	fmaxnm.4s	v0, v0, v16
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #2688]                ; 8-byte Reload
	ldp	q16, q2, [x12]
	fmaxnm.4s	v1, v1, v16
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #2648]                ; 8-byte Reload
	ldp	q2, q16, [x12]
	fmaxnm.4s	v0, v0, v16
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #2640]                ; 8-byte Reload
	ldp	q16, q2, [x12]
	fmaxnm.4s	v1, v1, v16
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #2616]                ; 8-byte Reload
	ldp	q2, q16, [x12]
	fmaxnm.4s	v0, v0, v16
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #2584]                ; 8-byte Reload
	ldp	q16, q2, [x12]
	fmaxnm.4s	v1, v1, v16
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #2576]                ; 8-byte Reload
	ldp	q2, q16, [x12]
	fmaxnm.4s	v0, v0, v16
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #2552]                ; 8-byte Reload
	ldp	q16, q2, [x12]
	fmaxnm.4s	v1, v1, v16
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #2520]                ; 8-byte Reload
	ldp	q2, q16, [x12]
	fmaxnm.4s	v0, v0, v16
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #2512]                ; 8-byte Reload
	ldp	q16, q2, [x12]
	fmaxnm.4s	v1, v1, v16
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #2488]                ; 8-byte Reload
	ldp	q2, q16, [x12]
	fmaxnm.4s	v0, v0, v16
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #2456]                ; 8-byte Reload
	ldp	q16, q2, [x12]
	fmaxnm.4s	v1, v1, v16
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #2448]                ; 8-byte Reload
	ldp	q2, q16, [x12]
	fmaxnm.4s	v16, v0, v16
	fmaxnm.4s	v17, v1, v2
	mov	w12, #19072                     ; =0x4a80
	movk	w12, #1, lsl #16
	add	x12, x30, x12
	ldp	q1, q0, [x12]
	fmaxnm.4s	v0, v0, v5
	ldr	x12, [sp, #2840]                ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v5
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #2832]                ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #2824]                ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #2816]                ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #2808]                ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #2800]                ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #2792]                ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #2784]                ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #2776]                ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #2768]                ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #2760]                ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #2752]                ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #2744]                ; 8-byte Reload
	ldp	q2, q3, [x12]
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v1, v1, v2
	ldr	x12, [sp, #2736]                ; 8-byte Reload
	ldp	q3, q2, [x12]
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v0, v0, v2
	ldr	x12, [sp, #2728]                ; 8-byte Reload
	ldr	q2, [x12, #16]
	fmaxnm.4s	v2, v0, v2
	ldr	q0, [x12]
	fmaxnm.4s	v0, v1, v0
	fmaxnm.4s	v0, v23, v0
	str	q0, [sp, #4928]                 ; 16-byte Spill
	mov	w12, #-1026555904               ; =0xc2d00000
	dup.4s	v27, w12
	fsub.4s	v0, v23, v0
	fcmge.4s	v1, v0, v27
	mov	w12, #1120403456                ; =0x42c80000
	dup.4s	v23, w12
	fcmge.4s	v18, v23, v0
	and.16b	v1, v1, v18
	fmaxnm.4s	v2, v22, v2
	str	q2, [sp, #4912]                 ; 16-byte Spill
	fsub.4s	v18, v22, v2
	fcmge.4s	v2, v18, v27
	fcmge.4s	v22, v23, v18
	and.16b	v2, v2, v22
	and.16b	v2, v2, v18
	mov	w12, #43579                     ; =0xaa3b
	movk	w12, #16312, lsl #16
	dup.4s	v22, w12
	fmul.4s	v28, v2, v22
	mvni.4s	v13, #128, lsl #24
	mov.16b	v29, v13
	bsl.16b	v29, v20, v28
	fadd.4s	v28, v28, v29
	fsub.4s	v28, v28, v29
	and.16b	v29, v1, v0
	fmul.4s	v1, v29, v22
	mov.16b	v30, v13
	bsl.16b	v30, v20, v1
	fadd.4s	v1, v1, v30
	fsub.4s	v30, v1, v30
	fcvtzs.4s	v12, v28
	scvtf.4s	v28, v12
	mov	w12, #29184                     ; =0x7200
	movk	w12, #16177, lsl #16
	dup.4s	v10, w12
	fmul.4s	v31, v28, v10
	fsub.4s	v31, v2, v31
	fcvtzs.4s	v19, v30
	scvtf.4s	v30, v19
	fmul.4s	v2, v30, v10
	fsub.4s	v29, v29, v2
	mov	w12, #48782                     ; =0xbe8e
	movk	w12, #13759, lsl #16
	dup.4s	v2, w12
	fmul.4s	v30, v30, v2
	movi.4s	v3, #75, lsl #24
	fsub.4s	v20, v29, v30
	fmul.4s	v28, v28, v2
	fsub.4s	v21, v31, v28
	mov	w12, #11226                     ; =0x2bda
	movk	w12, #14672, lsl #16
	dup.4s	v28, w12
	fmul.4s	v30, v21, v28
	mov	w12, #38601                     ; =0x96c9
	movk	w12, #15030, lsl #16
	dup.4s	v29, w12
	fadd.4s	v30, v30, v29
	fmul.4s	v31, v21, v30
	mov	w12, #34982                     ; =0x88a6
	movk	w12, #15368, lsl #16
	dup.4s	v30, w12
	fadd.4s	v31, v31, v30
	fmul.4s	v9, v21, v31
	mov	w12, #43642                     ; =0xaa7a
	movk	w12, #15658, lsl #16
	dup.4s	v31, w12
	fadd.4s	v9, v9, v31
	fmul.4s	v8, v21, v9
	mov	w12, #43691                     ; =0xaaab
	movk	w12, #15914, lsl #16
	dup.4s	v9, w12
	fadd.4s	v8, v8, v9
	fmul.4s	v8, v21, v8
	fadd.4s	v8, v8, v26
	movi.4s	v11, #63, lsl #24
	fmul.4s	v26, v21, v21
	fmul.4s	v26, v26, v8
	fmul.4s	v8, v20, v28
	fadd.4s	v8, v8, v29
	fmul.4s	v8, v20, v8
	fadd.4s	v8, v8, v30
	fmul.4s	v8, v20, v8
	fadd.4s	v8, v8, v31
	fmul.4s	v8, v20, v8
	fadd.4s	v8, v8, v9
	fmul.4s	v8, v20, v8
	fadd.4s	v8, v8, v11
	fmul.4s	v25, v20, v20
	fmul.4s	v25, v25, v8
	fadd.4s	v20, v20, v25
	fadd.4s	v21, v21, v26
	fmov.4s	v1, #1.00000000
	fadd.4s	v20, v20, v1
	sshr.4s	v25, v19, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v1
	fmul.4s	v20, v20, v26
	fadd.4s	v21, v21, v1
	sshr.4s	v26, v12, #1
	shl.4s	v8, v26, #23
	add.4s	v8, v8, v1
	fmul.4s	v21, v21, v8
	sub.4s	v19, v19, v25
	sub.4s	v25, v12, v26
	shl.4s	v25, v25, #23
	add.4s	v25, v25, v1
	fmul.4s	v21, v21, v25
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v1
	fmul.4s	v19, v20, v19
	fcmgt.4s	v20, v27, v0
	bic.16b	v19, v19, v20
	fcmgt.4s	v20, v27, v18
	bic.16b	v20, v21, v20
	fcmgt.4s	v21, v18, v23
	fneg.4s	v12, v5
	bit.16b	v20, v12, v21
	fcmgt.4s	v21, v0, v23
	bit.16b	v19, v12, v21
	fcmeq.4s	v0, v0, v0
	ldr	q8, [sp, #784]                  ; 16-byte Reload
	bsl.16b	v0, v19, v8
	str	q0, [sp, #4864]                 ; 16-byte Spill
	fcmeq.4s	v0, v18, v18
	bsl.16b	v0, v20, v8
	str	q0, [sp, #4848]                 ; 16-byte Spill
	ldr	q0, [sp, #4816]                 ; 16-byte Reload
	fmaxnm.4s	v5, v0, v17
	str	q5, [sp, #4896]                 ; 16-byte Spill
	fsub.4s	v0, v0, v5
	fcmge.4s	v17, v0, v27
	fcmge.4s	v18, v23, v0
	and.16b	v17, v17, v18
	ldr	q5, [sp, #4832]                 ; 16-byte Reload
	fmaxnm.4s	v16, v5, v16
	str	q16, [sp, #4880]                ; 16-byte Spill
	fsub.4s	v16, v5, v16
	fcmge.4s	v18, v16, v27
	fcmge.4s	v19, v23, v16
	and.16b	v18, v18, v19
	and.16b	v18, v18, v16
	fmul.4s	v19, v18, v22
	mov.16b	v20, v13
	bsl.16b	v20, v3, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v17, v17, v0
	fmul.4s	v20, v17, v22
	mov.16b	v21, v13
	bsl.16b	v21, v3, v20
	fadd.4s	v20, v20, v21
	fsub.4s	v20, v20, v21
	fcvtzs.4s	v19, v19
	scvtf.4s	v21, v19
	fmul.4s	v25, v21, v10
	fsub.4s	v18, v18, v25
	fcvtzs.4s	v20, v20
	scvtf.4s	v25, v20
	fmul.4s	v26, v25, v10
	fsub.4s	v17, v17, v26
	fmul.4s	v25, v25, v2
	fsub.4s	v17, v17, v25
	fmul.4s	v21, v21, v2
	fsub.4s	v18, v18, v21
	fmul.4s	v21, v18, v28
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v18, v21
	fadd.4s	v21, v21, v30
	fmul.4s	v21, v18, v21
	fadd.4s	v21, v21, v31
	fmul.4s	v21, v18, v21
	fadd.4s	v21, v21, v9
	fmul.4s	v21, v18, v21
	fadd.4s	v21, v21, v11
	fmul.4s	v25, v18, v18
	fmul.4s	v21, v25, v21
	fmul.4s	v25, v17, v28
	fadd.4s	v25, v25, v29
	fmul.4s	v25, v17, v25
	fadd.4s	v25, v25, v30
	fmul.4s	v25, v17, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v25, v17, v25
	fadd.4s	v25, v25, v9
	fmul.4s	v25, v17, v25
	fadd.4s	v25, v25, v11
	ldr	q11, [sp, #4304]                ; 16-byte Reload
	fmul.4s	v26, v17, v17
	fmul.4s	v25, v26, v25
	fadd.4s	v17, v17, v25
	fadd.4s	v18, v18, v21
	fadd.4s	v17, v17, v1
	sshr.4s	v21, v20, #1
	shl.4s	v25, v21, #23
	add.4s	v25, v25, v1
	fmul.4s	v17, v17, v25
	fadd.4s	v18, v18, v1
	sshr.4s	v25, v19, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v1
	fmul.4s	v18, v18, v26
	movi.4s	v26, #63, lsl #24
	sub.4s	v20, v20, v21
	sub.4s	v19, v19, v25
	ldr	q25, [sp, #4336]                ; 16-byte Reload
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v1
	fmul.4s	v18, v18, v19
	shl.4s	v19, v20, #23
	add.4s	v19, v19, v1
	fmul.4s	v17, v17, v19
	fcmgt.4s	v19, v27, v0
	bic.16b	v17, v17, v19
	fcmgt.4s	v19, v27, v16
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v16, v23
	bit.16b	v18, v12, v19
	fcmgt.4s	v19, v0, v23
	bit.16b	v17, v12, v19
	fcmeq.4s	v0, v0, v0
	bsl.16b	v0, v17, v8
	str	q0, [sp, #4800]                 ; 16-byte Spill
	fcmeq.4s	v0, v16, v16
	bsl.16b	v0, v18, v8
	str	q0, [sp, #4784]                 ; 16-byte Spill
	ldr	q0, [sp, #4752]                 ; 16-byte Reload
	fmaxnm.4s	v5, v0, v7
	str	q5, [sp, #4832]                 ; 16-byte Spill
	fsub.4s	v0, v0, v5
	fcmge.4s	v7, v0, v27
	fcmge.4s	v16, v23, v0
	and.16b	v7, v7, v16
	ldr	q5, [sp, #4768]                 ; 16-byte Reload
	fmaxnm.4s	v6, v5, v6
	str	q6, [sp, #4816]                 ; 16-byte Spill
	fsub.4s	v6, v5, v6
	fcmge.4s	v16, v6, v27
	fcmge.4s	v17, v23, v6
	and.16b	v16, v16, v17
	and.16b	v16, v16, v6
	fmul.4s	v17, v16, v22
	mov.16b	v18, v13
	bsl.16b	v18, v3, v17
	fadd.4s	v17, v17, v18
	fsub.4s	v17, v17, v18
	and.16b	v7, v7, v0
	fmul.4s	v18, v7, v22
	mov.16b	v19, v13
	bsl.16b	v19, v3, v18
	fadd.4s	v18, v18, v19
	fsub.4s	v18, v18, v19
	fcvtzs.4s	v17, v17
	scvtf.4s	v19, v17
	fmul.4s	v20, v19, v10
	fsub.4s	v16, v16, v20
	fcvtzs.4s	v18, v18
	scvtf.4s	v20, v18
	fmul.4s	v21, v20, v10
	fsub.4s	v7, v7, v21
	fmul.4s	v20, v20, v2
	fsub.4s	v7, v7, v20
	fmul.4s	v19, v19, v2
	fsub.4s	v16, v16, v19
	fmul.4s	v19, v16, v28
	fadd.4s	v19, v19, v29
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v30
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v31
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v26
	fmul.4s	v20, v16, v16
	fmul.4s	v19, v20, v19
	fmul.4s	v20, v7, v28
	fadd.4s	v20, v20, v29
	fmul.4s	v20, v7, v20
	fadd.4s	v20, v20, v30
	fmul.4s	v20, v7, v20
	fadd.4s	v20, v20, v31
	fmul.4s	v20, v7, v20
	fadd.4s	v20, v20, v9
	fmul.4s	v20, v7, v20
	fadd.4s	v20, v20, v26
	fmul.4s	v21, v7, v7
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	fadd.4s	v16, v16, v19
	fadd.4s	v7, v7, v1
	sshr.4s	v19, v18, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v1
	fmul.4s	v7, v7, v20
	fadd.4s	v16, v16, v1
	sshr.4s	v20, v17, #1
	shl.4s	v21, v20, #23
	add.4s	v21, v21, v1
	fmul.4s	v16, v16, v21
	ldr	q21, [sp, #4352]                ; 16-byte Reload
	sub.4s	v18, v18, v19
	sub.4s	v17, v17, v20
	movi.4s	v20, #75, lsl #24
	shl.4s	v17, v17, #23
	add.4s	v17, v17, v1
	fmul.4s	v16, v16, v17
	shl.4s	v17, v18, #23
	add.4s	v17, v17, v1
	fmul.4s	v7, v7, v17
	fcmgt.4s	v17, v27, v0
	bic.16b	v7, v7, v17
	fcmgt.4s	v17, v27, v6
	bic.16b	v16, v16, v17
	fcmgt.4s	v17, v6, v23
	bit.16b	v16, v12, v17
	fcmgt.4s	v17, v0, v23
	bit.16b	v7, v12, v17
	fcmeq.4s	v0, v0, v0
	bsl.16b	v0, v7, v8
	str	q0, [sp, #4736]                 ; 16-byte Spill
	fcmeq.4s	v0, v6, v6
	bsl.16b	v0, v16, v8
	str	q0, [sp, #4720]                 ; 16-byte Spill
	ldr	q0, [sp, #4688]                 ; 16-byte Reload
	fmaxnm.4s	v3, v0, v4
	str	q3, [sp, #4768]                 ; 16-byte Spill
	fsub.4s	v0, v0, v3
	fcmge.4s	v5, v0, v27
	fcmge.4s	v6, v23, v0
	and.16b	v5, v5, v6
	ldr	q3, [sp, #4704]                 ; 16-byte Reload
	fmaxnm.4s	v4, v3, v14
	str	q4, [sp, #4752]                 ; 16-byte Spill
	ldr	q14, [sp, #4272]                ; 16-byte Reload
	fsub.4s	v4, v3, v4
	fcmge.4s	v6, v4, v27
	fcmge.4s	v7, v23, v4
	and.16b	v6, v6, v7
	and.16b	v6, v6, v4
	fmul.4s	v7, v6, v22
	mov.16b	v16, v13
	bsl.16b	v16, v20, v7
	fadd.4s	v7, v7, v16
	fsub.4s	v7, v7, v16
	and.16b	v5, v5, v0
	fmul.4s	v16, v5, v22
	mov.16b	v17, v13
	bsl.16b	v17, v20, v16
	fadd.4s	v16, v16, v17
	fsub.4s	v16, v16, v17
	fcvtzs.4s	v7, v7
	scvtf.4s	v17, v7
	fmul.4s	v18, v17, v10
	fsub.4s	v6, v6, v18
	fcvtzs.4s	v16, v16
	scvtf.4s	v18, v16
	fmul.4s	v19, v18, v10
	fsub.4s	v5, v5, v19
	fmul.4s	v18, v18, v2
	fsub.4s	v5, v5, v18
	fmul.4s	v17, v17, v2
	fsub.4s	v6, v6, v17
	fmul.4s	v17, v6, v28
	fadd.4s	v17, v17, v29
	fmul.4s	v17, v6, v17
	fadd.4s	v17, v17, v30
	fmul.4s	v17, v6, v17
	fadd.4s	v17, v17, v31
	fmul.4s	v17, v6, v17
	fadd.4s	v17, v17, v9
	fmul.4s	v17, v6, v17
	fadd.4s	v17, v17, v26
	fmul.4s	v18, v6, v6
	fmul.4s	v17, v18, v17
	fmul.4s	v18, v5, v28
	fadd.4s	v18, v18, v29
	fmul.4s	v18, v5, v18
	fadd.4s	v18, v18, v30
	fmul.4s	v18, v5, v18
	fadd.4s	v18, v18, v31
	fmul.4s	v18, v5, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v5, v18
	fadd.4s	v18, v18, v26
	fmul.4s	v19, v5, v5
	fmul.4s	v18, v19, v18
	fadd.4s	v5, v5, v18
	fadd.4s	v6, v6, v17
	fadd.4s	v5, v5, v1
	sshr.4s	v17, v16, #1
	shl.4s	v18, v17, #23
	add.4s	v18, v18, v1
	fmul.4s	v5, v5, v18
	fadd.4s	v6, v6, v1
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v1
	fmul.4s	v6, v6, v19
	fmov.4s	v19, #1.00000000
	sub.4s	v16, v16, v17
	sub.4s	v7, v7, v18
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v19
	fmul.4s	v6, v6, v7
	shl.4s	v7, v16, #23
	add.4s	v7, v7, v19
	fmul.4s	v5, v5, v7
	fcmgt.4s	v7, v27, v0
	bic.16b	v5, v5, v7
	fcmgt.4s	v7, v27, v4
	bic.16b	v6, v6, v7
	fcmgt.4s	v7, v4, v23
	bit.16b	v6, v12, v7
	fcmgt.4s	v7, v0, v23
	bit.16b	v5, v12, v7
	fcmeq.4s	v0, v0, v0
	bsl.16b	v0, v5, v8
	str	q0, [sp, #4672]                 ; 16-byte Spill
	fcmeq.4s	v0, v4, v4
	bsl.16b	v0, v6, v8
	str	q0, [sp, #4656]                 ; 16-byte Spill
	ldr	q0, [sp, #4624]                 ; 16-byte Reload
	fmaxnm.4s	v1, v0, v15
	str	q1, [sp, #4704]                 ; 16-byte Spill
	ldr	q15, [sp, #4256]                ; 16-byte Reload
	fsub.4s	v0, v0, v1
	fcmge.4s	v3, v0, v27
	fcmge.4s	v4, v23, v0
	and.16b	v4, v3, v4
	ldr	q1, [sp, #4640]                 ; 16-byte Reload
	ldr	q3, [sp, #4608]                 ; 16-byte Reload
	fmaxnm.4s	v3, v1, v3
	str	q3, [sp, #4688]                 ; 16-byte Spill
	fsub.4s	v3, v1, v3
	fcmge.4s	v5, v3, v27
	fcmge.4s	v6, v23, v3
	and.16b	v5, v5, v6
	and.16b	v5, v5, v3
	fmul.4s	v6, v5, v22
	mov.16b	v7, v13
	bsl.16b	v7, v20, v6
	fadd.4s	v6, v6, v7
	fsub.4s	v6, v6, v7
	and.16b	v4, v4, v0
	fmul.4s	v7, v4, v22
	mov.16b	v16, v13
	bsl.16b	v16, v20, v7
	fadd.4s	v7, v7, v16
	fsub.4s	v7, v7, v16
	fcvtzs.4s	v6, v6
	scvtf.4s	v16, v6
	fmul.4s	v17, v16, v10
	fsub.4s	v5, v5, v17
	fcvtzs.4s	v7, v7
	scvtf.4s	v17, v7
	fmul.4s	v18, v17, v10
	fsub.4s	v4, v4, v18
	fmul.4s	v17, v17, v2
	fsub.4s	v4, v4, v17
	fmul.4s	v16, v16, v2
	fsub.4s	v5, v5, v16
	fmul.4s	v16, v5, v28
	fadd.4s	v16, v16, v29
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v30
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v31
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v9
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v17, v5, v5
	fmul.4s	v16, v17, v16
	fmul.4s	v17, v4, v28
	fadd.4s	v17, v17, v29
	fmul.4s	v17, v4, v17
	fadd.4s	v17, v17, v30
	fmul.4s	v17, v4, v17
	fadd.4s	v17, v17, v31
	fmul.4s	v17, v4, v17
	fadd.4s	v17, v17, v9
	fmul.4s	v17, v4, v17
	fadd.4s	v17, v17, v26
	fmul.4s	v18, v4, v4
	fmul.4s	v17, v18, v17
	fadd.4s	v4, v4, v17
	fadd.4s	v5, v5, v16
	fadd.4s	v4, v4, v19
	sshr.4s	v16, v7, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v19
	fmul.4s	v4, v4, v17
	fadd.4s	v5, v5, v19
	sshr.4s	v17, v6, #1
	shl.4s	v18, v17, #23
	add.4s	v18, v18, v19
	fmul.4s	v5, v5, v18
	sub.4s	v7, v7, v16
	sub.4s	v6, v6, v17
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v19
	fmul.4s	v5, v5, v6
	shl.4s	v6, v7, #23
	add.4s	v6, v6, v19
	fmul.4s	v4, v4, v6
	fcmgt.4s	v6, v27, v0
	bic.16b	v4, v4, v6
	fcmgt.4s	v6, v27, v3
	bic.16b	v5, v5, v6
	fcmgt.4s	v6, v3, v23
	bit.16b	v5, v12, v6
	fcmgt.4s	v6, v0, v23
	bit.16b	v4, v12, v6
	fcmeq.4s	v0, v0, v0
	bsl.16b	v0, v4, v8
	str	q0, [sp, #4608]                 ; 16-byte Spill
	fcmeq.4s	v0, v3, v3
	bsl.16b	v0, v5, v8
	str	q0, [sp, #4592]                 ; 16-byte Spill
	ldr	q0, [sp, #4560]                 ; 16-byte Reload
	ldr	q1, [sp, #4528]                 ; 16-byte Reload
	fmaxnm.4s	v1, v0, v1
	str	q1, [sp, #4640]                 ; 16-byte Spill
	fsub.4s	v0, v0, v1
	fcmge.4s	v3, v0, v27
	fcmge.4s	v4, v23, v0
	and.16b	v4, v3, v4
	ldr	q1, [sp, #4576]                 ; 16-byte Reload
	ldr	q3, [sp, #4544]                 ; 16-byte Reload
	fmaxnm.4s	v3, v1, v3
	str	q3, [sp, #4624]                 ; 16-byte Spill
	fsub.4s	v3, v1, v3
	fcmge.4s	v5, v3, v27
	fcmge.4s	v6, v23, v3
	and.16b	v5, v5, v6
	and.16b	v5, v5, v3
	fmul.4s	v6, v5, v22
	mov.16b	v7, v13
	bsl.16b	v7, v20, v6
	fadd.4s	v6, v6, v7
	fsub.4s	v6, v6, v7
	and.16b	v4, v4, v0
	fmul.4s	v7, v4, v22
	mov.16b	v16, v13
	bsl.16b	v16, v20, v7
	fadd.4s	v7, v7, v16
	fsub.4s	v7, v7, v16
	fcvtzs.4s	v6, v6
	scvtf.4s	v16, v6
	fmul.4s	v17, v16, v10
	fsub.4s	v5, v5, v17
	fcvtzs.4s	v7, v7
	scvtf.4s	v17, v7
	fmul.4s	v18, v17, v10
	fsub.4s	v4, v4, v18
	fmul.4s	v17, v17, v2
	fsub.4s	v4, v4, v17
	fmul.4s	v16, v16, v2
	fsub.4s	v5, v5, v16
	fmul.4s	v16, v5, v28
	fadd.4s	v16, v16, v29
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v30
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v31
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v9
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v17, v5, v5
	fmul.4s	v16, v17, v16
	fmul.4s	v17, v4, v28
	fadd.4s	v17, v17, v29
	fmul.4s	v17, v4, v17
	fadd.4s	v17, v17, v30
	fmul.4s	v17, v4, v17
	fadd.4s	v17, v17, v31
	fmul.4s	v17, v4, v17
	fadd.4s	v17, v17, v9
	fmul.4s	v17, v4, v17
	fadd.4s	v17, v17, v26
	fmul.4s	v18, v4, v4
	fmul.4s	v17, v18, v17
	fadd.4s	v4, v4, v17
	fadd.4s	v5, v5, v16
	fadd.4s	v4, v4, v19
	sshr.4s	v16, v7, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v19
	fmul.4s	v4, v4, v17
	fadd.4s	v5, v5, v19
	sshr.4s	v17, v6, #1
	shl.4s	v18, v17, #23
	add.4s	v18, v18, v19
	fmul.4s	v5, v5, v18
	sub.4s	v7, v7, v16
	sub.4s	v6, v6, v17
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v19
	fmul.4s	v5, v5, v6
	shl.4s	v6, v7, #23
	add.4s	v6, v6, v19
	fmul.4s	v4, v4, v6
	fcmgt.4s	v6, v27, v0
	bic.16b	v4, v4, v6
	fcmgt.4s	v6, v27, v3
	bic.16b	v5, v5, v6
	fcmgt.4s	v6, v3, v23
	bit.16b	v5, v12, v6
	fcmgt.4s	v6, v0, v23
	bit.16b	v4, v12, v6
	fcmeq.4s	v0, v0, v0
	bsl.16b	v0, v4, v8
	str	q0, [sp, #4544]                 ; 16-byte Spill
	fcmeq.4s	v0, v3, v3
	bsl.16b	v0, v5, v8
	str	q0, [sp, #4528]                 ; 16-byte Spill
	ldr	q0, [sp, #4496]                 ; 16-byte Reload
	ldr	q1, [sp, #4464]                 ; 16-byte Reload
	fmaxnm.4s	v1, v0, v1
	str	q1, [sp, #4576]                 ; 16-byte Spill
	fsub.4s	v0, v0, v1
	fcmge.4s	v3, v0, v27
	fcmge.4s	v4, v23, v0
	and.16b	v4, v3, v4
	ldr	q1, [sp, #4512]                 ; 16-byte Reload
	ldr	q3, [sp, #4480]                 ; 16-byte Reload
	fmaxnm.4s	v3, v1, v3
	str	q3, [sp, #4560]                 ; 16-byte Spill
	fsub.4s	v3, v1, v3
	fcmge.4s	v5, v3, v27
	fcmge.4s	v6, v23, v3
	and.16b	v5, v5, v6
	and.16b	v5, v5, v3
	fmul.4s	v6, v5, v22
	mov.16b	v7, v13
	bsl.16b	v7, v20, v6
	fadd.4s	v6, v6, v7
	fsub.4s	v6, v6, v7
	and.16b	v4, v4, v0
	fmul.4s	v7, v4, v22
	mov.16b	v16, v13
	bsl.16b	v16, v20, v7
	ldr	q13, [sp, #4288]                ; 16-byte Reload
	fadd.4s	v7, v7, v16
	fsub.4s	v7, v7, v16
	fcvtzs.4s	v6, v6
	scvtf.4s	v16, v6
	fmul.4s	v17, v16, v10
	fsub.4s	v5, v5, v17
	fcvtzs.4s	v7, v7
	scvtf.4s	v17, v7
	fmul.4s	v18, v17, v10
	fsub.4s	v4, v4, v18
	fmul.4s	v17, v17, v2
	fsub.4s	v4, v4, v17
	fmul.4s	v16, v16, v2
	fsub.4s	v5, v5, v16
	fmul.4s	v16, v5, v28
	fadd.4s	v16, v16, v29
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v30
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v31
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v9
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v17, v5, v5
	fmul.4s	v16, v17, v16
	fmul.4s	v17, v4, v28
	fadd.4s	v17, v17, v29
	fmul.4s	v17, v4, v17
	fadd.4s	v17, v17, v30
	fmul.4s	v17, v4, v17
	fadd.4s	v17, v17, v31
	fmul.4s	v17, v4, v17
	fadd.4s	v17, v17, v9
	fmul.4s	v17, v4, v17
	fadd.4s	v17, v17, v26
	fmul.4s	v18, v4, v4
	fmul.4s	v17, v18, v17
	fadd.4s	v4, v4, v17
	fadd.4s	v5, v5, v16
	fadd.4s	v4, v4, v19
	sshr.4s	v16, v7, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v19
	fmul.4s	v4, v4, v17
	fadd.4s	v5, v5, v19
	sshr.4s	v17, v6, #1
	shl.4s	v18, v17, #23
	add.4s	v18, v18, v19
	fmul.4s	v5, v5, v18
	mvni.4s	v18, #128, lsl #24
	sub.4s	v7, v7, v16
	sub.4s	v6, v6, v17
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v19
	fmul.4s	v5, v5, v6
	shl.4s	v6, v7, #23
	add.4s	v6, v6, v19
	fmul.4s	v4, v4, v6
	fcmgt.4s	v6, v27, v0
	bic.16b	v4, v4, v6
	fcmgt.4s	v6, v27, v3
	bic.16b	v5, v5, v6
	fcmgt.4s	v6, v3, v23
	bit.16b	v5, v12, v6
	fcmgt.4s	v6, v0, v23
	bit.16b	v4, v12, v6
	fcmeq.4s	v0, v0, v0
	bsl.16b	v0, v4, v8
	str	q0, [sp, #4480]                 ; 16-byte Spill
	fcmeq.4s	v0, v3, v3
	bsl.16b	v0, v5, v8
	str	q0, [sp, #4464]                 ; 16-byte Spill
	ldr	q0, [sp, #4224]                 ; 16-byte Reload
	ldr	q1, [sp, #3984]                 ; 16-byte Reload
	fmaxnm.4s	v1, v0, v1
	str	q1, [sp, #4512]                 ; 16-byte Spill
	fsub.4s	v0, v0, v1
	fcmge.4s	v3, v0, v27
	fcmge.4s	v4, v23, v0
	and.16b	v4, v3, v4
	ldr	q1, [sp, #4208]                 ; 16-byte Reload
	ldr	q3, [sp, #4000]                 ; 16-byte Reload
	fmaxnm.4s	v3, v1, v3
	str	q3, [sp, #4496]                 ; 16-byte Spill
	fsub.4s	v3, v1, v3
	fcmge.4s	v5, v3, v27
	fcmge.4s	v6, v23, v3
	and.16b	v5, v5, v6
	and.16b	v5, v5, v3
	fmul.4s	v6, v5, v22
	mov.16b	v7, v18
	bsl.16b	v7, v20, v6
	fadd.4s	v6, v6, v7
	fsub.4s	v6, v6, v7
	and.16b	v4, v4, v0
	fmul.4s	v7, v4, v22
	mov.16b	v16, v18
	bsl.16b	v16, v20, v7
	fadd.4s	v7, v7, v16
	fsub.4s	v7, v7, v16
	fcvtzs.4s	v6, v6
	scvtf.4s	v16, v6
	fmul.4s	v17, v16, v10
	fsub.4s	v5, v5, v17
	fcvtzs.4s	v7, v7
	scvtf.4s	v17, v7
	fmul.4s	v1, v17, v10
	ldr	q10, [sp, #4320]                ; 16-byte Reload
	fsub.4s	v1, v4, v1
	fmul.4s	v4, v16, v2
	fmul.4s	v2, v17, v2
	fsub.4s	v1, v1, v2
	fsub.4s	v2, v5, v4
	fmul.4s	v4, v2, v28
	fadd.4s	v4, v4, v29
	fmul.4s	v4, v2, v4
	fadd.4s	v4, v4, v30
	fmul.4s	v4, v2, v4
	fadd.4s	v4, v4, v31
	fmul.4s	v4, v2, v4
	fadd.4s	v4, v4, v9
	fmul.4s	v4, v2, v4
	fadd.4s	v4, v4, v26
	fmul.4s	v5, v2, v2
	fmul.4s	v4, v5, v4
	fmul.4s	v5, v1, v28
	fadd.4s	v5, v5, v29
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v30
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v31
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v9
	fmul.4s	v5, v1, v5
	fadd.4s	v5, v5, v26
	fmul.4s	v16, v1, v1
	fmul.4s	v5, v16, v5
	fadd.4s	v1, v1, v5
	fadd.4s	v2, v2, v4
	fadd.4s	v1, v1, v19
	sshr.4s	v4, v7, #1
	shl.4s	v5, v4, #23
	add.4s	v5, v5, v19
	fmul.4s	v1, v1, v5
	fadd.4s	v2, v2, v19
	sshr.4s	v5, v6, #1
	shl.4s	v16, v5, #23
	add.4s	v16, v16, v19
	fmul.4s	v2, v2, v16
	sub.4s	v4, v7, v4
	sub.4s	v5, v6, v5
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v19
	fmul.4s	v2, v2, v5
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v19
	fmul.4s	v1, v1, v4
	fcmgt.4s	v4, v27, v0
	bic.16b	v1, v1, v4
	fcmgt.4s	v4, v27, v3
	bic.16b	v2, v2, v4
	fcmgt.4s	v4, v3, v23
	bit.16b	v2, v12, v4
	fcmgt.4s	v4, v0, v23
	bit.16b	v1, v12, v4
	fcmeq.4s	v0, v0, v0
	bif.16b	v1, v8, v0
	fcmeq.4s	v0, v3, v3
	bsl.16b	v0, v2, v8
	mov	w12, #23168                     ; =0x5a80
	movk	w12, #1, lsl #16
	add	x12, x30, x12
	ldr	q4, [sp, #4912]                 ; 16-byte Reload
	ldr	q2, [sp, #4928]                 ; 16-byte Reload
	stp	q2, q4, [x12]
	mov	w12, #23424                     ; =0x5b80
	movk	w12, #1, lsl #16
	add	x12, x30, x12
	ldr	q4, [sp, #4848]                 ; 16-byte Reload
	ldr	q2, [sp, #4864]                 ; 16-byte Reload
	stp	q2, q4, [x12]
	ldr	x12, [sp, #592]                 ; 8-byte Reload
	ldr	q4, [sp, #4880]                 ; 16-byte Reload
	ldr	q2, [sp, #4896]                 ; 16-byte Reload
	stp	q2, q4, [x12]
	ldr	x12, [sp, #568]                 ; 8-byte Reload
	ldr	q4, [sp, #4816]                 ; 16-byte Reload
	ldr	q2, [sp, #4832]                 ; 16-byte Reload
	stp	q2, q4, [x12]
	ldr	x12, [sp, #536]                 ; 8-byte Reload
	ldr	q4, [sp, #4752]                 ; 16-byte Reload
	ldr	q2, [sp, #4768]                 ; 16-byte Reload
	stp	q2, q4, [x12]
	ldr	x12, [sp, #528]                 ; 8-byte Reload
	ldr	q4, [sp, #4688]                 ; 16-byte Reload
	ldr	q2, [sp, #4704]                 ; 16-byte Reload
	stp	q2, q4, [x12]
	ldp	x12, x13, [sp, #496]            ; 16-byte Folded Reload
	ldr	q4, [sp, #4624]                 ; 16-byte Reload
	ldr	q2, [sp, #4640]                 ; 16-byte Reload
	stp	q2, q4, [x13]
	ldr	q4, [sp, #4560]                 ; 16-byte Reload
	ldr	q2, [sp, #4576]                 ; 16-byte Reload
	stp	q2, q4, [x12]
	ldp	x12, x13, [sp, #480]            ; 16-byte Folded Reload
	ldr	q4, [sp, #4496]                 ; 16-byte Reload
	ldr	q2, [sp, #4512]                 ; 16-byte Reload
	stp	q2, q4, [x13]
	ldr	q4, [sp, #4784]                 ; 16-byte Reload
	ldr	q2, [sp, #4800]                 ; 16-byte Reload
	stp	q2, q4, [x12]
	ldp	x12, x13, [sp, #464]            ; 16-byte Folded Reload
	ldr	q4, [sp, #4720]                 ; 16-byte Reload
	ldr	q2, [sp, #4736]                 ; 16-byte Reload
	stp	q2, q4, [x13]
	ldr	q4, [sp, #4656]                 ; 16-byte Reload
	ldr	q2, [sp, #4672]                 ; 16-byte Reload
	stp	q2, q4, [x12]
	ldp	x12, x13, [sp, #448]            ; 16-byte Folded Reload
	ldr	q4, [sp, #4592]                 ; 16-byte Reload
	ldr	q2, [sp, #4608]                 ; 16-byte Reload
	stp	q2, q4, [x13]
	ldr	q4, [sp, #4528]                 ; 16-byte Reload
	ldr	q2, [sp, #4544]                 ; 16-byte Reload
	stp	q2, q4, [x12]
	ldp	x12, x13, [sp, #432]            ; 16-byte Folded Reload
	ldr	q4, [sp, #4464]                 ; 16-byte Reload
	ldr	q2, [sp, #4480]                 ; 16-byte Reload
	stp	q2, q4, [x13]
	str	q0, [sp, #4208]                 ; 16-byte Spill
	stp	q1, q0, [x12]
	str	q1, [sp, #4224]                 ; 16-byte Spill
	ldr	x4, [sp, #4248]                 ; 8-byte Reload
	mov	w30, #48782                     ; =0xbe8e
	movk	w30, #46527, lsl #16
LBB0_77:                                ; %direct.true632
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	x12, x9, #0x78
	orr	x12, x12, x11, lsr #4
	dup.2d	v0, x12
	add.2d	v2, v24, v0
	add.2d	v3, v2, v25
	add.2d	v4, v2, v21
	add.2d	v0, v2, v14
	mov.d	x12, v0[1]
	add	x14, x5, x11, lsl #5
	fmov	x13, d0
	ldp	q0, q1, [x14]
	and	x14, x8, #0xe0
	add	x15, x6, x14
	mov.d	x14, v4[1]
	ldp	q6, q5, [x15]
	fsub.4s	v0, v0, v6
	fsub.4s	v1, v1, v5
	fcmge.4s	v5, v1, v27
	fmov	x15, d4
	fcmge.4s	v4, v0, v27
	fcmge.4s	v6, v23, v1
	fcmge.4s	v7, v23, v0
	and.16b	v4, v4, v7
	mov.d	x16, v3[1]
	and.16b	v5, v5, v6
	and.16b	v5, v5, v1
	and.16b	v4, v4, v0
	fmul.4s	v6, v4, v22
	fmul.4s	v7, v5, v22
	mov.16b	v16, v18
	bsl.16b	v16, v20, v7
	mov.16b	v17, v18
	bsl.16b	v17, v20, v6
	fadd.4s	v6, v6, v17
	fadd.4s	v7, v7, v16
	fsub.4s	v7, v7, v16
	fsub.4s	v6, v6, v17
	fmov	x17, d3
	fcvtzs.4s	v3, v6
	fcvtzs.4s	v6, v7
	scvtf.4s	v7, v6
	dup.4s	v16, w7
	fmul.4s	v17, v7, v16
	fadd.4s	v5, v5, v17
	scvtf.4s	v17, v3
	fmul.4s	v16, v17, v16
	fadd.4s	v4, v4, v16
	dup.4s	v16, w30
	fmul.4s	v7, v7, v16
	fmul.4s	v16, v17, v16
	add.2d	v2, v2, v10
	mov.d	x0, v2[1]
	fadd.4s	v4, v4, v16
	fadd.4s	v5, v5, v7
	fmul.4s	v7, v5, v28
	fmul.4s	v16, v4, v28
	fadd.4s	v16, v16, v29
	fadd.4s	v7, v7, v29
	fmul.4s	v7, v5, v7
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v30
	fadd.4s	v7, v7, v30
	fmul.4s	v7, v5, v7
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v31
	fadd.4s	v7, v7, v31
	fmul.4s	v7, v5, v7
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v9
	fadd.4s	v7, v7, v9
	fmov	x1, d2
	fmul.4s	v2, v5, v7
	fmul.4s	v7, v4, v16
	fadd.4s	v7, v7, v26
	fadd.4s	v2, v2, v26
	fmul.4s	v16, v5, v5
	fmul.4s	v2, v16, v2
	fmul.4s	v16, v4, v4
	fmul.4s	v7, v16, v7
	fadd.4s	v4, v4, v7
	fadd.4s	v2, v5, v2
	sshr.4s	v5, v6, #1
	fadd.4s	v4, v4, v19
	sshr.4s	v7, v3, #1
	shl.4s	v16, v7, #23
	add.4s	v16, v16, v19
	fmul.4s	v4, v4, v16
	shl.4s	v16, v5, #23
	fadd.4s	v2, v2, v19
	add.4s	v16, v16, v19
	fmul.4s	v2, v2, v16
	sub.4s	v3, v3, v7
	sub.4s	v5, v6, v5
	shl.4s	v5, v5, #23
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v19
	add.4s	v5, v5, v19
	fmul.4s	v2, v2, v5
	fmul.4s	v3, v4, v3
	fcmgt.4s	v4, v27, v0
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v27, v1
	bic.16b	v2, v2, v4
	fcmgt.4s	v4, v0, v23
	fcmgt.4s	v5, v1, v23
	bit.16b	v2, v12, v5
	bit.16b	v3, v12, v4
	fcmeq.4s	v4, v0, v0
	dup.2d	v5, x10
	dup.2d	v0, x19
	bif.16b	v3, v8, v4
	add.2d	v4, v0, v5
	add.2d	v5, v4, v15
	mov.d	x2, v5[1]
	fmov	x3, d5
	ldr	b5, [x13]
	ld1.b	{ v5 }[1], [x12]
	ld1.b	{ v5 }[2], [x15]
	ld1.b	{ v5 }[3], [x14]
	ld1.b	{ v5 }[4], [x17]
	ld1.b	{ v5 }[5], [x16]
	ld1.b	{ v5 }[6], [x1]
	ld1.b	{ v5 }[7], [x0]
	cmeq.8b	v5, v5, #0
	sshll.8h	v5, v5, #0
	fcmeq.4s	v1, v1, v1
	bsl.16b	v1, v2, v8
	ldr	q2, [sp, #4960]                 ; 16-byte Reload
	add.2d	v2, v4, v2
	mov.d	x12, v2[1]
	fmov	x13, d2
	sshll.4s	v2, v5, #0
	bic.16b	v2, v3, v2
	sshll2.4s	v3, v5, #0
	str	s2, [x3]
	st1.s	{ v2 }[1], [x2]
	st1.s	{ v2 }[2], [x13]
	bic.16b	v1, v1, v3
	st1.s	{ v2 }[3], [x12]
	add.2d	v2, v4, v11
	mov.d	x12, v2[1]
	fmov	x13, d2
	add.2d	v2, v4, v13
	mov.d	x14, v2[1]
	fmov	x15, d2
	str	s1, [x13]
	st1.s	{ v1 }[1], [x12]
	st1.s	{ v1 }[2], [x15]
	st1.s	{ v1 }[3], [x14]
	add	x11, x11, #1
	add	x10, x10, #4
	add	x9, x9, #8
	add	x8, x8, #2
	cmp	x10, #512
	b.ne	LBB0_77
; %bb.78:                               ; %direct.true672.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	ldr	q17, [sp, #4960]                ; 16-byte Reload
LBB0_79:                                ; %direct.true672
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v1, x8
	add.2d	v1, v0, v1
	add.2d	v2, v1, v13
	add.2d	v3, v1, v11
	add.2d	v4, v1, v17
	add.2d	v1, v1, v15
	mov.d	x9, v1[1]
	fmov	x10, d1
	mov.d	x11, v4[1]
	fmov	x12, d4
	mov.d	x13, v3[1]
	fmov	x14, d3
	mov.d	x15, v2[1]
	ldr	s1, [x10]
	ld1.s	{ v1 }[1], [x9]
	ld1.s	{ v1 }[2], [x12]
	ld1.s	{ v1 }[3], [x11]
	fmov	x9, d2
	ldr	s2, [x14]
	ld1.s	{ v2 }[1], [x13]
	ld1.s	{ v2 }[2], [x9]
	ld1.s	{ v2 }[3], [x15]
	fadd.4s	v5, v5, v2
	fadd.4s	v6, v6, v1
	add	x8, x8, #4
	cmp	x8, #64
	b.ne	LBB0_79
; %bb.80:                               ; %direct.true682.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	str	q6, [sp, #3984]                 ; 16-byte Spill
	str	q5, [sp, #4000]                 ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	ldr	x17, [sp, #3712]                ; 8-byte Reload
	ldr	x0, [sp, #3704]                 ; 8-byte Reload
	ldr	x16, [sp, #3720]                ; 8-byte Reload
	ldr	x1, [sp, #3080]                 ; 8-byte Reload
	ldp	q6, q5, [sp, #816]              ; 32-byte Folded Reload
	ldr	q7, [sp, #800]                  ; 16-byte Reload
	ldr	q16, [sp, #768]                 ; 16-byte Reload
	ldr	x2, [sp, #3736]                 ; 8-byte Reload
	mov	w3, #320                        ; =0x140
	ldr	x5, [sp, #4952]                 ; 8-byte Reload
LBB0_81:                                ; %direct.true682
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	orr	x9, x8, #0x40
	dup.2d	v1, x9
	add.2d	v1, v0, v1
	add.2d	v2, v1, v13
	add.2d	v3, v1, v11
	add.2d	v4, v1, v17
	add.2d	v1, v1, v15
	mov.d	x9, v1[1]
	fmov	x10, d1
	mov.d	x11, v4[1]
	fmov	x12, d4
	mov.d	x13, v3[1]
	fmov	x14, d3
	mov.d	x15, v2[1]
	ldr	s1, [x10]
	ld1.s	{ v1 }[1], [x9]
	ld1.s	{ v1 }[2], [x12]
	ld1.s	{ v1 }[3], [x11]
	fmov	x9, d2
	ldr	s2, [x14]
	ld1.s	{ v2 }[1], [x13]
	ld1.s	{ v2 }[2], [x9]
	ld1.s	{ v2 }[3], [x15]
	fadd.4s	v18, v18, v2
	fadd.4s	v19, v19, v1
	add	x8, x8, #4
	cmp	x8, #64
	b.ne	LBB0_81
; %bb.82:                               ; %direct.true692.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
LBB0_83:                                ; %direct.true692
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	orr	x9, x8, #0x80
	dup.2d	v1, x9
	add.2d	v1, v0, v1
	add.2d	v2, v1, v13
	add.2d	v3, v1, v11
	add.2d	v4, v1, v17
	add.2d	v1, v1, v15
	mov.d	x9, v1[1]
	fmov	x10, d1
	mov.d	x11, v4[1]
	fmov	x12, d4
	mov.d	x13, v3[1]
	fmov	x14, d3
	mov.d	x15, v2[1]
	ldr	s1, [x10]
	ld1.s	{ v1 }[1], [x9]
	ld1.s	{ v1 }[2], [x12]
	ld1.s	{ v1 }[3], [x11]
	fmov	x9, d2
	ldr	s2, [x14]
	ld1.s	{ v2 }[1], [x13]
	ld1.s	{ v2 }[2], [x9]
	ld1.s	{ v2 }[3], [x15]
	fadd.4s	v20, v20, v2
	fadd.4s	v21, v21, v1
	add	x8, x8, #4
	cmp	x8, #64
	b.ne	LBB0_83
; %bb.84:                               ; %direct.true702.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
LBB0_85:                                ; %direct.true702
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	orr	x9, x8, #0xc0
	dup.2d	v1, x9
	add.2d	v1, v0, v1
	add.2d	v2, v1, v13
	add.2d	v3, v1, v11
	add.2d	v4, v1, v17
	add.2d	v1, v1, v15
	mov.d	x9, v1[1]
	fmov	x10, d1
	mov.d	x11, v4[1]
	fmov	x12, d4
	mov.d	x13, v3[1]
	fmov	x14, d3
	mov.d	x15, v2[1]
	ldr	s1, [x10]
	ld1.s	{ v1 }[1], [x9]
	ld1.s	{ v1 }[2], [x12]
	ld1.s	{ v1 }[3], [x11]
	fmov	x9, d2
	ldr	s2, [x14]
	ld1.s	{ v2 }[1], [x13]
	ld1.s	{ v2 }[2], [x9]
	ld1.s	{ v2 }[3], [x15]
	fadd.4s	v22, v22, v2
	fadd.4s	v23, v23, v1
	add	x8, x8, #4
	cmp	x8, #64
	b.ne	LBB0_85
; %bb.86:                               ; %direct.true712.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
LBB0_87:                                ; %direct.true712
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	orr	x9, x8, #0x100
	dup.2d	v1, x9
	add.2d	v1, v0, v1
	add.2d	v2, v1, v13
	add.2d	v3, v1, v11
	add.2d	v4, v1, v17
	add.2d	v1, v1, v15
	mov.d	x9, v1[1]
	fmov	x10, d1
	mov.d	x11, v4[1]
	fmov	x12, d4
	mov.d	x13, v3[1]
	fmov	x14, d3
	mov.d	x15, v2[1]
	ldr	s1, [x10]
	ld1.s	{ v1 }[1], [x9]
	ld1.s	{ v1 }[2], [x12]
	ld1.s	{ v1 }[3], [x11]
	fmov	x9, d2
	ldr	s2, [x14]
	ld1.s	{ v2 }[1], [x13]
	ld1.s	{ v2 }[2], [x9]
	ld1.s	{ v2 }[3], [x15]
	fadd.4s	v24, v24, v2
	fadd.4s	v25, v25, v1
	add	x8, x8, #4
	cmp	x8, #64
	b.ne	LBB0_87
; %bb.88:                               ; %direct.true722.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
LBB0_89:                                ; %direct.true722
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	orr	x9, x8, x3
	dup.2d	v1, x9
	add.2d	v1, v0, v1
	add.2d	v2, v1, v13
	add.2d	v3, v1, v11
	add.2d	v4, v1, v17
	add.2d	v1, v1, v15
	mov.d	x9, v1[1]
	fmov	x10, d1
	mov.d	x11, v4[1]
	fmov	x12, d4
	mov.d	x13, v3[1]
	fmov	x14, d3
	mov.d	x15, v2[1]
	ldr	s1, [x10]
	ld1.s	{ v1 }[1], [x9]
	ld1.s	{ v1 }[2], [x12]
	ld1.s	{ v1 }[3], [x11]
	fmov	x9, d2
	ldr	s2, [x14]
	ld1.s	{ v2 }[1], [x13]
	ld1.s	{ v2 }[2], [x9]
	ld1.s	{ v2 }[3], [x15]
	fadd.4s	v26, v26, v2
	fadd.4s	v27, v27, v1
	add	x8, x8, #4
	cmp	x8, #64
	b.ne	LBB0_89
; %bb.90:                               ; %direct.true732.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
LBB0_91:                                ; %direct.true732
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	orr	x9, x8, #0x180
	dup.2d	v1, x9
	add.2d	v1, v0, v1
	add.2d	v2, v1, v13
	add.2d	v3, v1, v11
	add.2d	v4, v1, v17
	add.2d	v1, v1, v15
	mov.d	x9, v1[1]
	fmov	x10, d1
	mov.d	x11, v4[1]
	fmov	x12, d4
	mov.d	x13, v3[1]
	fmov	x14, d3
	mov.d	x15, v2[1]
	ldr	s1, [x10]
	ld1.s	{ v1 }[1], [x9]
	ld1.s	{ v1 }[2], [x12]
	ld1.s	{ v1 }[3], [x11]
	fmov	x9, d2
	ldr	s2, [x14]
	ld1.s	{ v2 }[1], [x13]
	ld1.s	{ v2 }[2], [x9]
	ld1.s	{ v2 }[3], [x15]
	fadd.4s	v28, v28, v2
	fadd.4s	v29, v29, v1
	add	x8, x8, #4
	cmp	x8, #64
	b.ne	LBB0_91
; %bb.92:                               ; %direct.true742.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	movi.2d	v30, #0000000000000000
	movi.2d	v31, #0000000000000000
LBB0_93:                                ; %direct.true742
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	orr	x9, x8, #0x1c0
	dup.2d	v1, x9
	add.2d	v1, v0, v1
	add.2d	v2, v1, v13
	add.2d	v3, v1, v11
	add.2d	v4, v1, v17
	add.2d	v1, v1, v15
	mov.d	x9, v1[1]
	fmov	x10, d1
	mov.d	x11, v4[1]
	fmov	x12, d4
	mov.d	x13, v3[1]
	fmov	x14, d3
	mov.d	x15, v2[1]
	ldr	s1, [x10]
	ld1.s	{ v1 }[1], [x9]
	ld1.s	{ v1 }[2], [x12]
	ld1.s	{ v1 }[3], [x11]
	fmov	x9, d2
	ldr	s2, [x14]
	ld1.s	{ v2 }[1], [x13]
	ld1.s	{ v2 }[2], [x9]
	ld1.s	{ v2 }[3], [x15]
	fadd.4s	v30, v30, v2
	fadd.4s	v31, v31, v1
	add	x8, x8, #4
	cmp	x8, #64
	b.ne	LBB0_93
; %bb.94:                               ; %direct.true768.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	ldr	x12, [sp, #368]                 ; 8-byte Reload
	mov	w13, #43691                     ; =0xaaab
LBB0_95:                                ; %direct.true768
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w10, w9, #0xffff
	mul	w10, w10, w13
	lsr	w10, w10, #21
	msub	w11, w10, w25, w9
	and	x11, x11, #0xffff
	umaddl	x11, w10, w25, x11
	add	x11, x16, x11, lsl #5
	ldp	q0, q1, [x11]
	add	x10, x12, x10, lsl #5
	ldp	q2, q3, [x10]
	fmul.4s	v1, v1, v3
	dup.2d	v3, x8
	dup.2d	v4, x0
	fmul.4s	v0, v0, v2
	add.2d	v2, v3, v4
	add.2d	v3, v2, v5
	add.2d	v4, v2, v16
	mov.d	x10, v4[1]
	fmov	x11, d4
	str	s0, [x11]
	st1.s	{ v0 }[1], [x10]
	mov.d	x10, v3[1]
	add.2d	v4, v2, v6
	fmov	x11, d3
	st1.s	{ v0 }[2], [x11]
	st1.s	{ v0 }[3], [x10]
	mov.d	x10, v4[1]
	fmov	x11, d4
	str	s1, [x11]
	st1.s	{ v1 }[1], [x10]
	add.2d	v0, v2, v7
	mov.d	x10, v0[1]
	fmov	x11, d0
	st1.s	{ v1 }[2], [x11]
	st1.s	{ v1 }[3], [x10]
	add	x9, x9, #1
	add	x8, x8, #4
	cmp	x8, #1536
	b.ne	LBB0_95
; %bb.96:                               ; %mma.update.i404.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	mov	x10, x0
LBB0_97:                                ; %mma.update.i404
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_98 Depth 3
	mov	x11, x10
	mov	x12, x8
	mov	w13, #12                        ; =0xc
LBB0_98:                                ; %mma.update2.i
                                        ;   Parent Loop BB0_17 Depth=1
                                        ;     Parent Loop BB0_97 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	umulh	x14, x12, x24
	lsr	x15, x14, #5
	msub	x16, x15, x25, x12
	ldr	q0, [x11]
	lsl	x14, x14, #1
	and	x14, x14, #0x1c0
	add	x15, x19, x14
	add	x14, x4, x16, lsl #2
	ldr	q1, [x14]
	ldp	s2, s3, [x15]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #192]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #384]
	ldp	s2, s3, [x15, #8]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #576]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #768]
	ldp	s2, s3, [x15, #16]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #960]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1152]
	ldp	s2, s3, [x15, #24]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1344]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1536]
	ldp	s2, s3, [x15, #32]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1728]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1920]
	ldp	s2, s3, [x15, #40]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2112]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2304]
	ldp	s2, s3, [x15, #48]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2496]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2688]
	ldp	s2, s3, [x15, #56]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2880]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	str	q0, [x11, #12288]
	add	x12, x12, #4
	add	x11, x11, #16
	subs	x13, x13, #1
	b.ne	LBB0_98
; %bb.99:                               ; %mma.fold.done3.i
                                        ;   in Loop: Header=BB0_97 Depth=2
	add	x9, x9, #1
	add	x8, x8, #48
	add	x10, x10, #192
	cmp	x9, #8
	b.ne	LBB0_97
; %bb.100:                              ; %mma.update.i406.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	add	x10, x0, #1536
LBB0_101:                               ; %mma.update.i406
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_102 Depth 3
	mov	x11, x10
	mov	x12, x8
	mov	w13, #12                        ; =0xc
LBB0_102:                               ; %mma.update2.i408
                                        ;   Parent Loop BB0_17 Depth=1
                                        ;     Parent Loop BB0_101 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	umulh	x14, x12, x24
	lsr	x15, x14, #5
	msub	x16, x15, x25, x12
	ldr	q0, [x11]
	lsl	x14, x14, #1
	and	x14, x14, #0x1c0
	add	x15, x1, x14
	add	x14, x23, x16, lsl #2
	ldr	q1, [x14]
	ldp	s2, s3, [x15]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #192]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #384]
	ldp	s2, s3, [x15, #8]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #576]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #768]
	ldp	s2, s3, [x15, #16]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #960]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1152]
	ldp	s2, s3, [x15, #24]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1344]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1536]
	ldp	s2, s3, [x15, #32]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1728]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1920]
	ldp	s2, s3, [x15, #40]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2112]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2304]
	ldp	s2, s3, [x15, #48]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2496]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2688]
	ldp	s2, s3, [x15, #56]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2880]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	str	q0, [x11, #12288]
	add	x12, x12, #4
	add	x11, x11, #16
	subs	x13, x13, #1
	b.ne	LBB0_102
; %bb.103:                              ; %mma.fold.done3.i443
                                        ;   in Loop: Header=BB0_101 Depth=2
	add	x9, x9, #1
	add	x8, x8, #48
	add	x10, x10, #192
	cmp	x9, #8
	b.ne	LBB0_101
; %bb.104:                              ; %mma.update.i446.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	add	x10, x0, #3072
	ldr	x0, [sp, #3120]                 ; 8-byte Reload
	ldr	x1, [sp, #3072]                 ; 8-byte Reload
LBB0_105:                               ; %mma.update.i446
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_106 Depth 3
	mov	x11, x10
	mov	x12, x8
	mov	w13, #12                        ; =0xc
LBB0_106:                               ; %mma.update2.i448
                                        ;   Parent Loop BB0_17 Depth=1
                                        ;     Parent Loop BB0_105 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	umulh	x14, x12, x24
	lsr	x15, x14, #5
	msub	x16, x15, x25, x12
	ldr	q0, [x11]
	lsl	x14, x14, #1
	and	x14, x14, #0x1c0
	add	x15, x1, x14
	add	x14, x21, x16, lsl #2
	ldr	q1, [x14]
	ldp	s2, s3, [x15]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #192]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #384]
	ldp	s2, s3, [x15, #8]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #576]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #768]
	ldp	s2, s3, [x15, #16]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #960]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1152]
	ldp	s2, s3, [x15, #24]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1344]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1536]
	ldp	s2, s3, [x15, #32]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1728]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1920]
	ldp	s2, s3, [x15, #40]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2112]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2304]
	ldp	s2, s3, [x15, #48]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2496]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2688]
	ldp	s2, s3, [x15, #56]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2880]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	str	q0, [x11, #12288]
	add	x12, x12, #4
	add	x11, x11, #16
	subs	x13, x13, #1
	b.ne	LBB0_106
; %bb.107:                              ; %mma.fold.done3.i483
                                        ;   in Loop: Header=BB0_105 Depth=2
	add	x9, x9, #1
	add	x8, x8, #48
	add	x10, x10, #192
	cmp	x9, #8
	b.ne	LBB0_105
; %bb.108:                              ; %mma.update.i486.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	mov	x10, x17
	ldr	x1, [sp, #3064]                 ; 8-byte Reload
LBB0_109:                               ; %mma.update.i486
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_110 Depth 3
	mov	x11, x10
	mov	x12, x8
	mov	w13, #12                        ; =0xc
LBB0_110:                               ; %mma.update2.i488
                                        ;   Parent Loop BB0_17 Depth=1
                                        ;     Parent Loop BB0_109 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	umulh	x14, x12, x24
	lsr	x15, x14, #5
	msub	x16, x15, x25, x12
	ldr	q0, [x11]
	lsl	x14, x14, #1
	and	x14, x14, #0x1c0
	add	x15, x1, x14
	add	x14, x22, x16, lsl #2
	ldr	q1, [x14]
	ldp	s2, s3, [x15]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #192]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #384]
	ldp	s2, s3, [x15, #8]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #576]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #768]
	ldp	s2, s3, [x15, #16]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #960]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1152]
	ldp	s2, s3, [x15, #24]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1344]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1536]
	ldp	s2, s3, [x15, #32]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1728]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1920]
	ldp	s2, s3, [x15, #40]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2112]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2304]
	ldp	s2, s3, [x15, #48]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2496]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2688]
	ldp	s2, s3, [x15, #56]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2880]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	str	q0, [x11, #12288]
	add	x12, x12, #4
	add	x11, x11, #16
	subs	x13, x13, #1
	b.ne	LBB0_110
; %bb.111:                              ; %mma.fold.done3.i523
                                        ;   in Loop: Header=BB0_109 Depth=2
	add	x9, x9, #1
	add	x8, x8, #48
	add	x10, x10, #192
	cmp	x9, #8
	b.ne	LBB0_109
; %bb.112:                              ; %mma.update.i526.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	add	x10, x17, #1536
	ldr	x1, [sp, #3056]                 ; 8-byte Reload
LBB0_113:                               ; %mma.update.i526
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_114 Depth 3
	mov	x11, x10
	mov	x12, x8
	mov	w13, #12                        ; =0xc
LBB0_114:                               ; %mma.update2.i528
                                        ;   Parent Loop BB0_17 Depth=1
                                        ;     Parent Loop BB0_113 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	umulh	x14, x12, x24
	lsr	x15, x14, #5
	msub	x16, x15, x25, x12
	ldr	q0, [x11]
	lsl	x14, x14, #1
	and	x14, x14, #0x1c0
	add	x15, x1, x14
	add	x14, x2, x16, lsl #2
	ldr	q1, [x14]
	ldp	s2, s3, [x15]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #192]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #384]
	ldp	s2, s3, [x15, #8]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #576]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #768]
	ldp	s2, s3, [x15, #16]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #960]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1152]
	ldp	s2, s3, [x15, #24]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1344]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1536]
	ldp	s2, s3, [x15, #32]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1728]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1920]
	ldp	s2, s3, [x15, #40]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2112]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2304]
	ldp	s2, s3, [x15, #48]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2496]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2688]
	ldp	s2, s3, [x15, #56]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2880]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	str	q0, [x11, #12288]
	add	x12, x12, #4
	add	x11, x11, #16
	subs	x13, x13, #1
	b.ne	LBB0_114
; %bb.115:                              ; %mma.fold.done3.i563
                                        ;   in Loop: Header=BB0_113 Depth=2
	add	x9, x9, #1
	add	x8, x8, #48
	add	x10, x10, #192
	cmp	x9, #8
	b.ne	LBB0_113
; %bb.116:                              ; %mma.update.i566.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	add	x10, x17, #3072
	ldr	x17, [sp, #3048]                ; 8-byte Reload
LBB0_117:                               ; %mma.update.i566
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_118 Depth 3
	mov	x11, x10
	mov	x12, x8
	mov	w13, #12                        ; =0xc
LBB0_118:                               ; %mma.update2.i568
                                        ;   Parent Loop BB0_17 Depth=1
                                        ;     Parent Loop BB0_117 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	umulh	x14, x12, x24
	lsr	x15, x14, #5
	msub	x16, x15, x25, x12
	ldr	q0, [x11]
	lsl	x14, x14, #1
	and	x14, x14, #0x1c0
	add	x15, x17, x14
	add	x14, x26, x16, lsl #2
	ldr	q1, [x14]
	ldp	s2, s3, [x15]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #192]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #384]
	ldp	s2, s3, [x15, #8]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #576]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #768]
	ldp	s2, s3, [x15, #16]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #960]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1152]
	ldp	s2, s3, [x15, #24]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1344]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1536]
	ldp	s2, s3, [x15, #32]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1728]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1920]
	ldp	s2, s3, [x15, #40]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2112]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2304]
	ldp	s2, s3, [x15, #48]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2496]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2688]
	ldp	s2, s3, [x15, #56]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2880]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	str	q0, [x11, #12288]
	add	x12, x12, #4
	add	x11, x11, #16
	subs	x13, x13, #1
	b.ne	LBB0_118
; %bb.119:                              ; %mma.fold.done3.i603
                                        ;   in Loop: Header=BB0_117 Depth=2
	add	x9, x9, #1
	add	x8, x8, #48
	add	x10, x10, #192
	cmp	x9, #8
	b.ne	LBB0_117
; %bb.120:                              ; %mma.update.i606.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	ldr	x10, [sp, #4376]                ; 8-byte Reload
	ldr	x17, [sp, #3040]                ; 8-byte Reload
LBB0_121:                               ; %mma.update.i606
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_122 Depth 3
	mov	x11, x10
	mov	x12, x8
	mov	w13, #12                        ; =0xc
LBB0_122:                               ; %mma.update2.i608
                                        ;   Parent Loop BB0_17 Depth=1
                                        ;     Parent Loop BB0_121 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	umulh	x14, x12, x24
	lsr	x15, x14, #5
	msub	x16, x15, x25, x12
	ldr	q0, [x11]
	lsl	x14, x14, #1
	and	x14, x14, #0x1c0
	add	x15, x17, x14
	add	x14, x28, x16, lsl #2
	ldr	q1, [x14]
	ldp	s2, s3, [x15]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #192]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #384]
	ldp	s2, s3, [x15, #8]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #576]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #768]
	ldp	s2, s3, [x15, #16]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #960]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1152]
	ldp	s2, s3, [x15, #24]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1344]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1536]
	ldp	s2, s3, [x15, #32]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1728]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1920]
	ldp	s2, s3, [x15, #40]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2112]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2304]
	ldp	s2, s3, [x15, #48]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2496]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2688]
	ldp	s2, s3, [x15, #56]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2880]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	str	q0, [x11, #12288]
	add	x12, x12, #4
	add	x11, x11, #16
	subs	x13, x13, #1
	b.ne	LBB0_122
; %bb.123:                              ; %mma.fold.done3.i643
                                        ;   in Loop: Header=BB0_121 Depth=2
	add	x9, x9, #1
	add	x8, x8, #48
	add	x10, x10, #192
	cmp	x9, #8
	b.ne	LBB0_121
; %bb.124:                              ; %mma.update.i646.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	ldr	x10, [sp, #4376]                ; 8-byte Reload
	add	x10, x10, #1536
LBB0_125:                               ; %mma.update.i646
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_126 Depth 3
	mov	x11, x10
	mov	x12, x8
	mov	w13, #12                        ; =0xc
LBB0_126:                               ; %mma.update2.i648
                                        ;   Parent Loop BB0_17 Depth=1
                                        ;     Parent Loop BB0_125 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	umulh	x14, x12, x24
	lsr	x15, x14, #5
	msub	x16, x15, x25, x12
	ldr	q0, [x11]
	lsl	x14, x14, #1
	and	x14, x14, #0x1c0
	add	x15, x20, x14
	add	x14, x27, x16, lsl #2
	ldr	q1, [x14]
	ldp	s2, s3, [x15]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #192]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #384]
	ldp	s2, s3, [x15, #8]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #576]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #768]
	ldp	s2, s3, [x15, #16]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #960]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1152]
	ldp	s2, s3, [x15, #24]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1344]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1536]
	ldp	s2, s3, [x15, #32]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1728]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #1920]
	ldp	s2, s3, [x15, #40]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2112]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2304]
	ldp	s2, s3, [x15, #48]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2496]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2688]
	ldp	s2, s3, [x15, #56]
	fmul.4s	v1, v1, v2[0]
	fadd.4s	v0, v0, v1
	ldr	q1, [x14, #2880]
	fmul.4s	v1, v1, v3[0]
	fadd.4s	v0, v0, v1
	str	q0, [x11, #12288]
	add	x12, x12, #4
	add	x11, x11, #16
	subs	x13, x13, #1
	b.ne	LBB0_126
; %bb.127:                              ; %mma.fold.done3.i683
                                        ;   in Loop: Header=BB0_125 Depth=2
	add	x9, x9, #1
	add	x8, x8, #48
	add	x10, x10, #192
	cmp	x9, #8
	b.ne	LBB0_125
; %bb.128:                              ; %direct.true807.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	str	q31, [sp, #3760]                ; 16-byte Spill
	str	q30, [sp, #3776]                ; 16-byte Spill
	str	q29, [sp, #3792]                ; 16-byte Spill
	str	q28, [sp, #3808]                ; 16-byte Spill
	str	q27, [sp, #3824]                ; 16-byte Spill
	str	q26, [sp, #3840]                ; 16-byte Spill
	str	q25, [sp, #3856]                ; 16-byte Spill
	str	q24, [sp, #3872]                ; 16-byte Spill
	str	q23, [sp, #3888]                ; 16-byte Spill
	str	q22, [sp, #3904]                ; 16-byte Spill
	str	q21, [sp, #3920]                ; 16-byte Spill
	str	q20, [sp, #3936]                ; 16-byte Spill
	str	q19, [sp, #3952]                ; 16-byte Spill
	str	q18, [sp, #3968]                ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	add	x9, x5, #5, lsl #12             ; =20480
LBB0_129:                               ; %direct.true807
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v0, x8
	dup.2d	v1, x0
	add.2d	v0, v0, v1
	add.2d	v1, v0, v7
	add.2d	v2, v0, v6
	add.2d	v3, v0, v5
	add.2d	v0, v0, v16
	mov.d	x10, v0[1]
	fmov	x11, d0
	mov.d	x12, v3[1]
	fmov	x13, d3
	mov.d	x14, v2[1]
	fmov	x15, d2
	mov.d	x16, v1[1]
	ldr	s0, [x11]
	ld1.s	{ v0 }[1], [x10]
	fmov	x10, d1
	ld1.s	{ v0 }[2], [x13]
	ld1.s	{ v0 }[3], [x12]
	ldr	s1, [x15]
	ld1.s	{ v1 }[1], [x14]
	ld1.s	{ v1 }[2], [x10]
	ld1.s	{ v1 }[3], [x16]
	stp	q0, q1, [x9], #32
	add	x8, x8, #4
	cmp	x8, #1536
	b.ne	LBB0_129
; %bb.130:                              ; %direct.true821.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	add	x0, x5, #2, lsl #12             ; =8192
	add	x1, x5, #5, lsl #12             ; =20480
	mov	w2, #12288                      ; =0x3000
	bl	_memcpy
	ldr	q0, [sp, #4080]                 ; 16-byte Reload
	ldr	q1, [sp, #4848]                 ; 16-byte Reload
	fmul.4s	v0, v0, v1
	ldr	q1, [sp, #4064]                 ; 16-byte Reload
	ldr	q2, [sp, #4864]                 ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q2, [sp, #4384]                 ; 16-byte Reload
	ldr	q3, [sp, #4784]                 ; 16-byte Reload
	fmul.4s	v2, v2, v3
	ldr	q3, [sp, #4400]                 ; 16-byte Reload
	ldr	q4, [sp, #4800]                 ; 16-byte Reload
	fmul.4s	v3, v3, v4
	ldr	q4, [sp, #4416]                 ; 16-byte Reload
	ldr	q5, [sp, #4720]                 ; 16-byte Reload
	fmul.4s	v4, v4, v5
	ldr	q5, [sp, #4432]                 ; 16-byte Reload
	ldr	q6, [sp, #4736]                 ; 16-byte Reload
	fmul.4s	v5, v5, v6
	ldr	q6, [sp, #4448]                 ; 16-byte Reload
	ldr	q7, [sp, #4656]                 ; 16-byte Reload
	fmul.4s	v6, v6, v7
	ldr	q7, [sp, #4016]                 ; 16-byte Reload
	ldr	q16, [sp, #4672]                ; 16-byte Reload
	fmul.4s	v7, v7, v16
	ldr	q16, [sp, #4032]                ; 16-byte Reload
	ldr	q17, [sp, #4592]                ; 16-byte Reload
	fmul.4s	v16, v16, v17
	ldr	q17, [sp, #4048]                ; 16-byte Reload
	ldr	q18, [sp, #4608]                ; 16-byte Reload
	fmul.4s	v17, v17, v18
	ldr	q18, [sp, #4128]                ; 16-byte Reload
	ldr	q19, [sp, #4528]                ; 16-byte Reload
	fmul.4s	v18, v18, v19
	ldr	q19, [sp, #4160]                ; 16-byte Reload
	ldr	q20, [sp, #4544]                ; 16-byte Reload
	fmul.4s	v19, v19, v20
	ldr	q20, [sp, #4096]                ; 16-byte Reload
	ldr	q21, [sp, #4464]                ; 16-byte Reload
	fmul.4s	v20, v20, v21
	ldr	q21, [sp, #4144]                ; 16-byte Reload
	ldr	q22, [sp, #4480]                ; 16-byte Reload
	fmul.4s	v21, v21, v22
	ldr	q22, [sp, #4176]                ; 16-byte Reload
	ldr	q23, [sp, #4208]                ; 16-byte Reload
	fmul.4s	v22, v22, v23
	ldr	q23, [sp, #4112]                ; 16-byte Reload
	ldr	q24, [sp, #4224]                ; 16-byte Reload
	fmul.4s	v23, v23, v24
	ldr	q24, [sp, #3984]                ; 16-byte Reload
	fadd.4s	v12, v1, v24
	ldr	q1, [sp, #4000]                 ; 16-byte Reload
	fadd.4s	v24, v0, v1
	ldr	q0, [sp, #3952]                 ; 16-byte Reload
	fadd.4s	v0, v3, v0
	str	q0, [sp, #4400]                 ; 16-byte Spill
	ldr	q0, [sp, #3968]                 ; 16-byte Reload
	fadd.4s	v0, v2, v0
	str	q0, [sp, #4384]                 ; 16-byte Spill
	ldr	q0, [sp, #3920]                 ; 16-byte Reload
	fadd.4s	v0, v5, v0
	str	q0, [sp, #4432]                 ; 16-byte Spill
	ldr	q0, [sp, #3936]                 ; 16-byte Reload
	fadd.4s	v0, v4, v0
	str	q0, [sp, #4416]                 ; 16-byte Spill
	ldr	q0, [sp, #3888]                 ; 16-byte Reload
	fadd.4s	v15, v7, v0
	ldr	q0, [sp, #3904]                 ; 16-byte Reload
	fadd.4s	v0, v6, v0
	str	q0, [sp, #4448]                 ; 16-byte Spill
	ldr	q0, [sp, #3856]                 ; 16-byte Reload
	fadd.4s	v0, v17, v0
	ldr	q1, [sp, #3872]                 ; 16-byte Reload
	fadd.4s	v13, v16, v1
	ldr	q1, [sp, #3824]                 ; 16-byte Reload
	fadd.4s	v2, v19, v1
	ldr	q1, [sp, #3840]                 ; 16-byte Reload
	fadd.4s	v4, v18, v1
	ldr	q1, [sp, #3792]                 ; 16-byte Reload
	fadd.4s	v3, v21, v1
	ldr	q1, [sp, #3808]                 ; 16-byte Reload
	fadd.4s	v6, v20, v1
	ldr	q1, [sp, #3760]                 ; 16-byte Reload
	fadd.4s	v5, v23, v1
	ldr	q1, [sp, #3776]                 ; 16-byte Reload
	fadd.4s	v1, v22, v1
	ldr	x14, [sp, #4200]                ; 8-byte Reload
	add	x14, x14, #1
	ldr	q7, [sp, #4512]                 ; 16-byte Reload
	str	q7, [sp, #4224]                 ; 16-byte Spill
	ldr	q7, [sp, #4496]                 ; 16-byte Reload
	str	q7, [sp, #4208]                 ; 16-byte Spill
	ldr	q7, [sp, #4576]                 ; 16-byte Reload
	str	q7, [sp, #4496]                 ; 16-byte Spill
	ldr	q7, [sp, #4560]                 ; 16-byte Reload
	str	q7, [sp, #4512]                 ; 16-byte Spill
	ldr	q7, [sp, #4640]                 ; 16-byte Reload
	str	q7, [sp, #4560]                 ; 16-byte Spill
	ldr	q7, [sp, #4624]                 ; 16-byte Reload
	str	q7, [sp, #4576]                 ; 16-byte Spill
	ldr	q7, [sp, #4704]                 ; 16-byte Reload
	str	q7, [sp, #4624]                 ; 16-byte Spill
	ldr	q7, [sp, #4688]                 ; 16-byte Reload
	str	q7, [sp, #4640]                 ; 16-byte Spill
	ldr	q7, [sp, #4768]                 ; 16-byte Reload
	str	q7, [sp, #4688]                 ; 16-byte Spill
	ldr	q7, [sp, #4752]                 ; 16-byte Reload
	str	q7, [sp, #4704]                 ; 16-byte Spill
	ldr	q7, [sp, #4832]                 ; 16-byte Reload
	str	q7, [sp, #4752]                 ; 16-byte Spill
	ldr	q7, [sp, #4816]                 ; 16-byte Reload
	str	q7, [sp, #4768]                 ; 16-byte Spill
	ldr	q7, [sp, #4896]                 ; 16-byte Reload
	str	q7, [sp, #4816]                 ; 16-byte Spill
	ldr	q7, [sp, #4880]                 ; 16-byte Reload
	str	q7, [sp, #4832]                 ; 16-byte Spill
	ldr	q23, [sp, #4928]                ; 16-byte Reload
	ldr	q22, [sp, #4912]                ; 16-byte Reload
	cmp	x14, #9
	ldr	x16, [sp, #3728]                ; 8-byte Reload
	ldr	x17, [sp, #3112]                ; 8-byte Reload
	ldr	x1, [sp, #3104]                 ; 8-byte Reload
	ldr	x2, [sp, #3096]                 ; 8-byte Reload
	ldr	x3, [sp, #3088]                 ; 8-byte Reload
	ldr	x13, [sp, #3032]                ; 8-byte Reload
	ldr	x4, [sp, #3024]                 ; 8-byte Reload
	ldr	q17, [sp, #2672]                ; 16-byte Reload
	movi.4s	v26, #63, lsl #24
	movi.8b	v19, #1
	movi.4s	v20, #75, lsl #24
	ldr	q21, [sp, #4352]                ; 16-byte Reload
	ldr	q25, [sp, #4336]                ; 16-byte Reload
	ldr	q31, [sp, #4320]                ; 16-byte Reload
	ldr	q11, [sp, #4304]                ; 16-byte Reload
	ldr	q29, [sp, #4288]                ; 16-byte Reload
	ldr	q27, [sp, #4272]                ; 16-byte Reload
	ldr	q28, [sp, #4256]                ; 16-byte Reload
	ldr	q30, [sp, #4960]                ; 16-byte Reload
	ldp	x7, x5, [sp, #416]              ; 16-byte Folded Reload
	ldr	x6, [sp, #4248]                 ; 8-byte Reload
	ldr	x30, [sp, #360]                 ; 8-byte Reload
	ldr	q8, [sp, #336]                  ; 16-byte Reload
	ldr	q9, [sp, #288]                  ; 16-byte Reload
	ldr	q10, [sp, #240]                 ; 16-byte Reload
	ldr	q14, [sp, #192]                 ; 16-byte Reload
	b.ne	LBB0_17
	b	LBB0_135
LBB0_131:                               ; %direct.true854.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	b	LBB0_133
LBB0_132:                               ; %direct.schedule.83
                                        ;   in Loop: Header=BB0_133 Depth=2
	dup.2d	v1, x9
	dup.2d	v2, x6
	add.2d	v1, v1, v2
Lloh164:
	adrp	x8, lCPI0_70@PAGE
Lloh165:
	ldr	q2, [x8, lCPI0_70@PAGEOFF]
Lloh166:
	adrp	x8, lCPI0_71@PAGE
Lloh167:
	ldr	q3, [x8, lCPI0_71@PAGEOFF]
Lloh168:
	adrp	x8, lCPI0_72@PAGE
Lloh169:
	ldr	q4, [x8, lCPI0_72@PAGEOFF]
Lloh170:
	adrp	x8, lCPI0_73@PAGE
Lloh171:
	ldr	q5, [x8, lCPI0_73@PAGEOFF]
	add.2d	v3, v1, v3
	add.2d	v2, v1, v2
	mov.d	x11, v2[1]
	fmov	x12, d2
	str	s0, [x12]
	st1.s	{ v0 }[1], [x11]
	mov.d	x11, v3[1]
	add.2d	v2, v1, v4
	fmov	x12, d3
	st1.s	{ v0 }[2], [x12]
	st1.s	{ v0 }[3], [x11]
	mov.d	x11, v2[1]
	fmov	x12, d2
	str	s0, [x12]
	st1.s	{ v0 }[1], [x11]
	add.2d	v1, v1, v5
	mov.d	x11, v1[1]
	fmov	x12, d1
	st1.s	{ v0 }[2], [x12]
	st1.s	{ v0 }[3], [x11]
	add	x10, x10, #1
	add	x9, x9, #4
	cmp	x9, #3072
	b.eq	LBB0_54
LBB0_133:                               ; %direct.true854
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	movi.2d	v0, #0000000000000000
	cmp	x10, #47
	b.hi	LBB0_132
; %bb.134:                              ; %direct.true867
                                        ;   in Loop: Header=BB0_133 Depth=2
	add	x8, x4, x9
	ld1r.4s	{ v0 }, [x8]
	b	LBB0_132
LBB0_135:                               ; %direct.false217
	mov	x8, #0                          ; =0x0
	ldr	x11, [sp, #4952]                ; 8-byte Reload
	add	x9, x11, #28, lsl #12           ; =114688
	add	x9, x9, #3232
	ldr	q7, [sp, #4384]                 ; 16-byte Reload
	str	q7, [x9, #16]
	ldr	q7, [sp, #4400]                 ; 16-byte Reload
	str	q7, [x9]
	add	x9, x11, #28, lsl #12           ; =114688
	add	x9, x9, #3200
	add	x10, x11, #28, lsl #12          ; =114688
	add	x10, x10, #3264
	ldr	q7, [sp, #4416]                 ; 16-byte Reload
	str	q7, [x10, #16]
	ldr	q7, [sp, #4432]                 ; 16-byte Reload
	str	q7, [x10]
	add	x10, x11, #28, lsl #12          ; =114688
	add	x10, x10, #3296
	ldr	q7, [sp, #4448]                 ; 16-byte Reload
	stp	q15, q7, [x10]
	add	x10, x11, #28, lsl #12          ; =114688
	add	x10, x10, #3328
	stp	q0, q13, [x10]
	add	x10, x11, #28, lsl #12          ; =114688
	add	x10, x10, #3360
	stp	q2, q4, [x10]
	add	x10, x11, #28, lsl #12          ; =114688
	add	x10, x10, #3392
	stp	q3, q6, [x10]
	add	x10, x11, #28, lsl #12          ; =114688
	add	x10, x10, #3424
	stp	q5, q1, [x10]
	mov	w10, #43691                     ; =0xaaab
	mov	w11, #48                        ; =0x30
	stp	q12, q24, [x9]
	ldr	x17, [sp, #88]                  ; 8-byte Reload
	ldr	x0, [sp, #3720]                 ; 8-byte Reload
	ldp	q17, q16, [sp, #48]             ; 32-byte Folded Reload
	ldp	q19, q18, [sp, #16]             ; 32-byte Folded Reload
LBB0_136:                               ; %direct.true928
                                        ; =>This Inner Loop Header: Depth=1
	and	w12, w8, #0xffff
	mul	w12, w12, w10
	lsr	w12, w12, #21
	dup.2d	v0, x12
	add.2d	v1, v19, v0
	add.2d	v2, v18, v0
	add.2d	v3, v16, v0
	add.2d	v0, v17, v0
	mov.d	x13, v0[1]
	fmov	x14, d0
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #4
	fmov	d0, x14
	mov.d	x14, v3[1]
	fmov	x15, d3
	add	x15, x15, x15, lsl #1
	add	x13, x13, x13, lsl #1
	lsl	x15, x15, #4
	fmov	d3, x15
	add	x14, x14, x14, lsl #1
	mov.d	x15, v2[1]
	lsl	x13, x13, #4
	lsl	x14, x14, #4
	fmov	x16, d2
	add	x16, x16, x16, lsl #1
	lsl	x16, x16, #4
	mov.d	v0[1], x13
	fmov	d2, x16
	add	x13, x15, x15, lsl #1
	mov.d	x15, v1[1]
	mov.d	v3[1], x14
	lsl	x13, x13, #4
	fmov	x14, d1
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #4
	mov.d	v2[1], x13
	fmov	d1, x14
	msub	w13, w12, w11, w8
	add	x14, x15, x15, lsl #1
	lsl	x14, x14, #4
	mov.d	v1[1], x14
	and	x13, x13, #0xffff
	dup.2d	v4, x13
	add.2d	v1, v1, v4
	add.2d	v2, v2, v4
	add.2d	v3, v3, v4
	umaddl	x13, w12, w11, x13
	add	x13, x0, x13, lsl #5
	ldp	q5, q6, [x13]
	add	x12, x9, x12, lsl #5
	add.2d	v0, v0, v4
	ldp	q4, q7, [x12]
	fdiv.4s	v6, v6, v7
	fdiv.4s	v4, v5, v4
	shl.2d	v0, v0, #2
	shl.2d	v3, v3, #2
	shl.2d	v2, v2, #2
	shl.2d	v1, v1, #2
	dup.2d	v5, x17
	add.2d	v1, v5, v1
	add.2d	v0, v5, v0
	mov.d	x12, v0[1]
	fmov	x13, d0
	str	s4, [x13]
	st1.s	{ v4 }[1], [x12]
	add.2d	v0, v5, v3
	mov.d	x12, v0[1]
	fmov	x13, d0
	st1.s	{ v4 }[2], [x13]
	add.2d	v0, v5, v2
	mov.d	x13, v0[1]
	fmov	x14, d0
	st1.s	{ v4 }[3], [x12]
	str	s6, [x14]
	mov.d	x12, v1[1]
	fmov	x14, d1
	st1.s	{ v6 }[1], [x13]
	st1.s	{ v6 }[2], [x14]
	st1.s	{ v6 }[3], [x12]
	add	x8, x8, #1
	cmp	x8, #384
	b.ne	LBB0_136
; %bb.137:                              ; %direct.false929
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #880
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh154, Lloh155
	.loh AdrpLdr	Lloh152, Lloh153
	.loh AdrpLdr	Lloh150, Lloh151
	.loh AdrpLdr	Lloh148, Lloh149
	.loh AdrpLdr	Lloh146, Lloh147
	.loh AdrpLdr	Lloh144, Lloh145
	.loh AdrpLdr	Lloh142, Lloh143
	.loh AdrpLdr	Lloh140, Lloh141
	.loh AdrpLdr	Lloh138, Lloh139
	.loh AdrpLdr	Lloh136, Lloh137
	.loh AdrpLdr	Lloh134, Lloh135
	.loh AdrpLdr	Lloh130, Lloh131
	.loh AdrpLdr	Lloh129, Lloh133
	.loh AdrpLdr	Lloh125, Lloh126
	.loh AdrpAdrp	Lloh124, Lloh130
	.loh AdrpLdr	Lloh124, Lloh128
	.loh AdrpAdrp	Lloh123, Lloh129
	.loh AdrpLdr	Lloh123, Lloh127
	.loh AdrpAdrp	Lloh119, Lloh125
	.loh AdrpLdr	Lloh119, Lloh120
	.loh AdrpAdrp	Lloh118, Lloh124
	.loh AdrpLdr	Lloh118, Lloh122
	.loh AdrpAdrp	Lloh117, Lloh123
	.loh AdrpLdr	Lloh117, Lloh121
	.loh AdrpLdr	Lloh116, Lloh132
	.loh AdrpLdr	Lloh114, Lloh115
	.loh AdrpAdrp	Lloh110, Lloh118
	.loh AdrpLdr	Lloh110, Lloh113
	.loh AdrpAdrp	Lloh109, Lloh117
	.loh AdrpLdr	Lloh109, Lloh112
	.loh AdrpAdrp	Lloh108, Lloh114
	.loh AdrpLdr	Lloh108, Lloh111
	.loh AdrpLdr	Lloh106, Lloh107
	.loh AdrpLdr	Lloh104, Lloh105
	.loh AdrpLdr	Lloh102, Lloh103
	.loh AdrpLdr	Lloh100, Lloh101
	.loh AdrpLdr	Lloh98, Lloh99
	.loh AdrpLdr	Lloh96, Lloh97
	.loh AdrpLdr	Lloh94, Lloh95
	.loh AdrpLdr	Lloh92, Lloh93
	.loh AdrpLdr	Lloh90, Lloh91
	.loh AdrpLdr	Lloh88, Lloh89
	.loh AdrpLdr	Lloh86, Lloh87
	.loh AdrpLdr	Lloh84, Lloh85
	.loh AdrpLdr	Lloh82, Lloh83
	.loh AdrpLdr	Lloh80, Lloh81
	.loh AdrpLdr	Lloh78, Lloh79
	.loh AdrpLdr	Lloh76, Lloh77
	.loh AdrpLdr	Lloh74, Lloh75
	.loh AdrpLdr	Lloh72, Lloh73
	.loh AdrpLdr	Lloh70, Lloh71
	.loh AdrpLdr	Lloh68, Lloh69
	.loh AdrpLdr	Lloh66, Lloh67
	.loh AdrpLdr	Lloh64, Lloh65
	.loh AdrpLdr	Lloh62, Lloh63
	.loh AdrpLdr	Lloh60, Lloh61
	.loh AdrpLdr	Lloh58, Lloh59
	.loh AdrpLdr	Lloh56, Lloh57
	.loh AdrpLdr	Lloh54, Lloh55
	.loh AdrpLdr	Lloh52, Lloh53
	.loh AdrpLdr	Lloh50, Lloh51
	.loh AdrpLdr	Lloh48, Lloh49
	.loh AdrpLdr	Lloh46, Lloh47
	.loh AdrpLdr	Lloh44, Lloh45
	.loh AdrpLdr	Lloh42, Lloh43
	.loh AdrpLdr	Lloh40, Lloh41
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpLdr	Lloh32, Lloh33
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh109
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh162, Lloh163
	.loh AdrpAdrp	Lloh160, Lloh162
	.loh AdrpLdr	Lloh160, Lloh161
	.loh AdrpAdrp	Lloh158, Lloh160
	.loh AdrpLdr	Lloh158, Lloh159
	.loh AdrpAdrp	Lloh156, Lloh158
	.loh AdrpLdr	Lloh156, Lloh157
	.loh AdrpLdr	Lloh170, Lloh171
	.loh AdrpAdrp	Lloh168, Lloh170
	.loh AdrpLdr	Lloh168, Lloh169
	.loh AdrpAdrp	Lloh166, Lloh168
	.loh AdrpLdr	Lloh166, Lloh167
	.loh AdrpAdrp	Lloh164, Lloh166
	.loh AdrpLdr	Lloh164, Lloh165
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention.packet_batch.blocks
lCPI1_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI1_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI1_2:
	.quad	2048                            ; 0x800
	.quad	3072                            ; 0xc00
lCPI1_3:
	.quad	6144                            ; 0x1800
	.quad	7168                            ; 0x1c00
lCPI1_4:
	.quad	0                               ; 0x0
	.quad	1024                            ; 0x400
lCPI1_5:
	.quad	4096                            ; 0x1000
	.quad	5120                            ; 0x1400
lCPI1_6:
	.quad	96                              ; 0x60
	.quad	112                             ; 0x70
lCPI1_7:
	.quad	64                              ; 0x40
	.quad	80                              ; 0x50
lCPI1_8:
	.quad	32                              ; 0x20
	.quad	48                              ; 0x30
lCPI1_9:
	.quad	0                               ; 0x0
	.quad	16                              ; 0x10
lCPI1_10:
	.quad	97                              ; 0x61
	.quad	113                             ; 0x71
lCPI1_11:
	.quad	65                              ; 0x41
	.quad	81                              ; 0x51
lCPI1_12:
	.quad	33                              ; 0x21
	.quad	49                              ; 0x31
lCPI1_13:
	.quad	1                               ; 0x1
	.quad	17                              ; 0x11
lCPI1_14:
	.quad	98                              ; 0x62
	.quad	114                             ; 0x72
lCPI1_15:
	.quad	66                              ; 0x42
	.quad	82                              ; 0x52
lCPI1_16:
	.quad	34                              ; 0x22
	.quad	50                              ; 0x32
lCPI1_17:
	.quad	2                               ; 0x2
	.quad	18                              ; 0x12
lCPI1_18:
	.quad	99                              ; 0x63
	.quad	115                             ; 0x73
lCPI1_19:
	.quad	67                              ; 0x43
	.quad	83                              ; 0x53
lCPI1_20:
	.quad	35                              ; 0x23
	.quad	51                              ; 0x33
lCPI1_21:
	.quad	3                               ; 0x3
	.quad	19                              ; 0x13
lCPI1_22:
	.quad	100                             ; 0x64
	.quad	116                             ; 0x74
lCPI1_23:
	.quad	68                              ; 0x44
	.quad	84                              ; 0x54
lCPI1_24:
	.quad	36                              ; 0x24
	.quad	52                              ; 0x34
lCPI1_25:
	.quad	4                               ; 0x4
	.quad	20                              ; 0x14
lCPI1_26:
	.quad	101                             ; 0x65
	.quad	117                             ; 0x75
lCPI1_27:
	.quad	69                              ; 0x45
	.quad	85                              ; 0x55
lCPI1_28:
	.quad	37                              ; 0x25
	.quad	53                              ; 0x35
lCPI1_29:
	.quad	5                               ; 0x5
	.quad	21                              ; 0x15
lCPI1_30:
	.quad	102                             ; 0x66
	.quad	118                             ; 0x76
lCPI1_31:
	.quad	70                              ; 0x46
	.quad	86                              ; 0x56
lCPI1_32:
	.quad	38                              ; 0x26
	.quad	54                              ; 0x36
lCPI1_33:
	.quad	6                               ; 0x6
	.quad	22                              ; 0x16
lCPI1_34:
	.quad	103                             ; 0x67
	.quad	119                             ; 0x77
lCPI1_35:
	.quad	71                              ; 0x47
	.quad	87                              ; 0x57
lCPI1_36:
	.quad	39                              ; 0x27
	.quad	55                              ; 0x37
lCPI1_37:
	.quad	7                               ; 0x7
	.quad	23                              ; 0x17
lCPI1_38:
	.quad	104                             ; 0x68
	.quad	120                             ; 0x78
lCPI1_39:
	.quad	72                              ; 0x48
	.quad	88                              ; 0x58
lCPI1_40:
	.quad	40                              ; 0x28
	.quad	56                              ; 0x38
lCPI1_41:
	.quad	8                               ; 0x8
	.quad	24                              ; 0x18
lCPI1_42:
	.quad	105                             ; 0x69
	.quad	121                             ; 0x79
lCPI1_43:
	.quad	73                              ; 0x49
	.quad	89                              ; 0x59
lCPI1_44:
	.quad	41                              ; 0x29
	.quad	57                              ; 0x39
lCPI1_45:
	.quad	9                               ; 0x9
	.quad	25                              ; 0x19
lCPI1_46:
	.quad	106                             ; 0x6a
	.quad	122                             ; 0x7a
lCPI1_47:
	.quad	74                              ; 0x4a
	.quad	90                              ; 0x5a
lCPI1_48:
	.quad	42                              ; 0x2a
	.quad	58                              ; 0x3a
lCPI1_49:
	.quad	10                              ; 0xa
	.quad	26                              ; 0x1a
lCPI1_50:
	.quad	107                             ; 0x6b
	.quad	123                             ; 0x7b
lCPI1_51:
	.quad	75                              ; 0x4b
	.quad	91                              ; 0x5b
lCPI1_52:
	.quad	43                              ; 0x2b
	.quad	59                              ; 0x3b
lCPI1_53:
	.quad	11                              ; 0xb
	.quad	27                              ; 0x1b
lCPI1_54:
	.quad	108                             ; 0x6c
	.quad	124                             ; 0x7c
lCPI1_55:
	.quad	76                              ; 0x4c
	.quad	92                              ; 0x5c
lCPI1_56:
	.quad	44                              ; 0x2c
	.quad	60                              ; 0x3c
lCPI1_57:
	.quad	12                              ; 0xc
	.quad	28                              ; 0x1c
lCPI1_58:
	.quad	109                             ; 0x6d
	.quad	125                             ; 0x7d
lCPI1_59:
	.quad	77                              ; 0x4d
	.quad	93                              ; 0x5d
lCPI1_60:
	.quad	45                              ; 0x2d
	.quad	61                              ; 0x3d
lCPI1_61:
	.quad	13                              ; 0xd
	.quad	29                              ; 0x1d
lCPI1_62:
	.quad	110                             ; 0x6e
	.quad	126                             ; 0x7e
lCPI1_63:
	.quad	78                              ; 0x4e
	.quad	94                              ; 0x5e
lCPI1_64:
	.quad	46                              ; 0x2e
	.quad	62                              ; 0x3e
lCPI1_65:
	.quad	14                              ; 0xe
	.quad	30                              ; 0x1e
lCPI1_66:
	.quad	111                             ; 0x6f
	.quad	127                             ; 0x7f
lCPI1_67:
	.quad	79                              ; 0x4f
	.quad	95                              ; 0x5f
lCPI1_68:
	.quad	47                              ; 0x2f
	.quad	63                              ; 0x3f
lCPI1_69:
	.quad	15                              ; 0xf
	.quad	31                              ; 0x1f
lCPI1_70:
	.quad	12288                           ; 0x3000
	.quad	14336                           ; 0x3800
lCPI1_71:
	.quad	4096                            ; 0x1000
	.quad	6144                            ; 0x1800
lCPI1_72:
	.quad	8192                            ; 0x2000
	.quad	10240                           ; 0x2800
lCPI1_73:
	.quad	0                               ; 0x0
	.quad	2048                            ; 0x800
lCPI1_74:
	.quad	18432                           ; 0x4800
	.quad	21504                           ; 0x5400
lCPI1_75:
	.quad	6144                            ; 0x1800
	.quad	9216                            ; 0x2400
lCPI1_76:
	.quad	12288                           ; 0x3000
	.quad	15360                           ; 0x3c00
lCPI1_77:
	.quad	0                               ; 0x0
	.quad	3072                            ; 0xc00
lCPI1_78:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI1_79:
	.quad	3072                            ; 0xc00
	.quad	3584                            ; 0xe00
lCPI1_80:
	.quad	1024                            ; 0x400
	.quad	1536                            ; 0x600
lCPI1_81:
	.quad	2048                            ; 0x800
	.quad	2560                            ; 0xa00
lCPI1_82:
	.quad	0                               ; 0x0
	.quad	512                             ; 0x200
lCPI1_83:
	.quad	768                             ; 0x300
	.quad	896                             ; 0x380
lCPI1_84:
	.quad	256                             ; 0x100
	.quad	384                             ; 0x180
lCPI1_85:
	.quad	512                             ; 0x200
	.quad	640                             ; 0x280
lCPI1_86:
	.quad	0                               ; 0x0
	.quad	128                             ; 0x80
lCPI1_87:
	.quad	9216                            ; 0x2400
	.quad	10752                           ; 0x2a00
lCPI1_88:
	.quad	3072                            ; 0xc00
	.quad	4608                            ; 0x1200
lCPI1_89:
	.quad	6144                            ; 0x1800
	.quad	7680                            ; 0x1e00
lCPI1_90:
	.quad	0                               ; 0x0
	.quad	1536                            ; 0x600
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_attention.packet_batch.blocks
	.p2align	2
_llm_attention.packet_batch.blocks:     ; @llm_attention.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #1632
	str	x0, [sp, #224]                  ; 8-byte Spill
	cbz	w3, LBB1_787
; %bb.1:                                ; %block.batch.loop.preheader
	mov	x20, x3
	mov	x1, x2
	mov	w11, #0                         ; =0x0
	ldp	w9, w8, [x2, #44]
	stp	w8, w9, [sp, #216]              ; 8-byte Folded Spill
	ldp	w13, w14, [x2, #4]
Lloh172:
	adrp	x8, lCPI1_0@PAGE
Lloh173:
	ldr	q25, [x8, lCPI1_0@PAGEOFF]
Lloh174:
	adrp	x8, lCPI1_1@PAGE
Lloh175:
	ldr	q26, [x8, lCPI1_1@PAGEOFF]
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	str	q0, [sp, #5296]                 ; 16-byte Spill
	ldr	w15, [x2]
	adrp	x25, lCPI1_78@PAGE
	mov	w23, #43691                     ; =0xaaab
	mov	w28, #48                        ; =0x30
	mov	x19, #-6148914691236517206      ; =0xaaaaaaaaaaaaaaaa
	movk	x19, #43691
	str	x2, [sp, #312]                  ; 8-byte Spill
	str	w3, [sp, #212]                  ; 4-byte Spill
	stp	q26, q25, [sp, #176]            ; 32-byte Folded Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x1, #36]
	ldr	w20, [sp, #212]                 ; 4-byte Reload
	ldr	w11, [sp, #232]                 ; 4-byte Reload
LBB1_3:                                 ; %llm_attention.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w15, #1
	ldp	w10, w9, [sp, #216]             ; 8-byte Folded Reload
	cmp	w8, w9
	cset	w8, eq
	csinc	w15, wzr, w15, eq
	cinc	w9, w16, eq
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w13, wzr, w9, ne
	add	w14, w14, w8
	add	w11, w11, #1
	cmp	w11, w20
	b.eq	LBB1_787
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_15 Depth 2
                                        ;     Child Loop BB1_18 Depth 2
                                        ;     Child Loop BB1_21 Depth 2
                                        ;     Child Loop BB1_24 Depth 2
                                        ;     Child Loop BB1_27 Depth 2
                                        ;     Child Loop BB1_30 Depth 2
                                        ;     Child Loop BB1_33 Depth 2
                                        ;     Child Loop BB1_36 Depth 2
                                        ;     Child Loop BB1_38 Depth 2
                                        ;     Child Loop BB1_40 Depth 2
                                        ;       Child Loop BB1_63 Depth 3
                                        ;       Child Loop BB1_66 Depth 3
                                        ;       Child Loop BB1_69 Depth 3
                                        ;       Child Loop BB1_72 Depth 3
                                        ;       Child Loop BB1_75 Depth 3
                                        ;       Child Loop BB1_78 Depth 3
                                        ;       Child Loop BB1_81 Depth 3
                                        ;       Child Loop BB1_84 Depth 3
                                        ;       Child Loop BB1_87 Depth 3
                                        ;       Child Loop BB1_90 Depth 3
                                        ;       Child Loop BB1_93 Depth 3
                                        ;       Child Loop BB1_96 Depth 3
                                        ;       Child Loop BB1_99 Depth 3
                                        ;       Child Loop BB1_102 Depth 3
                                        ;       Child Loop BB1_105 Depth 3
                                        ;       Child Loop BB1_108 Depth 3
                                        ;       Child Loop BB1_43 Depth 3
                                        ;       Child Loop BB1_111 Depth 3
                                        ;       Child Loop BB1_132 Depth 3
                                        ;       Child Loop BB1_150 Depth 3
                                        ;       Child Loop BB1_153 Depth 3
                                        ;       Child Loop BB1_156 Depth 3
                                        ;       Child Loop BB1_159 Depth 3
                                        ;       Child Loop BB1_162 Depth 3
                                        ;       Child Loop BB1_165 Depth 3
                                        ;       Child Loop BB1_168 Depth 3
                                        ;       Child Loop BB1_171 Depth 3
                                        ;       Child Loop BB1_308 Depth 3
                                        ;       Child Loop BB1_342 Depth 3
                                        ;       Child Loop BB1_375 Depth 3
                                        ;       Child Loop BB1_377 Depth 3
                                        ;       Child Loop BB1_379 Depth 3
                                        ;       Child Loop BB1_381 Depth 3
                                        ;       Child Loop BB1_383 Depth 3
                                        ;       Child Loop BB1_385 Depth 3
                                        ;       Child Loop BB1_387 Depth 3
                                        ;       Child Loop BB1_389 Depth 3
                                        ;       Child Loop BB1_392 Depth 3
                                        ;       Child Loop BB1_426 Depth 3
                                        ;       Child Loop BB1_444 Depth 3
                                        ;       Child Loop BB1_462 Depth 3
                                        ;       Child Loop BB1_480 Depth 3
                                        ;       Child Loop BB1_498 Depth 3
                                        ;       Child Loop BB1_516 Depth 3
                                        ;       Child Loop BB1_534 Depth 3
                                        ;       Child Loop BB1_552 Depth 3
                                        ;       Child Loop BB1_570 Depth 3
                                        ;       Child Loop BB1_588 Depth 3
                                        ;         Child Loop BB1_589 Depth 4
                                        ;       Child Loop BB1_593 Depth 3
                                        ;         Child Loop BB1_594 Depth 4
                                        ;       Child Loop BB1_598 Depth 3
                                        ;         Child Loop BB1_599 Depth 4
                                        ;       Child Loop BB1_603 Depth 3
                                        ;         Child Loop BB1_604 Depth 4
                                        ;       Child Loop BB1_608 Depth 3
                                        ;         Child Loop BB1_609 Depth 4
                                        ;       Child Loop BB1_613 Depth 3
                                        ;         Child Loop BB1_614 Depth 4
                                        ;       Child Loop BB1_618 Depth 3
                                        ;         Child Loop BB1_619 Depth 4
                                        ;       Child Loop BB1_623 Depth 3
                                        ;         Child Loop BB1_624 Depth 4
                                        ;       Child Loop BB1_628 Depth 3
                                        ;       Child Loop BB1_645 Depth 3
                                        ;     Child Loop BB1_771 Depth 2
	stp	w11, w13, [sp, #232]            ; 8-byte Folded Spill
	ldr	w8, [x1, #12]
	ubfiz	x9, x15, #5, #32
	cmp	x9, x8
	csel	x10, x9, xzr, ls
	subs	x11, x8, x10
	cmp	x11, #32
	mov	w12, #32                        ; =0x20
	csel	x11, x11, x12, lo
	cmp	x8, x10
	str	x15, [sp, #240]                 ; 8-byte Spill
	stp	w15, w13, [x1]
	str	w14, [sp, #252]                 ; 4-byte Spill
	str	w14, [x1, #8]
	str	wzr, [x1, #36]
	ccmp	x9, x8, #2, hi
	csel	x21, x11, xzr, ls
	cmp	x21, #32
	b.lo	LBB1_6
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x21, [sp, #224]                 ; 8-byte Reload
	mov	x0, x21
	bl	_llm_attention.full_packet
	ldr	x8, [sp, #312]                  ; 8-byte Reload
	mov	w9, #8                          ; =0x8
	str	w9, [x8, #36]
	mov	x0, x21
	ldr	x1, [sp, #312]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x8, [sp, #312]                  ; 8-byte Reload
	mov	w9, #16                         ; =0x10
	str	w9, [x8, #36]
	mov	x0, x21
	ldr	x1, [sp, #312]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x8, [sp, #312]                  ; 8-byte Reload
	mov	w9, #24                         ; =0x18
	str	w9, [x8, #36]
	mov	x0, x21
	ldr	x1, [sp, #312]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x1, [sp, #312]                  ; 8-byte Reload
	ldp	w11, w16, [sp, #232]            ; 8-byte Folded Reload
	ldr	w14, [sp, #252]                 ; 4-byte Reload
	ldr	x15, [sp, #240]                 ; 8-byte Reload
	b	LBB1_3
LBB1_6:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x20, x21, #3
	cbz	x20, LBB1_11
; %bb.7:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x1, #36]
	ldr	x0, [sp, #224]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x1, [sp, #312]                  ; 8-byte Reload
	cmp	x20, #1
	b.eq	LBB1_11
; %bb.8:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x1, #36]
	ldr	x0, [sp, #224]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x1, [sp, #312]                  ; 8-byte Reload
	cmp	x20, #2
	b.eq	LBB1_11
; %bb.9:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x1, #36]
	ldr	x0, [sp, #224]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x1, [sp, #312]                  ; 8-byte Reload
	cmp	x20, #3
	b.eq	LBB1_11
; %bb.10:                               ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x1, #36]
	ldr	x22, [sp, #224]                 ; 8-byte Reload
	mov	x0, x22
	bl	_llm_attention.full_packet
	ldr	x8, [sp, #312]                  ; 8-byte Reload
	mov	w9, #32                         ; =0x20
	str	w9, [x8, #36]
	mov	x0, x22
	ldr	x1, [sp, #312]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x8, [sp, #312]                  ; 8-byte Reload
	mov	w9, #40                         ; =0x28
	str	w9, [x8, #36]
	mov	x0, x22
	ldr	x1, [sp, #312]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x8, [sp, #312]                  ; 8-byte Reload
	str	w28, [x8, #36]
	mov	x0, x22
	ldr	x1, [sp, #312]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x1, [sp, #312]                  ; 8-byte Reload
LBB1_11:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w8, w21, #0x7
	ldr	w14, [sp, #252]                 ; 4-byte Reload
	ldp	q26, q25, [sp, #176]            ; 32-byte Folded Reload
	ldr	x15, [sp, #240]                 ; 8-byte Reload
	ldr	w16, [sp, #236]                 ; 4-byte Reload
	cbz	w8, LBB1_2
; %bb.12:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w9, w20, #3
	dup.4s	v22, w8
	str	w9, [x1, #36]
	cmhi.4s	v0, v22, v26
	cmhi.4s	v1, v22, v25
	uzp1.8h	v1, v1, v0
	umaxv.8h	h1, v1
	fmov	w8, s1
	tbz	w8, #0, LBB1_2
; %bb.13:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x30, [x1, #136]
	ldr	x8, [sp, #224]                  ; 8-byte Reload
	ldr	x8, [x8]
	cmhi.4s	v1, v22, v25
	xtn.4h	v2, v1
	uzp1.8b	v16, v2, v0
	sshll.2d	v5, v1, #0
	orr	w9, w9, w15, lsl #5
	dup.4s	v4, w9
	orr.16b	v2, v4, v25
	and.16b	v6, v1, v2
	ushll.2d	v3, v6, #0
	mov	w9, #3                          ; =0x3
	dup.2d	v2, x9
	and.16b	v7, v5, v2
	neg.2d	v7, v7
	ushl.2d	v19, v3, v7
	ushll.2d	v7, v6, #3
	mov	w9, #56                         ; =0x38
	dup.2d	v3, x9
	and.16b	v27, v7, v3
	shl.2d	v7, v19, #11
	shl.2d	v17, v27, #5
	and.16b	v17, v5, v17
	orr.16b	v7, v17, v7
	umov.b	w15, v16[0]
	tbz	w15, #0, LBB1_16
; %bb.14:                               ; %copy.active.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x9, #0                          ; =0x0
	fmov	x10, d7
	add	x10, x8, x10, lsl #2
LBB1_15:                                ; %copy.chunk.i.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q16, [x10, x9]
	str	q16, [x30, x9]
	add	x9, x9, #16
	cmp	x9, #1024
	b.ne	LBB1_15
LBB1_16:                                ; %copy.continue.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.s	w10, v22[1]
	cmp	w10, #1
	cset	w16, hi
	cmp	w10, #2
	b.lo	LBB1_19
; %bb.17:                               ; %copy.active197.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x9, #0                          ; =0x0
	add	x11, x30, #1024
	mov.d	x12, v7[1]
	add	x12, x8, x12, lsl #2
LBB1_18:                                ; %copy.chunk.i497.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q7, [x12, x9]
	str	q7, [x11, x9]
	add	x9, x9, #16
	cmp	x9, #1024
	b.ne	LBB1_18
LBB1_19:                                ; %copy.continue198.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	sshll2.2d	v28, v1, #0
	ushll2.2d	v7, v6, #0
	and.16b	v16, v28, v2
	neg.2d	v16, v16
	ushl.2d	v16, v7, v16
	ushll2.2d	v6, v6, #3
	and.16b	v29, v6, v3
	shl.2d	v6, v16, #11
	shl.2d	v7, v29, #5
	and.16b	v7, v28, v7
	orr.16b	v6, v7, v6
	mov.s	w11, v22[2]
	cmp	w11, #2
	cset	w17, hi
	cmp	w11, #3
	b.lo	LBB1_22
; %bb.20:                               ; %copy.active199.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x9, #0                          ; =0x0
	add	x12, x30, #2048
	fmov	x13, d6
	add	x13, x8, x13, lsl #2
LBB1_21:                                ; %copy.chunk.i501.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q7, [x13, x9]
	str	q7, [x12, x9]
	add	x9, x9, #16
	cmp	x9, #1024
	b.ne	LBB1_21
LBB1_22:                                ; %copy.continue200.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.s	w9, v22[3]
	cmp	w9, #3
	cset	w0, hi
	cmp	w9, #4
	b.lo	LBB1_25
; %bb.23:                               ; %copy.active201.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x12, #0                         ; =0x0
	add	x13, x30, #3072
	mov.d	x14, v6[1]
	add	x14, x8, x14, lsl #2
LBB1_24:                                ; %copy.chunk.i505.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q6, [x14, x12]
	str	q6, [x13, x12]
	add	x12, x12, #16
	cmp	x12, #1024
	b.ne	LBB1_24
LBB1_25:                                ; %copy.continue202.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	sshll.2d	v23, v0, #0
	orr.16b	v4, v4, v26
	and.16b	v4, v0, v4
	ushll.2d	v6, v4, #0
	and.16b	v7, v23, v2
	neg.2d	v7, v7
	ushl.2d	v17, v6, v7
	ushll.2d	v6, v4, #3
	and.16b	v30, v6, v3
	shl.2d	v6, v17, #11
	shl.2d	v7, v30, #5
	and.16b	v7, v23, v7
	orr.16b	v6, v7, v6
	fmov	w12, s22
	cmp	w12, #4
	cset	w1, hi
	cmp	w12, #5
	b.lo	LBB1_28
; %bb.26:                               ; %copy.active203.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x12, #0                         ; =0x0
	add	x13, x30, #1, lsl #12           ; =4096
	fmov	x14, d6
	add	x14, x8, x14, lsl #2
LBB1_27:                                ; %copy.chunk.i509.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q7, [x14, x12]
	str	q7, [x13, x12]
	add	x12, x12, #16
	cmp	x12, #1024
	b.ne	LBB1_27
LBB1_28:                                ; %copy.continue204.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	cmp	w10, #5
	cset	w14, hi
	cmp	w10, #6
	b.lo	LBB1_31
; %bb.29:                               ; %copy.active205.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x10, #0                         ; =0x0
	mov	w12, #5120                      ; =0x1400
	add	x12, x30, x12
	mov.d	x13, v6[1]
	add	x13, x8, x13, lsl #2
LBB1_30:                                ; %copy.chunk.i513.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q6, [x13, x10]
	str	q6, [x12, x10]
	add	x10, x10, #16
	cmp	x10, #1024
	b.ne	LBB1_30
LBB1_31:                                ; %copy.continue206.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	sshll2.2d	v10, v0, #0
	ushll2.2d	v6, v4, #0
	and.16b	v2, v10, v2
	neg.2d	v2, v2
	ushl.2d	v6, v6, v2
	ushll2.2d	v2, v4, #3
	and.16b	v31, v2, v3
	shl.2d	v2, v6, #11
	shl.2d	v3, v31, #5
	and.16b	v3, v10, v3
	orr.16b	v2, v3, v2
	cmp	w11, #6
	cset	w13, hi
	cmp	w11, #7
	b.lo	LBB1_34
; %bb.32:                               ; %copy.active207.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x10, #0                         ; =0x0
	mov	w11, #6144                      ; =0x1800
	add	x11, x30, x11
	fmov	x12, d2
	add	x12, x8, x12, lsl #2
LBB1_33:                                ; %copy.chunk.i517.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x12, x10]
	str	q3, [x11, x10]
	add	x10, x10, #16
	cmp	x10, #1024
	b.ne	LBB1_33
LBB1_34:                                ; %copy.continue208.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x10, [sp, #224]                 ; 8-byte Reload
	ldr	x11, [x10, #16]
	str	x11, [sp, #2600]                ; 8-byte Spill
	ldr	x11, [x10, #32]
	str	x11, [sp, #2568]                ; 8-byte Spill
	ldr	x10, [x10, #48]
	str	x10, [sp, #136]                 ; 8-byte Spill
	cmp	w9, #7
	cset	w10, hi
	str	w10, [sp, #4284]                ; 4-byte Spill
	cmp	w9, #8
	b.lo	LBB1_37
; %bb.35:                               ; %copy.active209.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x9, #0                          ; =0x0
	mov	w10, #7168                      ; =0x1c00
	add	x10, x30, x10
	mov.d	x11, v2[1]
	add	x8, x8, x11, lsl #2
LBB1_36:                                ; %copy.chunk.i521.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x8, x9]
	str	q2, [x10, x9]
	add	x9, x9, #16
	cmp	x9, #1024
	b.ne	LBB1_36
LBB1_37:                                ; %direct.true.i.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	w13, [sp, #2612]                ; 4-byte Spill
	str	w14, [sp, #2616]                ; 4-byte Spill
	str	w1, [sp, #2620]                 ; 4-byte Spill
	str	w0, [sp, #2624]                 ; 4-byte Spill
	str	w17, [sp, #2628]                ; 4-byte Spill
	str	w16, [sp, #2632]                ; 4-byte Spill
	str	w15, [sp, #2636]                ; 4-byte Spill
	mov	x9, #0                          ; =0x0
	add	x8, x30, #19, lsl #12           ; =77824
	add	x10, x30, #8, lsl #12           ; =32768
	dup.2d	v2, x10
	str	q2, [sp, #2544]                 ; 16-byte Spill
	add	x10, x30, #12, lsl #12          ; =49152
	dup.2d	v2, x10
	str	q2, [sp, #3328]                 ; 16-byte Spill
	add	x10, x30, #18, lsl #12          ; =73728
	dup.2d	v2, x10
	str	q2, [sp, #2528]                 ; 16-byte Spill
	add	x11, x30, #2, lsl #12           ; =8192
	dup.2d	v2, x8
	str	q2, [sp, #2512]                 ; 16-byte Spill
	add	x10, x30, #20, lsl #12          ; =81920
	dup.2d	v2, x10
	str	q2, [sp, #2576]                 ; 16-byte Spill
	mov	w10, #16512                     ; =0x4080
	movk	w10, #1, lsl #16
	add	x10, x30, x10
	str	x10, [sp, #2504]                ; 8-byte Spill
	mov	w10, #17536                     ; =0x4480
	movk	w10, #1, lsl #16
	add	x10, x30, x10
	str	x10, [sp, #2496]                ; 8-byte Spill
	mov	w10, #18048                     ; =0x4680
	movk	w10, #1, lsl #16
	add	x10, x30, x10
	dup.2d	v2, x10
	str	q2, [sp, #2480]                 ; 16-byte Spill
	mov	w10, #19072                     ; =0x4a80
	movk	w10, #1, lsl #16
	add	x6, x30, x10
	mov	w10, #23168                     ; =0x5a80
	movk	w10, #1, lsl #16
	add	x10, x30, x10
	str	x10, [sp, #2472]                ; 8-byte Spill
	mov	w10, #23424                     ; =0x5b80
	movk	w10, #1, lsl #16
	add	x10, x30, x10
	str	x10, [sp, #2464]                ; 8-byte Spill
	mov	w10, #23680                     ; =0x5c80
	movk	w10, #1, lsl #16
	add	x10, x30, x10
	dup.2d	v2, x10
	str	q2, [sp, #2448]                 ; 16-byte Spill
	mov	w10, #27776                     ; =0x6c80
	movk	w10, #1, lsl #16
	add	x10, x30, x10
	dup.2d	v2, x10
	str	q2, [sp, #2432]                 ; 16-byte Spill
	mov	w10, #40064                     ; =0x9c80
	movk	w10, #1, lsl #16
	add	x10, x30, x10
	dup.2d	v2, x10
	str	q2, [sp, #2416]                 ; 16-byte Spill
	mov	w10, #52352                     ; =0xcc80
	movk	w10, #1, lsl #16
	add	x10, x30, x10
	str	x10, [sp, #88]                  ; 8-byte Spill
	dup.2d	v3, x30
	stp	q6, q17, [sp, #32]              ; 32-byte Folded Spill
	ushr.2d	v18, v6, #1
	str	q16, [sp, #96]                  ; 16-byte Spill
	ushr.2d	v16, v16, #1
	ushr.2d	v20, v17, #1
	str	q19, [sp, #160]                 ; 16-byte Spill
	ushr.2d	v21, v19, #1
	and.16b	v6, v28, v3
	and.16b	v2, v10, v3
	and.16b	v17, v5, v3
	and.16b	v4, v23, v3
Lloh176:
	adrp	x10, lCPI1_2@PAGE
Lloh177:
	ldr	q3, [x10, lCPI1_2@PAGEOFF]
	and.16b	v7, v28, v3
Lloh178:
	adrp	x10, lCPI1_3@PAGE
Lloh179:
	ldr	q3, [x10, lCPI1_3@PAGEOFF]
	and.16b	v11, v10, v3
Lloh180:
	adrp	x10, lCPI1_4@PAGE
Lloh181:
	ldr	q19, [x10, lCPI1_4@PAGEOFF]
	and.16b	v19, v5, v19
Lloh182:
	adrp	x10, lCPI1_5@PAGE
Lloh183:
	ldr	q5, [x10, lCPI1_5@PAGEOFF]
	and.16b	v5, v23, v5
LBB1_38:                                ; %direct.true.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x11, x9
	ldp	q23, q24, [x10]
	cmhs.4s	v15, v26, v22
	and.16b	v24, v15, v24
	cmhs.4s	v3, v25, v22
	and.16b	v23, v3, v23
	stp	q23, q24, [x10]
	add	x9, x9, #32
	cmp	x9, #3, lsl #12                 ; =12288
	b.ne	LBB1_38
; %bb.39:                               ; %direct.false.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	sshll.2d	v22, v0, #0
	sshll.2d	v23, v1, #0
Lloh184:
	adrp	x9, lCPI1_10@PAGE
Lloh185:
	ldr	q24, [x9, lCPI1_10@PAGEOFF]
	ldr	q25, [sp, #2576]                ; 16-byte Reload
	add.2d	v24, v25, v24
	str	q24, [sp, #2368]                ; 16-byte Spill
Lloh186:
	adrp	x9, lCPI1_11@PAGE
Lloh187:
	ldr	q24, [x9, lCPI1_11@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2352]                ; 16-byte Spill
Lloh188:
	adrp	x9, lCPI1_12@PAGE
Lloh189:
	ldr	q24, [x9, lCPI1_12@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2336]                ; 16-byte Spill
Lloh190:
	adrp	x9, lCPI1_13@PAGE
Lloh191:
	ldr	q24, [x9, lCPI1_13@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2320]                ; 16-byte Spill
Lloh192:
	adrp	x9, lCPI1_14@PAGE
Lloh193:
	ldr	q24, [x9, lCPI1_14@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2304]                ; 16-byte Spill
Lloh194:
	adrp	x9, lCPI1_15@PAGE
Lloh195:
	ldr	q24, [x9, lCPI1_15@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2288]                ; 16-byte Spill
Lloh196:
	adrp	x9, lCPI1_16@PAGE
Lloh197:
	ldr	q24, [x9, lCPI1_16@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2272]                ; 16-byte Spill
Lloh198:
	adrp	x9, lCPI1_17@PAGE
Lloh199:
	ldr	q24, [x9, lCPI1_17@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2256]                ; 16-byte Spill
Lloh200:
	adrp	x9, lCPI1_18@PAGE
Lloh201:
	ldr	q24, [x9, lCPI1_18@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2240]                ; 16-byte Spill
Lloh202:
	adrp	x9, lCPI1_19@PAGE
Lloh203:
	ldr	q24, [x9, lCPI1_19@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2224]                ; 16-byte Spill
Lloh204:
	adrp	x9, lCPI1_20@PAGE
Lloh205:
	ldr	q24, [x9, lCPI1_20@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2208]                ; 16-byte Spill
Lloh206:
	adrp	x9, lCPI1_21@PAGE
Lloh207:
	ldr	q24, [x9, lCPI1_21@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2192]                ; 16-byte Spill
Lloh208:
	adrp	x9, lCPI1_22@PAGE
Lloh209:
	ldr	q24, [x9, lCPI1_22@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2176]                ; 16-byte Spill
Lloh210:
	adrp	x9, lCPI1_23@PAGE
Lloh211:
	ldr	q24, [x9, lCPI1_23@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2160]                ; 16-byte Spill
Lloh212:
	adrp	x9, lCPI1_24@PAGE
Lloh213:
	ldr	q24, [x9, lCPI1_24@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2144]                ; 16-byte Spill
Lloh214:
	adrp	x9, lCPI1_25@PAGE
Lloh215:
	ldr	q24, [x9, lCPI1_25@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2128]                ; 16-byte Spill
Lloh216:
	adrp	x9, lCPI1_26@PAGE
Lloh217:
	ldr	q24, [x9, lCPI1_26@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2112]                ; 16-byte Spill
Lloh218:
	adrp	x9, lCPI1_27@PAGE
Lloh219:
	ldr	q24, [x9, lCPI1_27@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2096]                ; 16-byte Spill
	fmov	x9, d21
	add	x9, x9, x9, lsl #7
	mov.d	x10, v21[1]
	fmov	d21, x9
	add	x9, x10, x10, lsl #7
	mov.d	v21[1], x9
	and.16b	v9, v23, v21
Lloh220:
	adrp	x9, lCPI1_28@PAGE
Lloh221:
	ldr	q21, [x9, lCPI1_28@PAGEOFF]
	add.2d	v21, v25, v21
	str	q21, [sp, #2064]                ; 16-byte Spill
	fmov	x9, d20
	mov.d	x10, v20[1]
	add	x9, x9, x9, lsl #7
	fmov	d20, x9
	add	x9, x10, x10, lsl #7
	mov.d	v20[1], x9
	and.16b	v22, v22, v20
Lloh222:
	adrp	x9, lCPI1_29@PAGE
Lloh223:
	ldr	q20, [x9, lCPI1_29@PAGEOFF]
	add.2d	v20, v25, v20
	str	q20, [sp, #2032]                ; 16-byte Spill
	fmov	x9, d18
	mov.d	x10, v18[1]
Lloh224:
	adrp	x12, lCPI1_30@PAGE
Lloh225:
	ldr	q18, [x12, lCPI1_30@PAGEOFF]
	add.2d	v18, v25, v18
	str	q18, [sp, #2016]                ; 16-byte Spill
	fmov	x17, d16
	mov.d	x0, v16[1]
Lloh226:
	adrp	x12, lCPI1_31@PAGE
Lloh227:
	ldr	q16, [x12, lCPI1_31@PAGEOFF]
	add.2d	v16, v25, v16
	str	q16, [sp, #2000]                ; 16-byte Spill
	fmov	x12, d17
	mov.d	x13, v17[1]
Lloh228:
	adrp	x14, lCPI1_32@PAGE
Lloh229:
	ldr	q16, [x14, lCPI1_32@PAGEOFF]
	add.2d	v16, v25, v16
	str	q16, [sp, #1984]                ; 16-byte Spill
	fmov	x15, d19
	mov.d	x16, v19[1]
Lloh230:
	adrp	x14, lCPI1_33@PAGE
Lloh231:
	ldr	q16, [x14, lCPI1_33@PAGEOFF]
	add.2d	v16, v25, v16
	str	q16, [sp, #1968]                ; 16-byte Spill
	mov.d	x14, v6[1]
	fmov	x1, d6
Lloh232:
	adrp	x2, lCPI1_34@PAGE
Lloh233:
	ldr	q6, [x2, lCPI1_34@PAGEOFF]
	add.2d	v6, v25, v6
	str	q6, [sp, #1952]                 ; 16-byte Spill
	fmov	x4, d7
	mov.d	x2, v7[1]
Lloh234:
	adrp	x3, lCPI1_35@PAGE
Lloh235:
	ldr	q6, [x3, lCPI1_35@PAGEOFF]
	add.2d	v6, v25, v6
	str	q6, [sp, #1936]                 ; 16-byte Spill
	fmov	x5, d4
	mov.d	x3, v4[1]
Lloh236:
	adrp	x7, lCPI1_36@PAGE
Lloh237:
	ldr	q4, [x7, lCPI1_36@PAGEOFF]
	add.2d	v4, v25, v4
	str	q4, [sp, #1920]                 ; 16-byte Spill
	fmov	x21, d5
	mov.d	x7, v5[1]
Lloh238:
	adrp	x20, lCPI1_37@PAGE
Lloh239:
	ldr	q4, [x20, lCPI1_37@PAGEOFF]
	add.2d	v4, v25, v4
	str	q4, [sp, #1904]                 ; 16-byte Spill
	fmov	x22, d2
	mov.d	x20, v2[1]
Lloh240:
	adrp	x24, lCPI1_38@PAGE
Lloh241:
	ldr	q2, [x24, lCPI1_38@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1888]                 ; 16-byte Spill
	fmov	x26, d11
	mov.d	x24, v11[1]
Lloh242:
	adrp	x27, lCPI1_39@PAGE
Lloh243:
	ldr	q2, [x27, lCPI1_39@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1872]                 ; 16-byte Spill
Lloh244:
	adrp	x27, lCPI1_40@PAGE
Lloh245:
	ldr	q2, [x27, lCPI1_40@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1856]                 ; 16-byte Spill
Lloh246:
	adrp	x27, lCPI1_41@PAGE
Lloh247:
	ldr	q2, [x27, lCPI1_41@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1840]                 ; 16-byte Spill
Lloh248:
	adrp	x27, lCPI1_42@PAGE
Lloh249:
	ldr	q2, [x27, lCPI1_42@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1824]                 ; 16-byte Spill
Lloh250:
	adrp	x27, lCPI1_43@PAGE
Lloh251:
	ldr	q2, [x27, lCPI1_43@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1808]                 ; 16-byte Spill
Lloh252:
	adrp	x27, lCPI1_44@PAGE
Lloh253:
	ldr	q2, [x27, lCPI1_44@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1792]                 ; 16-byte Spill
Lloh254:
	adrp	x27, lCPI1_45@PAGE
Lloh255:
	ldr	q2, [x27, lCPI1_45@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1776]                 ; 16-byte Spill
Lloh256:
	adrp	x27, lCPI1_46@PAGE
Lloh257:
	ldr	q2, [x27, lCPI1_46@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1760]                 ; 16-byte Spill
Lloh258:
	adrp	x27, lCPI1_47@PAGE
Lloh259:
	ldr	q2, [x27, lCPI1_47@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1744]                 ; 16-byte Spill
Lloh260:
	adrp	x27, lCPI1_48@PAGE
Lloh261:
	ldr	q2, [x27, lCPI1_48@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1728]                 ; 16-byte Spill
Lloh262:
	adrp	x27, lCPI1_49@PAGE
Lloh263:
	ldr	q2, [x27, lCPI1_49@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1712]                 ; 16-byte Spill
Lloh264:
	adrp	x27, lCPI1_50@PAGE
Lloh265:
	ldr	q2, [x27, lCPI1_50@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1696]                 ; 16-byte Spill
Lloh266:
	adrp	x27, lCPI1_51@PAGE
Lloh267:
	ldr	q2, [x27, lCPI1_51@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1680]                 ; 16-byte Spill
Lloh268:
	adrp	x27, lCPI1_52@PAGE
Lloh269:
	ldr	q2, [x27, lCPI1_52@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1664]                 ; 16-byte Spill
Lloh270:
	adrp	x27, lCPI1_53@PAGE
Lloh271:
	ldr	q2, [x27, lCPI1_53@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1648]                 ; 16-byte Spill
Lloh272:
	adrp	x27, lCPI1_54@PAGE
Lloh273:
	ldr	q2, [x27, lCPI1_54@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1632]                 ; 16-byte Spill
Lloh274:
	adrp	x27, lCPI1_55@PAGE
Lloh275:
	ldr	q2, [x27, lCPI1_55@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1616]                 ; 16-byte Spill
Lloh276:
	adrp	x27, lCPI1_56@PAGE
Lloh277:
	ldr	q2, [x27, lCPI1_56@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1600]                 ; 16-byte Spill
Lloh278:
	adrp	x27, lCPI1_57@PAGE
Lloh279:
	ldr	q2, [x27, lCPI1_57@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1584]                 ; 16-byte Spill
Lloh280:
	adrp	x27, lCPI1_58@PAGE
Lloh281:
	ldr	q2, [x27, lCPI1_58@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1568]                 ; 16-byte Spill
Lloh282:
	adrp	x27, lCPI1_59@PAGE
Lloh283:
	ldr	q2, [x27, lCPI1_59@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1552]                 ; 16-byte Spill
Lloh284:
	adrp	x27, lCPI1_60@PAGE
Lloh285:
	ldr	q2, [x27, lCPI1_60@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1536]                 ; 16-byte Spill
Lloh286:
	adrp	x27, lCPI1_61@PAGE
Lloh287:
	ldr	q2, [x27, lCPI1_61@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1520]                 ; 16-byte Spill
Lloh288:
	adrp	x27, lCPI1_62@PAGE
Lloh289:
	ldr	q2, [x27, lCPI1_62@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1504]                 ; 16-byte Spill
Lloh290:
	adrp	x27, lCPI1_63@PAGE
Lloh291:
	ldr	q2, [x27, lCPI1_63@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1488]                 ; 16-byte Spill
Lloh292:
	adrp	x27, lCPI1_64@PAGE
Lloh293:
	ldr	q2, [x27, lCPI1_64@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1472]                 ; 16-byte Spill
Lloh294:
	adrp	x27, lCPI1_65@PAGE
Lloh295:
	ldr	q2, [x27, lCPI1_65@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1456]                 ; 16-byte Spill
Lloh296:
	adrp	x27, lCPI1_66@PAGE
Lloh297:
	ldr	q2, [x27, lCPI1_66@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1440]                 ; 16-byte Spill
Lloh298:
	adrp	x27, lCPI1_67@PAGE
Lloh299:
	ldr	q2, [x27, lCPI1_67@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1424]                 ; 16-byte Spill
Lloh300:
	adrp	x27, lCPI1_68@PAGE
Lloh301:
	ldr	q2, [x27, lCPI1_68@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1408]                 ; 16-byte Spill
Lloh302:
	adrp	x27, lCPI1_69@PAGE
Lloh303:
	ldr	q2, [x27, lCPI1_69@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1392]                 ; 16-byte Spill
	mov	w27, #65                        ; =0x41
	dup.2d	v2, x27
	orr.16b	v4, v30, v2
	str	q4, [sp, #1376]                 ; 16-byte Spill
	orr.16b	v4, v29, v2
	str	q4, [sp, #1360]                 ; 16-byte Spill
	orr.16b	v4, v27, v2
	str	q4, [sp, #1344]                 ; 16-byte Spill
	orr.16b	v2, v31, v2
	str	q2, [sp, #1328]                 ; 16-byte Spill
	mov	w27, #66                        ; =0x42
	dup.2d	v2, x27
	orr.16b	v4, v30, v2
	str	q4, [sp, #1312]                 ; 16-byte Spill
	orr.16b	v4, v29, v2
	str	q4, [sp, #1296]                 ; 16-byte Spill
	orr.16b	v4, v27, v2
	str	q4, [sp, #1280]                 ; 16-byte Spill
	orr.16b	v2, v31, v2
	str	q2, [sp, #1264]                 ; 16-byte Spill
	mov	w27, #67                        ; =0x43
	dup.2d	v2, x27
	orr.16b	v4, v30, v2
	str	q4, [sp, #1248]                 ; 16-byte Spill
	orr.16b	v4, v29, v2
	str	q4, [sp, #1232]                 ; 16-byte Spill
	orr.16b	v4, v27, v2
	str	q4, [sp, #1216]                 ; 16-byte Spill
	orr.16b	v2, v31, v2
	str	q2, [sp, #1200]                 ; 16-byte Spill
	mov	w27, #68                        ; =0x44
	dup.2d	v2, x27
	orr.16b	v4, v30, v2
	str	q4, [sp, #1184]                 ; 16-byte Spill
	orr.16b	v4, v29, v2
	str	q4, [sp, #1168]                 ; 16-byte Spill
	orr.16b	v4, v27, v2
	str	q4, [sp, #1152]                 ; 16-byte Spill
	orr.16b	v2, v31, v2
	str	q2, [sp, #1136]                 ; 16-byte Spill
	mov	w27, #69                        ; =0x45
	dup.2d	v2, x27
	orr.16b	v4, v30, v2
	str	q4, [sp, #1120]                 ; 16-byte Spill
	orr.16b	v4, v29, v2
	str	q4, [sp, #1104]                 ; 16-byte Spill
	orr.16b	v4, v27, v2
	str	q4, [sp, #1088]                 ; 16-byte Spill
	orr.16b	v2, v31, v2
	str	q2, [sp, #1072]                 ; 16-byte Spill
	mov	w27, #70                        ; =0x46
	dup.2d	v2, x27
	orr.16b	v4, v30, v2
	str	q4, [sp, #1056]                 ; 16-byte Spill
	orr.16b	v4, v29, v2
	str	q4, [sp, #1040]                 ; 16-byte Spill
	orr.16b	v4, v27, v2
	orr.16b	v2, v31, v2
	stp	q2, q4, [sp, #1008]             ; 32-byte Folded Spill
	mov	w27, #71                        ; =0x47
	dup.2d	v2, x27
	orr.16b	v5, v30, v2
	orr.16b	v4, v29, v2
	stp	q4, q5, [sp, #976]              ; 32-byte Folded Spill
	orr.16b	v4, v27, v2
	orr.16b	v2, v31, v2
	stp	q2, q4, [sp, #944]              ; 32-byte Folded Spill
	mov	w27, #72                        ; =0x48
	dup.2d	v2, x27
	str	q30, [sp, #64]                  ; 16-byte Spill
	add.2d	v5, v30, v2
	str	q29, [sp, #112]                 ; 16-byte Spill
	add.2d	v4, v29, v2
	stp	q4, q5, [sp, #912]              ; 32-byte Folded Spill
	str	q27, [sp, #144]                 ; 16-byte Spill
	add.2d	v4, v27, v2
	str	q31, [sp, #16]                  ; 16-byte Spill
	add.2d	v2, v31, v2
	stp	q2, q4, [sp, #880]              ; 32-byte Folded Spill
	uzp1.8h	v2, v3, v15
	xtn.8b	v2, v2
	str	d2, [sp, #4920]                 ; 8-byte Spill
	add	x17, x17, x17, lsl #7
	add	x0, x0, x0, lsl #7
	fmov	d2, x17
	mov.d	v2[1], x0
	str	q28, [sp, #4304]                ; 16-byte Spill
	and.16b	v4, v28, v2
	add	x9, x9, x9, lsl #7
	add	x10, x10, x10, lsl #7
	fmov	d2, x9
	mov.d	v2[1], x10
	str	q10, [sp, #4288]                ; 16-byte Spill
	and.16b	v2, v10, v2
	stp	q2, q4, [sp, #848]              ; 32-byte Folded Spill
	add	x9, x12, x15
	str	x9, [sp, #840]                  ; 8-byte Spill
	mov	x12, #0                         ; =0x0
	add	x8, x13, x16
	str	x8, [sp, #832]                  ; 8-byte Spill
	add	x9, x30, #19, lsl #12           ; =77824
	add	x10, x9, #512
	add	x8, x1, x4
	str	x8, [sp, #824]                  ; 8-byte Spill
	add	x8, x9, #1024
	stp	x8, x10, [sp, #296]             ; 16-byte Folded Spill
	add	x8, x14, x2
	str	x8, [sp, #816]                  ; 8-byte Spill
	add	x10, x9, #1536
	add	x8, x5, x21
	str	x8, [sp, #808]                  ; 8-byte Spill
	add	x8, x9, #2048
	stp	x8, x10, [sp, #280]             ; 16-byte Folded Spill
	add	x8, x3, x7
	str	x8, [sp, #800]                  ; 8-byte Spill
	add	x8, x9, #2560
	str	x8, [sp, #272]                  ; 8-byte Spill
	add	x10, x22, x26
	add	x8, x9, #3072
	str	x8, [sp, #264]                  ; 8-byte Spill
	add	x16, x20, x24
	add	x8, x9, #3584
	str	x8, [sp, #256]                  ; 8-byte Spill
	mov	w8, #19584                      ; =0x4c80
	movk	w8, #1, lsl #16
	add	x8, x30, x8
	str	x8, [sp, #792]                  ; 8-byte Spill
	mov	w8, #20096                      ; =0x4e80
	movk	w8, #1, lsl #16
	add	x8, x30, x8
	str	x8, [sp, #784]                  ; 8-byte Spill
	mov	w8, #20608                      ; =0x5080
	movk	w8, #1, lsl #16
	add	x8, x30, x8
	str	x8, [sp, #776]                  ; 8-byte Spill
	mov	w8, #21120                      ; =0x5280
	movk	w8, #1, lsl #16
	add	x8, x30, x8
	str	x8, [sp, #768]                  ; 8-byte Spill
	mov	w8, #21632                      ; =0x5480
	movk	w8, #1, lsl #16
	add	x8, x30, x8
	str	x8, [sp, #760]                  ; 8-byte Spill
	mov	w8, #22144                      ; =0x5680
	movk	w8, #1, lsl #16
	add	x8, x30, x8
	str	x8, [sp, #752]                  ; 8-byte Spill
	mov	w8, #22656                      ; =0x5880
	movk	w8, #1, lsl #16
	add	x8, x30, x8
	mov	w9, #16576                      ; =0x40c0
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #744]                  ; 8-byte Spill
	mov	w9, #16640                      ; =0x4100
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #736]                  ; 8-byte Spill
	mov	w9, #16704                      ; =0x4140
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #728]                  ; 8-byte Spill
	mov	w9, #16768                      ; =0x4180
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #720]                  ; 8-byte Spill
	mov	w9, #16832                      ; =0x41c0
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #712]                  ; 8-byte Spill
	mov	w9, #16896                      ; =0x4200
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #704]                  ; 8-byte Spill
	mov	w9, #16960                      ; =0x4240
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #696]                  ; 8-byte Spill
	mov	w9, #17024                      ; =0x4280
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #688]                  ; 8-byte Spill
	mov	w9, #17088                      ; =0x42c0
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #680]                  ; 8-byte Spill
	mov	w9, #17152                      ; =0x4300
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #672]                  ; 8-byte Spill
	mov	w9, #17216                      ; =0x4340
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #664]                  ; 8-byte Spill
	mov	w9, #17280                      ; =0x4380
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #656]                  ; 8-byte Spill
	mov	w9, #17344                      ; =0x43c0
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #648]                  ; 8-byte Spill
	mov	w9, #17408                      ; =0x4400
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #640]                  ; 8-byte Spill
	mov	w9, #17472                      ; =0x4440
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #632]                  ; 8-byte Spill
	mov	w9, #17600                      ; =0x44c0
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #624]                  ; 8-byte Spill
	mov	w9, #17664                      ; =0x4500
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #616]                  ; 8-byte Spill
	mov	w9, #17728                      ; =0x4540
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #608]                  ; 8-byte Spill
	mov	w9, #17792                      ; =0x4580
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #600]                  ; 8-byte Spill
	mov	w9, #17856                      ; =0x45c0
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #592]                  ; 8-byte Spill
	mov	w9, #17920                      ; =0x4600
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #584]                  ; 8-byte Spill
	mov	w9, #17984                      ; =0x4640
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #576]                  ; 8-byte Spill
	mov	w9, #23200                      ; =0x5aa0
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #568]                  ; 8-byte Spill
	mov	w9, #23232                      ; =0x5ac0
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #560]                  ; 8-byte Spill
	mov	w9, #23264                      ; =0x5ae0
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #552]                  ; 8-byte Spill
	mov	w9, #23296                      ; =0x5b00
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #544]                  ; 8-byte Spill
	mov	w9, #23328                      ; =0x5b20
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #536]                  ; 8-byte Spill
	mov	w9, #23360                      ; =0x5b40
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #528]                  ; 8-byte Spill
	mov	w9, #23392                      ; =0x5b60
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #520]                  ; 8-byte Spill
	mov	w9, #23456                      ; =0x5ba0
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #512]                  ; 8-byte Spill
	mov	w9, #23488                      ; =0x5bc0
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #504]                  ; 8-byte Spill
	mov	w9, #23520                      ; =0x5be0
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #496]                  ; 8-byte Spill
	mov	w9, #23552                      ; =0x5c00
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #488]                  ; 8-byte Spill
	mov	w9, #23584                      ; =0x5c20
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #480]                  ; 8-byte Spill
	mov	w9, #23616                      ; =0x5c40
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #472]                  ; 8-byte Spill
	mov	w9, #23648                      ; =0x5c60
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	str	x9, [sp, #464]                  ; 8-byte Spill
	mov	w9, #62154                      ; =0xf2ca
	movk	w9, #61769, lsl #16
	dup.4s	v4, w9
	and.16b	v2, v0, v4
	str	q4, [sp, #448]                  ; 16-byte Spill
	and.16b	v5, v1, v4
Lloh304:
	adrp	x9, lCPI1_6@PAGE
Lloh305:
	ldr	q4, [x9, lCPI1_6@PAGEOFF]
	str	q4, [sp, #432]                  ; 16-byte Spill
	add.2d	v4, v25, v4
	str	q4, [sp, #416]                  ; 16-byte Spill
Lloh306:
	adrp	x9, lCPI1_7@PAGE
Lloh307:
	ldr	q4, [x9, lCPI1_7@PAGEOFF]
	str	q4, [sp, #400]                  ; 16-byte Spill
	add.2d	v4, v25, v4
	str	q4, [sp, #384]                  ; 16-byte Spill
Lloh308:
	adrp	x9, lCPI1_8@PAGE
Lloh309:
	ldr	q4, [x9, lCPI1_8@PAGEOFF]
	str	q4, [sp, #368]                  ; 16-byte Spill
	add.2d	v4, v25, v4
	str	q4, [sp, #352]                  ; 16-byte Spill
Lloh310:
	adrp	x9, lCPI1_9@PAGE
Lloh311:
	ldr	q4, [x9, lCPI1_9@PAGEOFF]
	str	q4, [sp, #336]                  ; 16-byte Spill
	add.2d	v4, v25, v4
	str	q4, [sp, #320]                  ; 16-byte Spill
	movi.2d	v4, #0000000000000000
	str	q4, [sp, #3280]                 ; 16-byte Spill
	str	q4, [sp, #3264]                 ; 16-byte Spill
	str	q4, [sp, #3248]                 ; 16-byte Spill
	str	q4, [sp, #3232]                 ; 16-byte Spill
	str	q4, [sp, #4896]                 ; 16-byte Spill
	str	q4, [sp, #4880]                 ; 16-byte Spill
	str	q4, [sp, #4864]                 ; 16-byte Spill
	str	q4, [sp, #4848]                 ; 16-byte Spill
	str	q4, [sp, #4832]                 ; 16-byte Spill
	str	q4, [sp, #4816]                 ; 16-byte Spill
	str	q4, [sp, #4800]                 ; 16-byte Spill
	str	q4, [sp, #4784]                 ; 16-byte Spill
	str	q4, [sp, #3216]                 ; 16-byte Spill
	str	q4, [sp, #5248]                 ; 16-byte Spill
	str	q4, [sp, #5232]                 ; 16-byte Spill
	str	q4, [sp, #5216]                 ; 16-byte Spill
	str	q4, [sp, #3200]                 ; 16-byte Spill
	str	q4, [sp, #3184]                 ; 16-byte Spill
	str	q4, [sp, #3168]                 ; 16-byte Spill
	str	q4, [sp, #3312]                 ; 16-byte Spill
	str	q4, [sp, #3152]                 ; 16-byte Spill
	str	q4, [sp, #3136]                 ; 16-byte Spill
	str	q4, [sp, #3120]                 ; 16-byte Spill
	str	q4, [sp, #3296]                 ; 16-byte Spill
	str	q4, [sp, #4256]                 ; 16-byte Spill
	str	q4, [sp, #4240]                 ; 16-byte Spill
	str	q4, [sp, #4224]                 ; 16-byte Spill
	str	q4, [sp, #4208]                 ; 16-byte Spill
	str	q4, [sp, #5488]                 ; 16-byte Spill
	str	q4, [sp, #5472]                 ; 16-byte Spill
	str	q4, [sp, #5456]                 ; 16-byte Spill
	str	q4, [sp, #5440]                 ; 16-byte Spill
	str	q4, [sp, #5424]                 ; 16-byte Spill
	str	q4, [sp, #5408]                 ; 16-byte Spill
	str	q4, [sp, #5392]                 ; 16-byte Spill
	str	q4, [sp, #5376]                 ; 16-byte Spill
	str	q4, [sp, #5360]                 ; 16-byte Spill
	str	q4, [sp, #5344]                 ; 16-byte Spill
	str	q4, [sp, #5328]                 ; 16-byte Spill
	str	q4, [sp, #5312]                 ; 16-byte Spill
	str	q4, [sp, #5664]                 ; 16-byte Spill
	str	q4, [sp, #5648]                 ; 16-byte Spill
	str	q4, [sp, #5632]                 ; 16-byte Spill
	movi.2d	v13, #0000000000000000
	movi.2d	v11, #0000000000000000
	movi.2d	v14, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v6, #0000000000000000
	str	q6, [sp, #4192]                 ; 16-byte Spill
	str	q6, [sp, #3104]                 ; 16-byte Spill
	str	q6, [sp, #4176]                 ; 16-byte Spill
	str	q6, [sp, #4160]                 ; 16-byte Spill
	str	q6, [sp, #4144]                 ; 16-byte Spill
	str	q6, [sp, #4128]                 ; 16-byte Spill
	str	q6, [sp, #4112]                 ; 16-byte Spill
	str	q6, [sp, #4096]                 ; 16-byte Spill
	str	q6, [sp, #4080]                 ; 16-byte Spill
	str	q6, [sp, #4064]                 ; 16-byte Spill
	str	q6, [sp, #5200]                 ; 16-byte Spill
	str	q6, [sp, #5184]                 ; 16-byte Spill
	str	q6, [sp, #4048]                 ; 16-byte Spill
	str	q6, [sp, #4032]                 ; 16-byte Spill
	movi.2d	v26, #0000000000000000
	str	q6, [sp, #4016]                 ; 16-byte Spill
	str	q6, [sp, #5616]                 ; 16-byte Spill
	str	q6, [sp, #5600]                 ; 16-byte Spill
	str	q6, [sp, #5584]                 ; 16-byte Spill
	str	q6, [sp, #5568]                 ; 16-byte Spill
	str	q6, [sp, #5552]                 ; 16-byte Spill
	str	q6, [sp, #5536]                 ; 16-byte Spill
	str	q6, [sp, #5520]                 ; 16-byte Spill
	str	q6, [sp, #5504]                 ; 16-byte Spill
	str	q6, [sp, #5168]                 ; 16-byte Spill
	str	q6, [sp, #5152]                 ; 16-byte Spill
	str	q6, [sp, #5136]                 ; 16-byte Spill
	str	q6, [sp, #5120]                 ; 16-byte Spill
	str	q6, [sp, #5104]                 ; 16-byte Spill
	str	q6, [sp, #5088]                 ; 16-byte Spill
	str	q6, [sp, #5072]                 ; 16-byte Spill
	str	q6, [sp, #5056]                 ; 16-byte Spill
	str	q6, [sp, #5040]                 ; 16-byte Spill
	str	q6, [sp, #5024]                 ; 16-byte Spill
	str	q6, [sp, #5008]                 ; 16-byte Spill
	str	q6, [sp, #4992]                 ; 16-byte Spill
	str	q6, [sp, #4976]                 ; 16-byte Spill
	str	q6, [sp, #4960]                 ; 16-byte Spill
	str	q6, [sp, #4944]                 ; 16-byte Spill
	str	q6, [sp, #4928]                 ; 16-byte Spill
	str	q6, [sp, #3088]                 ; 16-byte Spill
	str	q6, [sp, #3072]                 ; 16-byte Spill
	str	q6, [sp, #4000]                 ; 16-byte Spill
	str	q6, [sp, #3984]                 ; 16-byte Spill
	str	q6, [sp, #3968]                 ; 16-byte Spill
	str	q6, [sp, #4512]                 ; 16-byte Spill
	str	q6, [sp, #5280]                 ; 16-byte Spill
	str	q6, [sp, #5264]                 ; 16-byte Spill
	str	q6, [sp, #4768]                 ; 16-byte Spill
	str	q6, [sp, #4752]                 ; 16-byte Spill
	str	q6, [sp, #4736]                 ; 16-byte Spill
	str	q6, [sp, #4720]                 ; 16-byte Spill
	str	q6, [sp, #4704]                 ; 16-byte Spill
	str	q6, [sp, #4688]                 ; 16-byte Spill
	str	q6, [sp, #4672]                 ; 16-byte Spill
	str	q6, [sp, #4656]                 ; 16-byte Spill
	str	q6, [sp, #4640]                 ; 16-byte Spill
	str	q6, [sp, #4624]                 ; 16-byte Spill
	str	q6, [sp, #4608]                 ; 16-byte Spill
	str	q6, [sp, #4592]                 ; 16-byte Spill
	str	q6, [sp, #4576]                 ; 16-byte Spill
	str	q6, [sp, #4560]                 ; 16-byte Spill
	str	q6, [sp, #4544]                 ; 16-byte Spill
	str	q6, [sp, #4528]                 ; 16-byte Spill
	str	q6, [sp, #3056]                 ; 16-byte Spill
	str	q6, [sp, #3952]                 ; 16-byte Spill
	str	q6, [sp, #3936]                 ; 16-byte Spill
	str	q6, [sp, #3920]                 ; 16-byte Spill
	str	q6, [sp, #3904]                 ; 16-byte Spill
	str	q6, [sp, #3888]                 ; 16-byte Spill
	str	q5, [sp, #4464]                 ; 16-byte Spill
	str	q6, [sp, #3872]                 ; 16-byte Spill
	str	q2, [sp, #4448]                 ; 16-byte Spill
	str	q5, [sp, #4432]                 ; 16-byte Spill
	str	q6, [sp, #3856]                 ; 16-byte Spill
	str	q2, [sp, #4416]                 ; 16-byte Spill
	str	q6, [sp, #3840]                 ; 16-byte Spill
	str	q5, [sp, #4400]                 ; 16-byte Spill
	str	q6, [sp, #3824]                 ; 16-byte Spill
	str	q2, [sp, #4384]                 ; 16-byte Spill
	str	q5, [sp, #4368]                 ; 16-byte Spill
	str	q6, [sp, #3808]                 ; 16-byte Spill
	str	q2, [sp, #4352]                 ; 16-byte Spill
	str	q6, [sp, #3792]                 ; 16-byte Spill
	str	q5, [sp, #4336]                 ; 16-byte Spill
	str	q6, [sp, #3776]                 ; 16-byte Spill
	str	q2, [sp, #4320]                 ; 16-byte Spill
	str	q5, [sp, #3760]                 ; 16-byte Spill
	str	q6, [sp, #3744]                 ; 16-byte Spill
	str	q2, [sp, #3728]                 ; 16-byte Spill
	str	q6, [sp, #3712]                 ; 16-byte Spill
	str	q5, [sp, #4480]                 ; 16-byte Spill
	str	q5, [sp, #3696]                 ; 16-byte Spill
	str	q2, [sp, #4496]                 ; 16-byte Spill
	str	q2, [sp, #3680]                 ; 16-byte Spill
	movi.2d	v2, #0000000000000000
	str	q2, [sp, #3664]                 ; 16-byte Spill
	ldr	w2, [sp, #2636]                 ; 4-byte Reload
	ldr	w7, [sp, #2632]                 ; 4-byte Reload
	ldr	w20, [sp, #2628]                ; 4-byte Reload
	ldr	w22, [sp, #2624]                ; 4-byte Reload
	ldr	w24, [sp, #2620]                ; 4-byte Reload
	ldr	w26, [sp, #2616]                ; 4-byte Reload
	ldr	w27, [sp, #2612]                ; 4-byte Reload
	ldr	x17, [sp, #2600]                ; 8-byte Reload
	str	q15, [sp, #2400]                ; 16-byte Spill
	movi.2d	v15, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v24, #0000000000000000
	str	q3, [sp, #2384]                 ; 16-byte Spill
	str	q9, [sp, #2080]                 ; 16-byte Spill
	str	q22, [sp, #2048]                ; 16-byte Spill
LBB1_40:                                ; %direct.true216.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB1_63 Depth 3
                                        ;       Child Loop BB1_66 Depth 3
                                        ;       Child Loop BB1_69 Depth 3
                                        ;       Child Loop BB1_72 Depth 3
                                        ;       Child Loop BB1_75 Depth 3
                                        ;       Child Loop BB1_78 Depth 3
                                        ;       Child Loop BB1_81 Depth 3
                                        ;       Child Loop BB1_84 Depth 3
                                        ;       Child Loop BB1_87 Depth 3
                                        ;       Child Loop BB1_90 Depth 3
                                        ;       Child Loop BB1_93 Depth 3
                                        ;       Child Loop BB1_96 Depth 3
                                        ;       Child Loop BB1_99 Depth 3
                                        ;       Child Loop BB1_102 Depth 3
                                        ;       Child Loop BB1_105 Depth 3
                                        ;       Child Loop BB1_108 Depth 3
                                        ;       Child Loop BB1_43 Depth 3
                                        ;       Child Loop BB1_111 Depth 3
                                        ;       Child Loop BB1_132 Depth 3
                                        ;       Child Loop BB1_150 Depth 3
                                        ;       Child Loop BB1_153 Depth 3
                                        ;       Child Loop BB1_156 Depth 3
                                        ;       Child Loop BB1_159 Depth 3
                                        ;       Child Loop BB1_162 Depth 3
                                        ;       Child Loop BB1_165 Depth 3
                                        ;       Child Loop BB1_168 Depth 3
                                        ;       Child Loop BB1_171 Depth 3
                                        ;       Child Loop BB1_308 Depth 3
                                        ;       Child Loop BB1_342 Depth 3
                                        ;       Child Loop BB1_375 Depth 3
                                        ;       Child Loop BB1_377 Depth 3
                                        ;       Child Loop BB1_379 Depth 3
                                        ;       Child Loop BB1_381 Depth 3
                                        ;       Child Loop BB1_383 Depth 3
                                        ;       Child Loop BB1_385 Depth 3
                                        ;       Child Loop BB1_387 Depth 3
                                        ;       Child Loop BB1_389 Depth 3
                                        ;       Child Loop BB1_392 Depth 3
                                        ;       Child Loop BB1_426 Depth 3
                                        ;       Child Loop BB1_444 Depth 3
                                        ;       Child Loop BB1_462 Depth 3
                                        ;       Child Loop BB1_480 Depth 3
                                        ;       Child Loop BB1_498 Depth 3
                                        ;       Child Loop BB1_516 Depth 3
                                        ;       Child Loop BB1_534 Depth 3
                                        ;       Child Loop BB1_552 Depth 3
                                        ;       Child Loop BB1_570 Depth 3
                                        ;       Child Loop BB1_588 Depth 3
                                        ;         Child Loop BB1_589 Depth 4
                                        ;       Child Loop BB1_593 Depth 3
                                        ;         Child Loop BB1_594 Depth 4
                                        ;       Child Loop BB1_598 Depth 3
                                        ;         Child Loop BB1_599 Depth 4
                                        ;       Child Loop BB1_603 Depth 3
                                        ;         Child Loop BB1_604 Depth 4
                                        ;       Child Loop BB1_608 Depth 3
                                        ;         Child Loop BB1_609 Depth 4
                                        ;       Child Loop BB1_613 Depth 3
                                        ;         Child Loop BB1_614 Depth 4
                                        ;       Child Loop BB1_618 Depth 3
                                        ;         Child Loop BB1_619 Depth 4
                                        ;       Child Loop BB1_623 Depth 3
                                        ;         Child Loop BB1_624 Depth 4
                                        ;       Child Loop BB1_628 Depth 3
                                        ;       Child Loop BB1_645 Depth 3
	str	q15, [sp, #2976]                ; 16-byte Spill
	str	q30, [sp, #2992]                ; 16-byte Spill
	str	q29, [sp, #3008]                ; 16-byte Spill
	str	q24, [sp, #3024]                ; 16-byte Spill
	sshll.2d	v2, v1, #0
	sshll.2d	v3, v0, #0
	lsl	x21, x12, #4
	ldr	q5, [sp, #2544]                 ; 16-byte Reload
	ldr	q6, [sp, #4592]                 ; 16-byte Reload
	ldr	q10, [sp, #4288]                ; 16-byte Reload
	bit.16b	v6, v5, v10
	str	q6, [sp, #4592]                 ; 16-byte Spill
	ldr	q6, [sp, #4624]                 ; 16-byte Reload
	ldr	q28, [sp, #4304]                ; 16-byte Reload
	bit.16b	v6, v5, v28
	str	q6, [sp, #4624]                 ; 16-byte Spill
	ldr	q6, [sp, #4608]                 ; 16-byte Reload
	bit.16b	v6, v5, v3
	str	q6, [sp, #4608]                 ; 16-byte Spill
	ldr	q6, [sp, #4640]                 ; 16-byte Reload
	bit.16b	v6, v5, v2
	str	q6, [sp, #4640]                 ; 16-byte Spill
Lloh312:
	adrp	x9, lCPI1_70@PAGE
Lloh313:
	ldr	q5, [x9, lCPI1_70@PAGEOFF]
	ldr	q6, [sp, #4528]                 ; 16-byte Reload
	bit.16b	v6, v5, v10
	str	q6, [sp, #4528]                 ; 16-byte Spill
Lloh314:
	adrp	x9, lCPI1_71@PAGE
Lloh315:
	ldr	q5, [x9, lCPI1_71@PAGEOFF]
	ldr	q6, [sp, #4560]                 ; 16-byte Reload
	bit.16b	v6, v5, v28
	str	q6, [sp, #4560]                 ; 16-byte Spill
Lloh316:
	adrp	x9, lCPI1_72@PAGE
Lloh317:
	ldr	q5, [x9, lCPI1_72@PAGEOFF]
	ldr	q6, [sp, #4544]                 ; 16-byte Reload
	bit.16b	v6, v5, v3
	str	q6, [sp, #4544]                 ; 16-byte Spill
Lloh318:
	adrp	x9, lCPI1_73@PAGE
Lloh319:
	ldr	q3, [x9, lCPI1_73@PAGEOFF]
	ldr	q5, [sp, #4576]                 ; 16-byte Reload
	bit.16b	v5, v3, v2
	str	q5, [sp, #4576]                 ; 16-byte Spill
	dup.2d	v6, x21
	str	x12, [sp, #3048]                ; 8-byte Spill
	cmp	x12, #8
	str	q6, [sp, #3648]                 ; 16-byte Spill
	b.ne	LBB1_61
; %bb.41:                               ; %direct.true879.i.i.preheader
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	ldp	q24, q21, [sp, #848]            ; 32-byte Folded Reload
	ldr	x3, [sp, #840]                  ; 8-byte Reload
	ldr	q29, [sp, #3280]                ; 16-byte Reload
	ldr	q30, [sp, #3264]                ; 16-byte Reload
	ldr	q31, [sp, #3248]                ; 16-byte Reload
	ldr	q15, [sp, #3232]                ; 16-byte Reload
	mvni.4s	v25, #127, msl #16
	b	LBB1_43
LBB1_42:                                ; %else649
                                        ;   in Loop: Header=BB1_43 Depth=3
	sshll.2d	v3, v0, #0
	add.2d	v5, v7, v21
	add.2d	v16, v7, v22
	add.2d	v7, v7, v24
	shl.2d	v7, v7, #5
	shl.2d	v16, v16, #5
	shl.2d	v5, v5, #5
	orr.16b	v5, v5, v6
	orr.16b	v16, v16, v6
	orr.16b	v6, v7, v6
	ldr	q7, [sp, #4880]                 ; 16-byte Reload
	bit.16b	v7, v6, v10
	str	q7, [sp, #4880]                 ; 16-byte Spill
	ldr	q6, [sp, #4896]                 ; 16-byte Reload
	bit.16b	v6, v16, v3
	str	q6, [sp, #4896]                 ; 16-byte Spill
	bit.16b	v15, v5, v28
	add	x13, x13, #1
	add	x12, x12, #4
	cmp	x13, #512
	b.eq	LBB1_109
LBB1_43:                                ; %direct.true879.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	sshll.2d	v2, v1, #0
	and	x9, x13, #0x1f
	lsr	x14, x13, #5
	orr	x15, x14, #0x80
	dup.2d	v7, x15
	add.2d	v3, v7, v9
	shl.2d	v3, v3, #5
	dup.2d	v6, x9
	orr.16b	v3, v3, v6
	bit.16b	v29, v3, v2
	movi.2d	v16, #0000000000000000
	cbnz	x14, LBB1_45
; %bb.44:                               ; %direct.true892.i.i
                                        ;   in Loop: Header=BB1_43 Depth=3
	fmov	x9, d29
	add	x9, x17, x9, lsl #2
	ld1r.4s	{ v16 }, [x9]
LBB1_45:                                ; %direct.schedule.88.i.i
                                        ;   in Loop: Header=BB1_43 Depth=3
	uzp1.8h	v2, v1, v0
	ldr	q3, [x25, lCPI1_78@PAGEOFF]
	and.16b	v2, v2, v3
	addv.8h	h2, v2
	fmov	w14, s2
	bit.16b	v30, v16, v1
	dup.2d	v19, x12
	ldr	q3, [sp, #4576]                 ; 16-byte Reload
	orr.16b	v3, v19, v3
	ldr	q5, [sp, #4640]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w14, #0, LBB1_53
; %bb.46:                               ; %else621
                                        ;   in Loop: Header=BB1_43 Depth=3
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB1_54
LBB1_47:                                ; %else625
                                        ;   in Loop: Header=BB1_43 Depth=3
	ldr	q3, [sp, #4560]                 ; 16-byte Reload
	orr.16b	v3, v19, v3
	ldr	q5, [sp, #4624]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w14, #2, LBB1_55
LBB1_48:                                ; %else629
                                        ;   in Loop: Header=BB1_43 Depth=3
	tbnz	w14, #3, LBB1_56
LBB1_49:                                ; %else633
                                        ;   in Loop: Header=BB1_43 Depth=3
	bit.16b	v31, v16, v0
	ldr	q3, [sp, #4544]                 ; 16-byte Reload
	orr.16b	v3, v19, v3
	ldr	q5, [sp, #4608]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w14, #4, LBB1_57
LBB1_50:                                ; %else637
                                        ;   in Loop: Header=BB1_43 Depth=3
	tbnz	w14, #5, LBB1_58
LBB1_51:                                ; %else641
                                        ;   in Loop: Header=BB1_43 Depth=3
	ldr	q3, [sp, #4528]                 ; 16-byte Reload
	orr.16b	v3, v19, v3
	ldr	q5, [sp, #4592]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w14, #6, LBB1_59
LBB1_52:                                ; %else645
                                        ;   in Loop: Header=BB1_43 Depth=3
	tbz	w14, #7, LBB1_42
	b	LBB1_60
LBB1_53:                                ; %cond.store618
                                        ;   in Loop: Header=BB1_43 Depth=3
	fmov	x15, d3
	str	s30, [x15]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB1_47
LBB1_54:                                ; %cond.store622
                                        ;   in Loop: Header=BB1_43 Depth=3
	mov.d	x15, v3[1]
	st1.s	{ v30 }[1], [x15]
	ldr	q3, [sp, #4560]                 ; 16-byte Reload
	orr.16b	v3, v19, v3
	ldr	q5, [sp, #4624]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w14, #2, LBB1_48
LBB1_55:                                ; %cond.store626
                                        ;   in Loop: Header=BB1_43 Depth=3
	fmov	x15, d3
	st1.s	{ v30 }[2], [x15]
	tbz	w14, #3, LBB1_49
LBB1_56:                                ; %cond.store630
                                        ;   in Loop: Header=BB1_43 Depth=3
	mov.d	x15, v3[1]
	st1.s	{ v30 }[3], [x15]
	bit.16b	v31, v16, v0
	ldr	q3, [sp, #4544]                 ; 16-byte Reload
	orr.16b	v3, v19, v3
	ldr	q5, [sp, #4608]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w14, #4, LBB1_50
LBB1_57:                                ; %cond.store634
                                        ;   in Loop: Header=BB1_43 Depth=3
	fmov	x15, d3
	str	s31, [x15]
	tbz	w14, #5, LBB1_51
LBB1_58:                                ; %cond.store638
                                        ;   in Loop: Header=BB1_43 Depth=3
	mov.d	x15, v3[1]
	st1.s	{ v31 }[1], [x15]
	ldr	q3, [sp, #4528]                 ; 16-byte Reload
	orr.16b	v3, v19, v3
	ldr	q5, [sp, #4592]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w14, #6, LBB1_52
LBB1_59:                                ; %cond.store642
                                        ;   in Loop: Header=BB1_43 Depth=3
	fmov	x15, d3
	st1.s	{ v31 }[2], [x15]
	tbz	w14, #7, LBB1_42
LBB1_60:                                ; %cond.store646
                                        ;   in Loop: Header=BB1_43 Depth=3
	mov.d	x14, v3[1]
	st1.s	{ v31 }[3], [x14]
	b	LBB1_42
LBB1_61:                                ; %direct.true219.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	add.2d	v16, v6, v9
	shl.2d	v2, v16, #5
	ldr	x3, [sp, #840]                  ; 8-byte Reload
	ldr	q15, [sp, #3232]                ; 16-byte Reload
	mvni.4s	v25, #127, msl #16
	tbz	w2, #0, LBB1_64
; %bb.62:                               ; %copy.active228.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	q3, [sp, #4640]                 ; 16-byte Reload
	fmov	x13, d3
	ldr	q3, [sp, #4576]                 ; 16-byte Reload
	fmov	x14, d3
	add	x13, x13, x14
	fmov	x14, d2
	add	x14, x17, x14, lsl #2
LBB1_63:                                ; %copy.chunk.i525.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x14, x12]
	str	q3, [x13, x12]
	add	x12, x12, #16
	cmp	x12, #2048
	b.ne	LBB1_63
LBB1_64:                                ; %copy.continue229.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #864]                  ; 16-byte Reload
	ldr	q24, [sp, #3072]                ; 16-byte Reload
	cbz	w7, LBB1_67
; %bb.65:                               ; %copy.active230.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	q5, [sp, #4640]                 ; 16-byte Reload
	mov.d	x13, v5[1]
	ldr	q5, [sp, #4576]                 ; 16-byte Reload
	mov.d	x14, v5[1]
	add	x13, x13, x14
	mov.d	x14, v2[1]
	add	x14, x17, x14, lsl #2
LBB1_66:                                ; %copy.chunk.i528.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q2, [x14, x12]
	str	q2, [x13, x12]
	add	x12, x12, #16
	cmp	x12, #2048
	b.ne	LBB1_66
LBB1_67:                                ; %copy.continue231.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	add.2d	v7, v6, v3
	shl.2d	v2, v7, #5
	ldr	q5, [sp, #848]                  ; 16-byte Reload
	ldr	q29, [sp, #3280]                ; 16-byte Reload
	ldr	q30, [sp, #3264]                ; 16-byte Reload
	ldr	q31, [sp, #3248]                ; 16-byte Reload
	ldr	q21, [sp, #3088]                ; 16-byte Reload
	ldr	q27, [sp, #448]                 ; 16-byte Reload
	cbz	w20, LBB1_70
; %bb.68:                               ; %copy.active232.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	q3, [sp, #4624]                 ; 16-byte Reload
	fmov	x13, d3
	ldr	q3, [sp, #4560]                 ; 16-byte Reload
	fmov	x14, d3
	add	x13, x13, x14
	fmov	x14, d2
	add	x14, x17, x14, lsl #2
LBB1_69:                                ; %copy.chunk.i532.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x14, x12]
	str	q3, [x13, x12]
	add	x12, x12, #16
	cmp	x12, #2048
	b.ne	LBB1_69
LBB1_70:                                ; %copy.continue233.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	cbz	w22, LBB1_73
; %bb.71:                               ; %copy.active234.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	q3, [sp, #4624]                 ; 16-byte Reload
	mov.d	x13, v3[1]
	ldr	q3, [sp, #4560]                 ; 16-byte Reload
	mov.d	x14, v3[1]
	add	x13, x13, x14
	mov.d	x14, v2[1]
	add	x14, x17, x14, lsl #2
LBB1_72:                                ; %copy.chunk.i536.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q2, [x14, x12]
	str	q2, [x13, x12]
	add	x12, x12, #16
	cmp	x12, #2048
	b.ne	LBB1_72
LBB1_73:                                ; %copy.continue235.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	add.2d	v6, v6, v22
	shl.2d	v2, v6, #5
	cbz	w24, LBB1_76
; %bb.74:                               ; %copy.active236.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	q3, [sp, #4608]                 ; 16-byte Reload
	fmov	x13, d3
	ldr	q3, [sp, #4544]                 ; 16-byte Reload
	fmov	x14, d3
	add	x13, x13, x14
	fmov	x14, d2
	add	x14, x17, x14, lsl #2
LBB1_75:                                ; %copy.chunk.i540.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x14, x12]
	str	q3, [x13, x12]
	add	x12, x12, #16
	cmp	x12, #2048
	b.ne	LBB1_75
LBB1_76:                                ; %copy.continue237.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	cbz	w26, LBB1_79
; %bb.77:                               ; %copy.active238.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	q3, [sp, #4608]                 ; 16-byte Reload
	mov.d	x13, v3[1]
	ldr	q3, [sp, #4544]                 ; 16-byte Reload
	mov.d	x14, v3[1]
	add	x13, x13, x14
	mov.d	x14, v2[1]
	add	x14, x17, x14, lsl #2
LBB1_78:                                ; %copy.chunk.i544.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q2, [x14, x12]
	str	q2, [x13, x12]
	add	x12, x12, #16
	cmp	x12, #2048
	b.ne	LBB1_78
LBB1_79:                                ; %copy.continue239.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q2, [sp, #3648]                 ; 16-byte Reload
	add.2d	v2, v2, v5
	shl.2d	v19, v2, #5
	cbz	w27, LBB1_82
; %bb.80:                               ; %copy.active240.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	q3, [sp, #4592]                 ; 16-byte Reload
	fmov	x13, d3
	ldr	q3, [sp, #4528]                 ; 16-byte Reload
	fmov	x14, d3
	add	x13, x13, x14
	fmov	x14, d19
	add	x14, x17, x14, lsl #2
LBB1_81:                                ; %copy.chunk.i548.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x14, x12]
	str	q3, [x13, x12]
	add	x12, x12, #16
	cmp	x12, #2048
	b.ne	LBB1_81
LBB1_82:                                ; %copy.continue241.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	w9, [sp, #4284]                 ; 4-byte Reload
	cbz	w9, LBB1_85
; %bb.83:                               ; %copy.active242.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	q3, [sp, #4592]                 ; 16-byte Reload
	mov.d	x13, v3[1]
	ldr	q3, [sp, #4528]                 ; 16-byte Reload
	mov.d	x14, v3[1]
	add	x13, x13, x14
	mov.d	x14, v19[1]
	add	x14, x17, x14, lsl #2
LBB1_84:                                ; %copy.chunk.i552.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x14, x12]
	str	q3, [x13, x12]
	add	x12, x12, #16
	cmp	x12, #2048
	b.ne	LBB1_84
LBB1_85:                                ; %direct.schedule.7.thread.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	sshll.2d	v3, v1, #0
	ldr	q5, [sp, #4768]                 ; 16-byte Reload
	ldr	q19, [sp, #3328]                ; 16-byte Reload
	bit.16b	v5, v19, v3
	str	q5, [sp, #4768]                 ; 16-byte Spill
Lloh320:
	adrp	x9, lCPI1_77@PAGE
Lloh321:
	ldr	q5, [x9, lCPI1_77@PAGEOFF]
	ldr	q19, [sp, #4704]                ; 16-byte Reload
	bit.16b	v19, v5, v3
	str	q19, [sp, #4704]                ; 16-byte Spill
	fmov	x12, d16
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #4
	fmov	d19, x12
	mov.d	x12, v16[1]
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #4
	mov.d	v19[1], x12
	ldr	x15, [sp, #2568]                ; 8-byte Reload
	tbz	w2, #0, LBB1_88
; %bb.86:                               ; %copy.active255.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	q3, [sp, #4768]                 ; 16-byte Reload
	fmov	x13, d3
	ldr	q3, [sp, #4704]                 ; 16-byte Reload
	fmov	x14, d3
	add	x13, x13, x14
	fmov	x14, d19
	add	x14, x15, x14, lsl #2
LBB1_87:                                ; %copy.chunk.i556.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x14, x12]
	str	q3, [x13, x12]
	add	x12, x12, #16
	cmp	x12, #3072
	b.ne	LBB1_87
LBB1_88:                                ; %copy.continue256.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	cbz	w7, LBB1_91
; %bb.89:                               ; %copy.active257.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	q3, [sp, #4768]                 ; 16-byte Reload
	mov.d	x13, v3[1]
	ldr	q3, [sp, #4704]                 ; 16-byte Reload
	mov.d	x14, v3[1]
	add	x13, x13, x14
	mov.d	x14, v19[1]
	add	x14, x15, x14, lsl #2
LBB1_90:                                ; %copy.chunk.i559.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x14, x12]
	str	q3, [x13, x12]
	add	x12, x12, #16
	cmp	x12, #3072
	b.ne	LBB1_90
LBB1_91:                                ; %copy.continue258.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #4752]                 ; 16-byte Reload
	ldr	q5, [sp, #3328]                 ; 16-byte Reload
	bit.16b	v3, v5, v28
	str	q3, [sp, #4752]                 ; 16-byte Spill
Lloh322:
	adrp	x9, lCPI1_75@PAGE
Lloh323:
	ldr	q3, [x9, lCPI1_75@PAGEOFF]
	ldr	q5, [sp, #4688]                 ; 16-byte Reload
	bit.16b	v5, v3, v28
	str	q5, [sp, #4688]                 ; 16-byte Spill
	fmov	x12, d7
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #4
	fmov	d16, x12
	mov.d	x12, v7[1]
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #4
	mov.d	v16[1], x12
	cbz	w20, LBB1_94
; %bb.92:                               ; %copy.active259.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	q3, [sp, #4752]                 ; 16-byte Reload
	fmov	x13, d3
	ldr	q3, [sp, #4688]                 ; 16-byte Reload
	fmov	x14, d3
	add	x13, x13, x14
	fmov	x14, d16
	add	x14, x15, x14, lsl #2
LBB1_93:                                ; %copy.chunk.i563.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x14, x12]
	str	q3, [x13, x12]
	add	x12, x12, #16
	cmp	x12, #3072
	b.ne	LBB1_93
LBB1_94:                                ; %copy.continue260.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q19, [sp, #4512]                ; 16-byte Reload
	cbz	w22, LBB1_97
; %bb.95:                               ; %copy.active261.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	q3, [sp, #4752]                 ; 16-byte Reload
	mov.d	x13, v3[1]
	ldr	q3, [sp, #4688]                 ; 16-byte Reload
	mov.d	x14, v3[1]
	add	x13, x13, x14
	mov.d	x14, v16[1]
	add	x14, x15, x14, lsl #2
LBB1_96:                                ; %copy.chunk.i567.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x14, x12]
	str	q3, [x13, x12]
	add	x12, x12, #16
	cmp	x12, #3072
	b.ne	LBB1_96
LBB1_97:                                ; %copy.continue262.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	sshll.2d	v3, v0, #0
	ldr	q5, [sp, #4736]                 ; 16-byte Reload
	ldr	q7, [sp, #3328]                 ; 16-byte Reload
	bit.16b	v5, v7, v3
	str	q5, [sp, #4736]                 ; 16-byte Spill
Lloh324:
	adrp	x9, lCPI1_76@PAGE
Lloh325:
	ldr	q5, [x9, lCPI1_76@PAGEOFF]
	ldr	q7, [sp, #4672]                 ; 16-byte Reload
	bit.16b	v7, v5, v3
	str	q7, [sp, #4672]                 ; 16-byte Spill
	fmov	x12, d6
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #4
	fmov	d7, x12
	mov.d	x12, v6[1]
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #4
	mov.d	v7[1], x12
	cbz	w24, LBB1_100
; %bb.98:                               ; %copy.active263.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	q3, [sp, #4736]                 ; 16-byte Reload
	fmov	x13, d3
	ldr	q3, [sp, #4672]                 ; 16-byte Reload
	fmov	x14, d3
	add	x13, x13, x14
	fmov	x14, d7
	add	x14, x15, x14, lsl #2
LBB1_99:                                ; %copy.chunk.i571.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x14, x12]
	str	q3, [x13, x12]
	add	x12, x12, #16
	cmp	x12, #3072
	b.ne	LBB1_99
LBB1_100:                               ; %copy.continue264.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q16, [sp, #3984]                ; 16-byte Reload
	cbz	w26, LBB1_103
; %bb.101:                              ; %copy.active265.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	q3, [sp, #4736]                 ; 16-byte Reload
	mov.d	x13, v3[1]
	ldr	q3, [sp, #4672]                 ; 16-byte Reload
	mov.d	x14, v3[1]
	add	x13, x13, x14
	mov.d	x14, v7[1]
	add	x14, x15, x14, lsl #2
LBB1_102:                               ; %copy.chunk.i575.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x14, x12]
	str	q3, [x13, x12]
	add	x12, x12, #16
	cmp	x12, #3072
	b.ne	LBB1_102
LBB1_103:                               ; %copy.continue266.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #4720]                 ; 16-byte Reload
	ldr	q5, [sp, #3328]                 ; 16-byte Reload
	bit.16b	v3, v5, v10
	str	q3, [sp, #4720]                 ; 16-byte Spill
Lloh326:
	adrp	x9, lCPI1_74@PAGE
Lloh327:
	ldr	q3, [x9, lCPI1_74@PAGEOFF]
	ldr	q5, [sp, #4656]                 ; 16-byte Reload
	bit.16b	v5, v3, v10
	str	q5, [sp, #4656]                 ; 16-byte Spill
	fmov	x12, d2
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #4
	fmov	d6, x12
	mov.d	x12, v2[1]
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #4
	mov.d	v6[1], x12
	cbz	w27, LBB1_106
; %bb.104:                              ; %copy.active267.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	q2, [sp, #4720]                 ; 16-byte Reload
	fmov	x13, d2
	ldr	q2, [sp, #4656]                 ; 16-byte Reload
	fmov	x14, d2
	add	x13, x13, x14
	fmov	x14, d6
	add	x14, x15, x14, lsl #2
LBB1_105:                               ; %copy.chunk.i579.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q2, [x14, x12]
	str	q2, [x13, x12]
	add	x12, x12, #16
	cmp	x12, #3072
	b.ne	LBB1_105
LBB1_106:                               ; %copy.continue268.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	w9, [sp, #4284]                 ; 4-byte Reload
	ldr	q7, [sp, #4000]                 ; 16-byte Reload
	cbz	w9, LBB1_130
; %bb.107:                              ; %copy.active269.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	q2, [sp, #4720]                 ; 16-byte Reload
	mov.d	x13, v2[1]
	ldr	q2, [sp, #4656]                 ; 16-byte Reload
	mov.d	x14, v2[1]
	add	x13, x13, x14
	mov.d	x14, v6[1]
	add	x14, x15, x14, lsl #2
LBB1_108:                               ; %copy.chunk.i583.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q2, [x14, x12]
	str	q2, [x13, x12]
	add	x12, x12, #16
	cmp	x12, #3072
	b.ne	LBB1_108
	b	LBB1_130
LBB1_109:                               ; %direct.schedule.7.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	sshll.2d	v3, v1, #0
	sshll.2d	v5, v0, #0
	ldr	q6, [sp, #4720]                 ; 16-byte Reload
	ldr	q7, [sp, #3328]                 ; 16-byte Reload
	bit.16b	v6, v7, v10
	str	q6, [sp, #4720]                 ; 16-byte Spill
	ldr	q6, [sp, #4752]                 ; 16-byte Reload
	bit.16b	v6, v7, v28
	str	q6, [sp, #4752]                 ; 16-byte Spill
	ldr	q6, [sp, #4736]                 ; 16-byte Reload
	bit.16b	v6, v7, v5
	str	q6, [sp, #4736]                 ; 16-byte Spill
	ldr	q6, [sp, #4768]                 ; 16-byte Reload
	bit.16b	v6, v7, v3
	str	q6, [sp, #4768]                 ; 16-byte Spill
Lloh328:
	adrp	x9, lCPI1_74@PAGE
Lloh329:
	ldr	q6, [x9, lCPI1_74@PAGEOFF]
	ldr	q7, [sp, #4656]                 ; 16-byte Reload
	bit.16b	v7, v6, v10
	str	q7, [sp, #4656]                 ; 16-byte Spill
Lloh330:
	adrp	x9, lCPI1_75@PAGE
Lloh331:
	ldr	q6, [x9, lCPI1_75@PAGEOFF]
	ldr	q7, [sp, #4688]                 ; 16-byte Reload
	bit.16b	v7, v6, v28
	str	q7, [sp, #4688]                 ; 16-byte Spill
Lloh332:
	adrp	x9, lCPI1_76@PAGE
Lloh333:
	ldr	q6, [x9, lCPI1_76@PAGEOFF]
	ldr	q7, [sp, #4672]                 ; 16-byte Reload
	bit.16b	v7, v6, v5
	str	q7, [sp, #4672]                 ; 16-byte Spill
Lloh334:
	adrp	x9, lCPI1_77@PAGE
Lloh335:
	ldr	q5, [x9, lCPI1_77@PAGEOFF]
	ldr	q6, [sp, #4704]                 ; 16-byte Reload
	bit.16b	v6, v5, v3
	str	q6, [sp, #4704]                 ; 16-byte Spill
	ldr	x17, [sp, #2568]                ; 8-byte Reload
	ldr	q27, [sp, #448]                 ; 16-byte Reload
	b	LBB1_111
LBB1_110:                               ; %else616
                                        ;   in Loop: Header=BB1_111 Depth=3
	str	q16, [sp, #4848]                ; 16-byte Spill
	add.2d	v3, v7, v21
	add.2d	v5, v7, v22
	add.2d	v7, v7, v24
	mov.d	x14, v7[1]
	fmov	x15, d7
	add	x15, x15, x15, lsl #1
	lsl	x15, x15, #4
	fmov	d7, x15
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #4
	mov.d	v7[1], x14
	mov.d	x14, v5[1]
	fmov	x15, d5
	add	x15, x15, x15, lsl #1
	lsl	x15, x15, #4
	fmov	d5, x15
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #4
	mov.d	v5[1], x14
	mov.d	x14, v3[1]
	fmov	x15, d3
	add	x15, x15, x15, lsl #1
	lsl	x15, x15, #4
	fmov	d3, x15
	sshll.2d	v16, v0, #0
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #4
	mov.d	v3[1], x14
	add.2d	v3, v3, v6
	add.2d	v5, v5, v6
	add.2d	v6, v7, v6
	ldr	q7, [sp, #4784]                 ; 16-byte Reload
	bit.16b	v7, v6, v10
	str	q7, [sp, #4784]                 ; 16-byte Spill
	ldr	q6, [sp, #4800]                 ; 16-byte Reload
	bit.16b	v6, v5, v16
	str	q6, [sp, #4800]                 ; 16-byte Spill
	ldr	q5, [sp, #4816]                 ; 16-byte Reload
	bit.16b	v5, v3, v28
	str	q5, [sp, #4816]                 ; 16-byte Spill
	add	x13, x13, #1
	add	x12, x12, #4
	cmp	x13, #768
	b.eq	LBB1_129
LBB1_111:                               ; %direct.true854.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	w9, w13, #0xffff
	mul	w9, w9, w23
	lsr	w9, w9, #21
	orr	w14, w9, #0x80
	dup.2d	v7, x14
	add.2d	v3, v7, v9
	mov.d	x14, v3[1]
	fmov	x15, d3
	add	x15, x15, x15, lsl #1
	lsl	x15, x15, #4
	fmov	d3, x15
	sshll.2d	v5, v1, #0
	msub	w9, w9, w28, w13
	and	x9, x9, #0xffff
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #4
	mov.d	v3[1], x14
	dup.2d	v6, x9
	add.2d	v3, v3, v6
	ldr	q16, [sp, #4832]                ; 16-byte Reload
	bif.16b	v3, v16, v5
	movi.2d	v16, #0000000000000000
	cmp	x13, #47
	b.hi	LBB1_113
; %bb.112:                              ; %direct.true867.i.i
                                        ;   in Loop: Header=BB1_111 Depth=3
	fmov	x9, d3
	add	x9, x17, x9, lsl #2
	ld1r.4s	{ v16 }, [x9]
LBB1_113:                               ; %direct.schedule.83.i.i
                                        ;   in Loop: Header=BB1_111 Depth=3
	str	q3, [sp, #4832]                 ; 16-byte Spill
	fmov	w14, s2
	ldr	q5, [sp, #4864]                 ; 16-byte Reload
	bit.16b	v5, v16, v1
	dup.2d	v19, x12
	ldr	q3, [sp, #4768]                 ; 16-byte Reload
	ldr	q12, [sp, #4704]                ; 16-byte Reload
	add.2d	v3, v3, v12
	add.2d	v3, v3, v19
	tbnz	w14, #0, LBB1_122
; %bb.114:                              ; %else
                                        ;   in Loop: Header=BB1_111 Depth=3
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB1_123
LBB1_115:                               ; %else604
                                        ;   in Loop: Header=BB1_111 Depth=3
	ldr	q3, [sp, #4752]                 ; 16-byte Reload
	ldr	q12, [sp, #4688]                ; 16-byte Reload
	add.2d	v3, v3, v12
	add.2d	v3, v3, v19
	tbnz	w14, #2, LBB1_124
LBB1_116:                               ; %else606
                                        ;   in Loop: Header=BB1_111 Depth=3
	tbz	w14, #3, LBB1_118
LBB1_117:                               ; %cond.store607
                                        ;   in Loop: Header=BB1_111 Depth=3
	mov.d	x15, v3[1]
	st1.s	{ v5 }[3], [x15]
LBB1_118:                               ; %else608
                                        ;   in Loop: Header=BB1_111 Depth=3
	ldr	q3, [sp, #4848]                 ; 16-byte Reload
	bif.16b	v16, v3, v0
	ldr	q3, [sp, #4736]                 ; 16-byte Reload
	ldr	q12, [sp, #4672]                ; 16-byte Reload
	add.2d	v3, v3, v12
	add.2d	v3, v3, v19
	tbnz	w14, #4, LBB1_125
; %bb.119:                              ; %else610
                                        ;   in Loop: Header=BB1_111 Depth=3
	tbnz	w14, #5, LBB1_126
LBB1_120:                               ; %else612
                                        ;   in Loop: Header=BB1_111 Depth=3
	ldr	q3, [sp, #4720]                 ; 16-byte Reload
	ldr	q12, [sp, #4656]                ; 16-byte Reload
	add.2d	v3, v3, v12
	add.2d	v3, v3, v19
	tbnz	w14, #6, LBB1_127
LBB1_121:                               ; %else614
                                        ;   in Loop: Header=BB1_111 Depth=3
	str	q5, [sp, #4864]                 ; 16-byte Spill
	ldr	q19, [sp, #4512]                ; 16-byte Reload
	tbz	w14, #7, LBB1_110
	b	LBB1_128
LBB1_122:                               ; %cond.store
                                        ;   in Loop: Header=BB1_111 Depth=3
	fmov	x15, d3
	str	s5, [x15]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB1_115
LBB1_123:                               ; %cond.store603
                                        ;   in Loop: Header=BB1_111 Depth=3
	mov.d	x15, v3[1]
	st1.s	{ v5 }[1], [x15]
	ldr	q3, [sp, #4752]                 ; 16-byte Reload
	ldr	q12, [sp, #4688]                ; 16-byte Reload
	add.2d	v3, v3, v12
	add.2d	v3, v3, v19
	tbz	w14, #2, LBB1_116
LBB1_124:                               ; %cond.store605
                                        ;   in Loop: Header=BB1_111 Depth=3
	fmov	x15, d3
	st1.s	{ v5 }[2], [x15]
	tbnz	w14, #3, LBB1_117
	b	LBB1_118
LBB1_125:                               ; %cond.store609
                                        ;   in Loop: Header=BB1_111 Depth=3
	fmov	x15, d3
	str	s16, [x15]
	tbz	w14, #5, LBB1_120
LBB1_126:                               ; %cond.store611
                                        ;   in Loop: Header=BB1_111 Depth=3
	mov.d	x15, v3[1]
	st1.s	{ v16 }[1], [x15]
	ldr	q3, [sp, #4720]                 ; 16-byte Reload
	ldr	q12, [sp, #4656]                ; 16-byte Reload
	add.2d	v3, v3, v12
	add.2d	v3, v3, v19
	tbz	w14, #6, LBB1_121
LBB1_127:                               ; %cond.store613
                                        ;   in Loop: Header=BB1_111 Depth=3
	fmov	x15, d3
	st1.s	{ v16 }[2], [x15]
	str	q5, [sp, #4864]                 ; 16-byte Spill
	ldr	q19, [sp, #4512]                ; 16-byte Reload
	tbz	w14, #7, LBB1_110
LBB1_128:                               ; %cond.store615
                                        ;   in Loop: Header=BB1_111 Depth=3
	mov.d	x14, v3[1]
	st1.s	{ v16 }[3], [x14]
	b	LBB1_110
LBB1_129:                               ;   in Loop: Header=BB1_40 Depth=2
	ldr	q21, [sp, #3088]                ; 16-byte Reload
	ldr	q24, [sp, #3072]                ; 16-byte Reload
	ldr	q7, [sp, #4000]                 ; 16-byte Reload
	ldr	q16, [sp, #3984]                ; 16-byte Reload
LBB1_130:                               ; %direct.schedule.9.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	sshll.2d	v2, v1, #0
	sshll.2d	v3, v0, #0
	ldr	q5, [sp, #2528]                 ; 16-byte Reload
	bit.16b	v16, v5, v10
	bit.16b	v24, v5, v28
	bit.16b	v7, v5, v3
	bit.16b	v21, v5, v2
Lloh336:
	adrp	x9, lCPI1_79@PAGE
Lloh337:
	ldr	q12, [x9, lCPI1_79@PAGEOFF]
	ldr	q5, [sp, #5264]                 ; 16-byte Reload
	bit.16b	v5, v12, v10
	str	q5, [sp, #5264]                 ; 16-byte Spill
Lloh338:
	adrp	x9, lCPI1_80@PAGE
Lloh339:
	ldr	q5, [x9, lCPI1_80@PAGEOFF]
	str	q5, [sp, #3632]                 ; 16-byte Spill
	bit.16b	v19, v5, v28
Lloh340:
	adrp	x9, lCPI1_81@PAGE
Lloh341:
	ldr	q6, [x9, lCPI1_81@PAGEOFF]
	ldr	q5, [sp, #5280]                 ; 16-byte Reload
	str	q6, [sp, #3616]                 ; 16-byte Spill
	bit.16b	v5, v6, v3
	str	q5, [sp, #5280]                 ; 16-byte Spill
Lloh342:
	adrp	x9, lCPI1_82@PAGE
Lloh343:
	ldr	q3, [x9, lCPI1_82@PAGEOFF]
	ldr	q5, [sp, #3968]                 ; 16-byte Reload
	str	q3, [sp, #3600]                 ; 16-byte Spill
	bit.16b	v5, v3, v2
	mov	w9, #1                          ; =0x1
	b	LBB1_132
LBB1_131:                               ; %else674
                                        ;   in Loop: Header=BB1_132 Depth=3
	add	x12, x12, #4
	cmp	x12, #512
	b.eq	LBB1_148
LBB1_132:                               ; %direct.true272.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	uzp1.8h	v2, v1, v0
	ldr	q3, [x25, lCPI1_78@PAGEOFF]
	and.16b	v2, v2, v3
	addv.8h	h2, v2
	fmov	w13, s2
	dup.2d	v6, x12
	orr.16b	v3, v6, v5
	add.2d	v3, v21, v3
	tbnz	w13, #0, LBB1_140
; %bb.133:                              ; %else653
                                        ;   in Loop: Header=BB1_132 Depth=3
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_141
LBB1_134:                               ; %else656
                                        ;   in Loop: Header=BB1_132 Depth=3
	orr.16b	v3, v6, v19
	add.2d	v3, v24, v3
	tbnz	w13, #2, LBB1_142
LBB1_135:                               ; %else659
                                        ;   in Loop: Header=BB1_132 Depth=3
	tbnz	w13, #3, LBB1_143
LBB1_136:                               ; %else662
                                        ;   in Loop: Header=BB1_132 Depth=3
	ldr	q3, [sp, #5280]                 ; 16-byte Reload
	orr.16b	v3, v6, v3
	add.2d	v3, v7, v3
	tbnz	w13, #4, LBB1_144
LBB1_137:                               ; %else665
                                        ;   in Loop: Header=BB1_132 Depth=3
	tbnz	w13, #5, LBB1_145
LBB1_138:                               ; %else668
                                        ;   in Loop: Header=BB1_132 Depth=3
	ldr	q3, [sp, #5264]                 ; 16-byte Reload
	orr.16b	v3, v6, v3
	add.2d	v3, v16, v3
	tbnz	w13, #6, LBB1_146
LBB1_139:                               ; %else671
                                        ;   in Loop: Header=BB1_132 Depth=3
	tbz	w13, #7, LBB1_131
	b	LBB1_147
LBB1_140:                               ; %cond.store651
                                        ;   in Loop: Header=BB1_132 Depth=3
	fmov	x14, d3
	str	wzr, [x14]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_134
LBB1_141:                               ; %cond.store654
                                        ;   in Loop: Header=BB1_132 Depth=3
	mov.d	x14, v3[1]
	str	wzr, [x14]
	orr.16b	v3, v6, v19
	add.2d	v3, v24, v3
	tbz	w13, #2, LBB1_135
LBB1_142:                               ; %cond.store657
                                        ;   in Loop: Header=BB1_132 Depth=3
	fmov	x14, d3
	str	wzr, [x14]
	tbz	w13, #3, LBB1_136
LBB1_143:                               ; %cond.store660
                                        ;   in Loop: Header=BB1_132 Depth=3
	mov.d	x14, v3[1]
	str	wzr, [x14]
	ldr	q3, [sp, #5280]                 ; 16-byte Reload
	orr.16b	v3, v6, v3
	add.2d	v3, v7, v3
	tbz	w13, #4, LBB1_137
LBB1_144:                               ; %cond.store663
                                        ;   in Loop: Header=BB1_132 Depth=3
	fmov	x14, d3
	str	wzr, [x14]
	tbz	w13, #5, LBB1_138
LBB1_145:                               ; %cond.store666
                                        ;   in Loop: Header=BB1_132 Depth=3
	mov.d	x14, v3[1]
	str	wzr, [x14]
	ldr	q3, [sp, #5264]                 ; 16-byte Reload
	orr.16b	v3, v6, v3
	add.2d	v3, v16, v3
	tbz	w13, #6, LBB1_139
LBB1_146:                               ; %cond.store669
                                        ;   in Loop: Header=BB1_132 Depth=3
	fmov	x14, d3
	str	wzr, [x14]
	tbz	w13, #7, LBB1_131
LBB1_147:                               ; %cond.store672
                                        ;   in Loop: Header=BB1_132 Depth=3
	mov.d	x13, v3[1]
	str	wzr, [x13]
	b	LBB1_131
LBB1_148:                               ; %direct.false273.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	str	q5, [sp, #3968]                 ; 16-byte Spill
	str	q16, [sp, #3984]                ; 16-byte Spill
	str	q7, [sp, #4000]                 ; 16-byte Spill
	tbz	w2, #0, LBB1_151
; %bb.149:                              ; %mma.active.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	ldr	q3, [sp, #4640]                 ; 16-byte Reload
	fmov	x14, d3
	ldr	q3, [sp, #4576]                 ; 16-byte Reload
	fmov	x15, d3
	add	x14, x14, x15
	fmov	x15, d21
	ldr	q3, [sp, #3968]                 ; 16-byte Reload
	fmov	x17, d3
	add	x15, x15, x17
	add	x17, x30, #19, lsl #12          ; =77824
LBB1_150:                               ; %mma.update.i.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	x0, x13, #0xe0
	and	x1, x12, #0x1e0
	add	x0, x3, x0, lsl #2
	add	x1, x14, x1, lsl #2
	ldp	q3, q5, [x0]
	ldp	q6, q7, [x1]
	fmul.4s	v3, v3, v6
	fmul.4s	v5, v5, v7
	fadd.4s	v3, v3, v5
	ldp	q5, q6, [x0, #32]
	ldp	q7, q16, [x1, #32]
	fmul.4s	v5, v5, v7
	fadd.4s	v3, v3, v5
	fmul.4s	v5, v6, v16
	fadd.4s	v3, v3, v5
	ldp	q5, q16, [x1, #64]
	ldp	q6, q7, [x0, #64]
	fmul.4s	v5, v6, v5
	fadd.4s	v3, v3, v5
	fmul.4s	v5, v7, v16
	fadd.4s	v3, v3, v5
	ldp	q6, q5, [x0, #96]
	ldp	q7, q16, [x1, #96]
	fmul.4s	v6, v6, v7
	ldr	s7, [x15], #4
	fadd.4s	v3, v3, v6
	fmul.4s	v5, v5, v16
	fadd.4s	v3, v3, v5
	dup.4s	v5, v3[1]
	fadd.4s	v5, v3, v5
	dup.4s	v6, v3[3]
	fadd.4s	v3, v3, v6
	dup.4s	v3, v3[2]
	fadd.4s	v3, v5, v3
	fadd	s3, s7, s3
	str	s3, [x17], #4
	add	x13, x13, #2
	add	x12, x12, #32
	cmp	x13, #256
	b.ne	LBB1_150
LBB1_151:                               ; %mma.continue.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	x2, [sp, #832]                  ; 8-byte Reload
	cbz	w7, LBB1_154
; %bb.152:                              ; %mma.active282.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	ldr	q3, [sp, #4640]                 ; 16-byte Reload
	mov.d	x14, v3[1]
	ldr	q3, [sp, #4576]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	add	x14, x14, x15
	mov.d	x15, v21[1]
	ldr	q3, [sp, #3968]                 ; 16-byte Reload
	mov.d	x17, v3[1]
	add	x15, x15, x17
	ldr	x17, [sp, #304]                 ; 8-byte Reload
LBB1_153:                               ; %mma.update.i588.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	x0, x13, #0xe0
	and	x1, x12, #0x1e0
	add	x0, x2, x0, lsl #2
	add	x1, x14, x1, lsl #2
	ldp	q3, q5, [x0]
	ldp	q6, q7, [x1]
	fmul.4s	v3, v3, v6
	fmul.4s	v5, v5, v7
	fadd.4s	v3, v3, v5
	ldp	q5, q6, [x0, #32]
	ldp	q7, q16, [x1, #32]
	fmul.4s	v5, v5, v7
	fadd.4s	v3, v3, v5
	fmul.4s	v5, v6, v16
	fadd.4s	v3, v3, v5
	ldp	q5, q16, [x1, #64]
	ldp	q6, q7, [x0, #64]
	fmul.4s	v5, v6, v5
	fadd.4s	v3, v3, v5
	fmul.4s	v5, v7, v16
	fadd.4s	v3, v3, v5
	ldp	q6, q5, [x0, #96]
	ldp	q7, q16, [x1, #96]
	fmul.4s	v6, v6, v7
	ldr	s7, [x15], #4
	fadd.4s	v3, v3, v6
	fmul.4s	v5, v5, v16
	fadd.4s	v3, v3, v5
	dup.4s	v5, v3[1]
	fadd.4s	v5, v3, v5
	dup.4s	v6, v3[3]
	fadd.4s	v3, v3, v6
	dup.4s	v3, v3[2]
	fadd.4s	v3, v5, v3
	fadd	s3, s7, s3
	str	s3, [x17], #4
	add	x13, x13, #2
	add	x12, x12, #32
	cmp	x13, #256
	b.ne	LBB1_153
LBB1_154:                               ; %mma.continue283.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	x2, [sp, #824]                  ; 8-byte Reload
	cbz	w20, LBB1_157
; %bb.155:                              ; %mma.active284.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	ldr	q3, [sp, #4624]                 ; 16-byte Reload
	fmov	x14, d3
	ldr	q3, [sp, #4560]                 ; 16-byte Reload
	fmov	x15, d3
	add	x14, x14, x15
	fmov	x15, d24
	fmov	x17, d19
	add	x15, x15, x17
	ldr	x17, [sp, #296]                 ; 8-byte Reload
LBB1_156:                               ; %mma.update.i592.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	x0, x13, #0xe0
	and	x1, x12, #0x1e0
	add	x0, x2, x0, lsl #2
	add	x1, x14, x1, lsl #2
	ldp	q3, q5, [x0]
	ldp	q6, q7, [x1]
	fmul.4s	v3, v3, v6
	fmul.4s	v5, v5, v7
	fadd.4s	v3, v3, v5
	ldp	q5, q6, [x0, #32]
	ldp	q7, q16, [x1, #32]
	fmul.4s	v5, v5, v7
	fadd.4s	v3, v3, v5
	fmul.4s	v5, v6, v16
	fadd.4s	v3, v3, v5
	ldp	q5, q16, [x1, #64]
	ldp	q6, q7, [x0, #64]
	fmul.4s	v5, v6, v5
	fadd.4s	v3, v3, v5
	fmul.4s	v5, v7, v16
	fadd.4s	v3, v3, v5
	ldp	q6, q5, [x0, #96]
	ldp	q7, q16, [x1, #96]
	fmul.4s	v6, v6, v7
	ldr	s7, [x15], #4
	fadd.4s	v3, v3, v6
	fmul.4s	v5, v5, v16
	fadd.4s	v3, v3, v5
	dup.4s	v5, v3[1]
	fadd.4s	v5, v3, v5
	dup.4s	v6, v3[3]
	fadd.4s	v3, v3, v6
	dup.4s	v3, v3[2]
	fadd.4s	v3, v5, v3
	fadd	s3, s7, s3
	str	s3, [x17], #4
	add	x13, x13, #2
	add	x12, x12, #32
	cmp	x13, #256
	b.ne	LBB1_156
LBB1_157:                               ; %mma.continue285.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	x2, [sp, #816]                  ; 8-byte Reload
	cbz	w22, LBB1_160
; %bb.158:                              ; %mma.active286.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	ldr	q3, [sp, #4624]                 ; 16-byte Reload
	mov.d	x14, v3[1]
	ldr	q3, [sp, #4560]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	add	x14, x14, x15
	mov.d	x15, v24[1]
	mov.d	x17, v19[1]
	add	x15, x15, x17
	ldr	x17, [sp, #288]                 ; 8-byte Reload
LBB1_159:                               ; %mma.update.i596.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	x0, x13, #0xe0
	and	x1, x12, #0x1e0
	add	x0, x2, x0, lsl #2
	add	x1, x14, x1, lsl #2
	ldp	q3, q5, [x0]
	ldp	q6, q7, [x1]
	fmul.4s	v3, v3, v6
	fmul.4s	v5, v5, v7
	fadd.4s	v3, v3, v5
	ldp	q5, q6, [x0, #32]
	ldp	q7, q16, [x1, #32]
	fmul.4s	v5, v5, v7
	fadd.4s	v3, v3, v5
	fmul.4s	v5, v6, v16
	fadd.4s	v3, v3, v5
	ldp	q5, q16, [x1, #64]
	ldp	q6, q7, [x0, #64]
	fmul.4s	v5, v6, v5
	fadd.4s	v3, v3, v5
	fmul.4s	v5, v7, v16
	fadd.4s	v3, v3, v5
	ldp	q6, q5, [x0, #96]
	ldp	q7, q16, [x1, #96]
	fmul.4s	v6, v6, v7
	ldr	s7, [x15], #4
	fadd.4s	v3, v3, v6
	fmul.4s	v5, v5, v16
	fadd.4s	v3, v3, v5
	dup.4s	v5, v3[1]
	fadd.4s	v5, v3, v5
	dup.4s	v6, v3[3]
	fadd.4s	v3, v3, v6
	dup.4s	v3, v3[2]
	fadd.4s	v3, v5, v3
	fadd	s3, s7, s3
	str	s3, [x17], #4
	add	x13, x13, #2
	add	x12, x12, #32
	cmp	x13, #256
	b.ne	LBB1_159
LBB1_160:                               ; %mma.continue287.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	x2, [sp, #808]                  ; 8-byte Reload
	cbz	w24, LBB1_163
; %bb.161:                              ; %mma.active288.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	ldr	q3, [sp, #4608]                 ; 16-byte Reload
	fmov	x14, d3
	ldr	q3, [sp, #4544]                 ; 16-byte Reload
	fmov	x15, d3
	add	x14, x14, x15
	ldr	q3, [sp, #4000]                 ; 16-byte Reload
	fmov	x15, d3
	ldr	q3, [sp, #5280]                 ; 16-byte Reload
	fmov	x17, d3
	add	x15, x15, x17
	ldr	x17, [sp, #280]                 ; 8-byte Reload
LBB1_162:                               ; %mma.update.i600.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	x0, x13, #0xe0
	and	x1, x12, #0x1e0
	add	x0, x2, x0, lsl #2
	add	x1, x14, x1, lsl #2
	ldp	q3, q5, [x0]
	ldp	q6, q7, [x1]
	fmul.4s	v3, v3, v6
	fmul.4s	v5, v5, v7
	fadd.4s	v3, v3, v5
	ldp	q5, q6, [x0, #32]
	ldp	q7, q16, [x1, #32]
	fmul.4s	v5, v5, v7
	fadd.4s	v3, v3, v5
	fmul.4s	v5, v6, v16
	fadd.4s	v3, v3, v5
	ldp	q5, q16, [x1, #64]
	ldp	q6, q7, [x0, #64]
	fmul.4s	v5, v6, v5
	fadd.4s	v3, v3, v5
	fmul.4s	v5, v7, v16
	fadd.4s	v3, v3, v5
	ldp	q6, q5, [x0, #96]
	ldp	q7, q16, [x1, #96]
	fmul.4s	v6, v6, v7
	ldr	s7, [x15], #4
	fadd.4s	v3, v3, v6
	fmul.4s	v5, v5, v16
	fadd.4s	v3, v3, v5
	dup.4s	v5, v3[1]
	fadd.4s	v5, v3, v5
	dup.4s	v6, v3[3]
	fadd.4s	v3, v3, v6
	dup.4s	v3, v3[2]
	fadd.4s	v3, v5, v3
	fadd	s3, s7, s3
	str	s3, [x17], #4
	add	x13, x13, #2
	add	x12, x12, #32
	cmp	x13, #256
	b.ne	LBB1_162
LBB1_163:                               ; %mma.continue289.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	x2, [sp, #800]                  ; 8-byte Reload
	cbz	w26, LBB1_166
; %bb.164:                              ; %mma.active290.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	ldr	q3, [sp, #4608]                 ; 16-byte Reload
	mov.d	x14, v3[1]
	ldr	q3, [sp, #4544]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	add	x14, x14, x15
	ldr	q3, [sp, #4000]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	ldr	q3, [sp, #5280]                 ; 16-byte Reload
	mov.d	x17, v3[1]
	add	x15, x15, x17
	ldr	x17, [sp, #272]                 ; 8-byte Reload
LBB1_165:                               ; %mma.update.i604.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	x0, x13, #0xe0
	and	x1, x12, #0x1e0
	add	x0, x2, x0, lsl #2
	add	x1, x14, x1, lsl #2
	ldp	q3, q5, [x0]
	ldp	q6, q7, [x1]
	fmul.4s	v3, v3, v6
	fmul.4s	v5, v5, v7
	fadd.4s	v3, v3, v5
	ldp	q5, q6, [x0, #32]
	ldp	q7, q16, [x1, #32]
	fmul.4s	v5, v5, v7
	fadd.4s	v3, v3, v5
	fmul.4s	v5, v6, v16
	fadd.4s	v3, v3, v5
	ldp	q5, q16, [x1, #64]
	ldp	q6, q7, [x0, #64]
	fmul.4s	v5, v6, v5
	fadd.4s	v3, v3, v5
	fmul.4s	v5, v7, v16
	fadd.4s	v3, v3, v5
	ldp	q6, q5, [x0, #96]
	ldp	q7, q16, [x1, #96]
	fmul.4s	v6, v6, v7
	ldr	s7, [x15], #4
	fadd.4s	v3, v3, v6
	fmul.4s	v5, v5, v16
	fadd.4s	v3, v3, v5
	dup.4s	v5, v3[1]
	fadd.4s	v5, v3, v5
	dup.4s	v6, v3[3]
	fadd.4s	v3, v3, v6
	dup.4s	v3, v3[2]
	fadd.4s	v3, v5, v3
	fadd	s3, s7, s3
	str	s3, [x17], #4
	add	x13, x13, #2
	add	x12, x12, #32
	cmp	x13, #256
	b.ne	LBB1_165
LBB1_166:                               ; %mma.continue291.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	cbz	w27, LBB1_169
; %bb.167:                              ; %mma.active292.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	ldr	q3, [sp, #4592]                 ; 16-byte Reload
	fmov	x14, d3
	ldr	q3, [sp, #4528]                 ; 16-byte Reload
	fmov	x15, d3
	add	x14, x14, x15
	ldr	q3, [sp, #3984]                 ; 16-byte Reload
	fmov	x15, d3
	ldr	q3, [sp, #5264]                 ; 16-byte Reload
	fmov	x17, d3
	add	x15, x15, x17
	ldr	x17, [sp, #264]                 ; 8-byte Reload
LBB1_168:                               ; %mma.update.i608.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	x0, x13, #0xe0
	and	x1, x12, #0x1e0
	add	x0, x10, x0, lsl #2
	add	x1, x14, x1, lsl #2
	ldp	q3, q5, [x0]
	ldp	q6, q7, [x1]
	fmul.4s	v3, v3, v6
	fmul.4s	v5, v5, v7
	fadd.4s	v3, v3, v5
	ldp	q5, q6, [x0, #32]
	ldp	q7, q16, [x1, #32]
	fmul.4s	v5, v5, v7
	fadd.4s	v3, v3, v5
	fmul.4s	v5, v6, v16
	fadd.4s	v3, v3, v5
	ldp	q5, q16, [x1, #64]
	ldp	q6, q7, [x0, #64]
	fmul.4s	v5, v6, v5
	fadd.4s	v3, v3, v5
	fmul.4s	v5, v7, v16
	fadd.4s	v3, v3, v5
	ldp	q6, q5, [x0, #96]
	ldp	q7, q16, [x1, #96]
	fmul.4s	v6, v6, v7
	ldr	s7, [x15], #4
	fadd.4s	v3, v3, v6
	fmul.4s	v5, v5, v16
	fadd.4s	v3, v3, v5
	dup.4s	v5, v3[1]
	fadd.4s	v5, v3, v5
	dup.4s	v6, v3[3]
	fadd.4s	v3, v3, v6
	dup.4s	v3, v3[2]
	fadd.4s	v3, v5, v3
	fadd	s3, s7, s3
	str	s3, [x17], #4
	add	x13, x13, #2
	add	x12, x12, #32
	cmp	x13, #256
	b.ne	LBB1_168
LBB1_169:                               ; %mma.continue293.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	w12, [sp, #4284]                ; 4-byte Reload
	cbz	w12, LBB1_172
; %bb.170:                              ; %mma.active294.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	ldr	q3, [sp, #4592]                 ; 16-byte Reload
	mov.d	x14, v3[1]
	ldr	q3, [sp, #4528]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	add	x14, x14, x15
	ldr	q3, [sp, #3984]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	ldr	q3, [sp, #5264]                 ; 16-byte Reload
	mov.d	x17, v3[1]
	add	x15, x15, x17
	ldr	x17, [sp, #256]                 ; 8-byte Reload
LBB1_171:                               ; %mma.update.i612.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	x0, x13, #0xe0
	and	x1, x12, #0x1e0
	add	x0, x16, x0, lsl #2
	add	x1, x14, x1, lsl #2
	ldp	q3, q5, [x0]
	ldp	q6, q7, [x1]
	fmul.4s	v3, v3, v6
	fmul.4s	v5, v5, v7
	fadd.4s	v3, v3, v5
	ldp	q5, q6, [x0, #32]
	ldp	q7, q16, [x1, #32]
	fmul.4s	v5, v5, v7
	fadd.4s	v3, v3, v5
	fmul.4s	v5, v6, v16
	fadd.4s	v3, v3, v5
	ldp	q5, q16, [x1, #64]
	ldp	q6, q7, [x0, #64]
	fmul.4s	v5, v6, v5
	fadd.4s	v3, v3, v5
	fmul.4s	v5, v7, v16
	fadd.4s	v3, v3, v5
	ldp	q6, q5, [x0, #96]
	ldp	q7, q16, [x1, #96]
	fmul.4s	v6, v6, v7
	ldr	s7, [x15], #4
	fadd.4s	v3, v3, v6
	fmul.4s	v5, v5, v16
	fadd.4s	v3, v3, v5
	dup.4s	v5, v3[1]
	fadd.4s	v5, v3, v5
	dup.4s	v6, v3[3]
	fadd.4s	v3, v3, v6
	dup.4s	v3, v3[2]
	fadd.4s	v3, v5, v3
	fadd	s3, s7, s3
	str	s3, [x17], #4
	add	x13, x13, #2
	add	x12, x12, #32
	cmp	x13, #256
	b.ne	LBB1_171
LBB1_172:                               ; %mma.continue295.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	fmov	w12, s2
	tbnz	w12, #0, LBB1_647
; %bb.173:                              ; %else678
                                        ;   in Loop: Header=BB1_40 Depth=2
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB1_648
LBB1_174:                               ; %else681
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #2, LBB1_649
LBB1_175:                               ; %else684
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #3, LBB1_650
LBB1_176:                               ; %else687
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #4, LBB1_651
LBB1_177:                               ; %else690
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #5, LBB1_652
LBB1_178:                               ; %else693
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #6, LBB1_653
LBB1_179:                               ; %else696
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #7, LBB1_654
LBB1_180:                               ; %else699
                                        ;   in Loop: Header=BB1_40 Depth=2
	orr	x22, x21, #0x1
	cmp	x22, #129
	cset	w13, lo
	fmov	w12, s2
	dup.8b	v6, w13
	tbnz	w12, #0, LBB1_655
LBB1_181:                               ; %else704
                                        ;   in Loop: Header=BB1_40 Depth=2
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB1_656
LBB1_182:                               ; %else708
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #2, LBB1_657
LBB1_183:                               ; %else712
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #3, LBB1_658
LBB1_184:                               ; %else716
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #4, LBB1_659
LBB1_185:                               ; %else720
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #5, LBB1_660
LBB1_186:                               ; %else724
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #6, LBB1_661
LBB1_187:                               ; %else728
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #7, LBB1_662
LBB1_188:                               ; %else732
                                        ;   in Loop: Header=BB1_40 Depth=2
	orr	x24, x21, #0x2
	cmp	x24, #129
	cset	w13, lo
	fmov	w12, s2
	dup.8b	v6, w13
	tbnz	w12, #0, LBB1_663
LBB1_189:                               ; %else737
                                        ;   in Loop: Header=BB1_40 Depth=2
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB1_664
LBB1_190:                               ; %else741
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #2, LBB1_665
LBB1_191:                               ; %else745
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #3, LBB1_666
LBB1_192:                               ; %else749
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #4, LBB1_667
LBB1_193:                               ; %else753
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #5, LBB1_668
LBB1_194:                               ; %else757
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #6, LBB1_669
LBB1_195:                               ; %else761
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #7, LBB1_670
LBB1_196:                               ; %else765
                                        ;   in Loop: Header=BB1_40 Depth=2
	orr	x27, x21, #0x3
	cmp	x27, #129
	cset	w13, lo
	fmov	w12, s2
	dup.8b	v6, w13
	tbnz	w12, #0, LBB1_671
LBB1_197:                               ; %else770
                                        ;   in Loop: Header=BB1_40 Depth=2
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB1_672
LBB1_198:                               ; %else774
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #2, LBB1_673
LBB1_199:                               ; %else778
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #3, LBB1_674
LBB1_200:                               ; %else782
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #4, LBB1_675
LBB1_201:                               ; %else786
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #5, LBB1_676
LBB1_202:                               ; %else790
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #6, LBB1_677
LBB1_203:                               ; %else794
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #7, LBB1_678
LBB1_204:                               ; %else798
                                        ;   in Loop: Header=BB1_40 Depth=2
	orr	x4, x21, #0x4
	cmp	x4, #129
	cset	w13, lo
	fmov	w12, s2
	dup.8b	v6, w13
	tbnz	w12, #0, LBB1_679
LBB1_205:                               ; %else803
                                        ;   in Loop: Header=BB1_40 Depth=2
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB1_680
LBB1_206:                               ; %else807
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #2, LBB1_681
LBB1_207:                               ; %else811
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #3, LBB1_682
LBB1_208:                               ; %else815
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #4, LBB1_683
LBB1_209:                               ; %else819
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #5, LBB1_684
LBB1_210:                               ; %else823
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #6, LBB1_685
LBB1_211:                               ; %else827
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbz	w12, #7, LBB1_213
LBB1_212:                               ; %cond.store828
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2176]                 ; 16-byte Reload
	mov.d	x12, v3[1]
	st1.b	{ v6 }[7], [x12]
LBB1_213:                               ; %else831
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	w9, #5                          ; =0x5
	orr	x5, x21, x9
	cmp	x5, #129
	cset	w13, lo
	fmov	w12, s2
	dup.8b	v6, w13
	tbnz	w12, #0, LBB1_686
; %bb.214:                              ; %else836
                                        ;   in Loop: Header=BB1_40 Depth=2
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB1_687
LBB1_215:                               ; %else840
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #2, LBB1_688
LBB1_216:                               ; %else844
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #3, LBB1_689
LBB1_217:                               ; %else848
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #4, LBB1_690
LBB1_218:                               ; %else852
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #5, LBB1_691
LBB1_219:                               ; %else856
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #6, LBB1_692
LBB1_220:                               ; %else860
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #7, LBB1_693
LBB1_221:                               ; %else864
                                        ;   in Loop: Header=BB1_40 Depth=2
	orr	x7, x21, #0x6
	cmp	x7, #129
	cset	w13, lo
	fmov	w12, s2
	dup.8b	v6, w13
	tbnz	w12, #0, LBB1_694
LBB1_222:                               ; %else869
                                        ;   in Loop: Header=BB1_40 Depth=2
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB1_695
LBB1_223:                               ; %else873
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #2, LBB1_696
LBB1_224:                               ; %else877
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #3, LBB1_697
LBB1_225:                               ; %else881
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #4, LBB1_698
LBB1_226:                               ; %else885
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #5, LBB1_699
LBB1_227:                               ; %else889
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #6, LBB1_700
LBB1_228:                               ; %else893
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x2, x30
	tbnz	w12, #7, LBB1_701
LBB1_229:                               ; %else897
                                        ;   in Loop: Header=BB1_40 Depth=2
	orr	x30, x21, #0x7
	cmp	x30, #129
	cset	w13, lo
	fmov	w12, s2
	dup.8b	v6, w13
	tbnz	w12, #0, LBB1_702
LBB1_230:                               ; %else902
                                        ;   in Loop: Header=BB1_40 Depth=2
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB1_703
LBB1_231:                               ; %else906
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #2, LBB1_704
LBB1_232:                               ; %else910
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #3, LBB1_705
LBB1_233:                               ; %else914
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #4, LBB1_706
LBB1_234:                               ; %else918
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #5, LBB1_707
LBB1_235:                               ; %else922
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #6, LBB1_708
LBB1_236:                               ; %else926
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #7, LBB1_709
LBB1_237:                               ; %else930
                                        ;   in Loop: Header=BB1_40 Depth=2
	orr	x13, x21, #0x8
	cmp	x13, #129
	cset	w14, lo
	fmov	w12, s2
	dup.8b	v6, w14
	tbnz	w12, #0, LBB1_710
LBB1_238:                               ; %else935
                                        ;   in Loop: Header=BB1_40 Depth=2
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB1_711
LBB1_239:                               ; %else939
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #2, LBB1_712
LBB1_240:                               ; %else943
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #3, LBB1_713
LBB1_241:                               ; %else947
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #4, LBB1_714
LBB1_242:                               ; %else951
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #5, LBB1_715
LBB1_243:                               ; %else955
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w12, #6, LBB1_716
LBB1_244:                               ; %else959
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbz	w12, #7, LBB1_246
LBB1_245:                               ; %cond.store960
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1888]                 ; 16-byte Reload
	mov.d	x12, v3[1]
	st1.b	{ v6 }[7], [x12]
LBB1_246:                               ; %else963
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	w9, #9                          ; =0x9
	orr	x12, x21, x9
	cmp	x12, #129
	cset	w15, lo
	fmov	w14, s2
	dup.8b	v6, w15
	tbnz	w14, #0, LBB1_717
; %bb.247:                              ; %else968
                                        ;   in Loop: Header=BB1_40 Depth=2
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB1_718
LBB1_248:                               ; %else972
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w14, #2, LBB1_719
LBB1_249:                               ; %else976
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w14, #3, LBB1_720
LBB1_250:                               ; %else980
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w14, #4, LBB1_721
LBB1_251:                               ; %else984
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w14, #5, LBB1_722
LBB1_252:                               ; %else988
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w14, #6, LBB1_723
LBB1_253:                               ; %else992
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbz	w14, #7, LBB1_255
LBB1_254:                               ; %cond.store993
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1824]                 ; 16-byte Reload
	mov.d	x14, v3[1]
	st1.b	{ v6 }[7], [x14]
LBB1_255:                               ; %else996
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	w9, #10                         ; =0xa
	orr	x17, x21, x9
	cmp	x17, #129
	cset	w15, lo
	fmov	w14, s2
	dup.8b	v6, w15
	tbnz	w14, #0, LBB1_724
; %bb.256:                              ; %else1001
                                        ;   in Loop: Header=BB1_40 Depth=2
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB1_725
LBB1_257:                               ; %else1005
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w14, #2, LBB1_726
LBB1_258:                               ; %else1009
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w14, #3, LBB1_727
LBB1_259:                               ; %else1013
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w14, #4, LBB1_728
LBB1_260:                               ; %else1017
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w14, #5, LBB1_729
LBB1_261:                               ; %else1021
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w14, #6, LBB1_730
LBB1_262:                               ; %else1025
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbz	w14, #7, LBB1_264
LBB1_263:                               ; %cond.store1026
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1760]                 ; 16-byte Reload
	mov.d	x14, v3[1]
	st1.b	{ v6 }[7], [x14]
LBB1_264:                               ; %else1029
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	w9, #11                         ; =0xb
	orr	x0, x21, x9
	cmp	x0, #129
	cset	w15, lo
	fmov	w14, s2
	dup.8b	v6, w15
	tbnz	w14, #0, LBB1_731
; %bb.265:                              ; %else1034
                                        ;   in Loop: Header=BB1_40 Depth=2
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB1_732
LBB1_266:                               ; %else1038
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w14, #2, LBB1_733
LBB1_267:                               ; %else1042
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w14, #3, LBB1_734
LBB1_268:                               ; %else1046
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w14, #4, LBB1_735
LBB1_269:                               ; %else1050
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w14, #5, LBB1_736
LBB1_270:                               ; %else1054
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w14, #6, LBB1_737
LBB1_271:                               ; %else1058
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w14, #7, LBB1_738
LBB1_272:                               ; %else1062
                                        ;   in Loop: Header=BB1_40 Depth=2
	orr	x14, x21, #0xc
	cmp	x14, #129
	cset	w1, lo
	fmov	w15, s2
	dup.8b	v6, w1
	tbnz	w15, #0, LBB1_739
LBB1_273:                               ; %else1067
                                        ;   in Loop: Header=BB1_40 Depth=2
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB1_740
LBB1_274:                               ; %else1071
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w15, #2, LBB1_741
LBB1_275:                               ; %else1075
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w15, #3, LBB1_742
LBB1_276:                               ; %else1079
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w15, #4, LBB1_743
LBB1_277:                               ; %else1083
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w15, #5, LBB1_744
LBB1_278:                               ; %else1087
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w15, #6, LBB1_745
LBB1_279:                               ; %else1091
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbz	w15, #7, LBB1_281
LBB1_280:                               ; %cond.store1092
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1632]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	st1.b	{ v6 }[7], [x15]
LBB1_281:                               ; %else1095
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	w9, #13                         ; =0xd
	orr	x3, x21, x9
	cmp	x3, #129
	cset	w1, lo
	fmov	w15, s2
	dup.8b	v6, w1
	tbnz	w15, #0, LBB1_746
; %bb.282:                              ; %else1100
                                        ;   in Loop: Header=BB1_40 Depth=2
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB1_747
LBB1_283:                               ; %else1104
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w15, #2, LBB1_748
LBB1_284:                               ; %else1108
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w15, #3, LBB1_749
LBB1_285:                               ; %else1112
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w15, #4, LBB1_750
LBB1_286:                               ; %else1116
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w15, #5, LBB1_751
LBB1_287:                               ; %else1120
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w15, #6, LBB1_752
LBB1_288:                               ; %else1124
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w15, #7, LBB1_753
LBB1_289:                               ; %else1128
                                        ;   in Loop: Header=BB1_40 Depth=2
	orr	x1, x21, #0xe
	cmp	x1, #129
	cset	w20, lo
	fmov	w15, s2
	dup.8b	v6, w20
	tbnz	w15, #0, LBB1_754
LBB1_290:                               ; %else1133
                                        ;   in Loop: Header=BB1_40 Depth=2
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB1_755
LBB1_291:                               ; %else1137
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w15, #2, LBB1_756
LBB1_292:                               ; %else1141
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w15, #3, LBB1_757
LBB1_293:                               ; %else1145
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w15, #4, LBB1_758
LBB1_294:                               ; %else1149
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w15, #5, LBB1_759
LBB1_295:                               ; %else1153
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w15, #6, LBB1_760
LBB1_296:                               ; %else1157
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w15, #7, LBB1_761
LBB1_297:                               ; %else1161
                                        ;   in Loop: Header=BB1_40 Depth=2
	orr	x15, x21, #0xf
	cmp	x15, #129
	cset	w21, lo
	fmov	w20, s2
	dup.8b	v6, w21
	tbnz	w20, #0, LBB1_762
LBB1_298:                               ; %else1166
                                        ;   in Loop: Header=BB1_40 Depth=2
	and	w20, w20, #0xff
	tbnz	w20, #1, LBB1_763
LBB1_299:                               ; %else1170
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w20, #2, LBB1_764
LBB1_300:                               ; %else1174
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w20, #3, LBB1_765
LBB1_301:                               ; %else1178
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w20, #4, LBB1_766
LBB1_302:                               ; %else1182
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbnz	w20, #5, LBB1_767
LBB1_303:                               ; %else1186
                                        ;   in Loop: Header=BB1_40 Depth=2
	str	q19, [sp, #4512]                ; 16-byte Spill
	str	q21, [sp, #3088]                ; 16-byte Spill
	tbnz	w20, #6, LBB1_768
LBB1_304:                               ; %else1190
                                        ;   in Loop: Header=BB1_40 Depth=2
	str	q24, [sp, #3072]                ; 16-byte Spill
	sshll.2d	v19, v1, #0
	sshll.2d	v22, v0, #0
	sshll.2d	v16, v1, #0
	sshll.2d	v21, v0, #0
	tbz	w20, #7, LBB1_306
LBB1_305:                               ; %cond.store1191
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1440]                 ; 16-byte Reload
	mov.d	x20, v3[1]
	st1.b	{ v6 }[7], [x20]
LBB1_306:                               ; %else1194
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x21, #0                         ; =0x0
	mov	x20, #0                         ; =0x0
	mov	x26, #0                         ; =0x0
	mov	w9, #16512                      ; =0x4080
	movk	w9, #1, lsl #16
	add	x9, x2, x9
	ldp	q5, q3, [x9, #32]
	sshll.2d	v7, v0, #0
	sshll.2d	v6, v1, #0
	ldp	q24, q23, [x9]
	ldr	q18, [sp, #3648]                ; 16-byte Reload
	bit.16b	v24, v18, v6
	bit.16b	v5, v18, v7
	bit.16b	v23, v18, v28
	bit.16b	v3, v18, v10
	stp	q5, q3, [x9, #32]
	stp	q24, q23, [x9]
	dup.2d	v3, x22
	ldr	q18, [sp, #2512]                ; 16-byte Reload
	ldr	q5, [sp, #5008]                 ; 16-byte Reload
	bit.16b	v5, v18, v22
	str	q5, [sp, #5008]                 ; 16-byte Spill
	ldr	q5, [sp, #5040]                 ; 16-byte Reload
	bit.16b	v5, v18, v19
	str	q5, [sp, #5040]                 ; 16-byte Spill
	ldr	q5, [sp, #4944]                 ; 16-byte Reload
	ldr	q20, [sp, #3616]                ; 16-byte Reload
	bit.16b	v5, v20, v22
	str	q5, [sp, #4944]                 ; 16-byte Spill
	ldr	q5, [sp, #4976]                 ; 16-byte Reload
	ldr	q20, [sp, #3600]                ; 16-byte Reload
	bit.16b	v5, v20, v19
	str	q5, [sp, #4976]                 ; 16-byte Spill
	ldr	q20, [sp, #2576]                ; 16-byte Reload
	ldr	q5, [sp, #5136]                 ; 16-byte Reload
	bit.16b	v5, v20, v21
	str	q5, [sp, #5136]                 ; 16-byte Spill
	ldr	q5, [sp, #5168]                 ; 16-byte Reload
	bit.16b	v5, v20, v16
	str	q5, [sp, #5168]                 ; 16-byte Spill
	ldr	q5, [sp, #400]                  ; 16-byte Reload
	ldr	q19, [sp, #5072]                ; 16-byte Reload
	bit.16b	v19, v5, v21
	str	q19, [sp, #5072]                ; 16-byte Spill
	ldr	q5, [sp, #336]                  ; 16-byte Reload
	ldr	q19, [sp, #5104]                ; 16-byte Reload
	bit.16b	v19, v5, v16
	str	q19, [sp, #5104]                ; 16-byte Spill
	ldr	x9, [sp, #744]                  ; 8-byte Reload
	ldp	q16, q5, [x9, #32]
	ldp	q21, q19, [x9]
	bit.16b	v21, v3, v6
	bit.16b	v16, v3, v7
	bit.16b	v19, v3, v28
	bif.16b	v3, v5, v10
	dup.2d	v5, x24
	stp	q16, q3, [x9, #32]
	stp	q21, q19, [x9]
	ldr	x9, [sp, #736]                  ; 8-byte Reload
	ldp	q16, q3, [x9, #32]
	ldp	q21, q19, [x9]
	bit.16b	v21, v5, v6
	bit.16b	v16, v5, v7
	bit.16b	v19, v5, v28
	bit.16b	v3, v5, v10
	stp	q16, q3, [x9, #32]
	stp	q21, q19, [x9]
	dup.2d	v3, x27
	ldr	x9, [sp, #728]                  ; 8-byte Reload
	ldp	q16, q5, [x9, #32]
	ldp	q21, q19, [x9]
	bit.16b	v21, v3, v6
	bit.16b	v16, v3, v7
	bit.16b	v19, v3, v28
	bif.16b	v3, v5, v10
	stp	q16, q3, [x9, #32]
	stp	q21, q19, [x9]
	dup.2d	v3, x4
	ldr	x9, [sp, #720]                  ; 8-byte Reload
	ldp	q16, q5, [x9, #32]
	ldp	q21, q19, [x9]
	bit.16b	v21, v3, v6
	bit.16b	v16, v3, v7
	bit.16b	v19, v3, v28
	bif.16b	v3, v5, v10
	stp	q16, q3, [x9, #32]
	dup.2d	v3, x5
	stp	q21, q19, [x9]
	ldr	x9, [sp, #712]                  ; 8-byte Reload
	ldp	q16, q5, [x9, #32]
	ldp	q21, q19, [x9]
	bit.16b	v21, v3, v6
	bit.16b	v16, v3, v7
	bit.16b	v19, v3, v28
	bif.16b	v3, v5, v10
	stp	q16, q3, [x9, #32]
	stp	q21, q19, [x9]
	dup.2d	v3, x7
	ldr	x9, [sp, #704]                  ; 8-byte Reload
	ldp	q16, q5, [x9, #32]
	ldp	q21, q19, [x9]
	bit.16b	v21, v3, v6
	bit.16b	v16, v3, v7
	bit.16b	v19, v3, v28
	bif.16b	v3, v5, v10
	stp	q16, q3, [x9, #32]
	stp	q21, q19, [x9]
	dup.2d	v3, x30
	mov	x30, x2
	ldr	x9, [sp, #696]                  ; 8-byte Reload
	ldp	q16, q5, [x9, #32]
	ldp	q21, q19, [x9]
	bit.16b	v21, v3, v6
	bit.16b	v16, v3, v7
	bit.16b	v19, v3, v28
	bif.16b	v3, v5, v10
	stp	q16, q3, [x9, #32]
	dup.2d	v3, x13
	stp	q21, q19, [x9]
	ldr	x9, [sp, #688]                  ; 8-byte Reload
	ldp	q16, q5, [x9, #32]
	ldp	q21, q19, [x9]
	bit.16b	v21, v3, v6
	bit.16b	v16, v3, v7
	bit.16b	v19, v3, v28
	bif.16b	v3, v5, v10
	stp	q16, q3, [x9, #32]
	stp	q21, q19, [x9]
	dup.2d	v3, x12
	ldr	x9, [sp, #680]                  ; 8-byte Reload
	ldp	q16, q5, [x9, #32]
	ldp	q21, q19, [x9]
	bit.16b	v21, v3, v6
	bit.16b	v19, v3, v28
	bit.16b	v16, v3, v7
	bif.16b	v3, v5, v10
	stp	q16, q3, [x9, #32]
	stp	q21, q19, [x9]
	dup.2d	v3, x17
	ldr	x9, [sp, #672]                  ; 8-byte Reload
	ldp	q5, q16, [x9, #32]
	ldp	q19, q21, [x9]
	bit.16b	v21, v3, v28
	bit.16b	v19, v3, v6
	bit.16b	v16, v3, v10
	bif.16b	v3, v5, v7
	stp	q3, q16, [x9, #32]
	dup.2d	v3, x0
	stp	q19, q21, [x9]
	ldr	x9, [sp, #664]                  ; 8-byte Reload
	ldp	q5, q16, [x9, #32]
	ldp	q19, q21, [x9]
	bit.16b	v21, v3, v28
	bit.16b	v19, v3, v6
	bit.16b	v16, v3, v10
	bif.16b	v3, v5, v7
	stp	q3, q16, [x9, #32]
	stp	q19, q21, [x9]
	dup.2d	v3, x14
	ldr	x9, [sp, #656]                  ; 8-byte Reload
	ldp	q16, q5, [x9, #32]
	ldp	q21, q19, [x9]
	bit.16b	v21, v3, v6
	bit.16b	v19, v3, v28
	bit.16b	v16, v3, v7
	bif.16b	v3, v5, v10
	stp	q16, q3, [x9, #32]
	stp	q21, q19, [x9]
	dup.2d	v3, x3
	ldr	x9, [sp, #648]                  ; 8-byte Reload
	ldp	q16, q5, [x9, #32]
	ldp	q21, q19, [x9]
	bit.16b	v21, v3, v6
	bit.16b	v19, v3, v28
	bit.16b	v16, v3, v7
	bif.16b	v3, v5, v10
	stp	q16, q3, [x9, #32]
	dup.2d	v3, x1
	stp	q21, q19, [x9]
	ldr	x9, [sp, #640]                  ; 8-byte Reload
	ldp	q16, q5, [x9, #32]
	ldp	q21, q19, [x9]
	bit.16b	v21, v3, v6
	bit.16b	v19, v3, v28
	bit.16b	v16, v3, v7
	bif.16b	v3, v5, v10
	stp	q16, q3, [x9, #32]
	stp	q21, q19, [x9]
	dup.2d	v3, x15
	ldr	x9, [sp, #632]                  ; 8-byte Reload
	ldp	q16, q5, [x9, #32]
	ldp	q21, q19, [x9]
	bit.16b	v21, v3, v6
	bit.16b	v19, v3, v28
	bit.16b	v16, v3, v7
	bif.16b	v3, v5, v10
	stp	q16, q3, [x9, #32]
	stp	q21, q19, [x9]
	mov	w9, #17536                      ; =0x4480
	movk	w9, #1, lsl #16
	add	x9, x2, x9
	ldp	q5, q3, [x9, #32]
	ldr	q16, [sp, #1376]                ; 16-byte Reload
	bit.16b	v5, v16, v7
	ldr	q16, [sp, #1328]                ; 16-byte Reload
	bit.16b	v3, v16, v10
	stp	q5, q3, [x9, #32]
	ldp	q5, q3, [x9]
	ldr	q16, [sp, #1344]                ; 16-byte Reload
	bit.16b	v5, v16, v6
	ldr	q16, [sp, #1360]                ; 16-byte Reload
	bit.16b	v3, v16, v28
	stp	q5, q3, [x9]
	ldr	x9, [sp, #624]                  ; 8-byte Reload
	ldp	q5, q3, [x9, #32]
	ldr	q16, [sp, #1312]                ; 16-byte Reload
	bit.16b	v5, v16, v7
	ldr	q16, [sp, #1264]                ; 16-byte Reload
	bit.16b	v3, v16, v10
	stp	q5, q3, [x9, #32]
	ldp	q5, q3, [x9]
	ldr	q16, [sp, #1280]                ; 16-byte Reload
	bit.16b	v5, v16, v6
	ldr	q16, [sp, #1296]                ; 16-byte Reload
	bit.16b	v3, v16, v28
	stp	q5, q3, [x9]
	ldr	x9, [sp, #616]                  ; 8-byte Reload
	ldp	q5, q3, [x9, #32]
	ldr	q16, [sp, #1248]                ; 16-byte Reload
	bit.16b	v5, v16, v7
	ldr	q16, [sp, #1200]                ; 16-byte Reload
	bit.16b	v3, v16, v10
	stp	q5, q3, [x9, #32]
	ldp	q5, q3, [x9]
	ldr	q16, [sp, #1216]                ; 16-byte Reload
	bit.16b	v5, v16, v6
	ldr	q16, [sp, #1232]                ; 16-byte Reload
	bit.16b	v3, v16, v28
	stp	q5, q3, [x9]
	ldr	x9, [sp, #608]                  ; 8-byte Reload
	ldp	q5, q3, [x9, #32]
	ldr	q16, [sp, #1184]                ; 16-byte Reload
	bit.16b	v5, v16, v7
	ldr	q16, [sp, #1136]                ; 16-byte Reload
	bit.16b	v3, v16, v10
	stp	q5, q3, [x9, #32]
	ldp	q5, q3, [x9]
	ldr	q16, [sp, #1152]                ; 16-byte Reload
	bit.16b	v5, v16, v6
	ldr	q16, [sp, #1168]                ; 16-byte Reload
	bit.16b	v3, v16, v28
	stp	q5, q3, [x9]
	ldr	x9, [sp, #600]                  ; 8-byte Reload
	ldp	q5, q3, [x9, #32]
	ldr	q16, [sp, #1120]                ; 16-byte Reload
	bit.16b	v5, v16, v7
	ldr	q16, [sp, #1072]                ; 16-byte Reload
	bit.16b	v3, v16, v10
	stp	q5, q3, [x9, #32]
	ldp	q5, q3, [x9]
	ldr	q16, [sp, #1088]                ; 16-byte Reload
	bit.16b	v5, v16, v6
	ldr	q16, [sp, #1104]                ; 16-byte Reload
	bit.16b	v3, v16, v28
	stp	q5, q3, [x9]
	ldr	x9, [sp, #592]                  ; 8-byte Reload
	ldp	q5, q3, [x9, #32]
	ldr	q16, [sp, #1056]                ; 16-byte Reload
	bit.16b	v5, v16, v7
	ldp	q19, q16, [sp, #1008]           ; 32-byte Folded Reload
	bit.16b	v3, v19, v10
	stp	q5, q3, [x9, #32]
	ldp	q5, q3, [x9]
	bit.16b	v5, v16, v6
	ldr	q16, [sp, #1040]                ; 16-byte Reload
	bit.16b	v3, v16, v28
	stp	q5, q3, [x9]
	ldr	x12, [sp, #584]                 ; 8-byte Reload
	ldp	q5, q3, [x12, #32]
	ldr	q16, [sp, #992]                 ; 16-byte Reload
	bit.16b	v5, v16, v7
	ldp	q19, q16, [sp, #944]            ; 32-byte Folded Reload
	bit.16b	v3, v19, v10
	stp	q5, q3, [x12, #32]
	ldr	q3, [x12]
	bit.16b	v3, v16, v6
Lloh344:
	adrp	x9, lCPI1_85@PAGE
Lloh345:
	ldr	q5, [x9, lCPI1_85@PAGEOFF]
	ldr	q16, [sp, #5520]                ; 16-byte Reload
	bit.16b	v16, v5, v7
	str	q16, [sp, #5520]                ; 16-byte Spill
	ldr	x13, [sp, #576]                 ; 8-byte Reload
	ldr	q5, [x13, #32]
	ldr	q16, [sp, #928]                 ; 16-byte Reload
	bit.16b	v5, v16, v7
	ldr	q16, [sp, #2480]                ; 16-byte Reload
	ldr	q19, [sp, #5584]                ; 16-byte Reload
	bit.16b	v19, v16, v7
	str	q19, [sp, #5584]                ; 16-byte Spill
Lloh346:
	adrp	x9, lCPI1_86@PAGE
Lloh347:
	ldr	q7, [x9, lCPI1_86@PAGEOFF]
	ldr	q19, [sp, #5552]                ; 16-byte Reload
	bit.16b	v19, v7, v6
	str	q19, [sp, #5552]                ; 16-byte Spill
	ldr	q7, [x13]
	ldr	q19, [sp, #896]                 ; 16-byte Reload
	bit.16b	v7, v19, v6
	ldr	q19, [sp, #5616]                ; 16-byte Reload
	bit.16b	v19, v16, v6
	str	q19, [sp, #5616]                ; 16-byte Spill
Lloh348:
	adrp	x9, lCPI1_83@PAGE
Lloh349:
	ldr	q6, [x9, lCPI1_83@PAGEOFF]
	ldr	q19, [sp, #5504]                ; 16-byte Reload
	bit.16b	v19, v6, v10
	str	q19, [sp, #5504]                ; 16-byte Spill
Lloh350:
	adrp	x9, lCPI1_84@PAGE
Lloh351:
	ldr	q6, [x9, lCPI1_84@PAGEOFF]
	ldr	q19, [sp, #5536]                ; 16-byte Reload
	bit.16b	v19, v6, v28
	str	q19, [sp, #5536]                ; 16-byte Spill
	ldr	q6, [x12, #16]
	ldr	q19, [sp, #976]                 ; 16-byte Reload
	bit.16b	v6, v19, v28
	stp	q3, q6, [x12]
	ldr	q3, [x13, #48]
	ldr	q6, [sp, #880]                  ; 16-byte Reload
	bit.16b	v3, v6, v10
	stp	q5, q3, [x13, #32]
	ldr	q3, [x13, #16]
	ldr	q5, [sp, #912]                  ; 16-byte Reload
	bit.16b	v3, v5, v28
	stp	q7, q3, [x13]
	ldr	q3, [sp, #4992]                 ; 16-byte Reload
	bit.16b	v3, v18, v10
	str	q3, [sp, #4992]                 ; 16-byte Spill
	ldr	q3, [sp, #5024]                 ; 16-byte Reload
	bit.16b	v3, v18, v28
	str	q3, [sp, #5024]                 ; 16-byte Spill
	ldr	q3, [sp, #4928]                 ; 16-byte Reload
	bit.16b	v3, v12, v10
	str	q3, [sp, #4928]                 ; 16-byte Spill
	ldr	q3, [sp, #4960]                 ; 16-byte Reload
	ldr	q5, [sp, #3632]                 ; 16-byte Reload
	bit.16b	v3, v5, v28
	str	q3, [sp, #4960]                 ; 16-byte Spill
	ldr	q3, [sp, #5120]                 ; 16-byte Reload
	bit.16b	v3, v20, v10
	str	q3, [sp, #5120]                 ; 16-byte Spill
	ldr	q3, [sp, #5152]                 ; 16-byte Reload
	bit.16b	v3, v20, v28
	str	q3, [sp, #5152]                 ; 16-byte Spill
	ldr	q3, [sp, #432]                  ; 16-byte Reload
	ldr	q5, [sp, #5056]                 ; 16-byte Reload
	bit.16b	v5, v3, v10
	str	q5, [sp, #5056]                 ; 16-byte Spill
	ldr	q3, [sp, #368]                  ; 16-byte Reload
	ldr	q5, [sp, #5088]                 ; 16-byte Reload
	bit.16b	v5, v3, v28
	str	q5, [sp, #5088]                 ; 16-byte Spill
	ldr	q3, [sp, #5568]                 ; 16-byte Reload
	bit.16b	v3, v16, v10
	str	q3, [sp, #5568]                 ; 16-byte Spill
	ldr	q3, [sp, #5600]                 ; 16-byte Reload
	bit.16b	v3, v16, v28
	str	q3, [sp, #5600]                 ; 16-byte Spill
	mov	w17, #1267                      ; =0x4f3
	movk	w17, #15925, lsl #16
	ldr	w2, [sp, #2636]                 ; 4-byte Reload
	ldr	w7, [sp, #2632]                 ; 4-byte Reload
	ldr	x13, [sp, #2504]                ; 8-byte Reload
	ldr	x14, [sp, #2496]                ; 8-byte Reload
	ldr	x0, [sp, #792]                  ; 8-byte Reload
	ldr	x1, [sp, #784]                  ; 8-byte Reload
	ldr	x3, [sp, #776]                  ; 8-byte Reload
	ldr	x4, [sp, #768]                  ; 8-byte Reload
	ldr	x5, [sp, #760]                  ; 8-byte Reload
	ldr	x22, [sp, #752]                 ; 8-byte Reload
	ldr	q18, [sp, #4160]                ; 16-byte Reload
	ldr	q20, [sp, #4144]                ; 16-byte Reload
	ldr	q24, [sp, #4128]                ; 16-byte Reload
	movi.8b	v28, #1
	b	LBB1_308
LBB1_307:                               ; %else1258
                                        ;   in Loop: Header=BB1_308 Depth=3
	add	x26, x26, #1
	add	x20, x20, #64
	add	x21, x21, #8
	cmp	x26, #128
	b.eq	LBB1_340
LBB1_308:                               ; %direct.true433.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	w12, s2
	lsr	x9, x26, #3
	dup.2d	v7, x9
	ldr	q3, [sp, #5104]                 ; 16-byte Reload
	orr.16b	v3, v7, v3
	ldr	q5, [sp, #5168]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w12, #0, LBB1_310
; %bb.309:                              ; %cond.load
                                        ;   in Loop: Header=BB1_308 Depth=3
	fmov	x9, d3
	ldr	b6, [x9]
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB1_311
	b	LBB1_312
LBB1_310:                               ;   in Loop: Header=BB1_308 Depth=3
	movi.2d	v6, #0000000000000000
	and	w12, w12, #0xff
	tbz	w12, #1, LBB1_312
LBB1_311:                               ; %cond.load1198
                                        ;   in Loop: Header=BB1_308 Depth=3
	mov.d	x9, v3[1]
	ld1.b	{ v6 }[1], [x9]
LBB1_312:                               ; %else1200
                                        ;   in Loop: Header=BB1_308 Depth=3
	ldr	q3, [sp, #5088]                 ; 16-byte Reload
	orr.16b	v3, v7, v3
	ldr	q5, [sp, #5152]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w12, #2, LBB1_327
; %bb.313:                              ; %else1204
                                        ;   in Loop: Header=BB1_308 Depth=3
	tbnz	w12, #3, LBB1_328
LBB1_314:                               ; %else1208
                                        ;   in Loop: Header=BB1_308 Depth=3
	ldr	q3, [sp, #5072]                 ; 16-byte Reload
	orr.16b	v3, v7, v3
	ldr	q5, [sp, #5136]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w12, #4, LBB1_329
LBB1_315:                               ; %else1212
                                        ;   in Loop: Header=BB1_308 Depth=3
	tbnz	w12, #5, LBB1_330
LBB1_316:                               ; %else1216
                                        ;   in Loop: Header=BB1_308 Depth=3
	ldr	q3, [sp, #5056]                 ; 16-byte Reload
	orr.16b	v3, v7, v3
	ldr	q5, [sp, #5120]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w12, #6, LBB1_331
LBB1_317:                               ; %else1220
                                        ;   in Loop: Header=BB1_308 Depth=3
	tbz	w12, #7, LBB1_319
LBB1_318:                               ; %cond.load1222
                                        ;   in Loop: Header=BB1_308 Depth=3
	mov.d	x9, v3[1]
	ld1.b	{ v6 }[7], [x9]
LBB1_319:                               ; %else1224
                                        ;   in Loop: Header=BB1_308 Depth=3
	fmov	w12, s2
	cmeq.8b	v3, v6, #0
	and	x9, x21, #0x3c0
	add	x9, x13, x9
	ldp	q5, q6, [x9]
	ldp	q7, q16, [x9, #32]
	and	x9, x20, #0x1c0
	add	x9, x14, x9
	ldp	q19, q21, [x9]
	ldp	q22, q23, [x9, #32]
	cmge.2d	v16, v23, v16
	cmge.2d	v7, v22, v7
	uzp1.4s	v7, v7, v16
	cmge.2d	v6, v21, v6
	cmge.2d	v5, v19, v5
	uzp1.4s	v5, v5, v6
	uzp1.8h	v5, v5, v7
	xtn.8b	v5, v5
	ldr	d6, [sp, #4920]                 ; 8-byte Reload
	orr.8b	v5, v6, v5
	bic.8b	v5, v5, v3
	dup.2d	v7, x26
	ldr	q3, [sp, #5552]                 ; 16-byte Reload
	orr.16b	v3, v7, v3
	ldr	q6, [sp, #5616]                 ; 16-byte Reload
	add.2d	v3, v6, v3
	and.8b	v6, v5, v28
	tbnz	w12, #0, LBB1_332
; %bb.320:                              ; %else1230
                                        ;   in Loop: Header=BB1_308 Depth=3
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB1_333
LBB1_321:                               ; %else1234
                                        ;   in Loop: Header=BB1_308 Depth=3
	ldr	q3, [sp, #5536]                 ; 16-byte Reload
	orr.16b	v3, v7, v3
	ldr	q5, [sp, #5600]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w12, #2, LBB1_334
LBB1_322:                               ; %else1238
                                        ;   in Loop: Header=BB1_308 Depth=3
	tbnz	w12, #3, LBB1_335
LBB1_323:                               ; %else1242
                                        ;   in Loop: Header=BB1_308 Depth=3
	ldr	q3, [sp, #5520]                 ; 16-byte Reload
	orr.16b	v3, v7, v3
	ldr	q5, [sp, #5584]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w12, #4, LBB1_336
LBB1_324:                               ; %else1246
                                        ;   in Loop: Header=BB1_308 Depth=3
	tbnz	w12, #5, LBB1_337
LBB1_325:                               ; %else1250
                                        ;   in Loop: Header=BB1_308 Depth=3
	ldr	q3, [sp, #5504]                 ; 16-byte Reload
	orr.16b	v3, v7, v3
	ldr	q5, [sp, #5568]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w12, #6, LBB1_338
LBB1_326:                               ; %else1254
                                        ;   in Loop: Header=BB1_308 Depth=3
	tbz	w12, #7, LBB1_307
	b	LBB1_339
LBB1_327:                               ; %cond.load1202
                                        ;   in Loop: Header=BB1_308 Depth=3
	fmov	x9, d3
	ld1.b	{ v6 }[2], [x9]
	tbz	w12, #3, LBB1_314
LBB1_328:                               ; %cond.load1206
                                        ;   in Loop: Header=BB1_308 Depth=3
	mov.d	x9, v3[1]
	ld1.b	{ v6 }[3], [x9]
	ldr	q3, [sp, #5072]                 ; 16-byte Reload
	orr.16b	v3, v7, v3
	ldr	q5, [sp, #5136]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w12, #4, LBB1_315
LBB1_329:                               ; %cond.load1210
                                        ;   in Loop: Header=BB1_308 Depth=3
	fmov	x9, d3
	ld1.b	{ v6 }[4], [x9]
	tbz	w12, #5, LBB1_316
LBB1_330:                               ; %cond.load1214
                                        ;   in Loop: Header=BB1_308 Depth=3
	mov.d	x9, v3[1]
	ld1.b	{ v6 }[5], [x9]
	ldr	q3, [sp, #5056]                 ; 16-byte Reload
	orr.16b	v3, v7, v3
	ldr	q5, [sp, #5120]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w12, #6, LBB1_317
LBB1_331:                               ; %cond.load1218
                                        ;   in Loop: Header=BB1_308 Depth=3
	fmov	x9, d3
	ld1.b	{ v6 }[6], [x9]
	tbnz	w12, #7, LBB1_318
	b	LBB1_319
LBB1_332:                               ; %cond.store1227
                                        ;   in Loop: Header=BB1_308 Depth=3
	fmov	x9, d3
	str	b6, [x9]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB1_321
LBB1_333:                               ; %cond.store1231
                                        ;   in Loop: Header=BB1_308 Depth=3
	mov.d	x9, v3[1]
	st1.b	{ v6 }[1], [x9]
	ldr	q3, [sp, #5536]                 ; 16-byte Reload
	orr.16b	v3, v7, v3
	ldr	q5, [sp, #5600]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w12, #2, LBB1_322
LBB1_334:                               ; %cond.store1235
                                        ;   in Loop: Header=BB1_308 Depth=3
	fmov	x9, d3
	st1.b	{ v6 }[2], [x9]
	tbz	w12, #3, LBB1_323
LBB1_335:                               ; %cond.store1239
                                        ;   in Loop: Header=BB1_308 Depth=3
	mov.d	x9, v3[1]
	st1.b	{ v6 }[3], [x9]
	ldr	q3, [sp, #5520]                 ; 16-byte Reload
	orr.16b	v3, v7, v3
	ldr	q5, [sp, #5584]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w12, #4, LBB1_324
LBB1_336:                               ; %cond.store1243
                                        ;   in Loop: Header=BB1_308 Depth=3
	fmov	x9, d3
	st1.b	{ v6 }[4], [x9]
	tbz	w12, #5, LBB1_325
LBB1_337:                               ; %cond.store1247
                                        ;   in Loop: Header=BB1_308 Depth=3
	mov.d	x9, v3[1]
	st1.b	{ v6 }[5], [x9]
	ldr	q3, [sp, #5504]                 ; 16-byte Reload
	orr.16b	v3, v7, v3
	ldr	q5, [sp, #5568]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w12, #6, LBB1_326
LBB1_338:                               ; %cond.store1251
                                        ;   in Loop: Header=BB1_308 Depth=3
	fmov	x9, d3
	st1.b	{ v6 }[6], [x9]
	tbz	w12, #7, LBB1_307
LBB1_339:                               ; %cond.store1255
                                        ;   in Loop: Header=BB1_308 Depth=3
	mov.d	x9, v3[1]
	st1.b	{ v6 }[7], [x9]
	b	LBB1_307
LBB1_340:                               ; %direct.true455.i.i.preheader
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	mov	x14, #0                         ; =0x0
	ldr	w20, [sp, #2628]                ; 4-byte Reload
	ldr	w26, [sp, #2616]                ; 4-byte Reload
	ldr	q21, [sp, #4112]                ; 16-byte Reload
	ldr	q22, [sp, #4096]                ; 16-byte Reload
	ldr	q23, [sp, #4080]                ; 16-byte Reload
	ldr	q8, [sp, #4064]                 ; 16-byte Reload
	b	LBB1_342
LBB1_341:                               ; %else1355
                                        ;   in Loop: Header=BB1_342 Depth=3
	cmeq.8b	v3, v6, #0
	sshll.8h	v3, v3, #0
	sshll.4s	v5, v3, #0
	sshll2.4s	v3, v3, #0
	dup.4s	v6, w17
	fmul.4s	v7, v7, v6
	fmul.4s	v6, v16, v6
	bsl.16b	v3, v27, v6
	bsl.16b	v5, v27, v7
	add	x9, x6, x14, lsl #5
	ldp	q7, q6, [x9]
	bif.16b	v5, v7, v1
	bif.16b	v3, v6, v0
	stp	q5, q3, [x9]
	add	x14, x14, #1
	add	x13, x13, #4
	add	x12, x12, #8
	cmp	x14, #128
	ldr	q16, [sp, #5200]                ; 16-byte Reload
	b.eq	LBB1_374
LBB1_342:                               ; %direct.true455.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	w15, s2
	and	x9, x12, #0x78
	orr	x9, x9, x14, lsr #4
	dup.2d	v7, x9
	ldr	q3, [sp, #5552]                 ; 16-byte Reload
	orr.16b	v3, v7, v3
	ldr	q5, [sp, #5616]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w15, #0, LBB1_344
; %bb.343:                              ; %cond.load1260
                                        ;   in Loop: Header=BB1_342 Depth=3
	fmov	x9, d3
	ldr	b6, [x9]
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB1_345
	b	LBB1_346
LBB1_344:                               ;   in Loop: Header=BB1_342 Depth=3
	movi.2d	v6, #0000000000000000
	and	w15, w15, #0xff
	tbz	w15, #1, LBB1_346
LBB1_345:                               ; %cond.load1266
                                        ;   in Loop: Header=BB1_342 Depth=3
	mov.d	x9, v3[1]
	ld1.b	{ v6 }[1], [x9]
LBB1_346:                               ; %else1270
                                        ;   in Loop: Header=BB1_342 Depth=3
	ldr	q3, [sp, #5536]                 ; 16-byte Reload
	orr.16b	v3, v7, v3
	ldr	q5, [sp, #5600]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w15, #2, LBB1_361
; %bb.347:                              ; %else1276
                                        ;   in Loop: Header=BB1_342 Depth=3
	tbnz	w15, #3, LBB1_362
LBB1_348:                               ; %else1282
                                        ;   in Loop: Header=BB1_342 Depth=3
	ldr	q3, [sp, #5520]                 ; 16-byte Reload
	orr.16b	v3, v7, v3
	ldr	q5, [sp, #5584]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w15, #4, LBB1_363
LBB1_349:                               ; %else1288
                                        ;   in Loop: Header=BB1_342 Depth=3
	tbnz	w15, #5, LBB1_364
LBB1_350:                               ; %else1294
                                        ;   in Loop: Header=BB1_342 Depth=3
	ldr	q3, [sp, #5504]                 ; 16-byte Reload
	orr.16b	v3, v7, v3
	ldr	q5, [sp, #5568]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w15, #6, LBB1_365
LBB1_351:                               ; %else1300
                                        ;   in Loop: Header=BB1_342 Depth=3
	tbz	w15, #7, LBB1_353
LBB1_352:                               ; %cond.load1302
                                        ;   in Loop: Header=BB1_342 Depth=3
	mov.d	x9, v3[1]
	ld1.b	{ v6 }[7], [x9]
LBB1_353:                               ; %else1306
                                        ;   in Loop: Header=BB1_342 Depth=3
	fmov	w15, s2
	dup.2d	v19, x13
	ldr	q3, [sp, #4976]                 ; 16-byte Reload
	orr.16b	v3, v19, v3
	ldr	q5, [sp, #5040]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbnz	w15, #0, LBB1_366
; %bb.354:                              ; %else1313
                                        ;   in Loop: Header=BB1_342 Depth=3
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB1_367
LBB1_355:                               ; %else1319
                                        ;   in Loop: Header=BB1_342 Depth=3
	ldr	q3, [sp, #4960]                 ; 16-byte Reload
	orr.16b	v3, v19, v3
	ldr	q5, [sp, #5024]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w15, #2, LBB1_368
LBB1_356:                               ; %else1325
                                        ;   in Loop: Header=BB1_342 Depth=3
	tbnz	w15, #3, LBB1_369
LBB1_357:                               ; %else1331
                                        ;   in Loop: Header=BB1_342 Depth=3
	ldr	q3, [sp, #4944]                 ; 16-byte Reload
	orr.16b	v3, v19, v3
	ldr	q5, [sp, #5008]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w15, #4, LBB1_370
LBB1_358:                               ; %else1337
                                        ;   in Loop: Header=BB1_342 Depth=3
	tbnz	w15, #5, LBB1_371
LBB1_359:                               ; %else1343
                                        ;   in Loop: Header=BB1_342 Depth=3
	ldr	q3, [sp, #4928]                 ; 16-byte Reload
	orr.16b	v3, v19, v3
	ldr	q5, [sp, #4992]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w15, #6, LBB1_372
LBB1_360:                               ; %else1349
                                        ;   in Loop: Header=BB1_342 Depth=3
	ldr	q19, [sp, #5184]                ; 16-byte Reload
	tbz	w15, #7, LBB1_341
	b	LBB1_373
LBB1_361:                               ; %cond.load1272
                                        ;   in Loop: Header=BB1_342 Depth=3
	fmov	x9, d3
	ld1.b	{ v6 }[2], [x9]
	tbz	w15, #3, LBB1_348
LBB1_362:                               ; %cond.load1278
                                        ;   in Loop: Header=BB1_342 Depth=3
	mov.d	x9, v3[1]
	ld1.b	{ v6 }[3], [x9]
	ldr	q3, [sp, #5520]                 ; 16-byte Reload
	orr.16b	v3, v7, v3
	ldr	q5, [sp, #5584]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w15, #4, LBB1_349
LBB1_363:                               ; %cond.load1284
                                        ;   in Loop: Header=BB1_342 Depth=3
	fmov	x9, d3
	ld1.b	{ v6 }[4], [x9]
	tbz	w15, #5, LBB1_350
LBB1_364:                               ; %cond.load1290
                                        ;   in Loop: Header=BB1_342 Depth=3
	mov.d	x9, v3[1]
	ld1.b	{ v6 }[5], [x9]
	ldr	q3, [sp, #5504]                 ; 16-byte Reload
	orr.16b	v3, v7, v3
	ldr	q5, [sp, #5568]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w15, #6, LBB1_351
LBB1_365:                               ; %cond.load1296
                                        ;   in Loop: Header=BB1_342 Depth=3
	fmov	x9, d3
	ld1.b	{ v6 }[6], [x9]
	tbnz	w15, #7, LBB1_352
	b	LBB1_353
LBB1_366:                               ; %cond.load1309
                                        ;   in Loop: Header=BB1_342 Depth=3
	fmov	x9, d3
	ldr	s7, [x9]
	and	w15, w15, #0xff
	tbz	w15, #1, LBB1_355
LBB1_367:                               ; %cond.load1315
                                        ;   in Loop: Header=BB1_342 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v7 }[1], [x9]
	ldr	q3, [sp, #4960]                 ; 16-byte Reload
	orr.16b	v3, v19, v3
	ldr	q5, [sp, #5024]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w15, #2, LBB1_356
LBB1_368:                               ; %cond.load1321
                                        ;   in Loop: Header=BB1_342 Depth=3
	fmov	x9, d3
	ld1.s	{ v7 }[2], [x9]
	tbz	w15, #3, LBB1_357
LBB1_369:                               ; %cond.load1327
                                        ;   in Loop: Header=BB1_342 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v7 }[3], [x9]
	ldr	q3, [sp, #4944]                 ; 16-byte Reload
	orr.16b	v3, v19, v3
	ldr	q5, [sp, #5008]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w15, #4, LBB1_358
LBB1_370:                               ; %cond.load1333
                                        ;   in Loop: Header=BB1_342 Depth=3
	fmov	x9, d3
	ld1.s	{ v16 }[0], [x9]
	tbz	w15, #5, LBB1_359
LBB1_371:                               ; %cond.load1339
                                        ;   in Loop: Header=BB1_342 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v16 }[1], [x9]
	ldr	q3, [sp, #4928]                 ; 16-byte Reload
	orr.16b	v3, v19, v3
	ldr	q5, [sp, #4992]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w15, #6, LBB1_360
LBB1_372:                               ; %cond.load1345
                                        ;   in Loop: Header=BB1_342 Depth=3
	fmov	x9, d3
	ld1.s	{ v16 }[2], [x9]
	ldr	q19, [sp, #5184]                ; 16-byte Reload
	tbz	w15, #7, LBB1_341
LBB1_373:                               ; %cond.load1351
                                        ;   in Loop: Header=BB1_342 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v16 }[3], [x9]
	b	LBB1_341
LBB1_374:                               ; %direct.false456.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	str	q12, [sp, #2928]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q6, [sp, #4016]                 ; 16-byte Reload
	bit.16b	v6, v25, v0
	bit.16b	v26, v25, v1
LBB1_375:                               ; %direct.true473.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x9, x6, x12
	ldp	q3, q5, [x9]
	and.16b	v5, v0, v5
	and.16b	v3, v1, v3
	fmaxnm.4s	v3, v26, v3
	fmaxnm.4s	v5, v6, v5
	bit.16b	v6, v5, v0
	bit.16b	v26, v3, v1
	add	x12, x12, #32
	cmp	x12, #512
	b.ne	LBB1_375
; %bb.376:                              ; %direct.false474.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	str	q6, [sp, #4016]                 ; 16-byte Spill
	str	q26, [sp, #3648]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q26, [sp, #4032]                ; 16-byte Reload
	bit.16b	v26, v25, v0
	ldr	q12, [sp, #4048]                ; 16-byte Reload
	bit.16b	v12, v25, v1
	mov	w13, #29184                     ; =0x7200
	movk	w13, #48945, lsl #16
	mov	w14, #48782                     ; =0xbe8e
	movk	w14, #46527, lsl #16
	ldr	x15, [sp, #2472]                ; 8-byte Reload
	ldr	x17, [sp, #2464]                ; 8-byte Reload
	ldr	q6, [sp, #4192]                 ; 16-byte Reload
	ldr	q7, [sp, #4176]                 ; 16-byte Reload
LBB1_377:                               ; %direct.true485.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x9, x0, x12
	ldp	q3, q5, [x9]
	and.16b	v5, v0, v5
	and.16b	v3, v1, v3
	fmaxnm.4s	v3, v12, v3
	fmaxnm.4s	v5, v26, v5
	bit.16b	v26, v5, v0
	bit.16b	v12, v3, v1
	add	x12, x12, #32
	cmp	x12, #512
	b.ne	LBB1_377
; %bb.378:                              ; %direct.false486.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	str	q26, [sp, #4032]                ; 16-byte Spill
	str	q12, [sp, #4048]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	bit.16b	v19, v25, v0
	bit.16b	v16, v25, v1
LBB1_379:                               ; %direct.true497.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x9, x1, x12
	ldp	q3, q5, [x9]
	and.16b	v5, v0, v5
	and.16b	v3, v1, v3
	fmaxnm.4s	v3, v16, v3
	fmaxnm.4s	v5, v19, v5
	bit.16b	v19, v5, v0
	bit.16b	v16, v3, v1
	add	x12, x12, #32
	cmp	x12, #512
	b.ne	LBB1_379
; %bb.380:                              ; %direct.false498.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	bit.16b	v8, v25, v0
	bit.16b	v23, v25, v1
	ldr	q26, [sp, #3648]                ; 16-byte Reload
LBB1_381:                               ; %direct.true509.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x9, x3, x12
	ldp	q3, q5, [x9]
	and.16b	v5, v0, v5
	and.16b	v3, v1, v3
	fmaxnm.4s	v3, v23, v3
	fmaxnm.4s	v5, v8, v5
	bit.16b	v8, v5, v0
	bit.16b	v23, v3, v1
	add	x12, x12, #32
	cmp	x12, #512
	b.ne	LBB1_381
; %bb.382:                              ; %direct.false510.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	bit.16b	v22, v25, v0
	bit.16b	v21, v25, v1
LBB1_383:                               ; %direct.true521.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x9, x4, x12
	ldp	q3, q5, [x9]
	and.16b	v5, v0, v5
	and.16b	v3, v1, v3
	fmaxnm.4s	v3, v21, v3
	fmaxnm.4s	v5, v22, v5
	bit.16b	v22, v5, v0
	bit.16b	v21, v3, v1
	add	x12, x12, #32
	cmp	x12, #512
	b.ne	LBB1_383
; %bb.384:                              ; %direct.false522.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	bit.16b	v24, v25, v0
	bit.16b	v20, v25, v1
LBB1_385:                               ; %direct.true533.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x9, x5, x12
	ldp	q3, q5, [x9]
	and.16b	v5, v0, v5
	and.16b	v3, v1, v3
	fmaxnm.4s	v3, v20, v3
	fmaxnm.4s	v5, v24, v5
	bit.16b	v24, v5, v0
	bit.16b	v20, v3, v1
	add	x12, x12, #32
	cmp	x12, #512
	b.ne	LBB1_385
; %bb.386:                              ; %direct.false534.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	str	q20, [sp, #4144]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	bit.16b	v18, v25, v0
	bit.16b	v7, v25, v1
LBB1_387:                               ; %direct.true545.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x9, x22, x12
	ldp	q3, q5, [x9]
	and.16b	v5, v0, v5
	and.16b	v3, v1, v3
	fmaxnm.4s	v3, v7, v3
	fmaxnm.4s	v5, v18, v5
	bit.16b	v18, v5, v0
	bit.16b	v7, v3, v1
	add	x12, x12, #32
	cmp	x12, #512
	b.ne	LBB1_387
; %bb.388:                              ; %direct.false546.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	str	q4, [sp, #2640]                 ; 16-byte Spill
	str	q14, [sp, #2656]                ; 16-byte Spill
	str	q11, [sp, #2672]                ; 16-byte Spill
	str	q13, [sp, #2688]                ; 16-byte Spill
	str	q19, [sp, #5184]                ; 16-byte Spill
	str	q16, [sp, #5200]                ; 16-byte Spill
	str	q8, [sp, #4064]                 ; 16-byte Spill
	str	q23, [sp, #4080]                ; 16-byte Spill
	str	q22, [sp, #4096]                ; 16-byte Spill
	str	q21, [sp, #4112]                ; 16-byte Spill
	str	q24, [sp, #4128]                ; 16-byte Spill
	str	q18, [sp, #4160]                ; 16-byte Spill
	str	q7, [sp, #4176]                 ; 16-byte Spill
	str	q15, [sp, #3232]                ; 16-byte Spill
	str	q31, [sp, #3248]                ; 16-byte Spill
	str	q30, [sp, #3264]                ; 16-byte Spill
	str	q29, [sp, #3280]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q10, [sp, #3104]                ; 16-byte Reload
	bit.16b	v10, v25, v0
	mvni.4s	v20, #127, msl #16
	bit.16b	v6, v25, v1
LBB1_389:                               ; %direct.true557.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x9, x8, x12
	ldp	q3, q5, [x9]
	and.16b	v5, v0, v5
	and.16b	v3, v1, v3
	fmaxnm.4s	v3, v6, v3
	fmaxnm.4s	v5, v10, v5
	bit.16b	v10, v5, v0
	bit.16b	v6, v3, v1
	add	x12, x12, #32
	cmp	x12, #512
	b.ne	LBB1_389
; %bb.390:                              ; %direct.false558.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x21, #0                         ; =0x0
	mov	x27, #0                         ; =0x0
	mov	x22, #0                         ; =0x0
	mov	x24, #0                         ; =0x0
	ldr	q16, [sp, #3696]                ; 16-byte Reload
	fmaxnm.4s	v19, v16, v26
	ldr	q3, [sp, #4016]                 ; 16-byte Reload
	ldr	q18, [sp, #3680]                ; 16-byte Reload
	fmaxnm.4s	v21, v18, v3
	mov	w9, #23168                      ; =0x5a80
	movk	w9, #1, lsl #16
	add	x12, x30, x9
	ldp	q3, q5, [x12]
	str	q6, [sp, #4192]                 ; 16-byte Spill
	mov.16b	v6, v0
	bsl.16b	v6, v21, v5
	mov.16b	v7, v1
	bsl.16b	v7, v19, v3
	str	q21, [sp, #2944]                ; 16-byte Spill
	fsub.4s	v3, v18, v21
	str	q19, [sp, #2960]                ; 16-byte Spill
	fsub.4s	v5, v16, v19
	and.16b	v22, v1, v5
	and.16b	v23, v0, v3
	mov	w9, #-1026555904                ; =0xc2d00000
	dup.4s	v12, w9
	fcmge.4s	v3, v23, v12
	stp	q7, q6, [x12]
	fcmge.4s	v5, v22, v12
	mov	w9, #1120403456                 ; =0x42c80000
	dup.4s	v6, w9
	fcmge.4s	v7, v6, v23
	fcmge.4s	v16, v6, v22
	and.16b	v5, v5, v16
	and.16b	v3, v3, v7
	and.16b	v3, v3, v23
	and.16b	v5, v5, v22
	mov	w9, #43579                      ; =0xaa3b
	movk	w9, #16312, lsl #16
	dup.4s	v16, w9
	fmul.4s	v7, v5, v16
	fmul.4s	v19, v3, v16
	movi.4s	v18, #75, lsl #24
	mvni.4s	v24, #128, lsl #24
	mov.16b	v21, v24
	bsl.16b	v21, v18, v19
	bsl.16b	v24, v18, v7
	fadd.4s	v7, v7, v24
	fadd.4s	v19, v19, v21
	fsub.4s	v19, v19, v21
	fsub.4s	v7, v7, v24
	fcvtzs.4s	v21, v7
	fcvtzs.4s	v24, v19
	scvtf.4s	v7, v24
	scvtf.4s	v19, v21
	mov	w9, #29184                      ; =0x7200
	movk	w9, #16177, lsl #16
	dup.4s	v8, w9
	fmul.4s	v25, v19, v8
	fmul.4s	v26, v7, v8
	fsub.4s	v3, v3, v26
	fsub.4s	v5, v5, v25
	mov	w9, #48782                      ; =0xbe8e
	movk	w9, #13759, lsl #16
	dup.4s	v13, w9
	fmul.4s	v7, v7, v13
	fmul.4s	v19, v19, v13
	fsub.4s	v5, v5, v19
	fsub.4s	v3, v3, v7
	mov	w9, #11226                      ; =0x2bda
	movk	w9, #14672, lsl #16
	dup.4s	v25, w9
	fmul.4s	v7, v3, v25
	fmul.4s	v26, v5, v25
	mov	w9, #38601                      ; =0x96c9
	movk	w9, #15030, lsl #16
	dup.4s	v19, w9
	fadd.4s	v26, v26, v19
	fadd.4s	v7, v7, v19
	fmul.4s	v7, v3, v7
	fmul.4s	v26, v5, v26
	mov	w9, #34982                      ; =0x88a6
	movk	w9, #15368, lsl #16
	dup.4s	v15, w9
	fadd.4s	v26, v26, v15
	fadd.4s	v7, v7, v15
	fmul.4s	v27, v3, v7
	fmul.4s	v26, v5, v26
	mov	w9, #43642                      ; =0xaa7a
	movk	w9, #15658, lsl #16
	dup.4s	v7, w9
	fadd.4s	v26, v26, v7
	fadd.4s	v27, v27, v7
	fmul.4s	v27, v3, v27
	fmul.4s	v26, v5, v26
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #15914, lsl #16
	dup.4s	v31, w9
	fadd.4s	v26, v26, v31
	fadd.4s	v27, v27, v31
	fmul.4s	v27, v3, v27
	fmul.4s	v26, v5, v26
	movi.4s	v18, #63, lsl #24
	fadd.4s	v26, v26, v18
	fadd.4s	v27, v27, v18
	fmul.4s	v28, v5, v5
	fmul.4s	v29, v3, v3
	fmul.4s	v27, v29, v27
	fmul.4s	v26, v28, v26
	fadd.4s	v5, v5, v26
	fadd.4s	v3, v3, v27
	fmov.4s	v18, #1.00000000
	fadd.4s	v3, v3, v18
	fadd.4s	v5, v5, v18
	sshr.4s	v26, v24, #1
	sshr.4s	v27, v21, #1
	shl.4s	v28, v27, #23
	shl.4s	v29, v26, #23
	add.4s	v29, v29, v18
	add.4s	v28, v28, v18
	fmul.4s	v5, v5, v28
	fmul.4s	v3, v3, v29
	sub.4s	v21, v21, v27
	sub.4s	v24, v24, v26
	shl.4s	v24, v24, #23
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v18
	add.4s	v24, v24, v18
	fmul.4s	v3, v3, v24
	fmul.4s	v5, v5, v21
	fcmgt.4s	v21, v12, v22
	bic.16b	v5, v5, v21
	fcmgt.4s	v21, v12, v23
	bic.16b	v3, v3, v21
	fcmgt.4s	v24, v22, v6
	fcmgt.4s	v26, v23, v6
	fneg.4s	v21, v20
	bit.16b	v3, v21, v26
	bit.16b	v5, v21, v24
	fcmeq.4s	v23, v23, v23
	fcmeq.4s	v22, v22, v22
	ldr	q9, [sp, #5296]                 ; 16-byte Reload
	mov.16b	v18, v22
	bsl.16b	v18, v5, v9
	mov.16b	v20, v23
	bsl.16b	v20, v3, v9
	mov	w9, #23424                      ; =0x5b80
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	ldp	q3, q5, [x9]
	str	q20, [sp, #2896]                ; 16-byte Spill
	bit.16b	v5, v20, v0
	str	q18, [sp, #2912]                ; 16-byte Spill
	bit.16b	v3, v18, v1
	stp	q3, q5, [x9]
	ldr	q3, [sp, #4048]                 ; 16-byte Reload
	ldr	q23, [sp, #3760]                ; 16-byte Reload
	fmaxnm.4s	v24, v23, v3
	ldr	q3, [sp, #4032]                 ; 16-byte Reload
	ldr	q22, [sp, #3728]                ; 16-byte Reload
	fmaxnm.4s	v26, v22, v3
	ldr	q3, [sp, #5200]                 ; 16-byte Reload
	ldr	q4, [sp, #4336]                 ; 16-byte Reload
	fmaxnm.4s	v30, v4, v3
	ldr	q3, [sp, #5184]                 ; 16-byte Reload
	ldr	q4, [sp, #4320]                 ; 16-byte Reload
	fmaxnm.4s	v18, v4, v3
	ldr	q3, [sp, #4080]                 ; 16-byte Reload
	ldr	q5, [sp, #4368]                 ; 16-byte Reload
	fmaxnm.4s	v14, v5, v3
	ldr	q3, [sp, #4064]                 ; 16-byte Reload
	ldr	q5, [sp, #4352]                 ; 16-byte Reload
	fmaxnm.4s	v4, v5, v3
	str	q4, [sp, #3552]                 ; 16-byte Spill
	ldr	q3, [sp, #4112]                 ; 16-byte Reload
	ldr	q5, [sp, #4400]                 ; 16-byte Reload
	fmaxnm.4s	v29, v5, v3
	ldr	q3, [sp, #4096]                 ; 16-byte Reload
	ldr	q5, [sp, #4384]                 ; 16-byte Reload
	fmaxnm.4s	v11, v5, v3
	str	q11, [sp, #3536]                ; 16-byte Spill
	ldr	q3, [sp, #4144]                 ; 16-byte Reload
	ldr	q5, [sp, #4432]                 ; 16-byte Reload
	fmaxnm.4s	v28, v5, v3
	str	q28, [sp, #3584]                ; 16-byte Spill
	ldr	q3, [sp, #4128]                 ; 16-byte Reload
	ldr	q5, [sp, #4416]                 ; 16-byte Reload
	fmaxnm.4s	v27, v5, v3
	str	q27, [sp, #3520]                ; 16-byte Spill
	ldr	q3, [sp, #4160]                 ; 16-byte Reload
	ldr	q5, [sp, #4448]                 ; 16-byte Reload
	fmaxnm.4s	v20, v5, v3
	str	q20, [sp, #3568]                ; 16-byte Spill
	ldr	x9, [sp, #568]                  ; 8-byte Reload
	ldp	q3, q5, [x9]
	bit.16b	v5, v26, v0
	bit.16b	v3, v24, v1
	stp	q3, q5, [x9]
	ldr	x9, [sp, #560]                  ; 8-byte Reload
	ldp	q3, q5, [x9]
	bit.16b	v5, v18, v0
	bit.16b	v3, v30, v1
	stp	q3, q5, [x9]
	ldr	x9, [sp, #552]                  ; 8-byte Reload
	ldp	q3, q5, [x9]
	bit.16b	v5, v4, v0
	bit.16b	v3, v14, v1
	stp	q3, q5, [x9]
	ldr	x9, [sp, #544]                  ; 8-byte Reload
	ldp	q3, q5, [x9]
	bit.16b	v5, v11, v0
	bit.16b	v3, v29, v1
	mov.16b	v11, v29
	stp	q3, q5, [x9]
	ldr	x9, [sp, #536]                  ; 8-byte Reload
	ldp	q3, q5, [x9]
	bit.16b	v5, v27, v0
	bit.16b	v3, v28, v1
	stp	q3, q5, [x9]
	ldr	x9, [sp, #528]                  ; 8-byte Reload
	ldp	q3, q5, [x9]
	bit.16b	v5, v20, v0
	ldr	q20, [sp, #4176]                ; 16-byte Reload
	ldr	q27, [sp, #4464]                ; 16-byte Reload
	fmaxnm.4s	v20, v27, v20
	str	q20, [sp, #3504]                ; 16-byte Spill
	bit.16b	v3, v20, v1
	stp	q3, q5, [x9]
	str	q10, [sp, #3104]                ; 16-byte Spill
	ldr	q3, [sp, #4496]                 ; 16-byte Reload
	fmaxnm.4s	v5, v3, v10
	str	q5, [sp, #3488]                 ; 16-byte Spill
	ldr	x9, [sp, #520]                  ; 8-byte Reload
	ldr	q3, [x9, #16]
	bit.16b	v3, v5, v0
	ldr	q5, [x9]
	ldr	q20, [sp, #4192]                ; 16-byte Reload
	ldr	q27, [sp, #4480]                ; 16-byte Reload
	fmaxnm.4s	v20, v27, v20
	str	q20, [sp, #3472]                ; 16-byte Spill
	bit.16b	v5, v20, v1
	stp	q5, q3, [x9]
	str	q26, [sp, #2816]                ; 16-byte Spill
	fsub.4s	v3, v22, v26
	and.16b	v22, v0, v3
	fcmge.4s	v3, v22, v12
	fcmge.4s	v5, v6, v22
	and.16b	v3, v3, v5
	str	q24, [sp, #2880]                ; 16-byte Spill
	fsub.4s	v5, v23, v24
	and.16b	v23, v1, v5
	fcmge.4s	v5, v23, v12
	fcmge.4s	v24, v6, v23
	and.16b	v5, v5, v24
	and.16b	v5, v5, v23
	fmul.4s	v24, v5, v16
	mvni.4s	v20, #128, lsl #24
	movi.4s	v27, #75, lsl #24
	mov.16b	v26, v20
	bsl.16b	v26, v27, v24
	fadd.4s	v24, v24, v26
	fsub.4s	v24, v24, v26
	and.16b	v3, v3, v22
	fmul.4s	v26, v3, v16
	bif.16b	v27, v26, v20
	mvni.4s	v10, #128, lsl #24
	fadd.4s	v26, v26, v27
	fsub.4s	v26, v26, v27
	fcvtzs.4s	v24, v24
	scvtf.4s	v27, v24
	fmul.4s	v28, v27, v8
	fsub.4s	v5, v5, v28
	fcvtzs.4s	v26, v26
	scvtf.4s	v28, v26
	fmul.4s	v29, v28, v8
	fsub.4s	v3, v3, v29
	fmul.4s	v28, v28, v13
	fsub.4s	v3, v3, v28
	fmul.4s	v27, v27, v13
	mov.16b	v20, v13
	fsub.4s	v5, v5, v27
	fmul.4s	v27, v5, v25
	fadd.4s	v27, v27, v19
	fmul.4s	v27, v5, v27
	fadd.4s	v27, v27, v15
	fmul.4s	v27, v5, v27
	fadd.4s	v27, v27, v7
	fmul.4s	v27, v5, v27
	fadd.4s	v27, v27, v31
	fmul.4s	v27, v5, v27
	movi.4s	v29, #63, lsl #24
	fadd.4s	v27, v27, v29
	fmul.4s	v28, v5, v5
	fmul.4s	v27, v28, v27
	fmul.4s	v28, v3, v25
	fadd.4s	v28, v28, v19
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v15
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v7
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v31
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v29
	fmul.4s	v29, v3, v3
	fmul.4s	v28, v29, v28
	fadd.4s	v3, v3, v28
	fadd.4s	v5, v5, v27
	fmov.4s	v13, #1.00000000
	fadd.4s	v3, v3, v13
	sshr.4s	v27, v26, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v13
	fmul.4s	v3, v3, v28
	fadd.4s	v5, v5, v13
	sshr.4s	v28, v24, #1
	shl.4s	v29, v28, #23
	add.4s	v29, v29, v13
	fmul.4s	v5, v5, v29
	sub.4s	v26, v26, v27
	sub.4s	v24, v24, v28
	shl.4s	v24, v24, #23
	add.4s	v24, v24, v13
	fmul.4s	v5, v5, v24
	shl.4s	v24, v26, #23
	add.4s	v24, v24, v13
	fmul.4s	v3, v3, v24
	fcmgt.4s	v24, v12, v22
	bic.16b	v3, v3, v24
	fcmgt.4s	v24, v12, v23
	bic.16b	v5, v5, v24
	fcmgt.4s	v24, v23, v6
	bit.16b	v5, v21, v24
	fcmgt.4s	v24, v22, v6
	bit.16b	v3, v21, v24
	fcmeq.4s	v22, v22, v22
	bif.16b	v3, v9, v22
	str	q3, [sp, #3456]                 ; 16-byte Spill
	fcmeq.4s	v3, v23, v23
	bsl.16b	v3, v5, v9
	str	q3, [sp, #3440]                 ; 16-byte Spill
	str	q18, [sp, #2800]                ; 16-byte Spill
	ldr	q3, [sp, #4320]                 ; 16-byte Reload
	fsub.4s	v3, v3, v18
	and.16b	v22, v0, v3
	fcmge.4s	v3, v22, v12
	fcmge.4s	v5, v6, v22
	and.16b	v3, v3, v5
	str	q30, [sp, #2864]                ; 16-byte Spill
	ldr	q4, [sp, #4336]                 ; 16-byte Reload
	fsub.4s	v5, v4, v30
	and.16b	v23, v1, v5
	fcmge.4s	v5, v23, v12
	fcmge.4s	v24, v6, v23
	and.16b	v5, v5, v24
	and.16b	v5, v5, v23
	fmul.4s	v24, v5, v16
	movi.4s	v18, #75, lsl #24
	mov.16b	v26, v10
	bsl.16b	v26, v18, v24
	fadd.4s	v24, v24, v26
	fsub.4s	v24, v24, v26
	and.16b	v3, v3, v22
	fmul.4s	v26, v3, v16
	mov.16b	v27, v10
	bsl.16b	v27, v18, v26
	movi.4s	v30, #75, lsl #24
	fadd.4s	v26, v26, v27
	fsub.4s	v26, v26, v27
	fcvtzs.4s	v24, v24
	scvtf.4s	v27, v24
	fmul.4s	v28, v27, v8
	fsub.4s	v5, v5, v28
	fcvtzs.4s	v26, v26
	scvtf.4s	v28, v26
	fmul.4s	v29, v28, v8
	fsub.4s	v3, v3, v29
	fmul.4s	v28, v28, v20
	fsub.4s	v3, v3, v28
	fmul.4s	v27, v27, v20
	fsub.4s	v5, v5, v27
	fmul.4s	v27, v5, v25
	fadd.4s	v27, v27, v19
	fmul.4s	v27, v5, v27
	fadd.4s	v27, v27, v15
	fmul.4s	v27, v5, v27
	fadd.4s	v27, v27, v7
	fmul.4s	v27, v5, v27
	fadd.4s	v27, v27, v31
	fmul.4s	v27, v5, v27
	movi.4s	v4, #63, lsl #24
	fadd.4s	v27, v27, v4
	fmul.4s	v28, v5, v5
	fmul.4s	v27, v28, v27
	fmul.4s	v28, v3, v25
	fadd.4s	v28, v28, v19
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v15
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v7
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v31
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v4
	fmul.4s	v29, v3, v3
	fmul.4s	v28, v29, v28
	fadd.4s	v3, v3, v28
	fadd.4s	v5, v5, v27
	fadd.4s	v3, v3, v13
	sshr.4s	v27, v26, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v13
	fmul.4s	v3, v3, v28
	fadd.4s	v5, v5, v13
	sshr.4s	v28, v24, #1
	shl.4s	v29, v28, #23
	add.4s	v29, v29, v13
	fmul.4s	v5, v5, v29
	sub.4s	v26, v26, v27
	sub.4s	v24, v24, v28
	shl.4s	v24, v24, #23
	add.4s	v24, v24, v13
	fmul.4s	v5, v5, v24
	shl.4s	v24, v26, #23
	add.4s	v24, v24, v13
	fmul.4s	v3, v3, v24
	fcmgt.4s	v24, v12, v22
	bic.16b	v3, v3, v24
	fcmgt.4s	v24, v12, v23
	bic.16b	v5, v5, v24
	fcmgt.4s	v24, v23, v6
	bit.16b	v5, v21, v24
	fcmgt.4s	v24, v22, v6
	bit.16b	v3, v21, v24
	fcmeq.4s	v22, v22, v22
	bif.16b	v3, v9, v22
	str	q3, [sp, #3424]                 ; 16-byte Spill
	fcmeq.4s	v3, v23, v23
	bsl.16b	v3, v5, v9
	str	q3, [sp, #3408]                 ; 16-byte Spill
	ldr	q5, [sp, #4352]                 ; 16-byte Reload
	ldr	q3, [sp, #3552]                 ; 16-byte Reload
	fsub.4s	v3, v5, v3
	and.16b	v22, v0, v3
	fcmge.4s	v3, v22, v12
	fcmge.4s	v5, v6, v22
	and.16b	v3, v3, v5
	str	q14, [sp, #2848]                ; 16-byte Spill
	ldr	q18, [sp, #4368]                ; 16-byte Reload
	fsub.4s	v5, v18, v14
	and.16b	v23, v1, v5
	fcmge.4s	v5, v23, v12
	fcmge.4s	v24, v6, v23
	and.16b	v5, v5, v24
	and.16b	v5, v5, v23
	fmul.4s	v24, v5, v16
	mov.16b	v26, v10
	bsl.16b	v26, v30, v24
	fadd.4s	v24, v24, v26
	fsub.4s	v24, v24, v26
	and.16b	v3, v3, v22
	fmul.4s	v26, v3, v16
	mov.16b	v27, v10
	bsl.16b	v27, v30, v26
	fadd.4s	v26, v26, v27
	fsub.4s	v26, v26, v27
	fcvtzs.4s	v24, v24
	scvtf.4s	v27, v24
	fmul.4s	v28, v27, v8
	fsub.4s	v5, v5, v28
	fcvtzs.4s	v26, v26
	scvtf.4s	v28, v26
	fmul.4s	v29, v28, v8
	fsub.4s	v3, v3, v29
	fmul.4s	v28, v28, v20
	fsub.4s	v3, v3, v28
	fmul.4s	v27, v27, v20
	fsub.4s	v5, v5, v27
	fmul.4s	v27, v5, v25
	fadd.4s	v27, v27, v19
	fmul.4s	v27, v5, v27
	fadd.4s	v27, v27, v15
	fmul.4s	v27, v5, v27
	fadd.4s	v27, v27, v7
	fmul.4s	v27, v5, v27
	fadd.4s	v27, v27, v31
	fmul.4s	v27, v5, v27
	fadd.4s	v27, v27, v4
	fmul.4s	v28, v5, v5
	fmul.4s	v27, v28, v27
	fmul.4s	v28, v3, v25
	fadd.4s	v28, v28, v19
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v15
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v7
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v31
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v4
	fmul.4s	v29, v3, v3
	fmul.4s	v28, v29, v28
	fadd.4s	v3, v3, v28
	fadd.4s	v5, v5, v27
	fadd.4s	v3, v3, v13
	sshr.4s	v27, v26, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v13
	fmul.4s	v3, v3, v28
	fadd.4s	v5, v5, v13
	sshr.4s	v28, v24, #1
	shl.4s	v29, v28, #23
	add.4s	v29, v29, v13
	fmul.4s	v5, v5, v29
	sub.4s	v26, v26, v27
	sub.4s	v24, v24, v28
	shl.4s	v24, v24, #23
	add.4s	v24, v24, v13
	fmul.4s	v5, v5, v24
	shl.4s	v24, v26, #23
	add.4s	v24, v24, v13
	fmul.4s	v3, v3, v24
	fcmgt.4s	v24, v12, v22
	bic.16b	v3, v3, v24
	fcmgt.4s	v24, v12, v23
	bic.16b	v5, v5, v24
	fcmgt.4s	v24, v23, v6
	bit.16b	v5, v21, v24
	fcmgt.4s	v24, v22, v6
	bit.16b	v3, v21, v24
	fcmeq.4s	v22, v22, v22
	bif.16b	v3, v9, v22
	str	q3, [sp, #3392]                 ; 16-byte Spill
	fcmeq.4s	v3, v23, v23
	bsl.16b	v3, v5, v9
	str	q3, [sp, #3376]                 ; 16-byte Spill
	ldr	q3, [sp, #4384]                 ; 16-byte Reload
	ldr	q5, [sp, #3536]                 ; 16-byte Reload
	fsub.4s	v3, v3, v5
	and.16b	v22, v0, v3
	fcmge.4s	v3, v22, v12
	fcmge.4s	v5, v6, v22
	and.16b	v3, v3, v5
	str	q11, [sp, #2832]                ; 16-byte Spill
	ldr	q18, [sp, #4400]                ; 16-byte Reload
	fsub.4s	v5, v18, v11
	and.16b	v23, v1, v5
	fcmge.4s	v5, v23, v12
	fcmge.4s	v24, v6, v23
	and.16b	v5, v5, v24
	and.16b	v5, v5, v23
	fmul.4s	v24, v5, v16
	mvni.4s	v18, #128, lsl #24
	movi.4s	v27, #75, lsl #24
	mov.16b	v26, v18
	bsl.16b	v26, v27, v24
	fadd.4s	v24, v24, v26
	fsub.4s	v24, v24, v26
	and.16b	v3, v3, v22
	fmul.4s	v26, v3, v16
	bif.16b	v27, v26, v18
	movi.4s	v10, #75, lsl #24
	fadd.4s	v26, v26, v27
	fsub.4s	v26, v26, v27
	fcvtzs.4s	v24, v24
	scvtf.4s	v27, v24
	fmul.4s	v28, v27, v8
	fsub.4s	v5, v5, v28
	fcvtzs.4s	v26, v26
	scvtf.4s	v28, v26
	fmul.4s	v29, v28, v8
	fsub.4s	v3, v3, v29
	mov.16b	v30, v20
	fmul.4s	v28, v28, v20
	fsub.4s	v3, v3, v28
	fmul.4s	v27, v27, v20
	fsub.4s	v5, v5, v27
	fmul.4s	v27, v5, v25
	fadd.4s	v27, v27, v19
	fmul.4s	v27, v5, v27
	fadd.4s	v27, v27, v15
	fmul.4s	v27, v5, v27
	fadd.4s	v27, v27, v7
	fmul.4s	v27, v5, v27
	fadd.4s	v27, v27, v31
	fmul.4s	v27, v5, v27
	movi.4s	v20, #63, lsl #24
	fadd.4s	v27, v27, v20
	fmul.4s	v28, v5, v5
	fmul.4s	v27, v28, v27
	fmul.4s	v28, v3, v25
	fadd.4s	v28, v28, v19
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v15
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v7
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v31
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v20
	fmul.4s	v29, v3, v3
	fmul.4s	v28, v29, v28
	fadd.4s	v3, v3, v28
	fadd.4s	v5, v5, v27
	fadd.4s	v3, v3, v13
	sshr.4s	v27, v26, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v13
	fmul.4s	v3, v3, v28
	fadd.4s	v5, v5, v13
	sshr.4s	v28, v24, #1
	shl.4s	v29, v28, #23
	add.4s	v29, v29, v13
	fmul.4s	v5, v5, v29
	sub.4s	v26, v26, v27
	sub.4s	v24, v24, v28
	shl.4s	v24, v24, #23
	add.4s	v24, v24, v13
	fmul.4s	v5, v5, v24
	shl.4s	v24, v26, #23
	add.4s	v24, v24, v13
	fmul.4s	v3, v3, v24
	fcmgt.4s	v24, v12, v22
	bic.16b	v3, v3, v24
	fcmgt.4s	v24, v12, v23
	bic.16b	v5, v5, v24
	fcmgt.4s	v24, v23, v6
	bit.16b	v5, v21, v24
	fcmgt.4s	v24, v22, v6
	bit.16b	v3, v21, v24
	fcmeq.4s	v22, v22, v22
	mov.16b	v11, v22
	bsl.16b	v11, v3, v9
	fcmeq.4s	v3, v23, v23
	bsl.16b	v3, v5, v9
	str	q3, [sp, #3360]                 ; 16-byte Spill
	ldr	q5, [sp, #4432]                 ; 16-byte Reload
	ldr	q3, [sp, #3584]                 ; 16-byte Reload
	fsub.4s	v3, v5, v3
	and.16b	v22, v1, v3
	fcmge.4s	v3, v22, v12
	fcmge.4s	v5, v6, v22
	and.16b	v3, v3, v5
	ldr	q23, [sp, #4416]                ; 16-byte Reload
	ldr	q5, [sp, #3520]                 ; 16-byte Reload
	fsub.4s	v5, v23, v5
	and.16b	v23, v0, v5
	fcmge.4s	v5, v23, v12
	fcmge.4s	v24, v6, v23
	and.16b	v5, v5, v24
	and.16b	v5, v5, v23
	fmul.4s	v24, v5, v16
	mov.16b	v26, v18
	bsl.16b	v26, v10, v24
	fadd.4s	v24, v24, v26
	fsub.4s	v24, v24, v26
	and.16b	v3, v3, v22
	fmul.4s	v26, v3, v16
	mov.16b	v27, v18
	bsl.16b	v27, v10, v26
	fadd.4s	v26, v26, v27
	fsub.4s	v26, v26, v27
	fcvtzs.4s	v24, v24
	scvtf.4s	v27, v24
	fmul.4s	v28, v27, v8
	fsub.4s	v5, v5, v28
	fcvtzs.4s	v26, v26
	scvtf.4s	v28, v26
	fmul.4s	v29, v28, v8
	fsub.4s	v3, v3, v29
	fmul.4s	v28, v28, v30
	fsub.4s	v3, v3, v28
	fmul.4s	v27, v27, v30
	fsub.4s	v5, v5, v27
	fmul.4s	v27, v5, v25
	fadd.4s	v27, v27, v19
	fmul.4s	v27, v5, v27
	fadd.4s	v27, v27, v15
	fmul.4s	v27, v5, v27
	fadd.4s	v27, v27, v7
	fmul.4s	v27, v5, v27
	fadd.4s	v27, v27, v31
	fmul.4s	v27, v5, v27
	fadd.4s	v27, v27, v20
	fmul.4s	v28, v5, v5
	fmul.4s	v27, v28, v27
	fmul.4s	v28, v3, v25
	fadd.4s	v28, v28, v19
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v15
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v7
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v31
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v20
	fmul.4s	v29, v3, v3
	fmul.4s	v28, v29, v28
	fadd.4s	v3, v3, v28
	fadd.4s	v5, v5, v27
	fadd.4s	v3, v3, v13
	sshr.4s	v27, v26, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v13
	fmul.4s	v3, v3, v28
	fadd.4s	v5, v5, v13
	sshr.4s	v28, v24, #1
	shl.4s	v29, v28, #23
	add.4s	v29, v29, v13
	fmul.4s	v5, v5, v29
	sub.4s	v26, v26, v27
	sub.4s	v24, v24, v28
	shl.4s	v24, v24, #23
	add.4s	v24, v24, v13
	fmul.4s	v5, v5, v24
	shl.4s	v24, v26, #23
	add.4s	v24, v24, v13
	fmul.4s	v3, v3, v24
	fcmgt.4s	v24, v12, v22
	bic.16b	v3, v3, v24
	fcmgt.4s	v24, v12, v23
	bic.16b	v5, v5, v24
	fcmgt.4s	v24, v23, v6
	bit.16b	v5, v21, v24
	fcmgt.4s	v24, v22, v6
	bit.16b	v3, v21, v24
	fcmeq.4s	v22, v22, v22
	bif.16b	v3, v9, v22
	str	q3, [sp, #3344]                 ; 16-byte Spill
	fcmeq.4s	v3, v23, v23
	mov.16b	v14, v3
	bsl.16b	v14, v5, v9
	ldr	q5, [sp, #4448]                 ; 16-byte Reload
	ldr	q3, [sp, #3568]                 ; 16-byte Reload
	fsub.4s	v3, v5, v3
	and.16b	v22, v0, v3
	fcmge.4s	v3, v22, v12
	fcmge.4s	v5, v6, v22
	and.16b	v3, v3, v5
	ldr	q18, [sp, #4464]                ; 16-byte Reload
	ldr	q5, [sp, #3504]                 ; 16-byte Reload
	fsub.4s	v5, v18, v5
	and.16b	v23, v1, v5
	fcmge.4s	v5, v23, v12
	fcmge.4s	v24, v6, v23
	and.16b	v5, v5, v24
	and.16b	v5, v5, v23
	fmul.4s	v24, v5, v16
	mvni.4s	v18, #128, lsl #24
	movi.4s	v20, #75, lsl #24
	mov.16b	v26, v18
	bsl.16b	v26, v20, v24
	fadd.4s	v24, v24, v26
	fsub.4s	v24, v24, v26
	and.16b	v3, v3, v22
	fmul.4s	v26, v3, v16
	mov.16b	v27, v18
	bsl.16b	v27, v20, v26
	fadd.4s	v26, v26, v27
	fsub.4s	v26, v26, v27
	fcvtzs.4s	v24, v24
	scvtf.4s	v27, v24
	fmul.4s	v28, v27, v8
	fsub.4s	v5, v5, v28
	fcvtzs.4s	v26, v26
	scvtf.4s	v28, v26
	fmul.4s	v29, v28, v8
	fsub.4s	v3, v3, v29
	fmul.4s	v28, v28, v30
	fsub.4s	v3, v3, v28
	fmul.4s	v27, v27, v30
	mov.16b	v18, v30
	fsub.4s	v5, v5, v27
	fmul.4s	v27, v5, v25
	fadd.4s	v27, v27, v19
	fmul.4s	v27, v5, v27
	fadd.4s	v27, v27, v15
	fmul.4s	v27, v5, v27
	fadd.4s	v27, v27, v7
	fmul.4s	v27, v5, v27
	fadd.4s	v27, v27, v31
	fmul.4s	v27, v5, v27
	movi.4s	v20, #63, lsl #24
	fadd.4s	v27, v27, v20
	fmul.4s	v28, v5, v5
	fmul.4s	v27, v28, v27
	fmul.4s	v28, v3, v25
	fadd.4s	v28, v28, v19
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v15
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v7
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v31
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v20
	fmul.4s	v29, v3, v3
	fmul.4s	v28, v29, v28
	fadd.4s	v3, v3, v28
	fadd.4s	v5, v5, v27
	fadd.4s	v3, v3, v13
	sshr.4s	v27, v26, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v13
	fmul.4s	v3, v3, v28
	fadd.4s	v5, v5, v13
	sshr.4s	v28, v24, #1
	shl.4s	v29, v28, #23
	add.4s	v29, v29, v13
	fmul.4s	v5, v5, v29
	sub.4s	v26, v26, v27
	sub.4s	v24, v24, v28
	shl.4s	v24, v24, #23
	add.4s	v24, v24, v13
	fmul.4s	v5, v5, v24
	shl.4s	v24, v26, #23
	add.4s	v24, v24, v13
	fmul.4s	v3, v3, v24
	fcmgt.4s	v24, v12, v22
	bic.16b	v3, v3, v24
	fcmgt.4s	v24, v12, v23
	bic.16b	v5, v5, v24
	fcmgt.4s	v24, v23, v6
	bit.16b	v5, v21, v24
	fcmgt.4s	v24, v22, v6
	bit.16b	v3, v21, v24
	fcmeq.4s	v22, v22, v22
	mov.16b	v4, v22
	bsl.16b	v4, v3, v9
	fcmeq.4s	v3, v23, v23
	mov.16b	v30, v3
	bsl.16b	v30, v5, v9
	ldr	q5, [sp, #4496]                 ; 16-byte Reload
	ldr	q3, [sp, #3488]                 ; 16-byte Reload
	fsub.4s	v3, v5, v3
	and.16b	v22, v0, v3
	fcmge.4s	v3, v22, v12
	fcmge.4s	v5, v6, v22
	and.16b	v3, v3, v5
	ldr	q5, [sp, #4480]                 ; 16-byte Reload
	ldr	q20, [sp, #3472]                ; 16-byte Reload
	fsub.4s	v5, v5, v20
	and.16b	v23, v1, v5
	fcmge.4s	v5, v23, v12
	fcmge.4s	v24, v6, v23
	and.16b	v5, v5, v24
	and.16b	v5, v5, v23
	fmul.4s	v24, v5, v16
	movi.4s	v27, #75, lsl #24
	mvni.4s	v28, #128, lsl #24
	mov.16b	v26, v28
	bsl.16b	v26, v27, v24
	fadd.4s	v24, v24, v26
	fsub.4s	v24, v24, v26
	and.16b	v3, v3, v22
	fmul.4s	v26, v3, v16
	mvni.4s	v20, #128, lsl #24
	bif.16b	v27, v26, v28
	fadd.4s	v26, v26, v27
	fsub.4s	v26, v26, v27
	fcvtzs.4s	v24, v24
	scvtf.4s	v27, v24
	fmul.4s	v28, v27, v8
	fsub.4s	v5, v5, v28
	fcvtzs.4s	v26, v26
	scvtf.4s	v28, v26
	fmul.4s	v29, v28, v8
	fsub.4s	v3, v3, v29
	fmul.4s	v27, v27, v18
	fmul.4s	v28, v28, v18
	fsub.4s	v3, v3, v28
	fsub.4s	v5, v5, v27
	fmul.4s	v27, v5, v25
	fadd.4s	v27, v27, v19
	fmul.4s	v27, v5, v27
	fadd.4s	v27, v27, v15
	fmul.4s	v27, v5, v27
	fadd.4s	v27, v27, v7
	fmul.4s	v27, v5, v27
	fadd.4s	v27, v27, v31
	fmul.4s	v27, v5, v27
	movi.4s	v29, #63, lsl #24
	fadd.4s	v27, v27, v29
	fmul.4s	v28, v5, v5
	fmul.4s	v27, v28, v27
	fmul.4s	v28, v3, v25
	fadd.4s	v28, v28, v19
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v15
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v7
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v31
	fmul.4s	v28, v3, v28
	movi.4s	v18, #63, lsl #24
	fadd.4s	v28, v28, v29
	fmul.4s	v29, v3, v3
	fmul.4s	v28, v29, v28
	fadd.4s	v3, v3, v28
	fadd.4s	v5, v5, v27
	fadd.4s	v3, v3, v13
	sshr.4s	v27, v26, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v13
	fmul.4s	v3, v3, v28
	fadd.4s	v5, v5, v13
	sshr.4s	v28, v24, #1
	shl.4s	v29, v28, #23
	add.4s	v29, v29, v13
	fmul.4s	v5, v5, v29
	sub.4s	v26, v26, v27
	sub.4s	v24, v24, v28
	shl.4s	v24, v24, #23
	add.4s	v24, v24, v13
	fmul.4s	v5, v5, v24
	ldr	x9, [sp, #512]                  ; 8-byte Reload
	ldr	q24, [x9]
	ldr	q27, [sp, #3440]                ; 16-byte Reload
	bit.16b	v24, v27, v1
	ldr	q27, [x9, #16]
	ldr	q28, [sp, #3456]                ; 16-byte Reload
	bit.16b	v27, v28, v0
	stp	q24, q27, [x9]
	shl.4s	v24, v26, #23
	add.4s	v24, v24, v13
	fmul.4s	v3, v3, v24
	ldr	x9, [sp, #504]                  ; 8-byte Reload
	ldr	q24, [x9]
	ldr	q26, [sp, #3408]                ; 16-byte Reload
	bit.16b	v24, v26, v1
	ldr	q26, [x9, #16]
	ldr	q27, [sp, #3424]                ; 16-byte Reload
	bit.16b	v26, v27, v0
	stp	q24, q26, [x9]
	fcmgt.4s	v24, v12, v22
	bic.16b	v3, v3, v24
	fcmgt.4s	v24, v12, v23
	bic.16b	v5, v5, v24
	ldr	x9, [sp, #496]                  ; 8-byte Reload
	ldr	q24, [x9]
	ldr	q26, [sp, #3376]                ; 16-byte Reload
	bit.16b	v24, v26, v1
	ldr	q26, [x9, #16]
	ldr	q27, [sp, #3392]                ; 16-byte Reload
	bit.16b	v26, v27, v0
	stp	q24, q26, [x9]
	fcmgt.4s	v24, v23, v6
	bit.16b	v5, v21, v24
	fcmgt.4s	v24, v22, v6
	bit.16b	v3, v21, v24
	ldr	x9, [sp, #488]                  ; 8-byte Reload
	ldr	q24, [x9]
	ldr	q26, [sp, #3360]                ; 16-byte Reload
	bit.16b	v24, v26, v1
	ldr	q26, [x9, #16]
	str	q11, [sp, #2784]                ; 16-byte Spill
	bit.16b	v26, v11, v0
	stp	q24, q26, [x9]
	fcmeq.4s	v22, v22, v22
	bsl.16b	v22, v3, v9
	fcmeq.4s	v3, v23, v23
	mov.16b	v23, v3
	bsl.16b	v23, v5, v9
	ldr	x9, [sp, #480]                  ; 8-byte Reload
	ldp	q5, q3, [x9]
	str	q14, [sp, #2768]                ; 16-byte Spill
	bit.16b	v3, v14, v0
	ldr	q24, [sp, #3344]                ; 16-byte Reload
	bit.16b	v5, v24, v1
	stp	q5, q3, [x9]
	ldr	x9, [sp, #472]                  ; 8-byte Reload
	ldp	q3, q5, [x9]
	str	q30, [sp, #2736]                ; 16-byte Spill
	bit.16b	v3, v30, v1
	str	q4, [sp, #2752]                 ; 16-byte Spill
	bit.16b	v5, v4, v0
	stp	q3, q5, [x9]
	ldr	x9, [sp, #464]                  ; 8-byte Reload
	ldp	q3, q5, [x9]
	str	q23, [sp, #2704]                ; 16-byte Spill
	bit.16b	v3, v23, v1
	str	q22, [sp, #2720]                ; 16-byte Spill
	bit.16b	v5, v22, v0
	stp	q3, q5, [x9]
	sshll.2d	v3, v1, #0
	ldr	q5, [sp, #3600]                 ; 16-byte Reload
	ldr	q11, [sp, #2672]                ; 16-byte Reload
	bit.16b	v11, v5, v3
	ldr	q22, [sp, #2448]                ; 16-byte Reload
	ldr	q5, [sp, #5664]                 ; 16-byte Reload
	bit.16b	v5, v22, v3
	str	q5, [sp, #5664]                 ; 16-byte Spill
	sshll.2d	v3, v0, #0
	ldr	q5, [sp, #3616]                 ; 16-byte Reload
	ldr	q4, [sp, #2640]                 ; 16-byte Reload
	bit.16b	v4, v5, v3
	ldr	q5, [sp, #5632]                 ; 16-byte Reload
	bit.16b	v5, v22, v3
	str	q5, [sp, #5632]                 ; 16-byte Spill
	ldr	q3, [sp, #4304]                 ; 16-byte Reload
	ldr	q5, [sp, #3632]                 ; 16-byte Reload
	ldr	q14, [sp, #2656]                ; 16-byte Reload
	bit.16b	v14, v5, v3
	ldr	q5, [sp, #4288]                 ; 16-byte Reload
	ldr	q23, [sp, #2928]                ; 16-byte Reload
	bit.16b	v17, v23, v5
	ldr	q23, [sp, #5648]                ; 16-byte Reload
	bit.16b	v23, v22, v3
	str	q23, [sp, #5648]                ; 16-byte Spill
	ldr	q13, [sp, #2688]                ; 16-byte Reload
	bit.16b	v13, v22, v5
	b	LBB1_392
LBB1_391:                               ; %else1438
                                        ;   in Loop: Header=BB1_392 Depth=3
	add	x24, x24, #1
	add	x22, x22, #4
	add	x27, x27, #2
	add	x21, x21, #8
	cmp	x24, #128
	b.eq	LBB1_424
LBB1_392:                               ; %direct.true632.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	w12, s2
	and	x9, x21, #0x78
	orr	x9, x9, x24, lsr #4
	dup.2d	v23, x9
	ldr	q3, [sp, #5552]                 ; 16-byte Reload
	orr.16b	v3, v23, v3
	ldr	q5, [sp, #5616]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w12, #0, LBB1_394
; %bb.393:                              ; %cond.load1358
                                        ;   in Loop: Header=BB1_392 Depth=3
	fmov	x9, d3
	ldr	b22, [x9]
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB1_395
	b	LBB1_396
LBB1_394:                               ;   in Loop: Header=BB1_392 Depth=3
	movi.2d	v22, #0000000000000000
	and	w12, w12, #0xff
	tbz	w12, #1, LBB1_396
LBB1_395:                               ; %cond.load1364
                                        ;   in Loop: Header=BB1_392 Depth=3
	mov.d	x9, v3[1]
	ld1.b	{ v22 }[1], [x9]
LBB1_396:                               ; %else1368
                                        ;   in Loop: Header=BB1_392 Depth=3
	ldr	q3, [sp, #5536]                 ; 16-byte Reload
	orr.16b	v3, v23, v3
	ldr	q5, [sp, #5600]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w12, #2, LBB1_412
; %bb.397:                              ; %else1374
                                        ;   in Loop: Header=BB1_392 Depth=3
	tbnz	w12, #3, LBB1_413
LBB1_398:                               ; %else1380
                                        ;   in Loop: Header=BB1_392 Depth=3
	ldr	q3, [sp, #5520]                 ; 16-byte Reload
	orr.16b	v3, v23, v3
	ldr	q5, [sp, #5584]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w12, #4, LBB1_414
LBB1_399:                               ; %else1386
                                        ;   in Loop: Header=BB1_392 Depth=3
	tbnz	w12, #5, LBB1_415
LBB1_400:                               ; %else1392
                                        ;   in Loop: Header=BB1_392 Depth=3
	ldr	q3, [sp, #5504]                 ; 16-byte Reload
	orr.16b	v3, v23, v3
	ldr	q5, [sp, #5568]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w12, #6, LBB1_416
LBB1_401:                               ; %else1398
                                        ;   in Loop: Header=BB1_392 Depth=3
	tbz	w12, #7, LBB1_403
LBB1_402:                               ; %cond.load1400
                                        ;   in Loop: Header=BB1_392 Depth=3
	mov.d	x9, v3[1]
	ld1.b	{ v22 }[7], [x9]
LBB1_403:                               ; %else1404
                                        ;   in Loop: Header=BB1_392 Depth=3
	fmov	w12, s2
	cmeq.8b	v3, v22, #0
	sshll.8h	v23, v3, #0
	sshll.4s	v3, v23, #0
	add	x9, x6, x24, lsl #5
	ldp	q5, q26, [x9]
	and	x9, x27, #0xe0
	add	x9, x15, x9
	ldp	q22, q27, [x9]
	fsub.4s	v5, v5, v22
	and.16b	v5, v1, v5
	fcmge.4s	v22, v5, v12
	fcmge.4s	v24, v6, v5
	and.16b	v22, v22, v24
	and.16b	v22, v22, v5
	fmul.4s	v24, v22, v16
	mov.16b	v28, v20
	bsl.16b	v28, v10, v24
	fadd.4s	v24, v24, v28
	fsub.4s	v24, v24, v28
	fcvtzs.4s	v29, v24
	scvtf.4s	v30, v29
	dup.4s	v28, w13
	fmul.4s	v8, v30, v28
	dup.4s	v24, w14
	fadd.4s	v22, v22, v8
	fmul.4s	v30, v30, v24
	fadd.4s	v22, v22, v30
	fmul.4s	v30, v22, v25
	fadd.4s	v30, v30, v19
	fmul.4s	v30, v22, v30
	fadd.4s	v30, v30, v15
	fmul.4s	v30, v22, v30
	fadd.4s	v30, v30, v7
	fmul.4s	v30, v22, v30
	fadd.4s	v30, v30, v31
	fmul.4s	v30, v22, v30
	fadd.4s	v30, v30, v18
	fmul.4s	v8, v22, v22
	fmul.4s	v30, v8, v30
	fadd.4s	v22, v22, v30
	fmov.4s	v9, #1.00000000
	fadd.4s	v22, v22, v9
	sshr.4s	v30, v29, #1
	shl.4s	v8, v30, #23
	add.4s	v8, v8, v9
	fmul.4s	v22, v22, v8
	sub.4s	v29, v29, v30
	shl.4s	v29, v29, #23
	add.4s	v29, v29, v9
	fmul.4s	v22, v22, v29
	fcmgt.4s	v29, v12, v5
	bic.16b	v22, v22, v29
	fcmgt.4s	v29, v5, v6
	bit.16b	v22, v21, v29
	fcmeq.4s	v5, v5, v5
	ldr	q29, [sp, #5296]                ; 16-byte Reload
	bsl.16b	v5, v22, v29
	bic.16b	v3, v5, v3
	dup.2d	v22, x22
	orr.16b	v5, v22, v11
	ldr	q29, [sp, #5664]                ; 16-byte Reload
	add.2d	v5, v29, v5
	tbnz	w12, #0, LBB1_417
; %bb.404:                              ; %else1410
                                        ;   in Loop: Header=BB1_392 Depth=3
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB1_418
LBB1_405:                               ; %else1414
                                        ;   in Loop: Header=BB1_392 Depth=3
	orr.16b	v5, v22, v14
	ldr	q29, [sp, #5648]                ; 16-byte Reload
	add.2d	v5, v29, v5
	tbnz	w12, #2, LBB1_419
LBB1_406:                               ; %else1418
                                        ;   in Loop: Header=BB1_392 Depth=3
	tbz	w12, #3, LBB1_408
LBB1_407:                               ; %cond.store1419
                                        ;   in Loop: Header=BB1_392 Depth=3
	mov.d	x9, v5[1]
	st1.s	{ v3 }[3], [x9]
LBB1_408:                               ; %else1422
                                        ;   in Loop: Header=BB1_392 Depth=3
	sshll2.4s	v3, v23, #0
	fsub.4s	v5, v26, v27
	and.16b	v5, v0, v5
	fcmge.4s	v23, v5, v12
	fcmge.4s	v26, v6, v5
	and.16b	v23, v23, v26
	and.16b	v23, v23, v5
	fmul.4s	v26, v23, v16
	mov.16b	v27, v20
	bsl.16b	v27, v10, v26
	fadd.4s	v26, v26, v27
	fsub.4s	v26, v26, v27
	fcvtzs.4s	v26, v26
	scvtf.4s	v27, v26
	fmul.4s	v28, v27, v28
	fadd.4s	v23, v23, v28
	fmul.4s	v24, v27, v24
	fadd.4s	v23, v23, v24
	fmul.4s	v24, v23, v25
	fadd.4s	v24, v24, v19
	fmul.4s	v24, v23, v24
	fadd.4s	v24, v24, v15
	fmul.4s	v24, v23, v24
	fadd.4s	v24, v24, v7
	fmul.4s	v24, v23, v24
	fadd.4s	v24, v24, v31
	fmul.4s	v24, v23, v24
	fadd.4s	v24, v24, v18
	fmul.4s	v27, v23, v23
	fmul.4s	v24, v27, v24
	fadd.4s	v23, v23, v24
	fmov.4s	v28, #1.00000000
	fadd.4s	v23, v23, v28
	sshr.4s	v24, v26, #1
	shl.4s	v27, v24, #23
	add.4s	v27, v27, v28
	fmul.4s	v23, v23, v27
	sub.4s	v24, v26, v24
	shl.4s	v24, v24, #23
	add.4s	v24, v24, v28
	fmul.4s	v23, v23, v24
	fcmgt.4s	v24, v12, v5
	bic.16b	v23, v23, v24
	fcmgt.4s	v24, v5, v6
	bit.16b	v23, v21, v24
	fcmeq.4s	v5, v5, v5
	ldr	q24, [sp, #5296]                ; 16-byte Reload
	bsl.16b	v5, v23, v24
	bic.16b	v3, v5, v3
	orr.16b	v5, v22, v4
	ldr	q23, [sp, #5632]                ; 16-byte Reload
	add.2d	v5, v23, v5
	tbnz	w12, #4, LBB1_420
; %bb.409:                              ; %else1426
                                        ;   in Loop: Header=BB1_392 Depth=3
	tbnz	w12, #5, LBB1_421
LBB1_410:                               ; %else1430
                                        ;   in Loop: Header=BB1_392 Depth=3
	orr.16b	v5, v22, v17
	add.2d	v5, v13, v5
	tbnz	w12, #6, LBB1_422
LBB1_411:                               ; %else1434
                                        ;   in Loop: Header=BB1_392 Depth=3
	tbz	w12, #7, LBB1_391
	b	LBB1_423
LBB1_412:                               ; %cond.load1370
                                        ;   in Loop: Header=BB1_392 Depth=3
	fmov	x9, d3
	ld1.b	{ v22 }[2], [x9]
	tbz	w12, #3, LBB1_398
LBB1_413:                               ; %cond.load1376
                                        ;   in Loop: Header=BB1_392 Depth=3
	mov.d	x9, v3[1]
	ld1.b	{ v22 }[3], [x9]
	ldr	q3, [sp, #5520]                 ; 16-byte Reload
	orr.16b	v3, v23, v3
	ldr	q5, [sp, #5584]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w12, #4, LBB1_399
LBB1_414:                               ; %cond.load1382
                                        ;   in Loop: Header=BB1_392 Depth=3
	fmov	x9, d3
	ld1.b	{ v22 }[4], [x9]
	tbz	w12, #5, LBB1_400
LBB1_415:                               ; %cond.load1388
                                        ;   in Loop: Header=BB1_392 Depth=3
	mov.d	x9, v3[1]
	ld1.b	{ v22 }[5], [x9]
	ldr	q3, [sp, #5504]                 ; 16-byte Reload
	orr.16b	v3, v23, v3
	ldr	q5, [sp, #5568]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w12, #6, LBB1_401
LBB1_416:                               ; %cond.load1394
                                        ;   in Loop: Header=BB1_392 Depth=3
	fmov	x9, d3
	ld1.b	{ v22 }[6], [x9]
	tbnz	w12, #7, LBB1_402
	b	LBB1_403
LBB1_417:                               ; %cond.store1407
                                        ;   in Loop: Header=BB1_392 Depth=3
	fmov	x9, d5
	str	s3, [x9]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB1_405
LBB1_418:                               ; %cond.store1411
                                        ;   in Loop: Header=BB1_392 Depth=3
	mov.d	x9, v5[1]
	st1.s	{ v3 }[1], [x9]
	orr.16b	v5, v22, v14
	ldr	q29, [sp, #5648]                ; 16-byte Reload
	add.2d	v5, v29, v5
	tbz	w12, #2, LBB1_406
LBB1_419:                               ; %cond.store1415
                                        ;   in Loop: Header=BB1_392 Depth=3
	fmov	x9, d5
	st1.s	{ v3 }[2], [x9]
	tbnz	w12, #3, LBB1_407
	b	LBB1_408
LBB1_420:                               ; %cond.store1423
                                        ;   in Loop: Header=BB1_392 Depth=3
	fmov	x9, d5
	str	s3, [x9]
	tbz	w12, #5, LBB1_410
LBB1_421:                               ; %cond.store1427
                                        ;   in Loop: Header=BB1_392 Depth=3
	mov.d	x9, v5[1]
	st1.s	{ v3 }[1], [x9]
	orr.16b	v5, v22, v17
	add.2d	v5, v13, v5
	tbz	w12, #6, LBB1_411
LBB1_422:                               ; %cond.store1431
                                        ;   in Loop: Header=BB1_392 Depth=3
	fmov	x9, d5
	st1.s	{ v3 }[2], [x9]
	tbz	w12, #7, LBB1_391
LBB1_423:                               ; %cond.store1435
                                        ;   in Loop: Header=BB1_392 Depth=3
	mov.d	x9, v5[1]
	st1.s	{ v3 }[3], [x9]
	b	LBB1_391
LBB1_424:                               ; %direct.false633.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	q18, [sp, #2400]                ; 16-byte Reload
	ldr	q3, [sp, #5312]                 ; 16-byte Reload
	and.16b	v3, v18, v3
	str	q3, [sp, #5312]                 ; 16-byte Spill
	ldr	q20, [sp, #2384]                ; 16-byte Reload
	ldr	q3, [sp, #5328]                 ; 16-byte Reload
	and.16b	v3, v20, v3
	str	q3, [sp, #5328]                 ; 16-byte Spill
	mov	w14, #320                       ; =0x140
	ldr	q27, [sp, #4304]                ; 16-byte Reload
	ldr	w22, [sp, #2624]                ; 4-byte Reload
	ldr	q10, [sp, #4288]                ; 16-byte Reload
	ldr	w24, [sp, #2620]                ; 4-byte Reload
	ldr	w27, [sp, #2612]                ; 4-byte Reload
	ldr	q19, [sp, #3200]                ; 16-byte Reload
	ldr	q21, [sp, #3184]                ; 16-byte Reload
	ldr	q22, [sp, #3168]                ; 16-byte Reload
	ldr	q23, [sp, #3312]                ; 16-byte Reload
	ldr	q24, [sp, #3152]                ; 16-byte Reload
	ldr	q25, [sp, #3136]                ; 16-byte Reload
	ldr	q29, [sp, #3120]                ; 16-byte Reload
	ldr	q30, [sp, #3296]                ; 16-byte Reload
	ldr	q31, [sp, #4256]                ; 16-byte Reload
	ldr	q8, [sp, #4240]                 ; 16-byte Reload
	ldr	q12, [sp, #4224]                ; 16-byte Reload
	ldr	q15, [sp, #4208]                ; 16-byte Reload
	ldr	q26, [sp, #3648]                ; 16-byte Reload
	b	LBB1_426
LBB1_425:                               ; %else1486
                                        ;   in Loop: Header=BB1_426 Depth=3
	ldr	q16, [sp, #5328]                ; 16-byte Reload
	fadd.4s	v3, v16, v6
	ldr	q6, [sp, #5312]                 ; 16-byte Reload
	fadd.4s	v5, v6, v7
	bit.16b	v6, v5, v0
	str	q6, [sp, #5312]                 ; 16-byte Spill
	bit.16b	v16, v3, v1
	str	q16, [sp, #5328]                ; 16-byte Spill
	add	x12, x12, #4
	cmp	x12, #64
	b.eq	LBB1_442
LBB1_426:                               ; %direct.true672.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	w13, s2
	dup.2d	v16, x12
	orr.16b	v3, v16, v11
	ldr	q5, [sp, #5664]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	tbnz	w13, #0, LBB1_434
; %bb.427:                              ; %else1444
                                        ;   in Loop: Header=BB1_426 Depth=3
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_435
LBB1_428:                               ; %else1450
                                        ;   in Loop: Header=BB1_426 Depth=3
	orr.16b	v3, v16, v14
	ldr	q5, [sp, #5648]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w13, #2, LBB1_436
LBB1_429:                               ; %else1456
                                        ;   in Loop: Header=BB1_426 Depth=3
	tbnz	w13, #3, LBB1_437
LBB1_430:                               ; %else1462
                                        ;   in Loop: Header=BB1_426 Depth=3
	orr.16b	v3, v16, v4
	ldr	q5, [sp, #5632]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w13, #4, LBB1_438
LBB1_431:                               ; %else1468
                                        ;   in Loop: Header=BB1_426 Depth=3
	tbnz	w13, #5, LBB1_439
LBB1_432:                               ; %else1474
                                        ;   in Loop: Header=BB1_426 Depth=3
	orr.16b	v3, v16, v17
	add.2d	v3, v13, v3
	tbnz	w13, #6, LBB1_440
LBB1_433:                               ; %else1480
                                        ;   in Loop: Header=BB1_426 Depth=3
	tbz	w13, #7, LBB1_425
	b	LBB1_441
LBB1_434:                               ; %cond.load1440
                                        ;   in Loop: Header=BB1_426 Depth=3
	fmov	x9, d3
	ldr	s6, [x9]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_428
LBB1_435:                               ; %cond.load1446
                                        ;   in Loop: Header=BB1_426 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v6 }[1], [x9]
	orr.16b	v3, v16, v14
	ldr	q5, [sp, #5648]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w13, #2, LBB1_429
LBB1_436:                               ; %cond.load1452
                                        ;   in Loop: Header=BB1_426 Depth=3
	fmov	x9, d3
	ld1.s	{ v6 }[2], [x9]
	tbz	w13, #3, LBB1_430
LBB1_437:                               ; %cond.load1458
                                        ;   in Loop: Header=BB1_426 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v6 }[3], [x9]
	orr.16b	v3, v16, v4
	ldr	q5, [sp, #5632]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w13, #4, LBB1_431
LBB1_438:                               ; %cond.load1464
                                        ;   in Loop: Header=BB1_426 Depth=3
	fmov	x9, d3
	ld1.s	{ v7 }[0], [x9]
	tbz	w13, #5, LBB1_432
LBB1_439:                               ; %cond.load1470
                                        ;   in Loop: Header=BB1_426 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v7 }[1], [x9]
	orr.16b	v3, v16, v17
	add.2d	v3, v13, v3
	tbz	w13, #6, LBB1_433
LBB1_440:                               ; %cond.load1476
                                        ;   in Loop: Header=BB1_426 Depth=3
	fmov	x9, d3
	ld1.s	{ v7 }[2], [x9]
	tbz	w13, #7, LBB1_425
LBB1_441:                               ; %cond.load1482
                                        ;   in Loop: Header=BB1_426 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v7 }[3], [x9]
	b	LBB1_425
LBB1_442:                               ; %direct.false673.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	q3, [sp, #5344]                 ; 16-byte Reload
	and.16b	v3, v18, v3
	str	q3, [sp, #5344]                 ; 16-byte Spill
	ldr	q3, [sp, #5360]                 ; 16-byte Reload
	and.16b	v3, v20, v3
	str	q3, [sp, #5360]                 ; 16-byte Spill
	b	LBB1_444
LBB1_443:                               ; %else1535
                                        ;   in Loop: Header=BB1_444 Depth=3
	ldr	q16, [sp, #5360]                ; 16-byte Reload
	fadd.4s	v3, v16, v6
	ldr	q6, [sp, #5344]                 ; 16-byte Reload
	fadd.4s	v5, v6, v7
	bit.16b	v6, v5, v0
	str	q6, [sp, #5344]                 ; 16-byte Spill
	bit.16b	v16, v3, v1
	str	q16, [sp, #5360]                ; 16-byte Spill
	add	x12, x12, #4
	cmp	x12, #64
	b.eq	LBB1_460
LBB1_444:                               ; %direct.true682.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	w13, s2
	orr	x9, x12, #0x40
	dup.2d	v16, x9
	orr.16b	v3, v16, v11
	ldr	q5, [sp, #5664]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	tbnz	w13, #0, LBB1_452
; %bb.445:                              ; %else1493
                                        ;   in Loop: Header=BB1_444 Depth=3
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_453
LBB1_446:                               ; %else1499
                                        ;   in Loop: Header=BB1_444 Depth=3
	orr.16b	v3, v16, v14
	ldr	q5, [sp, #5648]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w13, #2, LBB1_454
LBB1_447:                               ; %else1505
                                        ;   in Loop: Header=BB1_444 Depth=3
	tbnz	w13, #3, LBB1_455
LBB1_448:                               ; %else1511
                                        ;   in Loop: Header=BB1_444 Depth=3
	orr.16b	v3, v16, v4
	ldr	q5, [sp, #5632]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w13, #4, LBB1_456
LBB1_449:                               ; %else1517
                                        ;   in Loop: Header=BB1_444 Depth=3
	tbnz	w13, #5, LBB1_457
LBB1_450:                               ; %else1523
                                        ;   in Loop: Header=BB1_444 Depth=3
	orr.16b	v3, v16, v17
	add.2d	v3, v13, v3
	tbnz	w13, #6, LBB1_458
LBB1_451:                               ; %else1529
                                        ;   in Loop: Header=BB1_444 Depth=3
	tbz	w13, #7, LBB1_443
	b	LBB1_459
LBB1_452:                               ; %cond.load1489
                                        ;   in Loop: Header=BB1_444 Depth=3
	fmov	x9, d3
	ldr	s6, [x9]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_446
LBB1_453:                               ; %cond.load1495
                                        ;   in Loop: Header=BB1_444 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v6 }[1], [x9]
	orr.16b	v3, v16, v14
	ldr	q5, [sp, #5648]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w13, #2, LBB1_447
LBB1_454:                               ; %cond.load1501
                                        ;   in Loop: Header=BB1_444 Depth=3
	fmov	x9, d3
	ld1.s	{ v6 }[2], [x9]
	tbz	w13, #3, LBB1_448
LBB1_455:                               ; %cond.load1507
                                        ;   in Loop: Header=BB1_444 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v6 }[3], [x9]
	orr.16b	v3, v16, v4
	ldr	q5, [sp, #5632]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w13, #4, LBB1_449
LBB1_456:                               ; %cond.load1513
                                        ;   in Loop: Header=BB1_444 Depth=3
	fmov	x9, d3
	ld1.s	{ v7 }[0], [x9]
	tbz	w13, #5, LBB1_450
LBB1_457:                               ; %cond.load1519
                                        ;   in Loop: Header=BB1_444 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v7 }[1], [x9]
	orr.16b	v3, v16, v17
	add.2d	v3, v13, v3
	tbz	w13, #6, LBB1_451
LBB1_458:                               ; %cond.load1525
                                        ;   in Loop: Header=BB1_444 Depth=3
	fmov	x9, d3
	ld1.s	{ v7 }[2], [x9]
	tbz	w13, #7, LBB1_443
LBB1_459:                               ; %cond.load1531
                                        ;   in Loop: Header=BB1_444 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v7 }[3], [x9]
	b	LBB1_443
LBB1_460:                               ; %direct.false683.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	q3, [sp, #5376]                 ; 16-byte Reload
	and.16b	v3, v18, v3
	str	q3, [sp, #5376]                 ; 16-byte Spill
	ldr	q3, [sp, #5392]                 ; 16-byte Reload
	and.16b	v3, v20, v3
	str	q3, [sp, #5392]                 ; 16-byte Spill
	b	LBB1_462
LBB1_461:                               ; %else1584
                                        ;   in Loop: Header=BB1_462 Depth=3
	ldr	q16, [sp, #5392]                ; 16-byte Reload
	fadd.4s	v3, v16, v6
	ldr	q6, [sp, #5376]                 ; 16-byte Reload
	fadd.4s	v5, v6, v7
	bit.16b	v6, v5, v0
	str	q6, [sp, #5376]                 ; 16-byte Spill
	bit.16b	v16, v3, v1
	str	q16, [sp, #5392]                ; 16-byte Spill
	add	x12, x12, #4
	cmp	x12, #64
	b.eq	LBB1_478
LBB1_462:                               ; %direct.true692.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	w13, s2
	orr	x9, x12, #0x80
	dup.2d	v16, x9
	orr.16b	v3, v16, v11
	ldr	q5, [sp, #5664]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	tbnz	w13, #0, LBB1_470
; %bb.463:                              ; %else1542
                                        ;   in Loop: Header=BB1_462 Depth=3
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_471
LBB1_464:                               ; %else1548
                                        ;   in Loop: Header=BB1_462 Depth=3
	orr.16b	v3, v16, v14
	ldr	q5, [sp, #5648]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w13, #2, LBB1_472
LBB1_465:                               ; %else1554
                                        ;   in Loop: Header=BB1_462 Depth=3
	tbnz	w13, #3, LBB1_473
LBB1_466:                               ; %else1560
                                        ;   in Loop: Header=BB1_462 Depth=3
	orr.16b	v3, v16, v4
	ldr	q5, [sp, #5632]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w13, #4, LBB1_474
LBB1_467:                               ; %else1566
                                        ;   in Loop: Header=BB1_462 Depth=3
	tbnz	w13, #5, LBB1_475
LBB1_468:                               ; %else1572
                                        ;   in Loop: Header=BB1_462 Depth=3
	orr.16b	v3, v16, v17
	add.2d	v3, v13, v3
	tbnz	w13, #6, LBB1_476
LBB1_469:                               ; %else1578
                                        ;   in Loop: Header=BB1_462 Depth=3
	tbz	w13, #7, LBB1_461
	b	LBB1_477
LBB1_470:                               ; %cond.load1538
                                        ;   in Loop: Header=BB1_462 Depth=3
	fmov	x9, d3
	ldr	s6, [x9]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_464
LBB1_471:                               ; %cond.load1544
                                        ;   in Loop: Header=BB1_462 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v6 }[1], [x9]
	orr.16b	v3, v16, v14
	ldr	q5, [sp, #5648]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w13, #2, LBB1_465
LBB1_472:                               ; %cond.load1550
                                        ;   in Loop: Header=BB1_462 Depth=3
	fmov	x9, d3
	ld1.s	{ v6 }[2], [x9]
	tbz	w13, #3, LBB1_466
LBB1_473:                               ; %cond.load1556
                                        ;   in Loop: Header=BB1_462 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v6 }[3], [x9]
	orr.16b	v3, v16, v4
	ldr	q5, [sp, #5632]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w13, #4, LBB1_467
LBB1_474:                               ; %cond.load1562
                                        ;   in Loop: Header=BB1_462 Depth=3
	fmov	x9, d3
	ld1.s	{ v7 }[0], [x9]
	tbz	w13, #5, LBB1_468
LBB1_475:                               ; %cond.load1568
                                        ;   in Loop: Header=BB1_462 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v7 }[1], [x9]
	orr.16b	v3, v16, v17
	add.2d	v3, v13, v3
	tbz	w13, #6, LBB1_469
LBB1_476:                               ; %cond.load1574
                                        ;   in Loop: Header=BB1_462 Depth=3
	fmov	x9, d3
	ld1.s	{ v7 }[2], [x9]
	tbz	w13, #7, LBB1_461
LBB1_477:                               ; %cond.load1580
                                        ;   in Loop: Header=BB1_462 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v7 }[3], [x9]
	b	LBB1_461
LBB1_478:                               ; %direct.false693.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	q3, [sp, #5408]                 ; 16-byte Reload
	and.16b	v3, v18, v3
	str	q3, [sp, #5408]                 ; 16-byte Spill
	ldr	q3, [sp, #5424]                 ; 16-byte Reload
	and.16b	v3, v20, v3
	str	q3, [sp, #5424]                 ; 16-byte Spill
	b	LBB1_480
LBB1_479:                               ; %else1633
                                        ;   in Loop: Header=BB1_480 Depth=3
	ldr	q16, [sp, #5424]                ; 16-byte Reload
	fadd.4s	v3, v16, v6
	ldr	q6, [sp, #5408]                 ; 16-byte Reload
	fadd.4s	v5, v6, v7
	bit.16b	v6, v5, v0
	str	q6, [sp, #5408]                 ; 16-byte Spill
	bit.16b	v16, v3, v1
	str	q16, [sp, #5424]                ; 16-byte Spill
	add	x12, x12, #4
	cmp	x12, #64
	b.eq	LBB1_496
LBB1_480:                               ; %direct.true702.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	w13, s2
	orr	x9, x12, #0xc0
	dup.2d	v16, x9
	orr.16b	v3, v16, v11
	ldr	q5, [sp, #5664]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	tbnz	w13, #0, LBB1_488
; %bb.481:                              ; %else1591
                                        ;   in Loop: Header=BB1_480 Depth=3
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_489
LBB1_482:                               ; %else1597
                                        ;   in Loop: Header=BB1_480 Depth=3
	orr.16b	v3, v16, v14
	ldr	q5, [sp, #5648]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w13, #2, LBB1_490
LBB1_483:                               ; %else1603
                                        ;   in Loop: Header=BB1_480 Depth=3
	tbnz	w13, #3, LBB1_491
LBB1_484:                               ; %else1609
                                        ;   in Loop: Header=BB1_480 Depth=3
	orr.16b	v3, v16, v4
	ldr	q5, [sp, #5632]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w13, #4, LBB1_492
LBB1_485:                               ; %else1615
                                        ;   in Loop: Header=BB1_480 Depth=3
	tbnz	w13, #5, LBB1_493
LBB1_486:                               ; %else1621
                                        ;   in Loop: Header=BB1_480 Depth=3
	orr.16b	v3, v16, v17
	add.2d	v3, v13, v3
	tbnz	w13, #6, LBB1_494
LBB1_487:                               ; %else1627
                                        ;   in Loop: Header=BB1_480 Depth=3
	tbz	w13, #7, LBB1_479
	b	LBB1_495
LBB1_488:                               ; %cond.load1587
                                        ;   in Loop: Header=BB1_480 Depth=3
	fmov	x9, d3
	ldr	s6, [x9]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_482
LBB1_489:                               ; %cond.load1593
                                        ;   in Loop: Header=BB1_480 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v6 }[1], [x9]
	orr.16b	v3, v16, v14
	ldr	q5, [sp, #5648]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w13, #2, LBB1_483
LBB1_490:                               ; %cond.load1599
                                        ;   in Loop: Header=BB1_480 Depth=3
	fmov	x9, d3
	ld1.s	{ v6 }[2], [x9]
	tbz	w13, #3, LBB1_484
LBB1_491:                               ; %cond.load1605
                                        ;   in Loop: Header=BB1_480 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v6 }[3], [x9]
	orr.16b	v3, v16, v4
	ldr	q5, [sp, #5632]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w13, #4, LBB1_485
LBB1_492:                               ; %cond.load1611
                                        ;   in Loop: Header=BB1_480 Depth=3
	fmov	x9, d3
	ld1.s	{ v7 }[0], [x9]
	tbz	w13, #5, LBB1_486
LBB1_493:                               ; %cond.load1617
                                        ;   in Loop: Header=BB1_480 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v7 }[1], [x9]
	orr.16b	v3, v16, v17
	add.2d	v3, v13, v3
	tbz	w13, #6, LBB1_487
LBB1_494:                               ; %cond.load1623
                                        ;   in Loop: Header=BB1_480 Depth=3
	fmov	x9, d3
	ld1.s	{ v7 }[2], [x9]
	tbz	w13, #7, LBB1_479
LBB1_495:                               ; %cond.load1629
                                        ;   in Loop: Header=BB1_480 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v7 }[3], [x9]
	b	LBB1_479
LBB1_496:                               ; %direct.false703.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	q3, [sp, #5440]                 ; 16-byte Reload
	and.16b	v3, v18, v3
	str	q3, [sp, #5440]                 ; 16-byte Spill
	ldr	q3, [sp, #5456]                 ; 16-byte Reload
	and.16b	v3, v20, v3
	str	q3, [sp, #5456]                 ; 16-byte Spill
	b	LBB1_498
LBB1_497:                               ; %else1682
                                        ;   in Loop: Header=BB1_498 Depth=3
	ldr	q16, [sp, #5456]                ; 16-byte Reload
	fadd.4s	v3, v16, v6
	ldr	q6, [sp, #5440]                 ; 16-byte Reload
	fadd.4s	v5, v6, v7
	bit.16b	v6, v5, v0
	str	q6, [sp, #5440]                 ; 16-byte Spill
	bit.16b	v16, v3, v1
	str	q16, [sp, #5456]                ; 16-byte Spill
	add	x12, x12, #4
	cmp	x12, #64
	b.eq	LBB1_514
LBB1_498:                               ; %direct.true712.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	w13, s2
	orr	x9, x12, #0x100
	dup.2d	v16, x9
	orr.16b	v3, v16, v11
	ldr	q5, [sp, #5664]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	tbnz	w13, #0, LBB1_506
; %bb.499:                              ; %else1640
                                        ;   in Loop: Header=BB1_498 Depth=3
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_507
LBB1_500:                               ; %else1646
                                        ;   in Loop: Header=BB1_498 Depth=3
	orr.16b	v3, v16, v14
	ldr	q5, [sp, #5648]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w13, #2, LBB1_508
LBB1_501:                               ; %else1652
                                        ;   in Loop: Header=BB1_498 Depth=3
	tbnz	w13, #3, LBB1_509
LBB1_502:                               ; %else1658
                                        ;   in Loop: Header=BB1_498 Depth=3
	orr.16b	v3, v16, v4
	ldr	q5, [sp, #5632]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w13, #4, LBB1_510
LBB1_503:                               ; %else1664
                                        ;   in Loop: Header=BB1_498 Depth=3
	tbnz	w13, #5, LBB1_511
LBB1_504:                               ; %else1670
                                        ;   in Loop: Header=BB1_498 Depth=3
	orr.16b	v3, v16, v17
	add.2d	v3, v13, v3
	tbnz	w13, #6, LBB1_512
LBB1_505:                               ; %else1676
                                        ;   in Loop: Header=BB1_498 Depth=3
	tbz	w13, #7, LBB1_497
	b	LBB1_513
LBB1_506:                               ; %cond.load1636
                                        ;   in Loop: Header=BB1_498 Depth=3
	fmov	x9, d3
	ldr	s6, [x9]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_500
LBB1_507:                               ; %cond.load1642
                                        ;   in Loop: Header=BB1_498 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v6 }[1], [x9]
	orr.16b	v3, v16, v14
	ldr	q5, [sp, #5648]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w13, #2, LBB1_501
LBB1_508:                               ; %cond.load1648
                                        ;   in Loop: Header=BB1_498 Depth=3
	fmov	x9, d3
	ld1.s	{ v6 }[2], [x9]
	tbz	w13, #3, LBB1_502
LBB1_509:                               ; %cond.load1654
                                        ;   in Loop: Header=BB1_498 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v6 }[3], [x9]
	orr.16b	v3, v16, v4
	ldr	q5, [sp, #5632]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w13, #4, LBB1_503
LBB1_510:                               ; %cond.load1660
                                        ;   in Loop: Header=BB1_498 Depth=3
	fmov	x9, d3
	ld1.s	{ v7 }[0], [x9]
	tbz	w13, #5, LBB1_504
LBB1_511:                               ; %cond.load1666
                                        ;   in Loop: Header=BB1_498 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v7 }[1], [x9]
	orr.16b	v3, v16, v17
	add.2d	v3, v13, v3
	tbz	w13, #6, LBB1_505
LBB1_512:                               ; %cond.load1672
                                        ;   in Loop: Header=BB1_498 Depth=3
	fmov	x9, d3
	ld1.s	{ v7 }[2], [x9]
	tbz	w13, #7, LBB1_497
LBB1_513:                               ; %cond.load1678
                                        ;   in Loop: Header=BB1_498 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v7 }[3], [x9]
	b	LBB1_497
LBB1_514:                               ; %direct.false713.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	q3, [sp, #5472]                 ; 16-byte Reload
	and.16b	v3, v18, v3
	str	q3, [sp, #5472]                 ; 16-byte Spill
	ldr	q3, [sp, #5488]                 ; 16-byte Reload
	and.16b	v3, v20, v3
	str	q3, [sp, #5488]                 ; 16-byte Spill
	b	LBB1_516
LBB1_515:                               ; %else1731
                                        ;   in Loop: Header=BB1_516 Depth=3
	ldr	q16, [sp, #5488]                ; 16-byte Reload
	fadd.4s	v3, v16, v6
	ldr	q6, [sp, #5472]                 ; 16-byte Reload
	fadd.4s	v5, v6, v7
	bit.16b	v6, v5, v0
	str	q6, [sp, #5472]                 ; 16-byte Spill
	bit.16b	v16, v3, v1
	str	q16, [sp, #5488]                ; 16-byte Spill
	add	x12, x12, #4
	cmp	x12, #64
	b.eq	LBB1_532
LBB1_516:                               ; %direct.true722.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	w13, s2
	orr	x9, x12, x14
	dup.2d	v16, x9
	orr.16b	v3, v16, v11
	ldr	q5, [sp, #5664]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	tbnz	w13, #0, LBB1_524
; %bb.517:                              ; %else1689
                                        ;   in Loop: Header=BB1_516 Depth=3
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_525
LBB1_518:                               ; %else1695
                                        ;   in Loop: Header=BB1_516 Depth=3
	orr.16b	v3, v16, v14
	ldr	q5, [sp, #5648]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w13, #2, LBB1_526
LBB1_519:                               ; %else1701
                                        ;   in Loop: Header=BB1_516 Depth=3
	tbnz	w13, #3, LBB1_527
LBB1_520:                               ; %else1707
                                        ;   in Loop: Header=BB1_516 Depth=3
	orr.16b	v3, v16, v4
	ldr	q5, [sp, #5632]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w13, #4, LBB1_528
LBB1_521:                               ; %else1713
                                        ;   in Loop: Header=BB1_516 Depth=3
	tbnz	w13, #5, LBB1_529
LBB1_522:                               ; %else1719
                                        ;   in Loop: Header=BB1_516 Depth=3
	orr.16b	v3, v16, v17
	add.2d	v3, v13, v3
	tbnz	w13, #6, LBB1_530
LBB1_523:                               ; %else1725
                                        ;   in Loop: Header=BB1_516 Depth=3
	tbz	w13, #7, LBB1_515
	b	LBB1_531
LBB1_524:                               ; %cond.load1685
                                        ;   in Loop: Header=BB1_516 Depth=3
	fmov	x9, d3
	ldr	s6, [x9]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_518
LBB1_525:                               ; %cond.load1691
                                        ;   in Loop: Header=BB1_516 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v6 }[1], [x9]
	orr.16b	v3, v16, v14
	ldr	q5, [sp, #5648]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w13, #2, LBB1_519
LBB1_526:                               ; %cond.load1697
                                        ;   in Loop: Header=BB1_516 Depth=3
	fmov	x9, d3
	ld1.s	{ v6 }[2], [x9]
	tbz	w13, #3, LBB1_520
LBB1_527:                               ; %cond.load1703
                                        ;   in Loop: Header=BB1_516 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v6 }[3], [x9]
	orr.16b	v3, v16, v4
	ldr	q5, [sp, #5632]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w13, #4, LBB1_521
LBB1_528:                               ; %cond.load1709
                                        ;   in Loop: Header=BB1_516 Depth=3
	fmov	x9, d3
	ld1.s	{ v7 }[0], [x9]
	tbz	w13, #5, LBB1_522
LBB1_529:                               ; %cond.load1715
                                        ;   in Loop: Header=BB1_516 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v7 }[1], [x9]
	orr.16b	v3, v16, v17
	add.2d	v3, v13, v3
	tbz	w13, #6, LBB1_523
LBB1_530:                               ; %cond.load1721
                                        ;   in Loop: Header=BB1_516 Depth=3
	fmov	x9, d3
	ld1.s	{ v7 }[2], [x9]
	tbz	w13, #7, LBB1_515
LBB1_531:                               ; %cond.load1727
                                        ;   in Loop: Header=BB1_516 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v7 }[3], [x9]
	b	LBB1_515
LBB1_532:                               ; %direct.false723.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	and.16b	v15, v18, v15
	and.16b	v12, v20, v12
	b	LBB1_534
LBB1_533:                               ; %else1780
                                        ;   in Loop: Header=BB1_534 Depth=3
	fadd.4s	v3, v12, v6
	fadd.4s	v5, v15, v7
	bit.16b	v15, v5, v0
	bit.16b	v12, v3, v1
	add	x12, x12, #4
	cmp	x12, #64
	b.eq	LBB1_550
LBB1_534:                               ; %direct.true732.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	w13, s2
	orr	x9, x12, #0x180
	dup.2d	v16, x9
	orr.16b	v3, v16, v11
	ldr	q5, [sp, #5664]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	tbnz	w13, #0, LBB1_542
; %bb.535:                              ; %else1738
                                        ;   in Loop: Header=BB1_534 Depth=3
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_543
LBB1_536:                               ; %else1744
                                        ;   in Loop: Header=BB1_534 Depth=3
	orr.16b	v3, v16, v14
	ldr	q5, [sp, #5648]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w13, #2, LBB1_544
LBB1_537:                               ; %else1750
                                        ;   in Loop: Header=BB1_534 Depth=3
	tbnz	w13, #3, LBB1_545
LBB1_538:                               ; %else1756
                                        ;   in Loop: Header=BB1_534 Depth=3
	orr.16b	v3, v16, v4
	ldr	q5, [sp, #5632]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w13, #4, LBB1_546
LBB1_539:                               ; %else1762
                                        ;   in Loop: Header=BB1_534 Depth=3
	tbnz	w13, #5, LBB1_547
LBB1_540:                               ; %else1768
                                        ;   in Loop: Header=BB1_534 Depth=3
	orr.16b	v3, v16, v17
	add.2d	v3, v13, v3
	tbnz	w13, #6, LBB1_548
LBB1_541:                               ; %else1774
                                        ;   in Loop: Header=BB1_534 Depth=3
	tbz	w13, #7, LBB1_533
	b	LBB1_549
LBB1_542:                               ; %cond.load1734
                                        ;   in Loop: Header=BB1_534 Depth=3
	fmov	x9, d3
	ldr	s6, [x9]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_536
LBB1_543:                               ; %cond.load1740
                                        ;   in Loop: Header=BB1_534 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v6 }[1], [x9]
	orr.16b	v3, v16, v14
	ldr	q5, [sp, #5648]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w13, #2, LBB1_537
LBB1_544:                               ; %cond.load1746
                                        ;   in Loop: Header=BB1_534 Depth=3
	fmov	x9, d3
	ld1.s	{ v6 }[2], [x9]
	tbz	w13, #3, LBB1_538
LBB1_545:                               ; %cond.load1752
                                        ;   in Loop: Header=BB1_534 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v6 }[3], [x9]
	orr.16b	v3, v16, v4
	ldr	q5, [sp, #5632]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w13, #4, LBB1_539
LBB1_546:                               ; %cond.load1758
                                        ;   in Loop: Header=BB1_534 Depth=3
	fmov	x9, d3
	ld1.s	{ v7 }[0], [x9]
	tbz	w13, #5, LBB1_540
LBB1_547:                               ; %cond.load1764
                                        ;   in Loop: Header=BB1_534 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v7 }[1], [x9]
	orr.16b	v3, v16, v17
	add.2d	v3, v13, v3
	tbz	w13, #6, LBB1_541
LBB1_548:                               ; %cond.load1770
                                        ;   in Loop: Header=BB1_534 Depth=3
	fmov	x9, d3
	ld1.s	{ v7 }[2], [x9]
	tbz	w13, #7, LBB1_533
LBB1_549:                               ; %cond.load1776
                                        ;   in Loop: Header=BB1_534 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v7 }[3], [x9]
	b	LBB1_533
LBB1_550:                               ; %direct.false733.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	and.16b	v8, v18, v8
	and.16b	v31, v20, v31
	b	LBB1_552
LBB1_551:                               ; %else1829
                                        ;   in Loop: Header=BB1_552 Depth=3
	fadd.4s	v3, v31, v6
	fadd.4s	v5, v8, v7
	bit.16b	v8, v5, v0
	bit.16b	v31, v3, v1
	add	x12, x12, #4
	cmp	x12, #64
	b.eq	LBB1_568
LBB1_552:                               ; %direct.true742.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	w13, s2
	orr	x9, x12, #0x1c0
	dup.2d	v16, x9
	orr.16b	v3, v16, v11
	ldr	q5, [sp, #5664]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	tbnz	w13, #0, LBB1_560
; %bb.553:                              ; %else1787
                                        ;   in Loop: Header=BB1_552 Depth=3
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_561
LBB1_554:                               ; %else1793
                                        ;   in Loop: Header=BB1_552 Depth=3
	orr.16b	v3, v16, v14
	ldr	q5, [sp, #5648]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w13, #2, LBB1_562
LBB1_555:                               ; %else1799
                                        ;   in Loop: Header=BB1_552 Depth=3
	tbnz	w13, #3, LBB1_563
LBB1_556:                               ; %else1805
                                        ;   in Loop: Header=BB1_552 Depth=3
	orr.16b	v3, v16, v4
	ldr	q5, [sp, #5632]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbnz	w13, #4, LBB1_564
LBB1_557:                               ; %else1811
                                        ;   in Loop: Header=BB1_552 Depth=3
	tbnz	w13, #5, LBB1_565
LBB1_558:                               ; %else1817
                                        ;   in Loop: Header=BB1_552 Depth=3
	orr.16b	v3, v16, v17
	add.2d	v3, v13, v3
	tbnz	w13, #6, LBB1_566
LBB1_559:                               ; %else1823
                                        ;   in Loop: Header=BB1_552 Depth=3
	tbz	w13, #7, LBB1_551
	b	LBB1_567
LBB1_560:                               ; %cond.load1783
                                        ;   in Loop: Header=BB1_552 Depth=3
	fmov	x9, d3
	ldr	s6, [x9]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_554
LBB1_561:                               ; %cond.load1789
                                        ;   in Loop: Header=BB1_552 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v6 }[1], [x9]
	orr.16b	v3, v16, v14
	ldr	q5, [sp, #5648]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w13, #2, LBB1_555
LBB1_562:                               ; %cond.load1795
                                        ;   in Loop: Header=BB1_552 Depth=3
	fmov	x9, d3
	ld1.s	{ v6 }[2], [x9]
	tbz	w13, #3, LBB1_556
LBB1_563:                               ; %cond.load1801
                                        ;   in Loop: Header=BB1_552 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v6 }[3], [x9]
	orr.16b	v3, v16, v4
	ldr	q5, [sp, #5632]                 ; 16-byte Reload
	add.2d	v3, v5, v3
	tbz	w13, #4, LBB1_557
LBB1_564:                               ; %cond.load1807
                                        ;   in Loop: Header=BB1_552 Depth=3
	fmov	x9, d3
	ld1.s	{ v7 }[0], [x9]
	tbz	w13, #5, LBB1_558
LBB1_565:                               ; %cond.load1813
                                        ;   in Loop: Header=BB1_552 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v7 }[1], [x9]
	orr.16b	v3, v16, v17
	add.2d	v3, v13, v3
	tbz	w13, #6, LBB1_559
LBB1_566:                               ; %cond.load1819
                                        ;   in Loop: Header=BB1_552 Depth=3
	fmov	x9, d3
	ld1.s	{ v7 }[2], [x9]
	tbz	w13, #7, LBB1_551
LBB1_567:                               ; %cond.load1825
                                        ;   in Loop: Header=BB1_552 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v7 }[3], [x9]
	b	LBB1_551
LBB1_568:                               ; %direct.false743.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	sshll.2d	v3, v1, #0
	sshll.2d	v5, v0, #0
	ldr	q6, [sp, #2432]                 ; 16-byte Reload
	bit.16b	v23, v6, v10
	bit.16b	v21, v6, v27
	bit.16b	v22, v6, v5
	bit.16b	v19, v6, v3
Lloh352:
	adrp	x9, lCPI1_87@PAGE
Lloh353:
	ldr	q6, [x9, lCPI1_87@PAGEOFF]
	str	q6, [sp, #3632]                 ; 16-byte Spill
	bit.16b	v30, v6, v10
Lloh354:
	adrp	x9, lCPI1_88@PAGE
Lloh355:
	ldr	q6, [x9, lCPI1_88@PAGEOFF]
	str	q6, [sp, #3616]                 ; 16-byte Spill
	bit.16b	v25, v6, v27
Lloh356:
	adrp	x9, lCPI1_89@PAGE
Lloh357:
	ldr	q6, [x9, lCPI1_89@PAGEOFF]
	str	q6, [sp, #3600]                 ; 16-byte Spill
	bit.16b	v29, v6, v5
Lloh358:
	adrp	x9, lCPI1_90@PAGE
Lloh359:
	ldr	q5, [x9, lCPI1_90@PAGEOFF]
	str	q5, [sp, #2928]                 ; 16-byte Spill
	bit.16b	v24, v5, v3
	b	LBB1_570
LBB1_569:                               ; %else1863
                                        ;   in Loop: Header=BB1_570 Depth=3
	add	x13, x13, #1
	add	x12, x12, #4
	cmp	x13, #384
	b.eq	LBB1_586
LBB1_570:                               ; %direct.true768.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	w14, s2
	and	w9, w13, #0xffff
	mul	w9, w9, w23
	lsr	w9, w9, #21
	msub	w15, w9, w28, w13
	and	x15, x15, #0xffff
	umaddl	x15, w9, w28, x15
	add	x15, x11, x15, lsl #5
	ldp	q3, q7, [x15]
	add	x9, x17, x9, lsl #5
	ldp	q5, q16, [x9]
	fmul.4s	v3, v3, v5
	and.16b	v3, v1, v3
	dup.2d	v6, x12
	add.2d	v5, v19, v24
	add.2d	v5, v5, v6
	tbnz	w14, #0, LBB1_578
; %bb.571:                              ; %else1835
                                        ;   in Loop: Header=BB1_570 Depth=3
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB1_579
LBB1_572:                               ; %else1839
                                        ;   in Loop: Header=BB1_570 Depth=3
	add.2d	v5, v21, v25
	add.2d	v5, v5, v6
	tbnz	w14, #2, LBB1_580
LBB1_573:                               ; %else1843
                                        ;   in Loop: Header=BB1_570 Depth=3
	tbnz	w14, #3, LBB1_581
LBB1_574:                               ; %else1847
                                        ;   in Loop: Header=BB1_570 Depth=3
	fmul.4s	v3, v7, v16
	and.16b	v3, v0, v3
	add.2d	v5, v22, v29
	add.2d	v5, v5, v6
	tbnz	w14, #4, LBB1_582
LBB1_575:                               ; %else1851
                                        ;   in Loop: Header=BB1_570 Depth=3
	tbnz	w14, #5, LBB1_583
LBB1_576:                               ; %else1855
                                        ;   in Loop: Header=BB1_570 Depth=3
	add.2d	v5, v23, v30
	add.2d	v5, v5, v6
	tbnz	w14, #6, LBB1_584
LBB1_577:                               ; %else1859
                                        ;   in Loop: Header=BB1_570 Depth=3
	tbz	w14, #7, LBB1_569
	b	LBB1_585
LBB1_578:                               ; %cond.store1832
                                        ;   in Loop: Header=BB1_570 Depth=3
	fmov	x9, d5
	str	s3, [x9]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB1_572
LBB1_579:                               ; %cond.store1836
                                        ;   in Loop: Header=BB1_570 Depth=3
	mov.d	x9, v5[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v5, v21, v25
	add.2d	v5, v5, v6
	tbz	w14, #2, LBB1_573
LBB1_580:                               ; %cond.store1840
                                        ;   in Loop: Header=BB1_570 Depth=3
	fmov	x9, d5
	st1.s	{ v3 }[2], [x9]
	tbz	w14, #3, LBB1_574
LBB1_581:                               ; %cond.store1844
                                        ;   in Loop: Header=BB1_570 Depth=3
	mov.d	x9, v5[1]
	st1.s	{ v3 }[3], [x9]
	fmul.4s	v3, v7, v16
	and.16b	v3, v0, v3
	add.2d	v5, v22, v29
	add.2d	v5, v5, v6
	tbz	w14, #4, LBB1_575
LBB1_582:                               ; %cond.store1848
                                        ;   in Loop: Header=BB1_570 Depth=3
	fmov	x9, d5
	str	s3, [x9]
	tbz	w14, #5, LBB1_576
LBB1_583:                               ; %cond.store1852
                                        ;   in Loop: Header=BB1_570 Depth=3
	mov.d	x9, v5[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v5, v23, v30
	add.2d	v5, v5, v6
	tbz	w14, #6, LBB1_577
LBB1_584:                               ; %cond.store1856
                                        ;   in Loop: Header=BB1_570 Depth=3
	fmov	x9, d5
	st1.s	{ v3 }[2], [x9]
	tbz	w14, #7, LBB1_569
LBB1_585:                               ; %cond.store1860
                                        ;   in Loop: Header=BB1_570 Depth=3
	mov.d	x9, v5[1]
	st1.s	{ v3 }[3], [x9]
	b	LBB1_569
LBB1_586:                               ; %direct.false769.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	tbz	w2, #0, LBB1_591
; %bb.587:                              ; %mma.active790.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	ldr	q3, [sp, #5664]                 ; 16-byte Reload
	fmov	x9, d3
	fmov	x14, d11
	add	x14, x9, x14
	ldr	q3, [sp, #4768]                 ; 16-byte Reload
	fmov	x9, d3
	ldr	q3, [sp, #4704]                 ; 16-byte Reload
	fmov	x15, d3
	add	x15, x9, x15
	fmov	x9, d19
	fmov	x17, d24
	add	x17, x9, x17
	mov	w9, #40064                      ; =0x9c80
	movk	w9, #1, lsl #16
	add	x0, x30, x9
LBB1_588:                               ; %mma.update.i616.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB1_589 Depth 4
	mov	x1, #0                          ; =0x0
	mov	x3, x12
LBB1_589:                               ; %mma.update2.i.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ;       Parent Loop BB1_588 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	umulh	x9, x3, x19
	lsr	x4, x9, #5
	msub	x4, x4, x28, x3
	ldr	q3, [x17, x1]
	lsl	x9, x9, #1
	and	x9, x9, #0x1c0
	add	x5, x14, x9
	add	x4, x15, x4, lsl #2
	ldr	q5, [x4]
	ldp	s6, s7, [x5]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #192]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #384]
	ldp	s6, s7, [x5, #8]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #576]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #768]
	ldp	s6, s7, [x5, #16]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #960]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1152]
	ldp	s6, s7, [x5, #24]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1344]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1536]
	ldp	s6, s7, [x5, #32]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1728]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1920]
	ldp	s6, s7, [x5, #40]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2112]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2304]
	ldp	s6, s7, [x5, #48]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2496]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2688]
	ldp	s6, s7, [x5, #56]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2880]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	str	q3, [x0, x1]
	add	x1, x1, #16
	add	x3, x3, #4
	cmp	x1, #192
	b.ne	LBB1_589
; %bb.590:                              ; %mma.fold.done3.i.i.i
                                        ;   in Loop: Header=BB1_588 Depth=3
	add	x13, x13, #1
	add	x12, x12, #48
	add	x0, x0, #192
	add	x17, x17, #192
	cmp	x13, #8
	b.ne	LBB1_588
LBB1_591:                               ; %mma.continue791.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	cbz	w7, LBB1_596
; %bb.592:                              ; %mma.active792.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	ldr	q3, [sp, #5664]                 ; 16-byte Reload
	mov.d	x9, v3[1]
	mov.d	x14, v11[1]
	add	x14, x9, x14
	ldr	q3, [sp, #4768]                 ; 16-byte Reload
	mov.d	x9, v3[1]
	ldr	q3, [sp, #4704]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	add	x15, x9, x15
	mov.d	x9, v19[1]
	mov.d	x17, v24[1]
	add	x17, x9, x17
	mov	w9, #41600                      ; =0xa280
	movk	w9, #1, lsl #16
	add	x0, x30, x9
LBB1_593:                               ; %mma.update.i618.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB1_594 Depth 4
	mov	x1, #0                          ; =0x0
	mov	x3, x12
LBB1_594:                               ; %mma.update2.i620.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ;       Parent Loop BB1_593 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	umulh	x9, x3, x19
	lsr	x4, x9, #5
	msub	x4, x4, x28, x3
	ldr	q3, [x17, x1]
	lsl	x9, x9, #1
	and	x9, x9, #0x1c0
	add	x5, x14, x9
	add	x4, x15, x4, lsl #2
	ldr	q5, [x4]
	ldp	s6, s7, [x5]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #192]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #384]
	ldp	s6, s7, [x5, #8]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #576]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #768]
	ldp	s6, s7, [x5, #16]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #960]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1152]
	ldp	s6, s7, [x5, #24]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1344]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1536]
	ldp	s6, s7, [x5, #32]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1728]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1920]
	ldp	s6, s7, [x5, #40]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2112]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2304]
	ldp	s6, s7, [x5, #48]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2496]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2688]
	ldp	s6, s7, [x5, #56]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2880]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	str	q3, [x0, x1]
	add	x1, x1, #16
	add	x3, x3, #4
	cmp	x1, #192
	b.ne	LBB1_594
; %bb.595:                              ; %mma.fold.done3.i655.i.i
                                        ;   in Loop: Header=BB1_593 Depth=3
	add	x13, x13, #1
	add	x12, x12, #48
	add	x0, x0, #192
	add	x17, x17, #192
	cmp	x13, #8
	b.ne	LBB1_593
LBB1_596:                               ; %mma.continue793.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	cbz	w20, LBB1_601
; %bb.597:                              ; %mma.active794.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	ldr	q3, [sp, #5648]                 ; 16-byte Reload
	fmov	x9, d3
	fmov	x14, d14
	add	x14, x9, x14
	ldr	q3, [sp, #4752]                 ; 16-byte Reload
	fmov	x9, d3
	ldr	q3, [sp, #4688]                 ; 16-byte Reload
	fmov	x15, d3
	add	x15, x9, x15
	fmov	x9, d21
	fmov	x17, d25
	add	x17, x9, x17
	mov	w9, #43136                      ; =0xa880
	movk	w9, #1, lsl #16
	add	x0, x30, x9
LBB1_598:                               ; %mma.update.i658.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB1_599 Depth 4
	mov	x1, #0                          ; =0x0
	mov	x3, x12
LBB1_599:                               ; %mma.update2.i660.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ;       Parent Loop BB1_598 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	umulh	x9, x3, x19
	lsr	x4, x9, #5
	msub	x4, x4, x28, x3
	ldr	q3, [x17, x1]
	lsl	x9, x9, #1
	and	x9, x9, #0x1c0
	add	x5, x14, x9
	add	x4, x15, x4, lsl #2
	ldr	q5, [x4]
	ldp	s6, s7, [x5]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #192]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #384]
	ldp	s6, s7, [x5, #8]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #576]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #768]
	ldp	s6, s7, [x5, #16]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #960]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1152]
	ldp	s6, s7, [x5, #24]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1344]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1536]
	ldp	s6, s7, [x5, #32]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1728]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1920]
	ldp	s6, s7, [x5, #40]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2112]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2304]
	ldp	s6, s7, [x5, #48]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2496]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2688]
	ldp	s6, s7, [x5, #56]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2880]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	str	q3, [x0, x1]
	add	x1, x1, #16
	add	x3, x3, #4
	cmp	x1, #192
	b.ne	LBB1_599
; %bb.600:                              ; %mma.fold.done3.i695.i.i
                                        ;   in Loop: Header=BB1_598 Depth=3
	add	x13, x13, #1
	add	x12, x12, #48
	add	x0, x0, #192
	add	x17, x17, #192
	cmp	x13, #8
	b.ne	LBB1_598
LBB1_601:                               ; %mma.continue795.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	cbz	w22, LBB1_606
; %bb.602:                              ; %mma.active796.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	ldr	q3, [sp, #5648]                 ; 16-byte Reload
	mov.d	x9, v3[1]
	mov.d	x14, v14[1]
	add	x14, x9, x14
	ldr	q3, [sp, #4752]                 ; 16-byte Reload
	mov.d	x9, v3[1]
	ldr	q3, [sp, #4688]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	add	x15, x9, x15
	mov.d	x9, v21[1]
	mov.d	x17, v25[1]
	add	x17, x9, x17
	mov	w9, #44672                      ; =0xae80
	movk	w9, #1, lsl #16
	add	x0, x30, x9
LBB1_603:                               ; %mma.update.i698.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB1_604 Depth 4
	mov	x1, #0                          ; =0x0
	mov	x3, x12
LBB1_604:                               ; %mma.update2.i700.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ;       Parent Loop BB1_603 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	umulh	x9, x3, x19
	lsr	x4, x9, #5
	msub	x4, x4, x28, x3
	ldr	q3, [x17, x1]
	lsl	x9, x9, #1
	and	x9, x9, #0x1c0
	add	x5, x14, x9
	add	x4, x15, x4, lsl #2
	ldr	q5, [x4]
	ldp	s6, s7, [x5]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #192]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #384]
	ldp	s6, s7, [x5, #8]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #576]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #768]
	ldp	s6, s7, [x5, #16]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #960]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1152]
	ldp	s6, s7, [x5, #24]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1344]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1536]
	ldp	s6, s7, [x5, #32]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1728]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1920]
	ldp	s6, s7, [x5, #40]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2112]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2304]
	ldp	s6, s7, [x5, #48]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2496]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2688]
	ldp	s6, s7, [x5, #56]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2880]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	str	q3, [x0, x1]
	add	x1, x1, #16
	add	x3, x3, #4
	cmp	x1, #192
	b.ne	LBB1_604
; %bb.605:                              ; %mma.fold.done3.i735.i.i
                                        ;   in Loop: Header=BB1_603 Depth=3
	add	x13, x13, #1
	add	x12, x12, #48
	add	x0, x0, #192
	add	x17, x17, #192
	cmp	x13, #8
	b.ne	LBB1_603
LBB1_606:                               ; %mma.continue797.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	cbz	w24, LBB1_611
; %bb.607:                              ; %mma.active798.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	ldr	q3, [sp, #5632]                 ; 16-byte Reload
	fmov	x9, d3
	fmov	x14, d4
	add	x14, x9, x14
	ldr	q3, [sp, #4736]                 ; 16-byte Reload
	fmov	x9, d3
	ldr	q3, [sp, #4672]                 ; 16-byte Reload
	fmov	x15, d3
	add	x15, x9, x15
	fmov	x9, d22
	fmov	x17, d29
	add	x17, x9, x17
	mov	w9, #46208                      ; =0xb480
	movk	w9, #1, lsl #16
	add	x0, x30, x9
LBB1_608:                               ; %mma.update.i738.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB1_609 Depth 4
	mov	x1, #0                          ; =0x0
	mov	x3, x12
LBB1_609:                               ; %mma.update2.i740.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ;       Parent Loop BB1_608 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	umulh	x9, x3, x19
	lsr	x4, x9, #5
	msub	x4, x4, x28, x3
	ldr	q3, [x17, x1]
	lsl	x9, x9, #1
	and	x9, x9, #0x1c0
	add	x5, x14, x9
	add	x4, x15, x4, lsl #2
	ldr	q5, [x4]
	ldp	s6, s7, [x5]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #192]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #384]
	ldp	s6, s7, [x5, #8]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #576]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #768]
	ldp	s6, s7, [x5, #16]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #960]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1152]
	ldp	s6, s7, [x5, #24]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1344]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1536]
	ldp	s6, s7, [x5, #32]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1728]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1920]
	ldp	s6, s7, [x5, #40]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2112]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2304]
	ldp	s6, s7, [x5, #48]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2496]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2688]
	ldp	s6, s7, [x5, #56]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2880]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	str	q3, [x0, x1]
	add	x1, x1, #16
	add	x3, x3, #4
	cmp	x1, #192
	b.ne	LBB1_609
; %bb.610:                              ; %mma.fold.done3.i775.i.i
                                        ;   in Loop: Header=BB1_608 Depth=3
	add	x13, x13, #1
	add	x12, x12, #48
	add	x0, x0, #192
	add	x17, x17, #192
	cmp	x13, #8
	b.ne	LBB1_608
LBB1_611:                               ; %mma.continue799.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	cbz	w26, LBB1_616
; %bb.612:                              ; %mma.active800.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	ldr	q3, [sp, #5632]                 ; 16-byte Reload
	mov.d	x9, v3[1]
	mov.d	x14, v4[1]
	add	x14, x9, x14
	ldr	q3, [sp, #4736]                 ; 16-byte Reload
	mov.d	x9, v3[1]
	ldr	q3, [sp, #4672]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	add	x15, x9, x15
	mov.d	x9, v22[1]
	mov.d	x17, v29[1]
	add	x17, x9, x17
	mov	w9, #47744                      ; =0xba80
	movk	w9, #1, lsl #16
	add	x0, x30, x9
LBB1_613:                               ; %mma.update.i778.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB1_614 Depth 4
	mov	x1, #0                          ; =0x0
	mov	x3, x12
LBB1_614:                               ; %mma.update2.i780.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ;       Parent Loop BB1_613 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	umulh	x9, x3, x19
	lsr	x4, x9, #5
	msub	x4, x4, x28, x3
	ldr	q3, [x17, x1]
	lsl	x9, x9, #1
	and	x9, x9, #0x1c0
	add	x5, x14, x9
	add	x4, x15, x4, lsl #2
	ldr	q5, [x4]
	ldp	s6, s7, [x5]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #192]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #384]
	ldp	s6, s7, [x5, #8]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #576]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #768]
	ldp	s6, s7, [x5, #16]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #960]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1152]
	ldp	s6, s7, [x5, #24]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1344]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1536]
	ldp	s6, s7, [x5, #32]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1728]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1920]
	ldp	s6, s7, [x5, #40]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2112]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2304]
	ldp	s6, s7, [x5, #48]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2496]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2688]
	ldp	s6, s7, [x5, #56]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2880]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	str	q3, [x0, x1]
	add	x1, x1, #16
	add	x3, x3, #4
	cmp	x1, #192
	b.ne	LBB1_614
; %bb.615:                              ; %mma.fold.done3.i815.i.i
                                        ;   in Loop: Header=BB1_613 Depth=3
	add	x13, x13, #1
	add	x12, x12, #48
	add	x0, x0, #192
	add	x17, x17, #192
	cmp	x13, #8
	b.ne	LBB1_613
LBB1_616:                               ; %mma.continue801.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	cbz	w27, LBB1_621
; %bb.617:                              ; %mma.active802.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	fmov	x9, d13
	fmov	x14, d17
	add	x14, x9, x14
	ldr	q3, [sp, #4720]                 ; 16-byte Reload
	fmov	x9, d3
	ldr	q3, [sp, #4656]                 ; 16-byte Reload
	fmov	x15, d3
	add	x15, x9, x15
	fmov	x9, d23
	fmov	x17, d30
	add	x17, x9, x17
	mov	w9, #49280                      ; =0xc080
	movk	w9, #1, lsl #16
	add	x0, x30, x9
LBB1_618:                               ; %mma.update.i818.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB1_619 Depth 4
	mov	x1, #0                          ; =0x0
	mov	x3, x12
LBB1_619:                               ; %mma.update2.i820.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ;       Parent Loop BB1_618 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	umulh	x9, x3, x19
	lsr	x4, x9, #5
	msub	x4, x4, x28, x3
	ldr	q3, [x17, x1]
	lsl	x9, x9, #1
	and	x9, x9, #0x1c0
	add	x5, x14, x9
	add	x4, x15, x4, lsl #2
	ldr	q5, [x4]
	ldp	s6, s7, [x5]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #192]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #384]
	ldp	s6, s7, [x5, #8]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #576]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #768]
	ldp	s6, s7, [x5, #16]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #960]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1152]
	ldp	s6, s7, [x5, #24]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1344]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1536]
	ldp	s6, s7, [x5, #32]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1728]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1920]
	ldp	s6, s7, [x5, #40]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2112]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2304]
	ldp	s6, s7, [x5, #48]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2496]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2688]
	ldp	s6, s7, [x5, #56]
	fmul.4s	v5, v5, v6[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2880]
	fmul.4s	v5, v5, v7[0]
	fadd.4s	v3, v3, v5
	str	q3, [x0, x1]
	add	x1, x1, #16
	add	x3, x3, #4
	cmp	x1, #192
	b.ne	LBB1_619
; %bb.620:                              ; %mma.fold.done3.i855.i.i
                                        ;   in Loop: Header=BB1_618 Depth=3
	add	x13, x13, #1
	add	x12, x12, #48
	add	x0, x0, #192
	add	x17, x17, #192
	cmp	x13, #8
	b.ne	LBB1_618
LBB1_621:                               ; %mma.continue803.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	str	q15, [sp, #4208]                ; 16-byte Spill
	str	q12, [sp, #4224]                ; 16-byte Spill
	str	q8, [sp, #4240]                 ; 16-byte Spill
	str	q31, [sp, #4256]                ; 16-byte Spill
	str	q30, [sp, #3296]                ; 16-byte Spill
	str	q29, [sp, #3120]                ; 16-byte Spill
	str	q25, [sp, #3136]                ; 16-byte Spill
	str	q24, [sp, #3152]                ; 16-byte Spill
	str	q23, [sp, #3312]                ; 16-byte Spill
	str	q22, [sp, #3168]                ; 16-byte Spill
	str	q21, [sp, #3184]                ; 16-byte Spill
	str	q19, [sp, #3200]                ; 16-byte Spill
	sshll.2d	v31, v1, #0
	sshll.2d	v6, v0, #0
	ldr	q3, [sp, #3664]                 ; 16-byte Reload
	ldr	q5, [sp, #2896]                 ; 16-byte Reload
	fmul.4s	v24, v3, v5
	ldr	q3, [sp, #3712]                 ; 16-byte Reload
	ldr	q5, [sp, #2912]                 ; 16-byte Reload
	fmul.4s	v28, v3, v5
	ldr	q3, [sp, #3744]                 ; 16-byte Reload
	ldr	q5, [sp, #3456]                 ; 16-byte Reload
	fmul.4s	v30, v3, v5
	ldr	q3, [sp, #3776]                 ; 16-byte Reload
	ldr	q5, [sp, #3440]                 ; 16-byte Reload
	fmul.4s	v7, v3, v5
	ldr	q3, [sp, #3792]                 ; 16-byte Reload
	ldr	q5, [sp, #3424]                 ; 16-byte Reload
	fmul.4s	v8, v3, v5
	ldr	q3, [sp, #3808]                 ; 16-byte Reload
	ldr	q5, [sp, #3408]                 ; 16-byte Reload
	fmul.4s	v16, v3, v5
	ldr	q3, [sp, #3824]                 ; 16-byte Reload
	ldr	q5, [sp, #3392]                 ; 16-byte Reload
	fmul.4s	v3, v3, v5
	str	q3, [sp, #3440]                 ; 16-byte Spill
	ldr	q3, [sp, #3840]                 ; 16-byte Reload
	ldr	q5, [sp, #3376]                 ; 16-byte Reload
	fmul.4s	v19, v3, v5
	ldr	q3, [sp, #3856]                 ; 16-byte Reload
	ldr	q5, [sp, #2784]                 ; 16-byte Reload
	fmul.4s	v3, v3, v5
	str	q3, [sp, #3424]                 ; 16-byte Spill
	ldr	q3, [sp, #3872]                 ; 16-byte Reload
	ldr	q5, [sp, #3360]                 ; 16-byte Reload
	fmul.4s	v21, v3, v5
	ldr	q3, [sp, #3888]                 ; 16-byte Reload
	ldr	q5, [sp, #2768]                 ; 16-byte Reload
	fmul.4s	v3, v3, v5
	str	q3, [sp, #3376]                 ; 16-byte Spill
	ldr	q3, [sp, #3904]                 ; 16-byte Reload
	ldr	q5, [sp, #3344]                 ; 16-byte Reload
	fmul.4s	v25, v3, v5
	ldr	q3, [sp, #3920]                 ; 16-byte Reload
	ldr	q5, [sp, #2752]                 ; 16-byte Reload
	fmul.4s	v3, v3, v5
	str	q3, [sp, #3360]                 ; 16-byte Spill
	ldr	q3, [sp, #3936]                 ; 16-byte Reload
	ldr	q5, [sp, #2736]                 ; 16-byte Reload
	fmul.4s	v12, v3, v5
	ldr	q3, [sp, #3952]                 ; 16-byte Reload
	ldr	q5, [sp, #2720]                 ; 16-byte Reload
	fmul.4s	v3, v3, v5
	str	q3, [sp, #3344]                 ; 16-byte Spill
	ldr	q9, [sp, #3056]                 ; 16-byte Reload
	ldr	q3, [sp, #2704]                 ; 16-byte Reload
	fmul.4s	v15, v9, v3
	ldr	w9, [sp, #4284]                 ; 4-byte Reload
	cbz	w9, LBB1_626
; %bb.622:                              ; %mma.active804.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	mov.d	x9, v13[1]
	mov.d	x14, v17[1]
	add	x14, x9, x14
	ldr	q3, [sp, #4720]                 ; 16-byte Reload
	mov.d	x9, v3[1]
	ldr	q3, [sp, #4656]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	add	x15, x9, x15
	ldr	q3, [sp, #3312]                 ; 16-byte Reload
	mov.d	x9, v3[1]
	ldr	q3, [sp, #3296]                 ; 16-byte Reload
	mov.d	x17, v3[1]
	add	x17, x9, x17
	mov	w9, #50816                      ; =0xc680
	movk	w9, #1, lsl #16
	add	x0, x30, x9
LBB1_623:                               ; %mma.update.i858.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB1_624 Depth 4
	mov	x1, #0                          ; =0x0
	mov	x3, x12
LBB1_624:                               ; %mma.update2.i860.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ;       Parent Loop BB1_623 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	umulh	x9, x3, x19
	lsr	x4, x9, #5
	msub	x4, x4, x28, x3
	ldr	q3, [x17, x1]
	lsl	x9, x9, #1
	and	x9, x9, #0x1c0
	add	x5, x14, x9
	add	x4, x15, x4, lsl #2
	ldr	q5, [x4]
	ldp	s22, s23, [x5]
	fmul.4s	v5, v5, v22[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #192]
	fmul.4s	v5, v5, v23[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #384]
	ldp	s22, s23, [x5, #8]
	fmul.4s	v5, v5, v22[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #576]
	fmul.4s	v5, v5, v23[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #768]
	ldp	s22, s23, [x5, #16]
	fmul.4s	v5, v5, v22[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #960]
	fmul.4s	v5, v5, v23[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1152]
	ldp	s22, s23, [x5, #24]
	fmul.4s	v5, v5, v22[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1344]
	fmul.4s	v5, v5, v23[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1536]
	ldp	s22, s23, [x5, #32]
	fmul.4s	v5, v5, v22[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1728]
	fmul.4s	v5, v5, v23[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #1920]
	ldp	s22, s23, [x5, #40]
	fmul.4s	v5, v5, v22[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2112]
	fmul.4s	v5, v5, v23[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2304]
	ldp	s22, s23, [x5, #48]
	fmul.4s	v5, v5, v22[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2496]
	fmul.4s	v5, v5, v23[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2688]
	ldp	s22, s23, [x5, #56]
	fmul.4s	v5, v5, v22[0]
	fadd.4s	v3, v3, v5
	ldr	q5, [x4, #2880]
	fmul.4s	v5, v5, v23[0]
	fadd.4s	v3, v3, v5
	str	q3, [x0, x1]
	add	x1, x1, #16
	add	x3, x3, #4
	cmp	x1, #192
	b.ne	LBB1_624
; %bb.625:                              ; %mma.fold.done3.i895.i.i
                                        ;   in Loop: Header=BB1_623 Depth=3
	add	x13, x13, #1
	add	x12, x12, #48
	add	x0, x0, #192
	add	x17, x17, #192
	cmp	x13, #8
	b.ne	LBB1_623
LBB1_626:                               ; %direct.true807.i.i.preheader
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	q3, [sp, #5232]                 ; 16-byte Reload
	ldr	q5, [sp, #3600]                 ; 16-byte Reload
	bit.16b	v3, v5, v6
	str	q3, [sp, #5232]                 ; 16-byte Spill
	ldr	q3, [sp, #2416]                 ; 16-byte Reload
	ldr	q29, [sp, #3008]                ; 16-byte Reload
	bit.16b	v29, v3, v6
	ldr	q5, [sp, #2976]                 ; 16-byte Reload
	ldr	q6, [sp, #2928]                 ; 16-byte Reload
	bit.16b	v5, v6, v31
	ldr	q23, [sp, #3216]                ; 16-byte Reload
	bit.16b	v23, v3, v31
	ldr	q6, [sp, #5216]                 ; 16-byte Reload
	ldr	q22, [sp, #3632]                ; 16-byte Reload
	bit.16b	v6, v22, v10
	str	q6, [sp, #5216]                 ; 16-byte Spill
	ldr	q6, [sp, #5248]                 ; 16-byte Reload
	ldr	q22, [sp, #3616]                ; 16-byte Reload
	bit.16b	v6, v22, v27
	str	q6, [sp, #5248]                 ; 16-byte Spill
	ldr	q6, [sp, #5328]                 ; 16-byte Reload
	mov.16b	v20, v27
	fadd.4s	v27, v28, v6
	ldr	q6, [sp, #5312]                 ; 16-byte Reload
	fadd.4s	v28, v24, v6
	ldr	q6, [sp, #5360]                 ; 16-byte Reload
	mov.16b	v18, v10
	mov.16b	v10, v20
	fadd.4s	v6, v7, v6
	str	q6, [sp, #3392]                 ; 16-byte Spill
	ldr	q6, [sp, #5344]                 ; 16-byte Reload
	fadd.4s	v31, v30, v6
	ldr	q6, [sp, #5392]                 ; 16-byte Reload
	fadd.4s	v16, v16, v6
	ldr	q6, [sp, #5376]                 ; 16-byte Reload
	fadd.4s	v7, v8, v6
	ldr	q22, [sp, #5424]                ; 16-byte Reload
	fadd.4s	v6, v19, v22
	str	q6, [sp, #3456]                 ; 16-byte Spill
	ldr	q19, [sp, #5408]                ; 16-byte Reload
	ldr	q6, [sp, #3440]                 ; 16-byte Reload
	fadd.4s	v6, v6, v19
	str	q6, [sp, #3408]                 ; 16-byte Spill
	ldr	q22, [sp, #5456]                ; 16-byte Reload
	fadd.4s	v6, v21, v22
	str	q6, [sp, #3600]                 ; 16-byte Spill
	ldr	q21, [sp, #5440]                ; 16-byte Reload
	ldr	q6, [sp, #3424]                 ; 16-byte Reload
	fadd.4s	v6, v6, v21
	str	q6, [sp, #3424]                 ; 16-byte Spill
	ldr	q22, [sp, #5488]                ; 16-byte Reload
	fadd.4s	v6, v25, v22
	str	q6, [sp, #3440]                 ; 16-byte Spill
	ldr	q22, [sp, #5472]                ; 16-byte Reload
	ldr	q6, [sp, #3376]                 ; 16-byte Reload
	fadd.4s	v6, v6, v22
	ldr	q22, [sp, #4224]                ; 16-byte Reload
	fadd.4s	v19, v12, v22
	str	q19, [sp, #3616]                ; 16-byte Spill
	ldr	q22, [sp, #4208]                ; 16-byte Reload
	ldr	q19, [sp, #3360]                ; 16-byte Reload
	fadd.4s	v19, v19, v22
	ldr	q22, [sp, #4256]                ; 16-byte Reload
	fadd.4s	v20, v15, v22
	str	q20, [sp, #3632]                ; 16-byte Spill
	mov.16b	v15, v5
	ldr	q5, [sp, #4240]                 ; 16-byte Reload
	ldr	q20, [sp, #3344]                ; 16-byte Reload
	fadd.4s	v20, v20, v5
	ldr	q30, [sp, #2992]                ; 16-byte Reload
	bit.16b	v30, v3, v18
	add	x13, x30, #5, lsl #12           ; =20480
	ldr	q24, [sp, #3024]                ; 16-byte Reload
	bit.16b	v24, v3, v10
	ldr	x17, [sp, #2600]                ; 8-byte Reload
	b	LBB1_628
LBB1_627:                               ; %else1911
                                        ;   in Loop: Header=BB1_628 Depth=3
	ldp	q3, q5, [x13]
	bit.16b	v5, v12, v0
	bit.16b	v3, v25, v1
	stp	q3, q5, [x13], #32
	add	x12, x12, #4
	cmp	x12, #1536
	b.eq	LBB1_644
LBB1_628:                               ; %direct.true807.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	w14, s2
	dup.2d	v22, x12
	add.2d	v3, v23, v15
	add.2d	v3, v3, v22
	movi.2d	v25, #0000000000000000
	movi.2d	v12, #0000000000000000
	tbnz	w14, #0, LBB1_636
; %bb.629:                              ; %else1869
                                        ;   in Loop: Header=BB1_628 Depth=3
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB1_637
LBB1_630:                               ; %else1875
                                        ;   in Loop: Header=BB1_628 Depth=3
	ldr	q3, [sp, #5248]                 ; 16-byte Reload
	add.2d	v3, v24, v3
	add.2d	v3, v3, v22
	tbnz	w14, #2, LBB1_638
LBB1_631:                               ; %else1881
                                        ;   in Loop: Header=BB1_628 Depth=3
	tbnz	w14, #3, LBB1_639
LBB1_632:                               ; %else1887
                                        ;   in Loop: Header=BB1_628 Depth=3
	ldr	q3, [sp, #5232]                 ; 16-byte Reload
	add.2d	v3, v29, v3
	add.2d	v3, v3, v22
	tbnz	w14, #4, LBB1_640
LBB1_633:                               ; %else1893
                                        ;   in Loop: Header=BB1_628 Depth=3
	tbnz	w14, #5, LBB1_641
LBB1_634:                               ; %else1899
                                        ;   in Loop: Header=BB1_628 Depth=3
	ldr	q3, [sp, #5216]                 ; 16-byte Reload
	add.2d	v3, v30, v3
	add.2d	v3, v3, v22
	tbnz	w14, #6, LBB1_642
LBB1_635:                               ; %else1905
                                        ;   in Loop: Header=BB1_628 Depth=3
	tbz	w14, #7, LBB1_627
	b	LBB1_643
LBB1_636:                               ; %cond.load1865
                                        ;   in Loop: Header=BB1_628 Depth=3
	fmov	x9, d3
	ldr	s25, [x9]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB1_630
LBB1_637:                               ; %cond.load1871
                                        ;   in Loop: Header=BB1_628 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v25 }[1], [x9]
	ldr	q3, [sp, #5248]                 ; 16-byte Reload
	add.2d	v3, v24, v3
	add.2d	v3, v3, v22
	tbz	w14, #2, LBB1_631
LBB1_638:                               ; %cond.load1877
                                        ;   in Loop: Header=BB1_628 Depth=3
	fmov	x9, d3
	ld1.s	{ v25 }[2], [x9]
	tbz	w14, #3, LBB1_632
LBB1_639:                               ; %cond.load1883
                                        ;   in Loop: Header=BB1_628 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v25 }[3], [x9]
	ldr	q3, [sp, #5232]                 ; 16-byte Reload
	add.2d	v3, v29, v3
	add.2d	v3, v3, v22
	tbz	w14, #4, LBB1_633
LBB1_640:                               ; %cond.load1889
                                        ;   in Loop: Header=BB1_628 Depth=3
	fmov	x9, d3
	ld1.s	{ v12 }[0], [x9]
	tbz	w14, #5, LBB1_634
LBB1_641:                               ; %cond.load1895
                                        ;   in Loop: Header=BB1_628 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v12 }[1], [x9]
	ldr	q3, [sp, #5216]                 ; 16-byte Reload
	add.2d	v3, v30, v3
	add.2d	v3, v3, v22
	tbz	w14, #6, LBB1_635
LBB1_642:                               ; %cond.load1901
                                        ;   in Loop: Header=BB1_628 Depth=3
	fmov	x9, d3
	ld1.s	{ v12 }[2], [x9]
	tbz	w14, #7, LBB1_627
LBB1_643:                               ; %cond.load1907
                                        ;   in Loop: Header=BB1_628 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v12 }[3], [x9]
	b	LBB1_627
LBB1_644:                               ; %direct.true821.i.i.preheader
                                        ;   in Loop: Header=BB1_40 Depth=2
	str	q23, [sp, #3216]                ; 16-byte Spill
	mov	x12, x30
	mov	w13, #384                       ; =0x180
LBB1_645:                               ; %direct.true821.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x12, #20480]
	ldr	q5, [x12, #20496]
	ldr	q22, [x12, #8192]
	ldr	q23, [x12, #8208]
	bif.16b	v5, v23, v0
	bif.16b	v3, v22, v1
	str	q3, [x12, #8192]
	str	q5, [x12, #8208]
	add	x12, x12, #32
	subs	x13, x13, #1
	b.ne	LBB1_645
; %bb.646:                              ; %direct.false822.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #3680]                 ; 16-byte Reload
	ldr	q5, [sp, #2944]                 ; 16-byte Reload
	bit.16b	v3, v5, v0
	str	q3, [sp, #3680]                 ; 16-byte Spill
	ldr	q3, [sp, #3696]                 ; 16-byte Reload
	ldr	q5, [sp, #2960]                 ; 16-byte Reload
	bit.16b	v3, v5, v1
	str	q3, [sp, #3696]                 ; 16-byte Spill
	ldr	q3, [sp, #3728]                 ; 16-byte Reload
	ldr	q5, [sp, #2816]                 ; 16-byte Reload
	bit.16b	v3, v5, v0
	str	q3, [sp, #3728]                 ; 16-byte Spill
	ldr	q3, [sp, #3760]                 ; 16-byte Reload
	ldr	q5, [sp, #2880]                 ; 16-byte Reload
	bit.16b	v3, v5, v1
	str	q3, [sp, #3760]                 ; 16-byte Spill
	ldr	q3, [sp, #4320]                 ; 16-byte Reload
	ldr	q5, [sp, #2800]                 ; 16-byte Reload
	bit.16b	v3, v5, v0
	str	q3, [sp, #4320]                 ; 16-byte Spill
	ldr	q3, [sp, #4336]                 ; 16-byte Reload
	ldr	q5, [sp, #2864]                 ; 16-byte Reload
	bit.16b	v3, v5, v1
	str	q3, [sp, #4336]                 ; 16-byte Spill
	ldr	q3, [sp, #4352]                 ; 16-byte Reload
	ldr	q5, [sp, #3552]                 ; 16-byte Reload
	bit.16b	v3, v5, v0
	str	q3, [sp, #4352]                 ; 16-byte Spill
	ldr	q3, [sp, #4368]                 ; 16-byte Reload
	ldr	q5, [sp, #2848]                 ; 16-byte Reload
	bit.16b	v3, v5, v1
	str	q3, [sp, #4368]                 ; 16-byte Spill
	ldr	q3, [sp, #4384]                 ; 16-byte Reload
	ldr	q5, [sp, #3536]                 ; 16-byte Reload
	bit.16b	v3, v5, v0
	str	q3, [sp, #4384]                 ; 16-byte Spill
	ldr	q3, [sp, #4400]                 ; 16-byte Reload
	ldr	q5, [sp, #2832]                 ; 16-byte Reload
	bit.16b	v3, v5, v1
	str	q3, [sp, #4400]                 ; 16-byte Spill
	ldr	q3, [sp, #4416]                 ; 16-byte Reload
	ldr	q5, [sp, #3520]                 ; 16-byte Reload
	bit.16b	v3, v5, v0
	str	q3, [sp, #4416]                 ; 16-byte Spill
	ldr	q3, [sp, #4432]                 ; 16-byte Reload
	ldr	q5, [sp, #3584]                 ; 16-byte Reload
	bit.16b	v3, v5, v1
	str	q3, [sp, #4432]                 ; 16-byte Spill
	ldr	q3, [sp, #4448]                 ; 16-byte Reload
	ldr	q5, [sp, #3568]                 ; 16-byte Reload
	bit.16b	v3, v5, v0
	str	q3, [sp, #4448]                 ; 16-byte Spill
	ldr	q3, [sp, #4464]                 ; 16-byte Reload
	ldr	q5, [sp, #3504]                 ; 16-byte Reload
	bit.16b	v3, v5, v1
	str	q3, [sp, #4464]                 ; 16-byte Spill
	ldr	q3, [sp, #4496]                 ; 16-byte Reload
	ldr	q5, [sp, #3488]                 ; 16-byte Reload
	bit.16b	v3, v5, v0
	str	q3, [sp, #4496]                 ; 16-byte Spill
	ldr	q3, [sp, #4480]                 ; 16-byte Reload
	ldr	q5, [sp, #3472]                 ; 16-byte Reload
	bit.16b	v3, v5, v1
	str	q3, [sp, #4480]                 ; 16-byte Spill
	ldr	x12, [sp, #3048]                ; 8-byte Reload
	add	x12, x12, #1
	ldr	q3, [sp, #3664]                 ; 16-byte Reload
	bit.16b	v3, v28, v0
	str	q3, [sp, #3664]                 ; 16-byte Spill
	ldr	q3, [sp, #3712]                 ; 16-byte Reload
	bit.16b	v3, v27, v1
	str	q3, [sp, #3712]                 ; 16-byte Spill
	ldr	q3, [sp, #3744]                 ; 16-byte Reload
	bit.16b	v3, v31, v0
	str	q3, [sp, #3744]                 ; 16-byte Spill
	ldr	q3, [sp, #3776]                 ; 16-byte Reload
	ldr	q8, [sp, #3392]                 ; 16-byte Reload
	bit.16b	v3, v8, v1
	str	q3, [sp, #3776]                 ; 16-byte Spill
	ldr	q3, [sp, #3792]                 ; 16-byte Reload
	bit.16b	v3, v7, v0
	str	q3, [sp, #3792]                 ; 16-byte Spill
	ldr	q3, [sp, #3808]                 ; 16-byte Reload
	bit.16b	v3, v16, v1
	str	q3, [sp, #3808]                 ; 16-byte Spill
	ldr	q3, [sp, #3824]                 ; 16-byte Reload
	ldr	q12, [sp, #3408]                ; 16-byte Reload
	bit.16b	v3, v12, v0
	str	q3, [sp, #3824]                 ; 16-byte Spill
	ldr	q3, [sp, #3840]                 ; 16-byte Reload
	ldr	q5, [sp, #3456]                 ; 16-byte Reload
	bit.16b	v3, v5, v1
	str	q3, [sp, #3840]                 ; 16-byte Spill
	ldr	q3, [sp, #3856]                 ; 16-byte Reload
	ldr	q23, [sp, #3424]                ; 16-byte Reload
	bit.16b	v3, v23, v0
	str	q3, [sp, #3856]                 ; 16-byte Spill
	ldr	q3, [sp, #3872]                 ; 16-byte Reload
	ldr	q10, [sp, #3600]                ; 16-byte Reload
	bit.16b	v3, v10, v1
	str	q3, [sp, #3872]                 ; 16-byte Spill
	ldr	q3, [sp, #3888]                 ; 16-byte Reload
	bit.16b	v3, v6, v0
	str	q3, [sp, #3888]                 ; 16-byte Spill
	ldr	q3, [sp, #3904]                 ; 16-byte Reload
	ldr	q21, [sp, #3440]                ; 16-byte Reload
	bit.16b	v3, v21, v1
	str	q3, [sp, #3904]                 ; 16-byte Spill
	ldr	q3, [sp, #3920]                 ; 16-byte Reload
	bit.16b	v3, v19, v0
	str	q3, [sp, #3920]                 ; 16-byte Spill
	ldr	q3, [sp, #3936]                 ; 16-byte Reload
	ldr	q25, [sp, #3616]                ; 16-byte Reload
	bit.16b	v3, v25, v1
	str	q3, [sp, #3936]                 ; 16-byte Spill
	ldr	q3, [sp, #3952]                 ; 16-byte Reload
	bit.16b	v3, v20, v0
	str	q3, [sp, #3952]                 ; 16-byte Spill
	ldr	q18, [sp, #3632]                ; 16-byte Reload
	bit.16b	v9, v18, v1
	str	q9, [sp, #3056]                 ; 16-byte Spill
	cmp	x12, #9
	ldr	q9, [sp, #2080]                 ; 16-byte Reload
	ldr	q22, [sp, #2048]                ; 16-byte Reload
	b.ne	LBB1_40
	b	LBB1_769
LBB1_647:                               ; %cond.store676
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #320]                  ; 16-byte Reload
	fmov	x13, d3
	strb	w9, [x13]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB1_174
LBB1_648:                               ; %cond.store679
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #320]                  ; 16-byte Reload
	mov.d	x13, v3[1]
	strb	w9, [x13]
	tbz	w12, #2, LBB1_175
LBB1_649:                               ; %cond.store682
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #352]                  ; 16-byte Reload
	fmov	x13, d3
	strb	w9, [x13]
	tbz	w12, #3, LBB1_176
LBB1_650:                               ; %cond.store685
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #352]                  ; 16-byte Reload
	mov.d	x13, v3[1]
	strb	w9, [x13]
	tbz	w12, #4, LBB1_177
LBB1_651:                               ; %cond.store688
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #384]                  ; 16-byte Reload
	fmov	x13, d3
	strb	w9, [x13]
	tbz	w12, #5, LBB1_178
LBB1_652:                               ; %cond.store691
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #384]                  ; 16-byte Reload
	mov.d	x13, v3[1]
	strb	w9, [x13]
	tbz	w12, #6, LBB1_179
LBB1_653:                               ; %cond.store694
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #416]                  ; 16-byte Reload
	fmov	x13, d3
	strb	w9, [x13]
	tbz	w12, #7, LBB1_180
LBB1_654:                               ; %cond.store697
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #416]                  ; 16-byte Reload
	mov.d	x12, v3[1]
	strb	w9, [x12]
	orr	x22, x21, #0x1
	cmp	x22, #129
	cset	w13, lo
	fmov	w12, s2
	dup.8b	v6, w13
	tbz	w12, #0, LBB1_181
LBB1_655:                               ; %cond.store701
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2320]                 ; 16-byte Reload
	fmov	x13, d3
	str	b6, [x13]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB1_182
LBB1_656:                               ; %cond.store705
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2320]                 ; 16-byte Reload
	mov.d	x13, v3[1]
	st1.b	{ v6 }[1], [x13]
	tbz	w12, #2, LBB1_183
LBB1_657:                               ; %cond.store709
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2336]                 ; 16-byte Reload
	fmov	x13, d3
	st1.b	{ v6 }[2], [x13]
	tbz	w12, #3, LBB1_184
LBB1_658:                               ; %cond.store713
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2336]                 ; 16-byte Reload
	mov.d	x13, v3[1]
	st1.b	{ v6 }[3], [x13]
	tbz	w12, #4, LBB1_185
LBB1_659:                               ; %cond.store717
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2352]                 ; 16-byte Reload
	fmov	x13, d3
	st1.b	{ v6 }[4], [x13]
	tbz	w12, #5, LBB1_186
LBB1_660:                               ; %cond.store721
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2352]                 ; 16-byte Reload
	mov.d	x13, v3[1]
	st1.b	{ v6 }[5], [x13]
	tbz	w12, #6, LBB1_187
LBB1_661:                               ; %cond.store725
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2368]                 ; 16-byte Reload
	fmov	x13, d3
	st1.b	{ v6 }[6], [x13]
	tbz	w12, #7, LBB1_188
LBB1_662:                               ; %cond.store729
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2368]                 ; 16-byte Reload
	mov.d	x12, v3[1]
	st1.b	{ v6 }[7], [x12]
	orr	x24, x21, #0x2
	cmp	x24, #129
	cset	w13, lo
	fmov	w12, s2
	dup.8b	v6, w13
	tbz	w12, #0, LBB1_189
LBB1_663:                               ; %cond.store734
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2256]                 ; 16-byte Reload
	fmov	x13, d3
	str	b6, [x13]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB1_190
LBB1_664:                               ; %cond.store738
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2256]                 ; 16-byte Reload
	mov.d	x13, v3[1]
	st1.b	{ v6 }[1], [x13]
	tbz	w12, #2, LBB1_191
LBB1_665:                               ; %cond.store742
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2272]                 ; 16-byte Reload
	fmov	x13, d3
	st1.b	{ v6 }[2], [x13]
	tbz	w12, #3, LBB1_192
LBB1_666:                               ; %cond.store746
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2272]                 ; 16-byte Reload
	mov.d	x13, v3[1]
	st1.b	{ v6 }[3], [x13]
	tbz	w12, #4, LBB1_193
LBB1_667:                               ; %cond.store750
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2288]                 ; 16-byte Reload
	fmov	x13, d3
	st1.b	{ v6 }[4], [x13]
	tbz	w12, #5, LBB1_194
LBB1_668:                               ; %cond.store754
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2288]                 ; 16-byte Reload
	mov.d	x13, v3[1]
	st1.b	{ v6 }[5], [x13]
	tbz	w12, #6, LBB1_195
LBB1_669:                               ; %cond.store758
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2304]                 ; 16-byte Reload
	fmov	x13, d3
	st1.b	{ v6 }[6], [x13]
	tbz	w12, #7, LBB1_196
LBB1_670:                               ; %cond.store762
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2304]                 ; 16-byte Reload
	mov.d	x12, v3[1]
	st1.b	{ v6 }[7], [x12]
	orr	x27, x21, #0x3
	cmp	x27, #129
	cset	w13, lo
	fmov	w12, s2
	dup.8b	v6, w13
	tbz	w12, #0, LBB1_197
LBB1_671:                               ; %cond.store767
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2192]                 ; 16-byte Reload
	fmov	x13, d3
	str	b6, [x13]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB1_198
LBB1_672:                               ; %cond.store771
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2192]                 ; 16-byte Reload
	mov.d	x13, v3[1]
	st1.b	{ v6 }[1], [x13]
	tbz	w12, #2, LBB1_199
LBB1_673:                               ; %cond.store775
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2208]                 ; 16-byte Reload
	fmov	x13, d3
	st1.b	{ v6 }[2], [x13]
	tbz	w12, #3, LBB1_200
LBB1_674:                               ; %cond.store779
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2208]                 ; 16-byte Reload
	mov.d	x13, v3[1]
	st1.b	{ v6 }[3], [x13]
	tbz	w12, #4, LBB1_201
LBB1_675:                               ; %cond.store783
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2224]                 ; 16-byte Reload
	fmov	x13, d3
	st1.b	{ v6 }[4], [x13]
	tbz	w12, #5, LBB1_202
LBB1_676:                               ; %cond.store787
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2224]                 ; 16-byte Reload
	mov.d	x13, v3[1]
	st1.b	{ v6 }[5], [x13]
	tbz	w12, #6, LBB1_203
LBB1_677:                               ; %cond.store791
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2240]                 ; 16-byte Reload
	fmov	x13, d3
	st1.b	{ v6 }[6], [x13]
	tbz	w12, #7, LBB1_204
LBB1_678:                               ; %cond.store795
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2240]                 ; 16-byte Reload
	mov.d	x12, v3[1]
	st1.b	{ v6 }[7], [x12]
	orr	x4, x21, #0x4
	cmp	x4, #129
	cset	w13, lo
	fmov	w12, s2
	dup.8b	v6, w13
	tbz	w12, #0, LBB1_205
LBB1_679:                               ; %cond.store800
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2128]                 ; 16-byte Reload
	fmov	x13, d3
	str	b6, [x13]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB1_206
LBB1_680:                               ; %cond.store804
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2128]                 ; 16-byte Reload
	mov.d	x13, v3[1]
	st1.b	{ v6 }[1], [x13]
	tbz	w12, #2, LBB1_207
LBB1_681:                               ; %cond.store808
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2144]                 ; 16-byte Reload
	fmov	x13, d3
	st1.b	{ v6 }[2], [x13]
	tbz	w12, #3, LBB1_208
LBB1_682:                               ; %cond.store812
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2144]                 ; 16-byte Reload
	mov.d	x13, v3[1]
	st1.b	{ v6 }[3], [x13]
	tbz	w12, #4, LBB1_209
LBB1_683:                               ; %cond.store816
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2160]                 ; 16-byte Reload
	fmov	x13, d3
	st1.b	{ v6 }[4], [x13]
	tbz	w12, #5, LBB1_210
LBB1_684:                               ; %cond.store820
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2160]                 ; 16-byte Reload
	mov.d	x13, v3[1]
	st1.b	{ v6 }[5], [x13]
	tbz	w12, #6, LBB1_211
LBB1_685:                               ; %cond.store824
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2176]                 ; 16-byte Reload
	fmov	x13, d3
	st1.b	{ v6 }[6], [x13]
	tbnz	w12, #7, LBB1_212
	b	LBB1_213
LBB1_686:                               ; %cond.store833
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2032]                 ; 16-byte Reload
	fmov	x13, d3
	str	b6, [x13]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB1_215
LBB1_687:                               ; %cond.store837
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2032]                 ; 16-byte Reload
	mov.d	x13, v3[1]
	st1.b	{ v6 }[1], [x13]
	tbz	w12, #2, LBB1_216
LBB1_688:                               ; %cond.store841
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2064]                 ; 16-byte Reload
	fmov	x13, d3
	st1.b	{ v6 }[2], [x13]
	tbz	w12, #3, LBB1_217
LBB1_689:                               ; %cond.store845
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2064]                 ; 16-byte Reload
	mov.d	x13, v3[1]
	st1.b	{ v6 }[3], [x13]
	tbz	w12, #4, LBB1_218
LBB1_690:                               ; %cond.store849
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2096]                 ; 16-byte Reload
	fmov	x13, d3
	st1.b	{ v6 }[4], [x13]
	tbz	w12, #5, LBB1_219
LBB1_691:                               ; %cond.store853
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2096]                 ; 16-byte Reload
	mov.d	x13, v3[1]
	st1.b	{ v6 }[5], [x13]
	tbz	w12, #6, LBB1_220
LBB1_692:                               ; %cond.store857
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2112]                 ; 16-byte Reload
	fmov	x13, d3
	st1.b	{ v6 }[6], [x13]
	tbz	w12, #7, LBB1_221
LBB1_693:                               ; %cond.store861
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2112]                 ; 16-byte Reload
	mov.d	x12, v3[1]
	st1.b	{ v6 }[7], [x12]
	orr	x7, x21, #0x6
	cmp	x7, #129
	cset	w13, lo
	fmov	w12, s2
	dup.8b	v6, w13
	tbz	w12, #0, LBB1_222
LBB1_694:                               ; %cond.store866
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1968]                 ; 16-byte Reload
	fmov	x13, d3
	str	b6, [x13]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB1_223
LBB1_695:                               ; %cond.store870
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1968]                 ; 16-byte Reload
	mov.d	x13, v3[1]
	st1.b	{ v6 }[1], [x13]
	tbz	w12, #2, LBB1_224
LBB1_696:                               ; %cond.store874
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1984]                 ; 16-byte Reload
	fmov	x13, d3
	st1.b	{ v6 }[2], [x13]
	tbz	w12, #3, LBB1_225
LBB1_697:                               ; %cond.store878
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1984]                 ; 16-byte Reload
	mov.d	x13, v3[1]
	st1.b	{ v6 }[3], [x13]
	tbz	w12, #4, LBB1_226
LBB1_698:                               ; %cond.store882
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2000]                 ; 16-byte Reload
	fmov	x13, d3
	st1.b	{ v6 }[4], [x13]
	tbz	w12, #5, LBB1_227
LBB1_699:                               ; %cond.store886
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2000]                 ; 16-byte Reload
	mov.d	x13, v3[1]
	st1.b	{ v6 }[5], [x13]
	tbz	w12, #6, LBB1_228
LBB1_700:                               ; %cond.store890
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2016]                 ; 16-byte Reload
	fmov	x13, d3
	st1.b	{ v6 }[6], [x13]
	mov	x2, x30
	tbz	w12, #7, LBB1_229
LBB1_701:                               ; %cond.store894
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2016]                 ; 16-byte Reload
	mov.d	x12, v3[1]
	st1.b	{ v6 }[7], [x12]
	orr	x30, x21, #0x7
	cmp	x30, #129
	cset	w13, lo
	fmov	w12, s2
	dup.8b	v6, w13
	tbz	w12, #0, LBB1_230
LBB1_702:                               ; %cond.store899
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1904]                 ; 16-byte Reload
	fmov	x13, d3
	str	b6, [x13]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB1_231
LBB1_703:                               ; %cond.store903
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1904]                 ; 16-byte Reload
	mov.d	x13, v3[1]
	st1.b	{ v6 }[1], [x13]
	tbz	w12, #2, LBB1_232
LBB1_704:                               ; %cond.store907
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1920]                 ; 16-byte Reload
	fmov	x13, d3
	st1.b	{ v6 }[2], [x13]
	tbz	w12, #3, LBB1_233
LBB1_705:                               ; %cond.store911
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1920]                 ; 16-byte Reload
	mov.d	x13, v3[1]
	st1.b	{ v6 }[3], [x13]
	tbz	w12, #4, LBB1_234
LBB1_706:                               ; %cond.store915
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1936]                 ; 16-byte Reload
	fmov	x13, d3
	st1.b	{ v6 }[4], [x13]
	tbz	w12, #5, LBB1_235
LBB1_707:                               ; %cond.store919
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1936]                 ; 16-byte Reload
	mov.d	x13, v3[1]
	st1.b	{ v6 }[5], [x13]
	tbz	w12, #6, LBB1_236
LBB1_708:                               ; %cond.store923
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1952]                 ; 16-byte Reload
	fmov	x13, d3
	st1.b	{ v6 }[6], [x13]
	tbz	w12, #7, LBB1_237
LBB1_709:                               ; %cond.store927
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1952]                 ; 16-byte Reload
	mov.d	x12, v3[1]
	st1.b	{ v6 }[7], [x12]
	orr	x13, x21, #0x8
	cmp	x13, #129
	cset	w14, lo
	fmov	w12, s2
	dup.8b	v6, w14
	tbz	w12, #0, LBB1_238
LBB1_710:                               ; %cond.store932
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1840]                 ; 16-byte Reload
	fmov	x14, d3
	str	b6, [x14]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB1_239
LBB1_711:                               ; %cond.store936
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1840]                 ; 16-byte Reload
	mov.d	x14, v3[1]
	st1.b	{ v6 }[1], [x14]
	tbz	w12, #2, LBB1_240
LBB1_712:                               ; %cond.store940
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1856]                 ; 16-byte Reload
	fmov	x14, d3
	st1.b	{ v6 }[2], [x14]
	tbz	w12, #3, LBB1_241
LBB1_713:                               ; %cond.store944
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1856]                 ; 16-byte Reload
	mov.d	x14, v3[1]
	st1.b	{ v6 }[3], [x14]
	tbz	w12, #4, LBB1_242
LBB1_714:                               ; %cond.store948
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1872]                 ; 16-byte Reload
	fmov	x14, d3
	st1.b	{ v6 }[4], [x14]
	tbz	w12, #5, LBB1_243
LBB1_715:                               ; %cond.store952
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1872]                 ; 16-byte Reload
	mov.d	x14, v3[1]
	st1.b	{ v6 }[5], [x14]
	tbz	w12, #6, LBB1_244
LBB1_716:                               ; %cond.store956
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1888]                 ; 16-byte Reload
	fmov	x14, d3
	st1.b	{ v6 }[6], [x14]
	tbnz	w12, #7, LBB1_245
	b	LBB1_246
LBB1_717:                               ; %cond.store965
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1776]                 ; 16-byte Reload
	fmov	x15, d3
	str	b6, [x15]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB1_248
LBB1_718:                               ; %cond.store969
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1776]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	st1.b	{ v6 }[1], [x15]
	tbz	w14, #2, LBB1_249
LBB1_719:                               ; %cond.store973
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1792]                 ; 16-byte Reload
	fmov	x15, d3
	st1.b	{ v6 }[2], [x15]
	tbz	w14, #3, LBB1_250
LBB1_720:                               ; %cond.store977
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1792]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	st1.b	{ v6 }[3], [x15]
	tbz	w14, #4, LBB1_251
LBB1_721:                               ; %cond.store981
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1808]                 ; 16-byte Reload
	fmov	x15, d3
	st1.b	{ v6 }[4], [x15]
	tbz	w14, #5, LBB1_252
LBB1_722:                               ; %cond.store985
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1808]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	st1.b	{ v6 }[5], [x15]
	tbz	w14, #6, LBB1_253
LBB1_723:                               ; %cond.store989
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1824]                 ; 16-byte Reload
	fmov	x15, d3
	st1.b	{ v6 }[6], [x15]
	tbnz	w14, #7, LBB1_254
	b	LBB1_255
LBB1_724:                               ; %cond.store998
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1712]                 ; 16-byte Reload
	fmov	x15, d3
	str	b6, [x15]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB1_257
LBB1_725:                               ; %cond.store1002
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1712]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	st1.b	{ v6 }[1], [x15]
	tbz	w14, #2, LBB1_258
LBB1_726:                               ; %cond.store1006
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1728]                 ; 16-byte Reload
	fmov	x15, d3
	st1.b	{ v6 }[2], [x15]
	tbz	w14, #3, LBB1_259
LBB1_727:                               ; %cond.store1010
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1728]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	st1.b	{ v6 }[3], [x15]
	tbz	w14, #4, LBB1_260
LBB1_728:                               ; %cond.store1014
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1744]                 ; 16-byte Reload
	fmov	x15, d3
	st1.b	{ v6 }[4], [x15]
	tbz	w14, #5, LBB1_261
LBB1_729:                               ; %cond.store1018
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1744]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	st1.b	{ v6 }[5], [x15]
	tbz	w14, #6, LBB1_262
LBB1_730:                               ; %cond.store1022
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1760]                 ; 16-byte Reload
	fmov	x15, d3
	st1.b	{ v6 }[6], [x15]
	tbnz	w14, #7, LBB1_263
	b	LBB1_264
LBB1_731:                               ; %cond.store1031
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1648]                 ; 16-byte Reload
	fmov	x15, d3
	str	b6, [x15]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB1_266
LBB1_732:                               ; %cond.store1035
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1648]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	st1.b	{ v6 }[1], [x15]
	tbz	w14, #2, LBB1_267
LBB1_733:                               ; %cond.store1039
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1664]                 ; 16-byte Reload
	fmov	x15, d3
	st1.b	{ v6 }[2], [x15]
	tbz	w14, #3, LBB1_268
LBB1_734:                               ; %cond.store1043
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1664]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	st1.b	{ v6 }[3], [x15]
	tbz	w14, #4, LBB1_269
LBB1_735:                               ; %cond.store1047
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1680]                 ; 16-byte Reload
	fmov	x15, d3
	st1.b	{ v6 }[4], [x15]
	tbz	w14, #5, LBB1_270
LBB1_736:                               ; %cond.store1051
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1680]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	st1.b	{ v6 }[5], [x15]
	tbz	w14, #6, LBB1_271
LBB1_737:                               ; %cond.store1055
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1696]                 ; 16-byte Reload
	fmov	x15, d3
	st1.b	{ v6 }[6], [x15]
	tbz	w14, #7, LBB1_272
LBB1_738:                               ; %cond.store1059
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1696]                 ; 16-byte Reload
	mov.d	x14, v3[1]
	st1.b	{ v6 }[7], [x14]
	orr	x14, x21, #0xc
	cmp	x14, #129
	cset	w1, lo
	fmov	w15, s2
	dup.8b	v6, w1
	tbz	w15, #0, LBB1_273
LBB1_739:                               ; %cond.store1064
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1584]                 ; 16-byte Reload
	fmov	x1, d3
	str	b6, [x1]
	and	w15, w15, #0xff
	tbz	w15, #1, LBB1_274
LBB1_740:                               ; %cond.store1068
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1584]                 ; 16-byte Reload
	mov.d	x1, v3[1]
	st1.b	{ v6 }[1], [x1]
	tbz	w15, #2, LBB1_275
LBB1_741:                               ; %cond.store1072
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1600]                 ; 16-byte Reload
	fmov	x1, d3
	st1.b	{ v6 }[2], [x1]
	tbz	w15, #3, LBB1_276
LBB1_742:                               ; %cond.store1076
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1600]                 ; 16-byte Reload
	mov.d	x1, v3[1]
	st1.b	{ v6 }[3], [x1]
	tbz	w15, #4, LBB1_277
LBB1_743:                               ; %cond.store1080
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1616]                 ; 16-byte Reload
	fmov	x1, d3
	st1.b	{ v6 }[4], [x1]
	tbz	w15, #5, LBB1_278
LBB1_744:                               ; %cond.store1084
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1616]                 ; 16-byte Reload
	mov.d	x1, v3[1]
	st1.b	{ v6 }[5], [x1]
	tbz	w15, #6, LBB1_279
LBB1_745:                               ; %cond.store1088
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1632]                 ; 16-byte Reload
	fmov	x1, d3
	st1.b	{ v6 }[6], [x1]
	tbnz	w15, #7, LBB1_280
	b	LBB1_281
LBB1_746:                               ; %cond.store1097
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1520]                 ; 16-byte Reload
	fmov	x1, d3
	str	b6, [x1]
	and	w15, w15, #0xff
	tbz	w15, #1, LBB1_283
LBB1_747:                               ; %cond.store1101
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1520]                 ; 16-byte Reload
	mov.d	x1, v3[1]
	st1.b	{ v6 }[1], [x1]
	tbz	w15, #2, LBB1_284
LBB1_748:                               ; %cond.store1105
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1536]                 ; 16-byte Reload
	fmov	x1, d3
	st1.b	{ v6 }[2], [x1]
	tbz	w15, #3, LBB1_285
LBB1_749:                               ; %cond.store1109
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1536]                 ; 16-byte Reload
	mov.d	x1, v3[1]
	st1.b	{ v6 }[3], [x1]
	tbz	w15, #4, LBB1_286
LBB1_750:                               ; %cond.store1113
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1552]                 ; 16-byte Reload
	fmov	x1, d3
	st1.b	{ v6 }[4], [x1]
	tbz	w15, #5, LBB1_287
LBB1_751:                               ; %cond.store1117
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1552]                 ; 16-byte Reload
	mov.d	x1, v3[1]
	st1.b	{ v6 }[5], [x1]
	tbz	w15, #6, LBB1_288
LBB1_752:                               ; %cond.store1121
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1568]                 ; 16-byte Reload
	fmov	x1, d3
	st1.b	{ v6 }[6], [x1]
	tbz	w15, #7, LBB1_289
LBB1_753:                               ; %cond.store1125
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1568]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	st1.b	{ v6 }[7], [x15]
	orr	x1, x21, #0xe
	cmp	x1, #129
	cset	w20, lo
	fmov	w15, s2
	dup.8b	v6, w20
	tbz	w15, #0, LBB1_290
LBB1_754:                               ; %cond.store1130
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1456]                 ; 16-byte Reload
	fmov	x20, d3
	str	b6, [x20]
	and	w15, w15, #0xff
	tbz	w15, #1, LBB1_291
LBB1_755:                               ; %cond.store1134
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1456]                 ; 16-byte Reload
	mov.d	x20, v3[1]
	st1.b	{ v6 }[1], [x20]
	tbz	w15, #2, LBB1_292
LBB1_756:                               ; %cond.store1138
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1472]                 ; 16-byte Reload
	fmov	x20, d3
	st1.b	{ v6 }[2], [x20]
	tbz	w15, #3, LBB1_293
LBB1_757:                               ; %cond.store1142
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1472]                 ; 16-byte Reload
	mov.d	x20, v3[1]
	st1.b	{ v6 }[3], [x20]
	tbz	w15, #4, LBB1_294
LBB1_758:                               ; %cond.store1146
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1488]                 ; 16-byte Reload
	fmov	x20, d3
	st1.b	{ v6 }[4], [x20]
	tbz	w15, #5, LBB1_295
LBB1_759:                               ; %cond.store1150
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1488]                 ; 16-byte Reload
	mov.d	x20, v3[1]
	st1.b	{ v6 }[5], [x20]
	tbz	w15, #6, LBB1_296
LBB1_760:                               ; %cond.store1154
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1504]                 ; 16-byte Reload
	fmov	x20, d3
	st1.b	{ v6 }[6], [x20]
	tbz	w15, #7, LBB1_297
LBB1_761:                               ; %cond.store1158
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1504]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	st1.b	{ v6 }[7], [x15]
	orr	x15, x21, #0xf
	cmp	x15, #129
	cset	w21, lo
	fmov	w20, s2
	dup.8b	v6, w21
	tbz	w20, #0, LBB1_298
LBB1_762:                               ; %cond.store1163
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1392]                 ; 16-byte Reload
	fmov	x21, d3
	str	b6, [x21]
	and	w20, w20, #0xff
	tbz	w20, #1, LBB1_299
LBB1_763:                               ; %cond.store1167
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1392]                 ; 16-byte Reload
	mov.d	x21, v3[1]
	st1.b	{ v6 }[1], [x21]
	tbz	w20, #2, LBB1_300
LBB1_764:                               ; %cond.store1171
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1408]                 ; 16-byte Reload
	fmov	x21, d3
	st1.b	{ v6 }[2], [x21]
	tbz	w20, #3, LBB1_301
LBB1_765:                               ; %cond.store1175
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1408]                 ; 16-byte Reload
	mov.d	x21, v3[1]
	st1.b	{ v6 }[3], [x21]
	tbz	w20, #4, LBB1_302
LBB1_766:                               ; %cond.store1179
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1424]                 ; 16-byte Reload
	fmov	x21, d3
	st1.b	{ v6 }[4], [x21]
	tbz	w20, #5, LBB1_303
LBB1_767:                               ; %cond.store1183
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1424]                 ; 16-byte Reload
	mov.d	x21, v3[1]
	st1.b	{ v6 }[5], [x21]
	str	q19, [sp, #4512]                ; 16-byte Spill
	str	q21, [sp, #3088]                ; 16-byte Spill
	tbz	w20, #6, LBB1_304
LBB1_768:                               ; %cond.store1187
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1440]                 ; 16-byte Reload
	fmov	x21, d3
	st1.b	{ v6 }[6], [x21]
	str	q24, [sp, #3072]                ; 16-byte Spill
	sshll.2d	v19, v1, #0
	sshll.2d	v22, v0, #0
	sshll.2d	v16, v1, #0
	sshll.2d	v21, v0, #0
	tbnz	w20, #7, LBB1_305
	b	LBB1_306
LBB1_769:                               ; %direct.false217.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x8, #0                          ; =0x0
	mov	w9, #52352                      ; =0xcc80
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	ldp	q3, q4, [x9]
	bit.16b	v4, v28, v0
	bit.16b	v3, v27, v1
	stp	q3, q4, [x9]
	mov	w9, #52384                      ; =0xcca0
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	ldp	q3, q4, [x9]
	bit.16b	v4, v31, v0
	bit.16b	v3, v8, v1
	stp	q3, q4, [x9]
	mov	w9, #52416                      ; =0xccc0
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	ldp	q3, q4, [x9]
	bit.16b	v4, v7, v0
	bit.16b	v3, v16, v1
	stp	q3, q4, [x9]
	mov	w9, #52448                      ; =0xcce0
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	ldp	q3, q4, [x9]
	bit.16b	v4, v12, v0
	bit.16b	v3, v5, v1
	stp	q3, q4, [x9]
	mov	w9, #52480                      ; =0xcd00
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	ldp	q3, q4, [x9]
	bit.16b	v4, v23, v0
	bit.16b	v3, v10, v1
	stp	q3, q4, [x9]
	mov	w9, #52512                      ; =0xcd20
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	ldp	q3, q4, [x9]
	bit.16b	v4, v6, v0
	bit.16b	v3, v21, v1
	stp	q3, q4, [x9]
	mov	w9, #52544                      ; =0xcd40
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	ldp	q3, q4, [x9]
	bit.16b	v4, v19, v0
	bit.16b	v3, v25, v1
	stp	q3, q4, [x9]
	sshll.2d	v5, v1, #0
	sshll.2d	v4, v0, #0
	mov	w9, #52576                      ; =0xcd60
	movk	w9, #1, lsl #16
	add	x9, x30, x9
	ldp	q3, q6, [x9]
	mov.16b	v7, v0
	bsl.16b	v7, v20, v6
	mov.16b	v16, v1
	bsl.16b	v16, v18, v3
	ldr	q3, [sp, #96]                   ; 16-byte Reload
	shl.2d	v3, v3, #6
	ldp	q18, q6, [sp, #32]              ; 32-byte Folded Reload
	shl.2d	v6, v6, #6
	ldr	q17, [sp, #160]                 ; 16-byte Reload
	shl.2d	v17, v17, #6
	shl.2d	v18, v18, #6
	ldr	q19, [sp, #16]                  ; 16-byte Reload
	orr.16b	v18, v18, v19
	ldr	q19, [sp, #144]                 ; 16-byte Reload
	orr.16b	v17, v17, v19
	ldr	q19, [sp, #64]                  ; 16-byte Reload
	orr.16b	v6, v6, v19
	ldr	q19, [sp, #112]                 ; 16-byte Reload
	orr.16b	v3, v3, v19
	ldr	q19, [sp, #4304]                ; 16-byte Reload
	and.16b	v3, v19, v3
	and.16b	v4, v4, v6
	and.16b	v5, v5, v17
	ldr	q6, [sp, #4288]                 ; 16-byte Reload
	and.16b	v6, v6, v18
	stp	q16, q7, [x9]
	ldr	x1, [sp, #312]                  ; 8-byte Reload
	ldr	w14, [sp, #252]                 ; 4-byte Reload
	ldr	x15, [sp, #240]                 ; 8-byte Reload
	ldr	w16, [sp, #236]                 ; 4-byte Reload
	ldr	x17, [sp, #136]                 ; 8-byte Reload
	ldr	x0, [sp, #88]                   ; 8-byte Reload
	b	LBB1_771
LBB1_770:                               ; %else1945
                                        ;   in Loop: Header=BB1_771 Depth=2
	add	x8, x8, #1
	cmp	x8, #384
	b.eq	LBB1_2
LBB1_771:                               ; %direct.true928.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w9, s2
	and	w10, w8, #0xffff
	mul	w10, w10, w23
	lsr	w10, w10, #21
	dup.2d	v7, x10
	add.2d	v16, v7, v5
	mov.d	x12, v16[1]
	fmov	x13, d16
	add	x13, x13, x13, lsl #1
	lsl	x13, x13, #4
	fmov	d17, x13
	msub	w13, w10, w28, w8
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #4
	mov.d	v17[1], x12
	and	x12, x13, #0xffff
	dup.2d	v16, x12
	add.2d	v17, v17, v16
	umaddl	x12, w10, w28, x12
	add	x12, x11, x12, lsl #5
	ldp	q19, q18, [x12]
	and.16b	v20, v1, v19
	add	x10, x0, x10, lsl #5
	ldp	q21, q19, [x10]
	and.16b	v21, v1, v21
	fdiv.4s	v20, v20, v21
	shl.2d	v21, v17, #2
	dup.2d	v17, x17
	add.2d	v21, v17, v21
	tbz	w9, #0, LBB1_773
; %bb.772:                              ; %cond.store1914
                                        ;   in Loop: Header=BB1_771 Depth=2
	fmov	x10, d21
	str	s20, [x10]
LBB1_773:                               ; %else1917
                                        ;   in Loop: Header=BB1_771 Depth=2
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_775
; %bb.774:                              ; %cond.store1918
                                        ;   in Loop: Header=BB1_771 Depth=2
	mov.d	x10, v21[1]
	st1.s	{ v20 }[1], [x10]
LBB1_775:                               ; %else1921
                                        ;   in Loop: Header=BB1_771 Depth=2
	add.2d	v21, v7, v3
	mov.d	x10, v21[1]
	fmov	x12, d21
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #4
	fmov	d21, x12
	add	x10, x10, x10, lsl #1
	lsl	x10, x10, #4
	mov.d	v21[1], x10
	add.2d	v21, v21, v16
	shl.2d	v21, v21, #2
	add.2d	v21, v17, v21
	tbz	w9, #2, LBB1_777
; %bb.776:                              ; %cond.store1922
                                        ;   in Loop: Header=BB1_771 Depth=2
	fmov	x10, d21
	st1.s	{ v20 }[2], [x10]
LBB1_777:                               ; %else1925
                                        ;   in Loop: Header=BB1_771 Depth=2
	tbz	w9, #3, LBB1_779
; %bb.778:                              ; %cond.store1926
                                        ;   in Loop: Header=BB1_771 Depth=2
	mov.d	x10, v21[1]
	st1.s	{ v20 }[3], [x10]
LBB1_779:                               ; %else1929
                                        ;   in Loop: Header=BB1_771 Depth=2
	add.2d	v20, v7, v4
	mov.d	x10, v20[1]
	fmov	x12, d20
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #4
	fmov	d20, x12
	add	x10, x10, x10, lsl #1
	lsl	x10, x10, #4
	mov.d	v20[1], x10
	add.2d	v20, v20, v16
	and.16b	v18, v0, v18
	and.16b	v19, v0, v19
	fdiv.4s	v18, v18, v19
	shl.2d	v19, v20, #2
	add.2d	v19, v17, v19
	tbz	w9, #4, LBB1_781
; %bb.780:                              ; %cond.store1930
                                        ;   in Loop: Header=BB1_771 Depth=2
	fmov	x10, d19
	str	s18, [x10]
LBB1_781:                               ; %else1933
                                        ;   in Loop: Header=BB1_771 Depth=2
	tbz	w9, #5, LBB1_783
; %bb.782:                              ; %cond.store1934
                                        ;   in Loop: Header=BB1_771 Depth=2
	mov.d	x10, v19[1]
	st1.s	{ v18 }[1], [x10]
LBB1_783:                               ; %else1937
                                        ;   in Loop: Header=BB1_771 Depth=2
	add.2d	v7, v7, v6
	mov.d	x10, v7[1]
	fmov	x12, d7
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #4
	fmov	d7, x12
	add	x10, x10, x10, lsl #1
	lsl	x10, x10, #4
	mov.d	v7[1], x10
	add.2d	v7, v7, v16
	shl.2d	v7, v7, #2
	add.2d	v7, v17, v7
	tbnz	w9, #6, LBB1_785
; %bb.784:                              ; %else1941
                                        ;   in Loop: Header=BB1_771 Depth=2
	tbz	w9, #7, LBB1_770
	b	LBB1_786
LBB1_785:                               ; %cond.store1938
                                        ;   in Loop: Header=BB1_771 Depth=2
	fmov	x10, d7
	st1.s	{ v18 }[2], [x10]
	tbz	w9, #7, LBB1_770
LBB1_786:                               ; %cond.store1942
                                        ;   in Loop: Header=BB1_771 Depth=2
	mov.d	x9, v7[1]
	st1.s	{ v18 }[3], [x9]
	b	LBB1_770
LBB1_787:                               ; %block.batch.exit
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #1632
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh174, Lloh175
	.loh AdrpAdrp	Lloh172, Lloh174
	.loh AdrpLdr	Lloh172, Lloh173
	.loh AdrpLdr	Lloh182, Lloh183
	.loh AdrpAdrp	Lloh180, Lloh182
	.loh AdrpLdr	Lloh180, Lloh181
	.loh AdrpAdrp	Lloh178, Lloh180
	.loh AdrpLdr	Lloh178, Lloh179
	.loh AdrpAdrp	Lloh176, Lloh178
	.loh AdrpLdr	Lloh176, Lloh177
	.loh AdrpLdr	Lloh310, Lloh311
	.loh AdrpAdrp	Lloh308, Lloh310
	.loh AdrpLdr	Lloh308, Lloh309
	.loh AdrpAdrp	Lloh306, Lloh308
	.loh AdrpLdr	Lloh306, Lloh307
	.loh AdrpAdrp	Lloh304, Lloh306
	.loh AdrpLdr	Lloh304, Lloh305
	.loh AdrpLdr	Lloh302, Lloh303
	.loh AdrpAdrp	Lloh300, Lloh302
	.loh AdrpLdr	Lloh300, Lloh301
	.loh AdrpAdrp	Lloh298, Lloh300
	.loh AdrpLdr	Lloh298, Lloh299
	.loh AdrpAdrp	Lloh296, Lloh298
	.loh AdrpLdr	Lloh296, Lloh297
	.loh AdrpAdrp	Lloh294, Lloh296
	.loh AdrpLdr	Lloh294, Lloh295
	.loh AdrpAdrp	Lloh292, Lloh294
	.loh AdrpLdr	Lloh292, Lloh293
	.loh AdrpAdrp	Lloh290, Lloh292
	.loh AdrpLdr	Lloh290, Lloh291
	.loh AdrpAdrp	Lloh288, Lloh290
	.loh AdrpLdr	Lloh288, Lloh289
	.loh AdrpAdrp	Lloh286, Lloh288
	.loh AdrpLdr	Lloh286, Lloh287
	.loh AdrpAdrp	Lloh284, Lloh286
	.loh AdrpLdr	Lloh284, Lloh285
	.loh AdrpAdrp	Lloh282, Lloh284
	.loh AdrpLdr	Lloh282, Lloh283
	.loh AdrpAdrp	Lloh280, Lloh282
	.loh AdrpLdr	Lloh280, Lloh281
	.loh AdrpAdrp	Lloh278, Lloh280
	.loh AdrpLdr	Lloh278, Lloh279
	.loh AdrpAdrp	Lloh276, Lloh278
	.loh AdrpLdr	Lloh276, Lloh277
	.loh AdrpAdrp	Lloh274, Lloh276
	.loh AdrpLdr	Lloh274, Lloh275
	.loh AdrpAdrp	Lloh272, Lloh274
	.loh AdrpLdr	Lloh272, Lloh273
	.loh AdrpAdrp	Lloh270, Lloh272
	.loh AdrpLdr	Lloh270, Lloh271
	.loh AdrpAdrp	Lloh268, Lloh270
	.loh AdrpLdr	Lloh268, Lloh269
	.loh AdrpAdrp	Lloh266, Lloh268
	.loh AdrpLdr	Lloh266, Lloh267
	.loh AdrpAdrp	Lloh264, Lloh266
	.loh AdrpLdr	Lloh264, Lloh265
	.loh AdrpAdrp	Lloh262, Lloh264
	.loh AdrpLdr	Lloh262, Lloh263
	.loh AdrpAdrp	Lloh260, Lloh262
	.loh AdrpLdr	Lloh260, Lloh261
	.loh AdrpAdrp	Lloh258, Lloh260
	.loh AdrpLdr	Lloh258, Lloh259
	.loh AdrpAdrp	Lloh256, Lloh258
	.loh AdrpLdr	Lloh256, Lloh257
	.loh AdrpAdrp	Lloh254, Lloh256
	.loh AdrpLdr	Lloh254, Lloh255
	.loh AdrpAdrp	Lloh252, Lloh254
	.loh AdrpLdr	Lloh252, Lloh253
	.loh AdrpAdrp	Lloh250, Lloh252
	.loh AdrpLdr	Lloh250, Lloh251
	.loh AdrpAdrp	Lloh248, Lloh250
	.loh AdrpLdr	Lloh248, Lloh249
	.loh AdrpAdrp	Lloh246, Lloh248
	.loh AdrpLdr	Lloh246, Lloh247
	.loh AdrpAdrp	Lloh244, Lloh246
	.loh AdrpLdr	Lloh244, Lloh245
	.loh AdrpAdrp	Lloh242, Lloh244
	.loh AdrpLdr	Lloh242, Lloh243
	.loh AdrpLdr	Lloh240, Lloh241
	.loh AdrpLdr	Lloh238, Lloh239
	.loh AdrpLdr	Lloh236, Lloh237
	.loh AdrpLdr	Lloh234, Lloh235
	.loh AdrpLdr	Lloh232, Lloh233
	.loh AdrpLdr	Lloh230, Lloh231
	.loh AdrpAdrp	Lloh228, Lloh230
	.loh AdrpLdr	Lloh228, Lloh229
	.loh AdrpLdr	Lloh226, Lloh227
	.loh AdrpAdrp	Lloh224, Lloh226
	.loh AdrpLdr	Lloh224, Lloh225
	.loh AdrpLdr	Lloh222, Lloh223
	.loh AdrpLdr	Lloh220, Lloh221
	.loh AdrpLdr	Lloh218, Lloh219
	.loh AdrpAdrp	Lloh216, Lloh218
	.loh AdrpLdr	Lloh216, Lloh217
	.loh AdrpAdrp	Lloh214, Lloh216
	.loh AdrpLdr	Lloh214, Lloh215
	.loh AdrpAdrp	Lloh212, Lloh214
	.loh AdrpLdr	Lloh212, Lloh213
	.loh AdrpAdrp	Lloh210, Lloh212
	.loh AdrpLdr	Lloh210, Lloh211
	.loh AdrpAdrp	Lloh208, Lloh210
	.loh AdrpLdr	Lloh208, Lloh209
	.loh AdrpAdrp	Lloh206, Lloh208
	.loh AdrpLdr	Lloh206, Lloh207
	.loh AdrpAdrp	Lloh204, Lloh206
	.loh AdrpLdr	Lloh204, Lloh205
	.loh AdrpAdrp	Lloh202, Lloh204
	.loh AdrpLdr	Lloh202, Lloh203
	.loh AdrpAdrp	Lloh200, Lloh202
	.loh AdrpLdr	Lloh200, Lloh201
	.loh AdrpAdrp	Lloh198, Lloh200
	.loh AdrpLdr	Lloh198, Lloh199
	.loh AdrpAdrp	Lloh196, Lloh198
	.loh AdrpLdr	Lloh196, Lloh197
	.loh AdrpAdrp	Lloh194, Lloh196
	.loh AdrpLdr	Lloh194, Lloh195
	.loh AdrpAdrp	Lloh192, Lloh194
	.loh AdrpLdr	Lloh192, Lloh193
	.loh AdrpAdrp	Lloh190, Lloh192
	.loh AdrpLdr	Lloh190, Lloh191
	.loh AdrpAdrp	Lloh188, Lloh190
	.loh AdrpLdr	Lloh188, Lloh189
	.loh AdrpAdrp	Lloh186, Lloh188
	.loh AdrpLdr	Lloh186, Lloh187
	.loh AdrpAdrp	Lloh184, Lloh186
	.loh AdrpLdr	Lloh184, Lloh185
	.loh AdrpLdr	Lloh318, Lloh319
	.loh AdrpAdrp	Lloh316, Lloh318
	.loh AdrpLdr	Lloh316, Lloh317
	.loh AdrpAdrp	Lloh314, Lloh316
	.loh AdrpLdr	Lloh314, Lloh315
	.loh AdrpAdrp	Lloh312, Lloh314
	.loh AdrpLdr	Lloh312, Lloh313
	.loh AdrpLdr	Lloh320, Lloh321
	.loh AdrpLdr	Lloh322, Lloh323
	.loh AdrpLdr	Lloh324, Lloh325
	.loh AdrpLdr	Lloh326, Lloh327
	.loh AdrpLdr	Lloh334, Lloh335
	.loh AdrpAdrp	Lloh332, Lloh334
	.loh AdrpLdr	Lloh332, Lloh333
	.loh AdrpAdrp	Lloh330, Lloh332
	.loh AdrpLdr	Lloh330, Lloh331
	.loh AdrpAdrp	Lloh328, Lloh330
	.loh AdrpLdr	Lloh328, Lloh329
	.loh AdrpLdr	Lloh342, Lloh343
	.loh AdrpAdrp	Lloh340, Lloh342
	.loh AdrpLdr	Lloh340, Lloh341
	.loh AdrpAdrp	Lloh338, Lloh340
	.loh AdrpLdr	Lloh338, Lloh339
	.loh AdrpAdrp	Lloh336, Lloh338
	.loh AdrpLdr	Lloh336, Lloh337
	.loh AdrpLdr	Lloh350, Lloh351
	.loh AdrpAdrp	Lloh348, Lloh350
	.loh AdrpLdr	Lloh348, Lloh349
	.loh AdrpAdrp	Lloh346, Lloh348
	.loh AdrpLdr	Lloh346, Lloh347
	.loh AdrpAdrp	Lloh344, Lloh346
	.loh AdrpLdr	Lloh344, Lloh345
	.loh AdrpLdr	Lloh358, Lloh359
	.loh AdrpAdrp	Lloh356, Lloh358
	.loh AdrpLdr	Lloh356, Lloh357
	.loh AdrpAdrp	Lloh354, Lloh356
	.loh AdrpLdr	Lloh354, Lloh355
	.loh AdrpAdrp	Lloh352, Lloh354
	.loh AdrpLdr	Lloh352, Lloh353
                                        ; -- End function
.subsections_via_symbols

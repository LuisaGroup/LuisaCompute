"""Independently check complete selected build/test/syntax receipts, offline."""
import hashlib
import json
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent
EXPECTED = {
    'src/backends/simd/llvm/llvm_schedule_codegen.cpp',
    'src/backends/simd/llvm/llvm_schedule_emitter_memory.cpp',
    'src/backends/simd/llvm/llvm_schedule_emitter_mma.cpp',
    'src/backends/simd/simd_compiler.cpp',
    'src/backends/simd/runtime/simd_tile.cpp',
    'src/tests/unit/simd/test_llvm_schedule_codegen.cpp',
}


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def receipt(path):
    record = json.loads(path.read_text())
    require(record['returncode'] == 0 and record['source_unchanged'] is True, str(path))
    require(record['finished'] >= record['started'], 'invalid chronology')
    require(sha(path.with_suffix('.log')) == record['log_sha256'], 'log changed')
    return record


build = receipt(OUT / 'full-build-1.json')
test = receipt(OUT / 'regression-1.json')
require(test['started'] >= build['finished'], 'tests preceded complete build')
require(test['source_sha256'] == build['source_sha256'], 'gate sources differ')
require(re.search(r'100% tests passed(?:, 0 tests failed)? out of 11\b',
                  (OUT / 'regression-1.log').read_text()), 'incomplete tests')
syntax = {}
for path in sorted(OUT.glob('syntax-1-*.json')):
    record = receipt(path)
    require(record['source_sha256'] == build['source_sha256'], 'syntax source mismatch')
    command = record['command']
    require(Path(command[1]).name == 'check_cpp_syntax.py', 'wrong syntax command')
    name = Path(command[2]).relative_to(record['selected_source']).as_posix()
    require(name in EXPECTED and name not in syntax, 'wrong/duplicate syntax target')
    syntax[name] = dict(receipt=path.name, sha256=sha(path), log_sha256=record['log_sha256'])
require(set(syntax) == EXPECTED, 'incomplete six-TU syntax gate')
result = dict(status='passed', native_execution=False, syntax=syntax,
              full_build_receipt_sha256=sha(OUT / 'full-build-1.json'),
              test_receipt_sha256=sha(OUT / 'regression-1.json'), tests=11,
              source_sha256=build['source_sha256'])
with (OUT / 'validation-audit.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print('Verified full selected build, 11 tests and six syntax translation units.')

; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_attention(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 2560
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 5632
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 8704
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 49664
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 98816
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 99328
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 99840
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill29 = alloca i64, align 8
  store i64 0, ptr %.spill29, align 4
  %.spill30 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill30, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.spill31 = alloca i64, align 8
  store i64 0, ptr %.spill31, align 4
  %tile_snapshot.spill32 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill32, align 64
  %tile_snapshot.spill33 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill33, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.slot34 = alloca i64, align 8
  store i64 0, ptr %.slot34, align 4
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.slot36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot36, align 32
  %.spill37 = alloca i64, align 8
  store i64 0, ptr %.spill37, align 4
  %tile_snapshot.spill38 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill38, align 64
  %.spill39 = alloca i1, align 1
  store i1 false, ptr %.spill39, align 1
  %tile_snapshot.spill40 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill40, align 64
  %.slot41 = alloca i64, align 8
  store i64 0, ptr %.slot41, align 4
  %.slot42 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot42, align 32
  %.slot43 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot43, align 32
  %.slot44 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot44, align 32
  %.slot45 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot45, align 32
  %.slot46 = alloca i64, align 8
  store i64 0, ptr %.slot46, align 4
  %.slot47 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot47, align 32
  %.slot48 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot48, align 32
  %.slot49 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot49, align 32
  %.slot50 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot50, align 32
  %.slot51 = alloca i64, align 8
  store i64 0, ptr %.slot51, align 4
  %.slot52 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot52, align 32
  %.slot53 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot53, align 32
  %.slot54 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot54, align 32
  %.slot55 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot55, align 32
  %.slot56 = alloca i64, align 8
  store i64 0, ptr %.slot56, align 4
  %.slot57 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot57, align 32
  %.slot58 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot58, align 32
  %.slot59 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot59, align 32
  %.slot60 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot60, align 32
  %.spill61 = alloca i1, align 1
  store i1 false, ptr %.spill61, align 1
  %.spill62 = alloca i1, align 1
  store i1 false, ptr %.spill62, align 1
  %.spill63 = alloca i1, align 1
  store i1 false, ptr %.spill63, align 1
  %.spill64 = alloca i1, align 1
  store i1 false, ptr %.spill64, align 1
  %.spill65 = alloca i1, align 1
  store i1 false, ptr %.spill65, align 1
  %.spill66 = alloca i1, align 1
  store i1 false, ptr %.spill66, align 1
  %.spill67 = alloca i1, align 1
  store i1 false, ptr %.spill67, align 1
  %.spill68 = alloca i1, align 1
  store i1 false, ptr %.spill68, align 1
  %.spill69 = alloca i1, align 1
  store i1 false, ptr %.spill69, align 1
  %.spill70 = alloca i1, align 1
  store i1 false, ptr %.spill70, align 1
  %.spill71 = alloca i1, align 1
  store i1 false, ptr %.spill71, align 1
  %.spill72 = alloca i1, align 1
  store i1 false, ptr %.spill72, align 1
  %.spill73 = alloca i1, align 1
  store i1 false, ptr %.spill73, align 1
  %.spill74 = alloca i1, align 1
  store i1 false, ptr %.spill74, align 1
  %.spill75 = alloca i1, align 1
  store i1 false, ptr %.spill75, align 1
  %.spill76 = alloca i1, align 1
  store i1 false, ptr %.spill76, align 1
  %.spill77 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill77, align 32
  %.spill78 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill78, align 32
  %.spill79 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill79, align 32
  %.spill80 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill80, align 32
  %.spill81 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill81, align 32
  %.spill82 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill82, align 32
  %.spill83 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill83, align 32
  %.spill84 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill84, align 32
  %.spill85 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill85, align 32
  %.spill86 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill86, align 32
  %.spill87 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill87, align 32
  %.spill88 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill88, align 32
  %.spill89 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill89, align 32
  %.spill90 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill90, align 32
  %.spill91 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill91, align 32
  %.spill92 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill92, align 32
  %tile_snapshot.spill93 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill93, align 64
  %.slot94 = alloca i64, align 8
  store i64 0, ptr %.slot94, align 4
  %.slot95 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot95, align 32
  %.spill96 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill96, align 32
  %.spill97 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill97, align 32
  %tile_snapshot.spill98 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill98, align 64
  %.spill99 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill99, align 32
  %.slot100 = alloca i64, align 8
  store i64 0, ptr %.slot100, align 4
  %.slot101 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot101, align 32
  %.spill102 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill102, align 32
  %tile_snapshot.spill103 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill103, align 64
  %.slot104 = alloca i64, align 8
  store i64 0, ptr %.slot104, align 4
  %.spill105 = alloca i64, align 8
  store i64 0, ptr %.spill105, align 4
  %.spill106 = alloca i64, align 8
  store i64 0, ptr %.spill106, align 4
  %.spill107 = alloca i64, align 8
  store i64 0, ptr %.spill107, align 4
  %.spill108 = alloca i64, align 8
  store i64 0, ptr %.spill108, align 4
  %.slot109 = alloca i64, align 8
  store i64 0, ptr %.slot109, align 4
  %.slot110 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot110, align 32
  %.slot111 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot111, align 32
  %.slot112 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot112, align 32
  %.slot113 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot113, align 32
  %.slot114 = alloca i64, align 8
  store i64 0, ptr %.slot114, align 4
  %.slot115 = alloca i64, align 8
  store i64 0, ptr %.slot115, align 4
  %.slot116 = alloca i64, align 8
  store i64 0, ptr %.slot116, align 4
  %.spill117 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill117, align 64
  %.slot118 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot118, align 32
  %.slot119 = alloca i64, align 8
  store i64 0, ptr %.slot119, align 4
  %.spill120 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill120, align 64
  %.slot121 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot121, align 32
  %.slot122 = alloca i64, align 8
  store i64 0, ptr %.slot122, align 4
  %24 = getelementptr i8, ptr %argument_buffer, i64 0
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = getelementptr i8, ptr %argument_buffer, i64 16
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %30, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %33, 1
  %36 = getelementptr i8, ptr %argument_buffer, i64 32
  %37 = load ptr, ptr %36, align 16
  %38 = getelementptr i8, ptr %36, i64 8
  %39 = load i64, ptr %38, align 8
  %40 = insertvalue { ptr, i64 } poison, ptr %37, 0
  %41 = insertvalue { ptr, i64 } %40, i64 %39, 1
  %42 = getelementptr i8, ptr %argument_buffer, i64 48
  %43 = load ptr, ptr %42, align 16
  %44 = getelementptr i8, ptr %42, i64 8
  %45 = load i64, ptr %44, align 8
  %46 = insertvalue { ptr, i64 } poison, ptr %43, 0
  %47 = insertvalue { ptr, i64 } %46, i64 %45, 1
  %48 = load i32, ptr %launch_config, align 4
  %49 = getelementptr i8, ptr %launch_config, i64 12
  %50 = load i32, ptr %49, align 4
  %51 = getelementptr i8, ptr %launch_config, i64 4
  %52 = load i32, ptr %51, align 4
  %53 = getelementptr i8, ptr %launch_config, i64 16
  %54 = load i32, ptr %53, align 4
  %55 = getelementptr i8, ptr %launch_config, i64 8
  %56 = load i32, ptr %55, align 4
  %57 = getelementptr i8, ptr %launch_config, i64 20
  %58 = load i32, ptr %57, align 4
  %59 = getelementptr i8, ptr %launch_config, i64 36
  %60 = load i32, ptr %59, align 4
  %.splatinsert123 = insertelement <8 x i32> poison, i32 %60, i64 0
  %.splat124 = shufflevector <8 x i32> %.splatinsert123, <8 x i32> poison, <8 x i32> zeroinitializer
  %61 = add <8 x i32> %.splat124, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %62 = mul i32 %48, 32
  %.splatinsert125 = insertelement <8 x i32> poison, i32 %62, i64 0
  %.splat126 = shufflevector <8 x i32> %.splatinsert125, <8 x i32> poison, <8 x i32> zeroinitializer
  %63 = add <8 x i32> %.splat126, %61
  %64 = mul i32 %52, 1
  %.splatinsert127 = insertelement <8 x i32> poison, i32 %64, i64 0
  %.splat128 = shufflevector <8 x i32> %.splatinsert127, <8 x i32> poison, <8 x i32> zeroinitializer
  %65 = add <8 x i32> %.splat128, zeroinitializer
  %66 = mul i32 %56, 1
  %.splatinsert129 = insertelement <8 x i32> poison, i32 %66, i64 0
  %.splat130 = shufflevector <8 x i32> %.splatinsert129, <8 x i32> poison, <8 x i32> zeroinitializer
  %67 = add <8 x i32> %.splat130, zeroinitializer
  %68 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %63, 0
  %69 = insertvalue [3 x <8 x i32>] %68, <8 x i32> %65, 1
  %70 = insertvalue [3 x <8 x i32>] %69, <8 x i32> %67, 2
  %.splatinsert131 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat132 = shufflevector <8 x i32> %.splatinsert131, <8 x i32> poison, <8 x i32> zeroinitializer
  %71 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat132
  %72 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  br i1 %72, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %73 = extractvalue [3 x <8 x i32>] %70, 0
  %74 = zext <8 x i32> %73 to <8 x i64>
  %75 = select <8 x i1> %71, <8 x i64> %74, <8 x i64> zeroinitializer
  %76 = select <8 x i1> %71, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %77 = sdiv <8 x i64> %75, %76
  %78 = load <8 x i64>, ptr %.spill, align 64
  %79 = select <8 x i1> %71, <8 x i64> %77, <8 x i64> %78
  store <8 x i64> %79, ptr %.spill, align 64
  store i64 0, ptr %.spill29, align 4
  %80 = select <8 x i1> %71, <8 x i64> %77, <8 x i64> zeroinitializer
  %81 = select <8 x i1> %71, <8 x i64> splat (i64 4), <8 x i64> splat (i64 1)
  %82 = sdiv <8 x i64> %80, %81
  %83 = load <8 x i64>, ptr %.spill30, align 64
  %84 = select <8 x i1> %71, <8 x i64> %82, <8 x i64> %83
  store <8 x i64> %84, ptr %.spill30, align 64
  %85 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %86 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %85, 0
  %88 = select <8 x i1> %71, <8 x ptr> %86, <8 x ptr> %87
  %89 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %85, 1
  %91 = select <8 x i1> %71, <8 x i64> %89, <8 x i64> %90
  %92 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %88, 0
  %93 = insertvalue { <8 x ptr>, <8 x i64> } %92, <8 x i64> %91, 1
  store { <8 x ptr>, <8 x i64> } %93, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.spill31, align 4
  %94 = add <8 x i64> zeroinitializer, %77
  %95 = mul <8 x i64> %94, splat (i64 1)
  %96 = add <8 x i64> %95, zeroinitializer
  %97 = mul <8 x i64> %96, splat (i64 80)
  %98 = add <8 x i64> %97, zeroinitializer
  %99 = extractvalue { ptr, i64 } %29, 0
  %100 = extractelement <8 x i1> %71, i64 0
  br i1 %100, label %copy.active, label %copy.continue

direct.schedule.1:                                ; preds = %direct.schedule.2, %copy.continue146
  %.state = load i64, ptr %.slot, align 4
  %101 = icmp slt i64 %.state, 96
  br i1 %101, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %102 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %103 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state147 = load i64, ptr %.slot, align 4
  %.splatinsert148 = insertelement <8 x i64> poison, i64 %.state147, i64 0
  %.splat149 = shufflevector <8 x i64> %.splatinsert148, <8 x i64> poison, <8 x i32> zeroinitializer
  %104 = mul <8 x i64> %.splat149, splat (i64 32)
  %105 = add <8 x i64> %103, %104
  %106 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %102, 0
  %107 = insertvalue { <8 x ptr>, <8 x i64> } %106, <8 x i64> %105, 1
  %108 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %107, 1
  %110 = extractelement <8 x ptr> %108, i32 0
  %111 = extractelement <8 x i64> %109, i32 0
  %112 = sub i64 %111, 0
  %113 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %114 = select i1 %113, i64 %112, i64 0
  %private.contiguous.address = getelementptr i8, ptr %110, i64 %114
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %115 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %private.contiguous.preserve
  store <8 x float> %115, ptr %private.contiguous.address, align 4
  %.state150 = load i64, ptr %.slot, align 4
  %116 = add i64 %.state150, 1
  store i64 %116, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store i64 0, ptr %.slot34, align 4
  %117 = load <8 x float>, ptr %.slot35, align 32
  %118 = select <8 x i1> %71, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %117
  store <8 x float> %118, ptr %.slot35, align 32
  %119 = load <8 x float>, ptr %.slot36, align 32
  %120 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %119
  store <8 x float> %120, ptr %.slot36, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.39, %direct.schedule.3
  %.state151 = load i64, ptr %.slot34, align 4
  %121 = icmp slt i64 %.state151, 129
  br i1 %121, label %direct.true152, label %direct.false153

direct.schedule.5:                                ; preds = %direct.true152
  %.state154 = load i64, ptr %.slot34, align 4
  %122 = sdiv i64 %.state154, 1
  %123 = mul i64 %122, 16
  store i64 %123, ptr %.spill37, align 4
  %124 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %124, 0
  %127 = select <8 x i1> %71, <8 x ptr> %125, <8 x ptr> %126
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %124, 1
  %130 = select <8 x i1> %71, <8 x i64> %128, <8 x i64> %129
  %131 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %127, 0
  %132 = insertvalue { <8 x ptr>, <8 x i64> } %131, <8 x i64> %130, 1
  store { <8 x ptr>, <8 x i64> } %132, ptr %tile_snapshot.spill38, align 64
  %133 = icmp sge i64 %123, 0
  %134 = and i1 true, %133
  %135 = icmp sle i64 %123, 2037
  %136 = and i1 %134, %135
  store i1 %136, ptr %.spill39, align 1
  br i1 %136, label %direct.true155, label %direct.false156

direct.schedule.6:                                ; preds = %direct.true155
  %.spill.load = load i64, ptr %.spill31, align 4
  %137 = mul i64 %.spill.load, 2
  %.splatinsert157 = insertelement <8 x i64> poison, i64 %137, i64 0
  %.splat158 = shufflevector <8 x i64> %.splatinsert157, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load159 = load <8 x i64>, ptr %.spill30, align 64
  %138 = add <8 x i64> %.splat158, %.spill.load159
  %139 = mul <8 x i64> %138, splat (i64 2053)
  %.spill.load160 = load i64, ptr %.spill37, align 4
  %.splatinsert161 = insertelement <8 x i64> poison, i64 %.spill.load160, i64 0
  %.splat162 = shufflevector <8 x i64> %.splatinsert161, <8 x i64> poison, <8 x i32> zeroinitializer
  %140 = add <8 x i64> %139, %.splat162
  %141 = mul <8 x i64> %140, splat (i64 80)
  %142 = add <8 x i64> %141, zeroinitializer
  %tile_snapshot.spill.load163 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %143 = extractvalue { ptr, i64 } %35, 0
  %144 = extractelement <8 x i1> %71, i64 0
  br i1 %144, label %copy.active164, label %copy.continue165

direct.schedule.7:                                ; preds = %direct.false753, %copy.continue179
  %145 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %145, 0
  %148 = select <8 x i1> %71, <8 x ptr> %146, <8 x ptr> %147
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %145, 1
  %151 = select <8 x i1> %71, <8 x i64> %149, <8 x i64> %150
  %152 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %148, 0
  %153 = insertvalue { <8 x ptr>, <8 x i64> } %152, <8 x i64> %151, 1
  store { <8 x ptr>, <8 x i64> } %153, ptr %tile_snapshot.spill40, align 64
  %.spill.load180 = load i1, ptr %.spill39, align 1
  br i1 %.spill.load180, label %direct.true181, label %direct.false182

direct.schedule.8:                                ; preds = %direct.true181
  %.spill.load183 = load i64, ptr %.spill31, align 4
  %154 = mul i64 %.spill.load183, 2
  %.splatinsert184 = insertelement <8 x i64> poison, i64 %154, i64 0
  %.splat185 = shufflevector <8 x i64> %.splatinsert184, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load186 = load <8 x i64>, ptr %.spill30, align 64
  %155 = add <8 x i64> %.splat185, %.spill.load186
  %156 = mul <8 x i64> %155, splat (i64 2053)
  %.spill.load187 = load i64, ptr %.spill37, align 4
  %.splatinsert188 = insertelement <8 x i64> poison, i64 %.spill.load187, i64 0
  %.splat189 = shufflevector <8 x i64> %.splatinsert188, <8 x i64> poison, <8 x i32> zeroinitializer
  %157 = add <8 x i64> %156, %.splat189
  %158 = mul <8 x i64> %157, splat (i64 96)
  %159 = add <8 x i64> %158, zeroinitializer
  %tile_snapshot.spill.load190 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %160 = extractvalue { ptr, i64 } %41, 0
  %161 = extractelement <8 x i1> %71, i64 0
  br i1 %161, label %copy.active191, label %copy.continue192

direct.schedule.9:                                ; preds = %direct.false728, %copy.continue206
  store i64 0, ptr %.slot41, align 4
  %162 = load <8 x float>, ptr %.slot42, align 32
  %163 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %162
  store <8 x float> %163, ptr %.slot42, align 32
  %164 = load <8 x float>, ptr %.slot43, align 32
  %165 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %164
  store <8 x float> %165, ptr %.slot43, align 32
  %166 = load <8 x float>, ptr %.slot44, align 32
  %167 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %166
  store <8 x float> %167, ptr %.slot44, align 32
  %168 = load <8 x float>, ptr %.slot45, align 32
  %169 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %168
  store <8 x float> %169, ptr %.slot45, align 32
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state207 = load i64, ptr %.slot41, align 4
  %170 = icmp slt i64 %.state207, 80
  br i1 %170, label %direct.true208, label %direct.false209

direct.schedule.11:                               ; preds = %direct.true208
  %.state210 = load i64, ptr %.slot41, align 4
  %171 = add i64 0, %.state210
  %tile_snapshot.spill.load211 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load211, 0
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load211, 1
  %.splatinsert212 = insertelement <8 x i64> poison, i64 %171, i64 0
  %.splat213 = shufflevector <8 x i64> %.splatinsert212, <8 x i64> poison, <8 x i32> zeroinitializer
  %174 = mul <8 x i64> %.splat213, splat (i64 32)
  %175 = add <8 x i64> %173, %174
  %176 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %172, 0
  %177 = insertvalue { <8 x ptr>, <8 x i64> } %176, <8 x i64> %175, 1
  %178 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %177, 1
  %180 = extractelement <8 x ptr> %178, i32 0
  %181 = extractelement <8 x i64> %179, i32 0
  %182 = sub i64 %181, 0
  %183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %184 = select i1 %183, i64 %182, i64 0
  %private.contiguous.address214 = getelementptr i8, ptr %180, i64 %184
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address214, align 4
  %185 = select <8 x i1> %71, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load215 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %186 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load215, 0
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load215, 1
  %.splatinsert216 = insertelement <8 x i64> poison, i64 %171, i64 0
  %.splat217 = shufflevector <8 x i64> %.splatinsert216, <8 x i64> poison, <8 x i32> zeroinitializer
  %188 = mul <8 x i64> %.splat217, splat (i64 32)
  %189 = add <8 x i64> %187, %188
  %190 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %186, 0
  %191 = insertvalue { <8 x ptr>, <8 x i64> } %190, <8 x i64> %189, 1
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %191, 1
  %194 = extractelement <8 x ptr> %192, i32 0
  %195 = extractelement <8 x i64> %193, i32 0
  %196 = sub i64 %195, 0
  %197 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %198 = select i1 %197, i64 %196, i64 0
  %private.contiguous.address218 = getelementptr i8, ptr %194, i64 %198
  %private.contiguous.load219 = load <8 x float>, ptr %private.contiguous.address218, align 4
  %199 = select <8 x i1> %71, <8 x float> %private.contiguous.load219, <8 x float> zeroinitializer
  %200 = fmul <8 x float> %185, %199
  %.state220 = load <8 x float>, ptr %.slot42, align 32
  %201 = fadd <8 x float> %.state220, %200
  %.state221 = load i64, ptr %.slot41, align 4
  %202 = add i64 80, %.state221
  %tile_snapshot.spill.load222 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %203 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load222, 0
  %204 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load222, 1
  %.splatinsert223 = insertelement <8 x i64> poison, i64 %202, i64 0
  %.splat224 = shufflevector <8 x i64> %.splatinsert223, <8 x i64> poison, <8 x i32> zeroinitializer
  %205 = mul <8 x i64> %.splat224, splat (i64 32)
  %206 = add <8 x i64> %204, %205
  %207 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %203, 0
  %208 = insertvalue { <8 x ptr>, <8 x i64> } %207, <8 x i64> %206, 1
  %209 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %210 = extractvalue { <8 x ptr>, <8 x i64> } %208, 1
  %211 = extractelement <8 x ptr> %209, i32 0
  %212 = extractelement <8 x i64> %210, i32 0
  %213 = sub i64 %212, 0
  %214 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %215 = select i1 %214, i64 %213, i64 0
  %private.contiguous.address225 = getelementptr i8, ptr %211, i64 %215
  %private.contiguous.load226 = load <8 x float>, ptr %private.contiguous.address225, align 4
  %216 = select <8 x i1> %71, <8 x float> %private.contiguous.load226, <8 x float> zeroinitializer
  %217 = fmul <8 x float> %185, %216
  %.state227 = load <8 x float>, ptr %.slot43, align 32
  %218 = fadd <8 x float> %.state227, %217
  %.state228 = load i64, ptr %.slot41, align 4
  %219 = add i64 160, %.state228
  %tile_snapshot.spill.load229 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load229, 0
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load229, 1
  %.splatinsert230 = insertelement <8 x i64> poison, i64 %219, i64 0
  %.splat231 = shufflevector <8 x i64> %.splatinsert230, <8 x i64> poison, <8 x i32> zeroinitializer
  %222 = mul <8 x i64> %.splat231, splat (i64 32)
  %223 = add <8 x i64> %221, %222
  %224 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %220, 0
  %225 = insertvalue { <8 x ptr>, <8 x i64> } %224, <8 x i64> %223, 1
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %225, 1
  %228 = extractelement <8 x ptr> %226, i32 0
  %229 = extractelement <8 x i64> %227, i32 0
  %230 = sub i64 %229, 0
  %231 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %232 = select i1 %231, i64 %230, i64 0
  %private.contiguous.address232 = getelementptr i8, ptr %228, i64 %232
  %private.contiguous.load233 = load <8 x float>, ptr %private.contiguous.address232, align 4
  %233 = select <8 x i1> %71, <8 x float> %private.contiguous.load233, <8 x float> zeroinitializer
  %234 = fmul <8 x float> %185, %233
  %.state234 = load <8 x float>, ptr %.slot44, align 32
  %235 = fadd <8 x float> %.state234, %234
  %.state235 = load i64, ptr %.slot41, align 4
  %236 = add i64 240, %.state235
  %tile_snapshot.spill.load236 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %237 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load236, 0
  %238 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load236, 1
  %.splatinsert237 = insertelement <8 x i64> poison, i64 %236, i64 0
  %.splat238 = shufflevector <8 x i64> %.splatinsert237, <8 x i64> poison, <8 x i32> zeroinitializer
  %239 = mul <8 x i64> %.splat238, splat (i64 32)
  %240 = add <8 x i64> %238, %239
  %241 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %237, 0
  %242 = insertvalue { <8 x ptr>, <8 x i64> } %241, <8 x i64> %240, 1
  %243 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %244 = extractvalue { <8 x ptr>, <8 x i64> } %242, 1
  %245 = extractelement <8 x ptr> %243, i32 0
  %246 = extractelement <8 x i64> %244, i32 0
  %247 = sub i64 %246, 0
  %248 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %249 = select i1 %248, i64 %247, i64 0
  %private.contiguous.address239 = getelementptr i8, ptr %245, i64 %249
  %private.contiguous.load240 = load <8 x float>, ptr %private.contiguous.address239, align 4
  %250 = select <8 x i1> %71, <8 x float> %private.contiguous.load240, <8 x float> zeroinitializer
  %251 = fmul <8 x float> %185, %250
  %.state241 = load <8 x float>, ptr %.slot45, align 32
  %252 = fadd <8 x float> %.state241, %251
  %.state242 = load i64, ptr %.slot41, align 4
  %253 = add i64 %.state242, 1
  store i64 %253, ptr %.slot41, align 4
  %254 = load <8 x float>, ptr %.slot42, align 32
  %255 = select <8 x i1> %71, <8 x float> %201, <8 x float> %254
  store <8 x float> %255, ptr %.slot42, align 32
  %256 = load <8 x float>, ptr %.slot43, align 32
  %257 = select <8 x i1> %71, <8 x float> %218, <8 x float> %256
  store <8 x float> %257, ptr %.slot43, align 32
  %258 = load <8 x float>, ptr %.slot44, align 32
  %259 = select <8 x i1> %71, <8 x float> %235, <8 x float> %258
  store <8 x float> %259, ptr %.slot44, align 32
  %260 = load <8 x float>, ptr %.slot45, align 32
  %261 = select <8 x i1> %71, <8 x float> %252, <8 x float> %260
  store <8 x float> %261, ptr %.slot45, align 32
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false209
  store i64 0, ptr %.slot46, align 4
  %262 = load <8 x float>, ptr %.slot47, align 32
  %263 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %262
  store <8 x float> %263, ptr %.slot47, align 32
  %264 = load <8 x float>, ptr %.slot48, align 32
  %265 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %264
  store <8 x float> %265, ptr %.slot48, align 32
  %266 = load <8 x float>, ptr %.slot49, align 32
  %267 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %266
  store <8 x float> %267, ptr %.slot49, align 32
  %268 = load <8 x float>, ptr %.slot50, align 32
  %269 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %268
  store <8 x float> %269, ptr %.slot50, align 32
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state243 = load i64, ptr %.slot46, align 4
  %270 = icmp slt i64 %.state243, 80
  br i1 %270, label %direct.true244, label %direct.false245

direct.schedule.14:                               ; preds = %direct.true244
  %.state246 = load i64, ptr %.slot46, align 4
  %271 = add i64 0, %.state246
  %tile_snapshot.spill.load247 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %272 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load247, 0
  %273 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load247, 1
  %.splatinsert248 = insertelement <8 x i64> poison, i64 %271, i64 0
  %.splat249 = shufflevector <8 x i64> %.splatinsert248, <8 x i64> poison, <8 x i32> zeroinitializer
  %274 = mul <8 x i64> %.splat249, splat (i64 32)
  %275 = add <8 x i64> %273, %274
  %276 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %272, 0
  %277 = insertvalue { <8 x ptr>, <8 x i64> } %276, <8 x i64> %275, 1
  %278 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %279 = extractvalue { <8 x ptr>, <8 x i64> } %277, 1
  %280 = extractelement <8 x ptr> %278, i32 0
  %281 = extractelement <8 x i64> %279, i32 0
  %282 = sub i64 %281, 0
  %283 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %284 = select i1 %283, i64 %282, i64 0
  %private.contiguous.address250 = getelementptr i8, ptr %280, i64 %284
  %private.contiguous.load251 = load <8 x float>, ptr %private.contiguous.address250, align 4
  %285 = select <8 x i1> %71, <8 x float> %private.contiguous.load251, <8 x float> zeroinitializer
  %.state252 = load i64, ptr %.slot46, align 4
  %286 = add i64 320, %.state252
  %tile_snapshot.spill.load253 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load253, 0
  %288 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load253, 1
  %.splatinsert254 = insertelement <8 x i64> poison, i64 %286, i64 0
  %.splat255 = shufflevector <8 x i64> %.splatinsert254, <8 x i64> poison, <8 x i32> zeroinitializer
  %289 = mul <8 x i64> %.splat255, splat (i64 32)
  %290 = add <8 x i64> %288, %289
  %291 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %287, 0
  %292 = insertvalue { <8 x ptr>, <8 x i64> } %291, <8 x i64> %290, 1
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %292, 1
  %295 = extractelement <8 x ptr> %293, i32 0
  %296 = extractelement <8 x i64> %294, i32 0
  %297 = sub i64 %296, 0
  %298 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %299 = select i1 %298, i64 %297, i64 0
  %private.contiguous.address256 = getelementptr i8, ptr %295, i64 %299
  %private.contiguous.load257 = load <8 x float>, ptr %private.contiguous.address256, align 4
  %300 = select <8 x i1> %71, <8 x float> %private.contiguous.load257, <8 x float> zeroinitializer
  %301 = fmul <8 x float> %285, %300
  %.state258 = load <8 x float>, ptr %.slot47, align 32
  %302 = fadd <8 x float> %.state258, %301
  %.state259 = load i64, ptr %.slot46, align 4
  %303 = add i64 400, %.state259
  %tile_snapshot.spill.load260 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load260, 0
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load260, 1
  %.splatinsert261 = insertelement <8 x i64> poison, i64 %303, i64 0
  %.splat262 = shufflevector <8 x i64> %.splatinsert261, <8 x i64> poison, <8 x i32> zeroinitializer
  %306 = mul <8 x i64> %.splat262, splat (i64 32)
  %307 = add <8 x i64> %305, %306
  %308 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %304, 0
  %309 = insertvalue { <8 x ptr>, <8 x i64> } %308, <8 x i64> %307, 1
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %311 = extractvalue { <8 x ptr>, <8 x i64> } %309, 1
  %312 = extractelement <8 x ptr> %310, i32 0
  %313 = extractelement <8 x i64> %311, i32 0
  %314 = sub i64 %313, 0
  %315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %316 = select i1 %315, i64 %314, i64 0
  %private.contiguous.address263 = getelementptr i8, ptr %312, i64 %316
  %private.contiguous.load264 = load <8 x float>, ptr %private.contiguous.address263, align 4
  %317 = select <8 x i1> %71, <8 x float> %private.contiguous.load264, <8 x float> zeroinitializer
  %318 = fmul <8 x float> %285, %317
  %.state265 = load <8 x float>, ptr %.slot48, align 32
  %319 = fadd <8 x float> %.state265, %318
  %.state266 = load i64, ptr %.slot46, align 4
  %320 = add i64 480, %.state266
  %tile_snapshot.spill.load267 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %321 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load267, 0
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load267, 1
  %.splatinsert268 = insertelement <8 x i64> poison, i64 %320, i64 0
  %.splat269 = shufflevector <8 x i64> %.splatinsert268, <8 x i64> poison, <8 x i32> zeroinitializer
  %323 = mul <8 x i64> %.splat269, splat (i64 32)
  %324 = add <8 x i64> %322, %323
  %325 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %321, 0
  %326 = insertvalue { <8 x ptr>, <8 x i64> } %325, <8 x i64> %324, 1
  %327 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %328 = extractvalue { <8 x ptr>, <8 x i64> } %326, 1
  %329 = extractelement <8 x ptr> %327, i32 0
  %330 = extractelement <8 x i64> %328, i32 0
  %331 = sub i64 %330, 0
  %332 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %333 = select i1 %332, i64 %331, i64 0
  %private.contiguous.address270 = getelementptr i8, ptr %329, i64 %333
  %private.contiguous.load271 = load <8 x float>, ptr %private.contiguous.address270, align 4
  %334 = select <8 x i1> %71, <8 x float> %private.contiguous.load271, <8 x float> zeroinitializer
  %335 = fmul <8 x float> %285, %334
  %.state272 = load <8 x float>, ptr %.slot49, align 32
  %336 = fadd <8 x float> %.state272, %335
  %.state273 = load i64, ptr %.slot46, align 4
  %337 = add i64 560, %.state273
  %tile_snapshot.spill.load274 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %338 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load274, 0
  %339 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load274, 1
  %.splatinsert275 = insertelement <8 x i64> poison, i64 %337, i64 0
  %.splat276 = shufflevector <8 x i64> %.splatinsert275, <8 x i64> poison, <8 x i32> zeroinitializer
  %340 = mul <8 x i64> %.splat276, splat (i64 32)
  %341 = add <8 x i64> %339, %340
  %342 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %338, 0
  %343 = insertvalue { <8 x ptr>, <8 x i64> } %342, <8 x i64> %341, 1
  %344 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %345 = extractvalue { <8 x ptr>, <8 x i64> } %343, 1
  %346 = extractelement <8 x ptr> %344, i32 0
  %347 = extractelement <8 x i64> %345, i32 0
  %348 = sub i64 %347, 0
  %349 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %350 = select i1 %349, i64 %348, i64 0
  %private.contiguous.address277 = getelementptr i8, ptr %346, i64 %350
  %private.contiguous.load278 = load <8 x float>, ptr %private.contiguous.address277, align 4
  %351 = select <8 x i1> %71, <8 x float> %private.contiguous.load278, <8 x float> zeroinitializer
  %352 = fmul <8 x float> %285, %351
  %.state279 = load <8 x float>, ptr %.slot50, align 32
  %353 = fadd <8 x float> %.state279, %352
  %.state280 = load i64, ptr %.slot46, align 4
  %354 = add i64 %.state280, 1
  store i64 %354, ptr %.slot46, align 4
  %355 = load <8 x float>, ptr %.slot47, align 32
  %356 = select <8 x i1> %71, <8 x float> %302, <8 x float> %355
  store <8 x float> %356, ptr %.slot47, align 32
  %357 = load <8 x float>, ptr %.slot48, align 32
  %358 = select <8 x i1> %71, <8 x float> %319, <8 x float> %357
  store <8 x float> %358, ptr %.slot48, align 32
  %359 = load <8 x float>, ptr %.slot49, align 32
  %360 = select <8 x i1> %71, <8 x float> %336, <8 x float> %359
  store <8 x float> %360, ptr %.slot49, align 32
  %361 = load <8 x float>, ptr %.slot50, align 32
  %362 = select <8 x i1> %71, <8 x float> %353, <8 x float> %361
  store <8 x float> %362, ptr %.slot50, align 32
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false245
  store i64 0, ptr %.slot51, align 4
  %363 = load <8 x float>, ptr %.slot52, align 32
  %364 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %363
  store <8 x float> %364, ptr %.slot52, align 32
  %365 = load <8 x float>, ptr %.slot53, align 32
  %366 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %365
  store <8 x float> %366, ptr %.slot53, align 32
  %367 = load <8 x float>, ptr %.slot54, align 32
  %368 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %367
  store <8 x float> %368, ptr %.slot54, align 32
  %369 = load <8 x float>, ptr %.slot55, align 32
  %370 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %369
  store <8 x float> %370, ptr %.slot55, align 32
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state281 = load i64, ptr %.slot51, align 4
  %371 = icmp slt i64 %.state281, 80
  br i1 %371, label %direct.true282, label %direct.false283

direct.schedule.17:                               ; preds = %direct.true282
  %.state284 = load i64, ptr %.slot51, align 4
  %372 = add i64 0, %.state284
  %tile_snapshot.spill.load285 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %373 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load285, 0
  %374 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load285, 1
  %.splatinsert286 = insertelement <8 x i64> poison, i64 %372, i64 0
  %.splat287 = shufflevector <8 x i64> %.splatinsert286, <8 x i64> poison, <8 x i32> zeroinitializer
  %375 = mul <8 x i64> %.splat287, splat (i64 32)
  %376 = add <8 x i64> %374, %375
  %377 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %373, 0
  %378 = insertvalue { <8 x ptr>, <8 x i64> } %377, <8 x i64> %376, 1
  %379 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %380 = extractvalue { <8 x ptr>, <8 x i64> } %378, 1
  %381 = extractelement <8 x ptr> %379, i32 0
  %382 = extractelement <8 x i64> %380, i32 0
  %383 = sub i64 %382, 0
  %384 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %385 = select i1 %384, i64 %383, i64 0
  %private.contiguous.address288 = getelementptr i8, ptr %381, i64 %385
  %private.contiguous.load289 = load <8 x float>, ptr %private.contiguous.address288, align 4
  %386 = select <8 x i1> %71, <8 x float> %private.contiguous.load289, <8 x float> zeroinitializer
  %.state290 = load i64, ptr %.slot51, align 4
  %387 = add i64 640, %.state290
  %tile_snapshot.spill.load291 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %388 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load291, 0
  %389 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load291, 1
  %.splatinsert292 = insertelement <8 x i64> poison, i64 %387, i64 0
  %.splat293 = shufflevector <8 x i64> %.splatinsert292, <8 x i64> poison, <8 x i32> zeroinitializer
  %390 = mul <8 x i64> %.splat293, splat (i64 32)
  %391 = add <8 x i64> %389, %390
  %392 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %388, 0
  %393 = insertvalue { <8 x ptr>, <8 x i64> } %392, <8 x i64> %391, 1
  %394 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %395 = extractvalue { <8 x ptr>, <8 x i64> } %393, 1
  %396 = extractelement <8 x ptr> %394, i32 0
  %397 = extractelement <8 x i64> %395, i32 0
  %398 = sub i64 %397, 0
  %399 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %400 = select i1 %399, i64 %398, i64 0
  %private.contiguous.address294 = getelementptr i8, ptr %396, i64 %400
  %private.contiguous.load295 = load <8 x float>, ptr %private.contiguous.address294, align 4
  %401 = select <8 x i1> %71, <8 x float> %private.contiguous.load295, <8 x float> zeroinitializer
  %402 = fmul <8 x float> %386, %401
  %.state296 = load <8 x float>, ptr %.slot52, align 32
  %403 = fadd <8 x float> %.state296, %402
  %.state297 = load i64, ptr %.slot51, align 4
  %404 = add i64 720, %.state297
  %tile_snapshot.spill.load298 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %405 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load298, 0
  %406 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load298, 1
  %.splatinsert299 = insertelement <8 x i64> poison, i64 %404, i64 0
  %.splat300 = shufflevector <8 x i64> %.splatinsert299, <8 x i64> poison, <8 x i32> zeroinitializer
  %407 = mul <8 x i64> %.splat300, splat (i64 32)
  %408 = add <8 x i64> %406, %407
  %409 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %405, 0
  %410 = insertvalue { <8 x ptr>, <8 x i64> } %409, <8 x i64> %408, 1
  %411 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %412 = extractvalue { <8 x ptr>, <8 x i64> } %410, 1
  %413 = extractelement <8 x ptr> %411, i32 0
  %414 = extractelement <8 x i64> %412, i32 0
  %415 = sub i64 %414, 0
  %416 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %417 = select i1 %416, i64 %415, i64 0
  %private.contiguous.address301 = getelementptr i8, ptr %413, i64 %417
  %private.contiguous.load302 = load <8 x float>, ptr %private.contiguous.address301, align 4
  %418 = select <8 x i1> %71, <8 x float> %private.contiguous.load302, <8 x float> zeroinitializer
  %419 = fmul <8 x float> %386, %418
  %.state303 = load <8 x float>, ptr %.slot53, align 32
  %420 = fadd <8 x float> %.state303, %419
  %.state304 = load i64, ptr %.slot51, align 4
  %421 = add i64 800, %.state304
  %tile_snapshot.spill.load305 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %422 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load305, 0
  %423 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load305, 1
  %.splatinsert306 = insertelement <8 x i64> poison, i64 %421, i64 0
  %.splat307 = shufflevector <8 x i64> %.splatinsert306, <8 x i64> poison, <8 x i32> zeroinitializer
  %424 = mul <8 x i64> %.splat307, splat (i64 32)
  %425 = add <8 x i64> %423, %424
  %426 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %422, 0
  %427 = insertvalue { <8 x ptr>, <8 x i64> } %426, <8 x i64> %425, 1
  %428 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %429 = extractvalue { <8 x ptr>, <8 x i64> } %427, 1
  %430 = extractelement <8 x ptr> %428, i32 0
  %431 = extractelement <8 x i64> %429, i32 0
  %432 = sub i64 %431, 0
  %433 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %434 = select i1 %433, i64 %432, i64 0
  %private.contiguous.address308 = getelementptr i8, ptr %430, i64 %434
  %private.contiguous.load309 = load <8 x float>, ptr %private.contiguous.address308, align 4
  %435 = select <8 x i1> %71, <8 x float> %private.contiguous.load309, <8 x float> zeroinitializer
  %436 = fmul <8 x float> %386, %435
  %.state310 = load <8 x float>, ptr %.slot54, align 32
  %437 = fadd <8 x float> %.state310, %436
  %.state311 = load i64, ptr %.slot51, align 4
  %438 = add i64 880, %.state311
  %tile_snapshot.spill.load312 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %439 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load312, 0
  %440 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load312, 1
  %.splatinsert313 = insertelement <8 x i64> poison, i64 %438, i64 0
  %.splat314 = shufflevector <8 x i64> %.splatinsert313, <8 x i64> poison, <8 x i32> zeroinitializer
  %441 = mul <8 x i64> %.splat314, splat (i64 32)
  %442 = add <8 x i64> %440, %441
  %443 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %439, 0
  %444 = insertvalue { <8 x ptr>, <8 x i64> } %443, <8 x i64> %442, 1
  %445 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %446 = extractvalue { <8 x ptr>, <8 x i64> } %444, 1
  %447 = extractelement <8 x ptr> %445, i32 0
  %448 = extractelement <8 x i64> %446, i32 0
  %449 = sub i64 %448, 0
  %450 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %451 = select i1 %450, i64 %449, i64 0
  %private.contiguous.address315 = getelementptr i8, ptr %447, i64 %451
  %private.contiguous.load316 = load <8 x float>, ptr %private.contiguous.address315, align 4
  %452 = select <8 x i1> %71, <8 x float> %private.contiguous.load316, <8 x float> zeroinitializer
  %453 = fmul <8 x float> %386, %452
  %.state317 = load <8 x float>, ptr %.slot55, align 32
  %454 = fadd <8 x float> %.state317, %453
  %.state318 = load i64, ptr %.slot51, align 4
  %455 = add i64 %.state318, 1
  store i64 %455, ptr %.slot51, align 4
  %456 = load <8 x float>, ptr %.slot52, align 32
  %457 = select <8 x i1> %71, <8 x float> %403, <8 x float> %456
  store <8 x float> %457, ptr %.slot52, align 32
  %458 = load <8 x float>, ptr %.slot53, align 32
  %459 = select <8 x i1> %71, <8 x float> %420, <8 x float> %458
  store <8 x float> %459, ptr %.slot53, align 32
  %460 = load <8 x float>, ptr %.slot54, align 32
  %461 = select <8 x i1> %71, <8 x float> %437, <8 x float> %460
  store <8 x float> %461, ptr %.slot54, align 32
  %462 = load <8 x float>, ptr %.slot55, align 32
  %463 = select <8 x i1> %71, <8 x float> %454, <8 x float> %462
  store <8 x float> %463, ptr %.slot55, align 32
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false283
  store i64 0, ptr %.slot56, align 4
  %464 = load <8 x float>, ptr %.slot57, align 32
  %465 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %464
  store <8 x float> %465, ptr %.slot57, align 32
  %466 = load <8 x float>, ptr %.slot58, align 32
  %467 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %466
  store <8 x float> %467, ptr %.slot58, align 32
  %468 = load <8 x float>, ptr %.slot59, align 32
  %469 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %468
  store <8 x float> %469, ptr %.slot59, align 32
  %470 = load <8 x float>, ptr %.slot60, align 32
  %471 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %470
  store <8 x float> %471, ptr %.slot60, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state319 = load i64, ptr %.slot56, align 4
  %472 = icmp slt i64 %.state319, 80
  br i1 %472, label %direct.true320, label %direct.false321

direct.schedule.20:                               ; preds = %direct.true320
  %.state322 = load i64, ptr %.slot56, align 4
  %473 = add i64 0, %.state322
  %tile_snapshot.spill.load323 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %474 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load323, 0
  %475 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load323, 1
  %.splatinsert324 = insertelement <8 x i64> poison, i64 %473, i64 0
  %.splat325 = shufflevector <8 x i64> %.splatinsert324, <8 x i64> poison, <8 x i32> zeroinitializer
  %476 = mul <8 x i64> %.splat325, splat (i64 32)
  %477 = add <8 x i64> %475, %476
  %478 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %474, 0
  %479 = insertvalue { <8 x ptr>, <8 x i64> } %478, <8 x i64> %477, 1
  %480 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %481 = extractvalue { <8 x ptr>, <8 x i64> } %479, 1
  %482 = extractelement <8 x ptr> %480, i32 0
  %483 = extractelement <8 x i64> %481, i32 0
  %484 = sub i64 %483, 0
  %485 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %486 = select i1 %485, i64 %484, i64 0
  %private.contiguous.address326 = getelementptr i8, ptr %482, i64 %486
  %private.contiguous.load327 = load <8 x float>, ptr %private.contiguous.address326, align 4
  %487 = select <8 x i1> %71, <8 x float> %private.contiguous.load327, <8 x float> zeroinitializer
  %.state328 = load i64, ptr %.slot56, align 4
  %488 = add i64 960, %.state328
  %tile_snapshot.spill.load329 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %489 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load329, 0
  %490 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load329, 1
  %.splatinsert330 = insertelement <8 x i64> poison, i64 %488, i64 0
  %.splat331 = shufflevector <8 x i64> %.splatinsert330, <8 x i64> poison, <8 x i32> zeroinitializer
  %491 = mul <8 x i64> %.splat331, splat (i64 32)
  %492 = add <8 x i64> %490, %491
  %493 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %489, 0
  %494 = insertvalue { <8 x ptr>, <8 x i64> } %493, <8 x i64> %492, 1
  %495 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %496 = extractvalue { <8 x ptr>, <8 x i64> } %494, 1
  %497 = extractelement <8 x ptr> %495, i32 0
  %498 = extractelement <8 x i64> %496, i32 0
  %499 = sub i64 %498, 0
  %500 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %501 = select i1 %500, i64 %499, i64 0
  %private.contiguous.address332 = getelementptr i8, ptr %497, i64 %501
  %private.contiguous.load333 = load <8 x float>, ptr %private.contiguous.address332, align 4
  %502 = select <8 x i1> %71, <8 x float> %private.contiguous.load333, <8 x float> zeroinitializer
  %503 = fmul <8 x float> %487, %502
  %.state334 = load <8 x float>, ptr %.slot57, align 32
  %504 = fadd <8 x float> %.state334, %503
  %.state335 = load i64, ptr %.slot56, align 4
  %505 = add i64 1040, %.state335
  %tile_snapshot.spill.load336 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %506 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load336, 0
  %507 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load336, 1
  %.splatinsert337 = insertelement <8 x i64> poison, i64 %505, i64 0
  %.splat338 = shufflevector <8 x i64> %.splatinsert337, <8 x i64> poison, <8 x i32> zeroinitializer
  %508 = mul <8 x i64> %.splat338, splat (i64 32)
  %509 = add <8 x i64> %507, %508
  %510 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %506, 0
  %511 = insertvalue { <8 x ptr>, <8 x i64> } %510, <8 x i64> %509, 1
  %512 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %513 = extractvalue { <8 x ptr>, <8 x i64> } %511, 1
  %514 = extractelement <8 x ptr> %512, i32 0
  %515 = extractelement <8 x i64> %513, i32 0
  %516 = sub i64 %515, 0
  %517 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %518 = select i1 %517, i64 %516, i64 0
  %private.contiguous.address339 = getelementptr i8, ptr %514, i64 %518
  %private.contiguous.load340 = load <8 x float>, ptr %private.contiguous.address339, align 4
  %519 = select <8 x i1> %71, <8 x float> %private.contiguous.load340, <8 x float> zeroinitializer
  %520 = fmul <8 x float> %487, %519
  %.state341 = load <8 x float>, ptr %.slot58, align 32
  %521 = fadd <8 x float> %.state341, %520
  %.state342 = load i64, ptr %.slot56, align 4
  %522 = add i64 1120, %.state342
  %tile_snapshot.spill.load343 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %523 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load343, 0
  %524 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load343, 1
  %.splatinsert344 = insertelement <8 x i64> poison, i64 %522, i64 0
  %.splat345 = shufflevector <8 x i64> %.splatinsert344, <8 x i64> poison, <8 x i32> zeroinitializer
  %525 = mul <8 x i64> %.splat345, splat (i64 32)
  %526 = add <8 x i64> %524, %525
  %527 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %523, 0
  %528 = insertvalue { <8 x ptr>, <8 x i64> } %527, <8 x i64> %526, 1
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %530 = extractvalue { <8 x ptr>, <8 x i64> } %528, 1
  %531 = extractelement <8 x ptr> %529, i32 0
  %532 = extractelement <8 x i64> %530, i32 0
  %533 = sub i64 %532, 0
  %534 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %535 = select i1 %534, i64 %533, i64 0
  %private.contiguous.address346 = getelementptr i8, ptr %531, i64 %535
  %private.contiguous.load347 = load <8 x float>, ptr %private.contiguous.address346, align 4
  %536 = select <8 x i1> %71, <8 x float> %private.contiguous.load347, <8 x float> zeroinitializer
  %537 = fmul <8 x float> %487, %536
  %.state348 = load <8 x float>, ptr %.slot59, align 32
  %538 = fadd <8 x float> %.state348, %537
  %.state349 = load i64, ptr %.slot56, align 4
  %539 = add i64 1200, %.state349
  %tile_snapshot.spill.load350 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %540 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load350, 0
  %541 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load350, 1
  %.splatinsert351 = insertelement <8 x i64> poison, i64 %539, i64 0
  %.splat352 = shufflevector <8 x i64> %.splatinsert351, <8 x i64> poison, <8 x i32> zeroinitializer
  %542 = mul <8 x i64> %.splat352, splat (i64 32)
  %543 = add <8 x i64> %541, %542
  %544 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %540, 0
  %545 = insertvalue { <8 x ptr>, <8 x i64> } %544, <8 x i64> %543, 1
  %546 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %547 = extractvalue { <8 x ptr>, <8 x i64> } %545, 1
  %548 = extractelement <8 x ptr> %546, i32 0
  %549 = extractelement <8 x i64> %547, i32 0
  %550 = sub i64 %549, 0
  %551 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %552 = select i1 %551, i64 %550, i64 0
  %private.contiguous.address353 = getelementptr i8, ptr %548, i64 %552
  %private.contiguous.load354 = load <8 x float>, ptr %private.contiguous.address353, align 4
  %553 = select <8 x i1> %71, <8 x float> %private.contiguous.load354, <8 x float> zeroinitializer
  %554 = fmul <8 x float> %487, %553
  %.state355 = load <8 x float>, ptr %.slot60, align 32
  %555 = fadd <8 x float> %.state355, %554
  %.state356 = load i64, ptr %.slot56, align 4
  %556 = add i64 %.state356, 1
  store i64 %556, ptr %.slot56, align 4
  %557 = load <8 x float>, ptr %.slot57, align 32
  %558 = select <8 x i1> %71, <8 x float> %504, <8 x float> %557
  store <8 x float> %558, ptr %.slot57, align 32
  %559 = load <8 x float>, ptr %.slot58, align 32
  %560 = select <8 x i1> %71, <8 x float> %521, <8 x float> %559
  store <8 x float> %560, ptr %.slot58, align 32
  %561 = load <8 x float>, ptr %.slot59, align 32
  %562 = select <8 x i1> %71, <8 x float> %538, <8 x float> %561
  store <8 x float> %562, ptr %.slot59, align 32
  %563 = load <8 x float>, ptr %.slot60, align 32
  %564 = select <8 x i1> %71, <8 x float> %555, <8 x float> %563
  store <8 x float> %564, ptr %.slot60, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false321
  %.state357 = load <8 x float>, ptr %.slot42, align 32
  %565 = fmul <8 x float> %.state357, splat (float 0x3FBC9F25C0000000)
  %.state358 = load <8 x float>, ptr %.slot43, align 32
  %566 = fmul <8 x float> %.state358, splat (float 0x3FBC9F25C0000000)
  %.state359 = load <8 x float>, ptr %.slot44, align 32
  %567 = fmul <8 x float> %.state359, splat (float 0x3FBC9F25C0000000)
  %.state360 = load <8 x float>, ptr %.slot45, align 32
  %568 = fmul <8 x float> %.state360, splat (float 0x3FBC9F25C0000000)
  %.state361 = load <8 x float>, ptr %.slot47, align 32
  %569 = fmul <8 x float> %.state361, splat (float 0x3FBC9F25C0000000)
  %.state362 = load <8 x float>, ptr %.slot48, align 32
  %570 = fmul <8 x float> %.state362, splat (float 0x3FBC9F25C0000000)
  %.state363 = load <8 x float>, ptr %.slot49, align 32
  %571 = fmul <8 x float> %.state363, splat (float 0x3FBC9F25C0000000)
  %.state364 = load <8 x float>, ptr %.slot50, align 32
  %572 = fmul <8 x float> %.state364, splat (float 0x3FBC9F25C0000000)
  %.state365 = load <8 x float>, ptr %.slot52, align 32
  %573 = fmul <8 x float> %.state365, splat (float 0x3FBC9F25C0000000)
  %.state366 = load <8 x float>, ptr %.slot53, align 32
  %574 = fmul <8 x float> %.state366, splat (float 0x3FBC9F25C0000000)
  %.state367 = load <8 x float>, ptr %.slot54, align 32
  %575 = fmul <8 x float> %.state367, splat (float 0x3FBC9F25C0000000)
  %.state368 = load <8 x float>, ptr %.slot55, align 32
  %576 = fmul <8 x float> %.state368, splat (float 0x3FBC9F25C0000000)
  %.state369 = load <8 x float>, ptr %.slot57, align 32
  %577 = fmul <8 x float> %.state369, splat (float 0x3FBC9F25C0000000)
  %.state370 = load <8 x float>, ptr %.slot58, align 32
  %578 = fmul <8 x float> %.state370, splat (float 0x3FBC9F25C0000000)
  %.state371 = load <8 x float>, ptr %.slot59, align 32
  %579 = fmul <8 x float> %.state371, splat (float 0x3FBC9F25C0000000)
  %.state372 = load <8 x float>, ptr %.slot60, align 32
  %580 = fmul <8 x float> %.state372, splat (float 0x3FBC9F25C0000000)
  %.spill.load373 = load i64, ptr %.spill37, align 4
  %581 = add i64 0, %.spill.load373
  %.spill.load374 = load i64, ptr %.spill37, align 4
  %582 = add i64 1, %.spill.load374
  %.spill.load375 = load i64, ptr %.spill37, align 4
  %583 = add i64 2, %.spill.load375
  %.spill.load376 = load i64, ptr %.spill37, align 4
  %584 = add i64 3, %.spill.load376
  %.spill.load377 = load i64, ptr %.spill37, align 4
  %585 = add i64 4, %.spill.load377
  %.spill.load378 = load i64, ptr %.spill37, align 4
  %586 = add i64 5, %.spill.load378
  %.spill.load379 = load i64, ptr %.spill37, align 4
  %587 = add i64 6, %.spill.load379
  %.spill.load380 = load i64, ptr %.spill37, align 4
  %588 = add i64 7, %.spill.load380
  %.spill.load381 = load i64, ptr %.spill37, align 4
  %589 = add i64 8, %.spill.load381
  %.spill.load382 = load i64, ptr %.spill37, align 4
  %590 = add i64 9, %.spill.load382
  %.spill.load383 = load i64, ptr %.spill37, align 4
  %591 = add i64 10, %.spill.load383
  %.spill.load384 = load i64, ptr %.spill37, align 4
  %592 = add i64 11, %.spill.load384
  %.spill.load385 = load i64, ptr %.spill37, align 4
  %593 = add i64 12, %.spill.load385
  %.spill.load386 = load i64, ptr %.spill37, align 4
  %594 = add i64 13, %.spill.load386
  %.spill.load387 = load i64, ptr %.spill37, align 4
  %595 = add i64 14, %.spill.load387
  %.spill.load388 = load i64, ptr %.spill37, align 4
  %596 = add i64 15, %.spill.load388
  %597 = icmp slt i64 %581, 2053
  %598 = icmp slt i64 %582, 2053
  %599 = icmp slt i64 %583, 2053
  %600 = icmp slt i64 %584, 2053
  %601 = icmp slt i64 %585, 2053
  %602 = icmp slt i64 %586, 2053
  %603 = icmp slt i64 %587, 2053
  %604 = icmp slt i64 %588, 2053
  %605 = icmp slt i64 %589, 2053
  %606 = icmp slt i64 %590, 2053
  %607 = icmp slt i64 %591, 2053
  %608 = icmp slt i64 %592, 2053
  %609 = icmp slt i64 %593, 2053
  %610 = icmp slt i64 %594, 2053
  %611 = icmp slt i64 %595, 2053
  %612 = icmp slt i64 %596, 2053
  %.spill.load389 = load i64, ptr %.spill31, align 4
  %613 = add i64 %.spill.load389, 2053
  %614 = sub i64 %613, 1
  %615 = icmp sle i64 %581, %614
  %616 = icmp sle i64 %582, %614
  %617 = icmp sle i64 %583, %614
  %618 = icmp sle i64 %584, %614
  %619 = icmp sle i64 %585, %614
  %620 = icmp sle i64 %586, %614
  %621 = icmp sle i64 %587, %614
  %622 = icmp sle i64 %588, %614
  %623 = icmp sle i64 %589, %614
  %624 = icmp sle i64 %590, %614
  %625 = icmp sle i64 %591, %614
  %626 = icmp sle i64 %592, %614
  %627 = icmp sle i64 %593, %614
  %628 = icmp sle i64 %594, %614
  %629 = icmp sle i64 %595, %614
  %630 = icmp sle i64 %596, %614
  %631 = and i1 %597, %615
  store i1 %631, ptr %.spill61, align 1
  %632 = and i1 %598, %616
  store i1 %632, ptr %.spill62, align 1
  %633 = and i1 %599, %617
  store i1 %633, ptr %.spill63, align 1
  %634 = and i1 %600, %618
  store i1 %634, ptr %.spill64, align 1
  %635 = and i1 %601, %619
  store i1 %635, ptr %.spill65, align 1
  %636 = and i1 %602, %620
  store i1 %636, ptr %.spill66, align 1
  %637 = and i1 %603, %621
  store i1 %637, ptr %.spill67, align 1
  %638 = and i1 %604, %622
  store i1 %638, ptr %.spill68, align 1
  %639 = and i1 %605, %623
  store i1 %639, ptr %.spill69, align 1
  %640 = and i1 %606, %624
  store i1 %640, ptr %.spill70, align 1
  %641 = and i1 %607, %625
  store i1 %641, ptr %.spill71, align 1
  %642 = and i1 %608, %626
  store i1 %642, ptr %.spill72, align 1
  %643 = and i1 %609, %627
  store i1 %643, ptr %.spill73, align 1
  %644 = and i1 %610, %628
  store i1 %644, ptr %.spill74, align 1
  %645 = and i1 %611, %629
  store i1 %645, ptr %.spill75, align 1
  %646 = and i1 %612, %630
  store i1 %646, ptr %.spill76, align 1
  %.splatinsert390 = insertelement <8 x i1> poison, i1 %631, i64 0
  %.splat391 = shufflevector <8 x i1> %.splatinsert390, <8 x i1> poison, <8 x i32> zeroinitializer
  %647 = select <8 x i1> %.splat391, <8 x float> %565, <8 x float> splat (float 0xC6293E5940000000)
  %648 = load <8 x float>, ptr %.spill77, align 32
  %649 = select <8 x i1> %71, <8 x float> %647, <8 x float> %648
  store <8 x float> %649, ptr %.spill77, align 32
  %.splatinsert392 = insertelement <8 x i1> poison, i1 %632, i64 0
  %.splat393 = shufflevector <8 x i1> %.splatinsert392, <8 x i1> poison, <8 x i32> zeroinitializer
  %650 = select <8 x i1> %.splat393, <8 x float> %566, <8 x float> splat (float 0xC6293E5940000000)
  %651 = load <8 x float>, ptr %.spill78, align 32
  %652 = select <8 x i1> %71, <8 x float> %650, <8 x float> %651
  store <8 x float> %652, ptr %.spill78, align 32
  %.splatinsert394 = insertelement <8 x i1> poison, i1 %633, i64 0
  %.splat395 = shufflevector <8 x i1> %.splatinsert394, <8 x i1> poison, <8 x i32> zeroinitializer
  %653 = select <8 x i1> %.splat395, <8 x float> %567, <8 x float> splat (float 0xC6293E5940000000)
  %654 = load <8 x float>, ptr %.spill79, align 32
  %655 = select <8 x i1> %71, <8 x float> %653, <8 x float> %654
  store <8 x float> %655, ptr %.spill79, align 32
  %.splatinsert396 = insertelement <8 x i1> poison, i1 %634, i64 0
  %.splat397 = shufflevector <8 x i1> %.splatinsert396, <8 x i1> poison, <8 x i32> zeroinitializer
  %656 = select <8 x i1> %.splat397, <8 x float> %568, <8 x float> splat (float 0xC6293E5940000000)
  %657 = load <8 x float>, ptr %.spill80, align 32
  %658 = select <8 x i1> %71, <8 x float> %656, <8 x float> %657
  store <8 x float> %658, ptr %.spill80, align 32
  %.splatinsert398 = insertelement <8 x i1> poison, i1 %635, i64 0
  %.splat399 = shufflevector <8 x i1> %.splatinsert398, <8 x i1> poison, <8 x i32> zeroinitializer
  %659 = select <8 x i1> %.splat399, <8 x float> %569, <8 x float> splat (float 0xC6293E5940000000)
  %660 = load <8 x float>, ptr %.spill81, align 32
  %661 = select <8 x i1> %71, <8 x float> %659, <8 x float> %660
  store <8 x float> %661, ptr %.spill81, align 32
  %.splatinsert400 = insertelement <8 x i1> poison, i1 %636, i64 0
  %.splat401 = shufflevector <8 x i1> %.splatinsert400, <8 x i1> poison, <8 x i32> zeroinitializer
  %662 = select <8 x i1> %.splat401, <8 x float> %570, <8 x float> splat (float 0xC6293E5940000000)
  %663 = load <8 x float>, ptr %.spill82, align 32
  %664 = select <8 x i1> %71, <8 x float> %662, <8 x float> %663
  store <8 x float> %664, ptr %.spill82, align 32
  %.splatinsert402 = insertelement <8 x i1> poison, i1 %637, i64 0
  %.splat403 = shufflevector <8 x i1> %.splatinsert402, <8 x i1> poison, <8 x i32> zeroinitializer
  %665 = select <8 x i1> %.splat403, <8 x float> %571, <8 x float> splat (float 0xC6293E5940000000)
  %666 = load <8 x float>, ptr %.spill83, align 32
  %667 = select <8 x i1> %71, <8 x float> %665, <8 x float> %666
  store <8 x float> %667, ptr %.spill83, align 32
  %.splatinsert404 = insertelement <8 x i1> poison, i1 %638, i64 0
  %.splat405 = shufflevector <8 x i1> %.splatinsert404, <8 x i1> poison, <8 x i32> zeroinitializer
  %668 = select <8 x i1> %.splat405, <8 x float> %572, <8 x float> splat (float 0xC6293E5940000000)
  %669 = load <8 x float>, ptr %.spill84, align 32
  %670 = select <8 x i1> %71, <8 x float> %668, <8 x float> %669
  store <8 x float> %670, ptr %.spill84, align 32
  %.splatinsert406 = insertelement <8 x i1> poison, i1 %639, i64 0
  %.splat407 = shufflevector <8 x i1> %.splatinsert406, <8 x i1> poison, <8 x i32> zeroinitializer
  %671 = select <8 x i1> %.splat407, <8 x float> %573, <8 x float> splat (float 0xC6293E5940000000)
  %672 = load <8 x float>, ptr %.spill85, align 32
  %673 = select <8 x i1> %71, <8 x float> %671, <8 x float> %672
  store <8 x float> %673, ptr %.spill85, align 32
  %.splatinsert408 = insertelement <8 x i1> poison, i1 %640, i64 0
  %.splat409 = shufflevector <8 x i1> %.splatinsert408, <8 x i1> poison, <8 x i32> zeroinitializer
  %674 = select <8 x i1> %.splat409, <8 x float> %574, <8 x float> splat (float 0xC6293E5940000000)
  %675 = load <8 x float>, ptr %.spill86, align 32
  %676 = select <8 x i1> %71, <8 x float> %674, <8 x float> %675
  store <8 x float> %676, ptr %.spill86, align 32
  %.splatinsert410 = insertelement <8 x i1> poison, i1 %641, i64 0
  %.splat411 = shufflevector <8 x i1> %.splatinsert410, <8 x i1> poison, <8 x i32> zeroinitializer
  %677 = select <8 x i1> %.splat411, <8 x float> %575, <8 x float> splat (float 0xC6293E5940000000)
  %678 = load <8 x float>, ptr %.spill87, align 32
  %679 = select <8 x i1> %71, <8 x float> %677, <8 x float> %678
  store <8 x float> %679, ptr %.spill87, align 32
  %.splatinsert412 = insertelement <8 x i1> poison, i1 %642, i64 0
  %.splat413 = shufflevector <8 x i1> %.splatinsert412, <8 x i1> poison, <8 x i32> zeroinitializer
  %680 = select <8 x i1> %.splat413, <8 x float> %576, <8 x float> splat (float 0xC6293E5940000000)
  %681 = load <8 x float>, ptr %.spill88, align 32
  %682 = select <8 x i1> %71, <8 x float> %680, <8 x float> %681
  store <8 x float> %682, ptr %.spill88, align 32
  %.splatinsert414 = insertelement <8 x i1> poison, i1 %643, i64 0
  %.splat415 = shufflevector <8 x i1> %.splatinsert414, <8 x i1> poison, <8 x i32> zeroinitializer
  %683 = select <8 x i1> %.splat415, <8 x float> %577, <8 x float> splat (float 0xC6293E5940000000)
  %684 = load <8 x float>, ptr %.spill89, align 32
  %685 = select <8 x i1> %71, <8 x float> %683, <8 x float> %684
  store <8 x float> %685, ptr %.spill89, align 32
  %.splatinsert416 = insertelement <8 x i1> poison, i1 %644, i64 0
  %.splat417 = shufflevector <8 x i1> %.splatinsert416, <8 x i1> poison, <8 x i32> zeroinitializer
  %686 = select <8 x i1> %.splat417, <8 x float> %578, <8 x float> splat (float 0xC6293E5940000000)
  %687 = load <8 x float>, ptr %.spill90, align 32
  %688 = select <8 x i1> %71, <8 x float> %686, <8 x float> %687
  store <8 x float> %688, ptr %.spill90, align 32
  %.splatinsert418 = insertelement <8 x i1> poison, i1 %645, i64 0
  %.splat419 = shufflevector <8 x i1> %.splatinsert418, <8 x i1> poison, <8 x i32> zeroinitializer
  %689 = select <8 x i1> %.splat419, <8 x float> %579, <8 x float> splat (float 0xC6293E5940000000)
  %690 = load <8 x float>, ptr %.spill91, align 32
  %691 = select <8 x i1> %71, <8 x float> %689, <8 x float> %690
  store <8 x float> %691, ptr %.spill91, align 32
  %.splatinsert420 = insertelement <8 x i1> poison, i1 %646, i64 0
  %.splat421 = shufflevector <8 x i1> %.splatinsert420, <8 x i1> poison, <8 x i32> zeroinitializer
  %692 = select <8 x i1> %.splat421, <8 x float> %580, <8 x float> splat (float 0xC6293E5940000000)
  %693 = load <8 x float>, ptr %.spill92, align 32
  %694 = select <8 x i1> %71, <8 x float> %692, <8 x float> %693
  store <8 x float> %694, ptr %.spill92, align 32
  %695 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill93, align 64
  %696 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %697 = extractvalue { <8 x ptr>, <8 x i64> } %695, 0
  %698 = select <8 x i1> %71, <8 x ptr> %696, <8 x ptr> %697
  %699 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %700 = extractvalue { <8 x ptr>, <8 x i64> } %695, 1
  %701 = select <8 x i1> %71, <8 x i64> %699, <8 x i64> %700
  %702 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %698, 0
  %703 = insertvalue { <8 x ptr>, <8 x i64> } %702, <8 x i64> %701, 1
  store { <8 x ptr>, <8 x i64> } %703, ptr %tile_snapshot.spill93, align 64
  %704 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %705 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %706 = add <8 x i64> %705, zeroinitializer
  %707 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %704, 0
  %708 = insertvalue { <8 x ptr>, <8 x i64> } %707, <8 x i64> %706, 1
  %709 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %710 = extractvalue { <8 x ptr>, <8 x i64> } %708, 1
  %711 = extractelement <8 x ptr> %709, i32 0
  %712 = extractelement <8 x i64> %710, i32 0
  %713 = sub i64 %712, 0
  %714 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %715 = select i1 %714, i64 %713, i64 0
  %private.contiguous.address422 = getelementptr i8, ptr %711, i64 %715
  %private.contiguous.preserve423 = load <8 x float>, ptr %private.contiguous.address422, align 4
  %716 = select <8 x i1> %71, <8 x float> %647, <8 x float> %private.contiguous.preserve423
  store <8 x float> %716, ptr %private.contiguous.address422, align 4
  %717 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %718 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %719 = add <8 x i64> %718, splat (i64 32)
  %720 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %717, 0
  %721 = insertvalue { <8 x ptr>, <8 x i64> } %720, <8 x i64> %719, 1
  %722 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %723 = extractvalue { <8 x ptr>, <8 x i64> } %721, 1
  %724 = extractelement <8 x ptr> %722, i32 0
  %725 = extractelement <8 x i64> %723, i32 0
  %726 = sub i64 %725, 0
  %727 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %728 = select i1 %727, i64 %726, i64 0
  %private.contiguous.address424 = getelementptr i8, ptr %724, i64 %728
  %private.contiguous.preserve425 = load <8 x float>, ptr %private.contiguous.address424, align 4
  %729 = select <8 x i1> %71, <8 x float> %650, <8 x float> %private.contiguous.preserve425
  store <8 x float> %729, ptr %private.contiguous.address424, align 4
  %730 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %731 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %732 = add <8 x i64> %731, splat (i64 64)
  %733 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %730, 0
  %734 = insertvalue { <8 x ptr>, <8 x i64> } %733, <8 x i64> %732, 1
  %735 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %736 = extractvalue { <8 x ptr>, <8 x i64> } %734, 1
  %737 = extractelement <8 x ptr> %735, i32 0
  %738 = extractelement <8 x i64> %736, i32 0
  %739 = sub i64 %738, 0
  %740 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %741 = select i1 %740, i64 %739, i64 0
  %private.contiguous.address426 = getelementptr i8, ptr %737, i64 %741
  %private.contiguous.preserve427 = load <8 x float>, ptr %private.contiguous.address426, align 4
  %742 = select <8 x i1> %71, <8 x float> %653, <8 x float> %private.contiguous.preserve427
  store <8 x float> %742, ptr %private.contiguous.address426, align 4
  %743 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %744 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %745 = add <8 x i64> %744, splat (i64 96)
  %746 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %743, 0
  %747 = insertvalue { <8 x ptr>, <8 x i64> } %746, <8 x i64> %745, 1
  %748 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %749 = extractvalue { <8 x ptr>, <8 x i64> } %747, 1
  %750 = extractelement <8 x ptr> %748, i32 0
  %751 = extractelement <8 x i64> %749, i32 0
  %752 = sub i64 %751, 0
  %753 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %754 = select i1 %753, i64 %752, i64 0
  %private.contiguous.address428 = getelementptr i8, ptr %750, i64 %754
  %private.contiguous.preserve429 = load <8 x float>, ptr %private.contiguous.address428, align 4
  %755 = select <8 x i1> %71, <8 x float> %656, <8 x float> %private.contiguous.preserve429
  store <8 x float> %755, ptr %private.contiguous.address428, align 4
  %756 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %757 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %758 = add <8 x i64> %757, splat (i64 128)
  %759 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %756, 0
  %760 = insertvalue { <8 x ptr>, <8 x i64> } %759, <8 x i64> %758, 1
  %761 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %762 = extractvalue { <8 x ptr>, <8 x i64> } %760, 1
  %763 = extractelement <8 x ptr> %761, i32 0
  %764 = extractelement <8 x i64> %762, i32 0
  %765 = sub i64 %764, 0
  %766 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %767 = select i1 %766, i64 %765, i64 0
  %private.contiguous.address430 = getelementptr i8, ptr %763, i64 %767
  %private.contiguous.preserve431 = load <8 x float>, ptr %private.contiguous.address430, align 4
  %768 = select <8 x i1> %71, <8 x float> %659, <8 x float> %private.contiguous.preserve431
  store <8 x float> %768, ptr %private.contiguous.address430, align 4
  %769 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %770 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %771 = add <8 x i64> %770, splat (i64 160)
  %772 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %769, 0
  %773 = insertvalue { <8 x ptr>, <8 x i64> } %772, <8 x i64> %771, 1
  %774 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %775 = extractvalue { <8 x ptr>, <8 x i64> } %773, 1
  %776 = extractelement <8 x ptr> %774, i32 0
  %777 = extractelement <8 x i64> %775, i32 0
  %778 = sub i64 %777, 0
  %779 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %780 = select i1 %779, i64 %778, i64 0
  %private.contiguous.address432 = getelementptr i8, ptr %776, i64 %780
  %private.contiguous.preserve433 = load <8 x float>, ptr %private.contiguous.address432, align 4
  %781 = select <8 x i1> %71, <8 x float> %662, <8 x float> %private.contiguous.preserve433
  store <8 x float> %781, ptr %private.contiguous.address432, align 4
  %782 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %783 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %784 = add <8 x i64> %783, splat (i64 192)
  %785 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %782, 0
  %786 = insertvalue { <8 x ptr>, <8 x i64> } %785, <8 x i64> %784, 1
  %787 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %788 = extractvalue { <8 x ptr>, <8 x i64> } %786, 1
  %789 = extractelement <8 x ptr> %787, i32 0
  %790 = extractelement <8 x i64> %788, i32 0
  %791 = sub i64 %790, 0
  %792 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %793 = select i1 %792, i64 %791, i64 0
  %private.contiguous.address434 = getelementptr i8, ptr %789, i64 %793
  %private.contiguous.preserve435 = load <8 x float>, ptr %private.contiguous.address434, align 4
  %794 = select <8 x i1> %71, <8 x float> %665, <8 x float> %private.contiguous.preserve435
  store <8 x float> %794, ptr %private.contiguous.address434, align 4
  %795 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %796 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %797 = add <8 x i64> %796, splat (i64 224)
  %798 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %795, 0
  %799 = insertvalue { <8 x ptr>, <8 x i64> } %798, <8 x i64> %797, 1
  %800 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %801 = extractvalue { <8 x ptr>, <8 x i64> } %799, 1
  %802 = extractelement <8 x ptr> %800, i32 0
  %803 = extractelement <8 x i64> %801, i32 0
  %804 = sub i64 %803, 0
  %805 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %806 = select i1 %805, i64 %804, i64 0
  %private.contiguous.address436 = getelementptr i8, ptr %802, i64 %806
  %private.contiguous.preserve437 = load <8 x float>, ptr %private.contiguous.address436, align 4
  %807 = select <8 x i1> %71, <8 x float> %668, <8 x float> %private.contiguous.preserve437
  store <8 x float> %807, ptr %private.contiguous.address436, align 4
  %808 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %809 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %810 = add <8 x i64> %809, splat (i64 256)
  %811 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %808, 0
  %812 = insertvalue { <8 x ptr>, <8 x i64> } %811, <8 x i64> %810, 1
  %813 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %814 = extractvalue { <8 x ptr>, <8 x i64> } %812, 1
  %815 = extractelement <8 x ptr> %813, i32 0
  %816 = extractelement <8 x i64> %814, i32 0
  %817 = sub i64 %816, 0
  %818 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %819 = select i1 %818, i64 %817, i64 0
  %private.contiguous.address438 = getelementptr i8, ptr %815, i64 %819
  %private.contiguous.preserve439 = load <8 x float>, ptr %private.contiguous.address438, align 4
  %820 = select <8 x i1> %71, <8 x float> %671, <8 x float> %private.contiguous.preserve439
  store <8 x float> %820, ptr %private.contiguous.address438, align 4
  %821 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %822 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %823 = add <8 x i64> %822, splat (i64 288)
  %824 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %821, 0
  %825 = insertvalue { <8 x ptr>, <8 x i64> } %824, <8 x i64> %823, 1
  %826 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %827 = extractvalue { <8 x ptr>, <8 x i64> } %825, 1
  %828 = extractelement <8 x ptr> %826, i32 0
  %829 = extractelement <8 x i64> %827, i32 0
  %830 = sub i64 %829, 0
  %831 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %832 = select i1 %831, i64 %830, i64 0
  %private.contiguous.address440 = getelementptr i8, ptr %828, i64 %832
  %private.contiguous.preserve441 = load <8 x float>, ptr %private.contiguous.address440, align 4
  %833 = select <8 x i1> %71, <8 x float> %674, <8 x float> %private.contiguous.preserve441
  store <8 x float> %833, ptr %private.contiguous.address440, align 4
  %834 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %835 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %836 = add <8 x i64> %835, splat (i64 320)
  %837 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %834, 0
  %838 = insertvalue { <8 x ptr>, <8 x i64> } %837, <8 x i64> %836, 1
  %839 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %840 = extractvalue { <8 x ptr>, <8 x i64> } %838, 1
  %841 = extractelement <8 x ptr> %839, i32 0
  %842 = extractelement <8 x i64> %840, i32 0
  %843 = sub i64 %842, 0
  %844 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %845 = select i1 %844, i64 %843, i64 0
  %private.contiguous.address442 = getelementptr i8, ptr %841, i64 %845
  %private.contiguous.preserve443 = load <8 x float>, ptr %private.contiguous.address442, align 4
  %846 = select <8 x i1> %71, <8 x float> %677, <8 x float> %private.contiguous.preserve443
  store <8 x float> %846, ptr %private.contiguous.address442, align 4
  %847 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %848 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %849 = add <8 x i64> %848, splat (i64 352)
  %850 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %847, 0
  %851 = insertvalue { <8 x ptr>, <8 x i64> } %850, <8 x i64> %849, 1
  %852 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %853 = extractvalue { <8 x ptr>, <8 x i64> } %851, 1
  %854 = extractelement <8 x ptr> %852, i32 0
  %855 = extractelement <8 x i64> %853, i32 0
  %856 = sub i64 %855, 0
  %857 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %858 = select i1 %857, i64 %856, i64 0
  %private.contiguous.address444 = getelementptr i8, ptr %854, i64 %858
  %private.contiguous.preserve445 = load <8 x float>, ptr %private.contiguous.address444, align 4
  %859 = select <8 x i1> %71, <8 x float> %680, <8 x float> %private.contiguous.preserve445
  store <8 x float> %859, ptr %private.contiguous.address444, align 4
  %860 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %861 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %862 = add <8 x i64> %861, splat (i64 384)
  %863 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %860, 0
  %864 = insertvalue { <8 x ptr>, <8 x i64> } %863, <8 x i64> %862, 1
  %865 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %866 = extractvalue { <8 x ptr>, <8 x i64> } %864, 1
  %867 = extractelement <8 x ptr> %865, i32 0
  %868 = extractelement <8 x i64> %866, i32 0
  %869 = sub i64 %868, 0
  %870 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %871 = select i1 %870, i64 %869, i64 0
  %private.contiguous.address446 = getelementptr i8, ptr %867, i64 %871
  %private.contiguous.preserve447 = load <8 x float>, ptr %private.contiguous.address446, align 4
  %872 = select <8 x i1> %71, <8 x float> %683, <8 x float> %private.contiguous.preserve447
  store <8 x float> %872, ptr %private.contiguous.address446, align 4
  %873 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %874 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %875 = add <8 x i64> %874, splat (i64 416)
  %876 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %873, 0
  %877 = insertvalue { <8 x ptr>, <8 x i64> } %876, <8 x i64> %875, 1
  %878 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %879 = extractvalue { <8 x ptr>, <8 x i64> } %877, 1
  %880 = extractelement <8 x ptr> %878, i32 0
  %881 = extractelement <8 x i64> %879, i32 0
  %882 = sub i64 %881, 0
  %883 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %884 = select i1 %883, i64 %882, i64 0
  %private.contiguous.address448 = getelementptr i8, ptr %880, i64 %884
  %private.contiguous.preserve449 = load <8 x float>, ptr %private.contiguous.address448, align 4
  %885 = select <8 x i1> %71, <8 x float> %686, <8 x float> %private.contiguous.preserve449
  store <8 x float> %885, ptr %private.contiguous.address448, align 4
  %886 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %887 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %888 = add <8 x i64> %887, splat (i64 448)
  %889 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %886, 0
  %890 = insertvalue { <8 x ptr>, <8 x i64> } %889, <8 x i64> %888, 1
  %891 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %892 = extractvalue { <8 x ptr>, <8 x i64> } %890, 1
  %893 = extractelement <8 x ptr> %891, i32 0
  %894 = extractelement <8 x i64> %892, i32 0
  %895 = sub i64 %894, 0
  %896 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %897 = select i1 %896, i64 %895, i64 0
  %private.contiguous.address450 = getelementptr i8, ptr %893, i64 %897
  %private.contiguous.preserve451 = load <8 x float>, ptr %private.contiguous.address450, align 4
  %898 = select <8 x i1> %71, <8 x float> %689, <8 x float> %private.contiguous.preserve451
  store <8 x float> %898, ptr %private.contiguous.address450, align 4
  %899 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %900 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %901 = add <8 x i64> %900, splat (i64 480)
  %902 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %899, 0
  %903 = insertvalue { <8 x ptr>, <8 x i64> } %902, <8 x i64> %901, 1
  %904 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %905 = extractvalue { <8 x ptr>, <8 x i64> } %903, 1
  %906 = extractelement <8 x ptr> %904, i32 0
  %907 = extractelement <8 x i64> %905, i32 0
  %908 = sub i64 %907, 0
  %909 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %910 = select i1 %909, i64 %908, i64 0
  %private.contiguous.address452 = getelementptr i8, ptr %906, i64 %910
  %private.contiguous.preserve453 = load <8 x float>, ptr %private.contiguous.address452, align 4
  %911 = select <8 x i1> %71, <8 x float> %692, <8 x float> %private.contiguous.preserve453
  store <8 x float> %911, ptr %private.contiguous.address452, align 4
  store i64 0, ptr %.slot94, align 4
  %912 = load <8 x float>, ptr %.slot95, align 32
  %913 = select <8 x i1> %71, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %912
  store <8 x float> %913, ptr %.slot95, align 32
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state454 = load i64, ptr %.slot94, align 4
  %914 = icmp slt i64 %.state454, 16
  br i1 %914, label %direct.true455, label %direct.false456

direct.schedule.23:                               ; preds = %direct.true455
  %.state457 = load i64, ptr %.slot94, align 4
  %915 = sdiv i64 %.state457, 1
  %.spill.load458 = load i64, ptr %.spill31, align 4
  %916 = mul i64 %.spill.load458, 1
  %917 = add i64 %916, 0
  %918 = mul i64 %917, 1
  %919 = add i64 %918, 0
  %920 = mul i64 %919, 16
  %921 = add i64 %920, %915
  %tile_snapshot.spill.load459 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill93, align 64
  %922 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load459, 0
  %923 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load459, 1
  %.splatinsert460 = insertelement <8 x i64> poison, i64 %921, i64 0
  %.splat461 = shufflevector <8 x i64> %.splatinsert460, <8 x i64> poison, <8 x i32> zeroinitializer
  %924 = mul <8 x i64> %.splat461, splat (i64 32)
  %925 = add <8 x i64> %923, %924
  %926 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %922, 0
  %927 = insertvalue { <8 x ptr>, <8 x i64> } %926, <8 x i64> %925, 1
  %928 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %929 = extractvalue { <8 x ptr>, <8 x i64> } %927, 1
  %930 = extractelement <8 x ptr> %928, i32 0
  %931 = extractelement <8 x i64> %929, i32 0
  %932 = sub i64 %931, 0
  %933 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %934 = select i1 %933, i64 %932, i64 0
  %private.contiguous.address462 = getelementptr i8, ptr %930, i64 %934
  %private.contiguous.load463 = load <8 x float>, ptr %private.contiguous.address462, align 4
  %935 = select <8 x i1> %71, <8 x float> %private.contiguous.load463, <8 x float> zeroinitializer
  %.state464 = load <8 x float>, ptr %.slot95, align 32
  %936 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state464, <8 x float> %935)
  %.state465 = load i64, ptr %.slot94, align 4
  %937 = add i64 %.state465, 1
  store i64 %937, ptr %.slot94, align 4
  %938 = load <8 x float>, ptr %.slot95, align 32
  %939 = select <8 x i1> %71, <8 x float> %936, <8 x float> %938
  store <8 x float> %939, ptr %.slot95, align 32
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false456
  %.state466 = load <8 x float>, ptr %.slot35, align 32
  %.state467 = load <8 x float>, ptr %.slot95, align 32
  %940 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state466, <8 x float> %.state467)
  %941 = load <8 x float>, ptr %.spill96, align 32
  %942 = select <8 x i1> %71, <8 x float> %940, <8 x float> %941
  store <8 x float> %942, ptr %.spill96, align 32
  %.state468 = load <8 x float>, ptr %.slot35, align 32
  %943 = fsub <8 x float> %.state468, %940
  %944 = select <8 x i1> %71, <8 x float> %943, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %944)
  %945 = load <8 x float>, ptr %.spill97, align 32
  %946 = select <8 x i1> %71, <8 x float> %native.exp, <8 x float> %945
  store <8 x float> %946, ptr %.spill97, align 32
  %.spill.load469 = load <8 x float>, ptr %.spill77, align 32
  %947 = fsub <8 x float> %.spill.load469, %940
  %.spill.load470 = load <8 x float>, ptr %.spill78, align 32
  %948 = fsub <8 x float> %.spill.load470, %940
  %.spill.load471 = load <8 x float>, ptr %.spill79, align 32
  %949 = fsub <8 x float> %.spill.load471, %940
  %.spill.load472 = load <8 x float>, ptr %.spill80, align 32
  %950 = fsub <8 x float> %.spill.load472, %940
  %.spill.load473 = load <8 x float>, ptr %.spill81, align 32
  %951 = fsub <8 x float> %.spill.load473, %940
  %.spill.load474 = load <8 x float>, ptr %.spill82, align 32
  %952 = fsub <8 x float> %.spill.load474, %940
  %.spill.load475 = load <8 x float>, ptr %.spill83, align 32
  %953 = fsub <8 x float> %.spill.load475, %940
  %.spill.load476 = load <8 x float>, ptr %.spill84, align 32
  %954 = fsub <8 x float> %.spill.load476, %940
  %.spill.load477 = load <8 x float>, ptr %.spill85, align 32
  %955 = fsub <8 x float> %.spill.load477, %940
  %.spill.load478 = load <8 x float>, ptr %.spill86, align 32
  %956 = fsub <8 x float> %.spill.load478, %940
  %.spill.load479 = load <8 x float>, ptr %.spill87, align 32
  %957 = fsub <8 x float> %.spill.load479, %940
  %.spill.load480 = load <8 x float>, ptr %.spill88, align 32
  %958 = fsub <8 x float> %.spill.load480, %940
  %.spill.load481 = load <8 x float>, ptr %.spill89, align 32
  %959 = fsub <8 x float> %.spill.load481, %940
  %.spill.load482 = load <8 x float>, ptr %.spill90, align 32
  %960 = fsub <8 x float> %.spill.load482, %940
  %.spill.load483 = load <8 x float>, ptr %.spill91, align 32
  %961 = fsub <8 x float> %.spill.load483, %940
  %.spill.load484 = load <8 x float>, ptr %.spill92, align 32
  %962 = fsub <8 x float> %.spill.load484, %940
  %963 = select <8 x i1> %71, <8 x float> %947, <8 x float> zeroinitializer
  %native.exp485 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %963)
  %964 = select <8 x i1> %71, <8 x float> %948, <8 x float> zeroinitializer
  %native.exp486 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %964)
  %965 = select <8 x i1> %71, <8 x float> %949, <8 x float> zeroinitializer
  %native.exp487 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %965)
  %966 = select <8 x i1> %71, <8 x float> %950, <8 x float> zeroinitializer
  %native.exp488 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %966)
  %967 = select <8 x i1> %71, <8 x float> %951, <8 x float> zeroinitializer
  %native.exp489 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %967)
  %968 = select <8 x i1> %71, <8 x float> %952, <8 x float> zeroinitializer
  %native.exp490 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %968)
  %969 = select <8 x i1> %71, <8 x float> %953, <8 x float> zeroinitializer
  %native.exp491 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %969)
  %970 = select <8 x i1> %71, <8 x float> %954, <8 x float> zeroinitializer
  %native.exp492 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %970)
  %971 = select <8 x i1> %71, <8 x float> %955, <8 x float> zeroinitializer
  %native.exp493 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %971)
  %972 = select <8 x i1> %71, <8 x float> %956, <8 x float> zeroinitializer
  %native.exp494 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %972)
  %973 = select <8 x i1> %71, <8 x float> %957, <8 x float> zeroinitializer
  %native.exp495 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %973)
  %974 = select <8 x i1> %71, <8 x float> %958, <8 x float> zeroinitializer
  %native.exp496 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %974)
  %975 = select <8 x i1> %71, <8 x float> %959, <8 x float> zeroinitializer
  %native.exp497 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %975)
  %976 = select <8 x i1> %71, <8 x float> %960, <8 x float> zeroinitializer
  %native.exp498 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %976)
  %977 = select <8 x i1> %71, <8 x float> %961, <8 x float> zeroinitializer
  %native.exp499 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %977)
  %978 = select <8 x i1> %71, <8 x float> %962, <8 x float> zeroinitializer
  %native.exp500 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %978)
  %.spill.load501 = load i1, ptr %.spill61, align 1
  %.splatinsert502 = insertelement <8 x i1> poison, i1 %.spill.load501, i64 0
  %.splat503 = shufflevector <8 x i1> %.splatinsert502, <8 x i1> poison, <8 x i32> zeroinitializer
  %979 = select <8 x i1> %.splat503, <8 x float> %native.exp485, <8 x float> zeroinitializer
  %.spill.load504 = load i1, ptr %.spill62, align 1
  %.splatinsert505 = insertelement <8 x i1> poison, i1 %.spill.load504, i64 0
  %.splat506 = shufflevector <8 x i1> %.splatinsert505, <8 x i1> poison, <8 x i32> zeroinitializer
  %980 = select <8 x i1> %.splat506, <8 x float> %native.exp486, <8 x float> zeroinitializer
  %.spill.load507 = load i1, ptr %.spill63, align 1
  %.splatinsert508 = insertelement <8 x i1> poison, i1 %.spill.load507, i64 0
  %.splat509 = shufflevector <8 x i1> %.splatinsert508, <8 x i1> poison, <8 x i32> zeroinitializer
  %981 = select <8 x i1> %.splat509, <8 x float> %native.exp487, <8 x float> zeroinitializer
  %.spill.load510 = load i1, ptr %.spill64, align 1
  %.splatinsert511 = insertelement <8 x i1> poison, i1 %.spill.load510, i64 0
  %.splat512 = shufflevector <8 x i1> %.splatinsert511, <8 x i1> poison, <8 x i32> zeroinitializer
  %982 = select <8 x i1> %.splat512, <8 x float> %native.exp488, <8 x float> zeroinitializer
  %.spill.load513 = load i1, ptr %.spill65, align 1
  %.splatinsert514 = insertelement <8 x i1> poison, i1 %.spill.load513, i64 0
  %.splat515 = shufflevector <8 x i1> %.splatinsert514, <8 x i1> poison, <8 x i32> zeroinitializer
  %983 = select <8 x i1> %.splat515, <8 x float> %native.exp489, <8 x float> zeroinitializer
  %.spill.load516 = load i1, ptr %.spill66, align 1
  %.splatinsert517 = insertelement <8 x i1> poison, i1 %.spill.load516, i64 0
  %.splat518 = shufflevector <8 x i1> %.splatinsert517, <8 x i1> poison, <8 x i32> zeroinitializer
  %984 = select <8 x i1> %.splat518, <8 x float> %native.exp490, <8 x float> zeroinitializer
  %.spill.load519 = load i1, ptr %.spill67, align 1
  %.splatinsert520 = insertelement <8 x i1> poison, i1 %.spill.load519, i64 0
  %.splat521 = shufflevector <8 x i1> %.splatinsert520, <8 x i1> poison, <8 x i32> zeroinitializer
  %985 = select <8 x i1> %.splat521, <8 x float> %native.exp491, <8 x float> zeroinitializer
  %.spill.load522 = load i1, ptr %.spill68, align 1
  %.splatinsert523 = insertelement <8 x i1> poison, i1 %.spill.load522, i64 0
  %.splat524 = shufflevector <8 x i1> %.splatinsert523, <8 x i1> poison, <8 x i32> zeroinitializer
  %986 = select <8 x i1> %.splat524, <8 x float> %native.exp492, <8 x float> zeroinitializer
  %.spill.load525 = load i1, ptr %.spill69, align 1
  %.splatinsert526 = insertelement <8 x i1> poison, i1 %.spill.load525, i64 0
  %.splat527 = shufflevector <8 x i1> %.splatinsert526, <8 x i1> poison, <8 x i32> zeroinitializer
  %987 = select <8 x i1> %.splat527, <8 x float> %native.exp493, <8 x float> zeroinitializer
  %.spill.load528 = load i1, ptr %.spill70, align 1
  %.splatinsert529 = insertelement <8 x i1> poison, i1 %.spill.load528, i64 0
  %.splat530 = shufflevector <8 x i1> %.splatinsert529, <8 x i1> poison, <8 x i32> zeroinitializer
  %988 = select <8 x i1> %.splat530, <8 x float> %native.exp494, <8 x float> zeroinitializer
  %.spill.load531 = load i1, ptr %.spill71, align 1
  %.splatinsert532 = insertelement <8 x i1> poison, i1 %.spill.load531, i64 0
  %.splat533 = shufflevector <8 x i1> %.splatinsert532, <8 x i1> poison, <8 x i32> zeroinitializer
  %989 = select <8 x i1> %.splat533, <8 x float> %native.exp495, <8 x float> zeroinitializer
  %.spill.load534 = load i1, ptr %.spill72, align 1
  %.splatinsert535 = insertelement <8 x i1> poison, i1 %.spill.load534, i64 0
  %.splat536 = shufflevector <8 x i1> %.splatinsert535, <8 x i1> poison, <8 x i32> zeroinitializer
  %990 = select <8 x i1> %.splat536, <8 x float> %native.exp496, <8 x float> zeroinitializer
  %.spill.load537 = load i1, ptr %.spill73, align 1
  %.splatinsert538 = insertelement <8 x i1> poison, i1 %.spill.load537, i64 0
  %.splat539 = shufflevector <8 x i1> %.splatinsert538, <8 x i1> poison, <8 x i32> zeroinitializer
  %991 = select <8 x i1> %.splat539, <8 x float> %native.exp497, <8 x float> zeroinitializer
  %.spill.load540 = load i1, ptr %.spill74, align 1
  %.splatinsert541 = insertelement <8 x i1> poison, i1 %.spill.load540, i64 0
  %.splat542 = shufflevector <8 x i1> %.splatinsert541, <8 x i1> poison, <8 x i32> zeroinitializer
  %992 = select <8 x i1> %.splat542, <8 x float> %native.exp498, <8 x float> zeroinitializer
  %.spill.load543 = load i1, ptr %.spill75, align 1
  %.splatinsert544 = insertelement <8 x i1> poison, i1 %.spill.load543, i64 0
  %.splat545 = shufflevector <8 x i1> %.splatinsert544, <8 x i1> poison, <8 x i32> zeroinitializer
  %993 = select <8 x i1> %.splat545, <8 x float> %native.exp499, <8 x float> zeroinitializer
  %.spill.load546 = load i1, ptr %.spill76, align 1
  %.splatinsert547 = insertelement <8 x i1> poison, i1 %.spill.load546, i64 0
  %.splat548 = shufflevector <8 x i1> %.splatinsert547, <8 x i1> poison, <8 x i32> zeroinitializer
  %994 = select <8 x i1> %.splat548, <8 x float> %native.exp500, <8 x float> zeroinitializer
  %995 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill98, align 64
  %996 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %997 = extractvalue { <8 x ptr>, <8 x i64> } %995, 0
  %998 = select <8 x i1> %71, <8 x ptr> %996, <8 x ptr> %997
  %999 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1000 = extractvalue { <8 x ptr>, <8 x i64> } %995, 1
  %1001 = select <8 x i1> %71, <8 x i64> %999, <8 x i64> %1000
  %1002 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %998, 0
  %1003 = insertvalue { <8 x ptr>, <8 x i64> } %1002, <8 x i64> %1001, 1
  store { <8 x ptr>, <8 x i64> } %1003, ptr %tile_snapshot.spill98, align 64
  %1004 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1005 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1006 = add <8 x i64> %1005, zeroinitializer
  %1007 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1004, 0
  %1008 = insertvalue { <8 x ptr>, <8 x i64> } %1007, <8 x i64> %1006, 1
  %1009 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1010 = extractvalue { <8 x ptr>, <8 x i64> } %1008, 1
  %1011 = extractelement <8 x ptr> %1009, i32 0
  %1012 = extractelement <8 x i64> %1010, i32 0
  %1013 = sub i64 %1012, 0
  %1014 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1015 = select i1 %1014, i64 %1013, i64 0
  %private.contiguous.address549 = getelementptr i8, ptr %1011, i64 %1015
  %private.contiguous.preserve550 = load <8 x float>, ptr %private.contiguous.address549, align 4
  %1016 = select <8 x i1> %71, <8 x float> %979, <8 x float> %private.contiguous.preserve550
  store <8 x float> %1016, ptr %private.contiguous.address549, align 4
  %1017 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1018 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1019 = add <8 x i64> %1018, splat (i64 32)
  %1020 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1017, 0
  %1021 = insertvalue { <8 x ptr>, <8 x i64> } %1020, <8 x i64> %1019, 1
  %1022 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1023 = extractvalue { <8 x ptr>, <8 x i64> } %1021, 1
  %1024 = extractelement <8 x ptr> %1022, i32 0
  %1025 = extractelement <8 x i64> %1023, i32 0
  %1026 = sub i64 %1025, 0
  %1027 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1028 = select i1 %1027, i64 %1026, i64 0
  %private.contiguous.address551 = getelementptr i8, ptr %1024, i64 %1028
  %private.contiguous.preserve552 = load <8 x float>, ptr %private.contiguous.address551, align 4
  %1029 = select <8 x i1> %71, <8 x float> %980, <8 x float> %private.contiguous.preserve552
  store <8 x float> %1029, ptr %private.contiguous.address551, align 4
  %1030 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1031 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1032 = add <8 x i64> %1031, splat (i64 64)
  %1033 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1030, 0
  %1034 = insertvalue { <8 x ptr>, <8 x i64> } %1033, <8 x i64> %1032, 1
  %1035 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1036 = extractvalue { <8 x ptr>, <8 x i64> } %1034, 1
  %1037 = extractelement <8 x ptr> %1035, i32 0
  %1038 = extractelement <8 x i64> %1036, i32 0
  %1039 = sub i64 %1038, 0
  %1040 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1041 = select i1 %1040, i64 %1039, i64 0
  %private.contiguous.address553 = getelementptr i8, ptr %1037, i64 %1041
  %private.contiguous.preserve554 = load <8 x float>, ptr %private.contiguous.address553, align 4
  %1042 = select <8 x i1> %71, <8 x float> %981, <8 x float> %private.contiguous.preserve554
  store <8 x float> %1042, ptr %private.contiguous.address553, align 4
  %1043 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1044 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1045 = add <8 x i64> %1044, splat (i64 96)
  %1046 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1043, 0
  %1047 = insertvalue { <8 x ptr>, <8 x i64> } %1046, <8 x i64> %1045, 1
  %1048 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1049 = extractvalue { <8 x ptr>, <8 x i64> } %1047, 1
  %1050 = extractelement <8 x ptr> %1048, i32 0
  %1051 = extractelement <8 x i64> %1049, i32 0
  %1052 = sub i64 %1051, 0
  %1053 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1054 = select i1 %1053, i64 %1052, i64 0
  %private.contiguous.address555 = getelementptr i8, ptr %1050, i64 %1054
  %private.contiguous.preserve556 = load <8 x float>, ptr %private.contiguous.address555, align 4
  %1055 = select <8 x i1> %71, <8 x float> %982, <8 x float> %private.contiguous.preserve556
  store <8 x float> %1055, ptr %private.contiguous.address555, align 4
  %1056 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1057 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1058 = add <8 x i64> %1057, splat (i64 128)
  %1059 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1056, 0
  %1060 = insertvalue { <8 x ptr>, <8 x i64> } %1059, <8 x i64> %1058, 1
  %1061 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1062 = extractvalue { <8 x ptr>, <8 x i64> } %1060, 1
  %1063 = extractelement <8 x ptr> %1061, i32 0
  %1064 = extractelement <8 x i64> %1062, i32 0
  %1065 = sub i64 %1064, 0
  %1066 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1067 = select i1 %1066, i64 %1065, i64 0
  %private.contiguous.address557 = getelementptr i8, ptr %1063, i64 %1067
  %private.contiguous.preserve558 = load <8 x float>, ptr %private.contiguous.address557, align 4
  %1068 = select <8 x i1> %71, <8 x float> %983, <8 x float> %private.contiguous.preserve558
  store <8 x float> %1068, ptr %private.contiguous.address557, align 4
  %1069 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1070 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1071 = add <8 x i64> %1070, splat (i64 160)
  %1072 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1069, 0
  %1073 = insertvalue { <8 x ptr>, <8 x i64> } %1072, <8 x i64> %1071, 1
  %1074 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1075 = extractvalue { <8 x ptr>, <8 x i64> } %1073, 1
  %1076 = extractelement <8 x ptr> %1074, i32 0
  %1077 = extractelement <8 x i64> %1075, i32 0
  %1078 = sub i64 %1077, 0
  %1079 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1080 = select i1 %1079, i64 %1078, i64 0
  %private.contiguous.address559 = getelementptr i8, ptr %1076, i64 %1080
  %private.contiguous.preserve560 = load <8 x float>, ptr %private.contiguous.address559, align 4
  %1081 = select <8 x i1> %71, <8 x float> %984, <8 x float> %private.contiguous.preserve560
  store <8 x float> %1081, ptr %private.contiguous.address559, align 4
  %1082 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1083 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1084 = add <8 x i64> %1083, splat (i64 192)
  %1085 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1082, 0
  %1086 = insertvalue { <8 x ptr>, <8 x i64> } %1085, <8 x i64> %1084, 1
  %1087 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1088 = extractvalue { <8 x ptr>, <8 x i64> } %1086, 1
  %1089 = extractelement <8 x ptr> %1087, i32 0
  %1090 = extractelement <8 x i64> %1088, i32 0
  %1091 = sub i64 %1090, 0
  %1092 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1093 = select i1 %1092, i64 %1091, i64 0
  %private.contiguous.address561 = getelementptr i8, ptr %1089, i64 %1093
  %private.contiguous.preserve562 = load <8 x float>, ptr %private.contiguous.address561, align 4
  %1094 = select <8 x i1> %71, <8 x float> %985, <8 x float> %private.contiguous.preserve562
  store <8 x float> %1094, ptr %private.contiguous.address561, align 4
  %1095 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1096 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1097 = add <8 x i64> %1096, splat (i64 224)
  %1098 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1095, 0
  %1099 = insertvalue { <8 x ptr>, <8 x i64> } %1098, <8 x i64> %1097, 1
  %1100 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1101 = extractvalue { <8 x ptr>, <8 x i64> } %1099, 1
  %1102 = extractelement <8 x ptr> %1100, i32 0
  %1103 = extractelement <8 x i64> %1101, i32 0
  %1104 = sub i64 %1103, 0
  %1105 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1106 = select i1 %1105, i64 %1104, i64 0
  %private.contiguous.address563 = getelementptr i8, ptr %1102, i64 %1106
  %private.contiguous.preserve564 = load <8 x float>, ptr %private.contiguous.address563, align 4
  %1107 = select <8 x i1> %71, <8 x float> %986, <8 x float> %private.contiguous.preserve564
  store <8 x float> %1107, ptr %private.contiguous.address563, align 4
  %1108 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1109 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1110 = add <8 x i64> %1109, splat (i64 256)
  %1111 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1108, 0
  %1112 = insertvalue { <8 x ptr>, <8 x i64> } %1111, <8 x i64> %1110, 1
  %1113 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1114 = extractvalue { <8 x ptr>, <8 x i64> } %1112, 1
  %1115 = extractelement <8 x ptr> %1113, i32 0
  %1116 = extractelement <8 x i64> %1114, i32 0
  %1117 = sub i64 %1116, 0
  %1118 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1119 = select i1 %1118, i64 %1117, i64 0
  %private.contiguous.address565 = getelementptr i8, ptr %1115, i64 %1119
  %private.contiguous.preserve566 = load <8 x float>, ptr %private.contiguous.address565, align 4
  %1120 = select <8 x i1> %71, <8 x float> %987, <8 x float> %private.contiguous.preserve566
  store <8 x float> %1120, ptr %private.contiguous.address565, align 4
  %1121 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1122 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1123 = add <8 x i64> %1122, splat (i64 288)
  %1124 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1121, 0
  %1125 = insertvalue { <8 x ptr>, <8 x i64> } %1124, <8 x i64> %1123, 1
  %1126 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1127 = extractvalue { <8 x ptr>, <8 x i64> } %1125, 1
  %1128 = extractelement <8 x ptr> %1126, i32 0
  %1129 = extractelement <8 x i64> %1127, i32 0
  %1130 = sub i64 %1129, 0
  %1131 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1132 = select i1 %1131, i64 %1130, i64 0
  %private.contiguous.address567 = getelementptr i8, ptr %1128, i64 %1132
  %private.contiguous.preserve568 = load <8 x float>, ptr %private.contiguous.address567, align 4
  %1133 = select <8 x i1> %71, <8 x float> %988, <8 x float> %private.contiguous.preserve568
  store <8 x float> %1133, ptr %private.contiguous.address567, align 4
  %1134 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1135 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1136 = add <8 x i64> %1135, splat (i64 320)
  %1137 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1134, 0
  %1138 = insertvalue { <8 x ptr>, <8 x i64> } %1137, <8 x i64> %1136, 1
  %1139 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1140 = extractvalue { <8 x ptr>, <8 x i64> } %1138, 1
  %1141 = extractelement <8 x ptr> %1139, i32 0
  %1142 = extractelement <8 x i64> %1140, i32 0
  %1143 = sub i64 %1142, 0
  %1144 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1145 = select i1 %1144, i64 %1143, i64 0
  %private.contiguous.address569 = getelementptr i8, ptr %1141, i64 %1145
  %private.contiguous.preserve570 = load <8 x float>, ptr %private.contiguous.address569, align 4
  %1146 = select <8 x i1> %71, <8 x float> %989, <8 x float> %private.contiguous.preserve570
  store <8 x float> %1146, ptr %private.contiguous.address569, align 4
  %1147 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1148 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1149 = add <8 x i64> %1148, splat (i64 352)
  %1150 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1147, 0
  %1151 = insertvalue { <8 x ptr>, <8 x i64> } %1150, <8 x i64> %1149, 1
  %1152 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1153 = extractvalue { <8 x ptr>, <8 x i64> } %1151, 1
  %1154 = extractelement <8 x ptr> %1152, i32 0
  %1155 = extractelement <8 x i64> %1153, i32 0
  %1156 = sub i64 %1155, 0
  %1157 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1158 = select i1 %1157, i64 %1156, i64 0
  %private.contiguous.address571 = getelementptr i8, ptr %1154, i64 %1158
  %private.contiguous.preserve572 = load <8 x float>, ptr %private.contiguous.address571, align 4
  %1159 = select <8 x i1> %71, <8 x float> %990, <8 x float> %private.contiguous.preserve572
  store <8 x float> %1159, ptr %private.contiguous.address571, align 4
  %1160 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1161 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1162 = add <8 x i64> %1161, splat (i64 384)
  %1163 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1160, 0
  %1164 = insertvalue { <8 x ptr>, <8 x i64> } %1163, <8 x i64> %1162, 1
  %1165 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1166 = extractvalue { <8 x ptr>, <8 x i64> } %1164, 1
  %1167 = extractelement <8 x ptr> %1165, i32 0
  %1168 = extractelement <8 x i64> %1166, i32 0
  %1169 = sub i64 %1168, 0
  %1170 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1171 = select i1 %1170, i64 %1169, i64 0
  %private.contiguous.address573 = getelementptr i8, ptr %1167, i64 %1171
  %private.contiguous.preserve574 = load <8 x float>, ptr %private.contiguous.address573, align 4
  %1172 = select <8 x i1> %71, <8 x float> %991, <8 x float> %private.contiguous.preserve574
  store <8 x float> %1172, ptr %private.contiguous.address573, align 4
  %1173 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1174 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1175 = add <8 x i64> %1174, splat (i64 416)
  %1176 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1173, 0
  %1177 = insertvalue { <8 x ptr>, <8 x i64> } %1176, <8 x i64> %1175, 1
  %1178 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1179 = extractvalue { <8 x ptr>, <8 x i64> } %1177, 1
  %1180 = extractelement <8 x ptr> %1178, i32 0
  %1181 = extractelement <8 x i64> %1179, i32 0
  %1182 = sub i64 %1181, 0
  %1183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1184 = select i1 %1183, i64 %1182, i64 0
  %private.contiguous.address575 = getelementptr i8, ptr %1180, i64 %1184
  %private.contiguous.preserve576 = load <8 x float>, ptr %private.contiguous.address575, align 4
  %1185 = select <8 x i1> %71, <8 x float> %992, <8 x float> %private.contiguous.preserve576
  store <8 x float> %1185, ptr %private.contiguous.address575, align 4
  %1186 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1187 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1188 = add <8 x i64> %1187, splat (i64 448)
  %1189 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1186, 0
  %1190 = insertvalue { <8 x ptr>, <8 x i64> } %1189, <8 x i64> %1188, 1
  %1191 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1192 = extractvalue { <8 x ptr>, <8 x i64> } %1190, 1
  %1193 = extractelement <8 x ptr> %1191, i32 0
  %1194 = extractelement <8 x i64> %1192, i32 0
  %1195 = sub i64 %1194, 0
  %1196 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1197 = select i1 %1196, i64 %1195, i64 0
  %private.contiguous.address577 = getelementptr i8, ptr %1193, i64 %1197
  %private.contiguous.preserve578 = load <8 x float>, ptr %private.contiguous.address577, align 4
  %1198 = select <8 x i1> %71, <8 x float> %993, <8 x float> %private.contiguous.preserve578
  store <8 x float> %1198, ptr %private.contiguous.address577, align 4
  %1199 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1200 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1201 = add <8 x i64> %1200, splat (i64 480)
  %1202 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1199, 0
  %1203 = insertvalue { <8 x ptr>, <8 x i64> } %1202, <8 x i64> %1201, 1
  %1204 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1205 = extractvalue { <8 x ptr>, <8 x i64> } %1203, 1
  %1206 = extractelement <8 x ptr> %1204, i32 0
  %1207 = extractelement <8 x i64> %1205, i32 0
  %1208 = sub i64 %1207, 0
  %1209 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1210 = select i1 %1209, i64 %1208, i64 0
  %private.contiguous.address579 = getelementptr i8, ptr %1206, i64 %1210
  %private.contiguous.preserve580 = load <8 x float>, ptr %private.contiguous.address579, align 4
  %1211 = select <8 x i1> %71, <8 x float> %994, <8 x float> %private.contiguous.preserve580
  store <8 x float> %1211, ptr %private.contiguous.address579, align 4
  %.state581 = load <8 x float>, ptr %.slot36, align 32
  %1212 = fmul <8 x float> %.state581, %native.exp
  %1213 = load <8 x float>, ptr %.spill99, align 32
  %1214 = select <8 x i1> %71, <8 x float> %1212, <8 x float> %1213
  store <8 x float> %1214, ptr %.spill99, align 32
  store i64 0, ptr %.slot100, align 4
  %1215 = load <8 x float>, ptr %.slot101, align 32
  %1216 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1215
  store <8 x float> %1216, ptr %.slot101, align 32
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.26, %direct.schedule.24
  %.state582 = load i64, ptr %.slot100, align 4
  %1217 = icmp slt i64 %.state582, 16
  br i1 %1217, label %direct.true583, label %direct.false584

direct.schedule.26:                               ; preds = %direct.true583
  %.state585 = load i64, ptr %.slot100, align 4
  %1218 = sdiv i64 %.state585, 1
  %.spill.load586 = load i64, ptr %.spill31, align 4
  %1219 = mul i64 %.spill.load586, 1
  %1220 = add i64 %1219, 0
  %1221 = mul i64 %1220, 1
  %1222 = add i64 %1221, 0
  %1223 = mul i64 %1222, 16
  %1224 = add i64 %1223, %1218
  %tile_snapshot.spill.load587 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill98, align 64
  %1225 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load587, 0
  %1226 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load587, 1
  %.splatinsert588 = insertelement <8 x i64> poison, i64 %1224, i64 0
  %.splat589 = shufflevector <8 x i64> %.splatinsert588, <8 x i64> poison, <8 x i32> zeroinitializer
  %1227 = mul <8 x i64> %.splat589, splat (i64 32)
  %1228 = add <8 x i64> %1226, %1227
  %1229 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1225, 0
  %1230 = insertvalue { <8 x ptr>, <8 x i64> } %1229, <8 x i64> %1228, 1
  %1231 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1232 = extractvalue { <8 x ptr>, <8 x i64> } %1230, 1
  %1233 = extractelement <8 x ptr> %1231, i32 0
  %1234 = extractelement <8 x i64> %1232, i32 0
  %1235 = sub i64 %1234, 0
  %1236 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1237 = select i1 %1236, i64 %1235, i64 0
  %private.contiguous.address590 = getelementptr i8, ptr %1233, i64 %1237
  %private.contiguous.load591 = load <8 x float>, ptr %private.contiguous.address590, align 4
  %1238 = select <8 x i1> %71, <8 x float> %private.contiguous.load591, <8 x float> zeroinitializer
  %.state592 = load <8 x float>, ptr %.slot101, align 32
  %1239 = fadd <8 x float> %.state592, %1238
  %.state593 = load i64, ptr %.slot100, align 4
  %1240 = add i64 %.state593, 1
  store i64 %1240, ptr %.slot100, align 4
  %1241 = load <8 x float>, ptr %.slot101, align 32
  %1242 = select <8 x i1> %71, <8 x float> %1239, <8 x float> %1241
  store <8 x float> %1242, ptr %.slot101, align 32
  br label %direct.schedule.25

direct.schedule.27:                               ; preds = %direct.false584
  %.spill.load594 = load <8 x float>, ptr %.spill99, align 32
  %.state595 = load <8 x float>, ptr %.slot101, align 32
  %1243 = fadd <8 x float> %.spill.load594, %.state595
  %1244 = load <8 x float>, ptr %.spill102, align 32
  %1245 = select <8 x i1> %71, <8 x float> %1243, <8 x float> %1244
  store <8 x float> %1245, ptr %.spill102, align 32
  %1246 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %1247 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1248 = extractvalue { <8 x ptr>, <8 x i64> } %1246, 0
  %1249 = select <8 x i1> %71, <8 x ptr> %1247, <8 x ptr> %1248
  %1250 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1251 = extractvalue { <8 x ptr>, <8 x i64> } %1246, 1
  %1252 = select <8 x i1> %71, <8 x i64> %1250, <8 x i64> %1251
  %1253 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1249, 0
  %1254 = insertvalue { <8 x ptr>, <8 x i64> } %1253, <8 x i64> %1252, 1
  store { <8 x ptr>, <8 x i64> } %1254, ptr %tile_snapshot.spill103, align 64
  store i64 0, ptr %.slot104, align 4
  br label %direct.schedule.28

direct.schedule.28:                               ; preds = %direct.schedule.32, %direct.schedule.27
  %.state596 = load i64, ptr %.slot104, align 4
  %1255 = icmp slt i64 %.state596, 24
  br i1 %1255, label %direct.true597, label %direct.false598

direct.schedule.29:                               ; preds = %direct.true597
  %.state599 = load i64, ptr %.slot104, align 4
  %1256 = mul i64 %.state599, 4
  %1257 = add i64 0, %1256
  %1258 = add i64 %1257, 0
  store i64 %1258, ptr %.spill105, align 4
  %1259 = add i64 0, %1258
  %tile_snapshot.spill.load600 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1260 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load600, 0
  %1261 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load600, 1
  %.splatinsert601 = insertelement <8 x i64> poison, i64 %1259, i64 0
  %.splat602 = shufflevector <8 x i64> %.splatinsert601, <8 x i64> poison, <8 x i32> zeroinitializer
  %1262 = mul <8 x i64> %.splat602, splat (i64 32)
  %1263 = add <8 x i64> %1261, %1262
  %1264 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1260, 0
  %1265 = insertvalue { <8 x ptr>, <8 x i64> } %1264, <8 x i64> %1263, 1
  %1266 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1267 = extractvalue { <8 x ptr>, <8 x i64> } %1265, 1
  %1268 = extractelement <8 x ptr> %1266, i32 0
  %1269 = extractelement <8 x i64> %1267, i32 0
  %1270 = sub i64 %1269, 0
  %1271 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1272 = select i1 %1271, i64 %1270, i64 0
  %private.contiguous.address603 = getelementptr i8, ptr %1268, i64 %1272
  %private.contiguous.load604 = load <8 x float>, ptr %private.contiguous.address603, align 4
  %1273 = select <8 x i1> %71, <8 x float> %private.contiguous.load604, <8 x float> zeroinitializer
  %.spill.load605 = load <8 x float>, ptr %.spill97, align 32
  %1274 = fmul <8 x float> %1273, %.spill.load605
  %1275 = add i64 %1257, 1
  store i64 %1275, ptr %.spill106, align 4
  %1276 = add i64 0, %1275
  %tile_snapshot.spill.load606 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1277 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load606, 0
  %1278 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load606, 1
  %.splatinsert607 = insertelement <8 x i64> poison, i64 %1276, i64 0
  %.splat608 = shufflevector <8 x i64> %.splatinsert607, <8 x i64> poison, <8 x i32> zeroinitializer
  %1279 = mul <8 x i64> %.splat608, splat (i64 32)
  %1280 = add <8 x i64> %1278, %1279
  %1281 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1277, 0
  %1282 = insertvalue { <8 x ptr>, <8 x i64> } %1281, <8 x i64> %1280, 1
  %1283 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1284 = extractvalue { <8 x ptr>, <8 x i64> } %1282, 1
  %1285 = extractelement <8 x ptr> %1283, i32 0
  %1286 = extractelement <8 x i64> %1284, i32 0
  %1287 = sub i64 %1286, 0
  %1288 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1289 = select i1 %1288, i64 %1287, i64 0
  %private.contiguous.address609 = getelementptr i8, ptr %1285, i64 %1289
  %private.contiguous.load610 = load <8 x float>, ptr %private.contiguous.address609, align 4
  %1290 = select <8 x i1> %71, <8 x float> %private.contiguous.load610, <8 x float> zeroinitializer
  %.spill.load611 = load <8 x float>, ptr %.spill97, align 32
  %1291 = fmul <8 x float> %1290, %.spill.load611
  %1292 = add i64 %1257, 2
  store i64 %1292, ptr %.spill107, align 4
  %1293 = add i64 0, %1292
  %tile_snapshot.spill.load612 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1294 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load612, 0
  %1295 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load612, 1
  %.splatinsert613 = insertelement <8 x i64> poison, i64 %1293, i64 0
  %.splat614 = shufflevector <8 x i64> %.splatinsert613, <8 x i64> poison, <8 x i32> zeroinitializer
  %1296 = mul <8 x i64> %.splat614, splat (i64 32)
  %1297 = add <8 x i64> %1295, %1296
  %1298 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1294, 0
  %1299 = insertvalue { <8 x ptr>, <8 x i64> } %1298, <8 x i64> %1297, 1
  %1300 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1301 = extractvalue { <8 x ptr>, <8 x i64> } %1299, 1
  %1302 = extractelement <8 x ptr> %1300, i32 0
  %1303 = extractelement <8 x i64> %1301, i32 0
  %1304 = sub i64 %1303, 0
  %1305 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1306 = select i1 %1305, i64 %1304, i64 0
  %private.contiguous.address615 = getelementptr i8, ptr %1302, i64 %1306
  %private.contiguous.load616 = load <8 x float>, ptr %private.contiguous.address615, align 4
  %1307 = select <8 x i1> %71, <8 x float> %private.contiguous.load616, <8 x float> zeroinitializer
  %.spill.load617 = load <8 x float>, ptr %.spill97, align 32
  %1308 = fmul <8 x float> %1307, %.spill.load617
  %1309 = add i64 %1257, 3
  store i64 %1309, ptr %.spill108, align 4
  %1310 = add i64 0, %1309
  %tile_snapshot.spill.load618 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1311 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load618, 0
  %1312 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load618, 1
  %.splatinsert619 = insertelement <8 x i64> poison, i64 %1310, i64 0
  %.splat620 = shufflevector <8 x i64> %.splatinsert619, <8 x i64> poison, <8 x i32> zeroinitializer
  %1313 = mul <8 x i64> %.splat620, splat (i64 32)
  %1314 = add <8 x i64> %1312, %1313
  %1315 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1311, 0
  %1316 = insertvalue { <8 x ptr>, <8 x i64> } %1315, <8 x i64> %1314, 1
  %1317 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1318 = extractvalue { <8 x ptr>, <8 x i64> } %1316, 1
  %1319 = extractelement <8 x ptr> %1317, i32 0
  %1320 = extractelement <8 x i64> %1318, i32 0
  %1321 = sub i64 %1320, 0
  %1322 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1323 = select i1 %1322, i64 %1321, i64 0
  %private.contiguous.address621 = getelementptr i8, ptr %1319, i64 %1323
  %private.contiguous.load622 = load <8 x float>, ptr %private.contiguous.address621, align 4
  %1324 = select <8 x i1> %71, <8 x float> %private.contiguous.load622, <8 x float> zeroinitializer
  %.spill.load623 = load <8 x float>, ptr %.spill97, align 32
  %1325 = fmul <8 x float> %1324, %.spill.load623
  store i64 0, ptr %.slot109, align 4
  %1326 = load <8 x float>, ptr %.slot110, align 32
  %1327 = select <8 x i1> %71, <8 x float> %1274, <8 x float> %1326
  store <8 x float> %1327, ptr %.slot110, align 32
  %1328 = load <8 x float>, ptr %.slot111, align 32
  %1329 = select <8 x i1> %71, <8 x float> %1291, <8 x float> %1328
  store <8 x float> %1329, ptr %.slot111, align 32
  %1330 = load <8 x float>, ptr %.slot112, align 32
  %1331 = select <8 x i1> %71, <8 x float> %1308, <8 x float> %1330
  store <8 x float> %1331, ptr %.slot112, align 32
  %1332 = load <8 x float>, ptr %.slot113, align 32
  %1333 = select <8 x i1> %71, <8 x float> %1325, <8 x float> %1332
  store <8 x float> %1333, ptr %.slot113, align 32
  br label %direct.schedule.30

direct.schedule.30:                               ; preds = %direct.schedule.31, %direct.schedule.29
  %.state624 = load i64, ptr %.slot109, align 4
  %1334 = icmp slt i64 %.state624, 16
  br i1 %1334, label %direct.true625, label %direct.false626

direct.schedule.31:                               ; preds = %direct.true625
  %.state627 = load i64, ptr %.slot109, align 4
  %1335 = add i64 0, %.state627
  %tile_snapshot.spill.load628 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill98, align 64
  %1336 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load628, 0
  %1337 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load628, 1
  %.splatinsert629 = insertelement <8 x i64> poison, i64 %1335, i64 0
  %.splat630 = shufflevector <8 x i64> %.splatinsert629, <8 x i64> poison, <8 x i32> zeroinitializer
  %1338 = mul <8 x i64> %.splat630, splat (i64 32)
  %1339 = add <8 x i64> %1337, %1338
  %1340 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1336, 0
  %1341 = insertvalue { <8 x ptr>, <8 x i64> } %1340, <8 x i64> %1339, 1
  %1342 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1343 = extractvalue { <8 x ptr>, <8 x i64> } %1341, 1
  %1344 = extractelement <8 x ptr> %1342, i32 0
  %1345 = extractelement <8 x i64> %1343, i32 0
  %1346 = sub i64 %1345, 0
  %1347 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1348 = select i1 %1347, i64 %1346, i64 0
  %private.contiguous.address631 = getelementptr i8, ptr %1344, i64 %1348
  %private.contiguous.load632 = load <8 x float>, ptr %private.contiguous.address631, align 4
  %1349 = select <8 x i1> %71, <8 x float> %private.contiguous.load632, <8 x float> zeroinitializer
  %1350 = mul i64 %1335, 96
  %.spill.load633 = load i64, ptr %.spill105, align 4
  %1351 = add i64 %1350, %.spill.load633
  %tile_snapshot.spill.load634 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %1352 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load634, 0
  %1353 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load634, 1
  %.splatinsert635 = insertelement <8 x i64> poison, i64 %1351, i64 0
  %.splat636 = shufflevector <8 x i64> %.splatinsert635, <8 x i64> poison, <8 x i32> zeroinitializer
  %1354 = mul <8 x i64> %.splat636, splat (i64 32)
  %1355 = add <8 x i64> %1353, %1354
  %1356 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1352, 0
  %1357 = insertvalue { <8 x ptr>, <8 x i64> } %1356, <8 x i64> %1355, 1
  %1358 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1359 = extractvalue { <8 x ptr>, <8 x i64> } %1357, 1
  %1360 = extractelement <8 x ptr> %1358, i32 0
  %1361 = extractelement <8 x i64> %1359, i32 0
  %1362 = sub i64 %1361, 0
  %1363 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1364 = select i1 %1363, i64 %1362, i64 0
  %private.contiguous.address637 = getelementptr i8, ptr %1360, i64 %1364
  %private.contiguous.load638 = load <8 x float>, ptr %private.contiguous.address637, align 4
  %1365 = select <8 x i1> %71, <8 x float> %private.contiguous.load638, <8 x float> zeroinitializer
  %1366 = fmul <8 x float> %1349, %1365
  %.state639 = load <8 x float>, ptr %.slot110, align 32
  %1367 = fadd <8 x float> %.state639, %1366
  %.spill.load640 = load i64, ptr %.spill106, align 4
  %1368 = add i64 %1350, %.spill.load640
  %tile_snapshot.spill.load641 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %1369 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load641, 0
  %1370 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load641, 1
  %.splatinsert642 = insertelement <8 x i64> poison, i64 %1368, i64 0
  %.splat643 = shufflevector <8 x i64> %.splatinsert642, <8 x i64> poison, <8 x i32> zeroinitializer
  %1371 = mul <8 x i64> %.splat643, splat (i64 32)
  %1372 = add <8 x i64> %1370, %1371
  %1373 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1369, 0
  %1374 = insertvalue { <8 x ptr>, <8 x i64> } %1373, <8 x i64> %1372, 1
  %1375 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1376 = extractvalue { <8 x ptr>, <8 x i64> } %1374, 1
  %1377 = extractelement <8 x ptr> %1375, i32 0
  %1378 = extractelement <8 x i64> %1376, i32 0
  %1379 = sub i64 %1378, 0
  %1380 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1381 = select i1 %1380, i64 %1379, i64 0
  %private.contiguous.address644 = getelementptr i8, ptr %1377, i64 %1381
  %private.contiguous.load645 = load <8 x float>, ptr %private.contiguous.address644, align 4
  %1382 = select <8 x i1> %71, <8 x float> %private.contiguous.load645, <8 x float> zeroinitializer
  %1383 = fmul <8 x float> %1349, %1382
  %.state646 = load <8 x float>, ptr %.slot111, align 32
  %1384 = fadd <8 x float> %.state646, %1383
  %.spill.load647 = load i64, ptr %.spill107, align 4
  %1385 = add i64 %1350, %.spill.load647
  %tile_snapshot.spill.load648 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %1386 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load648, 0
  %1387 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load648, 1
  %.splatinsert649 = insertelement <8 x i64> poison, i64 %1385, i64 0
  %.splat650 = shufflevector <8 x i64> %.splatinsert649, <8 x i64> poison, <8 x i32> zeroinitializer
  %1388 = mul <8 x i64> %.splat650, splat (i64 32)
  %1389 = add <8 x i64> %1387, %1388
  %1390 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1386, 0
  %1391 = insertvalue { <8 x ptr>, <8 x i64> } %1390, <8 x i64> %1389, 1
  %1392 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1393 = extractvalue { <8 x ptr>, <8 x i64> } %1391, 1
  %1394 = extractelement <8 x ptr> %1392, i32 0
  %1395 = extractelement <8 x i64> %1393, i32 0
  %1396 = sub i64 %1395, 0
  %1397 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1398 = select i1 %1397, i64 %1396, i64 0
  %private.contiguous.address651 = getelementptr i8, ptr %1394, i64 %1398
  %private.contiguous.load652 = load <8 x float>, ptr %private.contiguous.address651, align 4
  %1399 = select <8 x i1> %71, <8 x float> %private.contiguous.load652, <8 x float> zeroinitializer
  %1400 = fmul <8 x float> %1349, %1399
  %.state653 = load <8 x float>, ptr %.slot112, align 32
  %1401 = fadd <8 x float> %.state653, %1400
  %.spill.load654 = load i64, ptr %.spill108, align 4
  %1402 = add i64 %1350, %.spill.load654
  %tile_snapshot.spill.load655 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %1403 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load655, 0
  %1404 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load655, 1
  %.splatinsert656 = insertelement <8 x i64> poison, i64 %1402, i64 0
  %.splat657 = shufflevector <8 x i64> %.splatinsert656, <8 x i64> poison, <8 x i32> zeroinitializer
  %1405 = mul <8 x i64> %.splat657, splat (i64 32)
  %1406 = add <8 x i64> %1404, %1405
  %1407 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1403, 0
  %1408 = insertvalue { <8 x ptr>, <8 x i64> } %1407, <8 x i64> %1406, 1
  %1409 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1410 = extractvalue { <8 x ptr>, <8 x i64> } %1408, 1
  %1411 = extractelement <8 x ptr> %1409, i32 0
  %1412 = extractelement <8 x i64> %1410, i32 0
  %1413 = sub i64 %1412, 0
  %1414 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1415 = select i1 %1414, i64 %1413, i64 0
  %private.contiguous.address658 = getelementptr i8, ptr %1411, i64 %1415
  %private.contiguous.load659 = load <8 x float>, ptr %private.contiguous.address658, align 4
  %1416 = select <8 x i1> %71, <8 x float> %private.contiguous.load659, <8 x float> zeroinitializer
  %1417 = fmul <8 x float> %1349, %1416
  %.state660 = load <8 x float>, ptr %.slot113, align 32
  %1418 = fadd <8 x float> %.state660, %1417
  %.state661 = load i64, ptr %.slot109, align 4
  %1419 = add i64 %.state661, 1
  store i64 %1419, ptr %.slot109, align 4
  %1420 = load <8 x float>, ptr %.slot110, align 32
  %1421 = select <8 x i1> %71, <8 x float> %1367, <8 x float> %1420
  store <8 x float> %1421, ptr %.slot110, align 32
  %1422 = load <8 x float>, ptr %.slot111, align 32
  %1423 = select <8 x i1> %71, <8 x float> %1384, <8 x float> %1422
  store <8 x float> %1423, ptr %.slot111, align 32
  %1424 = load <8 x float>, ptr %.slot112, align 32
  %1425 = select <8 x i1> %71, <8 x float> %1401, <8 x float> %1424
  store <8 x float> %1425, ptr %.slot112, align 32
  %1426 = load <8 x float>, ptr %.slot113, align 32
  %1427 = select <8 x i1> %71, <8 x float> %1418, <8 x float> %1426
  store <8 x float> %1427, ptr %.slot113, align 32
  br label %direct.schedule.30

direct.schedule.32:                               ; preds = %direct.false626
  %tile_snapshot.spill.load662 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %1428 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load662, 0
  %1429 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load662, 1
  %.spill.load663 = load i64, ptr %.spill105, align 4
  %.splatinsert664 = insertelement <8 x i64> poison, i64 %.spill.load663, i64 0
  %.splat665 = shufflevector <8 x i64> %.splatinsert664, <8 x i64> poison, <8 x i32> zeroinitializer
  %1430 = mul <8 x i64> %.splat665, splat (i64 32)
  %1431 = add <8 x i64> %1429, %1430
  %1432 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1428, 0
  %1433 = insertvalue { <8 x ptr>, <8 x i64> } %1432, <8 x i64> %1431, 1
  %.state666 = load <8 x float>, ptr %.slot110, align 32
  %1434 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1435 = extractvalue { <8 x ptr>, <8 x i64> } %1433, 1
  %1436 = extractelement <8 x ptr> %1434, i32 0
  %1437 = extractelement <8 x i64> %1435, i32 0
  %1438 = sub i64 %1437, 0
  %1439 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1440 = select i1 %1439, i64 %1438, i64 0
  %private.contiguous.address667 = getelementptr i8, ptr %1436, i64 %1440
  %private.contiguous.preserve668 = load <8 x float>, ptr %private.contiguous.address667, align 4
  %1441 = select <8 x i1> %71, <8 x float> %.state666, <8 x float> %private.contiguous.preserve668
  store <8 x float> %1441, ptr %private.contiguous.address667, align 4
  %tile_snapshot.spill.load669 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %1442 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load669, 0
  %1443 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load669, 1
  %.spill.load670 = load i64, ptr %.spill106, align 4
  %.splatinsert671 = insertelement <8 x i64> poison, i64 %.spill.load670, i64 0
  %.splat672 = shufflevector <8 x i64> %.splatinsert671, <8 x i64> poison, <8 x i32> zeroinitializer
  %1444 = mul <8 x i64> %.splat672, splat (i64 32)
  %1445 = add <8 x i64> %1443, %1444
  %1446 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1442, 0
  %1447 = insertvalue { <8 x ptr>, <8 x i64> } %1446, <8 x i64> %1445, 1
  %.state673 = load <8 x float>, ptr %.slot111, align 32
  %1448 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1449 = extractvalue { <8 x ptr>, <8 x i64> } %1447, 1
  %1450 = extractelement <8 x ptr> %1448, i32 0
  %1451 = extractelement <8 x i64> %1449, i32 0
  %1452 = sub i64 %1451, 0
  %1453 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1454 = select i1 %1453, i64 %1452, i64 0
  %private.contiguous.address674 = getelementptr i8, ptr %1450, i64 %1454
  %private.contiguous.preserve675 = load <8 x float>, ptr %private.contiguous.address674, align 4
  %1455 = select <8 x i1> %71, <8 x float> %.state673, <8 x float> %private.contiguous.preserve675
  store <8 x float> %1455, ptr %private.contiguous.address674, align 4
  %tile_snapshot.spill.load676 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %1456 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load676, 0
  %1457 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load676, 1
  %.spill.load677 = load i64, ptr %.spill107, align 4
  %.splatinsert678 = insertelement <8 x i64> poison, i64 %.spill.load677, i64 0
  %.splat679 = shufflevector <8 x i64> %.splatinsert678, <8 x i64> poison, <8 x i32> zeroinitializer
  %1458 = mul <8 x i64> %.splat679, splat (i64 32)
  %1459 = add <8 x i64> %1457, %1458
  %1460 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1456, 0
  %1461 = insertvalue { <8 x ptr>, <8 x i64> } %1460, <8 x i64> %1459, 1
  %.state680 = load <8 x float>, ptr %.slot112, align 32
  %1462 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1463 = extractvalue { <8 x ptr>, <8 x i64> } %1461, 1
  %1464 = extractelement <8 x ptr> %1462, i32 0
  %1465 = extractelement <8 x i64> %1463, i32 0
  %1466 = sub i64 %1465, 0
  %1467 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1468 = select i1 %1467, i64 %1466, i64 0
  %private.contiguous.address681 = getelementptr i8, ptr %1464, i64 %1468
  %private.contiguous.preserve682 = load <8 x float>, ptr %private.contiguous.address681, align 4
  %1469 = select <8 x i1> %71, <8 x float> %.state680, <8 x float> %private.contiguous.preserve682
  store <8 x float> %1469, ptr %private.contiguous.address681, align 4
  %tile_snapshot.spill.load683 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %1470 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load683, 0
  %1471 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load683, 1
  %.spill.load684 = load i64, ptr %.spill108, align 4
  %.splatinsert685 = insertelement <8 x i64> poison, i64 %.spill.load684, i64 0
  %.splat686 = shufflevector <8 x i64> %.splatinsert685, <8 x i64> poison, <8 x i32> zeroinitializer
  %1472 = mul <8 x i64> %.splat686, splat (i64 32)
  %1473 = add <8 x i64> %1471, %1472
  %1474 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1470, 0
  %1475 = insertvalue { <8 x ptr>, <8 x i64> } %1474, <8 x i64> %1473, 1
  %.state687 = load <8 x float>, ptr %.slot113, align 32
  %1476 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1477 = extractvalue { <8 x ptr>, <8 x i64> } %1475, 1
  %1478 = extractelement <8 x ptr> %1476, i32 0
  %1479 = extractelement <8 x i64> %1477, i32 0
  %1480 = sub i64 %1479, 0
  %1481 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1482 = select i1 %1481, i64 %1480, i64 0
  %private.contiguous.address688 = getelementptr i8, ptr %1478, i64 %1482
  %private.contiguous.preserve689 = load <8 x float>, ptr %private.contiguous.address688, align 4
  %1483 = select <8 x i1> %71, <8 x float> %.state687, <8 x float> %private.contiguous.preserve689
  store <8 x float> %1483, ptr %private.contiguous.address688, align 4
  %.state690 = load i64, ptr %.slot104, align 4
  %1484 = add i64 %.state690, 1
  store i64 %1484, ptr %.slot104, align 4
  br label %direct.schedule.28

direct.schedule.33:                               ; preds = %direct.false598
  store i64 0, ptr %.slot114, align 4
  br label %direct.schedule.34

direct.schedule.34:                               ; preds = %direct.schedule.35, %direct.schedule.33
  %.state691 = load i64, ptr %.slot114, align 4
  %1485 = icmp slt i64 %.state691, 96
  br i1 %1485, label %direct.true692, label %direct.false693

direct.schedule.35:                               ; preds = %direct.true692
  %tile_snapshot.spill.load694 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %1486 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load694, 0
  %1487 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load694, 1
  %.state695 = load i64, ptr %.slot114, align 4
  %.splatinsert696 = insertelement <8 x i64> poison, i64 %.state695, i64 0
  %.splat697 = shufflevector <8 x i64> %.splatinsert696, <8 x i64> poison, <8 x i32> zeroinitializer
  %1488 = mul <8 x i64> %.splat697, splat (i64 32)
  %1489 = add <8 x i64> %1487, %1488
  %1490 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1486, 0
  %1491 = insertvalue { <8 x ptr>, <8 x i64> } %1490, <8 x i64> %1489, 1
  %1492 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1493 = extractvalue { <8 x ptr>, <8 x i64> } %1491, 1
  %1494 = extractelement <8 x ptr> %1492, i32 0
  %1495 = extractelement <8 x i64> %1493, i32 0
  %1496 = sub i64 %1495, 0
  %1497 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1498 = select i1 %1497, i64 %1496, i64 0
  %private.contiguous.address698 = getelementptr i8, ptr %1494, i64 %1498
  %private.contiguous.load699 = load <8 x float>, ptr %private.contiguous.address698, align 4
  %1499 = select <8 x i1> %71, <8 x float> %private.contiguous.load699, <8 x float> zeroinitializer
  %tile_snapshot.spill.load700 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill33, align 64
  %1500 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load700, 0
  %1501 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load700, 1
  %.state701 = load i64, ptr %.slot114, align 4
  %.splatinsert702 = insertelement <8 x i64> poison, i64 %.state701, i64 0
  %.splat703 = shufflevector <8 x i64> %.splatinsert702, <8 x i64> poison, <8 x i32> zeroinitializer
  %1502 = mul <8 x i64> %.splat703, splat (i64 32)
  %1503 = add <8 x i64> %1501, %1502
  %1504 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1500, 0
  %1505 = insertvalue { <8 x ptr>, <8 x i64> } %1504, <8 x i64> %1503, 1
  %1506 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1507 = extractvalue { <8 x ptr>, <8 x i64> } %1505, 1
  %1508 = extractelement <8 x ptr> %1506, i32 0
  %1509 = extractelement <8 x i64> %1507, i32 0
  %1510 = sub i64 %1509, 0
  %1511 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1512 = select i1 %1511, i64 %1510, i64 0
  %private.contiguous.address704 = getelementptr i8, ptr %1508, i64 %1512
  %private.contiguous.preserve705 = load <8 x float>, ptr %private.contiguous.address704, align 4
  %1513 = select <8 x i1> %71, <8 x float> %1499, <8 x float> %private.contiguous.preserve705
  store <8 x float> %1513, ptr %private.contiguous.address704, align 4
  %.state706 = load i64, ptr %.slot114, align 4
  %1514 = add i64 %.state706, 1
  store i64 %1514, ptr %.slot114, align 4
  br label %direct.schedule.34

direct.schedule.36:                               ; preds = %direct.false693
  store i64 0, ptr %.slot115, align 4
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.38, %direct.schedule.36
  %.state707 = load i64, ptr %.slot115, align 4
  %1515 = icmp slt i64 %.state707, 96
  br i1 %1515, label %direct.true708, label %direct.false709

direct.schedule.38:                               ; preds = %direct.true708
  %tile_snapshot.spill.load710 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill33, align 64
  %1516 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load710, 0
  %1517 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load710, 1
  %.state711 = load i64, ptr %.slot115, align 4
  %.splatinsert712 = insertelement <8 x i64> poison, i64 %.state711, i64 0
  %.splat713 = shufflevector <8 x i64> %.splatinsert712, <8 x i64> poison, <8 x i32> zeroinitializer
  %1518 = mul <8 x i64> %.splat713, splat (i64 32)
  %1519 = add <8 x i64> %1517, %1518
  %1520 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1516, 0
  %1521 = insertvalue { <8 x ptr>, <8 x i64> } %1520, <8 x i64> %1519, 1
  %1522 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1523 = extractvalue { <8 x ptr>, <8 x i64> } %1521, 1
  %1524 = extractelement <8 x ptr> %1522, i32 0
  %1525 = extractelement <8 x i64> %1523, i32 0
  %1526 = sub i64 %1525, 0
  %1527 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1528 = select i1 %1527, i64 %1526, i64 0
  %private.contiguous.address714 = getelementptr i8, ptr %1524, i64 %1528
  %private.contiguous.load715 = load <8 x float>, ptr %private.contiguous.address714, align 4
  %1529 = select <8 x i1> %71, <8 x float> %private.contiguous.load715, <8 x float> zeroinitializer
  %tile_snapshot.spill.load716 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1530 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load716, 0
  %1531 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load716, 1
  %.state717 = load i64, ptr %.slot115, align 4
  %.splatinsert718 = insertelement <8 x i64> poison, i64 %.state717, i64 0
  %.splat719 = shufflevector <8 x i64> %.splatinsert718, <8 x i64> poison, <8 x i32> zeroinitializer
  %1532 = mul <8 x i64> %.splat719, splat (i64 32)
  %1533 = add <8 x i64> %1531, %1532
  %1534 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1530, 0
  %1535 = insertvalue { <8 x ptr>, <8 x i64> } %1534, <8 x i64> %1533, 1
  %1536 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1537 = extractvalue { <8 x ptr>, <8 x i64> } %1535, 1
  %1538 = extractelement <8 x ptr> %1536, i32 0
  %1539 = extractelement <8 x i64> %1537, i32 0
  %1540 = sub i64 %1539, 0
  %1541 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1542 = select i1 %1541, i64 %1540, i64 0
  %private.contiguous.address720 = getelementptr i8, ptr %1538, i64 %1542
  %private.contiguous.preserve721 = load <8 x float>, ptr %private.contiguous.address720, align 4
  %1543 = select <8 x i1> %71, <8 x float> %1529, <8 x float> %private.contiguous.preserve721
  store <8 x float> %1543, ptr %private.contiguous.address720, align 4
  %.state722 = load i64, ptr %.slot115, align 4
  %1544 = add i64 %.state722, 1
  store i64 %1544, ptr %.slot115, align 4
  br label %direct.schedule.37

direct.schedule.39:                               ; preds = %direct.false709
  %.state723 = load i64, ptr %.slot34, align 4
  %1545 = add i64 %.state723, 1
  %.spill.load724 = load <8 x float>, ptr %.spill96, align 32
  %.spill.load725 = load <8 x float>, ptr %.spill102, align 32
  store i64 %1545, ptr %.slot34, align 4
  %1546 = load <8 x float>, ptr %.slot35, align 32
  %1547 = select <8 x i1> %71, <8 x float> %.spill.load724, <8 x float> %1546
  store <8 x float> %1547, ptr %.slot35, align 32
  %1548 = load <8 x float>, ptr %.slot36, align 32
  %1549 = select <8 x i1> %71, <8 x float> %.spill.load725, <8 x float> %1548
  store <8 x float> %1549, ptr %.slot36, align 32
  br label %direct.schedule.4

direct.schedule.40:                               ; preds = %direct.false182
  store i64 0, ptr %.slot116, align 4
  br label %direct.schedule.41

direct.schedule.41:                               ; preds = %direct.schedule.44, %direct.schedule.40
  %.state726 = load i64, ptr %.slot116, align 4
  %1550 = icmp slt i64 %.state726, 1536
  br i1 %1550, label %direct.true727, label %direct.false728

direct.schedule.42:                               ; preds = %direct.true727
  %.state729 = load i64, ptr %.slot116, align 4
  %1551 = srem i64 %.state729, 96
  %.state730 = load i64, ptr %.slot116, align 4
  %1552 = sdiv i64 %.state730, 96
  %.spill.load731 = load i64, ptr %.spill29, align 4
  %1553 = add i64 %.spill.load731, 0
  %.spill.load732 = load <8 x i64>, ptr %.spill30, align 64
  %1554 = add <8 x i64> %.spill.load732, zeroinitializer
  %1555 = mul i64 %1553, 2
  %.splatinsert733 = insertelement <8 x i64> poison, i64 %1555, i64 0
  %.splat734 = shufflevector <8 x i64> %.splatinsert733, <8 x i64> poison, <8 x i32> zeroinitializer
  %1556 = add <8 x i64> %.splat734, %1554
  %.spill.load735 = load i64, ptr %.spill37, align 4
  %1557 = add i64 %.spill.load735, %1552
  %1558 = mul <8 x i64> %1556, splat (i64 2053)
  %.splatinsert736 = insertelement <8 x i64> poison, i64 %1557, i64 0
  %.splat737 = shufflevector <8 x i64> %.splatinsert736, <8 x i64> poison, <8 x i32> zeroinitializer
  %1559 = add <8 x i64> %1558, %.splat737
  %1560 = icmp sge i64 %1557, 0
  %1561 = and i1 true, %1560
  %1562 = icmp slt i64 %1557, 2053
  %1563 = and i1 %1561, %1562
  %1564 = add i64 0, %1551
  %1565 = mul <8 x i64> %1559, splat (i64 96)
  %.splatinsert738 = insertelement <8 x i64> poison, i64 %1564, i64 0
  %.splat739 = shufflevector <8 x i64> %.splatinsert738, <8 x i64> poison, <8 x i32> zeroinitializer
  %1566 = add <8 x i64> %1565, %.splat739
  %1567 = load <8 x i64>, ptr %.spill117, align 64
  %1568 = select <8 x i1> %71, <8 x i64> %1566, <8 x i64> %1567
  store <8 x i64> %1568, ptr %.spill117, align 64
  br i1 %1563, label %direct.true740, label %direct.false741

direct.schedule.43:                               ; preds = %direct.true740
  %.spill.load742 = load <8 x i64>, ptr %.spill117, align 64
  %1569 = extractvalue { ptr, i64 } %41, 0
  %1570 = mul <8 x i64> %.spill.load742, splat (i64 4)
  %1571 = getelementptr i8, ptr %1569, <8 x i64> %1570
  %1572 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1571, <8 x i1> %71, <8 x float> zeroinitializer)
  %1573 = load <8 x float>, ptr %.slot118, align 32
  %1574 = select <8 x i1> %71, <8 x float> %1572, <8 x float> %1573
  store <8 x float> %1574, ptr %.slot118, align 32
  br label %direct.schedule.44

direct.schedule.44:                               ; preds = %direct.schedule.43, %direct.false741
  %tile_snapshot.spill.load743 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %1575 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load743, 0
  %1576 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load743, 1
  %.state744 = load i64, ptr %.slot116, align 4
  %.splatinsert745 = insertelement <8 x i64> poison, i64 %.state744, i64 0
  %.splat746 = shufflevector <8 x i64> %.splatinsert745, <8 x i64> poison, <8 x i32> zeroinitializer
  %1577 = mul <8 x i64> %.splat746, splat (i64 32)
  %1578 = add <8 x i64> %1576, %1577
  %1579 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1575, 0
  %1580 = insertvalue { <8 x ptr>, <8 x i64> } %1579, <8 x i64> %1578, 1
  %.state747 = load <8 x float>, ptr %.slot118, align 32
  %1581 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1582 = extractvalue { <8 x ptr>, <8 x i64> } %1580, 1
  %1583 = extractelement <8 x ptr> %1581, i32 0
  %1584 = extractelement <8 x i64> %1582, i32 0
  %1585 = sub i64 %1584, 0
  %1586 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1587 = select i1 %1586, i64 %1585, i64 0
  %private.contiguous.address748 = getelementptr i8, ptr %1583, i64 %1587
  %private.contiguous.preserve749 = load <8 x float>, ptr %private.contiguous.address748, align 4
  %1588 = select <8 x i1> %71, <8 x float> %.state747, <8 x float> %private.contiguous.preserve749
  store <8 x float> %1588, ptr %private.contiguous.address748, align 4
  %.state750 = load i64, ptr %.slot116, align 4
  %1589 = add i64 %.state750, 1
  store i64 %1589, ptr %.slot116, align 4
  br label %direct.schedule.41

direct.schedule.45:                               ; preds = %direct.false156
  store i64 0, ptr %.slot119, align 4
  br label %direct.schedule.46

direct.schedule.46:                               ; preds = %direct.schedule.49, %direct.schedule.45
  %.state751 = load i64, ptr %.slot119, align 4
  %1590 = icmp slt i64 %.state751, 1280
  br i1 %1590, label %direct.true752, label %direct.false753

direct.schedule.47:                               ; preds = %direct.true752
  %.state754 = load i64, ptr %.slot119, align 4
  %1591 = srem i64 %.state754, 80
  %.state755 = load i64, ptr %.slot119, align 4
  %1592 = sdiv i64 %.state755, 80
  %.spill.load756 = load i64, ptr %.spill29, align 4
  %1593 = add i64 %.spill.load756, 0
  %.spill.load757 = load <8 x i64>, ptr %.spill30, align 64
  %1594 = add <8 x i64> %.spill.load757, zeroinitializer
  %1595 = mul i64 %1593, 2
  %.splatinsert758 = insertelement <8 x i64> poison, i64 %1595, i64 0
  %.splat759 = shufflevector <8 x i64> %.splatinsert758, <8 x i64> poison, <8 x i32> zeroinitializer
  %1596 = add <8 x i64> %.splat759, %1594
  %.spill.load760 = load i64, ptr %.spill37, align 4
  %1597 = add i64 %.spill.load760, %1592
  %1598 = mul <8 x i64> %1596, splat (i64 2053)
  %.splatinsert761 = insertelement <8 x i64> poison, i64 %1597, i64 0
  %.splat762 = shufflevector <8 x i64> %.splatinsert761, <8 x i64> poison, <8 x i32> zeroinitializer
  %1599 = add <8 x i64> %1598, %.splat762
  %1600 = icmp sge i64 %1597, 0
  %1601 = and i1 true, %1600
  %1602 = icmp slt i64 %1597, 2053
  %1603 = and i1 %1601, %1602
  %1604 = add i64 0, %1591
  %1605 = mul <8 x i64> %1599, splat (i64 80)
  %.splatinsert763 = insertelement <8 x i64> poison, i64 %1604, i64 0
  %.splat764 = shufflevector <8 x i64> %.splatinsert763, <8 x i64> poison, <8 x i32> zeroinitializer
  %1606 = add <8 x i64> %1605, %.splat764
  %1607 = load <8 x i64>, ptr %.spill120, align 64
  %1608 = select <8 x i1> %71, <8 x i64> %1606, <8 x i64> %1607
  store <8 x i64> %1608, ptr %.spill120, align 64
  br i1 %1603, label %direct.true765, label %direct.false766

direct.schedule.48:                               ; preds = %direct.true765
  %.spill.load767 = load <8 x i64>, ptr %.spill120, align 64
  %1609 = extractvalue { ptr, i64 } %35, 0
  %1610 = mul <8 x i64> %.spill.load767, splat (i64 4)
  %1611 = getelementptr i8, ptr %1609, <8 x i64> %1610
  %1612 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1611, <8 x i1> %71, <8 x float> zeroinitializer)
  %1613 = load <8 x float>, ptr %.slot121, align 32
  %1614 = select <8 x i1> %71, <8 x float> %1612, <8 x float> %1613
  store <8 x float> %1614, ptr %.slot121, align 32
  br label %direct.schedule.49

direct.schedule.49:                               ; preds = %direct.schedule.48, %direct.false766
  %tile_snapshot.spill.load768 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %1615 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load768, 0
  %1616 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load768, 1
  %.state769 = load i64, ptr %.slot119, align 4
  %.splatinsert770 = insertelement <8 x i64> poison, i64 %.state769, i64 0
  %.splat771 = shufflevector <8 x i64> %.splatinsert770, <8 x i64> poison, <8 x i32> zeroinitializer
  %1617 = mul <8 x i64> %.splat771, splat (i64 32)
  %1618 = add <8 x i64> %1616, %1617
  %1619 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1615, 0
  %1620 = insertvalue { <8 x ptr>, <8 x i64> } %1619, <8 x i64> %1618, 1
  %.state772 = load <8 x float>, ptr %.slot121, align 32
  %1621 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1622 = extractvalue { <8 x ptr>, <8 x i64> } %1620, 1
  %1623 = extractelement <8 x ptr> %1621, i32 0
  %1624 = extractelement <8 x i64> %1622, i32 0
  %1625 = sub i64 %1624, 0
  %1626 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1627 = select i1 %1626, i64 %1625, i64 0
  %private.contiguous.address773 = getelementptr i8, ptr %1623, i64 %1627
  %private.contiguous.preserve774 = load <8 x float>, ptr %private.contiguous.address773, align 4
  %1628 = select <8 x i1> %71, <8 x float> %.state772, <8 x float> %private.contiguous.preserve774
  store <8 x float> %1628, ptr %private.contiguous.address773, align 4
  %.state775 = load i64, ptr %.slot119, align 4
  %1629 = add i64 %.state775, 1
  store i64 %1629, ptr %.slot119, align 4
  br label %direct.schedule.46

direct.schedule.50:                               ; preds = %direct.false153
  store i64 0, ptr %.slot122, align 4
  br label %direct.schedule.51

direct.schedule.51:                               ; preds = %direct.schedule.52, %direct.schedule.50
  %.state776 = load i64, ptr %.slot122, align 4
  %1630 = icmp slt i64 %.state776, 96
  br i1 %1630, label %direct.true777, label %direct.false778

direct.schedule.52:                               ; preds = %direct.true777
  %.spill.load779 = load i64, ptr %.spill29, align 4
  %1631 = add i64 %.spill.load779, 0
  %.spill.load780 = load <8 x i64>, ptr %.spill, align 64
  %1632 = add <8 x i64> %.spill.load780, zeroinitializer
  %1633 = mul i64 %1631, 8
  %.splatinsert781 = insertelement <8 x i64> poison, i64 %1633, i64 0
  %.splat782 = shufflevector <8 x i64> %.splatinsert781, <8 x i64> poison, <8 x i32> zeroinitializer
  %1634 = add <8 x i64> %.splat782, %1632
  %1635 = mul <8 x i64> %1634, splat (i64 1)
  %.spill.load783 = load i64, ptr %.spill31, align 4
  %.splatinsert784 = insertelement <8 x i64> poison, i64 %.spill.load783, i64 0
  %.splat785 = shufflevector <8 x i64> %.splatinsert784, <8 x i64> poison, <8 x i32> zeroinitializer
  %1636 = add <8 x i64> %1635, %.splat785
  %.state786 = load i64, ptr %.slot122, align 4
  %1637 = add i64 0, %.state786
  %1638 = mul <8 x i64> %1636, splat (i64 96)
  %.splatinsert787 = insertelement <8 x i64> poison, i64 %1637, i64 0
  %.splat788 = shufflevector <8 x i64> %.splatinsert787, <8 x i64> poison, <8 x i32> zeroinitializer
  %1639 = add <8 x i64> %1638, %.splat788
  %.state789 = load i64, ptr %.slot122, align 4
  %1640 = add i64 0, %.state789
  %tile_snapshot.spill.load790 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1641 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load790, 0
  %1642 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load790, 1
  %.splatinsert791 = insertelement <8 x i64> poison, i64 %1640, i64 0
  %.splat792 = shufflevector <8 x i64> %.splatinsert791, <8 x i64> poison, <8 x i32> zeroinitializer
  %1643 = mul <8 x i64> %.splat792, splat (i64 32)
  %1644 = add <8 x i64> %1642, %1643
  %1645 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1641, 0
  %1646 = insertvalue { <8 x ptr>, <8 x i64> } %1645, <8 x i64> %1644, 1
  %1647 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1648 = extractvalue { <8 x ptr>, <8 x i64> } %1646, 1
  %1649 = extractelement <8 x ptr> %1647, i32 0
  %1650 = extractelement <8 x i64> %1648, i32 0
  %1651 = sub i64 %1650, 0
  %1652 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1653 = select i1 %1652, i64 %1651, i64 0
  %private.contiguous.address793 = getelementptr i8, ptr %1649, i64 %1653
  %private.contiguous.load794 = load <8 x float>, ptr %private.contiguous.address793, align 4
  %1654 = select <8 x i1> %71, <8 x float> %private.contiguous.load794, <8 x float> zeroinitializer
  %.state795 = load <8 x float>, ptr %.slot36, align 32
  %1655 = fdiv <8 x float> %1654, %.state795
  %1656 = extractvalue { ptr, i64 } %47, 0
  %1657 = mul <8 x i64> %1639, splat (i64 4)
  %1658 = getelementptr i8, ptr %1656, <8 x i64> %1657
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1655, <8 x ptr> align 1 %1658, <8 x i1> %71)
  %.state796 = load i64, ptr %.slot122, align 4
  %1659 = add i64 %.state796, 1
  store i64 %1659, ptr %.slot122, align 4
  br label %direct.schedule.51

direct.schedule.53:                               ; preds = %direct.false778
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

copy.active:                                      ; preds = %direct.schedule.0
  %1660 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1661 = extractelement <8 x ptr> %1660, i64 0
  %1662 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1663 = extractelement <8 x i64> %1662, i64 0
  %1664 = getelementptr i8, ptr %1661, i64 %1663
  %1665 = extractelement <8 x i64> %98, i64 0
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1665, ptr %1664)
  br label %copy.continue

copy.continue:                                    ; preds = %copy.active, %direct.schedule.0
  %1666 = extractelement <8 x i1> %71, i64 1
  br i1 %1666, label %copy.active133, label %copy.continue134

copy.active133:                                   ; preds = %copy.continue
  %1667 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1668 = extractelement <8 x ptr> %1667, i64 1
  %1669 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1670 = extractelement <8 x i64> %1669, i64 1
  %1671 = getelementptr i8, ptr %1668, i64 %1670
  %1672 = extractelement <8 x i64> %98, i64 1
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1672, ptr %1671)
  br label %copy.continue134

copy.continue134:                                 ; preds = %copy.active133, %copy.continue
  %1673 = extractelement <8 x i1> %71, i64 2
  br i1 %1673, label %copy.active135, label %copy.continue136

copy.active135:                                   ; preds = %copy.continue134
  %1674 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1675 = extractelement <8 x ptr> %1674, i64 2
  %1676 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1677 = extractelement <8 x i64> %1676, i64 2
  %1678 = getelementptr i8, ptr %1675, i64 %1677
  %1679 = extractelement <8 x i64> %98, i64 2
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1679, ptr %1678)
  br label %copy.continue136

copy.continue136:                                 ; preds = %copy.active135, %copy.continue134
  %1680 = extractelement <8 x i1> %71, i64 3
  br i1 %1680, label %copy.active137, label %copy.continue138

copy.active137:                                   ; preds = %copy.continue136
  %1681 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1682 = extractelement <8 x ptr> %1681, i64 3
  %1683 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1684 = extractelement <8 x i64> %1683, i64 3
  %1685 = getelementptr i8, ptr %1682, i64 %1684
  %1686 = extractelement <8 x i64> %98, i64 3
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1686, ptr %1685)
  br label %copy.continue138

copy.continue138:                                 ; preds = %copy.active137, %copy.continue136
  %1687 = extractelement <8 x i1> %71, i64 4
  br i1 %1687, label %copy.active139, label %copy.continue140

copy.active139:                                   ; preds = %copy.continue138
  %1688 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1689 = extractelement <8 x ptr> %1688, i64 4
  %1690 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1691 = extractelement <8 x i64> %1690, i64 4
  %1692 = getelementptr i8, ptr %1689, i64 %1691
  %1693 = extractelement <8 x i64> %98, i64 4
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1693, ptr %1692)
  br label %copy.continue140

copy.continue140:                                 ; preds = %copy.active139, %copy.continue138
  %1694 = extractelement <8 x i1> %71, i64 5
  br i1 %1694, label %copy.active141, label %copy.continue142

copy.active141:                                   ; preds = %copy.continue140
  %1695 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1696 = extractelement <8 x ptr> %1695, i64 5
  %1697 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1698 = extractelement <8 x i64> %1697, i64 5
  %1699 = getelementptr i8, ptr %1696, i64 %1698
  %1700 = extractelement <8 x i64> %98, i64 5
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1700, ptr %1699)
  br label %copy.continue142

copy.continue142:                                 ; preds = %copy.active141, %copy.continue140
  %1701 = extractelement <8 x i1> %71, i64 6
  br i1 %1701, label %copy.active143, label %copy.continue144

copy.active143:                                   ; preds = %copy.continue142
  %1702 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1703 = extractelement <8 x ptr> %1702, i64 6
  %1704 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1705 = extractelement <8 x i64> %1704, i64 6
  %1706 = getelementptr i8, ptr %1703, i64 %1705
  %1707 = extractelement <8 x i64> %98, i64 6
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1707, ptr %1706)
  br label %copy.continue144

copy.continue144:                                 ; preds = %copy.active143, %copy.continue142
  %1708 = extractelement <8 x i1> %71, i64 7
  br i1 %1708, label %copy.active145, label %copy.continue146

copy.active145:                                   ; preds = %copy.continue144
  %1709 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1710 = extractelement <8 x ptr> %1709, i64 7
  %1711 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1712 = extractelement <8 x i64> %1711, i64 7
  %1713 = getelementptr i8, ptr %1710, i64 %1712
  %1714 = extractelement <8 x i64> %98, i64 7
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1714, ptr %1713)
  br label %copy.continue146

copy.continue146:                                 ; preds = %copy.active145, %copy.continue144
  %1715 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1716 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1717 = extractvalue { <8 x ptr>, <8 x i64> } %1715, 0
  %1718 = select <8 x i1> %71, <8 x ptr> %1716, <8 x ptr> %1717
  %1719 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1720 = extractvalue { <8 x ptr>, <8 x i64> } %1715, 1
  %1721 = select <8 x i1> %71, <8 x i64> %1719, <8 x i64> %1720
  %1722 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1718, 0
  %1723 = insertvalue { <8 x ptr>, <8 x i64> } %1722, <8 x i64> %1721, 1
  store { <8 x ptr>, <8 x i64> } %1723, ptr %tile_snapshot.spill32, align 64
  %1724 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill33, align 64
  %1725 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1726 = extractvalue { <8 x ptr>, <8 x i64> } %1724, 0
  %1727 = select <8 x i1> %71, <8 x ptr> %1725, <8 x ptr> %1726
  %1728 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %1729 = extractvalue { <8 x ptr>, <8 x i64> } %1724, 1
  %1730 = select <8 x i1> %71, <8 x i64> %1728, <8 x i64> %1729
  %1731 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1727, 0
  %1732 = insertvalue { <8 x ptr>, <8 x i64> } %1731, <8 x i64> %1730, 1
  store { <8 x ptr>, <8 x i64> } %1732, ptr %tile_snapshot.spill33, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true152:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false153:                                  ; preds = %direct.schedule.4
  br label %direct.schedule.50

direct.true155:                                   ; preds = %direct.schedule.5
  br label %direct.schedule.6

direct.false156:                                  ; preds = %direct.schedule.5
  br label %direct.schedule.45

copy.active164:                                   ; preds = %direct.schedule.6
  %1733 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1734 = extractelement <8 x ptr> %1733, i64 0
  %1735 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1736 = extractelement <8 x i64> %1735, i64 0
  %1737 = getelementptr i8, ptr %1734, i64 %1736
  %1738 = extractelement <8 x i64> %142, i64 0
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1738, ptr %1737)
  br label %copy.continue165

copy.continue165:                                 ; preds = %copy.active164, %direct.schedule.6
  %1739 = extractelement <8 x i1> %71, i64 1
  br i1 %1739, label %copy.active166, label %copy.continue167

copy.active166:                                   ; preds = %copy.continue165
  %1740 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1741 = extractelement <8 x ptr> %1740, i64 1
  %1742 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1743 = extractelement <8 x i64> %1742, i64 1
  %1744 = getelementptr i8, ptr %1741, i64 %1743
  %1745 = extractelement <8 x i64> %142, i64 1
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1745, ptr %1744)
  br label %copy.continue167

copy.continue167:                                 ; preds = %copy.active166, %copy.continue165
  %1746 = extractelement <8 x i1> %71, i64 2
  br i1 %1746, label %copy.active168, label %copy.continue169

copy.active168:                                   ; preds = %copy.continue167
  %1747 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1748 = extractelement <8 x ptr> %1747, i64 2
  %1749 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1750 = extractelement <8 x i64> %1749, i64 2
  %1751 = getelementptr i8, ptr %1748, i64 %1750
  %1752 = extractelement <8 x i64> %142, i64 2
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1752, ptr %1751)
  br label %copy.continue169

copy.continue169:                                 ; preds = %copy.active168, %copy.continue167
  %1753 = extractelement <8 x i1> %71, i64 3
  br i1 %1753, label %copy.active170, label %copy.continue171

copy.active170:                                   ; preds = %copy.continue169
  %1754 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1755 = extractelement <8 x ptr> %1754, i64 3
  %1756 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1757 = extractelement <8 x i64> %1756, i64 3
  %1758 = getelementptr i8, ptr %1755, i64 %1757
  %1759 = extractelement <8 x i64> %142, i64 3
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1759, ptr %1758)
  br label %copy.continue171

copy.continue171:                                 ; preds = %copy.active170, %copy.continue169
  %1760 = extractelement <8 x i1> %71, i64 4
  br i1 %1760, label %copy.active172, label %copy.continue173

copy.active172:                                   ; preds = %copy.continue171
  %1761 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1762 = extractelement <8 x ptr> %1761, i64 4
  %1763 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1764 = extractelement <8 x i64> %1763, i64 4
  %1765 = getelementptr i8, ptr %1762, i64 %1764
  %1766 = extractelement <8 x i64> %142, i64 4
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1766, ptr %1765)
  br label %copy.continue173

copy.continue173:                                 ; preds = %copy.active172, %copy.continue171
  %1767 = extractelement <8 x i1> %71, i64 5
  br i1 %1767, label %copy.active174, label %copy.continue175

copy.active174:                                   ; preds = %copy.continue173
  %1768 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1769 = extractelement <8 x ptr> %1768, i64 5
  %1770 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1771 = extractelement <8 x i64> %1770, i64 5
  %1772 = getelementptr i8, ptr %1769, i64 %1771
  %1773 = extractelement <8 x i64> %142, i64 5
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1773, ptr %1772)
  br label %copy.continue175

copy.continue175:                                 ; preds = %copy.active174, %copy.continue173
  %1774 = extractelement <8 x i1> %71, i64 6
  br i1 %1774, label %copy.active176, label %copy.continue177

copy.active176:                                   ; preds = %copy.continue175
  %1775 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1776 = extractelement <8 x ptr> %1775, i64 6
  %1777 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1778 = extractelement <8 x i64> %1777, i64 6
  %1779 = getelementptr i8, ptr %1776, i64 %1778
  %1780 = extractelement <8 x i64> %142, i64 6
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1780, ptr %1779)
  br label %copy.continue177

copy.continue177:                                 ; preds = %copy.active176, %copy.continue175
  %1781 = extractelement <8 x i1> %71, i64 7
  br i1 %1781, label %copy.active178, label %copy.continue179

copy.active178:                                   ; preds = %copy.continue177
  %1782 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1783 = extractelement <8 x ptr> %1782, i64 7
  %1784 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1785 = extractelement <8 x i64> %1784, i64 7
  %1786 = getelementptr i8, ptr %1783, i64 %1785
  %1787 = extractelement <8 x i64> %142, i64 7
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1787, ptr %1786)
  br label %copy.continue179

copy.continue179:                                 ; preds = %copy.active178, %copy.continue177
  br label %direct.schedule.7

direct.true181:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false182:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.40

copy.active191:                                   ; preds = %direct.schedule.8
  %1788 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1789 = extractelement <8 x ptr> %1788, i64 0
  %1790 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1791 = extractelement <8 x i64> %1790, i64 0
  %1792 = getelementptr i8, ptr %1789, i64 %1791
  %1793 = extractelement <8 x i64> %159, i64 0
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1793, ptr %1792)
  br label %copy.continue192

copy.continue192:                                 ; preds = %copy.active191, %direct.schedule.8
  %1794 = extractelement <8 x i1> %71, i64 1
  br i1 %1794, label %copy.active193, label %copy.continue194

copy.active193:                                   ; preds = %copy.continue192
  %1795 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1796 = extractelement <8 x ptr> %1795, i64 1
  %1797 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1798 = extractelement <8 x i64> %1797, i64 1
  %1799 = getelementptr i8, ptr %1796, i64 %1798
  %1800 = extractelement <8 x i64> %159, i64 1
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1800, ptr %1799)
  br label %copy.continue194

copy.continue194:                                 ; preds = %copy.active193, %copy.continue192
  %1801 = extractelement <8 x i1> %71, i64 2
  br i1 %1801, label %copy.active195, label %copy.continue196

copy.active195:                                   ; preds = %copy.continue194
  %1802 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1803 = extractelement <8 x ptr> %1802, i64 2
  %1804 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1805 = extractelement <8 x i64> %1804, i64 2
  %1806 = getelementptr i8, ptr %1803, i64 %1805
  %1807 = extractelement <8 x i64> %159, i64 2
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1807, ptr %1806)
  br label %copy.continue196

copy.continue196:                                 ; preds = %copy.active195, %copy.continue194
  %1808 = extractelement <8 x i1> %71, i64 3
  br i1 %1808, label %copy.active197, label %copy.continue198

copy.active197:                                   ; preds = %copy.continue196
  %1809 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1810 = extractelement <8 x ptr> %1809, i64 3
  %1811 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1812 = extractelement <8 x i64> %1811, i64 3
  %1813 = getelementptr i8, ptr %1810, i64 %1812
  %1814 = extractelement <8 x i64> %159, i64 3
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1814, ptr %1813)
  br label %copy.continue198

copy.continue198:                                 ; preds = %copy.active197, %copy.continue196
  %1815 = extractelement <8 x i1> %71, i64 4
  br i1 %1815, label %copy.active199, label %copy.continue200

copy.active199:                                   ; preds = %copy.continue198
  %1816 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1817 = extractelement <8 x ptr> %1816, i64 4
  %1818 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1819 = extractelement <8 x i64> %1818, i64 4
  %1820 = getelementptr i8, ptr %1817, i64 %1819
  %1821 = extractelement <8 x i64> %159, i64 4
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1821, ptr %1820)
  br label %copy.continue200

copy.continue200:                                 ; preds = %copy.active199, %copy.continue198
  %1822 = extractelement <8 x i1> %71, i64 5
  br i1 %1822, label %copy.active201, label %copy.continue202

copy.active201:                                   ; preds = %copy.continue200
  %1823 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1824 = extractelement <8 x ptr> %1823, i64 5
  %1825 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1826 = extractelement <8 x i64> %1825, i64 5
  %1827 = getelementptr i8, ptr %1824, i64 %1826
  %1828 = extractelement <8 x i64> %159, i64 5
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1828, ptr %1827)
  br label %copy.continue202

copy.continue202:                                 ; preds = %copy.active201, %copy.continue200
  %1829 = extractelement <8 x i1> %71, i64 6
  br i1 %1829, label %copy.active203, label %copy.continue204

copy.active203:                                   ; preds = %copy.continue202
  %1830 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1831 = extractelement <8 x ptr> %1830, i64 6
  %1832 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1833 = extractelement <8 x i64> %1832, i64 6
  %1834 = getelementptr i8, ptr %1831, i64 %1833
  %1835 = extractelement <8 x i64> %159, i64 6
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1835, ptr %1834)
  br label %copy.continue204

copy.continue204:                                 ; preds = %copy.active203, %copy.continue202
  %1836 = extractelement <8 x i1> %71, i64 7
  br i1 %1836, label %copy.active205, label %copy.continue206

copy.active205:                                   ; preds = %copy.continue204
  %1837 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1838 = extractelement <8 x ptr> %1837, i64 7
  %1839 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1840 = extractelement <8 x i64> %1839, i64 7
  %1841 = getelementptr i8, ptr %1838, i64 %1840
  %1842 = extractelement <8 x i64> %159, i64 7
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1842, ptr %1841)
  br label %copy.continue206

copy.continue206:                                 ; preds = %copy.active205, %copy.continue204
  br label %direct.schedule.9

direct.true208:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false209:                                  ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true244:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false245:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true282:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false283:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true320:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false321:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true455:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false456:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24

direct.true583:                                   ; preds = %direct.schedule.25
  br label %direct.schedule.26

direct.false584:                                  ; preds = %direct.schedule.25
  br label %direct.schedule.27

direct.true597:                                   ; preds = %direct.schedule.28
  br label %direct.schedule.29

direct.false598:                                  ; preds = %direct.schedule.28
  br label %direct.schedule.33

direct.true625:                                   ; preds = %direct.schedule.30
  br label %direct.schedule.31

direct.false626:                                  ; preds = %direct.schedule.30
  br label %direct.schedule.32

direct.true692:                                   ; preds = %direct.schedule.34
  br label %direct.schedule.35

direct.false693:                                  ; preds = %direct.schedule.34
  br label %direct.schedule.36

direct.true708:                                   ; preds = %direct.schedule.37
  br label %direct.schedule.38

direct.false709:                                  ; preds = %direct.schedule.37
  br label %direct.schedule.39

direct.true727:                                   ; preds = %direct.schedule.41
  br label %direct.schedule.42

direct.false728:                                  ; preds = %direct.schedule.41
  br label %direct.schedule.9

direct.true740:                                   ; preds = %direct.schedule.42
  br label %direct.schedule.43

direct.false741:                                  ; preds = %direct.schedule.42
  %1843 = load <8 x float>, ptr %.slot118, align 32
  %1844 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1843
  store <8 x float> %1844, ptr %.slot118, align 32
  br label %direct.schedule.44

direct.true752:                                   ; preds = %direct.schedule.46
  br label %direct.schedule.47

direct.false753:                                  ; preds = %direct.schedule.46
  br label %direct.schedule.7

direct.true765:                                   ; preds = %direct.schedule.47
  br label %direct.schedule.48

direct.false766:                                  ; preds = %direct.schedule.47
  %1845 = load <8 x float>, ptr %.slot121, align 32
  %1846 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1845
  store <8 x float> %1846, ptr %.slot121, align 32
  br label %direct.schedule.49

direct.true777:                                   ; preds = %direct.schedule.51
  br label %direct.schedule.52

direct.false778:                                  ; preds = %direct.schedule.51
  br label %direct.schedule.53
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nounwind willreturn
define private void @llm_attention.contiguous_copy(ptr %0, i64 %1, ptr %2) #1 {
entry:
  %3 = getelementptr i32, ptr %0, i64 %1
  br label %copy.loop

copy.loop:                                        ; preds = %copy.chunk, %entry
  %copy.index = phi i64 [ 0, %entry ], [ %25, %copy.chunk ]
  %4 = icmp ult i64 %copy.index, 20
  br i1 %4, label %copy.chunk, label %copy.next

copy.chunk:                                       ; preds = %copy.loop
  %5 = mul i64 %copy.index, 4
  %6 = add i64 0, %5
  %7 = getelementptr i32, ptr %3, i64 %6
  %8 = load <4 x i32>, ptr %7, align 4
  %9 = add i64 %6, 0
  %10 = mul i64 %9, 8
  %11 = getelementptr i32, ptr %2, i64 %10
  %12 = extractelement <4 x i32> %8, i64 0
  store i32 %12, ptr %11, align 4
  %13 = add i64 %6, 1
  %14 = mul i64 %13, 8
  %15 = getelementptr i32, ptr %2, i64 %14
  %16 = extractelement <4 x i32> %8, i64 1
  store i32 %16, ptr %15, align 4
  %17 = add i64 %6, 2
  %18 = mul i64 %17, 8
  %19 = getelementptr i32, ptr %2, i64 %18
  %20 = extractelement <4 x i32> %8, i64 2
  store i32 %20, ptr %19, align 4
  %21 = add i64 %6, 3
  %22 = mul i64 %21, 8
  %23 = getelementptr i32, ptr %2, i64 %22
  %24 = extractelement <4 x i32> %8, i64 3
  store i32 %24, ptr %23, align 4
  %25 = add i64 %copy.index, 1
  br label %copy.loop

copy.next:                                        ; preds = %copy.loop
  ret void
}

; Function Attrs: nounwind willreturn
define private void @llm_attention.contiguous_copy.1(ptr %0, i64 %1, ptr %2) #1 {
entry:
  %3 = getelementptr i32, ptr %0, i64 %1
  br label %copy.loop

copy.loop:                                        ; preds = %copy.chunk, %entry
  %copy.index = phi i64 [ 0, %entry ], [ %25, %copy.chunk ]
  %4 = icmp ult i64 %copy.index, 320
  br i1 %4, label %copy.chunk, label %copy.next

copy.chunk:                                       ; preds = %copy.loop
  %5 = mul i64 %copy.index, 4
  %6 = add i64 0, %5
  %7 = getelementptr i32, ptr %3, i64 %6
  %8 = load <4 x i32>, ptr %7, align 4
  %9 = add i64 %6, 0
  %10 = mul i64 %9, 8
  %11 = getelementptr i32, ptr %2, i64 %10
  %12 = extractelement <4 x i32> %8, i64 0
  store i32 %12, ptr %11, align 4
  %13 = add i64 %6, 1
  %14 = mul i64 %13, 8
  %15 = getelementptr i32, ptr %2, i64 %14
  %16 = extractelement <4 x i32> %8, i64 1
  store i32 %16, ptr %15, align 4
  %17 = add i64 %6, 2
  %18 = mul i64 %17, 8
  %19 = getelementptr i32, ptr %2, i64 %18
  %20 = extractelement <4 x i32> %8, i64 2
  store i32 %20, ptr %19, align 4
  %21 = add i64 %6, 3
  %22 = mul i64 %21, 8
  %23 = getelementptr i32, ptr %2, i64 %22
  %24 = extractelement <4 x i32> %8, i64 3
  store i32 %24, ptr %23, align 4
  %25 = add i64 %copy.index, 1
  br label %copy.loop

copy.next:                                        ; preds = %copy.loop
  ret void
}

; Function Attrs: nounwind willreturn
define private void @llm_attention.contiguous_copy.2(ptr %0, i64 %1, ptr %2) #1 {
entry:
  %3 = getelementptr i32, ptr %0, i64 %1
  br label %copy.loop

copy.loop:                                        ; preds = %copy.chunk, %entry
  %copy.index = phi i64 [ 0, %entry ], [ %25, %copy.chunk ]
  %4 = icmp ult i64 %copy.index, 384
  br i1 %4, label %copy.chunk, label %copy.next

copy.chunk:                                       ; preds = %copy.loop
  %5 = mul i64 %copy.index, 4
  %6 = add i64 0, %5
  %7 = getelementptr i32, ptr %3, i64 %6
  %8 = load <4 x i32>, ptr %7, align 4
  %9 = add i64 %6, 0
  %10 = mul i64 %9, 8
  %11 = getelementptr i32, ptr %2, i64 %10
  %12 = extractelement <4 x i32> %8, i64 0
  store i32 %12, ptr %11, align 4
  %13 = add i64 %6, 1
  %14 = mul i64 %13, 8
  %15 = getelementptr i32, ptr %2, i64 %14
  %16 = extractelement <4 x i32> %8, i64 1
  store i32 %16, ptr %15, align 4
  %17 = add i64 %6, 2
  %18 = mul i64 %17, 8
  %19 = getelementptr i32, ptr %2, i64 %18
  %20 = extractelement <4 x i32> %8, i64 2
  store i32 %20, ptr %19, align 4
  %21 = add i64 %6, 3
  %22 = mul i64 %21, 8
  %23 = getelementptr i32, ptr %2, i64 %22
  %24 = extractelement <4 x i32> %8, i64 3
  store i32 %24, ptr %23, align 4
  %25 = add i64 %copy.index, 1
  br label %copy.loop

copy.next:                                        ; preds = %copy.loop
  ret void
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #2

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #3 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #4

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #5

define internal void @llm_attention.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 2560
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 5632
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 8704
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 49664
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 98816
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 99328
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 99840
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill29 = alloca i64, align 8
  store i64 0, ptr %.spill29, align 4
  %.spill30 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill30, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.spill31 = alloca i64, align 8
  store i64 0, ptr %.spill31, align 4
  %tile_snapshot.spill32 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill32, align 64
  %tile_snapshot.spill33 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill33, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.slot34 = alloca i64, align 8
  store i64 0, ptr %.slot34, align 4
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.slot36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot36, align 32
  %.spill37 = alloca i64, align 8
  store i64 0, ptr %.spill37, align 4
  %tile_snapshot.spill38 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill38, align 64
  %.spill39 = alloca i1, align 1
  store i1 false, ptr %.spill39, align 1
  %tile_snapshot.spill40 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill40, align 64
  %.slot41 = alloca i64, align 8
  store i64 0, ptr %.slot41, align 4
  %.slot42 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot42, align 32
  %.slot43 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot43, align 32
  %.slot44 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot44, align 32
  %.slot45 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot45, align 32
  %.slot46 = alloca i64, align 8
  store i64 0, ptr %.slot46, align 4
  %.slot47 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot47, align 32
  %.slot48 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot48, align 32
  %.slot49 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot49, align 32
  %.slot50 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot50, align 32
  %.slot51 = alloca i64, align 8
  store i64 0, ptr %.slot51, align 4
  %.slot52 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot52, align 32
  %.slot53 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot53, align 32
  %.slot54 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot54, align 32
  %.slot55 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot55, align 32
  %.slot56 = alloca i64, align 8
  store i64 0, ptr %.slot56, align 4
  %.slot57 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot57, align 32
  %.slot58 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot58, align 32
  %.slot59 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot59, align 32
  %.slot60 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot60, align 32
  %.spill61 = alloca i1, align 1
  store i1 false, ptr %.spill61, align 1
  %.spill62 = alloca i1, align 1
  store i1 false, ptr %.spill62, align 1
  %.spill63 = alloca i1, align 1
  store i1 false, ptr %.spill63, align 1
  %.spill64 = alloca i1, align 1
  store i1 false, ptr %.spill64, align 1
  %.spill65 = alloca i1, align 1
  store i1 false, ptr %.spill65, align 1
  %.spill66 = alloca i1, align 1
  store i1 false, ptr %.spill66, align 1
  %.spill67 = alloca i1, align 1
  store i1 false, ptr %.spill67, align 1
  %.spill68 = alloca i1, align 1
  store i1 false, ptr %.spill68, align 1
  %.spill69 = alloca i1, align 1
  store i1 false, ptr %.spill69, align 1
  %.spill70 = alloca i1, align 1
  store i1 false, ptr %.spill70, align 1
  %.spill71 = alloca i1, align 1
  store i1 false, ptr %.spill71, align 1
  %.spill72 = alloca i1, align 1
  store i1 false, ptr %.spill72, align 1
  %.spill73 = alloca i1, align 1
  store i1 false, ptr %.spill73, align 1
  %.spill74 = alloca i1, align 1
  store i1 false, ptr %.spill74, align 1
  %.spill75 = alloca i1, align 1
  store i1 false, ptr %.spill75, align 1
  %.spill76 = alloca i1, align 1
  store i1 false, ptr %.spill76, align 1
  %.spill77 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill77, align 32
  %.spill78 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill78, align 32
  %.spill79 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill79, align 32
  %.spill80 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill80, align 32
  %.spill81 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill81, align 32
  %.spill82 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill82, align 32
  %.spill83 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill83, align 32
  %.spill84 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill84, align 32
  %.spill85 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill85, align 32
  %.spill86 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill86, align 32
  %.spill87 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill87, align 32
  %.spill88 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill88, align 32
  %.spill89 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill89, align 32
  %.spill90 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill90, align 32
  %.spill91 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill91, align 32
  %.spill92 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill92, align 32
  %tile_snapshot.spill93 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill93, align 64
  %.slot94 = alloca i64, align 8
  store i64 0, ptr %.slot94, align 4
  %.slot95 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot95, align 32
  %.spill96 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill96, align 32
  %.spill97 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill97, align 32
  %tile_snapshot.spill98 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill98, align 64
  %.spill99 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill99, align 32
  %.slot100 = alloca i64, align 8
  store i64 0, ptr %.slot100, align 4
  %.slot101 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot101, align 32
  %.spill102 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill102, align 32
  %tile_snapshot.spill103 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill103, align 64
  %.slot104 = alloca i64, align 8
  store i64 0, ptr %.slot104, align 4
  %.spill105 = alloca i64, align 8
  store i64 0, ptr %.spill105, align 4
  %.spill106 = alloca i64, align 8
  store i64 0, ptr %.spill106, align 4
  %.spill107 = alloca i64, align 8
  store i64 0, ptr %.spill107, align 4
  %.spill108 = alloca i64, align 8
  store i64 0, ptr %.spill108, align 4
  %.slot109 = alloca i64, align 8
  store i64 0, ptr %.slot109, align 4
  %.slot110 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot110, align 32
  %.slot111 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot111, align 32
  %.slot112 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot112, align 32
  %.slot113 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot113, align 32
  %.slot114 = alloca i64, align 8
  store i64 0, ptr %.slot114, align 4
  %.slot115 = alloca i64, align 8
  store i64 0, ptr %.slot115, align 4
  %.slot116 = alloca i64, align 8
  store i64 0, ptr %.slot116, align 4
  %.spill117 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill117, align 64
  %.slot118 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot118, align 32
  %.slot119 = alloca i64, align 8
  store i64 0, ptr %.slot119, align 4
  %.spill120 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill120, align 64
  %.slot121 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot121, align 32
  %.slot122 = alloca i64, align 8
  store i64 0, ptr %.slot122, align 4
  %24 = getelementptr i8, ptr %argument_buffer, i64 0
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = getelementptr i8, ptr %argument_buffer, i64 16
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %30, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %33, 1
  %36 = getelementptr i8, ptr %argument_buffer, i64 32
  %37 = load ptr, ptr %36, align 16
  %38 = getelementptr i8, ptr %36, i64 8
  %39 = load i64, ptr %38, align 8
  %40 = insertvalue { ptr, i64 } poison, ptr %37, 0
  %41 = insertvalue { ptr, i64 } %40, i64 %39, 1
  %42 = getelementptr i8, ptr %argument_buffer, i64 48
  %43 = load ptr, ptr %42, align 16
  %44 = getelementptr i8, ptr %42, i64 8
  %45 = load i64, ptr %44, align 8
  %46 = insertvalue { ptr, i64 } poison, ptr %43, 0
  %47 = insertvalue { ptr, i64 } %46, i64 %45, 1
  %48 = load i32, ptr %launch_config, align 4
  %49 = getelementptr i8, ptr %launch_config, i64 12
  %50 = load i32, ptr %49, align 4
  %51 = getelementptr i8, ptr %launch_config, i64 4
  %52 = load i32, ptr %51, align 4
  %53 = getelementptr i8, ptr %launch_config, i64 16
  %54 = load i32, ptr %53, align 4
  %55 = getelementptr i8, ptr %launch_config, i64 8
  %56 = load i32, ptr %55, align 4
  %57 = getelementptr i8, ptr %launch_config, i64 20
  %58 = load i32, ptr %57, align 4
  %59 = getelementptr i8, ptr %launch_config, i64 36
  %60 = load i32, ptr %59, align 4
  %.splatinsert123 = insertelement <8 x i32> poison, i32 %60, i64 0
  %.splat124 = shufflevector <8 x i32> %.splatinsert123, <8 x i32> poison, <8 x i32> zeroinitializer
  %61 = add <8 x i32> %.splat124, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %62 = mul i32 %48, 32
  %.splatinsert125 = insertelement <8 x i32> poison, i32 %62, i64 0
  %.splat126 = shufflevector <8 x i32> %.splatinsert125, <8 x i32> poison, <8 x i32> zeroinitializer
  %63 = add <8 x i32> %.splat126, %61
  %64 = mul i32 %52, 1
  %.splatinsert127 = insertelement <8 x i32> poison, i32 %64, i64 0
  %.splat128 = shufflevector <8 x i32> %.splatinsert127, <8 x i32> poison, <8 x i32> zeroinitializer
  %65 = add <8 x i32> %.splat128, zeroinitializer
  %66 = mul i32 %56, 1
  %.splatinsert129 = insertelement <8 x i32> poison, i32 %66, i64 0
  %.splat130 = shufflevector <8 x i32> %.splatinsert129, <8 x i32> poison, <8 x i32> zeroinitializer
  %67 = add <8 x i32> %.splat130, zeroinitializer
  %68 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %63, 0
  %69 = insertvalue [3 x <8 x i32>] %68, <8 x i32> %65, 1
  %70 = insertvalue [3 x <8 x i32>] %69, <8 x i32> %67, 2
  %.splatinsert131 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat132 = shufflevector <8 x i32> %.splatinsert131, <8 x i32> poison, <8 x i32> zeroinitializer
  %71 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat132
  %72 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  br i1 %72, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %73 = extractvalue [3 x <8 x i32>] %70, 0
  %74 = zext <8 x i32> %73 to <8 x i64>
  %75 = select <8 x i1> %71, <8 x i64> %74, <8 x i64> zeroinitializer
  %76 = select <8 x i1> %71, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %77 = sdiv <8 x i64> %75, %76
  %78 = load <8 x i64>, ptr %.spill, align 64
  %79 = select <8 x i1> %71, <8 x i64> %77, <8 x i64> %78
  store <8 x i64> %79, ptr %.spill, align 64
  store i64 0, ptr %.spill29, align 4
  %80 = select <8 x i1> %71, <8 x i64> %77, <8 x i64> zeroinitializer
  %81 = select <8 x i1> %71, <8 x i64> splat (i64 4), <8 x i64> splat (i64 1)
  %82 = sdiv <8 x i64> %80, %81
  %83 = load <8 x i64>, ptr %.spill30, align 64
  %84 = select <8 x i1> %71, <8 x i64> %82, <8 x i64> %83
  store <8 x i64> %84, ptr %.spill30, align 64
  %85 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %86 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %85, 0
  %88 = select <8 x i1> %71, <8 x ptr> %86, <8 x ptr> %87
  %89 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %85, 1
  %91 = select <8 x i1> %71, <8 x i64> %89, <8 x i64> %90
  %92 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %88, 0
  %93 = insertvalue { <8 x ptr>, <8 x i64> } %92, <8 x i64> %91, 1
  store { <8 x ptr>, <8 x i64> } %93, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.spill31, align 4
  %94 = add <8 x i64> zeroinitializer, %77
  %95 = mul <8 x i64> %94, splat (i64 1)
  %96 = add <8 x i64> %95, zeroinitializer
  %97 = mul <8 x i64> %96, splat (i64 80)
  %98 = add <8 x i64> %97, zeroinitializer
  %99 = extractvalue { ptr, i64 } %29, 0
  %100 = extractelement <8 x i1> %71, i64 0
  br i1 %100, label %copy.active, label %copy.continue

direct.schedule.1:                                ; preds = %copy.continue146, %direct.schedule.2
  %.state = load i64, ptr %.slot, align 4
  %101 = icmp slt i64 %.state, 96
  br i1 %101, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %102 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %103 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state147 = load i64, ptr %.slot, align 4
  %.splatinsert148 = insertelement <8 x i64> poison, i64 %.state147, i64 0
  %.splat149 = shufflevector <8 x i64> %.splatinsert148, <8 x i64> poison, <8 x i32> zeroinitializer
  %104 = mul <8 x i64> %.splat149, splat (i64 32)
  %105 = add <8 x i64> %103, %104
  %106 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %102, 0
  %107 = insertvalue { <8 x ptr>, <8 x i64> } %106, <8 x i64> %105, 1
  %108 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %107, 1
  %110 = extractelement <8 x ptr> %108, i32 0
  %111 = extractelement <8 x i64> %109, i32 0
  %112 = sub i64 %111, 0
  %113 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %114 = select i1 %113, i64 %112, i64 0
  %private.contiguous.address = getelementptr i8, ptr %110, i64 %114
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %115 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %private.contiguous.preserve
  store <8 x float> %115, ptr %private.contiguous.address, align 4
  %.state150 = load i64, ptr %.slot, align 4
  %116 = add i64 %.state150, 1
  store i64 %116, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store i64 0, ptr %.slot34, align 4
  %117 = load <8 x float>, ptr %.slot35, align 32
  %118 = select <8 x i1> %71, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %117
  store <8 x float> %118, ptr %.slot35, align 32
  %119 = load <8 x float>, ptr %.slot36, align 32
  %120 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %119
  store <8 x float> %120, ptr %.slot36, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.39, %direct.schedule.3
  %.state151 = load i64, ptr %.slot34, align 4
  %121 = icmp slt i64 %.state151, 129
  br i1 %121, label %direct.true152, label %direct.false153

direct.schedule.5:                                ; preds = %direct.true152
  %.state154 = load i64, ptr %.slot34, align 4
  %122 = sdiv i64 %.state154, 1
  %123 = mul i64 %122, 16
  store i64 %123, ptr %.spill37, align 4
  %124 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %124, 0
  %127 = select <8 x i1> %71, <8 x ptr> %125, <8 x ptr> %126
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %124, 1
  %130 = select <8 x i1> %71, <8 x i64> %128, <8 x i64> %129
  %131 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %127, 0
  %132 = insertvalue { <8 x ptr>, <8 x i64> } %131, <8 x i64> %130, 1
  store { <8 x ptr>, <8 x i64> } %132, ptr %tile_snapshot.spill38, align 64
  %133 = icmp sge i64 %123, 0
  %134 = and i1 true, %133
  %135 = icmp sle i64 %123, 2037
  %136 = and i1 %134, %135
  store i1 %136, ptr %.spill39, align 1
  br i1 %136, label %direct.true155, label %direct.false156

direct.schedule.6:                                ; preds = %direct.true155
  %.spill.load = load i64, ptr %.spill31, align 4
  %137 = mul i64 %.spill.load, 2
  %.splatinsert157 = insertelement <8 x i64> poison, i64 %137, i64 0
  %.splat158 = shufflevector <8 x i64> %.splatinsert157, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load159 = load <8 x i64>, ptr %.spill30, align 64
  %138 = add <8 x i64> %.splat158, %.spill.load159
  %139 = mul <8 x i64> %138, splat (i64 2053)
  %.spill.load160 = load i64, ptr %.spill37, align 4
  %.splatinsert161 = insertelement <8 x i64> poison, i64 %.spill.load160, i64 0
  %.splat162 = shufflevector <8 x i64> %.splatinsert161, <8 x i64> poison, <8 x i32> zeroinitializer
  %140 = add <8 x i64> %139, %.splat162
  %141 = mul <8 x i64> %140, splat (i64 80)
  %142 = add <8 x i64> %141, zeroinitializer
  %tile_snapshot.spill.load163 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %143 = extractvalue { ptr, i64 } %35, 0
  %144 = extractelement <8 x i1> %71, i64 0
  br i1 %144, label %copy.active164, label %copy.continue165

direct.schedule.7:                                ; preds = %direct.false753, %copy.continue179
  %145 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %145, 0
  %148 = select <8 x i1> %71, <8 x ptr> %146, <8 x ptr> %147
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %145, 1
  %151 = select <8 x i1> %71, <8 x i64> %149, <8 x i64> %150
  %152 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %148, 0
  %153 = insertvalue { <8 x ptr>, <8 x i64> } %152, <8 x i64> %151, 1
  store { <8 x ptr>, <8 x i64> } %153, ptr %tile_snapshot.spill40, align 64
  %.spill.load180 = load i1, ptr %.spill39, align 1
  br i1 %.spill.load180, label %direct.true181, label %direct.false182

direct.schedule.8:                                ; preds = %direct.true181
  %.spill.load183 = load i64, ptr %.spill31, align 4
  %154 = mul i64 %.spill.load183, 2
  %.splatinsert184 = insertelement <8 x i64> poison, i64 %154, i64 0
  %.splat185 = shufflevector <8 x i64> %.splatinsert184, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load186 = load <8 x i64>, ptr %.spill30, align 64
  %155 = add <8 x i64> %.splat185, %.spill.load186
  %156 = mul <8 x i64> %155, splat (i64 2053)
  %.spill.load187 = load i64, ptr %.spill37, align 4
  %.splatinsert188 = insertelement <8 x i64> poison, i64 %.spill.load187, i64 0
  %.splat189 = shufflevector <8 x i64> %.splatinsert188, <8 x i64> poison, <8 x i32> zeroinitializer
  %157 = add <8 x i64> %156, %.splat189
  %158 = mul <8 x i64> %157, splat (i64 96)
  %159 = add <8 x i64> %158, zeroinitializer
  %tile_snapshot.spill.load190 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %160 = extractvalue { ptr, i64 } %41, 0
  %161 = extractelement <8 x i1> %71, i64 0
  br i1 %161, label %copy.active191, label %copy.continue192

direct.schedule.9:                                ; preds = %direct.false728, %copy.continue206
  store i64 0, ptr %.slot41, align 4
  %162 = load <8 x float>, ptr %.slot42, align 32
  %163 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %162
  store <8 x float> %163, ptr %.slot42, align 32
  %164 = load <8 x float>, ptr %.slot43, align 32
  %165 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %164
  store <8 x float> %165, ptr %.slot43, align 32
  %166 = load <8 x float>, ptr %.slot44, align 32
  %167 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %166
  store <8 x float> %167, ptr %.slot44, align 32
  %168 = load <8 x float>, ptr %.slot45, align 32
  %169 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %168
  store <8 x float> %169, ptr %.slot45, align 32
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state207 = load i64, ptr %.slot41, align 4
  %170 = icmp slt i64 %.state207, 80
  br i1 %170, label %direct.true208, label %direct.false209

direct.schedule.11:                               ; preds = %direct.true208
  %.state210 = load i64, ptr %.slot41, align 4
  %171 = add i64 0, %.state210
  %tile_snapshot.spill.load211 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load211, 0
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load211, 1
  %.splatinsert212 = insertelement <8 x i64> poison, i64 %171, i64 0
  %.splat213 = shufflevector <8 x i64> %.splatinsert212, <8 x i64> poison, <8 x i32> zeroinitializer
  %174 = mul <8 x i64> %.splat213, splat (i64 32)
  %175 = add <8 x i64> %173, %174
  %176 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %172, 0
  %177 = insertvalue { <8 x ptr>, <8 x i64> } %176, <8 x i64> %175, 1
  %178 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %177, 1
  %180 = extractelement <8 x ptr> %178, i32 0
  %181 = extractelement <8 x i64> %179, i32 0
  %182 = sub i64 %181, 0
  %183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %184 = select i1 %183, i64 %182, i64 0
  %private.contiguous.address214 = getelementptr i8, ptr %180, i64 %184
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address214, align 4
  %185 = select <8 x i1> %71, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load215 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %186 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load215, 0
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load215, 1
  %.splatinsert216 = insertelement <8 x i64> poison, i64 %171, i64 0
  %.splat217 = shufflevector <8 x i64> %.splatinsert216, <8 x i64> poison, <8 x i32> zeroinitializer
  %188 = mul <8 x i64> %.splat217, splat (i64 32)
  %189 = add <8 x i64> %187, %188
  %190 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %186, 0
  %191 = insertvalue { <8 x ptr>, <8 x i64> } %190, <8 x i64> %189, 1
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %191, 1
  %194 = extractelement <8 x ptr> %192, i32 0
  %195 = extractelement <8 x i64> %193, i32 0
  %196 = sub i64 %195, 0
  %197 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %198 = select i1 %197, i64 %196, i64 0
  %private.contiguous.address218 = getelementptr i8, ptr %194, i64 %198
  %private.contiguous.load219 = load <8 x float>, ptr %private.contiguous.address218, align 4
  %199 = select <8 x i1> %71, <8 x float> %private.contiguous.load219, <8 x float> zeroinitializer
  %200 = fmul <8 x float> %185, %199
  %.state220 = load <8 x float>, ptr %.slot42, align 32
  %201 = fadd <8 x float> %.state220, %200
  %.state221 = load i64, ptr %.slot41, align 4
  %202 = add i64 80, %.state221
  %tile_snapshot.spill.load222 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %203 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load222, 0
  %204 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load222, 1
  %.splatinsert223 = insertelement <8 x i64> poison, i64 %202, i64 0
  %.splat224 = shufflevector <8 x i64> %.splatinsert223, <8 x i64> poison, <8 x i32> zeroinitializer
  %205 = mul <8 x i64> %.splat224, splat (i64 32)
  %206 = add <8 x i64> %204, %205
  %207 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %203, 0
  %208 = insertvalue { <8 x ptr>, <8 x i64> } %207, <8 x i64> %206, 1
  %209 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %210 = extractvalue { <8 x ptr>, <8 x i64> } %208, 1
  %211 = extractelement <8 x ptr> %209, i32 0
  %212 = extractelement <8 x i64> %210, i32 0
  %213 = sub i64 %212, 0
  %214 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %215 = select i1 %214, i64 %213, i64 0
  %private.contiguous.address225 = getelementptr i8, ptr %211, i64 %215
  %private.contiguous.load226 = load <8 x float>, ptr %private.contiguous.address225, align 4
  %216 = select <8 x i1> %71, <8 x float> %private.contiguous.load226, <8 x float> zeroinitializer
  %217 = fmul <8 x float> %185, %216
  %.state227 = load <8 x float>, ptr %.slot43, align 32
  %218 = fadd <8 x float> %.state227, %217
  %.state228 = load i64, ptr %.slot41, align 4
  %219 = add i64 160, %.state228
  %tile_snapshot.spill.load229 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load229, 0
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load229, 1
  %.splatinsert230 = insertelement <8 x i64> poison, i64 %219, i64 0
  %.splat231 = shufflevector <8 x i64> %.splatinsert230, <8 x i64> poison, <8 x i32> zeroinitializer
  %222 = mul <8 x i64> %.splat231, splat (i64 32)
  %223 = add <8 x i64> %221, %222
  %224 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %220, 0
  %225 = insertvalue { <8 x ptr>, <8 x i64> } %224, <8 x i64> %223, 1
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %225, 1
  %228 = extractelement <8 x ptr> %226, i32 0
  %229 = extractelement <8 x i64> %227, i32 0
  %230 = sub i64 %229, 0
  %231 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %232 = select i1 %231, i64 %230, i64 0
  %private.contiguous.address232 = getelementptr i8, ptr %228, i64 %232
  %private.contiguous.load233 = load <8 x float>, ptr %private.contiguous.address232, align 4
  %233 = select <8 x i1> %71, <8 x float> %private.contiguous.load233, <8 x float> zeroinitializer
  %234 = fmul <8 x float> %185, %233
  %.state234 = load <8 x float>, ptr %.slot44, align 32
  %235 = fadd <8 x float> %.state234, %234
  %.state235 = load i64, ptr %.slot41, align 4
  %236 = add i64 240, %.state235
  %tile_snapshot.spill.load236 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %237 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load236, 0
  %238 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load236, 1
  %.splatinsert237 = insertelement <8 x i64> poison, i64 %236, i64 0
  %.splat238 = shufflevector <8 x i64> %.splatinsert237, <8 x i64> poison, <8 x i32> zeroinitializer
  %239 = mul <8 x i64> %.splat238, splat (i64 32)
  %240 = add <8 x i64> %238, %239
  %241 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %237, 0
  %242 = insertvalue { <8 x ptr>, <8 x i64> } %241, <8 x i64> %240, 1
  %243 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %244 = extractvalue { <8 x ptr>, <8 x i64> } %242, 1
  %245 = extractelement <8 x ptr> %243, i32 0
  %246 = extractelement <8 x i64> %244, i32 0
  %247 = sub i64 %246, 0
  %248 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %249 = select i1 %248, i64 %247, i64 0
  %private.contiguous.address239 = getelementptr i8, ptr %245, i64 %249
  %private.contiguous.load240 = load <8 x float>, ptr %private.contiguous.address239, align 4
  %250 = select <8 x i1> %71, <8 x float> %private.contiguous.load240, <8 x float> zeroinitializer
  %251 = fmul <8 x float> %185, %250
  %.state241 = load <8 x float>, ptr %.slot45, align 32
  %252 = fadd <8 x float> %.state241, %251
  %.state242 = load i64, ptr %.slot41, align 4
  %253 = add i64 %.state242, 1
  store i64 %253, ptr %.slot41, align 4
  %254 = load <8 x float>, ptr %.slot42, align 32
  %255 = select <8 x i1> %71, <8 x float> %201, <8 x float> %254
  store <8 x float> %255, ptr %.slot42, align 32
  %256 = load <8 x float>, ptr %.slot43, align 32
  %257 = select <8 x i1> %71, <8 x float> %218, <8 x float> %256
  store <8 x float> %257, ptr %.slot43, align 32
  %258 = load <8 x float>, ptr %.slot44, align 32
  %259 = select <8 x i1> %71, <8 x float> %235, <8 x float> %258
  store <8 x float> %259, ptr %.slot44, align 32
  %260 = load <8 x float>, ptr %.slot45, align 32
  %261 = select <8 x i1> %71, <8 x float> %252, <8 x float> %260
  store <8 x float> %261, ptr %.slot45, align 32
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false209
  store i64 0, ptr %.slot46, align 4
  %262 = load <8 x float>, ptr %.slot47, align 32
  %263 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %262
  store <8 x float> %263, ptr %.slot47, align 32
  %264 = load <8 x float>, ptr %.slot48, align 32
  %265 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %264
  store <8 x float> %265, ptr %.slot48, align 32
  %266 = load <8 x float>, ptr %.slot49, align 32
  %267 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %266
  store <8 x float> %267, ptr %.slot49, align 32
  %268 = load <8 x float>, ptr %.slot50, align 32
  %269 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %268
  store <8 x float> %269, ptr %.slot50, align 32
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state243 = load i64, ptr %.slot46, align 4
  %270 = icmp slt i64 %.state243, 80
  br i1 %270, label %direct.true244, label %direct.false245

direct.schedule.14:                               ; preds = %direct.true244
  %.state246 = load i64, ptr %.slot46, align 4
  %271 = add i64 0, %.state246
  %tile_snapshot.spill.load247 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %272 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load247, 0
  %273 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load247, 1
  %.splatinsert248 = insertelement <8 x i64> poison, i64 %271, i64 0
  %.splat249 = shufflevector <8 x i64> %.splatinsert248, <8 x i64> poison, <8 x i32> zeroinitializer
  %274 = mul <8 x i64> %.splat249, splat (i64 32)
  %275 = add <8 x i64> %273, %274
  %276 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %272, 0
  %277 = insertvalue { <8 x ptr>, <8 x i64> } %276, <8 x i64> %275, 1
  %278 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %279 = extractvalue { <8 x ptr>, <8 x i64> } %277, 1
  %280 = extractelement <8 x ptr> %278, i32 0
  %281 = extractelement <8 x i64> %279, i32 0
  %282 = sub i64 %281, 0
  %283 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %284 = select i1 %283, i64 %282, i64 0
  %private.contiguous.address250 = getelementptr i8, ptr %280, i64 %284
  %private.contiguous.load251 = load <8 x float>, ptr %private.contiguous.address250, align 4
  %285 = select <8 x i1> %71, <8 x float> %private.contiguous.load251, <8 x float> zeroinitializer
  %.state252 = load i64, ptr %.slot46, align 4
  %286 = add i64 320, %.state252
  %tile_snapshot.spill.load253 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load253, 0
  %288 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load253, 1
  %.splatinsert254 = insertelement <8 x i64> poison, i64 %286, i64 0
  %.splat255 = shufflevector <8 x i64> %.splatinsert254, <8 x i64> poison, <8 x i32> zeroinitializer
  %289 = mul <8 x i64> %.splat255, splat (i64 32)
  %290 = add <8 x i64> %288, %289
  %291 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %287, 0
  %292 = insertvalue { <8 x ptr>, <8 x i64> } %291, <8 x i64> %290, 1
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %292, 1
  %295 = extractelement <8 x ptr> %293, i32 0
  %296 = extractelement <8 x i64> %294, i32 0
  %297 = sub i64 %296, 0
  %298 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %299 = select i1 %298, i64 %297, i64 0
  %private.contiguous.address256 = getelementptr i8, ptr %295, i64 %299
  %private.contiguous.load257 = load <8 x float>, ptr %private.contiguous.address256, align 4
  %300 = select <8 x i1> %71, <8 x float> %private.contiguous.load257, <8 x float> zeroinitializer
  %301 = fmul <8 x float> %285, %300
  %.state258 = load <8 x float>, ptr %.slot47, align 32
  %302 = fadd <8 x float> %.state258, %301
  %.state259 = load i64, ptr %.slot46, align 4
  %303 = add i64 400, %.state259
  %tile_snapshot.spill.load260 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load260, 0
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load260, 1
  %.splatinsert261 = insertelement <8 x i64> poison, i64 %303, i64 0
  %.splat262 = shufflevector <8 x i64> %.splatinsert261, <8 x i64> poison, <8 x i32> zeroinitializer
  %306 = mul <8 x i64> %.splat262, splat (i64 32)
  %307 = add <8 x i64> %305, %306
  %308 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %304, 0
  %309 = insertvalue { <8 x ptr>, <8 x i64> } %308, <8 x i64> %307, 1
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %311 = extractvalue { <8 x ptr>, <8 x i64> } %309, 1
  %312 = extractelement <8 x ptr> %310, i32 0
  %313 = extractelement <8 x i64> %311, i32 0
  %314 = sub i64 %313, 0
  %315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %316 = select i1 %315, i64 %314, i64 0
  %private.contiguous.address263 = getelementptr i8, ptr %312, i64 %316
  %private.contiguous.load264 = load <8 x float>, ptr %private.contiguous.address263, align 4
  %317 = select <8 x i1> %71, <8 x float> %private.contiguous.load264, <8 x float> zeroinitializer
  %318 = fmul <8 x float> %285, %317
  %.state265 = load <8 x float>, ptr %.slot48, align 32
  %319 = fadd <8 x float> %.state265, %318
  %.state266 = load i64, ptr %.slot46, align 4
  %320 = add i64 480, %.state266
  %tile_snapshot.spill.load267 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %321 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load267, 0
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load267, 1
  %.splatinsert268 = insertelement <8 x i64> poison, i64 %320, i64 0
  %.splat269 = shufflevector <8 x i64> %.splatinsert268, <8 x i64> poison, <8 x i32> zeroinitializer
  %323 = mul <8 x i64> %.splat269, splat (i64 32)
  %324 = add <8 x i64> %322, %323
  %325 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %321, 0
  %326 = insertvalue { <8 x ptr>, <8 x i64> } %325, <8 x i64> %324, 1
  %327 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %328 = extractvalue { <8 x ptr>, <8 x i64> } %326, 1
  %329 = extractelement <8 x ptr> %327, i32 0
  %330 = extractelement <8 x i64> %328, i32 0
  %331 = sub i64 %330, 0
  %332 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %333 = select i1 %332, i64 %331, i64 0
  %private.contiguous.address270 = getelementptr i8, ptr %329, i64 %333
  %private.contiguous.load271 = load <8 x float>, ptr %private.contiguous.address270, align 4
  %334 = select <8 x i1> %71, <8 x float> %private.contiguous.load271, <8 x float> zeroinitializer
  %335 = fmul <8 x float> %285, %334
  %.state272 = load <8 x float>, ptr %.slot49, align 32
  %336 = fadd <8 x float> %.state272, %335
  %.state273 = load i64, ptr %.slot46, align 4
  %337 = add i64 560, %.state273
  %tile_snapshot.spill.load274 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %338 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load274, 0
  %339 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load274, 1
  %.splatinsert275 = insertelement <8 x i64> poison, i64 %337, i64 0
  %.splat276 = shufflevector <8 x i64> %.splatinsert275, <8 x i64> poison, <8 x i32> zeroinitializer
  %340 = mul <8 x i64> %.splat276, splat (i64 32)
  %341 = add <8 x i64> %339, %340
  %342 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %338, 0
  %343 = insertvalue { <8 x ptr>, <8 x i64> } %342, <8 x i64> %341, 1
  %344 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %345 = extractvalue { <8 x ptr>, <8 x i64> } %343, 1
  %346 = extractelement <8 x ptr> %344, i32 0
  %347 = extractelement <8 x i64> %345, i32 0
  %348 = sub i64 %347, 0
  %349 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %350 = select i1 %349, i64 %348, i64 0
  %private.contiguous.address277 = getelementptr i8, ptr %346, i64 %350
  %private.contiguous.load278 = load <8 x float>, ptr %private.contiguous.address277, align 4
  %351 = select <8 x i1> %71, <8 x float> %private.contiguous.load278, <8 x float> zeroinitializer
  %352 = fmul <8 x float> %285, %351
  %.state279 = load <8 x float>, ptr %.slot50, align 32
  %353 = fadd <8 x float> %.state279, %352
  %.state280 = load i64, ptr %.slot46, align 4
  %354 = add i64 %.state280, 1
  store i64 %354, ptr %.slot46, align 4
  %355 = load <8 x float>, ptr %.slot47, align 32
  %356 = select <8 x i1> %71, <8 x float> %302, <8 x float> %355
  store <8 x float> %356, ptr %.slot47, align 32
  %357 = load <8 x float>, ptr %.slot48, align 32
  %358 = select <8 x i1> %71, <8 x float> %319, <8 x float> %357
  store <8 x float> %358, ptr %.slot48, align 32
  %359 = load <8 x float>, ptr %.slot49, align 32
  %360 = select <8 x i1> %71, <8 x float> %336, <8 x float> %359
  store <8 x float> %360, ptr %.slot49, align 32
  %361 = load <8 x float>, ptr %.slot50, align 32
  %362 = select <8 x i1> %71, <8 x float> %353, <8 x float> %361
  store <8 x float> %362, ptr %.slot50, align 32
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false245
  store i64 0, ptr %.slot51, align 4
  %363 = load <8 x float>, ptr %.slot52, align 32
  %364 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %363
  store <8 x float> %364, ptr %.slot52, align 32
  %365 = load <8 x float>, ptr %.slot53, align 32
  %366 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %365
  store <8 x float> %366, ptr %.slot53, align 32
  %367 = load <8 x float>, ptr %.slot54, align 32
  %368 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %367
  store <8 x float> %368, ptr %.slot54, align 32
  %369 = load <8 x float>, ptr %.slot55, align 32
  %370 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %369
  store <8 x float> %370, ptr %.slot55, align 32
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state281 = load i64, ptr %.slot51, align 4
  %371 = icmp slt i64 %.state281, 80
  br i1 %371, label %direct.true282, label %direct.false283

direct.schedule.17:                               ; preds = %direct.true282
  %.state284 = load i64, ptr %.slot51, align 4
  %372 = add i64 0, %.state284
  %tile_snapshot.spill.load285 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %373 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load285, 0
  %374 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load285, 1
  %.splatinsert286 = insertelement <8 x i64> poison, i64 %372, i64 0
  %.splat287 = shufflevector <8 x i64> %.splatinsert286, <8 x i64> poison, <8 x i32> zeroinitializer
  %375 = mul <8 x i64> %.splat287, splat (i64 32)
  %376 = add <8 x i64> %374, %375
  %377 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %373, 0
  %378 = insertvalue { <8 x ptr>, <8 x i64> } %377, <8 x i64> %376, 1
  %379 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %380 = extractvalue { <8 x ptr>, <8 x i64> } %378, 1
  %381 = extractelement <8 x ptr> %379, i32 0
  %382 = extractelement <8 x i64> %380, i32 0
  %383 = sub i64 %382, 0
  %384 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %385 = select i1 %384, i64 %383, i64 0
  %private.contiguous.address288 = getelementptr i8, ptr %381, i64 %385
  %private.contiguous.load289 = load <8 x float>, ptr %private.contiguous.address288, align 4
  %386 = select <8 x i1> %71, <8 x float> %private.contiguous.load289, <8 x float> zeroinitializer
  %.state290 = load i64, ptr %.slot51, align 4
  %387 = add i64 640, %.state290
  %tile_snapshot.spill.load291 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %388 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load291, 0
  %389 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load291, 1
  %.splatinsert292 = insertelement <8 x i64> poison, i64 %387, i64 0
  %.splat293 = shufflevector <8 x i64> %.splatinsert292, <8 x i64> poison, <8 x i32> zeroinitializer
  %390 = mul <8 x i64> %.splat293, splat (i64 32)
  %391 = add <8 x i64> %389, %390
  %392 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %388, 0
  %393 = insertvalue { <8 x ptr>, <8 x i64> } %392, <8 x i64> %391, 1
  %394 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %395 = extractvalue { <8 x ptr>, <8 x i64> } %393, 1
  %396 = extractelement <8 x ptr> %394, i32 0
  %397 = extractelement <8 x i64> %395, i32 0
  %398 = sub i64 %397, 0
  %399 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %400 = select i1 %399, i64 %398, i64 0
  %private.contiguous.address294 = getelementptr i8, ptr %396, i64 %400
  %private.contiguous.load295 = load <8 x float>, ptr %private.contiguous.address294, align 4
  %401 = select <8 x i1> %71, <8 x float> %private.contiguous.load295, <8 x float> zeroinitializer
  %402 = fmul <8 x float> %386, %401
  %.state296 = load <8 x float>, ptr %.slot52, align 32
  %403 = fadd <8 x float> %.state296, %402
  %.state297 = load i64, ptr %.slot51, align 4
  %404 = add i64 720, %.state297
  %tile_snapshot.spill.load298 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %405 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load298, 0
  %406 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load298, 1
  %.splatinsert299 = insertelement <8 x i64> poison, i64 %404, i64 0
  %.splat300 = shufflevector <8 x i64> %.splatinsert299, <8 x i64> poison, <8 x i32> zeroinitializer
  %407 = mul <8 x i64> %.splat300, splat (i64 32)
  %408 = add <8 x i64> %406, %407
  %409 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %405, 0
  %410 = insertvalue { <8 x ptr>, <8 x i64> } %409, <8 x i64> %408, 1
  %411 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %412 = extractvalue { <8 x ptr>, <8 x i64> } %410, 1
  %413 = extractelement <8 x ptr> %411, i32 0
  %414 = extractelement <8 x i64> %412, i32 0
  %415 = sub i64 %414, 0
  %416 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %417 = select i1 %416, i64 %415, i64 0
  %private.contiguous.address301 = getelementptr i8, ptr %413, i64 %417
  %private.contiguous.load302 = load <8 x float>, ptr %private.contiguous.address301, align 4
  %418 = select <8 x i1> %71, <8 x float> %private.contiguous.load302, <8 x float> zeroinitializer
  %419 = fmul <8 x float> %386, %418
  %.state303 = load <8 x float>, ptr %.slot53, align 32
  %420 = fadd <8 x float> %.state303, %419
  %.state304 = load i64, ptr %.slot51, align 4
  %421 = add i64 800, %.state304
  %tile_snapshot.spill.load305 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %422 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load305, 0
  %423 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load305, 1
  %.splatinsert306 = insertelement <8 x i64> poison, i64 %421, i64 0
  %.splat307 = shufflevector <8 x i64> %.splatinsert306, <8 x i64> poison, <8 x i32> zeroinitializer
  %424 = mul <8 x i64> %.splat307, splat (i64 32)
  %425 = add <8 x i64> %423, %424
  %426 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %422, 0
  %427 = insertvalue { <8 x ptr>, <8 x i64> } %426, <8 x i64> %425, 1
  %428 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %429 = extractvalue { <8 x ptr>, <8 x i64> } %427, 1
  %430 = extractelement <8 x ptr> %428, i32 0
  %431 = extractelement <8 x i64> %429, i32 0
  %432 = sub i64 %431, 0
  %433 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %434 = select i1 %433, i64 %432, i64 0
  %private.contiguous.address308 = getelementptr i8, ptr %430, i64 %434
  %private.contiguous.load309 = load <8 x float>, ptr %private.contiguous.address308, align 4
  %435 = select <8 x i1> %71, <8 x float> %private.contiguous.load309, <8 x float> zeroinitializer
  %436 = fmul <8 x float> %386, %435
  %.state310 = load <8 x float>, ptr %.slot54, align 32
  %437 = fadd <8 x float> %.state310, %436
  %.state311 = load i64, ptr %.slot51, align 4
  %438 = add i64 880, %.state311
  %tile_snapshot.spill.load312 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %439 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load312, 0
  %440 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load312, 1
  %.splatinsert313 = insertelement <8 x i64> poison, i64 %438, i64 0
  %.splat314 = shufflevector <8 x i64> %.splatinsert313, <8 x i64> poison, <8 x i32> zeroinitializer
  %441 = mul <8 x i64> %.splat314, splat (i64 32)
  %442 = add <8 x i64> %440, %441
  %443 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %439, 0
  %444 = insertvalue { <8 x ptr>, <8 x i64> } %443, <8 x i64> %442, 1
  %445 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %446 = extractvalue { <8 x ptr>, <8 x i64> } %444, 1
  %447 = extractelement <8 x ptr> %445, i32 0
  %448 = extractelement <8 x i64> %446, i32 0
  %449 = sub i64 %448, 0
  %450 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %451 = select i1 %450, i64 %449, i64 0
  %private.contiguous.address315 = getelementptr i8, ptr %447, i64 %451
  %private.contiguous.load316 = load <8 x float>, ptr %private.contiguous.address315, align 4
  %452 = select <8 x i1> %71, <8 x float> %private.contiguous.load316, <8 x float> zeroinitializer
  %453 = fmul <8 x float> %386, %452
  %.state317 = load <8 x float>, ptr %.slot55, align 32
  %454 = fadd <8 x float> %.state317, %453
  %.state318 = load i64, ptr %.slot51, align 4
  %455 = add i64 %.state318, 1
  store i64 %455, ptr %.slot51, align 4
  %456 = load <8 x float>, ptr %.slot52, align 32
  %457 = select <8 x i1> %71, <8 x float> %403, <8 x float> %456
  store <8 x float> %457, ptr %.slot52, align 32
  %458 = load <8 x float>, ptr %.slot53, align 32
  %459 = select <8 x i1> %71, <8 x float> %420, <8 x float> %458
  store <8 x float> %459, ptr %.slot53, align 32
  %460 = load <8 x float>, ptr %.slot54, align 32
  %461 = select <8 x i1> %71, <8 x float> %437, <8 x float> %460
  store <8 x float> %461, ptr %.slot54, align 32
  %462 = load <8 x float>, ptr %.slot55, align 32
  %463 = select <8 x i1> %71, <8 x float> %454, <8 x float> %462
  store <8 x float> %463, ptr %.slot55, align 32
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false283
  store i64 0, ptr %.slot56, align 4
  %464 = load <8 x float>, ptr %.slot57, align 32
  %465 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %464
  store <8 x float> %465, ptr %.slot57, align 32
  %466 = load <8 x float>, ptr %.slot58, align 32
  %467 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %466
  store <8 x float> %467, ptr %.slot58, align 32
  %468 = load <8 x float>, ptr %.slot59, align 32
  %469 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %468
  store <8 x float> %469, ptr %.slot59, align 32
  %470 = load <8 x float>, ptr %.slot60, align 32
  %471 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %470
  store <8 x float> %471, ptr %.slot60, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state319 = load i64, ptr %.slot56, align 4
  %472 = icmp slt i64 %.state319, 80
  br i1 %472, label %direct.true320, label %direct.false321

direct.schedule.20:                               ; preds = %direct.true320
  %.state322 = load i64, ptr %.slot56, align 4
  %473 = add i64 0, %.state322
  %tile_snapshot.spill.load323 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %474 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load323, 0
  %475 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load323, 1
  %.splatinsert324 = insertelement <8 x i64> poison, i64 %473, i64 0
  %.splat325 = shufflevector <8 x i64> %.splatinsert324, <8 x i64> poison, <8 x i32> zeroinitializer
  %476 = mul <8 x i64> %.splat325, splat (i64 32)
  %477 = add <8 x i64> %475, %476
  %478 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %474, 0
  %479 = insertvalue { <8 x ptr>, <8 x i64> } %478, <8 x i64> %477, 1
  %480 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %481 = extractvalue { <8 x ptr>, <8 x i64> } %479, 1
  %482 = extractelement <8 x ptr> %480, i32 0
  %483 = extractelement <8 x i64> %481, i32 0
  %484 = sub i64 %483, 0
  %485 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %486 = select i1 %485, i64 %484, i64 0
  %private.contiguous.address326 = getelementptr i8, ptr %482, i64 %486
  %private.contiguous.load327 = load <8 x float>, ptr %private.contiguous.address326, align 4
  %487 = select <8 x i1> %71, <8 x float> %private.contiguous.load327, <8 x float> zeroinitializer
  %.state328 = load i64, ptr %.slot56, align 4
  %488 = add i64 960, %.state328
  %tile_snapshot.spill.load329 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %489 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load329, 0
  %490 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load329, 1
  %.splatinsert330 = insertelement <8 x i64> poison, i64 %488, i64 0
  %.splat331 = shufflevector <8 x i64> %.splatinsert330, <8 x i64> poison, <8 x i32> zeroinitializer
  %491 = mul <8 x i64> %.splat331, splat (i64 32)
  %492 = add <8 x i64> %490, %491
  %493 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %489, 0
  %494 = insertvalue { <8 x ptr>, <8 x i64> } %493, <8 x i64> %492, 1
  %495 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %496 = extractvalue { <8 x ptr>, <8 x i64> } %494, 1
  %497 = extractelement <8 x ptr> %495, i32 0
  %498 = extractelement <8 x i64> %496, i32 0
  %499 = sub i64 %498, 0
  %500 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %501 = select i1 %500, i64 %499, i64 0
  %private.contiguous.address332 = getelementptr i8, ptr %497, i64 %501
  %private.contiguous.load333 = load <8 x float>, ptr %private.contiguous.address332, align 4
  %502 = select <8 x i1> %71, <8 x float> %private.contiguous.load333, <8 x float> zeroinitializer
  %503 = fmul <8 x float> %487, %502
  %.state334 = load <8 x float>, ptr %.slot57, align 32
  %504 = fadd <8 x float> %.state334, %503
  %.state335 = load i64, ptr %.slot56, align 4
  %505 = add i64 1040, %.state335
  %tile_snapshot.spill.load336 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %506 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load336, 0
  %507 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load336, 1
  %.splatinsert337 = insertelement <8 x i64> poison, i64 %505, i64 0
  %.splat338 = shufflevector <8 x i64> %.splatinsert337, <8 x i64> poison, <8 x i32> zeroinitializer
  %508 = mul <8 x i64> %.splat338, splat (i64 32)
  %509 = add <8 x i64> %507, %508
  %510 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %506, 0
  %511 = insertvalue { <8 x ptr>, <8 x i64> } %510, <8 x i64> %509, 1
  %512 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %513 = extractvalue { <8 x ptr>, <8 x i64> } %511, 1
  %514 = extractelement <8 x ptr> %512, i32 0
  %515 = extractelement <8 x i64> %513, i32 0
  %516 = sub i64 %515, 0
  %517 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %518 = select i1 %517, i64 %516, i64 0
  %private.contiguous.address339 = getelementptr i8, ptr %514, i64 %518
  %private.contiguous.load340 = load <8 x float>, ptr %private.contiguous.address339, align 4
  %519 = select <8 x i1> %71, <8 x float> %private.contiguous.load340, <8 x float> zeroinitializer
  %520 = fmul <8 x float> %487, %519
  %.state341 = load <8 x float>, ptr %.slot58, align 32
  %521 = fadd <8 x float> %.state341, %520
  %.state342 = load i64, ptr %.slot56, align 4
  %522 = add i64 1120, %.state342
  %tile_snapshot.spill.load343 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %523 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load343, 0
  %524 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load343, 1
  %.splatinsert344 = insertelement <8 x i64> poison, i64 %522, i64 0
  %.splat345 = shufflevector <8 x i64> %.splatinsert344, <8 x i64> poison, <8 x i32> zeroinitializer
  %525 = mul <8 x i64> %.splat345, splat (i64 32)
  %526 = add <8 x i64> %524, %525
  %527 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %523, 0
  %528 = insertvalue { <8 x ptr>, <8 x i64> } %527, <8 x i64> %526, 1
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %530 = extractvalue { <8 x ptr>, <8 x i64> } %528, 1
  %531 = extractelement <8 x ptr> %529, i32 0
  %532 = extractelement <8 x i64> %530, i32 0
  %533 = sub i64 %532, 0
  %534 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %535 = select i1 %534, i64 %533, i64 0
  %private.contiguous.address346 = getelementptr i8, ptr %531, i64 %535
  %private.contiguous.load347 = load <8 x float>, ptr %private.contiguous.address346, align 4
  %536 = select <8 x i1> %71, <8 x float> %private.contiguous.load347, <8 x float> zeroinitializer
  %537 = fmul <8 x float> %487, %536
  %.state348 = load <8 x float>, ptr %.slot59, align 32
  %538 = fadd <8 x float> %.state348, %537
  %.state349 = load i64, ptr %.slot56, align 4
  %539 = add i64 1200, %.state349
  %tile_snapshot.spill.load350 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %540 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load350, 0
  %541 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load350, 1
  %.splatinsert351 = insertelement <8 x i64> poison, i64 %539, i64 0
  %.splat352 = shufflevector <8 x i64> %.splatinsert351, <8 x i64> poison, <8 x i32> zeroinitializer
  %542 = mul <8 x i64> %.splat352, splat (i64 32)
  %543 = add <8 x i64> %541, %542
  %544 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %540, 0
  %545 = insertvalue { <8 x ptr>, <8 x i64> } %544, <8 x i64> %543, 1
  %546 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %547 = extractvalue { <8 x ptr>, <8 x i64> } %545, 1
  %548 = extractelement <8 x ptr> %546, i32 0
  %549 = extractelement <8 x i64> %547, i32 0
  %550 = sub i64 %549, 0
  %551 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %552 = select i1 %551, i64 %550, i64 0
  %private.contiguous.address353 = getelementptr i8, ptr %548, i64 %552
  %private.contiguous.load354 = load <8 x float>, ptr %private.contiguous.address353, align 4
  %553 = select <8 x i1> %71, <8 x float> %private.contiguous.load354, <8 x float> zeroinitializer
  %554 = fmul <8 x float> %487, %553
  %.state355 = load <8 x float>, ptr %.slot60, align 32
  %555 = fadd <8 x float> %.state355, %554
  %.state356 = load i64, ptr %.slot56, align 4
  %556 = add i64 %.state356, 1
  store i64 %556, ptr %.slot56, align 4
  %557 = load <8 x float>, ptr %.slot57, align 32
  %558 = select <8 x i1> %71, <8 x float> %504, <8 x float> %557
  store <8 x float> %558, ptr %.slot57, align 32
  %559 = load <8 x float>, ptr %.slot58, align 32
  %560 = select <8 x i1> %71, <8 x float> %521, <8 x float> %559
  store <8 x float> %560, ptr %.slot58, align 32
  %561 = load <8 x float>, ptr %.slot59, align 32
  %562 = select <8 x i1> %71, <8 x float> %538, <8 x float> %561
  store <8 x float> %562, ptr %.slot59, align 32
  %563 = load <8 x float>, ptr %.slot60, align 32
  %564 = select <8 x i1> %71, <8 x float> %555, <8 x float> %563
  store <8 x float> %564, ptr %.slot60, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false321
  %.state357 = load <8 x float>, ptr %.slot42, align 32
  %565 = fmul <8 x float> %.state357, splat (float 0x3FBC9F25C0000000)
  %.state358 = load <8 x float>, ptr %.slot43, align 32
  %566 = fmul <8 x float> %.state358, splat (float 0x3FBC9F25C0000000)
  %.state359 = load <8 x float>, ptr %.slot44, align 32
  %567 = fmul <8 x float> %.state359, splat (float 0x3FBC9F25C0000000)
  %.state360 = load <8 x float>, ptr %.slot45, align 32
  %568 = fmul <8 x float> %.state360, splat (float 0x3FBC9F25C0000000)
  %.state361 = load <8 x float>, ptr %.slot47, align 32
  %569 = fmul <8 x float> %.state361, splat (float 0x3FBC9F25C0000000)
  %.state362 = load <8 x float>, ptr %.slot48, align 32
  %570 = fmul <8 x float> %.state362, splat (float 0x3FBC9F25C0000000)
  %.state363 = load <8 x float>, ptr %.slot49, align 32
  %571 = fmul <8 x float> %.state363, splat (float 0x3FBC9F25C0000000)
  %.state364 = load <8 x float>, ptr %.slot50, align 32
  %572 = fmul <8 x float> %.state364, splat (float 0x3FBC9F25C0000000)
  %.state365 = load <8 x float>, ptr %.slot52, align 32
  %573 = fmul <8 x float> %.state365, splat (float 0x3FBC9F25C0000000)
  %.state366 = load <8 x float>, ptr %.slot53, align 32
  %574 = fmul <8 x float> %.state366, splat (float 0x3FBC9F25C0000000)
  %.state367 = load <8 x float>, ptr %.slot54, align 32
  %575 = fmul <8 x float> %.state367, splat (float 0x3FBC9F25C0000000)
  %.state368 = load <8 x float>, ptr %.slot55, align 32
  %576 = fmul <8 x float> %.state368, splat (float 0x3FBC9F25C0000000)
  %.state369 = load <8 x float>, ptr %.slot57, align 32
  %577 = fmul <8 x float> %.state369, splat (float 0x3FBC9F25C0000000)
  %.state370 = load <8 x float>, ptr %.slot58, align 32
  %578 = fmul <8 x float> %.state370, splat (float 0x3FBC9F25C0000000)
  %.state371 = load <8 x float>, ptr %.slot59, align 32
  %579 = fmul <8 x float> %.state371, splat (float 0x3FBC9F25C0000000)
  %.state372 = load <8 x float>, ptr %.slot60, align 32
  %580 = fmul <8 x float> %.state372, splat (float 0x3FBC9F25C0000000)
  %.spill.load373 = load i64, ptr %.spill37, align 4
  %581 = add i64 0, %.spill.load373
  %.spill.load374 = load i64, ptr %.spill37, align 4
  %582 = add i64 1, %.spill.load374
  %.spill.load375 = load i64, ptr %.spill37, align 4
  %583 = add i64 2, %.spill.load375
  %.spill.load376 = load i64, ptr %.spill37, align 4
  %584 = add i64 3, %.spill.load376
  %.spill.load377 = load i64, ptr %.spill37, align 4
  %585 = add i64 4, %.spill.load377
  %.spill.load378 = load i64, ptr %.spill37, align 4
  %586 = add i64 5, %.spill.load378
  %.spill.load379 = load i64, ptr %.spill37, align 4
  %587 = add i64 6, %.spill.load379
  %.spill.load380 = load i64, ptr %.spill37, align 4
  %588 = add i64 7, %.spill.load380
  %.spill.load381 = load i64, ptr %.spill37, align 4
  %589 = add i64 8, %.spill.load381
  %.spill.load382 = load i64, ptr %.spill37, align 4
  %590 = add i64 9, %.spill.load382
  %.spill.load383 = load i64, ptr %.spill37, align 4
  %591 = add i64 10, %.spill.load383
  %.spill.load384 = load i64, ptr %.spill37, align 4
  %592 = add i64 11, %.spill.load384
  %.spill.load385 = load i64, ptr %.spill37, align 4
  %593 = add i64 12, %.spill.load385
  %.spill.load386 = load i64, ptr %.spill37, align 4
  %594 = add i64 13, %.spill.load386
  %.spill.load387 = load i64, ptr %.spill37, align 4
  %595 = add i64 14, %.spill.load387
  %.spill.load388 = load i64, ptr %.spill37, align 4
  %596 = add i64 15, %.spill.load388
  %597 = icmp slt i64 %581, 2053
  %598 = icmp slt i64 %582, 2053
  %599 = icmp slt i64 %583, 2053
  %600 = icmp slt i64 %584, 2053
  %601 = icmp slt i64 %585, 2053
  %602 = icmp slt i64 %586, 2053
  %603 = icmp slt i64 %587, 2053
  %604 = icmp slt i64 %588, 2053
  %605 = icmp slt i64 %589, 2053
  %606 = icmp slt i64 %590, 2053
  %607 = icmp slt i64 %591, 2053
  %608 = icmp slt i64 %592, 2053
  %609 = icmp slt i64 %593, 2053
  %610 = icmp slt i64 %594, 2053
  %611 = icmp slt i64 %595, 2053
  %612 = icmp slt i64 %596, 2053
  %.spill.load389 = load i64, ptr %.spill31, align 4
  %613 = add i64 %.spill.load389, 2053
  %614 = sub i64 %613, 1
  %615 = icmp sle i64 %581, %614
  %616 = icmp sle i64 %582, %614
  %617 = icmp sle i64 %583, %614
  %618 = icmp sle i64 %584, %614
  %619 = icmp sle i64 %585, %614
  %620 = icmp sle i64 %586, %614
  %621 = icmp sle i64 %587, %614
  %622 = icmp sle i64 %588, %614
  %623 = icmp sle i64 %589, %614
  %624 = icmp sle i64 %590, %614
  %625 = icmp sle i64 %591, %614
  %626 = icmp sle i64 %592, %614
  %627 = icmp sle i64 %593, %614
  %628 = icmp sle i64 %594, %614
  %629 = icmp sle i64 %595, %614
  %630 = icmp sle i64 %596, %614
  %631 = and i1 %597, %615
  store i1 %631, ptr %.spill61, align 1
  %632 = and i1 %598, %616
  store i1 %632, ptr %.spill62, align 1
  %633 = and i1 %599, %617
  store i1 %633, ptr %.spill63, align 1
  %634 = and i1 %600, %618
  store i1 %634, ptr %.spill64, align 1
  %635 = and i1 %601, %619
  store i1 %635, ptr %.spill65, align 1
  %636 = and i1 %602, %620
  store i1 %636, ptr %.spill66, align 1
  %637 = and i1 %603, %621
  store i1 %637, ptr %.spill67, align 1
  %638 = and i1 %604, %622
  store i1 %638, ptr %.spill68, align 1
  %639 = and i1 %605, %623
  store i1 %639, ptr %.spill69, align 1
  %640 = and i1 %606, %624
  store i1 %640, ptr %.spill70, align 1
  %641 = and i1 %607, %625
  store i1 %641, ptr %.spill71, align 1
  %642 = and i1 %608, %626
  store i1 %642, ptr %.spill72, align 1
  %643 = and i1 %609, %627
  store i1 %643, ptr %.spill73, align 1
  %644 = and i1 %610, %628
  store i1 %644, ptr %.spill74, align 1
  %645 = and i1 %611, %629
  store i1 %645, ptr %.spill75, align 1
  %646 = and i1 %612, %630
  store i1 %646, ptr %.spill76, align 1
  %.splatinsert390 = insertelement <8 x i1> poison, i1 %631, i64 0
  %.splat391 = shufflevector <8 x i1> %.splatinsert390, <8 x i1> poison, <8 x i32> zeroinitializer
  %647 = select <8 x i1> %.splat391, <8 x float> %565, <8 x float> splat (float 0xC6293E5940000000)
  %648 = load <8 x float>, ptr %.spill77, align 32
  %649 = select <8 x i1> %71, <8 x float> %647, <8 x float> %648
  store <8 x float> %649, ptr %.spill77, align 32
  %.splatinsert392 = insertelement <8 x i1> poison, i1 %632, i64 0
  %.splat393 = shufflevector <8 x i1> %.splatinsert392, <8 x i1> poison, <8 x i32> zeroinitializer
  %650 = select <8 x i1> %.splat393, <8 x float> %566, <8 x float> splat (float 0xC6293E5940000000)
  %651 = load <8 x float>, ptr %.spill78, align 32
  %652 = select <8 x i1> %71, <8 x float> %650, <8 x float> %651
  store <8 x float> %652, ptr %.spill78, align 32
  %.splatinsert394 = insertelement <8 x i1> poison, i1 %633, i64 0
  %.splat395 = shufflevector <8 x i1> %.splatinsert394, <8 x i1> poison, <8 x i32> zeroinitializer
  %653 = select <8 x i1> %.splat395, <8 x float> %567, <8 x float> splat (float 0xC6293E5940000000)
  %654 = load <8 x float>, ptr %.spill79, align 32
  %655 = select <8 x i1> %71, <8 x float> %653, <8 x float> %654
  store <8 x float> %655, ptr %.spill79, align 32
  %.splatinsert396 = insertelement <8 x i1> poison, i1 %634, i64 0
  %.splat397 = shufflevector <8 x i1> %.splatinsert396, <8 x i1> poison, <8 x i32> zeroinitializer
  %656 = select <8 x i1> %.splat397, <8 x float> %568, <8 x float> splat (float 0xC6293E5940000000)
  %657 = load <8 x float>, ptr %.spill80, align 32
  %658 = select <8 x i1> %71, <8 x float> %656, <8 x float> %657
  store <8 x float> %658, ptr %.spill80, align 32
  %.splatinsert398 = insertelement <8 x i1> poison, i1 %635, i64 0
  %.splat399 = shufflevector <8 x i1> %.splatinsert398, <8 x i1> poison, <8 x i32> zeroinitializer
  %659 = select <8 x i1> %.splat399, <8 x float> %569, <8 x float> splat (float 0xC6293E5940000000)
  %660 = load <8 x float>, ptr %.spill81, align 32
  %661 = select <8 x i1> %71, <8 x float> %659, <8 x float> %660
  store <8 x float> %661, ptr %.spill81, align 32
  %.splatinsert400 = insertelement <8 x i1> poison, i1 %636, i64 0
  %.splat401 = shufflevector <8 x i1> %.splatinsert400, <8 x i1> poison, <8 x i32> zeroinitializer
  %662 = select <8 x i1> %.splat401, <8 x float> %570, <8 x float> splat (float 0xC6293E5940000000)
  %663 = load <8 x float>, ptr %.spill82, align 32
  %664 = select <8 x i1> %71, <8 x float> %662, <8 x float> %663
  store <8 x float> %664, ptr %.spill82, align 32
  %.splatinsert402 = insertelement <8 x i1> poison, i1 %637, i64 0
  %.splat403 = shufflevector <8 x i1> %.splatinsert402, <8 x i1> poison, <8 x i32> zeroinitializer
  %665 = select <8 x i1> %.splat403, <8 x float> %571, <8 x float> splat (float 0xC6293E5940000000)
  %666 = load <8 x float>, ptr %.spill83, align 32
  %667 = select <8 x i1> %71, <8 x float> %665, <8 x float> %666
  store <8 x float> %667, ptr %.spill83, align 32
  %.splatinsert404 = insertelement <8 x i1> poison, i1 %638, i64 0
  %.splat405 = shufflevector <8 x i1> %.splatinsert404, <8 x i1> poison, <8 x i32> zeroinitializer
  %668 = select <8 x i1> %.splat405, <8 x float> %572, <8 x float> splat (float 0xC6293E5940000000)
  %669 = load <8 x float>, ptr %.spill84, align 32
  %670 = select <8 x i1> %71, <8 x float> %668, <8 x float> %669
  store <8 x float> %670, ptr %.spill84, align 32
  %.splatinsert406 = insertelement <8 x i1> poison, i1 %639, i64 0
  %.splat407 = shufflevector <8 x i1> %.splatinsert406, <8 x i1> poison, <8 x i32> zeroinitializer
  %671 = select <8 x i1> %.splat407, <8 x float> %573, <8 x float> splat (float 0xC6293E5940000000)
  %672 = load <8 x float>, ptr %.spill85, align 32
  %673 = select <8 x i1> %71, <8 x float> %671, <8 x float> %672
  store <8 x float> %673, ptr %.spill85, align 32
  %.splatinsert408 = insertelement <8 x i1> poison, i1 %640, i64 0
  %.splat409 = shufflevector <8 x i1> %.splatinsert408, <8 x i1> poison, <8 x i32> zeroinitializer
  %674 = select <8 x i1> %.splat409, <8 x float> %574, <8 x float> splat (float 0xC6293E5940000000)
  %675 = load <8 x float>, ptr %.spill86, align 32
  %676 = select <8 x i1> %71, <8 x float> %674, <8 x float> %675
  store <8 x float> %676, ptr %.spill86, align 32
  %.splatinsert410 = insertelement <8 x i1> poison, i1 %641, i64 0
  %.splat411 = shufflevector <8 x i1> %.splatinsert410, <8 x i1> poison, <8 x i32> zeroinitializer
  %677 = select <8 x i1> %.splat411, <8 x float> %575, <8 x float> splat (float 0xC6293E5940000000)
  %678 = load <8 x float>, ptr %.spill87, align 32
  %679 = select <8 x i1> %71, <8 x float> %677, <8 x float> %678
  store <8 x float> %679, ptr %.spill87, align 32
  %.splatinsert412 = insertelement <8 x i1> poison, i1 %642, i64 0
  %.splat413 = shufflevector <8 x i1> %.splatinsert412, <8 x i1> poison, <8 x i32> zeroinitializer
  %680 = select <8 x i1> %.splat413, <8 x float> %576, <8 x float> splat (float 0xC6293E5940000000)
  %681 = load <8 x float>, ptr %.spill88, align 32
  %682 = select <8 x i1> %71, <8 x float> %680, <8 x float> %681
  store <8 x float> %682, ptr %.spill88, align 32
  %.splatinsert414 = insertelement <8 x i1> poison, i1 %643, i64 0
  %.splat415 = shufflevector <8 x i1> %.splatinsert414, <8 x i1> poison, <8 x i32> zeroinitializer
  %683 = select <8 x i1> %.splat415, <8 x float> %577, <8 x float> splat (float 0xC6293E5940000000)
  %684 = load <8 x float>, ptr %.spill89, align 32
  %685 = select <8 x i1> %71, <8 x float> %683, <8 x float> %684
  store <8 x float> %685, ptr %.spill89, align 32
  %.splatinsert416 = insertelement <8 x i1> poison, i1 %644, i64 0
  %.splat417 = shufflevector <8 x i1> %.splatinsert416, <8 x i1> poison, <8 x i32> zeroinitializer
  %686 = select <8 x i1> %.splat417, <8 x float> %578, <8 x float> splat (float 0xC6293E5940000000)
  %687 = load <8 x float>, ptr %.spill90, align 32
  %688 = select <8 x i1> %71, <8 x float> %686, <8 x float> %687
  store <8 x float> %688, ptr %.spill90, align 32
  %.splatinsert418 = insertelement <8 x i1> poison, i1 %645, i64 0
  %.splat419 = shufflevector <8 x i1> %.splatinsert418, <8 x i1> poison, <8 x i32> zeroinitializer
  %689 = select <8 x i1> %.splat419, <8 x float> %579, <8 x float> splat (float 0xC6293E5940000000)
  %690 = load <8 x float>, ptr %.spill91, align 32
  %691 = select <8 x i1> %71, <8 x float> %689, <8 x float> %690
  store <8 x float> %691, ptr %.spill91, align 32
  %.splatinsert420 = insertelement <8 x i1> poison, i1 %646, i64 0
  %.splat421 = shufflevector <8 x i1> %.splatinsert420, <8 x i1> poison, <8 x i32> zeroinitializer
  %692 = select <8 x i1> %.splat421, <8 x float> %580, <8 x float> splat (float 0xC6293E5940000000)
  %693 = load <8 x float>, ptr %.spill92, align 32
  %694 = select <8 x i1> %71, <8 x float> %692, <8 x float> %693
  store <8 x float> %694, ptr %.spill92, align 32
  %695 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill93, align 64
  %696 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %697 = extractvalue { <8 x ptr>, <8 x i64> } %695, 0
  %698 = select <8 x i1> %71, <8 x ptr> %696, <8 x ptr> %697
  %699 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %700 = extractvalue { <8 x ptr>, <8 x i64> } %695, 1
  %701 = select <8 x i1> %71, <8 x i64> %699, <8 x i64> %700
  %702 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %698, 0
  %703 = insertvalue { <8 x ptr>, <8 x i64> } %702, <8 x i64> %701, 1
  store { <8 x ptr>, <8 x i64> } %703, ptr %tile_snapshot.spill93, align 64
  %704 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %705 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %706 = add <8 x i64> %705, zeroinitializer
  %707 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %704, 0
  %708 = insertvalue { <8 x ptr>, <8 x i64> } %707, <8 x i64> %706, 1
  %709 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %710 = extractvalue { <8 x ptr>, <8 x i64> } %708, 1
  %711 = extractelement <8 x ptr> %709, i32 0
  %712 = extractelement <8 x i64> %710, i32 0
  %713 = sub i64 %712, 0
  %714 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %715 = select i1 %714, i64 %713, i64 0
  %private.contiguous.address422 = getelementptr i8, ptr %711, i64 %715
  %private.contiguous.preserve423 = load <8 x float>, ptr %private.contiguous.address422, align 4
  %716 = select <8 x i1> %71, <8 x float> %647, <8 x float> %private.contiguous.preserve423
  store <8 x float> %716, ptr %private.contiguous.address422, align 4
  %717 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %718 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %719 = add <8 x i64> %718, splat (i64 32)
  %720 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %717, 0
  %721 = insertvalue { <8 x ptr>, <8 x i64> } %720, <8 x i64> %719, 1
  %722 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %723 = extractvalue { <8 x ptr>, <8 x i64> } %721, 1
  %724 = extractelement <8 x ptr> %722, i32 0
  %725 = extractelement <8 x i64> %723, i32 0
  %726 = sub i64 %725, 0
  %727 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %728 = select i1 %727, i64 %726, i64 0
  %private.contiguous.address424 = getelementptr i8, ptr %724, i64 %728
  %private.contiguous.preserve425 = load <8 x float>, ptr %private.contiguous.address424, align 4
  %729 = select <8 x i1> %71, <8 x float> %650, <8 x float> %private.contiguous.preserve425
  store <8 x float> %729, ptr %private.contiguous.address424, align 4
  %730 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %731 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %732 = add <8 x i64> %731, splat (i64 64)
  %733 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %730, 0
  %734 = insertvalue { <8 x ptr>, <8 x i64> } %733, <8 x i64> %732, 1
  %735 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %736 = extractvalue { <8 x ptr>, <8 x i64> } %734, 1
  %737 = extractelement <8 x ptr> %735, i32 0
  %738 = extractelement <8 x i64> %736, i32 0
  %739 = sub i64 %738, 0
  %740 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %741 = select i1 %740, i64 %739, i64 0
  %private.contiguous.address426 = getelementptr i8, ptr %737, i64 %741
  %private.contiguous.preserve427 = load <8 x float>, ptr %private.contiguous.address426, align 4
  %742 = select <8 x i1> %71, <8 x float> %653, <8 x float> %private.contiguous.preserve427
  store <8 x float> %742, ptr %private.contiguous.address426, align 4
  %743 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %744 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %745 = add <8 x i64> %744, splat (i64 96)
  %746 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %743, 0
  %747 = insertvalue { <8 x ptr>, <8 x i64> } %746, <8 x i64> %745, 1
  %748 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %749 = extractvalue { <8 x ptr>, <8 x i64> } %747, 1
  %750 = extractelement <8 x ptr> %748, i32 0
  %751 = extractelement <8 x i64> %749, i32 0
  %752 = sub i64 %751, 0
  %753 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %754 = select i1 %753, i64 %752, i64 0
  %private.contiguous.address428 = getelementptr i8, ptr %750, i64 %754
  %private.contiguous.preserve429 = load <8 x float>, ptr %private.contiguous.address428, align 4
  %755 = select <8 x i1> %71, <8 x float> %656, <8 x float> %private.contiguous.preserve429
  store <8 x float> %755, ptr %private.contiguous.address428, align 4
  %756 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %757 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %758 = add <8 x i64> %757, splat (i64 128)
  %759 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %756, 0
  %760 = insertvalue { <8 x ptr>, <8 x i64> } %759, <8 x i64> %758, 1
  %761 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %762 = extractvalue { <8 x ptr>, <8 x i64> } %760, 1
  %763 = extractelement <8 x ptr> %761, i32 0
  %764 = extractelement <8 x i64> %762, i32 0
  %765 = sub i64 %764, 0
  %766 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %767 = select i1 %766, i64 %765, i64 0
  %private.contiguous.address430 = getelementptr i8, ptr %763, i64 %767
  %private.contiguous.preserve431 = load <8 x float>, ptr %private.contiguous.address430, align 4
  %768 = select <8 x i1> %71, <8 x float> %659, <8 x float> %private.contiguous.preserve431
  store <8 x float> %768, ptr %private.contiguous.address430, align 4
  %769 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %770 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %771 = add <8 x i64> %770, splat (i64 160)
  %772 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %769, 0
  %773 = insertvalue { <8 x ptr>, <8 x i64> } %772, <8 x i64> %771, 1
  %774 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %775 = extractvalue { <8 x ptr>, <8 x i64> } %773, 1
  %776 = extractelement <8 x ptr> %774, i32 0
  %777 = extractelement <8 x i64> %775, i32 0
  %778 = sub i64 %777, 0
  %779 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %780 = select i1 %779, i64 %778, i64 0
  %private.contiguous.address432 = getelementptr i8, ptr %776, i64 %780
  %private.contiguous.preserve433 = load <8 x float>, ptr %private.contiguous.address432, align 4
  %781 = select <8 x i1> %71, <8 x float> %662, <8 x float> %private.contiguous.preserve433
  store <8 x float> %781, ptr %private.contiguous.address432, align 4
  %782 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %783 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %784 = add <8 x i64> %783, splat (i64 192)
  %785 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %782, 0
  %786 = insertvalue { <8 x ptr>, <8 x i64> } %785, <8 x i64> %784, 1
  %787 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %788 = extractvalue { <8 x ptr>, <8 x i64> } %786, 1
  %789 = extractelement <8 x ptr> %787, i32 0
  %790 = extractelement <8 x i64> %788, i32 0
  %791 = sub i64 %790, 0
  %792 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %793 = select i1 %792, i64 %791, i64 0
  %private.contiguous.address434 = getelementptr i8, ptr %789, i64 %793
  %private.contiguous.preserve435 = load <8 x float>, ptr %private.contiguous.address434, align 4
  %794 = select <8 x i1> %71, <8 x float> %665, <8 x float> %private.contiguous.preserve435
  store <8 x float> %794, ptr %private.contiguous.address434, align 4
  %795 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %796 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %797 = add <8 x i64> %796, splat (i64 224)
  %798 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %795, 0
  %799 = insertvalue { <8 x ptr>, <8 x i64> } %798, <8 x i64> %797, 1
  %800 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %801 = extractvalue { <8 x ptr>, <8 x i64> } %799, 1
  %802 = extractelement <8 x ptr> %800, i32 0
  %803 = extractelement <8 x i64> %801, i32 0
  %804 = sub i64 %803, 0
  %805 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %806 = select i1 %805, i64 %804, i64 0
  %private.contiguous.address436 = getelementptr i8, ptr %802, i64 %806
  %private.contiguous.preserve437 = load <8 x float>, ptr %private.contiguous.address436, align 4
  %807 = select <8 x i1> %71, <8 x float> %668, <8 x float> %private.contiguous.preserve437
  store <8 x float> %807, ptr %private.contiguous.address436, align 4
  %808 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %809 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %810 = add <8 x i64> %809, splat (i64 256)
  %811 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %808, 0
  %812 = insertvalue { <8 x ptr>, <8 x i64> } %811, <8 x i64> %810, 1
  %813 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %814 = extractvalue { <8 x ptr>, <8 x i64> } %812, 1
  %815 = extractelement <8 x ptr> %813, i32 0
  %816 = extractelement <8 x i64> %814, i32 0
  %817 = sub i64 %816, 0
  %818 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %819 = select i1 %818, i64 %817, i64 0
  %private.contiguous.address438 = getelementptr i8, ptr %815, i64 %819
  %private.contiguous.preserve439 = load <8 x float>, ptr %private.contiguous.address438, align 4
  %820 = select <8 x i1> %71, <8 x float> %671, <8 x float> %private.contiguous.preserve439
  store <8 x float> %820, ptr %private.contiguous.address438, align 4
  %821 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %822 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %823 = add <8 x i64> %822, splat (i64 288)
  %824 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %821, 0
  %825 = insertvalue { <8 x ptr>, <8 x i64> } %824, <8 x i64> %823, 1
  %826 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %827 = extractvalue { <8 x ptr>, <8 x i64> } %825, 1
  %828 = extractelement <8 x ptr> %826, i32 0
  %829 = extractelement <8 x i64> %827, i32 0
  %830 = sub i64 %829, 0
  %831 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %832 = select i1 %831, i64 %830, i64 0
  %private.contiguous.address440 = getelementptr i8, ptr %828, i64 %832
  %private.contiguous.preserve441 = load <8 x float>, ptr %private.contiguous.address440, align 4
  %833 = select <8 x i1> %71, <8 x float> %674, <8 x float> %private.contiguous.preserve441
  store <8 x float> %833, ptr %private.contiguous.address440, align 4
  %834 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %835 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %836 = add <8 x i64> %835, splat (i64 320)
  %837 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %834, 0
  %838 = insertvalue { <8 x ptr>, <8 x i64> } %837, <8 x i64> %836, 1
  %839 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %840 = extractvalue { <8 x ptr>, <8 x i64> } %838, 1
  %841 = extractelement <8 x ptr> %839, i32 0
  %842 = extractelement <8 x i64> %840, i32 0
  %843 = sub i64 %842, 0
  %844 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %845 = select i1 %844, i64 %843, i64 0
  %private.contiguous.address442 = getelementptr i8, ptr %841, i64 %845
  %private.contiguous.preserve443 = load <8 x float>, ptr %private.contiguous.address442, align 4
  %846 = select <8 x i1> %71, <8 x float> %677, <8 x float> %private.contiguous.preserve443
  store <8 x float> %846, ptr %private.contiguous.address442, align 4
  %847 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %848 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %849 = add <8 x i64> %848, splat (i64 352)
  %850 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %847, 0
  %851 = insertvalue { <8 x ptr>, <8 x i64> } %850, <8 x i64> %849, 1
  %852 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %853 = extractvalue { <8 x ptr>, <8 x i64> } %851, 1
  %854 = extractelement <8 x ptr> %852, i32 0
  %855 = extractelement <8 x i64> %853, i32 0
  %856 = sub i64 %855, 0
  %857 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %858 = select i1 %857, i64 %856, i64 0
  %private.contiguous.address444 = getelementptr i8, ptr %854, i64 %858
  %private.contiguous.preserve445 = load <8 x float>, ptr %private.contiguous.address444, align 4
  %859 = select <8 x i1> %71, <8 x float> %680, <8 x float> %private.contiguous.preserve445
  store <8 x float> %859, ptr %private.contiguous.address444, align 4
  %860 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %861 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %862 = add <8 x i64> %861, splat (i64 384)
  %863 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %860, 0
  %864 = insertvalue { <8 x ptr>, <8 x i64> } %863, <8 x i64> %862, 1
  %865 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %866 = extractvalue { <8 x ptr>, <8 x i64> } %864, 1
  %867 = extractelement <8 x ptr> %865, i32 0
  %868 = extractelement <8 x i64> %866, i32 0
  %869 = sub i64 %868, 0
  %870 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %871 = select i1 %870, i64 %869, i64 0
  %private.contiguous.address446 = getelementptr i8, ptr %867, i64 %871
  %private.contiguous.preserve447 = load <8 x float>, ptr %private.contiguous.address446, align 4
  %872 = select <8 x i1> %71, <8 x float> %683, <8 x float> %private.contiguous.preserve447
  store <8 x float> %872, ptr %private.contiguous.address446, align 4
  %873 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %874 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %875 = add <8 x i64> %874, splat (i64 416)
  %876 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %873, 0
  %877 = insertvalue { <8 x ptr>, <8 x i64> } %876, <8 x i64> %875, 1
  %878 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %879 = extractvalue { <8 x ptr>, <8 x i64> } %877, 1
  %880 = extractelement <8 x ptr> %878, i32 0
  %881 = extractelement <8 x i64> %879, i32 0
  %882 = sub i64 %881, 0
  %883 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %884 = select i1 %883, i64 %882, i64 0
  %private.contiguous.address448 = getelementptr i8, ptr %880, i64 %884
  %private.contiguous.preserve449 = load <8 x float>, ptr %private.contiguous.address448, align 4
  %885 = select <8 x i1> %71, <8 x float> %686, <8 x float> %private.contiguous.preserve449
  store <8 x float> %885, ptr %private.contiguous.address448, align 4
  %886 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %887 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %888 = add <8 x i64> %887, splat (i64 448)
  %889 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %886, 0
  %890 = insertvalue { <8 x ptr>, <8 x i64> } %889, <8 x i64> %888, 1
  %891 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %892 = extractvalue { <8 x ptr>, <8 x i64> } %890, 1
  %893 = extractelement <8 x ptr> %891, i32 0
  %894 = extractelement <8 x i64> %892, i32 0
  %895 = sub i64 %894, 0
  %896 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %897 = select i1 %896, i64 %895, i64 0
  %private.contiguous.address450 = getelementptr i8, ptr %893, i64 %897
  %private.contiguous.preserve451 = load <8 x float>, ptr %private.contiguous.address450, align 4
  %898 = select <8 x i1> %71, <8 x float> %689, <8 x float> %private.contiguous.preserve451
  store <8 x float> %898, ptr %private.contiguous.address450, align 4
  %899 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %900 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %901 = add <8 x i64> %900, splat (i64 480)
  %902 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %899, 0
  %903 = insertvalue { <8 x ptr>, <8 x i64> } %902, <8 x i64> %901, 1
  %904 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %905 = extractvalue { <8 x ptr>, <8 x i64> } %903, 1
  %906 = extractelement <8 x ptr> %904, i32 0
  %907 = extractelement <8 x i64> %905, i32 0
  %908 = sub i64 %907, 0
  %909 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %910 = select i1 %909, i64 %908, i64 0
  %private.contiguous.address452 = getelementptr i8, ptr %906, i64 %910
  %private.contiguous.preserve453 = load <8 x float>, ptr %private.contiguous.address452, align 4
  %911 = select <8 x i1> %71, <8 x float> %692, <8 x float> %private.contiguous.preserve453
  store <8 x float> %911, ptr %private.contiguous.address452, align 4
  store i64 0, ptr %.slot94, align 4
  %912 = load <8 x float>, ptr %.slot95, align 32
  %913 = select <8 x i1> %71, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %912
  store <8 x float> %913, ptr %.slot95, align 32
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state454 = load i64, ptr %.slot94, align 4
  %914 = icmp slt i64 %.state454, 16
  br i1 %914, label %direct.true455, label %direct.false456

direct.schedule.23:                               ; preds = %direct.true455
  %.state457 = load i64, ptr %.slot94, align 4
  %915 = sdiv i64 %.state457, 1
  %.spill.load458 = load i64, ptr %.spill31, align 4
  %916 = mul i64 %.spill.load458, 1
  %917 = add i64 %916, 0
  %918 = mul i64 %917, 1
  %919 = add i64 %918, 0
  %920 = mul i64 %919, 16
  %921 = add i64 %920, %915
  %tile_snapshot.spill.load459 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill93, align 64
  %922 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load459, 0
  %923 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load459, 1
  %.splatinsert460 = insertelement <8 x i64> poison, i64 %921, i64 0
  %.splat461 = shufflevector <8 x i64> %.splatinsert460, <8 x i64> poison, <8 x i32> zeroinitializer
  %924 = mul <8 x i64> %.splat461, splat (i64 32)
  %925 = add <8 x i64> %923, %924
  %926 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %922, 0
  %927 = insertvalue { <8 x ptr>, <8 x i64> } %926, <8 x i64> %925, 1
  %928 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %929 = extractvalue { <8 x ptr>, <8 x i64> } %927, 1
  %930 = extractelement <8 x ptr> %928, i32 0
  %931 = extractelement <8 x i64> %929, i32 0
  %932 = sub i64 %931, 0
  %933 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %934 = select i1 %933, i64 %932, i64 0
  %private.contiguous.address462 = getelementptr i8, ptr %930, i64 %934
  %private.contiguous.load463 = load <8 x float>, ptr %private.contiguous.address462, align 4
  %935 = select <8 x i1> %71, <8 x float> %private.contiguous.load463, <8 x float> zeroinitializer
  %.state464 = load <8 x float>, ptr %.slot95, align 32
  %936 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state464, <8 x float> %935)
  %.state465 = load i64, ptr %.slot94, align 4
  %937 = add i64 %.state465, 1
  store i64 %937, ptr %.slot94, align 4
  %938 = load <8 x float>, ptr %.slot95, align 32
  %939 = select <8 x i1> %71, <8 x float> %936, <8 x float> %938
  store <8 x float> %939, ptr %.slot95, align 32
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false456
  %.state466 = load <8 x float>, ptr %.slot35, align 32
  %.state467 = load <8 x float>, ptr %.slot95, align 32
  %940 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state466, <8 x float> %.state467)
  %941 = load <8 x float>, ptr %.spill96, align 32
  %942 = select <8 x i1> %71, <8 x float> %940, <8 x float> %941
  store <8 x float> %942, ptr %.spill96, align 32
  %.state468 = load <8 x float>, ptr %.slot35, align 32
  %943 = fsub <8 x float> %.state468, %940
  %944 = select <8 x i1> %71, <8 x float> %943, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %944)
  %945 = load <8 x float>, ptr %.spill97, align 32
  %946 = select <8 x i1> %71, <8 x float> %native.exp, <8 x float> %945
  store <8 x float> %946, ptr %.spill97, align 32
  %.spill.load469 = load <8 x float>, ptr %.spill77, align 32
  %947 = fsub <8 x float> %.spill.load469, %940
  %.spill.load470 = load <8 x float>, ptr %.spill78, align 32
  %948 = fsub <8 x float> %.spill.load470, %940
  %.spill.load471 = load <8 x float>, ptr %.spill79, align 32
  %949 = fsub <8 x float> %.spill.load471, %940
  %.spill.load472 = load <8 x float>, ptr %.spill80, align 32
  %950 = fsub <8 x float> %.spill.load472, %940
  %.spill.load473 = load <8 x float>, ptr %.spill81, align 32
  %951 = fsub <8 x float> %.spill.load473, %940
  %.spill.load474 = load <8 x float>, ptr %.spill82, align 32
  %952 = fsub <8 x float> %.spill.load474, %940
  %.spill.load475 = load <8 x float>, ptr %.spill83, align 32
  %953 = fsub <8 x float> %.spill.load475, %940
  %.spill.load476 = load <8 x float>, ptr %.spill84, align 32
  %954 = fsub <8 x float> %.spill.load476, %940
  %.spill.load477 = load <8 x float>, ptr %.spill85, align 32
  %955 = fsub <8 x float> %.spill.load477, %940
  %.spill.load478 = load <8 x float>, ptr %.spill86, align 32
  %956 = fsub <8 x float> %.spill.load478, %940
  %.spill.load479 = load <8 x float>, ptr %.spill87, align 32
  %957 = fsub <8 x float> %.spill.load479, %940
  %.spill.load480 = load <8 x float>, ptr %.spill88, align 32
  %958 = fsub <8 x float> %.spill.load480, %940
  %.spill.load481 = load <8 x float>, ptr %.spill89, align 32
  %959 = fsub <8 x float> %.spill.load481, %940
  %.spill.load482 = load <8 x float>, ptr %.spill90, align 32
  %960 = fsub <8 x float> %.spill.load482, %940
  %.spill.load483 = load <8 x float>, ptr %.spill91, align 32
  %961 = fsub <8 x float> %.spill.load483, %940
  %.spill.load484 = load <8 x float>, ptr %.spill92, align 32
  %962 = fsub <8 x float> %.spill.load484, %940
  %963 = select <8 x i1> %71, <8 x float> %947, <8 x float> zeroinitializer
  %native.exp485 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %963)
  %964 = select <8 x i1> %71, <8 x float> %948, <8 x float> zeroinitializer
  %native.exp486 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %964)
  %965 = select <8 x i1> %71, <8 x float> %949, <8 x float> zeroinitializer
  %native.exp487 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %965)
  %966 = select <8 x i1> %71, <8 x float> %950, <8 x float> zeroinitializer
  %native.exp488 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %966)
  %967 = select <8 x i1> %71, <8 x float> %951, <8 x float> zeroinitializer
  %native.exp489 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %967)
  %968 = select <8 x i1> %71, <8 x float> %952, <8 x float> zeroinitializer
  %native.exp490 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %968)
  %969 = select <8 x i1> %71, <8 x float> %953, <8 x float> zeroinitializer
  %native.exp491 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %969)
  %970 = select <8 x i1> %71, <8 x float> %954, <8 x float> zeroinitializer
  %native.exp492 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %970)
  %971 = select <8 x i1> %71, <8 x float> %955, <8 x float> zeroinitializer
  %native.exp493 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %971)
  %972 = select <8 x i1> %71, <8 x float> %956, <8 x float> zeroinitializer
  %native.exp494 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %972)
  %973 = select <8 x i1> %71, <8 x float> %957, <8 x float> zeroinitializer
  %native.exp495 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %973)
  %974 = select <8 x i1> %71, <8 x float> %958, <8 x float> zeroinitializer
  %native.exp496 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %974)
  %975 = select <8 x i1> %71, <8 x float> %959, <8 x float> zeroinitializer
  %native.exp497 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %975)
  %976 = select <8 x i1> %71, <8 x float> %960, <8 x float> zeroinitializer
  %native.exp498 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %976)
  %977 = select <8 x i1> %71, <8 x float> %961, <8 x float> zeroinitializer
  %native.exp499 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %977)
  %978 = select <8 x i1> %71, <8 x float> %962, <8 x float> zeroinitializer
  %native.exp500 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %978)
  %.spill.load501 = load i1, ptr %.spill61, align 1
  %.splatinsert502 = insertelement <8 x i1> poison, i1 %.spill.load501, i64 0
  %.splat503 = shufflevector <8 x i1> %.splatinsert502, <8 x i1> poison, <8 x i32> zeroinitializer
  %979 = select <8 x i1> %.splat503, <8 x float> %native.exp485, <8 x float> zeroinitializer
  %.spill.load504 = load i1, ptr %.spill62, align 1
  %.splatinsert505 = insertelement <8 x i1> poison, i1 %.spill.load504, i64 0
  %.splat506 = shufflevector <8 x i1> %.splatinsert505, <8 x i1> poison, <8 x i32> zeroinitializer
  %980 = select <8 x i1> %.splat506, <8 x float> %native.exp486, <8 x float> zeroinitializer
  %.spill.load507 = load i1, ptr %.spill63, align 1
  %.splatinsert508 = insertelement <8 x i1> poison, i1 %.spill.load507, i64 0
  %.splat509 = shufflevector <8 x i1> %.splatinsert508, <8 x i1> poison, <8 x i32> zeroinitializer
  %981 = select <8 x i1> %.splat509, <8 x float> %native.exp487, <8 x float> zeroinitializer
  %.spill.load510 = load i1, ptr %.spill64, align 1
  %.splatinsert511 = insertelement <8 x i1> poison, i1 %.spill.load510, i64 0
  %.splat512 = shufflevector <8 x i1> %.splatinsert511, <8 x i1> poison, <8 x i32> zeroinitializer
  %982 = select <8 x i1> %.splat512, <8 x float> %native.exp488, <8 x float> zeroinitializer
  %.spill.load513 = load i1, ptr %.spill65, align 1
  %.splatinsert514 = insertelement <8 x i1> poison, i1 %.spill.load513, i64 0
  %.splat515 = shufflevector <8 x i1> %.splatinsert514, <8 x i1> poison, <8 x i32> zeroinitializer
  %983 = select <8 x i1> %.splat515, <8 x float> %native.exp489, <8 x float> zeroinitializer
  %.spill.load516 = load i1, ptr %.spill66, align 1
  %.splatinsert517 = insertelement <8 x i1> poison, i1 %.spill.load516, i64 0
  %.splat518 = shufflevector <8 x i1> %.splatinsert517, <8 x i1> poison, <8 x i32> zeroinitializer
  %984 = select <8 x i1> %.splat518, <8 x float> %native.exp490, <8 x float> zeroinitializer
  %.spill.load519 = load i1, ptr %.spill67, align 1
  %.splatinsert520 = insertelement <8 x i1> poison, i1 %.spill.load519, i64 0
  %.splat521 = shufflevector <8 x i1> %.splatinsert520, <8 x i1> poison, <8 x i32> zeroinitializer
  %985 = select <8 x i1> %.splat521, <8 x float> %native.exp491, <8 x float> zeroinitializer
  %.spill.load522 = load i1, ptr %.spill68, align 1
  %.splatinsert523 = insertelement <8 x i1> poison, i1 %.spill.load522, i64 0
  %.splat524 = shufflevector <8 x i1> %.splatinsert523, <8 x i1> poison, <8 x i32> zeroinitializer
  %986 = select <8 x i1> %.splat524, <8 x float> %native.exp492, <8 x float> zeroinitializer
  %.spill.load525 = load i1, ptr %.spill69, align 1
  %.splatinsert526 = insertelement <8 x i1> poison, i1 %.spill.load525, i64 0
  %.splat527 = shufflevector <8 x i1> %.splatinsert526, <8 x i1> poison, <8 x i32> zeroinitializer
  %987 = select <8 x i1> %.splat527, <8 x float> %native.exp493, <8 x float> zeroinitializer
  %.spill.load528 = load i1, ptr %.spill70, align 1
  %.splatinsert529 = insertelement <8 x i1> poison, i1 %.spill.load528, i64 0
  %.splat530 = shufflevector <8 x i1> %.splatinsert529, <8 x i1> poison, <8 x i32> zeroinitializer
  %988 = select <8 x i1> %.splat530, <8 x float> %native.exp494, <8 x float> zeroinitializer
  %.spill.load531 = load i1, ptr %.spill71, align 1
  %.splatinsert532 = insertelement <8 x i1> poison, i1 %.spill.load531, i64 0
  %.splat533 = shufflevector <8 x i1> %.splatinsert532, <8 x i1> poison, <8 x i32> zeroinitializer
  %989 = select <8 x i1> %.splat533, <8 x float> %native.exp495, <8 x float> zeroinitializer
  %.spill.load534 = load i1, ptr %.spill72, align 1
  %.splatinsert535 = insertelement <8 x i1> poison, i1 %.spill.load534, i64 0
  %.splat536 = shufflevector <8 x i1> %.splatinsert535, <8 x i1> poison, <8 x i32> zeroinitializer
  %990 = select <8 x i1> %.splat536, <8 x float> %native.exp496, <8 x float> zeroinitializer
  %.spill.load537 = load i1, ptr %.spill73, align 1
  %.splatinsert538 = insertelement <8 x i1> poison, i1 %.spill.load537, i64 0
  %.splat539 = shufflevector <8 x i1> %.splatinsert538, <8 x i1> poison, <8 x i32> zeroinitializer
  %991 = select <8 x i1> %.splat539, <8 x float> %native.exp497, <8 x float> zeroinitializer
  %.spill.load540 = load i1, ptr %.spill74, align 1
  %.splatinsert541 = insertelement <8 x i1> poison, i1 %.spill.load540, i64 0
  %.splat542 = shufflevector <8 x i1> %.splatinsert541, <8 x i1> poison, <8 x i32> zeroinitializer
  %992 = select <8 x i1> %.splat542, <8 x float> %native.exp498, <8 x float> zeroinitializer
  %.spill.load543 = load i1, ptr %.spill75, align 1
  %.splatinsert544 = insertelement <8 x i1> poison, i1 %.spill.load543, i64 0
  %.splat545 = shufflevector <8 x i1> %.splatinsert544, <8 x i1> poison, <8 x i32> zeroinitializer
  %993 = select <8 x i1> %.splat545, <8 x float> %native.exp499, <8 x float> zeroinitializer
  %.spill.load546 = load i1, ptr %.spill76, align 1
  %.splatinsert547 = insertelement <8 x i1> poison, i1 %.spill.load546, i64 0
  %.splat548 = shufflevector <8 x i1> %.splatinsert547, <8 x i1> poison, <8 x i32> zeroinitializer
  %994 = select <8 x i1> %.splat548, <8 x float> %native.exp500, <8 x float> zeroinitializer
  %995 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill98, align 64
  %996 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %997 = extractvalue { <8 x ptr>, <8 x i64> } %995, 0
  %998 = select <8 x i1> %71, <8 x ptr> %996, <8 x ptr> %997
  %999 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1000 = extractvalue { <8 x ptr>, <8 x i64> } %995, 1
  %1001 = select <8 x i1> %71, <8 x i64> %999, <8 x i64> %1000
  %1002 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %998, 0
  %1003 = insertvalue { <8 x ptr>, <8 x i64> } %1002, <8 x i64> %1001, 1
  store { <8 x ptr>, <8 x i64> } %1003, ptr %tile_snapshot.spill98, align 64
  %1004 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1005 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1006 = add <8 x i64> %1005, zeroinitializer
  %1007 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1004, 0
  %1008 = insertvalue { <8 x ptr>, <8 x i64> } %1007, <8 x i64> %1006, 1
  %1009 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1010 = extractvalue { <8 x ptr>, <8 x i64> } %1008, 1
  %1011 = extractelement <8 x ptr> %1009, i32 0
  %1012 = extractelement <8 x i64> %1010, i32 0
  %1013 = sub i64 %1012, 0
  %1014 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1015 = select i1 %1014, i64 %1013, i64 0
  %private.contiguous.address549 = getelementptr i8, ptr %1011, i64 %1015
  %private.contiguous.preserve550 = load <8 x float>, ptr %private.contiguous.address549, align 4
  %1016 = select <8 x i1> %71, <8 x float> %979, <8 x float> %private.contiguous.preserve550
  store <8 x float> %1016, ptr %private.contiguous.address549, align 4
  %1017 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1018 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1019 = add <8 x i64> %1018, splat (i64 32)
  %1020 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1017, 0
  %1021 = insertvalue { <8 x ptr>, <8 x i64> } %1020, <8 x i64> %1019, 1
  %1022 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1023 = extractvalue { <8 x ptr>, <8 x i64> } %1021, 1
  %1024 = extractelement <8 x ptr> %1022, i32 0
  %1025 = extractelement <8 x i64> %1023, i32 0
  %1026 = sub i64 %1025, 0
  %1027 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1028 = select i1 %1027, i64 %1026, i64 0
  %private.contiguous.address551 = getelementptr i8, ptr %1024, i64 %1028
  %private.contiguous.preserve552 = load <8 x float>, ptr %private.contiguous.address551, align 4
  %1029 = select <8 x i1> %71, <8 x float> %980, <8 x float> %private.contiguous.preserve552
  store <8 x float> %1029, ptr %private.contiguous.address551, align 4
  %1030 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1031 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1032 = add <8 x i64> %1031, splat (i64 64)
  %1033 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1030, 0
  %1034 = insertvalue { <8 x ptr>, <8 x i64> } %1033, <8 x i64> %1032, 1
  %1035 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1036 = extractvalue { <8 x ptr>, <8 x i64> } %1034, 1
  %1037 = extractelement <8 x ptr> %1035, i32 0
  %1038 = extractelement <8 x i64> %1036, i32 0
  %1039 = sub i64 %1038, 0
  %1040 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1041 = select i1 %1040, i64 %1039, i64 0
  %private.contiguous.address553 = getelementptr i8, ptr %1037, i64 %1041
  %private.contiguous.preserve554 = load <8 x float>, ptr %private.contiguous.address553, align 4
  %1042 = select <8 x i1> %71, <8 x float> %981, <8 x float> %private.contiguous.preserve554
  store <8 x float> %1042, ptr %private.contiguous.address553, align 4
  %1043 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1044 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1045 = add <8 x i64> %1044, splat (i64 96)
  %1046 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1043, 0
  %1047 = insertvalue { <8 x ptr>, <8 x i64> } %1046, <8 x i64> %1045, 1
  %1048 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1049 = extractvalue { <8 x ptr>, <8 x i64> } %1047, 1
  %1050 = extractelement <8 x ptr> %1048, i32 0
  %1051 = extractelement <8 x i64> %1049, i32 0
  %1052 = sub i64 %1051, 0
  %1053 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1054 = select i1 %1053, i64 %1052, i64 0
  %private.contiguous.address555 = getelementptr i8, ptr %1050, i64 %1054
  %private.contiguous.preserve556 = load <8 x float>, ptr %private.contiguous.address555, align 4
  %1055 = select <8 x i1> %71, <8 x float> %982, <8 x float> %private.contiguous.preserve556
  store <8 x float> %1055, ptr %private.contiguous.address555, align 4
  %1056 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1057 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1058 = add <8 x i64> %1057, splat (i64 128)
  %1059 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1056, 0
  %1060 = insertvalue { <8 x ptr>, <8 x i64> } %1059, <8 x i64> %1058, 1
  %1061 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1062 = extractvalue { <8 x ptr>, <8 x i64> } %1060, 1
  %1063 = extractelement <8 x ptr> %1061, i32 0
  %1064 = extractelement <8 x i64> %1062, i32 0
  %1065 = sub i64 %1064, 0
  %1066 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1067 = select i1 %1066, i64 %1065, i64 0
  %private.contiguous.address557 = getelementptr i8, ptr %1063, i64 %1067
  %private.contiguous.preserve558 = load <8 x float>, ptr %private.contiguous.address557, align 4
  %1068 = select <8 x i1> %71, <8 x float> %983, <8 x float> %private.contiguous.preserve558
  store <8 x float> %1068, ptr %private.contiguous.address557, align 4
  %1069 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1070 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1071 = add <8 x i64> %1070, splat (i64 160)
  %1072 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1069, 0
  %1073 = insertvalue { <8 x ptr>, <8 x i64> } %1072, <8 x i64> %1071, 1
  %1074 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1075 = extractvalue { <8 x ptr>, <8 x i64> } %1073, 1
  %1076 = extractelement <8 x ptr> %1074, i32 0
  %1077 = extractelement <8 x i64> %1075, i32 0
  %1078 = sub i64 %1077, 0
  %1079 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1080 = select i1 %1079, i64 %1078, i64 0
  %private.contiguous.address559 = getelementptr i8, ptr %1076, i64 %1080
  %private.contiguous.preserve560 = load <8 x float>, ptr %private.contiguous.address559, align 4
  %1081 = select <8 x i1> %71, <8 x float> %984, <8 x float> %private.contiguous.preserve560
  store <8 x float> %1081, ptr %private.contiguous.address559, align 4
  %1082 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1083 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1084 = add <8 x i64> %1083, splat (i64 192)
  %1085 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1082, 0
  %1086 = insertvalue { <8 x ptr>, <8 x i64> } %1085, <8 x i64> %1084, 1
  %1087 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1088 = extractvalue { <8 x ptr>, <8 x i64> } %1086, 1
  %1089 = extractelement <8 x ptr> %1087, i32 0
  %1090 = extractelement <8 x i64> %1088, i32 0
  %1091 = sub i64 %1090, 0
  %1092 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1093 = select i1 %1092, i64 %1091, i64 0
  %private.contiguous.address561 = getelementptr i8, ptr %1089, i64 %1093
  %private.contiguous.preserve562 = load <8 x float>, ptr %private.contiguous.address561, align 4
  %1094 = select <8 x i1> %71, <8 x float> %985, <8 x float> %private.contiguous.preserve562
  store <8 x float> %1094, ptr %private.contiguous.address561, align 4
  %1095 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1096 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1097 = add <8 x i64> %1096, splat (i64 224)
  %1098 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1095, 0
  %1099 = insertvalue { <8 x ptr>, <8 x i64> } %1098, <8 x i64> %1097, 1
  %1100 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1101 = extractvalue { <8 x ptr>, <8 x i64> } %1099, 1
  %1102 = extractelement <8 x ptr> %1100, i32 0
  %1103 = extractelement <8 x i64> %1101, i32 0
  %1104 = sub i64 %1103, 0
  %1105 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1106 = select i1 %1105, i64 %1104, i64 0
  %private.contiguous.address563 = getelementptr i8, ptr %1102, i64 %1106
  %private.contiguous.preserve564 = load <8 x float>, ptr %private.contiguous.address563, align 4
  %1107 = select <8 x i1> %71, <8 x float> %986, <8 x float> %private.contiguous.preserve564
  store <8 x float> %1107, ptr %private.contiguous.address563, align 4
  %1108 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1109 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1110 = add <8 x i64> %1109, splat (i64 256)
  %1111 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1108, 0
  %1112 = insertvalue { <8 x ptr>, <8 x i64> } %1111, <8 x i64> %1110, 1
  %1113 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1114 = extractvalue { <8 x ptr>, <8 x i64> } %1112, 1
  %1115 = extractelement <8 x ptr> %1113, i32 0
  %1116 = extractelement <8 x i64> %1114, i32 0
  %1117 = sub i64 %1116, 0
  %1118 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1119 = select i1 %1118, i64 %1117, i64 0
  %private.contiguous.address565 = getelementptr i8, ptr %1115, i64 %1119
  %private.contiguous.preserve566 = load <8 x float>, ptr %private.contiguous.address565, align 4
  %1120 = select <8 x i1> %71, <8 x float> %987, <8 x float> %private.contiguous.preserve566
  store <8 x float> %1120, ptr %private.contiguous.address565, align 4
  %1121 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1122 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1123 = add <8 x i64> %1122, splat (i64 288)
  %1124 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1121, 0
  %1125 = insertvalue { <8 x ptr>, <8 x i64> } %1124, <8 x i64> %1123, 1
  %1126 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1127 = extractvalue { <8 x ptr>, <8 x i64> } %1125, 1
  %1128 = extractelement <8 x ptr> %1126, i32 0
  %1129 = extractelement <8 x i64> %1127, i32 0
  %1130 = sub i64 %1129, 0
  %1131 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1132 = select i1 %1131, i64 %1130, i64 0
  %private.contiguous.address567 = getelementptr i8, ptr %1128, i64 %1132
  %private.contiguous.preserve568 = load <8 x float>, ptr %private.contiguous.address567, align 4
  %1133 = select <8 x i1> %71, <8 x float> %988, <8 x float> %private.contiguous.preserve568
  store <8 x float> %1133, ptr %private.contiguous.address567, align 4
  %1134 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1135 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1136 = add <8 x i64> %1135, splat (i64 320)
  %1137 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1134, 0
  %1138 = insertvalue { <8 x ptr>, <8 x i64> } %1137, <8 x i64> %1136, 1
  %1139 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1140 = extractvalue { <8 x ptr>, <8 x i64> } %1138, 1
  %1141 = extractelement <8 x ptr> %1139, i32 0
  %1142 = extractelement <8 x i64> %1140, i32 0
  %1143 = sub i64 %1142, 0
  %1144 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1145 = select i1 %1144, i64 %1143, i64 0
  %private.contiguous.address569 = getelementptr i8, ptr %1141, i64 %1145
  %private.contiguous.preserve570 = load <8 x float>, ptr %private.contiguous.address569, align 4
  %1146 = select <8 x i1> %71, <8 x float> %989, <8 x float> %private.contiguous.preserve570
  store <8 x float> %1146, ptr %private.contiguous.address569, align 4
  %1147 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1148 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1149 = add <8 x i64> %1148, splat (i64 352)
  %1150 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1147, 0
  %1151 = insertvalue { <8 x ptr>, <8 x i64> } %1150, <8 x i64> %1149, 1
  %1152 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1153 = extractvalue { <8 x ptr>, <8 x i64> } %1151, 1
  %1154 = extractelement <8 x ptr> %1152, i32 0
  %1155 = extractelement <8 x i64> %1153, i32 0
  %1156 = sub i64 %1155, 0
  %1157 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1158 = select i1 %1157, i64 %1156, i64 0
  %private.contiguous.address571 = getelementptr i8, ptr %1154, i64 %1158
  %private.contiguous.preserve572 = load <8 x float>, ptr %private.contiguous.address571, align 4
  %1159 = select <8 x i1> %71, <8 x float> %990, <8 x float> %private.contiguous.preserve572
  store <8 x float> %1159, ptr %private.contiguous.address571, align 4
  %1160 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1161 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1162 = add <8 x i64> %1161, splat (i64 384)
  %1163 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1160, 0
  %1164 = insertvalue { <8 x ptr>, <8 x i64> } %1163, <8 x i64> %1162, 1
  %1165 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1166 = extractvalue { <8 x ptr>, <8 x i64> } %1164, 1
  %1167 = extractelement <8 x ptr> %1165, i32 0
  %1168 = extractelement <8 x i64> %1166, i32 0
  %1169 = sub i64 %1168, 0
  %1170 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1171 = select i1 %1170, i64 %1169, i64 0
  %private.contiguous.address573 = getelementptr i8, ptr %1167, i64 %1171
  %private.contiguous.preserve574 = load <8 x float>, ptr %private.contiguous.address573, align 4
  %1172 = select <8 x i1> %71, <8 x float> %991, <8 x float> %private.contiguous.preserve574
  store <8 x float> %1172, ptr %private.contiguous.address573, align 4
  %1173 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1174 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1175 = add <8 x i64> %1174, splat (i64 416)
  %1176 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1173, 0
  %1177 = insertvalue { <8 x ptr>, <8 x i64> } %1176, <8 x i64> %1175, 1
  %1178 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1179 = extractvalue { <8 x ptr>, <8 x i64> } %1177, 1
  %1180 = extractelement <8 x ptr> %1178, i32 0
  %1181 = extractelement <8 x i64> %1179, i32 0
  %1182 = sub i64 %1181, 0
  %1183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1184 = select i1 %1183, i64 %1182, i64 0
  %private.contiguous.address575 = getelementptr i8, ptr %1180, i64 %1184
  %private.contiguous.preserve576 = load <8 x float>, ptr %private.contiguous.address575, align 4
  %1185 = select <8 x i1> %71, <8 x float> %992, <8 x float> %private.contiguous.preserve576
  store <8 x float> %1185, ptr %private.contiguous.address575, align 4
  %1186 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1187 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1188 = add <8 x i64> %1187, splat (i64 448)
  %1189 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1186, 0
  %1190 = insertvalue { <8 x ptr>, <8 x i64> } %1189, <8 x i64> %1188, 1
  %1191 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1192 = extractvalue { <8 x ptr>, <8 x i64> } %1190, 1
  %1193 = extractelement <8 x ptr> %1191, i32 0
  %1194 = extractelement <8 x i64> %1192, i32 0
  %1195 = sub i64 %1194, 0
  %1196 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1197 = select i1 %1196, i64 %1195, i64 0
  %private.contiguous.address577 = getelementptr i8, ptr %1193, i64 %1197
  %private.contiguous.preserve578 = load <8 x float>, ptr %private.contiguous.address577, align 4
  %1198 = select <8 x i1> %71, <8 x float> %993, <8 x float> %private.contiguous.preserve578
  store <8 x float> %1198, ptr %private.contiguous.address577, align 4
  %1199 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1200 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1201 = add <8 x i64> %1200, splat (i64 480)
  %1202 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1199, 0
  %1203 = insertvalue { <8 x ptr>, <8 x i64> } %1202, <8 x i64> %1201, 1
  %1204 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1205 = extractvalue { <8 x ptr>, <8 x i64> } %1203, 1
  %1206 = extractelement <8 x ptr> %1204, i32 0
  %1207 = extractelement <8 x i64> %1205, i32 0
  %1208 = sub i64 %1207, 0
  %1209 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1210 = select i1 %1209, i64 %1208, i64 0
  %private.contiguous.address579 = getelementptr i8, ptr %1206, i64 %1210
  %private.contiguous.preserve580 = load <8 x float>, ptr %private.contiguous.address579, align 4
  %1211 = select <8 x i1> %71, <8 x float> %994, <8 x float> %private.contiguous.preserve580
  store <8 x float> %1211, ptr %private.contiguous.address579, align 4
  %.state581 = load <8 x float>, ptr %.slot36, align 32
  %1212 = fmul <8 x float> %.state581, %native.exp
  %1213 = load <8 x float>, ptr %.spill99, align 32
  %1214 = select <8 x i1> %71, <8 x float> %1212, <8 x float> %1213
  store <8 x float> %1214, ptr %.spill99, align 32
  store i64 0, ptr %.slot100, align 4
  %1215 = load <8 x float>, ptr %.slot101, align 32
  %1216 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1215
  store <8 x float> %1216, ptr %.slot101, align 32
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.26, %direct.schedule.24
  %.state582 = load i64, ptr %.slot100, align 4
  %1217 = icmp slt i64 %.state582, 16
  br i1 %1217, label %direct.true583, label %direct.false584

direct.schedule.26:                               ; preds = %direct.true583
  %.state585 = load i64, ptr %.slot100, align 4
  %1218 = sdiv i64 %.state585, 1
  %.spill.load586 = load i64, ptr %.spill31, align 4
  %1219 = mul i64 %.spill.load586, 1
  %1220 = add i64 %1219, 0
  %1221 = mul i64 %1220, 1
  %1222 = add i64 %1221, 0
  %1223 = mul i64 %1222, 16
  %1224 = add i64 %1223, %1218
  %tile_snapshot.spill.load587 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill98, align 64
  %1225 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load587, 0
  %1226 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load587, 1
  %.splatinsert588 = insertelement <8 x i64> poison, i64 %1224, i64 0
  %.splat589 = shufflevector <8 x i64> %.splatinsert588, <8 x i64> poison, <8 x i32> zeroinitializer
  %1227 = mul <8 x i64> %.splat589, splat (i64 32)
  %1228 = add <8 x i64> %1226, %1227
  %1229 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1225, 0
  %1230 = insertvalue { <8 x ptr>, <8 x i64> } %1229, <8 x i64> %1228, 1
  %1231 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1232 = extractvalue { <8 x ptr>, <8 x i64> } %1230, 1
  %1233 = extractelement <8 x ptr> %1231, i32 0
  %1234 = extractelement <8 x i64> %1232, i32 0
  %1235 = sub i64 %1234, 0
  %1236 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1237 = select i1 %1236, i64 %1235, i64 0
  %private.contiguous.address590 = getelementptr i8, ptr %1233, i64 %1237
  %private.contiguous.load591 = load <8 x float>, ptr %private.contiguous.address590, align 4
  %1238 = select <8 x i1> %71, <8 x float> %private.contiguous.load591, <8 x float> zeroinitializer
  %.state592 = load <8 x float>, ptr %.slot101, align 32
  %1239 = fadd <8 x float> %.state592, %1238
  %.state593 = load i64, ptr %.slot100, align 4
  %1240 = add i64 %.state593, 1
  store i64 %1240, ptr %.slot100, align 4
  %1241 = load <8 x float>, ptr %.slot101, align 32
  %1242 = select <8 x i1> %71, <8 x float> %1239, <8 x float> %1241
  store <8 x float> %1242, ptr %.slot101, align 32
  br label %direct.schedule.25

direct.schedule.27:                               ; preds = %direct.false584
  %.spill.load594 = load <8 x float>, ptr %.spill99, align 32
  %.state595 = load <8 x float>, ptr %.slot101, align 32
  %1243 = fadd <8 x float> %.spill.load594, %.state595
  %1244 = load <8 x float>, ptr %.spill102, align 32
  %1245 = select <8 x i1> %71, <8 x float> %1243, <8 x float> %1244
  store <8 x float> %1245, ptr %.spill102, align 32
  %1246 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %1247 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1248 = extractvalue { <8 x ptr>, <8 x i64> } %1246, 0
  %1249 = select <8 x i1> %71, <8 x ptr> %1247, <8 x ptr> %1248
  %1250 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1251 = extractvalue { <8 x ptr>, <8 x i64> } %1246, 1
  %1252 = select <8 x i1> %71, <8 x i64> %1250, <8 x i64> %1251
  %1253 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1249, 0
  %1254 = insertvalue { <8 x ptr>, <8 x i64> } %1253, <8 x i64> %1252, 1
  store { <8 x ptr>, <8 x i64> } %1254, ptr %tile_snapshot.spill103, align 64
  store i64 0, ptr %.slot104, align 4
  br label %direct.schedule.28

direct.schedule.28:                               ; preds = %direct.schedule.32, %direct.schedule.27
  %.state596 = load i64, ptr %.slot104, align 4
  %1255 = icmp slt i64 %.state596, 24
  br i1 %1255, label %direct.true597, label %direct.false598

direct.schedule.29:                               ; preds = %direct.true597
  %.state599 = load i64, ptr %.slot104, align 4
  %1256 = mul i64 %.state599, 4
  %1257 = add i64 0, %1256
  %1258 = add i64 %1257, 0
  store i64 %1258, ptr %.spill105, align 4
  %1259 = add i64 0, %1258
  %tile_snapshot.spill.load600 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1260 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load600, 0
  %1261 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load600, 1
  %.splatinsert601 = insertelement <8 x i64> poison, i64 %1259, i64 0
  %.splat602 = shufflevector <8 x i64> %.splatinsert601, <8 x i64> poison, <8 x i32> zeroinitializer
  %1262 = mul <8 x i64> %.splat602, splat (i64 32)
  %1263 = add <8 x i64> %1261, %1262
  %1264 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1260, 0
  %1265 = insertvalue { <8 x ptr>, <8 x i64> } %1264, <8 x i64> %1263, 1
  %1266 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1267 = extractvalue { <8 x ptr>, <8 x i64> } %1265, 1
  %1268 = extractelement <8 x ptr> %1266, i32 0
  %1269 = extractelement <8 x i64> %1267, i32 0
  %1270 = sub i64 %1269, 0
  %1271 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1272 = select i1 %1271, i64 %1270, i64 0
  %private.contiguous.address603 = getelementptr i8, ptr %1268, i64 %1272
  %private.contiguous.load604 = load <8 x float>, ptr %private.contiguous.address603, align 4
  %1273 = select <8 x i1> %71, <8 x float> %private.contiguous.load604, <8 x float> zeroinitializer
  %.spill.load605 = load <8 x float>, ptr %.spill97, align 32
  %1274 = fmul <8 x float> %1273, %.spill.load605
  %1275 = add i64 %1257, 1
  store i64 %1275, ptr %.spill106, align 4
  %1276 = add i64 0, %1275
  %tile_snapshot.spill.load606 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1277 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load606, 0
  %1278 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load606, 1
  %.splatinsert607 = insertelement <8 x i64> poison, i64 %1276, i64 0
  %.splat608 = shufflevector <8 x i64> %.splatinsert607, <8 x i64> poison, <8 x i32> zeroinitializer
  %1279 = mul <8 x i64> %.splat608, splat (i64 32)
  %1280 = add <8 x i64> %1278, %1279
  %1281 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1277, 0
  %1282 = insertvalue { <8 x ptr>, <8 x i64> } %1281, <8 x i64> %1280, 1
  %1283 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1284 = extractvalue { <8 x ptr>, <8 x i64> } %1282, 1
  %1285 = extractelement <8 x ptr> %1283, i32 0
  %1286 = extractelement <8 x i64> %1284, i32 0
  %1287 = sub i64 %1286, 0
  %1288 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1289 = select i1 %1288, i64 %1287, i64 0
  %private.contiguous.address609 = getelementptr i8, ptr %1285, i64 %1289
  %private.contiguous.load610 = load <8 x float>, ptr %private.contiguous.address609, align 4
  %1290 = select <8 x i1> %71, <8 x float> %private.contiguous.load610, <8 x float> zeroinitializer
  %.spill.load611 = load <8 x float>, ptr %.spill97, align 32
  %1291 = fmul <8 x float> %1290, %.spill.load611
  %1292 = add i64 %1257, 2
  store i64 %1292, ptr %.spill107, align 4
  %1293 = add i64 0, %1292
  %tile_snapshot.spill.load612 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1294 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load612, 0
  %1295 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load612, 1
  %.splatinsert613 = insertelement <8 x i64> poison, i64 %1293, i64 0
  %.splat614 = shufflevector <8 x i64> %.splatinsert613, <8 x i64> poison, <8 x i32> zeroinitializer
  %1296 = mul <8 x i64> %.splat614, splat (i64 32)
  %1297 = add <8 x i64> %1295, %1296
  %1298 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1294, 0
  %1299 = insertvalue { <8 x ptr>, <8 x i64> } %1298, <8 x i64> %1297, 1
  %1300 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1301 = extractvalue { <8 x ptr>, <8 x i64> } %1299, 1
  %1302 = extractelement <8 x ptr> %1300, i32 0
  %1303 = extractelement <8 x i64> %1301, i32 0
  %1304 = sub i64 %1303, 0
  %1305 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1306 = select i1 %1305, i64 %1304, i64 0
  %private.contiguous.address615 = getelementptr i8, ptr %1302, i64 %1306
  %private.contiguous.load616 = load <8 x float>, ptr %private.contiguous.address615, align 4
  %1307 = select <8 x i1> %71, <8 x float> %private.contiguous.load616, <8 x float> zeroinitializer
  %.spill.load617 = load <8 x float>, ptr %.spill97, align 32
  %1308 = fmul <8 x float> %1307, %.spill.load617
  %1309 = add i64 %1257, 3
  store i64 %1309, ptr %.spill108, align 4
  %1310 = add i64 0, %1309
  %tile_snapshot.spill.load618 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1311 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load618, 0
  %1312 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load618, 1
  %.splatinsert619 = insertelement <8 x i64> poison, i64 %1310, i64 0
  %.splat620 = shufflevector <8 x i64> %.splatinsert619, <8 x i64> poison, <8 x i32> zeroinitializer
  %1313 = mul <8 x i64> %.splat620, splat (i64 32)
  %1314 = add <8 x i64> %1312, %1313
  %1315 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1311, 0
  %1316 = insertvalue { <8 x ptr>, <8 x i64> } %1315, <8 x i64> %1314, 1
  %1317 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1318 = extractvalue { <8 x ptr>, <8 x i64> } %1316, 1
  %1319 = extractelement <8 x ptr> %1317, i32 0
  %1320 = extractelement <8 x i64> %1318, i32 0
  %1321 = sub i64 %1320, 0
  %1322 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1323 = select i1 %1322, i64 %1321, i64 0
  %private.contiguous.address621 = getelementptr i8, ptr %1319, i64 %1323
  %private.contiguous.load622 = load <8 x float>, ptr %private.contiguous.address621, align 4
  %1324 = select <8 x i1> %71, <8 x float> %private.contiguous.load622, <8 x float> zeroinitializer
  %.spill.load623 = load <8 x float>, ptr %.spill97, align 32
  %1325 = fmul <8 x float> %1324, %.spill.load623
  store i64 0, ptr %.slot109, align 4
  %1326 = load <8 x float>, ptr %.slot110, align 32
  %1327 = select <8 x i1> %71, <8 x float> %1274, <8 x float> %1326
  store <8 x float> %1327, ptr %.slot110, align 32
  %1328 = load <8 x float>, ptr %.slot111, align 32
  %1329 = select <8 x i1> %71, <8 x float> %1291, <8 x float> %1328
  store <8 x float> %1329, ptr %.slot111, align 32
  %1330 = load <8 x float>, ptr %.slot112, align 32
  %1331 = select <8 x i1> %71, <8 x float> %1308, <8 x float> %1330
  store <8 x float> %1331, ptr %.slot112, align 32
  %1332 = load <8 x float>, ptr %.slot113, align 32
  %1333 = select <8 x i1> %71, <8 x float> %1325, <8 x float> %1332
  store <8 x float> %1333, ptr %.slot113, align 32
  br label %direct.schedule.30

direct.schedule.30:                               ; preds = %direct.schedule.31, %direct.schedule.29
  %.state624 = load i64, ptr %.slot109, align 4
  %1334 = icmp slt i64 %.state624, 16
  br i1 %1334, label %direct.true625, label %direct.false626

direct.schedule.31:                               ; preds = %direct.true625
  %.state627 = load i64, ptr %.slot109, align 4
  %1335 = add i64 0, %.state627
  %tile_snapshot.spill.load628 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill98, align 64
  %1336 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load628, 0
  %1337 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load628, 1
  %.splatinsert629 = insertelement <8 x i64> poison, i64 %1335, i64 0
  %.splat630 = shufflevector <8 x i64> %.splatinsert629, <8 x i64> poison, <8 x i32> zeroinitializer
  %1338 = mul <8 x i64> %.splat630, splat (i64 32)
  %1339 = add <8 x i64> %1337, %1338
  %1340 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1336, 0
  %1341 = insertvalue { <8 x ptr>, <8 x i64> } %1340, <8 x i64> %1339, 1
  %1342 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1343 = extractvalue { <8 x ptr>, <8 x i64> } %1341, 1
  %1344 = extractelement <8 x ptr> %1342, i32 0
  %1345 = extractelement <8 x i64> %1343, i32 0
  %1346 = sub i64 %1345, 0
  %1347 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1348 = select i1 %1347, i64 %1346, i64 0
  %private.contiguous.address631 = getelementptr i8, ptr %1344, i64 %1348
  %private.contiguous.load632 = load <8 x float>, ptr %private.contiguous.address631, align 4
  %1349 = select <8 x i1> %71, <8 x float> %private.contiguous.load632, <8 x float> zeroinitializer
  %1350 = mul i64 %1335, 96
  %.spill.load633 = load i64, ptr %.spill105, align 4
  %1351 = add i64 %1350, %.spill.load633
  %tile_snapshot.spill.load634 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %1352 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load634, 0
  %1353 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load634, 1
  %.splatinsert635 = insertelement <8 x i64> poison, i64 %1351, i64 0
  %.splat636 = shufflevector <8 x i64> %.splatinsert635, <8 x i64> poison, <8 x i32> zeroinitializer
  %1354 = mul <8 x i64> %.splat636, splat (i64 32)
  %1355 = add <8 x i64> %1353, %1354
  %1356 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1352, 0
  %1357 = insertvalue { <8 x ptr>, <8 x i64> } %1356, <8 x i64> %1355, 1
  %1358 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1359 = extractvalue { <8 x ptr>, <8 x i64> } %1357, 1
  %1360 = extractelement <8 x ptr> %1358, i32 0
  %1361 = extractelement <8 x i64> %1359, i32 0
  %1362 = sub i64 %1361, 0
  %1363 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1364 = select i1 %1363, i64 %1362, i64 0
  %private.contiguous.address637 = getelementptr i8, ptr %1360, i64 %1364
  %private.contiguous.load638 = load <8 x float>, ptr %private.contiguous.address637, align 4
  %1365 = select <8 x i1> %71, <8 x float> %private.contiguous.load638, <8 x float> zeroinitializer
  %1366 = fmul <8 x float> %1349, %1365
  %.state639 = load <8 x float>, ptr %.slot110, align 32
  %1367 = fadd <8 x float> %.state639, %1366
  %.spill.load640 = load i64, ptr %.spill106, align 4
  %1368 = add i64 %1350, %.spill.load640
  %tile_snapshot.spill.load641 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %1369 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load641, 0
  %1370 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load641, 1
  %.splatinsert642 = insertelement <8 x i64> poison, i64 %1368, i64 0
  %.splat643 = shufflevector <8 x i64> %.splatinsert642, <8 x i64> poison, <8 x i32> zeroinitializer
  %1371 = mul <8 x i64> %.splat643, splat (i64 32)
  %1372 = add <8 x i64> %1370, %1371
  %1373 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1369, 0
  %1374 = insertvalue { <8 x ptr>, <8 x i64> } %1373, <8 x i64> %1372, 1
  %1375 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1376 = extractvalue { <8 x ptr>, <8 x i64> } %1374, 1
  %1377 = extractelement <8 x ptr> %1375, i32 0
  %1378 = extractelement <8 x i64> %1376, i32 0
  %1379 = sub i64 %1378, 0
  %1380 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1381 = select i1 %1380, i64 %1379, i64 0
  %private.contiguous.address644 = getelementptr i8, ptr %1377, i64 %1381
  %private.contiguous.load645 = load <8 x float>, ptr %private.contiguous.address644, align 4
  %1382 = select <8 x i1> %71, <8 x float> %private.contiguous.load645, <8 x float> zeroinitializer
  %1383 = fmul <8 x float> %1349, %1382
  %.state646 = load <8 x float>, ptr %.slot111, align 32
  %1384 = fadd <8 x float> %.state646, %1383
  %.spill.load647 = load i64, ptr %.spill107, align 4
  %1385 = add i64 %1350, %.spill.load647
  %tile_snapshot.spill.load648 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %1386 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load648, 0
  %1387 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load648, 1
  %.splatinsert649 = insertelement <8 x i64> poison, i64 %1385, i64 0
  %.splat650 = shufflevector <8 x i64> %.splatinsert649, <8 x i64> poison, <8 x i32> zeroinitializer
  %1388 = mul <8 x i64> %.splat650, splat (i64 32)
  %1389 = add <8 x i64> %1387, %1388
  %1390 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1386, 0
  %1391 = insertvalue { <8 x ptr>, <8 x i64> } %1390, <8 x i64> %1389, 1
  %1392 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1393 = extractvalue { <8 x ptr>, <8 x i64> } %1391, 1
  %1394 = extractelement <8 x ptr> %1392, i32 0
  %1395 = extractelement <8 x i64> %1393, i32 0
  %1396 = sub i64 %1395, 0
  %1397 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1398 = select i1 %1397, i64 %1396, i64 0
  %private.contiguous.address651 = getelementptr i8, ptr %1394, i64 %1398
  %private.contiguous.load652 = load <8 x float>, ptr %private.contiguous.address651, align 4
  %1399 = select <8 x i1> %71, <8 x float> %private.contiguous.load652, <8 x float> zeroinitializer
  %1400 = fmul <8 x float> %1349, %1399
  %.state653 = load <8 x float>, ptr %.slot112, align 32
  %1401 = fadd <8 x float> %.state653, %1400
  %.spill.load654 = load i64, ptr %.spill108, align 4
  %1402 = add i64 %1350, %.spill.load654
  %tile_snapshot.spill.load655 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %1403 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load655, 0
  %1404 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load655, 1
  %.splatinsert656 = insertelement <8 x i64> poison, i64 %1402, i64 0
  %.splat657 = shufflevector <8 x i64> %.splatinsert656, <8 x i64> poison, <8 x i32> zeroinitializer
  %1405 = mul <8 x i64> %.splat657, splat (i64 32)
  %1406 = add <8 x i64> %1404, %1405
  %1407 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1403, 0
  %1408 = insertvalue { <8 x ptr>, <8 x i64> } %1407, <8 x i64> %1406, 1
  %1409 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1410 = extractvalue { <8 x ptr>, <8 x i64> } %1408, 1
  %1411 = extractelement <8 x ptr> %1409, i32 0
  %1412 = extractelement <8 x i64> %1410, i32 0
  %1413 = sub i64 %1412, 0
  %1414 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1415 = select i1 %1414, i64 %1413, i64 0
  %private.contiguous.address658 = getelementptr i8, ptr %1411, i64 %1415
  %private.contiguous.load659 = load <8 x float>, ptr %private.contiguous.address658, align 4
  %1416 = select <8 x i1> %71, <8 x float> %private.contiguous.load659, <8 x float> zeroinitializer
  %1417 = fmul <8 x float> %1349, %1416
  %.state660 = load <8 x float>, ptr %.slot113, align 32
  %1418 = fadd <8 x float> %.state660, %1417
  %.state661 = load i64, ptr %.slot109, align 4
  %1419 = add i64 %.state661, 1
  store i64 %1419, ptr %.slot109, align 4
  %1420 = load <8 x float>, ptr %.slot110, align 32
  %1421 = select <8 x i1> %71, <8 x float> %1367, <8 x float> %1420
  store <8 x float> %1421, ptr %.slot110, align 32
  %1422 = load <8 x float>, ptr %.slot111, align 32
  %1423 = select <8 x i1> %71, <8 x float> %1384, <8 x float> %1422
  store <8 x float> %1423, ptr %.slot111, align 32
  %1424 = load <8 x float>, ptr %.slot112, align 32
  %1425 = select <8 x i1> %71, <8 x float> %1401, <8 x float> %1424
  store <8 x float> %1425, ptr %.slot112, align 32
  %1426 = load <8 x float>, ptr %.slot113, align 32
  %1427 = select <8 x i1> %71, <8 x float> %1418, <8 x float> %1426
  store <8 x float> %1427, ptr %.slot113, align 32
  br label %direct.schedule.30

direct.schedule.32:                               ; preds = %direct.false626
  %tile_snapshot.spill.load662 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %1428 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load662, 0
  %1429 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load662, 1
  %.spill.load663 = load i64, ptr %.spill105, align 4
  %.splatinsert664 = insertelement <8 x i64> poison, i64 %.spill.load663, i64 0
  %.splat665 = shufflevector <8 x i64> %.splatinsert664, <8 x i64> poison, <8 x i32> zeroinitializer
  %1430 = mul <8 x i64> %.splat665, splat (i64 32)
  %1431 = add <8 x i64> %1429, %1430
  %1432 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1428, 0
  %1433 = insertvalue { <8 x ptr>, <8 x i64> } %1432, <8 x i64> %1431, 1
  %.state666 = load <8 x float>, ptr %.slot110, align 32
  %1434 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1435 = extractvalue { <8 x ptr>, <8 x i64> } %1433, 1
  %1436 = extractelement <8 x ptr> %1434, i32 0
  %1437 = extractelement <8 x i64> %1435, i32 0
  %1438 = sub i64 %1437, 0
  %1439 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1440 = select i1 %1439, i64 %1438, i64 0
  %private.contiguous.address667 = getelementptr i8, ptr %1436, i64 %1440
  %private.contiguous.preserve668 = load <8 x float>, ptr %private.contiguous.address667, align 4
  %1441 = select <8 x i1> %71, <8 x float> %.state666, <8 x float> %private.contiguous.preserve668
  store <8 x float> %1441, ptr %private.contiguous.address667, align 4
  %tile_snapshot.spill.load669 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %1442 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load669, 0
  %1443 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load669, 1
  %.spill.load670 = load i64, ptr %.spill106, align 4
  %.splatinsert671 = insertelement <8 x i64> poison, i64 %.spill.load670, i64 0
  %.splat672 = shufflevector <8 x i64> %.splatinsert671, <8 x i64> poison, <8 x i32> zeroinitializer
  %1444 = mul <8 x i64> %.splat672, splat (i64 32)
  %1445 = add <8 x i64> %1443, %1444
  %1446 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1442, 0
  %1447 = insertvalue { <8 x ptr>, <8 x i64> } %1446, <8 x i64> %1445, 1
  %.state673 = load <8 x float>, ptr %.slot111, align 32
  %1448 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1449 = extractvalue { <8 x ptr>, <8 x i64> } %1447, 1
  %1450 = extractelement <8 x ptr> %1448, i32 0
  %1451 = extractelement <8 x i64> %1449, i32 0
  %1452 = sub i64 %1451, 0
  %1453 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1454 = select i1 %1453, i64 %1452, i64 0
  %private.contiguous.address674 = getelementptr i8, ptr %1450, i64 %1454
  %private.contiguous.preserve675 = load <8 x float>, ptr %private.contiguous.address674, align 4
  %1455 = select <8 x i1> %71, <8 x float> %.state673, <8 x float> %private.contiguous.preserve675
  store <8 x float> %1455, ptr %private.contiguous.address674, align 4
  %tile_snapshot.spill.load676 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %1456 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load676, 0
  %1457 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load676, 1
  %.spill.load677 = load i64, ptr %.spill107, align 4
  %.splatinsert678 = insertelement <8 x i64> poison, i64 %.spill.load677, i64 0
  %.splat679 = shufflevector <8 x i64> %.splatinsert678, <8 x i64> poison, <8 x i32> zeroinitializer
  %1458 = mul <8 x i64> %.splat679, splat (i64 32)
  %1459 = add <8 x i64> %1457, %1458
  %1460 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1456, 0
  %1461 = insertvalue { <8 x ptr>, <8 x i64> } %1460, <8 x i64> %1459, 1
  %.state680 = load <8 x float>, ptr %.slot112, align 32
  %1462 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1463 = extractvalue { <8 x ptr>, <8 x i64> } %1461, 1
  %1464 = extractelement <8 x ptr> %1462, i32 0
  %1465 = extractelement <8 x i64> %1463, i32 0
  %1466 = sub i64 %1465, 0
  %1467 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1468 = select i1 %1467, i64 %1466, i64 0
  %private.contiguous.address681 = getelementptr i8, ptr %1464, i64 %1468
  %private.contiguous.preserve682 = load <8 x float>, ptr %private.contiguous.address681, align 4
  %1469 = select <8 x i1> %71, <8 x float> %.state680, <8 x float> %private.contiguous.preserve682
  store <8 x float> %1469, ptr %private.contiguous.address681, align 4
  %tile_snapshot.spill.load683 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %1470 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load683, 0
  %1471 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load683, 1
  %.spill.load684 = load i64, ptr %.spill108, align 4
  %.splatinsert685 = insertelement <8 x i64> poison, i64 %.spill.load684, i64 0
  %.splat686 = shufflevector <8 x i64> %.splatinsert685, <8 x i64> poison, <8 x i32> zeroinitializer
  %1472 = mul <8 x i64> %.splat686, splat (i64 32)
  %1473 = add <8 x i64> %1471, %1472
  %1474 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1470, 0
  %1475 = insertvalue { <8 x ptr>, <8 x i64> } %1474, <8 x i64> %1473, 1
  %.state687 = load <8 x float>, ptr %.slot113, align 32
  %1476 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1477 = extractvalue { <8 x ptr>, <8 x i64> } %1475, 1
  %1478 = extractelement <8 x ptr> %1476, i32 0
  %1479 = extractelement <8 x i64> %1477, i32 0
  %1480 = sub i64 %1479, 0
  %1481 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1482 = select i1 %1481, i64 %1480, i64 0
  %private.contiguous.address688 = getelementptr i8, ptr %1478, i64 %1482
  %private.contiguous.preserve689 = load <8 x float>, ptr %private.contiguous.address688, align 4
  %1483 = select <8 x i1> %71, <8 x float> %.state687, <8 x float> %private.contiguous.preserve689
  store <8 x float> %1483, ptr %private.contiguous.address688, align 4
  %.state690 = load i64, ptr %.slot104, align 4
  %1484 = add i64 %.state690, 1
  store i64 %1484, ptr %.slot104, align 4
  br label %direct.schedule.28

direct.schedule.33:                               ; preds = %direct.false598
  store i64 0, ptr %.slot114, align 4
  br label %direct.schedule.34

direct.schedule.34:                               ; preds = %direct.schedule.35, %direct.schedule.33
  %.state691 = load i64, ptr %.slot114, align 4
  %1485 = icmp slt i64 %.state691, 96
  br i1 %1485, label %direct.true692, label %direct.false693

direct.schedule.35:                               ; preds = %direct.true692
  %tile_snapshot.spill.load694 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %1486 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load694, 0
  %1487 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load694, 1
  %.state695 = load i64, ptr %.slot114, align 4
  %.splatinsert696 = insertelement <8 x i64> poison, i64 %.state695, i64 0
  %.splat697 = shufflevector <8 x i64> %.splatinsert696, <8 x i64> poison, <8 x i32> zeroinitializer
  %1488 = mul <8 x i64> %.splat697, splat (i64 32)
  %1489 = add <8 x i64> %1487, %1488
  %1490 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1486, 0
  %1491 = insertvalue { <8 x ptr>, <8 x i64> } %1490, <8 x i64> %1489, 1
  %1492 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1493 = extractvalue { <8 x ptr>, <8 x i64> } %1491, 1
  %1494 = extractelement <8 x ptr> %1492, i32 0
  %1495 = extractelement <8 x i64> %1493, i32 0
  %1496 = sub i64 %1495, 0
  %1497 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1498 = select i1 %1497, i64 %1496, i64 0
  %private.contiguous.address698 = getelementptr i8, ptr %1494, i64 %1498
  %private.contiguous.load699 = load <8 x float>, ptr %private.contiguous.address698, align 4
  %1499 = select <8 x i1> %71, <8 x float> %private.contiguous.load699, <8 x float> zeroinitializer
  %tile_snapshot.spill.load700 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill33, align 64
  %1500 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load700, 0
  %1501 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load700, 1
  %.state701 = load i64, ptr %.slot114, align 4
  %.splatinsert702 = insertelement <8 x i64> poison, i64 %.state701, i64 0
  %.splat703 = shufflevector <8 x i64> %.splatinsert702, <8 x i64> poison, <8 x i32> zeroinitializer
  %1502 = mul <8 x i64> %.splat703, splat (i64 32)
  %1503 = add <8 x i64> %1501, %1502
  %1504 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1500, 0
  %1505 = insertvalue { <8 x ptr>, <8 x i64> } %1504, <8 x i64> %1503, 1
  %1506 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1507 = extractvalue { <8 x ptr>, <8 x i64> } %1505, 1
  %1508 = extractelement <8 x ptr> %1506, i32 0
  %1509 = extractelement <8 x i64> %1507, i32 0
  %1510 = sub i64 %1509, 0
  %1511 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1512 = select i1 %1511, i64 %1510, i64 0
  %private.contiguous.address704 = getelementptr i8, ptr %1508, i64 %1512
  %private.contiguous.preserve705 = load <8 x float>, ptr %private.contiguous.address704, align 4
  %1513 = select <8 x i1> %71, <8 x float> %1499, <8 x float> %private.contiguous.preserve705
  store <8 x float> %1513, ptr %private.contiguous.address704, align 4
  %.state706 = load i64, ptr %.slot114, align 4
  %1514 = add i64 %.state706, 1
  store i64 %1514, ptr %.slot114, align 4
  br label %direct.schedule.34

direct.schedule.36:                               ; preds = %direct.false693
  store i64 0, ptr %.slot115, align 4
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.38, %direct.schedule.36
  %.state707 = load i64, ptr %.slot115, align 4
  %1515 = icmp slt i64 %.state707, 96
  br i1 %1515, label %direct.true708, label %direct.false709

direct.schedule.38:                               ; preds = %direct.true708
  %tile_snapshot.spill.load710 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill33, align 64
  %1516 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load710, 0
  %1517 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load710, 1
  %.state711 = load i64, ptr %.slot115, align 4
  %.splatinsert712 = insertelement <8 x i64> poison, i64 %.state711, i64 0
  %.splat713 = shufflevector <8 x i64> %.splatinsert712, <8 x i64> poison, <8 x i32> zeroinitializer
  %1518 = mul <8 x i64> %.splat713, splat (i64 32)
  %1519 = add <8 x i64> %1517, %1518
  %1520 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1516, 0
  %1521 = insertvalue { <8 x ptr>, <8 x i64> } %1520, <8 x i64> %1519, 1
  %1522 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1523 = extractvalue { <8 x ptr>, <8 x i64> } %1521, 1
  %1524 = extractelement <8 x ptr> %1522, i32 0
  %1525 = extractelement <8 x i64> %1523, i32 0
  %1526 = sub i64 %1525, 0
  %1527 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1528 = select i1 %1527, i64 %1526, i64 0
  %private.contiguous.address714 = getelementptr i8, ptr %1524, i64 %1528
  %private.contiguous.load715 = load <8 x float>, ptr %private.contiguous.address714, align 4
  %1529 = select <8 x i1> %71, <8 x float> %private.contiguous.load715, <8 x float> zeroinitializer
  %tile_snapshot.spill.load716 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1530 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load716, 0
  %1531 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load716, 1
  %.state717 = load i64, ptr %.slot115, align 4
  %.splatinsert718 = insertelement <8 x i64> poison, i64 %.state717, i64 0
  %.splat719 = shufflevector <8 x i64> %.splatinsert718, <8 x i64> poison, <8 x i32> zeroinitializer
  %1532 = mul <8 x i64> %.splat719, splat (i64 32)
  %1533 = add <8 x i64> %1531, %1532
  %1534 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1530, 0
  %1535 = insertvalue { <8 x ptr>, <8 x i64> } %1534, <8 x i64> %1533, 1
  %1536 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1537 = extractvalue { <8 x ptr>, <8 x i64> } %1535, 1
  %1538 = extractelement <8 x ptr> %1536, i32 0
  %1539 = extractelement <8 x i64> %1537, i32 0
  %1540 = sub i64 %1539, 0
  %1541 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1542 = select i1 %1541, i64 %1540, i64 0
  %private.contiguous.address720 = getelementptr i8, ptr %1538, i64 %1542
  %private.contiguous.preserve721 = load <8 x float>, ptr %private.contiguous.address720, align 4
  %1543 = select <8 x i1> %71, <8 x float> %1529, <8 x float> %private.contiguous.preserve721
  store <8 x float> %1543, ptr %private.contiguous.address720, align 4
  %.state722 = load i64, ptr %.slot115, align 4
  %1544 = add i64 %.state722, 1
  store i64 %1544, ptr %.slot115, align 4
  br label %direct.schedule.37

direct.schedule.39:                               ; preds = %direct.false709
  %.state723 = load i64, ptr %.slot34, align 4
  %1545 = add i64 %.state723, 1
  %.spill.load724 = load <8 x float>, ptr %.spill96, align 32
  %.spill.load725 = load <8 x float>, ptr %.spill102, align 32
  store i64 %1545, ptr %.slot34, align 4
  %1546 = load <8 x float>, ptr %.slot35, align 32
  %1547 = select <8 x i1> %71, <8 x float> %.spill.load724, <8 x float> %1546
  store <8 x float> %1547, ptr %.slot35, align 32
  %1548 = load <8 x float>, ptr %.slot36, align 32
  %1549 = select <8 x i1> %71, <8 x float> %.spill.load725, <8 x float> %1548
  store <8 x float> %1549, ptr %.slot36, align 32
  br label %direct.schedule.4

direct.schedule.40:                               ; preds = %direct.false182
  store i64 0, ptr %.slot116, align 4
  br label %direct.schedule.41

direct.schedule.41:                               ; preds = %direct.schedule.44, %direct.schedule.40
  %.state726 = load i64, ptr %.slot116, align 4
  %1550 = icmp slt i64 %.state726, 1536
  br i1 %1550, label %direct.true727, label %direct.false728

direct.schedule.42:                               ; preds = %direct.true727
  %.state729 = load i64, ptr %.slot116, align 4
  %1551 = srem i64 %.state729, 96
  %.state730 = load i64, ptr %.slot116, align 4
  %1552 = sdiv i64 %.state730, 96
  %.spill.load731 = load i64, ptr %.spill29, align 4
  %1553 = add i64 %.spill.load731, 0
  %.spill.load732 = load <8 x i64>, ptr %.spill30, align 64
  %1554 = add <8 x i64> %.spill.load732, zeroinitializer
  %1555 = mul i64 %1553, 2
  %.splatinsert733 = insertelement <8 x i64> poison, i64 %1555, i64 0
  %.splat734 = shufflevector <8 x i64> %.splatinsert733, <8 x i64> poison, <8 x i32> zeroinitializer
  %1556 = add <8 x i64> %.splat734, %1554
  %.spill.load735 = load i64, ptr %.spill37, align 4
  %1557 = add i64 %.spill.load735, %1552
  %1558 = mul <8 x i64> %1556, splat (i64 2053)
  %.splatinsert736 = insertelement <8 x i64> poison, i64 %1557, i64 0
  %.splat737 = shufflevector <8 x i64> %.splatinsert736, <8 x i64> poison, <8 x i32> zeroinitializer
  %1559 = add <8 x i64> %1558, %.splat737
  %1560 = icmp sge i64 %1557, 0
  %1561 = and i1 true, %1560
  %1562 = icmp slt i64 %1557, 2053
  %1563 = and i1 %1561, %1562
  %1564 = add i64 0, %1551
  %1565 = mul <8 x i64> %1559, splat (i64 96)
  %.splatinsert738 = insertelement <8 x i64> poison, i64 %1564, i64 0
  %.splat739 = shufflevector <8 x i64> %.splatinsert738, <8 x i64> poison, <8 x i32> zeroinitializer
  %1566 = add <8 x i64> %1565, %.splat739
  %1567 = load <8 x i64>, ptr %.spill117, align 64
  %1568 = select <8 x i1> %71, <8 x i64> %1566, <8 x i64> %1567
  store <8 x i64> %1568, ptr %.spill117, align 64
  br i1 %1563, label %direct.true740, label %direct.false741

direct.schedule.43:                               ; preds = %direct.true740
  %.spill.load742 = load <8 x i64>, ptr %.spill117, align 64
  %1569 = extractvalue { ptr, i64 } %41, 0
  %1570 = mul <8 x i64> %.spill.load742, splat (i64 4)
  %1571 = getelementptr i8, ptr %1569, <8 x i64> %1570
  %1572 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1571, <8 x i1> %71, <8 x float> zeroinitializer)
  %1573 = load <8 x float>, ptr %.slot118, align 32
  %1574 = select <8 x i1> %71, <8 x float> %1572, <8 x float> %1573
  store <8 x float> %1574, ptr %.slot118, align 32
  br label %direct.schedule.44

direct.schedule.44:                               ; preds = %direct.false741, %direct.schedule.43
  %tile_snapshot.spill.load743 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %1575 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load743, 0
  %1576 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load743, 1
  %.state744 = load i64, ptr %.slot116, align 4
  %.splatinsert745 = insertelement <8 x i64> poison, i64 %.state744, i64 0
  %.splat746 = shufflevector <8 x i64> %.splatinsert745, <8 x i64> poison, <8 x i32> zeroinitializer
  %1577 = mul <8 x i64> %.splat746, splat (i64 32)
  %1578 = add <8 x i64> %1576, %1577
  %1579 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1575, 0
  %1580 = insertvalue { <8 x ptr>, <8 x i64> } %1579, <8 x i64> %1578, 1
  %.state747 = load <8 x float>, ptr %.slot118, align 32
  %1581 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1582 = extractvalue { <8 x ptr>, <8 x i64> } %1580, 1
  %1583 = extractelement <8 x ptr> %1581, i32 0
  %1584 = extractelement <8 x i64> %1582, i32 0
  %1585 = sub i64 %1584, 0
  %1586 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1587 = select i1 %1586, i64 %1585, i64 0
  %private.contiguous.address748 = getelementptr i8, ptr %1583, i64 %1587
  %private.contiguous.preserve749 = load <8 x float>, ptr %private.contiguous.address748, align 4
  %1588 = select <8 x i1> %71, <8 x float> %.state747, <8 x float> %private.contiguous.preserve749
  store <8 x float> %1588, ptr %private.contiguous.address748, align 4
  %.state750 = load i64, ptr %.slot116, align 4
  %1589 = add i64 %.state750, 1
  store i64 %1589, ptr %.slot116, align 4
  br label %direct.schedule.41

direct.schedule.45:                               ; preds = %direct.false156
  store i64 0, ptr %.slot119, align 4
  br label %direct.schedule.46

direct.schedule.46:                               ; preds = %direct.schedule.49, %direct.schedule.45
  %.state751 = load i64, ptr %.slot119, align 4
  %1590 = icmp slt i64 %.state751, 1280
  br i1 %1590, label %direct.true752, label %direct.false753

direct.schedule.47:                               ; preds = %direct.true752
  %.state754 = load i64, ptr %.slot119, align 4
  %1591 = srem i64 %.state754, 80
  %.state755 = load i64, ptr %.slot119, align 4
  %1592 = sdiv i64 %.state755, 80
  %.spill.load756 = load i64, ptr %.spill29, align 4
  %1593 = add i64 %.spill.load756, 0
  %.spill.load757 = load <8 x i64>, ptr %.spill30, align 64
  %1594 = add <8 x i64> %.spill.load757, zeroinitializer
  %1595 = mul i64 %1593, 2
  %.splatinsert758 = insertelement <8 x i64> poison, i64 %1595, i64 0
  %.splat759 = shufflevector <8 x i64> %.splatinsert758, <8 x i64> poison, <8 x i32> zeroinitializer
  %1596 = add <8 x i64> %.splat759, %1594
  %.spill.load760 = load i64, ptr %.spill37, align 4
  %1597 = add i64 %.spill.load760, %1592
  %1598 = mul <8 x i64> %1596, splat (i64 2053)
  %.splatinsert761 = insertelement <8 x i64> poison, i64 %1597, i64 0
  %.splat762 = shufflevector <8 x i64> %.splatinsert761, <8 x i64> poison, <8 x i32> zeroinitializer
  %1599 = add <8 x i64> %1598, %.splat762
  %1600 = icmp sge i64 %1597, 0
  %1601 = and i1 true, %1600
  %1602 = icmp slt i64 %1597, 2053
  %1603 = and i1 %1601, %1602
  %1604 = add i64 0, %1591
  %1605 = mul <8 x i64> %1599, splat (i64 80)
  %.splatinsert763 = insertelement <8 x i64> poison, i64 %1604, i64 0
  %.splat764 = shufflevector <8 x i64> %.splatinsert763, <8 x i64> poison, <8 x i32> zeroinitializer
  %1606 = add <8 x i64> %1605, %.splat764
  %1607 = load <8 x i64>, ptr %.spill120, align 64
  %1608 = select <8 x i1> %71, <8 x i64> %1606, <8 x i64> %1607
  store <8 x i64> %1608, ptr %.spill120, align 64
  br i1 %1603, label %direct.true765, label %direct.false766

direct.schedule.48:                               ; preds = %direct.true765
  %.spill.load767 = load <8 x i64>, ptr %.spill120, align 64
  %1609 = extractvalue { ptr, i64 } %35, 0
  %1610 = mul <8 x i64> %.spill.load767, splat (i64 4)
  %1611 = getelementptr i8, ptr %1609, <8 x i64> %1610
  %1612 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1611, <8 x i1> %71, <8 x float> zeroinitializer)
  %1613 = load <8 x float>, ptr %.slot121, align 32
  %1614 = select <8 x i1> %71, <8 x float> %1612, <8 x float> %1613
  store <8 x float> %1614, ptr %.slot121, align 32
  br label %direct.schedule.49

direct.schedule.49:                               ; preds = %direct.false766, %direct.schedule.48
  %tile_snapshot.spill.load768 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %1615 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load768, 0
  %1616 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load768, 1
  %.state769 = load i64, ptr %.slot119, align 4
  %.splatinsert770 = insertelement <8 x i64> poison, i64 %.state769, i64 0
  %.splat771 = shufflevector <8 x i64> %.splatinsert770, <8 x i64> poison, <8 x i32> zeroinitializer
  %1617 = mul <8 x i64> %.splat771, splat (i64 32)
  %1618 = add <8 x i64> %1616, %1617
  %1619 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1615, 0
  %1620 = insertvalue { <8 x ptr>, <8 x i64> } %1619, <8 x i64> %1618, 1
  %.state772 = load <8 x float>, ptr %.slot121, align 32
  %1621 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1622 = extractvalue { <8 x ptr>, <8 x i64> } %1620, 1
  %1623 = extractelement <8 x ptr> %1621, i32 0
  %1624 = extractelement <8 x i64> %1622, i32 0
  %1625 = sub i64 %1624, 0
  %1626 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1627 = select i1 %1626, i64 %1625, i64 0
  %private.contiguous.address773 = getelementptr i8, ptr %1623, i64 %1627
  %private.contiguous.preserve774 = load <8 x float>, ptr %private.contiguous.address773, align 4
  %1628 = select <8 x i1> %71, <8 x float> %.state772, <8 x float> %private.contiguous.preserve774
  store <8 x float> %1628, ptr %private.contiguous.address773, align 4
  %.state775 = load i64, ptr %.slot119, align 4
  %1629 = add i64 %.state775, 1
  store i64 %1629, ptr %.slot119, align 4
  br label %direct.schedule.46

direct.schedule.50:                               ; preds = %direct.false153
  store i64 0, ptr %.slot122, align 4
  br label %direct.schedule.51

direct.schedule.51:                               ; preds = %direct.schedule.52, %direct.schedule.50
  %.state776 = load i64, ptr %.slot122, align 4
  %1630 = icmp slt i64 %.state776, 96
  br i1 %1630, label %direct.true777, label %direct.false778

direct.schedule.52:                               ; preds = %direct.true777
  %.spill.load779 = load i64, ptr %.spill29, align 4
  %1631 = add i64 %.spill.load779, 0
  %.spill.load780 = load <8 x i64>, ptr %.spill, align 64
  %1632 = add <8 x i64> %.spill.load780, zeroinitializer
  %1633 = mul i64 %1631, 8
  %.splatinsert781 = insertelement <8 x i64> poison, i64 %1633, i64 0
  %.splat782 = shufflevector <8 x i64> %.splatinsert781, <8 x i64> poison, <8 x i32> zeroinitializer
  %1634 = add <8 x i64> %.splat782, %1632
  %1635 = mul <8 x i64> %1634, splat (i64 1)
  %.spill.load783 = load i64, ptr %.spill31, align 4
  %.splatinsert784 = insertelement <8 x i64> poison, i64 %.spill.load783, i64 0
  %.splat785 = shufflevector <8 x i64> %.splatinsert784, <8 x i64> poison, <8 x i32> zeroinitializer
  %1636 = add <8 x i64> %1635, %.splat785
  %.state786 = load i64, ptr %.slot122, align 4
  %1637 = add i64 0, %.state786
  %1638 = mul <8 x i64> %1636, splat (i64 96)
  %.splatinsert787 = insertelement <8 x i64> poison, i64 %1637, i64 0
  %.splat788 = shufflevector <8 x i64> %.splatinsert787, <8 x i64> poison, <8 x i32> zeroinitializer
  %1639 = add <8 x i64> %1638, %.splat788
  %.state789 = load i64, ptr %.slot122, align 4
  %1640 = add i64 0, %.state789
  %tile_snapshot.spill.load790 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1641 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load790, 0
  %1642 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load790, 1
  %.splatinsert791 = insertelement <8 x i64> poison, i64 %1640, i64 0
  %.splat792 = shufflevector <8 x i64> %.splatinsert791, <8 x i64> poison, <8 x i32> zeroinitializer
  %1643 = mul <8 x i64> %.splat792, splat (i64 32)
  %1644 = add <8 x i64> %1642, %1643
  %1645 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1641, 0
  %1646 = insertvalue { <8 x ptr>, <8 x i64> } %1645, <8 x i64> %1644, 1
  %1647 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1648 = extractvalue { <8 x ptr>, <8 x i64> } %1646, 1
  %1649 = extractelement <8 x ptr> %1647, i32 0
  %1650 = extractelement <8 x i64> %1648, i32 0
  %1651 = sub i64 %1650, 0
  %1652 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1653 = select i1 %1652, i64 %1651, i64 0
  %private.contiguous.address793 = getelementptr i8, ptr %1649, i64 %1653
  %private.contiguous.load794 = load <8 x float>, ptr %private.contiguous.address793, align 4
  %1654 = select <8 x i1> %71, <8 x float> %private.contiguous.load794, <8 x float> zeroinitializer
  %.state795 = load <8 x float>, ptr %.slot36, align 32
  %1655 = fdiv <8 x float> %1654, %.state795
  %1656 = extractvalue { ptr, i64 } %47, 0
  %1657 = mul <8 x i64> %1639, splat (i64 4)
  %1658 = getelementptr i8, ptr %1656, <8 x i64> %1657
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1655, <8 x ptr> align 1 %1658, <8 x i1> %71)
  %.state796 = load i64, ptr %.slot122, align 4
  %1659 = add i64 %.state796, 1
  store i64 %1659, ptr %.slot122, align 4
  br label %direct.schedule.51

direct.schedule.53:                               ; preds = %direct.false778
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

copy.active:                                      ; preds = %direct.schedule.0
  %1660 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1661 = extractelement <8 x ptr> %1660, i64 0
  %1662 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1663 = extractelement <8 x i64> %1662, i64 0
  %1664 = getelementptr i8, ptr %1661, i64 %1663
  %1665 = extractelement <8 x i64> %98, i64 0
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1665, ptr %1664)
  br label %copy.continue

copy.continue:                                    ; preds = %copy.active, %direct.schedule.0
  %1666 = extractelement <8 x i1> %71, i64 1
  br i1 %1666, label %copy.active133, label %copy.continue134

copy.active133:                                   ; preds = %copy.continue
  %1667 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1668 = extractelement <8 x ptr> %1667, i64 1
  %1669 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1670 = extractelement <8 x i64> %1669, i64 1
  %1671 = getelementptr i8, ptr %1668, i64 %1670
  %1672 = extractelement <8 x i64> %98, i64 1
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1672, ptr %1671)
  br label %copy.continue134

copy.continue134:                                 ; preds = %copy.active133, %copy.continue
  %1673 = extractelement <8 x i1> %71, i64 2
  br i1 %1673, label %copy.active135, label %copy.continue136

copy.active135:                                   ; preds = %copy.continue134
  %1674 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1675 = extractelement <8 x ptr> %1674, i64 2
  %1676 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1677 = extractelement <8 x i64> %1676, i64 2
  %1678 = getelementptr i8, ptr %1675, i64 %1677
  %1679 = extractelement <8 x i64> %98, i64 2
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1679, ptr %1678)
  br label %copy.continue136

copy.continue136:                                 ; preds = %copy.active135, %copy.continue134
  %1680 = extractelement <8 x i1> %71, i64 3
  br i1 %1680, label %copy.active137, label %copy.continue138

copy.active137:                                   ; preds = %copy.continue136
  %1681 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1682 = extractelement <8 x ptr> %1681, i64 3
  %1683 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1684 = extractelement <8 x i64> %1683, i64 3
  %1685 = getelementptr i8, ptr %1682, i64 %1684
  %1686 = extractelement <8 x i64> %98, i64 3
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1686, ptr %1685)
  br label %copy.continue138

copy.continue138:                                 ; preds = %copy.active137, %copy.continue136
  %1687 = extractelement <8 x i1> %71, i64 4
  br i1 %1687, label %copy.active139, label %copy.continue140

copy.active139:                                   ; preds = %copy.continue138
  %1688 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1689 = extractelement <8 x ptr> %1688, i64 4
  %1690 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1691 = extractelement <8 x i64> %1690, i64 4
  %1692 = getelementptr i8, ptr %1689, i64 %1691
  %1693 = extractelement <8 x i64> %98, i64 4
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1693, ptr %1692)
  br label %copy.continue140

copy.continue140:                                 ; preds = %copy.active139, %copy.continue138
  %1694 = extractelement <8 x i1> %71, i64 5
  br i1 %1694, label %copy.active141, label %copy.continue142

copy.active141:                                   ; preds = %copy.continue140
  %1695 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1696 = extractelement <8 x ptr> %1695, i64 5
  %1697 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1698 = extractelement <8 x i64> %1697, i64 5
  %1699 = getelementptr i8, ptr %1696, i64 %1698
  %1700 = extractelement <8 x i64> %98, i64 5
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1700, ptr %1699)
  br label %copy.continue142

copy.continue142:                                 ; preds = %copy.active141, %copy.continue140
  %1701 = extractelement <8 x i1> %71, i64 6
  br i1 %1701, label %copy.active143, label %copy.continue144

copy.active143:                                   ; preds = %copy.continue142
  %1702 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1703 = extractelement <8 x ptr> %1702, i64 6
  %1704 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1705 = extractelement <8 x i64> %1704, i64 6
  %1706 = getelementptr i8, ptr %1703, i64 %1705
  %1707 = extractelement <8 x i64> %98, i64 6
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1707, ptr %1706)
  br label %copy.continue144

copy.continue144:                                 ; preds = %copy.active143, %copy.continue142
  %1708 = extractelement <8 x i1> %71, i64 7
  br i1 %1708, label %copy.active145, label %copy.continue146

copy.active145:                                   ; preds = %copy.continue144
  %1709 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1710 = extractelement <8 x ptr> %1709, i64 7
  %1711 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1712 = extractelement <8 x i64> %1711, i64 7
  %1713 = getelementptr i8, ptr %1710, i64 %1712
  %1714 = extractelement <8 x i64> %98, i64 7
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1714, ptr %1713)
  br label %copy.continue146

copy.continue146:                                 ; preds = %copy.active145, %copy.continue144
  %1715 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1716 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1717 = extractvalue { <8 x ptr>, <8 x i64> } %1715, 0
  %1718 = select <8 x i1> %71, <8 x ptr> %1716, <8 x ptr> %1717
  %1719 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1720 = extractvalue { <8 x ptr>, <8 x i64> } %1715, 1
  %1721 = select <8 x i1> %71, <8 x i64> %1719, <8 x i64> %1720
  %1722 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1718, 0
  %1723 = insertvalue { <8 x ptr>, <8 x i64> } %1722, <8 x i64> %1721, 1
  store { <8 x ptr>, <8 x i64> } %1723, ptr %tile_snapshot.spill32, align 64
  %1724 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill33, align 64
  %1725 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1726 = extractvalue { <8 x ptr>, <8 x i64> } %1724, 0
  %1727 = select <8 x i1> %71, <8 x ptr> %1725, <8 x ptr> %1726
  %1728 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %1729 = extractvalue { <8 x ptr>, <8 x i64> } %1724, 1
  %1730 = select <8 x i1> %71, <8 x i64> %1728, <8 x i64> %1729
  %1731 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1727, 0
  %1732 = insertvalue { <8 x ptr>, <8 x i64> } %1731, <8 x i64> %1730, 1
  store { <8 x ptr>, <8 x i64> } %1732, ptr %tile_snapshot.spill33, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true152:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false153:                                  ; preds = %direct.schedule.4
  br label %direct.schedule.50

direct.true155:                                   ; preds = %direct.schedule.5
  br label %direct.schedule.6

direct.false156:                                  ; preds = %direct.schedule.5
  br label %direct.schedule.45

copy.active164:                                   ; preds = %direct.schedule.6
  %1733 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1734 = extractelement <8 x ptr> %1733, i64 0
  %1735 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1736 = extractelement <8 x i64> %1735, i64 0
  %1737 = getelementptr i8, ptr %1734, i64 %1736
  %1738 = extractelement <8 x i64> %142, i64 0
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1738, ptr %1737)
  br label %copy.continue165

copy.continue165:                                 ; preds = %copy.active164, %direct.schedule.6
  %1739 = extractelement <8 x i1> %71, i64 1
  br i1 %1739, label %copy.active166, label %copy.continue167

copy.active166:                                   ; preds = %copy.continue165
  %1740 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1741 = extractelement <8 x ptr> %1740, i64 1
  %1742 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1743 = extractelement <8 x i64> %1742, i64 1
  %1744 = getelementptr i8, ptr %1741, i64 %1743
  %1745 = extractelement <8 x i64> %142, i64 1
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1745, ptr %1744)
  br label %copy.continue167

copy.continue167:                                 ; preds = %copy.active166, %copy.continue165
  %1746 = extractelement <8 x i1> %71, i64 2
  br i1 %1746, label %copy.active168, label %copy.continue169

copy.active168:                                   ; preds = %copy.continue167
  %1747 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1748 = extractelement <8 x ptr> %1747, i64 2
  %1749 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1750 = extractelement <8 x i64> %1749, i64 2
  %1751 = getelementptr i8, ptr %1748, i64 %1750
  %1752 = extractelement <8 x i64> %142, i64 2
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1752, ptr %1751)
  br label %copy.continue169

copy.continue169:                                 ; preds = %copy.active168, %copy.continue167
  %1753 = extractelement <8 x i1> %71, i64 3
  br i1 %1753, label %copy.active170, label %copy.continue171

copy.active170:                                   ; preds = %copy.continue169
  %1754 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1755 = extractelement <8 x ptr> %1754, i64 3
  %1756 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1757 = extractelement <8 x i64> %1756, i64 3
  %1758 = getelementptr i8, ptr %1755, i64 %1757
  %1759 = extractelement <8 x i64> %142, i64 3
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1759, ptr %1758)
  br label %copy.continue171

copy.continue171:                                 ; preds = %copy.active170, %copy.continue169
  %1760 = extractelement <8 x i1> %71, i64 4
  br i1 %1760, label %copy.active172, label %copy.continue173

copy.active172:                                   ; preds = %copy.continue171
  %1761 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1762 = extractelement <8 x ptr> %1761, i64 4
  %1763 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1764 = extractelement <8 x i64> %1763, i64 4
  %1765 = getelementptr i8, ptr %1762, i64 %1764
  %1766 = extractelement <8 x i64> %142, i64 4
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1766, ptr %1765)
  br label %copy.continue173

copy.continue173:                                 ; preds = %copy.active172, %copy.continue171
  %1767 = extractelement <8 x i1> %71, i64 5
  br i1 %1767, label %copy.active174, label %copy.continue175

copy.active174:                                   ; preds = %copy.continue173
  %1768 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1769 = extractelement <8 x ptr> %1768, i64 5
  %1770 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1771 = extractelement <8 x i64> %1770, i64 5
  %1772 = getelementptr i8, ptr %1769, i64 %1771
  %1773 = extractelement <8 x i64> %142, i64 5
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1773, ptr %1772)
  br label %copy.continue175

copy.continue175:                                 ; preds = %copy.active174, %copy.continue173
  %1774 = extractelement <8 x i1> %71, i64 6
  br i1 %1774, label %copy.active176, label %copy.continue177

copy.active176:                                   ; preds = %copy.continue175
  %1775 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1776 = extractelement <8 x ptr> %1775, i64 6
  %1777 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1778 = extractelement <8 x i64> %1777, i64 6
  %1779 = getelementptr i8, ptr %1776, i64 %1778
  %1780 = extractelement <8 x i64> %142, i64 6
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1780, ptr %1779)
  br label %copy.continue177

copy.continue177:                                 ; preds = %copy.active176, %copy.continue175
  %1781 = extractelement <8 x i1> %71, i64 7
  br i1 %1781, label %copy.active178, label %copy.continue179

copy.active178:                                   ; preds = %copy.continue177
  %1782 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1783 = extractelement <8 x ptr> %1782, i64 7
  %1784 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1785 = extractelement <8 x i64> %1784, i64 7
  %1786 = getelementptr i8, ptr %1783, i64 %1785
  %1787 = extractelement <8 x i64> %142, i64 7
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1787, ptr %1786)
  br label %copy.continue179

copy.continue179:                                 ; preds = %copy.active178, %copy.continue177
  br label %direct.schedule.7

direct.true181:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false182:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.40

copy.active191:                                   ; preds = %direct.schedule.8
  %1788 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1789 = extractelement <8 x ptr> %1788, i64 0
  %1790 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1791 = extractelement <8 x i64> %1790, i64 0
  %1792 = getelementptr i8, ptr %1789, i64 %1791
  %1793 = extractelement <8 x i64> %159, i64 0
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1793, ptr %1792)
  br label %copy.continue192

copy.continue192:                                 ; preds = %copy.active191, %direct.schedule.8
  %1794 = extractelement <8 x i1> %71, i64 1
  br i1 %1794, label %copy.active193, label %copy.continue194

copy.active193:                                   ; preds = %copy.continue192
  %1795 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1796 = extractelement <8 x ptr> %1795, i64 1
  %1797 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1798 = extractelement <8 x i64> %1797, i64 1
  %1799 = getelementptr i8, ptr %1796, i64 %1798
  %1800 = extractelement <8 x i64> %159, i64 1
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1800, ptr %1799)
  br label %copy.continue194

copy.continue194:                                 ; preds = %copy.active193, %copy.continue192
  %1801 = extractelement <8 x i1> %71, i64 2
  br i1 %1801, label %copy.active195, label %copy.continue196

copy.active195:                                   ; preds = %copy.continue194
  %1802 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1803 = extractelement <8 x ptr> %1802, i64 2
  %1804 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1805 = extractelement <8 x i64> %1804, i64 2
  %1806 = getelementptr i8, ptr %1803, i64 %1805
  %1807 = extractelement <8 x i64> %159, i64 2
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1807, ptr %1806)
  br label %copy.continue196

copy.continue196:                                 ; preds = %copy.active195, %copy.continue194
  %1808 = extractelement <8 x i1> %71, i64 3
  br i1 %1808, label %copy.active197, label %copy.continue198

copy.active197:                                   ; preds = %copy.continue196
  %1809 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1810 = extractelement <8 x ptr> %1809, i64 3
  %1811 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1812 = extractelement <8 x i64> %1811, i64 3
  %1813 = getelementptr i8, ptr %1810, i64 %1812
  %1814 = extractelement <8 x i64> %159, i64 3
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1814, ptr %1813)
  br label %copy.continue198

copy.continue198:                                 ; preds = %copy.active197, %copy.continue196
  %1815 = extractelement <8 x i1> %71, i64 4
  br i1 %1815, label %copy.active199, label %copy.continue200

copy.active199:                                   ; preds = %copy.continue198
  %1816 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1817 = extractelement <8 x ptr> %1816, i64 4
  %1818 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1819 = extractelement <8 x i64> %1818, i64 4
  %1820 = getelementptr i8, ptr %1817, i64 %1819
  %1821 = extractelement <8 x i64> %159, i64 4
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1821, ptr %1820)
  br label %copy.continue200

copy.continue200:                                 ; preds = %copy.active199, %copy.continue198
  %1822 = extractelement <8 x i1> %71, i64 5
  br i1 %1822, label %copy.active201, label %copy.continue202

copy.active201:                                   ; preds = %copy.continue200
  %1823 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1824 = extractelement <8 x ptr> %1823, i64 5
  %1825 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1826 = extractelement <8 x i64> %1825, i64 5
  %1827 = getelementptr i8, ptr %1824, i64 %1826
  %1828 = extractelement <8 x i64> %159, i64 5
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1828, ptr %1827)
  br label %copy.continue202

copy.continue202:                                 ; preds = %copy.active201, %copy.continue200
  %1829 = extractelement <8 x i1> %71, i64 6
  br i1 %1829, label %copy.active203, label %copy.continue204

copy.active203:                                   ; preds = %copy.continue202
  %1830 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1831 = extractelement <8 x ptr> %1830, i64 6
  %1832 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1833 = extractelement <8 x i64> %1832, i64 6
  %1834 = getelementptr i8, ptr %1831, i64 %1833
  %1835 = extractelement <8 x i64> %159, i64 6
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1835, ptr %1834)
  br label %copy.continue204

copy.continue204:                                 ; preds = %copy.active203, %copy.continue202
  %1836 = extractelement <8 x i1> %71, i64 7
  br i1 %1836, label %copy.active205, label %copy.continue206

copy.active205:                                   ; preds = %copy.continue204
  %1837 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1838 = extractelement <8 x ptr> %1837, i64 7
  %1839 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1840 = extractelement <8 x i64> %1839, i64 7
  %1841 = getelementptr i8, ptr %1838, i64 %1840
  %1842 = extractelement <8 x i64> %159, i64 7
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1842, ptr %1841)
  br label %copy.continue206

copy.continue206:                                 ; preds = %copy.active205, %copy.continue204
  br label %direct.schedule.9

direct.true208:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false209:                                  ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true244:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false245:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true282:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false283:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true320:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false321:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true455:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false456:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24

direct.true583:                                   ; preds = %direct.schedule.25
  br label %direct.schedule.26

direct.false584:                                  ; preds = %direct.schedule.25
  br label %direct.schedule.27

direct.true597:                                   ; preds = %direct.schedule.28
  br label %direct.schedule.29

direct.false598:                                  ; preds = %direct.schedule.28
  br label %direct.schedule.33

direct.true625:                                   ; preds = %direct.schedule.30
  br label %direct.schedule.31

direct.false626:                                  ; preds = %direct.schedule.30
  br label %direct.schedule.32

direct.true692:                                   ; preds = %direct.schedule.34
  br label %direct.schedule.35

direct.false693:                                  ; preds = %direct.schedule.34
  br label %direct.schedule.36

direct.true708:                                   ; preds = %direct.schedule.37
  br label %direct.schedule.38

direct.false709:                                  ; preds = %direct.schedule.37
  br label %direct.schedule.39

direct.true727:                                   ; preds = %direct.schedule.41
  br label %direct.schedule.42

direct.false728:                                  ; preds = %direct.schedule.41
  br label %direct.schedule.9

direct.true740:                                   ; preds = %direct.schedule.42
  br label %direct.schedule.43

direct.false741:                                  ; preds = %direct.schedule.42
  %1843 = load <8 x float>, ptr %.slot118, align 32
  %1844 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1843
  store <8 x float> %1844, ptr %.slot118, align 32
  br label %direct.schedule.44

direct.true752:                                   ; preds = %direct.schedule.46
  br label %direct.schedule.47

direct.false753:                                  ; preds = %direct.schedule.46
  br label %direct.schedule.7

direct.true765:                                   ; preds = %direct.schedule.47
  br label %direct.schedule.48

direct.false766:                                  ; preds = %direct.schedule.47
  %1845 = load <8 x float>, ptr %.slot121, align 32
  %1846 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1845
  store <8 x float> %1846, ptr %.slot121, align 32
  br label %direct.schedule.49

direct.true777:                                   ; preds = %direct.schedule.51
  br label %direct.schedule.52

direct.false778:                                  ; preds = %direct.schedule.51
  br label %direct.schedule.53
}

define internal void @llm_attention.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_attention.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_attention.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nounwind willreturn }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(write) }

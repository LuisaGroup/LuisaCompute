	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention.full_packet
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention.full_packet:             ; @llm_attention.full_packet
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #2048
	mov	x9, #0                          ; =0x0
	ldr	x21, [x1, #136]
	add	x22, x21, #35, lsl #12          ; =143360
	add	x23, x21, #19, lsl #12          ; =77824
	ldr	x8, [x0]
	ldr	x13, [x0, #16]
	ldr	x25, [x0, #32]
	ldr	w10, [x1]
	ldr	w11, [x1, #36]
	add	w10, w11, w10, lsl #5
	dup.4s	v0, w10
	ldr	x10, [x0, #48]
	str	x10, [sp, #88]                  ; 8-byte Spill
Lloh0:
	adrp	x10, lCPI0_0@PAGE
Lloh1:
	ldr	q1, [x10, lCPI0_0@PAGEOFF]
	add.4s	v1, v0, v1
Lloh2:
	adrp	x10, lCPI0_1@PAGE
Lloh3:
	ldr	q2, [x10, lCPI0_1@PAGEOFF]
	add.4s	v0, v0, v2
	ushll2.2d	v2, v0, #0
	str	q2, [sp, #2016]                 ; 16-byte Spill
	ushll2.2d	v2, v1, #0
	str	q2, [sp, #2032]                 ; 16-byte Spill
	ushll.2d	v2, v0, #0
	str	q2, [sp, #1984]                 ; 16-byte Spill
	ushll.2d	v2, v1, #0
	str	q2, [sp, #2000]                 ; 16-byte Spill
	ushll2.2d	v2, v0, #7
	ushll2.2d	v3, v1, #7
	ushll.2d	v4, v0, #7
	ushll.2d	v5, v1, #7
	fmov	x10, d5
	add	x10, x8, x10, lsl #2
	add	x11, x21, #64
LBB0_1:                                 ; %copy.chunk.i
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q0, [x10, x9]
	stur	s0, [x11, #-64]
	mov	s1, v0[1]
	stur	s1, [x11, #-32]
	st1.s	{ v0 }[2], [x11]
	add	x12, x11, #32
	st1.s	{ v0 }[3], [x12]
	add	x9, x9, #16
	add	x11, x11, #128
	cmp	x9, #512
	b.ne	LBB0_1
; %bb.2:                                ; %llm_attention.contiguous_copy.exit
	mov	x9, #0                          ; =0x0
	mov.d	x10, v5[1]
	add	x10, x8, x10, lsl #2
	add	x11, x21, #68
LBB0_3:                                 ; %copy.chunk.i339
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q0, [x10, x9]
	stur	s0, [x11, #-64]
	mov	s1, v0[1]
	stur	s1, [x11, #-32]
	st1.s	{ v0 }[2], [x11]
	add	x12, x11, #32
	st1.s	{ v0 }[3], [x12]
	add	x9, x9, #16
	add	x11, x11, #128
	cmp	x9, #512
	b.ne	LBB0_3
; %bb.4:                                ; %llm_attention.contiguous_copy.exit344
	mov	x9, #0                          ; =0x0
	fmov	x10, d3
	add	x10, x8, x10, lsl #2
	add	x11, x21, #72
LBB0_5:                                 ; %copy.chunk.i345
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q0, [x10, x9]
	stur	s0, [x11, #-64]
	mov	s1, v0[1]
	stur	s1, [x11, #-32]
	st1.s	{ v0 }[2], [x11]
	add	x12, x11, #32
	st1.s	{ v0 }[3], [x12]
	add	x9, x9, #16
	add	x11, x11, #128
	cmp	x9, #512
	b.ne	LBB0_5
; %bb.6:                                ; %llm_attention.contiguous_copy.exit350
	mov	x9, #0                          ; =0x0
	mov.d	x10, v3[1]
	add	x10, x8, x10, lsl #2
	add	x11, x21, #76
LBB0_7:                                 ; %copy.chunk.i351
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q0, [x10, x9]
	stur	s0, [x11, #-64]
	mov	s1, v0[1]
	stur	s1, [x11, #-32]
	st1.s	{ v0 }[2], [x11]
	add	x12, x11, #32
	st1.s	{ v0 }[3], [x12]
	add	x9, x9, #16
	add	x11, x11, #128
	cmp	x9, #512
	b.ne	LBB0_7
; %bb.8:                                ; %llm_attention.contiguous_copy.exit356
	mov	x9, #0                          ; =0x0
	fmov	x10, d4
	add	x10, x8, x10, lsl #2
	add	x11, x21, #80
LBB0_9:                                 ; %copy.chunk.i357
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q0, [x10, x9]
	stur	s0, [x11, #-64]
	mov	s1, v0[1]
	stur	s1, [x11, #-32]
	st1.s	{ v0 }[2], [x11]
	add	x12, x11, #32
	st1.s	{ v0 }[3], [x12]
	add	x9, x9, #16
	add	x11, x11, #128
	cmp	x9, #512
	b.ne	LBB0_9
; %bb.10:                               ; %llm_attention.contiguous_copy.exit362
	mov	x9, #0                          ; =0x0
	mov.d	x10, v4[1]
	add	x10, x8, x10, lsl #2
	add	x11, x21, #84
LBB0_11:                                ; %copy.chunk.i363
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q0, [x10, x9]
	stur	s0, [x11, #-64]
	mov	s1, v0[1]
	stur	s1, [x11, #-32]
	st1.s	{ v0 }[2], [x11]
	add	x12, x11, #32
	st1.s	{ v0 }[3], [x12]
	add	x9, x9, #16
	add	x11, x11, #128
	cmp	x9, #512
	b.ne	LBB0_11
; %bb.12:                               ; %llm_attention.contiguous_copy.exit368
	mov	x9, #0                          ; =0x0
	fmov	x10, d2
	add	x10, x8, x10, lsl #2
	add	x11, x21, #88
LBB0_13:                                ; %copy.chunk.i369
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q0, [x10, x9]
	stur	s0, [x11, #-64]
	mov	s1, v0[1]
	stur	s1, [x11, #-32]
	st1.s	{ v0 }[2], [x11]
	add	x12, x11, #32
	st1.s	{ v0 }[3], [x12]
	add	x9, x9, #16
	add	x11, x11, #128
	cmp	x9, #512
	b.ne	LBB0_13
; %bb.14:                               ; %llm_attention.contiguous_copy.exit374
	str	x13, [sp, #344]                 ; 8-byte Spill
	stp	q5, q4, [sp, #16]               ; 32-byte Folded Spill
	stp	q3, q2, [sp, #48]               ; 32-byte Folded Spill
	mov	x9, #0                          ; =0x0
	mov.d	x10, v2[1]
	add	x8, x8, x10, lsl #2
	add	x10, x21, #92
LBB0_15:                                ; %copy.chunk.i375
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q0, [x8, x9]
	stur	s0, [x10, #-64]
	mov	s1, v0[1]
	stur	s1, [x10, #-32]
	st1.s	{ v0 }[2], [x10]
	add	x11, x10, #32
	st1.s	{ v0 }[3], [x11]
	add	x9, x9, #16
	add	x10, x10, #128
	cmp	x9, #512
	b.ne	LBB0_15
; %bb.16:                               ; %direct.true.preheader
	add	x26, x21, #1, lsl #12           ; =4096
	add	x0, x21, #1, lsl #12            ; =4096
	mov	w1, #4096                       ; =0x1000
	bl	_bzero
	mov	x27, #0                         ; =0x0
	add	x28, x21, #3, lsl #12           ; =12288
	add	x20, x22, #512
	add	x8, x21, #35, lsl #12           ; =143360
	add	x19, x8, #1024
	ldr	q0, [sp, #2016]                 ; 16-byte Reload
	shrn.2s	v0, v0, #2
	ldr	q1, [sp, #1984]                 ; 16-byte Reload
	shrn.2s	v1, v1, #2
	ldr	q2, [sp, #2032]                 ; 16-byte Reload
	shrn.2s	v2, v2, #2
	ldr	q3, [sp, #2000]                 ; 16-byte Reload
	shrn.2s	v3, v3, #2
	mov	w8, #8193                       ; =0x2001
	dup.2s	v4, w8
	umull.2d	v6, v3, v4
	umull.2d	v5, v2, v4
	stp	q5, q6, [sp, #192]              ; 32-byte Folded Spill
	umull.2d	v5, v1, v4
	umull.2d	v4, v0, v4
	stp	q4, q5, [sp, #160]              ; 32-byte Folded Spill
	mov	w8, #128                        ; =0x80
	movk	w8, #16, lsl #16
	dup.2s	v4, w8
	umull.2d	v6, v3, v4
	umull.2d	v7, v2, v4
	umull.2d	v16, v1, v4
	umull.2d	v17, v0, v4
	mov	w8, #12384                      ; =0x3060
	add	x8, x21, x8
	str	x8, [sp, #152]                  ; 8-byte Spill
	mov	w8, #12388                      ; =0x3064
	add	x8, x21, x8
	str	x8, [sp, #144]                  ; 8-byte Spill
	mov	w8, #12392                      ; =0x3068
	add	x8, x21, x8
	str	x8, [sp, #136]                  ; 8-byte Spill
	mov	w8, #12396                      ; =0x306c
	add	x8, x21, x8
	str	x8, [sp, #128]                  ; 8-byte Spill
	mov	w8, #12400                      ; =0x3070
	add	x8, x21, x8
	str	x8, [sp, #120]                  ; 8-byte Spill
	mov	w8, #12404                      ; =0x3074
	add	x8, x21, x8
	str	x8, [sp, #112]                  ; 8-byte Spill
	mov	w8, #12408                      ; =0x3078
	add	x8, x21, x8
	str	x8, [sp, #104]                  ; 8-byte Spill
	mov	w8, #12412                      ; =0x307c
	add	x8, x21, x8
	str	x8, [sp, #96]                   ; 8-byte Spill
	add	x8, x21, #19, lsl #12           ; =77824
	add	x8, x8, #96
	str	x8, [sp, #264]                  ; 8-byte Spill
	mov	w8, #62154                      ; =0xf2ca
	movk	w8, #61769, lsl #16
	dup.4s	v1, w8
	ldr	x1, [sp, #344]                  ; 8-byte Reload
	dup.2d	v18, x1
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	stp	q0, q18, [sp, #224]             ; 32-byte Folded Spill
	mov	w24, #3                         ; =0x3
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	mov.16b	v0, v1
	stp	q7, q6, [sp, #304]              ; 32-byte Folded Spill
	stp	q17, q16, [sp, #272]            ; 32-byte Folded Spill
LBB0_17:                                ; %direct.true152
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_23 Depth 2
                                        ;     Child Loop BB0_25 Depth 2
                                        ;     Child Loop BB0_27 Depth 2
                                        ;     Child Loop BB0_29 Depth 2
                                        ;     Child Loop BB0_31 Depth 2
                                        ;     Child Loop BB0_33 Depth 2
                                        ;     Child Loop BB0_35 Depth 2
                                        ;     Child Loop BB0_37 Depth 2
                                        ;     Child Loop BB0_39 Depth 2
                                        ;     Child Loop BB0_41 Depth 2
                                        ;     Child Loop BB0_43 Depth 2
                                        ;     Child Loop BB0_45 Depth 2
                                        ;     Child Loop BB0_47 Depth 2
                                        ;     Child Loop BB0_49 Depth 2
                                        ;     Child Loop BB0_51 Depth 2
                                        ;     Child Loop BB0_53 Depth 2
                                        ;     Child Loop BB0_20 Depth 2
                                        ;     Child Loop BB0_69 Depth 2
                                        ;     Child Loop BB0_55 Depth 2
                                        ;     Child Loop BB0_57 Depth 2
                                        ;     Child Loop BB0_59 Depth 2
                                        ;     Child Loop BB0_61 Depth 2
                                        ;     Child Loop BB0_63 Depth 2
                                        ;       Child Loop BB0_64 Depth 3
	str	q0, [sp, #2000]                 ; 16-byte Spill
	str	q1, [sp, #2016]                 ; 16-byte Spill
	cmp	x27, #512
	b.ne	LBB0_22
; %bb.18:                               ; %direct.true752.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	b	LBB0_20
LBB0_19:                                ; %direct.schedule.49
                                        ;   in Loop: Header=BB0_20 Depth=2
	add	x9, x28, x8, lsl #5
	stp	q1, q0, [x9]
	add	x8, x8, #1
	cmp	x8, #2048
	b.eq	LBB0_67
LBB0_20:                                ; %direct.true752
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	cmp	x8, #127
	b.hi	LBB0_19
; %bb.21:                               ; %direct.true765
                                        ;   in Loop: Header=BB0_20 Depth=2
	add	x9, x8, #256, lsl #12           ; =1048576
	dup.2d	v0, x9
	add.2d	v1, v0, v17
	add.2d	v2, v0, v16
	add.2d	v3, v0, v7
	add.2d	v0, v0, v6
	shl.2d	v0, v0, #2
	shl.2d	v3, v3, #2
	shl.2d	v2, v2, #2
	shl.2d	v1, v1, #2
	add.2d	v1, v18, v1
	add.2d	v2, v18, v2
	add.2d	v3, v18, v3
	add.2d	v0, v18, v0
	mov.d	x9, v0[1]
	fmov	x10, d0
	mov.d	x11, v3[1]
	fmov	x12, d3
	mov.d	x13, v2[1]
	fmov	x14, d2
	mov.d	x15, v1[1]
	ldr	s0, [x14]
	ld1.s	{ v0 }[1], [x13]
	fmov	x13, d1
	ld1.s	{ v0 }[2], [x13]
	ld1.s	{ v0 }[3], [x15]
	ldr	s1, [x10]
	ld1.s	{ v1 }[1], [x9]
	ld1.s	{ v1 }[2], [x12]
	ld1.s	{ v1 }[3], [x11]
	b	LBB0_19
LBB0_22:                                ; %direct.true155
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
	lsl	x8, x27, #4
	dup.2d	v0, x8
	ldr	q1, [sp, #208]                  ; 16-byte Reload
	add.2d	v3, v0, v1
	ldr	q1, [sp, #160]                  ; 16-byte Reload
	add.2d	v4, v0, v1
	ldp	q1, q5, [sp, #176]              ; 32-byte Folded Reload
	add.2d	v2, v0, v5
	add.2d	v0, v0, v1
	shl.2d	v1, v0, #7
	shl.2d	v2, v2, #7
	shl.2d	v0, v4, #7
	shl.2d	v3, v3, #7
	fmov	x8, d3
	add	x10, x1, x8, lsl #2
	ldr	x11, [sp, #152]                 ; 8-byte Reload
LBB0_23:                                ; %copy.chunk.i381
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q4, [x10, x9]
	stur	s4, [x11, #-96]
	mov	s5, v4[1]
	sub	x12, x11, #32
	st1.s	{ v4 }[2], [x12]
	stur	s5, [x11, #-64]
	st1.s	{ v4 }[3], [x11]
	add	x9, x9, #16
	add	x11, x11, #128
	cmp	x9, #2, lsl #12                 ; =8192
	b.ne	LBB0_23
; %bb.24:                               ; %llm_attention.contiguous_copy.1.exit
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x10, #0                         ; =0x0
	mov.d	x9, v3[1]
	add	x11, x1, x9, lsl #2
	ldr	x12, [sp, #144]                 ; 8-byte Reload
LBB0_25:                                ; %copy.chunk.i386
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x11, x10]
	stur	s3, [x12, #-96]
	mov	s4, v3[1]
	sub	x13, x12, #32
	st1.s	{ v3 }[2], [x13]
	stur	s4, [x12, #-64]
	st1.s	{ v3 }[3], [x12]
	add	x10, x10, #16
	add	x12, x12, #128
	cmp	x10, #2, lsl #12                ; =8192
	b.ne	LBB0_25
; %bb.26:                               ; %llm_attention.contiguous_copy.1.exit391
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x11, #0                         ; =0x0
	fmov	x10, d2
	add	x12, x1, x10, lsl #2
	ldr	x13, [sp, #136]                 ; 8-byte Reload
LBB0_27:                                ; %copy.chunk.i392
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x12, x11]
	stur	s3, [x13, #-96]
	mov	s4, v3[1]
	sub	x14, x13, #32
	st1.s	{ v3 }[2], [x14]
	stur	s4, [x13, #-64]
	st1.s	{ v3 }[3], [x13]
	add	x11, x11, #16
	add	x13, x13, #128
	cmp	x11, #2, lsl #12                ; =8192
	b.ne	LBB0_27
; %bb.28:                               ; %llm_attention.contiguous_copy.1.exit397
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x12, #0                         ; =0x0
	mov.d	x11, v2[1]
	add	x13, x1, x11, lsl #2
	ldr	x14, [sp, #128]                 ; 8-byte Reload
LBB0_29:                                ; %copy.chunk.i398
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x13, x12]
	stur	s2, [x14, #-96]
	mov	s3, v2[1]
	sub	x15, x14, #32
	st1.s	{ v2 }[2], [x15]
	stur	s3, [x14, #-64]
	st1.s	{ v2 }[3], [x14]
	add	x12, x12, #16
	add	x14, x14, #128
	cmp	x12, #2, lsl #12                ; =8192
	b.ne	LBB0_29
; %bb.30:                               ; %llm_attention.contiguous_copy.1.exit403
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x13, #0                         ; =0x0
	fmov	x12, d1
	add	x14, x1, x12, lsl #2
	ldr	x15, [sp, #120]                 ; 8-byte Reload
LBB0_31:                                ; %copy.chunk.i404
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x14, x13]
	stur	s2, [x15, #-96]
	mov	s3, v2[1]
	sub	x16, x15, #32
	st1.s	{ v2 }[2], [x16]
	stur	s3, [x15, #-64]
	st1.s	{ v2 }[3], [x15]
	add	x13, x13, #16
	add	x15, x15, #128
	cmp	x13, #2, lsl #12                ; =8192
	b.ne	LBB0_31
; %bb.32:                               ; %llm_attention.contiguous_copy.1.exit409
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x14, #0                         ; =0x0
	mov.d	x13, v1[1]
	add	x15, x1, x13, lsl #2
	ldr	x16, [sp, #112]                 ; 8-byte Reload
LBB0_33:                                ; %copy.chunk.i410
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q1, [x15, x14]
	stur	s1, [x16, #-96]
	mov	s2, v1[1]
	sub	x17, x16, #32
	st1.s	{ v1 }[2], [x17]
	stur	s2, [x16, #-64]
	st1.s	{ v1 }[3], [x16]
	add	x14, x14, #16
	add	x16, x16, #128
	cmp	x14, #2, lsl #12                ; =8192
	b.ne	LBB0_33
; %bb.34:                               ; %llm_attention.contiguous_copy.1.exit415
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x15, #0                         ; =0x0
	fmov	x14, d0
	add	x16, x1, x14, lsl #2
	ldr	x17, [sp, #104]                 ; 8-byte Reload
LBB0_35:                                ; %copy.chunk.i416
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q1, [x16, x15]
	stur	s1, [x17, #-96]
	mov	s2, v1[1]
	sub	x0, x17, #32
	st1.s	{ v1 }[2], [x0]
	stur	s2, [x17, #-64]
	st1.s	{ v1 }[3], [x17]
	add	x15, x15, #16
	add	x17, x17, #128
	cmp	x15, #2, lsl #12                ; =8192
	b.ne	LBB0_35
; %bb.36:                               ; %llm_attention.contiguous_copy.1.exit421
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x16, #0                         ; =0x0
	mov.d	x15, v0[1]
	add	x17, x1, x15, lsl #2
	ldr	x0, [sp, #96]                   ; 8-byte Reload
LBB0_37:                                ; %copy.chunk.i422
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x17, x16]
	stur	s0, [x0, #-96]
	mov	s1, v0[1]
	sub	x1, x0, #32
	st1.s	{ v0 }[2], [x1]
	stur	s1, [x0, #-64]
	st1.s	{ v0 }[3], [x0]
	add	x16, x16, #16
	add	x0, x0, #128
	cmp	x16, #2, lsl #12                ; =8192
	b.ne	LBB0_37
; %bb.38:                               ; %direct.true181
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x16, #0                         ; =0x0
	add	x8, x25, x8, lsl #2
	add	x17, x21, #19, lsl #12          ; =77824
LBB0_39:                                ; %copy.chunk.i428
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x8, x16]
	str	s0, [x17]
	mov	s1, v0[1]
	str	s1, [x17, #32]
	add	x0, x17, #64
	st1.s	{ v0 }[2], [x0]
	add	x0, x17, #96
	st1.s	{ v0 }[3], [x0]
	add	x16, x16, #16
	add	x17, x17, #128
	cmp	x16, #2, lsl #12                ; =8192
	b.ne	LBB0_39
; %bb.40:                               ; %llm_attention.contiguous_copy.2.exit
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	add	x9, x25, x9, lsl #2
	add	x16, x23, #100
LBB0_41:                                ; %copy.chunk.i433
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x9, x8]
	stur	s0, [x16, #-96]
	mov	s1, v0[1]
	sub	x17, x16, #32
	st1.s	{ v0 }[2], [x17]
	stur	s1, [x16, #-64]
	st1.s	{ v0 }[3], [x16]
	add	x8, x8, #16
	add	x16, x16, #128
	cmp	x8, #2, lsl #12                 ; =8192
	b.ne	LBB0_41
; %bb.42:                               ; %llm_attention.contiguous_copy.2.exit438
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	add	x9, x25, x10, lsl #2
	add	x10, x23, #104
LBB0_43:                                ; %copy.chunk.i439
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x9, x8]
	stur	s0, [x10, #-96]
	mov	s1, v0[1]
	sub	x16, x10, #32
	st1.s	{ v0 }[2], [x16]
	stur	s1, [x10, #-64]
	st1.s	{ v0 }[3], [x10]
	add	x8, x8, #16
	add	x10, x10, #128
	cmp	x8, #2, lsl #12                 ; =8192
	b.ne	LBB0_43
; %bb.44:                               ; %llm_attention.contiguous_copy.2.exit444
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	add	x9, x25, x11, lsl #2
	add	x10, x23, #108
LBB0_45:                                ; %copy.chunk.i445
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x9, x8]
	stur	s0, [x10, #-96]
	mov	s1, v0[1]
	sub	x11, x10, #32
	st1.s	{ v0 }[2], [x11]
	stur	s1, [x10, #-64]
	st1.s	{ v0 }[3], [x10]
	add	x8, x8, #16
	add	x10, x10, #128
	cmp	x8, #2, lsl #12                 ; =8192
	b.ne	LBB0_45
; %bb.46:                               ; %llm_attention.contiguous_copy.2.exit450
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	add	x9, x25, x12, lsl #2
	add	x10, x23, #112
LBB0_47:                                ; %copy.chunk.i451
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x9, x8]
	stur	s0, [x10, #-96]
	mov	s1, v0[1]
	sub	x11, x10, #32
	st1.s	{ v0 }[2], [x11]
	stur	s1, [x10, #-64]
	st1.s	{ v0 }[3], [x10]
	add	x8, x8, #16
	add	x10, x10, #128
	cmp	x8, #2, lsl #12                 ; =8192
	b.ne	LBB0_47
; %bb.48:                               ; %llm_attention.contiguous_copy.2.exit456
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	add	x9, x25, x13, lsl #2
	add	x10, x23, #116
LBB0_49:                                ; %copy.chunk.i457
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x9, x8]
	stur	s0, [x10, #-96]
	mov	s1, v0[1]
	sub	x11, x10, #32
	st1.s	{ v0 }[2], [x11]
	stur	s1, [x10, #-64]
	st1.s	{ v0 }[3], [x10]
	add	x8, x8, #16
	add	x10, x10, #128
	cmp	x8, #2, lsl #12                 ; =8192
	b.ne	LBB0_49
; %bb.50:                               ; %llm_attention.contiguous_copy.2.exit462
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	add	x9, x25, x14, lsl #2
	add	x10, x23, #120
LBB0_51:                                ; %copy.chunk.i463
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x9, x8]
	stur	s0, [x10, #-96]
	mov	s1, v0[1]
	sub	x11, x10, #32
	st1.s	{ v0 }[2], [x11]
	stur	s1, [x10, #-64]
	st1.s	{ v0 }[3], [x10]
	add	x8, x8, #16
	add	x10, x10, #128
	cmp	x8, #2, lsl #12                 ; =8192
	b.ne	LBB0_51
; %bb.52:                               ; %llm_attention.contiguous_copy.2.exit468
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	add	x9, x25, x15, lsl #2
	add	x10, x23, #124
LBB0_53:                                ; %copy.chunk.i469
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x9, x8]
	stur	s0, [x10, #-96]
	mov	s1, v0[1]
	sub	x11, x10, #32
	st1.s	{ v0 }[2], [x11]
	stur	s1, [x10, #-64]
	st1.s	{ v0 }[3], [x10]
	add	x8, x8, #16
	add	x10, x10, #128
	cmp	x8, #2, lsl #12                 ; =8192
	b.ne	LBB0_53
LBB0_54:                                ; %direct.true208.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	str	q20, [sp, #1600]                ; 16-byte Spill
	str	q19, [sp, #1616]                ; 16-byte Spill
	movi.2d	v1, #0000000000000000
	mov	x8, x21
	movi.2d	v0, #0000000000000000
	mov	w9, #128                        ; =0x80
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
LBB0_55:                                ; %direct.true208
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q17, q16, [x8]
	ldr	q18, [x8, #12304]
	ldr	q19, [x8, #12288]
	fmul.4s	v19, v17, v19
	fmul.4s	v18, v16, v18
	fadd.4s	v1, v1, v18
	fadd.4s	v7, v7, v19
	ldr	q18, [x8, #16400]
	ldr	q19, [x8, #16384]
	fmul.4s	v19, v17, v19
	fmul.4s	v18, v16, v18
	fadd.4s	v6, v6, v18
	fadd.4s	v5, v5, v19
	ldr	q18, [x8, #20496]
	ldr	q19, [x8, #20480]
	fmul.4s	v19, v17, v19
	fmul.4s	v18, v16, v18
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v19
	ldr	q18, [x8, #24592]
	ldr	q19, [x8, #24576]
	fmul.4s	v17, v17, v19
	fmul.4s	v16, v16, v18
	fadd.4s	v2, v2, v16
	fadd.4s	v0, v0, v17
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_55
; %bb.56:                               ; %direct.true244.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	movi.2d	v17, #0000000000000000
	mov	x8, x21
	movi.2d	v16, #0000000000000000
	mov	w9, #128                        ; =0x80
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
LBB0_57:                                ; %direct.true244
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q25, q24, [x8]
	ldr	q26, [x8, #28688]
	ldr	q27, [x8, #28672]
	fmul.4s	v27, v25, v27
	fmul.4s	v26, v24, v26
	fadd.4s	v17, v17, v26
	fadd.4s	v23, v23, v27
	ldr	q26, [x8, #32784]
	ldr	q27, [x8, #32768]
	fmul.4s	v27, v25, v27
	fmul.4s	v26, v24, v26
	fadd.4s	v22, v22, v26
	fadd.4s	v21, v21, v27
	ldr	q26, [x8, #36880]
	ldr	q27, [x8, #36864]
	fmul.4s	v27, v25, v27
	fmul.4s	v26, v24, v26
	fadd.4s	v20, v20, v26
	fadd.4s	v19, v19, v27
	ldr	q26, [x8, #40976]
	ldr	q27, [x8, #40960]
	fmul.4s	v25, v25, v27
	fmul.4s	v24, v24, v26
	fadd.4s	v18, v18, v24
	fadd.4s	v16, v16, v25
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_57
; %bb.58:                               ; %direct.true282.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	str	q1, [sp, #1984]                 ; 16-byte Spill
	movi.2d	v25, #0000000000000000
	mov	x8, x21
	movi.2d	v24, #0000000000000000
	mov	w9, #128                        ; =0x80
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v31, #0000000000000000
LBB0_59:                                ; %direct.true282
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q9, q8, [x8]
	ldr	q10, [x8, #45072]
	ldr	q11, [x8, #45056]
	fmul.4s	v11, v9, v11
	fmul.4s	v10, v8, v10
	fadd.4s	v25, v25, v10
	fadd.4s	v31, v31, v11
	ldr	q10, [x8, #49168]
	ldr	q11, [x8, #49152]
	fmul.4s	v11, v9, v11
	fmul.4s	v10, v8, v10
	fadd.4s	v30, v30, v10
	fadd.4s	v29, v29, v11
	ldr	q10, [x8, #53264]
	ldr	q11, [x8, #53248]
	fmul.4s	v11, v9, v11
	fmul.4s	v10, v8, v10
	fadd.4s	v28, v28, v10
	fadd.4s	v27, v27, v11
	ldr	q10, [x8, #57360]
	ldr	q11, [x8, #57344]
	fmul.4s	v9, v9, v11
	fmul.4s	v8, v8, v10
	fadd.4s	v26, v26, v8
	fadd.4s	v24, v24, v9
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_59
; %bb.60:                               ; %direct.true320.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	str	q3, [sp, #1952]                 ; 16-byte Spill
	str	q2, [sp, #1968]                 ; 16-byte Spill
	str	q0, [sp, #2032]                 ; 16-byte Spill
	movi.2d	v9, #0000000000000000
	mov	x8, x21
	movi.2d	v8, #0000000000000000
	mov	w9, #128                        ; =0x80
	movi.2d	v10, #0000000000000000
	movi.2d	v11, #0000000000000000
	movi.2d	v12, #0000000000000000
	movi.2d	v13, #0000000000000000
	movi.2d	v14, #0000000000000000
	movi.2d	v15, #0000000000000000
LBB0_61:                                ; %direct.true320
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q1, q0, [x8]
	ldr	q2, [x8, #61456]
	ldr	q3, [x8, #61440]
	fmul.4s	v3, v1, v3
	fmul.4s	v2, v0, v2
	fadd.4s	v9, v9, v2
	fadd.4s	v15, v15, v3
	add	x10, x8, #16, lsl #12           ; =65536
	ldp	q3, q2, [x10]
	fmul.4s	v3, v1, v3
	fmul.4s	v2, v0, v2
	fadd.4s	v14, v14, v2
	fadd.4s	v13, v13, v3
	add	x10, x8, #17, lsl #12           ; =69632
	ldp	q3, q2, [x10]
	fmul.4s	v3, v1, v3
	fmul.4s	v2, v0, v2
	fadd.4s	v12, v12, v2
	fadd.4s	v11, v11, v3
	add	x10, x8, #18, lsl #12           ; =73728
	ldp	q3, q2, [x10]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v10, v10, v0
	fadd.4s	v8, v8, v1
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_61
; %bb.62:                               ; %direct.false321
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	mov	w9, #1267                       ; =0x4f3
	movk	w9, #15797, lsl #16
	dup.4s	v2, w9
	fmul.4s	v0, v7, v2
	str	q0, [sp, #1840]                 ; 16-byte Spill
	ldr	q0, [sp, #1984]                 ; 16-byte Reload
	fmul.4s	v0, v0, v2
	str	q0, [sp, #1696]                 ; 16-byte Spill
	fmul.4s	v3, v6, v2
	fmul.4s	v5, v5, v2
	fmul.4s	v6, v4, v2
	ldr	q0, [sp, #1952]                 ; 16-byte Reload
	fmul.4s	v7, v0, v2
	ldr	q0, [sp, #1968]                 ; 16-byte Reload
	fmul.4s	v0, v0, v2
	ldr	q1, [sp, #2032]                 ; 16-byte Reload
	fmul.4s	v1, v1, v2
	fmul.4s	v17, v17, v2
	fmul.4s	v23, v23, v2
	fmul.4s	v22, v22, v2
	fmul.4s	v21, v21, v2
	fmul.4s	v20, v20, v2
	fmul.4s	v19, v19, v2
	fmul.4s	v18, v18, v2
	fmul.4s	v16, v16, v2
	fmul.4s	v25, v25, v2
	fmul.4s	v31, v31, v2
	fmul.4s	v30, v30, v2
	fmul.4s	v29, v29, v2
	fmul.4s	v28, v28, v2
	fmul.4s	v27, v27, v2
	fmul.4s	v26, v26, v2
	fmul.4s	v24, v24, v2
	fmul.4s	v9, v9, v2
	fmul.4s	v15, v15, v2
	fmul.4s	v14, v14, v2
	fmul.4s	v13, v13, v2
	fmul.4s	v12, v12, v2
	fmul.4s	v11, v11, v2
	fmul.4s	v10, v10, v2
	fmul.4s	v2, v8, v2
	cmp	x27, #512
	cset	w9, lo
	dup.4h	v4, w9
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	str	q4, [sp, #1552]                 ; 16-byte Spill
	mov	w9, #62154                      ; =0xf2ca
	movk	w9, #61769, lsl #16
	dup.4s	v8, w9
	bif.16b	v5, v8, v4
	bif.16b	v3, v8, v4
	str	q3, [sp, #1680]                 ; 16-byte Spill
	mov.16b	v3, v4
	bsl.16b	v3, v7, v8
	str	q3, [sp, #1936]                 ; 16-byte Spill
	bif.16b	v6, v8, v4
	str	q6, [sp, #1664]                 ; 16-byte Spill
	bif.16b	v1, v8, v4
	str	q1, [sp, #1984]                 ; 16-byte Spill
	bif.16b	v0, v8, v4
	str	q0, [sp, #1648]                 ; 16-byte Spill
	mov.16b	v7, v4
	bsl.16b	v7, v23, v8
	str	q7, [sp, #1920]                 ; 16-byte Spill
	mov.16b	v0, v4
	bsl.16b	v0, v17, v8
	str	q0, [sp, #2032]                 ; 16-byte Spill
	mov.16b	v17, v4
	bsl.16b	v17, v21, v8
	str	q17, [sp, #1968]                ; 16-byte Spill
	mov.16b	v23, v4
	bsl.16b	v23, v22, v8
	str	q23, [sp, #1712]                ; 16-byte Spill
	bif.16b	v19, v8, v4
	str	q19, [sp, #1904]                ; 16-byte Spill
	mov.16b	v21, v4
	bsl.16b	v21, v20, v8
	str	q21, [sp, #1728]                ; 16-byte Spill
	bif.16b	v16, v8, v4
	str	q16, [sp, #1952]                ; 16-byte Spill
	mov.16b	v20, v4
	bsl.16b	v20, v18, v8
	str	q20, [sp, #1744]                ; 16-byte Spill
	mov.16b	v22, v4
	bsl.16b	v22, v31, v8
	str	q22, [sp, #1888]                ; 16-byte Spill
	mov.16b	v31, v4
	bsl.16b	v31, v25, v8
	str	q31, [sp, #1760]                ; 16-byte Spill
	mov.16b	v25, v4
	bsl.16b	v25, v29, v8
	str	q25, [sp, #1872]                ; 16-byte Spill
	mov.16b	v29, v4
	bsl.16b	v29, v30, v8
	str	q29, [sp, #1776]                ; 16-byte Spill
	bif.16b	v27, v8, v4
	str	q27, [sp, #1856]                ; 16-byte Spill
	bif.16b	v28, v8, v4
	str	q28, [sp, #1792]                ; 16-byte Spill
	bif.16b	v24, v8, v4
	str	q24, [sp, #1824]                ; 16-byte Spill
	bif.16b	v26, v8, v4
	str	q26, [sp, #1808]                ; 16-byte Spill
	mov.16b	v30, v4
	bsl.16b	v30, v15, v8
	str	q30, [sp, #1632]                ; 16-byte Spill
	mov.16b	v15, v4
	bsl.16b	v15, v9, v8
	mov.16b	v9, v4
	bsl.16b	v9, v13, v8
	str	q9, [sp, #1200]                 ; 16-byte Spill
	bif.16b	v14, v8, v4
	bif.16b	v11, v8, v4
	str	q11, [sp, #1296]                ; 16-byte Spill
	mov.16b	v18, v4
	bsl.16b	v18, v12, v8
	str	q18, [sp, #1280]                ; 16-byte Spill
	bif.16b	v2, v8, v4
	str	q2, [sp, #1392]                 ; 16-byte Spill
	mov.16b	v6, v4
	bsl.16b	v6, v10, v8
	str	q6, [sp, #1376]                 ; 16-byte Spill
	mvni.4s	v13, #127, msl #16
	ldr	q4, [sp, #1840]                 ; 16-byte Reload
	fmaxnm.4s	v0, v4, v13
	fmaxnm.4s	v0, v0, v5
	mov.16b	v8, v5
	str	q5, [sp, #1472]                 ; 16-byte Spill
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v0, v0, v1
	fmaxnm.4s	v0, v0, v7
	fmaxnm.4s	v0, v0, v17
	fmaxnm.4s	v0, v0, v19
	fmaxnm.4s	v0, v0, v16
	fmaxnm.4s	v0, v0, v22
	fmaxnm.4s	v0, v0, v25
	fmaxnm.4s	v0, v0, v27
	fmaxnm.4s	v0, v0, v24
	fmaxnm.4s	v0, v0, v30
	fmaxnm.4s	v0, v0, v9
	fmaxnm.4s	v0, v0, v11
	fmaxnm.4s	v0, v0, v2
	ldr	q1, [sp, #2016]                 ; 16-byte Reload
	fmaxnm.4s	v9, v1, v0
	fsub.4s	v0, v4, v9
	mov	w9, #-1026555904                ; =0xc2d00000
	dup.4s	v1, w9
	mov	w9, #1120403456                 ; =0x42c80000
	dup.4s	v4, w9
	fcmge.4s	v2, v0, v1
	fcmge.4s	v3, v4, v0
	and.16b	v2, v2, v3
	ldr	q5, [sp, #1696]                 ; 16-byte Reload
	fmaxnm.4s	v3, v5, v13
	ldr	q10, [sp, #1680]                ; 16-byte Reload
	fmaxnm.4s	v3, v3, v10
	ldr	q30, [sp, #1664]                ; 16-byte Reload
	fmaxnm.4s	v3, v3, v30
	ldr	q11, [sp, #1648]                ; 16-byte Reload
	fmaxnm.4s	v3, v3, v11
	ldr	q7, [sp, #2032]                 ; 16-byte Reload
	fmaxnm.4s	v3, v3, v7
	fmaxnm.4s	v3, v3, v23
	fmaxnm.4s	v3, v3, v21
	fmaxnm.4s	v3, v3, v20
	fmaxnm.4s	v3, v3, v31
	fmaxnm.4s	v3, v3, v29
	fmaxnm.4s	v3, v3, v28
	fmaxnm.4s	v3, v3, v26
	fmaxnm.4s	v3, v3, v15
	str	q15, [sp, #688]                 ; 16-byte Spill
	fmaxnm.4s	v3, v3, v14
	fmaxnm.4s	v3, v3, v18
	fmaxnm.4s	v3, v3, v6
	ldr	q6, [sp, #2000]                 ; 16-byte Reload
	fmaxnm.4s	v28, v6, v3
	fsub.4s	v26, v5, v28
	fcmge.4s	v3, v26, v1
	fcmge.4s	v5, v4, v26
	and.16b	v3, v3, v5
	and.16b	v3, v3, v26
	mov	w9, #43579                      ; =0xaa3b
	movk	w9, #16312, lsl #16
	dup.4s	v27, w9
	fmul.4s	v5, v3, v27
	movi.4s	v7, #75, lsl #24
	mvni.4s	v29, #128, lsl #24
	mov.16b	v6, v29
	bsl.16b	v6, v7, v5
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	and.16b	v6, v2, v0
	fmul.4s	v2, v6, v27
	bif.16b	v7, v2, v29
	movi.4s	v18, #75, lsl #24
	fadd.4s	v2, v2, v7
	fsub.4s	v7, v2, v7
	fcvtzs.4s	v2, v5
	scvtf.4s	v5, v2
	mov	w9, #29184                      ; =0x7200
	movk	w9, #16177, lsl #16
	dup.4s	v21, w9
	fmul.4s	v16, v5, v21
	fsub.4s	v16, v3, v16
	fcvtzs.4s	v3, v7
	scvtf.4s	v7, v3
	fmul.4s	v17, v7, v21
	fsub.4s	v6, v6, v17
	mov	w9, #48782                      ; =0xbe8e
	movk	w9, #13759, lsl #16
	dup.4s	v20, w9
	fmul.4s	v7, v7, v20
	fsub.4s	v22, v6, v7
	fmul.4s	v5, v5, v20
	fsub.4s	v5, v16, v5
	mov	w9, #11226                      ; =0x2bda
	movk	w9, #14672, lsl #16
	dup.4s	v19, w9
	fmul.4s	v6, v5, v19
	mov	w9, #38601                      ; =0x96c9
	movk	w9, #15030, lsl #16
	dup.4s	v17, w9
	fadd.4s	v6, v6, v17
	mov	w9, #34982                      ; =0x88a6
	movk	w9, #15368, lsl #16
	dup.4s	v16, w9
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v6, v16
	fmul.4s	v6, v5, v6
	mov	w9, #43642                      ; =0xaa7a
	movk	w9, #15658, lsl #16
	dup.4s	v7, w9
	fadd.4s	v6, v6, v7
	fmul.4s	v23, v5, v6
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #15914, lsl #16
	dup.4s	v6, w9
	fadd.4s	v23, v23, v6
	fmul.4s	v23, v5, v23
	movi.4s	v12, #63, lsl #24
	fadd.4s	v23, v23, v12
	fmul.4s	v24, v5, v5
	fmul.4s	v23, v24, v23
	fmul.4s	v24, v22, v19
	fadd.4s	v24, v24, v17
	fmul.4s	v24, v22, v24
	fadd.4s	v24, v24, v16
	fmul.4s	v24, v22, v24
	fadd.4s	v24, v24, v7
	fmul.4s	v24, v22, v24
	fadd.4s	v24, v24, v6
	fmul.4s	v24, v22, v24
	fadd.4s	v24, v24, v12
	fmul.4s	v25, v22, v22
	fmul.4s	v24, v25, v24
	fadd.4s	v22, v22, v24
	fadd.4s	v5, v5, v23
	fmov.4s	v31, #1.00000000
	fadd.4s	v22, v22, v31
	sshr.4s	v23, v3, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v31
	fmul.4s	v22, v22, v24
	fadd.4s	v5, v5, v31
	sshr.4s	v24, v2, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v31
	fmul.4s	v5, v5, v25
	sub.4s	v3, v3, v23
	sub.4s	v2, v2, v24
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v5, v2
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	str	q0, [sp, #1488]                 ; 16-byte Spill
	fcmgt.4s	v5, v1, v0
	bic.16b	v3, v3, v5
	str	q26, [sp, #1536]                ; 16-byte Spill
	fcmgt.4s	v5, v1, v26
	bic.16b	v2, v2, v5
	fcmgt.4s	v22, v26, v4
	fneg.4s	v5, v13
	bit.16b	v2, v5, v22
	str	q2, [sp, #1520]                 ; 16-byte Spill
	fcmgt.4s	v2, v0, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #1504]                 ; 16-byte Spill
	fsub.4s	v10, v10, v28
	fcmge.4s	v2, v10, v1
	fcmge.4s	v3, v4, v10
	and.16b	v2, v2, v3
	fsub.4s	v0, v8, v9
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v27
	mov.16b	v23, v29
	bsl.16b	v23, v18, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v10
	fmul.4s	v2, v23, v27
	mov.16b	v24, v29
	bsl.16b	v24, v18, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v21
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v21
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v20
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v20
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v19
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v12
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v19
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v12
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v31
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v31
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v31
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v31
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	str	q10, [sp, #1408]                ; 16-byte Spill
	fcmgt.4s	v22, v1, v10
	bic.16b	v3, v3, v22
	str	q0, [sp, #1440]                 ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #1456]                 ; 16-byte Spill
	fcmgt.4s	v2, v10, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #1424]                 ; 16-byte Spill
	fsub.4s	v30, v30, v28
	fcmge.4s	v2, v30, v1
	fcmge.4s	v3, v4, v30
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1936]                 ; 16-byte Reload
	fsub.4s	v0, v3, v9
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v27
	mov.16b	v23, v29
	bsl.16b	v23, v18, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v30
	fmul.4s	v2, v23, v27
	mov.16b	v24, v29
	bsl.16b	v24, v18, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v21
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v21
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v20
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v20
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v19
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v12
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v19
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v12
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v31
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v31
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v31
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v31
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	str	q30, [sp, #1312]                ; 16-byte Spill
	fcmgt.4s	v22, v1, v30
	bic.16b	v3, v3, v22
	str	q0, [sp, #1344]                 ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #1360]                 ; 16-byte Spill
	fcmgt.4s	v2, v30, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #1328]                 ; 16-byte Spill
	fsub.4s	v30, v11, v28
	fcmge.4s	v2, v30, v1
	fcmge.4s	v3, v4, v30
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1984]                 ; 16-byte Reload
	fsub.4s	v0, v3, v9
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v27
	mov.16b	v23, v29
	bsl.16b	v23, v18, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v30
	fmul.4s	v2, v23, v27
	mov.16b	v24, v29
	bsl.16b	v24, v18, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v21
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v21
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v20
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v20
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v19
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v12
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v19
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v12
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v31
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v31
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v31
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v31
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	str	q30, [sp, #1216]                ; 16-byte Spill
	fcmgt.4s	v22, v1, v30
	bic.16b	v3, v3, v22
	str	q0, [sp, #1248]                 ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #1264]                 ; 16-byte Spill
	fcmgt.4s	v2, v30, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #1232]                 ; 16-byte Spill
	ldr	q0, [sp, #2032]                 ; 16-byte Reload
	fsub.4s	v30, v0, v28
	fcmge.4s	v2, v30, v1
	fcmge.4s	v3, v4, v30
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1920]                 ; 16-byte Reload
	fsub.4s	v0, v3, v9
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v27
	mov.16b	v23, v29
	bsl.16b	v23, v18, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v30
	fmul.4s	v2, v23, v27
	mov.16b	v24, v29
	bsl.16b	v24, v18, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v21
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v21
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v20
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v20
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v19
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v12
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v19
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v12
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v31
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v31
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v31
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v31
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	str	q30, [sp, #1136]                ; 16-byte Spill
	fcmgt.4s	v22, v1, v30
	bic.16b	v3, v3, v22
	str	q0, [sp, #1168]                 ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #1184]                 ; 16-byte Spill
	fcmgt.4s	v2, v30, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #1152]                 ; 16-byte Spill
	ldr	q0, [sp, #1712]                 ; 16-byte Reload
	fsub.4s	v30, v0, v28
	fcmge.4s	v2, v30, v1
	fcmge.4s	v3, v4, v30
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1968]                 ; 16-byte Reload
	fsub.4s	v0, v3, v9
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v27
	mov.16b	v23, v29
	bsl.16b	v23, v18, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v30
	fmul.4s	v2, v23, v27
	mov.16b	v24, v29
	bsl.16b	v24, v18, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v21
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v21
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v20
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v20
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v19
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v12
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v19
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v12
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v31
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v31
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v31
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v31
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	str	q30, [sp, #1072]                ; 16-byte Spill
	fcmgt.4s	v22, v1, v30
	bic.16b	v3, v3, v22
	str	q0, [sp, #1104]                 ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #1120]                 ; 16-byte Spill
	fcmgt.4s	v2, v30, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #1088]                 ; 16-byte Spill
	ldr	q0, [sp, #1728]                 ; 16-byte Reload
	fsub.4s	v30, v0, v28
	fcmge.4s	v2, v30, v1
	fcmge.4s	v3, v4, v30
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1904]                 ; 16-byte Reload
	fsub.4s	v0, v3, v9
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v27
	mov.16b	v23, v29
	bsl.16b	v23, v18, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v30
	fmul.4s	v2, v23, v27
	mov.16b	v24, v29
	bsl.16b	v24, v18, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v21
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v21
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v20
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v20
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v19
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v12
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v19
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v12
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v31
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v31
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v31
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v31
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	fcmgt.4s	v22, v1, v30
	bic.16b	v3, v3, v22
	str	q0, [sp, #1040]                 ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #1056]                 ; 16-byte Spill
	fcmgt.4s	v2, v30, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	stp	q30, q0, [sp, #1008]            ; 32-byte Folded Spill
	ldr	q0, [sp, #1744]                 ; 16-byte Reload
	fsub.4s	v30, v0, v28
	fcmge.4s	v2, v30, v1
	fcmge.4s	v3, v4, v30
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1952]                 ; 16-byte Reload
	fsub.4s	v0, v3, v9
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v27
	mov.16b	v23, v29
	bsl.16b	v23, v18, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v30
	fmul.4s	v2, v23, v27
	mov.16b	v24, v29
	bsl.16b	v24, v18, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v21
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v21
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v20
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v20
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v19
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v12
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v19
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v12
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v31
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v31
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v31
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v31
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	fcmgt.4s	v22, v1, v30
	bic.16b	v3, v3, v22
	str	q0, [sp, #976]                  ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #992]                  ; 16-byte Spill
	fcmgt.4s	v2, v30, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	stp	q30, q0, [sp, #944]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1760]                 ; 16-byte Reload
	fsub.4s	v30, v0, v28
	fcmge.4s	v2, v30, v1
	fcmge.4s	v3, v4, v30
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1888]                 ; 16-byte Reload
	fsub.4s	v0, v3, v9
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v27
	mov.16b	v23, v29
	bsl.16b	v23, v18, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v30
	fmul.4s	v2, v23, v27
	mov.16b	v24, v29
	bsl.16b	v24, v18, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v21
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v21
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v20
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v20
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v19
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v12
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v19
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v12
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v31
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v31
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v31
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v31
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	fcmgt.4s	v22, v1, v30
	bic.16b	v3, v3, v22
	str	q0, [sp, #912]                  ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #928]                  ; 16-byte Spill
	fcmgt.4s	v2, v30, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	stp	q30, q0, [sp, #880]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1776]                 ; 16-byte Reload
	fsub.4s	v30, v0, v28
	fcmge.4s	v2, v30, v1
	fcmge.4s	v3, v4, v30
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1872]                 ; 16-byte Reload
	fsub.4s	v0, v3, v9
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v27
	mov.16b	v23, v29
	bsl.16b	v23, v18, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v30
	fmul.4s	v2, v23, v27
	mov.16b	v24, v29
	bsl.16b	v24, v18, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v21
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v21
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v20
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v20
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v19
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v12
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v19
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v12
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v31
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v31
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v31
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v31
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	fcmgt.4s	v22, v1, v30
	bic.16b	v3, v3, v22
	str	q0, [sp, #848]                  ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #864]                  ; 16-byte Spill
	fcmgt.4s	v2, v30, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	stp	q30, q0, [sp, #816]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1792]                 ; 16-byte Reload
	fsub.4s	v30, v0, v28
	fcmge.4s	v2, v30, v1
	fcmge.4s	v3, v4, v30
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1856]                 ; 16-byte Reload
	fsub.4s	v0, v3, v9
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v27
	mov.16b	v23, v29
	bsl.16b	v23, v18, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v30
	fmul.4s	v2, v23, v27
	mov.16b	v24, v29
	bsl.16b	v24, v18, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v21
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v21
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v20
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v20
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v19
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v12
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v19
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v12
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v31
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v31
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v31
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v31
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	str	q30, [sp, #480]                 ; 16-byte Spill
	fcmgt.4s	v22, v1, v30
	bic.16b	v3, v3, v22
	str	q0, [sp, #784]                  ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #800]                  ; 16-byte Spill
	fcmgt.4s	v2, v30, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #768]                  ; 16-byte Spill
	ldr	q0, [sp, #1808]                 ; 16-byte Reload
	fsub.4s	v8, v0, v28
	fcmge.4s	v2, v8, v1
	fcmge.4s	v3, v4, v8
	and.16b	v2, v2, v3
	ldr	q0, [sp, #1824]                 ; 16-byte Reload
	fsub.4s	v0, v0, v9
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v27
	mov.16b	v23, v29
	bsl.16b	v23, v18, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v8
	fmul.4s	v2, v23, v27
	mov.16b	v24, v29
	bsl.16b	v24, v18, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v21
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v21
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v20
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v20
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v19
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v12
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v19
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v12
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v31
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v31
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v31
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v31
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	fcmgt.4s	v22, v1, v8
	bic.16b	v3, v3, v22
	str	q0, [sp, #736]                  ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #752]                  ; 16-byte Spill
	fcmgt.4s	v2, v8, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	stp	q8, q0, [sp, #704]              ; 32-byte Folded Spill
	fsub.4s	v8, v15, v28
	fcmge.4s	v2, v8, v1
	fcmge.4s	v3, v4, v8
	and.16b	v2, v2, v3
	ldr	q0, [sp, #1632]                 ; 16-byte Reload
	fsub.4s	v0, v0, v9
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v27
	mov.16b	v23, v29
	bsl.16b	v23, v18, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v8
	fmul.4s	v2, v23, v27
	mov.16b	v24, v29
	bsl.16b	v24, v18, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v21
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v21
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v20
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v20
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v19
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v12
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v19
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v12
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v31
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v31
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v31
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v31
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	fcmgt.4s	v22, v1, v8
	bic.16b	v3, v3, v22
	str	q0, [sp, #656]                  ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #672]                  ; 16-byte Spill
	fcmgt.4s	v2, v8, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	stp	q8, q0, [sp, #624]              ; 32-byte Folded Spill
	mov.16b	v8, v14
	fsub.4s	v11, v14, v28
	fcmge.4s	v2, v11, v1
	fcmge.4s	v3, v4, v11
	and.16b	v2, v2, v3
	ldr	q30, [sp, #1200]                ; 16-byte Reload
	fsub.4s	v0, v30, v9
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v27
	mov.16b	v23, v29
	bsl.16b	v23, v18, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v11
	fmul.4s	v2, v23, v27
	mov.16b	v24, v29
	bsl.16b	v24, v18, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v21
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v10, v25, v21
	fsub.4s	v23, v23, v10
	fmul.4s	v25, v25, v20
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v20
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v19
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v12
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v19
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v12
	fmul.4s	v10, v23, v23
	fmul.4s	v25, v10, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v31
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v31
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v31
	sshr.4s	v25, v2, #1
	shl.4s	v10, v25, #23
	add.4s	v10, v10, v31
	fmul.4s	v3, v3, v10
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	fcmgt.4s	v22, v1, v11
	bic.16b	v3, v3, v22
	str	q0, [sp, #592]                  ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #608]                  ; 16-byte Spill
	fcmgt.4s	v2, v11, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	stp	q11, q0, [sp, #560]             ; 32-byte Folded Spill
	ldr	q26, [sp, #1280]                ; 16-byte Reload
	fsub.4s	v0, v26, v28
	fcmge.4s	v2, v0, v1
	fcmge.4s	v3, v4, v0
	and.16b	v2, v2, v3
	ldr	q25, [sp, #1296]                ; 16-byte Reload
	fsub.4s	v13, v25, v9
	fcmge.4s	v3, v13, v1
	fcmge.4s	v22, v4, v13
	and.16b	v3, v3, v22
	and.16b	v3, v3, v13
	fmul.4s	v22, v3, v27
	mov.16b	v23, v29
	bsl.16b	v23, v18, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v0
	fmul.4s	v2, v23, v27
	mov.16b	v10, v29
	bsl.16b	v10, v18, v2
	fadd.4s	v2, v2, v10
	fsub.4s	v10, v2, v10
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v11, v22, v21
	fsub.4s	v3, v3, v11
	fcvtzs.4s	v10, v10
	scvtf.4s	v11, v10
	fmul.4s	v15, v11, v21
	fsub.4s	v23, v23, v15
	fmul.4s	v11, v11, v20
	fsub.4s	v23, v23, v11
	fmul.4s	v22, v22, v20
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v19
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v12
	fmul.4s	v11, v3, v3
	fmul.4s	v22, v11, v22
	fmul.4s	v11, v23, v19
	fadd.4s	v11, v11, v17
	fmul.4s	v11, v23, v11
	fadd.4s	v11, v11, v16
	fmul.4s	v11, v23, v11
	fadd.4s	v11, v11, v7
	fmul.4s	v11, v23, v11
	fadd.4s	v11, v11, v6
	fmul.4s	v11, v23, v11
	fadd.4s	v11, v11, v12
	fmul.4s	v15, v23, v23
	fmul.4s	v11, v15, v11
	fadd.4s	v23, v23, v11
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v31
	sshr.4s	v23, v10, #1
	shl.4s	v11, v23, #23
	add.4s	v11, v11, v31
	fmul.4s	v22, v22, v11
	fadd.4s	v3, v3, v31
	sshr.4s	v11, v2, #1
	shl.4s	v15, v11, #23
	add.4s	v15, v15, v31
	fmul.4s	v3, v3, v15
	sub.4s	v23, v10, v23
	sub.4s	v2, v2, v11
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	str	q0, [sp, #496]                  ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v3, v3, v22
	fcmgt.4s	v22, v1, v13
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v13, v4
	bit.16b	v2, v5, v22
	stp	q13, q2, [sp, #528]             ; 32-byte Folded Spill
	fcmgt.4s	v2, v0, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #512]                  ; 16-byte Spill
	ldr	q23, [sp, #1376]                ; 16-byte Reload
	fsub.4s	v0, v23, v28
	fcmge.4s	v2, v0, v1
	fcmge.4s	v3, v4, v0
	and.16b	v2, v2, v3
	ldr	q22, [sp, #1392]                ; 16-byte Reload
	fsub.4s	v18, v22, v9
	fcmge.4s	v3, v18, v1
	fcmge.4s	v10, v4, v18
	and.16b	v3, v3, v10
	and.16b	v3, v3, v18
	fmul.4s	v10, v3, v27
	movi.4s	v24, #75, lsl #24
	mov.16b	v11, v29
	bsl.16b	v11, v24, v10
	fadd.4s	v10, v10, v11
	fsub.4s	v10, v10, v11
	and.16b	v11, v2, v0
	fmul.4s	v2, v11, v27
	mov.16b	v15, v29
	bsl.16b	v15, v24, v2
	fadd.4s	v2, v2, v15
	fsub.4s	v15, v2, v15
	fcvtzs.4s	v2, v10
	scvtf.4s	v10, v2
	fmul.4s	v14, v10, v21
	fsub.4s	v3, v3, v14
	fcvtzs.4s	v14, v15
	scvtf.4s	v15, v14
	fmul.4s	v13, v15, v21
	fsub.4s	v11, v11, v13
	fmul.4s	v13, v15, v20
	fsub.4s	v11, v11, v13
	fmul.4s	v10, v10, v20
	fsub.4s	v3, v3, v10
	fmul.4s	v10, v3, v19
	fadd.4s	v10, v10, v17
	fmul.4s	v10, v3, v10
	fadd.4s	v10, v10, v16
	fmul.4s	v10, v3, v10
	fadd.4s	v10, v10, v7
	fmul.4s	v10, v3, v10
	fadd.4s	v10, v10, v6
	fmul.4s	v10, v3, v10
	fadd.4s	v10, v10, v12
	fmul.4s	v13, v3, v3
	fmul.4s	v10, v13, v10
	fmul.4s	v13, v11, v19
	fadd.4s	v13, v13, v17
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v13, v16
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v13, v7
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v13, v6
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v13, v12
	fmul.4s	v15, v11, v11
	fmul.4s	v13, v15, v13
	fadd.4s	v11, v11, v13
	fadd.4s	v3, v3, v10
	fadd.4s	v10, v11, v31
	sshr.4s	v11, v14, #1
	shl.4s	v13, v11, #23
	add.4s	v13, v13, v31
	fmul.4s	v10, v10, v13
	fadd.4s	v3, v3, v31
	sshr.4s	v13, v2, #1
	shl.4s	v15, v13, #23
	add.4s	v15, v15, v31
	fmul.4s	v3, v3, v15
	sub.4s	v11, v14, v11
	sub.4s	v2, v2, v13
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v11, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v10, v3
	str	q0, [sp, #416]                  ; 16-byte Spill
	fcmgt.4s	v10, v1, v0
	bic.16b	v3, v3, v10
	fcmgt.4s	v10, v1, v18
	bic.16b	v2, v2, v10
	fcmgt.4s	v10, v18, v4
	bit.16b	v2, v5, v10
	stp	q18, q2, [sp, #448]             ; 32-byte Folded Spill
	fcmgt.4s	v2, v0, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #432]                  ; 16-byte Spill
	str	q28, [sp, #1568]                ; 16-byte Spill
	ldr	q0, [sp, #2000]                 ; 16-byte Reload
	fsub.4s	v3, v0, v28
	fcmge.4s	v2, v3, v1
	fcmge.4s	v13, v4, v3
	and.16b	v13, v2, v13
	str	q9, [sp, #1584]                 ; 16-byte Spill
	ldr	q0, [sp, #2016]                 ; 16-byte Reload
	fsub.4s	v2, v0, v9
	fcmge.4s	v14, v2, v1
	fcmge.4s	v15, v4, v2
	and.16b	v14, v14, v15
	and.16b	v14, v14, v2
	fmul.4s	v15, v14, v27
	mov.16b	v0, v29
	bsl.16b	v0, v24, v15
	fadd.4s	v15, v15, v0
	fsub.4s	v0, v15, v0
	and.16b	v13, v13, v3
	fmul.4s	v27, v13, v27
	mov.16b	v15, v29
	bsl.16b	v15, v24, v27
	fadd.4s	v27, v27, v15
	fsub.4s	v27, v27, v15
	fcvtzs.4s	v0, v0
	scvtf.4s	v15, v0
	fmul.4s	v11, v15, v21
	fsub.4s	v11, v14, v11
	fcvtzs.4s	v27, v27
	scvtf.4s	v14, v27
	fmul.4s	v21, v14, v21
	fsub.4s	v21, v13, v21
	fmul.4s	v13, v15, v20
	fmul.4s	v20, v14, v20
	fsub.4s	v20, v21, v20
	fsub.4s	v21, v11, v13
	fmul.4s	v11, v21, v19
	fmul.4s	v19, v20, v19
	fadd.4s	v19, v19, v17
	fadd.4s	v17, v11, v17
	fmul.4s	v17, v21, v17
	fmul.4s	v19, v20, v19
	fadd.4s	v19, v19, v16
	fadd.4s	v16, v17, v16
	fmul.4s	v16, v21, v16
	fmul.4s	v17, v20, v19
	fadd.4s	v17, v17, v7
	fadd.4s	v7, v16, v7
	fmul.4s	v7, v21, v7
	fmul.4s	v16, v20, v17
	fadd.4s	v16, v16, v6
	fadd.4s	v6, v7, v6
	fmul.4s	v6, v21, v6
	fadd.4s	v6, v6, v12
	fmul.4s	v7, v21, v21
	fmul.4s	v6, v7, v6
	fmul.4s	v7, v20, v16
	fadd.4s	v7, v7, v12
	fmul.4s	v16, v20, v20
	fmul.4s	v7, v16, v7
	fadd.4s	v7, v20, v7
	fadd.4s	v6, v21, v6
	fadd.4s	v7, v7, v31
	sshr.4s	v16, v27, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v31
	fmul.4s	v7, v7, v17
	fadd.4s	v6, v6, v31
	sshr.4s	v17, v0, #1
	shl.4s	v19, v17, #23
	add.4s	v19, v19, v31
	fmul.4s	v6, v6, v19
	sub.4s	v16, v27, v16
	sub.4s	v0, v0, v17
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v31
	fmul.4s	v0, v6, v0
	shl.4s	v6, v16, #23
	add.4s	v6, v6, v31
	fmul.4s	v6, v7, v6
	fcmgt.4s	v7, v1, v3
	bic.16b	v6, v6, v7
	fcmgt.4s	v1, v1, v2
	bic.16b	v0, v0, v1
	fcmgt.4s	v1, v2, v4
	bit.16b	v0, v5, v1
	stp	q2, q0, [sp, #384]              ; 32-byte Folded Spill
	fcmgt.4s	v1, v3, v4
	mov.16b	v0, v1
	bsl.16b	v0, v5, v6
	stp	q3, q0, [sp, #352]              ; 32-byte Folded Spill
	ldr	q1, [sp, #1696]                 ; 16-byte Reload
	ldr	q0, [sp, #1840]                 ; 16-byte Reload
	stp	q0, q1, [x22]
	ldr	q1, [sp, #1680]                 ; 16-byte Reload
	ldr	q0, [sp, #1472]                 ; 16-byte Reload
	stp	q0, q1, [x22, #32]
	ldr	q1, [sp, #1664]                 ; 16-byte Reload
	ldr	q0, [sp, #1936]                 ; 16-byte Reload
	stp	q0, q1, [x22, #64]
	ldr	q1, [sp, #1648]                 ; 16-byte Reload
	ldr	q0, [sp, #1984]                 ; 16-byte Reload
	stp	q0, q1, [x22, #96]
	ldr	q1, [sp, #2032]                 ; 16-byte Reload
	ldr	q0, [sp, #1920]                 ; 16-byte Reload
	stp	q0, q1, [x22, #128]
	ldr	q1, [sp, #1712]                 ; 16-byte Reload
	ldr	q0, [sp, #1968]                 ; 16-byte Reload
	stp	q0, q1, [x22, #160]
	ldr	q1, [sp, #1728]                 ; 16-byte Reload
	ldr	q0, [sp, #1904]                 ; 16-byte Reload
	stp	q0, q1, [x22, #192]
	ldr	q1, [sp, #1744]                 ; 16-byte Reload
	ldr	q0, [sp, #1952]                 ; 16-byte Reload
	stp	q0, q1, [x22, #224]
	ldr	q1, [sp, #1760]                 ; 16-byte Reload
	ldr	q0, [sp, #1888]                 ; 16-byte Reload
	stp	q0, q1, [x22, #256]
	ldr	q1, [sp, #1776]                 ; 16-byte Reload
	ldr	q0, [sp, #1872]                 ; 16-byte Reload
	stp	q0, q1, [x22, #288]
	ldr	q1, [sp, #1792]                 ; 16-byte Reload
	ldr	q0, [sp, #1856]                 ; 16-byte Reload
	stp	q0, q1, [x22, #320]
	ldr	q1, [sp, #1808]                 ; 16-byte Reload
	ldr	q0, [sp, #1824]                 ; 16-byte Reload
	stp	q0, q1, [x22, #352]
	ldr	q1, [sp, #688]                  ; 16-byte Reload
	ldr	q0, [sp, #1632]                 ; 16-byte Reload
	stp	q0, q1, [x22, #384]
	stp	q30, q8, [x22, #416]
	stp	q25, q26, [x22, #448]
	stp	q22, q23, [x22, #480]
	ldr	q0, [sp, #1488]                 ; 16-byte Reload
	fcmeq.4s	v4, v0, v0
	ldr	q2, [sp, #224]                  ; 16-byte Reload
	ldr	q0, [sp, #1504]                 ; 16-byte Reload
	bif.16b	v0, v2, v4
	str	q0, [sp, #2032]                 ; 16-byte Spill
	ldr	q0, [sp, #1536]                 ; 16-byte Reload
	fcmeq.4s	v4, v0, v0
	ldr	q0, [sp, #1520]                 ; 16-byte Reload
	bif.16b	v0, v2, v4
	str	q0, [sp, #2016]                 ; 16-byte Spill
	ldr	q0, [sp, #1408]                 ; 16-byte Reload
	fcmeq.4s	v4, v0, v0
	ldr	q0, [sp, #1424]                 ; 16-byte Reload
	bif.16b	v0, v2, v4
	str	q0, [sp, #2000]                 ; 16-byte Spill
	ldr	q0, [sp, #1440]                 ; 16-byte Reload
	fcmeq.4s	v5, v0, v0
	ldr	q0, [sp, #1456]                 ; 16-byte Reload
	bif.16b	v0, v2, v5
	str	q0, [sp, #1968]                 ; 16-byte Spill
	ldr	q0, [sp, #1312]                 ; 16-byte Reload
	fcmeq.4s	v6, v0, v0
	ldr	q0, [sp, #1328]                 ; 16-byte Reload
	bif.16b	v0, v2, v6
	str	q0, [sp, #1984]                 ; 16-byte Spill
	ldr	q0, [sp, #1344]                 ; 16-byte Reload
	fcmeq.4s	v7, v0, v0
	ldr	q0, [sp, #1360]                 ; 16-byte Reload
	bif.16b	v0, v2, v7
	str	q0, [sp, #1936]                 ; 16-byte Spill
	ldr	q0, [sp, #1216]                 ; 16-byte Reload
	fcmeq.4s	v16, v0, v0
	ldr	q0, [sp, #1232]                 ; 16-byte Reload
	bif.16b	v0, v2, v16
	str	q0, [sp, #1952]                 ; 16-byte Spill
	ldr	q0, [sp, #1248]                 ; 16-byte Reload
	fcmeq.4s	v17, v0, v0
	ldr	q0, [sp, #1264]                 ; 16-byte Reload
	mov.16b	v3, v17
	bsl.16b	v3, v0, v2
	ldr	q0, [sp, #1136]                 ; 16-byte Reload
	fcmeq.4s	v19, v0, v0
	ldr	q0, [sp, #1152]                 ; 16-byte Reload
	bif.16b	v0, v2, v19
	str	q0, [sp, #1920]                 ; 16-byte Spill
	ldr	q0, [sp, #1168]                 ; 16-byte Reload
	fcmeq.4s	v20, v0, v0
	ldr	q0, [sp, #1184]                 ; 16-byte Reload
	mov.16b	v7, v20
	bsl.16b	v7, v0, v2
	ldr	q0, [sp, #1072]                 ; 16-byte Reload
	fcmeq.4s	v21, v0, v0
	ldr	q0, [sp, #1088]                 ; 16-byte Reload
	mov.16b	v16, v21
	bsl.16b	v16, v0, v2
	ldr	q0, [sp, #1104]                 ; 16-byte Reload
	fcmeq.4s	v27, v0, v0
	ldr	q0, [sp, #1120]                 ; 16-byte Reload
	mov.16b	v5, v27
	bsl.16b	v5, v0, v2
	ldp	q1, q0, [sp, #1008]             ; 32-byte Folded Reload
	fcmeq.4s	v11, v1, v1
	bsl.16b	v11, v0, v2
	ldr	q0, [sp, #1040]                 ; 16-byte Reload
	fcmeq.4s	v13, v0, v0
	ldr	q0, [sp, #1056]                 ; 16-byte Reload
	bsl.16b	v13, v0, v2
	ldp	q4, q0, [sp, #944]              ; 32-byte Folded Reload
	fcmeq.4s	v14, v4, v4
	bsl.16b	v14, v0, v2
	ldp	q6, q0, [sp, #976]              ; 32-byte Folded Reload
	fcmeq.4s	v15, v6, v6
	bsl.16b	v15, v0, v2
	ldr	q0, [sp, #880]                  ; 16-byte Reload
	fcmeq.4s	v10, v0, v0
	ldr	q0, [sp, #896]                  ; 16-byte Reload
	bsl.16b	v10, v0, v2
	ldr	q0, [sp, #912]                  ; 16-byte Reload
	fcmeq.4s	v12, v0, v0
	ldr	q0, [sp, #928]                  ; 16-byte Reload
	bsl.16b	v12, v0, v2
	ldr	q0, [sp, #816]                  ; 16-byte Reload
	fcmeq.4s	v9, v0, v0
	ldr	q0, [sp, #832]                  ; 16-byte Reload
	mov.16b	v19, v9
	bsl.16b	v19, v0, v2
	ldr	q0, [sp, #848]                  ; 16-byte Reload
	fcmeq.4s	v8, v0, v0
	ldr	q0, [sp, #864]                  ; 16-byte Reload
	mov.16b	v17, v8
	bsl.16b	v17, v0, v2
	ldr	q0, [sp, #480]                  ; 16-byte Reload
	fcmeq.4s	v31, v0, v0
	ldr	q0, [sp, #768]                  ; 16-byte Reload
	bsl.16b	v31, v0, v2
	ldr	q0, [sp, #784]                  ; 16-byte Reload
	fcmeq.4s	v30, v0, v0
	ldr	q0, [sp, #800]                  ; 16-byte Reload
	bsl.16b	v30, v0, v2
	ldr	q0, [sp, #704]                  ; 16-byte Reload
	fcmeq.4s	v29, v0, v0
	ldr	q0, [sp, #720]                  ; 16-byte Reload
	mov.16b	v9, v29
	bsl.16b	v9, v0, v2
	ldr	q0, [sp, #736]                  ; 16-byte Reload
	fcmeq.4s	v28, v0, v0
	ldr	q0, [sp, #752]                  ; 16-byte Reload
	bsl.16b	v28, v0, v2
	ldr	q0, [sp, #624]                  ; 16-byte Reload
	fcmeq.4s	v26, v0, v0
	ldr	q0, [sp, #640]                  ; 16-byte Reload
	mov.16b	v20, v26
	bsl.16b	v20, v0, v2
	ldp	q0, q1, [sp, #656]              ; 32-byte Folded Reload
	fcmeq.4s	v0, v0, v0
	mov.16b	v27, v0
	bsl.16b	v27, v1, v2
	ldr	q0, [sp, #560]                  ; 16-byte Reload
	fcmeq.4s	v1, v0, v0
	ldr	q0, [sp, #576]                  ; 16-byte Reload
	mov.16b	v29, v1
	bsl.16b	v29, v0, v2
	ldp	q1, q0, [sp, #592]              ; 32-byte Folded Reload
	fcmeq.4s	v25, v1, v1
	mov.16b	v21, v25
	bsl.16b	v21, v0, v2
	ldr	q0, [sp, #496]                  ; 16-byte Reload
	fcmeq.4s	v24, v0, v0
	ldr	q0, [sp, #512]                  ; 16-byte Reload
	bsl.16b	v24, v0, v2
	ldr	q0, [sp, #528]                  ; 16-byte Reload
	fcmeq.4s	v23, v0, v0
	ldr	q0, [sp, #544]                  ; 16-byte Reload
	bsl.16b	v23, v0, v2
	ldr	q0, [sp, #416]                  ; 16-byte Reload
	fcmeq.4s	v22, v0, v0
	ldr	q0, [sp, #432]                  ; 16-byte Reload
	mov.16b	v26, v22
	bsl.16b	v26, v0, v2
	ldr	q0, [sp, #448]                  ; 16-byte Reload
	fcmeq.4s	v4, v0, v0
	ldr	q0, [sp, #464]                  ; 16-byte Reload
	mov.16b	v18, v4
	bsl.16b	v18, v0, v2
	ldr	q0, [sp, #1552]                 ; 16-byte Reload
	ldr	q1, [sp, #1968]                 ; 16-byte Reload
	and.16b	v25, v0, v1
	ldr	q1, [sp, #2000]                 ; 16-byte Reload
	and.16b	v6, v0, v1
	ldr	q1, [sp, #1936]                 ; 16-byte Reload
	and.16b	v22, v0, v1
	ldr	q1, [sp, #1984]                 ; 16-byte Reload
	and.16b	v1, v0, v1
	and.16b	v8, v0, v3
	ldr	q3, [sp, #1952]                 ; 16-byte Reload
	and.16b	v4, v0, v3
	and.16b	v3, v0, v7
	str	q3, [sp, #1984]                 ; 16-byte Spill
	ldr	q3, [sp, #1920]                 ; 16-byte Reload
	and.16b	v3, v0, v3
	and.16b	v5, v0, v5
	str	q5, [sp, #2000]                 ; 16-byte Spill
	and.16b	v5, v0, v16
	and.16b	v13, v0, v13
	and.16b	v11, v0, v11
	and.16b	v16, v0, v15
	and.16b	v14, v0, v14
	and.16b	v12, v0, v12
	and.16b	v10, v0, v10
	and.16b	v17, v0, v17
	and.16b	v15, v0, v19
	and.16b	v30, v0, v30
	and.16b	v31, v0, v31
	and.16b	v19, v0, v28
	and.16b	v9, v0, v9
	and.16b	v28, v0, v27
	and.16b	v27, v0, v20
	and.16b	v21, v0, v21
	and.16b	v29, v0, v29
	and.16b	v23, v0, v23
	and.16b	v24, v0, v24
	and.16b	v18, v0, v18
	and.16b	v26, v0, v26
	ldp	q0, q7, [sp, #352]              ; 32-byte Folded Reload
	fcmeq.4s	v0, v0, v0
	mov.16b	v20, v0
	bsl.16b	v20, v7, v2
	ldp	q0, q7, [sp, #384]              ; 32-byte Folded Reload
	fcmeq.4s	v0, v0, v0
	bsl.16b	v0, v7, v2
	ldr	q7, [sp, #2016]                 ; 16-byte Reload
	ldr	q2, [sp, #2032]                 ; 16-byte Reload
	stp	q2, q7, [x22, #512]
	str	q6, [sp, #1472]                 ; 16-byte Spill
	stp	q25, q6, [x22, #544]
	str	q25, [sp, #1968]                ; 16-byte Spill
	str	q1, [sp, #1840]                 ; 16-byte Spill
	stp	q22, q1, [x22, #576]
	str	q22, [sp, #1856]                ; 16-byte Spill
	str	q4, [sp, #1648]                 ; 16-byte Spill
	stp	q8, q4, [x22, #608]
	str	q8, [sp, #1952]                 ; 16-byte Spill
	str	q3, [sp, #1824]                 ; 16-byte Spill
	ldr	q1, [sp, #1984]                 ; 16-byte Reload
	stp	q1, q3, [x22, #640]
	str	q5, [sp, #1632]                 ; 16-byte Spill
	ldr	q1, [sp, #2000]                 ; 16-byte Reload
	stp	q1, q5, [x22, #672]
	str	q11, [sp, #1792]                ; 16-byte Spill
	stp	q13, q11, [x22, #704]
	str	q13, [sp, #1808]                ; 16-byte Spill
	str	q14, [sp, #1552]                ; 16-byte Spill
	stp	q16, q14, [x22, #736]
	str	q16, [sp, #1936]                ; 16-byte Spill
	str	q10, [sp, #1760]                ; 16-byte Spill
	stp	q12, q10, [x22, #768]
	str	q12, [sp, #1776]                ; 16-byte Spill
	str	q15, [sp, #1536]                ; 16-byte Spill
	stp	q17, q15, [x22, #800]
	str	q17, [sp, #1920]                ; 16-byte Spill
	str	q31, [sp, #1728]                ; 16-byte Spill
	stp	q30, q31, [x22, #832]
	str	q30, [sp, #1744]                ; 16-byte Spill
	str	q9, [sp, #1520]                 ; 16-byte Spill
	stp	q19, q9, [x22, #864]
	str	q19, [sp, #1904]                ; 16-byte Spill
	str	q27, [sp, #1696]                ; 16-byte Spill
	stp	q28, q27, [x22, #896]
	str	q28, [sp, #1712]                ; 16-byte Spill
	str	q29, [sp, #1504]                ; 16-byte Spill
	stp	q21, q29, [x22, #928]
	str	q21, [sp, #1888]                ; 16-byte Spill
	mov.16b	v21, v0
	str	q24, [sp, #1664]                ; 16-byte Spill
	stp	q23, q24, [x22, #960]
	str	q23, [sp, #1680]                ; 16-byte Spill
	str	q26, [sp, #1488]                ; 16-byte Spill
	stp	q18, q26, [x22, #992]
	str	q18, [sp, #1872]                ; 16-byte Spill
	ldr	x9, [sp, #264]                  ; 8-byte Reload
LBB0_63:                                ; %direct.true597
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_64 Depth 3
	mov	x10, #0                         ; =0x0
	lsl	x11, x8, #7
	add	x12, x26, x11
	ldp	q0, q1, [x12]
	fmul.4s	v1, v20, v1
	fmul.4s	v0, v21, v0
	mov	w12, #1                         ; =0x1
	bfi	x12, x8, #2, #61
	add	x13, x26, x12, lsl #5
	ldp	q2, q3, [x13]
	fmul.4s	v3, v20, v3
	fmul.4s	v2, v21, v2
	mov	w13, #2                         ; =0x2
	bfi	x13, x8, #2, #61
	add	x14, x26, x13, lsl #5
	ldp	q4, q5, [x14]
	fmul.4s	v7, v20, v5
	fmul.4s	v6, v21, v4
	orr	x14, x24, x8, lsl #2
	add	x15, x26, x14, lsl #5
	ldp	q4, q5, [x15]
	fmul.4s	v5, v20, v5
	fmul.4s	v4, v21, v4
	mov	x15, x9
LBB0_64:                                ; %direct.true625
                                        ;   Parent Loop BB0_17 Depth=1
                                        ;     Parent Loop BB0_63 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x16, x20, x10
	ldp	q17, q16, [x16]
	ldp	q19, q18, [x15, #-96]
	fmul.4s	v19, v17, v19
	fmul.4s	v18, v16, v18
	fadd.4s	v1, v1, v18
	fadd.4s	v0, v0, v19
	ldp	q19, q18, [x15, #-64]
	fmul.4s	v19, v17, v19
	fmul.4s	v18, v16, v18
	fadd.4s	v3, v3, v18
	fadd.4s	v2, v2, v19
	ldp	q19, q18, [x15, #-32]
	fmul.4s	v19, v17, v19
	fmul.4s	v18, v16, v18
	fadd.4s	v7, v7, v18
	fadd.4s	v6, v6, v19
	ldp	q19, q18, [x15]
	fmul.4s	v17, v17, v19
	fmul.4s	v16, v16, v18
	fadd.4s	v5, v5, v16
	fadd.4s	v4, v4, v17
	add	x10, x10, #32
	add	x15, x15, #1, lsl #12           ; =4096
	cmp	x10, #512
	b.ne	LBB0_64
; %bb.65:                               ; %direct.false626
                                        ;   in Loop: Header=BB0_63 Depth=2
	add	x10, x19, x11
	stp	q0, q1, [x10]
	add	x10, x19, x12, lsl #5
	stp	q2, q3, [x10]
	add	x10, x19, x13, lsl #5
	stp	q6, q7, [x10]
	add	x10, x19, x14, lsl #5
	add	x8, x8, #1
	add	x9, x9, #128
	stp	q4, q5, [x10]
	cmp	x8, #32
	b.ne	LBB0_63
; %bb.66:                               ; %direct.true692.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	add	x0, x21, #2, lsl #12            ; =8192
	mov	x1, x19
	mov	w2, #4096                       ; =0x1000
	str	q20, [sp, #1440]                ; 16-byte Spill
	str	q21, [sp, #1456]                ; 16-byte Spill
	bl	_memcpy
	add	x0, x21, #1, lsl #12            ; =4096
	mov	x1, x19
	mov	w2, #4096                       ; =0x1000
	bl	_memcpy
	ldr	q0, [sp, #1600]                 ; 16-byte Reload
	ldr	q1, [sp, #1440]                 ; 16-byte Reload
	fmul.4s	v0, v0, v1
	ldr	q1, [sp, #1616]                 ; 16-byte Reload
	ldr	q2, [sp, #1456]                 ; 16-byte Reload
	fmul.4s	v1, v1, v2
	movi.2d	v3, #0000000000000000
	ldr	q2, [sp, #2016]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q4, [sp, #1472]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2032]                 ; 16-byte Reload
	fadd.4s	v3, v4, v3
	ldr	q4, [sp, #1968]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1856]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1840]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1648]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1952]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1984]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1824]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1632]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2000]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1808]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1792]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1552]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1936]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1776]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1760]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1536]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1920]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1744]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1728]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1520]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1904]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1712]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1696]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1504]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1888]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1680]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1664]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1488]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1872]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	fadd.4s	v19, v1, v3
	fadd.4s	v20, v0, v2
	add	x27, x27, #1
	ldr	q1, [sp, #1584]                 ; 16-byte Reload
	ldr	q0, [sp, #1568]                 ; 16-byte Reload
	cmp	x27, #513
	ldr	x1, [sp, #344]                  ; 8-byte Reload
	ldp	q7, q6, [sp, #304]              ; 32-byte Folded Reload
	ldp	q17, q16, [sp, #272]            ; 32-byte Folded Reload
	ldr	q18, [sp, #240]                 ; 16-byte Reload
	b.ne	LBB0_17
	b	LBB0_71
LBB0_67:                                ; %direct.true727.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	b	LBB0_69
LBB0_68:                                ; %direct.schedule.44
                                        ;   in Loop: Header=BB0_69 Depth=2
	add	x9, x23, x8, lsl #5
	stp	q1, q0, [x9]
	add	x8, x8, #1
	cmp	x8, #2048
	b.eq	LBB0_54
LBB0_69:                                ; %direct.true727
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	cmp	x8, #127
	b.hi	LBB0_68
; %bb.70:                               ; %direct.true740
                                        ;   in Loop: Header=BB0_69 Depth=2
	add	x9, x8, #256, lsl #12           ; =1048576
	dup.2d	v0, x9
	add.2d	v1, v0, v17
	add.2d	v2, v0, v16
	add.2d	v3, v0, v7
	add.2d	v0, v0, v6
	shl.2d	v0, v0, #2
	shl.2d	v3, v3, #2
	shl.2d	v2, v2, #2
	shl.2d	v1, v1, #2
	dup.2d	v4, x25
	add.2d	v1, v4, v1
	add.2d	v2, v4, v2
	add.2d	v3, v4, v3
	add.2d	v0, v4, v0
	mov.d	x9, v0[1]
	fmov	x10, d0
	mov.d	x11, v3[1]
	fmov	x12, d3
	mov.d	x13, v2[1]
	fmov	x14, d2
	mov.d	x15, v1[1]
	ldr	s0, [x14]
	ld1.s	{ v0 }[1], [x13]
	fmov	x13, d1
	ld1.s	{ v0 }[2], [x13]
	ld1.s	{ v0 }[3], [x15]
	ldr	s1, [x10]
	ld1.s	{ v1 }[1], [x9]
	ld1.s	{ v1 }[2], [x12]
	ld1.s	{ v1 }[3], [x11]
	b	LBB0_68
LBB0_71:                                ; %direct.true777.preheader
	mov	x8, #0                          ; =0x0
	ldr	x11, [sp, #88]                  ; 8-byte Reload
	ldp	q16, q7, [sp, #48]              ; 32-byte Folded Reload
	ldp	q18, q17, [sp, #16]             ; 32-byte Folded Reload
LBB0_72:                                ; %direct.true777
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v0, x8
	add.2d	v1, v0, v7
	add.2d	v2, v0, v17
	add.2d	v3, v0, v16
	add.2d	v0, v0, v18
	add	x9, x26, x8, lsl #5
	ldp	q4, q5, [x9]
	fdiv.4s	v5, v5, v20
	fdiv.4s	v4, v4, v19
	shl.2d	v0, v0, #2
	shl.2d	v3, v3, #2
	shl.2d	v2, v2, #2
	shl.2d	v1, v1, #2
	dup.2d	v6, x11
	add.2d	v1, v6, v1
	add.2d	v0, v6, v0
	mov.d	x9, v0[1]
	fmov	x10, d0
	str	s4, [x10]
	st1.s	{ v4 }[1], [x9]
	add.2d	v0, v6, v3
	mov.d	x9, v0[1]
	fmov	x10, d0
	st1.s	{ v4 }[2], [x10]
	add.2d	v0, v6, v2
	st1.s	{ v4 }[3], [x9]
	mov.d	x9, v0[1]
	fmov	x10, d0
	str	s5, [x10]
	st1.s	{ v5 }[1], [x9]
	mov.d	x9, v1[1]
	fmov	x10, d1
	st1.s	{ v5 }[2], [x10]
	st1.s	{ v5 }[3], [x9]
	add	x8, x8, #1
	cmp	x8, #128
	b.ne	LBB0_72
; %bb.73:                               ; %common.ret
	add	sp, sp, #2048
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention.packet_batch.blocks
lCPI1_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI1_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI1_2:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI1_3:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI1_4:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI1_5:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI1_6:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_attention.packet_batch.blocks
	.p2align	2
_llm_attention.packet_batch.blocks:     ; @llm_attention.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #2720
	str	x0, [sp, #112]                  ; 8-byte Spill
	cbz	w3, LBB1_166
; %bb.1:                                ; %block.batch.loop.preheader
	mov	x19, x3
	mov	x20, x2
	mov	w9, #0                          ; =0x0
	ldp	w10, w8, [x2, #44]
	stp	w8, w10, [sp, #104]             ; 8-byte Folded Spill
	ldp	w13, w27, [x2, #4]
	ldr	w25, [x2]
Lloh4:
	adrp	x8, lCPI1_0@PAGE
Lloh5:
	ldr	q19, [x8, lCPI1_0@PAGEOFF]
Lloh6:
	adrp	x8, lCPI1_1@PAGE
Lloh7:
	ldr	q18, [x8, lCPI1_1@PAGEOFF]
Lloh8:
	adrp	x8, lCPI1_5@PAGE
Lloh9:
	ldr	q8, [x8, lCPI1_5@PAGEOFF]
	adrp	x26, lCPI1_6@PAGE
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	str	q0, [sp, #128]                  ; 16-byte Spill
	str	w3, [sp, #100]                  ; 4-byte Spill
	str	q19, [sp, #224]                 ; 16-byte Spill
	str	q18, [sp, #80]                  ; 16-byte Spill
	str	q8, [sp, #2112]                 ; 16-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	w19, [sp, #100]                 ; 4-byte Reload
LBB1_3:                                 ; %llm_attention.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	ldp	w10, w9, [sp, #104]             ; 8-byte Folded Reload
	cmp	w8, w9
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	ldp	w9, w11, [sp, #120]             ; 8-byte Folded Reload
	cinc	w9, w9, eq
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w13, wzr, w9, ne
	add	w27, w27, w8
	add	w9, w11, #1
	cmp	w9, w19
	b.eq	LBB1_166
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_15 Depth 2
                                        ;     Child Loop BB1_18 Depth 2
                                        ;     Child Loop BB1_21 Depth 2
                                        ;     Child Loop BB1_24 Depth 2
                                        ;     Child Loop BB1_27 Depth 2
                                        ;     Child Loop BB1_30 Depth 2
                                        ;     Child Loop BB1_33 Depth 2
                                        ;     Child Loop BB1_36 Depth 2
                                        ;     Child Loop BB1_38 Depth 2
                                        ;     Child Loop BB1_40 Depth 2
                                        ;       Child Loop BB1_62 Depth 3
                                        ;       Child Loop BB1_65 Depth 3
                                        ;       Child Loop BB1_68 Depth 3
                                        ;       Child Loop BB1_71 Depth 3
                                        ;       Child Loop BB1_74 Depth 3
                                        ;       Child Loop BB1_77 Depth 3
                                        ;       Child Loop BB1_80 Depth 3
                                        ;       Child Loop BB1_83 Depth 3
                                        ;       Child Loop BB1_86 Depth 3
                                        ;       Child Loop BB1_89 Depth 3
                                        ;       Child Loop BB1_92 Depth 3
                                        ;       Child Loop BB1_95 Depth 3
                                        ;       Child Loop BB1_98 Depth 3
                                        ;       Child Loop BB1_101 Depth 3
                                        ;       Child Loop BB1_104 Depth 3
                                        ;       Child Loop BB1_107 Depth 3
                                        ;       Child Loop BB1_43 Depth 3
                                        ;       Child Loop BB1_111 Depth 3
                                        ;       Child Loop BB1_130 Depth 3
                                        ;       Child Loop BB1_132 Depth 3
                                        ;       Child Loop BB1_134 Depth 3
                                        ;       Child Loop BB1_136 Depth 3
                                        ;       Child Loop BB1_138 Depth 3
                                        ;       Child Loop BB1_140 Depth 3
                                        ;         Child Loop BB1_141 Depth 4
                                        ;       Child Loop BB1_144 Depth 3
                                        ;       Child Loop BB1_146 Depth 3
                                        ;     Child Loop BB1_150 Depth 2
	stp	w13, w9, [sp, #120]             ; 8-byte Folded Spill
	ldr	w8, [x20, #12]
	ubfiz	x9, x25, #5, #32
	cmp	x9, x8
	csel	x10, x9, xzr, ls
	subs	x11, x8, x10
	cmp	x11, #32
	mov	w12, #32                        ; =0x20
	csel	x11, x11, x12, lo
	cmp	x8, x10
	stp	w25, w13, [x20]
	str	w27, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x9, x8, #2, hi
	csel	x21, x11, xzr, ls
	cmp	x21, #32
	b.lo	LBB1_6
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x21, [sp, #112]                 ; 8-byte Reload
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention.full_packet
	b	LBB1_3
LBB1_6:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x19, x21, #3
	cbz	x19, LBB1_11
; %bb.7:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	ldr	x0, [sp, #112]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_attention.full_packet
	cmp	x19, #1
	b.eq	LBB1_11
; %bb.8:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	ldr	x0, [sp, #112]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_attention.full_packet
	cmp	x19, #2
	b.eq	LBB1_11
; %bb.9:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	ldr	x0, [sp, #112]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_attention.full_packet
	cmp	x19, #3
	b.eq	LBB1_11
; %bb.10:                               ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	x22, [sp, #112]                 ; 8-byte Reload
	mov	x0, x22
	mov	x1, x20
	bl	_llm_attention.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x22
	mov	x1, x20
	bl	_llm_attention.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x22
	mov	x1, x20
	bl	_llm_attention.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x22
	mov	x1, x20
	bl	_llm_attention.full_packet
LBB1_11:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w8, w21, #0x7
	ldr	q19, [sp, #224]                 ; 16-byte Reload
	ldr	q18, [sp, #80]                  ; 16-byte Reload
	ldr	q8, [sp, #2112]                 ; 16-byte Reload
	cbz	w8, LBB1_2
; %bb.12:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w9, w19, #3
	dup.4s	v10, w8
	str	w9, [x20, #36]
	cmhi.4s	v0, v10, v18
	cmhi.4s	v2, v10, v19
	uzp1.8h	v25, v2, v0
	umaxv.8h	h1, v25
	fmov	w8, s1
	tbz	w8, #0, LBB1_2
; %bb.13:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x8, [x20, #136]
	ldr	x10, [sp, #112]                 ; 8-byte Reload
	ldr	x16, [x10]
	xtn.4h	v1, v2
	orr	w9, w9, w25, lsl #5
	dup.4s	v3, w9
	uzp1.8b	v4, v1, v0
	orr.16b	v1, v3, v19
	and.16b	v1, v2, v1
	ushll.2d	v6, v1, #7
	umov.b	w9, v4[0]
	tbz	w9, #0, LBB1_16
; %bb.14:                               ; %copy.active.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x10, #0                         ; =0x0
	fmov	x11, d6
	add	x11, x16, x11, lsl #2
	add	x12, x8, #64
LBB1_15:                                ; %copy.chunk.i.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q4, [x11, x10]
	stur	s4, [x12, #-64]
	mov	s5, v4[1]
	stur	s5, [x12, #-32]
	st1.s	{ v4 }[2], [x12]
	add	x13, x12, #32
	st1.s	{ v4 }[3], [x13]
	add	x10, x10, #16
	add	x12, x12, #128
	cmp	x10, #512
	b.ne	LBB1_15
LBB1_16:                                ; %copy.continue.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.s	w14, v10[1]
	cmp	w14, #1
	cset	w10, hi
	str	w10, [sp, #188]                 ; 4-byte Spill
	cmp	w14, #2
	b.lo	LBB1_19
; %bb.17:                               ; %copy.active133.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x10, #0                         ; =0x0
	mov.d	x11, v6[1]
	add	x11, x16, x11, lsl #2
	add	x12, x8, #68
LBB1_18:                                ; %copy.chunk.i340.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q4, [x11, x10]
	stur	s4, [x12, #-64]
	mov	s5, v4[1]
	stur	s5, [x12, #-32]
	st1.s	{ v4 }[2], [x12]
	add	x13, x12, #32
	st1.s	{ v4 }[3], [x13]
	add	x10, x10, #16
	add	x12, x12, #128
	cmp	x10, #512
	b.ne	LBB1_18
LBB1_19:                                ; %copy.continue134.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ushll2.2d	v7, v1, #7
	mov.s	w0, v10[2]
	cmp	w0, #2
	cset	w10, hi
	str	w10, [sp, #184]                 ; 4-byte Spill
	cmp	w0, #3
	b.lo	LBB1_22
; %bb.20:                               ; %copy.active135.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x10, #0                         ; =0x0
	fmov	x11, d7
	add	x11, x16, x11, lsl #2
	add	x12, x8, #72
LBB1_21:                                ; %copy.chunk.i346.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q4, [x11, x10]
	stur	s4, [x12, #-64]
	mov	s5, v4[1]
	stur	s5, [x12, #-32]
	st1.s	{ v4 }[2], [x12]
	add	x13, x12, #32
	st1.s	{ v4 }[3], [x13]
	add	x10, x10, #16
	add	x12, x12, #128
	cmp	x10, #512
	b.ne	LBB1_21
LBB1_22:                                ; %copy.continue136.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.s	w3, v10[3]
	cmp	w3, #3
	cset	w10, hi
	str	w10, [sp, #180]                 ; 4-byte Spill
	cmp	w3, #4
	b.lo	LBB1_25
; %bb.23:                               ; %copy.active137.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x10, #0                         ; =0x0
	mov.d	x11, v7[1]
	add	x11, x16, x11, lsl #2
	add	x13, x8, #76
LBB1_24:                                ; %copy.chunk.i352.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q4, [x11, x10]
	stur	s4, [x13, #-64]
	mov	s5, v4[1]
	stur	s5, [x13, #-32]
	st1.s	{ v4 }[2], [x13]
	add	x15, x13, #32
	st1.s	{ v4 }[3], [x15]
	add	x10, x10, #16
	add	x13, x13, #128
	cmp	x10, #512
	b.ne	LBB1_24
LBB1_25:                                ; %copy.continue138.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	orr.16b	v3, v3, v18
	and.16b	v3, v0, v3
	ushll.2d	v16, v3, #7
	fmov	w10, s10
	cmp	w10, #4
	cset	w13, hi
	cmp	w10, #5
	b.lo	LBB1_28
; %bb.26:                               ; %copy.active139.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x10, #0                         ; =0x0
	fmov	x11, d16
	add	x11, x16, x11, lsl #2
	add	x15, x8, #80
LBB1_27:                                ; %copy.chunk.i358.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q4, [x11, x10]
	stur	s4, [x15, #-64]
	mov	s5, v4[1]
	stur	s5, [x15, #-32]
	st1.s	{ v4 }[2], [x15]
	add	x17, x15, #32
	st1.s	{ v4 }[3], [x17]
	add	x10, x10, #16
	add	x15, x15, #128
	cmp	x10, #512
	b.ne	LBB1_27
LBB1_28:                                ; %copy.continue140.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	cmp	w14, #5
	cset	w15, hi
	cmp	w14, #6
	b.lo	LBB1_31
; %bb.29:                               ; %copy.active141.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x10, #0                         ; =0x0
	mov.d	x11, v16[1]
	add	x11, x16, x11, lsl #2
	add	x14, x8, #84
LBB1_30:                                ; %copy.chunk.i364.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q4, [x11, x10]
	stur	s4, [x14, #-64]
	mov	s5, v4[1]
	stur	s5, [x14, #-32]
	st1.s	{ v4 }[2], [x14]
	add	x17, x14, #32
	st1.s	{ v4 }[3], [x17]
	add	x10, x10, #16
	add	x14, x14, #128
	cmp	x10, #512
	b.ne	LBB1_30
LBB1_31:                                ; %copy.continue142.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ushll2.2d	v17, v3, #7
	cmp	w0, #6
	cset	w17, hi
	cmp	w0, #7
	b.lo	LBB1_34
; %bb.32:                               ; %copy.active143.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x10, #0                         ; =0x0
	fmov	x11, d17
	add	x11, x16, x11, lsl #2
	add	x14, x8, #88
LBB1_33:                                ; %copy.chunk.i370.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q4, [x11, x10]
	stur	s4, [x14, #-64]
	mov	s5, v4[1]
	stur	s5, [x14, #-32]
	st1.s	{ v4 }[2], [x14]
	add	x0, x14, #32
	st1.s	{ v4 }[3], [x0]
	add	x10, x10, #16
	add	x14, x14, #128
	cmp	x10, #512
	b.ne	LBB1_33
LBB1_34:                                ; %copy.continue144.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	stp	q7, q6, [sp, #48]               ; 32-byte Folded Spill
	ldr	x10, [sp, #112]                 ; 8-byte Reload
	ldr	x0, [x10, #16]
	ldr	x1, [x10, #32]
	ldr	x14, [x10, #48]
	cmp	w3, #7
	cset	w2, hi
	cmp	w3, #8
	b.lo	LBB1_37
; %bb.35:                               ; %copy.active145.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x10, #0                         ; =0x0
	mov.d	x11, v17[1]
	add	x11, x16, x11, lsl #2
	add	x16, x8, #92
LBB1_36:                                ; %copy.chunk.i376.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q4, [x11, x10]
	stur	s4, [x16, #-64]
	mov	s5, v4[1]
	stur	s5, [x16, #-32]
	st1.s	{ v4 }[2], [x16]
	add	x3, x16, #32
	st1.s	{ v4 }[3], [x3]
	add	x10, x10, #16
	add	x16, x16, #128
	cmp	x10, #512
	b.ne	LBB1_36
LBB1_37:                                ; %direct.true.i.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	stp	q17, q16, [sp, #16]             ; 32-byte Folded Spill
	mov	x19, #0                         ; =0x0
	add	x3, x8, #35, lsl #12            ; =143360
	add	x16, x8, #1, lsl #12            ; =4096
	add	x4, x8, #2, lsl #12             ; =8192
	add	x5, x8, #3, lsl #12             ; =12288
	dup.2d	v4, x5
	str	q4, [sp, #160]                  ; 16-byte Spill
	add	x6, x8, #19, lsl #12            ; =77824
	dup.2d	v4, x6
	str	q4, [sp, #1792]                 ; 16-byte Spill
	mov	w10, #12800                     ; =0x3200
	movk	w10, #2, lsl #16
	add	x7, x8, x10
	mov	w10, #13312                     ; =0x3400
	movk	w10, #2, lsl #16
	add	x30, x8, x10
	sshll.2d	v6, v2, #0
	ushll.2d	v7, v1, #0
	ushll.2d	v4, v3, #0
	ushll2.2d	v1, v1, #0
	ushll2.2d	v3, v3, #0
	ushr.2d	v5, v3, #2
	ushr.2d	v3, v1, #2
	ushr.2d	v4, v4, #2
	ushr.2d	v1, v7, #2
	and.16b	v6, v6, v8
	str	q6, [sp, #2608]                 ; 16-byte Spill
LBB1_38:                                ; %direct.true.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x16, x19
	ldp	q6, q7, [x10]
	cmhs.4s	v16, v18, v10
	and.16b	v7, v16, v7
	cmhs.4s	v16, v19, v10
	and.16b	v6, v16, v6
	stp	q6, q7, [x10]
	add	x19, x19, #32
	cmp	x19, #1, lsl #12                ; =4096
	b.ne	LBB1_38
; %bb.39:                               ; %direct.false.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x19, #0                         ; =0x0
	fmov	x10, d5
	add	x10, x10, x10, lsl #13
	fmov	d6, x10
	mov.d	x10, v5[1]
	add	x10, x10, x10, lsl #13
	mov.d	v6[1], x10
	fmov	x10, d4
	add	x10, x10, x10, lsl #13
	fmov	d5, x10
	mov.d	x10, v4[1]
	add	x10, x10, x10, lsl #13
	mov.d	v5[1], x10
	fmov	x10, d3
	add	x10, x10, x10, lsl #13
	mov.d	x11, v3[1]
	fmov	d3, x10
	add	x10, x11, x11, lsl #13
	mov.d	v3[1], x10
	fmov	x10, d1
	add	x10, x10, x10, lsl #13
	fmov	d4, x10
	mov.d	x10, v1[1]
	add	x10, x10, x10, lsl #13
	mov.d	v4[1], x10
	sshll2.2d	v18, v0, #0
	sshll.2d	v1, v0, #0
	sshll2.2d	v20, v2, #0
	sshll.2d	v7, v2, #0
	mov	w10, #62154                     ; =0xf2ca
	movk	w10, #61769, lsl #16
	dup.4s	v16, w10
	and.16b	v17, v0, v16
	str	q17, [sp, #2176]                ; 16-byte Spill
	str	q16, [sp, #144]                 ; 16-byte Spill
	and.16b	v16, v2, v16
	str	q16, [sp, #2160]                ; 16-byte Spill
	and.16b	v9, v7, v4
	str	q20, [sp, #2592]                ; 16-byte Spill
	and.16b	v3, v20, v3
	str	q3, [sp, #2560]                 ; 16-byte Spill
	and.16b	v1, v1, v5
	str	q1, [sp, #2544]                 ; 16-byte Spill
	str	q18, [sp, #2624]                ; 16-byte Spill
	and.16b	v1, v18, v6
	str	q1, [sp, #2528]                 ; 16-byte Spill
	movi.2d	v1, #0000000000000000
	str	q1, [sp, #1648]                 ; 16-byte Spill
	str	q1, [sp, #2512]                 ; 16-byte Spill
	str	q1, [sp, #2496]                 ; 16-byte Spill
	str	q1, [sp, #2480]                 ; 16-byte Spill
	str	q1, [sp, #2464]                 ; 16-byte Spill
	str	q1, [sp, #2448]                 ; 16-byte Spill
	str	q1, [sp, #2432]                 ; 16-byte Spill
	str	q1, [sp, #2416]                 ; 16-byte Spill
	str	q1, [sp, #2400]                 ; 16-byte Spill
	movi.2d	v15, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v3, #0000000000000000
	str	q3, [sp, #2576]                 ; 16-byte Spill
	str	q3, [sp, #1632]                 ; 16-byte Spill
	str	q3, [sp, #1616]                 ; 16-byte Spill
	str	q3, [sp, #1600]                 ; 16-byte Spill
	str	q3, [sp, #1584]                 ; 16-byte Spill
	str	q3, [sp, #1568]                 ; 16-byte Spill
	str	q3, [sp, #1552]                 ; 16-byte Spill
	str	q3, [sp, #1536]                 ; 16-byte Spill
	str	q3, [sp, #1520]                 ; 16-byte Spill
	str	q3, [sp, #1504]                 ; 16-byte Spill
	str	q3, [sp, #1488]                 ; 16-byte Spill
	movi.2d	v11, #0000000000000000
	str	q3, [sp, #1472]                 ; 16-byte Spill
	movi.2d	v13, #0000000000000000
	str	q3, [sp, #2096]                 ; 16-byte Spill
	str	q3, [sp, #2080]                 ; 16-byte Spill
	str	q3, [sp, #2064]                 ; 16-byte Spill
	str	q3, [sp, #2688]                 ; 16-byte Spill
	str	q3, [sp, #2672]                 ; 16-byte Spill
	str	q3, [sp, #2656]                 ; 16-byte Spill
	str	q3, [sp, #2640]                 ; 16-byte Spill
	str	q3, [sp, #2048]                 ; 16-byte Spill
	movi.2d	v26, #0000000000000000
	str	q3, [sp, #2032]                 ; 16-byte Spill
	str	q3, [sp, #2016]                 ; 16-byte Spill
	movi.2d	v14, #0000000000000000
	str	q3, [sp, #2000]                 ; 16-byte Spill
	str	q3, [sp, #1984]                 ; 16-byte Spill
	str	q3, [sp, #1968]                 ; 16-byte Spill
	str	q3, [sp, #1952]                 ; 16-byte Spill
	str	q3, [sp, #1936]                 ; 16-byte Spill
	str	q3, [sp, #1920]                 ; 16-byte Spill
	str	q3, [sp, #1904]                 ; 16-byte Spill
	movi.2d	v27, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v12, #0000000000000000
	str	q3, [sp, #1456]                 ; 16-byte Spill
	str	q3, [sp, #1440]                 ; 16-byte Spill
	str	q3, [sp, #1424]                 ; 16-byte Spill
	str	q3, [sp, #1776]                 ; 16-byte Spill
	str	q3, [sp, #1408]                 ; 16-byte Spill
	str	q3, [sp, #1760]                 ; 16-byte Spill
	str	q3, [sp, #1392]                 ; 16-byte Spill
	str	q3, [sp, #1744]                 ; 16-byte Spill
	str	q3, [sp, #1728]                 ; 16-byte Spill
	str	q3, [sp, #1712]                 ; 16-byte Spill
	movi.2d	v23, #0000000000000000
	str	q3, [sp, #1696]                 ; 16-byte Spill
	str	q3, [sp, #1680]                 ; 16-byte Spill
	str	q3, [sp, #1664]                 ; 16-byte Spill
	movi.2d	v20, #0000000000000000
	movi.2d	v24, #0000000000000000
	stp	q25, q10, [sp, #192]            ; 32-byte Folded Spill
	str	q9, [sp, #2288]                 ; 16-byte Spill
LBB1_40:                                ; %direct.true152.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB1_62 Depth 3
                                        ;       Child Loop BB1_65 Depth 3
                                        ;       Child Loop BB1_68 Depth 3
                                        ;       Child Loop BB1_71 Depth 3
                                        ;       Child Loop BB1_74 Depth 3
                                        ;       Child Loop BB1_77 Depth 3
                                        ;       Child Loop BB1_80 Depth 3
                                        ;       Child Loop BB1_83 Depth 3
                                        ;       Child Loop BB1_86 Depth 3
                                        ;       Child Loop BB1_89 Depth 3
                                        ;       Child Loop BB1_92 Depth 3
                                        ;       Child Loop BB1_95 Depth 3
                                        ;       Child Loop BB1_98 Depth 3
                                        ;       Child Loop BB1_101 Depth 3
                                        ;       Child Loop BB1_104 Depth 3
                                        ;       Child Loop BB1_107 Depth 3
                                        ;       Child Loop BB1_43 Depth 3
                                        ;       Child Loop BB1_111 Depth 3
                                        ;       Child Loop BB1_130 Depth 3
                                        ;       Child Loop BB1_132 Depth 3
                                        ;       Child Loop BB1_134 Depth 3
                                        ;       Child Loop BB1_136 Depth 3
                                        ;       Child Loop BB1_138 Depth 3
                                        ;       Child Loop BB1_140 Depth 3
                                        ;         Child Loop BB1_141 Depth 4
                                        ;       Child Loop BB1_144 Depth 3
                                        ;       Child Loop BB1_146 Depth 3
	str	q26, [sp, #2208]                ; 16-byte Spill
	sshll.2d	v3, v2, #0
	sshll.2d	v17, v0, #0
	ldr	q18, [sp, #160]                 ; 16-byte Reload
	ldr	q19, [sp, #1712]                ; 16-byte Reload
	ldr	q8, [sp, #2624]                 ; 16-byte Reload
	bit.16b	v19, v18, v8
	str	q19, [sp, #1712]                ; 16-byte Spill
	ldr	q19, [sp, #1744]                ; 16-byte Reload
	ldr	q26, [sp, #2592]                ; 16-byte Reload
	bit.16b	v19, v18, v26
	str	q19, [sp, #1744]                ; 16-byte Spill
	ldr	q19, [sp, #1728]                ; 16-byte Reload
	bit.16b	v19, v18, v17
	str	q19, [sp, #1728]                ; 16-byte Spill
	ldr	q31, [sp, #1392]                ; 16-byte Reload
	bit.16b	v31, v18, v3
Lloh10:
	adrp	x10, lCPI1_2@PAGE
Lloh11:
	ldr	q19, [x10, lCPI1_2@PAGEOFF]
	ldr	q18, [sp, #1664]                ; 16-byte Reload
	str	q19, [sp, #2384]                ; 16-byte Spill
	bit.16b	v18, v19, v8
	str	q18, [sp, #1664]                ; 16-byte Spill
Lloh12:
	adrp	x10, lCPI1_3@PAGE
Lloh13:
	ldr	q10, [x10, lCPI1_3@PAGEOFF]
	ldr	q18, [sp, #1696]                ; 16-byte Reload
	bit.16b	v18, v10, v26
	str	q18, [sp, #1696]                ; 16-byte Spill
Lloh14:
	adrp	x10, lCPI1_4@PAGE
Lloh15:
	ldr	q19, [x10, lCPI1_4@PAGEOFF]
	ldr	q18, [sp, #1680]                ; 16-byte Reload
	str	q19, [sp, #1840]                ; 16-byte Spill
	bit.16b	v18, v19, v17
	str	q18, [sp, #1680]                ; 16-byte Spill
	ldr	q17, [sp, #2112]                ; 16-byte Reload
	bit.16b	v23, v17, v3
	cmp	x19, #512
	str	q23, [sp, #2128]                ; 16-byte Spill
	str	q20, [sp, #1376]                ; 16-byte Spill
	str	q24, [sp, #1360]                ; 16-byte Spill
	str	q31, [sp, #1392]                ; 16-byte Spill
	str	q10, [sp, #1264]                ; 16-byte Spill
	str	q11, [sp, #2144]                ; 16-byte Spill
	b.ne	LBB1_60
; %bb.41:                               ; %direct.true752.i.i.preheader
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x21, #0                         ; =0x0
	b	LBB1_43
LBB1_42:                                ; %direct.schedule.49.i.i
                                        ;   in Loop: Header=BB1_43 Depth=3
	str	q24, [sp, #2464]                ; 16-byte Spill
	str	q23, [sp, #2480]                ; 16-byte Spill
	str	q18, [sp, #2496]                ; 16-byte Spill
	str	q17, [sp, #2512]                ; 16-byte Spill
	add	x10, x5, x21, lsl #5
	ldp	q3, q17, [x10]
	bit.16b	v17, v8, v0
	bit.16b	v3, v31, v2
	stp	q3, q17, [x10]
	add	x21, x21, #1
	cmp	x21, #2048
	b.eq	LBB1_109
LBB1_43:                                ; %direct.true752.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	sshll.2d	v3, v2, #0
	sshll.2d	v17, v0, #0
	and	x10, x21, #0x7f
	lsr	x11, x21, #7
	orr	x12, x11, #0x2000
	dup.2d	v18, x12
	add.2d	v19, v18, v9
	ldr	q20, [sp, #2560]                ; 16-byte Reload
	add.2d	v20, v18, v20
	ldr	q23, [sp, #2544]                ; 16-byte Reload
	add.2d	v23, v18, v23
	ldr	q24, [sp, #2528]                ; 16-byte Reload
	add.2d	v18, v18, v24
	shl.2d	v18, v18, #7
	shl.2d	v23, v23, #7
	shl.2d	v20, v20, #7
	shl.2d	v19, v19, #7
	dup.2d	v24, x10
	orr.16b	v19, v19, v24
	orr.16b	v20, v20, v24
	orr.16b	v23, v23, v24
	orr.16b	v18, v18, v24
	ldr	q24, [sp, #2464]                ; 16-byte Reload
	ldr	q31, [sp, #2624]                ; 16-byte Reload
	bit.16b	v24, v18, v31
	ldr	q18, [sp, #2480]                ; 16-byte Reload
	bif.16b	v23, v18, v17
	ldr	q18, [sp, #2496]                ; 16-byte Reload
	ldr	q17, [sp, #2592]                ; 16-byte Reload
	bit.16b	v18, v20, v17
	ldr	q17, [sp, #2512]                ; 16-byte Reload
	bit.16b	v17, v19, v3
	movi.2d	v31, #0000000000000000
	movi.2d	v8, #0000000000000000
	cbnz	x11, LBB1_42
; %bb.44:                               ; %direct.true765.i.i
                                        ;   in Loop: Header=BB1_43 Depth=3
	ldr	q3, [x26, lCPI1_6@PAGEOFF]
	and.16b	v3, v25, v3
	addv.8h	h3, v3
	fmov	w10, s3
	shl.2d	v3, v17, #2
	dup.2d	v9, x0
	add.2d	v3, v9, v3
	tbz	w10, #0, LBB1_52
; %bb.45:                               ; %cond.load475
                                        ;   in Loop: Header=BB1_43 Depth=3
	fmov	x11, d3
	ldr	s31, [x11]
	and	w23, w10, #0xff
	tbnz	w23, #1, LBB1_53
LBB1_46:                                ; %else485
                                        ;   in Loop: Header=BB1_43 Depth=3
	shl.2d	v3, v18, #2
	add.2d	v3, v9, v3
	tbz	w23, #2, LBB1_54
LBB1_47:                                ; %cond.load487
                                        ;   in Loop: Header=BB1_43 Depth=3
	fmov	x10, d3
	ld1.s	{ v31 }[2], [x10]
	tbnz	w23, #3, LBB1_55
LBB1_48:                                ; %else497
                                        ;   in Loop: Header=BB1_43 Depth=3
	shl.2d	v3, v23, #2
	add.2d	v3, v9, v3
	tbz	w23, #4, LBB1_56
LBB1_49:                                ; %cond.load499
                                        ;   in Loop: Header=BB1_43 Depth=3
	fmov	x10, d3
	ld1.s	{ v8 }[0], [x10]
	tbnz	w23, #5, LBB1_57
LBB1_50:                                ; %else509
                                        ;   in Loop: Header=BB1_43 Depth=3
	shl.2d	v3, v24, #2
	add.2d	v3, v9, v3
	tbz	w23, #6, LBB1_58
LBB1_51:                                ; %cond.load511
                                        ;   in Loop: Header=BB1_43 Depth=3
	fmov	x10, d3
	ld1.s	{ v8 }[2], [x10]
	ldr	q9, [sp, #2288]                 ; 16-byte Reload
	tbz	w23, #7, LBB1_42
	b	LBB1_59
LBB1_52:                                ; %else479
                                        ;   in Loop: Header=BB1_43 Depth=3
	and	w23, w10, #0xff
	tbz	w23, #1, LBB1_46
LBB1_53:                                ; %cond.load481
                                        ;   in Loop: Header=BB1_43 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v31 }[1], [x10]
	shl.2d	v3, v18, #2
	add.2d	v3, v9, v3
	tbnz	w23, #2, LBB1_47
LBB1_54:                                ; %else491
                                        ;   in Loop: Header=BB1_43 Depth=3
	tbz	w23, #3, LBB1_48
LBB1_55:                                ; %cond.load493
                                        ;   in Loop: Header=BB1_43 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v31 }[3], [x10]
	shl.2d	v3, v23, #2
	add.2d	v3, v9, v3
	tbnz	w23, #4, LBB1_49
LBB1_56:                                ; %else503
                                        ;   in Loop: Header=BB1_43 Depth=3
	tbz	w23, #5, LBB1_50
LBB1_57:                                ; %cond.load505
                                        ;   in Loop: Header=BB1_43 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v8 }[1], [x10]
	shl.2d	v3, v24, #2
	add.2d	v3, v9, v3
	tbnz	w23, #6, LBB1_51
LBB1_58:                                ; %else515
                                        ;   in Loop: Header=BB1_43 Depth=3
	ldr	q9, [sp, #2288]                 ; 16-byte Reload
	tbz	w23, #7, LBB1_42
LBB1_59:                                ; %cond.load517
                                        ;   in Loop: Header=BB1_43 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v8 }[3], [x10]
	b	LBB1_42
LBB1_60:                                ; %direct.true155.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	lsl	x10, x19, #4
	dup.2d	v8, x10
	add.2d	v3, v8, v9
	shl.2d	v18, v3, #7
	mov.16b	v26, v12
	tbz	w9, #0, LBB1_63
; %bb.61:                               ; %copy.active164.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x21, #0                         ; =0x0
	fmov	x11, d31
	fmov	x22, d23
	fmov	x10, d18
	add	x10, x0, x10, lsl #2
	add	x11, x11, x22
	add	x11, x11, #64
LBB1_62:                                ; %copy.chunk.i382.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x10, x21]
	stur	s3, [x11, #-64]
	mov	s17, v3[1]
	stur	s17, [x11, #-32]
	st1.s	{ v3 }[2], [x11]
	add	x22, x11, #32
	st1.s	{ v3 }[3], [x22]
	add	x21, x21, #16
	add	x11, x11, #128
	cmp	x21, #2, lsl #12                ; =8192
	b.ne	LBB1_62
LBB1_63:                                ; %copy.continue165.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov.16b	v12, v18
	mov.d	x24, v18[1]
	ldr	w10, [sp, #188]                 ; 4-byte Reload
	ldr	q18, [sp, #1648]                ; 16-byte Reload
	ldr	q19, [sp, #1920]                ; 16-byte Reload
	ldr	q9, [sp, #1904]                 ; 16-byte Reload
	ldr	q23, [sp, #1456]                ; 16-byte Reload
	ldr	q25, [sp, #1440]                ; 16-byte Reload
	cbz	w10, LBB1_66
; %bb.64:                               ; %copy.active166.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x10, #0                         ; =0x0
	mov.d	x11, v31[1]
	ldr	q3, [sp, #2128]                 ; 16-byte Reload
	mov.d	x22, v3[1]
	add	x21, x0, x24, lsl #2
	add	x11, x11, x22
	add	x11, x11, #64
LBB1_65:                                ; %copy.chunk.i387.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x21, x10]
	stur	s3, [x11, #-64]
	mov	s17, v3[1]
	stur	s17, [x11, #-32]
	st1.s	{ v3 }[2], [x11]
	add	x22, x11, #32
	st1.s	{ v3 }[3], [x22]
	add	x10, x10, #16
	add	x11, x11, #128
	cmp	x10, #2, lsl #12                ; =8192
	b.ne	LBB1_65
LBB1_66:                                ; %copy.continue167.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2560]                 ; 16-byte Reload
	add.2d	v3, v8, v3
	shl.2d	v31, v3, #7
	ldr	w10, [sp, #184]                 ; 4-byte Reload
	cbz	w10, LBB1_69
; %bb.67:                               ; %copy.active168.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x21, #0                         ; =0x0
	ldr	q3, [sp, #1744]                 ; 16-byte Reload
	fmov	x11, d3
	ldr	q3, [sp, #1696]                 ; 16-byte Reload
	fmov	x22, d3
	fmov	x10, d31
	add	x10, x0, x10, lsl #2
	add	x11, x11, x22
	add	x11, x11, #64
LBB1_68:                                ; %copy.chunk.i393.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x10, x21]
	stur	s3, [x11, #-64]
	mov	s17, v3[1]
	stur	s17, [x11, #-32]
	st1.s	{ v3 }[2], [x11]
	add	x22, x11, #32
	st1.s	{ v3 }[3], [x22]
	add	x21, x21, #16
	add	x11, x11, #128
	cmp	x21, #2, lsl #12                ; =8192
	b.ne	LBB1_68
LBB1_69:                                ; %copy.continue169.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov.d	x21, v31[1]
	ldr	w10, [sp, #180]                 ; 4-byte Reload
	cbz	w10, LBB1_72
; %bb.70:                               ; %copy.active170.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x10, #0                         ; =0x0
	ldr	q3, [sp, #1744]                 ; 16-byte Reload
	mov.d	x11, v3[1]
	ldr	q3, [sp, #1696]                 ; 16-byte Reload
	mov.d	x22, v3[1]
	add	x23, x0, x21, lsl #2
	add	x11, x11, x22
	add	x11, x11, #64
LBB1_71:                                ; %copy.chunk.i399.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x23, x10]
	stur	s3, [x11, #-64]
	mov	s17, v3[1]
	stur	s17, [x11, #-32]
	st1.s	{ v3 }[2], [x11]
	add	x22, x11, #32
	st1.s	{ v3 }[3], [x22]
	add	x10, x10, #16
	add	x11, x11, #128
	cmp	x10, #2, lsl #12                ; =8192
	b.ne	LBB1_71
LBB1_72:                                ; %copy.continue171.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2544]                 ; 16-byte Reload
	add.2d	v3, v8, v3
	shl.2d	v3, v3, #7
	str	q3, [sp, #2368]                 ; 16-byte Spill
	cbz	w13, LBB1_75
; %bb.73:                               ; %copy.active172.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x23, #0                         ; =0x0
	ldr	q3, [sp, #1728]                 ; 16-byte Reload
	fmov	x11, d3
	ldr	q3, [sp, #1680]                 ; 16-byte Reload
	fmov	x22, d3
	ldr	q3, [sp, #2368]                 ; 16-byte Reload
	fmov	x10, d3
	add	x10, x0, x10, lsl #2
	add	x11, x11, x22
	add	x11, x11, #64
LBB1_74:                                ; %copy.chunk.i405.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x10, x23]
	stur	s3, [x11, #-64]
	mov	s17, v3[1]
	stur	s17, [x11, #-32]
	st1.s	{ v3 }[2], [x11]
	add	x22, x11, #32
	st1.s	{ v3 }[3], [x22]
	add	x23, x23, #16
	add	x11, x11, #128
	cmp	x23, #2, lsl #12                ; =8192
	b.ne	LBB1_74
LBB1_75:                                ; %copy.continue173.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2368]                 ; 16-byte Reload
	mov.d	x28, v3[1]
	cbz	w15, LBB1_78
; %bb.76:                               ; %copy.active174.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x10, #0                         ; =0x0
	ldr	q3, [sp, #1728]                 ; 16-byte Reload
	mov.d	x11, v3[1]
	ldr	q3, [sp, #1680]                 ; 16-byte Reload
	mov.d	x22, v3[1]
	add	x23, x0, x28, lsl #2
	add	x11, x11, x22
	add	x11, x11, #64
LBB1_77:                                ; %copy.chunk.i411.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x23, x10]
	stur	s3, [x11, #-64]
	mov	s17, v3[1]
	stur	s17, [x11, #-32]
	st1.s	{ v3 }[2], [x11]
	add	x22, x11, #32
	st1.s	{ v3 }[3], [x22]
	add	x10, x10, #16
	add	x11, x11, #128
	cmp	x10, #2, lsl #12                ; =8192
	b.ne	LBB1_77
LBB1_78:                                ; %copy.continue175.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2528]                 ; 16-byte Reload
	add.2d	v3, v8, v3
	shl.2d	v8, v3, #7
	cbz	w17, LBB1_81
; %bb.79:                               ; %copy.active176.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x23, #0                         ; =0x0
	ldr	q3, [sp, #1712]                 ; 16-byte Reload
	fmov	x11, d3
	ldr	q3, [sp, #1664]                 ; 16-byte Reload
	fmov	x22, d3
	fmov	x10, d8
	add	x10, x0, x10, lsl #2
	add	x11, x11, x22
	add	x11, x11, #64
LBB1_80:                                ; %copy.chunk.i417.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x10, x23]
	stur	s3, [x11, #-64]
	mov	s17, v3[1]
	stur	s17, [x11, #-32]
	st1.s	{ v3 }[2], [x11]
	add	x22, x11, #32
	st1.s	{ v3 }[3], [x22]
	add	x23, x23, #16
	add	x11, x11, #128
	cmp	x23, #2, lsl #12                ; =8192
	b.ne	LBB1_80
LBB1_81:                                ; %copy.continue177.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	str	q8, [sp, #2352]                 ; 16-byte Spill
	mov.d	x23, v8[1]
	ldr	q8, [sp, #1424]                 ; 16-byte Reload
	cbz	w2, LBB1_84
; %bb.82:                               ; %copy.active178.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x10, #0                         ; =0x0
	ldr	q3, [sp, #1712]                 ; 16-byte Reload
	mov.d	x22, v3[1]
	ldr	q3, [sp, #1664]                 ; 16-byte Reload
	mov.d	x12, v3[1]
	add	x11, x0, x23, lsl #2
	add	x12, x22, x12
	add	x22, x12, #64
LBB1_83:                                ; %copy.chunk.i423.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x11, x10]
	stur	s3, [x22, #-64]
	mov	s17, v3[1]
	stur	s17, [x22, #-32]
	st1.s	{ v3 }[2], [x22]
	add	x12, x22, #32
	st1.s	{ v3 }[3], [x12]
	add	x10, x10, #16
	add	x22, x22, #128
	cmp	x10, #2, lsl #12                ; =8192
	b.ne	LBB1_83
LBB1_84:                                ; %direct.schedule.7.thread.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	sshll.2d	v3, v2, #0
	ldr	q17, [sp, #1792]                ; 16-byte Reload
	bit.16b	v18, v17, v3
	ldr	q17, [sp, #2112]                ; 16-byte Reload
	bit.16b	v8, v17, v3
	tbz	w9, #0, LBB1_87
; %bb.85:                               ; %copy.active191.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x10, #0                         ; =0x0
	fmov	x12, d18
	fmov	x22, d8
	fmov	x11, d12
	add	x11, x1, x11, lsl #2
	add	x12, x12, x22
	add	x22, x12, #64
LBB1_86:                                ; %copy.chunk.i429.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x11, x10]
	stur	s3, [x22, #-64]
	mov	s17, v3[1]
	stur	s17, [x22, #-32]
	st1.s	{ v3 }[2], [x22]
	add	x12, x22, #32
	st1.s	{ v3 }[3], [x12]
	add	x10, x10, #16
	add	x22, x22, #128
	cmp	x10, #2, lsl #12                ; =8192
	b.ne	LBB1_86
LBB1_87:                                ; %copy.continue192.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	w10, [sp, #188]                 ; 4-byte Reload
	cbz	w10, LBB1_90
; %bb.88:                               ; %copy.active193.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x10, #0                         ; =0x0
	mov.d	x12, v18[1]
	mov.d	x22, v8[1]
	add	x11, x1, x24, lsl #2
	add	x12, x12, x22
	add	x22, x12, #64
LBB1_89:                                ; %copy.chunk.i434.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x11, x10]
	stur	s3, [x22, #-64]
	mov	s17, v3[1]
	stur	s17, [x22, #-32]
	st1.s	{ v3 }[2], [x22]
	add	x12, x22, #32
	st1.s	{ v3 }[3], [x12]
	add	x10, x10, #16
	add	x22, x22, #128
	cmp	x10, #2, lsl #12                ; =8192
	b.ne	LBB1_89
LBB1_90:                                ; %copy.continue194.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1792]                 ; 16-byte Reload
	ldr	q17, [sp, #2592]                ; 16-byte Reload
	bit.16b	v26, v3, v17
	ldr	q3, [sp, #1776]                 ; 16-byte Reload
	bit.16b	v3, v10, v17
	str	q3, [sp, #1776]                 ; 16-byte Spill
	ldr	w10, [sp, #184]                 ; 4-byte Reload
	cbz	w10, LBB1_93
; %bb.91:                               ; %copy.active195.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x10, #0                         ; =0x0
	fmov	x12, d26
	ldr	q3, [sp, #1776]                 ; 16-byte Reload
	fmov	x22, d3
	fmov	x11, d31
	add	x11, x1, x11, lsl #2
	add	x12, x12, x22
	add	x22, x12, #64
LBB1_92:                                ; %copy.chunk.i440.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x11, x10]
	stur	s3, [x22, #-64]
	mov	s17, v3[1]
	stur	s17, [x22, #-32]
	st1.s	{ v3 }[2], [x22]
	add	x12, x22, #32
	st1.s	{ v3 }[3], [x12]
	add	x10, x10, #16
	add	x22, x22, #128
	cmp	x10, #2, lsl #12                ; =8192
	b.ne	LBB1_92
LBB1_93:                                ; %copy.continue196.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	w10, [sp, #180]                 ; 4-byte Reload
	cbz	w10, LBB1_96
; %bb.94:                               ; %copy.active197.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x10, #0                         ; =0x0
	mov.d	x12, v26[1]
	ldr	q3, [sp, #1776]                 ; 16-byte Reload
	mov.d	x22, v3[1]
	add	x11, x1, x21, lsl #2
	add	x12, x12, x22
	add	x21, x12, #64
LBB1_95:                                ; %copy.chunk.i446.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x11, x10]
	stur	s3, [x21, #-64]
	mov	s17, v3[1]
	stur	s17, [x21, #-32]
	st1.s	{ v3 }[2], [x21]
	add	x12, x21, #32
	st1.s	{ v3 }[3], [x12]
	add	x10, x10, #16
	add	x21, x21, #128
	cmp	x10, #2, lsl #12                ; =8192
	b.ne	LBB1_95
LBB1_96:                                ; %copy.continue198.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	sshll.2d	v3, v0, #0
	ldr	q17, [sp, #1792]                ; 16-byte Reload
	bit.16b	v23, v17, v3
	ldr	q31, [sp, #1408]                ; 16-byte Reload
	ldr	q17, [sp, #1840]                ; 16-byte Reload
	bit.16b	v31, v17, v3
	cbz	w13, LBB1_99
; %bb.97:                               ; %copy.active199.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x10, #0                         ; =0x0
	fmov	x12, d23
	fmov	x21, d31
	ldr	q3, [sp, #2368]                 ; 16-byte Reload
	fmov	x11, d3
	add	x11, x1, x11, lsl #2
	add	x12, x12, x21
	add	x21, x12, #64
LBB1_98:                                ; %copy.chunk.i452.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x11, x10]
	stur	s3, [x21, #-64]
	mov	s17, v3[1]
	stur	s17, [x21, #-32]
	st1.s	{ v3 }[2], [x21]
	add	x12, x21, #32
	st1.s	{ v3 }[3], [x12]
	add	x10, x10, #16
	add	x21, x21, #128
	cmp	x10, #2, lsl #12                ; =8192
	b.ne	LBB1_98
LBB1_99:                                ; %copy.continue200.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov.16b	v12, v26
	cbz	w15, LBB1_102
; %bb.100:                              ; %copy.active201.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x10, #0                         ; =0x0
	mov.d	x12, v23[1]
	mov.d	x21, v31[1]
	add	x11, x1, x28, lsl #2
	add	x12, x12, x21
	add	x21, x12, #64
LBB1_101:                               ; %copy.chunk.i458.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x11, x10]
	stur	s3, [x21, #-64]
	mov	s17, v3[1]
	stur	s17, [x21, #-32]
	st1.s	{ v3 }[2], [x21]
	add	x12, x21, #32
	st1.s	{ v3 }[3], [x12]
	add	x10, x10, #16
	add	x21, x21, #128
	cmp	x10, #2, lsl #12                ; =8192
	b.ne	LBB1_101
LBB1_102:                               ; %copy.continue202.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q17, [sp, #2624]                ; 16-byte Reload
	ldr	q3, [sp, #1792]                 ; 16-byte Reload
	bit.16b	v25, v3, v17
	ldr	q3, [sp, #1760]                 ; 16-byte Reload
	ldr	q26, [sp, #2384]                ; 16-byte Reload
	bit.16b	v3, v26, v17
	str	q3, [sp, #1760]                 ; 16-byte Spill
	cbz	w17, LBB1_105
; %bb.103:                              ; %copy.active203.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x10, #0                         ; =0x0
	fmov	x12, d25
	ldr	q3, [sp, #1760]                 ; 16-byte Reload
	fmov	x21, d3
	ldr	q3, [sp, #2352]                 ; 16-byte Reload
	fmov	x11, d3
	add	x11, x1, x11, lsl #2
	add	x12, x12, x21
	add	x21, x12, #64
LBB1_104:                               ; %copy.chunk.i464.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x11, x10]
	stur	s3, [x21, #-64]
	mov	s17, v3[1]
	stur	s17, [x21, #-32]
	st1.s	{ v3 }[2], [x21]
	add	x12, x21, #32
	st1.s	{ v3 }[3], [x12]
	add	x10, x10, #16
	add	x21, x21, #128
	cmp	x10, #2, lsl #12                ; =8192
	b.ne	LBB1_104
LBB1_105:                               ; %copy.continue204.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	str	q18, [sp, #1648]                ; 16-byte Spill
	str	q12, [sp, #1280]                ; 16-byte Spill
	str	q23, [sp, #1456]                ; 16-byte Spill
	str	q25, [sp, #1440]                ; 16-byte Spill
	str	q8, [sp, #1424]                 ; 16-byte Spill
	str	q31, [sp, #1408]                ; 16-byte Spill
	cbz	w2, LBB1_108
; %bb.106:                              ; %copy.active205.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x10, #0                         ; =0x0
	mov.d	x12, v25[1]
	ldr	q3, [sp, #1760]                 ; 16-byte Reload
	mov.d	x21, v3[1]
	add	x11, x1, x23, lsl #2
	add	x12, x12, x21
	add	x21, x12, #64
LBB1_107:                               ; %copy.chunk.i470.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x11, x10]
	stur	s3, [x21, #-64]
	mov	s17, v3[1]
	stur	s17, [x21, #-32]
	st1.s	{ v3 }[2], [x21]
	add	x12, x21, #32
	st1.s	{ v3 }[3], [x12]
	add	x10, x10, #16
	add	x21, x21, #128
	cmp	x10, #2, lsl #12                ; =8192
	b.ne	LBB1_107
LBB1_108:                               ;   in Loop: Header=BB1_40 Depth=2
	ldr	q11, [sp, #2608]                ; 16-byte Reload
	b	LBB1_129
LBB1_109:                               ; %direct.true727.i.i.preheader
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x21, #0                         ; =0x0
	b	LBB1_111
LBB1_110:                               ; %direct.schedule.44.i.i
                                        ;   in Loop: Header=BB1_111 Depth=3
	str	q24, [sp, #2400]                ; 16-byte Spill
	str	q23, [sp, #2416]                ; 16-byte Spill
	str	q18, [sp, #2432]                ; 16-byte Spill
	str	q17, [sp, #2448]                ; 16-byte Spill
	add	x10, x6, x21, lsl #5
	ldp	q3, q17, [x10]
	bit.16b	v17, v8, v0
	bit.16b	v3, v31, v2
	stp	q3, q17, [x10]
	add	x21, x21, #1
	cmp	x21, #2048
	b.eq	LBB1_128
LBB1_111:                               ; %direct.true727.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	sshll.2d	v3, v2, #0
	sshll.2d	v17, v0, #0
	and	x10, x21, #0x7f
	lsr	x11, x21, #7
	orr	x12, x11, #0x2000
	dup.2d	v18, x12
	add.2d	v19, v18, v9
	ldr	q20, [sp, #2560]                ; 16-byte Reload
	add.2d	v20, v18, v20
	ldr	q23, [sp, #2544]                ; 16-byte Reload
	add.2d	v23, v18, v23
	ldr	q24, [sp, #2528]                ; 16-byte Reload
	add.2d	v18, v18, v24
	shl.2d	v18, v18, #7
	shl.2d	v23, v23, #7
	shl.2d	v20, v20, #7
	shl.2d	v19, v19, #7
	dup.2d	v24, x10
	orr.16b	v19, v19, v24
	orr.16b	v20, v20, v24
	orr.16b	v23, v23, v24
	orr.16b	v18, v18, v24
	ldr	q24, [sp, #2400]                ; 16-byte Reload
	ldr	q31, [sp, #2624]                ; 16-byte Reload
	bit.16b	v24, v18, v31
	ldr	q18, [sp, #2416]                ; 16-byte Reload
	bif.16b	v23, v18, v17
	ldr	q18, [sp, #2432]                ; 16-byte Reload
	ldr	q17, [sp, #2592]                ; 16-byte Reload
	bit.16b	v18, v20, v17
	ldr	q17, [sp, #2448]                ; 16-byte Reload
	bit.16b	v17, v19, v3
	movi.2d	v31, #0000000000000000
	movi.2d	v8, #0000000000000000
	cbnz	x11, LBB1_110
; %bb.112:                              ; %direct.true740.i.i
                                        ;   in Loop: Header=BB1_111 Depth=3
	ldr	q3, [x26, lCPI1_6@PAGEOFF]
	and.16b	v3, v25, v3
	addv.8h	h3, v3
	fmov	w10, s3
	shl.2d	v3, v17, #2
	dup.2d	v9, x1
	add.2d	v3, v9, v3
	tbz	w10, #0, LBB1_120
; %bb.113:                              ; %cond.load
                                        ;   in Loop: Header=BB1_111 Depth=3
	fmov	x11, d3
	ldr	s31, [x11]
	and	w23, w10, #0xff
	tbnz	w23, #1, LBB1_121
LBB1_114:                               ; %else454
                                        ;   in Loop: Header=BB1_111 Depth=3
	shl.2d	v3, v18, #2
	add.2d	v3, v9, v3
	tbz	w23, #2, LBB1_122
LBB1_115:                               ; %cond.load456
                                        ;   in Loop: Header=BB1_111 Depth=3
	fmov	x10, d3
	ld1.s	{ v31 }[2], [x10]
	tbnz	w23, #3, LBB1_123
LBB1_116:                               ; %else460
                                        ;   in Loop: Header=BB1_111 Depth=3
	shl.2d	v3, v23, #2
	add.2d	v3, v9, v3
	tbz	w23, #4, LBB1_124
LBB1_117:                               ; %cond.load462
                                        ;   in Loop: Header=BB1_111 Depth=3
	fmov	x10, d3
	ld1.s	{ v8 }[0], [x10]
	tbnz	w23, #5, LBB1_125
LBB1_118:                               ; %else466
                                        ;   in Loop: Header=BB1_111 Depth=3
	shl.2d	v3, v24, #2
	add.2d	v3, v9, v3
	tbz	w23, #6, LBB1_126
LBB1_119:                               ; %cond.load468
                                        ;   in Loop: Header=BB1_111 Depth=3
	fmov	x10, d3
	ld1.s	{ v8 }[2], [x10]
	ldr	q9, [sp, #2288]                 ; 16-byte Reload
	tbz	w23, #7, LBB1_110
	b	LBB1_127
LBB1_120:                               ; %else
                                        ;   in Loop: Header=BB1_111 Depth=3
	and	w23, w10, #0xff
	tbz	w23, #1, LBB1_114
LBB1_121:                               ; %cond.load453
                                        ;   in Loop: Header=BB1_111 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v31 }[1], [x10]
	shl.2d	v3, v18, #2
	add.2d	v3, v9, v3
	tbnz	w23, #2, LBB1_115
LBB1_122:                               ; %else457
                                        ;   in Loop: Header=BB1_111 Depth=3
	tbz	w23, #3, LBB1_116
LBB1_123:                               ; %cond.load459
                                        ;   in Loop: Header=BB1_111 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v31 }[3], [x10]
	shl.2d	v3, v23, #2
	add.2d	v3, v9, v3
	tbnz	w23, #4, LBB1_117
LBB1_124:                               ; %else463
                                        ;   in Loop: Header=BB1_111 Depth=3
	tbz	w23, #5, LBB1_118
LBB1_125:                               ; %cond.load465
                                        ;   in Loop: Header=BB1_111 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v8 }[1], [x10]
	shl.2d	v3, v24, #2
	add.2d	v3, v9, v3
	tbnz	w23, #6, LBB1_119
LBB1_126:                               ; %else469
                                        ;   in Loop: Header=BB1_111 Depth=3
	ldr	q9, [sp, #2288]                 ; 16-byte Reload
	tbz	w23, #7, LBB1_110
LBB1_127:                               ; %cond.load471
                                        ;   in Loop: Header=BB1_111 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v8 }[3], [x10]
	b	LBB1_110
LBB1_128:                               ; %direct.schedule.9.loopexit.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	sshll.2d	v3, v2, #0
	sshll.2d	v17, v0, #0
	ldr	q18, [sp, #1440]                ; 16-byte Reload
	ldr	q19, [sp, #2624]                ; 16-byte Reload
	ldr	q20, [sp, #1792]                ; 16-byte Reload
	bit.16b	v18, v20, v19
	str	q18, [sp, #1440]                ; 16-byte Spill
	ldr	q23, [sp, #2592]                ; 16-byte Reload
	bit.16b	v12, v20, v23
	str	q12, [sp, #1280]                ; 16-byte Spill
	ldr	q18, [sp, #1456]                ; 16-byte Reload
	bit.16b	v18, v20, v17
	str	q18, [sp, #1456]                ; 16-byte Spill
	ldr	q18, [sp, #1648]                ; 16-byte Reload
	bit.16b	v18, v20, v3
	str	q18, [sp, #1648]                ; 16-byte Spill
	ldr	q18, [sp, #1760]                ; 16-byte Reload
	ldr	q20, [sp, #2384]                ; 16-byte Reload
	bit.16b	v18, v20, v19
	str	q18, [sp, #1760]                ; 16-byte Spill
	ldr	q18, [sp, #1776]                ; 16-byte Reload
	bit.16b	v18, v10, v23
	str	q18, [sp, #1776]                ; 16-byte Spill
	ldr	q18, [sp, #1408]                ; 16-byte Reload
	ldr	q19, [sp, #1840]                ; 16-byte Reload
	bit.16b	v18, v19, v17
	str	q18, [sp, #1408]                ; 16-byte Spill
	ldr	q17, [sp, #1424]                ; 16-byte Reload
	ldr	q18, [sp, #2112]                ; 16-byte Reload
	bit.16b	v17, v18, v3
	str	q17, [sp, #1424]                ; 16-byte Spill
	ldr	q11, [sp, #2608]                ; 16-byte Reload
	ldr	q19, [sp, #1920]                ; 16-byte Reload
	ldr	q9, [sp, #1904]                 ; 16-byte Reload
LBB1_129:                               ; %direct.schedule.9.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	bic.16b	v28, v28, v0
	bic.16b	v22, v22, v2
	bic.16b	v29, v29, v0
	bic.16b	v21, v21, v2
	bic.16b	v27, v27, v0
	bic.16b	v9, v9, v2
	bic.16b	v23, v19, v0
	add	x21, x8, #4, lsl #12            ; =16384
	mov	w23, #16384                     ; =0x4000
	ldr	q10, [sp, #1936]                ; 16-byte Reload
	bic.16b	v10, v10, v2
	ldr	q12, [sp, #2128]                ; 16-byte Reload
LBB1_130:                               ; %direct.true208.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	sub	x10, x23, #4, lsl #12           ; =16384
	fmov	d3, x10
	orr.16b	v17, v3, v11
	fmov	x10, d17
	add	x10, x8, x10
	ldp	q18, q17, [x10]
	and.16b	v18, v2, v18
	and.16b	v17, v0, v17
	orr.16b	v3, v3, v12
	fmov	x10, d3
	add	x10, x5, x10
	ldp	q19, q3, [x10]
	and.16b	v19, v2, v19
	and.16b	v3, v0, v3
	fmul.4s	v3, v17, v3
	fmul.4s	v19, v18, v19
	fadd.4s	v19, v22, v19
	fadd.4s	v3, v28, v3
	ldp	q24, q20, [x21]
	and.16b	v24, v2, v24
	and.16b	v20, v0, v20
	fmul.4s	v20, v17, v20
	fmul.4s	v24, v18, v24
	fadd.4s	v24, v21, v24
	fadd.4s	v20, v29, v20
	ldr	q25, [x21, #4112]
	ldr	q31, [x21, #4096]
	and.16b	v31, v2, v31
	and.16b	v25, v0, v25
	fmul.4s	v25, v17, v25
	fmul.4s	v31, v18, v31
	fadd.4s	v31, v9, v31
	fadd.4s	v25, v27, v25
	ldr	q8, [x21, #8208]
	mov.16b	v26, v28
	mov.16b	v28, v22
	mov.16b	v22, v29
	mov.16b	v29, v21
	mov.16b	v21, v27
	mov.16b	v27, v9
	ldr	q9, [x21, #8192]
	and.16b	v9, v2, v9
	and.16b	v8, v0, v8
	fmul.4s	v17, v17, v8
	fmul.4s	v18, v18, v9
	mov.16b	v9, v27
	mov.16b	v27, v21
	mov.16b	v21, v29
	mov.16b	v29, v22
	mov.16b	v22, v28
	fadd.4s	v18, v10, v18
	fadd.4s	v17, v23, v17
	mov.16b	v28, v0
	bsl.16b	v28, v3, v26
	bit.16b	v22, v19, v2
	bit.16b	v29, v20, v0
	bit.16b	v21, v24, v2
	bit.16b	v27, v25, v0
	bit.16b	v9, v31, v2
	bit.16b	v23, v17, v0
	bit.16b	v10, v18, v2
	add	x23, x23, #32
	add	x21, x21, #32
	cmp	x23, #5, lsl #12                ; =20480
	b.ne	LBB1_130
; %bb.131:                              ; %direct.false209.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	str	q28, [sp, #1856]                ; 16-byte Spill
	str	q22, [sp, #1872]                ; 16-byte Spill
	str	q29, [sp, #1296]                ; 16-byte Spill
	str	q21, [sp, #1312]                ; 16-byte Spill
	str	q27, [sp, #1328]                ; 16-byte Spill
	str	q9, [sp, #1904]                 ; 16-byte Spill
	str	q23, [sp, #1920]                ; 16-byte Spill
	str	q10, [sp, #1936]                ; 16-byte Spill
	ldr	q27, [sp, #1952]                ; 16-byte Reload
	bic.16b	v27, v27, v0
	ldr	q21, [sp, #1968]                ; 16-byte Reload
	bic.16b	v21, v21, v2
	ldr	q22, [sp, #1984]                ; 16-byte Reload
	bic.16b	v22, v22, v0
	ldr	q29, [sp, #2000]                ; 16-byte Reload
	bic.16b	v29, v29, v2
	bic.16b	v14, v14, v0
	ldr	q8, [sp, #2016]                 ; 16-byte Reload
	bic.16b	v8, v8, v2
	ldr	q23, [sp, #2032]                ; 16-byte Reload
	bic.16b	v23, v23, v0
	mov	x21, x8
	mov	w23, #128                       ; =0x80
	ldr	q26, [sp, #2208]                ; 16-byte Reload
	bic.16b	v26, v26, v2
LBB1_132:                               ; %direct.true244.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q17, q3, [x21]
	and.16b	v17, v2, v17
	and.16b	v3, v0, v3
	ldr	q18, [x21, #28688]
	ldr	q19, [x21, #28672]
	and.16b	v19, v2, v19
	and.16b	v18, v0, v18
	fmul.4s	v18, v3, v18
	fmul.4s	v19, v17, v19
	fadd.4s	v19, v21, v19
	fadd.4s	v18, v27, v18
	ldr	q20, [x21, #32784]
	ldr	q24, [x21, #32768]
	and.16b	v24, v2, v24
	and.16b	v20, v0, v20
	fmul.4s	v20, v3, v20
	fmul.4s	v24, v17, v24
	fadd.4s	v24, v29, v24
	fadd.4s	v20, v22, v20
	ldr	q25, [x21, #36880]
	ldr	q31, [x21, #36864]
	and.16b	v31, v2, v31
	and.16b	v25, v0, v25
	fmul.4s	v25, v3, v25
	fmul.4s	v31, v17, v31
	fadd.4s	v31, v8, v31
	fadd.4s	v25, v14, v25
	mov.16b	v28, v14
	mov.16b	v14, v8
	ldr	q8, [x21, #40976]
	ldr	q9, [x21, #40960]
	and.16b	v9, v2, v9
	and.16b	v8, v0, v8
	fmul.4s	v3, v3, v8
	mov.16b	v8, v14
	fmul.4s	v17, v17, v9
	fadd.4s	v17, v26, v17
	fadd.4s	v3, v23, v3
	bit.16b	v27, v18, v0
	bit.16b	v21, v19, v2
	bit.16b	v22, v20, v0
	bit.16b	v29, v24, v2
	mov.16b	v14, v0
	bsl.16b	v14, v25, v28
	bit.16b	v8, v31, v2
	bit.16b	v23, v3, v0
	bit.16b	v26, v17, v2
	add	x21, x21, #32
	subs	x23, x23, #1
	b.ne	LBB1_132
; %bb.133:                              ; %direct.false245.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	str	q27, [sp, #1952]                ; 16-byte Spill
	str	q21, [sp, #1968]                ; 16-byte Spill
	str	q22, [sp, #1984]                ; 16-byte Spill
	str	q29, [sp, #2000]                ; 16-byte Spill
	str	q14, [sp, #1888]                ; 16-byte Spill
	str	q8, [sp, #2016]                 ; 16-byte Spill
	str	q23, [sp, #2032]                ; 16-byte Spill
	str	q26, [sp, #2208]                ; 16-byte Spill
	ldr	q26, [sp, #2048]                ; 16-byte Reload
	bic.16b	v26, v26, v0
	ldr	q3, [sp, #2640]                 ; 16-byte Reload
	bic.16b	v3, v3, v2
	str	q3, [sp, #2640]                 ; 16-byte Spill
	ldr	q3, [sp, #2656]                 ; 16-byte Reload
	bic.16b	v3, v3, v0
	str	q3, [sp, #2656]                 ; 16-byte Spill
	ldr	q3, [sp, #2672]                 ; 16-byte Reload
	bic.16b	v3, v3, v2
	str	q3, [sp, #2672]                 ; 16-byte Spill
	ldr	q3, [sp, #2688]                 ; 16-byte Reload
	bic.16b	v3, v3, v0
	str	q3, [sp, #2688]                 ; 16-byte Spill
	ldr	q8, [sp, #2064]                 ; 16-byte Reload
	bic.16b	v8, v8, v2
	ldr	q14, [sp, #2080]                ; 16-byte Reload
	bic.16b	v14, v14, v0
	mov	x21, x8
	mov	w23, #128                       ; =0x80
	ldr	q12, [sp, #2096]                ; 16-byte Reload
	bic.16b	v12, v12, v2
	ldr	q23, [sp, #1552]                ; 16-byte Reload
	ldr	q10, [sp, #1472]                ; 16-byte Reload
	ldr	q11, [sp, #2144]                ; 16-byte Reload
LBB1_134:                               ; %direct.true282.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q17, q3, [x21]
	and.16b	v17, v2, v17
	and.16b	v3, v0, v3
	ldr	q18, [x21, #45072]
	ldr	q19, [x21, #45056]
	and.16b	v19, v2, v19
	and.16b	v18, v0, v18
	fmul.4s	v18, v3, v18
	fmul.4s	v19, v17, v19
	ldr	q27, [sp, #2640]                ; 16-byte Reload
	fadd.4s	v19, v27, v19
	fadd.4s	v18, v26, v18
	ldr	q20, [x21, #49168]
	ldr	q24, [x21, #49152]
	and.16b	v24, v2, v24
	and.16b	v20, v0, v20
	fmul.4s	v20, v3, v20
	fmul.4s	v24, v17, v24
	ldr	q22, [sp, #2672]                ; 16-byte Reload
	fadd.4s	v24, v22, v24
	ldr	q21, [sp, #2656]                ; 16-byte Reload
	fadd.4s	v20, v21, v20
	ldr	q25, [x21, #53264]
	ldr	q31, [x21, #53248]
	and.16b	v31, v2, v31
	and.16b	v25, v0, v25
	fmul.4s	v25, v3, v25
	fmul.4s	v31, v17, v31
	fadd.4s	v31, v8, v31
	ldr	q28, [sp, #2688]                ; 16-byte Reload
	fadd.4s	v25, v28, v25
	mov.16b	v29, v28
	mov.16b	v28, v8
	ldr	q8, [x21, #57360]
	ldr	q9, [x21, #57344]
	and.16b	v9, v2, v9
	and.16b	v8, v0, v8
	fmul.4s	v3, v3, v8
	mov.16b	v8, v28
	mov.16b	v28, v29
	mov.16b	v29, v22
	fmul.4s	v17, v17, v9
	fadd.4s	v17, v12, v17
	fadd.4s	v3, v14, v3
	bit.16b	v26, v18, v0
	bit.16b	v27, v19, v2
	str	q27, [sp, #2640]                ; 16-byte Spill
	mov.16b	v22, v0
	bsl.16b	v22, v20, v21
	str	q22, [sp, #2656]                ; 16-byte Spill
	bit.16b	v29, v24, v2
	str	q29, [sp, #2672]                ; 16-byte Spill
	bit.16b	v28, v25, v0
	str	q28, [sp, #2688]                ; 16-byte Spill
	bit.16b	v8, v31, v2
	bit.16b	v14, v3, v0
	bit.16b	v12, v17, v2
	add	x21, x21, #32
	subs	x23, x23, #1
	b.ne	LBB1_134
; %bb.135:                              ; %direct.false283.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	str	q26, [sp, #2048]                ; 16-byte Spill
	str	q8, [sp, #2064]                 ; 16-byte Spill
	str	q14, [sp, #2080]                ; 16-byte Spill
	str	q12, [sp, #2096]                ; 16-byte Spill
	bic.16b	v13, v13, v0
	bic.16b	v10, v10, v2
	bic.16b	v11, v11, v0
	ldr	q26, [sp, #1488]                ; 16-byte Reload
	bic.16b	v26, v26, v2
	ldr	q21, [sp, #1504]                ; 16-byte Reload
	bic.16b	v21, v21, v0
	ldr	q8, [sp, #1520]                 ; 16-byte Reload
	bic.16b	v8, v8, v2
	ldr	q25, [sp, #1536]                ; 16-byte Reload
	bic.16b	v25, v25, v0
	mov	x21, x8
	mov	w23, #128                       ; =0x80
	bic.16b	v23, v23, v2
LBB1_136:                               ; %direct.true320.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q17, q3, [x21]
	and.16b	v17, v2, v17
	and.16b	v3, v0, v3
	ldr	q18, [x21, #61456]
	ldr	q19, [x21, #61440]
	and.16b	v19, v2, v19
	and.16b	v18, v0, v18
	fmul.4s	v18, v3, v18
	fmul.4s	v19, v17, v19
	fadd.4s	v19, v10, v19
	fadd.4s	v18, v13, v18
	add	x10, x21, #16, lsl #12          ; =65536
	ldp	q24, q20, [x10]
	and.16b	v24, v2, v24
	and.16b	v20, v0, v20
	fmul.4s	v20, v3, v20
	fmul.4s	v24, v17, v24
	fadd.4s	v24, v26, v24
	fadd.4s	v20, v11, v20
	add	x10, x21, #17, lsl #12          ; =69632
	mov.16b	v14, v25
	ldp	q31, q25, [x10]
	and.16b	v31, v2, v31
	and.16b	v25, v0, v25
	fmul.4s	v25, v3, v25
	fmul.4s	v31, v17, v31
	fadd.4s	v31, v8, v31
	fadd.4s	v25, v21, v25
	add	x10, x21, #18, lsl #12          ; =73728
	mov.16b	v27, v13
	mov.16b	v13, v10
	mov.16b	v12, v11
	mov.16b	v10, v8
	ldp	q9, q8, [x10]
	and.16b	v9, v2, v9
	and.16b	v8, v0, v8
	fmul.4s	v3, v3, v8
	mov.16b	v8, v10
	mov.16b	v10, v13
	fmul.4s	v17, v17, v9
	fadd.4s	v17, v23, v17
	fadd.4s	v3, v14, v3
	mov.16b	v13, v0
	bsl.16b	v13, v18, v27
	bit.16b	v10, v19, v2
	mov.16b	v11, v0
	bsl.16b	v11, v20, v12
	bit.16b	v26, v24, v2
	bit.16b	v21, v25, v0
	bit.16b	v8, v31, v2
	mov.16b	v25, v0
	bsl.16b	v25, v3, v14
	bit.16b	v23, v17, v2
	add	x21, x21, #32
	subs	x23, x23, #1
	b.ne	LBB1_136
; %bb.137:                              ; %direct.false321.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x21, #0                         ; =0x0
	mov	w10, #1267                      ; =0x4f3
	movk	w10, #15797, lsl #16
	mov.16b	v14, v13
	mov.16b	v13, v11
	mov.16b	v11, v8
	dup.4s	v8, w10
	ldr	q3, [sp, #1872]                 ; 16-byte Reload
	fmul.4s	v31, v3, v8
	ldr	q3, [sp, #1856]                 ; 16-byte Reload
	fmul.4s	v28, v3, v8
	cmp	x19, #512
	cset	w23, lo
	dup.4h	v3, w23
	ldr	q29, [sp, #1296]                ; 16-byte Reload
	fmul.4s	v17, v29, v8
	mov.16b	v12, v21
	ldr	q21, [sp, #1312]                ; 16-byte Reload
	fmul.4s	v18, v21, v8
	ldr	q27, [sp, #1328]                ; 16-byte Reload
	fmul.4s	v19, v27, v8
	ldp	q20, q24, [x3]
	ushll.4s	v3, v3, #0
	bit.16b	v24, v28, v0
	bit.16b	v20, v31, v2
	stp	q20, q24, [x3]
	shl.4s	v3, v3, #31
	cmlt.4s	v9, v3, #0
	ldr	q20, [sp, #144]                 ; 16-byte Reload
	mov.16b	v24, v9
	bsl.16b	v24, v18, v20
	ldp	q3, q18, [x3, #32]
	bif.16b	v17, v20, v9
	str	q17, [sp, #1168]                ; 16-byte Spill
	bif.16b	v17, v18, v0
	str	q24, [sp, #1824]                ; 16-byte Spill
	bit.16b	v3, v24, v2
	stp	q3, q17, [x3, #32]
	ldr	q3, [sp, #1904]                 ; 16-byte Reload
	fmul.4s	v3, v3, v8
	ldr	q17, [sp, #1920]                ; 16-byte Reload
	fmul.4s	v17, v17, v8
	mov.16b	v24, v9
	bsl.16b	v24, v3, v20
	ldp	q3, q18, [x3, #64]
	bif.16b	v19, v20, v9
	str	q19, [sp, #1072]                ; 16-byte Spill
	bit.16b	v18, v19, v0
	str	q24, [sp, #1088]                ; 16-byte Spill
	bit.16b	v3, v24, v2
	stp	q3, q18, [x3, #64]
	ldr	q3, [sp, #1936]                 ; 16-byte Reload
	fmul.4s	v3, v3, v8
	ldr	q18, [sp, #1952]                ; 16-byte Reload
	fmul.4s	v18, v18, v8
	mov.16b	v24, v9
	bsl.16b	v24, v3, v20
	ldp	q3, q19, [x3, #96]
	bif.16b	v17, v20, v9
	stp	q17, q24, [sp, #976]            ; 32-byte Folded Spill
	bif.16b	v17, v19, v0
	bit.16b	v3, v24, v2
	stp	q3, q17, [x3, #96]
	ldr	q3, [sp, #1968]                 ; 16-byte Reload
	fmul.4s	v3, v3, v8
	ldr	q17, [sp, #1984]                ; 16-byte Reload
	fmul.4s	v17, v17, v8
	mov.16b	v24, v9
	bsl.16b	v24, v3, v20
	ldp	q3, q19, [x3, #128]
	bif.16b	v18, v20, v9
	stp	q18, q24, [sp, #880]            ; 32-byte Folded Spill
	bif.16b	v18, v19, v0
	bit.16b	v3, v24, v2
	stp	q3, q18, [x3, #128]
	ldr	q3, [sp, #2000]                 ; 16-byte Reload
	fmul.4s	v3, v3, v8
	ldr	q18, [sp, #1888]                ; 16-byte Reload
	fmul.4s	v18, v18, v8
	mov.16b	v24, v9
	bsl.16b	v24, v3, v20
	ldp	q3, q19, [x3, #160]
	bif.16b	v17, v20, v9
	stp	q17, q24, [sp, #800]            ; 32-byte Folded Spill
	bif.16b	v17, v19, v0
	bit.16b	v3, v24, v2
	stp	q3, q17, [x3, #160]
	ldr	q3, [sp, #2016]                 ; 16-byte Reload
	fmul.4s	v3, v3, v8
	ldr	q17, [sp, #2032]                ; 16-byte Reload
	fmul.4s	v17, v17, v8
	mov.16b	v24, v9
	bsl.16b	v24, v3, v20
	ldp	q3, q19, [x3, #192]
	bif.16b	v18, v20, v9
	stp	q18, q24, [sp, #704]            ; 32-byte Folded Spill
	bif.16b	v18, v19, v0
	bit.16b	v3, v24, v2
	stp	q3, q18, [x3, #192]
	ldr	q3, [sp, #2208]                 ; 16-byte Reload
	fmul.4s	v3, v3, v8
	ldr	q18, [sp, #2048]                ; 16-byte Reload
	fmul.4s	v18, v18, v8
	mov.16b	v24, v9
	bsl.16b	v24, v3, v20
	ldp	q3, q19, [x3, #224]
	bif.16b	v17, v20, v9
	stp	q17, q24, [sp, #608]            ; 32-byte Folded Spill
	bif.16b	v17, v19, v0
	bit.16b	v3, v24, v2
	stp	q3, q17, [x3, #224]
	ldr	q3, [sp, #2640]                 ; 16-byte Reload
	fmul.4s	v3, v3, v8
	ldr	q17, [sp, #2672]                ; 16-byte Reload
	fmul.4s	v17, v17, v8
	mov.16b	v24, v9
	bsl.16b	v24, v3, v20
	ldp	q3, q19, [x3, #256]
	bif.16b	v18, v20, v9
	stp	q18, q24, [sp, #512]            ; 32-byte Folded Spill
	bif.16b	v18, v19, v0
	bit.16b	v3, v24, v2
	stp	q3, q18, [x3, #256]
	ldr	q3, [sp, #2656]                 ; 16-byte Reload
	fmul.4s	v3, v3, v8
	ldr	q18, [sp, #2064]                ; 16-byte Reload
	fmul.4s	v18, v18, v8
	mov.16b	v24, v9
	bsl.16b	v24, v3, v20
	ldp	q19, q3, [x3, #288]
	bif.16b	v17, v20, v9
	stp	q17, q24, [sp, #544]            ; 32-byte Folded Spill
	bif.16b	v17, v19, v2
	bit.16b	v3, v24, v0
	stp	q17, q3, [x3, #288]
	ldr	q3, [sp, #2688]                 ; 16-byte Reload
	fmul.4s	v3, v3, v8
	ldr	q17, [sp, #2096]                ; 16-byte Reload
	fmul.4s	v17, v17, v8
	mov.16b	v24, v9
	bsl.16b	v24, v3, v20
	ldp	q19, q3, [x3, #320]
	bif.16b	v18, v20, v9
	stp	q18, q24, [sp, #640]            ; 32-byte Folded Spill
	bif.16b	v18, v19, v2
	bit.16b	v3, v24, v0
	stp	q18, q3, [x3, #320]
	ldr	q3, [sp, #2080]                 ; 16-byte Reload
	fmul.4s	v3, v3, v8
	str	q10, [sp, #1472]                ; 16-byte Spill
	fmul.4s	v18, v10, v8
	mov.16b	v24, v9
	bsl.16b	v24, v3, v20
	ldp	q19, q3, [x3, #352]
	bif.16b	v17, v20, v9
	stp	q17, q24, [sp, #736]            ; 32-byte Folded Spill
	bif.16b	v17, v19, v2
	bit.16b	v3, v24, v0
	stp	q17, q3, [x3, #352]
	str	q14, [sp, #1344]                ; 16-byte Spill
	fmul.4s	v3, v14, v8
	str	q13, [sp, #2144]                ; 16-byte Spill
	fmul.4s	v17, v13, v8
	mov.16b	v24, v9
	bsl.16b	v24, v3, v20
	ldp	q19, q3, [x3, #384]
	bif.16b	v18, v20, v9
	str	q18, [sp, #832]                 ; 16-byte Spill
	bif.16b	v18, v19, v2
	str	q24, [sp, #1808]                ; 16-byte Spill
	bit.16b	v3, v24, v0
	stp	q18, q3, [x3, #384]
	str	q26, [sp, #1488]                ; 16-byte Spill
	fmul.4s	v3, v26, v8
	mov.16b	v18, v9
	bsl.16b	v18, v3, v20
	mov.16b	v19, v9
	bsl.16b	v19, v17, v20
	ldp	q3, q17, [x3, #416]
	stp	q19, q18, [sp, #912]            ; 32-byte Folded Spill
	bit.16b	v17, v19, v0
	bit.16b	v3, v18, v2
	stp	q3, q17, [x3, #416]
	str	q11, [sp, #1520]                ; 16-byte Spill
	fmul.4s	v3, v11, v8
	str	q12, [sp, #1504]                ; 16-byte Spill
	fmul.4s	v17, v12, v8
	mov.16b	v18, v9
	bsl.16b	v18, v17, v20
	mov.16b	v17, v9
	bsl.16b	v17, v3, v20
	ldr	q3, [x3, #448]
	stp	q17, q18, [sp, #1008]           ; 32-byte Folded Spill
	bit.16b	v3, v17, v2
	ldr	q17, [x3, #464]
	bit.16b	v17, v18, v0
	stp	q3, q17, [x3, #448]
	str	q23, [sp, #1552]                ; 16-byte Spill
	fmul.4s	v3, v23, v8
	str	q25, [sp, #1536]                ; 16-byte Spill
	fmul.4s	v17, v25, v8
	mov.16b	v18, v9
	bsl.16b	v18, v17, v20
	mov.16b	v17, v9
	bsl.16b	v17, v3, v20
	ldr	q3, [x3, #480]
	str	q17, [sp, #1104]                ; 16-byte Spill
	bit.16b	v3, v17, v2
	ldr	q17, [x3, #496]
	str	q18, [sp, #1120]                ; 16-byte Spill
	bit.16b	v17, v18, v0
	stp	q3, q17, [x3, #480]
	mvni.4s	v3, #127, msl #16
	ldr	q19, [sp, #1568]                ; 16-byte Reload
	bit.16b	v19, v3, v0
	ldr	q18, [sp, #1584]                ; 16-byte Reload
	bit.16b	v18, v3, v2
	dup.8b	v3, w23
	str	d3, [sp, #1248]                 ; 8-byte Spill
LBB1_138:                               ; %direct.true455.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x10, x3, x21
	ldp	q3, q17, [x10]
	and.16b	v17, v0, v17
	and.16b	v3, v2, v3
	fmaxnm.4s	v3, v18, v3
	fmaxnm.4s	v17, v19, v17
	bit.16b	v19, v17, v0
	bit.16b	v18, v3, v2
	add	x21, x21, #32
	cmp	x21, #512
	b.ne	LBB1_138
; %bb.139:                              ; %direct.false456.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x28, #0                         ; =0x0
	ldr	q3, [sp, #1600]                 ; 16-byte Reload
	ldr	q17, [sp, #2624]                ; 16-byte Reload
	ldr	q20, [sp, #2384]                ; 16-byte Reload
	bit.16b	v3, v20, v17
	str	q3, [sp, #1600]                 ; 16-byte Spill
	str	q18, [sp, #1584]                ; 16-byte Spill
	ldr	q3, [sp, #2160]                 ; 16-byte Reload
	fmaxnm.4s	v3, v3, v18
	str	q3, [sp, #2240]                 ; 16-byte Spill
	fsub.4s	v3, v31, v3
	ldp	q18, q17, [sp, #208]            ; 32-byte Folded Reload
	cmhi.4s	v31, v18, v17
	mov	w10, #-1026555904               ; =0xc2d00000
	dup.4s	v26, w10
	and.16b	v12, v31, v3
	fcmge.4s	v3, v12, v26
	mov	w10, #1120403456                ; =0x42c80000
	dup.4s	v14, w10
	fcmge.4s	v17, v14, v12
	and.16b	v3, v3, v17
	str	q19, [sp, #1568]                ; 16-byte Spill
	ldr	q17, [sp, #2176]                ; 16-byte Reload
	fmaxnm.4s	v17, v17, v19
	str	q17, [sp, #2224]                ; 16-byte Spill
	fsub.4s	v17, v28, v17
	and.16b	v13, v0, v17
	fcmge.4s	v17, v13, v26
	fcmge.4s	v18, v14, v13
	and.16b	v17, v17, v18
	and.16b	v17, v17, v13
	mov	w10, #43579                     ; =0xaa3b
	movk	w10, #16312, lsl #16
	dup.4s	v22, w10
	str	q22, [sp, #2368]                ; 16-byte Spill
	fmul.4s	v18, v17, v22
	movi.4s	v20, #75, lsl #24
	mvni.4s	v8, #128, lsl #24
	mov.16b	v19, v8
	bsl.16b	v19, v20, v18
	fadd.4s	v18, v18, v19
	fsub.4s	v18, v18, v19
	and.16b	v3, v3, v12
	fmul.4s	v19, v3, v22
	bif.16b	v20, v19, v8
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	fcvtzs.4s	v8, v18
	scvtf.4s	v18, v8
	mov	w10, #29184                     ; =0x7200
	movk	w10, #16177, lsl #16
	dup.4s	v10, w10
	fmul.4s	v20, v18, v10
	fsub.4s	v17, v17, v20
	fcvtzs.4s	v9, v19
	scvtf.4s	v19, v9
	fmul.4s	v20, v19, v10
	fsub.4s	v3, v3, v20
	mov	w10, #48782                     ; =0xbe8e
	movk	w10, #13759, lsl #16
	dup.4s	v11, w10
	fmul.4s	v19, v19, v11
	fsub.4s	v3, v3, v19
	fmul.4s	v18, v18, v11
	fsub.4s	v17, v17, v18
	mov	w10, #11226                     ; =0x2bda
	movk	w10, #14672, lsl #16
	dup.4s	v25, w10
	fmul.4s	v18, v17, v25
	str	q25, [sp, #2272]                ; 16-byte Spill
	mov	w10, #38601                     ; =0x96c9
	movk	w10, #15030, lsl #16
	dup.4s	v24, w10
	fadd.4s	v18, v18, v24
	str	q24, [sp, #2256]                ; 16-byte Spill
	mov	w10, #34982                     ; =0x88a6
	movk	w10, #15368, lsl #16
	dup.4s	v23, w10
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v23
	str	q23, [sp, #2320]                ; 16-byte Spill
	fmul.4s	v18, v17, v18
	mov	w10, #43642                     ; =0xaa7a
	movk	w10, #15658, lsl #16
	dup.4s	v22, w10
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v17, v18
	mov	w10, #43691                     ; =0xaaab
	movk	w10, #15914, lsl #16
	dup.4s	v20, w10
	fadd.4s	v18, v18, v20
	str	q20, [sp, #2336]                ; 16-byte Spill
	fmul.4s	v18, v17, v18
	movi.4s	v19, #63, lsl #24
	fadd.4s	v18, v18, v19
	movi.4s	v28, #63, lsl #24
	fmul.4s	v19, v17, v17
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v3, v25
	fadd.4s	v19, v19, v24
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v23
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v22
	mov.16b	v25, v22
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v19, v28
	fmul.4s	v20, v3, v3
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v17, v17, v18
	fmov.4s	v22, #1.00000000
	fadd.4s	v3, v3, v22
	sshr.4s	v18, v9, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v22
	fmul.4s	v3, v3, v19
	fadd.4s	v17, v17, v22
	sshr.4s	v19, v8, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v22
	fmul.4s	v17, v17, v20
	sub.4s	v18, v9, v18
	sub.4s	v19, v8, v19
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v22
	fmul.4s	v17, v17, v19
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v22
	fmul.4s	v3, v3, v18
	str	q12, [sp, #1184]                ; 16-byte Spill
	fcmgt.4s	v18, v26, v12
	bic.16b	v3, v3, v18
	str	q13, [sp, #1232]                ; 16-byte Spill
	fcmgt.4s	v18, v26, v13
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v13, v14
	mvni.4s	v19, #127, msl #16
	fneg.4s	v19, v19
	str	q19, [sp, #2352]                ; 16-byte Spill
	bit.16b	v17, v19, v18
	str	q17, [sp, #1216]                ; 16-byte Spill
	fcmgt.4s	v17, v12, v14
	bit.16b	v3, v19, v17
	str	q3, [sp, #1200]                 ; 16-byte Spill
	ldr	q3, [sp, #1168]                 ; 16-byte Reload
	ldr	q17, [sp, #2224]                ; 16-byte Reload
	fsub.4s	v3, v3, v17
	and.16b	v12, v0, v3
	fcmge.4s	v3, v12, v26
	fcmge.4s	v17, v14, v12
	and.16b	v3, v3, v17
	ldr	q22, [sp, #2240]                ; 16-byte Reload
	ldr	q17, [sp, #1824]                ; 16-byte Reload
	fsub.4s	v17, v17, v22
	and.16b	v19, v31, v17
	str	q19, [sp, #1824]                ; 16-byte Spill
	fcmge.4s	v17, v19, v26
	fcmge.4s	v18, v14, v19
	and.16b	v17, v17, v18
	and.16b	v17, v17, v19
	ldr	q23, [sp, #2368]                ; 16-byte Reload
	fmul.4s	v18, v17, v23
	mvni.4s	v20, #128, lsl #24
	movi.4s	v24, #75, lsl #24
	mov.16b	v19, v20
	bsl.16b	v19, v24, v18
	fadd.4s	v18, v18, v19
	fsub.4s	v18, v18, v19
	and.16b	v3, v3, v12
	fmul.4s	v19, v3, v23
	bsl.16b	v20, v24, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	fcvtzs.4s	v8, v18
	scvtf.4s	v18, v8
	str	q10, [sp, #2384]                ; 16-byte Spill
	fmul.4s	v20, v18, v10
	fsub.4s	v17, v17, v20
	fcvtzs.4s	v19, v19
	scvtf.4s	v20, v19
	fmul.4s	v24, v20, v10
	fsub.4s	v3, v3, v24
	str	q11, [sp, #2304]                ; 16-byte Spill
	fmul.4s	v20, v20, v11
	fsub.4s	v3, v3, v20
	fmul.4s	v18, v18, v11
	fsub.4s	v17, v17, v18
	ldr	q10, [sp, #2272]                ; 16-byte Reload
	fmul.4s	v18, v17, v10
	ldr	q9, [sp, #2256]                 ; 16-byte Reload
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v17, v18
	ldr	q28, [sp, #2320]                ; 16-byte Reload
	fadd.4s	v18, v18, v28
	fmul.4s	v18, v17, v18
	mov.16b	v13, v25
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v17, v18
	ldr	q23, [sp, #2336]                ; 16-byte Reload
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v17, v18
	movi.4s	v24, #63, lsl #24
	fadd.4s	v18, v18, v24
	fmul.4s	v20, v17, v17
	fmul.4s	v18, v20, v18
	fmul.4s	v20, v3, v10
	fadd.4s	v20, v20, v9
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v28
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v25
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v23
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v24
	fmul.4s	v24, v3, v3
	fmul.4s	v20, v24, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v17, v17, v18
	fmov.4s	v23, #1.00000000
	fadd.4s	v3, v3, v23
	sshr.4s	v18, v19, #1
	shl.4s	v20, v18, #23
	add.4s	v20, v20, v23
	fmul.4s	v3, v3, v20
	fadd.4s	v17, v17, v23
	sshr.4s	v20, v8, #1
	shl.4s	v24, v20, #23
	add.4s	v24, v24, v23
	fmul.4s	v17, v17, v24
	sub.4s	v18, v19, v18
	sub.4s	v19, v8, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v23
	fmul.4s	v17, v17, v19
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v23
	fmov.4s	v9, #1.00000000
	fmul.4s	v3, v3, v18
	str	q12, [sp, #1136]                ; 16-byte Spill
	fcmgt.4s	v18, v26, v12
	bic.16b	v3, v3, v18
	ldr	q19, [sp, #1824]                ; 16-byte Reload
	fcmgt.4s	v18, v26, v19
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v19, v14
	ldr	q19, [sp, #2352]                ; 16-byte Reload
	bit.16b	v17, v19, v18
	str	q17, [sp, #1168]                ; 16-byte Spill
	fcmgt.4s	v17, v12, v14
	bit.16b	v3, v19, v17
	str	q3, [sp, #1152]                 ; 16-byte Spill
	ldr	q11, [sp, #2224]                ; 16-byte Reload
	ldr	q3, [sp, #1072]                 ; 16-byte Reload
	fsub.4s	v3, v3, v11
	and.16b	v25, v0, v3
	fcmge.4s	v3, v25, v26
	fcmge.4s	v17, v14, v25
	and.16b	v3, v3, v17
	ldr	q17, [sp, #1088]                ; 16-byte Reload
	fsub.4s	v17, v17, v22
	and.16b	v10, v31, v17
	fcmge.4s	v17, v10, v26
	fcmge.4s	v18, v14, v10
	and.16b	v17, v17, v18
	and.16b	v17, v17, v10
	ldr	q23, [sp, #2368]                ; 16-byte Reload
	fmul.4s	v18, v17, v23
	mvni.4s	v20, #128, lsl #24
	movi.4s	v22, #75, lsl #24
	mov.16b	v19, v20
	bsl.16b	v19, v22, v18
	fadd.4s	v18, v18, v19
	fsub.4s	v18, v18, v19
	and.16b	v3, v3, v25
	fmul.4s	v19, v3, v23
	bsl.16b	v20, v22, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	fcvtzs.4s	v8, v18
	scvtf.4s	v18, v8
	ldr	q23, [sp, #2384]                ; 16-byte Reload
	fmul.4s	v20, v18, v23
	fsub.4s	v17, v17, v20
	fcvtzs.4s	v22, v19
	scvtf.4s	v20, v22
	fmul.4s	v24, v20, v23
	fsub.4s	v3, v3, v24
	ldr	q19, [sp, #2304]                ; 16-byte Reload
	fmul.4s	v20, v20, v19
	fsub.4s	v3, v3, v20
	fmul.4s	v18, v18, v19
	fsub.4s	v17, v17, v18
	ldr	q19, [sp, #2272]                ; 16-byte Reload
	fmul.4s	v18, v17, v19
	ldr	q28, [sp, #2256]                ; 16-byte Reload
	fadd.4s	v18, v18, v28
	fmul.4s	v18, v17, v18
	ldr	q12, [sp, #2320]                ; 16-byte Reload
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v13
	fmul.4s	v18, v17, v18
	ldr	q24, [sp, #2336]                ; 16-byte Reload
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v17, v18
	movi.4s	v23, #63, lsl #24
	fadd.4s	v18, v18, v23
	fmul.4s	v20, v17, v17
	fmul.4s	v18, v20, v18
	fmul.4s	v20, v3, v19
	fadd.4s	v20, v20, v28
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v12
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v13
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v24
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v23
	fmul.4s	v24, v3, v3
	fmul.4s	v20, v24, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v17, v17, v18
	fadd.4s	v3, v3, v9
	sshr.4s	v18, v22, #1
	shl.4s	v20, v18, #23
	add.4s	v20, v20, v9
	fmul.4s	v3, v3, v20
	fadd.4s	v17, v17, v9
	sshr.4s	v20, v8, #1
	shl.4s	v24, v20, #23
	add.4s	v24, v24, v9
	fmul.4s	v17, v17, v24
	sub.4s	v18, v22, v18
	sub.4s	v19, v8, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v9
	fmul.4s	v17, v17, v19
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v9
	fmul.4s	v3, v3, v18
	str	q25, [sp, #1040]                ; 16-byte Spill
	fcmgt.4s	v18, v26, v25
	bic.16b	v3, v3, v18
	str	q10, [sp, #1072]                ; 16-byte Spill
	fcmgt.4s	v18, v26, v10
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v10, v14
	ldr	q19, [sp, #2352]                ; 16-byte Reload
	bit.16b	v17, v19, v18
	str	q17, [sp, #1088]                ; 16-byte Spill
	fcmgt.4s	v17, v25, v14
	bit.16b	v3, v19, v17
	str	q3, [sp, #1056]                 ; 16-byte Spill
	ldr	q3, [sp, #976]                  ; 16-byte Reload
	fsub.4s	v3, v3, v11
	and.16b	v11, v0, v3
	fcmge.4s	v3, v11, v26
	fcmge.4s	v17, v14, v11
	and.16b	v3, v3, v17
	ldr	q17, [sp, #992]                 ; 16-byte Reload
	ldr	q18, [sp, #2240]                ; 16-byte Reload
	fsub.4s	v17, v17, v18
	and.16b	v10, v31, v17
	fcmge.4s	v17, v10, v26
	fcmge.4s	v18, v14, v10
	and.16b	v17, v17, v18
	and.16b	v17, v17, v10
	ldr	q22, [sp, #2368]                ; 16-byte Reload
	fmul.4s	v18, v17, v22
	mvni.4s	v24, #128, lsl #24
	movi.4s	v25, #75, lsl #24
	mov.16b	v19, v24
	bsl.16b	v19, v25, v18
	fadd.4s	v18, v18, v19
	fsub.4s	v18, v18, v19
	and.16b	v3, v3, v11
	fmul.4s	v19, v3, v22
	mov.16b	v20, v24
	bsl.16b	v20, v25, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	fcvtzs.4s	v8, v18
	scvtf.4s	v18, v8
	ldr	q23, [sp, #2384]                ; 16-byte Reload
	fmul.4s	v20, v18, v23
	fsub.4s	v17, v17, v20
	fcvtzs.4s	v19, v19
	scvtf.4s	v20, v19
	fmul.4s	v24, v20, v23
	fsub.4s	v3, v3, v24
	ldr	q23, [sp, #2304]                ; 16-byte Reload
	fmul.4s	v20, v20, v23
	fsub.4s	v3, v3, v20
	fmul.4s	v18, v18, v23
	fsub.4s	v17, v17, v18
	ldr	q9, [sp, #2272]                 ; 16-byte Reload
	fmul.4s	v18, v17, v9
	mov.16b	v25, v28
	fadd.4s	v18, v18, v28
	fmul.4s	v18, v17, v18
	mov.16b	v23, v12
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v17, v18
	mov.16b	v28, v13
	str	q13, [sp, #2192]                ; 16-byte Spill
	fadd.4s	v18, v18, v13
	fmul.4s	v18, v17, v18
	ldr	q13, [sp, #2336]                ; 16-byte Reload
	fadd.4s	v18, v18, v13
	fmul.4s	v18, v17, v18
	movi.4s	v24, #63, lsl #24
	fadd.4s	v18, v18, v24
	fmul.4s	v20, v17, v17
	fmul.4s	v18, v20, v18
	fmul.4s	v20, v3, v9
	mov.16b	v12, v9
	fadd.4s	v20, v20, v25
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v23
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v28
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v13
	mov.16b	v25, v13
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v24
	fmul.4s	v24, v3, v3
	fmul.4s	v20, v24, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v17, v17, v18
	fmov.4s	v23, #1.00000000
	fadd.4s	v3, v3, v23
	sshr.4s	v18, v19, #1
	shl.4s	v20, v18, #23
	add.4s	v20, v20, v23
	fmul.4s	v3, v3, v20
	fadd.4s	v17, v17, v23
	sshr.4s	v20, v8, #1
	shl.4s	v24, v20, #23
	add.4s	v24, v24, v23
	fmul.4s	v17, v17, v24
	sub.4s	v18, v19, v18
	sub.4s	v19, v8, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v23
	fmul.4s	v17, v17, v19
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v23
	fmul.4s	v3, v3, v18
	fcmgt.4s	v18, v26, v11
	bic.16b	v3, v3, v18
	fcmgt.4s	v18, v26, v10
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v10, v14
	ldr	q19, [sp, #2352]                ; 16-byte Reload
	bit.16b	v17, v19, v18
	stp	q10, q17, [sp, #976]            ; 32-byte Folded Spill
	fcmgt.4s	v17, v11, v14
	bit.16b	v3, v19, v17
	stp	q11, q3, [sp, #944]             ; 32-byte Folded Spill
	ldr	q28, [sp, #2224]                ; 16-byte Reload
	ldr	q3, [sp, #880]                  ; 16-byte Reload
	fsub.4s	v3, v3, v28
	and.16b	v10, v0, v3
	fcmge.4s	v3, v10, v26
	fcmge.4s	v17, v14, v10
	and.16b	v3, v3, v17
	ldr	q9, [sp, #2240]                 ; 16-byte Reload
	ldr	q17, [sp, #896]                 ; 16-byte Reload
	fsub.4s	v17, v17, v9
	and.16b	v11, v31, v17
	fcmge.4s	v17, v11, v26
	fcmge.4s	v18, v14, v11
	and.16b	v17, v17, v18
	and.16b	v17, v17, v11
	fmul.4s	v18, v17, v22
	movi.4s	v20, #75, lsl #24
	mvni.4s	v23, #128, lsl #24
	mov.16b	v19, v23
	bsl.16b	v19, v20, v18
	fadd.4s	v18, v18, v19
	fsub.4s	v18, v18, v19
	and.16b	v3, v3, v10
	fmul.4s	v19, v3, v22
	bif.16b	v20, v19, v23
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	fcvtzs.4s	v8, v18
	scvtf.4s	v18, v8
	ldr	q22, [sp, #2384]                ; 16-byte Reload
	fmul.4s	v20, v18, v22
	fsub.4s	v17, v17, v20
	fcvtzs.4s	v23, v19
	scvtf.4s	v20, v23
	fmul.4s	v24, v20, v22
	fsub.4s	v3, v3, v24
	ldr	q19, [sp, #2304]                ; 16-byte Reload
	fmul.4s	v20, v20, v19
	fsub.4s	v3, v3, v20
	fmul.4s	v18, v18, v19
	fsub.4s	v17, v17, v18
	mov.16b	v19, v12
	fmul.4s	v18, v17, v12
	ldr	q13, [sp, #2256]                ; 16-byte Reload
	fadd.4s	v18, v18, v13
	fmul.4s	v18, v17, v18
	ldr	q12, [sp, #2320]                ; 16-byte Reload
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v17, v18
	ldr	q22, [sp, #2192]                ; 16-byte Reload
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v17, v18
	mov.16b	v24, v25
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v17, v18
	movi.4s	v25, #63, lsl #24
	fadd.4s	v18, v18, v25
	fmul.4s	v20, v17, v17
	fmul.4s	v18, v20, v18
	fmul.4s	v20, v3, v19
	fadd.4s	v20, v20, v13
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v12
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v22
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v24
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v25
	fmul.4s	v24, v3, v3
	fmul.4s	v20, v24, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v17, v17, v18
	fmov.4s	v25, #1.00000000
	fadd.4s	v3, v3, v25
	sshr.4s	v18, v23, #1
	shl.4s	v20, v18, #23
	add.4s	v20, v20, v25
	fmul.4s	v3, v3, v20
	fadd.4s	v17, v17, v25
	sshr.4s	v20, v8, #1
	shl.4s	v24, v20, #23
	add.4s	v24, v24, v25
	fmul.4s	v17, v17, v24
	sub.4s	v18, v23, v18
	sub.4s	v19, v8, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v25
	fmov.4s	v20, #1.00000000
	fmul.4s	v17, v17, v19
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v20
	fmul.4s	v3, v3, v18
	fcmgt.4s	v18, v26, v10
	bic.16b	v3, v3, v18
	fcmgt.4s	v18, v26, v11
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v11, v14
	ldr	q19, [sp, #2352]                ; 16-byte Reload
	bit.16b	v17, v19, v18
	stp	q11, q17, [sp, #880]            ; 32-byte Folded Spill
	fcmgt.4s	v17, v10, v14
	bit.16b	v3, v19, v17
	stp	q10, q3, [sp, #848]             ; 32-byte Folded Spill
	ldr	q3, [sp, #800]                  ; 16-byte Reload
	fsub.4s	v3, v3, v28
	and.16b	v10, v0, v3
	fcmge.4s	v3, v10, v26
	fcmge.4s	v17, v14, v10
	and.16b	v3, v3, v17
	ldr	q17, [sp, #816]                 ; 16-byte Reload
	fsub.4s	v17, v17, v9
	and.16b	v11, v31, v17
	fcmge.4s	v17, v11, v26
	fcmge.4s	v18, v14, v11
	and.16b	v17, v17, v18
	and.16b	v17, v17, v11
	ldr	q20, [sp, #2368]                ; 16-byte Reload
	fmul.4s	v18, v17, v20
	mvni.4s	v24, #128, lsl #24
	movi.4s	v23, #75, lsl #24
	mov.16b	v19, v24
	bsl.16b	v19, v23, v18
	fadd.4s	v18, v18, v19
	fsub.4s	v18, v18, v19
	and.16b	v3, v3, v10
	fmul.4s	v19, v3, v20
	mov.16b	v20, v24
	bsl.16b	v20, v23, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	fcvtzs.4s	v8, v18
	scvtf.4s	v18, v8
	ldr	q23, [sp, #2384]                ; 16-byte Reload
	fmul.4s	v20, v18, v23
	fsub.4s	v17, v17, v20
	fcvtzs.4s	v19, v19
	scvtf.4s	v20, v19
	fmul.4s	v24, v20, v23
	fsub.4s	v3, v3, v24
	ldr	q23, [sp, #2304]                ; 16-byte Reload
	fmul.4s	v20, v20, v23
	fsub.4s	v3, v3, v20
	fmul.4s	v18, v18, v23
	fsub.4s	v17, v17, v18
	ldr	q13, [sp, #2272]                ; 16-byte Reload
	fmul.4s	v18, v17, v13
	ldr	q25, [sp, #2256]                ; 16-byte Reload
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v17, v18
	mov.16b	v28, v12
	fadd.4s	v18, v18, v12
	fmul.4s	v18, v17, v18
	mov.16b	v12, v22
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v17, v18
	ldr	q22, [sp, #2336]                ; 16-byte Reload
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v17, v18
	movi.4s	v24, #63, lsl #24
	fadd.4s	v18, v18, v24
	fmul.4s	v20, v17, v17
	fmul.4s	v18, v20, v18
	fmul.4s	v20, v3, v13
	fadd.4s	v20, v20, v25
	mov.16b	v13, v25
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v28
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v12
	mov.16b	v25, v12
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v22
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v24
	fmul.4s	v24, v3, v3
	fmul.4s	v20, v24, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v17, v17, v18
	fmov.4s	v22, #1.00000000
	fadd.4s	v3, v3, v22
	sshr.4s	v18, v19, #1
	shl.4s	v20, v18, #23
	add.4s	v20, v20, v22
	fmul.4s	v3, v3, v20
	fadd.4s	v17, v17, v22
	sshr.4s	v20, v8, #1
	shl.4s	v24, v20, #23
	add.4s	v24, v24, v22
	fmul.4s	v17, v17, v24
	sub.4s	v18, v19, v18
	sub.4s	v19, v8, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v22
	fmul.4s	v17, v17, v19
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v22
	fmov.4s	v28, #1.00000000
	fmul.4s	v3, v3, v18
	fcmgt.4s	v18, v26, v10
	bic.16b	v3, v3, v18
	fcmgt.4s	v18, v26, v11
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v11, v14
	ldr	q19, [sp, #2352]                ; 16-byte Reload
	bit.16b	v17, v19, v18
	stp	q11, q17, [sp, #800]            ; 32-byte Folded Spill
	fcmgt.4s	v17, v10, v14
	bit.16b	v3, v19, v17
	stp	q10, q3, [sp, #768]             ; 32-byte Folded Spill
	ldr	q3, [sp, #704]                  ; 16-byte Reload
	ldr	q12, [sp, #2224]                ; 16-byte Reload
	fsub.4s	v3, v3, v12
	and.16b	v11, v0, v3
	fcmge.4s	v3, v11, v26
	fcmge.4s	v17, v14, v11
	and.16b	v3, v3, v17
	ldr	q17, [sp, #720]                 ; 16-byte Reload
	fsub.4s	v17, v17, v9
	and.16b	v10, v31, v17
	fcmge.4s	v17, v10, v26
	fcmge.4s	v18, v14, v10
	and.16b	v17, v17, v18
	and.16b	v17, v17, v10
	ldr	q22, [sp, #2368]                ; 16-byte Reload
	fmul.4s	v18, v17, v22
	movi.4s	v20, #75, lsl #24
	mvni.4s	v24, #128, lsl #24
	mov.16b	v19, v24
	bsl.16b	v19, v20, v18
	fadd.4s	v18, v18, v19
	fsub.4s	v18, v18, v19
	and.16b	v3, v3, v11
	fmul.4s	v19, v3, v22
	bif.16b	v20, v19, v24
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	fcvtzs.4s	v8, v18
	scvtf.4s	v18, v8
	ldr	q24, [sp, #2384]                ; 16-byte Reload
	fmul.4s	v20, v18, v24
	fsub.4s	v17, v17, v20
	fcvtzs.4s	v22, v19
	scvtf.4s	v20, v22
	fmul.4s	v24, v20, v24
	fsub.4s	v3, v3, v24
	fmul.4s	v20, v20, v23
	fsub.4s	v3, v3, v20
	fmul.4s	v18, v18, v23
	fsub.4s	v17, v17, v18
	ldr	q19, [sp, #2272]                ; 16-byte Reload
	fmul.4s	v18, v17, v19
	fadd.4s	v18, v18, v13
	fmul.4s	v18, v17, v18
	ldr	q9, [sp, #2320]                 ; 16-byte Reload
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v17, v18
	ldr	q24, [sp, #2336]                ; 16-byte Reload
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v17, v18
	movi.4s	v23, #63, lsl #24
	fadd.4s	v18, v18, v23
	fmul.4s	v20, v17, v17
	fmul.4s	v18, v20, v18
	fmul.4s	v20, v3, v19
	fadd.4s	v20, v20, v13
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v9
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v25
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v24
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v23
	fmul.4s	v24, v3, v3
	fmul.4s	v20, v24, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v17, v17, v18
	fadd.4s	v3, v3, v28
	sshr.4s	v18, v22, #1
	shl.4s	v20, v18, #23
	add.4s	v20, v20, v28
	fmul.4s	v3, v3, v20
	fadd.4s	v17, v17, v28
	sshr.4s	v20, v8, #1
	shl.4s	v24, v20, #23
	add.4s	v24, v24, v28
	fmul.4s	v17, v17, v24
	sub.4s	v18, v22, v18
	sub.4s	v19, v8, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v28
	fmul.4s	v17, v17, v19
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v28
	fmul.4s	v3, v3, v18
	fcmgt.4s	v18, v26, v11
	bic.16b	v3, v3, v18
	fcmgt.4s	v18, v26, v10
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v10, v14
	ldr	q19, [sp, #2352]                ; 16-byte Reload
	bit.16b	v17, v19, v18
	stp	q10, q17, [sp, #704]            ; 32-byte Folded Spill
	fcmgt.4s	v17, v11, v14
	bit.16b	v3, v19, v17
	stp	q11, q3, [sp, #672]             ; 32-byte Folded Spill
	mov.16b	v11, v12
	ldr	q3, [sp, #608]                  ; 16-byte Reload
	fsub.4s	v3, v3, v12
	and.16b	v25, v0, v3
	fcmge.4s	v3, v25, v26
	fcmge.4s	v17, v14, v25
	and.16b	v3, v3, v17
	ldr	q17, [sp, #624]                 ; 16-byte Reload
	ldr	q18, [sp, #2240]                ; 16-byte Reload
	fsub.4s	v17, v17, v18
	and.16b	v9, v31, v17
	fcmge.4s	v17, v9, v26
	fcmge.4s	v18, v14, v9
	and.16b	v17, v17, v18
	and.16b	v17, v17, v9
	ldr	q23, [sp, #2368]                ; 16-byte Reload
	fmul.4s	v18, v17, v23
	movi.4s	v20, #75, lsl #24
	mvni.4s	v22, #128, lsl #24
	mov.16b	v19, v22
	bsl.16b	v19, v20, v18
	fadd.4s	v18, v18, v19
	fsub.4s	v18, v18, v19
	and.16b	v3, v3, v25
	fmul.4s	v19, v3, v23
	bif.16b	v20, v19, v22
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	fcvtzs.4s	v8, v18
	scvtf.4s	v18, v8
	ldr	q22, [sp, #2384]                ; 16-byte Reload
	fmul.4s	v20, v18, v22
	fsub.4s	v17, v17, v20
	fcvtzs.4s	v19, v19
	scvtf.4s	v20, v19
	fmul.4s	v24, v20, v22
	fsub.4s	v3, v3, v24
	ldr	q22, [sp, #2304]                ; 16-byte Reload
	fmul.4s	v20, v20, v22
	fsub.4s	v3, v3, v20
	fmul.4s	v18, v18, v22
	fsub.4s	v17, v17, v18
	ldr	q12, [sp, #2272]                ; 16-byte Reload
	fmul.4s	v18, v17, v12
	fadd.4s	v18, v18, v13
	fmul.4s	v18, v17, v18
	ldr	q22, [sp, #2320]                ; 16-byte Reload
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v17, v18
	ldr	q28, [sp, #2192]                ; 16-byte Reload
	fadd.4s	v18, v18, v28
	fmul.4s	v18, v17, v18
	ldr	q23, [sp, #2336]                ; 16-byte Reload
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v17, v18
	movi.4s	v24, #63, lsl #24
	fadd.4s	v18, v18, v24
	fmul.4s	v20, v17, v17
	fmul.4s	v18, v20, v18
	fmul.4s	v20, v3, v12
	fadd.4s	v20, v20, v13
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v22
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v28
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v23
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v24
	fmul.4s	v24, v3, v3
	fmul.4s	v20, v24, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v17, v17, v18
	fmov.4s	v22, #1.00000000
	fadd.4s	v3, v3, v22
	sshr.4s	v18, v19, #1
	shl.4s	v20, v18, #23
	add.4s	v20, v20, v22
	fmul.4s	v3, v3, v20
	fadd.4s	v17, v17, v22
	sshr.4s	v20, v8, #1
	shl.4s	v24, v20, #23
	add.4s	v24, v24, v22
	fmul.4s	v17, v17, v24
	sub.4s	v18, v19, v18
	sub.4s	v19, v8, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v22
	fmul.4s	v17, v17, v19
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v22
	fmov.4s	v23, #1.00000000
	fmul.4s	v3, v3, v18
	fcmgt.4s	v18, v26, v25
	bic.16b	v3, v3, v18
	fcmgt.4s	v18, v26, v9
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v9, v14
	ldr	q19, [sp, #2352]                ; 16-byte Reload
	bit.16b	v17, v19, v18
	stp	q9, q17, [sp, #608]             ; 32-byte Folded Spill
	fcmgt.4s	v17, v25, v14
	bit.16b	v3, v19, v17
	stp	q25, q3, [sp, #576]             ; 32-byte Folded Spill
	ldr	q3, [sp, #512]                  ; 16-byte Reload
	fsub.4s	v3, v3, v11
	and.16b	v12, v0, v3
	fcmge.4s	v3, v12, v26
	fcmge.4s	v17, v14, v12
	and.16b	v3, v3, v17
	ldr	q10, [sp, #2240]                ; 16-byte Reload
	ldr	q17, [sp, #528]                 ; 16-byte Reload
	fsub.4s	v17, v17, v10
	and.16b	v13, v31, v17
	fcmge.4s	v17, v13, v26
	fcmge.4s	v18, v14, v13
	and.16b	v17, v17, v18
	and.16b	v17, v17, v13
	ldr	q22, [sp, #2368]                ; 16-byte Reload
	fmul.4s	v18, v17, v22
	mvni.4s	v20, #128, lsl #24
	movi.4s	v24, #75, lsl #24
	mov.16b	v19, v20
	bsl.16b	v19, v24, v18
	fadd.4s	v18, v18, v19
	fsub.4s	v18, v18, v19
	and.16b	v3, v3, v12
	fmul.4s	v19, v3, v22
	bsl.16b	v20, v24, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	fcvtzs.4s	v8, v18
	scvtf.4s	v18, v8
	ldr	q24, [sp, #2384]                ; 16-byte Reload
	fmul.4s	v20, v18, v24
	fsub.4s	v17, v17, v20
	fcvtzs.4s	v22, v19
	scvtf.4s	v20, v22
	fmul.4s	v24, v20, v24
	fsub.4s	v3, v3, v24
	ldr	q19, [sp, #2304]                ; 16-byte Reload
	fmul.4s	v20, v20, v19
	fsub.4s	v3, v3, v20
	fmul.4s	v18, v18, v19
	fsub.4s	v17, v17, v18
	ldr	q19, [sp, #2272]                ; 16-byte Reload
	fmul.4s	v18, v17, v19
	ldr	q24, [sp, #2256]                ; 16-byte Reload
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v17, v18
	ldr	q9, [sp, #2320]                 ; 16-byte Reload
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v17, v18
	mov.16b	v11, v28
	fadd.4s	v18, v18, v28
	fmul.4s	v18, v17, v18
	ldr	q25, [sp, #2336]                ; 16-byte Reload
	fadd.4s	v18, v18, v25
	fmul.4s	v18, v17, v18
	movi.4s	v28, #63, lsl #24
	fadd.4s	v18, v18, v28
	fmul.4s	v20, v17, v17
	fmul.4s	v18, v20, v18
	fmul.4s	v20, v3, v19
	fadd.4s	v20, v20, v24
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v9
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v11
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v25
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v28
	fmul.4s	v24, v3, v3
	fmul.4s	v20, v24, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v17, v17, v18
	fadd.4s	v3, v3, v23
	sshr.4s	v18, v22, #1
	shl.4s	v20, v18, #23
	add.4s	v20, v20, v23
	fmul.4s	v3, v3, v20
	fadd.4s	v17, v17, v23
	sshr.4s	v20, v8, #1
	shl.4s	v24, v20, #23
	add.4s	v24, v24, v23
	fmul.4s	v17, v17, v24
	sub.4s	v18, v22, v18
	sub.4s	v19, v8, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v23
	fmul.4s	v17, v17, v19
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v23
	fmul.4s	v3, v3, v18
	fcmgt.4s	v18, v26, v12
	bic.16b	v3, v3, v18
	fcmgt.4s	v18, v26, v13
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v13, v14
	ldr	q28, [sp, #2352]                ; 16-byte Reload
	bit.16b	v17, v28, v18
	stp	q13, q17, [sp, #512]            ; 32-byte Folded Spill
	fcmgt.4s	v17, v12, v14
	bit.16b	v3, v28, v17
	stp	q12, q3, [sp, #480]             ; 32-byte Folded Spill
	ldr	q3, [sp, #544]                  ; 16-byte Reload
	fsub.4s	v3, v3, v10
	and.16b	v12, v31, v3
	fcmge.4s	v3, v12, v26
	fcmge.4s	v17, v14, v12
	and.16b	v3, v3, v17
	ldr	q17, [sp, #560]                 ; 16-byte Reload
	ldr	q18, [sp, #2224]                ; 16-byte Reload
	fsub.4s	v17, v17, v18
	and.16b	v25, v0, v17
	fcmge.4s	v17, v25, v26
	fcmge.4s	v18, v14, v25
	and.16b	v17, v17, v18
	and.16b	v17, v17, v25
	ldr	q23, [sp, #2368]                ; 16-byte Reload
	fmul.4s	v18, v17, v23
	movi.4s	v20, #75, lsl #24
	mvni.4s	v22, #128, lsl #24
	mov.16b	v19, v22
	bsl.16b	v19, v20, v18
	fadd.4s	v18, v18, v19
	fsub.4s	v18, v18, v19
	and.16b	v3, v3, v12
	fmul.4s	v19, v3, v23
	bif.16b	v20, v19, v22
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	fcvtzs.4s	v8, v18
	scvtf.4s	v18, v8
	ldr	q22, [sp, #2384]                ; 16-byte Reload
	fmul.4s	v20, v18, v22
	fsub.4s	v17, v17, v20
	fcvtzs.4s	v19, v19
	scvtf.4s	v20, v19
	fmul.4s	v24, v20, v22
	fsub.4s	v3, v3, v24
	ldr	q22, [sp, #2304]                ; 16-byte Reload
	fmul.4s	v20, v20, v22
	fsub.4s	v3, v3, v20
	fmul.4s	v18, v18, v22
	fsub.4s	v17, v17, v18
	ldr	q22, [sp, #2272]                ; 16-byte Reload
	fmul.4s	v18, v17, v22
	ldr	q10, [sp, #2256]                ; 16-byte Reload
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v17, v18
	ldr	q13, [sp, #2320]                ; 16-byte Reload
	fadd.4s	v18, v18, v13
	fmul.4s	v18, v17, v18
	mov.16b	v23, v11
	fadd.4s	v18, v18, v11
	fmul.4s	v18, v17, v18
	ldr	q11, [sp, #2336]                ; 16-byte Reload
	fadd.4s	v18, v18, v11
	fmul.4s	v18, v17, v18
	movi.4s	v24, #63, lsl #24
	fadd.4s	v18, v18, v24
	fmul.4s	v20, v17, v17
	fmul.4s	v18, v20, v18
	fmul.4s	v20, v3, v22
	fadd.4s	v20, v20, v10
	mov.16b	v22, v10
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v13
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v23
	mov.16b	v10, v23
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v11
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v24
	fmul.4s	v24, v3, v3
	fmul.4s	v20, v24, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v17, v17, v18
	fmov.4s	v23, #1.00000000
	fadd.4s	v3, v3, v23
	sshr.4s	v18, v19, #1
	shl.4s	v20, v18, #23
	add.4s	v20, v20, v23
	fmul.4s	v3, v3, v20
	fadd.4s	v17, v17, v23
	sshr.4s	v20, v8, #1
	shl.4s	v24, v20, #23
	add.4s	v24, v24, v23
	fmul.4s	v17, v17, v24
	sub.4s	v18, v19, v18
	sub.4s	v19, v8, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v23
	fmul.4s	v17, v17, v19
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v23
	fmov.4s	v13, #1.00000000
	fmul.4s	v3, v3, v18
	fcmgt.4s	v18, v26, v12
	bic.16b	v3, v3, v18
	fcmgt.4s	v18, v26, v25
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v25, v14
	bit.16b	v17, v28, v18
	stp	q25, q17, [sp, #544]            ; 32-byte Folded Spill
	fcmgt.4s	v17, v12, v14
	bit.16b	v3, v28, v17
	stp	q12, q3, [sp, #448]             ; 32-byte Folded Spill
	ldr	q3, [sp, #640]                  ; 16-byte Reload
	ldr	q17, [sp, #2240]                ; 16-byte Reload
	fsub.4s	v3, v3, v17
	and.16b	v9, v31, v3
	fcmge.4s	v3, v9, v26
	fcmge.4s	v17, v14, v9
	and.16b	v3, v3, v17
	ldr	q17, [sp, #656]                 ; 16-byte Reload
	ldr	q25, [sp, #2224]                ; 16-byte Reload
	fsub.4s	v17, v17, v25
	and.16b	v11, v0, v17
	fcmge.4s	v17, v11, v26
	fcmge.4s	v18, v14, v11
	and.16b	v17, v17, v18
	and.16b	v17, v17, v11
	ldr	q23, [sp, #2368]                ; 16-byte Reload
	fmul.4s	v18, v17, v23
	mvni.4s	v20, #128, lsl #24
	movi.4s	v24, #75, lsl #24
	mov.16b	v19, v20
	bsl.16b	v19, v24, v18
	fadd.4s	v18, v18, v19
	fsub.4s	v18, v18, v19
	and.16b	v3, v3, v9
	fmul.4s	v19, v3, v23
	bsl.16b	v20, v24, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	fcvtzs.4s	v8, v18
	scvtf.4s	v18, v8
	ldr	q24, [sp, #2384]                ; 16-byte Reload
	fmul.4s	v20, v18, v24
	fsub.4s	v17, v17, v20
	fcvtzs.4s	v23, v19
	scvtf.4s	v20, v23
	fmul.4s	v24, v20, v24
	fsub.4s	v3, v3, v24
	ldr	q19, [sp, #2304]                ; 16-byte Reload
	fmul.4s	v20, v20, v19
	fsub.4s	v3, v3, v20
	fmul.4s	v18, v18, v19
	fsub.4s	v17, v17, v18
	ldr	q12, [sp, #2272]                ; 16-byte Reload
	fmul.4s	v18, v17, v12
	mov.16b	v19, v22
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v17, v18
	ldr	q28, [sp, #2320]                ; 16-byte Reload
	fadd.4s	v18, v18, v28
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v17, v18
	ldr	q22, [sp, #2336]                ; 16-byte Reload
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v17, v18
	movi.4s	v24, #63, lsl #24
	fadd.4s	v18, v18, v24
	fmul.4s	v20, v17, v17
	fmul.4s	v18, v20, v18
	fmul.4s	v20, v3, v12
	fadd.4s	v20, v20, v19
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v28
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v10
	mov.16b	v28, v10
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v22
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v24
	fmul.4s	v24, v3, v3
	fmul.4s	v20, v24, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v17, v17, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v23, #1
	shl.4s	v20, v18, #23
	add.4s	v20, v20, v13
	fmul.4s	v3, v3, v20
	fadd.4s	v17, v17, v13
	sshr.4s	v20, v8, #1
	shl.4s	v24, v20, #23
	add.4s	v24, v24, v13
	fmul.4s	v17, v17, v24
	sub.4s	v18, v23, v18
	sub.4s	v19, v8, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v17, v17, v19
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v13
	fmul.4s	v3, v3, v18
	fcmgt.4s	v18, v26, v9
	bic.16b	v3, v3, v18
	fcmgt.4s	v18, v26, v11
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v11, v14
	ldr	q19, [sp, #2352]                ; 16-byte Reload
	bit.16b	v17, v19, v18
	stp	q11, q17, [sp, #640]            ; 32-byte Folded Spill
	fcmgt.4s	v17, v9, v14
	bit.16b	v3, v19, v17
	stp	q9, q3, [sp, #416]              ; 32-byte Folded Spill
	ldr	q3, [sp, #736]                  ; 16-byte Reload
	ldr	q9, [sp, #2240]                 ; 16-byte Reload
	fsub.4s	v3, v3, v9
	and.16b	v10, v31, v3
	fcmge.4s	v3, v10, v26
	fcmge.4s	v17, v14, v10
	and.16b	v3, v3, v17
	ldr	q17, [sp, #752]                 ; 16-byte Reload
	fsub.4s	v17, v17, v25
	and.16b	v25, v0, v17
	fcmge.4s	v17, v25, v26
	fcmge.4s	v18, v14, v25
	and.16b	v17, v17, v18
	and.16b	v17, v17, v25
	ldr	q20, [sp, #2368]                ; 16-byte Reload
	fmul.4s	v18, v17, v20
	movi.4s	v24, #75, lsl #24
	mvni.4s	v8, #128, lsl #24
	mov.16b	v19, v8
	bsl.16b	v19, v24, v18
	fadd.4s	v18, v18, v19
	fsub.4s	v18, v18, v19
	and.16b	v3, v3, v10
	fmul.4s	v19, v3, v20
	mov.16b	v20, v8
	bsl.16b	v20, v24, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	fcvtzs.4s	v8, v18
	scvtf.4s	v18, v8
	ldr	q23, [sp, #2384]                ; 16-byte Reload
	fmul.4s	v20, v18, v23
	fsub.4s	v17, v17, v20
	fcvtzs.4s	v19, v19
	scvtf.4s	v20, v19
	fmul.4s	v24, v20, v23
	fsub.4s	v3, v3, v24
	ldr	q23, [sp, #2304]                ; 16-byte Reload
	fmul.4s	v20, v20, v23
	fsub.4s	v3, v3, v20
	fmul.4s	v18, v18, v23
	fsub.4s	v17, v17, v18
	fmul.4s	v18, v17, v12
	ldr	q23, [sp, #2256]                ; 16-byte Reload
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v17, v18
	ldr	q11, [sp, #2320]                ; 16-byte Reload
	fadd.4s	v18, v18, v11
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v28
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v17, v18
	movi.4s	v24, #63, lsl #24
	fadd.4s	v18, v18, v24
	fmul.4s	v20, v17, v17
	fmul.4s	v18, v20, v18
	fmul.4s	v20, v3, v12
	fadd.4s	v20, v20, v23
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v11
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v28
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v22
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v24
	fmul.4s	v24, v3, v3
	fmul.4s	v20, v24, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v17, v17, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v19, #1
	shl.4s	v20, v18, #23
	add.4s	v20, v20, v13
	fmul.4s	v3, v3, v20
	fadd.4s	v17, v17, v13
	sshr.4s	v20, v8, #1
	shl.4s	v24, v20, #23
	add.4s	v24, v24, v13
	fmul.4s	v17, v17, v24
	sub.4s	v18, v19, v18
	sub.4s	v19, v8, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v17, v17, v19
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v13
	fmul.4s	v3, v3, v18
	fcmgt.4s	v18, v26, v10
	bic.16b	v3, v3, v18
	fcmgt.4s	v18, v26, v25
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v25, v14
	ldr	q19, [sp, #2352]                ; 16-byte Reload
	bit.16b	v17, v19, v18
	stp	q25, q17, [sp, #736]            ; 32-byte Folded Spill
	fcmgt.4s	v17, v10, v14
	bit.16b	v3, v19, v17
	stp	q10, q3, [sp, #384]             ; 32-byte Folded Spill
	ldr	q3, [sp, #832]                  ; 16-byte Reload
	fsub.4s	v3, v3, v9
	mov.16b	v12, v9
	and.16b	v10, v31, v3
	fcmge.4s	v3, v10, v26
	fcmge.4s	v17, v14, v10
	and.16b	v3, v3, v17
	ldr	q17, [sp, #1808]                ; 16-byte Reload
	ldr	q11, [sp, #2224]                ; 16-byte Reload
	fsub.4s	v17, v17, v11
	and.16b	v19, v0, v17
	str	q19, [sp, #1808]                ; 16-byte Spill
	fcmge.4s	v17, v19, v26
	fcmge.4s	v18, v14, v19
	and.16b	v17, v17, v18
	and.16b	v17, v17, v19
	ldr	q20, [sp, #2368]                ; 16-byte Reload
	fmul.4s	v18, v17, v20
	mvni.4s	v22, #128, lsl #24
	movi.4s	v23, #75, lsl #24
	mov.16b	v19, v22
	bsl.16b	v19, v23, v18
	fadd.4s	v18, v18, v19
	fsub.4s	v18, v18, v19
	and.16b	v3, v3, v10
	fmul.4s	v19, v3, v20
	mov.16b	v20, v22
	bsl.16b	v20, v23, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	fcvtzs.4s	v8, v18
	scvtf.4s	v18, v8
	ldr	q22, [sp, #2384]                ; 16-byte Reload
	fmul.4s	v20, v18, v22
	fsub.4s	v17, v17, v20
	fcvtzs.4s	v23, v19
	scvtf.4s	v20, v23
	fmul.4s	v24, v20, v22
	fsub.4s	v3, v3, v24
	ldr	q19, [sp, #2304]                ; 16-byte Reload
	fmul.4s	v20, v20, v19
	fsub.4s	v3, v3, v20
	fmul.4s	v18, v18, v19
	fsub.4s	v17, v17, v18
	ldr	q19, [sp, #2272]                ; 16-byte Reload
	fmul.4s	v18, v17, v19
	ldr	q22, [sp, #2256]                ; 16-byte Reload
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v17, v18
	ldr	q9, [sp, #2320]                 ; 16-byte Reload
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v28
	fmul.4s	v18, v17, v18
	ldr	q24, [sp, #2336]                ; 16-byte Reload
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v17, v18
	movi.4s	v25, #63, lsl #24
	fadd.4s	v18, v18, v25
	fmul.4s	v20, v17, v17
	fmul.4s	v18, v20, v18
	fmul.4s	v20, v3, v19
	fadd.4s	v20, v20, v22
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v9
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v28
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v24
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v25
	fmul.4s	v24, v3, v3
	fmul.4s	v20, v24, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v17, v17, v18
	fadd.4s	v3, v3, v13
	sshr.4s	v18, v23, #1
	shl.4s	v20, v18, #23
	add.4s	v20, v20, v13
	fmul.4s	v3, v3, v20
	fadd.4s	v17, v17, v13
	sshr.4s	v20, v8, #1
	shl.4s	v24, v20, #23
	add.4s	v24, v24, v13
	fmul.4s	v17, v17, v24
	sub.4s	v18, v23, v18
	sub.4s	v19, v8, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v17, v17, v19
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v13
	fmul.4s	v3, v3, v18
	fcmgt.4s	v18, v26, v10
	bic.16b	v3, v3, v18
	ldr	q25, [sp, #1808]                ; 16-byte Reload
	fcmgt.4s	v18, v26, v25
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v25, v14
	ldr	q19, [sp, #2352]                ; 16-byte Reload
	bit.16b	v17, v19, v18
	str	q17, [sp, #832]                 ; 16-byte Spill
	fcmgt.4s	v17, v10, v14
	bit.16b	v3, v19, v17
	stp	q10, q3, [sp, #352]             ; 32-byte Folded Spill
	ldr	q3, [sp, #912]                  ; 16-byte Reload
	fsub.4s	v3, v3, v11
	and.16b	v25, v0, v3
	fcmge.4s	v3, v25, v26
	fcmge.4s	v17, v14, v25
	and.16b	v3, v3, v17
	ldr	q17, [sp, #928]                 ; 16-byte Reload
	fsub.4s	v17, v17, v12
	and.16b	v9, v31, v17
	fcmge.4s	v17, v9, v26
	fcmge.4s	v18, v14, v9
	and.16b	v17, v17, v18
	and.16b	v17, v17, v9
	ldr	q20, [sp, #2368]                ; 16-byte Reload
	fmul.4s	v18, v17, v20
	mvni.4s	v22, #128, lsl #24
	movi.4s	v23, #75, lsl #24
	mov.16b	v19, v22
	bsl.16b	v19, v23, v18
	fadd.4s	v18, v18, v19
	fsub.4s	v18, v18, v19
	and.16b	v3, v3, v25
	fmul.4s	v19, v3, v20
	mov.16b	v20, v22
	bsl.16b	v20, v23, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	fcvtzs.4s	v8, v18
	scvtf.4s	v18, v8
	ldr	q22, [sp, #2384]                ; 16-byte Reload
	fmul.4s	v20, v18, v22
	fsub.4s	v17, v17, v20
	fcvtzs.4s	v19, v19
	scvtf.4s	v20, v19
	fmul.4s	v24, v20, v22
	fsub.4s	v3, v3, v24
	ldr	q22, [sp, #2304]                ; 16-byte Reload
	fmul.4s	v20, v20, v22
	fsub.4s	v3, v3, v20
	fmul.4s	v18, v18, v22
	fsub.4s	v17, v17, v18
	ldr	q12, [sp, #2272]                ; 16-byte Reload
	fmul.4s	v18, v17, v12
	ldr	q24, [sp, #2256]                ; 16-byte Reload
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v17, v18
	ldr	q23, [sp, #2320]                ; 16-byte Reload
	fadd.4s	v18, v18, v23
	fmul.4s	v18, v17, v18
	mov.16b	v11, v28
	fadd.4s	v18, v18, v28
	fmul.4s	v18, v17, v18
	ldr	q10, [sp, #2336]                ; 16-byte Reload
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v17, v18
	movi.4s	v22, #63, lsl #24
	fadd.4s	v18, v18, v22
	fmul.4s	v20, v17, v17
	fmul.4s	v18, v20, v18
	fmul.4s	v20, v3, v12
	mov.16b	v28, v12
	fadd.4s	v20, v20, v24
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v23
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v11
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v10
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v22
	fmul.4s	v24, v3, v3
	fmul.4s	v20, v24, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v17, v17, v18
	fmov.4s	v23, #1.00000000
	fadd.4s	v3, v3, v23
	sshr.4s	v18, v19, #1
	shl.4s	v20, v18, #23
	add.4s	v20, v20, v23
	fmul.4s	v3, v3, v20
	fadd.4s	v17, v17, v23
	sshr.4s	v20, v8, #1
	shl.4s	v24, v20, #23
	add.4s	v24, v24, v23
	fmul.4s	v17, v17, v24
	sub.4s	v18, v19, v18
	sub.4s	v19, v8, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v23
	fmul.4s	v17, v17, v19
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v23
	fmul.4s	v3, v3, v18
	fcmgt.4s	v18, v26, v25
	bic.16b	v3, v3, v18
	fcmgt.4s	v18, v26, v9
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v9, v14
	ldr	q19, [sp, #2352]                ; 16-byte Reload
	bit.16b	v17, v19, v18
	stp	q9, q17, [sp, #912]             ; 32-byte Folded Spill
	fcmgt.4s	v17, v25, v14
	bit.16b	v3, v19, v17
	stp	q25, q3, [sp, #320]             ; 32-byte Folded Spill
	ldr	q3, [sp, #1008]                 ; 16-byte Reload
	ldr	q13, [sp, #2240]                ; 16-byte Reload
	fsub.4s	v3, v3, v13
	and.16b	v9, v31, v3
	fcmge.4s	v3, v9, v26
	fcmge.4s	v17, v14, v9
	and.16b	v3, v3, v17
	ldr	q17, [sp, #1024]                ; 16-byte Reload
	ldr	q12, [sp, #2224]                ; 16-byte Reload
	fsub.4s	v17, v17, v12
	and.16b	v25, v0, v17
	fcmge.4s	v17, v25, v26
	fcmge.4s	v18, v14, v25
	and.16b	v17, v17, v18
	and.16b	v17, v17, v25
	ldr	q20, [sp, #2368]                ; 16-byte Reload
	fmul.4s	v18, v17, v20
	movi.4s	v22, #75, lsl #24
	mvni.4s	v23, #128, lsl #24
	mov.16b	v19, v23
	bsl.16b	v19, v22, v18
	fadd.4s	v18, v18, v19
	fsub.4s	v18, v18, v19
	and.16b	v3, v3, v9
	fmul.4s	v19, v3, v20
	mov.16b	v20, v23
	bsl.16b	v20, v22, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	fcvtzs.4s	v8, v18
	scvtf.4s	v18, v8
	ldr	q22, [sp, #2384]                ; 16-byte Reload
	fmul.4s	v20, v18, v22
	fsub.4s	v17, v17, v20
	fcvtzs.4s	v19, v19
	scvtf.4s	v20, v19
	fmul.4s	v24, v20, v22
	fsub.4s	v3, v3, v24
	ldr	q22, [sp, #2304]                ; 16-byte Reload
	fmul.4s	v20, v20, v22
	fsub.4s	v3, v3, v20
	fmul.4s	v18, v18, v22
	fsub.4s	v17, v17, v18
	mov.16b	v23, v28
	fmul.4s	v18, v17, v28
	ldr	q22, [sp, #2256]                ; 16-byte Reload
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v17, v18
	ldr	q28, [sp, #2320]                ; 16-byte Reload
	fadd.4s	v18, v18, v28
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v11
	fmul.4s	v18, v17, v18
	mov.16b	v24, v10
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v17, v18
	movi.4s	v10, #63, lsl #24
	fadd.4s	v18, v18, v10
	fmul.4s	v20, v17, v17
	fmul.4s	v18, v20, v18
	fmul.4s	v20, v3, v23
	fadd.4s	v20, v20, v22
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v28
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v11
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v24
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v10
	fmul.4s	v24, v3, v3
	fmul.4s	v20, v24, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v17, v17, v18
	fmov.4s	v23, #1.00000000
	fadd.4s	v3, v3, v23
	sshr.4s	v18, v19, #1
	shl.4s	v20, v18, #23
	add.4s	v20, v20, v23
	fmul.4s	v3, v3, v20
	fadd.4s	v17, v17, v23
	sshr.4s	v20, v8, #1
	shl.4s	v24, v20, #23
	add.4s	v24, v24, v23
	fmul.4s	v17, v17, v24
	sub.4s	v18, v19, v18
	sub.4s	v19, v8, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v23
	fmul.4s	v17, v17, v19
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v23
	fmov.4s	v11, #1.00000000
	fmul.4s	v3, v3, v18
	fcmgt.4s	v18, v26, v9
	bic.16b	v3, v3, v18
	fcmgt.4s	v18, v26, v25
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v25, v14
	ldr	q19, [sp, #2352]                ; 16-byte Reload
	bit.16b	v17, v19, v18
	stp	q25, q17, [sp, #1008]           ; 32-byte Folded Spill
	fcmgt.4s	v17, v9, v14
	bit.16b	v3, v19, v17
	stp	q9, q3, [sp, #288]              ; 32-byte Folded Spill
	ldr	q3, [sp, #1104]                 ; 16-byte Reload
	fsub.4s	v3, v3, v13
	and.16b	v9, v31, v3
	fcmge.4s	v3, v9, v26
	fcmge.4s	v17, v14, v9
	and.16b	v3, v3, v17
	ldr	q17, [sp, #1120]                ; 16-byte Reload
	fsub.4s	v17, v17, v12
	and.16b	v10, v0, v17
	fcmge.4s	v17, v10, v26
	fcmge.4s	v18, v14, v10
	and.16b	v17, v17, v18
	and.16b	v17, v17, v10
	ldr	q23, [sp, #2368]                ; 16-byte Reload
	fmul.4s	v18, v17, v23
	movi.4s	v20, #75, lsl #24
	mvni.4s	v24, #128, lsl #24
	mov.16b	v19, v24
	bsl.16b	v19, v20, v18
	fadd.4s	v18, v18, v19
	fsub.4s	v18, v18, v19
	and.16b	v3, v3, v9
	fmul.4s	v19, v3, v23
	bif.16b	v20, v19, v24
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	fcvtzs.4s	v8, v18
	scvtf.4s	v18, v8
	ldr	q24, [sp, #2384]                ; 16-byte Reload
	fmul.4s	v20, v18, v24
	fsub.4s	v17, v17, v20
	fcvtzs.4s	v23, v19
	scvtf.4s	v20, v23
	fmul.4s	v24, v20, v24
	fsub.4s	v3, v3, v24
	ldr	q13, [sp, #2304]                ; 16-byte Reload
	fmul.4s	v20, v20, v13
	fsub.4s	v3, v3, v20
	fmul.4s	v18, v18, v13
	fsub.4s	v17, v17, v18
	ldr	q12, [sp, #2272]                ; 16-byte Reload
	fmul.4s	v18, v17, v12
	mov.16b	v19, v22
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v17, v18
	mov.16b	v24, v28
	fadd.4s	v18, v18, v28
	fmul.4s	v18, v17, v18
	ldr	q28, [sp, #2192]                ; 16-byte Reload
	fadd.4s	v18, v18, v28
	fmul.4s	v18, v17, v18
	ldr	q22, [sp, #2336]                ; 16-byte Reload
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v17, v18
	movi.4s	v25, #63, lsl #24
	fadd.4s	v18, v18, v25
	fmul.4s	v20, v17, v17
	fmul.4s	v18, v20, v18
	fmul.4s	v20, v3, v12
	fadd.4s	v20, v20, v19
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v24
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v28
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v22
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v25
	fmul.4s	v24, v3, v3
	fmul.4s	v20, v24, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v17, v17, v18
	fadd.4s	v3, v3, v11
	sshr.4s	v18, v23, #1
	shl.4s	v20, v18, #23
	add.4s	v20, v20, v11
	fmul.4s	v3, v3, v20
	fadd.4s	v17, v17, v11
	sshr.4s	v20, v8, #1
	shl.4s	v24, v20, #23
	add.4s	v24, v24, v11
	fmul.4s	v17, v17, v24
	sub.4s	v18, v23, v18
	sub.4s	v19, v8, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v11
	fmul.4s	v17, v17, v19
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v11
	fmul.4s	v3, v3, v18
	str	q9, [sp, #272]                  ; 16-byte Spill
	fcmgt.4s	v18, v26, v9
	bic.16b	v3, v3, v18
	str	q10, [sp, #1120]                ; 16-byte Spill
	fcmgt.4s	v18, v26, v10
	bic.16b	v17, v17, v18
	mov.16b	v23, v14
	fcmgt.4s	v18, v10, v14
	ldr	q8, [sp, #2352]                 ; 16-byte Reload
	mov.16b	v14, v18
	bsl.16b	v14, v8, v17
	fcmgt.4s	v17, v9, v23
	bit.16b	v3, v8, v17
	str	q3, [sp, #1104]                 ; 16-byte Spill
	ldr	q3, [sp, #2160]                 ; 16-byte Reload
	ldr	q17, [sp, #2240]                ; 16-byte Reload
	fsub.4s	v3, v3, v17
	and.16b	v28, v31, v3
	fcmge.4s	v3, v28, v26
	fcmge.4s	v17, v23, v28
	and.16b	v3, v3, v17
	ldr	q17, [sp, #2176]                ; 16-byte Reload
	ldr	q18, [sp, #2224]                ; 16-byte Reload
	fsub.4s	v17, v17, v18
	and.16b	v9, v0, v17
	fcmge.4s	v17, v9, v26
	fcmge.4s	v18, v23, v9
	and.16b	v17, v17, v18
	and.16b	v17, v17, v9
	ldr	q24, [sp, #2368]                ; 16-byte Reload
	fmul.4s	v18, v17, v24
	mvni.4s	v20, #128, lsl #24
	movi.4s	v22, #75, lsl #24
	mov.16b	v19, v20
	bsl.16b	v19, v22, v18
	fadd.4s	v18, v18, v19
	fsub.4s	v18, v18, v19
	and.16b	v3, v3, v28
	fmul.4s	v19, v3, v24
	bsl.16b	v20, v22, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	fcvtzs.4s	v18, v18
	scvtf.4s	v20, v18
	ldr	q22, [sp, #2384]                ; 16-byte Reload
	fmul.4s	v24, v20, v22
	fsub.4s	v17, v17, v24
	fcvtzs.4s	v19, v19
	scvtf.4s	v24, v19
	fmul.4s	v25, v24, v22
	fsub.4s	v3, v3, v25
	fmul.4s	v20, v20, v13
	fmul.4s	v24, v24, v13
	fsub.4s	v3, v3, v24
	fsub.4s	v17, v17, v20
	fmul.4s	v20, v17, v12
	fmul.4s	v24, v3, v12
	ldr	q25, [sp, #2256]                ; 16-byte Reload
	fadd.4s	v24, v24, v25
	fadd.4s	v20, v20, v25
	fmul.4s	v20, v17, v20
	fmul.4s	v24, v3, v24
	ldr	q25, [sp, #2320]                ; 16-byte Reload
	fadd.4s	v24, v24, v25
	fadd.4s	v20, v20, v25
	fmul.4s	v20, v17, v20
	fmul.4s	v24, v3, v24
	ldr	q25, [sp, #2192]                ; 16-byte Reload
	fadd.4s	v24, v24, v25
	fadd.4s	v20, v20, v25
	fmul.4s	v20, v17, v20
	fmul.4s	v24, v3, v24
	ldr	q25, [sp, #2336]                ; 16-byte Reload
	fadd.4s	v24, v24, v25
	fadd.4s	v20, v20, v25
	fmul.4s	v20, v17, v20
	movi.4s	v22, #63, lsl #24
	fadd.4s	v20, v20, v22
	fmul.4s	v25, v17, v17
	fmul.4s	v20, v25, v20
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v22
	fmul.4s	v25, v3, v3
	fmul.4s	v24, v25, v24
	fadd.4s	v3, v3, v24
	fadd.4s	v17, v17, v20
	fadd.4s	v3, v3, v11
	sshr.4s	v20, v19, #1
	shl.4s	v24, v20, #23
	add.4s	v24, v24, v11
	fmul.4s	v3, v3, v24
	fadd.4s	v17, v17, v11
	sshr.4s	v24, v18, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v11
	fmul.4s	v17, v17, v25
	sub.4s	v19, v19, v20
	sub.4s	v18, v18, v24
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v11
	fmul.4s	v17, v17, v18
	shl.4s	v18, v19, #23
	add.4s	v18, v18, v11
	fmul.4s	v3, v3, v18
	fcmgt.4s	v18, v26, v28
	bic.16b	v3, v3, v18
	fcmgt.4s	v18, v26, v9
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v9, v23
	bit.16b	v17, v8, v18
	str	q17, [sp, #256]                 ; 16-byte Spill
	fcmgt.4s	v17, v28, v23
	bit.16b	v3, v8, v17
	str	q3, [sp, #240]                  ; 16-byte Spill
	sshll.2d	v3, v0, #0
	ldr	q17, [sp, #1616]                ; 16-byte Reload
	ldr	q18, [sp, #1840]                ; 16-byte Reload
	bit.16b	v17, v18, v3
	str	q17, [sp, #1616]                ; 16-byte Spill
	ldr	q3, [sp, #1184]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q23, [sp, #128]                 ; 16-byte Reload
	ldr	q17, [sp, #1200]                ; 16-byte Reload
	mov.16b	v11, v3
	bsl.16b	v11, v17, v23
	ldr	q3, [sp, #1232]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q17, [sp, #1216]                ; 16-byte Reload
	mov.16b	v10, v3
	bsl.16b	v10, v17, v23
	ldr	q3, [sp, #1136]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q17, [sp, #1152]                ; 16-byte Reload
	bsl.16b	v3, v17, v23
	ldr	q17, [sp, #1824]                ; 16-byte Reload
	fcmeq.4s	v17, v17, v17
	ldr	q18, [sp, #1168]                ; 16-byte Reload
	bsl.16b	v17, v18, v23
	ldr	q18, [sp, #1040]                ; 16-byte Reload
	fcmeq.4s	v18, v18, v18
	ldr	q19, [sp, #1056]                ; 16-byte Reload
	bsl.16b	v18, v19, v23
	ldr	q19, [sp, #1072]                ; 16-byte Reload
	fcmeq.4s	v19, v19, v19
	ldr	q20, [sp, #1088]                ; 16-byte Reload
	bsl.16b	v19, v20, v23
	ldp	q20, q24, [sp, #944]            ; 32-byte Folded Reload
	fcmeq.4s	v20, v20, v20
	bsl.16b	v20, v24, v23
	ldp	q24, q25, [sp, #976]            ; 32-byte Folded Reload
	fcmeq.4s	v24, v24, v24
	bsl.16b	v24, v25, v23
	ldp	q25, q26, [sp, #848]            ; 32-byte Folded Reload
	fcmeq.4s	v25, v25, v25
	mov.16b	v12, v25
	bsl.16b	v12, v26, v23
	ldp	q25, q26, [sp, #880]            ; 32-byte Folded Reload
	fcmeq.4s	v25, v25, v25
	mov.16b	v8, v25
	bsl.16b	v8, v26, v23
	ldp	q25, q26, [sp, #768]            ; 32-byte Folded Reload
	fcmeq.4s	v25, v25, v25
	mov.16b	v22, v25
	bsl.16b	v22, v26, v23
	str	q22, [sp, #1824]                ; 16-byte Spill
	ldp	q25, q26, [sp, #800]            ; 32-byte Folded Reload
	fcmeq.4s	v25, v25, v25
	mov.16b	v22, v25
	bsl.16b	v22, v26, v23
	str	q22, [sp, #1072]                ; 16-byte Spill
	ldp	q25, q26, [sp, #672]            ; 32-byte Folded Reload
	fcmeq.4s	v25, v25, v25
	mov.16b	v22, v25
	bsl.16b	v22, v26, v23
	str	q22, [sp, #1232]                ; 16-byte Spill
	ldp	q25, q26, [sp, #704]            ; 32-byte Folded Reload
	fcmeq.4s	v25, v25, v25
	mov.16b	v22, v25
	bsl.16b	v22, v26, v23
	str	q22, [sp, #1088]                ; 16-byte Spill
	ldp	q25, q26, [sp, #576]            ; 32-byte Folded Reload
	fcmeq.4s	v25, v25, v25
	mov.16b	v22, v25
	bsl.16b	v22, v26, v23
	str	q22, [sp, #1216]                ; 16-byte Spill
	ldp	q25, q26, [sp, #608]            ; 32-byte Folded Reload
	fcmeq.4s	v25, v25, v25
	mov.16b	v22, v25
	bsl.16b	v22, v26, v23
	str	q22, [sp, #1200]                ; 16-byte Spill
	ldp	q25, q26, [sp, #480]            ; 32-byte Folded Reload
	fcmeq.4s	v25, v25, v25
	mov.16b	v22, v25
	bsl.16b	v22, v26, v23
	str	q22, [sp, #1184]                ; 16-byte Spill
	ldp	q25, q26, [sp, #512]            ; 32-byte Folded Reload
	fcmeq.4s	v25, v25, v25
	mov.16b	v22, v25
	bsl.16b	v22, v26, v23
	str	q22, [sp, #1168]                ; 16-byte Spill
	ldp	q25, q26, [sp, #448]            ; 32-byte Folded Reload
	fcmeq.4s	v25, v25, v25
	mov.16b	v22, v25
	bsl.16b	v22, v26, v23
	str	q22, [sp, #1152]                ; 16-byte Spill
	ldp	q25, q26, [sp, #544]            ; 32-byte Folded Reload
	fcmeq.4s	v25, v25, v25
	mov.16b	v22, v25
	bsl.16b	v22, v26, v23
	str	q22, [sp, #1136]                ; 16-byte Spill
	ldp	q25, q26, [sp, #416]            ; 32-byte Folded Reload
	fcmeq.4s	v25, v25, v25
	mov.16b	v22, v25
	bsl.16b	v22, v26, v23
	ldr	q25, [x3, #528]
	str	q10, [sp, #2368]                ; 16-byte Spill
	bit.16b	v25, v10, v0
	ldr	q10, [x3, #512]
	str	q11, [sp, #2384]                ; 16-byte Spill
	bit.16b	v10, v11, v31
	stp	q10, q25, [x3, #512]
	ldr	d26, [sp, #1248]                ; 8-byte Reload
	zip1.8b	v25, v26, v0
	ushll.4s	v25, v25, #0
	shl.4s	v25, v25, #31
	cmlt.4s	v10, v25, #0
	and.16b	v25, v10, v17
	zip2.8b	v17, v26, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v11, v17, #0
	and.16b	v17, v11, v3
	ldr	q3, [x3, #560]
	str	q17, [sp, #2336]                ; 16-byte Spill
	bit.16b	v3, v17, v0
	ldr	q17, [x3, #544]
	str	q25, [sp, #2352]                ; 16-byte Spill
	bit.16b	v17, v25, v31
	stp	q17, q3, [x3, #544]
	ldp	q3, q17, [sp, #640]             ; 32-byte Folded Reload
	fcmeq.4s	v3, v3, v3
	mov.16b	v26, v3
	bsl.16b	v26, v17, v23
	and.16b	v19, v10, v19
	and.16b	v17, v11, v18
	ldr	q3, [x3, #592]
	str	q17, [sp, #2304]                ; 16-byte Spill
	bit.16b	v3, v17, v0
	ldr	q17, [x3, #576]
	str	q19, [sp, #2320]                ; 16-byte Spill
	bit.16b	v17, v19, v31
	stp	q17, q3, [x3, #576]
	ldp	q3, q17, [sp, #384]             ; 32-byte Folded Reload
	fcmeq.4s	v3, v3, v3
	bsl.16b	v3, v17, v23
	str	q3, [sp, #1056]                 ; 16-byte Spill
	and.16b	v18, v10, v24
	and.16b	v17, v11, v20
	ldr	q3, [x3, #624]
	str	q17, [sp, #2256]                ; 16-byte Spill
	bit.16b	v3, v17, v0
	ldr	q17, [x3, #608]
	str	q18, [sp, #2272]                ; 16-byte Spill
	bit.16b	v17, v18, v31
	stp	q17, q3, [x3, #608]
	ldp	q3, q17, [sp, #736]             ; 32-byte Folded Reload
	fcmeq.4s	v3, v3, v3
	mov.16b	v13, v3
	bsl.16b	v13, v17, v23
	and.16b	v18, v10, v8
	and.16b	v17, v11, v12
	ldr	q3, [x3, #656]
	str	q17, [sp, #1840]                ; 16-byte Spill
	bit.16b	v3, v17, v0
	ldr	q17, [x3, #640]
	str	q18, [sp, #2192]                ; 16-byte Spill
	bit.16b	v17, v18, v31
	stp	q17, q3, [x3, #640]
	ldp	q3, q17, [sp, #352]             ; 32-byte Folded Reload
	fcmeq.4s	v3, v3, v3
	mov.16b	v12, v3
	bsl.16b	v12, v17, v23
	ldr	q3, [sp, #1072]                 ; 16-byte Reload
	and.16b	v18, v10, v3
	ldr	q3, [sp, #1824]                 ; 16-byte Reload
	and.16b	v17, v11, v3
	ldr	q3, [x3, #688]
	str	q17, [sp, #1248]                ; 16-byte Spill
	bit.16b	v3, v17, v0
	ldr	q17, [x3, #672]
	str	q18, [sp, #1824]                ; 16-byte Spill
	bit.16b	v17, v18, v31
	stp	q17, q3, [x3, #672]
	ldr	q3, [sp, #1808]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q17, [sp, #832]                 ; 16-byte Reload
	bsl.16b	v3, v17, v23
	ldr	q17, [sp, #1088]                ; 16-byte Reload
	and.16b	v19, v10, v17
	ldr	q17, [sp, #1232]                ; 16-byte Reload
	and.16b	v18, v11, v17
	ldr	q17, [x3, #720]
	str	q18, [sp, #1232]                ; 16-byte Spill
	bit.16b	v17, v18, v0
	ldr	q18, [x3, #704]
	str	q19, [sp, #1808]                ; 16-byte Spill
	bit.16b	v18, v19, v31
	stp	q18, q17, [x3, #704]
	ldp	q17, q18, [sp, #320]            ; 32-byte Folded Reload
	fcmeq.4s	v17, v17, v17
	bsl.16b	v17, v18, v23
	ldr	q18, [sp, #1200]                ; 16-byte Reload
	and.16b	v20, v10, v18
	ldr	q18, [sp, #1216]                ; 16-byte Reload
	and.16b	v19, v11, v18
	ldr	q18, [x3, #752]
	str	q19, [sp, #1200]                ; 16-byte Spill
	bit.16b	v18, v19, v0
	ldr	q19, [x3, #736]
	str	q20, [sp, #1216]                ; 16-byte Spill
	bit.16b	v19, v20, v31
	stp	q19, q18, [x3, #736]
	ldp	q18, q19, [sp, #912]            ; 32-byte Folded Reload
	fcmeq.4s	v18, v18, v18
	bsl.16b	v18, v19, v23
	ldr	q19, [sp, #1168]                ; 16-byte Reload
	and.16b	v24, v10, v19
	ldr	q19, [sp, #1184]                ; 16-byte Reload
	and.16b	v20, v11, v19
	ldr	q19, [x3, #784]
	str	q20, [sp, #1168]                ; 16-byte Spill
	bit.16b	v19, v20, v0
	ldr	q20, [x3, #768]
	str	q24, [sp, #1184]                ; 16-byte Spill
	bit.16b	v20, v24, v31
	stp	q20, q19, [x3, #768]
	ldp	q19, q20, [sp, #288]            ; 32-byte Folded Reload
	fcmeq.4s	v19, v19, v19
	bsl.16b	v19, v20, v23
	ldr	q20, [sp, #1136]                ; 16-byte Reload
	and.16b	v25, v11, v20
	ldr	q20, [sp, #1152]                ; 16-byte Reload
	and.16b	v24, v10, v20
	ldr	q20, [x3, #800]
	str	q24, [sp, #1136]                ; 16-byte Spill
	bit.16b	v20, v24, v31
	ldr	q24, [x3, #816]
	str	q25, [sp, #1152]                ; 16-byte Spill
	bit.16b	v24, v25, v0
	stp	q20, q24, [x3, #800]
	ldp	q20, q24, [sp, #1008]           ; 32-byte Folded Reload
	fcmeq.4s	v20, v20, v20
	bsl.16b	v20, v24, v23
	and.16b	v26, v11, v26
	and.16b	v22, v10, v22
	ldp	q24, q25, [x3, #832]
	str	q22, [sp, #1088]                ; 16-byte Spill
	bit.16b	v24, v22, v31
	str	q26, [sp, #1072]                ; 16-byte Spill
	bit.16b	v25, v26, v0
	stp	q24, q25, [x3, #832]
	ldr	q24, [sp, #272]                 ; 16-byte Reload
	fcmeq.4s	v24, v24, v24
	ldr	q25, [sp, #1104]                ; 16-byte Reload
	bsl.16b	v24, v25, v23
	and.16b	v22, v11, v13
	ldr	q25, [sp, #1056]                ; 16-byte Reload
	and.16b	v26, v10, v25
	ldp	q25, q8, [x3, #864]
	str	q26, [sp, #1056]                ; 16-byte Spill
	bit.16b	v25, v26, v31
	str	q22, [sp, #1104]                ; 16-byte Spill
	bit.16b	v8, v22, v0
	stp	q25, q8, [x3, #864]
	ldr	q25, [sp, #1120]                ; 16-byte Reload
	fcmeq.4s	v25, v25, v25
	bsl.16b	v25, v14, v23
	and.16b	v26, v11, v3
	and.16b	v22, v10, v12
	ldp	q3, q8, [x3, #896]
	str	q22, [sp, #1120]                ; 16-byte Spill
	bit.16b	v3, v22, v31
	str	q26, [sp, #1040]                ; 16-byte Spill
	bit.16b	v8, v26, v0
	stp	q3, q8, [x3, #896]
	and.16b	v17, v11, v17
	and.16b	v22, v11, v20
	and.16b	v20, v11, v25
	and.16b	v25, v10, v18
	and.16b	v18, v10, v19
	and.16b	v19, v10, v24
	ldr	q3, [x3, #944]
	stp	q22, q17, [sp, #992]            ; 32-byte Folded Spill
	bit.16b	v3, v17, v0
	ldr	q17, [x3, #928]
	stp	q25, q19, [sp, #944]            ; 32-byte Folded Spill
	bit.16b	v17, v25, v31
	stp	q17, q3, [x3, #928]
	ldp	q3, q17, [x3, #960]
	str	q18, [sp, #976]                 ; 16-byte Spill
	bit.16b	v3, v18, v31
	bit.16b	v17, v22, v0
	stp	q3, q17, [x3, #960]
	ldp	q3, q17, [x3, #992]
	bit.16b	v3, v19, v31
	str	q20, [sp, #1024]                ; 16-byte Spill
	bit.16b	v17, v20, v0
	stp	q3, q17, [x3, #992]
	fcmeq.4s	v3, v28, v28
	ldp	q18, q17, [sp, #240]            ; 32-byte Folded Reload
	mov.16b	v8, v3
	bsl.16b	v8, v18, v23
	fcmeq.4s	v3, v9, v9
	mov.16b	v9, v3
	bsl.16b	v9, v17, v23
	sshll2.2d	v18, v31, #0
	ldr	q3, [sp, #1632]                 ; 16-byte Reload
	ldr	q17, [sp, #1264]                ; 16-byte Reload
	str	q18, [sp, #928]                 ; 16-byte Spill
	bit.16b	v3, v17, v18
	str	q3, [sp, #1632]                 ; 16-byte Spill
	sshll.2d	v3, v31, #0
	ldr	q10, [sp, #2576]                ; 16-byte Reload
	ldr	q17, [sp, #2112]                ; 16-byte Reload
	bit.16b	v10, v17, v3
	mov	w10, #12384                     ; =0x3060
	movk	w10, #1, lsl #16
	add	x21, x8, x10
	str	q10, [sp, #2576]                ; 16-byte Spill
LBB1_140:                               ; %direct.true597.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB1_141 Depth 4
	mov	x23, #0                         ; =0x0
	lsl	x10, x28, #7
	dup.2d	v10, x10
	ldr	q23, [sp, #2608]                ; 16-byte Reload
	orr.16b	v3, v10, v23
	fmov	x10, d3
	add	x10, x16, x10
	ldp	q17, q3, [x10]
	fmul.4s	v17, v8, v17
	fmul.4s	v3, v9, v3
	mov	w10, #32                        ; =0x20
	bfi	x10, x28, #7, #57
	dup.2d	v11, x10
	orr.16b	v18, v11, v23
	fmov	x10, d18
	add	x10, x16, x10
	ldp	q19, q18, [x10]
	fmul.4s	v19, v8, v19
	fmul.4s	v18, v9, v18
	mov	w10, #64                        ; =0x40
	bfi	x10, x28, #7, #57
	dup.2d	v12, x10
	orr.16b	v20, v12, v23
	fmov	x10, d20
	add	x10, x16, x10
	ldp	q24, q20, [x10]
	fmul.4s	v24, v8, v24
	fmul.4s	v20, v9, v20
	mov	w10, #96                        ; =0x60
	bfi	x10, x28, #7, #57
	dup.2d	v13, x10
	orr.16b	v25, v13, v23
	fmov	x10, d25
	add	x10, x16, x10
	ldp	q14, q25, [x10]
	fmul.4s	v14, v8, v14
	fmul.4s	v25, v9, v25
	bit.16b	v16, v3, v0
	bit.16b	v1, v17, v31
	bit.16b	v30, v18, v0
	bit.16b	v7, v19, v31
	bit.16b	v6, v20, v0
	bit.16b	v5, v24, v31
	bit.16b	v4, v25, v0
	bit.16b	v15, v14, v31
	mov	x24, x21
LBB1_141:                               ; %direct.true625.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ;       Parent Loop BB1_140 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	add	x10, x7, x23
	ldp	q17, q3, [x10]
	and.16b	v19, v31, v17
	and.16b	v14, v0, v3
	ldp	q17, q3, [x24, #-96]
	and.16b	v17, v31, v17
	and.16b	v3, v0, v3
	fmul.4s	v3, v14, v3
	fmul.4s	v17, v19, v17
	fadd.4s	v20, v1, v17
	fadd.4s	v3, v16, v3
	ldp	q18, q17, [x24, #-64]
	and.16b	v18, v31, v18
	and.16b	v17, v0, v17
	fmul.4s	v17, v14, v17
	fmul.4s	v18, v19, v18
	fadd.4s	v18, v7, v18
	fadd.4s	v25, v30, v17
	ldp	q24, q17, [x24, #-32]
	and.16b	v24, v31, v24
	and.16b	v17, v0, v17
	fmul.4s	v23, v14, v17
	fmul.4s	v17, v19, v24
	fadd.4s	v17, v5, v17
	fadd.4s	v24, v6, v23
	ldp	q26, q23, [x24]
	and.16b	v26, v31, v26
	and.16b	v23, v0, v23
	fmul.4s	v23, v14, v23
	fmul.4s	v19, v19, v26
	fadd.4s	v14, v15, v19
	fadd.4s	v19, v4, v23
	bit.16b	v16, v3, v0
	bit.16b	v1, v20, v31
	bit.16b	v30, v25, v0
	bit.16b	v7, v18, v31
	bit.16b	v6, v24, v0
	bit.16b	v5, v17, v31
	bit.16b	v4, v19, v0
	bit.16b	v15, v14, v31
	add	x23, x23, #32
	add	x24, x24, #1, lsl #12           ; =4096
	cmp	x23, #512
	b.ne	LBB1_141
; %bb.142:                              ; %direct.false626.i.i
                                        ;   in Loop: Header=BB1_140 Depth=3
	ldr	q26, [sp, #2576]                ; 16-byte Reload
	orr.16b	v23, v10, v26
	mov.16b	v10, v26
	fmov	x10, d23
	add	x10, x30, x10
	ldp	q23, q26, [x10]
	bif.16b	v3, v26, v0
	bif.16b	v20, v23, v31
	stp	q20, q3, [x10]
	orr.16b	v3, v11, v10
	fmov	x10, d3
	add	x10, x30, x10
	ldp	q3, q20, [x10]
	bit.16b	v20, v25, v0
	bit.16b	v3, v18, v31
	stp	q3, q20, [x10]
	orr.16b	v3, v12, v10
	fmov	x10, d3
	add	x10, x30, x10
	ldp	q3, q18, [x10]
	bit.16b	v18, v24, v0
	bit.16b	v3, v17, v31
	stp	q3, q18, [x10]
	orr.16b	v3, v13, v10
	fmov	x10, d3
	add	x10, x30, x10
	ldp	q3, q17, [x10]
	bit.16b	v17, v19, v0
	bit.16b	v3, v14, v31
	stp	q3, q17, [x10]
	add	x28, x28, #1
	add	x21, x21, #128
	cmp	x28, #32
	b.ne	LBB1_140
; %bb.143:                              ; %direct.true692.i.i.preheader
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x10, #0                         ; =0x0
	ldr	q20, [sp, #2608]                ; 16-byte Reload
LBB1_144:                               ; %direct.true692.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	d3, x10
	orr.16b	v17, v3, v10
	fmov	x11, d17
	add	x11, x30, x11
	ldp	q17, q18, [x11]
	orr.16b	v3, v3, v20
	fmov	x11, d3
	add	x11, x4, x11
	ldp	q3, q19, [x11]
	bif.16b	v18, v19, v0
	bit.16b	v3, v17, v31
	stp	q3, q18, [x11]
	add	x10, x10, #32
	cmp	x10, #1, lsl #12                ; =4096
	b.ne	LBB1_144
; %bb.145:                              ; %direct.true708.i.i.preheader
                                        ;   in Loop: Header=BB1_40 Depth=2
	add	x10, x8, #1, lsl #12            ; =4096
	mov	w11, #128                       ; =0x80
	ldr	q25, [sp, #192]                 ; 16-byte Reload
	ldr	q20, [sp, #1376]                ; 16-byte Reload
	ldr	q24, [sp, #1360]                ; 16-byte Reload
	ldr	q11, [sp, #2144]                ; 16-byte Reload
	ldr	q13, [sp, #1344]                ; 16-byte Reload
	ldr	q26, [sp, #2208]                ; 16-byte Reload
	ldr	q14, [sp, #1888]                ; 16-byte Reload
	ldr	q12, [sp, #1280]                ; 16-byte Reload
	ldr	q23, [sp, #2128]                ; 16-byte Reload
	ldr	q22, [sp, #1872]                ; 16-byte Reload
	ldr	q28, [sp, #1856]                ; 16-byte Reload
LBB1_146:                               ; %direct.true708.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x10, #4096]
	ldr	q17, [x10, #4112]
	ldp	q18, q19, [x10]
	bif.16b	v17, v19, v0
	bif.16b	v3, v18, v31
	stp	q3, q17, [x10], #32
	subs	x11, x11, #1
	b.ne	LBB1_146
; %bb.147:                              ; %direct.false709.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2176]                 ; 16-byte Reload
	ldr	q17, [sp, #2224]                ; 16-byte Reload
	bit.16b	v3, v17, v0
	str	q3, [sp, #2176]                 ; 16-byte Spill
	ldr	q3, [sp, #2160]                 ; 16-byte Reload
	ldr	q17, [sp, #2240]                ; 16-byte Reload
	bit.16b	v3, v17, v31
	str	q3, [sp, #2160]                 ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	ldr	q3, [sp, #2384]                 ; 16-byte Reload
	fadd.4s	v3, v3, v17
	ldr	q18, [sp, #2352]                ; 16-byte Reload
	fadd.4s	v3, v3, v18
	ldr	q18, [sp, #2368]                ; 16-byte Reload
	fadd.4s	v17, v18, v17
	ldr	q18, [sp, #2336]                ; 16-byte Reload
	fadd.4s	v17, v17, v18
	ldr	q18, [sp, #2304]                ; 16-byte Reload
	fadd.4s	v17, v18, v17
	ldr	q18, [sp, #2320]                ; 16-byte Reload
	fadd.4s	v3, v18, v3
	ldr	q18, [sp, #2272]                ; 16-byte Reload
	fadd.4s	v3, v18, v3
	ldr	q18, [sp, #2256]                ; 16-byte Reload
	fadd.4s	v17, v18, v17
	ldr	q18, [sp, #1840]                ; 16-byte Reload
	fadd.4s	v17, v18, v17
	ldr	q18, [sp, #2192]                ; 16-byte Reload
	fadd.4s	v3, v18, v3
	ldr	q18, [sp, #1824]                ; 16-byte Reload
	fadd.4s	v3, v18, v3
	ldr	q18, [sp, #1248]                ; 16-byte Reload
	fadd.4s	v17, v18, v17
	ldr	q18, [sp, #1232]                ; 16-byte Reload
	fadd.4s	v17, v18, v17
	ldr	q18, [sp, #1808]                ; 16-byte Reload
	fadd.4s	v3, v18, v3
	ldr	q18, [sp, #1216]                ; 16-byte Reload
	fadd.4s	v3, v18, v3
	ldr	q18, [sp, #1200]                ; 16-byte Reload
	fadd.4s	v17, v18, v17
	ldr	q18, [sp, #1168]                ; 16-byte Reload
	fadd.4s	v17, v18, v17
	ldr	q18, [sp, #1184]                ; 16-byte Reload
	fadd.4s	v3, v18, v3
	ldr	q18, [sp, #1136]                ; 16-byte Reload
	fadd.4s	v3, v18, v3
	ldr	q18, [sp, #1152]                ; 16-byte Reload
	fadd.4s	v17, v18, v17
	ldr	q18, [sp, #1072]                ; 16-byte Reload
	fadd.4s	v17, v18, v17
	ldr	q18, [sp, #1088]                ; 16-byte Reload
	fadd.4s	v3, v18, v3
	ldr	q18, [sp, #1056]                ; 16-byte Reload
	fadd.4s	v3, v18, v3
	ldr	q18, [sp, #1104]                ; 16-byte Reload
	fadd.4s	v17, v18, v17
	ldr	q18, [sp, #1040]                ; 16-byte Reload
	fadd.4s	v17, v18, v17
	ldr	q18, [sp, #1120]                ; 16-byte Reload
	fadd.4s	v3, v18, v3
	ldr	q18, [sp, #944]                 ; 16-byte Reload
	fadd.4s	v3, v18, v3
	ldp	q18, q19, [sp, #992]            ; 32-byte Folded Reload
	fadd.4s	v17, v19, v17
	fadd.4s	v17, v18, v17
	ldp	q18, q19, [sp, #960]            ; 32-byte Folded Reload
	fadd.4s	v3, v19, v3
	fadd.4s	v3, v18, v3
	ldr	q18, [sp, #1024]                ; 16-byte Reload
	fadd.4s	v17, v18, v17
	fmul.4s	v18, v20, v8
	fmul.4s	v19, v24, v9
	fadd.4s	v17, v19, v17
	fadd.4s	v3, v18, v3
	bit.16b	v20, v3, v31
	bit.16b	v24, v17, v0
	add	x19, x19, #1
	cmp	x19, #513
	ldr	q9, [sp, #2288]                 ; 16-byte Reload
	b.ne	LBB1_40
; %bb.148:                              ; %direct.schedule.51.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x8, #0                          ; =0x0
	sshll.2d	v4, v31, #0
	sshll.2d	v3, v0, #0
	ldr	q1, [sp, #48]                   ; 16-byte Reload
	ldr	q2, [sp, #928]                  ; 16-byte Reload
	and.16b	v1, v2, v1
	ldr	q2, [sp, #16]                   ; 16-byte Reload
	ldr	q5, [sp, #2624]                 ; 16-byte Reload
	and.16b	v2, v5, v2
	ldr	q5, [sp, #32]                   ; 16-byte Reload
	and.16b	v3, v3, v5
	ldr	q5, [sp, #64]                   ; 16-byte Reload
	and.16b	v4, v4, v5
	b	LBB1_150
LBB1_149:                               ; %else546
                                        ;   in Loop: Header=BB1_150 Depth=2
	add	x8, x8, #1
	cmp	x8, #128
	b.eq	LBB1_2
LBB1_150:                               ; %direct.true777.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	uzp1.8h	v5, v31, v0
	ldr	q6, [x26, lCPI1_6@PAGEOFF]
	and.16b	v5, v5, v6
	addv.8h	h5, v5
	fmov	w9, s5
	dup.2d	v5, x8
	add.2d	v6, v5, v4
	add	x10, x16, x8, lsl #5
	ldp	q16, q7, [x10]
	and.16b	v16, v31, v16
	fdiv.4s	v16, v16, v20
	shl.2d	v17, v6, #2
	dup.2d	v6, x14
	add.2d	v17, v6, v17
	tbz	w9, #0, LBB1_158
; %bb.151:                              ; %cond.store
                                        ;   in Loop: Header=BB1_150 Depth=2
	fmov	x10, d17
	str	s16, [x10]
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_159
LBB1_152:                               ; %else528
                                        ;   in Loop: Header=BB1_150 Depth=2
	add.2d	v17, v5, v1
	shl.2d	v17, v17, #2
	add.2d	v17, v6, v17
	tbz	w9, #2, LBB1_160
LBB1_153:                               ; %cond.store529
                                        ;   in Loop: Header=BB1_150 Depth=2
	fmov	x10, d17
	st1.s	{ v16 }[2], [x10]
	tbnz	w9, #3, LBB1_161
LBB1_154:                               ; %else534
                                        ;   in Loop: Header=BB1_150 Depth=2
	add.2d	v16, v5, v3
	and.16b	v7, v0, v7
	fdiv.4s	v7, v7, v24
	shl.2d	v16, v16, #2
	add.2d	v16, v6, v16
	tbz	w9, #4, LBB1_162
LBB1_155:                               ; %cond.store535
                                        ;   in Loop: Header=BB1_150 Depth=2
	fmov	x10, d16
	str	s7, [x10]
	tbnz	w9, #5, LBB1_163
LBB1_156:                               ; %else540
                                        ;   in Loop: Header=BB1_150 Depth=2
	add.2d	v5, v5, v2
	shl.2d	v5, v5, #2
	add.2d	v5, v6, v5
	tbz	w9, #6, LBB1_164
LBB1_157:                               ; %cond.store541
                                        ;   in Loop: Header=BB1_150 Depth=2
	fmov	x10, d5
	st1.s	{ v7 }[2], [x10]
	tbz	w9, #7, LBB1_149
	b	LBB1_165
LBB1_158:                               ; %else525
                                        ;   in Loop: Header=BB1_150 Depth=2
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_152
LBB1_159:                               ; %cond.store526
                                        ;   in Loop: Header=BB1_150 Depth=2
	mov.d	x10, v17[1]
	st1.s	{ v16 }[1], [x10]
	add.2d	v17, v5, v1
	shl.2d	v17, v17, #2
	add.2d	v17, v6, v17
	tbnz	w9, #2, LBB1_153
LBB1_160:                               ; %else531
                                        ;   in Loop: Header=BB1_150 Depth=2
	tbz	w9, #3, LBB1_154
LBB1_161:                               ; %cond.store532
                                        ;   in Loop: Header=BB1_150 Depth=2
	mov.d	x10, v17[1]
	st1.s	{ v16 }[3], [x10]
	add.2d	v16, v5, v3
	and.16b	v7, v0, v7
	fdiv.4s	v7, v7, v24
	shl.2d	v16, v16, #2
	add.2d	v16, v6, v16
	tbnz	w9, #4, LBB1_155
LBB1_162:                               ; %else537
                                        ;   in Loop: Header=BB1_150 Depth=2
	tbz	w9, #5, LBB1_156
LBB1_163:                               ; %cond.store538
                                        ;   in Loop: Header=BB1_150 Depth=2
	mov.d	x10, v16[1]
	st1.s	{ v7 }[1], [x10]
	add.2d	v5, v5, v2
	shl.2d	v5, v5, #2
	add.2d	v5, v6, v5
	tbnz	w9, #6, LBB1_157
LBB1_164:                               ; %else543
                                        ;   in Loop: Header=BB1_150 Depth=2
	tbz	w9, #7, LBB1_149
LBB1_165:                               ; %cond.store544
                                        ;   in Loop: Header=BB1_150 Depth=2
	mov.d	x9, v5[1]
	st1.s	{ v7 }[3], [x9]
	b	LBB1_149
LBB1_166:                               ; %block.batch.exit
	add	sp, sp, #2720
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
                                        ; -- End function
.subsections_via_symbols

; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_attention(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 1024, i64 2048, i64 3072, i64 4096, i64 5120, i64 6144, i64 7168>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 8192
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 20480
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 32768
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 2048, i64 4096, i64 6144, i64 8192, i64 10240, i64 12288, i64 14336>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 49152
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 3072, i64 6144, i64 9216, i64 12288, i64 15360, i64 18432, i64 21504>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 73728
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 512, i64 1024, i64 1536, i64 2048, i64 2560, i64 3072, i64 3584>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 77824
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 512, i64 1024, i64 1536, i64 2048, i64 2560, i64 3072, i64 3584>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 81920
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 16, i64 32, i64 48, i64 64, i64 80, i64 96, i64 112>, 1
  %24 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace29 = load ptr, ptr %24, align 8
  %tile_snapshot.private30 = getelementptr inbounds i8, ptr %private.workspace29, i64 82048
  %.splatinsert31 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private30, i64 0
  %.splat32 = shufflevector <8 x ptr> %.splatinsert31, <8 x ptr> poison, <8 x i32> zeroinitializer
  %25 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat32, 0
  %26 = insertvalue { <8 x ptr>, <8 x i64> } %25, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %27 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace33 = load ptr, ptr %27, align 8
  %tile_snapshot.private34 = getelementptr inbounds i8, ptr %private.workspace33, i64 83072
  %.splatinsert35 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private34, i64 0
  %.splat36 = shufflevector <8 x ptr> %.splatinsert35, <8 x ptr> poison, <8 x i32> zeroinitializer
  %28 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat36, 0
  %29 = insertvalue { <8 x ptr>, <8 x i64> } %28, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %30 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace37 = load ptr, ptr %30, align 8
  %tile_snapshot.private38 = getelementptr inbounds i8, ptr %private.workspace37, i64 83584
  %.splatinsert39 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private38, i64 0
  %.splat40 = shufflevector <8 x ptr> %.splatinsert39, <8 x ptr> poison, <8 x i32> zeroinitializer
  %31 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat40, 0
  %32 = insertvalue { <8 x ptr>, <8 x i64> } %31, <8 x i64> <i64 0, i64 128, i64 256, i64 384, i64 512, i64 640, i64 768, i64 896>, 1
  %33 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace41 = load ptr, ptr %33, align 8
  %tile_snapshot.private42 = getelementptr inbounds i8, ptr %private.workspace41, i64 84608
  %.splatinsert43 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private42, i64 0
  %.splat44 = shufflevector <8 x ptr> %.splatinsert43, <8 x ptr> poison, <8 x i32> zeroinitializer
  %34 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat44, 0
  %35 = insertvalue { <8 x ptr>, <8 x i64> } %34, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %36 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace45 = load ptr, ptr %36, align 8
  %tile_snapshot.private46 = getelementptr inbounds i8, ptr %private.workspace45, i64 88704
  %.splatinsert47 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private46, i64 0
  %.splat48 = shufflevector <8 x ptr> %.splatinsert47, <8 x ptr> poison, <8 x i32> zeroinitializer
  %37 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat48, 0
  %38 = insertvalue { <8 x ptr>, <8 x i64> } %37, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %39 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace49 = load ptr, ptr %39, align 8
  %tile_snapshot.private50 = getelementptr inbounds i8, ptr %private.workspace49, i64 88960
  %.splatinsert51 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private50, i64 0
  %.splat52 = shufflevector <8 x ptr> %.splatinsert51, <8 x ptr> poison, <8 x i32> zeroinitializer
  %40 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat52, 0
  %41 = insertvalue { <8 x ptr>, <8 x i64> } %40, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %42 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace53 = load ptr, ptr %42, align 8
  %tile_snapshot.private54 = getelementptr inbounds i8, ptr %private.workspace53, i64 89216
  %.splatinsert55 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private54, i64 0
  %.splat56 = shufflevector <8 x ptr> %.splatinsert55, <8 x ptr> poison, <8 x i32> zeroinitializer
  %43 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat56, 0
  %44 = insertvalue { <8 x ptr>, <8 x i64> } %43, <8 x i64> <i64 0, i64 512, i64 1024, i64 1536, i64 2048, i64 2560, i64 3072, i64 3584>, 1
  %45 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace57 = load ptr, ptr %45, align 8
  %tile_snapshot.private58 = getelementptr inbounds i8, ptr %private.workspace57, i64 93312
  %.splatinsert59 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private58, i64 0
  %.splat60 = shufflevector <8 x ptr> %.splatinsert59, <8 x ptr> poison, <8 x i32> zeroinitializer
  %46 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat60, 0
  %47 = insertvalue { <8 x ptr>, <8 x i64> } %46, <8 x i64> <i64 0, i64 1536, i64 3072, i64 4608, i64 6144, i64 7680, i64 9216, i64 10752>, 1
  %48 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace61 = load ptr, ptr %48, align 8
  %tile_snapshot.private62 = getelementptr inbounds i8, ptr %private.workspace61, i64 105600
  %.splatinsert63 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private62, i64 0
  %.splat64 = shufflevector <8 x ptr> %.splatinsert63, <8 x ptr> poison, <8 x i32> zeroinitializer
  %49 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat64, 0
  %50 = insertvalue { <8 x ptr>, <8 x i64> } %49, <8 x i64> <i64 0, i64 1536, i64 3072, i64 4608, i64 6144, i64 7680, i64 9216, i64 10752>, 1
  %51 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace65 = load ptr, ptr %51, align 8
  %tile_snapshot.private66 = getelementptr inbounds i8, ptr %private.workspace65, i64 117888
  %.splatinsert67 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private66, i64 0
  %.splat68 = shufflevector <8 x ptr> %.splatinsert67, <8 x ptr> poison, <8 x i32> zeroinitializer
  %52 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat68, 0
  %53 = insertvalue { <8 x ptr>, <8 x i64> } %52, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill69 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill69, align 64
  %.spill70 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill70, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.spill71 = alloca i64, align 8
  store i64 0, ptr %.spill71, align 4
  %.spill72 = alloca i64, align 8
  store i64 0, ptr %.spill72, align 4
  %tile_snapshot.spill73 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill73, align 64
  %tile_snapshot.spill74 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill74, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.slot75 = alloca i64, align 8
  store i64 0, ptr %.slot75, align 4
  %.slot76 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot76, align 32
  %.slot77 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot77, align 32
  %.slot78 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot78, align 32
  %.slot79 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot79, align 32
  %.slot80 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot80, align 32
  %.slot81 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot81, align 32
  %.slot82 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot82, align 32
  %.slot83 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot83, align 32
  %.slot84 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot84, align 32
  %.slot85 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot85, align 32
  %.slot86 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot86, align 32
  %.slot87 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot87, align 32
  %.slot88 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot88, align 32
  %.slot89 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot89, align 32
  %.slot90 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot90, align 32
  %.slot91 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot91, align 32
  %.spill92 = alloca i64, align 8
  store i64 0, ptr %.spill92, align 4
  %tile_snapshot.spill93 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill93, align 64
  %.spill94 = alloca i1, align 1
  store i1 false, ptr %.spill94, align 1
  %tile_snapshot.spill95 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill95, align 64
  %tile_snapshot.spill96 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill96, align 64
  %.slot97 = alloca i64, align 8
  store i64 0, ptr %.slot97, align 4
  %tile_snapshot.spill98 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill98, align 64
  %tile_snapshot.spill99 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill99, align 64
  %tile_snapshot.spill100 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill100, align 64
  %tile_snapshot.spill101 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill101, align 64
  %tile_snapshot.spill102 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill102, align 64
  %.slot103 = alloca i64, align 8
  store i64 0, ptr %.slot103, align 4
  %tile_snapshot.spill104 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill104, align 64
  %.slot105 = alloca i64, align 8
  store i64 0, ptr %.slot105, align 4
  %.slot106 = alloca i64, align 8
  store i64 0, ptr %.slot106, align 4
  %.slot107 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot107, align 32
  %.slot108 = alloca i64, align 8
  store i64 0, ptr %.slot108, align 4
  %.slot109 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot109, align 32
  %.slot110 = alloca i64, align 8
  store i64 0, ptr %.slot110, align 4
  %.slot111 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot111, align 32
  %.slot112 = alloca i64, align 8
  store i64 0, ptr %.slot112, align 4
  %.slot113 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot113, align 32
  %.slot114 = alloca i64, align 8
  store i64 0, ptr %.slot114, align 4
  %.slot115 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot115, align 32
  %.slot116 = alloca i64, align 8
  store i64 0, ptr %.slot116, align 4
  %.slot117 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot117, align 32
  %.slot118 = alloca i64, align 8
  store i64 0, ptr %.slot118, align 4
  %.slot119 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot119, align 32
  %.slot120 = alloca i64, align 8
  store i64 0, ptr %.slot120, align 4
  %.slot121 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot121, align 32
  %.spill122 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill122, align 32
  %.spill123 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill123, align 32
  %.spill124 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill124, align 32
  %.spill125 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill125, align 32
  %.spill126 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill126, align 32
  %.spill127 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill127, align 32
  %.spill128 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill128, align 32
  %.spill129 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill129, align 32
  %tile_snapshot.spill130 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill130, align 64
  %.spill131 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill131, align 32
  %.spill132 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill132, align 32
  %.spill133 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill133, align 32
  %.spill134 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill134, align 32
  %.spill135 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill135, align 32
  %.spill136 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill136, align 32
  %.spill137 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill137, align 32
  %.spill138 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill138, align 32
  %tile_snapshot.spill139 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill139, align 64
  %tile_snapshot.spill140 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill140, align 64
  %.slot141 = alloca i64, align 8
  store i64 0, ptr %.slot141, align 4
  %.spill142 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill142, align 32
  %.spill143 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill143, align 32
  %.spill144 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill144, align 32
  %.spill145 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill145, align 32
  %.spill146 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill146, align 32
  %.spill147 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill147, align 32
  %.spill148 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill148, align 32
  %.spill149 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill149, align 32
  %.slot150 = alloca i64, align 8
  store i64 0, ptr %.slot150, align 4
  %.slot151 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot151, align 32
  %.slot152 = alloca i64, align 8
  store i64 0, ptr %.slot152, align 4
  %.slot153 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot153, align 32
  %.slot154 = alloca i64, align 8
  store i64 0, ptr %.slot154, align 4
  %.slot155 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot155, align 32
  %.slot156 = alloca i64, align 8
  store i64 0, ptr %.slot156, align 4
  %.slot157 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot157, align 32
  %.slot158 = alloca i64, align 8
  store i64 0, ptr %.slot158, align 4
  %.slot159 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot159, align 32
  %.slot160 = alloca i64, align 8
  store i64 0, ptr %.slot160, align 4
  %.slot161 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot161, align 32
  %.slot162 = alloca i64, align 8
  store i64 0, ptr %.slot162, align 4
  %.slot163 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot163, align 32
  %.slot164 = alloca i64, align 8
  store i64 0, ptr %.slot164, align 4
  %.slot165 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot165, align 32
  %.spill166 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill166, align 32
  %.spill167 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill167, align 32
  %.spill168 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill168, align 32
  %.spill169 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill169, align 32
  %.spill170 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill170, align 32
  %.spill171 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill171, align 32
  %.spill172 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill172, align 32
  %.spill173 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill173, align 32
  %tile_snapshot.spill174 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill174, align 64
  %.slot175 = alloca i64, align 8
  store i64 0, ptr %.slot175, align 4
  %tile_snapshot.spill176 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill176, align 64
  %.slot177 = alloca i64, align 8
  store i64 0, ptr %.slot177, align 4
  %.slot178 = alloca i64, align 8
  store i64 0, ptr %.slot178, align 4
  %.slot179 = alloca i64, align 8
  store i64 0, ptr %.slot179, align 4
  %.spill180 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill180, align 64
  %.slot181 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot181, align 32
  %.slot182 = alloca i64, align 8
  store i64 0, ptr %.slot182, align 4
  %.spill183 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill183, align 64
  %.slot184 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot184, align 32
  %tile_snapshot.spill185 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill185, align 64
  %.slot186 = alloca i64, align 8
  store i64 0, ptr %.slot186, align 4
  %54 = getelementptr i8, ptr %argument_buffer, i64 0
  %55 = load ptr, ptr %54, align 16
  %56 = getelementptr i8, ptr %54, i64 8
  %57 = load i64, ptr %56, align 8
  %58 = insertvalue { ptr, i64 } poison, ptr %55, 0
  %59 = insertvalue { ptr, i64 } %58, i64 %57, 1
  %60 = getelementptr i8, ptr %argument_buffer, i64 16
  %61 = load ptr, ptr %60, align 16
  %62 = getelementptr i8, ptr %60, i64 8
  %63 = load i64, ptr %62, align 8
  %64 = insertvalue { ptr, i64 } poison, ptr %61, 0
  %65 = insertvalue { ptr, i64 } %64, i64 %63, 1
  %66 = getelementptr i8, ptr %argument_buffer, i64 32
  %67 = load ptr, ptr %66, align 16
  %68 = getelementptr i8, ptr %66, i64 8
  %69 = load i64, ptr %68, align 8
  %70 = insertvalue { ptr, i64 } poison, ptr %67, 0
  %71 = insertvalue { ptr, i64 } %70, i64 %69, 1
  %72 = getelementptr i8, ptr %argument_buffer, i64 48
  %73 = load ptr, ptr %72, align 16
  %74 = getelementptr i8, ptr %72, i64 8
  %75 = load i64, ptr %74, align 8
  %76 = insertvalue { ptr, i64 } poison, ptr %73, 0
  %77 = insertvalue { ptr, i64 } %76, i64 %75, 1
  %78 = load i32, ptr %launch_config, align 4
  %79 = getelementptr i8, ptr %launch_config, i64 12
  %80 = load i32, ptr %79, align 4
  %81 = getelementptr i8, ptr %launch_config, i64 4
  %82 = load i32, ptr %81, align 4
  %83 = getelementptr i8, ptr %launch_config, i64 16
  %84 = load i32, ptr %83, align 4
  %85 = getelementptr i8, ptr %launch_config, i64 8
  %86 = load i32, ptr %85, align 4
  %87 = getelementptr i8, ptr %launch_config, i64 20
  %88 = load i32, ptr %87, align 4
  %89 = getelementptr i8, ptr %launch_config, i64 36
  %90 = load i32, ptr %89, align 4
  %.splatinsert187 = insertelement <8 x i32> poison, i32 %90, i64 0
  %.splat188 = shufflevector <8 x i32> %.splatinsert187, <8 x i32> poison, <8 x i32> zeroinitializer
  %91 = add <8 x i32> %.splat188, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %92 = mul i32 %78, 32
  %.splatinsert189 = insertelement <8 x i32> poison, i32 %92, i64 0
  %.splat190 = shufflevector <8 x i32> %.splatinsert189, <8 x i32> poison, <8 x i32> zeroinitializer
  %93 = add <8 x i32> %.splat190, %91
  %94 = mul i32 %82, 1
  %.splatinsert191 = insertelement <8 x i32> poison, i32 %94, i64 0
  %.splat192 = shufflevector <8 x i32> %.splatinsert191, <8 x i32> poison, <8 x i32> zeroinitializer
  %95 = add <8 x i32> %.splat192, zeroinitializer
  %96 = mul i32 %86, 1
  %.splatinsert193 = insertelement <8 x i32> poison, i32 %96, i64 0
  %.splat194 = shufflevector <8 x i32> %.splatinsert193, <8 x i32> poison, <8 x i32> zeroinitializer
  %97 = add <8 x i32> %.splat194, zeroinitializer
  %98 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %93, 0
  %99 = insertvalue [3 x <8 x i32>] %98, <8 x i32> %95, 1
  %100 = insertvalue [3 x <8 x i32>] %99, <8 x i32> %97, 2
  %.splatinsert195 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat196 = shufflevector <8 x i32> %.splatinsert195, <8 x i32> poison, <8 x i32> zeroinitializer
  %101 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat196
  %102 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  br i1 %102, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %103 = extractvalue [3 x <8 x i32>] %100, 0
  %104 = zext <8 x i32> %103 to <8 x i64>
  %105 = select <8 x i1> %101, <8 x i64> %104, <8 x i64> zeroinitializer
  %106 = select <8 x i1> %101, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %107 = sdiv <8 x i64> %105, %106
  %108 = load <8 x i64>, ptr %.spill, align 64
  %109 = select <8 x i1> %101, <8 x i64> %107, <8 x i64> %108
  store <8 x i64> %109, ptr %.spill, align 64
  %110 = select <8 x i1> %101, <8 x i64> %104, <8 x i64> zeroinitializer
  %111 = select <8 x i1> %101, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %112 = sdiv <8 x i64> %110, %111
  %113 = select <8 x i1> %101, <8 x i64> %112, <8 x i64> zeroinitializer
  %114 = select <8 x i1> %101, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %115 = srem <8 x i64> %113, %114
  %116 = mul <8 x i64> %115, splat (i64 8)
  %117 = load <8 x i64>, ptr %.spill69, align 64
  %118 = select <8 x i1> %101, <8 x i64> %116, <8 x i64> %117
  store <8 x i64> %118, ptr %.spill69, align 64
  %119 = select <8 x i1> %101, <8 x i64> %107, <8 x i64> zeroinitializer
  %120 = select <8 x i1> %101, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %121 = sdiv <8 x i64> %119, %120
  %122 = load <8 x i64>, ptr %.spill70, align 64
  %123 = select <8 x i1> %101, <8 x i64> %121, <8 x i64> %122
  store <8 x i64> %123, ptr %.spill70, align 64
  %124 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %124, 0
  %127 = select <8 x i1> %101, <8 x ptr> %125, <8 x ptr> %126
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %124, 1
  %130 = select <8 x i1> %101, <8 x i64> %128, <8 x i64> %129
  %131 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %127, 0
  %132 = insertvalue { <8 x ptr>, <8 x i64> } %131, <8 x i64> %130, 1
  store { <8 x ptr>, <8 x i64> } %132, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.spill71, align 4
  store i64 0, ptr %.spill72, align 4
  %133 = add <8 x i64> zeroinitializer, %107
  %134 = mul <8 x i64> %133, splat (i64 64)
  %135 = add <8 x i64> %134, %116
  %136 = mul <8 x i64> %135, splat (i64 32)
  %137 = add <8 x i64> %136, zeroinitializer
  %138 = extractvalue { ptr, i64 } %59, 0
  %139 = extractelement <8 x i1> %101, i64 0
  br i1 %139, label %copy.active, label %copy.continue

direct.schedule.1:                                ; preds = %direct.schedule.2, %copy.continue210
  %.state = load i64, ptr %.slot, align 4
  %140 = icmp slt i64 %.state, 384
  br i1 %140, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill73, align 64
  %141 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state211 = load i64, ptr %.slot, align 4
  %.splatinsert212 = insertelement <8 x i64> poison, i64 %.state211, i64 0
  %.splat213 = shufflevector <8 x i64> %.splatinsert212, <8 x i64> poison, <8 x i32> zeroinitializer
  %143 = mul <8 x i64> %.splat213, splat (i64 32)
  %144 = add <8 x i64> %142, %143
  %145 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %141, 0
  %146 = insertvalue { <8 x ptr>, <8 x i64> } %145, <8 x i64> %144, 1
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %148 = extractvalue { <8 x ptr>, <8 x i64> } %146, 1
  %149 = extractelement <8 x ptr> %147, i32 0
  %150 = extractelement <8 x i64> %148, i32 0
  %151 = sub i64 %150, 0
  %152 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %153 = select i1 %152, i64 %151, i64 0
  %private.contiguous.address = getelementptr i8, ptr %149, i64 %153
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %154 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %private.contiguous.preserve
  store <8 x float> %154, ptr %private.contiguous.address, align 4
  %.state214 = load i64, ptr %.slot, align 4
  %155 = add i64 %.state214, 1
  store i64 %155, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store i64 0, ptr %.slot75, align 4
  %156 = load <8 x float>, ptr %.slot76, align 32
  %157 = select <8 x i1> %101, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %156
  store <8 x float> %157, ptr %.slot76, align 32
  %158 = load <8 x float>, ptr %.slot77, align 32
  %159 = select <8 x i1> %101, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %158
  store <8 x float> %159, ptr %.slot77, align 32
  %160 = load <8 x float>, ptr %.slot78, align 32
  %161 = select <8 x i1> %101, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %160
  store <8 x float> %161, ptr %.slot78, align 32
  %162 = load <8 x float>, ptr %.slot79, align 32
  %163 = select <8 x i1> %101, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %162
  store <8 x float> %163, ptr %.slot79, align 32
  %164 = load <8 x float>, ptr %.slot80, align 32
  %165 = select <8 x i1> %101, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %164
  store <8 x float> %165, ptr %.slot80, align 32
  %166 = load <8 x float>, ptr %.slot81, align 32
  %167 = select <8 x i1> %101, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %166
  store <8 x float> %167, ptr %.slot81, align 32
  %168 = load <8 x float>, ptr %.slot82, align 32
  %169 = select <8 x i1> %101, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %168
  store <8 x float> %169, ptr %.slot82, align 32
  %170 = load <8 x float>, ptr %.slot83, align 32
  %171 = select <8 x i1> %101, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %170
  store <8 x float> %171, ptr %.slot83, align 32
  %172 = load <8 x float>, ptr %.slot84, align 32
  %173 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %172
  store <8 x float> %173, ptr %.slot84, align 32
  %174 = load <8 x float>, ptr %.slot85, align 32
  %175 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %174
  store <8 x float> %175, ptr %.slot85, align 32
  %176 = load <8 x float>, ptr %.slot86, align 32
  %177 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %176
  store <8 x float> %177, ptr %.slot86, align 32
  %178 = load <8 x float>, ptr %.slot87, align 32
  %179 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %178
  store <8 x float> %179, ptr %.slot87, align 32
  %180 = load <8 x float>, ptr %.slot88, align 32
  %181 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %180
  store <8 x float> %181, ptr %.slot88, align 32
  %182 = load <8 x float>, ptr %.slot89, align 32
  %183 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %182
  store <8 x float> %183, ptr %.slot89, align 32
  %184 = load <8 x float>, ptr %.slot90, align 32
  %185 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %184
  store <8 x float> %185, ptr %.slot90, align 32
  %186 = load <8 x float>, ptr %.slot91, align 32
  %187 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %186
  store <8 x float> %187, ptr %.slot91, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.78, %direct.schedule.3
  %.state215 = load i64, ptr %.slot75, align 4
  %188 = icmp slt i64 %.state215, 9
  br i1 %188, label %direct.true216, label %direct.false217

direct.schedule.5:                                ; preds = %direct.true216
  %.state218 = load i64, ptr %.slot75, align 4
  %189 = sdiv i64 %.state218, 1
  %190 = mul i64 %189, 16
  store i64 %190, ptr %.spill92, align 4
  %191 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill93, align 64
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %191, 0
  %194 = select <8 x i1> %101, <8 x ptr> %192, <8 x ptr> %193
  %195 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %196 = extractvalue { <8 x ptr>, <8 x i64> } %191, 1
  %197 = select <8 x i1> %101, <8 x i64> %195, <8 x i64> %196
  %198 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %194, 0
  %199 = insertvalue { <8 x ptr>, <8 x i64> } %198, <8 x i64> %197, 1
  store { <8 x ptr>, <8 x i64> } %199, ptr %tile_snapshot.spill93, align 64
  %200 = icmp sge i64 %190, 0
  %201 = and i1 true, %200
  %202 = icmp sle i64 %190, 113
  %203 = and i1 %201, %202
  store i1 %203, ptr %.spill94, align 1
  br i1 %203, label %direct.true219, label %direct.false220

direct.schedule.6:                                ; preds = %direct.true219
  %.spill.load = load i64, ptr %.spill72, align 4
  %204 = mul i64 %.spill.load, 2
  %.splatinsert221 = insertelement <8 x i64> poison, i64 %204, i64 0
  %.splat222 = shufflevector <8 x i64> %.splatinsert221, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load223 = load <8 x i64>, ptr %.spill70, align 64
  %205 = add <8 x i64> %.splat222, %.spill.load223
  %206 = mul <8 x i64> %205, splat (i64 129)
  %.spill.load224 = load i64, ptr %.spill92, align 4
  %.splatinsert225 = insertelement <8 x i64> poison, i64 %.spill.load224, i64 0
  %.splat226 = shufflevector <8 x i64> %.splatinsert225, <8 x i64> poison, <8 x i32> zeroinitializer
  %207 = add <8 x i64> %206, %.splat226
  %208 = mul <8 x i64> %207, splat (i64 32)
  %209 = add <8 x i64> %208, zeroinitializer
  %tile_snapshot.spill.load227 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill93, align 64
  %210 = extractvalue { ptr, i64 } %65, 0
  %211 = extractelement <8 x i1> %101, i64 0
  br i1 %211, label %copy.active228, label %copy.continue229

direct.schedule.7:                                ; preds = %direct.false880, %copy.continue243
  %212 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %213 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %214 = extractvalue { <8 x ptr>, <8 x i64> } %212, 0
  %215 = select <8 x i1> %101, <8 x ptr> %213, <8 x ptr> %214
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %217 = extractvalue { <8 x ptr>, <8 x i64> } %212, 1
  %218 = select <8 x i1> %101, <8 x i64> %216, <8 x i64> %217
  %219 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %215, 0
  %220 = insertvalue { <8 x ptr>, <8 x i64> } %219, <8 x i64> %218, 1
  store { <8 x ptr>, <8 x i64> } %220, ptr %tile_snapshot.spill95, align 64
  %.spill.load244 = load i1, ptr %.spill94, align 1
  br i1 %.spill.load244, label %direct.true245, label %direct.false246

direct.schedule.8:                                ; preds = %direct.true245
  %.spill.load247 = load i64, ptr %.spill72, align 4
  %221 = mul i64 %.spill.load247, 2
  %.splatinsert248 = insertelement <8 x i64> poison, i64 %221, i64 0
  %.splat249 = shufflevector <8 x i64> %.splatinsert248, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load250 = load <8 x i64>, ptr %.spill70, align 64
  %222 = add <8 x i64> %.splat249, %.spill.load250
  %223 = mul <8 x i64> %222, splat (i64 129)
  %.spill.load251 = load i64, ptr %.spill92, align 4
  %.splatinsert252 = insertelement <8 x i64> poison, i64 %.spill.load251, i64 0
  %.splat253 = shufflevector <8 x i64> %.splatinsert252, <8 x i64> poison, <8 x i32> zeroinitializer
  %224 = add <8 x i64> %223, %.splat253
  %225 = mul <8 x i64> %224, splat (i64 48)
  %226 = add <8 x i64> %225, zeroinitializer
  %tile_snapshot.spill.load254 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %227 = extractvalue { ptr, i64 } %71, 0
  %228 = extractelement <8 x i1> %101, i64 0
  br i1 %228, label %copy.active255, label %copy.continue256

direct.schedule.9:                                ; preds = %direct.false855, %copy.continue270
  %229 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill96, align 64
  %230 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %231 = extractvalue { <8 x ptr>, <8 x i64> } %229, 0
  %232 = select <8 x i1> %101, <8 x ptr> %230, <8 x ptr> %231
  %233 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %234 = extractvalue { <8 x ptr>, <8 x i64> } %229, 1
  %235 = select <8 x i1> %101, <8 x i64> %233, <8 x i64> %234
  %236 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %232, 0
  %237 = insertvalue { <8 x ptr>, <8 x i64> } %236, <8 x i64> %235, 1
  store { <8 x ptr>, <8 x i64> } %237, ptr %tile_snapshot.spill96, align 64
  store i64 0, ptr %.slot97, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state271 = load i64, ptr %.slot97, align 4
  %238 = icmp slt i64 %.state271, 128
  br i1 %238, label %direct.true272, label %direct.false273

direct.schedule.11:                               ; preds = %direct.true272
  %tile_snapshot.spill.load274 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill96, align 64
  %239 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load274, 0
  %240 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load274, 1
  %.state275 = load i64, ptr %.slot97, align 4
  %.splatinsert276 = insertelement <8 x i64> poison, i64 %.state275, i64 0
  %.splat277 = shufflevector <8 x i64> %.splatinsert276, <8 x i64> poison, <8 x i32> zeroinitializer
  %241 = mul <8 x i64> %.splat277, splat (i64 4)
  %242 = add <8 x i64> %240, %241
  %243 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %239, 0
  %244 = insertvalue { <8 x ptr>, <8 x i64> } %243, <8 x i64> %242, 1
  %245 = extractvalue { <8 x ptr>, <8 x i64> } %244, 0
  %246 = extractvalue { <8 x ptr>, <8 x i64> } %244, 1
  %247 = getelementptr i8, <8 x ptr> %245, <8 x i64> %246
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %247, <8 x i1> %101)
  %.state278 = load i64, ptr %.slot97, align 4
  %248 = add i64 %.state278, 1
  store i64 %248, ptr %.slot97, align 4
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false273
  %249 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill98, align 64
  %250 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %251 = extractvalue { <8 x ptr>, <8 x i64> } %249, 0
  %252 = select <8 x i1> %101, <8 x ptr> %250, <8 x ptr> %251
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %249, 1
  %255 = select <8 x i1> %101, <8 x i64> %253, <8 x i64> %254
  %256 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %252, 0
  %257 = insertvalue { <8 x ptr>, <8 x i64> } %256, <8 x i64> %255, 1
  store { <8 x ptr>, <8 x i64> } %257, ptr %tile_snapshot.spill98, align 64
  %tile_snapshot.spill.load279 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %tile_snapshot.spill.load280 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill93, align 64
  %tile_snapshot.spill.load281 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill96, align 64
  %258 = extractelement <8 x i1> %101, i64 0
  br i1 %258, label %mma.active, label %mma.continue

direct.schedule.13:                               ; preds = %direct.schedule.14, %mma.continue295
  %.state432 = load i64, ptr %.slot103, align 4
  %259 = icmp slt i64 %.state432, 128
  br i1 %259, label %direct.true433, label %direct.false434

direct.schedule.14:                               ; preds = %direct.true433
  %.state435 = load i64, ptr %.slot103, align 4
  %260 = srem i64 %.state435, 8
  %.state436 = load i64, ptr %.slot103, align 4
  %261 = sdiv i64 %.state436, 8
  %262 = add i64 0, %261
  %tile_snapshot.spill.load437 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill99, align 64
  %263 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load437, 0
  %264 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load437, 1
  %.splatinsert438 = insertelement <8 x i64> poison, i64 %262, i64 0
  %.splat439 = shufflevector <8 x i64> %.splatinsert438, <8 x i64> poison, <8 x i32> zeroinitializer
  %265 = add <8 x i64> %264, %.splat439
  %266 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %263, 0
  %267 = insertvalue { <8 x ptr>, <8 x i64> } %266, <8 x i64> %265, 1
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %267, 0
  %269 = extractvalue { <8 x ptr>, <8 x i64> } %267, 1
  %270 = getelementptr i8, <8 x ptr> %268, <8 x i64> %269
  %271 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %270, <8 x i1> %101, <8 x i8> zeroinitializer)
  %272 = icmp ne <8 x i8> %271, zeroinitializer
  %273 = mul i64 %262, 8
  %274 = add i64 %273, %260
  %275 = srem i64 %274, 8
  %276 = sdiv i64 %274, 8
  %277 = add i64 0, %276
  %tile_snapshot.spill.load440 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill100, align 64
  %278 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load440, 0
  %279 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load440, 1
  %.splatinsert441 = insertelement <8 x i64> poison, i64 %277, i64 0
  %.splat442 = shufflevector <8 x i64> %.splatinsert441, <8 x i64> poison, <8 x i32> zeroinitializer
  %280 = mul <8 x i64> %.splat442, splat (i64 64)
  %281 = add <8 x i64> %279, %280
  %282 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %278, 0
  %283 = insertvalue { <8 x ptr>, <8 x i64> } %282, <8 x i64> %281, 1
  %284 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %285 = extractvalue { <8 x ptr>, <8 x i64> } %283, 1
  %286 = extractelement <8 x ptr> %284, i32 0
  %287 = extractelement <8 x i64> %285, i32 0
  %288 = sub i64 %287, 0
  %289 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %290 = select i1 %289, i64 %288, i64 0
  %private.contiguous.address443 = getelementptr i8, ptr %286, i64 %290
  %private.contiguous.load = load <8 x i64>, ptr %private.contiguous.address443, align 8
  %291 = select <8 x i1> %101, <8 x i64> %private.contiguous.load, <8 x i64> zeroinitializer
  %292 = add i64 0, %275
  %tile_snapshot.spill.load444 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill101, align 64
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load444, 0
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load444, 1
  %.splatinsert445 = insertelement <8 x i64> poison, i64 %292, i64 0
  %.splat446 = shufflevector <8 x i64> %.splatinsert445, <8 x i64> poison, <8 x i32> zeroinitializer
  %295 = mul <8 x i64> %.splat446, splat (i64 64)
  %296 = add <8 x i64> %294, %295
  %297 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %293, 0
  %298 = insertvalue { <8 x ptr>, <8 x i64> } %297, <8 x i64> %296, 1
  %299 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %298, 1
  %301 = extractelement <8 x ptr> %299, i32 0
  %302 = extractelement <8 x i64> %300, i32 0
  %303 = sub i64 %302, 0
  %304 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %305 = select i1 %304, i64 %303, i64 0
  %private.contiguous.address447 = getelementptr i8, ptr %301, i64 %305
  %private.contiguous.load448 = load <8 x i64>, ptr %private.contiguous.address447, align 8
  %306 = select <8 x i1> %101, <8 x i64> %private.contiguous.load448, <8 x i64> zeroinitializer
  %307 = icmp sle <8 x i64> %291, %306
  %308 = and <8 x i1> %272, %307
  %tile_snapshot.spill.load449 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill102, align 64
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load449, 0
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load449, 1
  %.state450 = load i64, ptr %.slot103, align 4
  %.splatinsert451 = insertelement <8 x i64> poison, i64 %.state450, i64 0
  %.splat452 = shufflevector <8 x i64> %.splatinsert451, <8 x i64> poison, <8 x i32> zeroinitializer
  %311 = add <8 x i64> %310, %.splat452
  %312 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %309, 0
  %313 = insertvalue { <8 x ptr>, <8 x i64> } %312, <8 x i64> %311, 1
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %313, 0
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %313, 1
  %316 = getelementptr i8, <8 x ptr> %314, <8 x i64> %315
  %317 = zext <8 x i1> %308 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %317, <8 x ptr> align 1 %316, <8 x i1> %101)
  %.state453 = load i64, ptr %.slot103, align 4
  %318 = add i64 %.state453, 1
  store i64 %318, ptr %.slot103, align 4
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false434
  %319 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill104, align 64
  %320 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %321 = extractvalue { <8 x ptr>, <8 x i64> } %319, 0
  %322 = select <8 x i1> %101, <8 x ptr> %320, <8 x ptr> %321
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %319, 1
  %325 = select <8 x i1> %101, <8 x i64> %323, <8 x i64> %324
  %326 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %322, 0
  %327 = insertvalue { <8 x ptr>, <8 x i64> } %326, <8 x i64> %325, 1
  store { <8 x ptr>, <8 x i64> } %327, ptr %tile_snapshot.spill104, align 64
  store i64 0, ptr %.slot105, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state454 = load i64, ptr %.slot105, align 4
  %328 = icmp slt i64 %.state454, 128
  br i1 %328, label %direct.true455, label %direct.false456

direct.schedule.17:                               ; preds = %direct.true455
  %.state457 = load i64, ptr %.slot105, align 4
  %329 = srem i64 %.state457, 16
  %.state458 = load i64, ptr %.slot105, align 4
  %330 = sdiv i64 %.state458, 16
  %331 = add i64 0, %329
  %332 = mul i64 %331, 8
  %333 = add i64 %332, %330
  %tile_snapshot.spill.load459 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill102, align 64
  %334 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load459, 0
  %335 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load459, 1
  %.splatinsert460 = insertelement <8 x i64> poison, i64 %333, i64 0
  %.splat461 = shufflevector <8 x i64> %.splatinsert460, <8 x i64> poison, <8 x i32> zeroinitializer
  %336 = add <8 x i64> %335, %.splat461
  %337 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %334, 0
  %338 = insertvalue { <8 x ptr>, <8 x i64> } %337, <8 x i64> %336, 1
  %339 = extractvalue { <8 x ptr>, <8 x i64> } %338, 0
  %340 = extractvalue { <8 x ptr>, <8 x i64> } %338, 1
  %341 = getelementptr i8, <8 x ptr> %339, <8 x i64> %340
  %342 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %341, <8 x i1> %101, <8 x i8> zeroinitializer)
  %343 = icmp ne <8 x i8> %342, zeroinitializer
  %344 = add i64 0, %330
  %345 = mul i64 %344, 16
  %346 = add i64 %345, %329
  %347 = srem i64 %346, 16
  %348 = sdiv i64 %346, 16
  %349 = add i64 0, %348
  %350 = mul i64 %349, 16
  %351 = add i64 %350, %347
  %tile_snapshot.spill.load462 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill98, align 64
  %352 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load462, 0
  %353 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load462, 1
  %.splatinsert463 = insertelement <8 x i64> poison, i64 %351, i64 0
  %.splat464 = shufflevector <8 x i64> %.splatinsert463, <8 x i64> poison, <8 x i32> zeroinitializer
  %354 = mul <8 x i64> %.splat464, splat (i64 4)
  %355 = add <8 x i64> %353, %354
  %356 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %352, 0
  %357 = insertvalue { <8 x ptr>, <8 x i64> } %356, <8 x i64> %355, 1
  %358 = extractvalue { <8 x ptr>, <8 x i64> } %357, 0
  %359 = extractvalue { <8 x ptr>, <8 x i64> } %357, 1
  %360 = getelementptr i8, <8 x ptr> %358, <8 x i64> %359
  %361 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %360, <8 x i1> %101, <8 x float> zeroinitializer)
  %362 = fmul <8 x float> %361, splat (float 0x3FC6A09E60000000)
  %363 = select <8 x i1> %343, <8 x float> %362, <8 x float> splat (float 0xC6293E5940000000)
  %tile_snapshot.spill.load465 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill104, align 64
  %364 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load465, 0
  %365 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load465, 1
  %.state466 = load i64, ptr %.slot105, align 4
  %.splatinsert467 = insertelement <8 x i64> poison, i64 %.state466, i64 0
  %.splat468 = shufflevector <8 x i64> %.splatinsert467, <8 x i64> poison, <8 x i32> zeroinitializer
  %366 = mul <8 x i64> %.splat468, splat (i64 32)
  %367 = add <8 x i64> %365, %366
  %368 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %364, 0
  %369 = insertvalue { <8 x ptr>, <8 x i64> } %368, <8 x i64> %367, 1
  %370 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %371 = extractvalue { <8 x ptr>, <8 x i64> } %369, 1
  %372 = extractelement <8 x ptr> %370, i32 0
  %373 = extractelement <8 x i64> %371, i32 0
  %374 = sub i64 %373, 0
  %375 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %376 = select i1 %375, i64 %374, i64 0
  %private.contiguous.address469 = getelementptr i8, ptr %372, i64 %376
  %private.contiguous.preserve470 = load <8 x float>, ptr %private.contiguous.address469, align 4
  %377 = select <8 x i1> %101, <8 x float> %363, <8 x float> %private.contiguous.preserve470
  store <8 x float> %377, ptr %private.contiguous.address469, align 4
  %.state471 = load i64, ptr %.slot105, align 4
  %378 = add i64 %.state471, 1
  store i64 %378, ptr %.slot105, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false456
  store i64 0, ptr %.slot106, align 4
  %379 = load <8 x float>, ptr %.slot107, align 32
  %380 = select <8 x i1> %101, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %379
  store <8 x float> %380, ptr %.slot107, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state472 = load i64, ptr %.slot106, align 4
  %381 = icmp slt i64 %.state472, 16
  br i1 %381, label %direct.true473, label %direct.false474

direct.schedule.20:                               ; preds = %direct.true473
  %.state475 = load i64, ptr %.slot106, align 4
  %382 = sdiv i64 %.state475, 1
  %.spill.load476 = load i64, ptr %.spill72, align 4
  %383 = mul i64 %.spill.load476, 1
  %384 = add i64 %383, 0
  %385 = mul i64 %384, 8
  %386 = add i64 %385, 0
  %387 = mul i64 %386, 16
  %388 = add i64 %387, %382
  %tile_snapshot.spill.load477 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill104, align 64
  %389 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load477, 0
  %390 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load477, 1
  %.splatinsert478 = insertelement <8 x i64> poison, i64 %388, i64 0
  %.splat479 = shufflevector <8 x i64> %.splatinsert478, <8 x i64> poison, <8 x i32> zeroinitializer
  %391 = mul <8 x i64> %.splat479, splat (i64 32)
  %392 = add <8 x i64> %390, %391
  %393 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %389, 0
  %394 = insertvalue { <8 x ptr>, <8 x i64> } %393, <8 x i64> %392, 1
  %395 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %396 = extractvalue { <8 x ptr>, <8 x i64> } %394, 1
  %397 = extractelement <8 x ptr> %395, i32 0
  %398 = extractelement <8 x i64> %396, i32 0
  %399 = sub i64 %398, 0
  %400 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %401 = select i1 %400, i64 %399, i64 0
  %private.contiguous.address480 = getelementptr i8, ptr %397, i64 %401
  %private.contiguous.load481 = load <8 x float>, ptr %private.contiguous.address480, align 4
  %402 = select <8 x i1> %101, <8 x float> %private.contiguous.load481, <8 x float> zeroinitializer
  %.state482 = load <8 x float>, ptr %.slot107, align 32
  %403 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state482, <8 x float> %402)
  %.state483 = load i64, ptr %.slot106, align 4
  %404 = add i64 %.state483, 1
  store i64 %404, ptr %.slot106, align 4
  %405 = load <8 x float>, ptr %.slot107, align 32
  %406 = select <8 x i1> %101, <8 x float> %403, <8 x float> %405
  store <8 x float> %406, ptr %.slot107, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false474
  store i64 0, ptr %.slot108, align 4
  %407 = load <8 x float>, ptr %.slot109, align 32
  %408 = select <8 x i1> %101, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %407
  store <8 x float> %408, ptr %.slot109, align 32
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state484 = load i64, ptr %.slot108, align 4
  %409 = icmp slt i64 %.state484, 16
  br i1 %409, label %direct.true485, label %direct.false486

direct.schedule.23:                               ; preds = %direct.true485
  %.state487 = load i64, ptr %.slot108, align 4
  %410 = sdiv i64 %.state487, 1
  %.spill.load488 = load i64, ptr %.spill72, align 4
  %411 = mul i64 %.spill.load488, 1
  %412 = add i64 %411, 0
  %413 = mul i64 %412, 8
  %414 = add i64 %413, 1
  %415 = mul i64 %414, 16
  %416 = add i64 %415, %410
  %tile_snapshot.spill.load489 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill104, align 64
  %417 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load489, 0
  %418 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load489, 1
  %.splatinsert490 = insertelement <8 x i64> poison, i64 %416, i64 0
  %.splat491 = shufflevector <8 x i64> %.splatinsert490, <8 x i64> poison, <8 x i32> zeroinitializer
  %419 = mul <8 x i64> %.splat491, splat (i64 32)
  %420 = add <8 x i64> %418, %419
  %421 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %417, 0
  %422 = insertvalue { <8 x ptr>, <8 x i64> } %421, <8 x i64> %420, 1
  %423 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %424 = extractvalue { <8 x ptr>, <8 x i64> } %422, 1
  %425 = extractelement <8 x ptr> %423, i32 0
  %426 = extractelement <8 x i64> %424, i32 0
  %427 = sub i64 %426, 0
  %428 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %429 = select i1 %428, i64 %427, i64 0
  %private.contiguous.address492 = getelementptr i8, ptr %425, i64 %429
  %private.contiguous.load493 = load <8 x float>, ptr %private.contiguous.address492, align 4
  %430 = select <8 x i1> %101, <8 x float> %private.contiguous.load493, <8 x float> zeroinitializer
  %.state494 = load <8 x float>, ptr %.slot109, align 32
  %431 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state494, <8 x float> %430)
  %.state495 = load i64, ptr %.slot108, align 4
  %432 = add i64 %.state495, 1
  store i64 %432, ptr %.slot108, align 4
  %433 = load <8 x float>, ptr %.slot109, align 32
  %434 = select <8 x i1> %101, <8 x float> %431, <8 x float> %433
  store <8 x float> %434, ptr %.slot109, align 32
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false486
  store i64 0, ptr %.slot110, align 4
  %435 = load <8 x float>, ptr %.slot111, align 32
  %436 = select <8 x i1> %101, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %435
  store <8 x float> %436, ptr %.slot111, align 32
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.26, %direct.schedule.24
  %.state496 = load i64, ptr %.slot110, align 4
  %437 = icmp slt i64 %.state496, 16
  br i1 %437, label %direct.true497, label %direct.false498

direct.schedule.26:                               ; preds = %direct.true497
  %.state499 = load i64, ptr %.slot110, align 4
  %438 = sdiv i64 %.state499, 1
  %.spill.load500 = load i64, ptr %.spill72, align 4
  %439 = mul i64 %.spill.load500, 1
  %440 = add i64 %439, 0
  %441 = mul i64 %440, 8
  %442 = add i64 %441, 2
  %443 = mul i64 %442, 16
  %444 = add i64 %443, %438
  %tile_snapshot.spill.load501 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill104, align 64
  %445 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load501, 0
  %446 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load501, 1
  %.splatinsert502 = insertelement <8 x i64> poison, i64 %444, i64 0
  %.splat503 = shufflevector <8 x i64> %.splatinsert502, <8 x i64> poison, <8 x i32> zeroinitializer
  %447 = mul <8 x i64> %.splat503, splat (i64 32)
  %448 = add <8 x i64> %446, %447
  %449 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %445, 0
  %450 = insertvalue { <8 x ptr>, <8 x i64> } %449, <8 x i64> %448, 1
  %451 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %452 = extractvalue { <8 x ptr>, <8 x i64> } %450, 1
  %453 = extractelement <8 x ptr> %451, i32 0
  %454 = extractelement <8 x i64> %452, i32 0
  %455 = sub i64 %454, 0
  %456 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %457 = select i1 %456, i64 %455, i64 0
  %private.contiguous.address504 = getelementptr i8, ptr %453, i64 %457
  %private.contiguous.load505 = load <8 x float>, ptr %private.contiguous.address504, align 4
  %458 = select <8 x i1> %101, <8 x float> %private.contiguous.load505, <8 x float> zeroinitializer
  %.state506 = load <8 x float>, ptr %.slot111, align 32
  %459 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state506, <8 x float> %458)
  %.state507 = load i64, ptr %.slot110, align 4
  %460 = add i64 %.state507, 1
  store i64 %460, ptr %.slot110, align 4
  %461 = load <8 x float>, ptr %.slot111, align 32
  %462 = select <8 x i1> %101, <8 x float> %459, <8 x float> %461
  store <8 x float> %462, ptr %.slot111, align 32
  br label %direct.schedule.25

direct.schedule.27:                               ; preds = %direct.false498
  store i64 0, ptr %.slot112, align 4
  %463 = load <8 x float>, ptr %.slot113, align 32
  %464 = select <8 x i1> %101, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %463
  store <8 x float> %464, ptr %.slot113, align 32
  br label %direct.schedule.28

direct.schedule.28:                               ; preds = %direct.schedule.29, %direct.schedule.27
  %.state508 = load i64, ptr %.slot112, align 4
  %465 = icmp slt i64 %.state508, 16
  br i1 %465, label %direct.true509, label %direct.false510

direct.schedule.29:                               ; preds = %direct.true509
  %.state511 = load i64, ptr %.slot112, align 4
  %466 = sdiv i64 %.state511, 1
  %.spill.load512 = load i64, ptr %.spill72, align 4
  %467 = mul i64 %.spill.load512, 1
  %468 = add i64 %467, 0
  %469 = mul i64 %468, 8
  %470 = add i64 %469, 3
  %471 = mul i64 %470, 16
  %472 = add i64 %471, %466
  %tile_snapshot.spill.load513 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill104, align 64
  %473 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load513, 0
  %474 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load513, 1
  %.splatinsert514 = insertelement <8 x i64> poison, i64 %472, i64 0
  %.splat515 = shufflevector <8 x i64> %.splatinsert514, <8 x i64> poison, <8 x i32> zeroinitializer
  %475 = mul <8 x i64> %.splat515, splat (i64 32)
  %476 = add <8 x i64> %474, %475
  %477 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %473, 0
  %478 = insertvalue { <8 x ptr>, <8 x i64> } %477, <8 x i64> %476, 1
  %479 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %480 = extractvalue { <8 x ptr>, <8 x i64> } %478, 1
  %481 = extractelement <8 x ptr> %479, i32 0
  %482 = extractelement <8 x i64> %480, i32 0
  %483 = sub i64 %482, 0
  %484 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %485 = select i1 %484, i64 %483, i64 0
  %private.contiguous.address516 = getelementptr i8, ptr %481, i64 %485
  %private.contiguous.load517 = load <8 x float>, ptr %private.contiguous.address516, align 4
  %486 = select <8 x i1> %101, <8 x float> %private.contiguous.load517, <8 x float> zeroinitializer
  %.state518 = load <8 x float>, ptr %.slot113, align 32
  %487 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state518, <8 x float> %486)
  %.state519 = load i64, ptr %.slot112, align 4
  %488 = add i64 %.state519, 1
  store i64 %488, ptr %.slot112, align 4
  %489 = load <8 x float>, ptr %.slot113, align 32
  %490 = select <8 x i1> %101, <8 x float> %487, <8 x float> %489
  store <8 x float> %490, ptr %.slot113, align 32
  br label %direct.schedule.28

direct.schedule.30:                               ; preds = %direct.false510
  store i64 0, ptr %.slot114, align 4
  %491 = load <8 x float>, ptr %.slot115, align 32
  %492 = select <8 x i1> %101, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %491
  store <8 x float> %492, ptr %.slot115, align 32
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.32, %direct.schedule.30
  %.state520 = load i64, ptr %.slot114, align 4
  %493 = icmp slt i64 %.state520, 16
  br i1 %493, label %direct.true521, label %direct.false522

direct.schedule.32:                               ; preds = %direct.true521
  %.state523 = load i64, ptr %.slot114, align 4
  %494 = sdiv i64 %.state523, 1
  %.spill.load524 = load i64, ptr %.spill72, align 4
  %495 = mul i64 %.spill.load524, 1
  %496 = add i64 %495, 0
  %497 = mul i64 %496, 8
  %498 = add i64 %497, 4
  %499 = mul i64 %498, 16
  %500 = add i64 %499, %494
  %tile_snapshot.spill.load525 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill104, align 64
  %501 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load525, 0
  %502 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load525, 1
  %.splatinsert526 = insertelement <8 x i64> poison, i64 %500, i64 0
  %.splat527 = shufflevector <8 x i64> %.splatinsert526, <8 x i64> poison, <8 x i32> zeroinitializer
  %503 = mul <8 x i64> %.splat527, splat (i64 32)
  %504 = add <8 x i64> %502, %503
  %505 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %501, 0
  %506 = insertvalue { <8 x ptr>, <8 x i64> } %505, <8 x i64> %504, 1
  %507 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %508 = extractvalue { <8 x ptr>, <8 x i64> } %506, 1
  %509 = extractelement <8 x ptr> %507, i32 0
  %510 = extractelement <8 x i64> %508, i32 0
  %511 = sub i64 %510, 0
  %512 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %513 = select i1 %512, i64 %511, i64 0
  %private.contiguous.address528 = getelementptr i8, ptr %509, i64 %513
  %private.contiguous.load529 = load <8 x float>, ptr %private.contiguous.address528, align 4
  %514 = select <8 x i1> %101, <8 x float> %private.contiguous.load529, <8 x float> zeroinitializer
  %.state530 = load <8 x float>, ptr %.slot115, align 32
  %515 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state530, <8 x float> %514)
  %.state531 = load i64, ptr %.slot114, align 4
  %516 = add i64 %.state531, 1
  store i64 %516, ptr %.slot114, align 4
  %517 = load <8 x float>, ptr %.slot115, align 32
  %518 = select <8 x i1> %101, <8 x float> %515, <8 x float> %517
  store <8 x float> %518, ptr %.slot115, align 32
  br label %direct.schedule.31

direct.schedule.33:                               ; preds = %direct.false522
  store i64 0, ptr %.slot116, align 4
  %519 = load <8 x float>, ptr %.slot117, align 32
  %520 = select <8 x i1> %101, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %519
  store <8 x float> %520, ptr %.slot117, align 32
  br label %direct.schedule.34

direct.schedule.34:                               ; preds = %direct.schedule.35, %direct.schedule.33
  %.state532 = load i64, ptr %.slot116, align 4
  %521 = icmp slt i64 %.state532, 16
  br i1 %521, label %direct.true533, label %direct.false534

direct.schedule.35:                               ; preds = %direct.true533
  %.state535 = load i64, ptr %.slot116, align 4
  %522 = sdiv i64 %.state535, 1
  %.spill.load536 = load i64, ptr %.spill72, align 4
  %523 = mul i64 %.spill.load536, 1
  %524 = add i64 %523, 0
  %525 = mul i64 %524, 8
  %526 = add i64 %525, 5
  %527 = mul i64 %526, 16
  %528 = add i64 %527, %522
  %tile_snapshot.spill.load537 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill104, align 64
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load537, 0
  %530 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load537, 1
  %.splatinsert538 = insertelement <8 x i64> poison, i64 %528, i64 0
  %.splat539 = shufflevector <8 x i64> %.splatinsert538, <8 x i64> poison, <8 x i32> zeroinitializer
  %531 = mul <8 x i64> %.splat539, splat (i64 32)
  %532 = add <8 x i64> %530, %531
  %533 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %529, 0
  %534 = insertvalue { <8 x ptr>, <8 x i64> } %533, <8 x i64> %532, 1
  %535 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %536 = extractvalue { <8 x ptr>, <8 x i64> } %534, 1
  %537 = extractelement <8 x ptr> %535, i32 0
  %538 = extractelement <8 x i64> %536, i32 0
  %539 = sub i64 %538, 0
  %540 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %541 = select i1 %540, i64 %539, i64 0
  %private.contiguous.address540 = getelementptr i8, ptr %537, i64 %541
  %private.contiguous.load541 = load <8 x float>, ptr %private.contiguous.address540, align 4
  %542 = select <8 x i1> %101, <8 x float> %private.contiguous.load541, <8 x float> zeroinitializer
  %.state542 = load <8 x float>, ptr %.slot117, align 32
  %543 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state542, <8 x float> %542)
  %.state543 = load i64, ptr %.slot116, align 4
  %544 = add i64 %.state543, 1
  store i64 %544, ptr %.slot116, align 4
  %545 = load <8 x float>, ptr %.slot117, align 32
  %546 = select <8 x i1> %101, <8 x float> %543, <8 x float> %545
  store <8 x float> %546, ptr %.slot117, align 32
  br label %direct.schedule.34

direct.schedule.36:                               ; preds = %direct.false534
  store i64 0, ptr %.slot118, align 4
  %547 = load <8 x float>, ptr %.slot119, align 32
  %548 = select <8 x i1> %101, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %547
  store <8 x float> %548, ptr %.slot119, align 32
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.38, %direct.schedule.36
  %.state544 = load i64, ptr %.slot118, align 4
  %549 = icmp slt i64 %.state544, 16
  br i1 %549, label %direct.true545, label %direct.false546

direct.schedule.38:                               ; preds = %direct.true545
  %.state547 = load i64, ptr %.slot118, align 4
  %550 = sdiv i64 %.state547, 1
  %.spill.load548 = load i64, ptr %.spill72, align 4
  %551 = mul i64 %.spill.load548, 1
  %552 = add i64 %551, 0
  %553 = mul i64 %552, 8
  %554 = add i64 %553, 6
  %555 = mul i64 %554, 16
  %556 = add i64 %555, %550
  %tile_snapshot.spill.load549 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill104, align 64
  %557 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load549, 0
  %558 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load549, 1
  %.splatinsert550 = insertelement <8 x i64> poison, i64 %556, i64 0
  %.splat551 = shufflevector <8 x i64> %.splatinsert550, <8 x i64> poison, <8 x i32> zeroinitializer
  %559 = mul <8 x i64> %.splat551, splat (i64 32)
  %560 = add <8 x i64> %558, %559
  %561 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %557, 0
  %562 = insertvalue { <8 x ptr>, <8 x i64> } %561, <8 x i64> %560, 1
  %563 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %564 = extractvalue { <8 x ptr>, <8 x i64> } %562, 1
  %565 = extractelement <8 x ptr> %563, i32 0
  %566 = extractelement <8 x i64> %564, i32 0
  %567 = sub i64 %566, 0
  %568 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %569 = select i1 %568, i64 %567, i64 0
  %private.contiguous.address552 = getelementptr i8, ptr %565, i64 %569
  %private.contiguous.load553 = load <8 x float>, ptr %private.contiguous.address552, align 4
  %570 = select <8 x i1> %101, <8 x float> %private.contiguous.load553, <8 x float> zeroinitializer
  %.state554 = load <8 x float>, ptr %.slot119, align 32
  %571 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state554, <8 x float> %570)
  %.state555 = load i64, ptr %.slot118, align 4
  %572 = add i64 %.state555, 1
  store i64 %572, ptr %.slot118, align 4
  %573 = load <8 x float>, ptr %.slot119, align 32
  %574 = select <8 x i1> %101, <8 x float> %571, <8 x float> %573
  store <8 x float> %574, ptr %.slot119, align 32
  br label %direct.schedule.37

direct.schedule.39:                               ; preds = %direct.false546
  store i64 0, ptr %.slot120, align 4
  %575 = load <8 x float>, ptr %.slot121, align 32
  %576 = select <8 x i1> %101, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %575
  store <8 x float> %576, ptr %.slot121, align 32
  br label %direct.schedule.40

direct.schedule.40:                               ; preds = %direct.schedule.41, %direct.schedule.39
  %.state556 = load i64, ptr %.slot120, align 4
  %577 = icmp slt i64 %.state556, 16
  br i1 %577, label %direct.true557, label %direct.false558

direct.schedule.41:                               ; preds = %direct.true557
  %.state559 = load i64, ptr %.slot120, align 4
  %578 = sdiv i64 %.state559, 1
  %.spill.load560 = load i64, ptr %.spill72, align 4
  %579 = mul i64 %.spill.load560, 1
  %580 = add i64 %579, 0
  %581 = mul i64 %580, 8
  %582 = add i64 %581, 7
  %583 = mul i64 %582, 16
  %584 = add i64 %583, %578
  %tile_snapshot.spill.load561 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill104, align 64
  %585 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load561, 0
  %586 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load561, 1
  %.splatinsert562 = insertelement <8 x i64> poison, i64 %584, i64 0
  %.splat563 = shufflevector <8 x i64> %.splatinsert562, <8 x i64> poison, <8 x i32> zeroinitializer
  %587 = mul <8 x i64> %.splat563, splat (i64 32)
  %588 = add <8 x i64> %586, %587
  %589 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %585, 0
  %590 = insertvalue { <8 x ptr>, <8 x i64> } %589, <8 x i64> %588, 1
  %591 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %592 = extractvalue { <8 x ptr>, <8 x i64> } %590, 1
  %593 = extractelement <8 x ptr> %591, i32 0
  %594 = extractelement <8 x i64> %592, i32 0
  %595 = sub i64 %594, 0
  %596 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %597 = select i1 %596, i64 %595, i64 0
  %private.contiguous.address564 = getelementptr i8, ptr %593, i64 %597
  %private.contiguous.load565 = load <8 x float>, ptr %private.contiguous.address564, align 4
  %598 = select <8 x i1> %101, <8 x float> %private.contiguous.load565, <8 x float> zeroinitializer
  %.state566 = load <8 x float>, ptr %.slot121, align 32
  %599 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state566, <8 x float> %598)
  %.state567 = load i64, ptr %.slot120, align 4
  %600 = add i64 %.state567, 1
  store i64 %600, ptr %.slot120, align 4
  %601 = load <8 x float>, ptr %.slot121, align 32
  %602 = select <8 x i1> %101, <8 x float> %599, <8 x float> %601
  store <8 x float> %602, ptr %.slot121, align 32
  br label %direct.schedule.40

direct.schedule.42:                               ; preds = %direct.false558
  %.state568 = load <8 x float>, ptr %.slot76, align 32
  %.state569 = load <8 x float>, ptr %.slot107, align 32
  %603 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state568, <8 x float> %.state569)
  %604 = load <8 x float>, ptr %.spill122, align 32
  %605 = select <8 x i1> %101, <8 x float> %603, <8 x float> %604
  store <8 x float> %605, ptr %.spill122, align 32
  %.state570 = load <8 x float>, ptr %.slot77, align 32
  %.state571 = load <8 x float>, ptr %.slot109, align 32
  %606 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state570, <8 x float> %.state571)
  %607 = load <8 x float>, ptr %.spill123, align 32
  %608 = select <8 x i1> %101, <8 x float> %606, <8 x float> %607
  store <8 x float> %608, ptr %.spill123, align 32
  %.state572 = load <8 x float>, ptr %.slot78, align 32
  %.state573 = load <8 x float>, ptr %.slot111, align 32
  %609 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state572, <8 x float> %.state573)
  %610 = load <8 x float>, ptr %.spill124, align 32
  %611 = select <8 x i1> %101, <8 x float> %609, <8 x float> %610
  store <8 x float> %611, ptr %.spill124, align 32
  %.state574 = load <8 x float>, ptr %.slot79, align 32
  %.state575 = load <8 x float>, ptr %.slot113, align 32
  %612 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state574, <8 x float> %.state575)
  %613 = load <8 x float>, ptr %.spill125, align 32
  %614 = select <8 x i1> %101, <8 x float> %612, <8 x float> %613
  store <8 x float> %614, ptr %.spill125, align 32
  %.state576 = load <8 x float>, ptr %.slot80, align 32
  %.state577 = load <8 x float>, ptr %.slot115, align 32
  %615 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state576, <8 x float> %.state577)
  %616 = load <8 x float>, ptr %.spill126, align 32
  %617 = select <8 x i1> %101, <8 x float> %615, <8 x float> %616
  store <8 x float> %617, ptr %.spill126, align 32
  %.state578 = load <8 x float>, ptr %.slot81, align 32
  %.state579 = load <8 x float>, ptr %.slot117, align 32
  %618 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state578, <8 x float> %.state579)
  %619 = load <8 x float>, ptr %.spill127, align 32
  %620 = select <8 x i1> %101, <8 x float> %618, <8 x float> %619
  store <8 x float> %620, ptr %.spill127, align 32
  %.state580 = load <8 x float>, ptr %.slot82, align 32
  %.state581 = load <8 x float>, ptr %.slot119, align 32
  %621 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state580, <8 x float> %.state581)
  %622 = load <8 x float>, ptr %.spill128, align 32
  %623 = select <8 x i1> %101, <8 x float> %621, <8 x float> %622
  store <8 x float> %623, ptr %.spill128, align 32
  %.state582 = load <8 x float>, ptr %.slot83, align 32
  %.state583 = load <8 x float>, ptr %.slot121, align 32
  %624 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state582, <8 x float> %.state583)
  %625 = load <8 x float>, ptr %.spill129, align 32
  %626 = select <8 x i1> %101, <8 x float> %624, <8 x float> %625
  store <8 x float> %626, ptr %.spill129, align 32
  %627 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill130, align 64
  %628 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %629 = extractvalue { <8 x ptr>, <8 x i64> } %627, 0
  %630 = select <8 x i1> %101, <8 x ptr> %628, <8 x ptr> %629
  %631 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %632 = extractvalue { <8 x ptr>, <8 x i64> } %627, 1
  %633 = select <8 x i1> %101, <8 x i64> %631, <8 x i64> %632
  %634 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %630, 0
  %635 = insertvalue { <8 x ptr>, <8 x i64> } %634, <8 x i64> %633, 1
  store { <8 x ptr>, <8 x i64> } %635, ptr %tile_snapshot.spill130, align 64
  %636 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %637 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %638 = add <8 x i64> %637, zeroinitializer
  %639 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %636, 0
  %640 = insertvalue { <8 x ptr>, <8 x i64> } %639, <8 x i64> %638, 1
  %641 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %642 = extractvalue { <8 x ptr>, <8 x i64> } %640, 1
  %643 = extractelement <8 x ptr> %641, i32 0
  %644 = extractelement <8 x i64> %642, i32 0
  %645 = sub i64 %644, 0
  %646 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %647 = select i1 %646, i64 %645, i64 0
  %private.contiguous.address584 = getelementptr i8, ptr %643, i64 %647
  %private.contiguous.preserve585 = load <8 x float>, ptr %private.contiguous.address584, align 4
  %648 = select <8 x i1> %101, <8 x float> %603, <8 x float> %private.contiguous.preserve585
  store <8 x float> %648, ptr %private.contiguous.address584, align 4
  %649 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %650 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %651 = add <8 x i64> %650, splat (i64 32)
  %652 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %649, 0
  %653 = insertvalue { <8 x ptr>, <8 x i64> } %652, <8 x i64> %651, 1
  %654 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %655 = extractvalue { <8 x ptr>, <8 x i64> } %653, 1
  %656 = extractelement <8 x ptr> %654, i32 0
  %657 = extractelement <8 x i64> %655, i32 0
  %658 = sub i64 %657, 0
  %659 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %660 = select i1 %659, i64 %658, i64 0
  %private.contiguous.address586 = getelementptr i8, ptr %656, i64 %660
  %private.contiguous.preserve587 = load <8 x float>, ptr %private.contiguous.address586, align 4
  %661 = select <8 x i1> %101, <8 x float> %606, <8 x float> %private.contiguous.preserve587
  store <8 x float> %661, ptr %private.contiguous.address586, align 4
  %662 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %663 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %664 = add <8 x i64> %663, splat (i64 64)
  %665 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %662, 0
  %666 = insertvalue { <8 x ptr>, <8 x i64> } %665, <8 x i64> %664, 1
  %667 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %668 = extractvalue { <8 x ptr>, <8 x i64> } %666, 1
  %669 = extractelement <8 x ptr> %667, i32 0
  %670 = extractelement <8 x i64> %668, i32 0
  %671 = sub i64 %670, 0
  %672 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %673 = select i1 %672, i64 %671, i64 0
  %private.contiguous.address588 = getelementptr i8, ptr %669, i64 %673
  %private.contiguous.preserve589 = load <8 x float>, ptr %private.contiguous.address588, align 4
  %674 = select <8 x i1> %101, <8 x float> %609, <8 x float> %private.contiguous.preserve589
  store <8 x float> %674, ptr %private.contiguous.address588, align 4
  %675 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %676 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %677 = add <8 x i64> %676, splat (i64 96)
  %678 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %675, 0
  %679 = insertvalue { <8 x ptr>, <8 x i64> } %678, <8 x i64> %677, 1
  %680 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %681 = extractvalue { <8 x ptr>, <8 x i64> } %679, 1
  %682 = extractelement <8 x ptr> %680, i32 0
  %683 = extractelement <8 x i64> %681, i32 0
  %684 = sub i64 %683, 0
  %685 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %686 = select i1 %685, i64 %684, i64 0
  %private.contiguous.address590 = getelementptr i8, ptr %682, i64 %686
  %private.contiguous.preserve591 = load <8 x float>, ptr %private.contiguous.address590, align 4
  %687 = select <8 x i1> %101, <8 x float> %612, <8 x float> %private.contiguous.preserve591
  store <8 x float> %687, ptr %private.contiguous.address590, align 4
  %688 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %689 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %690 = add <8 x i64> %689, splat (i64 128)
  %691 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %688, 0
  %692 = insertvalue { <8 x ptr>, <8 x i64> } %691, <8 x i64> %690, 1
  %693 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %694 = extractvalue { <8 x ptr>, <8 x i64> } %692, 1
  %695 = extractelement <8 x ptr> %693, i32 0
  %696 = extractelement <8 x i64> %694, i32 0
  %697 = sub i64 %696, 0
  %698 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %699 = select i1 %698, i64 %697, i64 0
  %private.contiguous.address592 = getelementptr i8, ptr %695, i64 %699
  %private.contiguous.preserve593 = load <8 x float>, ptr %private.contiguous.address592, align 4
  %700 = select <8 x i1> %101, <8 x float> %615, <8 x float> %private.contiguous.preserve593
  store <8 x float> %700, ptr %private.contiguous.address592, align 4
  %701 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %702 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %703 = add <8 x i64> %702, splat (i64 160)
  %704 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %701, 0
  %705 = insertvalue { <8 x ptr>, <8 x i64> } %704, <8 x i64> %703, 1
  %706 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %707 = extractvalue { <8 x ptr>, <8 x i64> } %705, 1
  %708 = extractelement <8 x ptr> %706, i32 0
  %709 = extractelement <8 x i64> %707, i32 0
  %710 = sub i64 %709, 0
  %711 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %712 = select i1 %711, i64 %710, i64 0
  %private.contiguous.address594 = getelementptr i8, ptr %708, i64 %712
  %private.contiguous.preserve595 = load <8 x float>, ptr %private.contiguous.address594, align 4
  %713 = select <8 x i1> %101, <8 x float> %618, <8 x float> %private.contiguous.preserve595
  store <8 x float> %713, ptr %private.contiguous.address594, align 4
  %714 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %715 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %716 = add <8 x i64> %715, splat (i64 192)
  %717 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %714, 0
  %718 = insertvalue { <8 x ptr>, <8 x i64> } %717, <8 x i64> %716, 1
  %719 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %720 = extractvalue { <8 x ptr>, <8 x i64> } %718, 1
  %721 = extractelement <8 x ptr> %719, i32 0
  %722 = extractelement <8 x i64> %720, i32 0
  %723 = sub i64 %722, 0
  %724 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %725 = select i1 %724, i64 %723, i64 0
  %private.contiguous.address596 = getelementptr i8, ptr %721, i64 %725
  %private.contiguous.preserve597 = load <8 x float>, ptr %private.contiguous.address596, align 4
  %726 = select <8 x i1> %101, <8 x float> %621, <8 x float> %private.contiguous.preserve597
  store <8 x float> %726, ptr %private.contiguous.address596, align 4
  %727 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %728 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %729 = add <8 x i64> %728, splat (i64 224)
  %730 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %727, 0
  %731 = insertvalue { <8 x ptr>, <8 x i64> } %730, <8 x i64> %729, 1
  %732 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %733 = extractvalue { <8 x ptr>, <8 x i64> } %731, 1
  %734 = extractelement <8 x ptr> %732, i32 0
  %735 = extractelement <8 x i64> %733, i32 0
  %736 = sub i64 %735, 0
  %737 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %738 = select i1 %737, i64 %736, i64 0
  %private.contiguous.address598 = getelementptr i8, ptr %734, i64 %738
  %private.contiguous.preserve599 = load <8 x float>, ptr %private.contiguous.address598, align 4
  %739 = select <8 x i1> %101, <8 x float> %624, <8 x float> %private.contiguous.preserve599
  store <8 x float> %739, ptr %private.contiguous.address598, align 4
  %.state600 = load <8 x float>, ptr %.slot76, align 32
  %740 = fsub <8 x float> %.state600, %603
  %.state601 = load <8 x float>, ptr %.slot77, align 32
  %741 = fsub <8 x float> %.state601, %606
  %.state602 = load <8 x float>, ptr %.slot78, align 32
  %742 = fsub <8 x float> %.state602, %609
  %.state603 = load <8 x float>, ptr %.slot79, align 32
  %743 = fsub <8 x float> %.state603, %612
  %.state604 = load <8 x float>, ptr %.slot80, align 32
  %744 = fsub <8 x float> %.state604, %615
  %.state605 = load <8 x float>, ptr %.slot81, align 32
  %745 = fsub <8 x float> %.state605, %618
  %.state606 = load <8 x float>, ptr %.slot82, align 32
  %746 = fsub <8 x float> %.state606, %621
  %.state607 = load <8 x float>, ptr %.slot83, align 32
  %747 = fsub <8 x float> %.state607, %624
  %748 = select <8 x i1> %101, <8 x float> %740, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %748)
  %749 = load <8 x float>, ptr %.spill131, align 32
  %750 = select <8 x i1> %101, <8 x float> %native.exp, <8 x float> %749
  store <8 x float> %750, ptr %.spill131, align 32
  %751 = select <8 x i1> %101, <8 x float> %741, <8 x float> zeroinitializer
  %native.exp608 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %751)
  %752 = load <8 x float>, ptr %.spill132, align 32
  %753 = select <8 x i1> %101, <8 x float> %native.exp608, <8 x float> %752
  store <8 x float> %753, ptr %.spill132, align 32
  %754 = select <8 x i1> %101, <8 x float> %742, <8 x float> zeroinitializer
  %native.exp609 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %754)
  %755 = load <8 x float>, ptr %.spill133, align 32
  %756 = select <8 x i1> %101, <8 x float> %native.exp609, <8 x float> %755
  store <8 x float> %756, ptr %.spill133, align 32
  %757 = select <8 x i1> %101, <8 x float> %743, <8 x float> zeroinitializer
  %native.exp610 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %757)
  %758 = load <8 x float>, ptr %.spill134, align 32
  %759 = select <8 x i1> %101, <8 x float> %native.exp610, <8 x float> %758
  store <8 x float> %759, ptr %.spill134, align 32
  %760 = select <8 x i1> %101, <8 x float> %744, <8 x float> zeroinitializer
  %native.exp611 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %760)
  %761 = load <8 x float>, ptr %.spill135, align 32
  %762 = select <8 x i1> %101, <8 x float> %native.exp611, <8 x float> %761
  store <8 x float> %762, ptr %.spill135, align 32
  %763 = select <8 x i1> %101, <8 x float> %745, <8 x float> zeroinitializer
  %native.exp612 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %763)
  %764 = load <8 x float>, ptr %.spill136, align 32
  %765 = select <8 x i1> %101, <8 x float> %native.exp612, <8 x float> %764
  store <8 x float> %765, ptr %.spill136, align 32
  %766 = select <8 x i1> %101, <8 x float> %746, <8 x float> zeroinitializer
  %native.exp613 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %766)
  %767 = load <8 x float>, ptr %.spill137, align 32
  %768 = select <8 x i1> %101, <8 x float> %native.exp613, <8 x float> %767
  store <8 x float> %768, ptr %.spill137, align 32
  %769 = select <8 x i1> %101, <8 x float> %747, <8 x float> zeroinitializer
  %native.exp614 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %769)
  %770 = load <8 x float>, ptr %.spill138, align 32
  %771 = select <8 x i1> %101, <8 x float> %native.exp614, <8 x float> %770
  store <8 x float> %771, ptr %.spill138, align 32
  %772 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill139, align 64
  %773 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %774 = extractvalue { <8 x ptr>, <8 x i64> } %772, 0
  %775 = select <8 x i1> %101, <8 x ptr> %773, <8 x ptr> %774
  %776 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %777 = extractvalue { <8 x ptr>, <8 x i64> } %772, 1
  %778 = select <8 x i1> %101, <8 x i64> %776, <8 x i64> %777
  %779 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %775, 0
  %780 = insertvalue { <8 x ptr>, <8 x i64> } %779, <8 x i64> %778, 1
  store { <8 x ptr>, <8 x i64> } %780, ptr %tile_snapshot.spill139, align 64
  %781 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %782 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %783 = add <8 x i64> %782, zeroinitializer
  %784 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %781, 0
  %785 = insertvalue { <8 x ptr>, <8 x i64> } %784, <8 x i64> %783, 1
  %786 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %787 = extractvalue { <8 x ptr>, <8 x i64> } %785, 1
  %788 = extractelement <8 x ptr> %786, i32 0
  %789 = extractelement <8 x i64> %787, i32 0
  %790 = sub i64 %789, 0
  %791 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %792 = select i1 %791, i64 %790, i64 0
  %private.contiguous.address615 = getelementptr i8, ptr %788, i64 %792
  %private.contiguous.preserve616 = load <8 x float>, ptr %private.contiguous.address615, align 4
  %793 = select <8 x i1> %101, <8 x float> %native.exp, <8 x float> %private.contiguous.preserve616
  store <8 x float> %793, ptr %private.contiguous.address615, align 4
  %794 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %795 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %796 = add <8 x i64> %795, splat (i64 32)
  %797 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %794, 0
  %798 = insertvalue { <8 x ptr>, <8 x i64> } %797, <8 x i64> %796, 1
  %799 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %800 = extractvalue { <8 x ptr>, <8 x i64> } %798, 1
  %801 = extractelement <8 x ptr> %799, i32 0
  %802 = extractelement <8 x i64> %800, i32 0
  %803 = sub i64 %802, 0
  %804 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %805 = select i1 %804, i64 %803, i64 0
  %private.contiguous.address617 = getelementptr i8, ptr %801, i64 %805
  %private.contiguous.preserve618 = load <8 x float>, ptr %private.contiguous.address617, align 4
  %806 = select <8 x i1> %101, <8 x float> %native.exp608, <8 x float> %private.contiguous.preserve618
  store <8 x float> %806, ptr %private.contiguous.address617, align 4
  %807 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %808 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %809 = add <8 x i64> %808, splat (i64 64)
  %810 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %807, 0
  %811 = insertvalue { <8 x ptr>, <8 x i64> } %810, <8 x i64> %809, 1
  %812 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %813 = extractvalue { <8 x ptr>, <8 x i64> } %811, 1
  %814 = extractelement <8 x ptr> %812, i32 0
  %815 = extractelement <8 x i64> %813, i32 0
  %816 = sub i64 %815, 0
  %817 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %818 = select i1 %817, i64 %816, i64 0
  %private.contiguous.address619 = getelementptr i8, ptr %814, i64 %818
  %private.contiguous.preserve620 = load <8 x float>, ptr %private.contiguous.address619, align 4
  %819 = select <8 x i1> %101, <8 x float> %native.exp609, <8 x float> %private.contiguous.preserve620
  store <8 x float> %819, ptr %private.contiguous.address619, align 4
  %820 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %821 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %822 = add <8 x i64> %821, splat (i64 96)
  %823 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %820, 0
  %824 = insertvalue { <8 x ptr>, <8 x i64> } %823, <8 x i64> %822, 1
  %825 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %826 = extractvalue { <8 x ptr>, <8 x i64> } %824, 1
  %827 = extractelement <8 x ptr> %825, i32 0
  %828 = extractelement <8 x i64> %826, i32 0
  %829 = sub i64 %828, 0
  %830 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %831 = select i1 %830, i64 %829, i64 0
  %private.contiguous.address621 = getelementptr i8, ptr %827, i64 %831
  %private.contiguous.preserve622 = load <8 x float>, ptr %private.contiguous.address621, align 4
  %832 = select <8 x i1> %101, <8 x float> %native.exp610, <8 x float> %private.contiguous.preserve622
  store <8 x float> %832, ptr %private.contiguous.address621, align 4
  %833 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %834 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %835 = add <8 x i64> %834, splat (i64 128)
  %836 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %833, 0
  %837 = insertvalue { <8 x ptr>, <8 x i64> } %836, <8 x i64> %835, 1
  %838 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %839 = extractvalue { <8 x ptr>, <8 x i64> } %837, 1
  %840 = extractelement <8 x ptr> %838, i32 0
  %841 = extractelement <8 x i64> %839, i32 0
  %842 = sub i64 %841, 0
  %843 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %844 = select i1 %843, i64 %842, i64 0
  %private.contiguous.address623 = getelementptr i8, ptr %840, i64 %844
  %private.contiguous.preserve624 = load <8 x float>, ptr %private.contiguous.address623, align 4
  %845 = select <8 x i1> %101, <8 x float> %native.exp611, <8 x float> %private.contiguous.preserve624
  store <8 x float> %845, ptr %private.contiguous.address623, align 4
  %846 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %847 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %848 = add <8 x i64> %847, splat (i64 160)
  %849 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %846, 0
  %850 = insertvalue { <8 x ptr>, <8 x i64> } %849, <8 x i64> %848, 1
  %851 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %852 = extractvalue { <8 x ptr>, <8 x i64> } %850, 1
  %853 = extractelement <8 x ptr> %851, i32 0
  %854 = extractelement <8 x i64> %852, i32 0
  %855 = sub i64 %854, 0
  %856 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %857 = select i1 %856, i64 %855, i64 0
  %private.contiguous.address625 = getelementptr i8, ptr %853, i64 %857
  %private.contiguous.preserve626 = load <8 x float>, ptr %private.contiguous.address625, align 4
  %858 = select <8 x i1> %101, <8 x float> %native.exp612, <8 x float> %private.contiguous.preserve626
  store <8 x float> %858, ptr %private.contiguous.address625, align 4
  %859 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %860 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %861 = add <8 x i64> %860, splat (i64 192)
  %862 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %859, 0
  %863 = insertvalue { <8 x ptr>, <8 x i64> } %862, <8 x i64> %861, 1
  %864 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %865 = extractvalue { <8 x ptr>, <8 x i64> } %863, 1
  %866 = extractelement <8 x ptr> %864, i32 0
  %867 = extractelement <8 x i64> %865, i32 0
  %868 = sub i64 %867, 0
  %869 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %870 = select i1 %869, i64 %868, i64 0
  %private.contiguous.address627 = getelementptr i8, ptr %866, i64 %870
  %private.contiguous.preserve628 = load <8 x float>, ptr %private.contiguous.address627, align 4
  %871 = select <8 x i1> %101, <8 x float> %native.exp613, <8 x float> %private.contiguous.preserve628
  store <8 x float> %871, ptr %private.contiguous.address627, align 4
  %872 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %873 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %874 = add <8 x i64> %873, splat (i64 224)
  %875 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %872, 0
  %876 = insertvalue { <8 x ptr>, <8 x i64> } %875, <8 x i64> %874, 1
  %877 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %878 = extractvalue { <8 x ptr>, <8 x i64> } %876, 1
  %879 = extractelement <8 x ptr> %877, i32 0
  %880 = extractelement <8 x i64> %878, i32 0
  %881 = sub i64 %880, 0
  %882 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %883 = select i1 %882, i64 %881, i64 0
  %private.contiguous.address629 = getelementptr i8, ptr %879, i64 %883
  %private.contiguous.preserve630 = load <8 x float>, ptr %private.contiguous.address629, align 4
  %884 = select <8 x i1> %101, <8 x float> %native.exp614, <8 x float> %private.contiguous.preserve630
  store <8 x float> %884, ptr %private.contiguous.address629, align 4
  %885 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill140, align 64
  %886 = extractvalue { <8 x ptr>, <8 x i64> } %44, 0
  %887 = extractvalue { <8 x ptr>, <8 x i64> } %885, 0
  %888 = select <8 x i1> %101, <8 x ptr> %886, <8 x ptr> %887
  %889 = extractvalue { <8 x ptr>, <8 x i64> } %44, 1
  %890 = extractvalue { <8 x ptr>, <8 x i64> } %885, 1
  %891 = select <8 x i1> %101, <8 x i64> %889, <8 x i64> %890
  %892 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %888, 0
  %893 = insertvalue { <8 x ptr>, <8 x i64> } %892, <8 x i64> %891, 1
  store { <8 x ptr>, <8 x i64> } %893, ptr %tile_snapshot.spill140, align 64
  store i64 0, ptr %.slot141, align 4
  br label %direct.schedule.43

direct.schedule.43:                               ; preds = %direct.schedule.44, %direct.schedule.42
  %.state631 = load i64, ptr %.slot141, align 4
  %894 = icmp slt i64 %.state631, 128
  br i1 %894, label %direct.true632, label %direct.false633

direct.schedule.44:                               ; preds = %direct.true632
  %.state634 = load i64, ptr %.slot141, align 4
  %895 = srem i64 %.state634, 16
  %.state635 = load i64, ptr %.slot141, align 4
  %896 = sdiv i64 %.state635, 16
  %897 = add i64 0, %895
  %898 = mul i64 %897, 8
  %899 = add i64 %898, %896
  %tile_snapshot.spill.load636 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill102, align 64
  %900 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load636, 0
  %901 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load636, 1
  %.splatinsert637 = insertelement <8 x i64> poison, i64 %899, i64 0
  %.splat638 = shufflevector <8 x i64> %.splatinsert637, <8 x i64> poison, <8 x i32> zeroinitializer
  %902 = add <8 x i64> %901, %.splat638
  %903 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %900, 0
  %904 = insertvalue { <8 x ptr>, <8 x i64> } %903, <8 x i64> %902, 1
  %905 = extractvalue { <8 x ptr>, <8 x i64> } %904, 0
  %906 = extractvalue { <8 x ptr>, <8 x i64> } %904, 1
  %907 = getelementptr i8, <8 x ptr> %905, <8 x i64> %906
  %908 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %907, <8 x i1> %101, <8 x i8> zeroinitializer)
  %909 = icmp ne <8 x i8> %908, zeroinitializer
  %910 = add i64 0, %896
  %911 = mul i64 %910, 16
  %912 = add i64 %911, %895
  %913 = srem i64 %912, 16
  %914 = sdiv i64 %912, 16
  %915 = add i64 0, %914
  %916 = mul i64 %915, 16
  %917 = add i64 %916, %913
  %918 = srem i64 %917, 16
  %919 = sdiv i64 %917, 16
  %920 = add i64 0, %919
  %921 = mul i64 %920, 16
  %922 = add i64 %921, %918
  %tile_snapshot.spill.load639 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill104, align 64
  %923 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load639, 0
  %924 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load639, 1
  %.splatinsert640 = insertelement <8 x i64> poison, i64 %922, i64 0
  %.splat641 = shufflevector <8 x i64> %.splatinsert640, <8 x i64> poison, <8 x i32> zeroinitializer
  %925 = mul <8 x i64> %.splat641, splat (i64 32)
  %926 = add <8 x i64> %924, %925
  %927 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %923, 0
  %928 = insertvalue { <8 x ptr>, <8 x i64> } %927, <8 x i64> %926, 1
  %929 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %930 = extractvalue { <8 x ptr>, <8 x i64> } %928, 1
  %931 = extractelement <8 x ptr> %929, i32 0
  %932 = extractelement <8 x i64> %930, i32 0
  %933 = sub i64 %932, 0
  %934 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %935 = select i1 %934, i64 %933, i64 0
  %private.contiguous.address642 = getelementptr i8, ptr %931, i64 %935
  %private.contiguous.load643 = load <8 x float>, ptr %private.contiguous.address642, align 4
  %936 = select <8 x i1> %101, <8 x float> %private.contiguous.load643, <8 x float> zeroinitializer
  %tile_snapshot.spill.load644 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill130, align 64
  %937 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load644, 0
  %938 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load644, 1
  %.splatinsert645 = insertelement <8 x i64> poison, i64 %920, i64 0
  %.splat646 = shufflevector <8 x i64> %.splatinsert645, <8 x i64> poison, <8 x i32> zeroinitializer
  %939 = mul <8 x i64> %.splat646, splat (i64 32)
  %940 = add <8 x i64> %938, %939
  %941 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %937, 0
  %942 = insertvalue { <8 x ptr>, <8 x i64> } %941, <8 x i64> %940, 1
  %943 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %944 = extractvalue { <8 x ptr>, <8 x i64> } %942, 1
  %945 = extractelement <8 x ptr> %943, i32 0
  %946 = extractelement <8 x i64> %944, i32 0
  %947 = sub i64 %946, 0
  %948 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %949 = select i1 %948, i64 %947, i64 0
  %private.contiguous.address647 = getelementptr i8, ptr %945, i64 %949
  %private.contiguous.load648 = load <8 x float>, ptr %private.contiguous.address647, align 4
  %950 = select <8 x i1> %101, <8 x float> %private.contiguous.load648, <8 x float> zeroinitializer
  %951 = fsub <8 x float> %936, %950
  %952 = select <8 x i1> %101, <8 x float> %951, <8 x float> zeroinitializer
  %native.exp649 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %952)
  %953 = select <8 x i1> %909, <8 x float> %native.exp649, <8 x float> zeroinitializer
  %tile_snapshot.spill.load650 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill140, align 64
  %954 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load650, 0
  %955 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load650, 1
  %.state651 = load i64, ptr %.slot141, align 4
  %.splatinsert652 = insertelement <8 x i64> poison, i64 %.state651, i64 0
  %.splat653 = shufflevector <8 x i64> %.splatinsert652, <8 x i64> poison, <8 x i32> zeroinitializer
  %956 = mul <8 x i64> %.splat653, splat (i64 4)
  %957 = add <8 x i64> %955, %956
  %958 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %954, 0
  %959 = insertvalue { <8 x ptr>, <8 x i64> } %958, <8 x i64> %957, 1
  %960 = extractvalue { <8 x ptr>, <8 x i64> } %959, 0
  %961 = extractvalue { <8 x ptr>, <8 x i64> } %959, 1
  %962 = getelementptr i8, <8 x ptr> %960, <8 x i64> %961
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %953, <8 x ptr> align 1 %962, <8 x i1> %101)
  %.state654 = load i64, ptr %.slot141, align 4
  %963 = add i64 %.state654, 1
  store i64 %963, ptr %.slot141, align 4
  br label %direct.schedule.43

direct.schedule.45:                               ; preds = %direct.false633
  %.state655 = load <8 x float>, ptr %.slot84, align 32
  %.spill.load656 = load <8 x float>, ptr %.spill131, align 32
  %964 = fmul <8 x float> %.state655, %.spill.load656
  %965 = load <8 x float>, ptr %.spill142, align 32
  %966 = select <8 x i1> %101, <8 x float> %964, <8 x float> %965
  store <8 x float> %966, ptr %.spill142, align 32
  %.state657 = load <8 x float>, ptr %.slot85, align 32
  %.spill.load658 = load <8 x float>, ptr %.spill132, align 32
  %967 = fmul <8 x float> %.state657, %.spill.load658
  %968 = load <8 x float>, ptr %.spill143, align 32
  %969 = select <8 x i1> %101, <8 x float> %967, <8 x float> %968
  store <8 x float> %969, ptr %.spill143, align 32
  %.state659 = load <8 x float>, ptr %.slot86, align 32
  %.spill.load660 = load <8 x float>, ptr %.spill133, align 32
  %970 = fmul <8 x float> %.state659, %.spill.load660
  %971 = load <8 x float>, ptr %.spill144, align 32
  %972 = select <8 x i1> %101, <8 x float> %970, <8 x float> %971
  store <8 x float> %972, ptr %.spill144, align 32
  %.state661 = load <8 x float>, ptr %.slot87, align 32
  %.spill.load662 = load <8 x float>, ptr %.spill134, align 32
  %973 = fmul <8 x float> %.state661, %.spill.load662
  %974 = load <8 x float>, ptr %.spill145, align 32
  %975 = select <8 x i1> %101, <8 x float> %973, <8 x float> %974
  store <8 x float> %975, ptr %.spill145, align 32
  %.state663 = load <8 x float>, ptr %.slot88, align 32
  %.spill.load664 = load <8 x float>, ptr %.spill135, align 32
  %976 = fmul <8 x float> %.state663, %.spill.load664
  %977 = load <8 x float>, ptr %.spill146, align 32
  %978 = select <8 x i1> %101, <8 x float> %976, <8 x float> %977
  store <8 x float> %978, ptr %.spill146, align 32
  %.state665 = load <8 x float>, ptr %.slot89, align 32
  %.spill.load666 = load <8 x float>, ptr %.spill136, align 32
  %979 = fmul <8 x float> %.state665, %.spill.load666
  %980 = load <8 x float>, ptr %.spill147, align 32
  %981 = select <8 x i1> %101, <8 x float> %979, <8 x float> %980
  store <8 x float> %981, ptr %.spill147, align 32
  %.state667 = load <8 x float>, ptr %.slot90, align 32
  %.spill.load668 = load <8 x float>, ptr %.spill137, align 32
  %982 = fmul <8 x float> %.state667, %.spill.load668
  %983 = load <8 x float>, ptr %.spill148, align 32
  %984 = select <8 x i1> %101, <8 x float> %982, <8 x float> %983
  store <8 x float> %984, ptr %.spill148, align 32
  %.state669 = load <8 x float>, ptr %.slot91, align 32
  %.spill.load670 = load <8 x float>, ptr %.spill138, align 32
  %985 = fmul <8 x float> %.state669, %.spill.load670
  %986 = load <8 x float>, ptr %.spill149, align 32
  %987 = select <8 x i1> %101, <8 x float> %985, <8 x float> %986
  store <8 x float> %987, ptr %.spill149, align 32
  store i64 0, ptr %.slot150, align 4
  %988 = load <8 x float>, ptr %.slot151, align 32
  %989 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %988
  store <8 x float> %989, ptr %.slot151, align 32
  br label %direct.schedule.46

direct.schedule.46:                               ; preds = %direct.schedule.47, %direct.schedule.45
  %.state671 = load i64, ptr %.slot150, align 4
  %990 = icmp slt i64 %.state671, 16
  br i1 %990, label %direct.true672, label %direct.false673

direct.schedule.47:                               ; preds = %direct.true672
  %.state674 = load i64, ptr %.slot150, align 4
  %991 = sdiv i64 %.state674, 1
  %.spill.load675 = load i64, ptr %.spill72, align 4
  %992 = mul i64 %.spill.load675, 1
  %993 = add i64 %992, 0
  %994 = mul i64 %993, 8
  %995 = add i64 %994, 0
  %996 = mul i64 %995, 16
  %997 = add i64 %996, %991
  %tile_snapshot.spill.load676 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill140, align 64
  %998 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load676, 0
  %999 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load676, 1
  %.splatinsert677 = insertelement <8 x i64> poison, i64 %997, i64 0
  %.splat678 = shufflevector <8 x i64> %.splatinsert677, <8 x i64> poison, <8 x i32> zeroinitializer
  %1000 = mul <8 x i64> %.splat678, splat (i64 4)
  %1001 = add <8 x i64> %999, %1000
  %1002 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %998, 0
  %1003 = insertvalue { <8 x ptr>, <8 x i64> } %1002, <8 x i64> %1001, 1
  %1004 = extractvalue { <8 x ptr>, <8 x i64> } %1003, 0
  %1005 = extractvalue { <8 x ptr>, <8 x i64> } %1003, 1
  %1006 = getelementptr i8, <8 x ptr> %1004, <8 x i64> %1005
  %1007 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1006, <8 x i1> %101, <8 x float> zeroinitializer)
  %.state679 = load <8 x float>, ptr %.slot151, align 32
  %1008 = fadd <8 x float> %.state679, %1007
  %.state680 = load i64, ptr %.slot150, align 4
  %1009 = add i64 %.state680, 1
  store i64 %1009, ptr %.slot150, align 4
  %1010 = load <8 x float>, ptr %.slot151, align 32
  %1011 = select <8 x i1> %101, <8 x float> %1008, <8 x float> %1010
  store <8 x float> %1011, ptr %.slot151, align 32
  br label %direct.schedule.46

direct.schedule.48:                               ; preds = %direct.false673
  store i64 0, ptr %.slot152, align 4
  %1012 = load <8 x float>, ptr %.slot153, align 32
  %1013 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %1012
  store <8 x float> %1013, ptr %.slot153, align 32
  br label %direct.schedule.49

direct.schedule.49:                               ; preds = %direct.schedule.50, %direct.schedule.48
  %.state681 = load i64, ptr %.slot152, align 4
  %1014 = icmp slt i64 %.state681, 16
  br i1 %1014, label %direct.true682, label %direct.false683

direct.schedule.50:                               ; preds = %direct.true682
  %.state684 = load i64, ptr %.slot152, align 4
  %1015 = sdiv i64 %.state684, 1
  %.spill.load685 = load i64, ptr %.spill72, align 4
  %1016 = mul i64 %.spill.load685, 1
  %1017 = add i64 %1016, 0
  %1018 = mul i64 %1017, 8
  %1019 = add i64 %1018, 1
  %1020 = mul i64 %1019, 16
  %1021 = add i64 %1020, %1015
  %tile_snapshot.spill.load686 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill140, align 64
  %1022 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load686, 0
  %1023 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load686, 1
  %.splatinsert687 = insertelement <8 x i64> poison, i64 %1021, i64 0
  %.splat688 = shufflevector <8 x i64> %.splatinsert687, <8 x i64> poison, <8 x i32> zeroinitializer
  %1024 = mul <8 x i64> %.splat688, splat (i64 4)
  %1025 = add <8 x i64> %1023, %1024
  %1026 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1022, 0
  %1027 = insertvalue { <8 x ptr>, <8 x i64> } %1026, <8 x i64> %1025, 1
  %1028 = extractvalue { <8 x ptr>, <8 x i64> } %1027, 0
  %1029 = extractvalue { <8 x ptr>, <8 x i64> } %1027, 1
  %1030 = getelementptr i8, <8 x ptr> %1028, <8 x i64> %1029
  %1031 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1030, <8 x i1> %101, <8 x float> zeroinitializer)
  %.state689 = load <8 x float>, ptr %.slot153, align 32
  %1032 = fadd <8 x float> %.state689, %1031
  %.state690 = load i64, ptr %.slot152, align 4
  %1033 = add i64 %.state690, 1
  store i64 %1033, ptr %.slot152, align 4
  %1034 = load <8 x float>, ptr %.slot153, align 32
  %1035 = select <8 x i1> %101, <8 x float> %1032, <8 x float> %1034
  store <8 x float> %1035, ptr %.slot153, align 32
  br label %direct.schedule.49

direct.schedule.51:                               ; preds = %direct.false683
  store i64 0, ptr %.slot154, align 4
  %1036 = load <8 x float>, ptr %.slot155, align 32
  %1037 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %1036
  store <8 x float> %1037, ptr %.slot155, align 32
  br label %direct.schedule.52

direct.schedule.52:                               ; preds = %direct.schedule.53, %direct.schedule.51
  %.state691 = load i64, ptr %.slot154, align 4
  %1038 = icmp slt i64 %.state691, 16
  br i1 %1038, label %direct.true692, label %direct.false693

direct.schedule.53:                               ; preds = %direct.true692
  %.state694 = load i64, ptr %.slot154, align 4
  %1039 = sdiv i64 %.state694, 1
  %.spill.load695 = load i64, ptr %.spill72, align 4
  %1040 = mul i64 %.spill.load695, 1
  %1041 = add i64 %1040, 0
  %1042 = mul i64 %1041, 8
  %1043 = add i64 %1042, 2
  %1044 = mul i64 %1043, 16
  %1045 = add i64 %1044, %1039
  %tile_snapshot.spill.load696 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill140, align 64
  %1046 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load696, 0
  %1047 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load696, 1
  %.splatinsert697 = insertelement <8 x i64> poison, i64 %1045, i64 0
  %.splat698 = shufflevector <8 x i64> %.splatinsert697, <8 x i64> poison, <8 x i32> zeroinitializer
  %1048 = mul <8 x i64> %.splat698, splat (i64 4)
  %1049 = add <8 x i64> %1047, %1048
  %1050 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1046, 0
  %1051 = insertvalue { <8 x ptr>, <8 x i64> } %1050, <8 x i64> %1049, 1
  %1052 = extractvalue { <8 x ptr>, <8 x i64> } %1051, 0
  %1053 = extractvalue { <8 x ptr>, <8 x i64> } %1051, 1
  %1054 = getelementptr i8, <8 x ptr> %1052, <8 x i64> %1053
  %1055 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1054, <8 x i1> %101, <8 x float> zeroinitializer)
  %.state699 = load <8 x float>, ptr %.slot155, align 32
  %1056 = fadd <8 x float> %.state699, %1055
  %.state700 = load i64, ptr %.slot154, align 4
  %1057 = add i64 %.state700, 1
  store i64 %1057, ptr %.slot154, align 4
  %1058 = load <8 x float>, ptr %.slot155, align 32
  %1059 = select <8 x i1> %101, <8 x float> %1056, <8 x float> %1058
  store <8 x float> %1059, ptr %.slot155, align 32
  br label %direct.schedule.52

direct.schedule.54:                               ; preds = %direct.false693
  store i64 0, ptr %.slot156, align 4
  %1060 = load <8 x float>, ptr %.slot157, align 32
  %1061 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %1060
  store <8 x float> %1061, ptr %.slot157, align 32
  br label %direct.schedule.55

direct.schedule.55:                               ; preds = %direct.schedule.56, %direct.schedule.54
  %.state701 = load i64, ptr %.slot156, align 4
  %1062 = icmp slt i64 %.state701, 16
  br i1 %1062, label %direct.true702, label %direct.false703

direct.schedule.56:                               ; preds = %direct.true702
  %.state704 = load i64, ptr %.slot156, align 4
  %1063 = sdiv i64 %.state704, 1
  %.spill.load705 = load i64, ptr %.spill72, align 4
  %1064 = mul i64 %.spill.load705, 1
  %1065 = add i64 %1064, 0
  %1066 = mul i64 %1065, 8
  %1067 = add i64 %1066, 3
  %1068 = mul i64 %1067, 16
  %1069 = add i64 %1068, %1063
  %tile_snapshot.spill.load706 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill140, align 64
  %1070 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load706, 0
  %1071 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load706, 1
  %.splatinsert707 = insertelement <8 x i64> poison, i64 %1069, i64 0
  %.splat708 = shufflevector <8 x i64> %.splatinsert707, <8 x i64> poison, <8 x i32> zeroinitializer
  %1072 = mul <8 x i64> %.splat708, splat (i64 4)
  %1073 = add <8 x i64> %1071, %1072
  %1074 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1070, 0
  %1075 = insertvalue { <8 x ptr>, <8 x i64> } %1074, <8 x i64> %1073, 1
  %1076 = extractvalue { <8 x ptr>, <8 x i64> } %1075, 0
  %1077 = extractvalue { <8 x ptr>, <8 x i64> } %1075, 1
  %1078 = getelementptr i8, <8 x ptr> %1076, <8 x i64> %1077
  %1079 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1078, <8 x i1> %101, <8 x float> zeroinitializer)
  %.state709 = load <8 x float>, ptr %.slot157, align 32
  %1080 = fadd <8 x float> %.state709, %1079
  %.state710 = load i64, ptr %.slot156, align 4
  %1081 = add i64 %.state710, 1
  store i64 %1081, ptr %.slot156, align 4
  %1082 = load <8 x float>, ptr %.slot157, align 32
  %1083 = select <8 x i1> %101, <8 x float> %1080, <8 x float> %1082
  store <8 x float> %1083, ptr %.slot157, align 32
  br label %direct.schedule.55

direct.schedule.57:                               ; preds = %direct.false703
  store i64 0, ptr %.slot158, align 4
  %1084 = load <8 x float>, ptr %.slot159, align 32
  %1085 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %1084
  store <8 x float> %1085, ptr %.slot159, align 32
  br label %direct.schedule.58

direct.schedule.58:                               ; preds = %direct.schedule.59, %direct.schedule.57
  %.state711 = load i64, ptr %.slot158, align 4
  %1086 = icmp slt i64 %.state711, 16
  br i1 %1086, label %direct.true712, label %direct.false713

direct.schedule.59:                               ; preds = %direct.true712
  %.state714 = load i64, ptr %.slot158, align 4
  %1087 = sdiv i64 %.state714, 1
  %.spill.load715 = load i64, ptr %.spill72, align 4
  %1088 = mul i64 %.spill.load715, 1
  %1089 = add i64 %1088, 0
  %1090 = mul i64 %1089, 8
  %1091 = add i64 %1090, 4
  %1092 = mul i64 %1091, 16
  %1093 = add i64 %1092, %1087
  %tile_snapshot.spill.load716 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill140, align 64
  %1094 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load716, 0
  %1095 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load716, 1
  %.splatinsert717 = insertelement <8 x i64> poison, i64 %1093, i64 0
  %.splat718 = shufflevector <8 x i64> %.splatinsert717, <8 x i64> poison, <8 x i32> zeroinitializer
  %1096 = mul <8 x i64> %.splat718, splat (i64 4)
  %1097 = add <8 x i64> %1095, %1096
  %1098 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1094, 0
  %1099 = insertvalue { <8 x ptr>, <8 x i64> } %1098, <8 x i64> %1097, 1
  %1100 = extractvalue { <8 x ptr>, <8 x i64> } %1099, 0
  %1101 = extractvalue { <8 x ptr>, <8 x i64> } %1099, 1
  %1102 = getelementptr i8, <8 x ptr> %1100, <8 x i64> %1101
  %1103 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1102, <8 x i1> %101, <8 x float> zeroinitializer)
  %.state719 = load <8 x float>, ptr %.slot159, align 32
  %1104 = fadd <8 x float> %.state719, %1103
  %.state720 = load i64, ptr %.slot158, align 4
  %1105 = add i64 %.state720, 1
  store i64 %1105, ptr %.slot158, align 4
  %1106 = load <8 x float>, ptr %.slot159, align 32
  %1107 = select <8 x i1> %101, <8 x float> %1104, <8 x float> %1106
  store <8 x float> %1107, ptr %.slot159, align 32
  br label %direct.schedule.58

direct.schedule.60:                               ; preds = %direct.false713
  store i64 0, ptr %.slot160, align 4
  %1108 = load <8 x float>, ptr %.slot161, align 32
  %1109 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %1108
  store <8 x float> %1109, ptr %.slot161, align 32
  br label %direct.schedule.61

direct.schedule.61:                               ; preds = %direct.schedule.62, %direct.schedule.60
  %.state721 = load i64, ptr %.slot160, align 4
  %1110 = icmp slt i64 %.state721, 16
  br i1 %1110, label %direct.true722, label %direct.false723

direct.schedule.62:                               ; preds = %direct.true722
  %.state724 = load i64, ptr %.slot160, align 4
  %1111 = sdiv i64 %.state724, 1
  %.spill.load725 = load i64, ptr %.spill72, align 4
  %1112 = mul i64 %.spill.load725, 1
  %1113 = add i64 %1112, 0
  %1114 = mul i64 %1113, 8
  %1115 = add i64 %1114, 5
  %1116 = mul i64 %1115, 16
  %1117 = add i64 %1116, %1111
  %tile_snapshot.spill.load726 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill140, align 64
  %1118 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load726, 0
  %1119 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load726, 1
  %.splatinsert727 = insertelement <8 x i64> poison, i64 %1117, i64 0
  %.splat728 = shufflevector <8 x i64> %.splatinsert727, <8 x i64> poison, <8 x i32> zeroinitializer
  %1120 = mul <8 x i64> %.splat728, splat (i64 4)
  %1121 = add <8 x i64> %1119, %1120
  %1122 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1118, 0
  %1123 = insertvalue { <8 x ptr>, <8 x i64> } %1122, <8 x i64> %1121, 1
  %1124 = extractvalue { <8 x ptr>, <8 x i64> } %1123, 0
  %1125 = extractvalue { <8 x ptr>, <8 x i64> } %1123, 1
  %1126 = getelementptr i8, <8 x ptr> %1124, <8 x i64> %1125
  %1127 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1126, <8 x i1> %101, <8 x float> zeroinitializer)
  %.state729 = load <8 x float>, ptr %.slot161, align 32
  %1128 = fadd <8 x float> %.state729, %1127
  %.state730 = load i64, ptr %.slot160, align 4
  %1129 = add i64 %.state730, 1
  store i64 %1129, ptr %.slot160, align 4
  %1130 = load <8 x float>, ptr %.slot161, align 32
  %1131 = select <8 x i1> %101, <8 x float> %1128, <8 x float> %1130
  store <8 x float> %1131, ptr %.slot161, align 32
  br label %direct.schedule.61

direct.schedule.63:                               ; preds = %direct.false723
  store i64 0, ptr %.slot162, align 4
  %1132 = load <8 x float>, ptr %.slot163, align 32
  %1133 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %1132
  store <8 x float> %1133, ptr %.slot163, align 32
  br label %direct.schedule.64

direct.schedule.64:                               ; preds = %direct.schedule.65, %direct.schedule.63
  %.state731 = load i64, ptr %.slot162, align 4
  %1134 = icmp slt i64 %.state731, 16
  br i1 %1134, label %direct.true732, label %direct.false733

direct.schedule.65:                               ; preds = %direct.true732
  %.state734 = load i64, ptr %.slot162, align 4
  %1135 = sdiv i64 %.state734, 1
  %.spill.load735 = load i64, ptr %.spill72, align 4
  %1136 = mul i64 %.spill.load735, 1
  %1137 = add i64 %1136, 0
  %1138 = mul i64 %1137, 8
  %1139 = add i64 %1138, 6
  %1140 = mul i64 %1139, 16
  %1141 = add i64 %1140, %1135
  %tile_snapshot.spill.load736 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill140, align 64
  %1142 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load736, 0
  %1143 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load736, 1
  %.splatinsert737 = insertelement <8 x i64> poison, i64 %1141, i64 0
  %.splat738 = shufflevector <8 x i64> %.splatinsert737, <8 x i64> poison, <8 x i32> zeroinitializer
  %1144 = mul <8 x i64> %.splat738, splat (i64 4)
  %1145 = add <8 x i64> %1143, %1144
  %1146 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1142, 0
  %1147 = insertvalue { <8 x ptr>, <8 x i64> } %1146, <8 x i64> %1145, 1
  %1148 = extractvalue { <8 x ptr>, <8 x i64> } %1147, 0
  %1149 = extractvalue { <8 x ptr>, <8 x i64> } %1147, 1
  %1150 = getelementptr i8, <8 x ptr> %1148, <8 x i64> %1149
  %1151 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1150, <8 x i1> %101, <8 x float> zeroinitializer)
  %.state739 = load <8 x float>, ptr %.slot163, align 32
  %1152 = fadd <8 x float> %.state739, %1151
  %.state740 = load i64, ptr %.slot162, align 4
  %1153 = add i64 %.state740, 1
  store i64 %1153, ptr %.slot162, align 4
  %1154 = load <8 x float>, ptr %.slot163, align 32
  %1155 = select <8 x i1> %101, <8 x float> %1152, <8 x float> %1154
  store <8 x float> %1155, ptr %.slot163, align 32
  br label %direct.schedule.64

direct.schedule.66:                               ; preds = %direct.false733
  store i64 0, ptr %.slot164, align 4
  %1156 = load <8 x float>, ptr %.slot165, align 32
  %1157 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %1156
  store <8 x float> %1157, ptr %.slot165, align 32
  br label %direct.schedule.67

direct.schedule.67:                               ; preds = %direct.schedule.68, %direct.schedule.66
  %.state741 = load i64, ptr %.slot164, align 4
  %1158 = icmp slt i64 %.state741, 16
  br i1 %1158, label %direct.true742, label %direct.false743

direct.schedule.68:                               ; preds = %direct.true742
  %.state744 = load i64, ptr %.slot164, align 4
  %1159 = sdiv i64 %.state744, 1
  %.spill.load745 = load i64, ptr %.spill72, align 4
  %1160 = mul i64 %.spill.load745, 1
  %1161 = add i64 %1160, 0
  %1162 = mul i64 %1161, 8
  %1163 = add i64 %1162, 7
  %1164 = mul i64 %1163, 16
  %1165 = add i64 %1164, %1159
  %tile_snapshot.spill.load746 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill140, align 64
  %1166 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load746, 0
  %1167 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load746, 1
  %.splatinsert747 = insertelement <8 x i64> poison, i64 %1165, i64 0
  %.splat748 = shufflevector <8 x i64> %.splatinsert747, <8 x i64> poison, <8 x i32> zeroinitializer
  %1168 = mul <8 x i64> %.splat748, splat (i64 4)
  %1169 = add <8 x i64> %1167, %1168
  %1170 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1166, 0
  %1171 = insertvalue { <8 x ptr>, <8 x i64> } %1170, <8 x i64> %1169, 1
  %1172 = extractvalue { <8 x ptr>, <8 x i64> } %1171, 0
  %1173 = extractvalue { <8 x ptr>, <8 x i64> } %1171, 1
  %1174 = getelementptr i8, <8 x ptr> %1172, <8 x i64> %1173
  %1175 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1174, <8 x i1> %101, <8 x float> zeroinitializer)
  %.state749 = load <8 x float>, ptr %.slot165, align 32
  %1176 = fadd <8 x float> %.state749, %1175
  %.state750 = load i64, ptr %.slot164, align 4
  %1177 = add i64 %.state750, 1
  store i64 %1177, ptr %.slot164, align 4
  %1178 = load <8 x float>, ptr %.slot165, align 32
  %1179 = select <8 x i1> %101, <8 x float> %1176, <8 x float> %1178
  store <8 x float> %1179, ptr %.slot165, align 32
  br label %direct.schedule.67

direct.schedule.69:                               ; preds = %direct.false743
  %.spill.load751 = load <8 x float>, ptr %.spill142, align 32
  %.state752 = load <8 x float>, ptr %.slot151, align 32
  %1180 = fadd <8 x float> %.spill.load751, %.state752
  %1181 = load <8 x float>, ptr %.spill166, align 32
  %1182 = select <8 x i1> %101, <8 x float> %1180, <8 x float> %1181
  store <8 x float> %1182, ptr %.spill166, align 32
  %.spill.load753 = load <8 x float>, ptr %.spill143, align 32
  %.state754 = load <8 x float>, ptr %.slot153, align 32
  %1183 = fadd <8 x float> %.spill.load753, %.state754
  %1184 = load <8 x float>, ptr %.spill167, align 32
  %1185 = select <8 x i1> %101, <8 x float> %1183, <8 x float> %1184
  store <8 x float> %1185, ptr %.spill167, align 32
  %.spill.load755 = load <8 x float>, ptr %.spill144, align 32
  %.state756 = load <8 x float>, ptr %.slot155, align 32
  %1186 = fadd <8 x float> %.spill.load755, %.state756
  %1187 = load <8 x float>, ptr %.spill168, align 32
  %1188 = select <8 x i1> %101, <8 x float> %1186, <8 x float> %1187
  store <8 x float> %1188, ptr %.spill168, align 32
  %.spill.load757 = load <8 x float>, ptr %.spill145, align 32
  %.state758 = load <8 x float>, ptr %.slot157, align 32
  %1189 = fadd <8 x float> %.spill.load757, %.state758
  %1190 = load <8 x float>, ptr %.spill169, align 32
  %1191 = select <8 x i1> %101, <8 x float> %1189, <8 x float> %1190
  store <8 x float> %1191, ptr %.spill169, align 32
  %.spill.load759 = load <8 x float>, ptr %.spill146, align 32
  %.state760 = load <8 x float>, ptr %.slot159, align 32
  %1192 = fadd <8 x float> %.spill.load759, %.state760
  %1193 = load <8 x float>, ptr %.spill170, align 32
  %1194 = select <8 x i1> %101, <8 x float> %1192, <8 x float> %1193
  store <8 x float> %1194, ptr %.spill170, align 32
  %.spill.load761 = load <8 x float>, ptr %.spill147, align 32
  %.state762 = load <8 x float>, ptr %.slot161, align 32
  %1195 = fadd <8 x float> %.spill.load761, %.state762
  %1196 = load <8 x float>, ptr %.spill171, align 32
  %1197 = select <8 x i1> %101, <8 x float> %1195, <8 x float> %1196
  store <8 x float> %1197, ptr %.spill171, align 32
  %.spill.load763 = load <8 x float>, ptr %.spill148, align 32
  %.state764 = load <8 x float>, ptr %.slot163, align 32
  %1198 = fadd <8 x float> %.spill.load763, %.state764
  %1199 = load <8 x float>, ptr %.spill172, align 32
  %1200 = select <8 x i1> %101, <8 x float> %1198, <8 x float> %1199
  store <8 x float> %1200, ptr %.spill172, align 32
  %.spill.load765 = load <8 x float>, ptr %.spill149, align 32
  %.state766 = load <8 x float>, ptr %.slot165, align 32
  %1201 = fadd <8 x float> %.spill.load765, %.state766
  %1202 = load <8 x float>, ptr %.spill173, align 32
  %1203 = select <8 x i1> %101, <8 x float> %1201, <8 x float> %1202
  store <8 x float> %1203, ptr %.spill173, align 32
  %1204 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill174, align 64
  %1205 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %1206 = extractvalue { <8 x ptr>, <8 x i64> } %1204, 0
  %1207 = select <8 x i1> %101, <8 x ptr> %1205, <8 x ptr> %1206
  %1208 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %1209 = extractvalue { <8 x ptr>, <8 x i64> } %1204, 1
  %1210 = select <8 x i1> %101, <8 x i64> %1208, <8 x i64> %1209
  %1211 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1207, 0
  %1212 = insertvalue { <8 x ptr>, <8 x i64> } %1211, <8 x i64> %1210, 1
  store { <8 x ptr>, <8 x i64> } %1212, ptr %tile_snapshot.spill174, align 64
  store i64 0, ptr %.slot175, align 4
  br label %direct.schedule.70

direct.schedule.70:                               ; preds = %direct.schedule.71, %direct.schedule.69
  %.state767 = load i64, ptr %.slot175, align 4
  %1213 = icmp slt i64 %.state767, 384
  br i1 %1213, label %direct.true768, label %direct.false769

direct.schedule.71:                               ; preds = %direct.true768
  %.state770 = load i64, ptr %.slot175, align 4
  %1214 = srem i64 %.state770, 48
  %.state771 = load i64, ptr %.slot175, align 4
  %1215 = sdiv i64 %.state771, 48
  %1216 = add i64 0, %1215
  %1217 = mul i64 %1216, 48
  %1218 = add i64 %1217, %1214
  %tile_snapshot.spill.load772 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill73, align 64
  %1219 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load772, 0
  %1220 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load772, 1
  %.splatinsert773 = insertelement <8 x i64> poison, i64 %1218, i64 0
  %.splat774 = shufflevector <8 x i64> %.splatinsert773, <8 x i64> poison, <8 x i32> zeroinitializer
  %1221 = mul <8 x i64> %.splat774, splat (i64 32)
  %1222 = add <8 x i64> %1220, %1221
  %1223 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1219, 0
  %1224 = insertvalue { <8 x ptr>, <8 x i64> } %1223, <8 x i64> %1222, 1
  %1225 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1226 = extractvalue { <8 x ptr>, <8 x i64> } %1224, 1
  %1227 = extractelement <8 x ptr> %1225, i32 0
  %1228 = extractelement <8 x i64> %1226, i32 0
  %1229 = sub i64 %1228, 0
  %1230 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1231 = select i1 %1230, i64 %1229, i64 0
  %private.contiguous.address775 = getelementptr i8, ptr %1227, i64 %1231
  %private.contiguous.load776 = load <8 x float>, ptr %private.contiguous.address775, align 4
  %1232 = select <8 x i1> %101, <8 x float> %private.contiguous.load776, <8 x float> zeroinitializer
  %tile_snapshot.spill.load777 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill139, align 64
  %1233 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load777, 0
  %1234 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load777, 1
  %.splatinsert778 = insertelement <8 x i64> poison, i64 %1216, i64 0
  %.splat779 = shufflevector <8 x i64> %.splatinsert778, <8 x i64> poison, <8 x i32> zeroinitializer
  %1235 = mul <8 x i64> %.splat779, splat (i64 32)
  %1236 = add <8 x i64> %1234, %1235
  %1237 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1233, 0
  %1238 = insertvalue { <8 x ptr>, <8 x i64> } %1237, <8 x i64> %1236, 1
  %1239 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %1240 = extractvalue { <8 x ptr>, <8 x i64> } %1238, 1
  %1241 = extractelement <8 x ptr> %1239, i32 0
  %1242 = extractelement <8 x i64> %1240, i32 0
  %1243 = sub i64 %1242, 0
  %1244 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1245 = select i1 %1244, i64 %1243, i64 0
  %private.contiguous.address780 = getelementptr i8, ptr %1241, i64 %1245
  %private.contiguous.load781 = load <8 x float>, ptr %private.contiguous.address780, align 4
  %1246 = select <8 x i1> %101, <8 x float> %private.contiguous.load781, <8 x float> zeroinitializer
  %1247 = fmul <8 x float> %1232, %1246
  %tile_snapshot.spill.load782 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill174, align 64
  %1248 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load782, 0
  %1249 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load782, 1
  %.state783 = load i64, ptr %.slot175, align 4
  %.splatinsert784 = insertelement <8 x i64> poison, i64 %.state783, i64 0
  %.splat785 = shufflevector <8 x i64> %.splatinsert784, <8 x i64> poison, <8 x i32> zeroinitializer
  %1250 = mul <8 x i64> %.splat785, splat (i64 4)
  %1251 = add <8 x i64> %1249, %1250
  %1252 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1248, 0
  %1253 = insertvalue { <8 x ptr>, <8 x i64> } %1252, <8 x i64> %1251, 1
  %1254 = extractvalue { <8 x ptr>, <8 x i64> } %1253, 0
  %1255 = extractvalue { <8 x ptr>, <8 x i64> } %1253, 1
  %1256 = getelementptr i8, <8 x ptr> %1254, <8 x i64> %1255
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1247, <8 x ptr> align 1 %1256, <8 x i1> %101)
  %.state786 = load i64, ptr %.slot175, align 4
  %1257 = add i64 %.state786, 1
  store i64 %1257, ptr %.slot175, align 4
  br label %direct.schedule.70

direct.schedule.72:                               ; preds = %direct.false769
  %1258 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill176, align 64
  %1259 = extractvalue { <8 x ptr>, <8 x i64> } %50, 0
  %1260 = extractvalue { <8 x ptr>, <8 x i64> } %1258, 0
  %1261 = select <8 x i1> %101, <8 x ptr> %1259, <8 x ptr> %1260
  %1262 = extractvalue { <8 x ptr>, <8 x i64> } %50, 1
  %1263 = extractvalue { <8 x ptr>, <8 x i64> } %1258, 1
  %1264 = select <8 x i1> %101, <8 x i64> %1262, <8 x i64> %1263
  %1265 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1261, 0
  %1266 = insertvalue { <8 x ptr>, <8 x i64> } %1265, <8 x i64> %1264, 1
  store { <8 x ptr>, <8 x i64> } %1266, ptr %tile_snapshot.spill176, align 64
  %tile_snapshot.spill.load787 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill140, align 64
  %tile_snapshot.spill.load788 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %tile_snapshot.spill.load789 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill174, align 64
  %1267 = extractelement <8 x i1> %101, i64 0
  br i1 %1267, label %mma.active790, label %mma.continue791

direct.schedule.73:                               ; preds = %direct.schedule.74, %mma.continue805
  %.state806 = load i64, ptr %.slot177, align 4
  %1268 = icmp slt i64 %.state806, 384
  br i1 %1268, label %direct.true807, label %direct.false808

direct.schedule.74:                               ; preds = %direct.true807
  %tile_snapshot.spill.load809 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill176, align 64
  %1269 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load809, 0
  %1270 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load809, 1
  %.state810 = load i64, ptr %.slot177, align 4
  %.splatinsert811 = insertelement <8 x i64> poison, i64 %.state810, i64 0
  %.splat812 = shufflevector <8 x i64> %.splatinsert811, <8 x i64> poison, <8 x i32> zeroinitializer
  %1271 = mul <8 x i64> %.splat812, splat (i64 4)
  %1272 = add <8 x i64> %1270, %1271
  %1273 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1269, 0
  %1274 = insertvalue { <8 x ptr>, <8 x i64> } %1273, <8 x i64> %1272, 1
  %1275 = extractvalue { <8 x ptr>, <8 x i64> } %1274, 0
  %1276 = extractvalue { <8 x ptr>, <8 x i64> } %1274, 1
  %1277 = getelementptr i8, <8 x ptr> %1275, <8 x i64> %1276
  %1278 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1277, <8 x i1> %101, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load813 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill74, align 64
  %1279 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load813, 0
  %1280 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load813, 1
  %.state814 = load i64, ptr %.slot177, align 4
  %.splatinsert815 = insertelement <8 x i64> poison, i64 %.state814, i64 0
  %.splat816 = shufflevector <8 x i64> %.splatinsert815, <8 x i64> poison, <8 x i32> zeroinitializer
  %1281 = mul <8 x i64> %.splat816, splat (i64 32)
  %1282 = add <8 x i64> %1280, %1281
  %1283 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1279, 0
  %1284 = insertvalue { <8 x ptr>, <8 x i64> } %1283, <8 x i64> %1282, 1
  %1285 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1286 = extractvalue { <8 x ptr>, <8 x i64> } %1284, 1
  %1287 = extractelement <8 x ptr> %1285, i32 0
  %1288 = extractelement <8 x i64> %1286, i32 0
  %1289 = sub i64 %1288, 0
  %1290 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1291 = select i1 %1290, i64 %1289, i64 0
  %private.contiguous.address817 = getelementptr i8, ptr %1287, i64 %1291
  %private.contiguous.preserve818 = load <8 x float>, ptr %private.contiguous.address817, align 4
  %1292 = select <8 x i1> %101, <8 x float> %1278, <8 x float> %private.contiguous.preserve818
  store <8 x float> %1292, ptr %private.contiguous.address817, align 4
  %.state819 = load i64, ptr %.slot177, align 4
  %1293 = add i64 %.state819, 1
  store i64 %1293, ptr %.slot177, align 4
  br label %direct.schedule.73

direct.schedule.75:                               ; preds = %direct.false808
  store i64 0, ptr %.slot178, align 4
  br label %direct.schedule.76

direct.schedule.76:                               ; preds = %direct.schedule.77, %direct.schedule.75
  %.state820 = load i64, ptr %.slot178, align 4
  %1294 = icmp slt i64 %.state820, 384
  br i1 %1294, label %direct.true821, label %direct.false822

direct.schedule.77:                               ; preds = %direct.true821
  %tile_snapshot.spill.load823 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill74, align 64
  %1295 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load823, 0
  %1296 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load823, 1
  %.state824 = load i64, ptr %.slot178, align 4
  %.splatinsert825 = insertelement <8 x i64> poison, i64 %.state824, i64 0
  %.splat826 = shufflevector <8 x i64> %.splatinsert825, <8 x i64> poison, <8 x i32> zeroinitializer
  %1297 = mul <8 x i64> %.splat826, splat (i64 32)
  %1298 = add <8 x i64> %1296, %1297
  %1299 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1295, 0
  %1300 = insertvalue { <8 x ptr>, <8 x i64> } %1299, <8 x i64> %1298, 1
  %1301 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1302 = extractvalue { <8 x ptr>, <8 x i64> } %1300, 1
  %1303 = extractelement <8 x ptr> %1301, i32 0
  %1304 = extractelement <8 x i64> %1302, i32 0
  %1305 = sub i64 %1304, 0
  %1306 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1307 = select i1 %1306, i64 %1305, i64 0
  %private.contiguous.address827 = getelementptr i8, ptr %1303, i64 %1307
  %private.contiguous.load828 = load <8 x float>, ptr %private.contiguous.address827, align 4
  %1308 = select <8 x i1> %101, <8 x float> %private.contiguous.load828, <8 x float> zeroinitializer
  %tile_snapshot.spill.load829 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill73, align 64
  %1309 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load829, 0
  %1310 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load829, 1
  %.state830 = load i64, ptr %.slot178, align 4
  %.splatinsert831 = insertelement <8 x i64> poison, i64 %.state830, i64 0
  %.splat832 = shufflevector <8 x i64> %.splatinsert831, <8 x i64> poison, <8 x i32> zeroinitializer
  %1311 = mul <8 x i64> %.splat832, splat (i64 32)
  %1312 = add <8 x i64> %1310, %1311
  %1313 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1309, 0
  %1314 = insertvalue { <8 x ptr>, <8 x i64> } %1313, <8 x i64> %1312, 1
  %1315 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1316 = extractvalue { <8 x ptr>, <8 x i64> } %1314, 1
  %1317 = extractelement <8 x ptr> %1315, i32 0
  %1318 = extractelement <8 x i64> %1316, i32 0
  %1319 = sub i64 %1318, 0
  %1320 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1321 = select i1 %1320, i64 %1319, i64 0
  %private.contiguous.address833 = getelementptr i8, ptr %1317, i64 %1321
  %private.contiguous.preserve834 = load <8 x float>, ptr %private.contiguous.address833, align 4
  %1322 = select <8 x i1> %101, <8 x float> %1308, <8 x float> %private.contiguous.preserve834
  store <8 x float> %1322, ptr %private.contiguous.address833, align 4
  %.state835 = load i64, ptr %.slot178, align 4
  %1323 = add i64 %.state835, 1
  store i64 %1323, ptr %.slot178, align 4
  br label %direct.schedule.76

direct.schedule.78:                               ; preds = %direct.false822
  %.state836 = load i64, ptr %.slot75, align 4
  %1324 = add i64 %.state836, 1
  %.spill.load837 = load <8 x float>, ptr %.spill122, align 32
  %.spill.load838 = load <8 x float>, ptr %.spill123, align 32
  %.spill.load839 = load <8 x float>, ptr %.spill124, align 32
  %.spill.load840 = load <8 x float>, ptr %.spill125, align 32
  %.spill.load841 = load <8 x float>, ptr %.spill126, align 32
  %.spill.load842 = load <8 x float>, ptr %.spill127, align 32
  %.spill.load843 = load <8 x float>, ptr %.spill128, align 32
  %.spill.load844 = load <8 x float>, ptr %.spill129, align 32
  %.spill.load845 = load <8 x float>, ptr %.spill166, align 32
  %.spill.load846 = load <8 x float>, ptr %.spill167, align 32
  %.spill.load847 = load <8 x float>, ptr %.spill168, align 32
  %.spill.load848 = load <8 x float>, ptr %.spill169, align 32
  %.spill.load849 = load <8 x float>, ptr %.spill170, align 32
  %.spill.load850 = load <8 x float>, ptr %.spill171, align 32
  %.spill.load851 = load <8 x float>, ptr %.spill172, align 32
  %.spill.load852 = load <8 x float>, ptr %.spill173, align 32
  store i64 %1324, ptr %.slot75, align 4
  %1325 = load <8 x float>, ptr %.slot76, align 32
  %1326 = select <8 x i1> %101, <8 x float> %.spill.load837, <8 x float> %1325
  store <8 x float> %1326, ptr %.slot76, align 32
  %1327 = load <8 x float>, ptr %.slot77, align 32
  %1328 = select <8 x i1> %101, <8 x float> %.spill.load838, <8 x float> %1327
  store <8 x float> %1328, ptr %.slot77, align 32
  %1329 = load <8 x float>, ptr %.slot78, align 32
  %1330 = select <8 x i1> %101, <8 x float> %.spill.load839, <8 x float> %1329
  store <8 x float> %1330, ptr %.slot78, align 32
  %1331 = load <8 x float>, ptr %.slot79, align 32
  %1332 = select <8 x i1> %101, <8 x float> %.spill.load840, <8 x float> %1331
  store <8 x float> %1332, ptr %.slot79, align 32
  %1333 = load <8 x float>, ptr %.slot80, align 32
  %1334 = select <8 x i1> %101, <8 x float> %.spill.load841, <8 x float> %1333
  store <8 x float> %1334, ptr %.slot80, align 32
  %1335 = load <8 x float>, ptr %.slot81, align 32
  %1336 = select <8 x i1> %101, <8 x float> %.spill.load842, <8 x float> %1335
  store <8 x float> %1336, ptr %.slot81, align 32
  %1337 = load <8 x float>, ptr %.slot82, align 32
  %1338 = select <8 x i1> %101, <8 x float> %.spill.load843, <8 x float> %1337
  store <8 x float> %1338, ptr %.slot82, align 32
  %1339 = load <8 x float>, ptr %.slot83, align 32
  %1340 = select <8 x i1> %101, <8 x float> %.spill.load844, <8 x float> %1339
  store <8 x float> %1340, ptr %.slot83, align 32
  %1341 = load <8 x float>, ptr %.slot84, align 32
  %1342 = select <8 x i1> %101, <8 x float> %.spill.load845, <8 x float> %1341
  store <8 x float> %1342, ptr %.slot84, align 32
  %1343 = load <8 x float>, ptr %.slot85, align 32
  %1344 = select <8 x i1> %101, <8 x float> %.spill.load846, <8 x float> %1343
  store <8 x float> %1344, ptr %.slot85, align 32
  %1345 = load <8 x float>, ptr %.slot86, align 32
  %1346 = select <8 x i1> %101, <8 x float> %.spill.load847, <8 x float> %1345
  store <8 x float> %1346, ptr %.slot86, align 32
  %1347 = load <8 x float>, ptr %.slot87, align 32
  %1348 = select <8 x i1> %101, <8 x float> %.spill.load848, <8 x float> %1347
  store <8 x float> %1348, ptr %.slot87, align 32
  %1349 = load <8 x float>, ptr %.slot88, align 32
  %1350 = select <8 x i1> %101, <8 x float> %.spill.load849, <8 x float> %1349
  store <8 x float> %1350, ptr %.slot88, align 32
  %1351 = load <8 x float>, ptr %.slot89, align 32
  %1352 = select <8 x i1> %101, <8 x float> %.spill.load850, <8 x float> %1351
  store <8 x float> %1352, ptr %.slot89, align 32
  %1353 = load <8 x float>, ptr %.slot90, align 32
  %1354 = select <8 x i1> %101, <8 x float> %.spill.load851, <8 x float> %1353
  store <8 x float> %1354, ptr %.slot90, align 32
  %1355 = load <8 x float>, ptr %.slot91, align 32
  %1356 = select <8 x i1> %101, <8 x float> %.spill.load852, <8 x float> %1355
  store <8 x float> %1356, ptr %.slot91, align 32
  br label %direct.schedule.4

direct.schedule.79:                               ; preds = %direct.false246
  store i64 0, ptr %.slot179, align 4
  br label %direct.schedule.80

direct.schedule.80:                               ; preds = %direct.schedule.83, %direct.schedule.79
  %.state853 = load i64, ptr %.slot179, align 4
  %1357 = icmp slt i64 %.state853, 768
  br i1 %1357, label %direct.true854, label %direct.false855

direct.schedule.81:                               ; preds = %direct.true854
  %.state856 = load i64, ptr %.slot179, align 4
  %1358 = srem i64 %.state856, 48
  %.state857 = load i64, ptr %.slot179, align 4
  %1359 = sdiv i64 %.state857, 48
  %.spill.load858 = load i64, ptr %.spill71, align 4
  %1360 = add i64 %.spill.load858, 0
  %.spill.load859 = load <8 x i64>, ptr %.spill70, align 64
  %1361 = add <8 x i64> %.spill.load859, zeroinitializer
  %1362 = mul i64 %1360, 2
  %.splatinsert860 = insertelement <8 x i64> poison, i64 %1362, i64 0
  %.splat861 = shufflevector <8 x i64> %.splatinsert860, <8 x i64> poison, <8 x i32> zeroinitializer
  %1363 = add <8 x i64> %.splat861, %1361
  %.spill.load862 = load i64, ptr %.spill92, align 4
  %1364 = add i64 %.spill.load862, %1359
  %1365 = mul <8 x i64> %1363, splat (i64 129)
  %.splatinsert863 = insertelement <8 x i64> poison, i64 %1364, i64 0
  %.splat864 = shufflevector <8 x i64> %.splatinsert863, <8 x i64> poison, <8 x i32> zeroinitializer
  %1366 = add <8 x i64> %1365, %.splat864
  %1367 = icmp sge i64 %1364, 0
  %1368 = and i1 true, %1367
  %1369 = icmp slt i64 %1364, 129
  %1370 = and i1 %1368, %1369
  %1371 = add i64 0, %1358
  %1372 = mul <8 x i64> %1366, splat (i64 48)
  %.splatinsert865 = insertelement <8 x i64> poison, i64 %1371, i64 0
  %.splat866 = shufflevector <8 x i64> %.splatinsert865, <8 x i64> poison, <8 x i32> zeroinitializer
  %1373 = add <8 x i64> %1372, %.splat866
  %1374 = load <8 x i64>, ptr %.spill180, align 64
  %1375 = select <8 x i1> %101, <8 x i64> %1373, <8 x i64> %1374
  store <8 x i64> %1375, ptr %.spill180, align 64
  br i1 %1370, label %direct.true867, label %direct.false868

direct.schedule.82:                               ; preds = %direct.true867
  %.spill.load869 = load <8 x i64>, ptr %.spill180, align 64
  %1376 = extractvalue { ptr, i64 } %71, 0
  %1377 = extractelement <8 x i64> %.spill.load869, i32 0
  %1378 = mul i64 %1377, 4
  %1379 = getelementptr i8, ptr %1376, i64 %1378
  %1380 = load float, ptr %1379, align 4
  %.splatinsert870 = insertelement <8 x float> poison, float %1380, i64 0
  %.splat871 = shufflevector <8 x float> %.splatinsert870, <8 x float> poison, <8 x i32> zeroinitializer
  %1381 = load <8 x float>, ptr %.slot181, align 32
  %1382 = select <8 x i1> %101, <8 x float> %.splat871, <8 x float> %1381
  store <8 x float> %1382, ptr %.slot181, align 32
  br label %direct.schedule.83

direct.schedule.83:                               ; preds = %direct.schedule.82, %direct.false868
  %tile_snapshot.spill.load872 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %1383 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load872, 0
  %1384 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load872, 1
  %.state873 = load i64, ptr %.slot179, align 4
  %.splatinsert874 = insertelement <8 x i64> poison, i64 %.state873, i64 0
  %.splat875 = shufflevector <8 x i64> %.splatinsert874, <8 x i64> poison, <8 x i32> zeroinitializer
  %1385 = mul <8 x i64> %.splat875, splat (i64 4)
  %1386 = add <8 x i64> %1384, %1385
  %1387 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1383, 0
  %1388 = insertvalue { <8 x ptr>, <8 x i64> } %1387, <8 x i64> %1386, 1
  %.state876 = load <8 x float>, ptr %.slot181, align 32
  %1389 = extractvalue { <8 x ptr>, <8 x i64> } %1388, 0
  %1390 = extractvalue { <8 x ptr>, <8 x i64> } %1388, 1
  %1391 = getelementptr i8, <8 x ptr> %1389, <8 x i64> %1390
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state876, <8 x ptr> align 1 %1391, <8 x i1> %101)
  %.state877 = load i64, ptr %.slot179, align 4
  %1392 = add i64 %.state877, 1
  store i64 %1392, ptr %.slot179, align 4
  br label %direct.schedule.80

direct.schedule.84:                               ; preds = %direct.false220
  store i64 0, ptr %.slot182, align 4
  br label %direct.schedule.85

direct.schedule.85:                               ; preds = %direct.schedule.88, %direct.schedule.84
  %.state878 = load i64, ptr %.slot182, align 4
  %1393 = icmp slt i64 %.state878, 512
  br i1 %1393, label %direct.true879, label %direct.false880

direct.schedule.86:                               ; preds = %direct.true879
  %.state881 = load i64, ptr %.slot182, align 4
  %1394 = srem i64 %.state881, 32
  %.state882 = load i64, ptr %.slot182, align 4
  %1395 = sdiv i64 %.state882, 32
  %.spill.load883 = load i64, ptr %.spill71, align 4
  %1396 = add i64 %.spill.load883, 0
  %.spill.load884 = load <8 x i64>, ptr %.spill70, align 64
  %1397 = add <8 x i64> %.spill.load884, zeroinitializer
  %1398 = mul i64 %1396, 2
  %.splatinsert885 = insertelement <8 x i64> poison, i64 %1398, i64 0
  %.splat886 = shufflevector <8 x i64> %.splatinsert885, <8 x i64> poison, <8 x i32> zeroinitializer
  %1399 = add <8 x i64> %.splat886, %1397
  %.spill.load887 = load i64, ptr %.spill92, align 4
  %1400 = add i64 %.spill.load887, %1395
  %1401 = mul <8 x i64> %1399, splat (i64 129)
  %.splatinsert888 = insertelement <8 x i64> poison, i64 %1400, i64 0
  %.splat889 = shufflevector <8 x i64> %.splatinsert888, <8 x i64> poison, <8 x i32> zeroinitializer
  %1402 = add <8 x i64> %1401, %.splat889
  %1403 = icmp sge i64 %1400, 0
  %1404 = and i1 true, %1403
  %1405 = icmp slt i64 %1400, 129
  %1406 = and i1 %1404, %1405
  %1407 = add i64 0, %1394
  %1408 = mul <8 x i64> %1402, splat (i64 32)
  %.splatinsert890 = insertelement <8 x i64> poison, i64 %1407, i64 0
  %.splat891 = shufflevector <8 x i64> %.splatinsert890, <8 x i64> poison, <8 x i32> zeroinitializer
  %1409 = add <8 x i64> %1408, %.splat891
  %1410 = load <8 x i64>, ptr %.spill183, align 64
  %1411 = select <8 x i1> %101, <8 x i64> %1409, <8 x i64> %1410
  store <8 x i64> %1411, ptr %.spill183, align 64
  br i1 %1406, label %direct.true892, label %direct.false893

direct.schedule.87:                               ; preds = %direct.true892
  %.spill.load894 = load <8 x i64>, ptr %.spill183, align 64
  %1412 = extractvalue { ptr, i64 } %65, 0
  %1413 = extractelement <8 x i64> %.spill.load894, i32 0
  %1414 = mul i64 %1413, 4
  %1415 = getelementptr i8, ptr %1412, i64 %1414
  %1416 = load float, ptr %1415, align 4
  %.splatinsert895 = insertelement <8 x float> poison, float %1416, i64 0
  %.splat896 = shufflevector <8 x float> %.splatinsert895, <8 x float> poison, <8 x i32> zeroinitializer
  %1417 = load <8 x float>, ptr %.slot184, align 32
  %1418 = select <8 x i1> %101, <8 x float> %.splat896, <8 x float> %1417
  store <8 x float> %1418, ptr %.slot184, align 32
  br label %direct.schedule.88

direct.schedule.88:                               ; preds = %direct.schedule.87, %direct.false893
  %tile_snapshot.spill.load897 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill93, align 64
  %1419 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load897, 0
  %1420 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load897, 1
  %.state898 = load i64, ptr %.slot182, align 4
  %.splatinsert899 = insertelement <8 x i64> poison, i64 %.state898, i64 0
  %.splat900 = shufflevector <8 x i64> %.splatinsert899, <8 x i64> poison, <8 x i32> zeroinitializer
  %1421 = mul <8 x i64> %.splat900, splat (i64 4)
  %1422 = add <8 x i64> %1420, %1421
  %1423 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1419, 0
  %1424 = insertvalue { <8 x ptr>, <8 x i64> } %1423, <8 x i64> %1422, 1
  %.state901 = load <8 x float>, ptr %.slot184, align 32
  %1425 = extractvalue { <8 x ptr>, <8 x i64> } %1424, 0
  %1426 = extractvalue { <8 x ptr>, <8 x i64> } %1424, 1
  %1427 = getelementptr i8, <8 x ptr> %1425, <8 x i64> %1426
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state901, <8 x ptr> align 1 %1427, <8 x i1> %101)
  %.state902 = load i64, ptr %.slot182, align 4
  %1428 = add i64 %.state902, 1
  store i64 %1428, ptr %.slot182, align 4
  br label %direct.schedule.85

direct.schedule.89:                               ; preds = %direct.false217
  %1429 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill185, align 64
  %1430 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1431 = extractvalue { <8 x ptr>, <8 x i64> } %1429, 0
  %1432 = select <8 x i1> %101, <8 x ptr> %1430, <8 x ptr> %1431
  %1433 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %1434 = extractvalue { <8 x ptr>, <8 x i64> } %1429, 1
  %1435 = select <8 x i1> %101, <8 x i64> %1433, <8 x i64> %1434
  %1436 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1432, 0
  %1437 = insertvalue { <8 x ptr>, <8 x i64> } %1436, <8 x i64> %1435, 1
  store { <8 x ptr>, <8 x i64> } %1437, ptr %tile_snapshot.spill185, align 64
  %1438 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1439 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %1440 = add <8 x i64> %1439, zeroinitializer
  %1441 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1438, 0
  %1442 = insertvalue { <8 x ptr>, <8 x i64> } %1441, <8 x i64> %1440, 1
  %.state903 = load <8 x float>, ptr %.slot84, align 32
  %1443 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1444 = extractvalue { <8 x ptr>, <8 x i64> } %1442, 1
  %1445 = extractelement <8 x ptr> %1443, i32 0
  %1446 = extractelement <8 x i64> %1444, i32 0
  %1447 = sub i64 %1446, 0
  %1448 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1449 = select i1 %1448, i64 %1447, i64 0
  %private.contiguous.address904 = getelementptr i8, ptr %1445, i64 %1449
  %private.contiguous.preserve905 = load <8 x float>, ptr %private.contiguous.address904, align 4
  %1450 = select <8 x i1> %101, <8 x float> %.state903, <8 x float> %private.contiguous.preserve905
  store <8 x float> %1450, ptr %private.contiguous.address904, align 4
  %1451 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1452 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %1453 = add <8 x i64> %1452, splat (i64 32)
  %1454 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1451, 0
  %1455 = insertvalue { <8 x ptr>, <8 x i64> } %1454, <8 x i64> %1453, 1
  %.state906 = load <8 x float>, ptr %.slot85, align 32
  %1456 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1457 = extractvalue { <8 x ptr>, <8 x i64> } %1455, 1
  %1458 = extractelement <8 x ptr> %1456, i32 0
  %1459 = extractelement <8 x i64> %1457, i32 0
  %1460 = sub i64 %1459, 0
  %1461 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1462 = select i1 %1461, i64 %1460, i64 0
  %private.contiguous.address907 = getelementptr i8, ptr %1458, i64 %1462
  %private.contiguous.preserve908 = load <8 x float>, ptr %private.contiguous.address907, align 4
  %1463 = select <8 x i1> %101, <8 x float> %.state906, <8 x float> %private.contiguous.preserve908
  store <8 x float> %1463, ptr %private.contiguous.address907, align 4
  %1464 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1465 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %1466 = add <8 x i64> %1465, splat (i64 64)
  %1467 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1464, 0
  %1468 = insertvalue { <8 x ptr>, <8 x i64> } %1467, <8 x i64> %1466, 1
  %.state909 = load <8 x float>, ptr %.slot86, align 32
  %1469 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1470 = extractvalue { <8 x ptr>, <8 x i64> } %1468, 1
  %1471 = extractelement <8 x ptr> %1469, i32 0
  %1472 = extractelement <8 x i64> %1470, i32 0
  %1473 = sub i64 %1472, 0
  %1474 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1475 = select i1 %1474, i64 %1473, i64 0
  %private.contiguous.address910 = getelementptr i8, ptr %1471, i64 %1475
  %private.contiguous.preserve911 = load <8 x float>, ptr %private.contiguous.address910, align 4
  %1476 = select <8 x i1> %101, <8 x float> %.state909, <8 x float> %private.contiguous.preserve911
  store <8 x float> %1476, ptr %private.contiguous.address910, align 4
  %1477 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1478 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %1479 = add <8 x i64> %1478, splat (i64 96)
  %1480 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1477, 0
  %1481 = insertvalue { <8 x ptr>, <8 x i64> } %1480, <8 x i64> %1479, 1
  %.state912 = load <8 x float>, ptr %.slot87, align 32
  %1482 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1483 = extractvalue { <8 x ptr>, <8 x i64> } %1481, 1
  %1484 = extractelement <8 x ptr> %1482, i32 0
  %1485 = extractelement <8 x i64> %1483, i32 0
  %1486 = sub i64 %1485, 0
  %1487 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1488 = select i1 %1487, i64 %1486, i64 0
  %private.contiguous.address913 = getelementptr i8, ptr %1484, i64 %1488
  %private.contiguous.preserve914 = load <8 x float>, ptr %private.contiguous.address913, align 4
  %1489 = select <8 x i1> %101, <8 x float> %.state912, <8 x float> %private.contiguous.preserve914
  store <8 x float> %1489, ptr %private.contiguous.address913, align 4
  %1490 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1491 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %1492 = add <8 x i64> %1491, splat (i64 128)
  %1493 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1490, 0
  %1494 = insertvalue { <8 x ptr>, <8 x i64> } %1493, <8 x i64> %1492, 1
  %.state915 = load <8 x float>, ptr %.slot88, align 32
  %1495 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1496 = extractvalue { <8 x ptr>, <8 x i64> } %1494, 1
  %1497 = extractelement <8 x ptr> %1495, i32 0
  %1498 = extractelement <8 x i64> %1496, i32 0
  %1499 = sub i64 %1498, 0
  %1500 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1501 = select i1 %1500, i64 %1499, i64 0
  %private.contiguous.address916 = getelementptr i8, ptr %1497, i64 %1501
  %private.contiguous.preserve917 = load <8 x float>, ptr %private.contiguous.address916, align 4
  %1502 = select <8 x i1> %101, <8 x float> %.state915, <8 x float> %private.contiguous.preserve917
  store <8 x float> %1502, ptr %private.contiguous.address916, align 4
  %1503 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1504 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %1505 = add <8 x i64> %1504, splat (i64 160)
  %1506 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1503, 0
  %1507 = insertvalue { <8 x ptr>, <8 x i64> } %1506, <8 x i64> %1505, 1
  %.state918 = load <8 x float>, ptr %.slot89, align 32
  %1508 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1509 = extractvalue { <8 x ptr>, <8 x i64> } %1507, 1
  %1510 = extractelement <8 x ptr> %1508, i32 0
  %1511 = extractelement <8 x i64> %1509, i32 0
  %1512 = sub i64 %1511, 0
  %1513 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1514 = select i1 %1513, i64 %1512, i64 0
  %private.contiguous.address919 = getelementptr i8, ptr %1510, i64 %1514
  %private.contiguous.preserve920 = load <8 x float>, ptr %private.contiguous.address919, align 4
  %1515 = select <8 x i1> %101, <8 x float> %.state918, <8 x float> %private.contiguous.preserve920
  store <8 x float> %1515, ptr %private.contiguous.address919, align 4
  %1516 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1517 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %1518 = add <8 x i64> %1517, splat (i64 192)
  %1519 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1516, 0
  %1520 = insertvalue { <8 x ptr>, <8 x i64> } %1519, <8 x i64> %1518, 1
  %.state921 = load <8 x float>, ptr %.slot90, align 32
  %1521 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1522 = extractvalue { <8 x ptr>, <8 x i64> } %1520, 1
  %1523 = extractelement <8 x ptr> %1521, i32 0
  %1524 = extractelement <8 x i64> %1522, i32 0
  %1525 = sub i64 %1524, 0
  %1526 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1527 = select i1 %1526, i64 %1525, i64 0
  %private.contiguous.address922 = getelementptr i8, ptr %1523, i64 %1527
  %private.contiguous.preserve923 = load <8 x float>, ptr %private.contiguous.address922, align 4
  %1528 = select <8 x i1> %101, <8 x float> %.state921, <8 x float> %private.contiguous.preserve923
  store <8 x float> %1528, ptr %private.contiguous.address922, align 4
  %1529 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1530 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %1531 = add <8 x i64> %1530, splat (i64 224)
  %1532 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1529, 0
  %1533 = insertvalue { <8 x ptr>, <8 x i64> } %1532, <8 x i64> %1531, 1
  %.state924 = load <8 x float>, ptr %.slot91, align 32
  %1534 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1535 = extractvalue { <8 x ptr>, <8 x i64> } %1533, 1
  %1536 = extractelement <8 x ptr> %1534, i32 0
  %1537 = extractelement <8 x i64> %1535, i32 0
  %1538 = sub i64 %1537, 0
  %1539 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1540 = select i1 %1539, i64 %1538, i64 0
  %private.contiguous.address925 = getelementptr i8, ptr %1536, i64 %1540
  %private.contiguous.preserve926 = load <8 x float>, ptr %private.contiguous.address925, align 4
  %1541 = select <8 x i1> %101, <8 x float> %.state924, <8 x float> %private.contiguous.preserve926
  store <8 x float> %1541, ptr %private.contiguous.address925, align 4
  store i64 0, ptr %.slot186, align 4
  br label %direct.schedule.90

direct.schedule.90:                               ; preds = %direct.schedule.91, %direct.schedule.89
  %.state927 = load i64, ptr %.slot186, align 4
  %1542 = icmp slt i64 %.state927, 384
  br i1 %1542, label %direct.true928, label %direct.false929

direct.schedule.91:                               ; preds = %direct.true928
  %.state930 = load i64, ptr %.slot186, align 4
  %1543 = srem i64 %.state930, 48
  %.state931 = load i64, ptr %.slot186, align 4
  %1544 = sdiv i64 %.state931, 48
  %.spill.load932 = load i64, ptr %.spill71, align 4
  %1545 = add i64 %.spill.load932, 0
  %.spill.load933 = load <8 x i64>, ptr %.spill, align 64
  %1546 = add <8 x i64> %.spill.load933, zeroinitializer
  %1547 = mul i64 %1545, 4
  %.splatinsert934 = insertelement <8 x i64> poison, i64 %1547, i64 0
  %.splat935 = shufflevector <8 x i64> %.splatinsert934, <8 x i64> poison, <8 x i32> zeroinitializer
  %1548 = add <8 x i64> %.splat935, %1546
  %.spill.load936 = load <8 x i64>, ptr %.spill69, align 64
  %.splatinsert937 = insertelement <8 x i64> poison, i64 %1544, i64 0
  %.splat938 = shufflevector <8 x i64> %.splatinsert937, <8 x i64> poison, <8 x i32> zeroinitializer
  %1549 = add <8 x i64> %.spill.load936, %.splat938
  %1550 = mul <8 x i64> %1548, splat (i64 64)
  %1551 = add <8 x i64> %1550, %1549
  %1552 = add i64 0, %1543
  %1553 = mul <8 x i64> %1551, splat (i64 48)
  %.splatinsert939 = insertelement <8 x i64> poison, i64 %1552, i64 0
  %.splat940 = shufflevector <8 x i64> %.splatinsert939, <8 x i64> poison, <8 x i32> zeroinitializer
  %1554 = add <8 x i64> %1553, %.splat940
  %1555 = add i64 0, %1544
  %1556 = mul i64 %1555, 48
  %1557 = add i64 %1556, %1543
  %tile_snapshot.spill.load941 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill73, align 64
  %1558 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load941, 0
  %1559 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load941, 1
  %.splatinsert942 = insertelement <8 x i64> poison, i64 %1557, i64 0
  %.splat943 = shufflevector <8 x i64> %.splatinsert942, <8 x i64> poison, <8 x i32> zeroinitializer
  %1560 = mul <8 x i64> %.splat943, splat (i64 32)
  %1561 = add <8 x i64> %1559, %1560
  %1562 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1558, 0
  %1563 = insertvalue { <8 x ptr>, <8 x i64> } %1562, <8 x i64> %1561, 1
  %1564 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1565 = extractvalue { <8 x ptr>, <8 x i64> } %1563, 1
  %1566 = extractelement <8 x ptr> %1564, i32 0
  %1567 = extractelement <8 x i64> %1565, i32 0
  %1568 = sub i64 %1567, 0
  %1569 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1570 = select i1 %1569, i64 %1568, i64 0
  %private.contiguous.address944 = getelementptr i8, ptr %1566, i64 %1570
  %private.contiguous.load945 = load <8 x float>, ptr %private.contiguous.address944, align 4
  %1571 = select <8 x i1> %101, <8 x float> %private.contiguous.load945, <8 x float> zeroinitializer
  %tile_snapshot.spill.load946 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill185, align 64
  %1572 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load946, 0
  %1573 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load946, 1
  %.splatinsert947 = insertelement <8 x i64> poison, i64 %1555, i64 0
  %.splat948 = shufflevector <8 x i64> %.splatinsert947, <8 x i64> poison, <8 x i32> zeroinitializer
  %1574 = mul <8 x i64> %.splat948, splat (i64 32)
  %1575 = add <8 x i64> %1573, %1574
  %1576 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1572, 0
  %1577 = insertvalue { <8 x ptr>, <8 x i64> } %1576, <8 x i64> %1575, 1
  %1578 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1579 = extractvalue { <8 x ptr>, <8 x i64> } %1577, 1
  %1580 = extractelement <8 x ptr> %1578, i32 0
  %1581 = extractelement <8 x i64> %1579, i32 0
  %1582 = sub i64 %1581, 0
  %1583 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1584 = select i1 %1583, i64 %1582, i64 0
  %private.contiguous.address949 = getelementptr i8, ptr %1580, i64 %1584
  %private.contiguous.load950 = load <8 x float>, ptr %private.contiguous.address949, align 4
  %1585 = select <8 x i1> %101, <8 x float> %private.contiguous.load950, <8 x float> zeroinitializer
  %1586 = fdiv <8 x float> %1571, %1585
  %1587 = extractvalue { ptr, i64 } %77, 0
  %1588 = mul <8 x i64> %1554, splat (i64 4)
  %1589 = getelementptr i8, ptr %1587, <8 x i64> %1588
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1586, <8 x ptr> align 1 %1589, <8 x i1> %101)
  %.state951 = load i64, ptr %.slot186, align 4
  %1590 = add i64 %.state951, 1
  store i64 %1590, ptr %.slot186, align 4
  br label %direct.schedule.90

direct.schedule.92:                               ; preds = %direct.false929
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

copy.active:                                      ; preds = %direct.schedule.0
  %1591 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1592 = extractelement <8 x ptr> %1591, i64 0
  %1593 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1594 = extractelement <8 x i64> %1593, i64 0
  %1595 = getelementptr i8, ptr %1592, i64 %1594
  %1596 = extractelement <8 x i64> %137, i64 0
  call void @llm_attention.contiguous_copy(ptr %138, i64 %1596, ptr %1595)
  br label %copy.continue

copy.continue:                                    ; preds = %copy.active, %direct.schedule.0
  %1597 = extractelement <8 x i1> %101, i64 1
  br i1 %1597, label %copy.active197, label %copy.continue198

copy.active197:                                   ; preds = %copy.continue
  %1598 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1599 = extractelement <8 x ptr> %1598, i64 1
  %1600 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1601 = extractelement <8 x i64> %1600, i64 1
  %1602 = getelementptr i8, ptr %1599, i64 %1601
  %1603 = extractelement <8 x i64> %137, i64 1
  call void @llm_attention.contiguous_copy(ptr %138, i64 %1603, ptr %1602)
  br label %copy.continue198

copy.continue198:                                 ; preds = %copy.active197, %copy.continue
  %1604 = extractelement <8 x i1> %101, i64 2
  br i1 %1604, label %copy.active199, label %copy.continue200

copy.active199:                                   ; preds = %copy.continue198
  %1605 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1606 = extractelement <8 x ptr> %1605, i64 2
  %1607 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1608 = extractelement <8 x i64> %1607, i64 2
  %1609 = getelementptr i8, ptr %1606, i64 %1608
  %1610 = extractelement <8 x i64> %137, i64 2
  call void @llm_attention.contiguous_copy(ptr %138, i64 %1610, ptr %1609)
  br label %copy.continue200

copy.continue200:                                 ; preds = %copy.active199, %copy.continue198
  %1611 = extractelement <8 x i1> %101, i64 3
  br i1 %1611, label %copy.active201, label %copy.continue202

copy.active201:                                   ; preds = %copy.continue200
  %1612 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1613 = extractelement <8 x ptr> %1612, i64 3
  %1614 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1615 = extractelement <8 x i64> %1614, i64 3
  %1616 = getelementptr i8, ptr %1613, i64 %1615
  %1617 = extractelement <8 x i64> %137, i64 3
  call void @llm_attention.contiguous_copy(ptr %138, i64 %1617, ptr %1616)
  br label %copy.continue202

copy.continue202:                                 ; preds = %copy.active201, %copy.continue200
  %1618 = extractelement <8 x i1> %101, i64 4
  br i1 %1618, label %copy.active203, label %copy.continue204

copy.active203:                                   ; preds = %copy.continue202
  %1619 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1620 = extractelement <8 x ptr> %1619, i64 4
  %1621 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1622 = extractelement <8 x i64> %1621, i64 4
  %1623 = getelementptr i8, ptr %1620, i64 %1622
  %1624 = extractelement <8 x i64> %137, i64 4
  call void @llm_attention.contiguous_copy(ptr %138, i64 %1624, ptr %1623)
  br label %copy.continue204

copy.continue204:                                 ; preds = %copy.active203, %copy.continue202
  %1625 = extractelement <8 x i1> %101, i64 5
  br i1 %1625, label %copy.active205, label %copy.continue206

copy.active205:                                   ; preds = %copy.continue204
  %1626 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1627 = extractelement <8 x ptr> %1626, i64 5
  %1628 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1629 = extractelement <8 x i64> %1628, i64 5
  %1630 = getelementptr i8, ptr %1627, i64 %1629
  %1631 = extractelement <8 x i64> %137, i64 5
  call void @llm_attention.contiguous_copy(ptr %138, i64 %1631, ptr %1630)
  br label %copy.continue206

copy.continue206:                                 ; preds = %copy.active205, %copy.continue204
  %1632 = extractelement <8 x i1> %101, i64 6
  br i1 %1632, label %copy.active207, label %copy.continue208

copy.active207:                                   ; preds = %copy.continue206
  %1633 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1634 = extractelement <8 x ptr> %1633, i64 6
  %1635 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1636 = extractelement <8 x i64> %1635, i64 6
  %1637 = getelementptr i8, ptr %1634, i64 %1636
  %1638 = extractelement <8 x i64> %137, i64 6
  call void @llm_attention.contiguous_copy(ptr %138, i64 %1638, ptr %1637)
  br label %copy.continue208

copy.continue208:                                 ; preds = %copy.active207, %copy.continue206
  %1639 = extractelement <8 x i1> %101, i64 7
  br i1 %1639, label %copy.active209, label %copy.continue210

copy.active209:                                   ; preds = %copy.continue208
  %1640 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1641 = extractelement <8 x ptr> %1640, i64 7
  %1642 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1643 = extractelement <8 x i64> %1642, i64 7
  %1644 = getelementptr i8, ptr %1641, i64 %1643
  %1645 = extractelement <8 x i64> %137, i64 7
  call void @llm_attention.contiguous_copy(ptr %138, i64 %1645, ptr %1644)
  br label %copy.continue210

copy.continue210:                                 ; preds = %copy.active209, %copy.continue208
  %1646 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill73, align 64
  %1647 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1648 = extractvalue { <8 x ptr>, <8 x i64> } %1646, 0
  %1649 = select <8 x i1> %101, <8 x ptr> %1647, <8 x ptr> %1648
  %1650 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1651 = extractvalue { <8 x ptr>, <8 x i64> } %1646, 1
  %1652 = select <8 x i1> %101, <8 x i64> %1650, <8 x i64> %1651
  %1653 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1649, 0
  %1654 = insertvalue { <8 x ptr>, <8 x i64> } %1653, <8 x i64> %1652, 1
  store { <8 x ptr>, <8 x i64> } %1654, ptr %tile_snapshot.spill73, align 64
  %1655 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill74, align 64
  %1656 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1657 = extractvalue { <8 x ptr>, <8 x i64> } %1655, 0
  %1658 = select <8 x i1> %101, <8 x ptr> %1656, <8 x ptr> %1657
  %1659 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %1660 = extractvalue { <8 x ptr>, <8 x i64> } %1655, 1
  %1661 = select <8 x i1> %101, <8 x i64> %1659, <8 x i64> %1660
  %1662 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1658, 0
  %1663 = insertvalue { <8 x ptr>, <8 x i64> } %1662, <8 x i64> %1661, 1
  store { <8 x ptr>, <8 x i64> } %1663, ptr %tile_snapshot.spill74, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true216:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false217:                                  ; preds = %direct.schedule.4
  br label %direct.schedule.89

direct.true219:                                   ; preds = %direct.schedule.5
  br label %direct.schedule.6

direct.false220:                                  ; preds = %direct.schedule.5
  br label %direct.schedule.84

copy.active228:                                   ; preds = %direct.schedule.6
  %1664 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load227, 0
  %1665 = extractelement <8 x ptr> %1664, i64 0
  %1666 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load227, 1
  %1667 = extractelement <8 x i64> %1666, i64 0
  %1668 = getelementptr i8, ptr %1665, i64 %1667
  %1669 = extractelement <8 x i64> %209, i64 0
  call void @llm_attention.contiguous_copy.1(ptr %210, i64 %1669, ptr %1668)
  br label %copy.continue229

copy.continue229:                                 ; preds = %copy.active228, %direct.schedule.6
  %1670 = extractelement <8 x i1> %101, i64 1
  br i1 %1670, label %copy.active230, label %copy.continue231

copy.active230:                                   ; preds = %copy.continue229
  %1671 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load227, 0
  %1672 = extractelement <8 x ptr> %1671, i64 1
  %1673 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load227, 1
  %1674 = extractelement <8 x i64> %1673, i64 1
  %1675 = getelementptr i8, ptr %1672, i64 %1674
  %1676 = extractelement <8 x i64> %209, i64 1
  call void @llm_attention.contiguous_copy.1(ptr %210, i64 %1676, ptr %1675)
  br label %copy.continue231

copy.continue231:                                 ; preds = %copy.active230, %copy.continue229
  %1677 = extractelement <8 x i1> %101, i64 2
  br i1 %1677, label %copy.active232, label %copy.continue233

copy.active232:                                   ; preds = %copy.continue231
  %1678 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load227, 0
  %1679 = extractelement <8 x ptr> %1678, i64 2
  %1680 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load227, 1
  %1681 = extractelement <8 x i64> %1680, i64 2
  %1682 = getelementptr i8, ptr %1679, i64 %1681
  %1683 = extractelement <8 x i64> %209, i64 2
  call void @llm_attention.contiguous_copy.1(ptr %210, i64 %1683, ptr %1682)
  br label %copy.continue233

copy.continue233:                                 ; preds = %copy.active232, %copy.continue231
  %1684 = extractelement <8 x i1> %101, i64 3
  br i1 %1684, label %copy.active234, label %copy.continue235

copy.active234:                                   ; preds = %copy.continue233
  %1685 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load227, 0
  %1686 = extractelement <8 x ptr> %1685, i64 3
  %1687 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load227, 1
  %1688 = extractelement <8 x i64> %1687, i64 3
  %1689 = getelementptr i8, ptr %1686, i64 %1688
  %1690 = extractelement <8 x i64> %209, i64 3
  call void @llm_attention.contiguous_copy.1(ptr %210, i64 %1690, ptr %1689)
  br label %copy.continue235

copy.continue235:                                 ; preds = %copy.active234, %copy.continue233
  %1691 = extractelement <8 x i1> %101, i64 4
  br i1 %1691, label %copy.active236, label %copy.continue237

copy.active236:                                   ; preds = %copy.continue235
  %1692 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load227, 0
  %1693 = extractelement <8 x ptr> %1692, i64 4
  %1694 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load227, 1
  %1695 = extractelement <8 x i64> %1694, i64 4
  %1696 = getelementptr i8, ptr %1693, i64 %1695
  %1697 = extractelement <8 x i64> %209, i64 4
  call void @llm_attention.contiguous_copy.1(ptr %210, i64 %1697, ptr %1696)
  br label %copy.continue237

copy.continue237:                                 ; preds = %copy.active236, %copy.continue235
  %1698 = extractelement <8 x i1> %101, i64 5
  br i1 %1698, label %copy.active238, label %copy.continue239

copy.active238:                                   ; preds = %copy.continue237
  %1699 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load227, 0
  %1700 = extractelement <8 x ptr> %1699, i64 5
  %1701 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load227, 1
  %1702 = extractelement <8 x i64> %1701, i64 5
  %1703 = getelementptr i8, ptr %1700, i64 %1702
  %1704 = extractelement <8 x i64> %209, i64 5
  call void @llm_attention.contiguous_copy.1(ptr %210, i64 %1704, ptr %1703)
  br label %copy.continue239

copy.continue239:                                 ; preds = %copy.active238, %copy.continue237
  %1705 = extractelement <8 x i1> %101, i64 6
  br i1 %1705, label %copy.active240, label %copy.continue241

copy.active240:                                   ; preds = %copy.continue239
  %1706 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load227, 0
  %1707 = extractelement <8 x ptr> %1706, i64 6
  %1708 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load227, 1
  %1709 = extractelement <8 x i64> %1708, i64 6
  %1710 = getelementptr i8, ptr %1707, i64 %1709
  %1711 = extractelement <8 x i64> %209, i64 6
  call void @llm_attention.contiguous_copy.1(ptr %210, i64 %1711, ptr %1710)
  br label %copy.continue241

copy.continue241:                                 ; preds = %copy.active240, %copy.continue239
  %1712 = extractelement <8 x i1> %101, i64 7
  br i1 %1712, label %copy.active242, label %copy.continue243

copy.active242:                                   ; preds = %copy.continue241
  %1713 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load227, 0
  %1714 = extractelement <8 x ptr> %1713, i64 7
  %1715 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load227, 1
  %1716 = extractelement <8 x i64> %1715, i64 7
  %1717 = getelementptr i8, ptr %1714, i64 %1716
  %1718 = extractelement <8 x i64> %209, i64 7
  call void @llm_attention.contiguous_copy.1(ptr %210, i64 %1718, ptr %1717)
  br label %copy.continue243

copy.continue243:                                 ; preds = %copy.active242, %copy.continue241
  br label %direct.schedule.7

direct.true245:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false246:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.79

copy.active255:                                   ; preds = %direct.schedule.8
  %1719 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load254, 0
  %1720 = extractelement <8 x ptr> %1719, i64 0
  %1721 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load254, 1
  %1722 = extractelement <8 x i64> %1721, i64 0
  %1723 = getelementptr i8, ptr %1720, i64 %1722
  %1724 = extractelement <8 x i64> %226, i64 0
  call void @llm_attention.contiguous_copy.2(ptr %227, i64 %1724, ptr %1723)
  br label %copy.continue256

copy.continue256:                                 ; preds = %copy.active255, %direct.schedule.8
  %1725 = extractelement <8 x i1> %101, i64 1
  br i1 %1725, label %copy.active257, label %copy.continue258

copy.active257:                                   ; preds = %copy.continue256
  %1726 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load254, 0
  %1727 = extractelement <8 x ptr> %1726, i64 1
  %1728 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load254, 1
  %1729 = extractelement <8 x i64> %1728, i64 1
  %1730 = getelementptr i8, ptr %1727, i64 %1729
  %1731 = extractelement <8 x i64> %226, i64 1
  call void @llm_attention.contiguous_copy.2(ptr %227, i64 %1731, ptr %1730)
  br label %copy.continue258

copy.continue258:                                 ; preds = %copy.active257, %copy.continue256
  %1732 = extractelement <8 x i1> %101, i64 2
  br i1 %1732, label %copy.active259, label %copy.continue260

copy.active259:                                   ; preds = %copy.continue258
  %1733 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load254, 0
  %1734 = extractelement <8 x ptr> %1733, i64 2
  %1735 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load254, 1
  %1736 = extractelement <8 x i64> %1735, i64 2
  %1737 = getelementptr i8, ptr %1734, i64 %1736
  %1738 = extractelement <8 x i64> %226, i64 2
  call void @llm_attention.contiguous_copy.2(ptr %227, i64 %1738, ptr %1737)
  br label %copy.continue260

copy.continue260:                                 ; preds = %copy.active259, %copy.continue258
  %1739 = extractelement <8 x i1> %101, i64 3
  br i1 %1739, label %copy.active261, label %copy.continue262

copy.active261:                                   ; preds = %copy.continue260
  %1740 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load254, 0
  %1741 = extractelement <8 x ptr> %1740, i64 3
  %1742 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load254, 1
  %1743 = extractelement <8 x i64> %1742, i64 3
  %1744 = getelementptr i8, ptr %1741, i64 %1743
  %1745 = extractelement <8 x i64> %226, i64 3
  call void @llm_attention.contiguous_copy.2(ptr %227, i64 %1745, ptr %1744)
  br label %copy.continue262

copy.continue262:                                 ; preds = %copy.active261, %copy.continue260
  %1746 = extractelement <8 x i1> %101, i64 4
  br i1 %1746, label %copy.active263, label %copy.continue264

copy.active263:                                   ; preds = %copy.continue262
  %1747 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load254, 0
  %1748 = extractelement <8 x ptr> %1747, i64 4
  %1749 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load254, 1
  %1750 = extractelement <8 x i64> %1749, i64 4
  %1751 = getelementptr i8, ptr %1748, i64 %1750
  %1752 = extractelement <8 x i64> %226, i64 4
  call void @llm_attention.contiguous_copy.2(ptr %227, i64 %1752, ptr %1751)
  br label %copy.continue264

copy.continue264:                                 ; preds = %copy.active263, %copy.continue262
  %1753 = extractelement <8 x i1> %101, i64 5
  br i1 %1753, label %copy.active265, label %copy.continue266

copy.active265:                                   ; preds = %copy.continue264
  %1754 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load254, 0
  %1755 = extractelement <8 x ptr> %1754, i64 5
  %1756 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load254, 1
  %1757 = extractelement <8 x i64> %1756, i64 5
  %1758 = getelementptr i8, ptr %1755, i64 %1757
  %1759 = extractelement <8 x i64> %226, i64 5
  call void @llm_attention.contiguous_copy.2(ptr %227, i64 %1759, ptr %1758)
  br label %copy.continue266

copy.continue266:                                 ; preds = %copy.active265, %copy.continue264
  %1760 = extractelement <8 x i1> %101, i64 6
  br i1 %1760, label %copy.active267, label %copy.continue268

copy.active267:                                   ; preds = %copy.continue266
  %1761 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load254, 0
  %1762 = extractelement <8 x ptr> %1761, i64 6
  %1763 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load254, 1
  %1764 = extractelement <8 x i64> %1763, i64 6
  %1765 = getelementptr i8, ptr %1762, i64 %1764
  %1766 = extractelement <8 x i64> %226, i64 6
  call void @llm_attention.contiguous_copy.2(ptr %227, i64 %1766, ptr %1765)
  br label %copy.continue268

copy.continue268:                                 ; preds = %copy.active267, %copy.continue266
  %1767 = extractelement <8 x i1> %101, i64 7
  br i1 %1767, label %copy.active269, label %copy.continue270

copy.active269:                                   ; preds = %copy.continue268
  %1768 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load254, 0
  %1769 = extractelement <8 x ptr> %1768, i64 7
  %1770 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load254, 1
  %1771 = extractelement <8 x i64> %1770, i64 7
  %1772 = getelementptr i8, ptr %1769, i64 %1771
  %1773 = extractelement <8 x i64> %226, i64 7
  call void @llm_attention.contiguous_copy.2(ptr %227, i64 %1773, ptr %1772)
  br label %copy.continue270

copy.continue270:                                 ; preds = %copy.active269, %copy.continue268
  br label %direct.schedule.9

direct.true272:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false273:                                  ; preds = %direct.schedule.10
  br label %direct.schedule.12

mma.active:                                       ; preds = %direct.schedule.12
  %1774 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load279, 0
  %1775 = extractelement <8 x ptr> %1774, i64 0
  %1776 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load279, 1
  %1777 = extractelement <8 x i64> %1776, i64 0
  %1778 = getelementptr i8, ptr %1775, i64 %1777
  %1779 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 0
  %1780 = extractelement <8 x ptr> %1779, i64 0
  %1781 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 1
  %1782 = extractelement <8 x i64> %1781, i64 0
  %1783 = getelementptr i8, ptr %1780, i64 %1782
  %1784 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 0
  %1785 = extractelement <8 x ptr> %1784, i64 0
  %1786 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 1
  %1787 = extractelement <8 x i64> %1786, i64 0
  %1788 = getelementptr i8, ptr %1785, i64 %1787
  %1789 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1790 = extractelement <8 x ptr> %1789, i64 0
  %1791 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1792 = extractelement <8 x i64> %1791, i64 0
  %1793 = getelementptr i8, ptr %1790, i64 %1792
  call void @llm_attention.strided_mma(ptr %1778, ptr %1783, ptr %1788, ptr %1793)
  br label %mma.continue

mma.continue:                                     ; preds = %mma.active, %direct.schedule.12
  %1794 = extractelement <8 x i1> %101, i64 1
  br i1 %1794, label %mma.active282, label %mma.continue283

mma.active282:                                    ; preds = %mma.continue
  %1795 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load279, 0
  %1796 = extractelement <8 x ptr> %1795, i64 1
  %1797 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load279, 1
  %1798 = extractelement <8 x i64> %1797, i64 1
  %1799 = getelementptr i8, ptr %1796, i64 %1798
  %1800 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 0
  %1801 = extractelement <8 x ptr> %1800, i64 1
  %1802 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 1
  %1803 = extractelement <8 x i64> %1802, i64 1
  %1804 = getelementptr i8, ptr %1801, i64 %1803
  %1805 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 0
  %1806 = extractelement <8 x ptr> %1805, i64 1
  %1807 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 1
  %1808 = extractelement <8 x i64> %1807, i64 1
  %1809 = getelementptr i8, ptr %1806, i64 %1808
  %1810 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1811 = extractelement <8 x ptr> %1810, i64 1
  %1812 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1813 = extractelement <8 x i64> %1812, i64 1
  %1814 = getelementptr i8, ptr %1811, i64 %1813
  call void @llm_attention.strided_mma(ptr %1799, ptr %1804, ptr %1809, ptr %1814)
  br label %mma.continue283

mma.continue283:                                  ; preds = %mma.active282, %mma.continue
  %1815 = extractelement <8 x i1> %101, i64 2
  br i1 %1815, label %mma.active284, label %mma.continue285

mma.active284:                                    ; preds = %mma.continue283
  %1816 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load279, 0
  %1817 = extractelement <8 x ptr> %1816, i64 2
  %1818 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load279, 1
  %1819 = extractelement <8 x i64> %1818, i64 2
  %1820 = getelementptr i8, ptr %1817, i64 %1819
  %1821 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 0
  %1822 = extractelement <8 x ptr> %1821, i64 2
  %1823 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 1
  %1824 = extractelement <8 x i64> %1823, i64 2
  %1825 = getelementptr i8, ptr %1822, i64 %1824
  %1826 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 0
  %1827 = extractelement <8 x ptr> %1826, i64 2
  %1828 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 1
  %1829 = extractelement <8 x i64> %1828, i64 2
  %1830 = getelementptr i8, ptr %1827, i64 %1829
  %1831 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1832 = extractelement <8 x ptr> %1831, i64 2
  %1833 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1834 = extractelement <8 x i64> %1833, i64 2
  %1835 = getelementptr i8, ptr %1832, i64 %1834
  call void @llm_attention.strided_mma(ptr %1820, ptr %1825, ptr %1830, ptr %1835)
  br label %mma.continue285

mma.continue285:                                  ; preds = %mma.active284, %mma.continue283
  %1836 = extractelement <8 x i1> %101, i64 3
  br i1 %1836, label %mma.active286, label %mma.continue287

mma.active286:                                    ; preds = %mma.continue285
  %1837 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load279, 0
  %1838 = extractelement <8 x ptr> %1837, i64 3
  %1839 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load279, 1
  %1840 = extractelement <8 x i64> %1839, i64 3
  %1841 = getelementptr i8, ptr %1838, i64 %1840
  %1842 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 0
  %1843 = extractelement <8 x ptr> %1842, i64 3
  %1844 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 1
  %1845 = extractelement <8 x i64> %1844, i64 3
  %1846 = getelementptr i8, ptr %1843, i64 %1845
  %1847 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 0
  %1848 = extractelement <8 x ptr> %1847, i64 3
  %1849 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 1
  %1850 = extractelement <8 x i64> %1849, i64 3
  %1851 = getelementptr i8, ptr %1848, i64 %1850
  %1852 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1853 = extractelement <8 x ptr> %1852, i64 3
  %1854 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1855 = extractelement <8 x i64> %1854, i64 3
  %1856 = getelementptr i8, ptr %1853, i64 %1855
  call void @llm_attention.strided_mma(ptr %1841, ptr %1846, ptr %1851, ptr %1856)
  br label %mma.continue287

mma.continue287:                                  ; preds = %mma.active286, %mma.continue285
  %1857 = extractelement <8 x i1> %101, i64 4
  br i1 %1857, label %mma.active288, label %mma.continue289

mma.active288:                                    ; preds = %mma.continue287
  %1858 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load279, 0
  %1859 = extractelement <8 x ptr> %1858, i64 4
  %1860 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load279, 1
  %1861 = extractelement <8 x i64> %1860, i64 4
  %1862 = getelementptr i8, ptr %1859, i64 %1861
  %1863 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 0
  %1864 = extractelement <8 x ptr> %1863, i64 4
  %1865 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 1
  %1866 = extractelement <8 x i64> %1865, i64 4
  %1867 = getelementptr i8, ptr %1864, i64 %1866
  %1868 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 0
  %1869 = extractelement <8 x ptr> %1868, i64 4
  %1870 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 1
  %1871 = extractelement <8 x i64> %1870, i64 4
  %1872 = getelementptr i8, ptr %1869, i64 %1871
  %1873 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1874 = extractelement <8 x ptr> %1873, i64 4
  %1875 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1876 = extractelement <8 x i64> %1875, i64 4
  %1877 = getelementptr i8, ptr %1874, i64 %1876
  call void @llm_attention.strided_mma(ptr %1862, ptr %1867, ptr %1872, ptr %1877)
  br label %mma.continue289

mma.continue289:                                  ; preds = %mma.active288, %mma.continue287
  %1878 = extractelement <8 x i1> %101, i64 5
  br i1 %1878, label %mma.active290, label %mma.continue291

mma.active290:                                    ; preds = %mma.continue289
  %1879 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load279, 0
  %1880 = extractelement <8 x ptr> %1879, i64 5
  %1881 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load279, 1
  %1882 = extractelement <8 x i64> %1881, i64 5
  %1883 = getelementptr i8, ptr %1880, i64 %1882
  %1884 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 0
  %1885 = extractelement <8 x ptr> %1884, i64 5
  %1886 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 1
  %1887 = extractelement <8 x i64> %1886, i64 5
  %1888 = getelementptr i8, ptr %1885, i64 %1887
  %1889 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 0
  %1890 = extractelement <8 x ptr> %1889, i64 5
  %1891 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 1
  %1892 = extractelement <8 x i64> %1891, i64 5
  %1893 = getelementptr i8, ptr %1890, i64 %1892
  %1894 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1895 = extractelement <8 x ptr> %1894, i64 5
  %1896 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1897 = extractelement <8 x i64> %1896, i64 5
  %1898 = getelementptr i8, ptr %1895, i64 %1897
  call void @llm_attention.strided_mma(ptr %1883, ptr %1888, ptr %1893, ptr %1898)
  br label %mma.continue291

mma.continue291:                                  ; preds = %mma.active290, %mma.continue289
  %1899 = extractelement <8 x i1> %101, i64 6
  br i1 %1899, label %mma.active292, label %mma.continue293

mma.active292:                                    ; preds = %mma.continue291
  %1900 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load279, 0
  %1901 = extractelement <8 x ptr> %1900, i64 6
  %1902 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load279, 1
  %1903 = extractelement <8 x i64> %1902, i64 6
  %1904 = getelementptr i8, ptr %1901, i64 %1903
  %1905 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 0
  %1906 = extractelement <8 x ptr> %1905, i64 6
  %1907 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 1
  %1908 = extractelement <8 x i64> %1907, i64 6
  %1909 = getelementptr i8, ptr %1906, i64 %1908
  %1910 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 0
  %1911 = extractelement <8 x ptr> %1910, i64 6
  %1912 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 1
  %1913 = extractelement <8 x i64> %1912, i64 6
  %1914 = getelementptr i8, ptr %1911, i64 %1913
  %1915 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1916 = extractelement <8 x ptr> %1915, i64 6
  %1917 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1918 = extractelement <8 x i64> %1917, i64 6
  %1919 = getelementptr i8, ptr %1916, i64 %1918
  call void @llm_attention.strided_mma(ptr %1904, ptr %1909, ptr %1914, ptr %1919)
  br label %mma.continue293

mma.continue293:                                  ; preds = %mma.active292, %mma.continue291
  %1920 = extractelement <8 x i1> %101, i64 7
  br i1 %1920, label %mma.active294, label %mma.continue295

mma.active294:                                    ; preds = %mma.continue293
  %1921 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load279, 0
  %1922 = extractelement <8 x ptr> %1921, i64 7
  %1923 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load279, 1
  %1924 = extractelement <8 x i64> %1923, i64 7
  %1925 = getelementptr i8, ptr %1922, i64 %1924
  %1926 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 0
  %1927 = extractelement <8 x ptr> %1926, i64 7
  %1928 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 1
  %1929 = extractelement <8 x i64> %1928, i64 7
  %1930 = getelementptr i8, ptr %1927, i64 %1929
  %1931 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 0
  %1932 = extractelement <8 x ptr> %1931, i64 7
  %1933 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 1
  %1934 = extractelement <8 x i64> %1933, i64 7
  %1935 = getelementptr i8, ptr %1932, i64 %1934
  %1936 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1937 = extractelement <8 x ptr> %1936, i64 7
  %1938 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1939 = extractelement <8 x i64> %1938, i64 7
  %1940 = getelementptr i8, ptr %1937, i64 %1939
  call void @llm_attention.strided_mma(ptr %1925, ptr %1930, ptr %1935, ptr %1940)
  br label %mma.continue295

mma.continue295:                                  ; preds = %mma.active294, %mma.continue293
  %.spill.load296 = load i64, ptr %.spill92, align 4
  %1941 = add i64 0, %.spill.load296
  %.spill.load297 = load i64, ptr %.spill92, align 4
  %1942 = add i64 1, %.spill.load297
  %.spill.load298 = load i64, ptr %.spill92, align 4
  %1943 = add i64 2, %.spill.load298
  %.spill.load299 = load i64, ptr %.spill92, align 4
  %1944 = add i64 3, %.spill.load299
  %.spill.load300 = load i64, ptr %.spill92, align 4
  %1945 = add i64 4, %.spill.load300
  %.spill.load301 = load i64, ptr %.spill92, align 4
  %1946 = add i64 5, %.spill.load301
  %.spill.load302 = load i64, ptr %.spill92, align 4
  %1947 = add i64 6, %.spill.load302
  %.spill.load303 = load i64, ptr %.spill92, align 4
  %1948 = add i64 7, %.spill.load303
  %.spill.load304 = load i64, ptr %.spill92, align 4
  %1949 = add i64 8, %.spill.load304
  %.spill.load305 = load i64, ptr %.spill92, align 4
  %1950 = add i64 9, %.spill.load305
  %.spill.load306 = load i64, ptr %.spill92, align 4
  %1951 = add i64 10, %.spill.load306
  %.spill.load307 = load i64, ptr %.spill92, align 4
  %1952 = add i64 11, %.spill.load307
  %.spill.load308 = load i64, ptr %.spill92, align 4
  %1953 = add i64 12, %.spill.load308
  %.spill.load309 = load i64, ptr %.spill92, align 4
  %1954 = add i64 13, %.spill.load309
  %.spill.load310 = load i64, ptr %.spill92, align 4
  %1955 = add i64 14, %.spill.load310
  %.spill.load311 = load i64, ptr %.spill92, align 4
  %1956 = add i64 15, %.spill.load311
  %1957 = icmp slt i64 %1941, 129
  %1958 = icmp slt i64 %1942, 129
  %1959 = icmp slt i64 %1943, 129
  %1960 = icmp slt i64 %1944, 129
  %1961 = icmp slt i64 %1945, 129
  %1962 = icmp slt i64 %1946, 129
  %1963 = icmp slt i64 %1947, 129
  %1964 = icmp slt i64 %1948, 129
  %1965 = icmp slt i64 %1949, 129
  %1966 = icmp slt i64 %1950, 129
  %1967 = icmp slt i64 %1951, 129
  %1968 = icmp slt i64 %1952, 129
  %1969 = icmp slt i64 %1953, 129
  %1970 = icmp slt i64 %1954, 129
  %1971 = icmp slt i64 %1955, 129
  %1972 = icmp slt i64 %1956, 129
  %1973 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill99, align 64
  %1974 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1975 = extractvalue { <8 x ptr>, <8 x i64> } %1973, 0
  %1976 = select <8 x i1> %101, <8 x ptr> %1974, <8 x ptr> %1975
  %1977 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1978 = extractvalue { <8 x ptr>, <8 x i64> } %1973, 1
  %1979 = select <8 x i1> %101, <8 x i64> %1977, <8 x i64> %1978
  %1980 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1976, 0
  %1981 = insertvalue { <8 x ptr>, <8 x i64> } %1980, <8 x i64> %1979, 1
  store { <8 x ptr>, <8 x i64> } %1981, ptr %tile_snapshot.spill99, align 64
  %1982 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1983 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1984 = add <8 x i64> %1983, zeroinitializer
  %1985 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1982, 0
  %1986 = insertvalue { <8 x ptr>, <8 x i64> } %1985, <8 x i64> %1984, 1
  %.splatinsert312 = insertelement <8 x i1> poison, i1 %1957, i64 0
  %.splat313 = shufflevector <8 x i1> %.splatinsert312, <8 x i1> poison, <8 x i32> zeroinitializer
  %1987 = extractvalue { <8 x ptr>, <8 x i64> } %1986, 0
  %1988 = extractvalue { <8 x ptr>, <8 x i64> } %1986, 1
  %1989 = getelementptr i8, <8 x ptr> %1987, <8 x i64> %1988
  %1990 = zext <8 x i1> %.splat313 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1990, <8 x ptr> align 1 %1989, <8 x i1> %101)
  %1991 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1992 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1993 = add <8 x i64> %1992, splat (i64 1)
  %1994 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1991, 0
  %1995 = insertvalue { <8 x ptr>, <8 x i64> } %1994, <8 x i64> %1993, 1
  %.splatinsert314 = insertelement <8 x i1> poison, i1 %1958, i64 0
  %.splat315 = shufflevector <8 x i1> %.splatinsert314, <8 x i1> poison, <8 x i32> zeroinitializer
  %1996 = extractvalue { <8 x ptr>, <8 x i64> } %1995, 0
  %1997 = extractvalue { <8 x ptr>, <8 x i64> } %1995, 1
  %1998 = getelementptr i8, <8 x ptr> %1996, <8 x i64> %1997
  %1999 = zext <8 x i1> %.splat315 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1999, <8 x ptr> align 1 %1998, <8 x i1> %101)
  %2000 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2001 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2002 = add <8 x i64> %2001, splat (i64 2)
  %2003 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2000, 0
  %2004 = insertvalue { <8 x ptr>, <8 x i64> } %2003, <8 x i64> %2002, 1
  %.splatinsert316 = insertelement <8 x i1> poison, i1 %1959, i64 0
  %.splat317 = shufflevector <8 x i1> %.splatinsert316, <8 x i1> poison, <8 x i32> zeroinitializer
  %2005 = extractvalue { <8 x ptr>, <8 x i64> } %2004, 0
  %2006 = extractvalue { <8 x ptr>, <8 x i64> } %2004, 1
  %2007 = getelementptr i8, <8 x ptr> %2005, <8 x i64> %2006
  %2008 = zext <8 x i1> %.splat317 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2008, <8 x ptr> align 1 %2007, <8 x i1> %101)
  %2009 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2010 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2011 = add <8 x i64> %2010, splat (i64 3)
  %2012 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2009, 0
  %2013 = insertvalue { <8 x ptr>, <8 x i64> } %2012, <8 x i64> %2011, 1
  %.splatinsert318 = insertelement <8 x i1> poison, i1 %1960, i64 0
  %.splat319 = shufflevector <8 x i1> %.splatinsert318, <8 x i1> poison, <8 x i32> zeroinitializer
  %2014 = extractvalue { <8 x ptr>, <8 x i64> } %2013, 0
  %2015 = extractvalue { <8 x ptr>, <8 x i64> } %2013, 1
  %2016 = getelementptr i8, <8 x ptr> %2014, <8 x i64> %2015
  %2017 = zext <8 x i1> %.splat319 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2017, <8 x ptr> align 1 %2016, <8 x i1> %101)
  %2018 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2019 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2020 = add <8 x i64> %2019, splat (i64 4)
  %2021 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2018, 0
  %2022 = insertvalue { <8 x ptr>, <8 x i64> } %2021, <8 x i64> %2020, 1
  %.splatinsert320 = insertelement <8 x i1> poison, i1 %1961, i64 0
  %.splat321 = shufflevector <8 x i1> %.splatinsert320, <8 x i1> poison, <8 x i32> zeroinitializer
  %2023 = extractvalue { <8 x ptr>, <8 x i64> } %2022, 0
  %2024 = extractvalue { <8 x ptr>, <8 x i64> } %2022, 1
  %2025 = getelementptr i8, <8 x ptr> %2023, <8 x i64> %2024
  %2026 = zext <8 x i1> %.splat321 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2026, <8 x ptr> align 1 %2025, <8 x i1> %101)
  %2027 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2028 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2029 = add <8 x i64> %2028, splat (i64 5)
  %2030 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2027, 0
  %2031 = insertvalue { <8 x ptr>, <8 x i64> } %2030, <8 x i64> %2029, 1
  %.splatinsert322 = insertelement <8 x i1> poison, i1 %1962, i64 0
  %.splat323 = shufflevector <8 x i1> %.splatinsert322, <8 x i1> poison, <8 x i32> zeroinitializer
  %2032 = extractvalue { <8 x ptr>, <8 x i64> } %2031, 0
  %2033 = extractvalue { <8 x ptr>, <8 x i64> } %2031, 1
  %2034 = getelementptr i8, <8 x ptr> %2032, <8 x i64> %2033
  %2035 = zext <8 x i1> %.splat323 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2035, <8 x ptr> align 1 %2034, <8 x i1> %101)
  %2036 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2037 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2038 = add <8 x i64> %2037, splat (i64 6)
  %2039 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2036, 0
  %2040 = insertvalue { <8 x ptr>, <8 x i64> } %2039, <8 x i64> %2038, 1
  %.splatinsert324 = insertelement <8 x i1> poison, i1 %1963, i64 0
  %.splat325 = shufflevector <8 x i1> %.splatinsert324, <8 x i1> poison, <8 x i32> zeroinitializer
  %2041 = extractvalue { <8 x ptr>, <8 x i64> } %2040, 0
  %2042 = extractvalue { <8 x ptr>, <8 x i64> } %2040, 1
  %2043 = getelementptr i8, <8 x ptr> %2041, <8 x i64> %2042
  %2044 = zext <8 x i1> %.splat325 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2044, <8 x ptr> align 1 %2043, <8 x i1> %101)
  %2045 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2046 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2047 = add <8 x i64> %2046, splat (i64 7)
  %2048 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2045, 0
  %2049 = insertvalue { <8 x ptr>, <8 x i64> } %2048, <8 x i64> %2047, 1
  %.splatinsert326 = insertelement <8 x i1> poison, i1 %1964, i64 0
  %.splat327 = shufflevector <8 x i1> %.splatinsert326, <8 x i1> poison, <8 x i32> zeroinitializer
  %2050 = extractvalue { <8 x ptr>, <8 x i64> } %2049, 0
  %2051 = extractvalue { <8 x ptr>, <8 x i64> } %2049, 1
  %2052 = getelementptr i8, <8 x ptr> %2050, <8 x i64> %2051
  %2053 = zext <8 x i1> %.splat327 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2053, <8 x ptr> align 1 %2052, <8 x i1> %101)
  %2054 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2055 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2056 = add <8 x i64> %2055, splat (i64 8)
  %2057 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2054, 0
  %2058 = insertvalue { <8 x ptr>, <8 x i64> } %2057, <8 x i64> %2056, 1
  %.splatinsert328 = insertelement <8 x i1> poison, i1 %1965, i64 0
  %.splat329 = shufflevector <8 x i1> %.splatinsert328, <8 x i1> poison, <8 x i32> zeroinitializer
  %2059 = extractvalue { <8 x ptr>, <8 x i64> } %2058, 0
  %2060 = extractvalue { <8 x ptr>, <8 x i64> } %2058, 1
  %2061 = getelementptr i8, <8 x ptr> %2059, <8 x i64> %2060
  %2062 = zext <8 x i1> %.splat329 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2062, <8 x ptr> align 1 %2061, <8 x i1> %101)
  %2063 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2064 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2065 = add <8 x i64> %2064, splat (i64 9)
  %2066 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2063, 0
  %2067 = insertvalue { <8 x ptr>, <8 x i64> } %2066, <8 x i64> %2065, 1
  %.splatinsert330 = insertelement <8 x i1> poison, i1 %1966, i64 0
  %.splat331 = shufflevector <8 x i1> %.splatinsert330, <8 x i1> poison, <8 x i32> zeroinitializer
  %2068 = extractvalue { <8 x ptr>, <8 x i64> } %2067, 0
  %2069 = extractvalue { <8 x ptr>, <8 x i64> } %2067, 1
  %2070 = getelementptr i8, <8 x ptr> %2068, <8 x i64> %2069
  %2071 = zext <8 x i1> %.splat331 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2071, <8 x ptr> align 1 %2070, <8 x i1> %101)
  %2072 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2073 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2074 = add <8 x i64> %2073, splat (i64 10)
  %2075 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2072, 0
  %2076 = insertvalue { <8 x ptr>, <8 x i64> } %2075, <8 x i64> %2074, 1
  %.splatinsert332 = insertelement <8 x i1> poison, i1 %1967, i64 0
  %.splat333 = shufflevector <8 x i1> %.splatinsert332, <8 x i1> poison, <8 x i32> zeroinitializer
  %2077 = extractvalue { <8 x ptr>, <8 x i64> } %2076, 0
  %2078 = extractvalue { <8 x ptr>, <8 x i64> } %2076, 1
  %2079 = getelementptr i8, <8 x ptr> %2077, <8 x i64> %2078
  %2080 = zext <8 x i1> %.splat333 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2080, <8 x ptr> align 1 %2079, <8 x i1> %101)
  %2081 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2082 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2083 = add <8 x i64> %2082, splat (i64 11)
  %2084 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2081, 0
  %2085 = insertvalue { <8 x ptr>, <8 x i64> } %2084, <8 x i64> %2083, 1
  %.splatinsert334 = insertelement <8 x i1> poison, i1 %1968, i64 0
  %.splat335 = shufflevector <8 x i1> %.splatinsert334, <8 x i1> poison, <8 x i32> zeroinitializer
  %2086 = extractvalue { <8 x ptr>, <8 x i64> } %2085, 0
  %2087 = extractvalue { <8 x ptr>, <8 x i64> } %2085, 1
  %2088 = getelementptr i8, <8 x ptr> %2086, <8 x i64> %2087
  %2089 = zext <8 x i1> %.splat335 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2089, <8 x ptr> align 1 %2088, <8 x i1> %101)
  %2090 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2091 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2092 = add <8 x i64> %2091, splat (i64 12)
  %2093 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2090, 0
  %2094 = insertvalue { <8 x ptr>, <8 x i64> } %2093, <8 x i64> %2092, 1
  %.splatinsert336 = insertelement <8 x i1> poison, i1 %1969, i64 0
  %.splat337 = shufflevector <8 x i1> %.splatinsert336, <8 x i1> poison, <8 x i32> zeroinitializer
  %2095 = extractvalue { <8 x ptr>, <8 x i64> } %2094, 0
  %2096 = extractvalue { <8 x ptr>, <8 x i64> } %2094, 1
  %2097 = getelementptr i8, <8 x ptr> %2095, <8 x i64> %2096
  %2098 = zext <8 x i1> %.splat337 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2098, <8 x ptr> align 1 %2097, <8 x i1> %101)
  %2099 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2100 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2101 = add <8 x i64> %2100, splat (i64 13)
  %2102 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2099, 0
  %2103 = insertvalue { <8 x ptr>, <8 x i64> } %2102, <8 x i64> %2101, 1
  %.splatinsert338 = insertelement <8 x i1> poison, i1 %1970, i64 0
  %.splat339 = shufflevector <8 x i1> %.splatinsert338, <8 x i1> poison, <8 x i32> zeroinitializer
  %2104 = extractvalue { <8 x ptr>, <8 x i64> } %2103, 0
  %2105 = extractvalue { <8 x ptr>, <8 x i64> } %2103, 1
  %2106 = getelementptr i8, <8 x ptr> %2104, <8 x i64> %2105
  %2107 = zext <8 x i1> %.splat339 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2107, <8 x ptr> align 1 %2106, <8 x i1> %101)
  %2108 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2109 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2110 = add <8 x i64> %2109, splat (i64 14)
  %2111 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2108, 0
  %2112 = insertvalue { <8 x ptr>, <8 x i64> } %2111, <8 x i64> %2110, 1
  %.splatinsert340 = insertelement <8 x i1> poison, i1 %1971, i64 0
  %.splat341 = shufflevector <8 x i1> %.splatinsert340, <8 x i1> poison, <8 x i32> zeroinitializer
  %2113 = extractvalue { <8 x ptr>, <8 x i64> } %2112, 0
  %2114 = extractvalue { <8 x ptr>, <8 x i64> } %2112, 1
  %2115 = getelementptr i8, <8 x ptr> %2113, <8 x i64> %2114
  %2116 = zext <8 x i1> %.splat341 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2116, <8 x ptr> align 1 %2115, <8 x i1> %101)
  %2117 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2118 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2119 = add <8 x i64> %2118, splat (i64 15)
  %2120 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2117, 0
  %2121 = insertvalue { <8 x ptr>, <8 x i64> } %2120, <8 x i64> %2119, 1
  %.splatinsert342 = insertelement <8 x i1> poison, i1 %1972, i64 0
  %.splat343 = shufflevector <8 x i1> %.splatinsert342, <8 x i1> poison, <8 x i32> zeroinitializer
  %2122 = extractvalue { <8 x ptr>, <8 x i64> } %2121, 0
  %2123 = extractvalue { <8 x ptr>, <8 x i64> } %2121, 1
  %2124 = getelementptr i8, <8 x ptr> %2122, <8 x i64> %2123
  %2125 = zext <8 x i1> %.splat343 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2125, <8 x ptr> align 1 %2124, <8 x i1> %101)
  %2126 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill100, align 64
  %2127 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2128 = extractvalue { <8 x ptr>, <8 x i64> } %2126, 0
  %2129 = select <8 x i1> %101, <8 x ptr> %2127, <8 x ptr> %2128
  %2130 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2131 = extractvalue { <8 x ptr>, <8 x i64> } %2126, 1
  %2132 = select <8 x i1> %101, <8 x i64> %2130, <8 x i64> %2131
  %2133 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2129, 0
  %2134 = insertvalue { <8 x ptr>, <8 x i64> } %2133, <8 x i64> %2132, 1
  store { <8 x ptr>, <8 x i64> } %2134, ptr %tile_snapshot.spill100, align 64
  %2135 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2136 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2137 = add <8 x i64> %2136, zeroinitializer
  %2138 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2135, 0
  %2139 = insertvalue { <8 x ptr>, <8 x i64> } %2138, <8 x i64> %2137, 1
  %.splatinsert344 = insertelement <8 x i64> poison, i64 %1941, i64 0
  %.splat345 = shufflevector <8 x i64> %.splatinsert344, <8 x i64> poison, <8 x i32> zeroinitializer
  %2140 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2141 = extractvalue { <8 x ptr>, <8 x i64> } %2139, 1
  %2142 = extractelement <8 x ptr> %2140, i32 0
  %2143 = extractelement <8 x i64> %2141, i32 0
  %2144 = sub i64 %2143, 0
  %2145 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2146 = select i1 %2145, i64 %2144, i64 0
  %private.contiguous.address346 = getelementptr i8, ptr %2142, i64 %2146
  %private.contiguous.preserve347 = load <8 x i64>, ptr %private.contiguous.address346, align 8
  %2147 = select <8 x i1> %101, <8 x i64> %.splat345, <8 x i64> %private.contiguous.preserve347
  store <8 x i64> %2147, ptr %private.contiguous.address346, align 8
  %2148 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2149 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2150 = add <8 x i64> %2149, splat (i64 64)
  %2151 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2148, 0
  %2152 = insertvalue { <8 x ptr>, <8 x i64> } %2151, <8 x i64> %2150, 1
  %.splatinsert348 = insertelement <8 x i64> poison, i64 %1942, i64 0
  %.splat349 = shufflevector <8 x i64> %.splatinsert348, <8 x i64> poison, <8 x i32> zeroinitializer
  %2153 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2154 = extractvalue { <8 x ptr>, <8 x i64> } %2152, 1
  %2155 = extractelement <8 x ptr> %2153, i32 0
  %2156 = extractelement <8 x i64> %2154, i32 0
  %2157 = sub i64 %2156, 0
  %2158 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2159 = select i1 %2158, i64 %2157, i64 0
  %private.contiguous.address350 = getelementptr i8, ptr %2155, i64 %2159
  %private.contiguous.preserve351 = load <8 x i64>, ptr %private.contiguous.address350, align 8
  %2160 = select <8 x i1> %101, <8 x i64> %.splat349, <8 x i64> %private.contiguous.preserve351
  store <8 x i64> %2160, ptr %private.contiguous.address350, align 8
  %2161 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2162 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2163 = add <8 x i64> %2162, splat (i64 128)
  %2164 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2161, 0
  %2165 = insertvalue { <8 x ptr>, <8 x i64> } %2164, <8 x i64> %2163, 1
  %.splatinsert352 = insertelement <8 x i64> poison, i64 %1943, i64 0
  %.splat353 = shufflevector <8 x i64> %.splatinsert352, <8 x i64> poison, <8 x i32> zeroinitializer
  %2166 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2167 = extractvalue { <8 x ptr>, <8 x i64> } %2165, 1
  %2168 = extractelement <8 x ptr> %2166, i32 0
  %2169 = extractelement <8 x i64> %2167, i32 0
  %2170 = sub i64 %2169, 0
  %2171 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2172 = select i1 %2171, i64 %2170, i64 0
  %private.contiguous.address354 = getelementptr i8, ptr %2168, i64 %2172
  %private.contiguous.preserve355 = load <8 x i64>, ptr %private.contiguous.address354, align 8
  %2173 = select <8 x i1> %101, <8 x i64> %.splat353, <8 x i64> %private.contiguous.preserve355
  store <8 x i64> %2173, ptr %private.contiguous.address354, align 8
  %2174 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2175 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2176 = add <8 x i64> %2175, splat (i64 192)
  %2177 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2174, 0
  %2178 = insertvalue { <8 x ptr>, <8 x i64> } %2177, <8 x i64> %2176, 1
  %.splatinsert356 = insertelement <8 x i64> poison, i64 %1944, i64 0
  %.splat357 = shufflevector <8 x i64> %.splatinsert356, <8 x i64> poison, <8 x i32> zeroinitializer
  %2179 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2180 = extractvalue { <8 x ptr>, <8 x i64> } %2178, 1
  %2181 = extractelement <8 x ptr> %2179, i32 0
  %2182 = extractelement <8 x i64> %2180, i32 0
  %2183 = sub i64 %2182, 0
  %2184 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2185 = select i1 %2184, i64 %2183, i64 0
  %private.contiguous.address358 = getelementptr i8, ptr %2181, i64 %2185
  %private.contiguous.preserve359 = load <8 x i64>, ptr %private.contiguous.address358, align 8
  %2186 = select <8 x i1> %101, <8 x i64> %.splat357, <8 x i64> %private.contiguous.preserve359
  store <8 x i64> %2186, ptr %private.contiguous.address358, align 8
  %2187 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2188 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2189 = add <8 x i64> %2188, splat (i64 256)
  %2190 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2187, 0
  %2191 = insertvalue { <8 x ptr>, <8 x i64> } %2190, <8 x i64> %2189, 1
  %.splatinsert360 = insertelement <8 x i64> poison, i64 %1945, i64 0
  %.splat361 = shufflevector <8 x i64> %.splatinsert360, <8 x i64> poison, <8 x i32> zeroinitializer
  %2192 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2193 = extractvalue { <8 x ptr>, <8 x i64> } %2191, 1
  %2194 = extractelement <8 x ptr> %2192, i32 0
  %2195 = extractelement <8 x i64> %2193, i32 0
  %2196 = sub i64 %2195, 0
  %2197 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2198 = select i1 %2197, i64 %2196, i64 0
  %private.contiguous.address362 = getelementptr i8, ptr %2194, i64 %2198
  %private.contiguous.preserve363 = load <8 x i64>, ptr %private.contiguous.address362, align 8
  %2199 = select <8 x i1> %101, <8 x i64> %.splat361, <8 x i64> %private.contiguous.preserve363
  store <8 x i64> %2199, ptr %private.contiguous.address362, align 8
  %2200 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2201 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2202 = add <8 x i64> %2201, splat (i64 320)
  %2203 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2200, 0
  %2204 = insertvalue { <8 x ptr>, <8 x i64> } %2203, <8 x i64> %2202, 1
  %.splatinsert364 = insertelement <8 x i64> poison, i64 %1946, i64 0
  %.splat365 = shufflevector <8 x i64> %.splatinsert364, <8 x i64> poison, <8 x i32> zeroinitializer
  %2205 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2206 = extractvalue { <8 x ptr>, <8 x i64> } %2204, 1
  %2207 = extractelement <8 x ptr> %2205, i32 0
  %2208 = extractelement <8 x i64> %2206, i32 0
  %2209 = sub i64 %2208, 0
  %2210 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2211 = select i1 %2210, i64 %2209, i64 0
  %private.contiguous.address366 = getelementptr i8, ptr %2207, i64 %2211
  %private.contiguous.preserve367 = load <8 x i64>, ptr %private.contiguous.address366, align 8
  %2212 = select <8 x i1> %101, <8 x i64> %.splat365, <8 x i64> %private.contiguous.preserve367
  store <8 x i64> %2212, ptr %private.contiguous.address366, align 8
  %2213 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2214 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2215 = add <8 x i64> %2214, splat (i64 384)
  %2216 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2213, 0
  %2217 = insertvalue { <8 x ptr>, <8 x i64> } %2216, <8 x i64> %2215, 1
  %.splatinsert368 = insertelement <8 x i64> poison, i64 %1947, i64 0
  %.splat369 = shufflevector <8 x i64> %.splatinsert368, <8 x i64> poison, <8 x i32> zeroinitializer
  %2218 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2219 = extractvalue { <8 x ptr>, <8 x i64> } %2217, 1
  %2220 = extractelement <8 x ptr> %2218, i32 0
  %2221 = extractelement <8 x i64> %2219, i32 0
  %2222 = sub i64 %2221, 0
  %2223 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2224 = select i1 %2223, i64 %2222, i64 0
  %private.contiguous.address370 = getelementptr i8, ptr %2220, i64 %2224
  %private.contiguous.preserve371 = load <8 x i64>, ptr %private.contiguous.address370, align 8
  %2225 = select <8 x i1> %101, <8 x i64> %.splat369, <8 x i64> %private.contiguous.preserve371
  store <8 x i64> %2225, ptr %private.contiguous.address370, align 8
  %2226 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2227 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2228 = add <8 x i64> %2227, splat (i64 448)
  %2229 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2226, 0
  %2230 = insertvalue { <8 x ptr>, <8 x i64> } %2229, <8 x i64> %2228, 1
  %.splatinsert372 = insertelement <8 x i64> poison, i64 %1948, i64 0
  %.splat373 = shufflevector <8 x i64> %.splatinsert372, <8 x i64> poison, <8 x i32> zeroinitializer
  %2231 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2232 = extractvalue { <8 x ptr>, <8 x i64> } %2230, 1
  %2233 = extractelement <8 x ptr> %2231, i32 0
  %2234 = extractelement <8 x i64> %2232, i32 0
  %2235 = sub i64 %2234, 0
  %2236 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2237 = select i1 %2236, i64 %2235, i64 0
  %private.contiguous.address374 = getelementptr i8, ptr %2233, i64 %2237
  %private.contiguous.preserve375 = load <8 x i64>, ptr %private.contiguous.address374, align 8
  %2238 = select <8 x i1> %101, <8 x i64> %.splat373, <8 x i64> %private.contiguous.preserve375
  store <8 x i64> %2238, ptr %private.contiguous.address374, align 8
  %2239 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2240 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2241 = add <8 x i64> %2240, splat (i64 512)
  %2242 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2239, 0
  %2243 = insertvalue { <8 x ptr>, <8 x i64> } %2242, <8 x i64> %2241, 1
  %.splatinsert376 = insertelement <8 x i64> poison, i64 %1949, i64 0
  %.splat377 = shufflevector <8 x i64> %.splatinsert376, <8 x i64> poison, <8 x i32> zeroinitializer
  %2244 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2245 = extractvalue { <8 x ptr>, <8 x i64> } %2243, 1
  %2246 = extractelement <8 x ptr> %2244, i32 0
  %2247 = extractelement <8 x i64> %2245, i32 0
  %2248 = sub i64 %2247, 0
  %2249 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2250 = select i1 %2249, i64 %2248, i64 0
  %private.contiguous.address378 = getelementptr i8, ptr %2246, i64 %2250
  %private.contiguous.preserve379 = load <8 x i64>, ptr %private.contiguous.address378, align 8
  %2251 = select <8 x i1> %101, <8 x i64> %.splat377, <8 x i64> %private.contiguous.preserve379
  store <8 x i64> %2251, ptr %private.contiguous.address378, align 8
  %2252 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2253 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2254 = add <8 x i64> %2253, splat (i64 576)
  %2255 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2252, 0
  %2256 = insertvalue { <8 x ptr>, <8 x i64> } %2255, <8 x i64> %2254, 1
  %.splatinsert380 = insertelement <8 x i64> poison, i64 %1950, i64 0
  %.splat381 = shufflevector <8 x i64> %.splatinsert380, <8 x i64> poison, <8 x i32> zeroinitializer
  %2257 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2258 = extractvalue { <8 x ptr>, <8 x i64> } %2256, 1
  %2259 = extractelement <8 x ptr> %2257, i32 0
  %2260 = extractelement <8 x i64> %2258, i32 0
  %2261 = sub i64 %2260, 0
  %2262 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2263 = select i1 %2262, i64 %2261, i64 0
  %private.contiguous.address382 = getelementptr i8, ptr %2259, i64 %2263
  %private.contiguous.preserve383 = load <8 x i64>, ptr %private.contiguous.address382, align 8
  %2264 = select <8 x i1> %101, <8 x i64> %.splat381, <8 x i64> %private.contiguous.preserve383
  store <8 x i64> %2264, ptr %private.contiguous.address382, align 8
  %2265 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2266 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2267 = add <8 x i64> %2266, splat (i64 640)
  %2268 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2265, 0
  %2269 = insertvalue { <8 x ptr>, <8 x i64> } %2268, <8 x i64> %2267, 1
  %.splatinsert384 = insertelement <8 x i64> poison, i64 %1951, i64 0
  %.splat385 = shufflevector <8 x i64> %.splatinsert384, <8 x i64> poison, <8 x i32> zeroinitializer
  %2270 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2271 = extractvalue { <8 x ptr>, <8 x i64> } %2269, 1
  %2272 = extractelement <8 x ptr> %2270, i32 0
  %2273 = extractelement <8 x i64> %2271, i32 0
  %2274 = sub i64 %2273, 0
  %2275 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2276 = select i1 %2275, i64 %2274, i64 0
  %private.contiguous.address386 = getelementptr i8, ptr %2272, i64 %2276
  %private.contiguous.preserve387 = load <8 x i64>, ptr %private.contiguous.address386, align 8
  %2277 = select <8 x i1> %101, <8 x i64> %.splat385, <8 x i64> %private.contiguous.preserve387
  store <8 x i64> %2277, ptr %private.contiguous.address386, align 8
  %2278 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2279 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2280 = add <8 x i64> %2279, splat (i64 704)
  %2281 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2278, 0
  %2282 = insertvalue { <8 x ptr>, <8 x i64> } %2281, <8 x i64> %2280, 1
  %.splatinsert388 = insertelement <8 x i64> poison, i64 %1952, i64 0
  %.splat389 = shufflevector <8 x i64> %.splatinsert388, <8 x i64> poison, <8 x i32> zeroinitializer
  %2283 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2284 = extractvalue { <8 x ptr>, <8 x i64> } %2282, 1
  %2285 = extractelement <8 x ptr> %2283, i32 0
  %2286 = extractelement <8 x i64> %2284, i32 0
  %2287 = sub i64 %2286, 0
  %2288 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2289 = select i1 %2288, i64 %2287, i64 0
  %private.contiguous.address390 = getelementptr i8, ptr %2285, i64 %2289
  %private.contiguous.preserve391 = load <8 x i64>, ptr %private.contiguous.address390, align 8
  %2290 = select <8 x i1> %101, <8 x i64> %.splat389, <8 x i64> %private.contiguous.preserve391
  store <8 x i64> %2290, ptr %private.contiguous.address390, align 8
  %2291 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2292 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2293 = add <8 x i64> %2292, splat (i64 768)
  %2294 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2291, 0
  %2295 = insertvalue { <8 x ptr>, <8 x i64> } %2294, <8 x i64> %2293, 1
  %.splatinsert392 = insertelement <8 x i64> poison, i64 %1953, i64 0
  %.splat393 = shufflevector <8 x i64> %.splatinsert392, <8 x i64> poison, <8 x i32> zeroinitializer
  %2296 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2297 = extractvalue { <8 x ptr>, <8 x i64> } %2295, 1
  %2298 = extractelement <8 x ptr> %2296, i32 0
  %2299 = extractelement <8 x i64> %2297, i32 0
  %2300 = sub i64 %2299, 0
  %2301 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2302 = select i1 %2301, i64 %2300, i64 0
  %private.contiguous.address394 = getelementptr i8, ptr %2298, i64 %2302
  %private.contiguous.preserve395 = load <8 x i64>, ptr %private.contiguous.address394, align 8
  %2303 = select <8 x i1> %101, <8 x i64> %.splat393, <8 x i64> %private.contiguous.preserve395
  store <8 x i64> %2303, ptr %private.contiguous.address394, align 8
  %2304 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2305 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2306 = add <8 x i64> %2305, splat (i64 832)
  %2307 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2304, 0
  %2308 = insertvalue { <8 x ptr>, <8 x i64> } %2307, <8 x i64> %2306, 1
  %.splatinsert396 = insertelement <8 x i64> poison, i64 %1954, i64 0
  %.splat397 = shufflevector <8 x i64> %.splatinsert396, <8 x i64> poison, <8 x i32> zeroinitializer
  %2309 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2310 = extractvalue { <8 x ptr>, <8 x i64> } %2308, 1
  %2311 = extractelement <8 x ptr> %2309, i32 0
  %2312 = extractelement <8 x i64> %2310, i32 0
  %2313 = sub i64 %2312, 0
  %2314 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2315 = select i1 %2314, i64 %2313, i64 0
  %private.contiguous.address398 = getelementptr i8, ptr %2311, i64 %2315
  %private.contiguous.preserve399 = load <8 x i64>, ptr %private.contiguous.address398, align 8
  %2316 = select <8 x i1> %101, <8 x i64> %.splat397, <8 x i64> %private.contiguous.preserve399
  store <8 x i64> %2316, ptr %private.contiguous.address398, align 8
  %2317 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2318 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2319 = add <8 x i64> %2318, splat (i64 896)
  %2320 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2317, 0
  %2321 = insertvalue { <8 x ptr>, <8 x i64> } %2320, <8 x i64> %2319, 1
  %.splatinsert400 = insertelement <8 x i64> poison, i64 %1955, i64 0
  %.splat401 = shufflevector <8 x i64> %.splatinsert400, <8 x i64> poison, <8 x i32> zeroinitializer
  %2322 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2323 = extractvalue { <8 x ptr>, <8 x i64> } %2321, 1
  %2324 = extractelement <8 x ptr> %2322, i32 0
  %2325 = extractelement <8 x i64> %2323, i32 0
  %2326 = sub i64 %2325, 0
  %2327 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2328 = select i1 %2327, i64 %2326, i64 0
  %private.contiguous.address402 = getelementptr i8, ptr %2324, i64 %2328
  %private.contiguous.preserve403 = load <8 x i64>, ptr %private.contiguous.address402, align 8
  %2329 = select <8 x i1> %101, <8 x i64> %.splat401, <8 x i64> %private.contiguous.preserve403
  store <8 x i64> %2329, ptr %private.contiguous.address402, align 8
  %2330 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2331 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2332 = add <8 x i64> %2331, splat (i64 960)
  %2333 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2330, 0
  %2334 = insertvalue { <8 x ptr>, <8 x i64> } %2333, <8 x i64> %2332, 1
  %.splatinsert404 = insertelement <8 x i64> poison, i64 %1956, i64 0
  %.splat405 = shufflevector <8 x i64> %.splatinsert404, <8 x i64> poison, <8 x i32> zeroinitializer
  %2335 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2336 = extractvalue { <8 x ptr>, <8 x i64> } %2334, 1
  %2337 = extractelement <8 x ptr> %2335, i32 0
  %2338 = extractelement <8 x i64> %2336, i32 0
  %2339 = sub i64 %2338, 0
  %2340 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2341 = select i1 %2340, i64 %2339, i64 0
  %private.contiguous.address406 = getelementptr i8, ptr %2337, i64 %2341
  %private.contiguous.preserve407 = load <8 x i64>, ptr %private.contiguous.address406, align 8
  %2342 = select <8 x i1> %101, <8 x i64> %.splat405, <8 x i64> %private.contiguous.preserve407
  store <8 x i64> %2342, ptr %private.contiguous.address406, align 8
  %.spill.load408 = load <8 x i64>, ptr %.spill69, align 64
  %2343 = add <8 x i64> zeroinitializer, %.spill.load408
  %.spill.load409 = load <8 x i64>, ptr %.spill69, align 64
  %2344 = add <8 x i64> splat (i64 1), %.spill.load409
  %.spill.load410 = load <8 x i64>, ptr %.spill69, align 64
  %2345 = add <8 x i64> splat (i64 2), %.spill.load410
  %.spill.load411 = load <8 x i64>, ptr %.spill69, align 64
  %2346 = add <8 x i64> splat (i64 3), %.spill.load411
  %.spill.load412 = load <8 x i64>, ptr %.spill69, align 64
  %2347 = add <8 x i64> splat (i64 4), %.spill.load412
  %.spill.load413 = load <8 x i64>, ptr %.spill69, align 64
  %2348 = add <8 x i64> splat (i64 5), %.spill.load413
  %.spill.load414 = load <8 x i64>, ptr %.spill69, align 64
  %2349 = add <8 x i64> splat (i64 6), %.spill.load414
  %.spill.load415 = load <8 x i64>, ptr %.spill69, align 64
  %2350 = add <8 x i64> splat (i64 7), %.spill.load415
  %2351 = add <8 x i64> %2343, splat (i64 129)
  %2352 = add <8 x i64> %2344, splat (i64 129)
  %2353 = add <8 x i64> %2345, splat (i64 129)
  %2354 = add <8 x i64> %2346, splat (i64 129)
  %2355 = add <8 x i64> %2347, splat (i64 129)
  %2356 = add <8 x i64> %2348, splat (i64 129)
  %2357 = add <8 x i64> %2349, splat (i64 129)
  %2358 = add <8 x i64> %2350, splat (i64 129)
  %2359 = sub <8 x i64> %2351, splat (i64 64)
  %2360 = sub <8 x i64> %2352, splat (i64 64)
  %2361 = sub <8 x i64> %2353, splat (i64 64)
  %2362 = sub <8 x i64> %2354, splat (i64 64)
  %2363 = sub <8 x i64> %2355, splat (i64 64)
  %2364 = sub <8 x i64> %2356, splat (i64 64)
  %2365 = sub <8 x i64> %2357, splat (i64 64)
  %2366 = sub <8 x i64> %2358, splat (i64 64)
  %2367 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill101, align 64
  %2368 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2369 = extractvalue { <8 x ptr>, <8 x i64> } %2367, 0
  %2370 = select <8 x i1> %101, <8 x ptr> %2368, <8 x ptr> %2369
  %2371 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %2372 = extractvalue { <8 x ptr>, <8 x i64> } %2367, 1
  %2373 = select <8 x i1> %101, <8 x i64> %2371, <8 x i64> %2372
  %2374 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2370, 0
  %2375 = insertvalue { <8 x ptr>, <8 x i64> } %2374, <8 x i64> %2373, 1
  store { <8 x ptr>, <8 x i64> } %2375, ptr %tile_snapshot.spill101, align 64
  %2376 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2377 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %2378 = add <8 x i64> %2377, zeroinitializer
  %2379 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2376, 0
  %2380 = insertvalue { <8 x ptr>, <8 x i64> } %2379, <8 x i64> %2378, 1
  %2381 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2382 = extractvalue { <8 x ptr>, <8 x i64> } %2380, 1
  %2383 = extractelement <8 x ptr> %2381, i32 0
  %2384 = extractelement <8 x i64> %2382, i32 0
  %2385 = sub i64 %2384, 0
  %2386 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2387 = select i1 %2386, i64 %2385, i64 0
  %private.contiguous.address416 = getelementptr i8, ptr %2383, i64 %2387
  %private.contiguous.preserve417 = load <8 x i64>, ptr %private.contiguous.address416, align 8
  %2388 = select <8 x i1> %101, <8 x i64> %2359, <8 x i64> %private.contiguous.preserve417
  store <8 x i64> %2388, ptr %private.contiguous.address416, align 8
  %2389 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2390 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %2391 = add <8 x i64> %2390, splat (i64 64)
  %2392 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2389, 0
  %2393 = insertvalue { <8 x ptr>, <8 x i64> } %2392, <8 x i64> %2391, 1
  %2394 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2395 = extractvalue { <8 x ptr>, <8 x i64> } %2393, 1
  %2396 = extractelement <8 x ptr> %2394, i32 0
  %2397 = extractelement <8 x i64> %2395, i32 0
  %2398 = sub i64 %2397, 0
  %2399 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2400 = select i1 %2399, i64 %2398, i64 0
  %private.contiguous.address418 = getelementptr i8, ptr %2396, i64 %2400
  %private.contiguous.preserve419 = load <8 x i64>, ptr %private.contiguous.address418, align 8
  %2401 = select <8 x i1> %101, <8 x i64> %2360, <8 x i64> %private.contiguous.preserve419
  store <8 x i64> %2401, ptr %private.contiguous.address418, align 8
  %2402 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2403 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %2404 = add <8 x i64> %2403, splat (i64 128)
  %2405 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2402, 0
  %2406 = insertvalue { <8 x ptr>, <8 x i64> } %2405, <8 x i64> %2404, 1
  %2407 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2408 = extractvalue { <8 x ptr>, <8 x i64> } %2406, 1
  %2409 = extractelement <8 x ptr> %2407, i32 0
  %2410 = extractelement <8 x i64> %2408, i32 0
  %2411 = sub i64 %2410, 0
  %2412 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2413 = select i1 %2412, i64 %2411, i64 0
  %private.contiguous.address420 = getelementptr i8, ptr %2409, i64 %2413
  %private.contiguous.preserve421 = load <8 x i64>, ptr %private.contiguous.address420, align 8
  %2414 = select <8 x i1> %101, <8 x i64> %2361, <8 x i64> %private.contiguous.preserve421
  store <8 x i64> %2414, ptr %private.contiguous.address420, align 8
  %2415 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2416 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %2417 = add <8 x i64> %2416, splat (i64 192)
  %2418 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2415, 0
  %2419 = insertvalue { <8 x ptr>, <8 x i64> } %2418, <8 x i64> %2417, 1
  %2420 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2421 = extractvalue { <8 x ptr>, <8 x i64> } %2419, 1
  %2422 = extractelement <8 x ptr> %2420, i32 0
  %2423 = extractelement <8 x i64> %2421, i32 0
  %2424 = sub i64 %2423, 0
  %2425 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2426 = select i1 %2425, i64 %2424, i64 0
  %private.contiguous.address422 = getelementptr i8, ptr %2422, i64 %2426
  %private.contiguous.preserve423 = load <8 x i64>, ptr %private.contiguous.address422, align 8
  %2427 = select <8 x i1> %101, <8 x i64> %2362, <8 x i64> %private.contiguous.preserve423
  store <8 x i64> %2427, ptr %private.contiguous.address422, align 8
  %2428 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2429 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %2430 = add <8 x i64> %2429, splat (i64 256)
  %2431 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2428, 0
  %2432 = insertvalue { <8 x ptr>, <8 x i64> } %2431, <8 x i64> %2430, 1
  %2433 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2434 = extractvalue { <8 x ptr>, <8 x i64> } %2432, 1
  %2435 = extractelement <8 x ptr> %2433, i32 0
  %2436 = extractelement <8 x i64> %2434, i32 0
  %2437 = sub i64 %2436, 0
  %2438 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2439 = select i1 %2438, i64 %2437, i64 0
  %private.contiguous.address424 = getelementptr i8, ptr %2435, i64 %2439
  %private.contiguous.preserve425 = load <8 x i64>, ptr %private.contiguous.address424, align 8
  %2440 = select <8 x i1> %101, <8 x i64> %2363, <8 x i64> %private.contiguous.preserve425
  store <8 x i64> %2440, ptr %private.contiguous.address424, align 8
  %2441 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2442 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %2443 = add <8 x i64> %2442, splat (i64 320)
  %2444 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2441, 0
  %2445 = insertvalue { <8 x ptr>, <8 x i64> } %2444, <8 x i64> %2443, 1
  %2446 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2447 = extractvalue { <8 x ptr>, <8 x i64> } %2445, 1
  %2448 = extractelement <8 x ptr> %2446, i32 0
  %2449 = extractelement <8 x i64> %2447, i32 0
  %2450 = sub i64 %2449, 0
  %2451 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2452 = select i1 %2451, i64 %2450, i64 0
  %private.contiguous.address426 = getelementptr i8, ptr %2448, i64 %2452
  %private.contiguous.preserve427 = load <8 x i64>, ptr %private.contiguous.address426, align 8
  %2453 = select <8 x i1> %101, <8 x i64> %2364, <8 x i64> %private.contiguous.preserve427
  store <8 x i64> %2453, ptr %private.contiguous.address426, align 8
  %2454 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2455 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %2456 = add <8 x i64> %2455, splat (i64 384)
  %2457 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2454, 0
  %2458 = insertvalue { <8 x ptr>, <8 x i64> } %2457, <8 x i64> %2456, 1
  %2459 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2460 = extractvalue { <8 x ptr>, <8 x i64> } %2458, 1
  %2461 = extractelement <8 x ptr> %2459, i32 0
  %2462 = extractelement <8 x i64> %2460, i32 0
  %2463 = sub i64 %2462, 0
  %2464 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2465 = select i1 %2464, i64 %2463, i64 0
  %private.contiguous.address428 = getelementptr i8, ptr %2461, i64 %2465
  %private.contiguous.preserve429 = load <8 x i64>, ptr %private.contiguous.address428, align 8
  %2466 = select <8 x i1> %101, <8 x i64> %2365, <8 x i64> %private.contiguous.preserve429
  store <8 x i64> %2466, ptr %private.contiguous.address428, align 8
  %2467 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2468 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %2469 = add <8 x i64> %2468, splat (i64 448)
  %2470 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2467, 0
  %2471 = insertvalue { <8 x ptr>, <8 x i64> } %2470, <8 x i64> %2469, 1
  %2472 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2473 = extractvalue { <8 x ptr>, <8 x i64> } %2471, 1
  %2474 = extractelement <8 x ptr> %2472, i32 0
  %2475 = extractelement <8 x i64> %2473, i32 0
  %2476 = sub i64 %2475, 0
  %2477 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2478 = select i1 %2477, i64 %2476, i64 0
  %private.contiguous.address430 = getelementptr i8, ptr %2474, i64 %2478
  %private.contiguous.preserve431 = load <8 x i64>, ptr %private.contiguous.address430, align 8
  %2479 = select <8 x i1> %101, <8 x i64> %2366, <8 x i64> %private.contiguous.preserve431
  store <8 x i64> %2479, ptr %private.contiguous.address430, align 8
  %2480 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill102, align 64
  %2481 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %2482 = extractvalue { <8 x ptr>, <8 x i64> } %2480, 0
  %2483 = select <8 x i1> %101, <8 x ptr> %2481, <8 x ptr> %2482
  %2484 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %2485 = extractvalue { <8 x ptr>, <8 x i64> } %2480, 1
  %2486 = select <8 x i1> %101, <8 x i64> %2484, <8 x i64> %2485
  %2487 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2483, 0
  %2488 = insertvalue { <8 x ptr>, <8 x i64> } %2487, <8 x i64> %2486, 1
  store { <8 x ptr>, <8 x i64> } %2488, ptr %tile_snapshot.spill102, align 64
  store i64 0, ptr %.slot103, align 4
  br label %direct.schedule.13

direct.true433:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false434:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true455:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false456:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true473:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false474:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true485:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false486:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24

direct.true497:                                   ; preds = %direct.schedule.25
  br label %direct.schedule.26

direct.false498:                                  ; preds = %direct.schedule.25
  br label %direct.schedule.27

direct.true509:                                   ; preds = %direct.schedule.28
  br label %direct.schedule.29

direct.false510:                                  ; preds = %direct.schedule.28
  br label %direct.schedule.30

direct.true521:                                   ; preds = %direct.schedule.31
  br label %direct.schedule.32

direct.false522:                                  ; preds = %direct.schedule.31
  br label %direct.schedule.33

direct.true533:                                   ; preds = %direct.schedule.34
  br label %direct.schedule.35

direct.false534:                                  ; preds = %direct.schedule.34
  br label %direct.schedule.36

direct.true545:                                   ; preds = %direct.schedule.37
  br label %direct.schedule.38

direct.false546:                                  ; preds = %direct.schedule.37
  br label %direct.schedule.39

direct.true557:                                   ; preds = %direct.schedule.40
  br label %direct.schedule.41

direct.false558:                                  ; preds = %direct.schedule.40
  br label %direct.schedule.42

direct.true632:                                   ; preds = %direct.schedule.43
  br label %direct.schedule.44

direct.false633:                                  ; preds = %direct.schedule.43
  br label %direct.schedule.45

direct.true672:                                   ; preds = %direct.schedule.46
  br label %direct.schedule.47

direct.false673:                                  ; preds = %direct.schedule.46
  br label %direct.schedule.48

direct.true682:                                   ; preds = %direct.schedule.49
  br label %direct.schedule.50

direct.false683:                                  ; preds = %direct.schedule.49
  br label %direct.schedule.51

direct.true692:                                   ; preds = %direct.schedule.52
  br label %direct.schedule.53

direct.false693:                                  ; preds = %direct.schedule.52
  br label %direct.schedule.54

direct.true702:                                   ; preds = %direct.schedule.55
  br label %direct.schedule.56

direct.false703:                                  ; preds = %direct.schedule.55
  br label %direct.schedule.57

direct.true712:                                   ; preds = %direct.schedule.58
  br label %direct.schedule.59

direct.false713:                                  ; preds = %direct.schedule.58
  br label %direct.schedule.60

direct.true722:                                   ; preds = %direct.schedule.61
  br label %direct.schedule.62

direct.false723:                                  ; preds = %direct.schedule.61
  br label %direct.schedule.63

direct.true732:                                   ; preds = %direct.schedule.64
  br label %direct.schedule.65

direct.false733:                                  ; preds = %direct.schedule.64
  br label %direct.schedule.66

direct.true742:                                   ; preds = %direct.schedule.67
  br label %direct.schedule.68

direct.false743:                                  ; preds = %direct.schedule.67
  br label %direct.schedule.69

direct.true768:                                   ; preds = %direct.schedule.70
  br label %direct.schedule.71

direct.false769:                                  ; preds = %direct.schedule.70
  br label %direct.schedule.72

mma.active790:                                    ; preds = %direct.schedule.72
  %2489 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load787, 0
  %2490 = extractelement <8 x ptr> %2489, i64 0
  %2491 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load787, 1
  %2492 = extractelement <8 x i64> %2491, i64 0
  %2493 = getelementptr i8, ptr %2490, i64 %2492
  %2494 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load788, 0
  %2495 = extractelement <8 x ptr> %2494, i64 0
  %2496 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load788, 1
  %2497 = extractelement <8 x i64> %2496, i64 0
  %2498 = getelementptr i8, ptr %2495, i64 %2497
  %2499 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load789, 0
  %2500 = extractelement <8 x ptr> %2499, i64 0
  %2501 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load789, 1
  %2502 = extractelement <8 x i64> %2501, i64 0
  %2503 = getelementptr i8, ptr %2500, i64 %2502
  %2504 = extractvalue { <8 x ptr>, <8 x i64> } %50, 0
  %2505 = extractelement <8 x ptr> %2504, i64 0
  %2506 = extractvalue { <8 x ptr>, <8 x i64> } %50, 1
  %2507 = extractelement <8 x i64> %2506, i64 0
  %2508 = getelementptr i8, ptr %2505, i64 %2507
  call void @llm_attention.strided_mma.3(ptr %2493, ptr %2498, ptr %2503, ptr %2508)
  br label %mma.continue791

mma.continue791:                                  ; preds = %mma.active790, %direct.schedule.72
  %2509 = extractelement <8 x i1> %101, i64 1
  br i1 %2509, label %mma.active792, label %mma.continue793

mma.active792:                                    ; preds = %mma.continue791
  %2510 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load787, 0
  %2511 = extractelement <8 x ptr> %2510, i64 1
  %2512 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load787, 1
  %2513 = extractelement <8 x i64> %2512, i64 1
  %2514 = getelementptr i8, ptr %2511, i64 %2513
  %2515 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load788, 0
  %2516 = extractelement <8 x ptr> %2515, i64 1
  %2517 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load788, 1
  %2518 = extractelement <8 x i64> %2517, i64 1
  %2519 = getelementptr i8, ptr %2516, i64 %2518
  %2520 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load789, 0
  %2521 = extractelement <8 x ptr> %2520, i64 1
  %2522 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load789, 1
  %2523 = extractelement <8 x i64> %2522, i64 1
  %2524 = getelementptr i8, ptr %2521, i64 %2523
  %2525 = extractvalue { <8 x ptr>, <8 x i64> } %50, 0
  %2526 = extractelement <8 x ptr> %2525, i64 1
  %2527 = extractvalue { <8 x ptr>, <8 x i64> } %50, 1
  %2528 = extractelement <8 x i64> %2527, i64 1
  %2529 = getelementptr i8, ptr %2526, i64 %2528
  call void @llm_attention.strided_mma.3(ptr %2514, ptr %2519, ptr %2524, ptr %2529)
  br label %mma.continue793

mma.continue793:                                  ; preds = %mma.active792, %mma.continue791
  %2530 = extractelement <8 x i1> %101, i64 2
  br i1 %2530, label %mma.active794, label %mma.continue795

mma.active794:                                    ; preds = %mma.continue793
  %2531 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load787, 0
  %2532 = extractelement <8 x ptr> %2531, i64 2
  %2533 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load787, 1
  %2534 = extractelement <8 x i64> %2533, i64 2
  %2535 = getelementptr i8, ptr %2532, i64 %2534
  %2536 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load788, 0
  %2537 = extractelement <8 x ptr> %2536, i64 2
  %2538 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load788, 1
  %2539 = extractelement <8 x i64> %2538, i64 2
  %2540 = getelementptr i8, ptr %2537, i64 %2539
  %2541 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load789, 0
  %2542 = extractelement <8 x ptr> %2541, i64 2
  %2543 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load789, 1
  %2544 = extractelement <8 x i64> %2543, i64 2
  %2545 = getelementptr i8, ptr %2542, i64 %2544
  %2546 = extractvalue { <8 x ptr>, <8 x i64> } %50, 0
  %2547 = extractelement <8 x ptr> %2546, i64 2
  %2548 = extractvalue { <8 x ptr>, <8 x i64> } %50, 1
  %2549 = extractelement <8 x i64> %2548, i64 2
  %2550 = getelementptr i8, ptr %2547, i64 %2549
  call void @llm_attention.strided_mma.3(ptr %2535, ptr %2540, ptr %2545, ptr %2550)
  br label %mma.continue795

mma.continue795:                                  ; preds = %mma.active794, %mma.continue793
  %2551 = extractelement <8 x i1> %101, i64 3
  br i1 %2551, label %mma.active796, label %mma.continue797

mma.active796:                                    ; preds = %mma.continue795
  %2552 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load787, 0
  %2553 = extractelement <8 x ptr> %2552, i64 3
  %2554 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load787, 1
  %2555 = extractelement <8 x i64> %2554, i64 3
  %2556 = getelementptr i8, ptr %2553, i64 %2555
  %2557 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load788, 0
  %2558 = extractelement <8 x ptr> %2557, i64 3
  %2559 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load788, 1
  %2560 = extractelement <8 x i64> %2559, i64 3
  %2561 = getelementptr i8, ptr %2558, i64 %2560
  %2562 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load789, 0
  %2563 = extractelement <8 x ptr> %2562, i64 3
  %2564 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load789, 1
  %2565 = extractelement <8 x i64> %2564, i64 3
  %2566 = getelementptr i8, ptr %2563, i64 %2565
  %2567 = extractvalue { <8 x ptr>, <8 x i64> } %50, 0
  %2568 = extractelement <8 x ptr> %2567, i64 3
  %2569 = extractvalue { <8 x ptr>, <8 x i64> } %50, 1
  %2570 = extractelement <8 x i64> %2569, i64 3
  %2571 = getelementptr i8, ptr %2568, i64 %2570
  call void @llm_attention.strided_mma.3(ptr %2556, ptr %2561, ptr %2566, ptr %2571)
  br label %mma.continue797

mma.continue797:                                  ; preds = %mma.active796, %mma.continue795
  %2572 = extractelement <8 x i1> %101, i64 4
  br i1 %2572, label %mma.active798, label %mma.continue799

mma.active798:                                    ; preds = %mma.continue797
  %2573 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load787, 0
  %2574 = extractelement <8 x ptr> %2573, i64 4
  %2575 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load787, 1
  %2576 = extractelement <8 x i64> %2575, i64 4
  %2577 = getelementptr i8, ptr %2574, i64 %2576
  %2578 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load788, 0
  %2579 = extractelement <8 x ptr> %2578, i64 4
  %2580 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load788, 1
  %2581 = extractelement <8 x i64> %2580, i64 4
  %2582 = getelementptr i8, ptr %2579, i64 %2581
  %2583 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load789, 0
  %2584 = extractelement <8 x ptr> %2583, i64 4
  %2585 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load789, 1
  %2586 = extractelement <8 x i64> %2585, i64 4
  %2587 = getelementptr i8, ptr %2584, i64 %2586
  %2588 = extractvalue { <8 x ptr>, <8 x i64> } %50, 0
  %2589 = extractelement <8 x ptr> %2588, i64 4
  %2590 = extractvalue { <8 x ptr>, <8 x i64> } %50, 1
  %2591 = extractelement <8 x i64> %2590, i64 4
  %2592 = getelementptr i8, ptr %2589, i64 %2591
  call void @llm_attention.strided_mma.3(ptr %2577, ptr %2582, ptr %2587, ptr %2592)
  br label %mma.continue799

mma.continue799:                                  ; preds = %mma.active798, %mma.continue797
  %2593 = extractelement <8 x i1> %101, i64 5
  br i1 %2593, label %mma.active800, label %mma.continue801

mma.active800:                                    ; preds = %mma.continue799
  %2594 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load787, 0
  %2595 = extractelement <8 x ptr> %2594, i64 5
  %2596 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load787, 1
  %2597 = extractelement <8 x i64> %2596, i64 5
  %2598 = getelementptr i8, ptr %2595, i64 %2597
  %2599 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load788, 0
  %2600 = extractelement <8 x ptr> %2599, i64 5
  %2601 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load788, 1
  %2602 = extractelement <8 x i64> %2601, i64 5
  %2603 = getelementptr i8, ptr %2600, i64 %2602
  %2604 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load789, 0
  %2605 = extractelement <8 x ptr> %2604, i64 5
  %2606 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load789, 1
  %2607 = extractelement <8 x i64> %2606, i64 5
  %2608 = getelementptr i8, ptr %2605, i64 %2607
  %2609 = extractvalue { <8 x ptr>, <8 x i64> } %50, 0
  %2610 = extractelement <8 x ptr> %2609, i64 5
  %2611 = extractvalue { <8 x ptr>, <8 x i64> } %50, 1
  %2612 = extractelement <8 x i64> %2611, i64 5
  %2613 = getelementptr i8, ptr %2610, i64 %2612
  call void @llm_attention.strided_mma.3(ptr %2598, ptr %2603, ptr %2608, ptr %2613)
  br label %mma.continue801

mma.continue801:                                  ; preds = %mma.active800, %mma.continue799
  %2614 = extractelement <8 x i1> %101, i64 6
  br i1 %2614, label %mma.active802, label %mma.continue803

mma.active802:                                    ; preds = %mma.continue801
  %2615 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load787, 0
  %2616 = extractelement <8 x ptr> %2615, i64 6
  %2617 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load787, 1
  %2618 = extractelement <8 x i64> %2617, i64 6
  %2619 = getelementptr i8, ptr %2616, i64 %2618
  %2620 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load788, 0
  %2621 = extractelement <8 x ptr> %2620, i64 6
  %2622 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load788, 1
  %2623 = extractelement <8 x i64> %2622, i64 6
  %2624 = getelementptr i8, ptr %2621, i64 %2623
  %2625 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load789, 0
  %2626 = extractelement <8 x ptr> %2625, i64 6
  %2627 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load789, 1
  %2628 = extractelement <8 x i64> %2627, i64 6
  %2629 = getelementptr i8, ptr %2626, i64 %2628
  %2630 = extractvalue { <8 x ptr>, <8 x i64> } %50, 0
  %2631 = extractelement <8 x ptr> %2630, i64 6
  %2632 = extractvalue { <8 x ptr>, <8 x i64> } %50, 1
  %2633 = extractelement <8 x i64> %2632, i64 6
  %2634 = getelementptr i8, ptr %2631, i64 %2633
  call void @llm_attention.strided_mma.3(ptr %2619, ptr %2624, ptr %2629, ptr %2634)
  br label %mma.continue803

mma.continue803:                                  ; preds = %mma.active802, %mma.continue801
  %2635 = extractelement <8 x i1> %101, i64 7
  br i1 %2635, label %mma.active804, label %mma.continue805

mma.active804:                                    ; preds = %mma.continue803
  %2636 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load787, 0
  %2637 = extractelement <8 x ptr> %2636, i64 7
  %2638 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load787, 1
  %2639 = extractelement <8 x i64> %2638, i64 7
  %2640 = getelementptr i8, ptr %2637, i64 %2639
  %2641 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load788, 0
  %2642 = extractelement <8 x ptr> %2641, i64 7
  %2643 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load788, 1
  %2644 = extractelement <8 x i64> %2643, i64 7
  %2645 = getelementptr i8, ptr %2642, i64 %2644
  %2646 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load789, 0
  %2647 = extractelement <8 x ptr> %2646, i64 7
  %2648 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load789, 1
  %2649 = extractelement <8 x i64> %2648, i64 7
  %2650 = getelementptr i8, ptr %2647, i64 %2649
  %2651 = extractvalue { <8 x ptr>, <8 x i64> } %50, 0
  %2652 = extractelement <8 x ptr> %2651, i64 7
  %2653 = extractvalue { <8 x ptr>, <8 x i64> } %50, 1
  %2654 = extractelement <8 x i64> %2653, i64 7
  %2655 = getelementptr i8, ptr %2652, i64 %2654
  call void @llm_attention.strided_mma.3(ptr %2640, ptr %2645, ptr %2650, ptr %2655)
  br label %mma.continue805

mma.continue805:                                  ; preds = %mma.active804, %mma.continue803
  store i64 0, ptr %.slot177, align 4
  br label %direct.schedule.73

direct.true807:                                   ; preds = %direct.schedule.73
  br label %direct.schedule.74

direct.false808:                                  ; preds = %direct.schedule.73
  br label %direct.schedule.75

direct.true821:                                   ; preds = %direct.schedule.76
  br label %direct.schedule.77

direct.false822:                                  ; preds = %direct.schedule.76
  br label %direct.schedule.78

direct.true854:                                   ; preds = %direct.schedule.80
  br label %direct.schedule.81

direct.false855:                                  ; preds = %direct.schedule.80
  br label %direct.schedule.9

direct.true867:                                   ; preds = %direct.schedule.81
  br label %direct.schedule.82

direct.false868:                                  ; preds = %direct.schedule.81
  %2656 = load <8 x float>, ptr %.slot181, align 32
  %2657 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %2656
  store <8 x float> %2657, ptr %.slot181, align 32
  br label %direct.schedule.83

direct.true879:                                   ; preds = %direct.schedule.85
  br label %direct.schedule.86

direct.false880:                                  ; preds = %direct.schedule.85
  br label %direct.schedule.7

direct.true892:                                   ; preds = %direct.schedule.86
  br label %direct.schedule.87

direct.false893:                                  ; preds = %direct.schedule.86
  %2658 = load <8 x float>, ptr %.slot184, align 32
  %2659 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %2658
  store <8 x float> %2659, ptr %.slot184, align 32
  br label %direct.schedule.88

direct.true928:                                   ; preds = %direct.schedule.90
  br label %direct.schedule.91

direct.false929:                                  ; preds = %direct.schedule.90
  br label %direct.schedule.92
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nounwind willreturn
define private void @llm_attention.contiguous_copy(ptr %0, i64 %1, ptr %2) #1 {
entry:
  %3 = getelementptr i32, ptr %0, i64 %1
  br label %copy.loop

copy.loop:                                        ; preds = %copy.chunk, %entry
  %copy.index = phi i64 [ 0, %entry ], [ %10, %copy.chunk ]
  %4 = icmp ult i64 %copy.index, 64
  br i1 %4, label %copy.chunk, label %copy.next

copy.chunk:                                       ; preds = %copy.loop
  %5 = mul i64 %copy.index, 4
  %6 = add i64 0, %5
  %7 = getelementptr i32, ptr %3, i64 %6
  %8 = load <4 x i32>, ptr %7, align 4
  %9 = getelementptr i32, ptr %2, i64 %6
  store <4 x i32> %8, ptr %9, align 4
  %10 = add i64 %copy.index, 1
  br label %copy.loop

copy.next:                                        ; preds = %copy.loop
  ret void
}

; Function Attrs: nounwind willreturn
define private void @llm_attention.contiguous_copy.1(ptr %0, i64 %1, ptr %2) #1 {
entry:
  %3 = getelementptr i32, ptr %0, i64 %1
  br label %copy.loop

copy.loop:                                        ; preds = %copy.chunk, %entry
  %copy.index = phi i64 [ 0, %entry ], [ %10, %copy.chunk ]
  %4 = icmp ult i64 %copy.index, 128
  br i1 %4, label %copy.chunk, label %copy.next

copy.chunk:                                       ; preds = %copy.loop
  %5 = mul i64 %copy.index, 4
  %6 = add i64 0, %5
  %7 = getelementptr i32, ptr %3, i64 %6
  %8 = load <4 x i32>, ptr %7, align 4
  %9 = getelementptr i32, ptr %2, i64 %6
  store <4 x i32> %8, ptr %9, align 4
  %10 = add i64 %copy.index, 1
  br label %copy.loop

copy.next:                                        ; preds = %copy.loop
  ret void
}

; Function Attrs: nounwind willreturn
define private void @llm_attention.contiguous_copy.2(ptr %0, i64 %1, ptr %2) #1 {
entry:
  %3 = getelementptr i32, ptr %0, i64 %1
  br label %copy.loop

copy.loop:                                        ; preds = %copy.chunk, %entry
  %copy.index = phi i64 [ 0, %entry ], [ %10, %copy.chunk ]
  %4 = icmp ult i64 %copy.index, 192
  br i1 %4, label %copy.chunk, label %copy.next

copy.chunk:                                       ; preds = %copy.loop
  %5 = mul i64 %copy.index, 4
  %6 = add i64 0, %5
  %7 = getelementptr i32, ptr %3, i64 %6
  %8 = load <4 x i32>, ptr %7, align 4
  %9 = getelementptr i32, ptr %2, i64 %6
  store <4 x i32> %8, ptr %9, align 4
  %10 = add i64 %copy.index, 1
  br label %copy.loop

copy.next:                                        ; preds = %copy.loop
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #2

; Function Attrs: nounwind willreturn
define private void @llm_attention.strided_mma(ptr %0, ptr %1, ptr %2, ptr %3) #3 {
entry:
  br label %mma.fold

mma.fold:                                         ; preds = %mma.fold.done3, %entry
  %mma.k = phi i64 [ 0, %entry ], [ %45, %mma.fold.done3 ]
  %mma.acc = phi i64 [ 0, %entry ], [ %mma.acc, %mma.fold.done3 ]
  %4 = icmp ult i64 %mma.k, 128
  br i1 %4, label %mma.update, label %mma.fold.done

mma.update:                                       ; preds = %mma.fold
  %5 = urem i64 %mma.k, 16
  %6 = udiv i64 %mma.k, 16
  %7 = urem i64 %6, 8
  %8 = mul i64 %7, 32
  %9 = add i64 0, %8
  %10 = udiv i64 %6, 8
  %11 = urem i64 %mma.k, 16
  %12 = mul i64 %11, 32
  %13 = add i64 0, %12
  %14 = udiv i64 %mma.k, 16
  %15 = urem i64 %14, 8
  %16 = udiv i64 %14, 8
  %17 = getelementptr float, ptr %2, i64 %mma.k
  %18 = load float, ptr %17, align 4
  %19 = getelementptr float, ptr %0, i64 %9
  %20 = load <4 x float>, ptr %19, align 4
  %21 = getelementptr float, ptr %1, i64 %13
  %22 = load <4 x float>, ptr %21, align 4
  %23 = fmul <4 x float> %20, %22
  br label %mma.fold1

mma.fold.done:                                    ; preds = %mma.fold
  ret void

mma.fold1:                                        ; preds = %mma.update2, %mma.update
  %mma.k4 = phi i64 [ 0, %mma.update ], [ %35, %mma.update2 ]
  %mma.acc5 = phi <4 x float> [ %23, %mma.update ], [ %34, %mma.update2 ]
  %24 = icmp ult i64 %mma.k4, 7
  br i1 %24, label %mma.update2, label %mma.fold.done3

mma.update2:                                      ; preds = %mma.fold1
  %25 = add i64 %mma.k4, 1
  %26 = mul i64 %25, 4
  %27 = add i64 %9, %26
  %28 = getelementptr float, ptr %0, i64 %27
  %29 = load <4 x float>, ptr %28, align 4
  %30 = add i64 %13, %26
  %31 = getelementptr float, ptr %1, i64 %30
  %32 = load <4 x float>, ptr %31, align 4
  %33 = fmul <4 x float> %29, %32
  %34 = fadd <4 x float> %mma.acc5, %33
  %35 = add i64 %mma.k4, 1
  br label %mma.fold1

mma.fold.done3:                                   ; preds = %mma.fold1
  %36 = extractelement <4 x float> %mma.acc5, i64 0
  %37 = extractelement <4 x float> %mma.acc5, i64 1
  %38 = extractelement <4 x float> %mma.acc5, i64 2
  %39 = extractelement <4 x float> %mma.acc5, i64 3
  %40 = fadd float %36, %37
  %41 = fadd float %38, %39
  %42 = fadd float %40, %41
  %43 = fadd float %18, %42
  %44 = getelementptr float, ptr %3, i64 %mma.k
  store float %43, ptr %44, align 4
  %45 = add i64 %mma.k, 1
  br label %mma.fold
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8i8.v8p0(<8 x i8>, <8 x ptr>, <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr>, <8 x i1>, <8 x i8>) #4

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #4

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #5

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #6 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nounwind willreturn
define private void @llm_attention.strided_mma.3(ptr %0, ptr %1, ptr %2, ptr %3) #3 {
entry:
  br label %mma.fold

mma.fold:                                         ; preds = %mma.fold.done3, %entry
  %mma.k = phi i64 [ 0, %entry ], [ %23, %mma.fold.done3 ]
  %mma.acc = phi i64 [ 0, %entry ], [ %mma.acc, %mma.fold.done3 ]
  %4 = icmp ult i64 %mma.k, 8
  br i1 %4, label %mma.update, label %mma.fold.done

mma.update:                                       ; preds = %mma.fold
  %5 = mul i64 %mma.k, 48
  br label %mma.fold1

mma.fold.done:                                    ; preds = %mma.fold
  ret void

mma.fold1:                                        ; preds = %mma.fold.done8, %mma.update
  %mma.k4 = phi i64 [ 0, %mma.update ], [ %37, %mma.fold.done8 ]
  %mma.acc5 = phi i64 [ 0, %mma.update ], [ %mma.acc5, %mma.fold.done8 ]
  %6 = icmp ult i64 %mma.k4, 12
  br i1 %6, label %mma.update2, label %mma.fold.done3

mma.update2:                                      ; preds = %mma.fold1
  %7 = mul i64 %mma.k4, 4
  %8 = add i64 %5, %7
  %9 = urem i64 %8, 48
  %10 = udiv i64 %8, 48
  %11 = urem i64 %10, 8
  %12 = mul i64 %11, 16
  %13 = add i64 0, %12
  %14 = udiv i64 %10, 8
  %15 = urem i64 %8, 48
  %16 = mul i64 %15, 1
  %17 = add i64 0, %16
  %18 = udiv i64 %8, 48
  %19 = urem i64 %18, 8
  %20 = udiv i64 %18, 8
  %21 = getelementptr float, ptr %2, i64 %8
  %22 = load <4 x float>, ptr %21, align 4
  br label %mma.fold6

mma.fold.done3:                                   ; preds = %mma.fold1
  %23 = add i64 %mma.k, 1
  br label %mma.fold

mma.fold6:                                        ; preds = %mma.update7, %mma.update2
  %mma.k9 = phi i64 [ 0, %mma.update2 ], [ %35, %mma.update7 ]
  %mma.acc10 = phi <4 x float> [ %22, %mma.update2 ], [ %34, %mma.update7 ]
  %24 = icmp ult i64 %mma.k9, 16
  br i1 %24, label %mma.update7, label %mma.fold.done8

mma.update7:                                      ; preds = %mma.fold6
  %25 = mul i64 %mma.k9, 1
  %26 = add i64 %13, %25
  %27 = getelementptr float, ptr %0, i64 %26
  %28 = load float, ptr %27, align 4
  %.splatinsert = insertelement <4 x float> poison, float %28, i64 0
  %.splat = shufflevector <4 x float> %.splatinsert, <4 x float> poison, <4 x i32> zeroinitializer
  %29 = mul i64 %mma.k9, 48
  %30 = add i64 %17, %29
  %31 = getelementptr float, ptr %1, i64 %30
  %32 = load <4 x float>, ptr %31, align 4
  %33 = fmul <4 x float> %.splat, %32
  %34 = fadd <4 x float> %mma.acc10, %33
  %35 = add i64 %mma.k9, 1
  br label %mma.fold6

mma.fold.done8:                                   ; preds = %mma.fold6
  %36 = getelementptr float, ptr %3, i64 %8
  store <4 x float> %mma.acc10, ptr %36, align 4
  %37 = add i64 %mma.k4, 1
  br label %mma.fold1
}

define internal void @llm_attention.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_attention.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_attention.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nounwind willreturn }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #3 = { nounwind willreturn "fp-contract"="off" }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #5 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #6 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }

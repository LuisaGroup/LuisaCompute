	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.quad	6144                            ; 0x1800
	.quad	7168                            ; 0x1c00
lCPI0_3:
	.quad	2048                            ; 0x800
	.quad	3072                            ; 0xc00
lCPI0_4:
	.quad	4096                            ; 0x1000
	.quad	5120                            ; 0x1400
lCPI0_5:
	.quad	0                               ; 0x0
	.quad	1024                            ; 0x400
lCPI0_6:
	.quad	96                              ; 0x60
	.quad	112                             ; 0x70
lCPI0_7:
	.quad	64                              ; 0x40
	.quad	80                              ; 0x50
lCPI0_8:
	.quad	32                              ; 0x20
	.quad	48                              ; 0x30
lCPI0_9:
	.quad	0                               ; 0x0
	.quad	16                              ; 0x10
lCPI0_10:
	.quad	97                              ; 0x61
	.quad	113                             ; 0x71
lCPI0_11:
	.quad	65                              ; 0x41
	.quad	81                              ; 0x51
lCPI0_12:
	.quad	33                              ; 0x21
	.quad	49                              ; 0x31
lCPI0_13:
	.quad	1                               ; 0x1
	.quad	17                              ; 0x11
lCPI0_14:
	.quad	98                              ; 0x62
	.quad	114                             ; 0x72
lCPI0_15:
	.quad	66                              ; 0x42
	.quad	82                              ; 0x52
lCPI0_16:
	.quad	34                              ; 0x22
	.quad	50                              ; 0x32
lCPI0_17:
	.quad	2                               ; 0x2
	.quad	18                              ; 0x12
lCPI0_18:
	.quad	99                              ; 0x63
	.quad	115                             ; 0x73
lCPI0_19:
	.quad	67                              ; 0x43
	.quad	83                              ; 0x53
lCPI0_20:
	.quad	35                              ; 0x23
	.quad	51                              ; 0x33
lCPI0_21:
	.quad	3                               ; 0x3
	.quad	19                              ; 0x13
lCPI0_22:
	.quad	100                             ; 0x64
	.quad	116                             ; 0x74
lCPI0_23:
	.quad	68                              ; 0x44
	.quad	84                              ; 0x54
lCPI0_24:
	.quad	36                              ; 0x24
	.quad	52                              ; 0x34
lCPI0_25:
	.quad	4                               ; 0x4
	.quad	20                              ; 0x14
lCPI0_26:
	.quad	101                             ; 0x65
	.quad	117                             ; 0x75
lCPI0_27:
	.quad	69                              ; 0x45
	.quad	85                              ; 0x55
lCPI0_28:
	.quad	37                              ; 0x25
	.quad	53                              ; 0x35
lCPI0_29:
	.quad	5                               ; 0x5
	.quad	21                              ; 0x15
lCPI0_30:
	.quad	102                             ; 0x66
	.quad	118                             ; 0x76
lCPI0_31:
	.quad	70                              ; 0x46
	.quad	86                              ; 0x56
lCPI0_32:
	.quad	38                              ; 0x26
	.quad	54                              ; 0x36
lCPI0_33:
	.quad	6                               ; 0x6
	.quad	22                              ; 0x16
lCPI0_34:
	.quad	103                             ; 0x67
	.quad	119                             ; 0x77
lCPI0_35:
	.quad	71                              ; 0x47
	.quad	87                              ; 0x57
lCPI0_36:
	.quad	39                              ; 0x27
	.quad	55                              ; 0x37
lCPI0_37:
	.quad	7                               ; 0x7
	.quad	23                              ; 0x17
lCPI0_38:
	.quad	104                             ; 0x68
	.quad	120                             ; 0x78
lCPI0_39:
	.quad	72                              ; 0x48
	.quad	88                              ; 0x58
lCPI0_40:
	.quad	40                              ; 0x28
	.quad	56                              ; 0x38
lCPI0_41:
	.quad	8                               ; 0x8
	.quad	24                              ; 0x18
lCPI0_42:
	.quad	105                             ; 0x69
	.quad	121                             ; 0x79
lCPI0_43:
	.quad	73                              ; 0x49
	.quad	89                              ; 0x59
lCPI0_44:
	.quad	41                              ; 0x29
	.quad	57                              ; 0x39
lCPI0_45:
	.quad	9                               ; 0x9
	.quad	25                              ; 0x19
lCPI0_46:
	.quad	106                             ; 0x6a
	.quad	122                             ; 0x7a
lCPI0_47:
	.quad	74                              ; 0x4a
	.quad	90                              ; 0x5a
lCPI0_48:
	.quad	42                              ; 0x2a
	.quad	58                              ; 0x3a
lCPI0_49:
	.quad	10                              ; 0xa
	.quad	26                              ; 0x1a
lCPI0_50:
	.quad	107                             ; 0x6b
	.quad	123                             ; 0x7b
lCPI0_51:
	.quad	75                              ; 0x4b
	.quad	91                              ; 0x5b
lCPI0_52:
	.quad	43                              ; 0x2b
	.quad	59                              ; 0x3b
lCPI0_53:
	.quad	11                              ; 0xb
	.quad	27                              ; 0x1b
lCPI0_54:
	.quad	108                             ; 0x6c
	.quad	124                             ; 0x7c
lCPI0_55:
	.quad	76                              ; 0x4c
	.quad	92                              ; 0x5c
lCPI0_56:
	.quad	44                              ; 0x2c
	.quad	60                              ; 0x3c
lCPI0_57:
	.quad	12                              ; 0xc
	.quad	28                              ; 0x1c
lCPI0_58:
	.quad	109                             ; 0x6d
	.quad	125                             ; 0x7d
lCPI0_59:
	.quad	77                              ; 0x4d
	.quad	93                              ; 0x5d
lCPI0_60:
	.quad	45                              ; 0x2d
	.quad	61                              ; 0x3d
lCPI0_61:
	.quad	13                              ; 0xd
	.quad	29                              ; 0x1d
lCPI0_62:
	.quad	110                             ; 0x6e
	.quad	126                             ; 0x7e
lCPI0_63:
	.quad	78                              ; 0x4e
	.quad	94                              ; 0x5e
lCPI0_64:
	.quad	46                              ; 0x2e
	.quad	62                              ; 0x3e
lCPI0_65:
	.quad	14                              ; 0xe
	.quad	30                              ; 0x1e
lCPI0_66:
	.quad	111                             ; 0x6f
	.quad	127                             ; 0x7f
lCPI0_67:
	.quad	79                              ; 0x4f
	.quad	95                              ; 0x5f
lCPI0_68:
	.quad	47                              ; 0x2f
	.quad	63                              ; 0x3f
lCPI0_69:
	.quad	15                              ; 0xf
	.quad	31                              ; 0x1f
lCPI0_70:
	.quad	12288                           ; 0x3000
	.quad	14336                           ; 0x3800
lCPI0_71:
	.quad	4096                            ; 0x1000
	.quad	6144                            ; 0x1800
lCPI0_72:
	.quad	8192                            ; 0x2000
	.quad	10240                           ; 0x2800
lCPI0_73:
	.quad	0                               ; 0x0
	.quad	2048                            ; 0x800
lCPI0_74:
	.quad	18432                           ; 0x4800
	.quad	21504                           ; 0x5400
lCPI0_75:
	.quad	6144                            ; 0x1800
	.quad	9216                            ; 0x2400
lCPI0_76:
	.quad	12288                           ; 0x3000
	.quad	15360                           ; 0x3c00
lCPI0_77:
	.quad	0                               ; 0x0
	.quad	3072                            ; 0xc00
lCPI0_78:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_79:
	.quad	3072                            ; 0xc00
	.quad	3584                            ; 0xe00
lCPI0_80:
	.quad	1024                            ; 0x400
	.quad	1536                            ; 0x600
lCPI0_81:
	.quad	2048                            ; 0x800
	.quad	2560                            ; 0xa00
lCPI0_82:
	.quad	0                               ; 0x0
	.quad	512                             ; 0x200
lCPI0_83:
	.quad	768                             ; 0x300
	.quad	896                             ; 0x380
lCPI0_84:
	.quad	256                             ; 0x100
	.quad	384                             ; 0x180
lCPI0_85:
	.quad	512                             ; 0x200
	.quad	640                             ; 0x280
lCPI0_86:
	.quad	0                               ; 0x0
	.quad	128                             ; 0x80
lCPI0_87:
	.quad	9216                            ; 0x2400
	.quad	10752                           ; 0x2a00
lCPI0_88:
	.quad	3072                            ; 0xc00
	.quad	4608                            ; 0x1200
lCPI0_89:
	.quad	6144                            ; 0x1800
	.quad	7680                            ; 0x1e00
lCPI0_90:
	.quad	0                               ; 0x0
	.quad	1536                            ; 0x600
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention:                         ; @llm_attention
; %bb.0:                                ; %prologue
	dup.4s	v22, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q23, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q24, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v0, v22, v24
	cmhi.4s	v1, v22, v23
	uzp1.8h	v3, v1, v0
	umaxv.8h	h2, v3
	fmov	w8, s2
	tbz	w8, #0, LBB0_776
; %bb.1:                                ; %direct.activate
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #1760
	str	q3, [sp, #2704]                 ; 16-byte Spill
	ldr	x28, [x1, #136]
	ldr	x9, [x0]
	xtn.4h	v2, v1
	uzp1.8b	v18, v2, v0
	sshll.2d	v16, v1, #0
	sshll.2d	v4, v0, #0
	sshll2.2d	v8, v1, #0
	ldr	w8, [x1]
	ldr	w10, [x1, #36]
	add	w8, w10, w8, lsl #5
	dup.4s	v2, w8
	add.4s	v3, v2, v24
	add.4s	v2, v2, v23
	and.16b	v7, v1, v2
	and.16b	v2, v0, v3
	ushll2.2d	v3, v7, #0
	ushll.2d	v17, v7, #0
	mov	w8, #3                          ; =0x3
	dup.2d	v5, x8
	and.16b	v19, v8, v5
	and.16b	v6, v4, v5
	and.16b	v20, v16, v5
	neg.2d	v20, v20
	ushl.2d	v28, v17, v20
	neg.2d	v17, v19
	ushl.2d	v21, v3, v17
	ushll2.2d	v19, v7, #3
	ushll.2d	v17, v2, #3
	ushll.2d	v7, v7, #3
	mov	w8, #56                         ; =0x38
	dup.2d	v3, x8
	and.16b	v30, v7, v3
	and.16b	v29, v19, v3
	shl.2d	v7, v28, #11
	shl.2d	v20, v29, #5
	shl.2d	v19, v30, #5
	and.16b	v19, v16, v19
	orr.16b	v7, v19, v7
	umov.b	w4, v18[0]
	tbz	w4, #0, LBB0_4
; %bb.2:                                ; %copy.active
	mov	x8, #0                          ; =0x0
	fmov	x10, d7
	add	x10, x9, x10, lsl #2
LBB0_3:                                 ; %copy.chunk.i
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q18, [x10, x8]
	str	q18, [x28, x8]
	add	x8, x8, #16
	cmp	x8, #1024
	b.ne	LBB0_3
LBB0_4:                                 ; %copy.continue
	sshll2.2d	v10, v0, #0
	ushll.2d	v18, v2, #0
	neg.2d	v19, v6
	and.16b	v31, v17, v3
	shl.2d	v17, v21, #11
	and.16b	v20, v8, v20
	mov.s	w11, v22[1]
	cmp	w11, #1
	cset	w8, hi
	str	w8, [sp, #2752]                 ; 4-byte Spill
	cmp	w11, #2
	b.lo	LBB0_7
; %bb.5:                                ; %copy.active197
	mov	x8, #0                          ; =0x0
	add	x10, x28, #1024
	mov.d	x12, v7[1]
	add	x12, x9, x12, lsl #2
LBB0_6:                                 ; %copy.chunk.i497
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q6, [x12, x8]
	str	q6, [x10, x8]
	add	x8, x8, #16
	cmp	x8, #1024
	b.ne	LBB0_6
LBB0_7:                                 ; %copy.continue198
	and.16b	v6, v10, v5
	ushll2.2d	v7, v2, #3
	ushl.2d	v19, v18, v19
	shl.2d	v18, v31, #5
	orr.16b	v5, v20, v17
	mov.s	w8, v22[2]
	cmp	w8, #2
	cset	w5, hi
	cmp	w8, #3
	b.lo	LBB0_10
; %bb.8:                                ; %copy.active199
	mov	x10, #0                         ; =0x0
	add	x12, x28, #2048
	fmov	x13, d5
	add	x13, x9, x13, lsl #2
LBB0_9:                                 ; %copy.chunk.i501
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q17, [x13, x10]
	str	q17, [x12, x10]
	add	x10, x10, #16
	cmp	x10, #1024
	b.ne	LBB0_9
LBB0_10:                                ; %copy.continue200
	ushll2.2d	v2, v2, #0
	neg.2d	v6, v6
	and.16b	v9, v7, v3
	shl.2d	v3, v19, #11
	and.16b	v7, v4, v18
	mov.s	w10, v22[3]
	cmp	w10, #3
	cset	w12, hi
	str	w12, [sp, #4268]                ; 4-byte Spill
	cmp	w10, #4
	b.lo	LBB0_13
; %bb.11:                               ; %copy.active201
	mov	x12, #0                         ; =0x0
	add	x13, x28, #3072
	mov.d	x14, v5[1]
	add	x14, x9, x14, lsl #2
LBB0_12:                                ; %copy.chunk.i505
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q5, [x14, x12]
	str	q5, [x13, x12]
	add	x12, x12, #16
	cmp	x12, #1024
	b.ne	LBB0_12
LBB0_13:                                ; %copy.continue202
	ushl.2d	v17, v2, v6
	shl.2d	v5, v9, #5
	orr.16b	v2, v7, v3
	fmov	w12, s22
	cmp	w12, #4
	cset	w13, hi
	str	w13, [sp, #4264]                ; 4-byte Spill
	cmp	w12, #5
	b.lo	LBB0_16
; %bb.14:                               ; %copy.active203
	mov	x12, #0                         ; =0x0
	add	x13, x28, #1, lsl #12           ; =4096
	fmov	x14, d2
	add	x14, x9, x14, lsl #2
LBB0_15:                                ; %copy.chunk.i509
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q3, [x14, x12]
	str	q3, [x13, x12]
	add	x12, x12, #16
	cmp	x12, #1024
	b.ne	LBB0_15
LBB0_16:                                ; %copy.continue204
	shl.2d	v3, v17, #11
	and.16b	v5, v10, v5
	cmp	w11, #5
	cset	w12, hi
	str	w12, [sp, #4260]                ; 4-byte Spill
	cmp	w11, #6
	b.lo	LBB0_19
; %bb.17:                               ; %copy.active205
	mov	x11, #0                         ; =0x0
	mov	w12, #5120                      ; =0x1400
	add	x12, x28, x12
	mov.d	x13, v2[1]
	add	x13, x9, x13, lsl #2
LBB0_18:                                ; %copy.chunk.i513
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q2, [x13, x11]
	str	q2, [x12, x11]
	add	x11, x11, #16
	cmp	x11, #1024
	b.ne	LBB0_18
LBB0_19:                                ; %copy.continue206
	adrp	x11, lCPI0_2@PAGE
	adrp	x3, lCPI0_3@PAGE
	adrp	x1, lCPI0_4@PAGE
	adrp	x2, lCPI0_5@PAGE
	orr.16b	v2, v5, v3
	cmp	w8, #6
	cset	w12, hi
	str	w12, [sp, #4256]                ; 4-byte Spill
	cmp	w8, #7
	b.lo	LBB0_22
; %bb.20:                               ; %copy.active207
	mov	x8, #0                          ; =0x0
	mov	w12, #6144                      ; =0x1800
	add	x12, x28, x12
	fmov	x13, d2
	add	x13, x9, x13, lsl #2
LBB0_21:                                ; %copy.chunk.i517
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q3, [x13, x8]
	str	q3, [x12, x8]
	add	x8, x8, #16
	cmp	x8, #1024
	b.ne	LBB0_21
LBB0_22:                                ; %copy.continue208
	add	x8, x28, #19, lsl #12           ; =77824
	add	x15, x28, #8, lsl #12           ; =32768
	add	x16, x28, #12, lsl #12          ; =49152
	add	x17, x28, #18, lsl #12          ; =73728
	add	x14, x28, #20, lsl #12          ; =81920
	add	x12, x28, #20, lsl #12          ; =81920
	add	x12, x12, #1664
	add	x13, x28, #21, lsl #12          ; =86016
	dup.2d	v3, x28
	add	x13, x13, #3200
	ldr	q6, [x11, lCPI0_2@PAGEOFF]
	add	x11, x28, #22, lsl #12          ; =90112
	add	x11, x11, #3200
	ldr	q25, [x3, lCPI0_3@PAGEOFF]
	add	x3, x28, #25, lsl #12           ; =102400
	add	x3, x3, #3200
	str	x3, [sp, #280]                  ; 8-byte Spill
	ldr	q26, [x1, lCPI0_4@PAGEOFF]
	ldr	q27, [x2, lCPI0_5@PAGEOFF]
	cmp	w10, #7
	cset	w1, hi
	str	w1, [sp, #4252]                 ; 4-byte Spill
	cmp	w10, #8
	b.lo	LBB0_25
; %bb.23:                               ; %copy.active209
	mov	x10, #0                         ; =0x0
	mov	w1, #7168                       ; =0x1c00
	add	x1, x28, x1
	mov.d	x2, v2[1]
	add	x9, x9, x2, lsl #2
LBB0_24:                                ; %copy.chunk.i521
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q2, [x9, x10]
	str	q2, [x1, x10]
	add	x10, x10, #16
	cmp	x10, #1024
	b.ne	LBB0_24
LBB0_25:                                ; %direct.true.preheader
	str	w5, [sp, #2748]                 ; 4-byte Spill
	str	w4, [sp, #2756]                 ; 4-byte Spill
	mov	x9, #0                          ; =0x0
	dup.2d	v2, x15
	str	q2, [sp, #2688]                 ; 16-byte Spill
	dup.2d	v2, x16
	str	q2, [sp, #2672]                 ; 16-byte Spill
	dup.2d	v2, x17
	str	q2, [sp, #2656]                 ; 16-byte Spill
	add	x10, x28, #2, lsl #12           ; =8192
	add	x15, x28, #20, lsl #12          ; =81920
	dup.2d	v2, x8
	str	q2, [sp, #2640]                 ; 16-byte Spill
	dup.2d	v2, x14
	str	q2, [sp, #2720]                 ; 16-byte Spill
	add	x14, x15, #128
	str	x14, [sp, #2632]                ; 8-byte Spill
	add	x14, x28, #20, lsl #12          ; =81920
	dup.2d	v2, x12
	str	q2, [sp, #2608]                 ; 16-byte Spill
	dup.2d	v2, x13
	str	q2, [sp, #2592]                 ; 16-byte Spill
	str	q17, [sp, #32]                  ; 16-byte Spill
	ushr.2d	v20, v17, #1
	str	q21, [sp, #128]                 ; 16-byte Spill
	ushr.2d	v18, v21, #1
	dup.2d	v2, x11
	str	q2, [sp, #2576]                 ; 16-byte Spill
	ldr	x11, [sp, #280]                 ; 8-byte Reload
	dup.2d	v2, x11
	str	q2, [sp, #2560]                 ; 16-byte Spill
	add	x5, x14, #1152
	add	x11, x28, #20, lsl #12          ; =81920
	add	x6, x11, #2688
	add	x11, x28, #21, lsl #12          ; =86016
	add	x7, x11, #2688
	add	x11, x28, #21, lsl #12          ; =86016
	add	x19, x11, #2944
	add	x11, x28, #28, lsl #12          ; =114688
	add	x11, x11, #3200
	str	x11, [sp, #24]                  ; 8-byte Spill
	ldr	x11, [x0, #16]
	str	x11, [sp, #2552]                ; 8-byte Spill
	ldr	x11, [x0, #32]
	str	x11, [sp, #2544]                ; 8-byte Spill
	str	q19, [sp, #64]                  ; 16-byte Spill
	ushr.2d	v21, v19, #1
	str	q28, [sp, #144]                 ; 16-byte Spill
	ushr.2d	v19, v28, #1
	and.16b	v2, v10, v3
	ldr	x11, [x0, #48]
	str	x11, [sp, #16]                  ; 8-byte Spill
	and.16b	v7, v8, v3
	and.16b	v5, v4, v3
	and.16b	v17, v16, v3
	and.16b	v3, v10, v6
	and.16b	v6, v8, v25
	and.16b	v4, v4, v26
	and.16b	v16, v16, v27
	cmhs.4s	v26, v24, v22
	cmhs.4s	v27, v23, v22
LBB0_26:                                ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	add	x11, x10, x9
	ldp	q22, q23, [x11]
	and.16b	v23, v26, v23
	and.16b	v22, v27, v22
	stp	q22, q23, [x11]
	add	x9, x9, #32
	cmp	x9, #3, lsl #12                 ; =12288
	b.ne	LBB0_26
; %bb.27:                               ; %direct.false
	sshll.2d	v22, v0, #0
	str	xzr, [sp, #3352]                ; 8-byte Spill
	sshll.2d	v23, v1, #0
Lloh4:
	adrp	x9, lCPI0_10@PAGE
Lloh5:
	ldr	q24, [x9, lCPI0_10@PAGEOFF]
	ldr	q25, [sp, #2720]                ; 16-byte Reload
	add.2d	v24, v25, v24
	str	q24, [sp, #2496]                ; 16-byte Spill
Lloh6:
	adrp	x9, lCPI0_11@PAGE
Lloh7:
	ldr	q24, [x9, lCPI0_11@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2480]                ; 16-byte Spill
Lloh8:
	adrp	x9, lCPI0_12@PAGE
Lloh9:
	ldr	q24, [x9, lCPI0_12@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2464]                ; 16-byte Spill
Lloh10:
	adrp	x9, lCPI0_13@PAGE
Lloh11:
	ldr	q24, [x9, lCPI0_13@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2448]                ; 16-byte Spill
Lloh12:
	adrp	x9, lCPI0_14@PAGE
Lloh13:
	ldr	q24, [x9, lCPI0_14@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2432]                ; 16-byte Spill
Lloh14:
	adrp	x9, lCPI0_15@PAGE
Lloh15:
	ldr	q24, [x9, lCPI0_15@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2416]                ; 16-byte Spill
Lloh16:
	adrp	x9, lCPI0_16@PAGE
Lloh17:
	ldr	q24, [x9, lCPI0_16@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2400]                ; 16-byte Spill
Lloh18:
	adrp	x9, lCPI0_17@PAGE
Lloh19:
	ldr	q24, [x9, lCPI0_17@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2384]                ; 16-byte Spill
Lloh20:
	adrp	x9, lCPI0_18@PAGE
Lloh21:
	ldr	q24, [x9, lCPI0_18@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2368]                ; 16-byte Spill
Lloh22:
	adrp	x9, lCPI0_19@PAGE
Lloh23:
	ldr	q24, [x9, lCPI0_19@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2352]                ; 16-byte Spill
Lloh24:
	adrp	x9, lCPI0_20@PAGE
Lloh25:
	ldr	q24, [x9, lCPI0_20@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2336]                ; 16-byte Spill
Lloh26:
	adrp	x9, lCPI0_21@PAGE
Lloh27:
	ldr	q24, [x9, lCPI0_21@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2320]                ; 16-byte Spill
Lloh28:
	adrp	x9, lCPI0_22@PAGE
Lloh29:
	ldr	q24, [x9, lCPI0_22@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2304]                ; 16-byte Spill
Lloh30:
	adrp	x9, lCPI0_23@PAGE
Lloh31:
	ldr	q24, [x9, lCPI0_23@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2288]                ; 16-byte Spill
Lloh32:
	adrp	x9, lCPI0_24@PAGE
Lloh33:
	ldr	q24, [x9, lCPI0_24@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2272]                ; 16-byte Spill
Lloh34:
	adrp	x9, lCPI0_25@PAGE
Lloh35:
	ldr	q24, [x9, lCPI0_25@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2256]                ; 16-byte Spill
Lloh36:
	adrp	x9, lCPI0_26@PAGE
Lloh37:
	ldr	q24, [x9, lCPI0_26@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2240]                ; 16-byte Spill
Lloh38:
	adrp	x9, lCPI0_27@PAGE
Lloh39:
	ldr	q24, [x9, lCPI0_27@PAGEOFF]
	add.2d	v24, v25, v24
	str	q24, [sp, #2224]                ; 16-byte Spill
	fmov	x9, d20
	mov.d	x11, v20[1]
Lloh40:
	adrp	x12, lCPI0_28@PAGE
Lloh41:
	ldr	q20, [x12, lCPI0_28@PAGEOFF]
	add.2d	v20, v25, v20
	str	q20, [sp, #2208]                ; 16-byte Spill
	fmov	x14, d21
	mov.d	x15, v21[1]
Lloh42:
	adrp	x12, lCPI0_29@PAGE
Lloh43:
	ldr	q20, [x12, lCPI0_29@PAGEOFF]
	add.2d	v20, v25, v20
	str	q20, [sp, #2192]                ; 16-byte Spill
	fmov	x12, d18
	mov.d	x13, v18[1]
Lloh44:
	adrp	x16, lCPI0_30@PAGE
Lloh45:
	ldr	q18, [x16, lCPI0_30@PAGEOFF]
	add.2d	v18, v25, v18
	str	q18, [sp, #2176]                ; 16-byte Spill
	add	x14, x14, x14, lsl #7
	fmov	x16, d19
	add	x16, x16, x16, lsl #7
	mov.d	x17, v19[1]
	fmov	d18, x16
	add	x16, x17, x17, lsl #7
	mov.d	v18[1], x16
	and.16b	v18, v23, v18
	str	q18, [sp, #4912]                ; 16-byte Spill
	fmov	d18, x14
	add	x14, x15, x15, lsl #7
	mov.d	v18[1], x14
	and.16b	v18, v22, v18
	str	q18, [sp, #2160]                ; 16-byte Spill
Lloh46:
	adrp	x14, lCPI0_31@PAGE
Lloh47:
	ldr	q18, [x14, lCPI0_31@PAGEOFF]
	add.2d	v18, v25, v18
	str	q18, [sp, #2144]                ; 16-byte Spill
	fmov	x14, d17
	mov.d	x15, v17[1]
Lloh48:
	adrp	x16, lCPI0_32@PAGE
Lloh49:
	ldr	q17, [x16, lCPI0_32@PAGEOFF]
	add.2d	v17, v25, v17
	str	q17, [sp, #2128]                ; 16-byte Spill
	fmov	x16, d16
	mov.d	x17, v16[1]
Lloh50:
	adrp	x0, lCPI0_33@PAGE
Lloh51:
	ldr	q16, [x0, lCPI0_33@PAGEOFF]
	add.2d	v16, v25, v16
	str	q16, [sp, #2112]                ; 16-byte Spill
	fmov	x1, d7
	mov.d	x0, v7[1]
Lloh52:
	adrp	x2, lCPI0_34@PAGE
Lloh53:
	ldr	q7, [x2, lCPI0_34@PAGEOFF]
	add.2d	v7, v25, v7
	str	q7, [sp, #2096]                 ; 16-byte Spill
	fmov	x3, d6
	mov.d	x2, v6[1]
Lloh54:
	adrp	x4, lCPI0_35@PAGE
Lloh55:
	ldr	q6, [x4, lCPI0_35@PAGEOFF]
	add.2d	v6, v25, v6
	str	q6, [sp, #2080]                 ; 16-byte Spill
	fmov	x20, d5
	mov.d	x4, v5[1]
Lloh56:
	adrp	x21, lCPI0_36@PAGE
Lloh57:
	ldr	q5, [x21, lCPI0_36@PAGEOFF]
	add.2d	v5, v25, v5
	str	q5, [sp, #2064]                 ; 16-byte Spill
	fmov	x22, d4
	mov.d	x21, v4[1]
Lloh58:
	adrp	x23, lCPI0_37@PAGE
Lloh59:
	ldr	q4, [x23, lCPI0_37@PAGEOFF]
	add.2d	v4, v25, v4
	str	q4, [sp, #2048]                 ; 16-byte Spill
	fmov	x24, d2
	mov.d	x23, v2[1]
Lloh60:
	adrp	x25, lCPI0_38@PAGE
Lloh61:
	ldr	q2, [x25, lCPI0_38@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #2032]                 ; 16-byte Spill
	fmov	x26, d3
	mov.d	x25, v3[1]
Lloh62:
	adrp	x27, lCPI0_39@PAGE
Lloh63:
	ldr	q2, [x27, lCPI0_39@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #2016]                 ; 16-byte Spill
Lloh64:
	adrp	x27, lCPI0_40@PAGE
Lloh65:
	ldr	q2, [x27, lCPI0_40@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #2000]                 ; 16-byte Spill
Lloh66:
	adrp	x27, lCPI0_41@PAGE
Lloh67:
	ldr	q2, [x27, lCPI0_41@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1984]                 ; 16-byte Spill
Lloh68:
	adrp	x27, lCPI0_42@PAGE
Lloh69:
	ldr	q2, [x27, lCPI0_42@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1968]                 ; 16-byte Spill
Lloh70:
	adrp	x27, lCPI0_43@PAGE
Lloh71:
	ldr	q2, [x27, lCPI0_43@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1952]                 ; 16-byte Spill
Lloh72:
	adrp	x27, lCPI0_44@PAGE
Lloh73:
	ldr	q2, [x27, lCPI0_44@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1936]                 ; 16-byte Spill
Lloh74:
	adrp	x27, lCPI0_45@PAGE
Lloh75:
	ldr	q2, [x27, lCPI0_45@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1920]                 ; 16-byte Spill
Lloh76:
	adrp	x27, lCPI0_46@PAGE
Lloh77:
	ldr	q2, [x27, lCPI0_46@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1904]                 ; 16-byte Spill
Lloh78:
	adrp	x27, lCPI0_47@PAGE
Lloh79:
	ldr	q2, [x27, lCPI0_47@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1888]                 ; 16-byte Spill
Lloh80:
	adrp	x27, lCPI0_48@PAGE
Lloh81:
	ldr	q2, [x27, lCPI0_48@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1872]                 ; 16-byte Spill
Lloh82:
	adrp	x27, lCPI0_49@PAGE
Lloh83:
	ldr	q2, [x27, lCPI0_49@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1856]                 ; 16-byte Spill
Lloh84:
	adrp	x27, lCPI0_50@PAGE
Lloh85:
	ldr	q2, [x27, lCPI0_50@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1840]                 ; 16-byte Spill
Lloh86:
	adrp	x27, lCPI0_51@PAGE
Lloh87:
	ldr	q2, [x27, lCPI0_51@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1824]                 ; 16-byte Spill
Lloh88:
	adrp	x27, lCPI0_52@PAGE
Lloh89:
	ldr	q2, [x27, lCPI0_52@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1808]                 ; 16-byte Spill
Lloh90:
	adrp	x27, lCPI0_53@PAGE
Lloh91:
	ldr	q2, [x27, lCPI0_53@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1792]                 ; 16-byte Spill
Lloh92:
	adrp	x27, lCPI0_54@PAGE
Lloh93:
	ldr	q2, [x27, lCPI0_54@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1776]                 ; 16-byte Spill
Lloh94:
	adrp	x27, lCPI0_55@PAGE
Lloh95:
	ldr	q2, [x27, lCPI0_55@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1760]                 ; 16-byte Spill
Lloh96:
	adrp	x27, lCPI0_56@PAGE
Lloh97:
	ldr	q2, [x27, lCPI0_56@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1744]                 ; 16-byte Spill
Lloh98:
	adrp	x27, lCPI0_57@PAGE
Lloh99:
	ldr	q2, [x27, lCPI0_57@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1728]                 ; 16-byte Spill
Lloh100:
	adrp	x27, lCPI0_58@PAGE
Lloh101:
	ldr	q2, [x27, lCPI0_58@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1712]                 ; 16-byte Spill
Lloh102:
	adrp	x27, lCPI0_59@PAGE
Lloh103:
	ldr	q2, [x27, lCPI0_59@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1696]                 ; 16-byte Spill
Lloh104:
	adrp	x27, lCPI0_60@PAGE
Lloh105:
	ldr	q2, [x27, lCPI0_60@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1680]                 ; 16-byte Spill
Lloh106:
	adrp	x27, lCPI0_61@PAGE
Lloh107:
	ldr	q2, [x27, lCPI0_61@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1664]                 ; 16-byte Spill
Lloh108:
	adrp	x27, lCPI0_62@PAGE
Lloh109:
	ldr	q2, [x27, lCPI0_62@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1648]                 ; 16-byte Spill
Lloh110:
	adrp	x27, lCPI0_63@PAGE
Lloh111:
	ldr	q2, [x27, lCPI0_63@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1632]                 ; 16-byte Spill
Lloh112:
	adrp	x27, lCPI0_64@PAGE
Lloh113:
	ldr	q2, [x27, lCPI0_64@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1616]                 ; 16-byte Spill
Lloh114:
	adrp	x27, lCPI0_65@PAGE
Lloh115:
	ldr	q2, [x27, lCPI0_65@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1600]                 ; 16-byte Spill
Lloh116:
	adrp	x27, lCPI0_66@PAGE
Lloh117:
	ldr	q2, [x27, lCPI0_66@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1584]                 ; 16-byte Spill
Lloh118:
	adrp	x27, lCPI0_67@PAGE
Lloh119:
	ldr	q2, [x27, lCPI0_67@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1568]                 ; 16-byte Spill
Lloh120:
	adrp	x27, lCPI0_68@PAGE
Lloh121:
	ldr	q2, [x27, lCPI0_68@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1552]                 ; 16-byte Spill
Lloh122:
	adrp	x27, lCPI0_69@PAGE
Lloh123:
	ldr	q2, [x27, lCPI0_69@PAGEOFF]
	add.2d	v2, v25, v2
	str	q2, [sp, #1536]                 ; 16-byte Spill
	mov	w27, #65                        ; =0x41
	dup.2d	v2, x27
	orr.16b	v3, v31, v2
	str	q3, [sp, #1520]                 ; 16-byte Spill
	orr.16b	v3, v29, v2
	str	q3, [sp, #1504]                 ; 16-byte Spill
	orr.16b	v3, v30, v2
	str	q3, [sp, #1488]                 ; 16-byte Spill
	orr.16b	v2, v9, v2
	str	q2, [sp, #1472]                 ; 16-byte Spill
	mov	w27, #66                        ; =0x42
	dup.2d	v2, x27
	orr.16b	v3, v31, v2
	str	q3, [sp, #1456]                 ; 16-byte Spill
	orr.16b	v3, v29, v2
	str	q3, [sp, #1440]                 ; 16-byte Spill
	orr.16b	v3, v30, v2
	str	q3, [sp, #1424]                 ; 16-byte Spill
	orr.16b	v2, v9, v2
	str	q2, [sp, #1408]                 ; 16-byte Spill
	mov	w27, #67                        ; =0x43
	dup.2d	v2, x27
	mov	w27, #68                        ; =0x44
	orr.16b	v3, v31, v2
	str	q3, [sp, #1392]                 ; 16-byte Spill
	orr.16b	v3, v29, v2
	str	q3, [sp, #1376]                 ; 16-byte Spill
	orr.16b	v3, v30, v2
	str	q3, [sp, #1360]                 ; 16-byte Spill
	dup.2d	v3, x27
	orr.16b	v2, v9, v2
	str	q2, [sp, #1344]                 ; 16-byte Spill
	orr.16b	v2, v31, v3
	str	q2, [sp, #1328]                 ; 16-byte Spill
	orr.16b	v2, v29, v3
	str	q2, [sp, #1312]                 ; 16-byte Spill
	orr.16b	v2, v30, v3
	str	q2, [sp, #1296]                 ; 16-byte Spill
	orr.16b	v2, v9, v3
	str	q2, [sp, #1280]                 ; 16-byte Spill
	mov	w27, #69                        ; =0x45
	dup.2d	v2, x27
	orr.16b	v3, v31, v2
	str	q3, [sp, #1264]                 ; 16-byte Spill
	orr.16b	v3, v29, v2
	str	q3, [sp, #1248]                 ; 16-byte Spill
	orr.16b	v3, v30, v2
	str	q3, [sp, #1232]                 ; 16-byte Spill
	orr.16b	v2, v9, v2
	str	q2, [sp, #1216]                 ; 16-byte Spill
	mov	w27, #70                        ; =0x46
	dup.2d	v2, x27
	orr.16b	v3, v31, v2
	str	q3, [sp, #1200]                 ; 16-byte Spill
	orr.16b	v3, v29, v2
	str	q3, [sp, #1184]                 ; 16-byte Spill
	orr.16b	v3, v30, v2
	str	q3, [sp, #1168]                 ; 16-byte Spill
	orr.16b	v2, v9, v2
	str	q2, [sp, #1152]                 ; 16-byte Spill
	mov	w27, #71                        ; =0x47
	dup.2d	v2, x27
	orr.16b	v3, v31, v2
	str	q3, [sp, #1136]                 ; 16-byte Spill
	orr.16b	v3, v29, v2
	str	q3, [sp, #1120]                 ; 16-byte Spill
	orr.16b	v3, v30, v2
	str	q3, [sp, #1104]                 ; 16-byte Spill
	orr.16b	v2, v9, v2
	str	q2, [sp, #1088]                 ; 16-byte Spill
	mov	w27, #72                        ; =0x48
	dup.2d	v2, x27
	stp	q31, q30, [sp, #80]             ; 32-byte Folded Spill
	add.2d	v3, v31, v2
	str	q3, [sp, #1072]                 ; 16-byte Spill
	str	q29, [sp, #112]                 ; 16-byte Spill
	add.2d	v3, v29, v2
	str	q3, [sp, #1056]                 ; 16-byte Spill
	add.2d	v3, v30, v2
	str	q3, [sp, #1040]                 ; 16-byte Spill
	str	q9, [sp, #48]                   ; 16-byte Spill
	add.2d	v2, v9, v2
	str	q2, [sp, #1024]                 ; 16-byte Spill
	str	q26, [sp, #2528]                ; 16-byte Spill
	str	q27, [sp, #2512]                ; 16-byte Spill
	uzp1.8h	v2, v27, v26
	xtn.8b	v2, v2
	str	d2, [sp, #1016]                 ; 8-byte Spill
	add	x9, x9, x9, lsl #7
	add	x11, x11, x11, lsl #7
	fmov	d2, x9
	mov.d	v2[1], x11
	add	x9, x12, x12, lsl #7
	add	x11, x13, x13, lsl #7
	fmov	d3, x9
	mov.d	v3[1], x11
	str	q8, [sp, #4528]                 ; 16-byte Spill
	and.16b	v3, v8, v3
	str	q10, [sp, #4512]                ; 16-byte Spill
	and.16b	v2, v10, v2
	stp	q2, q3, [sp, #976]              ; 32-byte Folded Spill
	add	x9, x14, x16
	str	x9, [sp, #968]                  ; 8-byte Spill
	add	x9, x15, x17
	str	x9, [sp, #960]                  ; 8-byte Spill
	add	x11, x8, #512
	add	x9, x1, x3
	str	x9, [sp, #952]                  ; 8-byte Spill
	add	x9, x8, #1024
	stp	x9, x11, [sp, #264]             ; 16-byte Folded Spill
	add	x9, x0, x2
	str	x9, [sp, #944]                  ; 8-byte Spill
	add	x11, x8, #1536
	add	x9, x20, x22
	str	x9, [sp, #936]                  ; 8-byte Spill
	add	x9, x8, #2048
	stp	x9, x11, [sp, #248]             ; 16-byte Folded Spill
	add	x9, x4, x21
	str	x9, [sp, #928]                  ; 8-byte Spill
	add	x11, x8, #2560
	add	x9, x24, x26
	str	x9, [sp, #920]                  ; 8-byte Spill
	add	x9, x8, #3072
	stp	x9, x11, [sp, #232]             ; 16-byte Folded Spill
	add	x9, x23, x25
	str	x9, [sp, #912]                  ; 8-byte Spill
	add	x9, x8, #3584
	add	x8, x28, #26, lsl #12           ; =106496
	add	x8, x8, #640
	stp	x8, x9, [sp, #216]              ; 16-byte Folded Spill
	add	x8, x28, #26, lsl #12           ; =106496
	add	x9, x8, #2176
	add	x8, x28, #26, lsl #12           ; =106496
	add	x8, x8, #3712
	stp	x8, x9, [sp, #200]              ; 16-byte Folded Spill
	add	x8, x28, #27, lsl #12           ; =110592
	add	x9, x8, #1152
	add	x8, x28, #27, lsl #12           ; =110592
	add	x8, x8, #2688
	stp	x8, x9, [sp, #184]              ; 16-byte Folded Spill
	add	x8, x28, #28, lsl #12           ; =114688
	add	x9, x8, #128
	add	x8, x28, #28, lsl #12           ; =114688
	add	x8, x8, #1664
	stp	x8, x9, [sp, #168]              ; 16-byte Folded Spill
	add	x8, x28, #20, lsl #12           ; =81920
	add	x2, x8, #3200
	add	x8, x28, #20, lsl #12           ; =81920
	add	x12, x8, #3712
	add	x8, x28, #21, lsl #12           ; =86016
	add	x14, x8, #128
	add	x8, x28, #21, lsl #12           ; =86016
	add	x11, x8, #640
	add	x8, x28, #21, lsl #12           ; =86016
	add	x13, x8, #1152
	add	x8, x28, #21, lsl #12           ; =86016
	add	x15, x8, #1664
	add	x8, x28, #21, lsl #12           ; =86016
	add	x9, x8, #2176
	add	x8, x28, #20, lsl #12           ; =81920
	add	x8, x8, #128
	str	x8, [sp, #904]                  ; 8-byte Spill
	add	x8, x28, #20, lsl #12           ; =81920
	add	x8, x8, #192
	str	x8, [sp, #896]                  ; 8-byte Spill
	add	x8, x28, #20, lsl #12           ; =81920
	add	x8, x8, #256
	str	x8, [sp, #888]                  ; 8-byte Spill
	add	x8, x28, #20, lsl #12           ; =81920
	add	x8, x8, #320
	str	x8, [sp, #880]                  ; 8-byte Spill
	add	x8, x28, #20, lsl #12           ; =81920
	add	x8, x8, #384
	str	x8, [sp, #872]                  ; 8-byte Spill
	add	x8, x28, #20, lsl #12           ; =81920
	add	x8, x8, #448
	str	x8, [sp, #864]                  ; 8-byte Spill
	add	x8, x28, #20, lsl #12           ; =81920
	add	x8, x8, #512
	str	x8, [sp, #856]                  ; 8-byte Spill
	add	x8, x28, #20, lsl #12           ; =81920
	add	x8, x8, #576
	str	x8, [sp, #848]                  ; 8-byte Spill
	add	x8, x28, #20, lsl #12           ; =81920
	add	x8, x8, #640
	str	x8, [sp, #840]                  ; 8-byte Spill
	add	x8, x28, #20, lsl #12           ; =81920
	add	x8, x8, #704
	str	x8, [sp, #832]                  ; 8-byte Spill
	add	x8, x28, #20, lsl #12           ; =81920
	add	x8, x8, #768
	str	x8, [sp, #824]                  ; 8-byte Spill
	mvni.4s	v2, #63, msl #16
	fneg.4s	v2, v2
	str	q2, [sp, #5392]                 ; 16-byte Spill
	add	x8, x28, #20, lsl #12           ; =81920
	add	x8, x8, #832
	str	x8, [sp, #816]                  ; 8-byte Spill
	add	x8, x28, #20, lsl #12           ; =81920
	add	x8, x8, #896
	str	x8, [sp, #808]                  ; 8-byte Spill
	add	x8, x28, #20, lsl #12           ; =81920
	add	x8, x8, #960
	str	x8, [sp, #800]                  ; 8-byte Spill
	add	x8, x28, #20, lsl #12           ; =81920
	add	x8, x8, #1024
	str	x8, [sp, #792]                  ; 8-byte Spill
	add	x8, x28, #20, lsl #12           ; =81920
	add	x8, x8, #1088
	str	x8, [sp, #784]                  ; 8-byte Spill
	add	x8, x28, #20, lsl #12           ; =81920
	add	x8, x8, #1152
	str	x8, [sp, #776]                  ; 8-byte Spill
	add	x8, x28, #20, lsl #12           ; =81920
	add	x8, x8, #1216
	str	x8, [sp, #768]                  ; 8-byte Spill
	add	x8, x28, #20, lsl #12           ; =81920
	add	x8, x8, #1280
	str	x8, [sp, #760]                  ; 8-byte Spill
	add	x8, x28, #20, lsl #12           ; =81920
	add	x8, x8, #1344
	str	x8, [sp, #752]                  ; 8-byte Spill
	add	x8, x28, #20, lsl #12           ; =81920
	add	x8, x8, #1408
	str	x8, [sp, #744]                  ; 8-byte Spill
	add	x8, x28, #20, lsl #12           ; =81920
	add	x8, x8, #1472
	str	x8, [sp, #736]                  ; 8-byte Spill
	add	x8, x28, #20, lsl #12           ; =81920
	add	x8, x8, #1536
	str	x8, [sp, #728]                  ; 8-byte Spill
	add	x8, x28, #20, lsl #12           ; =81920
	add	x8, x8, #1600
	str	x8, [sp, #720]                  ; 8-byte Spill
	add	x8, x28, #21, lsl #12           ; =86016
	add	x8, x8, #2688
	str	x8, [sp, #712]                  ; 8-byte Spill
	add	x8, x28, #21, lsl #12           ; =86016
	add	x8, x8, #2720
	str	x8, [sp, #704]                  ; 8-byte Spill
	add	x8, x28, #21, lsl #12           ; =86016
	add	x8, x8, #2752
	str	x8, [sp, #696]                  ; 8-byte Spill
	add	x8, x28, #21, lsl #12           ; =86016
	add	x8, x8, #2784
	str	x8, [sp, #688]                  ; 8-byte Spill
	add	x8, x28, #21, lsl #12           ; =86016
	add	x8, x8, #2816
	str	x8, [sp, #680]                  ; 8-byte Spill
	add	x8, x28, #21, lsl #12           ; =86016
	add	x8, x8, #2848
	str	x8, [sp, #672]                  ; 8-byte Spill
	add	x8, x28, #21, lsl #12           ; =86016
	add	x8, x8, #2880
	str	x8, [sp, #664]                  ; 8-byte Spill
	add	x8, x28, #21, lsl #12           ; =86016
	add	x8, x8, #2912
	str	x8, [sp, #656]                  ; 8-byte Spill
	add	x8, x28, #21, lsl #12           ; =86016
	add	x8, x8, #2944
	str	x8, [sp, #648]                  ; 8-byte Spill
	add	x8, x28, #21, lsl #12           ; =86016
	add	x8, x8, #2976
	str	x8, [sp, #640]                  ; 8-byte Spill
	add	x8, x28, #21, lsl #12           ; =86016
	add	x8, x8, #3008
	str	x8, [sp, #632]                  ; 8-byte Spill
	add	x8, x28, #21, lsl #12           ; =86016
	add	x8, x8, #3040
	str	x8, [sp, #624]                  ; 8-byte Spill
	add	x8, x28, #21, lsl #12           ; =86016
	add	x8, x8, #3072
	str	x8, [sp, #616]                  ; 8-byte Spill
	add	x8, x28, #21, lsl #12           ; =86016
	add	x8, x8, #3104
	str	x8, [sp, #608]                  ; 8-byte Spill
	add	x8, x28, #21, lsl #12           ; =86016
	add	x8, x8, #3136
	str	x8, [sp, #600]                  ; 8-byte Spill
	add	x8, x28, #21, lsl #12           ; =86016
	add	x8, x8, #3168
	str	x8, [sp, #592]                  ; 8-byte Spill
	mov	w21, #62154                     ; =0xf2ca
	movk	w21, #61769, lsl #16
Lloh124:
	adrp	x23, lCPI0_7@PAGE
Lloh125:
	adrp	x22, lCPI0_73@PAGE
	mov	w17, #48                        ; =0x30
Lloh126:
	adrp	x24, lCPI0_79@PAGE
Lloh127:
	adrp	x25, lCPI0_80@PAGE
Lloh128:
	adrp	x26, lCPI0_81@PAGE
Lloh129:
	adrp	x27, lCPI0_82@PAGE
	str	x28, [sp, #2760]                ; 8-byte Spill
Lloh130:
	adrp	x28, lCPI0_83@PAGE
Lloh131:
	adrp	x30, lCPI0_84@PAGE
Lloh132:
	adrp	x4, lCPI0_85@PAGE
Lloh133:
	adrp	x20, lCPI0_86@PAGE
Lloh134:
	adrp	x8, lCPI0_87@PAGE
Lloh135:
	adrp	x16, lCPI0_88@PAGE
Lloh136:
	adrp	x1, lCPI0_89@PAGE
Lloh137:
	adrp	x3, lCPI0_90@PAGE
	mov	x0, #-6148914691236517206       ; =0xaaaaaaaaaaaaaaaa
	movk	x0, #43691
	dup.4s	v7, w21
Lloh138:
	adrp	x21, lCPI0_6@PAGE
Lloh139:
	ldr	q2, [x21, lCPI0_6@PAGEOFF]
Lloh140:
	ldr	q3, [x23, lCPI0_7@PAGEOFF]
Lloh141:
	adrp	x21, lCPI0_8@PAGE
Lloh142:
	ldr	q4, [x21, lCPI0_8@PAGEOFF]
Lloh143:
	adrp	x21, lCPI0_9@PAGE
Lloh144:
	ldr	q5, [x21, lCPI0_9@PAGEOFF]
Lloh145:
	adrp	x21, lCPI0_70@PAGE
Lloh146:
	ldr	q6, [x21, lCPI0_70@PAGEOFF]
	str	q6, [sp, #496]                  ; 16-byte Spill
Lloh147:
	adrp	x21, lCPI0_71@PAGE
Lloh148:
	ldr	q6, [x21, lCPI0_71@PAGEOFF]
	str	q6, [sp, #480]                  ; 16-byte Spill
Lloh149:
	adrp	x21, lCPI0_72@PAGE
Lloh150:
	ldr	q6, [x21, lCPI0_72@PAGEOFF]
	str	q6, [sp, #464]                  ; 16-byte Spill
Lloh151:
	ldr	q6, [x22, lCPI0_73@PAGEOFF]
	str	q6, [sp, #448]                  ; 16-byte Spill
Lloh152:
	ldr	q6, [x24, lCPI0_79@PAGEOFF]
	str	q6, [sp, #4224]                 ; 16-byte Spill
Lloh153:
	ldr	q6, [x25, lCPI0_80@PAGEOFF]
	str	q6, [sp, #4208]                 ; 16-byte Spill
Lloh154:
	ldr	q6, [x26, lCPI0_81@PAGEOFF]
	str	q6, [sp, #4192]                 ; 16-byte Spill
Lloh155:
	ldr	q6, [x27, lCPI0_82@PAGEOFF]
	str	q6, [sp, #4176]                 ; 16-byte Spill
	mov	w27, #43691                     ; =0xaaab
Lloh156:
	adrp	x21, lCPI0_78@PAGE
Lloh157:
	ldr	q6, [x21, lCPI0_78@PAGEOFF]
	str	q6, [sp, #432]                  ; 16-byte Spill
Lloh158:
	ldr	q6, [x28, lCPI0_83@PAGEOFF]
	str	q6, [sp, #416]                  ; 16-byte Spill
	ldr	x22, [sp, #2760]                ; 8-byte Reload
Lloh159:
	ldr	q6, [x30, lCPI0_84@PAGEOFF]
	str	q6, [sp, #400]                  ; 16-byte Spill
Lloh160:
	ldr	q6, [x4, lCPI0_85@PAGEOFF]
	str	q6, [sp, #384]                  ; 16-byte Spill
Lloh161:
	ldr	q6, [x20, lCPI0_86@PAGEOFF]
	str	q6, [sp, #368]                  ; 16-byte Spill
Lloh162:
	ldr	q6, [x8, lCPI0_87@PAGEOFF]
	str	q6, [sp, #3328]                 ; 16-byte Spill
	ldr	x8, [sp, #3352]                 ; 8-byte Reload
Lloh163:
	ldr	q6, [x16, lCPI0_88@PAGEOFF]
	str	q6, [sp, #3312]                 ; 16-byte Spill
Lloh164:
	ldr	q6, [x1, lCPI0_89@PAGEOFF]
	str	q6, [sp, #3296]                 ; 16-byte Spill
Lloh165:
	ldr	q6, [x3, lCPI0_90@PAGEOFF]
	str	q6, [sp, #3280]                 ; 16-byte Spill
	and.16b	v19, v0, v7
	stp	q2, q7, [sp, #560]              ; 32-byte Folded Spill
	and.16b	v6, v1, v7
	add.2d	v7, v25, v2
	stp	q4, q3, [sp, #528]              ; 32-byte Folded Spill
	add.2d	v2, v25, v3
	stp	q2, q7, [sp, #336]              ; 32-byte Folded Spill
	add.2d	v3, v25, v4
	str	q5, [sp, #512]                  ; 16-byte Spill
	add.2d	v2, v25, v5
	stp	q2, q3, [sp, #304]              ; 32-byte Folded Spill
	movi.2d	v2, #0000000000000000
	str	q2, [sp, #288]                  ; 16-byte Spill
	str	q2, [sp, #3264]                 ; 16-byte Spill
	str	q2, [sp, #3248]                 ; 16-byte Spill
	movi.2d	v22, #0000000000000000
	movi.2d	v9, #0000000000000000
	str	q2, [sp, #4896]                 ; 16-byte Spill
	str	q2, [sp, #4880]                 ; 16-byte Spill
	movi.2d	v3, #0000000000000000
	str	q2, [sp, #4864]                 ; 16-byte Spill
	str	q2, [sp, #4848]                 ; 16-byte Spill
	str	q2, [sp, #4832]                 ; 16-byte Spill
	str	q2, [sp, #4816]                 ; 16-byte Spill
	movi.2d	v18, #0000000000000000
	str	q2, [sp, #5376]                 ; 16-byte Spill
	str	q2, [sp, #5360]                 ; 16-byte Spill
	str	q2, [sp, #5344]                 ; 16-byte Spill
	str	q2, [sp, #5328]                 ; 16-byte Spill
	str	q2, [sp, #5312]                 ; 16-byte Spill
	str	q2, [sp, #5296]                 ; 16-byte Spill
	str	q2, [sp, #5280]                 ; 16-byte Spill
	str	q2, [sp, #3232]                 ; 16-byte Spill
	str	q2, [sp, #3216]                 ; 16-byte Spill
	str	q2, [sp, #3200]                 ; 16-byte Spill
	str	q2, [sp, #3376]                 ; 16-byte Spill
	str	q2, [sp, #3184]                 ; 16-byte Spill
	str	q2, [sp, #3168]                 ; 16-byte Spill
	str	q2, [sp, #3152]                 ; 16-byte Spill
	str	q2, [sp, #3360]                 ; 16-byte Spill
	movi.2d	v15, #0000000000000000
	str	q2, [sp, #5616]                 ; 16-byte Spill
	str	q2, [sp, #4992]                 ; 16-byte Spill
	str	q2, [sp, #5600]                 ; 16-byte Spill
	str	q2, [sp, #5584]                 ; 16-byte Spill
	str	q2, [sp, #5568]                 ; 16-byte Spill
	str	q2, [sp, #5552]                 ; 16-byte Spill
	str	q2, [sp, #5536]                 ; 16-byte Spill
	str	q2, [sp, #5520]                 ; 16-byte Spill
	str	q2, [sp, #5504]                 ; 16-byte Spill
	str	q2, [sp, #5488]                 ; 16-byte Spill
	str	q2, [sp, #5472]                 ; 16-byte Spill
	str	q2, [sp, #5456]                 ; 16-byte Spill
	str	q2, [sp, #5440]                 ; 16-byte Spill
	str	q2, [sp, #5424]                 ; 16-byte Spill
	str	q2, [sp, #5408]                 ; 16-byte Spill
	str	q2, [sp, #5792]                 ; 16-byte Spill
	str	q2, [sp, #5776]                 ; 16-byte Spill
	str	q2, [sp, #5760]                 ; 16-byte Spill
	movi.2d	v23, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v24, #0000000000000000
	str	q2, [sp, #3136]                 ; 16-byte Spill
	str	q2, [sp, #3120]                 ; 16-byte Spill
	str	q2, [sp, #3104]                 ; 16-byte Spill
	str	q2, [sp, #3088]                 ; 16-byte Spill
	str	q2, [sp, #3072]                 ; 16-byte Spill
	str	q2, [sp, #3056]                 ; 16-byte Spill
	str	q2, [sp, #3040]                 ; 16-byte Spill
	str	q2, [sp, #4976]                 ; 16-byte Spill
	str	q2, [sp, #4960]                 ; 16-byte Spill
	str	q2, [sp, #4944]                 ; 16-byte Spill
	str	q2, [sp, #4928]                 ; 16-byte Spill
	str	q2, [sp, #4160]                 ; 16-byte Spill
	str	q2, [sp, #4144]                 ; 16-byte Spill
	str	q2, [sp, #4128]                 ; 16-byte Spill
	str	q2, [sp, #4112]                 ; 16-byte Spill
	movi.2d	v14, #0000000000000000
	str	q2, [sp, #5744]                 ; 16-byte Spill
	str	q2, [sp, #5728]                 ; 16-byte Spill
	str	q2, [sp, #5712]                 ; 16-byte Spill
	str	q2, [sp, #5696]                 ; 16-byte Spill
	str	q2, [sp, #5680]                 ; 16-byte Spill
	str	q2, [sp, #5664]                 ; 16-byte Spill
	str	q2, [sp, #5648]                 ; 16-byte Spill
	str	q2, [sp, #5632]                 ; 16-byte Spill
	str	q2, [sp, #5264]                 ; 16-byte Spill
	str	q2, [sp, #5248]                 ; 16-byte Spill
	str	q2, [sp, #5232]                 ; 16-byte Spill
	str	q2, [sp, #5216]                 ; 16-byte Spill
	str	q2, [sp, #5200]                 ; 16-byte Spill
	str	q2, [sp, #5184]                 ; 16-byte Spill
	str	q2, [sp, #5168]                 ; 16-byte Spill
	str	q2, [sp, #5152]                 ; 16-byte Spill
	str	q2, [sp, #5136]                 ; 16-byte Spill
	str	q2, [sp, #5120]                 ; 16-byte Spill
	str	q2, [sp, #5104]                 ; 16-byte Spill
	str	q2, [sp, #5088]                 ; 16-byte Spill
	str	q2, [sp, #5072]                 ; 16-byte Spill
	str	q2, [sp, #5056]                 ; 16-byte Spill
	str	q2, [sp, #5040]                 ; 16-byte Spill
	str	q2, [sp, #5024]                 ; 16-byte Spill
	str	q2, [sp, #3024]                 ; 16-byte Spill
	str	q2, [sp, #3008]                 ; 16-byte Spill
	str	q2, [sp, #2992]                 ; 16-byte Spill
	str	q2, [sp, #2976]                 ; 16-byte Spill
	str	q2, [sp, #2960]                 ; 16-byte Spill
	str	q2, [sp, #4096]                 ; 16-byte Spill
	str	q2, [sp, #4080]                 ; 16-byte Spill
	str	q2, [sp, #4544]                 ; 16-byte Spill
	str	q2, [sp, #4800]                 ; 16-byte Spill
	str	q2, [sp, #4784]                 ; 16-byte Spill
	str	q2, [sp, #4768]                 ; 16-byte Spill
	str	q2, [sp, #4752]                 ; 16-byte Spill
	str	q2, [sp, #4736]                 ; 16-byte Spill
	str	q2, [sp, #4720]                 ; 16-byte Spill
	str	q2, [sp, #4704]                 ; 16-byte Spill
	str	q2, [sp, #4688]                 ; 16-byte Spill
	str	q2, [sp, #4672]                 ; 16-byte Spill
	str	q2, [sp, #4656]                 ; 16-byte Spill
	str	q2, [sp, #4640]                 ; 16-byte Spill
	str	q2, [sp, #4624]                 ; 16-byte Spill
	str	q2, [sp, #4608]                 ; 16-byte Spill
	str	q2, [sp, #4592]                 ; 16-byte Spill
	str	q2, [sp, #4576]                 ; 16-byte Spill
	str	q2, [sp, #4560]                 ; 16-byte Spill
	str	q2, [sp, #4064]                 ; 16-byte Spill
	str	q2, [sp, #4048]                 ; 16-byte Spill
	str	q2, [sp, #4032]                 ; 16-byte Spill
	str	q2, [sp, #4016]                 ; 16-byte Spill
	str	q2, [sp, #4000]                 ; 16-byte Spill
	str	q2, [sp, #3984]                 ; 16-byte Spill
	str	q2, [sp, #3968]                 ; 16-byte Spill
	str	q2, [sp, #3952]                 ; 16-byte Spill
	str	q2, [sp, #3936]                 ; 16-byte Spill
	str	q2, [sp, #3920]                 ; 16-byte Spill
	str	q6, [sp, #4496]                 ; 16-byte Spill
	str	q19, [sp, #4480]                ; 16-byte Spill
	str	q2, [sp, #3904]                 ; 16-byte Spill
	str	q2, [sp, #3888]                 ; 16-byte Spill
	str	q6, [sp, #4464]                 ; 16-byte Spill
	str	q19, [sp, #4448]                ; 16-byte Spill
	str	q6, [sp, #4432]                 ; 16-byte Spill
	str	q19, [sp, #4416]                ; 16-byte Spill
	str	q2, [sp, #3872]                 ; 16-byte Spill
	str	q2, [sp, #3856]                 ; 16-byte Spill
	str	q2, [sp, #3840]                 ; 16-byte Spill
	str	q6, [sp, #4400]                 ; 16-byte Spill
	str	q19, [sp, #4384]                ; 16-byte Spill
	str	q6, [sp, #4368]                 ; 16-byte Spill
	str	q19, [sp, #4352]                ; 16-byte Spill
	str	q2, [sp, #3824]                 ; 16-byte Spill
	str	q6, [sp, #4336]                 ; 16-byte Spill
	str	q19, [sp, #4320]                ; 16-byte Spill
	str	q6, [sp, #3808]                 ; 16-byte Spill
	str	q19, [sp, #3792]                ; 16-byte Spill
	ldr	w26, [sp, #2756]                ; 4-byte Reload
	ldr	w28, [sp, #2752]                ; 4-byte Reload
	ldr	w30, [sp, #2748]                ; 4-byte Reload
LBB0_28:                                ; %direct.true216
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_51 Depth 2
                                        ;     Child Loop BB0_54 Depth 2
                                        ;     Child Loop BB0_57 Depth 2
                                        ;     Child Loop BB0_60 Depth 2
                                        ;     Child Loop BB0_63 Depth 2
                                        ;     Child Loop BB0_66 Depth 2
                                        ;     Child Loop BB0_69 Depth 2
                                        ;     Child Loop BB0_72 Depth 2
                                        ;     Child Loop BB0_75 Depth 2
                                        ;     Child Loop BB0_78 Depth 2
                                        ;     Child Loop BB0_81 Depth 2
                                        ;     Child Loop BB0_84 Depth 2
                                        ;     Child Loop BB0_87 Depth 2
                                        ;     Child Loop BB0_90 Depth 2
                                        ;     Child Loop BB0_93 Depth 2
                                        ;     Child Loop BB0_96 Depth 2
                                        ;     Child Loop BB0_31 Depth 2
                                        ;     Child Loop BB0_99 Depth 2
                                        ;     Child Loop BB0_120 Depth 2
                                        ;     Child Loop BB0_138 Depth 2
                                        ;     Child Loop BB0_141 Depth 2
                                        ;     Child Loop BB0_144 Depth 2
                                        ;     Child Loop BB0_147 Depth 2
                                        ;     Child Loop BB0_150 Depth 2
                                        ;     Child Loop BB0_153 Depth 2
                                        ;     Child Loop BB0_156 Depth 2
                                        ;     Child Loop BB0_159 Depth 2
                                        ;     Child Loop BB0_396 Depth 2
                                        ;     Child Loop BB0_452 Depth 2
                                        ;     Child Loop BB0_485 Depth 2
                                        ;     Child Loop BB0_487 Depth 2
                                        ;     Child Loop BB0_489 Depth 2
                                        ;     Child Loop BB0_491 Depth 2
                                        ;     Child Loop BB0_493 Depth 2
                                        ;     Child Loop BB0_495 Depth 2
                                        ;     Child Loop BB0_497 Depth 2
                                        ;     Child Loop BB0_499 Depth 2
                                        ;     Child Loop BB0_502 Depth 2
                                        ;     Child Loop BB0_536 Depth 2
                                        ;     Child Loop BB0_554 Depth 2
                                        ;     Child Loop BB0_572 Depth 2
                                        ;     Child Loop BB0_590 Depth 2
                                        ;     Child Loop BB0_608 Depth 2
                                        ;     Child Loop BB0_626 Depth 2
                                        ;     Child Loop BB0_644 Depth 2
                                        ;     Child Loop BB0_662 Depth 2
                                        ;     Child Loop BB0_680 Depth 2
                                        ;     Child Loop BB0_698 Depth 2
                                        ;       Child Loop BB0_699 Depth 3
                                        ;     Child Loop BB0_703 Depth 2
                                        ;       Child Loop BB0_704 Depth 3
                                        ;     Child Loop BB0_708 Depth 2
                                        ;       Child Loop BB0_709 Depth 3
                                        ;     Child Loop BB0_713 Depth 2
                                        ;       Child Loop BB0_714 Depth 3
                                        ;     Child Loop BB0_718 Depth 2
                                        ;       Child Loop BB0_719 Depth 3
                                        ;     Child Loop BB0_723 Depth 2
                                        ;       Child Loop BB0_724 Depth 3
                                        ;     Child Loop BB0_728 Depth 2
                                        ;       Child Loop BB0_729 Depth 3
                                        ;     Child Loop BB0_733 Depth 2
                                        ;       Child Loop BB0_734 Depth 3
                                        ;     Child Loop BB0_738 Depth 2
                                        ;     Child Loop BB0_755 Depth 2
	mov.16b	v5, v3
	str	q6, [sp, #4288]                 ; 16-byte Spill
	str	q15, [sp, #4272]                ; 16-byte Spill
	str	q18, [sp, #2912]                ; 16-byte Spill
	sshll.2d	v2, v1, #0
	sshll.2d	v3, v0, #0
	lsl	x21, x8, #4
	ldr	q4, [sp, #2688]                 ; 16-byte Reload
	ldr	q6, [sp, #4624]                 ; 16-byte Reload
	ldr	q11, [sp, #4512]                ; 16-byte Reload
	bit.16b	v6, v4, v11
	str	q6, [sp, #4624]                 ; 16-byte Spill
	ldr	q6, [sp, #4656]                 ; 16-byte Reload
	ldr	q8, [sp, #4528]                 ; 16-byte Reload
	bit.16b	v6, v4, v8
	str	q6, [sp, #4656]                 ; 16-byte Spill
	ldr	q6, [sp, #4640]                 ; 16-byte Reload
	bit.16b	v6, v4, v3
	str	q6, [sp, #4640]                 ; 16-byte Spill
	ldr	q6, [sp, #4672]                 ; 16-byte Reload
	bit.16b	v6, v4, v2
	str	q6, [sp, #4672]                 ; 16-byte Spill
	ldp	q4, q7, [sp, #480]              ; 32-byte Folded Reload
	ldr	q6, [sp, #4560]                 ; 16-byte Reload
	bit.16b	v6, v7, v11
	str	q6, [sp, #4560]                 ; 16-byte Spill
	ldr	q6, [sp, #4592]                 ; 16-byte Reload
	bit.16b	v6, v4, v8
	str	q6, [sp, #4592]                 ; 16-byte Spill
	ldr	q4, [sp, #464]                  ; 16-byte Reload
	ldr	q6, [sp, #4576]                 ; 16-byte Reload
	bit.16b	v6, v4, v3
	str	q6, [sp, #4576]                 ; 16-byte Spill
	ldr	q3, [sp, #448]                  ; 16-byte Reload
	ldr	q4, [sp, #4608]                 ; 16-byte Reload
	bit.16b	v4, v3, v2
	str	q4, [sp, #4608]                 ; 16-byte Spill
	dup.2d	v21, x21
	str	x8, [sp, #3352]                 ; 8-byte Spill
	cmp	x8, #8
	str	q19, [sp, #4304]                ; 16-byte Spill
	str	q5, [sp, #5008]                 ; 16-byte Spill
	str	q21, [sp, #3776]                ; 16-byte Spill
	b.ne	LBB0_49
; %bb.29:                               ; %direct.true879.preheader
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	ldr	q4, [sp, #2672]                 ; 16-byte Reload
	ldr	x20, [sp, #2552]                ; 8-byte Reload
	ldr	q18, [sp, #2160]                ; 16-byte Reload
	ldp	q27, q26, [sp, #976]            ; 32-byte Folded Reload
	ldr	x23, [sp, #968]                 ; 8-byte Reload
	ldr	q30, [sp, #432]                 ; 16-byte Reload
	ldr	q10, [sp, #288]                 ; 16-byte Reload
	ldr	q15, [sp, #3040]                ; 16-byte Reload
	ldr	d7, [sp, #1016]                 ; 8-byte Reload
	ldr	q31, [sp, #2704]                ; 16-byte Reload
	ldr	q12, [sp, #3264]                ; 16-byte Reload
	ldr	q5, [sp, #3248]                 ; 16-byte Reload
	b	LBB0_31
LBB0_30:                                ; %else555
                                        ;   in Loop: Header=BB0_31 Depth=2
	sshll.2d	v3, v0, #0
	add.2d	v16, v17, v26
	add.2d	v21, v17, v18
	add.2d	v17, v17, v27
	shl.2d	v17, v17, #5
	shl.2d	v21, v21, #5
	shl.2d	v16, v16, #5
	orr.16b	v16, v16, v6
	orr.16b	v21, v21, v6
	orr.16b	v6, v17, v6
	ldr	q17, [sp, #4896]                ; 16-byte Reload
	bit.16b	v17, v6, v11
	str	q17, [sp, #4896]                ; 16-byte Spill
	bit.16b	v9, v21, v3
	bit.16b	v22, v16, v8
	add	x16, x16, #1
	add	x8, x8, #4
	cmp	x8, #2048
	b.eq	LBB0_97
LBB0_31:                                ; %direct.true879
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v2, v1, #0
	and	x1, x16, #0x1f
	lsr	x3, x16, #5
	orr	x4, x3, #0x80
	dup.2d	v17, x4
	ldr	q3, [sp, #4912]                 ; 16-byte Reload
	add.2d	v3, v17, v3
	shl.2d	v3, v3, #5
	dup.2d	v6, x1
	orr.16b	v3, v3, v6
	bit.16b	v10, v3, v2
	movi.2d	v16, #0000000000000000
	cbnz	x3, LBB0_33
; %bb.32:                               ; %direct.true892
                                        ;   in Loop: Header=BB0_31 Depth=2
	fmov	x1, d10
	add	x1, x20, x1, lsl #2
	ld1r.4s	{ v16 }, [x1]
LBB0_33:                                ; %direct.schedule.88
                                        ;   in Loop: Header=BB0_31 Depth=2
	and.16b	v2, v31, v30
	addv.8h	h2, v2
	fmov	w1, s2
	bit.16b	v12, v16, v1
	dup.2d	v21, x8
	ldr	q3, [sp, #4608]                 ; 16-byte Reload
	orr.16b	v3, v21, v3
	ldr	q19, [sp, #4672]                ; 16-byte Reload
	add.2d	v25, v19, v3
	tbz	w1, #0, LBB0_41
; %bb.34:                               ; %cond.store524
                                        ;   in Loop: Header=BB0_31 Depth=2
	fmov	x3, d25
	str	s12, [x3]
	and	w1, w1, #0xff
	tbnz	w1, #1, LBB0_42
LBB0_35:                                ; %else531
                                        ;   in Loop: Header=BB0_31 Depth=2
	ldr	q3, [sp, #4592]                 ; 16-byte Reload
	orr.16b	v3, v21, v3
	ldr	q19, [sp, #4656]                ; 16-byte Reload
	add.2d	v3, v19, v3
	tbz	w1, #2, LBB0_43
LBB0_36:                                ; %cond.store532
                                        ;   in Loop: Header=BB0_31 Depth=2
	fmov	x3, d3
	st1.s	{ v12 }[2], [x3]
	tbnz	w1, #3, LBB0_44
LBB0_37:                                ; %else539
                                        ;   in Loop: Header=BB0_31 Depth=2
	bit.16b	v5, v16, v0
	ldr	q3, [sp, #4576]                 ; 16-byte Reload
	orr.16b	v3, v21, v3
	ldr	q16, [sp, #4640]                ; 16-byte Reload
	add.2d	v3, v16, v3
	tbz	w1, #4, LBB0_45
LBB0_38:                                ; %cond.store540
                                        ;   in Loop: Header=BB0_31 Depth=2
	fmov	x3, d3
	str	s5, [x3]
	tbnz	w1, #5, LBB0_46
LBB0_39:                                ; %else547
                                        ;   in Loop: Header=BB0_31 Depth=2
	ldr	q3, [sp, #4560]                 ; 16-byte Reload
	orr.16b	v3, v21, v3
	ldr	q16, [sp, #4624]                ; 16-byte Reload
	add.2d	v3, v16, v3
	tbz	w1, #6, LBB0_47
LBB0_40:                                ; %cond.store548
                                        ;   in Loop: Header=BB0_31 Depth=2
	fmov	x3, d3
	st1.s	{ v5 }[2], [x3]
	tbz	w1, #7, LBB0_30
	b	LBB0_48
LBB0_41:                                ; %else527
                                        ;   in Loop: Header=BB0_31 Depth=2
	and	w1, w1, #0xff
	tbz	w1, #1, LBB0_35
LBB0_42:                                ; %cond.store528
                                        ;   in Loop: Header=BB0_31 Depth=2
	mov.d	x3, v25[1]
	st1.s	{ v12 }[1], [x3]
	ldr	q3, [sp, #4592]                 ; 16-byte Reload
	orr.16b	v3, v21, v3
	ldr	q19, [sp, #4656]                ; 16-byte Reload
	add.2d	v3, v19, v3
	tbnz	w1, #2, LBB0_36
LBB0_43:                                ; %else535
                                        ;   in Loop: Header=BB0_31 Depth=2
	tbz	w1, #3, LBB0_37
LBB0_44:                                ; %cond.store536
                                        ;   in Loop: Header=BB0_31 Depth=2
	mov.d	x3, v3[1]
	st1.s	{ v12 }[3], [x3]
	bit.16b	v5, v16, v0
	ldr	q3, [sp, #4576]                 ; 16-byte Reload
	orr.16b	v3, v21, v3
	ldr	q16, [sp, #4640]                ; 16-byte Reload
	add.2d	v3, v16, v3
	tbnz	w1, #4, LBB0_38
LBB0_45:                                ; %else543
                                        ;   in Loop: Header=BB0_31 Depth=2
	tbz	w1, #5, LBB0_39
LBB0_46:                                ; %cond.store544
                                        ;   in Loop: Header=BB0_31 Depth=2
	mov.d	x3, v3[1]
	st1.s	{ v5 }[1], [x3]
	ldr	q3, [sp, #4560]                 ; 16-byte Reload
	orr.16b	v3, v21, v3
	ldr	q16, [sp, #4624]                ; 16-byte Reload
	add.2d	v3, v16, v3
	tbnz	w1, #6, LBB0_40
LBB0_47:                                ; %else551
                                        ;   in Loop: Header=BB0_31 Depth=2
	tbz	w1, #7, LBB0_30
LBB0_48:                                ; %cond.store552
                                        ;   in Loop: Header=BB0_31 Depth=2
	mov.d	x1, v3[1]
	st1.s	{ v5 }[3], [x1]
	b	LBB0_30
LBB0_49:                                ; %direct.true219
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q2, [sp, #4912]                 ; 16-byte Reload
	add.2d	v26, v21, v2
	shl.2d	v2, v26, #5
	ldr	q4, [sp, #2672]                 ; 16-byte Reload
	ldr	x3, [sp, #2552]                 ; 8-byte Reload
	ldr	q6, [sp, #2160]                 ; 16-byte Reload
	ldr	x23, [sp, #968]                 ; 8-byte Reload
	ldr	q15, [sp, #3040]                ; 16-byte Reload
	ldr	d7, [sp, #1016]                 ; 8-byte Reload
	ldr	q31, [sp, #2704]                ; 16-byte Reload
	tbz	w26, #0, LBB0_52
; %bb.50:                               ; %copy.active228
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q3, [sp, #4672]                 ; 16-byte Reload
	fmov	x16, d3
	ldr	q3, [sp, #4608]                 ; 16-byte Reload
	fmov	x1, d3
	add	x16, x16, x1
	fmov	x1, d2
	add	x1, x3, x1, lsl #2
LBB0_51:                                ; %copy.chunk.i525
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x1, x8]
	str	q3, [x16, x8]
	add	x8, x8, #16
	cmp	x8, #2048
	b.ne	LBB0_51
LBB0_52:                                ; %copy.continue229
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	x4, [sp, #2544]                 ; 8-byte Reload
	ldr	q3, [sp, #992]                  ; 16-byte Reload
	ldr	q18, [sp, #3024]                ; 16-byte Reload
	cbz	w28, LBB0_55
; %bb.53:                               ; %copy.active230
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q16, [sp, #4672]                ; 16-byte Reload
	mov.d	x16, v16[1]
	ldr	q16, [sp, #4608]                ; 16-byte Reload
	mov.d	x1, v16[1]
	add	x16, x16, x1
	mov.d	x1, v2[1]
	add	x1, x3, x1, lsl #2
LBB0_54:                                ; %copy.chunk.i528
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x1, x8]
	str	q2, [x16, x8]
	add	x8, x8, #16
	cmp	x8, #2048
	b.ne	LBB0_54
LBB0_55:                                ; %copy.continue231
                                        ;   in Loop: Header=BB0_28 Depth=1
	add.2d	v25, v21, v3
	shl.2d	v2, v25, #5
	ldr	q16, [sp, #976]                 ; 16-byte Reload
	ldr	q30, [sp, #432]                 ; 16-byte Reload
	ldr	q27, [sp, #2976]                ; 16-byte Reload
	ldr	q12, [sp, #3264]                ; 16-byte Reload
	ldr	q5, [sp, #3248]                 ; 16-byte Reload
	cbz	w30, LBB0_58
; %bb.56:                               ; %copy.active232
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q3, [sp, #4656]                 ; 16-byte Reload
	fmov	x16, d3
	ldr	q3, [sp, #4592]                 ; 16-byte Reload
	fmov	x1, d3
	add	x16, x16, x1
	fmov	x1, d2
	add	x1, x3, x1, lsl #2
LBB0_57:                                ; %copy.chunk.i532
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x1, x8]
	str	q3, [x16, x8]
	add	x8, x8, #16
	cmp	x8, #2048
	b.ne	LBB0_57
LBB0_58:                                ; %copy.continue233
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	w8, [sp, #4268]                 ; 4-byte Reload
	cbz	w8, LBB0_61
; %bb.59:                               ; %copy.active234
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q3, [sp, #4656]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	ldr	q3, [sp, #4592]                 ; 16-byte Reload
	mov.d	x1, v3[1]
	add	x16, x16, x1
	mov.d	x1, v2[1]
	add	x1, x3, x1, lsl #2
LBB0_60:                                ; %copy.chunk.i536
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x1, x8]
	str	q2, [x16, x8]
	add	x8, x8, #16
	cmp	x8, #2048
	b.ne	LBB0_60
LBB0_61:                                ; %copy.continue235
                                        ;   in Loop: Header=BB0_28 Depth=1
	add.2d	v17, v21, v6
	shl.2d	v2, v17, #5
	ldr	w8, [sp, #4264]                 ; 4-byte Reload
	cbz	w8, LBB0_64
; %bb.62:                               ; %copy.active236
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q3, [sp, #4640]                 ; 16-byte Reload
	fmov	x16, d3
	ldr	q3, [sp, #4576]                 ; 16-byte Reload
	fmov	x1, d3
	add	x16, x16, x1
	fmov	x1, d2
	add	x1, x3, x1, lsl #2
LBB0_63:                                ; %copy.chunk.i540
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x1, x8]
	str	q3, [x16, x8]
	add	x8, x8, #16
	cmp	x8, #2048
	b.ne	LBB0_63
LBB0_64:                                ; %copy.continue237
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	w8, [sp, #4260]                 ; 4-byte Reload
	cbz	w8, LBB0_67
; %bb.65:                               ; %copy.active238
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q3, [sp, #4640]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	ldr	q3, [sp, #4576]                 ; 16-byte Reload
	mov.d	x1, v3[1]
	add	x16, x16, x1
	mov.d	x1, v2[1]
	add	x1, x3, x1, lsl #2
LBB0_66:                                ; %copy.chunk.i544
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x1, x8]
	str	q2, [x16, x8]
	add	x8, x8, #16
	cmp	x8, #2048
	b.ne	LBB0_66
LBB0_67:                                ; %copy.continue239
                                        ;   in Loop: Header=BB0_28 Depth=1
	add.2d	v2, v21, v16
	shl.2d	v6, v2, #5
	ldr	w8, [sp, #4256]                 ; 4-byte Reload
	cbz	w8, LBB0_70
; %bb.68:                               ; %copy.active240
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q3, [sp, #4624]                 ; 16-byte Reload
	fmov	x16, d3
	ldr	q3, [sp, #4560]                 ; 16-byte Reload
	fmov	x1, d3
	add	x16, x16, x1
	fmov	x1, d6
	add	x1, x3, x1, lsl #2
LBB0_69:                                ; %copy.chunk.i548
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x1, x8]
	str	q3, [x16, x8]
	add	x8, x8, #16
	cmp	x8, #2048
	b.ne	LBB0_69
LBB0_70:                                ; %copy.continue241
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	w8, [sp, #4252]                 ; 4-byte Reload
	ldr	q16, [sp, #4096]                ; 16-byte Reload
	cbz	w8, LBB0_73
; %bb.71:                               ; %copy.active242
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q3, [sp, #4624]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	ldr	q3, [sp, #4560]                 ; 16-byte Reload
	mov.d	x1, v3[1]
	add	x16, x16, x1
	mov.d	x1, v6[1]
	add	x1, x3, x1, lsl #2
LBB0_72:                                ; %copy.chunk.i552
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x1, x8]
	str	q3, [x16, x8]
	add	x8, x8, #16
	cmp	x8, #2048
	b.ne	LBB0_72
LBB0_73:                                ; %direct.schedule.7.thread
                                        ;   in Loop: Header=BB0_28 Depth=1
	sshll.2d	v3, v1, #0
	ldr	q6, [sp, #4800]                 ; 16-byte Reload
	bit.16b	v6, v4, v3
	str	q6, [sp, #4800]                 ; 16-byte Spill
Lloh166:
	adrp	x8, lCPI0_77@PAGE
Lloh167:
	ldr	q6, [x8, lCPI0_77@PAGEOFF]
	ldr	q21, [sp, #4736]                ; 16-byte Reload
	bit.16b	v21, v6, v3
	str	q21, [sp, #4736]                ; 16-byte Spill
	fmov	x8, d26
	add	x8, x8, x8, lsl #1
	lsl	x8, x8, #4
	fmov	d6, x8
	mov.d	x8, v26[1]
	add	x8, x8, x8, lsl #1
	lsl	x8, x8, #4
	mov.d	v6[1], x8
	tbz	w26, #0, LBB0_76
; %bb.74:                               ; %copy.active255
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q3, [sp, #4800]                 ; 16-byte Reload
	fmov	x16, d3
	ldr	q3, [sp, #4736]                 ; 16-byte Reload
	fmov	x1, d3
	add	x16, x16, x1
	fmov	x1, d6
	add	x1, x4, x1, lsl #2
LBB0_75:                                ; %copy.chunk.i556
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x1, x8]
	str	q3, [x16, x8]
	add	x8, x8, #16
	cmp	x8, #3072
	b.ne	LBB0_75
LBB0_76:                                ; %copy.continue256
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q21, [sp, #3008]                ; 16-byte Reload
	ldr	q26, [sp, #2992]                ; 16-byte Reload
	cbz	w28, LBB0_79
; %bb.77:                               ; %copy.active257
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q3, [sp, #4800]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	ldr	q3, [sp, #4736]                 ; 16-byte Reload
	mov.d	x1, v3[1]
	add	x16, x16, x1
	mov.d	x1, v6[1]
	add	x1, x4, x1, lsl #2
LBB0_78:                                ; %copy.chunk.i559
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x1, x8]
	str	q3, [x16, x8]
	add	x8, x8, #16
	cmp	x8, #3072
	b.ne	LBB0_78
LBB0_79:                                ; %copy.continue258
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #4784]                 ; 16-byte Reload
	bit.16b	v3, v4, v8
	str	q3, [sp, #4784]                 ; 16-byte Spill
Lloh168:
	adrp	x8, lCPI0_75@PAGE
Lloh169:
	ldr	q3, [x8, lCPI0_75@PAGEOFF]
	ldr	q6, [sp, #4720]                 ; 16-byte Reload
	bit.16b	v6, v3, v8
	str	q6, [sp, #4720]                 ; 16-byte Spill
	fmov	x8, d25
	add	x8, x8, x8, lsl #1
	lsl	x8, x8, #4
	fmov	d6, x8
	mov.d	x8, v25[1]
	add	x8, x8, x8, lsl #1
	lsl	x8, x8, #4
	mov.d	v6[1], x8
	cbz	w30, LBB0_82
; %bb.80:                               ; %copy.active259
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q3, [sp, #4784]                 ; 16-byte Reload
	fmov	x16, d3
	ldr	q3, [sp, #4720]                 ; 16-byte Reload
	fmov	x1, d3
	add	x16, x16, x1
	fmov	x1, d6
	add	x1, x4, x1, lsl #2
LBB0_81:                                ; %copy.chunk.i563
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x1, x8]
	str	q3, [x16, x8]
	add	x8, x8, #16
	cmp	x8, #3072
	b.ne	LBB0_81
LBB0_82:                                ; %copy.continue260
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	w8, [sp, #4268]                 ; 4-byte Reload
	ldr	q25, [sp, #4544]                ; 16-byte Reload
	cbz	w8, LBB0_85
; %bb.83:                               ; %copy.active261
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q3, [sp, #4784]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	ldr	q3, [sp, #4720]                 ; 16-byte Reload
	mov.d	x1, v3[1]
	add	x16, x16, x1
	mov.d	x1, v6[1]
	add	x1, x4, x1, lsl #2
LBB0_84:                                ; %copy.chunk.i567
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x1, x8]
	str	q3, [x16, x8]
	add	x8, x8, #16
	cmp	x8, #3072
	b.ne	LBB0_84
LBB0_85:                                ; %copy.continue262
                                        ;   in Loop: Header=BB0_28 Depth=1
	sshll.2d	v3, v0, #0
	ldr	q6, [sp, #4768]                 ; 16-byte Reload
	bit.16b	v6, v4, v3
	str	q6, [sp, #4768]                 ; 16-byte Spill
Lloh170:
	adrp	x8, lCPI0_76@PAGE
Lloh171:
	ldr	q6, [x8, lCPI0_76@PAGEOFF]
	ldr	q10, [sp, #4704]                ; 16-byte Reload
	bit.16b	v10, v6, v3
	str	q10, [sp, #4704]                ; 16-byte Spill
	fmov	x8, d17
	add	x8, x8, x8, lsl #1
	lsl	x8, x8, #4
	fmov	d6, x8
	mov.d	x8, v17[1]
	add	x8, x8, x8, lsl #1
	lsl	x8, x8, #4
	mov.d	v6[1], x8
	ldr	w8, [sp, #4264]                 ; 4-byte Reload
	cbz	w8, LBB0_88
; %bb.86:                               ; %copy.active263
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q3, [sp, #4768]                 ; 16-byte Reload
	fmov	x16, d3
	ldr	q3, [sp, #4704]                 ; 16-byte Reload
	fmov	x1, d3
	add	x16, x16, x1
	fmov	x1, d6
	add	x1, x4, x1, lsl #2
LBB0_87:                                ; %copy.chunk.i571
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x1, x8]
	str	q3, [x16, x8]
	add	x8, x8, #16
	cmp	x8, #3072
	b.ne	LBB0_87
LBB0_88:                                ; %copy.continue264
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	w8, [sp, #4260]                 ; 4-byte Reload
	ldr	q17, [sp, #4080]                ; 16-byte Reload
	cbz	w8, LBB0_91
; %bb.89:                               ; %copy.active265
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q3, [sp, #4768]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	ldr	q3, [sp, #4704]                 ; 16-byte Reload
	mov.d	x1, v3[1]
	add	x16, x16, x1
	mov.d	x1, v6[1]
	add	x1, x4, x1, lsl #2
LBB0_90:                                ; %copy.chunk.i575
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x1, x8]
	str	q3, [x16, x8]
	add	x8, x8, #16
	cmp	x8, #3072
	b.ne	LBB0_90
LBB0_91:                                ; %copy.continue266
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #4752]                 ; 16-byte Reload
	bit.16b	v3, v4, v11
	str	q3, [sp, #4752]                 ; 16-byte Spill
Lloh172:
	adrp	x8, lCPI0_74@PAGE
Lloh173:
	ldr	q3, [x8, lCPI0_74@PAGEOFF]
	ldr	q4, [sp, #4688]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #4688]                 ; 16-byte Spill
	fmov	x8, d2
	add	x8, x8, x8, lsl #1
	lsl	x8, x8, #4
	fmov	d6, x8
	mov.d	x8, v2[1]
	add	x8, x8, x8, lsl #1
	lsl	x8, x8, #4
	mov.d	v6[1], x8
	ldr	w8, [sp, #4256]                 ; 4-byte Reload
	cbz	w8, LBB0_94
; %bb.92:                               ; %copy.active267
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q2, [sp, #4752]                 ; 16-byte Reload
	fmov	x16, d2
	ldr	q2, [sp, #4688]                 ; 16-byte Reload
	fmov	x1, d2
	add	x16, x16, x1
	fmov	x1, d6
	add	x1, x4, x1, lsl #2
LBB0_93:                                ; %copy.chunk.i579
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x1, x8]
	str	q2, [x16, x8]
	add	x8, x8, #16
	cmp	x8, #3072
	b.ne	LBB0_93
LBB0_94:                                ; %copy.continue268
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	w8, [sp, #4252]                 ; 4-byte Reload
	cbz	w8, LBB0_118
; %bb.95:                               ; %copy.active269
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q2, [sp, #4752]                 ; 16-byte Reload
	mov.d	x16, v2[1]
	ldr	q2, [sp, #4688]                 ; 16-byte Reload
	mov.d	x1, v2[1]
	add	x16, x16, x1
	mov.d	x1, v6[1]
	add	x1, x4, x1, lsl #2
LBB0_96:                                ; %copy.chunk.i583
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x1, x8]
	str	q2, [x16, x8]
	add	x8, x8, #16
	cmp	x8, #3072
	b.ne	LBB0_96
	b	LBB0_118
LBB0_97:                                ; %direct.schedule.7
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	sshll.2d	v3, v1, #0
	sshll.2d	v6, v0, #0
	ldr	q16, [sp, #4752]                ; 16-byte Reload
	bit.16b	v16, v4, v11
	str	q16, [sp, #4752]                ; 16-byte Spill
	ldr	q16, [sp, #4784]                ; 16-byte Reload
	bit.16b	v16, v4, v8
	str	q16, [sp, #4784]                ; 16-byte Spill
	ldr	q16, [sp, #4768]                ; 16-byte Reload
	bit.16b	v16, v4, v6
	str	q16, [sp, #4768]                ; 16-byte Spill
	ldr	q16, [sp, #4800]                ; 16-byte Reload
	bit.16b	v16, v4, v3
	str	q16, [sp, #4800]                ; 16-byte Spill
Lloh174:
	adrp	x1, lCPI0_74@PAGE
Lloh175:
	ldr	q16, [x1, lCPI0_74@PAGEOFF]
	ldr	q4, [sp, #4688]                 ; 16-byte Reload
	bit.16b	v4, v16, v11
	str	q4, [sp, #4688]                 ; 16-byte Spill
Lloh176:
	adrp	x1, lCPI0_75@PAGE
Lloh177:
	ldr	q16, [x1, lCPI0_75@PAGEOFF]
	ldr	q4, [sp, #4720]                 ; 16-byte Reload
	bit.16b	v4, v16, v8
	str	q4, [sp, #4720]                 ; 16-byte Spill
Lloh178:
	adrp	x1, lCPI0_76@PAGE
Lloh179:
	ldr	q16, [x1, lCPI0_76@PAGEOFF]
	ldr	q4, [sp, #4704]                 ; 16-byte Reload
	bit.16b	v4, v16, v6
	str	q4, [sp, #4704]                 ; 16-byte Spill
Lloh180:
	adrp	x1, lCPI0_77@PAGE
Lloh181:
	ldr	q6, [x1, lCPI0_77@PAGEOFF]
	ldr	q4, [sp, #4736]                 ; 16-byte Reload
	bit.16b	v4, v6, v3
	str	q4, [sp, #4736]                 ; 16-byte Spill
	ldr	x20, [sp, #2544]                ; 8-byte Reload
	b	LBB0_99
LBB0_98:                                ; %else522
                                        ;   in Loop: Header=BB0_99 Depth=2
	str	q16, [sp, #5008]                ; 16-byte Spill
	str	q4, [sp, #4880]                 ; 16-byte Spill
	add.2d	v3, v17, v26
	add.2d	v16, v17, v18
	add.2d	v17, v17, v27
	mov.d	x1, v17[1]
	fmov	x3, d17
	add	x3, x3, x3, lsl #1
	lsl	x3, x3, #4
	fmov	d17, x3
	add	x1, x1, x1, lsl #1
	lsl	x1, x1, #4
	mov.d	v17[1], x1
	mov.d	x1, v16[1]
	fmov	x3, d16
	add	x3, x3, x3, lsl #1
	lsl	x3, x3, #4
	fmov	d16, x3
	add	x1, x1, x1, lsl #1
	lsl	x1, x1, #4
	mov.d	v16[1], x1
	mov.d	x1, v3[1]
	fmov	x3, d3
	add	x3, x3, x3, lsl #1
	lsl	x3, x3, #4
	fmov	d3, x3
	sshll.2d	v21, v0, #0
	add	x1, x1, x1, lsl #1
	lsl	x1, x1, #4
	mov.d	v3[1], x1
	add.2d	v3, v3, v6
	add.2d	v16, v16, v6
	add.2d	v6, v17, v6
	ldr	q4, [sp, #4816]                 ; 16-byte Reload
	bit.16b	v4, v6, v11
	str	q4, [sp, #4816]                 ; 16-byte Spill
	ldr	q4, [sp, #4832]                 ; 16-byte Reload
	bit.16b	v4, v16, v21
	str	q4, [sp, #4832]                 ; 16-byte Spill
	ldr	q4, [sp, #4848]                 ; 16-byte Reload
	bit.16b	v4, v3, v8
	str	q4, [sp, #4848]                 ; 16-byte Spill
	add	x16, x16, #1
	add	x8, x8, #4
	cmp	x8, #3072
	b.eq	LBB0_117
LBB0_99:                                ; %direct.true854
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w1, w16, #0xffff
	mul	w1, w1, w27
	lsr	w1, w1, #21
	orr	w3, w1, #0x80
	dup.2d	v17, x3
	ldr	q3, [sp, #4912]                 ; 16-byte Reload
	add.2d	v3, v17, v3
	mov.d	x3, v3[1]
	fmov	x4, d3
	add	x4, x4, x4, lsl #1
	lsl	x4, x4, #4
	fmov	d3, x4
	sshll.2d	v4, v1, #0
	msub	w1, w1, w17, w16
	and	x1, x1, #0xffff
	add	x3, x3, x3, lsl #1
	lsl	x3, x3, #4
	mov.d	v3[1], x3
	dup.2d	v6, x1
	add.2d	v3, v3, v6
	ldr	q16, [sp, #4864]                ; 16-byte Reload
	bif.16b	v3, v16, v4
	movi.2d	v16, #0000000000000000
	cmp	x16, #47
	b.hi	LBB0_101
; %bb.100:                              ; %direct.true867
                                        ;   in Loop: Header=BB0_99 Depth=2
	fmov	x1, d3
	add	x1, x20, x1, lsl #2
	ld1r.4s	{ v16 }, [x1]
LBB0_101:                               ; %direct.schedule.83
                                        ;   in Loop: Header=BB0_99 Depth=2
	str	q3, [sp, #4864]                 ; 16-byte Spill
	fmov	w1, s2
	ldr	q4, [sp, #4880]                 ; 16-byte Reload
	bit.16b	v4, v16, v1
	dup.2d	v21, x8
	ldr	q3, [sp, #4800]                 ; 16-byte Reload
	ldr	q25, [sp, #4736]                ; 16-byte Reload
	add.2d	v3, v3, v25
	add.2d	v25, v3, v21
	tbz	w1, #0, LBB0_105
; %bb.102:                              ; %cond.store
                                        ;   in Loop: Header=BB0_99 Depth=2
	fmov	x3, d25
	str	s4, [x3]
	and	w1, w1, #0xff
	tbnz	w1, #1, LBB0_106
LBB0_103:                               ; %else510
                                        ;   in Loop: Header=BB0_99 Depth=2
	ldr	q3, [sp, #4784]                 ; 16-byte Reload
	ldr	q25, [sp, #4720]                ; 16-byte Reload
	add.2d	v3, v3, v25
	add.2d	v3, v3, v21
	tbz	w1, #2, LBB0_107
LBB0_104:                               ; %cond.store511
                                        ;   in Loop: Header=BB0_99 Depth=2
	fmov	x3, d3
	st1.s	{ v4 }[2], [x3]
	ldr	q25, [sp, #4544]                ; 16-byte Reload
	tbnz	w1, #3, LBB0_108
	b	LBB0_109
LBB0_105:                               ; %else
                                        ;   in Loop: Header=BB0_99 Depth=2
	and	w1, w1, #0xff
	tbz	w1, #1, LBB0_103
LBB0_106:                               ; %cond.store509
                                        ;   in Loop: Header=BB0_99 Depth=2
	mov.d	x3, v25[1]
	st1.s	{ v4 }[1], [x3]
	ldr	q3, [sp, #4784]                 ; 16-byte Reload
	ldr	q25, [sp, #4720]                ; 16-byte Reload
	add.2d	v3, v3, v25
	add.2d	v3, v3, v21
	tbnz	w1, #2, LBB0_104
LBB0_107:                               ; %else512
                                        ;   in Loop: Header=BB0_99 Depth=2
	ldr	q25, [sp, #4544]                ; 16-byte Reload
	tbz	w1, #3, LBB0_109
LBB0_108:                               ; %cond.store513
                                        ;   in Loop: Header=BB0_99 Depth=2
	mov.d	x3, v3[1]
	st1.s	{ v4 }[3], [x3]
LBB0_109:                               ; %else514
                                        ;   in Loop: Header=BB0_99 Depth=2
	ldr	q3, [sp, #5008]                 ; 16-byte Reload
	bif.16b	v16, v3, v0
	ldr	q3, [sp, #4768]                 ; 16-byte Reload
	ldr	q19, [sp, #4704]                ; 16-byte Reload
	add.2d	v3, v3, v19
	add.2d	v3, v3, v21
	tbz	w1, #4, LBB0_113
; %bb.110:                              ; %cond.store515
                                        ;   in Loop: Header=BB0_99 Depth=2
	fmov	x3, d3
	str	s16, [x3]
	tbnz	w1, #5, LBB0_114
LBB0_111:                               ; %else518
                                        ;   in Loop: Header=BB0_99 Depth=2
	ldr	q3, [sp, #4752]                 ; 16-byte Reload
	ldr	q19, [sp, #4688]                ; 16-byte Reload
	add.2d	v3, v3, v19
	add.2d	v3, v3, v21
	tbz	w1, #6, LBB0_115
LBB0_112:                               ; %cond.store519
                                        ;   in Loop: Header=BB0_99 Depth=2
	fmov	x3, d3
	st1.s	{ v16 }[2], [x3]
	tbz	w1, #7, LBB0_98
	b	LBB0_116
LBB0_113:                               ; %else516
                                        ;   in Loop: Header=BB0_99 Depth=2
	tbz	w1, #5, LBB0_111
LBB0_114:                               ; %cond.store517
                                        ;   in Loop: Header=BB0_99 Depth=2
	mov.d	x3, v3[1]
	st1.s	{ v16 }[1], [x3]
	ldr	q3, [sp, #4752]                 ; 16-byte Reload
	ldr	q19, [sp, #4688]                ; 16-byte Reload
	add.2d	v3, v3, v19
	add.2d	v3, v3, v21
	tbnz	w1, #6, LBB0_112
LBB0_115:                               ; %else520
                                        ;   in Loop: Header=BB0_99 Depth=2
	tbz	w1, #7, LBB0_98
LBB0_116:                               ; %cond.store521
                                        ;   in Loop: Header=BB0_99 Depth=2
	mov.d	x1, v3[1]
	st1.s	{ v16 }[3], [x1]
	b	LBB0_98
LBB0_117:                               ;   in Loop: Header=BB0_28 Depth=1
	str	q10, [sp, #288]                 ; 16-byte Spill
	ldr	q18, [sp, #3024]                ; 16-byte Reload
	ldr	q21, [sp, #3008]                ; 16-byte Reload
	ldr	q26, [sp, #2992]                ; 16-byte Reload
	ldr	q27, [sp, #2976]                ; 16-byte Reload
	ldr	q16, [sp, #4096]                ; 16-byte Reload
	ldr	q17, [sp, #4080]                ; 16-byte Reload
LBB0_118:                               ; %direct.schedule.9
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	sshll.2d	v2, v1, #0
	sshll.2d	v3, v0, #0
	ldr	q4, [sp, #2656]                 ; 16-byte Reload
	bit.16b	v27, v4, v11
	bit.16b	v21, v4, v8
	bit.16b	v26, v4, v3
	bit.16b	v18, v4, v2
	ldr	q4, [sp, #4224]                 ; 16-byte Reload
	bit.16b	v25, v4, v11
	ldr	q4, [sp, #4208]                 ; 16-byte Reload
	bit.16b	v16, v4, v8
	ldr	q4, [sp, #4192]                 ; 16-byte Reload
	bit.16b	v17, v4, v3
	ldr	q3, [sp, #4176]                 ; 16-byte Reload
	ldr	q4, [sp, #2960]                 ; 16-byte Reload
	bit.16b	v4, v3, v2
	b	LBB0_120
LBB0_119:                               ; %else580
                                        ;   in Loop: Header=BB0_120 Depth=2
	add	x8, x8, #4
	cmp	x8, #512
	b.eq	LBB0_136
LBB0_120:                               ; %direct.true272
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and.16b	v2, v31, v30
	addv.8h	h10, v2
	fmov	w16, s10
	dup.2d	v2, x8
	orr.16b	v3, v2, v4
	add.2d	v6, v18, v3
	tbz	w16, #0, LBB0_128
; %bb.121:                              ; %cond.store557
                                        ;   in Loop: Header=BB0_120 Depth=2
	fmov	x1, d6
	str	wzr, [x1]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_129
LBB0_122:                               ; %else562
                                        ;   in Loop: Header=BB0_120 Depth=2
	orr.16b	v3, v2, v16
	add.2d	v3, v21, v3
	tbz	w16, #2, LBB0_130
LBB0_123:                               ; %cond.store563
                                        ;   in Loop: Header=BB0_120 Depth=2
	fmov	x1, d3
	str	wzr, [x1]
	tbnz	w16, #3, LBB0_131
LBB0_124:                               ; %else568
                                        ;   in Loop: Header=BB0_120 Depth=2
	orr.16b	v3, v2, v17
	add.2d	v3, v26, v3
	tbz	w16, #4, LBB0_132
LBB0_125:                               ; %cond.store569
                                        ;   in Loop: Header=BB0_120 Depth=2
	fmov	x1, d3
	str	wzr, [x1]
	tbnz	w16, #5, LBB0_133
LBB0_126:                               ; %else574
                                        ;   in Loop: Header=BB0_120 Depth=2
	orr.16b	v2, v2, v25
	add.2d	v2, v27, v2
	tbz	w16, #6, LBB0_134
LBB0_127:                               ; %cond.store575
                                        ;   in Loop: Header=BB0_120 Depth=2
	fmov	x1, d2
	str	wzr, [x1]
	tbz	w16, #7, LBB0_119
	b	LBB0_135
LBB0_128:                               ; %else559
                                        ;   in Loop: Header=BB0_120 Depth=2
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_122
LBB0_129:                               ; %cond.store560
                                        ;   in Loop: Header=BB0_120 Depth=2
	mov.d	x1, v6[1]
	str	wzr, [x1]
	orr.16b	v3, v2, v16
	add.2d	v3, v21, v3
	tbnz	w16, #2, LBB0_123
LBB0_130:                               ; %else565
                                        ;   in Loop: Header=BB0_120 Depth=2
	tbz	w16, #3, LBB0_124
LBB0_131:                               ; %cond.store566
                                        ;   in Loop: Header=BB0_120 Depth=2
	mov.d	x1, v3[1]
	str	wzr, [x1]
	orr.16b	v3, v2, v17
	add.2d	v3, v26, v3
	tbnz	w16, #4, LBB0_125
LBB0_132:                               ; %else571
                                        ;   in Loop: Header=BB0_120 Depth=2
	tbz	w16, #5, LBB0_126
LBB0_133:                               ; %cond.store572
                                        ;   in Loop: Header=BB0_120 Depth=2
	mov.d	x1, v3[1]
	str	wzr, [x1]
	orr.16b	v2, v2, v25
	add.2d	v2, v27, v2
	tbnz	w16, #6, LBB0_127
LBB0_134:                               ; %else577
                                        ;   in Loop: Header=BB0_120 Depth=2
	tbz	w16, #7, LBB0_119
LBB0_135:                               ; %cond.store578
                                        ;   in Loop: Header=BB0_120 Depth=2
	mov.d	x16, v2[1]
	str	wzr, [x16]
	b	LBB0_119
LBB0_136:                               ; %direct.false273
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q17, [sp, #4080]                ; 16-byte Spill
	str	q16, [sp, #4096]                ; 16-byte Spill
	tbz	w26, #0, LBB0_139
; %bb.137:                              ; %mma.active
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	ldr	q2, [sp, #4672]                 ; 16-byte Reload
	fmov	x1, d2
	ldr	q2, [sp, #4608]                 ; 16-byte Reload
	fmov	x3, d2
	add	x1, x1, x3
	fmov	x3, d18
	fmov	x4, d4
	add	x3, x3, x4
	add	x4, x22, #19, lsl #12           ; =77824
LBB0_138:                               ; %mma.update.i
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	x20, x16, #0xe0
	and	x22, x8, #0x1e0
	add	x20, x23, x20, lsl #2
	add	x22, x1, x22, lsl #2
	ldp	q2, q3, [x20]
	ldp	q6, q16, [x22]
	fmul.4s	v2, v2, v6
	fmul.4s	v3, v3, v16
	fadd.4s	v2, v2, v3
	ldp	q3, q6, [x20, #32]
	ldp	q16, q17, [x22, #32]
	fmul.4s	v3, v3, v16
	fadd.4s	v2, v2, v3
	fmul.4s	v3, v6, v17
	fadd.4s	v2, v2, v3
	ldp	q3, q17, [x22, #64]
	ldp	q6, q16, [x20, #64]
	fmul.4s	v3, v6, v3
	fadd.4s	v2, v2, v3
	fmul.4s	v3, v16, v17
	fadd.4s	v2, v2, v3
	ldp	q6, q3, [x20, #96]
	ldp	q16, q17, [x22, #96]
	fmul.4s	v6, v6, v16
	ldr	s16, [x3], #4
	fadd.4s	v2, v2, v6
	fmul.4s	v3, v3, v17
	fadd.4s	v2, v2, v3
	dup.4s	v3, v2[1]
	fadd.4s	v3, v2, v3
	dup.4s	v6, v2[3]
	fadd.4s	v2, v2, v6
	dup.4s	v2, v2[2]
	fadd.4s	v2, v3, v2
	fadd	s2, s16, s2
	str	s2, [x4], #4
	add	x16, x16, #2
	add	x8, x8, #32
	cmp	x16, #256
	b.ne	LBB0_138
LBB0_139:                               ; %mma.continue
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	x23, [sp, #960]                 ; 8-byte Reload
	ldr	q30, [sp, #3056]                ; 16-byte Reload
	cbz	w28, LBB0_142
; %bb.140:                              ; %mma.active282
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	ldr	q2, [sp, #4672]                 ; 16-byte Reload
	mov.d	x1, v2[1]
	ldr	q2, [sp, #4608]                 ; 16-byte Reload
	mov.d	x3, v2[1]
	add	x1, x1, x3
	mov.d	x3, v18[1]
	mov.d	x4, v4[1]
	add	x3, x3, x4
	ldr	x4, [sp, #272]                  ; 8-byte Reload
LBB0_141:                               ; %mma.update.i588
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	x20, x16, #0xe0
	and	x22, x8, #0x1e0
	add	x20, x23, x20, lsl #2
	add	x22, x1, x22, lsl #2
	ldp	q2, q3, [x20]
	ldp	q6, q16, [x22]
	fmul.4s	v2, v2, v6
	fmul.4s	v3, v3, v16
	fadd.4s	v2, v2, v3
	ldp	q3, q6, [x20, #32]
	ldp	q16, q17, [x22, #32]
	fmul.4s	v3, v3, v16
	fadd.4s	v2, v2, v3
	fmul.4s	v3, v6, v17
	fadd.4s	v2, v2, v3
	ldp	q3, q17, [x22, #64]
	ldp	q6, q16, [x20, #64]
	fmul.4s	v3, v6, v3
	fadd.4s	v2, v2, v3
	fmul.4s	v3, v16, v17
	fadd.4s	v2, v2, v3
	ldp	q6, q3, [x20, #96]
	ldp	q16, q17, [x22, #96]
	fmul.4s	v6, v6, v16
	ldr	s16, [x3], #4
	fadd.4s	v2, v2, v6
	fmul.4s	v3, v3, v17
	fadd.4s	v2, v2, v3
	dup.4s	v3, v2[1]
	fadd.4s	v3, v2, v3
	dup.4s	v6, v2[3]
	fadd.4s	v2, v2, v6
	dup.4s	v2, v2[2]
	fadd.4s	v2, v3, v2
	fadd	s2, s16, s2
	str	s2, [x4], #4
	add	x16, x16, #2
	add	x8, x8, #32
	cmp	x16, #256
	b.ne	LBB0_141
LBB0_142:                               ; %mma.continue283
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	x23, [sp, #952]                 ; 8-byte Reload
	cbz	w30, LBB0_145
; %bb.143:                              ; %mma.active284
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	ldr	q2, [sp, #4656]                 ; 16-byte Reload
	fmov	x1, d2
	ldr	q2, [sp, #4592]                 ; 16-byte Reload
	fmov	x3, d2
	add	x1, x1, x3
	fmov	x3, d21
	ldr	q2, [sp, #4096]                 ; 16-byte Reload
	fmov	x4, d2
	add	x3, x3, x4
	ldr	x4, [sp, #264]                  ; 8-byte Reload
LBB0_144:                               ; %mma.update.i592
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	x20, x16, #0xe0
	and	x22, x8, #0x1e0
	add	x20, x23, x20, lsl #2
	add	x22, x1, x22, lsl #2
	ldp	q2, q3, [x20]
	ldp	q6, q16, [x22]
	fmul.4s	v2, v2, v6
	fmul.4s	v3, v3, v16
	fadd.4s	v2, v2, v3
	ldp	q3, q6, [x20, #32]
	ldp	q16, q17, [x22, #32]
	fmul.4s	v3, v3, v16
	fadd.4s	v2, v2, v3
	fmul.4s	v3, v6, v17
	fadd.4s	v2, v2, v3
	ldp	q3, q17, [x22, #64]
	ldp	q6, q16, [x20, #64]
	fmul.4s	v3, v6, v3
	fadd.4s	v2, v2, v3
	fmul.4s	v3, v16, v17
	fadd.4s	v2, v2, v3
	ldp	q6, q3, [x20, #96]
	ldp	q16, q17, [x22, #96]
	fmul.4s	v6, v6, v16
	ldr	s16, [x3], #4
	fadd.4s	v2, v2, v6
	fmul.4s	v3, v3, v17
	fadd.4s	v2, v2, v3
	dup.4s	v3, v2[1]
	fadd.4s	v3, v2, v3
	dup.4s	v6, v2[3]
	fadd.4s	v2, v2, v6
	dup.4s	v2, v2[2]
	fadd.4s	v2, v3, v2
	fadd	s2, s16, s2
	str	s2, [x4], #4
	add	x16, x16, #2
	add	x8, x8, #32
	cmp	x16, #256
	b.ne	LBB0_144
LBB0_145:                               ; %mma.continue285
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	w8, [sp, #4268]                 ; 4-byte Reload
	ldr	x23, [sp, #944]                 ; 8-byte Reload
	cbz	w8, LBB0_148
; %bb.146:                              ; %mma.active286
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	ldr	q2, [sp, #4656]                 ; 16-byte Reload
	mov.d	x1, v2[1]
	ldr	q2, [sp, #4592]                 ; 16-byte Reload
	mov.d	x3, v2[1]
	add	x1, x1, x3
	mov.d	x3, v21[1]
	ldr	q2, [sp, #4096]                 ; 16-byte Reload
	mov.d	x4, v2[1]
	add	x3, x3, x4
	ldr	x4, [sp, #256]                  ; 8-byte Reload
LBB0_147:                               ; %mma.update.i596
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	x20, x16, #0xe0
	and	x22, x8, #0x1e0
	add	x20, x23, x20, lsl #2
	add	x22, x1, x22, lsl #2
	ldp	q2, q3, [x20]
	ldp	q6, q16, [x22]
	fmul.4s	v2, v2, v6
	fmul.4s	v3, v3, v16
	fadd.4s	v2, v2, v3
	ldp	q3, q6, [x20, #32]
	ldp	q16, q17, [x22, #32]
	fmul.4s	v3, v3, v16
	fadd.4s	v2, v2, v3
	fmul.4s	v3, v6, v17
	fadd.4s	v2, v2, v3
	ldp	q3, q17, [x22, #64]
	ldp	q6, q16, [x20, #64]
	fmul.4s	v3, v6, v3
	fadd.4s	v2, v2, v3
	fmul.4s	v3, v16, v17
	fadd.4s	v2, v2, v3
	ldp	q6, q3, [x20, #96]
	ldp	q16, q17, [x22, #96]
	fmul.4s	v6, v6, v16
	ldr	s16, [x3], #4
	fadd.4s	v2, v2, v6
	fmul.4s	v3, v3, v17
	fadd.4s	v2, v2, v3
	dup.4s	v3, v2[1]
	fadd.4s	v3, v2, v3
	dup.4s	v6, v2[3]
	fadd.4s	v2, v2, v6
	dup.4s	v2, v2[2]
	fadd.4s	v2, v3, v2
	fadd	s2, s16, s2
	str	s2, [x4], #4
	add	x16, x16, #2
	add	x8, x8, #32
	cmp	x16, #256
	b.ne	LBB0_147
LBB0_148:                               ; %mma.continue287
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	w8, [sp, #4264]                 ; 4-byte Reload
	ldr	x23, [sp, #936]                 ; 8-byte Reload
	cbz	w8, LBB0_151
; %bb.149:                              ; %mma.active288
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	ldr	q2, [sp, #4640]                 ; 16-byte Reload
	fmov	x1, d2
	ldr	q2, [sp, #4576]                 ; 16-byte Reload
	fmov	x3, d2
	add	x1, x1, x3
	fmov	x3, d26
	ldr	q2, [sp, #4080]                 ; 16-byte Reload
	fmov	x4, d2
	add	x3, x3, x4
	ldr	x4, [sp, #248]                  ; 8-byte Reload
LBB0_150:                               ; %mma.update.i600
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	x20, x16, #0xe0
	and	x22, x8, #0x1e0
	add	x20, x23, x20, lsl #2
	add	x22, x1, x22, lsl #2
	ldp	q2, q3, [x20]
	ldp	q6, q16, [x22]
	fmul.4s	v2, v2, v6
	fmul.4s	v3, v3, v16
	fadd.4s	v2, v2, v3
	ldp	q3, q6, [x20, #32]
	ldp	q16, q17, [x22, #32]
	fmul.4s	v3, v3, v16
	fadd.4s	v2, v2, v3
	fmul.4s	v3, v6, v17
	fadd.4s	v2, v2, v3
	ldp	q3, q17, [x22, #64]
	ldp	q6, q16, [x20, #64]
	fmul.4s	v3, v6, v3
	fadd.4s	v2, v2, v3
	fmul.4s	v3, v16, v17
	fadd.4s	v2, v2, v3
	ldp	q6, q3, [x20, #96]
	ldp	q16, q17, [x22, #96]
	fmul.4s	v6, v6, v16
	ldr	s16, [x3], #4
	fadd.4s	v2, v2, v6
	fmul.4s	v3, v3, v17
	fadd.4s	v2, v2, v3
	dup.4s	v3, v2[1]
	fadd.4s	v3, v2, v3
	dup.4s	v6, v2[3]
	fadd.4s	v2, v2, v6
	dup.4s	v2, v2[2]
	fadd.4s	v2, v3, v2
	fadd	s2, s16, s2
	str	s2, [x4], #4
	add	x16, x16, #2
	add	x8, x8, #32
	cmp	x16, #256
	b.ne	LBB0_150
LBB0_151:                               ; %mma.continue289
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	w8, [sp, #4260]                 ; 4-byte Reload
	ldr	x23, [sp, #928]                 ; 8-byte Reload
	cbz	w8, LBB0_154
; %bb.152:                              ; %mma.active290
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	ldr	q2, [sp, #4640]                 ; 16-byte Reload
	mov.d	x1, v2[1]
	ldr	q2, [sp, #4576]                 ; 16-byte Reload
	mov.d	x3, v2[1]
	add	x1, x1, x3
	mov.d	x3, v26[1]
	ldr	q2, [sp, #4080]                 ; 16-byte Reload
	mov.d	x4, v2[1]
	add	x3, x3, x4
	ldr	x4, [sp, #240]                  ; 8-byte Reload
LBB0_153:                               ; %mma.update.i604
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	x20, x16, #0xe0
	and	x22, x8, #0x1e0
	add	x20, x23, x20, lsl #2
	add	x22, x1, x22, lsl #2
	ldp	q2, q3, [x20]
	ldp	q6, q16, [x22]
	fmul.4s	v2, v2, v6
	fmul.4s	v3, v3, v16
	fadd.4s	v2, v2, v3
	ldp	q3, q6, [x20, #32]
	ldp	q16, q17, [x22, #32]
	fmul.4s	v3, v3, v16
	fadd.4s	v2, v2, v3
	fmul.4s	v3, v6, v17
	fadd.4s	v2, v2, v3
	ldp	q3, q17, [x22, #64]
	ldp	q6, q16, [x20, #64]
	fmul.4s	v3, v6, v3
	fadd.4s	v2, v2, v3
	fmul.4s	v3, v16, v17
	fadd.4s	v2, v2, v3
	ldp	q6, q3, [x20, #96]
	ldp	q16, q17, [x22, #96]
	fmul.4s	v6, v6, v16
	ldr	s16, [x3], #4
	fadd.4s	v2, v2, v6
	fmul.4s	v3, v3, v17
	fadd.4s	v2, v2, v3
	dup.4s	v3, v2[1]
	fadd.4s	v3, v2, v3
	dup.4s	v6, v2[3]
	fadd.4s	v2, v2, v6
	dup.4s	v2, v2[2]
	fadd.4s	v2, v3, v2
	fadd	s2, s16, s2
	str	s2, [x4], #4
	add	x16, x16, #2
	add	x8, x8, #32
	cmp	x16, #256
	b.ne	LBB0_153
LBB0_154:                               ; %mma.continue291
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	w8, [sp, #4256]                 ; 4-byte Reload
	ldr	x23, [sp, #920]                 ; 8-byte Reload
	cbz	w8, LBB0_157
; %bb.155:                              ; %mma.active292
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	ldr	q2, [sp, #4624]                 ; 16-byte Reload
	fmov	x1, d2
	ldr	q2, [sp, #4560]                 ; 16-byte Reload
	fmov	x3, d2
	add	x1, x1, x3
	fmov	x3, d27
	fmov	x4, d25
	add	x3, x3, x4
	ldr	x4, [sp, #232]                  ; 8-byte Reload
LBB0_156:                               ; %mma.update.i608
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	x20, x16, #0xe0
	and	x22, x8, #0x1e0
	add	x20, x23, x20, lsl #2
	add	x22, x1, x22, lsl #2
	ldp	q2, q3, [x20]
	ldp	q6, q16, [x22]
	fmul.4s	v2, v2, v6
	fmul.4s	v3, v3, v16
	fadd.4s	v2, v2, v3
	ldp	q3, q6, [x20, #32]
	ldp	q16, q17, [x22, #32]
	fmul.4s	v3, v3, v16
	fadd.4s	v2, v2, v3
	fmul.4s	v3, v6, v17
	fadd.4s	v2, v2, v3
	ldp	q3, q17, [x22, #64]
	ldp	q6, q16, [x20, #64]
	fmul.4s	v3, v6, v3
	fadd.4s	v2, v2, v3
	fmul.4s	v3, v16, v17
	fadd.4s	v2, v2, v3
	ldp	q6, q3, [x20, #96]
	ldp	q16, q17, [x22, #96]
	fmul.4s	v6, v6, v16
	ldr	s16, [x3], #4
	fadd.4s	v2, v2, v6
	fmul.4s	v3, v3, v17
	fadd.4s	v2, v2, v3
	dup.4s	v3, v2[1]
	fadd.4s	v3, v2, v3
	dup.4s	v6, v2[3]
	fadd.4s	v2, v2, v6
	dup.4s	v2, v2[2]
	fadd.4s	v2, v3, v2
	fadd	s2, s16, s2
	str	s2, [x4], #4
	add	x16, x16, #2
	add	x8, x8, #32
	cmp	x16, #256
	b.ne	LBB0_156
LBB0_157:                               ; %mma.continue293
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	w8, [sp, #4252]                 ; 4-byte Reload
	ldr	x23, [sp, #912]                 ; 8-byte Reload
	cbz	w8, LBB0_160
; %bb.158:                              ; %mma.active294
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	ldr	q2, [sp, #4624]                 ; 16-byte Reload
	mov.d	x1, v2[1]
	ldr	q2, [sp, #4560]                 ; 16-byte Reload
	mov.d	x3, v2[1]
	add	x1, x1, x3
	mov.d	x3, v27[1]
	mov.d	x4, v25[1]
	add	x3, x3, x4
	ldr	x4, [sp, #224]                  ; 8-byte Reload
LBB0_159:                               ; %mma.update.i612
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	x20, x16, #0xe0
	and	x22, x8, #0x1e0
	add	x20, x23, x20, lsl #2
	add	x22, x1, x22, lsl #2
	ldp	q2, q3, [x20]
	ldp	q6, q16, [x22]
	fmul.4s	v2, v2, v6
	fmul.4s	v3, v3, v16
	fadd.4s	v2, v2, v3
	ldp	q3, q6, [x20, #32]
	ldp	q16, q17, [x22, #32]
	fmul.4s	v3, v3, v16
	fadd.4s	v2, v2, v3
	fmul.4s	v3, v6, v17
	fadd.4s	v2, v2, v3
	ldp	q3, q17, [x22, #64]
	ldp	q6, q16, [x20, #64]
	fmul.4s	v3, v6, v3
	fadd.4s	v2, v2, v3
	fmul.4s	v3, v16, v17
	fadd.4s	v2, v2, v3
	ldp	q6, q3, [x20, #96]
	ldp	q16, q17, [x22, #96]
	fmul.4s	v6, v6, v16
	ldr	s16, [x3], #4
	fadd.4s	v2, v2, v6
	fmul.4s	v3, v3, v17
	fadd.4s	v2, v2, v3
	dup.4s	v3, v2[1]
	fadd.4s	v3, v2, v3
	dup.4s	v6, v2[3]
	fadd.4s	v2, v2, v6
	dup.4s	v2, v2[2]
	fadd.4s	v2, v3, v2
	fadd	s2, s16, s2
	str	s2, [x4], #4
	add	x16, x16, #2
	add	x8, x8, #32
	cmp	x16, #256
	b.ne	LBB0_159
LBB0_160:                               ; %mma.continue295
                                        ;   in Loop: Header=BB0_28 Depth=1
	fmov	w8, s10
	mov	w1, #1                          ; =0x1
	tbz	w8, #0, LBB0_168
; %bb.161:                              ; %cond.store582
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q2, [sp, #304]                  ; 16-byte Reload
	fmov	x16, d2
	strb	w1, [x16]
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_169
LBB0_162:                               ; %else587
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #2, LBB0_170
LBB0_163:                               ; %cond.store588
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q2, [sp, #320]                  ; 16-byte Reload
	fmov	x16, d2
	strb	w1, [x16]
	tbnz	w8, #3, LBB0_171
LBB0_164:                               ; %else593
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #4, LBB0_172
LBB0_165:                               ; %cond.store594
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q2, [sp, #336]                  ; 16-byte Reload
	fmov	x16, d2
	strb	w1, [x16]
	tbnz	w8, #5, LBB0_173
LBB0_166:                               ; %else599
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #6, LBB0_174
LBB0_167:                               ; %cond.store600
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q2, [sp, #352]                  ; 16-byte Reload
	fmov	x16, d2
	strb	w1, [x16]
	tbnz	w8, #7, LBB0_175
	b	LBB0_176
LBB0_168:                               ; %else584
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_162
LBB0_169:                               ; %cond.store585
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q2, [sp, #304]                  ; 16-byte Reload
	mov.d	x16, v2[1]
	strb	w1, [x16]
	tbnz	w8, #2, LBB0_163
LBB0_170:                               ; %else590
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #3, LBB0_164
LBB0_171:                               ; %cond.store591
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q2, [sp, #320]                  ; 16-byte Reload
	mov.d	x16, v2[1]
	strb	w1, [x16]
	tbnz	w8, #4, LBB0_165
LBB0_172:                               ; %else596
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #5, LBB0_166
LBB0_173:                               ; %cond.store597
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q2, [sp, #336]                  ; 16-byte Reload
	mov.d	x16, v2[1]
	strb	w1, [x16]
	tbnz	w8, #6, LBB0_167
LBB0_174:                               ; %else602
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #7, LBB0_176
LBB0_175:                               ; %cond.store603
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q2, [sp, #352]                  ; 16-byte Reload
	mov.d	x8, v2[1]
	strb	w1, [x8]
LBB0_176:                               ; %else605
                                        ;   in Loop: Header=BB0_28 Depth=1
	orr	x16, x21, #0x1
	orr	x8, x21, #0x1
	str	x8, [sp, #3760]                 ; 8-byte Spill
	cmp	x16, #129
	cset	w16, lo
	fmov	w8, s10
	dup.8b	v2, w16
	tbz	w8, #0, LBB0_184
; %bb.177:                              ; %cond.store607
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2448]                 ; 16-byte Reload
	fmov	x16, d3
	str	b2, [x16]
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_185
LBB0_178:                               ; %else614
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #2, LBB0_186
LBB0_179:                               ; %cond.store615
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2464]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[2], [x16]
	tbnz	w8, #3, LBB0_187
LBB0_180:                               ; %else622
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #4, LBB0_188
LBB0_181:                               ; %cond.store623
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2480]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[4], [x16]
	tbnz	w8, #5, LBB0_189
LBB0_182:                               ; %else630
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #6, LBB0_190
LBB0_183:                               ; %cond.store631
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2496]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[6], [x16]
	tbnz	w8, #7, LBB0_191
	b	LBB0_192
LBB0_184:                               ; %else610
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_178
LBB0_185:                               ; %cond.store611
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2448]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[1], [x16]
	tbnz	w8, #2, LBB0_179
LBB0_186:                               ; %else618
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #3, LBB0_180
LBB0_187:                               ; %cond.store619
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2464]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[3], [x16]
	tbnz	w8, #4, LBB0_181
LBB0_188:                               ; %else626
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #5, LBB0_182
LBB0_189:                               ; %cond.store627
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2480]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[5], [x16]
	tbnz	w8, #6, LBB0_183
LBB0_190:                               ; %else634
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #7, LBB0_192
LBB0_191:                               ; %cond.store635
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2496]                 ; 16-byte Reload
	mov.d	x8, v3[1]
	st1.b	{ v2 }[7], [x8]
LBB0_192:                               ; %else638
                                        ;   in Loop: Header=BB0_28 Depth=1
	orr	x16, x21, #0x2
	orr	x8, x21, #0x2
	str	x8, [sp, #3744]                 ; 8-byte Spill
	cmp	x16, #129
	cset	w16, lo
	fmov	w8, s10
	dup.8b	v2, w16
	tbz	w8, #0, LBB0_200
; %bb.193:                              ; %cond.store640
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2384]                 ; 16-byte Reload
	fmov	x16, d3
	str	b2, [x16]
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_201
LBB0_194:                               ; %else647
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #2, LBB0_202
LBB0_195:                               ; %cond.store648
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2400]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[2], [x16]
	tbnz	w8, #3, LBB0_203
LBB0_196:                               ; %else655
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #4, LBB0_204
LBB0_197:                               ; %cond.store656
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2416]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[4], [x16]
	tbnz	w8, #5, LBB0_205
LBB0_198:                               ; %else663
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #6, LBB0_206
LBB0_199:                               ; %cond.store664
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2432]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[6], [x16]
	tbnz	w8, #7, LBB0_207
	b	LBB0_208
LBB0_200:                               ; %else643
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_194
LBB0_201:                               ; %cond.store644
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2384]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[1], [x16]
	tbnz	w8, #2, LBB0_195
LBB0_202:                               ; %else651
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #3, LBB0_196
LBB0_203:                               ; %cond.store652
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2400]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[3], [x16]
	tbnz	w8, #4, LBB0_197
LBB0_204:                               ; %else659
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #5, LBB0_198
LBB0_205:                               ; %cond.store660
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2416]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[5], [x16]
	tbnz	w8, #6, LBB0_199
LBB0_206:                               ; %else667
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #7, LBB0_208
LBB0_207:                               ; %cond.store668
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2432]                 ; 16-byte Reload
	mov.d	x8, v3[1]
	st1.b	{ v2 }[7], [x8]
LBB0_208:                               ; %else671
                                        ;   in Loop: Header=BB0_28 Depth=1
	orr	x16, x21, #0x3
	orr	x8, x21, #0x3
	str	x8, [sp, #3728]                 ; 8-byte Spill
	cmp	x16, #129
	cset	w16, lo
	fmov	w8, s10
	dup.8b	v2, w16
	tbz	w8, #0, LBB0_216
; %bb.209:                              ; %cond.store673
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2320]                 ; 16-byte Reload
	fmov	x16, d3
	str	b2, [x16]
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_217
LBB0_210:                               ; %else680
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #2, LBB0_218
LBB0_211:                               ; %cond.store681
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2336]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[2], [x16]
	tbnz	w8, #3, LBB0_219
LBB0_212:                               ; %else688
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #4, LBB0_220
LBB0_213:                               ; %cond.store689
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2352]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[4], [x16]
	tbnz	w8, #5, LBB0_221
LBB0_214:                               ; %else696
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #6, LBB0_222
LBB0_215:                               ; %cond.store697
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2368]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[6], [x16]
	tbnz	w8, #7, LBB0_223
	b	LBB0_224
LBB0_216:                               ; %else676
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_210
LBB0_217:                               ; %cond.store677
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2320]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[1], [x16]
	tbnz	w8, #2, LBB0_211
LBB0_218:                               ; %else684
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #3, LBB0_212
LBB0_219:                               ; %cond.store685
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2336]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[3], [x16]
	tbnz	w8, #4, LBB0_213
LBB0_220:                               ; %else692
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #5, LBB0_214
LBB0_221:                               ; %cond.store693
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2352]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[5], [x16]
	tbnz	w8, #6, LBB0_215
LBB0_222:                               ; %else700
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #7, LBB0_224
LBB0_223:                               ; %cond.store701
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2368]                 ; 16-byte Reload
	mov.d	x8, v3[1]
	st1.b	{ v2 }[7], [x8]
LBB0_224:                               ; %else704
                                        ;   in Loop: Header=BB0_28 Depth=1
	orr	x16, x21, #0x4
	orr	x8, x21, #0x4
	str	x8, [sp, #3712]                 ; 8-byte Spill
	cmp	x16, #129
	cset	w16, lo
	fmov	w8, s10
	dup.8b	v2, w16
	tbz	w8, #0, LBB0_232
; %bb.225:                              ; %cond.store706
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2256]                 ; 16-byte Reload
	fmov	x16, d3
	str	b2, [x16]
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_233
LBB0_226:                               ; %else713
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #2, LBB0_234
LBB0_227:                               ; %cond.store714
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2272]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[2], [x16]
	tbnz	w8, #3, LBB0_235
LBB0_228:                               ; %else721
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #4, LBB0_236
LBB0_229:                               ; %cond.store722
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2288]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[4], [x16]
	tbnz	w8, #5, LBB0_237
LBB0_230:                               ; %else729
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #6, LBB0_238
LBB0_231:                               ; %cond.store730
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2304]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[6], [x16]
	tbnz	w8, #7, LBB0_239
	b	LBB0_240
LBB0_232:                               ; %else709
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_226
LBB0_233:                               ; %cond.store710
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2256]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[1], [x16]
	tbnz	w8, #2, LBB0_227
LBB0_234:                               ; %else717
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #3, LBB0_228
LBB0_235:                               ; %cond.store718
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2272]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[3], [x16]
	tbnz	w8, #4, LBB0_229
LBB0_236:                               ; %else725
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #5, LBB0_230
LBB0_237:                               ; %cond.store726
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2288]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[5], [x16]
	tbnz	w8, #6, LBB0_231
LBB0_238:                               ; %else733
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #7, LBB0_240
LBB0_239:                               ; %cond.store734
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2304]                 ; 16-byte Reload
	mov.d	x8, v3[1]
	st1.b	{ v2 }[7], [x8]
LBB0_240:                               ; %else737
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	w8, #5                          ; =0x5
	orr	x8, x21, x8
	str	x8, [sp, #3696]                 ; 8-byte Spill
	cmp	x8, #129
	cset	w16, lo
	fmov	w8, s10
	dup.8b	v2, w16
	tbz	w8, #0, LBB0_272
; %bb.241:                              ; %cond.store739
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2192]                 ; 16-byte Reload
	fmov	x16, d3
	str	b2, [x16]
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_273
LBB0_242:                               ; %else746
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #2, LBB0_274
LBB0_243:                               ; %cond.store747
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2208]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[2], [x16]
	tbnz	w8, #3, LBB0_275
LBB0_244:                               ; %else754
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #4, LBB0_276
LBB0_245:                               ; %cond.store755
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2224]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[4], [x16]
	tbnz	w8, #5, LBB0_277
LBB0_246:                               ; %else762
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #6, LBB0_278
LBB0_247:                               ; %cond.store763
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2240]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[6], [x16]
	tbnz	w8, #7, LBB0_279
LBB0_248:                               ; %else770
                                        ;   in Loop: Header=BB0_28 Depth=1
	orr	x24, x21, #0x6
	cmp	x24, #129
	cset	w16, lo
	fmov	w8, s10
	dup.8b	v2, w16
	tbz	w8, #0, LBB0_280
LBB0_249:                               ; %cond.store772
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2112]                 ; 16-byte Reload
	fmov	x16, d3
	str	b2, [x16]
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_281
LBB0_250:                               ; %else779
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #2, LBB0_282
LBB0_251:                               ; %cond.store780
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2128]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[2], [x16]
	tbnz	w8, #3, LBB0_283
LBB0_252:                               ; %else787
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #4, LBB0_284
LBB0_253:                               ; %cond.store788
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2144]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[4], [x16]
	tbnz	w8, #5, LBB0_285
LBB0_254:                               ; %else795
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #6, LBB0_286
LBB0_255:                               ; %cond.store796
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2176]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[6], [x16]
	tbnz	w8, #7, LBB0_287
LBB0_256:                               ; %else803
                                        ;   in Loop: Header=BB0_28 Depth=1
	orr	x28, x21, #0x7
	cmp	x28, #129
	cset	w16, lo
	fmov	w8, s10
	dup.8b	v2, w16
	tbz	w8, #0, LBB0_288
LBB0_257:                               ; %cond.store805
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2048]                 ; 16-byte Reload
	fmov	x16, d3
	str	b2, [x16]
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_289
LBB0_258:                               ; %else812
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #2, LBB0_290
LBB0_259:                               ; %cond.store813
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2064]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[2], [x16]
	tbnz	w8, #3, LBB0_291
LBB0_260:                               ; %else820
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #4, LBB0_292
LBB0_261:                               ; %cond.store821
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2080]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[4], [x16]
	tbnz	w8, #5, LBB0_293
LBB0_262:                               ; %else828
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #6, LBB0_294
LBB0_263:                               ; %cond.store829
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2096]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[6], [x16]
	tbnz	w8, #7, LBB0_295
LBB0_264:                               ; %else836
                                        ;   in Loop: Header=BB0_28 Depth=1
	orr	x26, x21, #0x8
	cmp	x26, #129
	cset	w16, lo
	fmov	w8, s10
	dup.8b	v2, w16
	tbz	w8, #0, LBB0_296
LBB0_265:                               ; %cond.store838
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1984]                 ; 16-byte Reload
	fmov	x16, d3
	str	b2, [x16]
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_297
LBB0_266:                               ; %else845
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #2, LBB0_298
LBB0_267:                               ; %cond.store846
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2000]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[2], [x16]
	tbnz	w8, #3, LBB0_299
LBB0_268:                               ; %else853
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #4, LBB0_300
LBB0_269:                               ; %cond.store854
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2016]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[4], [x16]
	tbnz	w8, #5, LBB0_301
LBB0_270:                               ; %else861
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #6, LBB0_302
LBB0_271:                               ; %cond.store862
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2032]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[6], [x16]
	tbnz	w8, #7, LBB0_303
	b	LBB0_304
LBB0_272:                               ; %else742
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_242
LBB0_273:                               ; %cond.store743
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2192]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[1], [x16]
	tbnz	w8, #2, LBB0_243
LBB0_274:                               ; %else750
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #3, LBB0_244
LBB0_275:                               ; %cond.store751
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2208]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[3], [x16]
	tbnz	w8, #4, LBB0_245
LBB0_276:                               ; %else758
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #5, LBB0_246
LBB0_277:                               ; %cond.store759
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2224]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[5], [x16]
	tbnz	w8, #6, LBB0_247
LBB0_278:                               ; %else766
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #7, LBB0_248
LBB0_279:                               ; %cond.store767
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2240]                 ; 16-byte Reload
	mov.d	x8, v3[1]
	st1.b	{ v2 }[7], [x8]
	orr	x24, x21, #0x6
	cmp	x24, #129
	cset	w16, lo
	fmov	w8, s10
	dup.8b	v2, w16
	tbnz	w8, #0, LBB0_249
LBB0_280:                               ; %else775
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_250
LBB0_281:                               ; %cond.store776
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2112]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[1], [x16]
	tbnz	w8, #2, LBB0_251
LBB0_282:                               ; %else783
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #3, LBB0_252
LBB0_283:                               ; %cond.store784
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2128]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[3], [x16]
	tbnz	w8, #4, LBB0_253
LBB0_284:                               ; %else791
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #5, LBB0_254
LBB0_285:                               ; %cond.store792
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2144]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[5], [x16]
	tbnz	w8, #6, LBB0_255
LBB0_286:                               ; %else799
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #7, LBB0_256
LBB0_287:                               ; %cond.store800
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2176]                 ; 16-byte Reload
	mov.d	x8, v3[1]
	st1.b	{ v2 }[7], [x8]
	orr	x28, x21, #0x7
	cmp	x28, #129
	cset	w16, lo
	fmov	w8, s10
	dup.8b	v2, w16
	tbnz	w8, #0, LBB0_257
LBB0_288:                               ; %else808
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_258
LBB0_289:                               ; %cond.store809
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2048]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[1], [x16]
	tbnz	w8, #2, LBB0_259
LBB0_290:                               ; %else816
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #3, LBB0_260
LBB0_291:                               ; %cond.store817
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2064]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[3], [x16]
	tbnz	w8, #4, LBB0_261
LBB0_292:                               ; %else824
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #5, LBB0_262
LBB0_293:                               ; %cond.store825
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2080]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[5], [x16]
	tbnz	w8, #6, LBB0_263
LBB0_294:                               ; %else832
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #7, LBB0_264
LBB0_295:                               ; %cond.store833
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2096]                 ; 16-byte Reload
	mov.d	x8, v3[1]
	st1.b	{ v2 }[7], [x8]
	orr	x26, x21, #0x8
	cmp	x26, #129
	cset	w16, lo
	fmov	w8, s10
	dup.8b	v2, w16
	tbnz	w8, #0, LBB0_265
LBB0_296:                               ; %else841
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_266
LBB0_297:                               ; %cond.store842
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1984]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[1], [x16]
	tbnz	w8, #2, LBB0_267
LBB0_298:                               ; %else849
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #3, LBB0_268
LBB0_299:                               ; %cond.store850
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2000]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[3], [x16]
	tbnz	w8, #4, LBB0_269
LBB0_300:                               ; %else857
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #5, LBB0_270
LBB0_301:                               ; %cond.store858
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2016]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[5], [x16]
	tbnz	w8, #6, LBB0_271
LBB0_302:                               ; %else865
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w8, #7, LBB0_304
LBB0_303:                               ; %cond.store866
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2032]                 ; 16-byte Reload
	mov.d	x8, v3[1]
	st1.b	{ v2 }[7], [x8]
LBB0_304:                               ; %else869
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	w8, #9                          ; =0x9
	orr	x8, x21, x8
	cmp	x8, #129
	cset	w1, lo
	fmov	w16, s10
	dup.8b	v2, w1
	tbz	w16, #0, LBB0_312
; %bb.305:                              ; %cond.store871
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1920]                 ; 16-byte Reload
	fmov	x1, d3
	str	b2, [x1]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_313
LBB0_306:                               ; %else878
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #2, LBB0_314
LBB0_307:                               ; %cond.store879
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1936]                 ; 16-byte Reload
	fmov	x1, d3
	st1.b	{ v2 }[2], [x1]
	tbnz	w16, #3, LBB0_315
LBB0_308:                               ; %else886
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #4, LBB0_316
LBB0_309:                               ; %cond.store887
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1952]                 ; 16-byte Reload
	fmov	x1, d3
	st1.b	{ v2 }[4], [x1]
	tbnz	w16, #5, LBB0_317
LBB0_310:                               ; %else894
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #6, LBB0_318
LBB0_311:                               ; %cond.store895
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1968]                 ; 16-byte Reload
	fmov	x1, d3
	st1.b	{ v2 }[6], [x1]
	tbnz	w16, #7, LBB0_319
	b	LBB0_320
LBB0_312:                               ; %else874
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_306
LBB0_313:                               ; %cond.store875
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1920]                 ; 16-byte Reload
	mov.d	x1, v3[1]
	st1.b	{ v2 }[1], [x1]
	tbnz	w16, #2, LBB0_307
LBB0_314:                               ; %else882
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #3, LBB0_308
LBB0_315:                               ; %cond.store883
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1936]                 ; 16-byte Reload
	mov.d	x1, v3[1]
	st1.b	{ v2 }[3], [x1]
	tbnz	w16, #4, LBB0_309
LBB0_316:                               ; %else890
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #5, LBB0_310
LBB0_317:                               ; %cond.store891
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1952]                 ; 16-byte Reload
	mov.d	x1, v3[1]
	st1.b	{ v2 }[5], [x1]
	tbnz	w16, #6, LBB0_311
LBB0_318:                               ; %else898
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #7, LBB0_320
LBB0_319:                               ; %cond.store899
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1968]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[7], [x16]
LBB0_320:                               ; %else902
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	w16, #10                        ; =0xa
	orr	x20, x21, x16
	cmp	x20, #129
	cset	w1, lo
	fmov	w16, s10
	dup.8b	v2, w1
	tbz	w16, #0, LBB0_328
; %bb.321:                              ; %cond.store904
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1856]                 ; 16-byte Reload
	fmov	x1, d3
	str	b2, [x1]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_329
LBB0_322:                               ; %else911
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #2, LBB0_330
LBB0_323:                               ; %cond.store912
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1872]                 ; 16-byte Reload
	fmov	x1, d3
	st1.b	{ v2 }[2], [x1]
	tbnz	w16, #3, LBB0_331
LBB0_324:                               ; %else919
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #4, LBB0_332
LBB0_325:                               ; %cond.store920
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1888]                 ; 16-byte Reload
	fmov	x1, d3
	st1.b	{ v2 }[4], [x1]
	tbnz	w16, #5, LBB0_333
LBB0_326:                               ; %else927
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #6, LBB0_334
LBB0_327:                               ; %cond.store928
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1904]                 ; 16-byte Reload
	fmov	x1, d3
	st1.b	{ v2 }[6], [x1]
	tbnz	w16, #7, LBB0_335
	b	LBB0_336
LBB0_328:                               ; %else907
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_322
LBB0_329:                               ; %cond.store908
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1856]                 ; 16-byte Reload
	mov.d	x1, v3[1]
	st1.b	{ v2 }[1], [x1]
	tbnz	w16, #2, LBB0_323
LBB0_330:                               ; %else915
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #3, LBB0_324
LBB0_331:                               ; %cond.store916
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1872]                 ; 16-byte Reload
	mov.d	x1, v3[1]
	st1.b	{ v2 }[3], [x1]
	tbnz	w16, #4, LBB0_325
LBB0_332:                               ; %else923
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #5, LBB0_326
LBB0_333:                               ; %cond.store924
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1888]                 ; 16-byte Reload
	mov.d	x1, v3[1]
	st1.b	{ v2 }[5], [x1]
	tbnz	w16, #6, LBB0_327
LBB0_334:                               ; %else931
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #7, LBB0_336
LBB0_335:                               ; %cond.store932
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1904]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[7], [x16]
LBB0_336:                               ; %else935
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	w16, #11                        ; =0xb
	orr	x16, x21, x16
	cmp	x16, #129
	cset	w3, lo
	fmov	w1, s10
	dup.8b	v2, w3
	tbz	w1, #0, LBB0_352
; %bb.337:                              ; %cond.store937
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1792]                 ; 16-byte Reload
	fmov	x3, d3
	str	b2, [x3]
	and	w1, w1, #0xff
	tbnz	w1, #1, LBB0_353
LBB0_338:                               ; %else944
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w1, #2, LBB0_354
LBB0_339:                               ; %cond.store945
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1808]                 ; 16-byte Reload
	fmov	x3, d3
	st1.b	{ v2 }[2], [x3]
	tbnz	w1, #3, LBB0_355
LBB0_340:                               ; %else952
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w1, #4, LBB0_356
LBB0_341:                               ; %cond.store953
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1824]                 ; 16-byte Reload
	fmov	x3, d3
	st1.b	{ v2 }[4], [x3]
	tbnz	w1, #5, LBB0_357
LBB0_342:                               ; %else960
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w1, #6, LBB0_358
LBB0_343:                               ; %cond.store961
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1840]                 ; 16-byte Reload
	fmov	x3, d3
	st1.b	{ v2 }[6], [x3]
	tbnz	w1, #7, LBB0_359
LBB0_344:                               ; %else968
                                        ;   in Loop: Header=BB0_28 Depth=1
	orr	x22, x21, #0xc
	cmp	x22, #129
	cset	w3, lo
	fmov	w1, s10
	dup.8b	v2, w3
	tbz	w1, #0, LBB0_360
LBB0_345:                               ; %cond.store970
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1728]                 ; 16-byte Reload
	fmov	x3, d3
	str	b2, [x3]
	and	w1, w1, #0xff
	tbnz	w1, #1, LBB0_361
LBB0_346:                               ; %else977
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w1, #2, LBB0_362
LBB0_347:                               ; %cond.store978
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1744]                 ; 16-byte Reload
	fmov	x3, d3
	st1.b	{ v2 }[2], [x3]
	tbnz	w1, #3, LBB0_363
LBB0_348:                               ; %else985
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w1, #4, LBB0_364
LBB0_349:                               ; %cond.store986
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1760]                 ; 16-byte Reload
	fmov	x3, d3
	st1.b	{ v2 }[4], [x3]
	tbnz	w1, #5, LBB0_365
LBB0_350:                               ; %else993
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w1, #6, LBB0_366
LBB0_351:                               ; %cond.store994
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1776]                 ; 16-byte Reload
	fmov	x3, d3
	st1.b	{ v2 }[6], [x3]
	tbnz	w1, #7, LBB0_367
	b	LBB0_368
LBB0_352:                               ; %else940
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w1, w1, #0xff
	tbz	w1, #1, LBB0_338
LBB0_353:                               ; %cond.store941
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1792]                 ; 16-byte Reload
	mov.d	x3, v3[1]
	st1.b	{ v2 }[1], [x3]
	tbnz	w1, #2, LBB0_339
LBB0_354:                               ; %else948
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w1, #3, LBB0_340
LBB0_355:                               ; %cond.store949
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1808]                 ; 16-byte Reload
	mov.d	x3, v3[1]
	st1.b	{ v2 }[3], [x3]
	tbnz	w1, #4, LBB0_341
LBB0_356:                               ; %else956
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w1, #5, LBB0_342
LBB0_357:                               ; %cond.store957
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1824]                 ; 16-byte Reload
	mov.d	x3, v3[1]
	st1.b	{ v2 }[5], [x3]
	tbnz	w1, #6, LBB0_343
LBB0_358:                               ; %else964
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w1, #7, LBB0_344
LBB0_359:                               ; %cond.store965
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1840]                 ; 16-byte Reload
	mov.d	x1, v3[1]
	st1.b	{ v2 }[7], [x1]
	orr	x22, x21, #0xc
	cmp	x22, #129
	cset	w3, lo
	fmov	w1, s10
	dup.8b	v2, w3
	tbnz	w1, #0, LBB0_345
LBB0_360:                               ; %else973
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w1, w1, #0xff
	tbz	w1, #1, LBB0_346
LBB0_361:                               ; %cond.store974
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1728]                 ; 16-byte Reload
	mov.d	x3, v3[1]
	st1.b	{ v2 }[1], [x3]
	tbnz	w1, #2, LBB0_347
LBB0_362:                               ; %else981
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w1, #3, LBB0_348
LBB0_363:                               ; %cond.store982
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1744]                 ; 16-byte Reload
	mov.d	x3, v3[1]
	st1.b	{ v2 }[3], [x3]
	tbnz	w1, #4, LBB0_349
LBB0_364:                               ; %else989
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w1, #5, LBB0_350
LBB0_365:                               ; %cond.store990
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1760]                 ; 16-byte Reload
	mov.d	x3, v3[1]
	st1.b	{ v2 }[5], [x3]
	tbnz	w1, #6, LBB0_351
LBB0_366:                               ; %else997
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w1, #7, LBB0_368
LBB0_367:                               ; %cond.store998
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1776]                 ; 16-byte Reload
	mov.d	x1, v3[1]
	st1.b	{ v2 }[7], [x1]
LBB0_368:                               ; %else1001
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	w1, #13                         ; =0xd
	orr	x23, x21, x1
	cmp	x23, #129
	cset	w3, lo
	fmov	w1, s10
	dup.8b	v2, w3
	tbz	w1, #0, LBB0_428
; %bb.369:                              ; %cond.store1003
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1664]                 ; 16-byte Reload
	fmov	x3, d3
	str	b2, [x3]
	and	w1, w1, #0xff
	tbnz	w1, #1, LBB0_429
LBB0_370:                               ; %else1010
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w1, #2, LBB0_430
LBB0_371:                               ; %cond.store1011
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1680]                 ; 16-byte Reload
	fmov	x3, d3
	st1.b	{ v2 }[2], [x3]
	tbnz	w1, #3, LBB0_431
LBB0_372:                               ; %else1018
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w1, #4, LBB0_432
LBB0_373:                               ; %cond.store1019
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1696]                 ; 16-byte Reload
	fmov	x3, d3
	st1.b	{ v2 }[4], [x3]
	tbnz	w1, #5, LBB0_433
LBB0_374:                               ; %else1026
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w1, #6, LBB0_434
LBB0_375:                               ; %cond.store1027
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1712]                 ; 16-byte Reload
	fmov	x3, d3
	st1.b	{ v2 }[6], [x3]
	tbnz	w1, #7, LBB0_435
LBB0_376:                               ; %else1034
                                        ;   in Loop: Header=BB0_28 Depth=1
	orr	x25, x21, #0xe
	cmp	x25, #129
	cset	w3, lo
	fmov	w1, s10
	dup.8b	v2, w3
	tbz	w1, #0, LBB0_436
LBB0_377:                               ; %cond.store1036
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1600]                 ; 16-byte Reload
	fmov	x3, d3
	str	b2, [x3]
	and	w1, w1, #0xff
	tbnz	w1, #1, LBB0_437
LBB0_378:                               ; %else1043
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w1, #2, LBB0_438
LBB0_379:                               ; %cond.store1044
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1616]                 ; 16-byte Reload
	fmov	x3, d3
	st1.b	{ v2 }[2], [x3]
	tbnz	w1, #3, LBB0_439
LBB0_380:                               ; %else1051
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w1, #4, LBB0_440
LBB0_381:                               ; %cond.store1052
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1632]                 ; 16-byte Reload
	fmov	x3, d3
	st1.b	{ v2 }[4], [x3]
	tbnz	w1, #5, LBB0_441
LBB0_382:                               ; %else1059
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w1, #6, LBB0_442
LBB0_383:                               ; %cond.store1060
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1648]                 ; 16-byte Reload
	fmov	x3, d3
	st1.b	{ v2 }[6], [x3]
	tbnz	w1, #7, LBB0_443
LBB0_384:                               ; %else1067
                                        ;   in Loop: Header=BB0_28 Depth=1
	orr	x4, x21, #0xf
	cmp	x4, #129
	cset	w3, lo
	fmov	w1, s10
	dup.8b	v2, w3
	tbz	w1, #0, LBB0_444
LBB0_385:                               ; %cond.store1069
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1536]                 ; 16-byte Reload
	fmov	x3, d3
	str	b2, [x3]
	and	w1, w1, #0xff
	tbnz	w1, #1, LBB0_445
LBB0_386:                               ; %else1076
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w1, #2, LBB0_446
LBB0_387:                               ; %cond.store1077
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1552]                 ; 16-byte Reload
	fmov	x3, d3
	st1.b	{ v2 }[2], [x3]
	tbnz	w1, #3, LBB0_447
LBB0_388:                               ; %else1084
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x27, x10
	tbz	w1, #4, LBB0_448
LBB0_389:                               ; %cond.store1085
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1568]                 ; 16-byte Reload
	fmov	x3, d3
	st1.b	{ v2 }[4], [x3]
	mov	x10, x19
	tbnz	w1, #5, LBB0_449
LBB0_390:                               ; %else1092
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x19, x7
	tbz	w1, #6, LBB0_392
LBB0_391:                               ; %cond.store1093
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1584]                 ; 16-byte Reload
	fmov	x3, d3
	st1.b	{ v2 }[6], [x3]
LBB0_392:                               ; %else1096
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q25, [sp, #4544]                ; 16-byte Spill
	str	q4, [sp, #2960]                 ; 16-byte Spill
	str	q27, [sp, #2976]                ; 16-byte Spill
	str	q26, [sp, #2992]                ; 16-byte Spill
	str	q21, [sp, #3008]                ; 16-byte Spill
	str	q18, [sp, #3024]                ; 16-byte Spill
	mov	x7, x5
	sshll.2d	v17, v1, #0
	sshll.2d	v21, v0, #0
	sshll.2d	v6, v1, #0
	sshll.2d	v16, v0, #0
	tbz	w1, #7, LBB0_394
; %bb.393:                              ; %cond.store1097
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1584]                 ; 16-byte Reload
	mov.d	x1, v3[1]
	st1.b	{ v2 }[7], [x1]
LBB0_394:                               ; %else1100
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x21, #0                         ; =0x0
	mov	x1, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	ldr	x5, [sp, #904]                  ; 8-byte Reload
	ldp	q25, q3, [x5, #32]
	sshll.2d	v2, v0, #0
	ldr	q19, [sp, #3776]                ; 16-byte Reload
	bit.16b	v25, v19, v2
	bit.16b	v3, v19, v11
	stp	q25, q3, [x5, #32]
	ldr	q4, [sp, #2640]                 ; 16-byte Reload
	ldr	q3, [sp, #5104]                 ; 16-byte Reload
	bit.16b	v3, v4, v21
	str	q3, [sp, #5104]                 ; 16-byte Spill
	ldr	q3, [sp, #5136]                 ; 16-byte Reload
	bit.16b	v3, v4, v17
	str	q3, [sp, #5136]                 ; 16-byte Spill
	ldr	q3, [sp, #4192]                 ; 16-byte Reload
	ldr	q18, [sp, #5040]                ; 16-byte Reload
	bit.16b	v18, v3, v21
	str	q18, [sp, #5040]                ; 16-byte Spill
	ldr	q3, [sp, #4176]                 ; 16-byte Reload
	ldr	q18, [sp, #5072]                ; 16-byte Reload
	bit.16b	v18, v3, v17
	str	q18, [sp, #5072]                ; 16-byte Spill
	sshll.2d	v17, v1, #0
	ldp	q21, q3, [x5]
	bit.16b	v21, v19, v17
	bit.16b	v3, v19, v8
	ldr	x30, [sp, #3760]                ; 8-byte Reload
	dup.2d	v25, x30
	ldr	q18, [sp, #2720]                ; 16-byte Reload
	ldr	q19, [sp, #5232]                ; 16-byte Reload
	bit.16b	v19, v18, v16
	str	q19, [sp, #5232]                ; 16-byte Spill
	ldr	q19, [sp, #5264]                ; 16-byte Reload
	bit.16b	v19, v18, v6
	str	q19, [sp, #5264]                ; 16-byte Spill
	stp	q21, q3, [x5]
	ldr	q3, [sp, #544]                  ; 16-byte Reload
	ldr	q19, [sp, #5168]                ; 16-byte Reload
	bit.16b	v19, v3, v16
	str	q19, [sp, #5168]                ; 16-byte Spill
	ldr	q3, [sp, #512]                  ; 16-byte Reload
	ldr	q16, [sp, #5200]                ; 16-byte Reload
	bit.16b	v16, v3, v6
	str	q16, [sp, #5200]                ; 16-byte Spill
	ldr	x5, [sp, #896]                  ; 8-byte Reload
	ldp	q6, q3, [x5, #32]
	ldp	q21, q16, [x5]
	bit.16b	v21, v25, v17
	bit.16b	v6, v25, v2
	bit.16b	v16, v25, v8
	bit.16b	v3, v25, v11
	ldr	x30, [sp, #3744]                ; 8-byte Reload
	dup.2d	v25, x30
	stp	q6, q3, [x5, #32]
	stp	q21, q16, [x5]
	ldr	x5, [sp, #888]                  ; 8-byte Reload
	ldp	q6, q3, [x5, #32]
	ldp	q21, q16, [x5]
	bit.16b	v21, v25, v17
	bit.16b	v6, v25, v2
	bit.16b	v16, v25, v8
	bit.16b	v3, v25, v11
	ldr	x30, [sp, #3728]                ; 8-byte Reload
	dup.2d	v25, x30
	stp	q6, q3, [x5, #32]
	stp	q21, q16, [x5]
	ldr	x5, [sp, #880]                  ; 8-byte Reload
	ldp	q6, q3, [x5, #32]
	ldp	q21, q16, [x5]
	bit.16b	v21, v25, v17
	bit.16b	v6, v25, v2
	bit.16b	v16, v25, v8
	bit.16b	v3, v25, v11
	stp	q6, q3, [x5, #32]
	stp	q21, q16, [x5]
	ldr	x5, [sp, #3712]                 ; 8-byte Reload
	dup.2d	v3, x5
	ldr	x5, [sp, #872]                  ; 8-byte Reload
	ldp	q16, q6, [x5, #32]
	ldp	q25, q21, [x5]
	bit.16b	v25, v3, v17
	bit.16b	v16, v3, v2
	bit.16b	v21, v3, v8
	bif.16b	v3, v6, v11
	stp	q16, q3, [x5, #32]
	stp	q25, q21, [x5]
	ldr	x5, [sp, #3696]                 ; 8-byte Reload
	dup.2d	v3, x5
	ldr	x5, [sp, #864]                  ; 8-byte Reload
	ldp	q16, q6, [x5, #32]
	ldp	q25, q21, [x5]
	bit.16b	v25, v3, v17
	bit.16b	v16, v3, v2
	bit.16b	v21, v3, v8
	bif.16b	v3, v6, v11
	stp	q16, q3, [x5, #32]
	stp	q25, q21, [x5]
	dup.2d	v3, x24
	ldr	x5, [sp, #856]                  ; 8-byte Reload
	ldp	q16, q6, [x5, #32]
	ldp	q25, q21, [x5]
	bit.16b	v25, v3, v17
	bit.16b	v16, v3, v2
	bit.16b	v21, v3, v8
	bif.16b	v3, v6, v11
	stp	q16, q3, [x5, #32]
	stp	q25, q21, [x5]
	dup.2d	v3, x28
	ldr	x5, [sp, #848]                  ; 8-byte Reload
	ldp	q16, q6, [x5, #32]
	ldp	q25, q21, [x5]
	bit.16b	v25, v3, v17
	bit.16b	v16, v3, v2
	bit.16b	v21, v3, v8
	bif.16b	v3, v6, v11
	stp	q16, q3, [x5, #32]
	stp	q25, q21, [x5]
	dup.2d	v3, x26
	ldr	x5, [sp, #840]                  ; 8-byte Reload
	ldp	q16, q6, [x5, #32]
	ldp	q25, q21, [x5]
	bit.16b	v25, v3, v17
	bit.16b	v16, v3, v2
	bit.16b	v21, v3, v8
	bif.16b	v3, v6, v11
	stp	q16, q3, [x5, #32]
	stp	q25, q21, [x5]
	dup.2d	v3, x8
	ldr	x8, [sp, #832]                  ; 8-byte Reload
	ldp	q16, q6, [x8, #32]
	ldp	q25, q21, [x8]
	bit.16b	v25, v3, v17
	bit.16b	v21, v3, v8
	bit.16b	v16, v3, v2
	bif.16b	v3, v6, v11
	stp	q16, q3, [x8, #32]
	stp	q25, q21, [x8]
	dup.2d	v3, x20
	ldr	x8, [sp, #824]                  ; 8-byte Reload
	ldp	q6, q16, [x8, #32]
	ldp	q21, q25, [x8]
	bit.16b	v25, v3, v8
	bit.16b	v21, v3, v17
	bit.16b	v16, v3, v11
	bif.16b	v3, v6, v2
	stp	q3, q16, [x8, #32]
	stp	q21, q25, [x8]
	dup.2d	v3, x16
	ldr	x8, [sp, #816]                  ; 8-byte Reload
	ldp	q6, q16, [x8, #32]
	ldp	q21, q25, [x8]
	bit.16b	v25, v3, v8
	bit.16b	v21, v3, v17
	bit.16b	v16, v3, v11
	bif.16b	v3, v6, v2
	stp	q3, q16, [x8, #32]
	stp	q21, q25, [x8]
	dup.2d	v3, x22
	ldr	x8, [sp, #808]                  ; 8-byte Reload
	ldp	q16, q6, [x8, #32]
	ldp	q25, q21, [x8]
	bit.16b	v25, v3, v17
	bit.16b	v21, v3, v8
	bit.16b	v16, v3, v2
	bif.16b	v3, v6, v11
	stp	q16, q3, [x8, #32]
	stp	q25, q21, [x8]
	dup.2d	v3, x23
	ldr	x8, [sp, #800]                  ; 8-byte Reload
	ldp	q16, q6, [x8, #32]
	ldp	q25, q21, [x8]
	bit.16b	v25, v3, v17
	bit.16b	v21, v3, v8
	bit.16b	v16, v3, v2
	bif.16b	v3, v6, v11
	stp	q16, q3, [x8, #32]
	stp	q25, q21, [x8]
	dup.2d	v3, x25
	ldr	x8, [sp, #792]                  ; 8-byte Reload
	ldp	q16, q6, [x8, #32]
	ldp	q25, q21, [x8]
	bit.16b	v25, v3, v17
	bit.16b	v21, v3, v8
	bit.16b	v16, v3, v2
	bif.16b	v3, v6, v11
	stp	q16, q3, [x8, #32]
	stp	q25, q21, [x8]
	dup.2d	v3, x4
	ldr	x8, [sp, #784]                  ; 8-byte Reload
	ldp	q16, q6, [x8, #32]
	ldp	q25, q21, [x8]
	bit.16b	v25, v3, v17
	bit.16b	v21, v3, v8
	bit.16b	v16, v3, v2
	bif.16b	v3, v6, v11
	stp	q16, q3, [x8, #32]
	stp	q25, q21, [x8]
	ldr	x8, [sp, #776]                  ; 8-byte Reload
	ldp	q6, q3, [x8, #32]
	ldr	q16, [sp, #1520]                ; 16-byte Reload
	bit.16b	v6, v16, v2
	ldr	q16, [sp, #1472]                ; 16-byte Reload
	bit.16b	v3, v16, v11
	stp	q6, q3, [x8, #32]
	ldp	q16, q3, [x8]
	ldr	q19, [sp, #1488]                ; 16-byte Reload
	bit.16b	v16, v19, v17
	ldr	q19, [sp, #1504]                ; 16-byte Reload
	bit.16b	v3, v19, v8
	stp	q16, q3, [x8]
	ldr	x8, [sp, #768]                  ; 8-byte Reload
	ldp	q6, q3, [x8, #32]
	ldr	q16, [sp, #1456]                ; 16-byte Reload
	bit.16b	v6, v16, v2
	ldr	q16, [sp, #1408]                ; 16-byte Reload
	bit.16b	v3, v16, v11
	stp	q6, q3, [x8, #32]
	ldp	q16, q3, [x8]
	ldr	q19, [sp, #1424]                ; 16-byte Reload
	bit.16b	v16, v19, v17
	ldr	q19, [sp, #1440]                ; 16-byte Reload
	bit.16b	v3, v19, v8
	stp	q16, q3, [x8]
	ldr	x8, [sp, #760]                  ; 8-byte Reload
	ldp	q6, q3, [x8, #32]
	ldr	q16, [sp, #1392]                ; 16-byte Reload
	bit.16b	v6, v16, v2
	ldr	q16, [sp, #1344]                ; 16-byte Reload
	bit.16b	v3, v16, v11
	stp	q6, q3, [x8, #32]
	ldp	q16, q3, [x8]
	ldr	q19, [sp, #1360]                ; 16-byte Reload
	bit.16b	v16, v19, v17
	ldr	q19, [sp, #1376]                ; 16-byte Reload
	bit.16b	v3, v19, v8
	stp	q16, q3, [x8]
	ldr	x8, [sp, #752]                  ; 8-byte Reload
	ldp	q6, q3, [x8, #32]
	ldr	q16, [sp, #1328]                ; 16-byte Reload
	bit.16b	v6, v16, v2
	ldr	q16, [sp, #1280]                ; 16-byte Reload
	bit.16b	v3, v16, v11
	stp	q6, q3, [x8, #32]
	ldp	q16, q3, [x8]
	ldr	q19, [sp, #1296]                ; 16-byte Reload
	bit.16b	v16, v19, v17
	ldr	q19, [sp, #1312]                ; 16-byte Reload
	bit.16b	v3, v19, v8
	stp	q16, q3, [x8]
	ldr	x8, [sp, #744]                  ; 8-byte Reload
	ldp	q6, q3, [x8, #32]
	ldr	q16, [sp, #1264]                ; 16-byte Reload
	bit.16b	v6, v16, v2
	ldr	q16, [sp, #1216]                ; 16-byte Reload
	bit.16b	v3, v16, v11
	stp	q6, q3, [x8, #32]
	ldp	q16, q3, [x8]
	ldr	q19, [sp, #1232]                ; 16-byte Reload
	bit.16b	v16, v19, v17
	ldr	q19, [sp, #1248]                ; 16-byte Reload
	bit.16b	v3, v19, v8
	stp	q16, q3, [x8]
	ldr	x8, [sp, #736]                  ; 8-byte Reload
	ldp	q6, q3, [x8, #32]
	ldr	q16, [sp, #1200]                ; 16-byte Reload
	bit.16b	v6, v16, v2
	ldr	q16, [sp, #1152]                ; 16-byte Reload
	bit.16b	v3, v16, v11
	stp	q6, q3, [x8, #32]
	ldp	q16, q3, [x8]
	ldr	q19, [sp, #1168]                ; 16-byte Reload
	bit.16b	v16, v19, v17
	ldr	q19, [sp, #1184]                ; 16-byte Reload
	bit.16b	v3, v19, v8
	stp	q16, q3, [x8]
	ldr	x16, [sp, #728]                 ; 8-byte Reload
	ldr	q3, [x16]
	ldr	q6, [sp, #1104]                 ; 16-byte Reload
	bit.16b	v3, v6, v17
	ldr	q6, [x16, #32]
	ldr	q19, [sp, #1136]                ; 16-byte Reload
	bit.16b	v6, v19, v2
	ldr	x8, [sp, #720]                  ; 8-byte Reload
	ldr	q16, [x8, #32]
	ldr	q19, [sp, #1072]                ; 16-byte Reload
	bit.16b	v16, v19, v2
	ldr	q19, [sp, #2608]                ; 16-byte Reload
	ldr	q21, [sp, #5712]                ; 16-byte Reload
	bit.16b	v21, v19, v2
	str	q21, [sp, #5712]                ; 16-byte Spill
	ldr	q21, [sp, #384]                 ; 16-byte Reload
	ldr	q25, [sp, #5648]                ; 16-byte Reload
	bit.16b	v25, v21, v2
	str	q25, [sp, #5648]                ; 16-byte Spill
	ldr	q2, [x8]
	ldr	q21, [sp, #1040]                ; 16-byte Reload
	bit.16b	v2, v21, v17
	ldr	q21, [sp, #5744]                ; 16-byte Reload
	bit.16b	v21, v19, v17
	str	q21, [sp, #5744]                ; 16-byte Spill
	ldr	q21, [sp, #368]                 ; 16-byte Reload
	ldr	q25, [sp, #5680]                ; 16-byte Reload
	bit.16b	v25, v21, v17
	str	q25, [sp, #5680]                ; 16-byte Spill
	ldr	q17, [x16, #48]
	ldr	q21, [sp, #1088]                ; 16-byte Reload
	bit.16b	v17, v21, v11
	stp	q6, q17, [x16, #32]
	ldr	q6, [x16, #16]
	ldr	q17, [sp, #1120]                ; 16-byte Reload
	bit.16b	v6, v17, v8
	stp	q3, q6, [x16]
	ldr	q3, [x8, #48]
	ldr	q6, [sp, #1024]                 ; 16-byte Reload
	bit.16b	v3, v6, v11
	stp	q16, q3, [x8, #32]
	ldr	q3, [x8, #16]
	ldr	q6, [sp, #1056]                 ; 16-byte Reload
	bit.16b	v3, v6, v8
	stp	q2, q3, [x8]
	ldr	q2, [sp, #5088]                 ; 16-byte Reload
	bit.16b	v2, v4, v11
	str	q2, [sp, #5088]                 ; 16-byte Spill
	ldr	q2, [sp, #5120]                 ; 16-byte Reload
	bit.16b	v2, v4, v8
	str	q2, [sp, #5120]                 ; 16-byte Spill
	ldr	q2, [sp, #4224]                 ; 16-byte Reload
	ldr	q3, [sp, #5024]                 ; 16-byte Reload
	bit.16b	v3, v2, v11
	str	q3, [sp, #5024]                 ; 16-byte Spill
	ldr	q2, [sp, #4208]                 ; 16-byte Reload
	ldr	q3, [sp, #5056]                 ; 16-byte Reload
	bit.16b	v3, v2, v8
	str	q3, [sp, #5056]                 ; 16-byte Spill
	ldr	q2, [sp, #5216]                 ; 16-byte Reload
	bit.16b	v2, v18, v11
	str	q2, [sp, #5216]                 ; 16-byte Spill
	ldr	q2, [sp, #5248]                 ; 16-byte Reload
	bit.16b	v2, v18, v8
	str	q2, [sp, #5248]                 ; 16-byte Spill
	ldr	q2, [sp, #560]                  ; 16-byte Reload
	ldr	q3, [sp, #5152]                 ; 16-byte Reload
	bit.16b	v3, v2, v11
	str	q3, [sp, #5152]                 ; 16-byte Spill
	ldr	q2, [sp, #528]                  ; 16-byte Reload
	ldr	q3, [sp, #5184]                 ; 16-byte Reload
	bit.16b	v3, v2, v8
	str	q3, [sp, #5184]                 ; 16-byte Spill
	ldr	q2, [sp, #5696]                 ; 16-byte Reload
	bit.16b	v2, v19, v11
	str	q2, [sp, #5696]                 ; 16-byte Spill
	ldr	q2, [sp, #5728]                 ; 16-byte Reload
	bit.16b	v2, v19, v8
	str	q2, [sp, #5728]                 ; 16-byte Spill
	ldp	q2, q4, [sp, #400]              ; 32-byte Folded Reload
	ldr	q3, [sp, #5632]                 ; 16-byte Reload
	bit.16b	v3, v4, v11
	str	q3, [sp, #5632]                 ; 16-byte Spill
	ldr	q3, [sp, #5664]                 ; 16-byte Reload
	bit.16b	v3, v2, v8
	str	q3, [sp, #5664]                 ; 16-byte Spill
	ldr	w26, [sp, #2756]                ; 4-byte Reload
	ldr	w28, [sp, #2752]                ; 4-byte Reload
	ldr	w30, [sp, #2748]                ; 4-byte Reload
	ldr	x4, [sp, #2632]                 ; 8-byte Reload
	mov	x5, x7
	mov	x7, x19
	mov	x19, x10
	mov	x10, x27
	mov	w27, #43691                     ; =0xaaab
	mov	w20, #1267                      ; =0x4f3
	movk	w20, #15925, lsl #16
	movi.8b	v4, #1
	ldr	q18, [sp, #3088]                ; 16-byte Reload
	ldr	q19, [sp, #3072]                ; 16-byte Reload
	b	LBB0_396
LBB0_395:                               ; %else1164
                                        ;   in Loop: Header=BB0_396 Depth=2
	add	x3, x3, #1
	add	x1, x1, #8
	add	x21, x21, #64
	cmp	x3, #128
	b.eq	LBB0_450
LBB0_396:                               ; %direct.true433
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w8, s10
	lsr	x16, x3, #3
	dup.2d	v6, x16
	ldr	q2, [sp, #5200]                 ; 16-byte Reload
	orr.16b	v2, v6, v2
	ldr	q3, [sp, #5264]                 ; 16-byte Reload
	add.2d	v16, v3, v2
	tbz	w8, #0, LBB0_398
; %bb.397:                              ; %cond.load
                                        ;   in Loop: Header=BB0_396 Depth=2
	fmov	x16, d16
	ldr	b2, [x16]
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_399
	b	LBB0_400
LBB0_398:                               ;   in Loop: Header=BB0_396 Depth=2
	movi.2d	v2, #0000000000000000
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_400
LBB0_399:                               ; %cond.load1104
                                        ;   in Loop: Header=BB0_396 Depth=2
	mov.d	x16, v16[1]
	ld1.b	{ v2 }[1], [x16]
LBB0_400:                               ; %else1106
                                        ;   in Loop: Header=BB0_396 Depth=2
	ldr	q3, [sp, #5184]                 ; 16-byte Reload
	orr.16b	v3, v6, v3
	ldr	q16, [sp, #5248]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbz	w8, #2, LBB0_406
; %bb.401:                              ; %cond.load1108
                                        ;   in Loop: Header=BB0_396 Depth=2
	fmov	x16, d16
	ld1.b	{ v2 }[2], [x16]
	tbnz	w8, #3, LBB0_407
LBB0_402:                               ; %else1114
                                        ;   in Loop: Header=BB0_396 Depth=2
	ldr	q3, [sp, #5168]                 ; 16-byte Reload
	orr.16b	v3, v6, v3
	ldr	q16, [sp, #5232]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbz	w8, #4, LBB0_408
LBB0_403:                               ; %cond.load1116
                                        ;   in Loop: Header=BB0_396 Depth=2
	fmov	x16, d16
	ld1.b	{ v2 }[4], [x16]
	tbnz	w8, #5, LBB0_409
LBB0_404:                               ; %else1122
                                        ;   in Loop: Header=BB0_396 Depth=2
	ldr	q3, [sp, #5152]                 ; 16-byte Reload
	orr.16b	v3, v6, v3
	ldr	q6, [sp, #5216]                 ; 16-byte Reload
	add.2d	v6, v6, v3
	tbz	w8, #6, LBB0_410
LBB0_405:                               ; %cond.load1124
                                        ;   in Loop: Header=BB0_396 Depth=2
	fmov	x16, d6
	ld1.b	{ v2 }[6], [x16]
	tbnz	w8, #7, LBB0_411
	b	LBB0_412
LBB0_406:                               ; %else1110
                                        ;   in Loop: Header=BB0_396 Depth=2
	tbz	w8, #3, LBB0_402
LBB0_407:                               ; %cond.load1112
                                        ;   in Loop: Header=BB0_396 Depth=2
	mov.d	x16, v16[1]
	ld1.b	{ v2 }[3], [x16]
	ldr	q3, [sp, #5168]                 ; 16-byte Reload
	orr.16b	v3, v6, v3
	ldr	q16, [sp, #5232]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbnz	w8, #4, LBB0_403
LBB0_408:                               ; %else1118
                                        ;   in Loop: Header=BB0_396 Depth=2
	tbz	w8, #5, LBB0_404
LBB0_409:                               ; %cond.load1120
                                        ;   in Loop: Header=BB0_396 Depth=2
	mov.d	x16, v16[1]
	ld1.b	{ v2 }[5], [x16]
	ldr	q3, [sp, #5152]                 ; 16-byte Reload
	orr.16b	v3, v6, v3
	ldr	q6, [sp, #5216]                 ; 16-byte Reload
	add.2d	v6, v6, v3
	tbnz	w8, #6, LBB0_405
LBB0_410:                               ; %else1126
                                        ;   in Loop: Header=BB0_396 Depth=2
	tbz	w8, #7, LBB0_412
LBB0_411:                               ; %cond.load1128
                                        ;   in Loop: Header=BB0_396 Depth=2
	mov.d	x8, v6[1]
	ld1.b	{ v2 }[7], [x8]
LBB0_412:                               ; %else1130
                                        ;   in Loop: Header=BB0_396 Depth=2
	fmov	w8, s10
	cmeq.8b	v2, v2, #0
	and	x16, x1, #0x3c0
	add	x16, x4, x16
	ldp	q3, q6, [x16]
	ldp	q16, q17, [x16, #32]
	and	x16, x21, #0x1c0
	add	x16, x5, x16
	ldp	q21, q25, [x16]
	ldp	q26, q27, [x16, #32]
	cmge.2d	v17, v27, v17
	cmge.2d	v16, v26, v16
	uzp1.4s	v16, v16, v17
	cmge.2d	v6, v25, v6
	cmge.2d	v3, v21, v3
	uzp1.4s	v3, v3, v6
	uzp1.8h	v3, v3, v16
	xtn.8b	v3, v3
	orr.8b	v3, v7, v3
	bic.8b	v2, v3, v2
	dup.2d	v6, x3
	ldr	q3, [sp, #5680]                 ; 16-byte Reload
	orr.16b	v3, v6, v3
	ldr	q16, [sp, #5744]                ; 16-byte Reload
	add.2d	v16, v16, v3
	and.8b	v2, v2, v4
	tbz	w8, #0, LBB0_420
; %bb.413:                              ; %cond.store1133
                                        ;   in Loop: Header=BB0_396 Depth=2
	fmov	x16, d16
	str	b2, [x16]
	and	w8, w8, #0xff
	ldr	q25, [sp, #4976]                ; 16-byte Reload
	ldr	q26, [sp, #4960]                ; 16-byte Reload
	ldr	q27, [sp, #4944]                ; 16-byte Reload
	tbnz	w8, #1, LBB0_421
LBB0_414:                               ; %else1140
                                        ;   in Loop: Header=BB0_396 Depth=2
	ldr	q3, [sp, #5664]                 ; 16-byte Reload
	orr.16b	v3, v6, v3
	ldr	q16, [sp, #5728]                ; 16-byte Reload
	add.2d	v3, v16, v3
	tbz	w8, #2, LBB0_422
LBB0_415:                               ; %cond.store1141
                                        ;   in Loop: Header=BB0_396 Depth=2
	fmov	x16, d3
	st1.b	{ v2 }[2], [x16]
	tbnz	w8, #3, LBB0_423
LBB0_416:                               ; %else1148
                                        ;   in Loop: Header=BB0_396 Depth=2
	ldr	q3, [sp, #5648]                 ; 16-byte Reload
	orr.16b	v3, v6, v3
	ldr	q16, [sp, #5712]                ; 16-byte Reload
	add.2d	v3, v16, v3
	tbz	w8, #4, LBB0_424
LBB0_417:                               ; %cond.store1149
                                        ;   in Loop: Header=BB0_396 Depth=2
	fmov	x16, d3
	st1.b	{ v2 }[4], [x16]
	tbnz	w8, #5, LBB0_425
LBB0_418:                               ; %else1156
                                        ;   in Loop: Header=BB0_396 Depth=2
	ldr	q3, [sp, #5632]                 ; 16-byte Reload
	orr.16b	v3, v6, v3
	ldr	q6, [sp, #5696]                 ; 16-byte Reload
	add.2d	v3, v6, v3
	tbz	w8, #6, LBB0_426
LBB0_419:                               ; %cond.store1157
                                        ;   in Loop: Header=BB0_396 Depth=2
	fmov	x16, d3
	st1.b	{ v2 }[6], [x16]
	tbz	w8, #7, LBB0_395
	b	LBB0_427
LBB0_420:                               ; %else1136
                                        ;   in Loop: Header=BB0_396 Depth=2
	and	w8, w8, #0xff
	ldr	q25, [sp, #4976]                ; 16-byte Reload
	ldr	q26, [sp, #4960]                ; 16-byte Reload
	ldr	q27, [sp, #4944]                ; 16-byte Reload
	tbz	w8, #1, LBB0_414
LBB0_421:                               ; %cond.store1137
                                        ;   in Loop: Header=BB0_396 Depth=2
	mov.d	x16, v16[1]
	st1.b	{ v2 }[1], [x16]
	ldr	q3, [sp, #5664]                 ; 16-byte Reload
	orr.16b	v3, v6, v3
	ldr	q16, [sp, #5728]                ; 16-byte Reload
	add.2d	v3, v16, v3
	tbnz	w8, #2, LBB0_415
LBB0_422:                               ; %else1144
                                        ;   in Loop: Header=BB0_396 Depth=2
	tbz	w8, #3, LBB0_416
LBB0_423:                               ; %cond.store1145
                                        ;   in Loop: Header=BB0_396 Depth=2
	mov.d	x16, v3[1]
	st1.b	{ v2 }[3], [x16]
	ldr	q3, [sp, #5648]                 ; 16-byte Reload
	orr.16b	v3, v6, v3
	ldr	q16, [sp, #5712]                ; 16-byte Reload
	add.2d	v3, v16, v3
	tbnz	w8, #4, LBB0_417
LBB0_424:                               ; %else1152
                                        ;   in Loop: Header=BB0_396 Depth=2
	tbz	w8, #5, LBB0_418
LBB0_425:                               ; %cond.store1153
                                        ;   in Loop: Header=BB0_396 Depth=2
	mov.d	x16, v3[1]
	st1.b	{ v2 }[5], [x16]
	ldr	q3, [sp, #5632]                 ; 16-byte Reload
	orr.16b	v3, v6, v3
	ldr	q6, [sp, #5696]                 ; 16-byte Reload
	add.2d	v3, v6, v3
	tbnz	w8, #6, LBB0_419
LBB0_426:                               ; %else1160
                                        ;   in Loop: Header=BB0_396 Depth=2
	tbz	w8, #7, LBB0_395
LBB0_427:                               ; %cond.store1161
                                        ;   in Loop: Header=BB0_396 Depth=2
	mov.d	x8, v3[1]
	st1.b	{ v2 }[7], [x8]
	b	LBB0_395
LBB0_428:                               ; %else1006
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w1, w1, #0xff
	tbz	w1, #1, LBB0_370
LBB0_429:                               ; %cond.store1007
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1664]                 ; 16-byte Reload
	mov.d	x3, v3[1]
	st1.b	{ v2 }[1], [x3]
	tbnz	w1, #2, LBB0_371
LBB0_430:                               ; %else1014
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w1, #3, LBB0_372
LBB0_431:                               ; %cond.store1015
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1680]                 ; 16-byte Reload
	mov.d	x3, v3[1]
	st1.b	{ v2 }[3], [x3]
	tbnz	w1, #4, LBB0_373
LBB0_432:                               ; %else1022
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w1, #5, LBB0_374
LBB0_433:                               ; %cond.store1023
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1696]                 ; 16-byte Reload
	mov.d	x3, v3[1]
	st1.b	{ v2 }[5], [x3]
	tbnz	w1, #6, LBB0_375
LBB0_434:                               ; %else1030
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w1, #7, LBB0_376
LBB0_435:                               ; %cond.store1031
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1712]                 ; 16-byte Reload
	mov.d	x1, v3[1]
	st1.b	{ v2 }[7], [x1]
	orr	x25, x21, #0xe
	cmp	x25, #129
	cset	w3, lo
	fmov	w1, s10
	dup.8b	v2, w3
	tbnz	w1, #0, LBB0_377
LBB0_436:                               ; %else1039
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w1, w1, #0xff
	tbz	w1, #1, LBB0_378
LBB0_437:                               ; %cond.store1040
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1600]                 ; 16-byte Reload
	mov.d	x3, v3[1]
	st1.b	{ v2 }[1], [x3]
	tbnz	w1, #2, LBB0_379
LBB0_438:                               ; %else1047
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w1, #3, LBB0_380
LBB0_439:                               ; %cond.store1048
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1616]                 ; 16-byte Reload
	mov.d	x3, v3[1]
	st1.b	{ v2 }[3], [x3]
	tbnz	w1, #4, LBB0_381
LBB0_440:                               ; %else1055
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w1, #5, LBB0_382
LBB0_441:                               ; %cond.store1056
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1632]                 ; 16-byte Reload
	mov.d	x3, v3[1]
	st1.b	{ v2 }[5], [x3]
	tbnz	w1, #6, LBB0_383
LBB0_442:                               ; %else1063
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w1, #7, LBB0_384
LBB0_443:                               ; %cond.store1064
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1648]                 ; 16-byte Reload
	mov.d	x1, v3[1]
	st1.b	{ v2 }[7], [x1]
	orr	x4, x21, #0xf
	cmp	x4, #129
	cset	w3, lo
	fmov	w1, s10
	dup.8b	v2, w3
	tbnz	w1, #0, LBB0_385
LBB0_444:                               ; %else1072
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w1, w1, #0xff
	tbz	w1, #1, LBB0_386
LBB0_445:                               ; %cond.store1073
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1536]                 ; 16-byte Reload
	mov.d	x3, v3[1]
	st1.b	{ v2 }[1], [x3]
	tbnz	w1, #2, LBB0_387
LBB0_446:                               ; %else1080
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w1, #3, LBB0_388
LBB0_447:                               ; %cond.store1081
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1552]                 ; 16-byte Reload
	mov.d	x3, v3[1]
	st1.b	{ v2 }[3], [x3]
	mov	x27, x10
	tbnz	w1, #4, LBB0_389
LBB0_448:                               ; %else1088
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x10, x19
	tbz	w1, #5, LBB0_390
LBB0_449:                               ; %cond.store1089
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #1568]                 ; 16-byte Reload
	mov.d	x3, v3[1]
	st1.b	{ v2 }[5], [x3]
	mov	x19, x7
	tbnz	w1, #6, LBB0_391
	b	LBB0_392
LBB0_450:                               ; %direct.true455.preheader
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	mov	x1, #0                          ; =0x0
	ldr	q4, [sp, #576]                  ; 16-byte Reload
	b	LBB0_452
LBB0_451:                               ; %else1261
                                        ;   in Loop: Header=BB0_452 Depth=2
	cmeq.8b	v2, v2, #0
	sshll.8h	v2, v2, #0
	sshll.4s	v3, v2, #0
	sshll2.4s	v2, v2, #0
	dup.4s	v16, w20
	fmul.4s	v6, v6, v16
	fmul.4s	v16, v17, v16
	bsl.16b	v2, v4, v16
	bsl.16b	v3, v4, v6
	add	x3, x6, x1, lsl #5
	ldp	q16, q6, [x3]
	bif.16b	v3, v16, v1
	bif.16b	v2, v6, v0
	stp	q3, q2, [x3]
	add	x1, x1, #1
	add	x16, x16, #4
	add	x8, x8, #8
	cmp	x16, #512
	ldr	q17, [sp, #4928]                ; 16-byte Reload
	b.eq	LBB0_484
LBB0_452:                               ; %direct.true455
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w3, s10
	and	x4, x8, #0x78
	orr	x4, x4, x1, lsr #4
	dup.2d	v6, x4
	ldr	q2, [sp, #5680]                 ; 16-byte Reload
	orr.16b	v2, v6, v2
	ldr	q3, [sp, #5744]                 ; 16-byte Reload
	add.2d	v16, v3, v2
	tbz	w3, #0, LBB0_454
; %bb.453:                              ; %cond.load1166
                                        ;   in Loop: Header=BB0_452 Depth=2
	fmov	x4, d16
	ldr	b2, [x4]
	and	w3, w3, #0xff
	tbnz	w3, #1, LBB0_455
	b	LBB0_456
LBB0_454:                               ;   in Loop: Header=BB0_452 Depth=2
	movi.2d	v2, #0000000000000000
	and	w3, w3, #0xff
	tbz	w3, #1, LBB0_456
LBB0_455:                               ; %cond.load1172
                                        ;   in Loop: Header=BB0_452 Depth=2
	mov.d	x4, v16[1]
	ld1.b	{ v2 }[1], [x4]
LBB0_456:                               ; %else1176
                                        ;   in Loop: Header=BB0_452 Depth=2
	ldr	q3, [sp, #5664]                 ; 16-byte Reload
	orr.16b	v3, v6, v3
	ldr	q16, [sp, #5728]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbz	w3, #2, LBB0_462
; %bb.457:                              ; %cond.load1178
                                        ;   in Loop: Header=BB0_452 Depth=2
	fmov	x4, d16
	ld1.b	{ v2 }[2], [x4]
	tbnz	w3, #3, LBB0_463
LBB0_458:                               ; %else1188
                                        ;   in Loop: Header=BB0_452 Depth=2
	ldr	q3, [sp, #5648]                 ; 16-byte Reload
	orr.16b	v3, v6, v3
	ldr	q16, [sp, #5712]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbz	w3, #4, LBB0_464
LBB0_459:                               ; %cond.load1190
                                        ;   in Loop: Header=BB0_452 Depth=2
	fmov	x4, d16
	ld1.b	{ v2 }[4], [x4]
	tbnz	w3, #5, LBB0_465
LBB0_460:                               ; %else1200
                                        ;   in Loop: Header=BB0_452 Depth=2
	ldr	q3, [sp, #5632]                 ; 16-byte Reload
	orr.16b	v3, v6, v3
	ldr	q6, [sp, #5696]                 ; 16-byte Reload
	add.2d	v6, v6, v3
	tbz	w3, #6, LBB0_466
LBB0_461:                               ; %cond.load1202
                                        ;   in Loop: Header=BB0_452 Depth=2
	fmov	x4, d6
	ld1.b	{ v2 }[6], [x4]
	tbnz	w3, #7, LBB0_467
	b	LBB0_468
LBB0_462:                               ; %else1182
                                        ;   in Loop: Header=BB0_452 Depth=2
	tbz	w3, #3, LBB0_458
LBB0_463:                               ; %cond.load1184
                                        ;   in Loop: Header=BB0_452 Depth=2
	mov.d	x4, v16[1]
	ld1.b	{ v2 }[3], [x4]
	ldr	q3, [sp, #5648]                 ; 16-byte Reload
	orr.16b	v3, v6, v3
	ldr	q16, [sp, #5712]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbnz	w3, #4, LBB0_459
LBB0_464:                               ; %else1194
                                        ;   in Loop: Header=BB0_452 Depth=2
	tbz	w3, #5, LBB0_460
LBB0_465:                               ; %cond.load1196
                                        ;   in Loop: Header=BB0_452 Depth=2
	mov.d	x4, v16[1]
	ld1.b	{ v2 }[5], [x4]
	ldr	q3, [sp, #5632]                 ; 16-byte Reload
	orr.16b	v3, v6, v3
	ldr	q6, [sp, #5696]                 ; 16-byte Reload
	add.2d	v6, v6, v3
	tbnz	w3, #6, LBB0_461
LBB0_466:                               ; %else1206
                                        ;   in Loop: Header=BB0_452 Depth=2
	tbz	w3, #7, LBB0_468
LBB0_467:                               ; %cond.load1208
                                        ;   in Loop: Header=BB0_452 Depth=2
	mov.d	x3, v6[1]
	ld1.b	{ v2 }[7], [x3]
LBB0_468:                               ; %else1212
                                        ;   in Loop: Header=BB0_452 Depth=2
	fmov	w3, s10
	dup.2d	v21, x16
	ldr	q3, [sp, #5072]                 ; 16-byte Reload
	orr.16b	v3, v21, v3
	ldr	q6, [sp, #5136]                 ; 16-byte Reload
	add.2d	v16, v6, v3
	movi.2d	v6, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbz	w3, #0, LBB0_476
; %bb.469:                              ; %cond.load1215
                                        ;   in Loop: Header=BB0_452 Depth=2
	fmov	x4, d16
	ldr	s6, [x4]
	and	w3, w3, #0xff
	tbnz	w3, #1, LBB0_477
LBB0_470:                               ; %else1225
                                        ;   in Loop: Header=BB0_452 Depth=2
	ldr	q3, [sp, #5056]                 ; 16-byte Reload
	orr.16b	v3, v21, v3
	ldr	q16, [sp, #5120]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbz	w3, #2, LBB0_478
LBB0_471:                               ; %cond.load1227
                                        ;   in Loop: Header=BB0_452 Depth=2
	fmov	x4, d16
	ld1.s	{ v6 }[2], [x4]
	tbnz	w3, #3, LBB0_479
LBB0_472:                               ; %else1237
                                        ;   in Loop: Header=BB0_452 Depth=2
	ldr	q3, [sp, #5040]                 ; 16-byte Reload
	orr.16b	v3, v21, v3
	ldr	q16, [sp, #5104]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbz	w3, #4, LBB0_480
LBB0_473:                               ; %cond.load1239
                                        ;   in Loop: Header=BB0_452 Depth=2
	fmov	x4, d16
	ld1.s	{ v17 }[0], [x4]
	tbnz	w3, #5, LBB0_481
LBB0_474:                               ; %else1249
                                        ;   in Loop: Header=BB0_452 Depth=2
	ldr	q3, [sp, #5024]                 ; 16-byte Reload
	orr.16b	v3, v21, v3
	ldr	q16, [sp, #5088]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbz	w3, #6, LBB0_482
LBB0_475:                               ; %cond.load1251
                                        ;   in Loop: Header=BB0_452 Depth=2
	fmov	x4, d16
	ld1.s	{ v17 }[2], [x4]
	tbz	w3, #7, LBB0_451
	b	LBB0_483
LBB0_476:                               ; %else1219
                                        ;   in Loop: Header=BB0_452 Depth=2
	and	w3, w3, #0xff
	tbz	w3, #1, LBB0_470
LBB0_477:                               ; %cond.load1221
                                        ;   in Loop: Header=BB0_452 Depth=2
	mov.d	x4, v16[1]
	ld1.s	{ v6 }[1], [x4]
	ldr	q3, [sp, #5056]                 ; 16-byte Reload
	orr.16b	v3, v21, v3
	ldr	q16, [sp, #5120]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbnz	w3, #2, LBB0_471
LBB0_478:                               ; %else1231
                                        ;   in Loop: Header=BB0_452 Depth=2
	tbz	w3, #3, LBB0_472
LBB0_479:                               ; %cond.load1233
                                        ;   in Loop: Header=BB0_452 Depth=2
	mov.d	x4, v16[1]
	ld1.s	{ v6 }[3], [x4]
	ldr	q3, [sp, #5040]                 ; 16-byte Reload
	orr.16b	v3, v21, v3
	ldr	q16, [sp, #5104]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbnz	w3, #4, LBB0_473
LBB0_480:                               ; %else1243
                                        ;   in Loop: Header=BB0_452 Depth=2
	tbz	w3, #5, LBB0_474
LBB0_481:                               ; %cond.load1245
                                        ;   in Loop: Header=BB0_452 Depth=2
	mov.d	x4, v16[1]
	ld1.s	{ v17 }[1], [x4]
	ldr	q3, [sp, #5024]                 ; 16-byte Reload
	orr.16b	v3, v21, v3
	ldr	q16, [sp, #5088]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbnz	w3, #6, LBB0_475
LBB0_482:                               ; %else1255
                                        ;   in Loop: Header=BB0_452 Depth=2
	tbz	w3, #7, LBB0_451
LBB0_483:                               ; %cond.load1257
                                        ;   in Loop: Header=BB0_452 Depth=2
	mov.d	x3, v16[1]
	ld1.s	{ v17 }[3], [x3]
	b	LBB0_451
LBB0_484:                               ; %direct.false456
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	mvni.4s	v4, #127, msl #16
	bit.16b	v14, v4, v0
	ldr	q6, [sp, #4112]                 ; 16-byte Reload
	bit.16b	v6, v4, v1
LBB0_485:                               ; %direct.true473
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x6, x8
	ldp	q2, q3, [x16]
	and.16b	v3, v0, v3
	and.16b	v2, v1, v2
	fmaxnm.4s	v2, v6, v2
	fmaxnm.4s	v3, v14, v3
	bit.16b	v14, v3, v0
	bit.16b	v6, v2, v1
	add	x8, x8, #32
	cmp	x8, #512
	b.ne	LBB0_485
; %bb.486:                              ; %direct.false474
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q6, [sp, #4112]                 ; 16-byte Spill
	str	q14, [sp, #3776]                ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	ldr	q14, [sp, #4128]                ; 16-byte Reload
	bit.16b	v14, v4, v0
	ldr	q21, [sp, #4144]                ; 16-byte Reload
	bit.16b	v21, v4, v1
	ldr	q6, [sp, #3120]                 ; 16-byte Reload
	ldr	q16, [sp, #3104]                ; 16-byte Reload
LBB0_487:                               ; %direct.true485
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x2, x8
	ldp	q2, q3, [x16]
	and.16b	v3, v0, v3
	and.16b	v2, v1, v2
	fmaxnm.4s	v2, v21, v2
	fmaxnm.4s	v3, v14, v3
	bit.16b	v14, v3, v0
	bit.16b	v21, v2, v1
	add	x8, x8, #32
	cmp	x8, #512
	b.ne	LBB0_487
; %bb.488:                              ; %direct.false486
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q14, [sp, #4128]                ; 16-byte Spill
	str	q21, [sp, #4144]                ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	ldr	q21, [sp, #4160]                ; 16-byte Reload
	bit.16b	v21, v4, v0
	bit.16b	v17, v4, v1
LBB0_489:                               ; %direct.true497
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x12, x8
	ldp	q2, q3, [x16]
	and.16b	v3, v0, v3
	and.16b	v2, v1, v2
	fmaxnm.4s	v2, v17, v2
	fmaxnm.4s	v3, v21, v3
	bit.16b	v21, v3, v0
	bit.16b	v17, v2, v1
	add	x8, x8, #32
	cmp	x8, #512
	b.ne	LBB0_489
; %bb.490:                              ; %direct.false498
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q21, [sp, #4160]                ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	bit.16b	v27, v4, v0
	bit.16b	v26, v4, v1
	ldr	q21, [sp, #3776]                ; 16-byte Reload
LBB0_491:                               ; %direct.true509
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x14, x8
	ldp	q2, q3, [x16]
	and.16b	v3, v0, v3
	and.16b	v2, v1, v2
	fmaxnm.4s	v2, v26, v2
	fmaxnm.4s	v3, v27, v3
	bit.16b	v27, v3, v0
	bit.16b	v26, v2, v1
	add	x8, x8, #32
	cmp	x8, #512
	b.ne	LBB0_491
; %bb.492:                              ; %direct.false510
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	bit.16b	v25, v4, v0
	bit.16b	v15, v4, v1
LBB0_493:                               ; %direct.true521
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x11, x8
	ldp	q2, q3, [x16]
	and.16b	v3, v0, v3
	and.16b	v2, v1, v2
	fmaxnm.4s	v2, v15, v2
	fmaxnm.4s	v3, v25, v3
	bit.16b	v25, v3, v0
	bit.16b	v15, v2, v1
	add	x8, x8, #32
	cmp	x8, #512
	b.ne	LBB0_493
; %bb.494:                              ; %direct.false522
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	bit.16b	v30, v4, v0
	bit.16b	v19, v4, v1
LBB0_495:                               ; %direct.true533
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x13, x8
	ldp	q2, q3, [x16]
	and.16b	v3, v0, v3
	and.16b	v2, v1, v2
	fmaxnm.4s	v2, v19, v2
	fmaxnm.4s	v3, v30, v3
	bit.16b	v30, v3, v0
	bit.16b	v19, v2, v1
	add	x8, x8, #32
	cmp	x8, #512
	b.ne	LBB0_495
; %bb.496:                              ; %direct.false534
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	bit.16b	v18, v4, v0
	bit.16b	v16, v4, v1
LBB0_497:                               ; %direct.true545
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x15, x8
	ldp	q2, q3, [x16]
	and.16b	v3, v0, v3
	and.16b	v2, v1, v2
	fmaxnm.4s	v2, v16, v2
	fmaxnm.4s	v3, v18, v3
	bit.16b	v18, v3, v0
	bit.16b	v16, v2, v1
	add	x8, x8, #32
	cmp	x8, #512
	b.ne	LBB0_497
; %bb.498:                              ; %direct.false546
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q23, [sp, #2768]                ; 16-byte Spill
	str	q9, [sp, #2928]                 ; 16-byte Spill
	str	q22, [sp, #2944]                ; 16-byte Spill
	str	q5, [sp, #3248]                 ; 16-byte Spill
	str	q12, [sp, #3264]                ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	bit.16b	v6, v4, v0
	ldr	q5, [sp, #3136]                 ; 16-byte Reload
	bit.16b	v5, v4, v1
LBB0_499:                               ; %direct.true557
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x9, x8
	ldp	q2, q3, [x16]
	and.16b	v3, v0, v3
	and.16b	v2, v1, v2
	fmaxnm.4s	v2, v5, v2
	fmaxnm.4s	v3, v6, v3
	bit.16b	v6, v3, v0
	bit.16b	v5, v2, v1
	add	x8, x8, #32
	cmp	x8, #512
	b.ne	LBB0_499
; %bb.500:                              ; %direct.false558
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x21, #0                         ; =0x0
	mov	x22, #0                         ; =0x0
	mov	x23, #0                         ; =0x0
	mov	x25, #0                         ; =0x0
	ldr	q2, [sp, #4112]                 ; 16-byte Reload
	ldr	q11, [sp, #3808]                ; 16-byte Reload
	fmaxnm.4s	v8, v11, v2
	ldr	q4, [sp, #3792]                 ; 16-byte Reload
	fmaxnm.4s	v13, v4, v21
	ldr	q2, [sp, #4144]                 ; 16-byte Reload
	ldr	q3, [sp, #4336]                 ; 16-byte Reload
	fmaxnm.4s	v22, v3, v2
	ldr	q2, [sp, #4128]                 ; 16-byte Reload
	ldr	q3, [sp, #4320]                 ; 16-byte Reload
	fmaxnm.4s	v7, v3, v2
	str	q17, [sp, #4928]                ; 16-byte Spill
	ldr	q2, [sp, #4368]                 ; 16-byte Reload
	fmaxnm.4s	v14, v2, v17
	ldr	q2, [sp, #4160]                 ; 16-byte Reload
	ldr	q3, [sp, #4352]                 ; 16-byte Reload
	fmaxnm.4s	v23, v3, v2
	str	q23, [sp, #3680]                ; 16-byte Spill
	str	q26, [sp, #4960]                ; 16-byte Spill
	ldr	q2, [sp, #4400]                 ; 16-byte Reload
	fmaxnm.4s	v21, v2, v26
	str	q21, [sp, #3760]                ; 16-byte Spill
	str	q27, [sp, #4944]                ; 16-byte Spill
	ldr	q2, [sp, #4384]                 ; 16-byte Reload
	fmaxnm.4s	v17, v2, v27
	str	q17, [sp, #3664]                ; 16-byte Spill
	str	q15, [sp, #3040]                ; 16-byte Spill
	ldr	q2, [sp, #4432]                 ; 16-byte Reload
	fmaxnm.4s	v12, v2, v15
	str	q12, [sp, #3744]                ; 16-byte Spill
	str	q25, [sp, #4976]                ; 16-byte Spill
	ldr	q2, [sp, #4416]                 ; 16-byte Reload
	fmaxnm.4s	v26, v2, v25
	str	q26, [sp, #3648]                ; 16-byte Spill
	str	q19, [sp, #3072]                ; 16-byte Spill
	ldr	q2, [sp, #4464]                 ; 16-byte Reload
	fmaxnm.4s	v31, v2, v19
	str	q31, [sp, #3728]                ; 16-byte Spill
	str	q30, [sp, #3056]                ; 16-byte Spill
	ldr	q2, [sp, #4448]                 ; 16-byte Reload
	fmaxnm.4s	v19, v2, v30
	str	q19, [sp, #3632]                ; 16-byte Spill
	str	q16, [sp, #3104]                ; 16-byte Spill
	ldr	q2, [sp, #4496]                 ; 16-byte Reload
	fmaxnm.4s	v9, v2, v16
	str	q9, [sp, #3712]                 ; 16-byte Spill
	str	q18, [sp, #3088]                ; 16-byte Spill
	ldr	q2, [sp, #4480]                 ; 16-byte Reload
	fmaxnm.4s	v18, v2, v18
	str	q18, [sp, #3616]                ; 16-byte Spill
	str	q5, [sp, #3136]                 ; 16-byte Spill
	ldr	q2, [sp, #4288]                 ; 16-byte Reload
	fmaxnm.4s	v25, v2, v5
	str	q25, [sp, #3696]                ; 16-byte Spill
	str	q6, [sp, #3120]                 ; 16-byte Spill
	ldr	q2, [sp, #4304]                 ; 16-byte Reload
	fmaxnm.4s	v5, v2, v6
	str	q5, [sp, #3600]                 ; 16-byte Spill
	ldr	x8, [sp, #712]                  ; 8-byte Reload
	ldp	q2, q3, [x8]
	bit.16b	v3, v13, v0
	bit.16b	v2, v8, v1
	stp	q2, q3, [x8]
	ldr	x8, [sp, #704]                  ; 8-byte Reload
	ldp	q2, q3, [x8]
	bit.16b	v3, v7, v0
	bit.16b	v2, v22, v1
	stp	q2, q3, [x8]
	ldr	x8, [sp, #696]                  ; 8-byte Reload
	ldp	q2, q3, [x8]
	bit.16b	v3, v23, v0
	bit.16b	v2, v14, v1
	mov.16b	v23, v14
	ldr	x16, [sp, #688]                 ; 8-byte Reload
	ldp	q6, q16, [x16]
	bit.16b	v16, v17, v0
	mov.16b	v17, v1
	bsl.16b	v17, v21, v6
	ldr	x1, [sp, #680]                  ; 8-byte Reload
	ldp	q6, q21, [x1]
	bif.16b	v26, v21, v0
	mov.16b	v27, v1
	bsl.16b	v27, v12, v6
	ldr	x3, [sp, #672]                  ; 8-byte Reload
	ldp	q6, q21, [x3]
	mov.16b	v30, v0
	bsl.16b	v30, v19, v21
	bif.16b	v31, v6, v1
	ldr	x4, [sp, #664]                  ; 8-byte Reload
	ldp	q6, q21, [x4]
	mov.16b	v19, v0
	bsl.16b	v19, v18, v21
	mov.16b	v12, v1
	bsl.16b	v12, v9, v6
	ldr	x20, [sp, #656]                 ; 8-byte Reload
	ldp	q6, q21, [x20]
	mov.16b	v15, v0
	bsl.16b	v15, v5, v21
	mov.16b	v14, v1
	bsl.16b	v14, v25, v6
	str	q13, [sp, #2848]                ; 16-byte Spill
	fsub.4s	v21, v4, v13
	stp	q2, q3, [x8]
	str	q8, [sp, #2896]                 ; 16-byte Spill
	fsub.4s	v2, v11, v8
	and.16b	v6, v1, v2
	and.16b	v21, v0, v21
	mov	w8, #-1026555904                ; =0xc2d00000
	dup.4s	v11, w8
	stp	q17, q16, [x16]
	fcmge.4s	v2, v21, v11
	fcmge.4s	v3, v6, v11
	mov	w8, #1120403456                 ; =0x42c80000
	dup.4s	v25, w8
	fcmge.4s	v16, v25, v21
	fcmge.4s	v17, v25, v6
	stp	q27, q26, [x1]
	and.16b	v3, v3, v17
	and.16b	v2, v2, v16
	and.16b	v2, v2, v21
	stp	q31, q30, [x3]
	and.16b	v3, v3, v6
	mov	w8, #43579                      ; =0xaa3b
	movk	w8, #16312, lsl #16
	dup.4s	v17, w8
	fmul.4s	v16, v3, v17
	fmul.4s	v26, v2, v17
	stp	q12, q19, [x4]
	movi.4s	v4, #75, lsl #24
	mvni.4s	v5, #128, lsl #24
	mov.16b	v27, v5
	bsl.16b	v27, v4, v26
	mov.16b	v30, v5
	bsl.16b	v30, v4, v16
	fadd.4s	v16, v16, v30
	stp	q14, q15, [x20]
	fadd.4s	v26, v26, v27
	fsub.4s	v26, v26, v27
	fsub.4s	v16, v16, v30
	fcvtzs.4s	v16, v16
	fcvtzs.4s	v31, v26
	scvtf.4s	v26, v31
	scvtf.4s	v27, v16
	mov	w8, #29184                      ; =0x7200
	movk	w8, #16177, lsl #16
	dup.4s	v9, w8
	fmul.4s	v30, v27, v9
	fmul.4s	v8, v26, v9
	fsub.4s	v2, v2, v8
	fsub.4s	v3, v3, v30
	mov	w8, #48782                      ; =0xbe8e
	movk	w8, #13759, lsl #16
	dup.4s	v5, w8
	fmul.4s	v26, v26, v5
	fmul.4s	v27, v27, v5
	fsub.4s	v3, v3, v27
	fsub.4s	v8, v2, v26
	mov	w8, #11226                      ; =0x2bda
	movk	w8, #14672, lsl #16
	dup.4s	v12, w8
	fmul.4s	v26, v8, v12
	mov	w8, #38601                      ; =0x96c9
	movk	w8, #15030, lsl #16
	dup.4s	v2, w8
	fadd.4s	v26, v26, v2
	fmul.4s	v27, v8, v26
	mov	w8, #34982                      ; =0x88a6
	movk	w8, #15368, lsl #16
	dup.4s	v26, w8
	fadd.4s	v27, v27, v26
	fmul.4s	v30, v8, v27
	mov	w8, #43642                      ; =0xaa7a
	movk	w8, #15658, lsl #16
	dup.4s	v27, w8
	fadd.4s	v30, v30, v27
	fmul.4s	v13, v8, v30
	mov	w8, #43691                      ; =0xaaab
	movk	w8, #15914, lsl #16
	dup.4s	v30, w8
	fadd.4s	v13, v13, v30
	fmul.4s	v13, v8, v13
	movi.4s	v4, #63, lsl #24
	fadd.4s	v13, v13, v4
	movi.4s	v18, #63, lsl #24
	fmul.4s	v14, v8, v8
	fmul.4s	v13, v14, v13
	fmul.4s	v14, v3, v12
	fadd.4s	v14, v14, v2
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v26
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v27
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v30
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v18
	fmul.4s	v15, v3, v3
	fmul.4s	v14, v15, v14
	fadd.4s	v3, v3, v14
	fadd.4s	v8, v8, v13
	fmov.4s	v19, #1.00000000
	fadd.4s	v3, v3, v19
	sshr.4s	v13, v16, #1
	shl.4s	v14, v13, #23
	add.4s	v14, v14, v19
	fmul.4s	v3, v3, v14
	fadd.4s	v8, v8, v19
	sshr.4s	v14, v31, #1
	shl.4s	v15, v14, #23
	add.4s	v15, v15, v19
	fmul.4s	v8, v8, v15
	sub.4s	v16, v16, v13
	sub.4s	v31, v31, v14
	shl.4s	v31, v31, #23
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v19
	add.4s	v31, v31, v19
	fmul.4s	v31, v8, v31
	fmul.4s	v3, v3, v16
	fcmgt.4s	v16, v11, v6
	bic.16b	v3, v3, v16
	fcmgt.4s	v16, v11, v21
	bic.16b	v16, v31, v16
	fcmgt.4s	v8, v21, v25
	mvni.4s	v4, #127, msl #16
	fneg.4s	v31, v4
	bit.16b	v16, v31, v8
	fcmgt.4s	v8, v6, v25
	bit.16b	v3, v31, v8
	str	q7, [sp, #2832]                 ; 16-byte Spill
	ldr	q4, [sp, #4320]                 ; 16-byte Reload
	fsub.4s	v8, v4, v7
	fcmeq.4s	v21, v21, v21
	fcmeq.4s	v6, v6, v6
	ldr	q7, [sp, #5392]                 ; 16-byte Reload
	bif.16b	v3, v7, v6
	str	q3, [sp, #3584]                 ; 16-byte Spill
	mov.16b	v3, v21
	bsl.16b	v3, v16, v7
	str	q3, [sp, #3568]                 ; 16-byte Spill
	and.16b	v6, v0, v8
	fcmge.4s	v3, v6, v11
	fcmge.4s	v16, v25, v6
	and.16b	v3, v3, v16
	str	q22, [sp, #2880]                ; 16-byte Spill
	ldr	q4, [sp, #4336]                 ; 16-byte Reload
	fsub.4s	v16, v4, v22
	and.16b	v21, v1, v16
	fcmge.4s	v16, v21, v11
	fcmge.4s	v8, v25, v21
	and.16b	v16, v16, v8
	and.16b	v8, v16, v21
	fmul.4s	v16, v8, v17
	mvni.4s	v4, #128, lsl #24
	movi.4s	v22, #75, lsl #24
	mov.16b	v13, v4
	bsl.16b	v13, v22, v16
	fadd.4s	v16, v16, v13
	fsub.4s	v16, v16, v13
	and.16b	v3, v3, v6
	fmul.4s	v13, v3, v17
	mov.16b	v14, v4
	bsl.16b	v14, v22, v13
	fadd.4s	v13, v13, v14
	fsub.4s	v13, v13, v14
	fcvtzs.4s	v16, v16
	scvtf.4s	v14, v16
	fmul.4s	v15, v14, v9
	fsub.4s	v8, v8, v15
	fcvtzs.4s	v13, v13
	scvtf.4s	v15, v13
	fmul.4s	v4, v15, v9
	fsub.4s	v3, v3, v4
	fmul.4s	v4, v15, v5
	fsub.4s	v3, v3, v4
	fmul.4s	v4, v14, v5
	fsub.4s	v4, v8, v4
	fmul.4s	v8, v4, v12
	fadd.4s	v8, v8, v2
	fmul.4s	v8, v4, v8
	fadd.4s	v8, v8, v26
	fmul.4s	v8, v4, v8
	fadd.4s	v8, v8, v27
	fmul.4s	v8, v4, v8
	fadd.4s	v8, v8, v30
	fmul.4s	v8, v4, v8
	fadd.4s	v8, v8, v18
	fmul.4s	v14, v4, v4
	fmul.4s	v8, v14, v8
	fmul.4s	v14, v3, v12
	fadd.4s	v14, v14, v2
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v26
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v27
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v30
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v18
	fmul.4s	v15, v3, v3
	fmul.4s	v14, v15, v14
	fadd.4s	v3, v3, v14
	fadd.4s	v4, v4, v8
	fadd.4s	v3, v3, v19
	sshr.4s	v8, v13, #1
	shl.4s	v14, v8, #23
	add.4s	v14, v14, v19
	fmul.4s	v3, v3, v14
	fadd.4s	v4, v4, v19
	sshr.4s	v14, v16, #1
	shl.4s	v15, v14, #23
	add.4s	v15, v15, v19
	fmul.4s	v4, v4, v15
	sub.4s	v8, v13, v8
	sub.4s	v16, v16, v14
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v19
	fmul.4s	v4, v4, v16
	shl.4s	v16, v8, #23
	add.4s	v16, v16, v19
	fmul.4s	v3, v3, v16
	fcmgt.4s	v16, v11, v6
	bic.16b	v3, v3, v16
	fcmgt.4s	v16, v11, v21
	bic.16b	v4, v4, v16
	fcmgt.4s	v16, v21, v25
	bit.16b	v4, v31, v16
	fcmgt.4s	v16, v6, v25
	bit.16b	v3, v31, v16
	fcmeq.4s	v6, v6, v6
	bif.16b	v3, v7, v6
	str	q3, [sp, #3552]                 ; 16-byte Spill
	fcmeq.4s	v3, v21, v21
	bsl.16b	v3, v4, v7
	str	q3, [sp, #3536]                 ; 16-byte Spill
	ldr	q3, [sp, #4352]                 ; 16-byte Reload
	ldr	q4, [sp, #3680]                 ; 16-byte Reload
	fsub.4s	v3, v3, v4
	and.16b	v6, v0, v3
	fcmge.4s	v3, v6, v11
	fcmge.4s	v4, v25, v6
	and.16b	v3, v3, v4
	str	q23, [sp, #2864]                ; 16-byte Spill
	ldr	q16, [sp, #4368]                ; 16-byte Reload
	fsub.4s	v4, v16, v23
	and.16b	v21, v1, v4
	fcmge.4s	v4, v21, v11
	fcmge.4s	v16, v25, v21
	and.16b	v4, v4, v16
	and.16b	v4, v4, v21
	fmul.4s	v16, v4, v17
	mvni.4s	v22, #128, lsl #24
	movi.4s	v18, #75, lsl #24
	mov.16b	v8, v22
	bsl.16b	v8, v18, v16
	fadd.4s	v16, v16, v8
	fsub.4s	v16, v16, v8
	and.16b	v3, v3, v6
	fmul.4s	v8, v3, v17
	mov.16b	v13, v22
	bsl.16b	v13, v18, v8
	movi.4s	v23, #75, lsl #24
	fadd.4s	v8, v8, v13
	fsub.4s	v8, v8, v13
	fcvtzs.4s	v16, v16
	scvtf.4s	v13, v16
	fmul.4s	v14, v13, v9
	fsub.4s	v4, v4, v14
	fcvtzs.4s	v8, v8
	scvtf.4s	v14, v8
	fmul.4s	v15, v14, v9
	fsub.4s	v3, v3, v15
	fmul.4s	v14, v14, v5
	fsub.4s	v3, v3, v14
	fmul.4s	v13, v13, v5
	fsub.4s	v4, v4, v13
	fmul.4s	v13, v4, v12
	fadd.4s	v13, v13, v2
	fmul.4s	v13, v4, v13
	fadd.4s	v13, v13, v26
	fmul.4s	v13, v4, v13
	fadd.4s	v13, v13, v27
	fmul.4s	v13, v4, v13
	fadd.4s	v13, v13, v30
	fmul.4s	v13, v4, v13
	movi.4s	v18, #63, lsl #24
	fadd.4s	v13, v13, v18
	fmul.4s	v14, v4, v4
	fmul.4s	v13, v14, v13
	fmul.4s	v14, v3, v12
	fadd.4s	v14, v14, v2
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v26
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v27
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v30
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v18
	fmul.4s	v15, v3, v3
	fmul.4s	v14, v15, v14
	fadd.4s	v3, v3, v14
	fadd.4s	v4, v4, v13
	fadd.4s	v3, v3, v19
	sshr.4s	v13, v8, #1
	shl.4s	v14, v13, #23
	add.4s	v14, v14, v19
	fmul.4s	v3, v3, v14
	fadd.4s	v4, v4, v19
	sshr.4s	v14, v16, #1
	shl.4s	v15, v14, #23
	add.4s	v15, v15, v19
	fmul.4s	v4, v4, v15
	sub.4s	v8, v8, v13
	sub.4s	v16, v16, v14
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v19
	fmul.4s	v4, v4, v16
	shl.4s	v16, v8, #23
	add.4s	v16, v16, v19
	fmul.4s	v3, v3, v16
	fcmgt.4s	v16, v11, v6
	bic.16b	v3, v3, v16
	fcmgt.4s	v16, v11, v21
	bic.16b	v4, v4, v16
	fcmgt.4s	v16, v21, v25
	bit.16b	v4, v31, v16
	fcmgt.4s	v16, v6, v25
	bit.16b	v3, v31, v16
	fcmeq.4s	v6, v6, v6
	bif.16b	v3, v7, v6
	str	q3, [sp, #3520]                 ; 16-byte Spill
	fcmeq.4s	v3, v21, v21
	bsl.16b	v3, v4, v7
	str	q3, [sp, #3504]                 ; 16-byte Spill
	ldr	q3, [sp, #4384]                 ; 16-byte Reload
	ldr	q4, [sp, #3664]                 ; 16-byte Reload
	fsub.4s	v3, v3, v4
	and.16b	v6, v0, v3
	fcmge.4s	v3, v6, v11
	fcmge.4s	v4, v25, v6
	and.16b	v3, v3, v4
	ldr	q16, [sp, #4400]                ; 16-byte Reload
	ldr	q4, [sp, #3760]                 ; 16-byte Reload
	fsub.4s	v4, v16, v4
	and.16b	v21, v1, v4
	fcmge.4s	v4, v21, v11
	fcmge.4s	v16, v25, v21
	and.16b	v4, v4, v16
	and.16b	v4, v4, v21
	fmul.4s	v16, v4, v17
	mov.16b	v8, v22
	bsl.16b	v8, v23, v16
	fadd.4s	v16, v16, v8
	fsub.4s	v16, v16, v8
	and.16b	v3, v3, v6
	fmul.4s	v8, v3, v17
	mov.16b	v13, v22
	bsl.16b	v13, v23, v8
	fadd.4s	v8, v8, v13
	fsub.4s	v8, v8, v13
	fcvtzs.4s	v16, v16
	scvtf.4s	v13, v16
	fmul.4s	v14, v13, v9
	fsub.4s	v4, v4, v14
	fcvtzs.4s	v8, v8
	scvtf.4s	v14, v8
	fmul.4s	v15, v14, v9
	fsub.4s	v3, v3, v15
	fmul.4s	v14, v14, v5
	fsub.4s	v3, v3, v14
	fmul.4s	v13, v13, v5
	fsub.4s	v4, v4, v13
	fmul.4s	v13, v4, v12
	fadd.4s	v13, v13, v2
	fmul.4s	v13, v4, v13
	fadd.4s	v13, v13, v26
	fmul.4s	v13, v4, v13
	fadd.4s	v13, v13, v27
	fmul.4s	v13, v4, v13
	fadd.4s	v13, v13, v30
	fmul.4s	v13, v4, v13
	fadd.4s	v13, v13, v18
	fmul.4s	v14, v4, v4
	fmul.4s	v13, v14, v13
	fmul.4s	v14, v3, v12
	fadd.4s	v14, v14, v2
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v26
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v27
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v30
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v18
	fmul.4s	v15, v3, v3
	fmul.4s	v14, v15, v14
	fadd.4s	v3, v3, v14
	fadd.4s	v4, v4, v13
	fadd.4s	v3, v3, v19
	sshr.4s	v13, v8, #1
	shl.4s	v14, v13, #23
	add.4s	v14, v14, v19
	fmul.4s	v3, v3, v14
	fadd.4s	v4, v4, v19
	sshr.4s	v14, v16, #1
	shl.4s	v15, v14, #23
	add.4s	v15, v15, v19
	fmul.4s	v4, v4, v15
	sub.4s	v8, v8, v13
	sub.4s	v16, v16, v14
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v19
	fmul.4s	v4, v4, v16
	shl.4s	v16, v8, #23
	add.4s	v16, v16, v19
	fmul.4s	v3, v3, v16
	fcmgt.4s	v16, v11, v6
	bic.16b	v3, v3, v16
	fcmgt.4s	v16, v11, v21
	bic.16b	v4, v4, v16
	fcmgt.4s	v16, v21, v25
	bit.16b	v4, v31, v16
	fcmgt.4s	v16, v6, v25
	bit.16b	v3, v31, v16
	fcmeq.4s	v6, v6, v6
	bif.16b	v3, v7, v6
	str	q3, [sp, #3488]                 ; 16-byte Spill
	fcmeq.4s	v3, v21, v21
	bsl.16b	v3, v4, v7
	str	q3, [sp, #3472]                 ; 16-byte Spill
	ldr	q4, [sp, #4416]                 ; 16-byte Reload
	ldr	q3, [sp, #3648]                 ; 16-byte Reload
	fsub.4s	v3, v4, v3
	and.16b	v6, v0, v3
	fcmge.4s	v3, v6, v11
	fcmge.4s	v4, v25, v6
	and.16b	v3, v3, v4
	ldr	q16, [sp, #4432]                ; 16-byte Reload
	ldr	q4, [sp, #3744]                 ; 16-byte Reload
	fsub.4s	v4, v16, v4
	and.16b	v21, v1, v4
	fcmge.4s	v4, v21, v11
	fcmge.4s	v16, v25, v21
	and.16b	v4, v4, v16
	and.16b	v4, v4, v21
	fmul.4s	v16, v4, v17
	mvni.4s	v18, #128, lsl #24
	movi.4s	v22, #75, lsl #24
	mov.16b	v8, v18
	bsl.16b	v8, v22, v16
	fadd.4s	v16, v16, v8
	fsub.4s	v16, v16, v8
	and.16b	v3, v3, v6
	fmul.4s	v8, v3, v17
	mov.16b	v13, v18
	bsl.16b	v13, v22, v8
	mvni.4s	v22, #128, lsl #24
	fadd.4s	v8, v8, v13
	fsub.4s	v8, v8, v13
	fcvtzs.4s	v16, v16
	scvtf.4s	v13, v16
	fmul.4s	v14, v13, v9
	fsub.4s	v4, v4, v14
	fcvtzs.4s	v8, v8
	scvtf.4s	v14, v8
	fmul.4s	v15, v14, v9
	fsub.4s	v3, v3, v15
	fmul.4s	v14, v14, v5
	fsub.4s	v3, v3, v14
	fmul.4s	v13, v13, v5
	fsub.4s	v4, v4, v13
	fmul.4s	v13, v4, v12
	fadd.4s	v13, v13, v2
	fmul.4s	v13, v4, v13
	fadd.4s	v13, v13, v26
	fmul.4s	v13, v4, v13
	fadd.4s	v13, v13, v27
	fmul.4s	v13, v4, v13
	fadd.4s	v13, v13, v30
	fmul.4s	v13, v4, v13
	movi.4s	v18, #63, lsl #24
	fadd.4s	v13, v13, v18
	fmul.4s	v14, v4, v4
	fmul.4s	v13, v14, v13
	fmul.4s	v14, v3, v12
	fadd.4s	v14, v14, v2
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v26
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v27
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v30
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v18
	fmul.4s	v15, v3, v3
	fmul.4s	v14, v15, v14
	fadd.4s	v3, v3, v14
	fadd.4s	v4, v4, v13
	fadd.4s	v3, v3, v19
	sshr.4s	v13, v8, #1
	shl.4s	v14, v13, #23
	add.4s	v14, v14, v19
	fmul.4s	v3, v3, v14
	fadd.4s	v4, v4, v19
	sshr.4s	v14, v16, #1
	shl.4s	v15, v14, #23
	add.4s	v15, v15, v19
	fmul.4s	v4, v4, v15
	sub.4s	v8, v8, v13
	sub.4s	v16, v16, v14
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v19
	fmul.4s	v4, v4, v16
	shl.4s	v16, v8, #23
	add.4s	v16, v16, v19
	fmul.4s	v3, v3, v16
	fcmgt.4s	v16, v11, v6
	bic.16b	v3, v3, v16
	fcmgt.4s	v16, v11, v21
	bic.16b	v4, v4, v16
	fcmgt.4s	v16, v21, v25
	bit.16b	v4, v31, v16
	fcmgt.4s	v16, v6, v25
	bit.16b	v3, v31, v16
	fcmeq.4s	v6, v6, v6
	bif.16b	v3, v7, v6
	str	q3, [sp, #3456]                 ; 16-byte Spill
	fcmeq.4s	v3, v21, v21
	bsl.16b	v3, v4, v7
	str	q3, [sp, #3440]                 ; 16-byte Spill
	ldr	q4, [sp, #4464]                 ; 16-byte Reload
	ldr	q3, [sp, #3728]                 ; 16-byte Reload
	fsub.4s	v3, v4, v3
	and.16b	v6, v1, v3
	fcmge.4s	v3, v6, v11
	fcmge.4s	v4, v25, v6
	and.16b	v3, v3, v4
	ldr	q16, [sp, #4448]                ; 16-byte Reload
	ldr	q4, [sp, #3632]                 ; 16-byte Reload
	fsub.4s	v4, v16, v4
	and.16b	v21, v0, v4
	fcmge.4s	v4, v21, v11
	fcmge.4s	v16, v25, v21
	and.16b	v4, v4, v16
	and.16b	v4, v4, v21
	fmul.4s	v16, v4, v17
	mov.16b	v8, v22
	bsl.16b	v8, v23, v16
	fadd.4s	v16, v16, v8
	fsub.4s	v16, v16, v8
	and.16b	v3, v3, v6
	fmul.4s	v8, v3, v17
	mov.16b	v13, v22
	bsl.16b	v13, v23, v8
	fadd.4s	v8, v8, v13
	fsub.4s	v8, v8, v13
	fcvtzs.4s	v16, v16
	scvtf.4s	v13, v16
	fmul.4s	v14, v13, v9
	fsub.4s	v4, v4, v14
	fcvtzs.4s	v8, v8
	scvtf.4s	v14, v8
	fmul.4s	v15, v14, v9
	fsub.4s	v3, v3, v15
	str	q5, [sp, #2816]                 ; 16-byte Spill
	fmul.4s	v14, v14, v5
	fsub.4s	v3, v3, v14
	fmul.4s	v13, v13, v5
	fsub.4s	v4, v4, v13
	fmul.4s	v13, v4, v12
	fadd.4s	v13, v13, v2
	fmul.4s	v13, v4, v13
	fadd.4s	v13, v13, v26
	fmul.4s	v13, v4, v13
	fadd.4s	v13, v13, v27
	fmul.4s	v13, v4, v13
	fadd.4s	v13, v13, v30
	fmul.4s	v13, v4, v13
	fadd.4s	v13, v13, v18
	fmul.4s	v14, v4, v4
	fmul.4s	v13, v14, v13
	fmul.4s	v14, v3, v12
	fadd.4s	v14, v14, v2
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v26
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v27
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v30
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v18
	fmul.4s	v15, v3, v3
	fmul.4s	v14, v15, v14
	fadd.4s	v3, v3, v14
	fadd.4s	v4, v4, v13
	fadd.4s	v3, v3, v19
	sshr.4s	v13, v8, #1
	shl.4s	v14, v13, #23
	add.4s	v14, v14, v19
	fmul.4s	v3, v3, v14
	fadd.4s	v4, v4, v19
	sshr.4s	v14, v16, #1
	shl.4s	v15, v14, #23
	add.4s	v15, v15, v19
	fmul.4s	v4, v4, v15
	sub.4s	v8, v8, v13
	sub.4s	v16, v16, v14
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v19
	fmul.4s	v4, v4, v16
	shl.4s	v16, v8, #23
	add.4s	v16, v16, v19
	fmul.4s	v3, v3, v16
	fcmgt.4s	v16, v11, v6
	bic.16b	v3, v3, v16
	fcmgt.4s	v16, v11, v21
	bic.16b	v4, v4, v16
	fcmgt.4s	v16, v21, v25
	bit.16b	v4, v31, v16
	fcmgt.4s	v16, v6, v25
	bit.16b	v3, v31, v16
	fcmeq.4s	v6, v6, v6
	bif.16b	v3, v7, v6
	str	q3, [sp, #3424]                 ; 16-byte Spill
	fcmeq.4s	v3, v21, v21
	bsl.16b	v3, v4, v7
	str	q3, [sp, #3408]                 ; 16-byte Spill
	mov.16b	v23, v7
	ldr	q4, [sp, #4480]                 ; 16-byte Reload
	ldr	q3, [sp, #3616]                 ; 16-byte Reload
	fsub.4s	v3, v4, v3
	and.16b	v6, v0, v3
	fcmge.4s	v3, v6, v11
	fcmge.4s	v4, v25, v6
	and.16b	v3, v3, v4
	ldr	q5, [sp, #4496]                 ; 16-byte Reload
	ldr	q4, [sp, #3712]                 ; 16-byte Reload
	fsub.4s	v4, v5, v4
	and.16b	v21, v1, v4
	fcmge.4s	v4, v21, v11
	fcmge.4s	v16, v25, v21
	and.16b	v4, v4, v16
	and.16b	v4, v4, v21
	fmul.4s	v16, v4, v17
	mvni.4s	v7, #128, lsl #24
	movi.4s	v22, #75, lsl #24
	mov.16b	v8, v7
	bsl.16b	v8, v22, v16
	fadd.4s	v16, v16, v8
	fsub.4s	v16, v16, v8
	and.16b	v3, v3, v6
	fmul.4s	v8, v3, v17
	mov.16b	v13, v7
	bsl.16b	v13, v22, v8
	fadd.4s	v8, v8, v13
	fsub.4s	v8, v8, v13
	fcvtzs.4s	v16, v16
	scvtf.4s	v13, v16
	mov.16b	v18, v9
	fmul.4s	v14, v13, v9
	fsub.4s	v4, v4, v14
	fcvtzs.4s	v8, v8
	scvtf.4s	v14, v8
	fmul.4s	v15, v14, v9
	fsub.4s	v3, v3, v15
	ldr	q5, [sp, #2816]                 ; 16-byte Reload
	fmul.4s	v14, v14, v5
	fsub.4s	v3, v3, v14
	fmul.4s	v13, v13, v5
	fsub.4s	v4, v4, v13
	fmul.4s	v13, v4, v12
	fadd.4s	v13, v13, v2
	fmul.4s	v13, v4, v13
	fadd.4s	v13, v13, v26
	fmul.4s	v13, v4, v13
	fadd.4s	v13, v13, v27
	fmul.4s	v13, v4, v13
	fadd.4s	v13, v13, v30
	fmul.4s	v13, v4, v13
	movi.4s	v7, #63, lsl #24
	fadd.4s	v13, v13, v7
	fmul.4s	v14, v4, v4
	fmul.4s	v13, v14, v13
	fmul.4s	v14, v3, v12
	fadd.4s	v14, v14, v2
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v26
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v27
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v30
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v7
	fmul.4s	v15, v3, v3
	fmul.4s	v14, v15, v14
	fadd.4s	v3, v3, v14
	fadd.4s	v4, v4, v13
	fadd.4s	v3, v3, v19
	sshr.4s	v13, v8, #1
	shl.4s	v14, v13, #23
	add.4s	v14, v14, v19
	fmul.4s	v3, v3, v14
	fadd.4s	v4, v4, v19
	sshr.4s	v14, v16, #1
	shl.4s	v15, v14, #23
	add.4s	v15, v15, v19
	fmul.4s	v4, v4, v15
	sub.4s	v8, v8, v13
	sub.4s	v16, v16, v14
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v19
	fmul.4s	v4, v4, v16
	shl.4s	v16, v8, #23
	add.4s	v16, v16, v19
	fmul.4s	v3, v3, v16
	fcmgt.4s	v16, v11, v6
	bic.16b	v3, v3, v16
	fcmgt.4s	v16, v11, v21
	bic.16b	v4, v4, v16
	fcmgt.4s	v16, v21, v25
	bit.16b	v4, v31, v16
	fcmgt.4s	v16, v6, v25
	bit.16b	v3, v31, v16
	fcmeq.4s	v6, v6, v6
	mov.16b	v22, v23
	bif.16b	v3, v23, v6
	str	q3, [sp, #3392]                 ; 16-byte Spill
	fcmeq.4s	v3, v21, v21
	bit.16b	v23, v4, v3
	ldr	q4, [sp, #4304]                 ; 16-byte Reload
	ldr	q3, [sp, #3600]                 ; 16-byte Reload
	fsub.4s	v3, v4, v3
	and.16b	v6, v0, v3
	fcmge.4s	v3, v6, v11
	fcmge.4s	v4, v25, v6
	and.16b	v3, v3, v4
	ldr	q4, [sp, #3696]                 ; 16-byte Reload
	ldr	q7, [sp, #4288]                 ; 16-byte Reload
	fsub.4s	v4, v7, v4
	and.16b	v21, v1, v4
	fcmge.4s	v4, v21, v11
	fcmge.4s	v16, v25, v21
	and.16b	v4, v4, v16
	and.16b	v4, v4, v21
	fmul.4s	v16, v4, v17
	movi.4s	v13, #75, lsl #24
	mvni.4s	v14, #128, lsl #24
	mov.16b	v8, v14
	bsl.16b	v8, v13, v16
	fadd.4s	v16, v16, v8
	fsub.4s	v16, v16, v8
	and.16b	v3, v3, v6
	fmul.4s	v8, v3, v17
	movi.4s	v9, #75, lsl #24
	mvni.4s	v7, #128, lsl #24
	bif.16b	v13, v8, v14
	fadd.4s	v8, v8, v13
	fsub.4s	v8, v8, v13
	fcvtzs.4s	v16, v16
	scvtf.4s	v13, v16
	fmul.4s	v14, v13, v18
	fsub.4s	v4, v4, v14
	fcvtzs.4s	v8, v8
	scvtf.4s	v14, v8
	fmul.4s	v15, v14, v18
	fsub.4s	v3, v3, v15
	fmul.4s	v13, v13, v5
	fmul.4s	v14, v14, v5
	fsub.4s	v3, v3, v14
	fsub.4s	v4, v4, v13
	fmul.4s	v13, v4, v12
	fadd.4s	v13, v13, v2
	fmul.4s	v13, v4, v13
	fadd.4s	v13, v13, v26
	fmul.4s	v13, v4, v13
	fadd.4s	v13, v13, v27
	fmul.4s	v13, v4, v13
	fadd.4s	v13, v13, v30
	fmul.4s	v13, v4, v13
	movi.4s	v18, #63, lsl #24
	fadd.4s	v13, v13, v18
	fmul.4s	v14, v4, v4
	fmul.4s	v13, v14, v13
	fmul.4s	v14, v3, v12
	fadd.4s	v14, v14, v2
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v26
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v27
	fmul.4s	v14, v3, v14
	fadd.4s	v14, v14, v30
	fmul.4s	v14, v3, v14
	movi.4s	v5, #63, lsl #24
	fadd.4s	v14, v14, v18
	fmul.4s	v15, v3, v3
	fmul.4s	v14, v15, v14
	fadd.4s	v3, v3, v14
	fadd.4s	v4, v4, v13
	fadd.4s	v3, v3, v19
	sshr.4s	v13, v8, #1
	shl.4s	v14, v13, #23
	add.4s	v14, v14, v19
	fmul.4s	v3, v3, v14
	fadd.4s	v4, v4, v19
	sshr.4s	v14, v16, #1
	shl.4s	v15, v14, #23
	add.4s	v15, v15, v19
	fmul.4s	v4, v4, v15
	sub.4s	v8, v8, v13
	ldr	x8, [sp, #648]                  ; 8-byte Reload
	ldp	q15, q13, [x8]
	ldr	q18, [sp, #3568]                ; 16-byte Reload
	bit.16b	v13, v18, v0
	ldr	q18, [sp, #3584]                ; 16-byte Reload
	bit.16b	v15, v18, v1
	stp	q15, q13, [x8]
	sub.4s	v16, v16, v14
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v19
	fmul.4s	v4, v4, v16
	ldr	x8, [sp, #640]                  ; 8-byte Reload
	ldp	q16, q13, [x8]
	ldr	q18, [sp, #3536]                ; 16-byte Reload
	bit.16b	v16, v18, v1
	ldr	q18, [sp, #3552]                ; 16-byte Reload
	bit.16b	v13, v18, v0
	stp	q16, q13, [x8]
	shl.4s	v16, v8, #23
	add.4s	v16, v16, v19
	fmul.4s	v3, v3, v16
	ldr	x8, [sp, #632]                  ; 8-byte Reload
	ldp	q16, q8, [x8]
	ldr	q18, [sp, #3504]                ; 16-byte Reload
	bit.16b	v16, v18, v1
	ldr	q18, [sp, #3520]                ; 16-byte Reload
	bit.16b	v8, v18, v0
	stp	q16, q8, [x8]
	fcmgt.4s	v16, v11, v6
	bic.16b	v3, v3, v16
	fcmgt.4s	v16, v11, v21
	bic.16b	v4, v4, v16
	ldr	x8, [sp, #624]                  ; 8-byte Reload
	ldp	q16, q8, [x8]
	ldr	q18, [sp, #3472]                ; 16-byte Reload
	bit.16b	v16, v18, v1
	ldr	q18, [sp, #3488]                ; 16-byte Reload
	bit.16b	v8, v18, v0
	stp	q16, q8, [x8]
	fcmgt.4s	v16, v21, v25
	bit.16b	v4, v31, v16
	fcmgt.4s	v16, v6, v25
	bit.16b	v3, v31, v16
	ldr	x8, [sp, #616]                  ; 8-byte Reload
	ldp	q16, q8, [x8]
	ldr	q18, [sp, #3440]                ; 16-byte Reload
	bit.16b	v16, v18, v1
	ldr	q18, [sp, #3456]                ; 16-byte Reload
	bit.16b	v8, v18, v0
	stp	q16, q8, [x8]
	fcmeq.4s	v6, v6, v6
	bsl.16b	v6, v3, v22
	fcmeq.4s	v3, v21, v21
	mov.16b	v16, v3
	bsl.16b	v16, v4, v22
	ldr	x8, [sp, #608]                  ; 8-byte Reload
	ldr	q3, [x8, #16]
	ldr	q4, [sp, #3408]                 ; 16-byte Reload
	bit.16b	v3, v4, v0
	ldr	q4, [x8]
	ldr	q18, [sp, #3424]                ; 16-byte Reload
	bit.16b	v4, v18, v1
	stp	q4, q3, [x8]
	ldr	x8, [sp, #600]                  ; 8-byte Reload
	ldp	q3, q4, [x8]
	str	q23, [sp, #2816]                ; 16-byte Spill
	bit.16b	v3, v23, v1
	ldr	q18, [sp, #3392]                ; 16-byte Reload
	bit.16b	v4, v18, v0
	stp	q3, q4, [x8]
	ldr	x8, [sp, #592]                  ; 8-byte Reload
	ldp	q3, q4, [x8]
	str	q16, [sp, #2784]                ; 16-byte Spill
	bit.16b	v3, v16, v1
	str	q6, [sp, #2800]                 ; 16-byte Spill
	bit.16b	v4, v6, v0
	stp	q3, q4, [x8]
	sshll.2d	v3, v0, #0
	ldr	q6, [sp, #2592]                 ; 16-byte Reload
	ldr	q4, [sp, #5760]                 ; 16-byte Reload
	bit.16b	v4, v6, v3
	str	q4, [sp, #5760]                 ; 16-byte Spill
	ldr	q4, [sp, #4192]                 ; 16-byte Reload
	bit.16b	v20, v4, v3
	sshll.2d	v3, v1, #0
	ldr	q4, [sp, #5792]                 ; 16-byte Reload
	bit.16b	v4, v6, v3
	str	q4, [sp, #5792]                 ; 16-byte Spill
	ldr	q4, [sp, #4176]                 ; 16-byte Reload
	bit.16b	v28, v4, v3
	ldr	q4, [sp, #4512]                 ; 16-byte Reload
	ldr	q23, [sp, #2768]                ; 16-byte Reload
	bit.16b	v23, v6, v4
	ldr	q3, [sp, #4528]                 ; 16-byte Reload
	ldr	q16, [sp, #5776]                ; 16-byte Reload
	bit.16b	v16, v6, v3
	str	q16, [sp, #5776]                ; 16-byte Spill
	ldr	q6, [sp, #4224]                 ; 16-byte Reload
	bit.16b	v24, v6, v4
	ldr	q4, [sp, #4208]                 ; 16-byte Reload
	bit.16b	v29, v4, v3
	mov	w1, #29184                      ; =0x7200
	movk	w1, #48945, lsl #16
	mov	w3, #48782                      ; =0xbe8e
	movk	w3, #46527, lsl #16
	b	LBB0_502
LBB0_501:                               ; %else1344
                                        ;   in Loop: Header=BB0_502 Depth=2
	add	x25, x25, #1
	add	x23, x23, #4
	add	x22, x22, #8
	add	x21, x21, #2
	cmp	x23, #512
	b.eq	LBB0_534
LBB0_502:                               ; %direct.true632
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w8, s10
	and	x16, x22, #0x78
	orr	x16, x16, x25, lsr #4
	dup.2d	v16, x16
	ldr	q3, [sp, #5680]                 ; 16-byte Reload
	orr.16b	v3, v16, v3
	ldr	q4, [sp, #5744]                 ; 16-byte Reload
	add.2d	v21, v4, v3
	tbz	w8, #0, LBB0_504
; %bb.503:                              ; %cond.load1264
                                        ;   in Loop: Header=BB0_502 Depth=2
	fmov	x16, d21
	ldr	b6, [x16]
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_505
	b	LBB0_506
LBB0_504:                               ;   in Loop: Header=BB0_502 Depth=2
	movi.2d	v6, #0000000000000000
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_506
LBB0_505:                               ; %cond.load1270
                                        ;   in Loop: Header=BB0_502 Depth=2
	mov.d	x16, v21[1]
	ld1.b	{ v6 }[1], [x16]
LBB0_506:                               ; %else1274
                                        ;   in Loop: Header=BB0_502 Depth=2
	ldr	q3, [sp, #5664]                 ; 16-byte Reload
	orr.16b	v3, v16, v3
	ldr	q4, [sp, #5728]                 ; 16-byte Reload
	add.2d	v21, v4, v3
	tbz	w8, #2, LBB0_512
; %bb.507:                              ; %cond.load1276
                                        ;   in Loop: Header=BB0_502 Depth=2
	fmov	x16, d21
	ld1.b	{ v6 }[2], [x16]
	tbnz	w8, #3, LBB0_513
LBB0_508:                               ; %else1286
                                        ;   in Loop: Header=BB0_502 Depth=2
	ldr	q3, [sp, #5648]                 ; 16-byte Reload
	orr.16b	v3, v16, v3
	ldr	q4, [sp, #5712]                 ; 16-byte Reload
	add.2d	v21, v4, v3
	tbz	w8, #4, LBB0_514
LBB0_509:                               ; %cond.load1288
                                        ;   in Loop: Header=BB0_502 Depth=2
	fmov	x16, d21
	ld1.b	{ v6 }[4], [x16]
	tbnz	w8, #5, LBB0_515
LBB0_510:                               ; %else1298
                                        ;   in Loop: Header=BB0_502 Depth=2
	ldr	q3, [sp, #5632]                 ; 16-byte Reload
	orr.16b	v3, v16, v3
	ldr	q4, [sp, #5696]                 ; 16-byte Reload
	add.2d	v16, v4, v3
	tbz	w8, #6, LBB0_516
LBB0_511:                               ; %cond.load1300
                                        ;   in Loop: Header=BB0_502 Depth=2
	fmov	x16, d16
	ld1.b	{ v6 }[6], [x16]
	tbnz	w8, #7, LBB0_517
	b	LBB0_518
LBB0_512:                               ; %else1280
                                        ;   in Loop: Header=BB0_502 Depth=2
	tbz	w8, #3, LBB0_508
LBB0_513:                               ; %cond.load1282
                                        ;   in Loop: Header=BB0_502 Depth=2
	mov.d	x16, v21[1]
	ld1.b	{ v6 }[3], [x16]
	ldr	q3, [sp, #5648]                 ; 16-byte Reload
	orr.16b	v3, v16, v3
	ldr	q4, [sp, #5712]                 ; 16-byte Reload
	add.2d	v21, v4, v3
	tbnz	w8, #4, LBB0_509
LBB0_514:                               ; %else1292
                                        ;   in Loop: Header=BB0_502 Depth=2
	tbz	w8, #5, LBB0_510
LBB0_515:                               ; %cond.load1294
                                        ;   in Loop: Header=BB0_502 Depth=2
	mov.d	x16, v21[1]
	ld1.b	{ v6 }[5], [x16]
	ldr	q3, [sp, #5632]                 ; 16-byte Reload
	orr.16b	v3, v16, v3
	ldr	q4, [sp, #5696]                 ; 16-byte Reload
	add.2d	v16, v4, v3
	tbnz	w8, #6, LBB0_511
LBB0_516:                               ; %else1304
                                        ;   in Loop: Header=BB0_502 Depth=2
	tbz	w8, #7, LBB0_518
LBB0_517:                               ; %cond.load1306
                                        ;   in Loop: Header=BB0_502 Depth=2
	mov.d	x8, v16[1]
	ld1.b	{ v6 }[7], [x8]
LBB0_518:                               ; %else1310
                                        ;   in Loop: Header=BB0_502 Depth=2
	fmov	w8, s10
	cmeq.8b	v3, v6, #0
	sshll.8h	v16, v3, #0
	sshll.4s	v3, v16, #0
	add	x16, x6, x25, lsl #5
	ldp	q4, q21, [x16]
	and	x16, x21, #0xe0
	add	x16, x7, x16
	ldp	q6, q15, [x16]
	fsub.4s	v4, v4, v6
	and.16b	v4, v1, v4
	fcmge.4s	v6, v4, v11
	fcmge.4s	v8, v25, v4
	and.16b	v6, v6, v8
	and.16b	v6, v6, v4
	fmul.4s	v8, v6, v17
	mov.16b	v13, v7
	bsl.16b	v13, v9, v8
	fadd.4s	v8, v8, v13
	fsub.4s	v8, v8, v13
	fcvtzs.4s	v14, v8
	scvtf.4s	v18, v14
	dup.4s	v8, w1
	fmul.4s	v19, v18, v8
	dup.4s	v13, w3
	fadd.4s	v6, v6, v19
	fmul.4s	v18, v18, v13
	fadd.4s	v6, v6, v18
	fmul.4s	v18, v6, v12
	fadd.4s	v18, v18, v2
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v26
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v27
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v30
	fmul.4s	v18, v6, v18
	fadd.4s	v18, v18, v5
	fmul.4s	v19, v6, v6
	fmul.4s	v18, v19, v18
	fadd.4s	v6, v6, v18
	fmov.4s	v22, #1.00000000
	fadd.4s	v6, v6, v22
	sshr.4s	v18, v14, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v22
	fmul.4s	v6, v6, v19
	sub.4s	v18, v14, v18
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v22
	fmul.4s	v6, v6, v18
	fcmgt.4s	v18, v11, v4
	bic.16b	v6, v6, v18
	fcmgt.4s	v18, v4, v25
	bit.16b	v6, v31, v18
	fcmeq.4s	v4, v4, v4
	ldr	q18, [sp, #5392]                ; 16-byte Reload
	bsl.16b	v4, v6, v18
	bic.16b	v14, v4, v3
	dup.2d	v6, x23
	orr.16b	v3, v6, v28
	ldr	q4, [sp, #5792]                 ; 16-byte Reload
	add.2d	v3, v4, v3
	tbz	w8, #0, LBB0_522
; %bb.519:                              ; %cond.store1313
                                        ;   in Loop: Header=BB0_502 Depth=2
	fmov	x16, d3
	str	s14, [x16]
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_523
LBB0_520:                               ; %else1320
                                        ;   in Loop: Header=BB0_502 Depth=2
	orr.16b	v3, v6, v29
	ldr	q4, [sp, #5776]                 ; 16-byte Reload
	add.2d	v3, v4, v3
	tbz	w8, #2, LBB0_524
LBB0_521:                               ; %cond.store1321
                                        ;   in Loop: Header=BB0_502 Depth=2
	fmov	x16, d3
	st1.s	{ v14 }[2], [x16]
	tbnz	w8, #3, LBB0_525
	b	LBB0_526
LBB0_522:                               ; %else1316
                                        ;   in Loop: Header=BB0_502 Depth=2
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_520
LBB0_523:                               ; %cond.store1317
                                        ;   in Loop: Header=BB0_502 Depth=2
	mov.d	x16, v3[1]
	st1.s	{ v14 }[1], [x16]
	orr.16b	v3, v6, v29
	ldr	q4, [sp, #5776]                 ; 16-byte Reload
	add.2d	v3, v4, v3
	tbnz	w8, #2, LBB0_521
LBB0_524:                               ; %else1324
                                        ;   in Loop: Header=BB0_502 Depth=2
	tbz	w8, #3, LBB0_526
LBB0_525:                               ; %cond.store1325
                                        ;   in Loop: Header=BB0_502 Depth=2
	mov.d	x16, v3[1]
	st1.s	{ v14 }[3], [x16]
LBB0_526:                               ; %else1328
                                        ;   in Loop: Header=BB0_502 Depth=2
	sshll2.4s	v3, v16, #0
	fsub.4s	v4, v21, v15
	and.16b	v4, v0, v4
	fcmge.4s	v16, v4, v11
	fcmge.4s	v18, v25, v4
	and.16b	v16, v16, v18
	and.16b	v16, v16, v4
	fmul.4s	v18, v16, v17
	mov.16b	v19, v7
	bsl.16b	v19, v9, v18
	fadd.4s	v18, v18, v19
	fsub.4s	v18, v18, v19
	fcvtzs.4s	v18, v18
	scvtf.4s	v19, v18
	fmul.4s	v21, v19, v8
	fadd.4s	v16, v16, v21
	fmul.4s	v19, v19, v13
	fadd.4s	v16, v16, v19
	fmul.4s	v19, v16, v12
	fadd.4s	v19, v19, v2
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v26
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v27
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v30
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v5
	fmul.4s	v21, v16, v16
	fmul.4s	v19, v21, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v16, v16, v22
	sshr.4s	v19, v18, #1
	shl.4s	v21, v19, #23
	add.4s	v21, v21, v22
	fmul.4s	v16, v16, v21
	sub.4s	v18, v18, v19
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v22
	fmul.4s	v16, v16, v18
	fcmgt.4s	v18, v11, v4
	bic.16b	v16, v16, v18
	fcmgt.4s	v18, v4, v25
	bit.16b	v16, v31, v18
	fcmeq.4s	v4, v4, v4
	ldr	q18, [sp, #5392]                ; 16-byte Reload
	bsl.16b	v4, v16, v18
	bic.16b	v16, v4, v3
	orr.16b	v3, v6, v20
	ldr	q4, [sp, #5760]                 ; 16-byte Reload
	add.2d	v3, v4, v3
	tbz	w8, #4, LBB0_530
; %bb.527:                              ; %cond.store1329
                                        ;   in Loop: Header=BB0_502 Depth=2
	fmov	x16, d3
	str	s16, [x16]
	ldr	q15, [sp, #4992]                ; 16-byte Reload
	tbnz	w8, #5, LBB0_531
LBB0_528:                               ; %else1336
                                        ;   in Loop: Header=BB0_502 Depth=2
	orr.16b	v3, v6, v24
	add.2d	v3, v23, v3
	tbz	w8, #6, LBB0_532
LBB0_529:                               ; %cond.store1337
                                        ;   in Loop: Header=BB0_502 Depth=2
	fmov	x16, d3
	st1.s	{ v16 }[2], [x16]
	tbz	w8, #7, LBB0_501
	b	LBB0_533
LBB0_530:                               ; %else1332
                                        ;   in Loop: Header=BB0_502 Depth=2
	ldr	q15, [sp, #4992]                ; 16-byte Reload
	tbz	w8, #5, LBB0_528
LBB0_531:                               ; %cond.store1333
                                        ;   in Loop: Header=BB0_502 Depth=2
	mov.d	x16, v3[1]
	st1.s	{ v16 }[1], [x16]
	orr.16b	v3, v6, v24
	add.2d	v3, v23, v3
	tbnz	w8, #6, LBB0_529
LBB0_532:                               ; %else1340
                                        ;   in Loop: Header=BB0_502 Depth=2
	tbz	w8, #7, LBB0_501
LBB0_533:                               ; %cond.store1341
                                        ;   in Loop: Header=BB0_502 Depth=2
	mov.d	x8, v3[1]
	st1.s	{ v16 }[3], [x8]
	b	LBB0_501
LBB0_534:                               ; %direct.false633
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q19, [sp, #2528]                ; 16-byte Reload
	ldr	q2, [sp, #5408]                 ; 16-byte Reload
	and.16b	v2, v19, v2
	str	q2, [sp, #5408]                 ; 16-byte Spill
	ldr	q21, [sp, #2512]                ; 16-byte Reload
	ldr	q2, [sp, #5424]                 ; 16-byte Reload
	and.16b	v2, v21, v2
	str	q2, [sp, #5424]                 ; 16-byte Spill
	ldr	q4, [sp, #4528]                 ; 16-byte Reload
	ldr	q18, [sp, #4512]                ; 16-byte Reload
	mov	w3, #320                        ; =0x140
	ldr	q22, [sp, #2944]                ; 16-byte Reload
	ldr	q9, [sp, #2928]                 ; 16-byte Reload
	ldr	q25, [sp, #3232]                ; 16-byte Reload
	ldr	q26, [sp, #3216]                ; 16-byte Reload
	ldr	q27, [sp, #3200]                ; 16-byte Reload
	ldr	q30, [sp, #3376]                ; 16-byte Reload
	ldr	q31, [sp, #3184]                ; 16-byte Reload
	ldr	q8, [sp, #3168]                 ; 16-byte Reload
	ldr	q11, [sp, #3152]                ; 16-byte Reload
	ldr	q12, [sp, #3360]                ; 16-byte Reload
	ldr	q14, [sp, #3776]                ; 16-byte Reload
	b	LBB0_536
LBB0_535:                               ; %else1392
                                        ;   in Loop: Header=BB0_536 Depth=2
	ldr	q16, [sp, #5424]                ; 16-byte Reload
	fadd.4s	v2, v16, v2
	ldr	q17, [sp, #5408]                ; 16-byte Reload
	fadd.4s	v3, v17, v6
	bit.16b	v17, v3, v0
	str	q17, [sp, #5408]                ; 16-byte Spill
	bit.16b	v16, v2, v1
	str	q16, [sp, #5424]                ; 16-byte Spill
	add	x8, x8, #4
	cmp	x8, #64
	b.eq	LBB0_552
LBB0_536:                               ; %direct.true672
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w16, s10
	dup.2d	v17, x8
	orr.16b	v2, v17, v28
	ldr	q3, [sp, #5792]                 ; 16-byte Reload
	add.2d	v16, v3, v2
	movi.2d	v2, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbz	w16, #0, LBB0_544
; %bb.537:                              ; %cond.load1346
                                        ;   in Loop: Header=BB0_536 Depth=2
	fmov	x1, d16
	ldr	s2, [x1]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_545
LBB0_538:                               ; %else1356
                                        ;   in Loop: Header=BB0_536 Depth=2
	orr.16b	v3, v17, v29
	ldr	q16, [sp, #5776]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbz	w16, #2, LBB0_546
LBB0_539:                               ; %cond.load1358
                                        ;   in Loop: Header=BB0_536 Depth=2
	fmov	x1, d16
	ld1.s	{ v2 }[2], [x1]
	tbnz	w16, #3, LBB0_547
LBB0_540:                               ; %else1368
                                        ;   in Loop: Header=BB0_536 Depth=2
	orr.16b	v3, v17, v20
	ldr	q16, [sp, #5760]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbz	w16, #4, LBB0_548
LBB0_541:                               ; %cond.load1370
                                        ;   in Loop: Header=BB0_536 Depth=2
	fmov	x1, d16
	ld1.s	{ v6 }[0], [x1]
	tbnz	w16, #5, LBB0_549
LBB0_542:                               ; %else1380
                                        ;   in Loop: Header=BB0_536 Depth=2
	orr.16b	v3, v17, v24
	add.2d	v16, v23, v3
	tbz	w16, #6, LBB0_550
LBB0_543:                               ; %cond.load1382
                                        ;   in Loop: Header=BB0_536 Depth=2
	fmov	x1, d16
	ld1.s	{ v6 }[2], [x1]
	tbz	w16, #7, LBB0_535
	b	LBB0_551
LBB0_544:                               ; %else1350
                                        ;   in Loop: Header=BB0_536 Depth=2
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_538
LBB0_545:                               ; %cond.load1352
                                        ;   in Loop: Header=BB0_536 Depth=2
	mov.d	x1, v16[1]
	ld1.s	{ v2 }[1], [x1]
	orr.16b	v3, v17, v29
	ldr	q16, [sp, #5776]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbnz	w16, #2, LBB0_539
LBB0_546:                               ; %else1362
                                        ;   in Loop: Header=BB0_536 Depth=2
	tbz	w16, #3, LBB0_540
LBB0_547:                               ; %cond.load1364
                                        ;   in Loop: Header=BB0_536 Depth=2
	mov.d	x1, v16[1]
	ld1.s	{ v2 }[3], [x1]
	orr.16b	v3, v17, v20
	ldr	q16, [sp, #5760]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbnz	w16, #4, LBB0_541
LBB0_548:                               ; %else1374
                                        ;   in Loop: Header=BB0_536 Depth=2
	tbz	w16, #5, LBB0_542
LBB0_549:                               ; %cond.load1376
                                        ;   in Loop: Header=BB0_536 Depth=2
	mov.d	x1, v16[1]
	ld1.s	{ v6 }[1], [x1]
	orr.16b	v3, v17, v24
	add.2d	v16, v23, v3
	tbnz	w16, #6, LBB0_543
LBB0_550:                               ; %else1386
                                        ;   in Loop: Header=BB0_536 Depth=2
	tbz	w16, #7, LBB0_535
LBB0_551:                               ; %cond.load1388
                                        ;   in Loop: Header=BB0_536 Depth=2
	mov.d	x16, v16[1]
	ld1.s	{ v6 }[3], [x16]
	b	LBB0_535
LBB0_552:                               ; %direct.false673
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q2, [sp, #5440]                 ; 16-byte Reload
	and.16b	v2, v19, v2
	str	q2, [sp, #5440]                 ; 16-byte Spill
	ldr	q2, [sp, #5456]                 ; 16-byte Reload
	and.16b	v2, v21, v2
	str	q2, [sp, #5456]                 ; 16-byte Spill
	b	LBB0_554
LBB0_553:                               ; %else1441
                                        ;   in Loop: Header=BB0_554 Depth=2
	ldr	q16, [sp, #5456]                ; 16-byte Reload
	fadd.4s	v2, v16, v2
	ldr	q17, [sp, #5440]                ; 16-byte Reload
	fadd.4s	v3, v17, v6
	bit.16b	v17, v3, v0
	str	q17, [sp, #5440]                ; 16-byte Spill
	bit.16b	v16, v2, v1
	str	q16, [sp, #5456]                ; 16-byte Spill
	add	x8, x8, #4
	cmp	x8, #64
	b.eq	LBB0_570
LBB0_554:                               ; %direct.true682
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w16, s10
	orr	x1, x8, #0x40
	dup.2d	v17, x1
	orr.16b	v2, v17, v28
	ldr	q3, [sp, #5792]                 ; 16-byte Reload
	add.2d	v16, v3, v2
	movi.2d	v2, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbz	w16, #0, LBB0_562
; %bb.555:                              ; %cond.load1395
                                        ;   in Loop: Header=BB0_554 Depth=2
	fmov	x1, d16
	ldr	s2, [x1]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_563
LBB0_556:                               ; %else1405
                                        ;   in Loop: Header=BB0_554 Depth=2
	orr.16b	v3, v17, v29
	ldr	q16, [sp, #5776]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbz	w16, #2, LBB0_564
LBB0_557:                               ; %cond.load1407
                                        ;   in Loop: Header=BB0_554 Depth=2
	fmov	x1, d16
	ld1.s	{ v2 }[2], [x1]
	tbnz	w16, #3, LBB0_565
LBB0_558:                               ; %else1417
                                        ;   in Loop: Header=BB0_554 Depth=2
	orr.16b	v3, v17, v20
	ldr	q16, [sp, #5760]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbz	w16, #4, LBB0_566
LBB0_559:                               ; %cond.load1419
                                        ;   in Loop: Header=BB0_554 Depth=2
	fmov	x1, d16
	ld1.s	{ v6 }[0], [x1]
	tbnz	w16, #5, LBB0_567
LBB0_560:                               ; %else1429
                                        ;   in Loop: Header=BB0_554 Depth=2
	orr.16b	v3, v17, v24
	add.2d	v16, v23, v3
	tbz	w16, #6, LBB0_568
LBB0_561:                               ; %cond.load1431
                                        ;   in Loop: Header=BB0_554 Depth=2
	fmov	x1, d16
	ld1.s	{ v6 }[2], [x1]
	tbz	w16, #7, LBB0_553
	b	LBB0_569
LBB0_562:                               ; %else1399
                                        ;   in Loop: Header=BB0_554 Depth=2
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_556
LBB0_563:                               ; %cond.load1401
                                        ;   in Loop: Header=BB0_554 Depth=2
	mov.d	x1, v16[1]
	ld1.s	{ v2 }[1], [x1]
	orr.16b	v3, v17, v29
	ldr	q16, [sp, #5776]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbnz	w16, #2, LBB0_557
LBB0_564:                               ; %else1411
                                        ;   in Loop: Header=BB0_554 Depth=2
	tbz	w16, #3, LBB0_558
LBB0_565:                               ; %cond.load1413
                                        ;   in Loop: Header=BB0_554 Depth=2
	mov.d	x1, v16[1]
	ld1.s	{ v2 }[3], [x1]
	orr.16b	v3, v17, v20
	ldr	q16, [sp, #5760]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbnz	w16, #4, LBB0_559
LBB0_566:                               ; %else1423
                                        ;   in Loop: Header=BB0_554 Depth=2
	tbz	w16, #5, LBB0_560
LBB0_567:                               ; %cond.load1425
                                        ;   in Loop: Header=BB0_554 Depth=2
	mov.d	x1, v16[1]
	ld1.s	{ v6 }[1], [x1]
	orr.16b	v3, v17, v24
	add.2d	v16, v23, v3
	tbnz	w16, #6, LBB0_561
LBB0_568:                               ; %else1435
                                        ;   in Loop: Header=BB0_554 Depth=2
	tbz	w16, #7, LBB0_553
LBB0_569:                               ; %cond.load1437
                                        ;   in Loop: Header=BB0_554 Depth=2
	mov.d	x16, v16[1]
	ld1.s	{ v6 }[3], [x16]
	b	LBB0_553
LBB0_570:                               ; %direct.false683
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q2, [sp, #5472]                 ; 16-byte Reload
	and.16b	v2, v19, v2
	str	q2, [sp, #5472]                 ; 16-byte Spill
	ldr	q2, [sp, #5488]                 ; 16-byte Reload
	and.16b	v2, v21, v2
	str	q2, [sp, #5488]                 ; 16-byte Spill
	b	LBB0_572
LBB0_571:                               ; %else1490
                                        ;   in Loop: Header=BB0_572 Depth=2
	ldr	q16, [sp, #5488]                ; 16-byte Reload
	fadd.4s	v2, v16, v2
	ldr	q17, [sp, #5472]                ; 16-byte Reload
	fadd.4s	v3, v17, v6
	bit.16b	v17, v3, v0
	str	q17, [sp, #5472]                ; 16-byte Spill
	bit.16b	v16, v2, v1
	str	q16, [sp, #5488]                ; 16-byte Spill
	add	x8, x8, #4
	cmp	x8, #64
	b.eq	LBB0_588
LBB0_572:                               ; %direct.true692
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w16, s10
	orr	x1, x8, #0x80
	dup.2d	v17, x1
	orr.16b	v2, v17, v28
	ldr	q3, [sp, #5792]                 ; 16-byte Reload
	add.2d	v16, v3, v2
	movi.2d	v2, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbz	w16, #0, LBB0_580
; %bb.573:                              ; %cond.load1444
                                        ;   in Loop: Header=BB0_572 Depth=2
	fmov	x1, d16
	ldr	s2, [x1]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_581
LBB0_574:                               ; %else1454
                                        ;   in Loop: Header=BB0_572 Depth=2
	orr.16b	v3, v17, v29
	ldr	q16, [sp, #5776]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbz	w16, #2, LBB0_582
LBB0_575:                               ; %cond.load1456
                                        ;   in Loop: Header=BB0_572 Depth=2
	fmov	x1, d16
	ld1.s	{ v2 }[2], [x1]
	tbnz	w16, #3, LBB0_583
LBB0_576:                               ; %else1466
                                        ;   in Loop: Header=BB0_572 Depth=2
	orr.16b	v3, v17, v20
	ldr	q16, [sp, #5760]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbz	w16, #4, LBB0_584
LBB0_577:                               ; %cond.load1468
                                        ;   in Loop: Header=BB0_572 Depth=2
	fmov	x1, d16
	ld1.s	{ v6 }[0], [x1]
	tbnz	w16, #5, LBB0_585
LBB0_578:                               ; %else1478
                                        ;   in Loop: Header=BB0_572 Depth=2
	orr.16b	v3, v17, v24
	add.2d	v16, v23, v3
	tbz	w16, #6, LBB0_586
LBB0_579:                               ; %cond.load1480
                                        ;   in Loop: Header=BB0_572 Depth=2
	fmov	x1, d16
	ld1.s	{ v6 }[2], [x1]
	tbz	w16, #7, LBB0_571
	b	LBB0_587
LBB0_580:                               ; %else1448
                                        ;   in Loop: Header=BB0_572 Depth=2
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_574
LBB0_581:                               ; %cond.load1450
                                        ;   in Loop: Header=BB0_572 Depth=2
	mov.d	x1, v16[1]
	ld1.s	{ v2 }[1], [x1]
	orr.16b	v3, v17, v29
	ldr	q16, [sp, #5776]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbnz	w16, #2, LBB0_575
LBB0_582:                               ; %else1460
                                        ;   in Loop: Header=BB0_572 Depth=2
	tbz	w16, #3, LBB0_576
LBB0_583:                               ; %cond.load1462
                                        ;   in Loop: Header=BB0_572 Depth=2
	mov.d	x1, v16[1]
	ld1.s	{ v2 }[3], [x1]
	orr.16b	v3, v17, v20
	ldr	q16, [sp, #5760]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbnz	w16, #4, LBB0_577
LBB0_584:                               ; %else1472
                                        ;   in Loop: Header=BB0_572 Depth=2
	tbz	w16, #5, LBB0_578
LBB0_585:                               ; %cond.load1474
                                        ;   in Loop: Header=BB0_572 Depth=2
	mov.d	x1, v16[1]
	ld1.s	{ v6 }[1], [x1]
	orr.16b	v3, v17, v24
	add.2d	v16, v23, v3
	tbnz	w16, #6, LBB0_579
LBB0_586:                               ; %else1484
                                        ;   in Loop: Header=BB0_572 Depth=2
	tbz	w16, #7, LBB0_571
LBB0_587:                               ; %cond.load1486
                                        ;   in Loop: Header=BB0_572 Depth=2
	mov.d	x16, v16[1]
	ld1.s	{ v6 }[3], [x16]
	b	LBB0_571
LBB0_588:                               ; %direct.false693
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q2, [sp, #5504]                 ; 16-byte Reload
	and.16b	v2, v19, v2
	str	q2, [sp, #5504]                 ; 16-byte Spill
	ldr	q2, [sp, #5520]                 ; 16-byte Reload
	and.16b	v2, v21, v2
	str	q2, [sp, #5520]                 ; 16-byte Spill
	b	LBB0_590
LBB0_589:                               ; %else1539
                                        ;   in Loop: Header=BB0_590 Depth=2
	ldr	q16, [sp, #5520]                ; 16-byte Reload
	fadd.4s	v2, v16, v2
	ldr	q17, [sp, #5504]                ; 16-byte Reload
	fadd.4s	v3, v17, v6
	bit.16b	v17, v3, v0
	str	q17, [sp, #5504]                ; 16-byte Spill
	bit.16b	v16, v2, v1
	str	q16, [sp, #5520]                ; 16-byte Spill
	add	x8, x8, #4
	cmp	x8, #64
	b.eq	LBB0_606
LBB0_590:                               ; %direct.true702
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w16, s10
	orr	x1, x8, #0xc0
	dup.2d	v17, x1
	orr.16b	v2, v17, v28
	ldr	q3, [sp, #5792]                 ; 16-byte Reload
	add.2d	v16, v3, v2
	movi.2d	v2, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbz	w16, #0, LBB0_598
; %bb.591:                              ; %cond.load1493
                                        ;   in Loop: Header=BB0_590 Depth=2
	fmov	x1, d16
	ldr	s2, [x1]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_599
LBB0_592:                               ; %else1503
                                        ;   in Loop: Header=BB0_590 Depth=2
	orr.16b	v3, v17, v29
	ldr	q16, [sp, #5776]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbz	w16, #2, LBB0_600
LBB0_593:                               ; %cond.load1505
                                        ;   in Loop: Header=BB0_590 Depth=2
	fmov	x1, d16
	ld1.s	{ v2 }[2], [x1]
	tbnz	w16, #3, LBB0_601
LBB0_594:                               ; %else1515
                                        ;   in Loop: Header=BB0_590 Depth=2
	orr.16b	v3, v17, v20
	ldr	q16, [sp, #5760]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbz	w16, #4, LBB0_602
LBB0_595:                               ; %cond.load1517
                                        ;   in Loop: Header=BB0_590 Depth=2
	fmov	x1, d16
	ld1.s	{ v6 }[0], [x1]
	tbnz	w16, #5, LBB0_603
LBB0_596:                               ; %else1527
                                        ;   in Loop: Header=BB0_590 Depth=2
	orr.16b	v3, v17, v24
	add.2d	v16, v23, v3
	tbz	w16, #6, LBB0_604
LBB0_597:                               ; %cond.load1529
                                        ;   in Loop: Header=BB0_590 Depth=2
	fmov	x1, d16
	ld1.s	{ v6 }[2], [x1]
	tbz	w16, #7, LBB0_589
	b	LBB0_605
LBB0_598:                               ; %else1497
                                        ;   in Loop: Header=BB0_590 Depth=2
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_592
LBB0_599:                               ; %cond.load1499
                                        ;   in Loop: Header=BB0_590 Depth=2
	mov.d	x1, v16[1]
	ld1.s	{ v2 }[1], [x1]
	orr.16b	v3, v17, v29
	ldr	q16, [sp, #5776]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbnz	w16, #2, LBB0_593
LBB0_600:                               ; %else1509
                                        ;   in Loop: Header=BB0_590 Depth=2
	tbz	w16, #3, LBB0_594
LBB0_601:                               ; %cond.load1511
                                        ;   in Loop: Header=BB0_590 Depth=2
	mov.d	x1, v16[1]
	ld1.s	{ v2 }[3], [x1]
	orr.16b	v3, v17, v20
	ldr	q16, [sp, #5760]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbnz	w16, #4, LBB0_595
LBB0_602:                               ; %else1521
                                        ;   in Loop: Header=BB0_590 Depth=2
	tbz	w16, #5, LBB0_596
LBB0_603:                               ; %cond.load1523
                                        ;   in Loop: Header=BB0_590 Depth=2
	mov.d	x1, v16[1]
	ld1.s	{ v6 }[1], [x1]
	orr.16b	v3, v17, v24
	add.2d	v16, v23, v3
	tbnz	w16, #6, LBB0_597
LBB0_604:                               ; %else1533
                                        ;   in Loop: Header=BB0_590 Depth=2
	tbz	w16, #7, LBB0_589
LBB0_605:                               ; %cond.load1535
                                        ;   in Loop: Header=BB0_590 Depth=2
	mov.d	x16, v16[1]
	ld1.s	{ v6 }[3], [x16]
	b	LBB0_589
LBB0_606:                               ; %direct.false703
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q2, [sp, #5536]                 ; 16-byte Reload
	and.16b	v2, v19, v2
	str	q2, [sp, #5536]                 ; 16-byte Spill
	ldr	q2, [sp, #5552]                 ; 16-byte Reload
	and.16b	v2, v21, v2
	str	q2, [sp, #5552]                 ; 16-byte Spill
	b	LBB0_608
LBB0_607:                               ; %else1588
                                        ;   in Loop: Header=BB0_608 Depth=2
	ldr	q16, [sp, #5552]                ; 16-byte Reload
	fadd.4s	v2, v16, v2
	ldr	q17, [sp, #5536]                ; 16-byte Reload
	fadd.4s	v3, v17, v6
	bit.16b	v17, v3, v0
	str	q17, [sp, #5536]                ; 16-byte Spill
	bit.16b	v16, v2, v1
	str	q16, [sp, #5552]                ; 16-byte Spill
	add	x8, x8, #4
	cmp	x8, #64
	b.eq	LBB0_624
LBB0_608:                               ; %direct.true712
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w16, s10
	orr	x1, x8, #0x100
	dup.2d	v17, x1
	orr.16b	v2, v17, v28
	ldr	q3, [sp, #5792]                 ; 16-byte Reload
	add.2d	v16, v3, v2
	movi.2d	v2, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbz	w16, #0, LBB0_616
; %bb.609:                              ; %cond.load1542
                                        ;   in Loop: Header=BB0_608 Depth=2
	fmov	x1, d16
	ldr	s2, [x1]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_617
LBB0_610:                               ; %else1552
                                        ;   in Loop: Header=BB0_608 Depth=2
	orr.16b	v3, v17, v29
	ldr	q16, [sp, #5776]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbz	w16, #2, LBB0_618
LBB0_611:                               ; %cond.load1554
                                        ;   in Loop: Header=BB0_608 Depth=2
	fmov	x1, d16
	ld1.s	{ v2 }[2], [x1]
	tbnz	w16, #3, LBB0_619
LBB0_612:                               ; %else1564
                                        ;   in Loop: Header=BB0_608 Depth=2
	orr.16b	v3, v17, v20
	ldr	q16, [sp, #5760]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbz	w16, #4, LBB0_620
LBB0_613:                               ; %cond.load1566
                                        ;   in Loop: Header=BB0_608 Depth=2
	fmov	x1, d16
	ld1.s	{ v6 }[0], [x1]
	tbnz	w16, #5, LBB0_621
LBB0_614:                               ; %else1576
                                        ;   in Loop: Header=BB0_608 Depth=2
	orr.16b	v3, v17, v24
	add.2d	v16, v23, v3
	tbz	w16, #6, LBB0_622
LBB0_615:                               ; %cond.load1578
                                        ;   in Loop: Header=BB0_608 Depth=2
	fmov	x1, d16
	ld1.s	{ v6 }[2], [x1]
	tbz	w16, #7, LBB0_607
	b	LBB0_623
LBB0_616:                               ; %else1546
                                        ;   in Loop: Header=BB0_608 Depth=2
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_610
LBB0_617:                               ; %cond.load1548
                                        ;   in Loop: Header=BB0_608 Depth=2
	mov.d	x1, v16[1]
	ld1.s	{ v2 }[1], [x1]
	orr.16b	v3, v17, v29
	ldr	q16, [sp, #5776]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbnz	w16, #2, LBB0_611
LBB0_618:                               ; %else1558
                                        ;   in Loop: Header=BB0_608 Depth=2
	tbz	w16, #3, LBB0_612
LBB0_619:                               ; %cond.load1560
                                        ;   in Loop: Header=BB0_608 Depth=2
	mov.d	x1, v16[1]
	ld1.s	{ v2 }[3], [x1]
	orr.16b	v3, v17, v20
	ldr	q16, [sp, #5760]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbnz	w16, #4, LBB0_613
LBB0_620:                               ; %else1570
                                        ;   in Loop: Header=BB0_608 Depth=2
	tbz	w16, #5, LBB0_614
LBB0_621:                               ; %cond.load1572
                                        ;   in Loop: Header=BB0_608 Depth=2
	mov.d	x1, v16[1]
	ld1.s	{ v6 }[1], [x1]
	orr.16b	v3, v17, v24
	add.2d	v16, v23, v3
	tbnz	w16, #6, LBB0_615
LBB0_622:                               ; %else1582
                                        ;   in Loop: Header=BB0_608 Depth=2
	tbz	w16, #7, LBB0_607
LBB0_623:                               ; %cond.load1584
                                        ;   in Loop: Header=BB0_608 Depth=2
	mov.d	x16, v16[1]
	ld1.s	{ v6 }[3], [x16]
	b	LBB0_607
LBB0_624:                               ; %direct.false713
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q2, [sp, #5568]                 ; 16-byte Reload
	and.16b	v2, v19, v2
	str	q2, [sp, #5568]                 ; 16-byte Spill
	ldr	q2, [sp, #5584]                 ; 16-byte Reload
	and.16b	v2, v21, v2
	str	q2, [sp, #5584]                 ; 16-byte Spill
	b	LBB0_626
LBB0_625:                               ; %else1637
                                        ;   in Loop: Header=BB0_626 Depth=2
	ldr	q16, [sp, #5584]                ; 16-byte Reload
	fadd.4s	v2, v16, v2
	ldr	q17, [sp, #5568]                ; 16-byte Reload
	fadd.4s	v3, v17, v6
	bit.16b	v17, v3, v0
	str	q17, [sp, #5568]                ; 16-byte Spill
	bit.16b	v16, v2, v1
	str	q16, [sp, #5584]                ; 16-byte Spill
	add	x8, x8, #4
	cmp	x8, #64
	b.eq	LBB0_642
LBB0_626:                               ; %direct.true722
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w16, s10
	orr	x1, x8, x3
	dup.2d	v17, x1
	orr.16b	v2, v17, v28
	ldr	q3, [sp, #5792]                 ; 16-byte Reload
	add.2d	v16, v3, v2
	movi.2d	v2, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbz	w16, #0, LBB0_634
; %bb.627:                              ; %cond.load1591
                                        ;   in Loop: Header=BB0_626 Depth=2
	fmov	x1, d16
	ldr	s2, [x1]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_635
LBB0_628:                               ; %else1601
                                        ;   in Loop: Header=BB0_626 Depth=2
	orr.16b	v3, v17, v29
	ldr	q16, [sp, #5776]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbz	w16, #2, LBB0_636
LBB0_629:                               ; %cond.load1603
                                        ;   in Loop: Header=BB0_626 Depth=2
	fmov	x1, d16
	ld1.s	{ v2 }[2], [x1]
	tbnz	w16, #3, LBB0_637
LBB0_630:                               ; %else1613
                                        ;   in Loop: Header=BB0_626 Depth=2
	orr.16b	v3, v17, v20
	ldr	q16, [sp, #5760]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbz	w16, #4, LBB0_638
LBB0_631:                               ; %cond.load1615
                                        ;   in Loop: Header=BB0_626 Depth=2
	fmov	x1, d16
	ld1.s	{ v6 }[0], [x1]
	tbnz	w16, #5, LBB0_639
LBB0_632:                               ; %else1625
                                        ;   in Loop: Header=BB0_626 Depth=2
	orr.16b	v3, v17, v24
	add.2d	v16, v23, v3
	tbz	w16, #6, LBB0_640
LBB0_633:                               ; %cond.load1627
                                        ;   in Loop: Header=BB0_626 Depth=2
	fmov	x1, d16
	ld1.s	{ v6 }[2], [x1]
	tbz	w16, #7, LBB0_625
	b	LBB0_641
LBB0_634:                               ; %else1595
                                        ;   in Loop: Header=BB0_626 Depth=2
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_628
LBB0_635:                               ; %cond.load1597
                                        ;   in Loop: Header=BB0_626 Depth=2
	mov.d	x1, v16[1]
	ld1.s	{ v2 }[1], [x1]
	orr.16b	v3, v17, v29
	ldr	q16, [sp, #5776]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbnz	w16, #2, LBB0_629
LBB0_636:                               ; %else1607
                                        ;   in Loop: Header=BB0_626 Depth=2
	tbz	w16, #3, LBB0_630
LBB0_637:                               ; %cond.load1609
                                        ;   in Loop: Header=BB0_626 Depth=2
	mov.d	x1, v16[1]
	ld1.s	{ v2 }[3], [x1]
	orr.16b	v3, v17, v20
	ldr	q16, [sp, #5760]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbnz	w16, #4, LBB0_631
LBB0_638:                               ; %else1619
                                        ;   in Loop: Header=BB0_626 Depth=2
	tbz	w16, #5, LBB0_632
LBB0_639:                               ; %cond.load1621
                                        ;   in Loop: Header=BB0_626 Depth=2
	mov.d	x1, v16[1]
	ld1.s	{ v6 }[1], [x1]
	orr.16b	v3, v17, v24
	add.2d	v16, v23, v3
	tbnz	w16, #6, LBB0_633
LBB0_640:                               ; %else1631
                                        ;   in Loop: Header=BB0_626 Depth=2
	tbz	w16, #7, LBB0_625
LBB0_641:                               ; %cond.load1633
                                        ;   in Loop: Header=BB0_626 Depth=2
	mov.d	x16, v16[1]
	ld1.s	{ v6 }[3], [x16]
	b	LBB0_625
LBB0_642:                               ; %direct.false723
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q2, [sp, #5600]                 ; 16-byte Reload
	and.16b	v2, v19, v2
	str	q2, [sp, #5600]                 ; 16-byte Spill
	and.16b	v15, v21, v15
	b	LBB0_644
LBB0_643:                               ; %else1686
                                        ;   in Loop: Header=BB0_644 Depth=2
	fadd.4s	v2, v15, v2
	ldr	q16, [sp, #5600]                ; 16-byte Reload
	fadd.4s	v3, v16, v6
	bit.16b	v16, v3, v0
	str	q16, [sp, #5600]                ; 16-byte Spill
	bit.16b	v15, v2, v1
	add	x8, x8, #4
	cmp	x8, #64
	b.eq	LBB0_660
LBB0_644:                               ; %direct.true732
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w16, s10
	orr	x1, x8, #0x180
	dup.2d	v17, x1
	orr.16b	v2, v17, v28
	ldr	q3, [sp, #5792]                 ; 16-byte Reload
	add.2d	v16, v3, v2
	movi.2d	v2, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbz	w16, #0, LBB0_652
; %bb.645:                              ; %cond.load1640
                                        ;   in Loop: Header=BB0_644 Depth=2
	fmov	x1, d16
	ldr	s2, [x1]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_653
LBB0_646:                               ; %else1650
                                        ;   in Loop: Header=BB0_644 Depth=2
	orr.16b	v3, v17, v29
	ldr	q16, [sp, #5776]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbz	w16, #2, LBB0_654
LBB0_647:                               ; %cond.load1652
                                        ;   in Loop: Header=BB0_644 Depth=2
	fmov	x1, d16
	ld1.s	{ v2 }[2], [x1]
	tbnz	w16, #3, LBB0_655
LBB0_648:                               ; %else1662
                                        ;   in Loop: Header=BB0_644 Depth=2
	orr.16b	v3, v17, v20
	ldr	q16, [sp, #5760]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbz	w16, #4, LBB0_656
LBB0_649:                               ; %cond.load1664
                                        ;   in Loop: Header=BB0_644 Depth=2
	fmov	x1, d16
	ld1.s	{ v6 }[0], [x1]
	tbnz	w16, #5, LBB0_657
LBB0_650:                               ; %else1674
                                        ;   in Loop: Header=BB0_644 Depth=2
	orr.16b	v3, v17, v24
	add.2d	v16, v23, v3
	tbz	w16, #6, LBB0_658
LBB0_651:                               ; %cond.load1676
                                        ;   in Loop: Header=BB0_644 Depth=2
	fmov	x1, d16
	ld1.s	{ v6 }[2], [x1]
	tbz	w16, #7, LBB0_643
	b	LBB0_659
LBB0_652:                               ; %else1644
                                        ;   in Loop: Header=BB0_644 Depth=2
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_646
LBB0_653:                               ; %cond.load1646
                                        ;   in Loop: Header=BB0_644 Depth=2
	mov.d	x1, v16[1]
	ld1.s	{ v2 }[1], [x1]
	orr.16b	v3, v17, v29
	ldr	q16, [sp, #5776]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbnz	w16, #2, LBB0_647
LBB0_654:                               ; %else1656
                                        ;   in Loop: Header=BB0_644 Depth=2
	tbz	w16, #3, LBB0_648
LBB0_655:                               ; %cond.load1658
                                        ;   in Loop: Header=BB0_644 Depth=2
	mov.d	x1, v16[1]
	ld1.s	{ v2 }[3], [x1]
	orr.16b	v3, v17, v20
	ldr	q16, [sp, #5760]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbnz	w16, #4, LBB0_649
LBB0_656:                               ; %else1668
                                        ;   in Loop: Header=BB0_644 Depth=2
	tbz	w16, #5, LBB0_650
LBB0_657:                               ; %cond.load1670
                                        ;   in Loop: Header=BB0_644 Depth=2
	mov.d	x1, v16[1]
	ld1.s	{ v6 }[1], [x1]
	orr.16b	v3, v17, v24
	add.2d	v16, v23, v3
	tbnz	w16, #6, LBB0_651
LBB0_658:                               ; %else1680
                                        ;   in Loop: Header=BB0_644 Depth=2
	tbz	w16, #7, LBB0_643
LBB0_659:                               ; %cond.load1682
                                        ;   in Loop: Header=BB0_644 Depth=2
	mov.d	x16, v16[1]
	ld1.s	{ v6 }[3], [x16]
	b	LBB0_643
LBB0_660:                               ; %direct.false733
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q2, [sp, #5616]                 ; 16-byte Reload
	and.16b	v2, v19, v2
	str	q2, [sp, #5616]                 ; 16-byte Spill
	ldr	q2, [sp, #4272]                 ; 16-byte Reload
	and.16b	v21, v21, v2
	b	LBB0_662
LBB0_661:                               ; %else1735
                                        ;   in Loop: Header=BB0_662 Depth=2
	fadd.4s	v2, v21, v2
	ldr	q16, [sp, #5616]                ; 16-byte Reload
	fadd.4s	v3, v16, v6
	bit.16b	v16, v3, v0
	str	q16, [sp, #5616]                ; 16-byte Spill
	bit.16b	v21, v2, v1
	add	x8, x8, #4
	cmp	x8, #64
	b.eq	LBB0_678
LBB0_662:                               ; %direct.true742
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w16, s10
	orr	x1, x8, #0x1c0
	dup.2d	v17, x1
	orr.16b	v2, v17, v28
	ldr	q3, [sp, #5792]                 ; 16-byte Reload
	add.2d	v16, v3, v2
	movi.2d	v2, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbz	w16, #0, LBB0_670
; %bb.663:                              ; %cond.load1689
                                        ;   in Loop: Header=BB0_662 Depth=2
	fmov	x1, d16
	ldr	s2, [x1]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_671
LBB0_664:                               ; %else1699
                                        ;   in Loop: Header=BB0_662 Depth=2
	orr.16b	v3, v17, v29
	ldr	q16, [sp, #5776]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbz	w16, #2, LBB0_672
LBB0_665:                               ; %cond.load1701
                                        ;   in Loop: Header=BB0_662 Depth=2
	fmov	x1, d16
	ld1.s	{ v2 }[2], [x1]
	tbnz	w16, #3, LBB0_673
LBB0_666:                               ; %else1711
                                        ;   in Loop: Header=BB0_662 Depth=2
	orr.16b	v3, v17, v20
	ldr	q16, [sp, #5760]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbz	w16, #4, LBB0_674
LBB0_667:                               ; %cond.load1713
                                        ;   in Loop: Header=BB0_662 Depth=2
	fmov	x1, d16
	ld1.s	{ v6 }[0], [x1]
	tbnz	w16, #5, LBB0_675
LBB0_668:                               ; %else1723
                                        ;   in Loop: Header=BB0_662 Depth=2
	orr.16b	v3, v17, v24
	add.2d	v16, v23, v3
	tbz	w16, #6, LBB0_676
LBB0_669:                               ; %cond.load1725
                                        ;   in Loop: Header=BB0_662 Depth=2
	fmov	x1, d16
	ld1.s	{ v6 }[2], [x1]
	tbz	w16, #7, LBB0_661
	b	LBB0_677
LBB0_670:                               ; %else1693
                                        ;   in Loop: Header=BB0_662 Depth=2
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_664
LBB0_671:                               ; %cond.load1695
                                        ;   in Loop: Header=BB0_662 Depth=2
	mov.d	x1, v16[1]
	ld1.s	{ v2 }[1], [x1]
	orr.16b	v3, v17, v29
	ldr	q16, [sp, #5776]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbnz	w16, #2, LBB0_665
LBB0_672:                               ; %else1705
                                        ;   in Loop: Header=BB0_662 Depth=2
	tbz	w16, #3, LBB0_666
LBB0_673:                               ; %cond.load1707
                                        ;   in Loop: Header=BB0_662 Depth=2
	mov.d	x1, v16[1]
	ld1.s	{ v2 }[3], [x1]
	orr.16b	v3, v17, v20
	ldr	q16, [sp, #5760]                ; 16-byte Reload
	add.2d	v16, v16, v3
	tbnz	w16, #4, LBB0_667
LBB0_674:                               ; %else1717
                                        ;   in Loop: Header=BB0_662 Depth=2
	tbz	w16, #5, LBB0_668
LBB0_675:                               ; %cond.load1719
                                        ;   in Loop: Header=BB0_662 Depth=2
	mov.d	x1, v16[1]
	ld1.s	{ v6 }[1], [x1]
	orr.16b	v3, v17, v24
	add.2d	v16, v23, v3
	tbnz	w16, #6, LBB0_669
LBB0_676:                               ; %else1729
                                        ;   in Loop: Header=BB0_662 Depth=2
	tbz	w16, #7, LBB0_661
LBB0_677:                               ; %cond.load1731
                                        ;   in Loop: Header=BB0_662 Depth=2
	mov.d	x16, v16[1]
	ld1.s	{ v6 }[3], [x16]
	b	LBB0_661
LBB0_678:                               ; %direct.false743
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	sshll.2d	v2, v1, #0
	sshll.2d	v3, v0, #0
	ldr	q6, [sp, #2576]                 ; 16-byte Reload
	bit.16b	v30, v6, v18
	bit.16b	v26, v6, v4
	bit.16b	v27, v6, v3
	bit.16b	v25, v6, v2
	ldr	q6, [sp, #3328]                 ; 16-byte Reload
	bit.16b	v12, v6, v18
	ldr	q6, [sp, #3312]                 ; 16-byte Reload
	bit.16b	v8, v6, v4
	ldr	q4, [sp, #3296]                 ; 16-byte Reload
	bit.16b	v11, v4, v3
	ldr	q3, [sp, #3280]                 ; 16-byte Reload
	bit.16b	v31, v3, v2
	ldr	q18, [sp, #2912]                ; 16-byte Reload
	b	LBB0_680
LBB0_679:                               ; %else1769
                                        ;   in Loop: Header=BB0_680 Depth=2
	add	x16, x16, #1
	add	x8, x8, #4
	cmp	x8, #1536
	b.eq	LBB0_696
LBB0_680:                               ; %direct.true768
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w1, s10
	and	w3, w16, #0xffff
	mul	w3, w3, w27
	lsr	w3, w3, #21
	msub	w4, w3, w17, w16
	and	x4, x4, #0xffff
	umaddl	x4, w3, w17, x4
	add	x4, x10, x4, lsl #5
	ldp	q2, q6, [x4]
	add	x3, x19, x3, lsl #5
	ldp	q3, q16, [x3]
	fmul.4s	v2, v2, v3
	and.16b	v17, v1, v2
	dup.2d	v2, x8
	add.2d	v3, v25, v31
	add.2d	v3, v3, v2
	tbz	w1, #0, LBB0_688
; %bb.681:                              ; %cond.store1738
                                        ;   in Loop: Header=BB0_680 Depth=2
	fmov	x3, d3
	str	s17, [x3]
	and	w1, w1, #0xff
	tbnz	w1, #1, LBB0_689
LBB0_682:                               ; %else1745
                                        ;   in Loop: Header=BB0_680 Depth=2
	add.2d	v3, v26, v8
	add.2d	v3, v3, v2
	tbz	w1, #2, LBB0_690
LBB0_683:                               ; %cond.store1746
                                        ;   in Loop: Header=BB0_680 Depth=2
	fmov	x3, d3
	st1.s	{ v17 }[2], [x3]
	tbnz	w1, #3, LBB0_691
LBB0_684:                               ; %else1753
                                        ;   in Loop: Header=BB0_680 Depth=2
	fmul.4s	v3, v6, v16
	and.16b	v6, v0, v3
	add.2d	v3, v27, v11
	add.2d	v3, v3, v2
	tbz	w1, #4, LBB0_692
LBB0_685:                               ; %cond.store1754
                                        ;   in Loop: Header=BB0_680 Depth=2
	fmov	x3, d3
	str	s6, [x3]
	tbnz	w1, #5, LBB0_693
LBB0_686:                               ; %else1761
                                        ;   in Loop: Header=BB0_680 Depth=2
	add.2d	v3, v30, v12
	add.2d	v2, v3, v2
	tbz	w1, #6, LBB0_694
LBB0_687:                               ; %cond.store1762
                                        ;   in Loop: Header=BB0_680 Depth=2
	fmov	x3, d2
	st1.s	{ v6 }[2], [x3]
	tbz	w1, #7, LBB0_679
	b	LBB0_695
LBB0_688:                               ; %else1741
                                        ;   in Loop: Header=BB0_680 Depth=2
	and	w1, w1, #0xff
	tbz	w1, #1, LBB0_682
LBB0_689:                               ; %cond.store1742
                                        ;   in Loop: Header=BB0_680 Depth=2
	mov.d	x3, v3[1]
	st1.s	{ v17 }[1], [x3]
	add.2d	v3, v26, v8
	add.2d	v3, v3, v2
	tbnz	w1, #2, LBB0_683
LBB0_690:                               ; %else1749
                                        ;   in Loop: Header=BB0_680 Depth=2
	tbz	w1, #3, LBB0_684
LBB0_691:                               ; %cond.store1750
                                        ;   in Loop: Header=BB0_680 Depth=2
	mov.d	x3, v3[1]
	st1.s	{ v17 }[3], [x3]
	fmul.4s	v3, v6, v16
	and.16b	v6, v0, v3
	add.2d	v3, v27, v11
	add.2d	v3, v3, v2
	tbnz	w1, #4, LBB0_685
LBB0_692:                               ; %else1757
                                        ;   in Loop: Header=BB0_680 Depth=2
	tbz	w1, #5, LBB0_686
LBB0_693:                               ; %cond.store1758
                                        ;   in Loop: Header=BB0_680 Depth=2
	mov.d	x3, v3[1]
	st1.s	{ v6 }[1], [x3]
	add.2d	v3, v30, v12
	add.2d	v2, v3, v2
	tbnz	w1, #6, LBB0_687
LBB0_694:                               ; %else1765
                                        ;   in Loop: Header=BB0_680 Depth=2
	tbz	w1, #7, LBB0_679
LBB0_695:                               ; %cond.store1766
                                        ;   in Loop: Header=BB0_680 Depth=2
	mov.d	x1, v2[1]
	st1.s	{ v6 }[3], [x1]
	b	LBB0_679
LBB0_696:                               ; %direct.false769
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w26, #0, LBB0_701
; %bb.697:                              ; %mma.active790
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	ldr	q2, [sp, #5792]                 ; 16-byte Reload
	fmov	x1, d2
	fmov	x3, d28
	add	x1, x1, x3
	ldr	q2, [sp, #4800]                 ; 16-byte Reload
	fmov	x3, d2
	ldr	q2, [sp, #4736]                 ; 16-byte Reload
	fmov	x4, d2
	add	x3, x3, x4
	fmov	x4, d25
	fmov	x20, d31
	add	x4, x4, x20
	ldr	x20, [sp, #280]                 ; 8-byte Reload
LBB0_698:                               ; %mma.update.i616
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_699 Depth 3
	mov	x21, #0                         ; =0x0
	mov	x22, x8
LBB0_699:                               ; %mma.update2.i
                                        ;   Parent Loop BB0_28 Depth=1
                                        ;     Parent Loop BB0_698 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	umulh	x23, x22, x0
	lsr	x24, x23, #5
	msub	x25, x24, x17, x22
	ldr	q2, [x4, x21]
	lsl	x23, x23, #1
	and	x23, x23, #0x1c0
	add	x24, x1, x23
	add	x23, x3, x25, lsl #2
	ldr	q3, [x23]
	ldp	s4, s6, [x24]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #192]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #384]
	ldp	s4, s6, [x24, #8]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #576]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #768]
	ldp	s4, s6, [x24, #16]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #960]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1152]
	ldp	s4, s6, [x24, #24]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1344]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1536]
	ldp	s4, s6, [x24, #32]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1728]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1920]
	ldp	s4, s6, [x24, #40]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2112]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2304]
	ldp	s4, s6, [x24, #48]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2496]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2688]
	ldp	s4, s6, [x24, #56]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2880]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	str	q2, [x20, x21]
	add	x21, x21, #16
	add	x22, x22, #4
	cmp	x21, #192
	b.ne	LBB0_699
; %bb.700:                              ; %mma.fold.done3.i
                                        ;   in Loop: Header=BB0_698 Depth=2
	add	x16, x16, #1
	add	x8, x8, #48
	add	x20, x20, #192
	add	x4, x4, #192
	cmp	x16, #8
	b.ne	LBB0_698
LBB0_701:                               ; %mma.continue791
                                        ;   in Loop: Header=BB0_28 Depth=1
	cbz	w28, LBB0_706
; %bb.702:                              ; %mma.active792
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	ldr	q2, [sp, #5792]                 ; 16-byte Reload
	mov.d	x1, v2[1]
	mov.d	x3, v28[1]
	add	x1, x1, x3
	ldr	q2, [sp, #4800]                 ; 16-byte Reload
	mov.d	x3, v2[1]
	ldr	q2, [sp, #4736]                 ; 16-byte Reload
	mov.d	x4, v2[1]
	add	x3, x3, x4
	mov.d	x4, v25[1]
	mov.d	x20, v31[1]
	add	x4, x4, x20
	ldr	x20, [sp, #216]                 ; 8-byte Reload
LBB0_703:                               ; %mma.update.i618
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_704 Depth 3
	mov	x21, #0                         ; =0x0
	mov	x22, x8
LBB0_704:                               ; %mma.update2.i620
                                        ;   Parent Loop BB0_28 Depth=1
                                        ;     Parent Loop BB0_703 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	umulh	x23, x22, x0
	lsr	x24, x23, #5
	msub	x25, x24, x17, x22
	ldr	q2, [x4, x21]
	lsl	x23, x23, #1
	and	x23, x23, #0x1c0
	add	x24, x1, x23
	add	x23, x3, x25, lsl #2
	ldr	q3, [x23]
	ldp	s4, s6, [x24]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #192]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #384]
	ldp	s4, s6, [x24, #8]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #576]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #768]
	ldp	s4, s6, [x24, #16]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #960]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1152]
	ldp	s4, s6, [x24, #24]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1344]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1536]
	ldp	s4, s6, [x24, #32]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1728]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1920]
	ldp	s4, s6, [x24, #40]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2112]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2304]
	ldp	s4, s6, [x24, #48]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2496]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2688]
	ldp	s4, s6, [x24, #56]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2880]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	str	q2, [x20, x21]
	add	x21, x21, #16
	add	x22, x22, #4
	cmp	x21, #192
	b.ne	LBB0_704
; %bb.705:                              ; %mma.fold.done3.i655
                                        ;   in Loop: Header=BB0_703 Depth=2
	add	x16, x16, #1
	add	x8, x8, #48
	add	x20, x20, #192
	add	x4, x4, #192
	cmp	x16, #8
	b.ne	LBB0_703
LBB0_706:                               ; %mma.continue793
                                        ;   in Loop: Header=BB0_28 Depth=1
	cbz	w30, LBB0_711
; %bb.707:                              ; %mma.active794
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	ldr	q2, [sp, #5776]                 ; 16-byte Reload
	fmov	x1, d2
	fmov	x3, d29
	add	x1, x1, x3
	ldr	q2, [sp, #4784]                 ; 16-byte Reload
	fmov	x3, d2
	ldr	q2, [sp, #4720]                 ; 16-byte Reload
	fmov	x4, d2
	add	x3, x3, x4
	fmov	x4, d26
	fmov	x20, d8
	add	x4, x4, x20
	ldr	x20, [sp, #208]                 ; 8-byte Reload
LBB0_708:                               ; %mma.update.i658
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_709 Depth 3
	mov	x21, #0                         ; =0x0
	mov	x22, x8
LBB0_709:                               ; %mma.update2.i660
                                        ;   Parent Loop BB0_28 Depth=1
                                        ;     Parent Loop BB0_708 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	umulh	x23, x22, x0
	lsr	x24, x23, #5
	msub	x25, x24, x17, x22
	ldr	q2, [x4, x21]
	lsl	x23, x23, #1
	and	x23, x23, #0x1c0
	add	x24, x1, x23
	add	x23, x3, x25, lsl #2
	ldr	q3, [x23]
	ldp	s4, s6, [x24]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #192]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #384]
	ldp	s4, s6, [x24, #8]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #576]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #768]
	ldp	s4, s6, [x24, #16]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #960]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1152]
	ldp	s4, s6, [x24, #24]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1344]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1536]
	ldp	s4, s6, [x24, #32]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1728]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1920]
	ldp	s4, s6, [x24, #40]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2112]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2304]
	ldp	s4, s6, [x24, #48]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2496]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2688]
	ldp	s4, s6, [x24, #56]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2880]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	str	q2, [x20, x21]
	add	x21, x21, #16
	add	x22, x22, #4
	cmp	x21, #192
	b.ne	LBB0_709
; %bb.710:                              ; %mma.fold.done3.i695
                                        ;   in Loop: Header=BB0_708 Depth=2
	add	x16, x16, #1
	add	x8, x8, #48
	add	x20, x20, #192
	add	x4, x4, #192
	cmp	x16, #8
	b.ne	LBB0_708
LBB0_711:                               ; %mma.continue795
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	w8, [sp, #4268]                 ; 4-byte Reload
	cbz	w8, LBB0_716
; %bb.712:                              ; %mma.active796
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	ldr	q2, [sp, #5776]                 ; 16-byte Reload
	mov.d	x1, v2[1]
	mov.d	x3, v29[1]
	add	x1, x1, x3
	ldr	q2, [sp, #4784]                 ; 16-byte Reload
	mov.d	x3, v2[1]
	ldr	q2, [sp, #4720]                 ; 16-byte Reload
	mov.d	x4, v2[1]
	add	x3, x3, x4
	mov.d	x4, v26[1]
	mov.d	x20, v8[1]
	add	x4, x4, x20
	ldr	x20, [sp, #200]                 ; 8-byte Reload
LBB0_713:                               ; %mma.update.i698
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_714 Depth 3
	mov	x21, #0                         ; =0x0
	mov	x22, x8
LBB0_714:                               ; %mma.update2.i700
                                        ;   Parent Loop BB0_28 Depth=1
                                        ;     Parent Loop BB0_713 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	umulh	x23, x22, x0
	lsr	x24, x23, #5
	msub	x25, x24, x17, x22
	ldr	q2, [x4, x21]
	lsl	x23, x23, #1
	and	x23, x23, #0x1c0
	add	x24, x1, x23
	add	x23, x3, x25, lsl #2
	ldr	q3, [x23]
	ldp	s4, s6, [x24]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #192]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #384]
	ldp	s4, s6, [x24, #8]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #576]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #768]
	ldp	s4, s6, [x24, #16]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #960]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1152]
	ldp	s4, s6, [x24, #24]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1344]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1536]
	ldp	s4, s6, [x24, #32]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1728]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1920]
	ldp	s4, s6, [x24, #40]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2112]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2304]
	ldp	s4, s6, [x24, #48]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2496]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2688]
	ldp	s4, s6, [x24, #56]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2880]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	str	q2, [x20, x21]
	add	x21, x21, #16
	add	x22, x22, #4
	cmp	x21, #192
	b.ne	LBB0_714
; %bb.715:                              ; %mma.fold.done3.i735
                                        ;   in Loop: Header=BB0_713 Depth=2
	add	x16, x16, #1
	add	x8, x8, #48
	add	x20, x20, #192
	add	x4, x4, #192
	cmp	x16, #8
	b.ne	LBB0_713
LBB0_716:                               ; %mma.continue797
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	w8, [sp, #4264]                 ; 4-byte Reload
	cbz	w8, LBB0_721
; %bb.717:                              ; %mma.active798
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	ldr	q2, [sp, #5760]                 ; 16-byte Reload
	fmov	x1, d2
	fmov	x3, d20
	add	x1, x1, x3
	ldr	q2, [sp, #4768]                 ; 16-byte Reload
	fmov	x3, d2
	ldr	q2, [sp, #4704]                 ; 16-byte Reload
	fmov	x4, d2
	add	x3, x3, x4
	fmov	x4, d27
	fmov	x20, d11
	add	x4, x4, x20
	ldr	x20, [sp, #192]                 ; 8-byte Reload
LBB0_718:                               ; %mma.update.i738
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_719 Depth 3
	mov	x21, #0                         ; =0x0
	mov	x22, x8
LBB0_719:                               ; %mma.update2.i740
                                        ;   Parent Loop BB0_28 Depth=1
                                        ;     Parent Loop BB0_718 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	umulh	x23, x22, x0
	lsr	x24, x23, #5
	msub	x25, x24, x17, x22
	ldr	q2, [x4, x21]
	lsl	x23, x23, #1
	and	x23, x23, #0x1c0
	add	x24, x1, x23
	add	x23, x3, x25, lsl #2
	ldr	q3, [x23]
	ldp	s4, s6, [x24]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #192]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #384]
	ldp	s4, s6, [x24, #8]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #576]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #768]
	ldp	s4, s6, [x24, #16]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #960]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1152]
	ldp	s4, s6, [x24, #24]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1344]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1536]
	ldp	s4, s6, [x24, #32]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1728]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1920]
	ldp	s4, s6, [x24, #40]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2112]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2304]
	ldp	s4, s6, [x24, #48]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2496]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2688]
	ldp	s4, s6, [x24, #56]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2880]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	str	q2, [x20, x21]
	add	x21, x21, #16
	add	x22, x22, #4
	cmp	x21, #192
	b.ne	LBB0_719
; %bb.720:                              ; %mma.fold.done3.i775
                                        ;   in Loop: Header=BB0_718 Depth=2
	add	x16, x16, #1
	add	x8, x8, #48
	add	x20, x20, #192
	add	x4, x4, #192
	cmp	x16, #8
	b.ne	LBB0_718
LBB0_721:                               ; %mma.continue799
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	w8, [sp, #4260]                 ; 4-byte Reload
	cbz	w8, LBB0_726
; %bb.722:                              ; %mma.active800
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	ldr	q2, [sp, #5760]                 ; 16-byte Reload
	mov.d	x1, v2[1]
	mov.d	x3, v20[1]
	add	x1, x1, x3
	ldr	q2, [sp, #4768]                 ; 16-byte Reload
	mov.d	x3, v2[1]
	ldr	q2, [sp, #4704]                 ; 16-byte Reload
	mov.d	x4, v2[1]
	add	x3, x3, x4
	mov.d	x4, v27[1]
	mov.d	x20, v11[1]
	add	x4, x4, x20
	ldr	x20, [sp, #184]                 ; 8-byte Reload
LBB0_723:                               ; %mma.update.i778
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_724 Depth 3
	mov	x21, #0                         ; =0x0
	mov	x22, x8
LBB0_724:                               ; %mma.update2.i780
                                        ;   Parent Loop BB0_28 Depth=1
                                        ;     Parent Loop BB0_723 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	umulh	x23, x22, x0
	lsr	x24, x23, #5
	msub	x25, x24, x17, x22
	ldr	q2, [x4, x21]
	lsl	x23, x23, #1
	and	x23, x23, #0x1c0
	add	x24, x1, x23
	add	x23, x3, x25, lsl #2
	ldr	q3, [x23]
	ldp	s4, s6, [x24]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #192]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #384]
	ldp	s4, s6, [x24, #8]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #576]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #768]
	ldp	s4, s6, [x24, #16]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #960]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1152]
	ldp	s4, s6, [x24, #24]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1344]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1536]
	ldp	s4, s6, [x24, #32]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1728]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1920]
	ldp	s4, s6, [x24, #40]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2112]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2304]
	ldp	s4, s6, [x24, #48]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2496]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2688]
	ldp	s4, s6, [x24, #56]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2880]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	str	q2, [x20, x21]
	add	x21, x21, #16
	add	x22, x22, #4
	cmp	x21, #192
	b.ne	LBB0_724
; %bb.725:                              ; %mma.fold.done3.i815
                                        ;   in Loop: Header=BB0_723 Depth=2
	add	x16, x16, #1
	add	x8, x8, #48
	add	x20, x20, #192
	add	x4, x4, #192
	cmp	x16, #8
	b.ne	LBB0_723
LBB0_726:                               ; %mma.continue801
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	w8, [sp, #4256]                 ; 4-byte Reload
	cbz	w8, LBB0_731
; %bb.727:                              ; %mma.active802
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	fmov	x1, d23
	fmov	x3, d24
	add	x1, x1, x3
	ldr	q2, [sp, #4752]                 ; 16-byte Reload
	fmov	x3, d2
	ldr	q2, [sp, #4688]                 ; 16-byte Reload
	fmov	x4, d2
	add	x3, x3, x4
	fmov	x4, d30
	fmov	x20, d12
	add	x4, x4, x20
	ldr	x20, [sp, #176]                 ; 8-byte Reload
LBB0_728:                               ; %mma.update.i818
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_729 Depth 3
	mov	x21, #0                         ; =0x0
	mov	x22, x8
LBB0_729:                               ; %mma.update2.i820
                                        ;   Parent Loop BB0_28 Depth=1
                                        ;     Parent Loop BB0_728 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	umulh	x23, x22, x0
	lsr	x24, x23, #5
	msub	x25, x24, x17, x22
	ldr	q2, [x4, x21]
	lsl	x23, x23, #1
	and	x23, x23, #0x1c0
	add	x24, x1, x23
	add	x23, x3, x25, lsl #2
	ldr	q3, [x23]
	ldp	s4, s6, [x24]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #192]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #384]
	ldp	s4, s6, [x24, #8]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #576]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #768]
	ldp	s4, s6, [x24, #16]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #960]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1152]
	ldp	s4, s6, [x24, #24]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1344]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1536]
	ldp	s4, s6, [x24, #32]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1728]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #1920]
	ldp	s4, s6, [x24, #40]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2112]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2304]
	ldp	s4, s6, [x24, #48]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2496]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2688]
	ldp	s4, s6, [x24, #56]
	fmul.4s	v3, v3, v4[0]
	fadd.4s	v2, v2, v3
	ldr	q3, [x23, #2880]
	fmul.4s	v3, v3, v6[0]
	fadd.4s	v2, v2, v3
	str	q2, [x20, x21]
	add	x21, x21, #16
	add	x22, x22, #4
	cmp	x21, #192
	b.ne	LBB0_729
; %bb.730:                              ; %mma.fold.done3.i855
                                        ;   in Loop: Header=BB0_728 Depth=2
	add	x16, x16, #1
	add	x8, x8, #48
	add	x20, x20, #192
	add	x4, x4, #192
	cmp	x16, #8
	b.ne	LBB0_728
LBB0_731:                               ; %mma.continue803
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q12, [sp, #3360]                ; 16-byte Spill
	str	q11, [sp, #3152]                ; 16-byte Spill
	str	q8, [sp, #3168]                 ; 16-byte Spill
	str	q31, [sp, #3184]                ; 16-byte Spill
	str	q30, [sp, #3376]                ; 16-byte Spill
	str	q27, [sp, #3200]                ; 16-byte Spill
	str	q26, [sp, #3216]                ; 16-byte Spill
	str	q25, [sp, #3232]                ; 16-byte Spill
	sshll.2d	v2, v1, #0
	sshll.2d	v17, v0, #0
	ldr	q3, [sp, #3824]                 ; 16-byte Reload
	ldr	q4, [sp, #3568]                 ; 16-byte Reload
	fmul.4s	v7, v3, v4
	ldr	q3, [sp, #3840]                 ; 16-byte Reload
	ldr	q4, [sp, #3584]                 ; 16-byte Reload
	fmul.4s	v5, v3, v4
	ldr	q3, [sp, #3856]                 ; 16-byte Reload
	ldr	q4, [sp, #3552]                 ; 16-byte Reload
	fmul.4s	v19, v3, v4
	ldr	q3, [sp, #3872]                 ; 16-byte Reload
	ldr	q4, [sp, #3536]                 ; 16-byte Reload
	fmul.4s	v25, v3, v4
	ldr	q3, [sp, #3888]                 ; 16-byte Reload
	ldr	q4, [sp, #3520]                 ; 16-byte Reload
	fmul.4s	v8, v3, v4
	ldr	q3, [sp, #3904]                 ; 16-byte Reload
	ldr	q4, [sp, #3504]                 ; 16-byte Reload
	fmul.4s	v26, v3, v4
	ldr	q3, [sp, #3920]                 ; 16-byte Reload
	ldr	q4, [sp, #3488]                 ; 16-byte Reload
	fmul.4s	v3, v3, v4
	str	q3, [sp, #4992]                 ; 16-byte Spill
	ldr	q3, [sp, #3936]                 ; 16-byte Reload
	ldr	q4, [sp, #3472]                 ; 16-byte Reload
	fmul.4s	v27, v3, v4
	ldr	q3, [sp, #3952]                 ; 16-byte Reload
	ldr	q4, [sp, #3456]                 ; 16-byte Reload
	fmul.4s	v3, v3, v4
	str	q3, [sp, #4272]                 ; 16-byte Spill
	ldr	q3, [sp, #3968]                 ; 16-byte Reload
	ldr	q4, [sp, #3440]                 ; 16-byte Reload
	fmul.4s	v30, v3, v4
	ldr	q3, [sp, #3984]                 ; 16-byte Reload
	ldr	q4, [sp, #3408]                 ; 16-byte Reload
	fmul.4s	v3, v3, v4
	str	q3, [sp, #3584]                 ; 16-byte Spill
	ldr	q3, [sp, #4000]                 ; 16-byte Reload
	ldr	q4, [sp, #3424]                 ; 16-byte Reload
	fmul.4s	v31, v3, v4
	ldr	q3, [sp, #4016]                 ; 16-byte Reload
	ldr	q4, [sp, #3392]                 ; 16-byte Reload
	fmul.4s	v3, v3, v4
	str	q3, [sp, #3552]                 ; 16-byte Spill
	ldr	q3, [sp, #4032]                 ; 16-byte Reload
	ldr	q4, [sp, #2816]                 ; 16-byte Reload
	fmul.4s	v11, v3, v4
	ldr	q3, [sp, #4048]                 ; 16-byte Reload
	ldr	q4, [sp, #2800]                 ; 16-byte Reload
	fmul.4s	v3, v3, v4
	str	q3, [sp, #3504]                 ; 16-byte Spill
	ldr	q3, [sp, #4064]                 ; 16-byte Reload
	ldr	q4, [sp, #2784]                 ; 16-byte Reload
	fmul.4s	v12, v3, v4
	ldr	w8, [sp, #4252]                 ; 4-byte Reload
	cbz	w8, LBB0_736
; %bb.732:                              ; %mma.active804
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	mov.d	x1, v23[1]
	mov.d	x3, v24[1]
	add	x1, x1, x3
	ldr	q3, [sp, #4752]                 ; 16-byte Reload
	mov.d	x3, v3[1]
	ldr	q3, [sp, #4688]                 ; 16-byte Reload
	mov.d	x4, v3[1]
	add	x3, x3, x4
	ldr	q3, [sp, #3376]                 ; 16-byte Reload
	mov.d	x4, v3[1]
	ldr	q3, [sp, #3360]                 ; 16-byte Reload
	mov.d	x20, v3[1]
	add	x4, x4, x20
	ldr	x20, [sp, #168]                 ; 8-byte Reload
LBB0_733:                               ; %mma.update.i858
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_734 Depth 3
	mov	x21, #0                         ; =0x0
	mov	x22, x8
LBB0_734:                               ; %mma.update2.i860
                                        ;   Parent Loop BB0_28 Depth=1
                                        ;     Parent Loop BB0_733 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	umulh	x23, x22, x0
	lsr	x24, x23, #5
	msub	x25, x24, x17, x22
	ldr	q3, [x4, x21]
	lsl	x23, x23, #1
	and	x23, x23, #0x1c0
	add	x24, x1, x23
	add	x23, x3, x25, lsl #2
	ldr	q4, [x23]
	ldp	s6, s16, [x24]
	fmul.4s	v4, v4, v6[0]
	fadd.4s	v3, v3, v4
	ldr	q4, [x23, #192]
	fmul.4s	v4, v4, v16[0]
	fadd.4s	v3, v3, v4
	ldr	q4, [x23, #384]
	ldp	s6, s16, [x24, #8]
	fmul.4s	v4, v4, v6[0]
	fadd.4s	v3, v3, v4
	ldr	q4, [x23, #576]
	fmul.4s	v4, v4, v16[0]
	fadd.4s	v3, v3, v4
	ldr	q4, [x23, #768]
	ldp	s6, s16, [x24, #16]
	fmul.4s	v4, v4, v6[0]
	fadd.4s	v3, v3, v4
	ldr	q4, [x23, #960]
	fmul.4s	v4, v4, v16[0]
	fadd.4s	v3, v3, v4
	ldr	q4, [x23, #1152]
	ldp	s6, s16, [x24, #24]
	fmul.4s	v4, v4, v6[0]
	fadd.4s	v3, v3, v4
	ldr	q4, [x23, #1344]
	fmul.4s	v4, v4, v16[0]
	fadd.4s	v3, v3, v4
	ldr	q4, [x23, #1536]
	ldp	s6, s16, [x24, #32]
	fmul.4s	v4, v4, v6[0]
	fadd.4s	v3, v3, v4
	ldr	q4, [x23, #1728]
	fmul.4s	v4, v4, v16[0]
	fadd.4s	v3, v3, v4
	ldr	q4, [x23, #1920]
	ldp	s6, s16, [x24, #40]
	fmul.4s	v4, v4, v6[0]
	fadd.4s	v3, v3, v4
	ldr	q4, [x23, #2112]
	fmul.4s	v4, v4, v16[0]
	fadd.4s	v3, v3, v4
	ldr	q4, [x23, #2304]
	ldp	s6, s16, [x24, #48]
	fmul.4s	v4, v4, v6[0]
	fadd.4s	v3, v3, v4
	ldr	q4, [x23, #2496]
	fmul.4s	v4, v4, v16[0]
	fadd.4s	v3, v3, v4
	ldr	q4, [x23, #2688]
	ldp	s6, s16, [x24, #56]
	fmul.4s	v4, v4, v6[0]
	fadd.4s	v3, v3, v4
	ldr	q4, [x23, #2880]
	fmul.4s	v4, v4, v16[0]
	fadd.4s	v3, v3, v4
	str	q3, [x20, x21]
	add	x21, x21, #16
	add	x22, x22, #4
	cmp	x21, #192
	b.ne	LBB0_734
; %bb.735:                              ; %mma.fold.done3.i895
                                        ;   in Loop: Header=BB0_733 Depth=2
	add	x16, x16, #1
	add	x8, x8, #48
	add	x20, x20, #192
	add	x4, x4, #192
	cmp	x16, #8
	b.ne	LBB0_733
LBB0_736:                               ; %direct.true807.preheader
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q3, [sp, #2560]                 ; 16-byte Reload
	ldr	q4, [sp, #5360]                 ; 16-byte Reload
	bit.16b	v4, v3, v17
	str	q4, [sp, #5360]                 ; 16-byte Spill
	ldr	q4, [sp, #3296]                 ; 16-byte Reload
	ldr	q6, [sp, #5296]                 ; 16-byte Reload
	bit.16b	v6, v4, v17
	str	q6, [sp, #5296]                 ; 16-byte Spill
	bit.16b	v18, v3, v2
	ldr	q4, [sp, #3280]                 ; 16-byte Reload
	ldr	q6, [sp, #5328]                 ; 16-byte Reload
	bit.16b	v6, v4, v2
	str	q6, [sp, #5328]                 ; 16-byte Spill
	ldr	q2, [sp, #5424]                 ; 16-byte Reload
	fadd.4s	v5, v5, v2
	ldr	q4, [sp, #5408]                 ; 16-byte Reload
	fadd.4s	v17, v7, v4
	ldr	q4, [sp, #5456]                 ; 16-byte Reload
	fadd.4s	v13, v25, v4
	ldr	q4, [sp, #5440]                 ; 16-byte Reload
	fadd.4s	v25, v19, v4
	ldr	q4, [sp, #5488]                 ; 16-byte Reload
	fadd.4s	v2, v26, v4
	str	q2, [sp, #3520]                 ; 16-byte Spill
	ldr	q4, [sp, #5472]                 ; 16-byte Reload
	fadd.4s	v26, v8, v4
	ldr	q4, [sp, #5520]                 ; 16-byte Reload
	fadd.4s	v7, v27, v4
	ldr	q4, [sp, #5504]                 ; 16-byte Reload
	ldr	q2, [sp, #4992]                 ; 16-byte Reload
	fadd.4s	v19, v2, v4
	ldr	q4, [sp, #5552]                 ; 16-byte Reload
	fadd.4s	v2, v30, v4
	str	q2, [sp, #3536]                 ; 16-byte Spill
	ldr	q4, [sp, #5536]                 ; 16-byte Reload
	ldr	q2, [sp, #4272]                 ; 16-byte Reload
	fadd.4s	v27, v2, v4
	ldr	q4, [sp, #5584]                 ; 16-byte Reload
	fadd.4s	v2, v31, v4
	str	q2, [sp, #3568]                 ; 16-byte Spill
	ldr	q4, [sp, #5568]                 ; 16-byte Reload
	ldr	q2, [sp, #3584]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	str	q15, [sp, #4992]                ; 16-byte Spill
	fadd.4s	v4, v11, v15
	str	q4, [sp, #3584]                 ; 16-byte Spill
	ldr	q4, [sp, #5600]                 ; 16-byte Reload
	ldr	q6, [sp, #3552]                 ; 16-byte Reload
	fadd.4s	v30, v6, v4
	str	q21, [sp, #4272]                ; 16-byte Spill
	fadd.4s	v15, v12, v21
	ldr	q4, [sp, #5616]                 ; 16-byte Reload
	ldr	q6, [sp, #3504]                 ; 16-byte Reload
	fadd.4s	v4, v6, v4
	str	q4, [sp, #3552]                 ; 16-byte Spill
	ldr	q11, [sp, #4512]                ; 16-byte Reload
	ldr	q4, [sp, #5344]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #5344]                 ; 16-byte Spill
	ldr	q8, [sp, #4528]                 ; 16-byte Reload
	ldr	q4, [sp, #5376]                 ; 16-byte Reload
	bit.16b	v4, v3, v8
	str	q4, [sp, #5376]                 ; 16-byte Spill
	ldr	q3, [sp, #3328]                 ; 16-byte Reload
	ldr	q4, [sp, #5280]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #5280]                 ; 16-byte Spill
	ldr	x22, [sp, #2760]                ; 8-byte Reload
	add	x16, x22, #5, lsl #12           ; =20480
	ldr	q3, [sp, #3312]                 ; 16-byte Reload
	ldr	q4, [sp, #5312]                 ; 16-byte Reload
	bit.16b	v4, v3, v8
	str	q4, [sp, #5312]                 ; 16-byte Spill
	b	LBB0_738
LBB0_737:                               ; %else1817
                                        ;   in Loop: Header=BB0_738 Depth=2
	ldp	q3, q4, [x16]
	bit.16b	v4, v21, v0
	bit.16b	v3, v6, v1
	stp	q3, q4, [x16], #32
	add	x8, x8, #4
	cmp	x8, #1536
	b.eq	LBB0_754
LBB0_738:                               ; %direct.true807
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w1, s10
	dup.2d	v31, x8
	ldr	q3, [sp, #5328]                 ; 16-byte Reload
	add.2d	v3, v18, v3
	add.2d	v16, v3, v31
	movi.2d	v6, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbz	w1, #0, LBB0_746
; %bb.739:                              ; %cond.load1771
                                        ;   in Loop: Header=BB0_738 Depth=2
	fmov	x3, d16
	ldr	s6, [x3]
	and	w1, w1, #0xff
	tbnz	w1, #1, LBB0_747
LBB0_740:                               ; %else1781
                                        ;   in Loop: Header=BB0_738 Depth=2
	ldr	q3, [sp, #5376]                 ; 16-byte Reload
	ldr	q4, [sp, #5312]                 ; 16-byte Reload
	add.2d	v3, v3, v4
	add.2d	v16, v3, v31
	tbz	w1, #2, LBB0_748
LBB0_741:                               ; %cond.load1783
                                        ;   in Loop: Header=BB0_738 Depth=2
	fmov	x3, d16
	ld1.s	{ v6 }[2], [x3]
	tbnz	w1, #3, LBB0_749
LBB0_742:                               ; %else1793
                                        ;   in Loop: Header=BB0_738 Depth=2
	ldr	q3, [sp, #5360]                 ; 16-byte Reload
	ldr	q4, [sp, #5296]                 ; 16-byte Reload
	add.2d	v3, v3, v4
	add.2d	v16, v3, v31
	tbz	w1, #4, LBB0_750
LBB0_743:                               ; %cond.load1795
                                        ;   in Loop: Header=BB0_738 Depth=2
	fmov	x3, d16
	ld1.s	{ v21 }[0], [x3]
	tbnz	w1, #5, LBB0_751
LBB0_744:                               ; %else1805
                                        ;   in Loop: Header=BB0_738 Depth=2
	ldr	q3, [sp, #5344]                 ; 16-byte Reload
	ldr	q4, [sp, #5280]                 ; 16-byte Reload
	add.2d	v3, v3, v4
	add.2d	v16, v3, v31
	tbz	w1, #6, LBB0_752
LBB0_745:                               ; %cond.load1807
                                        ;   in Loop: Header=BB0_738 Depth=2
	fmov	x3, d16
	ld1.s	{ v21 }[2], [x3]
	tbz	w1, #7, LBB0_737
	b	LBB0_753
LBB0_746:                               ; %else1775
                                        ;   in Loop: Header=BB0_738 Depth=2
	and	w1, w1, #0xff
	tbz	w1, #1, LBB0_740
LBB0_747:                               ; %cond.load1777
                                        ;   in Loop: Header=BB0_738 Depth=2
	mov.d	x3, v16[1]
	ld1.s	{ v6 }[1], [x3]
	ldr	q3, [sp, #5376]                 ; 16-byte Reload
	ldr	q4, [sp, #5312]                 ; 16-byte Reload
	add.2d	v3, v3, v4
	add.2d	v16, v3, v31
	tbnz	w1, #2, LBB0_741
LBB0_748:                               ; %else1787
                                        ;   in Loop: Header=BB0_738 Depth=2
	tbz	w1, #3, LBB0_742
LBB0_749:                               ; %cond.load1789
                                        ;   in Loop: Header=BB0_738 Depth=2
	mov.d	x3, v16[1]
	ld1.s	{ v6 }[3], [x3]
	ldr	q3, [sp, #5360]                 ; 16-byte Reload
	ldr	q4, [sp, #5296]                 ; 16-byte Reload
	add.2d	v3, v3, v4
	add.2d	v16, v3, v31
	tbnz	w1, #4, LBB0_743
LBB0_750:                               ; %else1799
                                        ;   in Loop: Header=BB0_738 Depth=2
	tbz	w1, #5, LBB0_744
LBB0_751:                               ; %cond.load1801
                                        ;   in Loop: Header=BB0_738 Depth=2
	mov.d	x3, v16[1]
	ld1.s	{ v21 }[1], [x3]
	ldr	q3, [sp, #5344]                 ; 16-byte Reload
	ldr	q4, [sp, #5280]                 ; 16-byte Reload
	add.2d	v3, v3, v4
	add.2d	v16, v3, v31
	tbnz	w1, #6, LBB0_745
LBB0_752:                               ; %else1811
                                        ;   in Loop: Header=BB0_738 Depth=2
	tbz	w1, #7, LBB0_737
LBB0_753:                               ; %cond.load1813
                                        ;   in Loop: Header=BB0_738 Depth=2
	mov.d	x1, v16[1]
	ld1.s	{ v21 }[3], [x1]
	b	LBB0_737
LBB0_754:                               ; %direct.true821.preheader
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov.16b	v31, v19
	mov	x8, x22
	mov	w16, #384                       ; =0x180
LBB0_755:                               ; %direct.true821
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x8, #20480]
	ldr	q4, [x8, #20496]
	ldr	q6, [x8, #8192]
	ldr	q16, [x8, #8208]
	bif.16b	v4, v16, v0
	bif.16b	v3, v6, v1
	str	q3, [x8, #8192]
	str	q4, [x8, #8208]
	add	x8, x8, #32
	subs	x16, x16, #1
	b.ne	LBB0_755
; %bb.756:                              ; %direct.false822
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3792]                 ; 16-byte Reload
	ldr	q4, [sp, #2848]                 ; 16-byte Reload
	bit.16b	v3, v4, v0
	str	q3, [sp, #3792]                 ; 16-byte Spill
	ldr	q3, [sp, #2896]                 ; 16-byte Reload
	ldr	q4, [sp, #3808]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #3808]                 ; 16-byte Spill
	ldr	q3, [sp, #4320]                 ; 16-byte Reload
	ldr	q4, [sp, #2832]                 ; 16-byte Reload
	bit.16b	v3, v4, v0
	str	q3, [sp, #4320]                 ; 16-byte Spill
	ldr	q3, [sp, #4336]                 ; 16-byte Reload
	ldr	q4, [sp, #2880]                 ; 16-byte Reload
	bit.16b	v3, v4, v1
	str	q3, [sp, #4336]                 ; 16-byte Spill
	ldr	q3, [sp, #4352]                 ; 16-byte Reload
	ldr	q4, [sp, #3680]                 ; 16-byte Reload
	bit.16b	v3, v4, v0
	str	q3, [sp, #4352]                 ; 16-byte Spill
	ldr	q3, [sp, #4368]                 ; 16-byte Reload
	ldr	q4, [sp, #2864]                 ; 16-byte Reload
	bit.16b	v3, v4, v1
	str	q3, [sp, #4368]                 ; 16-byte Spill
	ldr	q3, [sp, #4384]                 ; 16-byte Reload
	ldr	q4, [sp, #3664]                 ; 16-byte Reload
	bit.16b	v3, v4, v0
	str	q3, [sp, #4384]                 ; 16-byte Spill
	ldr	q3, [sp, #4400]                 ; 16-byte Reload
	ldr	q4, [sp, #3760]                 ; 16-byte Reload
	bit.16b	v3, v4, v1
	str	q3, [sp, #4400]                 ; 16-byte Spill
	ldr	q3, [sp, #4416]                 ; 16-byte Reload
	ldr	q4, [sp, #3648]                 ; 16-byte Reload
	bit.16b	v3, v4, v0
	str	q3, [sp, #4416]                 ; 16-byte Spill
	ldr	q3, [sp, #4432]                 ; 16-byte Reload
	ldr	q4, [sp, #3744]                 ; 16-byte Reload
	bit.16b	v3, v4, v1
	str	q3, [sp, #4432]                 ; 16-byte Spill
	ldr	q3, [sp, #4448]                 ; 16-byte Reload
	ldr	q4, [sp, #3632]                 ; 16-byte Reload
	bit.16b	v3, v4, v0
	str	q3, [sp, #4448]                 ; 16-byte Spill
	ldr	q3, [sp, #4464]                 ; 16-byte Reload
	ldr	q4, [sp, #3728]                 ; 16-byte Reload
	bit.16b	v3, v4, v1
	str	q3, [sp, #4464]                 ; 16-byte Spill
	ldr	q3, [sp, #4480]                 ; 16-byte Reload
	ldr	q4, [sp, #3616]                 ; 16-byte Reload
	bit.16b	v3, v4, v0
	str	q3, [sp, #4480]                 ; 16-byte Spill
	ldr	q3, [sp, #4496]                 ; 16-byte Reload
	ldr	q4, [sp, #3712]                 ; 16-byte Reload
	bit.16b	v3, v4, v1
	str	q3, [sp, #4496]                 ; 16-byte Spill
	ldr	q19, [sp, #4304]                ; 16-byte Reload
	ldr	q3, [sp, #3600]                 ; 16-byte Reload
	bit.16b	v19, v3, v0
	ldr	q6, [sp, #4288]                 ; 16-byte Reload
	ldr	q3, [sp, #3696]                 ; 16-byte Reload
	bit.16b	v6, v3, v1
	ldr	x8, [sp, #3352]                 ; 8-byte Reload
	add	x8, x8, #1
	ldr	q3, [sp, #3824]                 ; 16-byte Reload
	mov.16b	v11, v17
	bit.16b	v3, v17, v0
	str	q3, [sp, #3824]                 ; 16-byte Spill
	ldr	q3, [sp, #3840]                 ; 16-byte Reload
	bit.16b	v3, v5, v1
	str	q3, [sp, #3840]                 ; 16-byte Spill
	ldr	q3, [sp, #3856]                 ; 16-byte Reload
	mov.16b	v8, v25
	bit.16b	v3, v25, v0
	str	q3, [sp, #3856]                 ; 16-byte Spill
	ldr	q3, [sp, #3872]                 ; 16-byte Reload
	bit.16b	v3, v13, v1
	str	q3, [sp, #3872]                 ; 16-byte Spill
	ldr	q3, [sp, #3888]                 ; 16-byte Reload
	mov.16b	v16, v13
	mov.16b	v13, v26
	bit.16b	v3, v26, v0
	str	q3, [sp, #3888]                 ; 16-byte Spill
	ldr	q3, [sp, #3904]                 ; 16-byte Reload
	ldr	q12, [sp, #3520]                ; 16-byte Reload
	bit.16b	v3, v12, v1
	str	q3, [sp, #3904]                 ; 16-byte Spill
	ldr	q3, [sp, #3920]                 ; 16-byte Reload
	bit.16b	v3, v31, v0
	str	q3, [sp, #3920]                 ; 16-byte Spill
	ldr	q3, [sp, #3936]                 ; 16-byte Reload
	bit.16b	v3, v7, v1
	str	q3, [sp, #3936]                 ; 16-byte Spill
	ldr	q3, [sp, #3952]                 ; 16-byte Reload
	mov.16b	v4, v27
	bit.16b	v3, v27, v0
	str	q3, [sp, #3952]                 ; 16-byte Spill
	ldr	q3, [sp, #3968]                 ; 16-byte Reload
	ldr	q17, [sp, #3536]                ; 16-byte Reload
	bit.16b	v3, v17, v1
	str	q3, [sp, #3968]                 ; 16-byte Spill
	ldr	q3, [sp, #3984]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #3984]                 ; 16-byte Spill
	ldr	q3, [sp, #4000]                 ; 16-byte Reload
	ldr	q25, [sp, #3568]                ; 16-byte Reload
	bit.16b	v3, v25, v1
	str	q3, [sp, #4000]                 ; 16-byte Spill
	ldr	q3, [sp, #4016]                 ; 16-byte Reload
	mov.16b	v26, v30
	bit.16b	v3, v30, v0
	str	q3, [sp, #4016]                 ; 16-byte Spill
	ldr	q3, [sp, #4032]                 ; 16-byte Reload
	ldr	q27, [sp, #3584]                ; 16-byte Reload
	bit.16b	v3, v27, v1
	str	q3, [sp, #4032]                 ; 16-byte Spill
	ldr	q3, [sp, #4048]                 ; 16-byte Reload
	ldr	q30, [sp, #3552]                ; 16-byte Reload
	bit.16b	v3, v30, v0
	str	q3, [sp, #4048]                 ; 16-byte Spill
	ldr	q3, [sp, #4064]                 ; 16-byte Reload
	mov.16b	v21, v15
	bit.16b	v3, v15, v1
	str	q3, [sp, #4064]                 ; 16-byte Spill
	cmp	x8, #9
	ldr	q3, [sp, #5008]                 ; 16-byte Reload
	ldr	q15, [sp, #4272]                ; 16-byte Reload
	b.ne	LBB0_28
; %bb.757:                              ; %direct.false217
	mov	x8, #0                          ; =0x0
	add	x9, x22, #28, lsl #12           ; =114688
	add	x9, x9, #3200
	ldp	q20, q6, [x9]
	mov.16b	v18, v2
	mov.16b	v19, v4
	sshll.2d	v4, v1, #0
	sshll.2d	v3, v0, #0
	bit.16b	v6, v11, v0
	mov.16b	v2, v1
	bsl.16b	v2, v5, v20
	stp	q2, q6, [x9]
	add	x9, x22, #28, lsl #12           ; =114688
	add	x9, x9, #3232
	ldp	q2, q5, [x9]
	bit.16b	v5, v8, v0
	bit.16b	v2, v16, v1
	stp	q2, q5, [x9]
	add	x9, x22, #28, lsl #12           ; =114688
	add	x9, x9, #3264
	ldp	q2, q5, [x9]
	bit.16b	v5, v13, v0
	bit.16b	v2, v12, v1
	stp	q2, q5, [x9]
	add	x9, x22, #28, lsl #12           ; =114688
	add	x9, x9, #3296
	ldp	q2, q5, [x9]
	bit.16b	v5, v31, v0
	bit.16b	v2, v7, v1
	stp	q2, q5, [x9]
	add	x9, x22, #28, lsl #12           ; =114688
	add	x9, x9, #3328
	ldp	q2, q5, [x9]
	bit.16b	v5, v19, v0
	bit.16b	v2, v17, v1
	stp	q2, q5, [x9]
	add	x9, x22, #28, lsl #12           ; =114688
	add	x9, x9, #3360
	ldp	q2, q5, [x9]
	bit.16b	v5, v18, v0
	bit.16b	v2, v25, v1
	stp	q2, q5, [x9]
	add	x9, x22, #28, lsl #12           ; =114688
	add	x9, x9, #3392
	ldp	q2, q5, [x9]
	bit.16b	v5, v26, v0
	bit.16b	v2, v27, v1
	add	x11, x22, #28, lsl #12          ; =114688
	add	x11, x11, #3424
	ldp	q6, q7, [x11]
	bit.16b	v7, v30, v0
	bit.16b	v6, v21, v1
	ldp	q16, q18, [sp, #128]            ; 32-byte Folded Reload
	shl.2d	v16, v16, #6
	ldp	q20, q17, [sp, #48]             ; 32-byte Folded Reload
	shl.2d	v17, v17, #6
	shl.2d	v18, v18, #6
	ldr	q19, [sp, #32]                  ; 16-byte Reload
	shl.2d	v19, v19, #6
	orr.16b	v19, v19, v20
	ldp	q20, q21, [sp, #80]             ; 32-byte Folded Reload
	orr.16b	v18, v18, v21
	orr.16b	v17, v17, v20
	ldr	q20, [sp, #112]                 ; 16-byte Reload
	orr.16b	v16, v16, v20
	stp	q2, q5, [x9]
	ldr	q2, [sp, #4528]                 ; 16-byte Reload
	and.16b	v2, v2, v16
	and.16b	v3, v3, v17
	and.16b	v4, v4, v18
	ldr	q5, [sp, #4512]                 ; 16-byte Reload
	and.16b	v5, v5, v19
	mov	w9, #43691                      ; =0xaaab
	stp	q6, q7, [x11]
	mov	w11, #48                        ; =0x30
	ldp	x17, x16, [sp, #16]             ; 16-byte Folded Reload
	b	LBB0_759
LBB0_758:                               ; %else1851
                                        ;   in Loop: Header=BB0_759 Depth=1
	add	x8, x8, #1
	cmp	x8, #384
	b.eq	LBB0_775
LBB0_759:                               ; %direct.true928
                                        ; =>This Inner Loop Header: Depth=1
	fmov	w12, s10
	and	w13, w8, #0xffff
	mul	w13, w13, w9
	lsr	w13, w13, #21
	dup.2d	v6, x13
	add.2d	v7, v4, v6
	mov.d	x14, v7[1]
	fmov	x15, d7
	add	x15, x15, x15, lsl #1
	lsl	x15, x15, #4
	fmov	d16, x15
	msub	w15, w13, w11, w8
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #4
	mov.d	v16[1], x14
	and	x14, x15, #0xffff
	dup.2d	v7, x14
	add.2d	v16, v16, v7
	umaddl	x14, w13, w11, x14
	add	x14, x10, x14, lsl #5
	ldp	q18, q17, [x14]
	and.16b	v19, v1, v18
	add	x13, x16, x13, lsl #5
	ldp	q20, q18, [x13]
	and.16b	v20, v1, v20
	fdiv.4s	v19, v19, v20
	shl.2d	v20, v16, #2
	dup.2d	v16, x17
	add.2d	v20, v16, v20
	tbz	w12, #0, LBB0_761
; %bb.760:                              ; %cond.store1820
                                        ;   in Loop: Header=BB0_759 Depth=1
	fmov	x13, d20
	str	s19, [x13]
LBB0_761:                               ; %else1823
                                        ;   in Loop: Header=BB0_759 Depth=1
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_763
; %bb.762:                              ; %cond.store1824
                                        ;   in Loop: Header=BB0_759 Depth=1
	mov.d	x13, v20[1]
	st1.s	{ v19 }[1], [x13]
LBB0_763:                               ; %else1827
                                        ;   in Loop: Header=BB0_759 Depth=1
	add.2d	v20, v2, v6
	mov.d	x13, v20[1]
	fmov	x14, d20
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #4
	fmov	d20, x14
	add	x13, x13, x13, lsl #1
	lsl	x13, x13, #4
	mov.d	v20[1], x13
	add.2d	v20, v20, v7
	shl.2d	v20, v20, #2
	add.2d	v20, v16, v20
	tbz	w12, #2, LBB0_765
; %bb.764:                              ; %cond.store1828
                                        ;   in Loop: Header=BB0_759 Depth=1
	fmov	x13, d20
	st1.s	{ v19 }[2], [x13]
LBB0_765:                               ; %else1831
                                        ;   in Loop: Header=BB0_759 Depth=1
	tbz	w12, #3, LBB0_767
; %bb.766:                              ; %cond.store1832
                                        ;   in Loop: Header=BB0_759 Depth=1
	mov.d	x13, v20[1]
	st1.s	{ v19 }[3], [x13]
LBB0_767:                               ; %else1835
                                        ;   in Loop: Header=BB0_759 Depth=1
	add.2d	v19, v3, v6
	mov.d	x13, v19[1]
	fmov	x14, d19
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #4
	fmov	d19, x14
	add	x13, x13, x13, lsl #1
	lsl	x13, x13, #4
	mov.d	v19[1], x13
	add.2d	v19, v19, v7
	and.16b	v17, v0, v17
	and.16b	v18, v0, v18
	fdiv.4s	v17, v17, v18
	shl.2d	v18, v19, #2
	add.2d	v18, v16, v18
	tbz	w12, #4, LBB0_769
; %bb.768:                              ; %cond.store1836
                                        ;   in Loop: Header=BB0_759 Depth=1
	fmov	x13, d18
	str	s17, [x13]
LBB0_769:                               ; %else1839
                                        ;   in Loop: Header=BB0_759 Depth=1
	tbz	w12, #5, LBB0_771
; %bb.770:                              ; %cond.store1840
                                        ;   in Loop: Header=BB0_759 Depth=1
	mov.d	x13, v18[1]
	st1.s	{ v17 }[1], [x13]
LBB0_771:                               ; %else1843
                                        ;   in Loop: Header=BB0_759 Depth=1
	add.2d	v6, v5, v6
	mov.d	x13, v6[1]
	fmov	x14, d6
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #4
	fmov	d6, x14
	add	x13, x13, x13, lsl #1
	lsl	x13, x13, #4
	mov.d	v6[1], x13
	add.2d	v6, v6, v7
	shl.2d	v6, v6, #2
	add.2d	v6, v16, v6
	tbz	w12, #6, LBB0_773
; %bb.772:                              ; %cond.store1844
                                        ;   in Loop: Header=BB0_759 Depth=1
	fmov	x13, d6
	st1.s	{ v17 }[2], [x13]
	tbz	w12, #7, LBB0_758
	b	LBB0_774
LBB0_773:                               ; %else1847
                                        ;   in Loop: Header=BB0_759 Depth=1
	tbz	w12, #7, LBB0_758
LBB0_774:                               ; %cond.store1848
                                        ;   in Loop: Header=BB0_759 Depth=1
	mov.d	x12, v6[1]
	st1.s	{ v17 }[3], [x12]
	b	LBB0_758
LBB0_775:
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #1760
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
LBB0_776:                               ; %common.ret
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh156, Lloh157
	.loh AdrpAdrp	Lloh149, Lloh156
	.loh AdrpLdr	Lloh149, Lloh150
	.loh AdrpAdrp	Lloh147, Lloh149
	.loh AdrpLdr	Lloh147, Lloh148
	.loh AdrpAdrp	Lloh145, Lloh147
	.loh AdrpLdr	Lloh145, Lloh146
	.loh AdrpAdrp	Lloh143, Lloh145
	.loh AdrpLdr	Lloh143, Lloh144
	.loh AdrpAdrp	Lloh141, Lloh143
	.loh AdrpLdr	Lloh141, Lloh142
	.loh AdrpAdrp	Lloh138, Lloh141
	.loh AdrpLdr	Lloh138, Lloh139
	.loh AdrpLdr	Lloh137, Lloh165
	.loh AdrpLdr	Lloh136, Lloh164
	.loh AdrpLdr	Lloh135, Lloh163
	.loh AdrpLdr	Lloh134, Lloh162
	.loh AdrpLdr	Lloh133, Lloh161
	.loh AdrpLdr	Lloh132, Lloh160
	.loh AdrpLdr	Lloh131, Lloh159
	.loh AdrpLdr	Lloh130, Lloh158
	.loh AdrpLdr	Lloh129, Lloh155
	.loh AdrpLdr	Lloh128, Lloh154
	.loh AdrpLdr	Lloh127, Lloh153
	.loh AdrpLdr	Lloh126, Lloh152
	.loh AdrpLdr	Lloh125, Lloh151
	.loh AdrpLdr	Lloh124, Lloh140
	.loh AdrpLdr	Lloh122, Lloh123
	.loh AdrpAdrp	Lloh120, Lloh122
	.loh AdrpLdr	Lloh120, Lloh121
	.loh AdrpAdrp	Lloh118, Lloh120
	.loh AdrpLdr	Lloh118, Lloh119
	.loh AdrpAdrp	Lloh116, Lloh118
	.loh AdrpLdr	Lloh116, Lloh117
	.loh AdrpAdrp	Lloh114, Lloh116
	.loh AdrpLdr	Lloh114, Lloh115
	.loh AdrpAdrp	Lloh112, Lloh114
	.loh AdrpLdr	Lloh112, Lloh113
	.loh AdrpAdrp	Lloh110, Lloh112
	.loh AdrpLdr	Lloh110, Lloh111
	.loh AdrpAdrp	Lloh108, Lloh110
	.loh AdrpLdr	Lloh108, Lloh109
	.loh AdrpAdrp	Lloh106, Lloh108
	.loh AdrpLdr	Lloh106, Lloh107
	.loh AdrpAdrp	Lloh104, Lloh106
	.loh AdrpLdr	Lloh104, Lloh105
	.loh AdrpAdrp	Lloh102, Lloh104
	.loh AdrpLdr	Lloh102, Lloh103
	.loh AdrpAdrp	Lloh100, Lloh102
	.loh AdrpLdr	Lloh100, Lloh101
	.loh AdrpAdrp	Lloh98, Lloh100
	.loh AdrpLdr	Lloh98, Lloh99
	.loh AdrpAdrp	Lloh96, Lloh98
	.loh AdrpLdr	Lloh96, Lloh97
	.loh AdrpAdrp	Lloh94, Lloh96
	.loh AdrpLdr	Lloh94, Lloh95
	.loh AdrpAdrp	Lloh92, Lloh94
	.loh AdrpLdr	Lloh92, Lloh93
	.loh AdrpAdrp	Lloh90, Lloh92
	.loh AdrpLdr	Lloh90, Lloh91
	.loh AdrpAdrp	Lloh88, Lloh90
	.loh AdrpLdr	Lloh88, Lloh89
	.loh AdrpAdrp	Lloh86, Lloh88
	.loh AdrpLdr	Lloh86, Lloh87
	.loh AdrpAdrp	Lloh84, Lloh86
	.loh AdrpLdr	Lloh84, Lloh85
	.loh AdrpAdrp	Lloh82, Lloh84
	.loh AdrpLdr	Lloh82, Lloh83
	.loh AdrpAdrp	Lloh80, Lloh82
	.loh AdrpLdr	Lloh80, Lloh81
	.loh AdrpAdrp	Lloh78, Lloh80
	.loh AdrpLdr	Lloh78, Lloh79
	.loh AdrpAdrp	Lloh76, Lloh78
	.loh AdrpLdr	Lloh76, Lloh77
	.loh AdrpAdrp	Lloh74, Lloh76
	.loh AdrpLdr	Lloh74, Lloh75
	.loh AdrpAdrp	Lloh72, Lloh74
	.loh AdrpLdr	Lloh72, Lloh73
	.loh AdrpAdrp	Lloh70, Lloh72
	.loh AdrpLdr	Lloh70, Lloh71
	.loh AdrpAdrp	Lloh68, Lloh70
	.loh AdrpLdr	Lloh68, Lloh69
	.loh AdrpAdrp	Lloh66, Lloh68
	.loh AdrpLdr	Lloh66, Lloh67
	.loh AdrpAdrp	Lloh64, Lloh66
	.loh AdrpLdr	Lloh64, Lloh65
	.loh AdrpAdrp	Lloh62, Lloh64
	.loh AdrpLdr	Lloh62, Lloh63
	.loh AdrpLdr	Lloh60, Lloh61
	.loh AdrpLdr	Lloh58, Lloh59
	.loh AdrpLdr	Lloh56, Lloh57
	.loh AdrpLdr	Lloh54, Lloh55
	.loh AdrpLdr	Lloh52, Lloh53
	.loh AdrpLdr	Lloh50, Lloh51
	.loh AdrpLdr	Lloh48, Lloh49
	.loh AdrpLdr	Lloh46, Lloh47
	.loh AdrpLdr	Lloh44, Lloh45
	.loh AdrpLdr	Lloh42, Lloh43
	.loh AdrpAdrp	Lloh40, Lloh42
	.loh AdrpLdr	Lloh40, Lloh41
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpAdrp	Lloh36, Lloh38
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpAdrp	Lloh34, Lloh36
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpAdrp	Lloh32, Lloh34
	.loh AdrpLdr	Lloh32, Lloh33
	.loh AdrpAdrp	Lloh30, Lloh32
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdrp	Lloh28, Lloh30
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh166, Lloh167
	.loh AdrpLdr	Lloh168, Lloh169
	.loh AdrpLdr	Lloh170, Lloh171
	.loh AdrpLdr	Lloh172, Lloh173
	.loh AdrpLdr	Lloh180, Lloh181
	.loh AdrpAdrp	Lloh178, Lloh180
	.loh AdrpLdr	Lloh178, Lloh179
	.loh AdrpAdrp	Lloh176, Lloh178
	.loh AdrpLdr	Lloh176, Lloh177
	.loh AdrpAdrp	Lloh174, Lloh176
	.loh AdrpLdr	Lloh174, Lloh175
                                        ; -- End function
	.globl	_llm_attention.packet_batch.blocks ; -- Begin function llm_attention.packet_batch.blocks
	.p2align	2
_llm_attention.packet_batch.blocks:     ; @llm_attention.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_3:                                 ; %llm_attention.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

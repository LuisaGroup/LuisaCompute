	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.quad	96                              ; 0x60
	.quad	112                             ; 0x70
lCPI0_3:
	.quad	64                              ; 0x40
	.quad	80                              ; 0x50
lCPI0_4:
	.quad	32                              ; 0x20
	.quad	48                              ; 0x30
lCPI0_5:
	.quad	0                               ; 0x0
	.quad	16                              ; 0x10
lCPI0_6:
	.quad	97                              ; 0x61
	.quad	113                             ; 0x71
lCPI0_7:
	.quad	65                              ; 0x41
	.quad	81                              ; 0x51
lCPI0_8:
	.quad	33                              ; 0x21
	.quad	49                              ; 0x31
lCPI0_9:
	.quad	1                               ; 0x1
	.quad	17                              ; 0x11
lCPI0_10:
	.quad	98                              ; 0x62
	.quad	114                             ; 0x72
lCPI0_11:
	.quad	66                              ; 0x42
	.quad	82                              ; 0x52
lCPI0_12:
	.quad	34                              ; 0x22
	.quad	50                              ; 0x32
lCPI0_13:
	.quad	2                               ; 0x2
	.quad	18                              ; 0x12
lCPI0_14:
	.quad	99                              ; 0x63
	.quad	115                             ; 0x73
lCPI0_15:
	.quad	67                              ; 0x43
	.quad	83                              ; 0x53
lCPI0_16:
	.quad	35                              ; 0x23
	.quad	51                              ; 0x33
lCPI0_17:
	.quad	3                               ; 0x3
	.quad	19                              ; 0x13
lCPI0_18:
	.quad	100                             ; 0x64
	.quad	116                             ; 0x74
lCPI0_19:
	.quad	68                              ; 0x44
	.quad	84                              ; 0x54
lCPI0_20:
	.quad	36                              ; 0x24
	.quad	52                              ; 0x34
lCPI0_21:
	.quad	4                               ; 0x4
	.quad	20                              ; 0x14
lCPI0_22:
	.quad	101                             ; 0x65
	.quad	117                             ; 0x75
lCPI0_23:
	.quad	69                              ; 0x45
	.quad	85                              ; 0x55
lCPI0_24:
	.quad	37                              ; 0x25
	.quad	53                              ; 0x35
lCPI0_25:
	.quad	5                               ; 0x5
	.quad	21                              ; 0x15
lCPI0_26:
	.quad	102                             ; 0x66
	.quad	118                             ; 0x76
lCPI0_27:
	.quad	70                              ; 0x46
	.quad	86                              ; 0x56
lCPI0_28:
	.quad	38                              ; 0x26
	.quad	54                              ; 0x36
lCPI0_29:
	.quad	6                               ; 0x6
	.quad	22                              ; 0x16
lCPI0_30:
	.quad	103                             ; 0x67
	.quad	119                             ; 0x77
lCPI0_31:
	.quad	71                              ; 0x47
	.quad	87                              ; 0x57
lCPI0_32:
	.quad	39                              ; 0x27
	.quad	55                              ; 0x37
lCPI0_33:
	.quad	7                               ; 0x7
	.quad	23                              ; 0x17
lCPI0_34:
	.quad	104                             ; 0x68
	.quad	120                             ; 0x78
lCPI0_35:
	.quad	72                              ; 0x48
	.quad	88                              ; 0x58
lCPI0_36:
	.quad	40                              ; 0x28
	.quad	56                              ; 0x38
lCPI0_37:
	.quad	8                               ; 0x8
	.quad	24                              ; 0x18
lCPI0_38:
	.quad	105                             ; 0x69
	.quad	121                             ; 0x79
lCPI0_39:
	.quad	73                              ; 0x49
	.quad	89                              ; 0x59
lCPI0_40:
	.quad	41                              ; 0x29
	.quad	57                              ; 0x39
lCPI0_41:
	.quad	9                               ; 0x9
	.quad	25                              ; 0x19
lCPI0_42:
	.quad	106                             ; 0x6a
	.quad	122                             ; 0x7a
lCPI0_43:
	.quad	74                              ; 0x4a
	.quad	90                              ; 0x5a
lCPI0_44:
	.quad	42                              ; 0x2a
	.quad	58                              ; 0x3a
lCPI0_45:
	.quad	10                              ; 0xa
	.quad	26                              ; 0x1a
lCPI0_46:
	.quad	107                             ; 0x6b
	.quad	123                             ; 0x7b
lCPI0_47:
	.quad	75                              ; 0x4b
	.quad	91                              ; 0x5b
lCPI0_48:
	.quad	43                              ; 0x2b
	.quad	59                              ; 0x3b
lCPI0_49:
	.quad	11                              ; 0xb
	.quad	27                              ; 0x1b
lCPI0_50:
	.quad	108                             ; 0x6c
	.quad	124                             ; 0x7c
lCPI0_51:
	.quad	76                              ; 0x4c
	.quad	92                              ; 0x5c
lCPI0_52:
	.quad	44                              ; 0x2c
	.quad	60                              ; 0x3c
lCPI0_53:
	.quad	12                              ; 0xc
	.quad	28                              ; 0x1c
lCPI0_54:
	.quad	109                             ; 0x6d
	.quad	125                             ; 0x7d
lCPI0_55:
	.quad	77                              ; 0x4d
	.quad	93                              ; 0x5d
lCPI0_56:
	.quad	45                              ; 0x2d
	.quad	61                              ; 0x3d
lCPI0_57:
	.quad	13                              ; 0xd
	.quad	29                              ; 0x1d
lCPI0_58:
	.quad	110                             ; 0x6e
	.quad	126                             ; 0x7e
lCPI0_59:
	.quad	78                              ; 0x4e
	.quad	94                              ; 0x5e
lCPI0_60:
	.quad	46                              ; 0x2e
	.quad	62                              ; 0x3e
lCPI0_61:
	.quad	14                              ; 0xe
	.quad	30                              ; 0x1e
lCPI0_62:
	.quad	111                             ; 0x6f
	.quad	127                             ; 0x7f
lCPI0_63:
	.quad	79                              ; 0x4f
	.quad	95                              ; 0x5f
lCPI0_64:
	.quad	47                              ; 0x2f
	.quad	63                              ; 0x3f
lCPI0_65:
	.quad	15                              ; 0xf
	.quad	31                              ; 0x1f
lCPI0_66:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_67:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_68:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_69:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_70:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_71:
	.quad	768                             ; 0x300
	.quad	896                             ; 0x380
lCPI0_72:
	.quad	256                             ; 0x100
	.quad	384                             ; 0x180
lCPI0_73:
	.quad	512                             ; 0x200
	.quad	640                             ; 0x280
lCPI0_74:
	.quad	0                               ; 0x0
	.quad	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention:                         ; @llm_attention
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #2, lsl #12             ; =8192
	sub	sp, sp, #1936
	dup.4s	v6, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q16, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q7, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v0, v6, v7
	cmhi.4s	v1, v6, v16
	uzp1.8h	v2, v1, v0
	str	q2, [sp, #3680]                 ; 16-byte Spill
	umaxv.8h	h2, v2
	fmov	w8, s2
	tbz	w8, #0, LBB0_460
; %bb.1:                                ; %direct.activate
	ldr	x8, [x1, #136]
	ldr	x9, [x0]
	xtn.4h	v2, v1
	uzp1.8b	v20, v2, v0
	sshll.2d	v18, v1, #0
	sshll.2d	v2, v0, #0
	sshll2.2d	v9, v1, #0
	ldr	w10, [x1]
	ldr	w11, [x1, #36]
	add	w10, w11, w10, lsl #5
	dup.4s	v3, w10
	add.4s	v4, v3, v7
	add.4s	v3, v3, v16
	and.16b	v21, v1, v3
	and.16b	v3, v0, v4
	ushll2.2d	v4, v21, #0
	ushll.2d	v19, v21, #0
	mov	w10, #3                         ; =0x3
	dup.2d	v5, x10
	and.16b	v22, v9, v5
	and.16b	v17, v2, v5
	and.16b	v23, v18, v5
	neg.2d	v23, v23
	ushl.2d	v24, v19, v23
	neg.2d	v19, v22
	ushl.2d	v25, v4, v19
	ushll2.2d	v22, v21, #3
	ushll.2d	v19, v3, #3
	ushll.2d	v21, v21, #3
	mov	w10, #56                        ; =0x38
	dup.2d	v4, x10
	and.16b	v27, v21, v4
	and.16b	v26, v22, v4
	shl.2d	v21, v24, #11
	shl.2d	v22, v26, #5
	shl.2d	v23, v27, #5
	and.16b	v18, v18, v23
	orr.16b	v18, v18, v21
	umov.b	w10, v20[0]
	str	w10, [sp, #3676]                ; 4-byte Spill
	tbz	w10, #0, LBB0_4
; %bb.2:                                ; %copy.active
	mov	x10, #0                         ; =0x0
	fmov	x11, d18
	add	x11, x9, x11, lsl #2
	add	x12, x8, #64
LBB0_3:                                 ; %copy.chunk.i
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q20, [x11, x10]
	stur	s20, [x12, #-64]
	mov	s21, v20[1]
	stur	s21, [x12, #-32]
	st1.s	{ v20 }[2], [x12]
	add	x13, x12, #32
	st1.s	{ v20 }[3], [x13]
	add	x10, x10, #16
	add	x12, x12, #128
	cmp	x10, #1024
	b.ne	LBB0_3
LBB0_4:                                 ; %copy.continue
	sshll2.2d	v23, v0, #0
	ushll.2d	v20, v3, #0
	neg.2d	v21, v17
	and.16b	v29, v19, v4
	shl.2d	v19, v25, #11
	and.16b	v22, v9, v22
	mov.s	w10, v6[1]
	cmp	w10, #1
	cset	w11, hi
	str	w11, [sp, #3672]                ; 4-byte Spill
	cmp	w10, #2
	b.lo	LBB0_7
; %bb.5:                                ; %copy.active191
	mov	x11, #0                         ; =0x0
	mov.d	x12, v18[1]
	add	x12, x9, x12, lsl #2
	add	x13, x8, #68
LBB0_6:                                 ; %copy.chunk.i879
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q17, [x12, x11]
	stur	s17, [x13, #-64]
	mov	s18, v17[1]
	stur	s18, [x13, #-32]
	st1.s	{ v17 }[2], [x13]
	add	x14, x13, #32
	st1.s	{ v17 }[3], [x14]
	add	x11, x11, #16
	add	x13, x13, #128
	cmp	x11, #1024
	b.ne	LBB0_6
LBB0_7:                                 ; %copy.continue192
	and.16b	v17, v23, v5
	ushll2.2d	v18, v3, #3
	ushl.2d	v28, v20, v21
	shl.2d	v20, v29, #5
	orr.16b	v5, v22, v19
	mov.s	w12, v6[2]
	cmp	w12, #2
	cset	w11, hi
	str	w11, [sp, #3668]                ; 4-byte Spill
	cmp	w12, #3
	b.lo	LBB0_10
; %bb.8:                                ; %copy.active193
	mov	x11, #0                         ; =0x0
	fmov	x13, d5
	add	x13, x9, x13, lsl #2
	add	x14, x8, #72
LBB0_9:                                 ; %copy.chunk.i885
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q19, [x13, x11]
	stur	s19, [x14, #-64]
	mov	s21, v19[1]
	stur	s21, [x14, #-32]
	st1.s	{ v19 }[2], [x14]
	add	x15, x14, #32
	st1.s	{ v19 }[3], [x15]
	add	x11, x11, #16
	add	x14, x14, #128
	cmp	x11, #1024
	b.ne	LBB0_9
LBB0_10:                                ; %copy.continue194
	ushll2.2d	v3, v3, #0
	neg.2d	v17, v17
	and.16b	v19, v18, v4
	shl.2d	v4, v28, #11
	and.16b	v2, v2, v20
	mov.s	w11, v6[3]
	cmp	w11, #3
	cset	w13, hi
	str	w13, [sp, #3664]                ; 4-byte Spill
	cmp	w11, #4
	b.lo	LBB0_13
; %bb.11:                               ; %copy.active195
	mov	x13, #0                         ; =0x0
	mov.d	x14, v5[1]
	add	x14, x9, x14, lsl #2
	add	x15, x8, #76
LBB0_12:                                ; %copy.chunk.i891
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q5, [x14, x13]
	stur	s5, [x15, #-64]
	mov	s18, v5[1]
	stur	s18, [x15, #-32]
	st1.s	{ v5 }[2], [x15]
	add	x16, x15, #32
	st1.s	{ v5 }[3], [x16]
	add	x13, x13, #16
	add	x15, x15, #128
	cmp	x13, #1024
	b.ne	LBB0_12
LBB0_13:                                ; %copy.continue196
	ushl.2d	v17, v3, v17
	shl.2d	v3, v19, #5
	orr.16b	v2, v2, v4
	fmov	w13, s6
	cmp	w13, #4
	cset	w14, hi
	str	w14, [sp, #3660]                ; 4-byte Spill
	cmp	w13, #5
	b.lo	LBB0_16
; %bb.14:                               ; %copy.active197
	mov	x13, #0                         ; =0x0
	fmov	x14, d2
	add	x14, x9, x14, lsl #2
	add	x15, x8, #80
LBB0_15:                                ; %copy.chunk.i897
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q4, [x14, x13]
	stur	s4, [x15, #-64]
	mov	s5, v4[1]
	stur	s5, [x15, #-32]
	st1.s	{ v4 }[2], [x15]
	add	x16, x15, #32
	st1.s	{ v4 }[3], [x16]
	add	x13, x13, #16
	add	x15, x15, #128
	cmp	x13, #1024
	b.ne	LBB0_15
LBB0_16:                                ; %copy.continue198
	shl.2d	v4, v17, #11
	and.16b	v3, v23, v3
	cmp	w10, #5
	cset	w13, hi
	str	w13, [sp, #3656]                ; 4-byte Spill
	cmp	w10, #6
	b.lo	LBB0_19
; %bb.17:                               ; %copy.active199
	mov	x10, #0                         ; =0x0
	mov.d	x13, v2[1]
	add	x13, x9, x13, lsl #2
	add	x14, x8, #84
LBB0_18:                                ; %copy.chunk.i903
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q2, [x13, x10]
	stur	s2, [x14, #-64]
	mov	s5, v2[1]
	stur	s5, [x14, #-32]
	st1.s	{ v2 }[2], [x14]
	add	x15, x14, #32
	st1.s	{ v2 }[3], [x15]
	add	x10, x10, #16
	add	x14, x14, #128
	cmp	x10, #1024
	b.ne	LBB0_18
LBB0_19:                                ; %copy.continue200
	orr.16b	v2, v3, v4
	cmp	w12, #6
	cset	w10, hi
	str	w10, [sp, #3652]                ; 4-byte Spill
	cmp	w12, #7
	b.lo	LBB0_22
; %bb.20:                               ; %copy.active201
	mov	x10, #0                         ; =0x0
	fmov	x12, d2
	add	x12, x9, x12, lsl #2
	add	x13, x8, #88
LBB0_21:                                ; %copy.chunk.i909
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q3, [x12, x10]
	stur	s3, [x13, #-64]
	mov	s4, v3[1]
	stur	s4, [x13, #-32]
	st1.s	{ v3 }[2], [x13]
	add	x14, x13, #32
	st1.s	{ v3 }[3], [x14]
	add	x10, x10, #16
	add	x13, x13, #128
	cmp	x10, #1024
	b.ne	LBB0_21
LBB0_22:                                ; %copy.continue202
	add	x15, x8, #8, lsl #12            ; =32768
	add	x3, x8, #12, lsl #12            ; =49152
	add	x12, x8, #19, lsl #12           ; =77824
	add	x10, x8, #19, lsl #12           ; =77824
	add	x10, x10, #1664
	add	x13, x8, #19, lsl #12           ; =77824
	add	x28, x13, #2688
	add	x13, x8, #21, lsl #12           ; =86016
	add	x13, x13, #3200
	str	x13, [sp, #3632]                ; 8-byte Spill
	cmp	w11, #7
	cset	w13, hi
	str	w13, [sp, #3628]                ; 4-byte Spill
	cmp	w11, #8
	b.lo	LBB0_25
; %bb.23:                               ; %copy.active203
	mov	x11, #0                         ; =0x0
	mov.d	x13, v2[1]
	add	x9, x9, x13, lsl #2
	add	x13, x8, #92
LBB0_24:                                ; %copy.chunk.i915
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q2, [x9, x11]
	stur	s2, [x13, #-64]
	mov	s3, v2[1]
	stur	s3, [x13, #-32]
	st1.s	{ v2 }[2], [x13]
	add	x14, x13, #32
	st1.s	{ v2 }[3], [x14]
	add	x11, x11, #16
	add	x13, x13, #128
	cmp	x11, #1024
	b.ne	LBB0_24
LBB0_25:                                ; %direct.true.preheader
	mov	x9, #0                          ; =0x0
	dup.2d	v2, x15
	str	q2, [sp, #3600]                 ; 16-byte Spill
	dup.2d	v31, x3
	dup.2d	v2, x12
	str	q2, [sp, #3696]                 ; 16-byte Spill
	add	x12, x8, #2, lsl #12            ; =8192
	add	x11, x8, #19, lsl #12           ; =77824
	add	x30, x11, #128
	add	x11, x8, #19, lsl #12           ; =77824
	dup.2d	v2, x10
	str	q2, [sp, #3552]                 ; 16-byte Spill
	add	x10, x11, #1152
	str	x10, [sp, #3544]                ; 8-byte Spill
	add	x10, x8, #20, lsl #12           ; =81920
	add	x10, x10, #2688
	str	x10, [sp, #3536]                ; 8-byte Spill
	add	x10, x8, #20, lsl #12           ; =81920
	add	x21, x10, #2944
	add	x10, x8, #20, lsl #12           ; =81920
	add	x22, x10, #3200
	add	x10, x8, #24, lsl #12           ; =98304
	add	x11, x10, #3200
	ldr	x2, [x0, #16]
	ldr	x4, [x0, #32]
	ldr	x10, [x0, #48]
	stp	x10, x11, [sp, #16]             ; 16-byte Folded Spill
	str	q17, [sp, #32]                  ; 16-byte Spill
	ushr.2d	v5, v17, #1
	stp	q25, q24, [sp, #128]            ; 32-byte Folded Spill
	ushr.2d	v3, v25, #1
	str	q28, [sp, #64]                  ; 16-byte Spill
	ushr.2d	v4, v28, #1
	ushr.2d	v2, v24, #1
	cmhs.4s	v7, v7, v6
	cmhs.4s	v16, v16, v6
LBB0_26:                                ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	add	x10, x12, x9
	ldp	q6, q17, [x10]
	and.16b	v17, v7, v17
	and.16b	v6, v16, v6
	stp	q6, q17, [x10]
	add	x9, x9, #32
	cmp	x9, #3, lsl #12                 ; =12288
	b.ne	LBB0_26
; %bb.27:                               ; %direct.false
	sshll.2d	v6, v0, #0
	mov	x5, #0                          ; =0x0
	sshll.2d	v17, v1, #0
Lloh4:
	adrp	x9, lCPI0_6@PAGE
Lloh5:
	ldr	q18, [x9, lCPI0_6@PAGEOFF]
	ldr	q28, [sp, #3696]                ; 16-byte Reload
	add.2d	v18, v28, v18
	str	q18, [sp, #3504]                ; 16-byte Spill
Lloh6:
	adrp	x9, lCPI0_7@PAGE
Lloh7:
	ldr	q18, [x9, lCPI0_7@PAGEOFF]
	add.2d	v18, v28, v18
	str	q18, [sp, #3488]                ; 16-byte Spill
Lloh8:
	adrp	x9, lCPI0_8@PAGE
Lloh9:
	ldr	q18, [x9, lCPI0_8@PAGEOFF]
	add.2d	v18, v28, v18
	str	q18, [sp, #3472]                ; 16-byte Spill
Lloh10:
	adrp	x9, lCPI0_9@PAGE
Lloh11:
	ldr	q18, [x9, lCPI0_9@PAGEOFF]
	add.2d	v18, v28, v18
	str	q18, [sp, #3456]                ; 16-byte Spill
Lloh12:
	adrp	x9, lCPI0_10@PAGE
Lloh13:
	ldr	q18, [x9, lCPI0_10@PAGEOFF]
	add.2d	v18, v28, v18
	str	q18, [sp, #3440]                ; 16-byte Spill
Lloh14:
	adrp	x9, lCPI0_11@PAGE
Lloh15:
	ldr	q18, [x9, lCPI0_11@PAGEOFF]
	add.2d	v18, v28, v18
	str	q18, [sp, #3424]                ; 16-byte Spill
Lloh16:
	adrp	x9, lCPI0_12@PAGE
Lloh17:
	ldr	q18, [x9, lCPI0_12@PAGEOFF]
	add.2d	v18, v28, v18
	str	q18, [sp, #3408]                ; 16-byte Spill
Lloh18:
	adrp	x9, lCPI0_13@PAGE
Lloh19:
	ldr	q18, [x9, lCPI0_13@PAGEOFF]
	add.2d	v18, v28, v18
	str	q18, [sp, #3392]                ; 16-byte Spill
Lloh20:
	adrp	x9, lCPI0_14@PAGE
Lloh21:
	ldr	q18, [x9, lCPI0_14@PAGEOFF]
	add.2d	v18, v28, v18
	str	q18, [sp, #3376]                ; 16-byte Spill
Lloh22:
	adrp	x9, lCPI0_15@PAGE
Lloh23:
	ldr	q18, [x9, lCPI0_15@PAGEOFF]
	add.2d	v18, v28, v18
	str	q18, [sp, #3360]                ; 16-byte Spill
Lloh24:
	adrp	x9, lCPI0_16@PAGE
Lloh25:
	ldr	q18, [x9, lCPI0_16@PAGEOFF]
	add.2d	v18, v28, v18
	str	q18, [sp, #3344]                ; 16-byte Spill
Lloh26:
	adrp	x9, lCPI0_17@PAGE
Lloh27:
	ldr	q18, [x9, lCPI0_17@PAGEOFF]
	add.2d	v18, v28, v18
	str	q18, [sp, #3328]                ; 16-byte Spill
Lloh28:
	adrp	x9, lCPI0_18@PAGE
Lloh29:
	ldr	q18, [x9, lCPI0_18@PAGEOFF]
	add.2d	v18, v28, v18
	str	q18, [sp, #3312]                ; 16-byte Spill
Lloh30:
	adrp	x9, lCPI0_19@PAGE
Lloh31:
	ldr	q18, [x9, lCPI0_19@PAGEOFF]
	add.2d	v18, v28, v18
	str	q18, [sp, #3296]                ; 16-byte Spill
Lloh32:
	adrp	x9, lCPI0_20@PAGE
Lloh33:
	ldr	q18, [x9, lCPI0_20@PAGEOFF]
	add.2d	v18, v28, v18
	str	q18, [sp, #3280]                ; 16-byte Spill
Lloh34:
	adrp	x9, lCPI0_21@PAGE
Lloh35:
	ldr	q18, [x9, lCPI0_21@PAGEOFF]
	add.2d	v18, v28, v18
	str	q18, [sp, #3264]                ; 16-byte Spill
Lloh36:
	adrp	x9, lCPI0_22@PAGE
Lloh37:
	ldr	q18, [x9, lCPI0_22@PAGEOFF]
	add.2d	v18, v28, v18
	str	q18, [sp, #3248]                ; 16-byte Spill
Lloh38:
	adrp	x9, lCPI0_23@PAGE
Lloh39:
	ldr	q18, [x9, lCPI0_23@PAGEOFF]
	add.2d	v18, v28, v18
	str	q18, [sp, #3232]                ; 16-byte Spill
Lloh40:
	adrp	x9, lCPI0_24@PAGE
Lloh41:
	ldr	q18, [x9, lCPI0_24@PAGEOFF]
	add.2d	v18, v28, v18
	str	q18, [sp, #3216]                ; 16-byte Spill
Lloh42:
	adrp	x9, lCPI0_25@PAGE
Lloh43:
	ldr	q18, [x9, lCPI0_25@PAGEOFF]
	add.2d	v18, v28, v18
	str	q18, [sp, #3200]                ; 16-byte Spill
Lloh44:
	adrp	x9, lCPI0_26@PAGE
Lloh45:
	ldr	q18, [x9, lCPI0_26@PAGEOFF]
	add.2d	v18, v28, v18
	str	q18, [sp, #3184]                ; 16-byte Spill
Lloh46:
	adrp	x9, lCPI0_27@PAGE
Lloh47:
	ldr	q18, [x9, lCPI0_27@PAGEOFF]
	add.2d	v18, v28, v18
	str	q18, [sp, #3168]                ; 16-byte Spill
Lloh48:
	adrp	x9, lCPI0_28@PAGE
Lloh49:
	ldr	q18, [x9, lCPI0_28@PAGEOFF]
	add.2d	v18, v28, v18
	str	q18, [sp, #3152]                ; 16-byte Spill
Lloh50:
	adrp	x9, lCPI0_29@PAGE
Lloh51:
	ldr	q18, [x9, lCPI0_29@PAGEOFF]
	add.2d	v18, v28, v18
	str	q18, [sp, #3136]                ; 16-byte Spill
	uzp1.8h	v7, v16, v7
Lloh52:
	adrp	x9, lCPI0_30@PAGE
Lloh53:
	ldr	q16, [x9, lCPI0_30@PAGEOFF]
	add.2d	v16, v28, v16
	str	q16, [sp, #3120]                ; 16-byte Spill
	mov.d	x9, v5[1]
	fmov	x10, d5
Lloh54:
	adrp	x11, lCPI0_31@PAGE
Lloh55:
	ldr	q5, [x11, lCPI0_31@PAGEOFF]
	add.2d	v5, v28, v5
	str	q5, [sp, #3104]                 ; 16-byte Spill
	mov.d	x11, v4[1]
	fmov	x13, d4
Lloh56:
	adrp	x14, lCPI0_32@PAGE
Lloh57:
	ldr	q4, [x14, lCPI0_32@PAGEOFF]
	add.2d	v4, v28, v4
	str	q4, [sp, #3088]                 ; 16-byte Spill
	mov.d	x16, v3[1]
	fmov	x17, d3
Lloh58:
	adrp	x14, lCPI0_33@PAGE
Lloh59:
	ldr	q3, [x14, lCPI0_33@PAGEOFF]
	add.2d	v3, v28, v3
	str	q3, [sp, #3072]                 ; 16-byte Spill
	fmov	x14, d2
	add	x14, x14, x14, lsl #7
	mov.d	x15, v2[1]
	fmov	d2, x14
	add	x14, x15, x15, lsl #7
	mov.d	v2[1], x14
	add	x13, x13, x13, lsl #7
	and.16b	v2, v17, v2
	str	q2, [sp, #3056]                 ; 16-byte Spill
	fmov	d2, x13
	add	x11, x11, x11, lsl #7
	mov.d	v2[1], x11
	and.16b	v6, v6, v2
Lloh60:
	adrp	x11, lCPI0_34@PAGE
Lloh61:
	ldr	q2, [x11, lCPI0_34@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #3024]                 ; 16-byte Spill
Lloh62:
	adrp	x11, lCPI0_35@PAGE
Lloh63:
	ldr	q2, [x11, lCPI0_35@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #3008]                 ; 16-byte Spill
Lloh64:
	adrp	x11, lCPI0_36@PAGE
Lloh65:
	ldr	q2, [x11, lCPI0_36@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #2992]                 ; 16-byte Spill
Lloh66:
	adrp	x11, lCPI0_37@PAGE
Lloh67:
	ldr	q2, [x11, lCPI0_37@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #2976]                 ; 16-byte Spill
Lloh68:
	adrp	x11, lCPI0_38@PAGE
Lloh69:
	ldr	q2, [x11, lCPI0_38@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #2960]                 ; 16-byte Spill
Lloh70:
	adrp	x11, lCPI0_39@PAGE
Lloh71:
	ldr	q2, [x11, lCPI0_39@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #2944]                 ; 16-byte Spill
Lloh72:
	adrp	x11, lCPI0_40@PAGE
Lloh73:
	ldr	q2, [x11, lCPI0_40@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #2928]                 ; 16-byte Spill
Lloh74:
	adrp	x11, lCPI0_41@PAGE
Lloh75:
	ldr	q2, [x11, lCPI0_41@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #2912]                 ; 16-byte Spill
Lloh76:
	adrp	x11, lCPI0_42@PAGE
Lloh77:
	ldr	q2, [x11, lCPI0_42@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #2896]                 ; 16-byte Spill
	add	x14, x10, x10, lsl #7
	add	x15, x9, x9, lsl #7
Lloh78:
	adrp	x9, lCPI0_43@PAGE
Lloh79:
	ldr	q2, [x9, lCPI0_43@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #2880]                 ; 16-byte Spill
	add	x9, x17, x17, lsl #7
Lloh80:
	adrp	x10, lCPI0_44@PAGE
Lloh81:
	ldr	q2, [x10, lCPI0_44@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #2864]                 ; 16-byte Spill
Lloh82:
	adrp	x10, lCPI0_45@PAGE
Lloh83:
	ldr	q2, [x10, lCPI0_45@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #2848]                 ; 16-byte Spill
	add	x16, x16, x16, lsl #7
	mov	w10, #32800                     ; =0x8020
Lloh84:
	adrp	x11, lCPI0_46@PAGE
Lloh85:
	ldr	q2, [x11, lCPI0_46@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #2832]                 ; 16-byte Spill
	add	x25, x8, x10
	add	x10, x8, #19, lsl #12           ; =77824
	add	x10, x10, #3200
	str	x10, [sp, #2824]                ; 8-byte Spill
Lloh86:
	adrp	x10, lCPI0_47@PAGE
Lloh87:
	ldr	q2, [x10, lCPI0_47@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #2800]                 ; 16-byte Spill
	add	x10, x8, #19, lsl #12           ; =77824
	add	x10, x10, #3712
	str	x10, [sp, #2792]                ; 8-byte Spill
	add	x10, x8, #20, lsl #12           ; =81920
Lloh88:
	adrp	x11, lCPI0_48@PAGE
Lloh89:
	ldr	q2, [x11, lCPI0_48@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #2768]                 ; 16-byte Spill
	add	x10, x10, #128
	str	x10, [sp, #2760]                ; 8-byte Spill
	add	x10, x8, #20, lsl #12           ; =81920
	add	x10, x10, #640
	str	x10, [sp, #2752]                ; 8-byte Spill
Lloh90:
	adrp	x10, lCPI0_49@PAGE
Lloh91:
	ldr	q2, [x10, lCPI0_49@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #2736]                 ; 16-byte Spill
	add	x10, x8, #20, lsl #12           ; =81920
	add	x10, x10, #1152
	str	x10, [sp, #2728]                ; 8-byte Spill
	add	x11, x8, #20, lsl #12           ; =81920
Lloh92:
	adrp	x13, lCPI0_50@PAGE
Lloh93:
	ldr	q2, [x13, lCPI0_50@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #2704]                 ; 16-byte Spill
	add	x11, x11, #1664
	add	x13, x8, #20, lsl #12           ; =81920
	add	x13, x13, #2176
Lloh94:
	adrp	x17, lCPI0_51@PAGE
Lloh95:
	ldr	q2, [x17, lCPI0_51@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #2688]                 ; 16-byte Spill
	add	x17, x8, #21, lsl #12           ; =86016
	add	x10, x17, #3232
	str	x10, [sp, #2680]                ; 8-byte Spill
	add	x17, x8, #22, lsl #12           ; =90112
Lloh96:
	adrp	x0, lCPI0_52@PAGE
Lloh97:
	ldr	q2, [x0, lCPI0_52@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #2656]                 ; 16-byte Spill
	add	x10, x17, #672
	str	x10, [sp, #2648]                ; 8-byte Spill
	mov	w17, #49184                     ; =0xc020
	add	x10, x8, x17
	str	x10, [sp, #2640]                ; 8-byte Spill
Lloh98:
	adrp	x17, lCPI0_53@PAGE
Lloh99:
	ldr	q2, [x17, lCPI0_53@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #2624]                 ; 16-byte Spill
	add	x17, x8, #19, lsl #12           ; =77824
	add	x10, x17, #128
	str	x10, [sp, #2616]                ; 8-byte Spill
	add	x17, x8, #19, lsl #12           ; =77824
Lloh100:
	adrp	x0, lCPI0_54@PAGE
Lloh101:
	ldr	q2, [x0, lCPI0_54@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #2592]                 ; 16-byte Spill
	add	x10, x17, #192
	str	x10, [sp, #2584]                ; 8-byte Spill
	add	x17, x8, #19, lsl #12           ; =77824
	add	x10, x17, #256
	str	x10, [sp, #2576]                ; 8-byte Spill
Lloh102:
	adrp	x17, lCPI0_55@PAGE
Lloh103:
	ldr	q2, [x17, lCPI0_55@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #2560]                 ; 16-byte Spill
	add	x17, x8, #19, lsl #12           ; =77824
	add	x10, x17, #320
	str	x10, [sp, #2552]                ; 8-byte Spill
	add	x17, x8, #19, lsl #12           ; =77824
Lloh104:
	adrp	x0, lCPI0_56@PAGE
Lloh105:
	ldr	q2, [x0, lCPI0_56@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #2528]                 ; 16-byte Spill
	add	x10, x17, #384
	str	x10, [sp, #2520]                ; 8-byte Spill
	add	x17, x8, #19, lsl #12           ; =77824
	add	x10, x17, #448
	str	x10, [sp, #2512]                ; 8-byte Spill
Lloh106:
	adrp	x17, lCPI0_57@PAGE
Lloh107:
	ldr	q2, [x17, lCPI0_57@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #2496]                 ; 16-byte Spill
	add	x17, x8, #19, lsl #12           ; =77824
	add	x10, x17, #512
	str	x10, [sp, #2488]                ; 8-byte Spill
	add	x17, x8, #19, lsl #12           ; =77824
Lloh108:
	adrp	x0, lCPI0_58@PAGE
Lloh109:
	ldr	q2, [x0, lCPI0_58@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #2464]                 ; 16-byte Spill
	add	x10, x17, #576
	str	x10, [sp, #2456]                ; 8-byte Spill
	add	x17, x8, #19, lsl #12           ; =77824
	add	x10, x17, #640
	str	x10, [sp, #2448]                ; 8-byte Spill
Lloh110:
	adrp	x17, lCPI0_59@PAGE
Lloh111:
	ldr	q2, [x17, lCPI0_59@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #2432]                 ; 16-byte Spill
	add	x17, x8, #19, lsl #12           ; =77824
	add	x10, x17, #704
	str	x10, [sp, #2424]                ; 8-byte Spill
	add	x17, x8, #19, lsl #12           ; =77824
Lloh112:
	adrp	x0, lCPI0_60@PAGE
Lloh113:
	ldr	q2, [x0, lCPI0_60@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #2400]                 ; 16-byte Spill
	add	x10, x17, #768
	str	x10, [sp, #2392]                ; 8-byte Spill
	add	x17, x8, #19, lsl #12           ; =77824
	add	x10, x17, #832
	str	x10, [sp, #2384]                ; 8-byte Spill
Lloh114:
	adrp	x17, lCPI0_61@PAGE
Lloh115:
	ldr	q2, [x17, lCPI0_61@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #2368]                 ; 16-byte Spill
	add	x17, x8, #19, lsl #12           ; =77824
	add	x10, x17, #896
	str	x10, [sp, #2360]                ; 8-byte Spill
	add	x17, x8, #19, lsl #12           ; =77824
Lloh116:
	adrp	x0, lCPI0_62@PAGE
Lloh117:
	ldr	q2, [x0, lCPI0_62@PAGEOFF]
	add.2d	v2, v28, v2
	str	q2, [sp, #2336]                 ; 16-byte Spill
	add	x10, x17, #960
	str	x10, [sp, #2328]                ; 8-byte Spill
	add	x17, x8, #19, lsl #12           ; =77824
	add	x10, x17, #1024
	str	x10, [sp, #2320]                ; 8-byte Spill
	fmov	d2, x14
	mov.d	v2[1], x15
	add	x14, x8, #19, lsl #12           ; =77824
	add	x10, x14, #1088
	str	x10, [sp, #2312]                ; 8-byte Spill
	add	x14, x8, #19, lsl #12           ; =77824
Lloh118:
	adrp	x15, lCPI0_63@PAGE
Lloh119:
	ldr	q3, [x15, lCPI0_63@PAGEOFF]
	add.2d	v3, v28, v3
	str	q3, [sp, #2288]                 ; 16-byte Spill
	add	x10, x14, #1152
	str	x10, [sp, #2280]                ; 8-byte Spill
	add	x14, x8, #19, lsl #12           ; =77824
	add	x10, x14, #1216
	str	x10, [sp, #2272]                ; 8-byte Spill
	fmov	d3, x9
	mov.d	v3[1], x16
	add	x9, x8, #19, lsl #12            ; =77824
	add	x9, x9, #1280
	str	x9, [sp, #2264]                 ; 8-byte Spill
Lloh120:
	adrp	x9, lCPI0_64@PAGE
Lloh121:
	ldr	q4, [x9, lCPI0_64@PAGEOFF]
	add.2d	v4, v28, v4
	str	q4, [sp, #2240]                 ; 16-byte Spill
	add	x9, x8, #19, lsl #12            ; =77824
	add	x9, x9, #1344
	str	x9, [sp, #2232]                 ; 8-byte Spill
	add	x9, x8, #19, lsl #12            ; =77824
	add	x9, x9, #1408
	str	x9, [sp, #2224]                 ; 8-byte Spill
	add	x9, x8, #19, lsl #12            ; =77824
	add	x9, x9, #1472
	str	x9, [sp, #2216]                 ; 8-byte Spill
	add	x9, x8, #19, lsl #12            ; =77824
	add	x9, x9, #1536
	str	x9, [sp, #2208]                 ; 8-byte Spill
Lloh122:
	adrp	x9, lCPI0_65@PAGE
Lloh123:
	ldr	q4, [x9, lCPI0_65@PAGEOFF]
	add.2d	v4, v28, v4
	str	q4, [sp, #2192]                 ; 16-byte Spill
	add	x9, x8, #19, lsl #12            ; =77824
	add	x9, x9, #1600
	str	x9, [sp, #2184]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #2688
	str	x9, [sp, #2176]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #2720
	str	x9, [sp, #2168]                 ; 8-byte Spill
	mov	w9, #65                         ; =0x41
	dup.2d	v4, x9
	orr.16b	v5, v29, v4
	str	q5, [sp, #2144]                 ; 16-byte Spill
	orr.16b	v5, v26, v4
	str	q5, [sp, #2128]                 ; 16-byte Spill
	orr.16b	v5, v27, v4
	str	q5, [sp, #2112]                 ; 16-byte Spill
	orr.16b	v4, v19, v4
	str	q4, [sp, #2096]                 ; 16-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #2752
	str	x9, [sp, #2088]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #2784
	str	x9, [sp, #2080]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #2816
	str	x9, [sp, #2072]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #2848
	str	x9, [sp, #2064]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #2880
	str	x9, [sp, #2056]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #2912
	str	x9, [sp, #2048]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #2944
	str	x9, [sp, #2040]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #2976
	str	x9, [sp, #2032]                 ; 8-byte Spill
	mov	w9, #66                         ; =0x42
	dup.2d	v4, x9
	orr.16b	v5, v29, v4
	str	q5, [sp, #2016]                 ; 16-byte Spill
	orr.16b	v5, v26, v4
	str	q5, [sp, #2000]                 ; 16-byte Spill
	orr.16b	v5, v27, v4
	str	q5, [sp, #1984]                 ; 16-byte Spill
	orr.16b	v4, v19, v4
	str	q4, [sp, #1968]                 ; 16-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3008
	str	x9, [sp, #1960]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3040
	str	x9, [sp, #1952]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3072
	str	x9, [sp, #1944]                 ; 8-byte Spill
	mov	w9, #67                         ; =0x43
	dup.2d	v4, x9
	orr.16b	v5, v29, v4
	str	q5, [sp, #1920]                 ; 16-byte Spill
	orr.16b	v5, v26, v4
	str	q5, [sp, #1904]                 ; 16-byte Spill
	orr.16b	v5, v27, v4
	str	q5, [sp, #1888]                 ; 16-byte Spill
	orr.16b	v4, v19, v4
	str	q4, [sp, #1872]                 ; 16-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3104
	str	x9, [sp, #1864]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3136
	str	x9, [sp, #1856]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3168
	str	x9, [sp, #1848]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3200
	str	x9, [sp, #1840]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3232
	str	x9, [sp, #1832]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3264
	str	x9, [sp, #1824]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3296
	str	x9, [sp, #1816]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3328
	str	x9, [sp, #1808]                 ; 8-byte Spill
	mov	w9, #68                         ; =0x44
	dup.2d	v4, x9
	orr.16b	v5, v29, v4
	str	q5, [sp, #1792]                 ; 16-byte Spill
	orr.16b	v5, v26, v4
	str	q5, [sp, #1776]                 ; 16-byte Spill
	orr.16b	v5, v27, v4
	str	q5, [sp, #1760]                 ; 16-byte Spill
	orr.16b	v4, v19, v4
	str	q4, [sp, #1744]                 ; 16-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3360
	str	x9, [sp, #1736]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3392
	str	x9, [sp, #1728]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3424
	str	x9, [sp, #1720]                 ; 8-byte Spill
	mov	w9, #69                         ; =0x45
	dup.2d	v4, x9
	orr.16b	v5, v29, v4
	str	q5, [sp, #1696]                 ; 16-byte Spill
	orr.16b	v5, v26, v4
	str	q5, [sp, #1680]                 ; 16-byte Spill
	orr.16b	v5, v27, v4
	str	q5, [sp, #1664]                 ; 16-byte Spill
	orr.16b	v4, v19, v4
	str	q4, [sp, #1648]                 ; 16-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3456
	str	x9, [sp, #1640]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3488
	str	x9, [sp, #1632]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3520
	str	x9, [sp, #1624]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3552
	str	x9, [sp, #1616]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3584
	str	x9, [sp, #1608]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3616
	str	x9, [sp, #1600]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3648
	str	x9, [sp, #1592]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3680
	str	x9, [sp, #1584]                 ; 8-byte Spill
	mov	w9, #70                         ; =0x46
	dup.2d	v4, x9
	orr.16b	v5, v29, v4
	str	q5, [sp, #1568]                 ; 16-byte Spill
	orr.16b	v5, v26, v4
	str	q5, [sp, #1552]                 ; 16-byte Spill
	orr.16b	v5, v27, v4
	str	q5, [sp, #1536]                 ; 16-byte Spill
	orr.16b	v4, v19, v4
	str	q4, [sp, #1520]                 ; 16-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3712
	str	x9, [sp, #1512]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3744
	str	x9, [sp, #1504]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3776
	str	x9, [sp, #1496]                 ; 8-byte Spill
	mov	w9, #71                         ; =0x47
	dup.2d	v4, x9
	orr.16b	v5, v29, v4
	str	q5, [sp, #1472]                 ; 16-byte Spill
	orr.16b	v5, v26, v4
	str	q5, [sp, #1456]                 ; 16-byte Spill
	orr.16b	v5, v27, v4
	str	q5, [sp, #1440]                 ; 16-byte Spill
	orr.16b	v4, v19, v4
	str	q4, [sp, #1424]                 ; 16-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3808
	str	x9, [sp, #1416]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3840
	str	x9, [sp, #1408]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3872
	str	x9, [sp, #1400]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3904
	str	x9, [sp, #1392]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3936
	str	x9, [sp, #1384]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #3968
	str	x9, [sp, #1376]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #4000
	str	x9, [sp, #1368]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #4032
	str	x9, [sp, #1360]                 ; 8-byte Spill
	mov	w9, #72                         ; =0x48
	dup.2d	v4, x9
	stp	q29, q27, [sp, #80]             ; 32-byte Folded Spill
	add.2d	v5, v29, v4
	str	q5, [sp, #1344]                 ; 16-byte Spill
	str	q26, [sp, #112]                 ; 16-byte Spill
	add.2d	v5, v26, v4
	str	q5, [sp, #1328]                 ; 16-byte Spill
	add.2d	v5, v27, v4
	str	q5, [sp, #1312]                 ; 16-byte Spill
	str	q19, [sp, #48]                  ; 16-byte Spill
	add.2d	v4, v19, v4
	str	q4, [sp, #1296]                 ; 16-byte Spill
	xtn.8b	v4, v7
	str	d4, [sp, #1288]                 ; 8-byte Spill
	add	x9, x8, #20, lsl #12            ; =81920
	add	x9, x9, #4064
	str	x9, [sp, #1280]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #32
	str	x9, [sp, #1272]                 ; 8-byte Spill
	and.16b	v7, v9, v3
	and.16b	v11, v23, v2
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #64
	str	x9, [sp, #1224]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #96
	str	x9, [sp, #1216]                 ; 8-byte Spill
	mvni.4s	v2, #63, msl #16
	fneg.4s	v2, v2
	str	q2, [sp, #9808]                 ; 16-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #128
	str	x9, [sp, #1208]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #160
	str	x9, [sp, #1200]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #192
	str	x9, [sp, #1192]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #224
	str	x9, [sp, #1184]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #256
	str	x9, [sp, #1176]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #288
	str	x9, [sp, #1168]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #320
	str	x9, [sp, #1160]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #352
	str	x9, [sp, #1152]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #384
	str	x9, [sp, #1144]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #416
	str	x9, [sp, #1136]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #448
	str	x9, [sp, #1128]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #480
	str	x9, [sp, #1120]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #512
	str	x9, [sp, #1112]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #544
	str	x9, [sp, #1104]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #576
	str	x9, [sp, #1096]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #608
	str	x9, [sp, #1088]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #640
	str	x9, [sp, #1080]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #672
	str	x9, [sp, #1072]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #704
	str	x9, [sp, #1064]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #736
	str	x9, [sp, #1056]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #768
	str	x9, [sp, #1048]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #800
	str	x9, [sp, #1040]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #832
	str	x9, [sp, #1032]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #864
	str	x9, [sp, #1024]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #896
	str	x9, [sp, #1016]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #928
	str	x9, [sp, #1008]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #960
	str	x9, [sp, #1000]                 ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #992
	str	x9, [sp, #992]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1024
	str	x9, [sp, #984]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1056
	str	x9, [sp, #976]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1088
	str	x9, [sp, #968]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1120
	str	x9, [sp, #960]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1152
	str	x9, [sp, #952]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1184
	str	x9, [sp, #944]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1216
	str	x9, [sp, #936]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1248
	str	x9, [sp, #928]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1280
	str	x9, [sp, #920]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1312
	str	x9, [sp, #912]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1344
	str	x9, [sp, #904]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1376
	str	x9, [sp, #896]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1408
	str	x9, [sp, #888]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1440
	str	x9, [sp, #880]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1472
	str	x9, [sp, #872]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1504
	str	x9, [sp, #864]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1536
	str	x9, [sp, #856]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1568
	str	x9, [sp, #848]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1600
	str	x9, [sp, #840]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1632
	str	x9, [sp, #832]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1664
	str	x9, [sp, #824]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1696
	str	x9, [sp, #816]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1728
	str	x9, [sp, #808]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1760
	str	x9, [sp, #800]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1792
	str	x9, [sp, #792]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1824
	str	x9, [sp, #784]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1856
	str	x9, [sp, #776]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1888
	str	x9, [sp, #768]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1920
	str	x9, [sp, #760]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1952
	str	x9, [sp, #752]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #1984
	str	x9, [sp, #744]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #2016
	str	x9, [sp, #736]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #2048
	str	x9, [sp, #728]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #2080
	str	x9, [sp, #720]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #2112
	str	x9, [sp, #712]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #2144
	str	x9, [sp, #704]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #2176
	str	x9, [sp, #696]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #2208
	str	x9, [sp, #688]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #2240
	str	x9, [sp, #680]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #2272
	str	x9, [sp, #672]                  ; 8-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #2304
	str	x9, [sp, #664]                  ; 8-byte Spill
	movi.2d	v2, #0000000000000000
	str	q2, [sp, #10064]                ; 16-byte Spill
	str	q2, [sp, #10048]                ; 16-byte Spill
	str	q2, [sp, #10032]                ; 16-byte Spill
	str	q2, [sp, #10016]                ; 16-byte Spill
	str	q2, [sp, #8752]                 ; 16-byte Spill
	str	q2, [sp, #8736]                 ; 16-byte Spill
	str	q2, [sp, #10000]                ; 16-byte Spill
	str	q2, [sp, #9984]                 ; 16-byte Spill
	str	q2, [sp, #9968]                 ; 16-byte Spill
	str	q2, [sp, #9952]                 ; 16-byte Spill
	str	q2, [sp, #8720]                 ; 16-byte Spill
	str	q2, [sp, #8704]                 ; 16-byte Spill
	str	q2, [sp, #8688]                 ; 16-byte Spill
	str	q2, [sp, #9792]                 ; 16-byte Spill
	str	q2, [sp, #9776]                 ; 16-byte Spill
	str	q2, [sp, #9760]                 ; 16-byte Spill
	str	q2, [sp, #8608]                 ; 16-byte Spill
	movi.2d	v25, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v24, #0000000000000000
	str	q2, [sp, #8576]                 ; 16-byte Spill
	str	q2, [sp, #8672]                 ; 16-byte Spill
	str	q2, [sp, #8656]                 ; 16-byte Spill
	str	q2, [sp, #8640]                 ; 16-byte Spill
	str	q2, [sp, #8624]                 ; 16-byte Spill
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
	str	q2, [sp, #9440]                 ; 16-byte Spill
	str	q2, [sp, #9424]                 ; 16-byte Spill
	str	q2, [sp, #9408]                 ; 16-byte Spill
	str	q2, [sp, #9392]                 ; 16-byte Spill
	str	q2, [sp, #9376]                 ; 16-byte Spill
	str	q2, [sp, #9360]                 ; 16-byte Spill
	str	q2, [sp, #9344]                 ; 16-byte Spill
	str	q2, [sp, #9328]                 ; 16-byte Spill
	str	q2, [sp, #9312]                 ; 16-byte Spill
	str	q2, [sp, #9296]                 ; 16-byte Spill
	str	q2, [sp, #9280]                 ; 16-byte Spill
	str	q2, [sp, #9264]                 ; 16-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	movi.2d	v13, #0000000000000000
	movi.2d	v14, #0000000000000000
	movi.2d	v15, #0000000000000000
	str	q2, [sp, #8592]                 ; 16-byte Spill
	str	q2, [sp, #640]                  ; 16-byte Spill
	add	x9, x9, #2336
	str	x9, [sp, #632]                  ; 8-byte Spill
	stp	q2, q2, [sp, #592]              ; 32-byte Folded Spill
	str	q2, [sp, #576]                  ; 16-byte Spill
	str	q2, [sp, #9744]                 ; 16-byte Spill
	str	q2, [sp, #9728]                 ; 16-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #2368
	str	x9, [sp, #568]                  ; 8-byte Spill
	str	q2, [sp, #9712]                 ; 16-byte Spill
	str	q2, [sp, #9696]                 ; 16-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #2400
	str	x9, [sp, #560]                  ; 8-byte Spill
Lloh124:
	adrp	x9, lCPI0_73@PAGE
Lloh125:
	adrp	x14, lCPI0_74@PAGE
Lloh126:
	adrp	x15, lCPI0_72@PAGE
Lloh127:
	ldr	q2, [x15, lCPI0_72@PAGEOFF]
	str	q2, [sp, #544]                  ; 16-byte Spill
Lloh128:
	ldr	q2, [x9, lCPI0_73@PAGEOFF]
	str	q2, [sp, #528]                  ; 16-byte Spill
Lloh129:
	ldr	q2, [x14, lCPI0_74@PAGEOFF]
	str	q2, [sp, #512]                  ; 16-byte Spill
Lloh130:
	adrp	x9, lCPI0_67@PAGE
Lloh131:
	adrp	x14, lCPI0_68@PAGE
Lloh132:
	adrp	x15, lCPI0_71@PAGE
Lloh133:
	adrp	x16, lCPI0_70@PAGE
Lloh134:
	ldr	q2, [x16, lCPI0_70@PAGEOFF]
	str	q2, [sp, #496]                  ; 16-byte Spill
Lloh135:
	ldr	q2, [x15, lCPI0_71@PAGEOFF]
	str	q2, [sp, #480]                  ; 16-byte Spill
Lloh136:
	adrp	x15, lCPI0_69@PAGE
Lloh137:
	adrp	x16, lCPI0_66@PAGE
Lloh138:
	ldr	q2, [x16, lCPI0_66@PAGEOFF]
	str	q2, [sp, #8560]                 ; 16-byte Spill
Lloh139:
	ldr	q2, [x9, lCPI0_67@PAGEOFF]
	str	q2, [sp, #8544]                 ; 16-byte Spill
Lloh140:
	ldr	q2, [x14, lCPI0_68@PAGEOFF]
	str	q2, [sp, #8528]                 ; 16-byte Spill
Lloh141:
	ldr	q2, [x15, lCPI0_69@PAGEOFF]
	str	q2, [sp, #8512]                 ; 16-byte Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x10, x9, #2432
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #2464
	stp	x9, x10, [sp, #464]             ; 16-byte Folded Spill
	add	x9, x8, #21, lsl #12            ; =86016
	movi.2d	v8, #0000000000000000
	add	x10, x9, #2496
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #2528
	stp	x9, x10, [sp, #448]             ; 16-byte Folded Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x10, x9, #2560
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #2592
	stp	x9, x10, [sp, #432]             ; 16-byte Folded Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x10, x9, #2624
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #2656
	stp	x9, x10, [sp, #416]             ; 16-byte Folded Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x10, x9, #2688
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #2720
	stp	x9, x10, [sp, #400]             ; 16-byte Folded Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x10, x9, #2752
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #2784
	stp	x9, x10, [sp, #384]             ; 16-byte Folded Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x10, x9, #2816
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #2848
	stp	x9, x10, [sp, #368]             ; 16-byte Folded Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x10, x9, #2880
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #2912
	stp	x9, x10, [sp, #352]             ; 16-byte Folded Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x10, x9, #2944
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #2976
	stp	x9, x10, [sp, #336]             ; 16-byte Folded Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x10, x9, #3008
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #3040
	stp	x9, x10, [sp, #320]             ; 16-byte Folded Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x10, x9, #3072
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #3104
	stp	x9, x10, [sp, #304]             ; 16-byte Folded Spill
	add	x9, x8, #21, lsl #12            ; =86016
	add	x10, x9, #3136
	add	x9, x8, #21, lsl #12            ; =86016
	add	x9, x9, #3168
	stp	x9, x10, [sp, #288]             ; 16-byte Folded Spill
	mov	w9, #62154                      ; =0xf2ca
	movk	w9, #61769, lsl #16
Lloh142:
	adrp	x15, lCPI0_2@PAGE
Lloh143:
	adrp	x16, lCPI0_3@PAGE
Lloh144:
	adrp	x0, lCPI0_4@PAGE
Lloh145:
	adrp	x1, lCPI0_5@PAGE
	mov	w14, #48                        ; =0x30
	mov	x23, #-6148914691236517206      ; =0xaaaaaaaaaaaaaaaa
	movk	x23, #43691
	mov	x17, #-1536                     ; =0xfffffffffffffa00
	dup.4s	v2, w9
Lloh146:
	ldr	q3, [x15, lCPI0_2@PAGEOFF]
Lloh147:
	ldr	q4, [x16, lCPI0_3@PAGEOFF]
Lloh148:
	ldr	q5, [x0, lCPI0_4@PAGEOFF]
Lloh149:
	ldr	q16, [x1, lCPI0_5@PAGEOFF]
	and.16b	v17, v0, v2
	str	q2, [sp, #9680]                 ; 16-byte Spill
	and.16b	v2, v1, v2
	stp	q4, q3, [sp, #256]              ; 32-byte Folded Spill
	add.2d	v3, v28, v3
	stp	q3, q16, [sp, #208]             ; 32-byte Folded Spill
	add.2d	v3, v28, v4
	str	q3, [sp, #192]                  ; 16-byte Spill
	str	q5, [sp, #240]                  ; 16-byte Spill
	add.2d	v4, v28, v5
	add.2d	v3, v28, v16
	stp	q3, q4, [sp, #160]              ; 32-byte Folded Spill
	movi.2d	v3, #0000000000000000
	str	q3, [sp, #9936]                 ; 16-byte Spill
	str	q3, [sp, #9920]                 ; 16-byte Spill
	str	q3, [sp, #9904]                 ; 16-byte Spill
	str	q3, [sp, #9888]                 ; 16-byte Spill
	str	q3, [sp, #9872]                 ; 16-byte Spill
	str	q3, [sp, #9856]                 ; 16-byte Spill
	str	q3, [sp, #9840]                 ; 16-byte Spill
	str	q3, [sp, #9824]                 ; 16-byte Spill
	str	q3, [sp, #8496]                 ; 16-byte Spill
	str	q3, [sp, #8480]                 ; 16-byte Spill
	str	q3, [sp, #8464]                 ; 16-byte Spill
	str	q3, [sp, #8448]                 ; 16-byte Spill
	str	q3, [sp, #8432]                 ; 16-byte Spill
	str	q3, [sp, #8416]                 ; 16-byte Spill
	str	q3, [sp, #8400]                 ; 16-byte Spill
	str	q3, [sp, #8384]                 ; 16-byte Spill
	str	q3, [sp, #8368]                 ; 16-byte Spill
	str	q3, [sp, #8352]                 ; 16-byte Spill
	str	q3, [sp, #8336]                 ; 16-byte Spill
	str	q3, [sp, #8320]                 ; 16-byte Spill
	str	q3, [sp, #8304]                 ; 16-byte Spill
	str	q3, [sp, #8288]                 ; 16-byte Spill
	str	q3, [sp, #8816]                 ; 16-byte Spill
	str	q3, [sp, #8800]                 ; 16-byte Spill
	str	q3, [sp, #8272]                 ; 16-byte Spill
	str	q3, [sp, #8256]                 ; 16-byte Spill
	str	q3, [sp, #8240]                 ; 16-byte Spill
	str	q3, [sp, #8224]                 ; 16-byte Spill
	str	q3, [sp, #8208]                 ; 16-byte Spill
	str	q3, [sp, #8192]                 ; 16-byte Spill
	str	q3, [sp, #8176]                 ; 16-byte Spill
	str	q3, [sp, #8160]                 ; 16-byte Spill
	str	q3, [sp, #8144]                 ; 16-byte Spill
	str	q3, [sp, #8128]                 ; 16-byte Spill
	str	q2, [sp, #9632]                 ; 16-byte Spill
	str	q17, [sp, #9616]                ; 16-byte Spill
	str	q3, [sp, #8112]                 ; 16-byte Spill
	str	q3, [sp, #8096]                 ; 16-byte Spill
	str	q2, [sp, #9600]                 ; 16-byte Spill
	str	q17, [sp, #9584]                ; 16-byte Spill
	str	q2, [sp, #9568]                 ; 16-byte Spill
	str	q17, [sp, #9552]                ; 16-byte Spill
	str	q3, [sp, #8080]                 ; 16-byte Spill
	str	q3, [sp, #8064]                 ; 16-byte Spill
	str	q3, [sp, #8048]                 ; 16-byte Spill
	str	q2, [sp, #9536]                 ; 16-byte Spill
	str	q17, [sp, #9520]                ; 16-byte Spill
	str	q2, [sp, #9504]                 ; 16-byte Spill
	str	q17, [sp, #9488]                ; 16-byte Spill
	str	q3, [sp, #8032]                 ; 16-byte Spill
	str	q2, [sp, #9472]                 ; 16-byte Spill
	str	q17, [sp, #9456]                ; 16-byte Spill
	str	q2, [sp, #9648]                 ; 16-byte Spill
	str	q2, [sp, #9248]                 ; 16-byte Spill
	str	q17, [sp, #9664]                ; 16-byte Spill
	str	q17, [sp, #9232]                ; 16-byte Spill
	str	q9, [sp, #8784]                 ; 16-byte Spill
	str	q23, [sp, #8768]                ; 16-byte Spill
	mov.16b	v21, v31
	str	q31, [sp, #3584]                ; 16-byte Spill
	str	x2, [sp, #3528]                 ; 8-byte Spill
	str	x4, [sp, #3520]                 ; 8-byte Spill
	str	q6, [sp, #3040]                 ; 16-byte Spill
	str	q11, [sp, #1232]                ; 16-byte Spill
	mov.16b	v20, v9
	str	x28, [sp, #3640]                ; 8-byte Spill
	str	x30, [sp, #3576]                ; 8-byte Spill
	str	q7, [sp, #1248]                 ; 16-byte Spill
LBB0_28:                                ; %direct.true210
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_35 Depth 2
                                        ;     Child Loop BB0_38 Depth 2
                                        ;     Child Loop BB0_41 Depth 2
                                        ;     Child Loop BB0_44 Depth 2
                                        ;     Child Loop BB0_47 Depth 2
                                        ;     Child Loop BB0_50 Depth 2
                                        ;     Child Loop BB0_53 Depth 2
                                        ;     Child Loop BB0_56 Depth 2
                                        ;     Child Loop BB0_59 Depth 2
                                        ;     Child Loop BB0_62 Depth 2
                                        ;     Child Loop BB0_65 Depth 2
                                        ;     Child Loop BB0_68 Depth 2
                                        ;     Child Loop BB0_71 Depth 2
                                        ;     Child Loop BB0_74 Depth 2
                                        ;     Child Loop BB0_77 Depth 2
                                        ;     Child Loop BB0_80 Depth 2
                                        ;     Child Loop BB0_31 Depth 2
                                        ;     Child Loop BB0_84 Depth 2
                                        ;     Child Loop BB0_88 Depth 2
                                        ;       Child Loop BB0_89 Depth 3
                                        ;     Child Loop BB0_349 Depth 2
                                        ;     Child Loop BB0_383 Depth 2
                                        ;     Child Loop BB0_400 Depth 2
                                        ;     Child Loop BB0_402 Depth 2
                                        ;     Child Loop BB0_404 Depth 2
                                        ;     Child Loop BB0_406 Depth 2
                                        ;     Child Loop BB0_408 Depth 2
                                        ;     Child Loop BB0_410 Depth 2
                                        ;     Child Loop BB0_412 Depth 2
                                        ;     Child Loop BB0_414 Depth 2
                                        ;     Child Loop BB0_417 Depth 2
                                        ;     Child Loop BB0_434 Depth 2
                                        ;       Child Loop BB0_435 Depth 3
                                        ;     Child Loop BB0_438 Depth 2
                                        ;     Child Loop BB0_440 Depth 2
	sshll.2d	v2, v1, #0
	sshll.2d	v3, v0, #0
	lsl	x9, x5, #4
	ldr	q4, [sp, #3600]                 ; 16-byte Reload
	ldr	q31, [sp, #8320]                ; 16-byte Reload
	bit.16b	v31, v4, v23
	ldr	q27, [sp, #8352]                ; 16-byte Reload
	bit.16b	v27, v4, v20
	ldr	q28, [sp, #8336]                ; 16-byte Reload
	bit.16b	v28, v4, v3
	ldr	q5, [sp, #8368]                 ; 16-byte Reload
	bit.16b	v5, v4, v2
	ldr	q4, [sp, #8560]                 ; 16-byte Reload
	ldr	q16, [sp, #8800]                ; 16-byte Reload
	bit.16b	v16, v4, v23
	str	q16, [sp, #8800]                ; 16-byte Spill
	ldr	q4, [sp, #8544]                 ; 16-byte Reload
	ldr	q12, [sp, #8288]                ; 16-byte Reload
	bit.16b	v12, v4, v20
	ldr	q4, [sp, #8528]                 ; 16-byte Reload
	ldr	q16, [sp, #8816]                ; 16-byte Reload
	bit.16b	v16, v4, v3
	str	q16, [sp, #8816]                ; 16-byte Spill
	ldr	q3, [sp, #8512]                 ; 16-byte Reload
	ldr	q17, [sp, #8304]                ; 16-byte Reload
	bit.16b	v17, v3, v2
	dup.2d	v10, x9
	cmp	x5, #8
	str	x5, [sp, #8024]                 ; 8-byte Spill
	str	q5, [sp, #8368]                 ; 16-byte Spill
	str	q27, [sp, #8352]                ; 16-byte Spill
	str	q28, [sp, #8336]                ; 16-byte Spill
	str	q31, [sp, #8320]                ; 16-byte Spill
	str	q17, [sp, #8304]                ; 16-byte Spill
	str	q12, [sp, #8288]                ; 16-byte Spill
	str	q10, [sp, #9216]                ; 16-byte Spill
	b.ne	LBB0_33
; %bb.29:                               ; %direct.true1895.preheader
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x15, #0                         ; =0x0
	add	x1, x8, #8, lsl #12             ; =32768
	ldr	q17, [sp, #8592]                ; 16-byte Reload
	ldr	q28, [sp, #640]                 ; 16-byte Reload
	ldp	q31, q19, [sp, #592]            ; 32-byte Folded Reload
	ldr	q12, [sp, #576]                 ; 16-byte Reload
	ldr	q10, [sp, #3056]                ; 16-byte Reload
	b	LBB0_31
LBB0_30:                                ; %direct.schedule.94
                                        ;   in Loop: Header=BB0_31 Depth=2
	sshll.2d	v16, v0, #0
	add.2d	v18, v4, v7
	add.2d	v27, v4, v6
	add.2d	v4, v4, v11
	shl.2d	v4, v4, #5
	shl.2d	v27, v27, #5
	shl.2d	v18, v18, #5
	orr.16b	v18, v18, v3
	orr.16b	v27, v27, v3
	orr.16b	v3, v4, v3
	ldr	q4, [sp, #9744]                 ; 16-byte Reload
	bit.16b	v4, v3, v23
	str	q4, [sp, #9744]                 ; 16-byte Spill
	bit.16b	v12, v27, v16
	bit.16b	v31, v18, v20
	ldr	q3, [sp, #9696]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #9696]                 ; 16-byte Spill
	ldr	q3, [sp, #9712]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #9712]                 ; 16-byte Spill
	add	x16, x1, x15, lsl #5
	ldp	q3, q4, [x16]
	bit.16b	v4, v2, v0
	bif.16b	v2, v3, v1
	stp	q2, q4, [x16]
	add	x15, x15, #1
	cmp	x15, #512
	b.eq	LBB0_82
LBB0_31:                                ; %direct.true1895
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v2, v1, #0
	and	x10, x15, #0x1f
	lsr	x16, x15, #5
	orr	x0, x16, #0x80
	dup.2d	v4, x0
	add.2d	v3, v4, v10
	shl.2d	v5, v3, #5
	dup.2d	v3, x10
	orr.16b	v5, v5, v3
	bit.16b	v19, v5, v2
	movi.2d	v2, #0000000000000000
	cbnz	x16, LBB0_30
; %bb.32:                               ; %direct.true1908
                                        ;   in Loop: Header=BB0_31 Depth=2
	fmov	x10, d19
	add	x10, x2, x10, lsl #2
	ld1r.4s	{ v2 }, [x10]
	b	LBB0_30
LBB0_33:                                ; %direct.true213
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q2, [sp, #3056]                 ; 16-byte Reload
	add.2d	v16, v10, v2
	shl.2d	v2, v16, #5
	ldr	w10, [sp, #3676]                ; 4-byte Reload
	tbz	w10, #0, LBB0_36
; %bb.34:                               ; %copy.active222
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x15, #0                         ; =0x0
	fmov	x0, d5
	fmov	x1, d17
	fmov	x16, d2
	add	x16, x2, x16, lsl #2
	add	x0, x0, x1
	add	x0, x0, #64
LBB0_35:                                ; %copy.chunk.i921
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x16, x15]
	stur	s3, [x0, #-64]
	mov	s4, v3[1]
	stur	s4, [x0, #-32]
	st1.s	{ v3 }[2], [x0]
	add	x1, x0, #32
	st1.s	{ v3 }[3], [x1]
	add	x15, x15, #16
	add	x0, x0, #128
	cmp	x15, #2048
	b.ne	LBB0_35
LBB0_36:                                ; %copy.continue223
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	w10, [sp, #3672]                ; 4-byte Reload
	cbz	w10, LBB0_39
; %bb.37:                               ; %copy.active224
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x15, #0                         ; =0x0
	mov.d	x0, v5[1]
	mov.d	x1, v17[1]
	mov.d	x16, v2[1]
	add	x16, x2, x16, lsl #2
	add	x0, x0, x1
	add	x0, x0, #64
LBB0_38:                                ; %copy.chunk.i926
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x16, x15]
	stur	s2, [x0, #-64]
	mov	s3, v2[1]
	stur	s3, [x0, #-32]
	st1.s	{ v2 }[2], [x0]
	add	x1, x0, #32
	st1.s	{ v2 }[3], [x1]
	add	x15, x15, #16
	add	x0, x0, #128
	cmp	x15, #2048
	b.ne	LBB0_38
LBB0_39:                                ; %copy.continue225
                                        ;   in Loop: Header=BB0_28 Depth=1
	add.2d	v4, v10, v7
	shl.2d	v2, v4, #5
	ldr	w10, [sp, #3668]                ; 4-byte Reload
	ldr	q19, [sp, #10064]               ; 16-byte Reload
	ldr	q17, [sp, #8592]                ; 16-byte Reload
	cbz	w10, LBB0_42
; %bb.40:                               ; %copy.active226
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x15, #0                         ; =0x0
	fmov	x0, d27
	fmov	x1, d12
	fmov	x16, d2
	add	x16, x2, x16, lsl #2
	add	x0, x0, x1
	add	x0, x0, #64
LBB0_41:                                ; %copy.chunk.i932
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x16, x15]
	stur	s3, [x0, #-64]
	mov	s18, v3[1]
	stur	s18, [x0, #-32]
	st1.s	{ v3 }[2], [x0]
	add	x1, x0, #32
	st1.s	{ v3 }[3], [x1]
	add	x15, x15, #16
	add	x0, x0, #128
	cmp	x15, #2048
	b.ne	LBB0_41
LBB0_42:                                ; %copy.continue227
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	w10, [sp, #3664]                ; 4-byte Reload
	cbz	w10, LBB0_45
; %bb.43:                               ; %copy.active228
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x15, #0                         ; =0x0
	mov.d	x0, v27[1]
	mov.d	x1, v12[1]
	mov.d	x16, v2[1]
	add	x16, x2, x16, lsl #2
	add	x0, x0, x1
	add	x0, x0, #64
LBB0_44:                                ; %copy.chunk.i938
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x16, x15]
	stur	s2, [x0, #-64]
	mov	s3, v2[1]
	stur	s3, [x0, #-32]
	st1.s	{ v2 }[2], [x0]
	add	x1, x0, #32
	st1.s	{ v2 }[3], [x1]
	add	x15, x15, #16
	add	x0, x0, #128
	cmp	x15, #2048
	b.ne	LBB0_44
LBB0_45:                                ; %copy.continue229
                                        ;   in Loop: Header=BB0_28 Depth=1
	add.2d	v3, v10, v6
	shl.2d	v2, v3, #5
	ldr	w10, [sp, #3660]                ; 4-byte Reload
	cbz	w10, LBB0_48
; %bb.46:                               ; %copy.active230
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x15, #0                         ; =0x0
	fmov	x0, d28
	ldr	q6, [sp, #8816]                 ; 16-byte Reload
	fmov	x1, d6
	fmov	x16, d2
	add	x16, x2, x16, lsl #2
	add	x0, x0, x1
	add	x0, x0, #64
LBB0_47:                                ; %copy.chunk.i944
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q18, [x16, x15]
	stur	s18, [x0, #-64]
	mov	s27, v18[1]
	stur	s27, [x0, #-32]
	st1.s	{ v18 }[2], [x0]
	add	x1, x0, #32
	st1.s	{ v18 }[3], [x1]
	add	x15, x15, #16
	add	x0, x0, #128
	cmp	x15, #2048
	b.ne	LBB0_47
LBB0_48:                                ; %copy.continue231
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	w10, [sp, #3656]                ; 4-byte Reload
	ldr	q6, [sp, #8496]                 ; 16-byte Reload
	cbz	w10, LBB0_51
; %bb.49:                               ; %copy.active232
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x15, #0                         ; =0x0
	mov.d	x0, v28[1]
	ldr	q18, [sp, #8816]                ; 16-byte Reload
	mov.d	x1, v18[1]
	mov.d	x16, v2[1]
	add	x16, x2, x16, lsl #2
	add	x0, x0, x1
	add	x0, x0, #64
LBB0_50:                                ; %copy.chunk.i950
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x16, x15]
	stur	s2, [x0, #-64]
	mov	s18, v2[1]
	stur	s18, [x0, #-32]
	st1.s	{ v2 }[2], [x0]
	add	x1, x0, #32
	st1.s	{ v2 }[3], [x1]
	add	x15, x15, #16
	add	x0, x0, #128
	cmp	x15, #2048
	b.ne	LBB0_50
LBB0_51:                                ; %copy.continue233
                                        ;   in Loop: Header=BB0_28 Depth=1
	add.2d	v2, v10, v11
	shl.2d	v18, v2, #5
	ldr	w10, [sp, #3652]                ; 4-byte Reload
	cbz	w10, LBB0_54
; %bb.52:                               ; %copy.active234
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x15, #0                         ; =0x0
	fmov	x0, d31
	ldr	q27, [sp, #8800]                ; 16-byte Reload
	fmov	x1, d27
	fmov	x16, d18
	add	x16, x2, x16, lsl #2
	add	x0, x0, x1
	add	x0, x0, #64
LBB0_53:                                ; %copy.chunk.i956
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q27, [x16, x15]
	stur	s27, [x0, #-64]
	mov	s28, v27[1]
	stur	s28, [x0, #-32]
	st1.s	{ v27 }[2], [x0]
	add	x1, x0, #32
	st1.s	{ v27 }[3], [x1]
	add	x15, x15, #16
	add	x0, x0, #128
	cmp	x15, #2048
	b.ne	LBB0_53
LBB0_54:                                ; %copy.continue235
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	w10, [sp, #3628]                ; 4-byte Reload
	cbz	w10, LBB0_57
; %bb.55:                               ; %copy.active236
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x15, #0                         ; =0x0
	mov.d	x0, v31[1]
	ldr	q5, [sp, #8800]                 ; 16-byte Reload
	mov.d	x1, v5[1]
	mov.d	x16, v18[1]
	add	x16, x2, x16, lsl #2
	add	x0, x0, x1
	add	x0, x0, #64
LBB0_56:                                ; %copy.chunk.i962
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q18, [x16, x15]
	stur	s18, [x0, #-64]
	mov	s27, v18[1]
	stur	s27, [x0, #-32]
	st1.s	{ v18 }[2], [x0]
	add	x1, x0, #32
	st1.s	{ v18 }[3], [x1]
	add	x15, x15, #16
	add	x0, x0, #128
	cmp	x15, #2048
	b.ne	LBB0_56
LBB0_57:                                ; %direct.schedule.7.thread
                                        ;   in Loop: Header=BB0_28 Depth=1
	sshll.2d	v18, v1, #0
	bit.16b	v6, v21, v18
	ldr	q5, [sp, #8512]                 ; 16-byte Reload
	ldr	q27, [sp, #8432]                ; 16-byte Reload
	bif.16b	v5, v27, v18
	fmov	x15, d16
	add	x15, x15, x15, lsl #1
	lsl	x15, x15, #4
	fmov	d18, x15
	mov.d	x15, v16[1]
	add	x15, x15, x15, lsl #1
	lsl	x15, x15, #4
	mov.d	v18[1], x15
	ldr	w10, [sp, #3676]                ; 4-byte Reload
	ldr	q28, [sp, #8400]                ; 16-byte Reload
	tbz	w10, #0, LBB0_60
; %bb.58:                               ; %copy.active249
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x15, #0                         ; =0x0
	fmov	x0, d6
	fmov	x1, d5
	fmov	x16, d18
	add	x16, x4, x16, lsl #2
	add	x0, x0, x1
	add	x0, x0, #64
LBB0_59:                                ; %copy.chunk.i968
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q16, [x16, x15]
	stur	s16, [x0, #-64]
	mov	s27, v16[1]
	stur	s27, [x0, #-32]
	st1.s	{ v16 }[2], [x0]
	add	x1, x0, #32
	st1.s	{ v16 }[3], [x1]
	add	x15, x15, #16
	add	x0, x0, #128
	cmp	x15, #3072
	b.ne	LBB0_59
LBB0_60:                                ; %copy.continue250
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	w10, [sp, #3672]                ; 4-byte Reload
	cbz	w10, LBB0_63
; %bb.61:                               ; %copy.active251
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x15, #0                         ; =0x0
	mov.d	x0, v6[1]
	mov.d	x1, v5[1]
	mov.d	x16, v18[1]
	add	x16, x4, x16, lsl #2
	add	x0, x0, x1
	add	x0, x0, #64
LBB0_62:                                ; %copy.chunk.i973
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q16, [x16, x15]
	stur	s16, [x0, #-64]
	mov	s18, v16[1]
	stur	s18, [x0, #-32]
	st1.s	{ v16 }[2], [x0]
	add	x1, x0, #32
	st1.s	{ v16 }[3], [x1]
	add	x15, x15, #16
	add	x0, x0, #128
	cmp	x15, #3072
	b.ne	LBB0_62
LBB0_63:                                ; %copy.continue252
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q5, [sp, #8432]                 ; 16-byte Spill
	ldr	q27, [sp, #8480]                ; 16-byte Reload
	bit.16b	v27, v21, v20
	ldr	q5, [sp, #8544]                 ; 16-byte Reload
	ldr	q16, [sp, #8416]                ; 16-byte Reload
	bif.16b	v5, v16, v20
	fmov	x15, d4
	add	x15, x15, x15, lsl #1
	lsl	x15, x15, #4
	fmov	d16, x15
	mov.d	x15, v4[1]
	add	x15, x15, x15, lsl #1
	lsl	x15, x15, #4
	mov.d	v16[1], x15
	ldr	w10, [sp, #3668]                ; 4-byte Reload
	cbz	w10, LBB0_66
; %bb.64:                               ; %copy.active253
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x15, #0                         ; =0x0
	fmov	x0, d27
	fmov	x1, d5
	fmov	x16, d16
	add	x16, x4, x16, lsl #2
	add	x0, x0, x1
	add	x0, x0, #64
LBB0_65:                                ; %copy.chunk.i979
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q4, [x16, x15]
	stur	s4, [x0, #-64]
	mov	s18, v4[1]
	stur	s18, [x0, #-32]
	st1.s	{ v4 }[2], [x0]
	add	x1, x0, #32
	st1.s	{ v4 }[3], [x1]
	add	x15, x15, #16
	add	x0, x0, #128
	cmp	x15, #3072
	b.ne	LBB0_65
LBB0_66:                                ; %copy.continue254
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	w10, [sp, #3664]                ; 4-byte Reload
	cbz	w10, LBB0_69
; %bb.67:                               ; %copy.active255
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x15, #0                         ; =0x0
	mov.d	x0, v27[1]
	mov.d	x1, v5[1]
	mov.d	x16, v16[1]
	add	x16, x4, x16, lsl #2
	add	x0, x0, x1
	add	x0, x0, #64
LBB0_68:                                ; %copy.chunk.i985
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q4, [x16, x15]
	stur	s4, [x0, #-64]
	mov	s16, v4[1]
	stur	s16, [x0, #-32]
	st1.s	{ v4 }[2], [x0]
	add	x1, x0, #32
	st1.s	{ v4 }[3], [x1]
	add	x15, x15, #16
	add	x0, x0, #128
	cmp	x15, #3072
	b.ne	LBB0_68
LBB0_69:                                ; %copy.continue256
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q5, [sp, #8416]                 ; 16-byte Spill
	sshll.2d	v4, v0, #0
	ldr	q18, [sp, #8464]                ; 16-byte Reload
	bit.16b	v18, v21, v4
	ldr	q5, [sp, #8528]                 ; 16-byte Reload
	bit.16b	v28, v5, v4
	fmov	x15, d3
	add	x15, x15, x15, lsl #1
	lsl	x15, x15, #4
	fmov	d4, x15
	mov.d	x15, v3[1]
	add	x15, x15, x15, lsl #1
	lsl	x15, x15, #4
	mov.d	v4[1], x15
	ldr	w10, [sp, #3660]                ; 4-byte Reload
	cbz	w10, LBB0_72
; %bb.70:                               ; %copy.active257
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x15, #0                         ; =0x0
	fmov	x0, d18
	fmov	x1, d28
	fmov	x16, d4
	add	x16, x4, x16, lsl #2
	add	x0, x0, x1
	add	x0, x0, #64
LBB0_71:                                ; %copy.chunk.i991
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x16, x15]
	stur	s3, [x0, #-64]
	mov	s16, v3[1]
	stur	s16, [x0, #-32]
	st1.s	{ v3 }[2], [x0]
	add	x1, x0, #32
	st1.s	{ v3 }[3], [x1]
	add	x15, x15, #16
	add	x0, x0, #128
	cmp	x15, #3072
	b.ne	LBB0_71
LBB0_72:                                ; %copy.continue258
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	w10, [sp, #3656]                ; 4-byte Reload
	ldr	q5, [sp, #8448]                 ; 16-byte Reload
	cbz	w10, LBB0_75
; %bb.73:                               ; %copy.active259
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x15, #0                         ; =0x0
	mov.d	x0, v18[1]
	mov.d	x1, v28[1]
	mov.d	x16, v4[1]
	add	x16, x4, x16, lsl #2
	add	x0, x0, x1
	add	x0, x0, #64
LBB0_74:                                ; %copy.chunk.i997
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x16, x15]
	stur	s3, [x0, #-64]
	mov	s4, v3[1]
	stur	s4, [x0, #-32]
	st1.s	{ v3 }[2], [x0]
	add	x1, x0, #32
	st1.s	{ v3 }[3], [x1]
	add	x15, x15, #16
	add	x0, x0, #128
	cmp	x15, #3072
	b.ne	LBB0_74
LBB0_75:                                ; %copy.continue260
                                        ;   in Loop: Header=BB0_28 Depth=1
	bit.16b	v5, v21, v23
	ldr	q3, [sp, #8560]                 ; 16-byte Reload
	ldr	q16, [sp, #8384]                ; 16-byte Reload
	bit.16b	v16, v3, v23
	fmov	x15, d2
	add	x15, x15, x15, lsl #1
	lsl	x15, x15, #4
	fmov	d3, x15
	mov.d	x15, v2[1]
	add	x15, x15, x15, lsl #1
	lsl	x15, x15, #4
	mov.d	v3[1], x15
	ldr	w10, [sp, #3652]                ; 4-byte Reload
	cbz	w10, LBB0_78
; %bb.76:                               ; %copy.active261
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x15, #0                         ; =0x0
	fmov	x0, d5
	fmov	x1, d16
	fmov	x16, d3
	add	x16, x4, x16, lsl #2
	add	x0, x0, x1
	add	x0, x0, #64
LBB0_77:                                ; %copy.chunk.i1003
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x16, x15]
	stur	s2, [x0, #-64]
	mov	s4, v2[1]
	stur	s4, [x0, #-32]
	st1.s	{ v2 }[2], [x0]
	add	x1, x0, #32
	st1.s	{ v2 }[3], [x1]
	add	x15, x15, #16
	add	x0, x0, #128
	cmp	x15, #3072
	b.ne	LBB0_77
LBB0_78:                                ; %copy.continue262
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	w10, [sp, #3628]                ; 4-byte Reload
	ldr	q23, [sp, #8608]                ; 16-byte Reload
	ldr	q21, [sp, #8576]                ; 16-byte Reload
	str	q13, [sp, #7968]                ; 16-byte Spill
	str	q14, [sp, #7952]                ; 16-byte Spill
	str	q15, [sp, #7936]                ; 16-byte Spill
	str	q6, [sp, #8496]                 ; 16-byte Spill
	str	q27, [sp, #8480]                ; 16-byte Spill
	str	q18, [sp, #8464]                ; 16-byte Spill
	str	q5, [sp, #8448]                 ; 16-byte Spill
	str	q28, [sp, #8400]                ; 16-byte Spill
	str	q16, [sp, #8384]                ; 16-byte Spill
	cbz	w10, LBB0_81
; %bb.79:                               ; %copy.active263
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x15, #0                         ; =0x0
	mov.d	x0, v5[1]
	mov.d	x1, v16[1]
	mov.d	x16, v3[1]
	add	x16, x4, x16, lsl #2
	add	x0, x0, x1
	add	x0, x0, #64
LBB0_80:                                ; %copy.chunk.i1009
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x16, x15]
	stur	s2, [x0, #-64]
	mov	s3, v2[1]
	stur	s3, [x0, #-32]
	st1.s	{ v2 }[2], [x0]
	add	x1, x0, #32
	st1.s	{ v2 }[3], [x1]
	add	x15, x15, #16
	add	x0, x0, #128
	cmp	x15, #3072
	b.ne	LBB0_80
LBB0_81:                                ;   in Loop: Header=BB0_28 Depth=1
	ldr	x10, [sp, #3544]                ; 8-byte Reload
	b	LBB0_87
LBB0_82:                                ; %direct.true1868.preheader
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q19, [sp, #608]                 ; 16-byte Spill
	mov	x15, #0                         ; =0x0
	ldr	q19, [sp, #10064]               ; 16-byte Reload
	mov	w1, #43691                      ; =0xaaab
	b	LBB0_84
LBB0_83:                                ; %direct.schedule.89
                                        ;   in Loop: Header=BB0_84 Depth=2
	add.2d	v16, v4, v7
	add.2d	v18, v4, v6
	add.2d	v4, v4, v11
	mov.d	x16, v4[1]
	fmov	x0, d4
	add	x0, x0, x0, lsl #1
	lsl	x0, x0, #4
	fmov	d4, x0
	add	x16, x16, x16, lsl #1
	lsl	x16, x16, #4
	mov.d	v4[1], x16
	mov.d	x16, v18[1]
	fmov	x0, d18
	add	x0, x0, x0, lsl #1
	lsl	x0, x0, #4
	fmov	d18, x0
	add	x16, x16, x16, lsl #1
	lsl	x16, x16, #4
	mov.d	v18[1], x16
	mov.d	x16, v16[1]
	fmov	x0, d16
	add	x0, x0, x0, lsl #1
	lsl	x0, x0, #4
	fmov	d16, x0
	add	x16, x16, x16, lsl #1
	lsl	x16, x16, #4
	mov.d	v16[1], x16
	sshll.2d	v27, v0, #0
	add.2d	v16, v16, v3
	add.2d	v18, v18, v3
	add.2d	v3, v4, v3
	bit.16b	v28, v3, v23
	bit.16b	v17, v18, v27
	bit.16b	v15, v16, v20
	bit.16b	v13, v2, v0
	ldr	q3, [sp, #9728]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #9728]                 ; 16-byte Spill
	add	x16, x3, x15, lsl #5
	ldp	q3, q4, [x16]
	bit.16b	v4, v2, v0
	bif.16b	v2, v3, v1
	stp	q2, q4, [x16]
	add	x15, x15, #1
	cmp	x15, #768
	b.eq	LBB0_86
LBB0_84:                                ; %direct.true1868
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w10, w15, #0xffff
	mul	w10, w10, w1
	lsr	w10, w10, #21
	orr	w16, w10, #0x80
	dup.2d	v4, x16
	add.2d	v2, v4, v10
	mov.d	x16, v2[1]
	fmov	x0, d2
	add	x0, x0, x0, lsl #1
	lsl	x0, x0, #4
	fmov	d2, x0
	sshll.2d	v5, v1, #0
	msub	w10, w10, w14, w15
	and	x10, x10, #0xffff
	add	x16, x16, x16, lsl #1
	lsl	x16, x16, #4
	mov.d	v2[1], x16
	dup.2d	v3, x10
	add.2d	v2, v2, v3
	bit.16b	v14, v2, v5
	movi.2d	v2, #0000000000000000
	cmp	x15, #47
	b.hi	LBB0_83
; %bb.85:                               ; %direct.true1881
                                        ;   in Loop: Header=BB0_84 Depth=2
	fmov	x10, d14
	add	x10, x4, x10, lsl #2
	ld1r.4s	{ v2 }, [x10]
	b	LBB0_83
LBB0_86:                                ; %direct.schedule.9.loopexit
                                        ;   in Loop: Header=BB0_28 Depth=1
	stp	q12, q31, [sp, #576]            ; 32-byte Folded Spill
	str	q28, [sp, #640]                 ; 16-byte Spill
	str	q15, [sp, #7936]                ; 16-byte Spill
	str	q14, [sp, #7952]                ; 16-byte Spill
	str	q13, [sp, #7968]                ; 16-byte Spill
	sshll.2d	v2, v1, #0
	sshll.2d	v3, v0, #0
	ldr	q4, [sp, #8448]                 ; 16-byte Reload
	bit.16b	v4, v21, v23
	str	q4, [sp, #8448]                 ; 16-byte Spill
	ldr	q4, [sp, #8480]                 ; 16-byte Reload
	bit.16b	v4, v21, v20
	str	q4, [sp, #8480]                 ; 16-byte Spill
	ldr	q4, [sp, #8464]                 ; 16-byte Reload
	bit.16b	v4, v21, v3
	str	q4, [sp, #8464]                 ; 16-byte Spill
	ldr	q4, [sp, #8496]                 ; 16-byte Reload
	bit.16b	v4, v21, v2
	str	q4, [sp, #8496]                 ; 16-byte Spill
	ldr	q4, [sp, #8560]                 ; 16-byte Reload
	ldr	q5, [sp, #8384]                 ; 16-byte Reload
	bit.16b	v5, v4, v23
	str	q5, [sp, #8384]                 ; 16-byte Spill
	ldr	q4, [sp, #8544]                 ; 16-byte Reload
	ldr	q5, [sp, #8416]                 ; 16-byte Reload
	bit.16b	v5, v4, v20
	str	q5, [sp, #8416]                 ; 16-byte Spill
	ldr	q4, [sp, #8528]                 ; 16-byte Reload
	ldr	q5, [sp, #8400]                 ; 16-byte Reload
	bit.16b	v5, v4, v3
	str	q5, [sp, #8400]                 ; 16-byte Spill
	ldr	q3, [sp, #8512]                 ; 16-byte Reload
	ldr	q4, [sp, #8432]                 ; 16-byte Reload
	bit.16b	v4, v3, v2
	str	q4, [sp, #8432]                 ; 16-byte Spill
	ldr	x10, [sp, #3544]                ; 8-byte Reload
	ldr	q23, [sp, #8608]                ; 16-byte Reload
	ldr	q21, [sp, #8576]                ; 16-byte Reload
LBB0_87:                                ; %direct.schedule.9
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x6, #0                          ; =0x0
	mov	w15, #1024                      ; =0x400
	mov	w16, #8192                      ; =0x2000
	movk	w16, #1, lsl #16
LBB0_88:                                ; %direct.schedule.12.preheader
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_89 Depth 3
	mov	x24, #-16384                    ; =0xffffffffffffc000
	mov	x5, x15
	mov	x0, x16
	add	x2, x8, x6, lsl #11
LBB0_89:                                ; %direct.true270
                                        ;   Parent Loop BB0_28 Depth=1
                                        ;     Parent Loop BB0_88 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q2, q3, [x2]
	and.16b	v3, v0, v3
	and.16b	v2, v1, v2
	and	x1, x5, #0x1c00
	add	x7, x8, x1
	ldp	q16, q4, [x7]
	and.16b	v16, v1, v16
	and.16b	v4, v0, v4
	add	x19, x25, x24
	add	x1, x8, x24
	prfm	pldl1keep, [x19, #18400]
	ldr	q18, [x1, #49168]
	and.16b	v18, v0, v18
	ldr	q27, [x1, #49152]
	and.16b	v27, v1, v27
	prfm	pldl1keep, [x19, #19424]
	ldr	q28, [x1, #50176]
	and.16b	v28, v1, v28
	ldr	q31, [x1, #50192]
	and.16b	v31, v0, v31
	fmul.4s	v9, v2, v27
	fmul.4s	v10, v3, v18
	fadd.4s	v10, v10, v8
	fadd.4s	v9, v9, v8
	fmul.4s	v3, v3, v31
	fmul.4s	v2, v2, v28
	fadd.4s	v2, v2, v8
	fadd.4s	v3, v3, v8
	fmul.4s	v18, v4, v18
	fmul.4s	v27, v16, v27
	fadd.4s	v27, v27, v8
	fadd.4s	v18, v18, v8
	fmul.4s	v4, v4, v31
	fmul.4s	v16, v16, v28
	fadd.4s	v16, v16, v8
	fadd.4s	v4, v4, v8
	ldp	q31, q28, [x2, #32]
	and.16b	v31, v1, v31
	and.16b	v28, v0, v28
	ldp	q11, q12, [x7, #32]
	and.16b	v12, v0, v12
	and.16b	v11, v1, v11
	ldr	q15, [x1, #49200]
	ldr	q13, [x1, #49184]
	and.16b	v13, v1, v13
	and.16b	v15, v0, v15
	ldr	q14, [x1, #50208]
	ldr	q20, [x1, #50224]
	and.16b	v20, v0, v20
	and.16b	v14, v1, v14
	fmul.4s	v5, v28, v15
	fmul.4s	v6, v31, v13
	fadd.4s	v6, v9, v6
	fadd.4s	v5, v10, v5
	fmul.4s	v31, v31, v14
	fmul.4s	v28, v28, v20
	fadd.4s	v3, v3, v28
	fadd.4s	v2, v2, v31
	fmul.4s	v28, v11, v13
	fmul.4s	v31, v12, v15
	fadd.4s	v18, v18, v31
	fadd.4s	v27, v27, v28
	fmul.4s	v28, v11, v14
	fmul.4s	v20, v12, v20
	fadd.4s	v4, v4, v20
	fadd.4s	v16, v16, v28
	ldp	q20, q28, [x2, #64]
	and.16b	v28, v0, v28
	and.16b	v20, v1, v20
	ldp	q9, q31, [x7, #64]
	and.16b	v9, v1, v9
	and.16b	v31, v0, v31
	prfm	pldl1keep, [x19, #18464]
	ldr	q10, [x1, #49216]
	ldr	q11, [x1, #49232]
	and.16b	v11, v0, v11
	and.16b	v10, v1, v10
	prfm	pldl1keep, [x19, #19488]
	ldr	q12, [x1, #50256]
	ldr	q13, [x1, #50240]
	and.16b	v13, v1, v13
	and.16b	v12, v0, v12
	fmul.4s	v14, v20, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v5, v5, v15
	fadd.4s	v6, v6, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v20, v20, v13
	fadd.4s	v2, v2, v20
	fadd.4s	v3, v3, v28
	fmul.4s	v20, v31, v11
	fmul.4s	v28, v9, v10
	fadd.4s	v27, v27, v28
	fadd.4s	v18, v18, v20
	fmul.4s	v20, v31, v12
	fmul.4s	v28, v9, v13
	fadd.4s	v16, v16, v28
	fadd.4s	v4, v4, v20
	ldp	q28, q20, [x2, #96]
	and.16b	v28, v1, v28
	and.16b	v20, v0, v20
	ldp	q31, q9, [x7, #96]
	and.16b	v9, v0, v9
	and.16b	v31, v1, v31
	ldr	q10, [x1, #49264]
	ldr	q11, [x1, #49248]
	and.16b	v11, v1, v11
	and.16b	v10, v0, v10
	ldr	q12, [x1, #50272]
	ldr	q13, [x1, #50288]
	and.16b	v13, v0, v13
	and.16b	v12, v1, v12
	fmul.4s	v14, v20, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v6, v6, v15
	fadd.4s	v5, v5, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v20, v20, v13
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v28
	fmul.4s	v20, v31, v11
	fmul.4s	v28, v9, v10
	fadd.4s	v18, v18, v28
	fadd.4s	v20, v27, v20
	fmul.4s	v27, v31, v12
	fmul.4s	v28, v9, v13
	fadd.4s	v4, v4, v28
	fadd.4s	v16, v16, v27
	ldp	q27, q28, [x2, #128]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	ldp	q9, q31, [x7, #128]
	and.16b	v9, v1, v9
	and.16b	v31, v0, v31
	prfm	pldl1keep, [x19, #18528]
	ldr	q10, [x1, #49280]
	ldr	q11, [x1, #49296]
	and.16b	v11, v0, v11
	and.16b	v10, v1, v10
	prfm	pldl1keep, [x19, #19552]
	ldr	q12, [x1, #50320]
	ldr	q13, [x1, #50304]
	and.16b	v13, v1, v13
	and.16b	v12, v0, v12
	fmul.4s	v14, v27, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v5, v5, v15
	fadd.4s	v6, v6, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v27, v27, v13
	fadd.4s	v2, v2, v27
	fadd.4s	v3, v3, v28
	fmul.4s	v27, v31, v11
	fmul.4s	v28, v9, v10
	fadd.4s	v20, v20, v28
	fadd.4s	v18, v18, v27
	fmul.4s	v27, v31, v12
	fmul.4s	v28, v9, v13
	fadd.4s	v16, v16, v28
	fadd.4s	v4, v4, v27
	ldp	q28, q27, [x2, #160]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	ldp	q31, q9, [x7, #160]
	and.16b	v9, v0, v9
	and.16b	v31, v1, v31
	ldr	q10, [x1, #49328]
	ldr	q11, [x1, #49312]
	and.16b	v11, v1, v11
	and.16b	v10, v0, v10
	ldr	q12, [x1, #50336]
	ldr	q13, [x1, #50352]
	and.16b	v13, v0, v13
	and.16b	v12, v1, v12
	fmul.4s	v14, v27, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v6, v6, v15
	fadd.4s	v5, v5, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v27, v27, v13
	fadd.4s	v3, v3, v27
	fadd.4s	v2, v2, v28
	fmul.4s	v27, v31, v11
	fmul.4s	v28, v9, v10
	fadd.4s	v18, v18, v28
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v31, v12
	fmul.4s	v28, v9, v13
	fadd.4s	v4, v4, v28
	fadd.4s	v16, v16, v27
	ldp	q27, q28, [x2, #192]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	ldp	q9, q31, [x7, #192]
	and.16b	v9, v1, v9
	and.16b	v31, v0, v31
	prfm	pldl1keep, [x19, #18592]
	ldr	q10, [x1, #49344]
	ldr	q11, [x1, #49360]
	and.16b	v11, v0, v11
	and.16b	v10, v1, v10
	prfm	pldl1keep, [x19, #19616]
	ldr	q12, [x1, #50384]
	ldr	q13, [x1, #50368]
	and.16b	v13, v1, v13
	and.16b	v12, v0, v12
	fmul.4s	v14, v27, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v5, v5, v15
	fadd.4s	v6, v6, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v27, v27, v13
	fadd.4s	v2, v2, v27
	fadd.4s	v3, v3, v28
	fmul.4s	v27, v31, v11
	fmul.4s	v28, v9, v10
	fadd.4s	v20, v20, v28
	fadd.4s	v18, v18, v27
	fmul.4s	v27, v31, v12
	fmul.4s	v28, v9, v13
	fadd.4s	v16, v16, v28
	fadd.4s	v4, v4, v27
	ldp	q28, q27, [x2, #224]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	ldp	q31, q9, [x7, #224]
	and.16b	v9, v0, v9
	and.16b	v31, v1, v31
	ldr	q10, [x1, #49392]
	ldr	q11, [x1, #49376]
	and.16b	v11, v1, v11
	and.16b	v10, v0, v10
	ldr	q12, [x1, #50400]
	ldr	q13, [x1, #50416]
	and.16b	v13, v0, v13
	and.16b	v12, v1, v12
	fmul.4s	v14, v27, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v6, v6, v15
	fadd.4s	v5, v5, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v27, v27, v13
	fadd.4s	v3, v3, v27
	fadd.4s	v2, v2, v28
	fmul.4s	v27, v31, v11
	fmul.4s	v28, v9, v10
	fadd.4s	v18, v18, v28
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v31, v12
	fmul.4s	v28, v9, v13
	fadd.4s	v4, v4, v28
	fadd.4s	v16, v16, v27
	ldp	q27, q28, [x2, #256]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	ldp	q9, q31, [x7, #256]
	and.16b	v9, v1, v9
	and.16b	v31, v0, v31
	prfm	pldl1keep, [x19, #18656]
	ldr	q10, [x1, #49408]
	ldr	q11, [x1, #49424]
	and.16b	v11, v0, v11
	and.16b	v10, v1, v10
	prfm	pldl1keep, [x19, #19680]
	ldr	q12, [x1, #50448]
	ldr	q13, [x1, #50432]
	and.16b	v13, v1, v13
	and.16b	v12, v0, v12
	fmul.4s	v14, v27, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v5, v5, v15
	fadd.4s	v6, v6, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v27, v27, v13
	fadd.4s	v2, v2, v27
	fadd.4s	v3, v3, v28
	fmul.4s	v27, v31, v11
	fmul.4s	v28, v9, v10
	fadd.4s	v20, v20, v28
	fadd.4s	v18, v18, v27
	fmul.4s	v27, v31, v12
	fmul.4s	v28, v9, v13
	fadd.4s	v16, v16, v28
	fadd.4s	v4, v4, v27
	ldp	q28, q27, [x2, #288]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	ldp	q31, q9, [x7, #288]
	and.16b	v9, v0, v9
	and.16b	v31, v1, v31
	ldr	q10, [x1, #49456]
	ldr	q11, [x1, #49440]
	and.16b	v11, v1, v11
	and.16b	v10, v0, v10
	ldr	q12, [x1, #50464]
	ldr	q13, [x1, #50480]
	and.16b	v13, v0, v13
	and.16b	v12, v1, v12
	fmul.4s	v14, v27, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v6, v6, v15
	fadd.4s	v5, v5, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v27, v27, v13
	fadd.4s	v3, v3, v27
	fadd.4s	v2, v2, v28
	fmul.4s	v27, v31, v11
	fmul.4s	v28, v9, v10
	fadd.4s	v18, v18, v28
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v31, v12
	fmul.4s	v28, v9, v13
	fadd.4s	v4, v4, v28
	fadd.4s	v16, v16, v27
	ldp	q27, q28, [x2, #320]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	ldp	q9, q31, [x7, #320]
	and.16b	v9, v1, v9
	and.16b	v31, v0, v31
	prfm	pldl1keep, [x19, #18720]
	ldr	q10, [x1, #49472]
	ldr	q11, [x1, #49488]
	and.16b	v11, v0, v11
	and.16b	v10, v1, v10
	prfm	pldl1keep, [x19, #19744]
	ldr	q12, [x1, #50512]
	ldr	q13, [x1, #50496]
	and.16b	v13, v1, v13
	and.16b	v12, v0, v12
	fmul.4s	v14, v27, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v5, v5, v15
	fadd.4s	v6, v6, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v27, v27, v13
	fadd.4s	v2, v2, v27
	fadd.4s	v3, v3, v28
	fmul.4s	v27, v31, v11
	fmul.4s	v28, v9, v10
	fadd.4s	v20, v20, v28
	fadd.4s	v18, v18, v27
	fmul.4s	v27, v31, v12
	fmul.4s	v28, v9, v13
	fadd.4s	v16, v16, v28
	fadd.4s	v4, v4, v27
	ldp	q28, q27, [x2, #352]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	ldp	q31, q9, [x7, #352]
	and.16b	v9, v0, v9
	and.16b	v31, v1, v31
	ldr	q10, [x1, #49520]
	ldr	q11, [x1, #49504]
	and.16b	v11, v1, v11
	and.16b	v10, v0, v10
	ldr	q12, [x1, #50528]
	ldr	q13, [x1, #50544]
	and.16b	v13, v0, v13
	and.16b	v12, v1, v12
	fmul.4s	v14, v27, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v6, v6, v15
	fadd.4s	v5, v5, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v27, v27, v13
	fadd.4s	v3, v3, v27
	fadd.4s	v2, v2, v28
	fmul.4s	v27, v31, v11
	fmul.4s	v28, v9, v10
	fadd.4s	v18, v18, v28
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v31, v12
	fmul.4s	v28, v9, v13
	fadd.4s	v4, v4, v28
	fadd.4s	v16, v16, v27
	ldp	q27, q28, [x2, #384]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	ldp	q9, q31, [x7, #384]
	and.16b	v9, v1, v9
	and.16b	v31, v0, v31
	prfm	pldl1keep, [x19, #18784]
	ldr	q10, [x1, #49536]
	ldr	q11, [x1, #49552]
	and.16b	v11, v0, v11
	and.16b	v10, v1, v10
	prfm	pldl1keep, [x19, #19808]
	ldr	q12, [x1, #50576]
	ldr	q13, [x1, #50560]
	and.16b	v13, v1, v13
	and.16b	v12, v0, v12
	fmul.4s	v14, v27, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v5, v5, v15
	fadd.4s	v6, v6, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v27, v27, v13
	fadd.4s	v2, v2, v27
	fadd.4s	v3, v3, v28
	fmul.4s	v27, v31, v11
	fmul.4s	v28, v9, v10
	fadd.4s	v20, v20, v28
	fadd.4s	v18, v18, v27
	fmul.4s	v27, v31, v12
	fmul.4s	v28, v9, v13
	fadd.4s	v16, v16, v28
	fadd.4s	v4, v4, v27
	ldp	q28, q27, [x2, #416]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	ldp	q31, q9, [x7, #416]
	and.16b	v9, v0, v9
	and.16b	v31, v1, v31
	ldr	q10, [x1, #49584]
	ldr	q11, [x1, #49568]
	and.16b	v11, v1, v11
	and.16b	v10, v0, v10
	ldr	q12, [x1, #50592]
	ldr	q13, [x1, #50608]
	and.16b	v13, v0, v13
	and.16b	v12, v1, v12
	fmul.4s	v14, v27, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v6, v6, v15
	fadd.4s	v5, v5, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v27, v27, v13
	fadd.4s	v3, v3, v27
	fadd.4s	v2, v2, v28
	fmul.4s	v27, v31, v11
	fmul.4s	v28, v9, v10
	fadd.4s	v18, v18, v28
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v31, v12
	fmul.4s	v28, v9, v13
	fadd.4s	v4, v4, v28
	fadd.4s	v16, v16, v27
	ldp	q27, q28, [x2, #448]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	ldp	q9, q31, [x7, #448]
	and.16b	v9, v1, v9
	and.16b	v31, v0, v31
	prfm	pldl1keep, [x19, #18848]
	ldr	q10, [x1, #49600]
	ldr	q11, [x1, #49616]
	and.16b	v11, v0, v11
	and.16b	v10, v1, v10
	prfm	pldl1keep, [x19, #19872]
	ldr	q12, [x1, #50640]
	ldr	q13, [x1, #50624]
	and.16b	v13, v1, v13
	and.16b	v12, v0, v12
	fmul.4s	v14, v27, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v5, v5, v15
	fadd.4s	v6, v6, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v27, v27, v13
	fadd.4s	v2, v2, v27
	fadd.4s	v3, v3, v28
	fmul.4s	v27, v31, v11
	fmul.4s	v28, v9, v10
	fadd.4s	v20, v20, v28
	fadd.4s	v18, v18, v27
	fmul.4s	v27, v31, v12
	fmul.4s	v28, v9, v13
	fadd.4s	v16, v16, v28
	fadd.4s	v4, v4, v27
	ldp	q28, q27, [x2, #480]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	ldp	q31, q9, [x7, #480]
	and.16b	v9, v0, v9
	and.16b	v31, v1, v31
	ldr	q10, [x1, #49648]
	ldr	q11, [x1, #49632]
	and.16b	v11, v1, v11
	and.16b	v10, v0, v10
	ldr	q12, [x1, #50656]
	ldr	q13, [x1, #50672]
	and.16b	v13, v0, v13
	and.16b	v12, v1, v12
	fmul.4s	v14, v27, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v6, v6, v15
	fadd.4s	v5, v5, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v27, v27, v13
	fadd.4s	v3, v3, v27
	fadd.4s	v2, v2, v28
	fmul.4s	v27, v31, v11
	fmul.4s	v28, v9, v10
	fadd.4s	v18, v18, v28
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v31, v12
	fmul.4s	v28, v9, v13
	fadd.4s	v4, v4, v28
	fadd.4s	v16, v16, v27
	ldp	q27, q28, [x2, #512]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	ldp	q9, q31, [x7, #512]
	and.16b	v9, v1, v9
	and.16b	v31, v0, v31
	prfm	pldl1keep, [x19, #18912]
	ldr	q10, [x1, #49664]
	ldr	q11, [x1, #49680]
	and.16b	v11, v0, v11
	and.16b	v10, v1, v10
	prfm	pldl1keep, [x19, #19936]
	ldr	q12, [x1, #50704]
	ldr	q13, [x1, #50688]
	and.16b	v13, v1, v13
	and.16b	v12, v0, v12
	fmul.4s	v14, v27, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v5, v5, v15
	fadd.4s	v6, v6, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v27, v27, v13
	fadd.4s	v2, v2, v27
	fadd.4s	v3, v3, v28
	fmul.4s	v27, v31, v11
	fmul.4s	v28, v9, v10
	fadd.4s	v20, v20, v28
	fadd.4s	v18, v18, v27
	fmul.4s	v27, v31, v12
	fmul.4s	v28, v9, v13
	fadd.4s	v16, v16, v28
	fadd.4s	v4, v4, v27
	ldp	q28, q27, [x2, #544]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	ldp	q31, q9, [x7, #544]
	and.16b	v9, v0, v9
	and.16b	v31, v1, v31
	ldr	q10, [x1, #49712]
	ldr	q11, [x1, #49696]
	and.16b	v11, v1, v11
	and.16b	v10, v0, v10
	ldr	q12, [x1, #50720]
	ldr	q13, [x1, #50736]
	and.16b	v13, v0, v13
	and.16b	v12, v1, v12
	fmul.4s	v14, v27, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v6, v6, v15
	fadd.4s	v5, v5, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v27, v27, v13
	fadd.4s	v3, v3, v27
	fadd.4s	v2, v2, v28
	fmul.4s	v27, v31, v11
	fmul.4s	v28, v9, v10
	fadd.4s	v18, v18, v28
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v31, v12
	fmul.4s	v28, v9, v13
	fadd.4s	v4, v4, v28
	fadd.4s	v16, v16, v27
	ldp	q27, q28, [x2, #576]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	ldp	q9, q31, [x7, #576]
	and.16b	v9, v1, v9
	and.16b	v31, v0, v31
	prfm	pldl1keep, [x19, #18976]
	ldr	q10, [x1, #49728]
	ldr	q11, [x1, #49744]
	and.16b	v11, v0, v11
	and.16b	v10, v1, v10
	prfm	pldl1keep, [x19, #20000]
	ldr	q12, [x1, #50768]
	ldr	q13, [x1, #50752]
	and.16b	v13, v1, v13
	and.16b	v12, v0, v12
	fmul.4s	v14, v27, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v5, v5, v15
	fadd.4s	v6, v6, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v27, v27, v13
	fadd.4s	v2, v2, v27
	fadd.4s	v3, v3, v28
	fmul.4s	v27, v31, v11
	fmul.4s	v28, v9, v10
	fadd.4s	v20, v20, v28
	fadd.4s	v18, v18, v27
	fmul.4s	v27, v31, v12
	fmul.4s	v28, v9, v13
	fadd.4s	v16, v16, v28
	fadd.4s	v4, v4, v27
	ldp	q28, q27, [x2, #608]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	ldp	q31, q9, [x7, #608]
	and.16b	v9, v0, v9
	and.16b	v31, v1, v31
	ldr	q10, [x1, #49776]
	ldr	q11, [x1, #49760]
	and.16b	v11, v1, v11
	and.16b	v10, v0, v10
	ldr	q12, [x1, #50784]
	ldr	q13, [x1, #50800]
	and.16b	v13, v0, v13
	and.16b	v12, v1, v12
	fmul.4s	v14, v27, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v6, v6, v15
	fadd.4s	v5, v5, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v27, v27, v13
	fadd.4s	v3, v3, v27
	fadd.4s	v2, v2, v28
	fmul.4s	v27, v31, v11
	fmul.4s	v28, v9, v10
	fadd.4s	v18, v18, v28
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v31, v12
	fmul.4s	v28, v9, v13
	fadd.4s	v4, v4, v28
	fadd.4s	v16, v16, v27
	ldp	q27, q28, [x2, #640]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	ldp	q9, q31, [x7, #640]
	and.16b	v9, v1, v9
	and.16b	v31, v0, v31
	prfm	pldl1keep, [x19, #19040]
	ldr	q10, [x1, #49792]
	ldr	q11, [x1, #49808]
	and.16b	v11, v0, v11
	and.16b	v10, v1, v10
	prfm	pldl1keep, [x19, #20064]
	ldr	q12, [x1, #50832]
	ldr	q13, [x1, #50816]
	and.16b	v13, v1, v13
	and.16b	v12, v0, v12
	fmul.4s	v14, v27, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v5, v5, v15
	fadd.4s	v6, v6, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v27, v27, v13
	fadd.4s	v2, v2, v27
	fadd.4s	v3, v3, v28
	fmul.4s	v27, v31, v11
	fmul.4s	v28, v9, v10
	fadd.4s	v20, v20, v28
	fadd.4s	v18, v18, v27
	fmul.4s	v27, v31, v12
	fmul.4s	v28, v9, v13
	fadd.4s	v16, v16, v28
	fadd.4s	v4, v4, v27
	ldp	q28, q27, [x2, #672]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	ldp	q31, q9, [x7, #672]
	and.16b	v9, v0, v9
	and.16b	v31, v1, v31
	ldr	q10, [x1, #49840]
	ldr	q11, [x1, #49824]
	and.16b	v11, v1, v11
	and.16b	v10, v0, v10
	ldr	q12, [x1, #50848]
	ldr	q13, [x1, #50864]
	and.16b	v13, v0, v13
	and.16b	v12, v1, v12
	fmul.4s	v14, v27, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v6, v6, v15
	fadd.4s	v5, v5, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v27, v27, v13
	fadd.4s	v3, v3, v27
	fadd.4s	v2, v2, v28
	fmul.4s	v27, v31, v11
	fmul.4s	v28, v9, v10
	fadd.4s	v18, v18, v28
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v31, v12
	fmul.4s	v28, v9, v13
	fadd.4s	v4, v4, v28
	fadd.4s	v16, v16, v27
	ldp	q27, q28, [x2, #704]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	ldp	q9, q31, [x7, #704]
	and.16b	v9, v1, v9
	and.16b	v31, v0, v31
	prfm	pldl1keep, [x19, #19104]
	ldr	q10, [x1, #49856]
	ldr	q11, [x1, #49872]
	and.16b	v11, v0, v11
	and.16b	v10, v1, v10
	prfm	pldl1keep, [x19, #20128]
	ldr	q12, [x1, #50896]
	ldr	q13, [x1, #50880]
	and.16b	v13, v1, v13
	and.16b	v12, v0, v12
	fmul.4s	v14, v27, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v5, v5, v15
	fadd.4s	v6, v6, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v27, v27, v13
	fadd.4s	v2, v2, v27
	fadd.4s	v3, v3, v28
	fmul.4s	v27, v31, v11
	fmul.4s	v28, v9, v10
	fadd.4s	v20, v20, v28
	fadd.4s	v18, v18, v27
	fmul.4s	v27, v31, v12
	fmul.4s	v28, v9, v13
	fadd.4s	v16, v16, v28
	fadd.4s	v4, v4, v27
	ldp	q28, q27, [x2, #736]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	ldp	q31, q9, [x7, #736]
	and.16b	v9, v0, v9
	and.16b	v31, v1, v31
	ldr	q10, [x1, #49904]
	ldr	q11, [x1, #49888]
	and.16b	v11, v1, v11
	and.16b	v10, v0, v10
	ldr	q12, [x1, #50912]
	ldr	q13, [x1, #50928]
	and.16b	v13, v0, v13
	and.16b	v12, v1, v12
	fmul.4s	v14, v27, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v6, v6, v15
	fadd.4s	v5, v5, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v27, v27, v13
	fadd.4s	v3, v3, v27
	fadd.4s	v2, v2, v28
	fmul.4s	v27, v31, v11
	fmul.4s	v28, v9, v10
	fadd.4s	v18, v18, v28
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v31, v12
	fmul.4s	v28, v9, v13
	fadd.4s	v4, v4, v28
	fadd.4s	v16, v16, v27
	ldp	q27, q28, [x2, #768]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	ldp	q9, q31, [x7, #768]
	and.16b	v9, v1, v9
	and.16b	v31, v0, v31
	prfm	pldl1keep, [x19, #19168]
	ldr	q10, [x1, #49920]
	ldr	q11, [x1, #49936]
	and.16b	v11, v0, v11
	and.16b	v10, v1, v10
	prfm	pldl1keep, [x19, #20192]
	ldr	q12, [x1, #50960]
	ldr	q13, [x1, #50944]
	and.16b	v13, v1, v13
	and.16b	v12, v0, v12
	fmul.4s	v14, v27, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v5, v5, v15
	fadd.4s	v6, v6, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v27, v27, v13
	fadd.4s	v2, v2, v27
	fadd.4s	v3, v3, v28
	fmul.4s	v27, v31, v11
	fmul.4s	v28, v9, v10
	fadd.4s	v20, v20, v28
	fadd.4s	v18, v18, v27
	fmul.4s	v27, v31, v12
	fmul.4s	v28, v9, v13
	fadd.4s	v16, v16, v28
	fadd.4s	v4, v4, v27
	ldp	q28, q27, [x2, #800]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	ldp	q31, q9, [x7, #800]
	and.16b	v9, v0, v9
	and.16b	v31, v1, v31
	ldr	q10, [x1, #49968]
	ldr	q11, [x1, #49952]
	and.16b	v11, v1, v11
	and.16b	v10, v0, v10
	ldr	q12, [x1, #50976]
	ldr	q13, [x1, #50992]
	and.16b	v13, v0, v13
	and.16b	v12, v1, v12
	fmul.4s	v14, v27, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v6, v6, v15
	fadd.4s	v5, v5, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v27, v27, v13
	fadd.4s	v3, v3, v27
	fadd.4s	v2, v2, v28
	fmul.4s	v27, v31, v11
	fmul.4s	v28, v9, v10
	fadd.4s	v18, v18, v28
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v31, v12
	fmul.4s	v28, v9, v13
	fadd.4s	v4, v4, v28
	fadd.4s	v16, v16, v27
	ldp	q27, q28, [x2, #832]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	ldp	q9, q31, [x7, #832]
	and.16b	v9, v1, v9
	and.16b	v31, v0, v31
	prfm	pldl1keep, [x19, #19232]
	ldr	q10, [x1, #49984]
	ldr	q11, [x1, #50000]
	and.16b	v11, v0, v11
	and.16b	v10, v1, v10
	prfm	pldl1keep, [x19, #20256]
	ldr	q12, [x1, #51024]
	ldr	q13, [x1, #51008]
	and.16b	v13, v1, v13
	and.16b	v12, v0, v12
	fmul.4s	v14, v27, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v5, v5, v15
	fadd.4s	v6, v6, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v27, v27, v13
	fadd.4s	v2, v2, v27
	fadd.4s	v3, v3, v28
	fmul.4s	v27, v31, v11
	fmul.4s	v28, v9, v10
	fadd.4s	v20, v20, v28
	fadd.4s	v18, v18, v27
	fmul.4s	v27, v31, v12
	fmul.4s	v28, v9, v13
	fadd.4s	v16, v16, v28
	fadd.4s	v4, v4, v27
	ldp	q28, q27, [x2, #864]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	ldp	q31, q9, [x7, #864]
	and.16b	v9, v0, v9
	and.16b	v31, v1, v31
	ldr	q10, [x1, #50032]
	ldr	q11, [x1, #50016]
	and.16b	v11, v1, v11
	and.16b	v10, v0, v10
	ldr	q12, [x1, #51040]
	ldr	q13, [x1, #51056]
	and.16b	v13, v0, v13
	and.16b	v12, v1, v12
	fmul.4s	v14, v27, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v6, v6, v15
	fadd.4s	v5, v5, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v27, v27, v13
	fadd.4s	v3, v3, v27
	fadd.4s	v2, v2, v28
	fmul.4s	v27, v31, v11
	fmul.4s	v28, v9, v10
	fadd.4s	v18, v18, v28
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v31, v12
	fmul.4s	v28, v9, v13
	fadd.4s	v4, v4, v28
	fadd.4s	v16, v16, v27
	ldp	q27, q28, [x2, #896]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	ldp	q9, q31, [x7, #896]
	and.16b	v9, v1, v9
	and.16b	v31, v0, v31
	prfm	pldl1keep, [x19, #19296]
	ldr	q10, [x1, #50048]
	ldr	q11, [x1, #50064]
	and.16b	v11, v0, v11
	and.16b	v10, v1, v10
	prfm	pldl1keep, [x19, #20320]
	ldr	q12, [x1, #51088]
	ldr	q13, [x1, #51072]
	and.16b	v13, v1, v13
	and.16b	v12, v0, v12
	fmul.4s	v14, v27, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v5, v5, v15
	fadd.4s	v6, v6, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v27, v27, v13
	fadd.4s	v2, v2, v27
	fadd.4s	v3, v3, v28
	fmul.4s	v27, v31, v11
	fmul.4s	v28, v9, v10
	fadd.4s	v20, v20, v28
	fadd.4s	v18, v18, v27
	fmul.4s	v27, v31, v12
	fmul.4s	v28, v9, v13
	fadd.4s	v16, v16, v28
	fadd.4s	v4, v4, v27
	ldp	q28, q27, [x2, #928]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	ldp	q31, q9, [x7, #928]
	and.16b	v9, v0, v9
	and.16b	v31, v1, v31
	ldr	q10, [x1, #50096]
	ldr	q11, [x1, #50080]
	and.16b	v11, v1, v11
	and.16b	v10, v0, v10
	ldr	q12, [x1, #51104]
	ldr	q13, [x1, #51120]
	and.16b	v13, v0, v13
	and.16b	v12, v1, v12
	fmul.4s	v14, v27, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v6, v6, v15
	fadd.4s	v5, v5, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v27, v27, v13
	fadd.4s	v3, v3, v27
	fadd.4s	v27, v2, v28
	fmul.4s	v2, v31, v11
	fmul.4s	v28, v9, v10
	fadd.4s	v18, v18, v28
	fadd.4s	v20, v20, v2
	fmul.4s	v28, v31, v12
	fmul.4s	v2, v9, v13
	fadd.4s	v2, v4, v2
	fadd.4s	v4, v16, v28
	ldp	q16, q28, [x2, #960]
	and.16b	v28, v0, v28
	and.16b	v16, v1, v16
	ldp	q9, q31, [x7, #960]
	and.16b	v9, v1, v9
	and.16b	v31, v0, v31
	prfm	pldl1keep, [x19, #19360]
	ldr	q10, [x1, #50112]
	ldr	q11, [x1, #50128]
	and.16b	v11, v0, v11
	and.16b	v10, v1, v10
	prfm	pldl1keep, [x19, #20384]
	ldr	q12, [x1, #51152]
	ldr	q13, [x1, #51136]
	and.16b	v13, v1, v13
	and.16b	v12, v0, v12
	fmul.4s	v14, v16, v10
	fmul.4s	v15, v28, v11
	fadd.4s	v5, v5, v15
	fadd.4s	v6, v6, v14
	fmul.4s	v28, v28, v12
	fmul.4s	v16, v16, v13
	fadd.4s	v27, v27, v16
	fadd.4s	v28, v3, v28
	fmul.4s	v3, v31, v11
	fmul.4s	v16, v9, v10
	fadd.4s	v16, v20, v16
	fadd.4s	v18, v18, v3
	fmul.4s	v3, v31, v12
	fmul.4s	v20, v9, v13
	ldp	q9, q31, [x2, #992]
	fadd.4s	v4, v4, v20
	and.16b	v20, v1, v9
	and.16b	v31, v0, v31
	ldp	q9, q10, [x7, #992]
	and.16b	v10, v0, v10
	and.16b	v9, v1, v9
	ldr	q11, [x1, #50160]
	ldr	q12, [x1, #50144]
	and.16b	v12, v1, v12
	and.16b	v11, v0, v11
	ldr	q13, [x1, #51168]
	fmul.4s	v14, v31, v11
	add	x4, x8, x0
	fmul.4s	v15, v20, v12
	fadd.4s	v6, v6, v15
	fadd.4s	v5, v5, v14
	ldp	q14, q15, [x4]
	bif.16b	v5, v15, v0
	ldr	q15, [x1, #51184]
	and.16b	v15, v0, v15
	and.16b	v13, v1, v13
	bif.16b	v6, v14, v1
	stp	q6, q5, [x4]
	fmul.4s	v5, v20, v13
	fmul.4s	v6, v31, v15
	fadd.4s	v6, v28, v6
	ldp	q28, q20, [x4, #32]
	fadd.4s	v5, v27, v5
	bif.16b	v5, v28, v1
	bif.16b	v6, v20, v0
	stp	q5, q6, [x4, #32]
	fmul.4s	v5, v9, v12
	fmul.4s	v6, v10, v11
	fadd.4s	v6, v18, v6
	ldp	q20, q18, [x4, #512]
	fadd.4s	v5, v16, v5
	bif.16b	v5, v20, v1
	bif.16b	v6, v18, v0
	stp	q5, q6, [x4, #512]
	fadd.4s	v2, v2, v3
	fmul.4s	v3, v9, v13
	fmul.4s	v5, v10, v15
	ldp	q16, q6, [x4, #544]
	fadd.4s	v2, v2, v5
	fadd.4s	v3, v4, v3
	bif.16b	v3, v16, v1
	bif.16b	v2, v6, v0
	stp	q3, q2, [x4, #544]
	add	x0, x0, #64
	add	x5, x5, #128
	adds	x24, x24, #2048
	b.ne	LBB0_89
; %bb.90:                               ; %direct.false271
                                        ;   in Loop: Header=BB0_88 Depth=2
	add	x6, x6, #1
	add	x16, x16, #1024
	add	x15, x15, #2048
	cmp	x6, #4
	b.ne	LBB0_88
; %bb.91:                               ; %direct.false267
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q2, [sp, #3680]                 ; 16-byte Reload
	ldr	q3, [sp, #496]                  ; 16-byte Reload
	and.16b	v2, v2, v3
	addv.8h	h4, v2
	fmov	w15, s4
	mov	w0, #1                          ; =0x1
	tbz	w15, #0, LBB0_93
; %bb.92:                               ; %cond.store
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q2, [sp, #160]                  ; 16-byte Reload
	fmov	x16, d2
	strb	w0, [x16]
LBB0_93:                                ; %else
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w15, w15, #0xff
	ldr	q5, [sp, #8784]                 ; 16-byte Reload
	ldr	q6, [sp, #8768]                 ; 16-byte Reload
	ldr	q31, [sp, #10016]               ; 16-byte Reload
	ldr	q9, [sp, #10000]                ; 16-byte Reload
	ldr	q10, [sp, #9984]                ; 16-byte Reload
	ldr	q11, [sp, #9968]                ; 16-byte Reload
	ldr	q12, [sp, #9952]                ; 16-byte Reload
	ldr	q13, [sp, #8720]                ; 16-byte Reload
	ldr	q14, [sp, #8704]                ; 16-byte Reload
	ldr	q15, [sp, #8688]                ; 16-byte Reload
	tbz	w15, #1, LBB0_117
; %bb.94:                               ; %cond.store645
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q2, [sp, #160]                  ; 16-byte Reload
	mov.d	x16, v2[1]
	strb	w0, [x16]
	tbnz	w15, #2, LBB0_118
LBB0_95:                                ; %else648
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #3, LBB0_119
LBB0_96:                                ; %cond.store649
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q2, [sp, #176]                  ; 16-byte Reload
	mov.d	x16, v2[1]
	strb	w0, [x16]
	tbnz	w15, #4, LBB0_120
LBB0_97:                                ; %else652
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #5, LBB0_121
LBB0_98:                                ; %cond.store653
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q2, [sp, #192]                  ; 16-byte Reload
	mov.d	x16, v2[1]
	strb	w0, [x16]
	tbnz	w15, #6, LBB0_122
LBB0_99:                                ; %else656
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #7, LBB0_123
LBB0_100:                               ; %cond.store657
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q2, [sp, #208]                  ; 16-byte Reload
	mov.d	x15, v2[1]
	strb	w0, [x15]
	orr	x1, x9, #0x1
	cmp	x1, #129
	cset	w16, lo
	fmov	w15, s4
	dup.8b	v2, w16
	tbnz	w15, #0, LBB0_124
LBB0_101:                               ; %else662
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w15, w15, #0xff
	tbz	w15, #1, LBB0_125
LBB0_102:                               ; %cond.store663
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3456]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[1], [x16]
	tbnz	w15, #2, LBB0_126
LBB0_103:                               ; %else668
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #3, LBB0_127
LBB0_104:                               ; %cond.store669
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3472]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[3], [x16]
	tbnz	w15, #4, LBB0_128
LBB0_105:                               ; %else674
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #5, LBB0_129
LBB0_106:                               ; %cond.store675
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3488]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[5], [x16]
	tbnz	w15, #6, LBB0_130
LBB0_107:                               ; %else680
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #7, LBB0_109
LBB0_108:                               ; %cond.store681
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3504]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	st1.b	{ v2 }[7], [x15]
LBB0_109:                               ; %else683
                                        ;   in Loop: Header=BB0_28 Depth=1
	orr	x16, x9, #0x2
	orr	x15, x9, #0x2
	str	x15, [sp, #10064]               ; 8-byte Spill
	cmp	x16, #129
	cset	w16, lo
	fmov	w15, s4
	dup.8b	v2, w16
	tbz	w15, #0, LBB0_131
; %bb.110:                              ; %cond.store685
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3392]                 ; 16-byte Reload
	fmov	x16, d3
	str	b2, [x16]
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB0_132
LBB0_111:                               ; %else692
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #2, LBB0_133
LBB0_112:                               ; %cond.store693
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3408]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[2], [x16]
	tbnz	w15, #3, LBB0_134
LBB0_113:                               ; %else700
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #4, LBB0_135
LBB0_114:                               ; %cond.store701
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3424]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[4], [x16]
	tbnz	w15, #5, LBB0_136
LBB0_115:                               ; %else708
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #6, LBB0_137
LBB0_116:                               ; %cond.store709
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3440]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[6], [x16]
	tbnz	w15, #7, LBB0_138
	b	LBB0_139
LBB0_117:                               ; %else646
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #2, LBB0_95
LBB0_118:                               ; %cond.store647
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q2, [sp, #176]                  ; 16-byte Reload
	fmov	x16, d2
	strb	w0, [x16]
	tbnz	w15, #3, LBB0_96
LBB0_119:                               ; %else650
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #4, LBB0_97
LBB0_120:                               ; %cond.store651
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q2, [sp, #192]                  ; 16-byte Reload
	fmov	x16, d2
	strb	w0, [x16]
	tbnz	w15, #5, LBB0_98
LBB0_121:                               ; %else654
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #6, LBB0_99
LBB0_122:                               ; %cond.store655
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q2, [sp, #208]                  ; 16-byte Reload
	fmov	x16, d2
	strb	w0, [x16]
	tbnz	w15, #7, LBB0_100
LBB0_123:                               ; %else658
                                        ;   in Loop: Header=BB0_28 Depth=1
	orr	x1, x9, #0x1
	cmp	x1, #129
	cset	w16, lo
	fmov	w15, s4
	dup.8b	v2, w16
	tbz	w15, #0, LBB0_101
LBB0_124:                               ; %cond.store660
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3456]                 ; 16-byte Reload
	fmov	x16, d3
	str	b2, [x16]
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB0_102
LBB0_125:                               ; %else665
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #2, LBB0_103
LBB0_126:                               ; %cond.store666
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3472]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[2], [x16]
	tbnz	w15, #3, LBB0_104
LBB0_127:                               ; %else671
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #4, LBB0_105
LBB0_128:                               ; %cond.store672
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3488]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[4], [x16]
	tbnz	w15, #5, LBB0_106
LBB0_129:                               ; %else677
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #6, LBB0_107
LBB0_130:                               ; %cond.store678
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3504]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[6], [x16]
	tbnz	w15, #7, LBB0_108
	b	LBB0_109
LBB0_131:                               ; %else688
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w15, w15, #0xff
	tbz	w15, #1, LBB0_111
LBB0_132:                               ; %cond.store689
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3392]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[1], [x16]
	tbnz	w15, #2, LBB0_112
LBB0_133:                               ; %else696
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #3, LBB0_113
LBB0_134:                               ; %cond.store697
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3408]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[3], [x16]
	tbnz	w15, #4, LBB0_114
LBB0_135:                               ; %else704
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #5, LBB0_115
LBB0_136:                               ; %cond.store705
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3424]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[5], [x16]
	tbnz	w15, #6, LBB0_116
LBB0_137:                               ; %else712
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #7, LBB0_139
LBB0_138:                               ; %cond.store713
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3440]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	st1.b	{ v2 }[7], [x15]
LBB0_139:                               ; %else716
                                        ;   in Loop: Header=BB0_28 Depth=1
	orr	x16, x9, #0x3
	orr	x15, x9, #0x3
	str	x15, [sp, #9200]                ; 8-byte Spill
	cmp	x16, #129
	cset	w16, lo
	fmov	w15, s4
	dup.8b	v2, w16
	tbz	w15, #0, LBB0_147
; %bb.140:                              ; %cond.store718
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3328]                 ; 16-byte Reload
	fmov	x16, d3
	str	b2, [x16]
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB0_148
LBB0_141:                               ; %else725
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #2, LBB0_149
LBB0_142:                               ; %cond.store726
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3344]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[2], [x16]
	tbnz	w15, #3, LBB0_150
LBB0_143:                               ; %else733
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #4, LBB0_151
LBB0_144:                               ; %cond.store734
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3360]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[4], [x16]
	tbnz	w15, #5, LBB0_152
LBB0_145:                               ; %else741
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #6, LBB0_153
LBB0_146:                               ; %cond.store742
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3376]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[6], [x16]
	tbnz	w15, #7, LBB0_154
	b	LBB0_155
LBB0_147:                               ; %else721
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w15, w15, #0xff
	tbz	w15, #1, LBB0_141
LBB0_148:                               ; %cond.store722
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3328]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[1], [x16]
	tbnz	w15, #2, LBB0_142
LBB0_149:                               ; %else729
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #3, LBB0_143
LBB0_150:                               ; %cond.store730
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3344]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[3], [x16]
	tbnz	w15, #4, LBB0_144
LBB0_151:                               ; %else737
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #5, LBB0_145
LBB0_152:                               ; %cond.store738
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3360]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[5], [x16]
	tbnz	w15, #6, LBB0_146
LBB0_153:                               ; %else745
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #7, LBB0_155
LBB0_154:                               ; %cond.store746
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3376]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	st1.b	{ v2 }[7], [x15]
LBB0_155:                               ; %else749
                                        ;   in Loop: Header=BB0_28 Depth=1
	orr	x16, x9, #0x4
	orr	x15, x9, #0x4
	str	x15, [sp, #9184]                ; 8-byte Spill
	cmp	x16, #129
	cset	w16, lo
	fmov	w15, s4
	dup.8b	v2, w16
	tbz	w15, #0, LBB0_163
; %bb.156:                              ; %cond.store751
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3264]                 ; 16-byte Reload
	fmov	x16, d3
	str	b2, [x16]
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB0_164
LBB0_157:                               ; %else758
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #2, LBB0_165
LBB0_158:                               ; %cond.store759
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3280]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[2], [x16]
	tbnz	w15, #3, LBB0_166
LBB0_159:                               ; %else766
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #4, LBB0_167
LBB0_160:                               ; %cond.store767
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3296]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[4], [x16]
	tbnz	w15, #5, LBB0_168
LBB0_161:                               ; %else774
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #6, LBB0_169
LBB0_162:                               ; %cond.store775
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3312]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[6], [x16]
	tbnz	w15, #7, LBB0_170
	b	LBB0_171
LBB0_163:                               ; %else754
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w15, w15, #0xff
	tbz	w15, #1, LBB0_157
LBB0_164:                               ; %cond.store755
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3264]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[1], [x16]
	tbnz	w15, #2, LBB0_158
LBB0_165:                               ; %else762
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #3, LBB0_159
LBB0_166:                               ; %cond.store763
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3280]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[3], [x16]
	tbnz	w15, #4, LBB0_160
LBB0_167:                               ; %else770
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #5, LBB0_161
LBB0_168:                               ; %cond.store771
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3296]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[5], [x16]
	tbnz	w15, #6, LBB0_162
LBB0_169:                               ; %else778
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #7, LBB0_171
LBB0_170:                               ; %cond.store779
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3312]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	st1.b	{ v2 }[7], [x15]
LBB0_171:                               ; %else782
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	w15, #5                         ; =0x5
	orr	x15, x9, x15
	str	x15, [sp, #9168]                ; 8-byte Spill
	cmp	x15, #129
	cset	w16, lo
	fmov	w15, s4
	dup.8b	v2, w16
	tbz	w15, #0, LBB0_203
; %bb.172:                              ; %cond.store784
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3200]                 ; 16-byte Reload
	fmov	x16, d3
	str	b2, [x16]
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB0_204
LBB0_173:                               ; %else791
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #2, LBB0_205
LBB0_174:                               ; %cond.store792
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3216]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[2], [x16]
	tbnz	w15, #3, LBB0_206
LBB0_175:                               ; %else799
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #4, LBB0_207
LBB0_176:                               ; %cond.store800
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3232]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[4], [x16]
	tbnz	w15, #5, LBB0_208
LBB0_177:                               ; %else807
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #6, LBB0_209
LBB0_178:                               ; %cond.store808
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3248]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[6], [x16]
	tbnz	w15, #7, LBB0_210
LBB0_179:                               ; %else815
                                        ;   in Loop: Header=BB0_28 Depth=1
	orr	x5, x9, #0x6
	cmp	x5, #129
	cset	w16, lo
	fmov	w15, s4
	dup.8b	v2, w16
	tbz	w15, #0, LBB0_211
LBB0_180:                               ; %cond.store817
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3136]                 ; 16-byte Reload
	fmov	x16, d3
	str	b2, [x16]
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB0_212
LBB0_181:                               ; %else824
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #2, LBB0_213
LBB0_182:                               ; %cond.store825
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3152]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[2], [x16]
	tbnz	w15, #3, LBB0_214
LBB0_183:                               ; %else832
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #4, LBB0_215
LBB0_184:                               ; %cond.store833
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3168]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[4], [x16]
	tbnz	w15, #5, LBB0_216
LBB0_185:                               ; %else840
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #6, LBB0_217
LBB0_186:                               ; %cond.store841
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3184]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[6], [x16]
	tbnz	w15, #7, LBB0_218
LBB0_187:                               ; %else848
                                        ;   in Loop: Header=BB0_28 Depth=1
	orr	x6, x9, #0x7
	cmp	x6, #129
	cset	w16, lo
	fmov	w15, s4
	dup.8b	v2, w16
	tbz	w15, #0, LBB0_219
LBB0_188:                               ; %cond.store850
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3072]                 ; 16-byte Reload
	fmov	x16, d3
	str	b2, [x16]
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB0_220
LBB0_189:                               ; %else857
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #2, LBB0_221
LBB0_190:                               ; %cond.store858
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3088]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[2], [x16]
	tbnz	w15, #3, LBB0_222
LBB0_191:                               ; %else865
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #4, LBB0_223
LBB0_192:                               ; %cond.store866
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3104]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[4], [x16]
	tbnz	w15, #5, LBB0_224
LBB0_193:                               ; %else873
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #6, LBB0_225
LBB0_194:                               ; %cond.store874
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3120]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[6], [x16]
	tbnz	w15, #7, LBB0_226
LBB0_195:                               ; %else881
                                        ;   in Loop: Header=BB0_28 Depth=1
	orr	x7, x9, #0x8
	cmp	x7, #129
	cset	w16, lo
	fmov	w15, s4
	dup.8b	v2, w16
	tbz	w15, #0, LBB0_227
LBB0_196:                               ; %cond.store883
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2976]                 ; 16-byte Reload
	fmov	x16, d3
	str	b2, [x16]
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB0_228
LBB0_197:                               ; %else890
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #2, LBB0_229
LBB0_198:                               ; %cond.store891
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2992]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[2], [x16]
	tbnz	w15, #3, LBB0_230
LBB0_199:                               ; %else898
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #4, LBB0_231
LBB0_200:                               ; %cond.store899
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3008]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[4], [x16]
	tbnz	w15, #5, LBB0_232
LBB0_201:                               ; %else906
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #6, LBB0_233
LBB0_202:                               ; %cond.store907
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3024]                 ; 16-byte Reload
	fmov	x16, d3
	st1.b	{ v2 }[6], [x16]
	tbnz	w15, #7, LBB0_234
	b	LBB0_235
LBB0_203:                               ; %else787
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w15, w15, #0xff
	tbz	w15, #1, LBB0_173
LBB0_204:                               ; %cond.store788
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3200]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[1], [x16]
	tbnz	w15, #2, LBB0_174
LBB0_205:                               ; %else795
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #3, LBB0_175
LBB0_206:                               ; %cond.store796
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3216]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[3], [x16]
	tbnz	w15, #4, LBB0_176
LBB0_207:                               ; %else803
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #5, LBB0_177
LBB0_208:                               ; %cond.store804
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3232]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[5], [x16]
	tbnz	w15, #6, LBB0_178
LBB0_209:                               ; %else811
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #7, LBB0_179
LBB0_210:                               ; %cond.store812
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3248]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	st1.b	{ v2 }[7], [x15]
	orr	x5, x9, #0x6
	cmp	x5, #129
	cset	w16, lo
	fmov	w15, s4
	dup.8b	v2, w16
	tbnz	w15, #0, LBB0_180
LBB0_211:                               ; %else820
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w15, w15, #0xff
	tbz	w15, #1, LBB0_181
LBB0_212:                               ; %cond.store821
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3136]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[1], [x16]
	tbnz	w15, #2, LBB0_182
LBB0_213:                               ; %else828
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #3, LBB0_183
LBB0_214:                               ; %cond.store829
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3152]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[3], [x16]
	tbnz	w15, #4, LBB0_184
LBB0_215:                               ; %else836
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #5, LBB0_185
LBB0_216:                               ; %cond.store837
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3168]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[5], [x16]
	tbnz	w15, #6, LBB0_186
LBB0_217:                               ; %else844
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #7, LBB0_187
LBB0_218:                               ; %cond.store845
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3184]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	st1.b	{ v2 }[7], [x15]
	orr	x6, x9, #0x7
	cmp	x6, #129
	cset	w16, lo
	fmov	w15, s4
	dup.8b	v2, w16
	tbnz	w15, #0, LBB0_188
LBB0_219:                               ; %else853
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w15, w15, #0xff
	tbz	w15, #1, LBB0_189
LBB0_220:                               ; %cond.store854
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3072]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[1], [x16]
	tbnz	w15, #2, LBB0_190
LBB0_221:                               ; %else861
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #3, LBB0_191
LBB0_222:                               ; %cond.store862
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3088]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[3], [x16]
	tbnz	w15, #4, LBB0_192
LBB0_223:                               ; %else869
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #5, LBB0_193
LBB0_224:                               ; %cond.store870
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3104]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[5], [x16]
	tbnz	w15, #6, LBB0_194
LBB0_225:                               ; %else877
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #7, LBB0_195
LBB0_226:                               ; %cond.store878
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3120]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	st1.b	{ v2 }[7], [x15]
	orr	x7, x9, #0x8
	cmp	x7, #129
	cset	w16, lo
	fmov	w15, s4
	dup.8b	v2, w16
	tbnz	w15, #0, LBB0_196
LBB0_227:                               ; %else886
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w15, w15, #0xff
	tbz	w15, #1, LBB0_197
LBB0_228:                               ; %cond.store887
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2976]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[1], [x16]
	tbnz	w15, #2, LBB0_198
LBB0_229:                               ; %else894
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #3, LBB0_199
LBB0_230:                               ; %cond.store895
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2992]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[3], [x16]
	tbnz	w15, #4, LBB0_200
LBB0_231:                               ; %else902
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #5, LBB0_201
LBB0_232:                               ; %cond.store903
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3008]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[5], [x16]
	tbnz	w15, #6, LBB0_202
LBB0_233:                               ; %else910
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w15, #7, LBB0_235
LBB0_234:                               ; %cond.store911
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #3024]                 ; 16-byte Reload
	mov.d	x15, v3[1]
	st1.b	{ v2 }[7], [x15]
LBB0_235:                               ; %else914
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	w15, #9                         ; =0x9
	orr	x15, x9, x15
	cmp	x15, #129
	cset	w0, lo
	fmov	w16, s4
	dup.8b	v2, w0
	tbz	w16, #0, LBB0_243
; %bb.236:                              ; %cond.store916
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2912]                 ; 16-byte Reload
	fmov	x0, d3
	str	b2, [x0]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_244
LBB0_237:                               ; %else923
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #2, LBB0_245
LBB0_238:                               ; %cond.store924
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2928]                 ; 16-byte Reload
	fmov	x0, d3
	st1.b	{ v2 }[2], [x0]
	tbnz	w16, #3, LBB0_246
LBB0_239:                               ; %else931
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #4, LBB0_247
LBB0_240:                               ; %cond.store932
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2944]                 ; 16-byte Reload
	fmov	x0, d3
	st1.b	{ v2 }[4], [x0]
	tbnz	w16, #5, LBB0_248
LBB0_241:                               ; %else939
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #6, LBB0_249
LBB0_242:                               ; %cond.store940
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2960]                 ; 16-byte Reload
	fmov	x0, d3
	st1.b	{ v2 }[6], [x0]
	tbnz	w16, #7, LBB0_250
	b	LBB0_251
LBB0_243:                               ; %else919
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_237
LBB0_244:                               ; %cond.store920
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2912]                 ; 16-byte Reload
	mov.d	x0, v3[1]
	st1.b	{ v2 }[1], [x0]
	tbnz	w16, #2, LBB0_238
LBB0_245:                               ; %else927
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #3, LBB0_239
LBB0_246:                               ; %cond.store928
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2928]                 ; 16-byte Reload
	mov.d	x0, v3[1]
	st1.b	{ v2 }[3], [x0]
	tbnz	w16, #4, LBB0_240
LBB0_247:                               ; %else935
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #5, LBB0_241
LBB0_248:                               ; %cond.store936
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2944]                 ; 16-byte Reload
	mov.d	x0, v3[1]
	st1.b	{ v2 }[5], [x0]
	tbnz	w16, #6, LBB0_242
LBB0_249:                               ; %else943
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #7, LBB0_251
LBB0_250:                               ; %cond.store944
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2960]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[7], [x16]
LBB0_251:                               ; %else947
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	w16, #10                        ; =0xa
	orr	x4, x9, x16
	cmp	x4, #129
	cset	w0, lo
	fmov	w16, s4
	dup.8b	v2, w0
	tbz	w16, #0, LBB0_259
; %bb.252:                              ; %cond.store949
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2848]                 ; 16-byte Reload
	fmov	x0, d3
	str	b2, [x0]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_260
LBB0_253:                               ; %else956
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #2, LBB0_261
LBB0_254:                               ; %cond.store957
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2864]                 ; 16-byte Reload
	fmov	x0, d3
	st1.b	{ v2 }[2], [x0]
	tbnz	w16, #3, LBB0_262
LBB0_255:                               ; %else964
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #4, LBB0_263
LBB0_256:                               ; %cond.store965
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2880]                 ; 16-byte Reload
	fmov	x0, d3
	st1.b	{ v2 }[4], [x0]
	tbnz	w16, #5, LBB0_264
LBB0_257:                               ; %else972
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #6, LBB0_265
LBB0_258:                               ; %cond.store973
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2896]                 ; 16-byte Reload
	fmov	x0, d3
	st1.b	{ v2 }[6], [x0]
	tbnz	w16, #7, LBB0_266
	b	LBB0_267
LBB0_259:                               ; %else952
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_253
LBB0_260:                               ; %cond.store953
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2848]                 ; 16-byte Reload
	mov.d	x0, v3[1]
	st1.b	{ v2 }[1], [x0]
	tbnz	w16, #2, LBB0_254
LBB0_261:                               ; %else960
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #3, LBB0_255
LBB0_262:                               ; %cond.store961
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2864]                 ; 16-byte Reload
	mov.d	x0, v3[1]
	st1.b	{ v2 }[3], [x0]
	tbnz	w16, #4, LBB0_256
LBB0_263:                               ; %else968
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #5, LBB0_257
LBB0_264:                               ; %cond.store969
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2880]                 ; 16-byte Reload
	mov.d	x0, v3[1]
	st1.b	{ v2 }[5], [x0]
	tbnz	w16, #6, LBB0_258
LBB0_265:                               ; %else976
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #7, LBB0_267
LBB0_266:                               ; %cond.store977
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2896]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[7], [x16]
LBB0_267:                               ; %else980
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	w16, #11                        ; =0xb
	orr	x20, x9, x16
	cmp	x20, #129
	cset	w0, lo
	fmov	w16, s4
	dup.8b	v2, w0
	tbz	w16, #0, LBB0_283
; %bb.268:                              ; %cond.store982
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2736]                 ; 16-byte Reload
	fmov	x0, d3
	str	b2, [x0]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_284
LBB0_269:                               ; %else989
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #2, LBB0_285
LBB0_270:                               ; %cond.store990
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2768]                 ; 16-byte Reload
	fmov	x0, d3
	st1.b	{ v2 }[2], [x0]
	tbnz	w16, #3, LBB0_286
LBB0_271:                               ; %else997
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #4, LBB0_287
LBB0_272:                               ; %cond.store998
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2800]                 ; 16-byte Reload
	fmov	x0, d3
	st1.b	{ v2 }[4], [x0]
	tbnz	w16, #5, LBB0_288
LBB0_273:                               ; %else1005
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #6, LBB0_289
LBB0_274:                               ; %cond.store1006
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2832]                 ; 16-byte Reload
	fmov	x0, d3
	st1.b	{ v2 }[6], [x0]
	tbnz	w16, #7, LBB0_290
LBB0_275:                               ; %else1013
                                        ;   in Loop: Header=BB0_28 Depth=1
	orr	x26, x9, #0xc
	cmp	x26, #129
	cset	w0, lo
	fmov	w16, s4
	dup.8b	v2, w0
	tbz	w16, #0, LBB0_291
LBB0_276:                               ; %cond.store1015
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2624]                 ; 16-byte Reload
	fmov	x0, d3
	str	b2, [x0]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_292
LBB0_277:                               ; %else1022
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #2, LBB0_293
LBB0_278:                               ; %cond.store1023
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2656]                 ; 16-byte Reload
	fmov	x0, d3
	st1.b	{ v2 }[2], [x0]
	tbnz	w16, #3, LBB0_294
LBB0_279:                               ; %else1030
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #4, LBB0_295
LBB0_280:                               ; %cond.store1031
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2688]                 ; 16-byte Reload
	fmov	x0, d3
	st1.b	{ v2 }[4], [x0]
	tbnz	w16, #5, LBB0_296
LBB0_281:                               ; %else1038
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #6, LBB0_297
LBB0_282:                               ; %cond.store1039
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2704]                 ; 16-byte Reload
	fmov	x0, d3
	st1.b	{ v2 }[6], [x0]
	tbnz	w16, #7, LBB0_298
	b	LBB0_299
LBB0_283:                               ; %else985
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_269
LBB0_284:                               ; %cond.store986
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2736]                 ; 16-byte Reload
	mov.d	x0, v3[1]
	st1.b	{ v2 }[1], [x0]
	tbnz	w16, #2, LBB0_270
LBB0_285:                               ; %else993
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #3, LBB0_271
LBB0_286:                               ; %cond.store994
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2768]                 ; 16-byte Reload
	mov.d	x0, v3[1]
	st1.b	{ v2 }[3], [x0]
	tbnz	w16, #4, LBB0_272
LBB0_287:                               ; %else1001
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #5, LBB0_273
LBB0_288:                               ; %cond.store1002
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2800]                 ; 16-byte Reload
	mov.d	x0, v3[1]
	st1.b	{ v2 }[5], [x0]
	tbnz	w16, #6, LBB0_274
LBB0_289:                               ; %else1009
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #7, LBB0_275
LBB0_290:                               ; %cond.store1010
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2832]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[7], [x16]
	orr	x26, x9, #0xc
	cmp	x26, #129
	cset	w0, lo
	fmov	w16, s4
	dup.8b	v2, w0
	tbnz	w16, #0, LBB0_276
LBB0_291:                               ; %else1018
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_277
LBB0_292:                               ; %cond.store1019
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2624]                 ; 16-byte Reload
	mov.d	x0, v3[1]
	st1.b	{ v2 }[1], [x0]
	tbnz	w16, #2, LBB0_278
LBB0_293:                               ; %else1026
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #3, LBB0_279
LBB0_294:                               ; %cond.store1027
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2656]                 ; 16-byte Reload
	mov.d	x0, v3[1]
	st1.b	{ v2 }[3], [x0]
	tbnz	w16, #4, LBB0_280
LBB0_295:                               ; %else1034
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #5, LBB0_281
LBB0_296:                               ; %cond.store1035
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2688]                 ; 16-byte Reload
	mov.d	x0, v3[1]
	st1.b	{ v2 }[5], [x0]
	tbnz	w16, #6, LBB0_282
LBB0_297:                               ; %else1042
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #7, LBB0_299
LBB0_298:                               ; %cond.store1043
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2704]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[7], [x16]
LBB0_299:                               ; %else1046
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	w16, #13                        ; =0xd
	orr	x27, x9, x16
	cmp	x27, #129
	cset	w0, lo
	fmov	w16, s4
	dup.8b	v2, w0
	tbz	w16, #0, LBB0_323
; %bb.300:                              ; %cond.store1048
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2496]                 ; 16-byte Reload
	fmov	x0, d3
	str	b2, [x0]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_324
LBB0_301:                               ; %else1055
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #2, LBB0_325
LBB0_302:                               ; %cond.store1056
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2528]                 ; 16-byte Reload
	fmov	x0, d3
	st1.b	{ v2 }[2], [x0]
	tbnz	w16, #3, LBB0_326
LBB0_303:                               ; %else1063
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #4, LBB0_327
LBB0_304:                               ; %cond.store1064
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2560]                 ; 16-byte Reload
	fmov	x0, d3
	st1.b	{ v2 }[4], [x0]
	tbnz	w16, #5, LBB0_328
LBB0_305:                               ; %else1071
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #6, LBB0_329
LBB0_306:                               ; %cond.store1072
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2592]                 ; 16-byte Reload
	fmov	x0, d3
	st1.b	{ v2 }[6], [x0]
	tbnz	w16, #7, LBB0_330
LBB0_307:                               ; %else1079
                                        ;   in Loop: Header=BB0_28 Depth=1
	orr	x16, x9, #0xe
	cmp	x16, #129
	cset	w19, lo
	fmov	w0, s4
	dup.8b	v2, w19
	tbz	w0, #0, LBB0_331
LBB0_308:                               ; %cond.store1081
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2368]                 ; 16-byte Reload
	fmov	x19, d3
	str	b2, [x19]
	and	w0, w0, #0xff
	tbnz	w0, #1, LBB0_332
LBB0_309:                               ; %else1088
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w0, #2, LBB0_333
LBB0_310:                               ; %cond.store1089
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2400]                 ; 16-byte Reload
	fmov	x19, d3
	st1.b	{ v2 }[2], [x19]
	tbnz	w0, #3, LBB0_334
LBB0_311:                               ; %else1096
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w0, #4, LBB0_335
LBB0_312:                               ; %cond.store1097
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2432]                 ; 16-byte Reload
	fmov	x19, d3
	st1.b	{ v2 }[4], [x19]
	tbnz	w0, #5, LBB0_336
LBB0_313:                               ; %else1104
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w0, #6, LBB0_337
LBB0_314:                               ; %cond.store1105
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2464]                 ; 16-byte Reload
	fmov	x19, d3
	st1.b	{ v2 }[6], [x19]
	tbnz	w0, #7, LBB0_338
LBB0_315:                               ; %else1112
                                        ;   in Loop: Header=BB0_28 Depth=1
	orr	x0, x9, #0xf
	cmp	x0, #129
	cset	w19, lo
	fmov	w9, s4
	dup.8b	v2, w19
	tbz	w9, #0, LBB0_339
LBB0_316:                               ; %cond.store1114
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2192]                 ; 16-byte Reload
	fmov	x19, d3
	str	b2, [x19]
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_340
LBB0_317:                               ; %else1121
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w9, #2, LBB0_341
LBB0_318:                               ; %cond.store1122
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2240]                 ; 16-byte Reload
	fmov	x19, d3
	st1.b	{ v2 }[2], [x19]
	tbnz	w9, #3, LBB0_342
LBB0_319:                               ; %else1129
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w9, #4, LBB0_343
LBB0_320:                               ; %cond.store1130
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2288]                 ; 16-byte Reload
	fmov	x19, d3
	st1.b	{ v2 }[4], [x19]
	tbnz	w9, #5, LBB0_344
LBB0_321:                               ; %else1137
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w9, #6, LBB0_345
LBB0_322:                               ; %cond.store1138
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2336]                 ; 16-byte Reload
	fmov	x19, d3
	st1.b	{ v2 }[6], [x19]
	str	q4, [sp, #10080]                ; 16-byte Spill
	str	q17, [sp, #8592]                ; 16-byte Spill
	sshll.2d	v3, v1, #0
	sshll.2d	v4, v0, #0
	tbnz	w9, #7, LBB0_346
	b	LBB0_347
LBB0_323:                               ; %else1051
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_301
LBB0_324:                               ; %cond.store1052
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2496]                 ; 16-byte Reload
	mov.d	x0, v3[1]
	st1.b	{ v2 }[1], [x0]
	tbnz	w16, #2, LBB0_302
LBB0_325:                               ; %else1059
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #3, LBB0_303
LBB0_326:                               ; %cond.store1060
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2528]                 ; 16-byte Reload
	mov.d	x0, v3[1]
	st1.b	{ v2 }[3], [x0]
	tbnz	w16, #4, LBB0_304
LBB0_327:                               ; %else1067
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #5, LBB0_305
LBB0_328:                               ; %cond.store1068
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2560]                 ; 16-byte Reload
	mov.d	x0, v3[1]
	st1.b	{ v2 }[5], [x0]
	tbnz	w16, #6, LBB0_306
LBB0_329:                               ; %else1075
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w16, #7, LBB0_307
LBB0_330:                               ; %cond.store1076
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2592]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	st1.b	{ v2 }[7], [x16]
	orr	x16, x9, #0xe
	cmp	x16, #129
	cset	w19, lo
	fmov	w0, s4
	dup.8b	v2, w19
	tbnz	w0, #0, LBB0_308
LBB0_331:                               ; %else1084
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w0, w0, #0xff
	tbz	w0, #1, LBB0_309
LBB0_332:                               ; %cond.store1085
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2368]                 ; 16-byte Reload
	mov.d	x19, v3[1]
	st1.b	{ v2 }[1], [x19]
	tbnz	w0, #2, LBB0_310
LBB0_333:                               ; %else1092
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w0, #3, LBB0_311
LBB0_334:                               ; %cond.store1093
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2400]                 ; 16-byte Reload
	mov.d	x19, v3[1]
	st1.b	{ v2 }[3], [x19]
	tbnz	w0, #4, LBB0_312
LBB0_335:                               ; %else1100
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w0, #5, LBB0_313
LBB0_336:                               ; %cond.store1101
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2432]                 ; 16-byte Reload
	mov.d	x19, v3[1]
	st1.b	{ v2 }[5], [x19]
	tbnz	w0, #6, LBB0_314
LBB0_337:                               ; %else1108
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w0, #7, LBB0_315
LBB0_338:                               ; %cond.store1109
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2464]                 ; 16-byte Reload
	mov.d	x0, v3[1]
	st1.b	{ v2 }[7], [x0]
	orr	x0, x9, #0xf
	cmp	x0, #129
	cset	w19, lo
	fmov	w9, s4
	dup.8b	v2, w19
	tbnz	w9, #0, LBB0_316
LBB0_339:                               ; %else1117
                                        ;   in Loop: Header=BB0_28 Depth=1
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_317
LBB0_340:                               ; %cond.store1118
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2192]                 ; 16-byte Reload
	mov.d	x19, v3[1]
	st1.b	{ v2 }[1], [x19]
	tbnz	w9, #2, LBB0_318
LBB0_341:                               ; %else1125
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w9, #3, LBB0_319
LBB0_342:                               ; %cond.store1126
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2240]                 ; 16-byte Reload
	mov.d	x19, v3[1]
	st1.b	{ v2 }[3], [x19]
	tbnz	w9, #4, LBB0_320
LBB0_343:                               ; %else1133
                                        ;   in Loop: Header=BB0_28 Depth=1
	tbz	w9, #5, LBB0_321
LBB0_344:                               ; %cond.store1134
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q3, [sp, #2288]                 ; 16-byte Reload
	mov.d	x19, v3[1]
	st1.b	{ v2 }[5], [x19]
	tbnz	w9, #6, LBB0_322
LBB0_345:                               ; %else1141
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q4, [sp, #10080]                ; 16-byte Spill
	str	q17, [sp, #8592]                ; 16-byte Spill
	sshll.2d	v3, v1, #0
	sshll.2d	v4, v0, #0
	tbz	w9, #7, LBB0_347
LBB0_346:                               ; %cond.store1142
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q7, [sp, #2336]                 ; 16-byte Reload
	mov.d	x9, v7[1]
	st1.b	{ v2 }[7], [x9]
LBB0_347:                               ; %else1145
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x9, #0                          ; =0x0
	mov	x19, #0                         ; =0x0
	mov	x24, #0                         ; =0x0
	dup.2d	v16, x1
	ldr	q7, [sp, #3696]                 ; 16-byte Reload
	ldr	q2, [sp, #9904]                 ; 16-byte Reload
	bit.16b	v2, v7, v4
	str	q2, [sp, #9904]                 ; 16-byte Spill
	ldr	x1, [sp, #2616]                 ; 8-byte Reload
	ldp	q27, q18, [x1, #32]
	ldr	q2, [sp, #9936]                 ; 16-byte Reload
	bit.16b	v2, v7, v3
	str	q2, [sp, #9936]                 ; 16-byte Spill
	ldr	q2, [sp, #256]                  ; 16-byte Reload
	ldr	q17, [sp, #9840]                ; 16-byte Reload
	bit.16b	v17, v2, v4
	str	q17, [sp, #9840]                ; 16-byte Spill
	ldr	q2, [sp, #224]                  ; 16-byte Reload
	ldr	q4, [sp, #9872]                 ; 16-byte Reload
	bit.16b	v4, v2, v3
	str	q4, [sp, #9872]                 ; 16-byte Spill
	sshll.2d	v2, v0, #0
	ldp	q28, q4, [x1]
	ldr	q17, [sp, #9216]                ; 16-byte Reload
	bit.16b	v27, v17, v2
	mov.16b	v3, v6
	bsl.16b	v3, v17, v18
	stp	q27, q3, [x1, #32]
	sshll.2d	v3, v1, #0
	mov.16b	v18, v3
	bsl.16b	v18, v17, v28
	bit.16b	v4, v17, v5
	stp	q18, q4, [x1]
	ldr	x1, [sp, #2584]                 ; 8-byte Reload
	ldp	q18, q4, [x1, #32]
	ldp	q28, q27, [x1]
	bit.16b	v28, v16, v3
	bit.16b	v18, v16, v2
	bit.16b	v27, v16, v5
	bit.16b	v4, v16, v6
	ldr	x2, [sp, #10064]                ; 8-byte Reload
	dup.2d	v16, x2
	stp	q18, q4, [x1, #32]
	stp	q28, q27, [x1]
	ldr	x1, [sp, #2576]                 ; 8-byte Reload
	ldp	q18, q4, [x1, #32]
	ldp	q28, q27, [x1]
	bit.16b	v28, v16, v3
	bit.16b	v18, v16, v2
	bit.16b	v27, v16, v5
	bit.16b	v4, v16, v6
	ldr	x2, [sp, #9200]                 ; 8-byte Reload
	dup.2d	v16, x2
	stp	q18, q4, [x1, #32]
	stp	q28, q27, [x1]
	ldr	x1, [sp, #2552]                 ; 8-byte Reload
	ldp	q18, q4, [x1, #32]
	ldp	q28, q27, [x1]
	bit.16b	v28, v16, v3
	bit.16b	v18, v16, v2
	bit.16b	v27, v16, v5
	bit.16b	v4, v16, v6
	stp	q18, q4, [x1, #32]
	stp	q28, q27, [x1]
	ldr	x1, [sp, #9184]                 ; 8-byte Reload
	dup.2d	v4, x1
	ldr	x1, [sp, #2520]                 ; 8-byte Reload
	ldp	q18, q16, [x1, #32]
	ldp	q28, q27, [x1]
	bit.16b	v28, v4, v3
	bit.16b	v18, v4, v2
	bit.16b	v27, v4, v5
	bif.16b	v4, v16, v6
	stp	q18, q4, [x1, #32]
	stp	q28, q27, [x1]
	ldr	x1, [sp, #9168]                 ; 8-byte Reload
	dup.2d	v4, x1
	ldr	x1, [sp, #2512]                 ; 8-byte Reload
	ldp	q18, q16, [x1, #32]
	ldp	q28, q27, [x1]
	bit.16b	v28, v4, v3
	bit.16b	v18, v4, v2
	bit.16b	v27, v4, v5
	bif.16b	v4, v16, v6
	stp	q18, q4, [x1, #32]
	stp	q28, q27, [x1]
	dup.2d	v4, x5
	ldr	x1, [sp, #2488]                 ; 8-byte Reload
	ldp	q18, q16, [x1, #32]
	ldp	q28, q27, [x1]
	bit.16b	v28, v4, v3
	bit.16b	v18, v4, v2
	bit.16b	v27, v4, v5
	bif.16b	v4, v16, v6
	stp	q18, q4, [x1, #32]
	stp	q28, q27, [x1]
	dup.2d	v4, x6
	ldr	x1, [sp, #2456]                 ; 8-byte Reload
	ldp	q18, q16, [x1, #32]
	ldp	q28, q27, [x1]
	bit.16b	v28, v4, v3
	bit.16b	v18, v4, v2
	bit.16b	v27, v4, v5
	bif.16b	v4, v16, v6
	stp	q18, q4, [x1, #32]
	stp	q28, q27, [x1]
	dup.2d	v4, x7
	ldr	x1, [sp, #2448]                 ; 8-byte Reload
	ldp	q18, q16, [x1, #32]
	ldp	q28, q27, [x1]
	bit.16b	v28, v4, v3
	bit.16b	v18, v4, v2
	bit.16b	v27, v4, v5
	bif.16b	v4, v16, v6
	stp	q18, q4, [x1, #32]
	stp	q28, q27, [x1]
	dup.2d	v4, x15
	ldr	x15, [sp, #2424]                ; 8-byte Reload
	ldp	q18, q16, [x15, #32]
	ldp	q28, q27, [x15]
	bit.16b	v28, v4, v3
	bit.16b	v27, v4, v5
	bit.16b	v18, v4, v2
	bif.16b	v4, v16, v6
	stp	q18, q4, [x15, #32]
	stp	q28, q27, [x15]
	dup.2d	v4, x4
	ldr	x15, [sp, #2392]                ; 8-byte Reload
	ldp	q16, q18, [x15, #32]
	ldp	q27, q28, [x15]
	bit.16b	v28, v4, v5
	bit.16b	v27, v4, v3
	bit.16b	v18, v4, v6
	bif.16b	v4, v16, v2
	stp	q4, q18, [x15, #32]
	stp	q27, q28, [x15]
	dup.2d	v4, x20
	ldr	x15, [sp, #2384]                ; 8-byte Reload
	ldp	q16, q18, [x15, #32]
	ldp	q27, q28, [x15]
	bit.16b	v28, v4, v5
	bit.16b	v27, v4, v3
	bit.16b	v18, v4, v6
	bif.16b	v4, v16, v2
	stp	q4, q18, [x15, #32]
	stp	q27, q28, [x15]
	dup.2d	v4, x26
	ldr	x15, [sp, #2360]                ; 8-byte Reload
	ldp	q18, q16, [x15, #32]
	ldp	q28, q27, [x15]
	bit.16b	v28, v4, v3
	bit.16b	v27, v4, v5
	bit.16b	v18, v4, v2
	bif.16b	v4, v16, v6
	stp	q18, q4, [x15, #32]
	stp	q28, q27, [x15]
	dup.2d	v4, x27
	ldr	x15, [sp, #2328]                ; 8-byte Reload
	ldp	q18, q16, [x15, #32]
	ldp	q28, q27, [x15]
	bit.16b	v28, v4, v3
	bit.16b	v27, v4, v5
	bit.16b	v18, v4, v2
	bif.16b	v4, v16, v6
	stp	q18, q4, [x15, #32]
	stp	q28, q27, [x15]
	dup.2d	v4, x16
	ldr	x15, [sp, #2320]                ; 8-byte Reload
	ldp	q18, q16, [x15, #32]
	ldp	q28, q27, [x15]
	bit.16b	v28, v4, v3
	bit.16b	v27, v4, v5
	bit.16b	v18, v4, v2
	bif.16b	v4, v16, v6
	stp	q18, q4, [x15, #32]
	stp	q28, q27, [x15]
	dup.2d	v4, x0
	ldr	x15, [sp, #2312]                ; 8-byte Reload
	ldp	q18, q16, [x15, #32]
	ldp	q28, q27, [x15]
	bit.16b	v28, v4, v3
	bit.16b	v27, v4, v5
	bit.16b	v18, v4, v2
	bif.16b	v4, v16, v6
	stp	q18, q4, [x15, #32]
	stp	q28, q27, [x15]
	ldr	x15, [sp, #2280]                ; 8-byte Reload
	ldp	q16, q4, [x15, #32]
	ldr	q17, [sp, #2144]                ; 16-byte Reload
	bit.16b	v16, v17, v2
	ldr	q17, [sp, #2096]                ; 16-byte Reload
	bit.16b	v4, v17, v6
	stp	q16, q4, [x15, #32]
	ldp	q16, q4, [x15]
	ldr	q17, [sp, #2112]                ; 16-byte Reload
	bit.16b	v16, v17, v3
	ldr	q17, [sp, #2128]                ; 16-byte Reload
	bit.16b	v4, v17, v5
	stp	q16, q4, [x15]
	ldr	x15, [sp, #2272]                ; 8-byte Reload
	ldp	q16, q4, [x15, #32]
	ldr	q17, [sp, #2016]                ; 16-byte Reload
	bit.16b	v16, v17, v2
	ldr	q17, [sp, #1968]                ; 16-byte Reload
	bit.16b	v4, v17, v6
	stp	q16, q4, [x15, #32]
	ldp	q16, q4, [x15]
	ldr	q17, [sp, #1984]                ; 16-byte Reload
	bit.16b	v16, v17, v3
	ldr	q17, [sp, #2000]                ; 16-byte Reload
	bit.16b	v4, v17, v5
	stp	q16, q4, [x15]
	ldr	x15, [sp, #2264]                ; 8-byte Reload
	ldp	q16, q4, [x15, #32]
	ldr	q17, [sp, #1920]                ; 16-byte Reload
	bit.16b	v16, v17, v2
	ldr	q17, [sp, #1872]                ; 16-byte Reload
	bit.16b	v4, v17, v6
	stp	q16, q4, [x15, #32]
	ldp	q16, q4, [x15]
	ldr	q17, [sp, #1888]                ; 16-byte Reload
	bit.16b	v16, v17, v3
	ldr	q17, [sp, #1904]                ; 16-byte Reload
	bit.16b	v4, v17, v5
	stp	q16, q4, [x15]
	ldr	x15, [sp, #2232]                ; 8-byte Reload
	ldp	q16, q4, [x15, #32]
	ldr	q17, [sp, #1792]                ; 16-byte Reload
	bit.16b	v16, v17, v2
	ldr	q17, [sp, #1744]                ; 16-byte Reload
	bit.16b	v4, v17, v6
	stp	q16, q4, [x15, #32]
	ldp	q16, q4, [x15]
	ldr	q17, [sp, #1760]                ; 16-byte Reload
	bit.16b	v16, v17, v3
	ldr	q17, [sp, #1776]                ; 16-byte Reload
	bit.16b	v4, v17, v5
	stp	q16, q4, [x15]
	ldr	x15, [sp, #2224]                ; 8-byte Reload
	ldp	q16, q4, [x15, #32]
	ldr	q17, [sp, #1696]                ; 16-byte Reload
	bit.16b	v16, v17, v2
	ldr	q17, [sp, #1648]                ; 16-byte Reload
	bit.16b	v4, v17, v6
	stp	q16, q4, [x15, #32]
	ldp	q16, q4, [x15]
	ldr	q17, [sp, #1664]                ; 16-byte Reload
	bit.16b	v16, v17, v3
	ldr	q17, [sp, #1680]                ; 16-byte Reload
	bit.16b	v4, v17, v5
	stp	q16, q4, [x15]
	ldr	x15, [sp, #2216]                ; 8-byte Reload
	ldp	q16, q4, [x15, #32]
	ldr	q17, [sp, #1568]                ; 16-byte Reload
	bit.16b	v16, v17, v2
	ldr	q17, [sp, #1520]                ; 16-byte Reload
	bit.16b	v4, v17, v6
	stp	q16, q4, [x15, #32]
	ldp	q16, q4, [x15]
	ldr	q17, [sp, #1536]                ; 16-byte Reload
	bit.16b	v16, v17, v3
	ldr	q17, [sp, #1552]                ; 16-byte Reload
	bit.16b	v4, v17, v5
	stp	q16, q4, [x15]
	ldr	x15, [sp, #2208]                ; 8-byte Reload
	ldp	q16, q4, [x15, #32]
	ldr	q17, [sp, #1472]                ; 16-byte Reload
	bit.16b	v16, v17, v2
	ldr	q17, [sp, #1424]                ; 16-byte Reload
	bit.16b	v4, v17, v6
	stp	q16, q4, [x15, #32]
	ldr	q4, [x15]
	ldr	q17, [sp, #1440]                ; 16-byte Reload
	bit.16b	v4, v17, v3
	ldr	x16, [sp, #2184]                ; 8-byte Reload
	ldr	q16, [x16, #32]
	ldr	q17, [sp, #1344]                ; 16-byte Reload
	bit.16b	v16, v17, v2
	ldr	q17, [sp, #3552]                ; 16-byte Reload
	bit.16b	v11, v17, v2
	ldr	q28, [sp, #10032]               ; 16-byte Reload
	ldr	q18, [sp, #528]                 ; 16-byte Reload
	bit.16b	v28, v18, v2
	ldr	q2, [x16]
	ldr	q18, [sp, #1312]                ; 16-byte Reload
	bit.16b	v2, v18, v3
	bit.16b	v9, v17, v3
	ldr	q18, [sp, #512]                 ; 16-byte Reload
	bit.16b	v19, v18, v3
	ldr	q3, [x15, #16]
	ldr	q18, [sp, #1456]                ; 16-byte Reload
	bit.16b	v3, v18, v5
	stp	q4, q3, [x15]
	ldr	q3, [x16, #48]
	ldr	q4, [sp, #1296]                 ; 16-byte Reload
	bit.16b	v3, v4, v6
	stp	q16, q3, [x16, #32]
	ldr	q3, [x16, #16]
	ldr	q4, [sp, #1328]                 ; 16-byte Reload
	bit.16b	v3, v4, v5
	stp	q2, q3, [x16]
	ldr	q2, [sp, #9888]                 ; 16-byte Reload
	bit.16b	v2, v7, v6
	str	q2, [sp, #9888]                 ; 16-byte Spill
	ldr	q2, [sp, #9920]                 ; 16-byte Reload
	bit.16b	v2, v7, v5
	str	q2, [sp, #9920]                 ; 16-byte Spill
	ldr	q2, [sp, #272]                  ; 16-byte Reload
	ldr	q3, [sp, #9824]                 ; 16-byte Reload
	bit.16b	v3, v2, v6
	str	q3, [sp, #9824]                 ; 16-byte Spill
	ldr	q2, [sp, #240]                  ; 16-byte Reload
	ldr	q3, [sp, #9856]                 ; 16-byte Reload
	bit.16b	v3, v2, v5
	str	q3, [sp, #9856]                 ; 16-byte Spill
	bit.16b	v12, v17, v6
	bit.16b	v10, v17, v5
	ldr	q2, [sp, #480]                  ; 16-byte Reload
	bit.16b	v31, v2, v6
	ldr	q17, [sp, #10048]               ; 16-byte Reload
	ldr	q2, [sp, #544]                  ; 16-byte Reload
	bit.16b	v17, v2, v5
	ldr	d7, [sp, #1288]                 ; 8-byte Reload
	mov	w4, #1267                       ; =0x4f3
	movk	w4, #15925, lsl #16
	mov	w5, #48782                      ; =0xbe8e
	movk	w5, #46527, lsl #16
	ldr	q27, [sp, #10080]               ; 16-byte Reload
	b	LBB0_349
LBB0_348:                               ; %else1209
                                        ;   in Loop: Header=BB0_349 Depth=2
	add	x24, x24, #1
	add	x19, x19, #8
	add	x9, x9, #64
	cmp	x24, #128
	b.eq	LBB0_381
LBB0_349:                               ; %direct.true1072
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w15, s27
	lsr	x16, x24, #3
	dup.2d	v3, x16
	ldr	q2, [sp, #9872]                 ; 16-byte Reload
	orr.16b	v2, v3, v2
	ldr	q4, [sp, #9936]                 ; 16-byte Reload
	add.2d	v4, v4, v2
	tbz	w15, #0, LBB0_351
; %bb.350:                              ; %cond.load
                                        ;   in Loop: Header=BB0_349 Depth=2
	fmov	x16, d4
	ldr	b2, [x16]
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB0_352
	b	LBB0_353
LBB0_351:                               ;   in Loop: Header=BB0_349 Depth=2
	movi.2d	v2, #0000000000000000
	and	w15, w15, #0xff
	tbz	w15, #1, LBB0_353
LBB0_352:                               ; %cond.load1149
                                        ;   in Loop: Header=BB0_349 Depth=2
	mov.d	x16, v4[1]
	ld1.b	{ v2 }[1], [x16]
LBB0_353:                               ; %else1151
                                        ;   in Loop: Header=BB0_349 Depth=2
	ldr	q4, [sp, #9856]                 ; 16-byte Reload
	orr.16b	v4, v3, v4
	ldr	q5, [sp, #9920]                 ; 16-byte Reload
	add.2d	v4, v5, v4
	tbz	w15, #2, LBB0_359
; %bb.354:                              ; %cond.load1153
                                        ;   in Loop: Header=BB0_349 Depth=2
	fmov	x16, d4
	ld1.b	{ v2 }[2], [x16]
	tbnz	w15, #3, LBB0_360
LBB0_355:                               ; %else1159
                                        ;   in Loop: Header=BB0_349 Depth=2
	ldr	q4, [sp, #9840]                 ; 16-byte Reload
	orr.16b	v4, v3, v4
	ldr	q5, [sp, #9904]                 ; 16-byte Reload
	add.2d	v4, v5, v4
	tbz	w15, #4, LBB0_361
LBB0_356:                               ; %cond.load1161
                                        ;   in Loop: Header=BB0_349 Depth=2
	fmov	x16, d4
	ld1.b	{ v2 }[4], [x16]
	tbnz	w15, #5, LBB0_362
LBB0_357:                               ; %else1167
                                        ;   in Loop: Header=BB0_349 Depth=2
	ldr	q4, [sp, #9824]                 ; 16-byte Reload
	orr.16b	v3, v3, v4
	ldr	q4, [sp, #9888]                 ; 16-byte Reload
	add.2d	v3, v4, v3
	tbz	w15, #6, LBB0_363
LBB0_358:                               ; %cond.load1169
                                        ;   in Loop: Header=BB0_349 Depth=2
	fmov	x16, d3
	ld1.b	{ v2 }[6], [x16]
	tbnz	w15, #7, LBB0_364
	b	LBB0_365
LBB0_359:                               ; %else1155
                                        ;   in Loop: Header=BB0_349 Depth=2
	tbz	w15, #3, LBB0_355
LBB0_360:                               ; %cond.load1157
                                        ;   in Loop: Header=BB0_349 Depth=2
	mov.d	x16, v4[1]
	ld1.b	{ v2 }[3], [x16]
	ldr	q4, [sp, #9840]                 ; 16-byte Reload
	orr.16b	v4, v3, v4
	ldr	q5, [sp, #9904]                 ; 16-byte Reload
	add.2d	v4, v5, v4
	tbnz	w15, #4, LBB0_356
LBB0_361:                               ; %else1163
                                        ;   in Loop: Header=BB0_349 Depth=2
	tbz	w15, #5, LBB0_357
LBB0_362:                               ; %cond.load1165
                                        ;   in Loop: Header=BB0_349 Depth=2
	mov.d	x16, v4[1]
	ld1.b	{ v2 }[5], [x16]
	ldr	q4, [sp, #9824]                 ; 16-byte Reload
	orr.16b	v3, v3, v4
	ldr	q4, [sp, #9888]                 ; 16-byte Reload
	add.2d	v3, v4, v3
	tbnz	w15, #6, LBB0_358
LBB0_363:                               ; %else1171
                                        ;   in Loop: Header=BB0_349 Depth=2
	tbz	w15, #7, LBB0_365
LBB0_364:                               ; %cond.load1173
                                        ;   in Loop: Header=BB0_349 Depth=2
	mov.d	x15, v3[1]
	ld1.b	{ v2 }[7], [x15]
LBB0_365:                               ; %else1175
                                        ;   in Loop: Header=BB0_349 Depth=2
	fmov	w15, s27
	cmeq.8b	v2, v2, #0
	and	x16, x19, #0x3c0
	add	x16, x30, x16
	ldp	q3, q4, [x16]
	ldp	q5, q6, [x16, #32]
	and	x16, x9, #0x1c0
	add	x16, x10, x16
	ldp	q16, q18, [x16]
	ldp	q20, q27, [x16, #32]
	cmge.2d	v6, v27, v6
	cmge.2d	v5, v20, v5
	uzp1.4s	v5, v5, v6
	cmge.2d	v4, v18, v4
	cmge.2d	v3, v16, v3
	uzp1.4s	v3, v3, v4
	uzp1.8h	v3, v3, v5
	xtn.8b	v3, v3
	orr.8b	v3, v7, v3
	bic.8b	v2, v3, v2
	dup.2d	v3, x24
	orr.16b	v4, v3, v19
	add.2d	v4, v9, v4
	movi.8b	v5, #1
	and.8b	v2, v2, v5
	tbz	w15, #0, LBB0_373
; %bb.366:                              ; %cond.store1178
                                        ;   in Loop: Header=BB0_349 Depth=2
	fmov	x16, d4
	str	b2, [x16]
	and	w15, w15, #0xff
	ldr	q16, [sp, #9792]                ; 16-byte Reload
	ldr	q18, [sp, #9776]                ; 16-byte Reload
	ldr	q20, [sp, #9760]                ; 16-byte Reload
	tbnz	w15, #1, LBB0_374
LBB0_367:                               ; %else1185
                                        ;   in Loop: Header=BB0_349 Depth=2
	orr.16b	v4, v3, v17
	add.2d	v4, v10, v4
	ldr	q27, [sp, #10080]               ; 16-byte Reload
	tbz	w15, #2, LBB0_375
LBB0_368:                               ; %cond.store1186
                                        ;   in Loop: Header=BB0_349 Depth=2
	fmov	x16, d4
	st1.b	{ v2 }[2], [x16]
	tbnz	w15, #3, LBB0_376
LBB0_369:                               ; %else1193
                                        ;   in Loop: Header=BB0_349 Depth=2
	orr.16b	v4, v3, v28
	add.2d	v4, v11, v4
	tbz	w15, #4, LBB0_377
LBB0_370:                               ; %cond.store1194
                                        ;   in Loop: Header=BB0_349 Depth=2
	fmov	x16, d4
	st1.b	{ v2 }[4], [x16]
	tbnz	w15, #5, LBB0_378
LBB0_371:                               ; %else1201
                                        ;   in Loop: Header=BB0_349 Depth=2
	orr.16b	v3, v3, v31
	add.2d	v3, v12, v3
	tbz	w15, #6, LBB0_379
LBB0_372:                               ; %cond.store1202
                                        ;   in Loop: Header=BB0_349 Depth=2
	fmov	x16, d3
	st1.b	{ v2 }[6], [x16]
	tbz	w15, #7, LBB0_348
	b	LBB0_380
LBB0_373:                               ; %else1181
                                        ;   in Loop: Header=BB0_349 Depth=2
	and	w15, w15, #0xff
	ldr	q16, [sp, #9792]                ; 16-byte Reload
	ldr	q18, [sp, #9776]                ; 16-byte Reload
	ldr	q20, [sp, #9760]                ; 16-byte Reload
	tbz	w15, #1, LBB0_367
LBB0_374:                               ; %cond.store1182
                                        ;   in Loop: Header=BB0_349 Depth=2
	mov.d	x16, v4[1]
	st1.b	{ v2 }[1], [x16]
	orr.16b	v4, v3, v17
	add.2d	v4, v10, v4
	ldr	q27, [sp, #10080]               ; 16-byte Reload
	tbnz	w15, #2, LBB0_368
LBB0_375:                               ; %else1189
                                        ;   in Loop: Header=BB0_349 Depth=2
	tbz	w15, #3, LBB0_369
LBB0_376:                               ; %cond.store1190
                                        ;   in Loop: Header=BB0_349 Depth=2
	mov.d	x16, v4[1]
	st1.b	{ v2 }[3], [x16]
	orr.16b	v4, v3, v28
	add.2d	v4, v11, v4
	tbnz	w15, #4, LBB0_370
LBB0_377:                               ; %else1197
                                        ;   in Loop: Header=BB0_349 Depth=2
	tbz	w15, #5, LBB0_371
LBB0_378:                               ; %cond.store1198
                                        ;   in Loop: Header=BB0_349 Depth=2
	mov.d	x16, v4[1]
	st1.b	{ v2 }[5], [x16]
	orr.16b	v3, v3, v31
	add.2d	v3, v12, v3
	tbnz	w15, #6, LBB0_372
LBB0_379:                               ; %else1205
                                        ;   in Loop: Header=BB0_349 Depth=2
	tbz	w15, #7, LBB0_348
LBB0_380:                               ; %cond.store1206
                                        ;   in Loop: Header=BB0_349 Depth=2
	mov.d	x15, v3[1]
	st1.b	{ v2 }[7], [x15]
	b	LBB0_348
LBB0_381:                               ; %direct.true1095.preheader
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x9, #0                          ; =0x0
	mov	x15, #-128                      ; =0xffffffffffffff80
	add	x16, x8, #18, lsl #12           ; =73728
	ldr	x10, [sp, #3536]                ; 8-byte Reload
	ldr	q7, [sp, #8736]                 ; 16-byte Reload
	b	LBB0_383
LBB0_382:                               ; %else1257
                                        ;   in Loop: Header=BB0_383 Depth=2
	cmeq.8b	v2, v2, #0
	sshll.8h	v2, v2, #0
	sshll2.4s	v3, v2, #0
	sshll.4s	v2, v2, #0
	ldp	q5, q4, [x16]
	dup.4s	v6, w4
	fmul.4s	v5, v5, v6
	fmul.4s	v4, v4, v6
	and.16b	v4, v0, v4
	and.16b	v5, v1, v5
	ldr	q6, [sp, #9680]                 ; 16-byte Reload
	bsl.16b	v2, v6, v5
	bsl.16b	v3, v6, v4
	ldr	q4, [x16, #6784]
	ldr	q5, [x16, #6800]
	bif.16b	v3, v5, v0
	bif.16b	v2, v4, v1
	str	q2, [x16, #6784]
	str	q3, [x16, #6800]
	add	x9, x9, #8
	add	x16, x16, #32
	adds	x15, x15, #1
	b.hs	LBB0_399
LBB0_383:                               ; %direct.true1095
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w0, s27
	add	x1, x15, #128
	and	x2, x9, #0x78
	orr	x1, x2, x1, lsr #4
	dup.2d	v3, x1
	orr.16b	v2, v3, v19
	add.2d	v4, v9, v2
	tbz	w0, #0, LBB0_385
; %bb.384:                              ; %cond.load1211
                                        ;   in Loop: Header=BB0_383 Depth=2
	fmov	x1, d4
	ldr	b2, [x1]
	and	w0, w0, #0xff
	tbnz	w0, #1, LBB0_386
	b	LBB0_387
LBB0_385:                               ;   in Loop: Header=BB0_383 Depth=2
	movi.2d	v2, #0000000000000000
	and	w0, w0, #0xff
	tbz	w0, #1, LBB0_387
LBB0_386:                               ; %cond.load1217
                                        ;   in Loop: Header=BB0_383 Depth=2
	mov.d	x1, v4[1]
	ld1.b	{ v2 }[1], [x1]
LBB0_387:                               ; %else1221
                                        ;   in Loop: Header=BB0_383 Depth=2
	orr.16b	v4, v3, v17
	add.2d	v4, v10, v4
	tbz	w0, #2, LBB0_393
; %bb.388:                              ; %cond.load1223
                                        ;   in Loop: Header=BB0_383 Depth=2
	fmov	x1, d4
	ld1.b	{ v2 }[2], [x1]
	tbnz	w0, #3, LBB0_394
LBB0_389:                               ; %else1233
                                        ;   in Loop: Header=BB0_383 Depth=2
	orr.16b	v4, v3, v28
	add.2d	v4, v11, v4
	tbz	w0, #4, LBB0_395
LBB0_390:                               ; %cond.load1235
                                        ;   in Loop: Header=BB0_383 Depth=2
	fmov	x1, d4
	ld1.b	{ v2 }[4], [x1]
	tbnz	w0, #5, LBB0_396
LBB0_391:                               ; %else1245
                                        ;   in Loop: Header=BB0_383 Depth=2
	orr.16b	v3, v3, v31
	add.2d	v3, v12, v3
	tbz	w0, #6, LBB0_397
LBB0_392:                               ; %cond.load1247
                                        ;   in Loop: Header=BB0_383 Depth=2
	fmov	x1, d3
	ld1.b	{ v2 }[6], [x1]
	tbz	w0, #7, LBB0_382
	b	LBB0_398
LBB0_393:                               ; %else1227
                                        ;   in Loop: Header=BB0_383 Depth=2
	tbz	w0, #3, LBB0_389
LBB0_394:                               ; %cond.load1229
                                        ;   in Loop: Header=BB0_383 Depth=2
	mov.d	x1, v4[1]
	ld1.b	{ v2 }[3], [x1]
	orr.16b	v4, v3, v28
	add.2d	v4, v11, v4
	tbnz	w0, #4, LBB0_390
LBB0_395:                               ; %else1239
                                        ;   in Loop: Header=BB0_383 Depth=2
	tbz	w0, #5, LBB0_391
LBB0_396:                               ; %cond.load1241
                                        ;   in Loop: Header=BB0_383 Depth=2
	mov.d	x1, v4[1]
	ld1.b	{ v2 }[5], [x1]
	orr.16b	v3, v3, v31
	add.2d	v3, v12, v3
	tbnz	w0, #6, LBB0_392
LBB0_397:                               ; %else1251
                                        ;   in Loop: Header=BB0_383 Depth=2
	tbz	w0, #7, LBB0_382
LBB0_398:                               ; %cond.load1253
                                        ;   in Loop: Header=BB0_383 Depth=2
	mov.d	x0, v3[1]
	ld1.b	{ v2 }[7], [x0]
	b	LBB0_382
LBB0_399:                               ; %direct.false1096
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x9, #0                          ; =0x0
	mvni.4s	v2, #127, msl #16
	bit.16b	v7, v2, v0
	ldr	q4, [sp, #8752]                 ; 16-byte Reload
	bit.16b	v4, v2, v1
LBB0_400:                               ; %direct.true1115
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x15, x28, x9
	ldp	q2, q3, [x15]
	and.16b	v3, v0, v3
	and.16b	v2, v1, v2
	fmaxnm.4s	v2, v4, v2
	fmaxnm.4s	v3, v7, v3
	bit.16b	v7, v3, v0
	bit.16b	v4, v2, v1
	add	x9, x9, #32
	cmp	x9, #512
	b.ne	LBB0_400
; %bb.401:                              ; %direct.false1116
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x9, #0                          ; =0x0
	mvni.4s	v2, #127, msl #16
	bit.16b	v20, v2, v0
	bit.16b	v18, v2, v1
	ldr	x16, [sp, #2824]                ; 8-byte Reload
LBB0_402:                               ; %direct.true1127
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x15, x16, x9
	ldp	q2, q3, [x15]
	and.16b	v3, v0, v3
	and.16b	v2, v1, v2
	fmaxnm.4s	v2, v18, v2
	fmaxnm.4s	v3, v20, v3
	bit.16b	v20, v3, v0
	bit.16b	v18, v2, v1
	add	x9, x9, #32
	cmp	x9, #512
	b.ne	LBB0_402
; %bb.403:                              ; %direct.false1128
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x9, #0                          ; =0x0
	mvni.4s	v2, #127, msl #16
	bit.16b	v16, v2, v0
	bit.16b	v15, v2, v1
	ldr	x16, [sp, #2792]                ; 8-byte Reload
LBB0_404:                               ; %direct.true1139
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x15, x16, x9
	ldp	q2, q3, [x15]
	and.16b	v3, v0, v3
	and.16b	v2, v1, v2
	fmaxnm.4s	v2, v15, v2
	fmaxnm.4s	v3, v16, v3
	bit.16b	v16, v3, v0
	bit.16b	v15, v2, v1
	add	x9, x9, #32
	cmp	x9, #512
	b.ne	LBB0_404
; %bb.405:                              ; %direct.false1140
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x9, #0                          ; =0x0
	mvni.4s	v2, #127, msl #16
	bit.16b	v14, v2, v0
	bit.16b	v13, v2, v1
	ldr	x16, [sp, #2760]                ; 8-byte Reload
LBB0_406:                               ; %direct.true1151
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x15, x16, x9
	ldp	q2, q3, [x15]
	and.16b	v3, v0, v3
	and.16b	v2, v1, v2
	fmaxnm.4s	v2, v13, v2
	fmaxnm.4s	v3, v14, v3
	bit.16b	v14, v3, v0
	bit.16b	v13, v2, v1
	add	x9, x9, #32
	cmp	x9, #512
	b.ne	LBB0_406
; %bb.407:                              ; %direct.false1152
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x9, #0                          ; =0x0
	mvni.4s	v2, #127, msl #16
	bit.16b	v21, v2, v0
	bit.16b	v24, v2, v1
	ldr	x16, [sp, #2752]                ; 8-byte Reload
LBB0_408:                               ; %direct.true1163
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x15, x16, x9
	ldp	q2, q3, [x15]
	and.16b	v3, v0, v3
	and.16b	v2, v1, v2
	fmaxnm.4s	v2, v24, v2
	fmaxnm.4s	v3, v21, v3
	bit.16b	v21, v3, v0
	bit.16b	v24, v2, v1
	add	x9, x9, #32
	cmp	x9, #512
	b.ne	LBB0_408
; %bb.409:                              ; %direct.false1164
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x9, #0                          ; =0x0
	mvni.4s	v2, #127, msl #16
	bit.16b	v22, v2, v0
	bit.16b	v26, v2, v1
	ldr	x16, [sp, #2728]                ; 8-byte Reload
LBB0_410:                               ; %direct.true1175
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x15, x16, x9
	ldp	q2, q3, [x15]
	and.16b	v3, v0, v3
	and.16b	v2, v1, v2
	fmaxnm.4s	v2, v26, v2
	fmaxnm.4s	v3, v22, v3
	bit.16b	v22, v3, v0
	bit.16b	v26, v2, v1
	add	x9, x9, #32
	cmp	x9, #512
	b.ne	LBB0_410
; %bb.411:                              ; %direct.false1176
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	x9, #0                          ; =0x0
	mvni.4s	v2, #127, msl #16
	bit.16b	v25, v2, v0
	bit.16b	v23, v2, v1
LBB0_412:                               ; %direct.true1187
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x15, x11, x9
	ldp	q2, q3, [x15]
	and.16b	v3, v0, v3
	and.16b	v2, v1, v2
	fmaxnm.4s	v2, v23, v2
	fmaxnm.4s	v3, v25, v3
	bit.16b	v25, v3, v0
	bit.16b	v23, v2, v1
	add	x9, x9, #32
	cmp	x9, #512
	b.ne	LBB0_412
; %bb.413:                              ; %direct.false1188
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q25, [sp, #9216]                ; 16-byte Spill
	mov.16b	v6, v21
	mov.16b	v5, v24
	str	q12, [sp, #9952]                ; 16-byte Spill
	str	q11, [sp, #9968]                ; 16-byte Spill
	str	q10, [sp, #9984]                ; 16-byte Spill
	str	q9, [sp, #10000]                ; 16-byte Spill
	str	q31, [sp, #10016]               ; 16-byte Spill
	str	q28, [sp, #10032]               ; 16-byte Spill
	mov	x9, #0                          ; =0x0
	mvni.4s	v2, #127, msl #16
	bit.16b	v30, v2, v0
	bit.16b	v29, v2, v1
LBB0_414:                               ; %direct.true1199
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x15, x13, x9
	ldp	q2, q3, [x15]
	and.16b	v3, v0, v3
	and.16b	v2, v1, v2
	fmaxnm.4s	v2, v29, v2
	fmaxnm.4s	v3, v30, v3
	bit.16b	v30, v3, v0
	bit.16b	v29, v2, v1
	add	x9, x9, #32
	cmp	x9, #512
	b.ne	LBB0_414
; %bb.415:                              ; %direct.false1200
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q17, [sp, #10048]               ; 16-byte Spill
	str	q19, [sp, #10064]               ; 16-byte Spill
	mov	x9, #0                          ; =0x0
	mov	x6, #0                          ; =0x0
	str	q4, [sp, #8752]                 ; 16-byte Spill
	ldr	q19, [sp, #9248]                ; 16-byte Reload
	fmaxnm.4s	v31, v19, v4
	str	q7, [sp, #8736]                 ; 16-byte Spill
	ldr	q21, [sp, #9232]                ; 16-byte Reload
	fmaxnm.4s	v7, v21, v7
	str	q18, [sp, #9776]                ; 16-byte Spill
	ldr	q2, [sp, #9472]                 ; 16-byte Reload
	fmaxnm.4s	v17, v2, v18
	str	q20, [sp, #9760]                ; 16-byte Spill
	ldr	q2, [sp, #9456]                 ; 16-byte Reload
	fmaxnm.4s	v25, v2, v20
	str	q15, [sp, #8688]                ; 16-byte Spill
	ldr	q2, [sp, #9504]                 ; 16-byte Reload
	fmaxnm.4s	v4, v2, v15
	str	q4, [sp, #9168]                 ; 16-byte Spill
	str	q16, [sp, #9792]                ; 16-byte Spill
	ldr	q2, [sp, #9488]                 ; 16-byte Reload
	fmaxnm.4s	v12, v2, v16
	str	q12, [sp, #9072]                ; 16-byte Spill
	str	q13, [sp, #8720]                ; 16-byte Spill
	ldr	q2, [sp, #9536]                 ; 16-byte Reload
	fmaxnm.4s	v16, v2, v13
	str	q16, [sp, #9152]                ; 16-byte Spill
	str	q14, [sp, #8704]                ; 16-byte Spill
	ldr	q2, [sp, #9520]                 ; 16-byte Reload
	fmaxnm.4s	v10, v2, v14
	str	q10, [sp, #9056]                ; 16-byte Spill
	str	q5, [sp, #7888]                 ; 16-byte Spill
	ldr	q2, [sp, #9568]                 ; 16-byte Reload
	fmaxnm.4s	v20, v2, v5
	str	q20, [sp, #9136]                ; 16-byte Spill
	str	q6, [sp, #8576]                 ; 16-byte Spill
	ldr	q2, [sp, #9552]                 ; 16-byte Reload
	fmaxnm.4s	v18, v2, v6
	str	q18, [sp, #9040]                ; 16-byte Spill
	ldr	q2, [sp, #9600]                 ; 16-byte Reload
	fmaxnm.4s	v28, v2, v26
	str	q28, [sp, #9120]                ; 16-byte Spill
	ldr	q2, [sp, #9584]                 ; 16-byte Reload
	fmaxnm.4s	v27, v2, v22
	str	q27, [sp, #9024]                ; 16-byte Spill
	str	q23, [sp, #8608]                ; 16-byte Spill
	ldr	q2, [sp, #9632]                 ; 16-byte Reload
	fmaxnm.4s	v24, v2, v23
	str	q24, [sp, #9104]                ; 16-byte Spill
	ldr	q2, [sp, #9616]                 ; 16-byte Reload
	ldr	q3, [sp, #9216]                 ; 16-byte Reload
	fmaxnm.4s	v9, v2, v3
	str	q9, [sp, #9008]                 ; 16-byte Spill
	ldr	q2, [sp, #9648]                 ; 16-byte Reload
	fmaxnm.4s	v23, v2, v29
	str	q23, [sp, #9088]                ; 16-byte Spill
	ldr	q2, [sp, #9664]                 ; 16-byte Reload
	fmaxnm.4s	v11, v2, v30
	str	q11, [sp, #8992]                ; 16-byte Spill
	ldr	x15, [sp, #2176]                ; 8-byte Reload
	ldp	q2, q3, [x15]
	bit.16b	v3, v7, v0
	bit.16b	v2, v31, v1
	stp	q2, q3, [x15]
	ldr	x15, [sp, #2168]                ; 8-byte Reload
	ldp	q2, q3, [x15]
	bit.16b	v3, v25, v0
	mov.16b	v14, v25
	bit.16b	v2, v17, v1
	mov.16b	v25, v17
	stp	q2, q3, [x15]
	ldr	x15, [sp, #2088]                ; 8-byte Reload
	ldp	q2, q3, [x15]
	bit.16b	v3, v12, v0
	bit.16b	v2, v4, v1
	ldr	x16, [sp, #2080]                ; 8-byte Reload
	ldp	q4, q5, [x16]
	bit.16b	v5, v10, v0
	mov.16b	v6, v1
	bsl.16b	v6, v16, v4
	ldr	x0, [sp, #2072]                 ; 8-byte Reload
	ldp	q4, q16, [x0]
	bit.16b	v16, v18, v0
	mov.16b	v18, v1
	bsl.16b	v18, v20, v4
	ldr	x1, [sp, #2064]                 ; 8-byte Reload
	ldp	q4, q20, [x1]
	bit.16b	v20, v27, v0
	mov.16b	v27, v1
	bsl.16b	v27, v28, v4
	ldr	x2, [sp, #2056]                 ; 8-byte Reload
	ldp	q4, q28, [x2]
	bif.16b	v9, v28, v0
	mov.16b	v10, v1
	bsl.16b	v10, v24, v4
	ldr	x4, [sp, #2048]                 ; 8-byte Reload
	ldp	q4, q28, [x4]
	bif.16b	v11, v28, v0
	mov.16b	v12, v1
	bsl.16b	v12, v23, v4
	str	q7, [sp, #7840]                 ; 16-byte Spill
	fsub.4s	v28, v21, v7
	stp	q2, q3, [x15]
	str	q31, [sp, #7872]                ; 16-byte Spill
	fsub.4s	v2, v19, v31
	and.16b	v4, v1, v2
	mov	w15, #-1026555904               ; =0xc2d00000
	dup.4s	v31, w15
	and.16b	v28, v0, v28
	fcmge.4s	v3, v28, v31
	mov	w15, #1120403456                ; =0x42c80000
	dup.4s	v2, w15
	stp	q6, q5, [x16]
	fcmge.4s	v5, v4, v31
	fcmge.4s	v6, v2, v28
	fcmge.4s	v13, v2, v4
	stp	q18, q16, [x0]
	and.16b	v5, v5, v13
	and.16b	v3, v3, v6
	and.16b	v6, v3, v28
	mov	w15, #43579                     ; =0xaa3b
	movk	w15, #16312, lsl #16
	dup.4s	v16, w15
	stp	q27, q20, [x1]
	and.16b	v5, v5, v4
	fmul.4s	v3, v5, v16
	fmul.4s	v18, v6, v16
	stp	q10, q9, [x2]
	movi.4s	v7, #75, lsl #24
	mvni.4s	v19, #128, lsl #24
	mov.16b	v20, v19
	bsl.16b	v20, v7, v18
	mov.16b	v27, v19
	bsl.16b	v27, v7, v3
	fadd.4s	v3, v3, v27
	stp	q12, q11, [x4]
	fadd.4s	v18, v18, v20
	fsub.4s	v18, v18, v20
	fsub.4s	v3, v3, v27
	fcvtzs.4s	v3, v3
	fcvtzs.4s	v18, v18
	scvtf.4s	v20, v18
	mov	w15, #29184                     ; =0x7200
	movk	w15, #16177, lsl #16
	dup.4s	v24, w15
	scvtf.4s	v27, v3
	fmul.4s	v9, v27, v24
	fmul.4s	v10, v20, v24
	fsub.4s	v6, v6, v10
	mov	w15, #48782                     ; =0xbe8e
	movk	w15, #13759, lsl #16
	dup.4s	v21, w15
	fsub.4s	v5, v5, v9
	fmul.4s	v20, v20, v21
	fmul.4s	v27, v27, v21
	fsub.4s	v5, v5, v27
	mov	w15, #11226                     ; =0x2bda
	movk	w15, #14672, lsl #16
	dup.4s	v9, w15
	fsub.4s	v6, v6, v20
	fmul.4s	v20, v6, v9
	mov	w15, #38601                     ; =0x96c9
	movk	w15, #15030, lsl #16
	dup.4s	v10, w15
	fadd.4s	v20, v20, v10
	fmul.4s	v20, v6, v20
	mov	w15, #34982                     ; =0x88a6
	movk	w15, #15368, lsl #16
	dup.4s	v11, w15
	fadd.4s	v20, v20, v11
	fmul.4s	v20, v6, v20
	mov	w15, #43642                     ; =0xaa7a
	movk	w15, #15658, lsl #16
	dup.4s	v12, w15
	fadd.4s	v20, v20, v12
	fmul.4s	v20, v6, v20
	mov	w15, #43691                     ; =0xaaab
	movk	w15, #15914, lsl #16
	dup.4s	v15, w15
	fadd.4s	v20, v20, v15
	fmul.4s	v20, v6, v20
	movi.4s	v7, #63, lsl #24
	fadd.4s	v20, v20, v7
	movi.4s	v23, #63, lsl #24
	fmul.4s	v27, v6, v6
	fmul.4s	v20, v27, v20
	fmul.4s	v27, v5, v9
	fadd.4s	v27, v27, v10
	fmul.4s	v27, v5, v27
	fadd.4s	v27, v27, v11
	fmul.4s	v27, v5, v27
	fadd.4s	v27, v27, v12
	fmul.4s	v27, v5, v27
	fadd.4s	v27, v27, v15
	fmul.4s	v27, v5, v27
	fadd.4s	v27, v27, v23
	fmul.4s	v13, v5, v5
	fmul.4s	v27, v13, v27
	fadd.4s	v5, v5, v27
	fadd.4s	v6, v6, v20
	fmov.4s	v19, #1.00000000
	fadd.4s	v5, v5, v19
	sshr.4s	v20, v3, #1
	shl.4s	v27, v20, #23
	add.4s	v27, v27, v19
	fmul.4s	v5, v5, v27
	fadd.4s	v6, v6, v19
	sshr.4s	v27, v18, #1
	shl.4s	v13, v27, #23
	add.4s	v13, v13, v19
	fmul.4s	v6, v6, v13
	sub.4s	v3, v3, v20
	sub.4s	v18, v18, v27
	shl.4s	v18, v18, #23
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v19
	add.4s	v18, v18, v19
	fmul.4s	v6, v6, v18
	fmul.4s	v3, v5, v3
	fcmgt.4s	v5, v31, v4
	bic.16b	v5, v3, v5
	fcmgt.4s	v3, v31, v28
	bic.16b	v6, v6, v3
	fcmgt.4s	v18, v28, v2
	mvni.4s	v3, #127, msl #16
	fneg.4s	v3, v3
	bit.16b	v6, v3, v18
	fcmgt.4s	v18, v4, v2
	bit.16b	v5, v3, v18
	str	q14, [sp, #7824]                ; 16-byte Spill
	ldr	q17, [sp, #9456]                ; 16-byte Reload
	fsub.4s	v18, v17, v14
	fcmeq.4s	v20, v28, v28
	fcmeq.4s	v4, v4, v4
	ldr	q7, [sp, #9808]                 ; 16-byte Reload
	bsl.16b	v4, v5, v7
	str	q4, [sp, #9200]                 ; 16-byte Spill
	mov.16b	v4, v20
	bsl.16b	v4, v6, v7
	str	q4, [sp, #9184]                 ; 16-byte Spill
	and.16b	v4, v0, v18
	fcmge.4s	v5, v4, v31
	fcmge.4s	v6, v2, v4
	and.16b	v5, v5, v6
	str	q25, [sp, #7856]                ; 16-byte Spill
	ldr	q17, [sp, #9472]                ; 16-byte Reload
	fsub.4s	v6, v17, v25
	and.16b	v27, v1, v6
	fcmge.4s	v6, v27, v31
	fcmge.4s	v18, v2, v27
	and.16b	v6, v6, v18
	and.16b	v6, v6, v27
	fmul.4s	v18, v6, v16
	mvni.4s	v17, #128, lsl #24
	movi.4s	v25, #75, lsl #24
	mov.16b	v20, v17
	bsl.16b	v20, v25, v18
	fadd.4s	v18, v18, v20
	fsub.4s	v18, v18, v20
	and.16b	v5, v5, v4
	fmul.4s	v20, v5, v16
	mov.16b	v28, v17
	bsl.16b	v28, v25, v20
	fadd.4s	v20, v20, v28
	fsub.4s	v20, v20, v28
	fcvtzs.4s	v18, v18
	scvtf.4s	v28, v18
	fmul.4s	v13, v28, v24
	fsub.4s	v6, v6, v13
	fcvtzs.4s	v20, v20
	scvtf.4s	v13, v20
	fmul.4s	v14, v13, v24
	fsub.4s	v5, v5, v14
	fmul.4s	v13, v13, v21
	fsub.4s	v5, v5, v13
	fmul.4s	v28, v28, v21
	fsub.4s	v6, v6, v28
	fmul.4s	v28, v6, v9
	fadd.4s	v28, v28, v10
	fmul.4s	v28, v6, v28
	fadd.4s	v28, v28, v11
	fmul.4s	v28, v6, v28
	fadd.4s	v28, v28, v12
	fmul.4s	v28, v6, v28
	fadd.4s	v28, v28, v15
	fmul.4s	v28, v6, v28
	fadd.4s	v28, v28, v23
	fmul.4s	v13, v6, v6
	fmul.4s	v28, v13, v28
	fmul.4s	v13, v5, v9
	fadd.4s	v13, v13, v10
	fmul.4s	v13, v5, v13
	fadd.4s	v13, v13, v11
	fmul.4s	v13, v5, v13
	fadd.4s	v13, v13, v12
	fmul.4s	v13, v5, v13
	fadd.4s	v13, v13, v15
	fmul.4s	v13, v5, v13
	fadd.4s	v13, v13, v23
	fmul.4s	v14, v5, v5
	fmul.4s	v13, v14, v13
	fadd.4s	v5, v5, v13
	fadd.4s	v6, v6, v28
	fadd.4s	v5, v5, v19
	sshr.4s	v28, v20, #1
	shl.4s	v13, v28, #23
	add.4s	v13, v13, v19
	fmul.4s	v5, v5, v13
	fadd.4s	v6, v6, v19
	sshr.4s	v13, v18, #1
	shl.4s	v14, v13, #23
	add.4s	v14, v14, v19
	fmul.4s	v6, v6, v14
	sub.4s	v20, v20, v28
	sub.4s	v18, v18, v13
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v19
	fmul.4s	v6, v6, v18
	shl.4s	v18, v20, #23
	add.4s	v18, v18, v19
	fmul.4s	v5, v5, v18
	fcmgt.4s	v18, v31, v4
	bic.16b	v5, v5, v18
	fcmgt.4s	v18, v31, v27
	bic.16b	v6, v6, v18
	fcmgt.4s	v18, v27, v2
	bit.16b	v6, v3, v18
	fcmgt.4s	v18, v4, v2
	bit.16b	v5, v3, v18
	fcmeq.4s	v4, v4, v4
	bsl.16b	v4, v5, v7
	str	q4, [sp, #8976]                 ; 16-byte Spill
	fcmeq.4s	v4, v27, v27
	bsl.16b	v4, v6, v7
	str	q4, [sp, #8960]                 ; 16-byte Spill
	ldr	q5, [sp, #9488]                 ; 16-byte Reload
	ldr	q4, [sp, #9072]                 ; 16-byte Reload
	fsub.4s	v4, v5, v4
	and.16b	v4, v0, v4
	fcmge.4s	v5, v4, v31
	fcmge.4s	v6, v2, v4
	and.16b	v5, v5, v6
	ldr	q17, [sp, #9504]                ; 16-byte Reload
	ldr	q6, [sp, #9168]                 ; 16-byte Reload
	fsub.4s	v6, v17, v6
	and.16b	v27, v1, v6
	fcmge.4s	v6, v27, v31
	fcmge.4s	v18, v2, v27
	and.16b	v6, v6, v18
	and.16b	v6, v6, v27
	fmul.4s	v18, v6, v16
	mvni.4s	v17, #128, lsl #24
	movi.4s	v23, #75, lsl #24
	mov.16b	v20, v17
	bsl.16b	v20, v23, v18
	fadd.4s	v18, v18, v20
	fsub.4s	v18, v18, v20
	and.16b	v5, v5, v4
	fmul.4s	v20, v5, v16
	mov.16b	v28, v17
	bsl.16b	v28, v23, v20
	mvni.4s	v23, #128, lsl #24
	fadd.4s	v20, v20, v28
	fsub.4s	v20, v20, v28
	fcvtzs.4s	v18, v18
	scvtf.4s	v28, v18
	fmul.4s	v13, v28, v24
	fsub.4s	v6, v6, v13
	fcvtzs.4s	v20, v20
	scvtf.4s	v13, v20
	fmul.4s	v14, v13, v24
	fsub.4s	v5, v5, v14
	fmul.4s	v13, v13, v21
	fsub.4s	v5, v5, v13
	fmul.4s	v28, v28, v21
	fsub.4s	v6, v6, v28
	fmul.4s	v28, v6, v9
	fadd.4s	v28, v28, v10
	fmul.4s	v28, v6, v28
	fadd.4s	v28, v28, v11
	fmul.4s	v28, v6, v28
	fadd.4s	v28, v28, v12
	fmul.4s	v28, v6, v28
	fadd.4s	v28, v28, v15
	fmul.4s	v28, v6, v28
	movi.4s	v17, #63, lsl #24
	fadd.4s	v28, v28, v17
	fmul.4s	v13, v6, v6
	fmul.4s	v28, v13, v28
	fmul.4s	v13, v5, v9
	fadd.4s	v13, v13, v10
	fmul.4s	v13, v5, v13
	fadd.4s	v13, v13, v11
	fmul.4s	v13, v5, v13
	fadd.4s	v13, v13, v12
	fmul.4s	v13, v5, v13
	fadd.4s	v13, v13, v15
	fmul.4s	v13, v5, v13
	fadd.4s	v13, v13, v17
	fmul.4s	v14, v5, v5
	fmul.4s	v13, v14, v13
	fadd.4s	v5, v5, v13
	fadd.4s	v6, v6, v28
	fadd.4s	v5, v5, v19
	sshr.4s	v28, v20, #1
	shl.4s	v13, v28, #23
	add.4s	v13, v13, v19
	fmul.4s	v5, v5, v13
	fadd.4s	v6, v6, v19
	sshr.4s	v13, v18, #1
	shl.4s	v14, v13, #23
	add.4s	v14, v14, v19
	fmul.4s	v6, v6, v14
	sub.4s	v20, v20, v28
	sub.4s	v18, v18, v13
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v19
	fmul.4s	v6, v6, v18
	shl.4s	v18, v20, #23
	add.4s	v18, v18, v19
	fmul.4s	v5, v5, v18
	fcmgt.4s	v18, v31, v4
	bic.16b	v5, v5, v18
	fcmgt.4s	v18, v31, v27
	bic.16b	v6, v6, v18
	fcmgt.4s	v18, v27, v2
	bit.16b	v6, v3, v18
	fcmgt.4s	v18, v4, v2
	bit.16b	v5, v3, v18
	fcmeq.4s	v4, v4, v4
	bsl.16b	v4, v5, v7
	str	q4, [sp, #8944]                 ; 16-byte Spill
	fcmeq.4s	v4, v27, v27
	bsl.16b	v4, v6, v7
	str	q4, [sp, #8928]                 ; 16-byte Spill
	ldr	q5, [sp, #9520]                 ; 16-byte Reload
	ldr	q4, [sp, #9056]                 ; 16-byte Reload
	fsub.4s	v4, v5, v4
	and.16b	v4, v0, v4
	fcmge.4s	v5, v4, v31
	fcmge.4s	v6, v2, v4
	and.16b	v5, v5, v6
	ldr	q17, [sp, #9536]                ; 16-byte Reload
	ldr	q6, [sp, #9152]                 ; 16-byte Reload
	fsub.4s	v6, v17, v6
	and.16b	v27, v1, v6
	fcmge.4s	v6, v27, v31
	fcmge.4s	v18, v2, v27
	and.16b	v6, v6, v18
	and.16b	v6, v6, v27
	fmul.4s	v18, v6, v16
	mov.16b	v20, v23
	bsl.16b	v20, v25, v18
	fadd.4s	v18, v18, v20
	fsub.4s	v18, v18, v20
	and.16b	v5, v5, v4
	fmul.4s	v20, v5, v16
	mov.16b	v28, v23
	bsl.16b	v28, v25, v20
	fadd.4s	v20, v20, v28
	fsub.4s	v20, v20, v28
	fcvtzs.4s	v18, v18
	scvtf.4s	v28, v18
	fmul.4s	v13, v28, v24
	fsub.4s	v6, v6, v13
	fcvtzs.4s	v20, v20
	scvtf.4s	v13, v20
	fmul.4s	v14, v13, v24
	fsub.4s	v5, v5, v14
	fmul.4s	v13, v13, v21
	fsub.4s	v5, v5, v13
	fmul.4s	v28, v28, v21
	fsub.4s	v6, v6, v28
	fmul.4s	v28, v6, v9
	fadd.4s	v28, v28, v10
	fmul.4s	v28, v6, v28
	fadd.4s	v28, v28, v11
	fmul.4s	v28, v6, v28
	fadd.4s	v28, v28, v12
	fmul.4s	v28, v6, v28
	fadd.4s	v28, v28, v15
	fmul.4s	v28, v6, v28
	movi.4s	v17, #63, lsl #24
	fadd.4s	v28, v28, v17
	fmul.4s	v13, v6, v6
	fmul.4s	v28, v13, v28
	fmul.4s	v13, v5, v9
	fadd.4s	v13, v13, v10
	fmul.4s	v13, v5, v13
	fadd.4s	v13, v13, v11
	fmul.4s	v13, v5, v13
	fadd.4s	v13, v13, v12
	fmul.4s	v13, v5, v13
	fadd.4s	v13, v13, v15
	fmul.4s	v13, v5, v13
	fadd.4s	v13, v13, v17
	fmul.4s	v14, v5, v5
	fmul.4s	v13, v14, v13
	fadd.4s	v5, v5, v13
	fadd.4s	v6, v6, v28
	fadd.4s	v5, v5, v19
	sshr.4s	v28, v20, #1
	shl.4s	v13, v28, #23
	add.4s	v13, v13, v19
	fmul.4s	v5, v5, v13
	fadd.4s	v6, v6, v19
	sshr.4s	v13, v18, #1
	shl.4s	v14, v13, #23
	add.4s	v14, v14, v19
	fmul.4s	v6, v6, v14
	sub.4s	v20, v20, v28
	sub.4s	v18, v18, v13
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v19
	fmul.4s	v6, v6, v18
	shl.4s	v18, v20, #23
	add.4s	v18, v18, v19
	fmul.4s	v5, v5, v18
	fcmgt.4s	v18, v31, v4
	bic.16b	v5, v5, v18
	fcmgt.4s	v18, v31, v27
	bic.16b	v6, v6, v18
	fcmgt.4s	v18, v27, v2
	bit.16b	v6, v3, v18
	fcmgt.4s	v18, v4, v2
	bit.16b	v5, v3, v18
	fcmeq.4s	v4, v4, v4
	bsl.16b	v4, v5, v7
	str	q4, [sp, #8912]                 ; 16-byte Spill
	fcmeq.4s	v4, v27, v27
	bsl.16b	v4, v6, v7
	str	q4, [sp, #8896]                 ; 16-byte Spill
	ldr	q5, [sp, #9552]                 ; 16-byte Reload
	ldr	q4, [sp, #9040]                 ; 16-byte Reload
	fsub.4s	v4, v5, v4
	and.16b	v4, v0, v4
	fcmge.4s	v5, v4, v31
	fcmge.4s	v6, v2, v4
	and.16b	v5, v5, v6
	ldr	q17, [sp, #9568]                ; 16-byte Reload
	ldr	q6, [sp, #9136]                 ; 16-byte Reload
	fsub.4s	v6, v17, v6
	and.16b	v27, v1, v6
	fcmge.4s	v6, v27, v31
	fcmge.4s	v18, v2, v27
	and.16b	v6, v6, v18
	and.16b	v6, v6, v27
	fmul.4s	v18, v6, v16
	mvni.4s	v17, #128, lsl #24
	movi.4s	v23, #75, lsl #24
	mov.16b	v20, v17
	bsl.16b	v20, v23, v18
	fadd.4s	v18, v18, v20
	fsub.4s	v18, v18, v20
	and.16b	v5, v5, v4
	fmul.4s	v20, v5, v16
	mov.16b	v28, v17
	bsl.16b	v28, v23, v20
	mvni.4s	v23, #128, lsl #24
	fadd.4s	v20, v20, v28
	fsub.4s	v20, v20, v28
	fcvtzs.4s	v18, v18
	scvtf.4s	v28, v18
	fmul.4s	v13, v28, v24
	fsub.4s	v6, v6, v13
	fcvtzs.4s	v20, v20
	scvtf.4s	v13, v20
	fmul.4s	v14, v13, v24
	fsub.4s	v5, v5, v14
	fmul.4s	v13, v13, v21
	fsub.4s	v5, v5, v13
	fmul.4s	v28, v28, v21
	fsub.4s	v6, v6, v28
	fmul.4s	v28, v6, v9
	fadd.4s	v28, v28, v10
	fmul.4s	v28, v6, v28
	fadd.4s	v28, v28, v11
	fmul.4s	v28, v6, v28
	fadd.4s	v28, v28, v12
	fmul.4s	v28, v6, v28
	fadd.4s	v28, v28, v15
	fmul.4s	v28, v6, v28
	movi.4s	v17, #63, lsl #24
	fadd.4s	v28, v28, v17
	fmul.4s	v13, v6, v6
	fmul.4s	v28, v13, v28
	fmul.4s	v13, v5, v9
	fadd.4s	v13, v13, v10
	fmul.4s	v13, v5, v13
	fadd.4s	v13, v13, v11
	fmul.4s	v13, v5, v13
	fadd.4s	v13, v13, v12
	fmul.4s	v13, v5, v13
	fadd.4s	v13, v13, v15
	fmul.4s	v13, v5, v13
	fadd.4s	v13, v13, v17
	fmul.4s	v14, v5, v5
	fmul.4s	v13, v14, v13
	fadd.4s	v5, v5, v13
	fadd.4s	v6, v6, v28
	fadd.4s	v5, v5, v19
	sshr.4s	v28, v20, #1
	shl.4s	v13, v28, #23
	add.4s	v13, v13, v19
	fmul.4s	v5, v5, v13
	fadd.4s	v6, v6, v19
	sshr.4s	v13, v18, #1
	shl.4s	v14, v13, #23
	add.4s	v14, v14, v19
	fmul.4s	v6, v6, v14
	sub.4s	v20, v20, v28
	sub.4s	v18, v18, v13
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v19
	fmul.4s	v6, v6, v18
	shl.4s	v18, v20, #23
	add.4s	v18, v18, v19
	fmul.4s	v5, v5, v18
	fcmgt.4s	v18, v31, v4
	bic.16b	v5, v5, v18
	fcmgt.4s	v18, v31, v27
	bic.16b	v6, v6, v18
	fcmgt.4s	v18, v27, v2
	bit.16b	v6, v3, v18
	fcmgt.4s	v18, v4, v2
	bit.16b	v5, v3, v18
	fcmeq.4s	v4, v4, v4
	bsl.16b	v4, v5, v7
	str	q4, [sp, #8880]                 ; 16-byte Spill
	fcmeq.4s	v4, v27, v27
	bsl.16b	v4, v6, v7
	str	q4, [sp, #8864]                 ; 16-byte Spill
	ldr	q5, [sp, #9600]                 ; 16-byte Reload
	ldr	q4, [sp, #9120]                 ; 16-byte Reload
	fsub.4s	v4, v5, v4
	and.16b	v4, v1, v4
	fcmge.4s	v5, v4, v31
	fcmge.4s	v6, v2, v4
	and.16b	v5, v5, v6
	ldr	q17, [sp, #9584]                ; 16-byte Reload
	ldr	q6, [sp, #9024]                 ; 16-byte Reload
	fsub.4s	v6, v17, v6
	and.16b	v27, v0, v6
	fcmge.4s	v6, v27, v31
	fcmge.4s	v18, v2, v27
	and.16b	v6, v6, v18
	and.16b	v6, v6, v27
	fmul.4s	v18, v6, v16
	mov.16b	v20, v23
	bsl.16b	v20, v25, v18
	fadd.4s	v18, v18, v20
	fsub.4s	v18, v18, v20
	and.16b	v5, v5, v4
	fmul.4s	v20, v5, v16
	mov.16b	v28, v23
	bsl.16b	v28, v25, v20
	fadd.4s	v20, v20, v28
	fsub.4s	v20, v20, v28
	fcvtzs.4s	v18, v18
	scvtf.4s	v28, v18
	fmul.4s	v13, v28, v24
	fsub.4s	v6, v6, v13
	fcvtzs.4s	v20, v20
	scvtf.4s	v13, v20
	fmul.4s	v14, v13, v24
	fsub.4s	v5, v5, v14
	fmul.4s	v13, v13, v21
	fsub.4s	v5, v5, v13
	fmul.4s	v28, v28, v21
	fsub.4s	v6, v6, v28
	fmul.4s	v28, v6, v9
	fadd.4s	v28, v28, v10
	fmul.4s	v28, v6, v28
	fadd.4s	v28, v28, v11
	fmul.4s	v28, v6, v28
	fadd.4s	v28, v28, v12
	fmul.4s	v28, v6, v28
	fadd.4s	v28, v28, v15
	fmul.4s	v28, v6, v28
	movi.4s	v17, #63, lsl #24
	fadd.4s	v28, v28, v17
	fmul.4s	v13, v6, v6
	fmul.4s	v28, v13, v28
	fmul.4s	v13, v5, v9
	fadd.4s	v13, v13, v10
	fmul.4s	v13, v5, v13
	fadd.4s	v13, v13, v11
	fmul.4s	v13, v5, v13
	fadd.4s	v13, v13, v12
	fmul.4s	v13, v5, v13
	fadd.4s	v13, v13, v15
	fmul.4s	v13, v5, v13
	fadd.4s	v13, v13, v17
	fmul.4s	v14, v5, v5
	fmul.4s	v13, v14, v13
	fadd.4s	v5, v5, v13
	fadd.4s	v6, v6, v28
	fadd.4s	v5, v5, v19
	sshr.4s	v28, v20, #1
	shl.4s	v13, v28, #23
	add.4s	v13, v13, v19
	fmul.4s	v5, v5, v13
	fadd.4s	v6, v6, v19
	sshr.4s	v13, v18, #1
	shl.4s	v14, v13, #23
	add.4s	v14, v14, v19
	fmul.4s	v6, v6, v14
	sub.4s	v20, v20, v28
	sub.4s	v18, v18, v13
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v19
	fmul.4s	v6, v6, v18
	shl.4s	v18, v20, #23
	add.4s	v18, v18, v19
	fmul.4s	v5, v5, v18
	fcmgt.4s	v18, v31, v4
	bic.16b	v5, v5, v18
	fcmgt.4s	v18, v31, v27
	bic.16b	v6, v6, v18
	fcmgt.4s	v18, v27, v2
	bit.16b	v6, v3, v18
	fcmgt.4s	v18, v4, v2
	bit.16b	v5, v3, v18
	fcmeq.4s	v4, v4, v4
	bsl.16b	v4, v5, v7
	str	q4, [sp, #8848]                 ; 16-byte Spill
	fcmeq.4s	v4, v27, v27
	bsl.16b	v4, v6, v7
	str	q4, [sp, #8832]                 ; 16-byte Spill
	ldr	q5, [sp, #9616]                 ; 16-byte Reload
	ldr	q4, [sp, #9008]                 ; 16-byte Reload
	fsub.4s	v4, v5, v4
	and.16b	v4, v0, v4
	fcmge.4s	v5, v4, v31
	fcmge.4s	v6, v2, v4
	and.16b	v5, v5, v6
	ldr	q17, [sp, #9632]                ; 16-byte Reload
	ldr	q6, [sp, #9104]                 ; 16-byte Reload
	fsub.4s	v6, v17, v6
	and.16b	v27, v1, v6
	fcmge.4s	v6, v27, v31
	fcmge.4s	v18, v2, v27
	and.16b	v6, v6, v18
	and.16b	v6, v6, v27
	fmul.4s	v18, v6, v16
	mvni.4s	v17, #128, lsl #24
	movi.4s	v23, #75, lsl #24
	mov.16b	v20, v17
	bsl.16b	v20, v23, v18
	fadd.4s	v18, v18, v20
	fsub.4s	v18, v18, v20
	and.16b	v5, v5, v4
	fmul.4s	v20, v5, v16
	mov.16b	v28, v17
	bsl.16b	v28, v23, v20
	fadd.4s	v20, v20, v28
	fsub.4s	v20, v20, v28
	fcvtzs.4s	v18, v18
	scvtf.4s	v28, v18
	fmul.4s	v13, v28, v24
	fsub.4s	v6, v6, v13
	fcvtzs.4s	v20, v20
	scvtf.4s	v13, v20
	fmul.4s	v14, v13, v24
	fsub.4s	v5, v5, v14
	fmul.4s	v13, v13, v21
	fsub.4s	v5, v5, v13
	fmul.4s	v28, v28, v21
	fsub.4s	v6, v6, v28
	fmul.4s	v28, v6, v9
	fadd.4s	v28, v28, v10
	fmul.4s	v28, v6, v28
	fadd.4s	v28, v28, v11
	fmul.4s	v28, v6, v28
	fadd.4s	v28, v28, v12
	fmul.4s	v28, v6, v28
	fadd.4s	v28, v28, v15
	fmul.4s	v28, v6, v28
	movi.4s	v17, #63, lsl #24
	fadd.4s	v28, v28, v17
	fmul.4s	v13, v6, v6
	fmul.4s	v28, v13, v28
	fmul.4s	v13, v5, v9
	fadd.4s	v13, v13, v10
	fmul.4s	v13, v5, v13
	fadd.4s	v13, v13, v11
	fmul.4s	v13, v5, v13
	fadd.4s	v13, v13, v12
	fmul.4s	v13, v5, v13
	fadd.4s	v13, v13, v15
	fmul.4s	v13, v5, v13
	fadd.4s	v13, v13, v17
	fmul.4s	v14, v5, v5
	fmul.4s	v13, v14, v13
	fadd.4s	v5, v5, v13
	fadd.4s	v6, v6, v28
	fadd.4s	v5, v5, v19
	sshr.4s	v28, v20, #1
	shl.4s	v13, v28, #23
	add.4s	v13, v13, v19
	fmul.4s	v5, v5, v13
	fadd.4s	v6, v6, v19
	sshr.4s	v13, v18, #1
	shl.4s	v14, v13, #23
	add.4s	v14, v14, v19
	fmul.4s	v6, v6, v14
	sub.4s	v20, v20, v28
	sub.4s	v18, v18, v13
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v19
	fmul.4s	v6, v6, v18
	shl.4s	v18, v20, #23
	add.4s	v18, v18, v19
	fmul.4s	v5, v5, v18
	fcmgt.4s	v18, v31, v4
	bic.16b	v5, v5, v18
	fcmgt.4s	v18, v31, v27
	bic.16b	v6, v6, v18
	fcmgt.4s	v18, v27, v2
	bit.16b	v6, v3, v18
	fcmgt.4s	v18, v4, v2
	bit.16b	v5, v3, v18
	fcmeq.4s	v4, v4, v4
	mov.16b	v23, v4
	bsl.16b	v23, v5, v7
	fcmeq.4s	v4, v27, v27
	mov.16b	v17, v4
	bsl.16b	v17, v6, v7
	ldr	q5, [sp, #9664]                 ; 16-byte Reload
	ldr	q4, [sp, #8992]                 ; 16-byte Reload
	fsub.4s	v4, v5, v4
	and.16b	v28, v0, v4
	fcmge.4s	v4, v28, v31
	fcmge.4s	v5, v2, v28
	and.16b	v5, v4, v5
	ldr	q6, [sp, #9648]                 ; 16-byte Reload
	ldr	q4, [sp, #9088]                 ; 16-byte Reload
	fsub.4s	v4, v6, v4
	and.16b	v4, v1, v4
	fcmge.4s	v6, v4, v31
	fcmge.4s	v18, v2, v4
	and.16b	v6, v6, v18
	and.16b	v6, v6, v4
	fmul.4s	v18, v6, v16
	mvni.4s	v27, #128, lsl #24
	mov.16b	v20, v27
	bsl.16b	v20, v25, v18
	fadd.4s	v18, v18, v20
	fsub.4s	v18, v18, v20
	and.16b	v5, v5, v28
	fmul.4s	v20, v5, v16
	bsl.16b	v27, v25, v20
	fadd.4s	v20, v20, v27
	fsub.4s	v20, v20, v27
	fcvtzs.4s	v27, v18
	scvtf.4s	v13, v27
	fmul.4s	v18, v13, v24
	fsub.4s	v6, v6, v18
	fcvtzs.4s	v18, v20
	scvtf.4s	v20, v18
	fmul.4s	v14, v20, v24
	fsub.4s	v5, v5, v14
	fmul.4s	v13, v13, v21
	fmul.4s	v20, v20, v21
	fsub.4s	v5, v5, v20
	fsub.4s	v6, v6, v13
	fmul.4s	v20, v6, v9
	fadd.4s	v20, v20, v10
	fmul.4s	v20, v6, v20
	fadd.4s	v20, v20, v11
	fmul.4s	v20, v6, v20
	fadd.4s	v20, v20, v12
	fmul.4s	v20, v6, v20
	fadd.4s	v20, v20, v15
	fmul.4s	v20, v6, v20
	movi.4s	v21, #63, lsl #24
	fadd.4s	v20, v20, v21
	fmul.4s	v13, v6, v6
	fmul.4s	v20, v13, v20
	fmul.4s	v13, v5, v9
	fadd.4s	v13, v13, v10
	fmul.4s	v13, v5, v13
	fadd.4s	v13, v13, v11
	fmul.4s	v13, v5, v13
	fadd.4s	v13, v13, v12
	fmul.4s	v13, v5, v13
	fadd.4s	v13, v13, v15
	fmul.4s	v13, v5, v13
	fadd.4s	v13, v13, v21
	fmul.4s	v14, v5, v5
	fmul.4s	v13, v14, v13
	fadd.4s	v5, v5, v13
	fadd.4s	v6, v6, v20
	ldr	x15, [sp, #2040]                ; 8-byte Reload
	ldp	q13, q20, [x15]
	ldr	q21, [sp, #9184]                ; 16-byte Reload
	bit.16b	v20, v21, v0
	ldr	q21, [sp, #9200]                ; 16-byte Reload
	bit.16b	v13, v21, v1
	stp	q13, q20, [x15]
	fadd.4s	v5, v5, v19
	sshr.4s	v20, v18, #1
	shl.4s	v13, v20, #23
	add.4s	v13, v13, v19
	fmul.4s	v5, v5, v13
	ldr	x15, [sp, #2032]                ; 8-byte Reload
	ldp	q13, q14, [x15]
	ldr	q21, [sp, #8960]                ; 16-byte Reload
	bit.16b	v13, v21, v1
	ldr	q21, [sp, #8976]                ; 16-byte Reload
	bit.16b	v14, v21, v0
	stp	q13, q14, [x15]
	ldr	x15, [sp, #1960]                ; 8-byte Reload
	ldp	q13, q14, [x15]
	ldr	q21, [sp, #8928]                ; 16-byte Reload
	bit.16b	v13, v21, v1
	ldr	q21, [sp, #8944]                ; 16-byte Reload
	bit.16b	v14, v21, v0
	stp	q13, q14, [x15]
	fadd.4s	v6, v6, v19
	sshr.4s	v13, v27, #1
	shl.4s	v14, v13, #23
	add.4s	v14, v14, v19
	fmul.4s	v6, v6, v14
	sub.4s	v18, v18, v20
	sub.4s	v20, v27, v13
	ldr	x15, [sp, #1952]                ; 8-byte Reload
	ldp	q27, q13, [x15]
	ldr	q21, [sp, #8896]                ; 16-byte Reload
	bit.16b	v27, v21, v1
	ldr	q21, [sp, #8912]                ; 16-byte Reload
	bit.16b	v13, v21, v0
	stp	q27, q13, [x15]
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v19
	fmul.4s	v6, v6, v20
	ldr	x15, [sp, #1944]                ; 8-byte Reload
	ldp	q20, q27, [x15]
	ldr	q21, [sp, #8864]                ; 16-byte Reload
	bit.16b	v20, v21, v1
	ldr	q21, [sp, #8880]                ; 16-byte Reload
	bit.16b	v27, v21, v0
	stp	q20, q27, [x15]
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v19
	fmul.4s	v5, v5, v18
	fcmgt.4s	v18, v31, v28
	bic.16b	v5, v5, v18
	ldr	x15, [sp, #1864]                ; 8-byte Reload
	ldp	q20, q18, [x15]
	ldr	q19, [sp, #8832]                ; 16-byte Reload
	bit.16b	v18, v19, v0
	ldr	q19, [sp, #8848]                ; 16-byte Reload
	bit.16b	v20, v19, v1
	stp	q20, q18, [x15]
	fcmgt.4s	v18, v31, v4
	bic.16b	v6, v6, v18
	fcmgt.4s	v18, v4, v2
	bit.16b	v6, v3, v18
	ldr	x15, [sp, #1856]                ; 8-byte Reload
	ldp	q18, q20, [x15]
	str	q17, [sp, #7792]                ; 16-byte Spill
	bit.16b	v18, v17, v1
	str	q23, [sp, #7808]                ; 16-byte Spill
	bit.16b	v20, v23, v0
	stp	q18, q20, [x15]
	fcmgt.4s	v18, v28, v2
	bit.16b	v5, v3, v18
	fcmeq.4s	v18, v28, v28
	mov.16b	v17, v18
	bsl.16b	v17, v5, v7
	fcmeq.4s	v4, v4, v4
	mov.16b	v5, v4
	bsl.16b	v5, v6, v7
	ldr	x15, [sp, #1848]                ; 8-byte Reload
	ldr	q4, [x15]
	str	q5, [sp, #7760]                 ; 16-byte Spill
	bit.16b	v4, v5, v1
	ldr	q5, [x15, #16]
	str	q17, [sp, #7776]                ; 16-byte Spill
	bit.16b	v5, v17, v0
	stp	q4, q5, [x15]
	mov	x15, #-128                      ; =0xffffffffffffff80
	mov	x16, x28
	mov	w4, #29184                      ; =0x7200
	movk	w4, #48945, lsl #16
	b	LBB0_417
LBB0_416:                               ; %else1306
                                        ;   in Loop: Header=BB0_417 Depth=2
	cmeq.8b	v4, v4, #0
	sshll.8h	v5, v4, #0
	sshll2.4s	v4, v5, #0
	sshll.4s	v18, v5, #0
	ldp	q6, q5, [x16]
	and	x0, x6, #0xe0
	add	x0, x10, x0
	ldp	q27, q20, [x0]
	fsub.4s	v6, v6, v27
	fsub.4s	v5, v5, v20
	and.16b	v27, v0, v5
	and.16b	v28, v1, v6
	fcmge.4s	v5, v28, v31
	fcmge.4s	v6, v27, v31
	fcmge.4s	v20, v2, v28
	fcmge.4s	v13, v2, v27
	and.16b	v6, v6, v13
	and.16b	v5, v5, v20
	and.16b	v5, v5, v28
	and.16b	v6, v6, v27
	fmul.4s	v20, v6, v16
	fmul.4s	v13, v5, v16
	movi.4s	v7, #75, lsl #24
	mvni.4s	v17, #128, lsl #24
	mov.16b	v14, v17
	bsl.16b	v14, v7, v13
	bsl.16b	v17, v7, v20
	fadd.4s	v20, v20, v17
	fadd.4s	v13, v13, v14
	fsub.4s	v13, v13, v14
	fsub.4s	v17, v20, v17
	fcvtzs.4s	v17, v17
	fcvtzs.4s	v20, v13
	scvtf.4s	v13, v20
	scvtf.4s	v14, v17
	dup.4s	v19, w4
	fmul.4s	v7, v14, v19
	fmul.4s	v19, v13, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v6, v6, v7
	dup.4s	v7, w5
	fmul.4s	v19, v13, v7
	fmul.4s	v7, v14, v7
	fadd.4s	v6, v6, v7
	fadd.4s	v5, v5, v19
	fmul.4s	v7, v5, v9
	fmul.4s	v19, v6, v9
	fadd.4s	v19, v19, v10
	fadd.4s	v7, v7, v10
	fmul.4s	v7, v5, v7
	fmul.4s	v19, v6, v19
	fadd.4s	v19, v19, v11
	fadd.4s	v7, v7, v11
	fmul.4s	v7, v5, v7
	fmul.4s	v19, v6, v19
	fadd.4s	v19, v19, v12
	fadd.4s	v7, v7, v12
	fmul.4s	v7, v5, v7
	fmul.4s	v19, v6, v19
	fadd.4s	v19, v19, v15
	fadd.4s	v7, v7, v15
	fmul.4s	v7, v5, v7
	fmul.4s	v19, v6, v19
	movi.4s	v13, #63, lsl #24
	fadd.4s	v19, v19, v13
	fadd.4s	v7, v7, v13
	fmul.4s	v13, v6, v6
	fmul.4s	v14, v5, v5
	fmul.4s	v7, v14, v7
	fmul.4s	v19, v13, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v5, v5, v7
	fmov.4s	v24, #1.00000000
	fadd.4s	v5, v5, v24
	fadd.4s	v6, v6, v24
	sshr.4s	v7, v20, #1
	sshr.4s	v19, v17, #1
	shl.4s	v13, v19, #23
	shl.4s	v14, v7, #23
	add.4s	v14, v14, v24
	add.4s	v13, v13, v24
	fmul.4s	v6, v6, v13
	fmul.4s	v5, v5, v14
	sub.4s	v17, v17, v19
	sub.4s	v7, v20, v7
	shl.4s	v7, v7, #23
	shl.4s	v17, v17, #23
	add.4s	v17, v17, v24
	add.4s	v7, v7, v24
	fmul.4s	v5, v5, v7
	fmul.4s	v6, v6, v17
	fcmgt.4s	v7, v31, v27
	bic.16b	v6, v6, v7
	fcmgt.4s	v7, v31, v28
	bic.16b	v5, v5, v7
	fcmgt.4s	v7, v27, v2
	fcmgt.4s	v17, v28, v2
	bit.16b	v5, v3, v17
	bit.16b	v6, v3, v7
	fcmeq.4s	v7, v28, v28
	fcmeq.4s	v17, v27, v27
	ldr	q19, [sp, #9808]                ; 16-byte Reload
	bif.16b	v6, v19, v17
	bif.16b	v5, v19, v7
	bic.16b	v5, v5, v18
	bic.16b	v4, v6, v4
	ldr	q6, [x16, #4608]
	ldr	q7, [x16, #4624]
	bif.16b	v4, v7, v0
	bif.16b	v5, v6, v1
	add	x6, x6, #2
	str	q5, [x16, #4608]
	str	q4, [x16, #4624]
	add	x15, x15, #1
	add	x9, x9, #8
	add	x16, x16, #32
	cmp	x6, #256
	b.eq	LBB0_433
LBB0_417:                               ; %direct.true1274
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q4, [sp, #10080]                ; 16-byte Reload
	fmov	w0, s4
	add	x1, x15, #128
	and	x2, x9, #0x78
	orr	x1, x2, x1, lsr #4
	dup.2d	v18, x1
	ldr	q4, [sp, #10064]                ; 16-byte Reload
	orr.16b	v4, v18, v4
	ldr	q5, [sp, #10000]                ; 16-byte Reload
	add.2d	v27, v5, v4
	ldr	q5, [sp, #10048]                ; 16-byte Reload
	ldr	q6, [sp, #10032]                ; 16-byte Reload
	tbz	w0, #0, LBB0_419
; %bb.418:                              ; %cond.load1260
                                        ;   in Loop: Header=BB0_417 Depth=2
	fmov	x1, d27
	ldr	b4, [x1]
	and	w0, w0, #0xff
	tbnz	w0, #1, LBB0_420
	b	LBB0_421
LBB0_419:                               ;   in Loop: Header=BB0_417 Depth=2
	movi.2d	v4, #0000000000000000
	and	w0, w0, #0xff
	tbz	w0, #1, LBB0_421
LBB0_420:                               ; %cond.load1266
                                        ;   in Loop: Header=BB0_417 Depth=2
	mov.d	x1, v27[1]
	ld1.b	{ v4 }[1], [x1]
LBB0_421:                               ; %else1270
                                        ;   in Loop: Header=BB0_417 Depth=2
	orr.16b	v5, v18, v5
	ldr	q7, [sp, #9984]                 ; 16-byte Reload
	add.2d	v27, v7, v5
	tbz	w0, #2, LBB0_427
; %bb.422:                              ; %cond.load1272
                                        ;   in Loop: Header=BB0_417 Depth=2
	fmov	x1, d27
	ld1.b	{ v4 }[2], [x1]
	tbnz	w0, #3, LBB0_428
LBB0_423:                               ; %else1282
                                        ;   in Loop: Header=BB0_417 Depth=2
	orr.16b	v5, v18, v6
	ldr	q6, [sp, #9968]                 ; 16-byte Reload
	add.2d	v27, v6, v5
	tbz	w0, #4, LBB0_429
LBB0_424:                               ; %cond.load1284
                                        ;   in Loop: Header=BB0_417 Depth=2
	fmov	x1, d27
	ld1.b	{ v4 }[4], [x1]
	tbnz	w0, #5, LBB0_430
LBB0_425:                               ; %else1294
                                        ;   in Loop: Header=BB0_417 Depth=2
	ldr	q5, [sp, #10016]                ; 16-byte Reload
	orr.16b	v5, v18, v5
	ldr	q6, [sp, #9952]                 ; 16-byte Reload
	add.2d	v18, v6, v5
	tbz	w0, #6, LBB0_431
LBB0_426:                               ; %cond.load1296
                                        ;   in Loop: Header=BB0_417 Depth=2
	fmov	x1, d18
	ld1.b	{ v4 }[6], [x1]
	tbz	w0, #7, LBB0_416
	b	LBB0_432
LBB0_427:                               ; %else1276
                                        ;   in Loop: Header=BB0_417 Depth=2
	tbz	w0, #3, LBB0_423
LBB0_428:                               ; %cond.load1278
                                        ;   in Loop: Header=BB0_417 Depth=2
	mov.d	x1, v27[1]
	ld1.b	{ v4 }[3], [x1]
	orr.16b	v5, v18, v6
	ldr	q6, [sp, #9968]                 ; 16-byte Reload
	add.2d	v27, v6, v5
	tbnz	w0, #4, LBB0_424
LBB0_429:                               ; %else1288
                                        ;   in Loop: Header=BB0_417 Depth=2
	tbz	w0, #5, LBB0_425
LBB0_430:                               ; %cond.load1290
                                        ;   in Loop: Header=BB0_417 Depth=2
	mov.d	x1, v27[1]
	ld1.b	{ v4 }[5], [x1]
	ldr	q5, [sp, #10016]                ; 16-byte Reload
	orr.16b	v5, v18, v5
	ldr	q6, [sp, #9952]                 ; 16-byte Reload
	add.2d	v18, v6, v5
	tbnz	w0, #6, LBB0_426
LBB0_431:                               ; %else1300
                                        ;   in Loop: Header=BB0_417 Depth=2
	tbz	w0, #7, LBB0_416
LBB0_432:                               ; %cond.load1302
                                        ;   in Loop: Header=BB0_417 Depth=2
	mov.d	x0, v18[1]
	ld1.b	{ v4 }[7], [x0]
	b	LBB0_416
LBB0_433:                               ; %direct.false1275
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	x10, [sp, #1840]                ; 8-byte Reload
	ldp	q24, q23, [x10]
	mov	x9, #0                          ; =0x0
	mov	x15, #0                         ; =0x0
	ldr	x10, [sp, #1832]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #7424]                 ; 16-byte Spill
	str	q2, [sp, #7632]                 ; 16-byte Spill
	ldr	x10, [sp, #1824]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #7744]                 ; 16-byte Spill
	str	q2, [sp, #7408]                 ; 16-byte Spill
	ldr	x10, [sp, #1816]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #7600]                 ; 16-byte Spill
	str	q2, [sp, #7616]                 ; 16-byte Spill
	ldr	x10, [sp, #1808]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #7728]                 ; 16-byte Spill
	str	q2, [sp, #7392]                 ; 16-byte Spill
	ldr	x10, [sp, #1736]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #7568]                 ; 16-byte Spill
	str	q2, [sp, #7584]                 ; 16-byte Spill
	ldr	x10, [sp, #1728]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #7712]                 ; 16-byte Spill
	str	q2, [sp, #7376]                 ; 16-byte Spill
	ldr	x10, [sp, #1720]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #7536]                 ; 16-byte Spill
	str	q2, [sp, #7552]                 ; 16-byte Spill
	ldr	x10, [sp, #1640]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #7696]                 ; 16-byte Spill
	str	q2, [sp, #7360]                 ; 16-byte Spill
	ldr	x10, [sp, #1632]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #7504]                 ; 16-byte Spill
	str	q2, [sp, #7520]                 ; 16-byte Spill
	ldr	x10, [sp, #1624]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #7680]                 ; 16-byte Spill
	str	q2, [sp, #7344]                 ; 16-byte Spill
	ldr	x10, [sp, #1616]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #7472]                 ; 16-byte Spill
	str	q2, [sp, #7488]                 ; 16-byte Spill
	ldr	x10, [sp, #1608]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #7664]                 ; 16-byte Spill
	str	q2, [sp, #7328]                 ; 16-byte Spill
	ldr	x10, [sp, #1600]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #7440]                 ; 16-byte Spill
	str	q2, [sp, #7456]                 ; 16-byte Spill
	ldr	x10, [sp, #1592]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #7648]                 ; 16-byte Spill
	str	q2, [sp, #7312]                 ; 16-byte Spill
	add	x16, x8, #21, lsl #12           ; =86016
	ldp	q2, q3, [x16]
	str	q3, [sp, #7264]                 ; 16-byte Spill
	str	q2, [sp, #7248]                 ; 16-byte Spill
	ldr	x16, [sp, #2640]                ; 8-byte Reload
	ldr	x0, [sp, #2648]                 ; 8-byte Reload
	mov	w1, #48                         ; =0x30
	ldr	x2, [sp, #2680]                 ; 8-byte Reload
	ldr	x5, [sp, #3632]                 ; 8-byte Reload
	ldr	x10, [sp, #1584]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #7280]                 ; 16-byte Spill
	str	q2, [sp, #7296]                 ; 16-byte Spill
	ldr	x10, [sp, #1512]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #7040]                 ; 16-byte Spill
	str	q2, [sp, #7152]                 ; 16-byte Spill
	ldr	x10, [sp, #1504]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6848]                 ; 16-byte Spill
	str	q2, [sp, #7024]                 ; 16-byte Spill
	ldr	x10, [sp, #1496]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #7136]                 ; 16-byte Spill
	str	q2, [sp, #6832]                 ; 16-byte Spill
	ldr	x10, [sp, #1416]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6992]                 ; 16-byte Spill
	str	q2, [sp, #7008]                 ; 16-byte Spill
	ldr	x10, [sp, #1408]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #7120]                 ; 16-byte Spill
	str	q2, [sp, #6816]                 ; 16-byte Spill
	ldr	x10, [sp, #1400]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6960]                 ; 16-byte Spill
	str	q2, [sp, #6976]                 ; 16-byte Spill
	ldr	x10, [sp, #1392]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #7104]                 ; 16-byte Spill
	str	q2, [sp, #6800]                 ; 16-byte Spill
	ldr	x10, [sp, #1384]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6928]                 ; 16-byte Spill
	str	q2, [sp, #6944]                 ; 16-byte Spill
	ldr	x10, [sp, #1376]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #7088]                 ; 16-byte Spill
	str	q2, [sp, #6784]                 ; 16-byte Spill
	ldr	x10, [sp, #1368]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6896]                 ; 16-byte Spill
	str	q2, [sp, #6912]                 ; 16-byte Spill
	ldr	x10, [sp, #1360]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #7072]                 ; 16-byte Spill
	str	q2, [sp, #6768]                 ; 16-byte Spill
	ldr	x10, [sp, #1280]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6864]                 ; 16-byte Spill
	str	q2, [sp, #6880]                 ; 16-byte Spill
	ldr	x10, [sp, #1272]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #7200]                 ; 16-byte Spill
	str	q2, [sp, #7216]                 ; 16-byte Spill
	ldr	x10, [sp, #1224]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #7232]                 ; 16-byte Spill
	str	q2, [sp, #7056]                 ; 16-byte Spill
	ldr	x10, [sp, #1216]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #7168]                 ; 16-byte Spill
	str	q2, [sp, #7184]                 ; 16-byte Spill
	ldr	x10, [sp, #1208]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6624]                 ; 16-byte Spill
	str	q2, [sp, #6752]                 ; 16-byte Spill
	ldr	x10, [sp, #1200]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6368]                 ; 16-byte Spill
	str	q2, [sp, #6608]                 ; 16-byte Spill
	ldr	x10, [sp, #1192]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6736]                 ; 16-byte Spill
	str	q2, [sp, #6352]                 ; 16-byte Spill
	ldr	x10, [sp, #1184]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6576]                 ; 16-byte Spill
	str	q2, [sp, #6592]                 ; 16-byte Spill
	ldr	x10, [sp, #1176]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6720]                 ; 16-byte Spill
	str	q2, [sp, #6336]                 ; 16-byte Spill
	ldr	x10, [sp, #1168]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6544]                 ; 16-byte Spill
	str	q2, [sp, #6560]                 ; 16-byte Spill
	ldr	x10, [sp, #1160]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6704]                 ; 16-byte Spill
	str	q2, [sp, #6320]                 ; 16-byte Spill
	ldr	x10, [sp, #1152]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6512]                 ; 16-byte Spill
	str	q2, [sp, #6528]                 ; 16-byte Spill
	ldr	x10, [sp, #1144]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6688]                 ; 16-byte Spill
	str	q2, [sp, #6304]                 ; 16-byte Spill
	ldr	x10, [sp, #1136]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6480]                 ; 16-byte Spill
	str	q2, [sp, #6496]                 ; 16-byte Spill
	ldr	x10, [sp, #1128]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6672]                 ; 16-byte Spill
	str	q2, [sp, #6288]                 ; 16-byte Spill
	ldr	x10, [sp, #1120]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6448]                 ; 16-byte Spill
	str	q2, [sp, #6464]                 ; 16-byte Spill
	ldr	x10, [sp, #1112]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6656]                 ; 16-byte Spill
	str	q2, [sp, #6272]                 ; 16-byte Spill
	ldr	x10, [sp, #1104]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6416]                 ; 16-byte Spill
	str	q2, [sp, #6432]                 ; 16-byte Spill
	ldr	x10, [sp, #1096]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6640]                 ; 16-byte Spill
	str	q2, [sp, #6256]                 ; 16-byte Spill
	ldr	x10, [sp, #1088]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6384]                 ; 16-byte Spill
	str	q2, [sp, #6400]                 ; 16-byte Spill
	ldr	x10, [sp, #1080]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6112]                 ; 16-byte Spill
	str	q2, [sp, #6240]                 ; 16-byte Spill
	ldr	x10, [sp, #1072]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5856]                 ; 16-byte Spill
	str	q2, [sp, #6096]                 ; 16-byte Spill
	ldr	x10, [sp, #1064]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6224]                 ; 16-byte Spill
	str	q2, [sp, #5840]                 ; 16-byte Spill
	ldr	x10, [sp, #1056]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6064]                 ; 16-byte Spill
	str	q2, [sp, #6080]                 ; 16-byte Spill
	ldr	x10, [sp, #1048]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6208]                 ; 16-byte Spill
	str	q2, [sp, #5824]                 ; 16-byte Spill
	ldr	x10, [sp, #1040]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6032]                 ; 16-byte Spill
	str	q2, [sp, #6048]                 ; 16-byte Spill
	ldr	x10, [sp, #1032]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6192]                 ; 16-byte Spill
	str	q2, [sp, #5808]                 ; 16-byte Spill
	ldr	x10, [sp, #1024]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6000]                 ; 16-byte Spill
	str	q2, [sp, #6016]                 ; 16-byte Spill
	ldr	x10, [sp, #1016]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6176]                 ; 16-byte Spill
	str	q2, [sp, #5792]                 ; 16-byte Spill
	ldr	x10, [sp, #1008]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5968]                 ; 16-byte Spill
	str	q2, [sp, #5984]                 ; 16-byte Spill
	ldr	x10, [sp, #1000]                ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6160]                 ; 16-byte Spill
	str	q2, [sp, #5776]                 ; 16-byte Spill
	ldr	x10, [sp, #992]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5936]                 ; 16-byte Spill
	str	q2, [sp, #5952]                 ; 16-byte Spill
	ldr	x10, [sp, #984]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6144]                 ; 16-byte Spill
	str	q2, [sp, #5760]                 ; 16-byte Spill
	ldr	x10, [sp, #976]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5904]                 ; 16-byte Spill
	str	q2, [sp, #5920]                 ; 16-byte Spill
	ldr	x10, [sp, #968]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #6128]                 ; 16-byte Spill
	str	q2, [sp, #5744]                 ; 16-byte Spill
	ldr	x10, [sp, #960]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5872]                 ; 16-byte Spill
	str	q2, [sp, #5888]                 ; 16-byte Spill
	ldr	x10, [sp, #952]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5600]                 ; 16-byte Spill
	str	q2, [sp, #5728]                 ; 16-byte Spill
	ldr	x10, [sp, #944]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5344]                 ; 16-byte Spill
	str	q2, [sp, #5584]                 ; 16-byte Spill
	ldr	x10, [sp, #936]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5712]                 ; 16-byte Spill
	str	q2, [sp, #5328]                 ; 16-byte Spill
	ldr	x10, [sp, #928]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5552]                 ; 16-byte Spill
	str	q2, [sp, #5568]                 ; 16-byte Spill
	ldr	x10, [sp, #920]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5696]                 ; 16-byte Spill
	str	q2, [sp, #5312]                 ; 16-byte Spill
	ldr	x10, [sp, #912]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5520]                 ; 16-byte Spill
	str	q2, [sp, #5536]                 ; 16-byte Spill
	ldr	x10, [sp, #904]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5680]                 ; 16-byte Spill
	str	q2, [sp, #5296]                 ; 16-byte Spill
	ldr	x10, [sp, #896]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5488]                 ; 16-byte Spill
	str	q2, [sp, #5504]                 ; 16-byte Spill
	ldr	x10, [sp, #888]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5664]                 ; 16-byte Spill
	str	q2, [sp, #5280]                 ; 16-byte Spill
	ldr	x10, [sp, #880]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5456]                 ; 16-byte Spill
	str	q2, [sp, #5472]                 ; 16-byte Spill
	ldr	x10, [sp, #872]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5648]                 ; 16-byte Spill
	str	q2, [sp, #5264]                 ; 16-byte Spill
	ldr	x10, [sp, #864]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5424]                 ; 16-byte Spill
	str	q2, [sp, #5440]                 ; 16-byte Spill
	ldr	x10, [sp, #856]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5632]                 ; 16-byte Spill
	str	q2, [sp, #5248]                 ; 16-byte Spill
	ldr	x10, [sp, #848]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5392]                 ; 16-byte Spill
	str	q2, [sp, #5408]                 ; 16-byte Spill
	ldr	x10, [sp, #840]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5616]                 ; 16-byte Spill
	str	q2, [sp, #5232]                 ; 16-byte Spill
	ldr	x10, [sp, #832]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5360]                 ; 16-byte Spill
	str	q2, [sp, #5376]                 ; 16-byte Spill
	ldr	x10, [sp, #824]                 ; 8-byte Reload
	ldp	q21, q2, [x10]
	str	q2, [sp, #5104]                 ; 16-byte Spill
	ldr	x10, [sp, #816]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4848]                 ; 16-byte Spill
	str	q2, [sp, #5088]                 ; 16-byte Spill
	ldr	x10, [sp, #808]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5216]                 ; 16-byte Spill
	str	q2, [sp, #4832]                 ; 16-byte Spill
	ldr	x10, [sp, #800]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5056]                 ; 16-byte Spill
	str	q2, [sp, #5072]                 ; 16-byte Spill
	ldr	x10, [sp, #792]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5200]                 ; 16-byte Spill
	str	q2, [sp, #4816]                 ; 16-byte Spill
	ldr	x10, [sp, #784]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5024]                 ; 16-byte Spill
	str	q2, [sp, #5040]                 ; 16-byte Spill
	ldr	x10, [sp, #776]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5184]                 ; 16-byte Spill
	str	q2, [sp, #4800]                 ; 16-byte Spill
	ldr	x10, [sp, #768]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4992]                 ; 16-byte Spill
	str	q2, [sp, #5008]                 ; 16-byte Spill
	ldr	x10, [sp, #760]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5168]                 ; 16-byte Spill
	str	q2, [sp, #4784]                 ; 16-byte Spill
	ldr	x10, [sp, #752]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4960]                 ; 16-byte Spill
	str	q2, [sp, #4976]                 ; 16-byte Spill
	ldr	x10, [sp, #744]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5152]                 ; 16-byte Spill
	str	q2, [sp, #4768]                 ; 16-byte Spill
	ldr	x10, [sp, #736]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4928]                 ; 16-byte Spill
	str	q2, [sp, #4944]                 ; 16-byte Spill
	ldr	x10, [sp, #728]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5136]                 ; 16-byte Spill
	str	q2, [sp, #4752]                 ; 16-byte Spill
	ldr	x10, [sp, #720]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4896]                 ; 16-byte Spill
	str	q2, [sp, #4912]                 ; 16-byte Spill
	ldr	x10, [sp, #712]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #5120]                 ; 16-byte Spill
	str	q2, [sp, #4736]                 ; 16-byte Spill
	ldr	x10, [sp, #704]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4864]                 ; 16-byte Spill
	str	q2, [sp, #4880]                 ; 16-byte Spill
	ldr	x10, [sp, #696]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4592]                 ; 16-byte Spill
	str	q2, [sp, #4720]                 ; 16-byte Spill
	ldr	x10, [sp, #688]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4336]                 ; 16-byte Spill
	str	q2, [sp, #4576]                 ; 16-byte Spill
	ldr	x10, [sp, #680]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4704]                 ; 16-byte Spill
	str	q2, [sp, #4320]                 ; 16-byte Spill
	ldr	x10, [sp, #672]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4544]                 ; 16-byte Spill
	str	q2, [sp, #4560]                 ; 16-byte Spill
	ldr	x10, [sp, #664]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4688]                 ; 16-byte Spill
	str	q2, [sp, #4304]                 ; 16-byte Spill
	ldr	x10, [sp, #632]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4512]                 ; 16-byte Spill
	str	q2, [sp, #4528]                 ; 16-byte Spill
	ldr	x10, [sp, #568]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4672]                 ; 16-byte Spill
	str	q2, [sp, #4288]                 ; 16-byte Spill
	ldr	x10, [sp, #560]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4480]                 ; 16-byte Spill
	str	q2, [sp, #4496]                 ; 16-byte Spill
	ldr	x10, [sp, #472]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4656]                 ; 16-byte Spill
	str	q2, [sp, #4272]                 ; 16-byte Spill
	ldr	x10, [sp, #464]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4448]                 ; 16-byte Spill
	str	q2, [sp, #4464]                 ; 16-byte Spill
	ldr	x10, [sp, #456]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4640]                 ; 16-byte Spill
	str	q2, [sp, #4256]                 ; 16-byte Spill
	ldr	x10, [sp, #448]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4416]                 ; 16-byte Spill
	str	q2, [sp, #4432]                 ; 16-byte Spill
	ldr	x10, [sp, #440]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4624]                 ; 16-byte Spill
	str	q2, [sp, #4240]                 ; 16-byte Spill
	ldr	x10, [sp, #432]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4384]                 ; 16-byte Spill
	str	q2, [sp, #4400]                 ; 16-byte Spill
	ldr	x10, [sp, #424]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4608]                 ; 16-byte Spill
	str	q2, [sp, #4224]                 ; 16-byte Spill
	ldr	x10, [sp, #416]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4352]                 ; 16-byte Spill
	str	q2, [sp, #4368]                 ; 16-byte Spill
	ldr	x10, [sp, #408]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4080]                 ; 16-byte Spill
	str	q2, [sp, #4208]                 ; 16-byte Spill
	ldr	x10, [sp, #400]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #3824]                 ; 16-byte Spill
	str	q2, [sp, #4064]                 ; 16-byte Spill
	ldr	x10, [sp, #392]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4192]                 ; 16-byte Spill
	str	q2, [sp, #3808]                 ; 16-byte Spill
	ldr	x10, [sp, #384]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4032]                 ; 16-byte Spill
	str	q2, [sp, #4048]                 ; 16-byte Spill
	ldr	x10, [sp, #376]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4176]                 ; 16-byte Spill
	str	q2, [sp, #3792]                 ; 16-byte Spill
	ldr	x10, [sp, #368]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4000]                 ; 16-byte Spill
	str	q2, [sp, #4016]                 ; 16-byte Spill
	ldr	x10, [sp, #360]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4160]                 ; 16-byte Spill
	str	q2, [sp, #3776]                 ; 16-byte Spill
	ldr	x10, [sp, #352]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #3968]                 ; 16-byte Spill
	str	q2, [sp, #3984]                 ; 16-byte Spill
	ldr	x10, [sp, #344]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4144]                 ; 16-byte Spill
	str	q2, [sp, #3760]                 ; 16-byte Spill
	ldr	x10, [sp, #336]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #3936]                 ; 16-byte Spill
	str	q2, [sp, #3952]                 ; 16-byte Spill
	ldr	x10, [sp, #328]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4128]                 ; 16-byte Spill
	str	q2, [sp, #3744]                 ; 16-byte Spill
	ldr	x10, [sp, #320]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #3904]                 ; 16-byte Spill
	str	q2, [sp, #3920]                 ; 16-byte Spill
	ldr	x10, [sp, #312]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4112]                 ; 16-byte Spill
	str	q2, [sp, #3728]                 ; 16-byte Spill
	ldr	x10, [sp, #304]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #3872]                 ; 16-byte Spill
	str	q2, [sp, #3888]                 ; 16-byte Spill
	ldr	x10, [sp, #296]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #4096]                 ; 16-byte Spill
	str	q2, [sp, #3712]                 ; 16-byte Spill
	ldr	x10, [sp, #288]                 ; 8-byte Reload
	ldp	q2, q3, [x10]
	str	q3, [sp, #3840]                 ; 16-byte Spill
	str	q2, [sp, #3856]                 ; 16-byte Spill
LBB0_434:                               ; %direct.schedule.75.preheader
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_435 Depth 3
	mov	x6, #0                          ; =0x0
	mov	x7, x16
	mov	x19, x9
	mov	x24, x0
LBB0_435:                               ; %direct.true1432
                                        ;   Parent Loop BB0_28 Depth=1
                                        ;     Parent Loop BB0_434 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x4, x1, x6
	umulh	x20, x4, x23
	lsr	x26, x20, #5
	add	x4, x12, x4, lsl #5
	ldp	q4, q5, [x4]
	add	x4, x21, x26, lsl #5
	ldp	q6, q7, [x4]
	fmul.4s	v5, v5, v7
	add	x28, x9, x6
	umulh	x4, x28, x23
	fmul.4s	v4, v4, v6
	lsr	x4, x4, #5
	add	x20, x22, x4, lsl #9
	ldp	q7, q6, [x20]
	and.16b	v7, v1, v7
	and.16b	v4, v1, v4
	and.16b	v6, v0, v6
	add	x27, x4, x4, lsl #1
	lsl	x30, x27, #4
	sub	x27, x28, x30
	add	x10, x12, x28, lsl #5
	and.16b	v5, v0, v5
	ldp	q18, q17, [x10]
	add	x10, x21, x4, lsl #5
	ldp	q20, q19, [x10]
	fmul.4s	v18, v18, v20
	add	x4, x22, x26, lsl #9
	ldp	q27, q28, [x4]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	fmul.4s	v17, v17, v19
	add	x26, x3, x27, lsl #5
	ldp	q14, q13, [x26]
	and.16b	v14, v1, v14
	and.16b	v13, v0, v13
	and.16b	v17, v0, v17
	umulh	x10, x19, x23
	lsr	x10, x10, #5
	madd	x27, x10, x17, x7
	add	x30, x28, x30
	msub	x10, x10, x14, x30
	and.16b	v18, v1, v18
	add	x10, x12, x10, lsl #5
	ldp	q2, q15, [x10, #32]
	ldp	q16, q3, [x27]
	fmul.4s	v2, v20, v2
	and.16b	v16, v1, v16
	add	x10, x28, #49
	umulh	x28, x10, x23
	add	x10, x12, x10, lsl #5
	fmul.4s	v19, v19, v15
	ldp	q20, q15, [x10]
	and	x10, x28, #0xffffffffffffffe0
	add	x10, x21, x10
	ldp	q31, q9, [x10]
	fmul.4s	v9, v15, v9
	and.16b	v3, v0, v3
	fmul.4s	v15, v6, v13
	fmul.4s	v10, v7, v14
	fadd.4s	v18, v18, v10
	fadd.4s	v17, v17, v15
	fmul.4s	v20, v20, v31
	fmul.4s	v6, v6, v3
	fmul.4s	v7, v7, v16
	fmul.4s	v31, v27, v14
	fmul.4s	v10, v28, v13
	fadd.4s	v5, v5, v10
	and.16b	v19, v0, v19
	fadd.4s	v4, v4, v31
	fmul.4s	v16, v27, v16
	fmul.4s	v3, v28, v3
	ldp	q27, q28, [x20, #32]
	and.16b	v2, v1, v2
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	ldp	q10, q31, [x4, #32]
	and.16b	v10, v1, v10
	and.16b	v20, v1, v20
	and.16b	v31, v0, v31
	ldr	q13, [x26, #1552]
	and.16b	v13, v0, v13
	ldr	q14, [x26, #1536]
	and.16b	v14, v1, v14
	and.16b	v9, v0, v9
	ldr	q15, [x27, #1552]
	and.16b	v15, v0, v15
	ldr	q11, [x27, #1536]
	and.16b	v11, v1, v11
	fmul.4s	v12, v28, v13
	fadd.4s	v17, v17, v12
	fmul.4s	v12, v27, v14
	fmul.4s	v27, v27, v11
	fmul.4s	v28, v28, v15
	fmul.4s	v13, v31, v13
	fmul.4s	v14, v10, v14
	fadd.4s	v18, v18, v12
	fadd.4s	v4, v4, v14
	fadd.4s	v5, v5, v13
	fmul.4s	v31, v31, v15
	fmul.4s	v10, v10, v11
	fadd.4s	v2, v2, v7
	ldp	q7, q11, [x20, #64]
	and.16b	v7, v1, v7
	and.16b	v11, v0, v11
	ldp	q12, q13, [x4, #64]
	fadd.4s	v6, v19, v6
	and.16b	v19, v0, v13
	and.16b	v12, v1, v12
	ldr	q13, [x26, #3072]
	and.16b	v13, v1, v13
	ldr	q14, [x26, #3088]
	fadd.4s	v3, v9, v3
	and.16b	v9, v0, v14
	ldr	q14, [x27, #3088]
	ldr	q15, [x27, #3072]
	and.16b	v15, v1, v15
	and.16b	v14, v0, v14
	fadd.4s	v16, v20, v16
	fmul.4s	v20, v7, v13
	fadd.4s	v18, v18, v20
	fmul.4s	v20, v11, v9
	fmul.4s	v11, v11, v14
	fmul.4s	v7, v7, v15
	fadd.4s	v17, v17, v20
	fmul.4s	v20, v12, v13
	fmul.4s	v9, v19, v9
	fadd.4s	v5, v5, v9
	fadd.4s	v4, v4, v20
	fmul.4s	v20, v12, v15
	fadd.4s	v6, v6, v28
	fmul.4s	v19, v19, v14
	ldp	q28, q9, [x20, #96]
	and.16b	v9, v0, v9
	and.16b	v28, v1, v28
	fadd.4s	v2, v2, v27
	ldp	q12, q27, [x4, #96]
	and.16b	v12, v1, v12
	and.16b	v27, v0, v27
	ldr	q13, [x26, #4608]
	fadd.4s	v16, v16, v10
	ldr	q10, [x26, #4624]
	and.16b	v10, v0, v10
	and.16b	v13, v1, v13
	ldr	q14, [x27, #4608]
	ldr	q15, [x27, #4624]
	fadd.4s	v3, v3, v31
	and.16b	v31, v0, v15
	and.16b	v14, v1, v14
	fmul.4s	v15, v9, v10
	fadd.4s	v17, v17, v15
	fmul.4s	v15, v28, v13
	fadd.4s	v18, v18, v15
	fmul.4s	v28, v28, v14
	fmul.4s	v9, v9, v31
	fmul.4s	v10, v27, v10
	fmul.4s	v13, v12, v13
	fadd.4s	v4, v4, v13
	fadd.4s	v2, v2, v7
	fadd.4s	v5, v5, v10
	fmul.4s	v7, v27, v31
	fmul.4s	v27, v12, v14
	ldp	q10, q31, [x20, #128]
	fadd.4s	v6, v6, v11
	and.16b	v10, v1, v10
	and.16b	v31, v0, v31
	ldp	q11, q12, [x4, #128]
	and.16b	v12, v0, v12
	fadd.4s	v3, v3, v19
	and.16b	v19, v1, v11
	ldr	q11, [x26, #6160]
	ldr	q13, [x26, #6144]
	and.16b	v13, v1, v13
	and.16b	v11, v0, v11
	fadd.4s	v16, v16, v20
	ldr	q20, [x27, #6160]
	ldr	q14, [x27, #6144]
	and.16b	v14, v1, v14
	and.16b	v20, v0, v20
	fmul.4s	v15, v10, v13
	fadd.4s	v18, v18, v15
	fmul.4s	v15, v31, v11
	fmul.4s	v31, v31, v20
	fmul.4s	v10, v10, v14
	fmul.4s	v13, v19, v13
	fmul.4s	v11, v12, v11
	fadd.4s	v17, v17, v15
	fadd.4s	v5, v5, v11
	fadd.4s	v4, v4, v13
	fmul.4s	v19, v19, v14
	fmul.4s	v20, v12, v20
	fadd.4s	v6, v6, v9
	ldp	q11, q9, [x20, #160]
	and.16b	v9, v0, v9
	and.16b	v11, v1, v11
	ldp	q13, q12, [x4, #160]
	fadd.4s	v2, v2, v28
	and.16b	v28, v1, v13
	and.16b	v12, v0, v12
	ldr	q13, [x26, #7680]
	ldr	q14, [x26, #7696]
	and.16b	v14, v0, v14
	fadd.4s	v16, v16, v27
	and.16b	v27, v1, v13
	ldr	q13, [x27, #7680]
	ldr	q15, [x27, #7696]
	and.16b	v15, v0, v15
	and.16b	v13, v1, v13
	fadd.4s	v3, v3, v7
	fmul.4s	v7, v9, v14
	fadd.4s	v7, v17, v7
	fmul.4s	v17, v11, v27
	fmul.4s	v11, v11, v13
	fmul.4s	v9, v9, v15
	fadd.4s	v17, v18, v17
	fmul.4s	v18, v12, v14
	fmul.4s	v27, v28, v27
	fadd.4s	v4, v4, v27
	fadd.4s	v5, v5, v18
	fmul.4s	v18, v12, v15
	fadd.4s	v2, v2, v10
	fmul.4s	v27, v28, v13
	ldp	q10, q28, [x20, #192]
	and.16b	v10, v1, v10
	and.16b	v28, v0, v28
	fadd.4s	v6, v6, v31
	ldp	q31, q12, [x4, #192]
	and.16b	v12, v0, v12
	and.16b	v31, v1, v31
	ldr	q13, [x26, #9232]
	fadd.4s	v3, v3, v20
	ldr	q20, [x26, #9216]
	and.16b	v20, v1, v20
	and.16b	v13, v0, v13
	ldr	q14, [x27, #9232]
	ldr	q15, [x27, #9216]
	fadd.4s	v16, v16, v19
	and.16b	v19, v1, v15
	and.16b	v14, v0, v14
	fmul.4s	v15, v10, v20
	fadd.4s	v17, v17, v15
	fmul.4s	v15, v28, v13
	fadd.4s	v7, v7, v15
	fmul.4s	v28, v28, v14
	fmul.4s	v10, v10, v19
	fmul.4s	v20, v31, v20
	fmul.4s	v13, v12, v13
	fadd.4s	v5, v5, v13
	fadd.4s	v6, v6, v9
	fadd.4s	v4, v4, v20
	fmul.4s	v19, v31, v19
	fmul.4s	v20, v12, v14
	ldp	q31, q9, [x20, #224]
	fadd.4s	v2, v2, v11
	and.16b	v9, v0, v9
	and.16b	v31, v1, v31
	ldp	q12, q11, [x4, #224]
	and.16b	v12, v1, v12
	fadd.4s	v16, v16, v27
	and.16b	v27, v0, v11
	ldr	q11, [x26, #10752]
	ldr	q13, [x26, #10768]
	and.16b	v13, v0, v13
	and.16b	v11, v1, v11
	fadd.4s	v3, v3, v18
	ldr	q18, [x27, #10752]
	ldr	q14, [x27, #10768]
	and.16b	v14, v0, v14
	and.16b	v18, v1, v18
	fmul.4s	v15, v9, v13
	fadd.4s	v7, v7, v15
	fmul.4s	v15, v31, v11
	fmul.4s	v31, v31, v18
	fmul.4s	v9, v9, v14
	fmul.4s	v13, v27, v13
	fmul.4s	v11, v12, v11
	fadd.4s	v17, v17, v15
	fadd.4s	v4, v4, v11
	fadd.4s	v5, v5, v13
	fmul.4s	v27, v27, v14
	fmul.4s	v18, v12, v18
	fadd.4s	v2, v2, v10
	ldp	q10, q11, [x20, #256]
	and.16b	v10, v1, v10
	and.16b	v11, v0, v11
	ldp	q12, q13, [x4, #256]
	fadd.4s	v6, v6, v28
	and.16b	v28, v0, v13
	and.16b	v12, v1, v12
	ldr	q13, [x26, #12304]
	ldr	q14, [x26, #12288]
	and.16b	v14, v1, v14
	fadd.4s	v3, v3, v20
	and.16b	v20, v0, v13
	ldr	q13, [x27, #12304]
	ldr	q15, [x27, #12288]
	and.16b	v15, v1, v15
	and.16b	v13, v0, v13
	fadd.4s	v16, v16, v19
	fmul.4s	v19, v10, v14
	fadd.4s	v17, v17, v19
	fmul.4s	v19, v11, v20
	fmul.4s	v11, v11, v13
	fmul.4s	v10, v10, v15
	fadd.4s	v7, v7, v19
	fmul.4s	v19, v12, v14
	fmul.4s	v20, v28, v20
	fadd.4s	v5, v5, v20
	fadd.4s	v4, v4, v19
	fmul.4s	v19, v12, v15
	fadd.4s	v6, v6, v9
	fmul.4s	v20, v28, v13
	ldp	q28, q9, [x20, #288]
	and.16b	v9, v0, v9
	and.16b	v28, v1, v28
	fadd.4s	v2, v2, v31
	ldp	q12, q31, [x4, #288]
	and.16b	v12, v1, v12
	and.16b	v31, v0, v31
	ldr	q13, [x26, #13824]
	fadd.4s	v16, v16, v18
	ldr	q18, [x26, #13840]
	and.16b	v18, v0, v18
	and.16b	v13, v1, v13
	ldr	q14, [x27, #13824]
	ldr	q15, [x27, #13840]
	fadd.4s	v3, v3, v27
	and.16b	v27, v0, v15
	and.16b	v14, v1, v14
	fmul.4s	v15, v9, v18
	fadd.4s	v7, v7, v15
	fmul.4s	v15, v28, v13
	fadd.4s	v17, v17, v15
	fmul.4s	v28, v28, v14
	fmul.4s	v9, v9, v27
	fmul.4s	v18, v31, v18
	fmul.4s	v13, v12, v13
	fadd.4s	v4, v4, v13
	fadd.4s	v2, v2, v10
	fadd.4s	v5, v5, v18
	fmul.4s	v18, v31, v27
	fmul.4s	v27, v12, v14
	ldp	q10, q31, [x20, #320]
	fadd.4s	v6, v6, v11
	and.16b	v10, v1, v10
	and.16b	v31, v0, v31
	ldp	q11, q12, [x4, #320]
	and.16b	v12, v0, v12
	fadd.4s	v3, v3, v20
	and.16b	v20, v1, v11
	ldr	q11, [x26, #15376]
	ldr	q13, [x26, #15360]
	and.16b	v13, v1, v13
	and.16b	v11, v0, v11
	fadd.4s	v16, v16, v19
	ldr	q19, [x27, #15376]
	ldr	q14, [x27, #15360]
	and.16b	v14, v1, v14
	and.16b	v19, v0, v19
	fmul.4s	v15, v10, v13
	fadd.4s	v17, v17, v15
	fmul.4s	v15, v31, v11
	fmul.4s	v31, v31, v19
	fmul.4s	v10, v10, v14
	fmul.4s	v13, v20, v13
	fmul.4s	v11, v12, v11
	fadd.4s	v7, v7, v15
	fadd.4s	v5, v5, v11
	fadd.4s	v4, v4, v13
	fmul.4s	v20, v20, v14
	fmul.4s	v19, v12, v19
	fadd.4s	v6, v6, v9
	ldp	q11, q9, [x20, #352]
	and.16b	v9, v0, v9
	and.16b	v11, v1, v11
	ldp	q13, q12, [x4, #352]
	fadd.4s	v2, v2, v28
	and.16b	v28, v1, v13
	and.16b	v12, v0, v12
	ldr	q13, [x26, #16896]
	ldr	q14, [x26, #16912]
	and.16b	v14, v0, v14
	fadd.4s	v16, v16, v27
	and.16b	v27, v1, v13
	ldr	q13, [x27, #16896]
	ldr	q15, [x27, #16912]
	and.16b	v15, v0, v15
	and.16b	v13, v1, v13
	fadd.4s	v3, v3, v18
	fmul.4s	v18, v9, v14
	fadd.4s	v7, v7, v18
	fmul.4s	v18, v11, v27
	fmul.4s	v11, v11, v13
	fmul.4s	v9, v9, v15
	fadd.4s	v17, v17, v18
	fmul.4s	v18, v12, v14
	fmul.4s	v27, v28, v27
	fadd.4s	v4, v4, v27
	fadd.4s	v5, v5, v18
	fmul.4s	v18, v12, v15
	fadd.4s	v2, v2, v10
	fmul.4s	v27, v28, v13
	ldp	q10, q28, [x20, #384]
	and.16b	v10, v1, v10
	and.16b	v28, v0, v28
	fadd.4s	v6, v6, v31
	ldp	q31, q12, [x4, #384]
	and.16b	v12, v0, v12
	and.16b	v31, v1, v31
	ldr	q13, [x26, #18448]
	fadd.4s	v3, v3, v19
	ldr	q19, [x26, #18432]
	and.16b	v19, v1, v19
	and.16b	v13, v0, v13
	ldr	q14, [x27, #18448]
	ldr	q15, [x27, #18432]
	fadd.4s	v16, v16, v20
	and.16b	v20, v1, v15
	and.16b	v14, v0, v14
	fmul.4s	v15, v10, v19
	fadd.4s	v17, v17, v15
	fmul.4s	v15, v28, v13
	fadd.4s	v7, v7, v15
	fmul.4s	v28, v28, v14
	fmul.4s	v10, v10, v20
	fmul.4s	v19, v31, v19
	fmul.4s	v13, v12, v13
	fadd.4s	v5, v5, v13
	fadd.4s	v6, v6, v9
	fadd.4s	v4, v4, v19
	fmul.4s	v19, v31, v20
	fmul.4s	v20, v12, v14
	ldp	q31, q9, [x20, #416]
	fadd.4s	v2, v2, v11
	and.16b	v9, v0, v9
	and.16b	v31, v1, v31
	ldp	q12, q11, [x4, #416]
	and.16b	v12, v1, v12
	fadd.4s	v16, v16, v27
	and.16b	v27, v0, v11
	ldr	q11, [x26, #19968]
	ldr	q13, [x26, #19984]
	and.16b	v13, v0, v13
	and.16b	v11, v1, v11
	fadd.4s	v3, v3, v18
	ldr	q18, [x27, #19968]
	ldr	q14, [x27, #19984]
	fmul.4s	v15, v9, v13
	fadd.4s	v7, v7, v15
	fmul.4s	v15, v31, v11
	fadd.4s	v17, v17, v15
	and.16b	v14, v0, v14
	and.16b	v18, v1, v18
	fmul.4s	v31, v31, v18
	fmul.4s	v9, v9, v14
	fmul.4s	v13, v27, v13
	fadd.4s	v2, v2, v10
	fmul.4s	v10, v12, v11
	fadd.4s	v10, v4, v10
	fadd.4s	v4, v5, v13
	fmul.4s	v5, v27, v14
	fmul.4s	v18, v12, v18
	fadd.4s	v6, v6, v28
	ldp	q28, q27, [x20, #448]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	fadd.4s	v3, v3, v20
	ldp	q11, q20, [x4, #448]
	and.16b	v20, v0, v20
	and.16b	v11, v1, v11
	ldr	q12, [x26, #21520]
	ldr	q13, [x26, #21504]
	fadd.4s	v16, v16, v19
	and.16b	v19, v1, v13
	and.16b	v12, v0, v12
	ldr	q13, [x27, #21520]
	ldr	q14, [x27, #21504]
	and.16b	v14, v1, v14
	fadd.4s	v6, v6, v9
	and.16b	v9, v0, v13
	fmul.4s	v13, v28, v19
	fadd.4s	v17, v17, v13
	fmul.4s	v13, v27, v12
	fadd.4s	v7, v7, v13
	fadd.4s	v2, v2, v31
	fmul.4s	v31, v27, v9
	fmul.4s	v28, v28, v14
	fmul.4s	v19, v11, v19
	fmul.4s	v27, v20, v12
	fadd.4s	v4, v4, v27
	fadd.4s	v16, v16, v18
	fadd.4s	v18, v10, v19
	fmul.4s	v19, v11, v14
	fmul.4s	v20, v20, v9
	ldp	q27, q9, [x20, #480]
	fadd.4s	v3, v3, v5
	and.16b	v5, v0, v9
	and.16b	v9, v1, v27
	ldp	q27, q10, [x4, #480]
	and.16b	v27, v1, v27
	fadd.4s	v2, v2, v28
	ldr	q28, [x26, #23040]
	ldr	q11, [x26, #23056]
	and.16b	v11, v0, v11
	and.16b	v28, v1, v28
	ldr	q12, [x27, #23040]
	fadd.4s	v6, v6, v31
	ldr	q31, [x27, #23056]
	and.16b	v31, v0, v31
	fmul.4s	v13, v9, v28
	fmul.4s	v14, v5, v11
	lsl	x10, x6, #5
	fadd.4s	v3, v3, v20
	add	x4, x5, x10
	fadd.4s	v7, v7, v14
	fadd.4s	v17, v17, v13
	ldp	q13, q20, [x4]
	fadd.4s	v16, v16, v19
	add	x10, x2, x10
	fmul.4s	v5, v5, v31
	bif.16b	v17, v13, v1
	ldp	q13, q19, [x10]
	fadd.4s	v5, v6, v5
	and.16b	v6, v0, v10
	and.16b	v10, v1, v12
	fmul.4s	v9, v9, v10
	bif.16b	v7, v20, v0
	stp	q17, q7, [x4]
	fadd.4s	v2, v2, v9
	fmul.4s	v7, v6, v11
	bif.16b	v2, v13, v1
	bif.16b	v5, v19, v0
	stp	q2, q5, [x10]
	fmul.4s	v2, v27, v28
	fadd.4s	v2, v18, v2
	fadd.4s	v4, v4, v7
	fmul.4s	v5, v6, v31
	ldp	q6, q7, [x24, #-32]
	ldp	q17, q18, [x24]
	fmul.4s	v19, v27, v10
	fadd.4s	v16, v16, v19
	fadd.4s	v3, v3, v5
	add	x6, x6, #2
	bif.16b	v4, v7, v0
	bif.16b	v2, v6, v1
	bif.16b	v3, v18, v0
	mov.16b	v5, v1
	bsl.16b	v5, v16, v17
	stp	q2, q4, [x24, #-32]
	stp	q5, q3, [x24], #64
	add	x19, x19, #2
	add	x7, x7, #64
	cmp	x6, #48
	b.ne	LBB0_435
; %bb.436:                              ; %direct.false1433
                                        ;   in Loop: Header=BB0_434 Depth=2
	add	x15, x15, #1
	add	x9, x9, #96
	add	x5, x5, #3072
	add	x2, x2, #3072
	add	x1, x1, #96
	add	x0, x0, #3072
	add	x16, x16, #3072
	cmp	x15, #4
	b.ne	LBB0_434
; %bb.437:                              ; %direct.true1819.preheader
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov	w9, #384                        ; =0x180
	mov	x15, x8
	mov	w16, #23680                     ; =0x5c80
	movk	w16, #1, lsl #16
LBB0_438:                               ; %direct.true1819
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x15, x16
	ldp	q2, q3, [x10]
	ldr	q4, [x15, #20480]
	ldr	q5, [x15, #20496]
	bif.16b	v3, v5, v0
	bif.16b	v2, v4, v1
	str	q2, [x15, #20480]
	str	q3, [x15, #20496]
	add	x15, x15, #32
	subs	x9, x9, #1
	b.ne	LBB0_438
; %bb.439:                              ; %direct.true1835.preheader
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q30, [sp, #7904]                ; 16-byte Spill
	str	q29, [sp, #7920]                ; 16-byte Spill
	str	q22, [sp, #7984]                ; 16-byte Spill
	str	q26, [sp, #8000]                ; 16-byte Spill
	mov	x9, x8
	mov	w15, #384                       ; =0x180
	ldr	x30, [sp, #3576]                ; 8-byte Reload
	ldr	x2, [sp, #3528]                 ; 8-byte Reload
	ldr	x4, [sp, #3520]                 ; 8-byte Reload
	ldr	x5, [sp, #8024]                 ; 8-byte Reload
LBB0_440:                               ; %direct.true1835
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x9, #20480]
	ldr	q3, [x9, #20496]
	ldr	q4, [x9, #8192]
	ldr	q5, [x9, #8208]
	bif.16b	v3, v5, v0
	bif.16b	v2, v4, v1
	str	q2, [x9, #8192]
	str	q3, [x9, #8208]
	add	x9, x9, #32
	subs	x15, x15, #1
	b.ne	LBB0_440
; %bb.441:                              ; %direct.false1836
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q2, [sp, #9232]                 ; 16-byte Reload
	ldr	q3, [sp, #7840]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #9232]                 ; 16-byte Spill
	ldr	q2, [sp, #9248]                 ; 16-byte Reload
	ldr	q3, [sp, #7872]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #9248]                 ; 16-byte Spill
	ldr	q2, [sp, #9456]                 ; 16-byte Reload
	ldr	q3, [sp, #7824]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #9456]                 ; 16-byte Spill
	ldr	q2, [sp, #9472]                 ; 16-byte Reload
	ldr	q3, [sp, #7856]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #9472]                 ; 16-byte Spill
	ldr	q2, [sp, #9488]                 ; 16-byte Reload
	ldr	q3, [sp, #9072]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #9488]                 ; 16-byte Spill
	ldr	q2, [sp, #9504]                 ; 16-byte Reload
	ldr	q3, [sp, #9168]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #9504]                 ; 16-byte Spill
	ldr	q2, [sp, #9520]                 ; 16-byte Reload
	ldr	q3, [sp, #9056]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #9520]                 ; 16-byte Spill
	ldr	q2, [sp, #9536]                 ; 16-byte Reload
	ldr	q3, [sp, #9152]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #9536]                 ; 16-byte Spill
	ldr	q2, [sp, #9552]                 ; 16-byte Reload
	ldr	q3, [sp, #9040]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #9552]                 ; 16-byte Spill
	ldr	q2, [sp, #9568]                 ; 16-byte Reload
	ldr	q3, [sp, #9136]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #9568]                 ; 16-byte Spill
	ldr	q2, [sp, #9584]                 ; 16-byte Reload
	ldr	q3, [sp, #9024]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #9584]                 ; 16-byte Spill
	ldr	q2, [sp, #9600]                 ; 16-byte Reload
	ldr	q3, [sp, #9120]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #9600]                 ; 16-byte Spill
	ldr	q2, [sp, #9616]                 ; 16-byte Reload
	ldr	q3, [sp, #9008]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #9616]                 ; 16-byte Spill
	ldr	q2, [sp, #9632]                 ; 16-byte Reload
	ldr	q3, [sp, #9104]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #9632]                 ; 16-byte Spill
	ldr	q2, [sp, #9664]                 ; 16-byte Reload
	ldr	q3, [sp, #8992]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #9664]                 ; 16-byte Spill
	ldr	q2, [sp, #9648]                 ; 16-byte Reload
	ldr	q3, [sp, #9088]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #9648]                 ; 16-byte Spill
	ldr	q2, [sp, #4080]                 ; 16-byte Reload
	fadd.4s	v2, v2, v8
	ldr	q3, [sp, #3824]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #4208]                 ; 16-byte Reload
	fadd.4s	v3, v3, v8
	ldr	q4, [sp, #4064]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #3808]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4192]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4032]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4048]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #3792]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4176]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4000]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4016]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #3776]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4160]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #3968]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #3984]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #3760]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4144]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #3936]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #3952]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #3744]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #3904]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #3920]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #3728]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4112]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #3872]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #3888]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #3712]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4096]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #3840]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #3856]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #9344]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #9344]                 ; 16-byte Spill
	ldr	q3, [sp, #9328]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #9328]                 ; 16-byte Spill
	ldr	q2, [sp, #4592]                 ; 16-byte Reload
	fadd.4s	v2, v2, v8
	ldr	q3, [sp, #4336]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #4720]                 ; 16-byte Reload
	fadd.4s	v3, v3, v8
	ldr	q4, [sp, #4576]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4320]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4704]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4544]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4560]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4304]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4688]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4512]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4528]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4288]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4672]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4480]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4496]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4272]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4656]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4448]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4464]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4256]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4640]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4416]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4432]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4240]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4624]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4384]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4400]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4224]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4608]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4352]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4368]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #9312]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #9312]                 ; 16-byte Spill
	ldr	q3, [sp, #9296]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #9296]                 ; 16-byte Spill
	ldr	q2, [sp, #5104]                 ; 16-byte Reload
	fadd.4s	v2, v2, v8
	ldr	q3, [sp, #4848]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	fadd.4s	v3, v21, v8
	ldr	q4, [sp, #5088]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4832]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #5216]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #5056]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #5072]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4816]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #5200]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #5024]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #5040]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4800]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #5184]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4992]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #5008]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4784]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #5168]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4960]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4976]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4768]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #5152]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4928]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4944]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4752]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #5136]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4896]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4912]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4736]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #5120]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4864]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4880]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #9280]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #9280]                 ; 16-byte Spill
	ldr	q3, [sp, #9264]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #9264]                 ; 16-byte Spill
	ldr	q2, [sp, #5600]                 ; 16-byte Reload
	fadd.4s	v2, v2, v8
	ldr	q3, [sp, #5344]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #5728]                 ; 16-byte Reload
	fadd.4s	v3, v3, v8
	ldr	q4, [sp, #5584]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #5328]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #5712]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #5552]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #5568]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #5312]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #5696]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #5520]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #5536]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #5296]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #5680]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #5488]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #5504]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #5280]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #5664]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #5456]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #5472]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #5264]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #5648]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #5424]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #5440]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #5248]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #5632]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #5392]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #5408]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #5232]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #5616]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #5360]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #5376]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #9440]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #9440]                 ; 16-byte Spill
	ldr	q3, [sp, #9424]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #9424]                 ; 16-byte Spill
	ldr	q2, [sp, #6112]                 ; 16-byte Reload
	fadd.4s	v2, v2, v8
	ldr	q3, [sp, #5856]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6240]                 ; 16-byte Reload
	fadd.4s	v3, v3, v8
	ldr	q4, [sp, #6096]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #5840]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #6224]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6064]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6080]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #5824]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #6208]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6032]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6048]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #5808]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #6192]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6000]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6016]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #5792]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #6176]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #5968]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #5984]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #5776]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #6160]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #5936]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #5952]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #5760]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #6144]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #5904]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #5920]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #5744]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #6128]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #5872]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #5888]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #9408]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #9408]                 ; 16-byte Spill
	ldr	q3, [sp, #9392]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #9392]                 ; 16-byte Spill
	ldr	q2, [sp, #6624]                 ; 16-byte Reload
	fadd.4s	v2, v2, v8
	ldr	q3, [sp, #6368]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #6752]                 ; 16-byte Reload
	fadd.4s	v3, v3, v8
	ldr	q4, [sp, #6608]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #6352]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #6736]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6576]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6592]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #6336]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #6720]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6544]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6560]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #6320]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #6704]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6512]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6528]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #6304]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #6688]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6480]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6496]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #6288]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #6672]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6448]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6464]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #6272]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #6656]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6416]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6432]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #6256]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #6640]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6384]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6400]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #9376]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #9376]                 ; 16-byte Spill
	ldr	q3, [sp, #9360]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #9360]                 ; 16-byte Spill
	ldr	q2, [sp, #7040]                 ; 16-byte Reload
	fadd.4s	v2, v2, v8
	ldr	q3, [sp, #6848]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #7152]                 ; 16-byte Reload
	fadd.4s	v3, v3, v8
	ldr	q4, [sp, #7024]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #6832]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #7136]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6992]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #7008]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #6816]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #7120]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6960]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6976]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #6800]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #7104]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6928]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6944]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #6784]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #7088]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6896]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6912]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #6768]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #7072]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6864]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #6880]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #7248]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #7264]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #7200]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #7216]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #7056]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #7232]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #7168]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #7184]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q28, [sp, #8672]                ; 16-byte Reload
	bit.16b	v28, v3, v1
	ldr	q12, [sp, #8656]                ; 16-byte Reload
	bit.16b	v12, v2, v0
	fadd.4s	v2, v23, v8
	ldr	q3, [sp, #7424]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	fadd.4s	v3, v24, v8
	ldr	q4, [sp, #7632]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #7408]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #7744]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #7600]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #7616]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #7392]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #7728]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #7568]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #7584]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #7376]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #7712]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #7536]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #7552]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #7360]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #7696]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #7504]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #7520]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #7344]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #7680]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #7472]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #7488]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #7328]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #7664]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #7440]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #7456]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #7312]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #7648]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #7280]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #7296]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #8640]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	ldr	q16, [sp, #8624]                ; 16-byte Reload
	bit.16b	v16, v2, v0
	ldr	q19, [sp, #8048]                ; 16-byte Reload
	ldr	q2, [sp, #9200]                 ; 16-byte Reload
	fmul.4s	v31, v19, v2
	ldr	q20, [sp, #8032]                ; 16-byte Reload
	ldr	q2, [sp, #9184]                 ; 16-byte Reload
	fmul.4s	v14, v20, v2
	ldr	q17, [sp, #8080]                ; 16-byte Reload
	ldr	q2, [sp, #8960]                 ; 16-byte Reload
	fmul.4s	v27, v17, v2
	ldr	q18, [sp, #8064]                ; 16-byte Reload
	ldr	q2, [sp, #8976]                 ; 16-byte Reload
	fmul.4s	v10, v18, v2
	ldr	q6, [sp, #8112]                 ; 16-byte Reload
	ldr	q2, [sp, #8928]                 ; 16-byte Reload
	fmul.4s	v2, v6, v2
	str	q2, [sp, #9200]                 ; 16-byte Spill
	ldr	q7, [sp, #8096]                 ; 16-byte Reload
	ldr	q2, [sp, #8944]                 ; 16-byte Reload
	fmul.4s	v22, v7, v2
	ldr	q3, [sp, #8144]                 ; 16-byte Reload
	ldr	q2, [sp, #8896]                 ; 16-byte Reload
	fmul.4s	v2, v3, v2
	str	q2, [sp, #9184]                 ; 16-byte Spill
	ldr	q5, [sp, #8128]                 ; 16-byte Reload
	ldr	q2, [sp, #8912]                 ; 16-byte Reload
	fmul.4s	v13, v5, v2
	ldr	q21, [sp, #8176]                ; 16-byte Reload
	ldr	q2, [sp, #8864]                 ; 16-byte Reload
	fmul.4s	v2, v21, v2
	str	q2, [sp, #9152]                 ; 16-byte Spill
	ldr	q2, [sp, #8160]                 ; 16-byte Reload
	ldr	q23, [sp, #8880]                ; 16-byte Reload
	fmul.4s	v9, v2, v23
	ldr	q26, [sp, #8208]                ; 16-byte Reload
	ldr	q23, [sp, #8848]                ; 16-byte Reload
	fmul.4s	v23, v26, v23
	str	q23, [sp, #9136]                ; 16-byte Spill
	ldr	q24, [sp, #8192]                ; 16-byte Reload
	ldr	q23, [sp, #8832]                ; 16-byte Reload
	fmul.4s	v15, v24, v23
	ldr	q23, [sp, #8240]                ; 16-byte Reload
	ldr	q25, [sp, #7792]                ; 16-byte Reload
	fmul.4s	v25, v23, v25
	str	q25, [sp, #9120]                ; 16-byte Spill
	ldr	q25, [sp, #8224]                ; 16-byte Reload
	ldr	q29, [sp, #7808]                ; 16-byte Reload
	fmul.4s	v29, v25, v29
	str	q29, [sp, #9072]                ; 16-byte Spill
	ldr	q29, [sp, #8272]                ; 16-byte Reload
	ldr	q30, [sp, #7760]                ; 16-byte Reload
	fmul.4s	v30, v29, v30
	str	q30, [sp, #9104]                ; 16-byte Spill
	ldr	q30, [sp, #8256]                ; 16-byte Reload
	ldr	q11, [sp, #7776]                ; 16-byte Reload
	fmul.4s	v11, v30, v11
	str	q16, [sp, #8624]                ; 16-byte Spill
	fadd.4s	v16, v14, v16
	str	q16, [sp, #9168]                ; 16-byte Spill
	str	q4, [sp, #8640]                 ; 16-byte Spill
	fadd.4s	v4, v31, v4
	str	q12, [sp, #8656]                ; 16-byte Spill
	fadd.4s	v31, v10, v12
	str	q28, [sp, #8672]                ; 16-byte Spill
	fadd.4s	v27, v27, v28
	ldr	q16, [sp, #9360]                ; 16-byte Reload
	fadd.4s	v28, v22, v16
	ldr	q16, [sp, #9376]                ; 16-byte Reload
	ldr	q22, [sp, #9200]                ; 16-byte Reload
	fadd.4s	v16, v22, v16
	ldr	q22, [sp, #9392]                ; 16-byte Reload
	fadd.4s	v22, v13, v22
	str	q22, [sp, #9200]                ; 16-byte Spill
	ldr	q22, [sp, #9408]                ; 16-byte Reload
	ldr	q10, [sp, #9184]                ; 16-byte Reload
	fadd.4s	v10, v10, v22
	ldr	q22, [sp, #9424]                ; 16-byte Reload
	fadd.4s	v22, v9, v22
	str	q22, [sp, #9088]                ; 16-byte Spill
	ldr	q22, [sp, #9440]                ; 16-byte Reload
	ldr	q9, [sp, #9152]                 ; 16-byte Reload
	fadd.4s	v9, v9, v22
	ldr	q22, [sp, #9264]                ; 16-byte Reload
	fadd.4s	v22, v15, v22
	str	q22, [sp, #9184]                ; 16-byte Spill
	ldr	q22, [sp, #9280]                ; 16-byte Reload
	ldr	q13, [sp, #9136]                ; 16-byte Reload
	fadd.4s	v15, v13, v22
	ldr	q22, [sp, #9296]                ; 16-byte Reload
	ldr	q12, [sp, #9072]                ; 16-byte Reload
	fadd.4s	v14, v12, v22
	ldr	q22, [sp, #9312]                ; 16-byte Reload
	ldr	q13, [sp, #9120]                ; 16-byte Reload
	fadd.4s	v13, v13, v22
	ldr	q22, [sp, #9328]                ; 16-byte Reload
	fadd.4s	v11, v11, v22
	ldr	q22, [sp, #9344]                ; 16-byte Reload
	ldr	q12, [sp, #9104]                ; 16-byte Reload
	fadd.4s	v22, v12, v22
	add	x5, x5, #1
	str	q4, [sp, #9056]                 ; 16-byte Spill
	bit.16b	v19, v4, v1
	ldr	q4, [sp, #9168]                 ; 16-byte Reload
	str	q19, [sp, #8048]                ; 16-byte Spill
	mov.16b	v19, v14
	bit.16b	v20, v4, v0
	str	q20, [sp, #8032]                ; 16-byte Spill
	str	q27, [sp, #9072]                ; 16-byte Spill
	bit.16b	v17, v27, v1
	ldr	q27, [sp, #9088]                ; 16-byte Reload
	str	q17, [sp, #8080]                ; 16-byte Spill
	bit.16b	v18, v31, v0
	str	q18, [sp, #8064]                ; 16-byte Spill
	mov.16b	v18, v13
	str	q16, [sp, #9104]                ; 16-byte Spill
	bit.16b	v6, v16, v1
	str	q6, [sp, #8112]                 ; 16-byte Spill
	str	q28, [sp, #9120]                ; 16-byte Spill
	bit.16b	v7, v28, v0
	str	q7, [sp, #8096]                 ; 16-byte Spill
	str	q10, [sp, #9136]                ; 16-byte Spill
	bit.16b	v3, v10, v1
	ldr	q10, [sp, #9200]                ; 16-byte Reload
	ldr	q28, [sp, #9184]                ; 16-byte Reload
	str	q3, [sp, #8144]                 ; 16-byte Spill
	bit.16b	v5, v10, v0
	str	q5, [sp, #8128]                 ; 16-byte Spill
	mov.16b	v5, v22
	str	q9, [sp, #9152]                 ; 16-byte Spill
	bit.16b	v21, v9, v1
	str	q21, [sp, #8176]                ; 16-byte Spill
	bit.16b	v2, v27, v0
	str	q2, [sp, #8160]                 ; 16-byte Spill
	mov.16b	v9, v15
	bit.16b	v26, v15, v1
	str	q26, [sp, #8208]                ; 16-byte Spill
	bit.16b	v24, v28, v0
	str	q24, [sp, #8192]                ; 16-byte Spill
	bit.16b	v23, v13, v1
	str	q23, [sp, #8240]                ; 16-byte Spill
	bit.16b	v25, v14, v0
	str	q25, [sp, #8224]                ; 16-byte Spill
	bit.16b	v29, v22, v1
	str	q29, [sp, #8272]                ; 16-byte Spill
	mov.16b	v16, v11
	bit.16b	v30, v11, v0
	str	q30, [sp, #8256]                ; 16-byte Spill
	cmp	x5, #9
	ldr	q20, [sp, #8784]                ; 16-byte Reload
	ldr	q23, [sp, #8768]                ; 16-byte Reload
	ldr	x28, [sp, #3640]                ; 8-byte Reload
	ldr	q21, [sp, #3584]                ; 16-byte Reload
	ldr	q6, [sp, #3040]                 ; 16-byte Reload
	ldr	q7, [sp, #1248]                 ; 16-byte Reload
	ldr	q11, [sp, #1232]                ; 16-byte Reload
	ldr	q25, [sp, #9216]                ; 16-byte Reload
	ldr	q26, [sp, #8000]                ; 16-byte Reload
	ldr	q22, [sp, #7984]                ; 16-byte Reload
	ldr	q13, [sp, #7968]                ; 16-byte Reload
	ldr	q14, [sp, #7952]                ; 16-byte Reload
	ldr	q15, [sp, #7936]                ; 16-byte Reload
	ldr	q29, [sp, #7920]                ; 16-byte Reload
	ldr	q30, [sp, #7904]                ; 16-byte Reload
	ldr	q24, [sp, #7888]                ; 16-byte Reload
	b.ne	LBB0_28
; %bb.442:                              ; %direct.false211
	mov	x9, #0                          ; =0x0
	add	x10, x8, #24, lsl #12           ; =98304
	add	x10, x10, #3200
	ldp	q7, q2, [x10]
	sshll.2d	v22, v1, #0
	sshll.2d	v6, v0, #0
	bit.16b	v2, v4, v0
	ldr	q3, [sp, #9056]                 ; 16-byte Reload
	mov.16b	v4, v1
	bsl.16b	v4, v3, v7
	stp	q4, q2, [x10]
	add	x10, x8, #24, lsl #12           ; =98304
	add	x10, x10, #3232
	ldp	q4, q7, [x10]
	mov.16b	v3, v0
	bsl.16b	v3, v31, v7
	ldr	q2, [sp, #9072]                 ; 16-byte Reload
	bif.16b	v2, v4, v1
	stp	q2, q3, [x10]
	add	x10, x8, #24, lsl #12           ; =98304
	add	x10, x10, #3264
	ldp	q2, q3, [x10]
	ldr	q4, [sp, #9120]                 ; 16-byte Reload
	bit.16b	v3, v4, v0
	ldr	q4, [sp, #9104]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	stp	q2, q3, [x10]
	add	x10, x8, #24, lsl #12           ; =98304
	add	x10, x10, #3296
	ldp	q2, q3, [x10]
	bit.16b	v3, v10, v0
	ldr	q4, [sp, #9136]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	stp	q2, q3, [x10]
	add	x10, x8, #24, lsl #12           ; =98304
	add	x10, x10, #3328
	ldp	q2, q3, [x10]
	bit.16b	v3, v27, v0
	ldr	q4, [sp, #9152]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	stp	q2, q3, [x10]
	add	x10, x8, #24, lsl #12           ; =98304
	add	x10, x10, #3360
	ldp	q2, q3, [x10]
	bit.16b	v3, v28, v0
	bit.16b	v2, v9, v1
	stp	q2, q3, [x10]
	add	x10, x8, #24, lsl #12           ; =98304
	add	x10, x10, #3392
	ldp	q2, q3, [x10]
	bit.16b	v3, v19, v0
	bit.16b	v2, v18, v1
	add	x8, x8, #24, lsl #12            ; =98304
	add	x11, x8, #3424
	ldp	q4, q7, [x11]
	bit.16b	v7, v16, v0
	mov.16b	v16, v1
	bsl.16b	v16, v5, v4
	ldr	q4, [sp, #128]                  ; 16-byte Reload
	shl.2d	v4, v4, #6
	ldr	q5, [sp, #64]                   ; 16-byte Reload
	shl.2d	v17, v5, #6
	ldr	q5, [sp, #144]                  ; 16-byte Reload
	shl.2d	v18, v5, #6
	ldr	q5, [sp, #32]                   ; 16-byte Reload
	shl.2d	v19, v5, #6
	ldr	q5, [sp, #48]                   ; 16-byte Reload
	orr.16b	v19, v19, v5
	ldr	q5, [sp, #96]                   ; 16-byte Reload
	orr.16b	v18, v18, v5
	ldr	q5, [sp, #80]                   ; 16-byte Reload
	orr.16b	v17, v17, v5
	ldr	q5, [sp, #112]                  ; 16-byte Reload
	orr.16b	v4, v4, v5
	stp	q2, q3, [x10]
	and.16b	v2, v20, v4
	and.16b	v3, v6, v17
	and.16b	v4, v22, v18
	and.16b	v5, v23, v19
	mov	w8, #43691                      ; =0xaaab
	stp	q16, q7, [x11]
	mov	w10, #48                        ; =0x30
	ldp	x17, x16, [sp, #16]             ; 16-byte Folded Reload
	ldr	q21, [sp, #10080]               ; 16-byte Reload
	b	LBB0_444
LBB0_443:                               ; %else1340
                                        ;   in Loop: Header=BB0_444 Depth=1
	add	x9, x9, #1
	cmp	x9, #384
	b.eq	LBB0_460
LBB0_444:                               ; %direct.true1946
                                        ; =>This Inner Loop Header: Depth=1
	fmov	w11, s21
	and	w13, w9, #0xffff
	mul	w13, w13, w8
	lsr	w13, w13, #21
	dup.2d	v6, x13
	add.2d	v7, v4, v6
	mov.d	x14, v7[1]
	fmov	x15, d7
	add	x15, x15, x15, lsl #1
	lsl	x15, x15, #4
	fmov	d16, x15
	msub	w15, w13, w10, w9
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #4
	mov.d	v16[1], x14
	and	x14, x15, #0xffff
	dup.2d	v7, x14
	add.2d	v16, v16, v7
	umaddl	x14, w13, w10, x14
	add	x14, x12, x14, lsl #5
	ldp	q18, q17, [x14]
	and.16b	v19, v1, v18
	add	x13, x16, x13, lsl #5
	ldp	q20, q18, [x13]
	and.16b	v20, v1, v20
	fdiv.4s	v19, v19, v20
	shl.2d	v20, v16, #2
	dup.2d	v16, x17
	add.2d	v20, v16, v20
	tbz	w11, #0, LBB0_446
; %bb.445:                              ; %cond.store1309
                                        ;   in Loop: Header=BB0_444 Depth=1
	fmov	x13, d20
	str	s19, [x13]
LBB0_446:                               ; %else1312
                                        ;   in Loop: Header=BB0_444 Depth=1
	and	w11, w11, #0xff
	tbz	w11, #1, LBB0_448
; %bb.447:                              ; %cond.store1313
                                        ;   in Loop: Header=BB0_444 Depth=1
	mov.d	x13, v20[1]
	st1.s	{ v19 }[1], [x13]
LBB0_448:                               ; %else1316
                                        ;   in Loop: Header=BB0_444 Depth=1
	add.2d	v20, v2, v6
	mov.d	x13, v20[1]
	fmov	x14, d20
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #4
	fmov	d20, x14
	add	x13, x13, x13, lsl #1
	lsl	x13, x13, #4
	mov.d	v20[1], x13
	add.2d	v20, v20, v7
	shl.2d	v20, v20, #2
	add.2d	v20, v16, v20
	tbz	w11, #2, LBB0_450
; %bb.449:                              ; %cond.store1317
                                        ;   in Loop: Header=BB0_444 Depth=1
	fmov	x13, d20
	st1.s	{ v19 }[2], [x13]
LBB0_450:                               ; %else1320
                                        ;   in Loop: Header=BB0_444 Depth=1
	tbz	w11, #3, LBB0_452
; %bb.451:                              ; %cond.store1321
                                        ;   in Loop: Header=BB0_444 Depth=1
	mov.d	x13, v20[1]
	st1.s	{ v19 }[3], [x13]
LBB0_452:                               ; %else1324
                                        ;   in Loop: Header=BB0_444 Depth=1
	add.2d	v19, v3, v6
	mov.d	x13, v19[1]
	fmov	x14, d19
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #4
	fmov	d19, x14
	add	x13, x13, x13, lsl #1
	lsl	x13, x13, #4
	mov.d	v19[1], x13
	add.2d	v19, v19, v7
	and.16b	v17, v0, v17
	and.16b	v18, v0, v18
	fdiv.4s	v17, v17, v18
	shl.2d	v18, v19, #2
	add.2d	v18, v16, v18
	tbz	w11, #4, LBB0_454
; %bb.453:                              ; %cond.store1325
                                        ;   in Loop: Header=BB0_444 Depth=1
	fmov	x13, d18
	str	s17, [x13]
LBB0_454:                               ; %else1328
                                        ;   in Loop: Header=BB0_444 Depth=1
	tbz	w11, #5, LBB0_456
; %bb.455:                              ; %cond.store1329
                                        ;   in Loop: Header=BB0_444 Depth=1
	mov.d	x13, v18[1]
	st1.s	{ v17 }[1], [x13]
LBB0_456:                               ; %else1332
                                        ;   in Loop: Header=BB0_444 Depth=1
	add.2d	v6, v5, v6
	mov.d	x13, v6[1]
	fmov	x14, d6
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #4
	fmov	d6, x14
	add	x13, x13, x13, lsl #1
	lsl	x13, x13, #4
	mov.d	v6[1], x13
	add.2d	v6, v6, v7
	shl.2d	v6, v6, #2
	add.2d	v6, v16, v6
	tbz	w11, #6, LBB0_458
; %bb.457:                              ; %cond.store1333
                                        ;   in Loop: Header=BB0_444 Depth=1
	fmov	x13, d6
	st1.s	{ v17 }[2], [x13]
	tbz	w11, #7, LBB0_443
	b	LBB0_459
LBB0_458:                               ; %else1336
                                        ;   in Loop: Header=BB0_444 Depth=1
	tbz	w11, #7, LBB0_443
LBB0_459:                               ; %cond.store1337
                                        ;   in Loop: Header=BB0_444 Depth=1
	mov.d	x11, v6[1]
	st1.s	{ v17 }[3], [x11]
	b	LBB0_443
LBB0_460:                               ; %common.ret
	add	sp, sp, #2, lsl #12             ; =8192
	add	sp, sp, #1936
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh145, Lloh149
	.loh AdrpLdr	Lloh144, Lloh148
	.loh AdrpLdr	Lloh143, Lloh147
	.loh AdrpLdr	Lloh142, Lloh146
	.loh AdrpAdrp	Lloh137, Lloh143
	.loh AdrpLdr	Lloh137, Lloh138
	.loh AdrpAdrp	Lloh136, Lloh142
	.loh AdrpLdr	Lloh136, Lloh141
	.loh AdrpAdrp	Lloh133, Lloh137
	.loh AdrpLdr	Lloh133, Lloh134
	.loh AdrpAdrp	Lloh132, Lloh136
	.loh AdrpLdr	Lloh132, Lloh135
	.loh AdrpLdr	Lloh131, Lloh140
	.loh AdrpLdr	Lloh130, Lloh139
	.loh AdrpAdrp	Lloh126, Lloh132
	.loh AdrpLdr	Lloh126, Lloh127
	.loh AdrpAdrp	Lloh125, Lloh131
	.loh AdrpLdr	Lloh125, Lloh129
	.loh AdrpAdrp	Lloh124, Lloh130
	.loh AdrpLdr	Lloh124, Lloh128
	.loh AdrpLdr	Lloh122, Lloh123
	.loh AdrpLdr	Lloh120, Lloh121
	.loh AdrpAdrp	Lloh118, Lloh126
	.loh AdrpLdr	Lloh118, Lloh119
	.loh AdrpAdrp	Lloh116, Lloh144
	.loh AdrpLdr	Lloh116, Lloh117
	.loh AdrpLdr	Lloh114, Lloh115
	.loh AdrpAdrp	Lloh112, Lloh116
	.loh AdrpLdr	Lloh112, Lloh113
	.loh AdrpLdr	Lloh110, Lloh111
	.loh AdrpAdrp	Lloh108, Lloh112
	.loh AdrpLdr	Lloh108, Lloh109
	.loh AdrpLdr	Lloh106, Lloh107
	.loh AdrpAdrp	Lloh104, Lloh108
	.loh AdrpLdr	Lloh104, Lloh105
	.loh AdrpLdr	Lloh102, Lloh103
	.loh AdrpAdrp	Lloh100, Lloh104
	.loh AdrpLdr	Lloh100, Lloh101
	.loh AdrpLdr	Lloh98, Lloh99
	.loh AdrpAdrp	Lloh96, Lloh100
	.loh AdrpLdr	Lloh96, Lloh97
	.loh AdrpLdr	Lloh94, Lloh95
	.loh AdrpLdr	Lloh92, Lloh93
	.loh AdrpLdr	Lloh90, Lloh91
	.loh AdrpLdr	Lloh88, Lloh89
	.loh AdrpLdr	Lloh86, Lloh87
	.loh AdrpAdrp	Lloh84, Lloh88
	.loh AdrpLdr	Lloh84, Lloh85
	.loh AdrpLdr	Lloh82, Lloh83
	.loh AdrpAdrp	Lloh80, Lloh82
	.loh AdrpLdr	Lloh80, Lloh81
	.loh AdrpLdr	Lloh78, Lloh79
	.loh AdrpAdrp	Lloh76, Lloh84
	.loh AdrpLdr	Lloh76, Lloh77
	.loh AdrpAdrp	Lloh74, Lloh76
	.loh AdrpLdr	Lloh74, Lloh75
	.loh AdrpAdrp	Lloh72, Lloh74
	.loh AdrpLdr	Lloh72, Lloh73
	.loh AdrpAdrp	Lloh70, Lloh72
	.loh AdrpLdr	Lloh70, Lloh71
	.loh AdrpAdrp	Lloh68, Lloh70
	.loh AdrpLdr	Lloh68, Lloh69
	.loh AdrpAdrp	Lloh66, Lloh68
	.loh AdrpLdr	Lloh66, Lloh67
	.loh AdrpAdrp	Lloh64, Lloh66
	.loh AdrpLdr	Lloh64, Lloh65
	.loh AdrpAdrp	Lloh62, Lloh64
	.loh AdrpLdr	Lloh62, Lloh63
	.loh AdrpAdrp	Lloh60, Lloh62
	.loh AdrpLdr	Lloh60, Lloh61
	.loh AdrpLdr	Lloh58, Lloh59
	.loh AdrpAdrp	Lloh56, Lloh58
	.loh AdrpLdr	Lloh56, Lloh57
	.loh AdrpLdr	Lloh54, Lloh55
	.loh AdrpLdr	Lloh52, Lloh53
	.loh AdrpAdrp	Lloh50, Lloh52
	.loh AdrpLdr	Lloh50, Lloh51
	.loh AdrpAdrp	Lloh48, Lloh50
	.loh AdrpLdr	Lloh48, Lloh49
	.loh AdrpAdrp	Lloh46, Lloh48
	.loh AdrpLdr	Lloh46, Lloh47
	.loh AdrpAdrp	Lloh44, Lloh46
	.loh AdrpLdr	Lloh44, Lloh45
	.loh AdrpAdrp	Lloh42, Lloh44
	.loh AdrpLdr	Lloh42, Lloh43
	.loh AdrpAdrp	Lloh40, Lloh42
	.loh AdrpLdr	Lloh40, Lloh41
	.loh AdrpAdrp	Lloh38, Lloh40
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpAdrp	Lloh36, Lloh38
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpAdrp	Lloh34, Lloh36
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpAdrp	Lloh32, Lloh34
	.loh AdrpLdr	Lloh32, Lloh33
	.loh AdrpAdrp	Lloh30, Lloh32
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdrp	Lloh28, Lloh30
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
                                        ; -- End function
	.globl	_llm_attention.packet_batch.blocks ; -- Begin function llm_attention.packet_batch.blocks
	.p2align	2
_llm_attention.packet_batch.blocks:     ; @llm_attention.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_3:                                 ; %llm_attention.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

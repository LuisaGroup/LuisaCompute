"""Bounded, read-only compiler-object/LLVM inspection; never loads native code."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
LLVM = Path('/opt/homebrew/opt/llvm/bin')
CASES = [('decode-mha-d64', 'm0-c0'), ('decode-mha-d64', 'm0-c4'),
         ('prefill-q4', 'm4-c4'), ('prefill-q4', 'm4-c4-simplified'),
         ('prefill-q8', 'm4-c4'), ('prefill-q8', 'm4-c4-simplified')]
FIELDS = ('native_mma_vector_width', 'native_copy_vector_width', 'native_copies',
          'interleaved_private_arrays', 'contiguous_private_reads', 'contiguous_private_writes',
          'static_snapshot_bytes_per_worker', 'static_snapshot_allocations', 'private_workspace_bytes',
          'full_packet_specializations', 'full_packet_cloned_instructions',
          'full_packet_source_instructions', 'full_packet_candidate_instructions', 'full_packet_simplification_rounds')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')


def command(label, argv, frozen):
    paths = [OUT / (label + suffix) for suffix in ('.command.json', '.result.json', '.stdout', '.stderr')]
    assert not any(path.exists() for path in paths)
    receipt = dict(argv=list(map(str, argv)), started=time.time(), timeout_s=20,
                   purpose='Static object disassembly/symbol inspection; no target-code execution',
                   tool_sha256=sha(Path(argv[0])), inputs_sha256=frozen)
    save(paths[0], receipt)
    result = subprocess.run(receipt['argv'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=20)
    for path, payload in zip(paths[2:], (result.stdout, result.stderr)):
        with path.open('xb') as stream:
            stream.write(payload)
    receipt.update(finished=time.time(), returncode=result.returncode,
                   stdout_sha256=sha(paths[2]), stderr_sha256=sha(paths[3]),
                   inputs_unchanged=all(sha(Path(path)) == digest for path, digest in frozen.items()))
    save(paths[1], receipt)
    assert result.returncode == 0 and not result.stderr and receipt['inputs_unchanged']
    return result.stdout.decode()


def functions(text):
    result = {}
    for match in re.finditer(r'^define ([^\n]*)@([-a-zA-Z$._0-9]+)\([^\n]*\) [^\n]*\{\n(.*?)^\}', text, re.M | re.S):
        name, body = match[2], match[3]
        assert name not in result
        instructions = [line for line in body.splitlines() if re.match(r'^  (?:%[^ ]+ = |(?:br|ret|store|call|unreachable|switch)\b)', line)]
        result[name] = dict(instructions=len(instructions),
                            blocks=len(re.findall(r'^[-a-zA-Z$._0-9]+:', body, re.M)),
                            masked_gathers=len(re.findall(r'\bcall\b[^\n]*@llvm\.masked\.gather\.', body)),
                            masked_scatters=len(re.findall(r'\bcall\b[^\n]*@llvm\.masked\.scatter\.', body)),
                            masked_loads=len(re.findall(r'\bcall\b[^\n]*@llvm\.masked\.load\.', body)),
                            masked_stores=len(re.findall(r'\bcall\b[^\n]*@llvm\.masked\.store\.', body)), body=body)
    return result


def main():
    report = dict(status='running', native_execution=False, metric='static code evidence, not measured cycles',
                  started=time.time(), variants=[], tool_commands=0)
    for case, variant in CASES:
        label = case + '-' + variant
        directory = ROOT / ('prepared-' + label)
        manifest = json.loads((directory / 'prepared.json').read_text())
        frozen = {str(directory / name): sha(directory / name) for name in ('prepared.json', 'kernel.ll', 'kernel.o')}
        assert all(frozen[str(directory / name)] == manifest['files'][name] for name in ('kernel.ll', 'kernel.o'))
        metadata = manifest['metadata']['realization']
        fields = {}
        for key in FIELDS:
            matches = re.findall(r'\b' + key + r'=(\d+)\b', metadata)
            assert len(matches) == 1
            fields[key] = int(matches[0])
        decisions = re.findall(r'\bfull_packet_specialization_decision=([a-z_]+)\b', metadata)
        assert len(decisions) == 1
        text = (directory / 'kernel.ll').read_text()
        bodies = functions(text)
        original = bodies['llm_attention']
        clone = bodies.get('llm_attention.full_packet')
        assert original['instructions'] == fields['full_packet_source_instructions']
        assert bool(clone) == bool(fields['full_packet_specializations'])
        if clone:
            assert clone['instructions'] == fields['full_packet_candidate_instructions'] <= 4096
            assert fields['full_packet_cloned_instructions'] == original['instructions'] <= 8192
        copies = {name: body['body'] for name, body in bodies.items() if '.contiguous_copy' in name}
        assert len(copies) == fields['native_copies']
        item = dict(case=case, variant=variant, frozen_inputs=frozen, fields=fields, decision=decisions[0],
                    actual_entry_symbol=manifest['symbol'], compile_ms=manifest['metadata']['compile_ms'],
                    captured_output_sha256=manifest['files']['captured.f32'],
                    functions={name: {k: v for k, v in body.items() if k != 'body'} for name, body in bodies.items()},
                    copy_helper_ir=copies, object_bytes=(directory / 'kernel.o').stat().st_size)
        if case == 'decode-mha-d64':
            assembly = command(label + '-objdump', [LLVM / 'llvm-objdump', '--disassemble', '--reloc', '--no-show-raw-insn', directory / 'kernel.o'], frozen)
            symbols = command(label + '-symbols', [LLVM / 'llvm-nm', '--defined-only', '--numeric-sort', directory / 'kernel.o'], frozen)
            imports = command(label + '-imports', [LLVM / 'llvm-nm', '--undefined-only', '--just-symbol-name', directory / 'kernel.o'], frozen)
            report['tool_commands'] += 3
            opcodes = Counter(re.findall(r'^\s*[0-9a-f]+:\s+([a-z][a-z0-9.]*)\s', assembly, re.M))
            item['machine_opcode_counts'] = dict(sorted(opcodes.items()))
            item['machine_call_lines'] = [line for line in assembly.splitlines() if re.search(r'\s(?:bl|blr)\s', line)]
            item['machine_copy_lane_store_lines'] = [line for line in assembly.splitlines() if re.search(r'\bst1\b', line)]
            item['defined_symbols'] = symbols.splitlines()
            item['undefined_symbols'] = imports.splitlines()
        assert all(sha(Path(path)) == digest for path, digest in frozen.items())
        report['variants'].append(item)
    report.update(status='passed', finished=time.time(),
                  interpretation='LLVM dump is pre-target O1/O2, after optional local candidate simplification; function counts exclude separately emitted helper bodies. Actual ORC object disassembly is post-codegen. Static evidence does not allocate measured time to a phase or prove speedups.')
    save(OUT / 'summary.json', report)
    print(json.dumps(dict(status=report['status'], variants=len(report['variants']), commands=report['tool_commands'],
                          elapsed_s=report['finished'] - report['started'], summary_sha256=sha(OUT / 'summary.json')), indent=2))


if __name__ == '__main__':
    main()

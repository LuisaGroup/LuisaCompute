# Joint copy / MMA：实际 LLVM 与 native object 的有界只读核查

本核查不执行目标 native code，不生成性能数据，不修改 frozen producer、实验脚本或已有结果。证据是本 cohort 的六份实际 `kernel.ll` / `kernel.o` / `prepared.json`；解码 MHA 的两份 object 另由 `llvm-objdump` 和 `llvm-nm` 各检查一次。

机器可读回执：[summary.json](summary.json)，SHA256 `02a8320b1614910084585d3aaa9ac36abab8b55cab2445dc4c0334c1800132ca`。六条静态工具命令的 argv、工具 SHA256、输入 SHA256、stdout / stderr SHA256、返回码和输入不变检查均保存在本目录。全部返回 0、stderr 为空；合计 0.622 秒。此时间是检查工具耗时，不是 kernel 时间。

## 1. M0C4 的 copy 保留了 consumer layout

实际比较 `prepared-decode-mha-d64-m0-c0` 和 `prepared-decode-mha-d64-m0-c4`：

| 项目 | M0C0 | M0C4 |
|---|---:|---:|
| native copy helpers | 0 | 2 |
| interleaved private arrays | 4 | 4 |
| contiguous private reads | 2050 | 2050 |
| contiguous private writes | 34 | 32 |
| snapshot bytes / worker | 8320 | 8320 |
| snapshot allocations | 4 | 4 |
| private workspace bytes | 66560 | 66560 |
| original entry IR instructions | 42529 | 41527 |
| original entry blocks | 29 | 51 |
| original entry masked gather / scatter calls | 66 / 64 | 64 / 64 |
| relocatable object bytes | 126976 | 127296 |

两臂 captured FP32 output 的 SHA256 相同：`c132ae27c97850b4f9cafa3bba0a3b22a553382fc219b1071d87fbfe1c82f847`。完整 same-MMA 数学与资源 guards 由主 cohort audit 负责；此处是独立实际代码佐证。

C4 两个 LLVM copy helper 都是 256 次循环、每次源 `load <4 x i32>`，四个结果分别写入目标 `(4*j+i)*8` 个 i32 的位置。传入 helper 的目标指针已经选择 program lane。因此物理地址为：

```
source(j, i)      = source_base + 4 * (source_offset + 4*j + i)
destination(j,i) = allocation_base + 4 * ((4*j + i)*8 + program_lane)
```

其中 `0 <= j < 256`、`0 <= i < 4`。这是 contiguous source → packet-interleaved destination，不是把 consumer private resource 改成逐 program 连续布局；copy 按 i32 传递原始位，没有 FP 转换或额外 snapshot allocation。

实际 C4 object 在 `0x2de0..0x2e08` 的第一条 program copy loop：

```asm
ldr    q3, [x21, x20]          // 一次读 16B
stur   s3, [x22, #-0x40]       // dst + 0B
mov    s4, v3[1]
stur   s4, [x22, #-0x20]       // dst + 32B
st1.s  { v3 }[2], [x22]        // dst + 64B
add    x23, x22, #0x20
st1.s  { v3 }[3], [x23]        // dst + 96B
add    x20, x20, #0x10         // source chunk +16B
add    x22, x22, #0x80         // destination chunk +128B
cmp    x20, #0x1, lsl #12      // 4096B source extent
b.ne   0x2de0
```

第二条 program loop 的初始目标从 `x8+0x40` 改为 `x8+0x44`，即相邻 program 的 lane 偏移仅 4B，吻合上式。每条 loop 之前有 active-program `tbz`，不是无条件覆盖其他 lane。

源代码核查也吻合：`llvm_schedule_emitter_memory.cpp` 的 `_find_interleaved_private_arrays` 仅允许 typed copy destination 与闭合的 scalar GEP / load / store address tree；未知 reference call（包括 native MMA）仍不准 interleave。`_contiguous_private_address` 使用 immutable allocation base 和保存的 GEP offset，并扣掉 seed lane byte offset，而不重新计算 index。这保留了 consumer 的引用快照语义。`llvm_schedule_emitter_mma.cpp` 中 copy stride 为 interleaved 时的 `_width`，否则为 1。

## 2. 残余 gather 的 scalarization 仍然存在

实际 C4 entry 的 `0xbc..0x124` 可见逐 lane 的 mask branch；例如：

```asm
tbz    w8, #0x7, 0x128
mov.d  x8, v6[1]
ldr    q6, [sp, #0x23b0]
ld1.s  { v6 }[3], [x8]
str    q6, [sp, #0x23b0]
```

这与 IR 内剩余 64 次 masked gather 的 lane-load 实现一致；copy 改写没有消除所有 global gather / 输出 scatter。两份 object 均无 undefined symbols，均只有 entry 和 packet-batch wrapper 两个代码符号；全部 12 条 `bl` 都在 wrapper，实际 relocation 指向 `_llm_attention`。所以被检查的 copy loops 已进入 entry 机器码，不是外部运行库调用。

`summary.json` 的 opcode counts 是整个 object 的静态计数。其 `machine_copy_lane_store_lines` 字段只是对所有 `st1.*` 行的词法筛选，**不表示每一条都是 copy**；特别是 C0 也有 scatter lane stores。以上判断使用的是明确的 loop 地址与操作数关系，而非该字段名。

这里不能推断哪部分占用了多少 cycles，也不能因 raw IR 减少或成功编译就宣称执行变快。实际收益必须引用主 cohort 的同 visit 配对测量。

## 3. Q4 / Q8 的 simplified full-packet 没有放宽最终预算

| case / arm | original IR instructions | retained clone instructions | rounds | decision | object bytes |
|---|---:|---:|---:|---|---:|
| q4 M4C4 | 6495 | 0 | 0 | source_budget_exceeded | 121952 |
| q4 M4C4 simplified | 6495 | 3182 | 3 | simplified_selected | 211752 |
| q8 M4C4 | 4146 | 0 | 0 | source_budget_exceeded | 35976 |
| q8 M4C4 simplified | 4146 | 2425 | 3 | simplified_selected | 63544 |

逐份实际 LLVM 计数与 metadata 的 source / candidate counts 完全一致。默认路径 raw source admission 为 4096；显式 simplified 路径只允许 raw source 至多 8192，然后至多 4 轮 local simplification，最终 candidate 仍须 <=4096。两份实际 candidate 均符合。

`full_packet_cloned_instructions` 刻意保留历史 raw-source 口径（6495 / 4146），**不是最后 clone body 大小**；当前实际 body 分别是 3182 / 2425。simplified 臂保留的 original body 与对应 baseline 同 instruction count / block count。两对的 interleaved / snapshot / workspace metadata 也不变。

增加 full-packet 专用 clone 的同时保留 fallback，因此整体 object 增大不与 candidate 清理成功矛盾。静态代码大小增加的运行时利弊仍须测量，不能凭这个表决定默认 policy。

## 4. 明确 IR / object 的阶段口径

`simd_compiler.cpp` 在 `jit->add_module` 之前打印捕获的 LLVM；因此上述 entry / helper / clone 计数是 **general LLVM optimization pipeline 之前** 的实际 emitted IR。simplified clone 已经过本地清理，不代表原始 fallback 被 general LLVM O2 优化过。

六份模块的全部定义汇总 `(instructions, blocks)` 分别为 `(42684,41)`、`(41746,71)`、`(6799,221)`、`(9981,400)`、`(4450,281)`、`(6875,520)`。当前 `LLVMJIT::selects_size_bounded_pipeline` 在 blocks >=8192 或 instructions >=262144 才切到 O1；这些模块均走正常 O2。object 是 ORC 捕获的最终 relocatable object，prepared helper 只链接该 object，不从 `kernel.ll` 重新编译。

因此不能将 raw entry instruction count、清理后 full-packet candidate count、整份 optimized object 大小混成同一个成本指标。当前可支撑的结论是：copy 修复保持 consumer layout 并实际生成向量读 / strided 写；simplified candidate 在不增加最终预算的前提下使 Q4/Q8 获得合法专用入口；残余 mask / gather / 大 fallback 仍是后续 profiling 应验证的优化方向。

; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_attention(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 1024, i64 2048, i64 3072, i64 4096, i64 5120, i64 6144, i64 7168>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 8192
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 20480
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 32768
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 2048, i64 4096, i64 6144, i64 8192, i64 10240, i64 12288, i64 14336>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 49152
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 3072, i64 6144, i64 9216, i64 12288, i64 15360, i64 18432, i64 21504>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 73728
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 512, i64 1024, i64 1536, i64 2048, i64 2560, i64 3072, i64 3584>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 77824
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 512, i64 1024, i64 1536, i64 2048, i64 2560, i64 3072, i64 3584>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 81920
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 16, i64 32, i64 48, i64 64, i64 80, i64 96, i64 112>, 1
  %24 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace29 = load ptr, ptr %24, align 8
  %tile_snapshot.private30 = getelementptr inbounds i8, ptr %private.workspace29, i64 82048
  %.splatinsert31 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private30, i64 0
  %.splat32 = shufflevector <8 x ptr> %.splatinsert31, <8 x ptr> poison, <8 x i32> zeroinitializer
  %25 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat32, 0
  %26 = insertvalue { <8 x ptr>, <8 x i64> } %25, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %27 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace33 = load ptr, ptr %27, align 8
  %tile_snapshot.private34 = getelementptr inbounds i8, ptr %private.workspace33, i64 83072
  %.splatinsert35 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private34, i64 0
  %.splat36 = shufflevector <8 x ptr> %.splatinsert35, <8 x ptr> poison, <8 x i32> zeroinitializer
  %28 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat36, 0
  %29 = insertvalue { <8 x ptr>, <8 x i64> } %28, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %30 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace37 = load ptr, ptr %30, align 8
  %tile_snapshot.private38 = getelementptr inbounds i8, ptr %private.workspace37, i64 83584
  %.splatinsert39 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private38, i64 0
  %.splat40 = shufflevector <8 x ptr> %.splatinsert39, <8 x ptr> poison, <8 x i32> zeroinitializer
  %31 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat40, 0
  %32 = insertvalue { <8 x ptr>, <8 x i64> } %31, <8 x i64> <i64 0, i64 128, i64 256, i64 384, i64 512, i64 640, i64 768, i64 896>, 1
  %33 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace41 = load ptr, ptr %33, align 8
  %tile_snapshot.private42 = getelementptr inbounds i8, ptr %private.workspace41, i64 84608
  %.splatinsert43 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private42, i64 0
  %.splat44 = shufflevector <8 x ptr> %.splatinsert43, <8 x ptr> poison, <8 x i32> zeroinitializer
  %34 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat44, 0
  %35 = insertvalue { <8 x ptr>, <8 x i64> } %34, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %36 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace45 = load ptr, ptr %36, align 8
  %tile_snapshot.private46 = getelementptr inbounds i8, ptr %private.workspace45, i64 88704
  %.splatinsert47 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private46, i64 0
  %.splat48 = shufflevector <8 x ptr> %.splatinsert47, <8 x ptr> poison, <8 x i32> zeroinitializer
  %37 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat48, 0
  %38 = insertvalue { <8 x ptr>, <8 x i64> } %37, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %39 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace49 = load ptr, ptr %39, align 8
  %tile_snapshot.private50 = getelementptr inbounds i8, ptr %private.workspace49, i64 88960
  %.splatinsert51 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private50, i64 0
  %.splat52 = shufflevector <8 x ptr> %.splatinsert51, <8 x ptr> poison, <8 x i32> zeroinitializer
  %40 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat52, 0
  %41 = insertvalue { <8 x ptr>, <8 x i64> } %40, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %42 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace53 = load ptr, ptr %42, align 8
  %tile_snapshot.private54 = getelementptr inbounds i8, ptr %private.workspace53, i64 89216
  %.splatinsert55 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private54, i64 0
  %.splat56 = shufflevector <8 x ptr> %.splatinsert55, <8 x ptr> poison, <8 x i32> zeroinitializer
  %43 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat56, 0
  %44 = insertvalue { <8 x ptr>, <8 x i64> } %43, <8 x i64> <i64 0, i64 512, i64 1024, i64 1536, i64 2048, i64 2560, i64 3072, i64 3584>, 1
  %45 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace57 = load ptr, ptr %45, align 8
  %tile_snapshot.private58 = getelementptr inbounds i8, ptr %private.workspace57, i64 93312
  %.splatinsert59 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private58, i64 0
  %.splat60 = shufflevector <8 x ptr> %.splatinsert59, <8 x ptr> poison, <8 x i32> zeroinitializer
  %46 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat60, 0
  %47 = insertvalue { <8 x ptr>, <8 x i64> } %46, <8 x i64> <i64 0, i64 1536, i64 3072, i64 4608, i64 6144, i64 7680, i64 9216, i64 10752>, 1
  %48 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace61 = load ptr, ptr %48, align 8
  %tile_snapshot.private62 = getelementptr inbounds i8, ptr %private.workspace61, i64 105600
  %.splatinsert63 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private62, i64 0
  %.splat64 = shufflevector <8 x ptr> %.splatinsert63, <8 x ptr> poison, <8 x i32> zeroinitializer
  %49 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat64, 0
  %50 = insertvalue { <8 x ptr>, <8 x i64> } %49, <8 x i64> <i64 0, i64 1536, i64 3072, i64 4608, i64 6144, i64 7680, i64 9216, i64 10752>, 1
  %51 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace65 = load ptr, ptr %51, align 8
  %tile_snapshot.private66 = getelementptr inbounds i8, ptr %private.workspace65, i64 117888
  %.splatinsert67 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private66, i64 0
  %.splat68 = shufflevector <8 x ptr> %.splatinsert67, <8 x ptr> poison, <8 x i32> zeroinitializer
  %52 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat68, 0
  %53 = insertvalue { <8 x ptr>, <8 x i64> } %52, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill69 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill69, align 64
  %.spill70 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill70, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill71 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill71, align 64
  %tile_snapshot.spill72 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill72, align 64
  %.slot73 = alloca i64, align 8
  store i64 0, ptr %.slot73, align 4
  %.slot74 = alloca i64, align 8
  store i64 0, ptr %.slot74, align 4
  %.slot75 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot75, align 32
  %.slot76 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot76, align 32
  %.slot77 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot77, align 32
  %.slot78 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot78, align 32
  %.slot79 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot79, align 32
  %.slot80 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot80, align 32
  %.slot81 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot81, align 32
  %.slot82 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot82, align 32
  %.slot83 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot83, align 32
  %.slot84 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot84, align 32
  %.slot85 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot85, align 32
  %.slot86 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot86, align 32
  %.slot87 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot87, align 32
  %.slot88 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot88, align 32
  %.slot89 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot89, align 32
  %.slot90 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot90, align 32
  %.spill91 = alloca i64, align 8
  store i64 0, ptr %.spill91, align 4
  %tile_snapshot.spill92 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill92, align 64
  %.slot93 = alloca i64, align 8
  store i64 0, ptr %.slot93, align 4
  %.spill94 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill94, align 64
  %.slot95 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot95, align 32
  %tile_snapshot.spill96 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill96, align 64
  %.slot97 = alloca i64, align 8
  store i64 0, ptr %.slot97, align 4
  %.spill98 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill98, align 64
  %.slot99 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot99, align 32
  %tile_snapshot.spill100 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill100, align 64
  %.slot101 = alloca i64, align 8
  store i64 0, ptr %.slot101, align 4
  %tile_snapshot.spill102 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill102, align 64
  %tile_snapshot.spill103 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill103, align 64
  %tile_snapshot.spill104 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill104, align 64
  %tile_snapshot.spill105 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill105, align 64
  %tile_snapshot.spill106 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill106, align 64
  %.slot107 = alloca i64, align 8
  store i64 0, ptr %.slot107, align 4
  %tile_snapshot.spill108 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill108, align 64
  %.slot109 = alloca i64, align 8
  store i64 0, ptr %.slot109, align 4
  %.slot110 = alloca i64, align 8
  store i64 0, ptr %.slot110, align 4
  %.slot111 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot111, align 32
  %.slot112 = alloca i64, align 8
  store i64 0, ptr %.slot112, align 4
  %.slot113 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot113, align 32
  %.slot114 = alloca i64, align 8
  store i64 0, ptr %.slot114, align 4
  %.slot115 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot115, align 32
  %.slot116 = alloca i64, align 8
  store i64 0, ptr %.slot116, align 4
  %.slot117 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot117, align 32
  %.slot118 = alloca i64, align 8
  store i64 0, ptr %.slot118, align 4
  %.slot119 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot119, align 32
  %.slot120 = alloca i64, align 8
  store i64 0, ptr %.slot120, align 4
  %.slot121 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot121, align 32
  %.slot122 = alloca i64, align 8
  store i64 0, ptr %.slot122, align 4
  %.slot123 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot123, align 32
  %.slot124 = alloca i64, align 8
  store i64 0, ptr %.slot124, align 4
  %.slot125 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot125, align 32
  %.spill126 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill126, align 32
  %.spill127 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill127, align 32
  %.spill128 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill128, align 32
  %.spill129 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill129, align 32
  %.spill130 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill130, align 32
  %.spill131 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill131, align 32
  %.spill132 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill132, align 32
  %.spill133 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill133, align 32
  %tile_snapshot.spill134 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill134, align 64
  %.spill135 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill135, align 32
  %.spill136 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill136, align 32
  %.spill137 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill137, align 32
  %.spill138 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill138, align 32
  %.spill139 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill139, align 32
  %.spill140 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill140, align 32
  %.spill141 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill141, align 32
  %.spill142 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill142, align 32
  %tile_snapshot.spill143 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill143, align 64
  %tile_snapshot.spill144 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill144, align 64
  %.slot145 = alloca i64, align 8
  store i64 0, ptr %.slot145, align 4
  %.spill146 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill146, align 32
  %.spill147 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill147, align 32
  %.spill148 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill148, align 32
  %.spill149 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill149, align 32
  %.spill150 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill150, align 32
  %.spill151 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill151, align 32
  %.spill152 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill152, align 32
  %.spill153 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill153, align 32
  %.slot154 = alloca i64, align 8
  store i64 0, ptr %.slot154, align 4
  %.slot155 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot155, align 32
  %.slot156 = alloca i64, align 8
  store i64 0, ptr %.slot156, align 4
  %.slot157 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot157, align 32
  %.slot158 = alloca i64, align 8
  store i64 0, ptr %.slot158, align 4
  %.slot159 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot159, align 32
  %.slot160 = alloca i64, align 8
  store i64 0, ptr %.slot160, align 4
  %.slot161 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot161, align 32
  %.slot162 = alloca i64, align 8
  store i64 0, ptr %.slot162, align 4
  %.slot163 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot163, align 32
  %.slot164 = alloca i64, align 8
  store i64 0, ptr %.slot164, align 4
  %.slot165 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot165, align 32
  %.slot166 = alloca i64, align 8
  store i64 0, ptr %.slot166, align 4
  %.slot167 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot167, align 32
  %.slot168 = alloca i64, align 8
  store i64 0, ptr %.slot168, align 4
  %.slot169 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot169, align 32
  %.spill170 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill170, align 32
  %.spill171 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill171, align 32
  %.spill172 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill172, align 32
  %.spill173 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill173, align 32
  %.spill174 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill174, align 32
  %.spill175 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill175, align 32
  %.spill176 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill176, align 32
  %.spill177 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill177, align 32
  %tile_snapshot.spill178 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill178, align 64
  %.slot179 = alloca i64, align 8
  store i64 0, ptr %.slot179, align 4
  %tile_snapshot.spill180 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill180, align 64
  %.slot181 = alloca i64, align 8
  store i64 0, ptr %.slot181, align 4
  %.slot182 = alloca i64, align 8
  store i64 0, ptr %.slot182, align 4
  %tile_snapshot.spill183 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill183, align 64
  %.slot184 = alloca i64, align 8
  store i64 0, ptr %.slot184, align 4
  %54 = getelementptr i8, ptr %argument_buffer, i64 0
  %55 = load ptr, ptr %54, align 16
  %56 = getelementptr i8, ptr %54, i64 8
  %57 = load i64, ptr %56, align 8
  %58 = insertvalue { ptr, i64 } poison, ptr %55, 0
  %59 = insertvalue { ptr, i64 } %58, i64 %57, 1
  %60 = getelementptr i8, ptr %argument_buffer, i64 16
  %61 = load ptr, ptr %60, align 16
  %62 = getelementptr i8, ptr %60, i64 8
  %63 = load i64, ptr %62, align 8
  %64 = insertvalue { ptr, i64 } poison, ptr %61, 0
  %65 = insertvalue { ptr, i64 } %64, i64 %63, 1
  %66 = getelementptr i8, ptr %argument_buffer, i64 32
  %67 = load ptr, ptr %66, align 16
  %68 = getelementptr i8, ptr %66, i64 8
  %69 = load i64, ptr %68, align 8
  %70 = insertvalue { ptr, i64 } poison, ptr %67, 0
  %71 = insertvalue { ptr, i64 } %70, i64 %69, 1
  %72 = getelementptr i8, ptr %argument_buffer, i64 48
  %73 = load ptr, ptr %72, align 16
  %74 = getelementptr i8, ptr %72, i64 8
  %75 = load i64, ptr %74, align 8
  %76 = insertvalue { ptr, i64 } poison, ptr %73, 0
  %77 = insertvalue { ptr, i64 } %76, i64 %75, 1
  %78 = load i32, ptr %launch_config, align 4
  %79 = getelementptr i8, ptr %launch_config, i64 12
  %80 = load i32, ptr %79, align 4
  %81 = getelementptr i8, ptr %launch_config, i64 4
  %82 = load i32, ptr %81, align 4
  %83 = getelementptr i8, ptr %launch_config, i64 16
  %84 = load i32, ptr %83, align 4
  %85 = getelementptr i8, ptr %launch_config, i64 8
  %86 = load i32, ptr %85, align 4
  %87 = getelementptr i8, ptr %launch_config, i64 20
  %88 = load i32, ptr %87, align 4
  %89 = getelementptr i8, ptr %launch_config, i64 36
  %90 = load i32, ptr %89, align 4
  %.splatinsert185 = insertelement <8 x i32> poison, i32 %90, i64 0
  %.splat186 = shufflevector <8 x i32> %.splatinsert185, <8 x i32> poison, <8 x i32> zeroinitializer
  %91 = add <8 x i32> %.splat186, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %92 = mul i32 %78, 32
  %.splatinsert187 = insertelement <8 x i32> poison, i32 %92, i64 0
  %.splat188 = shufflevector <8 x i32> %.splatinsert187, <8 x i32> poison, <8 x i32> zeroinitializer
  %93 = add <8 x i32> %.splat188, %91
  %94 = mul i32 %82, 1
  %.splatinsert189 = insertelement <8 x i32> poison, i32 %94, i64 0
  %.splat190 = shufflevector <8 x i32> %.splatinsert189, <8 x i32> poison, <8 x i32> zeroinitializer
  %95 = add <8 x i32> %.splat190, zeroinitializer
  %96 = mul i32 %86, 1
  %.splatinsert191 = insertelement <8 x i32> poison, i32 %96, i64 0
  %.splat192 = shufflevector <8 x i32> %.splatinsert191, <8 x i32> poison, <8 x i32> zeroinitializer
  %97 = add <8 x i32> %.splat192, zeroinitializer
  %98 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %93, 0
  %99 = insertvalue [3 x <8 x i32>] %98, <8 x i32> %95, 1
  %100 = insertvalue [3 x <8 x i32>] %99, <8 x i32> %97, 2
  %.splatinsert193 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat194 = shufflevector <8 x i32> %.splatinsert193, <8 x i32> poison, <8 x i32> zeroinitializer
  %101 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat194
  %102 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  br i1 %102, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %103 = extractvalue [3 x <8 x i32>] %100, 0
  %104 = zext <8 x i32> %103 to <8 x i64>
  %105 = select <8 x i1> %101, <8 x i64> %104, <8 x i64> zeroinitializer
  %106 = select <8 x i1> %101, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %107 = sdiv <8 x i64> %105, %106
  %108 = load <8 x i64>, ptr %.spill, align 64
  %109 = select <8 x i1> %101, <8 x i64> %107, <8 x i64> %108
  store <8 x i64> %109, ptr %.spill, align 64
  %110 = select <8 x i1> %101, <8 x i64> %104, <8 x i64> zeroinitializer
  %111 = select <8 x i1> %101, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %112 = sdiv <8 x i64> %110, %111
  %113 = select <8 x i1> %101, <8 x i64> %112, <8 x i64> zeroinitializer
  %114 = select <8 x i1> %101, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %115 = srem <8 x i64> %113, %114
  %116 = mul <8 x i64> %115, splat (i64 8)
  %117 = load <8 x i64>, ptr %.spill69, align 64
  %118 = select <8 x i1> %101, <8 x i64> %116, <8 x i64> %117
  store <8 x i64> %118, ptr %.spill69, align 64
  %119 = select <8 x i1> %101, <8 x i64> %107, <8 x i64> zeroinitializer
  %120 = select <8 x i1> %101, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %121 = sdiv <8 x i64> %119, %120
  %122 = load <8 x i64>, ptr %.spill70, align 64
  %123 = select <8 x i1> %101, <8 x i64> %121, <8 x i64> %122
  store <8 x i64> %123, ptr %.spill70, align 64
  %124 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %124, 0
  %127 = select <8 x i1> %101, <8 x ptr> %125, <8 x ptr> %126
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %124, 1
  %130 = select <8 x i1> %101, <8 x i64> %128, <8 x i64> %129
  %131 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %127, 0
  %132 = insertvalue { <8 x ptr>, <8 x i64> } %131, <8 x i64> %130, 1
  store { <8 x ptr>, <8 x i64> } %132, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %133 = icmp slt i64 %.state, 256
  br i1 %133, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state195 = load i64, ptr %.slot, align 4
  %134 = srem i64 %.state195, 32
  %.state196 = load i64, ptr %.slot, align 4
  %135 = sdiv i64 %.state196, 32
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %136 = add <8 x i64> %.spill.load, zeroinitializer
  %137 = add <8 x i64> zeroinitializer, %136
  %.spill.load197 = load <8 x i64>, ptr %.spill69, align 64
  %.splatinsert198 = insertelement <8 x i64> poison, i64 %135, i64 0
  %.splat199 = shufflevector <8 x i64> %.splatinsert198, <8 x i64> poison, <8 x i32> zeroinitializer
  %138 = add <8 x i64> %.spill.load197, %.splat199
  %139 = mul <8 x i64> %137, splat (i64 64)
  %140 = add <8 x i64> %139, %138
  %141 = add i64 0, %134
  %142 = mul <8 x i64> %140, splat (i64 32)
  %.splatinsert200 = insertelement <8 x i64> poison, i64 %141, i64 0
  %.splat201 = shufflevector <8 x i64> %.splatinsert200, <8 x i64> poison, <8 x i32> zeroinitializer
  %143 = add <8 x i64> %142, %.splat201
  %144 = extractvalue { ptr, i64 } %59, 0
  %145 = mul <8 x i64> %143, splat (i64 4)
  %146 = getelementptr i8, ptr %144, <8 x i64> %145
  %147 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %146, <8 x i1> %101, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %148 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state202 = load i64, ptr %.slot, align 4
  %.splatinsert203 = insertelement <8 x i64> poison, i64 %.state202, i64 0
  %.splat204 = shufflevector <8 x i64> %.splatinsert203, <8 x i64> poison, <8 x i32> zeroinitializer
  %150 = mul <8 x i64> %.splat204, splat (i64 4)
  %151 = add <8 x i64> %149, %150
  %152 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %148, 0
  %153 = insertvalue { <8 x ptr>, <8 x i64> } %152, <8 x i64> %151, 1
  %154 = extractvalue { <8 x ptr>, <8 x i64> } %153, 0
  %155 = extractvalue { <8 x ptr>, <8 x i64> } %153, 1
  %156 = getelementptr i8, <8 x ptr> %154, <8 x i64> %155
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %147, <8 x ptr> align 1 %156, <8 x i1> %101)
  %.state205 = load i64, ptr %.slot, align 4
  %157 = add i64 %.state205, 1
  store i64 %157, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %158 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill71, align 64
  %159 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %160 = extractvalue { <8 x ptr>, <8 x i64> } %158, 0
  %161 = select <8 x i1> %101, <8 x ptr> %159, <8 x ptr> %160
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %163 = extractvalue { <8 x ptr>, <8 x i64> } %158, 1
  %164 = select <8 x i1> %101, <8 x i64> %162, <8 x i64> %163
  %165 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %161, 0
  %166 = insertvalue { <8 x ptr>, <8 x i64> } %165, <8 x i64> %164, 1
  store { <8 x ptr>, <8 x i64> } %166, ptr %tile_snapshot.spill71, align 64
  %167 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill72, align 64
  %168 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %167, 0
  %170 = select <8 x i1> %101, <8 x ptr> %168, <8 x ptr> %169
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %167, 1
  %173 = select <8 x i1> %101, <8 x i64> %171, <8 x i64> %172
  %174 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %170, 0
  %175 = insertvalue { <8 x ptr>, <8 x i64> } %174, <8 x i64> %173, 1
  store { <8 x ptr>, <8 x i64> } %175, ptr %tile_snapshot.spill72, align 64
  store i64 0, ptr %.slot73, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state206 = load i64, ptr %.slot73, align 4
  %176 = icmp slt i64 %.state206, 384
  br i1 %176, label %direct.true207, label %direct.false208

direct.schedule.5:                                ; preds = %direct.true207
  %tile_snapshot.spill.load209 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill71, align 64
  %177 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load209, 0
  %178 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load209, 1
  %.state210 = load i64, ptr %.slot73, align 4
  %.splatinsert211 = insertelement <8 x i64> poison, i64 %.state210, i64 0
  %.splat212 = shufflevector <8 x i64> %.splatinsert211, <8 x i64> poison, <8 x i32> zeroinitializer
  %179 = mul <8 x i64> %.splat212, splat (i64 32)
  %180 = add <8 x i64> %178, %179
  %181 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %177, 0
  %182 = insertvalue { <8 x ptr>, <8 x i64> } %181, <8 x i64> %180, 1
  %183 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %184 = extractvalue { <8 x ptr>, <8 x i64> } %182, 1
  %185 = extractelement <8 x ptr> %183, i32 0
  %186 = extractelement <8 x i64> %184, i32 0
  %187 = sub i64 %186, 0
  %188 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %189 = select i1 %188, i64 %187, i64 0
  %private.contiguous.address = getelementptr i8, ptr %185, i64 %189
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %190 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %private.contiguous.preserve
  store <8 x float> %190, ptr %private.contiguous.address, align 4
  %.state213 = load i64, ptr %.slot73, align 4
  %191 = add i64 %.state213, 1
  store i64 %191, ptr %.slot73, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false208
  store i64 0, ptr %.slot74, align 4
  %192 = load <8 x float>, ptr %.slot75, align 32
  %193 = select <8 x i1> %101, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %192
  store <8 x float> %193, ptr %.slot75, align 32
  %194 = load <8 x float>, ptr %.slot76, align 32
  %195 = select <8 x i1> %101, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %194
  store <8 x float> %195, ptr %.slot76, align 32
  %196 = load <8 x float>, ptr %.slot77, align 32
  %197 = select <8 x i1> %101, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %196
  store <8 x float> %197, ptr %.slot77, align 32
  %198 = load <8 x float>, ptr %.slot78, align 32
  %199 = select <8 x i1> %101, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %198
  store <8 x float> %199, ptr %.slot78, align 32
  %200 = load <8 x float>, ptr %.slot79, align 32
  %201 = select <8 x i1> %101, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %200
  store <8 x float> %201, ptr %.slot79, align 32
  %202 = load <8 x float>, ptr %.slot80, align 32
  %203 = select <8 x i1> %101, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %202
  store <8 x float> %203, ptr %.slot80, align 32
  %204 = load <8 x float>, ptr %.slot81, align 32
  %205 = select <8 x i1> %101, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %204
  store <8 x float> %205, ptr %.slot81, align 32
  %206 = load <8 x float>, ptr %.slot82, align 32
  %207 = select <8 x i1> %101, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %206
  store <8 x float> %207, ptr %.slot82, align 32
  %208 = load <8 x float>, ptr %.slot83, align 32
  %209 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %208
  store <8 x float> %209, ptr %.slot83, align 32
  %210 = load <8 x float>, ptr %.slot84, align 32
  %211 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %210
  store <8 x float> %211, ptr %.slot84, align 32
  %212 = load <8 x float>, ptr %.slot85, align 32
  %213 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %212
  store <8 x float> %213, ptr %.slot85, align 32
  %214 = load <8 x float>, ptr %.slot86, align 32
  %215 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %214
  store <8 x float> %215, ptr %.slot86, align 32
  %216 = load <8 x float>, ptr %.slot87, align 32
  %217 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %216
  store <8 x float> %217, ptr %.slot87, align 32
  %218 = load <8 x float>, ptr %.slot88, align 32
  %219 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %218
  store <8 x float> %219, ptr %.slot88, align 32
  %220 = load <8 x float>, ptr %.slot89, align 32
  %221 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %220
  store <8 x float> %221, ptr %.slot89, align 32
  %222 = load <8 x float>, ptr %.slot90, align 32
  %223 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %222
  store <8 x float> %223, ptr %.slot90, align 32
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.87, %direct.schedule.6
  %.state214 = load i64, ptr %.slot74, align 4
  %224 = icmp slt i64 %.state214, 9
  br i1 %224, label %direct.true215, label %direct.false216

direct.schedule.8:                                ; preds = %direct.true215
  %.state217 = load i64, ptr %.slot74, align 4
  %225 = sdiv i64 %.state217, 1
  %226 = mul i64 %225, 16
  store i64 %226, ptr %.spill91, align 4
  %227 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill92, align 64
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %229 = extractvalue { <8 x ptr>, <8 x i64> } %227, 0
  %230 = select <8 x i1> %101, <8 x ptr> %228, <8 x ptr> %229
  %231 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %232 = extractvalue { <8 x ptr>, <8 x i64> } %227, 1
  %233 = select <8 x i1> %101, <8 x i64> %231, <8 x i64> %232
  %234 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %230, 0
  %235 = insertvalue { <8 x ptr>, <8 x i64> } %234, <8 x i64> %233, 1
  store { <8 x ptr>, <8 x i64> } %235, ptr %tile_snapshot.spill92, align 64
  store i64 0, ptr %.slot93, align 4
  br label %direct.schedule.9

direct.schedule.9:                                ; preds = %direct.schedule.12, %direct.schedule.8
  %.state218 = load i64, ptr %.slot93, align 4
  %236 = icmp slt i64 %.state218, 512
  br i1 %236, label %direct.true219, label %direct.false220

direct.schedule.10:                               ; preds = %direct.true219
  %.state221 = load i64, ptr %.slot93, align 4
  %237 = srem i64 %.state221, 32
  %.state222 = load i64, ptr %.slot93, align 4
  %238 = sdiv i64 %.state222, 32
  %.spill.load223 = load <8 x i64>, ptr %.spill70, align 64
  %239 = add <8 x i64> %.spill.load223, zeroinitializer
  %240 = add <8 x i64> zeroinitializer, %239
  %.spill.load224 = load i64, ptr %.spill91, align 4
  %241 = add i64 %.spill.load224, %238
  %242 = mul <8 x i64> %240, splat (i64 129)
  %.splatinsert225 = insertelement <8 x i64> poison, i64 %241, i64 0
  %.splat226 = shufflevector <8 x i64> %.splatinsert225, <8 x i64> poison, <8 x i32> zeroinitializer
  %243 = add <8 x i64> %242, %.splat226
  %244 = icmp sge i64 %241, 0
  %245 = and i1 true, %244
  %246 = icmp slt i64 %241, 129
  %247 = and i1 %245, %246
  %248 = add i64 0, %237
  %249 = mul <8 x i64> %243, splat (i64 32)
  %.splatinsert227 = insertelement <8 x i64> poison, i64 %248, i64 0
  %.splat228 = shufflevector <8 x i64> %.splatinsert227, <8 x i64> poison, <8 x i32> zeroinitializer
  %250 = add <8 x i64> %249, %.splat228
  %251 = load <8 x i64>, ptr %.spill94, align 64
  %252 = select <8 x i1> %101, <8 x i64> %250, <8 x i64> %251
  store <8 x i64> %252, ptr %.spill94, align 64
  br i1 %247, label %direct.true229, label %direct.false230

direct.schedule.11:                               ; preds = %direct.true229
  %.spill.load231 = load <8 x i64>, ptr %.spill94, align 64
  %253 = extractvalue { ptr, i64 } %65, 0
  %254 = extractelement <8 x i64> %.spill.load231, i32 0
  %255 = mul i64 %254, 4
  %256 = getelementptr i8, ptr %253, i64 %255
  %257 = load float, ptr %256, align 4
  %.splatinsert232 = insertelement <8 x float> poison, float %257, i64 0
  %.splat233 = shufflevector <8 x float> %.splatinsert232, <8 x float> poison, <8 x i32> zeroinitializer
  %258 = load <8 x float>, ptr %.slot95, align 32
  %259 = select <8 x i1> %101, <8 x float> %.splat233, <8 x float> %258
  store <8 x float> %259, ptr %.slot95, align 32
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.schedule.11, %direct.false230
  %tile_snapshot.spill.load234 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill92, align 64
  %260 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load234, 0
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load234, 1
  %.state235 = load i64, ptr %.slot93, align 4
  %.splatinsert236 = insertelement <8 x i64> poison, i64 %.state235, i64 0
  %.splat237 = shufflevector <8 x i64> %.splatinsert236, <8 x i64> poison, <8 x i32> zeroinitializer
  %262 = mul <8 x i64> %.splat237, splat (i64 4)
  %263 = add <8 x i64> %261, %262
  %264 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %260, 0
  %265 = insertvalue { <8 x ptr>, <8 x i64> } %264, <8 x i64> %263, 1
  %.state238 = load <8 x float>, ptr %.slot95, align 32
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %265, 0
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %265, 1
  %268 = getelementptr i8, <8 x ptr> %266, <8 x i64> %267
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state238, <8 x ptr> align 1 %268, <8 x i1> %101)
  %.state239 = load i64, ptr %.slot93, align 4
  %269 = add i64 %.state239, 1
  store i64 %269, ptr %.slot93, align 4
  br label %direct.schedule.9

direct.schedule.13:                               ; preds = %direct.false220
  %270 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill96, align 64
  %271 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %272 = extractvalue { <8 x ptr>, <8 x i64> } %270, 0
  %273 = select <8 x i1> %101, <8 x ptr> %271, <8 x ptr> %272
  %274 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %275 = extractvalue { <8 x ptr>, <8 x i64> } %270, 1
  %276 = select <8 x i1> %101, <8 x i64> %274, <8 x i64> %275
  %277 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %273, 0
  %278 = insertvalue { <8 x ptr>, <8 x i64> } %277, <8 x i64> %276, 1
  store { <8 x ptr>, <8 x i64> } %278, ptr %tile_snapshot.spill96, align 64
  store i64 0, ptr %.slot97, align 4
  br label %direct.schedule.14

direct.schedule.14:                               ; preds = %direct.schedule.17, %direct.schedule.13
  %.state240 = load i64, ptr %.slot97, align 4
  %279 = icmp slt i64 %.state240, 768
  br i1 %279, label %direct.true241, label %direct.false242

direct.schedule.15:                               ; preds = %direct.true241
  %.state243 = load i64, ptr %.slot97, align 4
  %280 = srem i64 %.state243, 48
  %.state244 = load i64, ptr %.slot97, align 4
  %281 = sdiv i64 %.state244, 48
  %.spill.load245 = load <8 x i64>, ptr %.spill70, align 64
  %282 = add <8 x i64> %.spill.load245, zeroinitializer
  %283 = add <8 x i64> zeroinitializer, %282
  %.spill.load246 = load i64, ptr %.spill91, align 4
  %284 = add i64 %.spill.load246, %281
  %285 = mul <8 x i64> %283, splat (i64 129)
  %.splatinsert247 = insertelement <8 x i64> poison, i64 %284, i64 0
  %.splat248 = shufflevector <8 x i64> %.splatinsert247, <8 x i64> poison, <8 x i32> zeroinitializer
  %286 = add <8 x i64> %285, %.splat248
  %287 = icmp sge i64 %284, 0
  %288 = and i1 true, %287
  %289 = icmp slt i64 %284, 129
  %290 = and i1 %288, %289
  %291 = add i64 0, %280
  %292 = mul <8 x i64> %286, splat (i64 48)
  %.splatinsert249 = insertelement <8 x i64> poison, i64 %291, i64 0
  %.splat250 = shufflevector <8 x i64> %.splatinsert249, <8 x i64> poison, <8 x i32> zeroinitializer
  %293 = add <8 x i64> %292, %.splat250
  %294 = load <8 x i64>, ptr %.spill98, align 64
  %295 = select <8 x i1> %101, <8 x i64> %293, <8 x i64> %294
  store <8 x i64> %295, ptr %.spill98, align 64
  br i1 %290, label %direct.true251, label %direct.false252

direct.schedule.16:                               ; preds = %direct.true251
  %.spill.load253 = load <8 x i64>, ptr %.spill98, align 64
  %296 = extractvalue { ptr, i64 } %71, 0
  %297 = extractelement <8 x i64> %.spill.load253, i32 0
  %298 = mul i64 %297, 4
  %299 = getelementptr i8, ptr %296, i64 %298
  %300 = load float, ptr %299, align 4
  %.splatinsert254 = insertelement <8 x float> poison, float %300, i64 0
  %.splat255 = shufflevector <8 x float> %.splatinsert254, <8 x float> poison, <8 x i32> zeroinitializer
  %301 = load <8 x float>, ptr %.slot99, align 32
  %302 = select <8 x i1> %101, <8 x float> %.splat255, <8 x float> %301
  store <8 x float> %302, ptr %.slot99, align 32
  br label %direct.schedule.17

direct.schedule.17:                               ; preds = %direct.schedule.16, %direct.false252
  %tile_snapshot.spill.load256 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill96, align 64
  %303 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load256, 0
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load256, 1
  %.state257 = load i64, ptr %.slot97, align 4
  %.splatinsert258 = insertelement <8 x i64> poison, i64 %.state257, i64 0
  %.splat259 = shufflevector <8 x i64> %.splatinsert258, <8 x i64> poison, <8 x i32> zeroinitializer
  %305 = mul <8 x i64> %.splat259, splat (i64 4)
  %306 = add <8 x i64> %304, %305
  %307 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %303, 0
  %308 = insertvalue { <8 x ptr>, <8 x i64> } %307, <8 x i64> %306, 1
  %.state260 = load <8 x float>, ptr %.slot99, align 32
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %308, 0
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %308, 1
  %311 = getelementptr i8, <8 x ptr> %309, <8 x i64> %310
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state260, <8 x ptr> align 1 %311, <8 x i1> %101)
  %.state261 = load i64, ptr %.slot97, align 4
  %312 = add i64 %.state261, 1
  store i64 %312, ptr %.slot97, align 4
  br label %direct.schedule.14

direct.schedule.18:                               ; preds = %direct.false242
  %313 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill100, align 64
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %313, 0
  %316 = select <8 x i1> %101, <8 x ptr> %314, <8 x ptr> %315
  %317 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %318 = extractvalue { <8 x ptr>, <8 x i64> } %313, 1
  %319 = select <8 x i1> %101, <8 x i64> %317, <8 x i64> %318
  %320 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %316, 0
  %321 = insertvalue { <8 x ptr>, <8 x i64> } %320, <8 x i64> %319, 1
  store { <8 x ptr>, <8 x i64> } %321, ptr %tile_snapshot.spill100, align 64
  store i64 0, ptr %.slot101, align 4
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state262 = load i64, ptr %.slot101, align 4
  %322 = icmp slt i64 %.state262, 128
  br i1 %322, label %direct.true263, label %direct.false264

direct.schedule.20:                               ; preds = %direct.true263
  %tile_snapshot.spill.load265 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill100, align 64
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load265, 0
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load265, 1
  %.state266 = load i64, ptr %.slot101, align 4
  %.splatinsert267 = insertelement <8 x i64> poison, i64 %.state266, i64 0
  %.splat268 = shufflevector <8 x i64> %.splatinsert267, <8 x i64> poison, <8 x i32> zeroinitializer
  %325 = mul <8 x i64> %.splat268, splat (i64 4)
  %326 = add <8 x i64> %324, %325
  %327 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %323, 0
  %328 = insertvalue { <8 x ptr>, <8 x i64> } %327, <8 x i64> %326, 1
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %328, 0
  %330 = extractvalue { <8 x ptr>, <8 x i64> } %328, 1
  %331 = getelementptr i8, <8 x ptr> %329, <8 x i64> %330
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %331, <8 x i1> %101)
  %.state269 = load i64, ptr %.slot101, align 4
  %332 = add i64 %.state269, 1
  store i64 %332, ptr %.slot101, align 4
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false264
  %333 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill102, align 64
  %334 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %335 = extractvalue { <8 x ptr>, <8 x i64> } %333, 0
  %336 = select <8 x i1> %101, <8 x ptr> %334, <8 x ptr> %335
  %337 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %338 = extractvalue { <8 x ptr>, <8 x i64> } %333, 1
  %339 = select <8 x i1> %101, <8 x i64> %337, <8 x i64> %338
  %340 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %336, 0
  %341 = insertvalue { <8 x ptr>, <8 x i64> } %340, <8 x i64> %339, 1
  store { <8 x ptr>, <8 x i64> } %341, ptr %tile_snapshot.spill102, align 64
  %tile_snapshot.spill.load270 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %tile_snapshot.spill.load271 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill92, align 64
  %tile_snapshot.spill.load272 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill100, align 64
  %342 = extractelement <8 x i1> %101, i64 0
  br i1 %342, label %mma.active, label %mma.continue

direct.schedule.22:                               ; preds = %direct.schedule.23, %mma.continue286
  %.state423 = load i64, ptr %.slot107, align 4
  %343 = icmp slt i64 %.state423, 128
  br i1 %343, label %direct.true424, label %direct.false425

direct.schedule.23:                               ; preds = %direct.true424
  %.state426 = load i64, ptr %.slot107, align 4
  %344 = srem i64 %.state426, 8
  %.state427 = load i64, ptr %.slot107, align 4
  %345 = sdiv i64 %.state427, 8
  %346 = add i64 0, %345
  %tile_snapshot.spill.load428 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %347 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load428, 0
  %348 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load428, 1
  %.splatinsert429 = insertelement <8 x i64> poison, i64 %346, i64 0
  %.splat430 = shufflevector <8 x i64> %.splatinsert429, <8 x i64> poison, <8 x i32> zeroinitializer
  %349 = add <8 x i64> %348, %.splat430
  %350 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %347, 0
  %351 = insertvalue { <8 x ptr>, <8 x i64> } %350, <8 x i64> %349, 1
  %352 = extractvalue { <8 x ptr>, <8 x i64> } %351, 0
  %353 = extractvalue { <8 x ptr>, <8 x i64> } %351, 1
  %354 = getelementptr i8, <8 x ptr> %352, <8 x i64> %353
  %355 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %354, <8 x i1> %101, <8 x i8> zeroinitializer)
  %356 = icmp ne <8 x i8> %355, zeroinitializer
  %357 = mul i64 %346, 8
  %358 = add i64 %357, %344
  %359 = srem i64 %358, 8
  %360 = sdiv i64 %358, 8
  %361 = add i64 0, %360
  %tile_snapshot.spill.load431 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill104, align 64
  %362 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load431, 0
  %363 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load431, 1
  %.splatinsert432 = insertelement <8 x i64> poison, i64 %361, i64 0
  %.splat433 = shufflevector <8 x i64> %.splatinsert432, <8 x i64> poison, <8 x i32> zeroinitializer
  %364 = mul <8 x i64> %.splat433, splat (i64 64)
  %365 = add <8 x i64> %363, %364
  %366 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %362, 0
  %367 = insertvalue { <8 x ptr>, <8 x i64> } %366, <8 x i64> %365, 1
  %368 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %369 = extractvalue { <8 x ptr>, <8 x i64> } %367, 1
  %370 = extractelement <8 x ptr> %368, i32 0
  %371 = extractelement <8 x i64> %369, i32 0
  %372 = sub i64 %371, 0
  %373 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %374 = select i1 %373, i64 %372, i64 0
  %private.contiguous.address434 = getelementptr i8, ptr %370, i64 %374
  %private.contiguous.load = load <8 x i64>, ptr %private.contiguous.address434, align 8
  %375 = select <8 x i1> %101, <8 x i64> %private.contiguous.load, <8 x i64> zeroinitializer
  %376 = add i64 0, %359
  %tile_snapshot.spill.load435 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill105, align 64
  %377 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load435, 0
  %378 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load435, 1
  %.splatinsert436 = insertelement <8 x i64> poison, i64 %376, i64 0
  %.splat437 = shufflevector <8 x i64> %.splatinsert436, <8 x i64> poison, <8 x i32> zeroinitializer
  %379 = mul <8 x i64> %.splat437, splat (i64 64)
  %380 = add <8 x i64> %378, %379
  %381 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %377, 0
  %382 = insertvalue { <8 x ptr>, <8 x i64> } %381, <8 x i64> %380, 1
  %383 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %384 = extractvalue { <8 x ptr>, <8 x i64> } %382, 1
  %385 = extractelement <8 x ptr> %383, i32 0
  %386 = extractelement <8 x i64> %384, i32 0
  %387 = sub i64 %386, 0
  %388 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %389 = select i1 %388, i64 %387, i64 0
  %private.contiguous.address438 = getelementptr i8, ptr %385, i64 %389
  %private.contiguous.load439 = load <8 x i64>, ptr %private.contiguous.address438, align 8
  %390 = select <8 x i1> %101, <8 x i64> %private.contiguous.load439, <8 x i64> zeroinitializer
  %391 = icmp sle <8 x i64> %375, %390
  %392 = and <8 x i1> %356, %391
  %tile_snapshot.spill.load440 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill106, align 64
  %393 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load440, 0
  %394 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load440, 1
  %.state441 = load i64, ptr %.slot107, align 4
  %.splatinsert442 = insertelement <8 x i64> poison, i64 %.state441, i64 0
  %.splat443 = shufflevector <8 x i64> %.splatinsert442, <8 x i64> poison, <8 x i32> zeroinitializer
  %395 = add <8 x i64> %394, %.splat443
  %396 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %393, 0
  %397 = insertvalue { <8 x ptr>, <8 x i64> } %396, <8 x i64> %395, 1
  %398 = extractvalue { <8 x ptr>, <8 x i64> } %397, 0
  %399 = extractvalue { <8 x ptr>, <8 x i64> } %397, 1
  %400 = getelementptr i8, <8 x ptr> %398, <8 x i64> %399
  %401 = zext <8 x i1> %392 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %401, <8 x ptr> align 1 %400, <8 x i1> %101)
  %.state444 = load i64, ptr %.slot107, align 4
  %402 = add i64 %.state444, 1
  store i64 %402, ptr %.slot107, align 4
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false425
  %403 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill108, align 64
  %404 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %405 = extractvalue { <8 x ptr>, <8 x i64> } %403, 0
  %406 = select <8 x i1> %101, <8 x ptr> %404, <8 x ptr> %405
  %407 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %408 = extractvalue { <8 x ptr>, <8 x i64> } %403, 1
  %409 = select <8 x i1> %101, <8 x i64> %407, <8 x i64> %408
  %410 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %406, 0
  %411 = insertvalue { <8 x ptr>, <8 x i64> } %410, <8 x i64> %409, 1
  store { <8 x ptr>, <8 x i64> } %411, ptr %tile_snapshot.spill108, align 64
  store i64 0, ptr %.slot109, align 4
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.26, %direct.schedule.24
  %.state445 = load i64, ptr %.slot109, align 4
  %412 = icmp slt i64 %.state445, 128
  br i1 %412, label %direct.true446, label %direct.false447

direct.schedule.26:                               ; preds = %direct.true446
  %.state448 = load i64, ptr %.slot109, align 4
  %413 = srem i64 %.state448, 16
  %.state449 = load i64, ptr %.slot109, align 4
  %414 = sdiv i64 %.state449, 16
  %415 = add i64 0, %413
  %416 = mul i64 %415, 8
  %417 = add i64 %416, %414
  %tile_snapshot.spill.load450 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill106, align 64
  %418 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load450, 0
  %419 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load450, 1
  %.splatinsert451 = insertelement <8 x i64> poison, i64 %417, i64 0
  %.splat452 = shufflevector <8 x i64> %.splatinsert451, <8 x i64> poison, <8 x i32> zeroinitializer
  %420 = add <8 x i64> %419, %.splat452
  %421 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %418, 0
  %422 = insertvalue { <8 x ptr>, <8 x i64> } %421, <8 x i64> %420, 1
  %423 = extractvalue { <8 x ptr>, <8 x i64> } %422, 0
  %424 = extractvalue { <8 x ptr>, <8 x i64> } %422, 1
  %425 = getelementptr i8, <8 x ptr> %423, <8 x i64> %424
  %426 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %425, <8 x i1> %101, <8 x i8> zeroinitializer)
  %427 = icmp ne <8 x i8> %426, zeroinitializer
  %428 = add i64 0, %414
  %429 = mul i64 %428, 16
  %430 = add i64 %429, %413
  %431 = srem i64 %430, 16
  %432 = sdiv i64 %430, 16
  %433 = add i64 0, %432
  %434 = mul i64 %433, 16
  %435 = add i64 %434, %431
  %tile_snapshot.spill.load453 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill102, align 64
  %436 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load453, 0
  %437 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load453, 1
  %.splatinsert454 = insertelement <8 x i64> poison, i64 %435, i64 0
  %.splat455 = shufflevector <8 x i64> %.splatinsert454, <8 x i64> poison, <8 x i32> zeroinitializer
  %438 = mul <8 x i64> %.splat455, splat (i64 4)
  %439 = add <8 x i64> %437, %438
  %440 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %436, 0
  %441 = insertvalue { <8 x ptr>, <8 x i64> } %440, <8 x i64> %439, 1
  %442 = extractvalue { <8 x ptr>, <8 x i64> } %441, 0
  %443 = extractvalue { <8 x ptr>, <8 x i64> } %441, 1
  %444 = getelementptr i8, <8 x ptr> %442, <8 x i64> %443
  %445 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %444, <8 x i1> %101, <8 x float> zeroinitializer)
  %446 = fmul <8 x float> %445, splat (float 0x3FC6A09E60000000)
  %447 = select <8 x i1> %427, <8 x float> %446, <8 x float> splat (float 0xC6293E5940000000)
  %tile_snapshot.spill.load456 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill108, align 64
  %448 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load456, 0
  %449 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load456, 1
  %.state457 = load i64, ptr %.slot109, align 4
  %.splatinsert458 = insertelement <8 x i64> poison, i64 %.state457, i64 0
  %.splat459 = shufflevector <8 x i64> %.splatinsert458, <8 x i64> poison, <8 x i32> zeroinitializer
  %450 = mul <8 x i64> %.splat459, splat (i64 32)
  %451 = add <8 x i64> %449, %450
  %452 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %448, 0
  %453 = insertvalue { <8 x ptr>, <8 x i64> } %452, <8 x i64> %451, 1
  %454 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %455 = extractvalue { <8 x ptr>, <8 x i64> } %453, 1
  %456 = extractelement <8 x ptr> %454, i32 0
  %457 = extractelement <8 x i64> %455, i32 0
  %458 = sub i64 %457, 0
  %459 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %460 = select i1 %459, i64 %458, i64 0
  %private.contiguous.address460 = getelementptr i8, ptr %456, i64 %460
  %private.contiguous.preserve461 = load <8 x float>, ptr %private.contiguous.address460, align 4
  %461 = select <8 x i1> %101, <8 x float> %447, <8 x float> %private.contiguous.preserve461
  store <8 x float> %461, ptr %private.contiguous.address460, align 4
  %.state462 = load i64, ptr %.slot109, align 4
  %462 = add i64 %.state462, 1
  store i64 %462, ptr %.slot109, align 4
  br label %direct.schedule.25

direct.schedule.27:                               ; preds = %direct.false447
  store i64 0, ptr %.slot110, align 4
  %463 = load <8 x float>, ptr %.slot111, align 32
  %464 = select <8 x i1> %101, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %463
  store <8 x float> %464, ptr %.slot111, align 32
  br label %direct.schedule.28

direct.schedule.28:                               ; preds = %direct.schedule.29, %direct.schedule.27
  %.state463 = load i64, ptr %.slot110, align 4
  %465 = icmp slt i64 %.state463, 16
  br i1 %465, label %direct.true464, label %direct.false465

direct.schedule.29:                               ; preds = %direct.true464
  %.state466 = load i64, ptr %.slot110, align 4
  %466 = sdiv i64 %.state466, 1
  %467 = add i64 0, %466
  %tile_snapshot.spill.load467 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill108, align 64
  %468 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load467, 0
  %469 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load467, 1
  %.splatinsert468 = insertelement <8 x i64> poison, i64 %467, i64 0
  %.splat469 = shufflevector <8 x i64> %.splatinsert468, <8 x i64> poison, <8 x i32> zeroinitializer
  %470 = mul <8 x i64> %.splat469, splat (i64 32)
  %471 = add <8 x i64> %469, %470
  %472 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %468, 0
  %473 = insertvalue { <8 x ptr>, <8 x i64> } %472, <8 x i64> %471, 1
  %474 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %475 = extractvalue { <8 x ptr>, <8 x i64> } %473, 1
  %476 = extractelement <8 x ptr> %474, i32 0
  %477 = extractelement <8 x i64> %475, i32 0
  %478 = sub i64 %477, 0
  %479 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %480 = select i1 %479, i64 %478, i64 0
  %private.contiguous.address470 = getelementptr i8, ptr %476, i64 %480
  %private.contiguous.load471 = load <8 x float>, ptr %private.contiguous.address470, align 4
  %481 = select <8 x i1> %101, <8 x float> %private.contiguous.load471, <8 x float> zeroinitializer
  %.state472 = load <8 x float>, ptr %.slot111, align 32
  %482 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state472, <8 x float> %481)
  %.state473 = load i64, ptr %.slot110, align 4
  %483 = add i64 %.state473, 1
  store i64 %483, ptr %.slot110, align 4
  %484 = load <8 x float>, ptr %.slot111, align 32
  %485 = select <8 x i1> %101, <8 x float> %482, <8 x float> %484
  store <8 x float> %485, ptr %.slot111, align 32
  br label %direct.schedule.28

direct.schedule.30:                               ; preds = %direct.false465
  store i64 0, ptr %.slot112, align 4
  %486 = load <8 x float>, ptr %.slot113, align 32
  %487 = select <8 x i1> %101, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %486
  store <8 x float> %487, ptr %.slot113, align 32
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.32, %direct.schedule.30
  %.state474 = load i64, ptr %.slot112, align 4
  %488 = icmp slt i64 %.state474, 16
  br i1 %488, label %direct.true475, label %direct.false476

direct.schedule.32:                               ; preds = %direct.true475
  %.state477 = load i64, ptr %.slot112, align 4
  %489 = sdiv i64 %.state477, 1
  %490 = add i64 16, %489
  %tile_snapshot.spill.load478 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill108, align 64
  %491 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load478, 0
  %492 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load478, 1
  %.splatinsert479 = insertelement <8 x i64> poison, i64 %490, i64 0
  %.splat480 = shufflevector <8 x i64> %.splatinsert479, <8 x i64> poison, <8 x i32> zeroinitializer
  %493 = mul <8 x i64> %.splat480, splat (i64 32)
  %494 = add <8 x i64> %492, %493
  %495 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %491, 0
  %496 = insertvalue { <8 x ptr>, <8 x i64> } %495, <8 x i64> %494, 1
  %497 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %498 = extractvalue { <8 x ptr>, <8 x i64> } %496, 1
  %499 = extractelement <8 x ptr> %497, i32 0
  %500 = extractelement <8 x i64> %498, i32 0
  %501 = sub i64 %500, 0
  %502 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %503 = select i1 %502, i64 %501, i64 0
  %private.contiguous.address481 = getelementptr i8, ptr %499, i64 %503
  %private.contiguous.load482 = load <8 x float>, ptr %private.contiguous.address481, align 4
  %504 = select <8 x i1> %101, <8 x float> %private.contiguous.load482, <8 x float> zeroinitializer
  %.state483 = load <8 x float>, ptr %.slot113, align 32
  %505 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state483, <8 x float> %504)
  %.state484 = load i64, ptr %.slot112, align 4
  %506 = add i64 %.state484, 1
  store i64 %506, ptr %.slot112, align 4
  %507 = load <8 x float>, ptr %.slot113, align 32
  %508 = select <8 x i1> %101, <8 x float> %505, <8 x float> %507
  store <8 x float> %508, ptr %.slot113, align 32
  br label %direct.schedule.31

direct.schedule.33:                               ; preds = %direct.false476
  store i64 0, ptr %.slot114, align 4
  %509 = load <8 x float>, ptr %.slot115, align 32
  %510 = select <8 x i1> %101, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %509
  store <8 x float> %510, ptr %.slot115, align 32
  br label %direct.schedule.34

direct.schedule.34:                               ; preds = %direct.schedule.35, %direct.schedule.33
  %.state485 = load i64, ptr %.slot114, align 4
  %511 = icmp slt i64 %.state485, 16
  br i1 %511, label %direct.true486, label %direct.false487

direct.schedule.35:                               ; preds = %direct.true486
  %.state488 = load i64, ptr %.slot114, align 4
  %512 = sdiv i64 %.state488, 1
  %513 = add i64 32, %512
  %tile_snapshot.spill.load489 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill108, align 64
  %514 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load489, 0
  %515 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load489, 1
  %.splatinsert490 = insertelement <8 x i64> poison, i64 %513, i64 0
  %.splat491 = shufflevector <8 x i64> %.splatinsert490, <8 x i64> poison, <8 x i32> zeroinitializer
  %516 = mul <8 x i64> %.splat491, splat (i64 32)
  %517 = add <8 x i64> %515, %516
  %518 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %514, 0
  %519 = insertvalue { <8 x ptr>, <8 x i64> } %518, <8 x i64> %517, 1
  %520 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %521 = extractvalue { <8 x ptr>, <8 x i64> } %519, 1
  %522 = extractelement <8 x ptr> %520, i32 0
  %523 = extractelement <8 x i64> %521, i32 0
  %524 = sub i64 %523, 0
  %525 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %526 = select i1 %525, i64 %524, i64 0
  %private.contiguous.address492 = getelementptr i8, ptr %522, i64 %526
  %private.contiguous.load493 = load <8 x float>, ptr %private.contiguous.address492, align 4
  %527 = select <8 x i1> %101, <8 x float> %private.contiguous.load493, <8 x float> zeroinitializer
  %.state494 = load <8 x float>, ptr %.slot115, align 32
  %528 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state494, <8 x float> %527)
  %.state495 = load i64, ptr %.slot114, align 4
  %529 = add i64 %.state495, 1
  store i64 %529, ptr %.slot114, align 4
  %530 = load <8 x float>, ptr %.slot115, align 32
  %531 = select <8 x i1> %101, <8 x float> %528, <8 x float> %530
  store <8 x float> %531, ptr %.slot115, align 32
  br label %direct.schedule.34

direct.schedule.36:                               ; preds = %direct.false487
  store i64 0, ptr %.slot116, align 4
  %532 = load <8 x float>, ptr %.slot117, align 32
  %533 = select <8 x i1> %101, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %532
  store <8 x float> %533, ptr %.slot117, align 32
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.38, %direct.schedule.36
  %.state496 = load i64, ptr %.slot116, align 4
  %534 = icmp slt i64 %.state496, 16
  br i1 %534, label %direct.true497, label %direct.false498

direct.schedule.38:                               ; preds = %direct.true497
  %.state499 = load i64, ptr %.slot116, align 4
  %535 = sdiv i64 %.state499, 1
  %536 = add i64 48, %535
  %tile_snapshot.spill.load500 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill108, align 64
  %537 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load500, 0
  %538 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load500, 1
  %.splatinsert501 = insertelement <8 x i64> poison, i64 %536, i64 0
  %.splat502 = shufflevector <8 x i64> %.splatinsert501, <8 x i64> poison, <8 x i32> zeroinitializer
  %539 = mul <8 x i64> %.splat502, splat (i64 32)
  %540 = add <8 x i64> %538, %539
  %541 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %537, 0
  %542 = insertvalue { <8 x ptr>, <8 x i64> } %541, <8 x i64> %540, 1
  %543 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %544 = extractvalue { <8 x ptr>, <8 x i64> } %542, 1
  %545 = extractelement <8 x ptr> %543, i32 0
  %546 = extractelement <8 x i64> %544, i32 0
  %547 = sub i64 %546, 0
  %548 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %549 = select i1 %548, i64 %547, i64 0
  %private.contiguous.address503 = getelementptr i8, ptr %545, i64 %549
  %private.contiguous.load504 = load <8 x float>, ptr %private.contiguous.address503, align 4
  %550 = select <8 x i1> %101, <8 x float> %private.contiguous.load504, <8 x float> zeroinitializer
  %.state505 = load <8 x float>, ptr %.slot117, align 32
  %551 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state505, <8 x float> %550)
  %.state506 = load i64, ptr %.slot116, align 4
  %552 = add i64 %.state506, 1
  store i64 %552, ptr %.slot116, align 4
  %553 = load <8 x float>, ptr %.slot117, align 32
  %554 = select <8 x i1> %101, <8 x float> %551, <8 x float> %553
  store <8 x float> %554, ptr %.slot117, align 32
  br label %direct.schedule.37

direct.schedule.39:                               ; preds = %direct.false498
  store i64 0, ptr %.slot118, align 4
  %555 = load <8 x float>, ptr %.slot119, align 32
  %556 = select <8 x i1> %101, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %555
  store <8 x float> %556, ptr %.slot119, align 32
  br label %direct.schedule.40

direct.schedule.40:                               ; preds = %direct.schedule.41, %direct.schedule.39
  %.state507 = load i64, ptr %.slot118, align 4
  %557 = icmp slt i64 %.state507, 16
  br i1 %557, label %direct.true508, label %direct.false509

direct.schedule.41:                               ; preds = %direct.true508
  %.state510 = load i64, ptr %.slot118, align 4
  %558 = sdiv i64 %.state510, 1
  %559 = add i64 64, %558
  %tile_snapshot.spill.load511 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill108, align 64
  %560 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load511, 0
  %561 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load511, 1
  %.splatinsert512 = insertelement <8 x i64> poison, i64 %559, i64 0
  %.splat513 = shufflevector <8 x i64> %.splatinsert512, <8 x i64> poison, <8 x i32> zeroinitializer
  %562 = mul <8 x i64> %.splat513, splat (i64 32)
  %563 = add <8 x i64> %561, %562
  %564 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %560, 0
  %565 = insertvalue { <8 x ptr>, <8 x i64> } %564, <8 x i64> %563, 1
  %566 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %567 = extractvalue { <8 x ptr>, <8 x i64> } %565, 1
  %568 = extractelement <8 x ptr> %566, i32 0
  %569 = extractelement <8 x i64> %567, i32 0
  %570 = sub i64 %569, 0
  %571 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %572 = select i1 %571, i64 %570, i64 0
  %private.contiguous.address514 = getelementptr i8, ptr %568, i64 %572
  %private.contiguous.load515 = load <8 x float>, ptr %private.contiguous.address514, align 4
  %573 = select <8 x i1> %101, <8 x float> %private.contiguous.load515, <8 x float> zeroinitializer
  %.state516 = load <8 x float>, ptr %.slot119, align 32
  %574 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state516, <8 x float> %573)
  %.state517 = load i64, ptr %.slot118, align 4
  %575 = add i64 %.state517, 1
  store i64 %575, ptr %.slot118, align 4
  %576 = load <8 x float>, ptr %.slot119, align 32
  %577 = select <8 x i1> %101, <8 x float> %574, <8 x float> %576
  store <8 x float> %577, ptr %.slot119, align 32
  br label %direct.schedule.40

direct.schedule.42:                               ; preds = %direct.false509
  store i64 0, ptr %.slot120, align 4
  %578 = load <8 x float>, ptr %.slot121, align 32
  %579 = select <8 x i1> %101, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %578
  store <8 x float> %579, ptr %.slot121, align 32
  br label %direct.schedule.43

direct.schedule.43:                               ; preds = %direct.schedule.44, %direct.schedule.42
  %.state518 = load i64, ptr %.slot120, align 4
  %580 = icmp slt i64 %.state518, 16
  br i1 %580, label %direct.true519, label %direct.false520

direct.schedule.44:                               ; preds = %direct.true519
  %.state521 = load i64, ptr %.slot120, align 4
  %581 = sdiv i64 %.state521, 1
  %582 = add i64 80, %581
  %tile_snapshot.spill.load522 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill108, align 64
  %583 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load522, 0
  %584 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load522, 1
  %.splatinsert523 = insertelement <8 x i64> poison, i64 %582, i64 0
  %.splat524 = shufflevector <8 x i64> %.splatinsert523, <8 x i64> poison, <8 x i32> zeroinitializer
  %585 = mul <8 x i64> %.splat524, splat (i64 32)
  %586 = add <8 x i64> %584, %585
  %587 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %583, 0
  %588 = insertvalue { <8 x ptr>, <8 x i64> } %587, <8 x i64> %586, 1
  %589 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %590 = extractvalue { <8 x ptr>, <8 x i64> } %588, 1
  %591 = extractelement <8 x ptr> %589, i32 0
  %592 = extractelement <8 x i64> %590, i32 0
  %593 = sub i64 %592, 0
  %594 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %595 = select i1 %594, i64 %593, i64 0
  %private.contiguous.address525 = getelementptr i8, ptr %591, i64 %595
  %private.contiguous.load526 = load <8 x float>, ptr %private.contiguous.address525, align 4
  %596 = select <8 x i1> %101, <8 x float> %private.contiguous.load526, <8 x float> zeroinitializer
  %.state527 = load <8 x float>, ptr %.slot121, align 32
  %597 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state527, <8 x float> %596)
  %.state528 = load i64, ptr %.slot120, align 4
  %598 = add i64 %.state528, 1
  store i64 %598, ptr %.slot120, align 4
  %599 = load <8 x float>, ptr %.slot121, align 32
  %600 = select <8 x i1> %101, <8 x float> %597, <8 x float> %599
  store <8 x float> %600, ptr %.slot121, align 32
  br label %direct.schedule.43

direct.schedule.45:                               ; preds = %direct.false520
  store i64 0, ptr %.slot122, align 4
  %601 = load <8 x float>, ptr %.slot123, align 32
  %602 = select <8 x i1> %101, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %601
  store <8 x float> %602, ptr %.slot123, align 32
  br label %direct.schedule.46

direct.schedule.46:                               ; preds = %direct.schedule.47, %direct.schedule.45
  %.state529 = load i64, ptr %.slot122, align 4
  %603 = icmp slt i64 %.state529, 16
  br i1 %603, label %direct.true530, label %direct.false531

direct.schedule.47:                               ; preds = %direct.true530
  %.state532 = load i64, ptr %.slot122, align 4
  %604 = sdiv i64 %.state532, 1
  %605 = add i64 96, %604
  %tile_snapshot.spill.load533 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill108, align 64
  %606 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load533, 0
  %607 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load533, 1
  %.splatinsert534 = insertelement <8 x i64> poison, i64 %605, i64 0
  %.splat535 = shufflevector <8 x i64> %.splatinsert534, <8 x i64> poison, <8 x i32> zeroinitializer
  %608 = mul <8 x i64> %.splat535, splat (i64 32)
  %609 = add <8 x i64> %607, %608
  %610 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %606, 0
  %611 = insertvalue { <8 x ptr>, <8 x i64> } %610, <8 x i64> %609, 1
  %612 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %613 = extractvalue { <8 x ptr>, <8 x i64> } %611, 1
  %614 = extractelement <8 x ptr> %612, i32 0
  %615 = extractelement <8 x i64> %613, i32 0
  %616 = sub i64 %615, 0
  %617 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %618 = select i1 %617, i64 %616, i64 0
  %private.contiguous.address536 = getelementptr i8, ptr %614, i64 %618
  %private.contiguous.load537 = load <8 x float>, ptr %private.contiguous.address536, align 4
  %619 = select <8 x i1> %101, <8 x float> %private.contiguous.load537, <8 x float> zeroinitializer
  %.state538 = load <8 x float>, ptr %.slot123, align 32
  %620 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state538, <8 x float> %619)
  %.state539 = load i64, ptr %.slot122, align 4
  %621 = add i64 %.state539, 1
  store i64 %621, ptr %.slot122, align 4
  %622 = load <8 x float>, ptr %.slot123, align 32
  %623 = select <8 x i1> %101, <8 x float> %620, <8 x float> %622
  store <8 x float> %623, ptr %.slot123, align 32
  br label %direct.schedule.46

direct.schedule.48:                               ; preds = %direct.false531
  store i64 0, ptr %.slot124, align 4
  %624 = load <8 x float>, ptr %.slot125, align 32
  %625 = select <8 x i1> %101, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %624
  store <8 x float> %625, ptr %.slot125, align 32
  br label %direct.schedule.49

direct.schedule.49:                               ; preds = %direct.schedule.50, %direct.schedule.48
  %.state540 = load i64, ptr %.slot124, align 4
  %626 = icmp slt i64 %.state540, 16
  br i1 %626, label %direct.true541, label %direct.false542

direct.schedule.50:                               ; preds = %direct.true541
  %.state543 = load i64, ptr %.slot124, align 4
  %627 = sdiv i64 %.state543, 1
  %628 = add i64 112, %627
  %tile_snapshot.spill.load544 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill108, align 64
  %629 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load544, 0
  %630 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load544, 1
  %.splatinsert545 = insertelement <8 x i64> poison, i64 %628, i64 0
  %.splat546 = shufflevector <8 x i64> %.splatinsert545, <8 x i64> poison, <8 x i32> zeroinitializer
  %631 = mul <8 x i64> %.splat546, splat (i64 32)
  %632 = add <8 x i64> %630, %631
  %633 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %629, 0
  %634 = insertvalue { <8 x ptr>, <8 x i64> } %633, <8 x i64> %632, 1
  %635 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %636 = extractvalue { <8 x ptr>, <8 x i64> } %634, 1
  %637 = extractelement <8 x ptr> %635, i32 0
  %638 = extractelement <8 x i64> %636, i32 0
  %639 = sub i64 %638, 0
  %640 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %641 = select i1 %640, i64 %639, i64 0
  %private.contiguous.address547 = getelementptr i8, ptr %637, i64 %641
  %private.contiguous.load548 = load <8 x float>, ptr %private.contiguous.address547, align 4
  %642 = select <8 x i1> %101, <8 x float> %private.contiguous.load548, <8 x float> zeroinitializer
  %.state549 = load <8 x float>, ptr %.slot125, align 32
  %643 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state549, <8 x float> %642)
  %.state550 = load i64, ptr %.slot124, align 4
  %644 = add i64 %.state550, 1
  store i64 %644, ptr %.slot124, align 4
  %645 = load <8 x float>, ptr %.slot125, align 32
  %646 = select <8 x i1> %101, <8 x float> %643, <8 x float> %645
  store <8 x float> %646, ptr %.slot125, align 32
  br label %direct.schedule.49

direct.schedule.51:                               ; preds = %direct.false542
  %.state551 = load <8 x float>, ptr %.slot75, align 32
  %.state552 = load <8 x float>, ptr %.slot111, align 32
  %647 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state551, <8 x float> %.state552)
  %648 = load <8 x float>, ptr %.spill126, align 32
  %649 = select <8 x i1> %101, <8 x float> %647, <8 x float> %648
  store <8 x float> %649, ptr %.spill126, align 32
  %.state553 = load <8 x float>, ptr %.slot76, align 32
  %.state554 = load <8 x float>, ptr %.slot113, align 32
  %650 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state553, <8 x float> %.state554)
  %651 = load <8 x float>, ptr %.spill127, align 32
  %652 = select <8 x i1> %101, <8 x float> %650, <8 x float> %651
  store <8 x float> %652, ptr %.spill127, align 32
  %.state555 = load <8 x float>, ptr %.slot77, align 32
  %.state556 = load <8 x float>, ptr %.slot115, align 32
  %653 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state555, <8 x float> %.state556)
  %654 = load <8 x float>, ptr %.spill128, align 32
  %655 = select <8 x i1> %101, <8 x float> %653, <8 x float> %654
  store <8 x float> %655, ptr %.spill128, align 32
  %.state557 = load <8 x float>, ptr %.slot78, align 32
  %.state558 = load <8 x float>, ptr %.slot117, align 32
  %656 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state557, <8 x float> %.state558)
  %657 = load <8 x float>, ptr %.spill129, align 32
  %658 = select <8 x i1> %101, <8 x float> %656, <8 x float> %657
  store <8 x float> %658, ptr %.spill129, align 32
  %.state559 = load <8 x float>, ptr %.slot79, align 32
  %.state560 = load <8 x float>, ptr %.slot119, align 32
  %659 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state559, <8 x float> %.state560)
  %660 = load <8 x float>, ptr %.spill130, align 32
  %661 = select <8 x i1> %101, <8 x float> %659, <8 x float> %660
  store <8 x float> %661, ptr %.spill130, align 32
  %.state561 = load <8 x float>, ptr %.slot80, align 32
  %.state562 = load <8 x float>, ptr %.slot121, align 32
  %662 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state561, <8 x float> %.state562)
  %663 = load <8 x float>, ptr %.spill131, align 32
  %664 = select <8 x i1> %101, <8 x float> %662, <8 x float> %663
  store <8 x float> %664, ptr %.spill131, align 32
  %.state563 = load <8 x float>, ptr %.slot81, align 32
  %.state564 = load <8 x float>, ptr %.slot123, align 32
  %665 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state563, <8 x float> %.state564)
  %666 = load <8 x float>, ptr %.spill132, align 32
  %667 = select <8 x i1> %101, <8 x float> %665, <8 x float> %666
  store <8 x float> %667, ptr %.spill132, align 32
  %.state565 = load <8 x float>, ptr %.slot82, align 32
  %.state566 = load <8 x float>, ptr %.slot125, align 32
  %668 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state565, <8 x float> %.state566)
  %669 = load <8 x float>, ptr %.spill133, align 32
  %670 = select <8 x i1> %101, <8 x float> %668, <8 x float> %669
  store <8 x float> %670, ptr %.spill133, align 32
  %671 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill134, align 64
  %672 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %673 = extractvalue { <8 x ptr>, <8 x i64> } %671, 0
  %674 = select <8 x i1> %101, <8 x ptr> %672, <8 x ptr> %673
  %675 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %676 = extractvalue { <8 x ptr>, <8 x i64> } %671, 1
  %677 = select <8 x i1> %101, <8 x i64> %675, <8 x i64> %676
  %678 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %674, 0
  %679 = insertvalue { <8 x ptr>, <8 x i64> } %678, <8 x i64> %677, 1
  store { <8 x ptr>, <8 x i64> } %679, ptr %tile_snapshot.spill134, align 64
  %680 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %681 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %682 = add <8 x i64> %681, zeroinitializer
  %683 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %680, 0
  %684 = insertvalue { <8 x ptr>, <8 x i64> } %683, <8 x i64> %682, 1
  %685 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %686 = extractvalue { <8 x ptr>, <8 x i64> } %684, 1
  %687 = extractelement <8 x ptr> %685, i32 0
  %688 = extractelement <8 x i64> %686, i32 0
  %689 = sub i64 %688, 0
  %690 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %691 = select i1 %690, i64 %689, i64 0
  %private.contiguous.address567 = getelementptr i8, ptr %687, i64 %691
  %private.contiguous.preserve568 = load <8 x float>, ptr %private.contiguous.address567, align 4
  %692 = select <8 x i1> %101, <8 x float> %647, <8 x float> %private.contiguous.preserve568
  store <8 x float> %692, ptr %private.contiguous.address567, align 4
  %693 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %694 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %695 = add <8 x i64> %694, splat (i64 32)
  %696 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %693, 0
  %697 = insertvalue { <8 x ptr>, <8 x i64> } %696, <8 x i64> %695, 1
  %698 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %699 = extractvalue { <8 x ptr>, <8 x i64> } %697, 1
  %700 = extractelement <8 x ptr> %698, i32 0
  %701 = extractelement <8 x i64> %699, i32 0
  %702 = sub i64 %701, 0
  %703 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %704 = select i1 %703, i64 %702, i64 0
  %private.contiguous.address569 = getelementptr i8, ptr %700, i64 %704
  %private.contiguous.preserve570 = load <8 x float>, ptr %private.contiguous.address569, align 4
  %705 = select <8 x i1> %101, <8 x float> %650, <8 x float> %private.contiguous.preserve570
  store <8 x float> %705, ptr %private.contiguous.address569, align 4
  %706 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %707 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %708 = add <8 x i64> %707, splat (i64 64)
  %709 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %706, 0
  %710 = insertvalue { <8 x ptr>, <8 x i64> } %709, <8 x i64> %708, 1
  %711 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %712 = extractvalue { <8 x ptr>, <8 x i64> } %710, 1
  %713 = extractelement <8 x ptr> %711, i32 0
  %714 = extractelement <8 x i64> %712, i32 0
  %715 = sub i64 %714, 0
  %716 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %717 = select i1 %716, i64 %715, i64 0
  %private.contiguous.address571 = getelementptr i8, ptr %713, i64 %717
  %private.contiguous.preserve572 = load <8 x float>, ptr %private.contiguous.address571, align 4
  %718 = select <8 x i1> %101, <8 x float> %653, <8 x float> %private.contiguous.preserve572
  store <8 x float> %718, ptr %private.contiguous.address571, align 4
  %719 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %720 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %721 = add <8 x i64> %720, splat (i64 96)
  %722 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %719, 0
  %723 = insertvalue { <8 x ptr>, <8 x i64> } %722, <8 x i64> %721, 1
  %724 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %725 = extractvalue { <8 x ptr>, <8 x i64> } %723, 1
  %726 = extractelement <8 x ptr> %724, i32 0
  %727 = extractelement <8 x i64> %725, i32 0
  %728 = sub i64 %727, 0
  %729 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %730 = select i1 %729, i64 %728, i64 0
  %private.contiguous.address573 = getelementptr i8, ptr %726, i64 %730
  %private.contiguous.preserve574 = load <8 x float>, ptr %private.contiguous.address573, align 4
  %731 = select <8 x i1> %101, <8 x float> %656, <8 x float> %private.contiguous.preserve574
  store <8 x float> %731, ptr %private.contiguous.address573, align 4
  %732 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %733 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %734 = add <8 x i64> %733, splat (i64 128)
  %735 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %732, 0
  %736 = insertvalue { <8 x ptr>, <8 x i64> } %735, <8 x i64> %734, 1
  %737 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %738 = extractvalue { <8 x ptr>, <8 x i64> } %736, 1
  %739 = extractelement <8 x ptr> %737, i32 0
  %740 = extractelement <8 x i64> %738, i32 0
  %741 = sub i64 %740, 0
  %742 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %743 = select i1 %742, i64 %741, i64 0
  %private.contiguous.address575 = getelementptr i8, ptr %739, i64 %743
  %private.contiguous.preserve576 = load <8 x float>, ptr %private.contiguous.address575, align 4
  %744 = select <8 x i1> %101, <8 x float> %659, <8 x float> %private.contiguous.preserve576
  store <8 x float> %744, ptr %private.contiguous.address575, align 4
  %745 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %746 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %747 = add <8 x i64> %746, splat (i64 160)
  %748 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %745, 0
  %749 = insertvalue { <8 x ptr>, <8 x i64> } %748, <8 x i64> %747, 1
  %750 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %751 = extractvalue { <8 x ptr>, <8 x i64> } %749, 1
  %752 = extractelement <8 x ptr> %750, i32 0
  %753 = extractelement <8 x i64> %751, i32 0
  %754 = sub i64 %753, 0
  %755 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %756 = select i1 %755, i64 %754, i64 0
  %private.contiguous.address577 = getelementptr i8, ptr %752, i64 %756
  %private.contiguous.preserve578 = load <8 x float>, ptr %private.contiguous.address577, align 4
  %757 = select <8 x i1> %101, <8 x float> %662, <8 x float> %private.contiguous.preserve578
  store <8 x float> %757, ptr %private.contiguous.address577, align 4
  %758 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %759 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %760 = add <8 x i64> %759, splat (i64 192)
  %761 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %758, 0
  %762 = insertvalue { <8 x ptr>, <8 x i64> } %761, <8 x i64> %760, 1
  %763 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %764 = extractvalue { <8 x ptr>, <8 x i64> } %762, 1
  %765 = extractelement <8 x ptr> %763, i32 0
  %766 = extractelement <8 x i64> %764, i32 0
  %767 = sub i64 %766, 0
  %768 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %769 = select i1 %768, i64 %767, i64 0
  %private.contiguous.address579 = getelementptr i8, ptr %765, i64 %769
  %private.contiguous.preserve580 = load <8 x float>, ptr %private.contiguous.address579, align 4
  %770 = select <8 x i1> %101, <8 x float> %665, <8 x float> %private.contiguous.preserve580
  store <8 x float> %770, ptr %private.contiguous.address579, align 4
  %771 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %772 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %773 = add <8 x i64> %772, splat (i64 224)
  %774 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %771, 0
  %775 = insertvalue { <8 x ptr>, <8 x i64> } %774, <8 x i64> %773, 1
  %776 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %777 = extractvalue { <8 x ptr>, <8 x i64> } %775, 1
  %778 = extractelement <8 x ptr> %776, i32 0
  %779 = extractelement <8 x i64> %777, i32 0
  %780 = sub i64 %779, 0
  %781 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %782 = select i1 %781, i64 %780, i64 0
  %private.contiguous.address581 = getelementptr i8, ptr %778, i64 %782
  %private.contiguous.preserve582 = load <8 x float>, ptr %private.contiguous.address581, align 4
  %783 = select <8 x i1> %101, <8 x float> %668, <8 x float> %private.contiguous.preserve582
  store <8 x float> %783, ptr %private.contiguous.address581, align 4
  %.state583 = load <8 x float>, ptr %.slot75, align 32
  %784 = fsub <8 x float> %.state583, %647
  %.state584 = load <8 x float>, ptr %.slot76, align 32
  %785 = fsub <8 x float> %.state584, %650
  %.state585 = load <8 x float>, ptr %.slot77, align 32
  %786 = fsub <8 x float> %.state585, %653
  %.state586 = load <8 x float>, ptr %.slot78, align 32
  %787 = fsub <8 x float> %.state586, %656
  %.state587 = load <8 x float>, ptr %.slot79, align 32
  %788 = fsub <8 x float> %.state587, %659
  %.state588 = load <8 x float>, ptr %.slot80, align 32
  %789 = fsub <8 x float> %.state588, %662
  %.state589 = load <8 x float>, ptr %.slot81, align 32
  %790 = fsub <8 x float> %.state589, %665
  %.state590 = load <8 x float>, ptr %.slot82, align 32
  %791 = fsub <8 x float> %.state590, %668
  %792 = select <8 x i1> %101, <8 x float> %784, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %792)
  %793 = load <8 x float>, ptr %.spill135, align 32
  %794 = select <8 x i1> %101, <8 x float> %native.exp, <8 x float> %793
  store <8 x float> %794, ptr %.spill135, align 32
  %795 = select <8 x i1> %101, <8 x float> %785, <8 x float> zeroinitializer
  %native.exp591 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %795)
  %796 = load <8 x float>, ptr %.spill136, align 32
  %797 = select <8 x i1> %101, <8 x float> %native.exp591, <8 x float> %796
  store <8 x float> %797, ptr %.spill136, align 32
  %798 = select <8 x i1> %101, <8 x float> %786, <8 x float> zeroinitializer
  %native.exp592 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %798)
  %799 = load <8 x float>, ptr %.spill137, align 32
  %800 = select <8 x i1> %101, <8 x float> %native.exp592, <8 x float> %799
  store <8 x float> %800, ptr %.spill137, align 32
  %801 = select <8 x i1> %101, <8 x float> %787, <8 x float> zeroinitializer
  %native.exp593 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %801)
  %802 = load <8 x float>, ptr %.spill138, align 32
  %803 = select <8 x i1> %101, <8 x float> %native.exp593, <8 x float> %802
  store <8 x float> %803, ptr %.spill138, align 32
  %804 = select <8 x i1> %101, <8 x float> %788, <8 x float> zeroinitializer
  %native.exp594 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %804)
  %805 = load <8 x float>, ptr %.spill139, align 32
  %806 = select <8 x i1> %101, <8 x float> %native.exp594, <8 x float> %805
  store <8 x float> %806, ptr %.spill139, align 32
  %807 = select <8 x i1> %101, <8 x float> %789, <8 x float> zeroinitializer
  %native.exp595 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %807)
  %808 = load <8 x float>, ptr %.spill140, align 32
  %809 = select <8 x i1> %101, <8 x float> %native.exp595, <8 x float> %808
  store <8 x float> %809, ptr %.spill140, align 32
  %810 = select <8 x i1> %101, <8 x float> %790, <8 x float> zeroinitializer
  %native.exp596 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %810)
  %811 = load <8 x float>, ptr %.spill141, align 32
  %812 = select <8 x i1> %101, <8 x float> %native.exp596, <8 x float> %811
  store <8 x float> %812, ptr %.spill141, align 32
  %813 = select <8 x i1> %101, <8 x float> %791, <8 x float> zeroinitializer
  %native.exp597 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %813)
  %814 = load <8 x float>, ptr %.spill142, align 32
  %815 = select <8 x i1> %101, <8 x float> %native.exp597, <8 x float> %814
  store <8 x float> %815, ptr %.spill142, align 32
  %816 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill143, align 64
  %817 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %818 = extractvalue { <8 x ptr>, <8 x i64> } %816, 0
  %819 = select <8 x i1> %101, <8 x ptr> %817, <8 x ptr> %818
  %820 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %821 = extractvalue { <8 x ptr>, <8 x i64> } %816, 1
  %822 = select <8 x i1> %101, <8 x i64> %820, <8 x i64> %821
  %823 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %819, 0
  %824 = insertvalue { <8 x ptr>, <8 x i64> } %823, <8 x i64> %822, 1
  store { <8 x ptr>, <8 x i64> } %824, ptr %tile_snapshot.spill143, align 64
  %825 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %826 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %827 = add <8 x i64> %826, zeroinitializer
  %828 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %825, 0
  %829 = insertvalue { <8 x ptr>, <8 x i64> } %828, <8 x i64> %827, 1
  %830 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %831 = extractvalue { <8 x ptr>, <8 x i64> } %829, 1
  %832 = extractelement <8 x ptr> %830, i32 0
  %833 = extractelement <8 x i64> %831, i32 0
  %834 = sub i64 %833, 0
  %835 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %836 = select i1 %835, i64 %834, i64 0
  %private.contiguous.address598 = getelementptr i8, ptr %832, i64 %836
  %private.contiguous.preserve599 = load <8 x float>, ptr %private.contiguous.address598, align 4
  %837 = select <8 x i1> %101, <8 x float> %native.exp, <8 x float> %private.contiguous.preserve599
  store <8 x float> %837, ptr %private.contiguous.address598, align 4
  %838 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %839 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %840 = add <8 x i64> %839, splat (i64 32)
  %841 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %838, 0
  %842 = insertvalue { <8 x ptr>, <8 x i64> } %841, <8 x i64> %840, 1
  %843 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %844 = extractvalue { <8 x ptr>, <8 x i64> } %842, 1
  %845 = extractelement <8 x ptr> %843, i32 0
  %846 = extractelement <8 x i64> %844, i32 0
  %847 = sub i64 %846, 0
  %848 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %849 = select i1 %848, i64 %847, i64 0
  %private.contiguous.address600 = getelementptr i8, ptr %845, i64 %849
  %private.contiguous.preserve601 = load <8 x float>, ptr %private.contiguous.address600, align 4
  %850 = select <8 x i1> %101, <8 x float> %native.exp591, <8 x float> %private.contiguous.preserve601
  store <8 x float> %850, ptr %private.contiguous.address600, align 4
  %851 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %852 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %853 = add <8 x i64> %852, splat (i64 64)
  %854 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %851, 0
  %855 = insertvalue { <8 x ptr>, <8 x i64> } %854, <8 x i64> %853, 1
  %856 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %857 = extractvalue { <8 x ptr>, <8 x i64> } %855, 1
  %858 = extractelement <8 x ptr> %856, i32 0
  %859 = extractelement <8 x i64> %857, i32 0
  %860 = sub i64 %859, 0
  %861 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %862 = select i1 %861, i64 %860, i64 0
  %private.contiguous.address602 = getelementptr i8, ptr %858, i64 %862
  %private.contiguous.preserve603 = load <8 x float>, ptr %private.contiguous.address602, align 4
  %863 = select <8 x i1> %101, <8 x float> %native.exp592, <8 x float> %private.contiguous.preserve603
  store <8 x float> %863, ptr %private.contiguous.address602, align 4
  %864 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %865 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %866 = add <8 x i64> %865, splat (i64 96)
  %867 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %864, 0
  %868 = insertvalue { <8 x ptr>, <8 x i64> } %867, <8 x i64> %866, 1
  %869 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %870 = extractvalue { <8 x ptr>, <8 x i64> } %868, 1
  %871 = extractelement <8 x ptr> %869, i32 0
  %872 = extractelement <8 x i64> %870, i32 0
  %873 = sub i64 %872, 0
  %874 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %875 = select i1 %874, i64 %873, i64 0
  %private.contiguous.address604 = getelementptr i8, ptr %871, i64 %875
  %private.contiguous.preserve605 = load <8 x float>, ptr %private.contiguous.address604, align 4
  %876 = select <8 x i1> %101, <8 x float> %native.exp593, <8 x float> %private.contiguous.preserve605
  store <8 x float> %876, ptr %private.contiguous.address604, align 4
  %877 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %878 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %879 = add <8 x i64> %878, splat (i64 128)
  %880 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %877, 0
  %881 = insertvalue { <8 x ptr>, <8 x i64> } %880, <8 x i64> %879, 1
  %882 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %883 = extractvalue { <8 x ptr>, <8 x i64> } %881, 1
  %884 = extractelement <8 x ptr> %882, i32 0
  %885 = extractelement <8 x i64> %883, i32 0
  %886 = sub i64 %885, 0
  %887 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %888 = select i1 %887, i64 %886, i64 0
  %private.contiguous.address606 = getelementptr i8, ptr %884, i64 %888
  %private.contiguous.preserve607 = load <8 x float>, ptr %private.contiguous.address606, align 4
  %889 = select <8 x i1> %101, <8 x float> %native.exp594, <8 x float> %private.contiguous.preserve607
  store <8 x float> %889, ptr %private.contiguous.address606, align 4
  %890 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %891 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %892 = add <8 x i64> %891, splat (i64 160)
  %893 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %890, 0
  %894 = insertvalue { <8 x ptr>, <8 x i64> } %893, <8 x i64> %892, 1
  %895 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %896 = extractvalue { <8 x ptr>, <8 x i64> } %894, 1
  %897 = extractelement <8 x ptr> %895, i32 0
  %898 = extractelement <8 x i64> %896, i32 0
  %899 = sub i64 %898, 0
  %900 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %901 = select i1 %900, i64 %899, i64 0
  %private.contiguous.address608 = getelementptr i8, ptr %897, i64 %901
  %private.contiguous.preserve609 = load <8 x float>, ptr %private.contiguous.address608, align 4
  %902 = select <8 x i1> %101, <8 x float> %native.exp595, <8 x float> %private.contiguous.preserve609
  store <8 x float> %902, ptr %private.contiguous.address608, align 4
  %903 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %904 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %905 = add <8 x i64> %904, splat (i64 192)
  %906 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %903, 0
  %907 = insertvalue { <8 x ptr>, <8 x i64> } %906, <8 x i64> %905, 1
  %908 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %909 = extractvalue { <8 x ptr>, <8 x i64> } %907, 1
  %910 = extractelement <8 x ptr> %908, i32 0
  %911 = extractelement <8 x i64> %909, i32 0
  %912 = sub i64 %911, 0
  %913 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %914 = select i1 %913, i64 %912, i64 0
  %private.contiguous.address610 = getelementptr i8, ptr %910, i64 %914
  %private.contiguous.preserve611 = load <8 x float>, ptr %private.contiguous.address610, align 4
  %915 = select <8 x i1> %101, <8 x float> %native.exp596, <8 x float> %private.contiguous.preserve611
  store <8 x float> %915, ptr %private.contiguous.address610, align 4
  %916 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %917 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %918 = add <8 x i64> %917, splat (i64 224)
  %919 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %916, 0
  %920 = insertvalue { <8 x ptr>, <8 x i64> } %919, <8 x i64> %918, 1
  %921 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %922 = extractvalue { <8 x ptr>, <8 x i64> } %920, 1
  %923 = extractelement <8 x ptr> %921, i32 0
  %924 = extractelement <8 x i64> %922, i32 0
  %925 = sub i64 %924, 0
  %926 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %927 = select i1 %926, i64 %925, i64 0
  %private.contiguous.address612 = getelementptr i8, ptr %923, i64 %927
  %private.contiguous.preserve613 = load <8 x float>, ptr %private.contiguous.address612, align 4
  %928 = select <8 x i1> %101, <8 x float> %native.exp597, <8 x float> %private.contiguous.preserve613
  store <8 x float> %928, ptr %private.contiguous.address612, align 4
  %929 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill144, align 64
  %930 = extractvalue { <8 x ptr>, <8 x i64> } %44, 0
  %931 = extractvalue { <8 x ptr>, <8 x i64> } %929, 0
  %932 = select <8 x i1> %101, <8 x ptr> %930, <8 x ptr> %931
  %933 = extractvalue { <8 x ptr>, <8 x i64> } %44, 1
  %934 = extractvalue { <8 x ptr>, <8 x i64> } %929, 1
  %935 = select <8 x i1> %101, <8 x i64> %933, <8 x i64> %934
  %936 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %932, 0
  %937 = insertvalue { <8 x ptr>, <8 x i64> } %936, <8 x i64> %935, 1
  store { <8 x ptr>, <8 x i64> } %937, ptr %tile_snapshot.spill144, align 64
  store i64 0, ptr %.slot145, align 4
  br label %direct.schedule.52

direct.schedule.52:                               ; preds = %direct.schedule.53, %direct.schedule.51
  %.state614 = load i64, ptr %.slot145, align 4
  %938 = icmp slt i64 %.state614, 128
  br i1 %938, label %direct.true615, label %direct.false616

direct.schedule.53:                               ; preds = %direct.true615
  %.state617 = load i64, ptr %.slot145, align 4
  %939 = srem i64 %.state617, 16
  %.state618 = load i64, ptr %.slot145, align 4
  %940 = sdiv i64 %.state618, 16
  %941 = add i64 0, %939
  %942 = mul i64 %941, 8
  %943 = add i64 %942, %940
  %tile_snapshot.spill.load619 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill106, align 64
  %944 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load619, 0
  %945 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load619, 1
  %.splatinsert620 = insertelement <8 x i64> poison, i64 %943, i64 0
  %.splat621 = shufflevector <8 x i64> %.splatinsert620, <8 x i64> poison, <8 x i32> zeroinitializer
  %946 = add <8 x i64> %945, %.splat621
  %947 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %944, 0
  %948 = insertvalue { <8 x ptr>, <8 x i64> } %947, <8 x i64> %946, 1
  %949 = extractvalue { <8 x ptr>, <8 x i64> } %948, 0
  %950 = extractvalue { <8 x ptr>, <8 x i64> } %948, 1
  %951 = getelementptr i8, <8 x ptr> %949, <8 x i64> %950
  %952 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %951, <8 x i1> %101, <8 x i8> zeroinitializer)
  %953 = icmp ne <8 x i8> %952, zeroinitializer
  %954 = add i64 0, %940
  %955 = mul i64 %954, 16
  %956 = add i64 %955, %939
  %957 = srem i64 %956, 16
  %958 = sdiv i64 %956, 16
  %959 = add i64 0, %958
  %960 = mul i64 %959, 16
  %961 = add i64 %960, %957
  %962 = srem i64 %961, 16
  %963 = sdiv i64 %961, 16
  %964 = add i64 0, %963
  %965 = mul i64 %964, 16
  %966 = add i64 %965, %962
  %tile_snapshot.spill.load622 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill108, align 64
  %967 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load622, 0
  %968 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load622, 1
  %.splatinsert623 = insertelement <8 x i64> poison, i64 %966, i64 0
  %.splat624 = shufflevector <8 x i64> %.splatinsert623, <8 x i64> poison, <8 x i32> zeroinitializer
  %969 = mul <8 x i64> %.splat624, splat (i64 32)
  %970 = add <8 x i64> %968, %969
  %971 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %967, 0
  %972 = insertvalue { <8 x ptr>, <8 x i64> } %971, <8 x i64> %970, 1
  %973 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %974 = extractvalue { <8 x ptr>, <8 x i64> } %972, 1
  %975 = extractelement <8 x ptr> %973, i32 0
  %976 = extractelement <8 x i64> %974, i32 0
  %977 = sub i64 %976, 0
  %978 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %979 = select i1 %978, i64 %977, i64 0
  %private.contiguous.address625 = getelementptr i8, ptr %975, i64 %979
  %private.contiguous.load626 = load <8 x float>, ptr %private.contiguous.address625, align 4
  %980 = select <8 x i1> %101, <8 x float> %private.contiguous.load626, <8 x float> zeroinitializer
  %tile_snapshot.spill.load627 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill134, align 64
  %981 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load627, 0
  %982 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load627, 1
  %.splatinsert628 = insertelement <8 x i64> poison, i64 %964, i64 0
  %.splat629 = shufflevector <8 x i64> %.splatinsert628, <8 x i64> poison, <8 x i32> zeroinitializer
  %983 = mul <8 x i64> %.splat629, splat (i64 32)
  %984 = add <8 x i64> %982, %983
  %985 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %981, 0
  %986 = insertvalue { <8 x ptr>, <8 x i64> } %985, <8 x i64> %984, 1
  %987 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %988 = extractvalue { <8 x ptr>, <8 x i64> } %986, 1
  %989 = extractelement <8 x ptr> %987, i32 0
  %990 = extractelement <8 x i64> %988, i32 0
  %991 = sub i64 %990, 0
  %992 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %993 = select i1 %992, i64 %991, i64 0
  %private.contiguous.address630 = getelementptr i8, ptr %989, i64 %993
  %private.contiguous.load631 = load <8 x float>, ptr %private.contiguous.address630, align 4
  %994 = select <8 x i1> %101, <8 x float> %private.contiguous.load631, <8 x float> zeroinitializer
  %995 = fsub <8 x float> %980, %994
  %996 = select <8 x i1> %101, <8 x float> %995, <8 x float> zeroinitializer
  %native.exp632 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %996)
  %997 = select <8 x i1> %953, <8 x float> %native.exp632, <8 x float> zeroinitializer
  %tile_snapshot.spill.load633 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill144, align 64
  %998 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load633, 0
  %999 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load633, 1
  %.state634 = load i64, ptr %.slot145, align 4
  %.splatinsert635 = insertelement <8 x i64> poison, i64 %.state634, i64 0
  %.splat636 = shufflevector <8 x i64> %.splatinsert635, <8 x i64> poison, <8 x i32> zeroinitializer
  %1000 = mul <8 x i64> %.splat636, splat (i64 4)
  %1001 = add <8 x i64> %999, %1000
  %1002 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %998, 0
  %1003 = insertvalue { <8 x ptr>, <8 x i64> } %1002, <8 x i64> %1001, 1
  %1004 = extractvalue { <8 x ptr>, <8 x i64> } %1003, 0
  %1005 = extractvalue { <8 x ptr>, <8 x i64> } %1003, 1
  %1006 = getelementptr i8, <8 x ptr> %1004, <8 x i64> %1005
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %997, <8 x ptr> align 1 %1006, <8 x i1> %101)
  %.state637 = load i64, ptr %.slot145, align 4
  %1007 = add i64 %.state637, 1
  store i64 %1007, ptr %.slot145, align 4
  br label %direct.schedule.52

direct.schedule.54:                               ; preds = %direct.false616
  %.state638 = load <8 x float>, ptr %.slot83, align 32
  %.spill.load639 = load <8 x float>, ptr %.spill135, align 32
  %1008 = fmul <8 x float> %.state638, %.spill.load639
  %1009 = load <8 x float>, ptr %.spill146, align 32
  %1010 = select <8 x i1> %101, <8 x float> %1008, <8 x float> %1009
  store <8 x float> %1010, ptr %.spill146, align 32
  %.state640 = load <8 x float>, ptr %.slot84, align 32
  %.spill.load641 = load <8 x float>, ptr %.spill136, align 32
  %1011 = fmul <8 x float> %.state640, %.spill.load641
  %1012 = load <8 x float>, ptr %.spill147, align 32
  %1013 = select <8 x i1> %101, <8 x float> %1011, <8 x float> %1012
  store <8 x float> %1013, ptr %.spill147, align 32
  %.state642 = load <8 x float>, ptr %.slot85, align 32
  %.spill.load643 = load <8 x float>, ptr %.spill137, align 32
  %1014 = fmul <8 x float> %.state642, %.spill.load643
  %1015 = load <8 x float>, ptr %.spill148, align 32
  %1016 = select <8 x i1> %101, <8 x float> %1014, <8 x float> %1015
  store <8 x float> %1016, ptr %.spill148, align 32
  %.state644 = load <8 x float>, ptr %.slot86, align 32
  %.spill.load645 = load <8 x float>, ptr %.spill138, align 32
  %1017 = fmul <8 x float> %.state644, %.spill.load645
  %1018 = load <8 x float>, ptr %.spill149, align 32
  %1019 = select <8 x i1> %101, <8 x float> %1017, <8 x float> %1018
  store <8 x float> %1019, ptr %.spill149, align 32
  %.state646 = load <8 x float>, ptr %.slot87, align 32
  %.spill.load647 = load <8 x float>, ptr %.spill139, align 32
  %1020 = fmul <8 x float> %.state646, %.spill.load647
  %1021 = load <8 x float>, ptr %.spill150, align 32
  %1022 = select <8 x i1> %101, <8 x float> %1020, <8 x float> %1021
  store <8 x float> %1022, ptr %.spill150, align 32
  %.state648 = load <8 x float>, ptr %.slot88, align 32
  %.spill.load649 = load <8 x float>, ptr %.spill140, align 32
  %1023 = fmul <8 x float> %.state648, %.spill.load649
  %1024 = load <8 x float>, ptr %.spill151, align 32
  %1025 = select <8 x i1> %101, <8 x float> %1023, <8 x float> %1024
  store <8 x float> %1025, ptr %.spill151, align 32
  %.state650 = load <8 x float>, ptr %.slot89, align 32
  %.spill.load651 = load <8 x float>, ptr %.spill141, align 32
  %1026 = fmul <8 x float> %.state650, %.spill.load651
  %1027 = load <8 x float>, ptr %.spill152, align 32
  %1028 = select <8 x i1> %101, <8 x float> %1026, <8 x float> %1027
  store <8 x float> %1028, ptr %.spill152, align 32
  %.state652 = load <8 x float>, ptr %.slot90, align 32
  %.spill.load653 = load <8 x float>, ptr %.spill142, align 32
  %1029 = fmul <8 x float> %.state652, %.spill.load653
  %1030 = load <8 x float>, ptr %.spill153, align 32
  %1031 = select <8 x i1> %101, <8 x float> %1029, <8 x float> %1030
  store <8 x float> %1031, ptr %.spill153, align 32
  store i64 0, ptr %.slot154, align 4
  %1032 = load <8 x float>, ptr %.slot155, align 32
  %1033 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %1032
  store <8 x float> %1033, ptr %.slot155, align 32
  br label %direct.schedule.55

direct.schedule.55:                               ; preds = %direct.schedule.56, %direct.schedule.54
  %.state654 = load i64, ptr %.slot154, align 4
  %1034 = icmp slt i64 %.state654, 16
  br i1 %1034, label %direct.true655, label %direct.false656

direct.schedule.56:                               ; preds = %direct.true655
  %.state657 = load i64, ptr %.slot154, align 4
  %1035 = sdiv i64 %.state657, 1
  %1036 = add i64 0, %1035
  %tile_snapshot.spill.load658 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill144, align 64
  %1037 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load658, 0
  %1038 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load658, 1
  %.splatinsert659 = insertelement <8 x i64> poison, i64 %1036, i64 0
  %.splat660 = shufflevector <8 x i64> %.splatinsert659, <8 x i64> poison, <8 x i32> zeroinitializer
  %1039 = mul <8 x i64> %.splat660, splat (i64 4)
  %1040 = add <8 x i64> %1038, %1039
  %1041 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1037, 0
  %1042 = insertvalue { <8 x ptr>, <8 x i64> } %1041, <8 x i64> %1040, 1
  %1043 = extractvalue { <8 x ptr>, <8 x i64> } %1042, 0
  %1044 = extractvalue { <8 x ptr>, <8 x i64> } %1042, 1
  %1045 = getelementptr i8, <8 x ptr> %1043, <8 x i64> %1044
  %1046 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1045, <8 x i1> %101, <8 x float> zeroinitializer)
  %.state661 = load <8 x float>, ptr %.slot155, align 32
  %1047 = fadd <8 x float> %.state661, %1046
  %.state662 = load i64, ptr %.slot154, align 4
  %1048 = add i64 %.state662, 1
  store i64 %1048, ptr %.slot154, align 4
  %1049 = load <8 x float>, ptr %.slot155, align 32
  %1050 = select <8 x i1> %101, <8 x float> %1047, <8 x float> %1049
  store <8 x float> %1050, ptr %.slot155, align 32
  br label %direct.schedule.55

direct.schedule.57:                               ; preds = %direct.false656
  store i64 0, ptr %.slot156, align 4
  %1051 = load <8 x float>, ptr %.slot157, align 32
  %1052 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %1051
  store <8 x float> %1052, ptr %.slot157, align 32
  br label %direct.schedule.58

direct.schedule.58:                               ; preds = %direct.schedule.59, %direct.schedule.57
  %.state663 = load i64, ptr %.slot156, align 4
  %1053 = icmp slt i64 %.state663, 16
  br i1 %1053, label %direct.true664, label %direct.false665

direct.schedule.59:                               ; preds = %direct.true664
  %.state666 = load i64, ptr %.slot156, align 4
  %1054 = sdiv i64 %.state666, 1
  %1055 = add i64 16, %1054
  %tile_snapshot.spill.load667 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill144, align 64
  %1056 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load667, 0
  %1057 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load667, 1
  %.splatinsert668 = insertelement <8 x i64> poison, i64 %1055, i64 0
  %.splat669 = shufflevector <8 x i64> %.splatinsert668, <8 x i64> poison, <8 x i32> zeroinitializer
  %1058 = mul <8 x i64> %.splat669, splat (i64 4)
  %1059 = add <8 x i64> %1057, %1058
  %1060 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1056, 0
  %1061 = insertvalue { <8 x ptr>, <8 x i64> } %1060, <8 x i64> %1059, 1
  %1062 = extractvalue { <8 x ptr>, <8 x i64> } %1061, 0
  %1063 = extractvalue { <8 x ptr>, <8 x i64> } %1061, 1
  %1064 = getelementptr i8, <8 x ptr> %1062, <8 x i64> %1063
  %1065 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1064, <8 x i1> %101, <8 x float> zeroinitializer)
  %.state670 = load <8 x float>, ptr %.slot157, align 32
  %1066 = fadd <8 x float> %.state670, %1065
  %.state671 = load i64, ptr %.slot156, align 4
  %1067 = add i64 %.state671, 1
  store i64 %1067, ptr %.slot156, align 4
  %1068 = load <8 x float>, ptr %.slot157, align 32
  %1069 = select <8 x i1> %101, <8 x float> %1066, <8 x float> %1068
  store <8 x float> %1069, ptr %.slot157, align 32
  br label %direct.schedule.58

direct.schedule.60:                               ; preds = %direct.false665
  store i64 0, ptr %.slot158, align 4
  %1070 = load <8 x float>, ptr %.slot159, align 32
  %1071 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %1070
  store <8 x float> %1071, ptr %.slot159, align 32
  br label %direct.schedule.61

direct.schedule.61:                               ; preds = %direct.schedule.62, %direct.schedule.60
  %.state672 = load i64, ptr %.slot158, align 4
  %1072 = icmp slt i64 %.state672, 16
  br i1 %1072, label %direct.true673, label %direct.false674

direct.schedule.62:                               ; preds = %direct.true673
  %.state675 = load i64, ptr %.slot158, align 4
  %1073 = sdiv i64 %.state675, 1
  %1074 = add i64 32, %1073
  %tile_snapshot.spill.load676 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill144, align 64
  %1075 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load676, 0
  %1076 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load676, 1
  %.splatinsert677 = insertelement <8 x i64> poison, i64 %1074, i64 0
  %.splat678 = shufflevector <8 x i64> %.splatinsert677, <8 x i64> poison, <8 x i32> zeroinitializer
  %1077 = mul <8 x i64> %.splat678, splat (i64 4)
  %1078 = add <8 x i64> %1076, %1077
  %1079 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1075, 0
  %1080 = insertvalue { <8 x ptr>, <8 x i64> } %1079, <8 x i64> %1078, 1
  %1081 = extractvalue { <8 x ptr>, <8 x i64> } %1080, 0
  %1082 = extractvalue { <8 x ptr>, <8 x i64> } %1080, 1
  %1083 = getelementptr i8, <8 x ptr> %1081, <8 x i64> %1082
  %1084 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1083, <8 x i1> %101, <8 x float> zeroinitializer)
  %.state679 = load <8 x float>, ptr %.slot159, align 32
  %1085 = fadd <8 x float> %.state679, %1084
  %.state680 = load i64, ptr %.slot158, align 4
  %1086 = add i64 %.state680, 1
  store i64 %1086, ptr %.slot158, align 4
  %1087 = load <8 x float>, ptr %.slot159, align 32
  %1088 = select <8 x i1> %101, <8 x float> %1085, <8 x float> %1087
  store <8 x float> %1088, ptr %.slot159, align 32
  br label %direct.schedule.61

direct.schedule.63:                               ; preds = %direct.false674
  store i64 0, ptr %.slot160, align 4
  %1089 = load <8 x float>, ptr %.slot161, align 32
  %1090 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %1089
  store <8 x float> %1090, ptr %.slot161, align 32
  br label %direct.schedule.64

direct.schedule.64:                               ; preds = %direct.schedule.65, %direct.schedule.63
  %.state681 = load i64, ptr %.slot160, align 4
  %1091 = icmp slt i64 %.state681, 16
  br i1 %1091, label %direct.true682, label %direct.false683

direct.schedule.65:                               ; preds = %direct.true682
  %.state684 = load i64, ptr %.slot160, align 4
  %1092 = sdiv i64 %.state684, 1
  %1093 = add i64 48, %1092
  %tile_snapshot.spill.load685 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill144, align 64
  %1094 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load685, 0
  %1095 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load685, 1
  %.splatinsert686 = insertelement <8 x i64> poison, i64 %1093, i64 0
  %.splat687 = shufflevector <8 x i64> %.splatinsert686, <8 x i64> poison, <8 x i32> zeroinitializer
  %1096 = mul <8 x i64> %.splat687, splat (i64 4)
  %1097 = add <8 x i64> %1095, %1096
  %1098 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1094, 0
  %1099 = insertvalue { <8 x ptr>, <8 x i64> } %1098, <8 x i64> %1097, 1
  %1100 = extractvalue { <8 x ptr>, <8 x i64> } %1099, 0
  %1101 = extractvalue { <8 x ptr>, <8 x i64> } %1099, 1
  %1102 = getelementptr i8, <8 x ptr> %1100, <8 x i64> %1101
  %1103 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1102, <8 x i1> %101, <8 x float> zeroinitializer)
  %.state688 = load <8 x float>, ptr %.slot161, align 32
  %1104 = fadd <8 x float> %.state688, %1103
  %.state689 = load i64, ptr %.slot160, align 4
  %1105 = add i64 %.state689, 1
  store i64 %1105, ptr %.slot160, align 4
  %1106 = load <8 x float>, ptr %.slot161, align 32
  %1107 = select <8 x i1> %101, <8 x float> %1104, <8 x float> %1106
  store <8 x float> %1107, ptr %.slot161, align 32
  br label %direct.schedule.64

direct.schedule.66:                               ; preds = %direct.false683
  store i64 0, ptr %.slot162, align 4
  %1108 = load <8 x float>, ptr %.slot163, align 32
  %1109 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %1108
  store <8 x float> %1109, ptr %.slot163, align 32
  br label %direct.schedule.67

direct.schedule.67:                               ; preds = %direct.schedule.68, %direct.schedule.66
  %.state690 = load i64, ptr %.slot162, align 4
  %1110 = icmp slt i64 %.state690, 16
  br i1 %1110, label %direct.true691, label %direct.false692

direct.schedule.68:                               ; preds = %direct.true691
  %.state693 = load i64, ptr %.slot162, align 4
  %1111 = sdiv i64 %.state693, 1
  %1112 = add i64 64, %1111
  %tile_snapshot.spill.load694 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill144, align 64
  %1113 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load694, 0
  %1114 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load694, 1
  %.splatinsert695 = insertelement <8 x i64> poison, i64 %1112, i64 0
  %.splat696 = shufflevector <8 x i64> %.splatinsert695, <8 x i64> poison, <8 x i32> zeroinitializer
  %1115 = mul <8 x i64> %.splat696, splat (i64 4)
  %1116 = add <8 x i64> %1114, %1115
  %1117 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1113, 0
  %1118 = insertvalue { <8 x ptr>, <8 x i64> } %1117, <8 x i64> %1116, 1
  %1119 = extractvalue { <8 x ptr>, <8 x i64> } %1118, 0
  %1120 = extractvalue { <8 x ptr>, <8 x i64> } %1118, 1
  %1121 = getelementptr i8, <8 x ptr> %1119, <8 x i64> %1120
  %1122 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1121, <8 x i1> %101, <8 x float> zeroinitializer)
  %.state697 = load <8 x float>, ptr %.slot163, align 32
  %1123 = fadd <8 x float> %.state697, %1122
  %.state698 = load i64, ptr %.slot162, align 4
  %1124 = add i64 %.state698, 1
  store i64 %1124, ptr %.slot162, align 4
  %1125 = load <8 x float>, ptr %.slot163, align 32
  %1126 = select <8 x i1> %101, <8 x float> %1123, <8 x float> %1125
  store <8 x float> %1126, ptr %.slot163, align 32
  br label %direct.schedule.67

direct.schedule.69:                               ; preds = %direct.false692
  store i64 0, ptr %.slot164, align 4
  %1127 = load <8 x float>, ptr %.slot165, align 32
  %1128 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %1127
  store <8 x float> %1128, ptr %.slot165, align 32
  br label %direct.schedule.70

direct.schedule.70:                               ; preds = %direct.schedule.71, %direct.schedule.69
  %.state699 = load i64, ptr %.slot164, align 4
  %1129 = icmp slt i64 %.state699, 16
  br i1 %1129, label %direct.true700, label %direct.false701

direct.schedule.71:                               ; preds = %direct.true700
  %.state702 = load i64, ptr %.slot164, align 4
  %1130 = sdiv i64 %.state702, 1
  %1131 = add i64 80, %1130
  %tile_snapshot.spill.load703 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill144, align 64
  %1132 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load703, 0
  %1133 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load703, 1
  %.splatinsert704 = insertelement <8 x i64> poison, i64 %1131, i64 0
  %.splat705 = shufflevector <8 x i64> %.splatinsert704, <8 x i64> poison, <8 x i32> zeroinitializer
  %1134 = mul <8 x i64> %.splat705, splat (i64 4)
  %1135 = add <8 x i64> %1133, %1134
  %1136 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1132, 0
  %1137 = insertvalue { <8 x ptr>, <8 x i64> } %1136, <8 x i64> %1135, 1
  %1138 = extractvalue { <8 x ptr>, <8 x i64> } %1137, 0
  %1139 = extractvalue { <8 x ptr>, <8 x i64> } %1137, 1
  %1140 = getelementptr i8, <8 x ptr> %1138, <8 x i64> %1139
  %1141 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1140, <8 x i1> %101, <8 x float> zeroinitializer)
  %.state706 = load <8 x float>, ptr %.slot165, align 32
  %1142 = fadd <8 x float> %.state706, %1141
  %.state707 = load i64, ptr %.slot164, align 4
  %1143 = add i64 %.state707, 1
  store i64 %1143, ptr %.slot164, align 4
  %1144 = load <8 x float>, ptr %.slot165, align 32
  %1145 = select <8 x i1> %101, <8 x float> %1142, <8 x float> %1144
  store <8 x float> %1145, ptr %.slot165, align 32
  br label %direct.schedule.70

direct.schedule.72:                               ; preds = %direct.false701
  store i64 0, ptr %.slot166, align 4
  %1146 = load <8 x float>, ptr %.slot167, align 32
  %1147 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %1146
  store <8 x float> %1147, ptr %.slot167, align 32
  br label %direct.schedule.73

direct.schedule.73:                               ; preds = %direct.schedule.74, %direct.schedule.72
  %.state708 = load i64, ptr %.slot166, align 4
  %1148 = icmp slt i64 %.state708, 16
  br i1 %1148, label %direct.true709, label %direct.false710

direct.schedule.74:                               ; preds = %direct.true709
  %.state711 = load i64, ptr %.slot166, align 4
  %1149 = sdiv i64 %.state711, 1
  %1150 = add i64 96, %1149
  %tile_snapshot.spill.load712 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill144, align 64
  %1151 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load712, 0
  %1152 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load712, 1
  %.splatinsert713 = insertelement <8 x i64> poison, i64 %1150, i64 0
  %.splat714 = shufflevector <8 x i64> %.splatinsert713, <8 x i64> poison, <8 x i32> zeroinitializer
  %1153 = mul <8 x i64> %.splat714, splat (i64 4)
  %1154 = add <8 x i64> %1152, %1153
  %1155 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1151, 0
  %1156 = insertvalue { <8 x ptr>, <8 x i64> } %1155, <8 x i64> %1154, 1
  %1157 = extractvalue { <8 x ptr>, <8 x i64> } %1156, 0
  %1158 = extractvalue { <8 x ptr>, <8 x i64> } %1156, 1
  %1159 = getelementptr i8, <8 x ptr> %1157, <8 x i64> %1158
  %1160 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1159, <8 x i1> %101, <8 x float> zeroinitializer)
  %.state715 = load <8 x float>, ptr %.slot167, align 32
  %1161 = fadd <8 x float> %.state715, %1160
  %.state716 = load i64, ptr %.slot166, align 4
  %1162 = add i64 %.state716, 1
  store i64 %1162, ptr %.slot166, align 4
  %1163 = load <8 x float>, ptr %.slot167, align 32
  %1164 = select <8 x i1> %101, <8 x float> %1161, <8 x float> %1163
  store <8 x float> %1164, ptr %.slot167, align 32
  br label %direct.schedule.73

direct.schedule.75:                               ; preds = %direct.false710
  store i64 0, ptr %.slot168, align 4
  %1165 = load <8 x float>, ptr %.slot169, align 32
  %1166 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %1165
  store <8 x float> %1166, ptr %.slot169, align 32
  br label %direct.schedule.76

direct.schedule.76:                               ; preds = %direct.schedule.77, %direct.schedule.75
  %.state717 = load i64, ptr %.slot168, align 4
  %1167 = icmp slt i64 %.state717, 16
  br i1 %1167, label %direct.true718, label %direct.false719

direct.schedule.77:                               ; preds = %direct.true718
  %.state720 = load i64, ptr %.slot168, align 4
  %1168 = sdiv i64 %.state720, 1
  %1169 = add i64 112, %1168
  %tile_snapshot.spill.load721 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill144, align 64
  %1170 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load721, 0
  %1171 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load721, 1
  %.splatinsert722 = insertelement <8 x i64> poison, i64 %1169, i64 0
  %.splat723 = shufflevector <8 x i64> %.splatinsert722, <8 x i64> poison, <8 x i32> zeroinitializer
  %1172 = mul <8 x i64> %.splat723, splat (i64 4)
  %1173 = add <8 x i64> %1171, %1172
  %1174 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1170, 0
  %1175 = insertvalue { <8 x ptr>, <8 x i64> } %1174, <8 x i64> %1173, 1
  %1176 = extractvalue { <8 x ptr>, <8 x i64> } %1175, 0
  %1177 = extractvalue { <8 x ptr>, <8 x i64> } %1175, 1
  %1178 = getelementptr i8, <8 x ptr> %1176, <8 x i64> %1177
  %1179 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1178, <8 x i1> %101, <8 x float> zeroinitializer)
  %.state724 = load <8 x float>, ptr %.slot169, align 32
  %1180 = fadd <8 x float> %.state724, %1179
  %.state725 = load i64, ptr %.slot168, align 4
  %1181 = add i64 %.state725, 1
  store i64 %1181, ptr %.slot168, align 4
  %1182 = load <8 x float>, ptr %.slot169, align 32
  %1183 = select <8 x i1> %101, <8 x float> %1180, <8 x float> %1182
  store <8 x float> %1183, ptr %.slot169, align 32
  br label %direct.schedule.76

direct.schedule.78:                               ; preds = %direct.false719
  %.spill.load726 = load <8 x float>, ptr %.spill146, align 32
  %.state727 = load <8 x float>, ptr %.slot155, align 32
  %1184 = fadd <8 x float> %.spill.load726, %.state727
  %1185 = load <8 x float>, ptr %.spill170, align 32
  %1186 = select <8 x i1> %101, <8 x float> %1184, <8 x float> %1185
  store <8 x float> %1186, ptr %.spill170, align 32
  %.spill.load728 = load <8 x float>, ptr %.spill147, align 32
  %.state729 = load <8 x float>, ptr %.slot157, align 32
  %1187 = fadd <8 x float> %.spill.load728, %.state729
  %1188 = load <8 x float>, ptr %.spill171, align 32
  %1189 = select <8 x i1> %101, <8 x float> %1187, <8 x float> %1188
  store <8 x float> %1189, ptr %.spill171, align 32
  %.spill.load730 = load <8 x float>, ptr %.spill148, align 32
  %.state731 = load <8 x float>, ptr %.slot159, align 32
  %1190 = fadd <8 x float> %.spill.load730, %.state731
  %1191 = load <8 x float>, ptr %.spill172, align 32
  %1192 = select <8 x i1> %101, <8 x float> %1190, <8 x float> %1191
  store <8 x float> %1192, ptr %.spill172, align 32
  %.spill.load732 = load <8 x float>, ptr %.spill149, align 32
  %.state733 = load <8 x float>, ptr %.slot161, align 32
  %1193 = fadd <8 x float> %.spill.load732, %.state733
  %1194 = load <8 x float>, ptr %.spill173, align 32
  %1195 = select <8 x i1> %101, <8 x float> %1193, <8 x float> %1194
  store <8 x float> %1195, ptr %.spill173, align 32
  %.spill.load734 = load <8 x float>, ptr %.spill150, align 32
  %.state735 = load <8 x float>, ptr %.slot163, align 32
  %1196 = fadd <8 x float> %.spill.load734, %.state735
  %1197 = load <8 x float>, ptr %.spill174, align 32
  %1198 = select <8 x i1> %101, <8 x float> %1196, <8 x float> %1197
  store <8 x float> %1198, ptr %.spill174, align 32
  %.spill.load736 = load <8 x float>, ptr %.spill151, align 32
  %.state737 = load <8 x float>, ptr %.slot165, align 32
  %1199 = fadd <8 x float> %.spill.load736, %.state737
  %1200 = load <8 x float>, ptr %.spill175, align 32
  %1201 = select <8 x i1> %101, <8 x float> %1199, <8 x float> %1200
  store <8 x float> %1201, ptr %.spill175, align 32
  %.spill.load738 = load <8 x float>, ptr %.spill152, align 32
  %.state739 = load <8 x float>, ptr %.slot167, align 32
  %1202 = fadd <8 x float> %.spill.load738, %.state739
  %1203 = load <8 x float>, ptr %.spill176, align 32
  %1204 = select <8 x i1> %101, <8 x float> %1202, <8 x float> %1203
  store <8 x float> %1204, ptr %.spill176, align 32
  %.spill.load740 = load <8 x float>, ptr %.spill153, align 32
  %.state741 = load <8 x float>, ptr %.slot169, align 32
  %1205 = fadd <8 x float> %.spill.load740, %.state741
  %1206 = load <8 x float>, ptr %.spill177, align 32
  %1207 = select <8 x i1> %101, <8 x float> %1205, <8 x float> %1206
  store <8 x float> %1207, ptr %.spill177, align 32
  %1208 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill178, align 64
  %1209 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %1210 = extractvalue { <8 x ptr>, <8 x i64> } %1208, 0
  %1211 = select <8 x i1> %101, <8 x ptr> %1209, <8 x ptr> %1210
  %1212 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %1213 = extractvalue { <8 x ptr>, <8 x i64> } %1208, 1
  %1214 = select <8 x i1> %101, <8 x i64> %1212, <8 x i64> %1213
  %1215 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1211, 0
  %1216 = insertvalue { <8 x ptr>, <8 x i64> } %1215, <8 x i64> %1214, 1
  store { <8 x ptr>, <8 x i64> } %1216, ptr %tile_snapshot.spill178, align 64
  store i64 0, ptr %.slot179, align 4
  br label %direct.schedule.79

direct.schedule.79:                               ; preds = %direct.schedule.80, %direct.schedule.78
  %.state742 = load i64, ptr %.slot179, align 4
  %1217 = icmp slt i64 %.state742, 384
  br i1 %1217, label %direct.true743, label %direct.false744

direct.schedule.80:                               ; preds = %direct.true743
  %.state745 = load i64, ptr %.slot179, align 4
  %1218 = srem i64 %.state745, 48
  %.state746 = load i64, ptr %.slot179, align 4
  %1219 = sdiv i64 %.state746, 48
  %1220 = add i64 0, %1219
  %1221 = mul i64 %1220, 48
  %1222 = add i64 %1221, %1218
  %tile_snapshot.spill.load747 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill71, align 64
  %1223 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load747, 0
  %1224 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load747, 1
  %.splatinsert748 = insertelement <8 x i64> poison, i64 %1222, i64 0
  %.splat749 = shufflevector <8 x i64> %.splatinsert748, <8 x i64> poison, <8 x i32> zeroinitializer
  %1225 = mul <8 x i64> %.splat749, splat (i64 32)
  %1226 = add <8 x i64> %1224, %1225
  %1227 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1223, 0
  %1228 = insertvalue { <8 x ptr>, <8 x i64> } %1227, <8 x i64> %1226, 1
  %1229 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1230 = extractvalue { <8 x ptr>, <8 x i64> } %1228, 1
  %1231 = extractelement <8 x ptr> %1229, i32 0
  %1232 = extractelement <8 x i64> %1230, i32 0
  %1233 = sub i64 %1232, 0
  %1234 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1235 = select i1 %1234, i64 %1233, i64 0
  %private.contiguous.address750 = getelementptr i8, ptr %1231, i64 %1235
  %private.contiguous.load751 = load <8 x float>, ptr %private.contiguous.address750, align 4
  %1236 = select <8 x i1> %101, <8 x float> %private.contiguous.load751, <8 x float> zeroinitializer
  %tile_snapshot.spill.load752 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill143, align 64
  %1237 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load752, 0
  %1238 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load752, 1
  %.splatinsert753 = insertelement <8 x i64> poison, i64 %1220, i64 0
  %.splat754 = shufflevector <8 x i64> %.splatinsert753, <8 x i64> poison, <8 x i32> zeroinitializer
  %1239 = mul <8 x i64> %.splat754, splat (i64 32)
  %1240 = add <8 x i64> %1238, %1239
  %1241 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1237, 0
  %1242 = insertvalue { <8 x ptr>, <8 x i64> } %1241, <8 x i64> %1240, 1
  %1243 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %1244 = extractvalue { <8 x ptr>, <8 x i64> } %1242, 1
  %1245 = extractelement <8 x ptr> %1243, i32 0
  %1246 = extractelement <8 x i64> %1244, i32 0
  %1247 = sub i64 %1246, 0
  %1248 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1249 = select i1 %1248, i64 %1247, i64 0
  %private.contiguous.address755 = getelementptr i8, ptr %1245, i64 %1249
  %private.contiguous.load756 = load <8 x float>, ptr %private.contiguous.address755, align 4
  %1250 = select <8 x i1> %101, <8 x float> %private.contiguous.load756, <8 x float> zeroinitializer
  %1251 = fmul <8 x float> %1236, %1250
  %tile_snapshot.spill.load757 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill178, align 64
  %1252 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load757, 0
  %1253 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load757, 1
  %.state758 = load i64, ptr %.slot179, align 4
  %.splatinsert759 = insertelement <8 x i64> poison, i64 %.state758, i64 0
  %.splat760 = shufflevector <8 x i64> %.splatinsert759, <8 x i64> poison, <8 x i32> zeroinitializer
  %1254 = mul <8 x i64> %.splat760, splat (i64 4)
  %1255 = add <8 x i64> %1253, %1254
  %1256 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1252, 0
  %1257 = insertvalue { <8 x ptr>, <8 x i64> } %1256, <8 x i64> %1255, 1
  %1258 = extractvalue { <8 x ptr>, <8 x i64> } %1257, 0
  %1259 = extractvalue { <8 x ptr>, <8 x i64> } %1257, 1
  %1260 = getelementptr i8, <8 x ptr> %1258, <8 x i64> %1259
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1251, <8 x ptr> align 1 %1260, <8 x i1> %101)
  %.state761 = load i64, ptr %.slot179, align 4
  %1261 = add i64 %.state761, 1
  store i64 %1261, ptr %.slot179, align 4
  br label %direct.schedule.79

direct.schedule.81:                               ; preds = %direct.false744
  %1262 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill180, align 64
  %1263 = extractvalue { <8 x ptr>, <8 x i64> } %50, 0
  %1264 = extractvalue { <8 x ptr>, <8 x i64> } %1262, 0
  %1265 = select <8 x i1> %101, <8 x ptr> %1263, <8 x ptr> %1264
  %1266 = extractvalue { <8 x ptr>, <8 x i64> } %50, 1
  %1267 = extractvalue { <8 x ptr>, <8 x i64> } %1262, 1
  %1268 = select <8 x i1> %101, <8 x i64> %1266, <8 x i64> %1267
  %1269 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1265, 0
  %1270 = insertvalue { <8 x ptr>, <8 x i64> } %1269, <8 x i64> %1268, 1
  store { <8 x ptr>, <8 x i64> } %1270, ptr %tile_snapshot.spill180, align 64
  %tile_snapshot.spill.load762 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill144, align 64
  %tile_snapshot.spill.load763 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill96, align 64
  %tile_snapshot.spill.load764 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill178, align 64
  %1271 = extractelement <8 x i1> %101, i64 0
  br i1 %1271, label %mma.active765, label %mma.continue766

direct.schedule.82:                               ; preds = %direct.schedule.83, %mma.continue780
  %.state781 = load i64, ptr %.slot181, align 4
  %1272 = icmp slt i64 %.state781, 384
  br i1 %1272, label %direct.true782, label %direct.false783

direct.schedule.83:                               ; preds = %direct.true782
  %tile_snapshot.spill.load784 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill180, align 64
  %1273 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load784, 0
  %1274 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load784, 1
  %.state785 = load i64, ptr %.slot181, align 4
  %.splatinsert786 = insertelement <8 x i64> poison, i64 %.state785, i64 0
  %.splat787 = shufflevector <8 x i64> %.splatinsert786, <8 x i64> poison, <8 x i32> zeroinitializer
  %1275 = mul <8 x i64> %.splat787, splat (i64 4)
  %1276 = add <8 x i64> %1274, %1275
  %1277 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1273, 0
  %1278 = insertvalue { <8 x ptr>, <8 x i64> } %1277, <8 x i64> %1276, 1
  %1279 = extractvalue { <8 x ptr>, <8 x i64> } %1278, 0
  %1280 = extractvalue { <8 x ptr>, <8 x i64> } %1278, 1
  %1281 = getelementptr i8, <8 x ptr> %1279, <8 x i64> %1280
  %1282 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1281, <8 x i1> %101, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load788 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill72, align 64
  %1283 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load788, 0
  %1284 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load788, 1
  %.state789 = load i64, ptr %.slot181, align 4
  %.splatinsert790 = insertelement <8 x i64> poison, i64 %.state789, i64 0
  %.splat791 = shufflevector <8 x i64> %.splatinsert790, <8 x i64> poison, <8 x i32> zeroinitializer
  %1285 = mul <8 x i64> %.splat791, splat (i64 32)
  %1286 = add <8 x i64> %1284, %1285
  %1287 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1283, 0
  %1288 = insertvalue { <8 x ptr>, <8 x i64> } %1287, <8 x i64> %1286, 1
  %1289 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1290 = extractvalue { <8 x ptr>, <8 x i64> } %1288, 1
  %1291 = extractelement <8 x ptr> %1289, i32 0
  %1292 = extractelement <8 x i64> %1290, i32 0
  %1293 = sub i64 %1292, 0
  %1294 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1295 = select i1 %1294, i64 %1293, i64 0
  %private.contiguous.address792 = getelementptr i8, ptr %1291, i64 %1295
  %private.contiguous.preserve793 = load <8 x float>, ptr %private.contiguous.address792, align 4
  %1296 = select <8 x i1> %101, <8 x float> %1282, <8 x float> %private.contiguous.preserve793
  store <8 x float> %1296, ptr %private.contiguous.address792, align 4
  %.state794 = load i64, ptr %.slot181, align 4
  %1297 = add i64 %.state794, 1
  store i64 %1297, ptr %.slot181, align 4
  br label %direct.schedule.82

direct.schedule.84:                               ; preds = %direct.false783
  store i64 0, ptr %.slot182, align 4
  br label %direct.schedule.85

direct.schedule.85:                               ; preds = %direct.schedule.86, %direct.schedule.84
  %.state795 = load i64, ptr %.slot182, align 4
  %1298 = icmp slt i64 %.state795, 384
  br i1 %1298, label %direct.true796, label %direct.false797

direct.schedule.86:                               ; preds = %direct.true796
  %tile_snapshot.spill.load798 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill72, align 64
  %1299 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load798, 0
  %1300 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load798, 1
  %.state799 = load i64, ptr %.slot182, align 4
  %.splatinsert800 = insertelement <8 x i64> poison, i64 %.state799, i64 0
  %.splat801 = shufflevector <8 x i64> %.splatinsert800, <8 x i64> poison, <8 x i32> zeroinitializer
  %1301 = mul <8 x i64> %.splat801, splat (i64 32)
  %1302 = add <8 x i64> %1300, %1301
  %1303 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1299, 0
  %1304 = insertvalue { <8 x ptr>, <8 x i64> } %1303, <8 x i64> %1302, 1
  %1305 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1306 = extractvalue { <8 x ptr>, <8 x i64> } %1304, 1
  %1307 = extractelement <8 x ptr> %1305, i32 0
  %1308 = extractelement <8 x i64> %1306, i32 0
  %1309 = sub i64 %1308, 0
  %1310 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1311 = select i1 %1310, i64 %1309, i64 0
  %private.contiguous.address802 = getelementptr i8, ptr %1307, i64 %1311
  %private.contiguous.load803 = load <8 x float>, ptr %private.contiguous.address802, align 4
  %1312 = select <8 x i1> %101, <8 x float> %private.contiguous.load803, <8 x float> zeroinitializer
  %tile_snapshot.spill.load804 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill71, align 64
  %1313 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load804, 0
  %1314 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load804, 1
  %.state805 = load i64, ptr %.slot182, align 4
  %.splatinsert806 = insertelement <8 x i64> poison, i64 %.state805, i64 0
  %.splat807 = shufflevector <8 x i64> %.splatinsert806, <8 x i64> poison, <8 x i32> zeroinitializer
  %1315 = mul <8 x i64> %.splat807, splat (i64 32)
  %1316 = add <8 x i64> %1314, %1315
  %1317 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1313, 0
  %1318 = insertvalue { <8 x ptr>, <8 x i64> } %1317, <8 x i64> %1316, 1
  %1319 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1320 = extractvalue { <8 x ptr>, <8 x i64> } %1318, 1
  %1321 = extractelement <8 x ptr> %1319, i32 0
  %1322 = extractelement <8 x i64> %1320, i32 0
  %1323 = sub i64 %1322, 0
  %1324 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1325 = select i1 %1324, i64 %1323, i64 0
  %private.contiguous.address808 = getelementptr i8, ptr %1321, i64 %1325
  %private.contiguous.preserve809 = load <8 x float>, ptr %private.contiguous.address808, align 4
  %1326 = select <8 x i1> %101, <8 x float> %1312, <8 x float> %private.contiguous.preserve809
  store <8 x float> %1326, ptr %private.contiguous.address808, align 4
  %.state810 = load i64, ptr %.slot182, align 4
  %1327 = add i64 %.state810, 1
  store i64 %1327, ptr %.slot182, align 4
  br label %direct.schedule.85

direct.schedule.87:                               ; preds = %direct.false797
  %.state811 = load i64, ptr %.slot74, align 4
  %1328 = add i64 %.state811, 1
  %.spill.load812 = load <8 x float>, ptr %.spill126, align 32
  %.spill.load813 = load <8 x float>, ptr %.spill127, align 32
  %.spill.load814 = load <8 x float>, ptr %.spill128, align 32
  %.spill.load815 = load <8 x float>, ptr %.spill129, align 32
  %.spill.load816 = load <8 x float>, ptr %.spill130, align 32
  %.spill.load817 = load <8 x float>, ptr %.spill131, align 32
  %.spill.load818 = load <8 x float>, ptr %.spill132, align 32
  %.spill.load819 = load <8 x float>, ptr %.spill133, align 32
  %.spill.load820 = load <8 x float>, ptr %.spill170, align 32
  %.spill.load821 = load <8 x float>, ptr %.spill171, align 32
  %.spill.load822 = load <8 x float>, ptr %.spill172, align 32
  %.spill.load823 = load <8 x float>, ptr %.spill173, align 32
  %.spill.load824 = load <8 x float>, ptr %.spill174, align 32
  %.spill.load825 = load <8 x float>, ptr %.spill175, align 32
  %.spill.load826 = load <8 x float>, ptr %.spill176, align 32
  %.spill.load827 = load <8 x float>, ptr %.spill177, align 32
  store i64 %1328, ptr %.slot74, align 4
  %1329 = load <8 x float>, ptr %.slot75, align 32
  %1330 = select <8 x i1> %101, <8 x float> %.spill.load812, <8 x float> %1329
  store <8 x float> %1330, ptr %.slot75, align 32
  %1331 = load <8 x float>, ptr %.slot76, align 32
  %1332 = select <8 x i1> %101, <8 x float> %.spill.load813, <8 x float> %1331
  store <8 x float> %1332, ptr %.slot76, align 32
  %1333 = load <8 x float>, ptr %.slot77, align 32
  %1334 = select <8 x i1> %101, <8 x float> %.spill.load814, <8 x float> %1333
  store <8 x float> %1334, ptr %.slot77, align 32
  %1335 = load <8 x float>, ptr %.slot78, align 32
  %1336 = select <8 x i1> %101, <8 x float> %.spill.load815, <8 x float> %1335
  store <8 x float> %1336, ptr %.slot78, align 32
  %1337 = load <8 x float>, ptr %.slot79, align 32
  %1338 = select <8 x i1> %101, <8 x float> %.spill.load816, <8 x float> %1337
  store <8 x float> %1338, ptr %.slot79, align 32
  %1339 = load <8 x float>, ptr %.slot80, align 32
  %1340 = select <8 x i1> %101, <8 x float> %.spill.load817, <8 x float> %1339
  store <8 x float> %1340, ptr %.slot80, align 32
  %1341 = load <8 x float>, ptr %.slot81, align 32
  %1342 = select <8 x i1> %101, <8 x float> %.spill.load818, <8 x float> %1341
  store <8 x float> %1342, ptr %.slot81, align 32
  %1343 = load <8 x float>, ptr %.slot82, align 32
  %1344 = select <8 x i1> %101, <8 x float> %.spill.load819, <8 x float> %1343
  store <8 x float> %1344, ptr %.slot82, align 32
  %1345 = load <8 x float>, ptr %.slot83, align 32
  %1346 = select <8 x i1> %101, <8 x float> %.spill.load820, <8 x float> %1345
  store <8 x float> %1346, ptr %.slot83, align 32
  %1347 = load <8 x float>, ptr %.slot84, align 32
  %1348 = select <8 x i1> %101, <8 x float> %.spill.load821, <8 x float> %1347
  store <8 x float> %1348, ptr %.slot84, align 32
  %1349 = load <8 x float>, ptr %.slot85, align 32
  %1350 = select <8 x i1> %101, <8 x float> %.spill.load822, <8 x float> %1349
  store <8 x float> %1350, ptr %.slot85, align 32
  %1351 = load <8 x float>, ptr %.slot86, align 32
  %1352 = select <8 x i1> %101, <8 x float> %.spill.load823, <8 x float> %1351
  store <8 x float> %1352, ptr %.slot86, align 32
  %1353 = load <8 x float>, ptr %.slot87, align 32
  %1354 = select <8 x i1> %101, <8 x float> %.spill.load824, <8 x float> %1353
  store <8 x float> %1354, ptr %.slot87, align 32
  %1355 = load <8 x float>, ptr %.slot88, align 32
  %1356 = select <8 x i1> %101, <8 x float> %.spill.load825, <8 x float> %1355
  store <8 x float> %1356, ptr %.slot88, align 32
  %1357 = load <8 x float>, ptr %.slot89, align 32
  %1358 = select <8 x i1> %101, <8 x float> %.spill.load826, <8 x float> %1357
  store <8 x float> %1358, ptr %.slot89, align 32
  %1359 = load <8 x float>, ptr %.slot90, align 32
  %1360 = select <8 x i1> %101, <8 x float> %.spill.load827, <8 x float> %1359
  store <8 x float> %1360, ptr %.slot90, align 32
  br label %direct.schedule.7

direct.schedule.88:                               ; preds = %direct.false216
  %1361 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill183, align 64
  %1362 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1363 = extractvalue { <8 x ptr>, <8 x i64> } %1361, 0
  %1364 = select <8 x i1> %101, <8 x ptr> %1362, <8 x ptr> %1363
  %1365 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %1366 = extractvalue { <8 x ptr>, <8 x i64> } %1361, 1
  %1367 = select <8 x i1> %101, <8 x i64> %1365, <8 x i64> %1366
  %1368 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1364, 0
  %1369 = insertvalue { <8 x ptr>, <8 x i64> } %1368, <8 x i64> %1367, 1
  store { <8 x ptr>, <8 x i64> } %1369, ptr %tile_snapshot.spill183, align 64
  %1370 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1371 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %1372 = add <8 x i64> %1371, zeroinitializer
  %1373 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1370, 0
  %1374 = insertvalue { <8 x ptr>, <8 x i64> } %1373, <8 x i64> %1372, 1
  %.state828 = load <8 x float>, ptr %.slot83, align 32
  %1375 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1376 = extractvalue { <8 x ptr>, <8 x i64> } %1374, 1
  %1377 = extractelement <8 x ptr> %1375, i32 0
  %1378 = extractelement <8 x i64> %1376, i32 0
  %1379 = sub i64 %1378, 0
  %1380 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1381 = select i1 %1380, i64 %1379, i64 0
  %private.contiguous.address829 = getelementptr i8, ptr %1377, i64 %1381
  %private.contiguous.preserve830 = load <8 x float>, ptr %private.contiguous.address829, align 4
  %1382 = select <8 x i1> %101, <8 x float> %.state828, <8 x float> %private.contiguous.preserve830
  store <8 x float> %1382, ptr %private.contiguous.address829, align 4
  %1383 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1384 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %1385 = add <8 x i64> %1384, splat (i64 32)
  %1386 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1383, 0
  %1387 = insertvalue { <8 x ptr>, <8 x i64> } %1386, <8 x i64> %1385, 1
  %.state831 = load <8 x float>, ptr %.slot84, align 32
  %1388 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1389 = extractvalue { <8 x ptr>, <8 x i64> } %1387, 1
  %1390 = extractelement <8 x ptr> %1388, i32 0
  %1391 = extractelement <8 x i64> %1389, i32 0
  %1392 = sub i64 %1391, 0
  %1393 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1394 = select i1 %1393, i64 %1392, i64 0
  %private.contiguous.address832 = getelementptr i8, ptr %1390, i64 %1394
  %private.contiguous.preserve833 = load <8 x float>, ptr %private.contiguous.address832, align 4
  %1395 = select <8 x i1> %101, <8 x float> %.state831, <8 x float> %private.contiguous.preserve833
  store <8 x float> %1395, ptr %private.contiguous.address832, align 4
  %1396 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1397 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %1398 = add <8 x i64> %1397, splat (i64 64)
  %1399 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1396, 0
  %1400 = insertvalue { <8 x ptr>, <8 x i64> } %1399, <8 x i64> %1398, 1
  %.state834 = load <8 x float>, ptr %.slot85, align 32
  %1401 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1402 = extractvalue { <8 x ptr>, <8 x i64> } %1400, 1
  %1403 = extractelement <8 x ptr> %1401, i32 0
  %1404 = extractelement <8 x i64> %1402, i32 0
  %1405 = sub i64 %1404, 0
  %1406 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1407 = select i1 %1406, i64 %1405, i64 0
  %private.contiguous.address835 = getelementptr i8, ptr %1403, i64 %1407
  %private.contiguous.preserve836 = load <8 x float>, ptr %private.contiguous.address835, align 4
  %1408 = select <8 x i1> %101, <8 x float> %.state834, <8 x float> %private.contiguous.preserve836
  store <8 x float> %1408, ptr %private.contiguous.address835, align 4
  %1409 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1410 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %1411 = add <8 x i64> %1410, splat (i64 96)
  %1412 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1409, 0
  %1413 = insertvalue { <8 x ptr>, <8 x i64> } %1412, <8 x i64> %1411, 1
  %.state837 = load <8 x float>, ptr %.slot86, align 32
  %1414 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1415 = extractvalue { <8 x ptr>, <8 x i64> } %1413, 1
  %1416 = extractelement <8 x ptr> %1414, i32 0
  %1417 = extractelement <8 x i64> %1415, i32 0
  %1418 = sub i64 %1417, 0
  %1419 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1420 = select i1 %1419, i64 %1418, i64 0
  %private.contiguous.address838 = getelementptr i8, ptr %1416, i64 %1420
  %private.contiguous.preserve839 = load <8 x float>, ptr %private.contiguous.address838, align 4
  %1421 = select <8 x i1> %101, <8 x float> %.state837, <8 x float> %private.contiguous.preserve839
  store <8 x float> %1421, ptr %private.contiguous.address838, align 4
  %1422 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1423 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %1424 = add <8 x i64> %1423, splat (i64 128)
  %1425 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1422, 0
  %1426 = insertvalue { <8 x ptr>, <8 x i64> } %1425, <8 x i64> %1424, 1
  %.state840 = load <8 x float>, ptr %.slot87, align 32
  %1427 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1428 = extractvalue { <8 x ptr>, <8 x i64> } %1426, 1
  %1429 = extractelement <8 x ptr> %1427, i32 0
  %1430 = extractelement <8 x i64> %1428, i32 0
  %1431 = sub i64 %1430, 0
  %1432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1433 = select i1 %1432, i64 %1431, i64 0
  %private.contiguous.address841 = getelementptr i8, ptr %1429, i64 %1433
  %private.contiguous.preserve842 = load <8 x float>, ptr %private.contiguous.address841, align 4
  %1434 = select <8 x i1> %101, <8 x float> %.state840, <8 x float> %private.contiguous.preserve842
  store <8 x float> %1434, ptr %private.contiguous.address841, align 4
  %1435 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1436 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %1437 = add <8 x i64> %1436, splat (i64 160)
  %1438 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1435, 0
  %1439 = insertvalue { <8 x ptr>, <8 x i64> } %1438, <8 x i64> %1437, 1
  %.state843 = load <8 x float>, ptr %.slot88, align 32
  %1440 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1441 = extractvalue { <8 x ptr>, <8 x i64> } %1439, 1
  %1442 = extractelement <8 x ptr> %1440, i32 0
  %1443 = extractelement <8 x i64> %1441, i32 0
  %1444 = sub i64 %1443, 0
  %1445 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1446 = select i1 %1445, i64 %1444, i64 0
  %private.contiguous.address844 = getelementptr i8, ptr %1442, i64 %1446
  %private.contiguous.preserve845 = load <8 x float>, ptr %private.contiguous.address844, align 4
  %1447 = select <8 x i1> %101, <8 x float> %.state843, <8 x float> %private.contiguous.preserve845
  store <8 x float> %1447, ptr %private.contiguous.address844, align 4
  %1448 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1449 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %1450 = add <8 x i64> %1449, splat (i64 192)
  %1451 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1448, 0
  %1452 = insertvalue { <8 x ptr>, <8 x i64> } %1451, <8 x i64> %1450, 1
  %.state846 = load <8 x float>, ptr %.slot89, align 32
  %1453 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1454 = extractvalue { <8 x ptr>, <8 x i64> } %1452, 1
  %1455 = extractelement <8 x ptr> %1453, i32 0
  %1456 = extractelement <8 x i64> %1454, i32 0
  %1457 = sub i64 %1456, 0
  %1458 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1459 = select i1 %1458, i64 %1457, i64 0
  %private.contiguous.address847 = getelementptr i8, ptr %1455, i64 %1459
  %private.contiguous.preserve848 = load <8 x float>, ptr %private.contiguous.address847, align 4
  %1460 = select <8 x i1> %101, <8 x float> %.state846, <8 x float> %private.contiguous.preserve848
  store <8 x float> %1460, ptr %private.contiguous.address847, align 4
  %1461 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1462 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %1463 = add <8 x i64> %1462, splat (i64 224)
  %1464 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1461, 0
  %1465 = insertvalue { <8 x ptr>, <8 x i64> } %1464, <8 x i64> %1463, 1
  %.state849 = load <8 x float>, ptr %.slot90, align 32
  %1466 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1467 = extractvalue { <8 x ptr>, <8 x i64> } %1465, 1
  %1468 = extractelement <8 x ptr> %1466, i32 0
  %1469 = extractelement <8 x i64> %1467, i32 0
  %1470 = sub i64 %1469, 0
  %1471 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1472 = select i1 %1471, i64 %1470, i64 0
  %private.contiguous.address850 = getelementptr i8, ptr %1468, i64 %1472
  %private.contiguous.preserve851 = load <8 x float>, ptr %private.contiguous.address850, align 4
  %1473 = select <8 x i1> %101, <8 x float> %.state849, <8 x float> %private.contiguous.preserve851
  store <8 x float> %1473, ptr %private.contiguous.address850, align 4
  store i64 0, ptr %.slot184, align 4
  br label %direct.schedule.89

direct.schedule.89:                               ; preds = %direct.schedule.90, %direct.schedule.88
  %.state852 = load i64, ptr %.slot184, align 4
  %1474 = icmp slt i64 %.state852, 384
  br i1 %1474, label %direct.true853, label %direct.false854

direct.schedule.90:                               ; preds = %direct.true853
  %.state855 = load i64, ptr %.slot184, align 4
  %1475 = srem i64 %.state855, 48
  %.state856 = load i64, ptr %.slot184, align 4
  %1476 = sdiv i64 %.state856, 48
  %.spill.load857 = load <8 x i64>, ptr %.spill, align 64
  %1477 = add <8 x i64> %.spill.load857, zeroinitializer
  %1478 = add <8 x i64> zeroinitializer, %1477
  %.spill.load858 = load <8 x i64>, ptr %.spill69, align 64
  %.splatinsert859 = insertelement <8 x i64> poison, i64 %1476, i64 0
  %.splat860 = shufflevector <8 x i64> %.splatinsert859, <8 x i64> poison, <8 x i32> zeroinitializer
  %1479 = add <8 x i64> %.spill.load858, %.splat860
  %1480 = mul <8 x i64> %1478, splat (i64 64)
  %1481 = add <8 x i64> %1480, %1479
  %1482 = add i64 0, %1475
  %1483 = mul <8 x i64> %1481, splat (i64 48)
  %.splatinsert861 = insertelement <8 x i64> poison, i64 %1482, i64 0
  %.splat862 = shufflevector <8 x i64> %.splatinsert861, <8 x i64> poison, <8 x i32> zeroinitializer
  %1484 = add <8 x i64> %1483, %.splat862
  %1485 = add i64 0, %1476
  %1486 = mul i64 %1485, 48
  %1487 = add i64 %1486, %1475
  %tile_snapshot.spill.load863 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill71, align 64
  %1488 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load863, 0
  %1489 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load863, 1
  %.splatinsert864 = insertelement <8 x i64> poison, i64 %1487, i64 0
  %.splat865 = shufflevector <8 x i64> %.splatinsert864, <8 x i64> poison, <8 x i32> zeroinitializer
  %1490 = mul <8 x i64> %.splat865, splat (i64 32)
  %1491 = add <8 x i64> %1489, %1490
  %1492 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1488, 0
  %1493 = insertvalue { <8 x ptr>, <8 x i64> } %1492, <8 x i64> %1491, 1
  %1494 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1495 = extractvalue { <8 x ptr>, <8 x i64> } %1493, 1
  %1496 = extractelement <8 x ptr> %1494, i32 0
  %1497 = extractelement <8 x i64> %1495, i32 0
  %1498 = sub i64 %1497, 0
  %1499 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1500 = select i1 %1499, i64 %1498, i64 0
  %private.contiguous.address866 = getelementptr i8, ptr %1496, i64 %1500
  %private.contiguous.load867 = load <8 x float>, ptr %private.contiguous.address866, align 4
  %1501 = select <8 x i1> %101, <8 x float> %private.contiguous.load867, <8 x float> zeroinitializer
  %tile_snapshot.spill.load868 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill183, align 64
  %1502 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load868, 0
  %1503 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load868, 1
  %.splatinsert869 = insertelement <8 x i64> poison, i64 %1485, i64 0
  %.splat870 = shufflevector <8 x i64> %.splatinsert869, <8 x i64> poison, <8 x i32> zeroinitializer
  %1504 = mul <8 x i64> %.splat870, splat (i64 32)
  %1505 = add <8 x i64> %1503, %1504
  %1506 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1502, 0
  %1507 = insertvalue { <8 x ptr>, <8 x i64> } %1506, <8 x i64> %1505, 1
  %1508 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1509 = extractvalue { <8 x ptr>, <8 x i64> } %1507, 1
  %1510 = extractelement <8 x ptr> %1508, i32 0
  %1511 = extractelement <8 x i64> %1509, i32 0
  %1512 = sub i64 %1511, 0
  %1513 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1514 = select i1 %1513, i64 %1512, i64 0
  %private.contiguous.address871 = getelementptr i8, ptr %1510, i64 %1514
  %private.contiguous.load872 = load <8 x float>, ptr %private.contiguous.address871, align 4
  %1515 = select <8 x i1> %101, <8 x float> %private.contiguous.load872, <8 x float> zeroinitializer
  %1516 = fdiv <8 x float> %1501, %1515
  %1517 = extractvalue { ptr, i64 } %77, 0
  %1518 = mul <8 x i64> %1484, splat (i64 4)
  %1519 = getelementptr i8, ptr %1517, <8 x i64> %1518
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1516, <8 x ptr> align 1 %1519, <8 x i1> %101)
  %.state873 = load i64, ptr %.slot184, align 4
  %1520 = add i64 %.state873, 1
  store i64 %1520, ptr %.slot184, align 4
  br label %direct.schedule.89

direct.schedule.91:                               ; preds = %direct.false854
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true207:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false208:                                  ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true215:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false216:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.88

direct.true219:                                   ; preds = %direct.schedule.9
  br label %direct.schedule.10

direct.false220:                                  ; preds = %direct.schedule.9
  br label %direct.schedule.13

direct.true229:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false230:                                  ; preds = %direct.schedule.10
  %1521 = load <8 x float>, ptr %.slot95, align 32
  %1522 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %1521
  store <8 x float> %1522, ptr %.slot95, align 32
  br label %direct.schedule.12

direct.true241:                                   ; preds = %direct.schedule.14
  br label %direct.schedule.15

direct.false242:                                  ; preds = %direct.schedule.14
  br label %direct.schedule.18

direct.true251:                                   ; preds = %direct.schedule.15
  br label %direct.schedule.16

direct.false252:                                  ; preds = %direct.schedule.15
  %1523 = load <8 x float>, ptr %.slot99, align 32
  %1524 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %1523
  store <8 x float> %1524, ptr %.slot99, align 32
  br label %direct.schedule.17

direct.true263:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false264:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

mma.active:                                       ; preds = %direct.schedule.21
  %1525 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 0
  %1526 = extractelement <8 x ptr> %1525, i64 0
  %1527 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 1
  %1528 = extractelement <8 x i64> %1527, i64 0
  %1529 = getelementptr i8, ptr %1526, i64 %1528
  %1530 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 0
  %1531 = extractelement <8 x ptr> %1530, i64 0
  %1532 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 1
  %1533 = extractelement <8 x i64> %1532, i64 0
  %1534 = getelementptr i8, ptr %1531, i64 %1533
  %1535 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 0
  %1536 = extractelement <8 x ptr> %1535, i64 0
  %1537 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 1
  %1538 = extractelement <8 x i64> %1537, i64 0
  %1539 = getelementptr i8, ptr %1536, i64 %1538
  %1540 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1541 = extractelement <8 x ptr> %1540, i64 0
  %1542 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1543 = extractelement <8 x i64> %1542, i64 0
  %1544 = getelementptr i8, ptr %1541, i64 %1543
  call void @llm_attention.strided_mma(ptr %1529, ptr %1534, ptr %1539, ptr %1544)
  br label %mma.continue

mma.continue:                                     ; preds = %mma.active, %direct.schedule.21
  %1545 = extractelement <8 x i1> %101, i64 1
  br i1 %1545, label %mma.active273, label %mma.continue274

mma.active273:                                    ; preds = %mma.continue
  %1546 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 0
  %1547 = extractelement <8 x ptr> %1546, i64 1
  %1548 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 1
  %1549 = extractelement <8 x i64> %1548, i64 1
  %1550 = getelementptr i8, ptr %1547, i64 %1549
  %1551 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 0
  %1552 = extractelement <8 x ptr> %1551, i64 1
  %1553 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 1
  %1554 = extractelement <8 x i64> %1553, i64 1
  %1555 = getelementptr i8, ptr %1552, i64 %1554
  %1556 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 0
  %1557 = extractelement <8 x ptr> %1556, i64 1
  %1558 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 1
  %1559 = extractelement <8 x i64> %1558, i64 1
  %1560 = getelementptr i8, ptr %1557, i64 %1559
  %1561 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1562 = extractelement <8 x ptr> %1561, i64 1
  %1563 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1564 = extractelement <8 x i64> %1563, i64 1
  %1565 = getelementptr i8, ptr %1562, i64 %1564
  call void @llm_attention.strided_mma(ptr %1550, ptr %1555, ptr %1560, ptr %1565)
  br label %mma.continue274

mma.continue274:                                  ; preds = %mma.active273, %mma.continue
  %1566 = extractelement <8 x i1> %101, i64 2
  br i1 %1566, label %mma.active275, label %mma.continue276

mma.active275:                                    ; preds = %mma.continue274
  %1567 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 0
  %1568 = extractelement <8 x ptr> %1567, i64 2
  %1569 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 1
  %1570 = extractelement <8 x i64> %1569, i64 2
  %1571 = getelementptr i8, ptr %1568, i64 %1570
  %1572 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 0
  %1573 = extractelement <8 x ptr> %1572, i64 2
  %1574 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 1
  %1575 = extractelement <8 x i64> %1574, i64 2
  %1576 = getelementptr i8, ptr %1573, i64 %1575
  %1577 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 0
  %1578 = extractelement <8 x ptr> %1577, i64 2
  %1579 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 1
  %1580 = extractelement <8 x i64> %1579, i64 2
  %1581 = getelementptr i8, ptr %1578, i64 %1580
  %1582 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1583 = extractelement <8 x ptr> %1582, i64 2
  %1584 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1585 = extractelement <8 x i64> %1584, i64 2
  %1586 = getelementptr i8, ptr %1583, i64 %1585
  call void @llm_attention.strided_mma(ptr %1571, ptr %1576, ptr %1581, ptr %1586)
  br label %mma.continue276

mma.continue276:                                  ; preds = %mma.active275, %mma.continue274
  %1587 = extractelement <8 x i1> %101, i64 3
  br i1 %1587, label %mma.active277, label %mma.continue278

mma.active277:                                    ; preds = %mma.continue276
  %1588 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 0
  %1589 = extractelement <8 x ptr> %1588, i64 3
  %1590 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 1
  %1591 = extractelement <8 x i64> %1590, i64 3
  %1592 = getelementptr i8, ptr %1589, i64 %1591
  %1593 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 0
  %1594 = extractelement <8 x ptr> %1593, i64 3
  %1595 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 1
  %1596 = extractelement <8 x i64> %1595, i64 3
  %1597 = getelementptr i8, ptr %1594, i64 %1596
  %1598 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 0
  %1599 = extractelement <8 x ptr> %1598, i64 3
  %1600 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 1
  %1601 = extractelement <8 x i64> %1600, i64 3
  %1602 = getelementptr i8, ptr %1599, i64 %1601
  %1603 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1604 = extractelement <8 x ptr> %1603, i64 3
  %1605 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1606 = extractelement <8 x i64> %1605, i64 3
  %1607 = getelementptr i8, ptr %1604, i64 %1606
  call void @llm_attention.strided_mma(ptr %1592, ptr %1597, ptr %1602, ptr %1607)
  br label %mma.continue278

mma.continue278:                                  ; preds = %mma.active277, %mma.continue276
  %1608 = extractelement <8 x i1> %101, i64 4
  br i1 %1608, label %mma.active279, label %mma.continue280

mma.active279:                                    ; preds = %mma.continue278
  %1609 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 0
  %1610 = extractelement <8 x ptr> %1609, i64 4
  %1611 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 1
  %1612 = extractelement <8 x i64> %1611, i64 4
  %1613 = getelementptr i8, ptr %1610, i64 %1612
  %1614 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 0
  %1615 = extractelement <8 x ptr> %1614, i64 4
  %1616 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 1
  %1617 = extractelement <8 x i64> %1616, i64 4
  %1618 = getelementptr i8, ptr %1615, i64 %1617
  %1619 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 0
  %1620 = extractelement <8 x ptr> %1619, i64 4
  %1621 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 1
  %1622 = extractelement <8 x i64> %1621, i64 4
  %1623 = getelementptr i8, ptr %1620, i64 %1622
  %1624 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1625 = extractelement <8 x ptr> %1624, i64 4
  %1626 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1627 = extractelement <8 x i64> %1626, i64 4
  %1628 = getelementptr i8, ptr %1625, i64 %1627
  call void @llm_attention.strided_mma(ptr %1613, ptr %1618, ptr %1623, ptr %1628)
  br label %mma.continue280

mma.continue280:                                  ; preds = %mma.active279, %mma.continue278
  %1629 = extractelement <8 x i1> %101, i64 5
  br i1 %1629, label %mma.active281, label %mma.continue282

mma.active281:                                    ; preds = %mma.continue280
  %1630 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 0
  %1631 = extractelement <8 x ptr> %1630, i64 5
  %1632 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 1
  %1633 = extractelement <8 x i64> %1632, i64 5
  %1634 = getelementptr i8, ptr %1631, i64 %1633
  %1635 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 0
  %1636 = extractelement <8 x ptr> %1635, i64 5
  %1637 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 1
  %1638 = extractelement <8 x i64> %1637, i64 5
  %1639 = getelementptr i8, ptr %1636, i64 %1638
  %1640 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 0
  %1641 = extractelement <8 x ptr> %1640, i64 5
  %1642 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 1
  %1643 = extractelement <8 x i64> %1642, i64 5
  %1644 = getelementptr i8, ptr %1641, i64 %1643
  %1645 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1646 = extractelement <8 x ptr> %1645, i64 5
  %1647 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1648 = extractelement <8 x i64> %1647, i64 5
  %1649 = getelementptr i8, ptr %1646, i64 %1648
  call void @llm_attention.strided_mma(ptr %1634, ptr %1639, ptr %1644, ptr %1649)
  br label %mma.continue282

mma.continue282:                                  ; preds = %mma.active281, %mma.continue280
  %1650 = extractelement <8 x i1> %101, i64 6
  br i1 %1650, label %mma.active283, label %mma.continue284

mma.active283:                                    ; preds = %mma.continue282
  %1651 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 0
  %1652 = extractelement <8 x ptr> %1651, i64 6
  %1653 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 1
  %1654 = extractelement <8 x i64> %1653, i64 6
  %1655 = getelementptr i8, ptr %1652, i64 %1654
  %1656 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 0
  %1657 = extractelement <8 x ptr> %1656, i64 6
  %1658 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 1
  %1659 = extractelement <8 x i64> %1658, i64 6
  %1660 = getelementptr i8, ptr %1657, i64 %1659
  %1661 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 0
  %1662 = extractelement <8 x ptr> %1661, i64 6
  %1663 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 1
  %1664 = extractelement <8 x i64> %1663, i64 6
  %1665 = getelementptr i8, ptr %1662, i64 %1664
  %1666 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1667 = extractelement <8 x ptr> %1666, i64 6
  %1668 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1669 = extractelement <8 x i64> %1668, i64 6
  %1670 = getelementptr i8, ptr %1667, i64 %1669
  call void @llm_attention.strided_mma(ptr %1655, ptr %1660, ptr %1665, ptr %1670)
  br label %mma.continue284

mma.continue284:                                  ; preds = %mma.active283, %mma.continue282
  %1671 = extractelement <8 x i1> %101, i64 7
  br i1 %1671, label %mma.active285, label %mma.continue286

mma.active285:                                    ; preds = %mma.continue284
  %1672 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 0
  %1673 = extractelement <8 x ptr> %1672, i64 7
  %1674 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 1
  %1675 = extractelement <8 x i64> %1674, i64 7
  %1676 = getelementptr i8, ptr %1673, i64 %1675
  %1677 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 0
  %1678 = extractelement <8 x ptr> %1677, i64 7
  %1679 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 1
  %1680 = extractelement <8 x i64> %1679, i64 7
  %1681 = getelementptr i8, ptr %1678, i64 %1680
  %1682 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 0
  %1683 = extractelement <8 x ptr> %1682, i64 7
  %1684 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 1
  %1685 = extractelement <8 x i64> %1684, i64 7
  %1686 = getelementptr i8, ptr %1683, i64 %1685
  %1687 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1688 = extractelement <8 x ptr> %1687, i64 7
  %1689 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1690 = extractelement <8 x i64> %1689, i64 7
  %1691 = getelementptr i8, ptr %1688, i64 %1690
  call void @llm_attention.strided_mma(ptr %1676, ptr %1681, ptr %1686, ptr %1691)
  br label %mma.continue286

mma.continue286:                                  ; preds = %mma.active285, %mma.continue284
  %.spill.load287 = load i64, ptr %.spill91, align 4
  %1692 = add i64 0, %.spill.load287
  %.spill.load288 = load i64, ptr %.spill91, align 4
  %1693 = add i64 1, %.spill.load288
  %.spill.load289 = load i64, ptr %.spill91, align 4
  %1694 = add i64 2, %.spill.load289
  %.spill.load290 = load i64, ptr %.spill91, align 4
  %1695 = add i64 3, %.spill.load290
  %.spill.load291 = load i64, ptr %.spill91, align 4
  %1696 = add i64 4, %.spill.load291
  %.spill.load292 = load i64, ptr %.spill91, align 4
  %1697 = add i64 5, %.spill.load292
  %.spill.load293 = load i64, ptr %.spill91, align 4
  %1698 = add i64 6, %.spill.load293
  %.spill.load294 = load i64, ptr %.spill91, align 4
  %1699 = add i64 7, %.spill.load294
  %.spill.load295 = load i64, ptr %.spill91, align 4
  %1700 = add i64 8, %.spill.load295
  %.spill.load296 = load i64, ptr %.spill91, align 4
  %1701 = add i64 9, %.spill.load296
  %.spill.load297 = load i64, ptr %.spill91, align 4
  %1702 = add i64 10, %.spill.load297
  %.spill.load298 = load i64, ptr %.spill91, align 4
  %1703 = add i64 11, %.spill.load298
  %.spill.load299 = load i64, ptr %.spill91, align 4
  %1704 = add i64 12, %.spill.load299
  %.spill.load300 = load i64, ptr %.spill91, align 4
  %1705 = add i64 13, %.spill.load300
  %.spill.load301 = load i64, ptr %.spill91, align 4
  %1706 = add i64 14, %.spill.load301
  %.spill.load302 = load i64, ptr %.spill91, align 4
  %1707 = add i64 15, %.spill.load302
  %1708 = icmp slt i64 %1692, 129
  %1709 = icmp slt i64 %1693, 129
  %1710 = icmp slt i64 %1694, 129
  %1711 = icmp slt i64 %1695, 129
  %1712 = icmp slt i64 %1696, 129
  %1713 = icmp slt i64 %1697, 129
  %1714 = icmp slt i64 %1698, 129
  %1715 = icmp slt i64 %1699, 129
  %1716 = icmp slt i64 %1700, 129
  %1717 = icmp slt i64 %1701, 129
  %1718 = icmp slt i64 %1702, 129
  %1719 = icmp slt i64 %1703, 129
  %1720 = icmp slt i64 %1704, 129
  %1721 = icmp slt i64 %1705, 129
  %1722 = icmp slt i64 %1706, 129
  %1723 = icmp slt i64 %1707, 129
  %1724 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %1725 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1726 = extractvalue { <8 x ptr>, <8 x i64> } %1724, 0
  %1727 = select <8 x i1> %101, <8 x ptr> %1725, <8 x ptr> %1726
  %1728 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1729 = extractvalue { <8 x ptr>, <8 x i64> } %1724, 1
  %1730 = select <8 x i1> %101, <8 x i64> %1728, <8 x i64> %1729
  %1731 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1727, 0
  %1732 = insertvalue { <8 x ptr>, <8 x i64> } %1731, <8 x i64> %1730, 1
  store { <8 x ptr>, <8 x i64> } %1732, ptr %tile_snapshot.spill103, align 64
  %1733 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1734 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1735 = add <8 x i64> %1734, zeroinitializer
  %1736 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1733, 0
  %1737 = insertvalue { <8 x ptr>, <8 x i64> } %1736, <8 x i64> %1735, 1
  %.splatinsert303 = insertelement <8 x i1> poison, i1 %1708, i64 0
  %.splat304 = shufflevector <8 x i1> %.splatinsert303, <8 x i1> poison, <8 x i32> zeroinitializer
  %1738 = extractvalue { <8 x ptr>, <8 x i64> } %1737, 0
  %1739 = extractvalue { <8 x ptr>, <8 x i64> } %1737, 1
  %1740 = getelementptr i8, <8 x ptr> %1738, <8 x i64> %1739
  %1741 = zext <8 x i1> %.splat304 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1741, <8 x ptr> align 1 %1740, <8 x i1> %101)
  %1742 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1743 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1744 = add <8 x i64> %1743, splat (i64 1)
  %1745 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1742, 0
  %1746 = insertvalue { <8 x ptr>, <8 x i64> } %1745, <8 x i64> %1744, 1
  %.splatinsert305 = insertelement <8 x i1> poison, i1 %1709, i64 0
  %.splat306 = shufflevector <8 x i1> %.splatinsert305, <8 x i1> poison, <8 x i32> zeroinitializer
  %1747 = extractvalue { <8 x ptr>, <8 x i64> } %1746, 0
  %1748 = extractvalue { <8 x ptr>, <8 x i64> } %1746, 1
  %1749 = getelementptr i8, <8 x ptr> %1747, <8 x i64> %1748
  %1750 = zext <8 x i1> %.splat306 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1750, <8 x ptr> align 1 %1749, <8 x i1> %101)
  %1751 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1752 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1753 = add <8 x i64> %1752, splat (i64 2)
  %1754 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1751, 0
  %1755 = insertvalue { <8 x ptr>, <8 x i64> } %1754, <8 x i64> %1753, 1
  %.splatinsert307 = insertelement <8 x i1> poison, i1 %1710, i64 0
  %.splat308 = shufflevector <8 x i1> %.splatinsert307, <8 x i1> poison, <8 x i32> zeroinitializer
  %1756 = extractvalue { <8 x ptr>, <8 x i64> } %1755, 0
  %1757 = extractvalue { <8 x ptr>, <8 x i64> } %1755, 1
  %1758 = getelementptr i8, <8 x ptr> %1756, <8 x i64> %1757
  %1759 = zext <8 x i1> %.splat308 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1759, <8 x ptr> align 1 %1758, <8 x i1> %101)
  %1760 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1761 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1762 = add <8 x i64> %1761, splat (i64 3)
  %1763 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1760, 0
  %1764 = insertvalue { <8 x ptr>, <8 x i64> } %1763, <8 x i64> %1762, 1
  %.splatinsert309 = insertelement <8 x i1> poison, i1 %1711, i64 0
  %.splat310 = shufflevector <8 x i1> %.splatinsert309, <8 x i1> poison, <8 x i32> zeroinitializer
  %1765 = extractvalue { <8 x ptr>, <8 x i64> } %1764, 0
  %1766 = extractvalue { <8 x ptr>, <8 x i64> } %1764, 1
  %1767 = getelementptr i8, <8 x ptr> %1765, <8 x i64> %1766
  %1768 = zext <8 x i1> %.splat310 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1768, <8 x ptr> align 1 %1767, <8 x i1> %101)
  %1769 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1770 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1771 = add <8 x i64> %1770, splat (i64 4)
  %1772 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1769, 0
  %1773 = insertvalue { <8 x ptr>, <8 x i64> } %1772, <8 x i64> %1771, 1
  %.splatinsert311 = insertelement <8 x i1> poison, i1 %1712, i64 0
  %.splat312 = shufflevector <8 x i1> %.splatinsert311, <8 x i1> poison, <8 x i32> zeroinitializer
  %1774 = extractvalue { <8 x ptr>, <8 x i64> } %1773, 0
  %1775 = extractvalue { <8 x ptr>, <8 x i64> } %1773, 1
  %1776 = getelementptr i8, <8 x ptr> %1774, <8 x i64> %1775
  %1777 = zext <8 x i1> %.splat312 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1777, <8 x ptr> align 1 %1776, <8 x i1> %101)
  %1778 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1779 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1780 = add <8 x i64> %1779, splat (i64 5)
  %1781 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1778, 0
  %1782 = insertvalue { <8 x ptr>, <8 x i64> } %1781, <8 x i64> %1780, 1
  %.splatinsert313 = insertelement <8 x i1> poison, i1 %1713, i64 0
  %.splat314 = shufflevector <8 x i1> %.splatinsert313, <8 x i1> poison, <8 x i32> zeroinitializer
  %1783 = extractvalue { <8 x ptr>, <8 x i64> } %1782, 0
  %1784 = extractvalue { <8 x ptr>, <8 x i64> } %1782, 1
  %1785 = getelementptr i8, <8 x ptr> %1783, <8 x i64> %1784
  %1786 = zext <8 x i1> %.splat314 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1786, <8 x ptr> align 1 %1785, <8 x i1> %101)
  %1787 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1788 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1789 = add <8 x i64> %1788, splat (i64 6)
  %1790 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1787, 0
  %1791 = insertvalue { <8 x ptr>, <8 x i64> } %1790, <8 x i64> %1789, 1
  %.splatinsert315 = insertelement <8 x i1> poison, i1 %1714, i64 0
  %.splat316 = shufflevector <8 x i1> %.splatinsert315, <8 x i1> poison, <8 x i32> zeroinitializer
  %1792 = extractvalue { <8 x ptr>, <8 x i64> } %1791, 0
  %1793 = extractvalue { <8 x ptr>, <8 x i64> } %1791, 1
  %1794 = getelementptr i8, <8 x ptr> %1792, <8 x i64> %1793
  %1795 = zext <8 x i1> %.splat316 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1795, <8 x ptr> align 1 %1794, <8 x i1> %101)
  %1796 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1797 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1798 = add <8 x i64> %1797, splat (i64 7)
  %1799 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1796, 0
  %1800 = insertvalue { <8 x ptr>, <8 x i64> } %1799, <8 x i64> %1798, 1
  %.splatinsert317 = insertelement <8 x i1> poison, i1 %1715, i64 0
  %.splat318 = shufflevector <8 x i1> %.splatinsert317, <8 x i1> poison, <8 x i32> zeroinitializer
  %1801 = extractvalue { <8 x ptr>, <8 x i64> } %1800, 0
  %1802 = extractvalue { <8 x ptr>, <8 x i64> } %1800, 1
  %1803 = getelementptr i8, <8 x ptr> %1801, <8 x i64> %1802
  %1804 = zext <8 x i1> %.splat318 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1804, <8 x ptr> align 1 %1803, <8 x i1> %101)
  %1805 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1806 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1807 = add <8 x i64> %1806, splat (i64 8)
  %1808 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1805, 0
  %1809 = insertvalue { <8 x ptr>, <8 x i64> } %1808, <8 x i64> %1807, 1
  %.splatinsert319 = insertelement <8 x i1> poison, i1 %1716, i64 0
  %.splat320 = shufflevector <8 x i1> %.splatinsert319, <8 x i1> poison, <8 x i32> zeroinitializer
  %1810 = extractvalue { <8 x ptr>, <8 x i64> } %1809, 0
  %1811 = extractvalue { <8 x ptr>, <8 x i64> } %1809, 1
  %1812 = getelementptr i8, <8 x ptr> %1810, <8 x i64> %1811
  %1813 = zext <8 x i1> %.splat320 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1813, <8 x ptr> align 1 %1812, <8 x i1> %101)
  %1814 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1815 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1816 = add <8 x i64> %1815, splat (i64 9)
  %1817 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1814, 0
  %1818 = insertvalue { <8 x ptr>, <8 x i64> } %1817, <8 x i64> %1816, 1
  %.splatinsert321 = insertelement <8 x i1> poison, i1 %1717, i64 0
  %.splat322 = shufflevector <8 x i1> %.splatinsert321, <8 x i1> poison, <8 x i32> zeroinitializer
  %1819 = extractvalue { <8 x ptr>, <8 x i64> } %1818, 0
  %1820 = extractvalue { <8 x ptr>, <8 x i64> } %1818, 1
  %1821 = getelementptr i8, <8 x ptr> %1819, <8 x i64> %1820
  %1822 = zext <8 x i1> %.splat322 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1822, <8 x ptr> align 1 %1821, <8 x i1> %101)
  %1823 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1824 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1825 = add <8 x i64> %1824, splat (i64 10)
  %1826 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1823, 0
  %1827 = insertvalue { <8 x ptr>, <8 x i64> } %1826, <8 x i64> %1825, 1
  %.splatinsert323 = insertelement <8 x i1> poison, i1 %1718, i64 0
  %.splat324 = shufflevector <8 x i1> %.splatinsert323, <8 x i1> poison, <8 x i32> zeroinitializer
  %1828 = extractvalue { <8 x ptr>, <8 x i64> } %1827, 0
  %1829 = extractvalue { <8 x ptr>, <8 x i64> } %1827, 1
  %1830 = getelementptr i8, <8 x ptr> %1828, <8 x i64> %1829
  %1831 = zext <8 x i1> %.splat324 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1831, <8 x ptr> align 1 %1830, <8 x i1> %101)
  %1832 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1833 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1834 = add <8 x i64> %1833, splat (i64 11)
  %1835 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1832, 0
  %1836 = insertvalue { <8 x ptr>, <8 x i64> } %1835, <8 x i64> %1834, 1
  %.splatinsert325 = insertelement <8 x i1> poison, i1 %1719, i64 0
  %.splat326 = shufflevector <8 x i1> %.splatinsert325, <8 x i1> poison, <8 x i32> zeroinitializer
  %1837 = extractvalue { <8 x ptr>, <8 x i64> } %1836, 0
  %1838 = extractvalue { <8 x ptr>, <8 x i64> } %1836, 1
  %1839 = getelementptr i8, <8 x ptr> %1837, <8 x i64> %1838
  %1840 = zext <8 x i1> %.splat326 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1840, <8 x ptr> align 1 %1839, <8 x i1> %101)
  %1841 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1842 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1843 = add <8 x i64> %1842, splat (i64 12)
  %1844 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1841, 0
  %1845 = insertvalue { <8 x ptr>, <8 x i64> } %1844, <8 x i64> %1843, 1
  %.splatinsert327 = insertelement <8 x i1> poison, i1 %1720, i64 0
  %.splat328 = shufflevector <8 x i1> %.splatinsert327, <8 x i1> poison, <8 x i32> zeroinitializer
  %1846 = extractvalue { <8 x ptr>, <8 x i64> } %1845, 0
  %1847 = extractvalue { <8 x ptr>, <8 x i64> } %1845, 1
  %1848 = getelementptr i8, <8 x ptr> %1846, <8 x i64> %1847
  %1849 = zext <8 x i1> %.splat328 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1849, <8 x ptr> align 1 %1848, <8 x i1> %101)
  %1850 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1851 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1852 = add <8 x i64> %1851, splat (i64 13)
  %1853 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1850, 0
  %1854 = insertvalue { <8 x ptr>, <8 x i64> } %1853, <8 x i64> %1852, 1
  %.splatinsert329 = insertelement <8 x i1> poison, i1 %1721, i64 0
  %.splat330 = shufflevector <8 x i1> %.splatinsert329, <8 x i1> poison, <8 x i32> zeroinitializer
  %1855 = extractvalue { <8 x ptr>, <8 x i64> } %1854, 0
  %1856 = extractvalue { <8 x ptr>, <8 x i64> } %1854, 1
  %1857 = getelementptr i8, <8 x ptr> %1855, <8 x i64> %1856
  %1858 = zext <8 x i1> %.splat330 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1858, <8 x ptr> align 1 %1857, <8 x i1> %101)
  %1859 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1860 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1861 = add <8 x i64> %1860, splat (i64 14)
  %1862 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1859, 0
  %1863 = insertvalue { <8 x ptr>, <8 x i64> } %1862, <8 x i64> %1861, 1
  %.splatinsert331 = insertelement <8 x i1> poison, i1 %1722, i64 0
  %.splat332 = shufflevector <8 x i1> %.splatinsert331, <8 x i1> poison, <8 x i32> zeroinitializer
  %1864 = extractvalue { <8 x ptr>, <8 x i64> } %1863, 0
  %1865 = extractvalue { <8 x ptr>, <8 x i64> } %1863, 1
  %1866 = getelementptr i8, <8 x ptr> %1864, <8 x i64> %1865
  %1867 = zext <8 x i1> %.splat332 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1867, <8 x ptr> align 1 %1866, <8 x i1> %101)
  %1868 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1869 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1870 = add <8 x i64> %1869, splat (i64 15)
  %1871 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1868, 0
  %1872 = insertvalue { <8 x ptr>, <8 x i64> } %1871, <8 x i64> %1870, 1
  %.splatinsert333 = insertelement <8 x i1> poison, i1 %1723, i64 0
  %.splat334 = shufflevector <8 x i1> %.splatinsert333, <8 x i1> poison, <8 x i32> zeroinitializer
  %1873 = extractvalue { <8 x ptr>, <8 x i64> } %1872, 0
  %1874 = extractvalue { <8 x ptr>, <8 x i64> } %1872, 1
  %1875 = getelementptr i8, <8 x ptr> %1873, <8 x i64> %1874
  %1876 = zext <8 x i1> %.splat334 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1876, <8 x ptr> align 1 %1875, <8 x i1> %101)
  %1877 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill104, align 64
  %1878 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1879 = extractvalue { <8 x ptr>, <8 x i64> } %1877, 0
  %1880 = select <8 x i1> %101, <8 x ptr> %1878, <8 x ptr> %1879
  %1881 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %1882 = extractvalue { <8 x ptr>, <8 x i64> } %1877, 1
  %1883 = select <8 x i1> %101, <8 x i64> %1881, <8 x i64> %1882
  %1884 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1880, 0
  %1885 = insertvalue { <8 x ptr>, <8 x i64> } %1884, <8 x i64> %1883, 1
  store { <8 x ptr>, <8 x i64> } %1885, ptr %tile_snapshot.spill104, align 64
  %1886 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1887 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %1888 = add <8 x i64> %1887, zeroinitializer
  %1889 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1886, 0
  %1890 = insertvalue { <8 x ptr>, <8 x i64> } %1889, <8 x i64> %1888, 1
  %.splatinsert335 = insertelement <8 x i64> poison, i64 %1692, i64 0
  %.splat336 = shufflevector <8 x i64> %.splatinsert335, <8 x i64> poison, <8 x i32> zeroinitializer
  %1891 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1892 = extractvalue { <8 x ptr>, <8 x i64> } %1890, 1
  %1893 = extractelement <8 x ptr> %1891, i32 0
  %1894 = extractelement <8 x i64> %1892, i32 0
  %1895 = sub i64 %1894, 0
  %1896 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1897 = select i1 %1896, i64 %1895, i64 0
  %private.contiguous.address337 = getelementptr i8, ptr %1893, i64 %1897
  %private.contiguous.preserve338 = load <8 x i64>, ptr %private.contiguous.address337, align 8
  %1898 = select <8 x i1> %101, <8 x i64> %.splat336, <8 x i64> %private.contiguous.preserve338
  store <8 x i64> %1898, ptr %private.contiguous.address337, align 8
  %1899 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1900 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %1901 = add <8 x i64> %1900, splat (i64 64)
  %1902 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1899, 0
  %1903 = insertvalue { <8 x ptr>, <8 x i64> } %1902, <8 x i64> %1901, 1
  %.splatinsert339 = insertelement <8 x i64> poison, i64 %1693, i64 0
  %.splat340 = shufflevector <8 x i64> %.splatinsert339, <8 x i64> poison, <8 x i32> zeroinitializer
  %1904 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1905 = extractvalue { <8 x ptr>, <8 x i64> } %1903, 1
  %1906 = extractelement <8 x ptr> %1904, i32 0
  %1907 = extractelement <8 x i64> %1905, i32 0
  %1908 = sub i64 %1907, 0
  %1909 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1910 = select i1 %1909, i64 %1908, i64 0
  %private.contiguous.address341 = getelementptr i8, ptr %1906, i64 %1910
  %private.contiguous.preserve342 = load <8 x i64>, ptr %private.contiguous.address341, align 8
  %1911 = select <8 x i1> %101, <8 x i64> %.splat340, <8 x i64> %private.contiguous.preserve342
  store <8 x i64> %1911, ptr %private.contiguous.address341, align 8
  %1912 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1913 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %1914 = add <8 x i64> %1913, splat (i64 128)
  %1915 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1912, 0
  %1916 = insertvalue { <8 x ptr>, <8 x i64> } %1915, <8 x i64> %1914, 1
  %.splatinsert343 = insertelement <8 x i64> poison, i64 %1694, i64 0
  %.splat344 = shufflevector <8 x i64> %.splatinsert343, <8 x i64> poison, <8 x i32> zeroinitializer
  %1917 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1918 = extractvalue { <8 x ptr>, <8 x i64> } %1916, 1
  %1919 = extractelement <8 x ptr> %1917, i32 0
  %1920 = extractelement <8 x i64> %1918, i32 0
  %1921 = sub i64 %1920, 0
  %1922 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1923 = select i1 %1922, i64 %1921, i64 0
  %private.contiguous.address345 = getelementptr i8, ptr %1919, i64 %1923
  %private.contiguous.preserve346 = load <8 x i64>, ptr %private.contiguous.address345, align 8
  %1924 = select <8 x i1> %101, <8 x i64> %.splat344, <8 x i64> %private.contiguous.preserve346
  store <8 x i64> %1924, ptr %private.contiguous.address345, align 8
  %1925 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1926 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %1927 = add <8 x i64> %1926, splat (i64 192)
  %1928 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1925, 0
  %1929 = insertvalue { <8 x ptr>, <8 x i64> } %1928, <8 x i64> %1927, 1
  %.splatinsert347 = insertelement <8 x i64> poison, i64 %1695, i64 0
  %.splat348 = shufflevector <8 x i64> %.splatinsert347, <8 x i64> poison, <8 x i32> zeroinitializer
  %1930 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1931 = extractvalue { <8 x ptr>, <8 x i64> } %1929, 1
  %1932 = extractelement <8 x ptr> %1930, i32 0
  %1933 = extractelement <8 x i64> %1931, i32 0
  %1934 = sub i64 %1933, 0
  %1935 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1936 = select i1 %1935, i64 %1934, i64 0
  %private.contiguous.address349 = getelementptr i8, ptr %1932, i64 %1936
  %private.contiguous.preserve350 = load <8 x i64>, ptr %private.contiguous.address349, align 8
  %1937 = select <8 x i1> %101, <8 x i64> %.splat348, <8 x i64> %private.contiguous.preserve350
  store <8 x i64> %1937, ptr %private.contiguous.address349, align 8
  %1938 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1939 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %1940 = add <8 x i64> %1939, splat (i64 256)
  %1941 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1938, 0
  %1942 = insertvalue { <8 x ptr>, <8 x i64> } %1941, <8 x i64> %1940, 1
  %.splatinsert351 = insertelement <8 x i64> poison, i64 %1696, i64 0
  %.splat352 = shufflevector <8 x i64> %.splatinsert351, <8 x i64> poison, <8 x i32> zeroinitializer
  %1943 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1944 = extractvalue { <8 x ptr>, <8 x i64> } %1942, 1
  %1945 = extractelement <8 x ptr> %1943, i32 0
  %1946 = extractelement <8 x i64> %1944, i32 0
  %1947 = sub i64 %1946, 0
  %1948 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1949 = select i1 %1948, i64 %1947, i64 0
  %private.contiguous.address353 = getelementptr i8, ptr %1945, i64 %1949
  %private.contiguous.preserve354 = load <8 x i64>, ptr %private.contiguous.address353, align 8
  %1950 = select <8 x i1> %101, <8 x i64> %.splat352, <8 x i64> %private.contiguous.preserve354
  store <8 x i64> %1950, ptr %private.contiguous.address353, align 8
  %1951 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1952 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %1953 = add <8 x i64> %1952, splat (i64 320)
  %1954 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1951, 0
  %1955 = insertvalue { <8 x ptr>, <8 x i64> } %1954, <8 x i64> %1953, 1
  %.splatinsert355 = insertelement <8 x i64> poison, i64 %1697, i64 0
  %.splat356 = shufflevector <8 x i64> %.splatinsert355, <8 x i64> poison, <8 x i32> zeroinitializer
  %1956 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1957 = extractvalue { <8 x ptr>, <8 x i64> } %1955, 1
  %1958 = extractelement <8 x ptr> %1956, i32 0
  %1959 = extractelement <8 x i64> %1957, i32 0
  %1960 = sub i64 %1959, 0
  %1961 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1962 = select i1 %1961, i64 %1960, i64 0
  %private.contiguous.address357 = getelementptr i8, ptr %1958, i64 %1962
  %private.contiguous.preserve358 = load <8 x i64>, ptr %private.contiguous.address357, align 8
  %1963 = select <8 x i1> %101, <8 x i64> %.splat356, <8 x i64> %private.contiguous.preserve358
  store <8 x i64> %1963, ptr %private.contiguous.address357, align 8
  %1964 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1965 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %1966 = add <8 x i64> %1965, splat (i64 384)
  %1967 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1964, 0
  %1968 = insertvalue { <8 x ptr>, <8 x i64> } %1967, <8 x i64> %1966, 1
  %.splatinsert359 = insertelement <8 x i64> poison, i64 %1698, i64 0
  %.splat360 = shufflevector <8 x i64> %.splatinsert359, <8 x i64> poison, <8 x i32> zeroinitializer
  %1969 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1970 = extractvalue { <8 x ptr>, <8 x i64> } %1968, 1
  %1971 = extractelement <8 x ptr> %1969, i32 0
  %1972 = extractelement <8 x i64> %1970, i32 0
  %1973 = sub i64 %1972, 0
  %1974 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1975 = select i1 %1974, i64 %1973, i64 0
  %private.contiguous.address361 = getelementptr i8, ptr %1971, i64 %1975
  %private.contiguous.preserve362 = load <8 x i64>, ptr %private.contiguous.address361, align 8
  %1976 = select <8 x i1> %101, <8 x i64> %.splat360, <8 x i64> %private.contiguous.preserve362
  store <8 x i64> %1976, ptr %private.contiguous.address361, align 8
  %1977 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1978 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %1979 = add <8 x i64> %1978, splat (i64 448)
  %1980 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1977, 0
  %1981 = insertvalue { <8 x ptr>, <8 x i64> } %1980, <8 x i64> %1979, 1
  %.splatinsert363 = insertelement <8 x i64> poison, i64 %1699, i64 0
  %.splat364 = shufflevector <8 x i64> %.splatinsert363, <8 x i64> poison, <8 x i32> zeroinitializer
  %1982 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1983 = extractvalue { <8 x ptr>, <8 x i64> } %1981, 1
  %1984 = extractelement <8 x ptr> %1982, i32 0
  %1985 = extractelement <8 x i64> %1983, i32 0
  %1986 = sub i64 %1985, 0
  %1987 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1988 = select i1 %1987, i64 %1986, i64 0
  %private.contiguous.address365 = getelementptr i8, ptr %1984, i64 %1988
  %private.contiguous.preserve366 = load <8 x i64>, ptr %private.contiguous.address365, align 8
  %1989 = select <8 x i1> %101, <8 x i64> %.splat364, <8 x i64> %private.contiguous.preserve366
  store <8 x i64> %1989, ptr %private.contiguous.address365, align 8
  %1990 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1991 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %1992 = add <8 x i64> %1991, splat (i64 512)
  %1993 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1990, 0
  %1994 = insertvalue { <8 x ptr>, <8 x i64> } %1993, <8 x i64> %1992, 1
  %.splatinsert367 = insertelement <8 x i64> poison, i64 %1700, i64 0
  %.splat368 = shufflevector <8 x i64> %.splatinsert367, <8 x i64> poison, <8 x i32> zeroinitializer
  %1995 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1996 = extractvalue { <8 x ptr>, <8 x i64> } %1994, 1
  %1997 = extractelement <8 x ptr> %1995, i32 0
  %1998 = extractelement <8 x i64> %1996, i32 0
  %1999 = sub i64 %1998, 0
  %2000 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2001 = select i1 %2000, i64 %1999, i64 0
  %private.contiguous.address369 = getelementptr i8, ptr %1997, i64 %2001
  %private.contiguous.preserve370 = load <8 x i64>, ptr %private.contiguous.address369, align 8
  %2002 = select <8 x i1> %101, <8 x i64> %.splat368, <8 x i64> %private.contiguous.preserve370
  store <8 x i64> %2002, ptr %private.contiguous.address369, align 8
  %2003 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2004 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2005 = add <8 x i64> %2004, splat (i64 576)
  %2006 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2003, 0
  %2007 = insertvalue { <8 x ptr>, <8 x i64> } %2006, <8 x i64> %2005, 1
  %.splatinsert371 = insertelement <8 x i64> poison, i64 %1701, i64 0
  %.splat372 = shufflevector <8 x i64> %.splatinsert371, <8 x i64> poison, <8 x i32> zeroinitializer
  %2008 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2009 = extractvalue { <8 x ptr>, <8 x i64> } %2007, 1
  %2010 = extractelement <8 x ptr> %2008, i32 0
  %2011 = extractelement <8 x i64> %2009, i32 0
  %2012 = sub i64 %2011, 0
  %2013 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2014 = select i1 %2013, i64 %2012, i64 0
  %private.contiguous.address373 = getelementptr i8, ptr %2010, i64 %2014
  %private.contiguous.preserve374 = load <8 x i64>, ptr %private.contiguous.address373, align 8
  %2015 = select <8 x i1> %101, <8 x i64> %.splat372, <8 x i64> %private.contiguous.preserve374
  store <8 x i64> %2015, ptr %private.contiguous.address373, align 8
  %2016 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2017 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2018 = add <8 x i64> %2017, splat (i64 640)
  %2019 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2016, 0
  %2020 = insertvalue { <8 x ptr>, <8 x i64> } %2019, <8 x i64> %2018, 1
  %.splatinsert375 = insertelement <8 x i64> poison, i64 %1702, i64 0
  %.splat376 = shufflevector <8 x i64> %.splatinsert375, <8 x i64> poison, <8 x i32> zeroinitializer
  %2021 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2022 = extractvalue { <8 x ptr>, <8 x i64> } %2020, 1
  %2023 = extractelement <8 x ptr> %2021, i32 0
  %2024 = extractelement <8 x i64> %2022, i32 0
  %2025 = sub i64 %2024, 0
  %2026 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2027 = select i1 %2026, i64 %2025, i64 0
  %private.contiguous.address377 = getelementptr i8, ptr %2023, i64 %2027
  %private.contiguous.preserve378 = load <8 x i64>, ptr %private.contiguous.address377, align 8
  %2028 = select <8 x i1> %101, <8 x i64> %.splat376, <8 x i64> %private.contiguous.preserve378
  store <8 x i64> %2028, ptr %private.contiguous.address377, align 8
  %2029 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2030 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2031 = add <8 x i64> %2030, splat (i64 704)
  %2032 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2029, 0
  %2033 = insertvalue { <8 x ptr>, <8 x i64> } %2032, <8 x i64> %2031, 1
  %.splatinsert379 = insertelement <8 x i64> poison, i64 %1703, i64 0
  %.splat380 = shufflevector <8 x i64> %.splatinsert379, <8 x i64> poison, <8 x i32> zeroinitializer
  %2034 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2035 = extractvalue { <8 x ptr>, <8 x i64> } %2033, 1
  %2036 = extractelement <8 x ptr> %2034, i32 0
  %2037 = extractelement <8 x i64> %2035, i32 0
  %2038 = sub i64 %2037, 0
  %2039 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2040 = select i1 %2039, i64 %2038, i64 0
  %private.contiguous.address381 = getelementptr i8, ptr %2036, i64 %2040
  %private.contiguous.preserve382 = load <8 x i64>, ptr %private.contiguous.address381, align 8
  %2041 = select <8 x i1> %101, <8 x i64> %.splat380, <8 x i64> %private.contiguous.preserve382
  store <8 x i64> %2041, ptr %private.contiguous.address381, align 8
  %2042 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2043 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2044 = add <8 x i64> %2043, splat (i64 768)
  %2045 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2042, 0
  %2046 = insertvalue { <8 x ptr>, <8 x i64> } %2045, <8 x i64> %2044, 1
  %.splatinsert383 = insertelement <8 x i64> poison, i64 %1704, i64 0
  %.splat384 = shufflevector <8 x i64> %.splatinsert383, <8 x i64> poison, <8 x i32> zeroinitializer
  %2047 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2048 = extractvalue { <8 x ptr>, <8 x i64> } %2046, 1
  %2049 = extractelement <8 x ptr> %2047, i32 0
  %2050 = extractelement <8 x i64> %2048, i32 0
  %2051 = sub i64 %2050, 0
  %2052 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2053 = select i1 %2052, i64 %2051, i64 0
  %private.contiguous.address385 = getelementptr i8, ptr %2049, i64 %2053
  %private.contiguous.preserve386 = load <8 x i64>, ptr %private.contiguous.address385, align 8
  %2054 = select <8 x i1> %101, <8 x i64> %.splat384, <8 x i64> %private.contiguous.preserve386
  store <8 x i64> %2054, ptr %private.contiguous.address385, align 8
  %2055 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2056 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2057 = add <8 x i64> %2056, splat (i64 832)
  %2058 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2055, 0
  %2059 = insertvalue { <8 x ptr>, <8 x i64> } %2058, <8 x i64> %2057, 1
  %.splatinsert387 = insertelement <8 x i64> poison, i64 %1705, i64 0
  %.splat388 = shufflevector <8 x i64> %.splatinsert387, <8 x i64> poison, <8 x i32> zeroinitializer
  %2060 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2061 = extractvalue { <8 x ptr>, <8 x i64> } %2059, 1
  %2062 = extractelement <8 x ptr> %2060, i32 0
  %2063 = extractelement <8 x i64> %2061, i32 0
  %2064 = sub i64 %2063, 0
  %2065 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2066 = select i1 %2065, i64 %2064, i64 0
  %private.contiguous.address389 = getelementptr i8, ptr %2062, i64 %2066
  %private.contiguous.preserve390 = load <8 x i64>, ptr %private.contiguous.address389, align 8
  %2067 = select <8 x i1> %101, <8 x i64> %.splat388, <8 x i64> %private.contiguous.preserve390
  store <8 x i64> %2067, ptr %private.contiguous.address389, align 8
  %2068 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2069 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2070 = add <8 x i64> %2069, splat (i64 896)
  %2071 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2068, 0
  %2072 = insertvalue { <8 x ptr>, <8 x i64> } %2071, <8 x i64> %2070, 1
  %.splatinsert391 = insertelement <8 x i64> poison, i64 %1706, i64 0
  %.splat392 = shufflevector <8 x i64> %.splatinsert391, <8 x i64> poison, <8 x i32> zeroinitializer
  %2073 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2074 = extractvalue { <8 x ptr>, <8 x i64> } %2072, 1
  %2075 = extractelement <8 x ptr> %2073, i32 0
  %2076 = extractelement <8 x i64> %2074, i32 0
  %2077 = sub i64 %2076, 0
  %2078 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2079 = select i1 %2078, i64 %2077, i64 0
  %private.contiguous.address393 = getelementptr i8, ptr %2075, i64 %2079
  %private.contiguous.preserve394 = load <8 x i64>, ptr %private.contiguous.address393, align 8
  %2080 = select <8 x i1> %101, <8 x i64> %.splat392, <8 x i64> %private.contiguous.preserve394
  store <8 x i64> %2080, ptr %private.contiguous.address393, align 8
  %2081 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2082 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2083 = add <8 x i64> %2082, splat (i64 960)
  %2084 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2081, 0
  %2085 = insertvalue { <8 x ptr>, <8 x i64> } %2084, <8 x i64> %2083, 1
  %.splatinsert395 = insertelement <8 x i64> poison, i64 %1707, i64 0
  %.splat396 = shufflevector <8 x i64> %.splatinsert395, <8 x i64> poison, <8 x i32> zeroinitializer
  %2086 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2087 = extractvalue { <8 x ptr>, <8 x i64> } %2085, 1
  %2088 = extractelement <8 x ptr> %2086, i32 0
  %2089 = extractelement <8 x i64> %2087, i32 0
  %2090 = sub i64 %2089, 0
  %2091 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2092 = select i1 %2091, i64 %2090, i64 0
  %private.contiguous.address397 = getelementptr i8, ptr %2088, i64 %2092
  %private.contiguous.preserve398 = load <8 x i64>, ptr %private.contiguous.address397, align 8
  %2093 = select <8 x i1> %101, <8 x i64> %.splat396, <8 x i64> %private.contiguous.preserve398
  store <8 x i64> %2093, ptr %private.contiguous.address397, align 8
  %.spill.load399 = load <8 x i64>, ptr %.spill69, align 64
  %2094 = add <8 x i64> zeroinitializer, %.spill.load399
  %.spill.load400 = load <8 x i64>, ptr %.spill69, align 64
  %2095 = add <8 x i64> splat (i64 1), %.spill.load400
  %.spill.load401 = load <8 x i64>, ptr %.spill69, align 64
  %2096 = add <8 x i64> splat (i64 2), %.spill.load401
  %.spill.load402 = load <8 x i64>, ptr %.spill69, align 64
  %2097 = add <8 x i64> splat (i64 3), %.spill.load402
  %.spill.load403 = load <8 x i64>, ptr %.spill69, align 64
  %2098 = add <8 x i64> splat (i64 4), %.spill.load403
  %.spill.load404 = load <8 x i64>, ptr %.spill69, align 64
  %2099 = add <8 x i64> splat (i64 5), %.spill.load404
  %.spill.load405 = load <8 x i64>, ptr %.spill69, align 64
  %2100 = add <8 x i64> splat (i64 6), %.spill.load405
  %.spill.load406 = load <8 x i64>, ptr %.spill69, align 64
  %2101 = add <8 x i64> splat (i64 7), %.spill.load406
  %2102 = add <8 x i64> %2094, splat (i64 129)
  %2103 = add <8 x i64> %2095, splat (i64 129)
  %2104 = add <8 x i64> %2096, splat (i64 129)
  %2105 = add <8 x i64> %2097, splat (i64 129)
  %2106 = add <8 x i64> %2098, splat (i64 129)
  %2107 = add <8 x i64> %2099, splat (i64 129)
  %2108 = add <8 x i64> %2100, splat (i64 129)
  %2109 = add <8 x i64> %2101, splat (i64 129)
  %2110 = sub <8 x i64> %2102, splat (i64 64)
  %2111 = sub <8 x i64> %2103, splat (i64 64)
  %2112 = sub <8 x i64> %2104, splat (i64 64)
  %2113 = sub <8 x i64> %2105, splat (i64 64)
  %2114 = sub <8 x i64> %2106, splat (i64 64)
  %2115 = sub <8 x i64> %2107, splat (i64 64)
  %2116 = sub <8 x i64> %2108, splat (i64 64)
  %2117 = sub <8 x i64> %2109, splat (i64 64)
  %2118 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill105, align 64
  %2119 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2120 = extractvalue { <8 x ptr>, <8 x i64> } %2118, 0
  %2121 = select <8 x i1> %101, <8 x ptr> %2119, <8 x ptr> %2120
  %2122 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %2123 = extractvalue { <8 x ptr>, <8 x i64> } %2118, 1
  %2124 = select <8 x i1> %101, <8 x i64> %2122, <8 x i64> %2123
  %2125 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2121, 0
  %2126 = insertvalue { <8 x ptr>, <8 x i64> } %2125, <8 x i64> %2124, 1
  store { <8 x ptr>, <8 x i64> } %2126, ptr %tile_snapshot.spill105, align 64
  %2127 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2128 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %2129 = add <8 x i64> %2128, zeroinitializer
  %2130 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2127, 0
  %2131 = insertvalue { <8 x ptr>, <8 x i64> } %2130, <8 x i64> %2129, 1
  %2132 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2133 = extractvalue { <8 x ptr>, <8 x i64> } %2131, 1
  %2134 = extractelement <8 x ptr> %2132, i32 0
  %2135 = extractelement <8 x i64> %2133, i32 0
  %2136 = sub i64 %2135, 0
  %2137 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2138 = select i1 %2137, i64 %2136, i64 0
  %private.contiguous.address407 = getelementptr i8, ptr %2134, i64 %2138
  %private.contiguous.preserve408 = load <8 x i64>, ptr %private.contiguous.address407, align 8
  %2139 = select <8 x i1> %101, <8 x i64> %2110, <8 x i64> %private.contiguous.preserve408
  store <8 x i64> %2139, ptr %private.contiguous.address407, align 8
  %2140 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2141 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %2142 = add <8 x i64> %2141, splat (i64 64)
  %2143 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2140, 0
  %2144 = insertvalue { <8 x ptr>, <8 x i64> } %2143, <8 x i64> %2142, 1
  %2145 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2146 = extractvalue { <8 x ptr>, <8 x i64> } %2144, 1
  %2147 = extractelement <8 x ptr> %2145, i32 0
  %2148 = extractelement <8 x i64> %2146, i32 0
  %2149 = sub i64 %2148, 0
  %2150 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2151 = select i1 %2150, i64 %2149, i64 0
  %private.contiguous.address409 = getelementptr i8, ptr %2147, i64 %2151
  %private.contiguous.preserve410 = load <8 x i64>, ptr %private.contiguous.address409, align 8
  %2152 = select <8 x i1> %101, <8 x i64> %2111, <8 x i64> %private.contiguous.preserve410
  store <8 x i64> %2152, ptr %private.contiguous.address409, align 8
  %2153 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2154 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %2155 = add <8 x i64> %2154, splat (i64 128)
  %2156 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2153, 0
  %2157 = insertvalue { <8 x ptr>, <8 x i64> } %2156, <8 x i64> %2155, 1
  %2158 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2159 = extractvalue { <8 x ptr>, <8 x i64> } %2157, 1
  %2160 = extractelement <8 x ptr> %2158, i32 0
  %2161 = extractelement <8 x i64> %2159, i32 0
  %2162 = sub i64 %2161, 0
  %2163 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2164 = select i1 %2163, i64 %2162, i64 0
  %private.contiguous.address411 = getelementptr i8, ptr %2160, i64 %2164
  %private.contiguous.preserve412 = load <8 x i64>, ptr %private.contiguous.address411, align 8
  %2165 = select <8 x i1> %101, <8 x i64> %2112, <8 x i64> %private.contiguous.preserve412
  store <8 x i64> %2165, ptr %private.contiguous.address411, align 8
  %2166 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2167 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %2168 = add <8 x i64> %2167, splat (i64 192)
  %2169 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2166, 0
  %2170 = insertvalue { <8 x ptr>, <8 x i64> } %2169, <8 x i64> %2168, 1
  %2171 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2172 = extractvalue { <8 x ptr>, <8 x i64> } %2170, 1
  %2173 = extractelement <8 x ptr> %2171, i32 0
  %2174 = extractelement <8 x i64> %2172, i32 0
  %2175 = sub i64 %2174, 0
  %2176 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2177 = select i1 %2176, i64 %2175, i64 0
  %private.contiguous.address413 = getelementptr i8, ptr %2173, i64 %2177
  %private.contiguous.preserve414 = load <8 x i64>, ptr %private.contiguous.address413, align 8
  %2178 = select <8 x i1> %101, <8 x i64> %2113, <8 x i64> %private.contiguous.preserve414
  store <8 x i64> %2178, ptr %private.contiguous.address413, align 8
  %2179 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2180 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %2181 = add <8 x i64> %2180, splat (i64 256)
  %2182 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2179, 0
  %2183 = insertvalue { <8 x ptr>, <8 x i64> } %2182, <8 x i64> %2181, 1
  %2184 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2185 = extractvalue { <8 x ptr>, <8 x i64> } %2183, 1
  %2186 = extractelement <8 x ptr> %2184, i32 0
  %2187 = extractelement <8 x i64> %2185, i32 0
  %2188 = sub i64 %2187, 0
  %2189 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2190 = select i1 %2189, i64 %2188, i64 0
  %private.contiguous.address415 = getelementptr i8, ptr %2186, i64 %2190
  %private.contiguous.preserve416 = load <8 x i64>, ptr %private.contiguous.address415, align 8
  %2191 = select <8 x i1> %101, <8 x i64> %2114, <8 x i64> %private.contiguous.preserve416
  store <8 x i64> %2191, ptr %private.contiguous.address415, align 8
  %2192 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2193 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %2194 = add <8 x i64> %2193, splat (i64 320)
  %2195 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2192, 0
  %2196 = insertvalue { <8 x ptr>, <8 x i64> } %2195, <8 x i64> %2194, 1
  %2197 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2198 = extractvalue { <8 x ptr>, <8 x i64> } %2196, 1
  %2199 = extractelement <8 x ptr> %2197, i32 0
  %2200 = extractelement <8 x i64> %2198, i32 0
  %2201 = sub i64 %2200, 0
  %2202 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2203 = select i1 %2202, i64 %2201, i64 0
  %private.contiguous.address417 = getelementptr i8, ptr %2199, i64 %2203
  %private.contiguous.preserve418 = load <8 x i64>, ptr %private.contiguous.address417, align 8
  %2204 = select <8 x i1> %101, <8 x i64> %2115, <8 x i64> %private.contiguous.preserve418
  store <8 x i64> %2204, ptr %private.contiguous.address417, align 8
  %2205 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2206 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %2207 = add <8 x i64> %2206, splat (i64 384)
  %2208 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2205, 0
  %2209 = insertvalue { <8 x ptr>, <8 x i64> } %2208, <8 x i64> %2207, 1
  %2210 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2211 = extractvalue { <8 x ptr>, <8 x i64> } %2209, 1
  %2212 = extractelement <8 x ptr> %2210, i32 0
  %2213 = extractelement <8 x i64> %2211, i32 0
  %2214 = sub i64 %2213, 0
  %2215 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2216 = select i1 %2215, i64 %2214, i64 0
  %private.contiguous.address419 = getelementptr i8, ptr %2212, i64 %2216
  %private.contiguous.preserve420 = load <8 x i64>, ptr %private.contiguous.address419, align 8
  %2217 = select <8 x i1> %101, <8 x i64> %2116, <8 x i64> %private.contiguous.preserve420
  store <8 x i64> %2217, ptr %private.contiguous.address419, align 8
  %2218 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2219 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %2220 = add <8 x i64> %2219, splat (i64 448)
  %2221 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2218, 0
  %2222 = insertvalue { <8 x ptr>, <8 x i64> } %2221, <8 x i64> %2220, 1
  %2223 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2224 = extractvalue { <8 x ptr>, <8 x i64> } %2222, 1
  %2225 = extractelement <8 x ptr> %2223, i32 0
  %2226 = extractelement <8 x i64> %2224, i32 0
  %2227 = sub i64 %2226, 0
  %2228 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2229 = select i1 %2228, i64 %2227, i64 0
  %private.contiguous.address421 = getelementptr i8, ptr %2225, i64 %2229
  %private.contiguous.preserve422 = load <8 x i64>, ptr %private.contiguous.address421, align 8
  %2230 = select <8 x i1> %101, <8 x i64> %2117, <8 x i64> %private.contiguous.preserve422
  store <8 x i64> %2230, ptr %private.contiguous.address421, align 8
  %2231 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill106, align 64
  %2232 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %2233 = extractvalue { <8 x ptr>, <8 x i64> } %2231, 0
  %2234 = select <8 x i1> %101, <8 x ptr> %2232, <8 x ptr> %2233
  %2235 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %2236 = extractvalue { <8 x ptr>, <8 x i64> } %2231, 1
  %2237 = select <8 x i1> %101, <8 x i64> %2235, <8 x i64> %2236
  %2238 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2234, 0
  %2239 = insertvalue { <8 x ptr>, <8 x i64> } %2238, <8 x i64> %2237, 1
  store { <8 x ptr>, <8 x i64> } %2239, ptr %tile_snapshot.spill106, align 64
  store i64 0, ptr %.slot107, align 4
  br label %direct.schedule.22

direct.true424:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false425:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24

direct.true446:                                   ; preds = %direct.schedule.25
  br label %direct.schedule.26

direct.false447:                                  ; preds = %direct.schedule.25
  br label %direct.schedule.27

direct.true464:                                   ; preds = %direct.schedule.28
  br label %direct.schedule.29

direct.false465:                                  ; preds = %direct.schedule.28
  br label %direct.schedule.30

direct.true475:                                   ; preds = %direct.schedule.31
  br label %direct.schedule.32

direct.false476:                                  ; preds = %direct.schedule.31
  br label %direct.schedule.33

direct.true486:                                   ; preds = %direct.schedule.34
  br label %direct.schedule.35

direct.false487:                                  ; preds = %direct.schedule.34
  br label %direct.schedule.36

direct.true497:                                   ; preds = %direct.schedule.37
  br label %direct.schedule.38

direct.false498:                                  ; preds = %direct.schedule.37
  br label %direct.schedule.39

direct.true508:                                   ; preds = %direct.schedule.40
  br label %direct.schedule.41

direct.false509:                                  ; preds = %direct.schedule.40
  br label %direct.schedule.42

direct.true519:                                   ; preds = %direct.schedule.43
  br label %direct.schedule.44

direct.false520:                                  ; preds = %direct.schedule.43
  br label %direct.schedule.45

direct.true530:                                   ; preds = %direct.schedule.46
  br label %direct.schedule.47

direct.false531:                                  ; preds = %direct.schedule.46
  br label %direct.schedule.48

direct.true541:                                   ; preds = %direct.schedule.49
  br label %direct.schedule.50

direct.false542:                                  ; preds = %direct.schedule.49
  br label %direct.schedule.51

direct.true615:                                   ; preds = %direct.schedule.52
  br label %direct.schedule.53

direct.false616:                                  ; preds = %direct.schedule.52
  br label %direct.schedule.54

direct.true655:                                   ; preds = %direct.schedule.55
  br label %direct.schedule.56

direct.false656:                                  ; preds = %direct.schedule.55
  br label %direct.schedule.57

direct.true664:                                   ; preds = %direct.schedule.58
  br label %direct.schedule.59

direct.false665:                                  ; preds = %direct.schedule.58
  br label %direct.schedule.60

direct.true673:                                   ; preds = %direct.schedule.61
  br label %direct.schedule.62

direct.false674:                                  ; preds = %direct.schedule.61
  br label %direct.schedule.63

direct.true682:                                   ; preds = %direct.schedule.64
  br label %direct.schedule.65

direct.false683:                                  ; preds = %direct.schedule.64
  br label %direct.schedule.66

direct.true691:                                   ; preds = %direct.schedule.67
  br label %direct.schedule.68

direct.false692:                                  ; preds = %direct.schedule.67
  br label %direct.schedule.69

direct.true700:                                   ; preds = %direct.schedule.70
  br label %direct.schedule.71

direct.false701:                                  ; preds = %direct.schedule.70
  br label %direct.schedule.72

direct.true709:                                   ; preds = %direct.schedule.73
  br label %direct.schedule.74

direct.false710:                                  ; preds = %direct.schedule.73
  br label %direct.schedule.75

direct.true718:                                   ; preds = %direct.schedule.76
  br label %direct.schedule.77

direct.false719:                                  ; preds = %direct.schedule.76
  br label %direct.schedule.78

direct.true743:                                   ; preds = %direct.schedule.79
  br label %direct.schedule.80

direct.false744:                                  ; preds = %direct.schedule.79
  br label %direct.schedule.81

mma.active765:                                    ; preds = %direct.schedule.81
  %2240 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 0
  %2241 = extractelement <8 x ptr> %2240, i64 0
  %2242 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 1
  %2243 = extractelement <8 x i64> %2242, i64 0
  %2244 = getelementptr i8, ptr %2241, i64 %2243
  %2245 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 0
  %2246 = extractelement <8 x ptr> %2245, i64 0
  %2247 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 1
  %2248 = extractelement <8 x i64> %2247, i64 0
  %2249 = getelementptr i8, ptr %2246, i64 %2248
  %2250 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 0
  %2251 = extractelement <8 x ptr> %2250, i64 0
  %2252 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 1
  %2253 = extractelement <8 x i64> %2252, i64 0
  %2254 = getelementptr i8, ptr %2251, i64 %2253
  %2255 = extractvalue { <8 x ptr>, <8 x i64> } %50, 0
  %2256 = extractelement <8 x ptr> %2255, i64 0
  %2257 = extractvalue { <8 x ptr>, <8 x i64> } %50, 1
  %2258 = extractelement <8 x i64> %2257, i64 0
  %2259 = getelementptr i8, ptr %2256, i64 %2258
  call void @llm_attention.strided_mma.1(ptr %2244, ptr %2249, ptr %2254, ptr %2259)
  br label %mma.continue766

mma.continue766:                                  ; preds = %mma.active765, %direct.schedule.81
  %2260 = extractelement <8 x i1> %101, i64 1
  br i1 %2260, label %mma.active767, label %mma.continue768

mma.active767:                                    ; preds = %mma.continue766
  %2261 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 0
  %2262 = extractelement <8 x ptr> %2261, i64 1
  %2263 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 1
  %2264 = extractelement <8 x i64> %2263, i64 1
  %2265 = getelementptr i8, ptr %2262, i64 %2264
  %2266 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 0
  %2267 = extractelement <8 x ptr> %2266, i64 1
  %2268 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 1
  %2269 = extractelement <8 x i64> %2268, i64 1
  %2270 = getelementptr i8, ptr %2267, i64 %2269
  %2271 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 0
  %2272 = extractelement <8 x ptr> %2271, i64 1
  %2273 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 1
  %2274 = extractelement <8 x i64> %2273, i64 1
  %2275 = getelementptr i8, ptr %2272, i64 %2274
  %2276 = extractvalue { <8 x ptr>, <8 x i64> } %50, 0
  %2277 = extractelement <8 x ptr> %2276, i64 1
  %2278 = extractvalue { <8 x ptr>, <8 x i64> } %50, 1
  %2279 = extractelement <8 x i64> %2278, i64 1
  %2280 = getelementptr i8, ptr %2277, i64 %2279
  call void @llm_attention.strided_mma.1(ptr %2265, ptr %2270, ptr %2275, ptr %2280)
  br label %mma.continue768

mma.continue768:                                  ; preds = %mma.active767, %mma.continue766
  %2281 = extractelement <8 x i1> %101, i64 2
  br i1 %2281, label %mma.active769, label %mma.continue770

mma.active769:                                    ; preds = %mma.continue768
  %2282 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 0
  %2283 = extractelement <8 x ptr> %2282, i64 2
  %2284 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 1
  %2285 = extractelement <8 x i64> %2284, i64 2
  %2286 = getelementptr i8, ptr %2283, i64 %2285
  %2287 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 0
  %2288 = extractelement <8 x ptr> %2287, i64 2
  %2289 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 1
  %2290 = extractelement <8 x i64> %2289, i64 2
  %2291 = getelementptr i8, ptr %2288, i64 %2290
  %2292 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 0
  %2293 = extractelement <8 x ptr> %2292, i64 2
  %2294 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 1
  %2295 = extractelement <8 x i64> %2294, i64 2
  %2296 = getelementptr i8, ptr %2293, i64 %2295
  %2297 = extractvalue { <8 x ptr>, <8 x i64> } %50, 0
  %2298 = extractelement <8 x ptr> %2297, i64 2
  %2299 = extractvalue { <8 x ptr>, <8 x i64> } %50, 1
  %2300 = extractelement <8 x i64> %2299, i64 2
  %2301 = getelementptr i8, ptr %2298, i64 %2300
  call void @llm_attention.strided_mma.1(ptr %2286, ptr %2291, ptr %2296, ptr %2301)
  br label %mma.continue770

mma.continue770:                                  ; preds = %mma.active769, %mma.continue768
  %2302 = extractelement <8 x i1> %101, i64 3
  br i1 %2302, label %mma.active771, label %mma.continue772

mma.active771:                                    ; preds = %mma.continue770
  %2303 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 0
  %2304 = extractelement <8 x ptr> %2303, i64 3
  %2305 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 1
  %2306 = extractelement <8 x i64> %2305, i64 3
  %2307 = getelementptr i8, ptr %2304, i64 %2306
  %2308 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 0
  %2309 = extractelement <8 x ptr> %2308, i64 3
  %2310 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 1
  %2311 = extractelement <8 x i64> %2310, i64 3
  %2312 = getelementptr i8, ptr %2309, i64 %2311
  %2313 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 0
  %2314 = extractelement <8 x ptr> %2313, i64 3
  %2315 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 1
  %2316 = extractelement <8 x i64> %2315, i64 3
  %2317 = getelementptr i8, ptr %2314, i64 %2316
  %2318 = extractvalue { <8 x ptr>, <8 x i64> } %50, 0
  %2319 = extractelement <8 x ptr> %2318, i64 3
  %2320 = extractvalue { <8 x ptr>, <8 x i64> } %50, 1
  %2321 = extractelement <8 x i64> %2320, i64 3
  %2322 = getelementptr i8, ptr %2319, i64 %2321
  call void @llm_attention.strided_mma.1(ptr %2307, ptr %2312, ptr %2317, ptr %2322)
  br label %mma.continue772

mma.continue772:                                  ; preds = %mma.active771, %mma.continue770
  %2323 = extractelement <8 x i1> %101, i64 4
  br i1 %2323, label %mma.active773, label %mma.continue774

mma.active773:                                    ; preds = %mma.continue772
  %2324 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 0
  %2325 = extractelement <8 x ptr> %2324, i64 4
  %2326 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 1
  %2327 = extractelement <8 x i64> %2326, i64 4
  %2328 = getelementptr i8, ptr %2325, i64 %2327
  %2329 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 0
  %2330 = extractelement <8 x ptr> %2329, i64 4
  %2331 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 1
  %2332 = extractelement <8 x i64> %2331, i64 4
  %2333 = getelementptr i8, ptr %2330, i64 %2332
  %2334 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 0
  %2335 = extractelement <8 x ptr> %2334, i64 4
  %2336 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 1
  %2337 = extractelement <8 x i64> %2336, i64 4
  %2338 = getelementptr i8, ptr %2335, i64 %2337
  %2339 = extractvalue { <8 x ptr>, <8 x i64> } %50, 0
  %2340 = extractelement <8 x ptr> %2339, i64 4
  %2341 = extractvalue { <8 x ptr>, <8 x i64> } %50, 1
  %2342 = extractelement <8 x i64> %2341, i64 4
  %2343 = getelementptr i8, ptr %2340, i64 %2342
  call void @llm_attention.strided_mma.1(ptr %2328, ptr %2333, ptr %2338, ptr %2343)
  br label %mma.continue774

mma.continue774:                                  ; preds = %mma.active773, %mma.continue772
  %2344 = extractelement <8 x i1> %101, i64 5
  br i1 %2344, label %mma.active775, label %mma.continue776

mma.active775:                                    ; preds = %mma.continue774
  %2345 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 0
  %2346 = extractelement <8 x ptr> %2345, i64 5
  %2347 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 1
  %2348 = extractelement <8 x i64> %2347, i64 5
  %2349 = getelementptr i8, ptr %2346, i64 %2348
  %2350 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 0
  %2351 = extractelement <8 x ptr> %2350, i64 5
  %2352 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 1
  %2353 = extractelement <8 x i64> %2352, i64 5
  %2354 = getelementptr i8, ptr %2351, i64 %2353
  %2355 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 0
  %2356 = extractelement <8 x ptr> %2355, i64 5
  %2357 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 1
  %2358 = extractelement <8 x i64> %2357, i64 5
  %2359 = getelementptr i8, ptr %2356, i64 %2358
  %2360 = extractvalue { <8 x ptr>, <8 x i64> } %50, 0
  %2361 = extractelement <8 x ptr> %2360, i64 5
  %2362 = extractvalue { <8 x ptr>, <8 x i64> } %50, 1
  %2363 = extractelement <8 x i64> %2362, i64 5
  %2364 = getelementptr i8, ptr %2361, i64 %2363
  call void @llm_attention.strided_mma.1(ptr %2349, ptr %2354, ptr %2359, ptr %2364)
  br label %mma.continue776

mma.continue776:                                  ; preds = %mma.active775, %mma.continue774
  %2365 = extractelement <8 x i1> %101, i64 6
  br i1 %2365, label %mma.active777, label %mma.continue778

mma.active777:                                    ; preds = %mma.continue776
  %2366 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 0
  %2367 = extractelement <8 x ptr> %2366, i64 6
  %2368 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 1
  %2369 = extractelement <8 x i64> %2368, i64 6
  %2370 = getelementptr i8, ptr %2367, i64 %2369
  %2371 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 0
  %2372 = extractelement <8 x ptr> %2371, i64 6
  %2373 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 1
  %2374 = extractelement <8 x i64> %2373, i64 6
  %2375 = getelementptr i8, ptr %2372, i64 %2374
  %2376 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 0
  %2377 = extractelement <8 x ptr> %2376, i64 6
  %2378 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 1
  %2379 = extractelement <8 x i64> %2378, i64 6
  %2380 = getelementptr i8, ptr %2377, i64 %2379
  %2381 = extractvalue { <8 x ptr>, <8 x i64> } %50, 0
  %2382 = extractelement <8 x ptr> %2381, i64 6
  %2383 = extractvalue { <8 x ptr>, <8 x i64> } %50, 1
  %2384 = extractelement <8 x i64> %2383, i64 6
  %2385 = getelementptr i8, ptr %2382, i64 %2384
  call void @llm_attention.strided_mma.1(ptr %2370, ptr %2375, ptr %2380, ptr %2385)
  br label %mma.continue778

mma.continue778:                                  ; preds = %mma.active777, %mma.continue776
  %2386 = extractelement <8 x i1> %101, i64 7
  br i1 %2386, label %mma.active779, label %mma.continue780

mma.active779:                                    ; preds = %mma.continue778
  %2387 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 0
  %2388 = extractelement <8 x ptr> %2387, i64 7
  %2389 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 1
  %2390 = extractelement <8 x i64> %2389, i64 7
  %2391 = getelementptr i8, ptr %2388, i64 %2390
  %2392 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 0
  %2393 = extractelement <8 x ptr> %2392, i64 7
  %2394 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 1
  %2395 = extractelement <8 x i64> %2394, i64 7
  %2396 = getelementptr i8, ptr %2393, i64 %2395
  %2397 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 0
  %2398 = extractelement <8 x ptr> %2397, i64 7
  %2399 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 1
  %2400 = extractelement <8 x i64> %2399, i64 7
  %2401 = getelementptr i8, ptr %2398, i64 %2400
  %2402 = extractvalue { <8 x ptr>, <8 x i64> } %50, 0
  %2403 = extractelement <8 x ptr> %2402, i64 7
  %2404 = extractvalue { <8 x ptr>, <8 x i64> } %50, 1
  %2405 = extractelement <8 x i64> %2404, i64 7
  %2406 = getelementptr i8, ptr %2403, i64 %2405
  call void @llm_attention.strided_mma.1(ptr %2391, ptr %2396, ptr %2401, ptr %2406)
  br label %mma.continue780

mma.continue780:                                  ; preds = %mma.active779, %mma.continue778
  store i64 0, ptr %.slot181, align 4
  br label %direct.schedule.82

direct.true782:                                   ; preds = %direct.schedule.82
  br label %direct.schedule.83

direct.false783:                                  ; preds = %direct.schedule.82
  br label %direct.schedule.84

direct.true796:                                   ; preds = %direct.schedule.85
  br label %direct.schedule.86

direct.false797:                                  ; preds = %direct.schedule.85
  br label %direct.schedule.87

direct.true853:                                   ; preds = %direct.schedule.89
  br label %direct.schedule.90

direct.false854:                                  ; preds = %direct.schedule.89
  br label %direct.schedule.91
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #2

; Function Attrs: nounwind willreturn
define private void @llm_attention.strided_mma(ptr %0, ptr %1, ptr %2, ptr %3) #3 {
entry:
  br label %mma.fold

mma.fold:                                         ; preds = %mma.fold.done3, %entry
  %mma.k = phi i64 [ 0, %entry ], [ %45, %mma.fold.done3 ]
  %mma.acc = phi i64 [ 0, %entry ], [ %mma.acc, %mma.fold.done3 ]
  %4 = icmp ult i64 %mma.k, 128
  br i1 %4, label %mma.update, label %mma.fold.done

mma.update:                                       ; preds = %mma.fold
  %5 = urem i64 %mma.k, 16
  %6 = udiv i64 %mma.k, 16
  %7 = urem i64 %6, 8
  %8 = mul i64 %7, 32
  %9 = add i64 0, %8
  %10 = udiv i64 %6, 8
  %11 = urem i64 %mma.k, 16
  %12 = mul i64 %11, 32
  %13 = add i64 0, %12
  %14 = udiv i64 %mma.k, 16
  %15 = urem i64 %14, 8
  %16 = udiv i64 %14, 8
  %17 = getelementptr float, ptr %2, i64 %mma.k
  %18 = load float, ptr %17, align 4
  %19 = getelementptr float, ptr %0, i64 %9
  %20 = load <4 x float>, ptr %19, align 4
  %21 = getelementptr float, ptr %1, i64 %13
  %22 = load <4 x float>, ptr %21, align 4
  %23 = fmul <4 x float> %20, %22
  br label %mma.fold1

mma.fold.done:                                    ; preds = %mma.fold
  ret void

mma.fold1:                                        ; preds = %mma.update2, %mma.update
  %mma.k4 = phi i64 [ 0, %mma.update ], [ %35, %mma.update2 ]
  %mma.acc5 = phi <4 x float> [ %23, %mma.update ], [ %34, %mma.update2 ]
  %24 = icmp ult i64 %mma.k4, 7
  br i1 %24, label %mma.update2, label %mma.fold.done3

mma.update2:                                      ; preds = %mma.fold1
  %25 = add i64 %mma.k4, 1
  %26 = mul i64 %25, 4
  %27 = add i64 %9, %26
  %28 = getelementptr float, ptr %0, i64 %27
  %29 = load <4 x float>, ptr %28, align 4
  %30 = add i64 %13, %26
  %31 = getelementptr float, ptr %1, i64 %30
  %32 = load <4 x float>, ptr %31, align 4
  %33 = fmul <4 x float> %29, %32
  %34 = fadd <4 x float> %mma.acc5, %33
  %35 = add i64 %mma.k4, 1
  br label %mma.fold1

mma.fold.done3:                                   ; preds = %mma.fold1
  %36 = extractelement <4 x float> %mma.acc5, i64 0
  %37 = extractelement <4 x float> %mma.acc5, i64 1
  %38 = extractelement <4 x float> %mma.acc5, i64 2
  %39 = extractelement <4 x float> %mma.acc5, i64 3
  %40 = fadd float %36, %37
  %41 = fadd float %38, %39
  %42 = fadd float %40, %41
  %43 = fadd float %18, %42
  %44 = getelementptr float, ptr %3, i64 %mma.k
  store float %43, ptr %44, align 4
  %45 = add i64 %mma.k, 1
  br label %mma.fold
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8i8.v8p0(<8 x i8>, <8 x ptr>, <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr>, <8 x i1>, <8 x i8>) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #4

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #5 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nounwind willreturn
define private void @llm_attention.strided_mma.1(ptr %0, ptr %1, ptr %2, ptr %3) #3 {
entry:
  br label %mma.fold

mma.fold:                                         ; preds = %mma.fold.done3, %entry
  %mma.k = phi i64 [ 0, %entry ], [ %23, %mma.fold.done3 ]
  %mma.acc = phi i64 [ 0, %entry ], [ %mma.acc, %mma.fold.done3 ]
  %4 = icmp ult i64 %mma.k, 8
  br i1 %4, label %mma.update, label %mma.fold.done

mma.update:                                       ; preds = %mma.fold
  %5 = mul i64 %mma.k, 48
  br label %mma.fold1

mma.fold.done:                                    ; preds = %mma.fold
  ret void

mma.fold1:                                        ; preds = %mma.fold.done8, %mma.update
  %mma.k4 = phi i64 [ 0, %mma.update ], [ %37, %mma.fold.done8 ]
  %mma.acc5 = phi i64 [ 0, %mma.update ], [ %mma.acc5, %mma.fold.done8 ]
  %6 = icmp ult i64 %mma.k4, 12
  br i1 %6, label %mma.update2, label %mma.fold.done3

mma.update2:                                      ; preds = %mma.fold1
  %7 = mul i64 %mma.k4, 4
  %8 = add i64 %5, %7
  %9 = urem i64 %8, 48
  %10 = udiv i64 %8, 48
  %11 = urem i64 %10, 8
  %12 = mul i64 %11, 16
  %13 = add i64 0, %12
  %14 = udiv i64 %10, 8
  %15 = urem i64 %8, 48
  %16 = mul i64 %15, 1
  %17 = add i64 0, %16
  %18 = udiv i64 %8, 48
  %19 = urem i64 %18, 8
  %20 = udiv i64 %18, 8
  %21 = getelementptr float, ptr %2, i64 %8
  %22 = load <4 x float>, ptr %21, align 4
  br label %mma.fold6

mma.fold.done3:                                   ; preds = %mma.fold1
  %23 = add i64 %mma.k, 1
  br label %mma.fold

mma.fold6:                                        ; preds = %mma.update7, %mma.update2
  %mma.k9 = phi i64 [ 0, %mma.update2 ], [ %35, %mma.update7 ]
  %mma.acc10 = phi <4 x float> [ %22, %mma.update2 ], [ %34, %mma.update7 ]
  %24 = icmp ult i64 %mma.k9, 16
  br i1 %24, label %mma.update7, label %mma.fold.done8

mma.update7:                                      ; preds = %mma.fold6
  %25 = mul i64 %mma.k9, 1
  %26 = add i64 %13, %25
  %27 = getelementptr float, ptr %0, i64 %26
  %28 = load float, ptr %27, align 4
  %.splatinsert = insertelement <4 x float> poison, float %28, i64 0
  %.splat = shufflevector <4 x float> %.splatinsert, <4 x float> poison, <4 x i32> zeroinitializer
  %29 = mul i64 %mma.k9, 48
  %30 = add i64 %17, %29
  %31 = getelementptr float, ptr %1, i64 %30
  %32 = load <4 x float>, ptr %31, align 4
  %33 = fmul <4 x float> %.splat, %32
  %34 = fadd <4 x float> %mma.acc10, %33
  %35 = add i64 %mma.k9, 1
  br label %mma.fold6

mma.fold.done8:                                   ; preds = %mma.fold6
  %36 = getelementptr float, ptr %3, i64 %8
  store <4 x float> %mma.acc10, ptr %36, align 4
  %37 = add i64 %mma.k4, 1
  br label %mma.fold1
}

define internal void @llm_attention.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 1024, i64 2048, i64 3072, i64 4096, i64 5120, i64 6144, i64 7168>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 8192
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 20480
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 32768
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 2048, i64 4096, i64 6144, i64 8192, i64 10240, i64 12288, i64 14336>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 49152
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 3072, i64 6144, i64 9216, i64 12288, i64 15360, i64 18432, i64 21504>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 73728
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 512, i64 1024, i64 1536, i64 2048, i64 2560, i64 3072, i64 3584>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 77824
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 512, i64 1024, i64 1536, i64 2048, i64 2560, i64 3072, i64 3584>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 81920
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 16, i64 32, i64 48, i64 64, i64 80, i64 96, i64 112>, 1
  %24 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace29 = load ptr, ptr %24, align 8
  %tile_snapshot.private30 = getelementptr inbounds i8, ptr %private.workspace29, i64 82048
  %.splatinsert31 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private30, i64 0
  %.splat32 = shufflevector <8 x ptr> %.splatinsert31, <8 x ptr> poison, <8 x i32> zeroinitializer
  %25 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat32, 0
  %26 = insertvalue { <8 x ptr>, <8 x i64> } %25, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %27 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace33 = load ptr, ptr %27, align 8
  %tile_snapshot.private34 = getelementptr inbounds i8, ptr %private.workspace33, i64 83072
  %.splatinsert35 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private34, i64 0
  %.splat36 = shufflevector <8 x ptr> %.splatinsert35, <8 x ptr> poison, <8 x i32> zeroinitializer
  %28 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat36, 0
  %29 = insertvalue { <8 x ptr>, <8 x i64> } %28, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %30 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace37 = load ptr, ptr %30, align 8
  %tile_snapshot.private38 = getelementptr inbounds i8, ptr %private.workspace37, i64 83584
  %.splatinsert39 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private38, i64 0
  %.splat40 = shufflevector <8 x ptr> %.splatinsert39, <8 x ptr> poison, <8 x i32> zeroinitializer
  %31 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat40, 0
  %32 = insertvalue { <8 x ptr>, <8 x i64> } %31, <8 x i64> <i64 0, i64 128, i64 256, i64 384, i64 512, i64 640, i64 768, i64 896>, 1
  %33 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace41 = load ptr, ptr %33, align 8
  %tile_snapshot.private42 = getelementptr inbounds i8, ptr %private.workspace41, i64 84608
  %.splatinsert43 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private42, i64 0
  %.splat44 = shufflevector <8 x ptr> %.splatinsert43, <8 x ptr> poison, <8 x i32> zeroinitializer
  %34 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat44, 0
  %35 = insertvalue { <8 x ptr>, <8 x i64> } %34, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %36 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace45 = load ptr, ptr %36, align 8
  %tile_snapshot.private46 = getelementptr inbounds i8, ptr %private.workspace45, i64 88704
  %.splatinsert47 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private46, i64 0
  %.splat48 = shufflevector <8 x ptr> %.splatinsert47, <8 x ptr> poison, <8 x i32> zeroinitializer
  %37 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat48, 0
  %38 = insertvalue { <8 x ptr>, <8 x i64> } %37, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %39 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace49 = load ptr, ptr %39, align 8
  %tile_snapshot.private50 = getelementptr inbounds i8, ptr %private.workspace49, i64 88960
  %.splatinsert51 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private50, i64 0
  %.splat52 = shufflevector <8 x ptr> %.splatinsert51, <8 x ptr> poison, <8 x i32> zeroinitializer
  %40 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat52, 0
  %41 = insertvalue { <8 x ptr>, <8 x i64> } %40, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %42 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace53 = load ptr, ptr %42, align 8
  %tile_snapshot.private54 = getelementptr inbounds i8, ptr %private.workspace53, i64 89216
  %.splatinsert55 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private54, i64 0
  %.splat56 = shufflevector <8 x ptr> %.splatinsert55, <8 x ptr> poison, <8 x i32> zeroinitializer
  %43 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat56, 0
  %44 = insertvalue { <8 x ptr>, <8 x i64> } %43, <8 x i64> <i64 0, i64 512, i64 1024, i64 1536, i64 2048, i64 2560, i64 3072, i64 3584>, 1
  %45 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace57 = load ptr, ptr %45, align 8
  %tile_snapshot.private58 = getelementptr inbounds i8, ptr %private.workspace57, i64 93312
  %.splatinsert59 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private58, i64 0
  %.splat60 = shufflevector <8 x ptr> %.splatinsert59, <8 x ptr> poison, <8 x i32> zeroinitializer
  %46 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat60, 0
  %47 = insertvalue { <8 x ptr>, <8 x i64> } %46, <8 x i64> <i64 0, i64 1536, i64 3072, i64 4608, i64 6144, i64 7680, i64 9216, i64 10752>, 1
  %48 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace61 = load ptr, ptr %48, align 8
  %tile_snapshot.private62 = getelementptr inbounds i8, ptr %private.workspace61, i64 105600
  %.splatinsert63 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private62, i64 0
  %.splat64 = shufflevector <8 x ptr> %.splatinsert63, <8 x ptr> poison, <8 x i32> zeroinitializer
  %49 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat64, 0
  %50 = insertvalue { <8 x ptr>, <8 x i64> } %49, <8 x i64> <i64 0, i64 1536, i64 3072, i64 4608, i64 6144, i64 7680, i64 9216, i64 10752>, 1
  %51 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace65 = load ptr, ptr %51, align 8
  %tile_snapshot.private66 = getelementptr inbounds i8, ptr %private.workspace65, i64 117888
  %.splatinsert67 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private66, i64 0
  %.splat68 = shufflevector <8 x ptr> %.splatinsert67, <8 x ptr> poison, <8 x i32> zeroinitializer
  %52 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat68, 0
  %53 = insertvalue { <8 x ptr>, <8 x i64> } %52, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill69 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill69, align 64
  %.spill70 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill70, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill71 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill71, align 64
  %tile_snapshot.spill72 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill72, align 64
  %.slot73 = alloca i64, align 8
  store i64 0, ptr %.slot73, align 4
  %.slot74 = alloca i64, align 8
  store i64 0, ptr %.slot74, align 4
  %.slot75 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot75, align 32
  %.slot76 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot76, align 32
  %.slot77 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot77, align 32
  %.slot78 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot78, align 32
  %.slot79 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot79, align 32
  %.slot80 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot80, align 32
  %.slot81 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot81, align 32
  %.slot82 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot82, align 32
  %.slot83 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot83, align 32
  %.slot84 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot84, align 32
  %.slot85 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot85, align 32
  %.slot86 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot86, align 32
  %.slot87 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot87, align 32
  %.slot88 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot88, align 32
  %.slot89 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot89, align 32
  %.slot90 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot90, align 32
  %.spill91 = alloca i64, align 8
  store i64 0, ptr %.spill91, align 4
  %tile_snapshot.spill92 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill92, align 64
  %.slot93 = alloca i64, align 8
  store i64 0, ptr %.slot93, align 4
  %.spill94 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill94, align 64
  %.slot95 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot95, align 32
  %tile_snapshot.spill96 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill96, align 64
  %.slot97 = alloca i64, align 8
  store i64 0, ptr %.slot97, align 4
  %.spill98 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill98, align 64
  %.slot99 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot99, align 32
  %tile_snapshot.spill100 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill100, align 64
  %.slot101 = alloca i64, align 8
  store i64 0, ptr %.slot101, align 4
  %tile_snapshot.spill102 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill102, align 64
  %tile_snapshot.spill103 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill103, align 64
  %tile_snapshot.spill104 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill104, align 64
  %tile_snapshot.spill105 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill105, align 64
  %tile_snapshot.spill106 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill106, align 64
  %.slot107 = alloca i64, align 8
  store i64 0, ptr %.slot107, align 4
  %tile_snapshot.spill108 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill108, align 64
  %.slot109 = alloca i64, align 8
  store i64 0, ptr %.slot109, align 4
  %.slot110 = alloca i64, align 8
  store i64 0, ptr %.slot110, align 4
  %.slot111 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot111, align 32
  %.slot112 = alloca i64, align 8
  store i64 0, ptr %.slot112, align 4
  %.slot113 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot113, align 32
  %.slot114 = alloca i64, align 8
  store i64 0, ptr %.slot114, align 4
  %.slot115 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot115, align 32
  %.slot116 = alloca i64, align 8
  store i64 0, ptr %.slot116, align 4
  %.slot117 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot117, align 32
  %.slot118 = alloca i64, align 8
  store i64 0, ptr %.slot118, align 4
  %.slot119 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot119, align 32
  %.slot120 = alloca i64, align 8
  store i64 0, ptr %.slot120, align 4
  %.slot121 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot121, align 32
  %.slot122 = alloca i64, align 8
  store i64 0, ptr %.slot122, align 4
  %.slot123 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot123, align 32
  %.slot124 = alloca i64, align 8
  store i64 0, ptr %.slot124, align 4
  %.slot125 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot125, align 32
  %.spill126 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill126, align 32
  %.spill127 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill127, align 32
  %.spill128 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill128, align 32
  %.spill129 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill129, align 32
  %.spill130 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill130, align 32
  %.spill131 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill131, align 32
  %.spill132 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill132, align 32
  %.spill133 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill133, align 32
  %tile_snapshot.spill134 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill134, align 64
  %.spill135 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill135, align 32
  %.spill136 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill136, align 32
  %.spill137 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill137, align 32
  %.spill138 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill138, align 32
  %.spill139 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill139, align 32
  %.spill140 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill140, align 32
  %.spill141 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill141, align 32
  %.spill142 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill142, align 32
  %tile_snapshot.spill143 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill143, align 64
  %tile_snapshot.spill144 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill144, align 64
  %.slot145 = alloca i64, align 8
  store i64 0, ptr %.slot145, align 4
  %.spill146 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill146, align 32
  %.spill147 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill147, align 32
  %.spill148 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill148, align 32
  %.spill149 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill149, align 32
  %.spill150 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill150, align 32
  %.spill151 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill151, align 32
  %.spill152 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill152, align 32
  %.spill153 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill153, align 32
  %.slot154 = alloca i64, align 8
  store i64 0, ptr %.slot154, align 4
  %.slot155 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot155, align 32
  %.slot156 = alloca i64, align 8
  store i64 0, ptr %.slot156, align 4
  %.slot157 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot157, align 32
  %.slot158 = alloca i64, align 8
  store i64 0, ptr %.slot158, align 4
  %.slot159 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot159, align 32
  %.slot160 = alloca i64, align 8
  store i64 0, ptr %.slot160, align 4
  %.slot161 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot161, align 32
  %.slot162 = alloca i64, align 8
  store i64 0, ptr %.slot162, align 4
  %.slot163 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot163, align 32
  %.slot164 = alloca i64, align 8
  store i64 0, ptr %.slot164, align 4
  %.slot165 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot165, align 32
  %.slot166 = alloca i64, align 8
  store i64 0, ptr %.slot166, align 4
  %.slot167 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot167, align 32
  %.slot168 = alloca i64, align 8
  store i64 0, ptr %.slot168, align 4
  %.slot169 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot169, align 32
  %.spill170 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill170, align 32
  %.spill171 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill171, align 32
  %.spill172 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill172, align 32
  %.spill173 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill173, align 32
  %.spill174 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill174, align 32
  %.spill175 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill175, align 32
  %.spill176 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill176, align 32
  %.spill177 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill177, align 32
  %tile_snapshot.spill178 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill178, align 64
  %.slot179 = alloca i64, align 8
  store i64 0, ptr %.slot179, align 4
  %tile_snapshot.spill180 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill180, align 64
  %.slot181 = alloca i64, align 8
  store i64 0, ptr %.slot181, align 4
  %.slot182 = alloca i64, align 8
  store i64 0, ptr %.slot182, align 4
  %tile_snapshot.spill183 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill183, align 64
  %.slot184 = alloca i64, align 8
  store i64 0, ptr %.slot184, align 4
  %54 = getelementptr i8, ptr %argument_buffer, i64 0
  %55 = load ptr, ptr %54, align 16
  %56 = getelementptr i8, ptr %54, i64 8
  %57 = load i64, ptr %56, align 8
  %58 = insertvalue { ptr, i64 } poison, ptr %55, 0
  %59 = insertvalue { ptr, i64 } %58, i64 %57, 1
  %60 = getelementptr i8, ptr %argument_buffer, i64 16
  %61 = load ptr, ptr %60, align 16
  %62 = getelementptr i8, ptr %60, i64 8
  %63 = load i64, ptr %62, align 8
  %64 = insertvalue { ptr, i64 } poison, ptr %61, 0
  %65 = insertvalue { ptr, i64 } %64, i64 %63, 1
  %66 = getelementptr i8, ptr %argument_buffer, i64 32
  %67 = load ptr, ptr %66, align 16
  %68 = getelementptr i8, ptr %66, i64 8
  %69 = load i64, ptr %68, align 8
  %70 = insertvalue { ptr, i64 } poison, ptr %67, 0
  %71 = insertvalue { ptr, i64 } %70, i64 %69, 1
  %72 = getelementptr i8, ptr %argument_buffer, i64 48
  %73 = load ptr, ptr %72, align 16
  %74 = getelementptr i8, ptr %72, i64 8
  %75 = load i64, ptr %74, align 8
  %76 = insertvalue { ptr, i64 } poison, ptr %73, 0
  %77 = insertvalue { ptr, i64 } %76, i64 %75, 1
  %78 = load i32, ptr %launch_config, align 4
  %79 = getelementptr i8, ptr %launch_config, i64 12
  %80 = load i32, ptr %79, align 4
  %81 = getelementptr i8, ptr %launch_config, i64 4
  %82 = load i32, ptr %81, align 4
  %83 = getelementptr i8, ptr %launch_config, i64 16
  %84 = load i32, ptr %83, align 4
  %85 = getelementptr i8, ptr %launch_config, i64 8
  %86 = load i32, ptr %85, align 4
  %87 = getelementptr i8, ptr %launch_config, i64 20
  %88 = load i32, ptr %87, align 4
  %89 = getelementptr i8, ptr %launch_config, i64 36
  %90 = load i32, ptr %89, align 4
  %.splatinsert185 = insertelement <8 x i32> poison, i32 %90, i64 0
  %.splat186 = shufflevector <8 x i32> %.splatinsert185, <8 x i32> poison, <8 x i32> zeroinitializer
  %91 = add <8 x i32> %.splat186, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %92 = mul i32 %78, 32
  %.splatinsert187 = insertelement <8 x i32> poison, i32 %92, i64 0
  %.splat188 = shufflevector <8 x i32> %.splatinsert187, <8 x i32> poison, <8 x i32> zeroinitializer
  %93 = add <8 x i32> %.splat188, %91
  %94 = mul i32 %82, 1
  %.splatinsert189 = insertelement <8 x i32> poison, i32 %94, i64 0
  %.splat190 = shufflevector <8 x i32> %.splatinsert189, <8 x i32> poison, <8 x i32> zeroinitializer
  %95 = add <8 x i32> %.splat190, zeroinitializer
  %96 = mul i32 %86, 1
  %.splatinsert191 = insertelement <8 x i32> poison, i32 %96, i64 0
  %.splat192 = shufflevector <8 x i32> %.splatinsert191, <8 x i32> poison, <8 x i32> zeroinitializer
  %97 = add <8 x i32> %.splat192, zeroinitializer
  %98 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %93, 0
  %99 = insertvalue [3 x <8 x i32>] %98, <8 x i32> %95, 1
  %100 = insertvalue [3 x <8 x i32>] %99, <8 x i32> %97, 2
  %.splatinsert193 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat194 = shufflevector <8 x i32> %.splatinsert193, <8 x i32> poison, <8 x i32> zeroinitializer
  %101 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat194
  %102 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  br i1 %102, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %103 = extractvalue [3 x <8 x i32>] %100, 0
  %104 = zext <8 x i32> %103 to <8 x i64>
  %105 = select <8 x i1> %101, <8 x i64> %104, <8 x i64> zeroinitializer
  %106 = select <8 x i1> %101, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %107 = sdiv <8 x i64> %105, %106
  %108 = load <8 x i64>, ptr %.spill, align 64
  %109 = select <8 x i1> %101, <8 x i64> %107, <8 x i64> %108
  store <8 x i64> %109, ptr %.spill, align 64
  %110 = select <8 x i1> %101, <8 x i64> %104, <8 x i64> zeroinitializer
  %111 = select <8 x i1> %101, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %112 = sdiv <8 x i64> %110, %111
  %113 = select <8 x i1> %101, <8 x i64> %112, <8 x i64> zeroinitializer
  %114 = select <8 x i1> %101, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %115 = srem <8 x i64> %113, %114
  %116 = mul <8 x i64> %115, splat (i64 8)
  %117 = load <8 x i64>, ptr %.spill69, align 64
  %118 = select <8 x i1> %101, <8 x i64> %116, <8 x i64> %117
  store <8 x i64> %118, ptr %.spill69, align 64
  %119 = select <8 x i1> %101, <8 x i64> %107, <8 x i64> zeroinitializer
  %120 = select <8 x i1> %101, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %121 = sdiv <8 x i64> %119, %120
  %122 = load <8 x i64>, ptr %.spill70, align 64
  %123 = select <8 x i1> %101, <8 x i64> %121, <8 x i64> %122
  store <8 x i64> %123, ptr %.spill70, align 64
  %124 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %124, 0
  %127 = select <8 x i1> %101, <8 x ptr> %125, <8 x ptr> %126
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %124, 1
  %130 = select <8 x i1> %101, <8 x i64> %128, <8 x i64> %129
  %131 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %127, 0
  %132 = insertvalue { <8 x ptr>, <8 x i64> } %131, <8 x i64> %130, 1
  store { <8 x ptr>, <8 x i64> } %132, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %133 = icmp slt i64 %.state, 256
  br i1 %133, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state195 = load i64, ptr %.slot, align 4
  %134 = srem i64 %.state195, 32
  %.state196 = load i64, ptr %.slot, align 4
  %135 = sdiv i64 %.state196, 32
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %136 = add <8 x i64> %.spill.load, zeroinitializer
  %137 = add <8 x i64> zeroinitializer, %136
  %.spill.load197 = load <8 x i64>, ptr %.spill69, align 64
  %.splatinsert198 = insertelement <8 x i64> poison, i64 %135, i64 0
  %.splat199 = shufflevector <8 x i64> %.splatinsert198, <8 x i64> poison, <8 x i32> zeroinitializer
  %138 = add <8 x i64> %.spill.load197, %.splat199
  %139 = mul <8 x i64> %137, splat (i64 64)
  %140 = add <8 x i64> %139, %138
  %141 = add i64 0, %134
  %142 = mul <8 x i64> %140, splat (i64 32)
  %.splatinsert200 = insertelement <8 x i64> poison, i64 %141, i64 0
  %.splat201 = shufflevector <8 x i64> %.splatinsert200, <8 x i64> poison, <8 x i32> zeroinitializer
  %143 = add <8 x i64> %142, %.splat201
  %144 = extractvalue { ptr, i64 } %59, 0
  %145 = mul <8 x i64> %143, splat (i64 4)
  %146 = getelementptr i8, ptr %144, <8 x i64> %145
  %147 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %146, <8 x i1> %101, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %148 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state202 = load i64, ptr %.slot, align 4
  %.splatinsert203 = insertelement <8 x i64> poison, i64 %.state202, i64 0
  %.splat204 = shufflevector <8 x i64> %.splatinsert203, <8 x i64> poison, <8 x i32> zeroinitializer
  %150 = mul <8 x i64> %.splat204, splat (i64 4)
  %151 = add <8 x i64> %149, %150
  %152 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %148, 0
  %153 = insertvalue { <8 x ptr>, <8 x i64> } %152, <8 x i64> %151, 1
  %154 = extractvalue { <8 x ptr>, <8 x i64> } %153, 0
  %155 = extractvalue { <8 x ptr>, <8 x i64> } %153, 1
  %156 = getelementptr i8, <8 x ptr> %154, <8 x i64> %155
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %147, <8 x ptr> align 1 %156, <8 x i1> %101)
  %.state205 = load i64, ptr %.slot, align 4
  %157 = add i64 %.state205, 1
  store i64 %157, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %158 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill71, align 64
  %159 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %160 = extractvalue { <8 x ptr>, <8 x i64> } %158, 0
  %161 = select <8 x i1> %101, <8 x ptr> %159, <8 x ptr> %160
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %163 = extractvalue { <8 x ptr>, <8 x i64> } %158, 1
  %164 = select <8 x i1> %101, <8 x i64> %162, <8 x i64> %163
  %165 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %161, 0
  %166 = insertvalue { <8 x ptr>, <8 x i64> } %165, <8 x i64> %164, 1
  store { <8 x ptr>, <8 x i64> } %166, ptr %tile_snapshot.spill71, align 64
  %167 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill72, align 64
  %168 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %167, 0
  %170 = select <8 x i1> %101, <8 x ptr> %168, <8 x ptr> %169
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %167, 1
  %173 = select <8 x i1> %101, <8 x i64> %171, <8 x i64> %172
  %174 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %170, 0
  %175 = insertvalue { <8 x ptr>, <8 x i64> } %174, <8 x i64> %173, 1
  store { <8 x ptr>, <8 x i64> } %175, ptr %tile_snapshot.spill72, align 64
  store i64 0, ptr %.slot73, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state206 = load i64, ptr %.slot73, align 4
  %176 = icmp slt i64 %.state206, 384
  br i1 %176, label %direct.true207, label %direct.false208

direct.schedule.5:                                ; preds = %direct.true207
  %tile_snapshot.spill.load209 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill71, align 64
  %177 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load209, 0
  %178 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load209, 1
  %.state210 = load i64, ptr %.slot73, align 4
  %.splatinsert211 = insertelement <8 x i64> poison, i64 %.state210, i64 0
  %.splat212 = shufflevector <8 x i64> %.splatinsert211, <8 x i64> poison, <8 x i32> zeroinitializer
  %179 = mul <8 x i64> %.splat212, splat (i64 32)
  %180 = add <8 x i64> %178, %179
  %181 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %177, 0
  %182 = insertvalue { <8 x ptr>, <8 x i64> } %181, <8 x i64> %180, 1
  %183 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %184 = extractvalue { <8 x ptr>, <8 x i64> } %182, 1
  %185 = extractelement <8 x ptr> %183, i32 0
  %186 = extractelement <8 x i64> %184, i32 0
  %187 = sub i64 %186, 0
  %188 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %189 = select i1 %188, i64 %187, i64 0
  %private.contiguous.address = getelementptr i8, ptr %185, i64 %189
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %190 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %private.contiguous.preserve
  store <8 x float> %190, ptr %private.contiguous.address, align 4
  %.state213 = load i64, ptr %.slot73, align 4
  %191 = add i64 %.state213, 1
  store i64 %191, ptr %.slot73, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false208
  store i64 0, ptr %.slot74, align 4
  %192 = load <8 x float>, ptr %.slot75, align 32
  %193 = select <8 x i1> %101, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %192
  store <8 x float> %193, ptr %.slot75, align 32
  %194 = load <8 x float>, ptr %.slot76, align 32
  %195 = select <8 x i1> %101, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %194
  store <8 x float> %195, ptr %.slot76, align 32
  %196 = load <8 x float>, ptr %.slot77, align 32
  %197 = select <8 x i1> %101, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %196
  store <8 x float> %197, ptr %.slot77, align 32
  %198 = load <8 x float>, ptr %.slot78, align 32
  %199 = select <8 x i1> %101, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %198
  store <8 x float> %199, ptr %.slot78, align 32
  %200 = load <8 x float>, ptr %.slot79, align 32
  %201 = select <8 x i1> %101, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %200
  store <8 x float> %201, ptr %.slot79, align 32
  %202 = load <8 x float>, ptr %.slot80, align 32
  %203 = select <8 x i1> %101, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %202
  store <8 x float> %203, ptr %.slot80, align 32
  %204 = load <8 x float>, ptr %.slot81, align 32
  %205 = select <8 x i1> %101, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %204
  store <8 x float> %205, ptr %.slot81, align 32
  %206 = load <8 x float>, ptr %.slot82, align 32
  %207 = select <8 x i1> %101, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %206
  store <8 x float> %207, ptr %.slot82, align 32
  %208 = load <8 x float>, ptr %.slot83, align 32
  %209 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %208
  store <8 x float> %209, ptr %.slot83, align 32
  %210 = load <8 x float>, ptr %.slot84, align 32
  %211 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %210
  store <8 x float> %211, ptr %.slot84, align 32
  %212 = load <8 x float>, ptr %.slot85, align 32
  %213 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %212
  store <8 x float> %213, ptr %.slot85, align 32
  %214 = load <8 x float>, ptr %.slot86, align 32
  %215 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %214
  store <8 x float> %215, ptr %.slot86, align 32
  %216 = load <8 x float>, ptr %.slot87, align 32
  %217 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %216
  store <8 x float> %217, ptr %.slot87, align 32
  %218 = load <8 x float>, ptr %.slot88, align 32
  %219 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %218
  store <8 x float> %219, ptr %.slot88, align 32
  %220 = load <8 x float>, ptr %.slot89, align 32
  %221 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %220
  store <8 x float> %221, ptr %.slot89, align 32
  %222 = load <8 x float>, ptr %.slot90, align 32
  %223 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %222
  store <8 x float> %223, ptr %.slot90, align 32
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.87, %direct.schedule.6
  %.state214 = load i64, ptr %.slot74, align 4
  %224 = icmp slt i64 %.state214, 9
  br i1 %224, label %direct.true215, label %direct.false216

direct.schedule.8:                                ; preds = %direct.true215
  %.state217 = load i64, ptr %.slot74, align 4
  %225 = sdiv i64 %.state217, 1
  %226 = mul i64 %225, 16
  store i64 %226, ptr %.spill91, align 4
  %227 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill92, align 64
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %229 = extractvalue { <8 x ptr>, <8 x i64> } %227, 0
  %230 = select <8 x i1> %101, <8 x ptr> %228, <8 x ptr> %229
  %231 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %232 = extractvalue { <8 x ptr>, <8 x i64> } %227, 1
  %233 = select <8 x i1> %101, <8 x i64> %231, <8 x i64> %232
  %234 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %230, 0
  %235 = insertvalue { <8 x ptr>, <8 x i64> } %234, <8 x i64> %233, 1
  store { <8 x ptr>, <8 x i64> } %235, ptr %tile_snapshot.spill92, align 64
  store i64 0, ptr %.slot93, align 4
  br label %direct.schedule.9

direct.schedule.9:                                ; preds = %direct.schedule.12, %direct.schedule.8
  %.state218 = load i64, ptr %.slot93, align 4
  %236 = icmp slt i64 %.state218, 512
  br i1 %236, label %direct.true219, label %direct.false220

direct.schedule.10:                               ; preds = %direct.true219
  %.state221 = load i64, ptr %.slot93, align 4
  %237 = srem i64 %.state221, 32
  %.state222 = load i64, ptr %.slot93, align 4
  %238 = sdiv i64 %.state222, 32
  %.spill.load223 = load <8 x i64>, ptr %.spill70, align 64
  %239 = add <8 x i64> %.spill.load223, zeroinitializer
  %240 = add <8 x i64> zeroinitializer, %239
  %.spill.load224 = load i64, ptr %.spill91, align 4
  %241 = add i64 %.spill.load224, %238
  %242 = mul <8 x i64> %240, splat (i64 129)
  %.splatinsert225 = insertelement <8 x i64> poison, i64 %241, i64 0
  %.splat226 = shufflevector <8 x i64> %.splatinsert225, <8 x i64> poison, <8 x i32> zeroinitializer
  %243 = add <8 x i64> %242, %.splat226
  %244 = icmp sge i64 %241, 0
  %245 = and i1 true, %244
  %246 = icmp slt i64 %241, 129
  %247 = and i1 %245, %246
  %248 = add i64 0, %237
  %249 = mul <8 x i64> %243, splat (i64 32)
  %.splatinsert227 = insertelement <8 x i64> poison, i64 %248, i64 0
  %.splat228 = shufflevector <8 x i64> %.splatinsert227, <8 x i64> poison, <8 x i32> zeroinitializer
  %250 = add <8 x i64> %249, %.splat228
  %251 = load <8 x i64>, ptr %.spill94, align 64
  %252 = select <8 x i1> %101, <8 x i64> %250, <8 x i64> %251
  store <8 x i64> %252, ptr %.spill94, align 64
  br i1 %247, label %direct.true229, label %direct.false230

direct.schedule.11:                               ; preds = %direct.true229
  %.spill.load231 = load <8 x i64>, ptr %.spill94, align 64
  %253 = extractvalue { ptr, i64 } %65, 0
  %254 = extractelement <8 x i64> %.spill.load231, i32 0
  %255 = mul i64 %254, 4
  %256 = getelementptr i8, ptr %253, i64 %255
  %257 = load float, ptr %256, align 4
  %.splatinsert232 = insertelement <8 x float> poison, float %257, i64 0
  %.splat233 = shufflevector <8 x float> %.splatinsert232, <8 x float> poison, <8 x i32> zeroinitializer
  %258 = load <8 x float>, ptr %.slot95, align 32
  %259 = select <8 x i1> %101, <8 x float> %.splat233, <8 x float> %258
  store <8 x float> %259, ptr %.slot95, align 32
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.false230, %direct.schedule.11
  %tile_snapshot.spill.load234 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill92, align 64
  %260 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load234, 0
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load234, 1
  %.state235 = load i64, ptr %.slot93, align 4
  %.splatinsert236 = insertelement <8 x i64> poison, i64 %.state235, i64 0
  %.splat237 = shufflevector <8 x i64> %.splatinsert236, <8 x i64> poison, <8 x i32> zeroinitializer
  %262 = mul <8 x i64> %.splat237, splat (i64 4)
  %263 = add <8 x i64> %261, %262
  %264 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %260, 0
  %265 = insertvalue { <8 x ptr>, <8 x i64> } %264, <8 x i64> %263, 1
  %.state238 = load <8 x float>, ptr %.slot95, align 32
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %265, 0
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %265, 1
  %268 = getelementptr i8, <8 x ptr> %266, <8 x i64> %267
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state238, <8 x ptr> align 1 %268, <8 x i1> %101)
  %.state239 = load i64, ptr %.slot93, align 4
  %269 = add i64 %.state239, 1
  store i64 %269, ptr %.slot93, align 4
  br label %direct.schedule.9

direct.schedule.13:                               ; preds = %direct.false220
  %270 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill96, align 64
  %271 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %272 = extractvalue { <8 x ptr>, <8 x i64> } %270, 0
  %273 = select <8 x i1> %101, <8 x ptr> %271, <8 x ptr> %272
  %274 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %275 = extractvalue { <8 x ptr>, <8 x i64> } %270, 1
  %276 = select <8 x i1> %101, <8 x i64> %274, <8 x i64> %275
  %277 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %273, 0
  %278 = insertvalue { <8 x ptr>, <8 x i64> } %277, <8 x i64> %276, 1
  store { <8 x ptr>, <8 x i64> } %278, ptr %tile_snapshot.spill96, align 64
  store i64 0, ptr %.slot97, align 4
  br label %direct.schedule.14

direct.schedule.14:                               ; preds = %direct.schedule.17, %direct.schedule.13
  %.state240 = load i64, ptr %.slot97, align 4
  %279 = icmp slt i64 %.state240, 768
  br i1 %279, label %direct.true241, label %direct.false242

direct.schedule.15:                               ; preds = %direct.true241
  %.state243 = load i64, ptr %.slot97, align 4
  %280 = srem i64 %.state243, 48
  %.state244 = load i64, ptr %.slot97, align 4
  %281 = sdiv i64 %.state244, 48
  %.spill.load245 = load <8 x i64>, ptr %.spill70, align 64
  %282 = add <8 x i64> %.spill.load245, zeroinitializer
  %283 = add <8 x i64> zeroinitializer, %282
  %.spill.load246 = load i64, ptr %.spill91, align 4
  %284 = add i64 %.spill.load246, %281
  %285 = mul <8 x i64> %283, splat (i64 129)
  %.splatinsert247 = insertelement <8 x i64> poison, i64 %284, i64 0
  %.splat248 = shufflevector <8 x i64> %.splatinsert247, <8 x i64> poison, <8 x i32> zeroinitializer
  %286 = add <8 x i64> %285, %.splat248
  %287 = icmp sge i64 %284, 0
  %288 = and i1 true, %287
  %289 = icmp slt i64 %284, 129
  %290 = and i1 %288, %289
  %291 = add i64 0, %280
  %292 = mul <8 x i64> %286, splat (i64 48)
  %.splatinsert249 = insertelement <8 x i64> poison, i64 %291, i64 0
  %.splat250 = shufflevector <8 x i64> %.splatinsert249, <8 x i64> poison, <8 x i32> zeroinitializer
  %293 = add <8 x i64> %292, %.splat250
  %294 = load <8 x i64>, ptr %.spill98, align 64
  %295 = select <8 x i1> %101, <8 x i64> %293, <8 x i64> %294
  store <8 x i64> %295, ptr %.spill98, align 64
  br i1 %290, label %direct.true251, label %direct.false252

direct.schedule.16:                               ; preds = %direct.true251
  %.spill.load253 = load <8 x i64>, ptr %.spill98, align 64
  %296 = extractvalue { ptr, i64 } %71, 0
  %297 = extractelement <8 x i64> %.spill.load253, i32 0
  %298 = mul i64 %297, 4
  %299 = getelementptr i8, ptr %296, i64 %298
  %300 = load float, ptr %299, align 4
  %.splatinsert254 = insertelement <8 x float> poison, float %300, i64 0
  %.splat255 = shufflevector <8 x float> %.splatinsert254, <8 x float> poison, <8 x i32> zeroinitializer
  %301 = load <8 x float>, ptr %.slot99, align 32
  %302 = select <8 x i1> %101, <8 x float> %.splat255, <8 x float> %301
  store <8 x float> %302, ptr %.slot99, align 32
  br label %direct.schedule.17

direct.schedule.17:                               ; preds = %direct.false252, %direct.schedule.16
  %tile_snapshot.spill.load256 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill96, align 64
  %303 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load256, 0
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load256, 1
  %.state257 = load i64, ptr %.slot97, align 4
  %.splatinsert258 = insertelement <8 x i64> poison, i64 %.state257, i64 0
  %.splat259 = shufflevector <8 x i64> %.splatinsert258, <8 x i64> poison, <8 x i32> zeroinitializer
  %305 = mul <8 x i64> %.splat259, splat (i64 4)
  %306 = add <8 x i64> %304, %305
  %307 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %303, 0
  %308 = insertvalue { <8 x ptr>, <8 x i64> } %307, <8 x i64> %306, 1
  %.state260 = load <8 x float>, ptr %.slot99, align 32
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %308, 0
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %308, 1
  %311 = getelementptr i8, <8 x ptr> %309, <8 x i64> %310
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state260, <8 x ptr> align 1 %311, <8 x i1> %101)
  %.state261 = load i64, ptr %.slot97, align 4
  %312 = add i64 %.state261, 1
  store i64 %312, ptr %.slot97, align 4
  br label %direct.schedule.14

direct.schedule.18:                               ; preds = %direct.false242
  %313 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill100, align 64
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %313, 0
  %316 = select <8 x i1> %101, <8 x ptr> %314, <8 x ptr> %315
  %317 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %318 = extractvalue { <8 x ptr>, <8 x i64> } %313, 1
  %319 = select <8 x i1> %101, <8 x i64> %317, <8 x i64> %318
  %320 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %316, 0
  %321 = insertvalue { <8 x ptr>, <8 x i64> } %320, <8 x i64> %319, 1
  store { <8 x ptr>, <8 x i64> } %321, ptr %tile_snapshot.spill100, align 64
  store i64 0, ptr %.slot101, align 4
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state262 = load i64, ptr %.slot101, align 4
  %322 = icmp slt i64 %.state262, 128
  br i1 %322, label %direct.true263, label %direct.false264

direct.schedule.20:                               ; preds = %direct.true263
  %tile_snapshot.spill.load265 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill100, align 64
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load265, 0
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load265, 1
  %.state266 = load i64, ptr %.slot101, align 4
  %.splatinsert267 = insertelement <8 x i64> poison, i64 %.state266, i64 0
  %.splat268 = shufflevector <8 x i64> %.splatinsert267, <8 x i64> poison, <8 x i32> zeroinitializer
  %325 = mul <8 x i64> %.splat268, splat (i64 4)
  %326 = add <8 x i64> %324, %325
  %327 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %323, 0
  %328 = insertvalue { <8 x ptr>, <8 x i64> } %327, <8 x i64> %326, 1
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %328, 0
  %330 = extractvalue { <8 x ptr>, <8 x i64> } %328, 1
  %331 = getelementptr i8, <8 x ptr> %329, <8 x i64> %330
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %331, <8 x i1> %101)
  %.state269 = load i64, ptr %.slot101, align 4
  %332 = add i64 %.state269, 1
  store i64 %332, ptr %.slot101, align 4
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false264
  %333 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill102, align 64
  %334 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %335 = extractvalue { <8 x ptr>, <8 x i64> } %333, 0
  %336 = select <8 x i1> %101, <8 x ptr> %334, <8 x ptr> %335
  %337 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %338 = extractvalue { <8 x ptr>, <8 x i64> } %333, 1
  %339 = select <8 x i1> %101, <8 x i64> %337, <8 x i64> %338
  %340 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %336, 0
  %341 = insertvalue { <8 x ptr>, <8 x i64> } %340, <8 x i64> %339, 1
  store { <8 x ptr>, <8 x i64> } %341, ptr %tile_snapshot.spill102, align 64
  %tile_snapshot.spill.load270 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %tile_snapshot.spill.load271 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill92, align 64
  %tile_snapshot.spill.load272 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill100, align 64
  %342 = extractelement <8 x i1> %101, i64 0
  br i1 %342, label %mma.active, label %mma.continue

direct.schedule.22:                               ; preds = %mma.continue286, %direct.schedule.23
  %.state423 = load i64, ptr %.slot107, align 4
  %343 = icmp slt i64 %.state423, 128
  br i1 %343, label %direct.true424, label %direct.false425

direct.schedule.23:                               ; preds = %direct.true424
  %.state426 = load i64, ptr %.slot107, align 4
  %344 = srem i64 %.state426, 8
  %.state427 = load i64, ptr %.slot107, align 4
  %345 = sdiv i64 %.state427, 8
  %346 = add i64 0, %345
  %tile_snapshot.spill.load428 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %347 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load428, 0
  %348 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load428, 1
  %.splatinsert429 = insertelement <8 x i64> poison, i64 %346, i64 0
  %.splat430 = shufflevector <8 x i64> %.splatinsert429, <8 x i64> poison, <8 x i32> zeroinitializer
  %349 = add <8 x i64> %348, %.splat430
  %350 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %347, 0
  %351 = insertvalue { <8 x ptr>, <8 x i64> } %350, <8 x i64> %349, 1
  %352 = extractvalue { <8 x ptr>, <8 x i64> } %351, 0
  %353 = extractvalue { <8 x ptr>, <8 x i64> } %351, 1
  %354 = getelementptr i8, <8 x ptr> %352, <8 x i64> %353
  %355 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %354, <8 x i1> %101, <8 x i8> zeroinitializer)
  %356 = icmp ne <8 x i8> %355, zeroinitializer
  %357 = mul i64 %346, 8
  %358 = add i64 %357, %344
  %359 = srem i64 %358, 8
  %360 = sdiv i64 %358, 8
  %361 = add i64 0, %360
  %tile_snapshot.spill.load431 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill104, align 64
  %362 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load431, 0
  %363 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load431, 1
  %.splatinsert432 = insertelement <8 x i64> poison, i64 %361, i64 0
  %.splat433 = shufflevector <8 x i64> %.splatinsert432, <8 x i64> poison, <8 x i32> zeroinitializer
  %364 = mul <8 x i64> %.splat433, splat (i64 64)
  %365 = add <8 x i64> %363, %364
  %366 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %362, 0
  %367 = insertvalue { <8 x ptr>, <8 x i64> } %366, <8 x i64> %365, 1
  %368 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %369 = extractvalue { <8 x ptr>, <8 x i64> } %367, 1
  %370 = extractelement <8 x ptr> %368, i32 0
  %371 = extractelement <8 x i64> %369, i32 0
  %372 = sub i64 %371, 0
  %373 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %374 = select i1 %373, i64 %372, i64 0
  %private.contiguous.address434 = getelementptr i8, ptr %370, i64 %374
  %private.contiguous.load = load <8 x i64>, ptr %private.contiguous.address434, align 8
  %375 = select <8 x i1> %101, <8 x i64> %private.contiguous.load, <8 x i64> zeroinitializer
  %376 = add i64 0, %359
  %tile_snapshot.spill.load435 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill105, align 64
  %377 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load435, 0
  %378 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load435, 1
  %.splatinsert436 = insertelement <8 x i64> poison, i64 %376, i64 0
  %.splat437 = shufflevector <8 x i64> %.splatinsert436, <8 x i64> poison, <8 x i32> zeroinitializer
  %379 = mul <8 x i64> %.splat437, splat (i64 64)
  %380 = add <8 x i64> %378, %379
  %381 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %377, 0
  %382 = insertvalue { <8 x ptr>, <8 x i64> } %381, <8 x i64> %380, 1
  %383 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %384 = extractvalue { <8 x ptr>, <8 x i64> } %382, 1
  %385 = extractelement <8 x ptr> %383, i32 0
  %386 = extractelement <8 x i64> %384, i32 0
  %387 = sub i64 %386, 0
  %388 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %389 = select i1 %388, i64 %387, i64 0
  %private.contiguous.address438 = getelementptr i8, ptr %385, i64 %389
  %private.contiguous.load439 = load <8 x i64>, ptr %private.contiguous.address438, align 8
  %390 = select <8 x i1> %101, <8 x i64> %private.contiguous.load439, <8 x i64> zeroinitializer
  %391 = icmp sle <8 x i64> %375, %390
  %392 = and <8 x i1> %356, %391
  %tile_snapshot.spill.load440 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill106, align 64
  %393 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load440, 0
  %394 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load440, 1
  %.state441 = load i64, ptr %.slot107, align 4
  %.splatinsert442 = insertelement <8 x i64> poison, i64 %.state441, i64 0
  %.splat443 = shufflevector <8 x i64> %.splatinsert442, <8 x i64> poison, <8 x i32> zeroinitializer
  %395 = add <8 x i64> %394, %.splat443
  %396 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %393, 0
  %397 = insertvalue { <8 x ptr>, <8 x i64> } %396, <8 x i64> %395, 1
  %398 = extractvalue { <8 x ptr>, <8 x i64> } %397, 0
  %399 = extractvalue { <8 x ptr>, <8 x i64> } %397, 1
  %400 = getelementptr i8, <8 x ptr> %398, <8 x i64> %399
  %401 = zext <8 x i1> %392 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %401, <8 x ptr> align 1 %400, <8 x i1> %101)
  %.state444 = load i64, ptr %.slot107, align 4
  %402 = add i64 %.state444, 1
  store i64 %402, ptr %.slot107, align 4
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false425
  %403 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill108, align 64
  %404 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %405 = extractvalue { <8 x ptr>, <8 x i64> } %403, 0
  %406 = select <8 x i1> %101, <8 x ptr> %404, <8 x ptr> %405
  %407 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %408 = extractvalue { <8 x ptr>, <8 x i64> } %403, 1
  %409 = select <8 x i1> %101, <8 x i64> %407, <8 x i64> %408
  %410 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %406, 0
  %411 = insertvalue { <8 x ptr>, <8 x i64> } %410, <8 x i64> %409, 1
  store { <8 x ptr>, <8 x i64> } %411, ptr %tile_snapshot.spill108, align 64
  store i64 0, ptr %.slot109, align 4
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.26, %direct.schedule.24
  %.state445 = load i64, ptr %.slot109, align 4
  %412 = icmp slt i64 %.state445, 128
  br i1 %412, label %direct.true446, label %direct.false447

direct.schedule.26:                               ; preds = %direct.true446
  %.state448 = load i64, ptr %.slot109, align 4
  %413 = srem i64 %.state448, 16
  %.state449 = load i64, ptr %.slot109, align 4
  %414 = sdiv i64 %.state449, 16
  %415 = add i64 0, %413
  %416 = mul i64 %415, 8
  %417 = add i64 %416, %414
  %tile_snapshot.spill.load450 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill106, align 64
  %418 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load450, 0
  %419 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load450, 1
  %.splatinsert451 = insertelement <8 x i64> poison, i64 %417, i64 0
  %.splat452 = shufflevector <8 x i64> %.splatinsert451, <8 x i64> poison, <8 x i32> zeroinitializer
  %420 = add <8 x i64> %419, %.splat452
  %421 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %418, 0
  %422 = insertvalue { <8 x ptr>, <8 x i64> } %421, <8 x i64> %420, 1
  %423 = extractvalue { <8 x ptr>, <8 x i64> } %422, 0
  %424 = extractvalue { <8 x ptr>, <8 x i64> } %422, 1
  %425 = getelementptr i8, <8 x ptr> %423, <8 x i64> %424
  %426 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %425, <8 x i1> %101, <8 x i8> zeroinitializer)
  %427 = icmp ne <8 x i8> %426, zeroinitializer
  %428 = add i64 0, %414
  %429 = mul i64 %428, 16
  %430 = add i64 %429, %413
  %431 = srem i64 %430, 16
  %432 = sdiv i64 %430, 16
  %433 = add i64 0, %432
  %434 = mul i64 %433, 16
  %435 = add i64 %434, %431
  %tile_snapshot.spill.load453 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill102, align 64
  %436 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load453, 0
  %437 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load453, 1
  %.splatinsert454 = insertelement <8 x i64> poison, i64 %435, i64 0
  %.splat455 = shufflevector <8 x i64> %.splatinsert454, <8 x i64> poison, <8 x i32> zeroinitializer
  %438 = mul <8 x i64> %.splat455, splat (i64 4)
  %439 = add <8 x i64> %437, %438
  %440 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %436, 0
  %441 = insertvalue { <8 x ptr>, <8 x i64> } %440, <8 x i64> %439, 1
  %442 = extractvalue { <8 x ptr>, <8 x i64> } %441, 0
  %443 = extractvalue { <8 x ptr>, <8 x i64> } %441, 1
  %444 = getelementptr i8, <8 x ptr> %442, <8 x i64> %443
  %445 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %444, <8 x i1> %101, <8 x float> zeroinitializer)
  %446 = fmul <8 x float> %445, splat (float 0x3FC6A09E60000000)
  %447 = select <8 x i1> %427, <8 x float> %446, <8 x float> splat (float 0xC6293E5940000000)
  %tile_snapshot.spill.load456 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill108, align 64
  %448 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load456, 0
  %449 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load456, 1
  %.state457 = load i64, ptr %.slot109, align 4
  %.splatinsert458 = insertelement <8 x i64> poison, i64 %.state457, i64 0
  %.splat459 = shufflevector <8 x i64> %.splatinsert458, <8 x i64> poison, <8 x i32> zeroinitializer
  %450 = mul <8 x i64> %.splat459, splat (i64 32)
  %451 = add <8 x i64> %449, %450
  %452 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %448, 0
  %453 = insertvalue { <8 x ptr>, <8 x i64> } %452, <8 x i64> %451, 1
  %454 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %455 = extractvalue { <8 x ptr>, <8 x i64> } %453, 1
  %456 = extractelement <8 x ptr> %454, i32 0
  %457 = extractelement <8 x i64> %455, i32 0
  %458 = sub i64 %457, 0
  %459 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %460 = select i1 %459, i64 %458, i64 0
  %private.contiguous.address460 = getelementptr i8, ptr %456, i64 %460
  %private.contiguous.preserve461 = load <8 x float>, ptr %private.contiguous.address460, align 4
  %461 = select <8 x i1> %101, <8 x float> %447, <8 x float> %private.contiguous.preserve461
  store <8 x float> %461, ptr %private.contiguous.address460, align 4
  %.state462 = load i64, ptr %.slot109, align 4
  %462 = add i64 %.state462, 1
  store i64 %462, ptr %.slot109, align 4
  br label %direct.schedule.25

direct.schedule.27:                               ; preds = %direct.false447
  store i64 0, ptr %.slot110, align 4
  %463 = load <8 x float>, ptr %.slot111, align 32
  %464 = select <8 x i1> %101, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %463
  store <8 x float> %464, ptr %.slot111, align 32
  br label %direct.schedule.28

direct.schedule.28:                               ; preds = %direct.schedule.29, %direct.schedule.27
  %.state463 = load i64, ptr %.slot110, align 4
  %465 = icmp slt i64 %.state463, 16
  br i1 %465, label %direct.true464, label %direct.false465

direct.schedule.29:                               ; preds = %direct.true464
  %.state466 = load i64, ptr %.slot110, align 4
  %466 = sdiv i64 %.state466, 1
  %467 = add i64 0, %466
  %tile_snapshot.spill.load467 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill108, align 64
  %468 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load467, 0
  %469 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load467, 1
  %.splatinsert468 = insertelement <8 x i64> poison, i64 %467, i64 0
  %.splat469 = shufflevector <8 x i64> %.splatinsert468, <8 x i64> poison, <8 x i32> zeroinitializer
  %470 = mul <8 x i64> %.splat469, splat (i64 32)
  %471 = add <8 x i64> %469, %470
  %472 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %468, 0
  %473 = insertvalue { <8 x ptr>, <8 x i64> } %472, <8 x i64> %471, 1
  %474 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %475 = extractvalue { <8 x ptr>, <8 x i64> } %473, 1
  %476 = extractelement <8 x ptr> %474, i32 0
  %477 = extractelement <8 x i64> %475, i32 0
  %478 = sub i64 %477, 0
  %479 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %480 = select i1 %479, i64 %478, i64 0
  %private.contiguous.address470 = getelementptr i8, ptr %476, i64 %480
  %private.contiguous.load471 = load <8 x float>, ptr %private.contiguous.address470, align 4
  %481 = select <8 x i1> %101, <8 x float> %private.contiguous.load471, <8 x float> zeroinitializer
  %.state472 = load <8 x float>, ptr %.slot111, align 32
  %482 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state472, <8 x float> %481)
  %.state473 = load i64, ptr %.slot110, align 4
  %483 = add i64 %.state473, 1
  store i64 %483, ptr %.slot110, align 4
  %484 = load <8 x float>, ptr %.slot111, align 32
  %485 = select <8 x i1> %101, <8 x float> %482, <8 x float> %484
  store <8 x float> %485, ptr %.slot111, align 32
  br label %direct.schedule.28

direct.schedule.30:                               ; preds = %direct.false465
  store i64 0, ptr %.slot112, align 4
  %486 = load <8 x float>, ptr %.slot113, align 32
  %487 = select <8 x i1> %101, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %486
  store <8 x float> %487, ptr %.slot113, align 32
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.32, %direct.schedule.30
  %.state474 = load i64, ptr %.slot112, align 4
  %488 = icmp slt i64 %.state474, 16
  br i1 %488, label %direct.true475, label %direct.false476

direct.schedule.32:                               ; preds = %direct.true475
  %.state477 = load i64, ptr %.slot112, align 4
  %489 = sdiv i64 %.state477, 1
  %490 = add i64 16, %489
  %tile_snapshot.spill.load478 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill108, align 64
  %491 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load478, 0
  %492 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load478, 1
  %.splatinsert479 = insertelement <8 x i64> poison, i64 %490, i64 0
  %.splat480 = shufflevector <8 x i64> %.splatinsert479, <8 x i64> poison, <8 x i32> zeroinitializer
  %493 = mul <8 x i64> %.splat480, splat (i64 32)
  %494 = add <8 x i64> %492, %493
  %495 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %491, 0
  %496 = insertvalue { <8 x ptr>, <8 x i64> } %495, <8 x i64> %494, 1
  %497 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %498 = extractvalue { <8 x ptr>, <8 x i64> } %496, 1
  %499 = extractelement <8 x ptr> %497, i32 0
  %500 = extractelement <8 x i64> %498, i32 0
  %501 = sub i64 %500, 0
  %502 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %503 = select i1 %502, i64 %501, i64 0
  %private.contiguous.address481 = getelementptr i8, ptr %499, i64 %503
  %private.contiguous.load482 = load <8 x float>, ptr %private.contiguous.address481, align 4
  %504 = select <8 x i1> %101, <8 x float> %private.contiguous.load482, <8 x float> zeroinitializer
  %.state483 = load <8 x float>, ptr %.slot113, align 32
  %505 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state483, <8 x float> %504)
  %.state484 = load i64, ptr %.slot112, align 4
  %506 = add i64 %.state484, 1
  store i64 %506, ptr %.slot112, align 4
  %507 = load <8 x float>, ptr %.slot113, align 32
  %508 = select <8 x i1> %101, <8 x float> %505, <8 x float> %507
  store <8 x float> %508, ptr %.slot113, align 32
  br label %direct.schedule.31

direct.schedule.33:                               ; preds = %direct.false476
  store i64 0, ptr %.slot114, align 4
  %509 = load <8 x float>, ptr %.slot115, align 32
  %510 = select <8 x i1> %101, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %509
  store <8 x float> %510, ptr %.slot115, align 32
  br label %direct.schedule.34

direct.schedule.34:                               ; preds = %direct.schedule.35, %direct.schedule.33
  %.state485 = load i64, ptr %.slot114, align 4
  %511 = icmp slt i64 %.state485, 16
  br i1 %511, label %direct.true486, label %direct.false487

direct.schedule.35:                               ; preds = %direct.true486
  %.state488 = load i64, ptr %.slot114, align 4
  %512 = sdiv i64 %.state488, 1
  %513 = add i64 32, %512
  %tile_snapshot.spill.load489 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill108, align 64
  %514 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load489, 0
  %515 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load489, 1
  %.splatinsert490 = insertelement <8 x i64> poison, i64 %513, i64 0
  %.splat491 = shufflevector <8 x i64> %.splatinsert490, <8 x i64> poison, <8 x i32> zeroinitializer
  %516 = mul <8 x i64> %.splat491, splat (i64 32)
  %517 = add <8 x i64> %515, %516
  %518 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %514, 0
  %519 = insertvalue { <8 x ptr>, <8 x i64> } %518, <8 x i64> %517, 1
  %520 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %521 = extractvalue { <8 x ptr>, <8 x i64> } %519, 1
  %522 = extractelement <8 x ptr> %520, i32 0
  %523 = extractelement <8 x i64> %521, i32 0
  %524 = sub i64 %523, 0
  %525 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %526 = select i1 %525, i64 %524, i64 0
  %private.contiguous.address492 = getelementptr i8, ptr %522, i64 %526
  %private.contiguous.load493 = load <8 x float>, ptr %private.contiguous.address492, align 4
  %527 = select <8 x i1> %101, <8 x float> %private.contiguous.load493, <8 x float> zeroinitializer
  %.state494 = load <8 x float>, ptr %.slot115, align 32
  %528 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state494, <8 x float> %527)
  %.state495 = load i64, ptr %.slot114, align 4
  %529 = add i64 %.state495, 1
  store i64 %529, ptr %.slot114, align 4
  %530 = load <8 x float>, ptr %.slot115, align 32
  %531 = select <8 x i1> %101, <8 x float> %528, <8 x float> %530
  store <8 x float> %531, ptr %.slot115, align 32
  br label %direct.schedule.34

direct.schedule.36:                               ; preds = %direct.false487
  store i64 0, ptr %.slot116, align 4
  %532 = load <8 x float>, ptr %.slot117, align 32
  %533 = select <8 x i1> %101, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %532
  store <8 x float> %533, ptr %.slot117, align 32
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.38, %direct.schedule.36
  %.state496 = load i64, ptr %.slot116, align 4
  %534 = icmp slt i64 %.state496, 16
  br i1 %534, label %direct.true497, label %direct.false498

direct.schedule.38:                               ; preds = %direct.true497
  %.state499 = load i64, ptr %.slot116, align 4
  %535 = sdiv i64 %.state499, 1
  %536 = add i64 48, %535
  %tile_snapshot.spill.load500 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill108, align 64
  %537 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load500, 0
  %538 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load500, 1
  %.splatinsert501 = insertelement <8 x i64> poison, i64 %536, i64 0
  %.splat502 = shufflevector <8 x i64> %.splatinsert501, <8 x i64> poison, <8 x i32> zeroinitializer
  %539 = mul <8 x i64> %.splat502, splat (i64 32)
  %540 = add <8 x i64> %538, %539
  %541 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %537, 0
  %542 = insertvalue { <8 x ptr>, <8 x i64> } %541, <8 x i64> %540, 1
  %543 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %544 = extractvalue { <8 x ptr>, <8 x i64> } %542, 1
  %545 = extractelement <8 x ptr> %543, i32 0
  %546 = extractelement <8 x i64> %544, i32 0
  %547 = sub i64 %546, 0
  %548 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %549 = select i1 %548, i64 %547, i64 0
  %private.contiguous.address503 = getelementptr i8, ptr %545, i64 %549
  %private.contiguous.load504 = load <8 x float>, ptr %private.contiguous.address503, align 4
  %550 = select <8 x i1> %101, <8 x float> %private.contiguous.load504, <8 x float> zeroinitializer
  %.state505 = load <8 x float>, ptr %.slot117, align 32
  %551 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state505, <8 x float> %550)
  %.state506 = load i64, ptr %.slot116, align 4
  %552 = add i64 %.state506, 1
  store i64 %552, ptr %.slot116, align 4
  %553 = load <8 x float>, ptr %.slot117, align 32
  %554 = select <8 x i1> %101, <8 x float> %551, <8 x float> %553
  store <8 x float> %554, ptr %.slot117, align 32
  br label %direct.schedule.37

direct.schedule.39:                               ; preds = %direct.false498
  store i64 0, ptr %.slot118, align 4
  %555 = load <8 x float>, ptr %.slot119, align 32
  %556 = select <8 x i1> %101, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %555
  store <8 x float> %556, ptr %.slot119, align 32
  br label %direct.schedule.40

direct.schedule.40:                               ; preds = %direct.schedule.41, %direct.schedule.39
  %.state507 = load i64, ptr %.slot118, align 4
  %557 = icmp slt i64 %.state507, 16
  br i1 %557, label %direct.true508, label %direct.false509

direct.schedule.41:                               ; preds = %direct.true508
  %.state510 = load i64, ptr %.slot118, align 4
  %558 = sdiv i64 %.state510, 1
  %559 = add i64 64, %558
  %tile_snapshot.spill.load511 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill108, align 64
  %560 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load511, 0
  %561 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load511, 1
  %.splatinsert512 = insertelement <8 x i64> poison, i64 %559, i64 0
  %.splat513 = shufflevector <8 x i64> %.splatinsert512, <8 x i64> poison, <8 x i32> zeroinitializer
  %562 = mul <8 x i64> %.splat513, splat (i64 32)
  %563 = add <8 x i64> %561, %562
  %564 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %560, 0
  %565 = insertvalue { <8 x ptr>, <8 x i64> } %564, <8 x i64> %563, 1
  %566 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %567 = extractvalue { <8 x ptr>, <8 x i64> } %565, 1
  %568 = extractelement <8 x ptr> %566, i32 0
  %569 = extractelement <8 x i64> %567, i32 0
  %570 = sub i64 %569, 0
  %571 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %572 = select i1 %571, i64 %570, i64 0
  %private.contiguous.address514 = getelementptr i8, ptr %568, i64 %572
  %private.contiguous.load515 = load <8 x float>, ptr %private.contiguous.address514, align 4
  %573 = select <8 x i1> %101, <8 x float> %private.contiguous.load515, <8 x float> zeroinitializer
  %.state516 = load <8 x float>, ptr %.slot119, align 32
  %574 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state516, <8 x float> %573)
  %.state517 = load i64, ptr %.slot118, align 4
  %575 = add i64 %.state517, 1
  store i64 %575, ptr %.slot118, align 4
  %576 = load <8 x float>, ptr %.slot119, align 32
  %577 = select <8 x i1> %101, <8 x float> %574, <8 x float> %576
  store <8 x float> %577, ptr %.slot119, align 32
  br label %direct.schedule.40

direct.schedule.42:                               ; preds = %direct.false509
  store i64 0, ptr %.slot120, align 4
  %578 = load <8 x float>, ptr %.slot121, align 32
  %579 = select <8 x i1> %101, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %578
  store <8 x float> %579, ptr %.slot121, align 32
  br label %direct.schedule.43

direct.schedule.43:                               ; preds = %direct.schedule.44, %direct.schedule.42
  %.state518 = load i64, ptr %.slot120, align 4
  %580 = icmp slt i64 %.state518, 16
  br i1 %580, label %direct.true519, label %direct.false520

direct.schedule.44:                               ; preds = %direct.true519
  %.state521 = load i64, ptr %.slot120, align 4
  %581 = sdiv i64 %.state521, 1
  %582 = add i64 80, %581
  %tile_snapshot.spill.load522 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill108, align 64
  %583 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load522, 0
  %584 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load522, 1
  %.splatinsert523 = insertelement <8 x i64> poison, i64 %582, i64 0
  %.splat524 = shufflevector <8 x i64> %.splatinsert523, <8 x i64> poison, <8 x i32> zeroinitializer
  %585 = mul <8 x i64> %.splat524, splat (i64 32)
  %586 = add <8 x i64> %584, %585
  %587 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %583, 0
  %588 = insertvalue { <8 x ptr>, <8 x i64> } %587, <8 x i64> %586, 1
  %589 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %590 = extractvalue { <8 x ptr>, <8 x i64> } %588, 1
  %591 = extractelement <8 x ptr> %589, i32 0
  %592 = extractelement <8 x i64> %590, i32 0
  %593 = sub i64 %592, 0
  %594 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %595 = select i1 %594, i64 %593, i64 0
  %private.contiguous.address525 = getelementptr i8, ptr %591, i64 %595
  %private.contiguous.load526 = load <8 x float>, ptr %private.contiguous.address525, align 4
  %596 = select <8 x i1> %101, <8 x float> %private.contiguous.load526, <8 x float> zeroinitializer
  %.state527 = load <8 x float>, ptr %.slot121, align 32
  %597 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state527, <8 x float> %596)
  %.state528 = load i64, ptr %.slot120, align 4
  %598 = add i64 %.state528, 1
  store i64 %598, ptr %.slot120, align 4
  %599 = load <8 x float>, ptr %.slot121, align 32
  %600 = select <8 x i1> %101, <8 x float> %597, <8 x float> %599
  store <8 x float> %600, ptr %.slot121, align 32
  br label %direct.schedule.43

direct.schedule.45:                               ; preds = %direct.false520
  store i64 0, ptr %.slot122, align 4
  %601 = load <8 x float>, ptr %.slot123, align 32
  %602 = select <8 x i1> %101, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %601
  store <8 x float> %602, ptr %.slot123, align 32
  br label %direct.schedule.46

direct.schedule.46:                               ; preds = %direct.schedule.47, %direct.schedule.45
  %.state529 = load i64, ptr %.slot122, align 4
  %603 = icmp slt i64 %.state529, 16
  br i1 %603, label %direct.true530, label %direct.false531

direct.schedule.47:                               ; preds = %direct.true530
  %.state532 = load i64, ptr %.slot122, align 4
  %604 = sdiv i64 %.state532, 1
  %605 = add i64 96, %604
  %tile_snapshot.spill.load533 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill108, align 64
  %606 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load533, 0
  %607 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load533, 1
  %.splatinsert534 = insertelement <8 x i64> poison, i64 %605, i64 0
  %.splat535 = shufflevector <8 x i64> %.splatinsert534, <8 x i64> poison, <8 x i32> zeroinitializer
  %608 = mul <8 x i64> %.splat535, splat (i64 32)
  %609 = add <8 x i64> %607, %608
  %610 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %606, 0
  %611 = insertvalue { <8 x ptr>, <8 x i64> } %610, <8 x i64> %609, 1
  %612 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %613 = extractvalue { <8 x ptr>, <8 x i64> } %611, 1
  %614 = extractelement <8 x ptr> %612, i32 0
  %615 = extractelement <8 x i64> %613, i32 0
  %616 = sub i64 %615, 0
  %617 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %618 = select i1 %617, i64 %616, i64 0
  %private.contiguous.address536 = getelementptr i8, ptr %614, i64 %618
  %private.contiguous.load537 = load <8 x float>, ptr %private.contiguous.address536, align 4
  %619 = select <8 x i1> %101, <8 x float> %private.contiguous.load537, <8 x float> zeroinitializer
  %.state538 = load <8 x float>, ptr %.slot123, align 32
  %620 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state538, <8 x float> %619)
  %.state539 = load i64, ptr %.slot122, align 4
  %621 = add i64 %.state539, 1
  store i64 %621, ptr %.slot122, align 4
  %622 = load <8 x float>, ptr %.slot123, align 32
  %623 = select <8 x i1> %101, <8 x float> %620, <8 x float> %622
  store <8 x float> %623, ptr %.slot123, align 32
  br label %direct.schedule.46

direct.schedule.48:                               ; preds = %direct.false531
  store i64 0, ptr %.slot124, align 4
  %624 = load <8 x float>, ptr %.slot125, align 32
  %625 = select <8 x i1> %101, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %624
  store <8 x float> %625, ptr %.slot125, align 32
  br label %direct.schedule.49

direct.schedule.49:                               ; preds = %direct.schedule.50, %direct.schedule.48
  %.state540 = load i64, ptr %.slot124, align 4
  %626 = icmp slt i64 %.state540, 16
  br i1 %626, label %direct.true541, label %direct.false542

direct.schedule.50:                               ; preds = %direct.true541
  %.state543 = load i64, ptr %.slot124, align 4
  %627 = sdiv i64 %.state543, 1
  %628 = add i64 112, %627
  %tile_snapshot.spill.load544 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill108, align 64
  %629 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load544, 0
  %630 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load544, 1
  %.splatinsert545 = insertelement <8 x i64> poison, i64 %628, i64 0
  %.splat546 = shufflevector <8 x i64> %.splatinsert545, <8 x i64> poison, <8 x i32> zeroinitializer
  %631 = mul <8 x i64> %.splat546, splat (i64 32)
  %632 = add <8 x i64> %630, %631
  %633 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %629, 0
  %634 = insertvalue { <8 x ptr>, <8 x i64> } %633, <8 x i64> %632, 1
  %635 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %636 = extractvalue { <8 x ptr>, <8 x i64> } %634, 1
  %637 = extractelement <8 x ptr> %635, i32 0
  %638 = extractelement <8 x i64> %636, i32 0
  %639 = sub i64 %638, 0
  %640 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %641 = select i1 %640, i64 %639, i64 0
  %private.contiguous.address547 = getelementptr i8, ptr %637, i64 %641
  %private.contiguous.load548 = load <8 x float>, ptr %private.contiguous.address547, align 4
  %642 = select <8 x i1> %101, <8 x float> %private.contiguous.load548, <8 x float> zeroinitializer
  %.state549 = load <8 x float>, ptr %.slot125, align 32
  %643 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state549, <8 x float> %642)
  %.state550 = load i64, ptr %.slot124, align 4
  %644 = add i64 %.state550, 1
  store i64 %644, ptr %.slot124, align 4
  %645 = load <8 x float>, ptr %.slot125, align 32
  %646 = select <8 x i1> %101, <8 x float> %643, <8 x float> %645
  store <8 x float> %646, ptr %.slot125, align 32
  br label %direct.schedule.49

direct.schedule.51:                               ; preds = %direct.false542
  %.state551 = load <8 x float>, ptr %.slot75, align 32
  %.state552 = load <8 x float>, ptr %.slot111, align 32
  %647 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state551, <8 x float> %.state552)
  %648 = load <8 x float>, ptr %.spill126, align 32
  %649 = select <8 x i1> %101, <8 x float> %647, <8 x float> %648
  store <8 x float> %649, ptr %.spill126, align 32
  %.state553 = load <8 x float>, ptr %.slot76, align 32
  %.state554 = load <8 x float>, ptr %.slot113, align 32
  %650 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state553, <8 x float> %.state554)
  %651 = load <8 x float>, ptr %.spill127, align 32
  %652 = select <8 x i1> %101, <8 x float> %650, <8 x float> %651
  store <8 x float> %652, ptr %.spill127, align 32
  %.state555 = load <8 x float>, ptr %.slot77, align 32
  %.state556 = load <8 x float>, ptr %.slot115, align 32
  %653 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state555, <8 x float> %.state556)
  %654 = load <8 x float>, ptr %.spill128, align 32
  %655 = select <8 x i1> %101, <8 x float> %653, <8 x float> %654
  store <8 x float> %655, ptr %.spill128, align 32
  %.state557 = load <8 x float>, ptr %.slot78, align 32
  %.state558 = load <8 x float>, ptr %.slot117, align 32
  %656 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state557, <8 x float> %.state558)
  %657 = load <8 x float>, ptr %.spill129, align 32
  %658 = select <8 x i1> %101, <8 x float> %656, <8 x float> %657
  store <8 x float> %658, ptr %.spill129, align 32
  %.state559 = load <8 x float>, ptr %.slot79, align 32
  %.state560 = load <8 x float>, ptr %.slot119, align 32
  %659 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state559, <8 x float> %.state560)
  %660 = load <8 x float>, ptr %.spill130, align 32
  %661 = select <8 x i1> %101, <8 x float> %659, <8 x float> %660
  store <8 x float> %661, ptr %.spill130, align 32
  %.state561 = load <8 x float>, ptr %.slot80, align 32
  %.state562 = load <8 x float>, ptr %.slot121, align 32
  %662 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state561, <8 x float> %.state562)
  %663 = load <8 x float>, ptr %.spill131, align 32
  %664 = select <8 x i1> %101, <8 x float> %662, <8 x float> %663
  store <8 x float> %664, ptr %.spill131, align 32
  %.state563 = load <8 x float>, ptr %.slot81, align 32
  %.state564 = load <8 x float>, ptr %.slot123, align 32
  %665 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state563, <8 x float> %.state564)
  %666 = load <8 x float>, ptr %.spill132, align 32
  %667 = select <8 x i1> %101, <8 x float> %665, <8 x float> %666
  store <8 x float> %667, ptr %.spill132, align 32
  %.state565 = load <8 x float>, ptr %.slot82, align 32
  %.state566 = load <8 x float>, ptr %.slot125, align 32
  %668 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state565, <8 x float> %.state566)
  %669 = load <8 x float>, ptr %.spill133, align 32
  %670 = select <8 x i1> %101, <8 x float> %668, <8 x float> %669
  store <8 x float> %670, ptr %.spill133, align 32
  %671 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill134, align 64
  %672 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %673 = extractvalue { <8 x ptr>, <8 x i64> } %671, 0
  %674 = select <8 x i1> %101, <8 x ptr> %672, <8 x ptr> %673
  %675 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %676 = extractvalue { <8 x ptr>, <8 x i64> } %671, 1
  %677 = select <8 x i1> %101, <8 x i64> %675, <8 x i64> %676
  %678 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %674, 0
  %679 = insertvalue { <8 x ptr>, <8 x i64> } %678, <8 x i64> %677, 1
  store { <8 x ptr>, <8 x i64> } %679, ptr %tile_snapshot.spill134, align 64
  %680 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %681 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %682 = add <8 x i64> %681, zeroinitializer
  %683 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %680, 0
  %684 = insertvalue { <8 x ptr>, <8 x i64> } %683, <8 x i64> %682, 1
  %685 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %686 = extractvalue { <8 x ptr>, <8 x i64> } %684, 1
  %687 = extractelement <8 x ptr> %685, i32 0
  %688 = extractelement <8 x i64> %686, i32 0
  %689 = sub i64 %688, 0
  %690 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %691 = select i1 %690, i64 %689, i64 0
  %private.contiguous.address567 = getelementptr i8, ptr %687, i64 %691
  %private.contiguous.preserve568 = load <8 x float>, ptr %private.contiguous.address567, align 4
  %692 = select <8 x i1> %101, <8 x float> %647, <8 x float> %private.contiguous.preserve568
  store <8 x float> %692, ptr %private.contiguous.address567, align 4
  %693 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %694 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %695 = add <8 x i64> %694, splat (i64 32)
  %696 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %693, 0
  %697 = insertvalue { <8 x ptr>, <8 x i64> } %696, <8 x i64> %695, 1
  %698 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %699 = extractvalue { <8 x ptr>, <8 x i64> } %697, 1
  %700 = extractelement <8 x ptr> %698, i32 0
  %701 = extractelement <8 x i64> %699, i32 0
  %702 = sub i64 %701, 0
  %703 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %704 = select i1 %703, i64 %702, i64 0
  %private.contiguous.address569 = getelementptr i8, ptr %700, i64 %704
  %private.contiguous.preserve570 = load <8 x float>, ptr %private.contiguous.address569, align 4
  %705 = select <8 x i1> %101, <8 x float> %650, <8 x float> %private.contiguous.preserve570
  store <8 x float> %705, ptr %private.contiguous.address569, align 4
  %706 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %707 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %708 = add <8 x i64> %707, splat (i64 64)
  %709 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %706, 0
  %710 = insertvalue { <8 x ptr>, <8 x i64> } %709, <8 x i64> %708, 1
  %711 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %712 = extractvalue { <8 x ptr>, <8 x i64> } %710, 1
  %713 = extractelement <8 x ptr> %711, i32 0
  %714 = extractelement <8 x i64> %712, i32 0
  %715 = sub i64 %714, 0
  %716 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %717 = select i1 %716, i64 %715, i64 0
  %private.contiguous.address571 = getelementptr i8, ptr %713, i64 %717
  %private.contiguous.preserve572 = load <8 x float>, ptr %private.contiguous.address571, align 4
  %718 = select <8 x i1> %101, <8 x float> %653, <8 x float> %private.contiguous.preserve572
  store <8 x float> %718, ptr %private.contiguous.address571, align 4
  %719 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %720 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %721 = add <8 x i64> %720, splat (i64 96)
  %722 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %719, 0
  %723 = insertvalue { <8 x ptr>, <8 x i64> } %722, <8 x i64> %721, 1
  %724 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %725 = extractvalue { <8 x ptr>, <8 x i64> } %723, 1
  %726 = extractelement <8 x ptr> %724, i32 0
  %727 = extractelement <8 x i64> %725, i32 0
  %728 = sub i64 %727, 0
  %729 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %730 = select i1 %729, i64 %728, i64 0
  %private.contiguous.address573 = getelementptr i8, ptr %726, i64 %730
  %private.contiguous.preserve574 = load <8 x float>, ptr %private.contiguous.address573, align 4
  %731 = select <8 x i1> %101, <8 x float> %656, <8 x float> %private.contiguous.preserve574
  store <8 x float> %731, ptr %private.contiguous.address573, align 4
  %732 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %733 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %734 = add <8 x i64> %733, splat (i64 128)
  %735 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %732, 0
  %736 = insertvalue { <8 x ptr>, <8 x i64> } %735, <8 x i64> %734, 1
  %737 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %738 = extractvalue { <8 x ptr>, <8 x i64> } %736, 1
  %739 = extractelement <8 x ptr> %737, i32 0
  %740 = extractelement <8 x i64> %738, i32 0
  %741 = sub i64 %740, 0
  %742 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %743 = select i1 %742, i64 %741, i64 0
  %private.contiguous.address575 = getelementptr i8, ptr %739, i64 %743
  %private.contiguous.preserve576 = load <8 x float>, ptr %private.contiguous.address575, align 4
  %744 = select <8 x i1> %101, <8 x float> %659, <8 x float> %private.contiguous.preserve576
  store <8 x float> %744, ptr %private.contiguous.address575, align 4
  %745 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %746 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %747 = add <8 x i64> %746, splat (i64 160)
  %748 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %745, 0
  %749 = insertvalue { <8 x ptr>, <8 x i64> } %748, <8 x i64> %747, 1
  %750 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %751 = extractvalue { <8 x ptr>, <8 x i64> } %749, 1
  %752 = extractelement <8 x ptr> %750, i32 0
  %753 = extractelement <8 x i64> %751, i32 0
  %754 = sub i64 %753, 0
  %755 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %756 = select i1 %755, i64 %754, i64 0
  %private.contiguous.address577 = getelementptr i8, ptr %752, i64 %756
  %private.contiguous.preserve578 = load <8 x float>, ptr %private.contiguous.address577, align 4
  %757 = select <8 x i1> %101, <8 x float> %662, <8 x float> %private.contiguous.preserve578
  store <8 x float> %757, ptr %private.contiguous.address577, align 4
  %758 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %759 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %760 = add <8 x i64> %759, splat (i64 192)
  %761 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %758, 0
  %762 = insertvalue { <8 x ptr>, <8 x i64> } %761, <8 x i64> %760, 1
  %763 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %764 = extractvalue { <8 x ptr>, <8 x i64> } %762, 1
  %765 = extractelement <8 x ptr> %763, i32 0
  %766 = extractelement <8 x i64> %764, i32 0
  %767 = sub i64 %766, 0
  %768 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %769 = select i1 %768, i64 %767, i64 0
  %private.contiguous.address579 = getelementptr i8, ptr %765, i64 %769
  %private.contiguous.preserve580 = load <8 x float>, ptr %private.contiguous.address579, align 4
  %770 = select <8 x i1> %101, <8 x float> %665, <8 x float> %private.contiguous.preserve580
  store <8 x float> %770, ptr %private.contiguous.address579, align 4
  %771 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %772 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %773 = add <8 x i64> %772, splat (i64 224)
  %774 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %771, 0
  %775 = insertvalue { <8 x ptr>, <8 x i64> } %774, <8 x i64> %773, 1
  %776 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %777 = extractvalue { <8 x ptr>, <8 x i64> } %775, 1
  %778 = extractelement <8 x ptr> %776, i32 0
  %779 = extractelement <8 x i64> %777, i32 0
  %780 = sub i64 %779, 0
  %781 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %782 = select i1 %781, i64 %780, i64 0
  %private.contiguous.address581 = getelementptr i8, ptr %778, i64 %782
  %private.contiguous.preserve582 = load <8 x float>, ptr %private.contiguous.address581, align 4
  %783 = select <8 x i1> %101, <8 x float> %668, <8 x float> %private.contiguous.preserve582
  store <8 x float> %783, ptr %private.contiguous.address581, align 4
  %.state583 = load <8 x float>, ptr %.slot75, align 32
  %784 = fsub <8 x float> %.state583, %647
  %.state584 = load <8 x float>, ptr %.slot76, align 32
  %785 = fsub <8 x float> %.state584, %650
  %.state585 = load <8 x float>, ptr %.slot77, align 32
  %786 = fsub <8 x float> %.state585, %653
  %.state586 = load <8 x float>, ptr %.slot78, align 32
  %787 = fsub <8 x float> %.state586, %656
  %.state587 = load <8 x float>, ptr %.slot79, align 32
  %788 = fsub <8 x float> %.state587, %659
  %.state588 = load <8 x float>, ptr %.slot80, align 32
  %789 = fsub <8 x float> %.state588, %662
  %.state589 = load <8 x float>, ptr %.slot81, align 32
  %790 = fsub <8 x float> %.state589, %665
  %.state590 = load <8 x float>, ptr %.slot82, align 32
  %791 = fsub <8 x float> %.state590, %668
  %792 = select <8 x i1> %101, <8 x float> %784, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %792)
  %793 = load <8 x float>, ptr %.spill135, align 32
  %794 = select <8 x i1> %101, <8 x float> %native.exp, <8 x float> %793
  store <8 x float> %794, ptr %.spill135, align 32
  %795 = select <8 x i1> %101, <8 x float> %785, <8 x float> zeroinitializer
  %native.exp591 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %795)
  %796 = load <8 x float>, ptr %.spill136, align 32
  %797 = select <8 x i1> %101, <8 x float> %native.exp591, <8 x float> %796
  store <8 x float> %797, ptr %.spill136, align 32
  %798 = select <8 x i1> %101, <8 x float> %786, <8 x float> zeroinitializer
  %native.exp592 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %798)
  %799 = load <8 x float>, ptr %.spill137, align 32
  %800 = select <8 x i1> %101, <8 x float> %native.exp592, <8 x float> %799
  store <8 x float> %800, ptr %.spill137, align 32
  %801 = select <8 x i1> %101, <8 x float> %787, <8 x float> zeroinitializer
  %native.exp593 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %801)
  %802 = load <8 x float>, ptr %.spill138, align 32
  %803 = select <8 x i1> %101, <8 x float> %native.exp593, <8 x float> %802
  store <8 x float> %803, ptr %.spill138, align 32
  %804 = select <8 x i1> %101, <8 x float> %788, <8 x float> zeroinitializer
  %native.exp594 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %804)
  %805 = load <8 x float>, ptr %.spill139, align 32
  %806 = select <8 x i1> %101, <8 x float> %native.exp594, <8 x float> %805
  store <8 x float> %806, ptr %.spill139, align 32
  %807 = select <8 x i1> %101, <8 x float> %789, <8 x float> zeroinitializer
  %native.exp595 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %807)
  %808 = load <8 x float>, ptr %.spill140, align 32
  %809 = select <8 x i1> %101, <8 x float> %native.exp595, <8 x float> %808
  store <8 x float> %809, ptr %.spill140, align 32
  %810 = select <8 x i1> %101, <8 x float> %790, <8 x float> zeroinitializer
  %native.exp596 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %810)
  %811 = load <8 x float>, ptr %.spill141, align 32
  %812 = select <8 x i1> %101, <8 x float> %native.exp596, <8 x float> %811
  store <8 x float> %812, ptr %.spill141, align 32
  %813 = select <8 x i1> %101, <8 x float> %791, <8 x float> zeroinitializer
  %native.exp597 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %813)
  %814 = load <8 x float>, ptr %.spill142, align 32
  %815 = select <8 x i1> %101, <8 x float> %native.exp597, <8 x float> %814
  store <8 x float> %815, ptr %.spill142, align 32
  %816 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill143, align 64
  %817 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %818 = extractvalue { <8 x ptr>, <8 x i64> } %816, 0
  %819 = select <8 x i1> %101, <8 x ptr> %817, <8 x ptr> %818
  %820 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %821 = extractvalue { <8 x ptr>, <8 x i64> } %816, 1
  %822 = select <8 x i1> %101, <8 x i64> %820, <8 x i64> %821
  %823 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %819, 0
  %824 = insertvalue { <8 x ptr>, <8 x i64> } %823, <8 x i64> %822, 1
  store { <8 x ptr>, <8 x i64> } %824, ptr %tile_snapshot.spill143, align 64
  %825 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %826 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %827 = add <8 x i64> %826, zeroinitializer
  %828 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %825, 0
  %829 = insertvalue { <8 x ptr>, <8 x i64> } %828, <8 x i64> %827, 1
  %830 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %831 = extractvalue { <8 x ptr>, <8 x i64> } %829, 1
  %832 = extractelement <8 x ptr> %830, i32 0
  %833 = extractelement <8 x i64> %831, i32 0
  %834 = sub i64 %833, 0
  %835 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %836 = select i1 %835, i64 %834, i64 0
  %private.contiguous.address598 = getelementptr i8, ptr %832, i64 %836
  %private.contiguous.preserve599 = load <8 x float>, ptr %private.contiguous.address598, align 4
  %837 = select <8 x i1> %101, <8 x float> %native.exp, <8 x float> %private.contiguous.preserve599
  store <8 x float> %837, ptr %private.contiguous.address598, align 4
  %838 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %839 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %840 = add <8 x i64> %839, splat (i64 32)
  %841 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %838, 0
  %842 = insertvalue { <8 x ptr>, <8 x i64> } %841, <8 x i64> %840, 1
  %843 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %844 = extractvalue { <8 x ptr>, <8 x i64> } %842, 1
  %845 = extractelement <8 x ptr> %843, i32 0
  %846 = extractelement <8 x i64> %844, i32 0
  %847 = sub i64 %846, 0
  %848 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %849 = select i1 %848, i64 %847, i64 0
  %private.contiguous.address600 = getelementptr i8, ptr %845, i64 %849
  %private.contiguous.preserve601 = load <8 x float>, ptr %private.contiguous.address600, align 4
  %850 = select <8 x i1> %101, <8 x float> %native.exp591, <8 x float> %private.contiguous.preserve601
  store <8 x float> %850, ptr %private.contiguous.address600, align 4
  %851 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %852 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %853 = add <8 x i64> %852, splat (i64 64)
  %854 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %851, 0
  %855 = insertvalue { <8 x ptr>, <8 x i64> } %854, <8 x i64> %853, 1
  %856 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %857 = extractvalue { <8 x ptr>, <8 x i64> } %855, 1
  %858 = extractelement <8 x ptr> %856, i32 0
  %859 = extractelement <8 x i64> %857, i32 0
  %860 = sub i64 %859, 0
  %861 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %862 = select i1 %861, i64 %860, i64 0
  %private.contiguous.address602 = getelementptr i8, ptr %858, i64 %862
  %private.contiguous.preserve603 = load <8 x float>, ptr %private.contiguous.address602, align 4
  %863 = select <8 x i1> %101, <8 x float> %native.exp592, <8 x float> %private.contiguous.preserve603
  store <8 x float> %863, ptr %private.contiguous.address602, align 4
  %864 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %865 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %866 = add <8 x i64> %865, splat (i64 96)
  %867 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %864, 0
  %868 = insertvalue { <8 x ptr>, <8 x i64> } %867, <8 x i64> %866, 1
  %869 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %870 = extractvalue { <8 x ptr>, <8 x i64> } %868, 1
  %871 = extractelement <8 x ptr> %869, i32 0
  %872 = extractelement <8 x i64> %870, i32 0
  %873 = sub i64 %872, 0
  %874 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %875 = select i1 %874, i64 %873, i64 0
  %private.contiguous.address604 = getelementptr i8, ptr %871, i64 %875
  %private.contiguous.preserve605 = load <8 x float>, ptr %private.contiguous.address604, align 4
  %876 = select <8 x i1> %101, <8 x float> %native.exp593, <8 x float> %private.contiguous.preserve605
  store <8 x float> %876, ptr %private.contiguous.address604, align 4
  %877 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %878 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %879 = add <8 x i64> %878, splat (i64 128)
  %880 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %877, 0
  %881 = insertvalue { <8 x ptr>, <8 x i64> } %880, <8 x i64> %879, 1
  %882 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %883 = extractvalue { <8 x ptr>, <8 x i64> } %881, 1
  %884 = extractelement <8 x ptr> %882, i32 0
  %885 = extractelement <8 x i64> %883, i32 0
  %886 = sub i64 %885, 0
  %887 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %888 = select i1 %887, i64 %886, i64 0
  %private.contiguous.address606 = getelementptr i8, ptr %884, i64 %888
  %private.contiguous.preserve607 = load <8 x float>, ptr %private.contiguous.address606, align 4
  %889 = select <8 x i1> %101, <8 x float> %native.exp594, <8 x float> %private.contiguous.preserve607
  store <8 x float> %889, ptr %private.contiguous.address606, align 4
  %890 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %891 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %892 = add <8 x i64> %891, splat (i64 160)
  %893 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %890, 0
  %894 = insertvalue { <8 x ptr>, <8 x i64> } %893, <8 x i64> %892, 1
  %895 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %896 = extractvalue { <8 x ptr>, <8 x i64> } %894, 1
  %897 = extractelement <8 x ptr> %895, i32 0
  %898 = extractelement <8 x i64> %896, i32 0
  %899 = sub i64 %898, 0
  %900 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %901 = select i1 %900, i64 %899, i64 0
  %private.contiguous.address608 = getelementptr i8, ptr %897, i64 %901
  %private.contiguous.preserve609 = load <8 x float>, ptr %private.contiguous.address608, align 4
  %902 = select <8 x i1> %101, <8 x float> %native.exp595, <8 x float> %private.contiguous.preserve609
  store <8 x float> %902, ptr %private.contiguous.address608, align 4
  %903 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %904 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %905 = add <8 x i64> %904, splat (i64 192)
  %906 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %903, 0
  %907 = insertvalue { <8 x ptr>, <8 x i64> } %906, <8 x i64> %905, 1
  %908 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %909 = extractvalue { <8 x ptr>, <8 x i64> } %907, 1
  %910 = extractelement <8 x ptr> %908, i32 0
  %911 = extractelement <8 x i64> %909, i32 0
  %912 = sub i64 %911, 0
  %913 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %914 = select i1 %913, i64 %912, i64 0
  %private.contiguous.address610 = getelementptr i8, ptr %910, i64 %914
  %private.contiguous.preserve611 = load <8 x float>, ptr %private.contiguous.address610, align 4
  %915 = select <8 x i1> %101, <8 x float> %native.exp596, <8 x float> %private.contiguous.preserve611
  store <8 x float> %915, ptr %private.contiguous.address610, align 4
  %916 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %917 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %918 = add <8 x i64> %917, splat (i64 224)
  %919 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %916, 0
  %920 = insertvalue { <8 x ptr>, <8 x i64> } %919, <8 x i64> %918, 1
  %921 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %922 = extractvalue { <8 x ptr>, <8 x i64> } %920, 1
  %923 = extractelement <8 x ptr> %921, i32 0
  %924 = extractelement <8 x i64> %922, i32 0
  %925 = sub i64 %924, 0
  %926 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %927 = select i1 %926, i64 %925, i64 0
  %private.contiguous.address612 = getelementptr i8, ptr %923, i64 %927
  %private.contiguous.preserve613 = load <8 x float>, ptr %private.contiguous.address612, align 4
  %928 = select <8 x i1> %101, <8 x float> %native.exp597, <8 x float> %private.contiguous.preserve613
  store <8 x float> %928, ptr %private.contiguous.address612, align 4
  %929 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill144, align 64
  %930 = extractvalue { <8 x ptr>, <8 x i64> } %44, 0
  %931 = extractvalue { <8 x ptr>, <8 x i64> } %929, 0
  %932 = select <8 x i1> %101, <8 x ptr> %930, <8 x ptr> %931
  %933 = extractvalue { <8 x ptr>, <8 x i64> } %44, 1
  %934 = extractvalue { <8 x ptr>, <8 x i64> } %929, 1
  %935 = select <8 x i1> %101, <8 x i64> %933, <8 x i64> %934
  %936 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %932, 0
  %937 = insertvalue { <8 x ptr>, <8 x i64> } %936, <8 x i64> %935, 1
  store { <8 x ptr>, <8 x i64> } %937, ptr %tile_snapshot.spill144, align 64
  store i64 0, ptr %.slot145, align 4
  br label %direct.schedule.52

direct.schedule.52:                               ; preds = %direct.schedule.53, %direct.schedule.51
  %.state614 = load i64, ptr %.slot145, align 4
  %938 = icmp slt i64 %.state614, 128
  br i1 %938, label %direct.true615, label %direct.false616

direct.schedule.53:                               ; preds = %direct.true615
  %.state617 = load i64, ptr %.slot145, align 4
  %939 = srem i64 %.state617, 16
  %.state618 = load i64, ptr %.slot145, align 4
  %940 = sdiv i64 %.state618, 16
  %941 = add i64 0, %939
  %942 = mul i64 %941, 8
  %943 = add i64 %942, %940
  %tile_snapshot.spill.load619 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill106, align 64
  %944 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load619, 0
  %945 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load619, 1
  %.splatinsert620 = insertelement <8 x i64> poison, i64 %943, i64 0
  %.splat621 = shufflevector <8 x i64> %.splatinsert620, <8 x i64> poison, <8 x i32> zeroinitializer
  %946 = add <8 x i64> %945, %.splat621
  %947 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %944, 0
  %948 = insertvalue { <8 x ptr>, <8 x i64> } %947, <8 x i64> %946, 1
  %949 = extractvalue { <8 x ptr>, <8 x i64> } %948, 0
  %950 = extractvalue { <8 x ptr>, <8 x i64> } %948, 1
  %951 = getelementptr i8, <8 x ptr> %949, <8 x i64> %950
  %952 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %951, <8 x i1> %101, <8 x i8> zeroinitializer)
  %953 = icmp ne <8 x i8> %952, zeroinitializer
  %954 = add i64 0, %940
  %955 = mul i64 %954, 16
  %956 = add i64 %955, %939
  %957 = srem i64 %956, 16
  %958 = sdiv i64 %956, 16
  %959 = add i64 0, %958
  %960 = mul i64 %959, 16
  %961 = add i64 %960, %957
  %962 = srem i64 %961, 16
  %963 = sdiv i64 %961, 16
  %964 = add i64 0, %963
  %965 = mul i64 %964, 16
  %966 = add i64 %965, %962
  %tile_snapshot.spill.load622 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill108, align 64
  %967 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load622, 0
  %968 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load622, 1
  %.splatinsert623 = insertelement <8 x i64> poison, i64 %966, i64 0
  %.splat624 = shufflevector <8 x i64> %.splatinsert623, <8 x i64> poison, <8 x i32> zeroinitializer
  %969 = mul <8 x i64> %.splat624, splat (i64 32)
  %970 = add <8 x i64> %968, %969
  %971 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %967, 0
  %972 = insertvalue { <8 x ptr>, <8 x i64> } %971, <8 x i64> %970, 1
  %973 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %974 = extractvalue { <8 x ptr>, <8 x i64> } %972, 1
  %975 = extractelement <8 x ptr> %973, i32 0
  %976 = extractelement <8 x i64> %974, i32 0
  %977 = sub i64 %976, 0
  %978 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %979 = select i1 %978, i64 %977, i64 0
  %private.contiguous.address625 = getelementptr i8, ptr %975, i64 %979
  %private.contiguous.load626 = load <8 x float>, ptr %private.contiguous.address625, align 4
  %980 = select <8 x i1> %101, <8 x float> %private.contiguous.load626, <8 x float> zeroinitializer
  %tile_snapshot.spill.load627 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill134, align 64
  %981 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load627, 0
  %982 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load627, 1
  %.splatinsert628 = insertelement <8 x i64> poison, i64 %964, i64 0
  %.splat629 = shufflevector <8 x i64> %.splatinsert628, <8 x i64> poison, <8 x i32> zeroinitializer
  %983 = mul <8 x i64> %.splat629, splat (i64 32)
  %984 = add <8 x i64> %982, %983
  %985 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %981, 0
  %986 = insertvalue { <8 x ptr>, <8 x i64> } %985, <8 x i64> %984, 1
  %987 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %988 = extractvalue { <8 x ptr>, <8 x i64> } %986, 1
  %989 = extractelement <8 x ptr> %987, i32 0
  %990 = extractelement <8 x i64> %988, i32 0
  %991 = sub i64 %990, 0
  %992 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %993 = select i1 %992, i64 %991, i64 0
  %private.contiguous.address630 = getelementptr i8, ptr %989, i64 %993
  %private.contiguous.load631 = load <8 x float>, ptr %private.contiguous.address630, align 4
  %994 = select <8 x i1> %101, <8 x float> %private.contiguous.load631, <8 x float> zeroinitializer
  %995 = fsub <8 x float> %980, %994
  %996 = select <8 x i1> %101, <8 x float> %995, <8 x float> zeroinitializer
  %native.exp632 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %996)
  %997 = select <8 x i1> %953, <8 x float> %native.exp632, <8 x float> zeroinitializer
  %tile_snapshot.spill.load633 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill144, align 64
  %998 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load633, 0
  %999 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load633, 1
  %.state634 = load i64, ptr %.slot145, align 4
  %.splatinsert635 = insertelement <8 x i64> poison, i64 %.state634, i64 0
  %.splat636 = shufflevector <8 x i64> %.splatinsert635, <8 x i64> poison, <8 x i32> zeroinitializer
  %1000 = mul <8 x i64> %.splat636, splat (i64 4)
  %1001 = add <8 x i64> %999, %1000
  %1002 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %998, 0
  %1003 = insertvalue { <8 x ptr>, <8 x i64> } %1002, <8 x i64> %1001, 1
  %1004 = extractvalue { <8 x ptr>, <8 x i64> } %1003, 0
  %1005 = extractvalue { <8 x ptr>, <8 x i64> } %1003, 1
  %1006 = getelementptr i8, <8 x ptr> %1004, <8 x i64> %1005
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %997, <8 x ptr> align 1 %1006, <8 x i1> %101)
  %.state637 = load i64, ptr %.slot145, align 4
  %1007 = add i64 %.state637, 1
  store i64 %1007, ptr %.slot145, align 4
  br label %direct.schedule.52

direct.schedule.54:                               ; preds = %direct.false616
  %.state638 = load <8 x float>, ptr %.slot83, align 32
  %.spill.load639 = load <8 x float>, ptr %.spill135, align 32
  %1008 = fmul <8 x float> %.state638, %.spill.load639
  %1009 = load <8 x float>, ptr %.spill146, align 32
  %1010 = select <8 x i1> %101, <8 x float> %1008, <8 x float> %1009
  store <8 x float> %1010, ptr %.spill146, align 32
  %.state640 = load <8 x float>, ptr %.slot84, align 32
  %.spill.load641 = load <8 x float>, ptr %.spill136, align 32
  %1011 = fmul <8 x float> %.state640, %.spill.load641
  %1012 = load <8 x float>, ptr %.spill147, align 32
  %1013 = select <8 x i1> %101, <8 x float> %1011, <8 x float> %1012
  store <8 x float> %1013, ptr %.spill147, align 32
  %.state642 = load <8 x float>, ptr %.slot85, align 32
  %.spill.load643 = load <8 x float>, ptr %.spill137, align 32
  %1014 = fmul <8 x float> %.state642, %.spill.load643
  %1015 = load <8 x float>, ptr %.spill148, align 32
  %1016 = select <8 x i1> %101, <8 x float> %1014, <8 x float> %1015
  store <8 x float> %1016, ptr %.spill148, align 32
  %.state644 = load <8 x float>, ptr %.slot86, align 32
  %.spill.load645 = load <8 x float>, ptr %.spill138, align 32
  %1017 = fmul <8 x float> %.state644, %.spill.load645
  %1018 = load <8 x float>, ptr %.spill149, align 32
  %1019 = select <8 x i1> %101, <8 x float> %1017, <8 x float> %1018
  store <8 x float> %1019, ptr %.spill149, align 32
  %.state646 = load <8 x float>, ptr %.slot87, align 32
  %.spill.load647 = load <8 x float>, ptr %.spill139, align 32
  %1020 = fmul <8 x float> %.state646, %.spill.load647
  %1021 = load <8 x float>, ptr %.spill150, align 32
  %1022 = select <8 x i1> %101, <8 x float> %1020, <8 x float> %1021
  store <8 x float> %1022, ptr %.spill150, align 32
  %.state648 = load <8 x float>, ptr %.slot88, align 32
  %.spill.load649 = load <8 x float>, ptr %.spill140, align 32
  %1023 = fmul <8 x float> %.state648, %.spill.load649
  %1024 = load <8 x float>, ptr %.spill151, align 32
  %1025 = select <8 x i1> %101, <8 x float> %1023, <8 x float> %1024
  store <8 x float> %1025, ptr %.spill151, align 32
  %.state650 = load <8 x float>, ptr %.slot89, align 32
  %.spill.load651 = load <8 x float>, ptr %.spill141, align 32
  %1026 = fmul <8 x float> %.state650, %.spill.load651
  %1027 = load <8 x float>, ptr %.spill152, align 32
  %1028 = select <8 x i1> %101, <8 x float> %1026, <8 x float> %1027
  store <8 x float> %1028, ptr %.spill152, align 32
  %.state652 = load <8 x float>, ptr %.slot90, align 32
  %.spill.load653 = load <8 x float>, ptr %.spill142, align 32
  %1029 = fmul <8 x float> %.state652, %.spill.load653
  %1030 = load <8 x float>, ptr %.spill153, align 32
  %1031 = select <8 x i1> %101, <8 x float> %1029, <8 x float> %1030
  store <8 x float> %1031, ptr %.spill153, align 32
  store i64 0, ptr %.slot154, align 4
  %1032 = load <8 x float>, ptr %.slot155, align 32
  %1033 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %1032
  store <8 x float> %1033, ptr %.slot155, align 32
  br label %direct.schedule.55

direct.schedule.55:                               ; preds = %direct.schedule.56, %direct.schedule.54
  %.state654 = load i64, ptr %.slot154, align 4
  %1034 = icmp slt i64 %.state654, 16
  br i1 %1034, label %direct.true655, label %direct.false656

direct.schedule.56:                               ; preds = %direct.true655
  %.state657 = load i64, ptr %.slot154, align 4
  %1035 = sdiv i64 %.state657, 1
  %1036 = add i64 0, %1035
  %tile_snapshot.spill.load658 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill144, align 64
  %1037 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load658, 0
  %1038 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load658, 1
  %.splatinsert659 = insertelement <8 x i64> poison, i64 %1036, i64 0
  %.splat660 = shufflevector <8 x i64> %.splatinsert659, <8 x i64> poison, <8 x i32> zeroinitializer
  %1039 = mul <8 x i64> %.splat660, splat (i64 4)
  %1040 = add <8 x i64> %1038, %1039
  %1041 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1037, 0
  %1042 = insertvalue { <8 x ptr>, <8 x i64> } %1041, <8 x i64> %1040, 1
  %1043 = extractvalue { <8 x ptr>, <8 x i64> } %1042, 0
  %1044 = extractvalue { <8 x ptr>, <8 x i64> } %1042, 1
  %1045 = getelementptr i8, <8 x ptr> %1043, <8 x i64> %1044
  %1046 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1045, <8 x i1> %101, <8 x float> zeroinitializer)
  %.state661 = load <8 x float>, ptr %.slot155, align 32
  %1047 = fadd <8 x float> %.state661, %1046
  %.state662 = load i64, ptr %.slot154, align 4
  %1048 = add i64 %.state662, 1
  store i64 %1048, ptr %.slot154, align 4
  %1049 = load <8 x float>, ptr %.slot155, align 32
  %1050 = select <8 x i1> %101, <8 x float> %1047, <8 x float> %1049
  store <8 x float> %1050, ptr %.slot155, align 32
  br label %direct.schedule.55

direct.schedule.57:                               ; preds = %direct.false656
  store i64 0, ptr %.slot156, align 4
  %1051 = load <8 x float>, ptr %.slot157, align 32
  %1052 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %1051
  store <8 x float> %1052, ptr %.slot157, align 32
  br label %direct.schedule.58

direct.schedule.58:                               ; preds = %direct.schedule.59, %direct.schedule.57
  %.state663 = load i64, ptr %.slot156, align 4
  %1053 = icmp slt i64 %.state663, 16
  br i1 %1053, label %direct.true664, label %direct.false665

direct.schedule.59:                               ; preds = %direct.true664
  %.state666 = load i64, ptr %.slot156, align 4
  %1054 = sdiv i64 %.state666, 1
  %1055 = add i64 16, %1054
  %tile_snapshot.spill.load667 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill144, align 64
  %1056 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load667, 0
  %1057 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load667, 1
  %.splatinsert668 = insertelement <8 x i64> poison, i64 %1055, i64 0
  %.splat669 = shufflevector <8 x i64> %.splatinsert668, <8 x i64> poison, <8 x i32> zeroinitializer
  %1058 = mul <8 x i64> %.splat669, splat (i64 4)
  %1059 = add <8 x i64> %1057, %1058
  %1060 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1056, 0
  %1061 = insertvalue { <8 x ptr>, <8 x i64> } %1060, <8 x i64> %1059, 1
  %1062 = extractvalue { <8 x ptr>, <8 x i64> } %1061, 0
  %1063 = extractvalue { <8 x ptr>, <8 x i64> } %1061, 1
  %1064 = getelementptr i8, <8 x ptr> %1062, <8 x i64> %1063
  %1065 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1064, <8 x i1> %101, <8 x float> zeroinitializer)
  %.state670 = load <8 x float>, ptr %.slot157, align 32
  %1066 = fadd <8 x float> %.state670, %1065
  %.state671 = load i64, ptr %.slot156, align 4
  %1067 = add i64 %.state671, 1
  store i64 %1067, ptr %.slot156, align 4
  %1068 = load <8 x float>, ptr %.slot157, align 32
  %1069 = select <8 x i1> %101, <8 x float> %1066, <8 x float> %1068
  store <8 x float> %1069, ptr %.slot157, align 32
  br label %direct.schedule.58

direct.schedule.60:                               ; preds = %direct.false665
  store i64 0, ptr %.slot158, align 4
  %1070 = load <8 x float>, ptr %.slot159, align 32
  %1071 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %1070
  store <8 x float> %1071, ptr %.slot159, align 32
  br label %direct.schedule.61

direct.schedule.61:                               ; preds = %direct.schedule.62, %direct.schedule.60
  %.state672 = load i64, ptr %.slot158, align 4
  %1072 = icmp slt i64 %.state672, 16
  br i1 %1072, label %direct.true673, label %direct.false674

direct.schedule.62:                               ; preds = %direct.true673
  %.state675 = load i64, ptr %.slot158, align 4
  %1073 = sdiv i64 %.state675, 1
  %1074 = add i64 32, %1073
  %tile_snapshot.spill.load676 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill144, align 64
  %1075 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load676, 0
  %1076 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load676, 1
  %.splatinsert677 = insertelement <8 x i64> poison, i64 %1074, i64 0
  %.splat678 = shufflevector <8 x i64> %.splatinsert677, <8 x i64> poison, <8 x i32> zeroinitializer
  %1077 = mul <8 x i64> %.splat678, splat (i64 4)
  %1078 = add <8 x i64> %1076, %1077
  %1079 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1075, 0
  %1080 = insertvalue { <8 x ptr>, <8 x i64> } %1079, <8 x i64> %1078, 1
  %1081 = extractvalue { <8 x ptr>, <8 x i64> } %1080, 0
  %1082 = extractvalue { <8 x ptr>, <8 x i64> } %1080, 1
  %1083 = getelementptr i8, <8 x ptr> %1081, <8 x i64> %1082
  %1084 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1083, <8 x i1> %101, <8 x float> zeroinitializer)
  %.state679 = load <8 x float>, ptr %.slot159, align 32
  %1085 = fadd <8 x float> %.state679, %1084
  %.state680 = load i64, ptr %.slot158, align 4
  %1086 = add i64 %.state680, 1
  store i64 %1086, ptr %.slot158, align 4
  %1087 = load <8 x float>, ptr %.slot159, align 32
  %1088 = select <8 x i1> %101, <8 x float> %1085, <8 x float> %1087
  store <8 x float> %1088, ptr %.slot159, align 32
  br label %direct.schedule.61

direct.schedule.63:                               ; preds = %direct.false674
  store i64 0, ptr %.slot160, align 4
  %1089 = load <8 x float>, ptr %.slot161, align 32
  %1090 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %1089
  store <8 x float> %1090, ptr %.slot161, align 32
  br label %direct.schedule.64

direct.schedule.64:                               ; preds = %direct.schedule.65, %direct.schedule.63
  %.state681 = load i64, ptr %.slot160, align 4
  %1091 = icmp slt i64 %.state681, 16
  br i1 %1091, label %direct.true682, label %direct.false683

direct.schedule.65:                               ; preds = %direct.true682
  %.state684 = load i64, ptr %.slot160, align 4
  %1092 = sdiv i64 %.state684, 1
  %1093 = add i64 48, %1092
  %tile_snapshot.spill.load685 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill144, align 64
  %1094 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load685, 0
  %1095 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load685, 1
  %.splatinsert686 = insertelement <8 x i64> poison, i64 %1093, i64 0
  %.splat687 = shufflevector <8 x i64> %.splatinsert686, <8 x i64> poison, <8 x i32> zeroinitializer
  %1096 = mul <8 x i64> %.splat687, splat (i64 4)
  %1097 = add <8 x i64> %1095, %1096
  %1098 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1094, 0
  %1099 = insertvalue { <8 x ptr>, <8 x i64> } %1098, <8 x i64> %1097, 1
  %1100 = extractvalue { <8 x ptr>, <8 x i64> } %1099, 0
  %1101 = extractvalue { <8 x ptr>, <8 x i64> } %1099, 1
  %1102 = getelementptr i8, <8 x ptr> %1100, <8 x i64> %1101
  %1103 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1102, <8 x i1> %101, <8 x float> zeroinitializer)
  %.state688 = load <8 x float>, ptr %.slot161, align 32
  %1104 = fadd <8 x float> %.state688, %1103
  %.state689 = load i64, ptr %.slot160, align 4
  %1105 = add i64 %.state689, 1
  store i64 %1105, ptr %.slot160, align 4
  %1106 = load <8 x float>, ptr %.slot161, align 32
  %1107 = select <8 x i1> %101, <8 x float> %1104, <8 x float> %1106
  store <8 x float> %1107, ptr %.slot161, align 32
  br label %direct.schedule.64

direct.schedule.66:                               ; preds = %direct.false683
  store i64 0, ptr %.slot162, align 4
  %1108 = load <8 x float>, ptr %.slot163, align 32
  %1109 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %1108
  store <8 x float> %1109, ptr %.slot163, align 32
  br label %direct.schedule.67

direct.schedule.67:                               ; preds = %direct.schedule.68, %direct.schedule.66
  %.state690 = load i64, ptr %.slot162, align 4
  %1110 = icmp slt i64 %.state690, 16
  br i1 %1110, label %direct.true691, label %direct.false692

direct.schedule.68:                               ; preds = %direct.true691
  %.state693 = load i64, ptr %.slot162, align 4
  %1111 = sdiv i64 %.state693, 1
  %1112 = add i64 64, %1111
  %tile_snapshot.spill.load694 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill144, align 64
  %1113 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load694, 0
  %1114 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load694, 1
  %.splatinsert695 = insertelement <8 x i64> poison, i64 %1112, i64 0
  %.splat696 = shufflevector <8 x i64> %.splatinsert695, <8 x i64> poison, <8 x i32> zeroinitializer
  %1115 = mul <8 x i64> %.splat696, splat (i64 4)
  %1116 = add <8 x i64> %1114, %1115
  %1117 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1113, 0
  %1118 = insertvalue { <8 x ptr>, <8 x i64> } %1117, <8 x i64> %1116, 1
  %1119 = extractvalue { <8 x ptr>, <8 x i64> } %1118, 0
  %1120 = extractvalue { <8 x ptr>, <8 x i64> } %1118, 1
  %1121 = getelementptr i8, <8 x ptr> %1119, <8 x i64> %1120
  %1122 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1121, <8 x i1> %101, <8 x float> zeroinitializer)
  %.state697 = load <8 x float>, ptr %.slot163, align 32
  %1123 = fadd <8 x float> %.state697, %1122
  %.state698 = load i64, ptr %.slot162, align 4
  %1124 = add i64 %.state698, 1
  store i64 %1124, ptr %.slot162, align 4
  %1125 = load <8 x float>, ptr %.slot163, align 32
  %1126 = select <8 x i1> %101, <8 x float> %1123, <8 x float> %1125
  store <8 x float> %1126, ptr %.slot163, align 32
  br label %direct.schedule.67

direct.schedule.69:                               ; preds = %direct.false692
  store i64 0, ptr %.slot164, align 4
  %1127 = load <8 x float>, ptr %.slot165, align 32
  %1128 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %1127
  store <8 x float> %1128, ptr %.slot165, align 32
  br label %direct.schedule.70

direct.schedule.70:                               ; preds = %direct.schedule.71, %direct.schedule.69
  %.state699 = load i64, ptr %.slot164, align 4
  %1129 = icmp slt i64 %.state699, 16
  br i1 %1129, label %direct.true700, label %direct.false701

direct.schedule.71:                               ; preds = %direct.true700
  %.state702 = load i64, ptr %.slot164, align 4
  %1130 = sdiv i64 %.state702, 1
  %1131 = add i64 80, %1130
  %tile_snapshot.spill.load703 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill144, align 64
  %1132 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load703, 0
  %1133 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load703, 1
  %.splatinsert704 = insertelement <8 x i64> poison, i64 %1131, i64 0
  %.splat705 = shufflevector <8 x i64> %.splatinsert704, <8 x i64> poison, <8 x i32> zeroinitializer
  %1134 = mul <8 x i64> %.splat705, splat (i64 4)
  %1135 = add <8 x i64> %1133, %1134
  %1136 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1132, 0
  %1137 = insertvalue { <8 x ptr>, <8 x i64> } %1136, <8 x i64> %1135, 1
  %1138 = extractvalue { <8 x ptr>, <8 x i64> } %1137, 0
  %1139 = extractvalue { <8 x ptr>, <8 x i64> } %1137, 1
  %1140 = getelementptr i8, <8 x ptr> %1138, <8 x i64> %1139
  %1141 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1140, <8 x i1> %101, <8 x float> zeroinitializer)
  %.state706 = load <8 x float>, ptr %.slot165, align 32
  %1142 = fadd <8 x float> %.state706, %1141
  %.state707 = load i64, ptr %.slot164, align 4
  %1143 = add i64 %.state707, 1
  store i64 %1143, ptr %.slot164, align 4
  %1144 = load <8 x float>, ptr %.slot165, align 32
  %1145 = select <8 x i1> %101, <8 x float> %1142, <8 x float> %1144
  store <8 x float> %1145, ptr %.slot165, align 32
  br label %direct.schedule.70

direct.schedule.72:                               ; preds = %direct.false701
  store i64 0, ptr %.slot166, align 4
  %1146 = load <8 x float>, ptr %.slot167, align 32
  %1147 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %1146
  store <8 x float> %1147, ptr %.slot167, align 32
  br label %direct.schedule.73

direct.schedule.73:                               ; preds = %direct.schedule.74, %direct.schedule.72
  %.state708 = load i64, ptr %.slot166, align 4
  %1148 = icmp slt i64 %.state708, 16
  br i1 %1148, label %direct.true709, label %direct.false710

direct.schedule.74:                               ; preds = %direct.true709
  %.state711 = load i64, ptr %.slot166, align 4
  %1149 = sdiv i64 %.state711, 1
  %1150 = add i64 96, %1149
  %tile_snapshot.spill.load712 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill144, align 64
  %1151 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load712, 0
  %1152 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load712, 1
  %.splatinsert713 = insertelement <8 x i64> poison, i64 %1150, i64 0
  %.splat714 = shufflevector <8 x i64> %.splatinsert713, <8 x i64> poison, <8 x i32> zeroinitializer
  %1153 = mul <8 x i64> %.splat714, splat (i64 4)
  %1154 = add <8 x i64> %1152, %1153
  %1155 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1151, 0
  %1156 = insertvalue { <8 x ptr>, <8 x i64> } %1155, <8 x i64> %1154, 1
  %1157 = extractvalue { <8 x ptr>, <8 x i64> } %1156, 0
  %1158 = extractvalue { <8 x ptr>, <8 x i64> } %1156, 1
  %1159 = getelementptr i8, <8 x ptr> %1157, <8 x i64> %1158
  %1160 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1159, <8 x i1> %101, <8 x float> zeroinitializer)
  %.state715 = load <8 x float>, ptr %.slot167, align 32
  %1161 = fadd <8 x float> %.state715, %1160
  %.state716 = load i64, ptr %.slot166, align 4
  %1162 = add i64 %.state716, 1
  store i64 %1162, ptr %.slot166, align 4
  %1163 = load <8 x float>, ptr %.slot167, align 32
  %1164 = select <8 x i1> %101, <8 x float> %1161, <8 x float> %1163
  store <8 x float> %1164, ptr %.slot167, align 32
  br label %direct.schedule.73

direct.schedule.75:                               ; preds = %direct.false710
  store i64 0, ptr %.slot168, align 4
  %1165 = load <8 x float>, ptr %.slot169, align 32
  %1166 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %1165
  store <8 x float> %1166, ptr %.slot169, align 32
  br label %direct.schedule.76

direct.schedule.76:                               ; preds = %direct.schedule.77, %direct.schedule.75
  %.state717 = load i64, ptr %.slot168, align 4
  %1167 = icmp slt i64 %.state717, 16
  br i1 %1167, label %direct.true718, label %direct.false719

direct.schedule.77:                               ; preds = %direct.true718
  %.state720 = load i64, ptr %.slot168, align 4
  %1168 = sdiv i64 %.state720, 1
  %1169 = add i64 112, %1168
  %tile_snapshot.spill.load721 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill144, align 64
  %1170 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load721, 0
  %1171 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load721, 1
  %.splatinsert722 = insertelement <8 x i64> poison, i64 %1169, i64 0
  %.splat723 = shufflevector <8 x i64> %.splatinsert722, <8 x i64> poison, <8 x i32> zeroinitializer
  %1172 = mul <8 x i64> %.splat723, splat (i64 4)
  %1173 = add <8 x i64> %1171, %1172
  %1174 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1170, 0
  %1175 = insertvalue { <8 x ptr>, <8 x i64> } %1174, <8 x i64> %1173, 1
  %1176 = extractvalue { <8 x ptr>, <8 x i64> } %1175, 0
  %1177 = extractvalue { <8 x ptr>, <8 x i64> } %1175, 1
  %1178 = getelementptr i8, <8 x ptr> %1176, <8 x i64> %1177
  %1179 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1178, <8 x i1> %101, <8 x float> zeroinitializer)
  %.state724 = load <8 x float>, ptr %.slot169, align 32
  %1180 = fadd <8 x float> %.state724, %1179
  %.state725 = load i64, ptr %.slot168, align 4
  %1181 = add i64 %.state725, 1
  store i64 %1181, ptr %.slot168, align 4
  %1182 = load <8 x float>, ptr %.slot169, align 32
  %1183 = select <8 x i1> %101, <8 x float> %1180, <8 x float> %1182
  store <8 x float> %1183, ptr %.slot169, align 32
  br label %direct.schedule.76

direct.schedule.78:                               ; preds = %direct.false719
  %.spill.load726 = load <8 x float>, ptr %.spill146, align 32
  %.state727 = load <8 x float>, ptr %.slot155, align 32
  %1184 = fadd <8 x float> %.spill.load726, %.state727
  %1185 = load <8 x float>, ptr %.spill170, align 32
  %1186 = select <8 x i1> %101, <8 x float> %1184, <8 x float> %1185
  store <8 x float> %1186, ptr %.spill170, align 32
  %.spill.load728 = load <8 x float>, ptr %.spill147, align 32
  %.state729 = load <8 x float>, ptr %.slot157, align 32
  %1187 = fadd <8 x float> %.spill.load728, %.state729
  %1188 = load <8 x float>, ptr %.spill171, align 32
  %1189 = select <8 x i1> %101, <8 x float> %1187, <8 x float> %1188
  store <8 x float> %1189, ptr %.spill171, align 32
  %.spill.load730 = load <8 x float>, ptr %.spill148, align 32
  %.state731 = load <8 x float>, ptr %.slot159, align 32
  %1190 = fadd <8 x float> %.spill.load730, %.state731
  %1191 = load <8 x float>, ptr %.spill172, align 32
  %1192 = select <8 x i1> %101, <8 x float> %1190, <8 x float> %1191
  store <8 x float> %1192, ptr %.spill172, align 32
  %.spill.load732 = load <8 x float>, ptr %.spill149, align 32
  %.state733 = load <8 x float>, ptr %.slot161, align 32
  %1193 = fadd <8 x float> %.spill.load732, %.state733
  %1194 = load <8 x float>, ptr %.spill173, align 32
  %1195 = select <8 x i1> %101, <8 x float> %1193, <8 x float> %1194
  store <8 x float> %1195, ptr %.spill173, align 32
  %.spill.load734 = load <8 x float>, ptr %.spill150, align 32
  %.state735 = load <8 x float>, ptr %.slot163, align 32
  %1196 = fadd <8 x float> %.spill.load734, %.state735
  %1197 = load <8 x float>, ptr %.spill174, align 32
  %1198 = select <8 x i1> %101, <8 x float> %1196, <8 x float> %1197
  store <8 x float> %1198, ptr %.spill174, align 32
  %.spill.load736 = load <8 x float>, ptr %.spill151, align 32
  %.state737 = load <8 x float>, ptr %.slot165, align 32
  %1199 = fadd <8 x float> %.spill.load736, %.state737
  %1200 = load <8 x float>, ptr %.spill175, align 32
  %1201 = select <8 x i1> %101, <8 x float> %1199, <8 x float> %1200
  store <8 x float> %1201, ptr %.spill175, align 32
  %.spill.load738 = load <8 x float>, ptr %.spill152, align 32
  %.state739 = load <8 x float>, ptr %.slot167, align 32
  %1202 = fadd <8 x float> %.spill.load738, %.state739
  %1203 = load <8 x float>, ptr %.spill176, align 32
  %1204 = select <8 x i1> %101, <8 x float> %1202, <8 x float> %1203
  store <8 x float> %1204, ptr %.spill176, align 32
  %.spill.load740 = load <8 x float>, ptr %.spill153, align 32
  %.state741 = load <8 x float>, ptr %.slot169, align 32
  %1205 = fadd <8 x float> %.spill.load740, %.state741
  %1206 = load <8 x float>, ptr %.spill177, align 32
  %1207 = select <8 x i1> %101, <8 x float> %1205, <8 x float> %1206
  store <8 x float> %1207, ptr %.spill177, align 32
  %1208 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill178, align 64
  %1209 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %1210 = extractvalue { <8 x ptr>, <8 x i64> } %1208, 0
  %1211 = select <8 x i1> %101, <8 x ptr> %1209, <8 x ptr> %1210
  %1212 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %1213 = extractvalue { <8 x ptr>, <8 x i64> } %1208, 1
  %1214 = select <8 x i1> %101, <8 x i64> %1212, <8 x i64> %1213
  %1215 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1211, 0
  %1216 = insertvalue { <8 x ptr>, <8 x i64> } %1215, <8 x i64> %1214, 1
  store { <8 x ptr>, <8 x i64> } %1216, ptr %tile_snapshot.spill178, align 64
  store i64 0, ptr %.slot179, align 4
  br label %direct.schedule.79

direct.schedule.79:                               ; preds = %direct.schedule.80, %direct.schedule.78
  %.state742 = load i64, ptr %.slot179, align 4
  %1217 = icmp slt i64 %.state742, 384
  br i1 %1217, label %direct.true743, label %direct.false744

direct.schedule.80:                               ; preds = %direct.true743
  %.state745 = load i64, ptr %.slot179, align 4
  %1218 = srem i64 %.state745, 48
  %.state746 = load i64, ptr %.slot179, align 4
  %1219 = sdiv i64 %.state746, 48
  %1220 = add i64 0, %1219
  %1221 = mul i64 %1220, 48
  %1222 = add i64 %1221, %1218
  %tile_snapshot.spill.load747 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill71, align 64
  %1223 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load747, 0
  %1224 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load747, 1
  %.splatinsert748 = insertelement <8 x i64> poison, i64 %1222, i64 0
  %.splat749 = shufflevector <8 x i64> %.splatinsert748, <8 x i64> poison, <8 x i32> zeroinitializer
  %1225 = mul <8 x i64> %.splat749, splat (i64 32)
  %1226 = add <8 x i64> %1224, %1225
  %1227 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1223, 0
  %1228 = insertvalue { <8 x ptr>, <8 x i64> } %1227, <8 x i64> %1226, 1
  %1229 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1230 = extractvalue { <8 x ptr>, <8 x i64> } %1228, 1
  %1231 = extractelement <8 x ptr> %1229, i32 0
  %1232 = extractelement <8 x i64> %1230, i32 0
  %1233 = sub i64 %1232, 0
  %1234 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1235 = select i1 %1234, i64 %1233, i64 0
  %private.contiguous.address750 = getelementptr i8, ptr %1231, i64 %1235
  %private.contiguous.load751 = load <8 x float>, ptr %private.contiguous.address750, align 4
  %1236 = select <8 x i1> %101, <8 x float> %private.contiguous.load751, <8 x float> zeroinitializer
  %tile_snapshot.spill.load752 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill143, align 64
  %1237 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load752, 0
  %1238 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load752, 1
  %.splatinsert753 = insertelement <8 x i64> poison, i64 %1220, i64 0
  %.splat754 = shufflevector <8 x i64> %.splatinsert753, <8 x i64> poison, <8 x i32> zeroinitializer
  %1239 = mul <8 x i64> %.splat754, splat (i64 32)
  %1240 = add <8 x i64> %1238, %1239
  %1241 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1237, 0
  %1242 = insertvalue { <8 x ptr>, <8 x i64> } %1241, <8 x i64> %1240, 1
  %1243 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %1244 = extractvalue { <8 x ptr>, <8 x i64> } %1242, 1
  %1245 = extractelement <8 x ptr> %1243, i32 0
  %1246 = extractelement <8 x i64> %1244, i32 0
  %1247 = sub i64 %1246, 0
  %1248 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1249 = select i1 %1248, i64 %1247, i64 0
  %private.contiguous.address755 = getelementptr i8, ptr %1245, i64 %1249
  %private.contiguous.load756 = load <8 x float>, ptr %private.contiguous.address755, align 4
  %1250 = select <8 x i1> %101, <8 x float> %private.contiguous.load756, <8 x float> zeroinitializer
  %1251 = fmul <8 x float> %1236, %1250
  %tile_snapshot.spill.load757 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill178, align 64
  %1252 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load757, 0
  %1253 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load757, 1
  %.state758 = load i64, ptr %.slot179, align 4
  %.splatinsert759 = insertelement <8 x i64> poison, i64 %.state758, i64 0
  %.splat760 = shufflevector <8 x i64> %.splatinsert759, <8 x i64> poison, <8 x i32> zeroinitializer
  %1254 = mul <8 x i64> %.splat760, splat (i64 4)
  %1255 = add <8 x i64> %1253, %1254
  %1256 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1252, 0
  %1257 = insertvalue { <8 x ptr>, <8 x i64> } %1256, <8 x i64> %1255, 1
  %1258 = extractvalue { <8 x ptr>, <8 x i64> } %1257, 0
  %1259 = extractvalue { <8 x ptr>, <8 x i64> } %1257, 1
  %1260 = getelementptr i8, <8 x ptr> %1258, <8 x i64> %1259
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1251, <8 x ptr> align 1 %1260, <8 x i1> %101)
  %.state761 = load i64, ptr %.slot179, align 4
  %1261 = add i64 %.state761, 1
  store i64 %1261, ptr %.slot179, align 4
  br label %direct.schedule.79

direct.schedule.81:                               ; preds = %direct.false744
  %1262 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill180, align 64
  %1263 = extractvalue { <8 x ptr>, <8 x i64> } %50, 0
  %1264 = extractvalue { <8 x ptr>, <8 x i64> } %1262, 0
  %1265 = select <8 x i1> %101, <8 x ptr> %1263, <8 x ptr> %1264
  %1266 = extractvalue { <8 x ptr>, <8 x i64> } %50, 1
  %1267 = extractvalue { <8 x ptr>, <8 x i64> } %1262, 1
  %1268 = select <8 x i1> %101, <8 x i64> %1266, <8 x i64> %1267
  %1269 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1265, 0
  %1270 = insertvalue { <8 x ptr>, <8 x i64> } %1269, <8 x i64> %1268, 1
  store { <8 x ptr>, <8 x i64> } %1270, ptr %tile_snapshot.spill180, align 64
  %tile_snapshot.spill.load762 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill144, align 64
  %tile_snapshot.spill.load763 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill96, align 64
  %tile_snapshot.spill.load764 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill178, align 64
  %1271 = extractelement <8 x i1> %101, i64 0
  br i1 %1271, label %mma.active765, label %mma.continue766

direct.schedule.82:                               ; preds = %mma.continue780, %direct.schedule.83
  %.state781 = load i64, ptr %.slot181, align 4
  %1272 = icmp slt i64 %.state781, 384
  br i1 %1272, label %direct.true782, label %direct.false783

direct.schedule.83:                               ; preds = %direct.true782
  %tile_snapshot.spill.load784 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill180, align 64
  %1273 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load784, 0
  %1274 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load784, 1
  %.state785 = load i64, ptr %.slot181, align 4
  %.splatinsert786 = insertelement <8 x i64> poison, i64 %.state785, i64 0
  %.splat787 = shufflevector <8 x i64> %.splatinsert786, <8 x i64> poison, <8 x i32> zeroinitializer
  %1275 = mul <8 x i64> %.splat787, splat (i64 4)
  %1276 = add <8 x i64> %1274, %1275
  %1277 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1273, 0
  %1278 = insertvalue { <8 x ptr>, <8 x i64> } %1277, <8 x i64> %1276, 1
  %1279 = extractvalue { <8 x ptr>, <8 x i64> } %1278, 0
  %1280 = extractvalue { <8 x ptr>, <8 x i64> } %1278, 1
  %1281 = getelementptr i8, <8 x ptr> %1279, <8 x i64> %1280
  %1282 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1281, <8 x i1> %101, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load788 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill72, align 64
  %1283 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load788, 0
  %1284 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load788, 1
  %.state789 = load i64, ptr %.slot181, align 4
  %.splatinsert790 = insertelement <8 x i64> poison, i64 %.state789, i64 0
  %.splat791 = shufflevector <8 x i64> %.splatinsert790, <8 x i64> poison, <8 x i32> zeroinitializer
  %1285 = mul <8 x i64> %.splat791, splat (i64 32)
  %1286 = add <8 x i64> %1284, %1285
  %1287 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1283, 0
  %1288 = insertvalue { <8 x ptr>, <8 x i64> } %1287, <8 x i64> %1286, 1
  %1289 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1290 = extractvalue { <8 x ptr>, <8 x i64> } %1288, 1
  %1291 = extractelement <8 x ptr> %1289, i32 0
  %1292 = extractelement <8 x i64> %1290, i32 0
  %1293 = sub i64 %1292, 0
  %1294 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1295 = select i1 %1294, i64 %1293, i64 0
  %private.contiguous.address792 = getelementptr i8, ptr %1291, i64 %1295
  %private.contiguous.preserve793 = load <8 x float>, ptr %private.contiguous.address792, align 4
  %1296 = select <8 x i1> %101, <8 x float> %1282, <8 x float> %private.contiguous.preserve793
  store <8 x float> %1296, ptr %private.contiguous.address792, align 4
  %.state794 = load i64, ptr %.slot181, align 4
  %1297 = add i64 %.state794, 1
  store i64 %1297, ptr %.slot181, align 4
  br label %direct.schedule.82

direct.schedule.84:                               ; preds = %direct.false783
  store i64 0, ptr %.slot182, align 4
  br label %direct.schedule.85

direct.schedule.85:                               ; preds = %direct.schedule.86, %direct.schedule.84
  %.state795 = load i64, ptr %.slot182, align 4
  %1298 = icmp slt i64 %.state795, 384
  br i1 %1298, label %direct.true796, label %direct.false797

direct.schedule.86:                               ; preds = %direct.true796
  %tile_snapshot.spill.load798 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill72, align 64
  %1299 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load798, 0
  %1300 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load798, 1
  %.state799 = load i64, ptr %.slot182, align 4
  %.splatinsert800 = insertelement <8 x i64> poison, i64 %.state799, i64 0
  %.splat801 = shufflevector <8 x i64> %.splatinsert800, <8 x i64> poison, <8 x i32> zeroinitializer
  %1301 = mul <8 x i64> %.splat801, splat (i64 32)
  %1302 = add <8 x i64> %1300, %1301
  %1303 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1299, 0
  %1304 = insertvalue { <8 x ptr>, <8 x i64> } %1303, <8 x i64> %1302, 1
  %1305 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1306 = extractvalue { <8 x ptr>, <8 x i64> } %1304, 1
  %1307 = extractelement <8 x ptr> %1305, i32 0
  %1308 = extractelement <8 x i64> %1306, i32 0
  %1309 = sub i64 %1308, 0
  %1310 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1311 = select i1 %1310, i64 %1309, i64 0
  %private.contiguous.address802 = getelementptr i8, ptr %1307, i64 %1311
  %private.contiguous.load803 = load <8 x float>, ptr %private.contiguous.address802, align 4
  %1312 = select <8 x i1> %101, <8 x float> %private.contiguous.load803, <8 x float> zeroinitializer
  %tile_snapshot.spill.load804 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill71, align 64
  %1313 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load804, 0
  %1314 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load804, 1
  %.state805 = load i64, ptr %.slot182, align 4
  %.splatinsert806 = insertelement <8 x i64> poison, i64 %.state805, i64 0
  %.splat807 = shufflevector <8 x i64> %.splatinsert806, <8 x i64> poison, <8 x i32> zeroinitializer
  %1315 = mul <8 x i64> %.splat807, splat (i64 32)
  %1316 = add <8 x i64> %1314, %1315
  %1317 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1313, 0
  %1318 = insertvalue { <8 x ptr>, <8 x i64> } %1317, <8 x i64> %1316, 1
  %1319 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1320 = extractvalue { <8 x ptr>, <8 x i64> } %1318, 1
  %1321 = extractelement <8 x ptr> %1319, i32 0
  %1322 = extractelement <8 x i64> %1320, i32 0
  %1323 = sub i64 %1322, 0
  %1324 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1325 = select i1 %1324, i64 %1323, i64 0
  %private.contiguous.address808 = getelementptr i8, ptr %1321, i64 %1325
  %private.contiguous.preserve809 = load <8 x float>, ptr %private.contiguous.address808, align 4
  %1326 = select <8 x i1> %101, <8 x float> %1312, <8 x float> %private.contiguous.preserve809
  store <8 x float> %1326, ptr %private.contiguous.address808, align 4
  %.state810 = load i64, ptr %.slot182, align 4
  %1327 = add i64 %.state810, 1
  store i64 %1327, ptr %.slot182, align 4
  br label %direct.schedule.85

direct.schedule.87:                               ; preds = %direct.false797
  %.state811 = load i64, ptr %.slot74, align 4
  %1328 = add i64 %.state811, 1
  %.spill.load812 = load <8 x float>, ptr %.spill126, align 32
  %.spill.load813 = load <8 x float>, ptr %.spill127, align 32
  %.spill.load814 = load <8 x float>, ptr %.spill128, align 32
  %.spill.load815 = load <8 x float>, ptr %.spill129, align 32
  %.spill.load816 = load <8 x float>, ptr %.spill130, align 32
  %.spill.load817 = load <8 x float>, ptr %.spill131, align 32
  %.spill.load818 = load <8 x float>, ptr %.spill132, align 32
  %.spill.load819 = load <8 x float>, ptr %.spill133, align 32
  %.spill.load820 = load <8 x float>, ptr %.spill170, align 32
  %.spill.load821 = load <8 x float>, ptr %.spill171, align 32
  %.spill.load822 = load <8 x float>, ptr %.spill172, align 32
  %.spill.load823 = load <8 x float>, ptr %.spill173, align 32
  %.spill.load824 = load <8 x float>, ptr %.spill174, align 32
  %.spill.load825 = load <8 x float>, ptr %.spill175, align 32
  %.spill.load826 = load <8 x float>, ptr %.spill176, align 32
  %.spill.load827 = load <8 x float>, ptr %.spill177, align 32
  store i64 %1328, ptr %.slot74, align 4
  %1329 = load <8 x float>, ptr %.slot75, align 32
  %1330 = select <8 x i1> %101, <8 x float> %.spill.load812, <8 x float> %1329
  store <8 x float> %1330, ptr %.slot75, align 32
  %1331 = load <8 x float>, ptr %.slot76, align 32
  %1332 = select <8 x i1> %101, <8 x float> %.spill.load813, <8 x float> %1331
  store <8 x float> %1332, ptr %.slot76, align 32
  %1333 = load <8 x float>, ptr %.slot77, align 32
  %1334 = select <8 x i1> %101, <8 x float> %.spill.load814, <8 x float> %1333
  store <8 x float> %1334, ptr %.slot77, align 32
  %1335 = load <8 x float>, ptr %.slot78, align 32
  %1336 = select <8 x i1> %101, <8 x float> %.spill.load815, <8 x float> %1335
  store <8 x float> %1336, ptr %.slot78, align 32
  %1337 = load <8 x float>, ptr %.slot79, align 32
  %1338 = select <8 x i1> %101, <8 x float> %.spill.load816, <8 x float> %1337
  store <8 x float> %1338, ptr %.slot79, align 32
  %1339 = load <8 x float>, ptr %.slot80, align 32
  %1340 = select <8 x i1> %101, <8 x float> %.spill.load817, <8 x float> %1339
  store <8 x float> %1340, ptr %.slot80, align 32
  %1341 = load <8 x float>, ptr %.slot81, align 32
  %1342 = select <8 x i1> %101, <8 x float> %.spill.load818, <8 x float> %1341
  store <8 x float> %1342, ptr %.slot81, align 32
  %1343 = load <8 x float>, ptr %.slot82, align 32
  %1344 = select <8 x i1> %101, <8 x float> %.spill.load819, <8 x float> %1343
  store <8 x float> %1344, ptr %.slot82, align 32
  %1345 = load <8 x float>, ptr %.slot83, align 32
  %1346 = select <8 x i1> %101, <8 x float> %.spill.load820, <8 x float> %1345
  store <8 x float> %1346, ptr %.slot83, align 32
  %1347 = load <8 x float>, ptr %.slot84, align 32
  %1348 = select <8 x i1> %101, <8 x float> %.spill.load821, <8 x float> %1347
  store <8 x float> %1348, ptr %.slot84, align 32
  %1349 = load <8 x float>, ptr %.slot85, align 32
  %1350 = select <8 x i1> %101, <8 x float> %.spill.load822, <8 x float> %1349
  store <8 x float> %1350, ptr %.slot85, align 32
  %1351 = load <8 x float>, ptr %.slot86, align 32
  %1352 = select <8 x i1> %101, <8 x float> %.spill.load823, <8 x float> %1351
  store <8 x float> %1352, ptr %.slot86, align 32
  %1353 = load <8 x float>, ptr %.slot87, align 32
  %1354 = select <8 x i1> %101, <8 x float> %.spill.load824, <8 x float> %1353
  store <8 x float> %1354, ptr %.slot87, align 32
  %1355 = load <8 x float>, ptr %.slot88, align 32
  %1356 = select <8 x i1> %101, <8 x float> %.spill.load825, <8 x float> %1355
  store <8 x float> %1356, ptr %.slot88, align 32
  %1357 = load <8 x float>, ptr %.slot89, align 32
  %1358 = select <8 x i1> %101, <8 x float> %.spill.load826, <8 x float> %1357
  store <8 x float> %1358, ptr %.slot89, align 32
  %1359 = load <8 x float>, ptr %.slot90, align 32
  %1360 = select <8 x i1> %101, <8 x float> %.spill.load827, <8 x float> %1359
  store <8 x float> %1360, ptr %.slot90, align 32
  br label %direct.schedule.7

direct.schedule.88:                               ; preds = %direct.false216
  %1361 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill183, align 64
  %1362 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1363 = extractvalue { <8 x ptr>, <8 x i64> } %1361, 0
  %1364 = select <8 x i1> %101, <8 x ptr> %1362, <8 x ptr> %1363
  %1365 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %1366 = extractvalue { <8 x ptr>, <8 x i64> } %1361, 1
  %1367 = select <8 x i1> %101, <8 x i64> %1365, <8 x i64> %1366
  %1368 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1364, 0
  %1369 = insertvalue { <8 x ptr>, <8 x i64> } %1368, <8 x i64> %1367, 1
  store { <8 x ptr>, <8 x i64> } %1369, ptr %tile_snapshot.spill183, align 64
  %1370 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1371 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %1372 = add <8 x i64> %1371, zeroinitializer
  %1373 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1370, 0
  %1374 = insertvalue { <8 x ptr>, <8 x i64> } %1373, <8 x i64> %1372, 1
  %.state828 = load <8 x float>, ptr %.slot83, align 32
  %1375 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1376 = extractvalue { <8 x ptr>, <8 x i64> } %1374, 1
  %1377 = extractelement <8 x ptr> %1375, i32 0
  %1378 = extractelement <8 x i64> %1376, i32 0
  %1379 = sub i64 %1378, 0
  %1380 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1381 = select i1 %1380, i64 %1379, i64 0
  %private.contiguous.address829 = getelementptr i8, ptr %1377, i64 %1381
  %private.contiguous.preserve830 = load <8 x float>, ptr %private.contiguous.address829, align 4
  %1382 = select <8 x i1> %101, <8 x float> %.state828, <8 x float> %private.contiguous.preserve830
  store <8 x float> %1382, ptr %private.contiguous.address829, align 4
  %1383 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1384 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %1385 = add <8 x i64> %1384, splat (i64 32)
  %1386 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1383, 0
  %1387 = insertvalue { <8 x ptr>, <8 x i64> } %1386, <8 x i64> %1385, 1
  %.state831 = load <8 x float>, ptr %.slot84, align 32
  %1388 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1389 = extractvalue { <8 x ptr>, <8 x i64> } %1387, 1
  %1390 = extractelement <8 x ptr> %1388, i32 0
  %1391 = extractelement <8 x i64> %1389, i32 0
  %1392 = sub i64 %1391, 0
  %1393 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1394 = select i1 %1393, i64 %1392, i64 0
  %private.contiguous.address832 = getelementptr i8, ptr %1390, i64 %1394
  %private.contiguous.preserve833 = load <8 x float>, ptr %private.contiguous.address832, align 4
  %1395 = select <8 x i1> %101, <8 x float> %.state831, <8 x float> %private.contiguous.preserve833
  store <8 x float> %1395, ptr %private.contiguous.address832, align 4
  %1396 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1397 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %1398 = add <8 x i64> %1397, splat (i64 64)
  %1399 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1396, 0
  %1400 = insertvalue { <8 x ptr>, <8 x i64> } %1399, <8 x i64> %1398, 1
  %.state834 = load <8 x float>, ptr %.slot85, align 32
  %1401 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1402 = extractvalue { <8 x ptr>, <8 x i64> } %1400, 1
  %1403 = extractelement <8 x ptr> %1401, i32 0
  %1404 = extractelement <8 x i64> %1402, i32 0
  %1405 = sub i64 %1404, 0
  %1406 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1407 = select i1 %1406, i64 %1405, i64 0
  %private.contiguous.address835 = getelementptr i8, ptr %1403, i64 %1407
  %private.contiguous.preserve836 = load <8 x float>, ptr %private.contiguous.address835, align 4
  %1408 = select <8 x i1> %101, <8 x float> %.state834, <8 x float> %private.contiguous.preserve836
  store <8 x float> %1408, ptr %private.contiguous.address835, align 4
  %1409 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1410 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %1411 = add <8 x i64> %1410, splat (i64 96)
  %1412 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1409, 0
  %1413 = insertvalue { <8 x ptr>, <8 x i64> } %1412, <8 x i64> %1411, 1
  %.state837 = load <8 x float>, ptr %.slot86, align 32
  %1414 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1415 = extractvalue { <8 x ptr>, <8 x i64> } %1413, 1
  %1416 = extractelement <8 x ptr> %1414, i32 0
  %1417 = extractelement <8 x i64> %1415, i32 0
  %1418 = sub i64 %1417, 0
  %1419 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1420 = select i1 %1419, i64 %1418, i64 0
  %private.contiguous.address838 = getelementptr i8, ptr %1416, i64 %1420
  %private.contiguous.preserve839 = load <8 x float>, ptr %private.contiguous.address838, align 4
  %1421 = select <8 x i1> %101, <8 x float> %.state837, <8 x float> %private.contiguous.preserve839
  store <8 x float> %1421, ptr %private.contiguous.address838, align 4
  %1422 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1423 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %1424 = add <8 x i64> %1423, splat (i64 128)
  %1425 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1422, 0
  %1426 = insertvalue { <8 x ptr>, <8 x i64> } %1425, <8 x i64> %1424, 1
  %.state840 = load <8 x float>, ptr %.slot87, align 32
  %1427 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1428 = extractvalue { <8 x ptr>, <8 x i64> } %1426, 1
  %1429 = extractelement <8 x ptr> %1427, i32 0
  %1430 = extractelement <8 x i64> %1428, i32 0
  %1431 = sub i64 %1430, 0
  %1432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1433 = select i1 %1432, i64 %1431, i64 0
  %private.contiguous.address841 = getelementptr i8, ptr %1429, i64 %1433
  %private.contiguous.preserve842 = load <8 x float>, ptr %private.contiguous.address841, align 4
  %1434 = select <8 x i1> %101, <8 x float> %.state840, <8 x float> %private.contiguous.preserve842
  store <8 x float> %1434, ptr %private.contiguous.address841, align 4
  %1435 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1436 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %1437 = add <8 x i64> %1436, splat (i64 160)
  %1438 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1435, 0
  %1439 = insertvalue { <8 x ptr>, <8 x i64> } %1438, <8 x i64> %1437, 1
  %.state843 = load <8 x float>, ptr %.slot88, align 32
  %1440 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1441 = extractvalue { <8 x ptr>, <8 x i64> } %1439, 1
  %1442 = extractelement <8 x ptr> %1440, i32 0
  %1443 = extractelement <8 x i64> %1441, i32 0
  %1444 = sub i64 %1443, 0
  %1445 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1446 = select i1 %1445, i64 %1444, i64 0
  %private.contiguous.address844 = getelementptr i8, ptr %1442, i64 %1446
  %private.contiguous.preserve845 = load <8 x float>, ptr %private.contiguous.address844, align 4
  %1447 = select <8 x i1> %101, <8 x float> %.state843, <8 x float> %private.contiguous.preserve845
  store <8 x float> %1447, ptr %private.contiguous.address844, align 4
  %1448 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1449 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %1450 = add <8 x i64> %1449, splat (i64 192)
  %1451 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1448, 0
  %1452 = insertvalue { <8 x ptr>, <8 x i64> } %1451, <8 x i64> %1450, 1
  %.state846 = load <8 x float>, ptr %.slot89, align 32
  %1453 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1454 = extractvalue { <8 x ptr>, <8 x i64> } %1452, 1
  %1455 = extractelement <8 x ptr> %1453, i32 0
  %1456 = extractelement <8 x i64> %1454, i32 0
  %1457 = sub i64 %1456, 0
  %1458 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1459 = select i1 %1458, i64 %1457, i64 0
  %private.contiguous.address847 = getelementptr i8, ptr %1455, i64 %1459
  %private.contiguous.preserve848 = load <8 x float>, ptr %private.contiguous.address847, align 4
  %1460 = select <8 x i1> %101, <8 x float> %.state846, <8 x float> %private.contiguous.preserve848
  store <8 x float> %1460, ptr %private.contiguous.address847, align 4
  %1461 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1462 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %1463 = add <8 x i64> %1462, splat (i64 224)
  %1464 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1461, 0
  %1465 = insertvalue { <8 x ptr>, <8 x i64> } %1464, <8 x i64> %1463, 1
  %.state849 = load <8 x float>, ptr %.slot90, align 32
  %1466 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1467 = extractvalue { <8 x ptr>, <8 x i64> } %1465, 1
  %1468 = extractelement <8 x ptr> %1466, i32 0
  %1469 = extractelement <8 x i64> %1467, i32 0
  %1470 = sub i64 %1469, 0
  %1471 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1472 = select i1 %1471, i64 %1470, i64 0
  %private.contiguous.address850 = getelementptr i8, ptr %1468, i64 %1472
  %private.contiguous.preserve851 = load <8 x float>, ptr %private.contiguous.address850, align 4
  %1473 = select <8 x i1> %101, <8 x float> %.state849, <8 x float> %private.contiguous.preserve851
  store <8 x float> %1473, ptr %private.contiguous.address850, align 4
  store i64 0, ptr %.slot184, align 4
  br label %direct.schedule.89

direct.schedule.89:                               ; preds = %direct.schedule.90, %direct.schedule.88
  %.state852 = load i64, ptr %.slot184, align 4
  %1474 = icmp slt i64 %.state852, 384
  br i1 %1474, label %direct.true853, label %direct.false854

direct.schedule.90:                               ; preds = %direct.true853
  %.state855 = load i64, ptr %.slot184, align 4
  %1475 = srem i64 %.state855, 48
  %.state856 = load i64, ptr %.slot184, align 4
  %1476 = sdiv i64 %.state856, 48
  %.spill.load857 = load <8 x i64>, ptr %.spill, align 64
  %1477 = add <8 x i64> %.spill.load857, zeroinitializer
  %1478 = add <8 x i64> zeroinitializer, %1477
  %.spill.load858 = load <8 x i64>, ptr %.spill69, align 64
  %.splatinsert859 = insertelement <8 x i64> poison, i64 %1476, i64 0
  %.splat860 = shufflevector <8 x i64> %.splatinsert859, <8 x i64> poison, <8 x i32> zeroinitializer
  %1479 = add <8 x i64> %.spill.load858, %.splat860
  %1480 = mul <8 x i64> %1478, splat (i64 64)
  %1481 = add <8 x i64> %1480, %1479
  %1482 = add i64 0, %1475
  %1483 = mul <8 x i64> %1481, splat (i64 48)
  %.splatinsert861 = insertelement <8 x i64> poison, i64 %1482, i64 0
  %.splat862 = shufflevector <8 x i64> %.splatinsert861, <8 x i64> poison, <8 x i32> zeroinitializer
  %1484 = add <8 x i64> %1483, %.splat862
  %1485 = add i64 0, %1476
  %1486 = mul i64 %1485, 48
  %1487 = add i64 %1486, %1475
  %tile_snapshot.spill.load863 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill71, align 64
  %1488 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load863, 0
  %1489 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load863, 1
  %.splatinsert864 = insertelement <8 x i64> poison, i64 %1487, i64 0
  %.splat865 = shufflevector <8 x i64> %.splatinsert864, <8 x i64> poison, <8 x i32> zeroinitializer
  %1490 = mul <8 x i64> %.splat865, splat (i64 32)
  %1491 = add <8 x i64> %1489, %1490
  %1492 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1488, 0
  %1493 = insertvalue { <8 x ptr>, <8 x i64> } %1492, <8 x i64> %1491, 1
  %1494 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1495 = extractvalue { <8 x ptr>, <8 x i64> } %1493, 1
  %1496 = extractelement <8 x ptr> %1494, i32 0
  %1497 = extractelement <8 x i64> %1495, i32 0
  %1498 = sub i64 %1497, 0
  %1499 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1500 = select i1 %1499, i64 %1498, i64 0
  %private.contiguous.address866 = getelementptr i8, ptr %1496, i64 %1500
  %private.contiguous.load867 = load <8 x float>, ptr %private.contiguous.address866, align 4
  %1501 = select <8 x i1> %101, <8 x float> %private.contiguous.load867, <8 x float> zeroinitializer
  %tile_snapshot.spill.load868 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill183, align 64
  %1502 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load868, 0
  %1503 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load868, 1
  %.splatinsert869 = insertelement <8 x i64> poison, i64 %1485, i64 0
  %.splat870 = shufflevector <8 x i64> %.splatinsert869, <8 x i64> poison, <8 x i32> zeroinitializer
  %1504 = mul <8 x i64> %.splat870, splat (i64 32)
  %1505 = add <8 x i64> %1503, %1504
  %1506 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1502, 0
  %1507 = insertvalue { <8 x ptr>, <8 x i64> } %1506, <8 x i64> %1505, 1
  %1508 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %1509 = extractvalue { <8 x ptr>, <8 x i64> } %1507, 1
  %1510 = extractelement <8 x ptr> %1508, i32 0
  %1511 = extractelement <8 x i64> %1509, i32 0
  %1512 = sub i64 %1511, 0
  %1513 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1514 = select i1 %1513, i64 %1512, i64 0
  %private.contiguous.address871 = getelementptr i8, ptr %1510, i64 %1514
  %private.contiguous.load872 = load <8 x float>, ptr %private.contiguous.address871, align 4
  %1515 = select <8 x i1> %101, <8 x float> %private.contiguous.load872, <8 x float> zeroinitializer
  %1516 = fdiv <8 x float> %1501, %1515
  %1517 = extractvalue { ptr, i64 } %77, 0
  %1518 = mul <8 x i64> %1484, splat (i64 4)
  %1519 = getelementptr i8, ptr %1517, <8 x i64> %1518
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1516, <8 x ptr> align 1 %1519, <8 x i1> %101)
  %.state873 = load i64, ptr %.slot184, align 4
  %1520 = add i64 %.state873, 1
  store i64 %1520, ptr %.slot184, align 4
  br label %direct.schedule.89

direct.schedule.91:                               ; preds = %direct.false854
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true207:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false208:                                  ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true215:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false216:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.88

direct.true219:                                   ; preds = %direct.schedule.9
  br label %direct.schedule.10

direct.false220:                                  ; preds = %direct.schedule.9
  br label %direct.schedule.13

direct.true229:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false230:                                  ; preds = %direct.schedule.10
  %1521 = load <8 x float>, ptr %.slot95, align 32
  %1522 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %1521
  store <8 x float> %1522, ptr %.slot95, align 32
  br label %direct.schedule.12

direct.true241:                                   ; preds = %direct.schedule.14
  br label %direct.schedule.15

direct.false242:                                  ; preds = %direct.schedule.14
  br label %direct.schedule.18

direct.true251:                                   ; preds = %direct.schedule.15
  br label %direct.schedule.16

direct.false252:                                  ; preds = %direct.schedule.15
  %1523 = load <8 x float>, ptr %.slot99, align 32
  %1524 = select <8 x i1> %101, <8 x float> zeroinitializer, <8 x float> %1523
  store <8 x float> %1524, ptr %.slot99, align 32
  br label %direct.schedule.17

direct.true263:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false264:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

mma.active:                                       ; preds = %direct.schedule.21
  %1525 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 0
  %1526 = extractelement <8 x ptr> %1525, i64 0
  %1527 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 1
  %1528 = extractelement <8 x i64> %1527, i64 0
  %1529 = getelementptr i8, ptr %1526, i64 %1528
  %1530 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 0
  %1531 = extractelement <8 x ptr> %1530, i64 0
  %1532 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 1
  %1533 = extractelement <8 x i64> %1532, i64 0
  %1534 = getelementptr i8, ptr %1531, i64 %1533
  %1535 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 0
  %1536 = extractelement <8 x ptr> %1535, i64 0
  %1537 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 1
  %1538 = extractelement <8 x i64> %1537, i64 0
  %1539 = getelementptr i8, ptr %1536, i64 %1538
  %1540 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1541 = extractelement <8 x ptr> %1540, i64 0
  %1542 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1543 = extractelement <8 x i64> %1542, i64 0
  %1544 = getelementptr i8, ptr %1541, i64 %1543
  call void @llm_attention.strided_mma(ptr %1529, ptr %1534, ptr %1539, ptr %1544)
  br label %mma.continue

mma.continue:                                     ; preds = %mma.active, %direct.schedule.21
  %1545 = extractelement <8 x i1> %101, i64 1
  br i1 %1545, label %mma.active273, label %mma.continue274

mma.active273:                                    ; preds = %mma.continue
  %1546 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 0
  %1547 = extractelement <8 x ptr> %1546, i64 1
  %1548 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 1
  %1549 = extractelement <8 x i64> %1548, i64 1
  %1550 = getelementptr i8, ptr %1547, i64 %1549
  %1551 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 0
  %1552 = extractelement <8 x ptr> %1551, i64 1
  %1553 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 1
  %1554 = extractelement <8 x i64> %1553, i64 1
  %1555 = getelementptr i8, ptr %1552, i64 %1554
  %1556 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 0
  %1557 = extractelement <8 x ptr> %1556, i64 1
  %1558 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 1
  %1559 = extractelement <8 x i64> %1558, i64 1
  %1560 = getelementptr i8, ptr %1557, i64 %1559
  %1561 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1562 = extractelement <8 x ptr> %1561, i64 1
  %1563 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1564 = extractelement <8 x i64> %1563, i64 1
  %1565 = getelementptr i8, ptr %1562, i64 %1564
  call void @llm_attention.strided_mma(ptr %1550, ptr %1555, ptr %1560, ptr %1565)
  br label %mma.continue274

mma.continue274:                                  ; preds = %mma.active273, %mma.continue
  %1566 = extractelement <8 x i1> %101, i64 2
  br i1 %1566, label %mma.active275, label %mma.continue276

mma.active275:                                    ; preds = %mma.continue274
  %1567 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 0
  %1568 = extractelement <8 x ptr> %1567, i64 2
  %1569 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 1
  %1570 = extractelement <8 x i64> %1569, i64 2
  %1571 = getelementptr i8, ptr %1568, i64 %1570
  %1572 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 0
  %1573 = extractelement <8 x ptr> %1572, i64 2
  %1574 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 1
  %1575 = extractelement <8 x i64> %1574, i64 2
  %1576 = getelementptr i8, ptr %1573, i64 %1575
  %1577 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 0
  %1578 = extractelement <8 x ptr> %1577, i64 2
  %1579 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 1
  %1580 = extractelement <8 x i64> %1579, i64 2
  %1581 = getelementptr i8, ptr %1578, i64 %1580
  %1582 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1583 = extractelement <8 x ptr> %1582, i64 2
  %1584 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1585 = extractelement <8 x i64> %1584, i64 2
  %1586 = getelementptr i8, ptr %1583, i64 %1585
  call void @llm_attention.strided_mma(ptr %1571, ptr %1576, ptr %1581, ptr %1586)
  br label %mma.continue276

mma.continue276:                                  ; preds = %mma.active275, %mma.continue274
  %1587 = extractelement <8 x i1> %101, i64 3
  br i1 %1587, label %mma.active277, label %mma.continue278

mma.active277:                                    ; preds = %mma.continue276
  %1588 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 0
  %1589 = extractelement <8 x ptr> %1588, i64 3
  %1590 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 1
  %1591 = extractelement <8 x i64> %1590, i64 3
  %1592 = getelementptr i8, ptr %1589, i64 %1591
  %1593 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 0
  %1594 = extractelement <8 x ptr> %1593, i64 3
  %1595 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 1
  %1596 = extractelement <8 x i64> %1595, i64 3
  %1597 = getelementptr i8, ptr %1594, i64 %1596
  %1598 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 0
  %1599 = extractelement <8 x ptr> %1598, i64 3
  %1600 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 1
  %1601 = extractelement <8 x i64> %1600, i64 3
  %1602 = getelementptr i8, ptr %1599, i64 %1601
  %1603 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1604 = extractelement <8 x ptr> %1603, i64 3
  %1605 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1606 = extractelement <8 x i64> %1605, i64 3
  %1607 = getelementptr i8, ptr %1604, i64 %1606
  call void @llm_attention.strided_mma(ptr %1592, ptr %1597, ptr %1602, ptr %1607)
  br label %mma.continue278

mma.continue278:                                  ; preds = %mma.active277, %mma.continue276
  %1608 = extractelement <8 x i1> %101, i64 4
  br i1 %1608, label %mma.active279, label %mma.continue280

mma.active279:                                    ; preds = %mma.continue278
  %1609 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 0
  %1610 = extractelement <8 x ptr> %1609, i64 4
  %1611 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 1
  %1612 = extractelement <8 x i64> %1611, i64 4
  %1613 = getelementptr i8, ptr %1610, i64 %1612
  %1614 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 0
  %1615 = extractelement <8 x ptr> %1614, i64 4
  %1616 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 1
  %1617 = extractelement <8 x i64> %1616, i64 4
  %1618 = getelementptr i8, ptr %1615, i64 %1617
  %1619 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 0
  %1620 = extractelement <8 x ptr> %1619, i64 4
  %1621 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 1
  %1622 = extractelement <8 x i64> %1621, i64 4
  %1623 = getelementptr i8, ptr %1620, i64 %1622
  %1624 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1625 = extractelement <8 x ptr> %1624, i64 4
  %1626 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1627 = extractelement <8 x i64> %1626, i64 4
  %1628 = getelementptr i8, ptr %1625, i64 %1627
  call void @llm_attention.strided_mma(ptr %1613, ptr %1618, ptr %1623, ptr %1628)
  br label %mma.continue280

mma.continue280:                                  ; preds = %mma.active279, %mma.continue278
  %1629 = extractelement <8 x i1> %101, i64 5
  br i1 %1629, label %mma.active281, label %mma.continue282

mma.active281:                                    ; preds = %mma.continue280
  %1630 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 0
  %1631 = extractelement <8 x ptr> %1630, i64 5
  %1632 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 1
  %1633 = extractelement <8 x i64> %1632, i64 5
  %1634 = getelementptr i8, ptr %1631, i64 %1633
  %1635 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 0
  %1636 = extractelement <8 x ptr> %1635, i64 5
  %1637 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 1
  %1638 = extractelement <8 x i64> %1637, i64 5
  %1639 = getelementptr i8, ptr %1636, i64 %1638
  %1640 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 0
  %1641 = extractelement <8 x ptr> %1640, i64 5
  %1642 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 1
  %1643 = extractelement <8 x i64> %1642, i64 5
  %1644 = getelementptr i8, ptr %1641, i64 %1643
  %1645 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1646 = extractelement <8 x ptr> %1645, i64 5
  %1647 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1648 = extractelement <8 x i64> %1647, i64 5
  %1649 = getelementptr i8, ptr %1646, i64 %1648
  call void @llm_attention.strided_mma(ptr %1634, ptr %1639, ptr %1644, ptr %1649)
  br label %mma.continue282

mma.continue282:                                  ; preds = %mma.active281, %mma.continue280
  %1650 = extractelement <8 x i1> %101, i64 6
  br i1 %1650, label %mma.active283, label %mma.continue284

mma.active283:                                    ; preds = %mma.continue282
  %1651 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 0
  %1652 = extractelement <8 x ptr> %1651, i64 6
  %1653 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 1
  %1654 = extractelement <8 x i64> %1653, i64 6
  %1655 = getelementptr i8, ptr %1652, i64 %1654
  %1656 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 0
  %1657 = extractelement <8 x ptr> %1656, i64 6
  %1658 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 1
  %1659 = extractelement <8 x i64> %1658, i64 6
  %1660 = getelementptr i8, ptr %1657, i64 %1659
  %1661 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 0
  %1662 = extractelement <8 x ptr> %1661, i64 6
  %1663 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 1
  %1664 = extractelement <8 x i64> %1663, i64 6
  %1665 = getelementptr i8, ptr %1662, i64 %1664
  %1666 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1667 = extractelement <8 x ptr> %1666, i64 6
  %1668 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1669 = extractelement <8 x i64> %1668, i64 6
  %1670 = getelementptr i8, ptr %1667, i64 %1669
  call void @llm_attention.strided_mma(ptr %1655, ptr %1660, ptr %1665, ptr %1670)
  br label %mma.continue284

mma.continue284:                                  ; preds = %mma.active283, %mma.continue282
  %1671 = extractelement <8 x i1> %101, i64 7
  br i1 %1671, label %mma.active285, label %mma.continue286

mma.active285:                                    ; preds = %mma.continue284
  %1672 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 0
  %1673 = extractelement <8 x ptr> %1672, i64 7
  %1674 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 1
  %1675 = extractelement <8 x i64> %1674, i64 7
  %1676 = getelementptr i8, ptr %1673, i64 %1675
  %1677 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 0
  %1678 = extractelement <8 x ptr> %1677, i64 7
  %1679 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 1
  %1680 = extractelement <8 x i64> %1679, i64 7
  %1681 = getelementptr i8, ptr %1678, i64 %1680
  %1682 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 0
  %1683 = extractelement <8 x ptr> %1682, i64 7
  %1684 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 1
  %1685 = extractelement <8 x i64> %1684, i64 7
  %1686 = getelementptr i8, ptr %1683, i64 %1685
  %1687 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1688 = extractelement <8 x ptr> %1687, i64 7
  %1689 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1690 = extractelement <8 x i64> %1689, i64 7
  %1691 = getelementptr i8, ptr %1688, i64 %1690
  call void @llm_attention.strided_mma(ptr %1676, ptr %1681, ptr %1686, ptr %1691)
  br label %mma.continue286

mma.continue286:                                  ; preds = %mma.active285, %mma.continue284
  %.spill.load287 = load i64, ptr %.spill91, align 4
  %1692 = add i64 0, %.spill.load287
  %.spill.load288 = load i64, ptr %.spill91, align 4
  %1693 = add i64 1, %.spill.load288
  %.spill.load289 = load i64, ptr %.spill91, align 4
  %1694 = add i64 2, %.spill.load289
  %.spill.load290 = load i64, ptr %.spill91, align 4
  %1695 = add i64 3, %.spill.load290
  %.spill.load291 = load i64, ptr %.spill91, align 4
  %1696 = add i64 4, %.spill.load291
  %.spill.load292 = load i64, ptr %.spill91, align 4
  %1697 = add i64 5, %.spill.load292
  %.spill.load293 = load i64, ptr %.spill91, align 4
  %1698 = add i64 6, %.spill.load293
  %.spill.load294 = load i64, ptr %.spill91, align 4
  %1699 = add i64 7, %.spill.load294
  %.spill.load295 = load i64, ptr %.spill91, align 4
  %1700 = add i64 8, %.spill.load295
  %.spill.load296 = load i64, ptr %.spill91, align 4
  %1701 = add i64 9, %.spill.load296
  %.spill.load297 = load i64, ptr %.spill91, align 4
  %1702 = add i64 10, %.spill.load297
  %.spill.load298 = load i64, ptr %.spill91, align 4
  %1703 = add i64 11, %.spill.load298
  %.spill.load299 = load i64, ptr %.spill91, align 4
  %1704 = add i64 12, %.spill.load299
  %.spill.load300 = load i64, ptr %.spill91, align 4
  %1705 = add i64 13, %.spill.load300
  %.spill.load301 = load i64, ptr %.spill91, align 4
  %1706 = add i64 14, %.spill.load301
  %.spill.load302 = load i64, ptr %.spill91, align 4
  %1707 = add i64 15, %.spill.load302
  %1708 = icmp slt i64 %1692, 129
  %1709 = icmp slt i64 %1693, 129
  %1710 = icmp slt i64 %1694, 129
  %1711 = icmp slt i64 %1695, 129
  %1712 = icmp slt i64 %1696, 129
  %1713 = icmp slt i64 %1697, 129
  %1714 = icmp slt i64 %1698, 129
  %1715 = icmp slt i64 %1699, 129
  %1716 = icmp slt i64 %1700, 129
  %1717 = icmp slt i64 %1701, 129
  %1718 = icmp slt i64 %1702, 129
  %1719 = icmp slt i64 %1703, 129
  %1720 = icmp slt i64 %1704, 129
  %1721 = icmp slt i64 %1705, 129
  %1722 = icmp slt i64 %1706, 129
  %1723 = icmp slt i64 %1707, 129
  %1724 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %1725 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1726 = extractvalue { <8 x ptr>, <8 x i64> } %1724, 0
  %1727 = select <8 x i1> %101, <8 x ptr> %1725, <8 x ptr> %1726
  %1728 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1729 = extractvalue { <8 x ptr>, <8 x i64> } %1724, 1
  %1730 = select <8 x i1> %101, <8 x i64> %1728, <8 x i64> %1729
  %1731 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1727, 0
  %1732 = insertvalue { <8 x ptr>, <8 x i64> } %1731, <8 x i64> %1730, 1
  store { <8 x ptr>, <8 x i64> } %1732, ptr %tile_snapshot.spill103, align 64
  %1733 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1734 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1735 = add <8 x i64> %1734, zeroinitializer
  %1736 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1733, 0
  %1737 = insertvalue { <8 x ptr>, <8 x i64> } %1736, <8 x i64> %1735, 1
  %.splatinsert303 = insertelement <8 x i1> poison, i1 %1708, i64 0
  %.splat304 = shufflevector <8 x i1> %.splatinsert303, <8 x i1> poison, <8 x i32> zeroinitializer
  %1738 = extractvalue { <8 x ptr>, <8 x i64> } %1737, 0
  %1739 = extractvalue { <8 x ptr>, <8 x i64> } %1737, 1
  %1740 = getelementptr i8, <8 x ptr> %1738, <8 x i64> %1739
  %1741 = zext <8 x i1> %.splat304 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1741, <8 x ptr> align 1 %1740, <8 x i1> %101)
  %1742 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1743 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1744 = add <8 x i64> %1743, splat (i64 1)
  %1745 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1742, 0
  %1746 = insertvalue { <8 x ptr>, <8 x i64> } %1745, <8 x i64> %1744, 1
  %.splatinsert305 = insertelement <8 x i1> poison, i1 %1709, i64 0
  %.splat306 = shufflevector <8 x i1> %.splatinsert305, <8 x i1> poison, <8 x i32> zeroinitializer
  %1747 = extractvalue { <8 x ptr>, <8 x i64> } %1746, 0
  %1748 = extractvalue { <8 x ptr>, <8 x i64> } %1746, 1
  %1749 = getelementptr i8, <8 x ptr> %1747, <8 x i64> %1748
  %1750 = zext <8 x i1> %.splat306 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1750, <8 x ptr> align 1 %1749, <8 x i1> %101)
  %1751 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1752 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1753 = add <8 x i64> %1752, splat (i64 2)
  %1754 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1751, 0
  %1755 = insertvalue { <8 x ptr>, <8 x i64> } %1754, <8 x i64> %1753, 1
  %.splatinsert307 = insertelement <8 x i1> poison, i1 %1710, i64 0
  %.splat308 = shufflevector <8 x i1> %.splatinsert307, <8 x i1> poison, <8 x i32> zeroinitializer
  %1756 = extractvalue { <8 x ptr>, <8 x i64> } %1755, 0
  %1757 = extractvalue { <8 x ptr>, <8 x i64> } %1755, 1
  %1758 = getelementptr i8, <8 x ptr> %1756, <8 x i64> %1757
  %1759 = zext <8 x i1> %.splat308 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1759, <8 x ptr> align 1 %1758, <8 x i1> %101)
  %1760 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1761 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1762 = add <8 x i64> %1761, splat (i64 3)
  %1763 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1760, 0
  %1764 = insertvalue { <8 x ptr>, <8 x i64> } %1763, <8 x i64> %1762, 1
  %.splatinsert309 = insertelement <8 x i1> poison, i1 %1711, i64 0
  %.splat310 = shufflevector <8 x i1> %.splatinsert309, <8 x i1> poison, <8 x i32> zeroinitializer
  %1765 = extractvalue { <8 x ptr>, <8 x i64> } %1764, 0
  %1766 = extractvalue { <8 x ptr>, <8 x i64> } %1764, 1
  %1767 = getelementptr i8, <8 x ptr> %1765, <8 x i64> %1766
  %1768 = zext <8 x i1> %.splat310 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1768, <8 x ptr> align 1 %1767, <8 x i1> %101)
  %1769 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1770 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1771 = add <8 x i64> %1770, splat (i64 4)
  %1772 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1769, 0
  %1773 = insertvalue { <8 x ptr>, <8 x i64> } %1772, <8 x i64> %1771, 1
  %.splatinsert311 = insertelement <8 x i1> poison, i1 %1712, i64 0
  %.splat312 = shufflevector <8 x i1> %.splatinsert311, <8 x i1> poison, <8 x i32> zeroinitializer
  %1774 = extractvalue { <8 x ptr>, <8 x i64> } %1773, 0
  %1775 = extractvalue { <8 x ptr>, <8 x i64> } %1773, 1
  %1776 = getelementptr i8, <8 x ptr> %1774, <8 x i64> %1775
  %1777 = zext <8 x i1> %.splat312 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1777, <8 x ptr> align 1 %1776, <8 x i1> %101)
  %1778 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1779 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1780 = add <8 x i64> %1779, splat (i64 5)
  %1781 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1778, 0
  %1782 = insertvalue { <8 x ptr>, <8 x i64> } %1781, <8 x i64> %1780, 1
  %.splatinsert313 = insertelement <8 x i1> poison, i1 %1713, i64 0
  %.splat314 = shufflevector <8 x i1> %.splatinsert313, <8 x i1> poison, <8 x i32> zeroinitializer
  %1783 = extractvalue { <8 x ptr>, <8 x i64> } %1782, 0
  %1784 = extractvalue { <8 x ptr>, <8 x i64> } %1782, 1
  %1785 = getelementptr i8, <8 x ptr> %1783, <8 x i64> %1784
  %1786 = zext <8 x i1> %.splat314 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1786, <8 x ptr> align 1 %1785, <8 x i1> %101)
  %1787 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1788 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1789 = add <8 x i64> %1788, splat (i64 6)
  %1790 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1787, 0
  %1791 = insertvalue { <8 x ptr>, <8 x i64> } %1790, <8 x i64> %1789, 1
  %.splatinsert315 = insertelement <8 x i1> poison, i1 %1714, i64 0
  %.splat316 = shufflevector <8 x i1> %.splatinsert315, <8 x i1> poison, <8 x i32> zeroinitializer
  %1792 = extractvalue { <8 x ptr>, <8 x i64> } %1791, 0
  %1793 = extractvalue { <8 x ptr>, <8 x i64> } %1791, 1
  %1794 = getelementptr i8, <8 x ptr> %1792, <8 x i64> %1793
  %1795 = zext <8 x i1> %.splat316 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1795, <8 x ptr> align 1 %1794, <8 x i1> %101)
  %1796 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1797 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1798 = add <8 x i64> %1797, splat (i64 7)
  %1799 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1796, 0
  %1800 = insertvalue { <8 x ptr>, <8 x i64> } %1799, <8 x i64> %1798, 1
  %.splatinsert317 = insertelement <8 x i1> poison, i1 %1715, i64 0
  %.splat318 = shufflevector <8 x i1> %.splatinsert317, <8 x i1> poison, <8 x i32> zeroinitializer
  %1801 = extractvalue { <8 x ptr>, <8 x i64> } %1800, 0
  %1802 = extractvalue { <8 x ptr>, <8 x i64> } %1800, 1
  %1803 = getelementptr i8, <8 x ptr> %1801, <8 x i64> %1802
  %1804 = zext <8 x i1> %.splat318 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1804, <8 x ptr> align 1 %1803, <8 x i1> %101)
  %1805 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1806 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1807 = add <8 x i64> %1806, splat (i64 8)
  %1808 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1805, 0
  %1809 = insertvalue { <8 x ptr>, <8 x i64> } %1808, <8 x i64> %1807, 1
  %.splatinsert319 = insertelement <8 x i1> poison, i1 %1716, i64 0
  %.splat320 = shufflevector <8 x i1> %.splatinsert319, <8 x i1> poison, <8 x i32> zeroinitializer
  %1810 = extractvalue { <8 x ptr>, <8 x i64> } %1809, 0
  %1811 = extractvalue { <8 x ptr>, <8 x i64> } %1809, 1
  %1812 = getelementptr i8, <8 x ptr> %1810, <8 x i64> %1811
  %1813 = zext <8 x i1> %.splat320 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1813, <8 x ptr> align 1 %1812, <8 x i1> %101)
  %1814 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1815 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1816 = add <8 x i64> %1815, splat (i64 9)
  %1817 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1814, 0
  %1818 = insertvalue { <8 x ptr>, <8 x i64> } %1817, <8 x i64> %1816, 1
  %.splatinsert321 = insertelement <8 x i1> poison, i1 %1717, i64 0
  %.splat322 = shufflevector <8 x i1> %.splatinsert321, <8 x i1> poison, <8 x i32> zeroinitializer
  %1819 = extractvalue { <8 x ptr>, <8 x i64> } %1818, 0
  %1820 = extractvalue { <8 x ptr>, <8 x i64> } %1818, 1
  %1821 = getelementptr i8, <8 x ptr> %1819, <8 x i64> %1820
  %1822 = zext <8 x i1> %.splat322 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1822, <8 x ptr> align 1 %1821, <8 x i1> %101)
  %1823 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1824 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1825 = add <8 x i64> %1824, splat (i64 10)
  %1826 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1823, 0
  %1827 = insertvalue { <8 x ptr>, <8 x i64> } %1826, <8 x i64> %1825, 1
  %.splatinsert323 = insertelement <8 x i1> poison, i1 %1718, i64 0
  %.splat324 = shufflevector <8 x i1> %.splatinsert323, <8 x i1> poison, <8 x i32> zeroinitializer
  %1828 = extractvalue { <8 x ptr>, <8 x i64> } %1827, 0
  %1829 = extractvalue { <8 x ptr>, <8 x i64> } %1827, 1
  %1830 = getelementptr i8, <8 x ptr> %1828, <8 x i64> %1829
  %1831 = zext <8 x i1> %.splat324 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1831, <8 x ptr> align 1 %1830, <8 x i1> %101)
  %1832 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1833 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1834 = add <8 x i64> %1833, splat (i64 11)
  %1835 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1832, 0
  %1836 = insertvalue { <8 x ptr>, <8 x i64> } %1835, <8 x i64> %1834, 1
  %.splatinsert325 = insertelement <8 x i1> poison, i1 %1719, i64 0
  %.splat326 = shufflevector <8 x i1> %.splatinsert325, <8 x i1> poison, <8 x i32> zeroinitializer
  %1837 = extractvalue { <8 x ptr>, <8 x i64> } %1836, 0
  %1838 = extractvalue { <8 x ptr>, <8 x i64> } %1836, 1
  %1839 = getelementptr i8, <8 x ptr> %1837, <8 x i64> %1838
  %1840 = zext <8 x i1> %.splat326 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1840, <8 x ptr> align 1 %1839, <8 x i1> %101)
  %1841 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1842 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1843 = add <8 x i64> %1842, splat (i64 12)
  %1844 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1841, 0
  %1845 = insertvalue { <8 x ptr>, <8 x i64> } %1844, <8 x i64> %1843, 1
  %.splatinsert327 = insertelement <8 x i1> poison, i1 %1720, i64 0
  %.splat328 = shufflevector <8 x i1> %.splatinsert327, <8 x i1> poison, <8 x i32> zeroinitializer
  %1846 = extractvalue { <8 x ptr>, <8 x i64> } %1845, 0
  %1847 = extractvalue { <8 x ptr>, <8 x i64> } %1845, 1
  %1848 = getelementptr i8, <8 x ptr> %1846, <8 x i64> %1847
  %1849 = zext <8 x i1> %.splat328 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1849, <8 x ptr> align 1 %1848, <8 x i1> %101)
  %1850 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1851 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1852 = add <8 x i64> %1851, splat (i64 13)
  %1853 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1850, 0
  %1854 = insertvalue { <8 x ptr>, <8 x i64> } %1853, <8 x i64> %1852, 1
  %.splatinsert329 = insertelement <8 x i1> poison, i1 %1721, i64 0
  %.splat330 = shufflevector <8 x i1> %.splatinsert329, <8 x i1> poison, <8 x i32> zeroinitializer
  %1855 = extractvalue { <8 x ptr>, <8 x i64> } %1854, 0
  %1856 = extractvalue { <8 x ptr>, <8 x i64> } %1854, 1
  %1857 = getelementptr i8, <8 x ptr> %1855, <8 x i64> %1856
  %1858 = zext <8 x i1> %.splat330 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1858, <8 x ptr> align 1 %1857, <8 x i1> %101)
  %1859 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1860 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1861 = add <8 x i64> %1860, splat (i64 14)
  %1862 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1859, 0
  %1863 = insertvalue { <8 x ptr>, <8 x i64> } %1862, <8 x i64> %1861, 1
  %.splatinsert331 = insertelement <8 x i1> poison, i1 %1722, i64 0
  %.splat332 = shufflevector <8 x i1> %.splatinsert331, <8 x i1> poison, <8 x i32> zeroinitializer
  %1864 = extractvalue { <8 x ptr>, <8 x i64> } %1863, 0
  %1865 = extractvalue { <8 x ptr>, <8 x i64> } %1863, 1
  %1866 = getelementptr i8, <8 x ptr> %1864, <8 x i64> %1865
  %1867 = zext <8 x i1> %.splat332 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1867, <8 x ptr> align 1 %1866, <8 x i1> %101)
  %1868 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1869 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1870 = add <8 x i64> %1869, splat (i64 15)
  %1871 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1868, 0
  %1872 = insertvalue { <8 x ptr>, <8 x i64> } %1871, <8 x i64> %1870, 1
  %.splatinsert333 = insertelement <8 x i1> poison, i1 %1723, i64 0
  %.splat334 = shufflevector <8 x i1> %.splatinsert333, <8 x i1> poison, <8 x i32> zeroinitializer
  %1873 = extractvalue { <8 x ptr>, <8 x i64> } %1872, 0
  %1874 = extractvalue { <8 x ptr>, <8 x i64> } %1872, 1
  %1875 = getelementptr i8, <8 x ptr> %1873, <8 x i64> %1874
  %1876 = zext <8 x i1> %.splat334 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1876, <8 x ptr> align 1 %1875, <8 x i1> %101)
  %1877 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill104, align 64
  %1878 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1879 = extractvalue { <8 x ptr>, <8 x i64> } %1877, 0
  %1880 = select <8 x i1> %101, <8 x ptr> %1878, <8 x ptr> %1879
  %1881 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %1882 = extractvalue { <8 x ptr>, <8 x i64> } %1877, 1
  %1883 = select <8 x i1> %101, <8 x i64> %1881, <8 x i64> %1882
  %1884 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1880, 0
  %1885 = insertvalue { <8 x ptr>, <8 x i64> } %1884, <8 x i64> %1883, 1
  store { <8 x ptr>, <8 x i64> } %1885, ptr %tile_snapshot.spill104, align 64
  %1886 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1887 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %1888 = add <8 x i64> %1887, zeroinitializer
  %1889 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1886, 0
  %1890 = insertvalue { <8 x ptr>, <8 x i64> } %1889, <8 x i64> %1888, 1
  %.splatinsert335 = insertelement <8 x i64> poison, i64 %1692, i64 0
  %.splat336 = shufflevector <8 x i64> %.splatinsert335, <8 x i64> poison, <8 x i32> zeroinitializer
  %1891 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1892 = extractvalue { <8 x ptr>, <8 x i64> } %1890, 1
  %1893 = extractelement <8 x ptr> %1891, i32 0
  %1894 = extractelement <8 x i64> %1892, i32 0
  %1895 = sub i64 %1894, 0
  %1896 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1897 = select i1 %1896, i64 %1895, i64 0
  %private.contiguous.address337 = getelementptr i8, ptr %1893, i64 %1897
  %private.contiguous.preserve338 = load <8 x i64>, ptr %private.contiguous.address337, align 8
  %1898 = select <8 x i1> %101, <8 x i64> %.splat336, <8 x i64> %private.contiguous.preserve338
  store <8 x i64> %1898, ptr %private.contiguous.address337, align 8
  %1899 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1900 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %1901 = add <8 x i64> %1900, splat (i64 64)
  %1902 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1899, 0
  %1903 = insertvalue { <8 x ptr>, <8 x i64> } %1902, <8 x i64> %1901, 1
  %.splatinsert339 = insertelement <8 x i64> poison, i64 %1693, i64 0
  %.splat340 = shufflevector <8 x i64> %.splatinsert339, <8 x i64> poison, <8 x i32> zeroinitializer
  %1904 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1905 = extractvalue { <8 x ptr>, <8 x i64> } %1903, 1
  %1906 = extractelement <8 x ptr> %1904, i32 0
  %1907 = extractelement <8 x i64> %1905, i32 0
  %1908 = sub i64 %1907, 0
  %1909 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1910 = select i1 %1909, i64 %1908, i64 0
  %private.contiguous.address341 = getelementptr i8, ptr %1906, i64 %1910
  %private.contiguous.preserve342 = load <8 x i64>, ptr %private.contiguous.address341, align 8
  %1911 = select <8 x i1> %101, <8 x i64> %.splat340, <8 x i64> %private.contiguous.preserve342
  store <8 x i64> %1911, ptr %private.contiguous.address341, align 8
  %1912 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1913 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %1914 = add <8 x i64> %1913, splat (i64 128)
  %1915 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1912, 0
  %1916 = insertvalue { <8 x ptr>, <8 x i64> } %1915, <8 x i64> %1914, 1
  %.splatinsert343 = insertelement <8 x i64> poison, i64 %1694, i64 0
  %.splat344 = shufflevector <8 x i64> %.splatinsert343, <8 x i64> poison, <8 x i32> zeroinitializer
  %1917 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1918 = extractvalue { <8 x ptr>, <8 x i64> } %1916, 1
  %1919 = extractelement <8 x ptr> %1917, i32 0
  %1920 = extractelement <8 x i64> %1918, i32 0
  %1921 = sub i64 %1920, 0
  %1922 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1923 = select i1 %1922, i64 %1921, i64 0
  %private.contiguous.address345 = getelementptr i8, ptr %1919, i64 %1923
  %private.contiguous.preserve346 = load <8 x i64>, ptr %private.contiguous.address345, align 8
  %1924 = select <8 x i1> %101, <8 x i64> %.splat344, <8 x i64> %private.contiguous.preserve346
  store <8 x i64> %1924, ptr %private.contiguous.address345, align 8
  %1925 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1926 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %1927 = add <8 x i64> %1926, splat (i64 192)
  %1928 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1925, 0
  %1929 = insertvalue { <8 x ptr>, <8 x i64> } %1928, <8 x i64> %1927, 1
  %.splatinsert347 = insertelement <8 x i64> poison, i64 %1695, i64 0
  %.splat348 = shufflevector <8 x i64> %.splatinsert347, <8 x i64> poison, <8 x i32> zeroinitializer
  %1930 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1931 = extractvalue { <8 x ptr>, <8 x i64> } %1929, 1
  %1932 = extractelement <8 x ptr> %1930, i32 0
  %1933 = extractelement <8 x i64> %1931, i32 0
  %1934 = sub i64 %1933, 0
  %1935 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1936 = select i1 %1935, i64 %1934, i64 0
  %private.contiguous.address349 = getelementptr i8, ptr %1932, i64 %1936
  %private.contiguous.preserve350 = load <8 x i64>, ptr %private.contiguous.address349, align 8
  %1937 = select <8 x i1> %101, <8 x i64> %.splat348, <8 x i64> %private.contiguous.preserve350
  store <8 x i64> %1937, ptr %private.contiguous.address349, align 8
  %1938 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1939 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %1940 = add <8 x i64> %1939, splat (i64 256)
  %1941 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1938, 0
  %1942 = insertvalue { <8 x ptr>, <8 x i64> } %1941, <8 x i64> %1940, 1
  %.splatinsert351 = insertelement <8 x i64> poison, i64 %1696, i64 0
  %.splat352 = shufflevector <8 x i64> %.splatinsert351, <8 x i64> poison, <8 x i32> zeroinitializer
  %1943 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1944 = extractvalue { <8 x ptr>, <8 x i64> } %1942, 1
  %1945 = extractelement <8 x ptr> %1943, i32 0
  %1946 = extractelement <8 x i64> %1944, i32 0
  %1947 = sub i64 %1946, 0
  %1948 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1949 = select i1 %1948, i64 %1947, i64 0
  %private.contiguous.address353 = getelementptr i8, ptr %1945, i64 %1949
  %private.contiguous.preserve354 = load <8 x i64>, ptr %private.contiguous.address353, align 8
  %1950 = select <8 x i1> %101, <8 x i64> %.splat352, <8 x i64> %private.contiguous.preserve354
  store <8 x i64> %1950, ptr %private.contiguous.address353, align 8
  %1951 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1952 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %1953 = add <8 x i64> %1952, splat (i64 320)
  %1954 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1951, 0
  %1955 = insertvalue { <8 x ptr>, <8 x i64> } %1954, <8 x i64> %1953, 1
  %.splatinsert355 = insertelement <8 x i64> poison, i64 %1697, i64 0
  %.splat356 = shufflevector <8 x i64> %.splatinsert355, <8 x i64> poison, <8 x i32> zeroinitializer
  %1956 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1957 = extractvalue { <8 x ptr>, <8 x i64> } %1955, 1
  %1958 = extractelement <8 x ptr> %1956, i32 0
  %1959 = extractelement <8 x i64> %1957, i32 0
  %1960 = sub i64 %1959, 0
  %1961 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1962 = select i1 %1961, i64 %1960, i64 0
  %private.contiguous.address357 = getelementptr i8, ptr %1958, i64 %1962
  %private.contiguous.preserve358 = load <8 x i64>, ptr %private.contiguous.address357, align 8
  %1963 = select <8 x i1> %101, <8 x i64> %.splat356, <8 x i64> %private.contiguous.preserve358
  store <8 x i64> %1963, ptr %private.contiguous.address357, align 8
  %1964 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1965 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %1966 = add <8 x i64> %1965, splat (i64 384)
  %1967 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1964, 0
  %1968 = insertvalue { <8 x ptr>, <8 x i64> } %1967, <8 x i64> %1966, 1
  %.splatinsert359 = insertelement <8 x i64> poison, i64 %1698, i64 0
  %.splat360 = shufflevector <8 x i64> %.splatinsert359, <8 x i64> poison, <8 x i32> zeroinitializer
  %1969 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1970 = extractvalue { <8 x ptr>, <8 x i64> } %1968, 1
  %1971 = extractelement <8 x ptr> %1969, i32 0
  %1972 = extractelement <8 x i64> %1970, i32 0
  %1973 = sub i64 %1972, 0
  %1974 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1975 = select i1 %1974, i64 %1973, i64 0
  %private.contiguous.address361 = getelementptr i8, ptr %1971, i64 %1975
  %private.contiguous.preserve362 = load <8 x i64>, ptr %private.contiguous.address361, align 8
  %1976 = select <8 x i1> %101, <8 x i64> %.splat360, <8 x i64> %private.contiguous.preserve362
  store <8 x i64> %1976, ptr %private.contiguous.address361, align 8
  %1977 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1978 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %1979 = add <8 x i64> %1978, splat (i64 448)
  %1980 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1977, 0
  %1981 = insertvalue { <8 x ptr>, <8 x i64> } %1980, <8 x i64> %1979, 1
  %.splatinsert363 = insertelement <8 x i64> poison, i64 %1699, i64 0
  %.splat364 = shufflevector <8 x i64> %.splatinsert363, <8 x i64> poison, <8 x i32> zeroinitializer
  %1982 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1983 = extractvalue { <8 x ptr>, <8 x i64> } %1981, 1
  %1984 = extractelement <8 x ptr> %1982, i32 0
  %1985 = extractelement <8 x i64> %1983, i32 0
  %1986 = sub i64 %1985, 0
  %1987 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %1988 = select i1 %1987, i64 %1986, i64 0
  %private.contiguous.address365 = getelementptr i8, ptr %1984, i64 %1988
  %private.contiguous.preserve366 = load <8 x i64>, ptr %private.contiguous.address365, align 8
  %1989 = select <8 x i1> %101, <8 x i64> %.splat364, <8 x i64> %private.contiguous.preserve366
  store <8 x i64> %1989, ptr %private.contiguous.address365, align 8
  %1990 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1991 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %1992 = add <8 x i64> %1991, splat (i64 512)
  %1993 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1990, 0
  %1994 = insertvalue { <8 x ptr>, <8 x i64> } %1993, <8 x i64> %1992, 1
  %.splatinsert367 = insertelement <8 x i64> poison, i64 %1700, i64 0
  %.splat368 = shufflevector <8 x i64> %.splatinsert367, <8 x i64> poison, <8 x i32> zeroinitializer
  %1995 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1996 = extractvalue { <8 x ptr>, <8 x i64> } %1994, 1
  %1997 = extractelement <8 x ptr> %1995, i32 0
  %1998 = extractelement <8 x i64> %1996, i32 0
  %1999 = sub i64 %1998, 0
  %2000 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2001 = select i1 %2000, i64 %1999, i64 0
  %private.contiguous.address369 = getelementptr i8, ptr %1997, i64 %2001
  %private.contiguous.preserve370 = load <8 x i64>, ptr %private.contiguous.address369, align 8
  %2002 = select <8 x i1> %101, <8 x i64> %.splat368, <8 x i64> %private.contiguous.preserve370
  store <8 x i64> %2002, ptr %private.contiguous.address369, align 8
  %2003 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2004 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2005 = add <8 x i64> %2004, splat (i64 576)
  %2006 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2003, 0
  %2007 = insertvalue { <8 x ptr>, <8 x i64> } %2006, <8 x i64> %2005, 1
  %.splatinsert371 = insertelement <8 x i64> poison, i64 %1701, i64 0
  %.splat372 = shufflevector <8 x i64> %.splatinsert371, <8 x i64> poison, <8 x i32> zeroinitializer
  %2008 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2009 = extractvalue { <8 x ptr>, <8 x i64> } %2007, 1
  %2010 = extractelement <8 x ptr> %2008, i32 0
  %2011 = extractelement <8 x i64> %2009, i32 0
  %2012 = sub i64 %2011, 0
  %2013 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2014 = select i1 %2013, i64 %2012, i64 0
  %private.contiguous.address373 = getelementptr i8, ptr %2010, i64 %2014
  %private.contiguous.preserve374 = load <8 x i64>, ptr %private.contiguous.address373, align 8
  %2015 = select <8 x i1> %101, <8 x i64> %.splat372, <8 x i64> %private.contiguous.preserve374
  store <8 x i64> %2015, ptr %private.contiguous.address373, align 8
  %2016 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2017 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2018 = add <8 x i64> %2017, splat (i64 640)
  %2019 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2016, 0
  %2020 = insertvalue { <8 x ptr>, <8 x i64> } %2019, <8 x i64> %2018, 1
  %.splatinsert375 = insertelement <8 x i64> poison, i64 %1702, i64 0
  %.splat376 = shufflevector <8 x i64> %.splatinsert375, <8 x i64> poison, <8 x i32> zeroinitializer
  %2021 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2022 = extractvalue { <8 x ptr>, <8 x i64> } %2020, 1
  %2023 = extractelement <8 x ptr> %2021, i32 0
  %2024 = extractelement <8 x i64> %2022, i32 0
  %2025 = sub i64 %2024, 0
  %2026 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2027 = select i1 %2026, i64 %2025, i64 0
  %private.contiguous.address377 = getelementptr i8, ptr %2023, i64 %2027
  %private.contiguous.preserve378 = load <8 x i64>, ptr %private.contiguous.address377, align 8
  %2028 = select <8 x i1> %101, <8 x i64> %.splat376, <8 x i64> %private.contiguous.preserve378
  store <8 x i64> %2028, ptr %private.contiguous.address377, align 8
  %2029 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2030 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2031 = add <8 x i64> %2030, splat (i64 704)
  %2032 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2029, 0
  %2033 = insertvalue { <8 x ptr>, <8 x i64> } %2032, <8 x i64> %2031, 1
  %.splatinsert379 = insertelement <8 x i64> poison, i64 %1703, i64 0
  %.splat380 = shufflevector <8 x i64> %.splatinsert379, <8 x i64> poison, <8 x i32> zeroinitializer
  %2034 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2035 = extractvalue { <8 x ptr>, <8 x i64> } %2033, 1
  %2036 = extractelement <8 x ptr> %2034, i32 0
  %2037 = extractelement <8 x i64> %2035, i32 0
  %2038 = sub i64 %2037, 0
  %2039 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2040 = select i1 %2039, i64 %2038, i64 0
  %private.contiguous.address381 = getelementptr i8, ptr %2036, i64 %2040
  %private.contiguous.preserve382 = load <8 x i64>, ptr %private.contiguous.address381, align 8
  %2041 = select <8 x i1> %101, <8 x i64> %.splat380, <8 x i64> %private.contiguous.preserve382
  store <8 x i64> %2041, ptr %private.contiguous.address381, align 8
  %2042 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2043 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2044 = add <8 x i64> %2043, splat (i64 768)
  %2045 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2042, 0
  %2046 = insertvalue { <8 x ptr>, <8 x i64> } %2045, <8 x i64> %2044, 1
  %.splatinsert383 = insertelement <8 x i64> poison, i64 %1704, i64 0
  %.splat384 = shufflevector <8 x i64> %.splatinsert383, <8 x i64> poison, <8 x i32> zeroinitializer
  %2047 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2048 = extractvalue { <8 x ptr>, <8 x i64> } %2046, 1
  %2049 = extractelement <8 x ptr> %2047, i32 0
  %2050 = extractelement <8 x i64> %2048, i32 0
  %2051 = sub i64 %2050, 0
  %2052 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2053 = select i1 %2052, i64 %2051, i64 0
  %private.contiguous.address385 = getelementptr i8, ptr %2049, i64 %2053
  %private.contiguous.preserve386 = load <8 x i64>, ptr %private.contiguous.address385, align 8
  %2054 = select <8 x i1> %101, <8 x i64> %.splat384, <8 x i64> %private.contiguous.preserve386
  store <8 x i64> %2054, ptr %private.contiguous.address385, align 8
  %2055 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2056 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2057 = add <8 x i64> %2056, splat (i64 832)
  %2058 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2055, 0
  %2059 = insertvalue { <8 x ptr>, <8 x i64> } %2058, <8 x i64> %2057, 1
  %.splatinsert387 = insertelement <8 x i64> poison, i64 %1705, i64 0
  %.splat388 = shufflevector <8 x i64> %.splatinsert387, <8 x i64> poison, <8 x i32> zeroinitializer
  %2060 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2061 = extractvalue { <8 x ptr>, <8 x i64> } %2059, 1
  %2062 = extractelement <8 x ptr> %2060, i32 0
  %2063 = extractelement <8 x i64> %2061, i32 0
  %2064 = sub i64 %2063, 0
  %2065 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2066 = select i1 %2065, i64 %2064, i64 0
  %private.contiguous.address389 = getelementptr i8, ptr %2062, i64 %2066
  %private.contiguous.preserve390 = load <8 x i64>, ptr %private.contiguous.address389, align 8
  %2067 = select <8 x i1> %101, <8 x i64> %.splat388, <8 x i64> %private.contiguous.preserve390
  store <8 x i64> %2067, ptr %private.contiguous.address389, align 8
  %2068 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2069 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2070 = add <8 x i64> %2069, splat (i64 896)
  %2071 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2068, 0
  %2072 = insertvalue { <8 x ptr>, <8 x i64> } %2071, <8 x i64> %2070, 1
  %.splatinsert391 = insertelement <8 x i64> poison, i64 %1706, i64 0
  %.splat392 = shufflevector <8 x i64> %.splatinsert391, <8 x i64> poison, <8 x i32> zeroinitializer
  %2073 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2074 = extractvalue { <8 x ptr>, <8 x i64> } %2072, 1
  %2075 = extractelement <8 x ptr> %2073, i32 0
  %2076 = extractelement <8 x i64> %2074, i32 0
  %2077 = sub i64 %2076, 0
  %2078 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2079 = select i1 %2078, i64 %2077, i64 0
  %private.contiguous.address393 = getelementptr i8, ptr %2075, i64 %2079
  %private.contiguous.preserve394 = load <8 x i64>, ptr %private.contiguous.address393, align 8
  %2080 = select <8 x i1> %101, <8 x i64> %.splat392, <8 x i64> %private.contiguous.preserve394
  store <8 x i64> %2080, ptr %private.contiguous.address393, align 8
  %2081 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2082 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2083 = add <8 x i64> %2082, splat (i64 960)
  %2084 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2081, 0
  %2085 = insertvalue { <8 x ptr>, <8 x i64> } %2084, <8 x i64> %2083, 1
  %.splatinsert395 = insertelement <8 x i64> poison, i64 %1707, i64 0
  %.splat396 = shufflevector <8 x i64> %.splatinsert395, <8 x i64> poison, <8 x i32> zeroinitializer
  %2086 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2087 = extractvalue { <8 x ptr>, <8 x i64> } %2085, 1
  %2088 = extractelement <8 x ptr> %2086, i32 0
  %2089 = extractelement <8 x i64> %2087, i32 0
  %2090 = sub i64 %2089, 0
  %2091 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2092 = select i1 %2091, i64 %2090, i64 0
  %private.contiguous.address397 = getelementptr i8, ptr %2088, i64 %2092
  %private.contiguous.preserve398 = load <8 x i64>, ptr %private.contiguous.address397, align 8
  %2093 = select <8 x i1> %101, <8 x i64> %.splat396, <8 x i64> %private.contiguous.preserve398
  store <8 x i64> %2093, ptr %private.contiguous.address397, align 8
  %.spill.load399 = load <8 x i64>, ptr %.spill69, align 64
  %2094 = add <8 x i64> zeroinitializer, %.spill.load399
  %.spill.load400 = load <8 x i64>, ptr %.spill69, align 64
  %2095 = add <8 x i64> splat (i64 1), %.spill.load400
  %.spill.load401 = load <8 x i64>, ptr %.spill69, align 64
  %2096 = add <8 x i64> splat (i64 2), %.spill.load401
  %.spill.load402 = load <8 x i64>, ptr %.spill69, align 64
  %2097 = add <8 x i64> splat (i64 3), %.spill.load402
  %.spill.load403 = load <8 x i64>, ptr %.spill69, align 64
  %2098 = add <8 x i64> splat (i64 4), %.spill.load403
  %.spill.load404 = load <8 x i64>, ptr %.spill69, align 64
  %2099 = add <8 x i64> splat (i64 5), %.spill.load404
  %.spill.load405 = load <8 x i64>, ptr %.spill69, align 64
  %2100 = add <8 x i64> splat (i64 6), %.spill.load405
  %.spill.load406 = load <8 x i64>, ptr %.spill69, align 64
  %2101 = add <8 x i64> splat (i64 7), %.spill.load406
  %2102 = add <8 x i64> %2094, splat (i64 129)
  %2103 = add <8 x i64> %2095, splat (i64 129)
  %2104 = add <8 x i64> %2096, splat (i64 129)
  %2105 = add <8 x i64> %2097, splat (i64 129)
  %2106 = add <8 x i64> %2098, splat (i64 129)
  %2107 = add <8 x i64> %2099, splat (i64 129)
  %2108 = add <8 x i64> %2100, splat (i64 129)
  %2109 = add <8 x i64> %2101, splat (i64 129)
  %2110 = sub <8 x i64> %2102, splat (i64 64)
  %2111 = sub <8 x i64> %2103, splat (i64 64)
  %2112 = sub <8 x i64> %2104, splat (i64 64)
  %2113 = sub <8 x i64> %2105, splat (i64 64)
  %2114 = sub <8 x i64> %2106, splat (i64 64)
  %2115 = sub <8 x i64> %2107, splat (i64 64)
  %2116 = sub <8 x i64> %2108, splat (i64 64)
  %2117 = sub <8 x i64> %2109, splat (i64 64)
  %2118 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill105, align 64
  %2119 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2120 = extractvalue { <8 x ptr>, <8 x i64> } %2118, 0
  %2121 = select <8 x i1> %101, <8 x ptr> %2119, <8 x ptr> %2120
  %2122 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %2123 = extractvalue { <8 x ptr>, <8 x i64> } %2118, 1
  %2124 = select <8 x i1> %101, <8 x i64> %2122, <8 x i64> %2123
  %2125 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2121, 0
  %2126 = insertvalue { <8 x ptr>, <8 x i64> } %2125, <8 x i64> %2124, 1
  store { <8 x ptr>, <8 x i64> } %2126, ptr %tile_snapshot.spill105, align 64
  %2127 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2128 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %2129 = add <8 x i64> %2128, zeroinitializer
  %2130 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2127, 0
  %2131 = insertvalue { <8 x ptr>, <8 x i64> } %2130, <8 x i64> %2129, 1
  %2132 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2133 = extractvalue { <8 x ptr>, <8 x i64> } %2131, 1
  %2134 = extractelement <8 x ptr> %2132, i32 0
  %2135 = extractelement <8 x i64> %2133, i32 0
  %2136 = sub i64 %2135, 0
  %2137 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2138 = select i1 %2137, i64 %2136, i64 0
  %private.contiguous.address407 = getelementptr i8, ptr %2134, i64 %2138
  %private.contiguous.preserve408 = load <8 x i64>, ptr %private.contiguous.address407, align 8
  %2139 = select <8 x i1> %101, <8 x i64> %2110, <8 x i64> %private.contiguous.preserve408
  store <8 x i64> %2139, ptr %private.contiguous.address407, align 8
  %2140 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2141 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %2142 = add <8 x i64> %2141, splat (i64 64)
  %2143 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2140, 0
  %2144 = insertvalue { <8 x ptr>, <8 x i64> } %2143, <8 x i64> %2142, 1
  %2145 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2146 = extractvalue { <8 x ptr>, <8 x i64> } %2144, 1
  %2147 = extractelement <8 x ptr> %2145, i32 0
  %2148 = extractelement <8 x i64> %2146, i32 0
  %2149 = sub i64 %2148, 0
  %2150 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2151 = select i1 %2150, i64 %2149, i64 0
  %private.contiguous.address409 = getelementptr i8, ptr %2147, i64 %2151
  %private.contiguous.preserve410 = load <8 x i64>, ptr %private.contiguous.address409, align 8
  %2152 = select <8 x i1> %101, <8 x i64> %2111, <8 x i64> %private.contiguous.preserve410
  store <8 x i64> %2152, ptr %private.contiguous.address409, align 8
  %2153 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2154 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %2155 = add <8 x i64> %2154, splat (i64 128)
  %2156 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2153, 0
  %2157 = insertvalue { <8 x ptr>, <8 x i64> } %2156, <8 x i64> %2155, 1
  %2158 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2159 = extractvalue { <8 x ptr>, <8 x i64> } %2157, 1
  %2160 = extractelement <8 x ptr> %2158, i32 0
  %2161 = extractelement <8 x i64> %2159, i32 0
  %2162 = sub i64 %2161, 0
  %2163 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2164 = select i1 %2163, i64 %2162, i64 0
  %private.contiguous.address411 = getelementptr i8, ptr %2160, i64 %2164
  %private.contiguous.preserve412 = load <8 x i64>, ptr %private.contiguous.address411, align 8
  %2165 = select <8 x i1> %101, <8 x i64> %2112, <8 x i64> %private.contiguous.preserve412
  store <8 x i64> %2165, ptr %private.contiguous.address411, align 8
  %2166 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2167 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %2168 = add <8 x i64> %2167, splat (i64 192)
  %2169 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2166, 0
  %2170 = insertvalue { <8 x ptr>, <8 x i64> } %2169, <8 x i64> %2168, 1
  %2171 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2172 = extractvalue { <8 x ptr>, <8 x i64> } %2170, 1
  %2173 = extractelement <8 x ptr> %2171, i32 0
  %2174 = extractelement <8 x i64> %2172, i32 0
  %2175 = sub i64 %2174, 0
  %2176 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2177 = select i1 %2176, i64 %2175, i64 0
  %private.contiguous.address413 = getelementptr i8, ptr %2173, i64 %2177
  %private.contiguous.preserve414 = load <8 x i64>, ptr %private.contiguous.address413, align 8
  %2178 = select <8 x i1> %101, <8 x i64> %2113, <8 x i64> %private.contiguous.preserve414
  store <8 x i64> %2178, ptr %private.contiguous.address413, align 8
  %2179 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2180 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %2181 = add <8 x i64> %2180, splat (i64 256)
  %2182 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2179, 0
  %2183 = insertvalue { <8 x ptr>, <8 x i64> } %2182, <8 x i64> %2181, 1
  %2184 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2185 = extractvalue { <8 x ptr>, <8 x i64> } %2183, 1
  %2186 = extractelement <8 x ptr> %2184, i32 0
  %2187 = extractelement <8 x i64> %2185, i32 0
  %2188 = sub i64 %2187, 0
  %2189 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2190 = select i1 %2189, i64 %2188, i64 0
  %private.contiguous.address415 = getelementptr i8, ptr %2186, i64 %2190
  %private.contiguous.preserve416 = load <8 x i64>, ptr %private.contiguous.address415, align 8
  %2191 = select <8 x i1> %101, <8 x i64> %2114, <8 x i64> %private.contiguous.preserve416
  store <8 x i64> %2191, ptr %private.contiguous.address415, align 8
  %2192 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2193 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %2194 = add <8 x i64> %2193, splat (i64 320)
  %2195 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2192, 0
  %2196 = insertvalue { <8 x ptr>, <8 x i64> } %2195, <8 x i64> %2194, 1
  %2197 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2198 = extractvalue { <8 x ptr>, <8 x i64> } %2196, 1
  %2199 = extractelement <8 x ptr> %2197, i32 0
  %2200 = extractelement <8 x i64> %2198, i32 0
  %2201 = sub i64 %2200, 0
  %2202 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2203 = select i1 %2202, i64 %2201, i64 0
  %private.contiguous.address417 = getelementptr i8, ptr %2199, i64 %2203
  %private.contiguous.preserve418 = load <8 x i64>, ptr %private.contiguous.address417, align 8
  %2204 = select <8 x i1> %101, <8 x i64> %2115, <8 x i64> %private.contiguous.preserve418
  store <8 x i64> %2204, ptr %private.contiguous.address417, align 8
  %2205 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2206 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %2207 = add <8 x i64> %2206, splat (i64 384)
  %2208 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2205, 0
  %2209 = insertvalue { <8 x ptr>, <8 x i64> } %2208, <8 x i64> %2207, 1
  %2210 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2211 = extractvalue { <8 x ptr>, <8 x i64> } %2209, 1
  %2212 = extractelement <8 x ptr> %2210, i32 0
  %2213 = extractelement <8 x i64> %2211, i32 0
  %2214 = sub i64 %2213, 0
  %2215 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2216 = select i1 %2215, i64 %2214, i64 0
  %private.contiguous.address419 = getelementptr i8, ptr %2212, i64 %2216
  %private.contiguous.preserve420 = load <8 x i64>, ptr %private.contiguous.address419, align 8
  %2217 = select <8 x i1> %101, <8 x i64> %2116, <8 x i64> %private.contiguous.preserve420
  store <8 x i64> %2217, ptr %private.contiguous.address419, align 8
  %2218 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2219 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %2220 = add <8 x i64> %2219, splat (i64 448)
  %2221 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2218, 0
  %2222 = insertvalue { <8 x ptr>, <8 x i64> } %2221, <8 x i64> %2220, 1
  %2223 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2224 = extractvalue { <8 x ptr>, <8 x i64> } %2222, 1
  %2225 = extractelement <8 x ptr> %2223, i32 0
  %2226 = extractelement <8 x i64> %2224, i32 0
  %2227 = sub i64 %2226, 0
  %2228 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  %2229 = select i1 %2228, i64 %2227, i64 0
  %private.contiguous.address421 = getelementptr i8, ptr %2225, i64 %2229
  %private.contiguous.preserve422 = load <8 x i64>, ptr %private.contiguous.address421, align 8
  %2230 = select <8 x i1> %101, <8 x i64> %2117, <8 x i64> %private.contiguous.preserve422
  store <8 x i64> %2230, ptr %private.contiguous.address421, align 8
  %2231 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill106, align 64
  %2232 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %2233 = extractvalue { <8 x ptr>, <8 x i64> } %2231, 0
  %2234 = select <8 x i1> %101, <8 x ptr> %2232, <8 x ptr> %2233
  %2235 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %2236 = extractvalue { <8 x ptr>, <8 x i64> } %2231, 1
  %2237 = select <8 x i1> %101, <8 x i64> %2235, <8 x i64> %2236
  %2238 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2234, 0
  %2239 = insertvalue { <8 x ptr>, <8 x i64> } %2238, <8 x i64> %2237, 1
  store { <8 x ptr>, <8 x i64> } %2239, ptr %tile_snapshot.spill106, align 64
  store i64 0, ptr %.slot107, align 4
  br label %direct.schedule.22

direct.true424:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false425:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24

direct.true446:                                   ; preds = %direct.schedule.25
  br label %direct.schedule.26

direct.false447:                                  ; preds = %direct.schedule.25
  br label %direct.schedule.27

direct.true464:                                   ; preds = %direct.schedule.28
  br label %direct.schedule.29

direct.false465:                                  ; preds = %direct.schedule.28
  br label %direct.schedule.30

direct.true475:                                   ; preds = %direct.schedule.31
  br label %direct.schedule.32

direct.false476:                                  ; preds = %direct.schedule.31
  br label %direct.schedule.33

direct.true486:                                   ; preds = %direct.schedule.34
  br label %direct.schedule.35

direct.false487:                                  ; preds = %direct.schedule.34
  br label %direct.schedule.36

direct.true497:                                   ; preds = %direct.schedule.37
  br label %direct.schedule.38

direct.false498:                                  ; preds = %direct.schedule.37
  br label %direct.schedule.39

direct.true508:                                   ; preds = %direct.schedule.40
  br label %direct.schedule.41

direct.false509:                                  ; preds = %direct.schedule.40
  br label %direct.schedule.42

direct.true519:                                   ; preds = %direct.schedule.43
  br label %direct.schedule.44

direct.false520:                                  ; preds = %direct.schedule.43
  br label %direct.schedule.45

direct.true530:                                   ; preds = %direct.schedule.46
  br label %direct.schedule.47

direct.false531:                                  ; preds = %direct.schedule.46
  br label %direct.schedule.48

direct.true541:                                   ; preds = %direct.schedule.49
  br label %direct.schedule.50

direct.false542:                                  ; preds = %direct.schedule.49
  br label %direct.schedule.51

direct.true615:                                   ; preds = %direct.schedule.52
  br label %direct.schedule.53

direct.false616:                                  ; preds = %direct.schedule.52
  br label %direct.schedule.54

direct.true655:                                   ; preds = %direct.schedule.55
  br label %direct.schedule.56

direct.false656:                                  ; preds = %direct.schedule.55
  br label %direct.schedule.57

direct.true664:                                   ; preds = %direct.schedule.58
  br label %direct.schedule.59

direct.false665:                                  ; preds = %direct.schedule.58
  br label %direct.schedule.60

direct.true673:                                   ; preds = %direct.schedule.61
  br label %direct.schedule.62

direct.false674:                                  ; preds = %direct.schedule.61
  br label %direct.schedule.63

direct.true682:                                   ; preds = %direct.schedule.64
  br label %direct.schedule.65

direct.false683:                                  ; preds = %direct.schedule.64
  br label %direct.schedule.66

direct.true691:                                   ; preds = %direct.schedule.67
  br label %direct.schedule.68

direct.false692:                                  ; preds = %direct.schedule.67
  br label %direct.schedule.69

direct.true700:                                   ; preds = %direct.schedule.70
  br label %direct.schedule.71

direct.false701:                                  ; preds = %direct.schedule.70
  br label %direct.schedule.72

direct.true709:                                   ; preds = %direct.schedule.73
  br label %direct.schedule.74

direct.false710:                                  ; preds = %direct.schedule.73
  br label %direct.schedule.75

direct.true718:                                   ; preds = %direct.schedule.76
  br label %direct.schedule.77

direct.false719:                                  ; preds = %direct.schedule.76
  br label %direct.schedule.78

direct.true743:                                   ; preds = %direct.schedule.79
  br label %direct.schedule.80

direct.false744:                                  ; preds = %direct.schedule.79
  br label %direct.schedule.81

mma.active765:                                    ; preds = %direct.schedule.81
  %2240 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 0
  %2241 = extractelement <8 x ptr> %2240, i64 0
  %2242 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 1
  %2243 = extractelement <8 x i64> %2242, i64 0
  %2244 = getelementptr i8, ptr %2241, i64 %2243
  %2245 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 0
  %2246 = extractelement <8 x ptr> %2245, i64 0
  %2247 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 1
  %2248 = extractelement <8 x i64> %2247, i64 0
  %2249 = getelementptr i8, ptr %2246, i64 %2248
  %2250 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 0
  %2251 = extractelement <8 x ptr> %2250, i64 0
  %2252 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 1
  %2253 = extractelement <8 x i64> %2252, i64 0
  %2254 = getelementptr i8, ptr %2251, i64 %2253
  %2255 = extractvalue { <8 x ptr>, <8 x i64> } %50, 0
  %2256 = extractelement <8 x ptr> %2255, i64 0
  %2257 = extractvalue { <8 x ptr>, <8 x i64> } %50, 1
  %2258 = extractelement <8 x i64> %2257, i64 0
  %2259 = getelementptr i8, ptr %2256, i64 %2258
  call void @llm_attention.strided_mma.1(ptr %2244, ptr %2249, ptr %2254, ptr %2259)
  br label %mma.continue766

mma.continue766:                                  ; preds = %mma.active765, %direct.schedule.81
  %2260 = extractelement <8 x i1> %101, i64 1
  br i1 %2260, label %mma.active767, label %mma.continue768

mma.active767:                                    ; preds = %mma.continue766
  %2261 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 0
  %2262 = extractelement <8 x ptr> %2261, i64 1
  %2263 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 1
  %2264 = extractelement <8 x i64> %2263, i64 1
  %2265 = getelementptr i8, ptr %2262, i64 %2264
  %2266 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 0
  %2267 = extractelement <8 x ptr> %2266, i64 1
  %2268 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 1
  %2269 = extractelement <8 x i64> %2268, i64 1
  %2270 = getelementptr i8, ptr %2267, i64 %2269
  %2271 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 0
  %2272 = extractelement <8 x ptr> %2271, i64 1
  %2273 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 1
  %2274 = extractelement <8 x i64> %2273, i64 1
  %2275 = getelementptr i8, ptr %2272, i64 %2274
  %2276 = extractvalue { <8 x ptr>, <8 x i64> } %50, 0
  %2277 = extractelement <8 x ptr> %2276, i64 1
  %2278 = extractvalue { <8 x ptr>, <8 x i64> } %50, 1
  %2279 = extractelement <8 x i64> %2278, i64 1
  %2280 = getelementptr i8, ptr %2277, i64 %2279
  call void @llm_attention.strided_mma.1(ptr %2265, ptr %2270, ptr %2275, ptr %2280)
  br label %mma.continue768

mma.continue768:                                  ; preds = %mma.active767, %mma.continue766
  %2281 = extractelement <8 x i1> %101, i64 2
  br i1 %2281, label %mma.active769, label %mma.continue770

mma.active769:                                    ; preds = %mma.continue768
  %2282 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 0
  %2283 = extractelement <8 x ptr> %2282, i64 2
  %2284 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 1
  %2285 = extractelement <8 x i64> %2284, i64 2
  %2286 = getelementptr i8, ptr %2283, i64 %2285
  %2287 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 0
  %2288 = extractelement <8 x ptr> %2287, i64 2
  %2289 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 1
  %2290 = extractelement <8 x i64> %2289, i64 2
  %2291 = getelementptr i8, ptr %2288, i64 %2290
  %2292 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 0
  %2293 = extractelement <8 x ptr> %2292, i64 2
  %2294 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 1
  %2295 = extractelement <8 x i64> %2294, i64 2
  %2296 = getelementptr i8, ptr %2293, i64 %2295
  %2297 = extractvalue { <8 x ptr>, <8 x i64> } %50, 0
  %2298 = extractelement <8 x ptr> %2297, i64 2
  %2299 = extractvalue { <8 x ptr>, <8 x i64> } %50, 1
  %2300 = extractelement <8 x i64> %2299, i64 2
  %2301 = getelementptr i8, ptr %2298, i64 %2300
  call void @llm_attention.strided_mma.1(ptr %2286, ptr %2291, ptr %2296, ptr %2301)
  br label %mma.continue770

mma.continue770:                                  ; preds = %mma.active769, %mma.continue768
  %2302 = extractelement <8 x i1> %101, i64 3
  br i1 %2302, label %mma.active771, label %mma.continue772

mma.active771:                                    ; preds = %mma.continue770
  %2303 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 0
  %2304 = extractelement <8 x ptr> %2303, i64 3
  %2305 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 1
  %2306 = extractelement <8 x i64> %2305, i64 3
  %2307 = getelementptr i8, ptr %2304, i64 %2306
  %2308 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 0
  %2309 = extractelement <8 x ptr> %2308, i64 3
  %2310 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 1
  %2311 = extractelement <8 x i64> %2310, i64 3
  %2312 = getelementptr i8, ptr %2309, i64 %2311
  %2313 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 0
  %2314 = extractelement <8 x ptr> %2313, i64 3
  %2315 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 1
  %2316 = extractelement <8 x i64> %2315, i64 3
  %2317 = getelementptr i8, ptr %2314, i64 %2316
  %2318 = extractvalue { <8 x ptr>, <8 x i64> } %50, 0
  %2319 = extractelement <8 x ptr> %2318, i64 3
  %2320 = extractvalue { <8 x ptr>, <8 x i64> } %50, 1
  %2321 = extractelement <8 x i64> %2320, i64 3
  %2322 = getelementptr i8, ptr %2319, i64 %2321
  call void @llm_attention.strided_mma.1(ptr %2307, ptr %2312, ptr %2317, ptr %2322)
  br label %mma.continue772

mma.continue772:                                  ; preds = %mma.active771, %mma.continue770
  %2323 = extractelement <8 x i1> %101, i64 4
  br i1 %2323, label %mma.active773, label %mma.continue774

mma.active773:                                    ; preds = %mma.continue772
  %2324 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 0
  %2325 = extractelement <8 x ptr> %2324, i64 4
  %2326 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 1
  %2327 = extractelement <8 x i64> %2326, i64 4
  %2328 = getelementptr i8, ptr %2325, i64 %2327
  %2329 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 0
  %2330 = extractelement <8 x ptr> %2329, i64 4
  %2331 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 1
  %2332 = extractelement <8 x i64> %2331, i64 4
  %2333 = getelementptr i8, ptr %2330, i64 %2332
  %2334 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 0
  %2335 = extractelement <8 x ptr> %2334, i64 4
  %2336 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 1
  %2337 = extractelement <8 x i64> %2336, i64 4
  %2338 = getelementptr i8, ptr %2335, i64 %2337
  %2339 = extractvalue { <8 x ptr>, <8 x i64> } %50, 0
  %2340 = extractelement <8 x ptr> %2339, i64 4
  %2341 = extractvalue { <8 x ptr>, <8 x i64> } %50, 1
  %2342 = extractelement <8 x i64> %2341, i64 4
  %2343 = getelementptr i8, ptr %2340, i64 %2342
  call void @llm_attention.strided_mma.1(ptr %2328, ptr %2333, ptr %2338, ptr %2343)
  br label %mma.continue774

mma.continue774:                                  ; preds = %mma.active773, %mma.continue772
  %2344 = extractelement <8 x i1> %101, i64 5
  br i1 %2344, label %mma.active775, label %mma.continue776

mma.active775:                                    ; preds = %mma.continue774
  %2345 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 0
  %2346 = extractelement <8 x ptr> %2345, i64 5
  %2347 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 1
  %2348 = extractelement <8 x i64> %2347, i64 5
  %2349 = getelementptr i8, ptr %2346, i64 %2348
  %2350 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 0
  %2351 = extractelement <8 x ptr> %2350, i64 5
  %2352 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 1
  %2353 = extractelement <8 x i64> %2352, i64 5
  %2354 = getelementptr i8, ptr %2351, i64 %2353
  %2355 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 0
  %2356 = extractelement <8 x ptr> %2355, i64 5
  %2357 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 1
  %2358 = extractelement <8 x i64> %2357, i64 5
  %2359 = getelementptr i8, ptr %2356, i64 %2358
  %2360 = extractvalue { <8 x ptr>, <8 x i64> } %50, 0
  %2361 = extractelement <8 x ptr> %2360, i64 5
  %2362 = extractvalue { <8 x ptr>, <8 x i64> } %50, 1
  %2363 = extractelement <8 x i64> %2362, i64 5
  %2364 = getelementptr i8, ptr %2361, i64 %2363
  call void @llm_attention.strided_mma.1(ptr %2349, ptr %2354, ptr %2359, ptr %2364)
  br label %mma.continue776

mma.continue776:                                  ; preds = %mma.active775, %mma.continue774
  %2365 = extractelement <8 x i1> %101, i64 6
  br i1 %2365, label %mma.active777, label %mma.continue778

mma.active777:                                    ; preds = %mma.continue776
  %2366 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 0
  %2367 = extractelement <8 x ptr> %2366, i64 6
  %2368 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 1
  %2369 = extractelement <8 x i64> %2368, i64 6
  %2370 = getelementptr i8, ptr %2367, i64 %2369
  %2371 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 0
  %2372 = extractelement <8 x ptr> %2371, i64 6
  %2373 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 1
  %2374 = extractelement <8 x i64> %2373, i64 6
  %2375 = getelementptr i8, ptr %2372, i64 %2374
  %2376 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 0
  %2377 = extractelement <8 x ptr> %2376, i64 6
  %2378 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 1
  %2379 = extractelement <8 x i64> %2378, i64 6
  %2380 = getelementptr i8, ptr %2377, i64 %2379
  %2381 = extractvalue { <8 x ptr>, <8 x i64> } %50, 0
  %2382 = extractelement <8 x ptr> %2381, i64 6
  %2383 = extractvalue { <8 x ptr>, <8 x i64> } %50, 1
  %2384 = extractelement <8 x i64> %2383, i64 6
  %2385 = getelementptr i8, ptr %2382, i64 %2384
  call void @llm_attention.strided_mma.1(ptr %2370, ptr %2375, ptr %2380, ptr %2385)
  br label %mma.continue778

mma.continue778:                                  ; preds = %mma.active777, %mma.continue776
  %2386 = extractelement <8 x i1> %101, i64 7
  br i1 %2386, label %mma.active779, label %mma.continue780

mma.active779:                                    ; preds = %mma.continue778
  %2387 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 0
  %2388 = extractelement <8 x ptr> %2387, i64 7
  %2389 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 1
  %2390 = extractelement <8 x i64> %2389, i64 7
  %2391 = getelementptr i8, ptr %2388, i64 %2390
  %2392 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 0
  %2393 = extractelement <8 x ptr> %2392, i64 7
  %2394 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 1
  %2395 = extractelement <8 x i64> %2394, i64 7
  %2396 = getelementptr i8, ptr %2393, i64 %2395
  %2397 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 0
  %2398 = extractelement <8 x ptr> %2397, i64 7
  %2399 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 1
  %2400 = extractelement <8 x i64> %2399, i64 7
  %2401 = getelementptr i8, ptr %2398, i64 %2400
  %2402 = extractvalue { <8 x ptr>, <8 x i64> } %50, 0
  %2403 = extractelement <8 x ptr> %2402, i64 7
  %2404 = extractvalue { <8 x ptr>, <8 x i64> } %50, 1
  %2405 = extractelement <8 x i64> %2404, i64 7
  %2406 = getelementptr i8, ptr %2403, i64 %2405
  call void @llm_attention.strided_mma.1(ptr %2391, ptr %2396, ptr %2401, ptr %2406)
  br label %mma.continue780

mma.continue780:                                  ; preds = %mma.active779, %mma.continue778
  store i64 0, ptr %.slot181, align 4
  br label %direct.schedule.82

direct.true782:                                   ; preds = %direct.schedule.82
  br label %direct.schedule.83

direct.false783:                                  ; preds = %direct.schedule.82
  br label %direct.schedule.84

direct.true796:                                   ; preds = %direct.schedule.85
  br label %direct.schedule.86

direct.false797:                                  ; preds = %direct.schedule.85
  br label %direct.schedule.87

direct.true853:                                   ; preds = %direct.schedule.89
  br label %direct.schedule.90

direct.false854:                                  ; preds = %direct.schedule.89
  br label %direct.schedule.91
}

define internal void @llm_attention.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_attention.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_attention.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #3 = { nounwind willreturn "fp-contract"="off" }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }

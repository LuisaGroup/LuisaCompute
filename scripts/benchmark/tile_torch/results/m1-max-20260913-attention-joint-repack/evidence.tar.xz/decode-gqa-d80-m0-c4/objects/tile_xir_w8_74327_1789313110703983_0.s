	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention.full_packet
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention.full_packet:             ; @llm_attention.full_packet
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #2160
	mov	x9, #0                          ; =0x0
	ldr	x13, [x1, #136]
	add	x20, x13, #12, lsl #12          ; =49152
	ldr	x8, [x0]
	ldr	x14, [x0, #16]
	ldr	x23, [x0, #32]
	ldr	x10, [x0, #48]
	str	x10, [sp, #8]                   ; 8-byte Spill
	ldr	w10, [x1]
	ldr	w11, [x1, #36]
	add	w10, w11, w10, lsl #5
	dup.4s	v0, w10
Lloh0:
	adrp	x10, lCPI0_0@PAGE
Lloh1:
	ldr	q1, [x10, lCPI0_0@PAGEOFF]
	add.4s	v3, v0, v1
Lloh2:
	adrp	x10, lCPI0_1@PAGE
Lloh3:
	ldr	q1, [x10, lCPI0_1@PAGEOFF]
	add.4s	v1, v0, v1
	ushll2.2d	v2, v1, #0
	ushll2.2d	v0, v3, #0
	stp	q0, q2, [sp, #48]               ; 32-byte Folded Spill
	ushll.2d	v2, v1, #0
	ushll.2d	v0, v3, #0
	stp	q0, q2, [sp, #16]               ; 32-byte Folded Spill
	movi.4s	v2, #80
	umull2.2d	v0, v1, v2
	umull2.2d	v2, v3, v2
	movi.2s	v4, #80
	umull.2d	v1, v1, v4
	umull.2d	v3, v3, v4
	fmov	x10, d3
	add	x10, x8, x10, lsl #2
	add	x11, x13, #64
LBB0_1:                                 ; %copy.chunk.i
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q4, [x10, x9]
	stur	s4, [x11, #-64]
	mov	s5, v4[1]
	stur	s5, [x11, #-32]
	st1.s	{ v4 }[2], [x11]
	add	x12, x11, #32
	st1.s	{ v4 }[3], [x12]
	add	x9, x9, #16
	add	x11, x11, #128
	cmp	x9, #320
	b.ne	LBB0_1
; %bb.2:                                ; %llm_attention.contiguous_copy.exit
	mov	x9, #0                          ; =0x0
	mov.d	x10, v3[1]
	add	x10, x8, x10, lsl #2
	add	x11, x13, #68
LBB0_3:                                 ; %copy.chunk.i339
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q3, [x10, x9]
	stur	s3, [x11, #-64]
	mov	s4, v3[1]
	stur	s4, [x11, #-32]
	st1.s	{ v3 }[2], [x11]
	add	x12, x11, #32
	st1.s	{ v3 }[3], [x12]
	add	x9, x9, #16
	add	x11, x11, #128
	cmp	x9, #320
	b.ne	LBB0_3
; %bb.4:                                ; %llm_attention.contiguous_copy.exit344
	mov	x9, #0                          ; =0x0
	fmov	x10, d2
	add	x10, x8, x10, lsl #2
	add	x11, x13, #72
LBB0_5:                                 ; %copy.chunk.i345
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q3, [x10, x9]
	stur	s3, [x11, #-64]
	mov	s4, v3[1]
	stur	s4, [x11, #-32]
	st1.s	{ v3 }[2], [x11]
	add	x12, x11, #32
	st1.s	{ v3 }[3], [x12]
	add	x9, x9, #16
	add	x11, x11, #128
	cmp	x9, #320
	b.ne	LBB0_5
; %bb.6:                                ; %llm_attention.contiguous_copy.exit350
	mov	x9, #0                          ; =0x0
	mov.d	x10, v2[1]
	add	x10, x8, x10, lsl #2
	add	x11, x13, #76
LBB0_7:                                 ; %copy.chunk.i351
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q2, [x10, x9]
	stur	s2, [x11, #-64]
	mov	s3, v2[1]
	stur	s3, [x11, #-32]
	st1.s	{ v2 }[2], [x11]
	add	x12, x11, #32
	st1.s	{ v2 }[3], [x12]
	add	x9, x9, #16
	add	x11, x11, #128
	cmp	x9, #320
	b.ne	LBB0_7
; %bb.8:                                ; %llm_attention.contiguous_copy.exit356
	mov	x9, #0                          ; =0x0
	fmov	x10, d1
	add	x10, x8, x10, lsl #2
	add	x11, x13, #80
LBB0_9:                                 ; %copy.chunk.i357
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q2, [x10, x9]
	stur	s2, [x11, #-64]
	mov	s3, v2[1]
	stur	s3, [x11, #-32]
	st1.s	{ v2 }[2], [x11]
	add	x12, x11, #32
	st1.s	{ v2 }[3], [x12]
	add	x9, x9, #16
	add	x11, x11, #128
	cmp	x9, #320
	b.ne	LBB0_9
; %bb.10:                               ; %llm_attention.contiguous_copy.exit362
	mov	x9, #0                          ; =0x0
	mov.d	x10, v1[1]
	add	x10, x8, x10, lsl #2
	add	x11, x13, #84
LBB0_11:                                ; %copy.chunk.i363
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q1, [x10, x9]
	stur	s1, [x11, #-64]
	mov	s2, v1[1]
	stur	s2, [x11, #-32]
	st1.s	{ v1 }[2], [x11]
	add	x12, x11, #32
	st1.s	{ v1 }[3], [x12]
	add	x9, x9, #16
	add	x11, x11, #128
	cmp	x9, #320
	b.ne	LBB0_11
; %bb.12:                               ; %llm_attention.contiguous_copy.exit368
	mov	x9, #0                          ; =0x0
	fmov	x10, d0
	add	x10, x8, x10, lsl #2
	add	x11, x13, #88
LBB0_13:                                ; %copy.chunk.i369
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q1, [x10, x9]
	stur	s1, [x11, #-64]
	mov	s2, v1[1]
	stur	s2, [x11, #-32]
	st1.s	{ v1 }[2], [x11]
	add	x12, x11, #32
	st1.s	{ v1 }[3], [x12]
	add	x9, x9, #16
	add	x11, x11, #128
	cmp	x9, #320
	b.ne	LBB0_13
; %bb.14:                               ; %llm_attention.contiguous_copy.exit374
	str	x14, [sp, #560]                 ; 8-byte Spill
	mov	x9, #0                          ; =0x0
	mov.d	x10, v0[1]
	add	x8, x8, x10, lsl #2
	add	x10, x13, #92
LBB0_15:                                ; %copy.chunk.i375
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q0, [x8, x9]
	stur	s0, [x10, #-64]
	mov	s1, v0[1]
	stur	s1, [x10, #-32]
	st1.s	{ v0 }[2], [x10]
	add	x11, x10, #32
	st1.s	{ v0 }[3], [x11]
	add	x9, x9, #16
	add	x10, x10, #128
	cmp	x9, #320
	b.ne	LBB0_15
; %bb.16:                               ; %direct.true.preheader
	add	x24, x13, #2560
	add	x0, x13, #2560
	mov	w1, #3072                       ; =0xc00
	mov	x21, x13
	bl	_bzero
	mov	x25, #0                         ; =0x0
	mov	w8, #8704                       ; =0x2200
	add	x26, x21, x8
	mov	w8, #49664                      ; =0xc200
	add	x27, x21, x8
	add	x8, x21, #24, lsl #12           ; =98304
	add	x19, x8, #1536
	ldp	q2, q0, [sp, #48]               ; 32-byte Folded Reload
	shrn.2s	v0, v0, #2
	ldp	q3, q1, [sp, #16]               ; 32-byte Folded Reload
	shrn.2s	v1, v1, #2
	shrn.2s	v2, v2, #2
	mov	w8, #2053                       ; =0x805
	shrn.2s	v3, v3, #2
	mov	w9, #8800                       ; =0x2260
	add	x9, x21, x9
	str	x9, [sp, #192]                  ; 8-byte Spill
	mov	w9, #8804                       ; =0x2264
	add	x9, x21, x9
	dup.2s	v4, w8
	mov	w8, #8808                       ; =0x2268
	add	x8, x21, x8
	stp	x8, x9, [sp, #176]              ; 16-byte Folded Spill
	umull.2d	v18, v3, v4
	mov	w8, #8812                       ; =0x226c
	add	x8, x21, x8
	str	x8, [sp, #168]                  ; 8-byte Spill
	umull.2d	v19, v2, v4
	mov	w8, #8816                       ; =0x2270
	add	x8, x21, x8
	str	x8, [sp, #160]                  ; 8-byte Spill
	umull.2d	v20, v1, v4
	mov	w8, #8820                       ; =0x2274
	add	x8, x21, x8
	str	x8, [sp, #152]                  ; 8-byte Spill
	umull.2d	v21, v0, v4
	mov	w8, #8824                       ; =0x2278
	add	x8, x21, x8
	str	x8, [sp, #144]                  ; 8-byte Spill
	mov	w8, #8828                       ; =0x227c
	add	x8, x21, x8
	str	x8, [sp, #136]                  ; 8-byte Spill
	add	x8, x20, #608
	str	x8, [sp, #568]                  ; 8-byte Spill
	add	x9, x20, #612
	add	x8, x20, #616
	stp	x8, x9, [sp, #120]              ; 16-byte Folded Spill
	add	x9, x20, #620
	add	x8, x20, #624
	stp	x8, x9, [sp, #104]              ; 16-byte Folded Spill
	add	x9, x20, #628
	mov	w8, #62154                      ; =0xf2ca
	movk	w8, #61769, lsl #16
	dup.4s	v1, w8
	add	x8, x20, #632
	stp	x8, x9, [sp, #88]               ; 16-byte Folded Spill
	add	x8, x20, #636
	str	x8, [sp, #80]                   ; 8-byte Spill
	ldr	x16, [sp, #560]                 ; 8-byte Reload
	dup.2d	v22, x16
	add	x8, x21, #24, lsl #12           ; =98304
	add	x9, x8, #512
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #544
	stp	x8, x9, [sp, #448]              ; 16-byte Folded Spill
	add	x8, x21, #24, lsl #12           ; =98304
	add	x9, x8, #576
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #608
	stp	x8, x9, [sp, #432]              ; 16-byte Folded Spill
	add	x8, x21, #24, lsl #12           ; =98304
	add	x9, x8, #640
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #672
	stp	x8, x9, [sp, #416]              ; 16-byte Folded Spill
	add	x8, x21, #24, lsl #12           ; =98304
	add	x9, x8, #704
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #736
	stp	x8, x9, [sp, #400]              ; 16-byte Folded Spill
	add	x8, x21, #24, lsl #12           ; =98304
	add	x9, x8, #768
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #800
	stp	x8, x9, [sp, #384]              ; 16-byte Folded Spill
	add	x8, x21, #24, lsl #12           ; =98304
	add	x9, x8, #832
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #864
	stp	x8, x9, [sp, #368]              ; 16-byte Folded Spill
	add	x8, x21, #24, lsl #12           ; =98304
	add	x9, x8, #896
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #928
	stp	x8, x9, [sp, #352]              ; 16-byte Folded Spill
	add	x8, x21, #24, lsl #12           ; =98304
	add	x9, x8, #960
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #992
	stp	x8, x9, [sp, #336]              ; 16-byte Folded Spill
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	str	q0, [sp, #320]                  ; 16-byte Spill
	add	x8, x21, #24, lsl #12           ; =98304
	add	x9, x8, #1056
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #1088
	stp	x8, x9, [sp, #304]              ; 16-byte Folded Spill
	add	x8, x21, #24, lsl #12           ; =98304
	add	x9, x8, #1120
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #1152
	stp	x8, x9, [sp, #288]              ; 16-byte Folded Spill
	add	x8, x21, #24, lsl #12           ; =98304
	add	x9, x8, #1184
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #1216
	stp	x8, x9, [sp, #272]              ; 16-byte Folded Spill
	add	x8, x21, #24, lsl #12           ; =98304
	add	x9, x8, #1248
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #1280
	stp	x8, x9, [sp, #256]              ; 16-byte Folded Spill
	add	x8, x21, #24, lsl #12           ; =98304
	add	x9, x8, #1312
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #1344
	stp	x8, x9, [sp, #240]              ; 16-byte Folded Spill
	add	x8, x21, #24, lsl #12           ; =98304
	add	x9, x8, #1376
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #1408
	stp	x8, x9, [sp, #224]              ; 16-byte Folded Spill
	add	x8, x21, #24, lsl #12           ; =98304
	add	x9, x8, #1440
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #1472
	stp	x8, x9, [sp, #208]              ; 16-byte Folded Spill
	add	x8, x21, #24, lsl #12           ; =98304
	add	x8, x8, #1504
	str	x8, [sp, #200]                  ; 8-byte Spill
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	mov.16b	v0, v1
	mov	w8, #33792                      ; =0x8400
	movk	w8, #1, lsl #16
	str	x21, [sp, #552]                 ; 8-byte Spill
	add	x28, x21, x8
	mov	w0, #52429                      ; =0xcccd
	mov	w1, #80                         ; =0x50
	mov	w22, #43691                     ; =0xaaab
	mov	w2, #96                         ; =0x60
	mov	w21, #3                         ; =0x3
	stp	q19, q18, [sp, #512]            ; 32-byte Folded Spill
	stp	q21, q20, [sp, #480]            ; 32-byte Folded Spill
	str	q22, [sp, #464]                 ; 16-byte Spill
LBB0_17:                                ; %direct.true152
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_23 Depth 2
                                        ;     Child Loop BB0_25 Depth 2
                                        ;     Child Loop BB0_27 Depth 2
                                        ;     Child Loop BB0_29 Depth 2
                                        ;     Child Loop BB0_31 Depth 2
                                        ;     Child Loop BB0_33 Depth 2
                                        ;     Child Loop BB0_35 Depth 2
                                        ;     Child Loop BB0_37 Depth 2
                                        ;     Child Loop BB0_39 Depth 2
                                        ;     Child Loop BB0_41 Depth 2
                                        ;     Child Loop BB0_43 Depth 2
                                        ;     Child Loop BB0_45 Depth 2
                                        ;     Child Loop BB0_47 Depth 2
                                        ;     Child Loop BB0_49 Depth 2
                                        ;     Child Loop BB0_51 Depth 2
                                        ;     Child Loop BB0_53 Depth 2
                                        ;     Child Loop BB0_20 Depth 2
                                        ;     Child Loop BB0_69 Depth 2
                                        ;     Child Loop BB0_55 Depth 2
                                        ;     Child Loop BB0_57 Depth 2
                                        ;     Child Loop BB0_59 Depth 2
                                        ;     Child Loop BB0_61 Depth 2
                                        ;     Child Loop BB0_63 Depth 2
                                        ;       Child Loop BB0_64 Depth 3
	str	q0, [sp, #2080]                 ; 16-byte Spill
	str	q1, [sp, #2096]                 ; 16-byte Spill
	cmp	x25, #128
	b.ne	LBB0_22
; %bb.18:                               ; %direct.true752.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	x20, [sp, #552]                 ; 8-byte Reload
	b	LBB0_20
LBB0_19:                                ; %direct.schedule.49
                                        ;   in Loop: Header=BB0_20 Depth=2
	add	x9, x26, x8, lsl #5
	stp	q1, q0, [x9]
	add	x8, x8, #1
	cmp	x8, #1280
	b.eq	LBB0_67
LBB0_20:                                ; %direct.true752
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w9, w8, #0xffff
	mul	w9, w9, w0
	mov	w10, #2048                      ; =0x800
	bfxil	w10, w9, #22, #10
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	cmp	w10, #2052
	b.hi	LBB0_19
; %bb.21:                               ; %direct.true765
                                        ;   in Loop: Header=BB0_20 Depth=2
	lsr	w9, w9, #22
	dup.2d	v0, x10
	add.2d	v1, v0, v21
	add.2d	v2, v0, v20
	add.2d	v3, v0, v19
	add.2d	v0, v0, v18
	mov.d	x10, v0[1]
	fmov	x11, d0
	add	x11, x11, x11, lsl #2
	lsl	x11, x11, #4
	fmov	d0, x11
	add	x10, x10, x10, lsl #2
	lsl	x10, x10, #4
	mov.d	v0[1], x10
	mov.d	x10, v3[1]
	fmov	x11, d3
	add	x11, x11, x11, lsl #2
	lsl	x11, x11, #4
	fmov	d3, x11
	add	x10, x10, x10, lsl #2
	lsl	x10, x10, #4
	mov.d	v3[1], x10
	mov.d	x10, v2[1]
	fmov	x11, d2
	add	x11, x11, x11, lsl #2
	lsl	x11, x11, #4
	fmov	d2, x11
	add	x10, x10, x10, lsl #2
	lsl	x10, x10, #4
	mov.d	v2[1], x10
	mov.d	x10, v1[1]
	fmov	x11, d1
	add	x11, x11, x11, lsl #2
	lsl	x11, x11, #4
	fmov	d1, x11
	add	x10, x10, x10, lsl #2
	lsl	x10, x10, #4
	mov.d	v1[1], x10
	msub	w9, w9, w1, w8
	and	x9, x9, #0xffff
	dup.2d	v4, x9
	add.2d	v1, v1, v4
	add.2d	v2, v2, v4
	add.2d	v3, v3, v4
	add.2d	v0, v0, v4
	shl.2d	v0, v0, #2
	shl.2d	v3, v3, #2
	shl.2d	v2, v2, #2
	shl.2d	v1, v1, #2
	add.2d	v1, v22, v1
	add.2d	v2, v22, v2
	add.2d	v3, v22, v3
	add.2d	v0, v22, v0
	mov.d	x9, v0[1]
	fmov	x10, d0
	mov.d	x11, v3[1]
	fmov	x12, d3
	mov.d	x13, v2[1]
	fmov	x14, d2
	mov.d	x15, v1[1]
	ldr	s0, [x14]
	ld1.s	{ v0 }[1], [x13]
	fmov	x13, d1
	ld1.s	{ v0 }[2], [x13]
	ld1.s	{ v0 }[3], [x15]
	ldr	s1, [x10]
	ld1.s	{ v1 }[1], [x9]
	ld1.s	{ v1 }[2], [x12]
	ld1.s	{ v1 }[3], [x11]
	b	LBB0_19
LBB0_22:                                ; %direct.true155
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x12, #0                         ; =0x0
	lsl	x8, x25, #4
	dup.2d	v1, x8
	add.2d	v0, v1, v21
	add.2d	v3, v1, v18
	add.2d	v2, v1, v19
	add.2d	v1, v1, v20
	fmov	x8, d1
	add	x8, x8, x8, lsl #2
	lsl	x8, x8, #4
	fmov	d5, x8
	mov.d	x8, v1[1]
	add	x9, x8, x8, lsl #2
	lsl	x9, x9, #4
	mov.d	v5[1], x9
	fmov	x9, d2
	add	x9, x9, x9, lsl #2
	lsl	x9, x9, #4
	fmov	d6, x9
	mov.d	x9, v2[1]
	add	x10, x9, x9, lsl #2
	lsl	x10, x10, #4
	mov.d	v6[1], x10
	fmov	x10, d3
	add	x13, x10, x10, lsl #2
	lsl	x10, x13, #4
	fmov	d7, x10
	mov.d	x11, v3[1]
	add	x10, x11, x11, lsl #2
	lsl	x10, x10, #4
	mov.d	v7[1], x10
	fmov	x10, d0
	add	x10, x10, x10, lsl #2
	lsl	x10, x10, #4
	fmov	d4, x10
	mov.d	x10, v0[1]
	add	x14, x10, x10, lsl #2
	lsl	x14, x14, #4
	mov.d	v4[1], x14
	add	x13, x16, x13, lsl #6
	ldr	x14, [sp, #192]                 ; 8-byte Reload
	ldr	x20, [sp, #552]                 ; 8-byte Reload
LBB0_23:                                ; %copy.chunk.i381
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q16, [x13, x12, lsl #4]
	stur	s16, [x14, #-96]
	mov	s17, v16[1]
	sub	x15, x14, #32
	st1.s	{ v16 }[2], [x15]
	stur	s17, [x14, #-64]
	st1.s	{ v16 }[3], [x14]
	add	x12, x12, #1
	add	x14, x14, #128
	cmp	x12, #320
	b.ne	LBB0_23
; %bb.24:                               ; %llm_attention.contiguous_copy.1.exit
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x12, #0                         ; =0x0
	mov.d	x13, v7[1]
	add	x13, x16, x13, lsl #2
	ldr	x14, [sp, #184]                 ; 8-byte Reload
LBB0_25:                                ; %copy.chunk.i386
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q7, [x13, x12, lsl #4]
	stur	s7, [x14, #-96]
	mov	s16, v7[1]
	sub	x15, x14, #32
	st1.s	{ v7 }[2], [x15]
	stur	s16, [x14, #-64]
	st1.s	{ v7 }[3], [x14]
	add	x12, x12, #1
	add	x14, x14, #128
	cmp	x12, #320
	b.ne	LBB0_25
; %bb.26:                               ; %llm_attention.contiguous_copy.1.exit391
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x12, #0                         ; =0x0
	fmov	x13, d6
	add	x13, x16, x13, lsl #2
	ldr	x14, [sp, #176]                 ; 8-byte Reload
LBB0_27:                                ; %copy.chunk.i392
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q7, [x13, x12, lsl #4]
	stur	s7, [x14, #-96]
	mov	s16, v7[1]
	sub	x15, x14, #32
	st1.s	{ v7 }[2], [x15]
	stur	s16, [x14, #-64]
	st1.s	{ v7 }[3], [x14]
	add	x12, x12, #1
	add	x14, x14, #128
	cmp	x12, #320
	b.ne	LBB0_27
; %bb.28:                               ; %llm_attention.contiguous_copy.1.exit397
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x12, #0                         ; =0x0
	mov.d	x13, v6[1]
	add	x13, x16, x13, lsl #2
	ldr	x14, [sp, #168]                 ; 8-byte Reload
LBB0_29:                                ; %copy.chunk.i398
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q6, [x13, x12, lsl #4]
	stur	s6, [x14, #-96]
	mov	s7, v6[1]
	sub	x15, x14, #32
	st1.s	{ v6 }[2], [x15]
	stur	s7, [x14, #-64]
	st1.s	{ v6 }[3], [x14]
	add	x12, x12, #1
	add	x14, x14, #128
	cmp	x12, #320
	b.ne	LBB0_29
; %bb.30:                               ; %llm_attention.contiguous_copy.1.exit403
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x12, #0                         ; =0x0
	fmov	x13, d5
	add	x13, x16, x13, lsl #2
	ldr	x14, [sp, #160]                 ; 8-byte Reload
LBB0_31:                                ; %copy.chunk.i404
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q6, [x13, x12, lsl #4]
	stur	s6, [x14, #-96]
	mov	s7, v6[1]
	sub	x15, x14, #32
	st1.s	{ v6 }[2], [x15]
	stur	s7, [x14, #-64]
	st1.s	{ v6 }[3], [x14]
	add	x12, x12, #1
	add	x14, x14, #128
	cmp	x12, #320
	b.ne	LBB0_31
; %bb.32:                               ; %llm_attention.contiguous_copy.1.exit409
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x12, #0                         ; =0x0
	mov.d	x13, v5[1]
	add	x13, x16, x13, lsl #2
	ldr	x14, [sp, #152]                 ; 8-byte Reload
LBB0_33:                                ; %copy.chunk.i410
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q5, [x13, x12, lsl #4]
	stur	s5, [x14, #-96]
	mov	s6, v5[1]
	sub	x15, x14, #32
	st1.s	{ v5 }[2], [x15]
	stur	s6, [x14, #-64]
	st1.s	{ v5 }[3], [x14]
	add	x12, x12, #1
	add	x14, x14, #128
	cmp	x12, #320
	b.ne	LBB0_33
; %bb.34:                               ; %llm_attention.contiguous_copy.1.exit415
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x12, #0                         ; =0x0
	fmov	x13, d4
	add	x13, x16, x13, lsl #2
	ldr	x14, [sp, #144]                 ; 8-byte Reload
LBB0_35:                                ; %copy.chunk.i416
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q5, [x13, x12, lsl #4]
	stur	s5, [x14, #-96]
	mov	s6, v5[1]
	sub	x15, x14, #32
	st1.s	{ v5 }[2], [x15]
	stur	s6, [x14, #-64]
	st1.s	{ v5 }[3], [x14]
	add	x12, x12, #1
	add	x14, x14, #128
	cmp	x12, #320
	b.ne	LBB0_35
; %bb.36:                               ; %llm_attention.contiguous_copy.1.exit421
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x12, #0                         ; =0x0
	mov.d	x13, v4[1]
	add	x13, x16, x13, lsl #2
	ldr	x14, [sp, #136]                 ; 8-byte Reload
LBB0_37:                                ; %copy.chunk.i422
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q4, [x13, x12, lsl #4]
	stur	s4, [x14, #-96]
	mov	s5, v4[1]
	sub	x15, x14, #32
	st1.s	{ v4 }[2], [x15]
	stur	s5, [x14, #-64]
	st1.s	{ v4 }[3], [x14]
	add	x12, x12, #1
	add	x14, x14, #128
	cmp	x12, #320
	b.ne	LBB0_37
; %bb.38:                               ; %direct.true181
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x12, #0                         ; =0x0
	fmov	x13, d3
	add	x13, x13, x13, lsl #1
	lsl	x14, x13, #5
	fmov	d3, x14
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #5
	mov.d	v3[1], x11
	fmov	x11, d2
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #5
	fmov	d2, x11
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #5
	mov.d	v2[1], x9
	fmov	x9, d1
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #5
	fmov	d1, x9
	add	x8, x8, x8, lsl #1
	lsl	x8, x8, #5
	mov.d	v1[1], x8
	fmov	x8, d0
	add	x8, x8, x8, lsl #1
	lsl	x8, x8, #5
	fmov	d0, x8
	add	x8, x10, x10, lsl #1
	lsl	x8, x8, #5
	mov.d	v0[1], x8
	ldr	x8, [sp, #568]                  ; 8-byte Reload
	add	x9, x23, x13, lsl #7
LBB0_39:                                ; %copy.chunk.i428
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q4, [x9, x12, lsl #4]
	stur	s4, [x8, #-96]
	mov	s5, v4[1]
	sub	x10, x8, #32
	st1.s	{ v4 }[2], [x10]
	stur	s5, [x8, #-64]
	st1.s	{ v4 }[3], [x8]
	add	x12, x12, #1
	add	x8, x8, #128
	cmp	x12, #384
	b.ne	LBB0_39
; %bb.40:                               ; %llm_attention.contiguous_copy.2.exit
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	mov.d	x9, v3[1]
	add	x9, x23, x9, lsl #2
	ldr	x10, [sp, #128]                 ; 8-byte Reload
LBB0_41:                                ; %copy.chunk.i433
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x9, x8, lsl #4]
	stur	s3, [x10, #-96]
	mov	s4, v3[1]
	sub	x11, x10, #32
	st1.s	{ v3 }[2], [x11]
	stur	s4, [x10, #-64]
	st1.s	{ v3 }[3], [x10]
	add	x8, x8, #1
	add	x10, x10, #128
	cmp	x8, #384
	b.ne	LBB0_41
; %bb.42:                               ; %llm_attention.contiguous_copy.2.exit438
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	fmov	x9, d2
	add	x9, x23, x9, lsl #2
	ldr	x10, [sp, #120]                 ; 8-byte Reload
LBB0_43:                                ; %copy.chunk.i439
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x9, x8, lsl #4]
	stur	s3, [x10, #-96]
	mov	s4, v3[1]
	sub	x11, x10, #32
	st1.s	{ v3 }[2], [x11]
	stur	s4, [x10, #-64]
	st1.s	{ v3 }[3], [x10]
	add	x8, x8, #1
	add	x10, x10, #128
	cmp	x8, #384
	b.ne	LBB0_43
; %bb.44:                               ; %llm_attention.contiguous_copy.2.exit444
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	mov.d	x9, v2[1]
	add	x9, x23, x9, lsl #2
	ldr	x10, [sp, #112]                 ; 8-byte Reload
LBB0_45:                                ; %copy.chunk.i445
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x9, x8, lsl #4]
	stur	s2, [x10, #-96]
	mov	s3, v2[1]
	sub	x11, x10, #32
	st1.s	{ v2 }[2], [x11]
	stur	s3, [x10, #-64]
	st1.s	{ v2 }[3], [x10]
	add	x8, x8, #1
	add	x10, x10, #128
	cmp	x8, #384
	b.ne	LBB0_45
; %bb.46:                               ; %llm_attention.contiguous_copy.2.exit450
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	fmov	x9, d1
	add	x9, x23, x9, lsl #2
	ldr	x10, [sp, #104]                 ; 8-byte Reload
LBB0_47:                                ; %copy.chunk.i451
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x9, x8, lsl #4]
	stur	s2, [x10, #-96]
	mov	s3, v2[1]
	sub	x11, x10, #32
	st1.s	{ v2 }[2], [x11]
	stur	s3, [x10, #-64]
	st1.s	{ v2 }[3], [x10]
	add	x8, x8, #1
	add	x10, x10, #128
	cmp	x8, #384
	b.ne	LBB0_47
; %bb.48:                               ; %llm_attention.contiguous_copy.2.exit456
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	mov.d	x9, v1[1]
	add	x9, x23, x9, lsl #2
	ldr	x10, [sp, #96]                  ; 8-byte Reload
LBB0_49:                                ; %copy.chunk.i457
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q1, [x9, x8, lsl #4]
	stur	s1, [x10, #-96]
	mov	s2, v1[1]
	sub	x11, x10, #32
	st1.s	{ v1 }[2], [x11]
	stur	s2, [x10, #-64]
	st1.s	{ v1 }[3], [x10]
	add	x8, x8, #1
	add	x10, x10, #128
	cmp	x8, #384
	b.ne	LBB0_49
; %bb.50:                               ; %llm_attention.contiguous_copy.2.exit462
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	fmov	x9, d0
	add	x9, x23, x9, lsl #2
	ldr	x10, [sp, #88]                  ; 8-byte Reload
LBB0_51:                                ; %copy.chunk.i463
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q1, [x9, x8, lsl #4]
	stur	s1, [x10, #-96]
	mov	s2, v1[1]
	sub	x11, x10, #32
	st1.s	{ v1 }[2], [x11]
	stur	s2, [x10, #-64]
	st1.s	{ v1 }[3], [x10]
	add	x8, x8, #1
	add	x10, x10, #128
	cmp	x8, #384
	b.ne	LBB0_51
; %bb.52:                               ; %llm_attention.contiguous_copy.2.exit468
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	mov.d	x9, v0[1]
	add	x9, x23, x9, lsl #2
	ldr	x10, [sp, #80]                  ; 8-byte Reload
LBB0_53:                                ; %copy.chunk.i469
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x9, x8, lsl #4]
	stur	s0, [x10, #-96]
	mov	s1, v0[1]
	sub	x11, x10, #32
	st1.s	{ v0 }[2], [x11]
	stur	s1, [x10, #-64]
	st1.s	{ v0 }[3], [x10]
	add	x8, x8, #1
	add	x10, x10, #128
	cmp	x8, #384
	b.ne	LBB0_53
LBB0_54:                                ; %direct.true208.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	str	q24, [sp, #1616]                ; 16-byte Spill
	str	q23, [sp, #1632]                ; 16-byte Spill
	movi.2d	v1, #0000000000000000
	mov	x8, x20
	movi.2d	v0, #0000000000000000
	mov	w9, #80                         ; =0x50
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
LBB0_55:                                ; %direct.true208
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q17, q16, [x8]
	ldr	q18, [x8, #8720]
	ldr	q19, [x8, #8704]
	fmul.4s	v19, v17, v19
	fmul.4s	v18, v16, v18
	fadd.4s	v1, v1, v18
	fadd.4s	v7, v7, v19
	ldr	q18, [x8, #11280]
	ldr	q19, [x8, #11264]
	fmul.4s	v19, v17, v19
	fmul.4s	v18, v16, v18
	fadd.4s	v6, v6, v18
	fadd.4s	v5, v5, v19
	ldr	q18, [x8, #13840]
	ldr	q19, [x8, #13824]
	fmul.4s	v19, v17, v19
	fmul.4s	v18, v16, v18
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v19
	ldr	q18, [x8, #16400]
	ldr	q19, [x8, #16384]
	fmul.4s	v17, v17, v19
	fmul.4s	v16, v16, v18
	fadd.4s	v2, v2, v16
	fadd.4s	v0, v0, v17
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_55
; %bb.56:                               ; %direct.true244.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	movi.2d	v17, #0000000000000000
	mov	x8, x20
	movi.2d	v16, #0000000000000000
	mov	w9, #80                         ; =0x50
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
LBB0_57:                                ; %direct.true244
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q25, q24, [x8]
	ldr	q26, [x8, #18960]
	ldr	q27, [x8, #18944]
	fmul.4s	v27, v25, v27
	fmul.4s	v26, v24, v26
	fadd.4s	v17, v17, v26
	fadd.4s	v23, v23, v27
	ldr	q26, [x8, #21520]
	ldr	q27, [x8, #21504]
	fmul.4s	v27, v25, v27
	fmul.4s	v26, v24, v26
	fadd.4s	v22, v22, v26
	fadd.4s	v21, v21, v27
	ldr	q26, [x8, #24080]
	ldr	q27, [x8, #24064]
	fmul.4s	v27, v25, v27
	fmul.4s	v26, v24, v26
	fadd.4s	v20, v20, v26
	fadd.4s	v19, v19, v27
	ldr	q26, [x8, #26640]
	ldr	q27, [x8, #26624]
	fmul.4s	v25, v25, v27
	fmul.4s	v24, v24, v26
	fadd.4s	v18, v18, v24
	fadd.4s	v16, v16, v25
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_57
; %bb.58:                               ; %direct.true282.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	str	q3, [sp, #2064]                 ; 16-byte Spill
	str	q2, [sp, #2112]                 ; 16-byte Spill
	str	q1, [sp, #2128]                 ; 16-byte Spill
	movi.2d	v25, #0000000000000000
	mov	x8, x20
	movi.2d	v24, #0000000000000000
	mov	w9, #80                         ; =0x50
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v31, #0000000000000000
LBB0_59:                                ; %direct.true282
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q9, q8, [x8]
	ldr	q10, [x8, #29200]
	ldr	q11, [x8, #29184]
	fmul.4s	v11, v9, v11
	fmul.4s	v10, v8, v10
	fadd.4s	v25, v25, v10
	fadd.4s	v31, v31, v11
	ldr	q10, [x8, #31760]
	ldr	q11, [x8, #31744]
	fmul.4s	v11, v9, v11
	fmul.4s	v10, v8, v10
	fadd.4s	v30, v30, v10
	fadd.4s	v29, v29, v11
	ldr	q10, [x8, #34320]
	ldr	q11, [x8, #34304]
	fmul.4s	v11, v9, v11
	fmul.4s	v10, v8, v10
	fadd.4s	v28, v28, v10
	fadd.4s	v27, v27, v11
	ldr	q10, [x8, #36880]
	ldr	q11, [x8, #36864]
	fmul.4s	v9, v9, v11
	fmul.4s	v8, v8, v10
	fadd.4s	v26, v26, v8
	fadd.4s	v24, v24, v9
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_59
; %bb.60:                               ; %direct.true320.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	str	q0, [sp, #2144]                 ; 16-byte Spill
	movi.2d	v9, #0000000000000000
	mov	x8, x20
	movi.2d	v8, #0000000000000000
	mov	w9, #80                         ; =0x50
	movi.2d	v10, #0000000000000000
	movi.2d	v11, #0000000000000000
	movi.2d	v12, #0000000000000000
	movi.2d	v13, #0000000000000000
	movi.2d	v14, #0000000000000000
	movi.2d	v15, #0000000000000000
LBB0_61:                                ; %direct.true320
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q1, q0, [x8]
	ldr	q2, [x8, #39440]
	ldr	q3, [x8, #39424]
	fmul.4s	v3, v1, v3
	fmul.4s	v2, v0, v2
	fadd.4s	v9, v9, v2
	fadd.4s	v15, v15, v3
	ldr	q2, [x8, #42000]
	ldr	q3, [x8, #41984]
	fmul.4s	v3, v1, v3
	fmul.4s	v2, v0, v2
	fadd.4s	v14, v14, v2
	fadd.4s	v13, v13, v3
	ldr	q2, [x8, #44560]
	ldr	q3, [x8, #44544]
	fmul.4s	v3, v1, v3
	fmul.4s	v2, v0, v2
	fadd.4s	v12, v12, v2
	fadd.4s	v11, v11, v3
	ldr	q2, [x8, #47120]
	ldr	q3, [x8, #47104]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v10, v10, v0
	fadd.4s	v8, v8, v1
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_61
; %bb.62:                               ; %direct.false321
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	mov	w9, #63790                      ; =0xf92e
	movk	w9, #15844, lsl #16
	dup.4s	v0, w9
	fmul.4s	v1, v7, v0
	str	q1, [sp, #1904]                 ; 16-byte Spill
	ldr	q1, [sp, #2128]                 ; 16-byte Reload
	fmul.4s	v1, v1, v0
	str	q1, [sp, #1728]                 ; 16-byte Spill
	fmul.4s	v1, v5, v0
	str	q1, [sp, #1712]                 ; 16-byte Spill
	fmul.4s	v1, v6, v0
	str	q1, [sp, #1696]                 ; 16-byte Spill
	ldr	q1, [sp, #2064]                 ; 16-byte Reload
	fmul.4s	v1, v1, v0
	str	q1, [sp, #1680]                 ; 16-byte Spill
	fmul.4s	v1, v4, v0
	str	q1, [sp, #1664]                 ; 16-byte Spill
	ldr	q1, [sp, #2144]                 ; 16-byte Reload
	fmul.4s	v1, v1, v0
	str	q1, [sp, #2144]                 ; 16-byte Spill
	ldr	q1, [sp, #2112]                 ; 16-byte Reload
	fmul.4s	v1, v1, v0
	str	q1, [sp, #1648]                 ; 16-byte Spill
	fmul.4s	v1, v23, v0
	str	q1, [sp, #2128]                 ; 16-byte Spill
	fmul.4s	v1, v17, v0
	str	q1, [sp, #2112]                 ; 16-byte Spill
	fmul.4s	v1, v22, v0
	fmul.4s	v2, v21, v0
	fmul.4s	v3, v20, v0
	fmul.4s	v5, v19, v0
	fmul.4s	v6, v18, v0
	fmul.4s	v7, v16, v0
	fmul.4s	v16, v25, v0
	fmul.4s	v17, v31, v0
	fmul.4s	v18, v30, v0
	fmul.4s	v19, v29, v0
	fmul.4s	v20, v28, v0
	fmul.4s	v21, v27, v0
	fmul.4s	v22, v26, v0
	fmul.4s	v23, v24, v0
	fmul.4s	v24, v9, v0
	fmul.4s	v25, v15, v0
	fmul.4s	v26, v14, v0
	fmul.4s	v27, v13, v0
	fmul.4s	v28, v12, v0
	fmul.4s	v29, v11, v0
	fmul.4s	v30, v10, v0
	fmul.4s	v0, v8, v0
	cmp	x25, #128
	cset	w9, lo
	dup.4h	v4, w9
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v8, v4, #0
	str	q8, [sp, #656]                  ; 16-byte Spill
	mov	w9, #62154                      ; =0xf2ca
	movk	w9, #61769, lsl #16
	dup.4s	v31, w9
	bif.16b	v2, v31, v8
	str	q2, [sp, #2064]                 ; 16-byte Spill
	mov.16b	v11, v8
	bsl.16b	v11, v1, v31
	mov.16b	v4, v8
	bsl.16b	v4, v5, v31
	str	q4, [sp, #1984]                 ; 16-byte Spill
	mov.16b	v10, v8
	bsl.16b	v10, v3, v31
	str	q10, [sp, #1744]                ; 16-byte Spill
	mov.16b	v3, v8
	bsl.16b	v3, v7, v31
	str	q3, [sp, #2048]                 ; 16-byte Spill
	mov.16b	v9, v8
	bsl.16b	v9, v6, v31
	str	q9, [sp, #1760]                 ; 16-byte Spill
	mov.16b	v5, v8
	bsl.16b	v5, v17, v31
	str	q5, [sp, #1968]                 ; 16-byte Spill
	bif.16b	v16, v31, v8
	str	q16, [sp, #1776]                ; 16-byte Spill
	mov.16b	v7, v8
	bsl.16b	v7, v19, v31
	str	q7, [sp, #2032]                 ; 16-byte Spill
	bif.16b	v18, v31, v8
	str	q18, [sp, #1792]                ; 16-byte Spill
	mov.16b	v17, v8
	bsl.16b	v17, v21, v31
	str	q17, [sp, #1952]                ; 16-byte Spill
	bif.16b	v20, v31, v8
	str	q20, [sp, #1808]                ; 16-byte Spill
	mov.16b	v19, v8
	bsl.16b	v19, v23, v31
	str	q19, [sp, #2016]                ; 16-byte Spill
	bif.16b	v22, v31, v8
	str	q22, [sp, #1824]                ; 16-byte Spill
	mov.16b	v21, v8
	bsl.16b	v21, v25, v31
	str	q21, [sp, #1936]                ; 16-byte Spill
	bif.16b	v24, v31, v8
	str	q24, [sp, #1840]                ; 16-byte Spill
	mov.16b	v23, v8
	bsl.16b	v23, v27, v31
	str	q23, [sp, #2000]                ; 16-byte Spill
	mov.16b	v27, v8
	bsl.16b	v27, v26, v31
	str	q27, [sp, #1856]                ; 16-byte Spill
	mov.16b	v25, v8
	bsl.16b	v25, v29, v31
	str	q25, [sp, #1920]                ; 16-byte Spill
	mov.16b	v6, v8
	bsl.16b	v6, v28, v31
	str	q6, [sp, #1872]                 ; 16-byte Spill
	mov.16b	v12, v8
	bsl.16b	v12, v0, v31
	str	q12, [sp, #1440]                ; 16-byte Spill
	bit.16b	v31, v30, v8
	str	q31, [sp, #1888]                ; 16-byte Spill
	mvni.4s	v26, #127, msl #16
	ldr	q1, [sp, #1904]                 ; 16-byte Reload
	fmaxnm.4s	v0, v1, v26
	ldr	q28, [sp, #1712]                ; 16-byte Reload
	fmaxnm.4s	v0, v0, v28
	ldr	q29, [sp, #1680]                ; 16-byte Reload
	fmaxnm.4s	v0, v0, v29
	ldr	q30, [sp, #2144]                ; 16-byte Reload
	fmaxnm.4s	v0, v0, v30
	ldr	q30, [sp, #2128]                ; 16-byte Reload
	fmaxnm.4s	v0, v0, v30
	fmaxnm.4s	v0, v0, v2
	fmaxnm.4s	v0, v0, v4
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v0, v0, v5
	fmaxnm.4s	v0, v0, v7
	fmaxnm.4s	v0, v0, v17
	fmaxnm.4s	v0, v0, v19
	fmaxnm.4s	v0, v0, v21
	fmaxnm.4s	v0, v0, v23
	fmaxnm.4s	v0, v0, v25
	fmaxnm.4s	v0, v0, v12
	ldr	q2, [sp, #2096]                 ; 16-byte Reload
	fmaxnm.4s	v12, v2, v0
	fsub.4s	v0, v1, v12
	mov	w9, #-1026555904                ; =0xc2d00000
	dup.4s	v1, w9
	fcmge.4s	v2, v0, v1
	mov	w9, #1120403456                 ; =0x42c80000
	dup.4s	v4, w9
	fcmge.4s	v3, v4, v0
	and.16b	v2, v2, v3
	ldr	q5, [sp, #1728]                 ; 16-byte Reload
	fmaxnm.4s	v3, v5, v26
	ldr	q13, [sp, #1696]                ; 16-byte Reload
	fmaxnm.4s	v3, v3, v13
	ldr	q14, [sp, #1664]                ; 16-byte Reload
	fmaxnm.4s	v3, v3, v14
	ldr	q15, [sp, #1648]                ; 16-byte Reload
	fmaxnm.4s	v3, v3, v15
	ldr	q7, [sp, #2112]                 ; 16-byte Reload
	fmaxnm.4s	v3, v3, v7
	fmaxnm.4s	v3, v3, v11
	str	q11, [sp, #1232]                ; 16-byte Spill
	fmaxnm.4s	v3, v3, v10
	fmaxnm.4s	v3, v3, v9
	fmaxnm.4s	v3, v3, v16
	fmaxnm.4s	v3, v3, v18
	fmaxnm.4s	v3, v3, v20
	fmaxnm.4s	v3, v3, v22
	fmaxnm.4s	v3, v3, v24
	fmaxnm.4s	v3, v3, v27
	fmaxnm.4s	v3, v3, v6
	fmaxnm.4s	v3, v3, v31
	ldr	q6, [sp, #2080]                 ; 16-byte Reload
	fmaxnm.4s	v30, v6, v3
	fsub.4s	v10, v5, v30
	fcmge.4s	v3, v10, v1
	fcmge.4s	v5, v4, v10
	and.16b	v3, v3, v5
	and.16b	v3, v3, v10
	mov	w9, #43579                      ; =0xaa3b
	movk	w9, #16312, lsl #16
	dup.4s	v21, w9
	fmul.4s	v5, v3, v21
	movi.4s	v7, #75, lsl #24
	mvni.4s	v16, #128, lsl #24
	mov.16b	v6, v16
	bsl.16b	v6, v7, v5
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	and.16b	v6, v2, v0
	fmul.4s	v2, v6, v21
	bif.16b	v7, v2, v16
	fadd.4s	v2, v2, v7
	fsub.4s	v7, v2, v7
	fcvtzs.4s	v2, v5
	scvtf.4s	v5, v2
	mov	w9, #29184                      ; =0x7200
	movk	w9, #16177, lsl #16
	dup.4s	v20, w9
	fmul.4s	v16, v5, v20
	fsub.4s	v16, v3, v16
	fcvtzs.4s	v3, v7
	scvtf.4s	v7, v3
	fmul.4s	v17, v7, v20
	mov	w9, #48782                      ; =0xbe8e
	movk	w9, #13759, lsl #16
	dup.4s	v19, w9
	fsub.4s	v6, v6, v17
	fmul.4s	v7, v7, v19
	fsub.4s	v22, v6, v7
	fmul.4s	v5, v5, v19
	mov	w9, #11226                      ; =0x2bda
	movk	w9, #14672, lsl #16
	dup.4s	v18, w9
	fsub.4s	v5, v16, v5
	fmul.4s	v6, v5, v18
	mov	w9, #38601                      ; =0x96c9
	movk	w9, #15030, lsl #16
	dup.4s	v17, w9
	fadd.4s	v6, v6, v17
	fmul.4s	v6, v5, v6
	mov	w9, #34982                      ; =0x88a6
	movk	w9, #15368, lsl #16
	dup.4s	v16, w9
	fadd.4s	v6, v6, v16
	fmul.4s	v6, v5, v6
	mov	w9, #43642                      ; =0xaa7a
	movk	w9, #15658, lsl #16
	dup.4s	v7, w9
	fadd.4s	v6, v6, v7
	fmul.4s	v23, v5, v6
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #15914, lsl #16
	dup.4s	v6, w9
	fadd.4s	v23, v23, v6
	fmul.4s	v23, v5, v23
	movi.4s	v31, #63, lsl #24
	fadd.4s	v23, v23, v31
	fmul.4s	v24, v5, v5
	fmul.4s	v23, v24, v23
	fmul.4s	v24, v22, v18
	fadd.4s	v24, v24, v17
	fmul.4s	v24, v22, v24
	fadd.4s	v24, v24, v16
	fmul.4s	v24, v22, v24
	fadd.4s	v24, v24, v7
	fmul.4s	v24, v22, v24
	fadd.4s	v24, v24, v6
	fmul.4s	v24, v22, v24
	fadd.4s	v24, v24, v31
	fmul.4s	v25, v22, v22
	fmul.4s	v24, v25, v24
	fadd.4s	v22, v22, v24
	fadd.4s	v5, v5, v23
	fmov.4s	v27, #1.00000000
	fadd.4s	v22, v22, v27
	sshr.4s	v23, v3, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v27
	fmul.4s	v22, v22, v24
	fadd.4s	v5, v5, v27
	sshr.4s	v24, v2, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v27
	fmul.4s	v5, v5, v25
	sub.4s	v3, v3, v23
	sub.4s	v2, v2, v24
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v5, v2
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v22, v3
	str	q0, [sp, #1520]                 ; 16-byte Spill
	fcmgt.4s	v5, v1, v0
	bic.16b	v3, v3, v5
	str	q10, [sp, #1568]                ; 16-byte Spill
	fcmgt.4s	v5, v1, v10
	bic.16b	v2, v2, v5
	fcmgt.4s	v22, v10, v4
	fneg.4s	v5, v26
	bit.16b	v2, v5, v22
	str	q2, [sp, #1552]                 ; 16-byte Spill
	fcmgt.4s	v2, v0, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #1536]                 ; 16-byte Spill
	fsub.4s	v28, v28, v12
	fcmge.4s	v2, v28, v1
	fcmge.4s	v3, v4, v28
	and.16b	v2, v2, v3
	fsub.4s	v10, v13, v30
	fcmge.4s	v3, v10, v1
	fcmge.4s	v22, v4, v10
	and.16b	v3, v3, v22
	and.16b	v3, v3, v10
	fmul.4s	v22, v3, v21
	movi.4s	v0, #75, lsl #24
	mvni.4s	v24, #128, lsl #24
	mov.16b	v23, v24
	bsl.16b	v23, v0, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v28
	fmul.4s	v2, v23, v21
	bsl.16b	v24, v0, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v20
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v20
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v19
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v18
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v31
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v27
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v27
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v27
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v27
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v22, v3
	str	q28, [sp, #1456]                ; 16-byte Spill
	fcmgt.4s	v22, v1, v28
	bic.16b	v3, v3, v22
	str	q10, [sp, #1488]                ; 16-byte Spill
	fcmgt.4s	v22, v1, v10
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v10, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #1504]                 ; 16-byte Spill
	fcmgt.4s	v2, v28, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #1472]                 ; 16-byte Spill
	fsub.4s	v28, v29, v12
	fcmge.4s	v2, v28, v1
	fcmge.4s	v3, v4, v28
	and.16b	v2, v2, v3
	fsub.4s	v0, v14, v30
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v21
	movi.4s	v24, #75, lsl #24
	mvni.4s	v25, #128, lsl #24
	mov.16b	v23, v25
	bsl.16b	v23, v24, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v28
	fmul.4s	v2, v23, v21
	bif.16b	v24, v2, v25
	mvni.4s	v29, #128, lsl #24
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v20
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v20
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v19
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v18
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v31
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v27
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v27
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v27
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v27
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v22, v3
	str	q28, [sp, #1376]                ; 16-byte Spill
	fcmgt.4s	v22, v1, v28
	bic.16b	v3, v3, v22
	str	q0, [sp, #1408]                 ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #1424]                 ; 16-byte Spill
	fcmgt.4s	v2, v28, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #1392]                 ; 16-byte Spill
	ldr	q0, [sp, #2144]                 ; 16-byte Reload
	fsub.4s	v28, v0, v12
	fcmge.4s	v2, v28, v1
	fcmge.4s	v3, v4, v28
	and.16b	v2, v2, v3
	fsub.4s	v0, v15, v30
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v21
	movi.4s	v24, #75, lsl #24
	mov.16b	v23, v29
	bsl.16b	v23, v24, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v28
	fmul.4s	v2, v23, v21
	bif.16b	v24, v2, v29
	movi.4s	v9, #75, lsl #24
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v20
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v20
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v19
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v18
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v31
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v27
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v27
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v27
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v27
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v22, v3
	str	q28, [sp, #1312]                ; 16-byte Spill
	fcmgt.4s	v22, v1, v28
	bic.16b	v3, v3, v22
	str	q0, [sp, #1344]                 ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #1360]                 ; 16-byte Spill
	fcmgt.4s	v2, v28, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #1328]                 ; 16-byte Spill
	ldr	q0, [sp, #2128]                 ; 16-byte Reload
	fsub.4s	v28, v0, v12
	fcmge.4s	v2, v28, v1
	fcmge.4s	v3, v4, v28
	and.16b	v2, v2, v3
	ldr	q0, [sp, #2112]                 ; 16-byte Reload
	fsub.4s	v0, v0, v30
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v21
	mov.16b	v23, v29
	bsl.16b	v23, v9, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v28
	fmul.4s	v2, v23, v21
	mov.16b	v24, v29
	bsl.16b	v24, v9, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v20
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v20
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v19
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v18
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v31
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v27
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v27
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v27
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v27
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v22, v3
	str	q28, [sp, #1248]                ; 16-byte Spill
	fcmgt.4s	v22, v1, v28
	bic.16b	v3, v3, v22
	str	q0, [sp, #1280]                 ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #1296]                 ; 16-byte Spill
	fcmgt.4s	v2, v28, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #1264]                 ; 16-byte Spill
	fsub.4s	v28, v11, v30
	fcmge.4s	v2, v28, v1
	fcmge.4s	v3, v4, v28
	and.16b	v2, v2, v3
	ldr	q3, [sp, #2064]                 ; 16-byte Reload
	mov.16b	v9, v12
	fsub.4s	v29, v3, v12
	fcmge.4s	v3, v29, v1
	fcmge.4s	v22, v4, v29
	and.16b	v3, v3, v22
	and.16b	v3, v3, v29
	fmul.4s	v22, v3, v21
	mvni.4s	v0, #128, lsl #24
	movi.4s	v24, #75, lsl #24
	mov.16b	v23, v0
	bsl.16b	v23, v24, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v28
	fmul.4s	v2, v23, v21
	bif.16b	v24, v2, v0
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v20
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v20
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v19
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v18
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v31
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v27
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v27
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v27
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v27
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v22, v3
	str	q28, [sp, #1168]                ; 16-byte Spill
	fcmgt.4s	v22, v1, v28
	bic.16b	v3, v3, v22
	str	q29, [sp, #1200]                ; 16-byte Spill
	fcmgt.4s	v22, v1, v29
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v29, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #1216]                 ; 16-byte Spill
	fcmgt.4s	v2, v28, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #1184]                 ; 16-byte Spill
	ldr	q0, [sp, #1744]                 ; 16-byte Reload
	fsub.4s	v28, v0, v30
	fcmge.4s	v2, v28, v1
	fcmge.4s	v3, v4, v28
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1984]                 ; 16-byte Reload
	fsub.4s	v0, v3, v12
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v21
	movi.4s	v24, #75, lsl #24
	mvni.4s	v25, #128, lsl #24
	mov.16b	v23, v25
	bsl.16b	v23, v24, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v28
	fmul.4s	v2, v23, v21
	bif.16b	v24, v2, v25
	mvni.4s	v29, #128, lsl #24
	movi.4s	v10, #75, lsl #24
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v20
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v20
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v19
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v18
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v31
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v27
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v27
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v27
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v27
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v22, v3
	str	q28, [sp, #1104]                ; 16-byte Spill
	fcmgt.4s	v22, v1, v28
	bic.16b	v3, v3, v22
	str	q0, [sp, #1136]                 ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #1152]                 ; 16-byte Spill
	fcmgt.4s	v2, v28, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #1120]                 ; 16-byte Spill
	ldr	q0, [sp, #1760]                 ; 16-byte Reload
	fsub.4s	v28, v0, v30
	fcmge.4s	v2, v28, v1
	fcmge.4s	v3, v4, v28
	and.16b	v2, v2, v3
	ldr	q3, [sp, #2048]                 ; 16-byte Reload
	fsub.4s	v0, v3, v12
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v21
	mov.16b	v23, v29
	bsl.16b	v23, v10, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v28
	fmul.4s	v2, v23, v21
	mov.16b	v24, v29
	bsl.16b	v24, v10, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v20
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v20
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v19
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v18
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v31
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v27
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v27
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v27
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v27
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v22, v3
	str	q28, [sp, #1040]                ; 16-byte Spill
	fcmgt.4s	v22, v1, v28
	bic.16b	v3, v3, v22
	str	q0, [sp, #1072]                 ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #1088]                 ; 16-byte Spill
	fcmgt.4s	v2, v28, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #1056]                 ; 16-byte Spill
	ldr	q0, [sp, #1776]                 ; 16-byte Reload
	fsub.4s	v28, v0, v30
	fcmge.4s	v2, v28, v1
	fcmge.4s	v3, v4, v28
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1968]                 ; 16-byte Reload
	fsub.4s	v29, v3, v12
	fcmge.4s	v3, v29, v1
	fcmge.4s	v22, v4, v29
	and.16b	v3, v3, v22
	and.16b	v3, v3, v29
	fmul.4s	v22, v3, v21
	mvni.4s	v0, #128, lsl #24
	movi.4s	v24, #75, lsl #24
	mov.16b	v23, v0
	bsl.16b	v23, v24, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v28
	fmul.4s	v2, v23, v21
	bif.16b	v24, v2, v0
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v20
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v20
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v19
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v18
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v31
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v27
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v27
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v27
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v27
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v22, v3
	fcmgt.4s	v22, v1, v28
	bic.16b	v3, v3, v22
	fcmgt.4s	v22, v1, v29
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v29, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	stp	q29, q0, [sp, #1008]            ; 32-byte Folded Spill
	fcmgt.4s	v2, v28, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	stp	q28, q0, [sp, #976]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1792]                 ; 16-byte Reload
	fsub.4s	v28, v0, v30
	fcmge.4s	v2, v28, v1
	fcmge.4s	v3, v4, v28
	and.16b	v2, v2, v3
	ldr	q3, [sp, #2032]                 ; 16-byte Reload
	fsub.4s	v0, v3, v12
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v21
	movi.4s	v24, #75, lsl #24
	mvni.4s	v25, #128, lsl #24
	mov.16b	v23, v25
	bsl.16b	v23, v24, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v28
	fmul.4s	v2, v23, v21
	bif.16b	v24, v2, v25
	mvni.4s	v29, #128, lsl #24
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v20
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v20
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v19
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v18
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v31
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v27
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v27
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v27
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v27
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v22, v3
	fcmgt.4s	v22, v1, v28
	bic.16b	v3, v3, v22
	str	q0, [sp, #944]                  ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #960]                  ; 16-byte Spill
	fcmgt.4s	v2, v28, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	stp	q28, q0, [sp, #912]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1808]                 ; 16-byte Reload
	fsub.4s	v28, v0, v30
	fcmge.4s	v2, v28, v1
	fcmge.4s	v3, v4, v28
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1952]                 ; 16-byte Reload
	fsub.4s	v0, v3, v12
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v21
	mov.16b	v23, v29
	bsl.16b	v23, v10, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v28
	fmul.4s	v2, v23, v21
	mov.16b	v24, v29
	bsl.16b	v24, v10, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v20
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v20
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v19
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v18
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v31
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v27
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v27
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v27
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v27
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v22, v3
	fcmgt.4s	v22, v1, v28
	bic.16b	v3, v3, v22
	str	q0, [sp, #880]                  ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #896]                  ; 16-byte Spill
	fcmgt.4s	v2, v28, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	stp	q28, q0, [sp, #848]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1824]                 ; 16-byte Reload
	fsub.4s	v28, v0, v30
	fcmge.4s	v2, v28, v1
	fcmge.4s	v3, v4, v28
	and.16b	v2, v2, v3
	ldr	q3, [sp, #2016]                 ; 16-byte Reload
	fsub.4s	v29, v3, v12
	fcmge.4s	v3, v29, v1
	fcmge.4s	v22, v4, v29
	and.16b	v3, v3, v22
	and.16b	v3, v3, v29
	fmul.4s	v22, v3, v21
	mvni.4s	v0, #128, lsl #24
	movi.4s	v24, #75, lsl #24
	mov.16b	v23, v0
	bsl.16b	v23, v24, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v28
	fmul.4s	v2, v23, v21
	bif.16b	v24, v2, v0
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v20
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v20
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v19
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v18
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v31
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v27
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v27
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v27
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v27
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v22, v3
	fcmgt.4s	v22, v1, v28
	bic.16b	v3, v3, v22
	fcmgt.4s	v22, v1, v29
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v29, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	stp	q29, q0, [sp, #816]             ; 32-byte Folded Spill
	fcmgt.4s	v2, v28, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	stp	q28, q0, [sp, #784]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1840]                 ; 16-byte Reload
	fsub.4s	v0, v0, v30
	fcmge.4s	v2, v0, v1
	fcmge.4s	v3, v4, v0
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1936]                 ; 16-byte Reload
	fsub.4s	v28, v3, v12
	fcmge.4s	v3, v28, v1
	fcmge.4s	v22, v4, v28
	and.16b	v3, v3, v22
	and.16b	v3, v3, v28
	fmul.4s	v22, v3, v21
	movi.4s	v24, #75, lsl #24
	mvni.4s	v25, #128, lsl #24
	mov.16b	v23, v25
	bsl.16b	v23, v24, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v0
	fmul.4s	v2, v23, v21
	bif.16b	v24, v2, v25
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v20
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v20
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v19
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v18
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v31
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v27
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v27
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v27
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v27
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v22, v3
	str	q0, [sp, #736]                  ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v3, v3, v22
	fcmgt.4s	v22, v1, v28
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v28, v4
	bit.16b	v2, v5, v22
	str	q2, [sp, #768]                  ; 16-byte Spill
	fcmgt.4s	v2, v0, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #752]                  ; 16-byte Spill
	ldr	q0, [sp, #1856]                 ; 16-byte Reload
	fsub.4s	v12, v0, v30
	fcmge.4s	v2, v12, v1
	fcmge.4s	v3, v4, v12
	and.16b	v2, v2, v3
	ldr	q3, [sp, #2000]                 ; 16-byte Reload
	fsub.4s	v26, v3, v9
	fcmge.4s	v3, v26, v1
	fcmge.4s	v22, v4, v26
	and.16b	v3, v3, v22
	and.16b	v3, v3, v26
	fmul.4s	v22, v3, v21
	mvni.4s	v0, #128, lsl #24
	movi.4s	v24, #75, lsl #24
	mov.16b	v23, v0
	bsl.16b	v23, v24, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v12
	fmul.4s	v2, v23, v21
	bif.16b	v24, v2, v0
	movi.4s	v29, #75, lsl #24
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v20
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v10, v25, v20
	fsub.4s	v23, v23, v10
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v19
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v18
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v31
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v10, v23, v23
	fmul.4s	v25, v10, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v27
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v27
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v27
	sshr.4s	v25, v2, #1
	shl.4s	v10, v25, #23
	add.4s	v10, v10, v27
	fmul.4s	v3, v3, v10
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v22, v3
	fcmgt.4s	v22, v1, v12
	bic.16b	v3, v3, v22
	fcmgt.4s	v22, v1, v26
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v26, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #720]                  ; 16-byte Spill
	fcmgt.4s	v2, v12, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #704]                  ; 16-byte Spill
	ldr	q0, [sp, #1872]                 ; 16-byte Reload
	fsub.4s	v25, v0, v30
	fcmge.4s	v2, v25, v1
	fcmge.4s	v3, v4, v25
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1920]                 ; 16-byte Reload
	fsub.4s	v24, v3, v9
	fcmge.4s	v3, v24, v1
	fcmge.4s	v22, v4, v24
	and.16b	v3, v3, v22
	and.16b	v3, v3, v24
	fmul.4s	v22, v3, v21
	mvni.4s	v0, #128, lsl #24
	mov.16b	v23, v0
	bsl.16b	v23, v29, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v25
	fmul.4s	v2, v23, v21
	mov.16b	v10, v0
	bsl.16b	v10, v29, v2
	fadd.4s	v2, v2, v10
	fsub.4s	v10, v2, v10
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v11, v22, v20
	fsub.4s	v3, v3, v11
	fcvtzs.4s	v10, v10
	scvtf.4s	v11, v10
	fmul.4s	v15, v11, v20
	fsub.4s	v23, v23, v15
	fmul.4s	v11, v11, v19
	fsub.4s	v23, v23, v11
	fmul.4s	v22, v22, v19
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v18
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v31
	fmul.4s	v11, v3, v3
	fmul.4s	v22, v11, v22
	fmul.4s	v11, v23, v18
	fadd.4s	v11, v11, v17
	fmul.4s	v11, v23, v11
	fadd.4s	v11, v11, v16
	fmul.4s	v11, v23, v11
	fadd.4s	v11, v11, v7
	fmul.4s	v11, v23, v11
	fadd.4s	v11, v11, v6
	fmul.4s	v11, v23, v11
	fadd.4s	v11, v11, v31
	fmul.4s	v15, v23, v23
	fmul.4s	v11, v15, v11
	fadd.4s	v23, v23, v11
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v27
	sshr.4s	v23, v10, #1
	shl.4s	v11, v23, #23
	add.4s	v11, v11, v27
	fmul.4s	v22, v22, v11
	fadd.4s	v3, v3, v27
	sshr.4s	v11, v2, #1
	shl.4s	v15, v11, #23
	add.4s	v15, v15, v27
	fmul.4s	v3, v3, v15
	sub.4s	v23, v10, v23
	sub.4s	v2, v2, v11
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v22, v3
	fcmgt.4s	v22, v1, v25
	bic.16b	v3, v3, v22
	fcmgt.4s	v22, v1, v24
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v24, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #688]                  ; 16-byte Spill
	fcmgt.4s	v2, v25, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #672]                  ; 16-byte Spill
	ldr	q0, [sp, #1888]                 ; 16-byte Reload
	fsub.4s	v23, v0, v30
	fcmge.4s	v2, v23, v1
	fcmge.4s	v3, v4, v23
	and.16b	v2, v2, v3
	ldr	q29, [sp, #1440]                ; 16-byte Reload
	fsub.4s	v22, v29, v9
	fcmge.4s	v3, v22, v1
	fcmge.4s	v10, v4, v22
	and.16b	v3, v3, v10
	and.16b	v3, v3, v22
	fmul.4s	v10, v3, v21
	movi.4s	v0, #75, lsl #24
	mvni.4s	v13, #128, lsl #24
	mov.16b	v11, v13
	bsl.16b	v11, v0, v10
	fadd.4s	v10, v10, v11
	fsub.4s	v10, v10, v11
	and.16b	v11, v2, v23
	fmul.4s	v2, v11, v21
	mov.16b	v15, v13
	bsl.16b	v15, v0, v2
	fadd.4s	v2, v2, v15
	fsub.4s	v15, v2, v15
	fcvtzs.4s	v2, v10
	scvtf.4s	v10, v2
	fmul.4s	v14, v10, v20
	fsub.4s	v3, v3, v14
	fcvtzs.4s	v14, v15
	scvtf.4s	v15, v14
	fmul.4s	v13, v15, v20
	fsub.4s	v11, v11, v13
	fmul.4s	v13, v15, v19
	fsub.4s	v11, v11, v13
	fmul.4s	v10, v10, v19
	fsub.4s	v3, v3, v10
	fmul.4s	v10, v3, v18
	fadd.4s	v10, v10, v17
	fmul.4s	v10, v3, v10
	fadd.4s	v10, v10, v16
	fmul.4s	v10, v3, v10
	fadd.4s	v10, v10, v7
	fmul.4s	v10, v3, v10
	fadd.4s	v10, v10, v6
	fmul.4s	v10, v3, v10
	fadd.4s	v10, v10, v31
	fmul.4s	v13, v3, v3
	fmul.4s	v10, v13, v10
	fmul.4s	v13, v11, v18
	fadd.4s	v13, v13, v17
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v13, v16
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v13, v7
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v13, v6
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v13, v31
	fmul.4s	v15, v11, v11
	fmul.4s	v13, v15, v13
	fadd.4s	v11, v11, v13
	fadd.4s	v3, v3, v10
	fadd.4s	v10, v11, v27
	sshr.4s	v11, v14, #1
	shl.4s	v13, v11, #23
	add.4s	v13, v13, v27
	fmul.4s	v10, v10, v13
	fadd.4s	v3, v3, v27
	sshr.4s	v13, v2, #1
	shl.4s	v15, v13, #23
	add.4s	v15, v15, v27
	fmul.4s	v3, v3, v15
	sub.4s	v11, v14, v11
	sub.4s	v2, v2, v13
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v11, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v10, v3
	fcmgt.4s	v10, v1, v23
	bic.16b	v3, v3, v10
	fcmgt.4s	v10, v1, v22
	bic.16b	v2, v2, v10
	fcmgt.4s	v10, v22, v4
	mov.16b	v0, v10
	bsl.16b	v0, v5, v2
	str	q0, [sp, #640]                  ; 16-byte Spill
	fcmgt.4s	v2, v23, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #624]                  ; 16-byte Spill
	str	q30, [sp, #1584]                ; 16-byte Spill
	ldr	q0, [sp, #2080]                 ; 16-byte Reload
	fsub.4s	v3, v0, v30
	fcmge.4s	v2, v3, v1
	fcmge.4s	v13, v4, v3
	and.16b	v13, v2, v13
	str	q9, [sp, #1600]                 ; 16-byte Spill
	ldr	q2, [sp, #2096]                 ; 16-byte Reload
	fsub.4s	v8, v2, v9
	fcmge.4s	v14, v8, v1
	fcmge.4s	v15, v4, v8
	and.16b	v14, v14, v15
	and.16b	v14, v14, v8
	fmul.4s	v15, v14, v21
	mvni.4s	v2, #128, lsl #24
	movi.4s	v30, #75, lsl #24
	mov.16b	v0, v2
	bsl.16b	v0, v30, v15
	fadd.4s	v15, v15, v0
	fsub.4s	v0, v15, v0
	and.16b	v13, v13, v3
	fmul.4s	v21, v13, v21
	mov.16b	v15, v2
	bsl.16b	v15, v30, v21
	fadd.4s	v21, v21, v15
	fsub.4s	v21, v21, v15
	fcvtzs.4s	v0, v0
	scvtf.4s	v15, v0
	fmul.4s	v11, v15, v20
	fsub.4s	v11, v14, v11
	fcvtzs.4s	v21, v21
	scvtf.4s	v14, v21
	fmul.4s	v20, v14, v20
	fsub.4s	v20, v13, v20
	fmul.4s	v13, v15, v19
	fmul.4s	v19, v14, v19
	fsub.4s	v19, v20, v19
	fsub.4s	v20, v11, v13
	fmul.4s	v11, v20, v18
	fmul.4s	v18, v19, v18
	fadd.4s	v18, v18, v17
	fadd.4s	v17, v11, v17
	fmul.4s	v17, v20, v17
	fmul.4s	v18, v19, v18
	fadd.4s	v18, v18, v16
	fadd.4s	v16, v17, v16
	fmul.4s	v16, v20, v16
	fmul.4s	v17, v19, v18
	fadd.4s	v17, v17, v7
	fadd.4s	v7, v16, v7
	fmul.4s	v7, v20, v7
	fmul.4s	v16, v19, v17
	fadd.4s	v16, v16, v6
	fadd.4s	v6, v7, v6
	fmul.4s	v6, v20, v6
	fadd.4s	v6, v6, v31
	fmul.4s	v7, v20, v20
	fmul.4s	v6, v7, v6
	fmul.4s	v7, v19, v16
	fadd.4s	v7, v7, v31
	fmul.4s	v16, v19, v19
	fmul.4s	v7, v16, v7
	fadd.4s	v7, v19, v7
	fadd.4s	v6, v20, v6
	fadd.4s	v7, v7, v27
	sshr.4s	v16, v21, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v27
	fmul.4s	v7, v7, v17
	fadd.4s	v6, v6, v27
	sshr.4s	v17, v0, #1
	shl.4s	v18, v17, #23
	add.4s	v18, v18, v27
	fmul.4s	v6, v6, v18
	sub.4s	v16, v21, v16
	sub.4s	v0, v0, v17
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v27
	fmul.4s	v0, v6, v0
	shl.4s	v6, v16, #23
	add.4s	v6, v6, v27
	fmul.4s	v6, v7, v6
	fcmgt.4s	v7, v1, v3
	bic.16b	v6, v6, v7
	fcmgt.4s	v1, v1, v8
	bic.16b	v0, v0, v1
	fcmgt.4s	v1, v8, v4
	bit.16b	v0, v5, v1
	str	q0, [sp, #608]                  ; 16-byte Spill
	fcmgt.4s	v1, v3, v4
	mov.16b	v0, v1
	bsl.16b	v0, v5, v6
	stp	q3, q0, [sp, #576]              ; 32-byte Folded Spill
	ldp	x9, x10, [sp, #448]             ; 16-byte Folded Reload
	ldr	q0, [sp, #1728]                 ; 16-byte Reload
	ldr	q4, [sp, #1904]                 ; 16-byte Reload
	stp	q4, q0, [x10]
	ldr	q0, [sp, #1696]                 ; 16-byte Reload
	ldr	q4, [sp, #1712]                 ; 16-byte Reload
	stp	q4, q0, [x9]
	ldp	x9, x10, [sp, #432]             ; 16-byte Folded Reload
	ldr	q0, [sp, #1664]                 ; 16-byte Reload
	ldr	q4, [sp, #1680]                 ; 16-byte Reload
	stp	q4, q0, [x10]
	ldr	q0, [sp, #1648]                 ; 16-byte Reload
	ldr	q4, [sp, #2144]                 ; 16-byte Reload
	stp	q4, q0, [x9]
	ldp	x9, x10, [sp, #416]             ; 16-byte Folded Reload
	ldr	q0, [sp, #2112]                 ; 16-byte Reload
	ldr	q4, [sp, #2128]                 ; 16-byte Reload
	stp	q4, q0, [x10]
	ldr	q0, [sp, #1232]                 ; 16-byte Reload
	ldr	q4, [sp, #2064]                 ; 16-byte Reload
	stp	q4, q0, [x9]
	ldp	x9, x10, [sp, #400]             ; 16-byte Folded Reload
	ldr	q0, [sp, #1744]                 ; 16-byte Reload
	ldr	q4, [sp, #1984]                 ; 16-byte Reload
	stp	q4, q0, [x10]
	ldr	q0, [sp, #1760]                 ; 16-byte Reload
	ldr	q4, [sp, #2048]                 ; 16-byte Reload
	stp	q4, q0, [x9]
	ldp	x9, x10, [sp, #384]             ; 16-byte Folded Reload
	ldr	q0, [sp, #1776]                 ; 16-byte Reload
	ldr	q4, [sp, #1968]                 ; 16-byte Reload
	stp	q4, q0, [x10]
	ldr	q0, [sp, #1792]                 ; 16-byte Reload
	ldr	q4, [sp, #2032]                 ; 16-byte Reload
	stp	q4, q0, [x9]
	ldp	x9, x10, [sp, #368]             ; 16-byte Folded Reload
	ldr	q0, [sp, #1808]                 ; 16-byte Reload
	ldr	q4, [sp, #1952]                 ; 16-byte Reload
	stp	q4, q0, [x10]
	ldr	q0, [sp, #1824]                 ; 16-byte Reload
	ldr	q4, [sp, #2016]                 ; 16-byte Reload
	stp	q4, q0, [x9]
	ldp	x9, x10, [sp, #352]             ; 16-byte Folded Reload
	ldr	q0, [sp, #1840]                 ; 16-byte Reload
	ldr	q4, [sp, #1936]                 ; 16-byte Reload
	stp	q4, q0, [x10]
	ldr	q0, [sp, #1856]                 ; 16-byte Reload
	ldr	q4, [sp, #2000]                 ; 16-byte Reload
	stp	q4, q0, [x9]
	ldp	x9, x10, [sp, #336]             ; 16-byte Folded Reload
	ldr	q0, [sp, #1872]                 ; 16-byte Reload
	ldr	q4, [sp, #1920]                 ; 16-byte Reload
	stp	q4, q0, [x10]
	ldr	q4, [sp, #1888]                 ; 16-byte Reload
	stp	q29, q4, [x9]
	ldr	q4, [sp, #1520]                 ; 16-byte Reload
	fcmeq.4s	v4, v4, v4
	ldr	q13, [sp, #320]                 ; 16-byte Reload
	ldr	q5, [sp, #1536]                 ; 16-byte Reload
	mov.16b	v0, v4
	bsl.16b	v0, v5, v13
	str	q0, [sp, #2144]                 ; 16-byte Spill
	ldr	q4, [sp, #1568]                 ; 16-byte Reload
	fcmeq.4s	v4, v4, v4
	ldr	q5, [sp, #1552]                 ; 16-byte Reload
	mov.16b	v0, v4
	bsl.16b	v0, v5, v13
	str	q0, [sp, #2112]                 ; 16-byte Spill
	ldr	q4, [sp, #1456]                 ; 16-byte Reload
	fcmeq.4s	v4, v4, v4
	ldr	q5, [sp, #1472]                 ; 16-byte Reload
	mov.16b	v0, v4
	bsl.16b	v0, v5, v13
	str	q0, [sp, #2128]                 ; 16-byte Spill
	ldr	q4, [sp, #1488]                 ; 16-byte Reload
	fcmeq.4s	v4, v4, v4
	ldr	q5, [sp, #1504]                 ; 16-byte Reload
	mov.16b	v0, v4
	bsl.16b	v0, v5, v13
	str	q0, [sp, #2080]                 ; 16-byte Spill
	ldr	q4, [sp, #1376]                 ; 16-byte Reload
	fcmeq.4s	v4, v4, v4
	ldr	q5, [sp, #1392]                 ; 16-byte Reload
	mov.16b	v0, v4
	bsl.16b	v0, v5, v13
	str	q0, [sp, #2096]                 ; 16-byte Spill
	ldr	q4, [sp, #1408]                 ; 16-byte Reload
	fcmeq.4s	v4, v4, v4
	ldr	q5, [sp, #1424]                 ; 16-byte Reload
	mov.16b	v0, v4
	bsl.16b	v0, v5, v13
	str	q0, [sp, #2064]                 ; 16-byte Spill
	ldr	q4, [sp, #1312]                 ; 16-byte Reload
	fcmeq.4s	v4, v4, v4
	ldr	q5, [sp, #1328]                 ; 16-byte Reload
	mov.16b	v0, v4
	bsl.16b	v0, v5, v13
	str	q0, [sp, #2048]                 ; 16-byte Spill
	ldr	q4, [sp, #1344]                 ; 16-byte Reload
	fcmeq.4s	v4, v4, v4
	ldr	q5, [sp, #1360]                 ; 16-byte Reload
	mov.16b	v14, v4
	bsl.16b	v14, v5, v13
	ldr	q4, [sp, #1248]                 ; 16-byte Reload
	fcmeq.4s	v4, v4, v4
	ldr	q5, [sp, #1264]                 ; 16-byte Reload
	mov.16b	v15, v4
	bsl.16b	v15, v5, v13
	ldr	q4, [sp, #1280]                 ; 16-byte Reload
	fcmeq.4s	v4, v4, v4
	ldr	q5, [sp, #1296]                 ; 16-byte Reload
	mov.16b	v10, v4
	bsl.16b	v10, v5, v13
	ldr	q4, [sp, #1168]                 ; 16-byte Reload
	fcmeq.4s	v4, v4, v4
	ldr	q5, [sp, #1184]                 ; 16-byte Reload
	mov.16b	v0, v4
	bsl.16b	v0, v5, v13
	ldr	q5, [sp, #1200]                 ; 16-byte Reload
	fcmeq.4s	v5, v5, v5
	ldr	q6, [sp, #1216]                 ; 16-byte Reload
	bsl.16b	v5, v6, v13
	ldr	q6, [sp, #1104]                 ; 16-byte Reload
	fcmeq.4s	v6, v6, v6
	ldr	q7, [sp, #1120]                 ; 16-byte Reload
	bsl.16b	v6, v7, v13
	ldr	q7, [sp, #1136]                 ; 16-byte Reload
	fcmeq.4s	v7, v7, v7
	ldr	q16, [sp, #1152]                ; 16-byte Reload
	bsl.16b	v7, v16, v13
	ldr	q16, [sp, #1040]                ; 16-byte Reload
	fcmeq.4s	v16, v16, v16
	ldr	q17, [sp, #1056]                ; 16-byte Reload
	mov.16b	v4, v16
	bsl.16b	v4, v17, v13
	ldr	q17, [sp, #1072]                ; 16-byte Reload
	fcmeq.4s	v17, v17, v17
	ldr	q18, [sp, #1088]                ; 16-byte Reload
	bsl.16b	v17, v18, v13
	ldp	q18, q19, [sp, #976]            ; 32-byte Folded Reload
	fcmeq.4s	v18, v18, v18
	bsl.16b	v18, v19, v13
	ldp	q19, q20, [sp, #1008]           ; 32-byte Folded Reload
	fcmeq.4s	v19, v19, v19
	bsl.16b	v19, v20, v13
	ldp	q20, q21, [sp, #912]            ; 32-byte Folded Reload
	fcmeq.4s	v20, v20, v20
	bsl.16b	v20, v21, v13
	ldp	q21, q27, [sp, #944]            ; 32-byte Folded Reload
	fcmeq.4s	v21, v21, v21
	bsl.16b	v21, v27, v13
	ldp	q1, q27, [sp, #848]             ; 32-byte Folded Reload
	fcmeq.4s	v11, v1, v1
	bsl.16b	v11, v27, v13
	ldp	q2, q27, [sp, #880]             ; 32-byte Folded Reload
	fcmeq.4s	v9, v2, v2
	bsl.16b	v9, v27, v13
	ldp	q16, q27, [sp, #784]            ; 32-byte Folded Reload
	fcmeq.4s	v31, v16, v16
	bsl.16b	v31, v27, v13
	ldp	q29, q27, [sp, #816]            ; 32-byte Folded Reload
	fcmeq.4s	v30, v29, v29
	bsl.16b	v30, v27, v13
	ldr	q27, [sp, #736]                 ; 16-byte Reload
	fcmeq.4s	v29, v27, v27
	ldr	q27, [sp, #752]                 ; 16-byte Reload
	bsl.16b	v29, v27, v13
	fcmeq.4s	v28, v28, v28
	ldr	q27, [sp, #768]                 ; 16-byte Reload
	bsl.16b	v28, v27, v13
	fcmeq.4s	v27, v12, v12
	ldr	q12, [sp, #704]                 ; 16-byte Reload
	bsl.16b	v27, v12, v13
	fcmeq.4s	v26, v26, v26
	ldr	q12, [sp, #720]                 ; 16-byte Reload
	mov.16b	v16, v26
	bsl.16b	v16, v12, v13
	fcmeq.4s	v25, v25, v25
	ldr	q12, [sp, #672]                 ; 16-byte Reload
	bsl.16b	v25, v12, v13
	fcmeq.4s	v24, v24, v24
	ldr	q12, [sp, #688]                 ; 16-byte Reload
	bsl.16b	v24, v12, v13
	fcmeq.4s	v23, v23, v23
	ldr	q12, [sp, #624]                 ; 16-byte Reload
	mov.16b	v3, v23
	bsl.16b	v3, v12, v13
	fcmeq.4s	v22, v22, v22
	ldr	q12, [sp, #640]                 ; 16-byte Reload
	mov.16b	v1, v22
	bsl.16b	v1, v12, v13
	ldr	q12, [sp, #656]                 ; 16-byte Reload
	and.16b	v26, v12, v5
	and.16b	v2, v12, v0
	and.16b	v22, v12, v7
	and.16b	v0, v12, v6
	and.16b	v23, v12, v17
	and.16b	v4, v12, v4
	and.16b	v19, v12, v19
	and.16b	v18, v12, v18
	and.16b	v6, v12, v21
	and.16b	v5, v12, v20
	and.16b	v20, v12, v9
	and.16b	v21, v12, v11
	and.16b	v7, v12, v30
	and.16b	v30, v12, v31
	and.16b	v28, v12, v28
	and.16b	v29, v12, v29
	and.16b	v16, v12, v16
	and.16b	v27, v12, v27
	and.16b	v24, v12, v24
	and.16b	v25, v12, v25
	and.16b	v17, v12, v1
	and.16b	v31, v12, v3
	ldr	q1, [sp, #576]                  ; 16-byte Reload
	fcmeq.4s	v3, v1, v1
	ldr	q1, [sp, #592]                  ; 16-byte Reload
	mov.16b	v9, v3
	bsl.16b	v9, v1, v13
	fcmeq.4s	v1, v8, v8
	ldr	q3, [sp, #608]                  ; 16-byte Reload
	mov.16b	v8, v1
	bsl.16b	v8, v3, v13
	mov	w9, #33792                      ; =0x8400
	movk	w9, #1, lsl #16
	add	x9, x20, x9
	ldr	q3, [sp, #2112]                 ; 16-byte Reload
	ldr	q1, [sp, #2144]                 ; 16-byte Reload
	stp	q1, q3, [x9]
	ldp	x9, x10, [sp, #304]             ; 16-byte Folded Reload
	ldr	q3, [sp, #2080]                 ; 16-byte Reload
	ldr	q1, [sp, #2128]                 ; 16-byte Reload
	stp	q1, q3, [x10]
	ldr	q3, [sp, #2064]                 ; 16-byte Reload
	ldr	q1, [sp, #2096]                 ; 16-byte Reload
	stp	q1, q3, [x9]
	ldp	x9, x10, [sp, #288]             ; 16-byte Folded Reload
	str	q14, [sp, #2032]                ; 16-byte Spill
	ldr	q1, [sp, #2048]                 ; 16-byte Reload
	stp	q1, q14, [x10]
	str	q10, [sp, #2000]                ; 16-byte Spill
	stp	q15, q10, [x9]
	str	q15, [sp, #2016]                ; 16-byte Spill
	ldp	x9, x10, [sp, #272]             ; 16-byte Folded Reload
	str	q2, [sp, #1728]                 ; 16-byte Spill
	stp	q26, q2, [x10]
	str	q26, [sp, #1984]                ; 16-byte Spill
	str	q0, [sp, #1872]                 ; 16-byte Spill
	stp	q22, q0, [x9]
	str	q22, [sp, #1888]                ; 16-byte Spill
	ldp	x9, x11, [sp, #256]             ; 16-byte Folded Reload
	str	q4, [sp, #1712]                 ; 16-byte Spill
	stp	q23, q4, [x11]
	str	q23, [sp, #1968]                ; 16-byte Spill
	str	q18, [sp, #1840]                ; 16-byte Spill
	stp	q19, q18, [x9]
	str	q19, [sp, #1856]                ; 16-byte Spill
	ldr	x9, [sp, #248]                  ; 8-byte Reload
	str	q5, [sp, #1696]                 ; 16-byte Spill
	stp	q6, q5, [x9]
	str	q6, [sp, #1952]                 ; 16-byte Spill
	ldr	x9, [sp, #240]                  ; 8-byte Reload
	str	q21, [sp, #1808]                ; 16-byte Spill
	stp	q20, q21, [x9]
	str	q20, [sp, #1824]                ; 16-byte Spill
	ldr	x9, [sp, #232]                  ; 8-byte Reload
	str	q30, [sp, #1680]                ; 16-byte Spill
	stp	q7, q30, [x9]
	str	q7, [sp, #1936]                 ; 16-byte Spill
	ldr	x9, [sp, #224]                  ; 8-byte Reload
	str	q29, [sp, #1776]                ; 16-byte Spill
	stp	q28, q29, [x9]
	str	q28, [sp, #1792]                ; 16-byte Spill
	ldr	x9, [sp, #216]                  ; 8-byte Reload
	str	q27, [sp, #1664]                ; 16-byte Spill
	stp	q16, q27, [x9]
	str	q16, [sp, #1920]                ; 16-byte Spill
	ldr	x9, [sp, #208]                  ; 8-byte Reload
	str	q25, [sp, #1744]                ; 16-byte Spill
	stp	q24, q25, [x9]
	str	q24, [sp, #1760]                ; 16-byte Spill
	ldr	x9, [sp, #200]                  ; 8-byte Reload
	str	q31, [sp, #1648]                ; 16-byte Spill
	stp	q17, q31, [x9]
	str	q17, [sp, #1904]                ; 16-byte Spill
	ldr	x9, [sp, #568]                  ; 8-byte Reload
LBB0_63:                                ; %direct.true597
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_64 Depth 3
	mov	x10, #0                         ; =0x0
	lsl	x11, x8, #7
	add	x12, x24, x11
	ldp	q0, q1, [x12]
	fmul.4s	v1, v9, v1
	fmul.4s	v0, v8, v0
	mov	w12, #1                         ; =0x1
	bfi	x12, x8, #2, #61
	add	x13, x24, x12, lsl #5
	ldp	q2, q3, [x13]
	fmul.4s	v3, v9, v3
	fmul.4s	v2, v8, v2
	mov	w13, #2                         ; =0x2
	bfi	x13, x8, #2, #61
	add	x14, x24, x13, lsl #5
	ldp	q4, q5, [x14]
	fmul.4s	v7, v9, v5
	fmul.4s	v6, v8, v4
	orr	x14, x21, x8, lsl #2
	add	x15, x24, x14, lsl #5
	ldp	q4, q5, [x15]
	fmul.4s	v5, v9, v5
	fmul.4s	v4, v8, v4
	mov	x15, x9
LBB0_64:                                ; %direct.true625
                                        ;   Parent Loop BB0_17 Depth=1
                                        ;     Parent Loop BB0_63 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x16, x28, x10
	ldp	q17, q16, [x16]
	ldp	q19, q18, [x15, #-96]
	fmul.4s	v19, v17, v19
	fmul.4s	v18, v16, v18
	fadd.4s	v1, v1, v18
	fadd.4s	v0, v0, v19
	ldp	q19, q18, [x15, #-64]
	fmul.4s	v19, v17, v19
	fmul.4s	v18, v16, v18
	fadd.4s	v3, v3, v18
	fadd.4s	v2, v2, v19
	ldp	q19, q18, [x15, #-32]
	fmul.4s	v19, v17, v19
	fmul.4s	v18, v16, v18
	fadd.4s	v7, v7, v18
	fadd.4s	v6, v6, v19
	ldp	q19, q18, [x15]
	fmul.4s	v17, v17, v19
	fmul.4s	v16, v16, v18
	fadd.4s	v5, v5, v16
	fadd.4s	v4, v4, v17
	add	x10, x10, #32
	add	x15, x15, #3072
	cmp	x10, #512
	b.ne	LBB0_64
; %bb.65:                               ; %direct.false626
                                        ;   in Loop: Header=BB0_63 Depth=2
	add	x10, x19, x11
	stp	q0, q1, [x10]
	add	x10, x19, x12, lsl #5
	stp	q2, q3, [x10]
	add	x10, x19, x13, lsl #5
	stp	q6, q7, [x10]
	add	x10, x19, x14, lsl #5
	add	x8, x8, #1
	add	x9, x9, #128
	stp	q4, q5, [x10]
	cmp	x8, #24
	b.ne	LBB0_63
; %bb.66:                               ; %direct.true692.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	w8, #5632                       ; =0x1600
	add	x0, x20, x8
	mov	x1, x19
	mov	w2, #3072                       ; =0xc00
	str	q9, [sp, #1552]                 ; 16-byte Spill
	str	q8, [sp, #1568]                 ; 16-byte Spill
	bl	_memcpy
	add	x0, x20, #2560
	mov	x1, x19
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	ldr	q0, [sp, #1616]                 ; 16-byte Reload
	ldr	q1, [sp, #1552]                 ; 16-byte Reload
	fmul.4s	v0, v0, v1
	ldr	q1, [sp, #1632]                 ; 16-byte Reload
	ldr	q2, [sp, #1568]                 ; 16-byte Reload
	fmul.4s	v1, v1, v2
	movi.2d	v3, #0000000000000000
	ldr	q2, [sp, #2112]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q4, [sp, #2080]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2144]                 ; 16-byte Reload
	fadd.4s	v3, v4, v3
	ldr	q4, [sp, #2128]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #2096]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #2064]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2032]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2048]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #2016]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #2000]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1728]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1984]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1888]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1872]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1712]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1968]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1856]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1840]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1696]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1952]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1824]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1808]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1680]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1936]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1792]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1776]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1664]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1920]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1760]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1744]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1648]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1904]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	fadd.4s	v23, v1, v3
	fadd.4s	v24, v0, v2
	add	x25, x25, #1
	ldr	q1, [sp, #1600]                 ; 16-byte Reload
	ldr	q0, [sp, #1584]                 ; 16-byte Reload
	cmp	x25, #129
	ldr	x16, [sp, #560]                 ; 8-byte Reload
	ldp	q19, q18, [sp, #512]            ; 32-byte Folded Reload
	ldp	q21, q20, [sp, #480]            ; 32-byte Folded Reload
	ldr	q22, [sp, #464]                 ; 16-byte Reload
	mov	w0, #52429                      ; =0xcccd
	mov	w1, #80                         ; =0x50
	mov	w2, #96                         ; =0x60
	b.ne	LBB0_17
	b	LBB0_71
LBB0_67:                                ; %direct.true727.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	b	LBB0_69
LBB0_68:                                ; %direct.schedule.44
                                        ;   in Loop: Header=BB0_69 Depth=2
	add	x9, x27, x8, lsl #5
	stp	q1, q0, [x9]
	add	x8, x8, #1
	cmp	x8, #1536
	b.eq	LBB0_54
LBB0_69:                                ; %direct.true727
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w9, w8, #0xffff
	mul	w9, w9, w22
	mov	w10, #2048                      ; =0x800
	bfxil	w10, w9, #22, #10
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	cmp	w10, #2052
	b.hi	LBB0_68
; %bb.70:                               ; %direct.true740
                                        ;   in Loop: Header=BB0_69 Depth=2
	lsr	w9, w9, #22
	dup.2d	v0, x10
	add.2d	v1, v0, v21
	add.2d	v2, v0, v20
	add.2d	v3, v0, v19
	add.2d	v0, v0, v18
	mov.d	x10, v0[1]
	fmov	x11, d0
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #5
	fmov	d0, x11
	add	x10, x10, x10, lsl #1
	lsl	x10, x10, #5
	mov.d	v0[1], x10
	mov.d	x10, v3[1]
	fmov	x11, d3
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #5
	fmov	d3, x11
	add	x10, x10, x10, lsl #1
	lsl	x10, x10, #5
	mov.d	v3[1], x10
	mov.d	x10, v2[1]
	fmov	x11, d2
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #5
	fmov	d2, x11
	add	x10, x10, x10, lsl #1
	lsl	x10, x10, #5
	mov.d	v2[1], x10
	mov.d	x10, v1[1]
	fmov	x11, d1
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #5
	fmov	d1, x11
	add	x10, x10, x10, lsl #1
	lsl	x10, x10, #5
	mov.d	v1[1], x10
	msub	w9, w9, w2, w8
	and	x9, x9, #0xffff
	dup.2d	v4, x9
	add.2d	v1, v1, v4
	add.2d	v2, v2, v4
	add.2d	v3, v3, v4
	add.2d	v0, v0, v4
	shl.2d	v0, v0, #2
	shl.2d	v3, v3, #2
	shl.2d	v2, v2, #2
	shl.2d	v1, v1, #2
	dup.2d	v4, x23
	add.2d	v1, v4, v1
	add.2d	v2, v4, v2
	add.2d	v3, v4, v3
	add.2d	v0, v4, v0
	mov.d	x9, v0[1]
	fmov	x10, d0
	mov.d	x11, v3[1]
	fmov	x12, d3
	mov.d	x13, v2[1]
	fmov	x14, d2
	mov.d	x15, v1[1]
	ldr	s0, [x14]
	ld1.s	{ v0 }[1], [x13]
	fmov	x13, d1
	ld1.s	{ v0 }[2], [x13]
	ld1.s	{ v0 }[3], [x15]
	ldr	s1, [x10]
	ld1.s	{ v1 }[1], [x9]
	ld1.s	{ v1 }[2], [x12]
	ld1.s	{ v1 }[3], [x11]
	b	LBB0_68
LBB0_71:                                ; %direct.schedule.51.preheader
	mov	x8, #0                          ; =0x0
	ldp	q0, q2, [sp, #16]               ; 32-byte Folded Reload
	xtn.2s	v0, v0
	movi.2s	v3, #96
	umull.2d	v0, v0, v3
	ldp	q1, q4, [sp, #48]               ; 32-byte Folded Reload
	xtn.2s	v1, v1
	umull.2d	v1, v1, v3
	xtn.2s	v2, v2
	umull.2d	v2, v2, v3
	xtn.2s	v4, v4
	umull.2d	v3, v4, v3
	ldr	x11, [sp, #8]                   ; 8-byte Reload
LBB0_72:                                ; %direct.true777
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v4, x8
	add.2d	v5, v4, v3
	add.2d	v6, v4, v2
	add.2d	v7, v4, v1
	add.2d	v4, v4, v0
	add	x9, x24, x8, lsl #5
	ldp	q16, q17, [x9]
	fdiv.4s	v17, v17, v24
	fdiv.4s	v16, v16, v23
	shl.2d	v4, v4, #2
	shl.2d	v7, v7, #2
	shl.2d	v6, v6, #2
	shl.2d	v5, v5, #2
	dup.2d	v18, x11
	add.2d	v5, v18, v5
	add.2d	v4, v18, v4
	mov.d	x9, v4[1]
	fmov	x10, d4
	str	s16, [x10]
	st1.s	{ v16 }[1], [x9]
	add.2d	v4, v18, v7
	mov.d	x9, v4[1]
	fmov	x10, d4
	st1.s	{ v16 }[2], [x10]
	add.2d	v4, v18, v6
	st1.s	{ v16 }[3], [x9]
	mov.d	x9, v4[1]
	fmov	x10, d4
	str	s17, [x10]
	st1.s	{ v17 }[1], [x9]
	mov.d	x9, v5[1]
	fmov	x10, d5
	st1.s	{ v17 }[2], [x10]
	st1.s	{ v17 }[3], [x9]
	add	x8, x8, #1
	cmp	x8, #96
	b.ne	LBB0_72
; %bb.73:                               ; %common.ret
	add	sp, sp, #2160
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention.packet_batch.blocks
lCPI1_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI1_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI1_2:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI1_3:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI1_4:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI1_5:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI1_6:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_attention.packet_batch.blocks
	.p2align	2
_llm_attention.packet_batch.blocks:     ; @llm_attention.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #2960
	str	x0, [sp, #120]                  ; 8-byte Spill
	cbz	w3, LBB1_168
; %bb.1:                                ; %block.batch.loop.preheader
	mov	x22, x3
	mov	w9, #0                          ; =0x0
	ldp	w10, w8, [x2, #44]
	stp	w8, w10, [sp, #112]             ; 8-byte Folded Spill
	mov	w24, #33280                     ; =0x8200
	movk	w24, #1, lsl #16
Lloh4:
	adrp	x8, lCPI1_0@PAGE
Lloh5:
	ldr	q19, [x8, lCPI1_0@PAGEOFF]
Lloh6:
	adrp	x8, lCPI1_1@PAGE
Lloh7:
	ldr	q18, [x8, lCPI1_1@PAGEOFF]
Lloh8:
	adrp	x8, lCPI1_5@PAGE
Lloh9:
	ldr	q0, [x8, lCPI1_5@PAGEOFF]
	str	q0, [sp, #2464]                 ; 16-byte Spill
	movi.2s	v8, #80
	mov	w19, #52429                     ; =0xcccd
	mov	w28, #80                        ; =0x50
	adrp	x23, lCPI1_6@PAGE
	mov	w26, #43691                     ; =0xaaab
	mov	w27, #96                        ; =0x60
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	str	q0, [sp, #160]                  ; 16-byte Spill
	ldp	w15, w13, [x2, #4]
	ldr	w14, [x2]
	str	x2, [sp, #152]                  ; 8-byte Spill
	str	w3, [sp, #12]                   ; 4-byte Spill
	str	q19, [sp, #480]                 ; 16-byte Spill
	str	q18, [sp, #96]                  ; 16-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x2, #36]
LBB1_3:                                 ; %llm_attention.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldp	w13, w11, [sp, #136]            ; 8-byte Folded Reload
	ldr	x14, [sp, #144]                 ; 8-byte Reload
	add	w8, w14, #1
	ldp	w10, w9, [sp, #112]             ; 8-byte Folded Reload
	cmp	w8, w9
	cset	w8, eq
	csinc	w14, wzr, w14, eq
	ldr	w9, [sp, #132]                  ; 4-byte Reload
	cinc	w9, w9, eq
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w15, wzr, w9, ne
	add	w13, w13, w8
	add	w9, w11, #1
	cmp	w9, w22
	b.eq	LBB1_168
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_15 Depth 2
                                        ;     Child Loop BB1_18 Depth 2
                                        ;     Child Loop BB1_21 Depth 2
                                        ;     Child Loop BB1_24 Depth 2
                                        ;     Child Loop BB1_27 Depth 2
                                        ;     Child Loop BB1_30 Depth 2
                                        ;     Child Loop BB1_33 Depth 2
                                        ;     Child Loop BB1_36 Depth 2
                                        ;     Child Loop BB1_38 Depth 2
                                        ;     Child Loop BB1_40 Depth 2
                                        ;       Child Loop BB1_62 Depth 3
                                        ;       Child Loop BB1_65 Depth 3
                                        ;       Child Loop BB1_68 Depth 3
                                        ;       Child Loop BB1_71 Depth 3
                                        ;       Child Loop BB1_74 Depth 3
                                        ;       Child Loop BB1_77 Depth 3
                                        ;       Child Loop BB1_80 Depth 3
                                        ;       Child Loop BB1_83 Depth 3
                                        ;       Child Loop BB1_86 Depth 3
                                        ;       Child Loop BB1_89 Depth 3
                                        ;       Child Loop BB1_92 Depth 3
                                        ;       Child Loop BB1_95 Depth 3
                                        ;       Child Loop BB1_98 Depth 3
                                        ;       Child Loop BB1_101 Depth 3
                                        ;       Child Loop BB1_104 Depth 3
                                        ;       Child Loop BB1_107 Depth 3
                                        ;       Child Loop BB1_43 Depth 3
                                        ;       Child Loop BB1_111 Depth 3
                                        ;       Child Loop BB1_132 Depth 3
                                        ;       Child Loop BB1_134 Depth 3
                                        ;       Child Loop BB1_136 Depth 3
                                        ;       Child Loop BB1_138 Depth 3
                                        ;       Child Loop BB1_140 Depth 3
                                        ;       Child Loop BB1_142 Depth 3
                                        ;         Child Loop BB1_143 Depth 4
                                        ;       Child Loop BB1_146 Depth 3
                                        ;       Child Loop BB1_148 Depth 3
                                        ;     Child Loop BB1_152 Depth 2
	stp	w13, w9, [sp, #136]             ; 8-byte Folded Spill
	ldr	w8, [x2, #12]
	ubfiz	x9, x14, #5, #32
	cmp	x9, x8
	csel	x10, x9, xzr, ls
	subs	x11, x8, x10
	cmp	x11, #32
	mov	w12, #32                        ; =0x20
	csel	x11, x11, x12, lo
	cmp	x8, x10
	stp	w14, w15, [x2]
	str	w15, [sp, #132]                 ; 4-byte Spill
	str	w13, [x2, #8]
	str	wzr, [x2, #36]
	ccmp	x9, x8, #2, hi
	csel	x21, x11, xzr, ls
	cmp	x21, #32
	str	x14, [sp, #144]                 ; 8-byte Spill
	b.lo	LBB1_6
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x20, [sp, #120]                 ; 8-byte Reload
	mov	x0, x20
	ldr	x1, [sp, #152]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x8, [sp, #152]                  ; 8-byte Reload
	mov	w9, #8                          ; =0x8
	str	w9, [x8, #36]
	mov	x0, x20
	ldr	x1, [sp, #152]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x8, [sp, #152]                  ; 8-byte Reload
	mov	w9, #16                         ; =0x10
	str	w9, [x8, #36]
	mov	x0, x20
	ldr	x1, [sp, #152]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x8, [sp, #152]                  ; 8-byte Reload
	mov	w9, #24                         ; =0x18
	str	w9, [x8, #36]
	mov	x0, x20
	ldr	x1, [sp, #152]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x2, [sp, #152]                  ; 8-byte Reload
	b	LBB1_3
LBB1_6:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x20, x21, #3
	cbz	x20, LBB1_11
; %bb.7:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x2, #36]
	ldr	x0, [sp, #120]                  ; 8-byte Reload
	ldr	x1, [sp, #152]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x2, [sp, #152]                  ; 8-byte Reload
	cmp	x20, #1
	b.eq	LBB1_11
; %bb.8:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x2, #36]
	ldr	x0, [sp, #120]                  ; 8-byte Reload
	ldr	x1, [sp, #152]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x2, [sp, #152]                  ; 8-byte Reload
	cmp	x20, #2
	b.eq	LBB1_11
; %bb.9:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x2, #36]
	ldr	x0, [sp, #120]                  ; 8-byte Reload
	ldr	x1, [sp, #152]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x2, [sp, #152]                  ; 8-byte Reload
	cmp	x20, #3
	b.eq	LBB1_11
; %bb.10:                               ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x2, #36]
	ldr	x24, [sp, #120]                 ; 8-byte Reload
	mov	x0, x24
	ldr	x1, [sp, #152]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x8, [sp, #152]                  ; 8-byte Reload
	mov	w9, #32                         ; =0x20
	str	w9, [x8, #36]
	mov	x0, x24
	ldr	x1, [sp, #152]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x8, [sp, #152]                  ; 8-byte Reload
	mov	w9, #40                         ; =0x28
	str	w9, [x8, #36]
	mov	x0, x24
	ldr	x1, [sp, #152]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x8, [sp, #152]                  ; 8-byte Reload
	mov	w9, #48                         ; =0x30
	str	w9, [x8, #36]
	mov	x0, x24
	mov	w24, #33280                     ; =0x8200
	movk	w24, #1, lsl #16
	ldr	x1, [sp, #152]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x2, [sp, #152]                  ; 8-byte Reload
LBB1_11:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w8, w21, #0x7
	ldr	q19, [sp, #480]                 ; 16-byte Reload
	ldr	q18, [sp, #96]                  ; 16-byte Reload
	cbz	w8, LBB1_2
; %bb.12:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w10, w20, #3
	dup.4s	v17, w8
	str	w10, [x2, #36]
	cmhi.4s	v0, v17, v18
	cmhi.4s	v2, v17, v19
	uzp1.8h	v25, v2, v0
	umaxv.8h	h1, v25
	fmov	w8, s1
	tbz	w8, #0, LBB1_2
; %bb.13:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x8, [x2, #136]
	ldr	x9, [sp, #120]                  ; 8-byte Reload
	ldr	x9, [x9]
	xtn.4h	v1, v2
	ldr	x11, [sp, #144]                 ; 8-byte Reload
	orr	w10, w10, w11, lsl #5
	dup.4s	v3, w10
	uzp1.8b	v5, v1, v0
	orr.16b	v1, v3, v19
	and.16b	v1, v2, v1
	umull.2d	v4, v1, v8
	umov.b	w10, v5[0]
	str	w10, [sp, #444]                 ; 4-byte Spill
	tbz	w10, #0, LBB1_16
; %bb.14:                               ; %copy.active.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x10, #0                         ; =0x0
	fmov	x11, d4
	add	x11, x9, x11, lsl #2
	add	x12, x8, #64
LBB1_15:                                ; %copy.chunk.i.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q5, [x11, x10]
	stur	s5, [x12, #-64]
	mov	s6, v5[1]
	stur	s6, [x12, #-32]
	st1.s	{ v5 }[2], [x12]
	add	x13, x12, #32
	st1.s	{ v5 }[3], [x13]
	add	x10, x10, #16
	add	x12, x12, #128
	cmp	x10, #320
	b.ne	LBB1_15
LBB1_16:                                ; %copy.continue.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.s	w11, v17[1]
	cmp	w11, #1
	cset	w10, hi
	str	w10, [sp, #440]                 ; 4-byte Spill
	cmp	w11, #2
	b.lo	LBB1_19
; %bb.17:                               ; %copy.active133.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x10, #0                         ; =0x0
	mov.d	x12, v4[1]
	add	x12, x9, x12, lsl #2
	add	x13, x8, #68
LBB1_18:                                ; %copy.chunk.i340.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q4, [x12, x10]
	stur	s4, [x13, #-64]
	mov	s5, v4[1]
	stur	s5, [x13, #-32]
	st1.s	{ v4 }[2], [x13]
	add	x14, x13, #32
	st1.s	{ v4 }[3], [x14]
	add	x10, x10, #16
	add	x13, x13, #128
	cmp	x10, #320
	b.ne	LBB1_18
LBB1_19:                                ; %copy.continue134.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	movi.4s	v4, #80
	umull2.2d	v4, v1, v4
	mov.s	w12, v17[2]
	cmp	w12, #2
	cset	w2, hi
	cmp	w12, #3
	b.lo	LBB1_22
; %bb.20:                               ; %copy.active135.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x10, #0                         ; =0x0
	fmov	x13, d4
	add	x13, x9, x13, lsl #2
	add	x14, x8, #72
LBB1_21:                                ; %copy.chunk.i346.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q5, [x13, x10]
	stur	s5, [x14, #-64]
	mov	s6, v5[1]
	stur	s6, [x14, #-32]
	st1.s	{ v5 }[2], [x14]
	add	x15, x14, #32
	st1.s	{ v5 }[3], [x15]
	add	x10, x10, #16
	add	x14, x14, #128
	cmp	x10, #320
	b.ne	LBB1_21
LBB1_22:                                ; %copy.continue136.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.s	w10, v17[3]
	cmp	w10, #3
	cset	w13, hi
	str	w13, [sp, #436]                 ; 4-byte Spill
	cmp	w10, #4
	b.lo	LBB1_25
; %bb.23:                               ; %copy.active137.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x13, #0                         ; =0x0
	mov.d	x14, v4[1]
	add	x14, x9, x14, lsl #2
	add	x15, x8, #76
LBB1_24:                                ; %copy.chunk.i352.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q4, [x14, x13]
	stur	s4, [x15, #-64]
	mov	s5, v4[1]
	stur	s5, [x15, #-32]
	st1.s	{ v4 }[2], [x15]
	add	x16, x15, #32
	st1.s	{ v4 }[3], [x16]
	add	x13, x13, #16
	add	x15, x15, #128
	cmp	x13, #320
	b.ne	LBB1_24
LBB1_25:                                ; %copy.continue138.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	orr.16b	v3, v3, v18
	and.16b	v3, v0, v3
	umull.2d	v4, v3, v8
	fmov	w13, s17
	cmp	w13, #4
	cset	w14, hi
	str	w14, [sp, #432]                 ; 4-byte Spill
	cmp	w13, #5
	b.lo	LBB1_28
; %bb.26:                               ; %copy.active139.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x13, #0                         ; =0x0
	fmov	x14, d4
	add	x14, x9, x14, lsl #2
	add	x15, x8, #80
LBB1_27:                                ; %copy.chunk.i358.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q5, [x14, x13]
	stur	s5, [x15, #-64]
	mov	s6, v5[1]
	stur	s6, [x15, #-32]
	st1.s	{ v5 }[2], [x15]
	add	x16, x15, #32
	st1.s	{ v5 }[3], [x16]
	add	x13, x13, #16
	add	x15, x15, #128
	cmp	x13, #320
	b.ne	LBB1_27
LBB1_28:                                ; %copy.continue140.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	cmp	w11, #5
	cset	w13, hi
	str	w13, [sp, #428]                 ; 4-byte Spill
	cmp	w11, #6
	b.lo	LBB1_31
; %bb.29:                               ; %copy.active141.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x11, #0                         ; =0x0
	mov.d	x13, v4[1]
	add	x13, x9, x13, lsl #2
	add	x14, x8, #84
LBB1_30:                                ; %copy.chunk.i364.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q4, [x13, x11]
	stur	s4, [x14, #-64]
	mov	s5, v4[1]
	stur	s5, [x14, #-32]
	st1.s	{ v4 }[2], [x14]
	add	x15, x14, #32
	st1.s	{ v4 }[3], [x15]
	add	x11, x11, #16
	add	x14, x14, #128
	cmp	x11, #320
	b.ne	LBB1_30
LBB1_31:                                ; %copy.continue142.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	movi.4s	v4, #80
	umull2.2d	v4, v3, v4
	cmp	w12, #6
	cset	w11, hi
	str	w11, [sp, #424]                 ; 4-byte Spill
	cmp	w12, #7
	b.lo	LBB1_34
; %bb.32:                               ; %copy.active143.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x11, #0                         ; =0x0
	fmov	x12, d4
	add	x12, x9, x12, lsl #2
	add	x13, x8, #88
LBB1_33:                                ; %copy.chunk.i370.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q5, [x12, x11]
	stur	s5, [x13, #-64]
	mov	s6, v5[1]
	stur	s6, [x13, #-32]
	st1.s	{ v5 }[2], [x13]
	add	x14, x13, #32
	st1.s	{ v5 }[3], [x14]
	add	x11, x11, #16
	add	x13, x13, #128
	cmp	x11, #320
	b.ne	LBB1_33
LBB1_34:                                ; %copy.continue144.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x11, [sp, #120]                 ; 8-byte Reload
	ldr	x0, [x11, #16]
	ldr	x1, [x11, #32]
	ldr	x11, [x11, #48]
	str	x11, [sp, #88]                  ; 8-byte Spill
	cmp	w10, #7
	cset	w11, hi
	str	w11, [sp, #420]                 ; 4-byte Spill
	cmp	w10, #8
	b.lo	LBB1_37
; %bb.35:                               ; %copy.active145.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x10, #0                         ; =0x0
	mov.d	x11, v4[1]
	add	x9, x9, x11, lsl #2
	add	x11, x8, #92
LBB1_36:                                ; %copy.chunk.i376.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q4, [x9, x10]
	stur	s4, [x11, #-64]
	mov	s5, v4[1]
	stur	s5, [x11, #-32]
	st1.s	{ v4 }[2], [x11]
	add	x12, x11, #32
	st1.s	{ v4 }[3], [x12]
	add	x10, x10, #16
	add	x11, x11, #128
	cmp	x10, #320
	b.ne	LBB1_36
LBB1_37:                                ; %direct.true.i.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x9, #0                          ; =0x0
	add	x15, x8, #2560
	mov	w10, #5632                      ; =0x1600
	add	x3, x8, x10
	mov	w10, #8704                      ; =0x2200
	add	x4, x8, x10
	dup.2d	v4, x4
	str	q4, [sp, #400]                  ; 16-byte Spill
	mov	w10, #49664                     ; =0xc200
	add	x5, x8, x10
	dup.2d	v4, x5
	str	q4, [sp, #2000]                 ; 16-byte Spill
	add	x6, x8, x24
	mov	w10, #33792                     ; =0x8400
	movk	w10, #1, lsl #16
	add	x7, x8, x10
	mov	w10, #34304                     ; =0x8600
	movk	w10, #1, lsl #16
	add	x30, x8, x10
	sshll.2d	v6, v2, #0
	ushll.2d	v7, v1, #0
	ushll.2d	v4, v3, #0
	ushll2.2d	v1, v1, #0
	ushll2.2d	v3, v3, #0
	stp	q3, q4, [sp, #16]               ; 32-byte Folded Spill
	ushr.2d	v5, v3, #2
	stp	q1, q7, [sp, #48]               ; 32-byte Folded Spill
	ushr.2d	v3, v1, #2
	ushr.2d	v4, v4, #2
	ushr.2d	v1, v7, #2
	ldr	q7, [sp, #2464]                 ; 16-byte Reload
	and.16b	v6, v6, v7
	str	q6, [sp, #2896]                 ; 16-byte Spill
LBB1_38:                                ; %direct.true.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x15, x9
	ldp	q6, q7, [x10]
	cmhs.4s	v16, v18, v17
	and.16b	v7, v16, v7
	cmhs.4s	v16, v19, v17
	and.16b	v6, v16, v6
	stp	q6, q7, [x10]
	add	x9, x9, #32
	cmp	x9, #3072
	b.ne	LBB1_38
; %bb.39:                               ; %direct.false.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	q17, [sp, #464]                 ; 16-byte Spill
	mov	x21, #0                         ; =0x0
	sshll2.2d	v14, v0, #0
	sshll.2d	v6, v0, #0
	sshll2.2d	v28, v2, #0
	sshll.2d	v7, v2, #0
	mov	w9, #62154                      ; =0xf2ca
	movk	w9, #61769, lsl #16
	dup.4s	v16, w9
	and.16b	v17, v0, v16
	str	q17, [sp, #2528]                ; 16-byte Spill
	str	q16, [sp, #384]                 ; 16-byte Spill
	and.16b	v16, v2, v16
	str	q16, [sp, #2512]                ; 16-byte Spill
	mov.d	x9, v5[1]
	mov	w11, #2053                      ; =0x805
	mul	x9, x9, x11
	fmov	x10, d5
	mul	x10, x10, x11
	fmov	d5, x10
	mov.d	v5[1], x9
	mov.d	x9, v4[1]
	mul	x9, x9, x11
	fmov	x10, d4
	mul	x10, x10, x11
	fmov	d4, x10
	mov.d	v4[1], x9
	mov.d	x9, v3[1]
	mul	x9, x9, x11
	fmov	x10, d3
	mul	x10, x10, x11
	fmov	d3, x10
	mov.d	v3[1], x9
	mov.d	x9, v1[1]
	mul	x9, x9, x11
	fmov	x10, d1
	mul	x10, x10, x11
	fmov	d1, x10
	mov.d	v1[1], x9
	and.16b	v1, v7, v1
	str	q1, [sp, #2864]                 ; 16-byte Spill
	and.16b	v1, v28, v3
	str	q1, [sp, #2848]                 ; 16-byte Spill
	and.16b	v1, v6, v4
	str	q1, [sp, #2832]                 ; 16-byte Spill
	and.16b	v1, v14, v5
	str	q1, [sp, #2816]                 ; 16-byte Spill
	movi.2d	v1, #0000000000000000
	str	q1, [sp, #1856]                 ; 16-byte Spill
	str	q1, [sp, #2800]                 ; 16-byte Spill
	str	q1, [sp, #2784]                 ; 16-byte Spill
	str	q1, [sp, #2768]                 ; 16-byte Spill
	str	q1, [sp, #2928]                 ; 16-byte Spill
	str	q1, [sp, #2752]                 ; 16-byte Spill
	str	q1, [sp, #2736]                 ; 16-byte Spill
	str	q1, [sp, #2720]                 ; 16-byte Spill
	str	q1, [sp, #2912]                 ; 16-byte Spill
	movi.2d	v8, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v30, #0000000000000000
	mov	w9, #33312                      ; =0x8220
	movk	w9, #1, lsl #16
	add	x20, x8, x9
	movi.2d	v16, #0000000000000000
	mov	w9, #33344                      ; =0x8240
	movk	w9, #1, lsl #16
	add	x22, x8, x9
	movi.2d	v3, #0000000000000000
	str	q3, [sp, #2880]                 ; 16-byte Spill
	mov	w9, #33376                      ; =0x8260
	movk	w9, #1, lsl #16
	add	x10, x8, x9
	str	q3, [sp, #1840]                 ; 16-byte Spill
	mov	w9, #33408                      ; =0x8280
	movk	w9, #1, lsl #16
	add	x11, x8, x9
	str	q3, [sp, #1824]                 ; 16-byte Spill
	mov	w9, #33440                      ; =0x82a0
	movk	w9, #1, lsl #16
	add	x12, x8, x9
	str	q3, [sp, #1808]                 ; 16-byte Spill
	mov	w9, #33472                      ; =0x82c0
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #376]                  ; 8-byte Spill
	str	q3, [sp, #1792]                 ; 16-byte Spill
	mov	w9, #33504                      ; =0x82e0
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #368]                  ; 8-byte Spill
	str	q3, [sp, #1776]                 ; 16-byte Spill
	mov	w9, #33536                      ; =0x8300
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #360]                  ; 8-byte Spill
	mov	w9, #33568                      ; =0x8320
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #352]                  ; 8-byte Spill
	mov	w9, #33600                      ; =0x8340
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #344]                  ; 8-byte Spill
	mov	w9, #33632                      ; =0x8360
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #336]                  ; 8-byte Spill
	mov	w9, #33664                      ; =0x8380
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #328]                  ; 8-byte Spill
	mov	w9, #33696                      ; =0x83a0
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #320]                  ; 8-byte Spill
	mov	w9, #33728                      ; =0x83c0
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #312]                  ; 8-byte Spill
	mov	w9, #33760                      ; =0x83e0
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #304]                  ; 8-byte Spill
	mov	w9, #33824                      ; =0x8420
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #296]                  ; 8-byte Spill
	mov	w9, #33856                      ; =0x8440
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #288]                  ; 8-byte Spill
	mov	w9, #33888                      ; =0x8460
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #280]                  ; 8-byte Spill
	mov	w9, #33920                      ; =0x8480
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #272]                  ; 8-byte Spill
	mov	w9, #33952                      ; =0x84a0
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #264]                  ; 8-byte Spill
	mov	w9, #33984                      ; =0x84c0
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #256]                  ; 8-byte Spill
	mov	w9, #34016                      ; =0x84e0
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #248]                  ; 8-byte Spill
	mov	w9, #34048                      ; =0x8500
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #240]                  ; 8-byte Spill
	mov	w9, #34080                      ; =0x8520
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #232]                  ; 8-byte Spill
	mov	w9, #34112                      ; =0x8540
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #224]                  ; 8-byte Spill
	mov	w9, #34144                      ; =0x8560
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #216]                  ; 8-byte Spill
	mov	w9, #34176                      ; =0x8580
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #208]                  ; 8-byte Spill
	mov	w9, #34208                      ; =0x85a0
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #200]                  ; 8-byte Spill
	mov	w9, #34240                      ; =0x85c0
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #192]                  ; 8-byte Spill
	mov	w9, #34272                      ; =0x85e0
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #184]                  ; 8-byte Spill
	str	q3, [sp, #2448]                 ; 16-byte Spill
	str	q3, [sp, #1760]                 ; 16-byte Spill
	str	q3, [sp, #2432]                 ; 16-byte Spill
	str	q3, [sp, #2416]                 ; 16-byte Spill
	str	q3, [sp, #1744]                 ; 16-byte Spill
	str	q3, [sp, #1728]                 ; 16-byte Spill
	str	q3, [sp, #1712]                 ; 16-byte Spill
	str	q3, [sp, #1696]                 ; 16-byte Spill
	str	q3, [sp, #2400]                 ; 16-byte Spill
	movi.2d	v24, #0000000000000000
	str	q3, [sp, #2384]                 ; 16-byte Spill
	str	q3, [sp, #2368]                 ; 16-byte Spill
	str	q3, [sp, #2352]                 ; 16-byte Spill
	movi.2d	v11, #0000000000000000
	str	q3, [sp, #2336]                 ; 16-byte Spill
	str	q3, [sp, #2320]                 ; 16-byte Spill
	str	q3, [sp, #2304]                 ; 16-byte Spill
	movi.2d	v21, #0000000000000000
	str	q3, [sp, #2288]                 ; 16-byte Spill
	str	q3, [sp, #2272]                 ; 16-byte Spill
	str	q3, [sp, #2256]                 ; 16-byte Spill
	str	q3, [sp, #2240]                 ; 16-byte Spill
	str	q3, [sp, #2224]                 ; 16-byte Spill
	str	q3, [sp, #2208]                 ; 16-byte Spill
	str	q3, [sp, #2192]                 ; 16-byte Spill
	str	q3, [sp, #2176]                 ; 16-byte Spill
	movi.2d	v29, #0000000000000000
	movi.2d	v20, #0000000000000000
	str	q3, [sp, #2160]                 ; 16-byte Spill
	movi.2d	v13, #0000000000000000
	str	q3, [sp, #2144]                 ; 16-byte Spill
	str	q3, [sp, #2128]                 ; 16-byte Spill
	movi.2d	v26, #0000000000000000
	movi.2d	v12, #0000000000000000
	str	q3, [sp, #1680]                 ; 16-byte Spill
	str	q3, [sp, #1664]                 ; 16-byte Spill
	str	q3, [sp, #1648]                 ; 16-byte Spill
	str	q3, [sp, #1984]                 ; 16-byte Spill
	str	q3, [sp, #1968]                 ; 16-byte Spill
	movi.2d	v27, #0000000000000000
	str	q3, [sp, #1952]                 ; 16-byte Spill
	str	q3, [sp, #1936]                 ; 16-byte Spill
	str	q3, [sp, #1920]                 ; 16-byte Spill
	movi.2d	v9, #0000000000000000
	movi.2d	v15, #0000000000000000
	str	q3, [sp, #1904]                 ; 16-byte Spill
	str	q3, [sp, #1888]                 ; 16-byte Spill
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	str	q25, [sp, #448]                 ; 16-byte Spill
	str	q14, [sp, #1872]                ; 16-byte Spill
	str	q28, [sp, #2704]                ; 16-byte Spill
LBB1_40:                                ; %direct.true152.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB1_62 Depth 3
                                        ;       Child Loop BB1_65 Depth 3
                                        ;       Child Loop BB1_68 Depth 3
                                        ;       Child Loop BB1_71 Depth 3
                                        ;       Child Loop BB1_74 Depth 3
                                        ;       Child Loop BB1_77 Depth 3
                                        ;       Child Loop BB1_80 Depth 3
                                        ;       Child Loop BB1_83 Depth 3
                                        ;       Child Loop BB1_86 Depth 3
                                        ;       Child Loop BB1_89 Depth 3
                                        ;       Child Loop BB1_92 Depth 3
                                        ;       Child Loop BB1_95 Depth 3
                                        ;       Child Loop BB1_98 Depth 3
                                        ;       Child Loop BB1_101 Depth 3
                                        ;       Child Loop BB1_104 Depth 3
                                        ;       Child Loop BB1_107 Depth 3
                                        ;       Child Loop BB1_43 Depth 3
                                        ;       Child Loop BB1_111 Depth 3
                                        ;       Child Loop BB1_132 Depth 3
                                        ;       Child Loop BB1_134 Depth 3
                                        ;       Child Loop BB1_136 Depth 3
                                        ;       Child Loop BB1_138 Depth 3
                                        ;       Child Loop BB1_140 Depth 3
                                        ;       Child Loop BB1_142 Depth 3
                                        ;         Child Loop BB1_143 Depth 4
                                        ;       Child Loop BB1_146 Depth 3
                                        ;       Child Loop BB1_148 Depth 3
	sshll.2d	v3, v2, #0
	sshll.2d	v18, v0, #0
	ldr	q19, [sp, #400]                 ; 16-byte Reload
	ldr	q31, [sp, #1920]                ; 16-byte Reload
	bit.16b	v31, v19, v14
	str	q31, [sp, #1920]                ; 16-byte Spill
	ldr	q31, [sp, #1952]                ; 16-byte Reload
	bit.16b	v31, v19, v28
	str	q31, [sp, #1952]                ; 16-byte Spill
	ldr	q31, [sp, #1936]                ; 16-byte Reload
	bit.16b	v31, v19, v18
	str	q31, [sp, #1936]                ; 16-byte Spill
	bit.16b	v27, v19, v3
Lloh10:
	adrp	x9, lCPI1_2@PAGE
Lloh11:
	ldr	q31, [x9, lCPI1_2@PAGEOFF]
	ldr	q19, [sp, #1888]                ; 16-byte Reload
	str	q31, [sp, #2688]                ; 16-byte Spill
	bit.16b	v19, v31, v14
	str	q19, [sp, #1888]                ; 16-byte Spill
Lloh12:
	adrp	x9, lCPI1_3@PAGE
Lloh13:
	ldr	q19, [x9, lCPI1_3@PAGEOFF]
	str	q19, [sp, #2048]                ; 16-byte Spill
	bit.16b	v15, v19, v28
Lloh14:
	adrp	x9, lCPI1_4@PAGE
Lloh15:
	ldr	q31, [x9, lCPI1_4@PAGEOFF]
	ldr	q19, [sp, #1904]                ; 16-byte Reload
	str	q31, [sp, #2032]                ; 16-byte Spill
	bit.16b	v19, v31, v18
	str	q19, [sp, #1904]                ; 16-byte Spill
	ldr	q18, [sp, #2464]                ; 16-byte Reload
	bit.16b	v9, v18, v3
	str	q9, [sp, #2480]                 ; 16-byte Spill
	cmp	x21, #128
	str	q22, [sp, #1632]                ; 16-byte Spill
	str	q23, [sp, #1616]                ; 16-byte Spill
	str	q24, [sp, #2576]                ; 16-byte Spill
	str	q21, [sp, #2560]                ; 16-byte Spill
	str	q27, [sp, #1568]                ; 16-byte Spill
	str	q15, [sp, #1552]                ; 16-byte Spill
	b.ne	LBB1_60
; %bb.41:                               ; %direct.true752.i.i.preheader
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x9, #0                          ; =0x0
	b	LBB1_43
LBB1_42:                                ; %direct.schedule.49.i.i
                                        ;   in Loop: Header=BB1_43 Depth=3
	str	q23, [sp, #2768]                ; 16-byte Spill
	str	q19, [sp, #2784]                ; 16-byte Spill
	str	q18, [sp, #2800]                ; 16-byte Spill
	add	x13, x4, x9, lsl #5
	ldp	q3, q18, [x13]
	bit.16b	v18, v9, v0
	bit.16b	v3, v31, v2
	stp	q3, q18, [x13]
	add	x9, x9, #1
	cmp	x9, #1280
	b.eq	LBB1_109
LBB1_43:                                ; %direct.true752.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	w13, w9, #0xffff
	mul	w14, w13, w19
	mov	w13, #2048                      ; =0x800
	bfxil	w13, w14, #22, #10
	dup.2d	v3, x13
	ldr	q18, [sp, #2864]                ; 16-byte Reload
	add.2d	v18, v3, v18
	ldr	q19, [sp, #2848]                ; 16-byte Reload
	add.2d	v19, v3, v19
	ldr	q21, [sp, #2832]                ; 16-byte Reload
	add.2d	v21, v3, v21
	ldr	q22, [sp, #2816]                ; 16-byte Reload
	add.2d	v3, v3, v22
	mov.d	x16, v3[1]
	fmov	x17, d3
	add	x17, x17, x17, lsl #2
	lsl	x17, x17, #4
	fmov	d3, x17
	add	x16, x16, x16, lsl #2
	lsl	x16, x16, #4
	mov.d	v3[1], x16
	mov.d	x16, v21[1]
	fmov	x17, d21
	add	x17, x17, x17, lsl #2
	lsl	x17, x17, #4
	fmov	d21, x17
	add	x16, x16, x16, lsl #2
	lsl	x16, x16, #4
	mov.d	v21[1], x16
	mov.d	x16, v19[1]
	fmov	x17, d19
	add	x17, x17, x17, lsl #2
	lsl	x17, x17, #4
	fmov	d19, x17
	add	x16, x16, x16, lsl #2
	lsl	x16, x16, #4
	mov.d	v19[1], x16
	mov.d	x16, v18[1]
	fmov	x17, d18
	add	x17, x17, x17, lsl #2
	lsl	x17, x17, #4
	fmov	d18, x17
	sshll.2d	v22, v2, #0
	lsr	w14, w14, #22
	msub	w14, w14, w28, w9
	and	x14, x14, #0xffff
	add	x16, x16, x16, lsl #2
	lsl	x16, x16, #4
	mov.d	v18[1], x16
	dup.2d	v23, x14
	sshll.2d	v24, v0, #0
	add.2d	v18, v18, v23
	add.2d	v19, v19, v23
	add.2d	v21, v21, v23
	add.2d	v3, v3, v23
	ldr	q23, [sp, #2928]                ; 16-byte Reload
	bit.16b	v23, v3, v14
	str	q23, [sp, #2928]                ; 16-byte Spill
	ldr	q23, [sp, #2768]                ; 16-byte Reload
	bit.16b	v23, v21, v24
	ldr	q3, [sp, #2784]                 ; 16-byte Reload
	bif.16b	v19, v3, v28
	ldr	q3, [sp, #2800]                 ; 16-byte Reload
	bif.16b	v18, v3, v22
	movi.2d	v31, #0000000000000000
	movi.2d	v9, #0000000000000000
	cmp	w13, #2052
	b.hi	LBB1_42
; %bb.44:                               ; %direct.true765.i.i
                                        ;   in Loop: Header=BB1_43 Depth=3
	ldr	q3, [x23, lCPI1_6@PAGEOFF]
	and.16b	v3, v25, v3
	addv.8h	h3, v3
	fmov	w13, s3
	shl.2d	v3, v18, #2
	dup.2d	v10, x0
	add.2d	v3, v10, v3
	tbnz	w13, #0, LBB1_52
; %bb.45:                               ; %else450
                                        ;   in Loop: Header=BB1_43 Depth=3
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_53
LBB1_46:                                ; %else456
                                        ;   in Loop: Header=BB1_43 Depth=3
	shl.2d	v3, v19, #2
	add.2d	v3, v10, v3
	tbnz	w13, #2, LBB1_54
LBB1_47:                                ; %else462
                                        ;   in Loop: Header=BB1_43 Depth=3
	tbnz	w13, #3, LBB1_55
LBB1_48:                                ; %else468
                                        ;   in Loop: Header=BB1_43 Depth=3
	shl.2d	v3, v23, #2
	add.2d	v3, v10, v3
	tbnz	w13, #4, LBB1_56
LBB1_49:                                ; %else474
                                        ;   in Loop: Header=BB1_43 Depth=3
	tbnz	w13, #5, LBB1_57
LBB1_50:                                ; %else480
                                        ;   in Loop: Header=BB1_43 Depth=3
	ldr	q3, [sp, #2928]                 ; 16-byte Reload
	shl.2d	v3, v3, #2
	add.2d	v3, v10, v3
	tbnz	w13, #6, LBB1_58
LBB1_51:                                ; %else486
                                        ;   in Loop: Header=BB1_43 Depth=3
	tbz	w13, #7, LBB1_42
	b	LBB1_59
LBB1_52:                                ; %cond.load446
                                        ;   in Loop: Header=BB1_43 Depth=3
	fmov	x14, d3
	ldr	s31, [x14]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_46
LBB1_53:                                ; %cond.load452
                                        ;   in Loop: Header=BB1_43 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v31 }[1], [x14]
	shl.2d	v3, v19, #2
	add.2d	v3, v10, v3
	tbz	w13, #2, LBB1_47
LBB1_54:                                ; %cond.load458
                                        ;   in Loop: Header=BB1_43 Depth=3
	fmov	x14, d3
	ld1.s	{ v31 }[2], [x14]
	tbz	w13, #3, LBB1_48
LBB1_55:                                ; %cond.load464
                                        ;   in Loop: Header=BB1_43 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v31 }[3], [x14]
	shl.2d	v3, v23, #2
	add.2d	v3, v10, v3
	tbz	w13, #4, LBB1_49
LBB1_56:                                ; %cond.load470
                                        ;   in Loop: Header=BB1_43 Depth=3
	fmov	x14, d3
	ld1.s	{ v9 }[0], [x14]
	tbz	w13, #5, LBB1_50
LBB1_57:                                ; %cond.load476
                                        ;   in Loop: Header=BB1_43 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v9 }[1], [x14]
	ldr	q3, [sp, #2928]                 ; 16-byte Reload
	shl.2d	v3, v3, #2
	add.2d	v3, v10, v3
	tbz	w13, #6, LBB1_51
LBB1_58:                                ; %cond.load482
                                        ;   in Loop: Header=BB1_43 Depth=3
	fmov	x14, d3
	ld1.s	{ v9 }[2], [x14]
	tbz	w13, #7, LBB1_42
LBB1_59:                                ; %cond.load488
                                        ;   in Loop: Header=BB1_43 Depth=3
	mov.d	x13, v3[1]
	ld1.s	{ v9 }[3], [x13]
	b	LBB1_42
LBB1_60:                                ; %direct.true155.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x19, x12
	mov	x12, x11
	mov	x11, x10
	mov	x10, x22
	lsl	x9, x21, #4
	dup.2d	v9, x9
	ldr	q3, [sp, #2864]                 ; 16-byte Reload
	add.2d	v31, v9, v3
	fmov	x9, d31
	add	x9, x9, x9, lsl #2
	lsl	x9, x9, #4
	fmov	d3, x9
	mov.d	x14, v31[1]
	add	x9, x14, x14, lsl #2
	lsl	x9, x9, #4
	mov.d	v3[1], x9
	ldr	w9, [sp, #444]                  ; 4-byte Reload
	tbz	w9, #0, LBB1_63
; %bb.61:                               ; %copy.active164.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x9, #0                          ; =0x0
	fmov	x16, d27
	ldr	q18, [sp, #2480]                ; 16-byte Reload
	fmov	x17, d18
	fmov	x13, d3
	add	x13, x0, x13, lsl #2
	add	x16, x16, x17
	add	x16, x16, #64
LBB1_62:                                ; %copy.chunk.i382.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q18, [x13, x9, lsl #4]
	stur	s18, [x16, #-64]
	mov	s19, v18[1]
	stur	s19, [x16, #-32]
	st1.s	{ v18 }[2], [x16]
	add	x17, x16, #32
	st1.s	{ v18 }[3], [x17]
	add	x9, x9, #1
	add	x16, x16, #128
	cmp	x9, #320
	b.ne	LBB1_62
LBB1_63:                                ; %copy.continue165.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x22, x20
	ldr	w9, [sp, #440]                  ; 4-byte Reload
	ldr	q21, [sp, #1856]                ; 16-byte Reload
	ldr	q25, [sp, #1680]                ; 16-byte Reload
	cbz	w9, LBB1_66
; %bb.64:                               ; %copy.active166.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x9, #0                          ; =0x0
	mov.d	x16, v27[1]
	ldr	q18, [sp, #2480]                ; 16-byte Reload
	mov.d	x17, v18[1]
	mov.d	x13, v3[1]
	add	x13, x0, x13, lsl #2
	add	x16, x16, x17
	add	x16, x16, #64
LBB1_65:                                ; %copy.chunk.i387.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x13, x9, lsl #4]
	stur	s3, [x16, #-64]
	mov	s18, v3[1]
	stur	s18, [x16, #-32]
	st1.s	{ v3 }[2], [x16]
	add	x17, x16, #32
	st1.s	{ v3 }[3], [x17]
	add	x9, x9, #1
	add	x16, x16, #128
	cmp	x9, #320
	b.ne	LBB1_65
LBB1_66:                                ; %copy.continue167.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2848]                 ; 16-byte Reload
	add.2d	v7, v9, v3
	fmov	x9, d7
	add	x9, x9, x9, lsl #2
	lsl	x9, x9, #4
	fmov	d3, x9
	mov.16b	v24, v7
	mov.d	x9, v7[1]
	add	x13, x9, x9, lsl #2
	lsl	x13, x13, #4
	mov.d	v3[1], x13
	mov	x20, x2
	cbz	w2, LBB1_69
; %bb.67:                               ; %copy.active168.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x13, #0                         ; =0x0
	ldr	q18, [sp, #1952]                ; 16-byte Reload
	fmov	x17, d18
	fmov	x2, d15
	fmov	x16, d3
	add	x16, x0, x16, lsl #2
	add	x17, x17, x2
	add	x17, x17, #64
LBB1_68:                                ; %copy.chunk.i393.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q18, [x16, x13, lsl #4]
	stur	s18, [x17, #-64]
	mov	s19, v18[1]
	stur	s19, [x17, #-32]
	st1.s	{ v18 }[2], [x17]
	add	x2, x17, #32
	st1.s	{ v18 }[3], [x2]
	add	x13, x13, #1
	add	x17, x17, #128
	cmp	x13, #320
	b.ne	LBB1_68
LBB1_69:                                ; %copy.continue169.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	w13, [sp, #436]                 ; 4-byte Reload
	cbz	w13, LBB1_72
; %bb.70:                               ; %copy.active170.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x13, #0                         ; =0x0
	ldr	q18, [sp, #1952]                ; 16-byte Reload
	mov.d	x17, v18[1]
	mov.d	x2, v15[1]
	mov.d	x16, v3[1]
	add	x16, x0, x16, lsl #2
	add	x17, x17, x2
	add	x17, x17, #64
LBB1_71:                                ; %copy.chunk.i399.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x16, x13, lsl #4]
	stur	s3, [x17, #-64]
	mov	s18, v3[1]
	stur	s18, [x17, #-32]
	st1.s	{ v3 }[2], [x17]
	add	x2, x17, #32
	st1.s	{ v3 }[3], [x2]
	add	x13, x13, #1
	add	x17, x17, #128
	cmp	x13, #320
	b.ne	LBB1_71
LBB1_72:                                ; %copy.continue171.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2832]                 ; 16-byte Reload
	add.2d	v7, v9, v3
	fmov	x13, d7
	add	x13, x13, x13, lsl #2
	lsl	x13, x13, #4
	fmov	d3, x13
	mov.d	x25, v7[1]
	add	x13, x25, x25, lsl #2
	lsl	x13, x13, #4
	mov.d	v3[1], x13
	ldr	w13, [sp, #432]                 ; 4-byte Reload
	cbz	w13, LBB1_75
; %bb.73:                               ; %copy.active172.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x13, #0                         ; =0x0
	ldr	q18, [sp, #1936]                ; 16-byte Reload
	fmov	x17, d18
	ldr	q18, [sp, #1904]                ; 16-byte Reload
	fmov	x2, d18
	fmov	x16, d3
	add	x16, x0, x16, lsl #2
	add	x17, x17, x2
	add	x17, x17, #64
LBB1_74:                                ; %copy.chunk.i405.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q18, [x16, x13, lsl #4]
	stur	s18, [x17, #-64]
	mov	s19, v18[1]
	stur	s19, [x17, #-32]
	st1.s	{ v18 }[2], [x17]
	add	x2, x17, #32
	st1.s	{ v18 }[3], [x2]
	add	x13, x13, #1
	add	x17, x17, #128
	cmp	x13, #320
	b.ne	LBB1_74
LBB1_75:                                ; %copy.continue173.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	w13, [sp, #428]                 ; 4-byte Reload
	cbz	w13, LBB1_78
; %bb.76:                               ; %copy.active174.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x13, #0                         ; =0x0
	ldr	q18, [sp, #1936]                ; 16-byte Reload
	mov.d	x17, v18[1]
	ldr	q18, [sp, #1904]                ; 16-byte Reload
	mov.d	x2, v18[1]
	mov.d	x16, v3[1]
	add	x16, x0, x16, lsl #2
	add	x17, x17, x2
	add	x17, x17, #64
LBB1_77:                                ; %copy.chunk.i411.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x16, x13, lsl #4]
	stur	s3, [x17, #-64]
	mov	s18, v3[1]
	stur	s18, [x17, #-32]
	st1.s	{ v3 }[2], [x17]
	add	x2, x17, #32
	st1.s	{ v3 }[3], [x2]
	add	x13, x13, #1
	add	x17, x17, #128
	cmp	x13, #320
	b.ne	LBB1_77
LBB1_78:                                ; %copy.continue175.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2816]                 ; 16-byte Reload
	add.2d	v10, v9, v3
	fmov	x13, d10
	add	x13, x13, x13, lsl #2
	lsl	x13, x13, #4
	fmov	d3, x13
	mov.d	x13, v10[1]
	add	x16, x13, x13, lsl #2
	lsl	x16, x16, #4
	mov.d	v3[1], x16
	ldr	w16, [sp, #424]                 ; 4-byte Reload
	cbz	w16, LBB1_81
; %bb.79:                               ; %copy.active176.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x16, #0                         ; =0x0
	ldr	q18, [sp, #1920]                ; 16-byte Reload
	fmov	x2, d18
	ldr	q18, [sp, #1888]                ; 16-byte Reload
	fmov	x24, d18
	fmov	x17, d3
	add	x17, x0, x17, lsl #2
	add	x2, x2, x24
	add	x2, x2, #64
LBB1_80:                                ; %copy.chunk.i417.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q18, [x17, x16, lsl #4]
	stur	s18, [x2, #-64]
	mov	s19, v18[1]
	stur	s19, [x2, #-32]
	st1.s	{ v18 }[2], [x2]
	add	x24, x2, #32
	st1.s	{ v18 }[3], [x24]
	add	x16, x16, #1
	add	x2, x2, #128
	cmp	x16, #320
	b.ne	LBB1_80
LBB1_81:                                ; %copy.continue177.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	w16, [sp, #420]                 ; 4-byte Reload
	ldr	q9, [sp, #1664]                 ; 16-byte Reload
	cbz	w16, LBB1_84
; %bb.82:                               ; %copy.active178.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x16, #0                         ; =0x0
	ldr	q18, [sp, #1920]                ; 16-byte Reload
	mov.d	x2, v18[1]
	ldr	q18, [sp, #1888]                ; 16-byte Reload
	mov.d	x24, v18[1]
	mov.d	x17, v3[1]
	add	x17, x0, x17, lsl #2
	add	x2, x2, x24
	add	x2, x2, #64
LBB1_83:                                ; %copy.chunk.i423.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x17, x16, lsl #4]
	stur	s3, [x2, #-64]
	mov	s18, v3[1]
	stur	s18, [x2, #-32]
	st1.s	{ v3 }[2], [x2]
	add	x24, x2, #32
	st1.s	{ v3 }[3], [x24]
	add	x16, x16, #1
	add	x2, x2, #128
	cmp	x16, #320
	b.ne	LBB1_83
LBB1_84:                                ; %direct.schedule.7.thread.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	sshll.2d	v3, v2, #0
	ldr	q18, [sp, #2000]                ; 16-byte Reload
	bit.16b	v21, v18, v3
	ldr	q18, [sp, #2464]                ; 16-byte Reload
	bit.16b	v9, v18, v3
	fmov	x16, d31
	add	x16, x16, x16, lsl #1
	lsl	x16, x16, #5
	fmov	d3, x16
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #5
	mov.d	v3[1], x14
	ldr	w14, [sp, #444]                 ; 4-byte Reload
	tbz	w14, #0, LBB1_87
; %bb.85:                               ; %copy.active191.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x14, #0                         ; =0x0
	fmov	x17, d21
	fmov	x2, d9
	fmov	x16, d3
	add	x16, x1, x16, lsl #2
	add	x17, x17, x2
	add	x17, x17, #64
LBB1_86:                                ; %copy.chunk.i429.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q18, [x16, x14, lsl #4]
	stur	s18, [x17, #-64]
	mov	s19, v18[1]
	stur	s19, [x17, #-32]
	st1.s	{ v18 }[2], [x17]
	add	x2, x17, #32
	st1.s	{ v18 }[3], [x2]
	add	x14, x14, #1
	add	x17, x17, #128
	cmp	x14, #384
	b.ne	LBB1_86
LBB1_87:                                ; %copy.continue192.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	w14, [sp, #440]                 ; 4-byte Reload
	ldr	q31, [sp, #1648]                ; 16-byte Reload
	cbz	w14, LBB1_90
; %bb.88:                               ; %copy.active193.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x14, #0                         ; =0x0
	mov.d	x17, v21[1]
	mov.d	x2, v9[1]
	mov.d	x16, v3[1]
	add	x16, x1, x16, lsl #2
	add	x17, x17, x2
	add	x17, x17, #64
LBB1_89:                                ; %copy.chunk.i434.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x16, x14, lsl #4]
	stur	s3, [x17, #-64]
	mov	s18, v3[1]
	stur	s18, [x17, #-32]
	st1.s	{ v3 }[2], [x17]
	add	x2, x17, #32
	st1.s	{ v3 }[3], [x2]
	add	x14, x14, #1
	add	x17, x17, #128
	cmp	x14, #384
	b.ne	LBB1_89
LBB1_90:                                ; %copy.continue194.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2000]                 ; 16-byte Reload
	bit.16b	v26, v3, v28
	ldr	q3, [sp, #2048]                 ; 16-byte Reload
	bit.16b	v31, v3, v28
	fmov	x14, d24
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #5
	fmov	d3, x14
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #5
	mov.d	v3[1], x9
	mov	w24, #33280                     ; =0x8200
	movk	w24, #1, lsl #16
	mov	x2, x20
	cbz	w20, LBB1_93
; %bb.91:                               ; %copy.active195.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x9, #0                          ; =0x0
	fmov	x16, d26
	fmov	x17, d31
	fmov	x14, d3
	add	x14, x1, x14, lsl #2
	add	x16, x16, x17
	add	x16, x16, #64
LBB1_92:                                ; %copy.chunk.i440.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q18, [x14, x9, lsl #4]
	stur	s18, [x16, #-64]
	mov	s19, v18[1]
	stur	s19, [x16, #-32]
	st1.s	{ v18 }[2], [x16]
	add	x17, x16, #32
	st1.s	{ v18 }[3], [x17]
	add	x9, x9, #1
	add	x16, x16, #128
	cmp	x9, #384
	b.ne	LBB1_92
LBB1_93:                                ; %copy.continue196.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	w9, [sp, #436]                  ; 4-byte Reload
	mov	x20, x22
	cbz	w9, LBB1_96
; %bb.94:                               ; %copy.active197.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x9, #0                          ; =0x0
	mov.d	x16, v26[1]
	mov.d	x17, v31[1]
	mov.d	x14, v3[1]
	add	x14, x1, x14, lsl #2
	add	x16, x16, x17
	add	x16, x16, #64
LBB1_95:                                ; %copy.chunk.i446.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x14, x9, lsl #4]
	stur	s3, [x16, #-64]
	mov	s18, v3[1]
	stur	s18, [x16, #-32]
	st1.s	{ v3 }[2], [x16]
	add	x17, x16, #32
	st1.s	{ v3 }[3], [x17]
	add	x9, x9, #1
	add	x16, x16, #128
	cmp	x9, #384
	b.ne	LBB1_95
LBB1_96:                                ; %copy.continue198.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	sshll.2d	v3, v0, #0
	ldr	q18, [sp, #2000]                ; 16-byte Reload
	bit.16b	v12, v18, v3
	ldr	q18, [sp, #1984]                ; 16-byte Reload
	ldr	q19, [sp, #2032]                ; 16-byte Reload
	bit.16b	v18, v19, v3
	str	q18, [sp, #1984]                ; 16-byte Spill
	fmov	x9, d7
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #5
	fmov	d3, x9
	add	x9, x25, x25, lsl #1
	lsl	x9, x9, #5
	mov.d	v3[1], x9
	ldr	w9, [sp, #432]                  ; 4-byte Reload
	mov	x22, x10
	cbz	w9, LBB1_99
; %bb.97:                               ; %copy.active199.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x9, #0                          ; =0x0
	fmov	x16, d12
	ldr	q18, [sp, #1984]                ; 16-byte Reload
	fmov	x17, d18
	fmov	x14, d3
	add	x14, x1, x14, lsl #2
	add	x16, x16, x17
	add	x16, x16, #64
LBB1_98:                                ; %copy.chunk.i452.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q18, [x14, x9, lsl #4]
	stur	s18, [x16, #-64]
	mov	s19, v18[1]
	stur	s19, [x16, #-32]
	st1.s	{ v18 }[2], [x16]
	add	x17, x16, #32
	st1.s	{ v18 }[3], [x17]
	add	x9, x9, #1
	add	x16, x16, #128
	cmp	x9, #384
	b.ne	LBB1_98
LBB1_99:                                ; %copy.continue200.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q28, [sp, #2160]                ; 16-byte Reload
	ldr	w9, [sp, #428]                  ; 4-byte Reload
	mov	x10, x11
	cbz	w9, LBB1_102
; %bb.100:                              ; %copy.active201.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x9, #0                          ; =0x0
	mov.d	x16, v12[1]
	ldr	q7, [sp, #1984]                 ; 16-byte Reload
	mov.d	x17, v7[1]
	mov.d	x14, v3[1]
	add	x14, x1, x14, lsl #2
	add	x16, x16, x17
	add	x16, x16, #64
LBB1_101:                               ; %copy.chunk.i458.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x14, x9, lsl #4]
	stur	s3, [x16, #-64]
	mov	s18, v3[1]
	stur	s18, [x16, #-32]
	st1.s	{ v3 }[2], [x16]
	add	x17, x16, #32
	st1.s	{ v3 }[3], [x17]
	add	x9, x9, #1
	add	x16, x16, #128
	cmp	x9, #384
	b.ne	LBB1_101
LBB1_102:                               ; %copy.continue202.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov.16b	v7, v20
	ldr	q3, [sp, #2000]                 ; 16-byte Reload
	bit.16b	v25, v3, v14
	ldr	q3, [sp, #1968]                 ; 16-byte Reload
	ldr	q18, [sp, #2688]                ; 16-byte Reload
	bit.16b	v3, v18, v14
	str	q3, [sp, #1968]                 ; 16-byte Spill
	fmov	x9, d10
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #5
	fmov	d3, x9
	add	x9, x13, x13, lsl #1
	lsl	x9, x9, #5
	mov.d	v3[1], x9
	ldr	w9, [sp, #424]                  ; 4-byte Reload
	mov	x11, x12
	cbz	w9, LBB1_105
; %bb.103:                              ; %copy.active203.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x9, #0                          ; =0x0
	fmov	x14, d25
	ldr	q18, [sp, #1968]                ; 16-byte Reload
	fmov	x16, d18
	fmov	x13, d3
	add	x13, x1, x13, lsl #2
	add	x14, x14, x16
	add	x14, x14, #64
LBB1_104:                               ; %copy.chunk.i464.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q18, [x13, x9, lsl #4]
	stur	s18, [x14, #-64]
	mov	s19, v18[1]
	stur	s19, [x14, #-32]
	st1.s	{ v18 }[2], [x14]
	add	x16, x14, #32
	st1.s	{ v18 }[3], [x16]
	add	x9, x9, #1
	add	x14, x14, #128
	cmp	x9, #384
	b.ne	LBB1_104
LBB1_105:                               ; %copy.continue204.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	str	q12, [sp, #1584]                ; 16-byte Spill
	str	q26, [sp, #1600]                ; 16-byte Spill
	mov.16b	v20, v29
	ldr	w9, [sp, #420]                  ; 4-byte Reload
	mov	x12, x19
	str	q21, [sp, #1856]                ; 16-byte Spill
	str	q25, [sp, #1680]                ; 16-byte Spill
	str	q9, [sp, #1664]                 ; 16-byte Spill
	str	q31, [sp, #1648]                ; 16-byte Spill
	cbz	w9, LBB1_129
; %bb.106:                              ; %copy.active205.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x9, #0                          ; =0x0
	mov.d	x14, v25[1]
	ldr	q18, [sp, #1968]                ; 16-byte Reload
	mov.d	x16, v18[1]
	mov.d	x13, v3[1]
	add	x13, x1, x13, lsl #2
	add	x14, x14, x16
	add	x14, x14, #64
	mov	w19, #52429                     ; =0xcccd
	ldr	q29, [sp, #2176]                ; 16-byte Reload
	ldr	q26, [sp, #2144]                ; 16-byte Reload
	ldr	q12, [sp, #2128]                ; 16-byte Reload
LBB1_107:                               ; %copy.chunk.i470.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x13, x9, lsl #4]
	stur	s3, [x14, #-64]
	mov	s18, v3[1]
	stur	s18, [x14, #-32]
	st1.s	{ v3 }[2], [x14]
	add	x16, x14, #32
	st1.s	{ v3 }[3], [x16]
	add	x9, x9, #1
	add	x14, x14, #128
	cmp	x9, #384
	b.ne	LBB1_107
; %bb.108:                              ;   in Loop: Header=BB1_40 Depth=2
	ldr	q21, [sp, #2576]                ; 16-byte Reload
	b	LBB1_131
LBB1_109:                               ; %direct.true727.i.i.preheader
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q28, [sp, #2160]                ; 16-byte Reload
	mov.16b	v7, v20
	mov.16b	v20, v29
	mov	x9, #0                          ; =0x0
	b	LBB1_111
LBB1_110:                               ; %direct.schedule.44.i.i
                                        ;   in Loop: Header=BB1_111 Depth=3
	str	q23, [sp, #2720]                ; 16-byte Spill
	str	q19, [sp, #2736]                ; 16-byte Spill
	str	q18, [sp, #2752]                ; 16-byte Spill
	add	x13, x5, x9, lsl #5
	ldp	q3, q18, [x13]
	bit.16b	v18, v9, v0
	bit.16b	v3, v31, v2
	stp	q3, q18, [x13]
	add	x9, x9, #1
	cmp	x9, #1536
	b.eq	LBB1_128
LBB1_111:                               ; %direct.true727.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	w13, w9, #0xffff
	mul	w14, w13, w26
	mov	w13, #2048                      ; =0x800
	bfxil	w13, w14, #22, #10
	dup.2d	v3, x13
	ldr	q18, [sp, #2864]                ; 16-byte Reload
	add.2d	v18, v3, v18
	ldr	q19, [sp, #2848]                ; 16-byte Reload
	add.2d	v19, v3, v19
	ldr	q21, [sp, #2832]                ; 16-byte Reload
	add.2d	v21, v3, v21
	ldr	q22, [sp, #2816]                ; 16-byte Reload
	add.2d	v3, v3, v22
	mov.d	x16, v3[1]
	fmov	x17, d3
	add	x17, x17, x17, lsl #1
	lsl	x17, x17, #5
	fmov	d3, x17
	add	x16, x16, x16, lsl #1
	lsl	x16, x16, #5
	mov.d	v3[1], x16
	mov.d	x16, v21[1]
	fmov	x17, d21
	add	x17, x17, x17, lsl #1
	lsl	x17, x17, #5
	fmov	d21, x17
	add	x16, x16, x16, lsl #1
	lsl	x16, x16, #5
	mov.d	v21[1], x16
	mov.d	x16, v19[1]
	fmov	x17, d19
	add	x17, x17, x17, lsl #1
	lsl	x17, x17, #5
	fmov	d19, x17
	add	x16, x16, x16, lsl #1
	lsl	x16, x16, #5
	mov.d	v19[1], x16
	mov.d	x16, v18[1]
	fmov	x17, d18
	add	x17, x17, x17, lsl #1
	lsl	x17, x17, #5
	fmov	d18, x17
	sshll.2d	v22, v2, #0
	lsr	w14, w14, #22
	msub	w14, w14, w27, w9
	and	x14, x14, #0xffff
	add	x16, x16, x16, lsl #1
	lsl	x16, x16, #5
	mov.d	v18[1], x16
	dup.2d	v23, x14
	sshll.2d	v24, v0, #0
	add.2d	v18, v18, v23
	add.2d	v19, v19, v23
	add.2d	v21, v21, v23
	add.2d	v3, v3, v23
	ldr	q23, [sp, #2912]                ; 16-byte Reload
	bit.16b	v23, v3, v14
	str	q23, [sp, #2912]                ; 16-byte Spill
	ldr	q23, [sp, #2720]                ; 16-byte Reload
	bit.16b	v23, v21, v24
	ldr	q3, [sp, #2736]                 ; 16-byte Reload
	ldr	q21, [sp, #2704]                ; 16-byte Reload
	bif.16b	v19, v3, v21
	ldr	q3, [sp, #2752]                 ; 16-byte Reload
	bif.16b	v18, v3, v22
	movi.2d	v31, #0000000000000000
	movi.2d	v9, #0000000000000000
	cmp	w13, #2052
	b.hi	LBB1_110
; %bb.112:                              ; %direct.true740.i.i
                                        ;   in Loop: Header=BB1_111 Depth=3
	ldr	q3, [x23, lCPI1_6@PAGEOFF]
	and.16b	v3, v25, v3
	addv.8h	h3, v3
	fmov	w13, s3
	shl.2d	v3, v18, #2
	dup.2d	v10, x1
	add.2d	v3, v10, v3
	tbnz	w13, #0, LBB1_120
; %bb.113:                              ; %else
                                        ;   in Loop: Header=BB1_111 Depth=3
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_121
LBB1_114:                               ; %else425
                                        ;   in Loop: Header=BB1_111 Depth=3
	shl.2d	v3, v19, #2
	add.2d	v3, v10, v3
	tbnz	w13, #2, LBB1_122
LBB1_115:                               ; %else428
                                        ;   in Loop: Header=BB1_111 Depth=3
	tbnz	w13, #3, LBB1_123
LBB1_116:                               ; %else431
                                        ;   in Loop: Header=BB1_111 Depth=3
	shl.2d	v3, v23, #2
	add.2d	v3, v10, v3
	tbnz	w13, #4, LBB1_124
LBB1_117:                               ; %else434
                                        ;   in Loop: Header=BB1_111 Depth=3
	tbnz	w13, #5, LBB1_125
LBB1_118:                               ; %else437
                                        ;   in Loop: Header=BB1_111 Depth=3
	ldr	q3, [sp, #2912]                 ; 16-byte Reload
	shl.2d	v3, v3, #2
	add.2d	v3, v10, v3
	tbnz	w13, #6, LBB1_126
LBB1_119:                               ; %else440
                                        ;   in Loop: Header=BB1_111 Depth=3
	tbz	w13, #7, LBB1_110
	b	LBB1_127
LBB1_120:                               ; %cond.load
                                        ;   in Loop: Header=BB1_111 Depth=3
	fmov	x14, d3
	ldr	s31, [x14]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_114
LBB1_121:                               ; %cond.load424
                                        ;   in Loop: Header=BB1_111 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v31 }[1], [x14]
	shl.2d	v3, v19, #2
	add.2d	v3, v10, v3
	tbz	w13, #2, LBB1_115
LBB1_122:                               ; %cond.load427
                                        ;   in Loop: Header=BB1_111 Depth=3
	fmov	x14, d3
	ld1.s	{ v31 }[2], [x14]
	tbz	w13, #3, LBB1_116
LBB1_123:                               ; %cond.load430
                                        ;   in Loop: Header=BB1_111 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v31 }[3], [x14]
	shl.2d	v3, v23, #2
	add.2d	v3, v10, v3
	tbz	w13, #4, LBB1_117
LBB1_124:                               ; %cond.load433
                                        ;   in Loop: Header=BB1_111 Depth=3
	fmov	x14, d3
	ld1.s	{ v9 }[0], [x14]
	tbz	w13, #5, LBB1_118
LBB1_125:                               ; %cond.load436
                                        ;   in Loop: Header=BB1_111 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v9 }[1], [x14]
	ldr	q3, [sp, #2912]                 ; 16-byte Reload
	shl.2d	v3, v3, #2
	add.2d	v3, v10, v3
	tbz	w13, #6, LBB1_119
LBB1_126:                               ; %cond.load439
                                        ;   in Loop: Header=BB1_111 Depth=3
	fmov	x14, d3
	ld1.s	{ v9 }[2], [x14]
	tbz	w13, #7, LBB1_110
LBB1_127:                               ; %cond.load442
                                        ;   in Loop: Header=BB1_111 Depth=3
	mov.d	x13, v3[1]
	ld1.s	{ v9 }[3], [x13]
	b	LBB1_110
LBB1_128:                               ; %direct.schedule.9.loopexit.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	sshll.2d	v3, v2, #0
	sshll.2d	v18, v0, #0
	ldr	q19, [sp, #1680]                ; 16-byte Reload
	ldr	q21, [sp, #2000]                ; 16-byte Reload
	bit.16b	v19, v21, v14
	str	q19, [sp, #1680]                ; 16-byte Spill
	ldr	q22, [sp, #2704]                ; 16-byte Reload
	bit.16b	v26, v21, v22
	str	q26, [sp, #1600]                ; 16-byte Spill
	bit.16b	v12, v21, v18
	str	q12, [sp, #1584]                ; 16-byte Spill
	ldr	q19, [sp, #1856]                ; 16-byte Reload
	bit.16b	v19, v21, v3
	str	q19, [sp, #1856]                ; 16-byte Spill
	ldr	q19, [sp, #1968]                ; 16-byte Reload
	ldr	q21, [sp, #2688]                ; 16-byte Reload
	bit.16b	v19, v21, v14
	str	q19, [sp, #1968]                ; 16-byte Spill
	ldr	q19, [sp, #1648]                ; 16-byte Reload
	ldr	q21, [sp, #2048]                ; 16-byte Reload
	bit.16b	v19, v21, v22
	str	q19, [sp, #1648]                ; 16-byte Spill
	ldr	q19, [sp, #1984]                ; 16-byte Reload
	ldr	q21, [sp, #2032]                ; 16-byte Reload
	bit.16b	v19, v21, v18
	str	q19, [sp, #1984]                ; 16-byte Spill
	ldr	q18, [sp, #2464]                ; 16-byte Reload
	ldr	q19, [sp, #1664]                ; 16-byte Reload
	bit.16b	v19, v18, v3
	str	q19, [sp, #1664]                ; 16-byte Spill
	b	LBB1_130
LBB1_129:                               ;   in Loop: Header=BB1_40 Depth=2
	mov	w19, #52429                     ; =0xcccd
LBB1_130:                               ; %direct.schedule.9.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q21, [sp, #2576]                ; 16-byte Reload
	ldr	q29, [sp, #2176]                ; 16-byte Reload
	ldr	q26, [sp, #2144]                ; 16-byte Reload
	ldr	q12, [sp, #2128]                ; 16-byte Reload
LBB1_131:                               ; %direct.schedule.9.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x9, #0                          ; =0x0
	bic.16b	v12, v12, v0
	bic.16b	v26, v26, v2
	bic.16b	v27, v13, v0
	bic.16b	v28, v28, v2
	bic.16b	v7, v7, v0
	bic.16b	v20, v20, v2
	bic.16b	v29, v29, v0
	ldr	q13, [sp, #2192]                ; 16-byte Reload
	bic.16b	v13, v13, v2
	ldr	q15, [sp, #2480]                ; 16-byte Reload
	ldr	q14, [sp, #2896]                ; 16-byte Reload
LBB1_132:                               ; %direct.true208.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	d3, x9
	orr.16b	v18, v3, v14
	fmov	x13, d18
	add	x13, x8, x13
	ldp	q19, q18, [x13]
	and.16b	v19, v2, v19
	and.16b	v18, v0, v18
	orr.16b	v3, v3, v15
	fmov	x13, d3
	add	x13, x4, x13
	ldp	q22, q3, [x13]
	and.16b	v22, v2, v22
	and.16b	v3, v0, v3
	fmul.4s	v3, v18, v3
	fmul.4s	v22, v19, v22
	fadd.4s	v22, v26, v22
	fadd.4s	v3, v12, v3
	add	x13, x8, x9
	ldr	q23, [x13, #11280]
	ldr	q24, [x13, #11264]
	and.16b	v24, v2, v24
	and.16b	v23, v0, v23
	fmul.4s	v23, v18, v23
	fmul.4s	v24, v19, v24
	fadd.4s	v24, v28, v24
	fadd.4s	v23, v27, v23
	ldr	q25, [x13, #13840]
	ldr	q31, [x13, #13824]
	and.16b	v31, v2, v31
	and.16b	v25, v0, v25
	fmul.4s	v25, v18, v25
	fmul.4s	v31, v19, v31
	fadd.4s	v31, v20, v31
	fadd.4s	v25, v7, v25
	ldr	q9, [x13, #16400]
	ldr	q10, [x13, #16384]
	and.16b	v10, v2, v10
	and.16b	v9, v0, v9
	fmul.4s	v18, v18, v9
	fmul.4s	v19, v19, v10
	fadd.4s	v19, v13, v19
	fadd.4s	v18, v29, v18
	bit.16b	v12, v3, v0
	bit.16b	v26, v22, v2
	bit.16b	v27, v23, v0
	bit.16b	v28, v24, v2
	bit.16b	v7, v25, v0
	bit.16b	v20, v31, v2
	bit.16b	v29, v18, v0
	bit.16b	v13, v19, v2
	add	x9, x9, #32
	cmp	x9, #2560
	b.ne	LBB1_132
; %bb.133:                              ; %direct.false209.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	str	q12, [sp, #2128]                ; 16-byte Spill
	str	q26, [sp, #2144]                ; 16-byte Spill
	str	q27, [sp, #2064]                ; 16-byte Spill
	str	q28, [sp, #2160]                ; 16-byte Spill
	str	q7, [sp, #2080]                 ; 16-byte Spill
	str	q20, [sp, #2096]                ; 16-byte Spill
	str	q29, [sp, #2176]                ; 16-byte Spill
	str	q13, [sp, #2192]                ; 16-byte Spill
	ldr	q26, [sp, #2208]                ; 16-byte Reload
	bic.16b	v26, v26, v0
	ldr	q27, [sp, #2224]                ; 16-byte Reload
	bic.16b	v27, v27, v2
	ldr	q28, [sp, #2240]                ; 16-byte Reload
	bic.16b	v28, v28, v0
	ldr	q7, [sp, #2256]                 ; 16-byte Reload
	bic.16b	v7, v7, v2
	ldr	q20, [sp, #2272]                ; 16-byte Reload
	bic.16b	v20, v20, v0
	ldr	q12, [sp, #2288]                ; 16-byte Reload
	bic.16b	v12, v12, v2
	ldr	q29, [sp, #2560]                ; 16-byte Reload
	bic.16b	v29, v29, v0
	mov	x9, x8
	mov	w13, #80                        ; =0x50
	ldr	q15, [sp, #2304]                ; 16-byte Reload
	bic.16b	v15, v15, v2
LBB1_134:                               ; %direct.true244.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q18, q3, [x9]
	and.16b	v18, v2, v18
	and.16b	v3, v0, v3
	ldr	q19, [x9, #18960]
	ldr	q22, [x9, #18944]
	and.16b	v22, v2, v22
	and.16b	v19, v0, v19
	fmul.4s	v19, v3, v19
	fmul.4s	v22, v18, v22
	fadd.4s	v22, v27, v22
	fadd.4s	v19, v26, v19
	ldr	q23, [x9, #21520]
	ldr	q24, [x9, #21504]
	and.16b	v24, v2, v24
	and.16b	v23, v0, v23
	fmul.4s	v23, v3, v23
	fmul.4s	v24, v18, v24
	fadd.4s	v24, v7, v24
	fadd.4s	v23, v28, v23
	ldr	q25, [x9, #24080]
	ldr	q31, [x9, #24064]
	and.16b	v31, v2, v31
	and.16b	v25, v0, v25
	fmul.4s	v25, v3, v25
	fmul.4s	v31, v18, v31
	fadd.4s	v31, v12, v31
	fadd.4s	v25, v20, v25
	ldr	q9, [x9, #26640]
	ldr	q10, [x9, #26624]
	and.16b	v10, v2, v10
	and.16b	v9, v0, v9
	fmul.4s	v3, v3, v9
	fmul.4s	v18, v18, v10
	fadd.4s	v18, v15, v18
	fadd.4s	v3, v29, v3
	bit.16b	v26, v19, v0
	bit.16b	v27, v22, v2
	bit.16b	v28, v23, v0
	bit.16b	v7, v24, v2
	bit.16b	v20, v25, v0
	bit.16b	v12, v31, v2
	bit.16b	v29, v3, v0
	bit.16b	v15, v18, v2
	add	x9, x9, #32
	subs	x13, x13, #1
	b.ne	LBB1_134
; %bb.135:                              ; %direct.false245.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	str	q26, [sp, #2208]                ; 16-byte Spill
	str	q27, [sp, #2224]                ; 16-byte Spill
	str	q28, [sp, #2240]                ; 16-byte Spill
	str	q7, [sp, #2256]                 ; 16-byte Spill
	str	q20, [sp, #2272]                ; 16-byte Spill
	str	q12, [sp, #2288]                ; 16-byte Spill
	str	q29, [sp, #2560]                ; 16-byte Spill
	str	q15, [sp, #2304]                ; 16-byte Spill
	ldr	q28, [sp, #2320]                ; 16-byte Reload
	bic.16b	v28, v28, v0
	ldr	q13, [sp, #2336]                ; 16-byte Reload
	bic.16b	v13, v13, v2
	bic.16b	v11, v11, v0
	ldr	q20, [sp, #2352]                ; 16-byte Reload
	bic.16b	v20, v20, v2
	ldr	q15, [sp, #2368]                ; 16-byte Reload
	bic.16b	v15, v15, v0
	ldr	q12, [sp, #2384]                ; 16-byte Reload
	bic.16b	v12, v12, v2
	bic.16b	v21, v21, v0
	mov	x9, x8
	mov	w13, #80                        ; =0x50
	ldr	q7, [sp, #2400]                 ; 16-byte Reload
	bic.16b	v7, v7, v2
LBB1_136:                               ; %direct.true282.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q18, q3, [x9]
	and.16b	v18, v2, v18
	and.16b	v3, v0, v3
	ldr	q19, [x9, #29200]
	ldr	q22, [x9, #29184]
	and.16b	v22, v2, v22
	and.16b	v19, v0, v19
	fmul.4s	v19, v3, v19
	fmul.4s	v22, v18, v22
	fadd.4s	v22, v13, v22
	fadd.4s	v19, v28, v19
	ldr	q23, [x9, #31760]
	ldr	q24, [x9, #31744]
	and.16b	v24, v2, v24
	and.16b	v23, v0, v23
	fmul.4s	v23, v3, v23
	fmul.4s	v24, v18, v24
	fadd.4s	v24, v20, v24
	fadd.4s	v23, v11, v23
	ldr	q25, [x9, #34320]
	ldr	q31, [x9, #34304]
	and.16b	v31, v2, v31
	and.16b	v25, v0, v25
	fmul.4s	v25, v3, v25
	fmul.4s	v31, v18, v31
	fadd.4s	v31, v12, v31
	fadd.4s	v25, v15, v25
	mov.16b	v14, v11
	ldr	q9, [x9, #36880]
	ldr	q10, [x9, #36864]
	and.16b	v10, v2, v10
	and.16b	v9, v0, v9
	fmul.4s	v3, v3, v9
	fmul.4s	v18, v18, v10
	fadd.4s	v18, v7, v18
	fadd.4s	v3, v21, v3
	bit.16b	v28, v19, v0
	bit.16b	v13, v22, v2
	mov.16b	v11, v0
	bsl.16b	v11, v23, v14
	bit.16b	v20, v24, v2
	bit.16b	v15, v25, v0
	bit.16b	v12, v31, v2
	bit.16b	v21, v3, v0
	bit.16b	v7, v18, v2
	add	x9, x9, #32
	subs	x13, x13, #1
	b.ne	LBB1_136
; %bb.137:                              ; %direct.false283.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	str	q28, [sp, #2320]                ; 16-byte Spill
	str	q13, [sp, #2336]                ; 16-byte Spill
	str	q11, [sp, #2112]                ; 16-byte Spill
	str	q20, [sp, #2352]                ; 16-byte Spill
	str	q15, [sp, #2368]                ; 16-byte Spill
	str	q12, [sp, #2384]                ; 16-byte Spill
	str	q21, [sp, #2576]                ; 16-byte Spill
	str	q7, [sp, #2400]                 ; 16-byte Spill
	ldr	q9, [sp, #1696]                 ; 16-byte Reload
	bic.16b	v9, v9, v0
	ldr	q15, [sp, #1712]                ; 16-byte Reload
	bic.16b	v15, v15, v2
	ldr	q14, [sp, #1728]                ; 16-byte Reload
	bic.16b	v14, v14, v0
	ldr	q13, [sp, #1744]                ; 16-byte Reload
	bic.16b	v13, v13, v2
	ldr	q12, [sp, #2416]                ; 16-byte Reload
	bic.16b	v12, v12, v0
	ldr	q11, [sp, #2432]                ; 16-byte Reload
	bic.16b	v11, v11, v2
	ldr	q28, [sp, #1760]                ; 16-byte Reload
	bic.16b	v28, v28, v0
	mov	x9, x8
	mov	w13, #80                        ; =0x50
	ldr	q21, [sp, #2448]                ; 16-byte Reload
	bic.16b	v21, v21, v2
	ldr	q26, [sp, #2208]                ; 16-byte Reload
	ldr	q29, [sp, #2096]                ; 16-byte Reload
	ldr	q20, [sp, #2080]                ; 16-byte Reload
	ldr	q7, [sp, #2160]                 ; 16-byte Reload
LBB1_138:                               ; %direct.true320.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q18, q3, [x9]
	and.16b	v18, v2, v18
	and.16b	v3, v0, v3
	ldr	q19, [x9, #39440]
	ldr	q22, [x9, #39424]
	and.16b	v22, v2, v22
	and.16b	v19, v0, v19
	fmul.4s	v19, v3, v19
	fmul.4s	v22, v18, v22
	fadd.4s	v22, v15, v22
	fadd.4s	v19, v9, v19
	ldr	q23, [x9, #42000]
	ldr	q24, [x9, #41984]
	and.16b	v24, v2, v24
	and.16b	v23, v0, v23
	fmul.4s	v23, v3, v23
	fmul.4s	v24, v18, v24
	fadd.4s	v24, v13, v24
	fadd.4s	v23, v14, v23
	ldr	q25, [x9, #44560]
	ldr	q31, [x9, #44544]
	and.16b	v31, v2, v31
	and.16b	v25, v0, v25
	fmul.4s	v25, v3, v25
	fmul.4s	v31, v18, v31
	fadd.4s	v31, v11, v31
	fadd.4s	v25, v12, v25
	mov.16b	v27, v9
	ldr	q9, [x9, #47120]
	ldr	q10, [x9, #47104]
	and.16b	v10, v2, v10
	and.16b	v9, v0, v9
	fmul.4s	v3, v3, v9
	fmul.4s	v18, v18, v10
	fadd.4s	v18, v21, v18
	fadd.4s	v3, v28, v3
	mov.16b	v9, v0
	bsl.16b	v9, v19, v27
	bit.16b	v15, v22, v2
	bit.16b	v14, v23, v0
	bit.16b	v13, v24, v2
	bit.16b	v12, v25, v0
	bit.16b	v11, v31, v2
	bit.16b	v28, v3, v0
	bit.16b	v21, v18, v2
	add	x9, x9, #32
	subs	x13, x13, #1
	b.ne	LBB1_138
; %bb.139:                              ; %direct.false321.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x9, #0                          ; =0x0
	mov	w13, #63790                     ; =0xf92e
	movk	w13, #15844, lsl #16
	dup.4s	v10, w13
	ldr	q3, [sp, #2144]                 ; 16-byte Reload
	fmul.4s	v22, v3, v10
	ldr	q3, [sp, #2128]                 ; 16-byte Reload
	fmul.4s	v19, v3, v10
	add	x13, x8, x24
	ldp	q3, q18, [x13]
	fmul.4s	v23, v7, v10
	cmp	x21, #128
	str	q19, [sp, #2672]                ; 16-byte Spill
	bit.16b	v18, v19, v0
	str	q22, [sp, #2656]                ; 16-byte Spill
	bit.16b	v3, v22, v2
	stp	q3, q18, [x13]
	cset	w13, lo
	dup.4h	v3, w13
	ldr	q7, [sp, #2064]                 ; 16-byte Reload
	fmul.4s	v7, v7, v10
	fmul.4s	v31, v29, v10
	fmul.4s	v25, v20, v10
	ldr	q18, [sp, #2192]                ; 16-byte Reload
	fmul.4s	v29, v18, v10
	ldp	q18, q19, [x20]
	ldr	q22, [sp, #2176]                ; 16-byte Reload
	fmul.4s	v27, v22, v10
	ldr	q22, [sp, #2224]                ; 16-byte Reload
	fmul.4s	v20, v22, v10
	str	q7, [sp, #1456]                 ; 16-byte Spill
	bit.16b	v19, v7, v0
	str	q23, [sp, #1440]                ; 16-byte Spill
	bit.16b	v18, v23, v2
	stp	q18, q19, [x20]
	fmul.4s	v7, v26, v10
	ldr	q18, [sp, #2240]                ; 16-byte Reload
	fmul.4s	v18, v18, v10
	ldr	q19, [sp, #2256]                ; 16-byte Reload
	fmul.4s	v19, v19, v10
	ldp	q22, q23, [x22]
	ldr	q24, [sp, #2272]                ; 16-byte Reload
	fmul.4s	v24, v24, v10
	str	q25, [sp, #1360]                ; 16-byte Spill
	bit.16b	v23, v25, v0
	str	q31, [sp, #1344]                ; 16-byte Spill
	bit.16b	v22, v31, v2
	stp	q22, q23, [x22]
	ldr	q22, [sp, #2288]                ; 16-byte Reload
	fmul.4s	v22, v22, v10
	ldr	q23, [sp, #2560]                ; 16-byte Reload
	fmul.4s	v23, v23, v10
	ldr	q25, [sp, #2304]                ; 16-byte Reload
	fmul.4s	v25, v25, v10
	str	q21, [sp, #2448]                ; 16-byte Spill
	str	q11, [sp, #2432]                ; 16-byte Spill
	str	q12, [sp, #2416]                ; 16-byte Spill
	ldp	q11, q12, [x10]
	ldr	q21, [sp, #2320]                ; 16-byte Reload
	fmul.4s	v26, v21, v10
	str	q27, [sp, #1264]                ; 16-byte Spill
	bit.16b	v12, v27, v0
	str	q29, [sp, #1248]                ; 16-byte Spill
	bit.16b	v11, v29, v2
	stp	q11, q12, [x10]
	ldr	q21, [sp, #2336]                ; 16-byte Reload
	fmul.4s	v12, v21, v10
	ldr	q21, [sp, #2352]                ; 16-byte Reload
	fmul.4s	v29, v21, v10
	ldr	q21, [sp, #2112]                ; 16-byte Reload
	fmul.4s	v31, v21, v10
	mov.16b	v27, v9
	ldp	q11, q9, [x11]
	ushll.4s	v3, v3, #0
	str	q7, [sp, #1168]                 ; 16-byte Spill
	bit.16b	v9, v7, v0
	str	q20, [sp, #1152]                ; 16-byte Spill
	bit.16b	v11, v20, v2
	stp	q11, q9, [x11]
	shl.4s	v3, v3, #31
	cmlt.4s	v11, v3, #0
	ldr	q21, [sp, #384]                 ; 16-byte Reload
	mov.16b	v7, v11
	bsl.16b	v7, v19, v21
	ldp	q3, q19, [x12]
	bif.16b	v18, v21, v11
	str	q18, [sp, #1056]                ; 16-byte Spill
	bif.16b	v18, v19, v0
	str	q7, [sp, #1072]                 ; 16-byte Spill
	bit.16b	v3, v7, v2
	stp	q3, q18, [x12]
	ldr	q3, [sp, #2384]                 ; 16-byte Reload
	fmul.4s	v3, v3, v10
	ldr	q18, [sp, #2368]                ; 16-byte Reload
	fmul.4s	v18, v18, v10
	mov.16b	v7, v11
	bsl.16b	v7, v22, v21
	ldr	x14, [sp, #376]                 ; 8-byte Reload
	ldp	q19, q22, [x14]
	mov.16b	v20, v11
	bsl.16b	v20, v24, v21
	stp	q20, q7, [sp, #960]             ; 32-byte Folded Spill
	bit.16b	v22, v20, v0
	bit.16b	v19, v7, v2
	stp	q19, q22, [x14]
	ldr	q19, [sp, #2400]                ; 16-byte Reload
	fmul.4s	v19, v19, v10
	ldr	q22, [sp, #2576]                ; 16-byte Reload
	fmul.4s	v22, v22, v10
	mov.16b	v7, v11
	bsl.16b	v7, v25, v21
	ldr	x14, [sp, #368]                 ; 8-byte Reload
	ldp	q24, q25, [x14]
	mov.16b	v20, v11
	bsl.16b	v20, v23, v21
	stp	q20, q7, [sp, #864]             ; 32-byte Folded Spill
	mov.16b	v23, v0
	bsl.16b	v23, v20, v25
	bit.16b	v24, v7, v2
	stp	q24, q23, [x14]
	str	q15, [sp, #1712]                ; 16-byte Spill
	fmul.4s	v23, v15, v10
	str	q27, [sp, #1696]                ; 16-byte Spill
	fmul.4s	v24, v27, v10
	mov.16b	v7, v11
	bsl.16b	v7, v12, v21
	ldr	x14, [sp, #360]                 ; 8-byte Reload
	ldp	q25, q9, [x14]
	mov.16b	v20, v11
	bsl.16b	v20, v26, v21
	stp	q20, q7, [sp, #768]             ; 32-byte Folded Spill
	bit.16b	v9, v20, v0
	bit.16b	v25, v7, v2
	stp	q25, q9, [x14]
	str	q14, [sp, #1728]                ; 16-byte Spill
	fmul.4s	v25, v14, v10
	str	q13, [sp, #1744]                ; 16-byte Spill
	fmul.4s	v9, v13, v10
	mov.16b	v7, v11
	bsl.16b	v7, v31, v21
	ldr	x14, [sp, #352]                 ; 8-byte Reload
	ldp	q13, q12, [x14]
	mov.16b	v20, v11
	bsl.16b	v20, v29, v21
	stp	q20, q7, [sp, #800]             ; 32-byte Folded Spill
	bit.16b	v13, v20, v2
	bit.16b	v12, v7, v0
	stp	q13, q12, [x14]
	mov.16b	v7, v11
	bsl.16b	v7, v18, v21
	mov.16b	v26, v11
	bsl.16b	v26, v3, v21
	mov.16b	v20, v11
	bsl.16b	v20, v22, v21
	ldr	x14, [sp, #344]                 ; 8-byte Reload
	ldp	q18, q3, [x14]
	mov.16b	v22, v11
	bsl.16b	v22, v19, v21
	stp	q26, q7, [sp, #896]             ; 32-byte Folded Spill
	bit.16b	v18, v26, v2
	bit.16b	v3, v7, v0
	stp	q18, q3, [x14]
	mov.16b	v7, v11
	bsl.16b	v7, v24, v21
	mov.16b	v19, v11
	bsl.16b	v19, v23, v21
	ldr	x14, [sp, #336]                 ; 8-byte Reload
	ldp	q18, q3, [x14]
	stp	q22, q20, [sp, #992]            ; 32-byte Folded Spill
	bit.16b	v18, v22, v2
	bit.16b	v3, v20, v0
	stp	q18, q3, [x14]
	ldr	x14, [sp, #328]                 ; 8-byte Reload
	ldp	q18, q3, [x14]
	str	q19, [sp, #1088]                ; 16-byte Spill
	bit.16b	v18, v19, v2
	str	q7, [sp, #1104]                 ; 16-byte Spill
	bit.16b	v3, v7, v0
	stp	q18, q3, [x14]
	ldr	q3, [sp, #2432]                 ; 16-byte Reload
	fmul.4s	v3, v3, v10
	ldr	q7, [sp, #2416]                 ; 16-byte Reload
	fmul.4s	v18, v7, v10
	ldr	q7, [sp, #2448]                 ; 16-byte Reload
	fmul.4s	v19, v7, v10
	str	q28, [sp, #1760]                ; 16-byte Spill
	fmul.4s	v22, v28, v10
	mov.16b	v24, v11
	bsl.16b	v24, v9, v21
	bif.16b	v25, v21, v11
	mov.16b	v20, v11
	bsl.16b	v20, v18, v21
	mov.16b	v23, v11
	bsl.16b	v23, v3, v21
	mov.16b	v7, v11
	bsl.16b	v7, v22, v21
	bif.16b	v19, v21, v11
	ldr	x14, [sp, #320]                 ; 8-byte Reload
	ldp	q18, q3, [x14]
	str	q25, [sp, #1184]                ; 16-byte Spill
	bit.16b	v3, v25, v0
	str	q24, [sp, #1200]                ; 16-byte Spill
	bit.16b	v18, v24, v2
	stp	q18, q3, [x14]
	ldr	x14, [sp, #312]                 ; 8-byte Reload
	ldp	q3, q18, [x14]
	str	q23, [sp, #1280]                ; 16-byte Spill
	bit.16b	v3, v23, v2
	str	q20, [sp, #1296]                ; 16-byte Spill
	bit.16b	v18, v20, v0
	stp	q3, q18, [x14]
	ldr	x14, [sp, #304]                 ; 8-byte Reload
	ldp	q3, q18, [x14]
	str	q19, [sp, #1376]                ; 16-byte Spill
	bit.16b	v3, v19, v2
	str	q7, [sp, #1392]                 ; 16-byte Spill
	bit.16b	v18, v7, v0
	stp	q3, q18, [x14]
	mvni.4s	v3, #127, msl #16
	ldr	q22, [sp, #1776]                ; 16-byte Reload
	bit.16b	v22, v3, v0
	ldr	q19, [sp, #1792]                ; 16-byte Reload
	bit.16b	v19, v3, v2
	dup.8b	v3, w13
	str	d3, [sp, #1536]                 ; 8-byte Spill
LBB1_140:                               ; %direct.true455.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x13, x6, x9
	ldp	q3, q18, [x13]
	and.16b	v18, v0, v18
	and.16b	v3, v2, v3
	fmaxnm.4s	v3, v19, v3
	fmaxnm.4s	v18, v22, v18
	bit.16b	v22, v18, v0
	bit.16b	v19, v3, v2
	add	x9, x9, #32
	cmp	x9, #512
	b.ne	LBB1_140
; %bb.141:                              ; %direct.false456.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x25, #0                         ; =0x0
	ldr	q3, [sp, #1872]                 ; 16-byte Reload
	ldr	q18, [sp, #1808]                ; 16-byte Reload
	ldr	q7, [sp, #2688]                 ; 16-byte Reload
	bit.16b	v18, v7, v3
	str	q18, [sp, #1808]                ; 16-byte Spill
	str	q19, [sp, #1792]                ; 16-byte Spill
	ldr	q3, [sp, #2512]                 ; 16-byte Reload
	fmaxnm.4s	v10, v3, v19
	ldr	q3, [sp, #2656]                 ; 16-byte Reload
	fsub.4s	v3, v3, v10
	ldp	q18, q19, [sp, #464]            ; 32-byte Folded Reload
	cmhi.4s	v31, v18, v19
	and.16b	v28, v31, v3
	mov	w9, #-1026555904                ; =0xc2d00000
	dup.4s	v25, w9
	fcmge.4s	v3, v28, v25
	mov	w9, #1120403456                 ; =0x42c80000
	dup.4s	v29, w9
	fcmge.4s	v18, v29, v28
	and.16b	v3, v3, v18
	str	q22, [sp, #1776]                ; 16-byte Spill
	ldr	q7, [sp, #2528]                 ; 16-byte Reload
	fmaxnm.4s	v7, v7, v22
	str	q7, [sp, #2624]                 ; 16-byte Spill
	ldr	q18, [sp, #2672]                ; 16-byte Reload
	fsub.4s	v18, v18, v7
	and.16b	v14, v0, v18
	fcmge.4s	v18, v14, v25
	fcmge.4s	v19, v29, v14
	and.16b	v18, v18, v19
	and.16b	v19, v18, v14
	mov	w9, #43579                      ; =0xaa3b
	movk	w9, #16312, lsl #16
	dup.4s	v12, w9
	fmul.4s	v18, v19, v12
	movi.4s	v7, #75, lsl #24
	mvni.4s	v20, #128, lsl #24
	mov.16b	v22, v20
	bsl.16b	v22, v7, v18
	fadd.4s	v18, v18, v22
	fsub.4s	v18, v18, v22
	and.16b	v3, v3, v28
	fmul.4s	v22, v3, v12
	mov.16b	v23, v20
	bsl.16b	v23, v7, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	fcvtzs.4s	v18, v18
	scvtf.4s	v23, v18
	mov	w9, #29184                      ; =0x7200
	movk	w9, #16177, lsl #16
	dup.4s	v11, w9
	fmul.4s	v24, v23, v11
	fsub.4s	v19, v19, v24
	fcvtzs.4s	v9, v22
	scvtf.4s	v22, v9
	fmul.4s	v24, v22, v11
	mov	w9, #48782                      ; =0xbe8e
	movk	w9, #13759, lsl #16
	dup.4s	v20, w9
	fsub.4s	v3, v3, v24
	fmul.4s	v22, v22, v20
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v23, v20
	mov	w9, #11226                      ; =0x2bda
	movk	w9, #14672, lsl #16
	dup.4s	v27, w9
	fsub.4s	v19, v19, v22
	fmul.4s	v22, v19, v27
	mov	w9, #38601                      ; =0x96c9
	movk	w9, #15030, lsl #16
	dup.4s	v26, w9
	fadd.4s	v22, v22, v26
	fmul.4s	v22, v19, v22
	mov	w9, #34982                      ; =0x88a6
	movk	w9, #15368, lsl #16
	dup.4s	v15, w9
	fadd.4s	v22, v22, v15
	fmul.4s	v22, v19, v22
	mov	w9, #43642                      ; =0xaa7a
	movk	w9, #15658, lsl #16
	dup.4s	v24, w9
	fadd.4s	v22, v22, v24
	str	q24, [sp, #2544]                ; 16-byte Spill
	fmul.4s	v22, v19, v22
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #15914, lsl #16
	dup.4s	v21, w9
	fadd.4s	v22, v22, v21
	fmul.4s	v22, v19, v22
	movi.4s	v23, #63, lsl #24
	fadd.4s	v22, v22, v23
	movi.4s	v7, #63, lsl #24
	fmul.4s	v23, v19, v19
	fmul.4s	v22, v23, v22
	fmul.4s	v23, v3, v27
	fadd.4s	v23, v23, v26
	fmul.4s	v23, v3, v23
	fadd.4s	v23, v23, v15
	fmul.4s	v23, v3, v23
	fadd.4s	v23, v23, v24
	fmul.4s	v23, v3, v23
	fadd.4s	v23, v23, v21
	fmul.4s	v23, v3, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v24, v3, v3
	fmul.4s	v23, v24, v23
	fadd.4s	v3, v3, v23
	fadd.4s	v19, v19, v22
	fmov.4s	v13, #1.00000000
	fadd.4s	v3, v3, v13
	sshr.4s	v22, v9, #1
	shl.4s	v23, v22, #23
	add.4s	v23, v23, v13
	fmul.4s	v3, v3, v23
	fadd.4s	v19, v19, v13
	sshr.4s	v23, v18, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v13
	fmul.4s	v19, v19, v24
	sub.4s	v22, v9, v22
	sub.4s	v18, v18, v23
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v13
	fmul.4s	v18, v19, v18
	shl.4s	v19, v22, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	mov.16b	v9, v25
	str	q28, [sp, #1472]                ; 16-byte Spill
	fcmgt.4s	v19, v25, v28
	bic.16b	v3, v3, v19
	str	q14, [sp, #1520]                ; 16-byte Spill
	fcmgt.4s	v19, v25, v14
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v14, v29
	mvni.4s	v22, #127, msl #16
	fneg.4s	v7, v22
	str	q7, [sp, #2672]                 ; 16-byte Spill
	bit.16b	v18, v7, v19
	str	q18, [sp, #1504]                ; 16-byte Spill
	fcmgt.4s	v18, v28, v29
	bit.16b	v3, v7, v18
	str	q3, [sp, #1488]                 ; 16-byte Spill
	ldr	q3, [sp, #1440]                 ; 16-byte Reload
	fsub.4s	v3, v3, v10
	and.16b	v7, v31, v3
	fcmge.4s	v3, v7, v25
	fcmge.4s	v18, v29, v7
	and.16b	v3, v3, v18
	ldr	q14, [sp, #2624]                ; 16-byte Reload
	ldr	q18, [sp, #1456]                ; 16-byte Reload
	fsub.4s	v18, v18, v14
	and.16b	v28, v0, v18
	fcmge.4s	v18, v28, v25
	fcmge.4s	v19, v29, v28
	and.16b	v18, v18, v19
	and.16b	v19, v18, v28
	fmul.4s	v18, v19, v12
	movi.4s	v23, #75, lsl #24
	mvni.4s	v24, #128, lsl #24
	mov.16b	v22, v24
	bsl.16b	v22, v23, v18
	fadd.4s	v18, v18, v22
	fsub.4s	v18, v18, v22
	and.16b	v3, v3, v7
	fmul.4s	v22, v3, v12
	bif.16b	v23, v22, v24
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	fcvtzs.4s	v18, v18
	scvtf.4s	v23, v18
	fmul.4s	v24, v23, v11
	fsub.4s	v19, v19, v24
	fcvtzs.4s	v22, v22
	scvtf.4s	v24, v22
	fmul.4s	v25, v24, v11
	fsub.4s	v3, v3, v25
	str	q20, [sp, #2656]                ; 16-byte Spill
	fmul.4s	v24, v24, v20
	fsub.4s	v3, v3, v24
	fmul.4s	v23, v23, v20
	fsub.4s	v19, v19, v23
	fmul.4s	v23, v19, v27
	str	q26, [sp, #2016]                ; 16-byte Spill
	fadd.4s	v23, v23, v26
	fmul.4s	v23, v19, v23
	fadd.4s	v23, v23, v15
	fmul.4s	v23, v19, v23
	ldr	q25, [sp, #2544]                ; 16-byte Reload
	fadd.4s	v23, v23, v25
	fmul.4s	v23, v19, v23
	str	q21, [sp, #2688]                ; 16-byte Spill
	fadd.4s	v23, v23, v21
	fmul.4s	v23, v19, v23
	movi.4s	v20, #63, lsl #24
	fadd.4s	v23, v23, v20
	fmul.4s	v24, v19, v19
	fmul.4s	v23, v24, v23
	fmul.4s	v24, v3, v27
	fadd.4s	v24, v24, v26
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v15
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v25
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v21
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v20
	fmul.4s	v25, v3, v3
	fmul.4s	v24, v25, v24
	fadd.4s	v3, v3, v24
	fadd.4s	v19, v19, v23
	fadd.4s	v3, v3, v13
	sshr.4s	v23, v22, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v13
	fmul.4s	v3, v3, v24
	fadd.4s	v19, v19, v13
	sshr.4s	v24, v18, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v13
	fmul.4s	v19, v19, v25
	sub.4s	v22, v22, v23
	sub.4s	v18, v18, v24
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v13
	fmul.4s	v18, v19, v18
	shl.4s	v19, v22, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	str	q7, [sp, #1424]                 ; 16-byte Spill
	fcmgt.4s	v19, v9, v7
	bic.16b	v3, v3, v19
	str	q28, [sp, #1408]                ; 16-byte Spill
	fcmgt.4s	v19, v9, v28
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v28, v29
	ldr	q20, [sp, #2672]                ; 16-byte Reload
	bit.16b	v18, v20, v19
	str	q18, [sp, #1456]                ; 16-byte Spill
	fcmgt.4s	v18, v7, v29
	bit.16b	v3, v20, v18
	str	q3, [sp, #1440]                 ; 16-byte Spill
	ldr	q3, [sp, #1344]                 ; 16-byte Reload
	fsub.4s	v3, v3, v10
	and.16b	v20, v31, v3
	fcmge.4s	v3, v20, v9
	fcmge.4s	v18, v29, v20
	and.16b	v3, v3, v18
	ldr	q7, [sp, #1360]                 ; 16-byte Reload
	fsub.4s	v18, v7, v14
	mov.16b	v26, v14
	and.16b	v14, v0, v18
	fcmge.4s	v18, v14, v9
	fcmge.4s	v19, v29, v14
	and.16b	v18, v18, v19
	and.16b	v19, v18, v14
	str	q12, [sp, #2640]                ; 16-byte Spill
	fmul.4s	v18, v19, v12
	mvni.4s	v7, #128, lsl #24
	movi.4s	v23, #75, lsl #24
	mov.16b	v22, v7
	bsl.16b	v22, v23, v18
	fadd.4s	v18, v18, v22
	fsub.4s	v18, v18, v22
	and.16b	v3, v3, v20
	fmul.4s	v22, v3, v12
	bif.16b	v23, v22, v7
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	fcvtzs.4s	v18, v18
	scvtf.4s	v23, v18
	str	q11, [sp, #2592]                ; 16-byte Spill
	fmul.4s	v24, v23, v11
	fsub.4s	v19, v19, v24
	fcvtzs.4s	v22, v22
	scvtf.4s	v24, v22
	fmul.4s	v25, v24, v11
	fsub.4s	v3, v3, v25
	ldr	q28, [sp, #2656]                ; 16-byte Reload
	fmul.4s	v24, v24, v28
	fsub.4s	v3, v3, v24
	fmul.4s	v23, v23, v28
	fsub.4s	v19, v19, v23
	mov.16b	v21, v27
	fmul.4s	v23, v19, v27
	ldr	q27, [sp, #2016]                ; 16-byte Reload
	fadd.4s	v23, v23, v27
	fmul.4s	v23, v19, v23
	mov.16b	v12, v15
	fadd.4s	v23, v23, v15
	fmul.4s	v23, v19, v23
	ldr	q15, [sp, #2544]                ; 16-byte Reload
	fadd.4s	v23, v23, v15
	fmul.4s	v23, v19, v23
	ldr	q7, [sp, #2688]                 ; 16-byte Reload
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v19, v23
	movi.4s	v25, #63, lsl #24
	fadd.4s	v23, v23, v25
	fmul.4s	v24, v19, v19
	fmul.4s	v23, v24, v23
	fmul.4s	v24, v3, v21
	fadd.4s	v24, v24, v27
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v12
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v15
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v7
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v25
	fmul.4s	v25, v3, v3
	fmul.4s	v24, v25, v24
	fadd.4s	v3, v3, v24
	fadd.4s	v19, v19, v23
	fadd.4s	v3, v3, v13
	sshr.4s	v23, v22, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v13
	fmul.4s	v3, v3, v24
	fadd.4s	v19, v19, v13
	sshr.4s	v24, v18, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v13
	fmul.4s	v19, v19, v25
	sub.4s	v22, v22, v23
	sub.4s	v18, v18, v24
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v13
	fmul.4s	v18, v19, v18
	shl.4s	v19, v22, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	str	q20, [sp, #1312]                ; 16-byte Spill
	fcmgt.4s	v19, v9, v20
	bic.16b	v3, v3, v19
	str	q14, [sp, #1344]                ; 16-byte Spill
	fcmgt.4s	v19, v9, v14
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v14, v29
	ldr	q7, [sp, #2672]                 ; 16-byte Reload
	bit.16b	v18, v7, v19
	str	q18, [sp, #1360]                ; 16-byte Spill
	fcmgt.4s	v18, v20, v29
	bit.16b	v3, v7, v18
	str	q3, [sp, #1328]                 ; 16-byte Spill
	mov.16b	v20, v7
	str	q10, [sp, #2608]                ; 16-byte Spill
	ldr	q3, [sp, #1248]                 ; 16-byte Reload
	fsub.4s	v3, v3, v10
	and.16b	v7, v31, v3
	fcmge.4s	v3, v7, v9
	fcmge.4s	v18, v29, v7
	and.16b	v3, v3, v18
	ldr	q18, [sp, #1264]                ; 16-byte Reload
	fsub.4s	v18, v18, v26
	and.16b	v14, v0, v18
	fcmge.4s	v18, v14, v9
	fcmge.4s	v19, v29, v14
	and.16b	v18, v18, v19
	and.16b	v19, v18, v14
	ldr	q25, [sp, #2640]                ; 16-byte Reload
	fmul.4s	v18, v19, v25
	movi.4s	v23, #75, lsl #24
	mvni.4s	v24, #128, lsl #24
	mov.16b	v22, v24
	bsl.16b	v22, v23, v18
	fadd.4s	v18, v18, v22
	fsub.4s	v18, v18, v22
	and.16b	v3, v3, v7
	fmul.4s	v22, v3, v25
	bif.16b	v23, v22, v24
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	fcvtzs.4s	v18, v18
	scvtf.4s	v23, v18
	ldr	q11, [sp, #2592]                ; 16-byte Reload
	fmul.4s	v24, v23, v11
	fsub.4s	v19, v19, v24
	fcvtzs.4s	v22, v22
	scvtf.4s	v24, v22
	fmul.4s	v25, v24, v11
	fsub.4s	v3, v3, v25
	fmul.4s	v24, v24, v28
	fsub.4s	v3, v3, v24
	fmul.4s	v23, v23, v28
	fsub.4s	v19, v19, v23
	mov.16b	v28, v21
	fmul.4s	v23, v19, v21
	mov.16b	v25, v27
	fadd.4s	v23, v23, v27
	fmul.4s	v23, v19, v23
	mov.16b	v26, v12
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v19, v23
	mov.16b	v12, v15
	fadd.4s	v23, v23, v15
	fmul.4s	v23, v19, v23
	ldr	q27, [sp, #2688]                ; 16-byte Reload
	fadd.4s	v23, v23, v27
	fmul.4s	v23, v19, v23
	movi.4s	v21, #63, lsl #24
	fadd.4s	v23, v23, v21
	fmul.4s	v24, v19, v19
	fmul.4s	v23, v24, v23
	fmul.4s	v24, v3, v28
	fadd.4s	v24, v24, v25
	mov.16b	v15, v25
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v26
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v12
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v27
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v21
	fmul.4s	v25, v3, v3
	fmul.4s	v24, v25, v24
	fadd.4s	v3, v3, v24
	fadd.4s	v19, v19, v23
	fadd.4s	v3, v3, v13
	sshr.4s	v23, v22, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v13
	fmul.4s	v3, v3, v24
	fadd.4s	v19, v19, v13
	sshr.4s	v24, v18, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v13
	fmul.4s	v19, v19, v25
	sub.4s	v22, v22, v23
	sub.4s	v18, v18, v24
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v13
	fmul.4s	v18, v19, v18
	shl.4s	v19, v22, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	str	q7, [sp, #1216]                 ; 16-byte Spill
	fcmgt.4s	v19, v9, v7
	bic.16b	v3, v3, v19
	str	q14, [sp, #1248]                ; 16-byte Spill
	fcmgt.4s	v19, v9, v14
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v14, v29
	bit.16b	v18, v20, v19
	str	q18, [sp, #1264]                ; 16-byte Spill
	fcmgt.4s	v18, v7, v29
	bit.16b	v3, v20, v18
	str	q3, [sp, #1232]                 ; 16-byte Spill
	ldr	q3, [sp, #1152]                 ; 16-byte Reload
	fsub.4s	v3, v3, v10
	and.16b	v7, v31, v3
	fcmge.4s	v3, v7, v9
	fcmge.4s	v18, v29, v7
	and.16b	v3, v3, v18
	ldr	q10, [sp, #2624]                ; 16-byte Reload
	ldr	q18, [sp, #1168]                ; 16-byte Reload
	fsub.4s	v18, v18, v10
	and.16b	v20, v0, v18
	fcmge.4s	v18, v20, v9
	fcmge.4s	v19, v29, v20
	and.16b	v18, v18, v19
	and.16b	v19, v18, v20
	ldr	q27, [sp, #2640]                ; 16-byte Reload
	fmul.4s	v18, v19, v27
	mvni.4s	v21, #128, lsl #24
	movi.4s	v23, #75, lsl #24
	mov.16b	v22, v21
	bsl.16b	v22, v23, v18
	fadd.4s	v18, v18, v22
	fsub.4s	v18, v18, v22
	and.16b	v3, v3, v7
	fmul.4s	v22, v3, v27
	bif.16b	v23, v22, v21
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	fcvtzs.4s	v18, v18
	scvtf.4s	v23, v18
	fmul.4s	v24, v23, v11
	fsub.4s	v19, v19, v24
	fcvtzs.4s	v22, v22
	scvtf.4s	v24, v22
	fmul.4s	v25, v24, v11
	fsub.4s	v3, v3, v25
	ldr	q21, [sp, #2656]                ; 16-byte Reload
	fmul.4s	v24, v24, v21
	fsub.4s	v3, v3, v24
	fmul.4s	v23, v23, v21
	fsub.4s	v19, v19, v23
	fmul.4s	v23, v19, v28
	fadd.4s	v23, v23, v15
	fmul.4s	v23, v19, v23
	mov.16b	v14, v26
	fadd.4s	v23, v23, v26
	fmul.4s	v23, v19, v23
	mov.16b	v21, v12
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v19, v23
	ldr	q25, [sp, #2688]                ; 16-byte Reload
	fadd.4s	v23, v23, v25
	fmul.4s	v23, v19, v23
	movi.4s	v26, #63, lsl #24
	fadd.4s	v23, v23, v26
	fmul.4s	v24, v19, v19
	fmul.4s	v23, v24, v23
	fmul.4s	v24, v3, v28
	fadd.4s	v24, v24, v15
	mov.16b	v12, v15
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v14
	mov.16b	v15, v14
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v21
	mov.16b	v14, v21
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v25
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v26
	fmul.4s	v25, v3, v3
	fmul.4s	v24, v25, v24
	fadd.4s	v3, v3, v24
	fadd.4s	v19, v19, v23
	fadd.4s	v3, v3, v13
	sshr.4s	v23, v22, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v13
	fmul.4s	v3, v3, v24
	fadd.4s	v19, v19, v13
	sshr.4s	v24, v18, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v13
	fmul.4s	v19, v19, v25
	sub.4s	v22, v22, v23
	sub.4s	v18, v18, v24
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v13
	fmul.4s	v18, v19, v18
	shl.4s	v19, v22, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	str	q7, [sp, #1120]                 ; 16-byte Spill
	fcmgt.4s	v19, v9, v7
	bic.16b	v3, v3, v19
	str	q20, [sp, #1152]                ; 16-byte Spill
	fcmgt.4s	v19, v9, v20
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v20, v29
	ldr	q26, [sp, #2672]                ; 16-byte Reload
	bit.16b	v18, v26, v19
	str	q18, [sp, #1168]                ; 16-byte Spill
	fcmgt.4s	v18, v7, v29
	bit.16b	v3, v26, v18
	str	q3, [sp, #1136]                 ; 16-byte Spill
	ldr	q3, [sp, #1056]                 ; 16-byte Reload
	fsub.4s	v3, v3, v10
	and.16b	v7, v0, v3
	fcmge.4s	v3, v7, v9
	fcmge.4s	v18, v29, v7
	and.16b	v3, v3, v18
	ldr	q21, [sp, #2608]                ; 16-byte Reload
	ldr	q18, [sp, #1072]                ; 16-byte Reload
	fsub.4s	v18, v18, v21
	and.16b	v20, v31, v18
	fcmge.4s	v18, v20, v9
	fcmge.4s	v19, v29, v20
	and.16b	v18, v18, v19
	and.16b	v19, v18, v20
	fmul.4s	v18, v19, v27
	movi.4s	v23, #75, lsl #24
	mvni.4s	v24, #128, lsl #24
	mov.16b	v22, v24
	bsl.16b	v22, v23, v18
	fadd.4s	v18, v18, v22
	fsub.4s	v18, v18, v22
	and.16b	v3, v3, v7
	fmul.4s	v22, v3, v27
	bif.16b	v23, v22, v24
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	fcvtzs.4s	v18, v18
	scvtf.4s	v23, v18
	fmul.4s	v24, v23, v11
	fsub.4s	v19, v19, v24
	fcvtzs.4s	v22, v22
	scvtf.4s	v24, v22
	fmul.4s	v25, v24, v11
	fsub.4s	v3, v3, v25
	ldr	q25, [sp, #2656]                ; 16-byte Reload
	fmul.4s	v24, v24, v25
	fsub.4s	v3, v3, v24
	fmul.4s	v23, v23, v25
	fsub.4s	v19, v19, v23
	fmul.4s	v23, v19, v28
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v19, v23
	fadd.4s	v23, v23, v15
	fmul.4s	v23, v19, v23
	fadd.4s	v23, v23, v14
	fmul.4s	v23, v19, v23
	ldr	q10, [sp, #2688]                ; 16-byte Reload
	fadd.4s	v23, v23, v10
	fmul.4s	v23, v19, v23
	movi.4s	v25, #63, lsl #24
	fadd.4s	v23, v23, v25
	fmul.4s	v24, v19, v19
	fmul.4s	v23, v24, v23
	fmul.4s	v24, v3, v28
	fadd.4s	v24, v24, v12
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v15
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v14
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v10
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v25
	fmul.4s	v25, v3, v3
	fmul.4s	v24, v25, v24
	fadd.4s	v3, v3, v24
	fadd.4s	v19, v19, v23
	fadd.4s	v3, v3, v13
	sshr.4s	v23, v22, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v13
	fmul.4s	v3, v3, v24
	fadd.4s	v19, v19, v13
	sshr.4s	v24, v18, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v13
	fmul.4s	v19, v19, v25
	sub.4s	v22, v22, v23
	sub.4s	v18, v18, v24
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v13
	fmul.4s	v18, v19, v18
	shl.4s	v19, v22, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	str	q7, [sp, #1024]                 ; 16-byte Spill
	fcmgt.4s	v19, v9, v7
	bic.16b	v3, v3, v19
	str	q20, [sp, #1056]                ; 16-byte Spill
	fcmgt.4s	v19, v9, v20
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v20, v29
	bit.16b	v18, v26, v19
	str	q18, [sp, #1072]                ; 16-byte Spill
	fcmgt.4s	v18, v7, v29
	bit.16b	v3, v26, v18
	str	q3, [sp, #1040]                 ; 16-byte Spill
	ldr	q3, [sp, #960]                  ; 16-byte Reload
	ldr	q10, [sp, #2624]                ; 16-byte Reload
	fsub.4s	v3, v3, v10
	and.16b	v7, v0, v3
	fcmge.4s	v3, v7, v9
	fcmge.4s	v18, v29, v7
	and.16b	v3, v3, v18
	ldr	q18, [sp, #976]                 ; 16-byte Reload
	fsub.4s	v18, v18, v21
	and.16b	v20, v31, v18
	fcmge.4s	v18, v20, v9
	fcmge.4s	v19, v29, v20
	and.16b	v18, v18, v19
	and.16b	v19, v18, v20
	fmul.4s	v18, v19, v27
	mvni.4s	v21, #128, lsl #24
	movi.4s	v23, #75, lsl #24
	mov.16b	v22, v21
	bsl.16b	v22, v23, v18
	fadd.4s	v18, v18, v22
	fsub.4s	v18, v18, v22
	and.16b	v3, v3, v7
	fmul.4s	v22, v3, v27
	bif.16b	v23, v22, v21
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	fcvtzs.4s	v18, v18
	scvtf.4s	v23, v18
	fmul.4s	v24, v23, v11
	fsub.4s	v19, v19, v24
	fcvtzs.4s	v22, v22
	scvtf.4s	v24, v22
	fmul.4s	v25, v24, v11
	fsub.4s	v3, v3, v25
	ldr	q21, [sp, #2656]                ; 16-byte Reload
	fmul.4s	v24, v24, v21
	fsub.4s	v3, v3, v24
	fmul.4s	v23, v23, v21
	fsub.4s	v19, v19, v23
	fmul.4s	v23, v19, v28
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v19, v23
	fadd.4s	v23, v23, v15
	fmul.4s	v23, v19, v23
	fadd.4s	v23, v23, v14
	fmul.4s	v23, v19, v23
	ldr	q25, [sp, #2688]                ; 16-byte Reload
	fadd.4s	v23, v23, v25
	fmul.4s	v23, v19, v23
	movi.4s	v21, #63, lsl #24
	fadd.4s	v23, v23, v21
	fmul.4s	v24, v19, v19
	fmul.4s	v23, v24, v23
	fmul.4s	v24, v3, v28
	fadd.4s	v24, v24, v12
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v15
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v14
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v25
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v21
	fmul.4s	v25, v3, v3
	fmul.4s	v24, v25, v24
	fadd.4s	v3, v3, v24
	fadd.4s	v19, v19, v23
	fadd.4s	v3, v3, v13
	sshr.4s	v23, v22, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v13
	fmul.4s	v3, v3, v24
	fadd.4s	v19, v19, v13
	sshr.4s	v24, v18, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v13
	fmul.4s	v19, v19, v25
	sub.4s	v22, v22, v23
	sub.4s	v18, v18, v24
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v13
	fmul.4s	v18, v19, v18
	shl.4s	v19, v22, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fcmgt.4s	v19, v9, v7
	bic.16b	v3, v3, v19
	fcmgt.4s	v19, v9, v20
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v20, v29
	bit.16b	v18, v26, v19
	stp	q20, q18, [sp, #960]            ; 32-byte Folded Spill
	fcmgt.4s	v18, v7, v29
	bit.16b	v3, v26, v18
	stp	q7, q3, [sp, #928]              ; 32-byte Folded Spill
	ldr	q3, [sp, #864]                  ; 16-byte Reload
	fsub.4s	v3, v3, v10
	and.16b	v21, v0, v3
	fcmge.4s	v3, v21, v9
	fcmge.4s	v18, v29, v21
	and.16b	v3, v3, v18
	ldr	q18, [sp, #880]                 ; 16-byte Reload
	ldr	q27, [sp, #2608]                ; 16-byte Reload
	fsub.4s	v18, v18, v27
	and.16b	v20, v31, v18
	fcmge.4s	v18, v20, v9
	fcmge.4s	v19, v29, v20
	and.16b	v18, v18, v19
	and.16b	v19, v18, v20
	ldr	q7, [sp, #2640]                 ; 16-byte Reload
	fmul.4s	v18, v19, v7
	mvni.4s	v23, #128, lsl #24
	movi.4s	v24, #75, lsl #24
	mov.16b	v22, v23
	bsl.16b	v22, v24, v18
	fadd.4s	v18, v18, v22
	fsub.4s	v18, v18, v22
	and.16b	v3, v3, v21
	fmul.4s	v22, v3, v7
	bsl.16b	v23, v24, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	fcvtzs.4s	v18, v18
	scvtf.4s	v23, v18
	fmul.4s	v24, v23, v11
	fsub.4s	v19, v19, v24
	fcvtzs.4s	v22, v22
	scvtf.4s	v24, v22
	fmul.4s	v25, v24, v11
	fsub.4s	v3, v3, v25
	ldr	q7, [sp, #2656]                 ; 16-byte Reload
	fmul.4s	v24, v24, v7
	fsub.4s	v3, v3, v24
	fmul.4s	v23, v23, v7
	fsub.4s	v19, v19, v23
	fmul.4s	v23, v19, v28
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v19, v23
	fadd.4s	v23, v23, v15
	fmul.4s	v23, v19, v23
	fadd.4s	v23, v23, v14
	fmul.4s	v23, v19, v23
	ldr	q7, [sp, #2688]                 ; 16-byte Reload
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v19, v23
	movi.4s	v25, #63, lsl #24
	fadd.4s	v23, v23, v25
	fmul.4s	v24, v19, v19
	fmul.4s	v23, v24, v23
	fmul.4s	v24, v3, v28
	fadd.4s	v24, v24, v12
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v15
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v14
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v7
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v25
	fmul.4s	v25, v3, v3
	fmul.4s	v24, v25, v24
	fadd.4s	v3, v3, v24
	fadd.4s	v19, v19, v23
	fadd.4s	v3, v3, v13
	sshr.4s	v23, v22, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v13
	fmul.4s	v3, v3, v24
	fadd.4s	v19, v19, v13
	sshr.4s	v24, v18, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v13
	fmul.4s	v19, v19, v25
	sub.4s	v22, v22, v23
	sub.4s	v18, v18, v24
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v13
	fmul.4s	v18, v19, v18
	shl.4s	v19, v22, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fcmgt.4s	v19, v9, v21
	bic.16b	v3, v3, v19
	fcmgt.4s	v19, v9, v20
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v20, v29
	bit.16b	v18, v26, v19
	stp	q20, q18, [sp, #864]            ; 32-byte Folded Spill
	fcmgt.4s	v18, v21, v29
	bit.16b	v3, v26, v18
	stp	q21, q3, [sp, #832]             ; 32-byte Folded Spill
	ldr	q3, [sp, #768]                  ; 16-byte Reload
	fsub.4s	v3, v3, v10
	mov.16b	v26, v10
	and.16b	v7, v0, v3
	fcmge.4s	v3, v7, v9
	fcmge.4s	v18, v29, v7
	and.16b	v3, v3, v18
	mov.16b	v21, v27
	ldr	q18, [sp, #784]                 ; 16-byte Reload
	fsub.4s	v18, v18, v27
	and.16b	v20, v31, v18
	fcmge.4s	v18, v20, v9
	fcmge.4s	v19, v29, v20
	and.16b	v18, v18, v19
	and.16b	v19, v18, v20
	ldr	q27, [sp, #2640]                ; 16-byte Reload
	fmul.4s	v18, v19, v27
	movi.4s	v23, #75, lsl #24
	mvni.4s	v24, #128, lsl #24
	mov.16b	v22, v24
	bsl.16b	v22, v23, v18
	fadd.4s	v18, v18, v22
	fsub.4s	v18, v18, v22
	and.16b	v3, v3, v7
	fmul.4s	v22, v3, v27
	bif.16b	v23, v22, v24
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	fcvtzs.4s	v18, v18
	scvtf.4s	v23, v18
	fmul.4s	v24, v23, v11
	fsub.4s	v19, v19, v24
	fcvtzs.4s	v22, v22
	scvtf.4s	v24, v22
	fmul.4s	v25, v24, v11
	fsub.4s	v3, v3, v25
	ldr	q25, [sp, #2656]                ; 16-byte Reload
	fmul.4s	v24, v24, v25
	fsub.4s	v3, v3, v24
	fmul.4s	v23, v23, v25
	fsub.4s	v19, v19, v23
	fmul.4s	v23, v19, v28
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v19, v23
	fadd.4s	v23, v23, v15
	fmul.4s	v23, v19, v23
	mov.16b	v10, v14
	fadd.4s	v23, v23, v14
	fmul.4s	v23, v19, v23
	ldr	q14, [sp, #2688]                ; 16-byte Reload
	fadd.4s	v23, v23, v14
	fmul.4s	v23, v19, v23
	movi.4s	v25, #63, lsl #24
	fadd.4s	v23, v23, v25
	fmul.4s	v24, v19, v19
	fmul.4s	v23, v24, v23
	fmul.4s	v24, v3, v28
	fadd.4s	v24, v24, v12
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v15
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v10
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v14
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v25
	fmul.4s	v25, v3, v3
	fmul.4s	v24, v25, v24
	fadd.4s	v3, v3, v24
	fadd.4s	v19, v19, v23
	fadd.4s	v3, v3, v13
	sshr.4s	v23, v22, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v13
	fmul.4s	v3, v3, v24
	fadd.4s	v19, v19, v13
	sshr.4s	v24, v18, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v13
	fmul.4s	v19, v19, v25
	sub.4s	v22, v22, v23
	sub.4s	v18, v18, v24
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v13
	fmul.4s	v18, v19, v18
	shl.4s	v19, v22, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fcmgt.4s	v19, v9, v7
	bic.16b	v3, v3, v19
	str	q20, [sp, #768]                 ; 16-byte Spill
	fcmgt.4s	v19, v9, v20
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v20, v29
	ldr	q20, [sp, #2672]                ; 16-byte Reload
	bit.16b	v18, v20, v19
	str	q18, [sp, #784]                 ; 16-byte Spill
	fcmgt.4s	v18, v7, v29
	bit.16b	v3, v20, v18
	stp	q7, q3, [sp, #736]              ; 32-byte Folded Spill
	ldp	q3, q7, [sp, #800]              ; 32-byte Folded Reload
	fsub.4s	v3, v3, v21
	and.16b	v14, v31, v3
	fcmge.4s	v3, v14, v9
	fcmge.4s	v18, v29, v14
	and.16b	v3, v3, v18
	fsub.4s	v18, v7, v26
	and.16b	v21, v0, v18
	fcmge.4s	v18, v21, v9
	fcmge.4s	v19, v29, v21
	and.16b	v18, v18, v19
	and.16b	v19, v18, v21
	fmul.4s	v18, v19, v27
	mvni.4s	v7, #128, lsl #24
	movi.4s	v20, #75, lsl #24
	mov.16b	v22, v7
	bsl.16b	v22, v20, v18
	fadd.4s	v18, v18, v22
	fsub.4s	v18, v18, v22
	and.16b	v3, v3, v14
	fmul.4s	v22, v3, v27
	mov.16b	v23, v7
	bsl.16b	v23, v20, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	fcvtzs.4s	v18, v18
	scvtf.4s	v23, v18
	fmul.4s	v24, v23, v11
	fsub.4s	v19, v19, v24
	fcvtzs.4s	v22, v22
	scvtf.4s	v24, v22
	fmul.4s	v25, v24, v11
	fsub.4s	v3, v3, v25
	ldr	q7, [sp, #2656]                 ; 16-byte Reload
	fmul.4s	v24, v24, v7
	fsub.4s	v3, v3, v24
	fmul.4s	v23, v23, v7
	fsub.4s	v19, v19, v23
	str	q28, [sp, #2496]                ; 16-byte Spill
	fmul.4s	v23, v19, v28
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v19, v23
	fadd.4s	v23, v23, v15
	fmul.4s	v23, v19, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v23, v19, v23
	ldr	q20, [sp, #2688]                ; 16-byte Reload
	fadd.4s	v23, v23, v20
	fmul.4s	v23, v19, v23
	movi.4s	v7, #63, lsl #24
	fadd.4s	v23, v23, v7
	fmul.4s	v24, v19, v19
	fmul.4s	v23, v24, v23
	fmul.4s	v24, v3, v28
	fadd.4s	v24, v24, v12
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v15
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v10
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v20
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v7
	fmul.4s	v25, v3, v3
	fmul.4s	v24, v25, v24
	fadd.4s	v3, v3, v24
	fadd.4s	v19, v19, v23
	fadd.4s	v3, v3, v13
	sshr.4s	v23, v22, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v13
	fmul.4s	v3, v3, v24
	fadd.4s	v19, v19, v13
	sshr.4s	v24, v18, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v13
	fmul.4s	v19, v19, v25
	sub.4s	v22, v22, v23
	sub.4s	v18, v18, v24
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v13
	fmul.4s	v18, v19, v18
	shl.4s	v19, v22, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fcmgt.4s	v19, v9, v14
	bic.16b	v3, v3, v19
	fcmgt.4s	v19, v9, v21
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v21, v29
	ldr	q20, [sp, #2672]                ; 16-byte Reload
	mov.16b	v7, v19
	bsl.16b	v7, v20, v18
	stp	q21, q7, [sp, #800]             ; 32-byte Folded Spill
	fcmgt.4s	v18, v14, v29
	bit.16b	v3, v20, v18
	stp	q14, q3, [sp, #704]             ; 32-byte Folded Spill
	ldp	q3, q7, [sp, #896]              ; 32-byte Folded Reload
	ldr	q26, [sp, #2608]                ; 16-byte Reload
	fsub.4s	v3, v3, v26
	and.16b	v14, v31, v3
	fcmge.4s	v3, v14, v9
	fcmge.4s	v18, v29, v14
	and.16b	v3, v3, v18
	ldr	q28, [sp, #2624]                ; 16-byte Reload
	fsub.4s	v18, v7, v28
	and.16b	v10, v0, v18
	fcmge.4s	v18, v10, v9
	fcmge.4s	v19, v29, v10
	and.16b	v18, v18, v19
	and.16b	v19, v18, v10
	fmul.4s	v18, v19, v27
	movi.4s	v7, #75, lsl #24
	mvni.4s	v20, #128, lsl #24
	mov.16b	v22, v20
	bsl.16b	v22, v7, v18
	fadd.4s	v18, v18, v22
	fsub.4s	v18, v18, v22
	and.16b	v3, v3, v14
	fmul.4s	v22, v3, v27
	mov.16b	v23, v20
	bsl.16b	v23, v7, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	fcvtzs.4s	v18, v18
	scvtf.4s	v23, v18
	fmul.4s	v24, v23, v11
	fsub.4s	v19, v19, v24
	fcvtzs.4s	v22, v22
	scvtf.4s	v24, v22
	fmul.4s	v25, v24, v11
	fsub.4s	v3, v3, v25
	ldr	q7, [sp, #2656]                 ; 16-byte Reload
	fmul.4s	v24, v24, v7
	fsub.4s	v3, v3, v24
	fmul.4s	v23, v23, v7
	fsub.4s	v19, v19, v23
	ldr	q25, [sp, #2496]                ; 16-byte Reload
	fmul.4s	v23, v19, v25
	mov.16b	v21, v12
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v19, v23
	mov.16b	v12, v15
	fadd.4s	v23, v23, v15
	fmul.4s	v23, v19, v23
	ldr	q7, [sp, #2544]                 ; 16-byte Reload
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v19, v23
	ldr	q15, [sp, #2688]                ; 16-byte Reload
	fadd.4s	v23, v23, v15
	fmul.4s	v23, v19, v23
	movi.4s	v20, #63, lsl #24
	fadd.4s	v23, v23, v20
	fmul.4s	v24, v19, v19
	fmul.4s	v23, v24, v23
	fmul.4s	v24, v3, v25
	fadd.4s	v24, v24, v21
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v12
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v7
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v15
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v20
	fmul.4s	v25, v3, v3
	fmul.4s	v24, v25, v24
	fadd.4s	v3, v3, v24
	fadd.4s	v19, v19, v23
	fadd.4s	v3, v3, v13
	sshr.4s	v23, v22, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v13
	fmul.4s	v3, v3, v24
	fadd.4s	v19, v19, v13
	sshr.4s	v24, v18, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v13
	fmul.4s	v19, v19, v25
	sub.4s	v22, v22, v23
	sub.4s	v18, v18, v24
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v13
	fmul.4s	v18, v19, v18
	shl.4s	v19, v22, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fcmgt.4s	v19, v9, v14
	bic.16b	v3, v3, v19
	fcmgt.4s	v19, v9, v10
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v10, v29
	ldr	q20, [sp, #2672]                ; 16-byte Reload
	bit.16b	v18, v20, v19
	stp	q10, q18, [sp, #896]            ; 32-byte Folded Spill
	fcmgt.4s	v18, v14, v29
	bit.16b	v3, v20, v18
	stp	q14, q3, [sp, #672]             ; 32-byte Folded Spill
	ldp	q3, q7, [sp, #992]              ; 32-byte Folded Reload
	fsub.4s	v3, v3, v26
	and.16b	v21, v31, v3
	fcmge.4s	v3, v21, v9
	fcmge.4s	v18, v29, v21
	and.16b	v3, v3, v18
	fsub.4s	v18, v7, v28
	and.16b	v26, v0, v18
	fcmge.4s	v18, v26, v9
	fcmge.4s	v19, v29, v26
	and.16b	v18, v18, v19
	and.16b	v19, v18, v26
	fmul.4s	v18, v19, v27
	movi.4s	v7, #75, lsl #24
	mvni.4s	v23, #128, lsl #24
	mov.16b	v22, v23
	bsl.16b	v22, v7, v18
	fadd.4s	v18, v18, v22
	fsub.4s	v18, v18, v22
	and.16b	v3, v3, v21
	fmul.4s	v22, v3, v27
	bsl.16b	v23, v7, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	fcvtzs.4s	v18, v18
	scvtf.4s	v23, v18
	fmul.4s	v24, v23, v11
	fsub.4s	v19, v19, v24
	fcvtzs.4s	v22, v22
	scvtf.4s	v24, v22
	fmul.4s	v25, v24, v11
	fsub.4s	v3, v3, v25
	ldr	q14, [sp, #2656]                ; 16-byte Reload
	fmul.4s	v24, v24, v14
	fsub.4s	v3, v3, v24
	fmul.4s	v23, v23, v14
	fsub.4s	v19, v19, v23
	ldr	q28, [sp, #2496]                ; 16-byte Reload
	fmul.4s	v23, v19, v28
	ldr	q10, [sp, #2016]                ; 16-byte Reload
	fadd.4s	v23, v23, v10
	fmul.4s	v23, v19, v23
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v19, v23
	ldr	q27, [sp, #2544]                ; 16-byte Reload
	fadd.4s	v23, v23, v27
	fmul.4s	v23, v19, v23
	ldr	q11, [sp, #2688]                ; 16-byte Reload
	fadd.4s	v23, v23, v11
	fmul.4s	v23, v19, v23
	movi.4s	v7, #63, lsl #24
	fadd.4s	v23, v23, v7
	fmul.4s	v24, v19, v19
	fmul.4s	v23, v24, v23
	fmul.4s	v24, v3, v28
	fadd.4s	v24, v24, v10
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v12
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v27
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v11
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v7
	fmul.4s	v25, v3, v3
	fmul.4s	v24, v25, v24
	fadd.4s	v3, v3, v24
	fadd.4s	v19, v19, v23
	fadd.4s	v3, v3, v13
	sshr.4s	v23, v22, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v13
	fmul.4s	v3, v3, v24
	fadd.4s	v19, v19, v13
	sshr.4s	v24, v18, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v13
	fmul.4s	v19, v19, v25
	sub.4s	v22, v22, v23
	sub.4s	v18, v18, v24
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v13
	fmul.4s	v18, v19, v18
	shl.4s	v19, v22, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fcmgt.4s	v19, v9, v21
	bic.16b	v3, v3, v19
	fcmgt.4s	v19, v9, v26
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v26, v29
	ldr	q20, [sp, #2672]                ; 16-byte Reload
	mov.16b	v7, v19
	bsl.16b	v7, v20, v18
	stp	q26, q7, [sp, #992]             ; 32-byte Folded Spill
	fcmgt.4s	v18, v21, v29
	bit.16b	v3, v20, v18
	stp	q21, q3, [sp, #640]             ; 32-byte Folded Spill
	ldr	q3, [sp, #1088]                 ; 16-byte Reload
	ldr	q11, [sp, #2608]                ; 16-byte Reload
	fsub.4s	v3, v3, v11
	and.16b	v26, v31, v3
	fcmge.4s	v3, v26, v9
	fcmge.4s	v18, v29, v26
	and.16b	v3, v3, v18
	ldr	q7, [sp, #1104]                 ; 16-byte Reload
	ldr	q20, [sp, #2624]                ; 16-byte Reload
	fsub.4s	v18, v7, v20
	and.16b	v21, v0, v18
	fcmge.4s	v18, v21, v9
	fcmge.4s	v19, v29, v21
	and.16b	v18, v18, v19
	and.16b	v19, v18, v21
	ldr	q7, [sp, #2640]                 ; 16-byte Reload
	fmul.4s	v18, v19, v7
	mvni.4s	v23, #128, lsl #24
	movi.4s	v24, #75, lsl #24
	mov.16b	v22, v23
	bsl.16b	v22, v24, v18
	fadd.4s	v18, v18, v22
	fsub.4s	v18, v18, v22
	and.16b	v3, v3, v26
	fmul.4s	v22, v3, v7
	bsl.16b	v23, v24, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	fcvtzs.4s	v18, v18
	scvtf.4s	v23, v18
	ldr	q7, [sp, #2592]                 ; 16-byte Reload
	fmul.4s	v24, v23, v7
	fsub.4s	v19, v19, v24
	fcvtzs.4s	v22, v22
	scvtf.4s	v24, v22
	fmul.4s	v25, v24, v7
	fsub.4s	v3, v3, v25
	fmul.4s	v24, v24, v14
	fsub.4s	v3, v3, v24
	fmul.4s	v23, v23, v14
	fsub.4s	v19, v19, v23
	fmul.4s	v23, v19, v28
	fadd.4s	v23, v23, v10
	fmul.4s	v23, v19, v23
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v19, v23
	fadd.4s	v23, v23, v27
	fmul.4s	v23, v19, v23
	ldr	q7, [sp, #2688]                 ; 16-byte Reload
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v19, v23
	movi.4s	v25, #63, lsl #24
	fadd.4s	v23, v23, v25
	fmul.4s	v24, v19, v19
	fmul.4s	v23, v24, v23
	fmul.4s	v24, v3, v28
	fadd.4s	v24, v24, v10
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v12
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v27
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v7
	mov.16b	v15, v7
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v25
	fmul.4s	v25, v3, v3
	fmul.4s	v24, v25, v24
	fadd.4s	v3, v3, v24
	fadd.4s	v19, v19, v23
	fadd.4s	v3, v3, v13
	sshr.4s	v23, v22, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v13
	fmul.4s	v3, v3, v24
	fadd.4s	v19, v19, v13
	sshr.4s	v24, v18, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v13
	fmul.4s	v19, v19, v25
	sub.4s	v22, v22, v23
	sub.4s	v18, v18, v24
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v13
	fmul.4s	v18, v19, v18
	shl.4s	v19, v22, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fcmgt.4s	v19, v9, v26
	bic.16b	v3, v3, v19
	str	q21, [sp, #1088]                ; 16-byte Spill
	fcmgt.4s	v19, v9, v21
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v21, v29
	ldr	q21, [sp, #2672]                ; 16-byte Reload
	mov.16b	v7, v19
	bsl.16b	v7, v21, v18
	str	q7, [sp, #1104]                 ; 16-byte Spill
	fcmgt.4s	v18, v26, v29
	bit.16b	v3, v21, v18
	stp	q26, q3, [sp, #608]             ; 32-byte Folded Spill
	ldr	q3, [sp, #1184]                 ; 16-byte Reload
	fsub.4s	v3, v3, v20
	and.16b	v26, v0, v3
	fcmge.4s	v3, v26, v9
	fcmge.4s	v18, v29, v26
	and.16b	v3, v3, v18
	ldr	q7, [sp, #1200]                 ; 16-byte Reload
	fsub.4s	v18, v7, v11
	and.16b	v21, v31, v18
	fcmge.4s	v18, v21, v9
	fcmge.4s	v19, v29, v21
	and.16b	v18, v18, v19
	and.16b	v19, v18, v21
	ldr	q7, [sp, #2640]                 ; 16-byte Reload
	fmul.4s	v18, v19, v7
	movi.4s	v20, #75, lsl #24
	mvni.4s	v23, #128, lsl #24
	mov.16b	v22, v23
	bsl.16b	v22, v20, v18
	fadd.4s	v18, v18, v22
	fsub.4s	v18, v18, v22
	and.16b	v3, v3, v26
	fmul.4s	v22, v3, v7
	bsl.16b	v23, v20, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	fcvtzs.4s	v18, v18
	scvtf.4s	v23, v18
	ldr	q7, [sp, #2592]                 ; 16-byte Reload
	fmul.4s	v24, v23, v7
	fsub.4s	v19, v19, v24
	fcvtzs.4s	v22, v22
	scvtf.4s	v24, v22
	fmul.4s	v25, v24, v7
	fsub.4s	v3, v3, v25
	fmul.4s	v24, v24, v14
	fsub.4s	v3, v3, v24
	fmul.4s	v23, v23, v14
	fsub.4s	v19, v19, v23
	fmul.4s	v23, v19, v28
	fadd.4s	v23, v23, v10
	fmul.4s	v23, v19, v23
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v19, v23
	fadd.4s	v23, v23, v27
	fmul.4s	v23, v19, v23
	mov.16b	v20, v15
	fadd.4s	v23, v23, v15
	fmul.4s	v23, v19, v23
	movi.4s	v7, #63, lsl #24
	fadd.4s	v23, v23, v7
	fmul.4s	v24, v19, v19
	fmul.4s	v23, v24, v23
	fmul.4s	v24, v3, v28
	fadd.4s	v24, v24, v10
	mov.16b	v15, v10
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v12
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v27
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v20
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v7
	fmul.4s	v25, v3, v3
	fmul.4s	v24, v25, v24
	fadd.4s	v3, v3, v24
	fadd.4s	v19, v19, v23
	fadd.4s	v3, v3, v13
	sshr.4s	v23, v22, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v13
	fmul.4s	v3, v3, v24
	fadd.4s	v19, v19, v13
	sshr.4s	v24, v18, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v13
	fmul.4s	v19, v19, v25
	sub.4s	v22, v22, v23
	sub.4s	v18, v18, v24
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v13
	fmul.4s	v18, v19, v18
	shl.4s	v19, v22, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fcmgt.4s	v19, v9, v26
	bic.16b	v3, v3, v19
	str	q21, [sp, #1184]                ; 16-byte Spill
	fcmgt.4s	v19, v9, v21
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v21, v29
	ldr	q20, [sp, #2672]                ; 16-byte Reload
	mov.16b	v7, v19
	bsl.16b	v7, v20, v18
	str	q7, [sp, #1200]                 ; 16-byte Spill
	fcmgt.4s	v18, v26, v29
	bit.16b	v3, v20, v18
	stp	q26, q3, [sp, #576]             ; 32-byte Folded Spill
	ldr	q3, [sp, #1280]                 ; 16-byte Reload
	fsub.4s	v3, v3, v11
	and.16b	v20, v31, v3
	fcmge.4s	v3, v20, v9
	fcmge.4s	v18, v29, v20
	and.16b	v3, v3, v18
	ldr	q7, [sp, #1296]                 ; 16-byte Reload
	ldr	q21, [sp, #2624]                ; 16-byte Reload
	fsub.4s	v18, v7, v21
	and.16b	v26, v0, v18
	fcmge.4s	v18, v26, v9
	fcmge.4s	v19, v29, v26
	and.16b	v18, v18, v19
	and.16b	v19, v18, v26
	ldr	q24, [sp, #2640]                ; 16-byte Reload
	fmul.4s	v18, v19, v24
	movi.4s	v7, #75, lsl #24
	mvni.4s	v23, #128, lsl #24
	mov.16b	v22, v23
	bsl.16b	v22, v7, v18
	fadd.4s	v18, v18, v22
	fsub.4s	v18, v18, v22
	and.16b	v3, v3, v20
	fmul.4s	v22, v3, v24
	bsl.16b	v23, v7, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	fcvtzs.4s	v18, v18
	scvtf.4s	v23, v18
	ldr	q7, [sp, #2592]                 ; 16-byte Reload
	fmul.4s	v24, v23, v7
	fsub.4s	v19, v19, v24
	fcvtzs.4s	v22, v22
	scvtf.4s	v24, v22
	fmul.4s	v25, v24, v7
	fsub.4s	v3, v3, v25
	fmul.4s	v24, v24, v14
	fsub.4s	v3, v3, v24
	fmul.4s	v23, v23, v14
	fsub.4s	v19, v19, v23
	fmul.4s	v23, v19, v28
	fadd.4s	v23, v23, v10
	fmul.4s	v23, v19, v23
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v19, v23
	mov.16b	v11, v27
	fadd.4s	v23, v23, v27
	fmul.4s	v23, v19, v23
	ldr	q10, [sp, #2688]                ; 16-byte Reload
	fadd.4s	v23, v23, v10
	fmul.4s	v23, v19, v23
	movi.4s	v25, #63, lsl #24
	fadd.4s	v23, v23, v25
	fmul.4s	v24, v19, v19
	fmul.4s	v23, v24, v23
	fmul.4s	v24, v3, v28
	mov.16b	v27, v28
	fadd.4s	v24, v24, v15
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v12
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v11
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v10
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v25
	fmul.4s	v25, v3, v3
	fmul.4s	v24, v25, v24
	fadd.4s	v3, v3, v24
	fadd.4s	v19, v19, v23
	fadd.4s	v3, v3, v13
	sshr.4s	v23, v22, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v13
	fmul.4s	v3, v3, v24
	fadd.4s	v19, v19, v13
	sshr.4s	v24, v18, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v13
	fmul.4s	v19, v19, v25
	sub.4s	v22, v22, v23
	sub.4s	v18, v18, v24
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v13
	fmul.4s	v18, v19, v18
	shl.4s	v19, v22, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fcmgt.4s	v19, v9, v20
	bic.16b	v3, v3, v19
	str	q26, [sp, #1280]                ; 16-byte Spill
	fcmgt.4s	v19, v9, v26
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v26, v29
	ldr	q7, [sp, #2672]                 ; 16-byte Reload
	bit.16b	v18, v7, v19
	str	q18, [sp, #1296]                ; 16-byte Spill
	fcmgt.4s	v18, v20, v29
	bit.16b	v3, v7, v18
	stp	q20, q3, [sp, #544]             ; 32-byte Folded Spill
	ldr	q3, [sp, #1376]                 ; 16-byte Reload
	ldr	q10, [sp, #2608]                ; 16-byte Reload
	fsub.4s	v3, v3, v10
	and.16b	v28, v31, v3
	fcmge.4s	v3, v28, v9
	fcmge.4s	v18, v29, v28
	and.16b	v3, v3, v18
	ldr	q7, [sp, #1392]                 ; 16-byte Reload
	fsub.4s	v18, v7, v21
	and.16b	v20, v0, v18
	fcmge.4s	v18, v20, v9
	fcmge.4s	v19, v29, v20
	and.16b	v18, v18, v19
	and.16b	v19, v18, v20
	ldr	q21, [sp, #2640]                ; 16-byte Reload
	fmul.4s	v18, v19, v21
	mvni.4s	v7, #128, lsl #24
	movi.4s	v23, #75, lsl #24
	mov.16b	v22, v7
	bsl.16b	v22, v23, v18
	fadd.4s	v18, v18, v22
	fsub.4s	v18, v18, v22
	and.16b	v3, v3, v28
	fmul.4s	v22, v3, v21
	bif.16b	v23, v22, v7
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	fcvtzs.4s	v18, v18
	scvtf.4s	v23, v18
	ldr	q7, [sp, #2592]                 ; 16-byte Reload
	fmul.4s	v24, v23, v7
	fsub.4s	v19, v19, v24
	fcvtzs.4s	v22, v22
	scvtf.4s	v24, v22
	fmul.4s	v25, v24, v7
	fsub.4s	v3, v3, v25
	ldr	q7, [sp, #2656]                 ; 16-byte Reload
	fmul.4s	v24, v24, v7
	fsub.4s	v3, v3, v24
	fmul.4s	v23, v23, v7
	fsub.4s	v19, v19, v23
	fmul.4s	v23, v19, v27
	fadd.4s	v23, v23, v15
	fmul.4s	v23, v19, v23
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v19, v23
	mov.16b	v25, v11
	fadd.4s	v23, v23, v11
	fmul.4s	v23, v19, v23
	ldr	q26, [sp, #2688]                ; 16-byte Reload
	fadd.4s	v23, v23, v26
	fmul.4s	v23, v19, v23
	movi.4s	v21, #63, lsl #24
	fadd.4s	v23, v23, v21
	fmul.4s	v24, v19, v19
	fmul.4s	v23, v24, v23
	fmul.4s	v24, v3, v27
	fadd.4s	v24, v24, v15
	mov.16b	v11, v15
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v12
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v25
	mov.16b	v15, v25
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v26
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v21
	movi.4s	v14, #63, lsl #24
	fmul.4s	v25, v3, v3
	fmul.4s	v24, v25, v24
	fadd.4s	v3, v3, v24
	fadd.4s	v19, v19, v23
	fadd.4s	v3, v3, v13
	sshr.4s	v23, v22, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v13
	fmul.4s	v3, v3, v24
	fadd.4s	v19, v19, v13
	sshr.4s	v24, v18, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v13
	fmul.4s	v19, v19, v25
	sub.4s	v22, v22, v23
	sub.4s	v18, v18, v24
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v13
	fmul.4s	v18, v19, v18
	shl.4s	v19, v22, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fcmgt.4s	v19, v9, v28
	bic.16b	v3, v3, v19
	str	q20, [sp, #1376]                ; 16-byte Spill
	fcmgt.4s	v19, v9, v20
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v20, v29
	ldr	q20, [sp, #2672]                ; 16-byte Reload
	bit.16b	v18, v20, v19
	str	q18, [sp, #1392]                ; 16-byte Spill
	fcmgt.4s	v18, v28, v29
	bit.16b	v3, v20, v18
	str	q3, [sp, #528]                  ; 16-byte Spill
	ldr	q3, [sp, #2512]                 ; 16-byte Reload
	fsub.4s	v3, v3, v10
	and.16b	v27, v31, v3
	fcmge.4s	v3, v27, v9
	fcmge.4s	v18, v29, v27
	and.16b	v3, v3, v18
	ldr	q18, [sp, #2528]                ; 16-byte Reload
	ldr	q19, [sp, #2624]                ; 16-byte Reload
	fsub.4s	v18, v18, v19
	and.16b	v10, v0, v18
	fcmge.4s	v18, v10, v9
	fcmge.4s	v19, v29, v10
	and.16b	v18, v18, v19
	and.16b	v18, v18, v10
	ldr	q24, [sp, #2640]                ; 16-byte Reload
	fmul.4s	v19, v18, v24
	movi.4s	v23, #75, lsl #24
	mvni.4s	v25, #128, lsl #24
	mov.16b	v22, v25
	bsl.16b	v22, v23, v19
	fadd.4s	v19, v19, v22
	fsub.4s	v19, v19, v22
	and.16b	v3, v3, v27
	fmul.4s	v22, v3, v24
	bif.16b	v23, v22, v25
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	fcvtzs.4s	v19, v19
	scvtf.4s	v23, v19
	ldr	q25, [sp, #2592]                ; 16-byte Reload
	fmul.4s	v24, v23, v25
	fsub.4s	v18, v18, v24
	fcvtzs.4s	v22, v22
	scvtf.4s	v24, v22
	fmul.4s	v25, v24, v25
	fsub.4s	v3, v3, v25
	fmul.4s	v23, v23, v7
	fmul.4s	v24, v24, v7
	fsub.4s	v3, v3, v24
	fsub.4s	v18, v18, v23
	ldr	q26, [sp, #2496]                ; 16-byte Reload
	fmul.4s	v23, v18, v26
	fmul.4s	v24, v3, v26
	fadd.4s	v24, v24, v11
	fadd.4s	v23, v23, v11
	fmul.4s	v23, v18, v23
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v12
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v18, v23
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v15
	fadd.4s	v23, v23, v15
	fmul.4s	v23, v18, v23
	fmul.4s	v24, v3, v24
	ldr	q7, [sp, #2688]                 ; 16-byte Reload
	fadd.4s	v24, v24, v7
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v18, v23
	fadd.4s	v23, v23, v14
	fmul.4s	v25, v18, v18
	fmul.4s	v23, v25, v23
	fmul.4s	v24, v3, v24
	fadd.4s	v24, v24, v14
	fmul.4s	v25, v3, v3
	fmul.4s	v24, v25, v24
	fadd.4s	v3, v3, v24
	fadd.4s	v18, v18, v23
	fadd.4s	v3, v3, v13
	sshr.4s	v23, v22, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v13
	fmul.4s	v3, v3, v24
	fadd.4s	v18, v18, v13
	sshr.4s	v24, v19, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v13
	fmul.4s	v18, v18, v25
	sub.4s	v22, v22, v23
	sub.4s	v19, v19, v24
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v18, v18, v19
	shl.4s	v19, v22, #23
	add.4s	v19, v19, v13
	fmul.4s	v3, v3, v19
	fcmgt.4s	v19, v9, v27
	bic.16b	v3, v3, v19
	fcmgt.4s	v19, v9, v10
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v10, v29
	mov.16b	v7, v19
	bsl.16b	v7, v20, v18
	fcmgt.4s	v18, v27, v29
	bit.16b	v3, v20, v18
	stp	q3, q7, [sp, #496]              ; 32-byte Folded Spill
	sshll.2d	v3, v0, #0
	ldr	q18, [sp, #1824]                ; 16-byte Reload
	ldr	q19, [sp, #2032]                ; 16-byte Reload
	bit.16b	v18, v19, v3
	str	q18, [sp, #1824]                ; 16-byte Spill
	ldr	q3, [sp, #1472]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q21, [sp, #160]                 ; 16-byte Reload
	ldr	q7, [sp, #1488]                 ; 16-byte Reload
	mov.16b	v22, v3
	bsl.16b	v22, v7, v21
	ldr	q3, [sp, #1520]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q7, [sp, #1504]                 ; 16-byte Reload
	mov.16b	v19, v3
	bsl.16b	v19, v7, v21
	ldr	q3, [sp, #1424]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q7, [sp, #1440]                 ; 16-byte Reload
	mov.16b	v23, v3
	bsl.16b	v23, v7, v21
	ldr	q3, [sp, #1408]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q7, [sp, #1456]                 ; 16-byte Reload
	mov.16b	v24, v3
	bsl.16b	v24, v7, v21
	ldr	q3, [sp, #1312]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q7, [sp, #1328]                 ; 16-byte Reload
	mov.16b	v25, v3
	bsl.16b	v25, v7, v21
	ldr	q3, [sp, #1344]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q7, [sp, #1360]                 ; 16-byte Reload
	mov.16b	v26, v3
	bsl.16b	v26, v7, v21
	ldr	q3, [sp, #1216]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q7, [sp, #1232]                 ; 16-byte Reload
	mov.16b	v9, v3
	bsl.16b	v9, v7, v21
	ldr	q3, [sp, #1248]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q7, [sp, #1264]                 ; 16-byte Reload
	mov.16b	v29, v3
	bsl.16b	v29, v7, v21
	ldr	q3, [sp, #1120]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q7, [sp, #1136]                 ; 16-byte Reload
	mov.16b	v15, v3
	bsl.16b	v15, v7, v21
	ldr	q3, [sp, #1152]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q7, [sp, #1168]                 ; 16-byte Reload
	mov.16b	v20, v3
	bsl.16b	v20, v7, v21
	ldr	q3, [sp, #1024]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q7, [sp, #1040]                 ; 16-byte Reload
	mov.16b	v11, v3
	bsl.16b	v11, v7, v21
	ldr	q3, [sp, #1056]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q7, [sp, #1072]                 ; 16-byte Reload
	bsl.16b	v3, v7, v21
	ldr	q7, [sp, #928]                  ; 16-byte Reload
	fcmeq.4s	v18, v7, v7
	ldr	q7, [sp, #944]                  ; 16-byte Reload
	mov.16b	v13, v18
	bsl.16b	v13, v7, v21
	ldr	q7, [sp, #960]                  ; 16-byte Reload
	fcmeq.4s	v18, v7, v7
	ldr	q7, [sp, #976]                  ; 16-byte Reload
	mov.16b	v12, v18
	bsl.16b	v12, v7, v21
	ldr	q7, [sp, #832]                  ; 16-byte Reload
	fcmeq.4s	v18, v7, v7
	ldr	q7, [sp, #848]                  ; 16-byte Reload
	bif.16b	v7, v21, v18
	str	q7, [sp, #1472]                 ; 16-byte Spill
	ldr	q7, [sp, #864]                  ; 16-byte Reload
	fcmeq.4s	v18, v7, v7
	ldr	q7, [sp, #880]                  ; 16-byte Reload
	mov.16b	v14, v18
	bsl.16b	v14, v7, v21
	ldr	q7, [sp, #736]                  ; 16-byte Reload
	fcmeq.4s	v18, v7, v7
	ldr	q7, [sp, #752]                  ; 16-byte Reload
	bif.16b	v7, v21, v18
	str	q7, [sp, #1440]                 ; 16-byte Spill
	ldr	q7, [sp, #768]                  ; 16-byte Reload
	fcmeq.4s	v18, v7, v7
	ldr	q7, [sp, #784]                  ; 16-byte Reload
	bif.16b	v7, v21, v18
	str	q7, [sp, #1424]                 ; 16-byte Spill
	ldr	q7, [sp, #704]                  ; 16-byte Reload
	fcmeq.4s	v18, v7, v7
	ldr	q7, [sp, #720]                  ; 16-byte Reload
	bif.16b	v7, v21, v18
	str	q7, [sp, #1408]                 ; 16-byte Spill
	ldr	q7, [sp, #800]                  ; 16-byte Reload
	fcmeq.4s	v18, v7, v7
	ldr	q7, [sp, #816]                  ; 16-byte Reload
	bif.16b	v7, v21, v18
	str	q7, [sp, #1360]                 ; 16-byte Spill
	mov	w9, #33792                      ; =0x8400
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	ldr	q18, [x9, #16]
	str	q19, [sp, #2688]                ; 16-byte Spill
	bit.16b	v18, v19, v0
	ldr	q19, [x9]
	str	q22, [sp, #2672]                ; 16-byte Spill
	bit.16b	v19, v22, v31
	stp	q19, q18, [x9]
	ldr	q7, [sp, #672]                  ; 16-byte Reload
	fcmeq.4s	v18, v7, v7
	ldr	q7, [sp, #688]                  ; 16-byte Reload
	bif.16b	v7, v21, v18
	str	q7, [sp, #1344]                 ; 16-byte Spill
	ldr	q7, [sp, #896]                  ; 16-byte Reload
	fcmeq.4s	v18, v7, v7
	ldr	q7, [sp, #912]                  ; 16-byte Reload
	bif.16b	v7, v21, v18
	str	q7, [sp, #1328]                 ; 16-byte Spill
	ldr	x9, [sp, #296]                  ; 8-byte Reload
	ldp	q19, q18, [x9]
	str	q24, [sp, #2656]                ; 16-byte Spill
	bit.16b	v18, v24, v0
	str	q23, [sp, #2640]                ; 16-byte Spill
	bit.16b	v19, v23, v31
	stp	q19, q18, [x9]
	ldr	q7, [sp, #640]                  ; 16-byte Reload
	fcmeq.4s	v18, v7, v7
	ldr	q7, [sp, #656]                  ; 16-byte Reload
	bif.16b	v7, v21, v18
	str	q7, [sp, #1312]                 ; 16-byte Spill
	ldr	q7, [sp, #992]                  ; 16-byte Reload
	fcmeq.4s	v18, v7, v7
	ldr	q7, [sp, #1008]                 ; 16-byte Reload
	bif.16b	v7, v21, v18
	str	q7, [sp, #1248]                 ; 16-byte Spill
	ldr	q7, [sp, #608]                  ; 16-byte Reload
	fcmeq.4s	v18, v7, v7
	ldr	q7, [sp, #624]                  ; 16-byte Reload
	bif.16b	v7, v21, v18
	str	q7, [sp, #1264]                 ; 16-byte Spill
	ldr	x9, [sp, #288]                  ; 8-byte Reload
	ldp	q19, q18, [x9]
	str	q26, [sp, #2592]                ; 16-byte Spill
	bit.16b	v18, v26, v0
	str	q25, [sp, #2544]                ; 16-byte Spill
	bit.16b	v19, v25, v31
	stp	q19, q18, [x9]
	ldr	x9, [sp, #280]                  ; 8-byte Reload
	ldp	q19, q18, [x9]
	str	q29, [sp, #2496]                ; 16-byte Spill
	bit.16b	v18, v29, v0
	str	q9, [sp, #2032]                 ; 16-byte Spill
	bit.16b	v19, v9, v31
	stp	q19, q18, [x9]
	ldr	x9, [sp, #272]                  ; 8-byte Reload
	ldp	q19, q18, [x9]
	str	q20, [sp, #2016]                ; 16-byte Spill
	bit.16b	v18, v20, v0
	str	q15, [sp, #1520]                ; 16-byte Spill
	bit.16b	v19, v15, v31
	stp	q19, q18, [x9]
	ldr	d7, [sp, #1536]                 ; 8-byte Reload
	zip1.8b	v18, v7, v0
	ushll.4s	v18, v18, #0
	shl.4s	v18, v18, #31
	cmlt.4s	v15, v18, #0
	and.16b	v20, v15, v3
	zip2.8b	v3, v7, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v18, v3, #0
	and.16b	v7, v18, v11
	ldr	x9, [sp, #264]                  ; 8-byte Reload
	ldp	q19, q3, [x9]
	str	q7, [sp, #1536]                 ; 16-byte Spill
	bit.16b	v3, v7, v0
	bit.16b	v19, v20, v31
	stp	q19, q3, [x9]
	ldr	q3, [sp, #1088]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q7, [sp, #1104]                 ; 16-byte Reload
	bsl.16b	v3, v7, v21
	and.16b	v7, v15, v12
	and.16b	v22, v18, v13
	ldr	x9, [sp, #256]                  ; 8-byte Reload
	ldr	q19, [x9, #16]
	str	q22, [sp, #1504]                ; 16-byte Spill
	bit.16b	v19, v22, v0
	ldr	q22, [x9]
	str	q7, [sp, #1488]                 ; 16-byte Spill
	bit.16b	v22, v7, v31
	stp	q22, q19, [x9]
	ldr	q7, [sp, #576]                  ; 16-byte Reload
	fcmeq.4s	v19, v7, v7
	ldr	q7, [sp, #592]                  ; 16-byte Reload
	bsl.16b	v19, v7, v21
	and.16b	v7, v15, v14
	ldr	q22, [sp, #1472]                ; 16-byte Reload
	and.16b	v23, v18, v22
	ldr	x9, [sp, #248]                  ; 8-byte Reload
	ldr	q22, [x9, #16]
	str	q23, [sp, #1472]                ; 16-byte Spill
	bit.16b	v22, v23, v0
	ldr	q23, [x9]
	str	q7, [sp, #1456]                 ; 16-byte Spill
	bit.16b	v23, v7, v31
	stp	q23, q22, [x9]
	ldr	q7, [sp, #1184]                 ; 16-byte Reload
	fcmeq.4s	v22, v7, v7
	ldr	q7, [sp, #1200]                 ; 16-byte Reload
	bsl.16b	v22, v7, v21
	ldr	q7, [sp, #1424]                 ; 16-byte Reload
	and.16b	v7, v15, v7
	ldr	q23, [sp, #1440]                ; 16-byte Reload
	and.16b	v24, v18, v23
	ldr	x9, [sp, #240]                  ; 8-byte Reload
	ldr	q23, [x9, #16]
	str	q24, [sp, #1440]                ; 16-byte Spill
	bit.16b	v23, v24, v0
	ldr	q24, [x9]
	str	q7, [sp, #1424]                 ; 16-byte Spill
	bit.16b	v24, v7, v31
	stp	q24, q23, [x9]
	ldr	q7, [sp, #544]                  ; 16-byte Reload
	fcmeq.4s	v23, v7, v7
	ldr	q7, [sp, #560]                  ; 16-byte Reload
	bsl.16b	v23, v7, v21
	ldr	q7, [sp, #1360]                 ; 16-byte Reload
	and.16b	v7, v18, v7
	ldr	q24, [sp, #1408]                ; 16-byte Reload
	and.16b	v25, v15, v24
	ldr	x9, [sp, #232]                  ; 8-byte Reload
	ldr	q24, [x9]
	str	q25, [sp, #1408]                ; 16-byte Spill
	bit.16b	v24, v25, v31
	ldr	q25, [x9, #16]
	str	q7, [sp, #1360]                 ; 16-byte Spill
	bit.16b	v25, v7, v0
	stp	q24, q25, [x9]
	ldr	q7, [sp, #1280]                 ; 16-byte Reload
	fcmeq.4s	v24, v7, v7
	ldr	q7, [sp, #1296]                 ; 16-byte Reload
	bsl.16b	v24, v7, v21
	ldr	q7, [sp, #1328]                 ; 16-byte Reload
	and.16b	v26, v18, v7
	ldr	q7, [sp, #1344]                 ; 16-byte Reload
	and.16b	v7, v15, v7
	ldr	x9, [sp, #224]                  ; 8-byte Reload
	ldp	q25, q11, [x9]
	str	q7, [sp, #1344]                 ; 16-byte Spill
	bit.16b	v25, v7, v31
	str	q26, [sp, #1328]                ; 16-byte Spill
	bit.16b	v11, v26, v0
	stp	q25, q11, [x9]
	fcmeq.4s	v25, v28, v28
	ldr	q7, [sp, #528]                  ; 16-byte Reload
	bsl.16b	v25, v7, v21
	ldr	q7, [sp, #1248]                 ; 16-byte Reload
	and.16b	v7, v18, v7
	ldr	q26, [sp, #1312]                ; 16-byte Reload
	and.16b	v26, v15, v26
	ldr	x9, [sp, #216]                  ; 8-byte Reload
	ldp	q11, q12, [x9]
	str	q26, [sp, #1312]                ; 16-byte Spill
	bit.16b	v11, v26, v31
	str	q7, [sp, #1296]                 ; 16-byte Spill
	bit.16b	v12, v7, v0
	stp	q11, q12, [x9]
	ldr	q7, [sp, #1376]                 ; 16-byte Reload
	fcmeq.4s	v11, v7, v7
	ldr	q7, [sp, #1392]                 ; 16-byte Reload
	bsl.16b	v11, v7, v21
	and.16b	v28, v18, v3
	ldr	q3, [sp, #1264]                 ; 16-byte Reload
	and.16b	v26, v15, v3
	ldr	x9, [sp, #208]                  ; 8-byte Reload
	ldp	q3, q12, [x9]
	str	q26, [sp, #1392]                ; 16-byte Spill
	bit.16b	v3, v26, v31
	str	q28, [sp, #1376]                ; 16-byte Spill
	bit.16b	v12, v28, v0
	stp	q3, q12, [x9]
	and.16b	v7, v18, v19
	and.16b	v24, v18, v24
	and.16b	v19, v18, v11
	and.16b	v26, v15, v22
	and.16b	v22, v15, v23
	and.16b	v23, v15, v25
	ldr	x9, [sp, #200]                  ; 8-byte Reload
	ldp	q18, q3, [x9]
	str	q7, [sp, #1280]                 ; 16-byte Spill
	bit.16b	v3, v7, v0
	str	q26, [sp, #1232]                ; 16-byte Spill
	bit.16b	v18, v26, v31
	stp	q18, q3, [x9]
	ldr	x9, [sp, #192]                  ; 8-byte Reload
	ldp	q3, q18, [x9]
	str	q22, [sp, #1264]                ; 16-byte Spill
	bit.16b	v3, v22, v31
	str	q24, [sp, #1248]                ; 16-byte Spill
	bit.16b	v18, v24, v0
	stp	q3, q18, [x9]
	ldr	x9, [sp, #184]                  ; 8-byte Reload
	ldp	q3, q18, [x9]
	mov.16b	v29, v23
	bit.16b	v3, v23, v31
	mov.16b	v7, v19
	bit.16b	v18, v19, v0
	stp	q3, q18, [x9]
	fcmeq.4s	v3, v27, v27
	ldp	q19, q18, [sp, #496]            ; 32-byte Folded Reload
	mov.16b	v9, v3
	bsl.16b	v9, v19, v21
	fcmeq.4s	v3, v10, v10
	mov.16b	v10, v3
	bsl.16b	v10, v18, v21
	sshll2.2d	v19, v31, #0
	ldr	q3, [sp, #1840]                 ; 16-byte Reload
	ldr	q18, [sp, #2048]                ; 16-byte Reload
	str	q19, [sp, #1216]                ; 16-byte Spill
	bit.16b	v3, v18, v19
	str	q3, [sp, #1840]                 ; 16-byte Spill
	sshll.2d	v3, v31, #0
	ldr	q18, [sp, #2464]                ; 16-byte Reload
	ldr	q11, [sp, #2880]                ; 16-byte Reload
	bit.16b	v11, v18, v3
	mov	w9, #49760                      ; =0xc260
	add	x9, x8, x9
	ldr	q27, [sp, #1568]                ; 16-byte Reload
	str	q11, [sp, #2880]                ; 16-byte Spill
LBB1_142:                               ; %direct.true597.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB1_143 Depth 4
	mov	x13, #0                         ; =0x0
	lsl	x14, x25, #7
	dup.2d	v11, x14
	ldr	q21, [sp, #2896]                ; 16-byte Reload
	orr.16b	v3, v11, v21
	fmov	x14, d3
	add	x14, x15, x14
	ldp	q18, q3, [x14]
	fmul.4s	v18, v9, v18
	fmul.4s	v3, v10, v3
	mov	w14, #32                        ; =0x20
	bfi	x14, x25, #7, #57
	dup.2d	v12, x14
	orr.16b	v19, v12, v21
	fmov	x14, d19
	add	x14, x15, x14
	ldp	q22, q19, [x14]
	fmul.4s	v22, v9, v22
	fmul.4s	v19, v10, v19
	mov	w14, #64                        ; =0x40
	bfi	x14, x25, #7, #57
	dup.2d	v13, x14
	orr.16b	v23, v13, v21
	fmov	x14, d23
	add	x14, x15, x14
	ldp	q24, q23, [x14]
	fmul.4s	v24, v9, v24
	fmul.4s	v23, v10, v23
	mov	w14, #96                        ; =0x60
	bfi	x14, x25, #7, #57
	dup.2d	v14, x14
	orr.16b	v25, v14, v21
	fmov	x14, d25
	add	x14, x15, x14
	ldp	q15, q25, [x14]
	fmul.4s	v15, v9, v15
	fmul.4s	v25, v10, v25
	bit.16b	v16, v3, v0
	bit.16b	v1, v18, v31
	bit.16b	v30, v19, v0
	bit.16b	v17, v22, v31
	bit.16b	v6, v23, v0
	bit.16b	v5, v24, v31
	bit.16b	v4, v25, v0
	bit.16b	v8, v15, v31
	mov	x14, x9
LBB1_143:                               ; %direct.true625.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ;       Parent Loop BB1_142 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	add	x16, x7, x13
	ldp	q18, q3, [x16]
	and.16b	v18, v31, v18
	and.16b	v22, v0, v3
	ldp	q19, q3, [x14, #-96]
	and.16b	v19, v31, v19
	and.16b	v3, v0, v3
	fmul.4s	v3, v22, v3
	fmul.4s	v19, v18, v19
	fadd.4s	v23, v1, v19
	fadd.4s	v3, v16, v3
	ldp	q24, q19, [x14, #-64]
	and.16b	v24, v31, v24
	and.16b	v19, v0, v19
	fmul.4s	v25, v22, v19
	fmul.4s	v19, v18, v24
	fadd.4s	v19, v17, v19
	fadd.4s	v25, v30, v25
	ldp	q15, q24, [x14, #-32]
	and.16b	v15, v31, v15
	and.16b	v24, v0, v24
	fmul.4s	v24, v22, v24
	fmul.4s	v15, v18, v15
	fadd.4s	v15, v5, v15
	fadd.4s	v24, v6, v24
	ldp	q26, q21, [x14]
	and.16b	v26, v31, v26
	and.16b	v21, v0, v21
	fmul.4s	v21, v22, v21
	fmul.4s	v18, v18, v26
	fadd.4s	v18, v8, v18
	fadd.4s	v22, v4, v21
	bit.16b	v16, v3, v0
	bit.16b	v1, v23, v31
	bit.16b	v30, v25, v0
	bit.16b	v17, v19, v31
	bit.16b	v6, v24, v0
	bit.16b	v5, v15, v31
	bit.16b	v4, v22, v0
	bit.16b	v8, v18, v31
	add	x13, x13, #32
	add	x14, x14, #3072
	cmp	x13, #512
	b.ne	LBB1_143
; %bb.144:                              ; %direct.false626.i.i
                                        ;   in Loop: Header=BB1_142 Depth=3
	ldr	q26, [sp, #2880]                ; 16-byte Reload
	orr.16b	v21, v11, v26
	mov.16b	v11, v26
	fmov	x13, d21
	add	x13, x30, x13
	ldp	q21, q26, [x13]
	bif.16b	v3, v26, v0
	bit.16b	v21, v23, v31
	stp	q21, q3, [x13]
	orr.16b	v3, v12, v11
	fmov	x13, d3
	add	x13, x30, x13
	ldp	q3, q21, [x13]
	bit.16b	v21, v25, v0
	bit.16b	v3, v19, v31
	stp	q3, q21, [x13]
	orr.16b	v3, v13, v11
	fmov	x13, d3
	add	x13, x30, x13
	ldp	q3, q19, [x13]
	bit.16b	v19, v24, v0
	bit.16b	v3, v15, v31
	stp	q3, q19, [x13]
	orr.16b	v3, v14, v11
	fmov	x13, d3
	add	x13, x30, x13
	ldp	q3, q19, [x13]
	bit.16b	v19, v22, v0
	bit.16b	v3, v18, v31
	stp	q3, q19, [x13]
	add	x25, x25, #1
	add	x9, x9, #128
	cmp	x25, #24
	b.ne	LBB1_142
; %bb.145:                              ; %direct.true692.i.i.preheader
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x9, #0                          ; =0x0
	ldr	q22, [sp, #2896]                ; 16-byte Reload
LBB1_146:                               ; %direct.true692.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	d3, x9
	orr.16b	v18, v3, v11
	fmov	x13, d18
	add	x13, x30, x13
	ldp	q18, q19, [x13]
	orr.16b	v3, v3, v22
	fmov	x13, d3
	add	x13, x3, x13
	ldp	q3, q21, [x13]
	bif.16b	v19, v21, v0
	bit.16b	v3, v18, v31
	stp	q3, q19, [x13]
	add	x9, x9, #32
	cmp	x9, #3072
	b.ne	LBB1_146
; %bb.147:                              ; %direct.true708.i.i.preheader
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x9, x8
	mov	w13, #96                        ; =0x60
	ldr	q25, [sp, #448]                 ; 16-byte Reload
	ldr	q14, [sp, #1872]                ; 16-byte Reload
	ldr	q28, [sp, #2704]                ; 16-byte Reload
	ldr	q22, [sp, #1632]                ; 16-byte Reload
	ldr	q23, [sp, #1616]                ; 16-byte Reload
	ldr	q26, [sp, #1600]                ; 16-byte Reload
	ldr	q12, [sp, #1584]                ; 16-byte Reload
	ldr	q15, [sp, #1552]                ; 16-byte Reload
	ldr	q13, [sp, #2064]                ; 16-byte Reload
LBB1_148:                               ; %direct.true708.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x9, #5632]
	ldr	q18, [x9, #5648]
	ldr	q19, [x9, #2560]
	ldr	q21, [x9, #2576]
	bif.16b	v18, v21, v0
	bif.16b	v3, v19, v31
	str	q3, [x9, #2560]
	str	q18, [x9, #2576]
	add	x9, x9, #32
	subs	x13, x13, #1
	b.ne	LBB1_148
; %bb.149:                              ; %direct.false709.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #2528]                 ; 16-byte Reload
	ldr	q18, [sp, #2624]                ; 16-byte Reload
	bit.16b	v3, v18, v0
	str	q3, [sp, #2528]                 ; 16-byte Spill
	ldr	q3, [sp, #2512]                 ; 16-byte Reload
	ldr	q18, [sp, #2608]                ; 16-byte Reload
	bit.16b	v3, v18, v31
	str	q3, [sp, #2512]                 ; 16-byte Spill
	movi.2d	v18, #0000000000000000
	ldr	q3, [sp, #2672]                 ; 16-byte Reload
	fadd.4s	v3, v3, v18
	ldr	q19, [sp, #2640]                ; 16-byte Reload
	fadd.4s	v3, v19, v3
	ldr	q19, [sp, #2688]                ; 16-byte Reload
	fadd.4s	v18, v19, v18
	ldr	q19, [sp, #2656]                ; 16-byte Reload
	fadd.4s	v18, v19, v18
	ldr	q19, [sp, #2592]                ; 16-byte Reload
	fadd.4s	v18, v19, v18
	ldr	q19, [sp, #2544]                ; 16-byte Reload
	fadd.4s	v3, v19, v3
	ldr	q19, [sp, #2032]                ; 16-byte Reload
	fadd.4s	v3, v19, v3
	ldr	q19, [sp, #2496]                ; 16-byte Reload
	fadd.4s	v18, v19, v18
	ldr	q19, [sp, #2016]                ; 16-byte Reload
	fadd.4s	v18, v19, v18
	ldr	q19, [sp, #1520]                ; 16-byte Reload
	fadd.4s	v3, v19, v3
	fadd.4s	v3, v20, v3
	ldr	q19, [sp, #1536]                ; 16-byte Reload
	fadd.4s	v18, v19, v18
	ldr	q19, [sp, #1504]                ; 16-byte Reload
	fadd.4s	v18, v19, v18
	ldr	q19, [sp, #1488]                ; 16-byte Reload
	fadd.4s	v3, v19, v3
	ldr	q19, [sp, #1456]                ; 16-byte Reload
	fadd.4s	v3, v19, v3
	ldr	q19, [sp, #1472]                ; 16-byte Reload
	fadd.4s	v18, v19, v18
	ldr	q19, [sp, #1440]                ; 16-byte Reload
	fadd.4s	v18, v19, v18
	ldr	q19, [sp, #1424]                ; 16-byte Reload
	fadd.4s	v3, v19, v3
	ldr	q19, [sp, #1408]                ; 16-byte Reload
	fadd.4s	v3, v19, v3
	ldr	q19, [sp, #1360]                ; 16-byte Reload
	fadd.4s	v18, v19, v18
	ldr	q19, [sp, #1328]                ; 16-byte Reload
	fadd.4s	v18, v19, v18
	ldr	q19, [sp, #1344]                ; 16-byte Reload
	fadd.4s	v3, v19, v3
	ldr	q19, [sp, #1312]                ; 16-byte Reload
	fadd.4s	v3, v19, v3
	ldr	q19, [sp, #1296]                ; 16-byte Reload
	fadd.4s	v18, v19, v18
	ldr	q19, [sp, #1376]                ; 16-byte Reload
	fadd.4s	v18, v19, v18
	ldr	q19, [sp, #1392]                ; 16-byte Reload
	fadd.4s	v3, v19, v3
	ldr	q19, [sp, #1232]                ; 16-byte Reload
	fadd.4s	v3, v19, v3
	ldr	q19, [sp, #1280]                ; 16-byte Reload
	fadd.4s	v18, v19, v18
	ldr	q19, [sp, #1248]                ; 16-byte Reload
	fadd.4s	v18, v19, v18
	ldr	q19, [sp, #1264]                ; 16-byte Reload
	fadd.4s	v3, v19, v3
	fadd.4s	v3, v29, v3
	fadd.4s	v18, v7, v18
	fmul.4s	v19, v22, v9
	fmul.4s	v21, v23, v10
	fadd.4s	v18, v21, v18
	fadd.4s	v3, v19, v3
	bit.16b	v22, v3, v31
	bit.16b	v23, v18, v0
	add	x21, x21, #1
	cmp	x21, #129
	ldr	q24, [sp, #2576]                ; 16-byte Reload
	ldr	q11, [sp, #2112]                ; 16-byte Reload
	ldr	q21, [sp, #2560]                ; 16-byte Reload
	ldr	q9, [sp, #2480]                 ; 16-byte Reload
	ldr	q29, [sp, #2096]                ; 16-byte Reload
	ldr	q20, [sp, #2080]                ; 16-byte Reload
	b.ne	LBB1_40
; %bb.150:                              ; %direct.schedule.51.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q1, [sp, #16]                   ; 16-byte Reload
	fmov	x9, d1
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #5
	fmov	d4, x9
	mov.d	x9, v1[1]
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #5
	mov.d	v4[1], x9
	ldr	q1, [sp, #32]                   ; 16-byte Reload
	fmov	x9, d1
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #5
	fmov	d3, x9
	mov.d	x9, v1[1]
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #5
	mov.d	v3[1], x9
	ldp	q1, q5, [sp, #48]               ; 32-byte Folded Reload
	fmov	x9, d1
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #5
	fmov	d2, x9
	mov.d	x9, v1[1]
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #5
	mov.d	v2[1], x9
	fmov	x9, d5
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #5
	fmov	d1, x9
	mov.d	x9, v5[1]
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #5
	mov.d	v1[1], x9
	sshll.2d	v5, v0, #0
	sshll.2d	v6, v31, #0
	and.16b	v1, v6, v1
	ldr	q6, [sp, #1216]                 ; 16-byte Reload
	and.16b	v2, v6, v2
	and.16b	v3, v5, v3
	and.16b	v4, v14, v4
	ldr	w22, [sp, #12]                  ; 4-byte Reload
	ldr	x2, [sp, #152]                  ; 8-byte Reload
	movi.2s	v8, #80
	ldr	x11, [sp, #88]                  ; 8-byte Reload
	b	LBB1_152
LBB1_151:                               ; %else517
                                        ;   in Loop: Header=BB1_152 Depth=2
	add	x8, x8, #1
	cmp	x8, #96
	b.eq	LBB1_2
LBB1_152:                               ; %direct.true777.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	uzp1.8h	v5, v31, v0
	ldr	q6, [x23, lCPI1_6@PAGEOFF]
	and.16b	v5, v5, v6
	addv.8h	h5, v5
	fmov	w9, s5
	dup.2d	v5, x8
	add.2d	v6, v5, v1
	add	x10, x15, x8, lsl #5
	ldp	q16, q7, [x10]
	and.16b	v16, v31, v16
	fdiv.4s	v16, v16, v22
	shl.2d	v17, v6, #2
	dup.2d	v6, x11
	add.2d	v17, v6, v17
	tbnz	w9, #0, LBB1_160
; %bb.153:                              ; %else496
                                        ;   in Loop: Header=BB1_152 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_161
LBB1_154:                               ; %else499
                                        ;   in Loop: Header=BB1_152 Depth=2
	add.2d	v17, v5, v2
	shl.2d	v17, v17, #2
	add.2d	v17, v6, v17
	tbnz	w9, #2, LBB1_162
LBB1_155:                               ; %else502
                                        ;   in Loop: Header=BB1_152 Depth=2
	tbnz	w9, #3, LBB1_163
LBB1_156:                               ; %else505
                                        ;   in Loop: Header=BB1_152 Depth=2
	add.2d	v16, v5, v3
	and.16b	v7, v0, v7
	fdiv.4s	v7, v7, v23
	shl.2d	v16, v16, #2
	add.2d	v16, v6, v16
	tbnz	w9, #4, LBB1_164
LBB1_157:                               ; %else508
                                        ;   in Loop: Header=BB1_152 Depth=2
	tbnz	w9, #5, LBB1_165
LBB1_158:                               ; %else511
                                        ;   in Loop: Header=BB1_152 Depth=2
	add.2d	v5, v5, v4
	shl.2d	v5, v5, #2
	add.2d	v5, v6, v5
	tbnz	w9, #6, LBB1_166
LBB1_159:                               ; %else514
                                        ;   in Loop: Header=BB1_152 Depth=2
	tbz	w9, #7, LBB1_151
	b	LBB1_167
LBB1_160:                               ; %cond.store
                                        ;   in Loop: Header=BB1_152 Depth=2
	fmov	x10, d17
	str	s16, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_154
LBB1_161:                               ; %cond.store497
                                        ;   in Loop: Header=BB1_152 Depth=2
	mov.d	x10, v17[1]
	st1.s	{ v16 }[1], [x10]
	add.2d	v17, v5, v2
	shl.2d	v17, v17, #2
	add.2d	v17, v6, v17
	tbz	w9, #2, LBB1_155
LBB1_162:                               ; %cond.store500
                                        ;   in Loop: Header=BB1_152 Depth=2
	fmov	x10, d17
	st1.s	{ v16 }[2], [x10]
	tbz	w9, #3, LBB1_156
LBB1_163:                               ; %cond.store503
                                        ;   in Loop: Header=BB1_152 Depth=2
	mov.d	x10, v17[1]
	st1.s	{ v16 }[3], [x10]
	add.2d	v16, v5, v3
	and.16b	v7, v0, v7
	fdiv.4s	v7, v7, v23
	shl.2d	v16, v16, #2
	add.2d	v16, v6, v16
	tbz	w9, #4, LBB1_157
LBB1_164:                               ; %cond.store506
                                        ;   in Loop: Header=BB1_152 Depth=2
	fmov	x10, d16
	str	s7, [x10]
	tbz	w9, #5, LBB1_158
LBB1_165:                               ; %cond.store509
                                        ;   in Loop: Header=BB1_152 Depth=2
	mov.d	x10, v16[1]
	st1.s	{ v7 }[1], [x10]
	add.2d	v5, v5, v4
	shl.2d	v5, v5, #2
	add.2d	v5, v6, v5
	tbz	w9, #6, LBB1_159
LBB1_166:                               ; %cond.store512
                                        ;   in Loop: Header=BB1_152 Depth=2
	fmov	x10, d5
	st1.s	{ v7 }[2], [x10]
	tbz	w9, #7, LBB1_151
LBB1_167:                               ; %cond.store515
                                        ;   in Loop: Header=BB1_152 Depth=2
	mov.d	x9, v5[1]
	st1.s	{ v7 }[3], [x9]
	b	LBB1_151
LBB1_168:                               ; %block.batch.exit
	add	sp, sp, #2960
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
                                        ; -- End function
.subsections_via_symbols

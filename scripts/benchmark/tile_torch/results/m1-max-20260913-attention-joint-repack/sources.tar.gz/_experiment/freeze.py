"""Freeze selected actual producer/replay sources before the first capture.

Run: /tmp/luisa-attention-joint-env.MxOWzT/bin/python -B /tmp/luisa-attention-joint-repack.ucXtia/freeze.py
The main task must finish the full build/test gate and freeze all writers first.
This script does not build, test, load native code, capture or benchmark. It
requires the two plan-selected gates to pass and preserves historical validation
logs verbatim without relabeling failed attempts as passes.
Existing outputs are never overwritten; a failed freeze may leave a partial
archive, which must not be mistaken for a completed provenance manifest.
"""
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import platform
import re
import stat
import subprocess
import tarfile
import time


OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/mike/CLionProjects/luisa')
SOURCE = Path('/tmp/luisa-next-integration.roZbN8/source')
BUILD = SOURCE.parent / 'build'
ISOLATED_PATHS = (
    'include/luisa/tile', 'include/luisa/xir', 'src/tile', 'src/xir', 'src/backends/simd',
    'src/tests/benchmark/benchmark_tile_xir.cpp',
    'src/tests/unit/tile/bridge/test_xir_llm.cpp',
    'src/tests/common/tile_llm_test_utils.h',
    'src/tests/common/tile_llm_benchmark.h',
    'src/tests/common/tile_xir_test_utils.h',
    'src/tests/common/tile_rank_benchmark.h',
    'src/tests/common/test_device.h',
)
MAIN_PATHS = (
    'scripts/check_cpp_syntax.py',
    'scripts/benchmark/tile_torch/test_native_tile.py',
    'scripts/benchmark/tile_torch/native_tile.py',
    'scripts/benchmark/tile_torch/native_tile_replay.cpp',
)
ABI_HEADER = 'src/backends/simd/llvm/llvm_schedule_codegen.h'
SKIP_DIRS = {'.git', '.cache', '__pycache__', 'results', 'CMakeFiles', 'build'}
SKIP_SUFFIXES = {'.o', '.a', '.so', '.dylib', '.pyc', '.pyo', '.metallib'}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest_bytes(data):
    return hashlib.sha256(data).hexdigest()


def regular(path):
    require(not path.is_symlink() and stat.S_ISREG(path.stat().st_mode),
            'missing/nonregular source: ' + str(path))
    return path


def sha(path):
    with regular(path).open('rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()


def safe_name(name):
    path = PurePosixPath(name)
    require(name and not path.is_absolute() and '..' not in path.parts and
            '\\' not in name and '\x00' not in name, 'unsafe archive member: ' + name)
    return name


def capture_not_started():
    # The subsequent audit must additionally compare this freeze timestamp to
    # every recorded capture start. Absence of markers alone is not an attestation.
    markers = ('captures.json', 'replays.json', 'capture.log', 'replay.log')
    require(not any((OUT / name).exists() for name in markers), 'capture/replay marker already exists')
    for path in OUT.rglob('*'):
        if 'validation' in path.relative_to(OUT).parts:
            continue
        require(path.name not in ('output.f32', 'captured.f32', 'capture.command.json'),
                'capture payload/command already exists: ' + str(path))


def command(argv, cwd=None):
    # Keep stdout/stderr as bytes. In particular NEVER strip or round-trip a
    # patch/status stream through text: leading/trailing whitespace is evidence.
    result = subprocess.run(argv, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            check=False, timeout=30)
    require(result.returncode == 0, 'read-only command failed: ' + repr(argv) + '\n' + repr(result.stderr))
    return result.stdout, result.stderr


def fingerprint(path):
    resolved = path.resolve(strict=True)
    return dict(path=str(path), resolved_path=str(resolved), bytes=regular(resolved).stat().st_size,
                sha256=sha(resolved))


def freeze():
    started = time.time()
    archive_path, manifest_path = OUT / 'sources.tar.gz', OUT / 'provenance.json'
    require(not archive_path.exists() and not archive_path.is_symlink() and
            not manifest_path.exists() and not manifest_path.is_symlink(),
            'frozen output already exists; refusing overwrite')
    capture_not_started()
    files, generated, excluded = {}, {}, []
    owned = regular(OUT / 'owned.txt').read_text().splitlines()
    require(len(owned) == 52 and len(set(owned)) == len(owned), 'expected the frozen 52-file owned source set')
    for name in owned:
        safe_name(name)
    plan = json.loads(regular(OUT / 'plan.json').read_bytes())
    expected_owned = plan['identities']['owned_source_sha256']
    owned_hashes = {name: sha(SOURCE / name) for name in owned}
    require(owned_hashes == expected_owned == plan['identities']['selected_source_sha256'],
            'actual selected source differs from the successful gate/plan')
    require({name: sha(ROOT / name) for name in owned} == owned_hashes, 'main/selected owned sources differ')
    for path, expected in plan['identities']['files_sha256'].items():
        require(fingerprint(Path(path))['sha256'] == expected, 'plan input changed: ' + path)
    for key in ('build_gate', 'test_gate'):
        gate_path = OUT / safe_name(plan[key])
        gate = json.loads(regular(gate_path).read_bytes())
        require(gate.get('returncode') == 0 and gate.get('source_unchanged') is True and
                gate['source_sha256'] == owned_hashes, 'selected validation gate is not green')
        require(gate.get('finished', started + 1) <= started, 'selected gate not completed before freeze')
        require(gate['log_sha256'] == sha(gate_path.with_suffix('.log')), 'selected gate log changed')

    def add(path, name, origin):
        safe_name(name)
        require(name not in files and name not in generated, 'duplicate archive member: ' + name)
        files[name] = (regular(path), origin)

    def collect(base, entries, origin):
        for relative in entries:
            path = base / relative
            require(path.exists() and not path.is_symlink(), 'missing/symlink selection: ' + str(path))
            members = sorted(path.rglob('*')) if path.is_dir() else [path]
            for item in members:
                name = item.relative_to(base).as_posix()
                parts = item.relative_to(base).parts
                if any(p in SKIP_DIRS or p.startswith('cmake-build-') for p in parts) or \
                        item.suffix in SKIP_SUFFIXES or item.name == '.DS_Store':
                    excluded.append(dict(path=str(item), reason='non-source cache/result/binary selection'))
                    continue
                require(not item.is_symlink(), 'unexpected selected symlink: ' + str(item))
                if item.is_dir():
                    continue
                add(item, name, origin)

    collect(SOURCE, ISOLATED_PATHS, 'actual_isolated_producer_source')
    # A few owned forwarding/tests live outside the broad source roots.
    for name in owned:
        if name not in files:
            add(SOURCE / name, name, 'actual_isolated_producer_source')
        else:
            require(files[name][0] == SOURCE / name, 'owned file did not come from selected export')
    collect(ROOT, MAIN_PATHS, 'main_worktree_replay_and_validation_source')
    for name in ('run.py', 'gate.py', 'owned.txt', 'freeze.py', 'predeclared.json', 'audit.py', 'protocol_check.py'):
        add(OUT / name, '_experiment/' + name, 'frozen_experiment_driver')
    if (OUT / 'plan.json').exists():
        add(OUT / 'plan.json', '_experiment/plan.json', 'predeclared_experiment_plan')
    # Preserve every terminal attempt, including failed builds/regressions and
    # warning diagnostics. A failed historical attempt does not become a pass.
    validation_files = []
    for path in sorted(OUT.iterdir()):
        if not re.fullmatch(r'(full-build|regression|syntax)-.+\.(json|log)', path.name):
            continue
        add(path, '_validation/' + path.name, 'raw_validation_attempt')
        validation_files.append('_validation/' + path.name)
        if path.suffix == '.json':
            record = json.loads(regular(path).read_bytes())
            require('returncode' in record and 'finished' in record, 'validation writer still active: ' + path.name)
            require(record.get('log_sha256') == sha(path.with_suffix('.log')), 'validation attempt/log mismatch: ' + path.name)
    require(validation_files, 'validation evidence is empty')
    for name in (plan['build_gate'], plan['test_gate']):
        require('_validation/' + name in validation_files, 'selected gate missing from archive')
    for name in ('CMakeCache.txt', 'build.ninja', 'compile_commands.json'):
        add(BUILD / name, '_build/' + name, 'actual_selected_build_configuration')
    for pattern in ('*/CMakeCXXCompiler.cmake', '*/CMakeSystem.cmake'):
        for path in sorted((BUILD / 'CMakeFiles').glob(pattern)):
            add(path, '_build/' + path.relative_to(BUILD).as_posix(), 'actual_selected_build_configuration')

    cache = regular(BUILD / 'CMakeCache.txt').read_text()
    source_lines = [line.split('=', 1)[1] for line in cache.splitlines()
                    if line.startswith('CMAKE_HOME_DIRECTORY:INTERNAL=')]
    require(len(source_lines) == 1 and Path(source_lines[0]).resolve() == SOURCE.resolve(),
            'selected build tree does not name the actual isolated source')
    compiler_lines = [line.split('=', 1)[1] for line in cache.splitlines()
                      if line.startswith(('CMAKE_CXX_COMPILER:FILEPATH=', 'CMAKE_CXX_COMPILER:STRING='))]
    require(len(compiler_lines) == 1, 'ambiguous/missing configured C++ compiler')
    abi_hash = sha(SOURCE / ABI_HEADER)
    require(sha(ROOT / ABI_HEADER) == abi_hash, 'main replay helper ABI header differs from actual producer header')

    git_scope = sorted(set((*owned, *MAIN_PATHS, ABI_HEADER)))
    git_commands = (
        ('head', ['git', 'rev-parse', 'HEAD']),
        ('status', ['git', 'status', '--porcelain=v1', '-z', '--untracked-files=all', '--', *git_scope]),
        ('diff', ['git', '-c', 'color.ui=false', 'diff', '--binary', '--no-ext-diff', 'HEAD', '--', *git_scope]),
    )
    git_records = {}
    for label, argv in git_commands:
        stdout, stderr = command(argv, ROOT)
        name = '_provenance/main-' + label + ('.patch' if label == 'diff' else '.raw')
        generated[name] = stdout
        generated[name + '.stderr'] = stderr
        git_records[label] = dict(argv=argv, cwd=str(ROOT), stdout_member=name,
                                  stdout_sha256=digest_bytes(stdout), stderr_member=name + '.stderr')
    head_bytes = generated['_provenance/main-head.raw']
    require(head_bytes.endswith(b'\n') and len(head_bytes) == 41 and
            all(x in b'0123456789abcdef' for x in head_bytes[:-1]), 'unexpected HEAD output')
    main_head = head_bytes[:-1].decode('ascii')

    producer = BUILD / 'bin/benchmark_tile_xir'
    plugins = [BUILD / 'bin' / name for name in ('libluisa-backend-simd.so', 'libluisa-backend-simd.dylib')
               if (BUILD / 'bin' / name).exists()]
    require(len(plugins) == 1, 'expected exactly one actual SIMD plugin (.so or .dylib)')
    binaries = {path.name: fingerprint(path) for path in (
        producer, plugins[0],
        BUILD / 'bin/libluisa-tile-bridge-xir.dylib',
        BUILD / 'bin/libluisa-tile.dylib',
        BUILD / 'bin/libluisa-xir.dylib')}
    tool_paths = dict(build_cxx=Path(compiler_lines[0]),
                      llvm_clangxx=Path('/opt/homebrew/opt/llvm/bin/clang++'),
                      llvm_config=Path('/opt/homebrew/opt/llvm/bin/llvm-config'),
                      llvm_nm=Path('/opt/homebrew/opt/llvm/bin/llvm-nm'))
    tools = {}
    for name, path in tool_paths.items():
        tools[name] = fingerprint(path)
        stdout, stderr = command([str(path), '--version'])
        member = '_provenance/' + name + '-version.raw'
        generated[member], generated[member + '.stderr'] = stdout, stderr
        tools[name].update(version_stdout_member=member, version_stderr_member=member + '.stderr')

    inventory = {}
    for name, (path, origin) in sorted(files.items()):
        inventory[name] = dict(origin=origin, original_path=str(path), bytes=path.stat().st_size, sha256=sha(path))
    for name, data in sorted(generated.items()):
        safe_name(name)
        require(name not in inventory, 'duplicate generated archive member: ' + name)
        inventory[name] = dict(origin='raw_read_only_command_output', bytes=len(data), sha256=digest_bytes(data))
    with archive_path.open('xb') as output:
        with gzip.GzipFile(filename='', mode='wb', fileobj=output, compresslevel=9, mtime=int(started)) as compressed:
            with tarfile.open(mode='w', fileobj=compressed) as archive:
                for name, record in sorted(inventory.items()):
                    data = files[name][0].read_bytes() if name in files else generated[name]
                    require(len(data) == record['bytes'] and digest_bytes(data) == record['sha256'],
                            'source changed while archiving: ' + name)
                    info = tarfile.TarInfo(safe_name(name))
                    info.size, info.mtime, info.mode = len(data), int(started), 0o644
                    archive.addfile(info, io.BytesIO(data))
    for name, (path, _) in files.items():
        require(sha(path) == inventory[name]['sha256'], 'source changed during freeze: ' + str(path))
    require({name: sha(ROOT / name) for name in owned} == owned_hashes,
            'main owned source changed during freeze, including untracked contents')
    for label, argv in git_commands:
        stdout, stderr = command(argv, ROOT)
        record = git_records[label]
        require(stdout == generated[record['stdout_member']] and stderr == generated[record['stderr_member']],
                'scoped repository state changed during freeze: ' + label)
    for record in (*binaries.values(), *tools.values()):
        require(fingerprint(Path(record['path']))['sha256'] == record['sha256'], 'binary/tool changed during freeze')
    require(sha(ROOT / ABI_HEADER) == abi_hash, 'main ABI header changed during freeze')
    capture_not_started()
    metadata = dict(
        format='attention-joint-copy-mma-source-freeze-v1', started_unix=started, frozen_unix=time.time(),
        platform=platform.platform(), main_head=main_head, main_root=str(ROOT), isolated_source=str(SOURCE),
        selected_build=str(BUILD), intended_stage='after build/tests; before first capture',
        observed_capture_markers_at_freeze=False, git_records=git_records,
        selection=dict(isolated_paths=ISOLATED_PATHS, extra_owned_paths=owned, main_paths=MAIN_PATHS),
        owned_source_sha256=owned_hashes, plan_sha256=sha(OUT / 'plan.json'),
        source_state='Actual selected isolated source plus explicitly selected main replay files; not a full main HEAD export.',
        source_inventory=inventory, source_sha256={name: record['sha256'] for name, record in sorted(inventory.items())},
        source_archive_sha256=sha(archive_path), source_archive_bytes=archive_path.stat().st_size,
        main_isolated_abi_equality=dict(path=ABI_HEADER, main_sha256=abi_hash, isolated_sha256=abi_hash),
        binary_fingerprints=binaries, tool_fingerprints=tools, validation_members=validation_files,
        excluded_observed_paths=excluded,
        limitations=[
            'Source hashes describe actual selected bytes, not their equality to every main HEAD file or every linked dependency.',
            'Unrelated main working-tree bytes are not substituted for the selected compiler export. The exact 52 owned files agree across main, selected source and the successful gate; other compiler bytes are the actual selected export, not a claimed full-HEAD snapshot.',
            'Scoped Git diff/status are raw byte streams and do not encode untracked contents; the source inventory contains the selected untracked files themselves.',
            'Producer and SIMD plugin/tool binaries are fingerprinted, not included as a complete dynamic-loader dependency closure or reproducible-build attestation.',
            'Build configuration and every historical validation attempt are archived verbatim. Only the two plan-selected build/test records must be green; failed/negative historical attempts remain failed, and no test is rerun here.',
            'Freeze chronology must be checked against subsequent capture timestamps; no capture/replay or native benchmark is run here.',
            'This records neither a quiescent/isolated host nor a calibrated timing model; user and system background CPU activity is outside this source freeze.',
            'Native contiguous copy is an opt-in compiler realization, not a handwritten attention replacement. Transfer orientation, private interleaving and code/clone admission may change. Matched copy and specialization edges must independently verify equal snapshot capacity and bitwise outputs; across MMA choices capacity and reduction bits may change, with each arm checked against the independent FP64 reference; the source archive alone is not runtime evidence.',
        ])
    with manifest_path.open('x') as output:
        json.dump(metadata, output, indent=2, allow_nan=False)
        output.write('\n')
    print(json.dumps(dict(source_archive=str(archive_path), source_members=len(inventory),
                          source_bytes=archive_path.stat().st_size, source_sha256=sha(archive_path),
                          provenance=str(manifest_path), provenance_sha256=sha(manifest_path),
                          frozen_unix=metadata['frozen_unix']), indent=2))


if __name__ == '__main__':
    freeze()

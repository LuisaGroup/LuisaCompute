"""Read-only offline audit of the fresh joint attention matrix.

Run after every replay finishes, with NumPy available. This does not import
run.py, open historical build/tool paths, or load/execute a native artifact.
It checks frozen local controls/gates, complete prepared artifact inventories,
30 captures, 30 independent paired cohorts, and each complete output against an
independent dense FP64 oracle. Binary/tool fingerprints outside this directory
are receipts, not a loader-closure attestation or reproducible-build proof.
"""
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import statistics as stats

os.environ.update(OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1')
import numpy as np

ROOT = Path(__file__).resolve().parent
CASES = (
    ('decode-mha-d64', (1, 8, 8, 1, 2048, 64, 64), (1, 16), 0, False),
    ('decode-gqa-d80', (1, 8, 2, 1, 2053, 80, 96), (1, 16), 8, False),
    ('decode-long-kv', (1, 16, 4, 1, 8193, 128, 128), (1, 16), 8, False),
    ('prefill-q4', (1, 4, 2, 32, 65, 32, 32), (4, 16), 0, True),
    ('prefill-q8', (1, 4, 2, 64, 129, 32, 48), (8, 16), 0, True),
    ('batch-gqa-q4', (2, 6, 2, 17, 67, 40, 48), (4, 16), 8, True))
VARIANTS = (('m0-c0', 0, 0, False), ('m0-c4', 0, 4, False),
            ('m4-c0', 4, 0, False), ('m4-c4', 4, 4, False), ('m4-c4-simplified', 4, 4, True))
EDGES = (('copy-m0', 'm0-c0', 'm0-c4', 'copy'), ('copy-m4', 'm4-c0', 'm4-c4', 'copy'),
         ('mma-c0', 'm0-c0', 'm4-c0', 'mma'), ('mma-c4', 'm0-c4', 'm4-c4', 'mma'),
         ('simplified-m4-c4', 'm4-c4', 'm4-c4-simplified', 'specialization'))
TESTS = ('test_simd_schedule_ir', 'test_simd_llvm_schedule_codegen', 'test_simd_xir_to_schedule',
         'test_simd_warp_uniformity', 'test_tile_dsl', 'test_tile_xir_target_info',
         'test_tile_xir_runtime', 'test_tile_xir_llm', 'test_xir_verifier', 'test_xir_interchange', 'test_xir_passes')
PHYSICAL = ('static_snapshot_bytes_per_worker', 'static_snapshot_allocations', 'interleaved_private_arrays',
            'full_packet_specializations', 'full_packet_cloned_instructions', 'native_mmas',
            'native_contraction_mmas', 'native_output_mmas', 'native_copies', 'full_packet_source_instructions',
            'full_packet_candidate_instructions', 'full_packet_simplification_rounds')
ATOL = RTOL = 5e-5
COMMANDS = set()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def safe(relative):
    p = PurePosixPath(relative)
    require(type(relative) is str and relative and not p.is_absolute() and '..' not in p.parts
            and '\\' not in relative and '\x00' not in relative, 'unsafe path: ' + repr(relative))
    current = ROOT
    for part in p.parts:
        current /= part
        require(not current.is_symlink(), 'symlinked artifact: ' + relative)
    require(current.is_file() and current.resolve().is_relative_to(ROOT), 'missing/escaped artifact: ' + relative)
    return current


def sha(relative):
    with safe(relative).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def unique(pairs):
    out = {}
    for k, v in pairs:
        require(k not in out, 'duplicate JSON key: ' + k)
        out[k] = v
    return out


def load(relative):
    value = json.loads(safe(relative).read_text(), object_pairs_hook=unique,
                       parse_constant=lambda x: require(False, 'nonfinite JSON: ' + x))
    def finite(item):
        if isinstance(item, float):
            require(math.isfinite(item), 'nonfinite JSON number')
        elif isinstance(item, dict):
            for child in item.values():
                finite(child)
        elif isinstance(item, list):
            for child in item:
                finite(child)
    finite(value)
    return value


def historical_relative(path):
    # /tmp and /private/tmp are the same original experiment on macOS. Do not
    # resolve the historical path on the current machine when auditing a copy.
    parts = PurePosixPath(path).parts
    marker = 'luisa-attention-joint-repack.ucXtia'
    require(parts.count(marker) == 1, 'unmapped historical path: ' + path)
    relative = PurePosixPath(*parts[parts.index(marker) + 1:]).as_posix()
    safe(relative)
    return relative


def field(text, name, kind='int'):
    token = '(true|false)' if kind == 'bool' else '([a-z_]+)' if kind == 'enum' else r'(\d+)'
    values = re.findall(r'\b' + re.escape(name) + '=' + token + r'\b', text)
    require(len(values) == 1, 'missing/duplicate realization field: ' + name)
    return values[0] == 'true' if kind == 'bool' else values[0] if kind == 'enum' else int(values[0])


def command(relative, timeout, expected_env=None):
    c, r = load(relative + '.command.json'), load(relative + '.result.json')
    require(r.get('returncode') == 0 and 'error' not in r, 'failed command: ' + relative)
    require(r.get('timed_out') is False and r.get('termination_reason') == 'process_exited', 'timing command did not exit normally')
    require(all(r.get(k) == v for k, v in c.items()), 'command/result receipt drift')
    require(c['timeout_s'] == timeout and c['process_group_isolated'] is True, 'supervision drift')
    require(math.isfinite(c['started']) and r['finished'] >= c['started'], 'invalid chronology')
    require(safe(relative + '.stderr').stat().st_size == 0, 'stderr needs explicit review: ' + relative)
    if expected_env is not None:
        require(c['environment'] == expected_env, 'capture environment differs: ' + relative)
    COMMANDS.add(relative + '.command.json')
    return c, r


def array(relative, shape, dtype):
    path = safe(relative)
    require(path.stat().st_size == math.prod(shape) * np.dtype(dtype).itemsize, 'tensor byte extent mismatch')
    result = np.fromfile(path, dtype=dtype).reshape(shape)
    require(np.isfinite(result).all(), 'nonfinite tensor: ' + relative)
    return result


def metadata(case, variant, prepared):
    name, dims, block, cap, two_d = case
    arm, mma, copy, simple = variant
    m, text = prepared['metadata'], prepared['metadata']['realization']
    require(m['dimensions'] == list(dims) and m['attention_block'] == list(block), 'shape/block drift')
    for k, v in dict(implementation='tile_xir_simd', operation='attention', precision='fp32',
                     fast_math=False, relaxed_precision=False, attention_qk='mma', attention_pv='mma',
                     source_reduction_policy='unordered_tree', source_kind='tile_lowering_source').items():
        require(type(m.get(k)) is type(v) and m[k] == v, 'math/source drift: ' + k)
    require(re.findall(r'\bW(\d+), (\d+) workers/block\b', text) == [('8', '32')], 'packet/block drift')
    for k, v in dict(local_lanes=1, max_unrolled_tile_elements=64, max_unrolled_region_work=4096,
                     requested_mma_output_block=4, requested_max_unrolled_mma_terms=cap,
                     native_mma_vector_width=mma, native_copy_vector_width=copy).items():
        require(field(text, k) == v, 'realization drift: ' + k)
    require(field(text, 'requested_mma_2d_blocking', 'bool') is two_d, '2D request drift')
    require(field(text, 'full_packet_simplification_requested', 'bool') is simple, 'simplified request drift')
    p = {k: field(text, k) for k in PHYSICAL}
    decision = field(text, 'full_packet_specialization_decision', 'enum')
    require(decision in ('ineligible', 'source_budget_exceeded', 'candidate_budget_exceeded', 'legacy_selected', 'simplified_selected'), 'unexpected specialization decision')
    require(decision != ('legacy_selected' if simple else 'simplified_selected'), 'wrong specialization algorithm')
    require(p['full_packet_simplification_rounds'] <= 4 and (simple or p['full_packet_simplification_rounds'] == 0), 'round drift')
    if decision == 'simplified_selected':
        require(p['full_packet_source_instructions'] <= 8192 and p['full_packet_candidate_instructions'] <= 4096, 'candidate budget drift')
        require(1 <= p['full_packet_simplification_rounds'] <= 4, 'selected simplified candidate was not simplified')
    if decision == 'legacy_selected':
        require(p['full_packet_source_instructions'] <= 4096, 'legacy budget drift')
    if decision == 'source_budget_exceeded':
        require(p['full_packet_source_instructions'] > (8192 if simple else 4096), 'source budget rejection has no excess')
    require([p[k] for k in ('native_mmas', 'native_contraction_mmas', 'native_output_mmas')] == ([2, 1, 1] if mma else [0, 0, 0]), 'native MMA count drift')
    require((p['native_copies'] == 0) if not copy else (1 <= p['native_copies'] <= 3), 'native copy count drift')
    orders = re.findall(r'\broot order \[([0-9]+(?:\s*,\s*[0-9]+)*)\]', text)
    require(len(orders) == 1, 'missing root order')
    order = [int(x) for x in orders[0].split(',')]
    require(sorted(order) == list(range(len(order))), 'invalid root order')
    require(prepared['packet_width'] == 8 and prepared['block'] == [32, 1, 1]
            and prepared['dispatch'] == m['dispatch'], 'entry geometry drift')
    require(prepared['workspace_bytes'] == field(text, 'private_workspace_bytes'), 'workspace ABI differs from realization')
    require(prepared['input_files'] == ['input0.f32', 'input1.f32', 'input2.f32'], 'Q/K/V buffer ABI differs')
    require(prepared['atol'] == ATOL and prepared['rtol'] == RTOL, 'tolerance drift')
    return dict(physical=p, specialization_decision=decision, workspace_bytes=prepared['workspace_bytes'],
                abi=prepared['abi'], symbol=prepared['symbol'],
                execution=dict(root_order=order, blocks_per_task=field(text, 'blocks_per_task')))


def llvm_accounting(directory, realization):
    # Compiler prints this module before LLVMJIT::add_module/_prepare_module:
    # it is pre-O1/O2, but an admitted .full_packet body already has the local
    # four-round candidate simplification. Counts are function-local, not
    # inlined helper/module totals or final machine instruction counts.
    text = safe(directory + '/kernel.ll').read_text()
    bodies = {}
    for match in re.finditer(r'^define ([^\n]*)@([-a-zA-Z$._0-9]+)\([^\n]*\) [^\n]*\{\n(.*?)^\}', text, re.M | re.S):
        name, body = match[2], match[3]
        require(name not in bodies, 'duplicate LLVM definition')
        lines, in_switch = [], False
        for line in body.splitlines():
            if not line.startswith('  ') or line.lstrip().startswith(';'):
                continue
            if in_switch:
                if line == '  ]':
                    in_switch = False
                else:
                    require(re.fullmatch(r'    i\d+ -?\d+, label %[-a-zA-Z$._0-9]+', line), 'unrecognized LLVM switch case')
                continue
            require(re.match(r'^  (?:%[^ ]+ = |(?:br|ret|store|call|unreachable|switch)\b)', line),
                    'unrecognized/multiline LLVM instruction; require explicit audit extension')
            in_switch = line.startswith('  switch ')
            require(not in_switch or line.endswith(' ['), 'unexpected switch format')
            lines.append(line)
        require(not in_switch, 'unterminated LLVM switch')
        bodies[name] = dict(instructions=len(lines), calls=re.findall(r'\bcall\b[^\n]*@([-a-zA-Z$._0-9]+)\(', body))
    require('llm_attention' in bodies, 'missing original packet entry')
    exports = re.findall(r'^define dso_local void @([-a-zA-Z$._0-9]+\.packet_batch(?:\.blocks)?)\(', text, re.M)
    blocks = [name for name in exports if name.endswith('.blocks')]
    entries = blocks or exports
    require(len(entries) == 1 and realization['symbol'] == entries[0] and realization['abi'] == (0 if blocks else 2),
            'prepared entry symbol/ABI differs from actual LLVM wrapper definition')
    p, decision = realization['physical'], realization['specialization_decision']
    original = bodies['llm_attention']['instructions']
    if decision == 'ineligible':
        require(p['full_packet_source_instructions'] == p['full_packet_candidate_instructions'] == p['full_packet_simplification_rounds'] == 0,
                'ineligible entry unexpectedly inspected a candidate')
    else:
        require(p['full_packet_source_instructions'] == original, 'raw source instruction count differs from dumped original entry')
    selected = decision in ('legacy_selected', 'simplified_selected')
    require(('llm_attention.full_packet' in bodies) == selected, 'clone decision differs from retained function')
    require(p['full_packet_specializations'] == int(selected), 'specialization count differs from actual clone')
    require(p['full_packet_cloned_instructions'] == (original if selected else 0), 'historical raw clone count changed meaning')
    if selected:
        require(bodies['llm_attention.full_packet']['instructions'] == p['full_packet_candidate_instructions'],
                'candidate count differs from retained pre-target-pipeline clone')
        require(any('llm_attention.full_packet' in body['calls'] for name, body in bodies.items() if name != 'llm_attention.full_packet'),
                'admitted clone is not called by any retained wrapper')
    else:
        require(all('llm_attention.full_packet' not in body['calls'] for body in bodies.values()), 'rejected candidate leaves a dangling call')
        if decision == 'source_budget_exceeded':
            require(p['full_packet_candidate_instructions'] == 0 and p['full_packet_simplification_rounds'] == 0,
                    'source-rejected candidate should not have been created')
            require(original > 4096, 'source-budget rejection has no raw budget excess')
        if decision == 'candidate_budget_exceeded':
            require(p['full_packet_candidate_instructions'] > 4096, 'candidate rejection has no budget excess')
    copies = [name for name in bodies if re.fullmatch(r'llm_attention\.contiguous_copy(?:\.\d+)?', name)]
    require(len(copies) == p['native_copies'], 'copy metadata differs from actual private helper definitions')
    require(all(name in bodies['llm_attention']['calls'] for name in copies), 'copy helper is absent from original entry')
    return dict(dump_stage='pre-target-O1/O2; admitted clone locally simplified before dump',
                original_instructions=original, retained_candidate_instructions=bodies.get('llm_attention.full_packet', {}).get('instructions'),
                copy_helpers=copies, rejected_candidate_count_scope='metadata only; rejected provisional body is intentionally erased',
                definitions={name: body['instructions'] for name, body in bodies.items()})


def prepared_commands(directory, manifest, frozen):
    tools = {PurePosixPath(path).name: (path, digest) for path, digest in manifest['tool_sha256'].items()}
    require(set(tools) == {'clang++', 'llvm-nm'} and len(tools) == len(manifest['tool_sha256']), 'prepared tool inventory differs')
    for name, (path, digest) in tools.items():
        expected = {h for p, h in frozen.items() if PurePosixPath(p).name == name}
        require(expected == {digest}, 'prepared tool differs from frozen fingerprint: ' + name)
    cc, nm = tools['clang++'][0], tools['llvm-nm'][0]
    link = load(directory + '/link.command.json')
    historical = str(PurePosixPath(link['argv'][2]).parent)
    require(historical_relative(historical + '/prepared.json') == directory + '/prepared.json', 'link directory drift')
    expected = dict(imports=[nm, '--undefined-only', '--just-symbol-name', historical + '/kernel.o'],
                    exports=[nm, '--defined-only', '--extern-only', '--just-symbol-name', historical + '/kernel.o'],
                    compiler=[cc, '--version'],
                    link=[cc, '-dynamiclib', historical + '/kernel.o', '-o', historical + '/kernel.dylib'],
                    helper=[cc, '-std=c++20', '-O3', '-dynamiclib', '-I' + historical,
                            historical + '/native_tile_replay.cpp', '-o', historical + '/replay.dylib'])
    for stem, argv in expected.items():
        receipt = directory + '/' + stem + '.command.json'
        require(load(receipt) == dict(argv=argv, returncode=0), 'internal preparation command drift: ' + receipt)
        require(safe(directory + '/' + stem + '.stderr').stat().st_size == 0, 'internal stderr needs review: ' + receipt)
        safe(directory + '/' + stem + '.stdout')
        COMMANDS.add(receipt)
    require('_' + manifest['symbol'] in safe(directory + '/exports.stdout').read_text().split(), 'actual ORC exported entry missing')
    require(set(safe(directory + '/imports.stdout').read_text().split()) <= {'_memcpy', '_memset', '_bzero', '___chkstk_darwin'}, 'unexpected object import')
    for relative, suffix in (
            ('native_tile.py', '/scripts/benchmark/tile_torch/native_tile.py'),
            ('native_tile_replay.cpp', '/scripts/benchmark/tile_torch/native_tile_replay.cpp'),
            ('backends/simd/llvm/llvm_schedule_codegen.h', '/src/backends/simd/llvm/llvm_schedule_codegen.h')):
        expected_hashes = {digest for path, digest in frozen.items() if path.endswith(suffix)}
        require(expected_hashes == {manifest['files'][relative]}, 'prepared helper/runner/ABI differs from frozen files')


def main():
    plan, declared = load('plan.json'), load('predeclared.json')
    require(plan['controls'] == declared, 'plan/predeclared controls drift')
    require(declared['cases'] == [dict(case=n, dimensions=list(d), block=list(b), cap=c, two_dimensional=t) for n, d, b, c, t in CASES], 'case inventory drift')
    require(declared['variants'] == [dict(name=n, native_mma_vector_width=m, native_copy_vector_width=c, simplified_full_packet_specialization=p) for n, m, c, p in VARIANTS], 'variant inventory drift')
    require(declared['edges'] == [dict(name=n, baseline=a, candidate=b, kind=k) for n, a, b, k in EDGES], 'edge inventory drift')
    require([declared[k] for k in ('captures', 'pair_replays', 'visits', 'samples')] == [30, 30, 360, 2520], 'cohort counts drift')
    local_frozen = {}
    frozen = plan['identities']['files_sha256']
    for path, digest in frozen.items():
        if 'luisa-attention-joint-repack.ucXtia' in PurePosixPath(path).parts:
            relative = historical_relative(path)
            require(sha(relative) == digest, 'frozen local file changed: ' + relative)
            local_frozen[relative] = digest
    require(set(('run.py', 'audit.py', 'predeclared.json', 'gate.py', 'owned.txt')).issubset(local_frozen), 'missing frozen harness files')
    producers = [p for p in frozen if p.endswith('/bin/benchmark_tile_xir')]
    runners = [p for p in frozen if p.endswith('/scripts/benchmark/tile_torch/native_tile.py')]
    require(len(producers) == len(runners) == 1, 'frozen producer/runner identity ambiguous')
    producer, runner = producers[0], runners[0]
    source = plan['identities']['owned_source_sha256']
    require(source == plan['identities']['selected_source_sha256'], 'main/selected source identity differs')
    gates = []
    for filename in (plan['build_gate'], plan['test_gate']):
        gate = load(filename)
        require(gate['returncode'] == 0 and gate['source_unchanged'] is True and gate['source_sha256'] == source, 'invalid gate')
        require(gate['log_sha256'] == sha(str(Path(filename).with_suffix('.log'))), 'gate log changed')
        require(gate['finished'] >= gate['started'], 'gate chronology')
        gates.append(gate)
    build, test = gates
    require(build['command'] == ['cmake', '--build', build['build'], '-j', '6'], 'not a full selected build')
    require(test['build'] == build['build'] and test['selected_source'] == build['selected_source'], 'gate tree drift')
    require(test['command'] == ['ctest', '--test-dir', build['build'], '--output-on-failure', '-R', '^(' + '|'.join(TESTS) + ')$'], 'test inventory drift')
    require(test['started'] >= build['finished'] and plan['frozen_unix'] >= test['finished'], 'build/test/freeze chronology')
    require(re.search(r'100% tests passed(?:, 0 tests failed)? out of 11\b', safe(str(Path(plan['test_gate']).with_suffix('.log'))).read_text()), 'incomplete CTest gate')
    captures, replays = load('captures.json'), load('replays.json')
    plan_hash = sha('plan.json')
    require(captures['status'] == replays['status'] == 'complete' and captures['plan_sha256'] == replays['plan_sha256'] == plan_hash, 'incomplete/drifted cohort')
    require([r['case'] for r in captures['cases']] == [n for n, *_ in CASES], 'capture inventory drift')
    require([(r['case'], r['edge']) for r in replays['experiments']] == [(n, e) for n, *_ in CASES for e, *_ in EDGES], 'replay inventory drift')
    report = dict(status='passed', plan_sha256=plan_hash, captures=30, pair_replays=30, visits=360, samples=2520,
                  metric='single_thread_native_entry_host_wall_us', captures_checked=[], comparisons=[], llvm_accounting=[],
                  boundary=declared['boundary'], limitations=[
                      'No native execution in this audit. External binary/tool hashes are receipts, not a loader closure or a reproduced build.',
                      'Source archive/package inventory must be audited separately; this minimal audit checks the frozen local harness/gate receipts and prepared artifacts.',
                      'Each edge is a separate matched ABBA cohort. No cross-edge timing ratios or aggregate best-arm/parity claim.',
                      'Guard/oracle checkpoints follow preflight, warmup, calibration and each sample batch, not every timed invoke.',
                      'Same-MMA copy/specialization pairs require bitwise equality; cross-MMA only retained-input numerical tolerance is required.',
                      'Observed min/max is not a confidence interval. Background work and host affinity were not controlled.'])
    prepared = {}
    launcher = plan['python_launcher']
    require(launcher in frozen and PurePosixPath(launcher).name.startswith('python'), 'Python launcher is not fingerprinted')
    last_prepare = plan['frozen_unix']
    for case, row in zip(CASES, captures['cases']):
        name, dims, block, cap, two_d = case
        require(row['status'] == 'OK' and [r['label'] for r in row['variants']] == [name + '-' + v[0] for v in VARIANTS], 'incomplete capture case')
        observed = {}
        for variant, receipt in zip(VARIANTS, row['variants']):
            arm, mma, copy, simple = variant
            label, directory = name + '-' + arm, 'prepared-' + name + '-' + arm
            manifest = load(directory + '/prepared.json')
            require(sha(directory + '/prepared.json') == receipt['prepared_manifest_sha256'], 'prepared receipt changed')
            require(manifest['status'] == 'prepared' and manifest['format'] == 'native-tile-entry-v1'
                    and manifest['capture_kind'] == 'llm' and manifest['name'] == arm, 'invalid prepared entry')
            for relative, digest in manifest['files'].items():
                require(sha(directory + '/' + relative) == digest, 'prepared artifact changed: ' + relative)
            require(set(('kernel.o', 'kernel.dylib', 'kernel.ll', 'native_tile.py', 'native_tile_replay.cpp',
                         'backends/simd/llvm/llvm_schedule_codegen.h', 'replay.dylib', 'expected.f64',
                         'captured.f32', 'input0.f32', 'input1.f32', 'input2.f32')).issubset(manifest['files']), 'incomplete prepared inventory')
            prepared_commands(directory, manifest, frozen)
            cc, cr = command(label + '/capture', 180)
            pc, pr = command(label + '/prepare', 180)
            require(cc['started'] >= plan['frozen_unix'] and pc['started'] >= cr['finished'], 'capture/prepare chronology')
            env = cc['environment']
            for k, v in dict(LUISA_TILE_BENCH_XIR_BACKEND='simd', LUISA_TILE_BENCH_ATTENTION_QK='mma',
                             LUISA_TILE_BENCH_ATTENTION_PV='mma', LUISA_TILE_BENCH_XIR_MMA_OUTPUT_BLOCK='4',
                             LUISA_TILE_BENCH_XIR_MMA_UNROLL_TERMS=str(cap), LUISA_TILE_BENCH_XIR_MMA_2D_BLOCKING='1' if two_d else '0',
                             LUISA_TILE_BENCH_XIR_BLOCK_SIZE='32', LUISA_TILE_BENCH_XIR_LOCAL_LANES='1',
                             LUISA_TILE_BENCH_XIR_REGION_WORK='4096', LUISA_SIMD_NATIVE_MMA_VECTOR_WIDTH=str(mma),
                             LUISA_SIMD_NATIVE_COPY_VECTOR_WIDTH=str(copy), LUISA_SIMD_ENABLE_FULL_PACKET_SPECIALIZATION='1',
                             LUISA_SIMD_ENABLE_SIMPLIFIED_FULL_PACKET_SPECIALIZATION='1' if simple else '0',
                             OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1').items():
                require(env.get(k) == v, 'capture flag drift: ' + k)
            argv = cc['command']
            require(argv[0] == producer, 'capture producer differs from frozen producer')
            require(argv[1:-1] == ['llm', 'attention', ','.join(map(str, dims)), *map(str, block), '3', '1', '1'], 'capture argv drift')
            require(historical_relative(argv[-1]) == label + '/output.f32', 'capture output drift')
            prefix = argv[-1]
            require(env['LUISA_TILE_BENCH_DUMP_SOURCE'] == prefix + '.source.txt'
                    and historical_relative(env['LUISA_SIMD_DUMP_ASSEMBLY_DIR'] + '/' + next((ROOT / label / 'objects').glob('*.o')).name).startswith(label + '/objects/'), 'capture dump paths drift')
            require(load(label + '/capture.stdout') == manifest['metadata'], 'prepared/capture metadata drift')
            require(sha(label + '/output.f32') == manifest['files']['captured.f32'], 'prepared output differs from capture')
            require(sha(label + '/output.f32.source.txt') == manifest['files']['kernel.ll'], 'source copy differs from capture')
            objects = [p for p in (ROOT / label / 'objects').glob('*.o')]
            require(len(objects) == 1 and sha(objects[0].relative_to(ROOT).as_posix()) == manifest['files']['kernel.o'], 'not the actual single ORC object')
            require(pc['command'][0] == launcher, 'Python launcher receipt changed')
            require(pc['command'][1:10] == [runner, 'prepare', '--capture-kind', 'llm', '--llvm', plan['llvm'], '--prefix', prefix, '--log'], 'prepare command drift')
            require(pc['command'][11] == '--objects' and pc['command'][13] == '--output'
                    and pc['command'][15:] == ['--name', arm], 'prepare argv tail drift')
            require(historical_relative(pc['command'][10]) == label + '/capture.stdout', 'prepare log differs from captured log')
            require(pc['command'][12] == env['LUISA_SIMD_DUMP_ASSEMBLY_DIR'] and historical_relative(pc['command'][14] + '/prepared.json') == directory + '/prepared.json', 'prepare artifact paths drift')
            require(pc['environment'] == dict(OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1'), 'prepare environment drift')
            require(pr['finished'] >= manifest['finished_unix'] >= manifest['started_unix'] >= pc['started'], 'prepare manifest chronology')
            last_prepare = max(last_prepare, pr['finished'])
            item = metadata(case, variant, manifest)
            report['llvm_accounting'].append(dict(case=name, variant=arm, **llvm_accounting(directory, item)))
            require(receipt['execution_controls'] == item['execution'] and receipt['realization'] == manifest['metadata']['realization'], 'capture aggregate drift')
            item['captured_output_sha256'] = manifest['files']['captured.f32']
            observed[arm] = item
            prepared[(name, arm)] = (directory, manifest)
        base_dir, base = prepared[(name, 'm0-c0')]
        b, h, kh, q, keys, d, dv = dims
        shapes = ((b, h, q, d), (b, kh, keys, d), (b, kh, keys, dv))
        query, key, value = [array(base_dir + f'/input{i}.f32', shape, '<f4').astype(np.float64) for i, shape in enumerate(shapes)]
        key, value = np.repeat(key, h // kh, axis=1), np.repeat(value, h // kh, axis=1)
        scale = float(np.float32(1) / np.sqrt(np.float32(d)))
        score = np.einsum('bhqd,bhkd->bhqk', query, key, optimize=False) * scale
        mask = np.arange(keys)[None, :] <= np.arange(q)[:, None] + keys - q
        score = np.where(mask, score, -1e30)
        weights = np.where(mask, np.exp(score - score.max(axis=-1, keepdims=True)), 0)
        expected = np.einsum('bhqk,bhkv->bhqv', weights / weights.sum(axis=-1, keepdims=True), value, optimize=False)
        original_expected = array(base_dir + '/expected.f64', expected.shape, '<f8')
        require(np.allclose(original_expected, expected, atol=1e-12, rtol=1e-12), 'independent FP64 oracle differs')
        for arm, *_ in VARIANTS:
            directory, manifest = prepared[(name, arm)]
            for relative in ('input0.f32', 'input1.f32', 'input2.f32', 'expected.f64', 'native_tile.py',
                             'native_tile_replay.cpp', 'backends/simd/llvm/llvm_schedule_codegen.h'):
                require(base['files'][relative] == manifest['files'][relative], 'input/oracle/helper differs')
            for key in ('packet_width', 'block', 'dispatch', 'tool_sha256', 'atol', 'rtol'):
                require(base[key] == manifest[key], 'launch/helper contract differs')
            out = array(directory + '/captured.f32', expected.shape, '<f4').astype(np.float64)
            error = np.abs(out - expected)
            require(np.all(error <= ATOL + RTOL * np.abs(expected)), 'full FP64 capture mismatch')
            require(manifest['output_elements'] == expected.size, 'output extent metadata differs')
            observed[arm]['max_abs_error'] = float(error.max())
        require(row['correctness']['variants'] == observed, 'independent capture summary differs')
        for edge, left, right, kind in EDGES:
            a, b = observed[left], observed[right]
            bitwise = a['captured_output_sha256'] == b['captured_output_sha256']
            require(row['correctness']['edge_checks'][edge] == dict(kind=kind, bitwise_equal=bitwise, bitwise_required=kind != 'mma'), 'edge numerical contract differs')
            if kind != 'mma':
                require(bitwise and a['abi'] == b['abi'] and a['symbol'] == b['symbol'] and a['execution'] == b['execution'], 'same-MMA exact contract changed')
                for key in ('static_snapshot_bytes_per_worker', 'static_snapshot_allocations'):
                    require(a['physical'][key] == b['physical'][key], 'same-MMA capacity differs')
        report['captures_checked'].append(dict(case=name, variants=observed))
    require(replays['started'] >= last_prepare, 'replay began before all captures/preparations completed')
    for row in replays['experiments']:
        name, edge = row['case'], row['edge']
        _, baseline, candidate, kind = next(e for e in EDGES if e[0] == edge)
        require(row['status'] == 'OK' and row['kind'] == kind, 'incomplete replay edge')
        directory = 'replay-' + name + '-' + edge
        c, r = command(directory, 120)
        result = load(directory + '/results.json')
        require(sha(directory + '/results.json') == row['results_sha256'], 'replay result changed')
        require(c['started'] >= last_prepare and r['finished'] >= result['finished_unix'] >= result['started_unix'] >= c['started'], 'replay chronology')
        require(c['command'][:4] == [launcher, runner, 'replay', '--prepared'] and
                c['command'][5] == '--prepared' and c['command'][7] == '--output' and
                c['command'][9:] == ['--cycles', '3', '--samples', '7', '--warmup-ms', '30', '--target-ms', '15'], 'replay command drift')
        require([historical_relative(c['command'][i]) for i in (4, 6)] ==
                [prepared[(name, arm)][0] + '/prepared.json' for arm in (baseline, candidate)], 'replay command entry order drift')
        require(historical_relative(c['command'][8] + '/results.json') == directory + '/results.json', 'replay output drift')
        require(c['environment'] == dict(OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1'), 'replay environment drift')
        require(result['status'] == 'passed' and result['artifacts_unchanged'] is True and result['metric'] == report['metric'], 'invalid replay status/metric')
        require(result['cpu_threads'] == 1 and result['order_policy'] == 'ABBA per cycle; two matched pairs per cycle', 'timing policy drift')
        for k, v in dict(cycles=3, samples=7, warmup_ms=30, target_ms=15, validate_only=False).items():
            require(result['options'][k] == v, 'replay control drift')
        require([historical_relative(p) for p in result['options']['prepared']] == [prepared[(name, v)][0] + '/prepared.json' for v in (baseline, candidate)], 'replay arm/order drift')
        require({historical_relative(p): digest for p, digest in result['prepared_sha256'].items()} ==
                {prepared[(name, v)][0] + '/prepared.json': sha(prepared[(name, v)][0] + '/prepared.json') for v in (baseline, candidate)}, 'prepared replay identity drift')
        require(result['runner_sha256'] == prepared[(name, baseline)][1]['files']['native_tile.py'], 'runner differs from prepared source')
        visits = result['visits']
        require(len(visits) == 12, 'incomplete ABBA visits')
        for i, visit in enumerate(visits):
            arm = (baseline, candidate, candidate, baseline)[i % 4]
            require(visit['cycle'] == i // 4 and visit['position'] == i % 4 and visit['variant'] == arm, 'ABBA order changed')
            require(visit['valid'] is True and visit['returncode'] == 0 and visit['all_guards_passed'] is True and visit['inputs_unchanged'] is True, 'guard/validity failure')
            values = visit['samples_us']
            require(len(values) == 7 and all(type(v) in (int, float) and math.isfinite(v) and v > 0 for v in values)
                    and type(visit['repetitions']) is int and visit['repetitions'] > 0, 'invalid samples/repetitions')
            require(stats.median(values) == visit['median_us'], 'visit median differs')
            manifest = prepared[(name, arm)][1]
            require(sha(directory + '/' + visit['output']) == visit['output_sha256'] == manifest['files']['captured.f32'], 'visit output differs from FP64-checked own capture')
        pairs = [x for c in range(3) for x in (visits[c * 4 + 1]['median_us'] / visits[c * 4]['median_us'], visits[c * 4 + 2]['median_us'] / visits[c * 4 + 3]['median_us'])]
        summary = {arm: stats.median(v['median_us'] for v in visits if v['variant'] == arm) for arm in (baseline, candidate)}
        ratio = dict(baseline=baseline, candidate=candidate, pairs=pairs, median=stats.median(pairs), minimum=min(pairs), maximum=max(pairs))
        require(result['summary_us'] == summary and result['candidate_over_baseline'] == ratio, 'paired statistic differs')
        report['comparisons'].append(dict(case=name, edge=edge, kind=kind, summary_us=summary, candidate_over_baseline=ratio,
                                         all_sample_medians_us={arm: stats.median(x for v in visits if v['variant'] == arm for x in v['samples_us']) for arm in (baseline, candidate)}))
    expected_receipts = {p.relative_to(ROOT).as_posix() for p in ROOT.glob('replay-*.command.json')}
    for name, *_ in CASES:
        for arm, *_ in VARIANTS:
            for directory in (name + '-' + arm, 'prepared-' + name + '-' + arm):
                expected_receipts.update(p.relative_to(ROOT).as_posix() for p in (ROOT / directory).glob('*.command.json'))
    require(COMMANDS == expected_receipts and len(COMMANDS) == 240, 'incomplete/extra preparation and timing command receipt set')
    report['commands_checked'] = len(COMMANDS)
    print(json.dumps(report, indent=2, allow_nan=False))


if __name__ == '__main__':
    main()

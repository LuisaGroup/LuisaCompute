"""Pure-Python pre-execution protocol checks; never load/call native code."""
import ast
import hashlib
import io
import json
import math
from pathlib import Path, PurePosixPath
import re
import runpy
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
driver = runpy.run_path(str(ROOT / 'run.py'), run_name='protocol_inspection_only')
assert driver['controls']() == json.loads((ROOT / 'predeclared.json').read_text())
audit_ast = ast.parse((ROOT / 'audit.py').read_text())
names = {'require', 'safe', 'field', 'llvm_accounting', 'sha', 'unique', 'load', 'prepared_commands'}
pure = ast.Module(body=[n for n in audit_ast.body if isinstance(n, ast.FunctionDef) and n.name in names], type_ignores=[])
old = Path('/tmp/luisa-attention-native-copy.n6RmGZ').resolve()
namespace = dict(Path=Path, PurePosixPath=PurePosixPath, re=re, ROOT=old, hashlib=hashlib, json=json, math=math, COMMANDS=set())
exec(compile(pure, str(ROOT / 'audit.py'), 'exec'), namespace)
def old_relative(path):
    parts = PurePosixPath(path).parts
    marker = 'luisa-attention-native-copy.n6RmGZ'
    assert parts.count(marker) == 1
    relative = PurePosixPath(*parts[parts.index(marker) + 1:]).as_posix()
    namespace['safe'](relative)
    return relative
namespace['historical_relative'] = old_relative
old_plan = json.loads((old / 'plan.json').read_text())
results = []
for path in sorted(old.glob('prepared-*/kernel.ll')):
    manifest = json.loads(path.with_name('prepared.json').read_text())
    namespace['prepared_commands'](path.parent.name, manifest, old_plan['identities']['files_sha256'])
    text = path.read_text()
    functions = re.findall(r'^define ([^\n]*)@([-a-zA-Z$._0-9]+)\([^\n]*\) [^\n]*\{\n(.*?)^\}', text, re.M | re.S)
    counts = {name: len([line for line in body.splitlines() if re.match(r'^  (?:%[^ ]+ = |(?:br|ret|store|call|unreachable|switch)\b)', line)])
              for _, name, body in functions}
    assert 'llm_attention' in counts
    clone = counts.get('llm_attention.full_packet')
    metadata = manifest['metadata']['realization']
    p = {key: namespace['field'](metadata, key) for key in ('full_packet_specializations', 'full_packet_cloned_instructions', 'native_copies')}
    p.update(full_packet_source_instructions=counts['llm_attention'],
             full_packet_candidate_instructions=clone or 0, full_packet_simplification_rounds=0)
    decision = 'legacy_selected' if clone else 'ineligible' if '%scheduler.dispatch.pc' in text else 'source_budget_exceeded'
    if decision == 'ineligible':
        p['full_packet_source_instructions'] = 0
    item = dict(physical=p, specialization_decision=decision, symbol=manifest['symbol'], abi=manifest['abi'])
    checked = namespace['llvm_accounting'](path.parent.name, item)
    assert checked['original_instructions'] == counts['llm_attention']
    results.append(dict(bundle=path.parent.name, original=counts['llm_attention'], clone=clone,
                        copies=len(checked['copy_helpers'])))
assert len(results) == 12
assert len(namespace['COMMANDS']) == 60
fake = dict(physical=dict(p, full_packet_specializations=0, full_packet_cloned_instructions=0,
                         full_packet_source_instructions=0, full_packet_candidate_instructions=0,
                         full_packet_simplification_rounds=0), specialization_decision='ineligible', symbol=manifest['symbol'], abi=manifest['abi'])
# The last historical bundle is q8-on, which has no clone; this exercises
# ineligible metadata without misrepresenting its raw body as zero-sized.
assert path.parent.name == 'prepared-prefill-q8-on'
assert namespace['llvm_accounting'](path.parent.name, fake)['original_instructions'] > 0

# Exercise supervisor bookkeeping entirely in memory. No subprocess, sleep,
# native library, benchmark, signal or filesystem write is performed.
def supervisor_check(timeout):
    receipts, payloads, kills = {}, {}, []
    class MemoryOutput(io.BytesIO):
        def __init__(self, name):
            super().__init__()
            self.name = name
        def __exit__(self, *args):
            payloads[self.name] = self.getvalue()
            self.close()
    class MemoryFile:
        def __init__(self, name):
            self.name = name
        def exists(self):
            return False
        def open(self, mode):
            assert mode == 'xb'
            return MemoryOutput(self.name)
    class MemoryFolder:
        def __truediv__(self, name):
            return MemoryFile(name)
    real_subprocess = driver['run'].__globals__['subprocess']
    class Process:
        pid = 123
        returncode = None
        calls = 0
        def communicate(self, timeout=None):
            self.calls += 1
            if self.calls == 1 and timeout_mode:
                raise real_subprocess.TimeoutExpired(['not-executed'], timeout)
            self.returncode = -9 if timeout_mode else 0
            return b'preserved stdout', b''
        def poll(self):
            return self.returncode
    timeout_mode = timeout
    fake_process = Process()
    def save_memory(path, record):
        assert path.name not in receipts
        receipts[path.name] = json.loads(json.dumps(record))
    replacements = dict(subprocess=SimpleNamespace(Popen=lambda *a, **k: fake_process,
                                                   TimeoutExpired=real_subprocess.TimeoutExpired, PIPE=-1),
                        os=SimpleNamespace(killpg=lambda pid, sig: kills.append((pid, sig))),
                        save=save_memory)
    failed = False
    with patch.dict(driver['run'].__globals__, replacements):
        try:
            driver['run'](['not-executed'], MemoryFolder(), 'probe', timeout=180)
        except ValueError:
            failed = True
    initial, final = receipts['probe.command.json'], receipts['probe.result.json']
    assert final['timed_out'] is timeout and failed is timeout
    assert final['termination_reason'] == ('deadline_exceeded' if timeout else 'process_exited')
    assert all(final[key] == value for key, value in initial.items())
    assert payloads == {'probe.stdout': b'preserved stdout', 'probe.stderr': b''}
    if timeout:
        assert final['error'] == 'timeout; entire isolated process group terminated'
        assert final['raised_exception'] == 'probe: failed; inspect retained logs'
        assert kills == [(123, 9)] and final['returncode'] == -9
    else:
        assert not kills and 'error' not in final and final['returncode'] == 0
    return final['termination_reason']

supervisor_checks = [supervisor_check(False), supervisor_check(True)]
print(json.dumps(dict(status='passed', native_execution=False, frozen=False,
                      controls_match=True, historical_llvm_parser_checks=results,
                      historical_preparation_commands_checked=len(namespace['COMMANDS']),
                      ineligible_zero_metadata_checked=True, in_memory_supervisor_checks=supervisor_checks), indent=2))

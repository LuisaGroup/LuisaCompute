// Artifact-only check of the generated Sphinx report, not user browser control.
const fs = require('node:fs');
const {pathToFileURL} = require('node:url');
const {chromium} = require('/Users/mike/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
(async () => {
    const root = '/tmp/luisa-ranking-map-budget.VSzyKx';
    const browser = await chromium.launch({headless: true, executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});
    const receipts = [];
    for (const width of [1280, 390]) {
        const page = await browser.newPage({viewport: {width, height: 900}, deviceScaleFactor: 1});
        await page.goto(pathToFileURL(root + '/docs-html-final/source/performance/tile/results.html').href);
        for (const id of ['top-k-and-sort-now-have-multi-output-cross-route-coverage', 'attention-priority-contribution-mapping-with-device-failures-retained']) {
            const heading = page.locator('#' + id);
            await heading.evaluate(el => el.scrollIntoView({block: 'start'}));
            const text = await heading.innerText();
            if (!text.includes(id.startsWith('top-k') ? 'Top-K' : 'Attention')) throw new Error('Missing report section');
            const overflow = await page.evaluate(() => document.documentElement.scrollWidth > innerWidth + 1);
            if (overflow) throw new Error('Page-level horizontal overflow');
            const path = root + '/' + id + '-' + width + '.png';
            await page.screenshot({path});
            receipts.push({id, width, overflow, screenshot: path});
        }
        await page.close();
    }
    await browser.close();
    fs.writeFileSync(root + '/docs-qa.json', JSON.stringify(receipts, null, 2));
})().catch(e => {console.error(e); process.exitCode = 1;});

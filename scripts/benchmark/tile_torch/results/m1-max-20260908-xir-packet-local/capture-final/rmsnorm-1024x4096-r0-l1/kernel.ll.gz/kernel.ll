; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 131072
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill5 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill5, align 4
  %.spill6 = alloca i64, align 8
  store i64 0, ptr %.spill6, align 4
  %.spill7 = alloca i64, align 8
  store i64 0, ptr %.spill7, align 4
  %.spill8 = alloca i64, align 8
  store i64 0, ptr %.spill8, align 4
  %.slot9 = alloca i64, align 8
  store i64 0, ptr %.slot9, align 4
  %.slot10 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot10, align 32
  %.slot11 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot11, align 32
  %.slot12 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot12, align 32
  %.slot13 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot13, align 32
  %.spill14 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill14, align 32
  %tile_snapshot.spill15 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill15, align 64
  %.slot16 = alloca i64, align 8
  store i64 0, ptr %.slot16, align 4
  %.spill17 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill17, align 32
  %.slot18 = alloca i64, align 8
  store i64 0, ptr %.slot18, align 4
  %6 = getelementptr i8, ptr %argument_buffer, i64 0
  %7 = load ptr, ptr %6, align 16
  %8 = getelementptr i8, ptr %6, i64 8
  %9 = load i64, ptr %8, align 8
  %10 = insertvalue { ptr, i64 } poison, ptr %7, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %9, 1
  %12 = getelementptr i8, ptr %argument_buffer, i64 16
  %13 = load ptr, ptr %12, align 16
  %14 = getelementptr i8, ptr %12, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = insertvalue { ptr, i64 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i64 } %16, i64 %15, 1
  %18 = getelementptr i8, ptr %argument_buffer, i64 32
  %19 = load ptr, ptr %18, align 16
  %20 = getelementptr i8, ptr %18, i64 8
  %21 = load i64, ptr %20, align 8
  %22 = insertvalue { ptr, i64 } poison, ptr %19, 0
  %23 = insertvalue { ptr, i64 } %22, i64 %21, 1
  %24 = getelementptr i8, ptr %argument_buffer, i64 48
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = load i32, ptr %launch_config, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 12
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 4
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 16
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 8
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 20
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 36
  %42 = load i32, ptr %41, align 4
  %.splatinsert19 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat20 = shufflevector <8 x i32> %.splatinsert19, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat20, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %44 = mul i32 %30, 1024
  %.splatinsert21 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat22 = shufflevector <8 x i32> %.splatinsert21, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat22, %43
  %46 = mul i32 %34, 1
  %.splatinsert23 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat24 = shufflevector <8 x i32> %.splatinsert23, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat24, zeroinitializer
  %48 = mul i32 %38, 1
  %.splatinsert25 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat26 = shufflevector <8 x i32> %.splatinsert25, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat26, zeroinitializer
  %50 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %45, 0
  %51 = insertvalue [3 x <8 x i32>] %50, <8 x i32> %47, 1
  %52 = insertvalue [3 x <8 x i32>] %51, <8 x i32> %49, 2
  %.splatinsert27 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat28 = shufflevector <8 x i32> %.splatinsert27, <8 x i32> poison, <8 x i32> zeroinitializer
  %53 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat28
  %54 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  br i1 %54, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %55 = extractvalue [3 x <8 x i32>] %52, 0
  %56 = zext <8 x i32> %55 to <8 x i64>
  %57 = select <8 x i1> %53, <8 x i64> %56, <8 x i64> zeroinitializer
  %58 = select <8 x i1> %53, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %59 = sdiv <8 x i64> %57, %58
  %60 = load <8 x i64>, ptr %.spill, align 64
  %61 = select <8 x i1> %53, <8 x i64> %59, <8 x i64> %60
  store <8 x i64> %61, ptr %.spill, align 64
  %62 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %63 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %64 = extractvalue { <8 x ptr>, <8 x i64> } %62, 0
  %65 = select <8 x i1> %53, <8 x ptr> %63, <8 x ptr> %64
  %66 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %62, 1
  %68 = select <8 x i1> %53, <8 x i64> %66, <8 x i64> %67
  %69 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %65, 0
  %70 = insertvalue { <8 x ptr>, <8 x i64> } %69, <8 x i64> %68, 1
  store { <8 x ptr>, <8 x i64> } %70, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %71 = icmp slt i64 %.state, 4096
  br i1 %71, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %72 = add <8 x i64> %.spill.load, zeroinitializer
  %73 = add <8 x i64> zeroinitializer, %72
  %.state29 = load i64, ptr %.slot, align 4
  %74 = add i64 0, %.state29
  %75 = mul <8 x i64> %73, splat (i64 4096)
  %.splatinsert30 = insertelement <8 x i64> poison, i64 %74, i64 0
  %.splat31 = shufflevector <8 x i64> %.splatinsert30, <8 x i64> poison, <8 x i32> zeroinitializer
  %76 = add <8 x i64> %75, %.splat31
  %77 = extractvalue { ptr, i64 } %11, 0
  %78 = mul <8 x i64> %76, splat (i64 4)
  %79 = getelementptr i8, ptr %77, <8 x i64> %78
  %80 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %79, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %81 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %82 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state32 = load i64, ptr %.slot, align 4
  %.splatinsert33 = insertelement <8 x i64> poison, i64 %.state32, i64 0
  %.splat34 = shufflevector <8 x i64> %.splatinsert33, <8 x i64> poison, <8 x i32> zeroinitializer
  %83 = mul <8 x i64> %.splat34, splat (i64 32)
  %84 = add <8 x i64> %82, %83
  %85 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %81, 0
  %86 = insertvalue { <8 x ptr>, <8 x i64> } %85, <8 x i64> %84, 1
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %86, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %86, 1
  %89 = getelementptr i8, <8 x ptr> %87, <8 x i64> %88
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %80, <8 x ptr> %89, i32 1, <8 x i1> %53)
  %.state35 = load i64, ptr %.slot, align 4
  %90 = add i64 %.state35, 1
  store i64 %90, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store float 0.000000e+00, ptr %.spill5, align 4
  store i64 0, ptr %.spill6, align 4
  store i64 0, ptr %.spill7, align 4
  store i64 0, ptr %.spill8, align 4
  %tile_snapshot.spill.load36 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %91 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load36, 0
  %92 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load36, 1
  %93 = add <8 x i64> %92, zeroinitializer
  %94 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %91, 0
  %95 = insertvalue { <8 x ptr>, <8 x i64> } %94, <8 x i64> %93, 1
  %96 = extractvalue { <8 x ptr>, <8 x i64> } %95, 0
  %97 = extractvalue { <8 x ptr>, <8 x i64> } %95, 1
  %98 = getelementptr i8, <8 x ptr> %96, <8 x i64> %97
  %99 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %98, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %100 = fmul <8 x float> %99, %99
  %tile_snapshot.spill.load37 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %101 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load37, 0
  %102 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load37, 1
  %103 = add <8 x i64> %102, splat (i64 32)
  %104 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %101, 0
  %105 = insertvalue { <8 x ptr>, <8 x i64> } %104, <8 x i64> %103, 1
  %106 = extractvalue { <8 x ptr>, <8 x i64> } %105, 0
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %105, 1
  %108 = getelementptr i8, <8 x ptr> %106, <8 x i64> %107
  %109 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %108, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %110 = fmul <8 x float> %109, %109
  %tile_snapshot.spill.load38 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %111 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load38, 0
  %112 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load38, 1
  %113 = add <8 x i64> %112, splat (i64 64)
  %114 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %111, 0
  %115 = insertvalue { <8 x ptr>, <8 x i64> } %114, <8 x i64> %113, 1
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %115, 0
  %117 = extractvalue { <8 x ptr>, <8 x i64> } %115, 1
  %118 = getelementptr i8, <8 x ptr> %116, <8 x i64> %117
  %119 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %118, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %120 = fmul <8 x float> %119, %119
  %tile_snapshot.spill.load39 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %121 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load39, 0
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load39, 1
  %123 = add <8 x i64> %122, splat (i64 96)
  %124 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %121, 0
  %125 = insertvalue { <8 x ptr>, <8 x i64> } %124, <8 x i64> %123, 1
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %125, 0
  %127 = extractvalue { <8 x ptr>, <8 x i64> } %125, 1
  %128 = getelementptr i8, <8 x ptr> %126, <8 x i64> %127
  %129 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %128, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %130 = fmul <8 x float> %129, %129
  store i64 4, ptr %.slot9, align 4
  %131 = load <8 x float>, ptr %.slot10, align 32
  %132 = select <8 x i1> %53, <8 x float> %100, <8 x float> %131
  store <8 x float> %132, ptr %.slot10, align 32
  %133 = load <8 x float>, ptr %.slot11, align 32
  %134 = select <8 x i1> %53, <8 x float> %110, <8 x float> %133
  store <8 x float> %134, ptr %.slot11, align 32
  %135 = load <8 x float>, ptr %.slot12, align 32
  %136 = select <8 x i1> %53, <8 x float> %120, <8 x float> %135
  store <8 x float> %136, ptr %.slot12, align 32
  %137 = load <8 x float>, ptr %.slot13, align 32
  %138 = select <8 x i1> %53, <8 x float> %130, <8 x float> %137
  store <8 x float> %138, ptr %.slot13, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state40 = load i64, ptr %.slot9, align 4
  %139 = icmp slt i64 %.state40, 4096
  br i1 %139, label %direct.true41, label %direct.false42

direct.schedule.5:                                ; preds = %direct.true41
  %.state43 = load i64, ptr %.slot9, align 4
  %140 = add i64 %.state43, 0
  %141 = sdiv i64 %140, 1
  %.spill.load44 = load i64, ptr %.spill7, align 4
  %142 = add i64 %.spill.load44, %141
  %.spill.load45 = load i64, ptr %.spill8, align 4
  %143 = add i64 %.spill.load45, %142
  %tile_snapshot.spill.load46 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %144 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load46, 0
  %145 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load46, 1
  %.splatinsert47 = insertelement <8 x i64> poison, i64 %143, i64 0
  %.splat48 = shufflevector <8 x i64> %.splatinsert47, <8 x i64> poison, <8 x i32> zeroinitializer
  %146 = mul <8 x i64> %.splat48, splat (i64 32)
  %147 = add <8 x i64> %145, %146
  %148 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %144, 0
  %149 = insertvalue { <8 x ptr>, <8 x i64> } %148, <8 x i64> %147, 1
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %149, 0
  %151 = extractvalue { <8 x ptr>, <8 x i64> } %149, 1
  %152 = getelementptr i8, <8 x ptr> %150, <8 x i64> %151
  %153 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %152, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %154 = fmul <8 x float> %153, %153
  %.state49 = load <8 x float>, ptr %.slot10, align 32
  %155 = fadd <8 x float> %.state49, %154
  %.state50 = load i64, ptr %.slot9, align 4
  %156 = add i64 %.state50, 1
  %157 = sdiv i64 %156, 1
  %.spill.load51 = load i64, ptr %.spill7, align 4
  %158 = add i64 %.spill.load51, %157
  %.spill.load52 = load i64, ptr %.spill8, align 4
  %159 = add i64 %.spill.load52, %158
  %tile_snapshot.spill.load53 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %160 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 0
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 1
  %.splatinsert54 = insertelement <8 x i64> poison, i64 %159, i64 0
  %.splat55 = shufflevector <8 x i64> %.splatinsert54, <8 x i64> poison, <8 x i32> zeroinitializer
  %162 = mul <8 x i64> %.splat55, splat (i64 32)
  %163 = add <8 x i64> %161, %162
  %164 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %160, 0
  %165 = insertvalue { <8 x ptr>, <8 x i64> } %164, <8 x i64> %163, 1
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %165, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %165, 1
  %168 = getelementptr i8, <8 x ptr> %166, <8 x i64> %167
  %169 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %168, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %170 = fmul <8 x float> %169, %169
  %.state56 = load <8 x float>, ptr %.slot11, align 32
  %171 = fadd <8 x float> %.state56, %170
  %.state57 = load i64, ptr %.slot9, align 4
  %172 = add i64 %.state57, 2
  %173 = sdiv i64 %172, 1
  %.spill.load58 = load i64, ptr %.spill7, align 4
  %174 = add i64 %.spill.load58, %173
  %.spill.load59 = load i64, ptr %.spill8, align 4
  %175 = add i64 %.spill.load59, %174
  %tile_snapshot.spill.load60 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load60, 0
  %177 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load60, 1
  %.splatinsert61 = insertelement <8 x i64> poison, i64 %175, i64 0
  %.splat62 = shufflevector <8 x i64> %.splatinsert61, <8 x i64> poison, <8 x i32> zeroinitializer
  %178 = mul <8 x i64> %.splat62, splat (i64 32)
  %179 = add <8 x i64> %177, %178
  %180 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %176, 0
  %181 = insertvalue { <8 x ptr>, <8 x i64> } %180, <8 x i64> %179, 1
  %182 = extractvalue { <8 x ptr>, <8 x i64> } %181, 0
  %183 = extractvalue { <8 x ptr>, <8 x i64> } %181, 1
  %184 = getelementptr i8, <8 x ptr> %182, <8 x i64> %183
  %185 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %184, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %186 = fmul <8 x float> %185, %185
  %.state63 = load <8 x float>, ptr %.slot12, align 32
  %187 = fadd <8 x float> %.state63, %186
  %.state64 = load i64, ptr %.slot9, align 4
  %188 = add i64 %.state64, 3
  %189 = sdiv i64 %188, 1
  %.spill.load65 = load i64, ptr %.spill7, align 4
  %190 = add i64 %.spill.load65, %189
  %.spill.load66 = load i64, ptr %.spill8, align 4
  %191 = add i64 %.spill.load66, %190
  %tile_snapshot.spill.load67 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load67, 0
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load67, 1
  %.splatinsert68 = insertelement <8 x i64> poison, i64 %191, i64 0
  %.splat69 = shufflevector <8 x i64> %.splatinsert68, <8 x i64> poison, <8 x i32> zeroinitializer
  %194 = mul <8 x i64> %.splat69, splat (i64 32)
  %195 = add <8 x i64> %193, %194
  %196 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %192, 0
  %197 = insertvalue { <8 x ptr>, <8 x i64> } %196, <8 x i64> %195, 1
  %198 = extractvalue { <8 x ptr>, <8 x i64> } %197, 0
  %199 = extractvalue { <8 x ptr>, <8 x i64> } %197, 1
  %200 = getelementptr i8, <8 x ptr> %198, <8 x i64> %199
  %201 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %200, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %202 = fmul <8 x float> %201, %201
  %.state70 = load <8 x float>, ptr %.slot13, align 32
  %203 = fadd <8 x float> %.state70, %202
  %.state71 = load i64, ptr %.slot9, align 4
  %204 = add i64 %.state71, 4
  store i64 %204, ptr %.slot9, align 4
  %205 = load <8 x float>, ptr %.slot10, align 32
  %206 = select <8 x i1> %53, <8 x float> %155, <8 x float> %205
  store <8 x float> %206, ptr %.slot10, align 32
  %207 = load <8 x float>, ptr %.slot11, align 32
  %208 = select <8 x i1> %53, <8 x float> %171, <8 x float> %207
  store <8 x float> %208, ptr %.slot11, align 32
  %209 = load <8 x float>, ptr %.slot12, align 32
  %210 = select <8 x i1> %53, <8 x float> %187, <8 x float> %209
  store <8 x float> %210, ptr %.slot12, align 32
  %211 = load <8 x float>, ptr %.slot13, align 32
  %212 = select <8 x i1> %53, <8 x float> %203, <8 x float> %211
  store <8 x float> %212, ptr %.slot13, align 32
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false42
  %.spill.load72 = load float, ptr %.spill5, align 4
  %.splatinsert73 = insertelement <8 x float> poison, float %.spill.load72, i64 0
  %.splat74 = shufflevector <8 x float> %.splatinsert73, <8 x float> poison, <8 x i32> zeroinitializer
  %.state75 = load <8 x float>, ptr %.slot10, align 32
  %213 = fadd <8 x float> %.splat74, %.state75
  %.state76 = load <8 x float>, ptr %.slot11, align 32
  %214 = fadd <8 x float> %213, %.state76
  %.state77 = load <8 x float>, ptr %.slot12, align 32
  %215 = fadd <8 x float> %214, %.state77
  %.state78 = load <8 x float>, ptr %.slot13, align 32
  %216 = fadd <8 x float> %215, %.state78
  %217 = fdiv <8 x float> %216, splat (float 4.096000e+03)
  %218 = load <8 x float>, ptr %.spill14, align 32
  %219 = select <8 x i1> %53, <8 x float> %217, <8 x float> %218
  store <8 x float> %219, ptr %.spill14, align 32
  %220 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %220, 0
  %223 = select <8 x i1> %53, <8 x ptr> %221, <8 x ptr> %222
  %224 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %225 = extractvalue { <8 x ptr>, <8 x i64> } %220, 1
  %226 = select <8 x i1> %53, <8 x i64> %224, <8 x i64> %225
  %227 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %223, 0
  %228 = insertvalue { <8 x ptr>, <8 x i64> } %227, <8 x i64> %226, 1
  store { <8 x ptr>, <8 x i64> } %228, ptr %tile_snapshot.spill15, align 64
  store i64 0, ptr %.slot16, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state79 = load i64, ptr %.slot16, align 4
  %229 = icmp slt i64 %.state79, 4096
  br i1 %229, label %direct.true80, label %direct.false81

direct.schedule.8:                                ; preds = %direct.true80
  %.spill.load82 = load i64, ptr %.spill6, align 4
  %230 = add i64 %.spill.load82, 0
  %.state83 = load i64, ptr %.slot16, align 4
  %231 = add i64 0, %.state83
  %232 = mul i64 %230, 4096
  %233 = add i64 %232, %231
  %234 = extractvalue { ptr, i64 } %17, 0
  %235 = mul i64 %233, 4
  %236 = getelementptr i8, ptr %234, i64 %235
  %237 = load float, ptr %236, align 4
  %.splatinsert84 = insertelement <8 x float> poison, float %237, i64 0
  %.splat85 = shufflevector <8 x float> %.splatinsert84, <8 x float> poison, <8 x i32> zeroinitializer
  %tile_snapshot.spill.load86 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %238 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load86, 0
  %239 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load86, 1
  %.state87 = load i64, ptr %.slot16, align 4
  %.splatinsert88 = insertelement <8 x i64> poison, i64 %.state87, i64 0
  %.splat89 = shufflevector <8 x i64> %.splatinsert88, <8 x i64> poison, <8 x i32> zeroinitializer
  %240 = mul <8 x i64> %.splat89, splat (i64 32)
  %241 = add <8 x i64> %239, %240
  %242 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %238, 0
  %243 = insertvalue { <8 x ptr>, <8 x i64> } %242, <8 x i64> %241, 1
  %244 = extractvalue { <8 x ptr>, <8 x i64> } %243, 0
  %245 = extractvalue { <8 x ptr>, <8 x i64> } %243, 1
  %246 = getelementptr i8, <8 x ptr> %244, <8 x i64> %245
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.splat85, <8 x ptr> %246, i32 1, <8 x i1> %53)
  %.state90 = load i64, ptr %.slot16, align 4
  %247 = add i64 %.state90, 1
  store i64 %247, ptr %.slot16, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false81
  %.spill.load91 = load <8 x float>, ptr %.spill14, align 32
  %248 = fadd <8 x float> %.spill.load91, splat (float 0x3EE4F8B580000000)
  %249 = call <8 x float> @llvm.sqrt.v8f32(<8 x float> %248)
  %250 = load <8 x float>, ptr %.spill17, align 32
  %251 = select <8 x i1> %53, <8 x float> %249, <8 x float> %250
  store <8 x float> %251, ptr %.spill17, align 32
  store i64 0, ptr %.slot18, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state92 = load i64, ptr %.slot18, align 4
  %252 = icmp slt i64 %.state92, 4096
  br i1 %252, label %direct.true93, label %direct.false94

direct.schedule.11:                               ; preds = %direct.true93
  %.spill.load95 = load <8 x i64>, ptr %.spill, align 64
  %253 = add <8 x i64> %.spill.load95, zeroinitializer
  %254 = add <8 x i64> zeroinitializer, %253
  %.state96 = load i64, ptr %.slot18, align 4
  %255 = add i64 0, %.state96
  %256 = mul <8 x i64> %254, splat (i64 4096)
  %.splatinsert97 = insertelement <8 x i64> poison, i64 %255, i64 0
  %.splat98 = shufflevector <8 x i64> %.splatinsert97, <8 x i64> poison, <8 x i32> zeroinitializer
  %257 = add <8 x i64> %256, %.splat98
  %.spill.load99 = load i64, ptr %.spill8, align 4
  %.state100 = load i64, ptr %.slot18, align 4
  %258 = add i64 %.spill.load99, %.state100
  %.spill.load101 = load i64, ptr %.spill8, align 4
  %259 = add i64 %.spill.load101, %258
  %tile_snapshot.spill.load102 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %260 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load102, 0
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load102, 1
  %.splatinsert103 = insertelement <8 x i64> poison, i64 %259, i64 0
  %.splat104 = shufflevector <8 x i64> %.splatinsert103, <8 x i64> poison, <8 x i32> zeroinitializer
  %262 = mul <8 x i64> %.splat104, splat (i64 32)
  %263 = add <8 x i64> %261, %262
  %264 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %260, 0
  %265 = insertvalue { <8 x ptr>, <8 x i64> } %264, <8 x i64> %263, 1
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %265, 0
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %265, 1
  %268 = getelementptr i8, <8 x ptr> %266, <8 x i64> %267
  %269 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %268, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %.spill.load105 = load <8 x float>, ptr %.spill17, align 32
  %270 = fdiv <8 x float> %269, %.spill.load105
  %tile_snapshot.spill.load106 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %271 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load106, 0
  %272 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load106, 1
  %.splatinsert107 = insertelement <8 x i64> poison, i64 %258, i64 0
  %.splat108 = shufflevector <8 x i64> %.splatinsert107, <8 x i64> poison, <8 x i32> zeroinitializer
  %273 = mul <8 x i64> %.splat108, splat (i64 32)
  %274 = add <8 x i64> %272, %273
  %275 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %271, 0
  %276 = insertvalue { <8 x ptr>, <8 x i64> } %275, <8 x i64> %274, 1
  %277 = extractvalue { <8 x ptr>, <8 x i64> } %276, 0
  %278 = extractvalue { <8 x ptr>, <8 x i64> } %276, 1
  %279 = getelementptr i8, <8 x ptr> %277, <8 x i64> %278
  %280 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %279, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %281 = fmul <8 x float> %270, %280
  %282 = extractvalue { ptr, i64 } %29, 0
  %283 = mul <8 x i64> %257, splat (i64 4)
  %284 = getelementptr i8, ptr %282, <8 x i64> %283
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %281, <8 x ptr> %284, i32 1, <8 x i1> %53)
  %.state109 = load i64, ptr %.slot18, align 4
  %285 = add i64 %.state109, 1
  store i64 %285, ptr %.slot18, align 4
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false94
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true41:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false42:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true80:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false81:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true93:                                    ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false94:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.12
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.sqrt.v8f32(<8 x float>) #0

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 1024
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 1024
  %3 = sub i64 1024, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 128
  %8 = icmp uge i64 %packet.range.remaining, 1024
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  br label %packet.batch.full.loop

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full.loop
  ret void

packet.batch.full.loop:                           ; preds = %packet.batch.full.loop, %packet.batch.full
  %packet.index = phi i32 [ 0, %packet.batch.full ], [ %packet.index.next, %packet.batch.full.loop ]
  %packet.thread.offset = mul i32 %packet.index, 8
  %packet.thread.index = add i32 %base.thread.index, %packet.thread.offset
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.index.next = add i32 %packet.index, 1
  %packet.batch.has.more = icmp ult i32 %packet.index.next, %packet_count
  br i1 %packet.batch.has.more, label %packet.batch.full.loop, label %packet.batch.exit

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 128)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }

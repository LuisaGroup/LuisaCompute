	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI0_0:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_1:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_2:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_3:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_4:
	.quad	56                              ; 0x38
	.quad	60                              ; 0x3c
lCPI0_5:
	.quad	48                              ; 0x30
	.quad	52                              ; 0x34
lCPI0_6:
	.quad	40                              ; 0x28
	.quad	44                              ; 0x2c
lCPI0_7:
	.quad	32                              ; 0x20
	.quad	36                              ; 0x24
lCPI0_8:
	.quad	88                              ; 0x58
	.quad	92                              ; 0x5c
lCPI0_9:
	.quad	80                              ; 0x50
	.quad	84                              ; 0x54
lCPI0_10:
	.quad	72                              ; 0x48
	.quad	76                              ; 0x4c
lCPI0_11:
	.quad	64                              ; 0x40
	.quad	68                              ; 0x44
lCPI0_12:
	.quad	120                             ; 0x78
	.quad	124                             ; 0x7c
lCPI0_13:
	.quad	112                             ; 0x70
	.quad	116                             ; 0x74
lCPI0_14:
	.quad	104                             ; 0x68
	.quad	108                             ; 0x6c
lCPI0_15:
	.quad	96                              ; 0x60
	.quad	100                             ; 0x64
lCPI0_16:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_17:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_18:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #4, lsl #12             ; =16384
	sub	sp, sp, #512
	str	x0, [sp, #120]                  ; 8-byte Folded Spill
	cbz	w3, LBB0_316
; %bb.1:                                ; %block.batch.loop.preheader
	mov	w20, #0                         ; =0x0
	ldp	w21, w22, [x2, #44]
Lloh0:
	adrp	x9, lCPI0_0@PAGE
Lloh1:
	ldr	q0, [x9, lCPI0_0@PAGEOFF]
	add	x9, sp, #2, lsl #12             ; =8192
	add	x9, x9, #512
	dup.2d	v1, x9
	add.2d	v14, v1, v0
Lloh2:
	adrp	x9, lCPI0_1@PAGE
Lloh3:
	ldr	q3, [x9, lCPI0_1@PAGEOFF]
	add.2d	v15, v1, v3
Lloh4:
	adrp	x9, lCPI0_2@PAGE
Lloh5:
	ldr	q5, [x9, lCPI0_2@PAGEOFF]
	add.2d	v13, v1, v5
Lloh6:
	adrp	x9, lCPI0_3@PAGE
Lloh7:
	ldr	q7, [x9, lCPI0_3@PAGEOFF]
	add.2d	v12, v1, v7
Lloh8:
	adrp	x9, lCPI0_4@PAGE
Lloh9:
	ldr	q2, [x9, lCPI0_4@PAGEOFF]
	add.2d	v11, v1, v2
Lloh10:
	adrp	x9, lCPI0_5@PAGE
Lloh11:
	ldr	q2, [x9, lCPI0_5@PAGEOFF]
	add.2d	v10, v1, v2
Lloh12:
	adrp	x9, lCPI0_6@PAGE
Lloh13:
	ldr	q2, [x9, lCPI0_6@PAGEOFF]
	add.2d	v2, v1, v2
	str	q2, [sp, #416]                  ; 16-byte Folded Spill
Lloh14:
	adrp	x9, lCPI0_7@PAGE
Lloh15:
	ldr	q2, [x9, lCPI0_7@PAGEOFF]
	add.2d	v2, v1, v2
	str	q2, [sp, #400]                  ; 16-byte Folded Spill
Lloh16:
	adrp	x9, lCPI0_8@PAGE
Lloh17:
	ldr	q2, [x9, lCPI0_8@PAGEOFF]
	add.2d	v2, v1, v2
	str	q2, [sp, #384]                  ; 16-byte Folded Spill
Lloh18:
	adrp	x9, lCPI0_9@PAGE
Lloh19:
	ldr	q2, [x9, lCPI0_9@PAGEOFF]
	add.2d	v2, v1, v2
	str	q2, [sp, #368]                  ; 16-byte Folded Spill
Lloh20:
	adrp	x9, lCPI0_10@PAGE
Lloh21:
	ldr	q2, [x9, lCPI0_10@PAGEOFF]
	add.2d	v2, v1, v2
	str	q2, [sp, #352]                  ; 16-byte Folded Spill
Lloh22:
	adrp	x9, lCPI0_11@PAGE
Lloh23:
	ldr	q2, [x9, lCPI0_11@PAGEOFF]
	add.2d	v2, v1, v2
	str	q2, [sp, #336]                  ; 16-byte Folded Spill
Lloh24:
	adrp	x9, lCPI0_12@PAGE
Lloh25:
	ldr	q2, [x9, lCPI0_12@PAGEOFF]
	add.2d	v2, v1, v2
	str	q2, [sp, #320]                  ; 16-byte Folded Spill
Lloh26:
	adrp	x9, lCPI0_13@PAGE
Lloh27:
	ldr	q2, [x9, lCPI0_13@PAGEOFF]
	add.2d	v2, v1, v2
	str	q2, [sp, #304]                  ; 16-byte Folded Spill
Lloh28:
	adrp	x9, lCPI0_14@PAGE
Lloh29:
	ldr	q2, [x9, lCPI0_14@PAGEOFF]
	add.2d	v2, v1, v2
	str	q2, [sp, #288]                  ; 16-byte Folded Spill
Lloh30:
	adrp	x9, lCPI0_15@PAGE
Lloh31:
	ldr	q2, [x9, lCPI0_15@PAGEOFF]
	add.2d	v2, v1, v2
	str	q2, [sp, #272]                  ; 16-byte Folded Spill
	add	x11, sp, #512
	mov	w23, #64                        ; =0x40
	adrp	x25, lCPI0_16@PAGE
	ldp	w9, w10, [x2]
	adrp	x26, lCPI0_17@PAGE
	mov	w24, #998244352                 ; =0x3b800000
	dup.2d	v29, x11
	mov	w27, #50604                     ; =0xc5ac
	movk	w27, #14119, lsl #16
	adrp	x28, lCPI0_18@PAGE
	ldp	w11, w30, [x2, #8]
	str	x2, [sp, #8]                    ; 8-byte Folded Spill
	stp	q13, q12, [sp, #160]            ; 32-byte Folded Spill
	stp	q11, q10, [sp, #192]            ; 32-byte Folded Spill
	str	w3, [sp, #116]                  ; 4-byte Folded Spill
	stp	q15, q14, [sp, #16]             ; 32-byte Folded Spill
	str	x30, [sp, #104]                 ; 8-byte Folded Spill
	b	LBB0_4
LBB0_2:                                 ; %llm_rows.exit335.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldp	q15, q14, [sp, #16]             ; 32-byte Folded Reload
	ldp	q13, q12, [sp, #160]            ; 32-byte Folded Reload
	ldp	q11, q10, [sp, #192]            ; 32-byte Folded Reload
LBB0_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	w8, w16, #1
	cmp	w8, w21
	cset	w8, eq
	csinc	w9, wzr, w16, eq
	cinc	w10, w13, eq
	cmp	w10, w22
	cset	w11, eq
	ands	w8, w8, w11
	csel	w10, wzr, w10, ne
	ldr	w12, [sp, #156]                 ; 4-byte Folded Reload
	add	w11, w12, w8
	add	w20, w20, #1
	cmp	w20, w3
	b.eq	LBB0_315
LBB0_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_72 Depth 2
                                        ;       Child Loop BB0_73 Depth 3
                                        ;       Child Loop BB0_75 Depth 3
                                        ;       Child Loop BB0_77 Depth 3
                                        ;       Child Loop BB0_79 Depth 3
                                        ;     Child Loop BB0_85 Depth 2
                                        ;     Child Loop BB0_154 Depth 2
                                        ;     Child Loop BB0_220 Depth 2
                                        ;     Child Loop BB0_238 Depth 2
                                        ;     Child Loop BB0_6 Depth 2
                                        ;     Child Loop BB0_8 Depth 2
                                        ;     Child Loop BB0_10 Depth 2
                                        ;     Child Loop BB0_12 Depth 2
                                        ;     Child Loop BB0_14 Depth 2
                                        ;     Child Loop BB0_16 Depth 2
                                        ;     Child Loop BB0_18 Depth 2
                                        ;     Child Loop BB0_20 Depth 2
                                        ;     Child Loop BB0_22 Depth 2
                                        ;     Child Loop BB0_24 Depth 2
                                        ;     Child Loop BB0_26 Depth 2
                                        ;     Child Loop BB0_28 Depth 2
                                        ;     Child Loop BB0_30 Depth 2
                                        ;     Child Loop BB0_32 Depth 2
                                        ;     Child Loop BB0_34 Depth 2
                                        ;     Child Loop BB0_36 Depth 2
                                        ;     Child Loop BB0_38 Depth 2
                                        ;     Child Loop BB0_40 Depth 2
                                        ;     Child Loop BB0_42 Depth 2
                                        ;     Child Loop BB0_44 Depth 2
                                        ;     Child Loop BB0_46 Depth 2
                                        ;     Child Loop BB0_48 Depth 2
                                        ;     Child Loop BB0_50 Depth 2
                                        ;     Child Loop BB0_52 Depth 2
                                        ;     Child Loop BB0_54 Depth 2
                                        ;     Child Loop BB0_56 Depth 2
                                        ;     Child Loop BB0_58 Depth 2
                                        ;     Child Loop BB0_60 Depth 2
                                        ;     Child Loop BB0_62 Depth 2
                                        ;     Child Loop BB0_64 Depth 2
                                        ;     Child Loop BB0_66 Depth 2
                                        ;     Child Loop BB0_68 Depth 2
	stp	w10, w11, [sp, #152]            ; 8-byte Folded Spill
	mov	x12, x9
	ubfiz	x9, x9, #6, #32
	cmp	x9, x30
	csel	x10, x9, xzr, ls
	subs	x11, x30, x10
	cmp	x11, #64
	csel	x11, x11, x23, lo
	cmp	x30, x10
	ccmp	x9, x30, #2, hi
	csel	x11, x11, xzr, ls
	dup.4s	v4, w24
	dup.4s	v2, w27
	stp	q4, q2, [sp, #464]              ; 32-byte Folded Spill
	cmp	x11, #64
	b.lo	LBB0_70
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x24, x22
	mov	x23, x21
	str	w20, [sp, #224]                 ; 4-byte Folded Spill
	mov	x9, #0                          ; =0x0
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldr	x11, [x8]
	ldr	x20, [x8, #16]
	ldr	x10, [x8, #48]
	str	x12, [sp, #128]                 ; 8-byte Folded Spill
	lsl	w28, w12, #6
	dup.4s	v2, w28
	ldr	q10, [x25, lCPI0_16@PAGEOFF]
	orr.16b	v6, v2, v10
	ldr	q11, [x26, lCPI0_17@PAGEOFF]
	orr.16b	v16, v2, v11
	ushll2.2d	v2, v6, #10
	ushll2.2d	v4, v16, #10
	ushll.2d	v6, v6, #10
	ushll.2d	v16, v16, #10
LBB0_6:                                 ; %direct.true.i.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v17, x9
	shl.2d	v18, v17, #2
	dup.2d	v8, x11
	add.2d	v19, v8, v2
	add.2d	v19, v19, v18
	add.2d	v20, v8, v6
	add.2d	v20, v20, v18
	add.2d	v21, v8, v4
	add.2d	v21, v21, v18
	add.2d	v22, v8, v16
	add.2d	v18, v22, v18
	mov.d	x12, v18[1]
	fmov	x13, d18
	ldr	s18, [x13]
	mov.d	x13, v21[1]
	ldr	s22, [x12]
	fmov	x12, d21
	ldr	s21, [x12]
	ldr	s23, [x13]
	mov.d	x12, v20[1]
	fmov	x13, d20
	ldr	s20, [x13]
	ldr	s24, [x12]
	mov.d	x12, v19[1]
	fmov	x13, d19
	ldr	s19, [x13]
	ldr	s25, [x12]
	shl.2d	v17, v17, #5
	add.2d	v17, v1, v17
	add.2d	v26, v17, v0
	add.2d	v27, v17, v3
	add.2d	v28, v17, v5
	add.2d	v17, v17, v7
	mov.d	x12, v17[1]
	fmov	x13, d17
	str	s18, [x13]
	str	s22, [x12]
	mov.d	x12, v28[1]
	fmov	x13, d28
	str	s21, [x13]
	str	s23, [x12]
	mov.d	x12, v27[1]
	fmov	x13, d27
	str	s20, [x13]
	mov.d	x13, v26[1]
	str	s24, [x12]
	fmov	x12, d26
	str	s19, [x12]
	str	s25, [x13]
	add	x9, x9, #1
	cmp	x9, #256
	b.ne	LBB0_6
; %bb.7:                                ; %direct.false.i.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x6, #0                          ; =0x0
	mov.d	x13, v12[1]
	mov.d	x8, v13[1]
	mov.d	x30, v15[1]
	fmov	x9, d12
	fmov	x11, d15
	mov.d	x26, v14[1]
	fmov	x12, d14
	ldr	s18, [x11]
	ld1.s	{ v18 }[1], [x30]
	ld1.s	{ v18 }[2], [x12]
	ld1.s	{ v18 }[3], [x26]
	fmov	x11, d13
	ldr	s17, [x9]
	str	x13, [sp, #432]                 ; 8-byte Folded Spill
	ld1.s	{ v17 }[1], [x13]
	ld1.s	{ v17 }[2], [x11]
	str	x8, [sp, #448]                  ; 8-byte Folded Spill
	ld1.s	{ v17 }[3], [x8]
	fmul.4s	v17, v17, v17
	ldr	q19, [sp, #400]                 ; 16-byte Folded Reload
	mov.d	x13, v19[1]
	fmov	x9, d19
	ldr	q19, [sp, #416]                 ; 16-byte Folded Reload
	fmov	x11, d19
	mov.d	x8, v19[1]
	ldr	q19, [sp, #208]                 ; 16-byte Folded Reload
	mov.d	x2, v19[1]
	fmov	x12, d19
	ldr	q19, [sp, #192]                 ; 16-byte Folded Reload
	mov.d	x4, v19[1]
	ldr	s20, [x12]
	ld1.s	{ v20 }[1], [x2]
	fmov	x12, d19
	ld1.s	{ v20 }[2], [x12]
	ld1.s	{ v20 }[3], [x4]
	ldr	s21, [x9]
	str	x13, [sp, #240]                 ; 8-byte Folded Spill
	ld1.s	{ v21 }[1], [x13]
	ld1.s	{ v21 }[2], [x11]
	str	x8, [sp, #256]                  ; 8-byte Folded Spill
	ld1.s	{ v21 }[3], [x8]
	fmul.4s	v19, v18, v18
	fmul.4s	v18, v21, v21
	ldp	q24, q23, [sp, #336]            ; 32-byte Folded Reload
	mov.d	x27, v24[1]
	mov.d	x25, v23[1]
	fmul.4s	v20, v20, v20
	ldr	q21, [sp, #368]                 ; 16-byte Folded Reload
	fmov	x9, d21
	mov.d	x11, v21[1]
	ldr	q21, [sp, #384]                 ; 16-byte Folded Reload
	mov.d	x15, v21[1]
	fmov	x12, d21
	ldr	s22, [x9]
	ld1.s	{ v22 }[1], [x11]
	ld1.s	{ v22 }[2], [x12]
	fmov	x9, d24
	ld1.s	{ v22 }[3], [x15]
	ldr	s21, [x9]
	ld1.s	{ v21 }[1], [x27]
	fmov	x9, d23
	ld1.s	{ v21 }[2], [x9]
	ld1.s	{ v21 }[3], [x25]
	fmul.4s	v21, v21, v21
	fmul.4s	v22, v22, v22
	ldr	q23, [sp, #272]                 ; 16-byte Folded Reload
	fmov	x12, d23
	mov.d	x14, v23[1]
	ldr	q23, [sp, #288]                 ; 16-byte Folded Reload
	mov.d	x1, v23[1]
	fmov	x13, d23
	ldp	q23, q25, [sp, #304]            ; 32-byte Folded Reload
	fmov	x17, d23
	mov.d	x9, v23[1]
	mov.d	x16, v25[1]
	ldr	s24, [x17]
	ld1.s	{ v24 }[1], [x9]
	ldr	s23, [x12]
	ld1.s	{ v23 }[1], [x14]
	fmov	x12, d25
	ld1.s	{ v23 }[2], [x13]
	ld1.s	{ v23 }[3], [x1]
	fmul.4s	v23, v23, v23
	ld1.s	{ v24 }[2], [x12]
	ld1.s	{ v24 }[3], [x16]
	fmul.4s	v24, v24, v24
	mov	w3, #224                        ; =0xe0
LBB0_8:                                 ; %direct.true40.i.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sub	x12, x3, #96
	dup.2d	v25, x12
	add.2d	v25, v1, v25
	add.2d	v26, v25, v0
	add.2d	v27, v25, v3
	add.2d	v28, v25, v5
	add.2d	v25, v25, v7
	mov.d	x12, v25[1]
	fmov	x0, d25
	mov.d	x7, v28[1]
	fmov	x5, d28
	mov.d	x19, v27[1]
	fmov	x8, d27
	mov.d	x17, v26[1]
	fmov	x13, d26
	sub	x21, x3, #64
	ldr	s25, [x8]
	dup.2d	v26, x21
	add.2d	v27, v1, v26
	add.2d	v30, v27, v0
	add.2d	v28, v27, v3
	ldr	s26, [x0]
	add.2d	v31, v27, v5
	add.2d	v27, v27, v7
	mov.d	x8, v27[1]
	ld1.s	{ v25 }[1], [x19]
	mov.d	x0, v31[1]
	mov.d	x19, v28[1]
	ld1.s	{ v26 }[1], [x12]
	fmov	x21, d27
	fmov	x12, d28
	ldr	s27, [x12]
	fmov	x22, d31
	ld1.s	{ v27 }[1], [x19]
	mov.d	x12, v30[1]
	ldr	s28, [x21]
	sub	x19, x3, #32
	ld1.s	{ v28 }[1], [x8]
	dup.2d	v31, x19
	fmov	x8, d30
	add.2d	v30, v1, v31
	ld1.s	{ v25 }[2], [x13]
	add.2d	v31, v30, v0
	add.2d	v9, v30, v3
	add.2d	v12, v30, v5
	add.2d	v30, v30, v7
	ld1.s	{ v26 }[2], [x5]
	mov.d	x13, v30[1]
	mov.d	x5, v9[1]
	ld1.s	{ v27 }[2], [x8]
	fmov	x8, d9
	ldr	s9, [x8]
	mov.d	x8, v31[1]
	ld1.s	{ v28 }[2], [x22]
	fmov	x19, d30
	ld1.s	{ v9 }[1], [x5]
	fmov	x5, d31
	ld1.s	{ v9 }[2], [x5]
	mov.d	x5, v12[1]
	ldr	s30, [x19]
	fmov	x19, d12
	ld1.s	{ v25 }[3], [x17]
	ld1.s	{ v30 }[1], [x13]
	dup.2d	v31, x3
	ld1.s	{ v26 }[3], [x7]
	add.2d	v31, v1, v31
	add.2d	v12, v31, v7
	mov.d	x13, v12[1]
	ld1.s	{ v27 }[3], [x12]
	fmov	x12, d12
	add.2d	v12, v31, v5
	mov.d	x17, v12[1]
	ld1.s	{ v28 }[3], [x0]
	fmov	x0, d12
	add.2d	v12, v31, v3
	mov.d	x7, v12[1]
	ld1.s	{ v9 }[3], [x8]
	fmov	x8, d12
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	ld1.s	{ v30 }[2], [x19]
	fadd.4s	v19, v19, v25
	ld1.s	{ v30 }[3], [x5]
	add.2d	v25, v31, v0
	mov.d	x5, v25[1]
	fadd.4s	v17, v17, v26
	fmov	x19, d25
	fmul.4s	v25, v28, v28
	fmul.4s	v26, v27, v27
	fmul.4s	v27, v30, v30
	fmul.4s	v28, v9, v9
	fadd.4s	v20, v20, v26
	ldr	s26, [x8]
	ld1.s	{ v26 }[1], [x7]
	ld1.s	{ v26 }[2], [x19]
	fadd.4s	v18, v18, v25
	ld1.s	{ v26 }[3], [x5]
	ldr	s25, [x12]
	ld1.s	{ v25 }[1], [x13]
	fadd.4s	v22, v22, v28
	ld1.s	{ v25 }[2], [x0]
	ld1.s	{ v25 }[3], [x17]
	fmul.4s	v25, v25, v25
	fadd.4s	v21, v21, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v23, v23, v25
	add	x6, x6, #4
	add	x3, x3, #128
	cmp	x6, #252
	b.lo	LBB0_8
; %bb.9:                                ; %direct.true79.i.i.preheader
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x12, #0                         ; =0x0
	mov	x13, x20
LBB0_10:                                ; %direct.true79.i.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s25, [x13], #4
	dup.2d	v26, x12
	add.2d	v26, v29, v26
	add.2d	v27, v26, v0
	add.2d	v28, v26, v3
	add.2d	v30, v26, v5
	add.2d	v26, v26, v7
	mov.d	x8, v26[1]
	fmov	x17, d26
	str	s25, [x17]
	str	s25, [x8]
	mov.d	x8, v30[1]
	fmov	x17, d30
	str	s25, [x17]
	str	s25, [x8]
	mov.d	x8, v28[1]
	fmov	x17, d28
	str	s25, [x17]
	mov.d	x17, v27[1]
	str	s25, [x8]
	fmov	x8, d27
	str	s25, [x8]
	str	s25, [x17]
	add	x12, x12, #32
	cmp	x12, #2, lsl #12                ; =8192
	b.ne	LBB0_10
; %bb.11:                               ; %direct.false80.i.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x3, #0                          ; =0x0
	fadd.4s	v19, v19, v20
	fadd.4s	v17, v17, v18
	fadd.4s	v17, v17, v21
	fadd.4s	v18, v19, v22
	fadd.4s	v18, v18, v24
	fadd.4s	v17, v17, v23
	ldp	q20, q19, [sp, #464]            ; 32-byte Folded Reload
	fmul.4s	v17, v17, v20
	fmul.4s	v18, v18, v20
	fadd.4s	v18, v18, v19
	fadd.4s	v17, v17, v19
	fsqrt.4s	v17, v17
	fsqrt.4s	v18, v18
LBB0_12:                                ; %direct.true92.i.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v19, x3
	shl.2d	v20, v19, #5
	orr.16b	v21, v20, v7
	orr.16b	v22, v20, v5
	orr.16b	v23, v20, v3
	orr.16b	v20, v20, v0
	add.2d	v24, v1, v20
	add.2d	v25, v1, v23
	add.2d	v26, v1, v22
	add.2d	v27, v1, v21
	mov.d	x8, v27[1]
	fmov	x12, d27
	mov.d	x13, v26[1]
	fmov	x17, d26
	mov.d	x0, v25[1]
	fmov	x5, d25
	mov.d	x6, v24[1]
	fmov	x7, d24
	ldr	s24, [x5]
	ld1.s	{ v24 }[1], [x0]
	ldr	s25, [x12]
	add.2d	v20, v29, v20
	add.2d	v23, v29, v23
	add.2d	v22, v29, v22
	ld1.s	{ v25 }[1], [x8]
	add.2d	v21, v29, v21
	mov.d	x8, v21[1]
	fmov	x12, d21
	ld1.s	{ v24 }[2], [x7]
	mov.d	x0, v22[1]
	mov.d	x5, v23[1]
	ld1.s	{ v25 }[2], [x17]
	fmov	x17, d22
	mov.d	x7, v20[1]
	ldr	s21, [x12]
	ld1.s	{ v24 }[3], [x6]
	ld1.s	{ v21 }[1], [x8]
	ld1.s	{ v21 }[2], [x17]
	ld1.s	{ v25 }[3], [x13]
	fmov	x8, d23
	ldr	s22, [x8]
	ld1.s	{ v22 }[1], [x5]
	ld1.s	{ v21 }[3], [x0]
	fmov	x8, d20
	ld1.s	{ v22 }[2], [x8]
	ld1.s	{ v22 }[3], [x7]
	fdiv.4s	v20, v25, v17
	fdiv.4s	v23, v24, v18
	shl.2d	v19, v19, #2
	dup.2d	v9, x10
	add.2d	v24, v9, v2
	fmul.4s	v22, v23, v22
	add.2d	v23, v24, v19
	add.2d	v24, v9, v6
	add.2d	v25, v9, v4
	add.2d	v26, v9, v16
	add.2d	v26, v26, v19
	fmul.4s	v20, v20, v21
	mov.d	x8, v26[1]
	fmov	x12, d26
	str	s20, [x12]
	st1.s	{ v20 }[1], [x8]
	add.2d	v21, v25, v19
	mov.d	x8, v21[1]
	fmov	x12, d21
	st1.s	{ v20 }[2], [x12]
	add.2d	v19, v24, v19
	mov.d	x12, v19[1]
	fmov	x13, d19
	st1.s	{ v20 }[3], [x8]
	str	s22, [x13]
	mov.d	x8, v23[1]
	fmov	x13, d23
	st1.s	{ v22 }[1], [x12]
	st1.s	{ v22 }[2], [x13]
	st1.s	{ v22 }[3], [x8]
	add	x3, x3, #1
	cmp	x3, #256
	b.ne	LBB0_12
; %bb.13:                               ; %llm_rows.exit.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	orr	w8, w28, #0x8
	dup.4s	v2, w8
	orr.16b	v6, v2, v10
	orr.16b	v16, v2, v11
	ushll2.2d	v2, v6, #10
	ushll2.2d	v4, v16, #10
	ushll.2d	v6, v6, #10
	ushll.2d	v16, v16, #10
	ldr	q30, [sp, #176]                 ; 16-byte Folded Reload
LBB0_14:                                ; %direct.true.i10.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v17, x10
	shl.2d	v18, v17, #2
	add.2d	v19, v8, v2
	add.2d	v19, v19, v18
	add.2d	v20, v8, v6
	add.2d	v20, v20, v18
	add.2d	v21, v8, v4
	add.2d	v21, v21, v18
	add.2d	v22, v8, v16
	add.2d	v18, v22, v18
	mov.d	x8, v18[1]
	fmov	x12, d18
	ldr	s18, [x12]
	mov.d	x12, v21[1]
	ldr	s22, [x8]
	fmov	x8, d21
	ldr	s21, [x8]
	ldr	s23, [x12]
	mov.d	x8, v20[1]
	fmov	x12, d20
	ldr	s20, [x12]
	ldr	s24, [x8]
	mov.d	x8, v19[1]
	fmov	x12, d19
	ldr	s19, [x12]
	ldr	s25, [x8]
	shl.2d	v17, v17, #5
	add.2d	v17, v1, v17
	add.2d	v26, v17, v0
	add.2d	v27, v17, v3
	add.2d	v28, v17, v5
	add.2d	v17, v17, v7
	mov.d	x8, v17[1]
	fmov	x12, d17
	str	s18, [x12]
	str	s22, [x8]
	mov.d	x8, v28[1]
	fmov	x12, d28
	str	s21, [x12]
	str	s23, [x8]
	mov.d	x8, v27[1]
	fmov	x12, d27
	str	s20, [x12]
	mov.d	x12, v26[1]
	str	s24, [x8]
	fmov	x8, d26
	str	s19, [x8]
	str	s25, [x12]
	add	x10, x10, #1
	cmp	x10, #256
	b.ne	LBB0_14
; %bb.15:                               ; %direct.false.i15.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	fmov	x8, d15
	ldr	s18, [x8]
	ld1.s	{ v18 }[1], [x30]
	fmov	x8, d14
	ld1.s	{ v18 }[2], [x8]
	fmov	x8, d30
	ld1.s	{ v18 }[3], [x26]
	fmov	x12, d13
	ldr	s17, [x8]
	ldr	x8, [sp, #432]                  ; 8-byte Folded Reload
	ld1.s	{ v17 }[1], [x8]
	ld1.s	{ v17 }[2], [x12]
	ldr	x8, [sp, #448]                  ; 8-byte Folded Reload
	ld1.s	{ v17 }[3], [x8]
	fmul.4s	v17, v17, v17
	fmul.4s	v18, v18, v18
	ldr	q19, [sp, #208]                 ; 16-byte Folded Reload
	fmov	x8, d19
	ldr	q19, [sp, #192]                 ; 16-byte Folded Reload
	fmov	x12, d19
	ldr	s20, [x8]
	ld1.s	{ v20 }[1], [x2]
	ld1.s	{ v20 }[2], [x12]
	ldp	q19, q21, [sp, #400]            ; 32-byte Folded Reload
	fmov	x8, d19
	ld1.s	{ v20 }[3], [x4]
	ldr	s19, [x8]
	ldr	x8, [sp, #240]                  ; 8-byte Folded Reload
	ld1.s	{ v19 }[1], [x8]
	fmov	x8, d21
	ld1.s	{ v19 }[2], [x8]
	ldr	x8, [sp, #256]                  ; 8-byte Folded Reload
	ld1.s	{ v19 }[3], [x8]
	fmul.4s	v19, v19, v19
	ldr	q21, [sp, #336]                 ; 16-byte Folded Reload
	fmov	x8, d21
	ldr	q21, [sp, #352]                 ; 16-byte Folded Reload
	fmov	x12, d21
	ldp	q21, q22, [sp, #368]            ; 32-byte Folded Reload
	fmov	x13, d21
	ldr	s21, [x13]
	ld1.s	{ v21 }[1], [x11]
	fmov	x13, d22
	ld1.s	{ v21 }[2], [x13]
	ld1.s	{ v21 }[3], [x15]
	ldr	s23, [x8]
	ld1.s	{ v23 }[1], [x27]
	ld1.s	{ v23 }[2], [x12]
	ld1.s	{ v23 }[3], [x25]
	fmul.4s	v22, v20, v20
	fmul.4s	v20, v23, v23
	fmul.4s	v21, v21, v21
	ldr	q23, [sp, #272]                 ; 16-byte Folded Reload
	fmov	x8, d23
	ldr	q23, [sp, #288]                 ; 16-byte Folded Reload
	fmov	x12, d23
	ldp	q23, q25, [sp, #304]            ; 32-byte Folded Reload
	fmov	x13, d23
	ldr	s24, [x13]
	ld1.s	{ v24 }[1], [x9]
	ldr	s23, [x8]
	ld1.s	{ v23 }[1], [x14]
	fmov	x8, d25
	ld1.s	{ v23 }[2], [x12]
	ld1.s	{ v23 }[3], [x1]
	fmul.4s	v23, v23, v23
	ld1.s	{ v24 }[2], [x8]
	ld1.s	{ v24 }[3], [x16]
	fmul.4s	v24, v24, v24
	mov	w3, #224                        ; =0xe0
	mov	x21, x23
	mov	x22, x24
LBB0_16:                                ; %direct.true40.i16.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sub	x8, x3, #96
	dup.2d	v25, x8
	add.2d	v25, v1, v25
	add.2d	v26, v25, v0
	add.2d	v27, v25, v3
	add.2d	v28, v25, v5
	add.2d	v25, v25, v7
	mov.d	x8, v25[1]
	fmov	x12, d25
	mov.d	x6, v28[1]
	fmov	x5, d28
	mov.d	x0, v27[1]
	fmov	x7, d27
	mov.d	x17, v26[1]
	fmov	x13, d26
	sub	x19, x3, #64
	ldr	s25, [x7]
	dup.2d	v26, x19
	add.2d	v27, v1, v26
	add.2d	v30, v27, v0
	add.2d	v28, v27, v3
	ldr	s26, [x12]
	add.2d	v31, v27, v5
	add.2d	v27, v27, v7
	mov.d	x7, v27[1]
	ld1.s	{ v25 }[1], [x0]
	mov.d	x0, v31[1]
	mov.d	x12, v28[1]
	ld1.s	{ v26 }[1], [x8]
	fmov	x8, d27
	fmov	x19, d28
	ldr	s27, [x19]
	fmov	x19, d31
	ld1.s	{ v27 }[1], [x12]
	mov.d	x12, v30[1]
	ldr	s28, [x8]
	sub	x8, x3, #32
	ld1.s	{ v28 }[1], [x7]
	dup.2d	v31, x8
	fmov	x8, d30
	add.2d	v30, v1, v31
	ld1.s	{ v25 }[2], [x13]
	add.2d	v31, v30, v0
	add.2d	v12, v30, v3
	add.2d	v13, v30, v5
	add.2d	v30, v30, v7
	ld1.s	{ v26 }[2], [x5]
	mov.d	x13, v30[1]
	mov.d	x5, v12[1]
	ld1.s	{ v27 }[2], [x8]
	fmov	x8, d12
	ldr	s12, [x8]
	mov.d	x8, v31[1]
	ld1.s	{ v28 }[2], [x19]
	fmov	x7, d30
	ld1.s	{ v12 }[1], [x5]
	fmov	x5, d31
	ld1.s	{ v12 }[2], [x5]
	mov.d	x5, v13[1]
	ldr	s30, [x7]
	fmov	x7, d13
	ld1.s	{ v25 }[3], [x17]
	ld1.s	{ v30 }[1], [x13]
	dup.2d	v31, x3
	ld1.s	{ v26 }[3], [x6]
	add.2d	v31, v1, v31
	add.2d	v13, v31, v7
	mov.d	x13, v13[1]
	ld1.s	{ v27 }[3], [x12]
	fmov	x12, d13
	add.2d	v13, v31, v5
	mov.d	x17, v13[1]
	ld1.s	{ v28 }[3], [x0]
	fmov	x0, d13
	add.2d	v13, v31, v3
	mov.d	x6, v13[1]
	ld1.s	{ v12 }[3], [x8]
	fmov	x8, d13
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	ld1.s	{ v30 }[2], [x7]
	fadd.4s	v18, v18, v25
	ld1.s	{ v30 }[3], [x5]
	add.2d	v25, v31, v0
	mov.d	x5, v25[1]
	fadd.4s	v17, v17, v26
	fmov	x7, d25
	fmul.4s	v25, v28, v28
	fmul.4s	v26, v27, v27
	fmul.4s	v27, v30, v30
	fmul.4s	v28, v12, v12
	fadd.4s	v22, v22, v26
	ldr	s26, [x8]
	ld1.s	{ v26 }[1], [x6]
	ld1.s	{ v26 }[2], [x7]
	fadd.4s	v19, v19, v25
	ld1.s	{ v26 }[3], [x5]
	ldr	s25, [x12]
	ld1.s	{ v25 }[1], [x13]
	fadd.4s	v21, v21, v28
	ld1.s	{ v25 }[2], [x0]
	ld1.s	{ v25 }[3], [x17]
	fmul.4s	v25, v25, v25
	fadd.4s	v20, v20, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v23, v23, v25
	add	x10, x10, #4
	add	x3, x3, #128
	cmp	x10, #252
	b.lo	LBB0_16
; %bb.17:                               ; %direct.true79.i27.i.preheader
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	mov	x12, x20
	mov	w23, #64                        ; =0x40
	mov	w24, #998244352                 ; =0x3b800000
LBB0_18:                                ; %direct.true79.i27.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s25, [x12], #4
	dup.2d	v26, x10
	add.2d	v26, v29, v26
	add.2d	v27, v26, v0
	add.2d	v28, v26, v3
	add.2d	v30, v26, v5
	add.2d	v26, v26, v7
	mov.d	x8, v26[1]
	fmov	x13, d26
	str	s25, [x13]
	str	s25, [x8]
	mov.d	x8, v30[1]
	fmov	x13, d30
	str	s25, [x13]
	str	s25, [x8]
	mov.d	x8, v28[1]
	fmov	x13, d28
	str	s25, [x13]
	mov.d	x13, v27[1]
	str	s25, [x8]
	fmov	x8, d27
	str	s25, [x8]
	str	s25, [x13]
	add	x10, x10, #32
	cmp	x10, #2, lsl #12                ; =8192
	b.ne	LBB0_18
; %bb.19:                               ; %direct.false80.i33.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	fadd.4s	v18, v18, v22
	fadd.4s	v17, v17, v19
	fadd.4s	v17, v17, v20
	fadd.4s	v18, v18, v21
	fadd.4s	v18, v18, v24
	fadd.4s	v17, v17, v23
	ldp	q20, q19, [sp, #464]            ; 32-byte Folded Reload
	fmul.4s	v17, v17, v20
	fmul.4s	v18, v18, v20
	fadd.4s	v18, v18, v19
	fadd.4s	v17, v17, v19
	fsqrt.4s	v17, v17
	fsqrt.4s	v18, v18
LBB0_20:                                ; %direct.true92.i34.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v19, x10
	shl.2d	v20, v19, #5
	orr.16b	v21, v20, v7
	orr.16b	v22, v20, v3
	orr.16b	v23, v20, v5
	orr.16b	v20, v20, v0
	add.2d	v24, v1, v20
	add.2d	v25, v1, v22
	add.2d	v26, v1, v21
	mov.d	x8, v26[1]
	add.2d	v27, v1, v23
	fmov	x12, d26
	mov.d	x13, v27[1]
	mov.d	x17, v25[1]
	fmov	x0, d27
	fmov	x3, d25
	mov.d	x5, v24[1]
	fmov	x6, d24
	ldr	s24, [x3]
	ld1.s	{ v24 }[1], [x17]
	ldr	s25, [x12]
	add.2d	v20, v29, v20
	ld1.s	{ v25 }[1], [x8]
	add.2d	v22, v29, v22
	add.2d	v21, v29, v21
	mov.d	x8, v21[1]
	ld1.s	{ v24 }[2], [x6]
	add.2d	v23, v29, v23
	fmov	x12, d21
	mov.d	x17, v23[1]
	ld1.s	{ v25 }[2], [x0]
	fmov	x0, d23
	mov.d	x3, v22[1]
	fmov	x6, d22
	ld1.s	{ v24 }[3], [x5]
	mov.d	x5, v20[1]
	ldr	s21, [x12]
	fmov	x12, d20
	ld1.s	{ v25 }[3], [x13]
	ld1.s	{ v21 }[1], [x8]
	ld1.s	{ v21 }[2], [x0]
	ld1.s	{ v21 }[3], [x17]
	ldr	s20, [x6]
	ld1.s	{ v20 }[1], [x3]
	ld1.s	{ v20 }[2], [x12]
	fdiv.4s	v22, v25, v17
	fdiv.4s	v23, v24, v18
	ld1.s	{ v20 }[3], [x5]
	shl.2d	v19, v19, #2
	add.2d	v24, v9, v2
	fmul.4s	v20, v23, v20
	add.2d	v23, v24, v19
	add.2d	v24, v9, v6
	add.2d	v25, v9, v4
	add.2d	v26, v9, v16
	add.2d	v26, v26, v19
	fmul.4s	v21, v22, v21
	mov.d	x8, v26[1]
	fmov	x12, d26
	str	s21, [x12]
	st1.s	{ v21 }[1], [x8]
	add.2d	v22, v25, v19
	mov.d	x8, v22[1]
	fmov	x12, d22
	st1.s	{ v21 }[2], [x12]
	add.2d	v19, v24, v19
	mov.d	x12, v19[1]
	fmov	x13, d19
	st1.s	{ v21 }[3], [x8]
	str	s20, [x13]
	mov.d	x8, v23[1]
	fmov	x13, d23
	st1.s	{ v20 }[1], [x12]
	st1.s	{ v20 }[2], [x13]
	st1.s	{ v20 }[3], [x8]
	add	x10, x10, #1
	cmp	x10, #256
	b.ne	LBB0_20
; %bb.21:                               ; %llm_rows.exit39.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	orr	w8, w28, #0x10
	dup.4s	v2, w8
	orr.16b	v6, v2, v10
	orr.16b	v16, v2, v11
	ushll2.2d	v2, v6, #10
	ushll2.2d	v4, v16, #10
	ushll.2d	v6, v6, #10
	ushll.2d	v16, v16, #10
	ldp	q30, q31, [sp, #160]            ; 32-byte Folded Reload
LBB0_22:                                ; %direct.true.i47.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v17, x10
	shl.2d	v18, v17, #2
	add.2d	v19, v8, v2
	add.2d	v19, v19, v18
	add.2d	v20, v8, v6
	add.2d	v20, v20, v18
	add.2d	v21, v8, v4
	add.2d	v21, v21, v18
	add.2d	v22, v8, v16
	add.2d	v18, v22, v18
	mov.d	x8, v18[1]
	fmov	x12, d18
	ldr	s18, [x12]
	mov.d	x12, v21[1]
	ldr	s22, [x8]
	fmov	x8, d21
	ldr	s21, [x8]
	ldr	s23, [x12]
	mov.d	x8, v20[1]
	fmov	x12, d20
	ldr	s20, [x12]
	ldr	s24, [x8]
	mov.d	x8, v19[1]
	fmov	x12, d19
	ldr	s19, [x12]
	ldr	s25, [x8]
	shl.2d	v17, v17, #5
	add.2d	v17, v1, v17
	add.2d	v26, v17, v0
	add.2d	v27, v17, v3
	add.2d	v28, v17, v5
	add.2d	v17, v17, v7
	mov.d	x8, v17[1]
	fmov	x12, d17
	str	s18, [x12]
	str	s22, [x8]
	mov.d	x8, v28[1]
	fmov	x12, d28
	str	s21, [x12]
	str	s23, [x8]
	mov.d	x8, v27[1]
	fmov	x12, d27
	str	s20, [x12]
	mov.d	x12, v26[1]
	str	s24, [x8]
	fmov	x8, d26
	str	s19, [x8]
	str	s25, [x12]
	add	x10, x10, #1
	cmp	x10, #256
	b.ne	LBB0_22
; %bb.23:                               ; %direct.false.i52.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	fmov	x8, d15
	ldr	s18, [x8]
	ld1.s	{ v18 }[1], [x30]
	fmov	x8, d14
	ld1.s	{ v18 }[2], [x8]
	fmov	x8, d31
	ld1.s	{ v18 }[3], [x26]
	fmov	x12, d30
	ldr	s17, [x8]
	ldr	x8, [sp, #432]                  ; 8-byte Folded Reload
	ld1.s	{ v17 }[1], [x8]
	ld1.s	{ v17 }[2], [x12]
	ldr	x8, [sp, #448]                  ; 8-byte Folded Reload
	ld1.s	{ v17 }[3], [x8]
	fmul.4s	v17, v17, v17
	fmul.4s	v18, v18, v18
	ldr	q19, [sp, #208]                 ; 16-byte Folded Reload
	fmov	x8, d19
	ldr	q19, [sp, #192]                 ; 16-byte Folded Reload
	fmov	x12, d19
	ldr	s20, [x8]
	ld1.s	{ v20 }[1], [x2]
	ld1.s	{ v20 }[2], [x12]
	ldp	q19, q21, [sp, #400]            ; 32-byte Folded Reload
	fmov	x8, d19
	ld1.s	{ v20 }[3], [x4]
	ldr	s19, [x8]
	ldr	x8, [sp, #240]                  ; 8-byte Folded Reload
	ld1.s	{ v19 }[1], [x8]
	fmov	x8, d21
	ld1.s	{ v19 }[2], [x8]
	ldr	x8, [sp, #256]                  ; 8-byte Folded Reload
	ld1.s	{ v19 }[3], [x8]
	fmul.4s	v19, v19, v19
	ldr	q21, [sp, #336]                 ; 16-byte Folded Reload
	fmov	x8, d21
	ldr	q21, [sp, #352]                 ; 16-byte Folded Reload
	fmov	x12, d21
	ldp	q21, q22, [sp, #368]            ; 32-byte Folded Reload
	fmov	x13, d21
	ldr	s21, [x13]
	ld1.s	{ v21 }[1], [x11]
	fmov	x13, d22
	ld1.s	{ v21 }[2], [x13]
	ld1.s	{ v21 }[3], [x15]
	ldr	s23, [x8]
	ld1.s	{ v23 }[1], [x27]
	ld1.s	{ v23 }[2], [x12]
	ld1.s	{ v23 }[3], [x25]
	fmul.4s	v22, v20, v20
	fmul.4s	v20, v23, v23
	fmul.4s	v21, v21, v21
	ldr	q23, [sp, #272]                 ; 16-byte Folded Reload
	fmov	x8, d23
	ldr	q23, [sp, #288]                 ; 16-byte Folded Reload
	fmov	x12, d23
	ldp	q23, q25, [sp, #304]            ; 32-byte Folded Reload
	fmov	x13, d23
	ldr	s24, [x13]
	ld1.s	{ v24 }[1], [x9]
	ldr	s23, [x8]
	ld1.s	{ v23 }[1], [x14]
	fmov	x8, d25
	ld1.s	{ v23 }[2], [x12]
	ld1.s	{ v23 }[3], [x1]
	fmul.4s	v23, v23, v23
	ld1.s	{ v24 }[2], [x8]
	ld1.s	{ v24 }[3], [x16]
	fmul.4s	v24, v24, v24
	mov	w3, #224                        ; =0xe0
LBB0_24:                                ; %direct.true40.i53.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sub	x8, x3, #96
	dup.2d	v25, x8
	add.2d	v25, v1, v25
	add.2d	v26, v25, v0
	add.2d	v27, v25, v3
	add.2d	v28, v25, v5
	add.2d	v25, v25, v7
	mov.d	x8, v25[1]
	fmov	x12, d25
	mov.d	x6, v28[1]
	fmov	x5, d28
	mov.d	x0, v27[1]
	fmov	x7, d27
	mov.d	x17, v26[1]
	fmov	x13, d26
	sub	x19, x3, #64
	ldr	s25, [x7]
	dup.2d	v26, x19
	add.2d	v27, v1, v26
	add.2d	v30, v27, v0
	add.2d	v28, v27, v3
	ldr	s26, [x12]
	add.2d	v31, v27, v5
	add.2d	v27, v27, v7
	mov.d	x7, v27[1]
	ld1.s	{ v25 }[1], [x0]
	mov.d	x0, v31[1]
	mov.d	x12, v28[1]
	ld1.s	{ v26 }[1], [x8]
	fmov	x8, d27
	fmov	x19, d28
	ldr	s27, [x19]
	fmov	x19, d31
	ld1.s	{ v27 }[1], [x12]
	mov.d	x12, v30[1]
	ldr	s28, [x8]
	sub	x8, x3, #32
	ld1.s	{ v28 }[1], [x7]
	dup.2d	v31, x8
	fmov	x8, d30
	add.2d	v30, v1, v31
	ld1.s	{ v25 }[2], [x13]
	add.2d	v31, v30, v0
	add.2d	v12, v30, v3
	add.2d	v13, v30, v5
	add.2d	v30, v30, v7
	ld1.s	{ v26 }[2], [x5]
	mov.d	x13, v30[1]
	mov.d	x5, v12[1]
	ld1.s	{ v27 }[2], [x8]
	fmov	x8, d12
	ldr	s12, [x8]
	mov.d	x8, v31[1]
	ld1.s	{ v28 }[2], [x19]
	fmov	x7, d30
	ld1.s	{ v12 }[1], [x5]
	fmov	x5, d31
	ld1.s	{ v12 }[2], [x5]
	mov.d	x5, v13[1]
	ldr	s30, [x7]
	fmov	x7, d13
	ld1.s	{ v25 }[3], [x17]
	ld1.s	{ v30 }[1], [x13]
	dup.2d	v31, x3
	ld1.s	{ v26 }[3], [x6]
	add.2d	v31, v1, v31
	add.2d	v13, v31, v7
	mov.d	x13, v13[1]
	ld1.s	{ v27 }[3], [x12]
	fmov	x12, d13
	add.2d	v13, v31, v5
	mov.d	x17, v13[1]
	ld1.s	{ v28 }[3], [x0]
	fmov	x0, d13
	add.2d	v13, v31, v3
	mov.d	x6, v13[1]
	ld1.s	{ v12 }[3], [x8]
	fmov	x8, d13
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	ld1.s	{ v30 }[2], [x7]
	fadd.4s	v18, v18, v25
	ld1.s	{ v30 }[3], [x5]
	add.2d	v25, v31, v0
	mov.d	x5, v25[1]
	fadd.4s	v17, v17, v26
	fmov	x7, d25
	fmul.4s	v25, v28, v28
	fmul.4s	v26, v27, v27
	fmul.4s	v27, v30, v30
	fmul.4s	v28, v12, v12
	fadd.4s	v22, v22, v26
	ldr	s26, [x8]
	ld1.s	{ v26 }[1], [x6]
	ld1.s	{ v26 }[2], [x7]
	fadd.4s	v19, v19, v25
	ld1.s	{ v26 }[3], [x5]
	ldr	s25, [x12]
	ld1.s	{ v25 }[1], [x13]
	fadd.4s	v21, v21, v28
	ld1.s	{ v25 }[2], [x0]
	ld1.s	{ v25 }[3], [x17]
	fmul.4s	v25, v25, v25
	fadd.4s	v20, v20, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v23, v23, v25
	add	x10, x10, #4
	add	x3, x3, #128
	cmp	x10, #252
	b.lo	LBB0_24
; %bb.25:                               ; %direct.true79.i64.i.preheader
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	mov	x12, x20
LBB0_26:                                ; %direct.true79.i64.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s25, [x12], #4
	dup.2d	v26, x10
	add.2d	v26, v29, v26
	add.2d	v27, v26, v0
	add.2d	v28, v26, v3
	add.2d	v30, v26, v5
	add.2d	v26, v26, v7
	mov.d	x8, v26[1]
	fmov	x13, d26
	str	s25, [x13]
	str	s25, [x8]
	mov.d	x8, v30[1]
	fmov	x13, d30
	str	s25, [x13]
	str	s25, [x8]
	mov.d	x8, v28[1]
	fmov	x13, d28
	str	s25, [x13]
	mov.d	x13, v27[1]
	str	s25, [x8]
	fmov	x8, d27
	str	s25, [x8]
	str	s25, [x13]
	add	x10, x10, #32
	cmp	x10, #2, lsl #12                ; =8192
	b.ne	LBB0_26
; %bb.27:                               ; %direct.false80.i70.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	fadd.4s	v18, v18, v22
	fadd.4s	v17, v17, v19
	fadd.4s	v17, v17, v20
	fadd.4s	v18, v18, v21
	fadd.4s	v18, v18, v24
	fadd.4s	v17, v17, v23
	ldp	q20, q19, [sp, #464]            ; 32-byte Folded Reload
	fmul.4s	v17, v17, v20
	fmul.4s	v18, v18, v20
	fadd.4s	v18, v18, v19
	fadd.4s	v17, v17, v19
	fsqrt.4s	v17, v17
	fsqrt.4s	v18, v18
LBB0_28:                                ; %direct.true92.i71.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v19, x10
	shl.2d	v20, v19, #5
	orr.16b	v21, v20, v7
	orr.16b	v22, v20, v3
	orr.16b	v23, v20, v5
	orr.16b	v20, v20, v0
	add.2d	v24, v1, v20
	add.2d	v25, v1, v22
	add.2d	v26, v1, v21
	mov.d	x8, v26[1]
	add.2d	v27, v1, v23
	fmov	x12, d26
	mov.d	x13, v27[1]
	mov.d	x17, v25[1]
	fmov	x0, d27
	fmov	x3, d25
	mov.d	x5, v24[1]
	fmov	x6, d24
	ldr	s24, [x3]
	ld1.s	{ v24 }[1], [x17]
	ldr	s25, [x12]
	add.2d	v20, v29, v20
	ld1.s	{ v25 }[1], [x8]
	add.2d	v22, v29, v22
	add.2d	v21, v29, v21
	mov.d	x8, v21[1]
	ld1.s	{ v24 }[2], [x6]
	add.2d	v23, v29, v23
	fmov	x12, d21
	mov.d	x17, v23[1]
	ld1.s	{ v25 }[2], [x0]
	fmov	x0, d23
	mov.d	x3, v22[1]
	fmov	x6, d22
	ld1.s	{ v24 }[3], [x5]
	mov.d	x5, v20[1]
	ldr	s21, [x12]
	fmov	x12, d20
	ld1.s	{ v25 }[3], [x13]
	ld1.s	{ v21 }[1], [x8]
	ld1.s	{ v21 }[2], [x0]
	ld1.s	{ v21 }[3], [x17]
	ldr	s20, [x6]
	ld1.s	{ v20 }[1], [x3]
	ld1.s	{ v20 }[2], [x12]
	fdiv.4s	v22, v25, v17
	fdiv.4s	v23, v24, v18
	ld1.s	{ v20 }[3], [x5]
	shl.2d	v19, v19, #2
	add.2d	v24, v9, v2
	fmul.4s	v20, v23, v20
	add.2d	v23, v24, v19
	add.2d	v24, v9, v6
	add.2d	v25, v9, v4
	add.2d	v26, v9, v16
	add.2d	v26, v26, v19
	fmul.4s	v21, v22, v21
	mov.d	x8, v26[1]
	fmov	x12, d26
	str	s21, [x12]
	st1.s	{ v21 }[1], [x8]
	add.2d	v22, v25, v19
	mov.d	x8, v22[1]
	fmov	x12, d22
	st1.s	{ v21 }[2], [x12]
	add.2d	v19, v24, v19
	mov.d	x12, v19[1]
	fmov	x13, d19
	st1.s	{ v21 }[3], [x8]
	str	s20, [x13]
	mov.d	x8, v23[1]
	fmov	x13, d23
	st1.s	{ v20 }[1], [x12]
	st1.s	{ v20 }[2], [x13]
	st1.s	{ v20 }[3], [x8]
	add	x10, x10, #1
	cmp	x10, #256
	b.ne	LBB0_28
; %bb.29:                               ; %llm_rows.exit76.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	orr	w8, w28, #0x18
	dup.4s	v2, w8
	orr.16b	v6, v2, v10
	orr.16b	v16, v2, v11
	ushll2.2d	v2, v6, #10
	ushll2.2d	v4, v16, #10
	ushll.2d	v6, v6, #10
	ushll.2d	v16, v16, #10
	ldp	q30, q31, [sp, #160]            ; 32-byte Folded Reload
LBB0_30:                                ; %direct.true.i84.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v17, x10
	shl.2d	v18, v17, #2
	add.2d	v19, v8, v2
	add.2d	v19, v19, v18
	add.2d	v20, v8, v6
	add.2d	v20, v20, v18
	add.2d	v21, v8, v4
	add.2d	v21, v21, v18
	add.2d	v22, v8, v16
	add.2d	v18, v22, v18
	mov.d	x8, v18[1]
	fmov	x12, d18
	ldr	s18, [x12]
	mov.d	x12, v21[1]
	ldr	s22, [x8]
	fmov	x8, d21
	ldr	s21, [x8]
	ldr	s23, [x12]
	mov.d	x8, v20[1]
	fmov	x12, d20
	ldr	s20, [x12]
	ldr	s24, [x8]
	mov.d	x8, v19[1]
	fmov	x12, d19
	ldr	s19, [x12]
	ldr	s25, [x8]
	shl.2d	v17, v17, #5
	add.2d	v17, v1, v17
	add.2d	v26, v17, v0
	add.2d	v27, v17, v3
	add.2d	v28, v17, v5
	add.2d	v17, v17, v7
	mov.d	x8, v17[1]
	fmov	x12, d17
	str	s18, [x12]
	str	s22, [x8]
	mov.d	x8, v28[1]
	fmov	x12, d28
	str	s21, [x12]
	str	s23, [x8]
	mov.d	x8, v27[1]
	fmov	x12, d27
	str	s20, [x12]
	mov.d	x12, v26[1]
	str	s24, [x8]
	fmov	x8, d26
	str	s19, [x8]
	str	s25, [x12]
	add	x10, x10, #1
	cmp	x10, #256
	b.ne	LBB0_30
; %bb.31:                               ; %direct.false.i89.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	fmov	x8, d15
	ldr	s18, [x8]
	ld1.s	{ v18 }[1], [x30]
	fmov	x8, d14
	ld1.s	{ v18 }[2], [x8]
	fmov	x8, d31
	ld1.s	{ v18 }[3], [x26]
	fmov	x12, d30
	ldr	s17, [x8]
	ldr	x8, [sp, #432]                  ; 8-byte Folded Reload
	ld1.s	{ v17 }[1], [x8]
	ld1.s	{ v17 }[2], [x12]
	ldr	x8, [sp, #448]                  ; 8-byte Folded Reload
	ld1.s	{ v17 }[3], [x8]
	fmul.4s	v17, v17, v17
	fmul.4s	v18, v18, v18
	ldr	q19, [sp, #208]                 ; 16-byte Folded Reload
	fmov	x8, d19
	ldr	q19, [sp, #192]                 ; 16-byte Folded Reload
	fmov	x12, d19
	ldr	s20, [x8]
	ld1.s	{ v20 }[1], [x2]
	ld1.s	{ v20 }[2], [x12]
	ldp	q19, q21, [sp, #400]            ; 32-byte Folded Reload
	fmov	x8, d19
	ld1.s	{ v20 }[3], [x4]
	ldr	s19, [x8]
	ldr	x8, [sp, #240]                  ; 8-byte Folded Reload
	ld1.s	{ v19 }[1], [x8]
	fmov	x8, d21
	ld1.s	{ v19 }[2], [x8]
	ldr	x8, [sp, #256]                  ; 8-byte Folded Reload
	ld1.s	{ v19 }[3], [x8]
	fmul.4s	v19, v19, v19
	ldr	q21, [sp, #336]                 ; 16-byte Folded Reload
	fmov	x8, d21
	ldr	q21, [sp, #352]                 ; 16-byte Folded Reload
	fmov	x12, d21
	ldp	q21, q22, [sp, #368]            ; 32-byte Folded Reload
	fmov	x13, d21
	ldr	s21, [x13]
	ld1.s	{ v21 }[1], [x11]
	fmov	x13, d22
	ld1.s	{ v21 }[2], [x13]
	ld1.s	{ v21 }[3], [x15]
	ldr	s23, [x8]
	ld1.s	{ v23 }[1], [x27]
	ld1.s	{ v23 }[2], [x12]
	ld1.s	{ v23 }[3], [x25]
	fmul.4s	v22, v20, v20
	fmul.4s	v20, v23, v23
	fmul.4s	v21, v21, v21
	ldr	q23, [sp, #272]                 ; 16-byte Folded Reload
	fmov	x8, d23
	ldr	q23, [sp, #288]                 ; 16-byte Folded Reload
	fmov	x12, d23
	ldp	q23, q25, [sp, #304]            ; 32-byte Folded Reload
	fmov	x13, d23
	ldr	s24, [x13]
	ld1.s	{ v24 }[1], [x9]
	ldr	s23, [x8]
	ld1.s	{ v23 }[1], [x14]
	fmov	x8, d25
	ld1.s	{ v23 }[2], [x12]
	ld1.s	{ v23 }[3], [x1]
	fmul.4s	v23, v23, v23
	ld1.s	{ v24 }[2], [x8]
	ld1.s	{ v24 }[3], [x16]
	fmul.4s	v24, v24, v24
	mov	w3, #224                        ; =0xe0
LBB0_32:                                ; %direct.true40.i90.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sub	x8, x3, #96
	dup.2d	v25, x8
	add.2d	v25, v1, v25
	add.2d	v26, v25, v0
	add.2d	v27, v25, v3
	add.2d	v28, v25, v5
	add.2d	v25, v25, v7
	mov.d	x8, v25[1]
	fmov	x12, d25
	mov.d	x6, v28[1]
	fmov	x5, d28
	mov.d	x0, v27[1]
	fmov	x7, d27
	mov.d	x17, v26[1]
	fmov	x13, d26
	sub	x19, x3, #64
	ldr	s25, [x7]
	dup.2d	v26, x19
	add.2d	v27, v1, v26
	add.2d	v30, v27, v0
	add.2d	v28, v27, v3
	ldr	s26, [x12]
	add.2d	v31, v27, v5
	add.2d	v27, v27, v7
	mov.d	x7, v27[1]
	ld1.s	{ v25 }[1], [x0]
	mov.d	x0, v31[1]
	mov.d	x12, v28[1]
	ld1.s	{ v26 }[1], [x8]
	fmov	x8, d27
	fmov	x19, d28
	ldr	s27, [x19]
	fmov	x19, d31
	ld1.s	{ v27 }[1], [x12]
	mov.d	x12, v30[1]
	ldr	s28, [x8]
	sub	x8, x3, #32
	ld1.s	{ v28 }[1], [x7]
	dup.2d	v31, x8
	fmov	x8, d30
	add.2d	v30, v1, v31
	ld1.s	{ v25 }[2], [x13]
	add.2d	v31, v30, v0
	add.2d	v12, v30, v3
	add.2d	v13, v30, v5
	add.2d	v30, v30, v7
	ld1.s	{ v26 }[2], [x5]
	mov.d	x13, v30[1]
	mov.d	x5, v12[1]
	ld1.s	{ v27 }[2], [x8]
	fmov	x8, d12
	ldr	s12, [x8]
	mov.d	x8, v31[1]
	ld1.s	{ v28 }[2], [x19]
	fmov	x7, d30
	ld1.s	{ v12 }[1], [x5]
	fmov	x5, d31
	ld1.s	{ v12 }[2], [x5]
	mov.d	x5, v13[1]
	ldr	s30, [x7]
	fmov	x7, d13
	ld1.s	{ v25 }[3], [x17]
	ld1.s	{ v30 }[1], [x13]
	dup.2d	v31, x3
	ld1.s	{ v26 }[3], [x6]
	add.2d	v31, v1, v31
	add.2d	v13, v31, v7
	mov.d	x13, v13[1]
	ld1.s	{ v27 }[3], [x12]
	fmov	x12, d13
	add.2d	v13, v31, v5
	mov.d	x17, v13[1]
	ld1.s	{ v28 }[3], [x0]
	fmov	x0, d13
	add.2d	v13, v31, v3
	mov.d	x6, v13[1]
	ld1.s	{ v12 }[3], [x8]
	fmov	x8, d13
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	ld1.s	{ v30 }[2], [x7]
	fadd.4s	v18, v18, v25
	ld1.s	{ v30 }[3], [x5]
	add.2d	v25, v31, v0
	mov.d	x5, v25[1]
	fadd.4s	v17, v17, v26
	fmov	x7, d25
	fmul.4s	v25, v28, v28
	fmul.4s	v26, v27, v27
	fmul.4s	v27, v30, v30
	fmul.4s	v28, v12, v12
	fadd.4s	v22, v22, v26
	ldr	s26, [x8]
	ld1.s	{ v26 }[1], [x6]
	ld1.s	{ v26 }[2], [x7]
	fadd.4s	v19, v19, v25
	ld1.s	{ v26 }[3], [x5]
	ldr	s25, [x12]
	ld1.s	{ v25 }[1], [x13]
	fadd.4s	v21, v21, v28
	ld1.s	{ v25 }[2], [x0]
	ld1.s	{ v25 }[3], [x17]
	fmul.4s	v25, v25, v25
	fadd.4s	v20, v20, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v23, v23, v25
	add	x10, x10, #4
	add	x3, x3, #128
	cmp	x10, #252
	b.lo	LBB0_32
; %bb.33:                               ; %direct.true79.i101.i.preheader
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	mov	x12, x20
LBB0_34:                                ; %direct.true79.i101.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s25, [x12], #4
	dup.2d	v26, x10
	add.2d	v26, v29, v26
	add.2d	v27, v26, v0
	add.2d	v28, v26, v3
	add.2d	v30, v26, v5
	add.2d	v26, v26, v7
	mov.d	x8, v26[1]
	fmov	x13, d26
	str	s25, [x13]
	str	s25, [x8]
	mov.d	x8, v30[1]
	fmov	x13, d30
	str	s25, [x13]
	str	s25, [x8]
	mov.d	x8, v28[1]
	fmov	x13, d28
	str	s25, [x13]
	mov.d	x13, v27[1]
	str	s25, [x8]
	fmov	x8, d27
	str	s25, [x8]
	str	s25, [x13]
	add	x10, x10, #32
	cmp	x10, #2, lsl #12                ; =8192
	b.ne	LBB0_34
; %bb.35:                               ; %direct.false80.i107.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	fadd.4s	v18, v18, v22
	fadd.4s	v17, v17, v19
	fadd.4s	v17, v17, v20
	fadd.4s	v18, v18, v21
	fadd.4s	v18, v18, v24
	fadd.4s	v17, v17, v23
	ldp	q20, q19, [sp, #464]            ; 32-byte Folded Reload
	fmul.4s	v17, v17, v20
	fmul.4s	v18, v18, v20
	fadd.4s	v18, v18, v19
	fadd.4s	v17, v17, v19
	fsqrt.4s	v17, v17
	fsqrt.4s	v18, v18
LBB0_36:                                ; %direct.true92.i108.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v19, x10
	shl.2d	v20, v19, #5
	orr.16b	v21, v20, v7
	orr.16b	v22, v20, v3
	orr.16b	v23, v20, v5
	orr.16b	v20, v20, v0
	add.2d	v24, v1, v20
	add.2d	v25, v1, v22
	add.2d	v26, v1, v21
	mov.d	x8, v26[1]
	add.2d	v27, v1, v23
	fmov	x12, d26
	mov.d	x13, v27[1]
	mov.d	x17, v25[1]
	fmov	x0, d27
	fmov	x3, d25
	mov.d	x5, v24[1]
	fmov	x6, d24
	ldr	s24, [x3]
	ld1.s	{ v24 }[1], [x17]
	ldr	s25, [x12]
	add.2d	v20, v29, v20
	ld1.s	{ v25 }[1], [x8]
	add.2d	v22, v29, v22
	add.2d	v21, v29, v21
	mov.d	x8, v21[1]
	ld1.s	{ v24 }[2], [x6]
	add.2d	v23, v29, v23
	fmov	x12, d21
	mov.d	x17, v23[1]
	ld1.s	{ v25 }[2], [x0]
	fmov	x0, d23
	mov.d	x3, v22[1]
	fmov	x6, d22
	ld1.s	{ v24 }[3], [x5]
	mov.d	x5, v20[1]
	ldr	s21, [x12]
	fmov	x12, d20
	ld1.s	{ v25 }[3], [x13]
	ld1.s	{ v21 }[1], [x8]
	ld1.s	{ v21 }[2], [x0]
	ld1.s	{ v21 }[3], [x17]
	ldr	s20, [x6]
	ld1.s	{ v20 }[1], [x3]
	ld1.s	{ v20 }[2], [x12]
	fdiv.4s	v22, v25, v17
	fdiv.4s	v23, v24, v18
	ld1.s	{ v20 }[3], [x5]
	shl.2d	v19, v19, #2
	add.2d	v24, v9, v2
	fmul.4s	v20, v23, v20
	add.2d	v23, v24, v19
	add.2d	v24, v9, v6
	add.2d	v25, v9, v4
	add.2d	v26, v9, v16
	add.2d	v26, v26, v19
	fmul.4s	v21, v22, v21
	mov.d	x8, v26[1]
	fmov	x12, d26
	str	s21, [x12]
	st1.s	{ v21 }[1], [x8]
	add.2d	v22, v25, v19
	mov.d	x8, v22[1]
	fmov	x12, d22
	st1.s	{ v21 }[2], [x12]
	add.2d	v19, v24, v19
	mov.d	x12, v19[1]
	fmov	x13, d19
	st1.s	{ v21 }[3], [x8]
	str	s20, [x13]
	mov.d	x8, v23[1]
	fmov	x13, d23
	st1.s	{ v20 }[1], [x12]
	st1.s	{ v20 }[2], [x13]
	st1.s	{ v20 }[3], [x8]
	add	x10, x10, #1
	cmp	x10, #256
	b.ne	LBB0_36
; %bb.37:                               ; %llm_rows.exit113.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	orr	w8, w28, #0x20
	dup.4s	v2, w8
	orr.16b	v6, v2, v10
	orr.16b	v16, v2, v11
	ushll2.2d	v2, v6, #10
	ushll2.2d	v4, v16, #10
	ushll.2d	v6, v6, #10
	ushll.2d	v16, v16, #10
	ldp	q30, q31, [sp, #160]            ; 32-byte Folded Reload
LBB0_38:                                ; %direct.true.i121.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v17, x10
	shl.2d	v18, v17, #2
	add.2d	v19, v8, v2
	add.2d	v19, v19, v18
	add.2d	v20, v8, v6
	add.2d	v20, v20, v18
	add.2d	v21, v8, v4
	add.2d	v21, v21, v18
	add.2d	v22, v8, v16
	add.2d	v18, v22, v18
	mov.d	x8, v18[1]
	fmov	x12, d18
	ldr	s18, [x12]
	mov.d	x12, v21[1]
	ldr	s22, [x8]
	fmov	x8, d21
	ldr	s21, [x8]
	ldr	s23, [x12]
	mov.d	x8, v20[1]
	fmov	x12, d20
	ldr	s20, [x12]
	ldr	s24, [x8]
	mov.d	x8, v19[1]
	fmov	x12, d19
	ldr	s19, [x12]
	ldr	s25, [x8]
	shl.2d	v17, v17, #5
	add.2d	v17, v1, v17
	add.2d	v26, v17, v0
	add.2d	v27, v17, v3
	add.2d	v28, v17, v5
	add.2d	v17, v17, v7
	mov.d	x8, v17[1]
	fmov	x12, d17
	str	s18, [x12]
	str	s22, [x8]
	mov.d	x8, v28[1]
	fmov	x12, d28
	str	s21, [x12]
	str	s23, [x8]
	mov.d	x8, v27[1]
	fmov	x12, d27
	str	s20, [x12]
	mov.d	x12, v26[1]
	str	s24, [x8]
	fmov	x8, d26
	str	s19, [x8]
	str	s25, [x12]
	add	x10, x10, #1
	cmp	x10, #256
	b.ne	LBB0_38
; %bb.39:                               ; %direct.false.i126.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	fmov	x8, d15
	ldr	s18, [x8]
	ld1.s	{ v18 }[1], [x30]
	fmov	x8, d14
	ld1.s	{ v18 }[2], [x8]
	fmov	x8, d31
	ld1.s	{ v18 }[3], [x26]
	fmov	x12, d30
	ldr	s17, [x8]
	ldr	x8, [sp, #432]                  ; 8-byte Folded Reload
	ld1.s	{ v17 }[1], [x8]
	ld1.s	{ v17 }[2], [x12]
	ldr	x8, [sp, #448]                  ; 8-byte Folded Reload
	ld1.s	{ v17 }[3], [x8]
	fmul.4s	v17, v17, v17
	fmul.4s	v18, v18, v18
	ldr	q19, [sp, #208]                 ; 16-byte Folded Reload
	fmov	x8, d19
	ldr	q19, [sp, #192]                 ; 16-byte Folded Reload
	fmov	x12, d19
	ldr	s20, [x8]
	ld1.s	{ v20 }[1], [x2]
	ld1.s	{ v20 }[2], [x12]
	ldp	q19, q21, [sp, #400]            ; 32-byte Folded Reload
	fmov	x8, d19
	ld1.s	{ v20 }[3], [x4]
	ldr	s19, [x8]
	ldr	x8, [sp, #240]                  ; 8-byte Folded Reload
	ld1.s	{ v19 }[1], [x8]
	fmov	x8, d21
	ld1.s	{ v19 }[2], [x8]
	ldr	x8, [sp, #256]                  ; 8-byte Folded Reload
	ld1.s	{ v19 }[3], [x8]
	fmul.4s	v19, v19, v19
	ldr	q21, [sp, #336]                 ; 16-byte Folded Reload
	fmov	x8, d21
	ldr	q21, [sp, #352]                 ; 16-byte Folded Reload
	fmov	x12, d21
	ldp	q21, q22, [sp, #368]            ; 32-byte Folded Reload
	fmov	x13, d21
	ldr	s21, [x13]
	ld1.s	{ v21 }[1], [x11]
	fmov	x13, d22
	ld1.s	{ v21 }[2], [x13]
	ld1.s	{ v21 }[3], [x15]
	ldr	s23, [x8]
	ld1.s	{ v23 }[1], [x27]
	ld1.s	{ v23 }[2], [x12]
	ld1.s	{ v23 }[3], [x25]
	fmul.4s	v22, v20, v20
	fmul.4s	v20, v23, v23
	fmul.4s	v21, v21, v21
	ldr	q23, [sp, #272]                 ; 16-byte Folded Reload
	fmov	x8, d23
	ldr	q23, [sp, #288]                 ; 16-byte Folded Reload
	fmov	x12, d23
	ldp	q23, q25, [sp, #304]            ; 32-byte Folded Reload
	fmov	x13, d23
	ldr	s24, [x13]
	ld1.s	{ v24 }[1], [x9]
	ldr	s23, [x8]
	ld1.s	{ v23 }[1], [x14]
	fmov	x8, d25
	ld1.s	{ v23 }[2], [x12]
	ld1.s	{ v23 }[3], [x1]
	fmul.4s	v23, v23, v23
	ld1.s	{ v24 }[2], [x8]
	ld1.s	{ v24 }[3], [x16]
	fmul.4s	v24, v24, v24
	mov	w3, #224                        ; =0xe0
LBB0_40:                                ; %direct.true40.i127.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sub	x8, x3, #96
	dup.2d	v25, x8
	add.2d	v25, v1, v25
	add.2d	v26, v25, v0
	add.2d	v27, v25, v3
	add.2d	v28, v25, v5
	add.2d	v25, v25, v7
	mov.d	x8, v25[1]
	fmov	x12, d25
	mov.d	x6, v28[1]
	fmov	x5, d28
	mov.d	x0, v27[1]
	fmov	x7, d27
	mov.d	x17, v26[1]
	fmov	x13, d26
	sub	x19, x3, #64
	ldr	s25, [x7]
	dup.2d	v26, x19
	add.2d	v27, v1, v26
	add.2d	v30, v27, v0
	add.2d	v28, v27, v3
	ldr	s26, [x12]
	add.2d	v31, v27, v5
	add.2d	v27, v27, v7
	mov.d	x7, v27[1]
	ld1.s	{ v25 }[1], [x0]
	mov.d	x0, v31[1]
	mov.d	x12, v28[1]
	ld1.s	{ v26 }[1], [x8]
	fmov	x8, d27
	fmov	x19, d28
	ldr	s27, [x19]
	fmov	x19, d31
	ld1.s	{ v27 }[1], [x12]
	mov.d	x12, v30[1]
	ldr	s28, [x8]
	sub	x8, x3, #32
	ld1.s	{ v28 }[1], [x7]
	dup.2d	v31, x8
	fmov	x8, d30
	add.2d	v30, v1, v31
	ld1.s	{ v25 }[2], [x13]
	add.2d	v31, v30, v0
	add.2d	v12, v30, v3
	add.2d	v13, v30, v5
	add.2d	v30, v30, v7
	ld1.s	{ v26 }[2], [x5]
	mov.d	x13, v30[1]
	mov.d	x5, v12[1]
	ld1.s	{ v27 }[2], [x8]
	fmov	x8, d12
	ldr	s12, [x8]
	mov.d	x8, v31[1]
	ld1.s	{ v28 }[2], [x19]
	fmov	x7, d30
	ld1.s	{ v12 }[1], [x5]
	fmov	x5, d31
	ld1.s	{ v12 }[2], [x5]
	mov.d	x5, v13[1]
	ldr	s30, [x7]
	fmov	x7, d13
	ld1.s	{ v25 }[3], [x17]
	ld1.s	{ v30 }[1], [x13]
	dup.2d	v31, x3
	ld1.s	{ v26 }[3], [x6]
	add.2d	v31, v1, v31
	add.2d	v13, v31, v7
	mov.d	x13, v13[1]
	ld1.s	{ v27 }[3], [x12]
	fmov	x12, d13
	add.2d	v13, v31, v5
	mov.d	x17, v13[1]
	ld1.s	{ v28 }[3], [x0]
	fmov	x0, d13
	add.2d	v13, v31, v3
	mov.d	x6, v13[1]
	ld1.s	{ v12 }[3], [x8]
	fmov	x8, d13
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	ld1.s	{ v30 }[2], [x7]
	fadd.4s	v18, v18, v25
	ld1.s	{ v30 }[3], [x5]
	add.2d	v25, v31, v0
	mov.d	x5, v25[1]
	fadd.4s	v17, v17, v26
	fmov	x7, d25
	fmul.4s	v25, v28, v28
	fmul.4s	v26, v27, v27
	fmul.4s	v27, v30, v30
	fmul.4s	v28, v12, v12
	fadd.4s	v22, v22, v26
	ldr	s26, [x8]
	ld1.s	{ v26 }[1], [x6]
	ld1.s	{ v26 }[2], [x7]
	fadd.4s	v19, v19, v25
	ld1.s	{ v26 }[3], [x5]
	ldr	s25, [x12]
	ld1.s	{ v25 }[1], [x13]
	fadd.4s	v21, v21, v28
	ld1.s	{ v25 }[2], [x0]
	ld1.s	{ v25 }[3], [x17]
	fmul.4s	v25, v25, v25
	fadd.4s	v20, v20, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v23, v23, v25
	add	x10, x10, #4
	add	x3, x3, #128
	cmp	x10, #252
	b.lo	LBB0_40
; %bb.41:                               ; %direct.true79.i138.i.preheader
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	mov	x12, x20
LBB0_42:                                ; %direct.true79.i138.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s25, [x12], #4
	dup.2d	v26, x10
	add.2d	v26, v29, v26
	add.2d	v27, v26, v0
	add.2d	v28, v26, v3
	add.2d	v30, v26, v5
	add.2d	v26, v26, v7
	mov.d	x8, v26[1]
	fmov	x13, d26
	str	s25, [x13]
	str	s25, [x8]
	mov.d	x8, v30[1]
	fmov	x13, d30
	str	s25, [x13]
	str	s25, [x8]
	mov.d	x8, v28[1]
	fmov	x13, d28
	str	s25, [x13]
	mov.d	x13, v27[1]
	str	s25, [x8]
	fmov	x8, d27
	str	s25, [x8]
	str	s25, [x13]
	add	x10, x10, #32
	cmp	x10, #2, lsl #12                ; =8192
	b.ne	LBB0_42
; %bb.43:                               ; %direct.false80.i144.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	fadd.4s	v18, v18, v22
	fadd.4s	v17, v17, v19
	fadd.4s	v17, v17, v20
	fadd.4s	v18, v18, v21
	fadd.4s	v18, v18, v24
	fadd.4s	v17, v17, v23
	ldp	q20, q19, [sp, #464]            ; 32-byte Folded Reload
	fmul.4s	v17, v17, v20
	fmul.4s	v18, v18, v20
	fadd.4s	v18, v18, v19
	fadd.4s	v17, v17, v19
	fsqrt.4s	v17, v17
	fsqrt.4s	v18, v18
LBB0_44:                                ; %direct.true92.i145.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v19, x10
	shl.2d	v20, v19, #5
	orr.16b	v21, v20, v7
	orr.16b	v22, v20, v3
	orr.16b	v23, v20, v5
	orr.16b	v20, v20, v0
	add.2d	v24, v1, v20
	add.2d	v25, v1, v22
	add.2d	v26, v1, v21
	mov.d	x8, v26[1]
	add.2d	v27, v1, v23
	fmov	x12, d26
	mov.d	x13, v27[1]
	mov.d	x17, v25[1]
	fmov	x0, d27
	fmov	x3, d25
	mov.d	x5, v24[1]
	fmov	x6, d24
	ldr	s24, [x3]
	ld1.s	{ v24 }[1], [x17]
	ldr	s25, [x12]
	add.2d	v20, v29, v20
	ld1.s	{ v25 }[1], [x8]
	add.2d	v22, v29, v22
	add.2d	v21, v29, v21
	mov.d	x8, v21[1]
	ld1.s	{ v24 }[2], [x6]
	add.2d	v23, v29, v23
	fmov	x12, d21
	mov.d	x17, v23[1]
	ld1.s	{ v25 }[2], [x0]
	fmov	x0, d23
	mov.d	x3, v22[1]
	fmov	x6, d22
	ld1.s	{ v24 }[3], [x5]
	mov.d	x5, v20[1]
	ldr	s21, [x12]
	fmov	x12, d20
	ld1.s	{ v25 }[3], [x13]
	ld1.s	{ v21 }[1], [x8]
	ld1.s	{ v21 }[2], [x0]
	ld1.s	{ v21 }[3], [x17]
	ldr	s20, [x6]
	ld1.s	{ v20 }[1], [x3]
	ld1.s	{ v20 }[2], [x12]
	fdiv.4s	v22, v25, v17
	fdiv.4s	v23, v24, v18
	ld1.s	{ v20 }[3], [x5]
	shl.2d	v19, v19, #2
	add.2d	v24, v9, v2
	fmul.4s	v20, v23, v20
	add.2d	v23, v24, v19
	add.2d	v24, v9, v6
	add.2d	v25, v9, v4
	add.2d	v26, v9, v16
	add.2d	v26, v26, v19
	fmul.4s	v21, v22, v21
	mov.d	x8, v26[1]
	fmov	x12, d26
	str	s21, [x12]
	st1.s	{ v21 }[1], [x8]
	add.2d	v22, v25, v19
	mov.d	x8, v22[1]
	fmov	x12, d22
	st1.s	{ v21 }[2], [x12]
	add.2d	v19, v24, v19
	mov.d	x12, v19[1]
	fmov	x13, d19
	st1.s	{ v21 }[3], [x8]
	str	s20, [x13]
	mov.d	x8, v23[1]
	fmov	x13, d23
	st1.s	{ v20 }[1], [x12]
	st1.s	{ v20 }[2], [x13]
	st1.s	{ v20 }[3], [x8]
	add	x10, x10, #1
	cmp	x10, #256
	b.ne	LBB0_44
; %bb.45:                               ; %llm_rows.exit150.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	mov	w8, #40                         ; =0x28
	orr	w8, w28, w8
	dup.4s	v2, w8
	orr.16b	v6, v2, v10
	orr.16b	v16, v2, v11
	ushll2.2d	v2, v6, #10
	ushll2.2d	v4, v16, #10
	ushll.2d	v6, v6, #10
	ushll.2d	v16, v16, #10
	ldp	q30, q31, [sp, #160]            ; 32-byte Folded Reload
LBB0_46:                                ; %direct.true.i158.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v17, x10
	shl.2d	v18, v17, #2
	add.2d	v19, v8, v2
	add.2d	v19, v19, v18
	add.2d	v20, v8, v6
	add.2d	v20, v20, v18
	add.2d	v21, v8, v4
	add.2d	v21, v21, v18
	add.2d	v22, v8, v16
	add.2d	v18, v22, v18
	mov.d	x8, v18[1]
	fmov	x12, d18
	ldr	s18, [x12]
	mov.d	x12, v21[1]
	ldr	s22, [x8]
	fmov	x8, d21
	ldr	s21, [x8]
	ldr	s23, [x12]
	mov.d	x8, v20[1]
	fmov	x12, d20
	ldr	s20, [x12]
	ldr	s24, [x8]
	mov.d	x8, v19[1]
	fmov	x12, d19
	ldr	s19, [x12]
	ldr	s25, [x8]
	shl.2d	v17, v17, #5
	add.2d	v17, v1, v17
	add.2d	v26, v17, v0
	add.2d	v27, v17, v3
	add.2d	v28, v17, v5
	add.2d	v17, v17, v7
	mov.d	x8, v17[1]
	fmov	x12, d17
	str	s18, [x12]
	str	s22, [x8]
	mov.d	x8, v28[1]
	fmov	x12, d28
	str	s21, [x12]
	str	s23, [x8]
	mov.d	x8, v27[1]
	fmov	x12, d27
	str	s20, [x12]
	mov.d	x12, v26[1]
	str	s24, [x8]
	fmov	x8, d26
	str	s19, [x8]
	str	s25, [x12]
	add	x10, x10, #1
	cmp	x10, #256
	b.ne	LBB0_46
; %bb.47:                               ; %direct.false.i163.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	fmov	x8, d15
	ldr	s18, [x8]
	ld1.s	{ v18 }[1], [x30]
	fmov	x8, d14
	ld1.s	{ v18 }[2], [x8]
	fmov	x8, d31
	ld1.s	{ v18 }[3], [x26]
	fmov	x12, d30
	ldr	s17, [x8]
	ldr	x8, [sp, #432]                  ; 8-byte Folded Reload
	ld1.s	{ v17 }[1], [x8]
	ld1.s	{ v17 }[2], [x12]
	ldr	x8, [sp, #448]                  ; 8-byte Folded Reload
	ld1.s	{ v17 }[3], [x8]
	fmul.4s	v17, v17, v17
	fmul.4s	v18, v18, v18
	ldr	q19, [sp, #208]                 ; 16-byte Folded Reload
	fmov	x8, d19
	ldr	q19, [sp, #192]                 ; 16-byte Folded Reload
	fmov	x12, d19
	ldr	s20, [x8]
	ld1.s	{ v20 }[1], [x2]
	ld1.s	{ v20 }[2], [x12]
	ldp	q19, q21, [sp, #400]            ; 32-byte Folded Reload
	fmov	x8, d19
	ld1.s	{ v20 }[3], [x4]
	ldr	s19, [x8]
	ldr	x8, [sp, #240]                  ; 8-byte Folded Reload
	ld1.s	{ v19 }[1], [x8]
	fmov	x8, d21
	ld1.s	{ v19 }[2], [x8]
	ldr	x8, [sp, #256]                  ; 8-byte Folded Reload
	ld1.s	{ v19 }[3], [x8]
	fmul.4s	v19, v19, v19
	ldr	q21, [sp, #336]                 ; 16-byte Folded Reload
	fmov	x8, d21
	ldr	q21, [sp, #352]                 ; 16-byte Folded Reload
	fmov	x12, d21
	ldp	q21, q22, [sp, #368]            ; 32-byte Folded Reload
	fmov	x13, d21
	ldr	s21, [x13]
	ld1.s	{ v21 }[1], [x11]
	fmov	x13, d22
	ld1.s	{ v21 }[2], [x13]
	ld1.s	{ v21 }[3], [x15]
	ldr	s23, [x8]
	ld1.s	{ v23 }[1], [x27]
	ld1.s	{ v23 }[2], [x12]
	ld1.s	{ v23 }[3], [x25]
	fmul.4s	v22, v20, v20
	fmul.4s	v20, v23, v23
	fmul.4s	v21, v21, v21
	ldr	q23, [sp, #272]                 ; 16-byte Folded Reload
	fmov	x8, d23
	ldr	q23, [sp, #288]                 ; 16-byte Folded Reload
	fmov	x12, d23
	ldp	q23, q25, [sp, #304]            ; 32-byte Folded Reload
	fmov	x13, d23
	ldr	s24, [x13]
	ld1.s	{ v24 }[1], [x9]
	ldr	s23, [x8]
	ld1.s	{ v23 }[1], [x14]
	fmov	x8, d25
	ld1.s	{ v23 }[2], [x12]
	ld1.s	{ v23 }[3], [x1]
	fmul.4s	v23, v23, v23
	ld1.s	{ v24 }[2], [x8]
	ld1.s	{ v24 }[3], [x16]
	fmul.4s	v24, v24, v24
	mov	w3, #224                        ; =0xe0
LBB0_48:                                ; %direct.true40.i164.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sub	x8, x3, #96
	dup.2d	v25, x8
	add.2d	v25, v1, v25
	add.2d	v26, v25, v0
	add.2d	v27, v25, v3
	add.2d	v28, v25, v5
	add.2d	v25, v25, v7
	mov.d	x8, v25[1]
	fmov	x12, d25
	mov.d	x6, v28[1]
	fmov	x5, d28
	mov.d	x0, v27[1]
	fmov	x7, d27
	mov.d	x17, v26[1]
	fmov	x13, d26
	sub	x19, x3, #64
	ldr	s25, [x7]
	dup.2d	v26, x19
	add.2d	v27, v1, v26
	add.2d	v30, v27, v0
	add.2d	v28, v27, v3
	ldr	s26, [x12]
	add.2d	v31, v27, v5
	add.2d	v27, v27, v7
	mov.d	x7, v27[1]
	ld1.s	{ v25 }[1], [x0]
	mov.d	x0, v31[1]
	mov.d	x12, v28[1]
	ld1.s	{ v26 }[1], [x8]
	fmov	x8, d27
	fmov	x19, d28
	ldr	s27, [x19]
	fmov	x19, d31
	ld1.s	{ v27 }[1], [x12]
	mov.d	x12, v30[1]
	ldr	s28, [x8]
	sub	x8, x3, #32
	ld1.s	{ v28 }[1], [x7]
	dup.2d	v31, x8
	fmov	x8, d30
	add.2d	v30, v1, v31
	ld1.s	{ v25 }[2], [x13]
	add.2d	v31, v30, v0
	add.2d	v12, v30, v3
	add.2d	v13, v30, v5
	add.2d	v30, v30, v7
	ld1.s	{ v26 }[2], [x5]
	mov.d	x13, v30[1]
	mov.d	x5, v12[1]
	ld1.s	{ v27 }[2], [x8]
	fmov	x8, d12
	ldr	s12, [x8]
	mov.d	x8, v31[1]
	ld1.s	{ v28 }[2], [x19]
	fmov	x7, d30
	ld1.s	{ v12 }[1], [x5]
	fmov	x5, d31
	ld1.s	{ v12 }[2], [x5]
	mov.d	x5, v13[1]
	ldr	s30, [x7]
	fmov	x7, d13
	ld1.s	{ v25 }[3], [x17]
	ld1.s	{ v30 }[1], [x13]
	dup.2d	v31, x3
	ld1.s	{ v26 }[3], [x6]
	add.2d	v31, v1, v31
	add.2d	v13, v31, v7
	mov.d	x13, v13[1]
	ld1.s	{ v27 }[3], [x12]
	fmov	x12, d13
	add.2d	v13, v31, v5
	mov.d	x17, v13[1]
	ld1.s	{ v28 }[3], [x0]
	fmov	x0, d13
	add.2d	v13, v31, v3
	mov.d	x6, v13[1]
	ld1.s	{ v12 }[3], [x8]
	fmov	x8, d13
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	ld1.s	{ v30 }[2], [x7]
	fadd.4s	v18, v18, v25
	ld1.s	{ v30 }[3], [x5]
	add.2d	v25, v31, v0
	mov.d	x5, v25[1]
	fadd.4s	v17, v17, v26
	fmov	x7, d25
	fmul.4s	v25, v28, v28
	fmul.4s	v26, v27, v27
	fmul.4s	v27, v30, v30
	fmul.4s	v28, v12, v12
	fadd.4s	v22, v22, v26
	ldr	s26, [x8]
	ld1.s	{ v26 }[1], [x6]
	ld1.s	{ v26 }[2], [x7]
	fadd.4s	v19, v19, v25
	ld1.s	{ v26 }[3], [x5]
	ldr	s25, [x12]
	ld1.s	{ v25 }[1], [x13]
	fadd.4s	v21, v21, v28
	ld1.s	{ v25 }[2], [x0]
	ld1.s	{ v25 }[3], [x17]
	fmul.4s	v25, v25, v25
	fadd.4s	v20, v20, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v23, v23, v25
	add	x10, x10, #4
	add	x3, x3, #128
	cmp	x10, #252
	b.lo	LBB0_48
; %bb.49:                               ; %direct.true79.i175.i.preheader
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	mov	x12, x20
LBB0_50:                                ; %direct.true79.i175.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s25, [x12], #4
	dup.2d	v26, x10
	add.2d	v26, v29, v26
	add.2d	v27, v26, v0
	add.2d	v28, v26, v3
	add.2d	v30, v26, v5
	add.2d	v26, v26, v7
	mov.d	x8, v26[1]
	fmov	x13, d26
	str	s25, [x13]
	str	s25, [x8]
	mov.d	x8, v30[1]
	fmov	x13, d30
	str	s25, [x13]
	str	s25, [x8]
	mov.d	x8, v28[1]
	fmov	x13, d28
	str	s25, [x13]
	mov.d	x13, v27[1]
	str	s25, [x8]
	fmov	x8, d27
	str	s25, [x8]
	str	s25, [x13]
	add	x10, x10, #32
	cmp	x10, #2, lsl #12                ; =8192
	b.ne	LBB0_50
; %bb.51:                               ; %direct.false80.i181.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	fadd.4s	v18, v18, v22
	fadd.4s	v17, v17, v19
	fadd.4s	v17, v17, v20
	fadd.4s	v18, v18, v21
	fadd.4s	v18, v18, v24
	fadd.4s	v17, v17, v23
	ldp	q20, q19, [sp, #464]            ; 32-byte Folded Reload
	fmul.4s	v17, v17, v20
	fmul.4s	v18, v18, v20
	fadd.4s	v18, v18, v19
	fadd.4s	v17, v17, v19
	fsqrt.4s	v17, v17
	fsqrt.4s	v18, v18
LBB0_52:                                ; %direct.true92.i182.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v19, x10
	shl.2d	v20, v19, #5
	orr.16b	v21, v20, v7
	orr.16b	v22, v20, v3
	orr.16b	v23, v20, v5
	orr.16b	v20, v20, v0
	add.2d	v24, v1, v20
	add.2d	v25, v1, v22
	add.2d	v26, v1, v21
	mov.d	x8, v26[1]
	add.2d	v27, v1, v23
	fmov	x12, d26
	mov.d	x13, v27[1]
	mov.d	x17, v25[1]
	fmov	x0, d27
	fmov	x3, d25
	mov.d	x5, v24[1]
	fmov	x6, d24
	ldr	s24, [x3]
	ld1.s	{ v24 }[1], [x17]
	ldr	s25, [x12]
	add.2d	v20, v29, v20
	ld1.s	{ v25 }[1], [x8]
	add.2d	v22, v29, v22
	add.2d	v21, v29, v21
	mov.d	x8, v21[1]
	ld1.s	{ v24 }[2], [x6]
	add.2d	v23, v29, v23
	fmov	x12, d21
	mov.d	x17, v23[1]
	ld1.s	{ v25 }[2], [x0]
	fmov	x0, d23
	mov.d	x3, v22[1]
	fmov	x6, d22
	ld1.s	{ v24 }[3], [x5]
	mov.d	x5, v20[1]
	ldr	s21, [x12]
	fmov	x12, d20
	ld1.s	{ v25 }[3], [x13]
	ld1.s	{ v21 }[1], [x8]
	ld1.s	{ v21 }[2], [x0]
	ld1.s	{ v21 }[3], [x17]
	ldr	s20, [x6]
	ld1.s	{ v20 }[1], [x3]
	ld1.s	{ v20 }[2], [x12]
	fdiv.4s	v22, v25, v17
	fdiv.4s	v23, v24, v18
	ld1.s	{ v20 }[3], [x5]
	shl.2d	v19, v19, #2
	add.2d	v24, v9, v2
	fmul.4s	v20, v23, v20
	add.2d	v23, v24, v19
	add.2d	v24, v9, v6
	add.2d	v25, v9, v4
	add.2d	v26, v9, v16
	add.2d	v26, v26, v19
	fmul.4s	v21, v22, v21
	mov.d	x8, v26[1]
	fmov	x12, d26
	str	s21, [x12]
	st1.s	{ v21 }[1], [x8]
	add.2d	v22, v25, v19
	mov.d	x8, v22[1]
	fmov	x12, d22
	st1.s	{ v21 }[2], [x12]
	add.2d	v19, v24, v19
	mov.d	x12, v19[1]
	fmov	x13, d19
	st1.s	{ v21 }[3], [x8]
	str	s20, [x13]
	mov.d	x8, v23[1]
	fmov	x13, d23
	st1.s	{ v20 }[1], [x12]
	st1.s	{ v20 }[2], [x13]
	st1.s	{ v20 }[3], [x8]
	add	x10, x10, #1
	cmp	x10, #256
	b.ne	LBB0_52
; %bb.53:                               ; %llm_rows.exit187.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	orr	w8, w28, #0x30
	dup.4s	v2, w8
	orr.16b	v6, v2, v10
	orr.16b	v16, v2, v11
	ushll2.2d	v2, v6, #10
	ushll2.2d	v4, v16, #10
	ushll.2d	v6, v6, #10
	ushll.2d	v16, v16, #10
	ldp	q30, q31, [sp, #160]            ; 32-byte Folded Reload
LBB0_54:                                ; %direct.true.i195.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v17, x10
	shl.2d	v18, v17, #2
	add.2d	v19, v8, v2
	add.2d	v19, v19, v18
	add.2d	v20, v8, v6
	add.2d	v20, v20, v18
	add.2d	v21, v8, v4
	add.2d	v21, v21, v18
	add.2d	v22, v8, v16
	add.2d	v18, v22, v18
	mov.d	x8, v18[1]
	fmov	x12, d18
	ldr	s18, [x12]
	mov.d	x12, v21[1]
	ldr	s22, [x8]
	fmov	x8, d21
	ldr	s21, [x8]
	ldr	s23, [x12]
	mov.d	x8, v20[1]
	fmov	x12, d20
	ldr	s20, [x12]
	ldr	s24, [x8]
	mov.d	x8, v19[1]
	fmov	x12, d19
	ldr	s19, [x12]
	ldr	s25, [x8]
	shl.2d	v17, v17, #5
	add.2d	v17, v1, v17
	add.2d	v26, v17, v0
	add.2d	v27, v17, v3
	add.2d	v28, v17, v5
	add.2d	v17, v17, v7
	mov.d	x8, v17[1]
	fmov	x12, d17
	str	s18, [x12]
	str	s22, [x8]
	mov.d	x8, v28[1]
	fmov	x12, d28
	str	s21, [x12]
	str	s23, [x8]
	mov.d	x8, v27[1]
	fmov	x12, d27
	str	s20, [x12]
	mov.d	x12, v26[1]
	str	s24, [x8]
	fmov	x8, d26
	str	s19, [x8]
	str	s25, [x12]
	add	x10, x10, #1
	cmp	x10, #256
	b.ne	LBB0_54
; %bb.55:                               ; %direct.false.i200.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	fmov	x8, d15
	ldr	s18, [x8]
	ld1.s	{ v18 }[1], [x30]
	fmov	x8, d14
	ld1.s	{ v18 }[2], [x8]
	fmov	x8, d31
	ld1.s	{ v18 }[3], [x26]
	fmov	x12, d30
	ldr	s17, [x8]
	ldr	x8, [sp, #432]                  ; 8-byte Folded Reload
	ld1.s	{ v17 }[1], [x8]
	ld1.s	{ v17 }[2], [x12]
	ldr	x8, [sp, #448]                  ; 8-byte Folded Reload
	ld1.s	{ v17 }[3], [x8]
	fmul.4s	v17, v17, v17
	fmul.4s	v18, v18, v18
	ldr	q19, [sp, #208]                 ; 16-byte Folded Reload
	fmov	x8, d19
	ldr	q19, [sp, #192]                 ; 16-byte Folded Reload
	fmov	x12, d19
	ldr	s20, [x8]
	ld1.s	{ v20 }[1], [x2]
	ld1.s	{ v20 }[2], [x12]
	ldp	q19, q21, [sp, #400]            ; 32-byte Folded Reload
	fmov	x8, d19
	ld1.s	{ v20 }[3], [x4]
	ldr	s19, [x8]
	ldr	x8, [sp, #240]                  ; 8-byte Folded Reload
	ld1.s	{ v19 }[1], [x8]
	fmov	x8, d21
	ld1.s	{ v19 }[2], [x8]
	ldr	x8, [sp, #256]                  ; 8-byte Folded Reload
	ld1.s	{ v19 }[3], [x8]
	fmul.4s	v19, v19, v19
	ldr	q21, [sp, #336]                 ; 16-byte Folded Reload
	fmov	x8, d21
	ldr	q21, [sp, #352]                 ; 16-byte Folded Reload
	fmov	x12, d21
	ldp	q21, q22, [sp, #368]            ; 32-byte Folded Reload
	fmov	x13, d21
	ldr	s21, [x13]
	ld1.s	{ v21 }[1], [x11]
	fmov	x13, d22
	ld1.s	{ v21 }[2], [x13]
	ld1.s	{ v21 }[3], [x15]
	ldr	s23, [x8]
	ld1.s	{ v23 }[1], [x27]
	ld1.s	{ v23 }[2], [x12]
	ld1.s	{ v23 }[3], [x25]
	fmul.4s	v22, v20, v20
	fmul.4s	v20, v23, v23
	fmul.4s	v21, v21, v21
	ldr	q23, [sp, #272]                 ; 16-byte Folded Reload
	fmov	x8, d23
	ldr	q23, [sp, #288]                 ; 16-byte Folded Reload
	fmov	x12, d23
	ldp	q23, q25, [sp, #304]            ; 32-byte Folded Reload
	fmov	x13, d23
	ldr	s24, [x13]
	ld1.s	{ v24 }[1], [x9]
	ldr	s23, [x8]
	ld1.s	{ v23 }[1], [x14]
	fmov	x8, d25
	ld1.s	{ v23 }[2], [x12]
	ld1.s	{ v23 }[3], [x1]
	fmul.4s	v23, v23, v23
	ld1.s	{ v24 }[2], [x8]
	ld1.s	{ v24 }[3], [x16]
	fmul.4s	v24, v24, v24
	mov	w3, #224                        ; =0xe0
LBB0_56:                                ; %direct.true40.i201.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sub	x8, x3, #96
	dup.2d	v25, x8
	add.2d	v25, v1, v25
	add.2d	v26, v25, v0
	add.2d	v27, v25, v3
	add.2d	v28, v25, v5
	add.2d	v25, v25, v7
	mov.d	x8, v25[1]
	fmov	x12, d25
	mov.d	x6, v28[1]
	fmov	x5, d28
	mov.d	x0, v27[1]
	fmov	x7, d27
	mov.d	x17, v26[1]
	fmov	x13, d26
	sub	x19, x3, #64
	ldr	s25, [x7]
	dup.2d	v26, x19
	add.2d	v27, v1, v26
	add.2d	v30, v27, v0
	add.2d	v28, v27, v3
	ldr	s26, [x12]
	add.2d	v31, v27, v5
	add.2d	v27, v27, v7
	mov.d	x7, v27[1]
	ld1.s	{ v25 }[1], [x0]
	mov.d	x0, v31[1]
	mov.d	x12, v28[1]
	ld1.s	{ v26 }[1], [x8]
	fmov	x8, d27
	fmov	x19, d28
	ldr	s27, [x19]
	fmov	x19, d31
	ld1.s	{ v27 }[1], [x12]
	mov.d	x12, v30[1]
	ldr	s28, [x8]
	sub	x8, x3, #32
	ld1.s	{ v28 }[1], [x7]
	dup.2d	v31, x8
	fmov	x8, d30
	add.2d	v30, v1, v31
	ld1.s	{ v25 }[2], [x13]
	add.2d	v31, v30, v0
	add.2d	v12, v30, v3
	add.2d	v13, v30, v5
	add.2d	v30, v30, v7
	ld1.s	{ v26 }[2], [x5]
	mov.d	x13, v30[1]
	mov.d	x5, v12[1]
	ld1.s	{ v27 }[2], [x8]
	fmov	x8, d12
	ldr	s12, [x8]
	mov.d	x8, v31[1]
	ld1.s	{ v28 }[2], [x19]
	fmov	x7, d30
	ld1.s	{ v12 }[1], [x5]
	fmov	x5, d31
	ld1.s	{ v12 }[2], [x5]
	mov.d	x5, v13[1]
	ldr	s30, [x7]
	fmov	x7, d13
	ld1.s	{ v25 }[3], [x17]
	ld1.s	{ v30 }[1], [x13]
	dup.2d	v31, x3
	ld1.s	{ v26 }[3], [x6]
	add.2d	v31, v1, v31
	add.2d	v13, v31, v7
	mov.d	x13, v13[1]
	ld1.s	{ v27 }[3], [x12]
	fmov	x12, d13
	add.2d	v13, v31, v5
	mov.d	x17, v13[1]
	ld1.s	{ v28 }[3], [x0]
	fmov	x0, d13
	add.2d	v13, v31, v3
	mov.d	x6, v13[1]
	ld1.s	{ v12 }[3], [x8]
	fmov	x8, d13
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	ld1.s	{ v30 }[2], [x7]
	fadd.4s	v18, v18, v25
	ld1.s	{ v30 }[3], [x5]
	add.2d	v25, v31, v0
	mov.d	x5, v25[1]
	fadd.4s	v17, v17, v26
	fmov	x7, d25
	fmul.4s	v25, v28, v28
	fmul.4s	v26, v27, v27
	fmul.4s	v27, v30, v30
	fmul.4s	v28, v12, v12
	fadd.4s	v22, v22, v26
	ldr	s26, [x8]
	ld1.s	{ v26 }[1], [x6]
	ld1.s	{ v26 }[2], [x7]
	fadd.4s	v19, v19, v25
	ld1.s	{ v26 }[3], [x5]
	ldr	s25, [x12]
	ld1.s	{ v25 }[1], [x13]
	fadd.4s	v21, v21, v28
	ld1.s	{ v25 }[2], [x0]
	ld1.s	{ v25 }[3], [x17]
	fmul.4s	v25, v25, v25
	fadd.4s	v20, v20, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v23, v23, v25
	add	x10, x10, #4
	add	x3, x3, #128
	cmp	x10, #252
	b.lo	LBB0_56
; %bb.57:                               ; %direct.true79.i212.i.preheader
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	mov	x12, x20
LBB0_58:                                ; %direct.true79.i212.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s25, [x12], #4
	dup.2d	v26, x10
	add.2d	v26, v29, v26
	add.2d	v27, v26, v0
	add.2d	v28, v26, v3
	add.2d	v30, v26, v5
	add.2d	v26, v26, v7
	mov.d	x8, v26[1]
	fmov	x13, d26
	str	s25, [x13]
	str	s25, [x8]
	mov.d	x8, v30[1]
	fmov	x13, d30
	str	s25, [x13]
	str	s25, [x8]
	mov.d	x8, v28[1]
	fmov	x13, d28
	str	s25, [x13]
	mov.d	x13, v27[1]
	str	s25, [x8]
	fmov	x8, d27
	str	s25, [x8]
	str	s25, [x13]
	add	x10, x10, #32
	cmp	x10, #2, lsl #12                ; =8192
	b.ne	LBB0_58
; %bb.59:                               ; %direct.false80.i218.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	fadd.4s	v18, v18, v22
	fadd.4s	v17, v17, v19
	fadd.4s	v17, v17, v20
	fadd.4s	v18, v18, v21
	fadd.4s	v18, v18, v24
	fadd.4s	v17, v17, v23
	ldp	q20, q19, [sp, #464]            ; 32-byte Folded Reload
	fmul.4s	v17, v17, v20
	fmul.4s	v18, v18, v20
	fadd.4s	v18, v18, v19
	fadd.4s	v17, v17, v19
	fsqrt.4s	v17, v17
	fsqrt.4s	v18, v18
	ldr	w3, [sp, #116]                  ; 4-byte Folded Reload
LBB0_60:                                ; %direct.true92.i219.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v19, x10
	shl.2d	v20, v19, #5
	orr.16b	v21, v20, v7
	orr.16b	v22, v20, v3
	orr.16b	v23, v20, v5
	orr.16b	v20, v20, v0
	add.2d	v24, v1, v20
	add.2d	v25, v1, v22
	add.2d	v26, v1, v21
	mov.d	x8, v26[1]
	add.2d	v27, v1, v23
	fmov	x12, d26
	mov.d	x13, v27[1]
	mov.d	x17, v25[1]
	fmov	x0, d27
	fmov	x7, d25
	mov.d	x5, v24[1]
	fmov	x6, d24
	ldr	s24, [x7]
	ld1.s	{ v24 }[1], [x17]
	ldr	s25, [x12]
	add.2d	v20, v29, v20
	ld1.s	{ v25 }[1], [x8]
	add.2d	v22, v29, v22
	add.2d	v21, v29, v21
	mov.d	x8, v21[1]
	ld1.s	{ v24 }[2], [x6]
	add.2d	v23, v29, v23
	fmov	x12, d21
	mov.d	x17, v23[1]
	ld1.s	{ v25 }[2], [x0]
	fmov	x0, d23
	mov.d	x7, v22[1]
	fmov	x6, d22
	ld1.s	{ v24 }[3], [x5]
	mov.d	x5, v20[1]
	ldr	s21, [x12]
	fmov	x12, d20
	ld1.s	{ v25 }[3], [x13]
	ld1.s	{ v21 }[1], [x8]
	ld1.s	{ v21 }[2], [x0]
	ld1.s	{ v21 }[3], [x17]
	ldr	s20, [x6]
	ld1.s	{ v20 }[1], [x7]
	ld1.s	{ v20 }[2], [x12]
	fdiv.4s	v22, v25, v17
	fdiv.4s	v23, v24, v18
	ld1.s	{ v20 }[3], [x5]
	shl.2d	v19, v19, #2
	add.2d	v24, v9, v2
	fmul.4s	v20, v23, v20
	add.2d	v23, v24, v19
	add.2d	v24, v9, v6
	add.2d	v25, v9, v4
	add.2d	v26, v9, v16
	add.2d	v26, v26, v19
	fmul.4s	v21, v22, v21
	mov.d	x8, v26[1]
	fmov	x12, d26
	str	s21, [x12]
	st1.s	{ v21 }[1], [x8]
	add.2d	v22, v25, v19
	mov.d	x8, v22[1]
	fmov	x12, d22
	st1.s	{ v21 }[2], [x12]
	add.2d	v19, v24, v19
	mov.d	x12, v19[1]
	fmov	x13, d19
	st1.s	{ v21 }[3], [x8]
	str	s20, [x13]
	mov.d	x8, v23[1]
	fmov	x13, d23
	st1.s	{ v20 }[1], [x12]
	st1.s	{ v20 }[2], [x13]
	st1.s	{ v20 }[3], [x8]
	add	x10, x10, #1
	cmp	x10, #256
	b.ne	LBB0_60
; %bb.61:                               ; %llm_rows.exit224.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	orr	w8, w28, #0x38
	dup.4s	v2, w8
	orr.16b	v6, v2, v10
	orr.16b	v16, v2, v11
	ushll2.2d	v2, v6, #10
	ushll2.2d	v4, v16, #10
	ushll.2d	v6, v6, #10
	ushll.2d	v16, v16, #10
	ldp	q13, q12, [sp, #160]            ; 32-byte Folded Reload
LBB0_62:                                ; %direct.true.i232.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v17, x10
	shl.2d	v18, v17, #2
	add.2d	v19, v8, v2
	add.2d	v19, v19, v18
	add.2d	v20, v8, v6
	add.2d	v20, v20, v18
	add.2d	v21, v8, v4
	add.2d	v21, v21, v18
	add.2d	v22, v8, v16
	add.2d	v18, v22, v18
	mov.d	x8, v18[1]
	fmov	x12, d18
	ldr	s18, [x12]
	mov.d	x12, v21[1]
	ldr	s22, [x8]
	fmov	x8, d21
	ldr	s21, [x8]
	ldr	s23, [x12]
	mov.d	x8, v20[1]
	fmov	x12, d20
	ldr	s20, [x12]
	ldr	s24, [x8]
	mov.d	x8, v19[1]
	fmov	x12, d19
	ldr	s19, [x12]
	ldr	s25, [x8]
	shl.2d	v17, v17, #5
	add.2d	v17, v1, v17
	add.2d	v26, v17, v0
	add.2d	v27, v17, v3
	add.2d	v28, v17, v5
	add.2d	v17, v17, v7
	mov.d	x8, v17[1]
	fmov	x12, d17
	str	s18, [x12]
	str	s22, [x8]
	mov.d	x8, v28[1]
	fmov	x12, d28
	str	s21, [x12]
	str	s23, [x8]
	mov.d	x8, v27[1]
	fmov	x12, d27
	str	s20, [x12]
	mov.d	x12, v26[1]
	str	s24, [x8]
	fmov	x8, d26
	str	s19, [x8]
	str	s25, [x12]
	add	x10, x10, #1
	cmp	x10, #256
	b.ne	LBB0_62
; %bb.63:                               ; %direct.false.i237.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	fmov	x8, d15
	ldr	s18, [x8]
	ld1.s	{ v18 }[1], [x30]
	fmov	x8, d14
	ld1.s	{ v18 }[2], [x8]
	fmov	x8, d12
	ld1.s	{ v18 }[3], [x26]
	fmov	x12, d13
	ldr	s17, [x8]
	ldr	x8, [sp, #432]                  ; 8-byte Folded Reload
	ld1.s	{ v17 }[1], [x8]
	ld1.s	{ v17 }[2], [x12]
	ldr	x8, [sp, #448]                  ; 8-byte Folded Reload
	ld1.s	{ v17 }[3], [x8]
	fmul.4s	v17, v17, v17
	fmul.4s	v18, v18, v18
	ldp	q11, q19, [sp, #192]            ; 32-byte Folded Reload
	fmov	x8, d19
	fmov	x12, d11
	ldr	s20, [x8]
	ld1.s	{ v20 }[1], [x2]
	ld1.s	{ v20 }[2], [x12]
	ldp	q19, q21, [sp, #400]            ; 32-byte Folded Reload
	fmov	x8, d19
	ld1.s	{ v20 }[3], [x4]
	ldr	s19, [x8]
	ldr	x8, [sp, #240]                  ; 8-byte Folded Reload
	ld1.s	{ v19 }[1], [x8]
	fmov	x8, d21
	ld1.s	{ v19 }[2], [x8]
	ldr	x8, [sp, #256]                  ; 8-byte Folded Reload
	ld1.s	{ v19 }[3], [x8]
	fmul.4s	v19, v19, v19
	ldr	q21, [sp, #336]                 ; 16-byte Folded Reload
	fmov	x8, d21
	ldr	q21, [sp, #352]                 ; 16-byte Folded Reload
	fmov	x12, d21
	ldp	q21, q22, [sp, #368]            ; 32-byte Folded Reload
	fmov	x13, d21
	ldr	s21, [x13]
	ld1.s	{ v21 }[1], [x11]
	fmov	x11, d22
	ld1.s	{ v21 }[2], [x11]
	ld1.s	{ v21 }[3], [x15]
	ldr	s23, [x8]
	ld1.s	{ v23 }[1], [x27]
	ld1.s	{ v23 }[2], [x12]
	ld1.s	{ v23 }[3], [x25]
	fmul.4s	v22, v20, v20
	fmul.4s	v20, v23, v23
	fmul.4s	v21, v21, v21
	ldr	q23, [sp, #272]                 ; 16-byte Folded Reload
	fmov	x8, d23
	ldr	q23, [sp, #288]                 ; 16-byte Folded Reload
	fmov	x11, d23
	ldp	q23, q25, [sp, #304]            ; 32-byte Folded Reload
	fmov	x12, d23
	ldr	s24, [x12]
	ld1.s	{ v24 }[1], [x9]
	ldr	s23, [x8]
	ld1.s	{ v23 }[1], [x14]
	fmov	x8, d25
	ld1.s	{ v23 }[2], [x11]
	ld1.s	{ v23 }[3], [x1]
	fmul.4s	v23, v23, v23
	ld1.s	{ v24 }[2], [x8]
	ld1.s	{ v24 }[3], [x16]
	fmul.4s	v24, v24, v24
	mov	w9, #224                        ; =0xe0
	adrp	x28, lCPI0_18@PAGE
LBB0_64:                                ; %direct.true40.i238.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sub	x8, x9, #96
	dup.2d	v25, x8
	add.2d	v25, v1, v25
	add.2d	v26, v25, v0
	add.2d	v27, v25, v3
	add.2d	v28, v25, v5
	add.2d	v25, v25, v7
	mov.d	x8, v25[1]
	fmov	x12, d25
	mov.d	x11, v28[1]
	fmov	x16, d28
	mov.d	x15, v27[1]
	fmov	x17, d27
	mov.d	x14, v26[1]
	fmov	x13, d26
	sub	x0, x9, #64
	ldr	s25, [x17]
	dup.2d	v26, x0
	add.2d	v27, v1, v26
	add.2d	v30, v27, v0
	add.2d	v28, v27, v3
	ldr	s26, [x12]
	add.2d	v31, v27, v5
	add.2d	v27, v27, v7
	mov.d	x17, v27[1]
	ld1.s	{ v25 }[1], [x15]
	mov.d	x15, v31[1]
	mov.d	x12, v28[1]
	ld1.s	{ v26 }[1], [x8]
	fmov	x8, d27
	fmov	x0, d28
	ldr	s27, [x0]
	fmov	x0, d31
	ld1.s	{ v27 }[1], [x12]
	mov.d	x12, v30[1]
	ldr	s28, [x8]
	sub	x8, x9, #32
	ld1.s	{ v28 }[1], [x17]
	dup.2d	v31, x8
	fmov	x8, d30
	add.2d	v30, v1, v31
	ld1.s	{ v25 }[2], [x13]
	add.2d	v31, v30, v0
	add.2d	v8, v30, v3
	add.2d	v10, v30, v5
	add.2d	v30, v30, v7
	ld1.s	{ v26 }[2], [x16]
	mov.d	x13, v30[1]
	mov.d	x16, v8[1]
	ld1.s	{ v27 }[2], [x8]
	fmov	x8, d8
	ldr	s8, [x8]
	mov.d	x8, v31[1]
	ld1.s	{ v28 }[2], [x0]
	fmov	x17, d30
	ld1.s	{ v8 }[1], [x16]
	fmov	x16, d31
	ld1.s	{ v8 }[2], [x16]
	mov.d	x16, v10[1]
	ldr	s30, [x17]
	fmov	x17, d10
	ld1.s	{ v25 }[3], [x14]
	ld1.s	{ v30 }[1], [x13]
	dup.2d	v31, x9
	ld1.s	{ v26 }[3], [x11]
	add.2d	v31, v1, v31
	add.2d	v10, v31, v7
	mov.d	x11, v10[1]
	ld1.s	{ v27 }[3], [x12]
	fmov	x12, d10
	add.2d	v10, v31, v5
	mov.d	x13, v10[1]
	ld1.s	{ v28 }[3], [x15]
	fmov	x14, d10
	add.2d	v10, v31, v3
	mov.d	x15, v10[1]
	ld1.s	{ v8 }[3], [x8]
	fmov	x8, d10
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	ld1.s	{ v30 }[2], [x17]
	fadd.4s	v18, v18, v25
	ld1.s	{ v30 }[3], [x16]
	add.2d	v25, v31, v0
	mov.d	x16, v25[1]
	fadd.4s	v17, v17, v26
	fmov	x17, d25
	fmul.4s	v25, v28, v28
	fmul.4s	v26, v27, v27
	fmul.4s	v27, v30, v30
	fmul.4s	v28, v8, v8
	fadd.4s	v22, v22, v26
	ldr	s26, [x8]
	ld1.s	{ v26 }[1], [x15]
	ld1.s	{ v26 }[2], [x17]
	fadd.4s	v19, v19, v25
	ld1.s	{ v26 }[3], [x16]
	ldr	s25, [x12]
	ld1.s	{ v25 }[1], [x11]
	fadd.4s	v21, v21, v28
	ld1.s	{ v25 }[2], [x14]
	ld1.s	{ v25 }[3], [x13]
	fmul.4s	v25, v25, v25
	fadd.4s	v20, v20, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v23, v23, v25
	add	x10, x10, #4
	add	x9, x9, #128
	cmp	x10, #252
	b.lo	LBB0_64
; %bb.65:                               ; %direct.true79.i249.i.preheader
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x9, #0                          ; =0x0
	adrp	x25, lCPI0_16@PAGE
	adrp	x26, lCPI0_17@PAGE
	mov	w27, #50604                     ; =0xc5ac
	movk	w27, #14119, lsl #16
	ldr	x30, [sp, #104]                 ; 8-byte Folded Reload
LBB0_66:                                ; %direct.true79.i249.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	s25, [x20], #4
	dup.2d	v26, x9
	add.2d	v26, v29, v26
	add.2d	v27, v26, v0
	add.2d	v28, v26, v3
	add.2d	v30, v26, v5
	add.2d	v26, v26, v7
	mov.d	x8, v26[1]
	fmov	x10, d26
	str	s25, [x10]
	str	s25, [x8]
	mov.d	x8, v30[1]
	fmov	x10, d30
	str	s25, [x10]
	str	s25, [x8]
	mov.d	x8, v28[1]
	fmov	x10, d28
	str	s25, [x10]
	mov.d	x10, v27[1]
	str	s25, [x8]
	fmov	x8, d27
	str	s25, [x8]
	str	s25, [x10]
	add	x9, x9, #32
	cmp	x9, #2, lsl #12                 ; =8192
	b.ne	LBB0_66
; %bb.67:                               ; %direct.false80.i255.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x9, #0                          ; =0x0
	fadd.4s	v18, v18, v22
	fadd.4s	v17, v17, v19
	fadd.4s	v17, v17, v20
	fadd.4s	v18, v18, v21
	fadd.4s	v18, v18, v24
	fadd.4s	v17, v17, v23
	ldp	q20, q19, [sp, #464]            ; 32-byte Folded Reload
	fmul.4s	v17, v17, v20
	fmul.4s	v18, v18, v20
	fadd.4s	v18, v18, v19
	fadd.4s	v17, v17, v19
	fsqrt.4s	v17, v17
	fsqrt.4s	v18, v18
LBB0_68:                                ; %direct.true92.i256.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v19, x9
	shl.2d	v20, v19, #5
	orr.16b	v21, v20, v7
	orr.16b	v22, v20, v3
	orr.16b	v23, v20, v5
	orr.16b	v20, v20, v0
	add.2d	v24, v1, v20
	add.2d	v25, v1, v22
	add.2d	v26, v1, v21
	mov.d	x8, v26[1]
	add.2d	v27, v1, v23
	fmov	x10, d26
	mov.d	x11, v27[1]
	mov.d	x12, v25[1]
	fmov	x13, d27
	fmov	x14, d25
	mov.d	x15, v24[1]
	fmov	x16, d24
	ldr	s24, [x14]
	ld1.s	{ v24 }[1], [x12]
	ldr	s25, [x10]
	add.2d	v20, v29, v20
	ld1.s	{ v25 }[1], [x8]
	add.2d	v22, v29, v22
	add.2d	v21, v29, v21
	mov.d	x8, v21[1]
	ld1.s	{ v24 }[2], [x16]
	add.2d	v23, v29, v23
	fmov	x10, d21
	mov.d	x12, v23[1]
	ld1.s	{ v25 }[2], [x13]
	fmov	x13, d23
	mov.d	x14, v22[1]
	fmov	x16, d22
	ld1.s	{ v24 }[3], [x15]
	mov.d	x15, v20[1]
	ldr	s21, [x10]
	fmov	x10, d20
	ld1.s	{ v25 }[3], [x11]
	ld1.s	{ v21 }[1], [x8]
	ld1.s	{ v21 }[2], [x13]
	ld1.s	{ v21 }[3], [x12]
	ldr	s20, [x16]
	ld1.s	{ v20 }[1], [x14]
	ld1.s	{ v20 }[2], [x10]
	fdiv.4s	v22, v25, v17
	fdiv.4s	v23, v24, v18
	ld1.s	{ v20 }[3], [x15]
	shl.2d	v19, v19, #2
	add.2d	v24, v9, v2
	fmul.4s	v20, v23, v20
	add.2d	v23, v24, v19
	add.2d	v24, v9, v6
	add.2d	v25, v9, v4
	add.2d	v26, v9, v16
	add.2d	v26, v26, v19
	fmul.4s	v21, v22, v21
	mov.d	x8, v26[1]
	fmov	x10, d26
	str	s21, [x10]
	st1.s	{ v21 }[1], [x8]
	add.2d	v22, v25, v19
	mov.d	x8, v22[1]
	fmov	x10, d22
	st1.s	{ v21 }[2], [x10]
	add.2d	v19, v24, v19
	mov.d	x10, v19[1]
	fmov	x11, d19
	st1.s	{ v21 }[3], [x8]
	str	s20, [x11]
	mov.d	x8, v23[1]
	fmov	x11, d23
	st1.s	{ v20 }[1], [x10]
	st1.s	{ v20 }[2], [x11]
	st1.s	{ v20 }[3], [x8]
	add	x9, x9, #1
	cmp	x9, #256
	b.ne	LBB0_68
; %bb.69:                               ; %llm_rows.exit261.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	w20, [sp, #224]                 ; 4-byte Folded Reload
	ldr	q10, [sp, #208]                 ; 16-byte Folded Reload
	ldr	w13, [sp, #152]                 ; 4-byte Folded Reload
	ldr	x16, [sp, #128]                 ; 8-byte Folded Reload
	b	LBB0_3
LBB0_70:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x24, x12
	lsr	x9, x11, #3
	cmp	x11, #8
	b.lo	LBB0_81
; %bb.71:                               ; %packet.batch.partial.full.loop.preheader.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	w14, #0                         ; =0x0
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldr	x15, [x8]
	ldr	x16, [x8, #16]
	lsl	w1, w24, #6
	ldr	x2, [x8, #48]
LBB0_72:                                ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_73 Depth 3
                                        ;       Child Loop BB0_75 Depth 3
                                        ;       Child Loop BB0_77 Depth 3
                                        ;       Child Loop BB0_79 Depth 3
	mov	x10, #0                         ; =0x0
	add	w8, w1, w14, lsl #3
	dup.4s	v2, w8
	ldr	q4, [x25, lCPI0_16@PAGEOFF]
	orr.16b	v6, v2, v4
	ldr	q4, [x26, lCPI0_17@PAGEOFF]
	orr.16b	v16, v2, v4
	ushll2.2d	v2, v6, #10
	ushll2.2d	v4, v16, #10
	ushll.2d	v6, v6, #10
	ushll.2d	v16, v16, #10
LBB0_73:                                ; %direct.true.i269.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ;     Parent Loop BB0_72 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	dup.2d	v17, x10
	shl.2d	v18, v17, #2
	dup.2d	v19, x15
	add.2d	v20, v19, v2
	add.2d	v20, v20, v18
	add.2d	v21, v19, v6
	add.2d	v21, v21, v18
	add.2d	v22, v19, v4
	add.2d	v22, v22, v18
	add.2d	v19, v19, v16
	add.2d	v18, v19, v18
	mov.d	x8, v18[1]
	fmov	x12, d18
	ldr	s18, [x12]
	mov.d	x12, v22[1]
	ldr	s19, [x8]
	fmov	x8, d22
	ldr	s22, [x8]
	ldr	s23, [x12]
	mov.d	x8, v21[1]
	fmov	x12, d21
	ldr	s21, [x12]
	ldr	s24, [x8]
	mov.d	x8, v20[1]
	fmov	x12, d20
	ldr	s20, [x12]
	ldr	s25, [x8]
	shl.2d	v17, v17, #5
	add.2d	v17, v1, v17
	add.2d	v26, v17, v0
	add.2d	v27, v17, v3
	add.2d	v28, v17, v5
	add.2d	v17, v17, v7
	mov.d	x8, v17[1]
	fmov	x12, d17
	str	s18, [x12]
	str	s19, [x8]
	mov.d	x8, v28[1]
	fmov	x12, d28
	str	s22, [x12]
	str	s23, [x8]
	mov.d	x8, v27[1]
	fmov	x12, d27
	str	s21, [x12]
	mov.d	x12, v26[1]
	str	s24, [x8]
	fmov	x8, d26
	str	s20, [x8]
	str	s25, [x12]
	add	x10, x10, #1
	cmp	x10, #256
	b.ne	LBB0_73
; %bb.74:                               ; %direct.false.i274.i
                                        ;   in Loop: Header=BB0_72 Depth=2
	mov	x10, #0                         ; =0x0
	mov.d	x8, v12[1]
	mov.d	x12, v13[1]
	mov.d	x13, v15[1]
	fmov	x17, d12
	fmov	x0, d15
	mov.d	x5, v14[1]
	fmov	x4, d14
	ldr	s18, [x0]
	ld1.s	{ v18 }[1], [x13]
	ld1.s	{ v18 }[2], [x4]
	ld1.s	{ v18 }[3], [x5]
	fmov	x13, d13
	ldr	s17, [x17]
	ld1.s	{ v17 }[1], [x8]
	ld1.s	{ v17 }[2], [x13]
	ld1.s	{ v17 }[3], [x12]
	fmul.4s	v17, v17, v17
	ldr	q19, [sp, #400]                 ; 16-byte Folded Reload
	mov.d	x8, v19[1]
	fmov	x12, d19
	ldr	q19, [sp, #416]                 ; 16-byte Folded Reload
	fmov	x13, d19
	mov.d	x17, v19[1]
	mov.d	x0, v10[1]
	fmov	x5, d10
	mov.d	x4, v11[1]
	ldr	s20, [x5]
	ld1.s	{ v20 }[1], [x0]
	fmov	x0, d11
	ld1.s	{ v20 }[2], [x0]
	ld1.s	{ v20 }[3], [x4]
	ldr	s21, [x12]
	ld1.s	{ v21 }[1], [x8]
	ld1.s	{ v21 }[2], [x13]
	ld1.s	{ v21 }[3], [x17]
	fmul.4s	v19, v18, v18
	fmul.4s	v18, v21, v21
	ldp	q24, q23, [sp, #336]            ; 32-byte Folded Reload
	mov.d	x8, v24[1]
	mov.d	x12, v23[1]
	fmul.4s	v20, v20, v20
	ldr	q21, [sp, #368]                 ; 16-byte Folded Reload
	fmov	x13, d21
	mov.d	x17, v21[1]
	ldr	q21, [sp, #384]                 ; 16-byte Folded Reload
	mov.d	x0, v21[1]
	fmov	x4, d21
	ldr	s22, [x13]
	ld1.s	{ v22 }[1], [x17]
	ld1.s	{ v22 }[2], [x4]
	fmov	x13, d24
	ld1.s	{ v22 }[3], [x0]
	ldr	s21, [x13]
	ld1.s	{ v21 }[1], [x8]
	fmov	x8, d23
	ld1.s	{ v21 }[2], [x8]
	ld1.s	{ v21 }[3], [x12]
	fmul.4s	v21, v21, v21
	fmul.4s	v22, v22, v22
	ldr	q23, [sp, #272]                 ; 16-byte Folded Reload
	fmov	x8, d23
	mov.d	x12, v23[1]
	ldr	q23, [sp, #288]                 ; 16-byte Folded Reload
	mov.d	x13, v23[1]
	fmov	x17, d23
	ldp	q23, q25, [sp, #304]            ; 32-byte Folded Reload
	fmov	x0, d23
	mov.d	x5, v23[1]
	mov.d	x4, v25[1]
	ldr	s24, [x0]
	ld1.s	{ v24 }[1], [x5]
	ldr	s23, [x8]
	ld1.s	{ v23 }[1], [x12]
	fmov	x8, d25
	ld1.s	{ v23 }[2], [x17]
	ld1.s	{ v23 }[3], [x13]
	fmul.4s	v23, v23, v23
	ld1.s	{ v24 }[2], [x8]
	ld1.s	{ v24 }[3], [x4]
	fmul.4s	v24, v24, v24
	mov	w19, #224                       ; =0xe0
LBB0_75:                                ; %direct.true40.i275.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ;     Parent Loop BB0_72 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	sub	x8, x19, #96
	dup.2d	v25, x8
	add.2d	v25, v1, v25
	add.2d	v26, v25, v0
	add.2d	v27, v25, v3
	add.2d	v28, v25, v5
	add.2d	v25, v25, v7
	mov.d	x8, v25[1]
	fmov	x13, d25
	mov.d	x4, v28[1]
	fmov	x0, d28
	mov.d	x17, v27[1]
	fmov	x5, d27
	mov.d	x6, v26[1]
	fmov	x12, d26
	sub	x7, x19, #64
	ldr	s25, [x5]
	dup.2d	v26, x7
	add.2d	v27, v1, v26
	add.2d	v30, v27, v0
	add.2d	v28, v27, v3
	ldr	s26, [x13]
	add.2d	v31, v27, v5
	add.2d	v27, v27, v7
	mov.d	x13, v27[1]
	ld1.s	{ v25 }[1], [x17]
	mov.d	x17, v31[1]
	mov.d	x5, v28[1]
	ld1.s	{ v26 }[1], [x8]
	fmov	x8, d27
	fmov	x7, d28
	ldr	s27, [x7]
	fmov	x7, d31
	ld1.s	{ v27 }[1], [x5]
	mov.d	x5, v30[1]
	ldr	s28, [x8]
	sub	x8, x19, #32
	ld1.s	{ v28 }[1], [x13]
	dup.2d	v31, x8
	fmov	x8, d30
	add.2d	v30, v1, v31
	ld1.s	{ v25 }[2], [x12]
	add.2d	v31, v30, v0
	add.2d	v8, v30, v3
	add.2d	v9, v30, v5
	add.2d	v30, v30, v7
	ld1.s	{ v26 }[2], [x0]
	mov.d	x12, v30[1]
	mov.d	x13, v8[1]
	ld1.s	{ v27 }[2], [x8]
	fmov	x8, d8
	ldr	s8, [x8]
	mov.d	x8, v31[1]
	ld1.s	{ v28 }[2], [x7]
	fmov	x0, d30
	ld1.s	{ v8 }[1], [x13]
	fmov	x13, d31
	ld1.s	{ v8 }[2], [x13]
	mov.d	x13, v9[1]
	ldr	s30, [x0]
	fmov	x0, d9
	ld1.s	{ v25 }[3], [x6]
	ld1.s	{ v30 }[1], [x12]
	dup.2d	v31, x19
	ld1.s	{ v26 }[3], [x4]
	add.2d	v31, v1, v31
	add.2d	v9, v31, v7
	mov.d	x12, v9[1]
	ld1.s	{ v27 }[3], [x5]
	fmov	x4, d9
	add.2d	v9, v31, v5
	mov.d	x5, v9[1]
	ld1.s	{ v28 }[3], [x17]
	fmov	x17, d9
	add.2d	v9, v31, v3
	mov.d	x6, v9[1]
	ld1.s	{ v8 }[3], [x8]
	fmov	x8, d9
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	ld1.s	{ v30 }[2], [x0]
	fadd.4s	v19, v19, v25
	ld1.s	{ v30 }[3], [x13]
	add.2d	v25, v31, v0
	mov.d	x13, v25[1]
	fadd.4s	v17, v17, v26
	fmov	x0, d25
	fmul.4s	v25, v28, v28
	fmul.4s	v26, v27, v27
	fmul.4s	v27, v30, v30
	fmul.4s	v28, v8, v8
	fadd.4s	v20, v20, v26
	ldr	s26, [x8]
	ld1.s	{ v26 }[1], [x6]
	ld1.s	{ v26 }[2], [x0]
	fadd.4s	v18, v18, v25
	ld1.s	{ v26 }[3], [x13]
	ldr	s25, [x4]
	ld1.s	{ v25 }[1], [x12]
	fadd.4s	v22, v22, v28
	ld1.s	{ v25 }[2], [x17]
	ld1.s	{ v25 }[3], [x5]
	fmul.4s	v25, v25, v25
	fadd.4s	v21, v21, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v23, v23, v25
	add	x10, x10, #4
	add	x19, x19, #128
	cmp	x10, #252
	b.lo	LBB0_75
; %bb.76:                               ; %direct.true79.i286.i.preheader
                                        ;   in Loop: Header=BB0_72 Depth=2
	mov	x10, #0                         ; =0x0
	mov	x12, x16
LBB0_77:                                ; %direct.true79.i286.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ;     Parent Loop BB0_72 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	s25, [x12], #4
	dup.2d	v26, x10
	add.2d	v26, v29, v26
	add.2d	v27, v26, v0
	add.2d	v28, v26, v3
	add.2d	v30, v26, v5
	add.2d	v26, v26, v7
	mov.d	x8, v26[1]
	fmov	x13, d26
	str	s25, [x13]
	str	s25, [x8]
	mov.d	x8, v30[1]
	fmov	x13, d30
	str	s25, [x13]
	str	s25, [x8]
	mov.d	x8, v28[1]
	fmov	x13, d28
	str	s25, [x13]
	mov.d	x13, v27[1]
	str	s25, [x8]
	fmov	x8, d27
	str	s25, [x8]
	str	s25, [x13]
	add	x10, x10, #32
	cmp	x10, #2, lsl #12                ; =8192
	b.ne	LBB0_77
; %bb.78:                               ; %direct.false80.i292.i
                                        ;   in Loop: Header=BB0_72 Depth=2
	mov	x10, #0                         ; =0x0
	fadd.4s	v19, v19, v20
	fadd.4s	v17, v17, v18
	fadd.4s	v17, v17, v21
	fadd.4s	v18, v19, v22
	fadd.4s	v18, v18, v24
	fadd.4s	v17, v17, v23
	ldp	q20, q19, [sp, #464]            ; 32-byte Folded Reload
	fmul.4s	v17, v17, v20
	fmul.4s	v18, v18, v20
	fadd.4s	v18, v18, v19
	fadd.4s	v17, v17, v19
	fsqrt.4s	v17, v17
	fsqrt.4s	v18, v18
LBB0_79:                                ; %direct.true92.i293.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ;     Parent Loop BB0_72 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	dup.2d	v19, x10
	shl.2d	v20, v19, #5
	orr.16b	v21, v20, v7
	orr.16b	v22, v20, v5
	orr.16b	v23, v20, v3
	orr.16b	v20, v20, v0
	add.2d	v24, v1, v20
	add.2d	v25, v1, v23
	add.2d	v26, v1, v22
	add.2d	v27, v1, v21
	mov.d	x8, v27[1]
	fmov	x12, d27
	mov.d	x13, v26[1]
	fmov	x17, d26
	mov.d	x0, v25[1]
	fmov	x6, d25
	mov.d	x4, v24[1]
	fmov	x5, d24
	ldr	s24, [x6]
	ld1.s	{ v24 }[1], [x0]
	ldr	s25, [x12]
	add.2d	v20, v29, v20
	add.2d	v23, v29, v23
	add.2d	v22, v29, v22
	ld1.s	{ v25 }[1], [x8]
	add.2d	v21, v29, v21
	mov.d	x8, v21[1]
	fmov	x12, d21
	ld1.s	{ v24 }[2], [x5]
	mov.d	x0, v22[1]
	mov.d	x6, v23[1]
	ld1.s	{ v25 }[2], [x17]
	fmov	x17, d22
	mov.d	x5, v20[1]
	ldr	s21, [x12]
	ld1.s	{ v24 }[3], [x4]
	ld1.s	{ v21 }[1], [x8]
	ld1.s	{ v21 }[2], [x17]
	ld1.s	{ v25 }[3], [x13]
	fmov	x8, d23
	ldr	s22, [x8]
	ld1.s	{ v22 }[1], [x6]
	ld1.s	{ v21 }[3], [x0]
	fmov	x8, d20
	ld1.s	{ v22 }[2], [x8]
	ld1.s	{ v22 }[3], [x5]
	fdiv.4s	v20, v25, v17
	fdiv.4s	v23, v24, v18
	shl.2d	v19, v19, #2
	dup.2d	v24, x2
	add.2d	v25, v24, v2
	fmul.4s	v22, v23, v22
	add.2d	v23, v25, v19
	add.2d	v25, v24, v6
	add.2d	v26, v24, v4
	add.2d	v24, v24, v16
	add.2d	v24, v24, v19
	fmul.4s	v20, v20, v21
	mov.d	x8, v24[1]
	fmov	x12, d24
	str	s20, [x12]
	st1.s	{ v20 }[1], [x8]
	add.2d	v21, v26, v19
	mov.d	x8, v21[1]
	fmov	x12, d21
	st1.s	{ v20 }[2], [x12]
	add.2d	v19, v25, v19
	mov.d	x12, v19[1]
	fmov	x13, d19
	st1.s	{ v20 }[3], [x8]
	str	s22, [x13]
	mov.d	x8, v23[1]
	fmov	x13, d23
	st1.s	{ v22 }[1], [x12]
	st1.s	{ v22 }[2], [x13]
	st1.s	{ v22 }[3], [x8]
	add	x10, x10, #1
	cmp	x10, #256
	b.ne	LBB0_79
; %bb.80:                               ; %llm_rows.exit298.i
                                        ;   in Loop: Header=BB0_72 Depth=2
	add	w14, w14, #1
	cmp	w14, w9
	b.ne	LBB0_72
LBB0_81:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w11, #0x7
	ldr	w13, [sp, #152]                 ; 4-byte Folded Reload
	mov	x16, x24
	mov	w24, #998244352                 ; =0x3b800000
	cbz	w10, LBB0_3
; %bb.82:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	dup.4s	v2, w10
	ldr	q4, [x26, lCPI0_17@PAGEOFF]
	ldr	q6, [x25, lCPI0_16@PAGEOFF]
	cmhi.4s	v28, v2, v6
	cmhi.4s	v30, v2, v4
	uzp1.8h	v2, v30, v28
	umaxv.8h	h16, v2
	fmov	w8, s16
	tbz	w8, #0, LBB0_2
; %bb.83:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	ldr	x12, [sp, #120]                 ; 8-byte Folded Reload
	ldr	x14, [x12]
	ldr	x11, [x12, #16]
	sshll.2d	v16, v30, #0
	sshll.2d	v17, v28, #0
	sshll2.2d	v19, v30, #0
	lsl	w8, w9, #3
	orr	w8, w8, w16, lsl #6
	dup.4s	v18, w8
	sshll2.2d	v20, v28, #0
	orr.16b	v4, v18, v4
	orr.16b	v6, v18, v6
	ldr	x9, [x12, #48]
	and.16b	v6, v28, v6
	and.16b	v4, v30, v4
	and.16b	v8, v20, v1
	and.16b	v9, v19, v1
	and.16b	v10, v17, v1
	and.16b	v11, v16, v1
	stp	q20, q19, [sp, #48]             ; 32-byte Folded Spill
	and.16b	v12, v20, v0
	and.16b	v13, v19, v5
	and.16b	v14, v17, v3
	and.16b	v15, v16, v7
	ushll2.2d	v25, v6, #10
	ushll2.2d	v27, v4, #10
	ushll.2d	v6, v6, #10
	ushll.2d	v4, v4, #10
	stp	q4, q6, [sp, #432]              ; 32-byte Folded Spill
	b	LBB0_85
LBB0_84:                                ; %else3164
                                        ;   in Loop: Header=BB0_85 Depth=2
	add	x10, x10, #1
	cmp	x10, #256
	b.eq	LBB0_117
LBB0_85:                                ; %direct.true.i306.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q4, [x28, lCPI0_18@PAGEOFF]
	and.16b	v4, v2, v4
	addv.8h	h17, v4
	fmov	w12, s17
	dup.2d	v16, x10
	shl.2d	v18, v16, #2
	dup.2d	v20, x14
	ldr	q4, [sp, #432]                  ; 16-byte Folded Reload
	add.2d	v4, v20, v4
	add.2d	v19, v4, v18
	movi.2d	v6, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbnz	w12, #0, LBB0_101
; %bb.86:                               ; %else
                                        ;   in Loop: Header=BB0_85 Depth=2
	and	w15, w12, #0xff
	tbnz	w15, #1, LBB0_102
LBB0_87:                                ; %else3095
                                        ;   in Loop: Header=BB0_85 Depth=2
	add.2d	v19, v20, v27
	add.2d	v19, v19, v18
	tbnz	w15, #2, LBB0_103
LBB0_88:                                ; %else3101
                                        ;   in Loop: Header=BB0_85 Depth=2
	tbnz	w15, #3, LBB0_104
LBB0_89:                                ; %else3107
                                        ;   in Loop: Header=BB0_85 Depth=2
	ldr	q19, [sp, #448]                 ; 16-byte Folded Reload
	add.2d	v19, v20, v19
	add.2d	v19, v19, v18
	tbnz	w15, #4, LBB0_105
LBB0_90:                                ; %else3113
                                        ;   in Loop: Header=BB0_85 Depth=2
	tbnz	w15, #5, LBB0_106
LBB0_91:                                ; %else3119
                                        ;   in Loop: Header=BB0_85 Depth=2
	add.2d	v19, v20, v25
	add.2d	v18, v19, v18
	tbnz	w15, #6, LBB0_107
LBB0_92:                                ; %else3125
                                        ;   in Loop: Header=BB0_85 Depth=2
	tbnz	w15, #7, LBB0_108
LBB0_93:                                ; %else3131
                                        ;   in Loop: Header=BB0_85 Depth=2
	fmov	w12, s17
	shl.2d	v16, v16, #5
	orr.16b	v18, v16, v15
	add.2d	v18, v11, v18
	tbnz	w12, #0, LBB0_109
LBB0_94:                                ; %else3136
                                        ;   in Loop: Header=BB0_85 Depth=2
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_110
LBB0_95:                                ; %else3140
                                        ;   in Loop: Header=BB0_85 Depth=2
	orr.16b	v18, v16, v13
	add.2d	v18, v9, v18
	tbnz	w12, #2, LBB0_111
LBB0_96:                                ; %else3144
                                        ;   in Loop: Header=BB0_85 Depth=2
	tbnz	w12, #3, LBB0_112
LBB0_97:                                ; %else3148
                                        ;   in Loop: Header=BB0_85 Depth=2
	orr.16b	v6, v16, v14
	add.2d	v6, v10, v6
	tbnz	w12, #4, LBB0_113
LBB0_98:                                ; %else3152
                                        ;   in Loop: Header=BB0_85 Depth=2
	tbnz	w12, #5, LBB0_114
LBB0_99:                                ; %else3156
                                        ;   in Loop: Header=BB0_85 Depth=2
	orr.16b	v6, v16, v12
	add.2d	v6, v8, v6
	tbnz	w12, #6, LBB0_115
LBB0_100:                               ; %else3160
                                        ;   in Loop: Header=BB0_85 Depth=2
	tbz	w12, #7, LBB0_84
	b	LBB0_116
LBB0_101:                               ; %cond.load
                                        ;   in Loop: Header=BB0_85 Depth=2
	fmov	x8, d19
	ldr	s6, [x8]
	and	w15, w12, #0xff
	tbz	w15, #1, LBB0_87
LBB0_102:                               ; %cond.load3091
                                        ;   in Loop: Header=BB0_85 Depth=2
	mov.d	x8, v19[1]
	ld1.s	{ v6 }[1], [x8]
	add.2d	v19, v20, v27
	add.2d	v19, v19, v18
	tbz	w15, #2, LBB0_88
LBB0_103:                               ; %cond.load3097
                                        ;   in Loop: Header=BB0_85 Depth=2
	fmov	x8, d19
	ld1.s	{ v6 }[2], [x8]
	tbz	w15, #3, LBB0_89
LBB0_104:                               ; %cond.load3103
                                        ;   in Loop: Header=BB0_85 Depth=2
	mov.d	x8, v19[1]
	ld1.s	{ v6 }[3], [x8]
	ldr	q19, [sp, #448]                 ; 16-byte Folded Reload
	add.2d	v19, v20, v19
	add.2d	v19, v19, v18
	tbz	w15, #4, LBB0_90
LBB0_105:                               ; %cond.load3109
                                        ;   in Loop: Header=BB0_85 Depth=2
	fmov	x8, d19
	ld1.s	{ v4 }[0], [x8]
	tbz	w15, #5, LBB0_91
LBB0_106:                               ; %cond.load3115
                                        ;   in Loop: Header=BB0_85 Depth=2
	mov.d	x8, v19[1]
	ld1.s	{ v4 }[1], [x8]
	add.2d	v19, v20, v25
	add.2d	v18, v19, v18
	tbz	w15, #6, LBB0_92
LBB0_107:                               ; %cond.load3121
                                        ;   in Loop: Header=BB0_85 Depth=2
	fmov	x8, d18
	ld1.s	{ v4 }[2], [x8]
	tbz	w15, #7, LBB0_93
LBB0_108:                               ; %cond.load3127
                                        ;   in Loop: Header=BB0_85 Depth=2
	mov.d	x8, v18[1]
	ld1.s	{ v4 }[3], [x8]
	fmov	w12, s17
	shl.2d	v16, v16, #5
	orr.16b	v18, v16, v15
	add.2d	v18, v11, v18
	tbz	w12, #0, LBB0_94
LBB0_109:                               ; %cond.store
                                        ;   in Loop: Header=BB0_85 Depth=2
	fmov	x8, d18
	str	s6, [x8]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_95
LBB0_110:                               ; %cond.store3137
                                        ;   in Loop: Header=BB0_85 Depth=2
	mov.d	x8, v18[1]
	st1.s	{ v6 }[1], [x8]
	orr.16b	v18, v16, v13
	add.2d	v18, v9, v18
	tbz	w12, #2, LBB0_96
LBB0_111:                               ; %cond.store3141
                                        ;   in Loop: Header=BB0_85 Depth=2
	fmov	x8, d18
	st1.s	{ v6 }[2], [x8]
	tbz	w12, #3, LBB0_97
LBB0_112:                               ; %cond.store3145
                                        ;   in Loop: Header=BB0_85 Depth=2
	mov.d	x8, v18[1]
	st1.s	{ v6 }[3], [x8]
	orr.16b	v6, v16, v14
	add.2d	v6, v10, v6
	tbz	w12, #4, LBB0_98
LBB0_113:                               ; %cond.store3149
                                        ;   in Loop: Header=BB0_85 Depth=2
	fmov	x8, d6
	str	s4, [x8]
	tbz	w12, #5, LBB0_99
LBB0_114:                               ; %cond.store3153
                                        ;   in Loop: Header=BB0_85 Depth=2
	mov.d	x8, v6[1]
	st1.s	{ v4 }[1], [x8]
	orr.16b	v6, v16, v12
	add.2d	v6, v8, v6
	tbz	w12, #6, LBB0_100
LBB0_115:                               ; %cond.store3157
                                        ;   in Loop: Header=BB0_85 Depth=2
	fmov	x8, d6
	st1.s	{ v4 }[2], [x8]
	tbz	w12, #7, LBB0_84
LBB0_116:                               ; %cond.store3161
                                        ;   in Loop: Header=BB0_85 Depth=2
	mov.d	x8, v6[1]
	st1.s	{ v4 }[3], [x8]
	b	LBB0_84
LBB0_117:                               ; %direct.false.i311.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	w10, s17
	add.2d	v2, v11, v15
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbnz	w10, #0, LBB0_286
; %bb.118:                              ; %else3170
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_287
LBB0_119:                               ; %else3176
                                        ;   in Loop: Header=BB0_4 Depth=1
	add.2d	v22, v9, v13
	tbnz	w10, #2, LBB0_288
LBB0_120:                               ; %else3182
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #3, LBB0_289
LBB0_121:                               ; %else3188
                                        ;   in Loop: Header=BB0_4 Depth=1
	add.2d	v23, v10, v14
	tbnz	w10, #4, LBB0_290
LBB0_122:                               ; %else3194
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #5, LBB0_291
LBB0_123:                               ; %else3200
                                        ;   in Loop: Header=BB0_4 Depth=1
	add.2d	v24, v8, v12
	tbnz	w10, #6, LBB0_292
LBB0_124:                               ; %else3206
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	q25, [sp, #128]                 ; 16-byte Folded Spill
	tbz	w10, #7, LBB0_126
LBB0_125:                               ; %cond.load3208
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x8, v24[1]
	ld1.s	{ v21 }[3], [x8]
LBB0_126:                               ; %else3212
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	w10, s17
	mov	w8, #32                         ; =0x20
	dup.2d	v4, x8
	add.2d	v6, v2, v4
	movi.2d	v25, #0000000000000000
	movi.2d	v26, #0000000000000000
	tbnz	w10, #0, LBB0_293
; %bb.127:                              ; %else3219
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_294
LBB0_128:                               ; %else3225
                                        ;   in Loop: Header=BB0_4 Depth=1
	add.2d	v6, v22, v4
	tbnz	w10, #2, LBB0_295
LBB0_129:                               ; %else3231
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #3, LBB0_296
LBB0_130:                               ; %else3237
                                        ;   in Loop: Header=BB0_4 Depth=1
	add.2d	v6, v23, v4
	tbnz	w10, #4, LBB0_297
LBB0_131:                               ; %else3243
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #5, LBB0_298
LBB0_132:                               ; %else3249
                                        ;   in Loop: Header=BB0_4 Depth=1
	add.2d	v4, v24, v4
	tbnz	w10, #6, LBB0_299
LBB0_133:                               ; %else3255
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #7, LBB0_300
LBB0_134:                               ; %else3261
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	w10, s17
	dup.2d	v16, x23
	add.2d	v18, v2, v16
	movi.2d	v4, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbnz	w10, #0, LBB0_301
LBB0_135:                               ; %else3268
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_302
LBB0_136:                               ; %else3274
                                        ;   in Loop: Header=BB0_4 Depth=1
	add.2d	v18, v22, v16
	tbnz	w10, #2, LBB0_303
LBB0_137:                               ; %else3280
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #3, LBB0_304
LBB0_138:                               ; %else3286
                                        ;   in Loop: Header=BB0_4 Depth=1
	add.2d	v18, v23, v16
	tbnz	w10, #4, LBB0_305
LBB0_139:                               ; %else3292
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #5, LBB0_306
LBB0_140:                               ; %else3298
                                        ;   in Loop: Header=BB0_4 Depth=1
	add.2d	v16, v24, v16
	tbnz	w10, #6, LBB0_307
LBB0_141:                               ; %else3304
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #7, LBB0_143
LBB0_142:                               ; %cond.load3306
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x8, v16[1]
	ld1.s	{ v6 }[3], [x8]
LBB0_143:                               ; %else3310
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	w10, s17
	mov	w8, #96                         ; =0x60
	dup.2d	v18, x8
	add.2d	v19, v2, v18
	movi.2d	v2, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbnz	w10, #0, LBB0_308
; %bb.144:                              ; %else3317
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_309
LBB0_145:                               ; %else3323
                                        ;   in Loop: Header=BB0_4 Depth=1
	add.2d	v19, v22, v18
	tbnz	w10, #2, LBB0_310
LBB0_146:                               ; %else3329
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #3, LBB0_311
LBB0_147:                               ; %else3335
                                        ;   in Loop: Header=BB0_4 Depth=1
	add.2d	v19, v23, v18
	tbnz	w10, #4, LBB0_312
LBB0_148:                               ; %else3341
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #5, LBB0_313
LBB0_149:                               ; %else3347
                                        ;   in Loop: Header=BB0_4 Depth=1
	add.2d	v18, v24, v18
	tbnz	w10, #6, LBB0_314
LBB0_150:                               ; %else3353
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	q27, [sp, #80]                  ; 16-byte Folded Spill
	tbz	w10, #7, LBB0_152
LBB0_151:                               ; %cond.load3355
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x8, v18[1]
	ld1.s	{ v16 }[3], [x8]
LBB0_152:                               ; %else3359
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	fmul.4s	v18, v20, v20
	fmul.4s	v19, v21, v21
	fmul.4s	v21, v25, v25
	fmul.4s	v22, v26, v26
	fmul.4s	v4, v4, v4
	fmul.4s	v6, v6, v6
	fmul.4s	v2, v2, v2
	fmul.4s	v16, v16, v16
	and.16b	v20, v28, v19
	and.16b	v23, v30, v18
	and.16b	v22, v28, v22
	and.16b	v26, v30, v21
	and.16b	v25, v28, v6
	and.16b	v24, v30, v4
	and.16b	v21, v28, v16
	mov	w14, #224                       ; =0xe0
	stp	q28, q30, [sp, #240]            ; 32-byte Folded Spill
	and.16b	v27, v30, v2
	str	q8, [sp, #224]                  ; 16-byte Folded Spill
	b	LBB0_154
LBB0_153:                               ; %else3555
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmul.4s	v19, v30, v30
	fmul.4s	v28, v28, v28
	fadd.4s	v28, v23, v28
	fadd.4s	v19, v20, v19
	fmul.4s	v30, v31, v31
	fmul.4s	v2, v2, v2
	fadd.4s	v2, v26, v2
	fadd.4s	v30, v22, v30
	fmul.4s	v6, v6, v6
	fmul.4s	v4, v4, v4
	fadd.4s	v4, v24, v4
	fadd.4s	v6, v25, v6
	fmul.4s	v16, v16, v16
	fmul.4s	v18, v18, v18
	fadd.4s	v18, v21, v18
	fadd.4s	v16, v27, v16
	ldr	q31, [sp, #240]                 ; 16-byte Folded Reload
	bit.16b	v20, v19, v31
	ldr	q19, [sp, #256]                 ; 16-byte Folded Reload
	bit.16b	v23, v28, v19
	bit.16b	v22, v30, v31
	bit.16b	v26, v2, v19
	bit.16b	v25, v6, v31
	bit.16b	v24, v4, v19
	add	x10, x10, #4
	bit.16b	v27, v16, v19
	add	x14, x14, #128
	bit.16b	v21, v18, v31
	cmp	x10, #252
	b.hs	LBB0_218
LBB0_154:                               ; %direct.true40.i312.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w12, s17
	sub	x8, x14, #96
	dup.2d	v2, x8
	orr.16b	v4, v2, v15
	add.2d	v4, v11, v4
	movi.2d	v28, #0000000000000000
	movi.2d	v30, #0000000000000000
	tbnz	w12, #0, LBB0_189
; %bb.155:                              ; %else3366
                                        ;   in Loop: Header=BB0_154 Depth=2
	and	w15, w12, #0xff
	tbnz	w15, #1, LBB0_190
LBB0_156:                               ; %else3372
                                        ;   in Loop: Header=BB0_154 Depth=2
	orr.16b	v4, v2, v13
	add.2d	v4, v9, v4
	tbnz	w15, #2, LBB0_191
LBB0_157:                               ; %else3378
                                        ;   in Loop: Header=BB0_154 Depth=2
	tbnz	w15, #3, LBB0_192
LBB0_158:                               ; %else3384
                                        ;   in Loop: Header=BB0_154 Depth=2
	orr.16b	v4, v2, v14
	add.2d	v4, v10, v4
	tbnz	w15, #4, LBB0_193
LBB0_159:                               ; %else3390
                                        ;   in Loop: Header=BB0_154 Depth=2
	tbnz	w15, #5, LBB0_194
LBB0_160:                               ; %else3396
                                        ;   in Loop: Header=BB0_154 Depth=2
	orr.16b	v2, v2, v12
	add.2d	v2, v8, v2
	tbnz	w15, #6, LBB0_195
LBB0_161:                               ; %else3402
                                        ;   in Loop: Header=BB0_154 Depth=2
	tbz	w15, #7, LBB0_163
LBB0_162:                               ; %cond.load3404
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.d	x8, v2[1]
	ld1.s	{ v30 }[3], [x8]
LBB0_163:                               ; %else3408
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	w12, s17
	sub	x8, x14, #64
	dup.2d	v4, x8
	orr.16b	v2, v4, v15
	add.2d	v6, v11, v2
	movi.2d	v2, #0000000000000000
	movi.2d	v31, #0000000000000000
	tbnz	w12, #0, LBB0_196
; %bb.164:                              ; %else3415
                                        ;   in Loop: Header=BB0_154 Depth=2
	and	w15, w12, #0xff
	tbnz	w15, #1, LBB0_197
LBB0_165:                               ; %else3421
                                        ;   in Loop: Header=BB0_154 Depth=2
	orr.16b	v6, v4, v13
	add.2d	v6, v9, v6
	tbnz	w15, #2, LBB0_198
LBB0_166:                               ; %else3427
                                        ;   in Loop: Header=BB0_154 Depth=2
	tbnz	w15, #3, LBB0_199
LBB0_167:                               ; %else3433
                                        ;   in Loop: Header=BB0_154 Depth=2
	orr.16b	v6, v4, v14
	add.2d	v6, v10, v6
	tbnz	w15, #4, LBB0_200
LBB0_168:                               ; %else3439
                                        ;   in Loop: Header=BB0_154 Depth=2
	tbnz	w15, #5, LBB0_201
LBB0_169:                               ; %else3445
                                        ;   in Loop: Header=BB0_154 Depth=2
	orr.16b	v4, v4, v12
	add.2d	v4, v8, v4
	tbnz	w15, #6, LBB0_202
LBB0_170:                               ; %else3451
                                        ;   in Loop: Header=BB0_154 Depth=2
	tbz	w15, #7, LBB0_172
LBB0_171:                               ; %cond.load3453
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.d	x8, v4[1]
	ld1.s	{ v31 }[3], [x8]
LBB0_172:                               ; %else3457
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	w12, s17
	sub	x8, x14, #32
	dup.2d	v16, x8
	orr.16b	v4, v16, v15
	add.2d	v18, v11, v4
	movi.2d	v4, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbnz	w12, #0, LBB0_203
; %bb.173:                              ; %else3464
                                        ;   in Loop: Header=BB0_154 Depth=2
	and	w15, w12, #0xff
	tbnz	w15, #1, LBB0_204
LBB0_174:                               ; %else3470
                                        ;   in Loop: Header=BB0_154 Depth=2
	orr.16b	v18, v16, v13
	add.2d	v18, v9, v18
	tbnz	w15, #2, LBB0_205
LBB0_175:                               ; %else3476
                                        ;   in Loop: Header=BB0_154 Depth=2
	tbnz	w15, #3, LBB0_206
LBB0_176:                               ; %else3482
                                        ;   in Loop: Header=BB0_154 Depth=2
	orr.16b	v18, v16, v14
	add.2d	v18, v10, v18
	tbnz	w15, #4, LBB0_207
LBB0_177:                               ; %else3488
                                        ;   in Loop: Header=BB0_154 Depth=2
	tbnz	w15, #5, LBB0_208
LBB0_178:                               ; %else3494
                                        ;   in Loop: Header=BB0_154 Depth=2
	orr.16b	v16, v16, v12
	add.2d	v16, v8, v16
	tbnz	w15, #6, LBB0_209
LBB0_179:                               ; %else3500
                                        ;   in Loop: Header=BB0_154 Depth=2
	tbz	w15, #7, LBB0_181
LBB0_180:                               ; %cond.load3502
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.d	x8, v16[1]
	ld1.s	{ v6 }[3], [x8]
LBB0_181:                               ; %else3506
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	w12, s17
	dup.2d	v19, x14
	orr.16b	v16, v19, v15
	add.2d	v8, v11, v16
	movi.2d	v16, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w12, #0, LBB0_210
; %bb.182:                              ; %else3513
                                        ;   in Loop: Header=BB0_154 Depth=2
	and	w15, w12, #0xff
	tbnz	w15, #1, LBB0_211
LBB0_183:                               ; %else3519
                                        ;   in Loop: Header=BB0_154 Depth=2
	orr.16b	v8, v19, v13
	add.2d	v8, v9, v8
	tbnz	w15, #2, LBB0_212
LBB0_184:                               ; %else3525
                                        ;   in Loop: Header=BB0_154 Depth=2
	tbnz	w15, #3, LBB0_213
LBB0_185:                               ; %else3531
                                        ;   in Loop: Header=BB0_154 Depth=2
	orr.16b	v8, v19, v14
	add.2d	v8, v10, v8
	tbnz	w15, #4, LBB0_214
LBB0_186:                               ; %else3537
                                        ;   in Loop: Header=BB0_154 Depth=2
	tbnz	w15, #5, LBB0_215
LBB0_187:                               ; %else3543
                                        ;   in Loop: Header=BB0_154 Depth=2
	orr.16b	v19, v19, v12
	ldr	q8, [sp, #224]                  ; 16-byte Folded Reload
	add.2d	v19, v8, v19
	tbnz	w15, #6, LBB0_216
LBB0_188:                               ; %else3549
                                        ;   in Loop: Header=BB0_154 Depth=2
	tbz	w15, #7, LBB0_153
	b	LBB0_217
LBB0_189:                               ; %cond.load3362
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	x8, d4
	ldr	s28, [x8]
	and	w15, w12, #0xff
	tbz	w15, #1, LBB0_156
LBB0_190:                               ; %cond.load3368
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.d	x8, v4[1]
	ld1.s	{ v28 }[1], [x8]
	orr.16b	v4, v2, v13
	add.2d	v4, v9, v4
	tbz	w15, #2, LBB0_157
LBB0_191:                               ; %cond.load3374
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	x8, d4
	ld1.s	{ v28 }[2], [x8]
	tbz	w15, #3, LBB0_158
LBB0_192:                               ; %cond.load3380
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.d	x8, v4[1]
	ld1.s	{ v28 }[3], [x8]
	orr.16b	v4, v2, v14
	add.2d	v4, v10, v4
	tbz	w15, #4, LBB0_159
LBB0_193:                               ; %cond.load3386
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	x8, d4
	ld1.s	{ v30 }[0], [x8]
	tbz	w15, #5, LBB0_160
LBB0_194:                               ; %cond.load3392
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.d	x8, v4[1]
	ld1.s	{ v30 }[1], [x8]
	orr.16b	v2, v2, v12
	add.2d	v2, v8, v2
	tbz	w15, #6, LBB0_161
LBB0_195:                               ; %cond.load3398
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	x8, d2
	ld1.s	{ v30 }[2], [x8]
	tbnz	w15, #7, LBB0_162
	b	LBB0_163
LBB0_196:                               ; %cond.load3411
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	x8, d6
	ldr	s2, [x8]
	and	w15, w12, #0xff
	tbz	w15, #1, LBB0_165
LBB0_197:                               ; %cond.load3417
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.d	x8, v6[1]
	ld1.s	{ v2 }[1], [x8]
	orr.16b	v6, v4, v13
	add.2d	v6, v9, v6
	tbz	w15, #2, LBB0_166
LBB0_198:                               ; %cond.load3423
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	x8, d6
	ld1.s	{ v2 }[2], [x8]
	tbz	w15, #3, LBB0_167
LBB0_199:                               ; %cond.load3429
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.d	x8, v6[1]
	ld1.s	{ v2 }[3], [x8]
	orr.16b	v6, v4, v14
	add.2d	v6, v10, v6
	tbz	w15, #4, LBB0_168
LBB0_200:                               ; %cond.load3435
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	x8, d6
	ld1.s	{ v31 }[0], [x8]
	tbz	w15, #5, LBB0_169
LBB0_201:                               ; %cond.load3441
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.d	x8, v6[1]
	ld1.s	{ v31 }[1], [x8]
	orr.16b	v4, v4, v12
	add.2d	v4, v8, v4
	tbz	w15, #6, LBB0_170
LBB0_202:                               ; %cond.load3447
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	x8, d4
	ld1.s	{ v31 }[2], [x8]
	tbnz	w15, #7, LBB0_171
	b	LBB0_172
LBB0_203:                               ; %cond.load3460
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	x8, d18
	ldr	s4, [x8]
	and	w15, w12, #0xff
	tbz	w15, #1, LBB0_174
LBB0_204:                               ; %cond.load3466
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.d	x8, v18[1]
	ld1.s	{ v4 }[1], [x8]
	orr.16b	v18, v16, v13
	add.2d	v18, v9, v18
	tbz	w15, #2, LBB0_175
LBB0_205:                               ; %cond.load3472
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	x8, d18
	ld1.s	{ v4 }[2], [x8]
	tbz	w15, #3, LBB0_176
LBB0_206:                               ; %cond.load3478
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.d	x8, v18[1]
	ld1.s	{ v4 }[3], [x8]
	orr.16b	v18, v16, v14
	add.2d	v18, v10, v18
	tbz	w15, #4, LBB0_177
LBB0_207:                               ; %cond.load3484
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	x8, d18
	ld1.s	{ v6 }[0], [x8]
	tbz	w15, #5, LBB0_178
LBB0_208:                               ; %cond.load3490
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.d	x8, v18[1]
	ld1.s	{ v6 }[1], [x8]
	orr.16b	v16, v16, v12
	add.2d	v16, v8, v16
	tbz	w15, #6, LBB0_179
LBB0_209:                               ; %cond.load3496
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	x8, d16
	ld1.s	{ v6 }[2], [x8]
	tbnz	w15, #7, LBB0_180
	b	LBB0_181
LBB0_210:                               ; %cond.load3509
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	x8, d8
	ldr	s16, [x8]
	and	w15, w12, #0xff
	tbz	w15, #1, LBB0_183
LBB0_211:                               ; %cond.load3515
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.d	x8, v8[1]
	ld1.s	{ v16 }[1], [x8]
	orr.16b	v8, v19, v13
	add.2d	v8, v9, v8
	tbz	w15, #2, LBB0_184
LBB0_212:                               ; %cond.load3521
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	x8, d8
	ld1.s	{ v16 }[2], [x8]
	tbz	w15, #3, LBB0_185
LBB0_213:                               ; %cond.load3527
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.d	x8, v8[1]
	ld1.s	{ v16 }[3], [x8]
	orr.16b	v8, v19, v14
	add.2d	v8, v10, v8
	tbz	w15, #4, LBB0_186
LBB0_214:                               ; %cond.load3533
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	x8, d8
	ld1.s	{ v18 }[0], [x8]
	tbz	w15, #5, LBB0_187
LBB0_215:                               ; %cond.load3539
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.d	x8, v8[1]
	ld1.s	{ v18 }[1], [x8]
	orr.16b	v19, v19, v12
	ldr	q8, [sp, #224]                  ; 16-byte Folded Reload
	add.2d	v19, v8, v19
	tbz	w15, #6, LBB0_188
LBB0_216:                               ; %cond.load3545
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	x8, d19
	ld1.s	{ v18 }[2], [x8]
	tbz	w15, #7, LBB0_153
LBB0_217:                               ; %cond.load3551
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.d	x8, v19[1]
	ld1.s	{ v18 }[3], [x8]
	b	LBB0_153
LBB0_218:                               ; %direct.false41.i322.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	ldr	q2, [sp, #256]                  ; 16-byte Folded Reload
	sshll.2d	v2, v2, #0
	sshll.2d	v4, v31, #0
	ldr	q6, [sp, #48]                   ; 16-byte Folded Reload
	and.16b	v28, v6, v29
	ldr	q6, [sp, #64]                   ; 16-byte Folded Reload
	and.16b	v30, v6, v29
	and.16b	v31, v4, v29
	and.16b	v2, v2, v29
	b	LBB0_220
LBB0_219:                               ; %else3589
                                        ;   in Loop: Header=BB0_220 Depth=2
	add	x10, x10, #32
	add	x11, x11, #4
	cmp	x10, #2, lsl #12                ; =8192
	b.eq	LBB0_236
LBB0_220:                               ; %direct.true79.i323.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w12, s17
	ld1r.4s	{ v4 }, [x11]
	dup.2d	v6, x10
	orr.16b	v16, v6, v15
	add.2d	v16, v2, v16
	tbnz	w12, #0, LBB0_228
; %bb.221:                              ; %else3561
                                        ;   in Loop: Header=BB0_220 Depth=2
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_229
LBB0_222:                               ; %else3565
                                        ;   in Loop: Header=BB0_220 Depth=2
	orr.16b	v16, v6, v13
	add.2d	v16, v30, v16
	tbnz	w12, #2, LBB0_230
LBB0_223:                               ; %else3569
                                        ;   in Loop: Header=BB0_220 Depth=2
	tbnz	w12, #3, LBB0_231
LBB0_224:                               ; %else3573
                                        ;   in Loop: Header=BB0_220 Depth=2
	orr.16b	v16, v6, v14
	add.2d	v16, v31, v16
	tbnz	w12, #4, LBB0_232
LBB0_225:                               ; %else3577
                                        ;   in Loop: Header=BB0_220 Depth=2
	tbnz	w12, #5, LBB0_233
LBB0_226:                               ; %else3581
                                        ;   in Loop: Header=BB0_220 Depth=2
	orr.16b	v6, v6, v12
	add.2d	v6, v28, v6
	tbnz	w12, #6, LBB0_234
LBB0_227:                               ; %else3585
                                        ;   in Loop: Header=BB0_220 Depth=2
	tbz	w12, #7, LBB0_219
	b	LBB0_235
LBB0_228:                               ; %cond.store3558
                                        ;   in Loop: Header=BB0_220 Depth=2
	fmov	x8, d16
	str	s4, [x8]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_222
LBB0_229:                               ; %cond.store3562
                                        ;   in Loop: Header=BB0_220 Depth=2
	mov.d	x8, v16[1]
	st1.s	{ v4 }[1], [x8]
	orr.16b	v16, v6, v13
	add.2d	v16, v30, v16
	tbz	w12, #2, LBB0_223
LBB0_230:                               ; %cond.store3566
                                        ;   in Loop: Header=BB0_220 Depth=2
	fmov	x8, d16
	st1.s	{ v4 }[2], [x8]
	tbz	w12, #3, LBB0_224
LBB0_231:                               ; %cond.store3570
                                        ;   in Loop: Header=BB0_220 Depth=2
	mov.d	x8, v16[1]
	st1.s	{ v4 }[3], [x8]
	orr.16b	v16, v6, v14
	add.2d	v16, v31, v16
	tbz	w12, #4, LBB0_225
LBB0_232:                               ; %cond.store3574
                                        ;   in Loop: Header=BB0_220 Depth=2
	fmov	x8, d16
	str	s4, [x8]
	tbz	w12, #5, LBB0_226
LBB0_233:                               ; %cond.store3578
                                        ;   in Loop: Header=BB0_220 Depth=2
	mov.d	x8, v16[1]
	st1.s	{ v4 }[1], [x8]
	orr.16b	v6, v6, v12
	add.2d	v6, v28, v6
	tbz	w12, #6, LBB0_227
LBB0_234:                               ; %cond.store3582
                                        ;   in Loop: Header=BB0_220 Depth=2
	fmov	x8, d6
	st1.s	{ v4 }[2], [x8]
	tbz	w12, #7, LBB0_219
LBB0_235:                               ; %cond.store3586
                                        ;   in Loop: Header=BB0_220 Depth=2
	mov.d	x8, v6[1]
	st1.s	{ v4 }[3], [x8]
	b	LBB0_219
LBB0_236:                               ; %direct.false80.i329.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x10, #0                         ; =0x0
	fadd.4s	v4, v23, v26
	fadd.4s	v6, v20, v22
	fadd.4s	v6, v6, v25
	fadd.4s	v4, v4, v24
	fadd.4s	v4, v4, v27
	fadd.4s	v6, v6, v21
	ldp	q18, q16, [sp, #464]            ; 32-byte Folded Reload
	fmul.4s	v6, v6, v18
	fmul.4s	v4, v4, v18
	fadd.4s	v4, v4, v16
	fadd.4s	v6, v6, v16
	fsqrt.4s	v6, v6
	fsqrt.4s	v4, v4
	ldr	q16, [sp, #256]                 ; 16-byte Folded Reload
	and.16b	v19, v16, v4
	ldr	q4, [sp, #240]                  ; 16-byte Folded Reload
	and.16b	v18, v4, v6
	ldr	q26, [sp, #128]                 ; 16-byte Folded Reload
	ldr	q27, [sp, #80]                  ; 16-byte Folded Reload
	b	LBB0_238
LBB0_237:                               ; %else3720
                                        ;   in Loop: Header=BB0_238 Depth=2
	add	x10, x10, #1
	cmp	x10, #256
	b.eq	LBB0_2
LBB0_238:                               ; %direct.true92.i330.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v4, x10
	fmov	w11, s17
	shl.2d	v21, v4, #5
	orr.16b	v16, v21, v15
	add.2d	v22, v11, v16
	movi.2d	v6, #0000000000000000
	movi.2d	v20, #0000000000000000
	tbnz	w11, #0, LBB0_263
; %bb.239:                              ; %else3595
                                        ;   in Loop: Header=BB0_238 Depth=2
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB0_264
LBB0_240:                               ; %else3601
                                        ;   in Loop: Header=BB0_238 Depth=2
	orr.16b	v22, v21, v13
	add.2d	v23, v9, v22
	tbnz	w11, #2, LBB0_265
LBB0_241:                               ; %else3607
                                        ;   in Loop: Header=BB0_238 Depth=2
	tbnz	w11, #3, LBB0_266
LBB0_242:                               ; %else3613
                                        ;   in Loop: Header=BB0_238 Depth=2
	orr.16b	v23, v21, v14
	add.2d	v24, v10, v23
	tbnz	w11, #4, LBB0_267
LBB0_243:                               ; %else3619
                                        ;   in Loop: Header=BB0_238 Depth=2
	tbnz	w11, #5, LBB0_268
LBB0_244:                               ; %else3625
                                        ;   in Loop: Header=BB0_238 Depth=2
	orr.16b	v24, v21, v12
	add.2d	v21, v8, v24
	tbnz	w11, #6, LBB0_269
LBB0_245:                               ; %else3631
                                        ;   in Loop: Header=BB0_238 Depth=2
	tbnz	w11, #7, LBB0_270
LBB0_246:                               ; %else3637
                                        ;   in Loop: Header=BB0_238 Depth=2
	fmov	w11, s17
	add.2d	v25, v2, v16
	movi.2d	v16, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbnz	w11, #0, LBB0_271
LBB0_247:                               ; %else3644
                                        ;   in Loop: Header=BB0_238 Depth=2
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB0_272
LBB0_248:                               ; %else3650
                                        ;   in Loop: Header=BB0_238 Depth=2
	add.2d	v22, v30, v22
	tbnz	w11, #2, LBB0_273
LBB0_249:                               ; %else3656
                                        ;   in Loop: Header=BB0_238 Depth=2
	tbnz	w11, #3, LBB0_274
LBB0_250:                               ; %else3662
                                        ;   in Loop: Header=BB0_238 Depth=2
	add.2d	v22, v31, v23
	tbnz	w11, #4, LBB0_275
LBB0_251:                               ; %else3668
                                        ;   in Loop: Header=BB0_238 Depth=2
	tbnz	w11, #5, LBB0_276
LBB0_252:                               ; %else3674
                                        ;   in Loop: Header=BB0_238 Depth=2
	add.2d	v22, v28, v24
	tbnz	w11, #6, LBB0_277
LBB0_253:                               ; %else3680
                                        ;   in Loop: Header=BB0_238 Depth=2
	tbz	w11, #7, LBB0_255
LBB0_254:                               ; %cond.load3682
                                        ;   in Loop: Header=BB0_238 Depth=2
	mov.d	x8, v22[1]
	ld1.s	{ v21 }[3], [x8]
LBB0_255:                               ; %else3686
                                        ;   in Loop: Header=BB0_238 Depth=2
	fdiv.4s	v6, v6, v19
	fmov	w11, s17
	fmul.4s	v16, v6, v16
	shl.2d	v4, v4, #2
	dup.2d	v6, x9
	ldr	q22, [sp, #432]                 ; 16-byte Folded Reload
	add.2d	v22, v6, v22
	add.2d	v22, v22, v4
	tbnz	w11, #0, LBB0_278
; %bb.256:                              ; %else3692
                                        ;   in Loop: Header=BB0_238 Depth=2
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB0_279
LBB0_257:                               ; %else3696
                                        ;   in Loop: Header=BB0_238 Depth=2
	add.2d	v22, v6, v27
	add.2d	v22, v22, v4
	tbnz	w11, #2, LBB0_280
LBB0_258:                               ; %else3700
                                        ;   in Loop: Header=BB0_238 Depth=2
	tbnz	w11, #3, LBB0_281
LBB0_259:                               ; %else3704
                                        ;   in Loop: Header=BB0_238 Depth=2
	fdiv.4s	v16, v20, v18
	fmul.4s	v16, v16, v21
	ldr	q20, [sp, #448]                 ; 16-byte Folded Reload
	add.2d	v20, v6, v20
	add.2d	v20, v20, v4
	tbnz	w11, #4, LBB0_282
LBB0_260:                               ; %else3708
                                        ;   in Loop: Header=BB0_238 Depth=2
	tbnz	w11, #5, LBB0_283
LBB0_261:                               ; %else3712
                                        ;   in Loop: Header=BB0_238 Depth=2
	add.2d	v6, v6, v26
	add.2d	v4, v6, v4
	tbnz	w11, #6, LBB0_284
LBB0_262:                               ; %else3716
                                        ;   in Loop: Header=BB0_238 Depth=2
	tbz	w11, #7, LBB0_237
	b	LBB0_285
LBB0_263:                               ; %cond.load3591
                                        ;   in Loop: Header=BB0_238 Depth=2
	fmov	x8, d22
	ldr	s6, [x8]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB0_240
LBB0_264:                               ; %cond.load3597
                                        ;   in Loop: Header=BB0_238 Depth=2
	mov.d	x8, v22[1]
	ld1.s	{ v6 }[1], [x8]
	orr.16b	v22, v21, v13
	add.2d	v23, v9, v22
	tbz	w11, #2, LBB0_241
LBB0_265:                               ; %cond.load3603
                                        ;   in Loop: Header=BB0_238 Depth=2
	fmov	x8, d23
	ld1.s	{ v6 }[2], [x8]
	tbz	w11, #3, LBB0_242
LBB0_266:                               ; %cond.load3609
                                        ;   in Loop: Header=BB0_238 Depth=2
	mov.d	x8, v23[1]
	ld1.s	{ v6 }[3], [x8]
	orr.16b	v23, v21, v14
	add.2d	v24, v10, v23
	tbz	w11, #4, LBB0_243
LBB0_267:                               ; %cond.load3615
                                        ;   in Loop: Header=BB0_238 Depth=2
	fmov	x8, d24
	ld1.s	{ v20 }[0], [x8]
	tbz	w11, #5, LBB0_244
LBB0_268:                               ; %cond.load3621
                                        ;   in Loop: Header=BB0_238 Depth=2
	mov.d	x8, v24[1]
	ld1.s	{ v20 }[1], [x8]
	orr.16b	v24, v21, v12
	add.2d	v21, v8, v24
	tbz	w11, #6, LBB0_245
LBB0_269:                               ; %cond.load3627
                                        ;   in Loop: Header=BB0_238 Depth=2
	fmov	x8, d21
	ld1.s	{ v20 }[2], [x8]
	tbz	w11, #7, LBB0_246
LBB0_270:                               ; %cond.load3633
                                        ;   in Loop: Header=BB0_238 Depth=2
	mov.d	x8, v21[1]
	ld1.s	{ v20 }[3], [x8]
	fmov	w11, s17
	add.2d	v25, v2, v16
	movi.2d	v16, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbz	w11, #0, LBB0_247
LBB0_271:                               ; %cond.load3640
                                        ;   in Loop: Header=BB0_238 Depth=2
	fmov	x8, d25
	ldr	s16, [x8]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB0_248
LBB0_272:                               ; %cond.load3646
                                        ;   in Loop: Header=BB0_238 Depth=2
	mov.d	x8, v25[1]
	ld1.s	{ v16 }[1], [x8]
	add.2d	v22, v30, v22
	tbz	w11, #2, LBB0_249
LBB0_273:                               ; %cond.load3652
                                        ;   in Loop: Header=BB0_238 Depth=2
	fmov	x8, d22
	ld1.s	{ v16 }[2], [x8]
	tbz	w11, #3, LBB0_250
LBB0_274:                               ; %cond.load3658
                                        ;   in Loop: Header=BB0_238 Depth=2
	mov.d	x8, v22[1]
	ld1.s	{ v16 }[3], [x8]
	add.2d	v22, v31, v23
	tbz	w11, #4, LBB0_251
LBB0_275:                               ; %cond.load3664
                                        ;   in Loop: Header=BB0_238 Depth=2
	fmov	x8, d22
	ld1.s	{ v21 }[0], [x8]
	tbz	w11, #5, LBB0_252
LBB0_276:                               ; %cond.load3670
                                        ;   in Loop: Header=BB0_238 Depth=2
	mov.d	x8, v22[1]
	ld1.s	{ v21 }[1], [x8]
	add.2d	v22, v28, v24
	tbz	w11, #6, LBB0_253
LBB0_277:                               ; %cond.load3676
                                        ;   in Loop: Header=BB0_238 Depth=2
	fmov	x8, d22
	ld1.s	{ v21 }[2], [x8]
	tbnz	w11, #7, LBB0_254
	b	LBB0_255
LBB0_278:                               ; %cond.store3689
                                        ;   in Loop: Header=BB0_238 Depth=2
	fmov	x8, d22
	str	s16, [x8]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB0_257
LBB0_279:                               ; %cond.store3693
                                        ;   in Loop: Header=BB0_238 Depth=2
	mov.d	x8, v22[1]
	st1.s	{ v16 }[1], [x8]
	add.2d	v22, v6, v27
	add.2d	v22, v22, v4
	tbz	w11, #2, LBB0_258
LBB0_280:                               ; %cond.store3697
                                        ;   in Loop: Header=BB0_238 Depth=2
	fmov	x8, d22
	st1.s	{ v16 }[2], [x8]
	tbz	w11, #3, LBB0_259
LBB0_281:                               ; %cond.store3701
                                        ;   in Loop: Header=BB0_238 Depth=2
	mov.d	x8, v22[1]
	st1.s	{ v16 }[3], [x8]
	fdiv.4s	v16, v20, v18
	fmul.4s	v16, v16, v21
	ldr	q20, [sp, #448]                 ; 16-byte Folded Reload
	add.2d	v20, v6, v20
	add.2d	v20, v20, v4
	tbz	w11, #4, LBB0_260
LBB0_282:                               ; %cond.store3705
                                        ;   in Loop: Header=BB0_238 Depth=2
	fmov	x8, d20
	str	s16, [x8]
	tbz	w11, #5, LBB0_261
LBB0_283:                               ; %cond.store3709
                                        ;   in Loop: Header=BB0_238 Depth=2
	mov.d	x8, v20[1]
	st1.s	{ v16 }[1], [x8]
	add.2d	v6, v6, v26
	add.2d	v4, v6, v4
	tbz	w11, #6, LBB0_262
LBB0_284:                               ; %cond.store3713
                                        ;   in Loop: Header=BB0_238 Depth=2
	fmov	x8, d4
	st1.s	{ v16 }[2], [x8]
	tbz	w11, #7, LBB0_237
LBB0_285:                               ; %cond.store3717
                                        ;   in Loop: Header=BB0_238 Depth=2
	mov.d	x8, v4[1]
	st1.s	{ v16 }[3], [x8]
	b	LBB0_237
LBB0_286:                               ; %cond.load3166
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x8, d2
	ldr	s20, [x8]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_119
LBB0_287:                               ; %cond.load3172
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x8, v2[1]
	ld1.s	{ v20 }[1], [x8]
	add.2d	v22, v9, v13
	tbz	w10, #2, LBB0_120
LBB0_288:                               ; %cond.load3178
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x8, d22
	ld1.s	{ v20 }[2], [x8]
	tbz	w10, #3, LBB0_121
LBB0_289:                               ; %cond.load3184
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x8, v22[1]
	ld1.s	{ v20 }[3], [x8]
	add.2d	v23, v10, v14
	tbz	w10, #4, LBB0_122
LBB0_290:                               ; %cond.load3190
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x8, d23
	ld1.s	{ v21 }[0], [x8]
	tbz	w10, #5, LBB0_123
LBB0_291:                               ; %cond.load3196
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x8, v23[1]
	ld1.s	{ v21 }[1], [x8]
	add.2d	v24, v8, v12
	tbz	w10, #6, LBB0_124
LBB0_292:                               ; %cond.load3202
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x8, d24
	ld1.s	{ v21 }[2], [x8]
	str	q25, [sp, #128]                 ; 16-byte Folded Spill
	tbnz	w10, #7, LBB0_125
	b	LBB0_126
LBB0_293:                               ; %cond.load3215
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x8, d6
	ldr	s25, [x8]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_128
LBB0_294:                               ; %cond.load3221
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x8, v6[1]
	ld1.s	{ v25 }[1], [x8]
	add.2d	v6, v22, v4
	tbz	w10, #2, LBB0_129
LBB0_295:                               ; %cond.load3227
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x8, d6
	ld1.s	{ v25 }[2], [x8]
	tbz	w10, #3, LBB0_130
LBB0_296:                               ; %cond.load3233
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x8, v6[1]
	ld1.s	{ v25 }[3], [x8]
	add.2d	v6, v23, v4
	tbz	w10, #4, LBB0_131
LBB0_297:                               ; %cond.load3239
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x8, d6
	ld1.s	{ v26 }[0], [x8]
	tbz	w10, #5, LBB0_132
LBB0_298:                               ; %cond.load3245
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x8, v6[1]
	ld1.s	{ v26 }[1], [x8]
	add.2d	v4, v24, v4
	tbz	w10, #6, LBB0_133
LBB0_299:                               ; %cond.load3251
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x8, d4
	ld1.s	{ v26 }[2], [x8]
	tbz	w10, #7, LBB0_134
LBB0_300:                               ; %cond.load3257
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x8, v4[1]
	ld1.s	{ v26 }[3], [x8]
	fmov	w10, s17
	dup.2d	v16, x23
	add.2d	v18, v2, v16
	movi.2d	v4, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbz	w10, #0, LBB0_135
LBB0_301:                               ; %cond.load3264
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x8, d18
	ldr	s4, [x8]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_136
LBB0_302:                               ; %cond.load3270
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x8, v18[1]
	ld1.s	{ v4 }[1], [x8]
	add.2d	v18, v22, v16
	tbz	w10, #2, LBB0_137
LBB0_303:                               ; %cond.load3276
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x8, d18
	ld1.s	{ v4 }[2], [x8]
	tbz	w10, #3, LBB0_138
LBB0_304:                               ; %cond.load3282
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x8, v18[1]
	ld1.s	{ v4 }[3], [x8]
	add.2d	v18, v23, v16
	tbz	w10, #4, LBB0_139
LBB0_305:                               ; %cond.load3288
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x8, d18
	ld1.s	{ v6 }[0], [x8]
	tbz	w10, #5, LBB0_140
LBB0_306:                               ; %cond.load3294
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x8, v18[1]
	ld1.s	{ v6 }[1], [x8]
	add.2d	v16, v24, v16
	tbz	w10, #6, LBB0_141
LBB0_307:                               ; %cond.load3300
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x8, d16
	ld1.s	{ v6 }[2], [x8]
	tbnz	w10, #7, LBB0_142
	b	LBB0_143
LBB0_308:                               ; %cond.load3313
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x8, d19
	ldr	s2, [x8]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_145
LBB0_309:                               ; %cond.load3319
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x8, v19[1]
	ld1.s	{ v2 }[1], [x8]
	add.2d	v19, v22, v18
	tbz	w10, #2, LBB0_146
LBB0_310:                               ; %cond.load3325
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x8, d19
	ld1.s	{ v2 }[2], [x8]
	tbz	w10, #3, LBB0_147
LBB0_311:                               ; %cond.load3331
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x8, v19[1]
	ld1.s	{ v2 }[3], [x8]
	add.2d	v19, v23, v18
	tbz	w10, #4, LBB0_148
LBB0_312:                               ; %cond.load3337
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x8, d19
	ld1.s	{ v16 }[0], [x8]
	tbz	w10, #5, LBB0_149
LBB0_313:                               ; %cond.load3343
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.d	x8, v19[1]
	ld1.s	{ v16 }[1], [x8]
	add.2d	v18, v24, v18
	tbz	w10, #6, LBB0_150
LBB0_314:                               ; %cond.load3349
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	x8, d18
	ld1.s	{ v16 }[2], [x8]
	str	q27, [sp, #80]                  ; 16-byte Folded Spill
	tbnz	w10, #7, LBB0_151
	b	LBB0_152
LBB0_315:                               ; %block.batch.exit.loopexit
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	stp	w16, w13, [x9]
	str	w12, [x9, #8]
	mov	w8, #56                         ; =0x38
	str	w8, [x9, #36]
LBB0_316:                               ; %block.batch.exit
	add	sp, sp, #4, lsl #12             ; =16384
	add	sp, sp, #512
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdrp	Lloh28, Lloh30
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpLdr	Lloh0, Lloh1
                                        ; -- End function
.subsections_via_symbols

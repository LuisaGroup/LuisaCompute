"""Bounded diagnostic only; does not reset devices or report performance."""
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path('/Users/mike/CLionProjects/luisa')
OUT = Path(__file__).resolve().parent / 'gpu-health'


def worker():
    os.environ['PYTORCH_ENABLE_MPS_FALLBACK'] = '0'
    import torch
    if not torch.backends.mps.is_available():
        raise RuntimeError('MPS unavailable')
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    phases = []
    for repeat in range(3):
        start = time.perf_counter()
        torch.mps.synchronize()
        phases.append(dict(repeat=repeat, phase='empty_sync', seconds=time.perf_counter()-start))
        print(json.dumps(phases[-1]), flush=True)
        x = torch.arange(37, dtype=torch.float32) / 8
        start = time.perf_counter()
        device_x = x.to('mps')
        copy = device_x.cpu()
        torch.mps.synchronize()
        if not torch.equal(copy, x):
            raise ValueError('copy roundtrip mismatch')
        phases.append(dict(repeat=repeat, phase='copy', seconds=time.perf_counter()-start, elements=x.numel()))
        print(json.dumps(phases[-1]), flush=True)
        start = time.perf_counter()
        y = device_x * 2 + 1
        torch.mps.synchronize()
        if not torch.equal(y.cpu(), x * 2 + 1):
            raise ValueError('tiny kernel mismatch')
        phases.append(dict(repeat=repeat, phase='tiny', seconds=time.perf_counter()-start, elements=x.numel()))
        print(json.dumps(phases[-1]), flush=True)
    print(json.dumps(dict(status='pass', torch=torch.__version__, phases=phases)), flush=True)


def main():
    sys.path.insert(0, str(ROOT / 'scripts/benchmark/tile_torch'))
    from compare_llm import capture_benchmark
    OUT.mkdir(exist_ok=False)
    records = []
    for visit in range(3):
        row = dict(visit=visit, started=time.time())
        records.append(row)
        try:
            result = capture_benchmark([sys.executable, str(Path(__file__).resolve()), '--worker'],
                                       dict(os.environ), 30, OUT, f'visit-{visit}', row)
            compact = (result.stdout + result.stderr).decode(errors='replace').replace(' ', '').lower()
            if 'gpuhangerror' in compact:
                raise RuntimeError('compact GPUHangError diagnostic')
            receipt = json.loads(result.stdout.splitlines()[-1])
            if receipt.get('status') != 'pass' or len(receipt.get('phases', [])) != 9:
                raise ValueError('incomplete health phases')
            row.update(status='pass', receipt=receipt)
        except Exception as error:
            row.update(status='failed', error=str(error))
            (OUT / 'health.json').write_text(json.dumps(records, indent=2) + '\n')
            raise
        row['finished'] = time.time()
        (OUT / 'health.json').write_text(json.dumps(records, indent=2) + '\n')
        print('health visit', visit, 'pass', flush=True)


if __name__ == '__main__':
    (worker if '--worker' in sys.argv else main)()

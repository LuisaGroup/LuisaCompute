	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention:                         ; @llm_attention
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #3, lsl #12             ; =12288
	sub	sp, sp, #1856
	dup.4s	v0, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q29, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q28, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v15, v0, v28
	str	q0, [sp, #4976]                 ; 16-byte Spill
	cmhi.4s	v14, v0, v29
	uzp1.8h	v0, v14, v15
	umaxv.8h	h1, v0
	fmov	w8, s1
	tbnz	w8, #0, LBB0_1
	b	LBB0_1801
LBB0_1:                                 ; %direct.activate
	ldr	x9, [x0]
Lloh4:
	adrp	x8, lCPI0_2@PAGE
Lloh5:
	ldr	q1, [x8, lCPI0_2@PAGEOFF]
	and.16b	v0, v0, v1
	addv.8h	h19, v0
	fmov	w10, s19
	and	w8, w10, #0xff
	ldr	w11, [x1]
	ldr	w12, [x1, #36]
	add	w11, w12, w11, lsl #5
	dup.4s	v1, w11
	add.4s	v0, v1, v28
	add.4s	v1, v1, v29
	and.16b	v4, v14, v1
	ushll.2d	v2, v4, #8
	dup.2d	v9, x9
	add.2d	v1, v9, v2
	movi.2d	v5, #0000000000000000
	movi.2d	v13, #0000000000000000
	tbnz	w10, #0, LBB0_231
; %bb.2:                                ; %else
	and.16b	v6, v15, v0
	ushll2.2d	v3, v4, #8
	tbnz	w8, #1, LBB0_232
LBB0_3:                                 ; %else1073
	add.2d	v0, v9, v3
	str	q4, [sp, #13648]                ; 16-byte Spill
	tbnz	w8, #2, LBB0_233
LBB0_4:                                 ; %else1076
	ushll.2d	v4, v6, #8
	tbnz	w8, #3, LBB0_234
LBB0_5:                                 ; %else1079
	add.2d	v0, v9, v4
	str	q5, [sp, #12816]                ; 16-byte Spill
	tbnz	w8, #4, LBB0_235
LBB0_6:                                 ; %else1082
	ushll2.2d	v5, v6, #8
	tbnz	w8, #5, LBB0_236
LBB0_7:                                 ; %else1085
	add.2d	v0, v9, v5
	tbnz	w8, #6, LBB0_237
LBB0_8:                                 ; %else1088
	tbz	w8, #7, LBB0_10
LBB0_9:                                 ; %cond.load1090
	mov.d	x8, v0[1]
	ld1.s	{ v13 }[3], [x8]
LBB0_10:                                ; %else1091
	str	q6, [sp, #13632]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #4                         ; =0x4
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #2144]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v26, #0000000000000000
	movi.2d	v12, #0000000000000000
	tbnz	w9, #0, LBB0_238
; %bb.11:                               ; %else1098
	orr.16b	v6, v3, v0
	tbnz	w8, #1, LBB0_239
LBB0_12:                                ; %else1104
	add.2d	v1, v9, v6
	tbnz	w8, #2, LBB0_240
LBB0_13:                                ; %else1110
	orr.16b	v20, v4, v0
	str	q20, [sp, #4112]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_241
LBB0_14:                                ; %else1116
	ldr	q1, [sp, #4112]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_242
LBB0_15:                                ; %else1122
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_243
LBB0_16:                                ; %else1128
	str	q0, [sp, #2112]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_244
LBB0_17:                                ; %else1134
	tbz	w8, #7, LBB0_19
LBB0_18:                                ; %cond.load1136
	mov.d	x8, v0[1]
	ld1.s	{ v12 }[3], [x8]
LBB0_19:                                ; %else1140
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #8                         ; =0x8
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #2096]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v31, #0000000000000000
	movi.2d	v27, #0000000000000000
	tbnz	w9, #0, LBB0_245
; %bb.20:                               ; %else1147
	orr.16b	v20, v3, v0
	str	q20, [sp, #4096]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_246
LBB0_21:                                ; %else1153
	ldr	q1, [sp, #4096]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_247
LBB0_22:                                ; %else1159
	orr.16b	v20, v4, v0
	str	q20, [sp, #4080]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_248
LBB0_23:                                ; %else1165
	ldr	q1, [sp, #4080]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_249
LBB0_24:                                ; %else1171
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_250
LBB0_25:                                ; %else1177
	str	q0, [sp, #2080]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_251
LBB0_26:                                ; %else1183
	tbz	w8, #7, LBB0_28
LBB0_27:                                ; %cond.load1185
	mov.d	x8, v0[1]
	ld1.s	{ v27 }[3], [x8]
LBB0_28:                                ; %else1189
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #12                        ; =0xc
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #2064]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v11, #0000000000000000
	movi.2d	v25, #0000000000000000
	tbnz	w9, #0, LBB0_252
; %bb.29:                               ; %else1196
	orr.16b	v20, v3, v0
	str	q20, [sp, #4064]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_253
LBB0_30:                                ; %else1202
	ldr	q1, [sp, #4064]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_254
LBB0_31:                                ; %else1208
	orr.16b	v20, v4, v0
	str	q20, [sp, #4048]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_255
LBB0_32:                                ; %else1214
	ldr	q1, [sp, #4048]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_256
LBB0_33:                                ; %else1220
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_257
LBB0_34:                                ; %else1226
	str	q0, [sp, #2048]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_258
LBB0_35:                                ; %else1232
	tbz	w8, #7, LBB0_37
LBB0_36:                                ; %cond.load1234
	mov.d	x8, v0[1]
	ld1.s	{ v25 }[3], [x8]
LBB0_37:                                ; %else1238
	str	q25, [sp, #13936]               ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #16                        ; =0x10
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #2032]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v8, #0000000000000000
	movi.2d	v10, #0000000000000000
	tbnz	w9, #0, LBB0_259
; %bb.38:                               ; %else1245
	orr.16b	v20, v3, v0
	str	q20, [sp, #4032]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_260
LBB0_39:                                ; %else1251
	ldr	q1, [sp, #4032]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_261
LBB0_40:                                ; %else1257
	orr.16b	v20, v4, v0
	str	q20, [sp, #4016]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_262
LBB0_41:                                ; %else1263
	ldr	q1, [sp, #4016]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_263
LBB0_42:                                ; %else1269
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_264
LBB0_43:                                ; %else1275
	str	q0, [sp, #2016]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_265
LBB0_44:                                ; %else1281
	str	q6, [sp, #2128]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_46
LBB0_45:                                ; %cond.load1283
	mov.d	x8, v0[1]
	ld1.s	{ v10 }[3], [x8]
LBB0_46:                                ; %else1287
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #20                        ; =0x14
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #2000]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v23, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbnz	w9, #0, LBB0_266
; %bb.47:                               ; %else1294
	orr.16b	v20, v3, v0
	str	q20, [sp, #4000]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_267
LBB0_48:                                ; %else1300
	ldr	q1, [sp, #4000]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_268
LBB0_49:                                ; %else1306
	orr.16b	v20, v4, v0
	str	q20, [sp, #3984]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_269
LBB0_50:                                ; %else1312
	ldr	q1, [sp, #3984]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_270
LBB0_51:                                ; %else1318
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_271
LBB0_52:                                ; %else1324
	str	q0, [sp, #1984]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_272
LBB0_53:                                ; %else1330
	tbz	w8, #7, LBB0_55
LBB0_54:                                ; %cond.load1332
	mov.d	x8, v0[1]
	ld1.s	{ v6 }[3], [x8]
LBB0_55:                                ; %else1336
	str	q6, [sp, #13872]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #24                        ; =0x18
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #1968]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v21, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbnz	w9, #0, LBB0_273
; %bb.56:                               ; %else1343
	orr.16b	v20, v3, v0
	str	q20, [sp, #3968]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_274
LBB0_57:                                ; %else1349
	ldr	q1, [sp, #3968]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_275
LBB0_58:                                ; %else1355
	orr.16b	v20, v4, v0
	str	q20, [sp, #3952]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_276
LBB0_59:                                ; %else1361
	ldr	q1, [sp, #3952]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_277
LBB0_60:                                ; %else1367
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_278
LBB0_61:                                ; %else1373
	str	q0, [sp, #1952]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_279
LBB0_62:                                ; %else1379
	tbz	w8, #7, LBB0_64
LBB0_63:                                ; %cond.load1381
	mov.d	x8, v0[1]
	ld1.s	{ v6 }[3], [x8]
LBB0_64:                                ; %else1385
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #28                        ; =0x1c
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #1936]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbnz	w9, #0, LBB0_280
; %bb.65:                               ; %else1392
	orr.16b	v20, v3, v0
	str	q20, [sp, #3936]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_281
LBB0_66:                                ; %else1398
	ldr	q1, [sp, #3936]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_282
LBB0_67:                                ; %else1404
	orr.16b	v20, v4, v0
	str	q20, [sp, #3920]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_283
LBB0_68:                                ; %else1410
	ldr	q1, [sp, #3920]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_284
LBB0_69:                                ; %else1416
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_285
LBB0_70:                                ; %else1422
	str	q0, [sp, #1920]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_286
LBB0_71:                                ; %else1428
	tbz	w8, #7, LBB0_73
LBB0_72:                                ; %cond.load1430
	mov.d	x8, v0[1]
	ld1.s	{ v16 }[3], [x8]
LBB0_73:                                ; %else1434
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #32                        ; =0x20
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #1904]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_287
; %bb.74:                               ; %else1441
	orr.16b	v20, v3, v0
	str	q20, [sp, #3904]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_288
LBB0_75:                                ; %else1447
	ldr	q1, [sp, #3904]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_289
LBB0_76:                                ; %else1453
	orr.16b	v20, v4, v0
	str	q20, [sp, #3888]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_290
LBB0_77:                                ; %else1459
	ldr	q1, [sp, #3888]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_291
LBB0_78:                                ; %else1465
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_292
LBB0_79:                                ; %else1471
	str	q0, [sp, #1888]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_293
LBB0_80:                                ; %else1477
	str	q6, [sp, #13856]                ; 16-byte Spill
	tbz	w8, #7, LBB0_82
LBB0_81:                                ; %cond.load1479
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_82:                                ; %else1483
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #36                        ; =0x24
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #1872]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v30, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbnz	w9, #0, LBB0_294
; %bb.83:                               ; %else1490
	orr.16b	v20, v3, v0
	str	q20, [sp, #3872]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_295
LBB0_84:                                ; %else1496
	ldr	q1, [sp, #3872]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_296
LBB0_85:                                ; %else1502
	orr.16b	v20, v4, v0
	str	q20, [sp, #3856]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_297
LBB0_86:                                ; %else1508
	ldr	q1, [sp, #3856]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_298
LBB0_87:                                ; %else1514
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_299
LBB0_88:                                ; %else1520
	str	q0, [sp, #1856]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_300
LBB0_89:                                ; %else1526
	tbz	w8, #7, LBB0_91
LBB0_90:                                ; %cond.load1528
	mov.d	x8, v0[1]
	ld1.s	{ v6 }[3], [x8]
LBB0_91:                                ; %else1532
	str	q6, [sp, #12640]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #40                        ; =0x28
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #1840]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v22, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbnz	w9, #0, LBB0_301
; %bb.92:                               ; %else1539
	orr.16b	v20, v3, v0
	str	q20, [sp, #3840]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_302
LBB0_93:                                ; %else1545
	ldr	q1, [sp, #3840]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_303
LBB0_94:                                ; %else1551
	orr.16b	v20, v4, v0
	str	q20, [sp, #3824]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_304
LBB0_95:                                ; %else1557
	ldr	q1, [sp, #3824]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_305
LBB0_96:                                ; %else1563
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_306
LBB0_97:                                ; %else1569
	str	q0, [sp, #1824]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_307
LBB0_98:                                ; %else1575
	tbz	w8, #7, LBB0_100
LBB0_99:                                ; %cond.load1577
	mov.d	x8, v0[1]
	ld1.s	{ v6 }[3], [x8]
LBB0_100:                               ; %else1581
	str	q6, [sp, #12608]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #44                        ; =0x2c
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #1808]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v6, #0000000000000000
	str	q6, [sp, #13984]                ; 16-byte Spill
	str	q6, [sp, #13968]                ; 16-byte Spill
	tbnz	w9, #0, LBB0_308
; %bb.101:                              ; %else1588
	orr.16b	v20, v3, v0
	str	q20, [sp, #3808]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_309
LBB0_102:                               ; %else1594
	ldr	q1, [sp, #3808]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_310
LBB0_103:                               ; %else1600
	orr.16b	v20, v4, v0
	str	q20, [sp, #3792]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_311
LBB0_104:                               ; %else1606
	ldr	q1, [sp, #3792]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_312
LBB0_105:                               ; %else1612
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_313
LBB0_106:                               ; %else1618
	str	q0, [sp, #1792]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_314
LBB0_107:                               ; %else1624
	tbz	w8, #7, LBB0_109
LBB0_108:                               ; %cond.load1626
	mov.d	x8, v0[1]
	ldr	q0, [sp, #13968]                ; 16-byte Reload
	ld1.s	{ v0 }[3], [x8]
	str	q0, [sp, #13968]                ; 16-byte Spill
LBB0_109:                               ; %else1630
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #48                        ; =0x30
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #1776]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v6, #0000000000000000
	str	q6, [sp, #13952]                ; 16-byte Spill
	str	q6, [sp, #12928]                ; 16-byte Spill
	tbnz	w9, #0, LBB0_315
; %bb.110:                              ; %else1637
	orr.16b	v20, v3, v0
	str	q20, [sp, #3776]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_316
LBB0_111:                               ; %else1643
	ldr	q1, [sp, #3776]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_317
LBB0_112:                               ; %else1649
	orr.16b	v20, v4, v0
	str	q20, [sp, #3760]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_318
LBB0_113:                               ; %else1655
	ldr	q1, [sp, #3760]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_319
LBB0_114:                               ; %else1661
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_320
LBB0_115:                               ; %else1667
	str	q0, [sp, #1760]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_321
LBB0_116:                               ; %else1673
	str	q7, [sp, #13840]                ; 16-byte Spill
	tbz	w8, #7, LBB0_118
LBB0_117:                               ; %cond.load1675
	mov.d	x8, v0[1]
	ldr	q0, [sp, #12928]                ; 16-byte Reload
	ld1.s	{ v0 }[3], [x8]
	str	q0, [sp, #12928]                ; 16-byte Spill
LBB0_118:                               ; %else1679
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #52                        ; =0x34
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #1744]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	tbnz	w9, #0, LBB0_322
; %bb.119:                              ; %else1686
	orr.16b	v20, v3, v0
	str	q20, [sp, #3744]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_323
LBB0_120:                               ; %else1692
	ldr	q1, [sp, #3744]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_324
LBB0_121:                               ; %else1698
	orr.16b	v20, v4, v0
	str	q20, [sp, #3728]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_325
LBB0_122:                               ; %else1704
	ldr	q1, [sp, #3728]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_326
LBB0_123:                               ; %else1710
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_327
LBB0_124:                               ; %else1716
	str	q0, [sp, #1728]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_328
LBB0_125:                               ; %else1722
	str	q16, [sp, #13824]               ; 16-byte Spill
	str	q17, [sp, #13808]               ; 16-byte Spill
	tbz	w8, #7, LBB0_127
LBB0_126:                               ; %cond.load1724
	mov.d	x8, v0[1]
	ld1.s	{ v7 }[3], [x8]
LBB0_127:                               ; %else1728
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #56                        ; =0x38
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #1712]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbnz	w9, #0, LBB0_329
; %bb.128:                              ; %else1735
	orr.16b	v20, v3, v0
	str	q20, [sp, #3712]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_330
LBB0_129:                               ; %else1741
	ldr	q1, [sp, #3712]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_331
LBB0_130:                               ; %else1747
	orr.16b	v20, v4, v0
	str	q20, [sp, #3696]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_332
LBB0_131:                               ; %else1753
	ldr	q1, [sp, #3696]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_333
LBB0_132:                               ; %else1759
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_334
LBB0_133:                               ; %else1765
	str	q0, [sp, #1696]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_335
LBB0_134:                               ; %else1771
	str	q18, [sp, #12080]               ; 16-byte Spill
	tbz	w8, #7, LBB0_136
LBB0_135:                               ; %cond.load1773
	mov.d	x8, v0[1]
	ld1.s	{ v17 }[3], [x8]
LBB0_136:                               ; %else1777
	str	q17, [sp, #12240]               ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #60                        ; =0x3c
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #1680]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_336
; %bb.137:                              ; %else1784
	orr.16b	v20, v3, v0
	str	q20, [sp, #3680]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_337
LBB0_138:                               ; %else1790
	ldr	q1, [sp, #3680]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_338
LBB0_139:                               ; %else1796
	orr.16b	v20, v4, v0
	str	q20, [sp, #3664]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_339
LBB0_140:                               ; %else1802
	ldr	q1, [sp, #3664]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_340
LBB0_141:                               ; %else1808
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_341
LBB0_142:                               ; %else1814
	str	q0, [sp, #1664]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_342
LBB0_143:                               ; %else1820
	tbz	w8, #7, LBB0_145
LBB0_144:                               ; %cond.load1822
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_145:                               ; %else1826
	str	q18, [sp, #12096]               ; 16-byte Spill
	str	q17, [sp, #12224]               ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #64                        ; =0x40
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #1648]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_343
; %bb.146:                              ; %else1833
	orr.16b	v20, v3, v0
	str	q20, [sp, #3648]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_344
LBB0_147:                               ; %else1839
	ldr	q1, [sp, #3648]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_345
LBB0_148:                               ; %else1845
	orr.16b	v20, v4, v0
	str	q20, [sp, #3632]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_346
LBB0_149:                               ; %else1851
	ldr	q1, [sp, #3632]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_347
LBB0_150:                               ; %else1857
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_348
LBB0_151:                               ; %else1863
	str	q0, [sp, #1632]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_349
LBB0_152:                               ; %else1869
	tbz	w8, #7, LBB0_154
LBB0_153:                               ; %cond.load1871
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_154:                               ; %else1875
	str	q18, [sp, #12192]               ; 16-byte Spill
	str	q17, [sp, #12208]               ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #68                        ; =0x44
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #1616]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_350
; %bb.155:                              ; %else1882
	orr.16b	v20, v3, v0
	str	q20, [sp, #3616]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_351
LBB0_156:                               ; %else1888
	ldr	q1, [sp, #3616]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_352
LBB0_157:                               ; %else1894
	orr.16b	v20, v4, v0
	str	q20, [sp, #3600]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_353
LBB0_158:                               ; %else1900
	ldr	q1, [sp, #3600]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_354
LBB0_159:                               ; %else1906
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_355
LBB0_160:                               ; %else1912
	str	q0, [sp, #1600]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_356
LBB0_161:                               ; %else1918
	tbz	w8, #7, LBB0_163
LBB0_162:                               ; %cond.load1920
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_163:                               ; %else1924
	str	q18, [sp, #12176]               ; 16-byte Spill
	str	q17, [sp, #12592]               ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #72                        ; =0x48
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #1584]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_357
; %bb.164:                              ; %else1931
	orr.16b	v20, v3, v0
	str	q20, [sp, #3584]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_358
LBB0_165:                               ; %else1937
	ldr	q1, [sp, #3584]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	str	q22, [sp, #12624]               ; 16-byte Spill
	tbnz	w8, #2, LBB0_359
LBB0_166:                               ; %else1943
	orr.16b	v25, v4, v0
	tbnz	w8, #3, LBB0_360
LBB0_167:                               ; %else1949
	add.2d	v1, v9, v25
	tbnz	w8, #4, LBB0_361
LBB0_168:                               ; %else1955
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_362
LBB0_169:                               ; %else1961
	str	q0, [sp, #1552]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_363
LBB0_170:                               ; %else1967
	tbz	w8, #7, LBB0_172
LBB0_171:                               ; %cond.load1969
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_172:                               ; %else1973
	str	q25, [sp, #1568]                ; 16-byte Spill
	str	q18, [sp, #12016]               ; 16-byte Spill
	str	q17, [sp, #12432]               ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #76                        ; =0x4c
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #1536]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_364
; %bb.173:                              ; %else1980
	orr.16b	v20, v3, v0
	str	q20, [sp, #3568]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_365
LBB0_174:                               ; %else1986
	ldr	q1, [sp, #3568]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_366
LBB0_175:                               ; %else1992
	orr.16b	v20, v4, v0
	str	q20, [sp, #3552]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_367
LBB0_176:                               ; %else1998
	ldr	q1, [sp, #3552]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_368
LBB0_177:                               ; %else2004
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_369
LBB0_178:                               ; %else2010
	str	q0, [sp, #1520]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_370
LBB0_179:                               ; %else2016
	tbz	w8, #7, LBB0_181
LBB0_180:                               ; %cond.load2018
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_181:                               ; %else2022
	str	q18, [sp, #11984]               ; 16-byte Spill
	str	q17, [sp, #12000]               ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #80                        ; =0x50
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #1504]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_371
; %bb.182:                              ; %else2029
	orr.16b	v20, v3, v0
	str	q20, [sp, #3536]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_372
LBB0_183:                               ; %else2035
	ldr	q1, [sp, #3536]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_373
LBB0_184:                               ; %else2041
	orr.16b	v25, v4, v0
	tbnz	w8, #3, LBB0_374
LBB0_185:                               ; %else2047
	add.2d	v1, v9, v25
	tbnz	w8, #4, LBB0_375
LBB0_186:                               ; %else2053
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_376
LBB0_187:                               ; %else2059
	str	q0, [sp, #1472]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_377
LBB0_188:                               ; %else2065
	str	q21, [sp, #12304]               ; 16-byte Spill
	str	q25, [sp, #1488]                ; 16-byte Spill
	tbz	w8, #7, LBB0_190
LBB0_189:                               ; %cond.load2067
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_190:                               ; %else2071
	str	q6, [sp, #12288]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #84                        ; =0x54
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #1456]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbnz	w9, #0, LBB0_378
; %bb.191:                              ; %else2078
	orr.16b	v6, v3, v0
	str	q6, [sp, #3520]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_379
LBB0_192:                               ; %else2084
	ldr	q1, [sp, #3520]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	mov.16b	v6, v21
	tbnz	w8, #2, LBB0_380
LBB0_193:                               ; %else2090
	orr.16b	v21, v4, v0
	tbnz	w8, #3, LBB0_381
LBB0_194:                               ; %else2096
	add.2d	v1, v9, v21
	tbnz	w8, #4, LBB0_382
LBB0_195:                               ; %else2102
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_383
LBB0_196:                               ; %else2108
	str	q0, [sp, #1424]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_384
LBB0_197:                               ; %else2114
	tbz	w8, #7, LBB0_199
LBB0_198:                               ; %cond.load2116
	mov.d	x8, v0[1]
	ld1.s	{ v6 }[3], [x8]
LBB0_199:                               ; %else2120
	str	q20, [sp, #12144]               ; 16-byte Spill
	str	q18, [sp, #11952]               ; 16-byte Spill
	str	q17, [sp, #11968]               ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #88                        ; =0x58
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #1408]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_385
; %bb.200:                              ; %else2127
	orr.16b	v20, v3, v0
	str	q20, [sp, #3504]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_386
LBB0_201:                               ; %else2133
	ldr	q1, [sp, #3504]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	str	q16, [sp, #12256]               ; 16-byte Spill
	tbnz	w8, #2, LBB0_387
LBB0_202:                               ; %else2139
	orr.16b	v24, v4, v0
	tbnz	w8, #3, LBB0_388
LBB0_203:                               ; %else2145
	add.2d	v1, v9, v24
	tbnz	w8, #4, LBB0_389
LBB0_204:                               ; %else2151
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_390
LBB0_205:                               ; %else2157
	str	q0, [sp, #1376]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_391
LBB0_206:                               ; %else2163
	tbz	w8, #7, LBB0_208
LBB0_207:                               ; %cond.load2165
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_208:                               ; %else2169
	str	q18, [sp, #12112]               ; 16-byte Spill
	str	q17, [sp, #12128]               ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #92                        ; =0x5c
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #1360]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_392
; %bb.209:                              ; %else2176
	str	q17, [sp, #12320]               ; 16-byte Spill
	orr.16b	v25, v3, v0
	tbnz	w8, #1, LBB0_393
LBB0_210:                               ; %else2182
	add.2d	v1, v9, v25
	str	q6, [sp, #12160]                ; 16-byte Spill
	tbnz	w8, #2, LBB0_394
LBB0_211:                               ; %else2188
	orr.16b	v6, v4, v0
	str	q6, [sp, #3488]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_395
LBB0_212:                               ; %else2194
	mov.16b	v6, v18
	ldr	q1, [sp, #3488]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_396
LBB0_213:                               ; %else2200
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_397
LBB0_214:                               ; %else2206
	str	q0, [sp, #1328]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_398
LBB0_215:                               ; %else2212
	tbz	w8, #7, LBB0_217
LBB0_216:                               ; %cond.load2214
	mov.d	x8, v0[1]
	ld1.s	{ v6 }[3], [x8]
LBB0_217:                               ; %else2218
	str	q6, [sp, #12416]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #96                        ; =0x60
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #1312]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v6, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbnz	w9, #0, LBB0_399
; %bb.218:                              ; %else2225
	str	q6, [sp, #12400]                ; 16-byte Spill
	orr.16b	v6, v3, v0
	tbnz	w8, #1, LBB0_400
LBB0_219:                               ; %else2231
	add.2d	v1, v9, v6
	str	q7, [sp, #12272]                ; 16-byte Spill
	tbnz	w8, #2, LBB0_401
LBB0_220:                               ; %else2237
	orr.16b	v7, v4, v0
	str	q7, [sp, #3472]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_402
LBB0_221:                               ; %else2243
	mov.16b	v7, v17
	ldr	q1, [sp, #3472]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_403
LBB0_222:                               ; %else2249
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_404
LBB0_223:                               ; %else2255
	str	q0, [sp, #1280]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_405
LBB0_224:                               ; %else2261
	tbz	w8, #7, LBB0_226
LBB0_225:                               ; %cond.load2263
	mov.d	x8, v0[1]
	ld1.s	{ v7 }[3], [x8]
LBB0_226:                               ; %else2267
	str	q7, [sp, #12368]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #100                       ; =0x64
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #1264]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v7, #0000000000000000
	tbnz	w9, #0, LBB0_406
; %bb.227:                              ; %else2274
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3456]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_407
LBB0_228:                               ; %else2280
	ldr	q1, [sp, #3456]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_408
LBB0_229:                               ; %else2286
	orr.16b	v7, v4, v0
	str	q7, [sp, #3440]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_409
LBB0_230:                               ; %cond.load2288
	mov.d	x9, v1[1]
	mov.16b	v7, v17
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #3440]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_410
	b	LBB0_411
LBB0_231:                               ; %cond.load
	fmov	x9, d1
	ldr	s5, [x9]
	and.16b	v6, v15, v0
	ushll2.2d	v3, v4, #8
	tbz	w8, #1, LBB0_3
LBB0_232:                               ; %cond.load1072
	mov.d	x9, v1[1]
	ld1.s	{ v5 }[1], [x9]
	add.2d	v0, v9, v3
	str	q4, [sp, #13648]                ; 16-byte Spill
	tbz	w8, #2, LBB0_4
LBB0_233:                               ; %cond.load1075
	fmov	x9, d0
	ld1.s	{ v5 }[2], [x9]
	ushll.2d	v4, v6, #8
	tbz	w8, #3, LBB0_5
LBB0_234:                               ; %cond.load1078
	mov.d	x9, v0[1]
	ld1.s	{ v5 }[3], [x9]
	add.2d	v0, v9, v4
	str	q5, [sp, #12816]                ; 16-byte Spill
	tbz	w8, #4, LBB0_6
LBB0_235:                               ; %cond.load1081
	fmov	x9, d0
	ld1.s	{ v13 }[0], [x9]
	ushll2.2d	v5, v6, #8
	tbz	w8, #5, LBB0_7
LBB0_236:                               ; %cond.load1084
	mov.d	x9, v0[1]
	ld1.s	{ v13 }[1], [x9]
	add.2d	v0, v9, v5
	tbz	w8, #6, LBB0_8
LBB0_237:                               ; %cond.load1087
	fmov	x9, d0
	ld1.s	{ v13 }[2], [x9]
	tbnz	w8, #7, LBB0_9
	b	LBB0_10
LBB0_238:                               ; %cond.load1094
	fmov	x9, d1
	ldr	s26, [x9]
	orr.16b	v6, v3, v0
	tbz	w8, #1, LBB0_12
LBB0_239:                               ; %cond.load1100
	mov.d	x9, v1[1]
	ld1.s	{ v26 }[1], [x9]
	add.2d	v1, v9, v6
	tbz	w8, #2, LBB0_13
LBB0_240:                               ; %cond.load1106
	fmov	x9, d1
	ld1.s	{ v26 }[2], [x9]
	orr.16b	v20, v4, v0
	str	q20, [sp, #4112]                ; 16-byte Spill
	tbz	w8, #3, LBB0_14
LBB0_241:                               ; %cond.load1112
	mov.d	x9, v1[1]
	ld1.s	{ v26 }[3], [x9]
	ldr	q1, [sp, #4112]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_15
LBB0_242:                               ; %cond.load1118
	fmov	x9, d1
	ld1.s	{ v12 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_16
LBB0_243:                               ; %cond.load1124
	mov.d	x9, v1[1]
	ld1.s	{ v12 }[1], [x9]
	str	q0, [sp, #2112]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_17
LBB0_244:                               ; %cond.load1130
	fmov	x9, d0
	ld1.s	{ v12 }[2], [x9]
	tbnz	w8, #7, LBB0_18
	b	LBB0_19
LBB0_245:                               ; %cond.load1143
	fmov	x9, d1
	ldr	s31, [x9]
	orr.16b	v20, v3, v0
	str	q20, [sp, #4096]                ; 16-byte Spill
	tbz	w8, #1, LBB0_21
LBB0_246:                               ; %cond.load1149
	mov.d	x9, v1[1]
	ld1.s	{ v31 }[1], [x9]
	ldr	q1, [sp, #4096]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_22
LBB0_247:                               ; %cond.load1155
	fmov	x9, d1
	ld1.s	{ v31 }[2], [x9]
	orr.16b	v20, v4, v0
	str	q20, [sp, #4080]                ; 16-byte Spill
	tbz	w8, #3, LBB0_23
LBB0_248:                               ; %cond.load1161
	mov.d	x9, v1[1]
	ld1.s	{ v31 }[3], [x9]
	ldr	q1, [sp, #4080]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_24
LBB0_249:                               ; %cond.load1167
	fmov	x9, d1
	ld1.s	{ v27 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_25
LBB0_250:                               ; %cond.load1173
	mov.d	x9, v1[1]
	ld1.s	{ v27 }[1], [x9]
	str	q0, [sp, #2080]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_26
LBB0_251:                               ; %cond.load1179
	fmov	x9, d0
	ld1.s	{ v27 }[2], [x9]
	tbnz	w8, #7, LBB0_27
	b	LBB0_28
LBB0_252:                               ; %cond.load1192
	fmov	x9, d1
	ldr	s11, [x9]
	orr.16b	v20, v3, v0
	str	q20, [sp, #4064]                ; 16-byte Spill
	tbz	w8, #1, LBB0_30
LBB0_253:                               ; %cond.load1198
	mov.d	x9, v1[1]
	ld1.s	{ v11 }[1], [x9]
	ldr	q1, [sp, #4064]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_31
LBB0_254:                               ; %cond.load1204
	fmov	x9, d1
	ld1.s	{ v11 }[2], [x9]
	orr.16b	v20, v4, v0
	str	q20, [sp, #4048]                ; 16-byte Spill
	tbz	w8, #3, LBB0_32
LBB0_255:                               ; %cond.load1210
	mov.d	x9, v1[1]
	ld1.s	{ v11 }[3], [x9]
	ldr	q1, [sp, #4048]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_33
LBB0_256:                               ; %cond.load1216
	fmov	x9, d1
	ld1.s	{ v25 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_34
LBB0_257:                               ; %cond.load1222
	mov.d	x9, v1[1]
	ld1.s	{ v25 }[1], [x9]
	str	q0, [sp, #2048]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_35
LBB0_258:                               ; %cond.load1228
	fmov	x9, d0
	ld1.s	{ v25 }[2], [x9]
	tbnz	w8, #7, LBB0_36
	b	LBB0_37
LBB0_259:                               ; %cond.load1241
	fmov	x9, d1
	ldr	s8, [x9]
	orr.16b	v20, v3, v0
	str	q20, [sp, #4032]                ; 16-byte Spill
	tbz	w8, #1, LBB0_39
LBB0_260:                               ; %cond.load1247
	mov.d	x9, v1[1]
	ld1.s	{ v8 }[1], [x9]
	ldr	q1, [sp, #4032]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_40
LBB0_261:                               ; %cond.load1253
	fmov	x9, d1
	ld1.s	{ v8 }[2], [x9]
	orr.16b	v20, v4, v0
	str	q20, [sp, #4016]                ; 16-byte Spill
	tbz	w8, #3, LBB0_41
LBB0_262:                               ; %cond.load1259
	mov.d	x9, v1[1]
	ld1.s	{ v8 }[3], [x9]
	ldr	q1, [sp, #4016]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_42
LBB0_263:                               ; %cond.load1265
	fmov	x9, d1
	ld1.s	{ v10 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_43
LBB0_264:                               ; %cond.load1271
	mov.d	x9, v1[1]
	ld1.s	{ v10 }[1], [x9]
	str	q0, [sp, #2016]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_44
LBB0_265:                               ; %cond.load1277
	fmov	x9, d0
	ld1.s	{ v10 }[2], [x9]
	str	q6, [sp, #2128]                 ; 16-byte Spill
	tbnz	w8, #7, LBB0_45
	b	LBB0_46
LBB0_266:                               ; %cond.load1290
	fmov	x9, d1
	ldr	s23, [x9]
	orr.16b	v20, v3, v0
	str	q20, [sp, #4000]                ; 16-byte Spill
	tbz	w8, #1, LBB0_48
LBB0_267:                               ; %cond.load1296
	mov.d	x9, v1[1]
	ld1.s	{ v23 }[1], [x9]
	ldr	q1, [sp, #4000]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_49
LBB0_268:                               ; %cond.load1302
	fmov	x9, d1
	ld1.s	{ v23 }[2], [x9]
	orr.16b	v20, v4, v0
	str	q20, [sp, #3984]                ; 16-byte Spill
	tbz	w8, #3, LBB0_50
LBB0_269:                               ; %cond.load1308
	mov.d	x9, v1[1]
	ld1.s	{ v23 }[3], [x9]
	ldr	q1, [sp, #3984]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_51
LBB0_270:                               ; %cond.load1314
	fmov	x9, d1
	ld1.s	{ v6 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_52
LBB0_271:                               ; %cond.load1320
	mov.d	x9, v1[1]
	ld1.s	{ v6 }[1], [x9]
	str	q0, [sp, #1984]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_53
LBB0_272:                               ; %cond.load1326
	fmov	x9, d0
	ld1.s	{ v6 }[2], [x9]
	tbnz	w8, #7, LBB0_54
	b	LBB0_55
LBB0_273:                               ; %cond.load1339
	fmov	x9, d1
	ldr	s21, [x9]
	orr.16b	v20, v3, v0
	str	q20, [sp, #3968]                ; 16-byte Spill
	tbz	w8, #1, LBB0_57
LBB0_274:                               ; %cond.load1345
	mov.d	x9, v1[1]
	ld1.s	{ v21 }[1], [x9]
	ldr	q1, [sp, #3968]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_58
LBB0_275:                               ; %cond.load1351
	fmov	x9, d1
	ld1.s	{ v21 }[2], [x9]
	orr.16b	v20, v4, v0
	str	q20, [sp, #3952]                ; 16-byte Spill
	tbz	w8, #3, LBB0_59
LBB0_276:                               ; %cond.load1357
	mov.d	x9, v1[1]
	ld1.s	{ v21 }[3], [x9]
	ldr	q1, [sp, #3952]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_60
LBB0_277:                               ; %cond.load1363
	fmov	x9, d1
	ld1.s	{ v6 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_61
LBB0_278:                               ; %cond.load1369
	mov.d	x9, v1[1]
	ld1.s	{ v6 }[1], [x9]
	str	q0, [sp, #1952]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_62
LBB0_279:                               ; %cond.load1375
	fmov	x9, d0
	ld1.s	{ v6 }[2], [x9]
	tbnz	w8, #7, LBB0_63
	b	LBB0_64
LBB0_280:                               ; %cond.load1388
	fmov	x9, d1
	ldr	s7, [x9]
	orr.16b	v20, v3, v0
	str	q20, [sp, #3936]                ; 16-byte Spill
	tbz	w8, #1, LBB0_66
LBB0_281:                               ; %cond.load1394
	mov.d	x9, v1[1]
	ld1.s	{ v7 }[1], [x9]
	ldr	q1, [sp, #3936]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_67
LBB0_282:                               ; %cond.load1400
	fmov	x9, d1
	ld1.s	{ v7 }[2], [x9]
	orr.16b	v20, v4, v0
	str	q20, [sp, #3920]                ; 16-byte Spill
	tbz	w8, #3, LBB0_68
LBB0_283:                               ; %cond.load1406
	mov.d	x9, v1[1]
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #3920]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_69
LBB0_284:                               ; %cond.load1412
	fmov	x9, d1
	ld1.s	{ v16 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_70
LBB0_285:                               ; %cond.load1418
	mov.d	x9, v1[1]
	ld1.s	{ v16 }[1], [x9]
	str	q0, [sp, #1920]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_71
LBB0_286:                               ; %cond.load1424
	fmov	x9, d0
	ld1.s	{ v16 }[2], [x9]
	tbnz	w8, #7, LBB0_72
	b	LBB0_73
LBB0_287:                               ; %cond.load1437
	fmov	x9, d1
	ldr	s17, [x9]
	orr.16b	v20, v3, v0
	str	q20, [sp, #3904]                ; 16-byte Spill
	tbz	w8, #1, LBB0_75
LBB0_288:                               ; %cond.load1443
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	ldr	q1, [sp, #3904]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_76
LBB0_289:                               ; %cond.load1449
	fmov	x9, d1
	ld1.s	{ v17 }[2], [x9]
	orr.16b	v20, v4, v0
	str	q20, [sp, #3888]                ; 16-byte Spill
	tbz	w8, #3, LBB0_77
LBB0_290:                               ; %cond.load1455
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[3], [x9]
	ldr	q1, [sp, #3888]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_78
LBB0_291:                               ; %cond.load1461
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_79
LBB0_292:                               ; %cond.load1467
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #1888]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_80
LBB0_293:                               ; %cond.load1473
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	str	q6, [sp, #13856]                ; 16-byte Spill
	tbnz	w8, #7, LBB0_81
	b	LBB0_82
LBB0_294:                               ; %cond.load1486
	fmov	x9, d1
	ldr	s30, [x9]
	orr.16b	v20, v3, v0
	str	q20, [sp, #3872]                ; 16-byte Spill
	tbz	w8, #1, LBB0_84
LBB0_295:                               ; %cond.load1492
	mov.d	x9, v1[1]
	ld1.s	{ v30 }[1], [x9]
	ldr	q1, [sp, #3872]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_85
LBB0_296:                               ; %cond.load1498
	fmov	x9, d1
	ld1.s	{ v30 }[2], [x9]
	orr.16b	v20, v4, v0
	str	q20, [sp, #3856]                ; 16-byte Spill
	tbz	w8, #3, LBB0_86
LBB0_297:                               ; %cond.load1504
	mov.d	x9, v1[1]
	ld1.s	{ v30 }[3], [x9]
	ldr	q1, [sp, #3856]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_87
LBB0_298:                               ; %cond.load1510
	fmov	x9, d1
	ld1.s	{ v6 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_88
LBB0_299:                               ; %cond.load1516
	mov.d	x9, v1[1]
	ld1.s	{ v6 }[1], [x9]
	str	q0, [sp, #1856]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_89
LBB0_300:                               ; %cond.load1522
	fmov	x9, d0
	ld1.s	{ v6 }[2], [x9]
	tbnz	w8, #7, LBB0_90
	b	LBB0_91
LBB0_301:                               ; %cond.load1535
	fmov	x9, d1
	ldr	s22, [x9]
	orr.16b	v20, v3, v0
	str	q20, [sp, #3840]                ; 16-byte Spill
	tbz	w8, #1, LBB0_93
LBB0_302:                               ; %cond.load1541
	mov.d	x9, v1[1]
	ld1.s	{ v22 }[1], [x9]
	ldr	q1, [sp, #3840]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_94
LBB0_303:                               ; %cond.load1547
	fmov	x9, d1
	ld1.s	{ v22 }[2], [x9]
	orr.16b	v20, v4, v0
	str	q20, [sp, #3824]                ; 16-byte Spill
	tbz	w8, #3, LBB0_95
LBB0_304:                               ; %cond.load1553
	mov.d	x9, v1[1]
	ld1.s	{ v22 }[3], [x9]
	ldr	q1, [sp, #3824]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_96
LBB0_305:                               ; %cond.load1559
	fmov	x9, d1
	ld1.s	{ v6 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_97
LBB0_306:                               ; %cond.load1565
	mov.d	x9, v1[1]
	ld1.s	{ v6 }[1], [x9]
	str	q0, [sp, #1824]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_98
LBB0_307:                               ; %cond.load1571
	fmov	x9, d0
	ld1.s	{ v6 }[2], [x9]
	tbnz	w8, #7, LBB0_99
	b	LBB0_100
LBB0_308:                               ; %cond.load1584
	fmov	x9, d1
	ldr	s6, [x9]
	str	q6, [sp, #13984]                ; 16-byte Spill
	movi.2d	v6, #0000000000000000
	str	q6, [sp, #13968]                ; 16-byte Spill
	orr.16b	v20, v3, v0
	str	q20, [sp, #3808]                ; 16-byte Spill
	tbz	w8, #1, LBB0_102
LBB0_309:                               ; %cond.load1590
	mov.d	x9, v1[1]
	ldr	q1, [sp, #13984]                ; 16-byte Reload
	ld1.s	{ v1 }[1], [x9]
	str	q1, [sp, #13984]                ; 16-byte Spill
	ldr	q1, [sp, #3808]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_103
LBB0_310:                               ; %cond.load1596
	fmov	x9, d1
	ldr	q6, [sp, #13984]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #13984]                ; 16-byte Spill
	orr.16b	v20, v4, v0
	str	q20, [sp, #3792]                ; 16-byte Spill
	tbz	w8, #3, LBB0_104
LBB0_311:                               ; %cond.load1602
	mov.d	x9, v1[1]
	ldr	q1, [sp, #13984]                ; 16-byte Reload
	ld1.s	{ v1 }[3], [x9]
	str	q1, [sp, #13984]                ; 16-byte Spill
	ldr	q1, [sp, #3792]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_105
LBB0_312:                               ; %cond.load1608
	fmov	x9, d1
	ldr	q6, [sp, #13968]                ; 16-byte Reload
	ld1.s	{ v6 }[0], [x9]
	str	q6, [sp, #13968]                ; 16-byte Spill
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_106
LBB0_313:                               ; %cond.load1614
	mov.d	x9, v1[1]
	ldr	q1, [sp, #13968]                ; 16-byte Reload
	ld1.s	{ v1 }[1], [x9]
	str	q1, [sp, #13968]                ; 16-byte Spill
	str	q0, [sp, #1792]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_107
LBB0_314:                               ; %cond.load1620
	fmov	x9, d0
	ldr	q1, [sp, #13968]                ; 16-byte Reload
	ld1.s	{ v1 }[2], [x9]
	str	q1, [sp, #13968]                ; 16-byte Spill
	tbnz	w8, #7, LBB0_108
	b	LBB0_109
LBB0_315:                               ; %cond.load1633
	fmov	x9, d1
	ldr	s6, [x9]
	str	q6, [sp, #13952]                ; 16-byte Spill
	movi.2d	v6, #0000000000000000
	str	q6, [sp, #12928]                ; 16-byte Spill
	orr.16b	v20, v3, v0
	str	q20, [sp, #3776]                ; 16-byte Spill
	tbz	w8, #1, LBB0_111
LBB0_316:                               ; %cond.load1639
	mov.d	x9, v1[1]
	ldr	q1, [sp, #13952]                ; 16-byte Reload
	ld1.s	{ v1 }[1], [x9]
	str	q1, [sp, #13952]                ; 16-byte Spill
	ldr	q1, [sp, #3776]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_112
LBB0_317:                               ; %cond.load1645
	fmov	x9, d1
	ldr	q6, [sp, #13952]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #13952]                ; 16-byte Spill
	orr.16b	v20, v4, v0
	str	q20, [sp, #3760]                ; 16-byte Spill
	tbz	w8, #3, LBB0_113
LBB0_318:                               ; %cond.load1651
	mov.d	x9, v1[1]
	ldr	q1, [sp, #13952]                ; 16-byte Reload
	ld1.s	{ v1 }[3], [x9]
	str	q1, [sp, #13952]                ; 16-byte Spill
	ldr	q1, [sp, #3760]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_114
LBB0_319:                               ; %cond.load1657
	fmov	x9, d1
	ldr	q6, [sp, #12928]                ; 16-byte Reload
	ld1.s	{ v6 }[0], [x9]
	str	q6, [sp, #12928]                ; 16-byte Spill
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_115
LBB0_320:                               ; %cond.load1663
	mov.d	x9, v1[1]
	ldr	q1, [sp, #12928]                ; 16-byte Reload
	ld1.s	{ v1 }[1], [x9]
	str	q1, [sp, #12928]                ; 16-byte Spill
	str	q0, [sp, #1760]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_116
LBB0_321:                               ; %cond.load1669
	fmov	x9, d0
	ldr	q1, [sp, #12928]                ; 16-byte Reload
	ld1.s	{ v1 }[2], [x9]
	str	q1, [sp, #12928]                ; 16-byte Spill
	str	q7, [sp, #13840]                ; 16-byte Spill
	tbnz	w8, #7, LBB0_117
	b	LBB0_118
LBB0_322:                               ; %cond.load1682
	fmov	x9, d1
	ldr	s6, [x9]
	orr.16b	v20, v3, v0
	str	q20, [sp, #3744]                ; 16-byte Spill
	tbz	w8, #1, LBB0_120
LBB0_323:                               ; %cond.load1688
	mov.d	x9, v1[1]
	ld1.s	{ v6 }[1], [x9]
	ldr	q1, [sp, #3744]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_121
LBB0_324:                               ; %cond.load1694
	fmov	x9, d1
	ld1.s	{ v6 }[2], [x9]
	orr.16b	v20, v4, v0
	str	q20, [sp, #3728]                ; 16-byte Spill
	tbz	w8, #3, LBB0_122
LBB0_325:                               ; %cond.load1700
	mov.d	x9, v1[1]
	ld1.s	{ v6 }[3], [x9]
	ldr	q1, [sp, #3728]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_123
LBB0_326:                               ; %cond.load1706
	fmov	x9, d1
	ld1.s	{ v7 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_124
LBB0_327:                               ; %cond.load1712
	mov.d	x9, v1[1]
	ld1.s	{ v7 }[1], [x9]
	str	q0, [sp, #1728]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_125
LBB0_328:                               ; %cond.load1718
	fmov	x9, d0
	ld1.s	{ v7 }[2], [x9]
	str	q16, [sp, #13824]               ; 16-byte Spill
	str	q17, [sp, #13808]               ; 16-byte Spill
	tbnz	w8, #7, LBB0_126
	b	LBB0_127
LBB0_329:                               ; %cond.load1731
	fmov	x9, d1
	ldr	s16, [x9]
	orr.16b	v20, v3, v0
	str	q20, [sp, #3712]                ; 16-byte Spill
	tbz	w8, #1, LBB0_129
LBB0_330:                               ; %cond.load1737
	mov.d	x9, v1[1]
	ld1.s	{ v16 }[1], [x9]
	ldr	q1, [sp, #3712]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_130
LBB0_331:                               ; %cond.load1743
	fmov	x9, d1
	ld1.s	{ v16 }[2], [x9]
	orr.16b	v20, v4, v0
	str	q20, [sp, #3696]                ; 16-byte Spill
	tbz	w8, #3, LBB0_131
LBB0_332:                               ; %cond.load1749
	mov.d	x9, v1[1]
	ld1.s	{ v16 }[3], [x9]
	ldr	q1, [sp, #3696]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_132
LBB0_333:                               ; %cond.load1755
	fmov	x9, d1
	ld1.s	{ v17 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_133
LBB0_334:                               ; %cond.load1761
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	str	q0, [sp, #1696]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_134
LBB0_335:                               ; %cond.load1767
	fmov	x9, d0
	ld1.s	{ v17 }[2], [x9]
	str	q18, [sp, #12080]               ; 16-byte Spill
	tbnz	w8, #7, LBB0_135
	b	LBB0_136
LBB0_336:                               ; %cond.load1780
	fmov	x9, d1
	ldr	s17, [x9]
	orr.16b	v20, v3, v0
	str	q20, [sp, #3680]                ; 16-byte Spill
	tbz	w8, #1, LBB0_138
LBB0_337:                               ; %cond.load1786
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	ldr	q1, [sp, #3680]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_139
LBB0_338:                               ; %cond.load1792
	fmov	x9, d1
	ld1.s	{ v17 }[2], [x9]
	orr.16b	v20, v4, v0
	str	q20, [sp, #3664]                ; 16-byte Spill
	tbz	w8, #3, LBB0_140
LBB0_339:                               ; %cond.load1798
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[3], [x9]
	ldr	q1, [sp, #3664]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_141
LBB0_340:                               ; %cond.load1804
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_142
LBB0_341:                               ; %cond.load1810
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #1664]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_143
LBB0_342:                               ; %cond.load1816
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	tbnz	w8, #7, LBB0_144
	b	LBB0_145
LBB0_343:                               ; %cond.load1829
	fmov	x9, d1
	ldr	s17, [x9]
	orr.16b	v20, v3, v0
	str	q20, [sp, #3648]                ; 16-byte Spill
	tbz	w8, #1, LBB0_147
LBB0_344:                               ; %cond.load1835
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	ldr	q1, [sp, #3648]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_148
LBB0_345:                               ; %cond.load1841
	fmov	x9, d1
	ld1.s	{ v17 }[2], [x9]
	orr.16b	v20, v4, v0
	str	q20, [sp, #3632]                ; 16-byte Spill
	tbz	w8, #3, LBB0_149
LBB0_346:                               ; %cond.load1847
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[3], [x9]
	ldr	q1, [sp, #3632]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_150
LBB0_347:                               ; %cond.load1853
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_151
LBB0_348:                               ; %cond.load1859
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #1632]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_152
LBB0_349:                               ; %cond.load1865
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	tbnz	w8, #7, LBB0_153
	b	LBB0_154
LBB0_350:                               ; %cond.load1878
	fmov	x9, d1
	ldr	s17, [x9]
	orr.16b	v20, v3, v0
	str	q20, [sp, #3616]                ; 16-byte Spill
	tbz	w8, #1, LBB0_156
LBB0_351:                               ; %cond.load1884
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	ldr	q1, [sp, #3616]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_157
LBB0_352:                               ; %cond.load1890
	fmov	x9, d1
	ld1.s	{ v17 }[2], [x9]
	orr.16b	v20, v4, v0
	str	q20, [sp, #3600]                ; 16-byte Spill
	tbz	w8, #3, LBB0_158
LBB0_353:                               ; %cond.load1896
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[3], [x9]
	ldr	q1, [sp, #3600]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_159
LBB0_354:                               ; %cond.load1902
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_160
LBB0_355:                               ; %cond.load1908
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #1600]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_161
LBB0_356:                               ; %cond.load1914
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	tbnz	w8, #7, LBB0_162
	b	LBB0_163
LBB0_357:                               ; %cond.load1927
	fmov	x9, d1
	ldr	s17, [x9]
	orr.16b	v20, v3, v0
	str	q20, [sp, #3584]                ; 16-byte Spill
	tbz	w8, #1, LBB0_165
LBB0_358:                               ; %cond.load1933
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	ldr	q1, [sp, #3584]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	str	q22, [sp, #12624]               ; 16-byte Spill
	tbz	w8, #2, LBB0_166
LBB0_359:                               ; %cond.load1939
	fmov	x9, d1
	ld1.s	{ v17 }[2], [x9]
	orr.16b	v25, v4, v0
	tbz	w8, #3, LBB0_167
LBB0_360:                               ; %cond.load1945
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[3], [x9]
	add.2d	v1, v9, v25
	tbz	w8, #4, LBB0_168
LBB0_361:                               ; %cond.load1951
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_169
LBB0_362:                               ; %cond.load1957
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #1552]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_170
LBB0_363:                               ; %cond.load1963
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	tbnz	w8, #7, LBB0_171
	b	LBB0_172
LBB0_364:                               ; %cond.load1976
	fmov	x9, d1
	ldr	s17, [x9]
	orr.16b	v20, v3, v0
	str	q20, [sp, #3568]                ; 16-byte Spill
	tbz	w8, #1, LBB0_174
LBB0_365:                               ; %cond.load1982
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	ldr	q1, [sp, #3568]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_175
LBB0_366:                               ; %cond.load1988
	fmov	x9, d1
	ld1.s	{ v17 }[2], [x9]
	orr.16b	v20, v4, v0
	str	q20, [sp, #3552]                ; 16-byte Spill
	tbz	w8, #3, LBB0_176
LBB0_367:                               ; %cond.load1994
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[3], [x9]
	ldr	q1, [sp, #3552]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_177
LBB0_368:                               ; %cond.load2000
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_178
LBB0_369:                               ; %cond.load2006
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #1520]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_179
LBB0_370:                               ; %cond.load2012
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	tbnz	w8, #7, LBB0_180
	b	LBB0_181
LBB0_371:                               ; %cond.load2025
	fmov	x9, d1
	ldr	s17, [x9]
	orr.16b	v20, v3, v0
	str	q20, [sp, #3536]                ; 16-byte Spill
	tbz	w8, #1, LBB0_183
LBB0_372:                               ; %cond.load2031
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	ldr	q1, [sp, #3536]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_184
LBB0_373:                               ; %cond.load2037
	fmov	x9, d1
	ld1.s	{ v17 }[2], [x9]
	orr.16b	v25, v4, v0
	tbz	w8, #3, LBB0_185
LBB0_374:                               ; %cond.load2043
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[3], [x9]
	add.2d	v1, v9, v25
	tbz	w8, #4, LBB0_186
LBB0_375:                               ; %cond.load2049
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_187
LBB0_376:                               ; %cond.load2055
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #1472]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_188
LBB0_377:                               ; %cond.load2061
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	str	q21, [sp, #12304]               ; 16-byte Spill
	str	q25, [sp, #1488]                ; 16-byte Spill
	tbnz	w8, #7, LBB0_189
	b	LBB0_190
LBB0_378:                               ; %cond.load2074
	fmov	x9, d1
	ldr	s20, [x9]
	orr.16b	v6, v3, v0
	str	q6, [sp, #3520]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_192
LBB0_379:                               ; %cond.load2080
	mov.d	x9, v1[1]
	ld1.s	{ v20 }[1], [x9]
	ldr	q1, [sp, #3520]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	mov.16b	v6, v21
	tbz	w8, #2, LBB0_193
LBB0_380:                               ; %cond.load2086
	fmov	x9, d1
	ld1.s	{ v20 }[2], [x9]
	orr.16b	v21, v4, v0
	tbz	w8, #3, LBB0_194
LBB0_381:                               ; %cond.load2092
	mov.d	x9, v1[1]
	ld1.s	{ v20 }[3], [x9]
	add.2d	v1, v9, v21
	tbz	w8, #4, LBB0_195
LBB0_382:                               ; %cond.load2098
	fmov	x9, d1
	ld1.s	{ v6 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_196
LBB0_383:                               ; %cond.load2104
	mov.d	x9, v1[1]
	ld1.s	{ v6 }[1], [x9]
	str	q0, [sp, #1424]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_197
LBB0_384:                               ; %cond.load2110
	fmov	x9, d0
	ld1.s	{ v6 }[2], [x9]
	tbnz	w8, #7, LBB0_198
	b	LBB0_199
LBB0_385:                               ; %cond.load2123
	fmov	x9, d1
	ldr	s17, [x9]
	orr.16b	v20, v3, v0
	str	q20, [sp, #3504]                ; 16-byte Spill
	tbz	w8, #1, LBB0_201
LBB0_386:                               ; %cond.load2129
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	ldr	q1, [sp, #3504]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	str	q16, [sp, #12256]               ; 16-byte Spill
	tbz	w8, #2, LBB0_202
LBB0_387:                               ; %cond.load2135
	fmov	x9, d1
	ld1.s	{ v17 }[2], [x9]
	orr.16b	v24, v4, v0
	tbz	w8, #3, LBB0_203
LBB0_388:                               ; %cond.load2141
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[3], [x9]
	add.2d	v1, v9, v24
	tbz	w8, #4, LBB0_204
LBB0_389:                               ; %cond.load2147
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_205
LBB0_390:                               ; %cond.load2153
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #1376]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_206
LBB0_391:                               ; %cond.load2159
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	tbnz	w8, #7, LBB0_207
	b	LBB0_208
LBB0_392:                               ; %cond.load2172
	fmov	x9, d1
	ldr	s17, [x9]
	str	q17, [sp, #12320]               ; 16-byte Spill
	orr.16b	v25, v3, v0
	tbz	w8, #1, LBB0_210
LBB0_393:                               ; %cond.load2178
	mov.d	x9, v1[1]
	ldr	q1, [sp, #12320]                ; 16-byte Reload
	ld1.s	{ v1 }[1], [x9]
	str	q1, [sp, #12320]                ; 16-byte Spill
	add.2d	v1, v9, v25
	str	q6, [sp, #12160]                ; 16-byte Spill
	tbz	w8, #2, LBB0_211
LBB0_394:                               ; %cond.load2184
	fmov	x9, d1
	ldr	q6, [sp, #12320]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #12320]                ; 16-byte Spill
	orr.16b	v6, v4, v0
	str	q6, [sp, #3488]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_212
LBB0_395:                               ; %cond.load2190
	mov.d	x9, v1[1]
	ldr	q1, [sp, #12320]                ; 16-byte Reload
	ld1.s	{ v1 }[3], [x9]
	str	q1, [sp, #12320]                ; 16-byte Spill
	mov.16b	v6, v18
	ldr	q1, [sp, #3488]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_213
LBB0_396:                               ; %cond.load2196
	fmov	x9, d1
	ld1.s	{ v6 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_214
LBB0_397:                               ; %cond.load2202
	mov.d	x9, v1[1]
	ld1.s	{ v6 }[1], [x9]
	str	q0, [sp, #1328]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_215
LBB0_398:                               ; %cond.load2208
	fmov	x9, d0
	ld1.s	{ v6 }[2], [x9]
	tbnz	w8, #7, LBB0_216
	b	LBB0_217
LBB0_399:                               ; %cond.load2221
	fmov	x9, d1
	ldr	s6, [x9]
	str	q6, [sp, #12400]                ; 16-byte Spill
	orr.16b	v6, v3, v0
	tbz	w8, #1, LBB0_219
LBB0_400:                               ; %cond.load2227
	mov.d	x9, v1[1]
	ldr	q1, [sp, #12400]                ; 16-byte Reload
	ld1.s	{ v1 }[1], [x9]
	str	q1, [sp, #12400]                ; 16-byte Spill
	add.2d	v1, v9, v6
	str	q7, [sp, #12272]                ; 16-byte Spill
	tbz	w8, #2, LBB0_220
LBB0_401:                               ; %cond.load2233
	fmov	x9, d1
	ldr	q7, [sp, #12400]                ; 16-byte Reload
	ld1.s	{ v7 }[2], [x9]
	str	q7, [sp, #12400]                ; 16-byte Spill
	orr.16b	v7, v4, v0
	str	q7, [sp, #3472]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_221
LBB0_402:                               ; %cond.load2239
	mov.d	x9, v1[1]
	ldr	q1, [sp, #12400]                ; 16-byte Reload
	ld1.s	{ v1 }[3], [x9]
	str	q1, [sp, #12400]                ; 16-byte Spill
	mov.16b	v7, v17
	ldr	q1, [sp, #3472]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_222
LBB0_403:                               ; %cond.load2245
	fmov	x9, d1
	ld1.s	{ v7 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_223
LBB0_404:                               ; %cond.load2251
	mov.d	x9, v1[1]
	ld1.s	{ v7 }[1], [x9]
	str	q0, [sp, #1280]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_224
LBB0_405:                               ; %cond.load2257
	fmov	x9, d0
	ld1.s	{ v7 }[2], [x9]
	tbnz	w8, #7, LBB0_225
	b	LBB0_226
LBB0_406:                               ; %cond.load2270
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3456]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_228
LBB0_407:                               ; %cond.load2276
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	ldr	q1, [sp, #3456]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_229
LBB0_408:                               ; %cond.load2282
	fmov	x9, d1
	ld1.s	{ v17 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #3440]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_230
LBB0_409:
	mov.16b	v7, v17
	ldr	q1, [sp, #3440]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_411
LBB0_410:                               ; %cond.load2294
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
LBB0_411:                               ; %else2298
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_420
; %bb.412:                              ; %else2304
	str	q0, [sp, #1248]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_421
LBB0_413:                               ; %else2310
	tbz	w8, #7, LBB0_415
LBB0_414:                               ; %cond.load2312
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_415:                               ; %else2316
	str	q18, [sp, #12464]               ; 16-byte Spill
	str	q7, [sp, #12064]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #104                       ; =0x68
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #1232]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_422
; %bb.416:                              ; %else2323
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3424]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_423
LBB0_417:                               ; %else2329
	ldr	q1, [sp, #3424]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_424
LBB0_418:                               ; %else2335
	orr.16b	v7, v4, v0
	str	q7, [sp, #3408]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_425
LBB0_419:                               ; %cond.load2337
	mov.d	x9, v1[1]
	mov.16b	v7, v17
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #3408]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_426
	b	LBB0_427
LBB0_420:                               ; %cond.load2300
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #1248]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_413
LBB0_421:                               ; %cond.load2306
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	tbnz	w8, #7, LBB0_414
	b	LBB0_415
LBB0_422:                               ; %cond.load2319
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3424]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_417
LBB0_423:                               ; %cond.load2325
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	ldr	q1, [sp, #3424]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_418
LBB0_424:                               ; %cond.load2331
	fmov	x9, d1
	ld1.s	{ v17 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #3408]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_419
LBB0_425:
	mov.16b	v7, v17
	ldr	q1, [sp, #3408]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_427
LBB0_426:                               ; %cond.load2343
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
LBB0_427:                               ; %else2347
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_436
; %bb.428:                              ; %else2353
	str	q0, [sp, #1216]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_437
LBB0_429:                               ; %else2359
	tbz	w8, #7, LBB0_431
LBB0_430:                               ; %cond.load2361
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_431:                               ; %else2365
	str	q18, [sp, #12800]               ; 16-byte Spill
	str	q7, [sp, #12352]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #108                       ; =0x6c
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #1200]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_438
; %bb.432:                              ; %else2372
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3392]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_439
LBB0_433:                               ; %else2378
	ldr	q1, [sp, #3392]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_440
LBB0_434:                               ; %else2384
	orr.16b	v7, v4, v0
	str	q7, [sp, #3376]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_441
LBB0_435:                               ; %cond.load2386
	mov.d	x9, v1[1]
	mov.16b	v7, v17
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #3376]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_442
	b	LBB0_443
LBB0_436:                               ; %cond.load2349
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #1216]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_429
LBB0_437:                               ; %cond.load2355
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	tbnz	w8, #7, LBB0_430
	b	LBB0_431
LBB0_438:                               ; %cond.load2368
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3392]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_433
LBB0_439:                               ; %cond.load2374
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	ldr	q1, [sp, #3392]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_434
LBB0_440:                               ; %cond.load2380
	fmov	x9, d1
	ld1.s	{ v17 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #3376]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_435
LBB0_441:
	mov.16b	v7, v17
	ldr	q1, [sp, #3376]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_443
LBB0_442:                               ; %cond.load2392
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
LBB0_443:                               ; %else2396
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_452
; %bb.444:                              ; %else2402
	str	q0, [sp, #1184]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_453
LBB0_445:                               ; %else2408
	tbz	w8, #7, LBB0_447
LBB0_446:                               ; %cond.load2410
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_447:                               ; %else2414
	str	q18, [sp, #12784]               ; 16-byte Spill
	str	q7, [sp, #12336]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #112                       ; =0x70
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #1168]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_454
; %bb.448:                              ; %else2421
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3360]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_455
LBB0_449:                               ; %else2427
	ldr	q1, [sp, #3360]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_456
LBB0_450:                               ; %else2433
	orr.16b	v7, v4, v0
	str	q7, [sp, #3344]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_457
LBB0_451:                               ; %cond.load2435
	mov.d	x9, v1[1]
	mov.16b	v7, v17
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #3344]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_458
	b	LBB0_459
LBB0_452:                               ; %cond.load2398
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #1184]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_445
LBB0_453:                               ; %cond.load2404
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	tbnz	w8, #7, LBB0_446
	b	LBB0_447
LBB0_454:                               ; %cond.load2417
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3360]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_449
LBB0_455:                               ; %cond.load2423
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	ldr	q1, [sp, #3360]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_450
LBB0_456:                               ; %cond.load2429
	fmov	x9, d1
	ld1.s	{ v17 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #3344]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_451
LBB0_457:
	mov.16b	v7, v17
	ldr	q1, [sp, #3344]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_459
LBB0_458:                               ; %cond.load2441
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
LBB0_459:                               ; %else2445
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_468
; %bb.460:                              ; %else2451
	str	q0, [sp, #1152]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_469
LBB0_461:                               ; %else2457
	tbz	w8, #7, LBB0_463
LBB0_462:                               ; %cond.load2459
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_463:                               ; %else2463
	str	q18, [sp, #12960]               ; 16-byte Spill
	str	q7, [sp, #12576]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #116                       ; =0x74
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #1136]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_470
; %bb.464:                              ; %else2470
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3328]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_471
LBB0_465:                               ; %else2476
	ldr	q1, [sp, #3328]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_472
LBB0_466:                               ; %else2482
	orr.16b	v7, v4, v0
	str	q7, [sp, #3312]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_473
LBB0_467:                               ; %cond.load2484
	mov.d	x9, v1[1]
	mov.16b	v7, v17
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #3312]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_474
	b	LBB0_475
LBB0_468:                               ; %cond.load2447
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #1152]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_461
LBB0_469:                               ; %cond.load2453
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	tbnz	w8, #7, LBB0_462
	b	LBB0_463
LBB0_470:                               ; %cond.load2466
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3328]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_465
LBB0_471:                               ; %cond.load2472
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	ldr	q1, [sp, #3328]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_466
LBB0_472:                               ; %cond.load2478
	fmov	x9, d1
	ld1.s	{ v17 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #3312]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_467
LBB0_473:
	mov.16b	v7, v17
	ldr	q1, [sp, #3312]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_475
LBB0_474:                               ; %cond.load2490
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
LBB0_475:                               ; %else2494
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_484
; %bb.476:                              ; %else2500
	str	q0, [sp, #1120]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_485
LBB0_477:                               ; %else2506
	tbz	w8, #7, LBB0_479
LBB0_478:                               ; %cond.load2508
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_479:                               ; %else2512
	str	q18, [sp, #12944]               ; 16-byte Spill
	str	q7, [sp, #12896]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #120                       ; =0x78
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #1104]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_486
; %bb.480:                              ; %else2519
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3296]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_487
LBB0_481:                               ; %else2525
	ldr	q1, [sp, #3296]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_488
LBB0_482:                               ; %else2531
	orr.16b	v7, v4, v0
	str	q7, [sp, #3280]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_489
LBB0_483:                               ; %cond.load2533
	mov.d	x9, v1[1]
	mov.16b	v7, v17
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #3280]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_490
	b	LBB0_491
LBB0_484:                               ; %cond.load2496
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #1120]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_477
LBB0_485:                               ; %cond.load2502
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	tbnz	w8, #7, LBB0_478
	b	LBB0_479
LBB0_486:                               ; %cond.load2515
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3296]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_481
LBB0_487:                               ; %cond.load2521
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	ldr	q1, [sp, #3296]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_482
LBB0_488:                               ; %cond.load2527
	fmov	x9, d1
	ld1.s	{ v17 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #3280]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_483
LBB0_489:
	mov.16b	v7, v17
	ldr	q1, [sp, #3280]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_491
LBB0_490:                               ; %cond.load2539
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
LBB0_491:                               ; %else2543
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_500
; %bb.492:                              ; %else2549
	str	q0, [sp, #1088]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_501
LBB0_493:                               ; %else2555
	tbz	w8, #7, LBB0_495
LBB0_494:                               ; %cond.load2557
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_495:                               ; %else2561
	str	q18, [sp, #13792]               ; 16-byte Spill
	str	q7, [sp, #12880]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #124                       ; =0x7c
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #1072]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_502
; %bb.496:                              ; %else2568
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3264]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_503
LBB0_497:                               ; %else2574
	ldr	q1, [sp, #3264]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_504
LBB0_498:                               ; %else2580
	orr.16b	v7, v4, v0
	str	q7, [sp, #3248]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_505
LBB0_499:                               ; %cond.load2582
	mov.d	x9, v1[1]
	mov.16b	v7, v17
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #3248]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_506
	b	LBB0_507
LBB0_500:                               ; %cond.load2545
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #1088]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_493
LBB0_501:                               ; %cond.load2551
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	tbnz	w8, #7, LBB0_494
	b	LBB0_495
LBB0_502:                               ; %cond.load2564
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3264]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_497
LBB0_503:                               ; %cond.load2570
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	ldr	q1, [sp, #3264]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_498
LBB0_504:                               ; %cond.load2576
	fmov	x9, d1
	ld1.s	{ v17 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #3248]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_499
LBB0_505:
	mov.16b	v7, v17
	ldr	q1, [sp, #3248]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_507
LBB0_506:                               ; %cond.load2588
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
LBB0_507:                               ; %else2592
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_516
; %bb.508:                              ; %else2598
	str	q0, [sp, #1056]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_517
LBB0_509:                               ; %else2604
	tbz	w8, #7, LBB0_511
LBB0_510:                               ; %cond.load2606
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_511:                               ; %else2610
	str	q18, [sp, #13760]               ; 16-byte Spill
	str	q7, [sp, #13776]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #128                       ; =0x80
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #1040]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_518
; %bb.512:                              ; %else2617
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3232]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_519
LBB0_513:                               ; %else2623
	ldr	q1, [sp, #3232]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_520
LBB0_514:                               ; %else2629
	orr.16b	v7, v4, v0
	str	q7, [sp, #3216]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_521
LBB0_515:                               ; %cond.load2631
	mov.d	x9, v1[1]
	mov.16b	v7, v17
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #3216]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_522
	b	LBB0_523
LBB0_516:                               ; %cond.load2594
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #1056]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_509
LBB0_517:                               ; %cond.load2600
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	tbnz	w8, #7, LBB0_510
	b	LBB0_511
LBB0_518:                               ; %cond.load2613
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3232]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_513
LBB0_519:                               ; %cond.load2619
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	ldr	q1, [sp, #3232]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_514
LBB0_520:                               ; %cond.load2625
	fmov	x9, d1
	ld1.s	{ v17 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #3216]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_515
LBB0_521:
	mov.16b	v7, v17
	ldr	q1, [sp, #3216]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_523
LBB0_522:                               ; %cond.load2637
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
LBB0_523:                               ; %else2641
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_532
; %bb.524:                              ; %else2647
	str	q0, [sp, #1024]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_533
LBB0_525:                               ; %else2653
	tbz	w8, #7, LBB0_527
LBB0_526:                               ; %cond.load2655
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_527:                               ; %else2659
	str	q18, [sp, #12864]               ; 16-byte Spill
	str	q7, [sp, #12560]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #132                       ; =0x84
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #1008]                 ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_534
; %bb.528:                              ; %else2666
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3200]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_535
LBB0_529:                               ; %else2672
	ldr	q1, [sp, #3200]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_536
LBB0_530:                               ; %else2678
	orr.16b	v7, v4, v0
	str	q7, [sp, #3184]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_537
LBB0_531:                               ; %cond.load2680
	mov.d	x9, v1[1]
	mov.16b	v7, v17
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #3184]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_538
	b	LBB0_539
LBB0_532:                               ; %cond.load2643
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #1024]                 ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_525
LBB0_533:                               ; %cond.load2649
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	tbnz	w8, #7, LBB0_526
	b	LBB0_527
LBB0_534:                               ; %cond.load2662
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3200]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_529
LBB0_535:                               ; %cond.load2668
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	ldr	q1, [sp, #3200]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_530
LBB0_536:                               ; %cond.load2674
	fmov	x9, d1
	ld1.s	{ v17 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #3184]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_531
LBB0_537:
	mov.16b	v7, v17
	ldr	q1, [sp, #3184]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_539
LBB0_538:                               ; %cond.load2686
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
LBB0_539:                               ; %else2690
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_548
; %bb.540:                              ; %else2696
	str	q0, [sp, #992]                  ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_549
LBB0_541:                               ; %else2702
	tbz	w8, #7, LBB0_543
LBB0_542:                               ; %cond.load2704
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_543:                               ; %else2708
	str	q18, [sp, #13728]               ; 16-byte Spill
	str	q7, [sp, #13744]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #136                       ; =0x88
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #976]                  ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_550
; %bb.544:                              ; %else2715
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3168]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_551
LBB0_545:                               ; %else2721
	ldr	q1, [sp, #3168]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_552
LBB0_546:                               ; %else2727
	orr.16b	v7, v4, v0
	str	q7, [sp, #3152]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_553
LBB0_547:                               ; %cond.load2729
	mov.d	x9, v1[1]
	mov.16b	v7, v17
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #3152]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_554
	b	LBB0_555
LBB0_548:                               ; %cond.load2692
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #992]                  ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_541
LBB0_549:                               ; %cond.load2698
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	tbnz	w8, #7, LBB0_542
	b	LBB0_543
LBB0_550:                               ; %cond.load2711
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3168]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_545
LBB0_551:                               ; %cond.load2717
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	ldr	q1, [sp, #3168]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_546
LBB0_552:                               ; %cond.load2723
	fmov	x9, d1
	ld1.s	{ v17 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #3152]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_547
LBB0_553:
	mov.16b	v7, v17
	ldr	q1, [sp, #3152]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_555
LBB0_554:                               ; %cond.load2735
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
LBB0_555:                               ; %else2739
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_564
; %bb.556:                              ; %else2745
	str	q0, [sp, #960]                  ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_565
LBB0_557:                               ; %else2751
	tbz	w8, #7, LBB0_559
LBB0_558:                               ; %cond.load2753
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_559:                               ; %else2757
	str	q18, [sp, #12768]               ; 16-byte Spill
	str	q7, [sp, #12848]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #140                       ; =0x8c
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #944]                  ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_566
; %bb.560:                              ; %else2764
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3136]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_567
LBB0_561:                               ; %else2770
	ldr	q1, [sp, #3136]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_568
LBB0_562:                               ; %else2776
	orr.16b	v7, v4, v0
	str	q7, [sp, #3120]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_569
LBB0_563:                               ; %cond.load2778
	mov.d	x9, v1[1]
	mov.16b	v7, v17
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #3120]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_570
	b	LBB0_571
LBB0_564:                               ; %cond.load2741
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #960]                  ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_557
LBB0_565:                               ; %cond.load2747
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	tbnz	w8, #7, LBB0_558
	b	LBB0_559
LBB0_566:                               ; %cond.load2760
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3136]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_561
LBB0_567:                               ; %cond.load2766
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	ldr	q1, [sp, #3136]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_562
LBB0_568:                               ; %cond.load2772
	fmov	x9, d1
	ld1.s	{ v17 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #3120]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_563
LBB0_569:
	mov.16b	v7, v17
	ldr	q1, [sp, #3120]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_571
LBB0_570:                               ; %cond.load2784
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
LBB0_571:                               ; %else2788
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_580
; %bb.572:                              ; %else2794
	str	q0, [sp, #928]                  ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_581
LBB0_573:                               ; %else2800
	tbz	w8, #7, LBB0_575
LBB0_574:                               ; %cond.load2802
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_575:                               ; %else2806
	str	q18, [sp, #12752]               ; 16-byte Spill
	str	q7, [sp, #12832]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #144                       ; =0x90
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #912]                  ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_582
; %bb.576:                              ; %else2813
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3104]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_583
LBB0_577:                               ; %else2819
	ldr	q1, [sp, #3104]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_584
LBB0_578:                               ; %else2825
	orr.16b	v7, v4, v0
	str	q7, [sp, #3088]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_585
LBB0_579:                               ; %cond.load2827
	mov.d	x9, v1[1]
	mov.16b	v7, v17
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #3088]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_586
	b	LBB0_587
LBB0_580:                               ; %cond.load2790
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #928]                  ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_573
LBB0_581:                               ; %cond.load2796
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	tbnz	w8, #7, LBB0_574
	b	LBB0_575
LBB0_582:                               ; %cond.load2809
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3104]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_577
LBB0_583:                               ; %cond.load2815
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	ldr	q1, [sp, #3104]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_578
LBB0_584:                               ; %cond.load2821
	fmov	x9, d1
	ld1.s	{ v17 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #3088]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_579
LBB0_585:
	mov.16b	v7, v17
	ldr	q1, [sp, #3088]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_587
LBB0_586:                               ; %cond.load2833
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
LBB0_587:                               ; %else2837
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_596
; %bb.588:                              ; %else2843
	str	q0, [sp, #896]                  ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_597
LBB0_589:                               ; %else2849
	tbz	w8, #7, LBB0_591
LBB0_590:                               ; %cond.load2851
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_591:                               ; %else2855
	str	q18, [sp, #12736]               ; 16-byte Spill
	str	q7, [sp, #12544]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #148                       ; =0x94
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #880]                  ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_598
; %bb.592:                              ; %else2862
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3072]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_599
LBB0_593:                               ; %else2868
	ldr	q1, [sp, #3072]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_600
LBB0_594:                               ; %else2874
	orr.16b	v7, v4, v0
	str	q7, [sp, #3056]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_601
LBB0_595:                               ; %cond.load2876
	mov.d	x9, v1[1]
	mov.16b	v7, v17
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #3056]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_602
	b	LBB0_603
LBB0_596:                               ; %cond.load2839
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #896]                  ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_589
LBB0_597:                               ; %cond.load2845
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	tbnz	w8, #7, LBB0_590
	b	LBB0_591
LBB0_598:                               ; %cond.load2858
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3072]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_593
LBB0_599:                               ; %cond.load2864
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	ldr	q1, [sp, #3072]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_594
LBB0_600:                               ; %cond.load2870
	fmov	x9, d1
	ld1.s	{ v17 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #3056]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_595
LBB0_601:
	mov.16b	v7, v17
	ldr	q1, [sp, #3056]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_603
LBB0_602:                               ; %cond.load2882
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
LBB0_603:                               ; %else2886
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_612
; %bb.604:                              ; %else2892
	str	q0, [sp, #864]                  ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_613
LBB0_605:                               ; %else2898
	tbz	w8, #7, LBB0_607
LBB0_606:                               ; %cond.load2900
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_607:                               ; %else2904
	str	q18, [sp, #12720]               ; 16-byte Spill
	str	q7, [sp, #12528]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #152                       ; =0x98
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #848]                  ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_614
; %bb.608:                              ; %else2911
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3040]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_615
LBB0_609:                               ; %else2917
	ldr	q1, [sp, #3040]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_616
LBB0_610:                               ; %else2923
	orr.16b	v7, v4, v0
	str	q7, [sp, #3024]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_617
LBB0_611:                               ; %cond.load2925
	mov.d	x9, v1[1]
	mov.16b	v7, v17
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #3024]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_618
	b	LBB0_619
LBB0_612:                               ; %cond.load2888
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #864]                  ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_605
LBB0_613:                               ; %cond.load2894
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	tbnz	w8, #7, LBB0_606
	b	LBB0_607
LBB0_614:                               ; %cond.load2907
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3040]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_609
LBB0_615:                               ; %cond.load2913
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	ldr	q1, [sp, #3040]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_610
LBB0_616:                               ; %cond.load2919
	fmov	x9, d1
	ld1.s	{ v17 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #3024]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_611
LBB0_617:
	mov.16b	v7, v17
	ldr	q1, [sp, #3024]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_619
LBB0_618:                               ; %cond.load2931
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
LBB0_619:                               ; %else2935
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_628
; %bb.620:                              ; %else2941
	str	q0, [sp, #832]                  ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_629
LBB0_621:                               ; %else2947
	tbz	w8, #7, LBB0_623
LBB0_622:                               ; %cond.load2949
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_623:                               ; %else2953
	str	q18, [sp, #12704]               ; 16-byte Spill
	str	q7, [sp, #12512]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #156                       ; =0x9c
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #816]                  ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_630
; %bb.624:                              ; %else2960
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3008]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_631
LBB0_625:                               ; %else2966
	ldr	q1, [sp, #3008]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_632
LBB0_626:                               ; %else2972
	orr.16b	v7, v4, v0
	str	q7, [sp, #2992]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_633
LBB0_627:                               ; %cond.load2974
	mov.d	x9, v1[1]
	mov.16b	v7, v17
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #2992]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_634
	b	LBB0_635
LBB0_628:                               ; %cond.load2937
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #832]                  ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_621
LBB0_629:                               ; %cond.load2943
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	tbnz	w8, #7, LBB0_622
	b	LBB0_623
LBB0_630:                               ; %cond.load2956
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #3008]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_625
LBB0_631:                               ; %cond.load2962
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	ldr	q1, [sp, #3008]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_626
LBB0_632:                               ; %cond.load2968
	fmov	x9, d1
	ld1.s	{ v17 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #2992]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_627
LBB0_633:
	mov.16b	v7, v17
	ldr	q1, [sp, #2992]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_635
LBB0_634:                               ; %cond.load2980
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
LBB0_635:                               ; %else2984
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_644
; %bb.636:                              ; %else2990
	str	q0, [sp, #800]                  ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_645
LBB0_637:                               ; %else2996
	tbz	w8, #7, LBB0_639
LBB0_638:                               ; %cond.load2998
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_639:                               ; %else3002
	str	q18, [sp, #12688]               ; 16-byte Spill
	str	q7, [sp, #12496]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #160                       ; =0xa0
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #784]                  ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_646
; %bb.640:                              ; %else3009
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2976]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_647
LBB0_641:                               ; %else3015
	ldr	q1, [sp, #2976]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_648
LBB0_642:                               ; %else3021
	orr.16b	v7, v4, v0
	str	q7, [sp, #2960]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_649
LBB0_643:                               ; %cond.load3023
	mov.d	x9, v1[1]
	mov.16b	v7, v17
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #2960]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_650
	b	LBB0_651
LBB0_644:                               ; %cond.load2986
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #800]                  ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_637
LBB0_645:                               ; %cond.load2992
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	tbnz	w8, #7, LBB0_638
	b	LBB0_639
LBB0_646:                               ; %cond.load3005
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2976]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_641
LBB0_647:                               ; %cond.load3011
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	ldr	q1, [sp, #2976]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_642
LBB0_648:                               ; %cond.load3017
	fmov	x9, d1
	ld1.s	{ v17 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #2960]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_643
LBB0_649:
	mov.16b	v7, v17
	ldr	q1, [sp, #2960]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_651
LBB0_650:                               ; %cond.load3029
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
LBB0_651:                               ; %else3033
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_660
; %bb.652:                              ; %else3039
	str	q0, [sp, #768]                  ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_661
LBB0_653:                               ; %else3045
	tbz	w8, #7, LBB0_655
LBB0_654:                               ; %cond.load3047
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_655:                               ; %else3051
	str	q18, [sp, #13712]               ; 16-byte Spill
	str	q7, [sp, #12480]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #164                       ; =0xa4
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #752]                  ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_662
; %bb.656:                              ; %else3058
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2944]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_663
LBB0_657:                               ; %else3064
	ldr	q1, [sp, #2944]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_664
LBB0_658:                               ; %else3070
	orr.16b	v7, v4, v0
	str	q7, [sp, #2928]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_665
LBB0_659:                               ; %cond.load3072
	mov.d	x9, v1[1]
	mov.16b	v7, v17
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #2928]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_666
	b	LBB0_667
LBB0_660:                               ; %cond.load3035
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #768]                  ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_653
LBB0_661:                               ; %cond.load3041
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	tbnz	w8, #7, LBB0_654
	b	LBB0_655
LBB0_662:                               ; %cond.load3054
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v17, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2944]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_657
LBB0_663:                               ; %cond.load3060
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	ldr	q1, [sp, #2944]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_658
LBB0_664:                               ; %cond.load3066
	fmov	x9, d1
	ld1.s	{ v17 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #2928]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_659
LBB0_665:
	mov.16b	v7, v17
	ldr	q1, [sp, #2928]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_667
LBB0_666:                               ; %cond.load3078
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
LBB0_667:                               ; %else3082
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_694
; %bb.668:                              ; %else3088
	str	q0, [sp, #736]                  ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_695
LBB0_669:                               ; %else3094
	tbz	w8, #7, LBB0_671
LBB0_670:                               ; %cond.load3096
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_671:                               ; %else3100
	str	q18, [sp, #13680]               ; 16-byte Spill
	str	q7, [sp, #13696]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #168                       ; =0xa8
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #720]                  ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbnz	w9, #0, LBB0_696
; %bb.672:                              ; %else3107
	orr.16b	v7, v3, v0
	str	q7, [sp, #2912]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_697
LBB0_673:                               ; %else3113
	ldr	q1, [sp, #2912]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_698
LBB0_674:                               ; %else3119
	orr.16b	v7, v4, v0
	str	q7, [sp, #2896]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_699
LBB0_675:                               ; %else3125
	ldr	q1, [sp, #2896]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_700
LBB0_676:                               ; %else3131
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_701
LBB0_677:                               ; %else3137
	str	q0, [sp, #704]                  ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_702
LBB0_678:                               ; %else3143
	str	q16, [sp, #13664]               ; 16-byte Spill
	str	q25, [sp, #1344]                ; 16-byte Spill
	str	q24, [sp, #1392]                ; 16-byte Spill
	mov.16b	v16, v30
	tbz	w8, #7, LBB0_680
LBB0_679:                               ; %cond.load3145
	mov.d	x8, v0[1]
	ld1.s	{ v17 }[3], [x8]
LBB0_680:                               ; %else3149
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #172                       ; =0xac
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #688]                  ; 16-byte Spill
	add.2d	v1, v9, v1
	movi.2d	v25, #0000000000000000
	movi.2d	v30, #0000000000000000
	tbnz	w9, #0, LBB0_703
; %bb.681:                              ; %else3156
	orr.16b	v7, v3, v0
	str	q7, [sp, #2880]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_704
LBB0_682:                               ; %else3162
	ldr	q1, [sp, #2880]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #2, LBB0_705
LBB0_683:                               ; %else3168
	orr.16b	v7, v4, v0
	str	q7, [sp, #2864]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_706
LBB0_684:                               ; %else3174
	mov.16b	v7, v30
	ldr	q1, [sp, #2864]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbnz	w8, #4, LBB0_707
LBB0_685:                               ; %else3180
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_708
LBB0_686:                               ; %else3186
	str	q0, [sp, #672]                  ; 16-byte Spill
	add.2d	v0, v9, v0
	tbnz	w8, #6, LBB0_709
LBB0_687:                               ; %else3192
	tbz	w8, #7, LBB0_689
LBB0_688:                               ; %cond.load3194
	mov.d	x8, v0[1]
	ld1.s	{ v7 }[3], [x8]
LBB0_689:                               ; %else3198
	str	q7, [sp, #13616]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #176                       ; =0xb0
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #656]                  ; 16-byte Spill
	mov.16b	v22, v9
	add.2d	v1, v9, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v9, #0000000000000000
	tbnz	w9, #0, LBB0_710
; %bb.690:                              ; %else3205
	mov.16b	v30, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2848]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_711
LBB0_691:                               ; %else3211
	ldr	q1, [sp, #2848]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbnz	w8, #2, LBB0_712
LBB0_692:                               ; %else3217
	orr.16b	v7, v4, v0
	str	q7, [sp, #2832]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_713
LBB0_693:                               ; %cond.load3219
	mov.d	x9, v1[1]
	mov.16b	v7, v30
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #2832]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbnz	w8, #4, LBB0_714
	b	LBB0_715
LBB0_694:                               ; %cond.load3084
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #736]                  ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_669
LBB0_695:                               ; %cond.load3090
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	tbnz	w8, #7, LBB0_670
	b	LBB0_671
LBB0_696:                               ; %cond.load3103
	fmov	x9, d1
	ldr	s16, [x9]
	orr.16b	v7, v3, v0
	str	q7, [sp, #2912]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_673
LBB0_697:                               ; %cond.load3109
	mov.d	x9, v1[1]
	ld1.s	{ v16 }[1], [x9]
	ldr	q1, [sp, #2912]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_674
LBB0_698:                               ; %cond.load3115
	fmov	x9, d1
	ld1.s	{ v16 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #2896]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_675
LBB0_699:                               ; %cond.load3121
	mov.d	x9, v1[1]
	ld1.s	{ v16 }[3], [x9]
	ldr	q1, [sp, #2896]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_676
LBB0_700:                               ; %cond.load3127
	fmov	x9, d1
	ld1.s	{ v17 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_677
LBB0_701:                               ; %cond.load3133
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	str	q0, [sp, #704]                  ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_678
LBB0_702:                               ; %cond.load3139
	fmov	x9, d0
	ld1.s	{ v17 }[2], [x9]
	str	q16, [sp, #13664]               ; 16-byte Spill
	str	q25, [sp, #1344]                ; 16-byte Spill
	str	q24, [sp, #1392]                ; 16-byte Spill
	mov.16b	v16, v30
	tbnz	w8, #7, LBB0_679
	b	LBB0_680
LBB0_703:                               ; %cond.load3152
	fmov	x9, d1
	ldr	s25, [x9]
	orr.16b	v7, v3, v0
	str	q7, [sp, #2880]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_682
LBB0_704:                               ; %cond.load3158
	mov.d	x9, v1[1]
	ld1.s	{ v25 }[1], [x9]
	ldr	q1, [sp, #2880]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #2, LBB0_683
LBB0_705:                               ; %cond.load3164
	fmov	x9, d1
	ld1.s	{ v25 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #2864]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_684
LBB0_706:                               ; %cond.load3170
	mov.d	x9, v1[1]
	ld1.s	{ v25 }[3], [x9]
	mov.16b	v7, v30
	ldr	q1, [sp, #2864]                 ; 16-byte Reload
	add.2d	v1, v9, v1
	tbz	w8, #4, LBB0_685
LBB0_707:                               ; %cond.load3176
	fmov	x9, d1
	ld1.s	{ v7 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_686
LBB0_708:                               ; %cond.load3182
	mov.d	x9, v1[1]
	ld1.s	{ v7 }[1], [x9]
	str	q0, [sp, #672]                  ; 16-byte Spill
	add.2d	v0, v9, v0
	tbz	w8, #6, LBB0_687
LBB0_709:                               ; %cond.load3188
	fmov	x9, d0
	ld1.s	{ v7 }[2], [x9]
	tbnz	w8, #7, LBB0_688
	b	LBB0_689
LBB0_710:                               ; %cond.load3201
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v30, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2848]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_691
LBB0_711:                               ; %cond.load3207
	mov.d	x9, v1[1]
	ld1.s	{ v30 }[1], [x9]
	ldr	q1, [sp, #2848]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbz	w8, #2, LBB0_692
LBB0_712:                               ; %cond.load3213
	fmov	x9, d1
	ld1.s	{ v30 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #2832]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_693
LBB0_713:
	mov.16b	v7, v30
	ldr	q1, [sp, #2832]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbz	w8, #4, LBB0_715
LBB0_714:                               ; %cond.load3225
	fmov	x9, d1
	ld1.s	{ v9 }[0], [x9]
LBB0_715:                               ; %else3229
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_724
; %bb.716:                              ; %else3235
	str	q0, [sp, #640]                  ; 16-byte Spill
	add.2d	v0, v22, v0
	tbnz	w8, #6, LBB0_725
LBB0_717:                               ; %else3241
	tbz	w8, #7, LBB0_719
LBB0_718:                               ; %cond.load3243
	mov.d	x8, v0[1]
	ld1.s	{ v9 }[3], [x8]
LBB0_719:                               ; %else3247
	str	q9, [sp, #13584]                ; 16-byte Spill
	str	q7, [sp, #13600]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #180                       ; =0xb4
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #624]                  ; 16-byte Spill
	add.2d	v1, v22, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v9, #0000000000000000
	tbnz	w9, #0, LBB0_726
; %bb.720:                              ; %else3254
	mov.16b	v30, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2816]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_727
LBB0_721:                               ; %else3260
	ldr	q1, [sp, #2816]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbnz	w8, #2, LBB0_728
LBB0_722:                               ; %else3266
	orr.16b	v7, v4, v0
	str	q7, [sp, #2800]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_729
LBB0_723:                               ; %cond.load3268
	mov.d	x9, v1[1]
	mov.16b	v7, v30
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #2800]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbnz	w8, #4, LBB0_730
	b	LBB0_731
LBB0_724:                               ; %cond.load3231
	mov.d	x9, v1[1]
	ld1.s	{ v9 }[1], [x9]
	str	q0, [sp, #640]                  ; 16-byte Spill
	add.2d	v0, v22, v0
	tbz	w8, #6, LBB0_717
LBB0_725:                               ; %cond.load3237
	fmov	x9, d0
	ld1.s	{ v9 }[2], [x9]
	tbnz	w8, #7, LBB0_718
	b	LBB0_719
LBB0_726:                               ; %cond.load3250
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v30, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2816]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_721
LBB0_727:                               ; %cond.load3256
	mov.d	x9, v1[1]
	ld1.s	{ v30 }[1], [x9]
	ldr	q1, [sp, #2816]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbz	w8, #2, LBB0_722
LBB0_728:                               ; %cond.load3262
	fmov	x9, d1
	ld1.s	{ v30 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #2800]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_723
LBB0_729:
	mov.16b	v7, v30
	ldr	q1, [sp, #2800]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbz	w8, #4, LBB0_731
LBB0_730:                               ; %cond.load3274
	fmov	x9, d1
	ld1.s	{ v9 }[0], [x9]
LBB0_731:                               ; %else3278
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_740
; %bb.732:                              ; %else3284
	str	q0, [sp, #608]                  ; 16-byte Spill
	add.2d	v0, v22, v0
	tbnz	w8, #6, LBB0_741
LBB0_733:                               ; %else3290
	tbz	w8, #7, LBB0_735
LBB0_734:                               ; %cond.load3292
	mov.d	x8, v0[1]
	ld1.s	{ v9 }[3], [x8]
LBB0_735:                               ; %else3296
	str	q9, [sp, #13552]                ; 16-byte Spill
	str	q7, [sp, #13568]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #184                       ; =0xb8
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #592]                  ; 16-byte Spill
	add.2d	v1, v22, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v9, #0000000000000000
	tbnz	w9, #0, LBB0_742
; %bb.736:                              ; %else3303
	mov.16b	v30, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2784]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_743
LBB0_737:                               ; %else3309
	ldr	q1, [sp, #2784]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbnz	w8, #2, LBB0_744
LBB0_738:                               ; %else3315
	orr.16b	v7, v4, v0
	str	q7, [sp, #2768]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_745
LBB0_739:                               ; %cond.load3317
	mov.d	x9, v1[1]
	mov.16b	v7, v30
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #2768]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbnz	w8, #4, LBB0_746
	b	LBB0_747
LBB0_740:                               ; %cond.load3280
	mov.d	x9, v1[1]
	ld1.s	{ v9 }[1], [x9]
	str	q0, [sp, #608]                  ; 16-byte Spill
	add.2d	v0, v22, v0
	tbz	w8, #6, LBB0_733
LBB0_741:                               ; %cond.load3286
	fmov	x9, d0
	ld1.s	{ v9 }[2], [x9]
	tbnz	w8, #7, LBB0_734
	b	LBB0_735
LBB0_742:                               ; %cond.load3299
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v30, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2784]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_737
LBB0_743:                               ; %cond.load3305
	mov.d	x9, v1[1]
	ld1.s	{ v30 }[1], [x9]
	ldr	q1, [sp, #2784]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbz	w8, #2, LBB0_738
LBB0_744:                               ; %cond.load3311
	fmov	x9, d1
	ld1.s	{ v30 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #2768]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_739
LBB0_745:
	mov.16b	v7, v30
	ldr	q1, [sp, #2768]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbz	w8, #4, LBB0_747
LBB0_746:                               ; %cond.load3323
	fmov	x9, d1
	ld1.s	{ v9 }[0], [x9]
LBB0_747:                               ; %else3327
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_756
; %bb.748:                              ; %else3333
	str	q0, [sp, #576]                  ; 16-byte Spill
	add.2d	v0, v22, v0
	tbnz	w8, #6, LBB0_757
LBB0_749:                               ; %else3339
	tbz	w8, #7, LBB0_751
LBB0_750:                               ; %cond.load3341
	mov.d	x8, v0[1]
	ld1.s	{ v9 }[3], [x8]
LBB0_751:                               ; %else3345
	str	q9, [sp, #13520]                ; 16-byte Spill
	str	q7, [sp, #13536]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #188                       ; =0xbc
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #560]                  ; 16-byte Spill
	add.2d	v1, v22, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v9, #0000000000000000
	tbnz	w9, #0, LBB0_758
; %bb.752:                              ; %else3352
	mov.16b	v30, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2752]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_759
LBB0_753:                               ; %else3358
	ldr	q1, [sp, #2752]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbnz	w8, #2, LBB0_760
LBB0_754:                               ; %else3364
	orr.16b	v7, v4, v0
	str	q7, [sp, #2736]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_761
LBB0_755:                               ; %cond.load3366
	mov.d	x9, v1[1]
	mov.16b	v7, v30
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #2736]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbnz	w8, #4, LBB0_762
	b	LBB0_763
LBB0_756:                               ; %cond.load3329
	mov.d	x9, v1[1]
	ld1.s	{ v9 }[1], [x9]
	str	q0, [sp, #576]                  ; 16-byte Spill
	add.2d	v0, v22, v0
	tbz	w8, #6, LBB0_749
LBB0_757:                               ; %cond.load3335
	fmov	x9, d0
	ld1.s	{ v9 }[2], [x9]
	tbnz	w8, #7, LBB0_750
	b	LBB0_751
LBB0_758:                               ; %cond.load3348
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v30, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2752]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_753
LBB0_759:                               ; %cond.load3354
	mov.d	x9, v1[1]
	ld1.s	{ v30 }[1], [x9]
	ldr	q1, [sp, #2752]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbz	w8, #2, LBB0_754
LBB0_760:                               ; %cond.load3360
	fmov	x9, d1
	ld1.s	{ v30 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #2736]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_755
LBB0_761:
	mov.16b	v7, v30
	ldr	q1, [sp, #2736]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbz	w8, #4, LBB0_763
LBB0_762:                               ; %cond.load3372
	fmov	x9, d1
	ld1.s	{ v9 }[0], [x9]
LBB0_763:                               ; %else3376
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_772
; %bb.764:                              ; %else3382
	str	q0, [sp, #544]                  ; 16-byte Spill
	add.2d	v0, v22, v0
	tbnz	w8, #6, LBB0_773
LBB0_765:                               ; %else3388
	tbz	w8, #7, LBB0_767
LBB0_766:                               ; %cond.load3390
	mov.d	x8, v0[1]
	ld1.s	{ v9 }[3], [x8]
LBB0_767:                               ; %else3394
	str	q9, [sp, #13488]                ; 16-byte Spill
	str	q7, [sp, #13504]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #192                       ; =0xc0
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #528]                  ; 16-byte Spill
	add.2d	v1, v22, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v9, #0000000000000000
	tbnz	w9, #0, LBB0_774
; %bb.768:                              ; %else3401
	mov.16b	v30, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2720]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_775
LBB0_769:                               ; %else3407
	ldr	q1, [sp, #2720]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbnz	w8, #2, LBB0_776
LBB0_770:                               ; %else3413
	orr.16b	v7, v4, v0
	str	q7, [sp, #2704]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_777
LBB0_771:                               ; %cond.load3415
	mov.d	x9, v1[1]
	mov.16b	v7, v30
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #2704]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbnz	w8, #4, LBB0_778
	b	LBB0_779
LBB0_772:                               ; %cond.load3378
	mov.d	x9, v1[1]
	ld1.s	{ v9 }[1], [x9]
	str	q0, [sp, #544]                  ; 16-byte Spill
	add.2d	v0, v22, v0
	tbz	w8, #6, LBB0_765
LBB0_773:                               ; %cond.load3384
	fmov	x9, d0
	ld1.s	{ v9 }[2], [x9]
	tbnz	w8, #7, LBB0_766
	b	LBB0_767
LBB0_774:                               ; %cond.load3397
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v30, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2720]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_769
LBB0_775:                               ; %cond.load3403
	mov.d	x9, v1[1]
	ld1.s	{ v30 }[1], [x9]
	ldr	q1, [sp, #2720]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbz	w8, #2, LBB0_770
LBB0_776:                               ; %cond.load3409
	fmov	x9, d1
	ld1.s	{ v30 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #2704]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_771
LBB0_777:
	mov.16b	v7, v30
	ldr	q1, [sp, #2704]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbz	w8, #4, LBB0_779
LBB0_778:                               ; %cond.load3421
	fmov	x9, d1
	ld1.s	{ v9 }[0], [x9]
LBB0_779:                               ; %else3425
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_788
; %bb.780:                              ; %else3431
	str	q0, [sp, #512]                  ; 16-byte Spill
	add.2d	v0, v22, v0
	tbnz	w8, #6, LBB0_789
LBB0_781:                               ; %else3437
	tbz	w8, #7, LBB0_783
LBB0_782:                               ; %cond.load3439
	mov.d	x8, v0[1]
	ld1.s	{ v9 }[3], [x8]
LBB0_783:                               ; %else3443
	str	q9, [sp, #13456]                ; 16-byte Spill
	str	q7, [sp, #13472]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #196                       ; =0xc4
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #496]                  ; 16-byte Spill
	add.2d	v1, v22, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v9, #0000000000000000
	tbnz	w9, #0, LBB0_790
; %bb.784:                              ; %else3450
	mov.16b	v30, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2688]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_791
LBB0_785:                               ; %else3456
	ldr	q1, [sp, #2688]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbnz	w8, #2, LBB0_792
LBB0_786:                               ; %else3462
	orr.16b	v7, v4, v0
	str	q7, [sp, #2672]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_793
LBB0_787:                               ; %cond.load3464
	mov.d	x9, v1[1]
	mov.16b	v7, v30
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #2672]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	str	q16, [sp, #12384]               ; 16-byte Spill
	tbnz	w8, #4, LBB0_794
	b	LBB0_795
LBB0_788:                               ; %cond.load3427
	mov.d	x9, v1[1]
	ld1.s	{ v9 }[1], [x9]
	str	q0, [sp, #512]                  ; 16-byte Spill
	add.2d	v0, v22, v0
	tbz	w8, #6, LBB0_781
LBB0_789:                               ; %cond.load3433
	fmov	x9, d0
	ld1.s	{ v9 }[2], [x9]
	tbnz	w8, #7, LBB0_782
	b	LBB0_783
LBB0_790:                               ; %cond.load3446
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v30, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2688]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_785
LBB0_791:                               ; %cond.load3452
	mov.d	x9, v1[1]
	ld1.s	{ v30 }[1], [x9]
	ldr	q1, [sp, #2688]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbz	w8, #2, LBB0_786
LBB0_792:                               ; %cond.load3458
	fmov	x9, d1
	ld1.s	{ v30 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #2672]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_787
LBB0_793:
	mov.16b	v7, v30
	ldr	q1, [sp, #2672]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	str	q16, [sp, #12384]               ; 16-byte Spill
	tbz	w8, #4, LBB0_795
LBB0_794:                               ; %cond.load3470
	fmov	x9, d1
	ld1.s	{ v9 }[0], [x9]
LBB0_795:                               ; %else3474
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_813
; %bb.796:                              ; %else3480
	str	q0, [sp, #480]                  ; 16-byte Spill
	add.2d	v0, v22, v0
	tbnz	w8, #6, LBB0_814
LBB0_797:                               ; %else3486
	tbz	w8, #7, LBB0_799
LBB0_798:                               ; %cond.load3488
	mov.d	x8, v0[1]
	ld1.s	{ v9 }[3], [x8]
LBB0_799:                               ; %else3492
	str	q9, [sp, #13424]                ; 16-byte Spill
	str	q7, [sp, #13440]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #200                       ; =0xc8
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #464]                  ; 16-byte Spill
	add.2d	v1, v22, v1
	movi.2d	v16, #0000000000000000
	movi.2d	v9, #0000000000000000
	tbnz	w9, #0, LBB0_815
; %bb.800:                              ; %else3499
	orr.16b	v7, v3, v0
	str	q7, [sp, #2656]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_816
LBB0_801:                               ; %else3505
	ldr	q1, [sp, #2656]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbnz	w8, #2, LBB0_817
LBB0_802:                               ; %else3511
	orr.16b	v7, v4, v0
	str	q7, [sp, #2640]                 ; 16-byte Spill
	str	q6, [sp, #1296]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_818
LBB0_803:                               ; %else3517
	mov.16b	v7, v9
	ldr	q1, [sp, #2640]                 ; 16-byte Reload
	mov.16b	v6, v22
	add.2d	v1, v22, v1
	tbnz	w8, #4, LBB0_819
LBB0_804:                               ; %else3523
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_820
LBB0_805:                               ; %else3529
	str	q0, [sp, #448]                  ; 16-byte Spill
	add.2d	v0, v6, v0
	tbnz	w8, #6, LBB0_821
LBB0_806:                               ; %else3535
	tbz	w8, #7, LBB0_808
LBB0_807:                               ; %cond.load3537
	mov.d	x8, v0[1]
	ld1.s	{ v7 }[3], [x8]
LBB0_808:                               ; %else3541
	str	q7, [sp, #13392]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #204                       ; =0xcc
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #432]                  ; 16-byte Spill
	add.2d	v1, v6, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v20, #0000000000000000
	tbnz	w9, #0, LBB0_822
; %bb.809:                              ; %else3548
	mov.16b	v9, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2624]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_823
LBB0_810:                               ; %else3554
	ldr	q1, [sp, #2624]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbnz	w8, #2, LBB0_824
LBB0_811:                               ; %else3560
	orr.16b	v7, v4, v0
	str	q7, [sp, #2608]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_825
LBB0_812:                               ; %cond.load3562
	mov.d	x9, v1[1]
	mov.16b	v7, v9
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #2608]                 ; 16-byte Reload
	mov.16b	v6, v22
	add.2d	v1, v22, v1
	tbnz	w8, #4, LBB0_826
	b	LBB0_827
LBB0_813:                               ; %cond.load3476
	mov.d	x9, v1[1]
	ld1.s	{ v9 }[1], [x9]
	str	q0, [sp, #480]                  ; 16-byte Spill
	add.2d	v0, v22, v0
	tbz	w8, #6, LBB0_797
LBB0_814:                               ; %cond.load3482
	fmov	x9, d0
	ld1.s	{ v9 }[2], [x9]
	tbnz	w8, #7, LBB0_798
	b	LBB0_799
LBB0_815:                               ; %cond.load3495
	fmov	x9, d1
	ldr	s16, [x9]
	orr.16b	v7, v3, v0
	str	q7, [sp, #2656]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_801
LBB0_816:                               ; %cond.load3501
	mov.d	x9, v1[1]
	ld1.s	{ v16 }[1], [x9]
	ldr	q1, [sp, #2656]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbz	w8, #2, LBB0_802
LBB0_817:                               ; %cond.load3507
	fmov	x9, d1
	ld1.s	{ v16 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #2640]                 ; 16-byte Spill
	str	q6, [sp, #1296]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_803
LBB0_818:                               ; %cond.load3513
	mov.d	x9, v1[1]
	ld1.s	{ v16 }[3], [x9]
	mov.16b	v7, v9
	ldr	q1, [sp, #2640]                 ; 16-byte Reload
	mov.16b	v6, v22
	add.2d	v1, v22, v1
	tbz	w8, #4, LBB0_804
LBB0_819:                               ; %cond.load3519
	fmov	x9, d1
	ld1.s	{ v7 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_805
LBB0_820:                               ; %cond.load3525
	mov.d	x9, v1[1]
	ld1.s	{ v7 }[1], [x9]
	str	q0, [sp, #448]                  ; 16-byte Spill
	add.2d	v0, v6, v0
	tbz	w8, #6, LBB0_806
LBB0_821:                               ; %cond.load3531
	fmov	x9, d0
	ld1.s	{ v7 }[2], [x9]
	tbnz	w8, #7, LBB0_807
	b	LBB0_808
LBB0_822:                               ; %cond.load3544
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v9, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2624]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_810
LBB0_823:                               ; %cond.load3550
	mov.d	x9, v1[1]
	ld1.s	{ v9 }[1], [x9]
	ldr	q1, [sp, #2624]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbz	w8, #2, LBB0_811
LBB0_824:                               ; %cond.load3556
	fmov	x9, d1
	ld1.s	{ v9 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #2608]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_812
LBB0_825:
	mov.16b	v7, v9
	ldr	q1, [sp, #2608]                 ; 16-byte Reload
	mov.16b	v6, v22
	add.2d	v1, v22, v1
	tbz	w8, #4, LBB0_827
LBB0_826:                               ; %cond.load3568
	fmov	x9, d1
	ld1.s	{ v20 }[0], [x9]
LBB0_827:                               ; %else3572
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_845
; %bb.828:                              ; %else3578
	str	q0, [sp, #416]                  ; 16-byte Spill
	add.2d	v0, v6, v0
	tbnz	w8, #6, LBB0_846
LBB0_829:                               ; %else3584
	tbz	w8, #7, LBB0_831
LBB0_830:                               ; %cond.load3586
	mov.d	x8, v0[1]
	ld1.s	{ v20 }[3], [x8]
LBB0_831:                               ; %else3590
	str	q20, [sp, #13360]               ; 16-byte Spill
	str	q7, [sp, #13376]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #208                       ; =0xd0
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #400]                  ; 16-byte Spill
	add.2d	v1, v6, v1
	movi.2d	v6, #0000000000000000
	movi.2d	v9, #0000000000000000
	tbnz	w9, #0, LBB0_847
; %bb.832:                              ; %else3597
	orr.16b	v7, v3, v0
	str	q7, [sp, #2592]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_848
LBB0_833:                               ; %else3603
	ldr	q1, [sp, #2592]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbnz	w8, #2, LBB0_849
LBB0_834:                               ; %else3609
	orr.16b	v7, v4, v0
	str	q7, [sp, #2576]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_850
LBB0_835:                               ; %else3615
	str	q6, [sp, #13344]                ; 16-byte Spill
	mov.16b	v7, v9
	ldr	q1, [sp, #2576]                 ; 16-byte Reload
	mov.16b	v6, v22
	add.2d	v1, v22, v1
	tbnz	w8, #4, LBB0_851
LBB0_836:                               ; %else3621
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_852
LBB0_837:                               ; %else3627
	str	q0, [sp, #384]                  ; 16-byte Spill
	add.2d	v0, v6, v0
	tbnz	w8, #6, LBB0_853
LBB0_838:                               ; %else3633
	tbz	w8, #7, LBB0_840
LBB0_839:                               ; %cond.load3635
	mov.d	x8, v0[1]
	ld1.s	{ v7 }[3], [x8]
LBB0_840:                               ; %else3639
	str	q7, [sp, #13328]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #212                       ; =0xd4
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #368]                  ; 16-byte Spill
	add.2d	v1, v6, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbnz	w9, #0, LBB0_854
; %bb.841:                              ; %else3646
	mov.16b	v9, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2560]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_855
LBB0_842:                               ; %else3652
	ldr	q1, [sp, #2560]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbnz	w8, #2, LBB0_856
LBB0_843:                               ; %else3658
	orr.16b	v7, v4, v0
	str	q7, [sp, #2544]                 ; 16-byte Spill
	str	q16, [sp, #13408]               ; 16-byte Spill
	tbz	w8, #3, LBB0_857
LBB0_844:                               ; %cond.load3660
	mov.d	x9, v1[1]
	mov.16b	v7, v9
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #2544]                 ; 16-byte Reload
	mov.16b	v16, v22
	add.2d	v1, v22, v1
	tbnz	w8, #4, LBB0_858
	b	LBB0_859
LBB0_845:                               ; %cond.load3574
	mov.d	x9, v1[1]
	ld1.s	{ v20 }[1], [x9]
	str	q0, [sp, #416]                  ; 16-byte Spill
	add.2d	v0, v6, v0
	tbz	w8, #6, LBB0_829
LBB0_846:                               ; %cond.load3580
	fmov	x9, d0
	ld1.s	{ v20 }[2], [x9]
	tbnz	w8, #7, LBB0_830
	b	LBB0_831
LBB0_847:                               ; %cond.load3593
	fmov	x9, d1
	ldr	s6, [x9]
	orr.16b	v7, v3, v0
	str	q7, [sp, #2592]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_833
LBB0_848:                               ; %cond.load3599
	mov.d	x9, v1[1]
	ld1.s	{ v6 }[1], [x9]
	ldr	q1, [sp, #2592]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbz	w8, #2, LBB0_834
LBB0_849:                               ; %cond.load3605
	fmov	x9, d1
	ld1.s	{ v6 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #2576]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_835
LBB0_850:                               ; %cond.load3611
	mov.d	x9, v1[1]
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #13344]                ; 16-byte Spill
	mov.16b	v7, v9
	ldr	q1, [sp, #2576]                 ; 16-byte Reload
	mov.16b	v6, v22
	add.2d	v1, v22, v1
	tbz	w8, #4, LBB0_836
LBB0_851:                               ; %cond.load3617
	fmov	x9, d1
	ld1.s	{ v7 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_837
LBB0_852:                               ; %cond.load3623
	mov.d	x9, v1[1]
	ld1.s	{ v7 }[1], [x9]
	str	q0, [sp, #384]                  ; 16-byte Spill
	add.2d	v0, v6, v0
	tbz	w8, #6, LBB0_838
LBB0_853:                               ; %cond.load3629
	fmov	x9, d0
	ld1.s	{ v7 }[2], [x9]
	tbnz	w8, #7, LBB0_839
	b	LBB0_840
LBB0_854:                               ; %cond.load3642
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v9, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2560]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_842
LBB0_855:                               ; %cond.load3648
	mov.d	x9, v1[1]
	ld1.s	{ v9 }[1], [x9]
	ldr	q1, [sp, #2560]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbz	w8, #2, LBB0_843
LBB0_856:                               ; %cond.load3654
	fmov	x9, d1
	ld1.s	{ v9 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #2544]                 ; 16-byte Spill
	str	q16, [sp, #13408]               ; 16-byte Spill
	tbnz	w8, #3, LBB0_844
LBB0_857:
	mov.16b	v7, v9
	ldr	q1, [sp, #2544]                 ; 16-byte Reload
	mov.16b	v16, v22
	add.2d	v1, v22, v1
	tbz	w8, #4, LBB0_859
LBB0_858:                               ; %cond.load3666
	fmov	x9, d1
	ld1.s	{ v6 }[0], [x9]
LBB0_859:                               ; %else3670
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_877
; %bb.860:                              ; %else3676
	str	q0, [sp, #352]                  ; 16-byte Spill
	add.2d	v0, v16, v0
	tbnz	w8, #6, LBB0_878
LBB0_861:                               ; %else3682
	tbz	w8, #7, LBB0_863
LBB0_862:                               ; %cond.load3684
	mov.d	x8, v0[1]
	ld1.s	{ v6 }[3], [x8]
LBB0_863:                               ; %else3688
	str	q6, [sp, #13296]                ; 16-byte Spill
	str	q7, [sp, #13312]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #216                       ; =0xd8
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #336]                  ; 16-byte Spill
	add.2d	v1, v16, v1
	movi.2d	v6, #0000000000000000
	movi.2d	v9, #0000000000000000
	tbnz	w9, #0, LBB0_879
; %bb.864:                              ; %else3695
	orr.16b	v7, v3, v0
	str	q7, [sp, #2528]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_880
LBB0_865:                               ; %else3701
	ldr	q1, [sp, #2528]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbnz	w8, #2, LBB0_881
LBB0_866:                               ; %else3707
	orr.16b	v7, v4, v0
	str	q7, [sp, #2512]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_882
LBB0_867:                               ; %else3713
	mov.16b	v7, v9
	ldr	q1, [sp, #2512]                 ; 16-byte Reload
	mov.16b	v16, v22
	add.2d	v1, v22, v1
	tbnz	w8, #4, LBB0_883
LBB0_868:                               ; %else3719
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_884
LBB0_869:                               ; %else3725
	str	q0, [sp, #320]                  ; 16-byte Spill
	add.2d	v0, v16, v0
	tbnz	w8, #6, LBB0_885
LBB0_870:                               ; %else3731
	mov.16b	v24, v17
	tbz	w8, #7, LBB0_872
LBB0_871:                               ; %cond.load3733
	mov.d	x8, v0[1]
	ld1.s	{ v7 }[3], [x8]
LBB0_872:                               ; %else3737
	str	q7, [sp, #13264]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #220                       ; =0xdc
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #304]                  ; 16-byte Spill
	add.2d	v1, v16, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbnz	w9, #0, LBB0_886
; %bb.873:                              ; %else3744
	mov.16b	v9, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2496]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_887
LBB0_874:                               ; %else3750
	ldr	q1, [sp, #2496]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbnz	w8, #2, LBB0_888
LBB0_875:                               ; %else3756
	orr.16b	v7, v4, v0
	str	q7, [sp, #2480]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_889
LBB0_876:                               ; %cond.load3758
	mov.d	x9, v1[1]
	mov.16b	v7, v9
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #2480]                 ; 16-byte Reload
	mov.16b	v16, v22
	add.2d	v1, v22, v1
	tbnz	w8, #4, LBB0_890
	b	LBB0_891
LBB0_877:                               ; %cond.load3672
	mov.d	x9, v1[1]
	ld1.s	{ v6 }[1], [x9]
	str	q0, [sp, #352]                  ; 16-byte Spill
	add.2d	v0, v16, v0
	tbz	w8, #6, LBB0_861
LBB0_878:                               ; %cond.load3678
	fmov	x9, d0
	ld1.s	{ v6 }[2], [x9]
	tbnz	w8, #7, LBB0_862
	b	LBB0_863
LBB0_879:                               ; %cond.load3691
	fmov	x9, d1
	ldr	s6, [x9]
	orr.16b	v7, v3, v0
	str	q7, [sp, #2528]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_865
LBB0_880:                               ; %cond.load3697
	mov.d	x9, v1[1]
	ld1.s	{ v6 }[1], [x9]
	ldr	q1, [sp, #2528]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbz	w8, #2, LBB0_866
LBB0_881:                               ; %cond.load3703
	fmov	x9, d1
	ld1.s	{ v6 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #2512]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_867
LBB0_882:                               ; %cond.load3709
	mov.d	x9, v1[1]
	ld1.s	{ v6 }[3], [x9]
	mov.16b	v7, v9
	ldr	q1, [sp, #2512]                 ; 16-byte Reload
	mov.16b	v16, v22
	add.2d	v1, v22, v1
	tbz	w8, #4, LBB0_868
LBB0_883:                               ; %cond.load3715
	fmov	x9, d1
	ld1.s	{ v7 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_869
LBB0_884:                               ; %cond.load3721
	mov.d	x9, v1[1]
	ld1.s	{ v7 }[1], [x9]
	str	q0, [sp, #320]                  ; 16-byte Spill
	add.2d	v0, v16, v0
	tbz	w8, #6, LBB0_870
LBB0_885:                               ; %cond.load3727
	fmov	x9, d0
	ld1.s	{ v7 }[2], [x9]
	mov.16b	v24, v17
	tbnz	w8, #7, LBB0_871
	b	LBB0_872
LBB0_886:                               ; %cond.load3740
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v9, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2496]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_874
LBB0_887:                               ; %cond.load3746
	mov.d	x9, v1[1]
	ld1.s	{ v9 }[1], [x9]
	ldr	q1, [sp, #2496]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbz	w8, #2, LBB0_875
LBB0_888:                               ; %cond.load3752
	fmov	x9, d1
	ld1.s	{ v9 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #2480]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_876
LBB0_889:
	mov.16b	v7, v9
	ldr	q1, [sp, #2480]                 ; 16-byte Reload
	mov.16b	v16, v22
	add.2d	v1, v22, v1
	tbz	w8, #4, LBB0_891
LBB0_890:                               ; %cond.load3764
	fmov	x9, d1
	ld1.s	{ v17 }[0], [x9]
LBB0_891:                               ; %else3768
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_909
; %bb.892:                              ; %else3774
	str	q0, [sp, #288]                  ; 16-byte Spill
	add.2d	v0, v16, v0
	tbnz	w8, #6, LBB0_910
LBB0_893:                               ; %else3780
	tbz	w8, #7, LBB0_895
LBB0_894:                               ; %cond.load3782
	mov.d	x8, v0[1]
	ld1.s	{ v17 }[3], [x8]
LBB0_895:                               ; %else3786
	str	q17, [sp, #13232]               ; 16-byte Spill
	str	q7, [sp, #13248]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #224                       ; =0xe0
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #272]                  ; 16-byte Spill
	add.2d	v1, v16, v1
	movi.2d	v17, #0000000000000000
	movi.2d	v9, #0000000000000000
	tbnz	w9, #0, LBB0_911
; %bb.896:                              ; %else3793
	orr.16b	v7, v3, v0
	str	q7, [sp, #2464]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_912
LBB0_897:                               ; %else3799
	ldr	q1, [sp, #2464]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbnz	w8, #2, LBB0_913
LBB0_898:                               ; %else3805
	orr.16b	v7, v4, v0
	str	q7, [sp, #2448]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_914
LBB0_899:                               ; %else3811
	mov.16b	v7, v9
	ldr	q1, [sp, #2448]                 ; 16-byte Reload
	mov.16b	v16, v22
	add.2d	v1, v22, v1
	tbnz	w8, #4, LBB0_915
LBB0_900:                               ; %else3817
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_916
LBB0_901:                               ; %else3823
	str	q0, [sp, #256]                  ; 16-byte Spill
	add.2d	v0, v16, v0
	tbnz	w8, #6, LBB0_917
LBB0_902:                               ; %else3829
	mov.16b	v30, v21
	tbz	w8, #7, LBB0_904
LBB0_903:                               ; %cond.load3831
	mov.d	x8, v0[1]
	ld1.s	{ v7 }[3], [x8]
LBB0_904:                               ; %else3835
	str	q7, [sp, #13200]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #228                       ; =0xe4
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #240]                  ; 16-byte Spill
	add.2d	v1, v16, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbnz	w9, #0, LBB0_918
; %bb.905:                              ; %else3842
	mov.16b	v9, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2432]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_919
LBB0_906:                               ; %else3848
	ldr	q1, [sp, #2432]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbnz	w8, #2, LBB0_920
LBB0_907:                               ; %else3854
	orr.16b	v7, v4, v0
	str	q7, [sp, #2416]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_921
LBB0_908:                               ; %cond.load3856
	mov.d	x9, v1[1]
	mov.16b	v7, v9
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #2416]                 ; 16-byte Reload
	mov.16b	v16, v22
	add.2d	v1, v22, v1
	tbnz	w8, #4, LBB0_922
	b	LBB0_923
LBB0_909:                               ; %cond.load3770
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	str	q0, [sp, #288]                  ; 16-byte Spill
	add.2d	v0, v16, v0
	tbz	w8, #6, LBB0_893
LBB0_910:                               ; %cond.load3776
	fmov	x9, d0
	ld1.s	{ v17 }[2], [x9]
	tbnz	w8, #7, LBB0_894
	b	LBB0_895
LBB0_911:                               ; %cond.load3789
	fmov	x9, d1
	ldr	s17, [x9]
	orr.16b	v7, v3, v0
	str	q7, [sp, #2464]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_897
LBB0_912:                               ; %cond.load3795
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[1], [x9]
	ldr	q1, [sp, #2464]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbz	w8, #2, LBB0_898
LBB0_913:                               ; %cond.load3801
	fmov	x9, d1
	ld1.s	{ v17 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #2448]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_899
LBB0_914:                               ; %cond.load3807
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[3], [x9]
	mov.16b	v7, v9
	ldr	q1, [sp, #2448]                 ; 16-byte Reload
	mov.16b	v16, v22
	add.2d	v1, v22, v1
	tbz	w8, #4, LBB0_900
LBB0_915:                               ; %cond.load3813
	fmov	x9, d1
	ld1.s	{ v7 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_901
LBB0_916:                               ; %cond.load3819
	mov.d	x9, v1[1]
	ld1.s	{ v7 }[1], [x9]
	str	q0, [sp, #256]                  ; 16-byte Spill
	add.2d	v0, v16, v0
	tbz	w8, #6, LBB0_902
LBB0_917:                               ; %cond.load3825
	fmov	x9, d0
	ld1.s	{ v7 }[2], [x9]
	mov.16b	v30, v21
	tbnz	w8, #7, LBB0_903
	b	LBB0_904
LBB0_918:                               ; %cond.load3838
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v9, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2432]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_906
LBB0_919:                               ; %cond.load3844
	mov.d	x9, v1[1]
	ld1.s	{ v9 }[1], [x9]
	ldr	q1, [sp, #2432]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbz	w8, #2, LBB0_907
LBB0_920:                               ; %cond.load3850
	fmov	x9, d1
	ld1.s	{ v9 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #2416]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_908
LBB0_921:
	mov.16b	v7, v9
	ldr	q1, [sp, #2416]                 ; 16-byte Reload
	mov.16b	v16, v22
	add.2d	v1, v22, v1
	tbz	w8, #4, LBB0_923
LBB0_922:                               ; %cond.load3862
	fmov	x9, d1
	ld1.s	{ v21 }[0], [x9]
LBB0_923:                               ; %else3866
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_941
; %bb.924:                              ; %else3872
	str	q0, [sp, #224]                  ; 16-byte Spill
	add.2d	v0, v16, v0
	tbnz	w8, #6, LBB0_942
LBB0_925:                               ; %else3878
	tbz	w8, #7, LBB0_927
LBB0_926:                               ; %cond.load3880
	mov.d	x8, v0[1]
	ld1.s	{ v21 }[3], [x8]
LBB0_927:                               ; %else3884
	str	q21, [sp, #13168]               ; 16-byte Spill
	str	q7, [sp, #13184]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #232                       ; =0xe8
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #208]                  ; 16-byte Spill
	add.2d	v1, v16, v1
	movi.2d	v21, #0000000000000000
	movi.2d	v9, #0000000000000000
	tbnz	w9, #0, LBB0_943
; %bb.928:                              ; %else3891
	orr.16b	v7, v3, v0
	str	q7, [sp, #2400]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_944
LBB0_929:                               ; %else3897
	ldr	q1, [sp, #2400]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbnz	w8, #2, LBB0_945
LBB0_930:                               ; %else3903
	orr.16b	v7, v4, v0
	str	q7, [sp, #2384]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_946
LBB0_931:                               ; %else3909
	mov.16b	v7, v9
	ldr	q1, [sp, #2384]                 ; 16-byte Reload
	mov.16b	v16, v22
	add.2d	v1, v22, v1
	tbnz	w8, #4, LBB0_947
LBB0_932:                               ; %else3915
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_948
LBB0_933:                               ; %else3921
	str	q0, [sp, #192]                  ; 16-byte Spill
	add.2d	v0, v16, v0
	tbnz	w8, #6, LBB0_949
LBB0_934:                               ; %else3927
	tbz	w8, #7, LBB0_936
LBB0_935:                               ; %cond.load3929
	mov.d	x8, v0[1]
	ld1.s	{ v7 }[3], [x8]
LBB0_936:                               ; %else3933
	str	q7, [sp, #13136]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #236                       ; =0xec
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #176]                  ; 16-byte Spill
	add.2d	v1, v16, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_950
; %bb.937:                              ; %else3940
	mov.16b	v9, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2368]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_951
LBB0_938:                               ; %else3946
	ldr	q1, [sp, #2368]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbnz	w8, #2, LBB0_952
LBB0_939:                               ; %else3952
	orr.16b	v7, v4, v0
	str	q7, [sp, #2352]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_953
LBB0_940:                               ; %cond.load3954
	mov.d	x9, v1[1]
	mov.16b	v7, v9
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #2352]                 ; 16-byte Reload
	mov.16b	v16, v22
	add.2d	v1, v22, v1
	tbnz	w8, #4, LBB0_954
	b	LBB0_955
LBB0_941:                               ; %cond.load3868
	mov.d	x9, v1[1]
	ld1.s	{ v21 }[1], [x9]
	str	q0, [sp, #224]                  ; 16-byte Spill
	add.2d	v0, v16, v0
	tbz	w8, #6, LBB0_925
LBB0_942:                               ; %cond.load3874
	fmov	x9, d0
	ld1.s	{ v21 }[2], [x9]
	tbnz	w8, #7, LBB0_926
	b	LBB0_927
LBB0_943:                               ; %cond.load3887
	fmov	x9, d1
	ldr	s21, [x9]
	orr.16b	v7, v3, v0
	str	q7, [sp, #2400]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_929
LBB0_944:                               ; %cond.load3893
	mov.d	x9, v1[1]
	ld1.s	{ v21 }[1], [x9]
	ldr	q1, [sp, #2400]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbz	w8, #2, LBB0_930
LBB0_945:                               ; %cond.load3899
	fmov	x9, d1
	ld1.s	{ v21 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #2384]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_931
LBB0_946:                               ; %cond.load3905
	mov.d	x9, v1[1]
	ld1.s	{ v21 }[3], [x9]
	mov.16b	v7, v9
	ldr	q1, [sp, #2384]                 ; 16-byte Reload
	mov.16b	v16, v22
	add.2d	v1, v22, v1
	tbz	w8, #4, LBB0_932
LBB0_947:                               ; %cond.load3911
	fmov	x9, d1
	ld1.s	{ v7 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_933
LBB0_948:                               ; %cond.load3917
	mov.d	x9, v1[1]
	ld1.s	{ v7 }[1], [x9]
	str	q0, [sp, #192]                  ; 16-byte Spill
	add.2d	v0, v16, v0
	tbz	w8, #6, LBB0_934
LBB0_949:                               ; %cond.load3923
	fmov	x9, d0
	ld1.s	{ v7 }[2], [x9]
	tbnz	w8, #7, LBB0_935
	b	LBB0_936
LBB0_950:                               ; %cond.load3936
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v9, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2368]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_938
LBB0_951:                               ; %cond.load3942
	mov.d	x9, v1[1]
	ld1.s	{ v9 }[1], [x9]
	ldr	q1, [sp, #2368]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbz	w8, #2, LBB0_939
LBB0_952:                               ; %cond.load3948
	fmov	x9, d1
	ld1.s	{ v9 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #2352]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_940
LBB0_953:
	mov.16b	v7, v9
	ldr	q1, [sp, #2352]                 ; 16-byte Reload
	mov.16b	v16, v22
	add.2d	v1, v22, v1
	tbz	w8, #4, LBB0_955
LBB0_954:                               ; %cond.load3960
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
LBB0_955:                               ; %else3964
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_973
; %bb.956:                              ; %else3970
	str	q0, [sp, #160]                  ; 16-byte Spill
	add.2d	v0, v16, v0
	tbnz	w8, #6, LBB0_974
LBB0_957:                               ; %else3976
	tbz	w8, #7, LBB0_959
LBB0_958:                               ; %cond.load3978
	mov.d	x8, v0[1]
	ld1.s	{ v18 }[3], [x8]
LBB0_959:                               ; %else3982
	str	q18, [sp, #13104]               ; 16-byte Spill
	str	q7, [sp, #13120]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #240                       ; =0xf0
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #144]                  ; 16-byte Spill
	add.2d	v1, v16, v1
	movi.2d	v18, #0000000000000000
	movi.2d	v9, #0000000000000000
	tbnz	w9, #0, LBB0_975
; %bb.960:                              ; %else3989
	orr.16b	v7, v3, v0
	str	q7, [sp, #2336]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_976
LBB0_961:                               ; %else3995
	ldr	q1, [sp, #2336]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbnz	w8, #2, LBB0_977
LBB0_962:                               ; %else4001
	orr.16b	v7, v4, v0
	str	q7, [sp, #2320]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_978
LBB0_963:                               ; %else4007
	mov.16b	v7, v9
	ldr	q1, [sp, #2320]                 ; 16-byte Reload
	mov.16b	v16, v22
	add.2d	v1, v22, v1
	tbnz	w8, #4, LBB0_979
LBB0_964:                               ; %else4013
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_980
LBB0_965:                               ; %else4019
	str	q0, [sp, #128]                  ; 16-byte Spill
	add.2d	v0, v16, v0
	tbnz	w8, #6, LBB0_981
LBB0_966:                               ; %else4025
	tbz	w8, #7, LBB0_968
LBB0_967:                               ; %cond.load4027
	mov.d	x8, v0[1]
	ld1.s	{ v7 }[3], [x8]
LBB0_968:                               ; %else4031
	str	q7, [sp, #13072]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #244                       ; =0xf4
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #112]                  ; 16-byte Spill
	add.2d	v1, v16, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbnz	w9, #0, LBB0_982
; %bb.969:                              ; %else4038
	mov.16b	v9, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2304]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_983
LBB0_970:                               ; %else4044
	ldr	q1, [sp, #2304]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbnz	w8, #2, LBB0_984
LBB0_971:                               ; %else4050
	orr.16b	v7, v4, v0
	str	q7, [sp, #2288]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_985
LBB0_972:                               ; %cond.load4052
	mov.d	x9, v1[1]
	mov.16b	v7, v9
	ld1.s	{ v7 }[3], [x9]
	ldr	q1, [sp, #2288]                 ; 16-byte Reload
	mov.16b	v20, v22
	add.2d	v1, v22, v1
	tbnz	w8, #4, LBB0_986
	b	LBB0_987
LBB0_973:                               ; %cond.load3966
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	str	q0, [sp, #160]                  ; 16-byte Spill
	add.2d	v0, v16, v0
	tbz	w8, #6, LBB0_957
LBB0_974:                               ; %cond.load3972
	fmov	x9, d0
	ld1.s	{ v18 }[2], [x9]
	tbnz	w8, #7, LBB0_958
	b	LBB0_959
LBB0_975:                               ; %cond.load3985
	fmov	x9, d1
	ldr	s18, [x9]
	orr.16b	v7, v3, v0
	str	q7, [sp, #2336]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_961
LBB0_976:                               ; %cond.load3991
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
	ldr	q1, [sp, #2336]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbz	w8, #2, LBB0_962
LBB0_977:                               ; %cond.load3997
	fmov	x9, d1
	ld1.s	{ v18 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #2320]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_963
LBB0_978:                               ; %cond.load4003
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[3], [x9]
	mov.16b	v7, v9
	ldr	q1, [sp, #2320]                 ; 16-byte Reload
	mov.16b	v16, v22
	add.2d	v1, v22, v1
	tbz	w8, #4, LBB0_964
LBB0_979:                               ; %cond.load4009
	fmov	x9, d1
	ld1.s	{ v7 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_965
LBB0_980:                               ; %cond.load4015
	mov.d	x9, v1[1]
	ld1.s	{ v7 }[1], [x9]
	str	q0, [sp, #128]                  ; 16-byte Spill
	add.2d	v0, v16, v0
	tbz	w8, #6, LBB0_966
LBB0_981:                               ; %cond.load4021
	fmov	x9, d0
	ld1.s	{ v7 }[2], [x9]
	tbnz	w8, #7, LBB0_967
	b	LBB0_968
LBB0_982:                               ; %cond.load4034
	fmov	x9, d1
	ldr	s7, [x9]
	mov.16b	v9, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2304]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_970
LBB0_983:                               ; %cond.load4040
	mov.d	x9, v1[1]
	ld1.s	{ v9 }[1], [x9]
	ldr	q1, [sp, #2304]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbz	w8, #2, LBB0_971
LBB0_984:                               ; %cond.load4046
	fmov	x9, d1
	ld1.s	{ v9 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #2288]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_972
LBB0_985:
	mov.16b	v7, v9
	ldr	q1, [sp, #2288]                 ; 16-byte Reload
	mov.16b	v20, v22
	add.2d	v1, v22, v1
	tbz	w8, #4, LBB0_987
LBB0_986:                               ; %cond.load4058
	fmov	x9, d1
	ld1.s	{ v16 }[0], [x9]
LBB0_987:                               ; %else4062
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_1005
; %bb.988:                              ; %else4068
	str	q0, [sp, #96]                   ; 16-byte Spill
	add.2d	v0, v20, v0
	tbnz	w8, #6, LBB0_1006
LBB0_989:                               ; %else4074
	tbz	w8, #7, LBB0_991
LBB0_990:                               ; %cond.load4076
	mov.d	x8, v0[1]
	ld1.s	{ v16 }[3], [x8]
LBB0_991:                               ; %else4080
	str	q16, [sp, #13040]               ; 16-byte Spill
	str	q7, [sp, #13056]                ; 16-byte Spill
	fmov	w9, s19
	and	w8, w9, #0xff
	mov	w10, #248                       ; =0xf8
	dup.2d	v0, x10
	orr.16b	v1, v2, v0
	str	q1, [sp, #80]                   ; 16-byte Spill
	add.2d	v1, v20, v1
	movi.2d	v16, #0000000000000000
	movi.2d	v9, #0000000000000000
	tbnz	w9, #0, LBB0_1007
; %bb.992:                              ; %else4087
	orr.16b	v7, v3, v0
	str	q7, [sp, #2272]                 ; 16-byte Spill
	tbnz	w8, #1, LBB0_1008
LBB0_993:                               ; %else4093
	ldr	q1, [sp, #2272]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbnz	w8, #2, LBB0_1009
LBB0_994:                               ; %else4099
	orr.16b	v7, v4, v0
	str	q7, [sp, #2256]                 ; 16-byte Spill
	tbnz	w8, #3, LBB0_1010
LBB0_995:                               ; %else4105
	mov.16b	v7, v9
	ldr	q1, [sp, #2256]                 ; 16-byte Reload
	mov.16b	v20, v22
	add.2d	v1, v22, v1
	tbnz	w8, #4, LBB0_1011
LBB0_996:                               ; %else4111
	orr.16b	v0, v5, v0
	tbnz	w8, #5, LBB0_1012
LBB0_997:                               ; %else4117
	str	q0, [sp, #64]                   ; 16-byte Spill
	add.2d	v0, v20, v0
	tbnz	w8, #6, LBB0_1013
LBB0_998:                               ; %else4123
	tbz	w8, #7, LBB0_1000
LBB0_999:                               ; %cond.load4125
	mov.d	x8, v0[1]
	ld1.s	{ v7 }[3], [x8]
LBB0_1000:                              ; %else4129
	str	q7, [sp, #13008]                ; 16-byte Spill
	fmov	w8, s19
	and	w11, w8, #0xff
	mov	w9, #252                        ; =0xfc
	dup.2d	v0, x9
	orr.16b	v1, v2, v0
	str	q1, [sp, #48]                   ; 16-byte Spill
	add.2d	v1, v20, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v20, #0000000000000000
	tbnz	w8, #0, LBB0_1014
; %bb.1001:                             ; %else4136
	mov.16b	v9, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2240]                 ; 16-byte Spill
	tbnz	w11, #1, LBB0_1015
LBB0_1002:                              ; %else4142
	ldr	q1, [sp, #2240]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbnz	w11, #2, LBB0_1016
LBB0_1003:                              ; %else4148
	orr.16b	v7, v4, v0
	str	q7, [sp, #2224]                 ; 16-byte Spill
	tbz	w11, #3, LBB0_1017
LBB0_1004:                              ; %cond.load4150
	mov.d	x8, v1[1]
	mov.16b	v7, v9
	ld1.s	{ v7 }[3], [x8]
	ldr	q1, [sp, #2224]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbnz	w11, #4, LBB0_1018
	b	LBB0_1019
LBB0_1005:                              ; %cond.load4064
	mov.d	x9, v1[1]
	ld1.s	{ v16 }[1], [x9]
	str	q0, [sp, #96]                   ; 16-byte Spill
	add.2d	v0, v20, v0
	tbz	w8, #6, LBB0_989
LBB0_1006:                              ; %cond.load4070
	fmov	x9, d0
	ld1.s	{ v16 }[2], [x9]
	tbnz	w8, #7, LBB0_990
	b	LBB0_991
LBB0_1007:                              ; %cond.load4083
	fmov	x9, d1
	ldr	s16, [x9]
	orr.16b	v7, v3, v0
	str	q7, [sp, #2272]                 ; 16-byte Spill
	tbz	w8, #1, LBB0_993
LBB0_1008:                              ; %cond.load4089
	mov.d	x9, v1[1]
	ld1.s	{ v16 }[1], [x9]
	ldr	q1, [sp, #2272]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbz	w8, #2, LBB0_994
LBB0_1009:                              ; %cond.load4095
	fmov	x9, d1
	ld1.s	{ v16 }[2], [x9]
	orr.16b	v7, v4, v0
	str	q7, [sp, #2256]                 ; 16-byte Spill
	tbz	w8, #3, LBB0_995
LBB0_1010:                              ; %cond.load4101
	mov.d	x9, v1[1]
	ld1.s	{ v16 }[3], [x9]
	mov.16b	v7, v9
	ldr	q1, [sp, #2256]                 ; 16-byte Reload
	mov.16b	v20, v22
	add.2d	v1, v22, v1
	tbz	w8, #4, LBB0_996
LBB0_1011:                              ; %cond.load4107
	fmov	x9, d1
	ld1.s	{ v7 }[0], [x9]
	orr.16b	v0, v5, v0
	tbz	w8, #5, LBB0_997
LBB0_1012:                              ; %cond.load4113
	mov.d	x9, v1[1]
	ld1.s	{ v7 }[1], [x9]
	str	q0, [sp, #64]                   ; 16-byte Spill
	add.2d	v0, v20, v0
	tbz	w8, #6, LBB0_998
LBB0_1013:                              ; %cond.load4119
	fmov	x9, d0
	ld1.s	{ v7 }[2], [x9]
	tbnz	w8, #7, LBB0_999
	b	LBB0_1000
LBB0_1014:                              ; %cond.load4132
	fmov	x8, d1
	ldr	s7, [x8]
	mov.16b	v9, v7
	orr.16b	v7, v3, v0
	str	q7, [sp, #2240]                 ; 16-byte Spill
	tbz	w11, #1, LBB0_1002
LBB0_1015:                              ; %cond.load4138
	mov.d	x8, v1[1]
	ld1.s	{ v9 }[1], [x8]
	ldr	q1, [sp, #2240]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbz	w11, #2, LBB0_1003
LBB0_1016:                              ; %cond.load4144
	fmov	x8, d1
	ld1.s	{ v9 }[2], [x8]
	orr.16b	v7, v4, v0
	str	q7, [sp, #2224]                 ; 16-byte Spill
	tbnz	w11, #3, LBB0_1004
LBB0_1017:
	mov.16b	v7, v9
	ldr	q1, [sp, #2224]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	tbz	w11, #4, LBB0_1019
LBB0_1018:                              ; %cond.load4156
	fmov	x8, d1
	ld1.s	{ v20 }[0], [x8]
LBB0_1019:                              ; %else4160
	orr.16b	v0, v5, v0
	tbz	w11, #5, LBB0_1021
; %bb.1020:                             ; %cond.load4162
	mov.d	x8, v1[1]
	ld1.s	{ v20 }[1], [x8]
LBB0_1021:                              ; %else4166
	ldr	x8, [x1, #136]
	str	q0, [sp, #32]                   ; 16-byte Spill
	add.2d	v0, v22, v0
	str	q2, [sp, #2208]                 ; 16-byte Spill
	str	q3, [sp, #2192]                 ; 16-byte Spill
	str	q4, [sp, #2176]                 ; 16-byte Spill
	str	q5, [sp, #2160]                 ; 16-byte Spill
	tbz	w11, #6, LBB0_1023
; %bb.1022:                             ; %cond.load4168
	fmov	x9, d0
	ld1.s	{ v20 }[2], [x9]
LBB0_1023:                              ; %else4172
	str	q18, [sp, #13088]               ; 16-byte Spill
	str	q17, [sp, #13216]               ; 16-byte Spill
	add	x9, x8, #8, lsl #12             ; =32768
	add	x10, x8, #16, lsl #12           ; =65536
	add	x10, x10, #512
	ldr	q3, [sp, #13632]                ; 16-byte Reload
	ushll2.2d	v4, v3, #0
	ldr	q1, [sp, #13648]                ; 16-byte Reload
	ushll2.2d	v2, v1, #0
	ushll.2d	v3, v3, #0
	ushll.2d	v5, v1, #0
	str	q24, [sp, #13648]               ; 16-byte Spill
	str	q25, [sp, #13632]               ; 16-byte Spill
	str	q6, [sp, #13280]                ; 16-byte Spill
	str	q21, [sp, #13152]               ; 16-byte Spill
	str	q16, [sp, #13024]               ; 16-byte Spill
	str	q30, [sp, #1440]                ; 16-byte Spill
	str	q7, [sp, #12992]                ; 16-byte Spill
	tbz	w11, #7, LBB0_1025
; %bb.1024:                             ; %cond.load4174
	mov.d	x11, v0[1]
	ld1.s	{ v20 }[3], [x11]
LBB0_1025:                              ; %else4178
	str	q20, [sp, #12976]               ; 16-byte Spill
	sshll2.2d	v7, v15, #0
	mov	x11, #0                         ; =0x0
	sshll.2d	v0, v14, #0
	ldr	x13, [x0, #16]
	sshll.2d	v1, v15, #0
	sshll2.2d	v16, v14, #0
	mov	w12, #62154                     ; =0xf2ca
	movk	w12, #61769, lsl #16
	dup.4s	v6, w12
	ldr	x14, [x0, #32]
	and.16b	v20, v15, v6
	str	q20, [sp, #11856]               ; 16-byte Spill
	ldr	x12, [x0, #48]
	str	x12, [sp, #8]                   ; 8-byte Spill
	and.16b	v6, v14, v6
	str	q6, [sp, #11840]                ; 16-byte Spill
	shl.2d	v4, v4, #19
	shl.2d	v5, v5, #19
	shl.2d	v3, v3, #19
	shl.2d	v2, v2, #19
	str	q16, [sp, #16]                  ; 16-byte Spill
	and.16b	v16, v16, v2
	and.16b	v9, v1, v3
	and.16b	v0, v0, v5
	str	q0, [sp, #11936]                ; 16-byte Spill
	str	q7, [sp, #4128]                 ; 16-byte Spill
	and.16b	v0, v7, v4
	str	q0, [sp, #11920]                ; 16-byte Spill
	mov	w12, #32800                     ; =0x8020
	add	x12, x8, x12
	str	x12, [sp, #4888]                ; 8-byte Spill
	mov	w12, #32832                     ; =0x8040
	add	x12, x8, x12
	str	x12, [sp, #4880]                ; 8-byte Spill
	mov	w12, #32864                     ; =0x8060
	add	x12, x8, x12
	str	x12, [sp, #4872]                ; 8-byte Spill
	mov	w12, #32896                     ; =0x8080
	add	x12, x8, x12
	str	x12, [sp, #4864]                ; 8-byte Spill
	mov	w12, #32928                     ; =0x80a0
	add	x12, x8, x12
	str	x12, [sp, #4856]                ; 8-byte Spill
	mov	w12, #32960                     ; =0x80c0
	add	x12, x8, x12
	str	x12, [sp, #4848]                ; 8-byte Spill
	mov	w12, #32992                     ; =0x80e0
	add	x12, x8, x12
	str	x12, [sp, #4840]                ; 8-byte Spill
	mov	w12, #33024                     ; =0x8100
	add	x12, x8, x12
	str	x12, [sp, #4832]                ; 8-byte Spill
	mvni.4s	v0, #63, msl #16
	mov	w12, #33056                     ; =0x8120
	fneg.4s	v0, v0
	str	q0, [sp, #4816]                 ; 16-byte Spill
	add	x12, x8, x12
	str	x12, [sp, #4808]                ; 8-byte Spill
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #9296]                 ; 16-byte Spill
	mov	w12, #33088                     ; =0x8140
	str	q0, [sp, #9280]                 ; 16-byte Spill
	add	x12, x8, x12
	str	x12, [sp, #4800]                ; 8-byte Spill
	str	q0, [sp, #9264]                 ; 16-byte Spill
	mov	w12, #33120                     ; =0x8160
	str	q0, [sp, #9248]                 ; 16-byte Spill
	add	x12, x8, x12
	str	x12, [sp, #4792]                ; 8-byte Spill
	str	q0, [sp, #9232]                 ; 16-byte Spill
	mov	w12, #33152                     ; =0x8180
	str	q0, [sp, #9216]                 ; 16-byte Spill
	add	x12, x8, x12
	str	x12, [sp, #4784]                ; 8-byte Spill
	str	q0, [sp, #9200]                 ; 16-byte Spill
	mov	w12, #33184                     ; =0x81a0
	str	q0, [sp, #9184]                 ; 16-byte Spill
	add	x12, x8, x12
	str	x12, [sp, #4776]                ; 8-byte Spill
	str	q0, [sp, #9168]                 ; 16-byte Spill
	mov	w12, #33216                     ; =0x81c0
	str	q0, [sp, #9152]                 ; 16-byte Spill
	add	x12, x8, x12
	str	x12, [sp, #4768]                ; 8-byte Spill
	str	q0, [sp, #9136]                 ; 16-byte Spill
	mov	w12, #33248                     ; =0x81e0
	str	q0, [sp, #9120]                 ; 16-byte Spill
	add	x12, x8, x12
	str	x12, [sp, #4760]                ; 8-byte Spill
	str	q0, [sp, #9104]                 ; 16-byte Spill
	mov	w12, #33280                     ; =0x8200
	str	q0, [sp, #9088]                 ; 16-byte Spill
	add	x23, x8, x12
	str	q0, [sp, #9072]                 ; 16-byte Spill
	mov	w12, #33312                     ; =0x8220
	str	q0, [sp, #9056]                 ; 16-byte Spill
	add	x12, x8, x12
	str	x12, [sp, #4752]                ; 8-byte Spill
	mov	w12, #33344                     ; =0x8240
	add	x12, x8, x12
	str	x12, [sp, #4744]                ; 8-byte Spill
	mov	w12, #33376                     ; =0x8260
	add	x12, x8, x12
	str	x12, [sp, #4736]                ; 8-byte Spill
	mov	w12, #33408                     ; =0x8280
	add	x12, x8, x12
	str	x12, [sp, #4728]                ; 8-byte Spill
	mov	w12, #33440                     ; =0x82a0
	add	x12, x8, x12
	str	x12, [sp, #4720]                ; 8-byte Spill
	mov	w12, #33472                     ; =0x82c0
	add	x12, x8, x12
	str	x12, [sp, #4712]                ; 8-byte Spill
	mov	w12, #33504                     ; =0x82e0
	add	x12, x8, x12
	str	x12, [sp, #4704]                ; 8-byte Spill
	mov	w12, #33536                     ; =0x8300
	add	x12, x8, x12
	str	x12, [sp, #4696]                ; 8-byte Spill
	mov	w12, #33568                     ; =0x8320
	add	x12, x8, x12
	str	x12, [sp, #4688]                ; 8-byte Spill
	mov	w12, #33600                     ; =0x8340
	add	x12, x8, x12
	str	x12, [sp, #4680]                ; 8-byte Spill
	mov	w12, #33632                     ; =0x8360
	add	x12, x8, x12
	str	x12, [sp, #4672]                ; 8-byte Spill
	mov	w12, #33664                     ; =0x8380
	add	x12, x8, x12
	str	x12, [sp, #4664]                ; 8-byte Spill
	mov	w12, #33696                     ; =0x83a0
	add	x12, x8, x12
	str	x12, [sp, #4656]                ; 8-byte Spill
	mov	w12, #33728                     ; =0x83c0
	add	x12, x8, x12
	str	x12, [sp, #4648]                ; 8-byte Spill
	mov	w12, #33760                     ; =0x83e0
	add	x12, x8, x12
	str	x12, [sp, #4640]                ; 8-byte Spill
	mov	w12, #33792                     ; =0x8400
	add	x12, x8, x12
	str	x12, [sp, #4632]                ; 8-byte Spill
	mov	w12, #33824                     ; =0x8420
	add	x12, x8, x12
	str	x12, [sp, #4624]                ; 8-byte Spill
	mov	w12, #33856                     ; =0x8440
	add	x12, x8, x12
	str	x12, [sp, #4616]                ; 8-byte Spill
	mov	w12, #33888                     ; =0x8460
	add	x12, x8, x12
	str	x12, [sp, #4608]                ; 8-byte Spill
	mov	w12, #33920                     ; =0x8480
	add	x12, x8, x12
	str	x12, [sp, #4600]                ; 8-byte Spill
	mov	w12, #33952                     ; =0x84a0
	add	x12, x8, x12
	str	x12, [sp, #4592]                ; 8-byte Spill
	mov	w12, #33984                     ; =0x84c0
	add	x12, x8, x12
	str	x12, [sp, #4584]                ; 8-byte Spill
	mov	w12, #34016                     ; =0x84e0
	add	x12, x8, x12
	str	x12, [sp, #4576]                ; 8-byte Spill
	mov	w12, #34048                     ; =0x8500
	add	x12, x8, x12
	str	x12, [sp, #4568]                ; 8-byte Spill
	mov	w12, #34080                     ; =0x8520
	add	x12, x8, x12
	str	x12, [sp, #4560]                ; 8-byte Spill
	mov	w12, #34112                     ; =0x8540
	add	x12, x8, x12
	str	x12, [sp, #4552]                ; 8-byte Spill
	mov	w12, #34144                     ; =0x8560
	add	x12, x8, x12
	str	x12, [sp, #4544]                ; 8-byte Spill
	mov	w12, #34176                     ; =0x8580
	add	x12, x8, x12
	str	x12, [sp, #4536]                ; 8-byte Spill
	mov	w12, #34208                     ; =0x85a0
	add	x12, x8, x12
	str	x12, [sp, #4528]                ; 8-byte Spill
	mov	w12, #34240                     ; =0x85c0
	add	x12, x8, x12
	str	x12, [sp, #4520]                ; 8-byte Spill
	mov	w12, #34272                     ; =0x85e0
	add	x12, x8, x12
	str	x12, [sp, #4512]                ; 8-byte Spill
	mov	w12, #34304                     ; =0x8600
	add	x12, x8, x12
	str	x12, [sp, #4504]                ; 8-byte Spill
	mov	w12, #34336                     ; =0x8620
	add	x12, x8, x12
	str	x12, [sp, #4496]                ; 8-byte Spill
	mov	w12, #34368                     ; =0x8640
	add	x12, x8, x12
	str	x12, [sp, #4488]                ; 8-byte Spill
	mov	w12, #34400                     ; =0x8660
	add	x12, x8, x12
	str	x12, [sp, #4480]                ; 8-byte Spill
	mov	w12, #34432                     ; =0x8680
	add	x12, x8, x12
	str	x12, [sp, #4472]                ; 8-byte Spill
	mov	w12, #34464                     ; =0x86a0
	add	x12, x8, x12
	str	x12, [sp, #4464]                ; 8-byte Spill
	mov	w12, #34496                     ; =0x86c0
	add	x12, x8, x12
	str	x12, [sp, #4456]                ; 8-byte Spill
	mov	w12, #34528                     ; =0x86e0
	add	x12, x8, x12
	str	x12, [sp, #4448]                ; 8-byte Spill
	mov	w12, #34560                     ; =0x8700
	add	x12, x8, x12
	str	x12, [sp, #4440]                ; 8-byte Spill
	mov	w12, #34592                     ; =0x8720
	add	x12, x8, x12
	str	x12, [sp, #4432]                ; 8-byte Spill
	mov	w12, #34624                     ; =0x8740
	add	x12, x8, x12
	str	x12, [sp, #4424]                ; 8-byte Spill
	mov	w12, #34656                     ; =0x8760
	add	x12, x8, x12
	str	x12, [sp, #4416]                ; 8-byte Spill
	mov	w12, #34688                     ; =0x8780
	add	x12, x8, x12
	str	x12, [sp, #4408]                ; 8-byte Spill
	mov	w12, #34720                     ; =0x87a0
	add	x12, x8, x12
	str	x12, [sp, #4400]                ; 8-byte Spill
	mov	w12, #34752                     ; =0x87c0
	add	x12, x8, x12
	str	x12, [sp, #4392]                ; 8-byte Spill
	mov	w12, #34784                     ; =0x87e0
	add	x12, x8, x12
	str	x12, [sp, #4384]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #32
	str	x12, [sp, #4376]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #64
	str	x12, [sp, #4368]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #96
	str	x12, [sp, #4360]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #128
	str	x12, [sp, #4352]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #160
	str	x12, [sp, #4344]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #192
	str	x12, [sp, #4336]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #224
	str	x12, [sp, #4328]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #256
	str	x12, [sp, #4320]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #288
	str	x12, [sp, #4312]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #320
	str	x12, [sp, #4304]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #352
	str	x12, [sp, #4296]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #384
	str	x12, [sp, #4288]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #416
	str	x12, [sp, #4280]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #448
	str	x12, [sp, #4272]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #480
	str	x12, [sp, #4264]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #512
	str	x12, [sp, #4256]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #544
	str	x12, [sp, #4248]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #576
	str	x12, [sp, #4240]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #608
	str	x12, [sp, #4232]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #640
	str	x12, [sp, #4224]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #672
	str	x12, [sp, #4216]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #704
	str	x12, [sp, #4208]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #736
	str	x12, [sp, #4200]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #768
	str	x12, [sp, #4192]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #800
	str	x12, [sp, #4184]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #832
	str	x12, [sp, #4176]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #864
	str	x12, [sp, #4168]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #896
	str	x12, [sp, #4160]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #928
	str	x12, [sp, #4152]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x12, x12, #960
	str	x12, [sp, #4144]                ; 8-byte Spill
	add	x12, x8, #16, lsl #12           ; =65536
	add	x1, x12, #992
	add	x2, x8, #16, lsl #12            ; =65536
	mov	w3, #6144                       ; =0x1800
	add	x4, x8, x3
	mov	w5, #10240                      ; =0x2800
	add	x6, x8, x5
	mov	w7, #14336                      ; =0x3800
	add	x19, x8, x7
	mov	w20, #18432                     ; =0x4800
	add	x21, x8, x20
	mov	w22, #22528                     ; =0x5800
	add	x24, x8, x22
	mov	w25, #26624                     ; =0x6800
	add	x26, x8, x25
	mov	w27, #30720                     ; =0x7800
	add	x28, x8, x27
	str	q0, [sp, #9040]                 ; 16-byte Spill
	str	q0, [sp, #9024]                 ; 16-byte Spill
	str	q0, [sp, #9008]                 ; 16-byte Spill
	str	q0, [sp, #8992]                 ; 16-byte Spill
	str	q0, [sp, #8976]                 ; 16-byte Spill
	str	q0, [sp, #8960]                 ; 16-byte Spill
	str	q0, [sp, #8944]                 ; 16-byte Spill
	str	q0, [sp, #8928]                 ; 16-byte Spill
	str	q0, [sp, #8912]                 ; 16-byte Spill
	str	q0, [sp, #8896]                 ; 16-byte Spill
	str	q0, [sp, #8880]                 ; 16-byte Spill
	str	q0, [sp, #8864]                 ; 16-byte Spill
	str	q0, [sp, #8848]                 ; 16-byte Spill
	str	q0, [sp, #8832]                 ; 16-byte Spill
	str	q0, [sp, #8816]                 ; 16-byte Spill
	str	q0, [sp, #8800]                 ; 16-byte Spill
	str	q0, [sp, #8784]                 ; 16-byte Spill
	str	q0, [sp, #8768]                 ; 16-byte Spill
	str	q0, [sp, #8752]                 ; 16-byte Spill
	str	q0, [sp, #8736]                 ; 16-byte Spill
	str	q0, [sp, #8720]                 ; 16-byte Spill
	str	q0, [sp, #8704]                 ; 16-byte Spill
	str	q0, [sp, #8688]                 ; 16-byte Spill
	str	q0, [sp, #8672]                 ; 16-byte Spill
	str	q0, [sp, #8656]                 ; 16-byte Spill
	str	q0, [sp, #8640]                 ; 16-byte Spill
	str	q0, [sp, #8624]                 ; 16-byte Spill
	str	q0, [sp, #8608]                 ; 16-byte Spill
	movi.2d	v24, #0000000000000000
	str	q0, [sp, #8592]                 ; 16-byte Spill
	str	q0, [sp, #8576]                 ; 16-byte Spill
	str	q0, [sp, #8560]                 ; 16-byte Spill
	str	q0, [sp, #8544]                 ; 16-byte Spill
	str	q0, [sp, #8528]                 ; 16-byte Spill
	str	q0, [sp, #8512]                 ; 16-byte Spill
	str	q0, [sp, #8496]                 ; 16-byte Spill
	str	q0, [sp, #8480]                 ; 16-byte Spill
	str	q0, [sp, #8464]                 ; 16-byte Spill
	str	q0, [sp, #8448]                 ; 16-byte Spill
	str	q0, [sp, #8432]                 ; 16-byte Spill
	str	q0, [sp, #8416]                 ; 16-byte Spill
	str	q0, [sp, #8400]                 ; 16-byte Spill
	str	q0, [sp, #8384]                 ; 16-byte Spill
	str	q0, [sp, #8368]                 ; 16-byte Spill
	str	q0, [sp, #8352]                 ; 16-byte Spill
	str	q0, [sp, #8336]                 ; 16-byte Spill
	str	q0, [sp, #8320]                 ; 16-byte Spill
	str	q0, [sp, #8304]                 ; 16-byte Spill
	str	q0, [sp, #8288]                 ; 16-byte Spill
	str	q0, [sp, #8272]                 ; 16-byte Spill
	str	q0, [sp, #8256]                 ; 16-byte Spill
	str	q0, [sp, #8240]                 ; 16-byte Spill
	str	q0, [sp, #8224]                 ; 16-byte Spill
	str	q0, [sp, #8208]                 ; 16-byte Spill
	str	q0, [sp, #8192]                 ; 16-byte Spill
	str	q0, [sp, #8176]                 ; 16-byte Spill
	str	q0, [sp, #8160]                 ; 16-byte Spill
	str	q0, [sp, #8144]                 ; 16-byte Spill
	str	q0, [sp, #8128]                 ; 16-byte Spill
	str	q0, [sp, #8112]                 ; 16-byte Spill
	str	q0, [sp, #8096]                 ; 16-byte Spill
	str	q0, [sp, #8080]                 ; 16-byte Spill
	str	q0, [sp, #8064]                 ; 16-byte Spill
	str	q0, [sp, #8048]                 ; 16-byte Spill
	str	q0, [sp, #8032]                 ; 16-byte Spill
	str	q0, [sp, #8016]                 ; 16-byte Spill
	str	q0, [sp, #8000]                 ; 16-byte Spill
	str	q0, [sp, #7984]                 ; 16-byte Spill
	str	q0, [sp, #7968]                 ; 16-byte Spill
	str	q0, [sp, #7952]                 ; 16-byte Spill
	str	q0, [sp, #7936]                 ; 16-byte Spill
	str	q0, [sp, #7920]                 ; 16-byte Spill
	str	q0, [sp, #7904]                 ; 16-byte Spill
	str	q0, [sp, #7888]                 ; 16-byte Spill
	str	q0, [sp, #7872]                 ; 16-byte Spill
	str	q0, [sp, #7856]                 ; 16-byte Spill
	str	q0, [sp, #7840]                 ; 16-byte Spill
	str	q0, [sp, #7824]                 ; 16-byte Spill
	str	q0, [sp, #7808]                 ; 16-byte Spill
	str	q0, [sp, #7792]                 ; 16-byte Spill
	str	q0, [sp, #7776]                 ; 16-byte Spill
	str	q0, [sp, #7760]                 ; 16-byte Spill
	str	q0, [sp, #7744]                 ; 16-byte Spill
	str	q0, [sp, #7728]                 ; 16-byte Spill
	str	q0, [sp, #7712]                 ; 16-byte Spill
	str	q0, [sp, #7696]                 ; 16-byte Spill
	str	q0, [sp, #7680]                 ; 16-byte Spill
	str	q0, [sp, #7664]                 ; 16-byte Spill
	str	q0, [sp, #7648]                 ; 16-byte Spill
	str	q0, [sp, #7632]                 ; 16-byte Spill
	str	q0, [sp, #7616]                 ; 16-byte Spill
	str	q0, [sp, #7600]                 ; 16-byte Spill
	str	q0, [sp, #7584]                 ; 16-byte Spill
	str	q0, [sp, #7568]                 ; 16-byte Spill
	str	q0, [sp, #7552]                 ; 16-byte Spill
	str	q0, [sp, #7536]                 ; 16-byte Spill
	str	q0, [sp, #7520]                 ; 16-byte Spill
	str	q0, [sp, #7504]                 ; 16-byte Spill
	str	q0, [sp, #7488]                 ; 16-byte Spill
	str	q0, [sp, #7472]                 ; 16-byte Spill
	str	q0, [sp, #7456]                 ; 16-byte Spill
	str	q0, [sp, #7440]                 ; 16-byte Spill
	str	q0, [sp, #7424]                 ; 16-byte Spill
	str	q0, [sp, #7408]                 ; 16-byte Spill
	str	q0, [sp, #9760]                 ; 16-byte Spill
	str	q0, [sp, #9744]                 ; 16-byte Spill
	str	q0, [sp, #9728]                 ; 16-byte Spill
	str	q0, [sp, #9712]                 ; 16-byte Spill
	str	q0, [sp, #9696]                 ; 16-byte Spill
	str	q0, [sp, #9680]                 ; 16-byte Spill
	str	q0, [sp, #9664]                 ; 16-byte Spill
	str	q0, [sp, #9648]                 ; 16-byte Spill
	str	q0, [sp, #9632]                 ; 16-byte Spill
	str	q0, [sp, #9616]                 ; 16-byte Spill
	str	q0, [sp, #7392]                 ; 16-byte Spill
	str	q0, [sp, #9600]                 ; 16-byte Spill
	str	q0, [sp, #9584]                 ; 16-byte Spill
	str	q0, [sp, #9568]                 ; 16-byte Spill
	str	q0, [sp, #9552]                 ; 16-byte Spill
	str	q0, [sp, #9536]                 ; 16-byte Spill
	str	q0, [sp, #7376]                 ; 16-byte Spill
	str	q0, [sp, #7360]                 ; 16-byte Spill
	str	q0, [sp, #7344]                 ; 16-byte Spill
	str	q0, [sp, #7328]                 ; 16-byte Spill
	str	q0, [sp, #7312]                 ; 16-byte Spill
	str	q0, [sp, #7296]                 ; 16-byte Spill
	str	q0, [sp, #7280]                 ; 16-byte Spill
	str	q0, [sp, #7264]                 ; 16-byte Spill
	str	q0, [sp, #7248]                 ; 16-byte Spill
	str	q0, [sp, #7232]                 ; 16-byte Spill
	str	q0, [sp, #7216]                 ; 16-byte Spill
	str	q0, [sp, #7200]                 ; 16-byte Spill
	str	q0, [sp, #9520]                 ; 16-byte Spill
	str	q0, [sp, #9504]                 ; 16-byte Spill
	str	q0, [sp, #9488]                 ; 16-byte Spill
	str	q0, [sp, #9472]                 ; 16-byte Spill
	str	q0, [sp, #9456]                 ; 16-byte Spill
	str	q0, [sp, #9440]                 ; 16-byte Spill
	str	q0, [sp, #9424]                 ; 16-byte Spill
	str	q0, [sp, #9408]                 ; 16-byte Spill
	str	q0, [sp, #9392]                 ; 16-byte Spill
	str	q0, [sp, #9376]                 ; 16-byte Spill
	str	q0, [sp, #9360]                 ; 16-byte Spill
	str	q0, [sp, #9344]                 ; 16-byte Spill
	str	q0, [sp, #9328]                 ; 16-byte Spill
	str	q0, [sp, #9312]                 ; 16-byte Spill
	str	q0, [sp, #11792]                ; 16-byte Spill
	str	q0, [sp, #11808]                ; 16-byte Spill
	str	q0, [sp, #11760]                ; 16-byte Spill
	str	q0, [sp, #11776]                ; 16-byte Spill
	str	q0, [sp, #11728]                ; 16-byte Spill
	str	q0, [sp, #11744]                ; 16-byte Spill
	str	q0, [sp, #11696]                ; 16-byte Spill
	str	q0, [sp, #11712]                ; 16-byte Spill
	str	q0, [sp, #11664]                ; 16-byte Spill
	str	q0, [sp, #11680]                ; 16-byte Spill
	str	q0, [sp, #11632]                ; 16-byte Spill
	str	q0, [sp, #11648]                ; 16-byte Spill
	str	q0, [sp, #11600]                ; 16-byte Spill
	str	q0, [sp, #11616]                ; 16-byte Spill
	str	q0, [sp, #11568]                ; 16-byte Spill
	str	q0, [sp, #11584]                ; 16-byte Spill
	str	q0, [sp, #11536]                ; 16-byte Spill
	str	q0, [sp, #11552]                ; 16-byte Spill
	str	q0, [sp, #11504]                ; 16-byte Spill
	str	q0, [sp, #11520]                ; 16-byte Spill
	str	q0, [sp, #11472]                ; 16-byte Spill
	str	q0, [sp, #11488]                ; 16-byte Spill
	str	q0, [sp, #11440]                ; 16-byte Spill
	str	q0, [sp, #11456]                ; 16-byte Spill
	str	q0, [sp, #11408]                ; 16-byte Spill
	str	q0, [sp, #11424]                ; 16-byte Spill
	str	q0, [sp, #11376]                ; 16-byte Spill
	str	q0, [sp, #11392]                ; 16-byte Spill
	str	q0, [sp, #11344]                ; 16-byte Spill
	str	q0, [sp, #11360]                ; 16-byte Spill
	str	q0, [sp, #11312]                ; 16-byte Spill
	str	q0, [sp, #11328]                ; 16-byte Spill
	str	q0, [sp, #11280]                ; 16-byte Spill
	str	q0, [sp, #11296]                ; 16-byte Spill
	str	q0, [sp, #11248]                ; 16-byte Spill
	str	q0, [sp, #11264]                ; 16-byte Spill
	str	q0, [sp, #11216]                ; 16-byte Spill
	str	q0, [sp, #11232]                ; 16-byte Spill
	str	q0, [sp, #11184]                ; 16-byte Spill
	str	q0, [sp, #11200]                ; 16-byte Spill
	str	q0, [sp, #11152]                ; 16-byte Spill
	str	q0, [sp, #11168]                ; 16-byte Spill
	str	q0, [sp, #11120]                ; 16-byte Spill
	str	q0, [sp, #11136]                ; 16-byte Spill
	str	q0, [sp, #11088]                ; 16-byte Spill
	str	q0, [sp, #11104]                ; 16-byte Spill
	str	q0, [sp, #11056]                ; 16-byte Spill
	str	q0, [sp, #11072]                ; 16-byte Spill
	str	q0, [sp, #11024]                ; 16-byte Spill
	str	q0, [sp, #11040]                ; 16-byte Spill
	str	q0, [sp, #10992]                ; 16-byte Spill
	str	q0, [sp, #11008]                ; 16-byte Spill
	str	q0, [sp, #10960]                ; 16-byte Spill
	str	q0, [sp, #10976]                ; 16-byte Spill
	str	q0, [sp, #10928]                ; 16-byte Spill
	str	q0, [sp, #10944]                ; 16-byte Spill
	str	q0, [sp, #10896]                ; 16-byte Spill
	str	q0, [sp, #10912]                ; 16-byte Spill
	str	q0, [sp, #10864]                ; 16-byte Spill
	str	q0, [sp, #10880]                ; 16-byte Spill
	str	q0, [sp, #10832]                ; 16-byte Spill
	str	q0, [sp, #10848]                ; 16-byte Spill
	str	q0, [sp, #10800]                ; 16-byte Spill
	str	q0, [sp, #10816]                ; 16-byte Spill
	str	q0, [sp, #10768]                ; 16-byte Spill
	str	q0, [sp, #10784]                ; 16-byte Spill
	str	q0, [sp, #10736]                ; 16-byte Spill
	str	q0, [sp, #10752]                ; 16-byte Spill
	str	q0, [sp, #10704]                ; 16-byte Spill
	str	q0, [sp, #10720]                ; 16-byte Spill
	str	q0, [sp, #10672]                ; 16-byte Spill
	str	q0, [sp, #10688]                ; 16-byte Spill
	str	q0, [sp, #10640]                ; 16-byte Spill
	str	q0, [sp, #10656]                ; 16-byte Spill
	str	q0, [sp, #10608]                ; 16-byte Spill
	str	q0, [sp, #10624]                ; 16-byte Spill
	str	q0, [sp, #10576]                ; 16-byte Spill
	str	q0, [sp, #10592]                ; 16-byte Spill
	str	q0, [sp, #10544]                ; 16-byte Spill
	str	q0, [sp, #10560]                ; 16-byte Spill
	str	q0, [sp, #10512]                ; 16-byte Spill
	str	q0, [sp, #10528]                ; 16-byte Spill
	str	q0, [sp, #10480]                ; 16-byte Spill
	str	q0, [sp, #10496]                ; 16-byte Spill
	str	q0, [sp, #10448]                ; 16-byte Spill
	str	q0, [sp, #10464]                ; 16-byte Spill
	str	q0, [sp, #10416]                ; 16-byte Spill
	str	q0, [sp, #10432]                ; 16-byte Spill
	str	q0, [sp, #10384]                ; 16-byte Spill
	str	q0, [sp, #10400]                ; 16-byte Spill
	str	q0, [sp, #10352]                ; 16-byte Spill
	str	q0, [sp, #10368]                ; 16-byte Spill
	str	q0, [sp, #10320]                ; 16-byte Spill
	str	q0, [sp, #10336]                ; 16-byte Spill
	str	q0, [sp, #10288]                ; 16-byte Spill
	str	q0, [sp, #10304]                ; 16-byte Spill
	str	q0, [sp, #10256]                ; 16-byte Spill
	str	q0, [sp, #10272]                ; 16-byte Spill
	str	q0, [sp, #10224]                ; 16-byte Spill
	str	q0, [sp, #10240]                ; 16-byte Spill
	str	q0, [sp, #10192]                ; 16-byte Spill
	str	q0, [sp, #10208]                ; 16-byte Spill
	str	q0, [sp, #10160]                ; 16-byte Spill
	str	q0, [sp, #10176]                ; 16-byte Spill
	str	q0, [sp, #10128]                ; 16-byte Spill
	str	q0, [sp, #10144]                ; 16-byte Spill
	str	q0, [sp, #10096]                ; 16-byte Spill
	str	q0, [sp, #10112]                ; 16-byte Spill
	str	q0, [sp, #10064]                ; 16-byte Spill
	str	q0, [sp, #10080]                ; 16-byte Spill
	str	q0, [sp, #10032]                ; 16-byte Spill
	str	q0, [sp, #10048]                ; 16-byte Spill
	str	q0, [sp, #10000]                ; 16-byte Spill
	str	q0, [sp, #10016]                ; 16-byte Spill
	str	q0, [sp, #9968]                 ; 16-byte Spill
	str	q0, [sp, #9984]                 ; 16-byte Spill
	str	q0, [sp, #9936]                 ; 16-byte Spill
	str	q0, [sp, #9952]                 ; 16-byte Spill
	str	q0, [sp, #9904]                 ; 16-byte Spill
	str	q0, [sp, #9920]                 ; 16-byte Spill
	str	q0, [sp, #9872]                 ; 16-byte Spill
	str	q0, [sp, #9888]                 ; 16-byte Spill
	str	q0, [sp, #9840]                 ; 16-byte Spill
	str	q0, [sp, #9856]                 ; 16-byte Spill
	str	q0, [sp, #9808]                 ; 16-byte Spill
	str	q0, [sp, #9824]                 ; 16-byte Spill
	str	q0, [sp, #9776]                 ; 16-byte Spill
	str	q0, [sp, #9792]                 ; 16-byte Spill
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	str	q15, [sp, #11904]               ; 16-byte Spill
	str	q19, [sp, #4960]                ; 16-byte Spill
	str	q29, [sp, #4944]                ; 16-byte Spill
	str	q28, [sp, #4928]                ; 16-byte Spill
	str	q13, [sp, #12048]               ; 16-byte Spill
	str	q26, [sp, #12032]               ; 16-byte Spill
	str	q12, [sp, #12448]               ; 16-byte Spill
	str	q31, [sp, #12672]               ; 16-byte Spill
	str	q27, [sp, #12656]               ; 16-byte Spill
	str	q11, [sp, #12912]               ; 16-byte Spill
	str	q8, [sp, #13920]                ; 16-byte Spill
	str	q10, [sp, #13904]               ; 16-byte Spill
	str	q23, [sp, #13888]               ; 16-byte Spill
	str	q16, [sp, #4912]                ; 16-byte Spill
	str	q9, [sp, #4896]                 ; 16-byte Spill
LBB0_1026:                              ; %direct.true
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_1028 Depth 2
                                        ;     Child Loop BB0_1046 Depth 2
                                        ;     Child Loop BB0_1063 Depth 2
                                        ;     Child Loop BB0_1065 Depth 2
                                        ;     Child Loop BB0_1067 Depth 2
                                        ;     Child Loop BB0_1069 Depth 2
                                        ;     Child Loop BB0_1071 Depth 2
                                        ;     Child Loop BB0_1073 Depth 2
                                        ;     Child Loop BB0_1075 Depth 2
                                        ;     Child Loop BB0_1077 Depth 2
                                        ;     Child Loop BB0_1079 Depth 2
                                        ;     Child Loop BB0_1081 Depth 2
                                        ;     Child Loop BB0_1083 Depth 2
                                        ;     Child Loop BB0_1085 Depth 2
                                        ;     Child Loop BB0_1087 Depth 2
                                        ;     Child Loop BB0_1089 Depth 2
                                        ;     Child Loop BB0_1091 Depth 2
                                        ;     Child Loop BB0_1093 Depth 2
                                        ;     Child Loop BB0_1095 Depth 2
                                        ;     Child Loop BB0_1097 Depth 2
                                        ;     Child Loop BB0_1099 Depth 2
                                        ;     Child Loop BB0_1101 Depth 2
                                        ;     Child Loop BB0_1103 Depth 2
                                        ;     Child Loop BB0_1105 Depth 2
                                        ;     Child Loop BB0_1107 Depth 2
                                        ;     Child Loop BB0_1109 Depth 2
                                        ;     Child Loop BB0_1111 Depth 2
                                        ;     Child Loop BB0_1113 Depth 2
                                        ;     Child Loop BB0_1115 Depth 2
                                        ;     Child Loop BB0_1117 Depth 2
                                        ;     Child Loop BB0_1119 Depth 2
                                        ;     Child Loop BB0_1121 Depth 2
                                        ;     Child Loop BB0_1123 Depth 2
                                        ;     Child Loop BB0_1125 Depth 2
                                        ;     Child Loop BB0_1127 Depth 2
                                        ;     Child Loop BB0_1129 Depth 2
                                        ;     Child Loop BB0_1131 Depth 2
                                        ;     Child Loop BB0_1133 Depth 2
                                        ;     Child Loop BB0_1135 Depth 2
                                        ;     Child Loop BB0_1137 Depth 2
                                        ;     Child Loop BB0_1139 Depth 2
                                        ;     Child Loop BB0_1141 Depth 2
                                        ;     Child Loop BB0_1143 Depth 2
                                        ;     Child Loop BB0_1145 Depth 2
                                        ;     Child Loop BB0_1147 Depth 2
                                        ;     Child Loop BB0_1149 Depth 2
                                        ;     Child Loop BB0_1151 Depth 2
                                        ;     Child Loop BB0_1153 Depth 2
                                        ;     Child Loop BB0_1155 Depth 2
                                        ;     Child Loop BB0_1157 Depth 2
                                        ;     Child Loop BB0_1159 Depth 2
                                        ;     Child Loop BB0_1161 Depth 2
                                        ;     Child Loop BB0_1163 Depth 2
                                        ;     Child Loop BB0_1165 Depth 2
                                        ;     Child Loop BB0_1167 Depth 2
                                        ;     Child Loop BB0_1169 Depth 2
                                        ;     Child Loop BB0_1171 Depth 2
                                        ;     Child Loop BB0_1173 Depth 2
                                        ;     Child Loop BB0_1175 Depth 2
                                        ;     Child Loop BB0_1177 Depth 2
                                        ;     Child Loop BB0_1179 Depth 2
                                        ;     Child Loop BB0_1181 Depth 2
                                        ;     Child Loop BB0_1183 Depth 2
                                        ;     Child Loop BB0_1185 Depth 2
                                        ;     Child Loop BB0_1187 Depth 2
                                        ;     Child Loop BB0_1189 Depth 2
                                        ;     Child Loop BB0_1191 Depth 2
                                        ;     Child Loop BB0_1193 Depth 2
                                        ;     Child Loop BB0_1195 Depth 2
                                        ;     Child Loop BB0_1197 Depth 2
                                        ;     Child Loop BB0_1199 Depth 2
                                        ;     Child Loop BB0_1201 Depth 2
                                        ;     Child Loop BB0_1203 Depth 2
                                        ;     Child Loop BB0_1205 Depth 2
                                        ;     Child Loop BB0_1207 Depth 2
                                        ;     Child Loop BB0_1209 Depth 2
                                        ;     Child Loop BB0_1211 Depth 2
                                        ;     Child Loop BB0_1213 Depth 2
                                        ;     Child Loop BB0_1215 Depth 2
                                        ;     Child Loop BB0_1217 Depth 2
                                        ;     Child Loop BB0_1219 Depth 2
                                        ;     Child Loop BB0_1221 Depth 2
                                        ;     Child Loop BB0_1223 Depth 2
	mov	x12, #0                         ; =0x0
	mov	x30, #0                         ; =0x0
	lsl	x15, x11, #4
	ldr	q13, [sp, #12640]               ; 16-byte Reload
	ldr	q8, [sp, #12624]                ; 16-byte Reload
	ldr	q10, [sp, #12608]               ; 16-byte Reload
	b	LBB0_1028
LBB0_1027:                              ; %else6330
                                        ;   in Loop: Header=BB0_1028 Depth=2
	add	x16, x8, x30, lsl #5
	ldp	q2, q3, [x16]
	bif.16b	v1, v3, v15
	bif.16b	v0, v2, v14
	stp	q0, q1, [x16]
	add	x30, x30, #1
	add	x12, x12, #4
	cmp	x12, #1, lsl #12                ; =4096
	b.eq	LBB0_1044
LBB0_1028:                              ; %direct.true490
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w16, s19
	orr	x17, x15, x30, lsr #6
	and	x0, x12, #0xfc
	orr	x17, x0, x17, lsl #8
	dup.2d	v2, x17
	ldr	q0, [sp, #11936]                ; 16-byte Reload
	orr.16b	v0, v2, v0
	dup.2d	v3, x13
	add.2d	v4, v3, v0
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	tbnz	w16, #0, LBB0_1036
; %bb.1029:                             ; %else6288
                                        ;   in Loop: Header=BB0_1028 Depth=2
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_1037
LBB0_1030:                              ; %else6294
                                        ;   in Loop: Header=BB0_1028 Depth=2
	orr.16b	v4, v2, v16
	add.2d	v4, v3, v4
	tbnz	w16, #2, LBB0_1038
LBB0_1031:                              ; %else6300
                                        ;   in Loop: Header=BB0_1028 Depth=2
	tbnz	w16, #3, LBB0_1039
LBB0_1032:                              ; %else6306
                                        ;   in Loop: Header=BB0_1028 Depth=2
	orr.16b	v4, v2, v9
	add.2d	v4, v3, v4
	tbnz	w16, #4, LBB0_1040
LBB0_1033:                              ; %else6312
                                        ;   in Loop: Header=BB0_1028 Depth=2
	tbnz	w16, #5, LBB0_1041
LBB0_1034:                              ; %else6318
                                        ;   in Loop: Header=BB0_1028 Depth=2
	ldr	q4, [sp, #11920]                ; 16-byte Reload
	orr.16b	v2, v2, v4
	add.2d	v2, v3, v2
	tbnz	w16, #6, LBB0_1042
LBB0_1035:                              ; %else6324
                                        ;   in Loop: Header=BB0_1028 Depth=2
	tbz	w16, #7, LBB0_1027
	b	LBB0_1043
LBB0_1036:                              ; %cond.load6284
                                        ;   in Loop: Header=BB0_1028 Depth=2
	fmov	x17, d4
	ldr	s0, [x17]
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_1030
LBB0_1037:                              ; %cond.load6290
                                        ;   in Loop: Header=BB0_1028 Depth=2
	mov.d	x17, v4[1]
	ld1.s	{ v0 }[1], [x17]
	orr.16b	v4, v2, v16
	add.2d	v4, v3, v4
	tbz	w16, #2, LBB0_1031
LBB0_1038:                              ; %cond.load6296
                                        ;   in Loop: Header=BB0_1028 Depth=2
	fmov	x17, d4
	ld1.s	{ v0 }[2], [x17]
	tbz	w16, #3, LBB0_1032
LBB0_1039:                              ; %cond.load6302
                                        ;   in Loop: Header=BB0_1028 Depth=2
	mov.d	x17, v4[1]
	ld1.s	{ v0 }[3], [x17]
	orr.16b	v4, v2, v9
	add.2d	v4, v3, v4
	tbz	w16, #4, LBB0_1033
LBB0_1040:                              ; %cond.load6308
                                        ;   in Loop: Header=BB0_1028 Depth=2
	fmov	x17, d4
	ld1.s	{ v1 }[0], [x17]
	tbz	w16, #5, LBB0_1034
LBB0_1041:                              ; %cond.load6314
                                        ;   in Loop: Header=BB0_1028 Depth=2
	mov.d	x17, v4[1]
	ld1.s	{ v1 }[1], [x17]
	ldr	q4, [sp, #11920]                ; 16-byte Reload
	orr.16b	v2, v2, v4
	add.2d	v2, v3, v2
	tbz	w16, #6, LBB0_1035
LBB0_1042:                              ; %cond.load6320
                                        ;   in Loop: Header=BB0_1028 Depth=2
	fmov	x17, d2
	ld1.s	{ v1 }[2], [x17]
	tbz	w16, #7, LBB0_1027
LBB0_1043:                              ; %cond.load6326
                                        ;   in Loop: Header=BB0_1028 Depth=2
	mov.d	x16, v2[1]
	ld1.s	{ v1 }[3], [x16]
	b	LBB0_1027
LBB0_1044:                              ; %direct.true507.preheader
                                        ;   in Loop: Header=BB0_1026 Depth=1
	mov	x12, #0                         ; =0x0
	mov	x30, #0                         ; =0x0
	str	q24, [sp, #11824]               ; 16-byte Spill
	b	LBB0_1046
LBB0_1045:                              ; %else6379
                                        ;   in Loop: Header=BB0_1046 Depth=2
	add	x16, x9, x30, lsl #5
	ldp	q2, q3, [x16]
	bif.16b	v1, v3, v15
	bif.16b	v0, v2, v14
	stp	q0, q1, [x16]
	add	x30, x30, #1
	add	x12, x12, #4
	cmp	x12, #1, lsl #12                ; =4096
	b.eq	LBB0_1062
LBB0_1046:                              ; %direct.true507
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w16, s19
	orr	x17, x15, x30, lsr #6
	and	x0, x12, #0xfc
	orr	x17, x0, x17, lsl #8
	dup.2d	v2, x17
	ldr	q0, [sp, #11936]                ; 16-byte Reload
	orr.16b	v0, v2, v0
	dup.2d	v3, x14
	add.2d	v4, v3, v0
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	tbnz	w16, #0, LBB0_1054
; %bb.1047:                             ; %else6337
                                        ;   in Loop: Header=BB0_1046 Depth=2
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_1055
LBB0_1048:                              ; %else6343
                                        ;   in Loop: Header=BB0_1046 Depth=2
	orr.16b	v4, v2, v16
	add.2d	v4, v3, v4
	tbnz	w16, #2, LBB0_1056
LBB0_1049:                              ; %else6349
                                        ;   in Loop: Header=BB0_1046 Depth=2
	tbnz	w16, #3, LBB0_1057
LBB0_1050:                              ; %else6355
                                        ;   in Loop: Header=BB0_1046 Depth=2
	orr.16b	v4, v2, v9
	add.2d	v4, v3, v4
	tbnz	w16, #4, LBB0_1058
LBB0_1051:                              ; %else6361
                                        ;   in Loop: Header=BB0_1046 Depth=2
	tbnz	w16, #5, LBB0_1059
LBB0_1052:                              ; %else6367
                                        ;   in Loop: Header=BB0_1046 Depth=2
	ldr	q4, [sp, #13984]                ; 16-byte Reload
	ldr	q24, [sp, #11920]               ; 16-byte Reload
	orr.16b	v2, v2, v24
	add.2d	v2, v3, v2
	tbnz	w16, #6, LBB0_1060
LBB0_1053:                              ; %else6373
                                        ;   in Loop: Header=BB0_1046 Depth=2
	tbz	w16, #7, LBB0_1045
	b	LBB0_1061
LBB0_1054:                              ; %cond.load6333
                                        ;   in Loop: Header=BB0_1046 Depth=2
	fmov	x17, d4
	ldr	s0, [x17]
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_1048
LBB0_1055:                              ; %cond.load6339
                                        ;   in Loop: Header=BB0_1046 Depth=2
	mov.d	x17, v4[1]
	ld1.s	{ v0 }[1], [x17]
	orr.16b	v4, v2, v16
	add.2d	v4, v3, v4
	tbz	w16, #2, LBB0_1049
LBB0_1056:                              ; %cond.load6345
                                        ;   in Loop: Header=BB0_1046 Depth=2
	fmov	x17, d4
	ld1.s	{ v0 }[2], [x17]
	tbz	w16, #3, LBB0_1050
LBB0_1057:                              ; %cond.load6351
                                        ;   in Loop: Header=BB0_1046 Depth=2
	mov.d	x17, v4[1]
	ld1.s	{ v0 }[3], [x17]
	orr.16b	v4, v2, v9
	add.2d	v4, v3, v4
	tbz	w16, #4, LBB0_1051
LBB0_1058:                              ; %cond.load6357
                                        ;   in Loop: Header=BB0_1046 Depth=2
	fmov	x17, d4
	ld1.s	{ v1 }[0], [x17]
	tbz	w16, #5, LBB0_1052
LBB0_1059:                              ; %cond.load6363
                                        ;   in Loop: Header=BB0_1046 Depth=2
	mov.d	x17, v4[1]
	ld1.s	{ v1 }[1], [x17]
	ldr	q4, [sp, #13984]                ; 16-byte Reload
	ldr	q24, [sp, #11920]               ; 16-byte Reload
	orr.16b	v2, v2, v24
	add.2d	v2, v3, v2
	tbz	w16, #6, LBB0_1053
LBB0_1060:                              ; %cond.load6369
                                        ;   in Loop: Header=BB0_1046 Depth=2
	fmov	x17, d2
	ld1.s	{ v1 }[2], [x17]
	tbz	w16, #7, LBB0_1045
LBB0_1061:                              ; %cond.load6375
                                        ;   in Loop: Header=BB0_1046 Depth=2
	mov.d	x16, v2[1]
	ld1.s	{ v1 }[3], [x16]
	b	LBB0_1045
LBB0_1062:                              ; %direct.false508
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q21, [sp, #7168]                ; 16-byte Spill
	str	q22, [sp, #7184]                ; 16-byte Spill
	mov	x30, #0                         ; =0x0
	ldr	q0, [sp, #4976]                 ; 16-byte Reload
	cmhs.4s	v2, v28, v0
	ldr	q1, [sp, #9312]                 ; 16-byte Reload
	str	q2, [sp, #11888]                ; 16-byte Spill
	and.16b	v7, v2, v1
	cmhs.4s	v0, v29, v0
	ldr	q9, [sp, #9328]                 ; 16-byte Reload
	str	q0, [sp, #11872]                ; 16-byte Spill
	and.16b	v9, v0, v9
	ldr	q1, [sp, #12320]                ; 16-byte Reload
	ldr	q12, [sp, #12880]               ; 16-byte Reload
	ldr	q19, [sp, #12560]               ; 16-byte Reload
	ldr	q18, [sp, #12848]               ; 16-byte Reload
	ldr	q21, [sp, #12768]               ; 16-byte Reload
	str	q4, [sp, #13984]                ; 16-byte Spill
	ldr	q29, [sp, #12752]               ; 16-byte Reload
	ldr	q31, [sp, #12544]               ; 16-byte Reload
	ldr	q27, [sp, #12736]               ; 16-byte Reload
	ldr	q28, [sp, #12528]               ; 16-byte Reload
	ldr	q3, [sp, #12816]                ; 16-byte Reload
	ldr	q22, [sp, #12720]               ; 16-byte Reload
	ldr	q16, [sp, #12512]               ; 16-byte Reload
	ldr	q23, [sp, #12704]               ; 16-byte Reload
	ldr	q25, [sp, #12496]               ; 16-byte Reload
	ldr	q24, [sp, #12688]               ; 16-byte Reload
	ldr	q17, [sp, #12480]               ; 16-byte Reload
	ldr	q11, [sp, #12080]               ; 16-byte Reload
	ldr	q20, [sp, #12304]               ; 16-byte Reload
	mov.16b	v5, v8
	mov.16b	v8, v1
	mov.16b	v6, v10
	ldr	q10, [sp, #12384]               ; 16-byte Reload
LBB0_1063:                              ; %direct.true528
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x30, #0
	cset	w12, eq
	dup.4h	v0, w12
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	ldr	q1, [sp, #12048]                ; 16-byte Reload
	and.16b	v1, v0, v1
	cmp	x30, #32
	cset	w12, eq
	dup.4h	v2, w12
	and.16b	v0, v0, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #64
	cset	w12, eq
	ldr	q4, [sp, #12032]                ; 16-byte Reload
	bit.16b	v0, v4, v2
	mov.16b	v4, v3
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q26, [sp, #12448]               ; 16-byte Reload
	bit.16b	v1, v26, v2
	ldr	q2, [sp, #12656]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #96
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q26, [sp, #12672]               ; 16-byte Reload
	bit.16b	v0, v26, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #128
	cset	w12, eq
	ldr	q3, [sp, #12912]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q26, [sp, #13936]               ; 16-byte Reload
	bit.16b	v1, v26, v2
	ldr	q2, [sp, #13904]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #160
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q26, [sp, #13920]               ; 16-byte Reload
	bit.16b	v0, v26, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #192
	cset	w12, eq
	ldr	q3, [sp, #13888]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q26, [sp, #13872]               ; 16-byte Reload
	bit.16b	v1, v26, v2
	ldr	q2, [sp, #13856]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #224
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v20, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #256
	cset	w12, eq
	ldr	q3, [sp, #13840]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q26, [sp, #13824]               ; 16-byte Reload
	bit.16b	v1, v26, v2
	bit.16b	v1, v11, v3
	cmp	x30, #288
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q26, [sp, #13808]               ; 16-byte Reload
	bit.16b	v0, v26, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #320
	cset	w12, eq
	bit.16b	v0, v10, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v13, v2
	bit.16b	v1, v6, v3
	cmp	x30, #352
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v5, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #384
	cset	w12, eq
	ldr	q3, [sp, #13984]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q26, [sp, #13968]               ; 16-byte Reload
	bit.16b	v1, v26, v2
	ldr	q2, [sp, #12928]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #416
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q26, [sp, #13952]               ; 16-byte Reload
	bit.16b	v0, v26, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #448
	cset	w12, eq
	ldr	q3, [sp, #12288]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q26, [sp, #12272]               ; 16-byte Reload
	bit.16b	v1, v26, v2
	ldr	q2, [sp, #12240]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #480
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q26, [sp, #12256]               ; 16-byte Reload
	bit.16b	v0, v26, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #512
	cset	w12, eq
	ldr	q3, [sp, #12224]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q26, [sp, #12096]               ; 16-byte Reload
	bit.16b	v1, v26, v2
	ldr	q2, [sp, #12192]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #544
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q26, [sp, #12208]               ; 16-byte Reload
	bit.16b	v0, v26, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #576
	cset	w12, eq
	ldr	q3, [sp, #12592]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q26, [sp, #12176]               ; 16-byte Reload
	bit.16b	v1, v26, v2
	ldr	q2, [sp, #12016]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #608
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q26, [sp, #12432]               ; 16-byte Reload
	bit.16b	v0, v26, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #640
	cset	w12, eq
	ldr	q3, [sp, #12000]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q26, [sp, #11984]               ; 16-byte Reload
	bit.16b	v1, v26, v2
	ldr	q2, [sp, #11952]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #672
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q26, [sp, #11968]               ; 16-byte Reload
	bit.16b	v0, v26, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #704
	cset	w12, eq
	ldr	q3, [sp, #12144]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q26, [sp, #12160]               ; 16-byte Reload
	bit.16b	v1, v26, v2
	ldr	q2, [sp, #12112]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #736
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q26, [sp, #12128]               ; 16-byte Reload
	bit.16b	v0, v26, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #768
	cset	w12, eq
	bit.16b	v0, v8, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q26, [sp, #12416]               ; 16-byte Reload
	bit.16b	v1, v26, v2
	ldr	q2, [sp, #12368]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #800
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q26, [sp, #12400]               ; 16-byte Reload
	bit.16b	v0, v26, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #832
	cset	w12, eq
	ldr	q3, [sp, #12064]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q26, [sp, #12464]               ; 16-byte Reload
	bit.16b	v1, v26, v2
	ldr	q2, [sp, #12800]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #864
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q26, [sp, #12352]               ; 16-byte Reload
	bit.16b	v0, v26, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #896
	cset	w12, eq
	ldr	q3, [sp, #12336]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q26, [sp, #12784]               ; 16-byte Reload
	bit.16b	v1, v26, v2
	ldr	q2, [sp, #12960]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #928
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q26, [sp, #12576]               ; 16-byte Reload
	bit.16b	v0, v26, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #960
	cset	w12, eq
	ldr	q3, [sp, #12896]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q26, [sp, #12944]               ; 16-byte Reload
	bit.16b	v1, v26, v2
	ldr	q2, [sp, #13792]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #992
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v12, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1024
	cset	w12, eq
	ldr	q3, [sp, #13776]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	mov.16b	v30, v19
	ldr	q19, [sp, #13760]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	mov.16b	v19, v30
	ldr	q2, [sp, #12864]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1056
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v30, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1088
	cset	w12, eq
	ldr	q3, [sp, #13744]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	mov.16b	v26, v21
	mov.16b	v21, v18
	ldr	q18, [sp, #13728]               ; 16-byte Reload
	bit.16b	v1, v18, v2
	mov.16b	v18, v21
	mov.16b	v21, v26
	bit.16b	v1, v26, v3
	cmp	x30, #1120
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1152
	cset	w12, eq
	ldr	q3, [sp, #12832]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v29, v2
	bit.16b	v1, v27, v3
	cmp	x30, #1184
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v31, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1216
	cset	w12, eq
	bit.16b	v0, v28, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v22, v2
	bit.16b	v1, v23, v3
	cmp	x30, #1248
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v16, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1280
	cset	w12, eq
	bit.16b	v0, v25, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v24, v2
	ldr	q2, [sp, #13712]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1312
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1344
	cset	w12, eq
	ldr	q3, [sp, #13696]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q26, [sp, #13680]               ; 16-byte Reload
	bit.16b	v1, v26, v2
	ldr	q2, [sp, #13648]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1376
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q26, [sp, #13664]               ; 16-byte Reload
	bit.16b	v0, v26, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1408
	cset	w12, eq
	ldr	q3, [sp, #13632]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q26, [sp, #13616]               ; 16-byte Reload
	bit.16b	v1, v26, v2
	ldr	q2, [sp, #13584]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1440
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q26, [sp, #13600]               ; 16-byte Reload
	bit.16b	v0, v26, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1472
	cset	w12, eq
	ldr	q3, [sp, #13568]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q26, [sp, #13552]               ; 16-byte Reload
	bit.16b	v1, v26, v2
	ldr	q2, [sp, #13520]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1504
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q26, [sp, #13536]               ; 16-byte Reload
	bit.16b	v0, v26, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1536
	cset	w12, eq
	ldr	q3, [sp, #13504]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q26, [sp, #13488]               ; 16-byte Reload
	bit.16b	v1, v26, v2
	ldr	q2, [sp, #13456]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1568
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q26, [sp, #13472]               ; 16-byte Reload
	bit.16b	v0, v26, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1600
	cset	w12, eq
	ldr	q3, [sp, #13440]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q26, [sp, #13424]               ; 16-byte Reload
	bit.16b	v1, v26, v2
	ldr	q2, [sp, #13392]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1632
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q26, [sp, #13408]               ; 16-byte Reload
	bit.16b	v0, v26, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1664
	cset	w12, eq
	ldr	q3, [sp, #13376]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q26, [sp, #13360]               ; 16-byte Reload
	bit.16b	v1, v26, v2
	ldr	q2, [sp, #13328]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1696
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q26, [sp, #13344]               ; 16-byte Reload
	bit.16b	v0, v26, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1728
	cset	w12, eq
	ldr	q3, [sp, #13312]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q26, [sp, #13296]               ; 16-byte Reload
	bit.16b	v1, v26, v2
	ldr	q2, [sp, #13264]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1760
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q26, [sp, #13280]               ; 16-byte Reload
	bit.16b	v0, v26, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1792
	cset	w12, eq
	ldr	q3, [sp, #13248]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q26, [sp, #13232]               ; 16-byte Reload
	bit.16b	v1, v26, v2
	ldr	q2, [sp, #13200]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1824
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q26, [sp, #13216]               ; 16-byte Reload
	bit.16b	v0, v26, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1856
	cset	w12, eq
	ldr	q3, [sp, #13184]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q26, [sp, #13168]               ; 16-byte Reload
	bit.16b	v1, v26, v2
	ldr	q2, [sp, #13136]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1888
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q26, [sp, #13152]               ; 16-byte Reload
	bit.16b	v0, v26, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1920
	cset	w12, eq
	ldr	q3, [sp, #13120]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q26, [sp, #13104]               ; 16-byte Reload
	bit.16b	v1, v26, v2
	ldr	q2, [sp, #13072]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1952
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q26, [sp, #13088]               ; 16-byte Reload
	bit.16b	v0, v26, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1984
	cset	w12, eq
	ldr	q3, [sp, #13056]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q26, [sp, #13040]               ; 16-byte Reload
	bit.16b	v1, v26, v2
	ldr	q2, [sp, #13008]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #2016
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q26, [sp, #13024]               ; 16-byte Reload
	bit.16b	v0, v26, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #12992]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	add	x12, x8, x30
	ldr	q3, [sp, #12976]                ; 16-byte Reload
	bit.16b	v1, v3, v2
	ldp	q3, q2, [x12]
	and.16b	v2, v15, v2
	fmul.4s	v1, v1, v2
	and.16b	v2, v14, v3
	mov.16b	v3, v4
	fmul.4s	v0, v0, v2
	fadd.4s	v1, v7, v1
	bit.16b	v7, v1, v15
	fadd.4s	v0, v9, v0
	bit.16b	v9, v0, v14
	add	x30, x30, #32
	cmp	x30, #2048
	b.ne	LBB0_1063
; %bb.1064:                             ; %direct.false529
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q7, [sp, #9312]                 ; 16-byte Spill
	str	q9, [sp, #9328]                 ; 16-byte Spill
	ldr	q12, [sp, #9344]                ; 16-byte Reload
	ldr	q0, [sp, #11888]                ; 16-byte Reload
	and.16b	v12, v0, v12
	ldr	q11, [sp, #9360]                ; 16-byte Reload
	ldr	q0, [sp, #11872]                ; 16-byte Reload
	and.16b	v11, v0, v11
	ldr	q20, [sp, #9728]                ; 16-byte Reload
	ldr	q7, [sp, #9520]                 ; 16-byte Reload
	str	q8, [sp, #12320]                ; 16-byte Spill
	ldr	q8, [sp, #9456]                 ; 16-byte Reload
	ldr	q10, [sp, #9424]                ; 16-byte Reload
	ldr	q9, [sp, #9392]                 ; 16-byte Reload
	ldr	q26, [sp, #12832]               ; 16-byte Reload
LBB0_1065:                              ; %direct.true730
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x30, #2048
	cset	w12, eq
	dup.4h	v0, w12
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	ldr	q1, [sp, #12048]                ; 16-byte Reload
	and.16b	v1, v0, v1
	cmp	x30, #2080
	cset	w12, eq
	dup.4h	v2, w12
	and.16b	v0, v0, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #2112
	cset	w12, eq
	ldr	q3, [sp, #12032]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q18, [sp, #12448]               ; 16-byte Reload
	bit.16b	v1, v18, v2
	ldr	q2, [sp, #12656]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #2144
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q18, [sp, #12672]               ; 16-byte Reload
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #2176
	cset	w12, eq
	ldr	q3, [sp, #12912]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q18, [sp, #13936]               ; 16-byte Reload
	bit.16b	v1, v18, v2
	ldr	q2, [sp, #13904]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #2208
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q18, [sp, #13920]               ; 16-byte Reload
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #2240
	cset	w12, eq
	ldr	q3, [sp, #13888]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q18, [sp, #13872]               ; 16-byte Reload
	bit.16b	v1, v18, v2
	ldr	q2, [sp, #13856]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #2272
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q18, [sp, #12304]               ; 16-byte Reload
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #2304
	cset	w12, eq
	ldr	q3, [sp, #13840]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q18, [sp, #13824]               ; 16-byte Reload
	bit.16b	v1, v18, v2
	ldr	q2, [sp, #12080]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #2336
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q18, [sp, #13808]               ; 16-byte Reload
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #2368
	cset	w12, eq
	ldr	q3, [sp, #12384]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v13, v2
	bit.16b	v1, v6, v3
	cmp	x30, #2400
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v5, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #2432
	cset	w12, eq
	ldr	q3, [sp, #13984]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q18, [sp, #13968]               ; 16-byte Reload
	bit.16b	v1, v18, v2
	ldr	q2, [sp, #12928]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #2464
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q18, [sp, #13952]               ; 16-byte Reload
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #2496
	cset	w12, eq
	ldr	q3, [sp, #12288]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q18, [sp, #12272]               ; 16-byte Reload
	bit.16b	v1, v18, v2
	ldr	q2, [sp, #12240]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #2528
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q18, [sp, #12256]               ; 16-byte Reload
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #2560
	cset	w12, eq
	ldr	q3, [sp, #12224]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q18, [sp, #12096]               ; 16-byte Reload
	bit.16b	v1, v18, v2
	ldr	q2, [sp, #12192]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #2592
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q18, [sp, #12208]               ; 16-byte Reload
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #2624
	cset	w12, eq
	ldr	q3, [sp, #12592]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q18, [sp, #12176]               ; 16-byte Reload
	bit.16b	v1, v18, v2
	ldr	q2, [sp, #12016]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #2656
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q18, [sp, #12432]               ; 16-byte Reload
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #2688
	cset	w12, eq
	ldr	q3, [sp, #12000]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q18, [sp, #11984]               ; 16-byte Reload
	bit.16b	v1, v18, v2
	ldr	q2, [sp, #11952]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #2720
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q18, [sp, #11968]               ; 16-byte Reload
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #2752
	cset	w12, eq
	ldr	q3, [sp, #12144]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q18, [sp, #12160]               ; 16-byte Reload
	bit.16b	v1, v18, v2
	ldr	q2, [sp, #12112]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #2784
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q18, [sp, #12128]               ; 16-byte Reload
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #2816
	cset	w12, eq
	ldr	q3, [sp, #12320]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q18, [sp, #12416]               ; 16-byte Reload
	bit.16b	v1, v18, v2
	ldr	q2, [sp, #12368]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #2848
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q18, [sp, #12400]               ; 16-byte Reload
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #2880
	cset	w12, eq
	ldr	q3, [sp, #12064]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q18, [sp, #12464]               ; 16-byte Reload
	bit.16b	v1, v18, v2
	ldr	q2, [sp, #12800]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #2912
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q18, [sp, #12352]               ; 16-byte Reload
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #2944
	cset	w12, eq
	ldr	q3, [sp, #12336]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q18, [sp, #12784]               ; 16-byte Reload
	bit.16b	v1, v18, v2
	ldr	q2, [sp, #12960]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #2976
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q18, [sp, #12576]               ; 16-byte Reload
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #3008
	cset	w12, eq
	ldr	q3, [sp, #12896]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q18, [sp, #12944]               ; 16-byte Reload
	bit.16b	v1, v18, v2
	ldr	q2, [sp, #13792]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #3040
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q18, [sp, #12880]               ; 16-byte Reload
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #3072
	cset	w12, eq
	ldr	q3, [sp, #13776]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13760]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12864]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #3104
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v30, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #3136
	cset	w12, eq
	ldr	q3, [sp, #13744]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q18, [sp, #13728]               ; 16-byte Reload
	bit.16b	v1, v18, v2
	bit.16b	v1, v21, v3
	cmp	x30, #3168
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q18, [sp, #12848]               ; 16-byte Reload
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #3200
	cset	w12, eq
	bit.16b	v0, v26, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v29, v2
	bit.16b	v1, v27, v3
	cmp	x30, #3232
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v31, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #3264
	cset	w12, eq
	bit.16b	v0, v28, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v22, v2
	bit.16b	v1, v23, v3
	cmp	x30, #3296
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v16, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #3328
	cset	w12, eq
	bit.16b	v0, v25, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v24, v2
	ldr	q2, [sp, #13712]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #3360
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #3392
	cset	w12, eq
	ldr	q3, [sp, #13696]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q18, [sp, #13680]               ; 16-byte Reload
	bit.16b	v1, v18, v2
	ldr	q2, [sp, #13648]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #3424
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q18, [sp, #13664]               ; 16-byte Reload
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #3456
	cset	w12, eq
	ldr	q3, [sp, #13632]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q18, [sp, #13616]               ; 16-byte Reload
	bit.16b	v1, v18, v2
	ldr	q2, [sp, #13584]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #3488
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q18, [sp, #13600]               ; 16-byte Reload
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #3520
	cset	w12, eq
	ldr	q3, [sp, #13568]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q18, [sp, #13552]               ; 16-byte Reload
	bit.16b	v1, v18, v2
	ldr	q2, [sp, #13520]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #3552
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q18, [sp, #13536]               ; 16-byte Reload
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #3584
	cset	w12, eq
	ldr	q3, [sp, #13504]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q18, [sp, #13488]               ; 16-byte Reload
	bit.16b	v1, v18, v2
	ldr	q2, [sp, #13456]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #3616
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q18, [sp, #13472]               ; 16-byte Reload
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #3648
	cset	w12, eq
	ldr	q3, [sp, #13440]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q18, [sp, #13424]               ; 16-byte Reload
	bit.16b	v1, v18, v2
	ldr	q2, [sp, #13392]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #3680
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q18, [sp, #13408]               ; 16-byte Reload
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #3712
	cset	w12, eq
	ldr	q3, [sp, #13376]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q18, [sp, #13360]               ; 16-byte Reload
	bit.16b	v1, v18, v2
	ldr	q2, [sp, #13328]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #3744
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q18, [sp, #13344]               ; 16-byte Reload
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #3776
	cset	w12, eq
	ldr	q3, [sp, #13312]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q18, [sp, #13296]               ; 16-byte Reload
	bit.16b	v1, v18, v2
	ldr	q2, [sp, #13264]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #3808
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q18, [sp, #13280]               ; 16-byte Reload
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #3840
	cset	w12, eq
	ldr	q3, [sp, #13248]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q18, [sp, #13232]               ; 16-byte Reload
	bit.16b	v1, v18, v2
	ldr	q2, [sp, #13200]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #3872
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q18, [sp, #13216]               ; 16-byte Reload
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #3904
	cset	w12, eq
	ldr	q3, [sp, #13184]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q18, [sp, #13168]               ; 16-byte Reload
	bit.16b	v1, v18, v2
	ldr	q2, [sp, #13136]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #3936
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q18, [sp, #13152]               ; 16-byte Reload
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #3968
	cset	w12, eq
	ldr	q3, [sp, #13120]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q18, [sp, #13104]               ; 16-byte Reload
	bit.16b	v1, v18, v2
	ldr	q2, [sp, #13072]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #4000
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q18, [sp, #13088]               ; 16-byte Reload
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #4032
	cset	w12, eq
	ldr	q3, [sp, #13056]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q18, [sp, #13040]               ; 16-byte Reload
	bit.16b	v1, v18, v2
	ldr	q2, [sp, #13008]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #4064
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q18, [sp, #13024]               ; 16-byte Reload
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #12992]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	add	x12, x8, x30
	ldr	q3, [sp, #12976]                ; 16-byte Reload
	bit.16b	v1, v3, v2
	ldp	q3, q2, [x12]
	and.16b	v2, v15, v2
	fmul.4s	v1, v1, v2
	and.16b	v2, v14, v3
	mov.16b	v3, v4
	fmul.4s	v0, v0, v2
	fadd.4s	v1, v12, v1
	bit.16b	v12, v1, v15
	fadd.4s	v0, v11, v0
	bit.16b	v11, v0, v14
	add	x30, x30, #32
	cmp	x30, #1, lsl #12                ; =4096
	b.ne	LBB0_1065
; %bb.1066:                             ; %direct.false731
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q12, [sp, #9344]                ; 16-byte Spill
	str	q11, [sp, #9360]                ; 16-byte Spill
	ldr	q11, [sp, #9376]                ; 16-byte Reload
	ldr	q0, [sp, #11888]                ; 16-byte Reload
	and.16b	v11, v0, v11
	ldr	q0, [sp, #11872]                ; 16-byte Reload
	and.16b	v9, v0, v9
	str	q3, [sp, #12816]                ; 16-byte Spill
	ldr	q1, [sp, #12048]                ; 16-byte Reload
	ldr	q3, [sp, #12032]                ; 16-byte Reload
	ldr	q30, [sp, #12288]               ; 16-byte Reload
	ldr	q26, [sp, #12272]               ; 16-byte Reload
	str	q29, [sp, #12752]               ; 16-byte Spill
	ldr	q29, [sp, #12256]               ; 16-byte Reload
	ldr	q31, [sp, #12240]               ; 16-byte Reload
	str	q27, [sp, #12736]               ; 16-byte Spill
	ldr	q27, [sp, #12224]               ; 16-byte Reload
	ldr	q28, [sp, #12096]               ; 16-byte Reload
	str	q21, [sp, #12768]               ; 16-byte Spill
	ldr	q6, [sp, #12208]                ; 16-byte Reload
	str	q22, [sp, #12720]               ; 16-byte Spill
	ldr	q5, [sp, #12192]                ; 16-byte Reload
	ldr	q16, [sp, #12176]               ; 16-byte Reload
	str	q23, [sp, #12704]               ; 16-byte Spill
	ldr	q23, [sp, #12016]               ; 16-byte Reload
	ldr	q25, [sp, #12000]               ; 16-byte Reload
	str	q24, [sp, #12688]               ; 16-byte Spill
	ldr	q24, [sp, #11984]               ; 16-byte Reload
	ldr	q12, [sp, #11968]               ; 16-byte Reload
	ldr	q13, [sp, #11952]               ; 16-byte Reload
	ldr	q17, [sp, #12160]               ; 16-byte Reload
	ldr	q21, [sp, #12112]               ; 16-byte Reload
	ldr	q18, [sp, #12864]               ; 16-byte Reload
LBB0_1067:                              ; %direct.true934
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	subs	x12, x30, #1, lsl #12           ; =4096
	cset	w15, eq
	dup.4h	v0, w15
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	mov.16b	v4, v1
	and.16b	v1, v0, v1
	cmp	x12, #32
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12816]               ; 16-byte Reload
	and.16b	v0, v0, v19
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #64
	cset	w15, eq
	bit.16b	v0, v3, v2
	mov.16b	v22, v3
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12448]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12656]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #96
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12672]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #128
	cset	w15, eq
	ldr	q3, [sp, #12912]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13936]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13904]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #160
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13920]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #192
	cset	w15, eq
	ldr	q3, [sp, #13888]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13872]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13856]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #224
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12304]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #256
	cset	w15, eq
	ldr	q3, [sp, #13840]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13824]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12080]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #288
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13808]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #320
	cset	w15, eq
	ldr	q3, [sp, #12384]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12640]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12608]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #352
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12624]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #384
	cset	w15, eq
	ldr	q3, [sp, #13984]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13968]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12928]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #416
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13952]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #448
	cset	w15, eq
	bit.16b	v0, v30, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v26, v2
	bit.16b	v1, v31, v3
	cmp	x12, #480
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v29, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #512
	cset	w15, eq
	bit.16b	v0, v27, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v28, v2
	bit.16b	v1, v5, v3
	cmp	x12, #544
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v6, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #576
	cset	w15, eq
	ldr	q3, [sp, #12592]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v16, v2
	bit.16b	v1, v23, v3
	cmp	x12, #608
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12432]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #640
	cset	w15, eq
	bit.16b	v0, v25, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v24, v2
	bit.16b	v1, v13, v3
	cmp	x12, #672
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v12, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #704
	cset	w15, eq
	ldr	q3, [sp, #12144]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v17, v2
	bit.16b	v1, v21, v3
	cmp	x12, #736
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12128]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #768
	cset	w15, eq
	ldr	q3, [sp, #12320]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12416]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12368]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #800
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12400]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #832
	cset	w15, eq
	ldr	q3, [sp, #12064]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12464]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12800]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #864
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12352]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #896
	cset	w15, eq
	ldr	q3, [sp, #12336]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12784]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12960]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #928
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12576]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #960
	cset	w15, eq
	ldr	q3, [sp, #12896]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12944]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13792]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #992
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12880]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1024
	cset	w15, eq
	ldr	q3, [sp, #13776]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13760]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	bit.16b	v1, v18, v3
	cmp	x12, #1056
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12560]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1088
	cset	w15, eq
	ldr	q3, [sp, #13744]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13728]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12768]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1120
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12848]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1152
	cset	w15, eq
	ldr	q3, [sp, #12832]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12752]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12736]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1184
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12544]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1216
	cset	w15, eq
	ldr	q3, [sp, #12528]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12720]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12704]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1248
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12512]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1280
	cset	w15, eq
	ldr	q3, [sp, #12496]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12688]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13712]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1312
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12480]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1344
	cset	w15, eq
	ldr	q3, [sp, #13696]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13680]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13648]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1376
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13664]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1408
	cset	w15, eq
	ldr	q3, [sp, #13632]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13616]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13584]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1440
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13600]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1472
	cset	w15, eq
	ldr	q3, [sp, #13568]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13552]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13520]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1504
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13536]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1536
	cset	w15, eq
	ldr	q3, [sp, #13504]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13488]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13456]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1568
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13472]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1600
	cset	w15, eq
	ldr	q3, [sp, #13440]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13424]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13392]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1632
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13408]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1664
	cset	w15, eq
	ldr	q3, [sp, #13376]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13360]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13328]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1696
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13344]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1728
	cset	w15, eq
	ldr	q3, [sp, #13312]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13296]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13264]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1760
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13280]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1792
	cset	w15, eq
	ldr	q3, [sp, #13248]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13232]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13200]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1824
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13216]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1856
	cset	w15, eq
	ldr	q3, [sp, #13184]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13168]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13136]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1888
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13152]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1920
	cset	w15, eq
	ldr	q3, [sp, #13120]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13104]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13072]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1952
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13088]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1984
	cset	w15, eq
	ldr	q3, [sp, #13056]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13040]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13008]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #2016
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13024]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #12992]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	add	x12, x8, x30
	ldr	q3, [sp, #12976]                ; 16-byte Reload
	bit.16b	v1, v3, v2
	ldp	q3, q2, [x12]
	and.16b	v2, v15, v2
	fmul.4s	v1, v1, v2
	and.16b	v2, v14, v3
	mov.16b	v3, v22
	fmul.4s	v0, v0, v2
	fadd.4s	v1, v11, v1
	bit.16b	v11, v1, v15
	mov.16b	v1, v4
	fadd.4s	v0, v9, v0
	bit.16b	v9, v0, v14
	add	x30, x30, #32
	cmp	x30, x3
	b.ne	LBB0_1067
; %bb.1068:                             ; %direct.false935
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q11, [sp, #9376]                ; 16-byte Spill
	str	q9, [sp, #9392]                 ; 16-byte Spill
	mov	x30, #0                         ; =0x0
	ldr	q9, [sp, #9408]                 ; 16-byte Reload
	ldr	q0, [sp, #11888]                ; 16-byte Reload
	and.16b	v9, v0, v9
	ldr	q0, [sp, #11872]                ; 16-byte Reload
	and.16b	v10, v0, v10
	ldr	q19, [sp, #12080]               ; 16-byte Reload
	ldr	q18, [sp, #12064]               ; 16-byte Reload
LBB0_1069:                              ; %direct.true1138
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x30, #0
	cset	w12, eq
	dup.4h	v0, w12
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	and.16b	v1, v0, v4
	cmp	x30, #32
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12816]               ; 16-byte Reload
	and.16b	v0, v0, v11
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #64
	cset	w12, eq
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12448]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12656]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #96
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12672]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #128
	cset	w12, eq
	ldr	q3, [sp, #12912]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13936]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13904]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #160
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13920]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #192
	cset	w12, eq
	ldr	q3, [sp, #13888]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13872]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13856]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #224
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12304]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #256
	cset	w12, eq
	ldr	q3, [sp, #13840]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13824]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	bit.16b	v1, v19, v3
	cmp	x30, #288
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13808]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #320
	cset	w12, eq
	ldr	q3, [sp, #12384]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12640]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12608]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #352
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12624]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #384
	cset	w12, eq
	ldr	q3, [sp, #13984]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13968]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12928]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #416
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13952]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #448
	cset	w12, eq
	bit.16b	v0, v30, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v26, v2
	bit.16b	v1, v31, v3
	cmp	x30, #480
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v29, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #512
	cset	w12, eq
	bit.16b	v0, v27, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v28, v2
	bit.16b	v1, v5, v3
	cmp	x30, #544
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v6, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #576
	cset	w12, eq
	ldr	q3, [sp, #12592]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v16, v2
	bit.16b	v1, v23, v3
	cmp	x30, #608
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12432]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #640
	cset	w12, eq
	bit.16b	v0, v25, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v24, v2
	bit.16b	v1, v13, v3
	cmp	x30, #672
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v12, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #704
	cset	w12, eq
	ldr	q3, [sp, #12144]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v17, v2
	bit.16b	v1, v21, v3
	cmp	x30, #736
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12128]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #768
	cset	w12, eq
	ldr	q3, [sp, #12320]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12416]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12368]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #800
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12400]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #832
	cset	w12, eq
	bit.16b	v0, v18, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12464]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12800]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #864
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12352]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #896
	cset	w12, eq
	ldr	q3, [sp, #12336]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12784]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12960]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #928
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12576]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #960
	cset	w12, eq
	ldr	q3, [sp, #12896]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12944]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13792]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #992
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12880]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1024
	cset	w12, eq
	ldr	q3, [sp, #13776]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13760]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12864]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1056
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12560]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1088
	cset	w12, eq
	ldr	q3, [sp, #13744]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13728]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12768]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1120
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12848]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1152
	cset	w12, eq
	ldr	q3, [sp, #12832]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12752]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12736]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1184
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12544]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1216
	cset	w12, eq
	ldr	q3, [sp, #12528]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12720]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12704]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1248
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12512]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1280
	cset	w12, eq
	ldr	q3, [sp, #12496]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12688]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13712]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1312
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12480]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1344
	cset	w12, eq
	ldr	q3, [sp, #13696]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13680]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13648]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1376
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13664]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1408
	cset	w12, eq
	ldr	q3, [sp, #13632]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13616]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13584]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1440
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13600]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1472
	cset	w12, eq
	ldr	q3, [sp, #13568]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13552]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13520]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1504
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13536]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1536
	cset	w12, eq
	ldr	q3, [sp, #13504]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13488]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13456]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1568
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13472]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1600
	cset	w12, eq
	ldr	q3, [sp, #13440]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13424]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13392]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1632
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13408]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1664
	cset	w12, eq
	ldr	q3, [sp, #13376]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13360]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13328]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1696
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13344]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1728
	cset	w12, eq
	ldr	q3, [sp, #13312]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13296]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13264]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1760
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13280]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1792
	cset	w12, eq
	ldr	q3, [sp, #13248]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13232]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13200]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1824
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13216]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1856
	cset	w12, eq
	ldr	q3, [sp, #13184]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13168]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13136]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1888
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13152]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1920
	cset	w12, eq
	ldr	q3, [sp, #13120]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13104]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13072]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1952
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13088]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1984
	cset	w12, eq
	ldr	q3, [sp, #13056]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13040]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13008]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #2016
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13024]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #12992]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	add	x12, x4, x30
	ldr	q3, [sp, #12976]                ; 16-byte Reload
	bit.16b	v1, v3, v2
	ldp	q3, q2, [x12]
	and.16b	v2, v15, v2
	fmul.4s	v1, v1, v2
	and.16b	v2, v14, v3
	mov.16b	v3, v22
	fmul.4s	v0, v0, v2
	fadd.4s	v1, v9, v1
	bit.16b	v9, v1, v15
	fadd.4s	v0, v10, v0
	bit.16b	v10, v0, v14
	add	x30, x30, #32
	cmp	x30, #2048
	b.ne	LBB0_1069
; %bb.1070:                             ; %direct.false1139
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q9, [sp, #9408]                 ; 16-byte Spill
	str	q10, [sp, #9424]                ; 16-byte Spill
	ldr	q10, [sp, #9440]                ; 16-byte Reload
	ldr	q0, [sp, #11888]                ; 16-byte Reload
	and.16b	v10, v0, v10
	ldr	q0, [sp, #11872]                ; 16-byte Reload
	and.16b	v8, v0, v8
	mov	w30, #8192                      ; =0x2000
	ldr	q9, [sp, #12128]                ; 16-byte Reload
LBB0_1071:                              ; %direct.true1342
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	subs	x12, x30, #2, lsl #12           ; =8192
	cset	w15, eq
	dup.4h	v0, w15
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	and.16b	v1, v0, v4
	cmp	x12, #32
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #12816]               ; 16-byte Reload
	and.16b	v0, v0, v11
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #64
	cset	w15, eq
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12448]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12656]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #96
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #12672]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #128
	cset	w15, eq
	ldr	q3, [sp, #12912]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13936]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13904]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #160
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #13920]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #192
	cset	w15, eq
	ldr	q3, [sp, #13888]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13872]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13856]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #224
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #12304]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #256
	cset	w15, eq
	ldr	q3, [sp, #13840]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13824]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	bit.16b	v1, v19, v3
	cmp	x12, #288
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #13808]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #320
	cset	w15, eq
	ldr	q3, [sp, #12384]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12640]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12608]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #352
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #12624]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #384
	cset	w15, eq
	ldr	q3, [sp, #13984]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13968]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12928]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #416
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #13952]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #448
	cset	w15, eq
	bit.16b	v0, v30, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v26, v2
	bit.16b	v1, v31, v3
	cmp	x12, #480
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v29, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #512
	cset	w15, eq
	bit.16b	v0, v27, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v28, v2
	bit.16b	v1, v5, v3
	cmp	x12, #544
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v6, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #576
	cset	w15, eq
	ldr	q3, [sp, #12592]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v16, v2
	bit.16b	v1, v23, v3
	cmp	x12, #608
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #12432]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #640
	cset	w15, eq
	bit.16b	v0, v25, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v24, v2
	bit.16b	v1, v13, v3
	cmp	x12, #672
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v12, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #704
	cset	w15, eq
	ldr	q3, [sp, #12144]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v17, v2
	bit.16b	v1, v21, v3
	cmp	x12, #736
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v9, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #768
	cset	w15, eq
	ldr	q3, [sp, #12320]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12416]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12368]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #800
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #12400]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #832
	cset	w15, eq
	bit.16b	v0, v18, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12464]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12800]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #864
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #12352]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #896
	cset	w15, eq
	ldr	q3, [sp, #12336]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12784]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12960]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #928
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #12576]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #960
	cset	w15, eq
	ldr	q3, [sp, #12896]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12944]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13792]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #992
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #12880]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1024
	cset	w15, eq
	ldr	q3, [sp, #13776]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13760]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12864]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1056
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #12560]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1088
	cset	w15, eq
	ldr	q3, [sp, #13744]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13728]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12768]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1120
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #12848]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1152
	cset	w15, eq
	ldr	q3, [sp, #12832]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12752]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12736]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1184
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #12544]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1216
	cset	w15, eq
	ldr	q3, [sp, #12528]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12720]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12704]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1248
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #12512]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1280
	cset	w15, eq
	ldr	q3, [sp, #12496]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12688]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13712]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1312
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #12480]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1344
	cset	w15, eq
	ldr	q3, [sp, #13696]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13680]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13648]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1376
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #13664]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1408
	cset	w15, eq
	ldr	q3, [sp, #13632]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13616]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13584]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1440
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #13600]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1472
	cset	w15, eq
	ldr	q3, [sp, #13568]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13552]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13520]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1504
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #13536]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1536
	cset	w15, eq
	ldr	q3, [sp, #13504]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13488]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13456]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1568
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #13472]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1600
	cset	w15, eq
	ldr	q3, [sp, #13440]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13424]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13392]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1632
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #13408]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1664
	cset	w15, eq
	ldr	q3, [sp, #13376]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13360]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13328]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1696
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #13344]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1728
	cset	w15, eq
	ldr	q3, [sp, #13312]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13296]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13264]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1760
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #13280]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1792
	cset	w15, eq
	ldr	q3, [sp, #13248]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13232]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13200]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1824
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #13216]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1856
	cset	w15, eq
	ldr	q3, [sp, #13184]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13168]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13136]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1888
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #13152]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1920
	cset	w15, eq
	ldr	q3, [sp, #13120]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13104]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13072]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1952
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #13088]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1984
	cset	w15, eq
	ldr	q3, [sp, #13056]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13040]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13008]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #2016
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13024]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #12992]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	add	x12, x8, x30
	ldr	q3, [sp, #12976]                ; 16-byte Reload
	bit.16b	v1, v3, v2
	ldp	q3, q2, [x12]
	and.16b	v2, v15, v2
	fmul.4s	v1, v1, v2
	and.16b	v2, v14, v3
	mov.16b	v3, v22
	fmul.4s	v0, v0, v2
	fadd.4s	v1, v10, v1
	bit.16b	v10, v1, v15
	fadd.4s	v0, v8, v0
	bit.16b	v8, v0, v14
	add	x30, x30, #32
	cmp	x30, x5
	b.ne	LBB0_1071
; %bb.1072:                             ; %direct.false1343
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q10, [sp, #9440]                ; 16-byte Spill
	str	q8, [sp, #9456]                 ; 16-byte Spill
	mov	x30, #0                         ; =0x0
	ldr	q8, [sp, #9472]                 ; 16-byte Reload
	ldr	q0, [sp, #11888]                ; 16-byte Reload
	and.16b	v8, v0, v8
	ldr	q0, [sp, #11872]                ; 16-byte Reload
	ldr	q10, [sp, #9488]                ; 16-byte Reload
	and.16b	v10, v0, v10
LBB0_1073:                              ; %direct.true1546
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x30, #0
	cset	w12, eq
	dup.4h	v0, w12
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	and.16b	v1, v0, v4
	cmp	x30, #32
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12816]               ; 16-byte Reload
	and.16b	v0, v0, v11
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #64
	cset	w12, eq
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12448]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12656]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #96
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12672]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #128
	cset	w12, eq
	ldr	q3, [sp, #12912]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13936]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13904]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #160
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13920]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #192
	cset	w12, eq
	ldr	q3, [sp, #13888]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13872]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13856]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #224
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12304]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #256
	cset	w12, eq
	ldr	q3, [sp, #13840]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13824]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	bit.16b	v1, v19, v3
	cmp	x30, #288
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13808]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #320
	cset	w12, eq
	ldr	q3, [sp, #12384]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12640]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12608]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #352
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12624]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #384
	cset	w12, eq
	ldr	q3, [sp, #13984]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13968]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12928]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #416
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13952]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #448
	cset	w12, eq
	bit.16b	v0, v30, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v26, v2
	bit.16b	v1, v31, v3
	cmp	x30, #480
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v29, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #512
	cset	w12, eq
	bit.16b	v0, v27, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v28, v2
	bit.16b	v1, v5, v3
	cmp	x30, #544
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v6, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #576
	cset	w12, eq
	ldr	q3, [sp, #12592]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v16, v2
	bit.16b	v1, v23, v3
	cmp	x30, #608
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12432]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #640
	cset	w12, eq
	bit.16b	v0, v25, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v24, v2
	bit.16b	v1, v13, v3
	cmp	x30, #672
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v12, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #704
	cset	w12, eq
	ldr	q3, [sp, #12144]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v17, v2
	bit.16b	v1, v21, v3
	cmp	x30, #736
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v9, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #768
	cset	w12, eq
	ldr	q3, [sp, #12320]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12416]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12368]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #800
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12400]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #832
	cset	w12, eq
	bit.16b	v0, v18, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12464]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12800]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #864
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12352]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #896
	cset	w12, eq
	ldr	q3, [sp, #12336]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12784]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12960]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #928
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12576]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #960
	cset	w12, eq
	ldr	q3, [sp, #12896]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12944]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13792]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #992
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12880]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1024
	cset	w12, eq
	ldr	q3, [sp, #13776]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13760]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12864]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1056
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12560]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1088
	cset	w12, eq
	ldr	q3, [sp, #13744]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13728]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12768]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1120
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12848]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1152
	cset	w12, eq
	ldr	q3, [sp, #12832]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12752]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12736]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1184
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12544]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1216
	cset	w12, eq
	ldr	q3, [sp, #12528]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12720]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12704]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1248
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12512]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1280
	cset	w12, eq
	ldr	q3, [sp, #12496]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12688]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13712]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1312
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12480]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1344
	cset	w12, eq
	ldr	q3, [sp, #13696]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13680]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13648]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1376
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13664]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1408
	cset	w12, eq
	ldr	q3, [sp, #13632]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13616]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13584]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1440
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13600]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1472
	cset	w12, eq
	ldr	q3, [sp, #13568]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13552]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13520]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1504
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13536]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1536
	cset	w12, eq
	ldr	q3, [sp, #13504]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13488]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13456]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1568
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13472]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1600
	cset	w12, eq
	ldr	q3, [sp, #13440]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13424]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13392]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1632
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13408]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1664
	cset	w12, eq
	ldr	q3, [sp, #13376]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13360]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13328]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1696
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13344]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1728
	cset	w12, eq
	ldr	q3, [sp, #13312]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13296]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13264]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1760
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13280]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1792
	cset	w12, eq
	ldr	q3, [sp, #13248]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13232]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13200]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1824
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13216]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1856
	cset	w12, eq
	ldr	q3, [sp, #13184]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13168]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13136]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1888
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13152]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1920
	cset	w12, eq
	ldr	q3, [sp, #13120]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13104]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13072]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1952
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13088]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1984
	cset	w12, eq
	ldr	q3, [sp, #13056]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13040]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13008]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #2016
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13024]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #12992]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	add	x12, x6, x30
	ldr	q3, [sp, #12976]                ; 16-byte Reload
	bit.16b	v1, v3, v2
	ldp	q3, q2, [x12]
	and.16b	v2, v15, v2
	fmul.4s	v1, v1, v2
	and.16b	v2, v14, v3
	mov.16b	v3, v22
	fmul.4s	v0, v0, v2
	fadd.4s	v1, v8, v1
	bit.16b	v8, v1, v15
	fadd.4s	v0, v10, v0
	bit.16b	v10, v0, v14
	add	x30, x30, #32
	cmp	x30, #2048
	b.ne	LBB0_1073
; %bb.1074:                             ; %direct.false1547
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q10, [sp, #9488]                ; 16-byte Spill
	str	q8, [sp, #9472]                 ; 16-byte Spill
	ldr	q0, [sp, #11888]                ; 16-byte Reload
	ldr	q1, [sp, #9504]                 ; 16-byte Reload
	and.16b	v1, v0, v1
	ldr	q0, [sp, #11872]                ; 16-byte Reload
	and.16b	v7, v0, v7
	mov	w30, #12288                     ; =0x3000
	ldr	q8, [sp, #12320]                ; 16-byte Reload
	mov.16b	v10, v19
	mov.16b	v19, v1
LBB0_1075:                              ; %direct.true1750
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	subs	x12, x30, #3, lsl #12           ; =12288
	cset	w15, eq
	dup.4h	v0, w15
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	and.16b	v1, v0, v4
	cmp	x12, #32
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #12816]               ; 16-byte Reload
	and.16b	v0, v0, v11
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #64
	cset	w15, eq
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12448]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12656]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #96
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #12672]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #128
	cset	w15, eq
	ldr	q3, [sp, #12912]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13936]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13904]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #160
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #13920]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #192
	cset	w15, eq
	ldr	q3, [sp, #13888]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13872]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13856]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #224
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #12304]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #256
	cset	w15, eq
	ldr	q3, [sp, #13840]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13824]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	bit.16b	v1, v10, v3
	cmp	x12, #288
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #13808]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #320
	cset	w15, eq
	ldr	q3, [sp, #12384]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12640]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12608]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #352
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #12624]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #384
	cset	w15, eq
	ldr	q3, [sp, #13984]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13968]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12928]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #416
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #13952]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #448
	cset	w15, eq
	bit.16b	v0, v30, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v26, v2
	bit.16b	v1, v31, v3
	cmp	x12, #480
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v29, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #512
	cset	w15, eq
	bit.16b	v0, v27, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v28, v2
	bit.16b	v1, v5, v3
	cmp	x12, #544
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v6, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #576
	cset	w15, eq
	ldr	q3, [sp, #12592]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v16, v2
	bit.16b	v1, v23, v3
	cmp	x12, #608
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #12432]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #640
	cset	w15, eq
	bit.16b	v0, v25, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v24, v2
	bit.16b	v1, v13, v3
	cmp	x12, #672
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v12, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #704
	cset	w15, eq
	ldr	q3, [sp, #12144]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v17, v2
	bit.16b	v1, v21, v3
	cmp	x12, #736
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v9, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #768
	cset	w15, eq
	bit.16b	v0, v8, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12416]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12368]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #800
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #12400]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #832
	cset	w15, eq
	bit.16b	v0, v18, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12464]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12800]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #864
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #12352]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #896
	cset	w15, eq
	ldr	q3, [sp, #12336]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12784]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12960]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #928
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #12576]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #960
	cset	w15, eq
	ldr	q3, [sp, #12896]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12944]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13792]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #992
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #12880]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1024
	cset	w15, eq
	ldr	q3, [sp, #13776]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13760]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12864]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1056
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #12560]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1088
	cset	w15, eq
	ldr	q3, [sp, #13744]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13728]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12768]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1120
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #12848]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1152
	cset	w15, eq
	ldr	q3, [sp, #12832]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12752]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12736]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1184
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #12544]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1216
	cset	w15, eq
	ldr	q3, [sp, #12528]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12720]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12704]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1248
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #12512]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1280
	cset	w15, eq
	ldr	q3, [sp, #12496]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12688]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13712]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1312
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #12480]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1344
	cset	w15, eq
	ldr	q3, [sp, #13696]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13680]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13648]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1376
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #13664]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1408
	cset	w15, eq
	ldr	q3, [sp, #13632]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13616]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13584]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1440
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #13600]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1472
	cset	w15, eq
	ldr	q3, [sp, #13568]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13552]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13520]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1504
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #13536]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1536
	cset	w15, eq
	ldr	q3, [sp, #13504]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13488]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13456]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1568
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #13472]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1600
	cset	w15, eq
	ldr	q3, [sp, #13440]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13424]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13392]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1632
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #13408]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1664
	cset	w15, eq
	ldr	q3, [sp, #13376]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13360]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13328]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1696
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #13344]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1728
	cset	w15, eq
	ldr	q3, [sp, #13312]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13296]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13264]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1760
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #13280]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1792
	cset	w15, eq
	ldr	q3, [sp, #13248]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13232]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13200]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1824
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #13216]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1856
	cset	w15, eq
	ldr	q3, [sp, #13184]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13168]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13136]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1888
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #13152]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1920
	cset	w15, eq
	ldr	q3, [sp, #13120]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13104]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13072]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1952
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q11, [sp, #13088]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1984
	cset	w15, eq
	ldr	q3, [sp, #13056]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13040]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13008]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #2016
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13024]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #12992]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	add	x12, x8, x30
	ldr	q3, [sp, #12976]                ; 16-byte Reload
	bit.16b	v1, v3, v2
	ldp	q3, q2, [x12]
	and.16b	v2, v15, v2
	fmul.4s	v1, v1, v2
	and.16b	v2, v14, v3
	mov.16b	v3, v22
	fmul.4s	v0, v0, v2
	fadd.4s	v1, v19, v1
	bit.16b	v19, v1, v15
	fadd.4s	v0, v7, v0
	bit.16b	v7, v0, v14
	add	x30, x30, #32
	cmp	x30, x7
	b.ne	LBB0_1075
; %bb.1076:                             ; %direct.false1751
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q19, [sp, #9504]                ; 16-byte Spill
	str	q7, [sp, #9520]                 ; 16-byte Spill
	mov	x30, #0                         ; =0x0
	ldr	q7, [sp, #9712]                 ; 16-byte Reload
	ldr	q0, [sp, #11888]                ; 16-byte Reload
	and.16b	v7, v0, v7
	ldr	q0, [sp, #11872]                ; 16-byte Reload
	and.16b	v20, v0, v20
	ldr	q19, [sp, #12416]               ; 16-byte Reload
LBB0_1077:                              ; %direct.true1954
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x30, #0
	cset	w12, eq
	dup.4h	v0, w12
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	and.16b	v1, v0, v4
	cmp	x30, #32
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12816]               ; 16-byte Reload
	and.16b	v0, v0, v11
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #64
	cset	w12, eq
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12448]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12656]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #96
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12672]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #128
	cset	w12, eq
	ldr	q3, [sp, #12912]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13936]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13904]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #160
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13920]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #192
	cset	w12, eq
	ldr	q3, [sp, #13888]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13872]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13856]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #224
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12304]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #256
	cset	w12, eq
	ldr	q3, [sp, #13840]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13824]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	bit.16b	v1, v10, v3
	cmp	x30, #288
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13808]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #320
	cset	w12, eq
	ldr	q3, [sp, #12384]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12640]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12608]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #352
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12624]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #384
	cset	w12, eq
	ldr	q3, [sp, #13984]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13968]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12928]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #416
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13952]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #448
	cset	w12, eq
	bit.16b	v0, v30, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v26, v2
	bit.16b	v1, v31, v3
	cmp	x30, #480
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v29, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #512
	cset	w12, eq
	bit.16b	v0, v27, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v28, v2
	bit.16b	v1, v5, v3
	cmp	x30, #544
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v6, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #576
	cset	w12, eq
	ldr	q3, [sp, #12592]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v16, v2
	bit.16b	v1, v23, v3
	cmp	x30, #608
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12432]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #640
	cset	w12, eq
	bit.16b	v0, v25, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v24, v2
	bit.16b	v1, v13, v3
	cmp	x30, #672
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v12, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #704
	cset	w12, eq
	ldr	q3, [sp, #12144]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v17, v2
	bit.16b	v1, v21, v3
	cmp	x30, #736
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v9, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #768
	cset	w12, eq
	bit.16b	v0, v8, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12368]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #800
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12400]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #832
	cset	w12, eq
	bit.16b	v0, v18, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12464]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12800]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #864
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12352]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #896
	cset	w12, eq
	ldr	q3, [sp, #12336]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12784]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12960]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #928
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12576]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #960
	cset	w12, eq
	ldr	q3, [sp, #12896]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12944]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13792]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #992
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12880]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1024
	cset	w12, eq
	ldr	q3, [sp, #13776]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13760]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12864]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1056
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12560]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1088
	cset	w12, eq
	ldr	q3, [sp, #13744]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13728]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12768]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1120
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12848]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1152
	cset	w12, eq
	ldr	q3, [sp, #12832]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12752]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12736]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1184
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12544]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1216
	cset	w12, eq
	ldr	q3, [sp, #12528]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12720]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #12704]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1248
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12512]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1280
	cset	w12, eq
	ldr	q3, [sp, #12496]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #12688]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13712]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1312
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #12480]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1344
	cset	w12, eq
	ldr	q3, [sp, #13696]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13680]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13648]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1376
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13664]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1408
	cset	w12, eq
	ldr	q3, [sp, #13632]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13616]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13584]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1440
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13600]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1472
	cset	w12, eq
	ldr	q3, [sp, #13568]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13552]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13520]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1504
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13536]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1536
	cset	w12, eq
	ldr	q3, [sp, #13504]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13488]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13456]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1568
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13472]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1600
	cset	w12, eq
	ldr	q3, [sp, #13440]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13424]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13392]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1632
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13408]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1664
	cset	w12, eq
	ldr	q3, [sp, #13376]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13360]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13328]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1696
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13344]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1728
	cset	w12, eq
	ldr	q3, [sp, #13312]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13296]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13264]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1760
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13280]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1792
	cset	w12, eq
	ldr	q3, [sp, #13248]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13232]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13200]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1824
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13216]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1856
	cset	w12, eq
	ldr	q3, [sp, #13184]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13168]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13136]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1888
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13152]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1920
	cset	w12, eq
	ldr	q3, [sp, #13120]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13104]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13072]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1952
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13088]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1984
	cset	w12, eq
	ldr	q3, [sp, #13056]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q11, [sp, #13040]               ; 16-byte Reload
	bit.16b	v1, v11, v2
	ldr	q2, [sp, #13008]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #2016
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q11, [sp, #13024]               ; 16-byte Reload
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #12992]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	add	x12, x19, x30
	ldr	q3, [sp, #12976]                ; 16-byte Reload
	bit.16b	v1, v3, v2
	ldp	q3, q2, [x12]
	and.16b	v2, v15, v2
	fmul.4s	v1, v1, v2
	and.16b	v2, v14, v3
	mov.16b	v3, v22
	fmul.4s	v0, v0, v2
	fadd.4s	v1, v7, v1
	bit.16b	v7, v1, v15
	fadd.4s	v0, v20, v0
	bit.16b	v20, v0, v14
	add	x30, x30, #32
	cmp	x30, #2048
	b.ne	LBB0_1077
; %bb.1078:                             ; %direct.false1955
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q7, [sp, #9712]                 ; 16-byte Spill
	str	q20, [sp, #9728]                ; 16-byte Spill
	ldr	q0, [sp, #11888]                ; 16-byte Reload
	ldr	q17, [sp, #9744]                ; 16-byte Reload
	and.16b	v17, v0, v17
	mov.16b	v29, v18
	ldr	q26, [sp, #12368]               ; 16-byte Reload
	mov.16b	v30, v23
	mov.16b	v27, v24
	ldr	q31, [sp, #12144]               ; 16-byte Reload
	ldr	q7, [sp, #9760]                 ; 16-byte Reload
	ldr	q0, [sp, #11872]                ; 16-byte Reload
	and.16b	v7, v0, v7
	mov	w30, #16384                     ; =0x4000
	ldr	q28, [sp, #12304]               ; 16-byte Reload
	ldr	q16, [sp, #12400]               ; 16-byte Reload
	mov.16b	v11, v19
	ldr	q23, [sp, #12464]               ; 16-byte Reload
	ldr	q18, [sp, #12352]               ; 16-byte Reload
	ldr	q6, [sp, #12800]                ; 16-byte Reload
	ldr	q20, [sp, #12784]               ; 16-byte Reload
	ldr	q5, [sp, #12448]                ; 16-byte Reload
	ldr	q24, [sp, #12336]               ; 16-byte Reload
LBB0_1079:                              ; %direct.true2158
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	subs	x12, x30, #4, lsl #12           ; =16384
	cset	w15, eq
	dup.4h	v0, w15
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	and.16b	v1, v0, v4
	cmp	x12, #32
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12816]               ; 16-byte Reload
	and.16b	v0, v0, v19
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #64
	cset	w15, eq
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v5, v2
	ldr	q2, [sp, #12656]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #96
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12672]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #128
	cset	w15, eq
	ldr	q3, [sp, #12912]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13936]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13904]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #160
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13920]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #192
	cset	w15, eq
	ldr	q3, [sp, #13888]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13872]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13856]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #224
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v28, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #256
	cset	w15, eq
	ldr	q3, [sp, #13840]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13824]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	bit.16b	v1, v10, v3
	cmp	x12, #288
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13808]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #320
	cset	w15, eq
	ldr	q3, [sp, #12384]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12640]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12608]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #352
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12624]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #384
	cset	w15, eq
	ldr	q3, [sp, #13984]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13968]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12928]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #416
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13952]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #448
	cset	w15, eq
	ldr	q3, [sp, #12288]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12272]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12240]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #480
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12256]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #512
	cset	w15, eq
	ldr	q3, [sp, #12224]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12096]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12192]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #544
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12208]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #576
	cset	w15, eq
	ldr	q3, [sp, #12592]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12176]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	bit.16b	v1, v30, v3
	cmp	x12, #608
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12432]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #640
	cset	w15, eq
	bit.16b	v0, v25, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v27, v2
	bit.16b	v1, v13, v3
	cmp	x12, #672
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v12, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #704
	cset	w15, eq
	bit.16b	v0, v31, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12160]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	bit.16b	v1, v21, v3
	cmp	x12, #736
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v9, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #768
	cset	w15, eq
	bit.16b	v0, v8, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v11, v2
	bit.16b	v1, v26, v3
	cmp	x12, #800
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v16, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #832
	cset	w15, eq
	bit.16b	v0, v29, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v23, v2
	bit.16b	v1, v6, v3
	cmp	x12, #864
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #896
	cset	w15, eq
	bit.16b	v0, v24, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v20, v2
	ldr	q2, [sp, #12960]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #928
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12576]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #960
	cset	w15, eq
	ldr	q3, [sp, #12896]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12944]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13792]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #992
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12880]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1024
	cset	w15, eq
	ldr	q3, [sp, #13776]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13760]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12864]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1056
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12560]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1088
	cset	w15, eq
	ldr	q3, [sp, #13744]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13728]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12768]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1120
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12848]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1152
	cset	w15, eq
	ldr	q3, [sp, #12832]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12752]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12736]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1184
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12544]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1216
	cset	w15, eq
	ldr	q3, [sp, #12528]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12720]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12704]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1248
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12512]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1280
	cset	w15, eq
	ldr	q3, [sp, #12496]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12688]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13712]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1312
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12480]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1344
	cset	w15, eq
	ldr	q3, [sp, #13696]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13680]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13648]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1376
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13664]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1408
	cset	w15, eq
	ldr	q3, [sp, #13632]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13616]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13584]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1440
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13600]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1472
	cset	w15, eq
	ldr	q3, [sp, #13568]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13552]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13520]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1504
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13536]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1536
	cset	w15, eq
	ldr	q3, [sp, #13504]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13488]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13456]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1568
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13472]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1600
	cset	w15, eq
	ldr	q3, [sp, #13440]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13424]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13392]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1632
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13408]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1664
	cset	w15, eq
	ldr	q3, [sp, #13376]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13360]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13328]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1696
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13344]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1728
	cset	w15, eq
	ldr	q3, [sp, #13312]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13296]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13264]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1760
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13280]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1792
	cset	w15, eq
	ldr	q3, [sp, #13248]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13232]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13200]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1824
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13216]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1856
	cset	w15, eq
	ldr	q3, [sp, #13184]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13168]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13136]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1888
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13152]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1920
	cset	w15, eq
	ldr	q3, [sp, #13120]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13104]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13072]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1952
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13088]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1984
	cset	w15, eq
	ldr	q3, [sp, #13056]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13040]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13008]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #2016
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13024]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #12992]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	add	x12, x8, x30
	ldr	q3, [sp, #12976]                ; 16-byte Reload
	bit.16b	v1, v3, v2
	ldp	q3, q2, [x12]
	and.16b	v2, v15, v2
	fmul.4s	v1, v1, v2
	and.16b	v2, v14, v3
	mov.16b	v3, v22
	fmul.4s	v0, v0, v2
	fadd.4s	v1, v17, v1
	bit.16b	v17, v1, v15
	fadd.4s	v0, v7, v0
	bit.16b	v7, v0, v14
	add	x30, x30, #32
	cmp	x30, x20
	b.ne	LBB0_1079
; %bb.1080:                             ; %direct.false2159
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q17, [sp, #9744]                ; 16-byte Spill
	str	q7, [sp, #9760]                 ; 16-byte Spill
	mov	x30, #0                         ; =0x0
	ldr	q17, [sp, #9616]                ; 16-byte Reload
	ldr	q0, [sp, #11888]                ; 16-byte Reload
	and.16b	v17, v0, v17
	ldr	q7, [sp, #9632]                 ; 16-byte Reload
	ldr	q0, [sp, #11872]                ; 16-byte Reload
	and.16b	v7, v0, v7
LBB0_1081:                              ; %direct.true2362
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x30, #0
	cset	w12, eq
	dup.4h	v0, w12
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	and.16b	v1, v0, v4
	cmp	x30, #32
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12816]               ; 16-byte Reload
	and.16b	v0, v0, v19
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #64
	cset	w12, eq
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v5, v2
	ldr	q2, [sp, #12656]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #96
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12672]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #128
	cset	w12, eq
	ldr	q3, [sp, #12912]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13936]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13904]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #160
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13920]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #192
	cset	w12, eq
	ldr	q3, [sp, #13888]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13872]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13856]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #224
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v28, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #256
	cset	w12, eq
	ldr	q3, [sp, #13840]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13824]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	bit.16b	v1, v10, v3
	cmp	x30, #288
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13808]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #320
	cset	w12, eq
	ldr	q3, [sp, #12384]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12640]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12608]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #352
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12624]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #384
	cset	w12, eq
	ldr	q3, [sp, #13984]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13968]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12928]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #416
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13952]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #448
	cset	w12, eq
	ldr	q3, [sp, #12288]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12272]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12240]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #480
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12256]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #512
	cset	w12, eq
	ldr	q3, [sp, #12224]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12096]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12192]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #544
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12208]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #576
	cset	w12, eq
	ldr	q3, [sp, #12592]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12176]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	bit.16b	v1, v30, v3
	cmp	x30, #608
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12432]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #640
	cset	w12, eq
	bit.16b	v0, v25, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v27, v2
	bit.16b	v1, v13, v3
	cmp	x30, #672
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v12, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #704
	cset	w12, eq
	bit.16b	v0, v31, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12160]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	bit.16b	v1, v21, v3
	cmp	x30, #736
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v9, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #768
	cset	w12, eq
	bit.16b	v0, v8, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v11, v2
	bit.16b	v1, v26, v3
	cmp	x30, #800
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v16, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #832
	cset	w12, eq
	bit.16b	v0, v29, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v23, v2
	bit.16b	v1, v6, v3
	cmp	x30, #864
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #896
	cset	w12, eq
	bit.16b	v0, v24, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v20, v2
	ldr	q2, [sp, #12960]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #928
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12576]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #960
	cset	w12, eq
	ldr	q3, [sp, #12896]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12944]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13792]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #992
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12880]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1024
	cset	w12, eq
	ldr	q3, [sp, #13776]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13760]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12864]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1056
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12560]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1088
	cset	w12, eq
	ldr	q3, [sp, #13744]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13728]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12768]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1120
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12848]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1152
	cset	w12, eq
	ldr	q3, [sp, #12832]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12752]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12736]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1184
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12544]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1216
	cset	w12, eq
	ldr	q3, [sp, #12528]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12720]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12704]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1248
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12512]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1280
	cset	w12, eq
	ldr	q3, [sp, #12496]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12688]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13712]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1312
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12480]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1344
	cset	w12, eq
	ldr	q3, [sp, #13696]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13680]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13648]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1376
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13664]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1408
	cset	w12, eq
	ldr	q3, [sp, #13632]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13616]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13584]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1440
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13600]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1472
	cset	w12, eq
	ldr	q3, [sp, #13568]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13552]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13520]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1504
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13536]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1536
	cset	w12, eq
	ldr	q3, [sp, #13504]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13488]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13456]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1568
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13472]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1600
	cset	w12, eq
	ldr	q3, [sp, #13440]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13424]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13392]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1632
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13408]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1664
	cset	w12, eq
	ldr	q3, [sp, #13376]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13360]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13328]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1696
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13344]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1728
	cset	w12, eq
	ldr	q3, [sp, #13312]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13296]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13264]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1760
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13280]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1792
	cset	w12, eq
	ldr	q3, [sp, #13248]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13232]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13200]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1824
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13216]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1856
	cset	w12, eq
	ldr	q3, [sp, #13184]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13168]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13136]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1888
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13152]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1920
	cset	w12, eq
	ldr	q3, [sp, #13120]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13104]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13072]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1952
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13088]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1984
	cset	w12, eq
	ldr	q3, [sp, #13056]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13040]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13008]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #2016
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13024]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #12992]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	add	x12, x21, x30
	ldr	q3, [sp, #12976]                ; 16-byte Reload
	bit.16b	v1, v3, v2
	ldp	q3, q2, [x12]
	and.16b	v2, v15, v2
	fmul.4s	v1, v1, v2
	and.16b	v2, v14, v3
	mov.16b	v3, v22
	fmul.4s	v0, v0, v2
	fadd.4s	v1, v17, v1
	bit.16b	v17, v1, v15
	fadd.4s	v0, v7, v0
	bit.16b	v7, v0, v14
	add	x30, x30, #32
	cmp	x30, #2048
	b.ne	LBB0_1081
; %bb.1082:                             ; %direct.false2363
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q17, [sp, #9616]                ; 16-byte Spill
	str	q7, [sp, #9632]                 ; 16-byte Spill
	ldr	q0, [sp, #11888]                ; 16-byte Reload
	ldr	q1, [sp, #9648]                 ; 16-byte Reload
	and.16b	v1, v0, v1
	str	q6, [sp, #12800]                ; 16-byte Spill
	mov.16b	v6, v9
	mov.16b	v9, v1
	str	q20, [sp, #12784]               ; 16-byte Spill
	mov.16b	v20, v8
	ldr	q8, [sp, #9664]                 ; 16-byte Reload
	ldr	q0, [sp, #11872]                ; 16-byte Reload
	and.16b	v8, v0, v8
	mov	w30, #20480                     ; =0x5000
	ldr	q7, [sp, #9696]                 ; 16-byte Reload
	ldr	q17, [sp, #9680]                ; 16-byte Reload
	ldr	q21, [sp, #12384]               ; 16-byte Reload
LBB0_1083:                              ; %direct.true2566
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	subs	x12, x30, #5, lsl #12           ; =20480
	cset	w15, eq
	dup.4h	v0, w15
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	and.16b	v1, v0, v4
	cmp	x12, #32
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12816]               ; 16-byte Reload
	and.16b	v0, v0, v19
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #64
	cset	w15, eq
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v5, v2
	ldr	q2, [sp, #12656]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #96
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12672]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #128
	cset	w15, eq
	ldr	q3, [sp, #12912]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13936]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13904]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #160
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13920]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #192
	cset	w15, eq
	ldr	q3, [sp, #13888]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13872]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13856]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #224
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v28, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #256
	cset	w15, eq
	ldr	q3, [sp, #13840]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13824]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	bit.16b	v1, v10, v3
	cmp	x12, #288
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13808]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #320
	cset	w15, eq
	bit.16b	v0, v21, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12640]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12608]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #352
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12624]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #384
	cset	w15, eq
	ldr	q3, [sp, #13984]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13968]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12928]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #416
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13952]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #448
	cset	w15, eq
	ldr	q3, [sp, #12288]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12272]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12240]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #480
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12256]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #512
	cset	w15, eq
	ldr	q3, [sp, #12224]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12096]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12192]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #544
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12208]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #576
	cset	w15, eq
	ldr	q3, [sp, #12592]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12176]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	bit.16b	v1, v30, v3
	cmp	x12, #608
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12432]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #640
	cset	w15, eq
	bit.16b	v0, v25, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v27, v2
	bit.16b	v1, v13, v3
	cmp	x12, #672
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v12, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #704
	cset	w15, eq
	bit.16b	v0, v31, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12160]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12112]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #736
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v6, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #768
	cset	w15, eq
	bit.16b	v0, v20, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v11, v2
	bit.16b	v1, v26, v3
	cmp	x12, #800
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v16, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #832
	cset	w15, eq
	bit.16b	v0, v29, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v23, v2
	ldr	q2, [sp, #12800]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #864
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #896
	cset	w15, eq
	bit.16b	v0, v24, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12784]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12960]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #928
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12576]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #960
	cset	w15, eq
	ldr	q3, [sp, #12896]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12944]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13792]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #992
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12880]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1024
	cset	w15, eq
	ldr	q3, [sp, #13776]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13760]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12864]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1056
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12560]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1088
	cset	w15, eq
	ldr	q3, [sp, #13744]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13728]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12768]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1120
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12848]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1152
	cset	w15, eq
	ldr	q3, [sp, #12832]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12752]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12736]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1184
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12544]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1216
	cset	w15, eq
	ldr	q3, [sp, #12528]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12720]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12704]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1248
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12512]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1280
	cset	w15, eq
	ldr	q3, [sp, #12496]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12688]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13712]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1312
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12480]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1344
	cset	w15, eq
	ldr	q3, [sp, #13696]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13680]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13648]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1376
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13664]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1408
	cset	w15, eq
	ldr	q3, [sp, #13632]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13616]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13584]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1440
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13600]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1472
	cset	w15, eq
	ldr	q3, [sp, #13568]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13552]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13520]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1504
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13536]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1536
	cset	w15, eq
	ldr	q3, [sp, #13504]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13488]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13456]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1568
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13472]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1600
	cset	w15, eq
	ldr	q3, [sp, #13440]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13424]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13392]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1632
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13408]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1664
	cset	w15, eq
	ldr	q3, [sp, #13376]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13360]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13328]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1696
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13344]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1728
	cset	w15, eq
	ldr	q3, [sp, #13312]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13296]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13264]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1760
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13280]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1792
	cset	w15, eq
	ldr	q3, [sp, #13248]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13232]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13200]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1824
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13216]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1856
	cset	w15, eq
	ldr	q3, [sp, #13184]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13168]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13136]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1888
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13152]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1920
	cset	w15, eq
	ldr	q3, [sp, #13120]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13104]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13072]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1952
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13088]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1984
	cset	w15, eq
	ldr	q3, [sp, #13056]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13040]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13008]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #2016
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13024]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #12992]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	add	x12, x8, x30
	ldr	q3, [sp, #12976]                ; 16-byte Reload
	bit.16b	v1, v3, v2
	ldp	q3, q2, [x12]
	and.16b	v2, v15, v2
	fmul.4s	v1, v1, v2
	and.16b	v2, v14, v3
	mov.16b	v3, v22
	fmul.4s	v0, v0, v2
	fadd.4s	v1, v9, v1
	bit.16b	v9, v1, v15
	fadd.4s	v0, v8, v0
	bit.16b	v8, v0, v14
	add	x30, x30, #32
	cmp	x30, x22
	b.ne	LBB0_1083
; %bb.1084:                             ; %direct.false2567
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q9, [sp, #9648]                 ; 16-byte Spill
	str	q8, [sp, #9664]                 ; 16-byte Spill
	mov	x30, #0                         ; =0x0
	ldr	q0, [sp, #11888]                ; 16-byte Reload
	and.16b	v17, v0, v17
	ldr	q0, [sp, #11872]                ; 16-byte Reload
	and.16b	v7, v0, v7
	ldr	q8, [sp, #12960]                ; 16-byte Reload
	ldr	q9, [sp, #12896]                ; 16-byte Reload
LBB0_1085:                              ; %direct.true2770
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x30, #0
	cset	w12, eq
	dup.4h	v0, w12
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	and.16b	v1, v0, v4
	cmp	x30, #32
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12816]               ; 16-byte Reload
	and.16b	v0, v0, v19
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #64
	cset	w12, eq
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v5, v2
	ldr	q2, [sp, #12656]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #96
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12672]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #128
	cset	w12, eq
	ldr	q3, [sp, #12912]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13936]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13904]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #160
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13920]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #192
	cset	w12, eq
	ldr	q3, [sp, #13888]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13872]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13856]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #224
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v28, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #256
	cset	w12, eq
	ldr	q3, [sp, #13840]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13824]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	bit.16b	v1, v10, v3
	cmp	x30, #288
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13808]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #320
	cset	w12, eq
	bit.16b	v0, v21, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12640]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12608]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #352
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12624]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #384
	cset	w12, eq
	ldr	q3, [sp, #13984]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13968]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12928]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #416
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13952]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #448
	cset	w12, eq
	ldr	q3, [sp, #12288]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12272]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12240]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #480
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12256]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #512
	cset	w12, eq
	ldr	q3, [sp, #12224]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12096]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12192]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #544
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12208]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #576
	cset	w12, eq
	ldr	q3, [sp, #12592]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12176]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	bit.16b	v1, v30, v3
	cmp	x30, #608
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12432]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #640
	cset	w12, eq
	bit.16b	v0, v25, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v27, v2
	bit.16b	v1, v13, v3
	cmp	x30, #672
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v12, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #704
	cset	w12, eq
	bit.16b	v0, v31, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12160]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12112]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #736
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v6, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #768
	cset	w12, eq
	bit.16b	v0, v20, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v11, v2
	bit.16b	v1, v26, v3
	cmp	x30, #800
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v16, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #832
	cset	w12, eq
	bit.16b	v0, v29, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v23, v2
	ldr	q2, [sp, #12800]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #864
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v18, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #896
	cset	w12, eq
	bit.16b	v0, v24, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12784]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	bit.16b	v1, v8, v3
	cmp	x30, #928
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12576]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #960
	cset	w12, eq
	bit.16b	v0, v9, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12944]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13792]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #992
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12880]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1024
	cset	w12, eq
	ldr	q3, [sp, #13776]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13760]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12864]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1056
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12560]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1088
	cset	w12, eq
	ldr	q3, [sp, #13744]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13728]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12768]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1120
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12848]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1152
	cset	w12, eq
	ldr	q3, [sp, #12832]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12752]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12736]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1184
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12544]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1216
	cset	w12, eq
	ldr	q3, [sp, #12528]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12720]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12704]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1248
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12512]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1280
	cset	w12, eq
	ldr	q3, [sp, #12496]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12688]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13712]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1312
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12480]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1344
	cset	w12, eq
	ldr	q3, [sp, #13696]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13680]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13648]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1376
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13664]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1408
	cset	w12, eq
	ldr	q3, [sp, #13632]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13616]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13584]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1440
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13600]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1472
	cset	w12, eq
	ldr	q3, [sp, #13568]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13552]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13520]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1504
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13536]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1536
	cset	w12, eq
	ldr	q3, [sp, #13504]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13488]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13456]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1568
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13472]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1600
	cset	w12, eq
	ldr	q3, [sp, #13440]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13424]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13392]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1632
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13408]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1664
	cset	w12, eq
	ldr	q3, [sp, #13376]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13360]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13328]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1696
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13344]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1728
	cset	w12, eq
	ldr	q3, [sp, #13312]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13296]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13264]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1760
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13280]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1792
	cset	w12, eq
	ldr	q3, [sp, #13248]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13232]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13200]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1824
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13216]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1856
	cset	w12, eq
	ldr	q3, [sp, #13184]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13168]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13136]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1888
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13152]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1920
	cset	w12, eq
	ldr	q3, [sp, #13120]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13104]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13072]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1952
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13088]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1984
	cset	w12, eq
	ldr	q3, [sp, #13056]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13040]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13008]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #2016
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13024]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #12992]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	add	x12, x24, x30
	ldr	q3, [sp, #12976]                ; 16-byte Reload
	bit.16b	v1, v3, v2
	ldp	q3, q2, [x12]
	and.16b	v2, v15, v2
	fmul.4s	v1, v1, v2
	and.16b	v2, v14, v3
	mov.16b	v3, v22
	fmul.4s	v0, v0, v2
	fadd.4s	v1, v17, v1
	bit.16b	v17, v1, v15
	fadd.4s	v0, v7, v0
	bit.16b	v7, v0, v14
	add	x30, x30, #32
	cmp	x30, #2048
	b.ne	LBB0_1085
; %bb.1086:                             ; %direct.false2771
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q23, [sp, #12464]               ; 16-byte Spill
	mov.16b	v1, v24
	mov.16b	v24, v21
	ldr	q10, [sp, #9536]                ; 16-byte Reload
	ldr	q0, [sp, #11888]                ; 16-byte Reload
	and.16b	v10, v0, v10
	ldr	q0, [sp, #11872]                ; 16-byte Reload
	ldr	q23, [sp, #9552]                ; 16-byte Reload
	and.16b	v23, v0, v23
	mov	w30, #24576                     ; =0x6000
	ldr	q9, [sp, #7392]                 ; 16-byte Reload
	str	q8, [sp, #12960]                ; 16-byte Spill
	ldr	q8, [sp, #9584]                 ; 16-byte Reload
	mov.16b	v20, v18
	mov.16b	v5, v1
	ldr	q11, [sp, #12576]               ; 16-byte Reload
	ldr	q6, [sp, #12672]                ; 16-byte Reload
	ldr	q18, [sp, #12656]               ; 16-byte Reload
	mov.16b	v21, v31
	mov.16b	v31, v30
	ldr	q30, [sp, #12432]               ; 16-byte Reload
LBB0_1087:                              ; %direct.true2974
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	subs	x12, x30, #6, lsl #12           ; =24576
	cset	w15, eq
	dup.4h	v0, w15
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	and.16b	v1, v0, v4
	cmp	x12, #32
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12816]               ; 16-byte Reload
	and.16b	v0, v0, v19
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #64
	cset	w15, eq
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12448]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	bit.16b	v1, v18, v3
	cmp	x12, #96
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v6, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #128
	cset	w15, eq
	ldr	q3, [sp, #12912]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13936]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13904]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #160
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13920]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #192
	cset	w15, eq
	ldr	q3, [sp, #13888]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13872]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13856]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #224
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v28, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #256
	cset	w15, eq
	ldr	q3, [sp, #13840]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13824]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12080]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #288
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13808]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #320
	cset	w15, eq
	bit.16b	v0, v24, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12640]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12608]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #352
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12624]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #384
	cset	w15, eq
	ldr	q3, [sp, #13984]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13968]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12928]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #416
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13952]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #448
	cset	w15, eq
	ldr	q3, [sp, #12288]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12272]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12240]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #480
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12256]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #512
	cset	w15, eq
	ldr	q3, [sp, #12224]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12096]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12192]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #544
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12208]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #576
	cset	w15, eq
	ldr	q3, [sp, #12592]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12176]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	bit.16b	v1, v31, v3
	cmp	x12, #608
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v30, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #640
	cset	w15, eq
	bit.16b	v0, v25, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v27, v2
	bit.16b	v1, v13, v3
	cmp	x12, #672
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v12, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #704
	cset	w15, eq
	bit.16b	v0, v21, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12160]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12112]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #736
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12128]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #768
	cset	w15, eq
	ldr	q3, [sp, #12320]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12416]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	bit.16b	v1, v26, v3
	cmp	x12, #800
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v16, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #832
	cset	w15, eq
	bit.16b	v0, v29, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12464]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12800]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #864
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v20, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #896
	cset	w15, eq
	bit.16b	v0, v5, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12784]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12960]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #928
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #960
	cset	w15, eq
	ldr	q3, [sp, #12896]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12944]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13792]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #992
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12880]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1024
	cset	w15, eq
	ldr	q3, [sp, #13776]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13760]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12864]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1056
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12560]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1088
	cset	w15, eq
	ldr	q3, [sp, #13744]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13728]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12768]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1120
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12848]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1152
	cset	w15, eq
	ldr	q3, [sp, #12832]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12752]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12736]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1184
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12544]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1216
	cset	w15, eq
	ldr	q3, [sp, #12528]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12720]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12704]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1248
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12512]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1280
	cset	w15, eq
	ldr	q3, [sp, #12496]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12688]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13712]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1312
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #12480]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1344
	cset	w15, eq
	ldr	q3, [sp, #13696]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13680]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13648]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1376
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13664]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1408
	cset	w15, eq
	ldr	q3, [sp, #13632]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13616]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13584]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1440
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13600]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1472
	cset	w15, eq
	ldr	q3, [sp, #13568]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13552]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13520]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1504
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13536]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1536
	cset	w15, eq
	ldr	q3, [sp, #13504]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13488]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13456]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1568
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13472]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1600
	cset	w15, eq
	ldr	q3, [sp, #13440]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13424]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13392]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1632
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13408]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1664
	cset	w15, eq
	ldr	q3, [sp, #13376]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13360]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13328]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1696
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13344]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1728
	cset	w15, eq
	ldr	q3, [sp, #13312]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13296]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13264]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1760
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13280]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1792
	cset	w15, eq
	ldr	q3, [sp, #13248]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13232]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13200]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1824
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13216]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1856
	cset	w15, eq
	ldr	q3, [sp, #13184]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13168]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13136]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1888
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13152]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1920
	cset	w15, eq
	ldr	q3, [sp, #13120]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13104]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13072]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1952
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q19, [sp, #13088]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1984
	cset	w15, eq
	ldr	q3, [sp, #13056]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13040]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13008]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #2016
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13024]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #12992]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	add	x12, x8, x30
	ldr	q3, [sp, #12976]                ; 16-byte Reload
	bit.16b	v1, v3, v2
	ldp	q3, q2, [x12]
	and.16b	v2, v15, v2
	fmul.4s	v1, v1, v2
	and.16b	v2, v14, v3
	mov.16b	v3, v22
	fmul.4s	v0, v0, v2
	fadd.4s	v1, v10, v1
	bit.16b	v10, v1, v15
	fadd.4s	v0, v23, v0
	bit.16b	v23, v0, v14
	add	x30, x30, #32
	cmp	x30, x25
	b.ne	LBB0_1087
; %bb.1088:                             ; %direct.false2975
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q10, [sp, #9536]                ; 16-byte Spill
	str	q23, [sp, #9552]                ; 16-byte Spill
	mov	x30, #0                         ; =0x0
	ldr	q10, [sp, #9568]                ; 16-byte Reload
	ldr	q0, [sp, #11888]                ; 16-byte Reload
	and.16b	v10, v0, v10
	ldr	q0, [sp, #11872]                ; 16-byte Reload
	and.16b	v8, v0, v8
	mov.16b	v23, v29
	ldr	q29, [sp, #12096]               ; 16-byte Reload
LBB0_1089:                              ; %direct.true3178
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x30, #0
	cset	w12, eq
	dup.4h	v0, w12
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	and.16b	v1, v0, v4
	cmp	x30, #32
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12816]               ; 16-byte Reload
	and.16b	v0, v0, v19
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #64
	cset	w12, eq
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12448]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	bit.16b	v1, v18, v3
	cmp	x30, #96
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v6, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #128
	cset	w12, eq
	ldr	q3, [sp, #12912]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13936]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13904]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #160
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13920]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #192
	cset	w12, eq
	ldr	q3, [sp, #13888]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13872]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13856]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #224
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v28, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #256
	cset	w12, eq
	ldr	q3, [sp, #13840]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13824]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12080]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #288
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13808]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #320
	cset	w12, eq
	bit.16b	v0, v24, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12640]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12608]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #352
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12624]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #384
	cset	w12, eq
	ldr	q3, [sp, #13984]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13968]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12928]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #416
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13952]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #448
	cset	w12, eq
	ldr	q3, [sp, #12288]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12272]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12240]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #480
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12256]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #512
	cset	w12, eq
	ldr	q3, [sp, #12224]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v29, v2
	ldr	q2, [sp, #12192]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #544
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12208]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #576
	cset	w12, eq
	ldr	q3, [sp, #12592]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12176]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	bit.16b	v1, v31, v3
	cmp	x30, #608
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v30, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #640
	cset	w12, eq
	bit.16b	v0, v25, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v27, v2
	bit.16b	v1, v13, v3
	cmp	x30, #672
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v12, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #704
	cset	w12, eq
	bit.16b	v0, v21, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12160]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12112]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #736
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12128]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #768
	cset	w12, eq
	ldr	q3, [sp, #12320]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12416]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	bit.16b	v1, v26, v3
	cmp	x30, #800
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v16, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #832
	cset	w12, eq
	bit.16b	v0, v23, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12464]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12800]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #864
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v20, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #896
	cset	w12, eq
	bit.16b	v0, v5, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12784]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12960]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #928
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v11, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #960
	cset	w12, eq
	ldr	q3, [sp, #12896]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12944]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13792]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #992
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12880]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1024
	cset	w12, eq
	ldr	q3, [sp, #13776]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13760]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12864]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1056
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12560]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1088
	cset	w12, eq
	ldr	q3, [sp, #13744]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13728]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12768]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1120
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12848]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1152
	cset	w12, eq
	ldr	q3, [sp, #12832]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12752]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12736]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1184
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12544]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1216
	cset	w12, eq
	ldr	q3, [sp, #12528]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12720]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #12704]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1248
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12512]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1280
	cset	w12, eq
	ldr	q3, [sp, #12496]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #12688]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13712]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1312
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #12480]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1344
	cset	w12, eq
	ldr	q3, [sp, #13696]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13680]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13648]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1376
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13664]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1408
	cset	w12, eq
	ldr	q3, [sp, #13632]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13616]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13584]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1440
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13600]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1472
	cset	w12, eq
	ldr	q3, [sp, #13568]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13552]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13520]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1504
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13536]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1536
	cset	w12, eq
	ldr	q3, [sp, #13504]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13488]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13456]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1568
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13472]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1600
	cset	w12, eq
	ldr	q3, [sp, #13440]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13424]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13392]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1632
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13408]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1664
	cset	w12, eq
	ldr	q3, [sp, #13376]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13360]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13328]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1696
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13344]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1728
	cset	w12, eq
	ldr	q3, [sp, #13312]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13296]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13264]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1760
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13280]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1792
	cset	w12, eq
	ldr	q3, [sp, #13248]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13232]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13200]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1824
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13216]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1856
	cset	w12, eq
	ldr	q3, [sp, #13184]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13168]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13136]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1888
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13152]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1920
	cset	w12, eq
	ldr	q3, [sp, #13120]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13104]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13072]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1952
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13088]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1984
	cset	w12, eq
	ldr	q3, [sp, #13056]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q19, [sp, #13040]               ; 16-byte Reload
	bit.16b	v1, v19, v2
	ldr	q2, [sp, #13008]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #2016
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q19, [sp, #13024]               ; 16-byte Reload
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #12992]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	add	x12, x26, x30
	ldr	q3, [sp, #12976]                ; 16-byte Reload
	bit.16b	v1, v3, v2
	ldp	q3, q2, [x12]
	and.16b	v2, v15, v2
	fmul.4s	v1, v1, v2
	and.16b	v2, v14, v3
	mov.16b	v3, v22
	fmul.4s	v0, v0, v2
	fadd.4s	v1, v10, v1
	bit.16b	v10, v1, v15
	fadd.4s	v0, v8, v0
	bit.16b	v8, v0, v14
	add	x30, x30, #32
	cmp	x30, #2048
	b.ne	LBB0_1089
; %bb.1090:                             ; %direct.false3179
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q10, [sp, #9568]                ; 16-byte Spill
	str	q17, [sp, #9680]                ; 16-byte Spill
	str	q7, [sp, #9696]                 ; 16-byte Spill
	ldr	q7, [sp, #9600]                 ; 16-byte Reload
	ldr	q0, [sp, #11888]                ; 16-byte Reload
	and.16b	v7, v0, v7
	ldr	q0, [sp, #11872]                ; 16-byte Reload
	and.16b	v9, v0, v9
	mov	w30, #28672                     ; =0x7000
	str	q16, [sp, #12400]               ; 16-byte Spill
	mov.16b	v11, v24
	mov.16b	v19, v30
	ldr	q30, [sp, #12288]               ; 16-byte Reload
	ldr	q26, [sp, #12272]               ; 16-byte Reload
	mov.16b	v0, v29
	ldr	q29, [sp, #12256]               ; 16-byte Reload
	mov.16b	v24, v27
	mov.16b	v1, v31
	ldr	q31, [sp, #12240]               ; 16-byte Reload
	ldr	q27, [sp, #12224]               ; 16-byte Reload
	mov.16b	v28, v0
	mov.16b	v0, v21
	ldr	q21, [sp, #12208]               ; 16-byte Reload
	ldr	q18, [sp, #12192]               ; 16-byte Reload
	ldr	q6, [sp, #12592]                ; 16-byte Reload
	ldr	q16, [sp, #12176]               ; 16-byte Reload
	mov.16b	v23, v1
	mov.16b	v5, v0
	ldr	q20, [sp, #12160]               ; 16-byte Reload
	ldr	q10, [sp, #12944]               ; 16-byte Reload
LBB0_1091:                              ; %direct.true3382
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	subs	x12, x30, #7, lsl #12           ; =28672
	cset	w15, eq
	dup.4h	v0, w15
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	and.16b	v1, v0, v4
	cmp	x12, #32
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q17, [sp, #12816]               ; 16-byte Reload
	and.16b	v0, v0, v17
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #64
	cset	w15, eq
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #12448]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #12656]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #96
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q17, [sp, #12672]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #128
	cset	w15, eq
	ldr	q3, [sp, #12912]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13936]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #13904]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #160
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q17, [sp, #13920]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #192
	cset	w15, eq
	ldr	q3, [sp, #13888]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13872]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #13856]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #224
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q17, [sp, #12304]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #256
	cset	w15, eq
	ldr	q3, [sp, #13840]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13824]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #12080]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #288
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q17, [sp, #13808]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #320
	cset	w15, eq
	bit.16b	v0, v11, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #12640]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #12608]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #352
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q17, [sp, #12624]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #384
	cset	w15, eq
	ldr	q3, [sp, #13984]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13968]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #12928]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #416
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q17, [sp, #13952]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #448
	cset	w15, eq
	bit.16b	v0, v30, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v26, v2
	bit.16b	v1, v31, v3
	cmp	x12, #480
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v29, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #512
	cset	w15, eq
	bit.16b	v0, v27, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v28, v2
	bit.16b	v1, v18, v3
	cmp	x12, #544
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v21, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #576
	cset	w15, eq
	bit.16b	v0, v6, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v16, v2
	bit.16b	v1, v23, v3
	cmp	x12, #608
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #640
	cset	w15, eq
	bit.16b	v0, v25, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v24, v2
	bit.16b	v1, v13, v3
	cmp	x12, #672
	cset	w15, eq
	dup.4h	v2, w15
	bit.16b	v0, v12, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #704
	cset	w15, eq
	bit.16b	v0, v5, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v20, v2
	ldr	q2, [sp, #12112]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #736
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q17, [sp, #12128]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #768
	cset	w15, eq
	ldr	q3, [sp, #12320]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #12416]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #12368]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #800
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q17, [sp, #12400]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #832
	cset	w15, eq
	ldr	q3, [sp, #12064]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #12464]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #12800]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #864
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q17, [sp, #12352]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #896
	cset	w15, eq
	ldr	q3, [sp, #12336]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #12784]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #12960]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #928
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q17, [sp, #12576]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #960
	cset	w15, eq
	ldr	q3, [sp, #12896]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v10, v2
	ldr	q2, [sp, #13792]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #992
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q17, [sp, #12880]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1024
	cset	w15, eq
	ldr	q3, [sp, #13776]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13760]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #12864]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1056
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q17, [sp, #12560]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1088
	cset	w15, eq
	ldr	q3, [sp, #13744]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13728]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #12768]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1120
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q17, [sp, #12848]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1152
	cset	w15, eq
	ldr	q3, [sp, #12832]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #12752]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #12736]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1184
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q17, [sp, #12544]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1216
	cset	w15, eq
	ldr	q3, [sp, #12528]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #12720]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #12704]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1248
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q17, [sp, #12512]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1280
	cset	w15, eq
	ldr	q3, [sp, #12496]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #12688]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #13712]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1312
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q17, [sp, #12480]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1344
	cset	w15, eq
	ldr	q3, [sp, #13696]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13680]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #13648]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1376
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q17, [sp, #13664]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1408
	cset	w15, eq
	ldr	q3, [sp, #13632]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13616]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #13584]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1440
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q17, [sp, #13600]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1472
	cset	w15, eq
	ldr	q3, [sp, #13568]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13552]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #13520]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1504
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q17, [sp, #13536]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1536
	cset	w15, eq
	ldr	q3, [sp, #13504]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13488]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #13456]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1568
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q17, [sp, #13472]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1600
	cset	w15, eq
	ldr	q3, [sp, #13440]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13424]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #13392]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1632
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q17, [sp, #13408]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1664
	cset	w15, eq
	ldr	q3, [sp, #13376]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13360]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #13328]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1696
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q17, [sp, #13344]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1728
	cset	w15, eq
	ldr	q3, [sp, #13312]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13296]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #13264]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1760
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q17, [sp, #13280]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1792
	cset	w15, eq
	ldr	q3, [sp, #13248]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13232]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #13200]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1824
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q17, [sp, #13216]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1856
	cset	w15, eq
	ldr	q3, [sp, #13184]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13168]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #13136]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1888
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q17, [sp, #13152]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1920
	cset	w15, eq
	ldr	q3, [sp, #13120]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13104]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #13072]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #1952
	cset	w15, eq
	dup.4h	v2, w15
	ldr	q17, [sp, #13088]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x12, #1984
	cset	w15, eq
	ldr	q3, [sp, #13056]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w15
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13040]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #13008]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x12, #2016
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q17, [sp, #13024]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #12992]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	add	x12, x8, x30
	ldr	q3, [sp, #12976]                ; 16-byte Reload
	bit.16b	v1, v3, v2
	ldp	q3, q2, [x12]
	and.16b	v2, v15, v2
	fmul.4s	v1, v1, v2
	and.16b	v2, v14, v3
	mov.16b	v3, v22
	fmul.4s	v0, v0, v2
	fadd.4s	v1, v7, v1
	bit.16b	v7, v1, v15
	fadd.4s	v0, v9, v0
	bit.16b	v9, v0, v14
	add	x30, x30, #32
	cmp	x30, x27
	b.ne	LBB0_1091
; %bb.1092:                             ; %direct.false3383
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q8, [sp, #9584]                 ; 16-byte Spill
	str	q7, [sp, #9600]                 ; 16-byte Spill
	mov	x30, #0                         ; =0x0
	str	q10, [sp, #12944]               ; 16-byte Spill
	ldr	q10, [sp, #7296]                ; 16-byte Reload
	ldr	q0, [sp, #11888]                ; 16-byte Reload
	and.16b	v10, v0, v10
	ldr	q8, [sp, #7312]                 ; 16-byte Reload
	ldr	q0, [sp, #11872]                ; 16-byte Reload
	and.16b	v8, v0, v8
	mov.16b	v11, v18
	mov.16b	v18, v6
	ldr	q7, [sp, #12928]                ; 16-byte Reload
	ldr	q17, [sp, #12912]               ; 16-byte Reload
LBB0_1093:                              ; %direct.true3586
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x30, #0
	cset	w12, eq
	dup.4h	v0, w12
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	and.16b	v1, v0, v4
	cmp	x30, #32
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q6, [sp, #12816]                ; 16-byte Reload
	and.16b	v0, v0, v6
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #64
	cset	w12, eq
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q6, [sp, #12448]                ; 16-byte Reload
	bit.16b	v1, v6, v2
	ldr	q2, [sp, #12656]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #96
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q6, [sp, #12672]                ; 16-byte Reload
	bit.16b	v0, v6, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #128
	cset	w12, eq
	bit.16b	v0, v17, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q6, [sp, #13936]                ; 16-byte Reload
	bit.16b	v1, v6, v2
	ldr	q2, [sp, #13904]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #160
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q6, [sp, #13920]                ; 16-byte Reload
	bit.16b	v0, v6, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #192
	cset	w12, eq
	ldr	q3, [sp, #13888]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q6, [sp, #13872]                ; 16-byte Reload
	bit.16b	v1, v6, v2
	ldr	q2, [sp, #13856]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #224
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q6, [sp, #12304]                ; 16-byte Reload
	bit.16b	v0, v6, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #256
	cset	w12, eq
	ldr	q3, [sp, #13840]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q6, [sp, #13824]                ; 16-byte Reload
	bit.16b	v1, v6, v2
	ldr	q2, [sp, #12080]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #288
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q6, [sp, #13808]                ; 16-byte Reload
	bit.16b	v0, v6, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #320
	cset	w12, eq
	ldr	q3, [sp, #12384]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q6, [sp, #12640]                ; 16-byte Reload
	bit.16b	v1, v6, v2
	ldr	q2, [sp, #12608]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #352
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q6, [sp, #12624]                ; 16-byte Reload
	bit.16b	v0, v6, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #384
	cset	w12, eq
	ldr	q3, [sp, #13984]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q6, [sp, #13968]                ; 16-byte Reload
	bit.16b	v1, v6, v2
	bit.16b	v1, v7, v3
	cmp	x30, #416
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q6, [sp, #13952]                ; 16-byte Reload
	bit.16b	v0, v6, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #448
	cset	w12, eq
	bit.16b	v0, v30, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v26, v2
	bit.16b	v1, v31, v3
	cmp	x30, #480
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v29, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #512
	cset	w12, eq
	bit.16b	v0, v27, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v28, v2
	bit.16b	v1, v11, v3
	cmp	x30, #544
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v21, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #576
	cset	w12, eq
	bit.16b	v0, v18, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v16, v2
	bit.16b	v1, v23, v3
	cmp	x30, #608
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v19, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #640
	cset	w12, eq
	bit.16b	v0, v25, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v24, v2
	bit.16b	v1, v13, v3
	cmp	x30, #672
	cset	w12, eq
	dup.4h	v2, w12
	bit.16b	v0, v12, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #704
	cset	w12, eq
	bit.16b	v0, v5, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v20, v2
	ldr	q2, [sp, #12112]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #736
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q6, [sp, #12128]                ; 16-byte Reload
	bit.16b	v0, v6, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #768
	cset	w12, eq
	ldr	q3, [sp, #12320]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q6, [sp, #12416]                ; 16-byte Reload
	bit.16b	v1, v6, v2
	ldr	q2, [sp, #12368]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #800
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q6, [sp, #12400]                ; 16-byte Reload
	bit.16b	v0, v6, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #832
	cset	w12, eq
	ldr	q3, [sp, #12064]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q6, [sp, #12464]                ; 16-byte Reload
	bit.16b	v1, v6, v2
	ldr	q2, [sp, #12800]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #864
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q6, [sp, #12352]                ; 16-byte Reload
	bit.16b	v0, v6, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #896
	cset	w12, eq
	ldr	q3, [sp, #12336]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q6, [sp, #12784]                ; 16-byte Reload
	bit.16b	v1, v6, v2
	ldr	q2, [sp, #12960]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #928
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q6, [sp, #12576]                ; 16-byte Reload
	bit.16b	v0, v6, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #960
	cset	w12, eq
	ldr	q3, [sp, #12896]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q6, [sp, #12944]                ; 16-byte Reload
	bit.16b	v1, v6, v2
	ldr	q2, [sp, #13792]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #992
	cset	w12, eq
	dup.4h	v2, w12
	mov.16b	v6, v17
	ldr	q17, [sp, #12880]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1024
	cset	w12, eq
	ldr	q3, [sp, #13776]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13760]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #12864]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1056
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q17, [sp, #12560]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1088
	cset	w12, eq
	ldr	q3, [sp, #13744]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13728]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #12768]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1120
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q17, [sp, #12848]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1152
	cset	w12, eq
	ldr	q3, [sp, #12832]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #12752]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #12736]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1184
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q17, [sp, #12544]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1216
	cset	w12, eq
	ldr	q3, [sp, #12528]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #12720]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #12704]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1248
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q17, [sp, #12512]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1280
	cset	w12, eq
	ldr	q3, [sp, #12496]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #12688]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #13712]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1312
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q17, [sp, #12480]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1344
	cset	w12, eq
	ldr	q3, [sp, #13696]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13680]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #13648]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1376
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q17, [sp, #13664]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1408
	cset	w12, eq
	ldr	q3, [sp, #13632]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13616]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #13584]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1440
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q17, [sp, #13600]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1472
	cset	w12, eq
	ldr	q3, [sp, #13568]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13552]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #13520]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1504
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q17, [sp, #13536]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1536
	cset	w12, eq
	ldr	q3, [sp, #13504]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13488]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #13456]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1568
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q17, [sp, #13472]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1600
	cset	w12, eq
	ldr	q3, [sp, #13440]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13424]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #13392]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1632
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q17, [sp, #13408]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1664
	cset	w12, eq
	ldr	q3, [sp, #13376]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13360]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #13328]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1696
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q17, [sp, #13344]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1728
	cset	w12, eq
	ldr	q3, [sp, #13312]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13296]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #13264]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1760
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q17, [sp, #13280]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1792
	cset	w12, eq
	ldr	q3, [sp, #13248]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13232]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #13200]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1824
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q17, [sp, #13216]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1856
	cset	w12, eq
	ldr	q3, [sp, #13184]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13168]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #13136]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1888
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q17, [sp, #13152]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1920
	cset	w12, eq
	ldr	q3, [sp, #13120]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13104]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #13072]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #1952
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q17, [sp, #13088]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	cmp	x30, #1984
	cset	w12, eq
	ldr	q3, [sp, #13056]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	dup.4h	v3, w12
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q17, [sp, #13040]               ; 16-byte Reload
	bit.16b	v1, v17, v2
	ldr	q2, [sp, #13008]                ; 16-byte Reload
	bit.16b	v1, v2, v3
	cmp	x30, #2016
	cset	w12, eq
	dup.4h	v2, w12
	ldr	q17, [sp, #13024]               ; 16-byte Reload
	bit.16b	v0, v17, v3
	mov.16b	v17, v6
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #12992]                ; 16-byte Reload
	bit.16b	v0, v3, v2
	add	x12, x28, x30
	ldr	q3, [sp, #12976]                ; 16-byte Reload
	bit.16b	v1, v3, v2
	ldp	q3, q2, [x12]
	and.16b	v2, v15, v2
	fmul.4s	v1, v1, v2
	and.16b	v2, v14, v3
	mov.16b	v3, v22
	fmul.4s	v0, v0, v2
	fadd.4s	v1, v10, v1
	bit.16b	v10, v1, v15
	fadd.4s	v0, v8, v0
	bit.16b	v8, v0, v14
	add	x30, x30, #32
	cmp	x30, #2048
	b.ne	LBB0_1093
; %bb.1094:                             ; %direct.false3587
                                        ;   in Loop: Header=BB0_1026 Depth=1
	mov	x12, #0                         ; =0x0
	movi.4s	v16, #62, lsl #24
	ldr	q0, [sp, #9328]                 ; 16-byte Reload
	fmul.4s	v3, v0, v16
	add	x15, x8, #16, lsl #12           ; =65536
	ldp	q0, q1, [x15]
	ldr	q2, [sp, #9312]                 ; 16-byte Reload
	fmul.4s	v6, v2, v16
	bit.16b	v1, v6, v15
	bit.16b	v0, v3, v14
	stp	q0, q1, [x15]
	mov.16b	v19, v10
	ldr	q0, [sp, #9360]                 ; 16-byte Reload
	fmul.4s	v10, v0, v16
	ldr	q0, [sp, #9344]                 ; 16-byte Reload
	fmul.4s	v31, v0, v16
	ldr	q0, [sp, #9392]                 ; 16-byte Reload
	fmul.4s	v30, v0, v16
	ldr	q0, [sp, #9376]                 ; 16-byte Reload
	fmul.4s	v29, v0, v16
	ldr	q0, [sp, #9424]                 ; 16-byte Reload
	fmul.4s	v24, v0, v16
	ldr	x15, [sp, #4376]                ; 8-byte Reload
	ldp	q2, q4, [x15]
	ldr	q0, [sp, #9408]                 ; 16-byte Reload
	fmul.4s	v18, v0, v16
	bit.16b	v4, v31, v15
	bit.16b	v2, v10, v14
	stp	q2, q4, [x15]
	ldr	q2, [sp, #9456]                 ; 16-byte Reload
	fmul.4s	v23, v2, v16
	ldr	q2, [sp, #9440]                 ; 16-byte Reload
	fmul.4s	v22, v2, v16
	ldr	q2, [sp, #9488]                 ; 16-byte Reload
	fmul.4s	v21, v2, v16
	ldr	x15, [sp, #4368]                ; 8-byte Reload
	ldp	q2, q4, [x15]
	ldr	q5, [sp, #9472]                 ; 16-byte Reload
	fmul.4s	v20, v5, v16
	bit.16b	v4, v29, v15
	bit.16b	v2, v30, v14
	stp	q2, q4, [x15]
	ldr	q2, [sp, #9520]                 ; 16-byte Reload
	fmul.4s	v1, v2, v16
	ldr	q2, [sp, #9504]                 ; 16-byte Reload
	fmul.4s	v4, v2, v16
	ldr	q2, [sp, #9728]                 ; 16-byte Reload
	fmul.4s	v0, v2, v16
	ldr	x15, [sp, #4360]                ; 8-byte Reload
	ldp	q5, q7, [x15]
	ldr	q17, [sp, #9712]                ; 16-byte Reload
	fmul.4s	v28, v17, v16
	str	q18, [sp, #6896]                ; 16-byte Spill
	bit.16b	v7, v18, v15
	str	q24, [sp, #6880]                ; 16-byte Spill
	bit.16b	v5, v24, v14
	stp	q5, q7, [x15]
	mov.16b	v18, v8
	mov.16b	v8, v14
	ldr	q5, [sp, #9760]                 ; 16-byte Reload
	fmul.4s	v13, v5, v16
	ldr	q5, [sp, #9744]                 ; 16-byte Reload
	fmul.4s	v12, v5, v16
	ldr	q5, [sp, #9616]                 ; 16-byte Reload
	fmul.4s	v11, v5, v16
	ldr	x15, [sp, #4352]                ; 8-byte Reload
	ldp	q5, q7, [x15]
	ldr	q17, [sp, #9632]                ; 16-byte Reload
	fmul.4s	v27, v17, v16
	str	q22, [sp, #6800]                ; 16-byte Spill
	bit.16b	v7, v22, v15
	str	q23, [sp, #6784]                ; 16-byte Spill
	bit.16b	v5, v23, v14
	stp	q5, q7, [x15]
	ldr	q5, [sp, #9648]                 ; 16-byte Reload
	fmul.4s	v26, v5, v16
	ldr	q5, [sp, #9664]                 ; 16-byte Reload
	fmul.4s	v25, v5, v16
	ldr	q5, [sp, #9680]                 ; 16-byte Reload
	fmul.4s	v24, v5, v16
	ldr	x15, [sp, #4344]                ; 8-byte Reload
	ldp	q5, q7, [x15]
	ldr	q17, [sp, #9696]                ; 16-byte Reload
	fmul.4s	v23, v17, v16
	str	q20, [sp, #6704]                ; 16-byte Spill
	bit.16b	v7, v20, v15
	str	q21, [sp, #6688]                ; 16-byte Spill
	bit.16b	v5, v21, v14
	stp	q5, q7, [x15]
	ldr	q5, [sp, #9536]                 ; 16-byte Reload
	fmul.4s	v22, v5, v16
	ldr	q5, [sp, #9552]                 ; 16-byte Reload
	fmul.4s	v21, v5, v16
	ldr	q5, [sp, #9584]                 ; 16-byte Reload
	fmul.4s	v20, v5, v16
	ldr	x15, [sp, #4336]                ; 8-byte Reload
	ldp	q5, q7, [x15]
	ldr	q17, [sp, #9568]                ; 16-byte Reload
	fmul.4s	v17, v17, v16
	str	q4, [sp, #6608]                 ; 16-byte Spill
	bit.16b	v7, v4, v15
	str	q1, [sp, #6592]                 ; 16-byte Spill
	bit.16b	v5, v1, v14
	stp	q5, q7, [x15]
	ldr	q5, [sp, #9600]                 ; 16-byte Reload
	fmul.4s	v4, v5, v16
	str	q9, [sp, #7392]                 ; 16-byte Spill
	fmul.4s	v2, v9, v16
	ldr	x15, [sp, #4328]                ; 8-byte Reload
	ldp	q5, q7, [x15]
	str	q28, [sp, #6512]                ; 16-byte Spill
	bit.16b	v7, v28, v15
	str	q0, [sp, #6496]                 ; 16-byte Spill
	bit.16b	v5, v0, v14
	stp	q5, q7, [x15]
	ldr	x15, [sp, #4320]                ; 8-byte Reload
	ldp	q5, q7, [x15]
	str	q12, [sp, #6448]                ; 16-byte Spill
	bit.16b	v7, v12, v15
	str	q13, [sp, #6432]                ; 16-byte Spill
	bit.16b	v5, v13, v14
	stp	q5, q7, [x15]
	ldr	x15, [sp, #4312]                ; 8-byte Reload
	ldp	q7, q5, [x15]
	str	q27, [sp, #6544]                ; 16-byte Spill
	bit.16b	v7, v27, v14
	str	q11, [sp, #6528]                ; 16-byte Spill
	bit.16b	v5, v11, v15
	stp	q7, q5, [x15]
	ldr	x15, [sp, #4304]                ; 8-byte Reload
	ldp	q7, q5, [x15]
	str	q25, [sp, #6640]                ; 16-byte Spill
	bit.16b	v7, v25, v14
	str	q26, [sp, #6624]                ; 16-byte Spill
	bit.16b	v5, v26, v15
	stp	q7, q5, [x15]
	ldr	x15, [sp, #4296]                ; 8-byte Reload
	ldp	q7, q5, [x15]
	str	q23, [sp, #6736]                ; 16-byte Spill
	bit.16b	v7, v23, v14
	str	q24, [sp, #6720]                ; 16-byte Spill
	bit.16b	v5, v24, v15
	stp	q7, q5, [x15]
	ldr	x15, [sp, #4288]                ; 8-byte Reload
	ldp	q7, q5, [x15]
	str	q21, [sp, #6832]                ; 16-byte Spill
	bit.16b	v7, v21, v14
	str	q22, [sp, #6816]                ; 16-byte Spill
	bit.16b	v5, v22, v15
	stp	q7, q5, [x15]
	ldr	x15, [sp, #4280]                ; 8-byte Reload
	ldp	q5, q7, [x15]
	str	q17, [sp, #6928]                ; 16-byte Spill
	bit.16b	v7, v17, v15
	str	q20, [sp, #6912]                ; 16-byte Spill
	bit.16b	v5, v20, v14
	stp	q5, q7, [x15]
	ldr	x15, [sp, #4272]                ; 8-byte Reload
	ldp	q7, q5, [x15]
	str	q2, [sp, #7024]                 ; 16-byte Spill
	bit.16b	v7, v2, v14
	str	q4, [sp, #7008]                 ; 16-byte Spill
	bit.16b	v5, v4, v15
	stp	q7, q5, [x15]
	str	q18, [sp, #7312]                ; 16-byte Spill
	fmul.4s	v2, v18, v16
	ldr	x15, [sp, #4264]                ; 8-byte Reload
	ldp	q5, q7, [x15]
	str	q2, [sp, #7152]                 ; 16-byte Spill
	bit.16b	v5, v2, v14
	str	q19, [sp, #7296]                ; 16-byte Spill
	fmul.4s	v2, v19, v16
	str	q2, [sp, #7136]                 ; 16-byte Spill
	bit.16b	v7, v2, v15
	stp	q5, q7, [x15]
	mvni.4s	v5, #127, msl #16
	ldr	q17, [sp, #7328]                ; 16-byte Reload
	bit.16b	v17, v5, v15
	mvni.4s	v24, #127, msl #16
	ldr	q16, [sp, #7344]                ; 16-byte Reload
	bit.16b	v16, v5, v14
LBB0_1095:                              ; %direct.true3887
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x15, x2, x12
	ldp	q5, q7, [x15]
	and.16b	v7, v15, v7
	and.16b	v5, v8, v5
	fmaxnm.4s	v5, v16, v5
	fmaxnm.4s	v7, v17, v7
	bit.16b	v17, v7, v15
	bit.16b	v16, v5, v8
	add	x12, x12, #32
	cmp	x12, #512
	b.ne	LBB0_1095
; %bb.1096:                             ; %direct.false3888
                                        ;   in Loop: Header=BB0_1026 Depth=1
	mov	x30, #0                         ; =0x0
	str	q16, [sp, #7344]                ; 16-byte Spill
	ldr	q2, [sp, #11840]                ; 16-byte Reload
	fmaxnm.4s	v25, v2, v16
	fsub.4s	v3, v3, v25
	and.16b	v2, v8, v3
	mov	w12, #-1026555904               ; =0xc2d00000
	dup.4s	v5, w12
	fcmge.4s	v7, v2, v5
	mov	w12, #1120403456                ; =0x42c80000
	dup.4s	v3, w12
	fcmge.4s	v16, v3, v2
	and.16b	v7, v7, v16
	str	q17, [sp, #7328]                ; 16-byte Spill
	ldr	q4, [sp, #11856]                ; 16-byte Reload
	fmaxnm.4s	v14, v4, v17
	fsub.4s	v6, v6, v14
	and.16b	v4, v15, v6
	fcmge.4s	v6, v4, v5
	fcmge.4s	v16, v3, v4
	and.16b	v16, v6, v16
	mov	w12, #43579                     ; =0xaa3b
	movk	w12, #16312, lsl #16
	dup.4s	v26, w12
	and.16b	v16, v16, v4
	fmul.4s	v17, v16, v26
	movi.4s	v19, #75, lsl #24
	mvni.4s	v20, #128, lsl #24
	mov.16b	v18, v20
	bsl.16b	v18, v19, v17
	fadd.4s	v17, v17, v18
	fsub.4s	v17, v17, v18
	and.16b	v18, v7, v2
	fmul.4s	v7, v18, v26
	bif.16b	v19, v7, v20
	fadd.4s	v7, v7, v19
	fsub.4s	v19, v7, v19
	fcvtzs.4s	v23, v17
	scvtf.4s	v17, v23
	mov	w12, #29184                     ; =0x7200
	movk	w12, #16177, lsl #16
	dup.4s	v7, w12
	fmul.4s	v20, v17, v7
	fsub.4s	v20, v16, v20
	fcvtzs.4s	v11, v19
	scvtf.4s	v19, v11
	fmul.4s	v16, v19, v7
	fsub.4s	v18, v18, v16
	mov	w12, #48782                     ; =0xbe8e
	movk	w12, #13759, lsl #16
	dup.4s	v16, w12
	fmul.4s	v19, v19, v16
	fsub.4s	v12, v18, v19
	fmul.4s	v17, v17, v16
	fsub.4s	v13, v20, v17
	mov	w12, #11226                     ; =0x2bda
	movk	w12, #14672, lsl #16
	dup.4s	v17, w12
	mov	w12, #38601                     ; =0x96c9
	movk	w12, #15030, lsl #16
	dup.4s	v18, w12
	fmul.4s	v19, v13, v17
	fadd.4s	v19, v19, v18
	fmul.4s	v20, v13, v19
	mov	w12, #34982                     ; =0x88a6
	movk	w12, #15368, lsl #16
	dup.4s	v19, w12
	fadd.4s	v20, v20, v19
	fmul.4s	v21, v13, v20
	mov	w12, #43642                     ; =0xaa7a
	movk	w12, #15658, lsl #16
	dup.4s	v6, w12
	fadd.4s	v15, v21, v6
	mov	w12, #43691                     ; =0xaaab
	movk	w12, #15914, lsl #16
	dup.4s	v21, w12
	fmul.4s	v15, v13, v15
	fadd.4s	v15, v15, v21
	fmul.4s	v15, v13, v15
	movi.4s	v20, #63, lsl #24
	fadd.4s	v15, v15, v20
	movi.4s	v27, #63, lsl #24
	fmul.4s	v22, v13, v13
	fmul.4s	v22, v22, v15
	fmul.4s	v15, v12, v17
	fadd.4s	v15, v15, v18
	fmul.4s	v15, v12, v15
	fadd.4s	v15, v15, v19
	fmul.4s	v15, v12, v15
	fadd.4s	v15, v15, v6
	fmul.4s	v15, v12, v15
	fadd.4s	v15, v15, v21
	fmul.4s	v15, v12, v15
	fadd.4s	v15, v15, v27
	fmul.4s	v9, v12, v12
	fmul.4s	v9, v9, v15
	fadd.4s	v9, v12, v9
	fadd.4s	v22, v13, v22
	fmov.4s	v20, #1.00000000
	fadd.4s	v9, v9, v20
	sshr.4s	v12, v11, #1
	shl.4s	v13, v12, #23
	add.4s	v13, v13, v20
	fmul.4s	v9, v9, v13
	fadd.4s	v22, v22, v20
	sshr.4s	v13, v23, #1
	shl.4s	v15, v13, #23
	add.4s	v15, v15, v20
	fmul.4s	v22, v22, v15
	sub.4s	v11, v11, v12
	sub.4s	v23, v23, v13
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v20
	fmul.4s	v22, v22, v23
	shl.4s	v23, v11, #23
	add.4s	v23, v23, v20
	fmul.4s	v23, v9, v23
	str	q2, [sp, #7104]                 ; 16-byte Spill
	fcmgt.4s	v9, v5, v2
	bic.16b	v9, v23, v9
	str	q4, [sp, #11888]                ; 16-byte Spill
	fcmgt.4s	v23, v5, v4
	bic.16b	v22, v22, v23
	fcmgt.4s	v11, v4, v3
	fneg.4s	v23, v24
	mov.16b	v4, v11
	bsl.16b	v4, v23, v22
	str	q4, [sp, #11872]                ; 16-byte Spill
	fcmgt.4s	v22, v2, v3
	mov.16b	v2, v22
	bsl.16b	v2, v23, v9
	str	q2, [sp, #7120]                 ; 16-byte Spill
	fsub.4s	v22, v10, v25
	and.16b	v24, v8, v22
	fcmge.4s	v22, v24, v5
	fcmge.4s	v9, v3, v24
	and.16b	v22, v22, v9
	fsub.4s	v31, v31, v14
	ldr	q9, [sp, #11904]                ; 16-byte Reload
	and.16b	v15, v9, v31
	fcmge.4s	v31, v15, v5
	fcmge.4s	v9, v3, v15
	and.16b	v31, v31, v9
	and.16b	v9, v31, v15
	fmul.4s	v31, v9, v26
	movi.4s	v2, #75, lsl #24
	mvni.4s	v4, #128, lsl #24
	mov.16b	v10, v4
	bsl.16b	v10, v2, v31
	fadd.4s	v31, v31, v10
	fsub.4s	v31, v31, v10
	and.16b	v22, v22, v24
	fmul.4s	v10, v22, v26
	mov.16b	v11, v4
	bsl.16b	v11, v2, v10
	fadd.4s	v10, v10, v11
	fsub.4s	v10, v10, v11
	fcvtzs.4s	v31, v31
	scvtf.4s	v11, v31
	fmul.4s	v12, v11, v7
	fsub.4s	v9, v9, v12
	fcvtzs.4s	v10, v10
	scvtf.4s	v12, v10
	fmul.4s	v13, v12, v7
	fsub.4s	v22, v22, v13
	fmul.4s	v12, v12, v16
	fsub.4s	v22, v22, v12
	fmul.4s	v11, v11, v16
	fsub.4s	v9, v9, v11
	fmul.4s	v11, v9, v17
	fadd.4s	v11, v11, v18
	fmul.4s	v11, v9, v11
	fadd.4s	v11, v11, v19
	fmul.4s	v11, v9, v11
	fadd.4s	v11, v11, v6
	fmul.4s	v11, v9, v11
	fadd.4s	v11, v11, v21
	fmul.4s	v11, v9, v11
	fadd.4s	v11, v11, v27
	fmul.4s	v12, v9, v9
	fmul.4s	v11, v12, v11
	fmul.4s	v12, v22, v17
	fadd.4s	v12, v12, v18
	fmul.4s	v12, v22, v12
	fadd.4s	v12, v12, v19
	fmul.4s	v12, v22, v12
	fadd.4s	v12, v12, v6
	fmul.4s	v12, v22, v12
	fadd.4s	v12, v12, v21
	fmul.4s	v12, v22, v12
	fadd.4s	v12, v12, v27
	fmul.4s	v13, v22, v22
	fmul.4s	v12, v13, v12
	fadd.4s	v22, v22, v12
	fadd.4s	v9, v9, v11
	fadd.4s	v22, v22, v20
	sshr.4s	v11, v10, #1
	shl.4s	v12, v11, #23
	add.4s	v12, v12, v20
	fmul.4s	v22, v22, v12
	fadd.4s	v9, v9, v20
	sshr.4s	v12, v31, #1
	shl.4s	v13, v12, #23
	add.4s	v13, v13, v20
	fmul.4s	v9, v9, v13
	sub.4s	v10, v10, v11
	sub.4s	v31, v31, v12
	shl.4s	v31, v31, #23
	add.4s	v31, v31, v20
	fmul.4s	v31, v9, v31
	shl.4s	v9, v10, #23
	add.4s	v9, v9, v20
	fmul.4s	v22, v22, v9
	str	q24, [sp, #7040]                ; 16-byte Spill
	fcmgt.4s	v9, v5, v24
	bic.16b	v22, v22, v9
	str	q15, [sp, #7072]                ; 16-byte Spill
	fcmgt.4s	v9, v5, v15
	bic.16b	v31, v31, v9
	fcmgt.4s	v9, v15, v3
	mov.16b	v2, v9
	bsl.16b	v2, v23, v31
	str	q2, [sp, #7088]                 ; 16-byte Spill
	fcmgt.4s	v31, v24, v3
	mov.16b	v2, v31
	bsl.16b	v2, v23, v22
	str	q2, [sp, #7056]                 ; 16-byte Spill
	fsub.4s	v22, v30, v25
	and.16b	v12, v8, v22
	fcmge.4s	v22, v12, v5
	fcmge.4s	v30, v3, v12
	and.16b	v22, v22, v30
	fsub.4s	v29, v29, v14
	ldr	q30, [sp, #11904]               ; 16-byte Reload
	and.16b	v24, v30, v29
	fcmge.4s	v29, v24, v5
	fcmge.4s	v30, v3, v24
	and.16b	v29, v29, v30
	and.16b	v30, v29, v24
	fmul.4s	v29, v30, v26
	mvni.4s	v2, #128, lsl #24
	movi.4s	v4, #75, lsl #24
	mov.16b	v31, v2
	bsl.16b	v31, v4, v29
	fadd.4s	v29, v29, v31
	fsub.4s	v29, v29, v31
	and.16b	v22, v22, v12
	fmul.4s	v31, v22, v26
	mov.16b	v13, v26
	mov.16b	v9, v2
	bsl.16b	v9, v4, v31
	fadd.4s	v31, v31, v9
	fsub.4s	v31, v31, v9
	fcvtzs.4s	v29, v29
	scvtf.4s	v9, v29
	fmul.4s	v10, v9, v7
	fsub.4s	v30, v30, v10
	fcvtzs.4s	v31, v31
	scvtf.4s	v10, v31
	fmul.4s	v11, v10, v7
	fsub.4s	v22, v22, v11
	fmul.4s	v10, v10, v16
	fsub.4s	v22, v22, v10
	fmul.4s	v9, v9, v16
	fsub.4s	v30, v30, v9
	fmul.4s	v9, v30, v17
	fadd.4s	v9, v9, v18
	fmul.4s	v9, v30, v9
	fadd.4s	v9, v9, v19
	fmul.4s	v9, v30, v9
	fadd.4s	v9, v9, v6
	fmul.4s	v9, v30, v9
	fadd.4s	v9, v9, v21
	fmul.4s	v9, v30, v9
	movi.4s	v2, #63, lsl #24
	fadd.4s	v9, v9, v2
	fmul.4s	v10, v30, v30
	fmul.4s	v9, v10, v9
	fmul.4s	v10, v22, v17
	fadd.4s	v10, v10, v18
	fmul.4s	v10, v22, v10
	fadd.4s	v10, v10, v19
	fmul.4s	v10, v22, v10
	fadd.4s	v10, v10, v6
	fmul.4s	v10, v22, v10
	fadd.4s	v10, v10, v21
	fmul.4s	v10, v22, v10
	fadd.4s	v10, v10, v2
	movi.4s	v15, #63, lsl #24
	fmul.4s	v11, v22, v22
	fmul.4s	v10, v11, v10
	fadd.4s	v22, v22, v10
	fadd.4s	v30, v30, v9
	fadd.4s	v22, v22, v20
	sshr.4s	v9, v31, #1
	shl.4s	v10, v9, #23
	add.4s	v10, v10, v20
	fmul.4s	v22, v22, v10
	fadd.4s	v30, v30, v20
	sshr.4s	v10, v29, #1
	shl.4s	v11, v10, #23
	add.4s	v11, v11, v20
	fmul.4s	v30, v30, v11
	sub.4s	v31, v31, v9
	sub.4s	v29, v29, v10
	shl.4s	v29, v29, #23
	add.4s	v29, v29, v20
	fmul.4s	v29, v30, v29
	shl.4s	v30, v31, #23
	add.4s	v30, v30, v20
	fmul.4s	v22, v22, v30
	str	q12, [sp, #6944]                ; 16-byte Spill
	fcmgt.4s	v30, v5, v12
	bic.16b	v22, v22, v30
	str	q24, [sp, #6976]                ; 16-byte Spill
	fcmgt.4s	v30, v5, v24
	bic.16b	v29, v29, v30
	fcmgt.4s	v30, v24, v3
	mov.16b	v2, v30
	bsl.16b	v2, v23, v29
	str	q2, [sp, #6992]                 ; 16-byte Spill
	fcmgt.4s	v29, v12, v3
	mov.16b	v2, v29
	bsl.16b	v2, v23, v22
	str	q2, [sp, #6960]                 ; 16-byte Spill
	ldr	q0, [sp, #6880]                 ; 16-byte Reload
	fsub.4s	v1, v0, v25
	mov.16b	v11, v25
	and.16b	v25, v8, v1
	fcmge.4s	v1, v25, v5
	fcmge.4s	v22, v3, v25
	and.16b	v1, v1, v22
	ldr	q0, [sp, #6896]                 ; 16-byte Reload
	fsub.4s	v0, v0, v14
	ldr	q22, [sp, #11904]               ; 16-byte Reload
	and.16b	v24, v22, v0
	fcmge.4s	v0, v24, v5
	fcmge.4s	v22, v3, v24
	and.16b	v0, v0, v22
	and.16b	v22, v0, v24
	fmul.4s	v0, v22, v26
	movi.4s	v2, #75, lsl #24
	mvni.4s	v4, #128, lsl #24
	mov.16b	v29, v4
	bsl.16b	v29, v2, v0
	fadd.4s	v0, v0, v29
	fsub.4s	v0, v0, v29
	and.16b	v1, v1, v25
	fmul.4s	v29, v1, v26
	mov.16b	v30, v4
	bsl.16b	v30, v2, v29
	movi.4s	v10, #75, lsl #24
	fadd.4s	v29, v29, v30
	fsub.4s	v29, v29, v30
	fcvtzs.4s	v0, v0
	scvtf.4s	v30, v0
	fmul.4s	v31, v30, v7
	fsub.4s	v22, v22, v31
	fcvtzs.4s	v29, v29
	scvtf.4s	v31, v29
	fmul.4s	v9, v31, v7
	fsub.4s	v1, v1, v9
	fmul.4s	v31, v31, v16
	fsub.4s	v1, v1, v31
	fmul.4s	v30, v30, v16
	fsub.4s	v22, v22, v30
	fmul.4s	v30, v22, v17
	fadd.4s	v30, v30, v18
	fmul.4s	v30, v22, v30
	fadd.4s	v30, v30, v19
	fmul.4s	v30, v22, v30
	fadd.4s	v30, v30, v6
	fmul.4s	v30, v22, v30
	fadd.4s	v30, v30, v21
	fmul.4s	v30, v22, v30
	fadd.4s	v30, v30, v15
	fmul.4s	v31, v22, v22
	fmul.4s	v30, v31, v30
	fmul.4s	v31, v1, v17
	fadd.4s	v31, v31, v18
	fmul.4s	v31, v1, v31
	fadd.4s	v31, v31, v19
	fmul.4s	v31, v1, v31
	fadd.4s	v31, v31, v6
	fmul.4s	v31, v1, v31
	fadd.4s	v31, v31, v21
	fmul.4s	v31, v1, v31
	fadd.4s	v31, v31, v15
	fmul.4s	v9, v1, v1
	fmul.4s	v31, v9, v31
	fadd.4s	v1, v1, v31
	fadd.4s	v22, v22, v30
	fadd.4s	v1, v1, v20
	sshr.4s	v30, v29, #1
	shl.4s	v31, v30, #23
	add.4s	v31, v31, v20
	fmul.4s	v1, v1, v31
	fadd.4s	v22, v22, v20
	sshr.4s	v31, v0, #1
	shl.4s	v9, v31, #23
	add.4s	v9, v9, v20
	fmul.4s	v22, v22, v9
	sub.4s	v29, v29, v30
	sub.4s	v0, v0, v31
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v20
	fmul.4s	v0, v22, v0
	shl.4s	v22, v29, #23
	add.4s	v22, v22, v20
	fmul.4s	v1, v1, v22
	str	q25, [sp, #6848]                ; 16-byte Spill
	fcmgt.4s	v22, v5, v25
	bic.16b	v1, v1, v22
	str	q24, [sp, #6880]                ; 16-byte Spill
	fcmgt.4s	v22, v5, v24
	bic.16b	v0, v0, v22
	fcmgt.4s	v22, v24, v3
	bit.16b	v0, v23, v22
	str	q0, [sp, #6896]                 ; 16-byte Spill
	fcmgt.4s	v0, v25, v3
	bsl.16b	v0, v23, v1
	str	q0, [sp, #6864]                 ; 16-byte Spill
	ldr	q0, [sp, #6784]                 ; 16-byte Reload
	fsub.4s	v0, v0, v11
	and.16b	v4, v8, v0
	fcmge.4s	v0, v4, v5
	fcmge.4s	v1, v3, v4
	and.16b	v0, v0, v1
	ldr	q1, [sp, #6800]                 ; 16-byte Reload
	fsub.4s	v1, v1, v14
	ldr	q22, [sp, #11904]               ; 16-byte Reload
	and.16b	v2, v22, v1
	fcmge.4s	v1, v2, v5
	fcmge.4s	v22, v3, v2
	and.16b	v1, v1, v22
	and.16b	v1, v1, v2
	fmul.4s	v22, v1, v26
	mvni.4s	v24, #128, lsl #24
	mov.16b	v27, v24
	bsl.16b	v27, v10, v22
	fadd.4s	v22, v22, v27
	fsub.4s	v22, v22, v27
	and.16b	v27, v0, v4
	fmul.4s	v0, v27, v26
	mov.16b	v28, v24
	bsl.16b	v28, v10, v0
	fadd.4s	v0, v0, v28
	fsub.4s	v28, v0, v28
	fcvtzs.4s	v0, v22
	scvtf.4s	v22, v0
	fmul.4s	v29, v22, v7
	fsub.4s	v1, v1, v29
	fcvtzs.4s	v28, v28
	scvtf.4s	v29, v28
	fmul.4s	v30, v29, v7
	fsub.4s	v27, v27, v30
	fmul.4s	v29, v29, v16
	fsub.4s	v27, v27, v29
	fmul.4s	v22, v22, v16
	fsub.4s	v1, v1, v22
	fmul.4s	v22, v1, v17
	fadd.4s	v22, v22, v18
	fmul.4s	v22, v1, v22
	fadd.4s	v22, v22, v19
	fmul.4s	v22, v1, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v1, v22
	fadd.4s	v22, v22, v21
	fmul.4s	v22, v1, v22
	fadd.4s	v22, v22, v15
	fmul.4s	v29, v1, v1
	fmul.4s	v22, v29, v22
	fmul.4s	v29, v27, v17
	fadd.4s	v29, v29, v18
	fmul.4s	v29, v27, v29
	fadd.4s	v29, v29, v19
	fmul.4s	v29, v27, v29
	fadd.4s	v29, v29, v6
	fmul.4s	v29, v27, v29
	fadd.4s	v29, v29, v21
	fmul.4s	v29, v27, v29
	fadd.4s	v29, v29, v15
	fmul.4s	v30, v27, v27
	fmul.4s	v29, v30, v29
	fadd.4s	v27, v27, v29
	fadd.4s	v1, v1, v22
	fadd.4s	v22, v27, v20
	sshr.4s	v27, v28, #1
	shl.4s	v29, v27, #23
	add.4s	v29, v29, v20
	fmul.4s	v22, v22, v29
	fadd.4s	v1, v1, v20
	sshr.4s	v29, v0, #1
	shl.4s	v30, v29, #23
	add.4s	v30, v30, v20
	fmul.4s	v1, v1, v30
	sub.4s	v27, v28, v27
	sub.4s	v0, v0, v29
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v20
	fmul.4s	v0, v1, v0
	shl.4s	v1, v27, #23
	add.4s	v1, v1, v20
	fmul.4s	v1, v22, v1
	str	q4, [sp, #6752]                 ; 16-byte Spill
	fcmgt.4s	v22, v5, v4
	bic.16b	v1, v1, v22
	str	q2, [sp, #6784]                 ; 16-byte Spill
	fcmgt.4s	v22, v5, v2
	bic.16b	v0, v0, v22
	fcmgt.4s	v22, v2, v3
	bit.16b	v0, v23, v22
	str	q0, [sp, #6800]                 ; 16-byte Spill
	fcmgt.4s	v0, v4, v3
	bsl.16b	v0, v23, v1
	str	q0, [sp, #6768]                 ; 16-byte Spill
	ldr	q0, [sp, #6688]                 ; 16-byte Reload
	fsub.4s	v0, v0, v11
	and.16b	v4, v8, v0
	fcmge.4s	v0, v4, v5
	fcmge.4s	v1, v3, v4
	and.16b	v0, v0, v1
	ldr	q1, [sp, #6704]                 ; 16-byte Reload
	fsub.4s	v1, v1, v14
	ldr	q22, [sp, #11904]               ; 16-byte Reload
	and.16b	v2, v22, v1
	fcmge.4s	v1, v2, v5
	fcmge.4s	v22, v3, v2
	and.16b	v1, v1, v22
	and.16b	v1, v1, v2
	fmul.4s	v22, v1, v26
	mov.16b	v25, v24
	bsl.16b	v25, v10, v22
	fadd.4s	v22, v22, v25
	fsub.4s	v22, v22, v25
	and.16b	v25, v0, v4
	fmul.4s	v0, v25, v26
	mov.16b	v26, v24
	bsl.16b	v26, v10, v0
	fadd.4s	v0, v0, v26
	fsub.4s	v26, v0, v26
	fcvtzs.4s	v0, v22
	scvtf.4s	v22, v0
	fmul.4s	v27, v22, v7
	fsub.4s	v1, v1, v27
	fcvtzs.4s	v26, v26
	scvtf.4s	v27, v26
	fmul.4s	v28, v27, v7
	fsub.4s	v25, v25, v28
	fmul.4s	v27, v27, v16
	fsub.4s	v25, v25, v27
	fmul.4s	v22, v22, v16
	fsub.4s	v1, v1, v22
	fmul.4s	v22, v1, v17
	fadd.4s	v22, v22, v18
	fmul.4s	v22, v1, v22
	fadd.4s	v22, v22, v19
	fmul.4s	v22, v1, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v1, v22
	fadd.4s	v22, v22, v21
	fmul.4s	v22, v1, v22
	fadd.4s	v22, v22, v15
	fmul.4s	v27, v1, v1
	fmul.4s	v22, v27, v22
	fmul.4s	v27, v25, v17
	fadd.4s	v27, v27, v18
	fmul.4s	v27, v25, v27
	fadd.4s	v27, v27, v19
	fmul.4s	v27, v25, v27
	fadd.4s	v27, v27, v6
	fmul.4s	v27, v25, v27
	fadd.4s	v27, v27, v21
	fmul.4s	v27, v25, v27
	fadd.4s	v27, v27, v15
	fmul.4s	v28, v25, v25
	fmul.4s	v27, v28, v27
	fadd.4s	v25, v25, v27
	fadd.4s	v1, v1, v22
	fadd.4s	v22, v25, v20
	sshr.4s	v25, v26, #1
	shl.4s	v27, v25, #23
	add.4s	v27, v27, v20
	fmul.4s	v22, v22, v27
	fadd.4s	v1, v1, v20
	sshr.4s	v27, v0, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v20
	fmul.4s	v1, v1, v28
	sub.4s	v25, v26, v25
	sub.4s	v0, v0, v27
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v20
	fmul.4s	v0, v1, v0
	shl.4s	v1, v25, #23
	add.4s	v1, v1, v20
	fmul.4s	v1, v22, v1
	str	q4, [sp, #6656]                 ; 16-byte Spill
	fcmgt.4s	v22, v5, v4
	bic.16b	v1, v1, v22
	str	q2, [sp, #6688]                 ; 16-byte Spill
	fcmgt.4s	v22, v5, v2
	bic.16b	v0, v0, v22
	fcmgt.4s	v22, v2, v3
	bit.16b	v0, v23, v22
	str	q0, [sp, #6704]                 ; 16-byte Spill
	fcmgt.4s	v0, v4, v3
	bsl.16b	v0, v23, v1
	str	q0, [sp, #6672]                 ; 16-byte Spill
	ldr	q0, [sp, #6592]                 ; 16-byte Reload
	fsub.4s	v0, v0, v11
	and.16b	v27, v8, v0
	fcmge.4s	v0, v27, v5
	fcmge.4s	v1, v3, v27
	and.16b	v0, v0, v1
	ldr	q1, [sp, #6608]                 ; 16-byte Reload
	fsub.4s	v1, v1, v14
	ldr	q4, [sp, #11904]                ; 16-byte Reload
	and.16b	v2, v4, v1
	fcmge.4s	v1, v2, v5
	fcmge.4s	v4, v3, v2
	and.16b	v1, v1, v4
	and.16b	v1, v1, v2
	fmul.4s	v4, v1, v13
	mov.16b	v22, v24
	bsl.16b	v22, v10, v4
	fadd.4s	v4, v4, v22
	fsub.4s	v4, v4, v22
	and.16b	v22, v0, v27
	fmul.4s	v0, v22, v13
	bsl.16b	v24, v10, v0
	mvni.4s	v28, #128, lsl #24
	fadd.4s	v0, v0, v24
	fsub.4s	v24, v0, v24
	fcvtzs.4s	v0, v4
	scvtf.4s	v4, v0
	fmul.4s	v25, v4, v7
	fsub.4s	v1, v1, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v7
	fsub.4s	v22, v22, v26
	fmul.4s	v25, v25, v16
	fsub.4s	v22, v22, v25
	fmul.4s	v4, v4, v16
	fsub.4s	v1, v1, v4
	fmul.4s	v4, v1, v17
	fadd.4s	v4, v4, v18
	fmul.4s	v4, v1, v4
	fadd.4s	v4, v4, v19
	fmul.4s	v4, v1, v4
	fadd.4s	v4, v4, v6
	fmul.4s	v4, v1, v4
	fadd.4s	v4, v4, v21
	fmul.4s	v4, v1, v4
	fadd.4s	v4, v4, v15
	fmul.4s	v25, v1, v1
	fmul.4s	v4, v25, v4
	fmul.4s	v25, v22, v17
	fadd.4s	v25, v25, v18
	fmul.4s	v25, v22, v25
	fadd.4s	v25, v25, v19
	fmul.4s	v25, v22, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v22, v25
	fadd.4s	v25, v25, v21
	fmul.4s	v25, v22, v25
	fadd.4s	v25, v25, v15
	fmul.4s	v26, v22, v22
	fmul.4s	v25, v26, v25
	fadd.4s	v22, v22, v25
	fadd.4s	v1, v1, v4
	fadd.4s	v4, v22, v20
	sshr.4s	v22, v24, #1
	shl.4s	v25, v22, #23
	add.4s	v25, v25, v20
	fmul.4s	v4, v4, v25
	fadd.4s	v1, v1, v20
	sshr.4s	v25, v0, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v20
	fmul.4s	v1, v1, v26
	sub.4s	v22, v24, v22
	sub.4s	v0, v0, v25
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v20
	fmul.4s	v0, v1, v0
	shl.4s	v1, v22, #23
	add.4s	v1, v1, v20
	fmul.4s	v1, v4, v1
	str	q27, [sp, #6560]                ; 16-byte Spill
	fcmgt.4s	v4, v5, v27
	bic.16b	v1, v1, v4
	str	q2, [sp, #6592]                 ; 16-byte Spill
	fcmgt.4s	v4, v5, v2
	bic.16b	v0, v0, v4
	fcmgt.4s	v4, v2, v3
	bit.16b	v0, v23, v4
	str	q0, [sp, #6608]                 ; 16-byte Spill
	fcmgt.4s	v0, v27, v3
	bsl.16b	v0, v23, v1
	str	q0, [sp, #6576]                 ; 16-byte Spill
	ldr	q0, [sp, #6496]                 ; 16-byte Reload
	fsub.4s	v0, v0, v11
	and.16b	v27, v8, v0
	fcmge.4s	v0, v27, v5
	fcmge.4s	v1, v3, v27
	and.16b	v0, v0, v1
	ldr	q1, [sp, #6512]                 ; 16-byte Reload
	fsub.4s	v1, v1, v14
	ldr	q2, [sp, #11904]                ; 16-byte Reload
	and.16b	v26, v2, v1
	fcmge.4s	v1, v26, v5
	fcmge.4s	v2, v3, v26
	and.16b	v1, v1, v2
	and.16b	v1, v1, v26
	fmul.4s	v2, v1, v13
	mov.16b	v4, v28
	bsl.16b	v4, v10, v2
	fadd.4s	v2, v2, v4
	fsub.4s	v2, v2, v4
	and.16b	v4, v0, v27
	fmul.4s	v0, v4, v13
	mov.16b	v22, v28
	bsl.16b	v22, v10, v0
	fadd.4s	v0, v0, v22
	fsub.4s	v22, v0, v22
	fcvtzs.4s	v0, v2
	scvtf.4s	v2, v0
	fmul.4s	v24, v2, v7
	fsub.4s	v1, v1, v24
	fcvtzs.4s	v22, v22
	scvtf.4s	v24, v22
	fmul.4s	v25, v24, v7
	fsub.4s	v4, v4, v25
	fmul.4s	v24, v24, v16
	fsub.4s	v4, v4, v24
	fmul.4s	v2, v2, v16
	fsub.4s	v1, v1, v2
	fmul.4s	v2, v1, v17
	fadd.4s	v2, v2, v18
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v19
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v6
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v21
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v15
	fmul.4s	v24, v1, v1
	fmul.4s	v2, v24, v2
	fmul.4s	v24, v4, v17
	fadd.4s	v24, v24, v18
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v19
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v6
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v21
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v15
	fmul.4s	v25, v4, v4
	fmul.4s	v24, v25, v24
	fadd.4s	v4, v4, v24
	fadd.4s	v1, v1, v2
	fadd.4s	v2, v4, v20
	sshr.4s	v4, v22, #1
	shl.4s	v24, v4, #23
	add.4s	v24, v24, v20
	fmul.4s	v2, v2, v24
	fadd.4s	v1, v1, v20
	sshr.4s	v24, v0, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v20
	fmul.4s	v1, v1, v25
	sub.4s	v4, v22, v4
	sub.4s	v0, v0, v24
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v20
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v20
	fmul.4s	v1, v2, v1
	str	q27, [sp, #6464]                ; 16-byte Spill
	fcmgt.4s	v2, v5, v27
	bic.16b	v1, v1, v2
	str	q26, [sp, #6496]                ; 16-byte Spill
	fcmgt.4s	v2, v5, v26
	bic.16b	v0, v0, v2
	fcmgt.4s	v2, v26, v3
	bit.16b	v0, v23, v2
	str	q0, [sp, #6512]                 ; 16-byte Spill
	fcmgt.4s	v0, v27, v3
	bsl.16b	v0, v23, v1
	str	q0, [sp, #6480]                 ; 16-byte Spill
	ldr	q0, [sp, #6432]                 ; 16-byte Reload
	fsub.4s	v0, v0, v11
	and.16b	v27, v8, v0
	fcmge.4s	v0, v27, v5
	fcmge.4s	v1, v3, v27
	and.16b	v0, v0, v1
	ldr	q1, [sp, #6448]                 ; 16-byte Reload
	fsub.4s	v1, v1, v14
	ldr	q2, [sp, #11904]                ; 16-byte Reload
	and.16b	v26, v2, v1
	fcmge.4s	v1, v26, v5
	fcmge.4s	v2, v3, v26
	and.16b	v1, v1, v2
	and.16b	v1, v1, v26
	fmul.4s	v2, v1, v13
	mvni.4s	v22, #128, lsl #24
	mov.16b	v4, v22
	bsl.16b	v4, v10, v2
	fadd.4s	v2, v2, v4
	fsub.4s	v2, v2, v4
	and.16b	v4, v0, v27
	fmul.4s	v0, v4, v13
	bsl.16b	v22, v10, v0
	fadd.4s	v0, v0, v22
	fsub.4s	v22, v0, v22
	fcvtzs.4s	v0, v2
	scvtf.4s	v2, v0
	fmul.4s	v24, v2, v7
	fsub.4s	v1, v1, v24
	fcvtzs.4s	v22, v22
	scvtf.4s	v24, v22
	fmul.4s	v25, v24, v7
	fsub.4s	v4, v4, v25
	fmul.4s	v24, v24, v16
	fsub.4s	v4, v4, v24
	fmul.4s	v2, v2, v16
	fsub.4s	v1, v1, v2
	fmul.4s	v2, v1, v17
	fadd.4s	v2, v2, v18
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v19
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v6
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v21
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v15
	fmul.4s	v24, v1, v1
	fmul.4s	v2, v24, v2
	fmul.4s	v24, v4, v17
	fadd.4s	v24, v24, v18
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v19
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v6
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v21
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v15
	fmul.4s	v25, v4, v4
	fmul.4s	v24, v25, v24
	fadd.4s	v4, v4, v24
	fadd.4s	v1, v1, v2
	fadd.4s	v2, v4, v20
	sshr.4s	v4, v22, #1
	shl.4s	v24, v4, #23
	add.4s	v24, v24, v20
	fmul.4s	v2, v2, v24
	fadd.4s	v1, v1, v20
	sshr.4s	v24, v0, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v20
	fmul.4s	v1, v1, v25
	sub.4s	v4, v22, v4
	sub.4s	v0, v0, v24
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v20
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v20
	fmul.4s	v1, v2, v1
	str	q27, [sp, #6400]                ; 16-byte Spill
	fcmgt.4s	v2, v5, v27
	bic.16b	v1, v1, v2
	str	q26, [sp, #6432]                ; 16-byte Spill
	fcmgt.4s	v2, v5, v26
	bic.16b	v0, v0, v2
	fcmgt.4s	v2, v26, v3
	bit.16b	v0, v23, v2
	str	q0, [sp, #6448]                 ; 16-byte Spill
	fcmgt.4s	v0, v27, v3
	bsl.16b	v0, v23, v1
	str	q0, [sp, #6416]                 ; 16-byte Spill
	ldr	q0, [sp, #6528]                 ; 16-byte Reload
	fsub.4s	v0, v0, v14
	ldr	q1, [sp, #11904]                ; 16-byte Reload
	and.16b	v27, v1, v0
	fcmge.4s	v0, v27, v5
	fcmge.4s	v1, v3, v27
	and.16b	v0, v0, v1
	ldr	q1, [sp, #6544]                 ; 16-byte Reload
	fsub.4s	v1, v1, v11
	and.16b	v26, v8, v1
	fcmge.4s	v1, v26, v5
	fcmge.4s	v2, v3, v26
	and.16b	v1, v1, v2
	and.16b	v1, v1, v26
	fmul.4s	v2, v1, v13
	mov.16b	v4, v28
	bsl.16b	v4, v10, v2
	fadd.4s	v2, v2, v4
	fsub.4s	v2, v2, v4
	and.16b	v4, v0, v27
	fmul.4s	v0, v4, v13
	mov.16b	v22, v28
	bsl.16b	v22, v10, v0
	fadd.4s	v0, v0, v22
	fsub.4s	v22, v0, v22
	fcvtzs.4s	v0, v2
	scvtf.4s	v2, v0
	fmul.4s	v24, v2, v7
	fsub.4s	v1, v1, v24
	fcvtzs.4s	v22, v22
	scvtf.4s	v24, v22
	fmul.4s	v25, v24, v7
	fsub.4s	v4, v4, v25
	fmul.4s	v24, v24, v16
	fsub.4s	v4, v4, v24
	fmul.4s	v2, v2, v16
	fsub.4s	v1, v1, v2
	fmul.4s	v2, v1, v17
	fadd.4s	v2, v2, v18
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v19
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v6
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v21
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v15
	fmul.4s	v24, v1, v1
	fmul.4s	v2, v24, v2
	fmul.4s	v24, v4, v17
	fadd.4s	v24, v24, v18
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v19
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v6
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v21
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v15
	fmul.4s	v25, v4, v4
	fmul.4s	v24, v25, v24
	fadd.4s	v4, v4, v24
	fadd.4s	v1, v1, v2
	fadd.4s	v2, v4, v20
	sshr.4s	v4, v22, #1
	shl.4s	v24, v4, #23
	add.4s	v24, v24, v20
	fmul.4s	v2, v2, v24
	fadd.4s	v1, v1, v20
	sshr.4s	v24, v0, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v20
	fmul.4s	v1, v1, v25
	sub.4s	v4, v22, v4
	sub.4s	v0, v0, v24
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v20
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v20
	fmul.4s	v1, v2, v1
	str	q27, [sp, #6368]                ; 16-byte Spill
	fcmgt.4s	v2, v5, v27
	bic.16b	v1, v1, v2
	str	q26, [sp, #6528]                ; 16-byte Spill
	fcmgt.4s	v2, v5, v26
	bic.16b	v0, v0, v2
	fcmgt.4s	v2, v26, v3
	bit.16b	v0, v23, v2
	str	q0, [sp, #6544]                 ; 16-byte Spill
	fcmgt.4s	v0, v27, v3
	bsl.16b	v0, v23, v1
	str	q0, [sp, #6384]                 ; 16-byte Spill
	ldr	q0, [sp, #6624]                 ; 16-byte Reload
	fsub.4s	v0, v0, v14
	ldr	q1, [sp, #11904]                ; 16-byte Reload
	and.16b	v27, v1, v0
	fcmge.4s	v0, v27, v5
	fcmge.4s	v1, v3, v27
	and.16b	v0, v0, v1
	ldr	q1, [sp, #6640]                 ; 16-byte Reload
	fsub.4s	v1, v1, v11
	and.16b	v26, v8, v1
	fcmge.4s	v1, v26, v5
	fcmge.4s	v2, v3, v26
	and.16b	v1, v1, v2
	and.16b	v1, v1, v26
	fmul.4s	v2, v1, v13
	mvni.4s	v22, #128, lsl #24
	mov.16b	v4, v22
	bsl.16b	v4, v10, v2
	fadd.4s	v2, v2, v4
	fsub.4s	v2, v2, v4
	and.16b	v4, v0, v27
	fmul.4s	v0, v4, v13
	bsl.16b	v22, v10, v0
	fadd.4s	v0, v0, v22
	fsub.4s	v22, v0, v22
	fcvtzs.4s	v0, v2
	scvtf.4s	v2, v0
	fmul.4s	v24, v2, v7
	fsub.4s	v1, v1, v24
	fcvtzs.4s	v22, v22
	scvtf.4s	v24, v22
	fmul.4s	v25, v24, v7
	fsub.4s	v4, v4, v25
	fmul.4s	v24, v24, v16
	fsub.4s	v4, v4, v24
	fmul.4s	v2, v2, v16
	fsub.4s	v1, v1, v2
	fmul.4s	v2, v1, v17
	fadd.4s	v2, v2, v18
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v19
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v6
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v21
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v15
	fmul.4s	v24, v1, v1
	fmul.4s	v2, v24, v2
	fmul.4s	v24, v4, v17
	fadd.4s	v24, v24, v18
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v19
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v6
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v21
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v15
	fmul.4s	v25, v4, v4
	fmul.4s	v24, v25, v24
	fadd.4s	v4, v4, v24
	fadd.4s	v1, v1, v2
	fadd.4s	v2, v4, v20
	sshr.4s	v4, v22, #1
	shl.4s	v24, v4, #23
	add.4s	v24, v24, v20
	fmul.4s	v2, v2, v24
	fadd.4s	v1, v1, v20
	sshr.4s	v24, v0, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v20
	fmul.4s	v1, v1, v25
	sub.4s	v4, v22, v4
	sub.4s	v0, v0, v24
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v20
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v20
	fmul.4s	v1, v2, v1
	str	q27, [sp, #6336]                ; 16-byte Spill
	fcmgt.4s	v2, v5, v27
	bic.16b	v1, v1, v2
	str	q26, [sp, #6624]                ; 16-byte Spill
	fcmgt.4s	v2, v5, v26
	bic.16b	v0, v0, v2
	fcmgt.4s	v2, v26, v3
	bit.16b	v0, v23, v2
	str	q0, [sp, #6640]                 ; 16-byte Spill
	fcmgt.4s	v0, v27, v3
	bsl.16b	v0, v23, v1
	str	q0, [sp, #6352]                 ; 16-byte Spill
	ldr	q0, [sp, #6720]                 ; 16-byte Reload
	fsub.4s	v0, v0, v14
	ldr	q1, [sp, #11904]                ; 16-byte Reload
	and.16b	v27, v1, v0
	fcmge.4s	v0, v27, v5
	fcmge.4s	v1, v3, v27
	and.16b	v0, v0, v1
	ldr	q1, [sp, #6736]                 ; 16-byte Reload
	fsub.4s	v1, v1, v11
	and.16b	v26, v8, v1
	fcmge.4s	v1, v26, v5
	fcmge.4s	v2, v3, v26
	and.16b	v1, v1, v2
	and.16b	v1, v1, v26
	fmul.4s	v2, v1, v13
	mov.16b	v4, v28
	bsl.16b	v4, v10, v2
	fadd.4s	v2, v2, v4
	fsub.4s	v2, v2, v4
	and.16b	v4, v0, v27
	fmul.4s	v0, v4, v13
	mov.16b	v22, v28
	bsl.16b	v22, v10, v0
	fadd.4s	v0, v0, v22
	fsub.4s	v22, v0, v22
	fcvtzs.4s	v0, v2
	scvtf.4s	v2, v0
	fmul.4s	v24, v2, v7
	fsub.4s	v1, v1, v24
	fcvtzs.4s	v22, v22
	scvtf.4s	v24, v22
	fmul.4s	v25, v24, v7
	fsub.4s	v4, v4, v25
	fmul.4s	v24, v24, v16
	fsub.4s	v4, v4, v24
	fmul.4s	v2, v2, v16
	fsub.4s	v1, v1, v2
	fmul.4s	v2, v1, v17
	fadd.4s	v2, v2, v18
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v19
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v6
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v21
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v15
	fmul.4s	v24, v1, v1
	fmul.4s	v2, v24, v2
	fmul.4s	v24, v4, v17
	fadd.4s	v24, v24, v18
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v19
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v6
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v21
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v15
	fmul.4s	v25, v4, v4
	fmul.4s	v24, v25, v24
	fadd.4s	v4, v4, v24
	fadd.4s	v1, v1, v2
	fadd.4s	v2, v4, v20
	sshr.4s	v4, v22, #1
	shl.4s	v24, v4, #23
	add.4s	v24, v24, v20
	fmul.4s	v2, v2, v24
	fadd.4s	v1, v1, v20
	sshr.4s	v24, v0, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v20
	fmul.4s	v1, v1, v25
	sub.4s	v4, v22, v4
	sub.4s	v0, v0, v24
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v20
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v20
	fmul.4s	v1, v2, v1
	str	q27, [sp, #6304]                ; 16-byte Spill
	fcmgt.4s	v2, v5, v27
	bic.16b	v1, v1, v2
	str	q26, [sp, #6720]                ; 16-byte Spill
	fcmgt.4s	v2, v5, v26
	bic.16b	v0, v0, v2
	fcmgt.4s	v2, v26, v3
	bit.16b	v0, v23, v2
	str	q0, [sp, #6736]                 ; 16-byte Spill
	fcmgt.4s	v0, v27, v3
	bsl.16b	v0, v23, v1
	str	q0, [sp, #6320]                 ; 16-byte Spill
	ldr	q0, [sp, #6816]                 ; 16-byte Reload
	fsub.4s	v0, v0, v14
	ldr	q1, [sp, #11904]                ; 16-byte Reload
	and.16b	v9, v1, v0
	fcmge.4s	v0, v9, v5
	fcmge.4s	v1, v3, v9
	and.16b	v0, v0, v1
	ldr	q1, [sp, #6832]                 ; 16-byte Reload
	fsub.4s	v1, v1, v11
	and.16b	v31, v8, v1
	fcmge.4s	v1, v31, v5
	fcmge.4s	v2, v3, v31
	and.16b	v1, v1, v2
	and.16b	v1, v1, v31
	fmul.4s	v2, v1, v13
	mvni.4s	v22, #128, lsl #24
	mov.16b	v4, v22
	bsl.16b	v4, v10, v2
	fadd.4s	v2, v2, v4
	fsub.4s	v2, v2, v4
	and.16b	v4, v0, v9
	fmul.4s	v0, v4, v13
	bsl.16b	v22, v10, v0
	fadd.4s	v0, v0, v22
	fsub.4s	v22, v0, v22
	fcvtzs.4s	v0, v2
	scvtf.4s	v2, v0
	fmul.4s	v24, v2, v7
	fsub.4s	v1, v1, v24
	fcvtzs.4s	v22, v22
	scvtf.4s	v24, v22
	fmul.4s	v25, v24, v7
	fsub.4s	v4, v4, v25
	fmul.4s	v24, v24, v16
	fsub.4s	v4, v4, v24
	fmul.4s	v2, v2, v16
	fsub.4s	v1, v1, v2
	fmul.4s	v2, v1, v17
	fadd.4s	v2, v2, v18
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v19
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v6
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v21
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v15
	fmul.4s	v24, v1, v1
	fmul.4s	v2, v24, v2
	fmul.4s	v24, v4, v17
	fadd.4s	v24, v24, v18
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v19
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v6
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v21
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v15
	fmul.4s	v25, v4, v4
	fmul.4s	v24, v25, v24
	fadd.4s	v4, v4, v24
	fadd.4s	v1, v1, v2
	fadd.4s	v2, v4, v20
	sshr.4s	v4, v22, #1
	shl.4s	v24, v4, #23
	add.4s	v24, v24, v20
	fmul.4s	v2, v2, v24
	fadd.4s	v1, v1, v20
	sshr.4s	v24, v0, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v20
	fmul.4s	v1, v1, v25
	sub.4s	v4, v22, v4
	sub.4s	v0, v0, v24
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v20
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v20
	fmul.4s	v1, v2, v1
	fcmgt.4s	v2, v5, v9
	bic.16b	v1, v1, v2
	fcmgt.4s	v2, v5, v31
	bic.16b	v0, v0, v2
	fcmgt.4s	v2, v31, v3
	bit.16b	v0, v23, v2
	str	q0, [sp, #6288]                 ; 16-byte Spill
	fcmgt.4s	v0, v9, v3
	bsl.16b	v0, v23, v1
	str	q0, [sp, #6272]                 ; 16-byte Spill
	ldr	q0, [sp, #6912]                 ; 16-byte Reload
	fsub.4s	v0, v0, v11
	and.16b	v29, v8, v0
	fcmge.4s	v0, v29, v5
	fcmge.4s	v1, v3, v29
	and.16b	v0, v0, v1
	mov.16b	v30, v14
	ldr	q1, [sp, #6928]                 ; 16-byte Reload
	fsub.4s	v1, v1, v14
	ldr	q2, [sp, #11904]                ; 16-byte Reload
	and.16b	v28, v2, v1
	fcmge.4s	v1, v28, v5
	fcmge.4s	v2, v3, v28
	and.16b	v1, v1, v2
	and.16b	v1, v1, v28
	fmul.4s	v2, v1, v13
	mvni.4s	v22, #128, lsl #24
	mov.16b	v4, v22
	bsl.16b	v4, v10, v2
	fadd.4s	v2, v2, v4
	fsub.4s	v2, v2, v4
	and.16b	v4, v0, v29
	fmul.4s	v0, v4, v13
	bsl.16b	v22, v10, v0
	fadd.4s	v0, v0, v22
	fsub.4s	v22, v0, v22
	fcvtzs.4s	v0, v2
	scvtf.4s	v2, v0
	fmul.4s	v24, v2, v7
	fsub.4s	v1, v1, v24
	fcvtzs.4s	v22, v22
	scvtf.4s	v24, v22
	fmul.4s	v12, v24, v7
	fsub.4s	v4, v4, v12
	fmul.4s	v24, v24, v16
	fsub.4s	v4, v4, v24
	fmul.4s	v2, v2, v16
	fsub.4s	v1, v1, v2
	fmul.4s	v2, v1, v17
	fadd.4s	v2, v2, v18
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v19
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v6
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v21
	fmul.4s	v2, v1, v2
	movi.4s	v25, #63, lsl #24
	fadd.4s	v2, v2, v25
	fmul.4s	v24, v1, v1
	fmul.4s	v2, v24, v2
	fmul.4s	v24, v4, v17
	fadd.4s	v24, v24, v18
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v19
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v6
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v21
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v25
	movi.4s	v27, #63, lsl #24
	fmul.4s	v12, v4, v4
	fmul.4s	v24, v12, v24
	fadd.4s	v4, v4, v24
	fadd.4s	v1, v1, v2
	fadd.4s	v2, v4, v20
	sshr.4s	v4, v22, #1
	shl.4s	v24, v4, #23
	add.4s	v24, v24, v20
	fmul.4s	v2, v2, v24
	fadd.4s	v1, v1, v20
	sshr.4s	v24, v0, #1
	shl.4s	v12, v24, #23
	add.4s	v12, v12, v20
	fmul.4s	v1, v1, v12
	sub.4s	v4, v22, v4
	sub.4s	v0, v0, v24
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v20
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v20
	fmul.4s	v1, v2, v1
	fcmgt.4s	v2, v5, v29
	bic.16b	v1, v1, v2
	fcmgt.4s	v2, v5, v28
	bic.16b	v0, v0, v2
	fcmgt.4s	v2, v28, v3
	bit.16b	v0, v23, v2
	str	q0, [sp, #6256]                 ; 16-byte Spill
	fcmgt.4s	v0, v29, v3
	bsl.16b	v0, v23, v1
	str	q0, [sp, #6240]                 ; 16-byte Spill
	ldr	q0, [sp, #7008]                 ; 16-byte Reload
	fsub.4s	v0, v0, v14
	ldr	q1, [sp, #11904]                ; 16-byte Reload
	and.16b	v26, v1, v0
	fcmge.4s	v0, v26, v5
	fcmge.4s	v1, v3, v26
	and.16b	v0, v0, v1
	ldr	q1, [sp, #7024]                 ; 16-byte Reload
	fsub.4s	v1, v1, v11
	and.16b	v25, v8, v1
	fcmge.4s	v1, v25, v5
	fcmge.4s	v2, v3, v25
	and.16b	v1, v1, v2
	and.16b	v1, v1, v25
	fmul.4s	v2, v1, v13
	mvni.4s	v22, #128, lsl #24
	mov.16b	v4, v22
	bsl.16b	v4, v10, v2
	fadd.4s	v2, v2, v4
	fsub.4s	v2, v2, v4
	and.16b	v4, v0, v26
	fmul.4s	v0, v4, v13
	mov.16b	v14, v13
	mov.16b	v12, v22
	bsl.16b	v12, v10, v0
	fadd.4s	v0, v0, v12
	fsub.4s	v12, v0, v12
	fcvtzs.4s	v0, v2
	scvtf.4s	v2, v0
	fmul.4s	v13, v2, v7
	fsub.4s	v1, v1, v13
	fcvtzs.4s	v12, v12
	scvtf.4s	v13, v12
	fmul.4s	v15, v13, v7
	fsub.4s	v4, v4, v15
	fmul.4s	v13, v13, v16
	fsub.4s	v4, v4, v13
	fmul.4s	v2, v2, v16
	fsub.4s	v1, v1, v2
	fmul.4s	v2, v1, v17
	fadd.4s	v2, v2, v18
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v19
	fmul.4s	v2, v1, v2
	mov.16b	v24, v6
	fadd.4s	v2, v2, v6
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v21
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v27
	fmul.4s	v13, v1, v1
	fmul.4s	v2, v13, v2
	fmul.4s	v13, v4, v17
	fadd.4s	v13, v13, v18
	fmul.4s	v13, v4, v13
	fadd.4s	v13, v13, v19
	fmul.4s	v13, v4, v13
	fadd.4s	v13, v13, v6
	fmul.4s	v13, v4, v13
	fadd.4s	v13, v13, v21
	fmul.4s	v13, v4, v13
	fadd.4s	v13, v13, v27
	fmul.4s	v15, v4, v4
	fmul.4s	v13, v15, v13
	fadd.4s	v4, v4, v13
	fadd.4s	v1, v1, v2
	fadd.4s	v2, v4, v20
	sshr.4s	v4, v12, #1
	shl.4s	v13, v4, #23
	add.4s	v13, v13, v20
	fmul.4s	v2, v2, v13
	fadd.4s	v1, v1, v20
	sshr.4s	v13, v0, #1
	shl.4s	v15, v13, #23
	add.4s	v15, v15, v20
	fmul.4s	v1, v1, v15
	sub.4s	v4, v12, v4
	sub.4s	v0, v0, v13
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v20
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v20
	fmul.4s	v1, v2, v1
	fcmgt.4s	v2, v5, v26
	bic.16b	v1, v1, v2
	fcmgt.4s	v2, v5, v25
	bic.16b	v0, v0, v2
	fcmgt.4s	v2, v25, v3
	bit.16b	v0, v23, v2
	str	q0, [sp, #6192]                 ; 16-byte Spill
	fcmgt.4s	v0, v26, v3
	bsl.16b	v0, v23, v1
	str	q0, [sp, #6224]                 ; 16-byte Spill
	ldr	q0, [sp, #7136]                 ; 16-byte Reload
	fsub.4s	v0, v0, v30
	ldr	q1, [sp, #11904]                ; 16-byte Reload
	and.16b	v22, v1, v0
	fcmge.4s	v0, v22, v5
	fcmge.4s	v1, v3, v22
	and.16b	v0, v0, v1
	mov.16b	v2, v11
	ldr	q1, [sp, #7152]                 ; 16-byte Reload
	fsub.4s	v1, v1, v11
	and.16b	v4, v8, v1
	fcmge.4s	v1, v4, v5
	fcmge.4s	v12, v3, v4
	and.16b	v1, v1, v12
	and.16b	v1, v1, v4
	mov.16b	v6, v14
	fmul.4s	v12, v1, v14
	mvni.4s	v27, #128, lsl #24
	mov.16b	v13, v27
	bsl.16b	v13, v10, v12
	fadd.4s	v12, v12, v13
	fsub.4s	v12, v12, v13
	and.16b	v13, v0, v22
	fmul.4s	v0, v13, v14
	mov.16b	v15, v27
	bsl.16b	v15, v10, v0
	fadd.4s	v0, v0, v15
	fsub.4s	v15, v0, v15
	fcvtzs.4s	v0, v12
	scvtf.4s	v12, v0
	fmul.4s	v11, v12, v7
	fsub.4s	v1, v1, v11
	fcvtzs.4s	v11, v15
	scvtf.4s	v15, v11
	fmul.4s	v14, v15, v7
	fsub.4s	v13, v13, v14
	fmul.4s	v14, v15, v16
	fsub.4s	v13, v13, v14
	fmul.4s	v12, v12, v16
	fsub.4s	v1, v1, v12
	fmul.4s	v12, v1, v17
	fadd.4s	v12, v12, v18
	fmul.4s	v12, v1, v12
	fadd.4s	v12, v12, v19
	fmul.4s	v12, v1, v12
	fadd.4s	v12, v12, v24
	fmul.4s	v12, v1, v12
	fadd.4s	v12, v12, v21
	fmul.4s	v12, v1, v12
	movi.4s	v15, #63, lsl #24
	fadd.4s	v12, v12, v15
	fmul.4s	v14, v1, v1
	fmul.4s	v12, v14, v12
	fmul.4s	v14, v13, v17
	fadd.4s	v14, v14, v18
	fmul.4s	v14, v13, v14
	fadd.4s	v14, v14, v19
	fmul.4s	v14, v13, v14
	fadd.4s	v14, v14, v24
	fmul.4s	v14, v13, v14
	fadd.4s	v14, v14, v21
	fmul.4s	v14, v13, v14
	fadd.4s	v14, v14, v15
	fmul.4s	v15, v13, v13
	fmul.4s	v14, v15, v14
	fadd.4s	v13, v13, v14
	fadd.4s	v1, v1, v12
	fadd.4s	v12, v13, v20
	sshr.4s	v13, v11, #1
	shl.4s	v14, v13, #23
	add.4s	v14, v14, v20
	fmul.4s	v12, v12, v14
	fadd.4s	v1, v1, v20
	sshr.4s	v14, v0, #1
	shl.4s	v15, v14, #23
	add.4s	v15, v15, v20
	fmul.4s	v1, v1, v15
	sub.4s	v11, v11, v13
	sub.4s	v0, v0, v14
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v20
	fmul.4s	v0, v1, v0
	shl.4s	v1, v11, #23
	add.4s	v1, v1, v20
	fmul.4s	v1, v12, v1
	fcmgt.4s	v11, v5, v22
	bic.16b	v1, v1, v11
	fcmgt.4s	v11, v5, v4
	bic.16b	v0, v0, v11
	fcmgt.4s	v11, v4, v3
	bit.16b	v0, v23, v11
	str	q0, [sp, #6208]                 ; 16-byte Spill
	fcmgt.4s	v0, v22, v3
	mov.16b	v12, v0
	bsl.16b	v12, v23, v1
	str	q2, [sp, #7152]                 ; 16-byte Spill
	ldr	q0, [sp, #11840]                ; 16-byte Reload
	fsub.4s	v0, v0, v2
	and.16b	v2, v8, v0
	fcmge.4s	v0, v2, v5
	fcmge.4s	v11, v3, v2
	and.16b	v11, v0, v11
	str	q30, [sp, #7136]                ; 16-byte Spill
	ldr	q1, [sp, #11856]                ; 16-byte Reload
	fsub.4s	v0, v1, v30
	ldr	q1, [sp, #11904]                ; 16-byte Reload
	and.16b	v1, v1, v0
	fcmge.4s	v14, v1, v5
	fcmge.4s	v15, v3, v1
	and.16b	v14, v14, v15
	and.16b	v14, v14, v1
	fmul.4s	v15, v14, v6
	mov.16b	v0, v27
	bsl.16b	v0, v10, v15
	fadd.4s	v15, v15, v0
	fsub.4s	v0, v15, v0
	and.16b	v11, v11, v2
	fmul.4s	v6, v11, v6
	mov.16b	v15, v27
	bsl.16b	v15, v10, v6
	fadd.4s	v6, v6, v15
	fsub.4s	v6, v6, v15
	fcvtzs.4s	v0, v0
	scvtf.4s	v15, v0
	fmul.4s	v13, v15, v7
	fsub.4s	v13, v14, v13
	fcvtzs.4s	v6, v6
	scvtf.4s	v14, v6
	fmul.4s	v7, v14, v7
	fsub.4s	v7, v11, v7
	fmul.4s	v11, v15, v16
	ldr	q15, [sp, #11904]               ; 16-byte Reload
	fmul.4s	v16, v14, v16
	fsub.4s	v7, v7, v16
	fsub.4s	v16, v13, v11
	fmul.4s	v11, v16, v17
	fmul.4s	v17, v7, v17
	fadd.4s	v17, v17, v18
	fadd.4s	v18, v11, v18
	fmul.4s	v18, v16, v18
	fmul.4s	v17, v7, v17
	fadd.4s	v17, v17, v19
	fadd.4s	v18, v18, v19
	fmul.4s	v18, v16, v18
	fmul.4s	v17, v7, v17
	fadd.4s	v17, v17, v24
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v16, v18
	fmul.4s	v17, v7, v17
	fadd.4s	v17, v17, v21
	fadd.4s	v18, v18, v21
	fmul.4s	v18, v16, v18
	movi.4s	v21, #63, lsl #24
	fadd.4s	v18, v18, v21
	fmul.4s	v19, v16, v16
	fmul.4s	v18, v19, v18
	fmul.4s	v17, v7, v17
	fadd.4s	v17, v17, v21
	fmul.4s	v19, v7, v7
	fmul.4s	v17, v19, v17
	fadd.4s	v7, v7, v17
	fadd.4s	v16, v16, v18
	fadd.4s	v7, v7, v20
	sshr.4s	v17, v6, #1
	shl.4s	v18, v17, #23
	add.4s	v18, v18, v20
	fmul.4s	v7, v7, v18
	fadd.4s	v16, v16, v20
	sshr.4s	v18, v0, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v20
	fmul.4s	v16, v16, v19
	sub.4s	v6, v6, v17
	sub.4s	v0, v0, v18
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v20
	fmul.4s	v0, v16, v0
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v20
	fmul.4s	v6, v7, v6
	fcmgt.4s	v7, v5, v2
	bic.16b	v6, v6, v7
	fcmgt.4s	v5, v5, v1
	bic.16b	v0, v0, v5
	fcmgt.4s	v5, v1, v3
	bsl.16b	v5, v23, v0
	fcmgt.4s	v0, v2, v3
	mov.16b	v3, v0
	bsl.16b	v3, v23, v6
	ldr	q0, [sp, #7104]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q7, [sp, #4816]                 ; 16-byte Reload
	ldr	q6, [sp, #7120]                 ; 16-byte Reload
	mov.16b	v16, v0
	bsl.16b	v16, v6, v7
	ldr	q0, [sp, #11888]                ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #11872]                ; 16-byte Reload
	bif.16b	v6, v7, v0
	ldr	q0, [sp, #7040]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q17, [sp, #7056]                ; 16-byte Reload
	bif.16b	v17, v7, v0
	ldr	q0, [sp, #7072]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q18, [sp, #7088]                ; 16-byte Reload
	bif.16b	v18, v7, v0
	ldr	q0, [sp, #6944]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q19, [sp, #6960]                ; 16-byte Reload
	bif.16b	v19, v7, v0
	ldr	x12, [sp, #4256]                ; 8-byte Reload
	ldr	q0, [x12, #16]
	str	q6, [sp, #7104]                 ; 16-byte Spill
	bit.16b	v0, v6, v15
	ldr	q6, [x12]
	str	q16, [sp, #7120]                ; 16-byte Spill
	bit.16b	v6, v16, v8
	stp	q6, q0, [x12]
	ldr	q0, [sp, #6976]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6992]                 ; 16-byte Reload
	mov.16b	v16, v0
	bsl.16b	v16, v6, v7
	ldr	q0, [sp, #6848]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6864]                 ; 16-byte Reload
	mov.16b	v20, v0
	bsl.16b	v20, v6, v7
	ldr	x12, [sp, #4248]                ; 8-byte Reload
	ldp	q6, q0, [x12]
	str	q18, [sp, #7072]                ; 16-byte Spill
	bit.16b	v0, v18, v15
	str	q17, [sp, #7088]                ; 16-byte Spill
	bit.16b	v6, v17, v8
	stp	q6, q0, [x12]
	ldr	q0, [sp, #6880]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6896]                 ; 16-byte Reload
	mov.16b	v17, v0
	bsl.16b	v17, v6, v7
	ldr	q0, [sp, #6752]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6768]                 ; 16-byte Reload
	mov.16b	v18, v0
	bsl.16b	v18, v6, v7
	ldr	x12, [sp, #4240]                ; 8-byte Reload
	ldp	q6, q0, [x12]
	str	q16, [sp, #7040]                ; 16-byte Spill
	bit.16b	v0, v16, v15
	str	q19, [sp, #7056]                ; 16-byte Spill
	bit.16b	v6, v19, v8
	stp	q6, q0, [x12]
	ldr	q0, [sp, #6784]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6800]                 ; 16-byte Reload
	mov.16b	v16, v0
	bsl.16b	v16, v6, v7
	ldr	q0, [sp, #6656]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6672]                 ; 16-byte Reload
	mov.16b	v19, v0
	bsl.16b	v19, v6, v7
	ldr	x12, [sp, #4232]                ; 8-byte Reload
	ldp	q6, q0, [x12]
	str	q17, [sp, #7008]                ; 16-byte Spill
	bit.16b	v0, v17, v15
	str	q20, [sp, #7024]                ; 16-byte Spill
	bit.16b	v6, v20, v8
	stp	q6, q0, [x12]
	ldr	q0, [sp, #6688]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6704]                 ; 16-byte Reload
	mov.16b	v17, v0
	bsl.16b	v17, v6, v7
	ldr	q0, [sp, #6560]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6576]                 ; 16-byte Reload
	mov.16b	v20, v0
	bsl.16b	v20, v6, v7
	ldr	x12, [sp, #4224]                ; 8-byte Reload
	ldp	q6, q0, [x12]
	str	q16, [sp, #6976]                ; 16-byte Spill
	bit.16b	v0, v16, v15
	str	q18, [sp, #6992]                ; 16-byte Spill
	bit.16b	v6, v18, v8
	stp	q6, q0, [x12]
	ldr	q0, [sp, #6592]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6608]                 ; 16-byte Reload
	mov.16b	v16, v0
	bsl.16b	v16, v6, v7
	ldr	q0, [sp, #6464]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6480]                 ; 16-byte Reload
	mov.16b	v18, v0
	bsl.16b	v18, v6, v7
	ldr	x12, [sp, #4216]                ; 8-byte Reload
	ldp	q6, q0, [x12]
	str	q17, [sp, #6944]                ; 16-byte Spill
	bit.16b	v0, v17, v15
	str	q19, [sp, #6960]                ; 16-byte Spill
	bit.16b	v6, v19, v8
	stp	q6, q0, [x12]
	ldr	q0, [sp, #6496]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6512]                 ; 16-byte Reload
	mov.16b	v17, v0
	bsl.16b	v17, v6, v7
	ldr	q0, [sp, #6400]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6416]                 ; 16-byte Reload
	mov.16b	v19, v0
	bsl.16b	v19, v6, v7
	ldr	x12, [sp, #4208]                ; 8-byte Reload
	ldp	q6, q0, [x12]
	str	q16, [sp, #6912]                ; 16-byte Spill
	bit.16b	v0, v16, v15
	str	q20, [sp, #6928]                ; 16-byte Spill
	bit.16b	v6, v20, v8
	stp	q6, q0, [x12]
	ldr	q0, [sp, #6432]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6448]                 ; 16-byte Reload
	mov.16b	v20, v0
	bsl.16b	v20, v6, v7
	ldr	q0, [sp, #6368]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6384]                 ; 16-byte Reload
	mov.16b	v16, v0
	bsl.16b	v16, v6, v7
	ldr	x12, [sp, #4200]                ; 8-byte Reload
	ldp	q6, q0, [x12]
	str	q17, [sp, #6880]                ; 16-byte Spill
	bit.16b	v0, v17, v15
	str	q18, [sp, #6896]                ; 16-byte Spill
	bit.16b	v6, v18, v8
	stp	q6, q0, [x12]
	ldr	q0, [sp, #6528]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6544]                 ; 16-byte Reload
	mov.16b	v17, v0
	bsl.16b	v17, v6, v7
	ldr	q0, [sp, #6336]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6352]                 ; 16-byte Reload
	mov.16b	v18, v0
	bsl.16b	v18, v6, v7
	ldr	x12, [sp, #4192]                ; 8-byte Reload
	ldp	q6, q0, [x12]
	str	q20, [sp, #6832]                ; 16-byte Spill
	bit.16b	v0, v20, v15
	str	q19, [sp, #6864]                ; 16-byte Spill
	bit.16b	v6, v19, v8
	stp	q6, q0, [x12]
	ldr	q0, [sp, #6624]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6640]                 ; 16-byte Reload
	mov.16b	v19, v0
	bsl.16b	v19, v6, v7
	ldr	q0, [sp, #6304]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6320]                 ; 16-byte Reload
	mov.16b	v20, v0
	bsl.16b	v20, v6, v7
	ldr	x12, [sp, #4184]                ; 8-byte Reload
	ldp	q0, q6, [x12]
	str	q17, [sp, #6816]                ; 16-byte Spill
	bit.16b	v0, v17, v8
	str	q16, [sp, #6848]                ; 16-byte Spill
	bit.16b	v6, v16, v15
	stp	q0, q6, [x12]
	ldr	q0, [sp, #6720]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q6, [sp, #6736]                 ; 16-byte Reload
	mov.16b	v16, v0
	bsl.16b	v16, v6, v7
	fcmeq.4s	v0, v9, v9
	ldr	q6, [sp, #6272]                 ; 16-byte Reload
	mov.16b	v17, v0
	bsl.16b	v17, v6, v7
	ldr	x12, [sp, #4176]                ; 8-byte Reload
	ldp	q0, q6, [x12]
	str	q19, [sp, #6784]                ; 16-byte Spill
	bit.16b	v0, v19, v8
	str	q18, [sp, #6800]                ; 16-byte Spill
	bit.16b	v6, v18, v15
	stp	q0, q6, [x12]
	fcmeq.4s	v0, v31, v31
	ldr	q6, [sp, #6288]                 ; 16-byte Reload
	mov.16b	v18, v0
	bsl.16b	v18, v6, v7
	fcmeq.4s	v0, v29, v29
	ldr	q6, [sp, #6240]                 ; 16-byte Reload
	mov.16b	v19, v0
	bsl.16b	v19, v6, v7
	ldr	x12, [sp, #4168]                ; 8-byte Reload
	ldp	q0, q6, [x12]
	str	q16, [sp, #6752]                ; 16-byte Spill
	bit.16b	v0, v16, v8
	str	q20, [sp, #6768]                ; 16-byte Spill
	bit.16b	v6, v20, v15
	stp	q0, q6, [x12]
	fcmeq.4s	v0, v28, v28
	ldr	q6, [sp, #6256]                 ; 16-byte Reload
	mov.16b	v16, v0
	bsl.16b	v16, v6, v7
	fcmeq.4s	v0, v26, v26
	ldr	q6, [sp, #6224]                 ; 16-byte Reload
	mov.16b	v20, v0
	bsl.16b	v20, v6, v7
	ldr	x12, [sp, #4160]                ; 8-byte Reload
	ldp	q0, q6, [x12]
	str	q18, [sp, #6720]                ; 16-byte Spill
	bit.16b	v0, v18, v8
	str	q17, [sp, #6736]                ; 16-byte Spill
	bit.16b	v6, v17, v15
	stp	q0, q6, [x12]
	fcmeq.4s	v0, v25, v25
	ldr	q6, [sp, #6192]                 ; 16-byte Reload
	bif.16b	v6, v7, v0
	fcmeq.4s	v0, v22, v22
	mov.16b	v17, v0
	bsl.16b	v17, v12, v7
	fcmeq.4s	v0, v4, v4
	ldr	q4, [sp, #6208]                 ; 16-byte Reload
	mov.16b	v18, v0
	bsl.16b	v18, v4, v7
	ldr	x12, [sp, #4152]                ; 8-byte Reload
	ldp	q4, q0, [x12]
	str	q16, [sp, #6688]                ; 16-byte Spill
	bit.16b	v0, v16, v15
	str	q19, [sp, #6704]                ; 16-byte Spill
	bit.16b	v4, v19, v8
	stp	q4, q0, [x12]
	ldr	x12, [sp, #4144]                ; 8-byte Reload
	ldp	q0, q4, [x12]
	str	q6, [sp, #6656]                 ; 16-byte Spill
	bit.16b	v0, v6, v8
	str	q20, [sp, #6672]                ; 16-byte Spill
	bit.16b	v4, v20, v15
	stp	q0, q4, [x12]
	ldp	q0, q4, [x1]
	str	q18, [sp, #6624]                ; 16-byte Spill
	bit.16b	v0, v18, v8
	str	q17, [sp, #6640]                ; 16-byte Spill
	bit.16b	v4, v17, v15
	stp	q0, q4, [x1]
	fcmeq.4s	v0, v2, v2
	mov.16b	v6, v0
	bsl.16b	v6, v3, v7
	fcmeq.4s	v0, v1, v1
	bit.16b	v7, v5, v0
	ldr	q0, [sp, #9776]                 ; 16-byte Reload
	fmul.4s	v0, v0, v6
	ldr	q4, [sp, #7376]                 ; 16-byte Reload
	bit.16b	v4, v0, v8
	ldr	q0, [sp, #9792]                 ; 16-byte Reload
	fmul.4s	v0, v0, v7
	ldr	q5, [sp, #7360]                 ; 16-byte Reload
	bit.16b	v5, v0, v15
	add	x12, x8, #8, lsl #12            ; =32768
	mov.16b	v14, v8
LBB0_1097:                              ; %direct.true4157
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x15, x10, x30
	ldp	q0, q1, [x15]
	ldp	q2, q3, [x12]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v4, v0
	fadd.4s	v1, v5, v1
	bit.16b	v5, v1, v15
	bit.16b	v4, v0, v14
	add	x30, x30, #32
	add	x12, x12, #2048
	cmp	x30, #512
	b.ne	LBB0_1097
; %bb.1098:                             ; %direct.false4158
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #6592]                 ; 16-byte Spill
	str	q0, [sp, #6608]                 ; 16-byte Spill
	str	q5, [sp, #7360]                 ; 16-byte Spill
	str	q4, [sp, #7376]                 ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #9808]                 ; 16-byte Reload
	str	q6, [sp, #11872]                ; 16-byte Spill
	fmul.4s	v0, v0, v6
	ldr	q1, [sp, #9824]                 ; 16-byte Reload
	str	q7, [sp, #11888]                ; 16-byte Spill
	fmul.4s	v1, v1, v7
	ldr	q19, [sp, #7200]                ; 16-byte Reload
	bit.16b	v19, v1, v15
	ldr	q7, [sp, #7216]                 ; 16-byte Reload
	bit.16b	v7, v0, v14
	ldr	x15, [sp, #4888]                ; 8-byte Reload
	ldr	q5, [sp, #8096]                 ; 16-byte Reload
	ldr	q22, [sp, #8064]                ; 16-byte Reload
	ldr	q23, [sp, #8032]                ; 16-byte Reload
	ldr	q28, [sp, #8000]                ; 16-byte Reload
	ldr	q29, [sp, #7968]                ; 16-byte Reload
	ldr	q16, [sp, #7936]                ; 16-byte Reload
	ldr	q4, [sp, #7904]                 ; 16-byte Reload
	ldr	q31, [sp, #7872]                ; 16-byte Reload
	ldr	q10, [sp, #7840]                ; 16-byte Reload
	ldr	q30, [sp, #7808]                ; 16-byte Reload
	ldr	q24, [sp, #7776]                ; 16-byte Reload
	ldr	q11, [sp, #7744]                ; 16-byte Reload
	ldr	q8, [sp, #7712]                 ; 16-byte Reload
	ldr	q9, [sp, #7680]                 ; 16-byte Reload
	ldr	q25, [sp, #7648]                ; 16-byte Reload
	ldr	q12, [sp, #7616]                ; 16-byte Reload
	ldr	q26, [sp, #7584]                ; 16-byte Reload
	ldr	q27, [sp, #7552]                ; 16-byte Reload
	ldr	q13, [sp, #7520]                ; 16-byte Reload
	ldr	q20, [sp, #7488]                ; 16-byte Reload
	ldr	q21, [sp, #7456]                ; 16-byte Reload
	ldr	q17, [sp, #7424]                ; 16-byte Reload
	ldr	q18, [sp, #7280]                ; 16-byte Reload
	ldr	q6, [sp, #7248]                 ; 16-byte Reload
LBB0_1099:                              ; %direct.true4174
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v7, v0
	fadd.4s	v1, v19, v1
	bit.16b	v19, v1, v15
	bit.16b	v7, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1099
; %bb.1100:                             ; %direct.false4175
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #6560]                 ; 16-byte Spill
	str	q0, [sp, #6576]                 ; 16-byte Spill
	str	q19, [sp, #7200]                ; 16-byte Spill
	str	q7, [sp, #7216]                 ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #9840]                 ; 16-byte Reload
	ldr	q19, [sp, #11872]               ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #9856]                 ; 16-byte Reload
	ldr	q2, [sp, #11888]                ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q7, [sp, #7232]                 ; 16-byte Reload
	bit.16b	v7, v1, v15
	bit.16b	v6, v0, v14
	ldr	x15, [sp, #4880]                ; 8-byte Reload
LBB0_1101:                              ; %direct.true4191
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v6, v0
	fadd.4s	v1, v7, v1
	bit.16b	v7, v1, v15
	bit.16b	v6, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1101
; %bb.1102:                             ; %direct.false4192
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #6528]                 ; 16-byte Spill
	str	q0, [sp, #6544]                 ; 16-byte Spill
	str	q7, [sp, #7232]                 ; 16-byte Spill
	str	q6, [sp, #7248]                 ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #9872]                 ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #9888]                 ; 16-byte Reload
	ldr	q7, [sp, #11888]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q6, [sp, #7264]                 ; 16-byte Reload
	bit.16b	v6, v1, v15
	bit.16b	v18, v0, v14
	ldr	x15, [sp, #4872]                ; 8-byte Reload
LBB0_1103:                              ; %direct.true4208
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v18, v0
	fadd.4s	v1, v6, v1
	bit.16b	v6, v1, v15
	bit.16b	v18, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1103
; %bb.1104:                             ; %direct.false4209
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #6496]                 ; 16-byte Spill
	str	q0, [sp, #6512]                 ; 16-byte Spill
	str	q6, [sp, #7264]                 ; 16-byte Spill
	str	q18, [sp, #7280]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #9904]                 ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #9920]                 ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q18, [sp, #7408]                ; 16-byte Reload
	bit.16b	v18, v1, v15
	bit.16b	v17, v0, v14
	ldr	x15, [sp, #4864]                ; 8-byte Reload
LBB0_1105:                              ; %direct.true4225
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v17, v0
	fadd.4s	v1, v18, v1
	bit.16b	v18, v1, v15
	bit.16b	v17, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1105
; %bb.1106:                             ; %direct.false4226
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #6464]                 ; 16-byte Spill
	str	q0, [sp, #6480]                 ; 16-byte Spill
	str	q18, [sp, #7408]                ; 16-byte Spill
	str	q17, [sp, #7424]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #9936]                 ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #9952]                 ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q17, [sp, #7440]                ; 16-byte Reload
	bit.16b	v17, v1, v15
	bit.16b	v21, v0, v14
	ldr	x15, [sp, #4856]                ; 8-byte Reload
	ldr	q6, [sp, #8192]                 ; 16-byte Reload
LBB0_1107:                              ; %direct.true4242
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v21, v0
	fadd.4s	v1, v17, v1
	bit.16b	v17, v1, v15
	bit.16b	v21, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1107
; %bb.1108:                             ; %direct.false4243
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #6432]                 ; 16-byte Spill
	str	q0, [sp, #6448]                 ; 16-byte Spill
	str	q17, [sp, #7440]                ; 16-byte Spill
	str	q21, [sp, #7456]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #9968]                 ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #9984]                 ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q21, [sp, #7472]                ; 16-byte Reload
	bit.16b	v21, v1, v15
	bit.16b	v20, v0, v14
	ldr	x15, [sp, #4848]                ; 8-byte Reload
	ldr	q18, [sp, #8128]                ; 16-byte Reload
LBB0_1109:                              ; %direct.true4259
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v20, v0
	fadd.4s	v1, v21, v1
	bit.16b	v21, v1, v15
	bit.16b	v20, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1109
; %bb.1110:                             ; %direct.false4260
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #6400]                 ; 16-byte Spill
	str	q0, [sp, #6416]                 ; 16-byte Spill
	str	q21, [sp, #7472]                ; 16-byte Spill
	str	q20, [sp, #7488]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10000]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10016]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q20, [sp, #7504]                ; 16-byte Reload
	bit.16b	v20, v1, v15
	bit.16b	v13, v0, v14
	ldr	x15, [sp, #4840]                ; 8-byte Reload
	ldr	q17, [sp, #8224]                ; 16-byte Reload
LBB0_1111:                              ; %direct.true4276
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v13, v0
	fadd.4s	v1, v20, v1
	bit.16b	v20, v1, v15
	bit.16b	v13, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1111
; %bb.1112:                             ; %direct.false4277
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #6368]                 ; 16-byte Spill
	str	q0, [sp, #6384]                 ; 16-byte Spill
	str	q20, [sp, #7504]                ; 16-byte Spill
	str	q13, [sp, #7520]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10032]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10048]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q13, [sp, #7536]                ; 16-byte Reload
	bit.16b	v13, v1, v15
	bit.16b	v27, v0, v14
	ldr	x15, [sp, #4832]                ; 8-byte Reload
LBB0_1113:                              ; %direct.true4293
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v27, v0
	fadd.4s	v1, v13, v1
	bit.16b	v13, v1, v15
	bit.16b	v27, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1113
; %bb.1114:                             ; %direct.false4294
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #6336]                 ; 16-byte Spill
	str	q0, [sp, #6352]                 ; 16-byte Spill
	str	q13, [sp, #7536]                ; 16-byte Spill
	str	q27, [sp, #7552]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10064]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10080]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q27, [sp, #7568]                ; 16-byte Reload
	bit.16b	v27, v1, v15
	bit.16b	v26, v0, v14
	ldr	x15, [sp, #4808]                ; 8-byte Reload
LBB0_1115:                              ; %direct.true4310
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v26, v0
	fadd.4s	v1, v27, v1
	bit.16b	v27, v1, v15
	bit.16b	v26, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1115
; %bb.1116:                             ; %direct.false4311
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #6304]                 ; 16-byte Spill
	str	q0, [sp, #6320]                 ; 16-byte Spill
	str	q27, [sp, #7568]                ; 16-byte Spill
	str	q26, [sp, #7584]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10096]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10112]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q26, [sp, #7600]                ; 16-byte Reload
	bit.16b	v26, v1, v15
	bit.16b	v12, v0, v14
	ldr	x15, [sp, #4800]                ; 8-byte Reload
LBB0_1117:                              ; %direct.true4327
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v12, v0
	fadd.4s	v1, v26, v1
	bit.16b	v26, v1, v15
	bit.16b	v12, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1117
; %bb.1118:                             ; %direct.false4328
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #6272]                 ; 16-byte Spill
	str	q0, [sp, #6288]                 ; 16-byte Spill
	str	q26, [sp, #7600]                ; 16-byte Spill
	str	q12, [sp, #7616]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10128]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10144]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q12, [sp, #7632]                ; 16-byte Reload
	bit.16b	v12, v1, v15
	bit.16b	v25, v0, v14
	ldr	x15, [sp, #4792]                ; 8-byte Reload
LBB0_1119:                              ; %direct.true4344
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v25, v0
	fadd.4s	v1, v12, v1
	bit.16b	v12, v1, v15
	bit.16b	v25, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1119
; %bb.1120:                             ; %direct.false4345
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #6240]                 ; 16-byte Spill
	str	q0, [sp, #6256]                 ; 16-byte Spill
	str	q12, [sp, #7632]                ; 16-byte Spill
	str	q25, [sp, #7648]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10160]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10176]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q25, [sp, #7664]                ; 16-byte Reload
	bit.16b	v25, v1, v15
	bit.16b	v9, v0, v14
	ldr	x15, [sp, #4784]                ; 8-byte Reload
	ldr	q26, [sp, #8416]                ; 16-byte Reload
LBB0_1121:                              ; %direct.true4361
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v9, v0
	fadd.4s	v1, v25, v1
	bit.16b	v25, v1, v15
	bit.16b	v9, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1121
; %bb.1122:                             ; %direct.false4362
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #6208]                 ; 16-byte Spill
	str	q0, [sp, #6224]                 ; 16-byte Spill
	str	q25, [sp, #7664]                ; 16-byte Spill
	str	q9, [sp, #7680]                 ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10192]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10208]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q9, [sp, #7696]                 ; 16-byte Reload
	bit.16b	v9, v1, v15
	bit.16b	v8, v0, v14
	ldr	x15, [sp, #4776]                ; 8-byte Reload
LBB0_1123:                              ; %direct.true4378
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v8, v0
	fadd.4s	v1, v9, v1
	bit.16b	v9, v1, v15
	bit.16b	v8, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1123
; %bb.1124:                             ; %direct.false4379
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #6176]                 ; 16-byte Spill
	str	q0, [sp, #6192]                 ; 16-byte Spill
	str	q9, [sp, #7696]                 ; 16-byte Spill
	str	q8, [sp, #7712]                 ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10224]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10240]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q8, [sp, #7728]                 ; 16-byte Reload
	bit.16b	v8, v1, v15
	bit.16b	v11, v0, v14
	ldr	x15, [sp, #4768]                ; 8-byte Reload
	ldr	q25, [sp, #8480]                ; 16-byte Reload
LBB0_1125:                              ; %direct.true4395
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v11, v0
	fadd.4s	v1, v8, v1
	bit.16b	v8, v1, v15
	bit.16b	v11, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1125
; %bb.1126:                             ; %direct.false4396
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #6144]                 ; 16-byte Spill
	str	q0, [sp, #6160]                 ; 16-byte Spill
	str	q8, [sp, #7728]                 ; 16-byte Spill
	str	q11, [sp, #7744]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10256]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10272]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q11, [sp, #7760]                ; 16-byte Reload
	bit.16b	v11, v1, v15
	bit.16b	v24, v0, v14
	ldr	x15, [sp, #4760]                ; 8-byte Reload
LBB0_1127:                              ; %direct.true4412
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v24, v0
	fadd.4s	v1, v11, v1
	bit.16b	v11, v1, v15
	bit.16b	v24, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1127
; %bb.1128:                             ; %direct.false4413
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #6112]                 ; 16-byte Spill
	str	q0, [sp, #6128]                 ; 16-byte Spill
	str	q11, [sp, #7760]                ; 16-byte Spill
	str	q24, [sp, #7776]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10288]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10304]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q24, [sp, #7792]                ; 16-byte Reload
	bit.16b	v24, v1, v15
	bit.16b	v30, v0, v14
	mov	x15, x10
LBB0_1129:                              ; %direct.true4429
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q0, q1, [x15], #32
	add	x16, x23, x12
	ldp	q2, q3, [x16]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v30, v0
	fadd.4s	v1, v24, v1
	bit.16b	v24, v1, v15
	bit.16b	v30, v0, v14
	add	x12, x12, #2048
	cmp	x12, #8, lsl #12                ; =32768
	b.ne	LBB0_1129
; %bb.1130:                             ; %direct.false4430
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #6080]                 ; 16-byte Spill
	str	q0, [sp, #6096]                 ; 16-byte Spill
	str	q24, [sp, #7792]                ; 16-byte Spill
	str	q30, [sp, #7808]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10320]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10336]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q30, [sp, #7824]                ; 16-byte Reload
	bit.16b	v30, v1, v15
	bit.16b	v10, v0, v14
	ldr	x15, [sp, #4752]                ; 8-byte Reload
LBB0_1131:                              ; %direct.true4446
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v10, v0
	fadd.4s	v1, v30, v1
	bit.16b	v30, v1, v15
	bit.16b	v10, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1131
; %bb.1132:                             ; %direct.false4447
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #6048]                 ; 16-byte Spill
	str	q0, [sp, #6064]                 ; 16-byte Spill
	str	q30, [sp, #7824]                ; 16-byte Spill
	str	q10, [sp, #7840]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10352]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10368]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q10, [sp, #7856]                ; 16-byte Reload
	bit.16b	v10, v1, v15
	bit.16b	v31, v0, v14
	ldr	x15, [sp, #4744]                ; 8-byte Reload
	ldr	q24, [sp, #11824]               ; 16-byte Reload
LBB0_1133:                              ; %direct.true4463
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v31, v0
	fadd.4s	v1, v10, v1
	bit.16b	v10, v1, v15
	bit.16b	v31, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1133
; %bb.1134:                             ; %direct.false4464
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #6016]                 ; 16-byte Spill
	str	q0, [sp, #6032]                 ; 16-byte Spill
	str	q10, [sp, #7856]                ; 16-byte Spill
	str	q31, [sp, #7872]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10384]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10400]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q31, [sp, #7888]                ; 16-byte Reload
	bit.16b	v31, v1, v15
	bit.16b	v4, v0, v14
	ldr	x15, [sp, #4736]                ; 8-byte Reload
	ldr	q30, [sp, #8512]                ; 16-byte Reload
LBB0_1135:                              ; %direct.true4480
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v4, v0
	fadd.4s	v1, v31, v1
	bit.16b	v31, v1, v15
	bit.16b	v4, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1135
; %bb.1136:                             ; %direct.false4481
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5984]                 ; 16-byte Spill
	str	q0, [sp, #6000]                 ; 16-byte Spill
	str	q31, [sp, #7888]                ; 16-byte Spill
	str	q4, [sp, #7904]                 ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10416]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10432]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q4, [sp, #7920]                 ; 16-byte Reload
	bit.16b	v4, v1, v15
	bit.16b	v16, v0, v14
	ldr	x15, [sp, #4728]                ; 8-byte Reload
LBB0_1137:                              ; %direct.true4497
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v16, v0
	fadd.4s	v1, v4, v1
	bit.16b	v4, v1, v15
	bit.16b	v16, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1137
; %bb.1138:                             ; %direct.false4498
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5952]                 ; 16-byte Spill
	str	q0, [sp, #5968]                 ; 16-byte Spill
	str	q4, [sp, #7920]                 ; 16-byte Spill
	str	q16, [sp, #7936]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10448]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10464]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q16, [sp, #7952]                ; 16-byte Reload
	bit.16b	v16, v1, v15
	bit.16b	v29, v0, v14
	ldr	x15, [sp, #4720]                ; 8-byte Reload
LBB0_1139:                              ; %direct.true4514
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v29, v0
	fadd.4s	v1, v16, v1
	bit.16b	v16, v1, v15
	bit.16b	v29, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1139
; %bb.1140:                             ; %direct.false4515
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5920]                 ; 16-byte Spill
	str	q0, [sp, #5936]                 ; 16-byte Spill
	str	q16, [sp, #7952]                ; 16-byte Spill
	str	q29, [sp, #7968]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10480]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10496]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q29, [sp, #7984]                ; 16-byte Reload
	bit.16b	v29, v1, v15
	bit.16b	v28, v0, v14
	ldr	x15, [sp, #4712]                ; 8-byte Reload
	ldr	q4, [sp, #8720]                 ; 16-byte Reload
LBB0_1141:                              ; %direct.true4531
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v28, v0
	fadd.4s	v1, v29, v1
	bit.16b	v29, v1, v15
	bit.16b	v28, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1141
; %bb.1142:                             ; %direct.false4532
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5888]                 ; 16-byte Spill
	str	q0, [sp, #5904]                 ; 16-byte Spill
	str	q29, [sp, #7984]                ; 16-byte Spill
	str	q28, [sp, #8000]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10512]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10528]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	mov.16b	v28, v14
	ldr	q14, [sp, #8016]                ; 16-byte Reload
	bit.16b	v14, v1, v15
	bit.16b	v23, v0, v28
	ldr	x15, [sp, #4704]                ; 8-byte Reload
	ldr	q16, [sp, #8752]                ; 16-byte Reload
LBB0_1143:                              ; %direct.true4548
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v23, v0
	fadd.4s	v1, v14, v1
	bit.16b	v14, v1, v15
	bit.16b	v23, v0, v28
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1143
; %bb.1144:                             ; %direct.false4549
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5856]                 ; 16-byte Spill
	str	q0, [sp, #5872]                 ; 16-byte Spill
	str	q14, [sp, #8016]                ; 16-byte Spill
	str	q23, [sp, #8032]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10544]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10560]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q23, [sp, #8048]                ; 16-byte Reload
	bit.16b	v23, v1, v15
	bit.16b	v22, v0, v28
	ldr	x15, [sp, #4696]                ; 8-byte Reload
	mov.16b	v14, v28
	ldr	q29, [sp, #8576]                ; 16-byte Reload
LBB0_1145:                              ; %direct.true4565
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v22, v0
	fadd.4s	v1, v23, v1
	bit.16b	v23, v1, v15
	bit.16b	v22, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1145
; %bb.1146:                             ; %direct.false4566
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5824]                 ; 16-byte Spill
	str	q0, [sp, #5840]                 ; 16-byte Spill
	str	q23, [sp, #8048]                ; 16-byte Spill
	str	q22, [sp, #8064]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10576]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10592]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q22, [sp, #8080]                ; 16-byte Reload
	bit.16b	v22, v1, v15
	bit.16b	v5, v0, v14
	ldr	x15, [sp, #4688]                ; 8-byte Reload
	ldr	q28, [sp, #8624]                ; 16-byte Reload
LBB0_1147:                              ; %direct.true4582
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v5, v0
	fadd.4s	v1, v22, v1
	bit.16b	v22, v1, v15
	bit.16b	v5, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1147
; %bb.1148:                             ; %direct.false4583
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5792]                 ; 16-byte Spill
	str	q0, [sp, #5808]                 ; 16-byte Spill
	str	q22, [sp, #8080]                ; 16-byte Spill
	str	q5, [sp, #8096]                 ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10608]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10624]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q5, [sp, #8112]                 ; 16-byte Reload
	bit.16b	v5, v1, v15
	bit.16b	v18, v0, v14
	ldr	x15, [sp, #4680]                ; 8-byte Reload
	ldr	q23, [sp, #8688]                ; 16-byte Reload
LBB0_1149:                              ; %direct.true4599
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v18, v0
	fadd.4s	v1, v5, v1
	bit.16b	v5, v1, v15
	bit.16b	v18, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1149
; %bb.1150:                             ; %direct.false4600
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5760]                 ; 16-byte Spill
	str	q0, [sp, #5776]                 ; 16-byte Spill
	str	q5, [sp, #8112]                 ; 16-byte Spill
	str	q18, [sp, #8128]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10640]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10656]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q19, [sp, #8144]                ; 16-byte Reload
	bit.16b	v19, v1, v15
	ldr	q5, [sp, #8160]                 ; 16-byte Reload
	bit.16b	v5, v0, v14
	ldr	x15, [sp, #4672]                ; 8-byte Reload
	ldr	q22, [sp, #8880]                ; 16-byte Reload
LBB0_1151:                              ; %direct.true4616
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v5, v0
	fadd.4s	v1, v19, v1
	bit.16b	v19, v1, v15
	bit.16b	v5, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1151
; %bb.1152:                             ; %direct.false4617
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5728]                 ; 16-byte Spill
	str	q0, [sp, #5744]                 ; 16-byte Spill
	str	q19, [sp, #8144]                ; 16-byte Spill
	str	q5, [sp, #8160]                 ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10672]                ; 16-byte Reload
	ldr	q19, [sp, #11872]               ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10688]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q7, [sp, #8176]                 ; 16-byte Reload
	bit.16b	v7, v1, v15
	bit.16b	v6, v0, v14
	ldr	x15, [sp, #4664]                ; 8-byte Reload
	ldr	q5, [sp, #8896]                 ; 16-byte Reload
LBB0_1153:                              ; %direct.true4633
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v6, v0
	fadd.4s	v1, v7, v1
	bit.16b	v7, v1, v15
	bit.16b	v6, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1153
; %bb.1154:                             ; %direct.false4634
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5696]                 ; 16-byte Spill
	str	q0, [sp, #5712]                 ; 16-byte Spill
	str	q7, [sp, #8176]                 ; 16-byte Spill
	str	q6, [sp, #8192]                 ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10704]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10720]                ; 16-byte Reload
	ldr	q7, [sp, #11888]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q6, [sp, #8208]                 ; 16-byte Reload
	bit.16b	v6, v1, v15
	bit.16b	v17, v0, v14
	ldr	x15, [sp, #4656]                ; 8-byte Reload
LBB0_1155:                              ; %direct.true4650
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v17, v0
	fadd.4s	v1, v6, v1
	bit.16b	v6, v1, v15
	bit.16b	v17, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1155
; %bb.1156:                             ; %direct.false4651
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5664]                 ; 16-byte Spill
	str	q0, [sp, #5680]                 ; 16-byte Spill
	str	q6, [sp, #8208]                 ; 16-byte Spill
	str	q17, [sp, #8224]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10736]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10752]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q18, [sp, #8240]                ; 16-byte Reload
	bit.16b	v18, v1, v15
	ldr	q6, [sp, #8256]                 ; 16-byte Reload
	bit.16b	v6, v0, v14
	ldr	x15, [sp, #4648]                ; 8-byte Reload
LBB0_1157:                              ; %direct.true4667
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v6, v0
	fadd.4s	v1, v18, v1
	bit.16b	v18, v1, v15
	bit.16b	v6, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1157
; %bb.1158:                             ; %direct.false4668
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5632]                 ; 16-byte Spill
	str	q0, [sp, #5648]                 ; 16-byte Spill
	str	q18, [sp, #8240]                ; 16-byte Spill
	str	q6, [sp, #8256]                 ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10768]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10784]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q17, [sp, #8272]                ; 16-byte Reload
	bit.16b	v17, v1, v15
	ldr	q18, [sp, #8288]                ; 16-byte Reload
	bit.16b	v18, v0, v14
	ldr	x15, [sp, #4640]                ; 8-byte Reload
	ldr	q6, [sp, #8976]                 ; 16-byte Reload
LBB0_1159:                              ; %direct.true4684
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v18, v0
	fadd.4s	v1, v17, v1
	bit.16b	v17, v1, v15
	bit.16b	v18, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1159
; %bb.1160:                             ; %direct.false4685
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5600]                 ; 16-byte Spill
	str	q0, [sp, #5616]                 ; 16-byte Spill
	str	q17, [sp, #8272]                ; 16-byte Spill
	str	q18, [sp, #8288]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10800]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10816]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q21, [sp, #8304]                ; 16-byte Reload
	bit.16b	v21, v1, v15
	ldr	q17, [sp, #8320]                ; 16-byte Reload
	bit.16b	v17, v0, v14
	ldr	x15, [sp, #4632]                ; 8-byte Reload
	ldr	q18, [sp, #8960]                ; 16-byte Reload
LBB0_1161:                              ; %direct.true4701
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v17, v0
	fadd.4s	v1, v21, v1
	bit.16b	v21, v1, v15
	bit.16b	v17, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1161
; %bb.1162:                             ; %direct.false4702
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5568]                 ; 16-byte Spill
	str	q0, [sp, #5584]                 ; 16-byte Spill
	str	q21, [sp, #8304]                ; 16-byte Spill
	str	q17, [sp, #8320]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10832]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10848]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q20, [sp, #8336]                ; 16-byte Reload
	bit.16b	v20, v1, v15
	ldr	q21, [sp, #8352]                ; 16-byte Reload
	bit.16b	v21, v0, v14
	ldr	x15, [sp, #4624]                ; 8-byte Reload
	ldr	q17, [sp, #8992]                ; 16-byte Reload
LBB0_1163:                              ; %direct.true4718
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v21, v0
	fadd.4s	v1, v20, v1
	bit.16b	v20, v1, v15
	bit.16b	v21, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1163
; %bb.1164:                             ; %direct.false4719
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5536]                 ; 16-byte Spill
	str	q0, [sp, #5552]                 ; 16-byte Spill
	str	q20, [sp, #8336]                ; 16-byte Spill
	str	q21, [sp, #8352]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10864]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10880]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q13, [sp, #8368]                ; 16-byte Reload
	bit.16b	v13, v1, v15
	ldr	q20, [sp, #8384]                ; 16-byte Reload
	bit.16b	v20, v0, v14
	ldr	x15, [sp, #4616]                ; 8-byte Reload
	ldr	q21, [sp, #9056]                ; 16-byte Reload
LBB0_1165:                              ; %direct.true4735
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v20, v0
	fadd.4s	v1, v13, v1
	bit.16b	v13, v1, v15
	bit.16b	v20, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1165
; %bb.1166:                             ; %direct.false4736
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5504]                 ; 16-byte Spill
	str	q0, [sp, #5520]                 ; 16-byte Spill
	str	q13, [sp, #8368]                ; 16-byte Spill
	str	q20, [sp, #8384]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10896]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10912]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q27, [sp, #8400]                ; 16-byte Reload
	bit.16b	v27, v1, v15
	bit.16b	v26, v0, v14
	ldr	x15, [sp, #4608]                ; 8-byte Reload
	ldr	q20, [sp, #9072]                ; 16-byte Reload
LBB0_1167:                              ; %direct.true4752
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v26, v0
	fadd.4s	v1, v27, v1
	bit.16b	v27, v1, v15
	bit.16b	v26, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1167
; %bb.1168:                             ; %direct.false4753
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5472]                 ; 16-byte Spill
	str	q0, [sp, #5488]                 ; 16-byte Spill
	str	q27, [sp, #8400]                ; 16-byte Spill
	str	q26, [sp, #8416]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10928]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10944]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q26, [sp, #8432]                ; 16-byte Reload
	bit.16b	v26, v1, v15
	ldr	q27, [sp, #8448]                ; 16-byte Reload
	bit.16b	v27, v0, v14
	ldr	x15, [sp, #4600]                ; 8-byte Reload
LBB0_1169:                              ; %direct.true4769
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v27, v0
	fadd.4s	v1, v26, v1
	bit.16b	v26, v1, v15
	bit.16b	v27, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1169
; %bb.1170:                             ; %direct.false4770
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5440]                 ; 16-byte Spill
	str	q0, [sp, #5456]                 ; 16-byte Spill
	str	q26, [sp, #8432]                ; 16-byte Spill
	str	q27, [sp, #8448]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10960]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #10976]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q12, [sp, #8464]                ; 16-byte Reload
	bit.16b	v12, v1, v15
	bit.16b	v25, v0, v14
	ldr	x15, [sp, #4592]                ; 8-byte Reload
	ldr	q27, [sp, #9040]                ; 16-byte Reload
LBB0_1171:                              ; %direct.true4786
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v25, v0
	fadd.4s	v1, v12, v1
	bit.16b	v12, v1, v15
	bit.16b	v25, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1171
; %bb.1172:                             ; %direct.false4787
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5408]                 ; 16-byte Spill
	str	q0, [sp, #5424]                 ; 16-byte Spill
	str	q12, [sp, #8464]                ; 16-byte Spill
	str	q25, [sp, #8480]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #10992]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #11008]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q25, [sp, #8496]                ; 16-byte Reload
	bit.16b	v25, v1, v15
	bit.16b	v30, v0, v14
	ldr	x15, [sp, #4584]                ; 8-byte Reload
	ldr	q26, [sp, #9088]                ; 16-byte Reload
LBB0_1173:                              ; %direct.true4803
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v30, v0
	fadd.4s	v1, v25, v1
	bit.16b	v25, v1, v15
	bit.16b	v30, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1173
; %bb.1174:                             ; %direct.false4804
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5376]                 ; 16-byte Spill
	str	q0, [sp, #5392]                 ; 16-byte Spill
	str	q25, [sp, #8496]                ; 16-byte Spill
	str	q30, [sp, #8512]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #11024]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #11040]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q9, [sp, #8528]                 ; 16-byte Reload
	bit.16b	v9, v1, v15
	ldr	q25, [sp, #8544]                ; 16-byte Reload
	bit.16b	v25, v0, v14
	ldr	x15, [sp, #4576]                ; 8-byte Reload
LBB0_1175:                              ; %direct.true4820
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v25, v0
	fadd.4s	v1, v9, v1
	bit.16b	v9, v1, v15
	bit.16b	v25, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1175
; %bb.1176:                             ; %direct.false4821
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5344]                 ; 16-byte Spill
	str	q0, [sp, #5360]                 ; 16-byte Spill
	str	q9, [sp, #8528]                 ; 16-byte Spill
	str	q25, [sp, #8544]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #11056]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #11072]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q8, [sp, #8560]                 ; 16-byte Reload
	bit.16b	v8, v1, v15
	bit.16b	v29, v0, v14
	ldr	x15, [sp, #4568]                ; 8-byte Reload
	ldr	q25, [sp, #9120]                ; 16-byte Reload
LBB0_1177:                              ; %direct.true4837
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v29, v0
	fadd.4s	v1, v8, v1
	bit.16b	v8, v1, v15
	bit.16b	v29, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1177
; %bb.1178:                             ; %direct.false4838
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5312]                 ; 16-byte Spill
	str	q0, [sp, #5328]                 ; 16-byte Spill
	str	q8, [sp, #8560]                 ; 16-byte Spill
	str	q29, [sp, #8576]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #11088]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #11104]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q11, [sp, #8592]                ; 16-byte Reload
	bit.16b	v11, v1, v15
	bit.16b	v24, v0, v14
	ldr	x15, [sp, #4560]                ; 8-byte Reload
LBB0_1179:                              ; %direct.true4854
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v24, v0
	fadd.4s	v1, v11, v1
	bit.16b	v11, v1, v15
	bit.16b	v24, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1179
; %bb.1180:                             ; %direct.false4855
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5280]                 ; 16-byte Spill
	str	q0, [sp, #5296]                 ; 16-byte Spill
	str	q11, [sp, #8592]                ; 16-byte Spill
	str	q24, [sp, #11824]               ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #11120]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #11136]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q24, [sp, #8608]                ; 16-byte Reload
	bit.16b	v24, v1, v15
	bit.16b	v28, v0, v14
	ldr	x15, [sp, #4552]                ; 8-byte Reload
LBB0_1181:                              ; %direct.true4871
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v28, v0
	fadd.4s	v1, v24, v1
	bit.16b	v24, v1, v15
	bit.16b	v28, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1181
; %bb.1182:                             ; %direct.false4872
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5248]                 ; 16-byte Spill
	str	q0, [sp, #5264]                 ; 16-byte Spill
	str	q24, [sp, #8608]                ; 16-byte Spill
	str	q28, [sp, #8624]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #11152]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #11168]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q30, [sp, #8640]                ; 16-byte Reload
	bit.16b	v30, v1, v15
	ldr	q24, [sp, #8656]                ; 16-byte Reload
	bit.16b	v24, v0, v14
	ldr	x15, [sp, #4544]                ; 8-byte Reload
LBB0_1183:                              ; %direct.true4888
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v24, v0
	fadd.4s	v1, v30, v1
	bit.16b	v30, v1, v15
	bit.16b	v24, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1183
; %bb.1184:                             ; %direct.false4889
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5216]                 ; 16-byte Spill
	str	q0, [sp, #5232]                 ; 16-byte Spill
	str	q30, [sp, #8640]                ; 16-byte Spill
	str	q24, [sp, #8656]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #11184]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #11200]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q10, [sp, #8672]                ; 16-byte Reload
	bit.16b	v10, v1, v15
	bit.16b	v23, v0, v14
	ldr	x15, [sp, #4536]                ; 8-byte Reload
	ldr	q24, [sp, #9104]                ; 16-byte Reload
LBB0_1185:                              ; %direct.true4905
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v23, v0
	fadd.4s	v1, v10, v1
	bit.16b	v10, v1, v15
	bit.16b	v23, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1185
; %bb.1186:                             ; %direct.false4906
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5184]                 ; 16-byte Spill
	str	q0, [sp, #5200]                 ; 16-byte Spill
	str	q10, [sp, #8672]                ; 16-byte Spill
	str	q23, [sp, #8688]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #11216]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #11232]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q31, [sp, #8704]                ; 16-byte Reload
	bit.16b	v31, v1, v15
	bit.16b	v4, v0, v14
	ldr	x15, [sp, #4528]                ; 8-byte Reload
LBB0_1187:                              ; %direct.true4922
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v4, v0
	fadd.4s	v1, v31, v1
	bit.16b	v31, v1, v15
	bit.16b	v4, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1187
; %bb.1188:                             ; %direct.false4923
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5152]                 ; 16-byte Spill
	str	q0, [sp, #5168]                 ; 16-byte Spill
	str	q31, [sp, #8704]                ; 16-byte Spill
	str	q4, [sp, #8720]                 ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #11248]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #11264]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q4, [sp, #8736]                 ; 16-byte Reload
	bit.16b	v4, v1, v15
	bit.16b	v16, v0, v14
	ldr	x15, [sp, #4520]                ; 8-byte Reload
LBB0_1189:                              ; %direct.true4939
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v16, v0
	fadd.4s	v1, v4, v1
	bit.16b	v4, v1, v15
	bit.16b	v16, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1189
; %bb.1190:                             ; %direct.false4940
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5120]                 ; 16-byte Spill
	str	q0, [sp, #5136]                 ; 16-byte Spill
	str	q4, [sp, #8736]                 ; 16-byte Spill
	str	q16, [sp, #8752]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #11280]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #11296]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q16, [sp, #8768]                ; 16-byte Reload
	bit.16b	v16, v1, v15
	ldr	q4, [sp, #8784]                 ; 16-byte Reload
	bit.16b	v4, v0, v14
	ldr	x15, [sp, #4512]                ; 8-byte Reload
LBB0_1191:                              ; %direct.true4956
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v4, v0
	fadd.4s	v1, v16, v1
	bit.16b	v16, v1, v15
	bit.16b	v4, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1191
; %bb.1192:                             ; %direct.false4957
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5088]                 ; 16-byte Spill
	str	q0, [sp, #5104]                 ; 16-byte Spill
	str	q16, [sp, #8768]                ; 16-byte Spill
	str	q4, [sp, #8784]                 ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #11312]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #11328]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q29, [sp, #8800]                ; 16-byte Reload
	bit.16b	v29, v1, v15
	ldr	q16, [sp, #8816]                ; 16-byte Reload
	bit.16b	v16, v0, v14
	ldr	x15, [sp, #4504]                ; 8-byte Reload
	ldr	q4, [sp, #8912]                 ; 16-byte Reload
LBB0_1193:                              ; %direct.true4973
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v16, v0
	fadd.4s	v1, v29, v1
	bit.16b	v29, v1, v15
	bit.16b	v16, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1193
; %bb.1194:                             ; %direct.false4974
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5056]                 ; 16-byte Spill
	str	q0, [sp, #5072]                 ; 16-byte Spill
	str	q29, [sp, #8800]                ; 16-byte Spill
	str	q16, [sp, #8816]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #11344]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #11360]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q28, [sp, #8832]                ; 16-byte Reload
	bit.16b	v28, v1, v15
	ldr	q10, [sp, #8848]                ; 16-byte Reload
	bit.16b	v10, v0, v14
	ldr	x15, [sp, #4496]                ; 8-byte Reload
	ldr	q16, [sp, #9008]                ; 16-byte Reload
LBB0_1195:                              ; %direct.true4990
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v10, v0
	fadd.4s	v1, v28, v1
	bit.16b	v28, v1, v15
	bit.16b	v10, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1195
; %bb.1196:                             ; %direct.false4991
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #5024]                 ; 16-byte Spill
	str	q0, [sp, #5040]                 ; 16-byte Spill
	str	q28, [sp, #8832]                ; 16-byte Spill
	str	q10, [sp, #8848]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #11376]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #11392]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	ldr	q31, [sp, #8864]                ; 16-byte Reload
	bit.16b	v31, v1, v15
	bit.16b	v22, v0, v14
	ldr	x15, [sp, #4488]                ; 8-byte Reload
LBB0_1197:                              ; %direct.true5007
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v22, v0
	fadd.4s	v1, v31, v1
	bit.16b	v31, v1, v15
	bit.16b	v22, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1197
; %bb.1198:                             ; %direct.false5008
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q1, [sp, #4992]                 ; 16-byte Spill
	str	q0, [sp, #5008]                 ; 16-byte Spill
	str	q31, [sp, #8864]                ; 16-byte Spill
	str	q22, [sp, #8880]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q0, [sp, #11408]                ; 16-byte Reload
	fmul.4s	v0, v0, v19
	ldr	q1, [sp, #11424]                ; 16-byte Reload
	fmul.4s	v1, v1, v7
	bit.16b	v5, v1, v15
	bit.16b	v4, v0, v14
	ldr	x15, [sp, #4480]                ; 8-byte Reload
	ldr	q28, [sp, #8944]                ; 16-byte Reload
LBB0_1199:                              ; %direct.true5024
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q0, q1, [x16]
	ldp	q2, q3, [x15]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v0, v4, v0
	fadd.4s	v1, v5, v1
	bit.16b	v5, v1, v15
	bit.16b	v4, v0, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1199
; %bb.1200:                             ; %direct.false5025
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q5, [sp, #8896]                 ; 16-byte Spill
	str	q4, [sp, #8912]                 ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q2, [sp, #11440]                ; 16-byte Reload
	fmul.4s	v2, v2, v19
	ldr	q3, [sp, #11456]                ; 16-byte Reload
	fmul.4s	v3, v3, v7
	ldr	q4, [sp, #8928]                 ; 16-byte Reload
	bit.16b	v4, v3, v15
	bit.16b	v28, v2, v14
	ldr	x15, [sp, #4472]                ; 8-byte Reload
LBB0_1201:                              ; %direct.true5041
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q2, q3, [x16]
	ldp	q22, q5, [x15]
	fmul.4s	v3, v3, v5
	fmul.4s	v2, v2, v22
	fadd.4s	v22, v28, v2
	fadd.4s	v23, v4, v3
	bit.16b	v4, v23, v15
	bit.16b	v28, v22, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1201
; %bb.1202:                             ; %direct.false5042
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q4, [sp, #8928]                 ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q2, [sp, #11472]                ; 16-byte Reload
	fmul.4s	v2, v2, v19
	ldr	q3, [sp, #11488]                ; 16-byte Reload
	fmul.4s	v3, v3, v7
	bit.16b	v18, v3, v15
	bit.16b	v6, v2, v14
	ldr	x15, [sp, #4464]                ; 8-byte Reload
LBB0_1203:                              ; %direct.true5058
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q2, q3, [x16]
	ldp	q4, q5, [x15]
	fmul.4s	v3, v3, v5
	fmul.4s	v2, v2, v4
	fadd.4s	v4, v6, v2
	fadd.4s	v5, v18, v3
	bit.16b	v18, v5, v15
	bit.16b	v6, v4, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1203
; %bb.1204:                             ; %direct.false5059
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q28, [sp, #8944]                ; 16-byte Spill
	str	q18, [sp, #8960]                ; 16-byte Spill
	str	q6, [sp, #8976]                 ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q2, [sp, #11504]                ; 16-byte Reload
	fmul.4s	v2, v2, v19
	ldr	q3, [sp, #11520]                ; 16-byte Reload
	fmul.4s	v3, v3, v7
	bit.16b	v17, v3, v15
	bit.16b	v16, v2, v14
	ldr	x15, [sp, #4456]                ; 8-byte Reload
LBB0_1205:                              ; %direct.true5075
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q2, q3, [x16]
	ldp	q6, q7, [x15]
	fmul.4s	v3, v3, v7
	fmul.4s	v2, v2, v6
	fadd.4s	v6, v16, v2
	fadd.4s	v7, v17, v3
	bit.16b	v17, v7, v15
	bit.16b	v16, v6, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1205
; %bb.1206:                             ; %direct.false5076
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q17, [sp, #8992]                ; 16-byte Spill
	str	q16, [sp, #9008]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q2, [sp, #11536]                ; 16-byte Reload
	fmul.4s	v2, v2, v19
	ldr	q3, [sp, #11552]                ; 16-byte Reload
	ldr	q16, [sp, #11888]               ; 16-byte Reload
	fmul.4s	v3, v3, v16
	ldr	q16, [sp, #9024]                ; 16-byte Reload
	bit.16b	v16, v3, v15
	bit.16b	v27, v2, v14
	ldr	x15, [sp, #4448]                ; 8-byte Reload
LBB0_1207:                              ; %direct.true5092
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q2, q3, [x16]
	ldp	q18, q17, [x15]
	fmul.4s	v3, v3, v17
	fmul.4s	v2, v2, v18
	fadd.4s	v18, v27, v2
	fadd.4s	v19, v16, v3
	bit.16b	v16, v19, v15
	bit.16b	v27, v18, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1207
; %bb.1208:                             ; %direct.false5093
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q16, [sp, #9024]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q2, [sp, #11568]                ; 16-byte Reload
	ldr	q3, [sp, #11872]                ; 16-byte Reload
	fmul.4s	v2, v2, v3
	ldr	q3, [sp, #11584]                ; 16-byte Reload
	ldr	q16, [sp, #11888]               ; 16-byte Reload
	fmul.4s	v3, v3, v16
	bit.16b	v21, v3, v15
	bit.16b	v20, v2, v14
	ldr	x15, [sp, #4440]                ; 8-byte Reload
LBB0_1209:                              ; %direct.true5109
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q2, q3, [x16]
	ldp	q16, q17, [x15]
	fmul.4s	v17, v3, v17
	fmul.4s	v2, v2, v16
	fadd.4s	v3, v20, v2
	fadd.4s	v2, v21, v17
	bit.16b	v21, v2, v15
	bit.16b	v20, v3, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1209
; %bb.1210:                             ; %direct.false5110
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q21, [sp, #9056]                ; 16-byte Spill
	str	q20, [sp, #9072]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q16, [sp, #11600]               ; 16-byte Reload
	ldr	q17, [sp, #11872]               ; 16-byte Reload
	fmul.4s	v16, v16, v17
	ldr	q17, [sp, #11616]               ; 16-byte Reload
	ldr	q20, [sp, #11888]               ; 16-byte Reload
	fmul.4s	v17, v17, v20
	bit.16b	v26, v17, v15
	bit.16b	v24, v16, v14
	ldr	x15, [sp, #4432]                ; 8-byte Reload
LBB0_1211:                              ; %direct.true5126
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q16, q17, [x16]
	ldp	q20, q21, [x15]
	fmul.4s	v17, v17, v21
	fmul.4s	v16, v16, v20
	fadd.4s	v16, v24, v16
	fadd.4s	v17, v26, v17
	bit.16b	v26, v17, v15
	bit.16b	v24, v16, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1211
; %bb.1212:                             ; %direct.false5127
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q27, [sp, #9040]                ; 16-byte Spill
	str	q26, [sp, #9088]                ; 16-byte Spill
	str	q24, [sp, #9104]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q20, [sp, #11632]               ; 16-byte Reload
	ldr	q21, [sp, #11872]               ; 16-byte Reload
	fmul.4s	v20, v20, v21
	ldr	q21, [sp, #11648]               ; 16-byte Reload
	ldr	q24, [sp, #11888]               ; 16-byte Reload
	fmul.4s	v21, v21, v24
	bit.16b	v25, v21, v15
	ldr	q24, [sp, #9136]                ; 16-byte Reload
	bit.16b	v24, v20, v14
	ldr	x15, [sp, #4424]                ; 8-byte Reload
LBB0_1213:                              ; %direct.true5143
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q20, q21, [x16]
	ldp	q26, q27, [x15]
	fmul.4s	v21, v21, v27
	fmul.4s	v20, v20, v26
	fadd.4s	v26, v24, v20
	fadd.4s	v27, v25, v21
	bit.16b	v25, v27, v15
	bit.16b	v24, v26, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1213
; %bb.1214:                             ; %direct.false5144
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q25, [sp, #9120]                ; 16-byte Spill
	str	q24, [sp, #9136]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q20, [sp, #11664]               ; 16-byte Reload
	ldr	q21, [sp, #11872]               ; 16-byte Reload
	fmul.4s	v20, v20, v21
	ldr	q21, [sp, #11680]               ; 16-byte Reload
	ldr	q24, [sp, #11888]               ; 16-byte Reload
	fmul.4s	v21, v21, v24
	ldr	q25, [sp, #9152]                ; 16-byte Reload
	bit.16b	v25, v21, v15
	ldr	q28, [sp, #9168]                ; 16-byte Reload
	bit.16b	v28, v20, v14
	ldr	x15, [sp, #4416]                ; 8-byte Reload
LBB0_1215:                              ; %direct.true5160
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q20, q21, [x16]
	ldp	q12, q29, [x15]
	fmul.4s	v21, v21, v29
	fmul.4s	v20, v20, v12
	fadd.4s	v12, v28, v20
	fadd.4s	v13, v25, v21
	bit.16b	v25, v13, v15
	bit.16b	v28, v12, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1215
; %bb.1216:                             ; %direct.false5161
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q25, [sp, #9152]                ; 16-byte Spill
	str	q28, [sp, #9168]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q20, [sp, #11696]               ; 16-byte Reload
	ldr	q21, [sp, #11872]               ; 16-byte Reload
	fmul.4s	v20, v20, v21
	ldr	q21, [sp, #11712]               ; 16-byte Reload
	ldr	q24, [sp, #11888]               ; 16-byte Reload
	fmul.4s	v21, v21, v24
	ldr	q25, [sp, #9184]                ; 16-byte Reload
	bit.16b	v25, v21, v15
	ldr	q24, [sp, #9200]                ; 16-byte Reload
	bit.16b	v24, v20, v14
	ldr	x15, [sp, #4408]                ; 8-byte Reload
LBB0_1217:                              ; %direct.true5177
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q20, q21, [x16]
	ldp	q28, q29, [x15]
	fmul.4s	v21, v21, v29
	fmul.4s	v20, v20, v28
	fadd.4s	v28, v24, v20
	fadd.4s	v29, v25, v21
	bit.16b	v25, v29, v15
	bit.16b	v24, v28, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1217
; %bb.1218:                             ; %direct.false5178
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q25, [sp, #9184]                ; 16-byte Spill
	str	q24, [sp, #9200]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q20, [sp, #11728]               ; 16-byte Reload
	ldr	q21, [sp, #11872]               ; 16-byte Reload
	fmul.4s	v20, v20, v21
	ldr	q21, [sp, #11744]               ; 16-byte Reload
	ldr	q24, [sp, #11888]               ; 16-byte Reload
	fmul.4s	v21, v21, v24
	ldr	q25, [sp, #9216]                ; 16-byte Reload
	bit.16b	v25, v21, v15
	ldr	q24, [sp, #9232]                ; 16-byte Reload
	bit.16b	v24, v20, v14
	ldr	x15, [sp, #4400]                ; 8-byte Reload
LBB0_1219:                              ; %direct.true5194
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q20, q21, [x16]
	ldp	q8, q9, [x15]
	fmul.4s	v21, v21, v9
	fmul.4s	v20, v20, v8
	fadd.4s	v20, v24, v20
	fadd.4s	v21, v25, v21
	bit.16b	v25, v21, v15
	bit.16b	v24, v20, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1219
; %bb.1220:                             ; %direct.false5195
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q25, [sp, #9216]                ; 16-byte Spill
	str	q24, [sp, #9232]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q24, [sp, #11760]               ; 16-byte Reload
	ldr	q25, [sp, #11872]               ; 16-byte Reload
	fmul.4s	v8, v24, v25
	ldr	q24, [sp, #11776]               ; 16-byte Reload
	ldr	q25, [sp, #11888]               ; 16-byte Reload
	fmul.4s	v9, v24, v25
	ldr	q24, [sp, #9248]                ; 16-byte Reload
	bit.16b	v24, v9, v15
	ldr	q25, [sp, #9264]                ; 16-byte Reload
	bit.16b	v25, v8, v14
	ldr	x15, [sp, #4392]                ; 8-byte Reload
LBB0_1221:                              ; %direct.true5211
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q8, q9, [x16]
	ldp	q10, q11, [x15]
	fmul.4s	v9, v9, v11
	fmul.4s	v8, v8, v10
	fadd.4s	v10, v25, v8
	fadd.4s	v11, v24, v9
	bit.16b	v24, v11, v15
	bit.16b	v25, v10, v14
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1221
; %bb.1222:                             ; %direct.false5212
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q24, [sp, #9248]                ; 16-byte Spill
	str	q25, [sp, #9264]                ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	ldr	q24, [sp, #11792]               ; 16-byte Reload
	ldr	q25, [sp, #11872]               ; 16-byte Reload
	fmul.4s	v8, v24, v25
	ldr	q24, [sp, #11808]               ; 16-byte Reload
	ldr	q25, [sp, #11888]               ; 16-byte Reload
	fmul.4s	v9, v24, v25
	ldr	q30, [sp, #9280]                ; 16-byte Reload
	bit.16b	v30, v9, v15
	ldr	q25, [sp, #9296]                ; 16-byte Reload
	bit.16b	v25, v8, v14
	ldr	x15, [sp, #4384]                ; 8-byte Reload
LBB0_1223:                              ; %direct.true5228
                                        ;   Parent Loop BB0_1026 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x10, x12
	ldp	q8, q9, [x16]
	mov.16b	v24, v14
	ldp	q14, q15, [x15]
	fmul.4s	v9, v9, v15
	ldr	q15, [sp, #11904]               ; 16-byte Reload
	fmul.4s	v8, v8, v14
	mov.16b	v14, v24
	fadd.4s	v8, v25, v8
	fadd.4s	v9, v30, v9
	bit.16b	v30, v9, v15
	bit.16b	v25, v8, v24
	add	x12, x12, #32
	add	x15, x15, #2048
	cmp	x12, #512
	b.ne	LBB0_1223
; %bb.1224:                             ; %direct.false5229
                                        ;   in Loop: Header=BB0_1026 Depth=1
	str	q30, [sp, #9280]                ; 16-byte Spill
	str	q25, [sp, #9296]                ; 16-byte Spill
	ldr	q24, [sp, #11856]               ; 16-byte Reload
	ldr	q25, [sp, #7136]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #11856]               ; 16-byte Spill
	ldr	q24, [sp, #11840]               ; 16-byte Reload
	ldr	q25, [sp, #7152]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #11840]               ; 16-byte Spill
	ldr	q24, [sp, #9792]                ; 16-byte Reload
	ldr	q25, [sp, #6592]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #9792]                ; 16-byte Spill
	ldr	q24, [sp, #9776]                ; 16-byte Reload
	ldr	q25, [sp, #6608]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #9776]                ; 16-byte Spill
	ldr	q24, [sp, #9824]                ; 16-byte Reload
	ldr	q25, [sp, #6560]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #9824]                ; 16-byte Spill
	ldr	q24, [sp, #9808]                ; 16-byte Reload
	ldr	q25, [sp, #6576]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #9808]                ; 16-byte Spill
	ldr	q24, [sp, #9856]                ; 16-byte Reload
	ldr	q25, [sp, #6528]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #9856]                ; 16-byte Spill
	ldr	q24, [sp, #9840]                ; 16-byte Reload
	ldr	q25, [sp, #6544]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #9840]                ; 16-byte Spill
	ldr	q24, [sp, #9888]                ; 16-byte Reload
	ldr	q25, [sp, #6496]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #9888]                ; 16-byte Spill
	ldr	q24, [sp, #9872]                ; 16-byte Reload
	ldr	q25, [sp, #6512]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #9872]                ; 16-byte Spill
	ldr	q24, [sp, #9920]                ; 16-byte Reload
	ldr	q25, [sp, #6464]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #9920]                ; 16-byte Spill
	ldr	q24, [sp, #9904]                ; 16-byte Reload
	ldr	q25, [sp, #6480]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #9904]                ; 16-byte Spill
	ldr	q24, [sp, #9952]                ; 16-byte Reload
	ldr	q25, [sp, #6432]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #9952]                ; 16-byte Spill
	ldr	q24, [sp, #9936]                ; 16-byte Reload
	ldr	q25, [sp, #6448]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #9936]                ; 16-byte Spill
	ldr	q24, [sp, #9984]                ; 16-byte Reload
	ldr	q25, [sp, #6400]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #9984]                ; 16-byte Spill
	ldr	q24, [sp, #9968]                ; 16-byte Reload
	ldr	q25, [sp, #6416]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #9968]                ; 16-byte Spill
	ldr	q24, [sp, #10016]               ; 16-byte Reload
	ldr	q25, [sp, #6368]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10016]               ; 16-byte Spill
	ldr	q24, [sp, #10000]               ; 16-byte Reload
	ldr	q25, [sp, #6384]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10000]               ; 16-byte Spill
	ldr	q24, [sp, #10048]               ; 16-byte Reload
	ldr	q25, [sp, #6336]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10048]               ; 16-byte Spill
	ldr	q24, [sp, #10032]               ; 16-byte Reload
	ldr	q25, [sp, #6352]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10032]               ; 16-byte Spill
	ldr	q24, [sp, #10080]               ; 16-byte Reload
	ldr	q25, [sp, #6304]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10080]               ; 16-byte Spill
	ldr	q24, [sp, #10064]               ; 16-byte Reload
	ldr	q25, [sp, #6320]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10064]               ; 16-byte Spill
	ldr	q24, [sp, #10112]               ; 16-byte Reload
	ldr	q25, [sp, #6272]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10112]               ; 16-byte Spill
	ldr	q24, [sp, #10096]               ; 16-byte Reload
	ldr	q25, [sp, #6288]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10096]               ; 16-byte Spill
	ldr	q24, [sp, #10144]               ; 16-byte Reload
	ldr	q25, [sp, #6240]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10144]               ; 16-byte Spill
	ldr	q24, [sp, #10128]               ; 16-byte Reload
	ldr	q25, [sp, #6256]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10128]               ; 16-byte Spill
	ldr	q24, [sp, #10176]               ; 16-byte Reload
	ldr	q25, [sp, #6208]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10176]               ; 16-byte Spill
	ldr	q24, [sp, #10160]               ; 16-byte Reload
	ldr	q25, [sp, #6224]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10160]               ; 16-byte Spill
	ldr	q24, [sp, #10208]               ; 16-byte Reload
	ldr	q25, [sp, #6176]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10208]               ; 16-byte Spill
	ldr	q24, [sp, #10192]               ; 16-byte Reload
	ldr	q25, [sp, #6192]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10192]               ; 16-byte Spill
	ldr	q24, [sp, #10240]               ; 16-byte Reload
	ldr	q25, [sp, #6144]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10240]               ; 16-byte Spill
	ldr	q24, [sp, #10224]               ; 16-byte Reload
	ldr	q25, [sp, #6160]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10224]               ; 16-byte Spill
	ldr	q24, [sp, #10272]               ; 16-byte Reload
	ldr	q25, [sp, #6112]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10272]               ; 16-byte Spill
	ldr	q24, [sp, #10256]               ; 16-byte Reload
	ldr	q25, [sp, #6128]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10256]               ; 16-byte Spill
	ldr	q24, [sp, #10304]               ; 16-byte Reload
	ldr	q25, [sp, #6080]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10304]               ; 16-byte Spill
	ldr	q24, [sp, #10288]               ; 16-byte Reload
	ldr	q25, [sp, #6096]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10288]               ; 16-byte Spill
	ldr	q24, [sp, #10336]               ; 16-byte Reload
	ldr	q25, [sp, #6048]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10336]               ; 16-byte Spill
	ldr	q24, [sp, #10320]               ; 16-byte Reload
	ldr	q25, [sp, #6064]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10320]               ; 16-byte Spill
	ldr	q24, [sp, #10368]               ; 16-byte Reload
	ldr	q25, [sp, #6016]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10368]               ; 16-byte Spill
	ldr	q24, [sp, #10352]               ; 16-byte Reload
	ldr	q25, [sp, #6032]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10352]               ; 16-byte Spill
	ldr	q24, [sp, #10400]               ; 16-byte Reload
	ldr	q25, [sp, #5984]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10400]               ; 16-byte Spill
	ldr	q24, [sp, #10384]               ; 16-byte Reload
	ldr	q25, [sp, #6000]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10384]               ; 16-byte Spill
	ldr	q24, [sp, #10432]               ; 16-byte Reload
	ldr	q25, [sp, #5952]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10432]               ; 16-byte Spill
	ldr	q24, [sp, #10416]               ; 16-byte Reload
	ldr	q25, [sp, #5968]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10416]               ; 16-byte Spill
	ldr	q24, [sp, #10464]               ; 16-byte Reload
	ldr	q25, [sp, #5920]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10464]               ; 16-byte Spill
	ldr	q24, [sp, #10448]               ; 16-byte Reload
	ldr	q25, [sp, #5936]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10448]               ; 16-byte Spill
	ldr	q24, [sp, #10496]               ; 16-byte Reload
	ldr	q25, [sp, #5888]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10496]               ; 16-byte Spill
	ldr	q24, [sp, #10480]               ; 16-byte Reload
	ldr	q25, [sp, #5904]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10480]               ; 16-byte Spill
	ldr	q24, [sp, #10528]               ; 16-byte Reload
	ldr	q25, [sp, #5856]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10528]               ; 16-byte Spill
	ldr	q24, [sp, #10512]               ; 16-byte Reload
	ldr	q25, [sp, #5872]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10512]               ; 16-byte Spill
	ldr	q24, [sp, #10560]               ; 16-byte Reload
	ldr	q25, [sp, #5824]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10560]               ; 16-byte Spill
	ldr	q24, [sp, #10544]               ; 16-byte Reload
	ldr	q25, [sp, #5840]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10544]               ; 16-byte Spill
	ldr	q24, [sp, #10592]               ; 16-byte Reload
	ldr	q25, [sp, #5792]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10592]               ; 16-byte Spill
	ldr	q24, [sp, #10576]               ; 16-byte Reload
	ldr	q25, [sp, #5808]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10576]               ; 16-byte Spill
	ldr	q24, [sp, #10624]               ; 16-byte Reload
	ldr	q25, [sp, #5760]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10624]               ; 16-byte Spill
	ldr	q24, [sp, #10608]               ; 16-byte Reload
	ldr	q25, [sp, #5776]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10608]               ; 16-byte Spill
	ldr	q24, [sp, #10656]               ; 16-byte Reload
	ldr	q25, [sp, #5728]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10656]               ; 16-byte Spill
	ldr	q24, [sp, #10640]               ; 16-byte Reload
	ldr	q25, [sp, #5744]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10640]               ; 16-byte Spill
	ldr	q24, [sp, #10688]               ; 16-byte Reload
	ldr	q25, [sp, #5696]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10688]               ; 16-byte Spill
	ldr	q24, [sp, #10672]               ; 16-byte Reload
	ldr	q25, [sp, #5712]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10672]               ; 16-byte Spill
	ldr	q24, [sp, #10720]               ; 16-byte Reload
	ldr	q25, [sp, #5664]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10720]               ; 16-byte Spill
	ldr	q24, [sp, #10704]               ; 16-byte Reload
	ldr	q25, [sp, #5680]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10704]               ; 16-byte Spill
	ldr	q24, [sp, #10752]               ; 16-byte Reload
	ldr	q25, [sp, #5632]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10752]               ; 16-byte Spill
	ldr	q24, [sp, #10736]               ; 16-byte Reload
	ldr	q25, [sp, #5648]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10736]               ; 16-byte Spill
	ldr	q24, [sp, #10784]               ; 16-byte Reload
	ldr	q25, [sp, #5600]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10784]               ; 16-byte Spill
	ldr	q24, [sp, #10768]               ; 16-byte Reload
	ldr	q25, [sp, #5616]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10768]               ; 16-byte Spill
	ldr	q24, [sp, #10816]               ; 16-byte Reload
	ldr	q25, [sp, #5568]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10816]               ; 16-byte Spill
	ldr	q24, [sp, #10800]               ; 16-byte Reload
	ldr	q25, [sp, #5584]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10800]               ; 16-byte Spill
	ldr	q24, [sp, #10848]               ; 16-byte Reload
	ldr	q25, [sp, #5536]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10848]               ; 16-byte Spill
	ldr	q24, [sp, #10832]               ; 16-byte Reload
	ldr	q25, [sp, #5552]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10832]               ; 16-byte Spill
	ldr	q24, [sp, #10880]               ; 16-byte Reload
	ldr	q25, [sp, #5504]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10880]               ; 16-byte Spill
	ldr	q24, [sp, #10864]               ; 16-byte Reload
	ldr	q25, [sp, #5520]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10864]               ; 16-byte Spill
	ldr	q24, [sp, #10912]               ; 16-byte Reload
	ldr	q25, [sp, #5472]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10912]               ; 16-byte Spill
	ldr	q24, [sp, #10896]               ; 16-byte Reload
	ldr	q25, [sp, #5488]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10896]               ; 16-byte Spill
	ldr	q24, [sp, #10944]               ; 16-byte Reload
	ldr	q25, [sp, #5440]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10944]               ; 16-byte Spill
	ldr	q24, [sp, #10928]               ; 16-byte Reload
	ldr	q25, [sp, #5456]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10928]               ; 16-byte Spill
	ldr	q24, [sp, #10976]               ; 16-byte Reload
	ldr	q25, [sp, #5408]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #10976]               ; 16-byte Spill
	ldr	q24, [sp, #10960]               ; 16-byte Reload
	ldr	q25, [sp, #5424]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10960]               ; 16-byte Spill
	ldr	q24, [sp, #11008]               ; 16-byte Reload
	ldr	q25, [sp, #5376]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #11008]               ; 16-byte Spill
	ldr	q24, [sp, #10992]               ; 16-byte Reload
	ldr	q25, [sp, #5392]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #10992]               ; 16-byte Spill
	ldr	q24, [sp, #11040]               ; 16-byte Reload
	ldr	q25, [sp, #5344]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #11040]               ; 16-byte Spill
	ldr	q24, [sp, #11024]               ; 16-byte Reload
	ldr	q25, [sp, #5360]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #11024]               ; 16-byte Spill
	ldr	q24, [sp, #11072]               ; 16-byte Reload
	ldr	q25, [sp, #5312]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #11072]               ; 16-byte Spill
	ldr	q24, [sp, #11056]               ; 16-byte Reload
	ldr	q25, [sp, #5328]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #11056]               ; 16-byte Spill
	ldr	q24, [sp, #11104]               ; 16-byte Reload
	ldr	q25, [sp, #5280]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #11104]               ; 16-byte Spill
	ldr	q24, [sp, #11088]               ; 16-byte Reload
	ldr	q25, [sp, #5296]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #11088]               ; 16-byte Spill
	ldr	q24, [sp, #11136]               ; 16-byte Reload
	ldr	q25, [sp, #5248]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #11136]               ; 16-byte Spill
	ldr	q24, [sp, #11120]               ; 16-byte Reload
	ldr	q25, [sp, #5264]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #11120]               ; 16-byte Spill
	ldr	q24, [sp, #11168]               ; 16-byte Reload
	ldr	q25, [sp, #5216]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #11168]               ; 16-byte Spill
	ldr	q24, [sp, #11152]               ; 16-byte Reload
	ldr	q25, [sp, #5232]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #11152]               ; 16-byte Spill
	ldr	q24, [sp, #11200]               ; 16-byte Reload
	ldr	q25, [sp, #5184]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #11200]               ; 16-byte Spill
	ldr	q24, [sp, #11184]               ; 16-byte Reload
	ldr	q25, [sp, #5200]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #11184]               ; 16-byte Spill
	ldr	q24, [sp, #11232]               ; 16-byte Reload
	ldr	q25, [sp, #5152]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #11232]               ; 16-byte Spill
	ldr	q24, [sp, #11216]               ; 16-byte Reload
	ldr	q25, [sp, #5168]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #11216]               ; 16-byte Spill
	ldr	q24, [sp, #11264]               ; 16-byte Reload
	ldr	q25, [sp, #5120]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #11264]               ; 16-byte Spill
	ldr	q24, [sp, #11248]               ; 16-byte Reload
	ldr	q25, [sp, #5136]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #11248]               ; 16-byte Spill
	ldr	q24, [sp, #11296]               ; 16-byte Reload
	ldr	q25, [sp, #5088]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #11296]               ; 16-byte Spill
	ldr	q24, [sp, #11280]               ; 16-byte Reload
	ldr	q25, [sp, #5104]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #11280]               ; 16-byte Spill
	ldr	q24, [sp, #11328]               ; 16-byte Reload
	ldr	q25, [sp, #5056]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #11328]               ; 16-byte Spill
	ldr	q24, [sp, #11312]               ; 16-byte Reload
	ldr	q25, [sp, #5072]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #11312]               ; 16-byte Spill
	ldr	q24, [sp, #11360]               ; 16-byte Reload
	ldr	q25, [sp, #5024]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #11360]               ; 16-byte Spill
	ldr	q24, [sp, #11344]               ; 16-byte Reload
	ldr	q25, [sp, #5040]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #11344]               ; 16-byte Spill
	ldr	q24, [sp, #11392]               ; 16-byte Reload
	ldr	q25, [sp, #4992]                ; 16-byte Reload
	bit.16b	v24, v25, v15
	str	q24, [sp, #11392]               ; 16-byte Spill
	ldr	q24, [sp, #11376]               ; 16-byte Reload
	ldr	q25, [sp, #5008]                ; 16-byte Reload
	bit.16b	v24, v25, v14
	str	q24, [sp, #11376]               ; 16-byte Spill
	ldr	q24, [sp, #11424]               ; 16-byte Reload
	bit.16b	v24, v1, v15
	str	q24, [sp, #11424]               ; 16-byte Spill
	ldr	q1, [sp, #11408]                ; 16-byte Reload
	bit.16b	v1, v0, v14
	str	q1, [sp, #11408]                ; 16-byte Spill
	ldr	q0, [sp, #11456]                ; 16-byte Reload
	bit.16b	v0, v23, v15
	str	q0, [sp, #11456]                ; 16-byte Spill
	ldr	q0, [sp, #11440]                ; 16-byte Reload
	bit.16b	v0, v22, v14
	str	q0, [sp, #11440]                ; 16-byte Spill
	ldr	q0, [sp, #11488]                ; 16-byte Reload
	bit.16b	v0, v5, v15
	str	q0, [sp, #11488]                ; 16-byte Spill
	ldr	q0, [sp, #11472]                ; 16-byte Reload
	bit.16b	v0, v4, v14
	str	q0, [sp, #11472]                ; 16-byte Spill
	ldr	q0, [sp, #11520]                ; 16-byte Reload
	bit.16b	v0, v7, v15
	str	q0, [sp, #11520]                ; 16-byte Spill
	ldr	q0, [sp, #11504]                ; 16-byte Reload
	bit.16b	v0, v6, v14
	str	q0, [sp, #11504]                ; 16-byte Spill
	ldr	q0, [sp, #11552]                ; 16-byte Reload
	bit.16b	v0, v19, v15
	str	q0, [sp, #11552]                ; 16-byte Spill
	ldr	q0, [sp, #11536]                ; 16-byte Reload
	bit.16b	v0, v18, v14
	str	q0, [sp, #11536]                ; 16-byte Spill
	ldr	q0, [sp, #11584]                ; 16-byte Reload
	bit.16b	v0, v2, v15
	str	q0, [sp, #11584]                ; 16-byte Spill
	ldr	q0, [sp, #11568]                ; 16-byte Reload
	bit.16b	v0, v3, v14
	str	q0, [sp, #11568]                ; 16-byte Spill
	ldr	q0, [sp, #11616]                ; 16-byte Reload
	bit.16b	v0, v17, v15
	str	q0, [sp, #11616]                ; 16-byte Spill
	ldr	q0, [sp, #11600]                ; 16-byte Reload
	bit.16b	v0, v16, v14
	str	q0, [sp, #11600]                ; 16-byte Spill
	ldr	q0, [sp, #11648]                ; 16-byte Reload
	bit.16b	v0, v27, v15
	str	q0, [sp, #11648]                ; 16-byte Spill
	ldr	q0, [sp, #11632]                ; 16-byte Reload
	bit.16b	v0, v26, v14
	str	q0, [sp, #11632]                ; 16-byte Spill
	ldr	q0, [sp, #11680]                ; 16-byte Reload
	bit.16b	v0, v13, v15
	str	q0, [sp, #11680]                ; 16-byte Spill
	ldr	q0, [sp, #11664]                ; 16-byte Reload
	bit.16b	v0, v12, v14
	str	q0, [sp, #11664]                ; 16-byte Spill
	ldr	q0, [sp, #11712]                ; 16-byte Reload
	bit.16b	v0, v29, v15
	str	q0, [sp, #11712]                ; 16-byte Spill
	ldr	q0, [sp, #11696]                ; 16-byte Reload
	bit.16b	v0, v28, v14
	str	q0, [sp, #11696]                ; 16-byte Spill
	ldr	q0, [sp, #11744]                ; 16-byte Reload
	bit.16b	v0, v21, v15
	str	q0, [sp, #11744]                ; 16-byte Spill
	ldr	q0, [sp, #11728]                ; 16-byte Reload
	bit.16b	v0, v20, v14
	str	q0, [sp, #11728]                ; 16-byte Spill
	ldr	q0, [sp, #11776]                ; 16-byte Reload
	bit.16b	v0, v11, v15
	str	q0, [sp, #11776]                ; 16-byte Spill
	ldr	q0, [sp, #11760]                ; 16-byte Reload
	bit.16b	v0, v10, v14
	str	q0, [sp, #11760]                ; 16-byte Spill
	ldr	q0, [sp, #11808]                ; 16-byte Reload
	bit.16b	v0, v9, v15
	str	q0, [sp, #11808]                ; 16-byte Spill
	ldr	q0, [sp, #11792]                ; 16-byte Reload
	bit.16b	v0, v8, v14
	str	q0, [sp, #11792]                ; 16-byte Spill
	movi.2d	v1, #0000000000000000
	ldr	q0, [sp, #7120]                 ; 16-byte Reload
	fadd.4s	v0, v0, v1
	ldr	q2, [sp, #7088]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #7104]                 ; 16-byte Reload
	fadd.4s	v1, v2, v1
	ldr	q2, [sp, #7072]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #7040]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #7056]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #7024]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #7008]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #6976]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #6992]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6960]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6944]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #6912]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #6928]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6896]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6880]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #6832]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #6864]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6816]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6848]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #6800]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #6784]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6752]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6768]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #6736]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #6720]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6704]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6688]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #6672]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #6656]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6624]                 ; 16-byte Reload
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #6640]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q21, [sp, #7168]                ; 16-byte Reload
	ldr	q2, [sp, #11872]                ; 16-byte Reload
	fmul.4s	v2, v21, v2
	ldr	q22, [sp, #7184]                ; 16-byte Reload
	ldr	q3, [sp, #11888]                ; 16-byte Reload
	fmul.4s	v3, v22, v3
	fadd.4s	v1, v3, v1
	fadd.4s	v0, v2, v0
	bit.16b	v21, v0, v14
	bit.16b	v22, v1, v15
	add	x11, x11, #1
	cmp	x11, #128
	ldr	q19, [sp, #4960]                ; 16-byte Reload
	ldr	q29, [sp, #4944]                ; 16-byte Reload
	ldr	q28, [sp, #4928]                ; 16-byte Reload
	ldr	q16, [sp, #4912]                ; 16-byte Reload
	ldr	q9, [sp, #4896]                 ; 16-byte Reload
	ldr	q24, [sp, #11824]               ; 16-byte Reload
	b.ne	LBB0_1026
; %bb.1225:                             ; %direct.false
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q0, [sp, #9776]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	ldr	q2, [sp, #2208]                 ; 16-byte Reload
	and.16b	v1, v1, v2
	ldr	x10, [sp, #8]                   ; 8-byte Reload
	dup.2d	v2, x10
	add.2d	v1, v2, v1
	ldr	q3, [sp, #2192]                 ; 16-byte Reload
	ldr	q5, [sp, #2160]                 ; 16-byte Reload
	ldr	q6, [sp, #2128]                 ; 16-byte Reload
	tbnz	w9, #0, LBB0_1802
; %bb.1226:                             ; %else4182
	ldr	q7, [sp, #16]                   ; 16-byte Reload
	and.16b	v4, v7, v3
	ldr	q16, [sp, #1488]                ; 16-byte Reload
	ldr	q17, [sp, #1392]                ; 16-byte Reload
	ldr	q18, [sp, #1344]                ; 16-byte Reload
	tbnz	w8, #1, LBB0_1803
LBB0_1227:                              ; %else4185
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1804
LBB0_1228:                              ; %else4188
	ldr	q4, [sp, #2176]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_1805
LBB0_1229:                              ; %else4191
	ldr	q0, [sp, #9792]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1806
LBB0_1230:                              ; %else4194
	ldr	q3, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v3, v5
	tbnz	w8, #5, LBB0_1807
LBB0_1231:                              ; %else4197
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1808
LBB0_1232:                              ; %else4200
	tbz	w8, #7, LBB0_1234
LBB0_1233:                              ; %cond.store4201
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1234:                              ; %else4203
	ldr	q0, [sp, #9808]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #2144]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1809
; %bb.1235:                             ; %else4208
	and.16b	v4, v7, v6
	tbnz	w8, #1, LBB0_1810
LBB0_1236:                              ; %else4212
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	ldr	q5, [sp, #1568]                 ; 16-byte Reload
	ldr	q6, [sp, #1440]                 ; 16-byte Reload
	tbnz	w8, #2, LBB0_1811
LBB0_1237:                              ; %else4216
	ldr	q4, [sp, #4112]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_1812
LBB0_1238:                              ; %else4220
	ldr	q0, [sp, #9824]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1813
LBB0_1239:                              ; %else4224
	ldr	q3, [sp, #2112]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1814
LBB0_1240:                              ; %else4228
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1815
LBB0_1241:                              ; %else4232
	tbz	w8, #7, LBB0_1243
LBB0_1242:                              ; %cond.store4233
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1243:                              ; %else4236
	ldr	q0, [sp, #9840]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #2096]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1816
; %bb.1244:                             ; %else4241
	ldr	q3, [sp, #4096]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_1817
LBB0_1245:                              ; %else4245
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1818
LBB0_1246:                              ; %else4249
	ldr	q4, [sp, #4080]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_1819
LBB0_1247:                              ; %else4253
	ldr	q0, [sp, #9856]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1820
LBB0_1248:                              ; %else4257
	ldr	q3, [sp, #2080]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1821
LBB0_1249:                              ; %else4261
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1822
LBB0_1250:                              ; %else4265
	tbz	w8, #7, LBB0_1252
LBB0_1251:                              ; %cond.store4266
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1252:                              ; %else4269
	ldr	q0, [sp, #9872]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #2064]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1823
; %bb.1253:                             ; %else4274
	ldr	q3, [sp, #4064]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_1824
LBB0_1254:                              ; %else4278
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1825
LBB0_1255:                              ; %else4282
	ldr	q4, [sp, #4048]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_1826
LBB0_1256:                              ; %else4286
	ldr	q0, [sp, #9888]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1827
LBB0_1257:                              ; %else4290
	ldr	q3, [sp, #2048]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1828
LBB0_1258:                              ; %else4294
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1829
LBB0_1259:                              ; %else4298
	tbz	w8, #7, LBB0_1261
LBB0_1260:                              ; %cond.store4299
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1261:                              ; %else4302
	ldr	q0, [sp, #9904]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #2032]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1830
; %bb.1262:                             ; %else4307
	ldr	q3, [sp, #4032]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_1831
LBB0_1263:                              ; %else4311
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1832
LBB0_1264:                              ; %else4315
	ldr	q4, [sp, #4016]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_1833
LBB0_1265:                              ; %else4319
	ldr	q0, [sp, #9920]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1834
LBB0_1266:                              ; %else4323
	ldr	q3, [sp, #2016]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1835
LBB0_1267:                              ; %else4327
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1836
LBB0_1268:                              ; %else4331
	tbz	w8, #7, LBB0_1270
LBB0_1269:                              ; %cond.store4332
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1270:                              ; %else4335
	ldr	q0, [sp, #9936]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #2000]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1837
; %bb.1271:                             ; %else4340
	ldr	q3, [sp, #4000]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_1838
LBB0_1272:                              ; %else4344
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1839
LBB0_1273:                              ; %else4348
	ldr	q4, [sp, #3984]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_1840
LBB0_1274:                              ; %else4352
	ldr	q0, [sp, #9952]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1841
LBB0_1275:                              ; %else4356
	ldr	q3, [sp, #1984]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1842
LBB0_1276:                              ; %else4360
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1843
LBB0_1277:                              ; %else4364
	tbz	w8, #7, LBB0_1279
LBB0_1278:                              ; %cond.store4365
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1279:                              ; %else4368
	ldr	q0, [sp, #9968]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #1968]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1844
; %bb.1280:                             ; %else4373
	ldr	q3, [sp, #3968]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_1845
LBB0_1281:                              ; %else4377
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1846
LBB0_1282:                              ; %else4381
	ldr	q4, [sp, #3952]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_1847
LBB0_1283:                              ; %else4385
	ldr	q0, [sp, #9984]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1848
LBB0_1284:                              ; %else4389
	ldr	q3, [sp, #1952]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1849
LBB0_1285:                              ; %else4393
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1850
LBB0_1286:                              ; %else4397
	tbz	w8, #7, LBB0_1288
LBB0_1287:                              ; %cond.store4398
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1288:                              ; %else4401
	ldr	q0, [sp, #10000]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #1936]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1851
; %bb.1289:                             ; %else4406
	ldr	q3, [sp, #3936]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_1852
LBB0_1290:                              ; %else4410
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1853
LBB0_1291:                              ; %else4414
	ldr	q4, [sp, #3920]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_1854
LBB0_1292:                              ; %else4418
	ldr	q0, [sp, #10016]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1855
LBB0_1293:                              ; %else4422
	ldr	q3, [sp, #1920]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1856
LBB0_1294:                              ; %else4426
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1857
LBB0_1295:                              ; %else4430
	tbz	w8, #7, LBB0_1297
LBB0_1296:                              ; %cond.store4431
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1297:                              ; %else4434
	ldr	q0, [sp, #10032]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #1904]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1858
; %bb.1298:                             ; %else4439
	ldr	q3, [sp, #3904]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_1859
LBB0_1299:                              ; %else4443
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1860
LBB0_1300:                              ; %else4447
	ldr	q4, [sp, #3888]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_1861
LBB0_1301:                              ; %else4451
	ldr	q0, [sp, #10048]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1862
LBB0_1302:                              ; %else4455
	ldr	q3, [sp, #1888]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1863
LBB0_1303:                              ; %else4459
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1864
LBB0_1304:                              ; %else4463
	tbz	w8, #7, LBB0_1306
LBB0_1305:                              ; %cond.store4464
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1306:                              ; %else4467
	ldr	q0, [sp, #10064]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #1872]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1865
; %bb.1307:                             ; %else4472
	ldr	q3, [sp, #3872]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_1866
LBB0_1308:                              ; %else4476
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1867
LBB0_1309:                              ; %else4480
	ldr	q4, [sp, #3856]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_1868
LBB0_1310:                              ; %else4484
	ldr	q0, [sp, #10080]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1869
LBB0_1311:                              ; %else4488
	ldr	q3, [sp, #1856]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1870
LBB0_1312:                              ; %else4492
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1871
LBB0_1313:                              ; %else4496
	tbz	w8, #7, LBB0_1315
LBB0_1314:                              ; %cond.store4497
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1315:                              ; %else4500
	ldr	q0, [sp, #10096]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #1840]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1872
; %bb.1316:                             ; %else4505
	ldr	q3, [sp, #3840]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_1873
LBB0_1317:                              ; %else4509
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1874
LBB0_1318:                              ; %else4513
	ldr	q4, [sp, #3824]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_1875
LBB0_1319:                              ; %else4517
	ldr	q0, [sp, #10112]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1876
LBB0_1320:                              ; %else4521
	ldr	q3, [sp, #1824]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1877
LBB0_1321:                              ; %else4525
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1878
LBB0_1322:                              ; %else4529
	tbz	w8, #7, LBB0_1324
LBB0_1323:                              ; %cond.store4530
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1324:                              ; %else4533
	ldr	q0, [sp, #10128]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #1808]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1879
; %bb.1325:                             ; %else4538
	ldr	q3, [sp, #3808]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_1880
LBB0_1326:                              ; %else4542
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1881
LBB0_1327:                              ; %else4546
	ldr	q4, [sp, #3792]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_1882
LBB0_1328:                              ; %else4550
	ldr	q0, [sp, #10144]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1883
LBB0_1329:                              ; %else4554
	ldr	q3, [sp, #1792]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1884
LBB0_1330:                              ; %else4558
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1885
LBB0_1331:                              ; %else4562
	tbz	w8, #7, LBB0_1333
LBB0_1332:                              ; %cond.store4563
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1333:                              ; %else4566
	ldr	q0, [sp, #10160]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #1776]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1886
; %bb.1334:                             ; %else4571
	ldr	q3, [sp, #3776]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_1887
LBB0_1335:                              ; %else4575
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1888
LBB0_1336:                              ; %else4579
	ldr	q4, [sp, #3760]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_1889
LBB0_1337:                              ; %else4583
	ldr	q0, [sp, #10176]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1890
LBB0_1338:                              ; %else4587
	ldr	q3, [sp, #1760]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1891
LBB0_1339:                              ; %else4591
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1892
LBB0_1340:                              ; %else4595
	tbz	w8, #7, LBB0_1342
LBB0_1341:                              ; %cond.store4596
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1342:                              ; %else4599
	ldr	q0, [sp, #10192]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #1744]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1893
; %bb.1343:                             ; %else4604
	ldr	q3, [sp, #3744]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_1894
LBB0_1344:                              ; %else4608
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1895
LBB0_1345:                              ; %else4612
	ldr	q4, [sp, #3728]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_1896
LBB0_1346:                              ; %else4616
	ldr	q0, [sp, #10208]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1897
LBB0_1347:                              ; %else4620
	ldr	q3, [sp, #1728]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1898
LBB0_1348:                              ; %else4624
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1899
LBB0_1349:                              ; %else4628
	tbz	w8, #7, LBB0_1351
LBB0_1350:                              ; %cond.store4629
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1351:                              ; %else4632
	ldr	q0, [sp, #10224]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #1712]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1900
; %bb.1352:                             ; %else4637
	ldr	q3, [sp, #3712]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_1901
LBB0_1353:                              ; %else4641
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1902
LBB0_1354:                              ; %else4645
	ldr	q4, [sp, #3696]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_1903
LBB0_1355:                              ; %else4649
	ldr	q0, [sp, #10240]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1904
LBB0_1356:                              ; %else4653
	ldr	q3, [sp, #1696]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1905
LBB0_1357:                              ; %else4657
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1906
LBB0_1358:                              ; %else4661
	tbz	w8, #7, LBB0_1360
LBB0_1359:                              ; %cond.store4662
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1360:                              ; %else4665
	ldr	q0, [sp, #10256]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #1680]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1907
; %bb.1361:                             ; %else4670
	ldr	q3, [sp, #3680]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_1908
LBB0_1362:                              ; %else4674
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1909
LBB0_1363:                              ; %else4678
	ldr	q4, [sp, #3664]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_1910
LBB0_1364:                              ; %else4682
	ldr	q0, [sp, #10272]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1911
LBB0_1365:                              ; %else4686
	ldr	q3, [sp, #1664]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1912
LBB0_1366:                              ; %else4690
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1913
LBB0_1367:                              ; %else4694
	tbz	w8, #7, LBB0_1369
LBB0_1368:                              ; %cond.store4695
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1369:                              ; %else4698
	ldr	q0, [sp, #10288]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #1648]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1914
; %bb.1370:                             ; %else4703
	ldr	q3, [sp, #3648]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_1915
LBB0_1371:                              ; %else4707
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1916
LBB0_1372:                              ; %else4711
	ldr	q4, [sp, #3632]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_1917
LBB0_1373:                              ; %else4715
	ldr	q0, [sp, #10304]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1918
LBB0_1374:                              ; %else4719
	ldr	q3, [sp, #1632]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1919
LBB0_1375:                              ; %else4723
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1920
LBB0_1376:                              ; %else4727
	tbz	w8, #7, LBB0_1378
LBB0_1377:                              ; %cond.store4728
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1378:                              ; %else4731
	ldr	q0, [sp, #10320]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #1616]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1921
; %bb.1379:                             ; %else4736
	ldr	q3, [sp, #3616]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_1922
LBB0_1380:                              ; %else4740
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1923
LBB0_1381:                              ; %else4744
	ldr	q4, [sp, #3600]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_1924
LBB0_1382:                              ; %else4748
	ldr	q0, [sp, #10336]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1925
LBB0_1383:                              ; %else4752
	ldr	q3, [sp, #1600]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1926
LBB0_1384:                              ; %else4756
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1927
LBB0_1385:                              ; %else4760
	tbz	w8, #7, LBB0_1387
LBB0_1386:                              ; %cond.store4761
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1387:                              ; %else4764
	ldr	q0, [sp, #10352]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #1584]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1928
; %bb.1388:                             ; %else4769
	ldr	q3, [sp, #3584]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_1929
LBB0_1389:                              ; %else4773
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1930
LBB0_1390:                              ; %else4777
	and.16b	v3, v3, v5
	tbnz	w8, #3, LBB0_1931
LBB0_1391:                              ; %else4781
	ldr	q0, [sp, #10368]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1932
LBB0_1392:                              ; %else4785
	ldr	q3, [sp, #1552]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1933
LBB0_1393:                              ; %else4789
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1934
LBB0_1394:                              ; %else4793
	tbz	w8, #7, LBB0_1396
LBB0_1395:                              ; %cond.store4794
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1396:                              ; %else4797
	ldr	q0, [sp, #10384]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #1536]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1935
; %bb.1397:                             ; %else4802
	ldr	q3, [sp, #3568]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_1936
LBB0_1398:                              ; %else4806
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1937
LBB0_1399:                              ; %else4810
	ldr	q4, [sp, #3552]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_1938
LBB0_1400:                              ; %else4814
	ldr	q0, [sp, #10400]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1939
LBB0_1401:                              ; %else4818
	ldr	q3, [sp, #1520]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1940
LBB0_1402:                              ; %else4822
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1941
LBB0_1403:                              ; %else4826
	tbz	w8, #7, LBB0_1405
LBB0_1404:                              ; %cond.store4827
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1405:                              ; %else4830
	ldr	q0, [sp, #10416]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #1504]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1942
; %bb.1406:                             ; %else4835
	ldr	q3, [sp, #3536]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_1943
LBB0_1407:                              ; %else4839
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1944
LBB0_1408:                              ; %else4843
	and.16b	v3, v3, v16
	tbnz	w8, #3, LBB0_1945
LBB0_1409:                              ; %else4847
	ldr	q0, [sp, #10432]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1946
LBB0_1410:                              ; %else4851
	ldr	q3, [sp, #1472]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbnz	w8, #5, LBB0_1947
LBB0_1411:                              ; %else4855
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1948
LBB0_1412:                              ; %else4859
	tbz	w8, #7, LBB0_1414
LBB0_1413:                              ; %cond.store4860
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1414:                              ; %else4863
	ldr	q0, [sp, #10448]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #1456]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1949
; %bb.1415:                             ; %else4868
	ldr	q3, [sp, #3520]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_1950
LBB0_1416:                              ; %else4872
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1951
LBB0_1417:                              ; %else4876
	and.16b	v3, v3, v6
	tbnz	w8, #3, LBB0_1952
LBB0_1418:                              ; %else4880
	ldr	q0, [sp, #10464]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	ldr	q5, [sp, #1296]                 ; 16-byte Reload
	ldr	q6, [sp, #4128]                 ; 16-byte Reload
	tbnz	w8, #4, LBB0_1953
LBB0_1419:                              ; %else4884
	ldr	q3, [sp, #1424]                 ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_1954
LBB0_1420:                              ; %else4888
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1955
LBB0_1421:                              ; %else4892
	tbz	w8, #7, LBB0_1423
LBB0_1422:                              ; %cond.store4893
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1423:                              ; %else4896
	ldr	q0, [sp, #10480]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #1408]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1956
; %bb.1424:                             ; %else4901
	ldr	q3, [sp, #3504]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_1957
LBB0_1425:                              ; %else4905
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1958
LBB0_1426:                              ; %else4909
	and.16b	v3, v3, v17
	tbnz	w8, #3, LBB0_1959
LBB0_1427:                              ; %else4913
	ldr	q0, [sp, #10496]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1960
LBB0_1428:                              ; %else4917
	ldr	q3, [sp, #1376]                 ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_1961
LBB0_1429:                              ; %else4921
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1962
LBB0_1430:                              ; %else4925
	tbz	w8, #7, LBB0_1432
LBB0_1431:                              ; %cond.store4926
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1432:                              ; %else4929
	ldr	q0, [sp, #10512]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #1360]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1963
; %bb.1433:                             ; %else4934
	and.16b	v4, v7, v18
	tbnz	w8, #1, LBB0_1964
LBB0_1434:                              ; %else4938
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1965
LBB0_1435:                              ; %else4942
	ldr	q4, [sp, #3488]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_1966
LBB0_1436:                              ; %else4946
	ldr	q0, [sp, #10528]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1967
LBB0_1437:                              ; %else4950
	ldr	q3, [sp, #1328]                 ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_1968
LBB0_1438:                              ; %else4954
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1969
LBB0_1439:                              ; %else4958
	tbz	w8, #7, LBB0_1441
LBB0_1440:                              ; %cond.store4959
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1441:                              ; %else4962
	ldr	q0, [sp, #10544]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #1312]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1970
; %bb.1442:                             ; %else4967
	and.16b	v4, v7, v5
	tbnz	w8, #1, LBB0_1971
LBB0_1443:                              ; %else4971
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1972
LBB0_1444:                              ; %else4975
	ldr	q4, [sp, #3472]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_1973
LBB0_1445:                              ; %else4979
	ldr	q0, [sp, #10560]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1974
LBB0_1446:                              ; %else4983
	ldr	q3, [sp, #1280]                 ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_1975
LBB0_1447:                              ; %else4987
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1976
LBB0_1448:                              ; %else4991
	tbz	w8, #7, LBB0_1450
LBB0_1449:                              ; %cond.store4992
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1450:                              ; %else4995
	ldr	q0, [sp, #10576]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #1264]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1977
; %bb.1451:                             ; %else5000
	ldr	q3, [sp, #3456]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_1978
LBB0_1452:                              ; %else5004
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1979
LBB0_1453:                              ; %else5008
	ldr	q4, [sp, #3440]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_1980
LBB0_1454:                              ; %else5012
	ldr	q0, [sp, #10592]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1981
LBB0_1455:                              ; %else5016
	ldr	q3, [sp, #1248]                 ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_1982
LBB0_1456:                              ; %else5020
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1983
LBB0_1457:                              ; %else5024
	tbz	w8, #7, LBB0_1459
LBB0_1458:                              ; %cond.store5025
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1459:                              ; %else5028
	ldr	q0, [sp, #10608]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #1232]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1984
; %bb.1460:                             ; %else5033
	ldr	q3, [sp, #3424]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_1985
LBB0_1461:                              ; %else5037
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1986
LBB0_1462:                              ; %else5041
	ldr	q4, [sp, #3408]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_1987
LBB0_1463:                              ; %else5045
	ldr	q0, [sp, #10624]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1988
LBB0_1464:                              ; %else5049
	ldr	q3, [sp, #1216]                 ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_1989
LBB0_1465:                              ; %else5053
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1990
LBB0_1466:                              ; %else5057
	tbz	w8, #7, LBB0_1468
LBB0_1467:                              ; %cond.store5058
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1468:                              ; %else5061
	ldr	q0, [sp, #10640]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #1200]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1991
; %bb.1469:                             ; %else5066
	ldr	q3, [sp, #3392]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_1992
LBB0_1470:                              ; %else5070
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_1993
LBB0_1471:                              ; %else5074
	ldr	q4, [sp, #3376]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_1994
LBB0_1472:                              ; %else5078
	ldr	q0, [sp, #10656]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_1995
LBB0_1473:                              ; %else5082
	ldr	q3, [sp, #1184]                 ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_1996
LBB0_1474:                              ; %else5086
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_1997
LBB0_1475:                              ; %else5090
	tbz	w8, #7, LBB0_1477
LBB0_1476:                              ; %cond.store5091
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1477:                              ; %else5094
	ldr	q0, [sp, #10672]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #1168]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_1998
; %bb.1478:                             ; %else5099
	ldr	q3, [sp, #3360]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_1999
LBB0_1479:                              ; %else5103
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2000
LBB0_1480:                              ; %else5107
	ldr	q4, [sp, #3344]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2001
LBB0_1481:                              ; %else5111
	ldr	q0, [sp, #10688]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2002
LBB0_1482:                              ; %else5115
	ldr	q3, [sp, #1152]                 ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2003
LBB0_1483:                              ; %else5119
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2004
LBB0_1484:                              ; %else5123
	tbz	w8, #7, LBB0_1486
LBB0_1485:                              ; %cond.store5124
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1486:                              ; %else5127
	ldr	q0, [sp, #10704]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #1136]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2005
; %bb.1487:                             ; %else5132
	ldr	q3, [sp, #3328]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2006
LBB0_1488:                              ; %else5136
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2007
LBB0_1489:                              ; %else5140
	ldr	q4, [sp, #3312]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2008
LBB0_1490:                              ; %else5144
	ldr	q0, [sp, #10720]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2009
LBB0_1491:                              ; %else5148
	ldr	q3, [sp, #1120]                 ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2010
LBB0_1492:                              ; %else5152
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2011
LBB0_1493:                              ; %else5156
	tbz	w8, #7, LBB0_1495
LBB0_1494:                              ; %cond.store5157
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1495:                              ; %else5160
	ldr	q0, [sp, #10736]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #1104]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2012
; %bb.1496:                             ; %else5165
	ldr	q3, [sp, #3296]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2013
LBB0_1497:                              ; %else5169
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2014
LBB0_1498:                              ; %else5173
	ldr	q4, [sp, #3280]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2015
LBB0_1499:                              ; %else5177
	ldr	q0, [sp, #10752]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2016
LBB0_1500:                              ; %else5181
	ldr	q3, [sp, #1088]                 ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2017
LBB0_1501:                              ; %else5185
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2018
LBB0_1502:                              ; %else5189
	tbz	w8, #7, LBB0_1504
LBB0_1503:                              ; %cond.store5190
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1504:                              ; %else5193
	ldr	q0, [sp, #10768]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #1072]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2019
; %bb.1505:                             ; %else5198
	ldr	q3, [sp, #3264]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2020
LBB0_1506:                              ; %else5202
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2021
LBB0_1507:                              ; %else5206
	ldr	q4, [sp, #3248]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2022
LBB0_1508:                              ; %else5210
	ldr	q0, [sp, #10784]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2023
LBB0_1509:                              ; %else5214
	ldr	q3, [sp, #1056]                 ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2024
LBB0_1510:                              ; %else5218
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2025
LBB0_1511:                              ; %else5222
	tbz	w8, #7, LBB0_1513
LBB0_1512:                              ; %cond.store5223
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1513:                              ; %else5226
	ldr	q0, [sp, #10800]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #1040]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2026
; %bb.1514:                             ; %else5231
	ldr	q3, [sp, #3232]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2027
LBB0_1515:                              ; %else5235
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2028
LBB0_1516:                              ; %else5239
	ldr	q4, [sp, #3216]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2029
LBB0_1517:                              ; %else5243
	ldr	q0, [sp, #10816]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2030
LBB0_1518:                              ; %else5247
	ldr	q3, [sp, #1024]                 ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2031
LBB0_1519:                              ; %else5251
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2032
LBB0_1520:                              ; %else5255
	tbz	w8, #7, LBB0_1522
LBB0_1521:                              ; %cond.store5256
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1522:                              ; %else5259
	ldr	q0, [sp, #10832]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #1008]                 ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2033
; %bb.1523:                             ; %else5264
	ldr	q3, [sp, #3200]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2034
LBB0_1524:                              ; %else5268
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2035
LBB0_1525:                              ; %else5272
	ldr	q4, [sp, #3184]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2036
LBB0_1526:                              ; %else5276
	ldr	q0, [sp, #10848]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2037
LBB0_1527:                              ; %else5280
	ldr	q3, [sp, #992]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2038
LBB0_1528:                              ; %else5284
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2039
LBB0_1529:                              ; %else5288
	tbz	w8, #7, LBB0_1531
LBB0_1530:                              ; %cond.store5289
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1531:                              ; %else5292
	ldr	q0, [sp, #10864]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #976]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2040
; %bb.1532:                             ; %else5297
	ldr	q3, [sp, #3168]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2041
LBB0_1533:                              ; %else5301
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2042
LBB0_1534:                              ; %else5305
	ldr	q4, [sp, #3152]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2043
LBB0_1535:                              ; %else5309
	ldr	q0, [sp, #10880]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2044
LBB0_1536:                              ; %else5313
	ldr	q3, [sp, #960]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2045
LBB0_1537:                              ; %else5317
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2046
LBB0_1538:                              ; %else5321
	tbz	w8, #7, LBB0_1540
LBB0_1539:                              ; %cond.store5322
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1540:                              ; %else5325
	ldr	q0, [sp, #10896]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #944]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2047
; %bb.1541:                             ; %else5330
	ldr	q3, [sp, #3136]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2048
LBB0_1542:                              ; %else5334
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2049
LBB0_1543:                              ; %else5338
	ldr	q4, [sp, #3120]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2050
LBB0_1544:                              ; %else5342
	ldr	q0, [sp, #10912]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2051
LBB0_1545:                              ; %else5346
	ldr	q3, [sp, #928]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2052
LBB0_1546:                              ; %else5350
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2053
LBB0_1547:                              ; %else5354
	tbz	w8, #7, LBB0_1549
LBB0_1548:                              ; %cond.store5355
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1549:                              ; %else5358
	ldr	q0, [sp, #10928]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #912]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2054
; %bb.1550:                             ; %else5363
	ldr	q3, [sp, #3104]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2055
LBB0_1551:                              ; %else5367
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2056
LBB0_1552:                              ; %else5371
	ldr	q4, [sp, #3088]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2057
LBB0_1553:                              ; %else5375
	ldr	q0, [sp, #10944]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2058
LBB0_1554:                              ; %else5379
	ldr	q3, [sp, #896]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2059
LBB0_1555:                              ; %else5383
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2060
LBB0_1556:                              ; %else5387
	tbz	w8, #7, LBB0_1558
LBB0_1557:                              ; %cond.store5388
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1558:                              ; %else5391
	ldr	q0, [sp, #10960]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #880]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2061
; %bb.1559:                             ; %else5396
	ldr	q3, [sp, #3072]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2062
LBB0_1560:                              ; %else5400
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2063
LBB0_1561:                              ; %else5404
	ldr	q4, [sp, #3056]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2064
LBB0_1562:                              ; %else5408
	ldr	q0, [sp, #10976]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2065
LBB0_1563:                              ; %else5412
	ldr	q3, [sp, #864]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2066
LBB0_1564:                              ; %else5416
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2067
LBB0_1565:                              ; %else5420
	tbz	w8, #7, LBB0_1567
LBB0_1566:                              ; %cond.store5421
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1567:                              ; %else5424
	ldr	q0, [sp, #10992]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #848]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2068
; %bb.1568:                             ; %else5429
	ldr	q3, [sp, #3040]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2069
LBB0_1569:                              ; %else5433
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2070
LBB0_1570:                              ; %else5437
	ldr	q4, [sp, #3024]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2071
LBB0_1571:                              ; %else5441
	ldr	q0, [sp, #11008]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2072
LBB0_1572:                              ; %else5445
	ldr	q3, [sp, #832]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2073
LBB0_1573:                              ; %else5449
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2074
LBB0_1574:                              ; %else5453
	tbz	w8, #7, LBB0_1576
LBB0_1575:                              ; %cond.store5454
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1576:                              ; %else5457
	ldr	q0, [sp, #11024]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #816]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2075
; %bb.1577:                             ; %else5462
	ldr	q3, [sp, #3008]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2076
LBB0_1578:                              ; %else5466
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2077
LBB0_1579:                              ; %else5470
	ldr	q4, [sp, #2992]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2078
LBB0_1580:                              ; %else5474
	ldr	q0, [sp, #11040]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2079
LBB0_1581:                              ; %else5478
	ldr	q3, [sp, #800]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2080
LBB0_1582:                              ; %else5482
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2081
LBB0_1583:                              ; %else5486
	tbz	w8, #7, LBB0_1585
LBB0_1584:                              ; %cond.store5487
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1585:                              ; %else5490
	ldr	q0, [sp, #11056]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #784]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2082
; %bb.1586:                             ; %else5495
	ldr	q3, [sp, #2976]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2083
LBB0_1587:                              ; %else5499
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2084
LBB0_1588:                              ; %else5503
	ldr	q4, [sp, #2960]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2085
LBB0_1589:                              ; %else5507
	ldr	q0, [sp, #11072]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2086
LBB0_1590:                              ; %else5511
	ldr	q3, [sp, #768]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2087
LBB0_1591:                              ; %else5515
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2088
LBB0_1592:                              ; %else5519
	tbz	w8, #7, LBB0_1594
LBB0_1593:                              ; %cond.store5520
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1594:                              ; %else5523
	ldr	q0, [sp, #11088]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #752]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2089
; %bb.1595:                             ; %else5528
	ldr	q3, [sp, #2944]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2090
LBB0_1596:                              ; %else5532
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2091
LBB0_1597:                              ; %else5536
	ldr	q4, [sp, #2928]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2092
LBB0_1598:                              ; %else5540
	ldr	q0, [sp, #11104]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2093
LBB0_1599:                              ; %else5544
	ldr	q3, [sp, #736]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2094
LBB0_1600:                              ; %else5548
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2095
LBB0_1601:                              ; %else5552
	tbz	w8, #7, LBB0_1603
LBB0_1602:                              ; %cond.store5553
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1603:                              ; %else5556
	ldr	q0, [sp, #11120]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #720]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2096
; %bb.1604:                             ; %else5561
	ldr	q3, [sp, #2912]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2097
LBB0_1605:                              ; %else5565
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2098
LBB0_1606:                              ; %else5569
	ldr	q4, [sp, #2896]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2099
LBB0_1607:                              ; %else5573
	ldr	q0, [sp, #11136]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2100
LBB0_1608:                              ; %else5577
	ldr	q3, [sp, #704]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2101
LBB0_1609:                              ; %else5581
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2102
LBB0_1610:                              ; %else5585
	tbz	w8, #7, LBB0_1612
LBB0_1611:                              ; %cond.store5586
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1612:                              ; %else5589
	ldr	q0, [sp, #11152]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #688]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2103
; %bb.1613:                             ; %else5594
	ldr	q3, [sp, #2880]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2104
LBB0_1614:                              ; %else5598
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2105
LBB0_1615:                              ; %else5602
	ldr	q4, [sp, #2864]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2106
LBB0_1616:                              ; %else5606
	ldr	q0, [sp, #11168]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2107
LBB0_1617:                              ; %else5610
	ldr	q3, [sp, #672]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2108
LBB0_1618:                              ; %else5614
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2109
LBB0_1619:                              ; %else5618
	tbz	w8, #7, LBB0_1621
LBB0_1620:                              ; %cond.store5619
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1621:                              ; %else5622
	ldr	q0, [sp, #11184]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #656]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2110
; %bb.1622:                             ; %else5627
	ldr	q3, [sp, #2848]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2111
LBB0_1623:                              ; %else5631
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2112
LBB0_1624:                              ; %else5635
	ldr	q4, [sp, #2832]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2113
LBB0_1625:                              ; %else5639
	ldr	q0, [sp, #11200]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2114
LBB0_1626:                              ; %else5643
	ldr	q3, [sp, #640]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2115
LBB0_1627:                              ; %else5647
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2116
LBB0_1628:                              ; %else5651
	tbz	w8, #7, LBB0_1630
LBB0_1629:                              ; %cond.store5652
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1630:                              ; %else5655
	ldr	q0, [sp, #11216]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #624]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2117
; %bb.1631:                             ; %else5660
	ldr	q3, [sp, #2816]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2118
LBB0_1632:                              ; %else5664
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2119
LBB0_1633:                              ; %else5668
	ldr	q4, [sp, #2800]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2120
LBB0_1634:                              ; %else5672
	ldr	q0, [sp, #11232]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2121
LBB0_1635:                              ; %else5676
	ldr	q3, [sp, #608]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2122
LBB0_1636:                              ; %else5680
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2123
LBB0_1637:                              ; %else5684
	tbz	w8, #7, LBB0_1639
LBB0_1638:                              ; %cond.store5685
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1639:                              ; %else5688
	ldr	q0, [sp, #11248]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #592]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2124
; %bb.1640:                             ; %else5693
	ldr	q3, [sp, #2784]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2125
LBB0_1641:                              ; %else5697
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2126
LBB0_1642:                              ; %else5701
	ldr	q4, [sp, #2768]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2127
LBB0_1643:                              ; %else5705
	ldr	q0, [sp, #11264]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2128
LBB0_1644:                              ; %else5709
	ldr	q3, [sp, #576]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2129
LBB0_1645:                              ; %else5713
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2130
LBB0_1646:                              ; %else5717
	tbz	w8, #7, LBB0_1648
LBB0_1647:                              ; %cond.store5718
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1648:                              ; %else5721
	ldr	q0, [sp, #11280]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #560]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2131
; %bb.1649:                             ; %else5726
	ldr	q3, [sp, #2752]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2132
LBB0_1650:                              ; %else5730
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2133
LBB0_1651:                              ; %else5734
	ldr	q4, [sp, #2736]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2134
LBB0_1652:                              ; %else5738
	ldr	q0, [sp, #11296]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2135
LBB0_1653:                              ; %else5742
	ldr	q3, [sp, #544]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2136
LBB0_1654:                              ; %else5746
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2137
LBB0_1655:                              ; %else5750
	tbz	w8, #7, LBB0_1657
LBB0_1656:                              ; %cond.store5751
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1657:                              ; %else5754
	ldr	q0, [sp, #11312]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #528]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2138
; %bb.1658:                             ; %else5759
	ldr	q3, [sp, #2720]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2139
LBB0_1659:                              ; %else5763
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2140
LBB0_1660:                              ; %else5767
	ldr	q4, [sp, #2704]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2141
LBB0_1661:                              ; %else5771
	ldr	q0, [sp, #11328]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2142
LBB0_1662:                              ; %else5775
	ldr	q3, [sp, #512]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2143
LBB0_1663:                              ; %else5779
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2144
LBB0_1664:                              ; %else5783
	tbz	w8, #7, LBB0_1666
LBB0_1665:                              ; %cond.store5784
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1666:                              ; %else5787
	ldr	q0, [sp, #11344]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #496]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2145
; %bb.1667:                             ; %else5792
	ldr	q3, [sp, #2688]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2146
LBB0_1668:                              ; %else5796
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2147
LBB0_1669:                              ; %else5800
	ldr	q4, [sp, #2672]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2148
LBB0_1670:                              ; %else5804
	ldr	q0, [sp, #11360]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2149
LBB0_1671:                              ; %else5808
	ldr	q3, [sp, #480]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2150
LBB0_1672:                              ; %else5812
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2151
LBB0_1673:                              ; %else5816
	tbz	w8, #7, LBB0_1675
LBB0_1674:                              ; %cond.store5817
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1675:                              ; %else5820
	ldr	q0, [sp, #11376]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #464]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2152
; %bb.1676:                             ; %else5825
	ldr	q3, [sp, #2656]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2153
LBB0_1677:                              ; %else5829
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2154
LBB0_1678:                              ; %else5833
	ldr	q4, [sp, #2640]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2155
LBB0_1679:                              ; %else5837
	ldr	q0, [sp, #11392]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2156
LBB0_1680:                              ; %else5841
	ldr	q3, [sp, #448]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2157
LBB0_1681:                              ; %else5845
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2158
LBB0_1682:                              ; %else5849
	tbz	w8, #7, LBB0_1684
LBB0_1683:                              ; %cond.store5850
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1684:                              ; %else5853
	ldr	q0, [sp, #11408]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #432]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2159
; %bb.1685:                             ; %else5858
	ldr	q3, [sp, #2624]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2160
LBB0_1686:                              ; %else5862
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2161
LBB0_1687:                              ; %else5866
	ldr	q4, [sp, #2608]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2162
LBB0_1688:                              ; %else5870
	ldr	q0, [sp, #11424]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2163
LBB0_1689:                              ; %else5874
	ldr	q3, [sp, #416]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2164
LBB0_1690:                              ; %else5878
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2165
LBB0_1691:                              ; %else5882
	tbz	w8, #7, LBB0_1693
LBB0_1692:                              ; %cond.store5883
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1693:                              ; %else5886
	ldr	q0, [sp, #11440]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #400]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2166
; %bb.1694:                             ; %else5891
	ldr	q3, [sp, #2592]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2167
LBB0_1695:                              ; %else5895
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2168
LBB0_1696:                              ; %else5899
	ldr	q4, [sp, #2576]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2169
LBB0_1697:                              ; %else5903
	ldr	q0, [sp, #11456]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2170
LBB0_1698:                              ; %else5907
	ldr	q3, [sp, #384]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2171
LBB0_1699:                              ; %else5911
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2172
LBB0_1700:                              ; %else5915
	tbz	w8, #7, LBB0_1702
LBB0_1701:                              ; %cond.store5916
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1702:                              ; %else5919
	ldr	q0, [sp, #11472]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #368]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2173
; %bb.1703:                             ; %else5924
	ldr	q3, [sp, #2560]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2174
LBB0_1704:                              ; %else5928
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2175
LBB0_1705:                              ; %else5932
	ldr	q4, [sp, #2544]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2176
LBB0_1706:                              ; %else5936
	ldr	q0, [sp, #11488]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2177
LBB0_1707:                              ; %else5940
	ldr	q3, [sp, #352]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2178
LBB0_1708:                              ; %else5944
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2179
LBB0_1709:                              ; %else5948
	tbz	w8, #7, LBB0_1711
LBB0_1710:                              ; %cond.store5949
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1711:                              ; %else5952
	ldr	q0, [sp, #11504]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #336]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2180
; %bb.1712:                             ; %else5957
	ldr	q3, [sp, #2528]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2181
LBB0_1713:                              ; %else5961
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2182
LBB0_1714:                              ; %else5965
	ldr	q4, [sp, #2512]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2183
LBB0_1715:                              ; %else5969
	ldr	q0, [sp, #11520]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2184
LBB0_1716:                              ; %else5973
	ldr	q3, [sp, #320]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2185
LBB0_1717:                              ; %else5977
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2186
LBB0_1718:                              ; %else5981
	tbz	w8, #7, LBB0_1720
LBB0_1719:                              ; %cond.store5982
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1720:                              ; %else5985
	ldr	q0, [sp, #11536]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #304]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2187
; %bb.1721:                             ; %else5990
	ldr	q3, [sp, #2496]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2188
LBB0_1722:                              ; %else5994
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2189
LBB0_1723:                              ; %else5998
	ldr	q4, [sp, #2480]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2190
LBB0_1724:                              ; %else6002
	ldr	q0, [sp, #11552]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2191
LBB0_1725:                              ; %else6006
	ldr	q3, [sp, #288]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2192
LBB0_1726:                              ; %else6010
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2193
LBB0_1727:                              ; %else6014
	tbz	w8, #7, LBB0_1729
LBB0_1728:                              ; %cond.store6015
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1729:                              ; %else6018
	ldr	q0, [sp, #11568]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #272]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2194
; %bb.1730:                             ; %else6023
	ldr	q3, [sp, #2464]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2195
LBB0_1731:                              ; %else6027
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2196
LBB0_1732:                              ; %else6031
	ldr	q4, [sp, #2448]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2197
LBB0_1733:                              ; %else6035
	ldr	q0, [sp, #11584]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2198
LBB0_1734:                              ; %else6039
	ldr	q3, [sp, #256]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2199
LBB0_1735:                              ; %else6043
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2200
LBB0_1736:                              ; %else6047
	tbz	w8, #7, LBB0_1738
LBB0_1737:                              ; %cond.store6048
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1738:                              ; %else6051
	ldr	q0, [sp, #11600]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #240]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2201
; %bb.1739:                             ; %else6056
	ldr	q3, [sp, #2432]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2202
LBB0_1740:                              ; %else6060
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2203
LBB0_1741:                              ; %else6064
	ldr	q4, [sp, #2416]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2204
LBB0_1742:                              ; %else6068
	ldr	q0, [sp, #11616]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2205
LBB0_1743:                              ; %else6072
	ldr	q3, [sp, #224]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2206
LBB0_1744:                              ; %else6076
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2207
LBB0_1745:                              ; %else6080
	tbz	w8, #7, LBB0_1747
LBB0_1746:                              ; %cond.store6081
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1747:                              ; %else6084
	ldr	q0, [sp, #11632]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #208]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2208
; %bb.1748:                             ; %else6089
	ldr	q3, [sp, #2400]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2209
LBB0_1749:                              ; %else6093
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2210
LBB0_1750:                              ; %else6097
	ldr	q4, [sp, #2384]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2211
LBB0_1751:                              ; %else6101
	ldr	q0, [sp, #11648]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2212
LBB0_1752:                              ; %else6105
	ldr	q3, [sp, #192]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2213
LBB0_1753:                              ; %else6109
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2214
LBB0_1754:                              ; %else6113
	tbz	w8, #7, LBB0_1756
LBB0_1755:                              ; %cond.store6114
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1756:                              ; %else6117
	ldr	q0, [sp, #11664]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #176]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2215
; %bb.1757:                             ; %else6122
	ldr	q3, [sp, #2368]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2216
LBB0_1758:                              ; %else6126
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2217
LBB0_1759:                              ; %else6130
	ldr	q4, [sp, #2352]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2218
LBB0_1760:                              ; %else6134
	ldr	q0, [sp, #11680]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2219
LBB0_1761:                              ; %else6138
	ldr	q3, [sp, #160]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2220
LBB0_1762:                              ; %else6142
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2221
LBB0_1763:                              ; %else6146
	tbz	w8, #7, LBB0_1765
LBB0_1764:                              ; %cond.store6147
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1765:                              ; %else6150
	ldr	q0, [sp, #11696]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #144]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2222
; %bb.1766:                             ; %else6155
	ldr	q3, [sp, #2336]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2223
LBB0_1767:                              ; %else6159
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2224
LBB0_1768:                              ; %else6163
	ldr	q4, [sp, #2320]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2225
LBB0_1769:                              ; %else6167
	ldr	q0, [sp, #11712]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2226
LBB0_1770:                              ; %else6171
	ldr	q3, [sp, #128]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2227
LBB0_1771:                              ; %else6175
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2228
LBB0_1772:                              ; %else6179
	tbz	w8, #7, LBB0_1774
LBB0_1773:                              ; %cond.store6180
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1774:                              ; %else6183
	ldr	q0, [sp, #11728]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #112]                  ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2229
; %bb.1775:                             ; %else6188
	ldr	q3, [sp, #2304]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2230
LBB0_1776:                              ; %else6192
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2231
LBB0_1777:                              ; %else6196
	ldr	q4, [sp, #2288]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2232
LBB0_1778:                              ; %else6200
	ldr	q0, [sp, #11744]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2233
LBB0_1779:                              ; %else6204
	ldr	q3, [sp, #96]                   ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2234
LBB0_1780:                              ; %else6208
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2235
LBB0_1781:                              ; %else6212
	tbz	w8, #7, LBB0_1783
LBB0_1782:                              ; %cond.store6213
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1783:                              ; %else6216
	ldr	q0, [sp, #11760]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #80]                   ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2236
; %bb.1784:                             ; %else6221
	ldr	q3, [sp, #2272]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2237
LBB0_1785:                              ; %else6225
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2238
LBB0_1786:                              ; %else6229
	ldr	q4, [sp, #2256]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2239
LBB0_1787:                              ; %else6233
	ldr	q0, [sp, #11776]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2240
LBB0_1788:                              ; %else6237
	ldr	q3, [sp, #64]                   ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2241
LBB0_1789:                              ; %else6241
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2242
LBB0_1790:                              ; %else6245
	tbz	w8, #7, LBB0_1792
LBB0_1791:                              ; %cond.store6246
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1792:                              ; %else6249
	ldr	q0, [sp, #11792]                ; 16-byte Reload
	fdiv.4s	v0, v0, v21
	fmov	w9, s19
	and	w8, w9, #0xff
	sshll.2d	v1, v14, #0
	ldr	q3, [sp, #48]                   ; 16-byte Reload
	and.16b	v1, v1, v3
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2243
; %bb.1793:                             ; %else6254
	ldr	q3, [sp, #2240]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbnz	w8, #1, LBB0_2244
LBB0_1794:                              ; %else6258
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbnz	w8, #2, LBB0_2245
LBB0_1795:                              ; %else6262
	ldr	q4, [sp, #2224]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbnz	w8, #3, LBB0_2246
LBB0_1796:                              ; %else6266
	ldr	q0, [sp, #11808]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbnz	w8, #4, LBB0_2247
LBB0_1797:                              ; %else6270
	ldr	q3, [sp, #32]                   ; 16-byte Reload
	and.16b	v3, v6, v3
	tbnz	w8, #5, LBB0_2248
LBB0_1798:                              ; %else6274
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2249
LBB0_1799:                              ; %else6278
	tbz	w8, #7, LBB0_1801
LBB0_1800:                              ; %cond.store6279
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1801:                              ; %common.ret
	add	sp, sp, #3, lsl #12             ; =12288
	add	sp, sp, #1856
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
LBB0_1802:                              ; %cond.store
	fmov	x9, d1
	str	s0, [x9]
	ldr	q7, [sp, #16]                   ; 16-byte Reload
	and.16b	v4, v7, v3
	ldr	q16, [sp, #1488]                ; 16-byte Reload
	ldr	q17, [sp, #1392]                ; 16-byte Reload
	ldr	q18, [sp, #1344]                ; 16-byte Reload
	tbz	w8, #1, LBB0_1227
LBB0_1803:                              ; %cond.store4183
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1228
LBB0_1804:                              ; %cond.store4186
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #2176]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1229
LBB0_1805:                              ; %cond.store4189
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #9792]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1230
LBB0_1806:                              ; %cond.store4192
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v3, v5
	tbz	w8, #5, LBB0_1231
LBB0_1807:                              ; %cond.store4195
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1232
LBB0_1808:                              ; %cond.store4198
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1233
	b	LBB0_1234
LBB0_1809:                              ; %cond.store4205
	fmov	x9, d1
	str	s0, [x9]
	and.16b	v4, v7, v6
	tbz	w8, #1, LBB0_1236
LBB0_1810:                              ; %cond.store4209
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	ldr	q5, [sp, #1568]                 ; 16-byte Reload
	ldr	q6, [sp, #1440]                 ; 16-byte Reload
	tbz	w8, #2, LBB0_1237
LBB0_1811:                              ; %cond.store4213
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #4112]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1238
LBB0_1812:                              ; %cond.store4217
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #9824]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1239
LBB0_1813:                              ; %cond.store4221
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2112]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1240
LBB0_1814:                              ; %cond.store4225
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1241
LBB0_1815:                              ; %cond.store4229
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1242
	b	LBB0_1243
LBB0_1816:                              ; %cond.store4238
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #4096]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1245
LBB0_1817:                              ; %cond.store4242
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1246
LBB0_1818:                              ; %cond.store4246
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #4080]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1247
LBB0_1819:                              ; %cond.store4250
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #9856]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1248
LBB0_1820:                              ; %cond.store4254
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2080]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1249
LBB0_1821:                              ; %cond.store4258
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1250
LBB0_1822:                              ; %cond.store4262
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1251
	b	LBB0_1252
LBB0_1823:                              ; %cond.store4271
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #4064]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1254
LBB0_1824:                              ; %cond.store4275
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1255
LBB0_1825:                              ; %cond.store4279
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #4048]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1256
LBB0_1826:                              ; %cond.store4283
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #9888]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1257
LBB0_1827:                              ; %cond.store4287
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2048]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1258
LBB0_1828:                              ; %cond.store4291
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1259
LBB0_1829:                              ; %cond.store4295
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1260
	b	LBB0_1261
LBB0_1830:                              ; %cond.store4304
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #4032]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1263
LBB0_1831:                              ; %cond.store4308
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1264
LBB0_1832:                              ; %cond.store4312
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #4016]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1265
LBB0_1833:                              ; %cond.store4316
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #9920]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1266
LBB0_1834:                              ; %cond.store4320
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2016]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1267
LBB0_1835:                              ; %cond.store4324
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1268
LBB0_1836:                              ; %cond.store4328
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1269
	b	LBB0_1270
LBB0_1837:                              ; %cond.store4337
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #4000]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1272
LBB0_1838:                              ; %cond.store4341
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1273
LBB0_1839:                              ; %cond.store4345
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3984]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1274
LBB0_1840:                              ; %cond.store4349
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #9952]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1275
LBB0_1841:                              ; %cond.store4353
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1984]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1276
LBB0_1842:                              ; %cond.store4357
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1277
LBB0_1843:                              ; %cond.store4361
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1278
	b	LBB0_1279
LBB0_1844:                              ; %cond.store4370
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3968]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1281
LBB0_1845:                              ; %cond.store4374
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1282
LBB0_1846:                              ; %cond.store4378
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3952]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1283
LBB0_1847:                              ; %cond.store4382
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #9984]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1284
LBB0_1848:                              ; %cond.store4386
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1952]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1285
LBB0_1849:                              ; %cond.store4390
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1286
LBB0_1850:                              ; %cond.store4394
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1287
	b	LBB0_1288
LBB0_1851:                              ; %cond.store4403
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3936]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1290
LBB0_1852:                              ; %cond.store4407
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1291
LBB0_1853:                              ; %cond.store4411
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3920]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1292
LBB0_1854:                              ; %cond.store4415
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10016]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1293
LBB0_1855:                              ; %cond.store4419
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1920]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1294
LBB0_1856:                              ; %cond.store4423
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1295
LBB0_1857:                              ; %cond.store4427
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1296
	b	LBB0_1297
LBB0_1858:                              ; %cond.store4436
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3904]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1299
LBB0_1859:                              ; %cond.store4440
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1300
LBB0_1860:                              ; %cond.store4444
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3888]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1301
LBB0_1861:                              ; %cond.store4448
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10048]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1302
LBB0_1862:                              ; %cond.store4452
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1888]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1303
LBB0_1863:                              ; %cond.store4456
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1304
LBB0_1864:                              ; %cond.store4460
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1305
	b	LBB0_1306
LBB0_1865:                              ; %cond.store4469
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3872]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1308
LBB0_1866:                              ; %cond.store4473
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1309
LBB0_1867:                              ; %cond.store4477
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3856]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1310
LBB0_1868:                              ; %cond.store4481
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10080]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1311
LBB0_1869:                              ; %cond.store4485
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1856]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1312
LBB0_1870:                              ; %cond.store4489
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1313
LBB0_1871:                              ; %cond.store4493
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1314
	b	LBB0_1315
LBB0_1872:                              ; %cond.store4502
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3840]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1317
LBB0_1873:                              ; %cond.store4506
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1318
LBB0_1874:                              ; %cond.store4510
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3824]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1319
LBB0_1875:                              ; %cond.store4514
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10112]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1320
LBB0_1876:                              ; %cond.store4518
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1824]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1321
LBB0_1877:                              ; %cond.store4522
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1322
LBB0_1878:                              ; %cond.store4526
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1323
	b	LBB0_1324
LBB0_1879:                              ; %cond.store4535
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3808]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1326
LBB0_1880:                              ; %cond.store4539
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1327
LBB0_1881:                              ; %cond.store4543
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3792]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1328
LBB0_1882:                              ; %cond.store4547
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10144]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1329
LBB0_1883:                              ; %cond.store4551
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1792]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1330
LBB0_1884:                              ; %cond.store4555
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1331
LBB0_1885:                              ; %cond.store4559
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1332
	b	LBB0_1333
LBB0_1886:                              ; %cond.store4568
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3776]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1335
LBB0_1887:                              ; %cond.store4572
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1336
LBB0_1888:                              ; %cond.store4576
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3760]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1337
LBB0_1889:                              ; %cond.store4580
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10176]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1338
LBB0_1890:                              ; %cond.store4584
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1760]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1339
LBB0_1891:                              ; %cond.store4588
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1340
LBB0_1892:                              ; %cond.store4592
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1341
	b	LBB0_1342
LBB0_1893:                              ; %cond.store4601
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3744]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1344
LBB0_1894:                              ; %cond.store4605
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1345
LBB0_1895:                              ; %cond.store4609
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3728]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1346
LBB0_1896:                              ; %cond.store4613
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10208]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1347
LBB0_1897:                              ; %cond.store4617
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1728]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1348
LBB0_1898:                              ; %cond.store4621
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1349
LBB0_1899:                              ; %cond.store4625
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1350
	b	LBB0_1351
LBB0_1900:                              ; %cond.store4634
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3712]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1353
LBB0_1901:                              ; %cond.store4638
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1354
LBB0_1902:                              ; %cond.store4642
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3696]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1355
LBB0_1903:                              ; %cond.store4646
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10240]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1356
LBB0_1904:                              ; %cond.store4650
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1696]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1357
LBB0_1905:                              ; %cond.store4654
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1358
LBB0_1906:                              ; %cond.store4658
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1359
	b	LBB0_1360
LBB0_1907:                              ; %cond.store4667
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3680]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1362
LBB0_1908:                              ; %cond.store4671
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1363
LBB0_1909:                              ; %cond.store4675
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3664]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1364
LBB0_1910:                              ; %cond.store4679
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10272]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1365
LBB0_1911:                              ; %cond.store4683
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1664]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1366
LBB0_1912:                              ; %cond.store4687
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1367
LBB0_1913:                              ; %cond.store4691
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1368
	b	LBB0_1369
LBB0_1914:                              ; %cond.store4700
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3648]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1371
LBB0_1915:                              ; %cond.store4704
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1372
LBB0_1916:                              ; %cond.store4708
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3632]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1373
LBB0_1917:                              ; %cond.store4712
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10304]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1374
LBB0_1918:                              ; %cond.store4716
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1632]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1375
LBB0_1919:                              ; %cond.store4720
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1376
LBB0_1920:                              ; %cond.store4724
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1377
	b	LBB0_1378
LBB0_1921:                              ; %cond.store4733
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3616]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1380
LBB0_1922:                              ; %cond.store4737
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1381
LBB0_1923:                              ; %cond.store4741
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3600]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1382
LBB0_1924:                              ; %cond.store4745
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10336]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1383
LBB0_1925:                              ; %cond.store4749
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1600]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1384
LBB0_1926:                              ; %cond.store4753
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1385
LBB0_1927:                              ; %cond.store4757
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1386
	b	LBB0_1387
LBB0_1928:                              ; %cond.store4766
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3584]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1389
LBB0_1929:                              ; %cond.store4770
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1390
LBB0_1930:                              ; %cond.store4774
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v5
	tbz	w8, #3, LBB0_1391
LBB0_1931:                              ; %cond.store4778
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10368]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1392
LBB0_1932:                              ; %cond.store4782
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1552]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1393
LBB0_1933:                              ; %cond.store4786
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1394
LBB0_1934:                              ; %cond.store4790
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1395
	b	LBB0_1396
LBB0_1935:                              ; %cond.store4799
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3568]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1398
LBB0_1936:                              ; %cond.store4803
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1399
LBB0_1937:                              ; %cond.store4807
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3552]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1400
LBB0_1938:                              ; %cond.store4811
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10400]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1401
LBB0_1939:                              ; %cond.store4815
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1520]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1402
LBB0_1940:                              ; %cond.store4819
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1403
LBB0_1941:                              ; %cond.store4823
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1404
	b	LBB0_1405
LBB0_1942:                              ; %cond.store4832
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3536]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1407
LBB0_1943:                              ; %cond.store4836
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1408
LBB0_1944:                              ; %cond.store4840
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v16
	tbz	w8, #3, LBB0_1409
LBB0_1945:                              ; %cond.store4844
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10432]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1410
LBB0_1946:                              ; %cond.store4848
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1472]                 ; 16-byte Reload
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	and.16b	v3, v4, v3
	tbz	w8, #5, LBB0_1411
LBB0_1947:                              ; %cond.store4852
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1412
LBB0_1948:                              ; %cond.store4856
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1413
	b	LBB0_1414
LBB0_1949:                              ; %cond.store4865
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3520]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1416
LBB0_1950:                              ; %cond.store4869
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1417
LBB0_1951:                              ; %cond.store4873
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v6
	tbz	w8, #3, LBB0_1418
LBB0_1952:                              ; %cond.store4877
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10464]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	ldr	q5, [sp, #1296]                 ; 16-byte Reload
	ldr	q6, [sp, #4128]                 ; 16-byte Reload
	tbz	w8, #4, LBB0_1419
LBB0_1953:                              ; %cond.store4881
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1424]                 ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1420
LBB0_1954:                              ; %cond.store4885
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1421
LBB0_1955:                              ; %cond.store4889
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1422
	b	LBB0_1423
LBB0_1956:                              ; %cond.store4898
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3504]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1425
LBB0_1957:                              ; %cond.store4902
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1426
LBB0_1958:                              ; %cond.store4906
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	and.16b	v3, v3, v17
	tbz	w8, #3, LBB0_1427
LBB0_1959:                              ; %cond.store4910
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10496]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1428
LBB0_1960:                              ; %cond.store4914
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1376]                 ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1429
LBB0_1961:                              ; %cond.store4918
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1430
LBB0_1962:                              ; %cond.store4922
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1431
	b	LBB0_1432
LBB0_1963:                              ; %cond.store4931
	fmov	x9, d1
	str	s0, [x9]
	and.16b	v4, v7, v18
	tbz	w8, #1, LBB0_1434
LBB0_1964:                              ; %cond.store4935
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1435
LBB0_1965:                              ; %cond.store4939
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3488]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1436
LBB0_1966:                              ; %cond.store4943
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10528]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1437
LBB0_1967:                              ; %cond.store4947
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1328]                 ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1438
LBB0_1968:                              ; %cond.store4951
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1439
LBB0_1969:                              ; %cond.store4955
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1440
	b	LBB0_1441
LBB0_1970:                              ; %cond.store4964
	fmov	x9, d1
	str	s0, [x9]
	and.16b	v4, v7, v5
	tbz	w8, #1, LBB0_1443
LBB0_1971:                              ; %cond.store4968
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1444
LBB0_1972:                              ; %cond.store4972
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3472]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1445
LBB0_1973:                              ; %cond.store4976
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10560]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1446
LBB0_1974:                              ; %cond.store4980
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1280]                 ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1447
LBB0_1975:                              ; %cond.store4984
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1448
LBB0_1976:                              ; %cond.store4988
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1449
	b	LBB0_1450
LBB0_1977:                              ; %cond.store4997
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3456]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1452
LBB0_1978:                              ; %cond.store5001
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1453
LBB0_1979:                              ; %cond.store5005
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3440]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1454
LBB0_1980:                              ; %cond.store5009
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10592]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1455
LBB0_1981:                              ; %cond.store5013
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1248]                 ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1456
LBB0_1982:                              ; %cond.store5017
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1457
LBB0_1983:                              ; %cond.store5021
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1458
	b	LBB0_1459
LBB0_1984:                              ; %cond.store5030
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3424]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1461
LBB0_1985:                              ; %cond.store5034
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1462
LBB0_1986:                              ; %cond.store5038
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3408]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1463
LBB0_1987:                              ; %cond.store5042
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10624]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1464
LBB0_1988:                              ; %cond.store5046
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1216]                 ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1465
LBB0_1989:                              ; %cond.store5050
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1466
LBB0_1990:                              ; %cond.store5054
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1467
	b	LBB0_1468
LBB0_1991:                              ; %cond.store5063
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3392]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1470
LBB0_1992:                              ; %cond.store5067
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1471
LBB0_1993:                              ; %cond.store5071
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3376]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1472
LBB0_1994:                              ; %cond.store5075
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10656]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1473
LBB0_1995:                              ; %cond.store5079
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1184]                 ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1474
LBB0_1996:                              ; %cond.store5083
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1475
LBB0_1997:                              ; %cond.store5087
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1476
	b	LBB0_1477
LBB0_1998:                              ; %cond.store5096
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3360]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1479
LBB0_1999:                              ; %cond.store5100
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1480
LBB0_2000:                              ; %cond.store5104
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3344]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1481
LBB0_2001:                              ; %cond.store5108
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10688]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1482
LBB0_2002:                              ; %cond.store5112
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1152]                 ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1483
LBB0_2003:                              ; %cond.store5116
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1484
LBB0_2004:                              ; %cond.store5120
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1485
	b	LBB0_1486
LBB0_2005:                              ; %cond.store5129
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3328]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1488
LBB0_2006:                              ; %cond.store5133
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1489
LBB0_2007:                              ; %cond.store5137
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3312]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1490
LBB0_2008:                              ; %cond.store5141
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10720]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1491
LBB0_2009:                              ; %cond.store5145
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1120]                 ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1492
LBB0_2010:                              ; %cond.store5149
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1493
LBB0_2011:                              ; %cond.store5153
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1494
	b	LBB0_1495
LBB0_2012:                              ; %cond.store5162
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3296]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1497
LBB0_2013:                              ; %cond.store5166
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1498
LBB0_2014:                              ; %cond.store5170
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3280]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1499
LBB0_2015:                              ; %cond.store5174
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10752]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1500
LBB0_2016:                              ; %cond.store5178
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1088]                 ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1501
LBB0_2017:                              ; %cond.store5182
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1502
LBB0_2018:                              ; %cond.store5186
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1503
	b	LBB0_1504
LBB0_2019:                              ; %cond.store5195
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3264]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1506
LBB0_2020:                              ; %cond.store5199
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1507
LBB0_2021:                              ; %cond.store5203
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3248]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1508
LBB0_2022:                              ; %cond.store5207
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10784]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1509
LBB0_2023:                              ; %cond.store5211
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1056]                 ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1510
LBB0_2024:                              ; %cond.store5215
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1511
LBB0_2025:                              ; %cond.store5219
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1512
	b	LBB0_1513
LBB0_2026:                              ; %cond.store5228
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3232]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1515
LBB0_2027:                              ; %cond.store5232
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1516
LBB0_2028:                              ; %cond.store5236
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3216]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1517
LBB0_2029:                              ; %cond.store5240
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10816]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1518
LBB0_2030:                              ; %cond.store5244
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #1024]                 ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1519
LBB0_2031:                              ; %cond.store5248
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1520
LBB0_2032:                              ; %cond.store5252
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1521
	b	LBB0_1522
LBB0_2033:                              ; %cond.store5261
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3200]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1524
LBB0_2034:                              ; %cond.store5265
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1525
LBB0_2035:                              ; %cond.store5269
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3184]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1526
LBB0_2036:                              ; %cond.store5273
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10848]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1527
LBB0_2037:                              ; %cond.store5277
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #992]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1528
LBB0_2038:                              ; %cond.store5281
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1529
LBB0_2039:                              ; %cond.store5285
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1530
	b	LBB0_1531
LBB0_2040:                              ; %cond.store5294
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3168]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1533
LBB0_2041:                              ; %cond.store5298
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1534
LBB0_2042:                              ; %cond.store5302
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3152]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1535
LBB0_2043:                              ; %cond.store5306
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10880]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1536
LBB0_2044:                              ; %cond.store5310
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #960]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1537
LBB0_2045:                              ; %cond.store5314
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1538
LBB0_2046:                              ; %cond.store5318
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1539
	b	LBB0_1540
LBB0_2047:                              ; %cond.store5327
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3136]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1542
LBB0_2048:                              ; %cond.store5331
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1543
LBB0_2049:                              ; %cond.store5335
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3120]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1544
LBB0_2050:                              ; %cond.store5339
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10912]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1545
LBB0_2051:                              ; %cond.store5343
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #928]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1546
LBB0_2052:                              ; %cond.store5347
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1547
LBB0_2053:                              ; %cond.store5351
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1548
	b	LBB0_1549
LBB0_2054:                              ; %cond.store5360
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3104]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1551
LBB0_2055:                              ; %cond.store5364
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1552
LBB0_2056:                              ; %cond.store5368
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3088]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1553
LBB0_2057:                              ; %cond.store5372
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10944]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1554
LBB0_2058:                              ; %cond.store5376
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #896]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1555
LBB0_2059:                              ; %cond.store5380
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1556
LBB0_2060:                              ; %cond.store5384
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1557
	b	LBB0_1558
LBB0_2061:                              ; %cond.store5393
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3072]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1560
LBB0_2062:                              ; %cond.store5397
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1561
LBB0_2063:                              ; %cond.store5401
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3056]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1562
LBB0_2064:                              ; %cond.store5405
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #10976]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1563
LBB0_2065:                              ; %cond.store5409
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #864]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1564
LBB0_2066:                              ; %cond.store5413
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1565
LBB0_2067:                              ; %cond.store5417
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1566
	b	LBB0_1567
LBB0_2068:                              ; %cond.store5426
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3040]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1569
LBB0_2069:                              ; %cond.store5430
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1570
LBB0_2070:                              ; %cond.store5434
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #3024]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1571
LBB0_2071:                              ; %cond.store5438
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11008]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1572
LBB0_2072:                              ; %cond.store5442
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #832]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1573
LBB0_2073:                              ; %cond.store5446
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1574
LBB0_2074:                              ; %cond.store5450
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1575
	b	LBB0_1576
LBB0_2075:                              ; %cond.store5459
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #3008]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1578
LBB0_2076:                              ; %cond.store5463
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1579
LBB0_2077:                              ; %cond.store5467
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #2992]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1580
LBB0_2078:                              ; %cond.store5471
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11040]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1581
LBB0_2079:                              ; %cond.store5475
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #800]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1582
LBB0_2080:                              ; %cond.store5479
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1583
LBB0_2081:                              ; %cond.store5483
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1584
	b	LBB0_1585
LBB0_2082:                              ; %cond.store5492
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2976]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1587
LBB0_2083:                              ; %cond.store5496
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1588
LBB0_2084:                              ; %cond.store5500
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #2960]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1589
LBB0_2085:                              ; %cond.store5504
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11072]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1590
LBB0_2086:                              ; %cond.store5508
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #768]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1591
LBB0_2087:                              ; %cond.store5512
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1592
LBB0_2088:                              ; %cond.store5516
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1593
	b	LBB0_1594
LBB0_2089:                              ; %cond.store5525
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2944]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1596
LBB0_2090:                              ; %cond.store5529
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1597
LBB0_2091:                              ; %cond.store5533
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #2928]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1598
LBB0_2092:                              ; %cond.store5537
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11104]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1599
LBB0_2093:                              ; %cond.store5541
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #736]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1600
LBB0_2094:                              ; %cond.store5545
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1601
LBB0_2095:                              ; %cond.store5549
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1602
	b	LBB0_1603
LBB0_2096:                              ; %cond.store5558
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2912]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1605
LBB0_2097:                              ; %cond.store5562
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1606
LBB0_2098:                              ; %cond.store5566
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #2896]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1607
LBB0_2099:                              ; %cond.store5570
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11136]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1608
LBB0_2100:                              ; %cond.store5574
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #704]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1609
LBB0_2101:                              ; %cond.store5578
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1610
LBB0_2102:                              ; %cond.store5582
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1611
	b	LBB0_1612
LBB0_2103:                              ; %cond.store5591
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2880]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1614
LBB0_2104:                              ; %cond.store5595
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1615
LBB0_2105:                              ; %cond.store5599
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #2864]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1616
LBB0_2106:                              ; %cond.store5603
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11168]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1617
LBB0_2107:                              ; %cond.store5607
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #672]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1618
LBB0_2108:                              ; %cond.store5611
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1619
LBB0_2109:                              ; %cond.store5615
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1620
	b	LBB0_1621
LBB0_2110:                              ; %cond.store5624
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2848]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1623
LBB0_2111:                              ; %cond.store5628
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1624
LBB0_2112:                              ; %cond.store5632
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #2832]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1625
LBB0_2113:                              ; %cond.store5636
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11200]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1626
LBB0_2114:                              ; %cond.store5640
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #640]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1627
LBB0_2115:                              ; %cond.store5644
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1628
LBB0_2116:                              ; %cond.store5648
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1629
	b	LBB0_1630
LBB0_2117:                              ; %cond.store5657
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2816]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1632
LBB0_2118:                              ; %cond.store5661
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1633
LBB0_2119:                              ; %cond.store5665
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #2800]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1634
LBB0_2120:                              ; %cond.store5669
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11232]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1635
LBB0_2121:                              ; %cond.store5673
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #608]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1636
LBB0_2122:                              ; %cond.store5677
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1637
LBB0_2123:                              ; %cond.store5681
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1638
	b	LBB0_1639
LBB0_2124:                              ; %cond.store5690
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2784]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1641
LBB0_2125:                              ; %cond.store5694
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1642
LBB0_2126:                              ; %cond.store5698
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #2768]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1643
LBB0_2127:                              ; %cond.store5702
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11264]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1644
LBB0_2128:                              ; %cond.store5706
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #576]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1645
LBB0_2129:                              ; %cond.store5710
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1646
LBB0_2130:                              ; %cond.store5714
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1647
	b	LBB0_1648
LBB0_2131:                              ; %cond.store5723
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2752]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1650
LBB0_2132:                              ; %cond.store5727
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1651
LBB0_2133:                              ; %cond.store5731
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #2736]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1652
LBB0_2134:                              ; %cond.store5735
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11296]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1653
LBB0_2135:                              ; %cond.store5739
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #544]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1654
LBB0_2136:                              ; %cond.store5743
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1655
LBB0_2137:                              ; %cond.store5747
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1656
	b	LBB0_1657
LBB0_2138:                              ; %cond.store5756
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2720]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1659
LBB0_2139:                              ; %cond.store5760
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1660
LBB0_2140:                              ; %cond.store5764
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #2704]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1661
LBB0_2141:                              ; %cond.store5768
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11328]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1662
LBB0_2142:                              ; %cond.store5772
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #512]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1663
LBB0_2143:                              ; %cond.store5776
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1664
LBB0_2144:                              ; %cond.store5780
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1665
	b	LBB0_1666
LBB0_2145:                              ; %cond.store5789
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2688]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1668
LBB0_2146:                              ; %cond.store5793
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1669
LBB0_2147:                              ; %cond.store5797
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #2672]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1670
LBB0_2148:                              ; %cond.store5801
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11360]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1671
LBB0_2149:                              ; %cond.store5805
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #480]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1672
LBB0_2150:                              ; %cond.store5809
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1673
LBB0_2151:                              ; %cond.store5813
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1674
	b	LBB0_1675
LBB0_2152:                              ; %cond.store5822
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2656]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1677
LBB0_2153:                              ; %cond.store5826
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1678
LBB0_2154:                              ; %cond.store5830
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #2640]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1679
LBB0_2155:                              ; %cond.store5834
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11392]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1680
LBB0_2156:                              ; %cond.store5838
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #448]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1681
LBB0_2157:                              ; %cond.store5842
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1682
LBB0_2158:                              ; %cond.store5846
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1683
	b	LBB0_1684
LBB0_2159:                              ; %cond.store5855
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2624]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1686
LBB0_2160:                              ; %cond.store5859
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1687
LBB0_2161:                              ; %cond.store5863
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #2608]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1688
LBB0_2162:                              ; %cond.store5867
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11424]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1689
LBB0_2163:                              ; %cond.store5871
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #416]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1690
LBB0_2164:                              ; %cond.store5875
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1691
LBB0_2165:                              ; %cond.store5879
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1692
	b	LBB0_1693
LBB0_2166:                              ; %cond.store5888
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2592]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1695
LBB0_2167:                              ; %cond.store5892
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1696
LBB0_2168:                              ; %cond.store5896
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #2576]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1697
LBB0_2169:                              ; %cond.store5900
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11456]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1698
LBB0_2170:                              ; %cond.store5904
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #384]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1699
LBB0_2171:                              ; %cond.store5908
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1700
LBB0_2172:                              ; %cond.store5912
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1701
	b	LBB0_1702
LBB0_2173:                              ; %cond.store5921
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2560]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1704
LBB0_2174:                              ; %cond.store5925
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1705
LBB0_2175:                              ; %cond.store5929
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #2544]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1706
LBB0_2176:                              ; %cond.store5933
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11488]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1707
LBB0_2177:                              ; %cond.store5937
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #352]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1708
LBB0_2178:                              ; %cond.store5941
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1709
LBB0_2179:                              ; %cond.store5945
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1710
	b	LBB0_1711
LBB0_2180:                              ; %cond.store5954
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2528]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1713
LBB0_2181:                              ; %cond.store5958
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1714
LBB0_2182:                              ; %cond.store5962
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #2512]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1715
LBB0_2183:                              ; %cond.store5966
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11520]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1716
LBB0_2184:                              ; %cond.store5970
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #320]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1717
LBB0_2185:                              ; %cond.store5974
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1718
LBB0_2186:                              ; %cond.store5978
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1719
	b	LBB0_1720
LBB0_2187:                              ; %cond.store5987
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2496]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1722
LBB0_2188:                              ; %cond.store5991
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1723
LBB0_2189:                              ; %cond.store5995
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #2480]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1724
LBB0_2190:                              ; %cond.store5999
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11552]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1725
LBB0_2191:                              ; %cond.store6003
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #288]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1726
LBB0_2192:                              ; %cond.store6007
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1727
LBB0_2193:                              ; %cond.store6011
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1728
	b	LBB0_1729
LBB0_2194:                              ; %cond.store6020
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2464]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1731
LBB0_2195:                              ; %cond.store6024
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1732
LBB0_2196:                              ; %cond.store6028
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #2448]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1733
LBB0_2197:                              ; %cond.store6032
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11584]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1734
LBB0_2198:                              ; %cond.store6036
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #256]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1735
LBB0_2199:                              ; %cond.store6040
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1736
LBB0_2200:                              ; %cond.store6044
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1737
	b	LBB0_1738
LBB0_2201:                              ; %cond.store6053
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2432]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1740
LBB0_2202:                              ; %cond.store6057
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1741
LBB0_2203:                              ; %cond.store6061
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #2416]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1742
LBB0_2204:                              ; %cond.store6065
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11616]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1743
LBB0_2205:                              ; %cond.store6069
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #224]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1744
LBB0_2206:                              ; %cond.store6073
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1745
LBB0_2207:                              ; %cond.store6077
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1746
	b	LBB0_1747
LBB0_2208:                              ; %cond.store6086
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2400]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1749
LBB0_2209:                              ; %cond.store6090
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1750
LBB0_2210:                              ; %cond.store6094
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #2384]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1751
LBB0_2211:                              ; %cond.store6098
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11648]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1752
LBB0_2212:                              ; %cond.store6102
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #192]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1753
LBB0_2213:                              ; %cond.store6106
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1754
LBB0_2214:                              ; %cond.store6110
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1755
	b	LBB0_1756
LBB0_2215:                              ; %cond.store6119
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2368]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1758
LBB0_2216:                              ; %cond.store6123
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1759
LBB0_2217:                              ; %cond.store6127
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #2352]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1760
LBB0_2218:                              ; %cond.store6131
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11680]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1761
LBB0_2219:                              ; %cond.store6135
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #160]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1762
LBB0_2220:                              ; %cond.store6139
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1763
LBB0_2221:                              ; %cond.store6143
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1764
	b	LBB0_1765
LBB0_2222:                              ; %cond.store6152
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2336]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1767
LBB0_2223:                              ; %cond.store6156
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1768
LBB0_2224:                              ; %cond.store6160
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #2320]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1769
LBB0_2225:                              ; %cond.store6164
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11712]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1770
LBB0_2226:                              ; %cond.store6168
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #128]                  ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1771
LBB0_2227:                              ; %cond.store6172
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1772
LBB0_2228:                              ; %cond.store6176
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1773
	b	LBB0_1774
LBB0_2229:                              ; %cond.store6185
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2304]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1776
LBB0_2230:                              ; %cond.store6189
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1777
LBB0_2231:                              ; %cond.store6193
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #2288]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1778
LBB0_2232:                              ; %cond.store6197
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11744]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1779
LBB0_2233:                              ; %cond.store6201
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #96]                   ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1780
LBB0_2234:                              ; %cond.store6205
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1781
LBB0_2235:                              ; %cond.store6209
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1782
	b	LBB0_1783
LBB0_2236:                              ; %cond.store6218
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2272]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1785
LBB0_2237:                              ; %cond.store6222
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1786
LBB0_2238:                              ; %cond.store6226
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #2256]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1787
LBB0_2239:                              ; %cond.store6230
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11776]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1788
LBB0_2240:                              ; %cond.store6234
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #64]                   ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1789
LBB0_2241:                              ; %cond.store6238
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1790
LBB0_2242:                              ; %cond.store6242
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1791
	b	LBB0_1792
LBB0_2243:                              ; %cond.store6251
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #2240]                 ; 16-byte Reload
	and.16b	v4, v7, v3
	tbz	w8, #1, LBB0_1794
LBB0_2244:                              ; %cond.store6255
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	sshll.2d	v3, v15, #0
	add.2d	v1, v2, v4
	tbz	w8, #2, LBB0_1795
LBB0_2245:                              ; %cond.store6259
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	ldr	q4, [sp, #2224]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	tbz	w8, #3, LBB0_1796
LBB0_2246:                              ; %cond.store6263
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #11808]                ; 16-byte Reload
	fdiv.4s	v0, v0, v22
	add.2d	v1, v2, v3
	tbz	w8, #4, LBB0_1797
LBB0_2247:                              ; %cond.store6267
	fmov	x9, d1
	str	s0, [x9]
	ldr	q3, [sp, #32]                   ; 16-byte Reload
	and.16b	v3, v6, v3
	tbz	w8, #5, LBB0_1798
LBB0_2248:                              ; %cond.store6271
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1799
LBB0_2249:                              ; %cond.store6275
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1800
	b	LBB0_1801
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
                                        ; -- End function
	.globl	_llm_attention.packet_batch.blocks ; -- Begin function llm_attention.packet_batch.blocks
	.p2align	2
_llm_attention.packet_batch.blocks:     ; @llm_attention.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_3:                                 ; %llm_attention.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

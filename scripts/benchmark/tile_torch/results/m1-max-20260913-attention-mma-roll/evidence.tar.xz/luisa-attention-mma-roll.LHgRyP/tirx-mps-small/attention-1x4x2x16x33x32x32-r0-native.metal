// Function: llm_attention_kernel
#include <metal_stdlib>
using namespace metal;

union __TVMArgUnion {
 int v_int[2];
};

kernel void llm_attention_kernel(  device float* arg0_ptr [[ buffer(0) ]],
  device float* arg1_ptr [[ buffer(1) ]],
  device float* arg2_ptr [[ buffer(2) ]],
  device float* arg3_ptr [[ buffer(3) ]],
  uint blockIdx [[threadgroup_position_in_grid]],
  uint threadIdx [[thread_position_in_threadgroup]]
) {
  threadgroup float tile_storage_5_shared[4];
  if (((int)threadIdx) < 4) {
    tile_storage_5_shared[((int)threadIdx)] = -1.000000e+30f;
  }
  threadgroup float tile_storage_9_shared[4];
  if (((int)threadIdx) < 4) {
    tile_storage_9_shared[((int)threadIdx)] = 0.000000e+00f;
  }
  threadgroup float tile_storage_13_shared[128];
  tile_storage_13_shared[((int)threadIdx)] = 0.000000e+00f;
  metal::threadgroup_barrier(metal::mem_flags(3));
  long cse_v1 = (((long)blockIdx) * (long)128);
  long cse_v2 = ((long)((int)threadIdx));
  int cse_v8 = (((int)threadIdx) >> 5);
  for (long pipeline_10 = (long)0; pipeline_10 < (long)3; ++pipeline_10) {
    threadgroup float tile_storage_28_shared[64];
    threadgroup long tile_storage_34_shared[16];
    threadgroup long tile_storage_36_shared[16];
    threadgroup long tile_storage_38_shared[4];
    threadgroup bool tile_storage_40_shared[64];
    threadgroup float tile_storage_43_shared[64];
    threadgroup float tile_storage_48_shared[4];
    threadgroup float tile_storage_54_shared[4];
    threadgroup float tile_storage_58_shared[4];
    threadgroup float tile_storage_62_shared[64];
    threadgroup float tile_storage_67_shared[4];
    threadgroup float tile_storage_73_shared[128];
    threadgroup float tile_storage_85_shared[4];
    long cse_v4 = (pipeline_10 * (long)16);
    long cse_v14 = ((((((long)blockIdx) >> (long)2) / (long)2) * (long)1056) + (pipeline_10 * (long)512));
    if (((int)threadIdx) < 64) {
      tile_storage_28_shared[((int)threadIdx)] = 0.000000e+00f;
      for (int tile_i_33 = 0; tile_i_33 < 32; ++tile_i_33) {
        long cse_v3 = ((long)tile_i_33);
        long cse_v10 = (((long)((int)threadIdx)) & (long)15);
        float condval;
        if ((((pipeline_10 * (long)16) + (((long)((int)threadIdx)) & (long)15)) < (long)33)) {
          condval = arg1_ptr[((((((((long)blockIdx) >> (long)2) / (long)2) * (long)1056) + (pipeline_10 * (long)512)) + ((((long)((int)threadIdx)) & (long)15) * (long)32)) + ((long)tile_i_33))];
        } else {
          condval = 0.000000e+00f;
        }
        tile_storage_28_shared[((int)threadIdx)] = (tile_storage_28_shared[((int)threadIdx)] + (arg0_ptr[(((((long)blockIdx) * (long)128) + ((((long)((int)threadIdx)) >> (long)4) * (long)32)) + ((long)tile_i_33))] * condval));
      }
    }
    if (((int)threadIdx) < 16) {
      tile_storage_34_shared[((int)threadIdx)] = ((long)((int)threadIdx));
    }
    if (((int)threadIdx) < 16) {
      tile_storage_36_shared[((int)threadIdx)] = ((long)((int)threadIdx));
    }
    if (((int)threadIdx) < 4) {
      tile_storage_38_shared[((int)threadIdx)] = ((long)((int)threadIdx));
    }
    metal::threadgroup_barrier(metal::mem_flags(3));
    if (((int)threadIdx) < 64) {
      int cse_v5 = (((int)threadIdx) >> 2);
      tile_storage_40_shared[((int)threadIdx)] = ((((pipeline_10 * (long)16) + tile_storage_34_shared[(((int)threadIdx) >> 2)]) < (long)33) && (((pipeline_10 * (long)16) + tile_storage_36_shared[(((int)threadIdx) >> 2)]) <= ((((((long)blockIdx) & (long)3) * (long)4) + tile_storage_38_shared[(((int)threadIdx) & 3)]) + (long)17)));
    }
    metal::threadgroup_barrier(metal::mem_flags(3));
    int cse_v6 = (((int)threadIdx) >> 4);
    int cse_v12 = (((((int)threadIdx) & 15) * 4) + (((int)threadIdx) >> 4));
    if (((int)threadIdx) < 64) {
      float condval_1;
      if (tile_storage_40_shared[(((((int)threadIdx) & 15) * 4) + (((int)threadIdx) >> 4))]) {
        condval_1 = (tile_storage_28_shared[((int)threadIdx)] * 1.767767e-01f);
      } else {
        condval_1 = -1.000000e+30f;
      }
      tile_storage_43_shared[((int)threadIdx)] = condval_1;
    }
    metal::threadgroup_barrier(metal::mem_flags(3));
    thread float n_55_0_lane_carry[1];
    n_55_0_lane_carry[0] = -INFINITY;
    int cse_v7 = (((int)threadIdx) & 31);
    int cse_v11 = ((((int)threadIdx) >> 5) * 16);
    int cse_v13 = (((((int)threadIdx) >> 5) * 16) + (((int)threadIdx) & 31));
    if ((((int)threadIdx) & 31) < 16) {
      n_55_0_lane_carry[0] = max(n_55_0_lane_carry[0], tile_storage_43_shared[(((((int)threadIdx) >> 5) * 16) + (((int)threadIdx) & 31))]);
    }
    float n_55_0_subgroup_value = simd_max(n_55_0_lane_carry[0]);
    if ((((int)threadIdx) % 32) == 0) {
      tile_storage_48_shared[(((int)threadIdx) >> 5)] = n_55_0_subgroup_value;
    }
    metal::threadgroup_barrier(metal::mem_flags(3));
    if (((int)threadIdx) < 4) {
      tile_storage_54_shared[((int)threadIdx)] = max(tile_storage_5_shared[((int)threadIdx)], tile_storage_48_shared[((int)threadIdx)]);
    }
    metal::threadgroup_barrier(metal::mem_flags(3));
    if (((int)threadIdx) < 4) {
      tile_storage_58_shared[((int)threadIdx)] = exp((tile_storage_5_shared[((int)threadIdx)] - tile_storage_54_shared[((int)threadIdx)]));
    }
    metal::threadgroup_barrier(metal::mem_flags(3));
    if (((int)threadIdx) < 64) {
      float condval_2;
      if (tile_storage_40_shared[(((((int)threadIdx) & 15) * 4) + (((int)threadIdx) >> 4))]) {
        condval_2 = exp((tile_storage_43_shared[((int)threadIdx)] - tile_storage_54_shared[(((int)threadIdx) >> 4)]));
      } else {
        condval_2 = 0.000000e+00f;
      }
      tile_storage_62_shared[((int)threadIdx)] = condval_2;
    }
    metal::threadgroup_barrier(metal::mem_flags(3));
    thread float n_87_0_lane_carry[1];
    n_87_0_lane_carry[0] = 0.000000e+00f;
    if ((((int)threadIdx) & 31) < 16) {
      n_87_0_lane_carry[0] = (n_87_0_lane_carry[0] + tile_storage_62_shared[(((((int)threadIdx) >> 5) * 16) + (((int)threadIdx) & 31))]);
    }
    float n_87_0_subgroup_value = simd_sum(n_87_0_lane_carry[0]);
    if ((((int)threadIdx) % 32) == 0) {
      tile_storage_67_shared[(((int)threadIdx) >> 5)] = n_87_0_subgroup_value;
    }
    metal::threadgroup_barrier(metal::mem_flags(3));
    tile_storage_73_shared[((int)threadIdx)] = (tile_storage_13_shared[((int)threadIdx)] * tile_storage_58_shared[(((int)threadIdx) >> 5)]);
    for (int tile_i_78 = 0; tile_i_78 < 16; ++tile_i_78) {
      long cse_v9 = ((long)tile_i_78);
      float condval_3;
      if ((((pipeline_10 * (long)16) + ((long)tile_i_78)) < (long)33)) {
        condval_3 = arg2_ptr[((((((((long)blockIdx) >> (long)2) / (long)2) * (long)1056) + (pipeline_10 * (long)512)) + (((long)tile_i_78) * (long)32)) + (((long)((int)threadIdx)) & (long)31))];
      } else {
        condval_3 = 0.000000e+00f;
      }
      tile_storage_73_shared[((int)threadIdx)] = (tile_storage_73_shared[((int)threadIdx)] + (tile_storage_62_shared[(((((int)threadIdx) >> 5) * 16) + tile_i_78)] * condval_3));
    }
    if (((int)threadIdx) < 4) {
      tile_storage_85_shared[((int)threadIdx)] = ((tile_storage_9_shared[((int)threadIdx)] * tile_storage_58_shared[((int)threadIdx)]) + tile_storage_67_shared[((int)threadIdx)]);
    }
    if (((int)threadIdx) < 4) {
      tile_storage_5_shared[((int)threadIdx)] = tile_storage_54_shared[((int)threadIdx)];
    }
    metal::threadgroup_barrier(metal::mem_flags(3));
    if (((int)threadIdx) < 4) {
      tile_storage_9_shared[((int)threadIdx)] = tile_storage_85_shared[((int)threadIdx)];
    }
    tile_storage_13_shared[((int)threadIdx)] = tile_storage_73_shared[((int)threadIdx)];
    metal::threadgroup_barrier(metal::mem_flags(3));
  }
  arg3_ptr[((((long)blockIdx) * (long)128) + ((long)((int)threadIdx)))] = (tile_storage_13_shared[((int)threadIdx)] / tile_storage_9_shared[(((int)threadIdx) >> 5)]);
  metal::threadgroup_barrier(metal::mem_flags(3));
}



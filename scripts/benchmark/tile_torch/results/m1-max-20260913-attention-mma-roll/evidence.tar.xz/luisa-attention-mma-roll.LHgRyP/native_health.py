"""Small existing Tile workloads after MPS preflight; no performance claim."""
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path('/Users/mike/CLionProjects/luisa')
OUT = Path(__file__).resolve().parent / 'native-health'
BUILD = Path('/tmp/luisa-next-integration.roZbN8/build')
sys.path.insert(0, str(ROOT / 'scripts/benchmark/tile_torch'))
from compare_llm import capture_benchmark

OUT.mkdir(exist_ok=False)
records = []
for op, dims, block in [('gelu_residual', '2,17', (1, 1)),
                         ('attention', '1,2,2,5,5,5,3', (2, 3))]:
    name = op + '-metal4'
    folder = OUT / name
    folder.mkdir()
    prefix = folder / 'output.f32'
    env = {k: v for k, v in os.environ.items() if not k.startswith(('LUISA_', 'MTL_'))}
    env.update(LUISA_TILE_BENCH_XIR_BACKEND='metal4', LUISA_TILE_BENCH_DUMP_SOURCE=str(prefix)+'.source.txt')
    command = [str(BUILD / 'bin/benchmark_tile_xir'), 'llm', op, dims, *map(str, block), '3', '1', '1', str(prefix)]
    row = dict(name=name, command=command, started=time.time(),
               environment={k: v for k, v in env.items() if k.startswith('LUISA_')})
    records.append(row)
    try:
        result = capture_benchmark(command, env, 30, folder, 'capture', row)
        data = json.loads(result.stdout)
        if data.get('correctness', {}).get('checks') != 2:
            raise ValueError('missing complete correctness checks')
        row.update(status='pass', metadata=data)
    except Exception as error:
        row.update(status='failed', error=str(error))
        (OUT / 'health.json').write_text(json.dumps(records, indent=2) + '\n')
        raise
    row['finished'] = time.time()
    (OUT / 'health.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, row['status'], flush=True)


/private/tmp/luisa-expression-fusion.qXgTbC/capture/swiglu-17x65/on/object/tile_xir_w8_23416_1788930268184903_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d11, d10, [sp, #-0x30]!
       4:      	stp	d9, d8, [sp, #0x10]
       8:      	stp	x28, x27, [sp, #0x20]
       c:      	sub	sp, sp, #0x240
      10:      	mov	x10, #0x0               ; =0
      14:      	ldr	x13, [x0]
      18:      	ldr	x11, [x0, #0x10]
      1c:      	ldr	x8, [x0, #0x30]
      20:      	ldr	w9, [x1]
      24:      	ldr	w12, [x1, #0x24]
      28:      	add	w9, w12, w9, lsl #5
      2c:      	lsr	w9, w9, #3
      30:      	fmov	s0, w9
      34:      	ushll.2d	v0, v0, #0x0
      38:      	fmov	x9, d0
      3c:      	add	x9, x9, x9, lsl #6
      40:      	lsl	x12, x9, #2
      44:      	add	x9, x13, x12
      48:      	ldp	q0, q1, [x9, #0xc0]
      4c:      	stp	q0, q1, [sp, #0x1e0]
      50:      	ldp	q0, q1, [x9, #0xe0]
      54:      	stp	q0, q1, [sp, #0x200]
      58:      	ldp	q0, q1, [x9, #0x80]
      5c:      	stp	q0, q1, [sp, #0x1a0]
      60:      	ldp	q0, q1, [x9, #0xa0]
      64:      	stp	q0, q1, [sp, #0x1c0]
      68:      	ldp	q0, q1, [x9, #0x40]
      6c:      	stp	q0, q1, [sp, #0x160]
      70:      	ldp	q0, q1, [x9, #0x60]
      74:      	stp	q0, q1, [sp, #0x180]
      78:      	ldp	q0, q1, [x9]
      7c:      	stp	q0, q1, [sp, #0x120]
      80:      	ldp	q0, q1, [x9, #0x20]
      84:      	stp	q0, q1, [sp, #0x140]
      88:      	add	x9, x12, #0x100
      8c:      	ldr	s0, [x13, x9]
      90:      	str	q0, [sp, #0x220]
      94:      	add	x13, x11, x12
      98:      	ldp	q1, q2, [x13, #0xc0]
      9c:      	stp	q1, q2, [sp, #0xc0]
      a0:      	ldp	q1, q2, [x13, #0xe0]
      a4:      	stp	q1, q2, [sp, #0xe0]
      a8:      	ldp	q1, q2, [x13, #0x80]
      ac:      	stp	q1, q2, [sp, #0x80]
      b0:      	ldp	q1, q2, [x13, #0xa0]
      b4:      	stp	q1, q2, [sp, #0xa0]
      b8:      	ldp	q1, q2, [x13, #0x40]
      bc:      	stp	q1, q2, [sp, #0x40]
      c0:      	ldp	q1, q2, [x13, #0x60]
      c4:      	stp	q1, q2, [sp, #0x60]
      c8:      	ldp	q2, q22, [x13]
      cc:      	ldp	q23, q24, [x13, #0x20]
      d0:      	ldr	s1, [x11, x9]
      d4:      	add	x11, x8, x12
      d8:      	mov	w12, #0x42d00000        ; =1120927744
      dc:      	dup.4s	v3, w12
      e0:      	mov	w12, #-0x3d380000       ; =-1027080192
      e4:      	dup.4s	v4, w12
      e8:      	mov	w12, #0xaa3b            ; =43579
      ec:      	movk	w12, #0x3fb8, lsl #16
      f0:      	dup.4s	v5, w12
      f4:      	add	x12, sp, #0x120
      f8:      	movi.4s	v6, #0x4b, lsl #24
      fc:      	mvni.4s	v7, #0x80, lsl #24
     100:      	mov	w13, #0x7200            ; =29184
     104:      	movk	w13, #0xbf31, lsl #16
     108:      	dup.4s	v16, w13
     10c:      	mov	w13, #0xbe8e            ; =48782
     110:      	movk	w13, #0xb5bf, lsl #16
     114:      	dup.4s	v17, w13
     118:      	mov	w13, #0x2bda            ; =11226
     11c:      	movk	w13, #0x3950, lsl #16
     120:      	dup.4s	v18, w13
     124:      	mov	w13, #0x96c9            ; =38601
     128:      	movk	w13, #0x3ab6, lsl #16
     12c:      	dup.4s	v19, w13
     130:      	mov	w13, #0x88a6            ; =34982
     134:      	movk	w13, #0x3c08, lsl #16
     138:      	dup.4s	v20, w13
     13c:      	mov	w13, #0xaa7a            ; =43642
     140:      	movk	w13, #0x3d2a, lsl #16
     144:      	dup.4s	v21, w13
     148:      	mov	w13, #0xaaab            ; =43691
     14c:      	movk	w13, #0x3e2a, lsl #16
     150:      	stp	q2, q22, [sp]
     154:      	movi.4s	v22, #0x3f, lsl #24
     158:      	fmov.4s	v2, #1.00000000
     15c:      	mvni.4s	v25, #0x7f, msl #16
     160:      	stp	q23, q24, [sp, #0x20]
     164:      	fneg.4s	v23, v25
     168:      	dup.4s	v24, w13
     16c:      	mvni.4s	v25, #0x3f, msl #16
     170:      	fneg.4s	v25, v25
     174:      	mov	x13, sp
     178:      	str	q1, [sp, #0x100]
     17c:      	add	x14, x12, x10
     180:      	ldp	q26, q27, [x14]
     184:      	fneg.4s	v28, v27
     188:      	fneg.4s	v29, v26
     18c:      	fcmge.4s	v30, v3, v26
     190:      	fcmge.4s	v31, v3, v27
     194:      	fcmge.4s	v8, v26, v4
     198:      	fcmge.4s	v9, v27, v4
     19c:      	and.16b	v31, v31, v9
     1a0:      	and.16b	v30, v30, v8
     1a4:      	and.16b	v29, v30, v29
     1a8:      	and.16b	v28, v31, v28
     1ac:      	fmul.4s	v30, v28, v5
     1b0:      	fmul.4s	v31, v29, v5
     1b4:      	mov.16b	v8, v7
     1b8:      	bsl.16b	v8, v6, v31
     1bc:      	mov.16b	v9, v7
     1c0:      	bsl.16b	v9, v6, v30
     1c4:      	fadd.4s	v30, v30, v9
     1c8:      	fadd.4s	v31, v31, v8
     1cc:      	fsub.4s	v31, v31, v8
     1d0:      	fsub.4s	v30, v30, v9
     1d4:      	fcvtzs.4s	v30, v30
     1d8:      	fcvtzs.4s	v31, v31
     1dc:      	scvtf.4s	v8, v31
     1e0:      	scvtf.4s	v9, v30
     1e4:      	fmul.4s	v10, v9, v16
     1e8:      	fmul.4s	v11, v8, v16
     1ec:      	fadd.4s	v29, v29, v11
     1f0:      	fadd.4s	v28, v28, v10
     1f4:      	fmul.4s	v8, v8, v17
     1f8:      	fmul.4s	v9, v9, v17
     1fc:      	fadd.4s	v28, v28, v9
     200:      	fadd.4s	v29, v29, v8
     204:      	fmul.4s	v8, v29, v18
     208:      	fmul.4s	v9, v28, v18
     20c:      	fadd.4s	v9, v9, v19
     210:      	fadd.4s	v8, v8, v19
     214:      	fmul.4s	v8, v29, v8
     218:      	fmul.4s	v9, v28, v9
     21c:      	fadd.4s	v9, v9, v20
     220:      	fadd.4s	v8, v8, v20
     224:      	fmul.4s	v8, v29, v8
     228:      	fmul.4s	v9, v28, v9
     22c:      	fadd.4s	v9, v9, v21
     230:      	fadd.4s	v8, v8, v21
     234:      	fmul.4s	v8, v29, v8
     238:      	fmul.4s	v9, v28, v9
     23c:      	fadd.4s	v9, v9, v24
     240:      	fadd.4s	v8, v8, v24
     244:      	fmul.4s	v8, v29, v8
     248:      	fmul.4s	v9, v28, v9
     24c:      	fadd.4s	v9, v9, v22
     250:      	fadd.4s	v8, v8, v22
     254:      	fmul.4s	v10, v28, v28
     258:      	fmul.4s	v11, v29, v29
     25c:      	fmul.4s	v8, v11, v8
     260:      	fmul.4s	v9, v10, v9
     264:      	fadd.4s	v28, v28, v9
     268:      	fadd.4s	v29, v29, v8
     26c:      	sshr.4s	v8, v31, #0x1
     270:      	fadd.4s	v29, v29, v2
     274:      	sshr.4s	v9, v30, #0x1
     278:      	shl.4s	v10, v9, #0x17
     27c:      	shl.4s	v11, v8, #0x17
     280:      	add.4s	v11, v11, v2
     284:      	add.4s	v10, v10, v2
     288:      	fadd.4s	v28, v28, v2
     28c:      	fmul.4s	v28, v28, v10
     290:      	sub.4s	v30, v30, v9
     294:      	sub.4s	v31, v31, v8
     298:      	shl.4s	v31, v31, #0x17
     29c:      	shl.4s	v30, v30, #0x17
     2a0:      	fmul.4s	v29, v29, v11
     2a4:      	add.4s	v30, v30, v2
     2a8:      	add.4s	v31, v31, v2
     2ac:      	fmul.4s	v29, v29, v31
     2b0:      	fmul.4s	v28, v28, v30
     2b4:      	fcmgt.4s	v30, v27, v3
     2b8:      	fcmgt.4s	v31, v26, v3
     2bc:      	fcmgt.4s	v8, v4, v26
     2c0:      	fcmgt.4s	v9, v4, v27
     2c4:      	fcmeq.4s	v10, v27, v27
     2c8:      	fadd.4s	v28, v28, v2
     2cc:      	fadd.4s	v29, v29, v2
     2d0:      	fcmeq.4s	v11, v26, v26
     2d4:      	bit.16b	v29, v2, v31
     2d8:      	bit.16b	v28, v2, v30
     2dc:      	bit.16b	v28, v23, v9
     2e0:      	bit.16b	v29, v23, v8
     2e4:      	bif.16b	v29, v25, v11
     2e8:      	bif.16b	v28, v25, v10
     2ec:      	fdiv.4s	v27, v27, v28
     2f0:      	fdiv.4s	v26, v26, v29
     2f4:      	add	x14, x13, x10
     2f8:      	ldp	q29, q28, [x14]
     2fc:      	fmul.4s	v26, v29, v26
     300:      	fmul.4s	v27, v28, v27
     304:      	add	x14, x11, x10
     308:      	stp	q26, q27, [x14]
     30c:      	add	x10, x10, #0x20
     310:      	cmp	x10, #0x100
     314:      	b.ne	0x17c <ltmp0+0x17c>
     318:      	movi.2d	v3, #0000000000000000
     31c:      	fneg.4s	v4, v0
     320:      	mov.s	v3[0], v4[0]
     324:      	mov	w10, #-0x3d300000       ; =-1026555904
     328:      	dup.4s	v4, w10
     32c:      	mov	w10, #0x42c80000        ; =1120403456
     330:      	dup.4s	v5, w10
     334:      	fcmge.4s	v6, v3, v4
     338:      	fcmge.4s	v7, v5, v3
     33c:      	and.16b	v6, v6, v7
     340:      	mov	w10, #0xaa3b            ; =43579
     344:      	movk	w10, #0x3fb8, lsl #16
     348:      	dup.4s	v7, w10
     34c:      	and.16b	v6, v6, v3
     350:      	fmul.4s	v7, v6, v7
     354:      	movi.4s	v16, #0x4b, lsl #24
     358:      	mvni.4s	v17, #0x80, lsl #24
     35c:      	bif.16b	v16, v7, v17
     360:      	fadd.4s	v7, v7, v16
     364:      	fsub.4s	v7, v7, v16
     368:      	fcvtzs.4s	v7, v7
     36c:      	scvtf.4s	v16, v7
     370:      	mov	w10, #0x7200            ; =29184
     374:      	movk	w10, #0xbf31, lsl #16
     378:      	dup.4s	v17, w10
     37c:      	fmul.4s	v17, v16, v17
     380:      	fadd.4s	v6, v6, v17
     384:      	mov	w10, #0xbe8e            ; =48782
     388:      	movk	w10, #0xb5bf, lsl #16
     38c:      	dup.4s	v17, w10
     390:      	fmul.4s	v16, v16, v17
     394:      	fadd.4s	v6, v6, v16
     398:      	mov	w10, #0x2bda            ; =11226
     39c:      	movk	w10, #0x3950, lsl #16
     3a0:      	dup.4s	v16, w10
     3a4:      	fmul.4s	v16, v6, v16
     3a8:      	mov	w10, #0x96c9            ; =38601
     3ac:      	movk	w10, #0x3ab6, lsl #16
     3b0:      	dup.4s	v17, w10
     3b4:      	fadd.4s	v16, v16, v17
     3b8:      	mov	w10, #0x88a6            ; =34982
     3bc:      	movk	w10, #0x3c08, lsl #16
     3c0:      	dup.4s	v17, w10
     3c4:      	fmul.4s	v16, v6, v16
     3c8:      	fadd.4s	v16, v16, v17
     3cc:      	fmul.4s	v16, v6, v16
     3d0:      	mov	w10, #0xaa7a            ; =43642
     3d4:      	movk	w10, #0x3d2a, lsl #16
     3d8:      	dup.4s	v17, w10
     3dc:      	fadd.4s	v16, v16, v17
     3e0:      	fmul.4s	v16, v6, v16
     3e4:      	mov	w10, #0xaaab            ; =43691
     3e8:      	movk	w10, #0x3e2a, lsl #16
     3ec:      	dup.4s	v17, w10
     3f0:      	fadd.4s	v16, v16, v17
     3f4:      	fmul.4s	v16, v6, v16
     3f8:      	movi.4s	v17, #0x3f, lsl #24
     3fc:      	fadd.4s	v16, v16, v17
     400:      	fmul.4s	v17, v6, v6
     404:      	fmul.4s	v16, v17, v16
     408:      	fadd.4s	v6, v6, v16
     40c:      	fadd.4s	v6, v6, v2
     410:      	sshr.4s	v16, v7, #0x1
     414:      	shl.4s	v17, v16, #0x17
     418:      	add.4s	v17, v17, v2
     41c:      	fmul.4s	v6, v6, v17
     420:      	sub.4s	v7, v7, v16
     424:      	shl.4s	v7, v7, #0x17
     428:      	add.4s	v7, v7, v2
     42c:      	fmul.4s	v6, v6, v7
     430:      	fcmgt.4s	v4, v4, v3
     434:      	fcmgt.4s	v5, v3, v5
     438:      	fcmeq.4s	v3, v3, v3
     43c:      	fadd.4s	v6, v6, v2
     440:      	bif.16b	v2, v6, v4
     444:      	mvni.4s	v4, #0x7f, msl #16
     448:      	fneg.4s	v4, v4
     44c:      	bit.16b	v2, v4, v5
     450:      	mvni.4s	v4, #0x3f, msl #16
     454:      	fneg.4s	v4, v4
     458:      	bif.16b	v2, v4, v3
     45c:      	fdiv.4s	v0, v0, v2
     460:      	fmul.4s	v0, v0, v1
     464:      	str	s0, [x8, x9]
     468:      	add	sp, sp, #0x240
     46c:      	ldp	x28, x27, [sp, #0x20]
     470:      	ldp	d9, d8, [sp, #0x10]
     474:      	ldp	d11, d10, [sp], #0x30
     478:      	ret

000000000000047c <_llm_rows.packet_batch.blocks>:
     47c:      	stp	d15, d14, [sp, #-0xa0]!
     480:      	stp	d13, d12, [sp, #0x10]
     484:      	stp	d11, d10, [sp, #0x20]
     488:      	stp	d9, d8, [sp, #0x30]
     48c:      	stp	x28, x27, [sp, #0x40]
     490:      	stp	x26, x25, [sp, #0x50]
     494:      	stp	x24, x23, [sp, #0x60]
     498:      	stp	x22, x21, [sp, #0x70]
     49c:      	stp	x20, x19, [sp, #0x80]
     4a0:      	stp	x29, x30, [sp, #0x90]
     4a4:      	sub	sp, sp, #0x410
     4a8:      	str	x0, [sp, #0xc8]
     4ac:      	cbz	w3, 0x1100 <_llm_rows.packet_batch.blocks+0xc84>
     4b0:      	mov	x19, x3
     4b4:      	mov	x20, x2
     4b8:      	mov	w22, #0x0               ; =0
     4bc:      	ldp	w9, w8, [x2, #0x2c]
     4c0:      	stp	w8, w9, [sp, #0xc0]
     4c4:      	add	x27, sp, #0x2f0
     4c8:      	ldp	w26, w25, [x2]
     4cc:      	adrp	x8, 0x0 <ltmp0>
     4d0:      	ldr	q0, [x8]
     4d4:      	str	q0, [sp, #0x30]
     4d8:      	adrp	x8, 0x0 <ltmp0>
     4dc:      	ldr	q0, [x8]
     4e0:      	str	q0, [sp, #0x20]
     4e4:      	adrp	x8, 0x0 <ltmp0>
     4e8:      	ldr	q0, [x8]
     4ec:      	str	q0, [sp, #0x10]
     4f0:      	movi.2s	v8, #0x41
     4f4:      	add	x28, sp, #0x1d0
     4f8:      	mvni.4s	v0, #0x7f, msl #16
     4fc:      	fneg.4s	v1, v0
     500:      	mvni.4s	v0, #0x3f, msl #16
     504:      	fneg.4s	v0, v0
     508:      	stp	q0, q1, [sp, #0xd0]
     50c:      	ldp	w21, w23, [x2, #0x8]
     510:      	mov	w30, #0xaa7a            ; =43642
     514:      	movk	w30, #0x3d2a, lsl #16
     518:      	str	w3, [sp, #0xbc]
     51c:      	b	0x564 <_llm_rows.packet_batch.blocks+0xe8>
     520:      	mov	w8, #0x18               ; =24
     524:      	str	w8, [x20, #0x24]
     528:      	ldr	w19, [sp, #0xbc]
     52c:      	add	w8, w26, #0x1
     530:      	ldp	w10, w9, [sp, #0xc0]
     534:      	cmp	w8, w9
     538:      	cset	w8, eq
     53c:      	csinc	w26, wzr, w26, eq
     540:      	cinc	w9, w25, eq
     544:      	cmp	w9, w10
     548:      	cset	w10, eq
     54c:      	ands	w8, w8, w10
     550:      	csel	w25, wzr, w9, ne
     554:      	add	w21, w21, w8
     558:      	add	w22, w22, #0x1
     55c:      	cmp	w22, w19
     560:      	b.eq	0x1100 <_llm_rows.packet_batch.blocks+0xc84>
     564:      	ubfiz	x8, x26, #5, #32
     568:      	cmp	x8, x23
     56c:      	csel	x9, x8, xzr, ls
     570:      	subs	x10, x23, x9
     574:      	cmp	x10, #0x20
     578:      	mov	w11, #0x20              ; =32
     57c:      	csel	x10, x10, x11, lo
     580:      	cmp	x23, x9
     584:      	stp	w26, w25, [x20]
     588:      	str	w21, [x20, #0x8]
     58c:      	str	wzr, [x20, #0x24]
     590:      	ccmp	x8, x23, #0x2, hi
     594:      	csel	x24, x10, xzr, ls
     598:      	cmp	x24, #0x20
     59c:      	b.lo	0x5f8 <_llm_rows.packet_batch.blocks+0x17c>
     5a0:      	ldr	x24, [sp, #0xc8]
     5a4:      	mov	x0, x24
     5a8:      	mov	x1, x20
     5ac:      	bl	0x5ac <_llm_rows.packet_batch.blocks+0x130>
     5b0:      	mov	w8, #0x8                ; =8
     5b4:      	str	w8, [x20, #0x24]
     5b8:      	mov	x0, x24
     5bc:      	mov	x1, x20
     5c0:      	bl	0x5c0 <_llm_rows.packet_batch.blocks+0x144>
     5c4:      	mov	w8, #0x10               ; =16
     5c8:      	str	w8, [x20, #0x24]
     5cc:      	mov	x0, x24
     5d0:      	mov	x1, x20
     5d4:      	bl	0x5d4 <_llm_rows.packet_batch.blocks+0x158>
     5d8:      	mov	w8, #0x18               ; =24
     5dc:      	str	w8, [x20, #0x24]
     5e0:      	mov	x0, x24
     5e4:      	mov	x1, x20
     5e8:      	bl	0x5e8 <_llm_rows.packet_batch.blocks+0x16c>
     5ec:      	mov	w30, #0xaa7a            ; =43642
     5f0:      	movk	w30, #0x3d2a, lsl #16
     5f4:      	b	0x52c <_llm_rows.packet_batch.blocks+0xb0>
     5f8:      	lsr	x19, x24, #3
     5fc:      	cmp	x24, #0x8
     600:      	b.lo	0x664 <_llm_rows.packet_batch.blocks+0x1e8>
     604:      	str	wzr, [x20, #0x24]
     608:      	ldr	x0, [sp, #0xc8]
     60c:      	mov	x1, x20
     610:      	bl	0x610 <_llm_rows.packet_batch.blocks+0x194>
     614:      	mov	w30, #0xaa7a            ; =43642
     618:      	movk	w30, #0x3d2a, lsl #16
     61c:      	cmp	x19, #0x1
     620:      	b.eq	0x664 <_llm_rows.packet_batch.blocks+0x1e8>
     624:      	mov	w8, #0x8                ; =8
     628:      	str	w8, [x20, #0x24]
     62c:      	ldr	x0, [sp, #0xc8]
     630:      	mov	x1, x20
     634:      	bl	0x634 <_llm_rows.packet_batch.blocks+0x1b8>
     638:      	mov	w30, #0xaa7a            ; =43642
     63c:      	movk	w30, #0x3d2a, lsl #16
     640:      	cmp	x19, #0x2
     644:      	b.eq	0x664 <_llm_rows.packet_batch.blocks+0x1e8>
     648:      	mov	w8, #0x10               ; =16
     64c:      	str	w8, [x20, #0x24]
     650:      	ldr	x0, [sp, #0xc8]
     654:      	mov	x1, x20
     658:      	bl	0x658 <_llm_rows.packet_batch.blocks+0x1dc>
     65c:      	mov	w30, #0xaa7a            ; =43642
     660:      	movk	w30, #0x3d2a, lsl #16
     664:      	and	w8, w24, #0x7
     668:      	mov	w24, #0xaaab            ; =43691
     66c:      	movk	w24, #0x3e2a, lsl #16
     670:      	cbz	w8, 0x520 <_llm_rows.packet_batch.blocks+0xa4>
     674:      	dup.4s	v1, w8
     678:      	ldp	q0, q2, [sp, #0x20]
     67c:      	cmhi.4s	v0, v1, v0
     680:      	cmhi.4s	v1, v1, v2
     684:      	uzp1.8h	v2, v1, v0
     688:      	umaxv.8h	h3, v2
     68c:      	fmov	w8, s3
     690:      	tbz	w8, #0x0, 0x520 <_llm_rows.packet_batch.blocks+0xa4>
     694:      	mov	x9, #0x0                ; =0
     698:      	ldr	x11, [sp, #0xc8]
     69c:      	ldr	x12, [x11]
     6a0:      	ldr	x10, [x11, #0x10]
     6a4:      	ubfiz	w8, w26, #2, #27
     6a8:      	orr	w8, w8, w19
     6ac:      	dup.4s	v3, w8
     6b0:      	ldr	x8, [x11, #0x30]
     6b4:      	and.16b	v4, v1, v3
     6b8:      	and.16b	v3, v0, v3
     6bc:      	ushll2.2d	v18, v3, #0x0
     6c0:      	ushll2.2d	v19, v4, #0x0
     6c4:      	ushll.2d	v20, v3, #0x0
     6c8:      	ushll.2d	v4, v4, #0x0
     6cc:      	fmov	x11, d4
     6d0:      	mov	w13, #0x104             ; =260
     6d4:      	umaddl	x11, w11, w13, x12
     6d8:      	ldr	q3, [sp, #0x10]
     6dc:      	and.16b	v2, v2, v3
     6e0:      	addv.8h	h2, v2
     6e4:      	fmov	w13, s2
     6e8:      	b	0x70c <_llm_rows.packet_batch.blocks+0x290>
     6ec:      	add	x14, x27, x9
     6f0:      	ldp	q6, q7, [x14]
     6f4:      	bif.16b	v5, v7, v0
     6f8:      	bif.16b	v3, v6, v1
     6fc:      	stp	q3, q5, [x14]
     700:      	add	x9, x9, #0x20
     704:      	cmp	x9, #0x100
     708:      	b.eq	0x7a0 <_llm_rows.packet_batch.blocks+0x324>
     70c:      	add	x14, x11, x9
     710:      	movi.2d	v3, #0000000000000000
     714:      	movi.2d	v5, #0000000000000000
     718:      	tbnz	w13, #0x0, 0x740 <_llm_rows.packet_batch.blocks+0x2c4>
     71c:      	and	w15, w13, #0xff
     720:      	tbnz	w15, #0x1, 0x74c <_llm_rows.packet_batch.blocks+0x2d0>
     724:      	tbnz	w15, #0x2, 0x758 <_llm_rows.packet_batch.blocks+0x2dc>
     728:      	tbnz	w15, #0x3, 0x764 <_llm_rows.packet_batch.blocks+0x2e8>
     72c:      	tbnz	w15, #0x4, 0x770 <_llm_rows.packet_batch.blocks+0x2f4>
     730:      	tbnz	w15, #0x5, 0x77c <_llm_rows.packet_batch.blocks+0x300>
     734:      	tbnz	w15, #0x6, 0x788 <_llm_rows.packet_batch.blocks+0x30c>
     738:      	tbz	w15, #0x7, 0x6ec <_llm_rows.packet_batch.blocks+0x270>
     73c:      	b	0x794 <_llm_rows.packet_batch.blocks+0x318>
     740:      	ldr	s3, [x14]
     744:      	and	w15, w13, #0xff
     748:      	tbz	w15, #0x1, 0x724 <_llm_rows.packet_batch.blocks+0x2a8>
     74c:      	add	x16, x14, #0x4
     750:      	ld1.s	{ v3 }[1], [x16]
     754:      	tbz	w15, #0x2, 0x728 <_llm_rows.packet_batch.blocks+0x2ac>
     758:      	add	x16, x14, #0x8
     75c:      	ld1.s	{ v3 }[2], [x16]
     760:      	tbz	w15, #0x3, 0x72c <_llm_rows.packet_batch.blocks+0x2b0>
     764:      	add	x16, x14, #0xc
     768:      	ld1.s	{ v3 }[3], [x16]
     76c:      	tbz	w15, #0x4, 0x730 <_llm_rows.packet_batch.blocks+0x2b4>
     770:      	add	x16, x14, #0x10
     774:      	ld1.s	{ v5 }[0], [x16]
     778:      	tbz	w15, #0x5, 0x734 <_llm_rows.packet_batch.blocks+0x2b8>
     77c:      	add	x16, x14, #0x14
     780:      	ld1.s	{ v5 }[1], [x16]
     784:      	tbz	w15, #0x6, 0x738 <_llm_rows.packet_batch.blocks+0x2bc>
     788:      	add	x16, x14, #0x18
     78c:      	ld1.s	{ v5 }[2], [x16]
     790:      	tbz	w15, #0x7, 0x6ec <_llm_rows.packet_batch.blocks+0x270>
     794:      	add	x14, x14, #0x1c
     798:      	ld1.s	{ v5 }[3], [x14]
     79c:      	b	0x6ec <_llm_rows.packet_batch.blocks+0x270>
     7a0:      	sshll.2d	v5, v1, #0x0
     7a4:      	xtn.4h	v3, v1
     7a8:      	uzp1.8b	v6, v3, v0
     7ac:      	movi.2d	v3, #0000000000000000
     7b0:      	mov.b	v3[0], v6[0]
     7b4:      	adrp	x9, 0x0 <ltmp0>
     7b8:      	ldr	d22, [x9]
     7bc:      	and.8b	v7, v3, v22
     7c0:      	addv.8b	b7, v7
     7c4:      	fmov	w13, s7
     7c8:      	umaxv.8b	b7, v3
     7cc:      	fmov	w14, s7
     7d0:      	rbit	w9, w13
     7d4:      	clz	w9, w9
     7d8:      	tst	w14, #0x1
     7dc:      	csel	w9, w9, wzr, ne
     7e0:      	mov	w11, #0x40              ; =64
     7e4:      	dup.2d	v17, x11
     7e8:      	adrp	x11, 0x0 <ltmp0>
     7ec:      	ldr	q7, [x11]
     7f0:      	bsl.16b	v5, v7, v17
     7f4:      	xtn.2s	v21, v4
     7f8:      	movi.2d	v4, #0000000000000000
     7fc:      	mov.b	v4[0], v6[0]
     800:      	umlal.2d	v5, v21, v8
     804:      	ushll.2d	v4, v4, #0x0
     808:      	shl.2d	v4, v4, #0x3f
     80c:      	cmlt.2d	v4, v4, #0
     810:      	str	q5, [sp, #0x90]
     814:      	and.16b	v4, v4, v5
     818:      	movi.2d	v5, #0000000000000000
     81c:      	stp	q5, q5, [sp, #0x1a0]
     820:      	stp	q4, q5, [sp, #0x180]
     824:      	and	x11, x9, #0x7
     828:      	add	x15, sp, #0x180
     82c:      	ldr	x11, [x15, x11, lsl #3]
     830:      	sub	x11, x11, x9
     834:      	lsl	x11, x11, #2
     838:      	add	x12, x12, x11
     83c:      	movi.2d	v4, #0000000000000000
     840:      	tbz	w14, #0x0, 0x848 <_llm_rows.packet_batch.blocks+0x3cc>
     844:      	ldr	s5, [x12]
     848:      	mov	w1, #-0x3d300000        ; =-1026555904
     84c:      	mov	w2, #0x42c80000         ; =1120403456
     850:      	mov	w3, #0xaa3b             ; =43579
     854:      	movk	w3, #0x3fb8, lsl #16
     858:      	mov	w4, #0x7200             ; =29184
     85c:      	movk	w4, #0xbf31, lsl #16
     860:      	mov	w5, #0xbe8e             ; =48782
     864:      	movk	w5, #0xb5bf, lsl #16
     868:      	mov	w6, #0x2bda             ; =11226
     86c:      	movk	w6, #0x3950, lsl #16
     870:      	mov	w7, #0x96c9             ; =38601
     874:      	movk	w7, #0x3ab6, lsl #16
     878:      	mov	w19, #0x88a6            ; =34982
     87c:      	movk	w19, #0x3c08, lsl #16
     880:      	tbnz	w13, #0x1, 0x1008 <_llm_rows.packet_batch.blocks+0xb8c>
     884:      	tbnz	w13, #0x2, 0x1014 <_llm_rows.packet_batch.blocks+0xb98>
     888:      	tbnz	w13, #0x3, 0x1020 <_llm_rows.packet_batch.blocks+0xba4>
     88c:      	tbnz	w13, #0x4, 0x102c <_llm_rows.packet_batch.blocks+0xbb0>
     890:      	tbnz	w13, #0x5, 0x1038 <_llm_rows.packet_batch.blocks+0xbbc>
     894:      	tbnz	w13, #0x6, 0x1044 <_llm_rows.packet_batch.blocks+0xbc8>
     898:      	tbz	w13, #0x7, 0x8a4 <_llm_rows.packet_batch.blocks+0x428>
     89c:      	add	x12, x12, #0x1c
     8a0:      	ld1.s	{ v4 }[3], [x12]
     8a4:      	mov	x15, #0x0               ; =0
     8a8:      	sshll2.2d	v7, v0, #0x0
     8ac:      	sshll2.2d	v16, v1, #0x0
     8b0:      	sshll.2d	v23, v0, #0x0
     8b4:      	adrp	x12, 0x0 <ltmp0>
     8b8:      	ldr	q24, [x12]
     8bc:      	mov.16b	v6, v23
     8c0:      	bsl.16b	v6, v24, v17
     8c4:      	adrp	x12, 0x0 <ltmp0>
     8c8:      	ldr	q23, [x12]
     8cc:      	mov.16b	v24, v16
     8d0:      	bsl.16b	v24, v23, v17
     8d4:      	adrp	x12, 0x0 <ltmp0>
     8d8:      	ldr	q23, [x12]
     8dc:      	bif.16b	v23, v17, v7
     8e0:      	umull.2d	v17, v21, v8
     8e4:      	xtn.2s	v19, v19
     8e8:      	xtn.2s	v20, v20
     8ec:      	xtn.2s	v18, v18
     8f0:      	umlal.2d	v23, v18, v8
     8f4:      	umlal.2d	v24, v19, v8
     8f8:      	stp	q23, q24, [sp, #0x50]
     8fc:      	adrp	x12, 0x0 <ltmp0>
     900:      	ldr	q18, [x12]
     904:      	mov	w12, #0x100             ; =256
     908:      	dup.2d	v19, x12
     90c:      	sshll.2d	v21, v1, #0x0
     910:      	bif.16b	v18, v19, v21
     914:      	adrp	x12, 0x0 <ltmp0>
     918:      	ldr	q21, [x12]
     91c:      	sshll.2d	v23, v0, #0x0
     920:      	bif.16b	v21, v19, v23
     924:      	adrp	x12, 0x0 <ltmp0>
     928:      	ldr	q23, [x12]
     92c:      	bsl.16b	v16, v23, v19
     930:      	adrp	x12, 0x0 <ltmp0>
     934:      	ldr	q23, [x12]
     938:      	bsl.16b	v7, v23, v19
     93c:      	stp	q21, q7, [sp, #0x160]
     940:      	stp	q18, q16, [sp, #0x140]
     944:      	and	x12, x9, #0x7
     948:      	add	x14, sp, #0x140
     94c:      	ldr	x12, [x14, x12, lsl #3]
     950:      	umlal.2d	v6, v20, v8
     954:      	stp	q6, q5, [sp, #0x70]
     958:      	sub	x12, x12, x9, lsl #2
     95c:      	tst	w13, #0xff
     960:      	csel	x12, xzr, x12, eq
     964:      	add	x13, x27, x12
     968:      	ldp	q7, q16, [x13]
     96c:      	zip2.8b	v18, v3, v0
     970:      	ushll.4s	v18, v18, #0x0
     974:      	shl.4s	v18, v18, #0x1f
     978:      	cmlt.4s	v18, v18, #0
     97c:      	bit.16b	v16, v4, v18
     980:      	zip1.8b	v18, v3, v0
     984:      	ushll.4s	v18, v18, #0x0
     988:      	shl.4s	v18, v18, #0x1f
     98c:      	cmlt.4s	v18, v18, #0
     990:      	bit.16b	v7, v5, v18
     994:      	stp	q7, q16, [x13]
     998:      	fmov	x13, d17
     99c:      	lsl	x13, x13, #2
     9a0:      	add	x14, x10, x13
     9a4:      	mov	w16, #0x1               ; =1
     9a8:      	dup.2d	v7, x16
     9ac:      	ushll2.2d	v16, v0, #0x0
     9b0:      	and.16b	v18, v16, v7
     9b4:      	ushll2.2d	v16, v1, #0x0
     9b8:      	and.16b	v19, v16, v7
     9bc:      	ushll.2d	v16, v0, #0x0
     9c0:      	and.16b	v20, v16, v7
     9c4:      	ushll.2d	v16, v1, #0x0
     9c8:      	and.16b	v21, v16, v7
     9cc:      	movi.2d	v23, #0000000000000000
     9d0:      	movi.2d	v24, #0000000000000000
     9d4:      	movi.2d	v25, #0000000000000000
     9d8:      	movi.2d	v26, #0000000000000000
     9dc:      	b	0xa10 <_llm_rows.packet_batch.blocks+0x594>
     9e0:      	add	x15, x28, x15
     9e4:      	ldp	q7, q16, [x15]
     9e8:      	bit.16b	v16, v28, v0
     9ec:      	bit.16b	v7, v27, v1
     9f0:      	stp	q7, q16, [x15]
     9f4:      	add.2d	v24, v24, v19
     9f8:      	add.2d	v25, v25, v20
     9fc:      	add.2d	v26, v26, v18
     a00:      	add.2d	v23, v23, v21
     a04:      	fmov	x15, d23
     a08:      	cmp	x15, #0x8
     a0c:      	b.ge	0xaac <_llm_rows.packet_batch.blocks+0x630>
     a10:      	fmov	w17, s2
     a14:      	lsl	x15, x15, #5
     a18:      	add	x16, x14, x15
     a1c:      	movi.2d	v27, #0000000000000000
     a20:      	movi.2d	v28, #0000000000000000
     a24:      	tbnz	w17, #0x0, 0xa4c <_llm_rows.packet_batch.blocks+0x5d0>
     a28:      	and	w17, w17, #0xff
     a2c:      	tbnz	w17, #0x1, 0xa58 <_llm_rows.packet_batch.blocks+0x5dc>
     a30:      	tbnz	w17, #0x2, 0xa64 <_llm_rows.packet_batch.blocks+0x5e8>
     a34:      	tbnz	w17, #0x3, 0xa70 <_llm_rows.packet_batch.blocks+0x5f4>
     a38:      	tbnz	w17, #0x4, 0xa7c <_llm_rows.packet_batch.blocks+0x600>
     a3c:      	tbnz	w17, #0x5, 0xa88 <_llm_rows.packet_batch.blocks+0x60c>
     a40:      	tbnz	w17, #0x6, 0xa94 <_llm_rows.packet_batch.blocks+0x618>
     a44:      	tbz	w17, #0x7, 0x9e0 <_llm_rows.packet_batch.blocks+0x564>
     a48:      	b	0xaa0 <_llm_rows.packet_batch.blocks+0x624>
     a4c:      	ldr	s27, [x16]
     a50:      	and	w17, w17, #0xff
     a54:      	tbz	w17, #0x1, 0xa30 <_llm_rows.packet_batch.blocks+0x5b4>
     a58:      	add	x0, x16, #0x4
     a5c:      	ld1.s	{ v27 }[1], [x0]
     a60:      	tbz	w17, #0x2, 0xa34 <_llm_rows.packet_batch.blocks+0x5b8>
     a64:      	add	x0, x16, #0x8
     a68:      	ld1.s	{ v27 }[2], [x0]
     a6c:      	tbz	w17, #0x3, 0xa38 <_llm_rows.packet_batch.blocks+0x5bc>
     a70:      	add	x0, x16, #0xc
     a74:      	ld1.s	{ v27 }[3], [x0]
     a78:      	tbz	w17, #0x4, 0xa3c <_llm_rows.packet_batch.blocks+0x5c0>
     a7c:      	add	x0, x16, #0x10
     a80:      	ld1.s	{ v28 }[0], [x0]
     a84:      	tbz	w17, #0x5, 0xa40 <_llm_rows.packet_batch.blocks+0x5c4>
     a88:      	add	x0, x16, #0x14
     a8c:      	ld1.s	{ v28 }[1], [x0]
     a90:      	tbz	w17, #0x6, 0xa44 <_llm_rows.packet_batch.blocks+0x5c8>
     a94:      	add	x0, x16, #0x18
     a98:      	ld1.s	{ v28 }[2], [x0]
     a9c:      	tbz	w17, #0x7, 0x9e0 <_llm_rows.packet_batch.blocks+0x564>
     aa0:      	add	x16, x16, #0x1c
     aa4:      	ld1.s	{ v28 }[3], [x16]
     aa8:      	b	0x9e0 <_llm_rows.packet_batch.blocks+0x564>
     aac:      	add	x10, x10, x11
     ab0:      	shl.8b	v7, v3, #0x7
     ab4:      	cmlt.8b	v7, v7, #0
     ab8:      	and.8b	v7, v7, v22
     abc:      	addv.8b	b5, v7
     ac0:      	str	d5, [sp, #0x48]
     ac4:      	fmov	w11, s5
     ac8:      	movi.2d	v23, #0000000000000000
     acc:      	movi.2d	v22, #0000000000000000
     ad0:      	tbnz	w11, #0x0, 0x1054 <_llm_rows.packet_batch.blocks+0xbd8>
     ad4:      	tbnz	w11, #0x1, 0x105c <_llm_rows.packet_batch.blocks+0xbe0>
     ad8:      	tbnz	w11, #0x2, 0x1068 <_llm_rows.packet_batch.blocks+0xbec>
     adc:      	tbnz	w11, #0x3, 0x1074 <_llm_rows.packet_batch.blocks+0xbf8>
     ae0:      	tbnz	w11, #0x4, 0x1080 <_llm_rows.packet_batch.blocks+0xc04>
     ae4:      	tbnz	w11, #0x5, 0x108c <_llm_rows.packet_batch.blocks+0xc10>
     ae8:      	tbnz	w11, #0x6, 0x1098 <_llm_rows.packet_batch.blocks+0xc1c>
     aec:      	tbz	w11, #0x7, 0xaf8 <_llm_rows.packet_batch.blocks+0x67c>
     af0:      	add	x10, x10, #0x1c
     af4:      	ld1.s	{ v22 }[3], [x10]
     af8:      	str	q4, [sp, #0xa0]
     afc:      	mov	x11, #0x0               ; =0
     b00:      	add	x10, x28, x12
     b04:      	ldp	q7, q16, [x10]
     b08:      	zip2.8b	v17, v3, v0
     b0c:      	ushll.4s	v17, v17, #0x0
     b10:      	shl.4s	v17, v17, #0x1f
     b14:      	cmlt.4s	v17, v17, #0
     b18:      	bit.16b	v16, v22, v17
     b1c:      	zip1.8b	v17, v3, v0
     b20:      	ushll.4s	v17, v17, #0x0
     b24:      	shl.4s	v17, v17, #0x1f
     b28:      	cmlt.4s	v17, v17, #0
     b2c:      	bit.16b	v7, v23, v17
     b30:      	stp	q7, q16, [x10]
     b34:      	add	x10, x8, x13
     b38:      	movi.2d	v13, #0000000000000000
     b3c:      	movi.2d	v14, #0000000000000000
     b40:      	movi.2d	v15, #0000000000000000
     b44:      	movi.2d	v8, #0000000000000000
     b48:      	b	0xb68 <_llm_rows.packet_batch.blocks+0x6ec>
     b4c:      	add.2d	v14, v14, v19
     b50:      	add.2d	v15, v15, v20
     b54:      	add.2d	v8, v8, v18
     b58:      	add.2d	v13, v13, v21
     b5c:      	fmov	x11, d13
     b60:      	cmp	x11, #0x8
     b64:      	b.ge	0xde8 <_llm_rows.packet_batch.blocks+0x96c>
     b68:      	fmov	w12, s2
     b6c:      	lsl	x11, x11, #5
     b70:      	add	x13, x27, x11
     b74:      	ldp	q16, q7, [x13]
     b78:      	and.16b	v16, v1, v16
     b7c:      	fneg.4s	v17, v16
     b80:      	and.16b	v17, v1, v17
     b84:      	dup.4s	v25, w1
     b88:      	fcmge.4s	v27, v17, v25
     b8c:      	dup.4s	v26, w2
     b90:      	fcmge.4s	v28, v26, v17
     b94:      	and.16b	v27, v27, v28
     b98:      	and.16b	v27, v27, v17
     b9c:      	dup.4s	v28, w3
     ba0:      	fmul.4s	v29, v27, v28
     ba4:      	movi.4s	v4, #0x4b, lsl #24
     ba8:      	mvni.4s	v5, #0x80, lsl #24
     bac:      	mov.16b	v30, v5
     bb0:      	bsl.16b	v30, v4, v29
     bb4:      	fadd.4s	v29, v29, v30
     bb8:      	fsub.4s	v29, v29, v30
     bbc:      	fcvtzs.4s	v5, v29
     bc0:      	dup.4s	v29, w4
     bc4:      	scvtf.4s	v31, v5
     bc8:      	fmul.4s	v30, v31, v29
     bcc:      	fadd.4s	v27, v27, v30
     bd0:      	dup.4s	v30, w5
     bd4:      	fmul.4s	v31, v31, v30
     bd8:      	fadd.4s	v27, v27, v31
     bdc:      	dup.4s	v31, w6
     be0:      	fmul.4s	v10, v27, v31
     be4:      	dup.4s	v9, w7
     be8:      	fadd.4s	v10, v10, v9
     bec:      	fmul.4s	v11, v27, v10
     bf0:      	dup.4s	v10, w19
     bf4:      	fadd.4s	v11, v11, v10
     bf8:      	fmul.4s	v12, v27, v11
     bfc:      	dup.4s	v11, w30
     c00:      	fadd.4s	v12, v12, v11
     c04:      	fmul.4s	v24, v27, v12
     c08:      	dup.4s	v12, w24
     c0c:      	fadd.4s	v24, v24, v12
     c10:      	fmul.4s	v24, v27, v24
     c14:      	movi.4s	v4, #0x3f, lsl #24
     c18:      	fadd.4s	v24, v24, v4
     c1c:      	fmul.4s	v6, v27, v27
     c20:      	fmul.4s	v6, v6, v24
     c24:      	fadd.4s	v6, v27, v6
     c28:      	fmov.4s	v27, #1.00000000
     c2c:      	fadd.4s	v6, v6, v27
     c30:      	sshr.4s	v24, v5, #0x1
     c34:      	shl.4s	v4, v24, #0x17
     c38:      	add.4s	v4, v4, v27
     c3c:      	fmul.4s	v4, v6, v4
     c40:      	sub.4s	v5, v5, v24
     c44:      	shl.4s	v5, v5, #0x17
     c48:      	add.4s	v5, v5, v27
     c4c:      	fmul.4s	v4, v4, v5
     c50:      	fcmgt.4s	v5, v25, v17
     c54:      	fcmgt.4s	v6, v17, v26
     c58:      	fcmeq.4s	v17, v17, v17
     c5c:      	fadd.4s	v4, v4, v27
     c60:      	bit.16b	v4, v27, v5
     c64:      	ldr	q5, [sp, #0xe0]
     c68:      	bit.16b	v4, v5, v6
     c6c:      	ldr	q5, [sp, #0xd0]
     c70:      	bif.16b	v4, v5, v17
     c74:      	fdiv.4s	v4, v16, v4
     c78:      	add	x13, x28, x11
     c7c:      	ldp	q5, q16, [x13]
     c80:      	and.16b	v5, v1, v5
     c84:      	fmul.4s	v17, v5, v4
     c88:      	add	x11, x10, x11
     c8c:      	tbnz	w12, #0x0, 0xd94 <_llm_rows.packet_batch.blocks+0x918>
     c90:      	and	w12, w12, #0xff
     c94:      	tbnz	w12, #0x1, 0xda0 <_llm_rows.packet_batch.blocks+0x924>
     c98:      	tbnz	w12, #0x2, 0xdac <_llm_rows.packet_batch.blocks+0x930>
     c9c:      	tbz	w12, #0x3, 0xca8 <_llm_rows.packet_batch.blocks+0x82c>
     ca0:      	add	x13, x11, #0xc
     ca4:      	st1.s	{ v17 }[3], [x13]
     ca8:      	and.16b	v4, v0, v7
     cac:      	fneg.4s	v5, v4
     cb0:      	and.16b	v5, v0, v5
     cb4:      	fcmge.4s	v6, v5, v25
     cb8:      	fcmge.4s	v7, v26, v5
     cbc:      	and.16b	v6, v6, v7
     cc0:      	and.16b	v6, v6, v5
     cc4:      	fmul.4s	v7, v6, v28
     cc8:      	movi.4s	v17, #0x4b, lsl #24
     ccc:      	mvni.4s	v24, #0x80, lsl #24
     cd0:      	bif.16b	v17, v7, v24
     cd4:      	fadd.4s	v7, v7, v17
     cd8:      	fsub.4s	v7, v7, v17
     cdc:      	fcvtzs.4s	v7, v7
     ce0:      	scvtf.4s	v17, v7
     ce4:      	fmul.4s	v24, v17, v29
     ce8:      	fadd.4s	v6, v6, v24
     cec:      	fmul.4s	v17, v17, v30
     cf0:      	fadd.4s	v6, v6, v17
     cf4:      	fmul.4s	v17, v6, v31
     cf8:      	fadd.4s	v17, v17, v9
     cfc:      	fmul.4s	v17, v6, v17
     d00:      	fadd.4s	v17, v17, v10
     d04:      	fmul.4s	v17, v6, v17
     d08:      	fadd.4s	v17, v17, v11
     d0c:      	fmul.4s	v17, v6, v17
     d10:      	fadd.4s	v17, v17, v12
     d14:      	fmul.4s	v17, v6, v17
     d18:      	movi.4s	v24, #0x3f, lsl #24
     d1c:      	fadd.4s	v17, v17, v24
     d20:      	fmul.4s	v24, v6, v6
     d24:      	fmul.4s	v17, v24, v17
     d28:      	fadd.4s	v6, v6, v17
     d2c:      	fadd.4s	v6, v6, v27
     d30:      	sshr.4s	v17, v7, #0x1
     d34:      	shl.4s	v24, v17, #0x17
     d38:      	add.4s	v24, v24, v27
     d3c:      	fmul.4s	v6, v6, v24
     d40:      	sub.4s	v7, v7, v17
     d44:      	shl.4s	v7, v7, #0x17
     d48:      	add.4s	v7, v7, v27
     d4c:      	fmul.4s	v6, v6, v7
     d50:      	fcmgt.4s	v7, v25, v5
     d54:      	fcmgt.4s	v17, v5, v26
     d58:      	fcmeq.4s	v5, v5, v5
     d5c:      	fadd.4s	v6, v6, v27
     d60:      	bit.16b	v6, v27, v7
     d64:      	ldr	q7, [sp, #0xe0]
     d68:      	bit.16b	v6, v7, v17
     d6c:      	ldr	q7, [sp, #0xd0]
     d70:      	bsl.16b	v5, v6, v7
     d74:      	fdiv.4s	v4, v4, v5
     d78:      	and.16b	v5, v0, v16
     d7c:      	fmul.4s	v7, v5, v4
     d80:      	tbnz	w12, #0x4, 0xdbc <_llm_rows.packet_batch.blocks+0x940>
     d84:      	tbnz	w12, #0x5, 0xdc4 <_llm_rows.packet_batch.blocks+0x948>
     d88:      	tbnz	w12, #0x6, 0xdd0 <_llm_rows.packet_batch.blocks+0x954>
     d8c:      	tbz	w12, #0x7, 0xb4c <_llm_rows.packet_batch.blocks+0x6d0>
     d90:      	b	0xddc <_llm_rows.packet_batch.blocks+0x960>
     d94:      	str	s17, [x11]
     d98:      	and	w12, w12, #0xff
     d9c:      	tbz	w12, #0x1, 0xc98 <_llm_rows.packet_batch.blocks+0x81c>
     da0:      	add	x13, x11, #0x4
     da4:      	st1.s	{ v17 }[1], [x13]
     da8:      	tbz	w12, #0x2, 0xc9c <_llm_rows.packet_batch.blocks+0x820>
     dac:      	add	x13, x11, #0x8
     db0:      	st1.s	{ v17 }[2], [x13]
     db4:      	tbnz	w12, #0x3, 0xca0 <_llm_rows.packet_batch.blocks+0x824>
     db8:      	b	0xca8 <_llm_rows.packet_batch.blocks+0x82c>
     dbc:      	str	s7, [x11, #0x10]
     dc0:      	tbz	w12, #0x5, 0xd88 <_llm_rows.packet_batch.blocks+0x90c>
     dc4:      	add	x13, x11, #0x14
     dc8:      	st1.s	{ v7 }[1], [x13]
     dcc:      	tbz	w12, #0x6, 0xd8c <_llm_rows.packet_batch.blocks+0x910>
     dd0:      	add	x13, x11, #0x18
     dd4:      	st1.s	{ v7 }[2], [x13]
     dd8:      	tbz	w12, #0x7, 0xb4c <_llm_rows.packet_batch.blocks+0x6d0>
     ddc:      	add	x11, x11, #0x1c
     de0:      	st1.s	{ v7 }[3], [x11]
     de4:      	b	0xb4c <_llm_rows.packet_batch.blocks+0x6d0>
     de8:      	ldr	q6, [sp, #0x80]
     dec:      	fneg.4s	v0, v6
     df0:      	ldr	d1, [sp, #0x48]
     df4:      	fmov	w10, s1
     df8:      	zip1.8b	v1, v3, v0
     dfc:      	ushll.4s	v1, v1, #0x0
     e00:      	shl.4s	v1, v1, #0x1f
     e04:      	cmlt.4s	v1, v1, #0
     e08:      	and.16b	v0, v1, v0
     e0c:      	fcmge.4s	v1, v0, v25
     e10:      	fcmge.4s	v2, v26, v0
     e14:      	and.16b	v1, v1, v2
     e18:      	and.16b	v1, v1, v0
     e1c:      	fmul.4s	v2, v1, v28
     e20:      	movi.4s	v4, #0x4b, lsl #24
     e24:      	mvni.4s	v5, #0x80, lsl #24
     e28:      	bif.16b	v4, v2, v5
     e2c:      	fadd.4s	v2, v2, v4
     e30:      	fsub.4s	v2, v2, v4
     e34:      	fcvtzs.4s	v2, v2
     e38:      	scvtf.4s	v4, v2
     e3c:      	fmul.4s	v5, v4, v29
     e40:      	fadd.4s	v1, v1, v5
     e44:      	fmul.4s	v4, v4, v30
     e48:      	fadd.4s	v1, v1, v4
     e4c:      	fmul.4s	v4, v1, v31
     e50:      	fadd.4s	v4, v4, v9
     e54:      	fmul.4s	v4, v1, v4
     e58:      	fadd.4s	v4, v4, v10
     e5c:      	fmul.4s	v4, v1, v4
     e60:      	fadd.4s	v4, v4, v11
     e64:      	fmul.4s	v4, v1, v4
     e68:      	fadd.4s	v4, v4, v12
     e6c:      	fmul.4s	v4, v1, v4
     e70:      	movi.4s	v5, #0x3f, lsl #24
     e74:      	fadd.4s	v4, v4, v5
     e78:      	fmul.4s	v5, v1, v1
     e7c:      	fmul.4s	v4, v5, v4
     e80:      	fadd.4s	v1, v1, v4
     e84:      	fadd.4s	v1, v1, v27
     e88:      	sshr.4s	v4, v2, #0x1
     e8c:      	shl.4s	v5, v4, #0x17
     e90:      	add.4s	v5, v5, v27
     e94:      	fmul.4s	v1, v1, v5
     e98:      	sub.4s	v2, v2, v4
     e9c:      	shl.4s	v2, v2, #0x17
     ea0:      	add.4s	v2, v2, v27
     ea4:      	fmul.4s	v1, v1, v2
     ea8:      	fcmgt.4s	v2, v25, v0
     eac:      	fcmgt.4s	v4, v0, v26
     eb0:      	fcmeq.4s	v0, v0, v0
     eb4:      	fadd.4s	v1, v1, v27
     eb8:      	bit.16b	v1, v27, v2
     ebc:      	ldp	q2, q5, [sp, #0xd0]
     ec0:      	bit.16b	v1, v5, v4
     ec4:      	bsl.16b	v0, v1, v2
     ec8:      	fdiv.4s	v0, v6, v0
     ecc:      	fmul.4s	v0, v0, v23
     ed0:      	ldr	q2, [sp, #0x90]
     ed4:      	ldp	q4, q5, [sp, #0x60]
     ed8:      	stp	q2, q4, [sp, #0xf0]
     edc:      	ldr	q1, [sp, #0x50]
     ee0:      	stp	q5, q1, [sp, #0x110]
     ee4:      	and	x11, x9, #0x7
     ee8:      	add	x12, sp, #0xf0
     eec:      	ldr	x11, [x12, x11, lsl #3]
     ef0:      	sub	x9, x11, x9
     ef4:      	add	x8, x8, x9, lsl #2
     ef8:      	tbnz	w10, #0x0, 0x10a8 <_llm_rows.packet_batch.blocks+0xc2c>
     efc:      	movi.2s	v8, #0x41
     f00:      	ldr	q5, [sp, #0xa0]
     f04:      	tbnz	w10, #0x1, 0x10b8 <_llm_rows.packet_batch.blocks+0xc3c>
     f08:      	tbnz	w10, #0x2, 0x10c4 <_llm_rows.packet_batch.blocks+0xc48>
     f0c:      	tbz	w10, #0x3, 0xf18 <_llm_rows.packet_batch.blocks+0xa9c>
     f10:      	add	x9, x8, #0xc
     f14:      	st1.s	{ v0 }[3], [x9]
     f18:      	fneg.4s	v0, v5
     f1c:      	zip2.8b	v1, v3, v0
     f20:      	ushll.4s	v1, v1, #0x0
     f24:      	shl.4s	v1, v1, #0x1f
     f28:      	cmlt.4s	v1, v1, #0
     f2c:      	and.16b	v0, v1, v0
     f30:      	fcmge.4s	v1, v0, v25
     f34:      	fcmge.4s	v2, v26, v0
     f38:      	and.16b	v1, v1, v2
     f3c:      	and.16b	v1, v1, v0
     f40:      	fmul.4s	v2, v1, v28
     f44:      	movi.4s	v3, #0x4b, lsl #24
     f48:      	mvni.4s	v4, #0x80, lsl #24
     f4c:      	bif.16b	v3, v2, v4
     f50:      	fadd.4s	v2, v2, v3
     f54:      	fsub.4s	v2, v2, v3
     f58:      	fcvtzs.4s	v2, v2
     f5c:      	scvtf.4s	v3, v2
     f60:      	fmul.4s	v4, v3, v29
     f64:      	fadd.4s	v1, v1, v4
     f68:      	fmul.4s	v3, v3, v30
     f6c:      	fadd.4s	v1, v1, v3
     f70:      	fmul.4s	v3, v1, v31
     f74:      	fadd.4s	v3, v3, v9
     f78:      	fmul.4s	v3, v1, v3
     f7c:      	fadd.4s	v3, v3, v10
     f80:      	fmul.4s	v3, v1, v3
     f84:      	fadd.4s	v3, v3, v11
     f88:      	fmul.4s	v3, v1, v3
     f8c:      	fadd.4s	v3, v3, v12
     f90:      	fmul.4s	v3, v1, v3
     f94:      	movi.4s	v4, #0x3f, lsl #24
     f98:      	fadd.4s	v3, v3, v4
     f9c:      	fmul.4s	v4, v1, v1
     fa0:      	fmul.4s	v3, v4, v3
     fa4:      	fadd.4s	v1, v1, v3
     fa8:      	fadd.4s	v1, v1, v27
     fac:      	sshr.4s	v3, v2, #0x1
     fb0:      	shl.4s	v4, v3, #0x17
     fb4:      	add.4s	v4, v4, v27
     fb8:      	fmul.4s	v1, v1, v4
     fbc:      	sub.4s	v2, v2, v3
     fc0:      	shl.4s	v2, v2, #0x17
     fc4:      	add.4s	v2, v2, v27
     fc8:      	fmul.4s	v1, v1, v2
     fcc:      	fcmgt.4s	v2, v25, v0
     fd0:      	fcmgt.4s	v3, v0, v26
     fd4:      	fcmeq.4s	v0, v0, v0
     fd8:      	fadd.4s	v1, v1, v27
     fdc:      	bit.16b	v1, v27, v2
     fe0:      	ldp	q2, q4, [sp, #0xd0]
     fe4:      	bit.16b	v1, v4, v3
     fe8:      	bsl.16b	v0, v1, v2
     fec:      	fdiv.4s	v0, v5, v0
     ff0:      	fmul.4s	v0, v0, v22
     ff4:      	tbnz	w10, #0x4, 0x10d4 <_llm_rows.packet_batch.blocks+0xc58>
     ff8:      	tbnz	w10, #0x5, 0x10dc <_llm_rows.packet_batch.blocks+0xc60>
     ffc:      	tbnz	w10, #0x6, 0x10e8 <_llm_rows.packet_batch.blocks+0xc6c>
    1000:      	tbz	w10, #0x7, 0x520 <_llm_rows.packet_batch.blocks+0xa4>
    1004:      	b	0x10f4 <_llm_rows.packet_batch.blocks+0xc78>
    1008:      	add	x14, x12, #0x4
    100c:      	ld1.s	{ v5 }[1], [x14]
    1010:      	tbz	w13, #0x2, 0x888 <_llm_rows.packet_batch.blocks+0x40c>
    1014:      	add	x14, x12, #0x8
    1018:      	ld1.s	{ v5 }[2], [x14]
    101c:      	tbz	w13, #0x3, 0x88c <_llm_rows.packet_batch.blocks+0x410>
    1020:      	add	x14, x12, #0xc
    1024:      	ld1.s	{ v5 }[3], [x14]
    1028:      	tbz	w13, #0x4, 0x890 <_llm_rows.packet_batch.blocks+0x414>
    102c:      	add	x14, x12, #0x10
    1030:      	ld1.s	{ v4 }[0], [x14]
    1034:      	tbz	w13, #0x5, 0x894 <_llm_rows.packet_batch.blocks+0x418>
    1038:      	add	x14, x12, #0x14
    103c:      	ld1.s	{ v4 }[1], [x14]
    1040:      	tbz	w13, #0x6, 0x898 <_llm_rows.packet_batch.blocks+0x41c>
    1044:      	add	x14, x12, #0x18
    1048:      	ld1.s	{ v4 }[2], [x14]
    104c:      	tbnz	w13, #0x7, 0x89c <_llm_rows.packet_batch.blocks+0x420>
    1050:      	b	0x8a4 <_llm_rows.packet_batch.blocks+0x428>
    1054:      	ldr	s23, [x10]
    1058:      	tbz	w11, #0x1, 0xad8 <_llm_rows.packet_batch.blocks+0x65c>
    105c:      	add	x14, x10, #0x4
    1060:      	ld1.s	{ v23 }[1], [x14]
    1064:      	tbz	w11, #0x2, 0xadc <_llm_rows.packet_batch.blocks+0x660>
    1068:      	add	x14, x10, #0x8
    106c:      	ld1.s	{ v23 }[2], [x14]
    1070:      	tbz	w11, #0x3, 0xae0 <_llm_rows.packet_batch.blocks+0x664>
    1074:      	add	x14, x10, #0xc
    1078:      	ld1.s	{ v23 }[3], [x14]
    107c:      	tbz	w11, #0x4, 0xae4 <_llm_rows.packet_batch.blocks+0x668>
    1080:      	add	x14, x10, #0x10
    1084:      	ld1.s	{ v22 }[0], [x14]
    1088:      	tbz	w11, #0x5, 0xae8 <_llm_rows.packet_batch.blocks+0x66c>
    108c:      	add	x14, x10, #0x14
    1090:      	ld1.s	{ v22 }[1], [x14]
    1094:      	tbz	w11, #0x6, 0xaec <_llm_rows.packet_batch.blocks+0x670>
    1098:      	add	x14, x10, #0x18
    109c:      	ld1.s	{ v22 }[2], [x14]
    10a0:      	tbnz	w11, #0x7, 0xaf0 <_llm_rows.packet_batch.blocks+0x674>
    10a4:      	b	0xaf8 <_llm_rows.packet_batch.blocks+0x67c>
    10a8:      	str	s0, [x8]
    10ac:      	movi.2s	v8, #0x41
    10b0:      	ldr	q5, [sp, #0xa0]
    10b4:      	tbz	w10, #0x1, 0xf08 <_llm_rows.packet_batch.blocks+0xa8c>
    10b8:      	add	x9, x8, #0x4
    10bc:      	st1.s	{ v0 }[1], [x9]
    10c0:      	tbz	w10, #0x2, 0xf0c <_llm_rows.packet_batch.blocks+0xa90>
    10c4:      	add	x9, x8, #0x8
    10c8:      	st1.s	{ v0 }[2], [x9]
    10cc:      	tbnz	w10, #0x3, 0xf10 <_llm_rows.packet_batch.blocks+0xa94>
    10d0:      	b	0xf18 <_llm_rows.packet_batch.blocks+0xa9c>
    10d4:      	str	s0, [x8, #0x10]
    10d8:      	tbz	w10, #0x5, 0xffc <_llm_rows.packet_batch.blocks+0xb80>
    10dc:      	add	x9, x8, #0x14
    10e0:      	st1.s	{ v0 }[1], [x9]
    10e4:      	tbz	w10, #0x6, 0x1000 <_llm_rows.packet_batch.blocks+0xb84>
    10e8:      	add	x9, x8, #0x18
    10ec:      	st1.s	{ v0 }[2], [x9]
    10f0:      	tbz	w10, #0x7, 0x520 <_llm_rows.packet_batch.blocks+0xa4>
    10f4:      	add	x8, x8, #0x1c
    10f8:      	st1.s	{ v0 }[3], [x8]
    10fc:      	b	0x520 <_llm_rows.packet_batch.blocks+0xa4>
    1100:      	add	sp, sp, #0x410
    1104:      	ldp	x29, x30, [sp, #0x90]
    1108:      	ldp	x20, x19, [sp, #0x80]
    110c:      	ldp	x22, x21, [sp, #0x70]
    1110:      	ldp	x24, x23, [sp, #0x60]
    1114:      	ldp	x26, x25, [sp, #0x50]
    1118:      	ldp	x28, x27, [sp, #0x40]
    111c:      	ldp	d9, d8, [sp, #0x30]
    1120:      	ldp	d11, d10, [sp, #0x20]
    1124:      	ldp	d13, d12, [sp, #0x10]
    1128:      	ldp	d15, d14, [sp], #0xa0
    112c:      	ret

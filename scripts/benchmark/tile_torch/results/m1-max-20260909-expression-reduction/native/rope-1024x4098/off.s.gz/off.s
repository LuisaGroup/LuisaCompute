
/private/tmp/luisa-expression-fusion.qXgTbC/capture/rope-1024x4098/off/object/tile_xir_w8_23526_1788930275267088_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
      2c:      	sub	sp, sp, #0x340
      30:      	str	x0, [sp, #0x40]
      34:      	cbz	w3, 0x1804 <ltmp0+0x1804>
      38:      	mov	w20, #0x0               ; =0
      3c:      	add	x7, sp, #0x6, lsl #12   ; =0x6000
      40:      	add	x7, x7, #0x320
      44:      	ldp	w9, w8, [x2, #0x2c]
      48:      	stp	w8, w9, [sp, #0x58]
      4c:      	add	x4, sp, #0x4, lsl #12   ; =0x4000
      50:      	add	x4, x4, #0x300
      54:      	add	x27, sp, #0x2, lsl #12  ; =0x2000
      58:      	add	x27, x27, #0x2e0
      5c:      	ldp	w8, w9, [x2]
      60:      	add	x28, sp, #0x2c0
      64:      	ldp	w10, w11, [x2, #0x8]
      68:      	str	x2, [sp, #0x8]
      6c:      	str	x11, [sp, #0x50]
      70:      	adrp	x11, 0x0 <ltmp0>
      74:      	ldr	q0, [x11]
      78:      	str	q0, [sp, #0x30]
      7c:      	adrp	x11, 0x0 <ltmp0>
      80:      	ldr	q0, [x11]
      84:      	str	q0, [sp, #0x20]
      88:      	adrp	x11, 0x0 <ltmp0>
      8c:      	ldr	q0, [x11]
      90:      	str	q0, [sp, #0x10]
      94:      	str	w3, [sp, #0x60]
      98:      	b	0xd8 <ltmp0+0xd8>
      9c:      	add	w8, w6, #0x1
      a0:      	ldp	w11, w9, [sp, #0x58]
      a4:      	cmp	w8, w9
      a8:      	cset	w9, eq
      ac:      	csinc	w8, wzr, w6, eq
      b0:      	cinc	w10, w5, eq
      b4:      	cmp	w10, w11
      b8:      	cset	w11, eq
      bc:      	ands	w11, w9, w11
      c0:      	csel	w9, wzr, w10, ne
      c4:      	ldr	w12, [sp, #0x68]
      c8:      	add	w10, w12, w11
      cc:      	add	w20, w20, #0x1
      d0:      	cmp	w20, w3
      d4:      	b.eq	0x17f0 <ltmp0+0x17f0>
      d8:      	stp	w9, w10, [sp, #0x64]
      dc:      	mov	x13, x8
      e0:      	ubfiz	x8, x8, #5, #32
      e4:      	ldr	x12, [sp, #0x50]
      e8:      	cmp	x8, x12
      ec:      	csel	x9, x8, xzr, ls
      f0:      	subs	x10, x12, x9
      f4:      	cmp	x10, #0x20
      f8:      	mov	w11, #0x20              ; =32
      fc:      	csel	x10, x10, x11, lo
     100:      	cmp	x12, x9
     104:      	ccmp	x8, x12, #0x2, hi
     108:      	csel	x9, x10, xzr, ls
     10c:      	cmp	x9, #0x20
     110:      	str	w20, [sp, #0x6c]
     114:      	str	x13, [sp, #0x70]
     118:      	b.lo	0x798 <ltmp0+0x798>
     11c:      	ldr	x8, [sp, #0x40]
     120:      	ldr	x23, [x8]
     124:      	ldr	x19, [x8, #0x10]
     128:      	ldr	x26, [x8, #0x20]
     12c:      	ldr	x24, [x8, #0x30]
     130:      	ubfiz	w8, w13, #2, #27
     134:      	str	x8, [sp, #0xc0]
     138:      	add	x21, x8, x8, lsl #11
     13c:      	lsl	x25, x21, #3
     140:      	add	x22, x23, x25
     144:      	add	x0, sp, #0x6, lsl #12   ; =0x6000
     148:      	add	x0, x0, #0x320
     14c:      	mov	x1, x22
     150:      	mov	w2, #0x2000             ; =8192
     154:      	bl	0x154 <ltmp0+0x154>
     158:      	add	x20, x25, #0x2, lsl #12 ; =0x2000
     15c:      	ldr	s0, [x23, x20]
     160:      	str	q0, [sp, #0xb0]
     164:      	str	q0, [sp, #0x8320]
     168:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
     16c:      	add	x0, x0, #0x300
     170:      	mov	w8, #0x2004             ; =8196
     174:      	add	x1, x22, x8
     178:      	mov	w2, #0x2000             ; =8192
     17c:      	bl	0x17c <ltmp0+0x17c>
     180:      	mov	w8, #0x4004             ; =16388
     184:      	add	x8, x25, x8
     188:      	str	x8, [sp, #0xa8]
     18c:      	ldr	s0, [x23, x8]
     190:      	str	q0, [sp, #0x90]
     194:      	str	q0, [sp, #0x6300]
     198:      	lsl	x21, x21, #2
     19c:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
     1a0:      	add	x0, x0, #0x2e0
     1a4:      	add	x1, x19, x21
     1a8:      	mov	w2, #0x2000             ; =8192
     1ac:      	bl	0x1ac <ltmp0+0x1ac>
     1b0:      	add	x22, x21, #0x2, lsl #12 ; =0x2000
     1b4:      	str	x19, [sp, #0xd0]
     1b8:      	ldr	s0, [x19, x22]
     1bc:      	str	q0, [sp, #0x80]
     1c0:      	str	q0, [sp, #0x42e0]
     1c4:      	add	x0, sp, #0x2c0
     1c8:      	add	x1, x26, x21
     1cc:      	mov	w2, #0x2000             ; =8192
     1d0:      	bl	0x1d0 <ltmp0+0x1d0>
     1d4:      	add	x12, sp, #0x4, lsl #12  ; =0x4000
     1d8:      	add	x12, x12, #0x300
     1dc:      	add	x11, sp, #0x6, lsl #12  ; =0x6000
     1e0:      	add	x11, x11, #0x320
     1e4:      	mov	x9, #0x0                ; =0
     1e8:      	str	x26, [sp, #0xe0]
     1ec:      	ldr	s0, [x26, x22]
     1f0:      	str	q0, [sp, #0x22c0]
     1f4:      	add	x8, x24, x25
     1f8:      	add	x10, x11, x9
     1fc:      	ldp	q1, q2, [x10]
     200:      	add	x10, x27, x9
     204:      	ldp	q3, q4, [x10]
     208:      	fmul.4s	v2, v2, v4
     20c:      	fmul.4s	v1, v1, v3
     210:      	add	x10, x12, x9
     214:      	ldp	q3, q4, [x10]
     218:      	add	x10, x28, x9
     21c:      	ldp	q5, q6, [x10]
     220:      	fmul.4s	v4, v4, v6
     224:      	fmul.4s	v3, v3, v5
     228:      	fsub.4s	v1, v1, v3
     22c:      	fsub.4s	v2, v2, v4
     230:      	add	x10, x8, x9
     234:      	stp	q1, q2, [x10]
     238:      	add	x9, x9, #0x20
     23c:      	cmp	x9, #0x2, lsl #12       ; =0x2000
     240:      	b.ne	0x1f8 <ltmp0+0x1f8>
     244:      	mov	x9, #0x0                ; =0
     248:      	ldr	q7, [sp, #0xb0]
     24c:      	ldp	q17, q16, [sp, #0x80]
     250:      	fmul.4s	v1, v7, v17
     254:      	fmul.4s	v2, v16, v0
     258:      	fsub.4s	v1, v1, v2
     25c:      	str	s1, [x24, x20]
     260:      	mov	w10, #0x2004            ; =8196
     264:      	add	x8, x8, x10
     268:      	add	x10, x11, x9
     26c:      	ldp	q1, q2, [x10]
     270:      	add	x10, x28, x9
     274:      	ldp	q3, q4, [x10]
     278:      	fmul.4s	v2, v2, v4
     27c:      	fmul.4s	v1, v1, v3
     280:      	add	x10, x12, x9
     284:      	ldp	q3, q4, [x10]
     288:      	add	x10, x27, x9
     28c:      	ldp	q5, q6, [x10]
     290:      	fmul.4s	v4, v4, v6
     294:      	fmul.4s	v3, v3, v5
     298:      	fadd.4s	v1, v1, v3
     29c:      	fadd.4s	v2, v2, v4
     2a0:      	add	x10, x8, x9
     2a4:      	stp	q1, q2, [x10]
     2a8:      	add	x9, x9, #0x20
     2ac:      	cmp	x9, #0x2, lsl #12       ; =0x2000
     2b0:      	b.ne	0x268 <ltmp0+0x268>
     2b4:      	fmul.4s	v0, v7, v0
     2b8:      	fmul.4s	v1, v16, v17
     2bc:      	fadd.4s	v0, v1, v0
     2c0:      	ldr	x8, [sp, #0xa8]
     2c4:      	str	s0, [x24, x8]
     2c8:      	ldr	x8, [sp, #0xc0]
     2cc:      	orr	w8, w8, #0x1
     2d0:      	add	x21, x8, x8, lsl #11
     2d4:      	lsl	x25, x21, #3
     2d8:      	add	x22, x23, x25
     2dc:      	add	x0, sp, #0x6, lsl #12   ; =0x6000
     2e0:      	add	x0, x0, #0x320
     2e4:      	mov	x1, x22
     2e8:      	mov	w2, #0x2000             ; =8192
     2ec:      	bl	0x2ec <ltmp0+0x2ec>
     2f0:      	add	x20, x25, #0x2, lsl #12 ; =0x2000
     2f4:      	ldr	s0, [x23, x20]
     2f8:      	str	q0, [sp, #0xb0]
     2fc:      	str	q0, [sp, #0x8320]
     300:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
     304:      	add	x0, x0, #0x300
     308:      	mov	w8, #0x2004             ; =8196
     30c:      	add	x1, x22, x8
     310:      	mov	w2, #0x2000             ; =8192
     314:      	bl	0x314 <ltmp0+0x314>
     318:      	mov	w8, #0x4004             ; =16388
     31c:      	add	x8, x25, x8
     320:      	str	x8, [sp, #0xa8]
     324:      	ldr	s0, [x23, x8]
     328:      	str	q0, [sp, #0x90]
     32c:      	str	q0, [sp, #0x6300]
     330:      	lsl	x21, x21, #2
     334:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
     338:      	add	x0, x0, #0x2e0
     33c:      	ldr	x19, [sp, #0xd0]
     340:      	add	x1, x19, x21
     344:      	mov	w2, #0x2000             ; =8192
     348:      	bl	0x348 <ltmp0+0x348>
     34c:      	add	x22, x21, #0x2, lsl #12 ; =0x2000
     350:      	ldr	s0, [x19, x22]
     354:      	str	q0, [sp, #0x80]
     358:      	str	q0, [sp, #0x42e0]
     35c:      	add	x0, sp, #0x2c0
     360:      	ldr	x26, [sp, #0xe0]
     364:      	add	x1, x26, x21
     368:      	mov	w2, #0x2000             ; =8192
     36c:      	bl	0x36c <ltmp0+0x36c>
     370:      	add	x12, sp, #0x4, lsl #12  ; =0x4000
     374:      	add	x12, x12, #0x300
     378:      	add	x11, sp, #0x6, lsl #12  ; =0x6000
     37c:      	add	x11, x11, #0x320
     380:      	mov	x9, #0x0                ; =0
     384:      	ldr	s0, [x26, x22]
     388:      	str	q0, [sp, #0x22c0]
     38c:      	add	x8, x24, x25
     390:      	add	x10, x11, x9
     394:      	ldp	q1, q2, [x10]
     398:      	add	x10, x27, x9
     39c:      	ldp	q3, q4, [x10]
     3a0:      	fmul.4s	v2, v2, v4
     3a4:      	fmul.4s	v1, v1, v3
     3a8:      	add	x10, x12, x9
     3ac:      	ldp	q3, q4, [x10]
     3b0:      	add	x10, x28, x9
     3b4:      	ldp	q5, q6, [x10]
     3b8:      	fmul.4s	v4, v4, v6
     3bc:      	fmul.4s	v3, v3, v5
     3c0:      	fsub.4s	v1, v1, v3
     3c4:      	fsub.4s	v2, v2, v4
     3c8:      	add	x10, x8, x9
     3cc:      	stp	q1, q2, [x10]
     3d0:      	add	x9, x9, #0x20
     3d4:      	cmp	x9, #0x2, lsl #12       ; =0x2000
     3d8:      	b.ne	0x390 <ltmp0+0x390>
     3dc:      	mov	x9, #0x0                ; =0
     3e0:      	ldr	q7, [sp, #0xb0]
     3e4:      	ldp	q17, q16, [sp, #0x80]
     3e8:      	fmul.4s	v1, v7, v17
     3ec:      	fmul.4s	v2, v16, v0
     3f0:      	fsub.4s	v1, v1, v2
     3f4:      	str	s1, [x24, x20]
     3f8:      	mov	w10, #0x2004            ; =8196
     3fc:      	add	x8, x8, x10
     400:      	add	x10, x11, x9
     404:      	ldp	q1, q2, [x10]
     408:      	add	x10, x28, x9
     40c:      	ldp	q3, q4, [x10]
     410:      	fmul.4s	v2, v2, v4
     414:      	fmul.4s	v1, v1, v3
     418:      	add	x10, x12, x9
     41c:      	ldp	q3, q4, [x10]
     420:      	add	x10, x27, x9
     424:      	ldp	q5, q6, [x10]
     428:      	fmul.4s	v4, v4, v6
     42c:      	fmul.4s	v3, v3, v5
     430:      	fadd.4s	v1, v1, v3
     434:      	fadd.4s	v2, v2, v4
     438:      	add	x10, x8, x9
     43c:      	stp	q1, q2, [x10]
     440:      	add	x9, x9, #0x20
     444:      	cmp	x9, #0x2, lsl #12       ; =0x2000
     448:      	b.ne	0x400 <ltmp0+0x400>
     44c:      	fmul.4s	v0, v7, v0
     450:      	fmul.4s	v1, v16, v17
     454:      	fadd.4s	v0, v1, v0
     458:      	ldr	x8, [sp, #0xa8]
     45c:      	str	s0, [x24, x8]
     460:      	ldr	x8, [sp, #0xc0]
     464:      	orr	w8, w8, #0x2
     468:      	add	x21, x8, x8, lsl #11
     46c:      	lsl	x25, x21, #3
     470:      	add	x22, x23, x25
     474:      	add	x0, sp, #0x6, lsl #12   ; =0x6000
     478:      	add	x0, x0, #0x320
     47c:      	mov	x1, x22
     480:      	mov	w2, #0x2000             ; =8192
     484:      	bl	0x484 <ltmp0+0x484>
     488:      	add	x20, x25, #0x2, lsl #12 ; =0x2000
     48c:      	ldr	s0, [x23, x20]
     490:      	str	q0, [sp, #0xb0]
     494:      	str	q0, [sp, #0x8320]
     498:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
     49c:      	add	x0, x0, #0x300
     4a0:      	mov	w8, #0x2004             ; =8196
     4a4:      	add	x1, x22, x8
     4a8:      	mov	w2, #0x2000             ; =8192
     4ac:      	bl	0x4ac <ltmp0+0x4ac>
     4b0:      	mov	w8, #0x4004             ; =16388
     4b4:      	add	x8, x25, x8
     4b8:      	str	x8, [sp, #0xa8]
     4bc:      	ldr	s0, [x23, x8]
     4c0:      	str	q0, [sp, #0x90]
     4c4:      	str	q0, [sp, #0x6300]
     4c8:      	lsl	x21, x21, #2
     4cc:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
     4d0:      	add	x0, x0, #0x2e0
     4d4:      	ldr	x19, [sp, #0xd0]
     4d8:      	add	x1, x19, x21
     4dc:      	mov	w2, #0x2000             ; =8192
     4e0:      	bl	0x4e0 <ltmp0+0x4e0>
     4e4:      	add	x22, x21, #0x2, lsl #12 ; =0x2000
     4e8:      	ldr	s0, [x19, x22]
     4ec:      	str	q0, [sp, #0x80]
     4f0:      	str	q0, [sp, #0x42e0]
     4f4:      	add	x0, sp, #0x2c0
     4f8:      	ldr	x26, [sp, #0xe0]
     4fc:      	add	x1, x26, x21
     500:      	mov	w2, #0x2000             ; =8192
     504:      	bl	0x504 <ltmp0+0x504>
     508:      	add	x12, sp, #0x4, lsl #12  ; =0x4000
     50c:      	add	x12, x12, #0x300
     510:      	add	x11, sp, #0x6, lsl #12  ; =0x6000
     514:      	add	x11, x11, #0x320
     518:      	mov	x9, #0x0                ; =0
     51c:      	ldr	s0, [x26, x22]
     520:      	str	q0, [sp, #0x22c0]
     524:      	add	x8, x24, x25
     528:      	add	x10, x11, x9
     52c:      	ldp	q1, q2, [x10]
     530:      	add	x10, x27, x9
     534:      	ldp	q3, q4, [x10]
     538:      	fmul.4s	v2, v2, v4
     53c:      	fmul.4s	v1, v1, v3
     540:      	add	x10, x12, x9
     544:      	ldp	q3, q4, [x10]
     548:      	add	x10, x28, x9
     54c:      	ldp	q5, q6, [x10]
     550:      	fmul.4s	v4, v4, v6
     554:      	fmul.4s	v3, v3, v5
     558:      	fsub.4s	v1, v1, v3
     55c:      	fsub.4s	v2, v2, v4
     560:      	add	x10, x8, x9
     564:      	stp	q1, q2, [x10]
     568:      	add	x9, x9, #0x20
     56c:      	cmp	x9, #0x2, lsl #12       ; =0x2000
     570:      	b.ne	0x528 <ltmp0+0x528>
     574:      	mov	x9, #0x0                ; =0
     578:      	ldr	q7, [sp, #0xb0]
     57c:      	ldp	q17, q16, [sp, #0x80]
     580:      	fmul.4s	v1, v7, v17
     584:      	fmul.4s	v2, v16, v0
     588:      	fsub.4s	v1, v1, v2
     58c:      	str	s1, [x24, x20]
     590:      	mov	w10, #0x2004            ; =8196
     594:      	add	x8, x8, x10
     598:      	add	x10, x11, x9
     59c:      	ldp	q1, q2, [x10]
     5a0:      	add	x10, x28, x9
     5a4:      	ldp	q3, q4, [x10]
     5a8:      	fmul.4s	v2, v2, v4
     5ac:      	fmul.4s	v1, v1, v3
     5b0:      	add	x10, x12, x9
     5b4:      	ldp	q3, q4, [x10]
     5b8:      	add	x10, x27, x9
     5bc:      	ldp	q5, q6, [x10]
     5c0:      	fmul.4s	v4, v4, v6
     5c4:      	fmul.4s	v3, v3, v5
     5c8:      	fadd.4s	v1, v1, v3
     5cc:      	fadd.4s	v2, v2, v4
     5d0:      	add	x10, x8, x9
     5d4:      	stp	q1, q2, [x10]
     5d8:      	add	x9, x9, #0x20
     5dc:      	cmp	x9, #0x2, lsl #12       ; =0x2000
     5e0:      	b.ne	0x598 <ltmp0+0x598>
     5e4:      	fmul.4s	v0, v7, v0
     5e8:      	fmul.4s	v1, v16, v17
     5ec:      	fadd.4s	v0, v1, v0
     5f0:      	ldr	x8, [sp, #0xa8]
     5f4:      	str	s0, [x24, x8]
     5f8:      	ldr	x8, [sp, #0xc0]
     5fc:      	orr	w8, w8, #0x3
     600:      	add	x25, x8, x8, lsl #11
     604:      	lsl	x20, x25, #3
     608:      	add	x22, x23, x20
     60c:      	add	x0, sp, #0x6, lsl #12   ; =0x6000
     610:      	add	x0, x0, #0x320
     614:      	mov	x1, x22
     618:      	mov	w2, #0x2000             ; =8192
     61c:      	bl	0x61c <ltmp0+0x61c>
     620:      	add	x21, x20, #0x2, lsl #12 ; =0x2000
     624:      	ldr	s0, [x23, x21]
     628:      	str	q0, [sp, #0xc0]
     62c:      	str	q0, [sp, #0x8320]
     630:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
     634:      	add	x0, x0, #0x300
     638:      	mov	w8, #0x2004             ; =8196
     63c:      	add	x1, x22, x8
     640:      	mov	w2, #0x2000             ; =8192
     644:      	bl	0x644 <ltmp0+0x644>
     648:      	mov	w8, #0x4004             ; =16388
     64c:      	add	x22, x20, x8
     650:      	ldr	s0, [x23, x22]
     654:      	str	q0, [sp, #0xb0]
     658:      	str	q0, [sp, #0x6300]
     65c:      	lsl	x23, x25, #2
     660:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
     664:      	add	x0, x0, #0x2e0
     668:      	ldr	x19, [sp, #0xd0]
     66c:      	add	x1, x19, x23
     670:      	mov	w2, #0x2000             ; =8192
     674:      	bl	0x674 <ltmp0+0x674>
     678:      	add	x25, x23, #0x2, lsl #12 ; =0x2000
     67c:      	ldr	s0, [x19, x25]
     680:      	str	q0, [sp, #0xd0]
     684:      	str	q0, [sp, #0x42e0]
     688:      	add	x0, sp, #0x2c0
     68c:      	ldr	x26, [sp, #0xe0]
     690:      	add	x1, x26, x23
     694:      	mov	w2, #0x2000             ; =8192
     698:      	bl	0x698 <ltmp0+0x698>
     69c:      	add	x4, sp, #0x4, lsl #12   ; =0x4000
     6a0:      	add	x4, x4, #0x300
     6a4:      	add	x7, sp, #0x6, lsl #12   ; =0x6000
     6a8:      	add	x7, x7, #0x320
     6ac:      	mov	x9, #0x0                ; =0
     6b0:      	ldr	s0, [x26, x25]
     6b4:      	str	q0, [sp, #0x22c0]
     6b8:      	add	x8, x24, x20
     6bc:      	add	x10, x7, x9
     6c0:      	ldp	q1, q2, [x10]
     6c4:      	add	x10, x27, x9
     6c8:      	ldp	q3, q4, [x10]
     6cc:      	fmul.4s	v2, v2, v4
     6d0:      	fmul.4s	v1, v1, v3
     6d4:      	add	x10, x4, x9
     6d8:      	ldp	q3, q4, [x10]
     6dc:      	add	x10, x28, x9
     6e0:      	ldp	q5, q6, [x10]
     6e4:      	fmul.4s	v4, v4, v6
     6e8:      	fmul.4s	v3, v3, v5
     6ec:      	fsub.4s	v1, v1, v3
     6f0:      	fsub.4s	v2, v2, v4
     6f4:      	add	x10, x8, x9
     6f8:      	stp	q1, q2, [x10]
     6fc:      	add	x9, x9, #0x20
     700:      	cmp	x9, #0x2, lsl #12       ; =0x2000
     704:      	b.ne	0x6bc <ltmp0+0x6bc>
     708:      	mov	x9, #0x0                ; =0
     70c:      	ldp	q7, q17, [sp, #0xc0]
     710:      	fmul.4s	v1, v7, v17
     714:      	ldr	q16, [sp, #0xb0]
     718:      	fmul.4s	v2, v16, v0
     71c:      	fsub.4s	v1, v1, v2
     720:      	str	s1, [x24, x21]
     724:      	mov	w10, #0x2004            ; =8196
     728:      	add	x8, x8, x10
     72c:      	ldp	w3, w5, [sp, #0x60]
     730:      	ldr	x6, [sp, #0x70]
     734:      	ldr	w20, [sp, #0x6c]
     738:      	add	x10, x7, x9
     73c:      	ldp	q1, q2, [x10]
     740:      	add	x10, x28, x9
     744:      	ldp	q3, q4, [x10]
     748:      	fmul.4s	v2, v2, v4
     74c:      	fmul.4s	v1, v1, v3
     750:      	add	x10, x4, x9
     754:      	ldp	q3, q4, [x10]
     758:      	add	x10, x27, x9
     75c:      	ldp	q5, q6, [x10]
     760:      	fmul.4s	v4, v4, v6
     764:      	fmul.4s	v3, v3, v5
     768:      	fadd.4s	v1, v1, v3
     76c:      	fadd.4s	v2, v2, v4
     770:      	add	x10, x8, x9
     774:      	stp	q1, q2, [x10]
     778:      	add	x9, x9, #0x20
     77c:      	cmp	x9, #0x2, lsl #12       ; =0x2000
     780:      	b.ne	0x738 <ltmp0+0x738>
     784:      	fmul.4s	v0, v7, v0
     788:      	fmul.4s	v1, v16, v17
     78c:      	fadd.4s	v0, v1, v0
     790:      	str	s0, [x24, x22]
     794:      	b	0x9c <ltmp0+0x9c>
     798:      	lsr	x8, x9, #3
     79c:      	str	x8, [sp, #0xb0]
     7a0:      	str	x9, [sp, #0x48]
     7a4:      	cmp	x9, #0x8
     7a8:      	b.lo	0x9a0 <ltmp0+0x9a0>
     7ac:      	mov	x23, #0x0               ; =0
     7b0:      	ldr	x8, [sp, #0x40]
     7b4:      	ldr	x10, [x8]
     7b8:      	ldr	x9, [x8, #0x10]
     7bc:      	str	x9, [sp, #0xa8]
     7c0:      	ldr	x9, [x8, #0x20]
     7c4:      	str	x9, [sp, #0x90]
     7c8:      	ldr	x24, [x8, #0x30]
     7cc:      	ldr	x8, [sp, #0x70]
     7d0:      	lsl	w9, w8, #2
     7d4:      	stp	x9, x10, [sp, #0x78]
     7d8:      	and	x8, x8, #0x7ffffff
     7dc:      	mov	w9, #0x20               ; =32
     7e0:      	movk	w9, #0x1, lsl #16
     7e4:      	umaddl	x25, w8, w9, x24
     7e8:      	mov	w8, #0x2004             ; =8196
     7ec:      	add	x21, x25, x8
     7f0:      	ldp	x8, x27, [sp, #0x78]
     7f4:      	add	w8, w23, w8
     7f8:      	and	x8, x8, #0x1fffffff
     7fc:      	add	x26, x8, x8, lsl #11
     800:      	lsl	x19, x26, #3
     804:      	add	x22, x27, x19
     808:      	add	x0, sp, #0x6, lsl #12   ; =0x6000
     80c:      	add	x0, x0, #0x320
     810:      	mov	x1, x22
     814:      	mov	w2, #0x2000             ; =8192
     818:      	bl	0x818 <ltmp0+0x818>
     81c:      	add	x20, x19, #0x2, lsl #12 ; =0x2000
     820:      	ldr	s0, [x27, x20]
     824:      	str	q0, [sp, #0xe0]
     828:      	str	q0, [sp, #0x8320]
     82c:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
     830:      	add	x0, x0, #0x300
     834:      	mov	w8, #0x2004             ; =8196
     838:      	add	x1, x22, x8
     83c:      	mov	w2, #0x2000             ; =8192
     840:      	bl	0x840 <ltmp0+0x840>
     844:      	mov	w8, #0x4004             ; =16388
     848:      	add	x22, x19, x8
     84c:      	ldr	s0, [x27, x22]
     850:      	str	q0, [sp, #0xd0]
     854:      	str	q0, [sp, #0x6300]
     858:      	lsl	x19, x26, #2
     85c:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
     860:      	add	x0, x0, #0x2e0
     864:      	ldr	x27, [sp, #0xa8]
     868:      	add	x1, x27, x19
     86c:      	mov	w2, #0x2000             ; =8192
     870:      	bl	0x870 <ltmp0+0x870>
     874:      	add	x26, x19, #0x2, lsl #12 ; =0x2000
     878:      	ldr	s0, [x27, x26]
     87c:      	add	x27, sp, #0x2, lsl #12  ; =0x2000
     880:      	add	x27, x27, #0x2e0
     884:      	str	q0, [sp, #0xc0]
     888:      	str	q0, [sp, #0x42e0]
     88c:      	add	x0, sp, #0x2c0
     890:      	ldr	x28, [sp, #0x90]
     894:      	add	x1, x28, x19
     898:      	mov	w2, #0x2000             ; =8192
     89c:      	bl	0x89c <ltmp0+0x89c>
     8a0:      	add	x4, sp, #0x4, lsl #12   ; =0x4000
     8a4:      	add	x4, x4, #0x300
     8a8:      	add	x7, sp, #0x6, lsl #12   ; =0x6000
     8ac:      	add	x7, x7, #0x320
     8b0:      	mov	x8, #0x0                ; =0
     8b4:      	ldr	s0, [x28, x26]
     8b8:      	add	x28, sp, #0x2c0
     8bc:      	str	q0, [sp, #0x22c0]
     8c0:      	add	x9, x7, x8
     8c4:      	ldp	q1, q2, [x9]
     8c8:      	add	x9, x27, x8
     8cc:      	ldp	q3, q4, [x9]
     8d0:      	fmul.4s	v2, v2, v4
     8d4:      	fmul.4s	v1, v1, v3
     8d8:      	add	x9, x4, x8
     8dc:      	ldp	q3, q4, [x9]
     8e0:      	add	x9, x28, x8
     8e4:      	ldp	q5, q6, [x9]
     8e8:      	fmul.4s	v4, v4, v6
     8ec:      	fmul.4s	v3, v3, v5
     8f0:      	fsub.4s	v1, v1, v3
     8f4:      	fsub.4s	v2, v2, v4
     8f8:      	add	x9, x25, x8
     8fc:      	stp	q1, q2, [x9]
     900:      	add	x8, x8, #0x20
     904:      	cmp	x8, #0x2, lsl #12       ; =0x2000
     908:      	b.ne	0x8c0 <ltmp0+0x8c0>
     90c:      	mov	x8, #0x0                ; =0
     910:      	ldp	q16, q7, [sp, #0xd0]
     914:      	ldr	q17, [sp, #0xc0]
     918:      	fmul.4s	v1, v7, v17
     91c:      	fmul.4s	v2, v16, v0
     920:      	fsub.4s	v1, v1, v2
     924:      	str	s1, [x24, x20]
     928:      	add	x9, x7, x8
     92c:      	ldp	q1, q2, [x9]
     930:      	add	x9, x28, x8
     934:      	ldp	q3, q4, [x9]
     938:      	fmul.4s	v2, v2, v4
     93c:      	fmul.4s	v1, v1, v3
     940:      	add	x9, x4, x8
     944:      	ldp	q3, q4, [x9]
     948:      	add	x9, x27, x8
     94c:      	ldp	q5, q6, [x9]
     950:      	fmul.4s	v4, v4, v6
     954:      	fmul.4s	v3, v3, v5
     958:      	fadd.4s	v1, v1, v3
     95c:      	fadd.4s	v2, v2, v4
     960:      	add	x9, x21, x8
     964:      	stp	q1, q2, [x9]
     968:      	add	x8, x8, #0x20
     96c:      	cmp	x8, #0x2, lsl #12       ; =0x2000
     970:      	b.ne	0x928 <ltmp0+0x928>
     974:      	fmul.4s	v0, v7, v0
     978:      	fmul.4s	v1, v16, v17
     97c:      	fadd.4s	v0, v1, v0
     980:      	str	s0, [x24, x22]
     984:      	add	x23, x23, #0x1
     988:      	mov	w8, #0x4008             ; =16392
     98c:      	add	x25, x25, x8
     990:      	add	x21, x21, x8
     994:      	ldr	x8, [sp, #0xb0]
     998:      	cmp	x23, x8
     99c:      	b.ne	0x7f0 <ltmp0+0x7f0>
     9a0:      	ldr	x8, [sp, #0x48]
     9a4:      	and	w8, w8, #0x7
     9a8:      	ldp	w3, w5, [sp, #0x60]
     9ac:      	ldr	w20, [sp, #0x6c]
     9b0:      	ldr	x6, [sp, #0x70]
     9b4:      	cbz	w8, 0x9c <ltmp0+0x9c>
     9b8:      	dup.4s	v1, w8
     9bc:      	ldp	q0, q2, [sp, #0x20]
     9c0:      	cmhi.4s	v0, v1, v0
     9c4:      	cmhi.4s	v1, v1, v2
     9c8:      	uzp1.8h	v2, v1, v0
     9cc:      	umaxv.8h	h3, v2
     9d0:      	fmov	w8, s3
     9d4:      	tbz	w8, #0x0, 0x9c <ltmp0+0x9c>
     9d8:      	mov	x9, #0x0                ; =0
     9dc:      	ldr	x11, [sp, #0x40]
     9e0:      	ldr	x15, [x11]
     9e4:      	ldr	x13, [x11, #0x10]
     9e8:      	ldr	x10, [x11, #0x20]
     9ec:      	ubfiz	w8, w6, #2, #27
     9f0:      	ldr	x12, [sp, #0xb0]
     9f4:      	orr	w8, w8, w12
     9f8:      	dup.4s	v3, w8
     9fc:      	ldr	x8, [x11, #0x30]
     a00:      	and.16b	v5, v1, v3
     a04:      	and.16b	v3, v0, v3
     a08:      	ushll2.2d	v4, v3, #0x0
     a0c:      	ushll2.2d	v6, v5, #0x0
     a10:      	ushll.2d	v7, v3, #0x0
     a14:      	ushll.2d	v5, v5, #0x0
     a18:      	fmov	x14, d5
     a1c:      	mov	w11, #0x4008            ; =16392
     a20:      	umaddl	x11, w14, w11, x15
     a24:      	ldr	q3, [sp, #0x10]
     a28:      	and.16b	v2, v2, v3
     a2c:      	addv.8h	h2, v2
     a30:      	fmov	w12, s2
     a34:      	b	0xa58 <ltmp0+0xa58>
     a38:      	add	x16, x7, x9
     a3c:      	ldp	q17, q18, [x16]
     a40:      	bif.16b	v16, v18, v0
     a44:      	bif.16b	v3, v17, v1
     a48:      	stp	q3, q16, [x16]
     a4c:      	add	x9, x9, #0x20
     a50:      	cmp	x9, #0x2, lsl #12       ; =0x2000
     a54:      	b.eq	0xaec <ltmp0+0xaec>
     a58:      	add	x16, x11, x9
     a5c:      	movi.2d	v3, #0000000000000000
     a60:      	movi.2d	v16, #0000000000000000
     a64:      	tbnz	w12, #0x0, 0xa8c <ltmp0+0xa8c>
     a68:      	and	w17, w12, #0xff
     a6c:      	tbnz	w17, #0x1, 0xa98 <ltmp0+0xa98>
     a70:      	tbnz	w17, #0x2, 0xaa4 <ltmp0+0xaa4>
     a74:      	tbnz	w17, #0x3, 0xab0 <ltmp0+0xab0>
     a78:      	tbnz	w17, #0x4, 0xabc <ltmp0+0xabc>
     a7c:      	tbnz	w17, #0x5, 0xac8 <ltmp0+0xac8>
     a80:      	tbnz	w17, #0x6, 0xad4 <ltmp0+0xad4>
     a84:      	tbz	w17, #0x7, 0xa38 <ltmp0+0xa38>
     a88:      	b	0xae0 <ltmp0+0xae0>
     a8c:      	ldr	s3, [x16]
     a90:      	and	w17, w12, #0xff
     a94:      	tbz	w17, #0x1, 0xa70 <ltmp0+0xa70>
     a98:      	add	x0, x16, #0x4
     a9c:      	ld1.s	{ v3 }[1], [x0]
     aa0:      	tbz	w17, #0x2, 0xa74 <ltmp0+0xa74>
     aa4:      	add	x0, x16, #0x8
     aa8:      	ld1.s	{ v3 }[2], [x0]
     aac:      	tbz	w17, #0x3, 0xa78 <ltmp0+0xa78>
     ab0:      	add	x0, x16, #0xc
     ab4:      	ld1.s	{ v3 }[3], [x0]
     ab8:      	tbz	w17, #0x4, 0xa7c <ltmp0+0xa7c>
     abc:      	add	x0, x16, #0x10
     ac0:      	ld1.s	{ v16 }[0], [x0]
     ac4:      	tbz	w17, #0x5, 0xa80 <ltmp0+0xa80>
     ac8:      	add	x0, x16, #0x14
     acc:      	ld1.s	{ v16 }[1], [x0]
     ad0:      	tbz	w17, #0x6, 0xa84 <ltmp0+0xa84>
     ad4:      	add	x0, x16, #0x18
     ad8:      	ld1.s	{ v16 }[2], [x0]
     adc:      	tbz	w17, #0x7, 0xa38 <ltmp0+0xa38>
     ae0:      	add	x16, x16, #0x1c
     ae4:      	ld1.s	{ v16 }[3], [x16]
     ae8:      	b	0xa38 <ltmp0+0xa38>
     aec:      	xtn.4h	v3, v1
     af0:      	uzp1.8b	v16, v3, v0
     af4:      	ushll.2d	v3, v1, #0x0
     af8:      	adrp	x9, 0x0 <ltmp0>
     afc:      	ldr	q17, [x9]
     b00:      	and.16b	v22, v3, v17
     b04:      	movi.2d	v3, #0000000000000000
     b08:      	mov.b	v3[0], v16[0]
     b0c:      	adrp	x9, 0x0 <ltmp0>
     b10:      	ldr	d17, [x9]
     b14:      	str	d17, [sp, #0x80]
     b18:      	and.8b	v17, v3, v17
     b1c:      	addv.8b	b17, v17
     b20:      	fmov	w11, s17
     b24:      	umaxv.8b	b17, v3
     b28:      	fmov	w16, s17
     b2c:      	rbit	w9, w11
     b30:      	clz	w9, w9
     b34:      	tst	w16, #0x1
     b38:      	csel	w9, w9, wzr, ne
     b3c:      	mov	w12, #0x800             ; =2048
     b40:      	dup.2d	v19, x12
     b44:      	orr.16b	v17, v22, v19
     b48:      	mov	w12, #0x1002            ; =4098
     b4c:      	dup.2s	v18, w12
     b50:      	xtn.2s	v26, v5
     b54:      	str	q17, [sp, #0x90]
     b58:      	mov.16b	v5, v17
     b5c:      	umlal.2d	v5, v26, v18
     b60:      	movi.2d	v17, #0000000000000000
     b64:      	mov.b	v17[0], v16[0]
     b68:      	ushll.2d	v16, v17, #0x0
     b6c:      	shl.2d	v16, v16, #0x3f
     b70:      	cmlt.2d	v16, v16, #0
     b74:      	str	q5, [sp, #0xe0]
     b78:      	and.16b	v16, v16, v5
     b7c:      	movi.2d	v5, #0000000000000000
     b80:      	stp	q5, q5, [sp, #0x290]
     b84:      	stp	q16, q5, [sp, #0x270]
     b88:      	and	x12, x9, #0x7
     b8c:      	add	x17, sp, #0x270
     b90:      	ldr	x12, [x17, x12, lsl #3]
     b94:      	sub	x12, x12, x9
     b98:      	add	x12, x15, x12, lsl #2
     b9c:      	movi.2d	v16, #0000000000000000
     ba0:      	movi.2d	v17, #0000000000000000
     ba4:      	tbnz	w16, #0x0, 0x15fc <ltmp0+0x15fc>
     ba8:      	tbnz	w11, #0x1, 0x1604 <ltmp0+0x1604>
     bac:      	tbnz	w11, #0x2, 0x1610 <ltmp0+0x1610>
     bb0:      	tbnz	w11, #0x3, 0x161c <ltmp0+0x161c>
     bb4:      	tbnz	w11, #0x4, 0x1628 <ltmp0+0x1628>
     bb8:      	tbnz	w11, #0x5, 0x1634 <ltmp0+0x1634>
     bbc:      	tbnz	w11, #0x6, 0x1640 <ltmp0+0x1640>
     bc0:      	tbz	w11, #0x7, 0xbcc <ltmp0+0xbcc>
     bc4:      	add	x12, x12, #0x1c
     bc8:      	ld1.s	{ v17 }[3], [x12]
     bcc:      	mov	x17, #0x0               ; =0
     bd0:      	sshll.2d	v20, v0, #0x0
     bd4:      	sshll2.2d	v21, v1, #0x0
     bd8:      	sshll2.2d	v15, v0, #0x0
     bdc:      	adrp	x12, 0x0 <ltmp0>
     be0:      	ldr	q23, [x12]
     be4:      	and.16b	v23, v15, v23
     be8:      	adrp	x12, 0x0 <ltmp0>
     bec:      	ldr	q24, [x12]
     bf0:      	and.16b	v24, v21, v24
     bf4:      	adrp	x12, 0x0 <ltmp0>
     bf8:      	ldr	q25, [x12]
     bfc:      	and.16b	v25, v20, v25
     c00:      	orr.16b	v8, v25, v19
     c04:      	orr.16b	v9, v24, v19
     c08:      	orr.16b	v31, v23, v19
     c0c:      	str	d26, [sp, #0xa8]
     c10:      	umull.2d	v27, v26, v18
     c14:      	xtn.2s	v10, v6
     c18:      	umull.2d	v28, v10, v18
     c1c:      	xtn.2s	v11, v7
     c20:      	umull.2d	v13, v11, v18
     c24:      	xtn.2s	v12, v4
     c28:      	umull.2d	v14, v12, v18
     c2c:      	mov.16b	v4, v31
     c30:      	umlal.2d	v4, v12, v18
     c34:      	str	q4, [sp, #0xd0]
     c38:      	mov.16b	v4, v9
     c3c:      	umlal.2d	v4, v10, v18
     c40:      	str	q4, [sp, #0xc0]
     c44:      	mov.16b	v4, v8
     c48:      	umlal.2d	v4, v11, v18
     c4c:      	str	q4, [sp, #0xb0]
     c50:      	adrp	x12, 0x0 <ltmp0>
     c54:      	ldr	q4, [x12]
     c58:      	mov	w12, #0x2000            ; =8192
     c5c:      	dup.2d	v6, x12
     c60:      	sshll.2d	v7, v1, #0x0
     c64:      	bif.16b	v4, v6, v7
     c68:      	adrp	x12, 0x0 <ltmp0>
     c6c:      	ldr	q7, [x12]
     c70:      	sshll.2d	v18, v0, #0x0
     c74:      	bif.16b	v7, v6, v18
     c78:      	adrp	x12, 0x0 <ltmp0>
     c7c:      	ldr	q18, [x12]
     c80:      	bif.16b	v18, v6, v21
     c84:      	adrp	x12, 0x0 <ltmp0>
     c88:      	ldr	q19, [x12]
     c8c:      	bit.16b	v6, v19, v15
     c90:      	stp	q7, q6, [sp, #0x250]
     c94:      	stp	q4, q18, [sp, #0x230]
     c98:      	and	x12, x9, #0x7
     c9c:      	add	x16, sp, #0x230
     ca0:      	ldr	x12, [x16, x12, lsl #3]
     ca4:      	sub	x12, x12, x9, lsl #2
     ca8:      	tst	w11, #0xff
     cac:      	csel	x11, xzr, x12, eq
     cb0:      	add	x12, x7, x11
     cb4:      	ldp	q4, q6, [x12]
     cb8:      	zip2.8b	v7, v3, v0
     cbc:      	ushll.4s	v7, v7, #0x0
     cc0:      	shl.4s	v7, v7, #0x1f
     cc4:      	cmlt.4s	v7, v7, #0
     cc8:      	mov.16b	v5, v7
     ccc:      	bsl.16b	v5, v17, v6
     cd0:      	zip1.8b	v6, v3, v0
     cd4:      	ushll.4s	v6, v6, #0x0
     cd8:      	shl.4s	v6, v6, #0x1f
     cdc:      	cmlt.4s	v6, v6, #0
     ce0:      	bit.16b	v4, v16, v6
     ce4:      	mov.16b	v30, v4
     ce8:      	stp	q4, q5, [x12]
     cec:      	mov.16b	v26, v5
     cf0:      	fmov	x12, d27
     cf4:      	ushll2.2d	v4, v0, #0x0
     cf8:      	mov	w16, #0x1               ; =1
     cfc:      	dup.2d	v6, x16
     d00:      	and.16b	v7, v4, v6
     d04:      	ushll2.2d	v4, v1, #0x0
     d08:      	and.16b	v16, v4, v6
     d0c:      	ushll.2d	v4, v0, #0x0
     d10:      	and.16b	v17, v4, v6
     d14:      	ushll.2d	v4, v1, #0x0
     d18:      	and.16b	v18, v4, v6
     d1c:      	lsl	x12, x12, #2
     d20:      	mov	w16, #0x2004            ; =8196
     d24:      	add	x16, x15, x16
     d28:      	add	x16, x16, x12
     d2c:      	movi.2d	v15, #0000000000000000
     d30:      	movi.2d	v4, #0000000000000000
     d34:      	movi.2d	v6, #0000000000000000
     d38:      	movi.2d	v19, #0000000000000000
     d3c:      	b	0xd70 <ltmp0+0xd70>
     d40:      	add	x17, x4, x17
     d44:      	ldp	q5, q29, [x17]
     d48:      	bif.16b	v21, v29, v0
     d4c:      	bit.16b	v5, v20, v1
     d50:      	stp	q5, q21, [x17]
     d54:      	add.2d	v4, v4, v16
     d58:      	add.2d	v6, v6, v17
     d5c:      	add.2d	v19, v19, v7
     d60:      	add.2d	v15, v15, v18
     d64:      	fmov	x17, d15
     d68:      	cmp	x17, #0x100
     d6c:      	b.ge	0xe0c <ltmp0+0xe0c>
     d70:      	fmov	w1, s2
     d74:      	lsl	x17, x17, #5
     d78:      	add	x0, x16, x17
     d7c:      	movi.2d	v20, #0000000000000000
     d80:      	movi.2d	v21, #0000000000000000
     d84:      	tbnz	w1, #0x0, 0xdac <ltmp0+0xdac>
     d88:      	and	w1, w1, #0xff
     d8c:      	tbnz	w1, #0x1, 0xdb8 <ltmp0+0xdb8>
     d90:      	tbnz	w1, #0x2, 0xdc4 <ltmp0+0xdc4>
     d94:      	tbnz	w1, #0x3, 0xdd0 <ltmp0+0xdd0>
     d98:      	tbnz	w1, #0x4, 0xddc <ltmp0+0xddc>
     d9c:      	tbnz	w1, #0x5, 0xde8 <ltmp0+0xde8>
     da0:      	tbnz	w1, #0x6, 0xdf4 <ltmp0+0xdf4>
     da4:      	tbz	w1, #0x7, 0xd40 <ltmp0+0xd40>
     da8:      	b	0xe00 <ltmp0+0xe00>
     dac:      	ldr	s20, [x0]
     db0:      	and	w1, w1, #0xff
     db4:      	tbz	w1, #0x1, 0xd90 <ltmp0+0xd90>
     db8:      	add	x2, x0, #0x4
     dbc:      	ld1.s	{ v20 }[1], [x2]
     dc0:      	tbz	w1, #0x2, 0xd94 <ltmp0+0xd94>
     dc4:      	add	x2, x0, #0x8
     dc8:      	ld1.s	{ v20 }[2], [x2]
     dcc:      	tbz	w1, #0x3, 0xd98 <ltmp0+0xd98>
     dd0:      	add	x2, x0, #0xc
     dd4:      	ld1.s	{ v20 }[3], [x2]
     dd8:      	tbz	w1, #0x4, 0xd9c <ltmp0+0xd9c>
     ddc:      	add	x2, x0, #0x10
     de0:      	ld1.s	{ v21 }[0], [x2]
     de4:      	tbz	w1, #0x5, 0xda0 <ltmp0+0xda0>
     de8:      	add	x2, x0, #0x14
     dec:      	ld1.s	{ v21 }[1], [x2]
     df0:      	tbz	w1, #0x6, 0xda4 <ltmp0+0xda4>
     df4:      	add	x2, x0, #0x18
     df8:      	ld1.s	{ v21 }[2], [x2]
     dfc:      	tbz	w1, #0x7, 0xd40 <ltmp0+0xd40>
     e00:      	add	x0, x0, #0x1c
     e04:      	ld1.s	{ v21 }[3], [x0]
     e08:      	b	0xd40 <ltmp0+0xd40>
     e0c:      	add.2d	v4, v22, v27
     e10:      	add.2d	v5, v24, v28
     e14:      	add.2d	v6, v25, v13
     e18:      	add.2d	v19, v23, v14
     e1c:      	mov	w16, #0x1001            ; =4097
     e20:      	dup.2d	v20, x16
     e24:      	add.2d	v22, v19, v20
     e28:      	add.2d	v23, v6, v20
     e2c:      	add.2d	v24, v5, v20
     e30:      	mov	b5, v3[0]
     e34:      	mov.b	v5[4], v3[1]
     e38:      	add.2d	v25, v4, v20
     e3c:      	ushll.2d	v4, v5, #0x0
     e40:      	shl.2d	v4, v4, #0x3f
     e44:      	cmlt.2d	v4, v4, #0
     e48:      	and.16b	v4, v4, v25
     e4c:      	mov	b5, v3[2]
     e50:      	mov.b	v5[4], v3[3]
     e54:      	ushll.2d	v5, v5, #0x0
     e58:      	shl.2d	v5, v5, #0x3f
     e5c:      	cmlt.2d	v5, v5, #0
     e60:      	and.16b	v5, v5, v24
     e64:      	mov	b6, v3[4]
     e68:      	mov.b	v6[4], v3[5]
     e6c:      	ushll.2d	v6, v6, #0x0
     e70:      	shl.2d	v6, v6, #0x3f
     e74:      	cmlt.2d	v6, v6, #0
     e78:      	and.16b	v6, v6, v23
     e7c:      	mov	b19, v3[6]
     e80:      	mov.b	v19[4], v3[7]
     e84:      	ushll.2d	v19, v19, #0x0
     e88:      	shl.2d	v19, v19, #0x3f
     e8c:      	cmlt.2d	v19, v19, #0
     e90:      	and.16b	v19, v19, v22
     e94:      	shl.8b	v20, v3, #0x7
     e98:      	cmlt.8b	v20, v20, #0
     e9c:      	ldr	d21, [sp, #0x80]
     ea0:      	and.8b	v20, v20, v21
     ea4:      	addv.8b	b15, v20
     ea8:      	fmov	w16, s15
     eac:      	stp	q6, q19, [sp, #0x200]
     eb0:      	stp	q4, q5, [sp, #0x1e0]
     eb4:      	and	x17, x9, #0x7
     eb8:      	add	x0, sp, #0x1e0
     ebc:      	ldr	x17, [x0, x17, lsl #3]
     ec0:      	sub	x17, x17, x9
     ec4:      	add	x15, x15, x17, lsl #2
     ec8:      	movi.2d	v4, #0000000000000000
     ecc:      	movi.2d	v6, #0000000000000000
     ed0:      	tbnz	w16, #0x0, 0x1650 <ltmp0+0x1650>
     ed4:      	mov.16b	v14, v26
     ed8:      	tbnz	w16, #0x1, 0x165c <ltmp0+0x165c>
     edc:      	mov.16b	v26, v30
     ee0:      	ldr	d30, [sp, #0xa8]
     ee4:      	tbnz	w16, #0x2, 0x1670 <ltmp0+0x1670>
     ee8:      	tbnz	w16, #0x3, 0x167c <ltmp0+0x167c>
     eec:      	tbnz	w16, #0x4, 0x1688 <ltmp0+0x1688>
     ef0:      	tbnz	w16, #0x5, 0x1694 <ltmp0+0x1694>
     ef4:      	tbnz	w16, #0x6, 0x16a0 <ltmp0+0x16a0>
     ef8:      	tbz	w16, #0x7, 0xf04 <ltmp0+0xf04>
     efc:      	add	x15, x15, #0x1c
     f00:      	ld1.s	{ v6 }[3], [x15]
     f04:      	mov	x15, #0x0               ; =0
     f08:      	add	x16, x4, x11
     f0c:      	ldp	q5, q19, [x16]
     f10:      	zip2.8b	v20, v3, v0
     f14:      	ushll.4s	v20, v20, #0x0
     f18:      	shl.4s	v20, v20, #0x1f
     f1c:      	cmlt.4s	v20, v20, #0
     f20:      	mov.16b	v27, v20
     f24:      	bsl.16b	v27, v6, v19
     f28:      	zip1.8b	v6, v3, v0
     f2c:      	ushll.4s	v6, v6, #0x0
     f30:      	shl.4s	v6, v6, #0x1f
     f34:      	cmlt.4s	v6, v6, #0
     f38:      	mov.16b	v28, v6
     f3c:      	bsl.16b	v28, v4, v5
     f40:      	stp	q28, q27, [x16]
     f44:      	mov	w16, #0x2004            ; =8196
     f48:      	umaddl	x14, w14, w16, x13
     f4c:      	movi.2d	v13, #0000000000000000
     f50:      	movi.2d	v4, #0000000000000000
     f54:      	movi.2d	v6, #0000000000000000
     f58:      	movi.2d	v19, #0000000000000000
     f5c:      	b	0xf90 <ltmp0+0xf90>
     f60:      	add	x15, x27, x15
     f64:      	ldp	q5, q29, [x15]
     f68:      	bif.16b	v21, v29, v0
     f6c:      	bit.16b	v5, v20, v1
     f70:      	stp	q5, q21, [x15]
     f74:      	add.2d	v4, v4, v16
     f78:      	add.2d	v6, v6, v17
     f7c:      	add.2d	v19, v19, v7
     f80:      	add.2d	v13, v13, v18
     f84:      	fmov	x15, d13
     f88:      	cmp	x15, #0x100
     f8c:      	b.ge	0x102c <ltmp0+0x102c>
     f90:      	fmov	w17, s2
     f94:      	lsl	x15, x15, #5
     f98:      	add	x16, x14, x15
     f9c:      	movi.2d	v20, #0000000000000000
     fa0:      	movi.2d	v21, #0000000000000000
     fa4:      	tbnz	w17, #0x0, 0xfcc <ltmp0+0xfcc>
     fa8:      	and	w17, w17, #0xff
     fac:      	tbnz	w17, #0x1, 0xfd8 <ltmp0+0xfd8>
     fb0:      	tbnz	w17, #0x2, 0xfe4 <ltmp0+0xfe4>
     fb4:      	tbnz	w17, #0x3, 0xff0 <ltmp0+0xff0>
     fb8:      	tbnz	w17, #0x4, 0xffc <ltmp0+0xffc>
     fbc:      	tbnz	w17, #0x5, 0x1008 <ltmp0+0x1008>
     fc0:      	tbnz	w17, #0x6, 0x1014 <ltmp0+0x1014>
     fc4:      	tbz	w17, #0x7, 0xf60 <ltmp0+0xf60>
     fc8:      	b	0x1020 <ltmp0+0x1020>
     fcc:      	ldr	s20, [x16]
     fd0:      	and	w17, w17, #0xff
     fd4:      	tbz	w17, #0x1, 0xfb0 <ltmp0+0xfb0>
     fd8:      	add	x0, x16, #0x4
     fdc:      	ld1.s	{ v20 }[1], [x0]
     fe0:      	tbz	w17, #0x2, 0xfb4 <ltmp0+0xfb4>
     fe4:      	add	x0, x16, #0x8
     fe8:      	ld1.s	{ v20 }[2], [x0]
     fec:      	tbz	w17, #0x3, 0xfb8 <ltmp0+0xfb8>
     ff0:      	add	x0, x16, #0xc
     ff4:      	ld1.s	{ v20 }[3], [x0]
     ff8:      	tbz	w17, #0x4, 0xfbc <ltmp0+0xfbc>
     ffc:      	add	x0, x16, #0x10
    1000:      	ld1.s	{ v21 }[0], [x0]
    1004:      	tbz	w17, #0x5, 0xfc0 <ltmp0+0xfc0>
    1008:      	add	x0, x16, #0x14
    100c:      	ld1.s	{ v21 }[1], [x0]
    1010:      	tbz	w17, #0x6, 0xfc4 <ltmp0+0xfc4>
    1014:      	add	x0, x16, #0x18
    1018:      	ld1.s	{ v21 }[2], [x0]
    101c:      	tbz	w17, #0x7, 0xf60 <ltmp0+0xf60>
    1020:      	add	x16, x16, #0x1c
    1024:      	ld1.s	{ v21 }[3], [x16]
    1028:      	b	0xf60 <ltmp0+0xf60>
    102c:      	mov	w14, #0x801             ; =2049
    1030:      	dup.2s	v13, w14
    1034:      	umlal.2d	v31, v12, v13
    1038:      	umlal.2d	v8, v11, v13
    103c:      	umlal.2d	v9, v10, v13
    1040:      	ldr	q5, [sp, #0x90]
    1044:      	umlal.2d	v5, v30, v13
    1048:      	mov	b4, v3[0]
    104c:      	mov.b	v4[4], v3[1]
    1050:      	ushll.2d	v4, v4, #0x0
    1054:      	shl.2d	v4, v4, #0x3f
    1058:      	cmlt.2d	v4, v4, #0
    105c:      	and.16b	v4, v4, v5
    1060:      	mov	b5, v3[2]
    1064:      	mov.b	v5[4], v3[3]
    1068:      	ushll.2d	v5, v5, #0x0
    106c:      	shl.2d	v5, v5, #0x3f
    1070:      	cmlt.2d	v5, v5, #0
    1074:      	and.16b	v5, v5, v9
    1078:      	mov	b6, v3[4]
    107c:      	mov.b	v6[4], v3[5]
    1080:      	ushll.2d	v6, v6, #0x0
    1084:      	shl.2d	v6, v6, #0x3f
    1088:      	cmlt.2d	v6, v6, #0
    108c:      	mov	b19, v3[6]
    1090:      	mov.b	v19[4], v3[7]
    1094:      	and.16b	v6, v6, v8
    1098:      	ushll.2d	v19, v19, #0x0
    109c:      	shl.2d	v19, v19, #0x3f
    10a0:      	cmlt.2d	v19, v19, #0
    10a4:      	and.16b	v19, v19, v31
    10a8:      	stp	q6, q19, [sp, #0x1b0]
    10ac:      	stp	q4, q5, [sp, #0x190]
    10b0:      	and	x14, x9, #0x7
    10b4:      	add	x15, sp, #0x190
    10b8:      	ldr	x14, [x15, x14, lsl #3]
    10bc:      	fmov	w15, s15
    10c0:      	sub	x14, x14, x9
    10c4:      	lsl	x14, x14, #2
    10c8:      	add	x13, x13, x14
    10cc:      	movi.2d	v4, #0000000000000000
    10d0:      	movi.2d	v6, #0000000000000000
    10d4:      	tbnz	w15, #0x0, 0x16b0 <ltmp0+0x16b0>
    10d8:      	tbnz	w15, #0x1, 0x16b8 <ltmp0+0x16b8>
    10dc:      	tbnz	w15, #0x2, 0x16c4 <ltmp0+0x16c4>
    10e0:      	tbnz	w15, #0x3, 0x16d0 <ltmp0+0x16d0>
    10e4:      	tbnz	w15, #0x4, 0x16dc <ltmp0+0x16dc>
    10e8:      	tbnz	w15, #0x5, 0x16e8 <ltmp0+0x16e8>
    10ec:      	tbnz	w15, #0x6, 0x16f4 <ltmp0+0x16f4>
    10f0:      	tbz	w15, #0x7, 0x10fc <ltmp0+0x10fc>
    10f4:      	add	x13, x13, #0x1c
    10f8:      	ld1.s	{ v6 }[3], [x13]
    10fc:      	mov	x15, #0x0               ; =0
    1100:      	umull.2d	v5, v30, v13
    1104:      	add	x13, x27, x11
    1108:      	ldp	q19, q20, [x13]
    110c:      	zip2.8b	v21, v3, v0
    1110:      	ushll.4s	v21, v21, #0x0
    1114:      	shl.4s	v21, v21, #0x1f
    1118:      	cmlt.4s	v21, v21, #0
    111c:      	mov.16b	v29, v21
    1120:      	bsl.16b	v29, v6, v20
    1124:      	zip1.8b	v6, v3, v0
    1128:      	ushll.4s	v6, v6, #0x0
    112c:      	shl.4s	v6, v6, #0x1f
    1130:      	cmlt.4s	v6, v6, #0
    1134:      	mov.16b	v30, v6
    1138:      	bsl.16b	v30, v4, v19
    113c:      	stp	q30, q29, [x13]
    1140:      	fmov	x13, d5
    1144:      	add	x13, x10, x13, lsl #2
    1148:      	movi.2d	v31, #0000000000000000
    114c:      	movi.2d	v4, #0000000000000000
    1150:      	movi.2d	v6, #0000000000000000
    1154:      	movi.2d	v19, #0000000000000000
    1158:      	b	0x118c <ltmp0+0x118c>
    115c:      	add	x15, x28, x15
    1160:      	ldp	q5, q8, [x15]
    1164:      	bif.16b	v21, v8, v0
    1168:      	bit.16b	v5, v20, v1
    116c:      	stp	q5, q21, [x15]
    1170:      	add.2d	v4, v4, v16
    1174:      	add.2d	v6, v6, v17
    1178:      	add.2d	v19, v19, v7
    117c:      	add.2d	v31, v31, v18
    1180:      	fmov	x15, d31
    1184:      	cmp	x15, #0x100
    1188:      	b.ge	0x1228 <ltmp0+0x1228>
    118c:      	fmov	w17, s2
    1190:      	lsl	x15, x15, #5
    1194:      	add	x16, x13, x15
    1198:      	movi.2d	v20, #0000000000000000
    119c:      	movi.2d	v21, #0000000000000000
    11a0:      	tbnz	w17, #0x0, 0x11c8 <ltmp0+0x11c8>
    11a4:      	and	w17, w17, #0xff
    11a8:      	tbnz	w17, #0x1, 0x11d4 <ltmp0+0x11d4>
    11ac:      	tbnz	w17, #0x2, 0x11e0 <ltmp0+0x11e0>
    11b0:      	tbnz	w17, #0x3, 0x11ec <ltmp0+0x11ec>
    11b4:      	tbnz	w17, #0x4, 0x11f8 <ltmp0+0x11f8>
    11b8:      	tbnz	w17, #0x5, 0x1204 <ltmp0+0x1204>
    11bc:      	tbnz	w17, #0x6, 0x1210 <ltmp0+0x1210>
    11c0:      	tbz	w17, #0x7, 0x115c <ltmp0+0x115c>
    11c4:      	b	0x121c <ltmp0+0x121c>
    11c8:      	ldr	s20, [x16]
    11cc:      	and	w17, w17, #0xff
    11d0:      	tbz	w17, #0x1, 0x11ac <ltmp0+0x11ac>
    11d4:      	add	x0, x16, #0x4
    11d8:      	ld1.s	{ v20 }[1], [x0]
    11dc:      	tbz	w17, #0x2, 0x11b0 <ltmp0+0x11b0>
    11e0:      	add	x0, x16, #0x8
    11e4:      	ld1.s	{ v20 }[2], [x0]
    11e8:      	tbz	w17, #0x3, 0x11b4 <ltmp0+0x11b4>
    11ec:      	add	x0, x16, #0xc
    11f0:      	ld1.s	{ v20 }[3], [x0]
    11f4:      	tbz	w17, #0x4, 0x11b8 <ltmp0+0x11b8>
    11f8:      	add	x0, x16, #0x10
    11fc:      	ld1.s	{ v21 }[0], [x0]
    1200:      	tbz	w17, #0x5, 0x11bc <ltmp0+0x11bc>
    1204:      	add	x0, x16, #0x14
    1208:      	ld1.s	{ v21 }[1], [x0]
    120c:      	tbz	w17, #0x6, 0x11c0 <ltmp0+0x11c0>
    1210:      	add	x0, x16, #0x18
    1214:      	ld1.s	{ v21 }[2], [x0]
    1218:      	tbz	w17, #0x7, 0x115c <ltmp0+0x115c>
    121c:      	add	x16, x16, #0x1c
    1220:      	ld1.s	{ v21 }[3], [x16]
    1224:      	b	0x115c <ltmp0+0x115c>
    1228:      	add	x10, x10, x14
    122c:      	fmov	w13, s15
    1230:      	movi.2d	v4, #0000000000000000
    1234:      	movi.2d	v6, #0000000000000000
    1238:      	tbnz	w13, #0x0, 0x1704 <ltmp0+0x1704>
    123c:      	tbnz	w13, #0x1, 0x170c <ltmp0+0x170c>
    1240:      	tbnz	w13, #0x2, 0x1718 <ltmp0+0x1718>
    1244:      	tbnz	w13, #0x3, 0x1724 <ltmp0+0x1724>
    1248:      	tbnz	w13, #0x4, 0x1730 <ltmp0+0x1730>
    124c:      	tbnz	w13, #0x5, 0x173c <ltmp0+0x173c>
    1250:      	tbnz	w13, #0x6, 0x1748 <ltmp0+0x1748>
    1254:      	tbz	w13, #0x7, 0x1260 <ltmp0+0x1260>
    1258:      	add	x10, x10, #0x1c
    125c:      	ld1.s	{ v6 }[3], [x10]
    1260:      	mov	x13, #0x0               ; =0
    1264:      	add	x10, x28, x11
    1268:      	ldp	q5, q19, [x10]
    126c:      	zip2.8b	v20, v3, v0
    1270:      	ushll.4s	v20, v20, #0x0
    1274:      	shl.4s	v20, v20, #0x1f
    1278:      	cmlt.4s	v20, v20, #0
    127c:      	mov.16b	v31, v20
    1280:      	bsl.16b	v31, v6, v19
    1284:      	zip1.8b	v6, v3, v0
    1288:      	ushll.4s	v6, v6, #0x0
    128c:      	shl.4s	v6, v6, #0x1f
    1290:      	cmlt.4s	v6, v6, #0
    1294:      	mov.16b	v8, v6
    1298:      	bsl.16b	v8, v4, v5
    129c:      	stp	q8, q31, [x10]
    12a0:      	add	x10, x8, x12
    12a4:      	movi.2d	v4, #0000000000000000
    12a8:      	movi.2d	v6, #0000000000000000
    12ac:      	movi.2d	v19, #0000000000000000
    12b0:      	movi.2d	v20, #0000000000000000
    12b4:      	b	0x12d4 <ltmp0+0x12d4>
    12b8:      	add.2d	v6, v6, v16
    12bc:      	add.2d	v19, v19, v17
    12c0:      	add.2d	v20, v20, v7
    12c4:      	add.2d	v4, v4, v18
    12c8:      	fmov	x13, d4
    12cc:      	cmp	x13, #0x100
    12d0:      	b.ge	0x13b4 <ltmp0+0x13b4>
    12d4:      	fmov	w12, s2
    12d8:      	lsl	x11, x13, #5
    12dc:      	add	x13, x7, x11
    12e0:      	ldp	q5, q21, [x13]
    12e4:      	add	x13, x27, x11
    12e8:      	ldp	q10, q9, [x13]
    12ec:      	fmul.4s	v5, v5, v10
    12f0:      	add	x13, x4, x11
    12f4:      	ldp	q12, q10, [x13]
    12f8:      	add	x13, x28, x11
    12fc:      	ldp	q13, q11, [x13]
    1300:      	fmul.4s	v12, v12, v13
    1304:      	fsub.4s	v5, v5, v12
    1308:      	and.16b	v12, v1, v5
    130c:      	add	x11, x10, x11
    1310:      	tbnz	w12, #0x0, 0x1348 <ltmp0+0x1348>
    1314:      	and	w12, w12, #0xff
    1318:      	tbnz	w12, #0x1, 0x1354 <ltmp0+0x1354>
    131c:      	tbnz	w12, #0x2, 0x1360 <ltmp0+0x1360>
    1320:      	tbnz	w12, #0x3, 0x136c <ltmp0+0x136c>
    1324:      	fmul.4s	v5, v21, v9
    1328:      	fmul.4s	v21, v10, v11
    132c:      	fsub.4s	v5, v5, v21
    1330:      	and.16b	v21, v0, v5
    1334:      	tbnz	w12, #0x4, 0x1388 <ltmp0+0x1388>
    1338:      	tbnz	w12, #0x5, 0x1390 <ltmp0+0x1390>
    133c:      	tbnz	w12, #0x6, 0x139c <ltmp0+0x139c>
    1340:      	tbz	w12, #0x7, 0x12b8 <ltmp0+0x12b8>
    1344:      	b	0x13a8 <ltmp0+0x13a8>
    1348:      	str	s12, [x11]
    134c:      	and	w12, w12, #0xff
    1350:      	tbz	w12, #0x1, 0x131c <ltmp0+0x131c>
    1354:      	add	x13, x11, #0x4
    1358:      	st1.s	{ v12 }[1], [x13]
    135c:      	tbz	w12, #0x2, 0x1320 <ltmp0+0x1320>
    1360:      	add	x13, x11, #0x8
    1364:      	st1.s	{ v12 }[2], [x13]
    1368:      	tbz	w12, #0x3, 0x1324 <ltmp0+0x1324>
    136c:      	add	x13, x11, #0xc
    1370:      	st1.s	{ v12 }[3], [x13]
    1374:      	fmul.4s	v5, v21, v9
    1378:      	fmul.4s	v21, v10, v11
    137c:      	fsub.4s	v5, v5, v21
    1380:      	and.16b	v21, v0, v5
    1384:      	tbz	w12, #0x4, 0x1338 <ltmp0+0x1338>
    1388:      	str	s21, [x11, #0x10]
    138c:      	tbz	w12, #0x5, 0x133c <ltmp0+0x133c>
    1390:      	add	x13, x11, #0x14
    1394:      	st1.s	{ v21 }[1], [x13]
    1398:      	tbz	w12, #0x6, 0x1340 <ltmp0+0x1340>
    139c:      	add	x13, x11, #0x18
    13a0:      	st1.s	{ v21 }[2], [x13]
    13a4:      	tbz	w12, #0x7, 0x12b8 <ltmp0+0x12b8>
    13a8:      	add	x11, x11, #0x1c
    13ac:      	st1.s	{ v21 }[3], [x11]
    13b0:      	b	0x12b8 <ltmp0+0x12b8>
    13b4:      	fmul.4s	v4, v26, v30
    13b8:      	fmul.4s	v5, v28, v8
    13bc:      	fsub.4s	v4, v4, v5
    13c0:      	zip1.8b	v5, v3, v0
    13c4:      	ushll.4s	v5, v5, #0x0
    13c8:      	shl.4s	v5, v5, #0x1f
    13cc:      	cmlt.4s	v5, v5, #0
    13d0:      	and.16b	v4, v5, v4
    13d4:      	fmov	w11, s15
    13d8:      	ldr	q6, [sp, #0xe0]
    13dc:      	ldr	q5, [sp, #0xc0]
    13e0:      	stp	q6, q5, [sp, #0x140]
    13e4:      	ldr	q6, [sp, #0xb0]
    13e8:      	ldr	q5, [sp, #0xd0]
    13ec:      	stp	q6, q5, [sp, #0x160]
    13f0:      	and	x12, x9, #0x7
    13f4:      	add	x13, sp, #0x140
    13f8:      	ldr	x12, [x13, x12, lsl #3]
    13fc:      	sub	x12, x12, x9
    1400:      	add	x12, x8, x12, lsl #2
    1404:      	tbnz	w11, #0x0, 0x1758 <ltmp0+0x1758>
    1408:      	tbnz	w11, #0x1, 0x1760 <ltmp0+0x1760>
    140c:      	tbnz	w11, #0x2, 0x176c <ltmp0+0x176c>
    1410:      	tbz	w11, #0x3, 0x141c <ltmp0+0x141c>
    1414:      	add	x13, x12, #0xc
    1418:      	st1.s	{ v4 }[3], [x13]
    141c:      	fmul.4s	v4, v14, v29
    1420:      	fmul.4s	v5, v27, v31
    1424:      	fsub.4s	v4, v4, v5
    1428:      	zip2.8b	v5, v3, v0
    142c:      	ushll.4s	v5, v5, #0x0
    1430:      	shl.4s	v5, v5, #0x1f
    1434:      	cmlt.4s	v5, v5, #0
    1438:      	and.16b	v4, v5, v4
    143c:      	tbnz	w11, #0x4, 0x177c <ltmp0+0x177c>
    1440:      	tbnz	w11, #0x5, 0x1784 <ltmp0+0x1784>
    1444:      	tbnz	w11, #0x6, 0x1790 <ltmp0+0x1790>
    1448:      	tbz	w11, #0x7, 0x1454 <ltmp0+0x1454>
    144c:      	add	x11, x12, #0x1c
    1450:      	st1.s	{ v4 }[3], [x11]
    1454:      	mov	x11, #0x0               ; =0
    1458:      	mov	w12, #0x2004            ; =8196
    145c:      	add	x10, x10, x12
    1460:      	movi.2d	v4, #0000000000000000
    1464:      	movi.2d	v5, #0000000000000000
    1468:      	movi.2d	v6, #0000000000000000
    146c:      	movi.2d	v19, #0000000000000000
    1470:      	b	0x1490 <ltmp0+0x1490>
    1474:      	add.2d	v5, v5, v16
    1478:      	add.2d	v6, v6, v17
    147c:      	add.2d	v19, v19, v7
    1480:      	add.2d	v4, v4, v18
    1484:      	fmov	x11, d4
    1488:      	cmp	x11, #0x100
    148c:      	b.ge	0x1570 <ltmp0+0x1570>
    1490:      	fmov	w12, s2
    1494:      	lsl	x11, x11, #5
    1498:      	add	x13, x7, x11
    149c:      	ldp	q9, q20, [x13]
    14a0:      	add	x13, x28, x11
    14a4:      	ldp	q10, q21, [x13]
    14a8:      	fmul.4s	v11, v9, v10
    14ac:      	add	x13, x4, x11
    14b0:      	ldp	q12, q9, [x13]
    14b4:      	add	x13, x27, x11
    14b8:      	ldp	q13, q10, [x13]
    14bc:      	fmul.4s	v12, v12, v13
    14c0:      	fadd.4s	v11, v11, v12
    14c4:      	and.16b	v11, v1, v11
    14c8:      	add	x11, x10, x11
    14cc:      	tbnz	w12, #0x0, 0x1504 <ltmp0+0x1504>
    14d0:      	and	w12, w12, #0xff
    14d4:      	tbnz	w12, #0x1, 0x1510 <ltmp0+0x1510>
    14d8:      	tbnz	w12, #0x2, 0x151c <ltmp0+0x151c>
    14dc:      	tbnz	w12, #0x3, 0x1528 <ltmp0+0x1528>
    14e0:      	fmul.4s	v20, v20, v21
    14e4:      	fmul.4s	v21, v9, v10
    14e8:      	fadd.4s	v20, v20, v21
    14ec:      	and.16b	v20, v0, v20
    14f0:      	tbnz	w12, #0x4, 0x1544 <ltmp0+0x1544>
    14f4:      	tbnz	w12, #0x5, 0x154c <ltmp0+0x154c>
    14f8:      	tbnz	w12, #0x6, 0x1558 <ltmp0+0x1558>
    14fc:      	tbz	w12, #0x7, 0x1474 <ltmp0+0x1474>
    1500:      	b	0x1564 <ltmp0+0x1564>
    1504:      	str	s11, [x11]
    1508:      	and	w12, w12, #0xff
    150c:      	tbz	w12, #0x1, 0x14d8 <ltmp0+0x14d8>
    1510:      	add	x13, x11, #0x4
    1514:      	st1.s	{ v11 }[1], [x13]
    1518:      	tbz	w12, #0x2, 0x14dc <ltmp0+0x14dc>
    151c:      	add	x13, x11, #0x8
    1520:      	st1.s	{ v11 }[2], [x13]
    1524:      	tbz	w12, #0x3, 0x14e0 <ltmp0+0x14e0>
    1528:      	add	x13, x11, #0xc
    152c:      	st1.s	{ v11 }[3], [x13]
    1530:      	fmul.4s	v20, v20, v21
    1534:      	fmul.4s	v21, v9, v10
    1538:      	fadd.4s	v20, v20, v21
    153c:      	and.16b	v20, v0, v20
    1540:      	tbz	w12, #0x4, 0x14f4 <ltmp0+0x14f4>
    1544:      	str	s20, [x11, #0x10]
    1548:      	tbz	w12, #0x5, 0x14f8 <ltmp0+0x14f8>
    154c:      	add	x13, x11, #0x14
    1550:      	st1.s	{ v20 }[1], [x13]
    1554:      	tbz	w12, #0x6, 0x14fc <ltmp0+0x14fc>
    1558:      	add	x13, x11, #0x18
    155c:      	st1.s	{ v20 }[2], [x13]
    1560:      	tbz	w12, #0x7, 0x1474 <ltmp0+0x1474>
    1564:      	add	x11, x11, #0x1c
    1568:      	st1.s	{ v20 }[3], [x11]
    156c:      	b	0x1474 <ltmp0+0x1474>
    1570:      	fmul.4s	v0, v26, v8
    1574:      	fmul.4s	v1, v28, v30
    1578:      	fadd.4s	v0, v1, v0
    157c:      	zip1.8b	v1, v3, v0
    1580:      	ushll.4s	v1, v1, #0x0
    1584:      	shl.4s	v1, v1, #0x1f
    1588:      	cmlt.4s	v1, v1, #0
    158c:      	and.16b	v0, v1, v0
    1590:      	fmov	w10, s15
    1594:      	stp	q25, q24, [sp, #0xf0]
    1598:      	stp	q23, q22, [sp, #0x110]
    159c:      	and	x11, x9, #0x7
    15a0:      	add	x12, sp, #0xf0
    15a4:      	ldr	x11, [x12, x11, lsl #3]
    15a8:      	sub	x9, x11, x9
    15ac:      	add	x8, x8, x9, lsl #2
    15b0:      	tbnz	w10, #0x0, 0x17a0 <ltmp0+0x17a0>
    15b4:      	tbnz	w10, #0x1, 0x17a8 <ltmp0+0x17a8>
    15b8:      	tbnz	w10, #0x2, 0x17b4 <ltmp0+0x17b4>
    15bc:      	tbz	w10, #0x3, 0x15c8 <ltmp0+0x15c8>
    15c0:      	add	x9, x8, #0xc
    15c4:      	st1.s	{ v0 }[3], [x9]
    15c8:      	fmul.4s	v0, v14, v31
    15cc:      	fmul.4s	v1, v27, v29
    15d0:      	fadd.4s	v0, v1, v0
    15d4:      	zip2.8b	v1, v3, v0
    15d8:      	ushll.4s	v1, v1, #0x0
    15dc:      	shl.4s	v1, v1, #0x1f
    15e0:      	cmlt.4s	v1, v1, #0
    15e4:      	and.16b	v0, v1, v0
    15e8:      	tbnz	w10, #0x4, 0x17c4 <ltmp0+0x17c4>
    15ec:      	tbnz	w10, #0x5, 0x17cc <ltmp0+0x17cc>
    15f0:      	tbnz	w10, #0x6, 0x17d8 <ltmp0+0x17d8>
    15f4:      	tbz	w10, #0x7, 0x9c <ltmp0+0x9c>
    15f8:      	b	0x17e4 <ltmp0+0x17e4>
    15fc:      	ldr	s16, [x12]
    1600:      	tbz	w11, #0x1, 0xbac <ltmp0+0xbac>
    1604:      	add	x16, x12, #0x4
    1608:      	ld1.s	{ v16 }[1], [x16]
    160c:      	tbz	w11, #0x2, 0xbb0 <ltmp0+0xbb0>
    1610:      	add	x16, x12, #0x8
    1614:      	ld1.s	{ v16 }[2], [x16]
    1618:      	tbz	w11, #0x3, 0xbb4 <ltmp0+0xbb4>
    161c:      	add	x16, x12, #0xc
    1620:      	ld1.s	{ v16 }[3], [x16]
    1624:      	tbz	w11, #0x4, 0xbb8 <ltmp0+0xbb8>
    1628:      	add	x16, x12, #0x10
    162c:      	ld1.s	{ v17 }[0], [x16]
    1630:      	tbz	w11, #0x5, 0xbbc <ltmp0+0xbbc>
    1634:      	add	x16, x12, #0x14
    1638:      	ld1.s	{ v17 }[1], [x16]
    163c:      	tbz	w11, #0x6, 0xbc0 <ltmp0+0xbc0>
    1640:      	add	x16, x12, #0x18
    1644:      	ld1.s	{ v17 }[2], [x16]
    1648:      	tbnz	w11, #0x7, 0xbc4 <ltmp0+0xbc4>
    164c:      	b	0xbcc <ltmp0+0xbcc>
    1650:      	ldr	s4, [x15]
    1654:      	mov.16b	v14, v26
    1658:      	tbz	w16, #0x1, 0xedc <ltmp0+0xedc>
    165c:      	add	x17, x15, #0x4
    1660:      	ld1.s	{ v4 }[1], [x17]
    1664:      	mov.16b	v26, v30
    1668:      	ldr	d30, [sp, #0xa8]
    166c:      	tbz	w16, #0x2, 0xee8 <ltmp0+0xee8>
    1670:      	add	x17, x15, #0x8
    1674:      	ld1.s	{ v4 }[2], [x17]
    1678:      	tbz	w16, #0x3, 0xeec <ltmp0+0xeec>
    167c:      	add	x17, x15, #0xc
    1680:      	ld1.s	{ v4 }[3], [x17]
    1684:      	tbz	w16, #0x4, 0xef0 <ltmp0+0xef0>
    1688:      	add	x17, x15, #0x10
    168c:      	ld1.s	{ v6 }[0], [x17]
    1690:      	tbz	w16, #0x5, 0xef4 <ltmp0+0xef4>
    1694:      	add	x17, x15, #0x14
    1698:      	ld1.s	{ v6 }[1], [x17]
    169c:      	tbz	w16, #0x6, 0xef8 <ltmp0+0xef8>
    16a0:      	add	x17, x15, #0x18
    16a4:      	ld1.s	{ v6 }[2], [x17]
    16a8:      	tbnz	w16, #0x7, 0xefc <ltmp0+0xefc>
    16ac:      	b	0xf04 <ltmp0+0xf04>
    16b0:      	ldr	s4, [x13]
    16b4:      	tbz	w15, #0x1, 0x10dc <ltmp0+0x10dc>
    16b8:      	add	x16, x13, #0x4
    16bc:      	ld1.s	{ v4 }[1], [x16]
    16c0:      	tbz	w15, #0x2, 0x10e0 <ltmp0+0x10e0>
    16c4:      	add	x16, x13, #0x8
    16c8:      	ld1.s	{ v4 }[2], [x16]
    16cc:      	tbz	w15, #0x3, 0x10e4 <ltmp0+0x10e4>
    16d0:      	add	x16, x13, #0xc
    16d4:      	ld1.s	{ v4 }[3], [x16]
    16d8:      	tbz	w15, #0x4, 0x10e8 <ltmp0+0x10e8>
    16dc:      	add	x16, x13, #0x10
    16e0:      	ld1.s	{ v6 }[0], [x16]
    16e4:      	tbz	w15, #0x5, 0x10ec <ltmp0+0x10ec>
    16e8:      	add	x16, x13, #0x14
    16ec:      	ld1.s	{ v6 }[1], [x16]
    16f0:      	tbz	w15, #0x6, 0x10f0 <ltmp0+0x10f0>
    16f4:      	add	x16, x13, #0x18
    16f8:      	ld1.s	{ v6 }[2], [x16]
    16fc:      	tbnz	w15, #0x7, 0x10f4 <ltmp0+0x10f4>
    1700:      	b	0x10fc <ltmp0+0x10fc>
    1704:      	ldr	s4, [x10]
    1708:      	tbz	w13, #0x1, 0x1240 <ltmp0+0x1240>
    170c:      	add	x14, x10, #0x4
    1710:      	ld1.s	{ v4 }[1], [x14]
    1714:      	tbz	w13, #0x2, 0x1244 <ltmp0+0x1244>
    1718:      	add	x14, x10, #0x8
    171c:      	ld1.s	{ v4 }[2], [x14]
    1720:      	tbz	w13, #0x3, 0x1248 <ltmp0+0x1248>
    1724:      	add	x14, x10, #0xc
    1728:      	ld1.s	{ v4 }[3], [x14]
    172c:      	tbz	w13, #0x4, 0x124c <ltmp0+0x124c>
    1730:      	add	x14, x10, #0x10
    1734:      	ld1.s	{ v6 }[0], [x14]
    1738:      	tbz	w13, #0x5, 0x1250 <ltmp0+0x1250>
    173c:      	add	x14, x10, #0x14
    1740:      	ld1.s	{ v6 }[1], [x14]
    1744:      	tbz	w13, #0x6, 0x1254 <ltmp0+0x1254>
    1748:      	add	x14, x10, #0x18
    174c:      	ld1.s	{ v6 }[2], [x14]
    1750:      	tbnz	w13, #0x7, 0x1258 <ltmp0+0x1258>
    1754:      	b	0x1260 <ltmp0+0x1260>
    1758:      	str	s4, [x12]
    175c:      	tbz	w11, #0x1, 0x140c <ltmp0+0x140c>
    1760:      	add	x13, x12, #0x4
    1764:      	st1.s	{ v4 }[1], [x13]
    1768:      	tbz	w11, #0x2, 0x1410 <ltmp0+0x1410>
    176c:      	add	x13, x12, #0x8
    1770:      	st1.s	{ v4 }[2], [x13]
    1774:      	tbnz	w11, #0x3, 0x1414 <ltmp0+0x1414>
    1778:      	b	0x141c <ltmp0+0x141c>
    177c:      	str	s4, [x12, #0x10]
    1780:      	tbz	w11, #0x5, 0x1444 <ltmp0+0x1444>
    1784:      	add	x13, x12, #0x14
    1788:      	st1.s	{ v4 }[1], [x13]
    178c:      	tbz	w11, #0x6, 0x1448 <ltmp0+0x1448>
    1790:      	add	x13, x12, #0x18
    1794:      	st1.s	{ v4 }[2], [x13]
    1798:      	tbnz	w11, #0x7, 0x144c <ltmp0+0x144c>
    179c:      	b	0x1454 <ltmp0+0x1454>
    17a0:      	str	s0, [x8]
    17a4:      	tbz	w10, #0x1, 0x15b8 <ltmp0+0x15b8>
    17a8:      	add	x9, x8, #0x4
    17ac:      	st1.s	{ v0 }[1], [x9]
    17b0:      	tbz	w10, #0x2, 0x15bc <ltmp0+0x15bc>
    17b4:      	add	x9, x8, #0x8
    17b8:      	st1.s	{ v0 }[2], [x9]
    17bc:      	tbnz	w10, #0x3, 0x15c0 <ltmp0+0x15c0>
    17c0:      	b	0x15c8 <ltmp0+0x15c8>
    17c4:      	str	s0, [x8, #0x10]
    17c8:      	tbz	w10, #0x5, 0x15f0 <ltmp0+0x15f0>
    17cc:      	add	x9, x8, #0x14
    17d0:      	st1.s	{ v0 }[1], [x9]
    17d4:      	tbz	w10, #0x6, 0x15f4 <ltmp0+0x15f4>
    17d8:      	add	x9, x8, #0x18
    17dc:      	st1.s	{ v0 }[2], [x9]
    17e0:      	tbz	w10, #0x7, 0x9c <ltmp0+0x9c>
    17e4:      	add	x8, x8, #0x1c
    17e8:      	st1.s	{ v0 }[3], [x8]
    17ec:      	b	0x9c <ltmp0+0x9c>
    17f0:      	ldr	x9, [sp, #0x8]
    17f4:      	stp	w6, w5, [x9]
    17f8:      	str	w12, [x9, #0x8]
    17fc:      	mov	w8, #0x18               ; =24
    1800:      	str	w8, [x9, #0x24]
    1804:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
    1808:      	add	sp, sp, #0x340
    180c:      	ldp	x29, x30, [sp, #0x90]
    1810:      	ldp	x20, x19, [sp, #0x80]
    1814:      	ldp	x22, x21, [sp, #0x70]
    1818:      	ldp	x24, x23, [sp, #0x60]
    181c:      	ldp	x26, x25, [sp, #0x50]
    1820:      	ldp	x28, x27, [sp, #0x40]
    1824:      	ldp	d9, d8, [sp, #0x30]
    1828:      	ldp	d11, d10, [sp, #0x20]
    182c:      	ldp	d13, d12, [sp, #0x10]
    1830:      	ldp	d15, d14, [sp], #0xa0
    1834:      	ret

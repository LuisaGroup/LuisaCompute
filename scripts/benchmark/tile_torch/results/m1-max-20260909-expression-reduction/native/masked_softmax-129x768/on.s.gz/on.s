
/private/tmp/luisa-expression-fusion.qXgTbC/capture/masked_softmax-129x768/on/object/tile_xir_w8_23385_1788930265219842_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x4, lsl #12   ; =0x4000
      2c:      	sub	sp, sp, #0xa0
      30:      	ldr	x8, [x0]
      34:      	ldr	x9, [x0, #0x30]
      38:      	str	x9, [sp, #0x8]
      3c:      	ldr	w9, [x1]
      40:      	ldr	w10, [x1, #0x24]
      44:      	add	w9, w10, w9, lsl #5
      48:      	lsr	w19, w9, #3
      4c:      	mov	w9, #0xc00              ; =3072
      50:      	umull	x20, w19, w9
      54:      	umaddl	x1, w19, w9, x8
      58:      	add	x0, sp, #0x3, lsl #12   ; =0x3000
      5c:      	add	x0, x0, #0x4a0
      60:      	mov	w2, #0xc00              ; =3072
      64:      	bl	0x64 <ltmp0+0x64>
      68:      	mov	x8, #0x0                ; =0
      6c:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
      70:      	add	x9, x9, #0xca0
      74:      	adrp	x10, 0x0 <ltmp0>
      78:      	ldr	q0, [x10]
      7c:      	adrp	x10, 0x0 <ltmp0>
      80:      	ldr	q1, [x10]
      84:      	adrp	x10, 0x0 <ltmp0>
      88:      	ldr	q2, [x10]
      8c:      	adrp	x10, 0x0 <ltmp0>
      90:      	ldr	q3, [x10]
      94:      	dup.2d	v4, x8
      98:      	orr.16b	v5, v4, v0
      9c:      	orr.16b	v6, v4, v1
      a0:      	orr.16b	v7, v4, v2
      a4:      	orr.16b	v4, v4, v3
      a8:      	stp	q7, q4, [x9, #0x20]
      ac:      	stp	q5, q6, [x9], #0x40
      b0:      	add	x8, x8, #0x8
      b4:      	cmp	x8, #0x300
      b8:      	b.ne	0x94 <ltmp0+0x94>
      bc:      	mov	x8, #0x0                ; =0
      c0:      	mov	w9, #0xaaab             ; =43691
      c4:      	movk	w9, #0xaaa, lsl #16
      c8:      	umull	x9, w19, w9
      cc:      	lsr	x9, x9, #37
      d0:      	mov	w10, #0x300             ; =768
      d4:      	msub	w9, w9, w10, w19
      d8:      	dup.2s	v0, w9
      dc:      	ushll.2d	v0, v0, #0x0
      e0:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
      e4:      	add	x9, x9, #0xca0
      e8:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
      ec:      	add	x10, x10, #0x9a0
      f0:      	dup.2d	v1, x10
      f4:      	adrp	x10, 0x0 <ltmp0>
      f8:      	ldr	q26, [x10]
      fc:      	adrp	x10, 0x0 <ltmp0>
     100:      	ldr	q27, [x10]
     104:      	adrp	x10, 0x0 <ltmp0>
     108:      	ldr	q28, [x10]
     10c:      	adrp	x10, 0x0 <ltmp0>
     110:      	ldr	q13, [x10]
     114:      	movi.8b	v2, #0x1
     118:      	dup.2d	v3, x8
     11c:      	add	x10, x9, x8, lsl #6
     120:      	ldp	q5, q4, [x10, #0x20]
     124:      	ldp	q6, q7, [x10]
     128:      	add.2d	v3, v3, v1
     12c:      	add.2d	v16, v3, v27
     130:      	add.2d	v17, v3, v26
     134:      	cmge.2d	v7, v0, v7
     138:      	cmge.2d	v6, v0, v6
     13c:      	uzp1.4s	v6, v6, v7
     140:      	cmge.2d	v5, v0, v5
     144:      	cmge.2d	v4, v0, v4
     148:      	uzp1.4s	v4, v5, v4
     14c:      	uzp1.8h	v4, v6, v4
     150:      	xtn.8b	v4, v4
     154:      	and.8b	v4, v4, v2
     158:      	mov.d	x10, v17[1]
     15c:      	fmov	x11, d17
     160:      	str	b4, [x11]
     164:      	st1.b	{ v4 }[1], [x10]
     168:      	mov.d	x10, v16[1]
     16c:      	fmov	x11, d16
     170:      	st1.b	{ v4 }[2], [x11]
     174:      	st1.b	{ v4 }[3], [x10]
     178:      	add.2d	v5, v3, v28
     17c:      	mov.d	x10, v5[1]
     180:      	fmov	x11, d5
     184:      	st1.b	{ v4 }[4], [x11]
     188:      	add.2d	v3, v3, v13
     18c:      	st1.b	{ v4 }[5], [x10]
     190:      	mov.d	x10, v3[1]
     194:      	fmov	x11, d3
     198:      	st1.b	{ v4 }[6], [x11]
     19c:      	st1.b	{ v4 }[7], [x10]
     1a0:      	add	x8, x8, #0x1
     1a4:      	cmp	x8, #0x60
     1a8:      	b.ne	0x118 <ltmp0+0x118>
     1ac:      	add	x8, sp, #0x1, lsl #12   ; =0x1000
     1b0:      	add	x8, x8, #0x9a0
     1b4:      	dup.2d	v4, x8
     1b8:      	add.2d	v0, v4, v13
     1bc:      	add.2d	v1, v4, v28
     1c0:      	add.2d	v2, v4, v26
     1c4:      	mov.d	x8, v2[1]
     1c8:      	add.2d	v3, v4, v27
     1cc:      	fmov	x9, d2
     1d0:      	mov.d	x10, v3[1]
     1d4:      	mov.d	x11, v1[1]
     1d8:      	fmov	x12, d3
     1dc:      	fmov	x13, d1
     1e0:      	mov.d	x14, v0[1]
     1e4:      	fmov	x15, d0
     1e8:      	ldr	b0, [x9]
     1ec:      	ld1.b	{ v0 }[1], [x8]
     1f0:      	ld1.b	{ v0 }[2], [x12]
     1f4:      	ld1.b	{ v0 }[3], [x10]
     1f8:      	ld1.b	{ v0 }[4], [x13]
     1fc:      	ld1.b	{ v0 }[5], [x11]
     200:      	ld1.b	{ v0 }[6], [x15]
     204:      	ld1.b	{ v0 }[7], [x14]
     208:      	cmeq.8b	v0, v0, #0
     20c:      	sshll.8h	v5, v0, #0x0
     210:      	sshll.4s	v0, v5, #0x0
     214:      	sshll2.4s	v30, v5, #0x0
     218:      	ldr	q1, [sp, #0x34a0]
     21c:      	ldr	q2, [sp, #0x34b0]
     220:      	mov	w8, #0xf2ca             ; =62154
     224:      	movk	w8, #0xf149, lsl #16
     228:      	dup.4s	v16, w8
     22c:      	mov.16b	v7, v30
     230:      	bsl.16b	v7, v16, v2
     234:      	mov.16b	v6, v0
     238:      	bsl.16b	v6, v16, v1
     23c:      	adrp	x8, 0x0 <ltmp0>
     240:      	ldr	q0, [x8]
     244:      	add.2d	v0, v4, v0
     248:      	adrp	x8, 0x0 <ltmp0>
     24c:      	ldr	q1, [x8]
     250:      	add.2d	v1, v4, v1
     254:      	adrp	x8, 0x0 <ltmp0>
     258:      	ldr	q2, [x8]
     25c:      	add.2d	v2, v4, v2
     260:      	adrp	x8, 0x0 <ltmp0>
     264:      	ldr	q3, [x8]
     268:      	add.2d	v3, v4, v3
     26c:      	mov.d	x8, v3[1]
     270:      	mov.d	x9, v2[1]
     274:      	fmov	x10, d3
     278:      	fmov	x11, d2
     27c:      	mov.d	x12, v1[1]
     280:      	mov.d	x13, v0[1]
     284:      	fmov	x14, d1
     288:      	ldr	b1, [x10]
     28c:      	ld1.b	{ v1 }[1], [x8]
     290:      	ld1.b	{ v1 }[2], [x11]
     294:      	ld1.b	{ v1 }[3], [x9]
     298:      	ld1.b	{ v1 }[4], [x14]
     29c:      	ld1.b	{ v1 }[5], [x12]
     2a0:      	fmov	x8, d0
     2a4:      	ld1.b	{ v1 }[6], [x8]
     2a8:      	ld1.b	{ v1 }[7], [x13]
     2ac:      	cmeq.8b	v0, v1, #0
     2b0:      	sshll.8h	v31, v0, #0x0
     2b4:      	sshll2.4s	v3, v31, #0x0
     2b8:      	sshll.4s	v0, v31, #0x0
     2bc:      	ldr	q1, [sp, #0x34d0]
     2c0:      	ldr	q2, [sp, #0x34c0]
     2c4:      	mov.16b	v17, v0
     2c8:      	bsl.16b	v17, v16, v2
     2cc:      	str	q3, [sp, #0xe0]
     2d0:      	mov.16b	v18, v3
     2d4:      	bsl.16b	v18, v16, v1
     2d8:      	str	q18, [sp, #0xdd0]
     2dc:      	str	q17, [sp, #0xdc0]
     2e0:      	adrp	x8, 0x0 <ltmp0>
     2e4:      	ldr	q0, [x8]
     2e8:      	add.2d	v0, v4, v0
     2ec:      	adrp	x8, 0x0 <ltmp0>
     2f0:      	ldr	q1, [x8]
     2f4:      	add.2d	v1, v4, v1
     2f8:      	adrp	x8, 0x0 <ltmp0>
     2fc:      	ldr	q2, [x8]
     300:      	add.2d	v2, v4, v2
     304:      	adrp	x8, 0x0 <ltmp0>
     308:      	ldr	q3, [x8]
     30c:      	add.2d	v3, v4, v3
     310:      	mov.d	x8, v3[1]
     314:      	fmov	x9, d3
     318:      	mov.d	x10, v2[1]
     31c:      	fmov	x11, d2
     320:      	mov.d	x12, v1[1]
     324:      	fmov	x13, d1
     328:      	mov.d	x14, v0[1]
     32c:      	fmov	x15, d0
     330:      	ldr	b0, [x9]
     334:      	ld1.b	{ v0 }[1], [x8]
     338:      	ld1.b	{ v0 }[2], [x11]
     33c:      	ld1.b	{ v0 }[3], [x10]
     340:      	ld1.b	{ v0 }[4], [x13]
     344:      	ld1.b	{ v0 }[5], [x12]
     348:      	ld1.b	{ v0 }[6], [x15]
     34c:      	ld1.b	{ v0 }[7], [x14]
     350:      	cmeq.8b	v0, v0, #0
     354:      	sshll.8h	v9, v0, #0x0
     358:      	sshll2.4s	v3, v9, #0x0
     35c:      	sshll.4s	v0, v9, #0x0
     360:      	ldr	q1, [sp, #0x34f0]
     364:      	ldr	q2, [sp, #0x34e0]
     368:      	mov.16b	v19, v0
     36c:      	bsl.16b	v19, v16, v2
     370:      	str	q3, [sp, #0xf0]
     374:      	mov.16b	v20, v3
     378:      	bsl.16b	v20, v16, v1
     37c:      	adrp	x8, 0x0 <ltmp0>
     380:      	ldr	q0, [x8]
     384:      	add.2d	v0, v4, v0
     388:      	adrp	x8, 0x0 <ltmp0>
     38c:      	ldr	q1, [x8]
     390:      	add.2d	v1, v4, v1
     394:      	adrp	x8, 0x0 <ltmp0>
     398:      	ldr	q2, [x8]
     39c:      	add.2d	v2, v4, v2
     3a0:      	adrp	x8, 0x0 <ltmp0>
     3a4:      	ldr	q3, [x8]
     3a8:      	add.2d	v3, v4, v3
     3ac:      	mov.d	x8, v3[1]
     3b0:      	mov.d	x9, v2[1]
     3b4:      	fmov	x10, d3
     3b8:      	fmov	x11, d2
     3bc:      	mov.d	x12, v1[1]
     3c0:      	mov.d	x13, v0[1]
     3c4:      	fmov	x14, d1
     3c8:      	ldr	b1, [x10]
     3cc:      	ld1.b	{ v1 }[1], [x8]
     3d0:      	ld1.b	{ v1 }[2], [x11]
     3d4:      	ld1.b	{ v1 }[3], [x9]
     3d8:      	ld1.b	{ v1 }[4], [x14]
     3dc:      	ld1.b	{ v1 }[5], [x12]
     3e0:      	fmov	x8, d0
     3e4:      	ld1.b	{ v1 }[6], [x8]
     3e8:      	ld1.b	{ v1 }[7], [x13]
     3ec:      	str	q20, [sp, #0xdf0]
     3f0:      	str	q19, [sp, #0xde0]
     3f4:      	cmeq.8b	v0, v1, #0
     3f8:      	sshll.8h	v0, v0, #0x0
     3fc:      	sshll2.4s	v3, v0, #0x0
     400:      	stp	q0, q3, [sp, #0x100]
     404:      	sshll.4s	v0, v0, #0x0
     408:      	ldr	q1, [sp, #0x3510]
     40c:      	ldr	q2, [sp, #0x3500]
     410:      	mov.16b	v21, v0
     414:      	bsl.16b	v21, v16, v2
     418:      	mov.16b	v22, v3
     41c:      	bsl.16b	v22, v16, v1
     420:      	add	x8, sp, #0xda0
     424:      	add	x8, x8, #0xe0
     428:      	add	x9, sp, #0x3, lsl #12   ; =0x3000
     42c:      	add	x9, x9, #0x4a0
     430:      	str	q22, [sp, #0xe10]
     434:      	str	q21, [sp, #0xe00]
     438:      	add	x9, x9, #0xe0
     43c:      	mov	w10, #0x4               ; =4
     440:      	mov.16b	v23, v6
     444:      	mov.16b	v24, v7
     448:      	dup.2d	v0, x10
     44c:      	add.2d	v0, v0, v4
     450:      	add.2d	v1, v0, v13
     454:      	add.2d	v2, v0, v28
     458:      	add.2d	v3, v0, v27
     45c:      	add.2d	v0, v0, v26
     460:      	mov.d	x11, v0[1]
     464:      	fmov	x12, d0
     468:      	mov.d	x13, v3[1]
     46c:      	fmov	x14, d3
     470:      	mov.d	x15, v2[1]
     474:      	fmov	x16, d2
     478:      	mov.d	x17, v1[1]
     47c:      	fmov	x0, d1
     480:      	ldr	b0, [x12]
     484:      	ld1.b	{ v0 }[1], [x11]
     488:      	ld1.b	{ v0 }[2], [x14]
     48c:      	ld1.b	{ v0 }[3], [x13]
     490:      	ld1.b	{ v0 }[4], [x16]
     494:      	ld1.b	{ v0 }[5], [x15]
     498:      	ld1.b	{ v0 }[6], [x0]
     49c:      	ld1.b	{ v0 }[7], [x17]
     4a0:      	cmeq.8b	v0, v0, #0
     4a4:      	sshll.8h	v0, v0, #0x0
     4a8:      	sshll2.4s	v1, v0, #0x0
     4ac:      	sshll.4s	v0, v0, #0x0
     4b0:      	ldp	q3, q2, [x9, #-0x60]
     4b4:      	bsl.16b	v0, v16, v3
     4b8:      	bsl.16b	v1, v16, v2
     4bc:      	stp	q0, q1, [x8, #-0x60]
     4c0:      	fmaxnm.4s	v24, v24, v1
     4c4:      	add	x11, x10, #0x1
     4c8:      	dup.2d	v1, x11
     4cc:      	add.2d	v1, v1, v4
     4d0:      	add.2d	v2, v1, v13
     4d4:      	add.2d	v3, v1, v26
     4d8:      	mov.d	x11, v3[1]
     4dc:      	fmov	x12, d3
     4e0:      	add.2d	v3, v1, v28
     4e4:      	add.2d	v1, v1, v27
     4e8:      	mov.d	x13, v1[1]
     4ec:      	mov.d	x14, v3[1]
     4f0:      	fmov	x15, d1
     4f4:      	fmov	x16, d3
     4f8:      	mov.d	x17, v2[1]
     4fc:      	fmov	x0, d2
     500:      	ldr	b1, [x12]
     504:      	ld1.b	{ v1 }[1], [x11]
     508:      	ld1.b	{ v1 }[2], [x15]
     50c:      	ld1.b	{ v1 }[3], [x13]
     510:      	ld1.b	{ v1 }[4], [x16]
     514:      	ld1.b	{ v1 }[5], [x14]
     518:      	ld1.b	{ v1 }[6], [x0]
     51c:      	fmaxnm.4s	v23, v23, v0
     520:      	ld1.b	{ v1 }[7], [x17]
     524:      	cmeq.8b	v0, v1, #0
     528:      	sshll.8h	v0, v0, #0x0
     52c:      	sshll2.4s	v1, v0, #0x0
     530:      	sshll.4s	v0, v0, #0x0
     534:      	ldp	q3, q2, [x9, #-0x40]
     538:      	bsl.16b	v0, v16, v3
     53c:      	bsl.16b	v1, v16, v2
     540:      	stp	q0, q1, [x8, #-0x40]
     544:      	fmaxnm.4s	v18, v18, v1
     548:      	fmaxnm.4s	v17, v17, v0
     54c:      	add	x11, x10, #0x2
     550:      	dup.2d	v0, x11
     554:      	add.2d	v0, v0, v4
     558:      	add.2d	v1, v0, v13
     55c:      	add.2d	v2, v0, v28
     560:      	add.2d	v3, v0, v26
     564:      	mov.d	x11, v3[1]
     568:      	add.2d	v0, v0, v27
     56c:      	fmov	x12, d3
     570:      	mov.d	x13, v0[1]
     574:      	mov.d	x14, v2[1]
     578:      	fmov	x15, d0
     57c:      	fmov	x16, d2
     580:      	mov.d	x17, v1[1]
     584:      	fmov	x0, d1
     588:      	ldr	b0, [x12]
     58c:      	ld1.b	{ v0 }[1], [x11]
     590:      	ld1.b	{ v0 }[2], [x15]
     594:      	ld1.b	{ v0 }[3], [x13]
     598:      	ld1.b	{ v0 }[4], [x16]
     59c:      	ld1.b	{ v0 }[5], [x14]
     5a0:      	ld1.b	{ v0 }[6], [x0]
     5a4:      	ld1.b	{ v0 }[7], [x17]
     5a8:      	cmeq.8b	v0, v0, #0
     5ac:      	sshll.8h	v0, v0, #0x0
     5b0:      	sshll2.4s	v1, v0, #0x0
     5b4:      	sshll.4s	v0, v0, #0x0
     5b8:      	ldp	q3, q2, [x9, #-0x20]
     5bc:      	bsl.16b	v0, v16, v3
     5c0:      	bsl.16b	v1, v16, v2
     5c4:      	stp	q0, q1, [x8, #-0x20]
     5c8:      	fmaxnm.4s	v20, v20, v1
     5cc:      	add	x11, x10, #0x3
     5d0:      	dup.2d	v1, x11
     5d4:      	add.2d	v1, v1, v4
     5d8:      	add.2d	v2, v1, v13
     5dc:      	add.2d	v3, v1, v26
     5e0:      	mov.d	x11, v3[1]
     5e4:      	fmov	x12, d3
     5e8:      	add.2d	v3, v1, v28
     5ec:      	add.2d	v1, v1, v27
     5f0:      	mov.d	x13, v1[1]
     5f4:      	fmov	x14, d1
     5f8:      	mov.d	x15, v3[1]
     5fc:      	fmov	x16, d3
     600:      	mov.d	x17, v2[1]
     604:      	fmov	x0, d2
     608:      	ldr	b1, [x12]
     60c:      	ld1.b	{ v1 }[1], [x11]
     610:      	ld1.b	{ v1 }[2], [x14]
     614:      	ld1.b	{ v1 }[3], [x13]
     618:      	ld1.b	{ v1 }[4], [x16]
     61c:      	ld1.b	{ v1 }[5], [x15]
     620:      	ld1.b	{ v1 }[6], [x0]
     624:      	ld1.b	{ v1 }[7], [x17]
     628:      	fmaxnm.4s	v19, v19, v0
     62c:      	cmeq.8b	v0, v1, #0
     630:      	sshll.8h	v0, v0, #0x0
     634:      	sshll2.4s	v1, v0, #0x0
     638:      	sshll.4s	v0, v0, #0x0
     63c:      	ldp	q3, q2, [x9], #0x80
     640:      	bsl.16b	v0, v16, v3
     644:      	bsl.16b	v1, v16, v2
     648:      	stp	q0, q1, [x8], #0x80
     64c:      	fmaxnm.4s	v22, v22, v1
     650:      	fmaxnm.4s	v21, v21, v0
     654:      	cmp	x10, #0x5c
     658:      	add	x10, x10, #0x4
     65c:      	b.lo	0x448 <ltmp0+0x448>
     660:      	fmaxnm.4s	v0, v23, v17
     664:      	fmaxnm.4s	v1, v24, v18
     668:      	fmaxnm.4s	v1, v1, v20
     66c:      	fmaxnm.4s	v0, v0, v19
     670:      	fmaxnm.4s	v0, v0, v21
     674:      	fmaxnm.4s	v1, v1, v22
     678:      	rev64.4s	v2, v1
     67c:      	rev64.4s	v3, v0
     680:      	fmaxnm.4s	v0, v0, v3
     684:      	fmaxnm.4s	v1, v1, v2
     688:      	ext.16b	v2, v1, v1, #0x8
     68c:      	ext.16b	v3, v0, v0, #0x8
     690:      	fmaxnm.4s	v0, v0, v3
     694:      	fmaxnm.4s	v1, v1, v2
     698:      	fmaxnm.4s	v0, v0, v1
     69c:      	mov	w8, #-0x800000          ; =-8388608
     6a0:      	fmov	s1, w8
     6a4:      	fmaxnm	s0, s0, s1
     6a8:      	dup.4s	v4, v0[0]
     6ac:      	sshll.4s	v0, v5, #0x0
     6b0:      	fsub.4s	v1, v7, v4
     6b4:      	fsub.4s	v2, v6, v4
     6b8:      	mov	w8, #-0x3d300000        ; =-1026555904
     6bc:      	dup.4s	v6, w8
     6c0:      	fcmge.4s	v3, v2, v6
     6c4:      	fcmge.4s	v7, v1, v6
     6c8:      	mov	w8, #0x42c80000         ; =1120403456
     6cc:      	dup.4s	v11, w8
     6d0:      	fcmge.4s	v16, v11, v2
     6d4:      	fcmge.4s	v17, v11, v1
     6d8:      	and.16b	v7, v7, v17
     6dc:      	and.16b	v3, v3, v16
     6e0:      	and.16b	v17, v3, v2
     6e4:      	and.16b	v19, v7, v1
     6e8:      	mov	w8, #0xaa3b             ; =43579
     6ec:      	movk	w8, #0x3fb8, lsl #16
     6f0:      	dup.4s	v7, w8
     6f4:      	fmul.4s	v3, v19, v7
     6f8:      	fmul.4s	v16, v17, v7
     6fc:      	movi.4s	v14, #0x4b, lsl #24
     700:      	mvni.4s	v15, #0x80, lsl #24
     704:      	mov.16b	v18, v15
     708:      	bsl.16b	v18, v14, v16
     70c:      	mov.16b	v20, v15
     710:      	bsl.16b	v20, v14, v3
     714:      	fadd.4s	v3, v3, v20
     718:      	fadd.4s	v16, v16, v18
     71c:      	fsub.4s	v16, v16, v18
     720:      	fsub.4s	v3, v3, v20
     724:      	fcvtzs.4s	v3, v3
     728:      	fcvtzs.4s	v16, v16
     72c:      	scvtf.4s	v20, v16
     730:      	mov	w8, #0x7200             ; =29184
     734:      	movk	w8, #0x3f31, lsl #16
     738:      	dup.4s	v18, w8
     73c:      	scvtf.4s	v21, v3
     740:      	fmul.4s	v22, v21, v18
     744:      	fmul.4s	v23, v20, v18
     748:      	fsub.4s	v17, v17, v23
     74c:      	fsub.4s	v22, v19, v22
     750:      	mov	w8, #0xbe8e             ; =48782
     754:      	movk	w8, #0x35bf, lsl #16
     758:      	dup.4s	v19, w8
     75c:      	fmul.4s	v20, v20, v19
     760:      	fmul.4s	v21, v21, v19
     764:      	fsub.4s	v25, v22, v21
     768:      	fsub.4s	v17, v17, v20
     76c:      	mov	w8, #0x2bda             ; =11226
     770:      	movk	w8, #0x3950, lsl #16
     774:      	dup.4s	v20, w8
     778:      	fmul.4s	v22, v17, v20
     77c:      	fmul.4s	v23, v25, v20
     780:      	mov	w8, #0x96c9             ; =38601
     784:      	movk	w8, #0x3ab6, lsl #16
     788:      	dup.4s	v8, w8
     78c:      	fadd.4s	v23, v23, v8
     790:      	fadd.4s	v22, v22, v8
     794:      	fmul.4s	v24, v17, v22
     798:      	fmul.4s	v23, v25, v23
     79c:      	mov	w8, #0x88a6             ; =34982
     7a0:      	movk	w8, #0x3c08, lsl #16
     7a4:      	dup.4s	v10, w8
     7a8:      	fadd.4s	v23, v23, v10
     7ac:      	fadd.4s	v24, v24, v10
     7b0:      	fmul.4s	v24, v17, v24
     7b4:      	str	q26, [sp, #0x60]
     7b8:      	fmul.4s	v26, v25, v23
     7bc:      	mov	w8, #0xaa7a             ; =43642
     7c0:      	movk	w8, #0x3d2a, lsl #16
     7c4:      	dup.4s	v5, w8
     7c8:      	fadd.4s	v26, v26, v5
     7cc:      	fadd.4s	v24, v24, v5
     7d0:      	str	q27, [sp, #0x170]
     7d4:      	fmul.4s	v27, v17, v24
     7d8:      	fmul.4s	v26, v25, v26
     7dc:      	mov	w8, #0xaaab             ; =43691
     7e0:      	movk	w8, #0x3e2a, lsl #16
     7e4:      	dup.4s	v23, w8
     7e8:      	fadd.4s	v26, v26, v23
     7ec:      	fadd.4s	v27, v27, v23
     7f0:      	fmul.4s	v27, v17, v27
     7f4:      	fmul.4s	v26, v25, v26
     7f8:      	movi.4s	v24, #0x3f, lsl #24
     7fc:      	fadd.4s	v26, v26, v24
     800:      	fadd.4s	v27, v27, v24
     804:      	str	q28, [sp, #0x120]
     808:      	fmul.4s	v28, v25, v25
     80c:      	fmul.4s	v29, v17, v17
     810:      	fmul.4s	v27, v29, v27
     814:      	fmul.4s	v26, v28, v26
     818:      	fadd.4s	v25, v25, v26
     81c:      	fadd.4s	v17, v17, v27
     820:      	fmov.4s	v12, #1.00000000
     824:      	fadd.4s	v17, v17, v12
     828:      	fadd.4s	v25, v25, v12
     82c:      	sshr.4s	v27, v16, #0x1
     830:      	sshr.4s	v28, v3, #0x1
     834:      	shl.4s	v29, v28, #0x17
     838:      	add.4s	v29, v29, v12
     83c:      	fmul.4s	v25, v25, v29
     840:      	shl.4s	v29, v27, #0x17
     844:      	add.4s	v29, v29, v12
     848:      	fmul.4s	v17, v17, v29
     84c:      	sub.4s	v3, v3, v28
     850:      	sub.4s	v16, v16, v27
     854:      	shl.4s	v16, v16, #0x17
     858:      	shl.4s	v3, v3, #0x17
     85c:      	add.4s	v3, v3, v12
     860:      	add.4s	v16, v16, v12
     864:      	fmul.4s	v16, v17, v16
     868:      	fmul.4s	v3, v25, v3
     86c:      	fcmgt.4s	v17, v6, v1
     870:      	bic.16b	v3, v3, v17
     874:      	fcmgt.4s	v17, v6, v2
     878:      	bic.16b	v16, v16, v17
     87c:      	fcmgt.4s	v17, v1, v11
     880:      	fcmgt.4s	v25, v2, v11
     884:      	mvni.4s	v27, #0x7f, msl #16
     888:      	fneg.4s	v27, v27
     88c:      	bit.16b	v16, v27, v25
     890:      	bit.16b	v3, v27, v17
     894:      	fcmeq.4s	v2, v2, v2
     898:      	fcmeq.4s	v1, v1, v1
     89c:      	mvni.4s	v17, #0x3f, msl #16
     8a0:      	fneg.4s	v26, v17
     8a4:      	bsl.16b	v1, v3, v26
     8a8:      	bsl.16b	v2, v16, v26
     8ac:      	bic.16b	v28, v2, v0
     8b0:      	bic.16b	v0, v1, v30
     8b4:      	str	q0, [sp, #0x150]
     8b8:      	ldr	q1, [sp, #0xdc0]
     8bc:      	ldr	q0, [sp, #0xdd0]
     8c0:      	fsub.4s	v0, v0, v4
     8c4:      	fsub.4s	v1, v1, v4
     8c8:      	fcmge.4s	v2, v1, v6
     8cc:      	fcmge.4s	v3, v0, v6
     8d0:      	fcmge.4s	v16, v11, v1
     8d4:      	fcmge.4s	v17, v11, v0
     8d8:      	and.16b	v3, v3, v17
     8dc:      	and.16b	v2, v2, v16
     8e0:      	and.16b	v16, v2, v1
     8e4:      	and.16b	v3, v3, v0
     8e8:      	fmul.4s	v2, v3, v7
     8ec:      	fmul.4s	v17, v16, v7
     8f0:      	mov.16b	v25, v15
     8f4:      	bsl.16b	v25, v14, v17
     8f8:      	fadd.4s	v17, v17, v25
     8fc:      	fsub.4s	v17, v17, v25
     900:      	mov.16b	v25, v15
     904:      	bsl.16b	v25, v14, v2
     908:      	fadd.4s	v2, v2, v25
     90c:      	fsub.4s	v25, v2, v25
     910:      	fcvtzs.4s	v2, v17
     914:      	scvtf.4s	v17, v2
     918:      	fmul.4s	v29, v17, v18
     91c:      	fsub.4s	v16, v16, v29
     920:      	fcvtzs.4s	v25, v25
     924:      	scvtf.4s	v29, v25
     928:      	fmul.4s	v30, v29, v18
     92c:      	fsub.4s	v3, v3, v30
     930:      	fmul.4s	v29, v29, v19
     934:      	fsub.4s	v3, v3, v29
     938:      	fmul.4s	v17, v17, v19
     93c:      	fsub.4s	v16, v16, v17
     940:      	fmul.4s	v17, v16, v20
     944:      	fadd.4s	v17, v17, v8
     948:      	fmul.4s	v17, v16, v17
     94c:      	fadd.4s	v17, v17, v10
     950:      	fmul.4s	v17, v16, v17
     954:      	fadd.4s	v17, v17, v5
     958:      	fmul.4s	v17, v16, v17
     95c:      	fadd.4s	v17, v17, v23
     960:      	fmul.4s	v17, v16, v17
     964:      	fadd.4s	v17, v17, v24
     968:      	fmul.4s	v29, v16, v16
     96c:      	fmul.4s	v17, v29, v17
     970:      	fmul.4s	v29, v3, v20
     974:      	fadd.4s	v29, v29, v8
     978:      	fmul.4s	v29, v3, v29
     97c:      	fadd.4s	v29, v29, v10
     980:      	fmul.4s	v29, v3, v29
     984:      	fadd.4s	v29, v29, v5
     988:      	fmul.4s	v29, v3, v29
     98c:      	fadd.4s	v29, v29, v23
     990:      	fmul.4s	v29, v3, v29
     994:      	fadd.4s	v29, v29, v24
     998:      	fmul.4s	v30, v3, v3
     99c:      	fmul.4s	v29, v30, v29
     9a0:      	fadd.4s	v3, v3, v29
     9a4:      	fadd.4s	v16, v16, v17
     9a8:      	fadd.4s	v3, v3, v12
     9ac:      	sshr.4s	v17, v25, #0x1
     9b0:      	shl.4s	v29, v17, #0x17
     9b4:      	add.4s	v29, v29, v12
     9b8:      	fmul.4s	v3, v3, v29
     9bc:      	fadd.4s	v16, v16, v12
     9c0:      	sshr.4s	v29, v2, #0x1
     9c4:      	shl.4s	v30, v29, #0x17
     9c8:      	add.4s	v30, v30, v12
     9cc:      	fmul.4s	v16, v16, v30
     9d0:      	sub.4s	v17, v25, v17
     9d4:      	sshll.4s	v25, v31, #0x0
     9d8:      	sub.4s	v2, v2, v29
     9dc:      	shl.4s	v2, v2, #0x17
     9e0:      	shl.4s	v17, v17, #0x17
     9e4:      	add.4s	v17, v17, v12
     9e8:      	add.4s	v2, v2, v12
     9ec:      	fmul.4s	v2, v16, v2
     9f0:      	fmul.4s	v3, v3, v17
     9f4:      	fcmgt.4s	v16, v6, v0
     9f8:      	bic.16b	v3, v3, v16
     9fc:      	fcmgt.4s	v16, v6, v1
     a00:      	bic.16b	v2, v2, v16
     a04:      	fcmgt.4s	v16, v0, v11
     a08:      	fcmgt.4s	v17, v1, v11
     a0c:      	bit.16b	v2, v27, v17
     a10:      	bit.16b	v3, v27, v16
     a14:      	fcmeq.4s	v1, v1, v1
     a18:      	fcmeq.4s	v0, v0, v0
     a1c:      	bsl.16b	v0, v3, v26
     a20:      	bsl.16b	v1, v2, v26
     a24:      	bic.16b	v31, v1, v25
     a28:      	ldr	q1, [sp, #0xe0]
     a2c:      	bic.16b	v21, v0, v1
     a30:      	ldr	q1, [sp, #0xde0]
     a34:      	ldr	q0, [sp, #0xdf0]
     a38:      	fsub.4s	v0, v0, v4
     a3c:      	fsub.4s	v1, v1, v4
     a40:      	fcmge.4s	v2, v1, v6
     a44:      	fcmge.4s	v3, v0, v6
     a48:      	fcmge.4s	v16, v11, v1
     a4c:      	fcmge.4s	v17, v11, v0
     a50:      	and.16b	v3, v3, v17
     a54:      	and.16b	v2, v2, v16
     a58:      	and.16b	v16, v2, v1
     a5c:      	and.16b	v3, v3, v0
     a60:      	fmul.4s	v2, v3, v7
     a64:      	fmul.4s	v17, v16, v7
     a68:      	mov.16b	v25, v15
     a6c:      	bsl.16b	v25, v14, v17
     a70:      	fadd.4s	v17, v17, v25
     a74:      	fsub.4s	v17, v17, v25
     a78:      	mov.16b	v25, v15
     a7c:      	bsl.16b	v25, v14, v2
     a80:      	fadd.4s	v2, v2, v25
     a84:      	fsub.4s	v25, v2, v25
     a88:      	fcvtzs.4s	v2, v17
     a8c:      	scvtf.4s	v17, v2
     a90:      	fmul.4s	v29, v17, v18
     a94:      	fsub.4s	v16, v16, v29
     a98:      	fcvtzs.4s	v25, v25
     a9c:      	scvtf.4s	v29, v25
     aa0:      	fmul.4s	v30, v29, v18
     aa4:      	fsub.4s	v3, v3, v30
     aa8:      	fmul.4s	v29, v29, v19
     aac:      	fsub.4s	v3, v3, v29
     ab0:      	fmul.4s	v17, v17, v19
     ab4:      	fsub.4s	v16, v16, v17
     ab8:      	fmul.4s	v17, v16, v20
     abc:      	fadd.4s	v17, v17, v8
     ac0:      	fmul.4s	v17, v16, v17
     ac4:      	fadd.4s	v17, v17, v10
     ac8:      	fmul.4s	v17, v16, v17
     acc:      	fadd.4s	v17, v17, v5
     ad0:      	fmul.4s	v17, v16, v17
     ad4:      	fadd.4s	v17, v17, v23
     ad8:      	fmul.4s	v17, v16, v17
     adc:      	fadd.4s	v17, v17, v24
     ae0:      	fmul.4s	v29, v16, v16
     ae4:      	fmul.4s	v17, v29, v17
     ae8:      	fmul.4s	v29, v3, v20
     aec:      	fadd.4s	v29, v29, v8
     af0:      	fmul.4s	v29, v3, v29
     af4:      	fadd.4s	v29, v29, v10
     af8:      	fmul.4s	v29, v3, v29
     afc:      	fadd.4s	v29, v29, v5
     b00:      	fmul.4s	v29, v3, v29
     b04:      	fadd.4s	v29, v29, v23
     b08:      	fmul.4s	v29, v3, v29
     b0c:      	fadd.4s	v29, v29, v24
     b10:      	fmul.4s	v30, v3, v3
     b14:      	fmul.4s	v29, v30, v29
     b18:      	fadd.4s	v3, v3, v29
     b1c:      	fadd.4s	v16, v16, v17
     b20:      	fadd.4s	v3, v3, v12
     b24:      	sshr.4s	v17, v25, #0x1
     b28:      	shl.4s	v29, v17, #0x17
     b2c:      	add.4s	v29, v29, v12
     b30:      	fmul.4s	v3, v3, v29
     b34:      	fadd.4s	v16, v16, v12
     b38:      	sshr.4s	v29, v2, #0x1
     b3c:      	shl.4s	v30, v29, #0x17
     b40:      	add.4s	v30, v30, v12
     b44:      	fmul.4s	v16, v16, v30
     b48:      	sub.4s	v17, v25, v17
     b4c:      	sshll.4s	v25, v9, #0x0
     b50:      	sub.4s	v2, v2, v29
     b54:      	shl.4s	v2, v2, #0x17
     b58:      	shl.4s	v17, v17, #0x17
     b5c:      	add.4s	v17, v17, v12
     b60:      	add.4s	v2, v2, v12
     b64:      	fmul.4s	v2, v16, v2
     b68:      	fmul.4s	v3, v3, v17
     b6c:      	fcmgt.4s	v16, v6, v0
     b70:      	bic.16b	v3, v3, v16
     b74:      	fcmgt.4s	v16, v6, v1
     b78:      	bic.16b	v2, v2, v16
     b7c:      	fcmgt.4s	v16, v0, v11
     b80:      	fcmgt.4s	v17, v1, v11
     b84:      	bit.16b	v2, v27, v17
     b88:      	bit.16b	v3, v27, v16
     b8c:      	fcmeq.4s	v1, v1, v1
     b90:      	fcmeq.4s	v0, v0, v0
     b94:      	bsl.16b	v0, v3, v26
     b98:      	bsl.16b	v1, v2, v26
     b9c:      	bic.16b	v9, v1, v25
     ba0:      	ldr	q1, [sp, #0xf0]
     ba4:      	bic.16b	v22, v0, v1
     ba8:      	ldr	q0, [sp, #0xe00]
     bac:      	ldr	q1, [sp, #0xe10]
     bb0:      	fsub.4s	v1, v1, v4
     bb4:      	stp	q7, q4, [sp, #0x90]
     bb8:      	fsub.4s	v0, v0, v4
     bbc:      	fcmge.4s	v2, v0, v6
     bc0:      	fcmge.4s	v3, v1, v6
     bc4:      	fcmge.4s	v16, v11, v0
     bc8:      	fcmge.4s	v17, v11, v1
     bcc:      	and.16b	v3, v3, v17
     bd0:      	and.16b	v2, v2, v16
     bd4:      	and.16b	v16, v2, v0
     bd8:      	and.16b	v3, v3, v1
     bdc:      	fmul.4s	v2, v3, v7
     be0:      	fmul.4s	v17, v16, v7
     be4:      	mov.16b	v25, v15
     be8:      	bsl.16b	v25, v14, v17
     bec:      	fadd.4s	v17, v17, v25
     bf0:      	fsub.4s	v17, v17, v25
     bf4:      	mov.16b	v25, v15
     bf8:      	bsl.16b	v25, v14, v2
     bfc:      	fadd.4s	v2, v2, v25
     c00:      	fsub.4s	v25, v2, v25
     c04:      	fcvtzs.4s	v2, v17
     c08:      	scvtf.4s	v17, v2
     c0c:      	fmul.4s	v29, v17, v18
     c10:      	fsub.4s	v16, v16, v29
     c14:      	fcvtzs.4s	v25, v25
     c18:      	scvtf.4s	v29, v25
     c1c:      	str	q18, [sp, #0x180]
     c20:      	fmul.4s	v30, v29, v18
     c24:      	fsub.4s	v3, v3, v30
     c28:      	fmul.4s	v29, v29, v19
     c2c:      	fsub.4s	v3, v3, v29
     c30:      	stp	q8, q19, [sp, #0x70]
     c34:      	fmul.4s	v17, v17, v19
     c38:      	ldr	q19, [sp, #0x150]
     c3c:      	fsub.4s	v16, v16, v17
     c40:      	fmul.4s	v17, v16, v20
     c44:      	fadd.4s	v17, v17, v8
     c48:      	fmul.4s	v17, v16, v17
     c4c:      	fadd.4s	v17, v17, v10
     c50:      	fmul.4s	v17, v16, v17
     c54:      	fadd.4s	v17, v17, v5
     c58:      	fmul.4s	v17, v16, v17
     c5c:      	fadd.4s	v17, v17, v23
     c60:      	fmul.4s	v17, v16, v17
     c64:      	fadd.4s	v17, v17, v24
     c68:      	fmul.4s	v29, v16, v16
     c6c:      	fmul.4s	v17, v29, v17
     c70:      	stp	q10, q20, [sp, #0x130]
     c74:      	fmul.4s	v29, v3, v20
     c78:      	mov.16b	v20, v31
     c7c:      	fadd.4s	v29, v29, v8
     c80:      	fmul.4s	v29, v3, v29
     c84:      	fadd.4s	v29, v29, v10
     c88:      	fmul.4s	v29, v3, v29
     c8c:      	str	q5, [sp, #0x190]
     c90:      	fadd.4s	v29, v29, v5
     c94:      	fmul.4s	v29, v3, v29
     c98:      	str	q23, [sp, #0x50]
     c9c:      	fadd.4s	v29, v29, v23
     ca0:      	mov.16b	v23, v21
     ca4:      	fmul.4s	v29, v3, v29
     ca8:      	fadd.4s	v29, v29, v24
     cac:      	fmul.4s	v30, v3, v3
     cb0:      	fmul.4s	v29, v30, v29
     cb4:      	fadd.4s	v3, v3, v29
     cb8:      	fadd.4s	v16, v16, v17
     cbc:      	fadd.4s	v3, v3, v12
     cc0:      	sshr.4s	v17, v25, #0x1
     cc4:      	shl.4s	v29, v17, #0x17
     cc8:      	add.4s	v29, v29, v12
     ccc:      	fmul.4s	v3, v3, v29
     cd0:      	fadd.4s	v16, v16, v12
     cd4:      	sshr.4s	v29, v2, #0x1
     cd8:      	shl.4s	v30, v29, #0x17
     cdc:      	add.4s	v30, v30, v12
     ce0:      	fmul.4s	v16, v16, v30
     ce4:      	sub.4s	v17, v25, v17
     ce8:      	sub.4s	v2, v2, v29
     cec:      	shl.4s	v2, v2, #0x17
     cf0:      	add.4s	v2, v2, v12
     cf4:      	fmul.4s	v2, v16, v2
     cf8:      	shl.4s	v16, v17, #0x17
     cfc:      	mov.16b	v17, v22
     d00:      	add.4s	v16, v16, v12
     d04:      	fmul.4s	v3, v3, v16
     d08:      	fcmgt.4s	v16, v6, v1
     d0c:      	bic.16b	v3, v3, v16
     d10:      	stp	q11, q6, [sp, #0x30]
     d14:      	fcmgt.4s	v16, v6, v0
     d18:      	bic.16b	v2, v2, v16
     d1c:      	fcmgt.4s	v16, v0, v11
     d20:      	bit.16b	v2, v27, v16
     d24:      	fcmgt.4s	v16, v1, v11
     d28:      	stp	q26, q27, [sp, #0x10]
     d2c:      	bit.16b	v3, v27, v16
     d30:      	fcmeq.4s	v1, v1, v1
     d34:      	bsl.16b	v1, v3, v26
     d38:      	fcmeq.4s	v0, v0, v0
     d3c:      	bsl.16b	v0, v2, v26
     d40:      	ldr	q2, [sp, #0x100]
     d44:      	sshll.4s	v2, v2, #0x0
     d48:      	bic.16b	v2, v0, v2
     d4c:      	ldr	q0, [sp, #0x110]
     d50:      	bic.16b	v3, v1, v0
     d54:      	stp	q28, q19, [sp, #0x1a0]
     d58:      	stp	q31, q21, [sp, #0x1c0]
     d5c:      	stp	q9, q22, [sp, #0x1e0]
     d60:      	stp	q2, q3, [sp, #0x200]
     d64:      	add	x8, sp, #0x1a0
     d68:      	add	x8, x8, #0xe0
     d6c:      	add	x9, sp, #0xda0
     d70:      	add	x9, x9, #0xe0
     d74:      	mov	w11, #0x4               ; =4
     d78:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
     d7c:      	add	x10, x10, #0x9a0
     d80:      	str	q13, [sp, #0x160]
     d84:      	ldp	q5, q6, [sp, #0x30]
     d88:      	ldr	q27, [sp, #0x50]
     d8c:      	stp	q3, q2, [sp, #0xb0]
     d90:      	stp	q17, q9, [sp, #0xd0]
     d94:      	stp	q23, q20, [sp, #0xf0]
     d98:      	str	q19, [sp, #0x150]
     d9c:      	str	q28, [sp, #0x110]
     da0:      	dup.2d	v0, x11
     da4:      	dup.2d	v13, x10
     da8:      	add.2d	v1, v0, v13
     dac:      	ldp	q22, q7, [sp, #0x160]
     db0:      	add.2d	v0, v1, v22
     db4:      	ldr	q18, [sp, #0x120]
     db8:      	add.2d	v2, v1, v18
     dbc:      	ldr	q19, [sp, #0x60]
     dc0:      	add.2d	v3, v1, v19
     dc4:      	mov.d	x12, v3[1]
     dc8:      	add.2d	v1, v1, v7
     dcc:      	ldp	q16, q17, [x9, #-0x60]
     dd0:      	ldp	q20, q23, [sp, #0x90]
     dd4:      	fsub.4s	v15, v17, v23
     dd8:      	fsub.4s	v14, v16, v23
     ddc:      	fmov	x16, d3
     de0:      	mov.d	x15, v1[1]
     de4:      	fcmge.4s	v3, v14, v6
     de8:      	fcmge.4s	v16, v15, v6
     dec:      	fcmge.4s	v17, v5, v14
     df0:      	fmov	x0, d1
     df4:      	mov.d	x14, v2[1]
     df8:      	fcmge.4s	v1, v5, v15
     dfc:      	and.16b	v1, v16, v1
     e00:      	and.16b	v3, v3, v17
     e04:      	fmov	x1, d2
     e08:      	mov.d	x13, v0[1]
     e0c:      	and.16b	v2, v3, v14
     e10:      	fmov	x17, d0
     e14:      	and.16b	v0, v1, v15
     e18:      	fmul.4s	v1, v0, v20
     e1c:      	fmul.4s	v3, v2, v20
     e20:      	movi.4s	v4, #0x4b, lsl #24
     e24:      	mvni.4s	v17, #0x80, lsl #24
     e28:      	mov.16b	v16, v17
     e2c:      	bsl.16b	v16, v4, v3
     e30:      	bsl.16b	v17, v4, v1
     e34:      	fadd.4s	v1, v1, v17
     e38:      	fadd.4s	v3, v3, v16
     e3c:      	fsub.4s	v3, v3, v16
     e40:      	fsub.4s	v1, v1, v17
     e44:      	fcvtzs.4s	v16, v1
     e48:      	fcvtzs.4s	v3, v3
     e4c:      	scvtf.4s	v1, v3
     e50:      	scvtf.4s	v17, v16
     e54:      	ldr	q26, [sp, #0x180]
     e58:      	fmul.4s	v25, v17, v26
     e5c:      	fmul.4s	v29, v1, v26
     e60:      	fsub.4s	v29, v2, v29
     e64:      	fsub.4s	v0, v0, v25
     e68:      	ldp	q28, q24, [sp, #0x70]
     e6c:      	fmul.4s	v1, v1, v24
     e70:      	fmul.4s	v2, v17, v24
     e74:      	fsub.4s	v2, v0, v2
     e78:      	fsub.4s	v0, v29, v1
     e7c:      	ldr	q4, [sp, #0x140]
     e80:      	fmul.4s	v1, v0, v4
     e84:      	fmul.4s	v17, v2, v4
     e88:      	fadd.4s	v17, v17, v28
     e8c:      	fadd.4s	v1, v1, v28
     e90:      	fmul.4s	v1, v0, v1
     e94:      	fmul.4s	v17, v2, v17
     e98:      	ldr	q4, [sp, #0x130]
     e9c:      	fadd.4s	v17, v17, v4
     ea0:      	fadd.4s	v1, v1, v4
     ea4:      	fmul.4s	v1, v0, v1
     ea8:      	fmul.4s	v17, v2, v17
     eac:      	ldr	q4, [sp, #0x190]
     eb0:      	fadd.4s	v17, v17, v4
     eb4:      	fadd.4s	v1, v1, v4
     eb8:      	fmul.4s	v8, v0, v1
     ebc:      	fmul.4s	v29, v2, v2
     ec0:      	fmul.4s	v30, v0, v0
     ec4:      	sshr.4s	v31, v3, #0x1
     ec8:      	fmul.4s	v17, v2, v17
     ecc:      	sshr.4s	v4, v16, #0x1
     ed0:      	shl.4s	v1, v4, #0x17
     ed4:      	shl.4s	v25, v31, #0x17
     ed8:      	add.4s	v25, v25, v12
     edc:      	add.4s	v1, v1, v12
     ee0:      	fadd.4s	v17, v17, v27
     ee4:      	sub.4s	v4, v16, v4
     ee8:      	sub.4s	v3, v3, v31
     eec:      	shl.4s	v3, v3, #0x17
     ef0:      	shl.4s	v31, v4, #0x17
     ef4:      	add	x2, x11, #0x1
     ef8:      	fadd.4s	v4, v8, v27
     efc:      	dup.2d	v16, x2
     f00:      	add.2d	v16, v16, v13
     f04:      	add.2d	v8, v16, v22
     f08:      	add.2d	v9, v16, v18
     f0c:      	mov.16b	v22, v18
     f10:      	fmul.4s	v4, v0, v4
     f14:      	add.2d	v10, v16, v7
     f18:      	add.2d	v16, v16, v19
     f1c:      	mov.d	x2, v16[1]
     f20:      	fmov	x6, d16
     f24:      	fmul.4s	v16, v2, v17
     f28:      	mov.d	x3, v10[1]
     f2c:      	fmov	x7, d10
     f30:      	mov.d	x4, v9[1]
     f34:      	movi.4s	v7, #0x3f, lsl #24
     f38:      	fadd.4s	v10, v16, v7
     f3c:      	fmov	x21, d9
     f40:      	mov.d	x5, v8[1]
     f44:      	fmov	x22, d8
     f48:      	ldp	q17, q16, [x9, #-0x40]
     f4c:      	fadd.4s	v4, v4, v7
     f50:      	fsub.4s	v16, v16, v23
     f54:      	fsub.4s	v17, v17, v23
     f58:      	fcmge.4s	v8, v17, v6
     f5c:      	fcmge.4s	v9, v16, v6
     f60:      	fmul.4s	v4, v30, v4
     f64:      	fcmge.4s	v30, v5, v17
     f68:      	fcmge.4s	v7, v5, v16
     f6c:      	and.16b	v7, v9, v7
     f70:      	and.16b	v30, v8, v30
     f74:      	and.16b	v9, v30, v17
     f78:      	fmul.4s	v29, v29, v10
     f7c:      	and.16b	v7, v7, v16
     f80:      	fmul.4s	v8, v7, v20
     f84:      	fmul.4s	v30, v9, v20
     f88:      	mvni.4s	v21, #0x80, lsl #24
     f8c:      	movi.4s	v11, #0x4b, lsl #24
     f90:      	mov.16b	v10, v21
     f94:      	bsl.16b	v10, v11, v30
     f98:      	fadd.4s	v18, v30, v10
     f9c:      	add.4s	v30, v31, v12
     fa0:      	fsub.4s	v18, v18, v10
     fa4:      	mov.16b	v31, v21
     fa8:      	bsl.16b	v31, v11, v8
     fac:      	fadd.4s	v8, v8, v31
     fb0:      	fsub.4s	v31, v8, v31
     fb4:      	fcvtzs.4s	v31, v31
     fb8:      	fadd.4s	v29, v2, v29
     fbc:      	fcvtzs.4s	v8, v18
     fc0:      	scvtf.4s	v18, v8
     fc4:      	fmul.4s	v2, v18, v26
     fc8:      	fsub.4s	v9, v9, v2
     fcc:      	scvtf.4s	v10, v31
     fd0:      	fadd.4s	v0, v0, v4
     fd4:      	fmul.4s	v2, v10, v26
     fd8:      	fsub.4s	v4, v7, v2
     fdc:      	fcmgt.4s	v2, v6, v15
     fe0:      	fmul.4s	v7, v18, v24
     fe4:      	fmul.4s	v18, v10, v24
     fe8:      	add.4s	v3, v3, v12
     fec:      	fsub.4s	v4, v4, v18
     ff0:      	fsub.4s	v7, v9, v7
     ff4:      	ldp	q21, q11, [sp, #0x130]
     ff8:      	fmul.4s	v18, v7, v11
     ffc:      	fmul.4s	v9, v4, v11
    1000:      	fadd.4s	v9, v9, v28
    1004:      	fadd.4s	v18, v18, v28
    1008:      	fmul.4s	v18, v7, v18
    100c:      	fmul.4s	v9, v4, v9
    1010:      	fadd.4s	v9, v9, v21
    1014:      	fadd.4s	v18, v18, v21
    1018:      	fmul.4s	v18, v7, v18
    101c:      	fmul.4s	v9, v4, v9
    1020:      	ldr	q26, [sp, #0x190]
    1024:      	fadd.4s	v9, v9, v26
    1028:      	fadd.4s	v18, v18, v26
    102c:      	fmul.4s	v18, v7, v18
    1030:      	fmul.4s	v9, v4, v9
    1034:      	fadd.4s	v9, v9, v27
    1038:      	fadd.4s	v29, v29, v12
    103c:      	fadd.4s	v18, v18, v27
    1040:      	fmul.4s	v18, v7, v18
    1044:      	fmul.4s	v9, v4, v9
    1048:      	movi.4s	v26, #0x3f, lsl #24
    104c:      	fadd.4s	v9, v9, v26
    1050:      	fadd.4s	v18, v18, v26
    1054:      	fmul.4s	v1, v29, v1
    1058:      	fmul.4s	v29, v7, v7
    105c:      	fmul.4s	v18, v29, v18
    1060:      	fmul.4s	v29, v4, v4
    1064:      	fmul.4s	v29, v29, v9
    1068:      	fcmgt.4s	v9, v6, v14
    106c:      	fadd.4s	v10, v0, v12
    1070:      	fadd.4s	v4, v4, v29
    1074:      	fcmgt.4s	v0, v15, v5
    1078:      	fadd.4s	v7, v7, v18
    107c:      	fadd.4s	v7, v7, v12
    1080:      	fadd.4s	v4, v4, v12
    1084:      	fmul.4s	v18, v10, v25
    1088:      	sshr.4s	v25, v31, #0x1
    108c:      	shl.4s	v29, v25, #0x17
    1090:      	add.4s	v29, v29, v12
    1094:      	fmul.4s	v4, v4, v29
    1098:      	sshr.4s	v10, v8, #0x1
    109c:      	fmul.4s	v3, v18, v3
    10a0:      	shl.4s	v18, v10, #0x17
    10a4:      	add.4s	v18, v18, v12
    10a8:      	fmul.4s	v7, v7, v18
    10ac:      	fcmgt.4s	v29, v14, v5
    10b0:      	sub.4s	v18, v31, v25
    10b4:      	fmul.4s	v31, v1, v30
    10b8:      	sub.4s	v1, v8, v10
    10bc:      	shl.4s	v1, v1, #0x17
    10c0:      	shl.4s	v18, v18, #0x17
    10c4:      	add.4s	v18, v18, v12
    10c8:      	add.4s	v1, v1, v12
    10cc:      	fmul.4s	v1, v7, v1
    10d0:      	fmul.4s	v4, v4, v18
    10d4:      	fcmgt.4s	v7, v6, v16
    10d8:      	fcmgt.4s	v30, v6, v17
    10dc:      	fcmgt.4s	v25, v17, v5
    10e0:      	add	x19, x11, #0x2
    10e4:      	bic.16b	v31, v31, v2
    10e8:      	dup.2d	v2, x19
    10ec:      	add.2d	v2, v2, v13
    10f0:      	ldr	q18, [sp, #0x160]
    10f4:      	add.2d	v18, v2, v18
    10f8:      	add.2d	v8, v2, v22
    10fc:      	bic.16b	v9, v3, v9
    1100:      	ldr	q3, [sp, #0x170]
    1104:      	add.2d	v3, v2, v3
    1108:      	add.2d	v2, v2, v19
    110c:      	mov.d	x27, v2[1]
    1110:      	mov.d	x26, v3[1]
    1114:      	fmov	x19, d2
    1118:      	fmov	x30, d3
    111c:      	mov.d	x23, v8[1]
    1120:      	fmov	x28, d8
    1124:      	bic.16b	v3, v4, v7
    1128:      	mov.d	x24, v18[1]
    112c:      	fmov	x25, d18
    1130:      	ldp	q4, q2, [x9, #-0x20]
    1134:      	bic.16b	v7, v1, v30
    1138:      	fsub.4s	v1, v4, v23
    113c:      	fsub.4s	v2, v2, v23
    1140:      	fcmge.4s	v4, v2, v6
    1144:      	fcmge.4s	v18, v1, v6
    1148:      	fcmge.4s	v30, v5, v2
    114c:      	ldr	q26, [sp, #0x20]
    1150:      	bsl.16b	v29, v26, v9
    1154:      	fcmge.4s	v8, v5, v1
    1158:      	and.16b	v18, v18, v8
    115c:      	and.16b	v4, v4, v30
    1160:      	and.16b	v4, v4, v2
    1164:      	and.16b	v18, v18, v1
    1168:      	bsl.16b	v0, v26, v31
    116c:      	fmul.4s	v30, v18, v20
    1170:      	fmul.4s	v31, v4, v20
    1174:      	mvni.4s	v9, #0x80, lsl #24
    1178:      	movi.4s	v10, #0x4b, lsl #24
    117c:      	mov.16b	v8, v9
    1180:      	bsl.16b	v8, v10, v31
    1184:      	bsl.16b	v9, v10, v30
    1188:      	fadd.4s	v30, v30, v9
    118c:      	fadd.4s	v31, v31, v8
    1190:      	fsub.4s	v31, v31, v8
    1194:      	fsub.4s	v30, v30, v9
    1198:      	fcvtzs.4s	v8, v30
    119c:      	fcvtzs.4s	v30, v31
    11a0:      	scvtf.4s	v31, v30
    11a4:      	bsl.16b	v25, v26, v7
    11a8:      	scvtf.4s	v7, v8
    11ac:      	ldr	q22, [sp, #0x180]
    11b0:      	fmul.4s	v9, v31, v22
    11b4:      	fsub.4s	v4, v4, v9
    11b8:      	fmul.4s	v9, v7, v22
    11bc:      	fsub.4s	v18, v18, v9
    11c0:      	fcmgt.4s	v9, v16, v5
    11c4:      	fmul.4s	v31, v31, v24
    11c8:      	fmul.4s	v7, v7, v24
    11cc:      	fsub.4s	v7, v18, v7
    11d0:      	fsub.4s	v4, v4, v31
    11d4:      	fmul.4s	v18, v4, v11
    11d8:      	fmul.4s	v31, v7, v11
    11dc:      	fadd.4s	v31, v31, v28
    11e0:      	fadd.4s	v18, v18, v28
    11e4:      	fmul.4s	v18, v4, v18
    11e8:      	fmul.4s	v31, v7, v31
    11ec:      	fadd.4s	v31, v31, v21
    11f0:      	fadd.4s	v18, v18, v21
    11f4:      	fmul.4s	v18, v4, v18
    11f8:      	fmul.4s	v31, v7, v31
    11fc:      	ldr	q22, [sp, #0x190]
    1200:      	fadd.4s	v31, v31, v22
    1204:      	fadd.4s	v18, v18, v22
    1208:      	fmul.4s	v18, v4, v18
    120c:      	fmul.4s	v31, v7, v31
    1210:      	fadd.4s	v31, v31, v27
    1214:      	fadd.4s	v18, v18, v27
    1218:      	fmul.4s	v18, v4, v18
    121c:      	fmul.4s	v31, v7, v31
    1220:      	movi.4s	v22, #0x3f, lsl #24
    1224:      	fadd.4s	v10, v31, v22
    1228:      	mov.16b	v31, v9
    122c:      	bsl.16b	v31, v26, v3
    1230:      	fadd.4s	v3, v18, v22
    1234:      	fmul.4s	v18, v4, v4
    1238:      	fmul.4s	v3, v18, v3
    123c:      	fmul.4s	v18, v7, v7
    1240:      	fmul.4s	v18, v18, v10
    1244:      	fcmeq.4s	v9, v15, v15
    1248:      	fadd.4s	v7, v7, v18
    124c:      	fadd.4s	v3, v4, v3
    1250:      	fadd.4s	v4, v7, v12
    1254:      	sshr.4s	v7, v30, #0x1
    1258:      	sshr.4s	v18, v8, #0x1
    125c:      	ldr	q22, [sp, #0x10]
    1260:      	bif.16b	v0, v22, v9
    1264:      	shl.4s	v9, v18, #0x17
    1268:      	add.4s	v9, v9, v12
    126c:      	fmul.4s	v4, v4, v9
    1270:      	shl.4s	v9, v7, #0x17
    1274:      	add.4s	v9, v9, v12
    1278:      	fadd.4s	v3, v3, v12
    127c:      	fmul.4s	v9, v3, v9
    1280:      	ldr	b3, [x16]
    1284:      	ld1.b	{ v3 }[1], [x12]
    1288:      	ld1.b	{ v3 }[2], [x0]
    128c:      	ld1.b	{ v3 }[3], [x15]
    1290:      	sub.4s	v18, v8, v18
    1294:      	ldr	b8, [x6]
    1298:      	ld1.b	{ v3 }[4], [x1]
    129c:      	ld1.b	{ v8 }[1], [x2]
    12a0:      	ld1.b	{ v8 }[2], [x7]
    12a4:      	ld1.b	{ v3 }[5], [x14]
    12a8:      	ld1.b	{ v8 }[3], [x3]
    12ac:      	ld1.b	{ v8 }[4], [x21]
    12b0:      	ld1.b	{ v3 }[6], [x17]
    12b4:      	ld1.b	{ v8 }[5], [x4]
    12b8:      	ld1.b	{ v8 }[6], [x22]
    12bc:      	ld1.b	{ v3 }[7], [x13]
    12c0:      	sub.4s	v7, v30, v7
    12c4:      	ld1.b	{ v8 }[7], [x5]
    12c8:      	cmeq.8b	v30, v3, #0
    12cc:      	fcmeq.4s	v3, v14, v14
    12d0:      	bsl.16b	v3, v29, v22
    12d4:      	ldr	b10, [x19]
    12d8:      	ld1.b	{ v10 }[1], [x27]
    12dc:      	ld1.b	{ v10 }[2], [x30]
    12e0:      	sshll.8h	v29, v30, #0x0
    12e4:      	cmeq.8b	v30, v8, #0
    12e8:      	ld1.b	{ v10 }[3], [x26]
    12ec:      	ld1.b	{ v10 }[4], [x28]
    12f0:      	sshll.8h	v8, v30, #0x0
    12f4:      	fcmeq.4s	v17, v17, v17
    12f8:      	shl.4s	v7, v7, #0x17
    12fc:      	shl.4s	v18, v18, #0x17
    1300:      	add.4s	v7, v7, v12
    1304:      	fmul.4s	v7, v9, v7
    1308:      	sshll2.4s	v30, v29, #0x0
    130c:      	add.4s	v18, v18, v12
    1310:      	fmul.4s	v4, v4, v18
    1314:      	fcmgt.4s	v18, v6, v1
    1318:      	bic.16b	v4, v4, v18
    131c:      	fcmgt.4s	v18, v6, v2
    1320:      	sshll.4s	v15, v29, #0x0
    1324:      	bic.16b	v7, v7, v18
    1328:      	fcmgt.4s	v18, v2, v5
    132c:      	bit.16b	v7, v26, v18
    1330:      	fcmgt.4s	v18, v1, v5
    1334:      	bit.16b	v4, v26, v18
    1338:      	sshll2.4s	v29, v8, #0x0
    133c:      	fcmeq.4s	v18, v16, v16
    1340:      	ld1.b	{ v10 }[5], [x23]
    1344:      	ld1.b	{ v10 }[6], [x25]
    1348:      	sshll.4s	v14, v8, #0x0
    134c:      	ld1.b	{ v10 }[7], [x24]
    1350:      	cmeq.8b	v16, v10, #0
    1354:      	sshll.8h	v16, v16, #0x0
    1358:      	fcmeq.4s	v2, v2, v2
    135c:      	bif.16b	v31, v22, v18
    1360:      	fcmeq.4s	v1, v1, v1
    1364:      	add	x12, x11, #0x3
    1368:      	dup.2d	v18, x12
    136c:      	add.2d	v18, v18, v13
    1370:      	mov.16b	v13, v17
    1374:      	bsl.16b	v13, v25, v22
    1378:      	ldr	q17, [sp, #0x170]
    137c:      	add.2d	v17, v18, v17
    1380:      	add.2d	v25, v18, v19
    1384:      	mov.d	x14, v25[1]
    1388:      	fmov	x15, d25
    138c:      	sshll2.4s	v25, v16, #0x0
    1390:      	mov.d	x16, v17[1]
    1394:      	fmov	x17, d17
    1398:      	ldp	q19, q17, [sp, #0x150]
    139c:      	add.2d	v9, v18, v17
    13a0:      	ldr	q17, [sp, #0x120]
    13a4:      	add.2d	v18, v18, v17
    13a8:      	mov.16b	v17, v1
    13ac:      	bsl.16b	v17, v4, v22
    13b0:      	mov.d	x0, v18[1]
    13b4:      	fmov	x1, d18
    13b8:      	mov.d	x12, v9[1]
    13bc:      	mov.16b	v8, v2
    13c0:      	bsl.16b	v8, v7, v22
    13c4:      	fmov	x13, d9
    13c8:      	ldp	q1, q2, [x9]
    13cc:      	fsub.4s	v2, v2, v23
    13d0:      	fsub.4s	v1, v1, v23
    13d4:      	bic.16b	v3, v3, v15
    13d8:      	fcmge.4s	v4, v1, v6
    13dc:      	fcmge.4s	v7, v2, v6
    13e0:      	fcmge.4s	v18, v5, v2
    13e4:      	and.16b	v7, v7, v18
    13e8:      	fcmge.4s	v18, v5, v1
    13ec:      	bic.16b	v30, v0, v30
    13f0:      	and.16b	v0, v4, v18
    13f4:      	and.16b	v4, v0, v1
    13f8:      	and.16b	v7, v7, v2
    13fc:      	fmul.4s	v18, v7, v20
    1400:      	fmul.4s	v9, v4, v20
    1404:      	ldr	q20, [sp, #0x100]
    1408:      	bic.16b	v0, v13, v14
    140c:      	movi.4s	v23, #0x4b, lsl #24
    1410:      	mvni.4s	v13, #0x80, lsl #24
    1414:      	mov.16b	v10, v13
    1418:      	bsl.16b	v10, v23, v9
    141c:      	fadd.4s	v9, v9, v10
    1420:      	fsub.4s	v9, v9, v10
    1424:      	mov.16b	v10, v13
    1428:      	bsl.16b	v10, v23, v18
    142c:      	fadd.4s	v18, v18, v10
    1430:      	bic.16b	v29, v31, v29
    1434:      	fsub.4s	v18, v18, v10
    1438:      	fcvtzs.4s	v18, v18
    143c:      	fcvtzs.4s	v31, v9
    1440:      	scvtf.4s	v9, v31
    1444:      	scvtf.4s	v10, v18
    1448:      	bic.16b	v25, v8, v25
    144c:      	ldr	q23, [sp, #0x180]
    1450:      	fmul.4s	v8, v9, v23
    1454:      	fsub.4s	v4, v4, v8
    1458:      	fmul.4s	v8, v10, v23
    145c:      	ldr	q23, [sp, #0xf0]
    1460:      	fsub.4s	v7, v7, v8
    1464:      	fmul.4s	v8, v9, v24
    1468:      	sshll.4s	v16, v16, #0x0
    146c:      	fmul.4s	v9, v10, v24
    1470:      	fsub.4s	v7, v7, v9
    1474:      	fsub.4s	v4, v4, v8
    1478:      	fmul.4s	v8, v4, v11
    147c:      	fmul.4s	v9, v7, v11
    1480:      	fadd.4s	v9, v9, v28
    1484:      	fadd.4s	v8, v8, v28
    1488:      	ldr	q28, [sp, #0x110]
    148c:      	fmul.4s	v8, v4, v8
    1490:      	fmul.4s	v9, v7, v9
    1494:      	fadd.4s	v9, v9, v21
    1498:      	fadd.4s	v8, v8, v21
    149c:      	fmul.4s	v8, v4, v8
    14a0:      	fmul.4s	v9, v7, v9
    14a4:      	ldr	q24, [sp, #0x190]
    14a8:      	fadd.4s	v9, v9, v24
    14ac:      	fadd.4s	v8, v8, v24
    14b0:      	fmul.4s	v8, v4, v8
    14b4:      	fmul.4s	v9, v7, v9
    14b8:      	fadd.4s	v9, v9, v27
    14bc:      	fadd.4s	v8, v8, v27
    14c0:      	fmul.4s	v8, v4, v8
    14c4:      	fmul.4s	v9, v7, v9
    14c8:      	movi.4s	v24, #0x3f, lsl #24
    14cc:      	fadd.4s	v9, v9, v24
    14d0:      	fadd.4s	v8, v8, v24
    14d4:      	bic.16b	v16, v17, v16
    14d8:      	fmul.4s	v17, v4, v4
    14dc:      	fmul.4s	v17, v17, v8
    14e0:      	fmul.4s	v8, v7, v7
    14e4:      	fmul.4s	v8, v8, v9
    14e8:      	ldr	q9, [sp, #0xe0]
    14ec:      	fadd.4s	v19, v19, v30
    14f0:      	stp	q3, q30, [x8, #-0x60]
    14f4:      	fadd.4s	v7, v7, v8
    14f8:      	fadd.4s	v4, v4, v17
    14fc:      	fadd.4s	v7, v7, v12
    1500:      	sshr.4s	v17, v31, #0x1
    1504:      	fadd.4s	v28, v28, v3
    1508:      	sshr.4s	v3, v18, #0x1
    150c:      	shl.4s	v30, v3, #0x17
    1510:      	add.4s	v30, v30, v12
    1514:      	fmul.4s	v7, v7, v30
    1518:      	shl.4s	v30, v17, #0x17
    151c:      	fadd.4s	v4, v4, v12
    1520:      	add.4s	v30, v30, v12
    1524:      	fmul.4s	v4, v4, v30
    1528:      	fadd.4s	v23, v23, v29
    152c:      	stp	q0, q29, [x8, #-0x40]
    1530:      	fadd.4s	v20, v20, v0
    1534:      	sub.4s	v0, v18, v3
    1538:      	sub.4s	v3, v31, v17
    153c:      	ldr	q17, [sp, #0xd0]
    1540:      	fadd.4s	v17, v17, v25
    1544:      	stp	q16, q25, [x8, #-0x20]
    1548:      	fadd.4s	v9, v9, v16
    154c:      	shl.4s	v3, v3, #0x17
    1550:      	add.4s	v3, v3, v12
    1554:      	fmul.4s	v3, v4, v3
    1558:      	ldr	b4, [x15]
    155c:      	ld1.b	{ v4 }[1], [x14]
    1560:      	ld1.b	{ v4 }[2], [x17]
    1564:      	ld1.b	{ v4 }[3], [x16]
    1568:      	ld1.b	{ v4 }[4], [x1]
    156c:      	ld1.b	{ v4 }[5], [x0]
    1570:      	shl.4s	v0, v0, #0x17
    1574:      	add.4s	v0, v0, v12
    1578:      	fmul.4s	v0, v7, v0
    157c:      	fcmgt.4s	v7, v6, v2
    1580:      	bic.16b	v0, v0, v7
    1584:      	fcmgt.4s	v7, v6, v1
    1588:      	bic.16b	v3, v3, v7
    158c:      	fcmgt.4s	v7, v1, v5
    1590:      	bit.16b	v3, v26, v7
    1594:      	fcmgt.4s	v7, v2, v5
    1598:      	bit.16b	v0, v26, v7
    159c:      	ld1.b	{ v4 }[6], [x13]
    15a0:      	ld1.b	{ v4 }[7], [x12]
    15a4:      	fcmeq.4s	v2, v2, v2
    15a8:      	bif.16b	v0, v22, v2
    15ac:      	cmeq.8b	v2, v4, #0
    15b0:      	sshll.8h	v2, v2, #0x0
    15b4:      	fcmeq.4s	v1, v1, v1
    15b8:      	bsl.16b	v1, v3, v22
    15bc:      	sshll.4s	v3, v2, #0x0
    15c0:      	bic.16b	v1, v1, v3
    15c4:      	sshll2.4s	v2, v2, #0x0
    15c8:      	bic.16b	v0, v0, v2
    15cc:      	ldp	q3, q2, [sp, #0xb0]
    15d0:      	fadd.4s	v3, v3, v0
    15d4:      	stp	q1, q0, [x8], #0x80
    15d8:      	fadd.4s	v2, v2, v1
    15dc:      	add	x9, x9, #0x80
    15e0:      	cmp	x11, #0x5c
    15e4:      	add	x11, x11, #0x4
    15e8:      	b.lo	0xd8c <ltmp0+0xd8c>
    15ec:      	mov	x8, #0x0                ; =0
    15f0:      	fadd.4s	v0, v28, v20
    15f4:      	fadd.4s	v1, v19, v23
    15f8:      	fadd.4s	v1, v1, v17
    15fc:      	fadd.4s	v0, v0, v9
    1600:      	fadd.4s	v0, v0, v2
    1604:      	fadd.4s	v1, v1, v3
    1608:      	rev64.4s	v2, v1
    160c:      	rev64.4s	v3, v0
    1610:      	fadd.4s	v1, v1, v2
    1614:      	dup.4s	v2, v1[2]
    1618:      	fadd.4s	v0, v0, v3
    161c:      	dup.4s	v3, v0[2]
    1620:      	fadd.4s	v0, v0, v3
    1624:      	fadd.4s	v1, v1, v2
    1628:      	fadd.4s	v0, v0, v1
    162c:      	movi	d1, #0000000000000000
    1630:      	fadd	s0, s0, s1
    1634:      	dup.4s	v0, v0[0]
    1638:      	ldr	x9, [sp, #0x8]
    163c:      	add	x9, x9, x20
    1640:      	add	x10, sp, #0x1a0
    1644:      	add	x11, x10, x8
    1648:      	ldp	q2, q1, [x11]
    164c:      	fdiv.4s	v2, v2, v0
    1650:      	fdiv.4s	v1, v1, v0
    1654:      	add	x11, x9, x8
    1658:      	stp	q2, q1, [x11]
    165c:      	add	x8, x8, #0x20
    1660:      	cmp	x8, #0xc00
    1664:      	b.ne	0x1644 <ltmp0+0x1644>
    1668:      	add	sp, sp, #0x4, lsl #12   ; =0x4000
    166c:      	add	sp, sp, #0xa0
    1670:      	ldp	x29, x30, [sp, #0x90]
    1674:      	ldp	x20, x19, [sp, #0x80]
    1678:      	ldp	x22, x21, [sp, #0x70]
    167c:      	ldp	x24, x23, [sp, #0x60]
    1680:      	ldp	x26, x25, [sp, #0x50]
    1684:      	ldp	x28, x27, [sp, #0x40]
    1688:      	ldp	d9, d8, [sp, #0x30]
    168c:      	ldp	d11, d10, [sp, #0x20]
    1690:      	ldp	d13, d12, [sp, #0x10]
    1694:      	ldp	d15, d14, [sp], #0xa0
    1698:      	ret

000000000000169c <_llm_rows.packet_batch.blocks>:
    169c:      	stp	d15, d14, [sp, #-0xa0]!
    16a0:      	stp	d13, d12, [sp, #0x10]
    16a4:      	stp	d11, d10, [sp, #0x20]
    16a8:      	stp	d9, d8, [sp, #0x30]
    16ac:      	stp	x28, x27, [sp, #0x40]
    16b0:      	stp	x26, x25, [sp, #0x50]
    16b4:      	stp	x24, x23, [sp, #0x60]
    16b8:      	stp	x22, x21, [sp, #0x70]
    16bc:      	stp	x20, x19, [sp, #0x80]
    16c0:      	stp	x29, x30, [sp, #0x90]
    16c4:      	sub	sp, sp, #0x4, lsl #12   ; =0x4000
    16c8:      	sub	sp, sp, #0x660
    16cc:      	str	x0, [sp, #0xe8]
    16d0:      	cbz	w3, 0x4380 <_llm_rows.packet_batch.blocks+0x2ce4>
    16d4:      	mov	x19, x3
    16d8:      	mov	x20, x2
    16dc:      	mov	w22, #0x0               ; =0
    16e0:      	add	x23, sp, #0x260
    16e4:      	add	x8, sp, #0x1, lsl #12   ; =0x1000
    16e8:      	add	x8, x8, #0xf60
    16ec:      	add	x9, sp, #0x3, lsl #12   ; =0x3000
    16f0:      	add	x9, x9, #0xa60
    16f4:      	dup.2d	v0, x8
    16f8:      	str	q0, [sp, #0x50]
    16fc:      	add	x10, x9, #0xe0
    1700:      	add	x8, sp, #0x1, lsl #12   ; =0x1000
    1704:      	add	x8, x8, #0x360
    1708:      	add	x8, x8, #0xe0
    170c:      	str	x8, [sp, #0xb0]
    1710:      	add	x8, sp, #0x760
    1714:      	add	x8, x8, #0xe0
    1718:      	stp	x8, x10, [sp, #0x40]
    171c:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1720:      	ldr	q0, [x8]
    1724:      	str	q0, [sp, #0x30]
    1728:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    172c:      	ldr	q0, [x8]
    1730:      	str	q0, [sp, #0xd0]
    1734:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1738:      	ldr	q0, [x8]
    173c:      	str	q0, [sp, #0xc0]
    1740:      	adrp	x15, 0x1000 <ltmp0+0x1000>
    1744:      	adrp	x16, 0x1000 <ltmp0+0x1000>
    1748:      	add	x21, sp, #0x2, lsl #12  ; =0x2000
    174c:      	add	x21, x21, #0x260
    1750:      	movi.8b	v8, #0x1
    1754:      	mov	w8, #0x40               ; =64
    1758:      	fmov	d0, x8
    175c:      	str	q0, [sp, #0x20]
    1760:      	mov	w8, #0x60               ; =96
    1764:      	fmov	d0, x8
    1768:      	str	q0, [sp, #0x10]
    176c:      	mvni.4s	v0, #0x7f, msl #16
    1770:      	fneg.4s	v1, v0
    1774:      	mvni.4s	v0, #0x3f, msl #16
    1778:      	fneg.4s	v0, v0
    177c:      	stp	q0, q1, [sp, #0x160]
    1780:      	ldp	w9, w8, [x2, #0x2c]
    1784:      	stp	w8, w9, [sp, #0xe0]
    1788:      	ldp	w24, w27, [x2]
    178c:      	ldp	w26, w25, [x2, #0x8]
    1790:      	str	w3, [sp, #0xbc]
    1794:      	b	0x17dc <_llm_rows.packet_batch.blocks+0x140>
    1798:      	mov	w8, #0x18               ; =24
    179c:      	str	w8, [x20, #0x24]
    17a0:      	ldr	w19, [sp, #0xbc]
    17a4:      	add	w8, w24, #0x1
    17a8:      	ldp	w10, w9, [sp, #0xe0]
    17ac:      	cmp	w8, w9
    17b0:      	cset	w8, eq
    17b4:      	csinc	w24, wzr, w24, eq
    17b8:      	cinc	w9, w27, eq
    17bc:      	cmp	w9, w10
    17c0:      	cset	w10, eq
    17c4:      	ands	w8, w8, w10
    17c8:      	csel	w27, wzr, w9, ne
    17cc:      	add	w26, w26, w8
    17d0:      	add	w22, w22, #0x1
    17d4:      	cmp	w22, w19
    17d8:      	b.eq	0x4380 <_llm_rows.packet_batch.blocks+0x2ce4>
    17dc:      	ubfiz	x8, x24, #5, #32
    17e0:      	cmp	x8, x25
    17e4:      	csel	x9, x8, xzr, ls
    17e8:      	subs	x10, x25, x9
    17ec:      	cmp	x10, #0x20
    17f0:      	mov	w11, #0x20              ; =32
    17f4:      	csel	x10, x10, x11, lo
    17f8:      	cmp	x25, x9
    17fc:      	stp	w24, w27, [x20]
    1800:      	str	w26, [x20, #0x8]
    1804:      	str	wzr, [x20, #0x24]
    1808:      	ccmp	x8, x25, #0x2, hi
    180c:      	csel	x28, x10, xzr, ls
    1810:      	cmp	x28, #0x20
    1814:      	b.lo	0x1870 <_llm_rows.packet_batch.blocks+0x1d4>
    1818:      	ldr	x28, [sp, #0xe8]
    181c:      	mov	x0, x28
    1820:      	mov	x1, x20
    1824:      	bl	0x1824 <_llm_rows.packet_batch.blocks+0x188>
    1828:      	mov	w8, #0x8                ; =8
    182c:      	str	w8, [x20, #0x24]
    1830:      	mov	x0, x28
    1834:      	mov	x1, x20
    1838:      	bl	0x1838 <_llm_rows.packet_batch.blocks+0x19c>
    183c:      	mov	w8, #0x10               ; =16
    1840:      	str	w8, [x20, #0x24]
    1844:      	mov	x0, x28
    1848:      	mov	x1, x20
    184c:      	bl	0x184c <_llm_rows.packet_batch.blocks+0x1b0>
    1850:      	mov	w8, #0x18               ; =24
    1854:      	str	w8, [x20, #0x24]
    1858:      	mov	x0, x28
    185c:      	mov	x1, x20
    1860:      	bl	0x1860 <_llm_rows.packet_batch.blocks+0x1c4>
    1864:      	adrp	x16, 0x1000 <ltmp0+0x1000>
    1868:      	adrp	x15, 0x1000 <ltmp0+0x1000>
    186c:      	b	0x17a4 <_llm_rows.packet_batch.blocks+0x108>
    1870:      	lsr	x19, x28, #3
    1874:      	cmp	x28, #0x8
    1878:      	b.lo	0x18dc <_llm_rows.packet_batch.blocks+0x240>
    187c:      	str	wzr, [x20, #0x24]
    1880:      	ldr	x0, [sp, #0xe8]
    1884:      	mov	x1, x20
    1888:      	bl	0x1888 <_llm_rows.packet_batch.blocks+0x1ec>
    188c:      	adrp	x16, 0x1000 <ltmp0+0x1000>
    1890:      	adrp	x15, 0x1000 <ltmp0+0x1000>
    1894:      	cmp	x19, #0x1
    1898:      	b.eq	0x18dc <_llm_rows.packet_batch.blocks+0x240>
    189c:      	mov	w8, #0x8                ; =8
    18a0:      	str	w8, [x20, #0x24]
    18a4:      	ldr	x0, [sp, #0xe8]
    18a8:      	mov	x1, x20
    18ac:      	bl	0x18ac <_llm_rows.packet_batch.blocks+0x210>
    18b0:      	adrp	x16, 0x1000 <ltmp0+0x1000>
    18b4:      	adrp	x15, 0x1000 <ltmp0+0x1000>
    18b8:      	cmp	x19, #0x2
    18bc:      	b.eq	0x18dc <_llm_rows.packet_batch.blocks+0x240>
    18c0:      	mov	w8, #0x10               ; =16
    18c4:      	str	w8, [x20, #0x24]
    18c8:      	ldr	x0, [sp, #0xe8]
    18cc:      	mov	x1, x20
    18d0:      	bl	0x18d0 <_llm_rows.packet_batch.blocks+0x234>
    18d4:      	adrp	x16, 0x1000 <ltmp0+0x1000>
    18d8:      	adrp	x15, 0x1000 <ltmp0+0x1000>
    18dc:      	and	w8, w28, #0x7
    18e0:      	add	x14, sp, #0x3, lsl #12  ; =0x3000
    18e4:      	add	x14, x14, #0xa60
    18e8:      	add	x28, sp, #0x760
    18ec:      	cbz	w8, 0x1798 <_llm_rows.packet_batch.blocks+0xfc>
    18f0:      	dup.4s	v3, w8
    18f4:      	ldp	q0, q1, [sp, #0xc0]
    18f8:      	cmhi.4s	v0, v3, v0
    18fc:      	cmhi.4s	v1, v3, v1
    1900:      	uzp1.8h	v19, v1, v0
    1904:      	umaxv.8h	h2, v19
    1908:      	fmov	w8, s2
    190c:      	tbz	w8, #0x0, 0x1798 <_llm_rows.packet_batch.blocks+0xfc>
    1910:      	mov	x8, #0x0                ; =0
    1914:      	ldr	x10, [sp, #0xe8]
    1918:      	ldr	x9, [x10, #0x30]
    191c:      	str	x9, [sp, #0xa8]
    1920:      	ldr	q2, [sp, #0x30]
    1924:      	and.16b	v2, v19, v2
    1928:      	addv.8h	h31, v2
    192c:      	fmov	w9, s31
    1930:      	and	w6, w9, #0xff
    1934:      	ubfiz	w9, w24, #2, #27
    1938:      	orr	w9, w9, w19
    193c:      	dup.4s	v5, w9
    1940:      	ldr	x9, [x10]
    1944:      	and.16b	v4, v1, v5
    1948:      	fmov	w10, s4
    194c:      	mov	w11, #0xc00             ; =3072
    1950:      	umull	x12, w10, w11
    1954:      	str	x12, [sp, #0xa0]
    1958:      	umaddl	x9, w10, w11, x9
    195c:      	fmov	w10, s31
    1960:      	b	0x1984 <_llm_rows.packet_batch.blocks+0x2e8>
    1964:      	add	x11, x14, x8
    1968:      	ldp	q7, q16, [x11]
    196c:      	bif.16b	v6, v16, v0
    1970:      	bif.16b	v2, v7, v1
    1974:      	stp	q2, q6, [x11]
    1978:      	add	x8, x8, #0x20
    197c:      	cmp	x8, #0xc00
    1980:      	b.eq	0x1a18 <_llm_rows.packet_batch.blocks+0x37c>
    1984:      	add	x11, x9, x8
    1988:      	movi.2d	v2, #0000000000000000
    198c:      	movi.2d	v6, #0000000000000000
    1990:      	tbnz	w10, #0x0, 0x19b8 <_llm_rows.packet_batch.blocks+0x31c>
    1994:      	and	w12, w10, #0xff
    1998:      	tbnz	w12, #0x1, 0x19c4 <_llm_rows.packet_batch.blocks+0x328>
    199c:      	tbnz	w12, #0x2, 0x19d0 <_llm_rows.packet_batch.blocks+0x334>
    19a0:      	tbnz	w12, #0x3, 0x19dc <_llm_rows.packet_batch.blocks+0x340>
    19a4:      	tbnz	w12, #0x4, 0x19e8 <_llm_rows.packet_batch.blocks+0x34c>
    19a8:      	tbnz	w12, #0x5, 0x19f4 <_llm_rows.packet_batch.blocks+0x358>
    19ac:      	tbnz	w12, #0x6, 0x1a00 <_llm_rows.packet_batch.blocks+0x364>
    19b0:      	tbz	w12, #0x7, 0x1964 <_llm_rows.packet_batch.blocks+0x2c8>
    19b4:      	b	0x1a0c <_llm_rows.packet_batch.blocks+0x370>
    19b8:      	ldr	s2, [x11]
    19bc:      	and	w12, w10, #0xff
    19c0:      	tbz	w12, #0x1, 0x199c <_llm_rows.packet_batch.blocks+0x300>
    19c4:      	add	x13, x11, #0x4
    19c8:      	ld1.s	{ v2 }[1], [x13]
    19cc:      	tbz	w12, #0x2, 0x19a0 <_llm_rows.packet_batch.blocks+0x304>
    19d0:      	add	x13, x11, #0x8
    19d4:      	ld1.s	{ v2 }[2], [x13]
    19d8:      	tbz	w12, #0x3, 0x19a4 <_llm_rows.packet_batch.blocks+0x308>
    19dc:      	add	x13, x11, #0xc
    19e0:      	ld1.s	{ v2 }[3], [x13]
    19e4:      	tbz	w12, #0x4, 0x19a8 <_llm_rows.packet_batch.blocks+0x30c>
    19e8:      	add	x13, x11, #0x10
    19ec:      	ld1.s	{ v6 }[0], [x13]
    19f0:      	tbz	w12, #0x5, 0x19ac <_llm_rows.packet_batch.blocks+0x310>
    19f4:      	add	x13, x11, #0x14
    19f8:      	ld1.s	{ v6 }[1], [x13]
    19fc:      	tbz	w12, #0x6, 0x19b0 <_llm_rows.packet_batch.blocks+0x314>
    1a00:      	add	x13, x11, #0x18
    1a04:      	ld1.s	{ v6 }[2], [x13]
    1a08:      	tbz	w12, #0x7, 0x1964 <_llm_rows.packet_batch.blocks+0x2c8>
    1a0c:      	add	x11, x11, #0x1c
    1a10:      	ld1.s	{ v6 }[3], [x11]
    1a14:      	b	0x1964 <_llm_rows.packet_batch.blocks+0x2c8>
    1a18:      	mov	x8, #0x0                ; =0
    1a1c:      	add	x9, sp, #0x2, lsl #12   ; =0x2000
    1a20:      	add	x9, x9, #0x260
    1a24:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    1a28:      	adrp	x11, 0x1000 <ltmp0+0x1000>
    1a2c:      	sshll2.2d	v7, v0, #0x0
    1a30:      	sshll2.2d	v16, v1, #0x0
    1a34:      	sshll.2d	v2, v0, #0x0
    1a38:      	dup.2d	v6, x8
    1a3c:      	sshll.2d	v17, v1, #0x0
    1a40:      	ldr	q18, [x10]
    1a44:      	orr.16b	v18, v6, v18
    1a48:      	ldr	q20, [x11]
    1a4c:      	orr.16b	v20, v6, v20
    1a50:      	ldr	q21, [x15]
    1a54:      	orr.16b	v21, v6, v21
    1a58:      	ldr	q22, [x16]
    1a5c:      	orr.16b	v6, v6, v22
    1a60:      	ldp	q23, q22, [x9, #0x20]
    1a64:      	ldp	q25, q24, [x9]
    1a68:      	bif.16b	v6, v25, v17
    1a6c:      	bsl.16b	v2, v21, v23
    1a70:      	mov.16b	v17, v16
    1a74:      	bsl.16b	v17, v20, v24
    1a78:      	bif.16b	v18, v22, v7
    1a7c:      	stp	q2, q18, [x9, #0x20]
    1a80:      	stp	q6, q17, [x9], #0x40
    1a84:      	add	x8, x8, #0x8
    1a88:      	cmp	x8, #0x300
    1a8c:      	b.ne	0x1a2c <_llm_rows.packet_batch.blocks+0x390>
    1a90:      	mov	x8, #0x0                ; =0
    1a94:      	sshll.2d	v6, v1, #0x0
    1a98:      	sshll.2d	v26, v0, #0x0
    1a9c:      	and.16b	v2, v0, v5
    1aa0:      	movi.4s	v18, #0x3, lsl #8
    1aa4:      	and.16b	v5, v0, v18
    1aa8:      	mvn.16b	v17, v0
    1aac:      	sub.4s	v5, v5, v17
    1ab0:      	and.16b	v17, v1, v18
    1ab4:      	mvn.16b	v18, v1
    1ab8:      	sub.4s	v17, v17, v18
    1abc:      	mov.s	w9, v17[1]
    1ac0:      	mov.s	w10, v4[1]
    1ac4:      	udiv	w11, w10, w9
    1ac8:      	msub	w9, w11, w9, w10
    1acc:      	mov.s	w10, v17[3]
    1ad0:      	mov.s	w11, v17[2]
    1ad4:      	fmov	w12, s17
    1ad8:      	fmov	w13, s4
    1adc:      	udiv	w14, w13, w12
    1ae0:      	msub	w12, w14, w12, w13
    1ae4:      	mov.s	w13, v4[3]
    1ae8:      	udiv	w14, w13, w10
    1aec:      	msub	w10, w14, w10, w13
    1af0:      	mov.s	w13, v4[2]
    1af4:      	udiv	w14, w13, w11
    1af8:      	msub	w11, w14, w11, w13
    1afc:      	mov.s	w13, v5[1]
    1b00:      	mov.s	w14, v2[1]
    1b04:      	udiv	w15, w14, w13
    1b08:      	msub	w13, w15, w13, w14
    1b0c:      	mov.s	w14, v5[3]
    1b10:      	mov.s	w15, v2[3]
    1b14:      	udiv	w16, w15, w14
    1b18:      	msub	w14, w16, w14, w15
    1b1c:      	mov.s	w15, v5[2]
    1b20:      	mov.s	w16, v2[2]
    1b24:      	udiv	w17, w16, w15
    1b28:      	msub	w15, w17, w15, w16
    1b2c:      	fmov	w16, s5
    1b30:      	fmov	w17, s2
    1b34:      	fmov	s2, w15
    1b38:      	mov.s	v2[1], w14
    1b3c:      	udiv	w14, w17, w16
    1b40:      	msub	w14, w14, w16, w17
    1b44:      	ushll.2d	v2, v2, #0x0
    1b48:      	fmov	s4, w14
    1b4c:      	mov.s	v4[1], w13
    1b50:      	ushll.2d	v22, v4, #0x0
    1b54:      	fmov	s4, w11
    1b58:      	mov.s	v4[1], w10
    1b5c:      	fmov	s5, w12
    1b60:      	mov.s	v5[1], w9
    1b64:      	ushll.2d	v23, v4, #0x0
    1b68:      	ushll.2d	v24, v5, #0x0
    1b6c:      	ldr	q4, [sp, #0x50]
    1b70:      	and.16b	v17, v7, v4
    1b74:      	and.16b	v20, v16, v4
    1b78:      	and.16b	v18, v26, v4
    1b7c:      	and.16b	v21, v6, v4
    1b80:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    1b84:      	ldr	q4, [x9]
    1b88:      	and.16b	v25, v7, v4
    1b8c:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    1b90:      	ldr	q4, [x9]
    1b94:      	and.16b	v27, v16, v4
    1b98:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    1b9c:      	ldr	q4, [x9]
    1ba0:      	and.16b	v26, v26, v4
    1ba4:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    1ba8:      	ldr	q4, [x9]
    1bac:      	and.16b	v28, v6, v4
    1bb0:      	ldp	q4, q5, [sp, #0xc0]
    1bb4:      	cmhs.4s	v4, v4, v3
    1bb8:      	cmhs.4s	v3, v5, v3
    1bbc:      	uzp1.8h	v3, v3, v4
    1bc0:      	xtn.8b	v3, v3
    1bc4:      	b	0x1bd4 <_llm_rows.packet_batch.blocks+0x538>
    1bc8:      	add	x8, x8, #0x1
    1bcc:      	cmp	x8, #0x60
    1bd0:      	b.eq	0x1cf0 <_llm_rows.packet_batch.blocks+0x654>
    1bd4:      	dup.2d	v4, x8
    1bd8:      	fmov	w9, s31
    1bdc:      	add	x10, x21, x8, lsl #6
    1be0:      	ldp	q6, q5, [x10, #0x20]
    1be4:      	ldp	q29, q30, [x10]
    1be8:      	cmge.2d	v30, v23, v30
    1bec:      	cmge.2d	v29, v24, v29
    1bf0:      	uzp1.4s	v29, v29, v30
    1bf4:      	cmge.2d	v6, v22, v6
    1bf8:      	cmge.2d	v5, v2, v5
    1bfc:      	uzp1.4s	v5, v6, v5
    1c00:      	uzp1.8h	v5, v29, v5
    1c04:      	xtn.8b	v5, v5
    1c08:      	orr.8b	v5, v3, v5
    1c0c:      	add.2d	v6, v21, v28
    1c10:      	str	q6, [sp, #0x1c0]
    1c14:      	add.2d	v6, v6, v4
    1c18:      	and.8b	v5, v5, v8
    1c1c:      	tbnz	w9, #0x0, 0x1c68 <_llm_rows.packet_batch.blocks+0x5cc>
    1c20:      	and	w9, w9, #0xff
    1c24:      	tbnz	w9, #0x1, 0x1c78 <_llm_rows.packet_batch.blocks+0x5dc>
    1c28:      	add.2d	v6, v20, v27
    1c2c:      	str	q6, [sp, #0x1b0]
    1c30:      	add.2d	v6, v6, v4
    1c34:      	tbnz	w9, #0x2, 0x1c90 <_llm_rows.packet_batch.blocks+0x5f4>
    1c38:      	tbnz	w9, #0x3, 0x1c9c <_llm_rows.packet_batch.blocks+0x600>
    1c3c:      	add.2d	v6, v18, v26
    1c40:      	str	q6, [sp, #0x1a0]
    1c44:      	add.2d	v6, v6, v4
    1c48:      	tbnz	w9, #0x4, 0x1cb4 <_llm_rows.packet_batch.blocks+0x618>
    1c4c:      	tbnz	w9, #0x5, 0x1cc0 <_llm_rows.packet_batch.blocks+0x624>
    1c50:      	add.2d	v6, v17, v25
    1c54:      	str	q6, [sp, #0x190]
    1c58:      	add.2d	v4, v6, v4
    1c5c:      	tbnz	w9, #0x6, 0x1cd8 <_llm_rows.packet_batch.blocks+0x63c>
    1c60:      	tbz	w9, #0x7, 0x1bc8 <_llm_rows.packet_batch.blocks+0x52c>
    1c64:      	b	0x1ce4 <_llm_rows.packet_batch.blocks+0x648>
    1c68:      	fmov	x10, d6
    1c6c:      	str	b5, [x10]
    1c70:      	and	w9, w9, #0xff
    1c74:      	tbz	w9, #0x1, 0x1c28 <_llm_rows.packet_batch.blocks+0x58c>
    1c78:      	mov.d	x10, v6[1]
    1c7c:      	st1.b	{ v5 }[1], [x10]
    1c80:      	add.2d	v6, v20, v27
    1c84:      	str	q6, [sp, #0x1b0]
    1c88:      	add.2d	v6, v6, v4
    1c8c:      	tbz	w9, #0x2, 0x1c38 <_llm_rows.packet_batch.blocks+0x59c>
    1c90:      	fmov	x10, d6
    1c94:      	st1.b	{ v5 }[2], [x10]
    1c98:      	tbz	w9, #0x3, 0x1c3c <_llm_rows.packet_batch.blocks+0x5a0>
    1c9c:      	mov.d	x10, v6[1]
    1ca0:      	st1.b	{ v5 }[3], [x10]
    1ca4:      	add.2d	v6, v18, v26
    1ca8:      	str	q6, [sp, #0x1a0]
    1cac:      	add.2d	v6, v6, v4
    1cb0:      	tbz	w9, #0x4, 0x1c4c <_llm_rows.packet_batch.blocks+0x5b0>
    1cb4:      	fmov	x10, d6
    1cb8:      	st1.b	{ v5 }[4], [x10]
    1cbc:      	tbz	w9, #0x5, 0x1c50 <_llm_rows.packet_batch.blocks+0x5b4>
    1cc0:      	mov.d	x10, v6[1]
    1cc4:      	st1.b	{ v5 }[5], [x10]
    1cc8:      	add.2d	v6, v17, v25
    1ccc:      	str	q6, [sp, #0x190]
    1cd0:      	add.2d	v4, v6, v4
    1cd4:      	tbz	w9, #0x6, 0x1c60 <_llm_rows.packet_batch.blocks+0x5c4>
    1cd8:      	fmov	x10, d4
    1cdc:      	st1.b	{ v5 }[6], [x10]
    1ce0:      	tbz	w9, #0x7, 0x1bc8 <_llm_rows.packet_batch.blocks+0x52c>
    1ce4:      	mov.d	x9, v4[1]
    1ce8:      	st1.b	{ v5 }[7], [x9]
    1cec:      	b	0x1bc8 <_llm_rows.packet_batch.blocks+0x52c>
    1cf0:      	fmov	w8, s31
    1cf4:      	tbz	w8, #0x0, 0x1d10 <_llm_rows.packet_batch.blocks+0x674>
    1cf8:      	ldr	q2, [sp, #0x1c0]
    1cfc:      	fmov	x9, d2
    1d00:      	ldr	b2, [x9]
    1d04:      	and	w8, w8, #0xff
    1d08:      	tbnz	w8, #0x1, 0x1d1c <_llm_rows.packet_batch.blocks+0x680>
    1d0c:      	b	0x1d28 <_llm_rows.packet_batch.blocks+0x68c>
    1d10:      	movi.2d	v2, #0000000000000000
    1d14:      	and	w8, w8, #0xff
    1d18:      	tbz	w8, #0x1, 0x1d28 <_llm_rows.packet_batch.blocks+0x68c>
    1d1c:      	ldr	q3, [sp, #0x1c0]
    1d20:      	mov.d	x9, v3[1]
    1d24:      	ld1.b	{ v2 }[1], [x9]
    1d28:      	tbnz	w8, #0x2, 0x1db8 <_llm_rows.packet_batch.blocks+0x71c>
    1d2c:      	tbnz	w8, #0x3, 0x1dc8 <_llm_rows.packet_batch.blocks+0x72c>
    1d30:      	tbnz	w8, #0x4, 0x1dd8 <_llm_rows.packet_batch.blocks+0x73c>
    1d34:      	tbnz	w8, #0x5, 0x1de8 <_llm_rows.packet_batch.blocks+0x74c>
    1d38:      	tbnz	w8, #0x6, 0x1df8 <_llm_rows.packet_batch.blocks+0x75c>
    1d3c:      	tbz	w8, #0x7, 0x1d4c <_llm_rows.packet_batch.blocks+0x6b0>
    1d40:      	ldr	q3, [sp, #0x190]
    1d44:      	mov.d	x8, v3[1]
    1d48:      	ld1.b	{ v2 }[7], [x8]
    1d4c:      	fmov	w8, s31
    1d50:      	cmeq.8b	v2, v2, #0
    1d54:      	sshll.8h	v13, v2, #0x0
    1d58:      	sshll2.4s	v5, v13, #0x0
    1d5c:      	sshll.4s	v2, v13, #0x0
    1d60:      	ldr	q3, [x23, #0x3800]
    1d64:      	ldr	q4, [x23, #0x3810]
    1d68:      	and.16b	v4, v0, v4
    1d6c:      	and.16b	v3, v1, v3
    1d70:      	mov	w9, #0xf2ca             ; =62154
    1d74:      	movk	w9, #0xf149, lsl #16
    1d78:      	dup.4s	v22, w9
    1d7c:      	mov.16b	v23, v2
    1d80:      	bsl.16b	v23, v22, v3
    1d84:      	str	q5, [sp, #0x70]
    1d88:      	mov.16b	v24, v5
    1d8c:      	bsl.16b	v24, v22, v4
    1d90:      	str	q24, [x23, #0x1110]
    1d94:      	str	q23, [x23, #0x1100]
    1d98:      	mvn.16b	v2, v21
    1d9c:      	sub.2d	v3, v28, v2
    1da0:      	tbz	w8, #0x0, 0x1e0c <_llm_rows.packet_batch.blocks+0x770>
    1da4:      	fmov	x9, d3
    1da8:      	ldr	b2, [x9]
    1dac:      	and	w8, w8, #0xff
    1db0:      	tbnz	w8, #0x1, 0x1e18 <_llm_rows.packet_batch.blocks+0x77c>
    1db4:      	b	0x1e20 <_llm_rows.packet_batch.blocks+0x784>
    1db8:      	ldr	q3, [sp, #0x1b0]
    1dbc:      	fmov	x9, d3
    1dc0:      	ld1.b	{ v2 }[2], [x9]
    1dc4:      	tbz	w8, #0x3, 0x1d30 <_llm_rows.packet_batch.blocks+0x694>
    1dc8:      	ldr	q3, [sp, #0x1b0]
    1dcc:      	mov.d	x9, v3[1]
    1dd0:      	ld1.b	{ v2 }[3], [x9]
    1dd4:      	tbz	w8, #0x4, 0x1d34 <_llm_rows.packet_batch.blocks+0x698>
    1dd8:      	ldr	q3, [sp, #0x1a0]
    1ddc:      	fmov	x9, d3
    1de0:      	ld1.b	{ v2 }[4], [x9]
    1de4:      	tbz	w8, #0x5, 0x1d38 <_llm_rows.packet_batch.blocks+0x69c>
    1de8:      	ldr	q3, [sp, #0x1a0]
    1dec:      	mov.d	x9, v3[1]
    1df0:      	ld1.b	{ v2 }[5], [x9]
    1df4:      	tbz	w8, #0x6, 0x1d3c <_llm_rows.packet_batch.blocks+0x6a0>
    1df8:      	ldr	q3, [sp, #0x190]
    1dfc:      	fmov	x9, d3
    1e00:      	ld1.b	{ v2 }[6], [x9]
    1e04:      	tbnz	w8, #0x7, 0x1d40 <_llm_rows.packet_batch.blocks+0x6a4>
    1e08:      	b	0x1d4c <_llm_rows.packet_batch.blocks+0x6b0>
    1e0c:      	movi.2d	v2, #0000000000000000
    1e10:      	and	w8, w8, #0xff
    1e14:      	tbz	w8, #0x1, 0x1e20 <_llm_rows.packet_batch.blocks+0x784>
    1e18:      	mov.d	x9, v3[1]
    1e1c:      	ld1.b	{ v2 }[1], [x9]
    1e20:      	mvn.16b	v3, v20
    1e24:      	sub.2d	v3, v27, v3
    1e28:      	tbnz	w8, #0x2, 0x1ebc <_llm_rows.packet_batch.blocks+0x820>
    1e2c:      	tbnz	w8, #0x3, 0x1ec8 <_llm_rows.packet_batch.blocks+0x82c>
    1e30:      	mvn.16b	v3, v18
    1e34:      	sub.2d	v3, v26, v3
    1e38:      	tbnz	w8, #0x4, 0x1edc <_llm_rows.packet_batch.blocks+0x840>
    1e3c:      	tbnz	w8, #0x5, 0x1ee8 <_llm_rows.packet_batch.blocks+0x84c>
    1e40:      	mvn.16b	v3, v17
    1e44:      	sub.2d	v3, v25, v3
    1e48:      	tbnz	w8, #0x6, 0x1efc <_llm_rows.packet_batch.blocks+0x860>
    1e4c:      	tbz	w8, #0x7, 0x1e58 <_llm_rows.packet_batch.blocks+0x7bc>
    1e50:      	mov.d	x8, v3[1]
    1e54:      	ld1.b	{ v2 }[7], [x8]
    1e58:      	fmov	w8, s31
    1e5c:      	cmeq.8b	v2, v2, #0
    1e60:      	sshll.8h	v2, v2, #0x0
    1e64:      	sshll2.4s	v3, v2, #0x0
    1e68:      	sshll.4s	v2, v2, #0x0
    1e6c:      	ldr	q4, [x23, #0x3820]
    1e70:      	ldr	q5, [x23, #0x3830]
    1e74:      	and.16b	v5, v0, v5
    1e78:      	and.16b	v4, v1, v4
    1e7c:      	mov.16b	v27, v2
    1e80:      	bsl.16b	v27, v22, v4
    1e84:      	mov.16b	v28, v3
    1e88:      	bsl.16b	v28, v22, v5
    1e8c:      	str	q28, [x23, #0x1130]
    1e90:      	str	q27, [x23, #0x1120]
    1e94:      	mov	w9, #0x2                ; =2
    1e98:      	dup.2d	v3, x9
    1e9c:      	ldr	q2, [sp, #0x1c0]
    1ea0:      	add.2d	v4, v2, v3
    1ea4:      	tbz	w8, #0x0, 0x1f0c <_llm_rows.packet_batch.blocks+0x870>
    1ea8:      	fmov	x9, d4
    1eac:      	ldr	b2, [x9]
    1eb0:      	and	w8, w8, #0xff
    1eb4:      	tbnz	w8, #0x1, 0x1f18 <_llm_rows.packet_batch.blocks+0x87c>
    1eb8:      	b	0x1f20 <_llm_rows.packet_batch.blocks+0x884>
    1ebc:      	fmov	x9, d3
    1ec0:      	ld1.b	{ v2 }[2], [x9]
    1ec4:      	tbz	w8, #0x3, 0x1e30 <_llm_rows.packet_batch.blocks+0x794>
    1ec8:      	mov.d	x9, v3[1]
    1ecc:      	ld1.b	{ v2 }[3], [x9]
    1ed0:      	mvn.16b	v3, v18
    1ed4:      	sub.2d	v3, v26, v3
    1ed8:      	tbz	w8, #0x4, 0x1e3c <_llm_rows.packet_batch.blocks+0x7a0>
    1edc:      	fmov	x9, d3
    1ee0:      	ld1.b	{ v2 }[4], [x9]
    1ee4:      	tbz	w8, #0x5, 0x1e40 <_llm_rows.packet_batch.blocks+0x7a4>
    1ee8:      	mov.d	x9, v3[1]
    1eec:      	ld1.b	{ v2 }[5], [x9]
    1ef0:      	mvn.16b	v3, v17
    1ef4:      	sub.2d	v3, v25, v3
    1ef8:      	tbz	w8, #0x6, 0x1e4c <_llm_rows.packet_batch.blocks+0x7b0>
    1efc:      	fmov	x9, d3
    1f00:      	ld1.b	{ v2 }[6], [x9]
    1f04:      	tbnz	w8, #0x7, 0x1e50 <_llm_rows.packet_batch.blocks+0x7b4>
    1f08:      	b	0x1e58 <_llm_rows.packet_batch.blocks+0x7bc>
    1f0c:      	movi.2d	v2, #0000000000000000
    1f10:      	and	w8, w8, #0xff
    1f14:      	tbz	w8, #0x1, 0x1f20 <_llm_rows.packet_batch.blocks+0x884>
    1f18:      	mov.d	x9, v4[1]
    1f1c:      	ld1.b	{ v2 }[1], [x9]
    1f20:      	ldr	q4, [sp, #0x1b0]
    1f24:      	add.2d	v4, v4, v3
    1f28:      	tbnz	w8, #0x2, 0x1fb4 <_llm_rows.packet_batch.blocks+0x918>
    1f2c:      	tbnz	w8, #0x3, 0x1fc0 <_llm_rows.packet_batch.blocks+0x924>
    1f30:      	ldr	q4, [sp, #0x1a0]
    1f34:      	add.2d	v4, v4, v3
    1f38:      	tbnz	w8, #0x4, 0x1fd4 <_llm_rows.packet_batch.blocks+0x938>
    1f3c:      	tbnz	w8, #0x5, 0x1fe0 <_llm_rows.packet_batch.blocks+0x944>
    1f40:      	ldr	q4, [sp, #0x190]
    1f44:      	add.2d	v3, v4, v3
    1f48:      	tbnz	w8, #0x6, 0x1ff4 <_llm_rows.packet_batch.blocks+0x958>
    1f4c:      	tbz	w8, #0x7, 0x1f58 <_llm_rows.packet_batch.blocks+0x8bc>
    1f50:      	mov.d	x8, v3[1]
    1f54:      	ld1.b	{ v2 }[7], [x8]
    1f58:      	fmov	w8, s31
    1f5c:      	cmeq.8b	v2, v2, #0
    1f60:      	sshll.8h	v2, v2, #0x0
    1f64:      	sshll2.4s	v3, v2, #0x0
    1f68:      	sshll.4s	v2, v2, #0x0
    1f6c:      	ldr	q4, [x23, #0x3840]
    1f70:      	ldr	q5, [x23, #0x3850]
    1f74:      	and.16b	v5, v0, v5
    1f78:      	and.16b	v4, v1, v4
    1f7c:      	bsl.16b	v2, v22, v4
    1f80:      	bsl.16b	v3, v22, v5
    1f84:      	str	q3, [x23, #0x1150]
    1f88:      	str	q2, [x23, #0x1140]
    1f8c:      	mov	w9, #0x3                ; =3
    1f90:      	dup.2d	v5, x9
    1f94:      	ldr	q4, [sp, #0x1c0]
    1f98:      	add.2d	v25, v4, v5
    1f9c:      	tbz	w8, #0x0, 0x2004 <_llm_rows.packet_batch.blocks+0x968>
    1fa0:      	fmov	x9, d25
    1fa4:      	ldr	b4, [x9]
    1fa8:      	and	w8, w8, #0xff
    1fac:      	tbnz	w8, #0x1, 0x2010 <_llm_rows.packet_batch.blocks+0x974>
    1fb0:      	b	0x2018 <_llm_rows.packet_batch.blocks+0x97c>
    1fb4:      	fmov	x9, d4
    1fb8:      	ld1.b	{ v2 }[2], [x9]
    1fbc:      	tbz	w8, #0x3, 0x1f30 <_llm_rows.packet_batch.blocks+0x894>
    1fc0:      	mov.d	x9, v4[1]
    1fc4:      	ld1.b	{ v2 }[3], [x9]
    1fc8:      	ldr	q4, [sp, #0x1a0]
    1fcc:      	add.2d	v4, v4, v3
    1fd0:      	tbz	w8, #0x4, 0x1f3c <_llm_rows.packet_batch.blocks+0x8a0>
    1fd4:      	fmov	x9, d4
    1fd8:      	ld1.b	{ v2 }[4], [x9]
    1fdc:      	tbz	w8, #0x5, 0x1f40 <_llm_rows.packet_batch.blocks+0x8a4>
    1fe0:      	mov.d	x9, v4[1]
    1fe4:      	ld1.b	{ v2 }[5], [x9]
    1fe8:      	ldr	q4, [sp, #0x190]
    1fec:      	add.2d	v3, v4, v3
    1ff0:      	tbz	w8, #0x6, 0x1f4c <_llm_rows.packet_batch.blocks+0x8b0>
    1ff4:      	fmov	x9, d3
    1ff8:      	ld1.b	{ v2 }[6], [x9]
    1ffc:      	tbnz	w8, #0x7, 0x1f50 <_llm_rows.packet_batch.blocks+0x8b4>
    2000:      	b	0x1f58 <_llm_rows.packet_batch.blocks+0x8bc>
    2004:      	movi.2d	v4, #0000000000000000
    2008:      	and	w8, w8, #0xff
    200c:      	tbz	w8, #0x1, 0x2018 <_llm_rows.packet_batch.blocks+0x97c>
    2010:      	mov.d	x9, v25[1]
    2014:      	ld1.b	{ v4 }[1], [x9]
    2018:      	ldr	q6, [sp, #0x1b0]
    201c:      	add.2d	v25, v6, v5
    2020:      	tbnz	w8, #0x2, 0x2bec <_llm_rows.packet_batch.blocks+0x1550>
    2024:      	tbnz	w8, #0x3, 0x2bf8 <_llm_rows.packet_batch.blocks+0x155c>
    2028:      	ldr	q6, [sp, #0x1a0]
    202c:      	add.2d	v25, v6, v5
    2030:      	tbnz	w8, #0x4, 0x2c0c <_llm_rows.packet_batch.blocks+0x1570>
    2034:      	tbnz	w8, #0x5, 0x2c18 <_llm_rows.packet_batch.blocks+0x157c>
    2038:      	ldr	q6, [sp, #0x190]
    203c:      	add.2d	v5, v6, v5
    2040:      	tbnz	w8, #0x6, 0x2c2c <_llm_rows.packet_batch.blocks+0x1590>
    2044:      	tbz	w8, #0x7, 0x2050 <_llm_rows.packet_batch.blocks+0x9b4>
    2048:      	mov.d	x8, v5[1]
    204c:      	ld1.b	{ v4 }[7], [x8]
    2050:      	str	q31, [sp, #0x180]
    2054:      	cmeq.8b	v4, v4, #0
    2058:      	sshll.8h	v4, v4, #0x0
    205c:      	sshll2.4s	v5, v4, #0x0
    2060:      	sshll.4s	v4, v4, #0x0
    2064:      	ldr	q25, [x23, #0x3860]
    2068:      	ldr	q26, [x23, #0x3870]
    206c:      	and.16b	v26, v0, v26
    2070:      	and.16b	v25, v1, v25
    2074:      	bsl.16b	v4, v22, v25
    2078:      	bsl.16b	v5, v22, v26
    207c:      	str	q5, [x23, #0x1170]
    2080:      	str	q4, [x23, #0x1160]
    2084:      	and.16b	v26, v0, v24
    2088:      	and.16b	v25, v1, v23
    208c:      	and.16b	v31, v0, v28
    2090:      	and.16b	v30, v1, v27
    2094:      	and.16b	v27, v0, v3
    2098:      	and.16b	v10, v1, v2
    209c:      	and.16b	v29, v0, v5
    20a0:      	and.16b	v28, v1, v4
    20a4:      	ldr	x8, [sp, #0xb0]
    20a8:      	ldr	x9, [sp, #0x48]
    20ac:      	mov	w10, #0x4               ; =4
    20b0:      	b	0x2138 <_llm_rows.packet_batch.blocks+0xa9c>
    20b4:      	fmaxnm.4s	v5, v26, v8
    20b8:      	fmaxnm.4s	v8, v25, v11
    20bc:      	fmaxnm.4s	v9, v31, v14
    20c0:      	fmaxnm.4s	v11, v30, v15
    20c4:      	fmaxnm.4s	v2, v27, v2
    20c8:      	fmaxnm.4s	v3, v10, v3
    20cc:      	cmeq.8b	v4, v4, #0
    20d0:      	sshll.8h	v4, v4, #0x0
    20d4:      	sshll.4s	v14, v4, #0x0
    20d8:      	sshll2.4s	v4, v4, #0x0
    20dc:      	ldp	q12, q15, [x9], #0x80
    20e0:      	and.16b	v12, v1, v12
    20e4:      	and.16b	v15, v0, v15
    20e8:      	bsl.16b	v4, v22, v15
    20ec:      	bit.16b	v12, v22, v14
    20f0:      	ldp	q15, q14, [x8]
    20f4:      	bit.16b	v15, v12, v1
    20f8:      	bit.16b	v14, v4, v0
    20fc:      	stp	q15, q14, [x8], #0x80
    2100:      	fmaxnm.4s	v12, v28, v12
    2104:      	fmaxnm.4s	v4, v29, v4
    2108:      	bit.16b	v26, v5, v0
    210c:      	bit.16b	v25, v8, v1
    2110:      	bit.16b	v31, v9, v0
    2114:      	bit.16b	v30, v11, v1
    2118:      	bit.16b	v27, v2, v0
    211c:      	bit.16b	v10, v3, v1
    2120:      	bit.16b	v29, v4, v0
    2124:      	bit.16b	v28, v12, v1
    2128:      	sub	x11, x10, #0x3
    212c:      	add	x10, x10, #0x1
    2130:      	cmp	x11, #0x5c
    2134:      	b.hs	0x2508 <_llm_rows.packet_batch.blocks+0xe6c>
    2138:      	ldr	q6, [sp, #0x180]
    213c:      	fmov	w11, s6
    2140:      	dup.2d	v3, x10
    2144:      	ldr	q2, [sp, #0x1c0]
    2148:      	add.2d	v4, v2, v3
    214c:      	tbz	w11, #0x0, 0x2164 <_llm_rows.packet_batch.blocks+0xac8>
    2150:      	fmov	x12, d4
    2154:      	ldr	b2, [x12]
    2158:      	and	w11, w11, #0xff
    215c:      	tbnz	w11, #0x1, 0x2170 <_llm_rows.packet_batch.blocks+0xad4>
    2160:      	b	0x2178 <_llm_rows.packet_batch.blocks+0xadc>
    2164:      	movi.2d	v2, #0000000000000000
    2168:      	and	w11, w11, #0xff
    216c:      	tbz	w11, #0x1, 0x2178 <_llm_rows.packet_batch.blocks+0xadc>
    2170:      	mov.d	x12, v4[1]
    2174:      	ld1.b	{ v2 }[1], [x12]
    2178:      	ldr	q4, [sp, #0x1b0]
    217c:      	add.2d	v4, v4, v3
    2180:      	tbnz	w11, #0x2, 0x2218 <_llm_rows.packet_batch.blocks+0xb7c>
    2184:      	tbnz	w11, #0x3, 0x2224 <_llm_rows.packet_batch.blocks+0xb88>
    2188:      	ldr	q4, [sp, #0x1a0]
    218c:      	add.2d	v4, v4, v3
    2190:      	tbnz	w11, #0x4, 0x2238 <_llm_rows.packet_batch.blocks+0xb9c>
    2194:      	tbnz	w11, #0x5, 0x2244 <_llm_rows.packet_batch.blocks+0xba8>
    2198:      	ldr	q4, [sp, #0x190]
    219c:      	add.2d	v3, v4, v3
    21a0:      	tbnz	w11, #0x6, 0x2258 <_llm_rows.packet_batch.blocks+0xbbc>
    21a4:      	tbz	w11, #0x7, 0x21b0 <_llm_rows.packet_batch.blocks+0xb14>
    21a8:      	mov.d	x11, v3[1]
    21ac:      	ld1.b	{ v2 }[7], [x11]
    21b0:      	fmov	w11, s6
    21b4:      	cmeq.8b	v2, v2, #0
    21b8:      	sshll.8h	v2, v2, #0x0
    21bc:      	sshll.4s	v3, v2, #0x0
    21c0:      	sshll2.4s	v2, v2, #0x0
    21c4:      	ldp	q5, q4, [x9, #-0x60]
    21c8:      	and.16b	v5, v1, v5
    21cc:      	and.16b	v4, v0, v4
    21d0:      	mov.16b	v8, v2
    21d4:      	bsl.16b	v8, v22, v4
    21d8:      	mov.16b	v11, v3
    21dc:      	bsl.16b	v11, v22, v5
    21e0:      	ldp	q3, q2, [x8, #-0x60]
    21e4:      	bit.16b	v3, v11, v1
    21e8:      	bit.16b	v2, v8, v0
    21ec:      	stp	q3, q2, [x8, #-0x60]
    21f0:      	add	x10, x10, #0x1
    21f4:      	dup.2d	v3, x10
    21f8:      	ldr	q2, [sp, #0x1c0]
    21fc:      	add.2d	v4, v2, v3
    2200:      	tbz	w11, #0x0, 0x2268 <_llm_rows.packet_batch.blocks+0xbcc>
    2204:      	fmov	x12, d4
    2208:      	ldr	b2, [x12]
    220c:      	and	w11, w11, #0xff
    2210:      	tbnz	w11, #0x1, 0x2274 <_llm_rows.packet_batch.blocks+0xbd8>
    2214:      	b	0x227c <_llm_rows.packet_batch.blocks+0xbe0>
    2218:      	fmov	x12, d4
    221c:      	ld1.b	{ v2 }[2], [x12]
    2220:      	tbz	w11, #0x3, 0x2188 <_llm_rows.packet_batch.blocks+0xaec>
    2224:      	mov.d	x12, v4[1]
    2228:      	ld1.b	{ v2 }[3], [x12]
    222c:      	ldr	q4, [sp, #0x1a0]
    2230:      	add.2d	v4, v4, v3
    2234:      	tbz	w11, #0x4, 0x2194 <_llm_rows.packet_batch.blocks+0xaf8>
    2238:      	fmov	x12, d4
    223c:      	ld1.b	{ v2 }[4], [x12]
    2240:      	tbz	w11, #0x5, 0x2198 <_llm_rows.packet_batch.blocks+0xafc>
    2244:      	mov.d	x12, v4[1]
    2248:      	ld1.b	{ v2 }[5], [x12]
    224c:      	ldr	q4, [sp, #0x190]
    2250:      	add.2d	v3, v4, v3
    2254:      	tbz	w11, #0x6, 0x21a4 <_llm_rows.packet_batch.blocks+0xb08>
    2258:      	fmov	x12, d3
    225c:      	ld1.b	{ v2 }[6], [x12]
    2260:      	tbnz	w11, #0x7, 0x21a8 <_llm_rows.packet_batch.blocks+0xb0c>
    2264:      	b	0x21b0 <_llm_rows.packet_batch.blocks+0xb14>
    2268:      	movi.2d	v2, #0000000000000000
    226c:      	and	w11, w11, #0xff
    2270:      	tbz	w11, #0x1, 0x227c <_llm_rows.packet_batch.blocks+0xbe0>
    2274:      	mov.d	x12, v4[1]
    2278:      	ld1.b	{ v2 }[1], [x12]
    227c:      	ldr	q4, [sp, #0x1b0]
    2280:      	add.2d	v4, v4, v3
    2284:      	tbnz	w11, #0x2, 0x231c <_llm_rows.packet_batch.blocks+0xc80>
    2288:      	tbnz	w11, #0x3, 0x2328 <_llm_rows.packet_batch.blocks+0xc8c>
    228c:      	ldr	q4, [sp, #0x1a0]
    2290:      	add.2d	v4, v4, v3
    2294:      	tbnz	w11, #0x4, 0x233c <_llm_rows.packet_batch.blocks+0xca0>
    2298:      	tbnz	w11, #0x5, 0x2348 <_llm_rows.packet_batch.blocks+0xcac>
    229c:      	ldr	q4, [sp, #0x190]
    22a0:      	add.2d	v3, v4, v3
    22a4:      	tbnz	w11, #0x6, 0x235c <_llm_rows.packet_batch.blocks+0xcc0>
    22a8:      	tbz	w11, #0x7, 0x22b4 <_llm_rows.packet_batch.blocks+0xc18>
    22ac:      	mov.d	x11, v3[1]
    22b0:      	ld1.b	{ v2 }[7], [x11]
    22b4:      	fmov	w11, s6
    22b8:      	cmeq.8b	v2, v2, #0
    22bc:      	sshll.8h	v2, v2, #0x0
    22c0:      	sshll.4s	v3, v2, #0x0
    22c4:      	sshll2.4s	v2, v2, #0x0
    22c8:      	ldp	q5, q4, [x9, #-0x40]
    22cc:      	and.16b	v5, v1, v5
    22d0:      	and.16b	v4, v0, v4
    22d4:      	mov.16b	v14, v2
    22d8:      	bsl.16b	v14, v22, v4
    22dc:      	mov.16b	v15, v3
    22e0:      	bsl.16b	v15, v22, v5
    22e4:      	ldp	q3, q2, [x8, #-0x40]
    22e8:      	bit.16b	v3, v15, v1
    22ec:      	bit.16b	v2, v14, v0
    22f0:      	stp	q3, q2, [x8, #-0x40]
    22f4:      	add	x10, x10, #0x1
    22f8:      	dup.2d	v3, x10
    22fc:      	ldr	q2, [sp, #0x1c0]
    2300:      	add.2d	v4, v2, v3
    2304:      	tbz	w11, #0x0, 0x236c <_llm_rows.packet_batch.blocks+0xcd0>
    2308:      	fmov	x12, d4
    230c:      	ldr	b2, [x12]
    2310:      	and	w11, w11, #0xff
    2314:      	tbnz	w11, #0x1, 0x2378 <_llm_rows.packet_batch.blocks+0xcdc>
    2318:      	b	0x2380 <_llm_rows.packet_batch.blocks+0xce4>
    231c:      	fmov	x12, d4
    2320:      	ld1.b	{ v2 }[2], [x12]
    2324:      	tbz	w11, #0x3, 0x228c <_llm_rows.packet_batch.blocks+0xbf0>
    2328:      	mov.d	x12, v4[1]
    232c:      	ld1.b	{ v2 }[3], [x12]
    2330:      	ldr	q4, [sp, #0x1a0]
    2334:      	add.2d	v4, v4, v3
    2338:      	tbz	w11, #0x4, 0x2298 <_llm_rows.packet_batch.blocks+0xbfc>
    233c:      	fmov	x12, d4
    2340:      	ld1.b	{ v2 }[4], [x12]
    2344:      	tbz	w11, #0x5, 0x229c <_llm_rows.packet_batch.blocks+0xc00>
    2348:      	mov.d	x12, v4[1]
    234c:      	ld1.b	{ v2 }[5], [x12]
    2350:      	ldr	q4, [sp, #0x190]
    2354:      	add.2d	v3, v4, v3
    2358:      	tbz	w11, #0x6, 0x22a8 <_llm_rows.packet_batch.blocks+0xc0c>
    235c:      	fmov	x12, d3
    2360:      	ld1.b	{ v2 }[6], [x12]
    2364:      	tbnz	w11, #0x7, 0x22ac <_llm_rows.packet_batch.blocks+0xc10>
    2368:      	b	0x22b4 <_llm_rows.packet_batch.blocks+0xc18>
    236c:      	movi.2d	v2, #0000000000000000
    2370:      	and	w11, w11, #0xff
    2374:      	tbz	w11, #0x1, 0x2380 <_llm_rows.packet_batch.blocks+0xce4>
    2378:      	mov.d	x12, v4[1]
    237c:      	ld1.b	{ v2 }[1], [x12]
    2380:      	ldr	q4, [sp, #0x1b0]
    2384:      	add.2d	v4, v4, v3
    2388:      	tbnz	w11, #0x2, 0x2418 <_llm_rows.packet_batch.blocks+0xd7c>
    238c:      	tbnz	w11, #0x3, 0x2424 <_llm_rows.packet_batch.blocks+0xd88>
    2390:      	ldr	q4, [sp, #0x1a0]
    2394:      	add.2d	v4, v4, v3
    2398:      	tbnz	w11, #0x4, 0x2438 <_llm_rows.packet_batch.blocks+0xd9c>
    239c:      	tbnz	w11, #0x5, 0x2444 <_llm_rows.packet_batch.blocks+0xda8>
    23a0:      	ldr	q4, [sp, #0x190]
    23a4:      	add.2d	v3, v4, v3
    23a8:      	tbnz	w11, #0x6, 0x2458 <_llm_rows.packet_batch.blocks+0xdbc>
    23ac:      	tbz	w11, #0x7, 0x23b8 <_llm_rows.packet_batch.blocks+0xd1c>
    23b0:      	mov.d	x11, v3[1]
    23b4:      	ld1.b	{ v2 }[7], [x11]
    23b8:      	fmov	w11, s6
    23bc:      	cmeq.8b	v2, v2, #0
    23c0:      	sshll.8h	v2, v2, #0x0
    23c4:      	sshll.4s	v3, v2, #0x0
    23c8:      	sshll2.4s	v2, v2, #0x0
    23cc:      	ldp	q5, q4, [x9, #-0x20]
    23d0:      	and.16b	v5, v1, v5
    23d4:      	and.16b	v4, v0, v4
    23d8:      	bsl.16b	v2, v22, v4
    23dc:      	bsl.16b	v3, v22, v5
    23e0:      	ldp	q5, q4, [x8, #-0x20]
    23e4:      	bit.16b	v5, v3, v1
    23e8:      	bit.16b	v4, v2, v0
    23ec:      	stp	q5, q4, [x8, #-0x20]
    23f0:      	add	x10, x10, #0x1
    23f4:      	dup.2d	v5, x10
    23f8:      	ldr	q4, [sp, #0x1c0]
    23fc:      	add.2d	v9, v4, v5
    2400:      	tbz	w11, #0x0, 0x2468 <_llm_rows.packet_batch.blocks+0xdcc>
    2404:      	fmov	x12, d9
    2408:      	ldr	b4, [x12]
    240c:      	and	w11, w11, #0xff
    2410:      	tbnz	w11, #0x1, 0x2474 <_llm_rows.packet_batch.blocks+0xdd8>
    2414:      	b	0x247c <_llm_rows.packet_batch.blocks+0xde0>
    2418:      	fmov	x12, d4
    241c:      	ld1.b	{ v2 }[2], [x12]
    2420:      	tbz	w11, #0x3, 0x2390 <_llm_rows.packet_batch.blocks+0xcf4>
    2424:      	mov.d	x12, v4[1]
    2428:      	ld1.b	{ v2 }[3], [x12]
    242c:      	ldr	q4, [sp, #0x1a0]
    2430:      	add.2d	v4, v4, v3
    2434:      	tbz	w11, #0x4, 0x239c <_llm_rows.packet_batch.blocks+0xd00>
    2438:      	fmov	x12, d4
    243c:      	ld1.b	{ v2 }[4], [x12]
    2440:      	tbz	w11, #0x5, 0x23a0 <_llm_rows.packet_batch.blocks+0xd04>
    2444:      	mov.d	x12, v4[1]
    2448:      	ld1.b	{ v2 }[5], [x12]
    244c:      	ldr	q4, [sp, #0x190]
    2450:      	add.2d	v3, v4, v3
    2454:      	tbz	w11, #0x6, 0x23ac <_llm_rows.packet_batch.blocks+0xd10>
    2458:      	fmov	x12, d3
    245c:      	ld1.b	{ v2 }[6], [x12]
    2460:      	tbnz	w11, #0x7, 0x23b0 <_llm_rows.packet_batch.blocks+0xd14>
    2464:      	b	0x23b8 <_llm_rows.packet_batch.blocks+0xd1c>
    2468:      	movi.2d	v4, #0000000000000000
    246c:      	and	w11, w11, #0xff
    2470:      	tbz	w11, #0x1, 0x247c <_llm_rows.packet_batch.blocks+0xde0>
    2474:      	mov.d	x12, v9[1]
    2478:      	ld1.b	{ v4 }[1], [x12]
    247c:      	ldr	q6, [sp, #0x1b0]
    2480:      	add.2d	v9, v6, v5
    2484:      	tbnz	w11, #0x2, 0x24b0 <_llm_rows.packet_batch.blocks+0xe14>
    2488:      	tbnz	w11, #0x3, 0x24bc <_llm_rows.packet_batch.blocks+0xe20>
    248c:      	ldr	q6, [sp, #0x1a0]
    2490:      	add.2d	v9, v6, v5
    2494:      	tbnz	w11, #0x4, 0x24d0 <_llm_rows.packet_batch.blocks+0xe34>
    2498:      	tbnz	w11, #0x5, 0x24dc <_llm_rows.packet_batch.blocks+0xe40>
    249c:      	ldr	q6, [sp, #0x190]
    24a0:      	add.2d	v5, v6, v5
    24a4:      	tbnz	w11, #0x6, 0x24f0 <_llm_rows.packet_batch.blocks+0xe54>
    24a8:      	tbz	w11, #0x7, 0x20b4 <_llm_rows.packet_batch.blocks+0xa18>
    24ac:      	b	0x24fc <_llm_rows.packet_batch.blocks+0xe60>
    24b0:      	fmov	x12, d9
    24b4:      	ld1.b	{ v4 }[2], [x12]
    24b8:      	tbz	w11, #0x3, 0x248c <_llm_rows.packet_batch.blocks+0xdf0>
    24bc:      	mov.d	x12, v9[1]
    24c0:      	ld1.b	{ v4 }[3], [x12]
    24c4:      	ldr	q6, [sp, #0x1a0]
    24c8:      	add.2d	v9, v6, v5
    24cc:      	tbz	w11, #0x4, 0x2498 <_llm_rows.packet_batch.blocks+0xdfc>
    24d0:      	fmov	x12, d9
    24d4:      	ld1.b	{ v4 }[4], [x12]
    24d8:      	tbz	w11, #0x5, 0x249c <_llm_rows.packet_batch.blocks+0xe00>
    24dc:      	mov.d	x12, v9[1]
    24e0:      	ld1.b	{ v4 }[5], [x12]
    24e4:      	ldr	q6, [sp, #0x190]
    24e8:      	add.2d	v5, v6, v5
    24ec:      	tbz	w11, #0x6, 0x24a8 <_llm_rows.packet_batch.blocks+0xe0c>
    24f0:      	fmov	x12, d5
    24f4:      	ld1.b	{ v4 }[6], [x12]
    24f8:      	tbz	w11, #0x7, 0x20b4 <_llm_rows.packet_batch.blocks+0xa18>
    24fc:      	mov.d	x11, v5[1]
    2500:      	ld1.b	{ v4 }[7], [x11]
    2504:      	b	0x20b4 <_llm_rows.packet_batch.blocks+0xa18>
    2508:      	xtn.8b	v8, v19
    250c:      	fmaxnm.4s	v2, v26, v31
    2510:      	fmaxnm.4s	v3, v25, v30
    2514:      	fmaxnm.4s	v3, v3, v10
    2518:      	fmaxnm.4s	v2, v2, v27
    251c:      	fmaxnm.4s	v2, v2, v29
    2520:      	fmaxnm.4s	v3, v3, v28
    2524:      	ldp	q4, q5, [sp, #0xc0]
    2528:      	and.16b	v19, v1, v5
    252c:      	and.16b	v22, v0, v4
    2530:      	movi.4s	v4, #0x1
    2534:      	eor.16b	v5, v22, v4
    2538:      	eor.16b	v27, v19, v4
    253c:      	umov.b	w10, v8[0]
    2540:      	str	q3, [x23, #0x4d0]
    2544:      	ldr	s4, [x23, #0x4d4]
    2548:      	umov.b	w11, v8[1]
    254c:      	ands	w8, w10, #0x1
    2550:      	tst	w8, w11
    2554:      	movi	d6, #0000000000000000
    2558:      	fcsel	s4, s4, s6, ne
    255c:      	mov.s	w9, v27[1]
    2560:      	add	x12, sp, #0x710
    2564:      	orr	x12, x12, x9, lsl #2
    2568:      	add	x13, sp, #0x428
    256c:      	bfxil	x13, x9, #0, #3
    2570:      	str	d8, [x23, #0x1c8]
    2574:      	ldrb	w9, [x13]
    2578:      	and	w9, w11, w9
    257c:      	str	q3, [x23, #0x4b0]
    2580:      	str	q2, [x23, #0x4c0]
    2584:      	ldr	s25, [x12]
    2588:      	tst	w9, #0x1
    258c:      	fcsel	s25, s25, s6, ne
    2590:      	mov.s	w9, v27[2]
    2594:      	add	x12, sp, #0x6f0
    2598:      	orr	x13, x12, x9, lsl #2
    259c:      	add	x12, sp, #0x428
    25a0:      	bfxil	x12, x9, #0, #3
    25a4:      	ldrb	w9, [x12]
    25a8:      	umov.b	w12, v8[2]
    25ac:      	and	w9, w12, w9
    25b0:      	str	q3, [x23, #0x490]
    25b4:      	str	q2, [x23, #0x4a0]
    25b8:      	ldr	s26, [x13]
    25bc:      	tst	w9, #0x1
    25c0:      	fcsel	s26, s26, s6, ne
    25c4:      	mov.s	w9, v27[3]
    25c8:      	add	x13, sp, #0x6d0
    25cc:      	orr	x14, x13, x9, lsl #2
    25d0:      	add	x13, sp, #0x428
    25d4:      	bfxil	x13, x9, #0, #3
    25d8:      	ldrb	w9, [x13]
    25dc:      	umov.b	w13, v8[3]
    25e0:      	and	w9, w13, w9
    25e4:      	str	q3, [x23, #0x470]
    25e8:      	str	q2, [x23, #0x480]
    25ec:      	ldr	s27, [x14]
    25f0:      	tst	w9, #0x1
    25f4:      	fcsel	s27, s27, s6, ne
    25f8:      	fmov	w9, s5
    25fc:      	add	x14, sp, #0x428
    2600:      	bfxil	x14, x9, #0, #3
    2604:      	ldrb	w15, [x14]
    2608:      	umov.b	w14, v8[4]
    260c:      	and	w15, w14, w15
    2610:      	str	q3, [x23, #0x450]
    2614:      	str	q2, [x23, #0x460]
    2618:      	add	x16, sp, #0x6b0
    261c:      	ldr	s28, [x16, w9, uxtw #2]
    2620:      	tst	w15, #0x1
    2624:      	fcsel	s28, s28, s6, ne
    2628:      	mov.s	w9, v5[1]
    262c:      	add	x16, sp, #0x428
    2630:      	bfxil	x16, x9, #0, #3
    2634:      	umov.b	w15, v8[5]
    2638:      	ldrb	w16, [x16]
    263c:      	and	w16, w15, w16
    2640:      	str	q3, [x23, #0x430]
    2644:      	str	q2, [x23, #0x440]
    2648:      	add	x17, sp, #0x690
    264c:      	ldr	s29, [x17, w9, uxtw #2]
    2650:      	tst	w16, #0x1
    2654:      	fcsel	s29, s29, s6, ne
    2658:      	mov.s	w9, v5[2]
    265c:      	add	x16, sp, #0x428
    2660:      	bfxil	x16, x9, #0, #3
    2664:      	ldrb	w17, [x16]
    2668:      	umov.b	w16, v8[6]
    266c:      	and	w17, w16, w17
    2670:      	str	q3, [x23, #0x410]
    2674:      	str	q2, [x23, #0x420]
    2678:      	add	x0, sp, #0x670
    267c:      	ldr	s30, [x0, w9, uxtw #2]
    2680:      	tst	w17, #0x1
    2684:      	fcsel	s30, s30, s6, ne
    2688:      	mov.s	w9, v5[3]
    268c:      	add	x17, sp, #0x428
    2690:      	bfxil	x17, x9, #0, #3
    2694:      	ldrb	w0, [x17]
    2698:      	str	q8, [sp, #0x90]
    269c:      	umov.b	w17, v8[7]
    26a0:      	and	w0, w17, w0
    26a4:      	stp	q3, q2, [x23, #0x3f0]
    26a8:      	add	x1, sp, #0x650
    26ac:      	ldr	s5, [x1, w9, uxtw #2]
    26b0:      	tst	w0, #0x1
    26b4:      	fcsel	s5, s5, s6, ne
    26b8:      	mov.s	v4[1], v25[0]
    26bc:      	mov.s	v4[2], v26[0]
    26c0:      	mov.s	v4[3], v27[0]
    26c4:      	mov.s	v28[1], v29[0]
    26c8:      	mov.s	v28[2], v30[0]
    26cc:      	mov.s	v28[3], v5[0]
    26d0:      	fmaxnm.4s	v2, v2, v28
    26d4:      	fmaxnm.4s	v3, v3, v4
    26d8:      	movi.4s	v4, #0x2
    26dc:      	eor.16b	v22, v22, v4
    26e0:      	eor.16b	v26, v19, v4
    26e4:      	str	q3, [x23, #0x3d0]
    26e8:      	ldr	s4, [x23, #0x3d8]
    26ec:      	tst	w8, w12
    26f0:      	fcsel	s4, s4, s6, ne
    26f4:      	mov.s	w9, v26[1]
    26f8:      	add	x0, sp, #0x610
    26fc:      	orr	x0, x0, x9, lsl #2
    2700:      	add	x1, sp, #0x428
    2704:      	bfxil	x1, x9, #0, #3
    2708:      	ldrb	w9, [x1]
    270c:      	and	w9, w11, w9
    2710:      	stp	q3, q2, [x23, #0x3b0]
    2714:      	ldr	s5, [x0]
    2718:      	tst	w9, #0x1
    271c:      	fcsel	s5, s5, s6, ne
    2720:      	mov.s	w9, v26[2]
    2724:      	add	x0, sp, #0x5f0
    2728:      	orr	x0, x0, x9, lsl #2
    272c:      	add	x1, sp, #0x428
    2730:      	bfxil	x1, x9, #0, #3
    2734:      	ldrb	w9, [x1]
    2738:      	and	w9, w12, w9
    273c:      	stp	q3, q2, [x23, #0x390]
    2740:      	ldr	s25, [x0]
    2744:      	tst	w9, #0x1
    2748:      	fcsel	s25, s25, s6, ne
    274c:      	mov.s	w9, v26[3]
    2750:      	add	x0, sp, #0x5d0
    2754:      	orr	x0, x0, x9, lsl #2
    2758:      	add	x1, sp, #0x428
    275c:      	bfxil	x1, x9, #0, #3
    2760:      	ldrb	w9, [x1]
    2764:      	and	w9, w13, w9
    2768:      	stp	q3, q2, [x23, #0x370]
    276c:      	ldr	s26, [x0]
    2770:      	tst	w9, #0x1
    2774:      	fcsel	s26, s26, s6, ne
    2778:      	fmov	w9, s22
    277c:      	add	x0, sp, #0x428
    2780:      	bfxil	x0, x9, #0, #3
    2784:      	ldrb	w0, [x0]
    2788:      	and	w0, w14, w0
    278c:      	stp	q3, q2, [x23, #0x350]
    2790:      	add	x1, sp, #0x5b0
    2794:      	ldr	s27, [x1, w9, uxtw #2]
    2798:      	tst	w0, #0x1
    279c:      	fcsel	s27, s27, s6, ne
    27a0:      	mov.s	w9, v22[1]
    27a4:      	add	x0, sp, #0x428
    27a8:      	bfxil	x0, x9, #0, #3
    27ac:      	ldrb	w0, [x0]
    27b0:      	and	w0, w15, w0
    27b4:      	stp	q3, q2, [x23, #0x330]
    27b8:      	add	x1, sp, #0x590
    27bc:      	ldr	s28, [x1, w9, uxtw #2]
    27c0:      	tst	w0, #0x1
    27c4:      	fcsel	s28, s28, s6, ne
    27c8:      	mov.s	w9, v22[2]
    27cc:      	add	x0, sp, #0x428
    27d0:      	bfxil	x0, x9, #0, #3
    27d4:      	ldrb	w0, [x0]
    27d8:      	and	w0, w16, w0
    27dc:      	stp	q3, q2, [x23, #0x310]
    27e0:      	add	x1, sp, #0x570
    27e4:      	ldr	s29, [x1, w9, uxtw #2]
    27e8:      	tst	w0, #0x1
    27ec:      	fcsel	s29, s29, s6, ne
    27f0:      	mov.s	w9, v22[3]
    27f4:      	add	x0, sp, #0x428
    27f8:      	bfxil	x0, x9, #0, #3
    27fc:      	ldrb	w0, [x0]
    2800:      	and	w0, w17, w0
    2804:      	stp	q3, q2, [x23, #0x2f0]
    2808:      	add	x1, sp, #0x550
    280c:      	ldr	s22, [x1, w9, uxtw #2]
    2810:      	tst	w0, #0x1
    2814:      	fcsel	s22, s22, s6, ne
    2818:      	mov.s	v27[1], v28[0]
    281c:      	mov.s	v27[2], v29[0]
    2820:      	mov.s	v27[3], v22[0]
    2824:      	mov.s	v4[1], v5[0]
    2828:      	mov.s	v4[2], v25[0]
    282c:      	mov.s	v4[3], v26[0]
    2830:      	fmaxnm.4s	v3, v3, v4
    2834:      	fmaxnm.4s	v2, v2, v27
    2838:      	orr.4s	v19, #0x4
    283c:      	str	q2, [x23, #0x2e0]
    2840:      	ldr	s4, [x23, #0x2e0]
    2844:      	tst	w8, w14
    2848:      	fcsel	s4, s4, s6, ne
    284c:      	mov.s	w8, v19[1]
    2850:      	add	x9, sp, #0x428
    2854:      	bfxil	x9, x8, #0, #3
    2858:      	ldrb	w9, [x9]
    285c:      	and	w9, w11, w9
    2860:      	stp	q3, q2, [x23, #0x2b0]
    2864:      	add	x0, sp, #0x510
    2868:      	ldr	s5, [x0, w8, uxtw #2]
    286c:      	tst	w9, #0x1
    2870:      	fcsel	s5, s5, s6, ne
    2874:      	mov.s	w8, v19[2]
    2878:      	add	x9, sp, #0x428
    287c:      	bfxil	x9, x8, #0, #3
    2880:      	ldrb	w9, [x9]
    2884:      	and	w9, w12, w9
    2888:      	stp	q3, q2, [x23, #0x290]
    288c:      	add	x0, sp, #0x4f0
    2890:      	ldr	s22, [x0, w8, uxtw #2]
    2894:      	tst	w9, #0x1
    2898:      	fcsel	s22, s22, s6, ne
    289c:      	mov.s	w8, v19[3]
    28a0:      	add	x9, sp, #0x428
    28a4:      	bfxil	x9, x8, #0, #3
    28a8:      	ldrb	w9, [x9]
    28ac:      	and	w9, w13, w9
    28b0:      	stp	q3, q2, [x23, #0x270]
    28b4:      	add	x0, sp, #0x4d0
    28b8:      	ldr	s2, [x0, w8, uxtw #2]
    28bc:      	tst	w9, #0x1
    28c0:      	fcsel	s2, s2, s6, ne
    28c4:      	mov.s	v4[1], v5[0]
    28c8:      	ands	w0, w10, #0x1
    28cc:      	mov.s	v4[2], v22[0]
    28d0:      	mov.s	v4[3], v2[0]
    28d4:      	fmaxnm.4s	v2, v3, v4
    28d8:      	fcsel	s3, s2, s6, ne
    28dc:      	and	w8, w11, w10
    28e0:      	str	w8, [sp, #0x8c]
    28e4:      	tst	w8, #0x1
    28e8:      	fcsel	s4, s2, s6, ne
    28ec:      	and	w8, w12, w10
    28f0:      	str	w8, [sp, #0x88]
    28f4:      	tst	w8, #0x1
    28f8:      	fcsel	s5, s2, s6, ne
    28fc:      	and	w3, w13, w10
    2900:      	tst	w3, #0x1
    2904:      	fcsel	s19, s2, s6, ne
    2908:      	and	w4, w14, w10
    290c:      	tst	w4, #0x1
    2910:      	fcsel	s22, s2, s6, ne
    2914:      	and	w5, w15, w10
    2918:      	tst	w5, #0x1
    291c:      	fcsel	s25, s2, s6, ne
    2920:      	and	w7, w16, w10
    2924:      	tst	w7, #0x1
    2928:      	fcsel	s26, s2, s6, ne
    292c:      	and	w30, w17, w10
    2930:      	tst	w30, #0x1
    2934:      	fcsel	s2, s2, s6, ne
    2938:      	mov.s	v3[1], v4[0]
    293c:      	mov.s	v3[2], v5[0]
    2940:      	mov.s	v3[3], v19[0]
    2944:      	mov.s	v22[1], v25[0]
    2948:      	mov.s	v22[2], v26[0]
    294c:      	mov.s	v22[3], v2[0]
    2950:      	rbit	w8, w6
    2954:      	clz	w6, w8
    2958:      	stp	q3, q22, [x23, #0x1d0]
    295c:      	and	x8, x6, #0x7
    2960:      	add	x9, sp, #0x430
    2964:      	ldr	s2, [x9, x8, lsl #2]
    2968:      	mov	w8, #-0x800000          ; =-8388608
    296c:      	fmov	s3, w8
    2970:      	fmaxnm	s2, s2, s3
    2974:      	dup.4s	v3, v2[0]
    2978:      	fsub.4s	v2, v23, v3
    297c:      	str	q3, [sp, #0x100]
    2980:      	fsub.4s	v3, v24, v3
    2984:      	and.16b	v3, v0, v3
    2988:      	and.16b	v2, v1, v2
    298c:      	mov	w8, #-0x3d300000        ; =-1026555904
    2990:      	dup.4s	v23, w8
    2994:      	fcmge.4s	v4, v2, v23
    2998:      	mov	w8, #0x42c80000         ; =1120403456
    299c:      	dup.4s	v24, w8
    29a0:      	fcmge.4s	v5, v3, v23
    29a4:      	fcmge.4s	v19, v24, v2
    29a8:      	fcmge.4s	v25, v24, v3
    29ac:      	and.16b	v5, v5, v25
    29b0:      	and.16b	v4, v4, v19
    29b4:      	and.16b	v4, v4, v2
    29b8:      	and.16b	v5, v5, v3
    29bc:      	mov	w8, #0xaa3b             ; =43579
    29c0:      	movk	w8, #0x3fb8, lsl #16
    29c4:      	dup.4s	v6, w8
    29c8:      	fmul.4s	v19, v5, v6
    29cc:      	str	q6, [sp, #0x150]
    29d0:      	fmul.4s	v26, v4, v6
    29d4:      	movi.4s	v6, #0x4b, lsl #24
    29d8:      	mvni.4s	v22, #0x80, lsl #24
    29dc:      	mov.16b	v27, v22
    29e0:      	bsl.16b	v27, v6, v26
    29e4:      	mov.16b	v28, v22
    29e8:      	bsl.16b	v28, v6, v19
    29ec:      	fadd.4s	v19, v19, v28
    29f0:      	fadd.4s	v26, v26, v27
    29f4:      	fsub.4s	v26, v26, v27
    29f8:      	fsub.4s	v19, v19, v28
    29fc:      	fcvtzs.4s	v19, v19
    2a00:      	fcvtzs.4s	v8, v26
    2a04:      	scvtf.4s	v28, v8
    2a08:      	scvtf.4s	v29, v19
    2a0c:      	mov	w8, #0x7200             ; =29184
    2a10:      	movk	w8, #0xbf31, lsl #16
    2a14:      	dup.4s	v6, w8
    2a18:      	fmul.4s	v27, v29, v6
    2a1c:      	str	q6, [sp, #0x140]
    2a20:      	fmul.4s	v30, v28, v6
    2a24:      	fadd.4s	v4, v4, v30
    2a28:      	fadd.4s	v5, v5, v27
    2a2c:      	mov	w8, #0xbe8e             ; =48782
    2a30:      	movk	w8, #0xb5bf, lsl #16
    2a34:      	dup.4s	v6, w8
    2a38:      	fmul.4s	v28, v28, v6
    2a3c:      	str	q6, [sp, #0xf0]
    2a40:      	fmul.4s	v29, v29, v6
    2a44:      	fadd.4s	v5, v5, v29
    2a48:      	fadd.4s	v4, v4, v28
    2a4c:      	mov	w8, #0x2bda             ; =11226
    2a50:      	movk	w8, #0x3950, lsl #16
    2a54:      	dup.4s	v6, w8
    2a58:      	fmul.4s	v30, v4, v6
    2a5c:      	str	q6, [sp, #0x130]
    2a60:      	fmul.4s	v31, v5, v6
    2a64:      	mov	w8, #0x96c9             ; =38601
    2a68:      	movk	w8, #0x3ab6, lsl #16
    2a6c:      	dup.4s	v6, w8
    2a70:      	fadd.4s	v31, v31, v6
    2a74:      	str	q6, [sp, #0x120]
    2a78:      	fadd.4s	v30, v30, v6
    2a7c:      	fmul.4s	v9, v4, v30
    2a80:      	fmul.4s	v31, v5, v31
    2a84:      	mov	w8, #0x88a6             ; =34982
    2a88:      	movk	w8, #0x3c08, lsl #16
    2a8c:      	dup.4s	v6, w8
    2a90:      	fadd.4s	v31, v31, v6
    2a94:      	str	q6, [sp, #0x110]
    2a98:      	fadd.4s	v9, v9, v6
    2a9c:      	fmul.4s	v9, v4, v9
    2aa0:      	fmul.4s	v10, v5, v31
    2aa4:      	mov	w8, #0xaa7a             ; =43642
    2aa8:      	movk	w8, #0x3d2a, lsl #16
    2aac:      	dup.4s	v31, w8
    2ab0:      	fadd.4s	v10, v10, v31
    2ab4:      	fadd.4s	v9, v9, v31
    2ab8:      	fmul.4s	v9, v4, v9
    2abc:      	fmul.4s	v11, v5, v10
    2ac0:      	mov	w8, #0xaaab             ; =43691
    2ac4:      	movk	w8, #0x3e2a, lsl #16
    2ac8:      	dup.4s	v10, w8
    2acc:      	fadd.4s	v11, v11, v10
    2ad0:      	fadd.4s	v9, v9, v10
    2ad4:      	fmul.4s	v9, v4, v9
    2ad8:      	fmul.4s	v11, v5, v11
    2adc:      	movi.4s	v6, #0x3f, lsl #24
    2ae0:      	fadd.4s	v11, v11, v6
    2ae4:      	fadd.4s	v9, v9, v6
    2ae8:      	fmul.4s	v12, v5, v5
    2aec:      	fmul.4s	v14, v4, v4
    2af0:      	fmul.4s	v9, v14, v9
    2af4:      	fmul.4s	v11, v12, v11
    2af8:      	fadd.4s	v5, v5, v11
    2afc:      	fadd.4s	v4, v4, v9
    2b00:      	fmov.4s	v11, #1.00000000
    2b04:      	fadd.4s	v4, v4, v11
    2b08:      	fadd.4s	v5, v5, v11
    2b0c:      	sshr.4s	v9, v8, #0x1
    2b10:      	sshr.4s	v12, v19, #0x1
    2b14:      	shl.4s	v14, v12, #0x17
    2b18:      	add.4s	v14, v14, v11
    2b1c:      	fmul.4s	v5, v5, v14
    2b20:      	shl.4s	v14, v9, #0x17
    2b24:      	add.4s	v14, v14, v11
    2b28:      	fmul.4s	v4, v4, v14
    2b2c:      	sub.4s	v19, v19, v12
    2b30:      	sub.4s	v8, v8, v9
    2b34:      	shl.4s	v8, v8, #0x17
    2b38:      	add.4s	v8, v8, v11
    2b3c:      	fmul.4s	v4, v4, v8
    2b40:      	shl.4s	v19, v19, #0x17
    2b44:      	add.4s	v19, v19, v11
    2b48:      	fmul.4s	v5, v5, v19
    2b4c:      	fcmgt.4s	v19, v23, v3
    2b50:      	bic.16b	v5, v5, v19
    2b54:      	fcmgt.4s	v19, v23, v2
    2b58:      	bic.16b	v4, v4, v19
    2b5c:      	fcmgt.4s	v19, v2, v24
    2b60:      	ldr	q6, [sp, #0x170]
    2b64:      	bit.16b	v4, v6, v19
    2b68:      	fcmgt.4s	v19, v3, v24
    2b6c:      	bit.16b	v5, v6, v19
    2b70:      	fcmeq.4s	v3, v3, v3
    2b74:      	ldr	q6, [sp, #0x160]
    2b78:      	bsl.16b	v3, v5, v6
    2b7c:      	fcmeq.4s	v2, v2, v2
    2b80:      	bsl.16b	v2, v4, v6
    2b84:      	sshll.4s	v4, v13, #0x0
    2b88:      	ldr	q5, [sp, #0x180]
    2b8c:      	fmov	w8, s5
    2b90:      	bic.16b	v4, v2, v4
    2b94:      	sshll.2d	v14, v1, #0x0
    2b98:      	ldr	q2, [sp, #0x70]
    2b9c:      	bic.16b	v3, v3, v2
    2ba0:      	ldr	q2, [x23, #0x500]
    2ba4:      	stp	q3, q4, [sp, #0x60]
    2ba8:      	bit.16b	v2, v4, v1
    2bac:      	str	q2, [x23, #0x500]
    2bb0:      	ldr	q2, [x23, #0x510]
    2bb4:      	bit.16b	v2, v3, v0
    2bb8:      	str	q2, [x23, #0x510]
    2bbc:      	adrp	x9, 0x2000 <_llm_rows.packet_batch.blocks+0x964>
    2bc0:      	ldr	q2, [x9]
    2bc4:      	and.16b	v2, v14, v2
    2bc8:      	add.2d	v2, v21, v2
    2bcc:      	tbz	w8, #0x0, 0x2c3c <_llm_rows.packet_batch.blocks+0x15a0>
    2bd0:      	fmov	x9, d2
    2bd4:      	ldr	b19, [x9]
    2bd8:      	and	w8, w8, #0xff
    2bdc:      	movi.4s	v6, #0x4b, lsl #24
    2be0:      	ldp	q30, q26, [sp, #0xf0]
    2be4:      	tbnz	w8, #0x1, 0x2c50 <_llm_rows.packet_batch.blocks+0x15b4>
    2be8:      	b	0x2c58 <_llm_rows.packet_batch.blocks+0x15bc>
    2bec:      	fmov	x9, d25
    2bf0:      	ld1.b	{ v4 }[2], [x9]
    2bf4:      	tbz	w8, #0x3, 0x2028 <_llm_rows.packet_batch.blocks+0x98c>
    2bf8:      	mov.d	x9, v25[1]
    2bfc:      	ld1.b	{ v4 }[3], [x9]
    2c00:      	ldr	q6, [sp, #0x1a0]
    2c04:      	add.2d	v25, v6, v5
    2c08:      	tbz	w8, #0x4, 0x2034 <_llm_rows.packet_batch.blocks+0x998>
    2c0c:      	fmov	x9, d25
    2c10:      	ld1.b	{ v4 }[4], [x9]
    2c14:      	tbz	w8, #0x5, 0x2038 <_llm_rows.packet_batch.blocks+0x99c>
    2c18:      	mov.d	x9, v25[1]
    2c1c:      	ld1.b	{ v4 }[5], [x9]
    2c20:      	ldr	q6, [sp, #0x190]
    2c24:      	add.2d	v5, v6, v5
    2c28:      	tbz	w8, #0x6, 0x2044 <_llm_rows.packet_batch.blocks+0x9a8>
    2c2c:      	fmov	x9, d5
    2c30:      	ld1.b	{ v4 }[6], [x9]
    2c34:      	tbnz	w8, #0x7, 0x2048 <_llm_rows.packet_batch.blocks+0x9ac>
    2c38:      	b	0x2050 <_llm_rows.packet_batch.blocks+0x9b4>
    2c3c:      	movi.2d	v19, #0000000000000000
    2c40:      	and	w8, w8, #0xff
    2c44:      	movi.4s	v6, #0x4b, lsl #24
    2c48:      	ldp	q30, q26, [sp, #0xf0]
    2c4c:      	tbz	w8, #0x1, 0x2c58 <_llm_rows.packet_batch.blocks+0x15bc>
    2c50:      	mov.d	x9, v2[1]
    2c54:      	ld1.b	{ v19 }[1], [x9]
    2c58:      	adrp	x9, 0x2000 <_llm_rows.packet_batch.blocks+0x964>
    2c5c:      	ldr	q2, [x9]
    2c60:      	and.16b	v2, v16, v2
    2c64:      	add.2d	v2, v20, v2
    2c68:      	tbnz	w8, #0x2, 0x2eb8 <_llm_rows.packet_batch.blocks+0x181c>
    2c6c:      	tbz	w8, #0x3, 0x2c78 <_llm_rows.packet_batch.blocks+0x15dc>
    2c70:      	mov.d	x9, v2[1]
    2c74:      	ld1.b	{ v19 }[3], [x9]
    2c78:      	sshll.2d	v3, v0, #0x0
    2c7c:      	adrp	x9, 0x2000 <_llm_rows.packet_batch.blocks+0x964>
    2c80:      	ldr	q2, [x9]
    2c84:      	mov.16b	v28, v3
    2c88:      	and.16b	v2, v3, v2
    2c8c:      	add.2d	v2, v18, v2
    2c90:      	tbnz	w8, #0x4, 0x2ec8 <_llm_rows.packet_batch.blocks+0x182c>
    2c94:      	tbnz	w8, #0x5, 0x2ed4 <_llm_rows.packet_batch.blocks+0x1838>
    2c98:      	adrp	x9, 0x2000 <_llm_rows.packet_batch.blocks+0x964>
    2c9c:      	ldr	q2, [x9]
    2ca0:      	and.16b	v2, v7, v2
    2ca4:      	add.2d	v2, v17, v2
    2ca8:      	tbnz	w8, #0x6, 0x2ef0 <_llm_rows.packet_batch.blocks+0x1854>
    2cac:      	tbz	w8, #0x7, 0x2cb8 <_llm_rows.packet_batch.blocks+0x161c>
    2cb0:      	mov.d	x8, v2[1]
    2cb4:      	ld1.b	{ v19 }[7], [x8]
    2cb8:      	mov	w8, #0x20               ; =32
    2cbc:      	fmov	d2, x8
    2cc0:      	and.16b	v2, v14, v2
    2cc4:      	fmov	x8, d2
    2cc8:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
    2ccc:      	add	x9, x9, #0x360
    2cd0:      	add	x8, x9, x8
    2cd4:      	ldp	q3, q2, [x8]
    2cd8:      	fsub.4s	v4, v3, v26
    2cdc:      	fsub.4s	v2, v2, v26
    2ce0:      	and.16b	v3, v0, v2
    2ce4:      	and.16b	v2, v1, v4
    2ce8:      	fcmge.4s	v4, v2, v23
    2cec:      	fcmge.4s	v5, v3, v23
    2cf0:      	fcmge.4s	v8, v24, v2
    2cf4:      	fcmge.4s	v9, v24, v3
    2cf8:      	and.16b	v5, v5, v9
    2cfc:      	and.16b	v4, v4, v8
    2d00:      	and.16b	v4, v4, v2
    2d04:      	and.16b	v5, v5, v3
    2d08:      	ldp	q25, q27, [sp, #0x140]
    2d0c:      	fmul.4s	v8, v5, v27
    2d10:      	fmul.4s	v9, v4, v27
    2d14:      	mov.16b	v15, v22
    2d18:      	bsl.16b	v15, v6, v9
    2d1c:      	mov.16b	v12, v22
    2d20:      	bsl.16b	v12, v6, v8
    2d24:      	fadd.4s	v8, v8, v12
    2d28:      	fadd.4s	v9, v9, v15
    2d2c:      	fsub.4s	v9, v9, v15
    2d30:      	fsub.4s	v8, v8, v12
    2d34:      	fcvtzs.4s	v8, v8
    2d38:      	fcvtzs.4s	v9, v9
    2d3c:      	scvtf.4s	v12, v9
    2d40:      	scvtf.4s	v15, v8
    2d44:      	fmul.4s	v13, v12, v25
    2d48:      	fadd.4s	v4, v4, v13
    2d4c:      	fmul.4s	v13, v15, v25
    2d50:      	fadd.4s	v5, v5, v13
    2d54:      	fmul.4s	v12, v12, v30
    2d58:      	fmul.4s	v13, v15, v30
    2d5c:      	fadd.4s	v5, v5, v13
    2d60:      	fadd.4s	v4, v4, v12
    2d64:      	ldp	q25, q27, [sp, #0x120]
    2d68:      	fmul.4s	v12, v4, v27
    2d6c:      	fmul.4s	v13, v5, v27
    2d70:      	fadd.4s	v13, v13, v25
    2d74:      	fadd.4s	v12, v12, v25
    2d78:      	fmul.4s	v12, v4, v12
    2d7c:      	fmul.4s	v13, v5, v13
    2d80:      	ldr	q25, [sp, #0x110]
    2d84:      	fadd.4s	v13, v13, v25
    2d88:      	fadd.4s	v12, v12, v25
    2d8c:      	fmul.4s	v12, v4, v12
    2d90:      	fmul.4s	v13, v5, v13
    2d94:      	fadd.4s	v13, v13, v31
    2d98:      	fadd.4s	v12, v12, v31
    2d9c:      	fmul.4s	v12, v4, v12
    2da0:      	fmul.4s	v13, v5, v13
    2da4:      	fadd.4s	v13, v13, v10
    2da8:      	fadd.4s	v12, v12, v10
    2dac:      	fmul.4s	v12, v4, v12
    2db0:      	fmul.4s	v13, v5, v13
    2db4:      	movi.4s	v25, #0x3f, lsl #24
    2db8:      	fadd.4s	v13, v13, v25
    2dbc:      	fadd.4s	v12, v12, v25
    2dc0:      	fmul.4s	v15, v4, v4
    2dc4:      	fmul.4s	v12, v15, v12
    2dc8:      	fmul.4s	v15, v5, v5
    2dcc:      	fmul.4s	v13, v15, v13
    2dd0:      	fadd.4s	v5, v5, v13
    2dd4:      	fadd.4s	v4, v4, v12
    2dd8:      	fadd.4s	v4, v4, v11
    2ddc:      	fadd.4s	v5, v5, v11
    2de0:      	sshr.4s	v12, v9, #0x1
    2de4:      	sshr.4s	v13, v8, #0x1
    2de8:      	shl.4s	v15, v13, #0x17
    2dec:      	add.4s	v15, v15, v11
    2df0:      	fmul.4s	v5, v5, v15
    2df4:      	shl.4s	v15, v12, #0x17
    2df8:      	add.4s	v15, v15, v11
    2dfc:      	fmul.4s	v4, v4, v15
    2e00:      	sub.4s	v8, v8, v13
    2e04:      	sub.4s	v9, v9, v12
    2e08:      	shl.4s	v9, v9, #0x17
    2e0c:      	add.4s	v9, v9, v11
    2e10:      	fmul.4s	v4, v4, v9
    2e14:      	shl.4s	v8, v8, #0x17
    2e18:      	add.4s	v8, v8, v11
    2e1c:      	fmul.4s	v5, v5, v8
    2e20:      	fcmgt.4s	v8, v23, v3
    2e24:      	bic.16b	v5, v5, v8
    2e28:      	fcmgt.4s	v8, v23, v2
    2e2c:      	bic.16b	v4, v4, v8
    2e30:      	fcmgt.4s	v8, v2, v24
    2e34:      	ldp	q25, q27, [sp, #0x160]
    2e38:      	bit.16b	v4, v27, v8
    2e3c:      	fcmgt.4s	v8, v3, v24
    2e40:      	bit.16b	v5, v27, v8
    2e44:      	fcmeq.4s	v3, v3, v3
    2e48:      	bsl.16b	v3, v5, v25
    2e4c:      	cmeq.8b	v5, v19, #0
    2e50:      	sshll.8h	v5, v5, #0x0
    2e54:      	fcmeq.4s	v2, v2, v2
    2e58:      	bsl.16b	v2, v4, v25
    2e5c:      	sshll.4s	v4, v5, #0x0
    2e60:      	bic.16b	v29, v2, v4
    2e64:      	sshll2.4s	v2, v5, #0x0
    2e68:      	bic.16b	v3, v3, v2
    2e6c:      	ldr	q2, [x23, #0x520]
    2e70:      	bit.16b	v2, v29, v1
    2e74:      	str	q2, [x23, #0x520]
    2e78:      	ldr	q2, [x23, #0x530]
    2e7c:      	mov.16b	v27, v3
    2e80:      	bit.16b	v2, v3, v0
    2e84:      	str	q2, [x23, #0x530]
    2e88:      	adrp	x8, 0x2000 <_llm_rows.packet_batch.blocks+0x964>
    2e8c:      	ldr	q2, [x8]
    2e90:      	and.16b	v2, v14, v2
    2e94:      	ldr	q3, [sp, #0x180]
    2e98:      	fmov	w8, s3
    2e9c:      	add.2d	v2, v21, v2
    2ea0:      	tbz	w8, #0x0, 0x2f00 <_llm_rows.packet_batch.blocks+0x1864>
    2ea4:      	fmov	x9, d2
    2ea8:      	ldr	b19, [x9]
    2eac:      	and	w8, w8, #0xff
    2eb0:      	tbnz	w8, #0x1, 0x2f0c <_llm_rows.packet_batch.blocks+0x1870>
    2eb4:      	b	0x2f14 <_llm_rows.packet_batch.blocks+0x1878>
    2eb8:      	fmov	x9, d2
    2ebc:      	ld1.b	{ v19 }[2], [x9]
    2ec0:      	tbnz	w8, #0x3, 0x2c70 <_llm_rows.packet_batch.blocks+0x15d4>
    2ec4:      	b	0x2c78 <_llm_rows.packet_batch.blocks+0x15dc>
    2ec8:      	fmov	x9, d2
    2ecc:      	ld1.b	{ v19 }[4], [x9]
    2ed0:      	tbz	w8, #0x5, 0x2c98 <_llm_rows.packet_batch.blocks+0x15fc>
    2ed4:      	mov.d	x9, v2[1]
    2ed8:      	ld1.b	{ v19 }[5], [x9]
    2edc:      	adrp	x9, 0x2000 <_llm_rows.packet_batch.blocks+0x964>
    2ee0:      	ldr	q2, [x9]
    2ee4:      	and.16b	v2, v7, v2
    2ee8:      	add.2d	v2, v17, v2
    2eec:      	tbz	w8, #0x6, 0x2cac <_llm_rows.packet_batch.blocks+0x1610>
    2ef0:      	fmov	x9, d2
    2ef4:      	ld1.b	{ v19 }[6], [x9]
    2ef8:      	tbnz	w8, #0x7, 0x2cb0 <_llm_rows.packet_batch.blocks+0x1614>
    2efc:      	b	0x2cb8 <_llm_rows.packet_batch.blocks+0x161c>
    2f00:      	movi.2d	v19, #0000000000000000
    2f04:      	and	w8, w8, #0xff
    2f08:      	tbz	w8, #0x1, 0x2f14 <_llm_rows.packet_batch.blocks+0x1878>
    2f0c:      	mov.d	x9, v2[1]
    2f10:      	ld1.b	{ v19 }[1], [x9]
    2f14:      	adrp	x9, 0x2000 <_llm_rows.packet_batch.blocks+0x964>
    2f18:      	ldr	q2, [x9]
    2f1c:      	and.16b	v2, v16, v2
    2f20:      	add.2d	v2, v20, v2
    2f24:      	tbnz	w8, #0x2, 0x3168 <_llm_rows.packet_batch.blocks+0x1acc>
    2f28:      	tbnz	w8, #0x3, 0x3174 <_llm_rows.packet_batch.blocks+0x1ad8>
    2f2c:      	adrp	x9, 0x2000 <_llm_rows.packet_batch.blocks+0x964>
    2f30:      	ldr	q2, [x9]
    2f34:      	and.16b	v2, v28, v2
    2f38:      	add.2d	v2, v18, v2
    2f3c:      	tbnz	w8, #0x4, 0x3190 <_llm_rows.packet_batch.blocks+0x1af4>
    2f40:      	tbnz	w8, #0x5, 0x319c <_llm_rows.packet_batch.blocks+0x1b00>
    2f44:      	adrp	x9, 0x2000 <_llm_rows.packet_batch.blocks+0x964>
    2f48:      	ldr	q2, [x9]
    2f4c:      	and.16b	v2, v7, v2
    2f50:      	add.2d	v2, v17, v2
    2f54:      	tbnz	w8, #0x6, 0x31b8 <_llm_rows.packet_batch.blocks+0x1b1c>
    2f58:      	tbz	w8, #0x7, 0x2f64 <_llm_rows.packet_batch.blocks+0x18c8>
    2f5c:      	mov.d	x8, v2[1]
    2f60:      	ld1.b	{ v19 }[7], [x8]
    2f64:      	ldr	q2, [sp, #0x20]
    2f68:      	and.16b	v2, v14, v2
    2f6c:      	fmov	x8, d2
    2f70:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
    2f74:      	add	x9, x9, #0x360
    2f78:      	add	x8, x9, x8
    2f7c:      	ldp	q3, q2, [x8]
    2f80:      	fsub.4s	v4, v3, v26
    2f84:      	fsub.4s	v2, v2, v26
    2f88:      	and.16b	v3, v0, v2
    2f8c:      	and.16b	v2, v1, v4
    2f90:      	fcmge.4s	v4, v2, v23
    2f94:      	fcmge.4s	v5, v3, v23
    2f98:      	fcmge.4s	v9, v24, v2
    2f9c:      	fcmge.4s	v12, v24, v3
    2fa0:      	and.16b	v5, v5, v12
    2fa4:      	and.16b	v4, v4, v9
    2fa8:      	and.16b	v4, v4, v2
    2fac:      	and.16b	v5, v5, v3
    2fb0:      	ldr	q25, [sp, #0x150]
    2fb4:      	fmul.4s	v9, v5, v25
    2fb8:      	fmul.4s	v12, v4, v25
    2fbc:      	mov.16b	v13, v22
    2fc0:      	bsl.16b	v13, v6, v12
    2fc4:      	mov.16b	v15, v22
    2fc8:      	bsl.16b	v15, v6, v9
    2fcc:      	fadd.4s	v9, v9, v15
    2fd0:      	fadd.4s	v12, v12, v13
    2fd4:      	fsub.4s	v12, v12, v13
    2fd8:      	fsub.4s	v9, v9, v15
    2fdc:      	fcvtzs.4s	v9, v9
    2fe0:      	fcvtzs.4s	v12, v12
    2fe4:      	scvtf.4s	v13, v12
    2fe8:      	scvtf.4s	v15, v9
    2fec:      	ldr	q25, [sp, #0x140]
    2ff0:      	fmul.4s	v8, v13, v25
    2ff4:      	fadd.4s	v4, v4, v8
    2ff8:      	fmul.4s	v8, v15, v25
    2ffc:      	fadd.4s	v5, v5, v8
    3000:      	fmul.4s	v8, v13, v30
    3004:      	fmul.4s	v13, v15, v30
    3008:      	fadd.4s	v5, v5, v13
    300c:      	fadd.4s	v4, v4, v8
    3010:      	ldr	q25, [sp, #0x130]
    3014:      	fmul.4s	v8, v4, v25
    3018:      	fmul.4s	v13, v5, v25
    301c:      	ldr	q25, [sp, #0x120]
    3020:      	fadd.4s	v13, v13, v25
    3024:      	fadd.4s	v8, v8, v25
    3028:      	fmul.4s	v8, v4, v8
    302c:      	fmul.4s	v13, v5, v13
    3030:      	ldr	q25, [sp, #0x110]
    3034:      	fadd.4s	v13, v13, v25
    3038:      	fadd.4s	v8, v8, v25
    303c:      	fmul.4s	v8, v4, v8
    3040:      	fmul.4s	v13, v5, v13
    3044:      	fadd.4s	v13, v13, v31
    3048:      	fadd.4s	v8, v8, v31
    304c:      	fmul.4s	v8, v4, v8
    3050:      	fmul.4s	v13, v5, v13
    3054:      	fadd.4s	v13, v13, v10
    3058:      	fadd.4s	v8, v8, v10
    305c:      	fmul.4s	v8, v4, v8
    3060:      	fmul.4s	v13, v5, v13
    3064:      	movi.4s	v25, #0x3f, lsl #24
    3068:      	fadd.4s	v13, v13, v25
    306c:      	fadd.4s	v8, v8, v25
    3070:      	fmul.4s	v15, v4, v4
    3074:      	fmul.4s	v8, v15, v8
    3078:      	fmul.4s	v15, v5, v5
    307c:      	fmul.4s	v13, v15, v13
    3080:      	fadd.4s	v5, v5, v13
    3084:      	fadd.4s	v4, v4, v8
    3088:      	fadd.4s	v4, v4, v11
    308c:      	fadd.4s	v5, v5, v11
    3090:      	sshr.4s	v8, v12, #0x1
    3094:      	sshr.4s	v13, v9, #0x1
    3098:      	shl.4s	v15, v13, #0x17
    309c:      	add.4s	v15, v15, v11
    30a0:      	fmul.4s	v5, v5, v15
    30a4:      	shl.4s	v15, v8, #0x17
    30a8:      	add.4s	v15, v15, v11
    30ac:      	fmul.4s	v4, v4, v15
    30b0:      	sub.4s	v9, v9, v13
    30b4:      	sub.4s	v8, v12, v8
    30b8:      	shl.4s	v8, v8, #0x17
    30bc:      	add.4s	v8, v8, v11
    30c0:      	fmul.4s	v4, v4, v8
    30c4:      	shl.4s	v8, v9, #0x17
    30c8:      	add.4s	v8, v8, v11
    30cc:      	fmul.4s	v5, v5, v8
    30d0:      	fcmgt.4s	v8, v23, v3
    30d4:      	bic.16b	v5, v5, v8
    30d8:      	fcmgt.4s	v8, v23, v2
    30dc:      	bic.16b	v4, v4, v8
    30e0:      	fcmgt.4s	v8, v2, v24
    30e4:      	ldr	q25, [sp, #0x170]
    30e8:      	bit.16b	v4, v25, v8
    30ec:      	fcmgt.4s	v8, v3, v24
    30f0:      	bit.16b	v5, v25, v8
    30f4:      	fcmeq.4s	v3, v3, v3
    30f8:      	ldr	q25, [sp, #0x160]
    30fc:      	bsl.16b	v3, v5, v25
    3100:      	cmeq.8b	v5, v19, #0
    3104:      	sshll.8h	v5, v5, #0x0
    3108:      	fcmeq.4s	v2, v2, v2
    310c:      	bsl.16b	v2, v4, v25
    3110:      	sshll.4s	v4, v5, #0x0
    3114:      	bic.16b	v19, v2, v4
    3118:      	sshll2.4s	v2, v5, #0x0
    311c:      	bic.16b	v15, v3, v2
    3120:      	ldr	q2, [x23, #0x540]
    3124:      	bit.16b	v2, v19, v1
    3128:      	str	q2, [x23, #0x540]
    312c:      	ldr	q2, [x23, #0x550]
    3130:      	bit.16b	v2, v15, v0
    3134:      	str	q2, [x23, #0x550]
    3138:      	adrp	x8, 0x3000 <_llm_rows.packet_batch.blocks+0x1964>
    313c:      	ldr	q2, [x8]
    3140:      	and.16b	v2, v14, v2
    3144:      	add.2d	v2, v21, v2
    3148:      	ldr	q25, [sp, #0x180]
    314c:      	fmov	w8, s25
    3150:      	tbz	w8, #0x0, 0x31c8 <_llm_rows.packet_batch.blocks+0x1b2c>
    3154:      	fmov	x9, d2
    3158:      	ldr	b21, [x9]
    315c:      	and	w8, w8, #0xff
    3160:      	tbnz	w8, #0x1, 0x31d4 <_llm_rows.packet_batch.blocks+0x1b38>
    3164:      	b	0x31dc <_llm_rows.packet_batch.blocks+0x1b40>
    3168:      	fmov	x9, d2
    316c:      	ld1.b	{ v19 }[2], [x9]
    3170:      	tbz	w8, #0x3, 0x2f2c <_llm_rows.packet_batch.blocks+0x1890>
    3174:      	mov.d	x9, v2[1]
    3178:      	ld1.b	{ v19 }[3], [x9]
    317c:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1964>
    3180:      	ldr	q2, [x9]
    3184:      	and.16b	v2, v28, v2
    3188:      	add.2d	v2, v18, v2
    318c:      	tbz	w8, #0x4, 0x2f40 <_llm_rows.packet_batch.blocks+0x18a4>
    3190:      	fmov	x9, d2
    3194:      	ld1.b	{ v19 }[4], [x9]
    3198:      	tbz	w8, #0x5, 0x2f44 <_llm_rows.packet_batch.blocks+0x18a8>
    319c:      	mov.d	x9, v2[1]
    31a0:      	ld1.b	{ v19 }[5], [x9]
    31a4:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1964>
    31a8:      	ldr	q2, [x9]
    31ac:      	and.16b	v2, v7, v2
    31b0:      	add.2d	v2, v17, v2
    31b4:      	tbz	w8, #0x6, 0x2f58 <_llm_rows.packet_batch.blocks+0x18bc>
    31b8:      	fmov	x9, d2
    31bc:      	ld1.b	{ v19 }[6], [x9]
    31c0:      	tbnz	w8, #0x7, 0x2f5c <_llm_rows.packet_batch.blocks+0x18c0>
    31c4:      	b	0x2f64 <_llm_rows.packet_batch.blocks+0x18c8>
    31c8:      	movi.2d	v21, #0000000000000000
    31cc:      	and	w8, w8, #0xff
    31d0:      	tbz	w8, #0x1, 0x31dc <_llm_rows.packet_batch.blocks+0x1b40>
    31d4:      	mov.d	x9, v2[1]
    31d8:      	ld1.b	{ v21 }[1], [x9]
    31dc:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1964>
    31e0:      	ldr	q2, [x9]
    31e4:      	and.16b	v2, v16, v2
    31e8:      	add.2d	v2, v20, v2
    31ec:      	tbnz	w8, #0x2, 0x4318 <_llm_rows.packet_batch.blocks+0x2c7c>
    31f0:      	tbnz	w8, #0x3, 0x4324 <_llm_rows.packet_batch.blocks+0x2c88>
    31f4:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1964>
    31f8:      	ldr	q2, [x9]
    31fc:      	and.16b	v2, v28, v2
    3200:      	add.2d	v2, v18, v2
    3204:      	tbnz	w8, #0x4, 0x4340 <_llm_rows.packet_batch.blocks+0x2ca4>
    3208:      	tbnz	w8, #0x5, 0x434c <_llm_rows.packet_batch.blocks+0x2cb0>
    320c:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1964>
    3210:      	ldr	q2, [x9]
    3214:      	and.16b	v2, v7, v2
    3218:      	add.2d	v3, v17, v2
    321c:      	tbnz	w8, #0x6, 0x4368 <_llm_rows.packet_batch.blocks+0x2ccc>
    3220:      	ldr	q2, [sp, #0x10]
    3224:      	and.16b	v2, v14, v2
    3228:      	tbz	w8, #0x7, 0x3234 <_llm_rows.packet_batch.blocks+0x1b98>
    322c:      	mov.d	x8, v3[1]
    3230:      	ld1.b	{ v21 }[7], [x8]
    3234:      	fmov	x8, d2
    3238:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
    323c:      	add	x9, x9, #0x360
    3240:      	add	x8, x9, x8
    3244:      	ldp	q3, q2, [x8]
    3248:      	fsub.4s	v4, v3, v26
    324c:      	fsub.4s	v2, v2, v26
    3250:      	and.16b	v3, v0, v2
    3254:      	and.16b	v2, v1, v4
    3258:      	fcmge.4s	v4, v2, v23
    325c:      	fcmge.4s	v5, v3, v23
    3260:      	fcmge.4s	v7, v24, v2
    3264:      	fcmge.4s	v16, v24, v3
    3268:      	and.16b	v5, v5, v16
    326c:      	and.16b	v4, v4, v7
    3270:      	and.16b	v4, v4, v2
    3274:      	and.16b	v5, v5, v3
    3278:      	ldr	q16, [sp, #0x150]
    327c:      	fmul.4s	v7, v5, v16
    3280:      	fmul.4s	v16, v4, v16
    3284:      	mov.16b	v17, v22
    3288:      	bsl.16b	v17, v6, v16
    328c:      	mov.16b	v18, v22
    3290:      	bsl.16b	v18, v6, v7
    3294:      	fadd.4s	v7, v7, v18
    3298:      	fadd.4s	v16, v16, v17
    329c:      	fsub.4s	v16, v16, v17
    32a0:      	fsub.4s	v7, v7, v18
    32a4:      	fcvtzs.4s	v7, v7
    32a8:      	fcvtzs.4s	v16, v16
    32ac:      	scvtf.4s	v17, v16
    32b0:      	scvtf.4s	v18, v7
    32b4:      	ldr	q6, [sp, #0x140]
    32b8:      	fmul.4s	v20, v17, v6
    32bc:      	fadd.4s	v4, v4, v20
    32c0:      	fmul.4s	v20, v18, v6
    32c4:      	fadd.4s	v5, v5, v20
    32c8:      	fmul.4s	v17, v17, v30
    32cc:      	fmul.4s	v18, v18, v30
    32d0:      	fadd.4s	v5, v5, v18
    32d4:      	fadd.4s	v4, v4, v17
    32d8:      	ldr	q6, [sp, #0x130]
    32dc:      	fmul.4s	v17, v4, v6
    32e0:      	fmul.4s	v18, v5, v6
    32e4:      	ldr	q6, [sp, #0x120]
    32e8:      	fadd.4s	v18, v18, v6
    32ec:      	fadd.4s	v17, v17, v6
    32f0:      	fmul.4s	v17, v4, v17
    32f4:      	fmul.4s	v18, v5, v18
    32f8:      	ldr	q6, [sp, #0x110]
    32fc:      	fadd.4s	v18, v18, v6
    3300:      	fadd.4s	v17, v17, v6
    3304:      	fmul.4s	v17, v4, v17
    3308:      	fmul.4s	v18, v5, v18
    330c:      	fadd.4s	v18, v18, v31
    3310:      	fadd.4s	v17, v17, v31
    3314:      	fmul.4s	v17, v4, v17
    3318:      	fmul.4s	v18, v5, v18
    331c:      	fadd.4s	v18, v18, v10
    3320:      	fadd.4s	v17, v17, v10
    3324:      	fmul.4s	v17, v4, v17
    3328:      	fmul.4s	v18, v5, v18
    332c:      	movi.4s	v6, #0x3f, lsl #24
    3330:      	fadd.4s	v18, v18, v6
    3334:      	fadd.4s	v17, v17, v6
    3338:      	fmul.4s	v20, v4, v4
    333c:      	fmul.4s	v17, v20, v17
    3340:      	fmul.4s	v20, v5, v5
    3344:      	fmul.4s	v18, v20, v18
    3348:      	fadd.4s	v5, v5, v18
    334c:      	fadd.4s	v4, v4, v17
    3350:      	fadd.4s	v4, v4, v11
    3354:      	fadd.4s	v5, v5, v11
    3358:      	sshr.4s	v17, v16, #0x1
    335c:      	sshr.4s	v18, v7, #0x1
    3360:      	shl.4s	v20, v18, #0x17
    3364:      	add.4s	v20, v20, v11
    3368:      	fmul.4s	v5, v5, v20
    336c:      	shl.4s	v20, v17, #0x17
    3370:      	add.4s	v20, v20, v11
    3374:      	fmul.4s	v4, v4, v20
    3378:      	sub.4s	v7, v7, v18
    337c:      	sub.4s	v16, v16, v17
    3380:      	shl.4s	v16, v16, #0x17
    3384:      	add.4s	v16, v16, v11
    3388:      	fmul.4s	v4, v4, v16
    338c:      	shl.4s	v7, v7, #0x17
    3390:      	add.4s	v7, v7, v11
    3394:      	fmul.4s	v5, v5, v7
    3398:      	fcmgt.4s	v7, v23, v3
    339c:      	bic.16b	v5, v5, v7
    33a0:      	fcmgt.4s	v7, v23, v2
    33a4:      	bic.16b	v4, v4, v7
    33a8:      	fcmgt.4s	v7, v2, v24
    33ac:      	ldr	q6, [sp, #0x170]
    33b0:      	bit.16b	v4, v6, v7
    33b4:      	fcmgt.4s	v7, v3, v24
    33b8:      	bit.16b	v5, v6, v7
    33bc:      	fcmeq.4s	v3, v3, v3
    33c0:      	ldr	q6, [sp, #0x160]
    33c4:      	bsl.16b	v3, v5, v6
    33c8:      	cmeq.8b	v5, v21, #0
    33cc:      	sshll.8h	v5, v5, #0x0
    33d0:      	fcmeq.4s	v2, v2, v2
    33d4:      	bsl.16b	v2, v4, v6
    33d8:      	sshll.4s	v4, v5, #0x0
    33dc:      	bic.16b	v2, v2, v4
    33e0:      	sshll2.4s	v4, v5, #0x0
    33e4:      	bic.16b	v3, v3, v4
    33e8:      	ldr	q4, [x23, #0x560]
    33ec:      	bit.16b	v4, v2, v1
    33f0:      	str	q4, [x23, #0x560]
    33f4:      	ldr	q4, [x23, #0x570]
    33f8:      	bit.16b	v4, v3, v0
    33fc:      	str	q4, [x23, #0x570]
    3400:      	ldp	q5, q4, [sp, #0x60]
    3404:      	and.16b	v16, v0, v5
    3408:      	and.16b	v7, v1, v4
    340c:      	and.16b	v12, v0, v27
    3410:      	and.16b	v21, v1, v29
    3414:      	and.16b	v17, v0, v15
    3418:      	and.16b	v13, v1, v19
    341c:      	and.16b	v20, v0, v3
    3420:      	and.16b	v18, v1, v2
    3424:      	ldr	x8, [sp, #0x40]
    3428:      	ldr	x9, [sp, #0xb0]
    342c:      	mov	w1, #0x4                ; =4
    3430:      	b	0x3620 <_llm_rows.packet_batch.blocks+0x1f84>
    3434:      	ldp	q5, q4, [x9]
    3438:      	fsub.4s	v6, v5, v22
    343c:      	fsub.4s	v4, v4, v22
    3440:      	and.16b	v5, v0, v4
    3444:      	and.16b	v4, v1, v6
    3448:      	fcmge.4s	v6, v4, v23
    344c:      	fcmge.4s	v22, v5, v23
    3450:      	fcmge.4s	v25, v24, v4
    3454:      	fcmge.4s	v26, v24, v5
    3458:      	and.16b	v22, v22, v26
    345c:      	and.16b	v6, v6, v25
    3460:      	and.16b	v6, v6, v4
    3464:      	and.16b	v22, v22, v5
    3468:      	ldp	q30, q26, [sp, #0x140]
    346c:      	fmul.4s	v25, v22, v26
    3470:      	fmul.4s	v26, v6, v26
    3474:      	mov.16b	v27, v29
    3478:      	bsl.16b	v27, v28, v26
    347c:      	bif.16b	v28, v25, v29
    3480:      	fadd.4s	v25, v25, v28
    3484:      	fadd.4s	v26, v26, v27
    3488:      	fsub.4s	v26, v26, v27
    348c:      	fsub.4s	v25, v25, v28
    3490:      	fcvtzs.4s	v25, v25
    3494:      	fcvtzs.4s	v26, v26
    3498:      	scvtf.4s	v27, v26
    349c:      	scvtf.4s	v28, v25
    34a0:      	fmul.4s	v29, v27, v30
    34a4:      	fadd.4s	v6, v6, v29
    34a8:      	fmul.4s	v29, v28, v30
    34ac:      	fadd.4s	v22, v22, v29
    34b0:      	ldr	q30, [sp, #0xf0]
    34b4:      	fmul.4s	v27, v27, v30
    34b8:      	fmul.4s	v28, v28, v30
    34bc:      	fadd.4s	v22, v22, v28
    34c0:      	fadd.4s	v6, v6, v27
    34c4:      	ldp	q29, q28, [sp, #0x120]
    34c8:      	fmul.4s	v27, v6, v28
    34cc:      	fmul.4s	v28, v22, v28
    34d0:      	fadd.4s	v28, v28, v29
    34d4:      	fadd.4s	v27, v27, v29
    34d8:      	fmul.4s	v27, v6, v27
    34dc:      	fmul.4s	v28, v22, v28
    34e0:      	ldr	q29, [sp, #0x110]
    34e4:      	fadd.4s	v28, v28, v29
    34e8:      	fadd.4s	v27, v27, v29
    34ec:      	fmul.4s	v27, v6, v27
    34f0:      	fmul.4s	v28, v22, v28
    34f4:      	fadd.4s	v28, v28, v31
    34f8:      	fadd.4s	v27, v27, v31
    34fc:      	fmul.4s	v27, v6, v27
    3500:      	fmul.4s	v28, v22, v28
    3504:      	fadd.4s	v28, v28, v10
    3508:      	fadd.4s	v27, v27, v10
    350c:      	fmul.4s	v27, v6, v27
    3510:      	fmul.4s	v28, v22, v28
    3514:      	movi.4s	v29, #0x3f, lsl #24
    3518:      	fadd.4s	v28, v28, v29
    351c:      	fadd.4s	v27, v27, v29
    3520:      	fmul.4s	v29, v6, v6
    3524:      	fmul.4s	v27, v29, v27
    3528:      	fmul.4s	v29, v22, v22
    352c:      	fmul.4s	v28, v29, v28
    3530:      	fadd.4s	v22, v22, v28
    3534:      	fadd.4s	v6, v6, v27
    3538:      	fadd.4s	v6, v6, v11
    353c:      	fadd.4s	v22, v22, v11
    3540:      	sshr.4s	v27, v26, #0x1
    3544:      	sshr.4s	v28, v25, #0x1
    3548:      	shl.4s	v29, v28, #0x17
    354c:      	add.4s	v29, v29, v11
    3550:      	fmul.4s	v22, v22, v29
    3554:      	shl.4s	v29, v27, #0x17
    3558:      	add.4s	v29, v29, v11
    355c:      	fmul.4s	v6, v6, v29
    3560:      	sub.4s	v25, v25, v28
    3564:      	sub.4s	v26, v26, v27
    3568:      	shl.4s	v26, v26, #0x17
    356c:      	add.4s	v26, v26, v11
    3570:      	fmul.4s	v6, v6, v26
    3574:      	shl.4s	v25, v25, #0x17
    3578:      	add.4s	v25, v25, v11
    357c:      	fmul.4s	v22, v22, v25
    3580:      	fcmgt.4s	v25, v23, v5
    3584:      	bic.16b	v22, v22, v25
    3588:      	fcmgt.4s	v25, v23, v4
    358c:      	bic.16b	v6, v6, v25
    3590:      	fcmgt.4s	v25, v4, v24
    3594:      	ldr	q26, [sp, #0x170]
    3598:      	bit.16b	v6, v26, v25
    359c:      	fcmgt.4s	v25, v5, v24
    35a0:      	bit.16b	v22, v26, v25
    35a4:      	fcmeq.4s	v5, v5, v5
    35a8:      	ldr	q25, [sp, #0x160]
    35ac:      	bsl.16b	v5, v22, v25
    35b0:      	cmeq.8b	v22, v9, #0
    35b4:      	sshll.8h	v22, v22, #0x0
    35b8:      	fcmeq.4s	v4, v4, v4
    35bc:      	bsl.16b	v4, v6, v25
    35c0:      	sshll2.4s	v6, v22, #0x0
    35c4:      	sshll.4s	v22, v22, #0x0
    35c8:      	bic.16b	v4, v4, v22
    35cc:      	bic.16b	v5, v5, v6
    35d0:      	ldp	q6, q22, [x8]
    35d4:      	bit.16b	v22, v5, v0
    35d8:      	bit.16b	v6, v4, v1
    35dc:      	stp	q6, q22, [x8], #0x80
    35e0:      	bit.16b	v16, v15, v0
    35e4:      	bit.16b	v7, v14, v1
    35e8:      	bit.16b	v12, v2, v0
    35ec:      	bit.16b	v21, v19, v1
    35f0:      	bit.16b	v17, v3, v0
    35f4:      	bit.16b	v13, v8, v1
    35f8:      	fadd.4s	v2, v20, v5
    35fc:      	bit.16b	v20, v2, v0
    3600:      	fadd.4s	v2, v18, v4
    3604:      	bit.16b	v18, v2, v1
    3608:      	add	x9, x9, #0x80
    360c:      	sub	x2, x1, #0x3
    3610:      	add	x1, x1, #0x1
    3614:      	cmp	x2, #0x5c
    3618:      	ldr	q25, [sp, #0x180]
    361c:      	b.hs	0x3e88 <_llm_rows.packet_batch.blocks+0x27ec>
    3620:      	fmov	w2, s25
    3624:      	dup.2d	v2, x1
    3628:      	ldr	q3, [sp, #0x1c0]
    362c:      	add.2d	v3, v3, v2
    3630:      	tbz	w2, #0x0, 0x3654 <_llm_rows.packet_batch.blocks+0x1fb8>
    3634:      	fmov	x19, d3
    3638:      	ldr	b19, [x19]
    363c:      	movi.4s	v28, #0x4b, lsl #24
    3640:      	mvni.4s	v29, #0x80, lsl #24
    3644:      	ldr	q27, [sp, #0x100]
    3648:      	and	w2, w2, #0xff
    364c:      	tbnz	w2, #0x1, 0x366c <_llm_rows.packet_batch.blocks+0x1fd0>
    3650:      	b	0x3674 <_llm_rows.packet_batch.blocks+0x1fd8>
    3654:      	movi.2d	v19, #0000000000000000
    3658:      	movi.4s	v28, #0x4b, lsl #24
    365c:      	mvni.4s	v29, #0x80, lsl #24
    3660:      	ldr	q27, [sp, #0x100]
    3664:      	and	w2, w2, #0xff
    3668:      	tbz	w2, #0x1, 0x3674 <_llm_rows.packet_batch.blocks+0x1fd8>
    366c:      	mov.d	x19, v3[1]
    3670:      	ld1.b	{ v19 }[1], [x19]
    3674:      	ldr	q3, [sp, #0x1b0]
    3678:      	add.2d	v3, v3, v2
    367c:      	tbnz	w2, #0x2, 0x3888 <_llm_rows.packet_batch.blocks+0x21ec>
    3680:      	tbnz	w2, #0x3, 0x3894 <_llm_rows.packet_batch.blocks+0x21f8>
    3684:      	ldr	q3, [sp, #0x1a0]
    3688:      	add.2d	v3, v3, v2
    368c:      	tbnz	w2, #0x4, 0x38a8 <_llm_rows.packet_batch.blocks+0x220c>
    3690:      	tbnz	w2, #0x5, 0x38b4 <_llm_rows.packet_batch.blocks+0x2218>
    3694:      	ldr	q3, [sp, #0x190]
    3698:      	add.2d	v2, v3, v2
    369c:      	tbnz	w2, #0x6, 0x38c8 <_llm_rows.packet_batch.blocks+0x222c>
    36a0:      	tbz	w2, #0x7, 0x36ac <_llm_rows.packet_batch.blocks+0x2010>
    36a4:      	mov.d	x2, v2[1]
    36a8:      	ld1.b	{ v19 }[7], [x2]
    36ac:      	ldp	q3, q2, [x9, #-0x60]
    36b0:      	fsub.4s	v4, v3, v27
    36b4:      	fsub.4s	v2, v2, v27
    36b8:      	and.16b	v3, v0, v2
    36bc:      	and.16b	v2, v1, v4
    36c0:      	fcmge.4s	v4, v2, v23
    36c4:      	fcmge.4s	v5, v3, v23
    36c8:      	fcmge.4s	v8, v24, v2
    36cc:      	fcmge.4s	v9, v24, v3
    36d0:      	and.16b	v5, v5, v9
    36d4:      	and.16b	v4, v4, v8
    36d8:      	and.16b	v4, v4, v2
    36dc:      	and.16b	v5, v5, v3
    36e0:      	ldp	q22, q6, [sp, #0x140]
    36e4:      	fmul.4s	v8, v5, v6
    36e8:      	fmul.4s	v9, v4, v6
    36ec:      	mov.16b	v14, v29
    36f0:      	bsl.16b	v14, v28, v9
    36f4:      	mov.16b	v15, v29
    36f8:      	bsl.16b	v15, v28, v8
    36fc:      	fadd.4s	v8, v8, v15
    3700:      	fadd.4s	v9, v9, v14
    3704:      	fsub.4s	v9, v9, v14
    3708:      	fsub.4s	v8, v8, v15
    370c:      	fcvtzs.4s	v8, v8
    3710:      	fcvtzs.4s	v9, v9
    3714:      	scvtf.4s	v14, v9
    3718:      	scvtf.4s	v15, v8
    371c:      	fmul.4s	v6, v14, v22
    3720:      	fadd.4s	v4, v4, v6
    3724:      	fmul.4s	v6, v15, v22
    3728:      	fadd.4s	v5, v5, v6
    372c:      	fmul.4s	v6, v14, v30
    3730:      	fmul.4s	v14, v15, v30
    3734:      	fadd.4s	v5, v5, v14
    3738:      	fadd.4s	v4, v4, v6
    373c:      	ldp	q22, q25, [sp, #0x120]
    3740:      	fmul.4s	v6, v4, v25
    3744:      	fmul.4s	v14, v5, v25
    3748:      	fadd.4s	v14, v14, v22
    374c:      	fadd.4s	v6, v6, v22
    3750:      	fmul.4s	v6, v4, v6
    3754:      	fmul.4s	v14, v5, v14
    3758:      	ldr	q22, [sp, #0x110]
    375c:      	fadd.4s	v14, v14, v22
    3760:      	fadd.4s	v6, v6, v22
    3764:      	fmul.4s	v6, v4, v6
    3768:      	fmul.4s	v14, v5, v14
    376c:      	fadd.4s	v14, v14, v31
    3770:      	fadd.4s	v6, v6, v31
    3774:      	fmul.4s	v6, v4, v6
    3778:      	fmul.4s	v14, v5, v14
    377c:      	fadd.4s	v14, v14, v10
    3780:      	fadd.4s	v6, v6, v10
    3784:      	fmul.4s	v6, v4, v6
    3788:      	fmul.4s	v14, v5, v14
    378c:      	movi.4s	v22, #0x3f, lsl #24
    3790:      	fadd.4s	v14, v14, v22
    3794:      	fadd.4s	v6, v6, v22
    3798:      	fmul.4s	v15, v4, v4
    379c:      	fmul.4s	v6, v15, v6
    37a0:      	fmul.4s	v15, v5, v5
    37a4:      	fmul.4s	v14, v15, v14
    37a8:      	fadd.4s	v5, v5, v14
    37ac:      	fadd.4s	v4, v4, v6
    37b0:      	fadd.4s	v4, v4, v11
    37b4:      	fadd.4s	v5, v5, v11
    37b8:      	sshr.4s	v6, v9, #0x1
    37bc:      	sshr.4s	v14, v8, #0x1
    37c0:      	shl.4s	v15, v14, #0x17
    37c4:      	add.4s	v15, v15, v11
    37c8:      	fmul.4s	v5, v5, v15
    37cc:      	shl.4s	v15, v6, #0x17
    37d0:      	add.4s	v15, v15, v11
    37d4:      	fmul.4s	v4, v4, v15
    37d8:      	sub.4s	v8, v8, v14
    37dc:      	sub.4s	v6, v9, v6
    37e0:      	shl.4s	v6, v6, #0x17
    37e4:      	add.4s	v6, v6, v11
    37e8:      	fmul.4s	v4, v4, v6
    37ec:      	shl.4s	v6, v8, #0x17
    37f0:      	add.4s	v6, v6, v11
    37f4:      	fmul.4s	v5, v5, v6
    37f8:      	fcmgt.4s	v6, v23, v3
    37fc:      	bic.16b	v5, v5, v6
    3800:      	fcmgt.4s	v6, v23, v2
    3804:      	bic.16b	v4, v4, v6
    3808:      	fcmgt.4s	v6, v2, v24
    380c:      	ldr	q22, [sp, #0x170]
    3810:      	bit.16b	v4, v22, v6
    3814:      	fcmgt.4s	v6, v3, v24
    3818:      	bit.16b	v5, v22, v6
    381c:      	fcmeq.4s	v3, v3, v3
    3820:      	ldr	q6, [sp, #0x160]
    3824:      	bsl.16b	v3, v5, v6
    3828:      	ldr	q5, [sp, #0x180]
    382c:      	fmov	w2, s5
    3830:      	cmeq.8b	v5, v19, #0
    3834:      	sshll.8h	v5, v5, #0x0
    3838:      	fcmeq.4s	v2, v2, v2
    383c:      	bsl.16b	v2, v4, v6
    3840:      	sshll2.4s	v4, v5, #0x0
    3844:      	sshll.4s	v5, v5, #0x0
    3848:      	bic.16b	v14, v2, v5
    384c:      	bic.16b	v15, v3, v4
    3850:      	ldp	q2, q3, [x8, #-0x60]
    3854:      	bit.16b	v3, v15, v0
    3858:      	bit.16b	v2, v14, v1
    385c:      	stp	q2, q3, [x8, #-0x60]
    3860:      	add	x1, x1, #0x1
    3864:      	dup.2d	v2, x1
    3868:      	ldr	q3, [sp, #0x1c0]
    386c:      	add.2d	v3, v3, v2
    3870:      	tbz	w2, #0x0, 0x38d8 <_llm_rows.packet_batch.blocks+0x223c>
    3874:      	fmov	x19, d3
    3878:      	ldr	b19, [x19]
    387c:      	and	w2, w2, #0xff
    3880:      	tbnz	w2, #0x1, 0x38e4 <_llm_rows.packet_batch.blocks+0x2248>
    3884:      	b	0x38ec <_llm_rows.packet_batch.blocks+0x2250>
    3888:      	fmov	x19, d3
    388c:      	ld1.b	{ v19 }[2], [x19]
    3890:      	tbz	w2, #0x3, 0x3684 <_llm_rows.packet_batch.blocks+0x1fe8>
    3894:      	mov.d	x19, v3[1]
    3898:      	ld1.b	{ v19 }[3], [x19]
    389c:      	ldr	q3, [sp, #0x1a0]
    38a0:      	add.2d	v3, v3, v2
    38a4:      	tbz	w2, #0x4, 0x3690 <_llm_rows.packet_batch.blocks+0x1ff4>
    38a8:      	fmov	x19, d3
    38ac:      	ld1.b	{ v19 }[4], [x19]
    38b0:      	tbz	w2, #0x5, 0x3694 <_llm_rows.packet_batch.blocks+0x1ff8>
    38b4:      	mov.d	x19, v3[1]
    38b8:      	ld1.b	{ v19 }[5], [x19]
    38bc:      	ldr	q3, [sp, #0x190]
    38c0:      	add.2d	v2, v3, v2
    38c4:      	tbz	w2, #0x6, 0x36a0 <_llm_rows.packet_batch.blocks+0x2004>
    38c8:      	fmov	x19, d2
    38cc:      	ld1.b	{ v19 }[6], [x19]
    38d0:      	tbnz	w2, #0x7, 0x36a4 <_llm_rows.packet_batch.blocks+0x2008>
    38d4:      	b	0x36ac <_llm_rows.packet_batch.blocks+0x2010>
    38d8:      	movi.2d	v19, #0000000000000000
    38dc:      	and	w2, w2, #0xff
    38e0:      	tbz	w2, #0x1, 0x38ec <_llm_rows.packet_batch.blocks+0x2250>
    38e4:      	mov.d	x19, v3[1]
    38e8:      	ld1.b	{ v19 }[1], [x19]
    38ec:      	ldr	q3, [sp, #0x1b0]
    38f0:      	add.2d	v3, v3, v2
    38f4:      	tbnz	w2, #0x2, 0x3b00 <_llm_rows.packet_batch.blocks+0x2464>
    38f8:      	tbnz	w2, #0x3, 0x3b0c <_llm_rows.packet_batch.blocks+0x2470>
    38fc:      	ldr	q3, [sp, #0x1a0]
    3900:      	add.2d	v3, v3, v2
    3904:      	tbnz	w2, #0x4, 0x3b20 <_llm_rows.packet_batch.blocks+0x2484>
    3908:      	tbnz	w2, #0x5, 0x3b2c <_llm_rows.packet_batch.blocks+0x2490>
    390c:      	ldr	q3, [sp, #0x190]
    3910:      	add.2d	v2, v3, v2
    3914:      	tbnz	w2, #0x6, 0x3b40 <_llm_rows.packet_batch.blocks+0x24a4>
    3918:      	tbz	w2, #0x7, 0x3924 <_llm_rows.packet_batch.blocks+0x2288>
    391c:      	mov.d	x2, v2[1]
    3920:      	ld1.b	{ v19 }[7], [x2]
    3924:      	ldp	q3, q2, [x9, #-0x40]
    3928:      	fsub.4s	v4, v3, v27
    392c:      	fsub.4s	v2, v2, v27
    3930:      	and.16b	v3, v0, v2
    3934:      	and.16b	v2, v1, v4
    3938:      	fcmge.4s	v4, v2, v23
    393c:      	fcmge.4s	v5, v3, v23
    3940:      	fcmge.4s	v6, v24, v2
    3944:      	fcmge.4s	v8, v24, v3
    3948:      	and.16b	v5, v5, v8
    394c:      	and.16b	v4, v4, v6
    3950:      	and.16b	v4, v4, v2
    3954:      	and.16b	v5, v5, v3
    3958:      	ldp	q26, q22, [sp, #0x140]
    395c:      	fmul.4s	v6, v5, v22
    3960:      	fmul.4s	v8, v4, v22
    3964:      	mov.16b	v9, v29
    3968:      	bsl.16b	v9, v28, v8
    396c:      	mov.16b	v22, v29
    3970:      	bsl.16b	v22, v28, v6
    3974:      	fadd.4s	v6, v6, v22
    3978:      	fadd.4s	v8, v8, v9
    397c:      	fsub.4s	v8, v8, v9
    3980:      	fsub.4s	v6, v6, v22
    3984:      	fcvtzs.4s	v6, v6
    3988:      	fcvtzs.4s	v22, v8
    398c:      	scvtf.4s	v8, v22
    3990:      	scvtf.4s	v9, v6
    3994:      	fmul.4s	v25, v8, v26
    3998:      	fadd.4s	v4, v4, v25
    399c:      	fmul.4s	v25, v9, v26
    39a0:      	fadd.4s	v5, v5, v25
    39a4:      	fmul.4s	v25, v8, v30
    39a8:      	fmul.4s	v8, v9, v30
    39ac:      	fadd.4s	v5, v5, v8
    39b0:      	fadd.4s	v4, v4, v25
    39b4:      	ldp	q26, q30, [sp, #0x120]
    39b8:      	fmul.4s	v25, v4, v30
    39bc:      	fmul.4s	v8, v5, v30
    39c0:      	fadd.4s	v8, v8, v26
    39c4:      	fadd.4s	v25, v25, v26
    39c8:      	fmul.4s	v25, v4, v25
    39cc:      	fmul.4s	v8, v5, v8
    39d0:      	ldr	q26, [sp, #0x110]
    39d4:      	fadd.4s	v8, v8, v26
    39d8:      	fadd.4s	v25, v25, v26
    39dc:      	fmul.4s	v25, v4, v25
    39e0:      	fmul.4s	v8, v5, v8
    39e4:      	fadd.4s	v8, v8, v31
    39e8:      	fadd.4s	v25, v25, v31
    39ec:      	fmul.4s	v25, v4, v25
    39f0:      	fmul.4s	v8, v5, v8
    39f4:      	fadd.4s	v8, v8, v10
    39f8:      	fadd.4s	v25, v25, v10
    39fc:      	fmul.4s	v25, v4, v25
    3a00:      	fmul.4s	v8, v5, v8
    3a04:      	movi.4s	v26, #0x3f, lsl #24
    3a08:      	fadd.4s	v8, v8, v26
    3a0c:      	fadd.4s	v25, v25, v26
    3a10:      	fmul.4s	v9, v4, v4
    3a14:      	fmul.4s	v25, v9, v25
    3a18:      	fmul.4s	v9, v5, v5
    3a1c:      	fmul.4s	v8, v9, v8
    3a20:      	fadd.4s	v5, v5, v8
    3a24:      	fadd.4s	v4, v4, v25
    3a28:      	fadd.4s	v4, v4, v11
    3a2c:      	fadd.4s	v5, v5, v11
    3a30:      	sshr.4s	v25, v22, #0x1
    3a34:      	sshr.4s	v8, v6, #0x1
    3a38:      	shl.4s	v9, v8, #0x17
    3a3c:      	add.4s	v9, v9, v11
    3a40:      	fmul.4s	v5, v5, v9
    3a44:      	shl.4s	v9, v25, #0x17
    3a48:      	add.4s	v9, v9, v11
    3a4c:      	fmul.4s	v4, v4, v9
    3a50:      	sub.4s	v6, v6, v8
    3a54:      	sub.4s	v22, v22, v25
    3a58:      	shl.4s	v22, v22, #0x17
    3a5c:      	add.4s	v22, v22, v11
    3a60:      	fmul.4s	v4, v4, v22
    3a64:      	shl.4s	v6, v6, #0x17
    3a68:      	add.4s	v6, v6, v11
    3a6c:      	fmul.4s	v5, v5, v6
    3a70:      	fcmgt.4s	v6, v23, v3
    3a74:      	bic.16b	v5, v5, v6
    3a78:      	fcmgt.4s	v6, v23, v2
    3a7c:      	bic.16b	v4, v4, v6
    3a80:      	fcmgt.4s	v6, v2, v24
    3a84:      	ldr	q22, [sp, #0x170]
    3a88:      	bit.16b	v4, v22, v6
    3a8c:      	fcmgt.4s	v6, v3, v24
    3a90:      	bit.16b	v5, v22, v6
    3a94:      	fcmeq.4s	v3, v3, v3
    3a98:      	ldr	q6, [sp, #0x160]
    3a9c:      	bsl.16b	v3, v5, v6
    3aa0:      	ldr	q5, [sp, #0x180]
    3aa4:      	fmov	w2, s5
    3aa8:      	cmeq.8b	v5, v19, #0
    3aac:      	sshll.8h	v5, v5, #0x0
    3ab0:      	fcmeq.4s	v2, v2, v2
    3ab4:      	bsl.16b	v2, v4, v6
    3ab8:      	sshll2.4s	v4, v5, #0x0
    3abc:      	sshll.4s	v5, v5, #0x0
    3ac0:      	bic.16b	v8, v2, v5
    3ac4:      	bic.16b	v19, v3, v4
    3ac8:      	ldp	q2, q3, [x8, #-0x40]
    3acc:      	bit.16b	v3, v19, v0
    3ad0:      	bit.16b	v2, v8, v1
    3ad4:      	stp	q2, q3, [x8, #-0x40]
    3ad8:      	add	x1, x1, #0x1
    3adc:      	dup.2d	v2, x1
    3ae0:      	ldr	q3, [sp, #0x1c0]
    3ae4:      	add.2d	v3, v3, v2
    3ae8:      	tbz	w2, #0x0, 0x3b50 <_llm_rows.packet_batch.blocks+0x24b4>
    3aec:      	fmov	x19, d3
    3af0:      	ldr	b9, [x19]
    3af4:      	and	w2, w2, #0xff
    3af8:      	tbnz	w2, #0x1, 0x3b5c <_llm_rows.packet_batch.blocks+0x24c0>
    3afc:      	b	0x3b64 <_llm_rows.packet_batch.blocks+0x24c8>
    3b00:      	fmov	x19, d3
    3b04:      	ld1.b	{ v19 }[2], [x19]
    3b08:      	tbz	w2, #0x3, 0x38fc <_llm_rows.packet_batch.blocks+0x2260>
    3b0c:      	mov.d	x19, v3[1]
    3b10:      	ld1.b	{ v19 }[3], [x19]
    3b14:      	ldr	q3, [sp, #0x1a0]
    3b18:      	add.2d	v3, v3, v2
    3b1c:      	tbz	w2, #0x4, 0x3908 <_llm_rows.packet_batch.blocks+0x226c>
    3b20:      	fmov	x19, d3
    3b24:      	ld1.b	{ v19 }[4], [x19]
    3b28:      	tbz	w2, #0x5, 0x390c <_llm_rows.packet_batch.blocks+0x2270>
    3b2c:      	mov.d	x19, v3[1]
    3b30:      	ld1.b	{ v19 }[5], [x19]
    3b34:      	ldr	q3, [sp, #0x190]
    3b38:      	add.2d	v2, v3, v2
    3b3c:      	tbz	w2, #0x6, 0x3918 <_llm_rows.packet_batch.blocks+0x227c>
    3b40:      	fmov	x19, d2
    3b44:      	ld1.b	{ v19 }[6], [x19]
    3b48:      	tbnz	w2, #0x7, 0x391c <_llm_rows.packet_batch.blocks+0x2280>
    3b4c:      	b	0x3924 <_llm_rows.packet_batch.blocks+0x2288>
    3b50:      	movi.2d	v9, #0000000000000000
    3b54:      	and	w2, w2, #0xff
    3b58:      	tbz	w2, #0x1, 0x3b64 <_llm_rows.packet_batch.blocks+0x24c8>
    3b5c:      	mov.d	x19, v3[1]
    3b60:      	ld1.b	{ v9 }[1], [x19]
    3b64:      	ldr	q3, [sp, #0x1b0]
    3b68:      	add.2d	v3, v3, v2
    3b6c:      	tbnz	w2, #0x2, 0x3d80 <_llm_rows.packet_batch.blocks+0x26e4>
    3b70:      	tbnz	w2, #0x3, 0x3d8c <_llm_rows.packet_batch.blocks+0x26f0>
    3b74:      	ldr	q3, [sp, #0x1a0]
    3b78:      	add.2d	v3, v3, v2
    3b7c:      	tbnz	w2, #0x4, 0x3da0 <_llm_rows.packet_batch.blocks+0x2704>
    3b80:      	tbnz	w2, #0x5, 0x3dac <_llm_rows.packet_batch.blocks+0x2710>
    3b84:      	ldr	q3, [sp, #0x190]
    3b88:      	add.2d	v2, v3, v2
    3b8c:      	tbnz	w2, #0x6, 0x3dc0 <_llm_rows.packet_batch.blocks+0x2724>
    3b90:      	tbz	w2, #0x7, 0x3b9c <_llm_rows.packet_batch.blocks+0x2500>
    3b94:      	mov.d	x2, v2[1]
    3b98:      	ld1.b	{ v9 }[7], [x2]
    3b9c:      	ldp	q3, q2, [x9, #-0x20]
    3ba0:      	fsub.4s	v4, v3, v27
    3ba4:      	fsub.4s	v2, v2, v27
    3ba8:      	and.16b	v3, v0, v2
    3bac:      	and.16b	v2, v1, v4
    3bb0:      	fcmge.4s	v4, v2, v23
    3bb4:      	fcmge.4s	v5, v3, v23
    3bb8:      	fcmge.4s	v6, v24, v2
    3bbc:      	fcmge.4s	v22, v24, v3
    3bc0:      	and.16b	v5, v5, v22
    3bc4:      	and.16b	v4, v4, v6
    3bc8:      	and.16b	v4, v4, v2
    3bcc:      	and.16b	v5, v5, v3
    3bd0:      	ldp	q30, q22, [sp, #0x140]
    3bd4:      	fmul.4s	v6, v5, v22
    3bd8:      	fmul.4s	v22, v4, v22
    3bdc:      	mov.16b	v25, v29
    3be0:      	bsl.16b	v25, v28, v22
    3be4:      	mov.16b	v26, v29
    3be8:      	bsl.16b	v26, v28, v6
    3bec:      	fadd.4s	v6, v6, v26
    3bf0:      	fadd.4s	v22, v22, v25
    3bf4:      	fsub.4s	v22, v22, v25
    3bf8:      	fsub.4s	v6, v6, v26
    3bfc:      	fcvtzs.4s	v6, v6
    3c00:      	fcvtzs.4s	v22, v22
    3c04:      	scvtf.4s	v25, v22
    3c08:      	scvtf.4s	v26, v6
    3c0c:      	fmul.4s	v27, v25, v30
    3c10:      	fadd.4s	v4, v4, v27
    3c14:      	fmul.4s	v27, v26, v30
    3c18:      	fadd.4s	v5, v5, v27
    3c1c:      	ldr	q27, [sp, #0xf0]
    3c20:      	fmul.4s	v25, v25, v27
    3c24:      	fmul.4s	v26, v26, v27
    3c28:      	fadd.4s	v5, v5, v26
    3c2c:      	fadd.4s	v4, v4, v25
    3c30:      	ldp	q27, q26, [sp, #0x120]
    3c34:      	fmul.4s	v25, v4, v26
    3c38:      	fmul.4s	v26, v5, v26
    3c3c:      	fadd.4s	v26, v26, v27
    3c40:      	fadd.4s	v25, v25, v27
    3c44:      	fmul.4s	v25, v4, v25
    3c48:      	fmul.4s	v26, v5, v26
    3c4c:      	ldr	q27, [sp, #0x110]
    3c50:      	fadd.4s	v26, v26, v27
    3c54:      	fadd.4s	v25, v25, v27
    3c58:      	fmul.4s	v25, v4, v25
    3c5c:      	fmul.4s	v26, v5, v26
    3c60:      	fadd.4s	v26, v26, v31
    3c64:      	fadd.4s	v25, v25, v31
    3c68:      	fmul.4s	v25, v4, v25
    3c6c:      	fmul.4s	v26, v5, v26
    3c70:      	fadd.4s	v26, v26, v10
    3c74:      	fadd.4s	v25, v25, v10
    3c78:      	fmul.4s	v25, v4, v25
    3c7c:      	fmul.4s	v26, v5, v26
    3c80:      	movi.4s	v27, #0x3f, lsl #24
    3c84:      	fadd.4s	v26, v26, v27
    3c88:      	fadd.4s	v25, v25, v27
    3c8c:      	fmul.4s	v27, v4, v4
    3c90:      	fmul.4s	v25, v27, v25
    3c94:      	fmul.4s	v27, v5, v5
    3c98:      	fmul.4s	v26, v27, v26
    3c9c:      	fadd.4s	v5, v5, v26
    3ca0:      	fadd.4s	v4, v4, v25
    3ca4:      	fadd.4s	v4, v4, v11
    3ca8:      	fadd.4s	v5, v5, v11
    3cac:      	sshr.4s	v25, v22, #0x1
    3cb0:      	sshr.4s	v26, v6, #0x1
    3cb4:      	shl.4s	v27, v26, #0x17
    3cb8:      	add.4s	v27, v27, v11
    3cbc:      	fmul.4s	v5, v5, v27
    3cc0:      	shl.4s	v27, v25, #0x17
    3cc4:      	add.4s	v27, v27, v11
    3cc8:      	fmul.4s	v4, v4, v27
    3ccc:      	sub.4s	v6, v6, v26
    3cd0:      	sub.4s	v22, v22, v25
    3cd4:      	shl.4s	v22, v22, #0x17
    3cd8:      	add.4s	v22, v22, v11
    3cdc:      	fmul.4s	v4, v4, v22
    3ce0:      	shl.4s	v6, v6, #0x17
    3ce4:      	add.4s	v6, v6, v11
    3ce8:      	fmul.4s	v5, v5, v6
    3cec:      	fcmgt.4s	v6, v23, v3
    3cf0:      	bic.16b	v5, v5, v6
    3cf4:      	fcmgt.4s	v6, v23, v2
    3cf8:      	bic.16b	v4, v4, v6
    3cfc:      	fcmgt.4s	v6, v2, v24
    3d00:      	ldr	q22, [sp, #0x170]
    3d04:      	bit.16b	v4, v22, v6
    3d08:      	fcmgt.4s	v6, v3, v24
    3d0c:      	bit.16b	v5, v22, v6
    3d10:      	fcmeq.4s	v3, v3, v3
    3d14:      	ldr	q6, [sp, #0x160]
    3d18:      	bsl.16b	v3, v5, v6
    3d1c:      	ldr	q5, [sp, #0x180]
    3d20:      	fmov	w2, s5
    3d24:      	cmeq.8b	v5, v9, #0
    3d28:      	sshll.8h	v5, v5, #0x0
    3d2c:      	fcmeq.4s	v2, v2, v2
    3d30:      	bsl.16b	v2, v4, v6
    3d34:      	sshll2.4s	v6, v5, #0x0
    3d38:      	sshll.4s	v4, v5, #0x0
    3d3c:      	bic.16b	v4, v2, v4
    3d40:      	bic.16b	v3, v3, v6
    3d44:      	ldp	q2, q5, [x8, #-0x20]
    3d48:      	bit.16b	v5, v3, v0
    3d4c:      	bit.16b	v2, v4, v1
    3d50:      	stp	q2, q5, [x8, #-0x20]
    3d54:      	add	x1, x1, #0x1
    3d58:      	dup.2d	v2, x1
    3d5c:      	ldr	q5, [sp, #0x1c0]
    3d60:      	add.2d	v5, v5, v2
    3d64:      	tbz	w2, #0x0, 0x3dd0 <_llm_rows.packet_batch.blocks+0x2734>
    3d68:      	fmov	x19, d5
    3d6c:      	ldr	b9, [x19]
    3d70:      	and	w2, w2, #0xff
    3d74:      	ldr	q22, [sp, #0x100]
    3d78:      	tbnz	w2, #0x1, 0x3de0 <_llm_rows.packet_batch.blocks+0x2744>
    3d7c:      	b	0x3de8 <_llm_rows.packet_batch.blocks+0x274c>
    3d80:      	fmov	x19, d3
    3d84:      	ld1.b	{ v9 }[2], [x19]
    3d88:      	tbz	w2, #0x3, 0x3b74 <_llm_rows.packet_batch.blocks+0x24d8>
    3d8c:      	mov.d	x19, v3[1]
    3d90:      	ld1.b	{ v9 }[3], [x19]
    3d94:      	ldr	q3, [sp, #0x1a0]
    3d98:      	add.2d	v3, v3, v2
    3d9c:      	tbz	w2, #0x4, 0x3b80 <_llm_rows.packet_batch.blocks+0x24e4>
    3da0:      	fmov	x19, d3
    3da4:      	ld1.b	{ v9 }[4], [x19]
    3da8:      	tbz	w2, #0x5, 0x3b84 <_llm_rows.packet_batch.blocks+0x24e8>
    3dac:      	mov.d	x19, v3[1]
    3db0:      	ld1.b	{ v9 }[5], [x19]
    3db4:      	ldr	q3, [sp, #0x190]
    3db8:      	add.2d	v2, v3, v2
    3dbc:      	tbz	w2, #0x6, 0x3b90 <_llm_rows.packet_batch.blocks+0x24f4>
    3dc0:      	fmov	x19, d2
    3dc4:      	ld1.b	{ v9 }[6], [x19]
    3dc8:      	tbnz	w2, #0x7, 0x3b94 <_llm_rows.packet_batch.blocks+0x24f8>
    3dcc:      	b	0x3b9c <_llm_rows.packet_batch.blocks+0x2500>
    3dd0:      	movi.2d	v9, #0000000000000000
    3dd4:      	and	w2, w2, #0xff
    3dd8:      	ldr	q22, [sp, #0x100]
    3ddc:      	tbz	w2, #0x1, 0x3de8 <_llm_rows.packet_batch.blocks+0x274c>
    3de0:      	mov.d	x19, v5[1]
    3de4:      	ld1.b	{ v9 }[1], [x19]
    3de8:      	ldr	q5, [sp, #0x1b0]
    3dec:      	add.2d	v5, v5, v2
    3df0:      	tbnz	w2, #0x2, 0x3e44 <_llm_rows.packet_batch.blocks+0x27a8>
    3df4:      	tbnz	w2, #0x3, 0x3e50 <_llm_rows.packet_batch.blocks+0x27b4>
    3df8:      	ldr	q5, [sp, #0x1a0]
    3dfc:      	add.2d	v5, v5, v2
    3e00:      	tbnz	w2, #0x4, 0x3e64 <_llm_rows.packet_batch.blocks+0x27c8>
    3e04:      	tbnz	w2, #0x5, 0x3e70 <_llm_rows.packet_batch.blocks+0x27d4>
    3e08:      	ldr	q5, [sp, #0x190]
    3e0c:      	add.2d	v5, v5, v2
    3e10:      	tbz	w2, #0x6, 0x3e1c <_llm_rows.packet_batch.blocks+0x2780>
    3e14:      	fmov	x19, d5
    3e18:      	ld1.b	{ v9 }[6], [x19]
    3e1c:      	fadd.4s	v15, v16, v15
    3e20:      	fadd.4s	v14, v7, v14
    3e24:      	fadd.4s	v2, v12, v19
    3e28:      	fadd.4s	v19, v21, v8
    3e2c:      	fadd.4s	v3, v17, v3
    3e30:      	fadd.4s	v8, v13, v4
    3e34:      	tbz	w2, #0x7, 0x3434 <_llm_rows.packet_batch.blocks+0x1d98>
    3e38:      	mov.d	x2, v5[1]
    3e3c:      	ld1.b	{ v9 }[7], [x2]
    3e40:      	b	0x3434 <_llm_rows.packet_batch.blocks+0x1d98>
    3e44:      	fmov	x19, d5
    3e48:      	ld1.b	{ v9 }[2], [x19]
    3e4c:      	tbz	w2, #0x3, 0x3df8 <_llm_rows.packet_batch.blocks+0x275c>
    3e50:      	mov.d	x19, v5[1]
    3e54:      	ld1.b	{ v9 }[3], [x19]
    3e58:      	ldr	q5, [sp, #0x1a0]
    3e5c:      	add.2d	v5, v5, v2
    3e60:      	tbz	w2, #0x4, 0x3e04 <_llm_rows.packet_batch.blocks+0x2768>
    3e64:      	fmov	x19, d5
    3e68:      	ld1.b	{ v9 }[4], [x19]
    3e6c:      	tbz	w2, #0x5, 0x3e08 <_llm_rows.packet_batch.blocks+0x276c>
    3e70:      	mov.d	x19, v5[1]
    3e74:      	ld1.b	{ v9 }[5], [x19]
    3e78:      	ldr	q5, [sp, #0x190]
    3e7c:      	add.2d	v5, v5, v2
    3e80:      	tbnz	w2, #0x6, 0x3e14 <_llm_rows.packet_batch.blocks+0x2778>
    3e84:      	b	0x3e1c <_llm_rows.packet_batch.blocks+0x2780>
    3e88:      	mov	x8, #0x0                ; =0
    3e8c:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1964>
    3e90:      	ldr	q2, [x9]
    3e94:      	and.16b	v6, v0, v2
    3e98:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1964>
    3e9c:      	ldr	q2, [x9]
    3ea0:      	and.16b	v19, v1, v2
    3ea4:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1964>
    3ea8:      	ldr	q2, [x9]
    3eac:      	and.16b	v3, v1, v2
    3eb0:      	fadd.4s	v2, v16, v12
    3eb4:      	fadd.4s	v4, v7, v21
    3eb8:      	fadd.4s	v4, v4, v13
    3ebc:      	fadd.4s	v2, v2, v17
    3ec0:      	fadd.4s	v2, v2, v20
    3ec4:      	fadd.4s	v4, v4, v18
    3ec8:      	fmov	w9, s19
    3ecc:      	add	x1, sp, #0x1d8
    3ed0:      	bfxil	x1, x9, #0, #3
    3ed4:      	ldr	q5, [sp, #0x90]
    3ed8:      	str	d5, [sp, #0x1d8]
    3edc:      	ldrb	w1, [x1]
    3ee0:      	add	x2, sp, #0x400
    3ee4:      	orr	x9, x2, x9, lsl #2
    3ee8:      	stp	q4, q2, [x23, #0x1a0]
    3eec:      	ldr	s5, [x9]
    3ef0:      	tst	w0, w1
    3ef4:      	movi	d21, #0000000000000000
    3ef8:      	fcsel	s5, s5, s21, ne
    3efc:      	mov.s	w9, v19[1]
    3f00:      	add	x1, sp, #0x1d8
    3f04:      	bfxil	x1, x9, #0, #3
    3f08:      	ldrb	w9, [x1]
    3f0c:      	and	w9, w11, w9
    3f10:      	str	q4, [x23, #0x180]
    3f14:      	ldr	s7, [x23, #0x180]
    3f18:      	tst	w9, #0x1
    3f1c:      	fcsel	s7, s7, s21, ne
    3f20:      	mov.s	w9, v19[2]
    3f24:      	add	x1, sp, #0x1d8
    3f28:      	bfxil	x1, x9, #0, #3
    3f2c:      	add	x2, sp, #0x3c0
    3f30:      	orr	x9, x2, x9, lsl #2
    3f34:      	ldrb	w1, [x1]
    3f38:      	and	w1, w12, w1
    3f3c:      	stp	q4, q2, [x23, #0x160]
    3f40:      	ldr	s16, [x9]
    3f44:      	tst	w1, #0x1
    3f48:      	fcsel	s16, s16, s21, ne
    3f4c:      	mov.s	w9, v19[3]
    3f50:      	add	x1, sp, #0x1d8
    3f54:      	bfxil	x1, x9, #0, #3
    3f58:      	add	x2, sp, #0x3a0
    3f5c:      	orr	x9, x2, x9, lsl #2
    3f60:      	ldrb	w1, [x1]
    3f64:      	and	w1, w13, w1
    3f68:      	stp	q4, q2, [x23, #0x140]
    3f6c:      	ldr	s17, [x9]
    3f70:      	tst	w1, #0x1
    3f74:      	fcsel	s17, s17, s21, ne
    3f78:      	fmov	w9, s6
    3f7c:      	add	x1, sp, #0x1d8
    3f80:      	bfxil	x1, x9, #0, #3
    3f84:      	ldrb	w1, [x1]
    3f88:      	and	w1, w14, w1
    3f8c:      	stp	q4, q2, [x23, #0x120]
    3f90:      	add	x2, sp, #0x380
    3f94:      	ldr	s18, [x2, w9, uxtw #2]
    3f98:      	tst	w1, #0x1
    3f9c:      	mov.s	w9, v6[1]
    3fa0:      	fcsel	s18, s18, s21, ne
    3fa4:      	add	x1, sp, #0x1d8
    3fa8:      	bfxil	x1, x9, #0, #3
    3fac:      	ldrb	w1, [x1]
    3fb0:      	and	w1, w15, w1
    3fb4:      	stp	q4, q2, [x23, #0x100]
    3fb8:      	add	x2, sp, #0x360
    3fbc:      	ldr	s19, [x2, w9, uxtw #2]
    3fc0:      	tst	w1, #0x1
    3fc4:      	mov.s	w9, v6[2]
    3fc8:      	fcsel	s19, s19, s21, ne
    3fcc:      	add	x1, sp, #0x1d8
    3fd0:      	bfxil	x1, x9, #0, #3
    3fd4:      	ldrb	w1, [x1]
    3fd8:      	and	w1, w16, w1
    3fdc:      	stp	q4, q2, [x23, #0xe0]
    3fe0:      	add	x2, sp, #0x340
    3fe4:      	ldr	s20, [x2, w9, uxtw #2]
    3fe8:      	tst	w1, #0x1
    3fec:      	mov.s	w9, v6[3]
    3ff0:      	fcsel	s6, s20, s21, ne
    3ff4:      	add	x1, sp, #0x1d8
    3ff8:      	bfxil	x1, x9, #0, #3
    3ffc:      	ldrb	w1, [x1]
    4000:      	and	w1, w17, w1
    4004:      	stp	q4, q2, [x23, #0xc0]
    4008:      	add	x2, sp, #0x320
    400c:      	ldr	s20, [x2, w9, uxtw #2]
    4010:      	tst	w1, #0x1
    4014:      	mov.s	v5[1], v7[0]
    4018:      	mov.s	v5[2], v16[0]
    401c:      	mov.s	v5[3], v17[0]
    4020:      	mov.s	v18[1], v19[0]
    4024:      	fcsel	s7, s20, s21, ne
    4028:      	mov.s	v18[2], v6[0]
    402c:      	mov.s	v18[3], v7[0]
    4030:      	fadd.4s	v2, v2, v18
    4034:      	fadd.4s	v4, v4, v5
    4038:      	fmov	w9, s3
    403c:      	add	x1, sp, #0x1d8
    4040:      	bfxil	x1, x9, #0, #3
    4044:      	ldrb	w1, [x1]
    4048:      	add	x2, sp, #0x300
    404c:      	orr	x9, x2, x9, lsl #2
    4050:      	stp	q4, q2, [x23, #0xa0]
    4054:      	ldr	s5, [x9]
    4058:      	tst	w0, w1
    405c:      	mov.s	w9, v3[1]
    4060:      	add	x1, sp, #0x1d8
    4064:      	bfxil	x1, x9, #0, #3
    4068:      	ldrb	w1, [x1]
    406c:      	and	w11, w11, w1
    4070:      	fcsel	s5, s5, s21, ne
    4074:      	add	x1, sp, #0x2e0
    4078:      	orr	x9, x1, x9, lsl #2
    407c:      	stp	q4, q2, [x23, #0x80]
    4080:      	ldr	s6, [x9]
    4084:      	tst	w11, #0x1
    4088:      	mov.s	w9, v3[2]
    408c:      	add	x11, sp, #0x1d8
    4090:      	bfxil	x11, x9, #0, #3
    4094:      	adrp	x9, 0x4000 <_llm_rows.packet_batch.blocks+0x2964>
    4098:      	ldr	q7, [x9]
    409c:      	and.16b	v16, v0, v7
    40a0:      	fcsel	s6, s6, s21, ne
    40a4:      	ldrb	w9, [x11]
    40a8:      	and	w9, w12, w9
    40ac:      	str	q4, [x23, #0x60]
    40b0:      	ldr	s7, [x23, #0x60]
    40b4:      	tst	w9, #0x1
    40b8:      	mov.s	w9, v3[3]
    40bc:      	fcsel	s3, s7, s21, ne
    40c0:      	add	x11, sp, #0x1d8
    40c4:      	bfxil	x11, x9, #0, #3
    40c8:      	add	x12, sp, #0x2a0
    40cc:      	orr	x9, x12, x9, lsl #2
    40d0:      	ldrb	w11, [x11]
    40d4:      	and	w11, w13, w11
    40d8:      	stp	q4, q2, [x23, #0x40]
    40dc:      	ldr	s7, [x9]
    40e0:      	tst	w11, #0x1
    40e4:      	fcsel	s7, s7, s21, ne
    40e8:      	fmov	w9, s16
    40ec:      	add	x11, sp, #0x1d8
    40f0:      	bfxil	x11, x9, #0, #3
    40f4:      	ldrb	w11, [x11]
    40f8:      	and	w11, w14, w11
    40fc:      	stp	q4, q2, [x23, #0x20]
    4100:      	add	x12, sp, #0x280
    4104:      	ldr	s17, [x12, w9, uxtw #2]
    4108:      	tst	w11, #0x1
    410c:      	fcsel	s17, s17, s21, ne
    4110:      	mov.s	w9, v16[1]
    4114:      	add	x11, sp, #0x1d8
    4118:      	bfxil	x11, x9, #0, #3
    411c:      	ldrb	w11, [x11]
    4120:      	and	w11, w15, w11
    4124:      	stp	q4, q2, [x23]
    4128:      	ldr	s18, [x23, w9, uxtw #2]
    412c:      	tst	w11, #0x1
    4130:      	fcsel	s18, s18, s21, ne
    4134:      	mov.s	w9, v16[2]
    4138:      	add	x11, sp, #0x1d8
    413c:      	bfxil	x11, x9, #0, #3
    4140:      	ldrb	w11, [x11]
    4144:      	and	w11, w16, w11
    4148:      	stp	q4, q2, [sp, #0x240]
    414c:      	add	x12, sp, #0x240
    4150:      	ldr	s19, [x12, w9, uxtw #2]
    4154:      	tst	w11, #0x1
    4158:      	fcsel	s19, s19, s21, ne
    415c:      	mov.s	w9, v16[3]
    4160:      	add	x11, sp, #0x1d8
    4164:      	bfxil	x11, x9, #0, #3
    4168:      	ldrb	w11, [x11]
    416c:      	and	w11, w17, w11
    4170:      	stp	q4, q2, [sp, #0x220]
    4174:      	add	x12, sp, #0x220
    4178:      	ldr	s16, [x12, w9, uxtw #2]
    417c:      	tst	w11, #0x1
    4180:      	fcsel	s16, s16, s21, ne
    4184:      	mov.s	v17[1], v18[0]
    4188:      	mov.s	v17[2], v19[0]
    418c:      	mov.s	v17[3], v16[0]
    4190:      	mov.s	v5[1], v6[0]
    4194:      	movi.4s	v6, #0x4
    4198:      	and.16b	v6, v1, v6
    419c:      	mov.s	v5[2], v3[0]
    41a0:      	mov.s	v5[3], v7[0]
    41a4:      	fadd.4s	v3, v4, v5
    41a8:      	fadd.4s	v2, v2, v17
    41ac:      	fmov	w9, s6
    41b0:      	add	x11, sp, #0x1d8
    41b4:      	orr	x11, x11, x9
    41b8:      	ldrb	w11, [x11]
    41bc:      	stp	q3, q2, [sp, #0x200]
    41c0:      	add	x12, sp, #0x200
    41c4:      	ldr	s2, [x12, w9, uxtw #2]
    41c8:      	tst	w0, w11
    41cc:      	fcsel	s2, s2, s21, ne
    41d0:      	tst	w10, #0x1
    41d4:      	fadd	s2, s3, s2
    41d8:      	fcsel	s3, s2, s21, ne
    41dc:      	ldp	w9, w10, [sp, #0x88]
    41e0:      	tst	w10, #0x1
    41e4:      	fcsel	s4, s2, s21, ne
    41e8:      	tst	w9, #0x1
    41ec:      	fcsel	s5, s2, s21, ne
    41f0:      	tst	w3, #0x1
    41f4:      	fcsel	s6, s2, s21, ne
    41f8:      	tst	w4, #0x1
    41fc:      	fcsel	s7, s2, s21, ne
    4200:      	tst	w5, #0x1
    4204:      	fcsel	s16, s2, s21, ne
    4208:      	tst	w7, #0x1
    420c:      	fcsel	s17, s2, s21, ne
    4210:      	tst	w30, #0x1
    4214:      	mov.s	v3[1], v4[0]
    4218:      	mov.s	v3[2], v5[0]
    421c:      	mov.s	v3[3], v6[0]
    4220:      	mov.s	v7[1], v16[0]
    4224:      	mov.s	v7[2], v17[0]
    4228:      	fcsel	s2, s2, s21, ne
    422c:      	mov.s	v7[3], v2[0]
    4230:      	stp	q3, q7, [sp, #0x1e0]
    4234:      	and	x9, x6, #0x7
    4238:      	add	x10, sp, #0x1e0
    423c:      	ldr	s2, [x10, x9, lsl #2]
    4240:      	fadd	s2, s2, s21
    4244:      	ldp	x10, x9, [sp, #0xa0]
    4248:      	add	x9, x9, x10
    424c:      	dup.4s	v2, v2[0]
    4250:      	adrp	x15, 0x4000 <_llm_rows.packet_batch.blocks+0x2964>
    4254:      	adrp	x16, 0x4000 <_llm_rows.packet_batch.blocks+0x2964>
    4258:      	movi.8b	v8, #0x1
    425c:      	b	0x426c <_llm_rows.packet_batch.blocks+0x2bd0>
    4260:      	add	x8, x8, #0x20
    4264:      	cmp	x8, #0xc00
    4268:      	b.eq	0x1798 <_llm_rows.packet_batch.blocks+0xfc>
    426c:      	fmov	w11, s25
    4270:      	add	x10, x28, x8
    4274:      	ldp	q4, q3, [x10]
    4278:      	and.16b	v4, v1, v4
    427c:      	fdiv.4s	v4, v4, v2
    4280:      	add	x10, x9, x8
    4284:      	tbnz	w11, #0x0, 0x42b4 <_llm_rows.packet_batch.blocks+0x2c18>
    4288:      	and	w11, w11, #0xff
    428c:      	tbnz	w11, #0x1, 0x42c0 <_llm_rows.packet_batch.blocks+0x2c24>
    4290:      	tbnz	w11, #0x2, 0x42cc <_llm_rows.packet_batch.blocks+0x2c30>
    4294:      	tbnz	w11, #0x3, 0x42d8 <_llm_rows.packet_batch.blocks+0x2c3c>
    4298:      	and.16b	v3, v0, v3
    429c:      	fdiv.4s	v3, v3, v2
    42a0:      	tbnz	w11, #0x4, 0x42ec <_llm_rows.packet_batch.blocks+0x2c50>
    42a4:      	tbnz	w11, #0x5, 0x42f4 <_llm_rows.packet_batch.blocks+0x2c58>
    42a8:      	tbnz	w11, #0x6, 0x4300 <_llm_rows.packet_batch.blocks+0x2c64>
    42ac:      	tbz	w11, #0x7, 0x4260 <_llm_rows.packet_batch.blocks+0x2bc4>
    42b0:      	b	0x430c <_llm_rows.packet_batch.blocks+0x2c70>
    42b4:      	str	s4, [x10]
    42b8:      	and	w11, w11, #0xff
    42bc:      	tbz	w11, #0x1, 0x4290 <_llm_rows.packet_batch.blocks+0x2bf4>
    42c0:      	add	x12, x10, #0x4
    42c4:      	st1.s	{ v4 }[1], [x12]
    42c8:      	tbz	w11, #0x2, 0x4294 <_llm_rows.packet_batch.blocks+0x2bf8>
    42cc:      	add	x12, x10, #0x8
    42d0:      	st1.s	{ v4 }[2], [x12]
    42d4:      	tbz	w11, #0x3, 0x4298 <_llm_rows.packet_batch.blocks+0x2bfc>
    42d8:      	add	x12, x10, #0xc
    42dc:      	st1.s	{ v4 }[3], [x12]
    42e0:      	and.16b	v3, v0, v3
    42e4:      	fdiv.4s	v3, v3, v2
    42e8:      	tbz	w11, #0x4, 0x42a4 <_llm_rows.packet_batch.blocks+0x2c08>
    42ec:      	str	s3, [x10, #0x10]
    42f0:      	tbz	w11, #0x5, 0x42a8 <_llm_rows.packet_batch.blocks+0x2c0c>
    42f4:      	add	x12, x10, #0x14
    42f8:      	st1.s	{ v3 }[1], [x12]
    42fc:      	tbz	w11, #0x6, 0x42ac <_llm_rows.packet_batch.blocks+0x2c10>
    4300:      	add	x12, x10, #0x18
    4304:      	st1.s	{ v3 }[2], [x12]
    4308:      	tbz	w11, #0x7, 0x4260 <_llm_rows.packet_batch.blocks+0x2bc4>
    430c:      	add	x10, x10, #0x1c
    4310:      	st1.s	{ v3 }[3], [x10]
    4314:      	b	0x4260 <_llm_rows.packet_batch.blocks+0x2bc4>
    4318:      	fmov	x9, d2
    431c:      	ld1.b	{ v21 }[2], [x9]
    4320:      	tbz	w8, #0x3, 0x31f4 <_llm_rows.packet_batch.blocks+0x1b58>
    4324:      	mov.d	x9, v2[1]
    4328:      	ld1.b	{ v21 }[3], [x9]
    432c:      	adrp	x9, 0x4000 <_llm_rows.packet_batch.blocks+0x2964>
    4330:      	ldr	q2, [x9]
    4334:      	and.16b	v2, v28, v2
    4338:      	add.2d	v2, v18, v2
    433c:      	tbz	w8, #0x4, 0x3208 <_llm_rows.packet_batch.blocks+0x1b6c>
    4340:      	fmov	x9, d2
    4344:      	ld1.b	{ v21 }[4], [x9]
    4348:      	tbz	w8, #0x5, 0x320c <_llm_rows.packet_batch.blocks+0x1b70>
    434c:      	mov.d	x9, v2[1]
    4350:      	ld1.b	{ v21 }[5], [x9]
    4354:      	adrp	x9, 0x4000 <_llm_rows.packet_batch.blocks+0x2964>
    4358:      	ldr	q2, [x9]
    435c:      	and.16b	v2, v7, v2
    4360:      	add.2d	v3, v17, v2
    4364:      	tbz	w8, #0x6, 0x3220 <_llm_rows.packet_batch.blocks+0x1b84>
    4368:      	fmov	x9, d3
    436c:      	ld1.b	{ v21 }[6], [x9]
    4370:      	ldr	q2, [sp, #0x10]
    4374:      	and.16b	v2, v14, v2
    4378:      	tbnz	w8, #0x7, 0x322c <_llm_rows.packet_batch.blocks+0x1b90>
    437c:      	b	0x3234 <_llm_rows.packet_batch.blocks+0x1b98>
    4380:      	add	sp, sp, #0x4, lsl #12   ; =0x4000
    4384:      	add	sp, sp, #0x660
    4388:      	ldp	x29, x30, [sp, #0x90]
    438c:      	ldp	x20, x19, [sp, #0x80]
    4390:      	ldp	x22, x21, [sp, #0x70]
    4394:      	ldp	x24, x23, [sp, #0x60]
    4398:      	ldp	x26, x25, [sp, #0x50]
    439c:      	ldp	x28, x27, [sp, #0x40]
    43a0:      	ldp	d9, d8, [sp, #0x30]
    43a4:      	ldp	d11, d10, [sp, #0x20]
    43a8:      	ldp	d13, d12, [sp, #0x10]
    43ac:      	ldp	d15, d14, [sp], #0xa0
    43b0:      	ret

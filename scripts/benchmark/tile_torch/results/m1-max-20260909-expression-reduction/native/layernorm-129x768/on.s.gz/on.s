
/private/tmp/luisa-expression-fusion.qXgTbC/capture/layernorm-129x768/on/object/tile_xir_w8_23345_1788930262330924_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	x24, x23, [sp, #-0x40]!
       4:      	stp	x22, x21, [sp, #0x10]
       8:      	stp	x20, x19, [sp, #0x20]
       c:      	stp	x29, x30, [sp, #0x30]
      10:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
      14:      	sub	sp, sp, #0x80
      18:      	ldr	x8, [x0]
      1c:      	ldr	x20, [x0, #0x10]
      20:      	ldr	x19, [x0, #0x20]
      24:      	ldr	x21, [x0, #0x30]
      28:      	ldr	w9, [x1]
      2c:      	ldr	w10, [x1, #0x24]
      30:      	add	w9, w10, w9, lsl #5
      34:      	lsr	w9, w9, #3
      38:      	mov	w10, #0xc00             ; =3072
      3c:      	umull	x22, w9, w10
      40:      	umaddl	x1, w9, w10, x8
      44:      	add	x23, sp, #0x2, lsl #12  ; =0x2000
      48:      	add	x23, x23, #0x480
      4c:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
      50:      	add	x0, x0, #0x480
      54:      	mov	w2, #0xc00              ; =3072
      58:      	bl	0x58 <ltmp0+0x58>
      5c:      	ldr	q5, [sp, #0x2490]
      60:      	ldr	q6, [sp, #0x2480]
      64:      	ldr	q3, [sp, #0x24d0]
      68:      	ldr	q4, [sp, #0x24c0]
      6c:      	ldr	q1, [sp, #0x24f0]
      70:      	ldr	q2, [sp, #0x24e0]
      74:      	add	x8, x23, #0xe0
      78:      	mov	w9, #0x4                ; =4
      7c:      	mov.16b	v0, v2
      80:      	mov.16b	v17, v1
      84:      	mov.16b	v18, v4
      88:      	mov.16b	v19, v3
      8c:      	ldr	q7, [sp, #0x24b0]
      90:      	ldr	q16, [sp, #0x24a0]
      94:      	mov.16b	v20, v16
      98:      	mov.16b	v21, v7
      9c:      	mov.16b	v22, v6
      a0:      	mov.16b	v23, v5
      a4:      	ldp	q24, q25, [x8, #-0x60]
      a8:      	fadd.4s	v23, v23, v25
      ac:      	fadd.4s	v22, v22, v24
      b0:      	ldp	q24, q25, [x8, #-0x40]
      b4:      	fadd.4s	v21, v21, v25
      b8:      	fadd.4s	v20, v20, v24
      bc:      	ldp	q24, q25, [x8, #-0x20]
      c0:      	fadd.4s	v19, v19, v25
      c4:      	fadd.4s	v18, v18, v24
      c8:      	ldp	q24, q25, [x8], #0x80
      cc:      	fadd.4s	v17, v17, v25
      d0:      	fadd.4s	v0, v0, v24
      d4:      	cmp	x9, #0x5c
      d8:      	add	x9, x9, #0x4
      dc:      	b.lo	0xa4 <ltmp0+0xa4>
      e0:      	mov	x8, #0x0                ; =0
      e4:      	fadd.4s	v20, v22, v20
      e8:      	fadd.4s	v21, v23, v21
      ec:      	fadd.4s	v19, v21, v19
      f0:      	fadd.4s	v18, v20, v18
      f4:      	fadd.4s	v0, v18, v0
      f8:      	fadd.4s	v17, v19, v17
      fc:      	rev64.4s	v18, v17
     100:      	rev64.4s	v19, v0
     104:      	fadd.4s	v0, v0, v19
     108:      	fadd.4s	v17, v17, v18
     10c:      	dup.4s	v18, v17[2]
     110:      	dup.4s	v19, v0[2]
     114:      	fadd.4s	v0, v0, v19
     118:      	fadd.4s	v17, v17, v18
     11c:      	fadd.4s	v0, v0, v17
     120:      	movi	d17, #0000000000000000
     124:      	fadd	s0, s0, s17
     128:      	mov	w9, #0x44400000         ; =1145044992
     12c:      	fmov	s17, w9
     130:      	fdiv	s0, s0, s17
     134:      	dup.4s	v0, v0[0]
     138:      	fsub.4s	v6, v6, v0
     13c:      	fsub.4s	v5, v5, v0
     140:      	str	q5, [sp, #0x1890]
     144:      	str	q6, [sp, #0x1880]
     148:      	fmul.4s	v17, v5, v5
     14c:      	fmul.4s	v18, v6, v6
     150:      	fsub.4s	v5, v16, v0
     154:      	fsub.4s	v6, v7, v0
     158:      	str	q6, [sp, #0x18b0]
     15c:      	str	q5, [sp, #0x18a0]
     160:      	fmul.4s	v7, v6, v6
     164:      	fmul.4s	v16, v5, v5
     168:      	fsub.4s	v4, v4, v0
     16c:      	fsub.4s	v3, v3, v0
     170:      	str	q3, [sp, #0x18d0]
     174:      	str	q4, [sp, #0x18c0]
     178:      	fmul.4s	v5, v3, v3
     17c:      	fmul.4s	v3, v4, v4
     180:      	fsub.4s	v2, v2, v0
     184:      	fsub.4s	v1, v1, v0
     188:      	str	q1, [sp, #0x18f0]
     18c:      	str	q2, [sp, #0x18e0]
     190:      	fmul.4s	v4, v1, v1
     194:      	fmul.4s	v6, v2, v2
     198:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     19c:      	add	x9, x9, #0x880
     1a0:      	add	x9, x9, #0xe0
     1a4:      	add	x10, sp, #0x2, lsl #12  ; =0x2000
     1a8:      	add	x10, x10, #0x480
     1ac:      	add	x10, x10, #0xe0
     1b0:      	ldp	q2, q1, [x10, #-0x60]
     1b4:      	fsub.4s	v2, v2, v0
     1b8:      	fsub.4s	v1, v1, v0
     1bc:      	stp	q2, q1, [x9, #-0x60]
     1c0:      	fmul.4s	v2, v2, v2
     1c4:      	fmul.4s	v1, v1, v1
     1c8:      	fadd.4s	v17, v17, v1
     1cc:      	fadd.4s	v18, v18, v2
     1d0:      	ldp	q2, q1, [x10, #-0x40]
     1d4:      	fsub.4s	v2, v2, v0
     1d8:      	fsub.4s	v1, v1, v0
     1dc:      	stp	q2, q1, [x9, #-0x40]
     1e0:      	fmul.4s	v2, v2, v2
     1e4:      	fmul.4s	v1, v1, v1
     1e8:      	fadd.4s	v7, v7, v1
     1ec:      	fadd.4s	v16, v16, v2
     1f0:      	ldp	q2, q1, [x10, #-0x20]
     1f4:      	fsub.4s	v2, v2, v0
     1f8:      	fsub.4s	v1, v1, v0
     1fc:      	stp	q2, q1, [x9, #-0x20]
     200:      	fmul.4s	v2, v2, v2
     204:      	fmul.4s	v1, v1, v1
     208:      	fadd.4s	v5, v5, v1
     20c:      	fadd.4s	v3, v3, v2
     210:      	ldp	q2, q1, [x10], #0x80
     214:      	fsub.4s	v2, v2, v0
     218:      	fsub.4s	v1, v1, v0
     21c:      	stp	q2, q1, [x9], #0x80
     220:      	fmul.4s	v2, v2, v2
     224:      	fmul.4s	v1, v1, v1
     228:      	fadd.4s	v4, v4, v1
     22c:      	fadd.4s	v6, v6, v2
     230:      	add	x8, x8, #0x4
     234:      	cmp	x8, #0x5c
     238:      	b.lo	0x1b0 <ltmp0+0x1b0>
     23c:      	add	x23, sp, #0xc80
     240:      	add	x0, sp, #0xc80
     244:      	mov	x1, x20
     248:      	mov	w2, #0xc00              ; =3072
     24c:      	stp	q3, q4, [sp, #0x60]
     250:      	stp	q5, q6, [sp, #0x40]
     254:      	stp	q7, q17, [sp, #0x20]
     258:      	stp	q16, q18, [sp]
     25c:      	bl	0x25c <ltmp0+0x25c>
     260:      	add	x20, sp, #0x80
     264:      	add	x0, sp, #0x80
     268:      	mov	x1, x19
     26c:      	mov	w2, #0xc00              ; =3072
     270:      	bl	0x270 <ltmp0+0x270>
     274:      	mov	x8, #0x0                ; =0
     278:      	ldp	q1, q0, [sp]
     27c:      	fadd.4s	v0, v0, v1
     280:      	ldp	q2, q1, [sp, #0x20]
     284:      	fadd.4s	v1, v1, v2
     288:      	mov	w9, #0x44400000         ; =1145044992
     28c:      	fmov	s2, w9
     290:      	mov	w9, #0xc5ac             ; =50604
     294:      	movk	w9, #0x3727, lsl #16
     298:      	fmov	s3, w9
     29c:      	ldr	q4, [sp, #0x40]
     2a0:      	fadd.4s	v1, v1, v4
     2a4:      	ldp	q4, q5, [sp, #0x50]
     2a8:      	fadd.4s	v0, v0, v5
     2ac:      	fadd.4s	v0, v0, v4
     2b0:      	ldr	q4, [sp, #0x70]
     2b4:      	fadd.4s	v1, v1, v4
     2b8:      	rev64.4s	v4, v1
     2bc:      	rev64.4s	v5, v0
     2c0:      	fadd.4s	v0, v0, v5
     2c4:      	fadd.4s	v1, v1, v4
     2c8:      	dup.4s	v4, v1[2]
     2cc:      	dup.4s	v5, v0[2]
     2d0:      	fadd.4s	v0, v0, v5
     2d4:      	fadd.4s	v1, v1, v4
     2d8:      	fadd.4s	v0, v0, v1
     2dc:      	movi	d1, #0000000000000000
     2e0:      	fadd	s0, s0, s1
     2e4:      	fdiv	s0, s0, s2
     2e8:      	fadd	s0, s0, s3
     2ec:      	fsqrt	s0, s0
     2f0:      	dup.4s	v0, v0[0]
     2f4:      	add	x9, x21, x22
     2f8:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
     2fc:      	add	x10, x10, #0x880
     300:      	add	x11, x10, x8
     304:      	ldp	q2, q1, [x11]
     308:      	fdiv.4s	v2, v2, v0
     30c:      	fdiv.4s	v1, v1, v0
     310:      	add	x11, x23, x8
     314:      	ldp	q3, q4, [x11]
     318:      	fmul.4s	v1, v1, v4
     31c:      	fmul.4s	v2, v2, v3
     320:      	add	x11, x20, x8
     324:      	ldp	q4, q3, [x11]
     328:      	fadd.4s	v2, v2, v4
     32c:      	fadd.4s	v1, v1, v3
     330:      	add	x11, x9, x8
     334:      	stp	q2, q1, [x11]
     338:      	add	x8, x8, #0x20
     33c:      	cmp	x8, #0xc00
     340:      	b.ne	0x300 <ltmp0+0x300>
     344:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
     348:      	add	sp, sp, #0x80
     34c:      	ldp	x29, x30, [sp, #0x30]
     350:      	ldp	x20, x19, [sp, #0x20]
     354:      	ldp	x22, x21, [sp, #0x10]
     358:      	ldp	x24, x23, [sp], #0x40
     35c:      	ret

0000000000000360 <_llm_rows.packet_batch.blocks>:
     360:      	stp	d9, d8, [sp, #-0x70]!
     364:      	stp	x28, x27, [sp, #0x10]
     368:      	stp	x26, x25, [sp, #0x20]
     36c:      	stp	x24, x23, [sp, #0x30]
     370:      	stp	x22, x21, [sp, #0x40]
     374:      	stp	x20, x19, [sp, #0x50]
     378:      	stp	x29, x30, [sp, #0x60]
     37c:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
     380:      	sub	sp, sp, #0x460
     384:      	str	x0, [sp, #0x88]
     388:      	cbz	w3, 0x124c <_llm_rows.packet_batch.blocks+0xeec>
     38c:      	mov	x24, x3
     390:      	mov	x20, x2
     394:      	mov	w22, #0x0               ; =0
     398:      	add	x23, sp, #0x120
     39c:      	add	x8, sp, #0x2, lsl #12   ; =0x2000
     3a0:      	add	x8, x8, #0x860
     3a4:      	add	x8, x8, #0xe0
     3a8:      	str	x8, [sp, #0x40]
     3ac:      	ldp	w9, w8, [x2, #0x2c]
     3b0:      	stp	w8, w9, [sp, #0x80]
     3b4:      	add	x8, sp, #0x1, lsl #12   ; =0x1000
     3b8:      	add	x8, x8, #0xc60
     3bc:      	add	x8, x8, #0xe0
     3c0:      	str	x8, [sp, #0x20]
     3c4:      	ldp	w25, w26, [x2]
     3c8:      	ldp	w27, w8, [x2, #0x8]
     3cc:      	str	x8, [sp, #0x78]
     3d0:      	adrp	x8, 0x0 <ltmp0>
     3d4:      	ldr	q0, [x8]
     3d8:      	str	q0, [sp, #0x10]
     3dc:      	adrp	x8, 0x0 <ltmp0>
     3e0:      	ldr	q0, [x8]
     3e4:      	str	q0, [sp, #0x60]
     3e8:      	adrp	x8, 0x0 <ltmp0>
     3ec:      	ldr	q0, [x8]
     3f0:      	str	q0, [sp, #0x50]
     3f4:      	movi	d8, #0000000000000000
     3f8:      	add	x28, sp, #0x1, lsl #12  ; =0x1000
     3fc:      	add	x28, x28, #0x60
     400:      	add	x21, sp, #0x460
     404:      	str	w3, [sp, #0x4c]
     408:      	b	0x450 <_llm_rows.packet_batch.blocks+0xf0>
     40c:      	mov	w8, #0x18               ; =24
     410:      	str	w8, [x20, #0x24]
     414:      	ldr	w24, [sp, #0x4c]
     418:      	add	w8, w25, #0x1
     41c:      	ldp	w10, w9, [sp, #0x80]
     420:      	cmp	w8, w9
     424:      	cset	w8, eq
     428:      	csinc	w25, wzr, w25, eq
     42c:      	cinc	w9, w26, eq
     430:      	cmp	w9, w10
     434:      	cset	w10, eq
     438:      	ands	w8, w8, w10
     43c:      	csel	w26, wzr, w9, ne
     440:      	add	w27, w27, w8
     444:      	add	w22, w22, #0x1
     448:      	cmp	w22, w24
     44c:      	b.eq	0x124c <_llm_rows.packet_batch.blocks+0xeec>
     450:      	ubfiz	x8, x25, #5, #32
     454:      	ldr	x12, [sp, #0x78]
     458:      	cmp	x8, x12
     45c:      	csel	x9, x8, xzr, ls
     460:      	subs	x10, x12, x9
     464:      	cmp	x10, #0x20
     468:      	mov	w11, #0x20              ; =32
     46c:      	csel	x10, x10, x11, lo
     470:      	cmp	x12, x9
     474:      	stp	w25, w26, [x20]
     478:      	str	w27, [x20, #0x8]
     47c:      	str	wzr, [x20, #0x24]
     480:      	ccmp	x8, x12, #0x2, hi
     484:      	csel	x19, x10, xzr, ls
     488:      	cmp	x19, #0x20
     48c:      	b.lo	0x4e0 <_llm_rows.packet_batch.blocks+0x180>
     490:      	ldr	x19, [sp, #0x88]
     494:      	mov	x0, x19
     498:      	mov	x1, x20
     49c:      	bl	0x49c <_llm_rows.packet_batch.blocks+0x13c>
     4a0:      	mov	w8, #0x8                ; =8
     4a4:      	str	w8, [x20, #0x24]
     4a8:      	mov	x0, x19
     4ac:      	mov	x1, x20
     4b0:      	bl	0x4b0 <_llm_rows.packet_batch.blocks+0x150>
     4b4:      	mov	w8, #0x10               ; =16
     4b8:      	str	w8, [x20, #0x24]
     4bc:      	mov	x0, x19
     4c0:      	mov	x1, x20
     4c4:      	bl	0x4c4 <_llm_rows.packet_batch.blocks+0x164>
     4c8:      	mov	w8, #0x18               ; =24
     4cc:      	str	w8, [x20, #0x24]
     4d0:      	mov	x0, x19
     4d4:      	mov	x1, x20
     4d8:      	bl	0x4d8 <_llm_rows.packet_batch.blocks+0x178>
     4dc:      	b	0x418 <_llm_rows.packet_batch.blocks+0xb8>
     4e0:      	lsr	x24, x19, #3
     4e4:      	cmp	x19, #0x8
     4e8:      	b.lo	0x534 <_llm_rows.packet_batch.blocks+0x1d4>
     4ec:      	str	wzr, [x20, #0x24]
     4f0:      	ldr	x0, [sp, #0x88]
     4f4:      	mov	x1, x20
     4f8:      	bl	0x4f8 <_llm_rows.packet_batch.blocks+0x198>
     4fc:      	cmp	x24, #0x1
     500:      	b.eq	0x534 <_llm_rows.packet_batch.blocks+0x1d4>
     504:      	mov	w8, #0x8                ; =8
     508:      	str	w8, [x20, #0x24]
     50c:      	ldr	x0, [sp, #0x88]
     510:      	mov	x1, x20
     514:      	bl	0x514 <_llm_rows.packet_batch.blocks+0x1b4>
     518:      	cmp	x24, #0x2
     51c:      	b.eq	0x534 <_llm_rows.packet_batch.blocks+0x1d4>
     520:      	mov	w8, #0x10               ; =16
     524:      	str	w8, [x20, #0x24]
     528:      	ldr	x0, [sp, #0x88]
     52c:      	mov	x1, x20
     530:      	bl	0x530 <_llm_rows.packet_batch.blocks+0x1d0>
     534:      	and	w8, w19, #0x7
     538:      	cbz	w8, 0x40c <_llm_rows.packet_batch.blocks+0xac>
     53c:      	dup.4s	v1, w8
     540:      	ldp	q0, q2, [sp, #0x50]
     544:      	cmhi.4s	v0, v1, v0
     548:      	cmhi.4s	v1, v1, v2
     54c:      	uzp1.8h	v3, v1, v0
     550:      	umaxv.8h	h2, v3
     554:      	fmov	w8, s2
     558:      	tbz	w8, #0x0, 0x40c <_llm_rows.packet_batch.blocks+0xac>
     55c:      	mov	x9, #0x0                ; =0
     560:      	ldr	x10, [sp, #0x88]
     564:      	ldr	x3, [x10, #0x10]
     568:      	ldr	x11, [x10, #0x20]
     56c:      	ldr	x8, [x10, #0x30]
     570:      	str	x8, [sp, #0x38]
     574:      	ldr	q2, [sp, #0x10]
     578:      	and.16b	v2, v3, v2
     57c:      	addv.8h	h2, v2
     580:      	fmov	w8, s2
     584:      	and	w8, w8, #0xff
     588:      	ldr	x10, [x10]
     58c:      	ubfiz	w12, w25, #2, #27
     590:      	orr	w12, w12, w24
     594:      	fmov	s4, w12
     598:      	and.16b	v4, v1, v4
     59c:      	fmov	w12, s4
     5a0:      	mov	w13, #0xc00             ; =3072
     5a4:      	umull	x14, w12, w13
     5a8:      	str	x14, [sp, #0x30]
     5ac:      	umaddl	x10, w12, w13, x10
     5b0:      	fmov	w12, s2
     5b4:      	add	x6, sp, #0x2, lsl #12   ; =0x2000
     5b8:      	add	x6, x6, #0x860
     5bc:      	b	0x5e0 <_llm_rows.packet_batch.blocks+0x280>
     5c0:      	add	x13, x6, x9
     5c4:      	ldp	q6, q7, [x13]
     5c8:      	bif.16b	v5, v7, v0
     5cc:      	bif.16b	v4, v6, v1
     5d0:      	stp	q4, q5, [x13]
     5d4:      	add	x9, x9, #0x20
     5d8:      	cmp	x9, #0xc00
     5dc:      	b.eq	0x674 <_llm_rows.packet_batch.blocks+0x314>
     5e0:      	add	x13, x10, x9
     5e4:      	movi.2d	v4, #0000000000000000
     5e8:      	movi.2d	v5, #0000000000000000
     5ec:      	tbnz	w12, #0x0, 0x614 <_llm_rows.packet_batch.blocks+0x2b4>
     5f0:      	and	w14, w12, #0xff
     5f4:      	tbnz	w14, #0x1, 0x620 <_llm_rows.packet_batch.blocks+0x2c0>
     5f8:      	tbnz	w14, #0x2, 0x62c <_llm_rows.packet_batch.blocks+0x2cc>
     5fc:      	tbnz	w14, #0x3, 0x638 <_llm_rows.packet_batch.blocks+0x2d8>
     600:      	tbnz	w14, #0x4, 0x644 <_llm_rows.packet_batch.blocks+0x2e4>
     604:      	tbnz	w14, #0x5, 0x650 <_llm_rows.packet_batch.blocks+0x2f0>
     608:      	tbnz	w14, #0x6, 0x65c <_llm_rows.packet_batch.blocks+0x2fc>
     60c:      	tbz	w14, #0x7, 0x5c0 <_llm_rows.packet_batch.blocks+0x260>
     610:      	b	0x668 <_llm_rows.packet_batch.blocks+0x308>
     614:      	ldr	s4, [x13]
     618:      	and	w14, w12, #0xff
     61c:      	tbz	w14, #0x1, 0x5f8 <_llm_rows.packet_batch.blocks+0x298>
     620:      	add	x15, x13, #0x4
     624:      	ld1.s	{ v4 }[1], [x15]
     628:      	tbz	w14, #0x2, 0x5fc <_llm_rows.packet_batch.blocks+0x29c>
     62c:      	add	x15, x13, #0x8
     630:      	ld1.s	{ v4 }[2], [x15]
     634:      	tbz	w14, #0x3, 0x600 <_llm_rows.packet_batch.blocks+0x2a0>
     638:      	add	x15, x13, #0xc
     63c:      	ld1.s	{ v4 }[3], [x15]
     640:      	tbz	w14, #0x4, 0x604 <_llm_rows.packet_batch.blocks+0x2a4>
     644:      	add	x15, x13, #0x10
     648:      	ld1.s	{ v5 }[0], [x15]
     64c:      	tbz	w14, #0x5, 0x608 <_llm_rows.packet_batch.blocks+0x2a8>
     650:      	add	x15, x13, #0x14
     654:      	ld1.s	{ v5 }[1], [x15]
     658:      	tbz	w14, #0x6, 0x60c <_llm_rows.packet_batch.blocks+0x2ac>
     65c:      	add	x15, x13, #0x18
     660:      	ld1.s	{ v5 }[2], [x15]
     664:      	tbz	w14, #0x7, 0x5c0 <_llm_rows.packet_batch.blocks+0x260>
     668:      	add	x13, x13, #0x1c
     66c:      	ld1.s	{ v5 }[3], [x13]
     670:      	b	0x5c0 <_llm_rows.packet_batch.blocks+0x260>
     674:      	ldr	q5, [x23, #0x2740]
     678:      	ldr	q4, [x23, #0x2750]
     67c:      	ldr	q6, [x23, #0x2760]
     680:      	ldr	q7, [x23, #0x2770]
     684:      	ldr	q16, [x23, #0x2780]
     688:      	ldr	q19, [x23, #0x2790]
     68c:      	ldr	q20, [x23, #0x27a0]
     690:      	and.16b	v4, v0, v4
     694:      	and.16b	v5, v1, v5
     698:      	ldr	q21, [x23, #0x27b0]
     69c:      	and.16b	v18, v0, v7
     6a0:      	and.16b	v17, v1, v6
     6a4:      	and.16b	v6, v0, v19
     6a8:      	and.16b	v19, v1, v16
     6ac:      	and.16b	v16, v0, v21
     6b0:      	and.16b	v7, v1, v20
     6b4:      	ldr	x9, [sp, #0x40]
     6b8:      	mov.16b	v20, v5
     6bc:      	mov.16b	v21, v4
     6c0:      	mov	w10, #0x4               ; =4
     6c4:      	ldp	q23, q22, [x9, #-0x60]
     6c8:      	fadd.4s	v23, v20, v23
     6cc:      	fadd.4s	v22, v21, v22
     6d0:      	ldp	q25, q24, [x9, #-0x40]
     6d4:      	fadd.4s	v25, v17, v25
     6d8:      	fadd.4s	v24, v18, v24
     6dc:      	ldp	q27, q26, [x9, #-0x20]
     6e0:      	fadd.4s	v27, v19, v27
     6e4:      	fadd.4s	v26, v6, v26
     6e8:      	ldp	q29, q28, [x9], #0x80
     6ec:      	fadd.4s	v29, v7, v29
     6f0:      	fadd.4s	v28, v16, v28
     6f4:      	bit.16b	v21, v22, v0
     6f8:      	bit.16b	v20, v23, v1
     6fc:      	bit.16b	v18, v24, v0
     700:      	bit.16b	v17, v25, v1
     704:      	bit.16b	v6, v26, v0
     708:      	bit.16b	v19, v27, v1
     70c:      	bit.16b	v16, v28, v0
     710:      	bit.16b	v7, v29, v1
     714:      	cmp	x10, #0x5c
     718:      	add	x10, x10, #0x4
     71c:      	b.lo	0x6c4 <_llm_rows.packet_batch.blocks+0x364>
     720:      	mov	x4, #0x0                ; =0
     724:      	xtn.8b	v3, v3
     728:      	fadd.4s	v18, v21, v18
     72c:      	fadd.4s	v17, v20, v17
     730:      	fadd.4s	v17, v17, v19
     734:      	fadd.4s	v6, v18, v6
     738:      	fadd.4s	v6, v6, v16
     73c:      	fadd.4s	v7, v17, v7
     740:      	ldp	q16, q18, [sp, #0x50]
     744:      	and.16b	v17, v1, v18
     748:      	and.16b	v16, v0, v16
     74c:      	movi.4s	v19, #0x1
     750:      	eor.16b	v18, v16, v19
     754:      	umov.b	w10, v3[0]
     758:      	eor.16b	v20, v17, v19
     75c:      	str	q7, [x23, #0x310]
     760:      	ldr	s17, [x23, #0x314]
     764:      	umov.b	w12, v3[1]
     768:      	ands	w9, w10, #0x1
     76c:      	tst	w9, w12
     770:      	fcsel	s17, s17, s8, ne
     774:      	mov.s	w13, v20[1]
     778:      	add	x14, sp, #0x410
     77c:      	orr	x14, x14, x13, lsl #2
     780:      	add	x15, sp, #0x2e8
     784:      	bfxil	x15, x13, #0, #3
     788:      	str	d3, [x23, #0x1c8]
     78c:      	ldrb	w13, [x15]
     790:      	and	w13, w12, w13
     794:      	stp	q7, q6, [x23, #0x2f0]
     798:      	ldr	s19, [x14]
     79c:      	tst	w13, #0x1
     7a0:      	fcsel	s19, s19, s8, ne
     7a4:      	mov.s	w13, v20[2]
     7a8:      	add	x14, sp, #0x3f0
     7ac:      	orr	x14, x14, x13, lsl #2
     7b0:      	add	x15, sp, #0x2e8
     7b4:      	bfxil	x15, x13, #0, #3
     7b8:      	ldrb	w15, [x15]
     7bc:      	umov.b	w13, v3[2]
     7c0:      	and	w15, w13, w15
     7c4:      	stp	q7, q6, [x23, #0x2d0]
     7c8:      	ldr	s21, [x14]
     7cc:      	tst	w15, #0x1
     7d0:      	mov.s	w14, v20[3]
     7d4:      	fcsel	s20, s21, s8, ne
     7d8:      	add	x15, sp, #0x3d0
     7dc:      	orr	x15, x15, x14, lsl #2
     7e0:      	add	x16, sp, #0x2e8
     7e4:      	bfxil	x16, x14, #0, #3
     7e8:      	umov.b	w14, v3[3]
     7ec:      	ldrb	w16, [x16]
     7f0:      	and	w16, w14, w16
     7f4:      	stp	q7, q6, [x23, #0x2b0]
     7f8:      	ldr	s21, [x15]
     7fc:      	tst	w16, #0x1
     800:      	fcsel	s21, s21, s8, ne
     804:      	fmov	w16, s18
     808:      	add	x17, sp, #0x2e8
     80c:      	bfxil	x17, x16, #0, #3
     810:      	umov.b	w15, v3[4]
     814:      	ldrb	w17, [x17]
     818:      	and	w17, w15, w17
     81c:      	stp	q7, q6, [x23, #0x290]
     820:      	add	x0, sp, #0x3b0
     824:      	ldr	s22, [x0, w16, uxtw #2]
     828:      	tst	w17, #0x1
     82c:      	fcsel	s22, s22, s8, ne
     830:      	mov.s	w17, v18[1]
     834:      	add	x16, sp, #0x2e8
     838:      	bfxil	x16, x17, #0, #3
     83c:      	ldrb	w0, [x16]
     840:      	umov.b	w16, v3[5]
     844:      	and	w0, w16, w0
     848:      	stp	q7, q6, [x23, #0x270]
     84c:      	add	x1, sp, #0x390
     850:      	ldr	s23, [x1, w17, uxtw #2]
     854:      	tst	w0, #0x1
     858:      	fcsel	s23, s23, s8, ne
     85c:      	mov.s	w0, v18[2]
     860:      	add	x17, sp, #0x2e8
     864:      	bfxil	x17, x0, #0, #3
     868:      	ldrb	w1, [x17]
     86c:      	umov.b	w17, v3[6]
     870:      	and	w1, w17, w1
     874:      	stp	q7, q6, [x23, #0x250]
     878:      	add	x2, sp, #0x370
     87c:      	ldr	s24, [x2, w0, uxtw #2]
     880:      	tst	w1, #0x1
     884:      	fcsel	s24, s24, s8, ne
     888:      	mov.s	w1, v18[3]
     88c:      	add	x2, sp, #0x2e8
     890:      	bfxil	x2, x1, #0, #3
     894:      	umov.b	w0, v3[7]
     898:      	ldrb	w2, [x2]
     89c:      	and	w2, w0, w2
     8a0:      	stp	q7, q6, [x23, #0x230]
     8a4:      	add	x5, sp, #0x350
     8a8:      	ldr	s18, [x5, w1, uxtw #2]
     8ac:      	tst	w2, #0x1
     8b0:      	fcsel	s18, s18, s8, ne
     8b4:      	mov.s	v17[1], v19[0]
     8b8:      	mov.s	v17[2], v20[0]
     8bc:      	mov.s	v17[3], v21[0]
     8c0:      	mov.s	v22[1], v23[0]
     8c4:      	mov.s	v22[2], v24[0]
     8c8:      	mov.s	v22[3], v18[0]
     8cc:      	fadd.4s	v6, v6, v22
     8d0:      	fadd.4s	v7, v7, v17
     8d4:      	movi.4s	v17, #0x2
     8d8:      	eor.16b	v16, v16, v17
     8dc:      	str	q7, [x23, #0x210]
     8e0:      	ldr	s17, [x23, #0x218]
     8e4:      	tst	w9, w13
     8e8:      	fcsel	s17, s17, s8, ne
     8ec:      	fmov	w9, s16
     8f0:      	add	x1, sp, #0x2e8
     8f4:      	bfxil	x1, x9, #0, #3
     8f8:      	ldrb	w1, [x1]
     8fc:      	and	w1, w15, w1
     900:      	stp	q7, q6, [x23, #0x1f0]
     904:      	add	x2, sp, #0x310
     908:      	ldr	s16, [x2, w9, uxtw #2]
     90c:      	tst	w1, #0x1
     910:      	fcsel	s16, s16, s8, ne
     914:      	fadd.4s	v6, v6, v16
     918:      	and	w1, w10, w15
     91c:      	tst	w1, #0x1
     920:      	fcsel	s6, s6, s8, ne
     924:      	ands	w2, w10, #0x1
     928:      	fadd.4s	v7, v7, v17
     92c:      	fadd	s17, s7, s6
     930:      	fcsel	s18, s17, s8, ne
     934:      	tst	w1, #0x1
     938:      	sshll.2d	v6, v1, #0x0
     93c:      	mov	w9, #0x20               ; =32
     940:      	dup.2d	v7, x9
     944:      	and.16b	v16, v6, v7
     948:      	mov	w9, #0x40               ; =64
     94c:      	dup.2d	v7, x9
     950:      	and.16b	v7, v6, v7
     954:      	mov	w9, #0x60               ; =96
     958:      	dup.2d	v19, x9
     95c:      	and.16b	v6, v6, v19
     960:      	and	w9, w12, w10
     964:      	fcsel	s19, s17, s8, ne
     968:      	str	w9, [sp, #0x2c]
     96c:      	tst	w9, #0x1
     970:      	and	w9, w13, w10
     974:      	fcsel	s20, s17, s8, ne
     978:      	str	w9, [sp, #0x28]
     97c:      	tst	w9, #0x1
     980:      	and	w9, w14, w10
     984:      	fcsel	s21, s17, s8, ne
     988:      	mov	x24, x9
     98c:      	tst	w9, #0x1
     990:      	fcsel	s22, s17, s8, ne
     994:      	and	w7, w16, w10
     998:      	tst	w7, #0x1
     99c:      	fcsel	s23, s17, s8, ne
     9a0:      	and	w30, w17, w10
     9a4:      	tst	w30, #0x1
     9a8:      	fcsel	s24, s17, s8, ne
     9ac:      	and	w9, w0, w10
     9b0:      	tst	w9, #0x1
     9b4:      	fcsel	s17, s17, s8, ne
     9b8:      	mov.s	v18[1], v20[0]
     9bc:      	mov.s	v18[2], v21[0]
     9c0:      	mov.s	v18[3], v22[0]
     9c4:      	mov.s	v19[1], v23[0]
     9c8:      	mov.s	v19[2], v24[0]
     9cc:      	mov.s	v19[3], v17[0]
     9d0:      	rbit	w8, w8
     9d4:      	clz	w8, w8
     9d8:      	stp	q18, q19, [x23, #0x1d0]
     9dc:      	and	x5, x8, #0x7
     9e0:      	add	x19, sp, #0x2f0
     9e4:      	ldr	s17, [x19, x5, lsl #2]
     9e8:      	fadd	s17, s17, s8
     9ec:      	mov	w5, #0x44400000         ; =1145044992
     9f0:      	fmov	s18, w5
     9f4:      	fdiv	s17, s17, s18
     9f8:      	dup.4s	v20, v17[0]
     9fc:      	fsub.4s	v5, v5, v20
     a00:      	fsub.4s	v4, v4, v20
     a04:      	ldr	q17, [x23, #0x1b40]
     a08:      	ldr	q18, [x23, #0x1b50]
     a0c:      	bit.16b	v18, v4, v0
     a10:      	bit.16b	v17, v5, v1
     a14:      	str	q17, [x23, #0x1b40]
     a18:      	str	q18, [x23, #0x1b50]
     a1c:      	fmul.4s	v17, v5, v5
     a20:      	fmul.4s	v4, v4, v4
     a24:      	fmov	x5, d16
     a28:      	add	x5, x6, x5
     a2c:      	ldp	q5, q16, [x5]
     a30:      	and.16b	v16, v0, v16
     a34:      	and.16b	v5, v1, v5
     a38:      	fsub.4s	v5, v5, v20
     a3c:      	fsub.4s	v16, v16, v20
     a40:      	ldr	q18, [x23, #0x1b60]
     a44:      	ldr	q19, [x23, #0x1b70]
     a48:      	bit.16b	v19, v16, v0
     a4c:      	bit.16b	v18, v5, v1
     a50:      	str	q18, [x23, #0x1b60]
     a54:      	str	q19, [x23, #0x1b70]
     a58:      	fmul.4s	v19, v5, v5
     a5c:      	fmul.4s	v16, v16, v16
     a60:      	fmov	x5, d7
     a64:      	add	x5, x6, x5
     a68:      	ldp	q5, q7, [x5]
     a6c:      	and.16b	v7, v0, v7
     a70:      	and.16b	v5, v1, v5
     a74:      	fsub.4s	v5, v5, v20
     a78:      	fsub.4s	v7, v7, v20
     a7c:      	ldr	q18, [x23, #0x1b80]
     a80:      	ldr	q21, [x23, #0x1b90]
     a84:      	bit.16b	v21, v7, v0
     a88:      	bit.16b	v18, v5, v1
     a8c:      	fmul.4s	v22, v5, v5
     a90:      	fmul.4s	v7, v7, v7
     a94:      	fmov	x5, d6
     a98:      	add	x5, x6, x5
     a9c:      	ldp	q5, q6, [x5]
     aa0:      	and.16b	v6, v0, v6
     aa4:      	and.16b	v5, v1, v5
     aa8:      	fsub.4s	v5, v5, v20
     aac:      	fsub.4s	v6, v6, v20
     ab0:      	ldr	q23, [x23, #0x1ba0]
     ab4:      	ldr	q24, [x23, #0x1bb0]
     ab8:      	bit.16b	v24, v6, v0
     abc:      	bit.16b	v23, v5, v1
     ac0:      	fmul.4s	v25, v5, v5
     ac4:      	fmul.4s	v26, v6, v6
     ac8:      	and.16b	v5, v0, v4
     acc:      	and.16b	v4, v1, v17
     ad0:      	str	q18, [x23, #0x1b80]
     ad4:      	str	q21, [x23, #0x1b90]
     ad8:      	str	q23, [x23, #0x1ba0]
     adc:      	str	q24, [x23, #0x1bb0]
     ae0:      	and.16b	v18, v0, v16
     ae4:      	and.16b	v17, v1, v19
     ae8:      	and.16b	v6, v0, v7
     aec:      	and.16b	v19, v1, v22
     af0:      	and.16b	v16, v0, v26
     af4:      	and.16b	v7, v1, v25
     af8:      	ldr	x5, [sp, #0x40]
     afc:      	ldr	x6, [sp, #0x20]
     b00:      	ldp	q21, q22, [x5, #-0x60]
     b04:      	and.16b	v22, v0, v22
     b08:      	and.16b	v21, v1, v21
     b0c:      	fsub.4s	v21, v21, v20
     b10:      	fsub.4s	v22, v22, v20
     b14:      	ldp	q23, q24, [x6, #-0x60]
     b18:      	bit.16b	v24, v22, v0
     b1c:      	bit.16b	v23, v21, v1
     b20:      	stp	q23, q24, [x6, #-0x60]
     b24:      	fmul.4s	v22, v22, v22
     b28:      	fmul.4s	v21, v21, v21
     b2c:      	fadd.4s	v21, v4, v21
     b30:      	fadd.4s	v22, v5, v22
     b34:      	ldp	q23, q24, [x5, #-0x40]
     b38:      	and.16b	v24, v0, v24
     b3c:      	and.16b	v23, v1, v23
     b40:      	fsub.4s	v23, v23, v20
     b44:      	fsub.4s	v24, v24, v20
     b48:      	ldp	q25, q26, [x6, #-0x40]
     b4c:      	bit.16b	v26, v24, v0
     b50:      	bit.16b	v25, v23, v1
     b54:      	stp	q25, q26, [x6, #-0x40]
     b58:      	fmul.4s	v24, v24, v24
     b5c:      	fmul.4s	v23, v23, v23
     b60:      	fadd.4s	v23, v17, v23
     b64:      	fadd.4s	v24, v18, v24
     b68:      	ldp	q25, q26, [x5, #-0x20]
     b6c:      	and.16b	v26, v0, v26
     b70:      	and.16b	v25, v1, v25
     b74:      	fsub.4s	v25, v25, v20
     b78:      	fsub.4s	v26, v26, v20
     b7c:      	ldp	q27, q28, [x6, #-0x20]
     b80:      	bit.16b	v28, v26, v0
     b84:      	bit.16b	v27, v25, v1
     b88:      	stp	q27, q28, [x6, #-0x20]
     b8c:      	fmul.4s	v26, v26, v26
     b90:      	fmul.4s	v25, v25, v25
     b94:      	fadd.4s	v25, v19, v25
     b98:      	fadd.4s	v26, v6, v26
     b9c:      	ldp	q27, q28, [x5], #0x80
     ba0:      	and.16b	v28, v0, v28
     ba4:      	and.16b	v27, v1, v27
     ba8:      	fsub.4s	v27, v27, v20
     bac:      	fsub.4s	v28, v28, v20
     bb0:      	ldp	q29, q30, [x6]
     bb4:      	bit.16b	v30, v28, v0
     bb8:      	bit.16b	v29, v27, v1
     bbc:      	stp	q29, q30, [x6], #0x80
     bc0:      	fmul.4s	v28, v28, v28
     bc4:      	fmul.4s	v27, v27, v27
     bc8:      	fadd.4s	v27, v7, v27
     bcc:      	fadd.4s	v28, v16, v28
     bd0:      	bit.16b	v5, v22, v0
     bd4:      	bit.16b	v4, v21, v1
     bd8:      	bit.16b	v18, v24, v0
     bdc:      	bit.16b	v17, v23, v1
     be0:      	bit.16b	v6, v26, v0
     be4:      	bit.16b	v19, v25, v1
     be8:      	bit.16b	v16, v28, v0
     bec:      	bit.16b	v7, v27, v1
     bf0:      	add	x4, x4, #0x4
     bf4:      	cmp	x4, #0x5c
     bf8:      	b.lo	0xb00 <_llm_rows.packet_batch.blocks+0x7a0>
     bfc:      	mov	x4, #0x0                ; =0
     c00:      	b	0xc24 <_llm_rows.packet_batch.blocks+0x8c4>
     c04:      	add	x5, x28, x4
     c08:      	ldp	q22, q23, [x5]
     c0c:      	bif.16b	v21, v23, v0
     c10:      	bif.16b	v20, v22, v1
     c14:      	stp	q20, q21, [x5]
     c18:      	add	x4, x4, #0x20
     c1c:      	cmp	x4, #0xc00
     c20:      	b.eq	0xcbc <_llm_rows.packet_batch.blocks+0x95c>
     c24:      	fmov	w6, s2
     c28:      	add	x5, x3, x4
     c2c:      	movi.2d	v20, #0000000000000000
     c30:      	movi.2d	v21, #0000000000000000
     c34:      	tbnz	w6, #0x0, 0xc5c <_llm_rows.packet_batch.blocks+0x8fc>
     c38:      	and	w6, w6, #0xff
     c3c:      	tbnz	w6, #0x1, 0xc68 <_llm_rows.packet_batch.blocks+0x908>
     c40:      	tbnz	w6, #0x2, 0xc74 <_llm_rows.packet_batch.blocks+0x914>
     c44:      	tbnz	w6, #0x3, 0xc80 <_llm_rows.packet_batch.blocks+0x920>
     c48:      	tbnz	w6, #0x4, 0xc8c <_llm_rows.packet_batch.blocks+0x92c>
     c4c:      	tbnz	w6, #0x5, 0xc98 <_llm_rows.packet_batch.blocks+0x938>
     c50:      	tbnz	w6, #0x6, 0xca4 <_llm_rows.packet_batch.blocks+0x944>
     c54:      	tbz	w6, #0x7, 0xc04 <_llm_rows.packet_batch.blocks+0x8a4>
     c58:      	b	0xcb0 <_llm_rows.packet_batch.blocks+0x950>
     c5c:      	ldr	s20, [x5]
     c60:      	and	w6, w6, #0xff
     c64:      	tbz	w6, #0x1, 0xc40 <_llm_rows.packet_batch.blocks+0x8e0>
     c68:      	add	x19, x5, #0x4
     c6c:      	ld1.s	{ v20 }[1], [x19]
     c70:      	tbz	w6, #0x2, 0xc44 <_llm_rows.packet_batch.blocks+0x8e4>
     c74:      	add	x19, x5, #0x8
     c78:      	ld1.s	{ v20 }[2], [x19]
     c7c:      	tbz	w6, #0x3, 0xc48 <_llm_rows.packet_batch.blocks+0x8e8>
     c80:      	add	x19, x5, #0xc
     c84:      	ld1.s	{ v20 }[3], [x19]
     c88:      	tbz	w6, #0x4, 0xc4c <_llm_rows.packet_batch.blocks+0x8ec>
     c8c:      	add	x19, x5, #0x10
     c90:      	ld1.s	{ v21 }[0], [x19]
     c94:      	tbz	w6, #0x5, 0xc50 <_llm_rows.packet_batch.blocks+0x8f0>
     c98:      	add	x19, x5, #0x14
     c9c:      	ld1.s	{ v21 }[1], [x19]
     ca0:      	tbz	w6, #0x6, 0xc54 <_llm_rows.packet_batch.blocks+0x8f4>
     ca4:      	add	x19, x5, #0x18
     ca8:      	ld1.s	{ v21 }[2], [x19]
     cac:      	tbz	w6, #0x7, 0xc04 <_llm_rows.packet_batch.blocks+0x8a4>
     cb0:      	add	x5, x5, #0x1c
     cb4:      	ld1.s	{ v21 }[3], [x5]
     cb8:      	b	0xc04 <_llm_rows.packet_batch.blocks+0x8a4>
     cbc:      	mov	x3, #0x0                ; =0
     cc0:      	b	0xce4 <_llm_rows.packet_batch.blocks+0x984>
     cc4:      	add	x4, x21, x3
     cc8:      	ldp	q22, q23, [x4]
     ccc:      	bif.16b	v21, v23, v0
     cd0:      	bif.16b	v20, v22, v1
     cd4:      	stp	q20, q21, [x4]
     cd8:      	add	x3, x3, #0x20
     cdc:      	cmp	x3, #0xc00
     ce0:      	b.eq	0xd7c <_llm_rows.packet_batch.blocks+0xa1c>
     ce4:      	fmov	w5, s2
     ce8:      	add	x4, x11, x3
     cec:      	movi.2d	v20, #0000000000000000
     cf0:      	movi.2d	v21, #0000000000000000
     cf4:      	tbnz	w5, #0x0, 0xd1c <_llm_rows.packet_batch.blocks+0x9bc>
     cf8:      	and	w5, w5, #0xff
     cfc:      	tbnz	w5, #0x1, 0xd28 <_llm_rows.packet_batch.blocks+0x9c8>
     d00:      	tbnz	w5, #0x2, 0xd34 <_llm_rows.packet_batch.blocks+0x9d4>
     d04:      	tbnz	w5, #0x3, 0xd40 <_llm_rows.packet_batch.blocks+0x9e0>
     d08:      	tbnz	w5, #0x4, 0xd4c <_llm_rows.packet_batch.blocks+0x9ec>
     d0c:      	tbnz	w5, #0x5, 0xd58 <_llm_rows.packet_batch.blocks+0x9f8>
     d10:      	tbnz	w5, #0x6, 0xd64 <_llm_rows.packet_batch.blocks+0xa04>
     d14:      	tbz	w5, #0x7, 0xcc4 <_llm_rows.packet_batch.blocks+0x964>
     d18:      	b	0xd70 <_llm_rows.packet_batch.blocks+0xa10>
     d1c:      	ldr	s20, [x4]
     d20:      	and	w5, w5, #0xff
     d24:      	tbz	w5, #0x1, 0xd00 <_llm_rows.packet_batch.blocks+0x9a0>
     d28:      	add	x6, x4, #0x4
     d2c:      	ld1.s	{ v20 }[1], [x6]
     d30:      	tbz	w5, #0x2, 0xd04 <_llm_rows.packet_batch.blocks+0x9a4>
     d34:      	add	x6, x4, #0x8
     d38:      	ld1.s	{ v20 }[2], [x6]
     d3c:      	tbz	w5, #0x3, 0xd08 <_llm_rows.packet_batch.blocks+0x9a8>
     d40:      	add	x6, x4, #0xc
     d44:      	ld1.s	{ v20 }[3], [x6]
     d48:      	tbz	w5, #0x4, 0xd0c <_llm_rows.packet_batch.blocks+0x9ac>
     d4c:      	add	x6, x4, #0x10
     d50:      	ld1.s	{ v21 }[0], [x6]
     d54:      	tbz	w5, #0x5, 0xd10 <_llm_rows.packet_batch.blocks+0x9b0>
     d58:      	add	x6, x4, #0x14
     d5c:      	ld1.s	{ v21 }[1], [x6]
     d60:      	tbz	w5, #0x6, 0xd14 <_llm_rows.packet_batch.blocks+0x9b4>
     d64:      	add	x6, x4, #0x18
     d68:      	ld1.s	{ v21 }[2], [x6]
     d6c:      	tbz	w5, #0x7, 0xcc4 <_llm_rows.packet_batch.blocks+0x964>
     d70:      	add	x4, x4, #0x1c
     d74:      	ld1.s	{ v21 }[3], [x4]
     d78:      	b	0xcc4 <_llm_rows.packet_batch.blocks+0x964>
     d7c:      	mov	x11, #0x0               ; =0
     d80:      	adrp	x3, 0x0 <ltmp0>
     d84:      	ldr	q20, [x3]
     d88:      	and.16b	v21, v0, v20
     d8c:      	adrp	x3, 0x0 <ltmp0>
     d90:      	ldr	q20, [x3]
     d94:      	and.16b	v22, v1, v20
     d98:      	adrp	x3, 0x0 <ltmp0>
     d9c:      	ldr	q20, [x3]
     da0:      	and.16b	v20, v1, v20
     da4:      	fadd.4s	v5, v5, v18
     da8:      	fadd.4s	v4, v4, v17
     dac:      	fadd.4s	v17, v4, v19
     db0:      	fadd.4s	v4, v5, v6
     db4:      	fadd.4s	v4, v4, v16
     db8:      	fadd.4s	v5, v17, v7
     dbc:      	fmov	w3, s22
     dc0:      	add	x4, sp, #0x98
     dc4:      	bfxil	x4, x3, #0, #3
     dc8:      	str	d3, [sp, #0x98]
     dcc:      	ldrb	w4, [x4]
     dd0:      	add	x5, sp, #0x2c0
     dd4:      	orr	x3, x5, x3, lsl #2
     dd8:      	stp	q5, q4, [x23, #0x1a0]
     ddc:      	ldr	s3, [x3]
     de0:      	tst	w2, w4
     de4:      	fcsel	s6, s3, s8, ne
     de8:      	mov.s	w3, v22[1]
     dec:      	add	x4, sp, #0x98
     df0:      	bfxil	x4, x3, #0, #3
     df4:      	ldrb	w3, [x4]
     df8:      	and	w3, w12, w3
     dfc:      	str	q5, [x23, #0x180]
     e00:      	ldr	s3, [x23, #0x180]
     e04:      	tst	w3, #0x1
     e08:      	fcsel	s3, s3, s8, ne
     e0c:      	mov.s	w3, v22[2]
     e10:      	add	x4, sp, #0x98
     e14:      	bfxil	x4, x3, #0, #3
     e18:      	add	x5, sp, #0x280
     e1c:      	orr	x3, x5, x3, lsl #2
     e20:      	ldrb	w4, [x4]
     e24:      	and	w4, w13, w4
     e28:      	stp	q5, q4, [x23, #0x160]
     e2c:      	ldr	s7, [x3]
     e30:      	tst	w4, #0x1
     e34:      	fcsel	s7, s7, s8, ne
     e38:      	mov.s	w3, v22[3]
     e3c:      	add	x4, sp, #0x98
     e40:      	bfxil	x4, x3, #0, #3
     e44:      	add	x5, sp, #0x260
     e48:      	orr	x3, x5, x3, lsl #2
     e4c:      	ldrb	w4, [x4]
     e50:      	and	w4, w14, w4
     e54:      	stp	q5, q4, [x23, #0x140]
     e58:      	ldr	s16, [x3]
     e5c:      	tst	w4, #0x1
     e60:      	fcsel	s16, s16, s8, ne
     e64:      	fmov	w3, s21
     e68:      	add	x4, sp, #0x98
     e6c:      	bfxil	x4, x3, #0, #3
     e70:      	ldrb	w4, [x4]
     e74:      	and	w4, w15, w4
     e78:      	stp	q5, q4, [x23, #0x120]
     e7c:      	add	x5, sp, #0x240
     e80:      	ldr	s17, [x5, w3, uxtw #2]
     e84:      	tst	w4, #0x1
     e88:      	fcsel	s17, s17, s8, ne
     e8c:      	mov.s	w3, v21[1]
     e90:      	add	x4, sp, #0x98
     e94:      	bfxil	x4, x3, #0, #3
     e98:      	ldrb	w4, [x4]
     e9c:      	and	w4, w16, w4
     ea0:      	stp	q5, q4, [x23, #0x100]
     ea4:      	add	x5, sp, #0x220
     ea8:      	ldr	s18, [x5, w3, uxtw #2]
     eac:      	tst	w4, #0x1
     eb0:      	fcsel	s18, s18, s8, ne
     eb4:      	mov.s	w3, v21[2]
     eb8:      	add	x4, sp, #0x98
     ebc:      	bfxil	x4, x3, #0, #3
     ec0:      	ldrb	w4, [x4]
     ec4:      	and	w4, w17, w4
     ec8:      	stp	q5, q4, [x23, #0xe0]
     ecc:      	add	x5, sp, #0x200
     ed0:      	ldr	s19, [x5, w3, uxtw #2]
     ed4:      	tst	w4, #0x1
     ed8:      	fcsel	s19, s19, s8, ne
     edc:      	mov.s	w3, v21[3]
     ee0:      	add	x4, sp, #0x98
     ee4:      	bfxil	x4, x3, #0, #3
     ee8:      	ldrb	w4, [x4]
     eec:      	and	w4, w0, w4
     ef0:      	stp	q5, q4, [x23, #0xc0]
     ef4:      	add	x5, sp, #0x1e0
     ef8:      	ldr	s21, [x5, w3, uxtw #2]
     efc:      	tst	w4, #0x1
     f00:      	fcsel	s21, s21, s8, ne
     f04:      	mov.s	v6[1], v3[0]
     f08:      	mov.s	v6[2], v7[0]
     f0c:      	mov.s	v6[3], v16[0]
     f10:      	mov.s	v17[1], v18[0]
     f14:      	mov.s	v17[2], v19[0]
     f18:      	mov.s	v17[3], v21[0]
     f1c:      	fadd.4s	v3, v4, v17
     f20:      	fadd.4s	v4, v5, v6
     f24:      	fmov	w3, s20
     f28:      	add	x4, sp, #0x98
     f2c:      	bfxil	x4, x3, #0, #3
     f30:      	ldrb	w4, [x4]
     f34:      	add	x5, sp, #0x1c0
     f38:      	orr	x3, x5, x3, lsl #2
     f3c:      	stp	q4, q3, [x23, #0xa0]
     f40:      	ldr	s5, [x3]
     f44:      	mov.s	w3, v20[1]
     f48:      	tst	w2, w4
     f4c:      	add	x4, sp, #0x98
     f50:      	bfxil	x4, x3, #0, #3
     f54:      	ldrb	w4, [x4]
     f58:      	and	w12, w12, w4
     f5c:      	fcsel	s5, s5, s8, ne
     f60:      	add	x4, sp, #0x1a0
     f64:      	orr	x3, x4, x3, lsl #2
     f68:      	stp	q4, q3, [x23, #0x80]
     f6c:      	ldr	s7, [x3]
     f70:      	mov.s	w3, v20[2]
     f74:      	tst	w12, #0x1
     f78:      	add	x12, sp, #0x98
     f7c:      	bfxil	x12, x3, #0, #3
     f80:      	adrp	x3, 0x0 <ltmp0>
     f84:      	ldr	q6, [x3]
     f88:      	and.16b	v18, v0, v6
     f8c:      	movi.4s	v6, #0x4
     f90:      	and.16b	v6, v1, v6
     f94:      	fcsel	s7, s7, s8, ne
     f98:      	ldrb	w12, [x12]
     f9c:      	and	w12, w13, w12
     fa0:      	str	q4, [x23, #0x60]
     fa4:      	ldr	s16, [x23, #0x60]
     fa8:      	tst	w12, #0x1
     fac:      	fcsel	s16, s16, s8, ne
     fb0:      	mov.s	w12, v20[3]
     fb4:      	add	x13, sp, #0x98
     fb8:      	bfxil	x13, x12, #0, #3
     fbc:      	add	x3, sp, #0x160
     fc0:      	orr	x12, x3, x12, lsl #2
     fc4:      	ldrb	w13, [x13]
     fc8:      	and	w13, w14, w13
     fcc:      	stp	q4, q3, [x23, #0x40]
     fd0:      	ldr	s17, [x12]
     fd4:      	tst	w13, #0x1
     fd8:      	fcsel	s17, s17, s8, ne
     fdc:      	fmov	w12, s18
     fe0:      	add	x13, sp, #0x98
     fe4:      	bfxil	x13, x12, #0, #3
     fe8:      	ldrb	w13, [x13]
     fec:      	and	w13, w15, w13
     ff0:      	stp	q4, q3, [x23, #0x20]
     ff4:      	add	x14, sp, #0x140
     ff8:      	ldr	s19, [x14, w12, uxtw #2]
     ffc:      	tst	w13, #0x1
    1000:      	fcsel	s19, s19, s8, ne
    1004:      	mov.s	w12, v18[1]
    1008:      	add	x13, sp, #0x98
    100c:      	bfxil	x13, x12, #0, #3
    1010:      	ldrb	w13, [x13]
    1014:      	and	w13, w16, w13
    1018:      	stp	q4, q3, [x23]
    101c:      	ldr	s20, [x23, w12, uxtw #2]
    1020:      	tst	w13, #0x1
    1024:      	fcsel	s20, s20, s8, ne
    1028:      	mov.s	w12, v18[2]
    102c:      	add	x13, sp, #0x98
    1030:      	bfxil	x13, x12, #0, #3
    1034:      	ldrb	w13, [x13]
    1038:      	and	w13, w17, w13
    103c:      	stp	q4, q3, [sp, #0x100]
    1040:      	add	x14, sp, #0x100
    1044:      	ldr	s21, [x14, w12, uxtw #2]
    1048:      	tst	w13, #0x1
    104c:      	fcsel	s21, s21, s8, ne
    1050:      	mov.s	w12, v18[3]
    1054:      	add	x13, sp, #0x98
    1058:      	bfxil	x13, x12, #0, #3
    105c:      	ldrb	w13, [x13]
    1060:      	and	w13, w0, w13
    1064:      	stp	q4, q3, [sp, #0xe0]
    1068:      	add	x14, sp, #0xe0
    106c:      	ldr	s18, [x14, w12, uxtw #2]
    1070:      	tst	w13, #0x1
    1074:      	fcsel	s18, s18, s8, ne
    1078:      	mov.s	v19[1], v20[0]
    107c:      	mov.s	v19[2], v21[0]
    1080:      	mov.s	v19[3], v18[0]
    1084:      	mov.s	v5[1], v7[0]
    1088:      	mov.s	v5[2], v16[0]
    108c:      	mov.s	v5[3], v17[0]
    1090:      	fadd.4s	v4, v4, v5
    1094:      	fadd.4s	v3, v3, v19
    1098:      	fmov	w12, s6
    109c:      	add	x13, sp, #0x98
    10a0:      	orr	x13, x13, x12
    10a4:      	ldrb	w13, [x13]
    10a8:      	stp	q4, q3, [sp, #0xc0]
    10ac:      	add	x14, sp, #0xc0
    10b0:      	ldr	s3, [x14, w12, uxtw #2]
    10b4:      	tst	w2, w13
    10b8:      	fcsel	s3, s3, s8, ne
    10bc:      	tst	w10, #0x1
    10c0:      	fadd	s3, s4, s3
    10c4:      	fcsel	s4, s3, s8, ne
    10c8:      	ldr	w10, [sp, #0x2c]
    10cc:      	tst	w10, #0x1
    10d0:      	fcsel	s5, s3, s8, ne
    10d4:      	ldr	w10, [sp, #0x28]
    10d8:      	tst	w10, #0x1
    10dc:      	fcsel	s6, s3, s8, ne
    10e0:      	tst	w24, #0x1
    10e4:      	fcsel	s7, s3, s8, ne
    10e8:      	tst	w1, #0x1
    10ec:      	fcsel	s16, s3, s8, ne
    10f0:      	tst	w7, #0x1
    10f4:      	fcsel	s17, s3, s8, ne
    10f8:      	tst	w30, #0x1
    10fc:      	fcsel	s18, s3, s8, ne
    1100:      	tst	w9, #0x1
    1104:      	fcsel	s3, s3, s8, ne
    1108:      	mov.s	v4[1], v5[0]
    110c:      	mov.s	v4[2], v6[0]
    1110:      	mov.s	v4[3], v7[0]
    1114:      	mov.s	v16[1], v17[0]
    1118:      	mov.s	v16[2], v18[0]
    111c:      	mov.s	v16[3], v3[0]
    1120:      	stp	q4, q16, [sp, #0xa0]
    1124:      	and	x8, x8, #0x7
    1128:      	add	x9, sp, #0xa0
    112c:      	ldr	s3, [x9, x8, lsl #2]
    1130:      	fadd	s3, s3, s8
    1134:      	mov	w8, #0x44400000         ; =1145044992
    1138:      	fmov	s4, w8
    113c:      	fdiv	s3, s3, s4
    1140:      	mov	w8, #0xc5ac             ; =50604
    1144:      	movk	w8, #0x3727, lsl #16
    1148:      	fmov	s4, w8
    114c:      	fadd	s3, s3, s4
    1150:      	fsqrt	s3, s3
    1154:      	ldp	x9, x8, [sp, #0x30]
    1158:      	add	x8, x8, x9
    115c:      	dup.4s	v3, v3[0]
    1160:      	add	x13, sp, #0x1, lsl #12  ; =0x1000
    1164:      	add	x13, x13, #0xc60
    1168:      	b	0x1178 <_llm_rows.packet_batch.blocks+0xe18>
    116c:      	add	x11, x11, #0x20
    1170:      	cmp	x11, #0xc00
    1174:      	b.eq	0x40c <_llm_rows.packet_batch.blocks+0xac>
    1178:      	fmov	w10, s2
    117c:      	add	x9, x13, x11
    1180:      	ldp	q5, q4, [x9]
    1184:      	and.16b	v5, v1, v5
    1188:      	fdiv.4s	v6, v5, v3
    118c:      	add	x9, x28, x11
    1190:      	ldp	q7, q5, [x9]
    1194:      	and.16b	v7, v1, v7
    1198:      	fmul.4s	v7, v6, v7
    119c:      	add	x9, x21, x11
    11a0:      	ldp	q16, q6, [x9]
    11a4:      	and.16b	v16, v1, v16
    11a8:      	fadd.4s	v7, v7, v16
    11ac:      	add	x9, x8, x11
    11b0:      	tbnz	w10, #0x0, 0x11f8 <_llm_rows.packet_batch.blocks+0xe98>
    11b4:      	and	w10, w10, #0xff
    11b8:      	tbnz	w10, #0x1, 0x1204 <_llm_rows.packet_batch.blocks+0xea4>
    11bc:      	tbnz	w10, #0x2, 0x1210 <_llm_rows.packet_batch.blocks+0xeb0>
    11c0:      	tbz	w10, #0x3, 0x11cc <_llm_rows.packet_batch.blocks+0xe6c>
    11c4:      	add	x12, x9, #0xc
    11c8:      	st1.s	{ v7 }[3], [x12]
    11cc:      	and.16b	v4, v0, v4
    11d0:      	fdiv.4s	v4, v4, v3
    11d4:      	and.16b	v5, v0, v5
    11d8:      	fmul.4s	v4, v4, v5
    11dc:      	and.16b	v5, v0, v6
    11e0:      	fadd.4s	v4, v4, v5
    11e4:      	tbnz	w10, #0x4, 0x1220 <_llm_rows.packet_batch.blocks+0xec0>
    11e8:      	tbnz	w10, #0x5, 0x1228 <_llm_rows.packet_batch.blocks+0xec8>
    11ec:      	tbnz	w10, #0x6, 0x1234 <_llm_rows.packet_batch.blocks+0xed4>
    11f0:      	tbz	w10, #0x7, 0x116c <_llm_rows.packet_batch.blocks+0xe0c>
    11f4:      	b	0x1240 <_llm_rows.packet_batch.blocks+0xee0>
    11f8:      	str	s7, [x9]
    11fc:      	and	w10, w10, #0xff
    1200:      	tbz	w10, #0x1, 0x11bc <_llm_rows.packet_batch.blocks+0xe5c>
    1204:      	add	x12, x9, #0x4
    1208:      	st1.s	{ v7 }[1], [x12]
    120c:      	tbz	w10, #0x2, 0x11c0 <_llm_rows.packet_batch.blocks+0xe60>
    1210:      	add	x12, x9, #0x8
    1214:      	st1.s	{ v7 }[2], [x12]
    1218:      	tbnz	w10, #0x3, 0x11c4 <_llm_rows.packet_batch.blocks+0xe64>
    121c:      	b	0x11cc <_llm_rows.packet_batch.blocks+0xe6c>
    1220:      	str	s4, [x9, #0x10]
    1224:      	tbz	w10, #0x5, 0x11ec <_llm_rows.packet_batch.blocks+0xe8c>
    1228:      	add	x12, x9, #0x14
    122c:      	st1.s	{ v4 }[1], [x12]
    1230:      	tbz	w10, #0x6, 0x11f0 <_llm_rows.packet_batch.blocks+0xe90>
    1234:      	add	x12, x9, #0x18
    1238:      	st1.s	{ v4 }[2], [x12]
    123c:      	tbz	w10, #0x7, 0x116c <_llm_rows.packet_batch.blocks+0xe0c>
    1240:      	add	x9, x9, #0x1c
    1244:      	st1.s	{ v4 }[3], [x9]
    1248:      	b	0x116c <_llm_rows.packet_batch.blocks+0xe0c>
    124c:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
    1250:      	add	sp, sp, #0x460
    1254:      	ldp	x29, x30, [sp, #0x60]
    1258:      	ldp	x20, x19, [sp, #0x50]
    125c:      	ldp	x22, x21, [sp, #0x40]
    1260:      	ldp	x24, x23, [sp, #0x30]
    1264:      	ldp	x26, x25, [sp, #0x20]
    1268:      	ldp	x28, x27, [sp, #0x10]
    126c:      	ldp	d9, d8, [sp], #0x70
    1270:      	ret

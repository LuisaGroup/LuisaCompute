
/private/tmp/luisa-expression-fusion.qXgTbC/capture/layernorm-129x768/off/object/tile_xir_w8_23340_1788930262105070_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	x24, x23, [sp, #-0x40]!
       4:      	stp	x22, x21, [sp, #0x10]
       8:      	stp	x20, x19, [sp, #0x20]
       c:      	stp	x29, x30, [sp, #0x30]
      10:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
      14:      	sub	sp, sp, #0x80
      18:      	ldr	x8, [x0]
      1c:      	ldr	x20, [x0, #0x10]
      20:      	ldr	x19, [x0, #0x20]
      24:      	ldr	x21, [x0, #0x30]
      28:      	ldr	w9, [x1]
      2c:      	ldr	w10, [x1, #0x24]
      30:      	add	w9, w10, w9, lsl #5
      34:      	lsr	w9, w9, #3
      38:      	mov	w10, #0xc00             ; =3072
      3c:      	umull	x22, w9, w10
      40:      	umaddl	x1, w9, w10, x8
      44:      	add	x23, sp, #0x2, lsl #12  ; =0x2000
      48:      	add	x23, x23, #0x480
      4c:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
      50:      	add	x0, x0, #0x480
      54:      	mov	w2, #0xc00              ; =3072
      58:      	bl	0x58 <ltmp0+0x58>
      5c:      	ldr	q0, [sp, #0x2490]
      60:      	ldr	q2, [sp, #0x2480]
      64:      	ldr	q1, [sp, #0x24b0]
      68:      	ldr	q5, [sp, #0x24a0]
      6c:      	ldr	q4, [sp, #0x24d0]
      70:      	ldr	q3, [sp, #0x24c0]
      74:      	add	x8, x23, #0xe0
      78:      	mov	w9, #0x4                ; =4
      7c:      	ldr	q6, [sp, #0x24f0]
      80:      	ldr	q7, [sp, #0x24e0]
      84:      	ldp	q16, q17, [x8, #-0x60]
      88:      	fadd.4s	v0, v0, v17
      8c:      	fadd.4s	v2, v2, v16
      90:      	ldp	q16, q17, [x8, #-0x40]
      94:      	fadd.4s	v1, v1, v17
      98:      	fadd.4s	v5, v5, v16
      9c:      	ldp	q16, q17, [x8, #-0x20]
      a0:      	fadd.4s	v4, v4, v17
      a4:      	fadd.4s	v3, v3, v16
      a8:      	ldp	q16, q17, [x8], #0x80
      ac:      	fadd.4s	v6, v6, v17
      b0:      	fadd.4s	v7, v7, v16
      b4:      	cmp	x9, #0x5c
      b8:      	add	x9, x9, #0x4
      bc:      	b.lo	0x84 <ltmp0+0x84>
      c0:      	mov	x8, #0x0                ; =0
      c4:      	fadd.4s	v2, v2, v5
      c8:      	fadd.4s	v0, v0, v1
      cc:      	fadd.4s	v0, v0, v4
      d0:      	fadd.4s	v1, v2, v3
      d4:      	fadd.4s	v1, v1, v7
      d8:      	fadd.4s	v0, v0, v6
      dc:      	rev64.4s	v2, v0
      e0:      	rev64.4s	v3, v1
      e4:      	fadd.4s	v1, v1, v3
      e8:      	fadd.4s	v0, v0, v2
      ec:      	dup.4s	v2, v0[2]
      f0:      	dup.4s	v3, v1[2]
      f4:      	fadd.4s	v1, v1, v3
      f8:      	fadd.4s	v0, v0, v2
      fc:      	fadd.4s	v0, v1, v0
     100:      	movi	d1, #0000000000000000
     104:      	fadd	s0, s0, s1
     108:      	mov	w9, #0x44400000         ; =1145044992
     10c:      	fmov	s1, w9
     110:      	fdiv	s0, s0, s1
     114:      	dup.4s	v0, v0[0]
     118:      	add	x9, sp, #0x2, lsl #12   ; =0x2000
     11c:      	add	x9, x9, #0x480
     120:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
     124:      	add	x10, x10, #0x880
     128:      	add	x11, x9, x8
     12c:      	ldp	q2, q1, [x11]
     130:      	fsub.4s	v2, v2, v0
     134:      	fsub.4s	v1, v1, v0
     138:      	add	x11, x10, x8
     13c:      	stp	q2, q1, [x11]
     140:      	add	x8, x8, #0x20
     144:      	cmp	x8, #0xc00
     148:      	b.ne	0x128 <ltmp0+0x128>
     14c:      	ldr	q0, [sp, #0x1880]
     150:      	ldr	q1, [sp, #0x1890]
     154:      	fmul.4s	v6, v1, v1
     158:      	fmul.4s	v7, v0, v0
     15c:      	ldr	q0, [sp, #0x18a0]
     160:      	ldr	q1, [sp, #0x18b0]
     164:      	fmul.4s	v16, v1, v1
     168:      	fmul.4s	v17, v0, v0
     16c:      	ldr	q0, [sp, #0x18c0]
     170:      	ldr	q1, [sp, #0x18d0]
     174:      	fmul.4s	v3, v1, v1
     178:      	fmul.4s	v2, v0, v0
     17c:      	ldr	q0, [sp, #0x18e0]
     180:      	ldr	q1, [sp, #0x18f0]
     184:      	fmul.4s	v4, v1, v1
     188:      	fmul.4s	v5, v0, v0
     18c:      	add	x8, sp, #0x1, lsl #12   ; =0x1000
     190:      	add	x8, x8, #0x880
     194:      	add	x8, x8, #0xe0
     198:      	mov	w9, #0x4                ; =4
     19c:      	ldp	q1, q0, [x8, #-0x60]
     1a0:      	fmul.4s	v1, v1, v1
     1a4:      	fmul.4s	v0, v0, v0
     1a8:      	fadd.4s	v6, v6, v0
     1ac:      	fadd.4s	v7, v7, v1
     1b0:      	ldp	q1, q0, [x8, #-0x40]
     1b4:      	fmul.4s	v1, v1, v1
     1b8:      	fmul.4s	v0, v0, v0
     1bc:      	fadd.4s	v16, v16, v0
     1c0:      	fadd.4s	v17, v17, v1
     1c4:      	ldp	q1, q0, [x8, #-0x20]
     1c8:      	fmul.4s	v1, v1, v1
     1cc:      	fmul.4s	v0, v0, v0
     1d0:      	fadd.4s	v3, v3, v0
     1d4:      	fadd.4s	v2, v2, v1
     1d8:      	ldp	q1, q0, [x8], #0x80
     1dc:      	fmul.4s	v1, v1, v1
     1e0:      	fmul.4s	v0, v0, v0
     1e4:      	fadd.4s	v4, v4, v0
     1e8:      	fadd.4s	v5, v5, v1
     1ec:      	cmp	x9, #0x5c
     1f0:      	add	x9, x9, #0x4
     1f4:      	b.lo	0x19c <ltmp0+0x19c>
     1f8:      	add	x23, sp, #0xc80
     1fc:      	add	x0, sp, #0xc80
     200:      	mov	x1, x20
     204:      	mov	w2, #0xc00              ; =3072
     208:      	stp	q2, q4, [sp, #0x60]
     20c:      	stp	q3, q5, [sp, #0x40]
     210:      	stp	q16, q6, [sp, #0x20]
     214:      	stp	q17, q7, [sp]
     218:      	bl	0x218 <ltmp0+0x218>
     21c:      	add	x20, sp, #0x80
     220:      	add	x0, sp, #0x80
     224:      	mov	x1, x19
     228:      	mov	w2, #0xc00              ; =3072
     22c:      	bl	0x22c <ltmp0+0x22c>
     230:      	mov	x8, #0x0                ; =0
     234:      	ldp	q1, q0, [sp]
     238:      	fadd.4s	v0, v0, v1
     23c:      	ldp	q2, q1, [sp, #0x20]
     240:      	fadd.4s	v1, v1, v2
     244:      	mov	w9, #0x44400000         ; =1145044992
     248:      	fmov	s2, w9
     24c:      	mov	w9, #0xc5ac             ; =50604
     250:      	movk	w9, #0x3727, lsl #16
     254:      	fmov	s3, w9
     258:      	ldr	q4, [sp, #0x40]
     25c:      	fadd.4s	v1, v1, v4
     260:      	ldp	q4, q5, [sp, #0x50]
     264:      	fadd.4s	v0, v0, v5
     268:      	fadd.4s	v0, v0, v4
     26c:      	ldr	q4, [sp, #0x70]
     270:      	fadd.4s	v1, v1, v4
     274:      	rev64.4s	v4, v1
     278:      	rev64.4s	v5, v0
     27c:      	fadd.4s	v0, v0, v5
     280:      	fadd.4s	v1, v1, v4
     284:      	dup.4s	v4, v1[2]
     288:      	dup.4s	v5, v0[2]
     28c:      	fadd.4s	v0, v0, v5
     290:      	fadd.4s	v1, v1, v4
     294:      	fadd.4s	v0, v0, v1
     298:      	movi	d1, #0000000000000000
     29c:      	fadd	s0, s0, s1
     2a0:      	fdiv	s0, s0, s2
     2a4:      	fadd	s0, s0, s3
     2a8:      	fsqrt	s0, s0
     2ac:      	dup.4s	v0, v0[0]
     2b0:      	add	x9, x21, x22
     2b4:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
     2b8:      	add	x10, x10, #0x880
     2bc:      	add	x11, x10, x8
     2c0:      	ldp	q2, q1, [x11]
     2c4:      	fdiv.4s	v2, v2, v0
     2c8:      	fdiv.4s	v1, v1, v0
     2cc:      	add	x11, x23, x8
     2d0:      	ldp	q3, q4, [x11]
     2d4:      	fmul.4s	v1, v1, v4
     2d8:      	fmul.4s	v2, v2, v3
     2dc:      	add	x11, x20, x8
     2e0:      	ldp	q4, q3, [x11]
     2e4:      	fadd.4s	v2, v2, v4
     2e8:      	fadd.4s	v1, v1, v3
     2ec:      	add	x11, x9, x8
     2f0:      	stp	q2, q1, [x11]
     2f4:      	add	x8, x8, #0x20
     2f8:      	cmp	x8, #0xc00
     2fc:      	b.ne	0x2bc <ltmp0+0x2bc>
     300:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
     304:      	add	sp, sp, #0x80
     308:      	ldp	x29, x30, [sp, #0x30]
     30c:      	ldp	x20, x19, [sp, #0x20]
     310:      	ldp	x22, x21, [sp, #0x10]
     314:      	ldp	x24, x23, [sp], #0x40
     318:      	ret

000000000000031c <_llm_rows.packet_batch.blocks>:
     31c:      	stp	d9, d8, [sp, #-0x70]!
     320:      	stp	x28, x27, [sp, #0x10]
     324:      	stp	x26, x25, [sp, #0x20]
     328:      	stp	x24, x23, [sp, #0x30]
     32c:      	stp	x22, x21, [sp, #0x40]
     330:      	stp	x20, x19, [sp, #0x50]
     334:      	stp	x29, x30, [sp, #0x60]
     338:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
     33c:      	sub	sp, sp, #0x460
     340:      	str	x0, [sp, #0x88]
     344:      	cbz	w3, 0x112c <_llm_rows.packet_batch.blocks+0xe10>
     348:      	mov	x26, x3
     34c:      	mov	x20, x2
     350:      	mov	w22, #0x0               ; =0
     354:      	add	x23, sp, #0x120
     358:      	add	x8, sp, #0x2, lsl #12   ; =0x2000
     35c:      	add	x8, x8, #0x860
     360:      	add	x9, x8, #0xe0
     364:      	ldp	w10, w8, [x2, #0x2c]
     368:      	stp	w8, w10, [sp, #0x80]
     36c:      	add	x8, sp, #0x1, lsl #12   ; =0x1000
     370:      	add	x8, x8, #0xc60
     374:      	add	x8, x8, #0xe0
     378:      	stp	x8, x9, [sp, #0x20]
     37c:      	ldp	w25, w13, [x2]
     380:      	ldp	w27, w8, [x2, #0x8]
     384:      	str	x8, [sp, #0x78]
     388:      	adrp	x8, 0x0 <ltmp0>
     38c:      	ldr	q0, [x8]
     390:      	str	q0, [sp, #0x10]
     394:      	adrp	x8, 0x0 <ltmp0>
     398:      	ldr	q0, [x8]
     39c:      	str	q0, [sp, #0x60]
     3a0:      	adrp	x8, 0x0 <ltmp0>
     3a4:      	ldr	q0, [x8]
     3a8:      	str	q0, [sp, #0x50]
     3ac:      	movi	d8, #0000000000000000
     3b0:      	add	x21, sp, #0x1, lsl #12  ; =0x1000
     3b4:      	add	x21, x21, #0x60
     3b8:      	add	x19, sp, #0x460
     3bc:      	str	w3, [sp, #0x4c]
     3c0:      	b	0x408 <_llm_rows.packet_batch.blocks+0xec>
     3c4:      	mov	w8, #0x18               ; =24
     3c8:      	str	w8, [x20, #0x24]
     3cc:      	ldr	w26, [sp, #0x4c]
     3d0:      	add	w8, w25, #0x1
     3d4:      	ldp	w10, w9, [sp, #0x80]
     3d8:      	cmp	w8, w9
     3dc:      	cset	w8, eq
     3e0:      	csinc	w25, wzr, w25, eq
     3e4:      	cinc	w9, w13, eq
     3e8:      	cmp	w9, w10
     3ec:      	cset	w10, eq
     3f0:      	ands	w8, w8, w10
     3f4:      	csel	w13, wzr, w9, ne
     3f8:      	add	w27, w27, w8
     3fc:      	add	w22, w22, #0x1
     400:      	cmp	w22, w26
     404:      	b.eq	0x112c <_llm_rows.packet_batch.blocks+0xe10>
     408:      	ubfiz	x8, x25, #5, #32
     40c:      	ldr	x12, [sp, #0x78]
     410:      	cmp	x8, x12
     414:      	csel	x9, x8, xzr, ls
     418:      	subs	x10, x12, x9
     41c:      	cmp	x10, #0x20
     420:      	mov	w11, #0x20              ; =32
     424:      	csel	x10, x10, x11, lo
     428:      	cmp	x12, x9
     42c:      	stp	w25, w13, [x20]
     430:      	str	w27, [x20, #0x8]
     434:      	str	wzr, [x20, #0x24]
     438:      	ccmp	x8, x12, #0x2, hi
     43c:      	csel	x24, x10, xzr, ls
     440:      	cmp	x24, #0x20
     444:      	b.lo	0x4a0 <_llm_rows.packet_batch.blocks+0x184>
     448:      	ldr	x24, [sp, #0x88]
     44c:      	mov	x0, x24
     450:      	mov	x1, x20
     454:      	mov	x28, x13
     458:      	bl	0x458 <_llm_rows.packet_batch.blocks+0x13c>
     45c:      	mov	w8, #0x8                ; =8
     460:      	str	w8, [x20, #0x24]
     464:      	mov	x0, x24
     468:      	mov	x1, x20
     46c:      	bl	0x46c <_llm_rows.packet_batch.blocks+0x150>
     470:      	mov	w8, #0x10               ; =16
     474:      	str	w8, [x20, #0x24]
     478:      	mov	x0, x24
     47c:      	mov	x1, x20
     480:      	bl	0x480 <_llm_rows.packet_batch.blocks+0x164>
     484:      	mov	w8, #0x18               ; =24
     488:      	str	w8, [x20, #0x24]
     48c:      	mov	x0, x24
     490:      	mov	x1, x20
     494:      	bl	0x494 <_llm_rows.packet_batch.blocks+0x178>
     498:      	mov	x13, x28
     49c:      	b	0x3d0 <_llm_rows.packet_batch.blocks+0xb4>
     4a0:      	lsr	x26, x24, #3
     4a4:      	cmp	x24, #0x8
     4a8:      	b.lo	0x504 <_llm_rows.packet_batch.blocks+0x1e8>
     4ac:      	str	wzr, [x20, #0x24]
     4b0:      	ldr	x0, [sp, #0x88]
     4b4:      	mov	x1, x20
     4b8:      	mov	x28, x13
     4bc:      	bl	0x4bc <_llm_rows.packet_batch.blocks+0x1a0>
     4c0:      	mov	x13, x28
     4c4:      	cmp	x26, #0x1
     4c8:      	b.eq	0x504 <_llm_rows.packet_batch.blocks+0x1e8>
     4cc:      	mov	w8, #0x8                ; =8
     4d0:      	str	w8, [x20, #0x24]
     4d4:      	ldr	x0, [sp, #0x88]
     4d8:      	mov	x1, x20
     4dc:      	bl	0x4dc <_llm_rows.packet_batch.blocks+0x1c0>
     4e0:      	mov	x13, x28
     4e4:      	cmp	x26, #0x2
     4e8:      	b.eq	0x504 <_llm_rows.packet_batch.blocks+0x1e8>
     4ec:      	mov	w8, #0x10               ; =16
     4f0:      	str	w8, [x20, #0x24]
     4f4:      	ldr	x0, [sp, #0x88]
     4f8:      	mov	x1, x20
     4fc:      	bl	0x4fc <_llm_rows.packet_batch.blocks+0x1e0>
     500:      	mov	x13, x28
     504:      	and	w8, w24, #0x7
     508:      	add	x28, sp, #0x1, lsl #12  ; =0x1000
     50c:      	add	x28, x28, #0xc60
     510:      	cbz	w8, 0x3c4 <_llm_rows.packet_batch.blocks+0xa8>
     514:      	dup.4s	v1, w8
     518:      	ldp	q0, q2, [sp, #0x50]
     51c:      	cmhi.4s	v0, v1, v0
     520:      	cmhi.4s	v1, v1, v2
     524:      	uzp1.8h	v3, v1, v0
     528:      	umaxv.8h	h2, v3
     52c:      	fmov	w8, s2
     530:      	tbz	w8, #0x0, 0x3c4 <_llm_rows.packet_batch.blocks+0xa8>
     534:      	str	w13, [sp, #0x48]
     538:      	mov	x10, #0x0               ; =0
     53c:      	ldr	x12, [sp, #0x88]
     540:      	ldr	x9, [x12, #0x10]
     544:      	ldr	x11, [x12, #0x20]
     548:      	ldr	x8, [x12, #0x30]
     54c:      	str	x8, [sp, #0x40]
     550:      	ldr	q2, [sp, #0x10]
     554:      	and.16b	v2, v3, v2
     558:      	addv.8h	h2, v2
     55c:      	fmov	w8, s2
     560:      	and	w8, w8, #0xff
     564:      	ldr	x12, [x12]
     568:      	ubfiz	w13, w25, #2, #27
     56c:      	orr	w13, w13, w26
     570:      	fmov	s4, w13
     574:      	and.16b	v4, v1, v4
     578:      	fmov	w13, s4
     57c:      	mov	w14, #0xc00             ; =3072
     580:      	umull	x15, w13, w14
     584:      	str	x15, [sp, #0x38]
     588:      	umaddl	x12, w13, w14, x12
     58c:      	fmov	w13, s2
     590:      	add	x5, sp, #0x2, lsl #12   ; =0x2000
     594:      	add	x5, x5, #0x860
     598:      	b	0x5bc <_llm_rows.packet_batch.blocks+0x2a0>
     59c:      	add	x14, x5, x10
     5a0:      	ldp	q6, q7, [x14]
     5a4:      	bif.16b	v5, v7, v0
     5a8:      	bif.16b	v4, v6, v1
     5ac:      	stp	q4, q5, [x14]
     5b0:      	add	x10, x10, #0x20
     5b4:      	cmp	x10, #0xc00
     5b8:      	b.eq	0x650 <_llm_rows.packet_batch.blocks+0x334>
     5bc:      	add	x14, x12, x10
     5c0:      	movi.2d	v4, #0000000000000000
     5c4:      	movi.2d	v5, #0000000000000000
     5c8:      	tbnz	w13, #0x0, 0x5f0 <_llm_rows.packet_batch.blocks+0x2d4>
     5cc:      	and	w15, w13, #0xff
     5d0:      	tbnz	w15, #0x1, 0x5fc <_llm_rows.packet_batch.blocks+0x2e0>
     5d4:      	tbnz	w15, #0x2, 0x608 <_llm_rows.packet_batch.blocks+0x2ec>
     5d8:      	tbnz	w15, #0x3, 0x614 <_llm_rows.packet_batch.blocks+0x2f8>
     5dc:      	tbnz	w15, #0x4, 0x620 <_llm_rows.packet_batch.blocks+0x304>
     5e0:      	tbnz	w15, #0x5, 0x62c <_llm_rows.packet_batch.blocks+0x310>
     5e4:      	tbnz	w15, #0x6, 0x638 <_llm_rows.packet_batch.blocks+0x31c>
     5e8:      	tbz	w15, #0x7, 0x59c <_llm_rows.packet_batch.blocks+0x280>
     5ec:      	b	0x644 <_llm_rows.packet_batch.blocks+0x328>
     5f0:      	ldr	s4, [x14]
     5f4:      	and	w15, w13, #0xff
     5f8:      	tbz	w15, #0x1, 0x5d4 <_llm_rows.packet_batch.blocks+0x2b8>
     5fc:      	add	x16, x14, #0x4
     600:      	ld1.s	{ v4 }[1], [x16]
     604:      	tbz	w15, #0x2, 0x5d8 <_llm_rows.packet_batch.blocks+0x2bc>
     608:      	add	x16, x14, #0x8
     60c:      	ld1.s	{ v4 }[2], [x16]
     610:      	tbz	w15, #0x3, 0x5dc <_llm_rows.packet_batch.blocks+0x2c0>
     614:      	add	x16, x14, #0xc
     618:      	ld1.s	{ v4 }[3], [x16]
     61c:      	tbz	w15, #0x4, 0x5e0 <_llm_rows.packet_batch.blocks+0x2c4>
     620:      	add	x16, x14, #0x10
     624:      	ld1.s	{ v5 }[0], [x16]
     628:      	tbz	w15, #0x5, 0x5e4 <_llm_rows.packet_batch.blocks+0x2c8>
     62c:      	add	x16, x14, #0x14
     630:      	ld1.s	{ v5 }[1], [x16]
     634:      	tbz	w15, #0x6, 0x5e8 <_llm_rows.packet_batch.blocks+0x2cc>
     638:      	add	x16, x14, #0x18
     63c:      	ld1.s	{ v5 }[2], [x16]
     640:      	tbz	w15, #0x7, 0x59c <_llm_rows.packet_batch.blocks+0x280>
     644:      	add	x14, x14, #0x1c
     648:      	ld1.s	{ v5 }[3], [x14]
     64c:      	b	0x59c <_llm_rows.packet_batch.blocks+0x280>
     650:      	ldr	q4, [x23, #0x2740]
     654:      	ldr	q5, [x23, #0x2750]
     658:      	ldr	q6, [x23, #0x2760]
     65c:      	ldr	q7, [x23, #0x2770]
     660:      	ldr	q16, [x23, #0x2780]
     664:      	ldr	q19, [x23, #0x2790]
     668:      	ldr	q20, [x23, #0x27a0]
     66c:      	and.16b	v5, v0, v5
     670:      	and.16b	v4, v1, v4
     674:      	ldr	q21, [x23, #0x27b0]
     678:      	and.16b	v18, v0, v7
     67c:      	and.16b	v17, v1, v6
     680:      	and.16b	v6, v0, v19
     684:      	and.16b	v19, v1, v16
     688:      	and.16b	v16, v0, v21
     68c:      	and.16b	v7, v1, v20
     690:      	ldr	x10, [sp, #0x28]
     694:      	mov	w12, #0x4               ; =4
     698:      	ldp	q21, q20, [x10, #-0x60]
     69c:      	fadd.4s	v21, v4, v21
     6a0:      	fadd.4s	v20, v5, v20
     6a4:      	ldp	q23, q22, [x10, #-0x40]
     6a8:      	fadd.4s	v23, v17, v23
     6ac:      	fadd.4s	v22, v18, v22
     6b0:      	ldp	q25, q24, [x10, #-0x20]
     6b4:      	fadd.4s	v25, v19, v25
     6b8:      	fadd.4s	v24, v6, v24
     6bc:      	ldp	q27, q26, [x10], #0x80
     6c0:      	fadd.4s	v27, v7, v27
     6c4:      	fadd.4s	v26, v16, v26
     6c8:      	bit.16b	v5, v20, v0
     6cc:      	bit.16b	v4, v21, v1
     6d0:      	bit.16b	v18, v22, v0
     6d4:      	bit.16b	v17, v23, v1
     6d8:      	bit.16b	v6, v24, v0
     6dc:      	bit.16b	v19, v25, v1
     6e0:      	bit.16b	v16, v26, v0
     6e4:      	bit.16b	v7, v27, v1
     6e8:      	cmp	x12, #0x5c
     6ec:      	add	x12, x12, #0x4
     6f0:      	b.lo	0x698 <_llm_rows.packet_batch.blocks+0x37c>
     6f4:      	mov	x3, #0x0                ; =0
     6f8:      	xtn.8b	v3, v3
     6fc:      	fadd.4s	v5, v5, v18
     700:      	fadd.4s	v4, v4, v17
     704:      	fadd.4s	v17, v4, v19
     708:      	fadd.4s	v4, v5, v6
     70c:      	fadd.4s	v4, v4, v16
     710:      	fadd.4s	v5, v17, v7
     714:      	ldr	q6, [sp, #0x60]
     718:      	and.16b	v7, v1, v6
     71c:      	ldr	q6, [sp, #0x50]
     720:      	and.16b	v6, v0, v6
     724:      	movi.4s	v17, #0x1
     728:      	eor.16b	v16, v6, v17
     72c:      	eor.16b	v19, v7, v17
     730:      	umov.b	w10, v3[0]
     734:      	str	q5, [x23, #0x310]
     738:      	ldr	s7, [x23, #0x314]
     73c:      	umov.b	w12, v3[1]
     740:      	ands	w1, w10, #0x1
     744:      	tst	w1, w12
     748:      	fcsel	s7, s7, s8, ne
     74c:      	mov.s	w13, v19[1]
     750:      	add	x14, sp, #0x410
     754:      	orr	x14, x14, x13, lsl #2
     758:      	add	x15, sp, #0x2e8
     75c:      	bfxil	x15, x13, #0, #3
     760:      	str	d3, [x23, #0x1c8]
     764:      	ldrb	w13, [x15]
     768:      	and	w13, w12, w13
     76c:      	stp	q5, q4, [x23, #0x2f0]
     770:      	ldr	s17, [x14]
     774:      	tst	w13, #0x1
     778:      	fcsel	s17, s17, s8, ne
     77c:      	mov.s	w13, v19[2]
     780:      	add	x14, sp, #0x3f0
     784:      	orr	x14, x14, x13, lsl #2
     788:      	add	x15, sp, #0x2e8
     78c:      	bfxil	x15, x13, #0, #3
     790:      	ldrb	w15, [x15]
     794:      	umov.b	w13, v3[2]
     798:      	and	w15, w13, w15
     79c:      	stp	q5, q4, [x23, #0x2d0]
     7a0:      	ldr	s18, [x14]
     7a4:      	tst	w15, #0x1
     7a8:      	fcsel	s18, s18, s8, ne
     7ac:      	mov.s	w14, v19[3]
     7b0:      	add	x15, sp, #0x3d0
     7b4:      	orr	x15, x15, x14, lsl #2
     7b8:      	add	x16, sp, #0x2e8
     7bc:      	bfxil	x16, x14, #0, #3
     7c0:      	ldrb	w16, [x16]
     7c4:      	umov.b	w14, v3[3]
     7c8:      	and	w16, w14, w16
     7cc:      	stp	q5, q4, [x23, #0x2b0]
     7d0:      	ldr	s19, [x15]
     7d4:      	tst	w16, #0x1
     7d8:      	fcsel	s19, s19, s8, ne
     7dc:      	fmov	w16, s16
     7e0:      	add	x15, sp, #0x2e8
     7e4:      	bfxil	x15, x16, #0, #3
     7e8:      	ldrb	w17, [x15]
     7ec:      	umov.b	w15, v3[4]
     7f0:      	and	w17, w15, w17
     7f4:      	stp	q5, q4, [x23, #0x290]
     7f8:      	add	x0, sp, #0x3b0
     7fc:      	ldr	s20, [x0, w16, uxtw #2]
     800:      	tst	w17, #0x1
     804:      	fcsel	s20, s20, s8, ne
     808:      	mov.s	w17, v16[1]
     80c:      	add	x0, sp, #0x2e8
     810:      	bfxil	x0, x17, #0, #3
     814:      	umov.b	w16, v3[5]
     818:      	ldrb	w0, [x0]
     81c:      	and	w0, w16, w0
     820:      	stp	q5, q4, [x23, #0x270]
     824:      	add	x2, sp, #0x390
     828:      	ldr	s21, [x2, w17, uxtw #2]
     82c:      	tst	w0, #0x1
     830:      	fcsel	s21, s21, s8, ne
     834:      	mov.s	w0, v16[2]
     838:      	add	x17, sp, #0x2e8
     83c:      	bfxil	x17, x0, #0, #3
     840:      	ldrb	w2, [x17]
     844:      	umov.b	w17, v3[6]
     848:      	and	w2, w17, w2
     84c:      	stp	q5, q4, [x23, #0x250]
     850:      	add	x4, sp, #0x370
     854:      	ldr	s22, [x4, w0, uxtw #2]
     858:      	tst	w2, #0x1
     85c:      	fcsel	s22, s22, s8, ne
     860:      	mov.s	w2, v16[3]
     864:      	add	x0, sp, #0x2e8
     868:      	bfxil	x0, x2, #0, #3
     86c:      	ldrb	w4, [x0]
     870:      	umov.b	w0, v3[7]
     874:      	and	w4, w0, w4
     878:      	stp	q5, q4, [x23, #0x230]
     87c:      	add	x6, sp, #0x350
     880:      	ldr	s16, [x6, w2, uxtw #2]
     884:      	tst	w4, #0x1
     888:      	fcsel	s16, s16, s8, ne
     88c:      	mov.s	v7[1], v17[0]
     890:      	mov.s	v7[2], v18[0]
     894:      	mov.s	v7[3], v19[0]
     898:      	mov.s	v20[1], v21[0]
     89c:      	mov.s	v20[2], v22[0]
     8a0:      	mov.s	v20[3], v16[0]
     8a4:      	fadd.4s	v4, v4, v20
     8a8:      	fadd.4s	v5, v5, v7
     8ac:      	movi.4s	v7, #0x2
     8b0:      	eor.16b	v6, v6, v7
     8b4:      	str	q5, [x23, #0x210]
     8b8:      	ldr	s7, [x23, #0x218]
     8bc:      	tst	w1, w13
     8c0:      	fcsel	s7, s7, s8, ne
     8c4:      	fmov	w1, s6
     8c8:      	add	x2, sp, #0x2e8
     8cc:      	bfxil	x2, x1, #0, #3
     8d0:      	ldrb	w2, [x2]
     8d4:      	and	w2, w15, w2
     8d8:      	stp	q5, q4, [x23, #0x1f0]
     8dc:      	add	x4, sp, #0x310
     8e0:      	ldr	s6, [x4, w1, uxtw #2]
     8e4:      	tst	w2, #0x1
     8e8:      	fcsel	s6, s6, s8, ne
     8ec:      	fadd.4s	v4, v4, v6
     8f0:      	and	w1, w10, w15
     8f4:      	tst	w1, #0x1
     8f8:      	fcsel	s4, s4, s8, ne
     8fc:      	ands	w2, w10, #0x1
     900:      	fadd.4s	v5, v5, v7
     904:      	fadd	s4, s5, s4
     908:      	fcsel	s5, s4, s8, ne
     90c:      	tst	w1, #0x1
     910:      	and	w4, w12, w10
     914:      	fcsel	s6, s4, s8, ne
     918:      	str	w4, [sp, #0x34]
     91c:      	tst	w4, #0x1
     920:      	and	w4, w13, w10
     924:      	fcsel	s7, s4, s8, ne
     928:      	str	w4, [sp, #0x30]
     92c:      	tst	w4, #0x1
     930:      	and	w4, w14, w10
     934:      	fcsel	s16, s4, s8, ne
     938:      	mov	x26, x4
     93c:      	tst	w4, #0x1
     940:      	fcsel	s17, s4, s8, ne
     944:      	and	w6, w16, w10
     948:      	tst	w6, #0x1
     94c:      	fcsel	s18, s4, s8, ne
     950:      	and	w7, w17, w10
     954:      	tst	w7, #0x1
     958:      	fcsel	s19, s4, s8, ne
     95c:      	and	w30, w0, w10
     960:      	tst	w30, #0x1
     964:      	mov.s	v5[1], v7[0]
     968:      	mov.s	v5[2], v16[0]
     96c:      	mov.s	v5[3], v17[0]
     970:      	mov.s	v6[1], v18[0]
     974:      	fcsel	s4, s4, s8, ne
     978:      	mov.s	v6[2], v19[0]
     97c:      	mov.s	v6[3], v4[0]
     980:      	rbit	w8, w8
     984:      	clz	w8, w8
     988:      	stp	q5, q6, [x23, #0x1d0]
     98c:      	and	x4, x8, #0x7
     990:      	add	x24, sp, #0x2f0
     994:      	ldr	s4, [x24, x4, lsl #2]
     998:      	fadd	s4, s4, s8
     99c:      	mov	w4, #0x44400000         ; =1145044992
     9a0:      	fmov	s5, w4
     9a4:      	fdiv	s4, s4, s5
     9a8:      	dup.4s	v4, v4[0]
     9ac:      	add	x4, x5, x3
     9b0:      	ldp	q6, q5, [x4]
     9b4:      	fsub.4s	v6, v6, v4
     9b8:      	fsub.4s	v5, v5, v4
     9bc:      	add	x4, x28, x3
     9c0:      	ldp	q7, q16, [x4]
     9c4:      	bif.16b	v5, v16, v0
     9c8:      	bif.16b	v6, v7, v1
     9cc:      	stp	q6, q5, [x4]
     9d0:      	add	x3, x3, #0x20
     9d4:      	cmp	x3, #0xc00
     9d8:      	b.ne	0x9ac <_llm_rows.packet_batch.blocks+0x690>
     9dc:      	ldr	q4, [x23, #0x1b50]
     9e0:      	ldr	q5, [x23, #0x1b40]
     9e4:      	fmul.4s	v6, v5, v5
     9e8:      	fmul.4s	v4, v4, v4
     9ec:      	ldr	q5, [x23, #0x1b70]
     9f0:      	ldr	q7, [x23, #0x1b60]
     9f4:      	fmul.4s	v7, v7, v7
     9f8:      	fmul.4s	v16, v5, v5
     9fc:      	ldr	q5, [x23, #0x1b90]
     a00:      	ldr	q17, [x23, #0x1b80]
     a04:      	fmul.4s	v19, v17, v17
     a08:      	fmul.4s	v20, v5, v5
     a0c:      	ldr	q5, [x23, #0x1bb0]
     a10:      	ldr	q17, [x23, #0x1ba0]
     a14:      	fmul.4s	v21, v17, v17
     a18:      	fmul.4s	v22, v5, v5
     a1c:      	and.16b	v5, v0, v4
     a20:      	and.16b	v4, v1, v6
     a24:      	and.16b	v18, v0, v16
     a28:      	and.16b	v17, v1, v7
     a2c:      	and.16b	v6, v0, v20
     a30:      	and.16b	v19, v1, v19
     a34:      	and.16b	v16, v0, v22
     a38:      	and.16b	v7, v1, v21
     a3c:      	ldr	x3, [sp, #0x20]
     a40:      	mov	w4, #0x4                ; =4
     a44:      	ldp	q21, q20, [x3, #-0x60]
     a48:      	and.16b	v21, v1, v21
     a4c:      	and.16b	v20, v0, v20
     a50:      	fmul.4s	v20, v20, v20
     a54:      	fmul.4s	v21, v21, v21
     a58:      	fadd.4s	v21, v4, v21
     a5c:      	fadd.4s	v20, v5, v20
     a60:      	ldp	q23, q22, [x3, #-0x40]
     a64:      	and.16b	v23, v1, v23
     a68:      	and.16b	v22, v0, v22
     a6c:      	fmul.4s	v22, v22, v22
     a70:      	fmul.4s	v23, v23, v23
     a74:      	fadd.4s	v23, v17, v23
     a78:      	fadd.4s	v22, v18, v22
     a7c:      	ldp	q25, q24, [x3, #-0x20]
     a80:      	and.16b	v25, v1, v25
     a84:      	and.16b	v24, v0, v24
     a88:      	fmul.4s	v24, v24, v24
     a8c:      	fmul.4s	v25, v25, v25
     a90:      	fadd.4s	v25, v19, v25
     a94:      	fadd.4s	v24, v6, v24
     a98:      	ldp	q27, q26, [x3], #0x80
     a9c:      	and.16b	v27, v1, v27
     aa0:      	and.16b	v26, v0, v26
     aa4:      	fmul.4s	v26, v26, v26
     aa8:      	fmul.4s	v27, v27, v27
     aac:      	fadd.4s	v27, v7, v27
     ab0:      	fadd.4s	v26, v16, v26
     ab4:      	bit.16b	v5, v20, v0
     ab8:      	bit.16b	v4, v21, v1
     abc:      	bit.16b	v18, v22, v0
     ac0:      	bit.16b	v17, v23, v1
     ac4:      	bit.16b	v6, v24, v0
     ac8:      	bit.16b	v19, v25, v1
     acc:      	bit.16b	v16, v26, v0
     ad0:      	bit.16b	v7, v27, v1
     ad4:      	cmp	x4, #0x5c
     ad8:      	add	x4, x4, #0x4
     adc:      	b.lo	0xa44 <_llm_rows.packet_batch.blocks+0x728>
     ae0:      	mov	x3, #0x0                ; =0
     ae4:      	b	0xb08 <_llm_rows.packet_batch.blocks+0x7ec>
     ae8:      	add	x4, x21, x3
     aec:      	ldp	q22, q23, [x4]
     af0:      	bif.16b	v21, v23, v0
     af4:      	bif.16b	v20, v22, v1
     af8:      	stp	q20, q21, [x4]
     afc:      	add	x3, x3, #0x20
     b00:      	cmp	x3, #0xc00
     b04:      	b.eq	0xba0 <_llm_rows.packet_batch.blocks+0x884>
     b08:      	fmov	w5, s2
     b0c:      	add	x4, x9, x3
     b10:      	movi.2d	v20, #0000000000000000
     b14:      	movi.2d	v21, #0000000000000000
     b18:      	tbnz	w5, #0x0, 0xb40 <_llm_rows.packet_batch.blocks+0x824>
     b1c:      	and	w5, w5, #0xff
     b20:      	tbnz	w5, #0x1, 0xb4c <_llm_rows.packet_batch.blocks+0x830>
     b24:      	tbnz	w5, #0x2, 0xb58 <_llm_rows.packet_batch.blocks+0x83c>
     b28:      	tbnz	w5, #0x3, 0xb64 <_llm_rows.packet_batch.blocks+0x848>
     b2c:      	tbnz	w5, #0x4, 0xb70 <_llm_rows.packet_batch.blocks+0x854>
     b30:      	tbnz	w5, #0x5, 0xb7c <_llm_rows.packet_batch.blocks+0x860>
     b34:      	tbnz	w5, #0x6, 0xb88 <_llm_rows.packet_batch.blocks+0x86c>
     b38:      	tbz	w5, #0x7, 0xae8 <_llm_rows.packet_batch.blocks+0x7cc>
     b3c:      	b	0xb94 <_llm_rows.packet_batch.blocks+0x878>
     b40:      	ldr	s20, [x4]
     b44:      	and	w5, w5, #0xff
     b48:      	tbz	w5, #0x1, 0xb24 <_llm_rows.packet_batch.blocks+0x808>
     b4c:      	add	x24, x4, #0x4
     b50:      	ld1.s	{ v20 }[1], [x24]
     b54:      	tbz	w5, #0x2, 0xb28 <_llm_rows.packet_batch.blocks+0x80c>
     b58:      	add	x24, x4, #0x8
     b5c:      	ld1.s	{ v20 }[2], [x24]
     b60:      	tbz	w5, #0x3, 0xb2c <_llm_rows.packet_batch.blocks+0x810>
     b64:      	add	x24, x4, #0xc
     b68:      	ld1.s	{ v20 }[3], [x24]
     b6c:      	tbz	w5, #0x4, 0xb30 <_llm_rows.packet_batch.blocks+0x814>
     b70:      	add	x24, x4, #0x10
     b74:      	ld1.s	{ v21 }[0], [x24]
     b78:      	tbz	w5, #0x5, 0xb34 <_llm_rows.packet_batch.blocks+0x818>
     b7c:      	add	x24, x4, #0x14
     b80:      	ld1.s	{ v21 }[1], [x24]
     b84:      	tbz	w5, #0x6, 0xb38 <_llm_rows.packet_batch.blocks+0x81c>
     b88:      	add	x24, x4, #0x18
     b8c:      	ld1.s	{ v21 }[2], [x24]
     b90:      	tbz	w5, #0x7, 0xae8 <_llm_rows.packet_batch.blocks+0x7cc>
     b94:      	add	x4, x4, #0x1c
     b98:      	ld1.s	{ v21 }[3], [x4]
     b9c:      	b	0xae8 <_llm_rows.packet_batch.blocks+0x7cc>
     ba0:      	mov	x9, #0x0                ; =0
     ba4:      	b	0xbc8 <_llm_rows.packet_batch.blocks+0x8ac>
     ba8:      	add	x3, x19, x9
     bac:      	ldp	q22, q23, [x3]
     bb0:      	bif.16b	v21, v23, v0
     bb4:      	bif.16b	v20, v22, v1
     bb8:      	stp	q20, q21, [x3]
     bbc:      	add	x9, x9, #0x20
     bc0:      	cmp	x9, #0xc00
     bc4:      	b.eq	0xc60 <_llm_rows.packet_batch.blocks+0x944>
     bc8:      	fmov	w4, s2
     bcc:      	add	x3, x11, x9
     bd0:      	movi.2d	v20, #0000000000000000
     bd4:      	movi.2d	v21, #0000000000000000
     bd8:      	tbnz	w4, #0x0, 0xc00 <_llm_rows.packet_batch.blocks+0x8e4>
     bdc:      	and	w4, w4, #0xff
     be0:      	tbnz	w4, #0x1, 0xc0c <_llm_rows.packet_batch.blocks+0x8f0>
     be4:      	tbnz	w4, #0x2, 0xc18 <_llm_rows.packet_batch.blocks+0x8fc>
     be8:      	tbnz	w4, #0x3, 0xc24 <_llm_rows.packet_batch.blocks+0x908>
     bec:      	tbnz	w4, #0x4, 0xc30 <_llm_rows.packet_batch.blocks+0x914>
     bf0:      	tbnz	w4, #0x5, 0xc3c <_llm_rows.packet_batch.blocks+0x920>
     bf4:      	tbnz	w4, #0x6, 0xc48 <_llm_rows.packet_batch.blocks+0x92c>
     bf8:      	tbz	w4, #0x7, 0xba8 <_llm_rows.packet_batch.blocks+0x88c>
     bfc:      	b	0xc54 <_llm_rows.packet_batch.blocks+0x938>
     c00:      	ldr	s20, [x3]
     c04:      	and	w4, w4, #0xff
     c08:      	tbz	w4, #0x1, 0xbe4 <_llm_rows.packet_batch.blocks+0x8c8>
     c0c:      	add	x5, x3, #0x4
     c10:      	ld1.s	{ v20 }[1], [x5]
     c14:      	tbz	w4, #0x2, 0xbe8 <_llm_rows.packet_batch.blocks+0x8cc>
     c18:      	add	x5, x3, #0x8
     c1c:      	ld1.s	{ v20 }[2], [x5]
     c20:      	tbz	w4, #0x3, 0xbec <_llm_rows.packet_batch.blocks+0x8d0>
     c24:      	add	x5, x3, #0xc
     c28:      	ld1.s	{ v20 }[3], [x5]
     c2c:      	tbz	w4, #0x4, 0xbf0 <_llm_rows.packet_batch.blocks+0x8d4>
     c30:      	add	x5, x3, #0x10
     c34:      	ld1.s	{ v21 }[0], [x5]
     c38:      	tbz	w4, #0x5, 0xbf4 <_llm_rows.packet_batch.blocks+0x8d8>
     c3c:      	add	x5, x3, #0x14
     c40:      	ld1.s	{ v21 }[1], [x5]
     c44:      	tbz	w4, #0x6, 0xbf8 <_llm_rows.packet_batch.blocks+0x8dc>
     c48:      	add	x5, x3, #0x18
     c4c:      	ld1.s	{ v21 }[2], [x5]
     c50:      	tbz	w4, #0x7, 0xba8 <_llm_rows.packet_batch.blocks+0x88c>
     c54:      	add	x3, x3, #0x1c
     c58:      	ld1.s	{ v21 }[3], [x3]
     c5c:      	b	0xba8 <_llm_rows.packet_batch.blocks+0x88c>
     c60:      	mov	x9, #0x0                ; =0
     c64:      	adrp	x11, 0x0 <ltmp0>
     c68:      	ldr	q20, [x11]
     c6c:      	and.16b	v21, v0, v20
     c70:      	adrp	x11, 0x0 <ltmp0>
     c74:      	ldr	q20, [x11]
     c78:      	and.16b	v22, v1, v20
     c7c:      	adrp	x11, 0x0 <ltmp0>
     c80:      	ldr	q20, [x11]
     c84:      	and.16b	v20, v1, v20
     c88:      	fadd.4s	v5, v5, v18
     c8c:      	fadd.4s	v4, v4, v17
     c90:      	fadd.4s	v17, v4, v19
     c94:      	fadd.4s	v4, v5, v6
     c98:      	fadd.4s	v4, v4, v16
     c9c:      	fadd.4s	v5, v17, v7
     ca0:      	fmov	w11, s22
     ca4:      	add	x3, sp, #0x98
     ca8:      	bfxil	x3, x11, #0, #3
     cac:      	str	d3, [sp, #0x98]
     cb0:      	ldrb	w3, [x3]
     cb4:      	add	x4, sp, #0x2c0
     cb8:      	orr	x11, x4, x11, lsl #2
     cbc:      	stp	q5, q4, [x23, #0x1a0]
     cc0:      	ldr	s3, [x11]
     cc4:      	tst	w2, w3
     cc8:      	fcsel	s6, s3, s8, ne
     ccc:      	mov.s	w11, v22[1]
     cd0:      	add	x3, sp, #0x98
     cd4:      	bfxil	x3, x11, #0, #3
     cd8:      	ldrb	w11, [x3]
     cdc:      	and	w11, w12, w11
     ce0:      	str	q5, [x23, #0x180]
     ce4:      	ldr	s3, [x23, #0x180]
     ce8:      	tst	w11, #0x1
     cec:      	fcsel	s3, s3, s8, ne
     cf0:      	mov.s	w11, v22[2]
     cf4:      	add	x3, sp, #0x98
     cf8:      	bfxil	x3, x11, #0, #3
     cfc:      	add	x4, sp, #0x280
     d00:      	orr	x11, x4, x11, lsl #2
     d04:      	ldrb	w3, [x3]
     d08:      	and	w3, w13, w3
     d0c:      	stp	q5, q4, [x23, #0x160]
     d10:      	ldr	s7, [x11]
     d14:      	tst	w3, #0x1
     d18:      	fcsel	s7, s7, s8, ne
     d1c:      	mov.s	w11, v22[3]
     d20:      	add	x3, sp, #0x98
     d24:      	bfxil	x3, x11, #0, #3
     d28:      	add	x4, sp, #0x260
     d2c:      	orr	x11, x4, x11, lsl #2
     d30:      	ldrb	w3, [x3]
     d34:      	and	w3, w14, w3
     d38:      	stp	q5, q4, [x23, #0x140]
     d3c:      	ldr	s16, [x11]
     d40:      	tst	w3, #0x1
     d44:      	fcsel	s16, s16, s8, ne
     d48:      	fmov	w11, s21
     d4c:      	add	x3, sp, #0x98
     d50:      	bfxil	x3, x11, #0, #3
     d54:      	ldrb	w3, [x3]
     d58:      	and	w3, w15, w3
     d5c:      	stp	q5, q4, [x23, #0x120]
     d60:      	add	x4, sp, #0x240
     d64:      	ldr	s17, [x4, w11, uxtw #2]
     d68:      	tst	w3, #0x1
     d6c:      	fcsel	s17, s17, s8, ne
     d70:      	mov.s	w11, v21[1]
     d74:      	add	x3, sp, #0x98
     d78:      	bfxil	x3, x11, #0, #3
     d7c:      	ldrb	w3, [x3]
     d80:      	and	w3, w16, w3
     d84:      	stp	q5, q4, [x23, #0x100]
     d88:      	add	x4, sp, #0x220
     d8c:      	ldr	s18, [x4, w11, uxtw #2]
     d90:      	tst	w3, #0x1
     d94:      	fcsel	s18, s18, s8, ne
     d98:      	mov.s	w11, v21[2]
     d9c:      	add	x3, sp, #0x98
     da0:      	bfxil	x3, x11, #0, #3
     da4:      	ldrb	w3, [x3]
     da8:      	and	w3, w17, w3
     dac:      	stp	q5, q4, [x23, #0xe0]
     db0:      	add	x4, sp, #0x200
     db4:      	ldr	s19, [x4, w11, uxtw #2]
     db8:      	tst	w3, #0x1
     dbc:      	fcsel	s19, s19, s8, ne
     dc0:      	mov.s	w11, v21[3]
     dc4:      	add	x3, sp, #0x98
     dc8:      	bfxil	x3, x11, #0, #3
     dcc:      	ldrb	w3, [x3]
     dd0:      	and	w3, w0, w3
     dd4:      	stp	q5, q4, [x23, #0xc0]
     dd8:      	add	x4, sp, #0x1e0
     ddc:      	ldr	s21, [x4, w11, uxtw #2]
     de0:      	tst	w3, #0x1
     de4:      	fcsel	s21, s21, s8, ne
     de8:      	mov.s	v6[1], v3[0]
     dec:      	mov.s	v6[2], v7[0]
     df0:      	mov.s	v6[3], v16[0]
     df4:      	mov.s	v17[1], v18[0]
     df8:      	mov.s	v17[2], v19[0]
     dfc:      	mov.s	v17[3], v21[0]
     e00:      	fadd.4s	v3, v4, v17
     e04:      	fadd.4s	v4, v5, v6
     e08:      	fmov	w11, s20
     e0c:      	add	x3, sp, #0x98
     e10:      	bfxil	x3, x11, #0, #3
     e14:      	ldrb	w3, [x3]
     e18:      	add	x4, sp, #0x1c0
     e1c:      	orr	x11, x4, x11, lsl #2
     e20:      	stp	q4, q3, [x23, #0xa0]
     e24:      	ldr	s5, [x11]
     e28:      	mov.s	w11, v20[1]
     e2c:      	tst	w2, w3
     e30:      	add	x3, sp, #0x98
     e34:      	bfxil	x3, x11, #0, #3
     e38:      	ldrb	w3, [x3]
     e3c:      	and	w12, w12, w3
     e40:      	fcsel	s5, s5, s8, ne
     e44:      	add	x3, sp, #0x1a0
     e48:      	orr	x11, x3, x11, lsl #2
     e4c:      	stp	q4, q3, [x23, #0x80]
     e50:      	ldr	s7, [x11]
     e54:      	mov.s	w11, v20[2]
     e58:      	tst	w12, #0x1
     e5c:      	add	x12, sp, #0x98
     e60:      	bfxil	x12, x11, #0, #3
     e64:      	adrp	x11, 0x0 <ltmp0>
     e68:      	ldr	q6, [x11]
     e6c:      	and.16b	v18, v0, v6
     e70:      	movi.4s	v6, #0x4
     e74:      	and.16b	v6, v1, v6
     e78:      	fcsel	s7, s7, s8, ne
     e7c:      	ldrb	w11, [x12]
     e80:      	and	w11, w13, w11
     e84:      	str	q4, [x23, #0x60]
     e88:      	ldr	s16, [x23, #0x60]
     e8c:      	tst	w11, #0x1
     e90:      	fcsel	s16, s16, s8, ne
     e94:      	mov.s	w11, v20[3]
     e98:      	add	x12, sp, #0x98
     e9c:      	bfxil	x12, x11, #0, #3
     ea0:      	add	x13, sp, #0x160
     ea4:      	orr	x11, x13, x11, lsl #2
     ea8:      	ldrb	w12, [x12]
     eac:      	and	w12, w14, w12
     eb0:      	stp	q4, q3, [x23, #0x40]
     eb4:      	ldr	s17, [x11]
     eb8:      	tst	w12, #0x1
     ebc:      	fcsel	s17, s17, s8, ne
     ec0:      	fmov	w11, s18
     ec4:      	add	x12, sp, #0x98
     ec8:      	bfxil	x12, x11, #0, #3
     ecc:      	ldrb	w12, [x12]
     ed0:      	and	w12, w15, w12
     ed4:      	stp	q4, q3, [x23, #0x20]
     ed8:      	add	x13, sp, #0x140
     edc:      	ldr	s19, [x13, w11, uxtw #2]
     ee0:      	tst	w12, #0x1
     ee4:      	fcsel	s19, s19, s8, ne
     ee8:      	mov.s	w11, v18[1]
     eec:      	add	x12, sp, #0x98
     ef0:      	bfxil	x12, x11, #0, #3
     ef4:      	ldrb	w12, [x12]
     ef8:      	and	w12, w16, w12
     efc:      	stp	q4, q3, [x23]
     f00:      	ldr	s20, [x23, w11, uxtw #2]
     f04:      	tst	w12, #0x1
     f08:      	fcsel	s20, s20, s8, ne
     f0c:      	mov.s	w11, v18[2]
     f10:      	add	x12, sp, #0x98
     f14:      	bfxil	x12, x11, #0, #3
     f18:      	ldrb	w12, [x12]
     f1c:      	and	w12, w17, w12
     f20:      	stp	q4, q3, [sp, #0x100]
     f24:      	add	x13, sp, #0x100
     f28:      	ldr	s21, [x13, w11, uxtw #2]
     f2c:      	tst	w12, #0x1
     f30:      	fcsel	s21, s21, s8, ne
     f34:      	mov.s	w11, v18[3]
     f38:      	add	x12, sp, #0x98
     f3c:      	bfxil	x12, x11, #0, #3
     f40:      	ldrb	w12, [x12]
     f44:      	and	w12, w0, w12
     f48:      	stp	q4, q3, [sp, #0xe0]
     f4c:      	add	x13, sp, #0xe0
     f50:      	ldr	s18, [x13, w11, uxtw #2]
     f54:      	tst	w12, #0x1
     f58:      	fcsel	s18, s18, s8, ne
     f5c:      	mov.s	v19[1], v20[0]
     f60:      	mov.s	v19[2], v21[0]
     f64:      	mov.s	v19[3], v18[0]
     f68:      	mov.s	v5[1], v7[0]
     f6c:      	mov.s	v5[2], v16[0]
     f70:      	mov.s	v5[3], v17[0]
     f74:      	fadd.4s	v4, v4, v5
     f78:      	fadd.4s	v3, v3, v19
     f7c:      	fmov	w11, s6
     f80:      	add	x12, sp, #0x98
     f84:      	orr	x12, x12, x11
     f88:      	ldrb	w12, [x12]
     f8c:      	stp	q4, q3, [sp, #0xc0]
     f90:      	add	x13, sp, #0xc0
     f94:      	ldr	s3, [x13, w11, uxtw #2]
     f98:      	tst	w2, w12
     f9c:      	fcsel	s3, s3, s8, ne
     fa0:      	tst	w10, #0x1
     fa4:      	fadd	s3, s4, s3
     fa8:      	fcsel	s4, s3, s8, ne
     fac:      	ldr	w10, [sp, #0x34]
     fb0:      	tst	w10, #0x1
     fb4:      	fcsel	s5, s3, s8, ne
     fb8:      	ldr	w10, [sp, #0x30]
     fbc:      	tst	w10, #0x1
     fc0:      	fcsel	s6, s3, s8, ne
     fc4:      	tst	w26, #0x1
     fc8:      	fcsel	s7, s3, s8, ne
     fcc:      	tst	w1, #0x1
     fd0:      	fcsel	s16, s3, s8, ne
     fd4:      	tst	w6, #0x1
     fd8:      	fcsel	s17, s3, s8, ne
     fdc:      	tst	w7, #0x1
     fe0:      	fcsel	s18, s3, s8, ne
     fe4:      	tst	w30, #0x1
     fe8:      	fcsel	s3, s3, s8, ne
     fec:      	mov.s	v4[1], v5[0]
     ff0:      	mov.s	v4[2], v6[0]
     ff4:      	mov.s	v4[3], v7[0]
     ff8:      	mov.s	v16[1], v17[0]
     ffc:      	mov.s	v16[2], v18[0]
    1000:      	mov.s	v16[3], v3[0]
    1004:      	stp	q4, q16, [sp, #0xa0]
    1008:      	and	x8, x8, #0x7
    100c:      	add	x10, sp, #0xa0
    1010:      	ldr	s3, [x10, x8, lsl #2]
    1014:      	fadd	s3, s3, s8
    1018:      	mov	w8, #0x44400000         ; =1145044992
    101c:      	fmov	s4, w8
    1020:      	fdiv	s3, s3, s4
    1024:      	mov	w8, #0xc5ac             ; =50604
    1028:      	movk	w8, #0x3727, lsl #16
    102c:      	fmov	s4, w8
    1030:      	fadd	s3, s3, s4
    1034:      	fsqrt	s3, s3
    1038:      	ldp	x10, x8, [sp, #0x38]
    103c:      	add	x8, x8, x10
    1040:      	dup.4s	v3, v3[0]
    1044:      	ldr	w13, [sp, #0x48]
    1048:      	b	0x1058 <_llm_rows.packet_batch.blocks+0xd3c>
    104c:      	add	x9, x9, #0x20
    1050:      	cmp	x9, #0xc00
    1054:      	b.eq	0x3c4 <_llm_rows.packet_batch.blocks+0xa8>
    1058:      	fmov	w11, s2
    105c:      	add	x10, x28, x9
    1060:      	ldp	q5, q4, [x10]
    1064:      	and.16b	v5, v1, v5
    1068:      	fdiv.4s	v6, v5, v3
    106c:      	add	x10, x21, x9
    1070:      	ldp	q7, q5, [x10]
    1074:      	and.16b	v7, v1, v7
    1078:      	fmul.4s	v7, v6, v7
    107c:      	add	x10, x19, x9
    1080:      	ldp	q16, q6, [x10]
    1084:      	and.16b	v16, v1, v16
    1088:      	fadd.4s	v7, v7, v16
    108c:      	add	x10, x8, x9
    1090:      	tbnz	w11, #0x0, 0x10d8 <_llm_rows.packet_batch.blocks+0xdbc>
    1094:      	and	w11, w11, #0xff
    1098:      	tbnz	w11, #0x1, 0x10e4 <_llm_rows.packet_batch.blocks+0xdc8>
    109c:      	tbnz	w11, #0x2, 0x10f0 <_llm_rows.packet_batch.blocks+0xdd4>
    10a0:      	tbz	w11, #0x3, 0x10ac <_llm_rows.packet_batch.blocks+0xd90>
    10a4:      	add	x12, x10, #0xc
    10a8:      	st1.s	{ v7 }[3], [x12]
    10ac:      	and.16b	v4, v0, v4
    10b0:      	fdiv.4s	v4, v4, v3
    10b4:      	and.16b	v5, v0, v5
    10b8:      	fmul.4s	v4, v4, v5
    10bc:      	and.16b	v5, v0, v6
    10c0:      	fadd.4s	v4, v4, v5
    10c4:      	tbnz	w11, #0x4, 0x1100 <_llm_rows.packet_batch.blocks+0xde4>
    10c8:      	tbnz	w11, #0x5, 0x1108 <_llm_rows.packet_batch.blocks+0xdec>
    10cc:      	tbnz	w11, #0x6, 0x1114 <_llm_rows.packet_batch.blocks+0xdf8>
    10d0:      	tbz	w11, #0x7, 0x104c <_llm_rows.packet_batch.blocks+0xd30>
    10d4:      	b	0x1120 <_llm_rows.packet_batch.blocks+0xe04>
    10d8:      	str	s7, [x10]
    10dc:      	and	w11, w11, #0xff
    10e0:      	tbz	w11, #0x1, 0x109c <_llm_rows.packet_batch.blocks+0xd80>
    10e4:      	add	x12, x10, #0x4
    10e8:      	st1.s	{ v7 }[1], [x12]
    10ec:      	tbz	w11, #0x2, 0x10a0 <_llm_rows.packet_batch.blocks+0xd84>
    10f0:      	add	x12, x10, #0x8
    10f4:      	st1.s	{ v7 }[2], [x12]
    10f8:      	tbnz	w11, #0x3, 0x10a4 <_llm_rows.packet_batch.blocks+0xd88>
    10fc:      	b	0x10ac <_llm_rows.packet_batch.blocks+0xd90>
    1100:      	str	s4, [x10, #0x10]
    1104:      	tbz	w11, #0x5, 0x10cc <_llm_rows.packet_batch.blocks+0xdb0>
    1108:      	add	x12, x10, #0x14
    110c:      	st1.s	{ v4 }[1], [x12]
    1110:      	tbz	w11, #0x6, 0x10d0 <_llm_rows.packet_batch.blocks+0xdb4>
    1114:      	add	x12, x10, #0x18
    1118:      	st1.s	{ v4 }[2], [x12]
    111c:      	tbz	w11, #0x7, 0x104c <_llm_rows.packet_batch.blocks+0xd30>
    1120:      	add	x10, x10, #0x1c
    1124:      	st1.s	{ v4 }[3], [x10]
    1128:      	b	0x104c <_llm_rows.packet_batch.blocks+0xd30>
    112c:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
    1130:      	add	sp, sp, #0x460
    1134:      	ldp	x29, x30, [sp, #0x60]
    1138:      	ldp	x20, x19, [sp, #0x50]
    113c:      	ldp	x22, x21, [sp, #0x40]
    1140:      	ldp	x24, x23, [sp, #0x30]
    1144:      	ldp	x26, x25, [sp, #0x20]
    1148:      	ldp	x28, x27, [sp, #0x10]
    114c:      	ldp	d9, d8, [sp], #0x70
    1150:      	ret

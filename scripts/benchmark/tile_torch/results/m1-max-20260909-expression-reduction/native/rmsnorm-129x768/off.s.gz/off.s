
/private/tmp/luisa-expression-fusion.qXgTbC/capture/rmsnorm-129x768/off/object/tile_xir_w8_23300_1788930259628520_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d9, d8, [sp, #-0x70]!
       4:      	stp	x28, x27, [sp, #0x10]
       8:      	stp	x26, x25, [sp, #0x20]
       c:      	stp	x24, x23, [sp, #0x30]
      10:      	stp	x22, x21, [sp, #0x40]
      14:      	stp	x20, x19, [sp, #0x50]
      18:      	stp	x29, x30, [sp, #0x60]
      1c:      	sub	sp, sp, #0x1, lsl #12   ; =0x1000
      20:      	sub	sp, sp, #0xa50
      24:      	str	x0, [sp, #0x18]
      28:      	cbz	w3, 0xfd8 <ltmp0+0xfd8>
      2c:      	mov	w23, #0x0               ; =0
      30:      	add	x24, sp, #0x160
      34:      	ldp	w9, w8, [x2, #0x2c]
      38:      	stp	w8, w9, [sp, #0x34]
      3c:      	add	x27, sp, #0xe50
      40:      	add	x8, x27, #0xe0
      44:      	stp	x2, x8, [sp, #0x8]
      48:      	ldp	w8, w9, [x2]
      4c:      	add	x28, sp, #0x250
      50:      	ldp	w10, w11, [x2, #0x8]
      54:      	str	x11, [sp, #0x28]
      58:      	movi	d8, #0000000000000000
      5c:      	str	w3, [sp, #0x3c]
      60:      	b	0xa0 <ltmp0+0xa0>
      64:      	add	w8, w21, #0x1
      68:      	ldp	w11, w9, [sp, #0x34]
      6c:      	cmp	w8, w9
      70:      	cset	w9, eq
      74:      	csinc	w8, wzr, w21, eq
      78:      	cinc	w10, w6, eq
      7c:      	cmp	w10, w11
      80:      	cset	w11, eq
      84:      	ands	w11, w9, w11
      88:      	csel	w9, wzr, w10, ne
      8c:      	ldr	w12, [sp, #0x4c]
      90:      	add	w10, w12, w11
      94:      	add	w23, w23, #0x1
      98:      	cmp	w23, w19
      9c:      	b.eq	0xfc4 <ltmp0+0xfc4>
      a0:      	stp	w9, w10, [sp, #0x48]
      a4:      	mov	x13, x8
      a8:      	ubfiz	x8, x8, #5, #32
      ac:      	ldr	x12, [sp, #0x28]
      b0:      	cmp	x8, x12
      b4:      	csel	x9, x8, xzr, ls
      b8:      	subs	x10, x12, x9
      bc:      	cmp	x10, #0x20
      c0:      	mov	w11, #0x20              ; =32
      c4:      	csel	x10, x10, x11, lo
      c8:      	cmp	x12, x9
      cc:      	ccmp	x8, x12, #0x2, hi
      d0:      	csel	x25, x10, xzr, ls
      d4:      	cmp	x25, #0x20
      d8:      	b.lo	0x75c <ltmp0+0x75c>
      dc:      	ldr	x8, [sp, #0x18]
      e0:      	ldr	x25, [x8]
      e4:      	ldr	x22, [x8, #0x10]
      e8:      	ldr	x20, [x8, #0x30]
      ec:      	mov	x21, x13
      f0:      	ubfiz	w26, w13, #2, #27
      f4:      	mov	w8, #0xc00              ; =3072
      f8:      	umull	x19, w26, w8
      fc:      	umaddl	x1, w26, w8, x25
     100:      	add	x0, sp, #0xe50
     104:      	mov	w2, #0xc00              ; =3072
     108:      	bl	0x108 <ltmp0+0x108>
     10c:      	mov	x8, #0x0                ; =0
     110:      	ldr	q0, [x24, #0xcf0]
     114:      	ldr	q1, [x24, #0xd00]
     118:      	fmul.4s	v2, v1, v1
     11c:      	fmul.4s	v3, v0, v0
     120:      	ldr	q0, [x24, #0xd10]
     124:      	ldr	q1, [x24, #0xd20]
     128:      	fmul.4s	v4, v1, v1
     12c:      	fmul.4s	v5, v0, v0
     130:      	ldr	q0, [x24, #0xd30]
     134:      	ldr	q1, [x24, #0xd40]
     138:      	fmul.4s	v7, v1, v1
     13c:      	fmul.4s	v6, v0, v0
     140:      	ldr	q0, [x24, #0xd50]
     144:      	ldr	q1, [x24, #0xd60]
     148:      	fmul.4s	v16, v1, v1
     14c:      	fmul.4s	v17, v0, v0
     150:      	add	x9, x27, x8, lsl #5
     154:      	ldp	q1, q0, [x9, #0x80]
     158:      	fmul.4s	v1, v1, v1
     15c:      	fmul.4s	v0, v0, v0
     160:      	fadd.4s	v2, v2, v0
     164:      	fadd.4s	v3, v3, v1
     168:      	ldp	q1, q0, [x9, #0xa0]
     16c:      	fmul.4s	v1, v1, v1
     170:      	fmul.4s	v0, v0, v0
     174:      	fadd.4s	v4, v4, v0
     178:      	fadd.4s	v5, v5, v1
     17c:      	ldp	q1, q0, [x9, #0xc0]
     180:      	fmul.4s	v1, v1, v1
     184:      	fmul.4s	v0, v0, v0
     188:      	fadd.4s	v7, v7, v0
     18c:      	fadd.4s	v6, v6, v1
     190:      	ldp	q1, q0, [x9, #0xe0]
     194:      	fmul.4s	v1, v1, v1
     198:      	fmul.4s	v0, v0, v0
     19c:      	fadd.4s	v16, v16, v0
     1a0:      	fadd.4s	v17, v17, v1
     1a4:      	add	x8, x8, #0x4
     1a8:      	cmp	x8, #0x5c
     1ac:      	b.lo	0x150 <ltmp0+0x150>
     1b0:      	add	x0, sp, #0x250
     1b4:      	mov	x1, x22
     1b8:      	mov	w2, #0xc00              ; =3072
     1bc:      	stp	q4, q2, [sp, #0x80]
     1c0:      	stp	q5, q3, [sp, #0x50]
     1c4:      	stp	q6, q16, [sp, #0xb0]
     1c8:      	str	q7, [sp, #0x70]
     1cc:      	str	q17, [sp, #0xa0]
     1d0:      	bl	0x1d0 <ltmp0+0x1d0>
     1d4:      	mov	x8, #0x0                ; =0
     1d8:      	ldp	q1, q0, [sp, #0x50]
     1dc:      	fadd.4s	v0, v0, v1
     1e0:      	ldp	q2, q1, [sp, #0x80]
     1e4:      	fadd.4s	v1, v1, v2
     1e8:      	ldr	q2, [sp, #0x70]
     1ec:      	fadd.4s	v1, v1, v2
     1f0:      	ldp	q2, q3, [sp, #0xa0]
     1f4:      	fadd.4s	v0, v0, v3
     1f8:      	fadd.4s	v0, v0, v2
     1fc:      	ldr	q2, [sp, #0xc0]
     200:      	fadd.4s	v1, v1, v2
     204:      	rev64.4s	v2, v1
     208:      	rev64.4s	v3, v0
     20c:      	fadd.4s	v0, v0, v3
     210:      	fadd.4s	v1, v1, v2
     214:      	dup.4s	v2, v1[2]
     218:      	dup.4s	v3, v0[2]
     21c:      	fadd.4s	v0, v0, v3
     220:      	fadd.4s	v1, v1, v2
     224:      	fadd.4s	v0, v0, v1
     228:      	fadd	s0, s0, s8
     22c:      	mov	w9, #0x44400000         ; =1145044992
     230:      	fmov	s1, w9
     234:      	fdiv	s0, s0, s1
     238:      	mov	w9, #0xc5ac             ; =50604
     23c:      	movk	w9, #0x3727, lsl #16
     240:      	fmov	s1, w9
     244:      	fadd	s0, s0, s1
     248:      	fsqrt	s0, s0
     24c:      	dup.4s	v0, v0[0]
     250:      	add	x9, x20, x19
     254:      	add	x10, x27, x8
     258:      	ldp	q1, q2, [x10]
     25c:      	fdiv.4s	v2, v2, v0
     260:      	fdiv.4s	v1, v1, v0
     264:      	add	x10, x28, x8
     268:      	ldp	q4, q3, [x10]
     26c:      	fmul.4s	v1, v1, v4
     270:      	fmul.4s	v2, v2, v3
     274:      	add	x10, x9, x8
     278:      	stp	q1, q2, [x10]
     27c:      	add	x8, x8, #0x20
     280:      	cmp	x8, #0xc00
     284:      	b.ne	0x254 <ltmp0+0x254>
     288:      	orr	w8, w26, #0x1
     28c:      	mov	w9, #0xc00              ; =3072
     290:      	umull	x19, w8, w9
     294:      	umaddl	x1, w8, w9, x25
     298:      	add	x0, sp, #0xe50
     29c:      	mov	w2, #0xc00              ; =3072
     2a0:      	bl	0x2a0 <ltmp0+0x2a0>
     2a4:      	mov	x8, #0x0                ; =0
     2a8:      	ldr	q0, [x24, #0xcf0]
     2ac:      	ldr	q1, [x24, #0xd00]
     2b0:      	fmul.4s	v2, v1, v1
     2b4:      	fmul.4s	v3, v0, v0
     2b8:      	ldr	q0, [x24, #0xd10]
     2bc:      	ldr	q1, [x24, #0xd20]
     2c0:      	fmul.4s	v4, v1, v1
     2c4:      	fmul.4s	v5, v0, v0
     2c8:      	ldr	q0, [x24, #0xd30]
     2cc:      	ldr	q1, [x24, #0xd40]
     2d0:      	fmul.4s	v7, v1, v1
     2d4:      	fmul.4s	v6, v0, v0
     2d8:      	ldr	q0, [x24, #0xd50]
     2dc:      	ldr	q1, [x24, #0xd60]
     2e0:      	fmul.4s	v16, v1, v1
     2e4:      	fmul.4s	v17, v0, v0
     2e8:      	add	x9, x27, x8, lsl #5
     2ec:      	ldp	q1, q0, [x9, #0x80]
     2f0:      	fmul.4s	v1, v1, v1
     2f4:      	fmul.4s	v0, v0, v0
     2f8:      	fadd.4s	v2, v2, v0
     2fc:      	fadd.4s	v3, v3, v1
     300:      	ldp	q1, q0, [x9, #0xa0]
     304:      	fmul.4s	v1, v1, v1
     308:      	fmul.4s	v0, v0, v0
     30c:      	fadd.4s	v4, v4, v0
     310:      	fadd.4s	v5, v5, v1
     314:      	ldp	q1, q0, [x9, #0xc0]
     318:      	fmul.4s	v1, v1, v1
     31c:      	fmul.4s	v0, v0, v0
     320:      	fadd.4s	v7, v7, v0
     324:      	fadd.4s	v6, v6, v1
     328:      	ldp	q1, q0, [x9, #0xe0]
     32c:      	fmul.4s	v1, v1, v1
     330:      	fmul.4s	v0, v0, v0
     334:      	fadd.4s	v16, v16, v0
     338:      	fadd.4s	v17, v17, v1
     33c:      	add	x8, x8, #0x4
     340:      	cmp	x8, #0x5c
     344:      	b.lo	0x2e8 <ltmp0+0x2e8>
     348:      	add	x0, sp, #0x250
     34c:      	mov	x1, x22
     350:      	mov	w2, #0xc00              ; =3072
     354:      	stp	q4, q2, [sp, #0x80]
     358:      	stp	q5, q3, [sp, #0x50]
     35c:      	stp	q6, q16, [sp, #0xb0]
     360:      	str	q7, [sp, #0x70]
     364:      	str	q17, [sp, #0xa0]
     368:      	bl	0x368 <ltmp0+0x368>
     36c:      	mov	x8, #0x0                ; =0
     370:      	ldp	q1, q0, [sp, #0x50]
     374:      	fadd.4s	v0, v0, v1
     378:      	ldp	q2, q1, [sp, #0x80]
     37c:      	fadd.4s	v1, v1, v2
     380:      	ldr	q2, [sp, #0x70]
     384:      	fadd.4s	v1, v1, v2
     388:      	ldp	q2, q3, [sp, #0xa0]
     38c:      	fadd.4s	v0, v0, v3
     390:      	fadd.4s	v0, v0, v2
     394:      	ldr	q2, [sp, #0xc0]
     398:      	fadd.4s	v1, v1, v2
     39c:      	rev64.4s	v2, v1
     3a0:      	rev64.4s	v3, v0
     3a4:      	fadd.4s	v0, v0, v3
     3a8:      	fadd.4s	v1, v1, v2
     3ac:      	dup.4s	v2, v1[2]
     3b0:      	dup.4s	v3, v0[2]
     3b4:      	fadd.4s	v0, v0, v3
     3b8:      	fadd.4s	v1, v1, v2
     3bc:      	fadd.4s	v0, v0, v1
     3c0:      	fadd	s0, s0, s8
     3c4:      	mov	w9, #0x44400000         ; =1145044992
     3c8:      	fmov	s1, w9
     3cc:      	fdiv	s0, s0, s1
     3d0:      	mov	w9, #0xc5ac             ; =50604
     3d4:      	movk	w9, #0x3727, lsl #16
     3d8:      	fmov	s1, w9
     3dc:      	fadd	s0, s0, s1
     3e0:      	fsqrt	s0, s0
     3e4:      	dup.4s	v0, v0[0]
     3e8:      	add	x9, x20, x19
     3ec:      	add	x10, x27, x8
     3f0:      	ldp	q1, q2, [x10]
     3f4:      	fdiv.4s	v2, v2, v0
     3f8:      	fdiv.4s	v1, v1, v0
     3fc:      	add	x10, x28, x8
     400:      	ldp	q4, q3, [x10]
     404:      	fmul.4s	v1, v1, v4
     408:      	fmul.4s	v2, v2, v3
     40c:      	add	x10, x9, x8
     410:      	stp	q1, q2, [x10]
     414:      	add	x8, x8, #0x20
     418:      	cmp	x8, #0xc00
     41c:      	b.ne	0x3ec <ltmp0+0x3ec>
     420:      	orr	w8, w26, #0x2
     424:      	mov	w9, #0xc00              ; =3072
     428:      	umull	x19, w8, w9
     42c:      	umaddl	x1, w8, w9, x25
     430:      	add	x0, sp, #0xe50
     434:      	mov	w2, #0xc00              ; =3072
     438:      	bl	0x438 <ltmp0+0x438>
     43c:      	mov	x8, #0x0                ; =0
     440:      	ldr	q0, [x24, #0xcf0]
     444:      	ldr	q1, [x24, #0xd00]
     448:      	fmul.4s	v2, v1, v1
     44c:      	fmul.4s	v3, v0, v0
     450:      	ldr	q0, [x24, #0xd10]
     454:      	ldr	q1, [x24, #0xd20]
     458:      	fmul.4s	v4, v1, v1
     45c:      	fmul.4s	v5, v0, v0
     460:      	ldr	q0, [x24, #0xd30]
     464:      	ldr	q1, [x24, #0xd40]
     468:      	fmul.4s	v7, v1, v1
     46c:      	fmul.4s	v6, v0, v0
     470:      	ldr	q0, [x24, #0xd50]
     474:      	ldr	q1, [x24, #0xd60]
     478:      	fmul.4s	v16, v1, v1
     47c:      	fmul.4s	v17, v0, v0
     480:      	add	x9, x27, x8, lsl #5
     484:      	ldp	q1, q0, [x9, #0x80]
     488:      	fmul.4s	v1, v1, v1
     48c:      	fmul.4s	v0, v0, v0
     490:      	fadd.4s	v2, v2, v0
     494:      	fadd.4s	v3, v3, v1
     498:      	ldp	q1, q0, [x9, #0xa0]
     49c:      	fmul.4s	v1, v1, v1
     4a0:      	fmul.4s	v0, v0, v0
     4a4:      	fadd.4s	v4, v4, v0
     4a8:      	fadd.4s	v5, v5, v1
     4ac:      	ldp	q1, q0, [x9, #0xc0]
     4b0:      	fmul.4s	v1, v1, v1
     4b4:      	fmul.4s	v0, v0, v0
     4b8:      	fadd.4s	v7, v7, v0
     4bc:      	fadd.4s	v6, v6, v1
     4c0:      	ldp	q1, q0, [x9, #0xe0]
     4c4:      	fmul.4s	v1, v1, v1
     4c8:      	fmul.4s	v0, v0, v0
     4cc:      	fadd.4s	v16, v16, v0
     4d0:      	fadd.4s	v17, v17, v1
     4d4:      	add	x8, x8, #0x4
     4d8:      	cmp	x8, #0x5c
     4dc:      	b.lo	0x480 <ltmp0+0x480>
     4e0:      	add	x0, sp, #0x250
     4e4:      	mov	x1, x22
     4e8:      	mov	w2, #0xc00              ; =3072
     4ec:      	stp	q4, q2, [sp, #0x80]
     4f0:      	stp	q5, q3, [sp, #0x50]
     4f4:      	stp	q6, q16, [sp, #0xb0]
     4f8:      	str	q7, [sp, #0x70]
     4fc:      	str	q17, [sp, #0xa0]
     500:      	bl	0x500 <ltmp0+0x500>
     504:      	mov	x8, #0x0                ; =0
     508:      	ldp	q1, q0, [sp, #0x50]
     50c:      	fadd.4s	v0, v0, v1
     510:      	ldp	q2, q1, [sp, #0x80]
     514:      	fadd.4s	v1, v1, v2
     518:      	ldr	q2, [sp, #0x70]
     51c:      	fadd.4s	v1, v1, v2
     520:      	ldp	q2, q3, [sp, #0xa0]
     524:      	fadd.4s	v0, v0, v3
     528:      	fadd.4s	v0, v0, v2
     52c:      	ldr	q2, [sp, #0xc0]
     530:      	fadd.4s	v1, v1, v2
     534:      	rev64.4s	v2, v1
     538:      	rev64.4s	v3, v0
     53c:      	fadd.4s	v0, v0, v3
     540:      	fadd.4s	v1, v1, v2
     544:      	dup.4s	v2, v1[2]
     548:      	dup.4s	v3, v0[2]
     54c:      	fadd.4s	v0, v0, v3
     550:      	fadd.4s	v1, v1, v2
     554:      	fadd.4s	v0, v0, v1
     558:      	fadd	s0, s0, s8
     55c:      	mov	w9, #0x44400000         ; =1145044992
     560:      	fmov	s1, w9
     564:      	fdiv	s0, s0, s1
     568:      	mov	w9, #0xc5ac             ; =50604
     56c:      	movk	w9, #0x3727, lsl #16
     570:      	fmov	s1, w9
     574:      	fadd	s0, s0, s1
     578:      	fsqrt	s0, s0
     57c:      	dup.4s	v0, v0[0]
     580:      	add	x9, x20, x19
     584:      	add	x10, x27, x8
     588:      	ldp	q1, q2, [x10]
     58c:      	fdiv.4s	v2, v2, v0
     590:      	fdiv.4s	v1, v1, v0
     594:      	add	x10, x28, x8
     598:      	ldp	q4, q3, [x10]
     59c:      	fmul.4s	v1, v1, v4
     5a0:      	fmul.4s	v2, v2, v3
     5a4:      	add	x10, x9, x8
     5a8:      	stp	q1, q2, [x10]
     5ac:      	add	x8, x8, #0x20
     5b0:      	cmp	x8, #0xc00
     5b4:      	b.ne	0x584 <ltmp0+0x584>
     5b8:      	orr	w8, w26, #0x3
     5bc:      	mov	w9, #0xc00              ; =3072
     5c0:      	umull	x19, w8, w9
     5c4:      	umaddl	x1, w8, w9, x25
     5c8:      	add	x0, sp, #0xe50
     5cc:      	mov	w2, #0xc00              ; =3072
     5d0:      	bl	0x5d0 <ltmp0+0x5d0>
     5d4:      	mov	x8, #0x0                ; =0
     5d8:      	ldr	q0, [x24, #0xcf0]
     5dc:      	ldr	q1, [x24, #0xd00]
     5e0:      	fmul.4s	v2, v1, v1
     5e4:      	fmul.4s	v3, v0, v0
     5e8:      	ldr	q0, [x24, #0xd10]
     5ec:      	ldr	q1, [x24, #0xd20]
     5f0:      	fmul.4s	v4, v1, v1
     5f4:      	fmul.4s	v5, v0, v0
     5f8:      	ldr	q0, [x24, #0xd30]
     5fc:      	ldr	q1, [x24, #0xd40]
     600:      	fmul.4s	v7, v1, v1
     604:      	fmul.4s	v6, v0, v0
     608:      	ldr	q0, [x24, #0xd50]
     60c:      	ldr	q1, [x24, #0xd60]
     610:      	fmul.4s	v16, v1, v1
     614:      	fmul.4s	v17, v0, v0
     618:      	add	x9, x27, x8, lsl #5
     61c:      	ldp	q1, q0, [x9, #0x80]
     620:      	fmul.4s	v1, v1, v1
     624:      	fmul.4s	v0, v0, v0
     628:      	fadd.4s	v2, v2, v0
     62c:      	fadd.4s	v3, v3, v1
     630:      	ldp	q1, q0, [x9, #0xa0]
     634:      	fmul.4s	v1, v1, v1
     638:      	fmul.4s	v0, v0, v0
     63c:      	fadd.4s	v4, v4, v0
     640:      	fadd.4s	v5, v5, v1
     644:      	ldp	q1, q0, [x9, #0xc0]
     648:      	fmul.4s	v1, v1, v1
     64c:      	fmul.4s	v0, v0, v0
     650:      	fadd.4s	v7, v7, v0
     654:      	fadd.4s	v6, v6, v1
     658:      	ldp	q1, q0, [x9, #0xe0]
     65c:      	fmul.4s	v1, v1, v1
     660:      	fmul.4s	v0, v0, v0
     664:      	fadd.4s	v16, v16, v0
     668:      	fadd.4s	v17, v17, v1
     66c:      	add	x8, x8, #0x4
     670:      	cmp	x8, #0x5c
     674:      	b.lo	0x618 <ltmp0+0x618>
     678:      	add	x0, sp, #0x250
     67c:      	mov	x1, x22
     680:      	mov	w2, #0xc00              ; =3072
     684:      	stp	q4, q2, [sp, #0x80]
     688:      	stp	q5, q3, [sp, #0x50]
     68c:      	stp	q6, q16, [sp, #0xb0]
     690:      	str	q7, [sp, #0x70]
     694:      	str	q17, [sp, #0xa0]
     698:      	bl	0x698 <ltmp0+0x698>
     69c:      	mov	x8, #0x0                ; =0
     6a0:      	ldp	q1, q0, [sp, #0x50]
     6a4:      	fadd.4s	v0, v0, v1
     6a8:      	ldp	q2, q1, [sp, #0x80]
     6ac:      	fadd.4s	v1, v1, v2
     6b0:      	ldr	q2, [sp, #0x70]
     6b4:      	fadd.4s	v1, v1, v2
     6b8:      	ldp	q2, q3, [sp, #0xa0]
     6bc:      	fadd.4s	v0, v0, v3
     6c0:      	fadd.4s	v0, v0, v2
     6c4:      	ldr	q2, [sp, #0xc0]
     6c8:      	fadd.4s	v1, v1, v2
     6cc:      	rev64.4s	v2, v1
     6d0:      	rev64.4s	v3, v0
     6d4:      	fadd.4s	v0, v0, v3
     6d8:      	fadd.4s	v1, v1, v2
     6dc:      	dup.4s	v2, v1[2]
     6e0:      	dup.4s	v3, v0[2]
     6e4:      	add	x9, x20, x19
     6e8:      	fadd.4s	v0, v0, v3
     6ec:      	fadd.4s	v1, v1, v2
     6f0:      	fadd.4s	v0, v0, v1
     6f4:      	fadd	s0, s0, s8
     6f8:      	mov	w10, #0x44400000        ; =1145044992
     6fc:      	fmov	s1, w10
     700:      	fdiv	s0, s0, s1
     704:      	mov	w10, #0xc5ac            ; =50604
     708:      	movk	w10, #0x3727, lsl #16
     70c:      	fmov	s1, w10
     710:      	fadd	s0, s0, s1
     714:      	fsqrt	s0, s0
     718:      	dup.4s	v0, v0[0]
     71c:      	add	x10, x27, x8
     720:      	ldp	q1, q2, [x10]
     724:      	fdiv.4s	v2, v2, v0
     728:      	fdiv.4s	v1, v1, v0
     72c:      	add	x10, x28, x8
     730:      	ldp	q4, q3, [x10]
     734:      	fmul.4s	v1, v1, v4
     738:      	fmul.4s	v2, v2, v3
     73c:      	add	x10, x9, x8
     740:      	stp	q1, q2, [x10]
     744:      	add	x8, x8, #0x20
     748:      	cmp	x8, #0xc00
     74c:      	b.ne	0x71c <ltmp0+0x71c>
     750:      	ldr	w6, [sp, #0x48]
     754:      	ldr	w19, [sp, #0x3c]
     758:      	b	0x64 <ltmp0+0x64>
     75c:      	str	x13, [sp, #0x40]
     760:      	str	w23, [sp, #0x24]
     764:      	lsr	x20, x25, #3
     768:      	cmp	x25, #0x8
     76c:      	b.lo	0x93c <ltmp0+0x93c>
     770:      	mov	x26, #0x0               ; =0
     774:      	ldr	x8, [sp, #0x18]
     778:      	ldr	x21, [x8]
     77c:      	ldr	x22, [x8, #0x10]
     780:      	ldr	x8, [x8, #0x30]
     784:      	ldr	x9, [sp, #0x40]
     788:      	lsl	w19, w9, #2
     78c:      	and	x9, x9, #0x7ffffff
     790:      	mov	w10, #0x3000            ; =12288
     794:      	umaddl	x23, w9, w10, x8
     798:      	add	w8, w26, w19
     79c:      	and	x8, x8, #0x1fffffff
     7a0:      	mov	w9, #0xc00              ; =3072
     7a4:      	umaddl	x1, w8, w9, x21
     7a8:      	add	x0, sp, #0xe50
     7ac:      	mov	w2, #0xc00              ; =3072
     7b0:      	bl	0x7b0 <ltmp0+0x7b0>
     7b4:      	mov	x8, #0x0                ; =0
     7b8:      	ldr	q0, [x24, #0xcf0]
     7bc:      	ldr	q1, [x24, #0xd00]
     7c0:      	fmul.4s	v2, v1, v1
     7c4:      	fmul.4s	v3, v0, v0
     7c8:      	ldr	q0, [x24, #0xd10]
     7cc:      	ldr	q1, [x24, #0xd20]
     7d0:      	fmul.4s	v4, v1, v1
     7d4:      	fmul.4s	v5, v0, v0
     7d8:      	ldr	q0, [x24, #0xd30]
     7dc:      	ldr	q1, [x24, #0xd40]
     7e0:      	fmul.4s	v7, v1, v1
     7e4:      	fmul.4s	v6, v0, v0
     7e8:      	ldr	q0, [x24, #0xd50]
     7ec:      	ldr	q1, [x24, #0xd60]
     7f0:      	fmul.4s	v16, v1, v1
     7f4:      	fmul.4s	v17, v0, v0
     7f8:      	add	x9, x27, x8, lsl #5
     7fc:      	ldp	q1, q0, [x9, #0x80]
     800:      	fmul.4s	v1, v1, v1
     804:      	fmul.4s	v0, v0, v0
     808:      	fadd.4s	v2, v2, v0
     80c:      	fadd.4s	v3, v3, v1
     810:      	ldp	q1, q0, [x9, #0xa0]
     814:      	fmul.4s	v1, v1, v1
     818:      	fmul.4s	v0, v0, v0
     81c:      	fadd.4s	v4, v4, v0
     820:      	fadd.4s	v5, v5, v1
     824:      	ldp	q1, q0, [x9, #0xc0]
     828:      	fmul.4s	v1, v1, v1
     82c:      	fmul.4s	v0, v0, v0
     830:      	fadd.4s	v7, v7, v0
     834:      	fadd.4s	v6, v6, v1
     838:      	ldp	q1, q0, [x9, #0xe0]
     83c:      	fmul.4s	v1, v1, v1
     840:      	fmul.4s	v0, v0, v0
     844:      	fadd.4s	v16, v16, v0
     848:      	fadd.4s	v17, v17, v1
     84c:      	add	x8, x8, #0x4
     850:      	cmp	x8, #0x5c
     854:      	b.lo	0x7f8 <ltmp0+0x7f8>
     858:      	add	x0, sp, #0x250
     85c:      	mov	x1, x22
     860:      	mov	w2, #0xc00              ; =3072
     864:      	stp	q4, q2, [sp, #0x80]
     868:      	stp	q5, q3, [sp, #0x50]
     86c:      	stp	q6, q16, [sp, #0xb0]
     870:      	str	q7, [sp, #0x70]
     874:      	str	q17, [sp, #0xa0]
     878:      	bl	0x878 <ltmp0+0x878>
     87c:      	mov	x8, #0x0                ; =0
     880:      	ldp	q1, q0, [sp, #0x50]
     884:      	fadd.4s	v0, v0, v1
     888:      	ldp	q2, q1, [sp, #0x80]
     88c:      	fadd.4s	v1, v1, v2
     890:      	ldr	q2, [sp, #0x70]
     894:      	fadd.4s	v1, v1, v2
     898:      	ldp	q2, q3, [sp, #0xa0]
     89c:      	fadd.4s	v0, v0, v3
     8a0:      	fadd.4s	v0, v0, v2
     8a4:      	ldr	q2, [sp, #0xc0]
     8a8:      	fadd.4s	v1, v1, v2
     8ac:      	rev64.4s	v2, v1
     8b0:      	rev64.4s	v3, v0
     8b4:      	fadd.4s	v0, v0, v3
     8b8:      	fadd.4s	v1, v1, v2
     8bc:      	dup.4s	v2, v1[2]
     8c0:      	dup.4s	v3, v0[2]
     8c4:      	fadd.4s	v0, v0, v3
     8c8:      	fadd.4s	v1, v1, v2
     8cc:      	fadd.4s	v0, v0, v1
     8d0:      	fadd	s0, s0, s8
     8d4:      	mov	w9, #0x44400000         ; =1145044992
     8d8:      	fmov	s1, w9
     8dc:      	fdiv	s0, s0, s1
     8e0:      	mov	w9, #0xc5ac             ; =50604
     8e4:      	movk	w9, #0x3727, lsl #16
     8e8:      	fmov	s1, w9
     8ec:      	fadd	s0, s0, s1
     8f0:      	fsqrt	s0, s0
     8f4:      	dup.4s	v0, v0[0]
     8f8:      	add	x9, x27, x8
     8fc:      	ldp	q1, q2, [x9]
     900:      	fdiv.4s	v2, v2, v0
     904:      	fdiv.4s	v1, v1, v0
     908:      	add	x9, x28, x8
     90c:      	ldp	q4, q3, [x9]
     910:      	fmul.4s	v1, v1, v4
     914:      	fmul.4s	v2, v2, v3
     918:      	add	x9, x23, x8
     91c:      	stp	q1, q2, [x9]
     920:      	add	x8, x8, #0x20
     924:      	cmp	x8, #0xc00
     928:      	b.ne	0x8f8 <ltmp0+0x8f8>
     92c:      	add	x26, x26, #0x1
     930:      	add	x23, x23, #0xc00
     934:      	cmp	x26, x20
     938:      	b.ne	0x798 <ltmp0+0x798>
     93c:      	and	w8, w25, #0x7
     940:      	ldr	w19, [sp, #0x3c]
     944:      	ldr	w23, [sp, #0x24]
     948:      	ldr	w6, [sp, #0x48]
     94c:      	ldr	x21, [sp, #0x40]
     950:      	cbz	w8, 0x64 <ltmp0+0x64>
     954:      	dup.4s	v1, w8
     958:      	adrp	x8, 0x0 <ltmp0>
     95c:      	ldr	q3, [x8]
     960:      	adrp	x8, 0x0 <ltmp0>
     964:      	ldr	q4, [x8]
     968:      	cmhi.4s	v0, v1, v4
     96c:      	cmhi.4s	v1, v1, v3
     970:      	uzp1.8h	v5, v1, v0
     974:      	umaxv.8h	h2, v5
     978:      	fmov	w8, s2
     97c:      	tbz	w8, #0x0, 0x64 <ltmp0+0x64>
     980:      	mov	x12, #0x0               ; =0
     984:      	ldr	x13, [sp, #0x18]
     988:      	ldr	x11, [x13, #0x10]
     98c:      	ldr	x8, [x13, #0x30]
     990:      	adrp	x9, 0x0 <ltmp0>
     994:      	ldr	q2, [x9]
     998:      	and.16b	v2, v5, v2
     99c:      	addv.8h	h2, v2
     9a0:      	fmov	w9, s2
     9a4:      	and	w10, w9, #0xff
     9a8:      	ubfiz	w9, w21, #2, #27
     9ac:      	orr	w9, w9, w20
     9b0:      	ldr	x13, [x13]
     9b4:      	fmov	s6, w9
     9b8:      	and.16b	v6, v1, v6
     9bc:      	fmov	w9, s6
     9c0:      	mov	w14, #0xc00             ; =3072
     9c4:      	umaddl	x13, w9, w14, x13
     9c8:      	umull	x9, w9, w14
     9cc:      	b	0x9f0 <ltmp0+0x9f0>
     9d0:      	add	x14, x27, x12
     9d4:      	ldp	q16, q17, [x14]
     9d8:      	bif.16b	v7, v17, v0
     9dc:      	bif.16b	v6, v16, v1
     9e0:      	stp	q6, q7, [x14]
     9e4:      	add	x12, x12, #0x20
     9e8:      	cmp	x12, #0xc00
     9ec:      	b.eq	0xa88 <ltmp0+0xa88>
     9f0:      	fmov	w15, s2
     9f4:      	add	x14, x13, x12
     9f8:      	movi.2d	v6, #0000000000000000
     9fc:      	movi.2d	v7, #0000000000000000
     a00:      	tbnz	w15, #0x0, 0xa28 <ltmp0+0xa28>
     a04:      	and	w15, w15, #0xff
     a08:      	tbnz	w15, #0x1, 0xa34 <ltmp0+0xa34>
     a0c:      	tbnz	w15, #0x2, 0xa40 <ltmp0+0xa40>
     a10:      	tbnz	w15, #0x3, 0xa4c <ltmp0+0xa4c>
     a14:      	tbnz	w15, #0x4, 0xa58 <ltmp0+0xa58>
     a18:      	tbnz	w15, #0x5, 0xa64 <ltmp0+0xa64>
     a1c:      	tbnz	w15, #0x6, 0xa70 <ltmp0+0xa70>
     a20:      	tbz	w15, #0x7, 0x9d0 <ltmp0+0x9d0>
     a24:      	b	0xa7c <ltmp0+0xa7c>
     a28:      	ldr	s6, [x14]
     a2c:      	and	w15, w15, #0xff
     a30:      	tbz	w15, #0x1, 0xa0c <ltmp0+0xa0c>
     a34:      	add	x16, x14, #0x4
     a38:      	ld1.s	{ v6 }[1], [x16]
     a3c:      	tbz	w15, #0x2, 0xa10 <ltmp0+0xa10>
     a40:      	add	x16, x14, #0x8
     a44:      	ld1.s	{ v6 }[2], [x16]
     a48:      	tbz	w15, #0x3, 0xa14 <ltmp0+0xa14>
     a4c:      	add	x16, x14, #0xc
     a50:      	ld1.s	{ v6 }[3], [x16]
     a54:      	tbz	w15, #0x4, 0xa18 <ltmp0+0xa18>
     a58:      	add	x16, x14, #0x10
     a5c:      	ld1.s	{ v7 }[0], [x16]
     a60:      	tbz	w15, #0x5, 0xa1c <ltmp0+0xa1c>
     a64:      	add	x16, x14, #0x14
     a68:      	ld1.s	{ v7 }[1], [x16]
     a6c:      	tbz	w15, #0x6, 0xa20 <ltmp0+0xa20>
     a70:      	add	x16, x14, #0x18
     a74:      	ld1.s	{ v7 }[2], [x16]
     a78:      	tbz	w15, #0x7, 0x9d0 <ltmp0+0x9d0>
     a7c:      	add	x14, x14, #0x1c
     a80:      	ld1.s	{ v7 }[3], [x14]
     a84:      	b	0x9d0 <ltmp0+0x9d0>
     a88:      	ldr	q6, [x24, #0xd00]
     a8c:      	ldr	q7, [x24, #0xcf0]
     a90:      	fmul.4s	v16, v7, v7
     a94:      	fmul.4s	v6, v6, v6
     a98:      	ldr	q7, [x24, #0xd20]
     a9c:      	ldr	q17, [x24, #0xd10]
     aa0:      	fmul.4s	v17, v17, v17
     aa4:      	fmul.4s	v18, v7, v7
     aa8:      	ldr	q7, [x24, #0xd40]
     aac:      	ldr	q19, [x24, #0xd30]
     ab0:      	fmul.4s	v21, v19, v19
     ab4:      	fmul.4s	v22, v7, v7
     ab8:      	ldr	q7, [x24, #0xd60]
     abc:      	ldr	q19, [x24, #0xd50]
     ac0:      	fmul.4s	v23, v19, v19
     ac4:      	fmul.4s	v24, v7, v7
     ac8:      	and.16b	v7, v0, v6
     acc:      	and.16b	v6, v1, v16
     ad0:      	and.16b	v20, v0, v18
     ad4:      	and.16b	v19, v1, v17
     ad8:      	and.16b	v16, v0, v22
     adc:      	and.16b	v21, v1, v21
     ae0:      	and.16b	v18, v0, v24
     ae4:      	and.16b	v17, v1, v23
     ae8:      	ldr	x12, [sp, #0x10]
     aec:      	mov	w13, #0x4               ; =4
     af0:      	ldp	q23, q22, [x12, #-0x60]
     af4:      	and.16b	v23, v1, v23
     af8:      	and.16b	v22, v0, v22
     afc:      	fmul.4s	v22, v22, v22
     b00:      	fmul.4s	v23, v23, v23
     b04:      	fadd.4s	v23, v6, v23
     b08:      	fadd.4s	v22, v7, v22
     b0c:      	ldp	q25, q24, [x12, #-0x40]
     b10:      	and.16b	v25, v1, v25
     b14:      	and.16b	v24, v0, v24
     b18:      	fmul.4s	v24, v24, v24
     b1c:      	fmul.4s	v25, v25, v25
     b20:      	fadd.4s	v25, v19, v25
     b24:      	fadd.4s	v24, v20, v24
     b28:      	ldp	q27, q26, [x12, #-0x20]
     b2c:      	and.16b	v27, v1, v27
     b30:      	and.16b	v26, v0, v26
     b34:      	fmul.4s	v26, v26, v26
     b38:      	fmul.4s	v27, v27, v27
     b3c:      	fadd.4s	v27, v21, v27
     b40:      	fadd.4s	v26, v16, v26
     b44:      	ldp	q29, q28, [x12], #0x80
     b48:      	and.16b	v29, v1, v29
     b4c:      	and.16b	v28, v0, v28
     b50:      	fmul.4s	v28, v28, v28
     b54:      	fmul.4s	v29, v29, v29
     b58:      	fadd.4s	v29, v17, v29
     b5c:      	fadd.4s	v28, v18, v28
     b60:      	bit.16b	v7, v22, v0
     b64:      	bit.16b	v6, v23, v1
     b68:      	bit.16b	v20, v24, v0
     b6c:      	bit.16b	v19, v25, v1
     b70:      	bit.16b	v16, v26, v0
     b74:      	bit.16b	v21, v27, v1
     b78:      	bit.16b	v18, v28, v0
     b7c:      	bit.16b	v17, v29, v1
     b80:      	cmp	x13, #0x5c
     b84:      	add	x13, x13, #0x4
     b88:      	b.lo	0xaf0 <ltmp0+0xaf0>
     b8c:      	mov	x12, #0x0               ; =0
     b90:      	b	0xbb4 <ltmp0+0xbb4>
     b94:      	add	x13, x28, x12
     b98:      	ldp	q24, q25, [x13]
     b9c:      	bif.16b	v23, v25, v0
     ba0:      	bif.16b	v22, v24, v1
     ba4:      	stp	q22, q23, [x13]
     ba8:      	add	x12, x12, #0x20
     bac:      	cmp	x12, #0xc00
     bb0:      	b.eq	0xc4c <ltmp0+0xc4c>
     bb4:      	fmov	w14, s2
     bb8:      	add	x13, x11, x12
     bbc:      	movi.2d	v22, #0000000000000000
     bc0:      	movi.2d	v23, #0000000000000000
     bc4:      	tbnz	w14, #0x0, 0xbec <ltmp0+0xbec>
     bc8:      	and	w14, w14, #0xff
     bcc:      	tbnz	w14, #0x1, 0xbf8 <ltmp0+0xbf8>
     bd0:      	tbnz	w14, #0x2, 0xc04 <ltmp0+0xc04>
     bd4:      	tbnz	w14, #0x3, 0xc10 <ltmp0+0xc10>
     bd8:      	tbnz	w14, #0x4, 0xc1c <ltmp0+0xc1c>
     bdc:      	tbnz	w14, #0x5, 0xc28 <ltmp0+0xc28>
     be0:      	tbnz	w14, #0x6, 0xc34 <ltmp0+0xc34>
     be4:      	tbz	w14, #0x7, 0xb94 <ltmp0+0xb94>
     be8:      	b	0xc40 <ltmp0+0xc40>
     bec:      	ldr	s22, [x13]
     bf0:      	and	w14, w14, #0xff
     bf4:      	tbz	w14, #0x1, 0xbd0 <ltmp0+0xbd0>
     bf8:      	add	x15, x13, #0x4
     bfc:      	ld1.s	{ v22 }[1], [x15]
     c00:      	tbz	w14, #0x2, 0xbd4 <ltmp0+0xbd4>
     c04:      	add	x15, x13, #0x8
     c08:      	ld1.s	{ v22 }[2], [x15]
     c0c:      	tbz	w14, #0x3, 0xbd8 <ltmp0+0xbd8>
     c10:      	add	x15, x13, #0xc
     c14:      	ld1.s	{ v22 }[3], [x15]
     c18:      	tbz	w14, #0x4, 0xbdc <ltmp0+0xbdc>
     c1c:      	add	x15, x13, #0x10
     c20:      	ld1.s	{ v23 }[0], [x15]
     c24:      	tbz	w14, #0x5, 0xbe0 <ltmp0+0xbe0>
     c28:      	add	x15, x13, #0x14
     c2c:      	ld1.s	{ v23 }[1], [x15]
     c30:      	tbz	w14, #0x6, 0xbe4 <ltmp0+0xbe4>
     c34:      	add	x15, x13, #0x18
     c38:      	ld1.s	{ v23 }[2], [x15]
     c3c:      	tbz	w14, #0x7, 0xb94 <ltmp0+0xb94>
     c40:      	add	x13, x13, #0x1c
     c44:      	ld1.s	{ v23 }[3], [x13]
     c48:      	b	0xb94 <ltmp0+0xb94>
     c4c:      	mov	x11, #0x0               ; =0
     c50:      	xtn.8b	v22, v5
     c54:      	fadd.4s	v5, v7, v20
     c58:      	fadd.4s	v6, v6, v19
     c5c:      	fadd.4s	v6, v6, v21
     c60:      	fadd.4s	v5, v5, v16
     c64:      	fadd.4s	v5, v5, v18
     c68:      	fadd.4s	v6, v6, v17
     c6c:      	and.16b	v16, v1, v3
     c70:      	and.16b	v3, v0, v4
     c74:      	movi.4s	v4, #0x1
     c78:      	eor.16b	v7, v3, v4
     c7c:      	eor.16b	v18, v16, v4
     c80:      	umov.b	w13, v22[0]
     c84:      	str	q6, [x24, #0xc0]
     c88:      	ldr	s4, [x24, #0xc4]
     c8c:      	umov.b	w12, v22[1]
     c90:      	ands	w14, w13, #0x1
     c94:      	tst	w14, w12
     c98:      	mov.s	w15, v18[1]
     c9c:      	fcsel	s4, s4, s8, ne
     ca0:      	add	x16, sp, #0xd8
     ca4:      	bfxil	x16, x15, #0, #3
     ca8:      	str	d22, [sp, #0xd8]
     cac:      	ldrb	w16, [x16]
     cb0:      	add	x17, sp, #0x200
     cb4:      	orr	x15, x17, x15, lsl #2
     cb8:      	stp	q6, q5, [x24, #0xa0]
     cbc:      	ldr	s16, [x15]
     cc0:      	ands	w15, w12, #0x1
     cc4:      	tst	w15, w16
     cc8:      	fcsel	s16, s16, s8, ne
     ccc:      	mov.s	w15, v18[2]
     cd0:      	add	x16, sp, #0xd8
     cd4:      	bfxil	x16, x15, #0, #3
     cd8:      	ldrb	w16, [x16]
     cdc:      	add	x17, sp, #0x1e0
     ce0:      	orr	x17, x17, x15, lsl #2
     ce4:      	umov.b	w15, v22[2]
     ce8:      	stp	q6, q5, [x24, #0x80]
     cec:      	ldr	s17, [x17]
     cf0:      	ands	w17, w15, #0x1
     cf4:      	tst	w17, w16
     cf8:      	fcsel	s17, s17, s8, ne
     cfc:      	mov.s	w16, v18[3]
     d00:      	add	x17, sp, #0xd8
     d04:      	bfxil	x17, x16, #0, #3
     d08:      	ldrb	w17, [x17]
     d0c:      	add	x0, sp, #0x1c0
     d10:      	orr	x0, x0, x16, lsl #2
     d14:      	umov.b	w16, v22[3]
     d18:      	stp	q6, q5, [x24, #0x60]
     d1c:      	ldr	s18, [x0]
     d20:      	ands	w0, w16, #0x1
     d24:      	tst	w0, w17
     d28:      	fcsel	s18, s18, s8, ne
     d2c:      	fmov	w0, s7
     d30:      	add	x17, sp, #0xd8
     d34:      	bfxil	x17, x0, #0, #3
     d38:      	ldrb	w1, [x17]
     d3c:      	umov.b	w17, v22[4]
     d40:      	and	w1, w17, w1
     d44:      	stp	q6, q5, [x24, #0x40]
     d48:      	add	x2, sp, #0x1a0
     d4c:      	ldr	s19, [x2, w0, uxtw #2]
     d50:      	tst	w1, #0x1
     d54:      	mov.s	w1, v7[1]
     d58:      	fcsel	s19, s19, s8, ne
     d5c:      	add	x0, sp, #0xd8
     d60:      	bfxil	x0, x1, #0, #3
     d64:      	ldrb	w2, [x0]
     d68:      	umov.b	w0, v22[5]
     d6c:      	stp	q6, q5, [x24, #0x20]
     d70:      	add	x3, sp, #0x180
     d74:      	ldr	s20, [x3, w1, uxtw #2]
     d78:      	ands	w1, w0, #0x1
     d7c:      	tst	w1, w2
     d80:      	fcsel	s20, s20, s8, ne
     d84:      	mov.s	w2, v7[2]
     d88:      	add	x1, sp, #0xd8
     d8c:      	bfxil	x1, x2, #0, #3
     d90:      	ldrb	w3, [x1]
     d94:      	umov.b	w1, v22[6]
     d98:      	stp	q6, q5, [x24]
     d9c:      	ldr	s21, [x24, w2, uxtw #2]
     da0:      	ands	w2, w1, #0x1
     da4:      	tst	w2, w3
     da8:      	fcsel	s21, s21, s8, ne
     dac:      	mov.s	w3, v7[3]
     db0:      	add	x2, sp, #0xd8
     db4:      	bfxil	x2, x3, #0, #3
     db8:      	ldrb	w4, [x2]
     dbc:      	umov.b	w2, v22[7]
     dc0:      	stp	q6, q5, [sp, #0x140]
     dc4:      	add	x5, sp, #0x140
     dc8:      	ldr	s7, [x5, w3, uxtw #2]
     dcc:      	ands	w3, w2, #0x1
     dd0:      	tst	w3, w4
     dd4:      	mov.s	v4[1], v16[0]
     dd8:      	mov.s	v4[2], v17[0]
     ddc:      	mov.s	v4[3], v18[0]
     de0:      	mov.s	v19[1], v20[0]
     de4:      	fcsel	s7, s7, s8, ne
     de8:      	mov.s	v19[2], v21[0]
     dec:      	mov.s	v19[3], v7[0]
     df0:      	fadd.4s	v5, v5, v19
     df4:      	fadd.4s	v4, v6, v4
     df8:      	movi.4s	v6, #0x2
     dfc:      	eor.16b	v3, v3, v6
     e00:      	str	q4, [sp, #0x120]
     e04:      	ldr	s6, [sp, #0x128]
     e08:      	fmov	w3, s3
     e0c:      	add	x4, sp, #0xd8
     e10:      	bfxil	x4, x3, #0, #3
     e14:      	ldrb	w4, [x4]
     e18:      	stp	q4, q5, [sp, #0x100]
     e1c:      	add	x5, sp, #0x100
     e20:      	ldr	s3, [x5, w3, uxtw #2]
     e24:      	tst	w14, w15
     e28:      	fcsel	s6, s6, s8, ne
     e2c:      	and	w3, w17, w4
     e30:      	tst	w3, #0x1
     e34:      	fcsel	s3, s3, s8, ne
     e38:      	fadd.4s	v3, v5, v3
     e3c:      	tst	w14, w17
     e40:      	fcsel	s3, s3, s8, ne
     e44:      	ands	w13, w13, #0x1
     e48:      	fadd.4s	v4, v4, v6
     e4c:      	fadd	s3, s4, s3
     e50:      	fcsel	s4, s3, s8, ne
     e54:      	tst	w12, #0x1
     e58:      	fcsel	s5, s4, s8, ne
     e5c:      	tst	w15, #0x1
     e60:      	fcsel	s6, s4, s8, ne
     e64:      	tst	w16, #0x1
     e68:      	fcsel	s7, s4, s8, ne
     e6c:      	tst	w13, w17
     e70:      	fcsel	s3, s3, s8, ne
     e74:      	tst	w0, #0x1
     e78:      	fcsel	s16, s4, s8, ne
     e7c:      	tst	w1, #0x1
     e80:      	fcsel	s17, s4, s8, ne
     e84:      	tst	w2, #0x1
     e88:      	fcsel	s18, s4, s8, ne
     e8c:      	mov.s	v4[1], v5[0]
     e90:      	mov.s	v4[2], v6[0]
     e94:      	mov.s	v4[3], v7[0]
     e98:      	mov.s	v3[1], v16[0]
     e9c:      	mov.s	v3[2], v17[0]
     ea0:      	mov.s	v3[3], v18[0]
     ea4:      	rbit	w10, w10
     ea8:      	clz	w10, w10
     eac:      	stp	q4, q3, [sp, #0xe0]
     eb0:      	and	x10, x10, #0x7
     eb4:      	add	x12, sp, #0xe0
     eb8:      	ldr	s3, [x12, x10, lsl #2]
     ebc:      	fadd	s3, s3, s8
     ec0:      	mov	w10, #0x44400000        ; =1145044992
     ec4:      	fmov	s4, w10
     ec8:      	fdiv	s3, s3, s4
     ecc:      	mov	w10, #0xc5ac            ; =50604
     ed0:      	movk	w10, #0x3727, lsl #16
     ed4:      	fmov	s4, w10
     ed8:      	fadd	s3, s3, s4
     edc:      	fsqrt	s3, s3
     ee0:      	dup.4s	v3, v3[0]
     ee4:      	add	x8, x8, x9
     ee8:      	b	0xef8 <ltmp0+0xef8>
     eec:      	add	x11, x11, #0x20
     ef0:      	cmp	x11, #0xc00
     ef4:      	b.eq	0x64 <ltmp0+0x64>
     ef8:      	fmov	w10, s2
     efc:      	add	x9, x27, x11
     f00:      	ldp	q5, q4, [x9]
     f04:      	and.16b	v5, v1, v5
     f08:      	fdiv.4s	v6, v5, v3
     f0c:      	add	x9, x28, x11
     f10:      	ldp	q7, q5, [x9]
     f14:      	and.16b	v7, v1, v7
     f18:      	fmul.4s	v6, v6, v7
     f1c:      	add	x9, x8, x11
     f20:      	tbnz	w10, #0x0, 0xf58 <ltmp0+0xf58>
     f24:      	and	w10, w10, #0xff
     f28:      	tbnz	w10, #0x1, 0xf64 <ltmp0+0xf64>
     f2c:      	tbnz	w10, #0x2, 0xf70 <ltmp0+0xf70>
     f30:      	tbnz	w10, #0x3, 0xf7c <ltmp0+0xf7c>
     f34:      	and.16b	v4, v0, v4
     f38:      	fdiv.4s	v4, v4, v3
     f3c:      	and.16b	v5, v0, v5
     f40:      	fmul.4s	v4, v4, v5
     f44:      	tbnz	w10, #0x4, 0xf98 <ltmp0+0xf98>
     f48:      	tbnz	w10, #0x5, 0xfa0 <ltmp0+0xfa0>
     f4c:      	tbnz	w10, #0x6, 0xfac <ltmp0+0xfac>
     f50:      	tbz	w10, #0x7, 0xeec <ltmp0+0xeec>
     f54:      	b	0xfb8 <ltmp0+0xfb8>
     f58:      	str	s6, [x9]
     f5c:      	and	w10, w10, #0xff
     f60:      	tbz	w10, #0x1, 0xf2c <ltmp0+0xf2c>
     f64:      	add	x12, x9, #0x4
     f68:      	st1.s	{ v6 }[1], [x12]
     f6c:      	tbz	w10, #0x2, 0xf30 <ltmp0+0xf30>
     f70:      	add	x12, x9, #0x8
     f74:      	st1.s	{ v6 }[2], [x12]
     f78:      	tbz	w10, #0x3, 0xf34 <ltmp0+0xf34>
     f7c:      	add	x12, x9, #0xc
     f80:      	st1.s	{ v6 }[3], [x12]
     f84:      	and.16b	v4, v0, v4
     f88:      	fdiv.4s	v4, v4, v3
     f8c:      	and.16b	v5, v0, v5
     f90:      	fmul.4s	v4, v4, v5
     f94:      	tbz	w10, #0x4, 0xf48 <ltmp0+0xf48>
     f98:      	str	s4, [x9, #0x10]
     f9c:      	tbz	w10, #0x5, 0xf4c <ltmp0+0xf4c>
     fa0:      	add	x12, x9, #0x14
     fa4:      	st1.s	{ v4 }[1], [x12]
     fa8:      	tbz	w10, #0x6, 0xf50 <ltmp0+0xf50>
     fac:      	add	x12, x9, #0x18
     fb0:      	st1.s	{ v4 }[2], [x12]
     fb4:      	tbz	w10, #0x7, 0xeec <ltmp0+0xeec>
     fb8:      	add	x9, x9, #0x1c
     fbc:      	st1.s	{ v4 }[3], [x9]
     fc0:      	b	0xeec <ltmp0+0xeec>
     fc4:      	ldr	x9, [sp, #0x8]
     fc8:      	stp	w21, w6, [x9]
     fcc:      	str	w12, [x9, #0x8]
     fd0:      	mov	w8, #0x18               ; =24
     fd4:      	str	w8, [x9, #0x24]
     fd8:      	add	sp, sp, #0x1, lsl #12   ; =0x1000
     fdc:      	add	sp, sp, #0xa50
     fe0:      	ldp	x29, x30, [sp, #0x60]
     fe4:      	ldp	x20, x19, [sp, #0x50]
     fe8:      	ldp	x22, x21, [sp, #0x40]
     fec:      	ldp	x24, x23, [sp, #0x30]
     ff0:      	ldp	x26, x25, [sp, #0x20]
     ff4:      	ldp	x28, x27, [sp, #0x10]
     ff8:      	ldp	d9, d8, [sp], #0x70
     ffc:      	ret

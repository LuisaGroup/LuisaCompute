
/private/tmp/luisa-expression-fusion.qXgTbC/capture/swiglu-1024x4097/off/object/tile_xir_w8_23442_1788930269533566_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d11, d10, [sp, #-0x70]!
       4:      	stp	d9, d8, [sp, #0x10]
       8:      	stp	x28, x27, [sp, #0x20]
       c:      	stp	x24, x23, [sp, #0x30]
      10:      	stp	x22, x21, [sp, #0x40]
      14:      	stp	x20, x19, [sp, #0x50]
      18:      	stp	x29, x30, [sp, #0x60]
      1c:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
      20:      	sub	sp, sp, #0x50
      24:      	ldr	x22, [x0]
      28:      	ldr	x23, [x0, #0x10]
      2c:      	ldr	x19, [x0, #0x30]
      30:      	ldr	w8, [x1]
      34:      	ldr	w9, [x1, #0x24]
      38:      	add	w8, w9, w8, lsl #5
      3c:      	lsr	w8, w8, #3
      40:      	fmov	s0, w8
      44:      	ushll.2d	v0, v0, #0x0
      48:      	fmov	x8, d0
      4c:      	add	x8, x8, x8, lsl #12
      50:      	lsl	x24, x8, #2
      54:      	add	x21, sp, #0x4, lsl #12  ; =0x4000
      58:      	add	x21, x21, #0x30
      5c:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
      60:      	add	x0, x0, #0x30
      64:      	add	x1, x22, x24
      68:      	mov	w2, #0x4000             ; =16384
      6c:      	bl	0x6c <ltmp0+0x6c>
      70:      	add	x20, x24, #0x4, lsl #12 ; =0x4000
      74:      	ldr	s0, [x22, x20]
      78:      	str	q0, [sp]
      7c:      	str	q0, [sp, #0x8030]
      80:      	add	x22, sp, #0x10
      84:      	add	x0, sp, #0x10
      88:      	add	x1, x23, x24
      8c:      	mov	w2, #0x4000             ; =16384
      90:      	bl	0x90 <ltmp0+0x90>
      94:      	mov	x8, #0x0                ; =0
      98:      	ldr	s0, [x23, x20]
      9c:      	mov	w9, #0x42d00000         ; =1120927744
      a0:      	dup.4s	v2, w9
      a4:      	mov	w9, #-0x3d380000        ; =-1027080192
      a8:      	dup.4s	v3, w9
      ac:      	mov	w9, #0xaa3b             ; =43579
      b0:      	movk	w9, #0x3fb8, lsl #16
      b4:      	dup.4s	v4, w9
      b8:      	mov	w9, #0x7200             ; =29184
      bc:      	movk	w9, #0xbf31, lsl #16
      c0:      	dup.4s	v5, w9
      c4:      	mov	w9, #0xbe8e             ; =48782
      c8:      	movk	w9, #0xb5bf, lsl #16
      cc:      	dup.4s	v6, w9
      d0:      	mov	w9, #0x2bda             ; =11226
      d4:      	movk	w9, #0x3950, lsl #16
      d8:      	dup.4s	v7, w9
      dc:      	mov	w9, #0x96c9             ; =38601
      e0:      	movk	w9, #0x3ab6, lsl #16
      e4:      	dup.4s	v16, w9
      e8:      	mov	w9, #0x88a6             ; =34982
      ec:      	movk	w9, #0x3c08, lsl #16
      f0:      	dup.4s	v17, w9
      f4:      	mov	w9, #0xaa7a             ; =43642
      f8:      	movk	w9, #0x3d2a, lsl #16
      fc:      	dup.4s	v18, w9
     100:      	mov	w9, #0xaaab             ; =43691
     104:      	movk	w9, #0x3e2a, lsl #16
     108:      	dup.4s	v19, w9
     10c:      	str	q0, [sp, #0x4010]
     110:      	add	x9, x19, x24
     114:      	movi.4s	v20, #0x4b, lsl #24
     118:      	mvni.4s	v21, #0x80, lsl #24
     11c:      	movi.4s	v22, #0x3f, lsl #24
     120:      	fmov.4s	v1, #1.00000000
     124:      	mvni.4s	v23, #0x7f, msl #16
     128:      	fneg.4s	v23, v23
     12c:      	mvni.4s	v24, #0x3f, msl #16
     130:      	fneg.4s	v24, v24
     134:      	add	x10, x21, x8
     138:      	ldp	q25, q26, [x10]
     13c:      	fneg.4s	v27, v26
     140:      	fneg.4s	v28, v25
     144:      	fcmge.4s	v29, v2, v25
     148:      	fcmge.4s	v30, v2, v26
     14c:      	fcmge.4s	v31, v25, v3
     150:      	fcmge.4s	v8, v26, v3
     154:      	and.16b	v30, v30, v8
     158:      	and.16b	v29, v29, v31
     15c:      	and.16b	v28, v29, v28
     160:      	and.16b	v27, v30, v27
     164:      	fmul.4s	v29, v27, v4
     168:      	fmul.4s	v30, v28, v4
     16c:      	mov.16b	v31, v21
     170:      	bsl.16b	v31, v20, v30
     174:      	mov.16b	v8, v21
     178:      	bsl.16b	v8, v20, v29
     17c:      	fadd.4s	v29, v29, v8
     180:      	fadd.4s	v30, v30, v31
     184:      	fsub.4s	v30, v30, v31
     188:      	fsub.4s	v29, v29, v8
     18c:      	fcvtzs.4s	v29, v29
     190:      	fcvtzs.4s	v30, v30
     194:      	scvtf.4s	v31, v30
     198:      	scvtf.4s	v8, v29
     19c:      	fmul.4s	v9, v8, v5
     1a0:      	fmul.4s	v10, v31, v5
     1a4:      	fadd.4s	v28, v28, v10
     1a8:      	fadd.4s	v27, v27, v9
     1ac:      	fmul.4s	v31, v31, v6
     1b0:      	fmul.4s	v8, v8, v6
     1b4:      	fadd.4s	v27, v27, v8
     1b8:      	fadd.4s	v28, v28, v31
     1bc:      	fmul.4s	v31, v28, v7
     1c0:      	fmul.4s	v8, v27, v7
     1c4:      	fadd.4s	v8, v8, v16
     1c8:      	fadd.4s	v31, v31, v16
     1cc:      	fmul.4s	v31, v28, v31
     1d0:      	fmul.4s	v8, v27, v8
     1d4:      	fadd.4s	v8, v8, v17
     1d8:      	fadd.4s	v31, v31, v17
     1dc:      	fmul.4s	v31, v28, v31
     1e0:      	fmul.4s	v8, v27, v8
     1e4:      	fadd.4s	v8, v8, v18
     1e8:      	fadd.4s	v31, v31, v18
     1ec:      	fmul.4s	v31, v28, v31
     1f0:      	fmul.4s	v8, v27, v8
     1f4:      	fadd.4s	v8, v8, v19
     1f8:      	fadd.4s	v31, v31, v19
     1fc:      	fmul.4s	v31, v28, v31
     200:      	fmul.4s	v8, v27, v8
     204:      	fadd.4s	v8, v8, v22
     208:      	fadd.4s	v31, v31, v22
     20c:      	fmul.4s	v9, v27, v27
     210:      	fmul.4s	v10, v28, v28
     214:      	fmul.4s	v31, v10, v31
     218:      	fmul.4s	v8, v9, v8
     21c:      	fadd.4s	v27, v27, v8
     220:      	fadd.4s	v28, v28, v31
     224:      	sshr.4s	v31, v30, #0x1
     228:      	fadd.4s	v28, v28, v1
     22c:      	sshr.4s	v8, v29, #0x1
     230:      	shl.4s	v9, v8, #0x17
     234:      	shl.4s	v10, v31, #0x17
     238:      	add.4s	v10, v10, v1
     23c:      	add.4s	v9, v9, v1
     240:      	fadd.4s	v27, v27, v1
     244:      	fmul.4s	v27, v27, v9
     248:      	sub.4s	v29, v29, v8
     24c:      	sub.4s	v30, v30, v31
     250:      	shl.4s	v30, v30, #0x17
     254:      	shl.4s	v29, v29, #0x17
     258:      	fmul.4s	v28, v28, v10
     25c:      	add.4s	v29, v29, v1
     260:      	add.4s	v30, v30, v1
     264:      	fmul.4s	v28, v28, v30
     268:      	fmul.4s	v27, v27, v29
     26c:      	fcmgt.4s	v29, v26, v2
     270:      	fcmgt.4s	v30, v25, v2
     274:      	fcmgt.4s	v31, v3, v25
     278:      	fcmgt.4s	v8, v3, v26
     27c:      	fcmeq.4s	v9, v26, v26
     280:      	fadd.4s	v27, v27, v1
     284:      	fadd.4s	v28, v28, v1
     288:      	fcmeq.4s	v10, v25, v25
     28c:      	bit.16b	v28, v1, v30
     290:      	bit.16b	v27, v1, v29
     294:      	bit.16b	v27, v23, v8
     298:      	bit.16b	v28, v23, v31
     29c:      	bif.16b	v28, v24, v10
     2a0:      	bif.16b	v27, v24, v9
     2a4:      	fdiv.4s	v26, v26, v27
     2a8:      	fdiv.4s	v25, v25, v28
     2ac:      	add	x10, x22, x8
     2b0:      	ldp	q28, q27, [x10]
     2b4:      	fmul.4s	v25, v28, v25
     2b8:      	fmul.4s	v26, v27, v26
     2bc:      	add	x10, x9, x8
     2c0:      	stp	q25, q26, [x10]
     2c4:      	add	x8, x8, #0x20
     2c8:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     2cc:      	b.ne	0x134 <ltmp0+0x134>
     2d0:      	movi.2d	v2, #0000000000000000
     2d4:      	ldr	q17, [sp]
     2d8:      	fneg.4s	v3, v17
     2dc:      	mov.s	v2[0], v3[0]
     2e0:      	mov	w8, #-0x3d300000        ; =-1026555904
     2e4:      	dup.4s	v3, w8
     2e8:      	mov	w8, #0x42c80000         ; =1120403456
     2ec:      	dup.4s	v4, w8
     2f0:      	fcmge.4s	v5, v2, v3
     2f4:      	fcmge.4s	v6, v4, v2
     2f8:      	and.16b	v5, v5, v6
     2fc:      	mov	w8, #0xaa3b             ; =43579
     300:      	movk	w8, #0x3fb8, lsl #16
     304:      	dup.4s	v6, w8
     308:      	and.16b	v5, v5, v2
     30c:      	fmul.4s	v6, v5, v6
     310:      	movi.4s	v7, #0x4b, lsl #24
     314:      	mvni.4s	v16, #0x80, lsl #24
     318:      	bif.16b	v7, v6, v16
     31c:      	fadd.4s	v6, v6, v7
     320:      	fsub.4s	v6, v6, v7
     324:      	fcvtzs.4s	v6, v6
     328:      	scvtf.4s	v7, v6
     32c:      	mov	w8, #0x7200             ; =29184
     330:      	movk	w8, #0xbf31, lsl #16
     334:      	dup.4s	v16, w8
     338:      	fmul.4s	v16, v7, v16
     33c:      	fadd.4s	v5, v5, v16
     340:      	mov	w8, #0xbe8e             ; =48782
     344:      	movk	w8, #0xb5bf, lsl #16
     348:      	dup.4s	v16, w8
     34c:      	fmul.4s	v7, v7, v16
     350:      	fadd.4s	v5, v5, v7
     354:      	mov	w8, #0x2bda             ; =11226
     358:      	movk	w8, #0x3950, lsl #16
     35c:      	dup.4s	v7, w8
     360:      	fmul.4s	v7, v5, v7
     364:      	mov	w8, #0x96c9             ; =38601
     368:      	movk	w8, #0x3ab6, lsl #16
     36c:      	dup.4s	v16, w8
     370:      	fadd.4s	v7, v7, v16
     374:      	mov	w8, #0x88a6             ; =34982
     378:      	movk	w8, #0x3c08, lsl #16
     37c:      	dup.4s	v16, w8
     380:      	fmul.4s	v7, v5, v7
     384:      	fadd.4s	v7, v7, v16
     388:      	fmul.4s	v7, v5, v7
     38c:      	mov	w8, #0xaa7a             ; =43642
     390:      	movk	w8, #0x3d2a, lsl #16
     394:      	dup.4s	v16, w8
     398:      	fadd.4s	v7, v7, v16
     39c:      	fmul.4s	v7, v5, v7
     3a0:      	mov	w8, #0xaaab             ; =43691
     3a4:      	movk	w8, #0x3e2a, lsl #16
     3a8:      	dup.4s	v16, w8
     3ac:      	fadd.4s	v7, v7, v16
     3b0:      	fmul.4s	v7, v5, v7
     3b4:      	movi.4s	v16, #0x3f, lsl #24
     3b8:      	fadd.4s	v7, v7, v16
     3bc:      	fmul.4s	v16, v5, v5
     3c0:      	fmul.4s	v7, v16, v7
     3c4:      	fadd.4s	v5, v5, v7
     3c8:      	fadd.4s	v5, v5, v1
     3cc:      	sshr.4s	v7, v6, #0x1
     3d0:      	shl.4s	v16, v7, #0x17
     3d4:      	add.4s	v16, v16, v1
     3d8:      	fmul.4s	v5, v5, v16
     3dc:      	sub.4s	v6, v6, v7
     3e0:      	shl.4s	v6, v6, #0x17
     3e4:      	add.4s	v6, v6, v1
     3e8:      	fmul.4s	v5, v5, v6
     3ec:      	fcmgt.4s	v3, v3, v2
     3f0:      	fcmgt.4s	v4, v2, v4
     3f4:      	fcmeq.4s	v2, v2, v2
     3f8:      	fadd.4s	v5, v5, v1
     3fc:      	bif.16b	v1, v5, v3
     400:      	mvni.4s	v3, #0x7f, msl #16
     404:      	fneg.4s	v3, v3
     408:      	bit.16b	v1, v3, v4
     40c:      	mvni.4s	v3, #0x3f, msl #16
     410:      	fneg.4s	v3, v3
     414:      	bif.16b	v1, v3, v2
     418:      	fdiv.4s	v1, v17, v1
     41c:      	fmul.4s	v0, v1, v0
     420:      	str	s0, [x19, x20]
     424:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
     428:      	add	sp, sp, #0x50
     42c:      	ldp	x29, x30, [sp, #0x60]
     430:      	ldp	x20, x19, [sp, #0x50]
     434:      	ldp	x22, x21, [sp, #0x40]
     438:      	ldp	x24, x23, [sp, #0x30]
     43c:      	ldp	x28, x27, [sp, #0x20]
     440:      	ldp	d9, d8, [sp, #0x10]
     444:      	ldp	d11, d10, [sp], #0x70
     448:      	ret

000000000000044c <_llm_rows.packet_batch.blocks>:
     44c:      	stp	d15, d14, [sp, #-0xa0]!
     450:      	stp	d13, d12, [sp, #0x10]
     454:      	stp	d11, d10, [sp, #0x20]
     458:      	stp	d9, d8, [sp, #0x30]
     45c:      	stp	x28, x27, [sp, #0x40]
     460:      	stp	x26, x25, [sp, #0x50]
     464:      	stp	x24, x23, [sp, #0x60]
     468:      	stp	x22, x21, [sp, #0x70]
     46c:      	stp	x20, x19, [sp, #0x80]
     470:      	stp	x29, x30, [sp, #0x90]
     474:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
     478:      	sub	sp, sp, #0x210
     47c:      	str	x0, [sp, #0xc8]
     480:      	cbz	w3, 0x10d8 <_llm_rows.packet_batch.blocks+0xc8c>
     484:      	mov	x19, x3
     488:      	mov	x20, x2
     48c:      	mov	w22, #0x0               ; =0
     490:      	ldp	w9, w8, [x2, #0x2c]
     494:      	stp	w8, w9, [sp, #0xc0]
     498:      	add	x27, sp, #0x4, lsl #12  ; =0x4000
     49c:      	add	x27, x27, #0x1f0
     4a0:      	ldp	w26, w25, [x2]
     4a4:      	adrp	x8, 0x0 <ltmp0>
     4a8:      	ldr	q0, [x8]
     4ac:      	str	q0, [sp, #0x30]
     4b0:      	adrp	x8, 0x0 <ltmp0>
     4b4:      	ldr	q0, [x8]
     4b8:      	str	q0, [sp, #0x20]
     4bc:      	adrp	x8, 0x0 <ltmp0>
     4c0:      	ldr	q0, [x8]
     4c4:      	str	q0, [sp, #0x10]
     4c8:      	add	x28, sp, #0x1d0
     4cc:      	mvni.4s	v0, #0x7f, msl #16
     4d0:      	fneg.4s	v1, v0
     4d4:      	mvni.4s	v0, #0x3f, msl #16
     4d8:      	fneg.4s	v0, v0
     4dc:      	stp	q0, q1, [sp, #0xd0]
     4e0:      	ldp	w21, w23, [x2, #0x8]
     4e4:      	mov	w30, #0xaa7a            ; =43642
     4e8:      	movk	w30, #0x3d2a, lsl #16
     4ec:      	str	w3, [sp, #0xbc]
     4f0:      	b	0x538 <_llm_rows.packet_batch.blocks+0xec>
     4f4:      	mov	w8, #0x18               ; =24
     4f8:      	str	w8, [x20, #0x24]
     4fc:      	ldr	w19, [sp, #0xbc]
     500:      	add	w8, w26, #0x1
     504:      	ldp	w10, w9, [sp, #0xc0]
     508:      	cmp	w8, w9
     50c:      	cset	w8, eq
     510:      	csinc	w26, wzr, w26, eq
     514:      	cinc	w9, w25, eq
     518:      	cmp	w9, w10
     51c:      	cset	w10, eq
     520:      	ands	w8, w8, w10
     524:      	csel	w25, wzr, w9, ne
     528:      	add	w21, w21, w8
     52c:      	add	w22, w22, #0x1
     530:      	cmp	w22, w19
     534:      	b.eq	0x10d8 <_llm_rows.packet_batch.blocks+0xc8c>
     538:      	ubfiz	x8, x26, #5, #32
     53c:      	cmp	x8, x23
     540:      	csel	x9, x8, xzr, ls
     544:      	subs	x10, x23, x9
     548:      	cmp	x10, #0x20
     54c:      	mov	w11, #0x20              ; =32
     550:      	csel	x10, x10, x11, lo
     554:      	cmp	x23, x9
     558:      	stp	w26, w25, [x20]
     55c:      	str	w21, [x20, #0x8]
     560:      	str	wzr, [x20, #0x24]
     564:      	ccmp	x8, x23, #0x2, hi
     568:      	csel	x24, x10, xzr, ls
     56c:      	cmp	x24, #0x20
     570:      	b.lo	0x5cc <_llm_rows.packet_batch.blocks+0x180>
     574:      	ldr	x24, [sp, #0xc8]
     578:      	mov	x0, x24
     57c:      	mov	x1, x20
     580:      	bl	0x580 <_llm_rows.packet_batch.blocks+0x134>
     584:      	mov	w8, #0x8                ; =8
     588:      	str	w8, [x20, #0x24]
     58c:      	mov	x0, x24
     590:      	mov	x1, x20
     594:      	bl	0x594 <_llm_rows.packet_batch.blocks+0x148>
     598:      	mov	w8, #0x10               ; =16
     59c:      	str	w8, [x20, #0x24]
     5a0:      	mov	x0, x24
     5a4:      	mov	x1, x20
     5a8:      	bl	0x5a8 <_llm_rows.packet_batch.blocks+0x15c>
     5ac:      	mov	w8, #0x18               ; =24
     5b0:      	str	w8, [x20, #0x24]
     5b4:      	mov	x0, x24
     5b8:      	mov	x1, x20
     5bc:      	bl	0x5bc <_llm_rows.packet_batch.blocks+0x170>
     5c0:      	mov	w30, #0xaa7a            ; =43642
     5c4:      	movk	w30, #0x3d2a, lsl #16
     5c8:      	b	0x500 <_llm_rows.packet_batch.blocks+0xb4>
     5cc:      	lsr	x19, x24, #3
     5d0:      	cmp	x24, #0x8
     5d4:      	b.lo	0x638 <_llm_rows.packet_batch.blocks+0x1ec>
     5d8:      	str	wzr, [x20, #0x24]
     5dc:      	ldr	x0, [sp, #0xc8]
     5e0:      	mov	x1, x20
     5e4:      	bl	0x5e4 <_llm_rows.packet_batch.blocks+0x198>
     5e8:      	mov	w30, #0xaa7a            ; =43642
     5ec:      	movk	w30, #0x3d2a, lsl #16
     5f0:      	cmp	x19, #0x1
     5f4:      	b.eq	0x638 <_llm_rows.packet_batch.blocks+0x1ec>
     5f8:      	mov	w8, #0x8                ; =8
     5fc:      	str	w8, [x20, #0x24]
     600:      	ldr	x0, [sp, #0xc8]
     604:      	mov	x1, x20
     608:      	bl	0x608 <_llm_rows.packet_batch.blocks+0x1bc>
     60c:      	mov	w30, #0xaa7a            ; =43642
     610:      	movk	w30, #0x3d2a, lsl #16
     614:      	cmp	x19, #0x2
     618:      	b.eq	0x638 <_llm_rows.packet_batch.blocks+0x1ec>
     61c:      	mov	w8, #0x10               ; =16
     620:      	str	w8, [x20, #0x24]
     624:      	ldr	x0, [sp, #0xc8]
     628:      	mov	x1, x20
     62c:      	bl	0x62c <_llm_rows.packet_batch.blocks+0x1e0>
     630:      	mov	w30, #0xaa7a            ; =43642
     634:      	movk	w30, #0x3d2a, lsl #16
     638:      	and	w8, w24, #0x7
     63c:      	mov	w24, #0xaaab            ; =43691
     640:      	movk	w24, #0x3e2a, lsl #16
     644:      	cbz	w8, 0x4f4 <_llm_rows.packet_batch.blocks+0xa8>
     648:      	dup.4s	v1, w8
     64c:      	ldp	q0, q2, [sp, #0x20]
     650:      	cmhi.4s	v0, v1, v0
     654:      	cmhi.4s	v1, v1, v2
     658:      	uzp1.8h	v2, v1, v0
     65c:      	umaxv.8h	h3, v2
     660:      	fmov	w8, s3
     664:      	tbz	w8, #0x0, 0x4f4 <_llm_rows.packet_batch.blocks+0xa8>
     668:      	mov	x9, #0x0                ; =0
     66c:      	ldr	x11, [sp, #0xc8]
     670:      	ldr	x12, [x11]
     674:      	ldr	x10, [x11, #0x10]
     678:      	ubfiz	w8, w26, #2, #27
     67c:      	orr	w8, w8, w19
     680:      	dup.4s	v3, w8
     684:      	ldr	x8, [x11, #0x30]
     688:      	and.16b	v4, v1, v3
     68c:      	and.16b	v3, v0, v3
     690:      	ushll2.2d	v20, v3, #0x0
     694:      	ushll2.2d	v18, v4, #0x0
     698:      	ushll.2d	v19, v3, #0x0
     69c:      	ushll.2d	v4, v4, #0x0
     6a0:      	fmov	x11, d4
     6a4:      	mov	w13, #0x4004            ; =16388
     6a8:      	umaddl	x11, w11, w13, x12
     6ac:      	ldr	q3, [sp, #0x10]
     6b0:      	and.16b	v2, v2, v3
     6b4:      	addv.8h	h2, v2
     6b8:      	fmov	w13, s2
     6bc:      	b	0x6e0 <_llm_rows.packet_batch.blocks+0x294>
     6c0:      	add	x14, x27, x9
     6c4:      	ldp	q6, q7, [x14]
     6c8:      	bif.16b	v5, v7, v0
     6cc:      	bif.16b	v3, v6, v1
     6d0:      	stp	q3, q5, [x14]
     6d4:      	add	x9, x9, #0x20
     6d8:      	cmp	x9, #0x4, lsl #12       ; =0x4000
     6dc:      	b.eq	0x774 <_llm_rows.packet_batch.blocks+0x328>
     6e0:      	add	x14, x11, x9
     6e4:      	movi.2d	v3, #0000000000000000
     6e8:      	movi.2d	v5, #0000000000000000
     6ec:      	tbnz	w13, #0x0, 0x714 <_llm_rows.packet_batch.blocks+0x2c8>
     6f0:      	and	w15, w13, #0xff
     6f4:      	tbnz	w15, #0x1, 0x720 <_llm_rows.packet_batch.blocks+0x2d4>
     6f8:      	tbnz	w15, #0x2, 0x72c <_llm_rows.packet_batch.blocks+0x2e0>
     6fc:      	tbnz	w15, #0x3, 0x738 <_llm_rows.packet_batch.blocks+0x2ec>
     700:      	tbnz	w15, #0x4, 0x744 <_llm_rows.packet_batch.blocks+0x2f8>
     704:      	tbnz	w15, #0x5, 0x750 <_llm_rows.packet_batch.blocks+0x304>
     708:      	tbnz	w15, #0x6, 0x75c <_llm_rows.packet_batch.blocks+0x310>
     70c:      	tbz	w15, #0x7, 0x6c0 <_llm_rows.packet_batch.blocks+0x274>
     710:      	b	0x768 <_llm_rows.packet_batch.blocks+0x31c>
     714:      	ldr	s3, [x14]
     718:      	and	w15, w13, #0xff
     71c:      	tbz	w15, #0x1, 0x6f8 <_llm_rows.packet_batch.blocks+0x2ac>
     720:      	add	x16, x14, #0x4
     724:      	ld1.s	{ v3 }[1], [x16]
     728:      	tbz	w15, #0x2, 0x6fc <_llm_rows.packet_batch.blocks+0x2b0>
     72c:      	add	x16, x14, #0x8
     730:      	ld1.s	{ v3 }[2], [x16]
     734:      	tbz	w15, #0x3, 0x700 <_llm_rows.packet_batch.blocks+0x2b4>
     738:      	add	x16, x14, #0xc
     73c:      	ld1.s	{ v3 }[3], [x16]
     740:      	tbz	w15, #0x4, 0x704 <_llm_rows.packet_batch.blocks+0x2b8>
     744:      	add	x16, x14, #0x10
     748:      	ld1.s	{ v5 }[0], [x16]
     74c:      	tbz	w15, #0x5, 0x708 <_llm_rows.packet_batch.blocks+0x2bc>
     750:      	add	x16, x14, #0x14
     754:      	ld1.s	{ v5 }[1], [x16]
     758:      	tbz	w15, #0x6, 0x70c <_llm_rows.packet_batch.blocks+0x2c0>
     75c:      	add	x16, x14, #0x18
     760:      	ld1.s	{ v5 }[2], [x16]
     764:      	tbz	w15, #0x7, 0x6c0 <_llm_rows.packet_batch.blocks+0x274>
     768:      	add	x14, x14, #0x1c
     76c:      	ld1.s	{ v5 }[3], [x14]
     770:      	b	0x6c0 <_llm_rows.packet_batch.blocks+0x274>
     774:      	sshll.2d	v5, v1, #0x0
     778:      	xtn.4h	v3, v1
     77c:      	uzp1.8b	v6, v3, v0
     780:      	movi.2d	v3, #0000000000000000
     784:      	mov.b	v3[0], v6[0]
     788:      	adrp	x9, 0x0 <ltmp0>
     78c:      	ldr	d22, [x9]
     790:      	and.8b	v7, v3, v22
     794:      	addv.8b	b7, v7
     798:      	fmov	w13, s7
     79c:      	umaxv.8b	b7, v3
     7a0:      	fmov	w14, s7
     7a4:      	rbit	w9, w13
     7a8:      	clz	w9, w9
     7ac:      	tst	w14, #0x1
     7b0:      	csel	w9, w9, wzr, ne
     7b4:      	adrp	x11, 0x0 <ltmp0>
     7b8:      	ldr	q7, [x11]
     7bc:      	mov	w11, #0x1000            ; =4096
     7c0:      	dup.2d	v17, x11
     7c4:      	bsl.16b	v5, v7, v17
     7c8:      	mov	w11, #0x1001            ; =4097
     7cc:      	dup.2s	v21, w11
     7d0:      	xtn.2s	v23, v4
     7d4:      	movi.2d	v4, #0000000000000000
     7d8:      	mov.b	v4[0], v6[0]
     7dc:      	umlal.2d	v5, v23, v21
     7e0:      	ushll.2d	v4, v4, #0x0
     7e4:      	shl.2d	v4, v4, #0x3f
     7e8:      	cmlt.2d	v4, v4, #0
     7ec:      	str	q5, [sp, #0x90]
     7f0:      	and.16b	v4, v4, v5
     7f4:      	movi.2d	v5, #0000000000000000
     7f8:      	stp	q5, q5, [sp, #0x1a0]
     7fc:      	stp	q4, q5, [sp, #0x180]
     800:      	and	x11, x9, #0x7
     804:      	add	x15, sp, #0x180
     808:      	ldr	x11, [x15, x11, lsl #3]
     80c:      	sub	x11, x11, x9
     810:      	lsl	x11, x11, #2
     814:      	add	x12, x12, x11
     818:      	movi.2d	v4, #0000000000000000
     81c:      	tbz	w14, #0x0, 0x824 <_llm_rows.packet_batch.blocks+0x3d8>
     820:      	ldr	s5, [x12]
     824:      	mov	w1, #-0x3d300000        ; =-1026555904
     828:      	mov	w2, #0x42c80000         ; =1120403456
     82c:      	mov	w3, #0xaa3b             ; =43579
     830:      	movk	w3, #0x3fb8, lsl #16
     834:      	mov	w4, #0x7200             ; =29184
     838:      	movk	w4, #0xbf31, lsl #16
     83c:      	mov	w5, #0xbe8e             ; =48782
     840:      	movk	w5, #0xb5bf, lsl #16
     844:      	mov	w6, #0x2bda             ; =11226
     848:      	movk	w6, #0x3950, lsl #16
     84c:      	mov	w7, #0x96c9             ; =38601
     850:      	movk	w7, #0x3ab6, lsl #16
     854:      	mov	w19, #0x88a6            ; =34982
     858:      	movk	w19, #0x3c08, lsl #16
     85c:      	tbnz	w13, #0x1, 0xfe4 <_llm_rows.packet_batch.blocks+0xb98>
     860:      	tbnz	w13, #0x2, 0xff0 <_llm_rows.packet_batch.blocks+0xba4>
     864:      	tbnz	w13, #0x3, 0xffc <_llm_rows.packet_batch.blocks+0xbb0>
     868:      	tbnz	w13, #0x4, 0x1008 <_llm_rows.packet_batch.blocks+0xbbc>
     86c:      	tbnz	w13, #0x5, 0x1014 <_llm_rows.packet_batch.blocks+0xbc8>
     870:      	tbnz	w13, #0x6, 0x1020 <_llm_rows.packet_batch.blocks+0xbd4>
     874:      	tbz	w13, #0x7, 0x880 <_llm_rows.packet_batch.blocks+0x434>
     878:      	add	x12, x12, #0x1c
     87c:      	ld1.s	{ v4 }[3], [x12]
     880:      	mov	x15, #0x0               ; =0
     884:      	sshll2.2d	v7, v0, #0x0
     888:      	sshll2.2d	v16, v1, #0x0
     88c:      	sshll.2d	v24, v0, #0x0
     890:      	adrp	x12, 0x0 <ltmp0>
     894:      	ldr	q25, [x12]
     898:      	mov.16b	v6, v24
     89c:      	bsl.16b	v6, v25, v17
     8a0:      	adrp	x12, 0x0 <ltmp0>
     8a4:      	ldr	q24, [x12]
     8a8:      	mov.16b	v27, v16
     8ac:      	bsl.16b	v27, v24, v17
     8b0:      	adrp	x12, 0x0 <ltmp0>
     8b4:      	ldr	q24, [x12]
     8b8:      	mov.16b	v28, v7
     8bc:      	bsl.16b	v28, v24, v17
     8c0:      	adrp	x12, 0x0 <ltmp0>
     8c4:      	ldr	q17, [x12]
     8c8:      	mov	w12, #0x4000            ; =16384
     8cc:      	dup.2d	v24, x12
     8d0:      	sshll.2d	v25, v1, #0x0
     8d4:      	bif.16b	v17, v24, v25
     8d8:      	adrp	x12, 0x0 <ltmp0>
     8dc:      	ldr	q25, [x12]
     8e0:      	sshll.2d	v26, v0, #0x0
     8e4:      	bif.16b	v25, v24, v26
     8e8:      	adrp	x12, 0x0 <ltmp0>
     8ec:      	ldr	q26, [x12]
     8f0:      	bsl.16b	v16, v26, v24
     8f4:      	adrp	x12, 0x0 <ltmp0>
     8f8:      	ldr	q26, [x12]
     8fc:      	bsl.16b	v7, v26, v24
     900:      	xtn.2s	v20, v20
     904:      	umlal.2d	v28, v20, v21
     908:      	umull.2d	v20, v23, v21
     90c:      	xtn.2s	v18, v18
     910:      	xtn.2s	v19, v19
     914:      	umlal.2d	v27, v18, v21
     918:      	stp	q28, q27, [sp, #0x50]
     91c:      	stp	q25, q7, [sp, #0x160]
     920:      	stp	q17, q16, [sp, #0x140]
     924:      	and	x12, x9, #0x7
     928:      	add	x14, sp, #0x140
     92c:      	ldr	x12, [x14, x12, lsl #3]
     930:      	umlal.2d	v6, v19, v21
     934:      	stp	q6, q5, [sp, #0x70]
     938:      	sub	x12, x12, x9, lsl #2
     93c:      	tst	w13, #0xff
     940:      	csel	x12, xzr, x12, eq
     944:      	add	x13, x27, x12
     948:      	ldp	q7, q16, [x13]
     94c:      	zip2.8b	v17, v3, v0
     950:      	ushll.4s	v17, v17, #0x0
     954:      	shl.4s	v17, v17, #0x1f
     958:      	cmlt.4s	v17, v17, #0
     95c:      	bit.16b	v16, v4, v17
     960:      	zip1.8b	v17, v3, v0
     964:      	ushll.4s	v17, v17, #0x0
     968:      	shl.4s	v17, v17, #0x1f
     96c:      	cmlt.4s	v17, v17, #0
     970:      	bit.16b	v7, v5, v17
     974:      	stp	q7, q16, [x13]
     978:      	fmov	x13, d20
     97c:      	lsl	x13, x13, #2
     980:      	add	x14, x10, x13
     984:      	mov	w16, #0x1               ; =1
     988:      	dup.2d	v7, x16
     98c:      	ushll2.2d	v16, v0, #0x0
     990:      	and.16b	v18, v16, v7
     994:      	ushll2.2d	v16, v1, #0x0
     998:      	and.16b	v19, v16, v7
     99c:      	ushll.2d	v16, v0, #0x0
     9a0:      	and.16b	v20, v16, v7
     9a4:      	ushll.2d	v16, v1, #0x0
     9a8:      	and.16b	v21, v16, v7
     9ac:      	movi.2d	v23, #0000000000000000
     9b0:      	movi.2d	v24, #0000000000000000
     9b4:      	movi.2d	v25, #0000000000000000
     9b8:      	movi.2d	v26, #0000000000000000
     9bc:      	b	0x9f0 <_llm_rows.packet_batch.blocks+0x5a4>
     9c0:      	add	x15, x28, x15
     9c4:      	ldp	q7, q16, [x15]
     9c8:      	bit.16b	v16, v28, v0
     9cc:      	bit.16b	v7, v27, v1
     9d0:      	stp	q7, q16, [x15]
     9d4:      	add.2d	v24, v24, v19
     9d8:      	add.2d	v25, v25, v20
     9dc:      	add.2d	v26, v26, v18
     9e0:      	add.2d	v23, v23, v21
     9e4:      	fmov	x15, d23
     9e8:      	cmp	x15, #0x200
     9ec:      	b.ge	0xa8c <_llm_rows.packet_batch.blocks+0x640>
     9f0:      	fmov	w17, s2
     9f4:      	lsl	x15, x15, #5
     9f8:      	add	x16, x14, x15
     9fc:      	movi.2d	v27, #0000000000000000
     a00:      	movi.2d	v28, #0000000000000000
     a04:      	tbnz	w17, #0x0, 0xa2c <_llm_rows.packet_batch.blocks+0x5e0>
     a08:      	and	w17, w17, #0xff
     a0c:      	tbnz	w17, #0x1, 0xa38 <_llm_rows.packet_batch.blocks+0x5ec>
     a10:      	tbnz	w17, #0x2, 0xa44 <_llm_rows.packet_batch.blocks+0x5f8>
     a14:      	tbnz	w17, #0x3, 0xa50 <_llm_rows.packet_batch.blocks+0x604>
     a18:      	tbnz	w17, #0x4, 0xa5c <_llm_rows.packet_batch.blocks+0x610>
     a1c:      	tbnz	w17, #0x5, 0xa68 <_llm_rows.packet_batch.blocks+0x61c>
     a20:      	tbnz	w17, #0x6, 0xa74 <_llm_rows.packet_batch.blocks+0x628>
     a24:      	tbz	w17, #0x7, 0x9c0 <_llm_rows.packet_batch.blocks+0x574>
     a28:      	b	0xa80 <_llm_rows.packet_batch.blocks+0x634>
     a2c:      	ldr	s27, [x16]
     a30:      	and	w17, w17, #0xff
     a34:      	tbz	w17, #0x1, 0xa10 <_llm_rows.packet_batch.blocks+0x5c4>
     a38:      	add	x0, x16, #0x4
     a3c:      	ld1.s	{ v27 }[1], [x0]
     a40:      	tbz	w17, #0x2, 0xa14 <_llm_rows.packet_batch.blocks+0x5c8>
     a44:      	add	x0, x16, #0x8
     a48:      	ld1.s	{ v27 }[2], [x0]
     a4c:      	tbz	w17, #0x3, 0xa18 <_llm_rows.packet_batch.blocks+0x5cc>
     a50:      	add	x0, x16, #0xc
     a54:      	ld1.s	{ v27 }[3], [x0]
     a58:      	tbz	w17, #0x4, 0xa1c <_llm_rows.packet_batch.blocks+0x5d0>
     a5c:      	add	x0, x16, #0x10
     a60:      	ld1.s	{ v28 }[0], [x0]
     a64:      	tbz	w17, #0x5, 0xa20 <_llm_rows.packet_batch.blocks+0x5d4>
     a68:      	add	x0, x16, #0x14
     a6c:      	ld1.s	{ v28 }[1], [x0]
     a70:      	tbz	w17, #0x6, 0xa24 <_llm_rows.packet_batch.blocks+0x5d8>
     a74:      	add	x0, x16, #0x18
     a78:      	ld1.s	{ v28 }[2], [x0]
     a7c:      	tbz	w17, #0x7, 0x9c0 <_llm_rows.packet_batch.blocks+0x574>
     a80:      	add	x16, x16, #0x1c
     a84:      	ld1.s	{ v28 }[3], [x16]
     a88:      	b	0x9c0 <_llm_rows.packet_batch.blocks+0x574>
     a8c:      	add	x10, x10, x11
     a90:      	shl.8b	v7, v3, #0x7
     a94:      	cmlt.8b	v7, v7, #0
     a98:      	and.8b	v7, v7, v22
     a9c:      	addv.8b	b5, v7
     aa0:      	str	d5, [sp, #0x48]
     aa4:      	fmov	w11, s5
     aa8:      	movi.2d	v23, #0000000000000000
     aac:      	movi.2d	v22, #0000000000000000
     ab0:      	tbnz	w11, #0x0, 0x1030 <_llm_rows.packet_batch.blocks+0xbe4>
     ab4:      	tbnz	w11, #0x1, 0x1038 <_llm_rows.packet_batch.blocks+0xbec>
     ab8:      	tbnz	w11, #0x2, 0x1044 <_llm_rows.packet_batch.blocks+0xbf8>
     abc:      	tbnz	w11, #0x3, 0x1050 <_llm_rows.packet_batch.blocks+0xc04>
     ac0:      	tbnz	w11, #0x4, 0x105c <_llm_rows.packet_batch.blocks+0xc10>
     ac4:      	tbnz	w11, #0x5, 0x1068 <_llm_rows.packet_batch.blocks+0xc1c>
     ac8:      	tbnz	w11, #0x6, 0x1074 <_llm_rows.packet_batch.blocks+0xc28>
     acc:      	tbz	w11, #0x7, 0xad8 <_llm_rows.packet_batch.blocks+0x68c>
     ad0:      	add	x10, x10, #0x1c
     ad4:      	ld1.s	{ v22 }[3], [x10]
     ad8:      	str	q4, [sp, #0xa0]
     adc:      	mov	x11, #0x0               ; =0
     ae0:      	add	x10, x28, x12
     ae4:      	ldp	q7, q16, [x10]
     ae8:      	zip2.8b	v17, v3, v0
     aec:      	ushll.4s	v17, v17, #0x0
     af0:      	shl.4s	v17, v17, #0x1f
     af4:      	cmlt.4s	v17, v17, #0
     af8:      	bit.16b	v16, v22, v17
     afc:      	zip1.8b	v17, v3, v0
     b00:      	ushll.4s	v17, v17, #0x0
     b04:      	shl.4s	v17, v17, #0x1f
     b08:      	cmlt.4s	v17, v17, #0
     b0c:      	bit.16b	v7, v23, v17
     b10:      	stp	q7, q16, [x10]
     b14:      	add	x10, x8, x13
     b18:      	movi.2d	v12, #0000000000000000
     b1c:      	movi.2d	v13, #0000000000000000
     b20:      	movi.2d	v14, #0000000000000000
     b24:      	movi.2d	v15, #0000000000000000
     b28:      	b	0xb48 <_llm_rows.packet_batch.blocks+0x6fc>
     b2c:      	add.2d	v13, v13, v19
     b30:      	add.2d	v14, v14, v20
     b34:      	add.2d	v15, v15, v18
     b38:      	add.2d	v12, v12, v21
     b3c:      	fmov	x11, d12
     b40:      	cmp	x11, #0x200
     b44:      	b.ge	0xdc8 <_llm_rows.packet_batch.blocks+0x97c>
     b48:      	fmov	w12, s2
     b4c:      	lsl	x11, x11, #5
     b50:      	add	x13, x27, x11
     b54:      	ldp	q16, q7, [x13]
     b58:      	and.16b	v16, v1, v16
     b5c:      	fneg.4s	v17, v16
     b60:      	and.16b	v17, v1, v17
     b64:      	dup.4s	v25, w1
     b68:      	fcmge.4s	v27, v17, v25
     b6c:      	dup.4s	v26, w2
     b70:      	fcmge.4s	v28, v26, v17
     b74:      	and.16b	v27, v27, v28
     b78:      	and.16b	v27, v27, v17
     b7c:      	dup.4s	v28, w3
     b80:      	fmul.4s	v29, v27, v28
     b84:      	movi.4s	v4, #0x4b, lsl #24
     b88:      	mvni.4s	v5, #0x80, lsl #24
     b8c:      	mov.16b	v30, v5
     b90:      	bsl.16b	v30, v4, v29
     b94:      	fadd.4s	v29, v29, v30
     b98:      	fsub.4s	v29, v29, v30
     b9c:      	fcvtzs.4s	v5, v29
     ba0:      	dup.4s	v29, w4
     ba4:      	scvtf.4s	v31, v5
     ba8:      	fmul.4s	v30, v31, v29
     bac:      	fadd.4s	v27, v27, v30
     bb0:      	dup.4s	v30, w5
     bb4:      	fmul.4s	v31, v31, v30
     bb8:      	fadd.4s	v27, v27, v31
     bbc:      	dup.4s	v31, w6
     bc0:      	fmul.4s	v9, v27, v31
     bc4:      	dup.4s	v8, w7
     bc8:      	fadd.4s	v9, v9, v8
     bcc:      	fmul.4s	v10, v27, v9
     bd0:      	dup.4s	v9, w19
     bd4:      	fadd.4s	v10, v10, v9
     bd8:      	fmul.4s	v11, v27, v10
     bdc:      	dup.4s	v10, w30
     be0:      	fadd.4s	v11, v11, v10
     be4:      	fmul.4s	v24, v27, v11
     be8:      	dup.4s	v11, w24
     bec:      	fadd.4s	v24, v24, v11
     bf0:      	fmul.4s	v24, v27, v24
     bf4:      	movi.4s	v4, #0x3f, lsl #24
     bf8:      	fadd.4s	v24, v24, v4
     bfc:      	fmul.4s	v6, v27, v27
     c00:      	fmul.4s	v6, v6, v24
     c04:      	fadd.4s	v6, v27, v6
     c08:      	fmov.4s	v27, #1.00000000
     c0c:      	fadd.4s	v6, v6, v27
     c10:      	sshr.4s	v24, v5, #0x1
     c14:      	shl.4s	v4, v24, #0x17
     c18:      	add.4s	v4, v4, v27
     c1c:      	fmul.4s	v4, v6, v4
     c20:      	sub.4s	v5, v5, v24
     c24:      	shl.4s	v5, v5, #0x17
     c28:      	add.4s	v5, v5, v27
     c2c:      	fmul.4s	v4, v4, v5
     c30:      	fcmgt.4s	v5, v25, v17
     c34:      	fcmgt.4s	v6, v17, v26
     c38:      	fcmeq.4s	v17, v17, v17
     c3c:      	fadd.4s	v4, v4, v27
     c40:      	bit.16b	v4, v27, v5
     c44:      	ldr	q5, [sp, #0xe0]
     c48:      	bit.16b	v4, v5, v6
     c4c:      	ldr	q5, [sp, #0xd0]
     c50:      	bif.16b	v4, v5, v17
     c54:      	fdiv.4s	v4, v16, v4
     c58:      	add	x13, x28, x11
     c5c:      	ldp	q5, q16, [x13]
     c60:      	and.16b	v5, v1, v5
     c64:      	fmul.4s	v17, v5, v4
     c68:      	add	x11, x10, x11
     c6c:      	tbnz	w12, #0x0, 0xd74 <_llm_rows.packet_batch.blocks+0x928>
     c70:      	and	w12, w12, #0xff
     c74:      	tbnz	w12, #0x1, 0xd80 <_llm_rows.packet_batch.blocks+0x934>
     c78:      	tbnz	w12, #0x2, 0xd8c <_llm_rows.packet_batch.blocks+0x940>
     c7c:      	tbz	w12, #0x3, 0xc88 <_llm_rows.packet_batch.blocks+0x83c>
     c80:      	add	x13, x11, #0xc
     c84:      	st1.s	{ v17 }[3], [x13]
     c88:      	and.16b	v4, v0, v7
     c8c:      	fneg.4s	v5, v4
     c90:      	and.16b	v5, v0, v5
     c94:      	fcmge.4s	v6, v5, v25
     c98:      	fcmge.4s	v7, v26, v5
     c9c:      	and.16b	v6, v6, v7
     ca0:      	and.16b	v6, v6, v5
     ca4:      	fmul.4s	v7, v6, v28
     ca8:      	movi.4s	v17, #0x4b, lsl #24
     cac:      	mvni.4s	v24, #0x80, lsl #24
     cb0:      	bif.16b	v17, v7, v24
     cb4:      	fadd.4s	v7, v7, v17
     cb8:      	fsub.4s	v7, v7, v17
     cbc:      	fcvtzs.4s	v7, v7
     cc0:      	scvtf.4s	v17, v7
     cc4:      	fmul.4s	v24, v17, v29
     cc8:      	fadd.4s	v6, v6, v24
     ccc:      	fmul.4s	v17, v17, v30
     cd0:      	fadd.4s	v6, v6, v17
     cd4:      	fmul.4s	v17, v6, v31
     cd8:      	fadd.4s	v17, v17, v8
     cdc:      	fmul.4s	v17, v6, v17
     ce0:      	fadd.4s	v17, v17, v9
     ce4:      	fmul.4s	v17, v6, v17
     ce8:      	fadd.4s	v17, v17, v10
     cec:      	fmul.4s	v17, v6, v17
     cf0:      	fadd.4s	v17, v17, v11
     cf4:      	fmul.4s	v17, v6, v17
     cf8:      	movi.4s	v24, #0x3f, lsl #24
     cfc:      	fadd.4s	v17, v17, v24
     d00:      	fmul.4s	v24, v6, v6
     d04:      	fmul.4s	v17, v24, v17
     d08:      	fadd.4s	v6, v6, v17
     d0c:      	fadd.4s	v6, v6, v27
     d10:      	sshr.4s	v17, v7, #0x1
     d14:      	shl.4s	v24, v17, #0x17
     d18:      	add.4s	v24, v24, v27
     d1c:      	fmul.4s	v6, v6, v24
     d20:      	sub.4s	v7, v7, v17
     d24:      	shl.4s	v7, v7, #0x17
     d28:      	add.4s	v7, v7, v27
     d2c:      	fmul.4s	v6, v6, v7
     d30:      	fcmgt.4s	v7, v25, v5
     d34:      	fcmgt.4s	v17, v5, v26
     d38:      	fcmeq.4s	v5, v5, v5
     d3c:      	fadd.4s	v6, v6, v27
     d40:      	bit.16b	v6, v27, v7
     d44:      	ldr	q7, [sp, #0xe0]
     d48:      	bit.16b	v6, v7, v17
     d4c:      	ldr	q7, [sp, #0xd0]
     d50:      	bsl.16b	v5, v6, v7
     d54:      	fdiv.4s	v4, v4, v5
     d58:      	and.16b	v5, v0, v16
     d5c:      	fmul.4s	v7, v5, v4
     d60:      	tbnz	w12, #0x4, 0xd9c <_llm_rows.packet_batch.blocks+0x950>
     d64:      	tbnz	w12, #0x5, 0xda4 <_llm_rows.packet_batch.blocks+0x958>
     d68:      	tbnz	w12, #0x6, 0xdb0 <_llm_rows.packet_batch.blocks+0x964>
     d6c:      	tbz	w12, #0x7, 0xb2c <_llm_rows.packet_batch.blocks+0x6e0>
     d70:      	b	0xdbc <_llm_rows.packet_batch.blocks+0x970>
     d74:      	str	s17, [x11]
     d78:      	and	w12, w12, #0xff
     d7c:      	tbz	w12, #0x1, 0xc78 <_llm_rows.packet_batch.blocks+0x82c>
     d80:      	add	x13, x11, #0x4
     d84:      	st1.s	{ v17 }[1], [x13]
     d88:      	tbz	w12, #0x2, 0xc7c <_llm_rows.packet_batch.blocks+0x830>
     d8c:      	add	x13, x11, #0x8
     d90:      	st1.s	{ v17 }[2], [x13]
     d94:      	tbnz	w12, #0x3, 0xc80 <_llm_rows.packet_batch.blocks+0x834>
     d98:      	b	0xc88 <_llm_rows.packet_batch.blocks+0x83c>
     d9c:      	str	s7, [x11, #0x10]
     da0:      	tbz	w12, #0x5, 0xd68 <_llm_rows.packet_batch.blocks+0x91c>
     da4:      	add	x13, x11, #0x14
     da8:      	st1.s	{ v7 }[1], [x13]
     dac:      	tbz	w12, #0x6, 0xd6c <_llm_rows.packet_batch.blocks+0x920>
     db0:      	add	x13, x11, #0x18
     db4:      	st1.s	{ v7 }[2], [x13]
     db8:      	tbz	w12, #0x7, 0xb2c <_llm_rows.packet_batch.blocks+0x6e0>
     dbc:      	add	x11, x11, #0x1c
     dc0:      	st1.s	{ v7 }[3], [x11]
     dc4:      	b	0xb2c <_llm_rows.packet_batch.blocks+0x6e0>
     dc8:      	ldr	q6, [sp, #0x80]
     dcc:      	fneg.4s	v0, v6
     dd0:      	ldr	d1, [sp, #0x48]
     dd4:      	fmov	w10, s1
     dd8:      	zip1.8b	v1, v3, v0
     ddc:      	ushll.4s	v1, v1, #0x0
     de0:      	shl.4s	v1, v1, #0x1f
     de4:      	cmlt.4s	v1, v1, #0
     de8:      	and.16b	v0, v1, v0
     dec:      	fcmge.4s	v1, v0, v25
     df0:      	fcmge.4s	v2, v26, v0
     df4:      	and.16b	v1, v1, v2
     df8:      	and.16b	v1, v1, v0
     dfc:      	fmul.4s	v2, v1, v28
     e00:      	movi.4s	v4, #0x4b, lsl #24
     e04:      	mvni.4s	v5, #0x80, lsl #24
     e08:      	bif.16b	v4, v2, v5
     e0c:      	fadd.4s	v2, v2, v4
     e10:      	fsub.4s	v2, v2, v4
     e14:      	fcvtzs.4s	v2, v2
     e18:      	scvtf.4s	v4, v2
     e1c:      	fmul.4s	v5, v4, v29
     e20:      	fadd.4s	v1, v1, v5
     e24:      	fmul.4s	v4, v4, v30
     e28:      	fadd.4s	v1, v1, v4
     e2c:      	fmul.4s	v4, v1, v31
     e30:      	fadd.4s	v4, v4, v8
     e34:      	fmul.4s	v4, v1, v4
     e38:      	fadd.4s	v4, v4, v9
     e3c:      	fmul.4s	v4, v1, v4
     e40:      	fadd.4s	v4, v4, v10
     e44:      	fmul.4s	v4, v1, v4
     e48:      	fadd.4s	v4, v4, v11
     e4c:      	fmul.4s	v4, v1, v4
     e50:      	movi.4s	v5, #0x3f, lsl #24
     e54:      	fadd.4s	v4, v4, v5
     e58:      	fmul.4s	v5, v1, v1
     e5c:      	fmul.4s	v4, v5, v4
     e60:      	fadd.4s	v1, v1, v4
     e64:      	fadd.4s	v1, v1, v27
     e68:      	sshr.4s	v4, v2, #0x1
     e6c:      	shl.4s	v5, v4, #0x17
     e70:      	add.4s	v5, v5, v27
     e74:      	fmul.4s	v1, v1, v5
     e78:      	sub.4s	v2, v2, v4
     e7c:      	shl.4s	v2, v2, #0x17
     e80:      	add.4s	v2, v2, v27
     e84:      	fmul.4s	v1, v1, v2
     e88:      	fcmgt.4s	v2, v25, v0
     e8c:      	fcmgt.4s	v4, v0, v26
     e90:      	fcmeq.4s	v0, v0, v0
     e94:      	fadd.4s	v1, v1, v27
     e98:      	bit.16b	v1, v27, v2
     e9c:      	ldp	q2, q5, [sp, #0xd0]
     ea0:      	bit.16b	v1, v5, v4
     ea4:      	bsl.16b	v0, v1, v2
     ea8:      	fdiv.4s	v0, v6, v0
     eac:      	fmul.4s	v0, v0, v23
     eb0:      	ldr	q2, [sp, #0x90]
     eb4:      	ldp	q4, q5, [sp, #0x60]
     eb8:      	stp	q2, q4, [sp, #0xf0]
     ebc:      	ldr	q1, [sp, #0x50]
     ec0:      	stp	q5, q1, [sp, #0x110]
     ec4:      	and	x11, x9, #0x7
     ec8:      	add	x12, sp, #0xf0
     ecc:      	ldr	x11, [x12, x11, lsl #3]
     ed0:      	sub	x9, x11, x9
     ed4:      	add	x8, x8, x9, lsl #2
     ed8:      	tbnz	w10, #0x0, 0x1084 <_llm_rows.packet_batch.blocks+0xc38>
     edc:      	ldr	q5, [sp, #0xa0]
     ee0:      	tbnz	w10, #0x1, 0x1090 <_llm_rows.packet_batch.blocks+0xc44>
     ee4:      	tbnz	w10, #0x2, 0x109c <_llm_rows.packet_batch.blocks+0xc50>
     ee8:      	tbz	w10, #0x3, 0xef4 <_llm_rows.packet_batch.blocks+0xaa8>
     eec:      	add	x9, x8, #0xc
     ef0:      	st1.s	{ v0 }[3], [x9]
     ef4:      	fneg.4s	v0, v5
     ef8:      	zip2.8b	v1, v3, v0
     efc:      	ushll.4s	v1, v1, #0x0
     f00:      	shl.4s	v1, v1, #0x1f
     f04:      	cmlt.4s	v1, v1, #0
     f08:      	and.16b	v0, v1, v0
     f0c:      	fcmge.4s	v1, v0, v25
     f10:      	fcmge.4s	v2, v26, v0
     f14:      	and.16b	v1, v1, v2
     f18:      	and.16b	v1, v1, v0
     f1c:      	fmul.4s	v2, v1, v28
     f20:      	movi.4s	v3, #0x4b, lsl #24
     f24:      	mvni.4s	v4, #0x80, lsl #24
     f28:      	bif.16b	v3, v2, v4
     f2c:      	fadd.4s	v2, v2, v3
     f30:      	fsub.4s	v2, v2, v3
     f34:      	fcvtzs.4s	v2, v2
     f38:      	scvtf.4s	v3, v2
     f3c:      	fmul.4s	v4, v3, v29
     f40:      	fadd.4s	v1, v1, v4
     f44:      	fmul.4s	v3, v3, v30
     f48:      	fadd.4s	v1, v1, v3
     f4c:      	fmul.4s	v3, v1, v31
     f50:      	fadd.4s	v3, v3, v8
     f54:      	fmul.4s	v3, v1, v3
     f58:      	fadd.4s	v3, v3, v9
     f5c:      	fmul.4s	v3, v1, v3
     f60:      	fadd.4s	v3, v3, v10
     f64:      	fmul.4s	v3, v1, v3
     f68:      	fadd.4s	v3, v3, v11
     f6c:      	fmul.4s	v3, v1, v3
     f70:      	movi.4s	v4, #0x3f, lsl #24
     f74:      	fadd.4s	v3, v3, v4
     f78:      	fmul.4s	v4, v1, v1
     f7c:      	fmul.4s	v3, v4, v3
     f80:      	fadd.4s	v1, v1, v3
     f84:      	fadd.4s	v1, v1, v27
     f88:      	sshr.4s	v3, v2, #0x1
     f8c:      	shl.4s	v4, v3, #0x17
     f90:      	add.4s	v4, v4, v27
     f94:      	fmul.4s	v1, v1, v4
     f98:      	sub.4s	v2, v2, v3
     f9c:      	shl.4s	v2, v2, #0x17
     fa0:      	add.4s	v2, v2, v27
     fa4:      	fmul.4s	v1, v1, v2
     fa8:      	fcmgt.4s	v2, v25, v0
     fac:      	fcmgt.4s	v3, v0, v26
     fb0:      	fcmeq.4s	v0, v0, v0
     fb4:      	fadd.4s	v1, v1, v27
     fb8:      	bit.16b	v1, v27, v2
     fbc:      	ldp	q2, q4, [sp, #0xd0]
     fc0:      	bit.16b	v1, v4, v3
     fc4:      	bsl.16b	v0, v1, v2
     fc8:      	fdiv.4s	v0, v5, v0
     fcc:      	fmul.4s	v0, v0, v22
     fd0:      	tbnz	w10, #0x4, 0x10ac <_llm_rows.packet_batch.blocks+0xc60>
     fd4:      	tbnz	w10, #0x5, 0x10b4 <_llm_rows.packet_batch.blocks+0xc68>
     fd8:      	tbnz	w10, #0x6, 0x10c0 <_llm_rows.packet_batch.blocks+0xc74>
     fdc:      	tbz	w10, #0x7, 0x4f4 <_llm_rows.packet_batch.blocks+0xa8>
     fe0:      	b	0x10cc <_llm_rows.packet_batch.blocks+0xc80>
     fe4:      	add	x14, x12, #0x4
     fe8:      	ld1.s	{ v5 }[1], [x14]
     fec:      	tbz	w13, #0x2, 0x864 <_llm_rows.packet_batch.blocks+0x418>
     ff0:      	add	x14, x12, #0x8
     ff4:      	ld1.s	{ v5 }[2], [x14]
     ff8:      	tbz	w13, #0x3, 0x868 <_llm_rows.packet_batch.blocks+0x41c>
     ffc:      	add	x14, x12, #0xc
    1000:      	ld1.s	{ v5 }[3], [x14]
    1004:      	tbz	w13, #0x4, 0x86c <_llm_rows.packet_batch.blocks+0x420>
    1008:      	add	x14, x12, #0x10
    100c:      	ld1.s	{ v4 }[0], [x14]
    1010:      	tbz	w13, #0x5, 0x870 <_llm_rows.packet_batch.blocks+0x424>
    1014:      	add	x14, x12, #0x14
    1018:      	ld1.s	{ v4 }[1], [x14]
    101c:      	tbz	w13, #0x6, 0x874 <_llm_rows.packet_batch.blocks+0x428>
    1020:      	add	x14, x12, #0x18
    1024:      	ld1.s	{ v4 }[2], [x14]
    1028:      	tbnz	w13, #0x7, 0x878 <_llm_rows.packet_batch.blocks+0x42c>
    102c:      	b	0x880 <_llm_rows.packet_batch.blocks+0x434>
    1030:      	ldr	s23, [x10]
    1034:      	tbz	w11, #0x1, 0xab8 <_llm_rows.packet_batch.blocks+0x66c>
    1038:      	add	x14, x10, #0x4
    103c:      	ld1.s	{ v23 }[1], [x14]
    1040:      	tbz	w11, #0x2, 0xabc <_llm_rows.packet_batch.blocks+0x670>
    1044:      	add	x14, x10, #0x8
    1048:      	ld1.s	{ v23 }[2], [x14]
    104c:      	tbz	w11, #0x3, 0xac0 <_llm_rows.packet_batch.blocks+0x674>
    1050:      	add	x14, x10, #0xc
    1054:      	ld1.s	{ v23 }[3], [x14]
    1058:      	tbz	w11, #0x4, 0xac4 <_llm_rows.packet_batch.blocks+0x678>
    105c:      	add	x14, x10, #0x10
    1060:      	ld1.s	{ v22 }[0], [x14]
    1064:      	tbz	w11, #0x5, 0xac8 <_llm_rows.packet_batch.blocks+0x67c>
    1068:      	add	x14, x10, #0x14
    106c:      	ld1.s	{ v22 }[1], [x14]
    1070:      	tbz	w11, #0x6, 0xacc <_llm_rows.packet_batch.blocks+0x680>
    1074:      	add	x14, x10, #0x18
    1078:      	ld1.s	{ v22 }[2], [x14]
    107c:      	tbnz	w11, #0x7, 0xad0 <_llm_rows.packet_batch.blocks+0x684>
    1080:      	b	0xad8 <_llm_rows.packet_batch.blocks+0x68c>
    1084:      	str	s0, [x8]
    1088:      	ldr	q5, [sp, #0xa0]
    108c:      	tbz	w10, #0x1, 0xee4 <_llm_rows.packet_batch.blocks+0xa98>
    1090:      	add	x9, x8, #0x4
    1094:      	st1.s	{ v0 }[1], [x9]
    1098:      	tbz	w10, #0x2, 0xee8 <_llm_rows.packet_batch.blocks+0xa9c>
    109c:      	add	x9, x8, #0x8
    10a0:      	st1.s	{ v0 }[2], [x9]
    10a4:      	tbnz	w10, #0x3, 0xeec <_llm_rows.packet_batch.blocks+0xaa0>
    10a8:      	b	0xef4 <_llm_rows.packet_batch.blocks+0xaa8>
    10ac:      	str	s0, [x8, #0x10]
    10b0:      	tbz	w10, #0x5, 0xfd8 <_llm_rows.packet_batch.blocks+0xb8c>
    10b4:      	add	x9, x8, #0x14
    10b8:      	st1.s	{ v0 }[1], [x9]
    10bc:      	tbz	w10, #0x6, 0xfdc <_llm_rows.packet_batch.blocks+0xb90>
    10c0:      	add	x9, x8, #0x18
    10c4:      	st1.s	{ v0 }[2], [x9]
    10c8:      	tbz	w10, #0x7, 0x4f4 <_llm_rows.packet_batch.blocks+0xa8>
    10cc:      	add	x8, x8, #0x1c
    10d0:      	st1.s	{ v0 }[3], [x8]
    10d4:      	b	0x4f4 <_llm_rows.packet_batch.blocks+0xa8>
    10d8:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
    10dc:      	add	sp, sp, #0x210
    10e0:      	ldp	x29, x30, [sp, #0x90]
    10e4:      	ldp	x20, x19, [sp, #0x80]
    10e8:      	ldp	x22, x21, [sp, #0x70]
    10ec:      	ldp	x24, x23, [sp, #0x60]
    10f0:      	ldp	x26, x25, [sp, #0x50]
    10f4:      	ldp	x28, x27, [sp, #0x40]
    10f8:      	ldp	d9, d8, [sp, #0x30]
    10fc:      	ldp	d11, d10, [sp, #0x20]
    1100:      	ldp	d13, d12, [sp, #0x10]
    1104:      	ldp	d15, d14, [sp], #0xa0
    1108:      	ret

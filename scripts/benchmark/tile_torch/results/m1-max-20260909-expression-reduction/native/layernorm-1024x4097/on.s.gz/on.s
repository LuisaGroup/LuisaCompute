
/private/tmp/luisa-expression-fusion.qXgTbC/capture/layernorm-1024x4097/on/object/tile_xir_w8_23365_1788930263671658_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	mov	x10, #0x0               ; =0
       4:      	ldr	x8, [x1, #0x88]
       8:      	ldr	x14, [x0]
       c:      	ldr	x13, [x0, #0x10]
      10:      	ldr	w9, [x1]
      14:      	ldr	w11, [x1, #0x24]
      18:      	add	w9, w11, w9, lsl #5
      1c:      	lsr	w9, w9, #3
      20:      	dup.2s	v0, w9
      24:      	ushll.2d	v0, v0, #0x0
      28:      	fmov	x9, d0
      2c:      	mov	w11, #0x4004            ; =16388
      30:      	umaddl	x12, w9, w11, x14
      34:      	ldr	x11, [x0, #0x20]
      38:      	ldr	x9, [x0, #0x30]
      3c:      	add	x15, x12, x10
      40:      	ldp	q1, q2, [x15]
      44:      	add	x15, x8, x10
      48:      	stp	q1, q2, [x15]
      4c:      	add	x10, x10, #0x20
      50:      	cmp	x10, #0x4, lsl #12      ; =0x4000
      54:      	b.ne	0x3c <ltmp0+0x3c>
      58:      	fmov	x10, d0
      5c:      	add	x10, x10, x10, lsl #12
      60:      	lsl	x12, x10, #2
      64:      	add	x10, x12, #0x4, lsl #12 ; =0x4000
      68:      	ldr	s0, [x14, x10]
      6c:      	ldr	q17, [x8, #0x4000]
      70:      	mov.s	v17[0], v0[0]
      74:      	str	q17, [x8, #0x4000]
      78:      	ldp	q2, q1, [x8]
      7c:      	ldp	q6, q5, [x8, #0x40]
      80:      	ldp	q16, q7, [x8, #0x60]
      84:      	add	x14, x8, #0xe0
      88:      	mov	w15, #0x4               ; =4
      8c:      	mov.16b	v18, v16
      90:      	mov.16b	v19, v7
      94:      	mov.16b	v20, v6
      98:      	mov.16b	v21, v5
      9c:      	ldp	q4, q3, [x8, #0x20]
      a0:      	mov.16b	v22, v4
      a4:      	mov.16b	v23, v3
      a8:      	mov.16b	v24, v2
      ac:      	mov.16b	v25, v1
      b0:      	ldp	q26, q27, [x14, #-0x60]
      b4:      	fadd.4s	v25, v25, v27
      b8:      	fadd.4s	v24, v24, v26
      bc:      	ldp	q26, q27, [x14, #-0x40]
      c0:      	fadd.4s	v23, v23, v27
      c4:      	fadd.4s	v22, v22, v26
      c8:      	ldp	q26, q27, [x14, #-0x20]
      cc:      	fadd.4s	v21, v21, v27
      d0:      	fadd.4s	v20, v20, v26
      d4:      	ldp	q26, q27, [x14], #0x80
      d8:      	fadd.4s	v19, v19, v27
      dc:      	fadd.4s	v18, v18, v26
      e0:      	cmp	x15, #0x1fc
      e4:      	add	x15, x15, #0x4
      e8:      	b.lo	0xb0 <ltmp0+0xb0>
      ec:      	fadd.4s	v17, v17, v24
      f0:      	mov.s	v24[0], v17[0]
      f4:      	fadd.4s	v17, v23, v25
      f8:      	fadd.4s	v22, v22, v24
      fc:      	fadd.4s	v20, v20, v22
     100:      	fadd.4s	v17, v21, v17
     104:      	fadd.4s	v17, v19, v17
     108:      	fadd.4s	v18, v18, v20
     10c:      	rev64.4s	v19, v18
     110:      	rev64.4s	v20, v17
     114:      	fadd.4s	v17, v17, v20
     118:      	fadd.4s	v18, v18, v19
     11c:      	dup.4s	v19, v18[2]
     120:      	dup.4s	v20, v17[2]
     124:      	fadd.4s	v17, v17, v20
     128:      	fadd.4s	v18, v18, v19
     12c:      	fadd.4s	v17, v18, v17
     130:      	movi	d18, #0000000000000000
     134:      	fadd	s17, s17, s18
     138:      	mov	w14, #0x800             ; =2048
     13c:      	movk	w14, #0x4580, lsl #16
     140:      	fmov	s18, w14
     144:      	fdiv	s17, s17, s18
     148:      	dup.4s	v17, v17[0]
     14c:      	fsub.4s	v18, v2, v17
     150:      	fsub.4s	v1, v1, v17
     154:      	str	q1, [x8, #0x4030]
     158:      	str	q18, [x8, #0x4020]
     15c:      	fmul.4s	v2, v1, v1
     160:      	fmul.4s	v1, v18, v18
     164:      	fsub.4s	v18, v4, v17
     168:      	fsub.4s	v3, v3, v17
     16c:      	str	q3, [x8, #0x4050]
     170:      	str	q18, [x8, #0x4040]
     174:      	fmul.4s	v4, v3, v3
     178:      	fmul.4s	v3, v18, v18
     17c:      	fsub.4s	v6, v6, v17
     180:      	fsub.4s	v5, v5, v17
     184:      	str	q5, [x8, #0x4070]
     188:      	str	q6, [x8, #0x4060]
     18c:      	fmul.4s	v5, v5, v5
     190:      	fmul.4s	v6, v6, v6
     194:      	fsub.4s	v18, v16, v17
     198:      	fsub.4s	v7, v7, v17
     19c:      	str	q7, [x8, #0x4090]
     1a0:      	str	q18, [x8, #0x4080]
     1a4:      	fmul.4s	v16, v7, v7
     1a8:      	fmul.4s	v7, v18, v18
     1ac:      	mov	w15, #0x208             ; =520
     1b0:      	mov	x14, x8
     1b4:      	ldp	q18, q19, [x14, #0x80]!
     1b8:      	ldr	q20, [x14, #0x20]
     1bc:      	fsub.4s	v19, v19, v17
     1c0:      	fsub.4s	v18, v18, v17
     1c4:      	str	q18, [x14, #0x4020]
     1c8:      	str	q19, [x14, #0x4030]
     1cc:      	fmul.4s	v19, v19, v19
     1d0:      	fmul.4s	v18, v18, v18
     1d4:      	fadd.4s	v1, v1, v18
     1d8:      	fadd.4s	v2, v2, v19
     1dc:      	fsub.4s	v18, v20, v17
     1e0:      	ldp	q19, q20, [x14, #0x30]
     1e4:      	fsub.4s	v19, v19, v17
     1e8:      	str	q19, [x14, #0x4050]
     1ec:      	str	q18, [x14, #0x4040]
     1f0:      	fmul.4s	v18, v18, v18
     1f4:      	fmul.4s	v19, v19, v19
     1f8:      	fadd.4s	v4, v4, v19
     1fc:      	fadd.4s	v3, v3, v18
     200:      	ldp	q18, q19, [x14, #0x50]
     204:      	fsub.4s	v18, v18, v17
     208:      	str	q18, [x14, #0x4070]
     20c:      	fmul.4s	v18, v18, v18
     210:      	fadd.4s	v5, v5, v18
     214:      	fsub.4s	v18, v20, v17
     218:      	str	q18, [x14, #0x4060]
     21c:      	fmul.4s	v18, v18, v18
     220:      	fadd.4s	v6, v6, v18
     224:      	ldr	q18, [x14, #0x70]
     228:      	fsub.4s	v19, v19, v17
     22c:      	fsub.4s	v18, v18, v17
     230:      	str	q18, [x14, #0x4090]
     234:      	str	q19, [x14, #0x4080]
     238:      	fmul.4s	v19, v19, v19
     23c:      	fmul.4s	v18, v18, v18
     240:      	fadd.4s	v16, v16, v18
     244:      	fadd.4s	v7, v7, v19
     248:      	sub	x16, x15, #0x204
     24c:      	add	x15, x15, #0x4
     250:      	cmp	x16, #0x1fc
     254:      	b.lo	0x1b4 <ltmp0+0x1b4>
     258:      	mov	x14, #0x0               ; =0
     25c:      	mov	w15, #0x8040            ; =32832
     260:      	movi.2d	v18, #0000000000000000
     264:      	mov.s	v18[0], v0[0]
     268:      	add	x15, x8, x15
     26c:      	fsub.4s	v0, v18, v17
     270:      	ldr	q17, [x8, #0x8020]
     274:      	mov.s	v17[0], v0[0]
     278:      	str	q17, [x8, #0x8020]
     27c:      	add	x16, x13, x14
     280:      	ldp	q17, q18, [x16]
     284:      	add	x16, x15, x14
     288:      	stp	q17, q18, [x16]
     28c:      	add	x14, x14, #0x20
     290:      	cmp	x14, #0x4, lsl #12      ; =0x4000
     294:      	b.ne	0x27c <ltmp0+0x27c>
     298:      	mov	x14, #0x0               ; =0
     29c:      	mov	w15, #0xc060            ; =49248
     2a0:      	add	x15, x8, x15
     2a4:      	mov	w16, #0x4000            ; =16384
     2a8:      	ldr	s17, [x13, x16]
     2ac:      	mov	w13, #0xc040            ; =49216
     2b0:      	str	s17, [x8, x13]
     2b4:      	add	x13, x11, x14
     2b8:      	ldp	q17, q18, [x13]
     2bc:      	add	x13, x15, x14
     2c0:      	stp	q17, q18, [x13]
     2c4:      	add	x14, x14, #0x20
     2c8:      	cmp	x14, #0x4, lsl #12      ; =0x4000
     2cc:      	b.ne	0x2b4 <ltmp0+0x2b4>
     2d0:      	fmul.4s	v0, v0, v0
     2d4:      	fadd.4s	v0, v1, v0
     2d8:      	mov.s	v1[0], v0[0]
     2dc:      	fadd.4s	v0, v4, v2
     2e0:      	fadd.4s	v1, v3, v1
     2e4:      	fadd.4s	v1, v6, v1
     2e8:      	fadd.4s	v0, v5, v0
     2ec:      	fadd.4s	v0, v16, v0
     2f0:      	fadd.4s	v1, v7, v1
     2f4:      	rev64.4s	v2, v1
     2f8:      	rev64.4s	v3, v0
     2fc:      	fadd.4s	v0, v0, v3
     300:      	fadd.4s	v1, v1, v2
     304:      	dup.4s	v2, v1[2]
     308:      	dup.4s	v3, v0[2]
     30c:      	fadd.4s	v0, v0, v3
     310:      	fadd.4s	v1, v1, v2
     314:      	fadd.4s	v0, v1, v0
     318:      	movi	d1, #0000000000000000
     31c:      	fadd	s0, s0, s1
     320:      	mov	w13, #0x800             ; =2048
     324:      	movk	w13, #0x4580, lsl #16
     328:      	fmov	s1, w13
     32c:      	fdiv	s0, s0, s1
     330:      	mov	w13, #0xc5ac            ; =50604
     334:      	movk	w13, #0x3727, lsl #16
     338:      	fmov	s1, w13
     33c:      	fadd	s0, s0, s1
     340:      	mov	w13, #0x4000            ; =16384
     344:      	ldr	s1, [x11, x13]
     348:      	mov	w11, #0x60              ; =96
     34c:      	movk	w11, #0x1, lsl #16
     350:      	str	s1, [x8, x11]
     354:      	fsqrt	s0, s0
     358:      	dup.4s	v1, v0[0]
     35c:      	add	x11, x9, x12
     360:      	mov	w12, #0x200             ; =512
     364:      	mov	x13, x8
     368:      	ldr	q2, [x13, #0x4030]
     36c:      	ldr	q3, [x13, #0x4020]
     370:      	fdiv.4s	v3, v3, v1
     374:      	fdiv.4s	v2, v2, v1
     378:      	ldr	q4, [x13, #0x8040]
     37c:      	ldr	q5, [x13, #0x8050]
     380:      	fmul.4s	v2, v2, v5
     384:      	fmul.4s	v3, v3, v4
     388:      	ldr	q4, [x13, #0xc070]
     38c:      	ldr	q5, [x13, #0xc060]
     390:      	fadd.4s	v3, v3, v5
     394:      	fadd.4s	v2, v2, v4
     398:      	stp	q3, q2, [x11], #0x20
     39c:      	add	x13, x13, #0x20
     3a0:      	subs	x12, x12, #0x1
     3a4:      	b.ne	0x368 <ltmp0+0x368>
     3a8:      	ldr	q1, [x8, #0x8020]
     3ac:      	fdiv.4s	v0, v1, v0
     3b0:      	ldr	q1, [x8, #0xc040]
     3b4:      	fmul.4s	v0, v0, v1
     3b8:      	add	x11, x8, #0x10, lsl #12 ; =0x10000
     3bc:      	ldr	q1, [x11, #0x60]
     3c0:      	fadd.4s	v0, v0, v1
     3c4:      	str	s0, [x9, x10]
     3c8:      	ret

00000000000003cc <_llm_rows.packet_batch.blocks>:
     3cc:      	cbz	w3, 0x1bb8 <_llm_rows.packet_batch.blocks+0x17ec>
     3d0:      	stp	d15, d14, [sp, #-0xa0]!
     3d4:      	stp	d13, d12, [sp, #0x10]
     3d8:      	stp	d11, d10, [sp, #0x20]
     3dc:      	stp	d9, d8, [sp, #0x30]
     3e0:      	stp	x28, x27, [sp, #0x40]
     3e4:      	stp	x26, x25, [sp, #0x50]
     3e8:      	stp	x24, x23, [sp, #0x60]
     3ec:      	stp	x22, x21, [sp, #0x70]
     3f0:      	stp	x20, x19, [sp, #0x80]
     3f4:      	stp	x29, x30, [sp, #0x90]
     3f8:      	sub	sp, sp, #0x680
     3fc:      	mov	x19, x3
     400:      	mov	x20, x2
     404:      	mov	x21, x0
     408:      	mov	w22, #0x0               ; =0
     40c:      	ldp	w9, w8, [x2, #0x2c]
     410:      	str	w9, [sp, #0x19c]
     414:      	str	w8, [sp, #0x198]
     418:      	ldp	w25, w24, [x2]
     41c:      	ldp	w28, w23, [x2, #0x8]
     420:      	adrp	x8, 0x0 <ltmp0>
     424:      	ldr	q0, [x8]
     428:      	str	q0, [sp, #0x10]
     42c:      	adrp	x8, 0x0 <ltmp0>
     430:      	ldr	q0, [x8]
     434:      	str	q0, [sp, #0x30]
     438:      	adrp	x8, 0x0 <ltmp0>
     43c:      	ldr	q0, [x8]
     440:      	str	q0, [sp, #0x20]
     444:      	mov	w26, #0x4               ; =4
     448:      	str	w3, [sp, #0x17c]
     44c:      	b	0x498 <_llm_rows.packet_batch.blocks+0xcc>
     450:      	mov	w8, #0x18               ; =24
     454:      	str	w8, [x20, #0x24]
     458:      	ldr	w19, [sp, #0x17c]
     45c:      	add	w8, w25, #0x1
     460:      	ldr	w9, [sp, #0x19c]
     464:      	cmp	w8, w9
     468:      	cset	w8, eq
     46c:      	csinc	w25, wzr, w25, eq
     470:      	cinc	w9, w24, eq
     474:      	ldr	w10, [sp, #0x198]
     478:      	cmp	w9, w10
     47c:      	cset	w10, eq
     480:      	ands	w8, w8, w10
     484:      	csel	w24, wzr, w9, ne
     488:      	add	w28, w28, w8
     48c:      	add	w22, w22, #0x1
     490:      	cmp	w22, w19
     494:      	b.eq	0x1b8c <_llm_rows.packet_batch.blocks+0x17c0>
     498:      	ubfiz	x8, x25, #5, #32
     49c:      	cmp	x8, x23
     4a0:      	csel	x9, x8, xzr, ls
     4a4:      	subs	x10, x23, x9
     4a8:      	cmp	x10, #0x20
     4ac:      	mov	w11, #0x20              ; =32
     4b0:      	csel	x10, x10, x11, lo
     4b4:      	cmp	x23, x9
     4b8:      	stp	w25, w24, [x20]
     4bc:      	str	w28, [x20, #0x8]
     4c0:      	str	wzr, [x20, #0x24]
     4c4:      	ccmp	x8, x23, #0x2, hi
     4c8:      	csel	x27, x10, xzr, ls
     4cc:      	cmp	x27, #0x20
     4d0:      	b.lo	0x520 <_llm_rows.packet_batch.blocks+0x154>
     4d4:      	mov	x0, x21
     4d8:      	mov	x1, x20
     4dc:      	bl	0x4dc <_llm_rows.packet_batch.blocks+0x110>
     4e0:      	mov	w8, #0x8                ; =8
     4e4:      	str	w8, [x20, #0x24]
     4e8:      	mov	x0, x21
     4ec:      	mov	x1, x20
     4f0:      	bl	0x4f0 <_llm_rows.packet_batch.blocks+0x124>
     4f4:      	mov	w8, #0x10               ; =16
     4f8:      	str	w8, [x20, #0x24]
     4fc:      	mov	x0, x21
     500:      	mov	x1, x20
     504:      	bl	0x504 <_llm_rows.packet_batch.blocks+0x138>
     508:      	mov	w8, #0x18               ; =24
     50c:      	str	w8, [x20, #0x24]
     510:      	mov	x0, x21
     514:      	mov	x1, x20
     518:      	bl	0x518 <_llm_rows.packet_batch.blocks+0x14c>
     51c:      	b	0x45c <_llm_rows.packet_batch.blocks+0x90>
     520:      	lsr	x19, x27, #3
     524:      	cmp	x27, #0x8
     528:      	b.lo	0x574 <_llm_rows.packet_batch.blocks+0x1a8>
     52c:      	str	wzr, [x20, #0x24]
     530:      	mov	x0, x21
     534:      	mov	x1, x20
     538:      	bl	0x538 <_llm_rows.packet_batch.blocks+0x16c>
     53c:      	cmp	x19, #0x1
     540:      	b.eq	0x574 <_llm_rows.packet_batch.blocks+0x1a8>
     544:      	mov	w8, #0x8                ; =8
     548:      	str	w8, [x20, #0x24]
     54c:      	mov	x0, x21
     550:      	mov	x1, x20
     554:      	bl	0x554 <_llm_rows.packet_batch.blocks+0x188>
     558:      	cmp	x19, #0x2
     55c:      	b.eq	0x574 <_llm_rows.packet_batch.blocks+0x1a8>
     560:      	mov	w8, #0x10               ; =16
     564:      	str	w8, [x20, #0x24]
     568:      	mov	x0, x21
     56c:      	mov	x1, x20
     570:      	bl	0x570 <_llm_rows.packet_batch.blocks+0x1a4>
     574:      	and	w8, w27, #0x7
     578:      	cbz	w8, 0x450 <_llm_rows.packet_batch.blocks+0x84>
     57c:      	dup.4s	v1, w8
     580:      	ldp	q0, q2, [sp, #0x20]
     584:      	cmhi.4s	v0, v1, v0
     588:      	cmhi.4s	v1, v1, v2
     58c:      	uzp1.8h	v3, v1, v0
     590:      	umaxv.8h	h2, v3
     594:      	fmov	w8, s2
     598:      	tbz	w8, #0x0, 0x450 <_llm_rows.packet_batch.blocks+0x84>
     59c:      	mov	x12, #0x0               ; =0
     5a0:      	ldr	x27, [x20, #0x88]
     5a4:      	mov	w8, #0x4020             ; =16416
     5a8:      	add	x11, x27, x8
     5ac:      	mov	w8, #0x8040             ; =32832
     5b0:      	add	x10, x27, x8
     5b4:      	mov	w8, #0xc060             ; =49248
     5b8:      	add	x9, x27, x8
     5bc:      	ldr	x8, [x21]
     5c0:      	ldr	x15, [x21, #0x10]
     5c4:      	ldr	x13, [x21, #0x20]
     5c8:      	ldr	x14, [x21, #0x30]
     5cc:      	str	x14, [sp, #0x170]
     5d0:      	ldr	q2, [sp, #0x10]
     5d4:      	str	q3, [sp, #0xf0]
     5d8:      	and.16b	v2, v3, v2
     5dc:      	addv.8h	h16, v2
     5e0:      	fmov	w14, s16
     5e4:      	and	w14, w14, #0xff
     5e8:      	str	w14, [sp, #0xa8]
     5ec:      	ubfiz	w14, w25, #2, #27
     5f0:      	orr	w14, w14, w19
     5f4:      	dup.4s	v3, w14
     5f8:      	and.16b	v4, v1, v3
     5fc:      	and.16b	v3, v0, v3
     600:      	ushll2.2d	v5, v3, #0x0
     604:      	ushll2.2d	v6, v4, #0x0
     608:      	ushll.2d	v7, v3, #0x0
     60c:      	ushll.2d	v4, v4, #0x0
     610:      	fmov	x14, d4
     614:      	mov	w16, #0x4004            ; =16388
     618:      	umaddl	x14, w14, w16, x8
     61c:      	fmov	w16, s16
     620:      	b	0x644 <_llm_rows.packet_batch.blocks+0x278>
     624:      	add	x17, x27, x12
     628:      	ldp	q18, q19, [x17]
     62c:      	bif.16b	v17, v19, v0
     630:      	bif.16b	v3, v18, v1
     634:      	stp	q3, q17, [x17]
     638:      	add	x12, x12, #0x20
     63c:      	cmp	x12, #0x4, lsl #12      ; =0x4000
     640:      	b.eq	0x6d8 <_llm_rows.packet_batch.blocks+0x30c>
     644:      	add	x17, x14, x12
     648:      	movi.2d	v3, #0000000000000000
     64c:      	movi.2d	v17, #0000000000000000
     650:      	tbnz	w16, #0x0, 0x678 <_llm_rows.packet_batch.blocks+0x2ac>
     654:      	and	w0, w16, #0xff
     658:      	tbnz	w0, #0x1, 0x684 <_llm_rows.packet_batch.blocks+0x2b8>
     65c:      	tbnz	w0, #0x2, 0x690 <_llm_rows.packet_batch.blocks+0x2c4>
     660:      	tbnz	w0, #0x3, 0x69c <_llm_rows.packet_batch.blocks+0x2d0>
     664:      	tbnz	w0, #0x4, 0x6a8 <_llm_rows.packet_batch.blocks+0x2dc>
     668:      	tbnz	w0, #0x5, 0x6b4 <_llm_rows.packet_batch.blocks+0x2e8>
     66c:      	tbnz	w0, #0x6, 0x6c0 <_llm_rows.packet_batch.blocks+0x2f4>
     670:      	tbz	w0, #0x7, 0x624 <_llm_rows.packet_batch.blocks+0x258>
     674:      	b	0x6cc <_llm_rows.packet_batch.blocks+0x300>
     678:      	ldr	s3, [x17]
     67c:      	and	w0, w16, #0xff
     680:      	tbz	w0, #0x1, 0x65c <_llm_rows.packet_batch.blocks+0x290>
     684:      	add	x1, x17, #0x4
     688:      	ld1.s	{ v3 }[1], [x1]
     68c:      	tbz	w0, #0x2, 0x660 <_llm_rows.packet_batch.blocks+0x294>
     690:      	add	x1, x17, #0x8
     694:      	ld1.s	{ v3 }[2], [x1]
     698:      	tbz	w0, #0x3, 0x664 <_llm_rows.packet_batch.blocks+0x298>
     69c:      	add	x1, x17, #0xc
     6a0:      	ld1.s	{ v3 }[3], [x1]
     6a4:      	tbz	w0, #0x4, 0x668 <_llm_rows.packet_batch.blocks+0x29c>
     6a8:      	add	x1, x17, #0x10
     6ac:      	ld1.s	{ v17 }[0], [x1]
     6b0:      	tbz	w0, #0x5, 0x66c <_llm_rows.packet_batch.blocks+0x2a0>
     6b4:      	add	x1, x17, #0x14
     6b8:      	ld1.s	{ v17 }[1], [x1]
     6bc:      	tbz	w0, #0x6, 0x670 <_llm_rows.packet_batch.blocks+0x2a4>
     6c0:      	add	x1, x17, #0x18
     6c4:      	ld1.s	{ v17 }[2], [x1]
     6c8:      	tbz	w0, #0x7, 0x624 <_llm_rows.packet_batch.blocks+0x258>
     6cc:      	add	x17, x17, #0x1c
     6d0:      	ld1.s	{ v17 }[3], [x17]
     6d4:      	b	0x624 <_llm_rows.packet_batch.blocks+0x258>
     6d8:      	xtn.4h	v3, v1
     6dc:      	uzp1.8b	v18, v3, v0
     6e0:      	sshll.2d	v17, v1, #0x0
     6e4:      	adrp	x12, 0x0 <ltmp0>
     6e8:      	ldr	q3, [x12]
     6ec:      	and.16b	v20, v17, v3
     6f0:      	movi.2d	v3, #0000000000000000
     6f4:      	mov.b	v3[0], v18[0]
     6f8:      	adrp	x12, 0x0 <ltmp0>
     6fc:      	ldr	d2, [x12]
     700:      	str	d2, [sp, #0x108]
     704:      	and.8b	v19, v3, v2
     708:      	addv.8b	b19, v19
     70c:      	fmov	w14, s19
     710:      	umaxv.8b	b19, v3
     714:      	fmov	w16, s19
     718:      	rbit	w12, w14
     71c:      	clz	w12, w12
     720:      	tst	w16, #0x1
     724:      	csel	w12, w12, wzr, ne
     728:      	mov	w17, #0x1000            ; =4096
     72c:      	dup.2d	v23, x17
     730:      	str	q20, [sp, #0xe0]
     734:      	orr.16b	v2, v20, v23
     738:      	mov	w17, #0x1001            ; =4097
     73c:      	dup.2s	v22, w17
     740:      	xtn.2s	v10, v4
     744:      	str	q2, [sp, #0x80]
     748:      	umlal.2d	v2, v10, v22
     74c:      	movi.2d	v4, #0000000000000000
     750:      	mov.b	v4[0], v18[0]
     754:      	ushll.2d	v4, v4, #0x0
     758:      	shl.2d	v4, v4, #0x3f
     75c:      	cmlt.2d	v4, v4, #0
     760:      	str	q2, [sp, #0x150]
     764:      	and.16b	v4, v4, v2
     768:      	movi.2d	v2, #0000000000000000
     76c:      	str	q2, [sp, #0x660]
     770:      	str	q2, [sp, #0x650]
     774:      	str	q2, [sp, #0x640]
     778:      	str	q4, [sp, #0x630]
     77c:      	and	x17, x12, #0x7
     780:      	add	x0, sp, #0x630
     784:      	ldr	x17, [x0, x17, lsl #3]
     788:      	sub	x17, x17, x12
     78c:      	add	x8, x8, x17, lsl #2
     790:      	movi.2d	v26, #0000000000000000
     794:      	movi.2d	v27, #0000000000000000
     798:      	tbnz	w16, #0x0, 0x1a38 <_llm_rows.packet_batch.blocks+0x166c>
     79c:      	tbnz	w14, #0x1, 0x1a40 <_llm_rows.packet_batch.blocks+0x1674>
     7a0:      	tbnz	w14, #0x2, 0x1a4c <_llm_rows.packet_batch.blocks+0x1680>
     7a4:      	tbnz	w14, #0x3, 0x1a58 <_llm_rows.packet_batch.blocks+0x168c>
     7a8:      	tbnz	w14, #0x4, 0x1a64 <_llm_rows.packet_batch.blocks+0x1698>
     7ac:      	tbnz	w14, #0x5, 0x1a70 <_llm_rows.packet_batch.blocks+0x16a4>
     7b0:      	tbnz	w14, #0x6, 0x1a7c <_llm_rows.packet_batch.blocks+0x16b0>
     7b4:      	tbz	w14, #0x7, 0x7c0 <_llm_rows.packet_batch.blocks+0x3f4>
     7b8:      	add	x8, x8, #0x1c
     7bc:      	ld1.s	{ v27 }[3], [x8]
     7c0:      	str	q16, [sp, #0x160]
     7c4:      	sshll.2d	v4, v0, #0x0
     7c8:      	sshll2.2d	v20, v1, #0x0
     7cc:      	sshll2.2d	v21, v0, #0x0
     7d0:      	adrp	x8, 0x0 <ltmp0>
     7d4:      	ldr	q18, [x8]
     7d8:      	and.16b	v2, v21, v18
     7dc:      	adrp	x8, 0x0 <ltmp0>
     7e0:      	ldr	q18, [x8]
     7e4:      	and.16b	v16, v20, v18
     7e8:      	adrp	x8, 0x0 <ltmp0>
     7ec:      	ldr	q18, [x8]
     7f0:      	and.16b	v25, v4, v18
     7f4:      	adrp	x8, 0x0 <ltmp0>
     7f8:      	ldr	q18, [x8]
     7fc:      	and.16b	v18, v21, v18
     800:      	adrp	x8, 0x0 <ltmp0>
     804:      	ldr	q19, [x8]
     808:      	and.16b	v19, v20, v19
     80c:      	adrp	x8, 0x0 <ltmp0>
     810:      	ldr	q24, [x8]
     814:      	and.16b	v4, v4, v24
     818:      	adrp	x8, 0x0 <ltmp0>
     81c:      	ldr	q24, [x8]
     820:      	and.16b	v17, v17, v24
     824:      	str	q25, [sp, #0x40]
     828:      	orr.16b	v24, v25, v23
     82c:      	str	q16, [sp, #0x90]
     830:      	orr.16b	v25, v16, v23
     834:      	str	q2, [sp, #0xb0]
     838:      	orr.16b	v16, v2, v23
     83c:      	umull.2d	v2, v10, v22
     840:      	str	q2, [sp, #0x110]
     844:      	xtn.2s	v6, v6
     848:      	xtn.2s	v7, v7
     84c:      	xtn.2s	v5, v5
     850:      	stp	q24, q16, [sp, #0x60]
     854:      	mov.16b	v2, v16
     858:      	umlal.2d	v2, v5, v22
     85c:      	str	q2, [sp, #0x140]
     860:      	str	q25, [sp, #0x50]
     864:      	mov.16b	v2, v25
     868:      	umlal.2d	v2, v6, v22
     86c:      	str	q2, [sp, #0x130]
     870:      	mov.16b	v2, v24
     874:      	umlal.2d	v2, v7, v22
     878:      	str	q2, [sp, #0x120]
     87c:      	sshll.2d	v5, v1, #0x0
     880:      	sshll.2d	v6, v0, #0x0
     884:      	str	q17, [sp, #0x5f0]
     888:      	str	q19, [sp, #0x600]
     88c:      	str	q4, [sp, #0x610]
     890:      	str	q18, [sp, #0x620]
     894:      	and	x8, x12, #0x7
     898:      	add	x16, sp, #0x5f0
     89c:      	ldr	x8, [x16, x8, lsl #3]
     8a0:      	orr	x8, x8, #0x4000
     8a4:      	sub	x8, x8, x12, lsl #2
     8a8:      	tst	w14, #0xff
     8ac:      	csel	x14, xzr, x8, eq
     8b0:      	add	x8, x27, x14
     8b4:      	ldp	q4, q7, [x8]
     8b8:      	zip2.8b	v18, v3, v0
     8bc:      	ushll.4s	v18, v18, #0x0
     8c0:      	shl.4s	v18, v18, #0x1f
     8c4:      	cmlt.4s	v18, v18, #0
     8c8:      	stp	q27, q26, [sp, #0xc0]
     8cc:      	bit.16b	v7, v27, v18
     8d0:      	str	q3, [sp, #0x180]
     8d4:      	zip1.8b	v18, v3, v0
     8d8:      	ushll.4s	v18, v18, #0x0
     8dc:      	shl.4s	v18, v18, #0x1f
     8e0:      	cmlt.4s	v18, v18, #0
     8e4:      	bit.16b	v4, v26, v18
     8e8:      	stp	q4, q7, [x8]
     8ec:      	dup.2d	v4, x26
     8f0:      	and.16b	v26, v21, v4
     8f4:      	and.16b	v23, v20, v4
     8f8:      	and.16b	v25, v6, v4
     8fc:      	and.16b	v14, v5, v4
     900:      	fmov	x8, d14
     904:      	ldp	q5, q4, [x27, #0x60]
     908:      	and.16b	v4, v0, v4
     90c:      	and.16b	v5, v1, v5
     910:      	ldp	q6, q7, [x27, #0x40]
     914:      	and.16b	v7, v0, v7
     918:      	and.16b	v6, v1, v6
     91c:      	ldp	q18, q19, [x27, #0x20]
     920:      	and.16b	v10, v0, v19
     924:      	and.16b	v11, v1, v18
     928:      	fmov	x16, d17
     92c:      	add	x16, x27, x16
     930:      	ldp	q17, q18, [x16]
     934:      	and.16b	v18, v0, v18
     938:      	mov	x16, x8
     93c:      	and.16b	v19, v1, v17
     940:      	mov.16b	v17, v14
     944:      	mov.16b	v15, v23
     948:      	mov.16b	v13, v25
     94c:      	mov.16b	v22, v26
     950:      	sshll.2d	v27, v1, #0x0
     954:      	sshll.2d	v8, v0, #0x0
     958:      	add	x16, x27, x16, lsl #5
     95c:      	ldp	q12, q24, [x16]
     960:      	fadd.4s	v12, v19, v12
     964:      	fadd.4s	v24, v18, v24
     968:      	ldp	q30, q16, [x16, #0x20]
     96c:      	fadd.4s	v30, v11, v30
     970:      	fadd.4s	v16, v10, v16
     974:      	ldp	q31, q3, [x16, #0x40]
     978:      	fadd.4s	v31, v6, v31
     97c:      	fadd.4s	v3, v7, v3
     980:      	ldp	q28, q9, [x16, #0x60]
     984:      	fadd.4s	v28, v5, v28
     988:      	fadd.4s	v9, v4, v9
     98c:      	dup.2d	v29, x26
     990:      	and.16b	v2, v21, v29
     994:      	add.2d	v22, v22, v2
     998:      	and.16b	v2, v20, v29
     99c:      	add.2d	v15, v15, v2
     9a0:      	and.16b	v2, v8, v29
     9a4:      	add.2d	v13, v13, v2
     9a8:      	and.16b	v2, v27, v29
     9ac:      	add.2d	v17, v17, v2
     9b0:      	bit.16b	v18, v24, v0
     9b4:      	bit.16b	v19, v12, v1
     9b8:      	bit.16b	v10, v16, v0
     9bc:      	bit.16b	v11, v30, v1
     9c0:      	bit.16b	v7, v3, v0
     9c4:      	bit.16b	v6, v31, v1
     9c8:      	bit.16b	v4, v9, v0
     9cc:      	bit.16b	v5, v28, v1
     9d0:      	fmov	x16, d17
     9d4:      	cmp	x16, #0x200
     9d8:      	b.lt	0x950 <_llm_rows.packet_batch.blocks+0x584>
     9dc:      	ldr	q2, [sp, #0xf0]
     9e0:      	xtn.8b	v17, v2
     9e4:      	ldp	q2, q3, [sp, #0xc0]
     9e8:      	fadd.4s	v2, v2, v18
     9ec:      	fadd.4s	v3, v3, v19
     9f0:      	ldr	q18, [sp, #0x180]
     9f4:      	zip1.8b	v16, v18, v0
     9f8:      	ushll.4s	v16, v16, #0x0
     9fc:      	shl.4s	v16, v16, #0x1f
     a00:      	cmlt.4s	v16, v16, #0
     a04:      	and.16b	v3, v16, v3
     a08:      	zip2.8b	v16, v18, v0
     a0c:      	ushll.4s	v16, v16, #0x0
     a10:      	shl.4s	v16, v16, #0x1f
     a14:      	cmlt.4s	v16, v16, #0
     a18:      	and.16b	v2, v16, v2
     a1c:      	zip2.8b	v16, v17, v0
     a20:      	ushll.4s	v16, v16, #0x0
     a24:      	shl.4s	v16, v16, #0x1f
     a28:      	cmlt.4s	v16, v16, #0
     a2c:      	movi.2d	v18, #0000000000000000
     a30:      	mov.b	v18[2], v17[1]
     a34:      	bit.16b	v2, v24, v16
     a38:      	mov.b	v18[4], v17[2]
     a3c:      	mov.b	v18[6], v17[3]
     a40:      	ushll.4s	v16, v18, #0x0
     a44:      	shl.4s	v16, v16, #0x1f
     a48:      	cmlt.4s	v16, v16, #0
     a4c:      	bit.16b	v3, v12, v16
     a50:      	fadd.4s	v3, v11, v3
     a54:      	fadd.4s	v2, v10, v2
     a58:      	fadd.4s	v2, v7, v2
     a5c:      	fadd.4s	v3, v6, v3
     a60:      	fadd.4s	v28, v5, v3
     a64:      	fadd.4s	v29, v4, v2
     a68:      	ldr	q2, [sp, #0xe0]
     a6c:      	ldr	q3, [sp, #0x90]
     a70:      	uzp1.4s	v16, v2, v3
     a74:      	ldr	q2, [sp, #0xb0]
     a78:      	ldr	q3, [sp, #0x40]
     a7c:      	uzp1.4s	v5, v3, v2
     a80:      	movi.4s	v3, #0x1
     a84:      	eor.16b	v2, v16, v3
     a88:      	mov.s	w17, v2[1]
     a8c:      	mov.s	w0, v2[2]
     a90:      	mov.s	w2, v2[3]
     a94:      	fmov	w16, s2
     a98:      	add	x1, sp, #0x488
     a9c:      	bfxil	x1, x16, #0, #3
     aa0:      	str	d17, [sp, #0x488]
     aa4:      	ldrb	w1, [x1]
     aa8:      	and	x3, x16, #0x7
     aac:      	umov.b	w16, v17[0]
     ab0:      	str	q29, [sp, #0x560]
     ab4:      	str	q28, [sp, #0x550]
     ab8:      	add	x4, sp, #0x550
     abc:      	ldr	s2, [x4, x3, lsl #2]
     ac0:      	eor.16b	v18, v5, v3
     ac4:      	ands	w4, w16, #0x1
     ac8:      	tst	w4, w1
     acc:      	movi	d30, #0000000000000000
     ad0:      	fcsel	s4, s2, s30, ne
     ad4:      	and	x3, x17, #0x7
     ad8:      	add	x1, sp, #0x488
     adc:      	bfxil	x1, x17, #0, #3
     ae0:      	ldrb	w17, [x1]
     ae4:      	umov.b	w1, v17[1]
     ae8:      	and	w17, w1, w17
     aec:      	str	q29, [sp, #0x540]
     af0:      	str	q28, [sp, #0x530]
     af4:      	add	x5, sp, #0x530
     af8:      	ldr	s2, [x5, x3, lsl #2]
     afc:      	tst	w17, #0x1
     b00:      	fcsel	s6, s2, s30, ne
     b04:      	and	x3, x0, #0x7
     b08:      	add	x17, sp, #0x488
     b0c:      	bfxil	x17, x0, #0, #3
     b10:      	ldrb	w0, [x17]
     b14:      	umov.b	w17, v17[2]
     b18:      	and	w0, w17, w0
     b1c:      	str	q29, [sp, #0x520]
     b20:      	str	q28, [sp, #0x510]
     b24:      	add	x5, sp, #0x510
     b28:      	ldr	s2, [x5, x3, lsl #2]
     b2c:      	tst	w0, #0x1
     b30:      	fcsel	s7, s2, s30, ne
     b34:      	and	x3, x2, #0x7
     b38:      	add	x0, sp, #0x488
     b3c:      	bfxil	x0, x2, #0, #3
     b40:      	ldrb	w2, [x0]
     b44:      	umov.b	w0, v17[3]
     b48:      	and	w2, w0, w2
     b4c:      	str	q29, [sp, #0x500]
     b50:      	str	q28, [sp, #0x4f0]
     b54:      	add	x5, sp, #0x4f0
     b58:      	ldr	s2, [x5, x3, lsl #2]
     b5c:      	tst	w2, #0x1
     b60:      	mov.s	w2, v18[1]
     b64:      	mov.s	w3, v18[2]
     b68:      	mov.s	w7, v18[3]
     b6c:      	fcsel	s19, s2, s30, ne
     b70:      	fmov	w5, s18
     b74:      	and	x19, x5, #0x7
     b78:      	add	x6, sp, #0x488
     b7c:      	bfxil	x6, x5, #0, #3
     b80:      	ldrb	w5, [x6]
     b84:      	umov.b	w6, v17[4]
     b88:      	str	q29, [sp, #0x5e0]
     b8c:      	str	q28, [sp, #0x5d0]
     b90:      	add	x30, sp, #0x5d0
     b94:      	ldr	s2, [x30, x19, lsl #2]
     b98:      	and	w5, w6, w5
     b9c:      	tst	w5, #0x1
     ba0:      	fcsel	s2, s2, s30, ne
     ba4:      	and	x19, x2, #0x7
     ba8:      	add	x5, sp, #0x488
     bac:      	bfxil	x5, x2, #0, #3
     bb0:      	ldrb	w2, [x5]
     bb4:      	umov.b	w5, v17[5]
     bb8:      	and	w2, w5, w2
     bbc:      	str	q29, [sp, #0x5c0]
     bc0:      	str	q28, [sp, #0x5b0]
     bc4:      	add	x30, sp, #0x5b0
     bc8:      	ldr	s3, [x30, x19, lsl #2]
     bcc:      	tst	w2, #0x1
     bd0:      	fcsel	s3, s3, s30, ne
     bd4:      	and	x19, x3, #0x7
     bd8:      	add	x2, sp, #0x488
     bdc:      	bfxil	x2, x3, #0, #3
     be0:      	ldrb	w3, [x2]
     be4:      	umov.b	w2, v17[6]
     be8:      	and	w3, w2, w3
     bec:      	str	q29, [sp, #0x5a0]
     bf0:      	str	q28, [sp, #0x590]
     bf4:      	add	x30, sp, #0x590
     bf8:      	ldr	s18, [x30, x19, lsl #2]
     bfc:      	tst	w3, #0x1
     c00:      	fcsel	s18, s18, s30, ne
     c04:      	and	x19, x7, #0x7
     c08:      	add	x3, sp, #0x488
     c0c:      	bfxil	x3, x7, #0, #3
     c10:      	ldrb	w7, [x3]
     c14:      	umov.b	w3, v17[7]
     c18:      	and	w7, w3, w7
     c1c:      	str	q29, [sp, #0x580]
     c20:      	str	q28, [sp, #0x570]
     c24:      	add	x30, sp, #0x570
     c28:      	ldr	s22, [x30, x19, lsl #2]
     c2c:      	tst	w7, #0x1
     c30:      	fcsel	s22, s22, s30, ne
     c34:      	mov.s	v2[1], v3[0]
     c38:      	mov.s	v2[2], v18[0]
     c3c:      	mov.s	v2[3], v22[0]
     c40:      	mov.s	v4[1], v6[0]
     c44:      	mov.s	v4[2], v7[0]
     c48:      	mov.s	v4[3], v19[0]
     c4c:      	fadd.4s	v3, v28, v4
     c50:      	fadd.4s	v2, v29, v2
     c54:      	movi.4s	v6, #0x2
     c58:      	eor.16b	v4, v16, v6
     c5c:      	fmov	w7, s4
     c60:      	add	x19, sp, #0x488
     c64:      	bfxil	x19, x7, #0, #3
     c68:      	ldrb	w19, [x19]
     c6c:      	and	x7, x7, #0x7
     c70:      	str	q2, [sp, #0x4e0]
     c74:      	str	q3, [sp, #0x4d0]
     c78:      	add	x30, sp, #0x4d0
     c7c:      	ldr	s4, [x30, x7, lsl #2]
     c80:      	eor.16b	v5, v5, v6
     c84:      	tst	w4, w19
     c88:      	fcsel	s4, s4, s30, ne
     c8c:      	fmov	w4, s5
     c90:      	and	x7, x4, #0x7
     c94:      	add	x19, sp, #0x488
     c98:      	bfxil	x19, x4, #0, #3
     c9c:      	ldrb	w4, [x19]
     ca0:      	str	q2, [sp, #0x4c0]
     ca4:      	str	q3, [sp, #0x4b0]
     ca8:      	add	x19, sp, #0x4b0
     cac:      	ldr	s5, [x19, x7, lsl #2]
     cb0:      	and	w4, w6, w4
     cb4:      	tst	w4, #0x1
     cb8:      	fcsel	s5, s5, s30, ne
     cbc:      	fadd.4s	v2, v2, v5
     cc0:      	and	w4, w16, w6
     cc4:      	tst	w4, #0x1
     cc8:      	fcsel	s2, s2, s30, ne
     ccc:      	ands	w7, w16, #0x1
     cd0:      	fadd.4s	v3, v3, v4
     cd4:      	fadd	s2, s3, s2
     cd8:      	fcsel	s3, s2, s30, ne
     cdc:      	tst	w4, #0x1
     ce0:      	sshll.2d	v4, v1, #0x0
     ce4:      	mov	w19, #0x20              ; =32
     ce8:      	dup.2d	v5, x19
     cec:      	and.16b	v6, v4, v5
     cf0:      	mov	w19, #0x40              ; =64
     cf4:      	dup.2d	v5, x19
     cf8:      	and.16b	v5, v4, v5
     cfc:      	mov	w19, #0x60              ; =96
     d00:      	dup.2d	v7, x19
     d04:      	and.16b	v4, v4, v7
     d08:      	and	w19, w1, w16
     d0c:      	fcsel	s7, s2, s30, ne
     d10:      	str	w19, [sp, #0xf0]
     d14:      	tst	w19, #0x1
     d18:      	and	w19, w17, w16
     d1c:      	fcsel	s16, s2, s30, ne
     d20:      	str	w19, [sp, #0xe0]
     d24:      	tst	w19, #0x1
     d28:      	and	w19, w0, w16
     d2c:      	fcsel	s18, s2, s30, ne
     d30:      	str	w19, [sp, #0xd0]
     d34:      	tst	w19, #0x1
     d38:      	fcsel	s19, s2, s30, ne
     d3c:      	and	w19, w5, w16
     d40:      	str	w19, [sp, #0xc0]
     d44:      	tst	w19, #0x1
     d48:      	fcsel	s22, s2, s30, ne
     d4c:      	and	w19, w2, w16
     d50:      	str	w19, [sp, #0xb0]
     d54:      	tst	w19, #0x1
     d58:      	fcsel	s24, s2, s30, ne
     d5c:      	and	w19, w3, w16
     d60:      	str	w19, [sp, #0x90]
     d64:      	tst	w19, #0x1
     d68:      	mov.s	v3[1], v16[0]
     d6c:      	mov.s	v3[2], v18[0]
     d70:      	mov.s	v3[3], v19[0]
     d74:      	mov.s	v7[1], v22[0]
     d78:      	fcsel	s2, s2, s30, ne
     d7c:      	mov.s	v7[2], v24[0]
     d80:      	mov.s	v7[3], v2[0]
     d84:      	ldr	w19, [sp, #0xa8]
     d88:      	rbit	w30, w19
     d8c:      	clz	w19, w30
     d90:      	str	q7, [sp, #0x4a0]
     d94:      	str	q3, [sp, #0x490]
     d98:      	str	x19, [sp, #0xa8]
     d9c:      	and	x30, x19, #0x7
     da0:      	add	x19, sp, #0x490
     da4:      	ldr	s2, [x19, x30, lsl #2]
     da8:      	fmov	x30, d6
     dac:      	add	x30, x27, x30
     db0:      	ldp	q3, q6, [x30]
     db4:      	fmov	x30, d5
     db8:      	add	x30, x27, x30
     dbc:      	ldp	q7, q16, [x30]
     dc0:      	fmov	x30, d4
     dc4:      	add	x30, x27, x30
     dc8:      	ldp	q4, q18, [x30]
     dcc:      	mov.16b	v27, v17
     dd0:      	mov.b	v27[0], wzr
     dd4:      	fadd	s2, s2, s30
     dd8:      	mov	w19, #0x800             ; =2048
     ddc:      	movk	w19, #0x4580, lsl #16
     de0:      	fmov	s5, w19
     de4:      	fdiv	s2, s2, s5
     de8:      	ldp	q5, q19, [x27]
     dec:      	and.16b	v19, v0, v19
     df0:      	and.16b	v22, v1, v5
     df4:      	dup.4s	v5, v2[0]
     df8:      	fsub.4s	v2, v22, v5
     dfc:      	fsub.4s	v19, v19, v5
     e00:      	ldr	q22, [x27, #0x4030]
     e04:      	bit.16b	v22, v19, v0
     e08:      	ldr	q24, [x27, #0x4020]
     e0c:      	bit.16b	v24, v2, v1
     e10:      	and.16b	v6, v0, v6
     e14:      	and.16b	v3, v1, v3
     e18:      	fsub.4s	v3, v3, v5
     e1c:      	fsub.4s	v6, v6, v5
     e20:      	str	q24, [x27, #0x4020]
     e24:      	str	q22, [x27, #0x4030]
     e28:      	ldr	q22, [x27, #0x4040]
     e2c:      	ldr	q24, [x27, #0x4050]
     e30:      	bit.16b	v24, v6, v0
     e34:      	bit.16b	v22, v3, v1
     e38:      	and.16b	v16, v0, v16
     e3c:      	and.16b	v7, v1, v7
     e40:      	fsub.4s	v7, v7, v5
     e44:      	fsub.4s	v16, v16, v5
     e48:      	ldr	q28, [x27, #0x4060]
     e4c:      	ldr	q29, [x27, #0x4070]
     e50:      	mov.16b	v30, v0
     e54:      	bsl.16b	v30, v16, v29
     e58:      	mov.16b	v31, v1
     e5c:      	bsl.16b	v31, v7, v28
     e60:      	and.16b	v18, v0, v18
     e64:      	and.16b	v4, v1, v4
     e68:      	fsub.4s	v4, v4, v5
     e6c:      	fsub.4s	v18, v18, v5
     e70:      	ldr	q28, [x27, #0x4090]
     e74:      	mov.16b	v8, v0
     e78:      	bsl.16b	v8, v18, v28
     e7c:      	ldr	q28, [x27, #0x4080]
     e80:      	mov.16b	v9, v1
     e84:      	bsl.16b	v9, v4, v28
     e88:      	fmul.4s	v4, v4, v4
     e8c:      	fmul.4s	v18, v18, v18
     e90:      	and.16b	v28, v0, v18
     e94:      	and.16b	v29, v1, v4
     e98:      	str	q22, [x27, #0x4040]
     e9c:      	str	q24, [x27, #0x4050]
     ea0:      	str	q31, [x27, #0x4060]
     ea4:      	str	q30, [x27, #0x4070]
     ea8:      	str	q9, [x27, #0x4080]
     eac:      	str	q8, [x27, #0x4090]
     eb0:      	fmul.4s	v4, v7, v7
     eb4:      	fmul.4s	v7, v16, v16
     eb8:      	and.16b	v31, v0, v7
     ebc:      	and.16b	v30, v1, v4
     ec0:      	fmul.4s	v3, v3, v3
     ec4:      	fmul.4s	v4, v6, v6
     ec8:      	and.16b	v9, v0, v4
     ecc:      	and.16b	v10, v1, v3
     ed0:      	fmul.4s	v2, v2, v2
     ed4:      	fmul.4s	v3, v19, v19
     ed8:      	and.16b	v12, v0, v3
     edc:      	and.16b	v11, v1, v2
     ee0:      	sshll.2d	v4, v1, #0x0
     ee4:      	sshll.2d	v6, v0, #0x0
     ee8:      	lsl	x8, x8, #5
     eec:      	add	x30, x27, x8
     ef0:      	ldp	q2, q3, [x30]
     ef4:      	and.16b	v3, v0, v3
     ef8:      	and.16b	v2, v1, v2
     efc:      	fsub.4s	v2, v2, v5
     f00:      	fsub.4s	v3, v3, v5
     f04:      	add	x30, x11, x8
     f08:      	ldp	q7, q16, [x30]
     f0c:      	bit.16b	v16, v3, v0
     f10:      	bit.16b	v7, v2, v1
     f14:      	stp	q7, q16, [x30]
     f18:      	fmul.4s	v3, v3, v3
     f1c:      	fmul.4s	v2, v2, v2
     f20:      	fadd.4s	v15, v11, v2
     f24:      	fadd.4s	v16, v12, v3
     f28:      	add	x30, x8, #0x20
     f2c:      	add	x19, x27, x30
     f30:      	ldp	q2, q3, [x19]
     f34:      	and.16b	v3, v0, v3
     f38:      	and.16b	v2, v1, v2
     f3c:      	fsub.4s	v2, v2, v5
     f40:      	fsub.4s	v3, v3, v5
     f44:      	add	x19, x11, x30
     f48:      	ldp	q7, q18, [x19]
     f4c:      	bit.16b	v18, v3, v0
     f50:      	bit.16b	v7, v2, v1
     f54:      	stp	q7, q18, [x19]
     f58:      	fmul.4s	v3, v3, v3
     f5c:      	fmul.4s	v2, v2, v2
     f60:      	fadd.4s	v2, v10, v2
     f64:      	fadd.4s	v3, v9, v3
     f68:      	add	x19, x8, #0x40
     f6c:      	add	x30, x27, x19
     f70:      	ldp	q7, q18, [x30]
     f74:      	and.16b	v18, v0, v18
     f78:      	and.16b	v7, v1, v7
     f7c:      	fsub.4s	v7, v7, v5
     f80:      	fsub.4s	v18, v18, v5
     f84:      	add	x19, x11, x19
     f88:      	ldp	q19, q22, [x19]
     f8c:      	bit.16b	v22, v18, v0
     f90:      	bit.16b	v19, v7, v1
     f94:      	stp	q19, q22, [x19]
     f98:      	fmul.4s	v18, v18, v18
     f9c:      	fmul.4s	v7, v7, v7
     fa0:      	fadd.4s	v7, v30, v7
     fa4:      	fadd.4s	v18, v31, v18
     fa8:      	add	x8, x8, #0x60
     fac:      	add	x19, x27, x8
     fb0:      	ldp	q19, q22, [x19]
     fb4:      	and.16b	v22, v0, v22
     fb8:      	and.16b	v19, v1, v19
     fbc:      	fsub.4s	v19, v19, v5
     fc0:      	fsub.4s	v22, v22, v5
     fc4:      	add	x8, x11, x8
     fc8:      	ldp	q24, q8, [x8]
     fcc:      	bit.16b	v8, v22, v0
     fd0:      	bit.16b	v24, v19, v1
     fd4:      	stp	q24, q8, [x8]
     fd8:      	fmul.4s	v22, v22, v22
     fdc:      	fmul.4s	v19, v19, v19
     fe0:      	fadd.4s	v19, v29, v19
     fe4:      	fadd.4s	v22, v28, v22
     fe8:      	dup.2d	v24, x26
     fec:      	and.16b	v8, v21, v24
     ff0:      	add.2d	v26, v26, v8
     ff4:      	and.16b	v8, v20, v24
     ff8:      	add.2d	v23, v23, v8
     ffc:      	and.16b	v6, v6, v24
    1000:      	add.2d	v25, v25, v6
    1004:      	and.16b	v4, v4, v24
    1008:      	add.2d	v14, v14, v4
    100c:      	bit.16b	v12, v16, v0
    1010:      	bit.16b	v11, v15, v1
    1014:      	bit.16b	v9, v3, v0
    1018:      	bit.16b	v10, v2, v1
    101c:      	bit.16b	v31, v18, v0
    1020:      	bit.16b	v30, v7, v1
    1024:      	bit.16b	v28, v22, v0
    1028:      	bit.16b	v29, v19, v1
    102c:      	fmov	x8, d14
    1030:      	cmp	x8, #0x200
    1034:      	b.lt	0xee0 <_llm_rows.packet_batch.blocks+0xb14>
    1038:      	mov	x8, #0x0                ; =0
    103c:      	add	x19, x27, x14
    1040:      	ldp	q2, q3, [x19]
    1044:      	ldr	q25, [sp, #0x180]
    1048:      	zip2.8b	v4, v25, v0
    104c:      	ushll.4s	v4, v4, #0x0
    1050:      	shl.4s	v4, v4, #0x1f
    1054:      	cmlt.4s	v4, v4, #0
    1058:      	and.16b	v3, v4, v3
    105c:      	zip1.8b	v6, v25, v0
    1060:      	ushll.4s	v6, v6, #0x0
    1064:      	shl.4s	v6, v6, #0x1f
    1068:      	cmlt.4s	v6, v6, #0
    106c:      	and.16b	v2, v6, v2
    1070:      	fsub.4s	v13, v2, v5
    1074:      	fsub.4s	v14, v3, v5
    1078:      	add	x19, x11, x14
    107c:      	ldp	q2, q3, [x19]
    1080:      	bit.16b	v3, v14, v4
    1084:      	bit.16b	v2, v13, v6
    1088:      	stp	q2, q3, [x19]
    108c:      	mov	w19, #0x1               ; =1
    1090:      	dup.2d	v2, x19
    1094:      	ushll2.2d	v3, v0, #0x0
    1098:      	and.16b	v20, v3, v2
    109c:      	ushll2.2d	v3, v1, #0x0
    10a0:      	and.16b	v21, v3, v2
    10a4:      	ushll.2d	v3, v0, #0x0
    10a8:      	and.16b	v22, v3, v2
    10ac:      	ushll.2d	v3, v1, #0x0
    10b0:      	and.16b	v23, v3, v2
    10b4:      	movi.2d	v5, #0000000000000000
    10b8:      	movi.2d	v6, #0000000000000000
    10bc:      	movi.2d	v7, #0000000000000000
    10c0:      	movi.2d	v4, #0000000000000000
    10c4:      	ldr	q8, [sp, #0x160]
    10c8:      	b	0x10fc <_llm_rows.packet_batch.blocks+0xd30>
    10cc:      	add	x8, x10, x8
    10d0:      	ldp	q2, q3, [x8]
    10d4:      	bit.16b	v3, v19, v0
    10d8:      	bit.16b	v2, v18, v1
    10dc:      	stp	q2, q3, [x8]
    10e0:      	add.2d	v6, v6, v21
    10e4:      	add.2d	v7, v7, v22
    10e8:      	add.2d	v4, v4, v20
    10ec:      	add.2d	v5, v5, v23
    10f0:      	fmov	x8, d5
    10f4:      	cmp	x8, #0x200
    10f8:      	b.ge	0x1198 <_llm_rows.packet_batch.blocks+0xdcc>
    10fc:      	fmov	w30, s8
    1100:      	lsl	x8, x8, #5
    1104:      	add	x27, x15, x8
    1108:      	movi.2d	v18, #0000000000000000
    110c:      	movi.2d	v19, #0000000000000000
    1110:      	tbnz	w30, #0x0, 0x1138 <_llm_rows.packet_batch.blocks+0xd6c>
    1114:      	and	w30, w30, #0xff
    1118:      	tbnz	w30, #0x1, 0x1144 <_llm_rows.packet_batch.blocks+0xd78>
    111c:      	tbnz	w30, #0x2, 0x1150 <_llm_rows.packet_batch.blocks+0xd84>
    1120:      	tbnz	w30, #0x3, 0x115c <_llm_rows.packet_batch.blocks+0xd90>
    1124:      	tbnz	w30, #0x4, 0x1168 <_llm_rows.packet_batch.blocks+0xd9c>
    1128:      	tbnz	w30, #0x5, 0x1174 <_llm_rows.packet_batch.blocks+0xda8>
    112c:      	tbnz	w30, #0x6, 0x1180 <_llm_rows.packet_batch.blocks+0xdb4>
    1130:      	tbz	w30, #0x7, 0x10cc <_llm_rows.packet_batch.blocks+0xd00>
    1134:      	b	0x118c <_llm_rows.packet_batch.blocks+0xdc0>
    1138:      	ldr	s18, [x27]
    113c:      	and	w30, w30, #0xff
    1140:      	tbz	w30, #0x1, 0x111c <_llm_rows.packet_batch.blocks+0xd50>
    1144:      	add	x19, x27, #0x4
    1148:      	ld1.s	{ v18 }[1], [x19]
    114c:      	tbz	w30, #0x2, 0x1120 <_llm_rows.packet_batch.blocks+0xd54>
    1150:      	add	x19, x27, #0x8
    1154:      	ld1.s	{ v18 }[2], [x19]
    1158:      	tbz	w30, #0x3, 0x1124 <_llm_rows.packet_batch.blocks+0xd58>
    115c:      	add	x19, x27, #0xc
    1160:      	ld1.s	{ v18 }[3], [x19]
    1164:      	tbz	w30, #0x4, 0x1128 <_llm_rows.packet_batch.blocks+0xd5c>
    1168:      	add	x19, x27, #0x10
    116c:      	ld1.s	{ v19 }[0], [x19]
    1170:      	tbz	w30, #0x5, 0x112c <_llm_rows.packet_batch.blocks+0xd60>
    1174:      	add	x19, x27, #0x14
    1178:      	ld1.s	{ v19 }[1], [x19]
    117c:      	tbz	w30, #0x6, 0x1130 <_llm_rows.packet_batch.blocks+0xd64>
    1180:      	add	x19, x27, #0x18
    1184:      	ld1.s	{ v19 }[2], [x19]
    1188:      	tbz	w30, #0x7, 0x10cc <_llm_rows.packet_batch.blocks+0xd00>
    118c:      	add	x19, x27, #0x1c
    1190:      	ld1.s	{ v19 }[3], [x19]
    1194:      	b	0x10cc <_llm_rows.packet_batch.blocks+0xd00>
    1198:      	mov	b2, v25[0]
    119c:      	mov.b	v2[4], v25[1]
    11a0:      	ushll.2d	v2, v2, #0x0
    11a4:      	shl.2d	v2, v2, #0x3f
    11a8:      	cmlt.2d	v2, v2, #0
    11ac:      	mov	b3, v25[2]
    11b0:      	mov.b	v3[4], v25[3]
    11b4:      	ldp	q6, q4, [sp, #0x70]
    11b8:      	and.16b	v2, v2, v4
    11bc:      	ushll.2d	v3, v3, #0x0
    11c0:      	shl.2d	v3, v3, #0x3f
    11c4:      	cmlt.2d	v3, v3, #0
    11c8:      	ldp	q4, q5, [sp, #0x50]
    11cc:      	and.16b	v3, v3, v4
    11d0:      	mov	b4, v25[4]
    11d4:      	mov.b	v4[4], v25[5]
    11d8:      	ushll.2d	v4, v4, #0x0
    11dc:      	shl.2d	v4, v4, #0x3f
    11e0:      	cmlt.2d	v4, v4, #0
    11e4:      	and.16b	v4, v4, v5
    11e8:      	mov	b5, v25[6]
    11ec:      	mov.b	v5[4], v25[7]
    11f0:      	ushll.2d	v5, v5, #0x0
    11f4:      	shl.2d	v5, v5, #0x3f
    11f8:      	cmlt.2d	v5, v5, #0
    11fc:      	and.16b	v5, v5, v6
    1200:      	shl.8b	v6, v25, #0x7
    1204:      	cmlt.8b	v6, v6, #0
    1208:      	ldr	d7, [sp, #0x108]
    120c:      	and.8b	v6, v6, v7
    1210:      	addv.8b	b18, v6
    1214:      	str	q5, [sp, #0x470]
    1218:      	str	q4, [sp, #0x460]
    121c:      	str	q3, [sp, #0x450]
    1220:      	str	q2, [sp, #0x440]
    1224:      	and	x8, x12, #0x7
    1228:      	add	x19, sp, #0x440
    122c:      	ldr	x19, [x19, x8, lsl #3]
    1230:      	fmov	w8, s18
    1234:      	sub	x19, x19, x12
    1238:      	lsl	x27, x19, #2
    123c:      	add	x15, x15, x27
    1240:      	movi.2d	v4, #0000000000000000
    1244:      	movi.2d	v5, #0000000000000000
    1248:      	tbnz	w8, #0x0, 0x1a8c <_llm_rows.packet_batch.blocks+0x16c0>
    124c:      	tbnz	w8, #0x1, 0x1a94 <_llm_rows.packet_batch.blocks+0x16c8>
    1250:      	tbnz	w8, #0x2, 0x1aa0 <_llm_rows.packet_batch.blocks+0x16d4>
    1254:      	tbnz	w8, #0x3, 0x1aac <_llm_rows.packet_batch.blocks+0x16e0>
    1258:      	tbnz	w8, #0x4, 0x1ab8 <_llm_rows.packet_batch.blocks+0x16ec>
    125c:      	tbnz	w8, #0x5, 0x1ac4 <_llm_rows.packet_batch.blocks+0x16f8>
    1260:      	tbnz	w8, #0x6, 0x1ad0 <_llm_rows.packet_batch.blocks+0x1704>
    1264:      	tbz	w8, #0x7, 0x1270 <_llm_rows.packet_batch.blocks+0xea4>
    1268:      	add	x8, x15, #0x1c
    126c:      	ld1.s	{ v5 }[3], [x8]
    1270:      	mov	x8, #0x0                ; =0
    1274:      	add	x15, x10, x14
    1278:      	ldp	q2, q3, [x15]
    127c:      	zip2.8b	v6, v25, v0
    1280:      	ushll.4s	v6, v6, #0x0
    1284:      	shl.4s	v6, v6, #0x1f
    1288:      	cmlt.4s	v6, v6, #0
    128c:      	bit.16b	v3, v5, v6
    1290:      	zip1.8b	v5, v25, v0
    1294:      	ushll.4s	v5, v5, #0x0
    1298:      	shl.4s	v5, v5, #0x1f
    129c:      	cmlt.4s	v5, v5, #0
    12a0:      	bit.16b	v2, v4, v5
    12a4:      	stp	q2, q3, [x15]
    12a8:      	movi.2d	v5, #0000000000000000
    12ac:      	movi.2d	v6, #0000000000000000
    12b0:      	movi.2d	v7, #0000000000000000
    12b4:      	movi.2d	v4, #0000000000000000
    12b8:      	b	0x12ec <_llm_rows.packet_batch.blocks+0xf20>
    12bc:      	add	x8, x9, x8
    12c0:      	ldp	q2, q3, [x8]
    12c4:      	bit.16b	v3, v24, v0
    12c8:      	bit.16b	v2, v19, v1
    12cc:      	stp	q2, q3, [x8]
    12d0:      	add.2d	v6, v6, v21
    12d4:      	add.2d	v7, v7, v22
    12d8:      	add.2d	v4, v4, v20
    12dc:      	add.2d	v5, v5, v23
    12e0:      	fmov	x8, d5
    12e4:      	cmp	x8, #0x200
    12e8:      	b.ge	0x1388 <_llm_rows.packet_batch.blocks+0xfbc>
    12ec:      	fmov	w30, s8
    12f0:      	lsl	x8, x8, #5
    12f4:      	add	x15, x13, x8
    12f8:      	movi.2d	v19, #0000000000000000
    12fc:      	movi.2d	v24, #0000000000000000
    1300:      	tbnz	w30, #0x0, 0x1328 <_llm_rows.packet_batch.blocks+0xf5c>
    1304:      	and	w30, w30, #0xff
    1308:      	tbnz	w30, #0x1, 0x1334 <_llm_rows.packet_batch.blocks+0xf68>
    130c:      	tbnz	w30, #0x2, 0x1340 <_llm_rows.packet_batch.blocks+0xf74>
    1310:      	tbnz	w30, #0x3, 0x134c <_llm_rows.packet_batch.blocks+0xf80>
    1314:      	tbnz	w30, #0x4, 0x1358 <_llm_rows.packet_batch.blocks+0xf8c>
    1318:      	tbnz	w30, #0x5, 0x1364 <_llm_rows.packet_batch.blocks+0xf98>
    131c:      	tbnz	w30, #0x6, 0x1370 <_llm_rows.packet_batch.blocks+0xfa4>
    1320:      	tbz	w30, #0x7, 0x12bc <_llm_rows.packet_batch.blocks+0xef0>
    1324:      	b	0x137c <_llm_rows.packet_batch.blocks+0xfb0>
    1328:      	ldr	s19, [x15]
    132c:      	and	w30, w30, #0xff
    1330:      	tbz	w30, #0x1, 0x130c <_llm_rows.packet_batch.blocks+0xf40>
    1334:      	add	x19, x15, #0x4
    1338:      	ld1.s	{ v19 }[1], [x19]
    133c:      	tbz	w30, #0x2, 0x1310 <_llm_rows.packet_batch.blocks+0xf44>
    1340:      	add	x19, x15, #0x8
    1344:      	ld1.s	{ v19 }[2], [x19]
    1348:      	tbz	w30, #0x3, 0x1314 <_llm_rows.packet_batch.blocks+0xf48>
    134c:      	add	x19, x15, #0xc
    1350:      	ld1.s	{ v19 }[3], [x19]
    1354:      	tbz	w30, #0x4, 0x1318 <_llm_rows.packet_batch.blocks+0xf4c>
    1358:      	add	x19, x15, #0x10
    135c:      	ld1.s	{ v24 }[0], [x19]
    1360:      	tbz	w30, #0x5, 0x131c <_llm_rows.packet_batch.blocks+0xf50>
    1364:      	add	x19, x15, #0x14
    1368:      	ld1.s	{ v24 }[1], [x19]
    136c:      	tbz	w30, #0x6, 0x1320 <_llm_rows.packet_batch.blocks+0xf54>
    1370:      	add	x19, x15, #0x18
    1374:      	ld1.s	{ v24 }[2], [x19]
    1378:      	tbz	w30, #0x7, 0x12bc <_llm_rows.packet_batch.blocks+0xef0>
    137c:      	add	x15, x15, #0x1c
    1380:      	ld1.s	{ v24 }[3], [x15]
    1384:      	b	0x12bc <_llm_rows.packet_batch.blocks+0xef0>
    1388:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0xc34>
    138c:      	ldr	q2, [x8]
    1390:      	and.16b	v5, v0, v2
    1394:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0xc34>
    1398:      	ldr	q2, [x8]
    139c:      	and.16b	v19, v1, v2
    13a0:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0xc34>
    13a4:      	ldr	q4, [x8]
    13a8:      	fmul.4s	v2, v13, v13
    13ac:      	fmul.4s	v3, v14, v14
    13b0:      	fadd.4s	v3, v12, v3
    13b4:      	fadd.4s	v2, v11, v2
    13b8:      	zip1.8b	v6, v25, v0
    13bc:      	ushll.4s	v6, v6, #0x0
    13c0:      	shl.4s	v6, v6, #0x1f
    13c4:      	cmlt.4s	v6, v6, #0
    13c8:      	and.16b	v2, v6, v2
    13cc:      	zip2.8b	v6, v25, v0
    13d0:      	ushll.4s	v6, v6, #0x0
    13d4:      	shl.4s	v6, v6, #0x1f
    13d8:      	cmlt.4s	v6, v6, #0
    13dc:      	and.16b	v3, v6, v3
    13e0:      	zip2.8b	v6, v27, v0
    13e4:      	ushll.4s	v6, v6, #0x0
    13e8:      	shl.4s	v6, v6, #0x1f
    13ec:      	cmlt.4s	v6, v6, #0
    13f0:      	bit.16b	v3, v16, v6
    13f4:      	zip1.8b	v6, v27, v0
    13f8:      	ushll.4s	v6, v6, #0x0
    13fc:      	shl.4s	v6, v6, #0x1f
    1400:      	cmlt.4s	v6, v6, #0
    1404:      	bit.16b	v2, v15, v6
    1408:      	fadd.4s	v2, v10, v2
    140c:      	fadd.4s	v3, v9, v3
    1410:      	fadd.4s	v3, v31, v3
    1414:      	fadd.4s	v2, v30, v2
    1418:      	fadd.4s	v6, v29, v2
    141c:      	fadd.4s	v7, v28, v3
    1420:      	fmov	w8, s19
    1424:      	add	x15, sp, #0x1e8
    1428:      	bfxil	x15, x8, #0, #3
    142c:      	str	d17, [sp, #0x1e8]
    1430:      	ldrb	w15, [x15]
    1434:      	add	x19, sp, #0x410
    1438:      	orr	x8, x19, x8, lsl #2
    143c:      	str	q7, [sp, #0x420]
    1440:      	str	q6, [sp, #0x410]
    1444:      	ldr	s2, [x8]
    1448:      	tst	w7, w15
    144c:      	movi	d26, #0000000000000000
    1450:      	fcsel	s16, s2, s26, ne
    1454:      	mov.s	w8, v19[1]
    1458:      	add	x15, sp, #0x1e8
    145c:      	bfxil	x15, x8, #0, #3
    1460:      	ldrb	w8, [x15]
    1464:      	and	w8, w1, w8
    1468:      	str	q6, [sp, #0x3f0]
    146c:      	ldr	s2, [sp, #0x3f0]
    1470:      	tst	w8, #0x1
    1474:      	mov.s	w8, v19[2]
    1478:      	fcsel	s17, s2, s26, ne
    147c:      	add	x15, sp, #0x1e8
    1480:      	bfxil	x15, x8, #0, #3
    1484:      	add	x19, sp, #0x3d0
    1488:      	orr	x8, x19, x8, lsl #2
    148c:      	ldrb	w15, [x15]
    1490:      	and	w15, w17, w15
    1494:      	stp	q6, q7, [sp, #0x3d0]
    1498:      	ldr	s2, [x8]
    149c:      	tst	w15, #0x1
    14a0:      	mov.s	w8, v19[3]
    14a4:      	fcsel	s19, s2, s26, ne
    14a8:      	add	x15, sp, #0x1e8
    14ac:      	bfxil	x15, x8, #0, #3
    14b0:      	add	x19, sp, #0x3b0
    14b4:      	orr	x8, x19, x8, lsl #2
    14b8:      	ldrb	w15, [x15]
    14bc:      	and	w15, w0, w15
    14c0:      	stp	q6, q7, [sp, #0x3b0]
    14c4:      	ldr	s2, [x8]
    14c8:      	tst	w15, #0x1
    14cc:      	fcsel	s24, s2, s26, ne
    14d0:      	fmov	w8, s5
    14d4:      	add	x15, sp, #0x1e8
    14d8:      	bfxil	x15, x8, #0, #3
    14dc:      	ldrb	w15, [x15]
    14e0:      	and	w15, w6, w15
    14e4:      	stp	q6, q7, [sp, #0x390]
    14e8:      	add	x19, sp, #0x390
    14ec:      	ldr	s2, [x19, w8, uxtw #2]
    14f0:      	tst	w15, #0x1
    14f4:      	fcsel	s2, s2, s26, ne
    14f8:      	mov.s	w8, v5[1]
    14fc:      	add	x15, sp, #0x1e8
    1500:      	bfxil	x15, x8, #0, #3
    1504:      	ldrb	w15, [x15]
    1508:      	and	w15, w5, w15
    150c:      	stp	q6, q7, [sp, #0x370]
    1510:      	add	x19, sp, #0x370
    1514:      	ldr	s3, [x19, w8, uxtw #2]
    1518:      	tst	w15, #0x1
    151c:      	fcsel	s3, s3, s26, ne
    1520:      	mov.s	w8, v5[2]
    1524:      	add	x15, sp, #0x1e8
    1528:      	bfxil	x15, x8, #0, #3
    152c:      	ldrb	w15, [x15]
    1530:      	and	w15, w2, w15
    1534:      	stp	q6, q7, [sp, #0x350]
    1538:      	add	x19, sp, #0x350
    153c:      	ldr	s25, [x19, w8, uxtw #2]
    1540:      	tst	w15, #0x1
    1544:      	fcsel	s25, s25, s26, ne
    1548:      	mov.s	w8, v5[3]
    154c:      	add	x15, sp, #0x1e8
    1550:      	bfxil	x15, x8, #0, #3
    1554:      	ldrb	w15, [x15]
    1558:      	and	w15, w3, w15
    155c:      	stp	q6, q7, [sp, #0x330]
    1560:      	add	x19, sp, #0x330
    1564:      	ldr	s5, [x19, w8, uxtw #2]
    1568:      	tst	w15, #0x1
    156c:      	fcsel	s5, s5, s26, ne
    1570:      	mov.s	v2[1], v3[0]
    1574:      	mov.s	v2[2], v25[0]
    1578:      	mov.s	v2[3], v5[0]
    157c:      	mov.s	v16[1], v17[0]
    1580:      	and.16b	v3, v1, v4
    1584:      	mov.s	v16[2], v19[0]
    1588:      	mov.s	v16[3], v24[0]
    158c:      	fadd.4s	v4, v6, v16
    1590:      	fadd.4s	v5, v7, v2
    1594:      	fmov	w8, s3
    1598:      	add	x15, sp, #0x1e8
    159c:      	bfxil	x15, x8, #0, #3
    15a0:      	ldrb	w15, [x15]
    15a4:      	add	x19, sp, #0x310
    15a8:      	orr	x8, x19, x8, lsl #2
    15ac:      	stp	q4, q5, [sp, #0x310]
    15b0:      	ldr	s2, [x8]
    15b4:      	tst	w7, w15
    15b8:      	mov.s	w8, v3[1]
    15bc:      	add	x15, sp, #0x1e8
    15c0:      	bfxil	x15, x8, #0, #3
    15c4:      	ldrb	w15, [x15]
    15c8:      	and	w15, w1, w15
    15cc:      	fcsel	s6, s2, s26, ne
    15d0:      	add	x1, sp, #0x2f0
    15d4:      	orr	x8, x1, x8, lsl #2
    15d8:      	stp	q4, q5, [sp, #0x2f0]
    15dc:      	ldr	s2, [x8]
    15e0:      	tst	w15, #0x1
    15e4:      	mov.s	w8, v3[2]
    15e8:      	add	x15, sp, #0x1e8
    15ec:      	bfxil	x15, x8, #0, #3
    15f0:      	fcsel	s7, s2, s26, ne
    15f4:      	ldrb	w8, [x15]
    15f8:      	and	w8, w17, w8
    15fc:      	str	q4, [sp, #0x2d0]
    1600:      	tst	w8, #0x1
    1604:      	mov.s	w8, v3[3]
    1608:      	add	x15, sp, #0x1e8
    160c:      	bfxil	x15, x8, #0, #3
    1610:      	ldrb	w15, [x15]
    1614:      	and	w15, w0, w15
    1618:      	adrp	x17, 0x1000 <_llm_rows.packet_batch.blocks+0xc34>
    161c:      	ldr	q2, [x17]
    1620:      	and.16b	v2, v0, v2
    1624:      	ldr	s3, [sp, #0x2d0]
    1628:      	fcsel	s17, s3, s26, ne
    162c:      	add	x17, sp, #0x2b0
    1630:      	orr	x8, x17, x8, lsl #2
    1634:      	stp	q4, q5, [sp, #0x2b0]
    1638:      	ldr	s3, [x8]
    163c:      	tst	w15, #0x1
    1640:      	fmov	w8, s2
    1644:      	add	x15, sp, #0x1e8
    1648:      	bfxil	x15, x8, #0, #3
    164c:      	ldrb	w15, [x15]
    1650:      	and	w15, w6, w15
    1654:      	fcsel	s16, s3, s26, ne
    1658:      	stp	q4, q5, [sp, #0x290]
    165c:      	add	x17, sp, #0x290
    1660:      	ldr	s3, [x17, w8, uxtw #2]
    1664:      	tst	w15, #0x1
    1668:      	mov.s	w8, v2[1]
    166c:      	add	x15, sp, #0x1e8
    1670:      	bfxil	x15, x8, #0, #3
    1674:      	ldrb	w15, [x15]
    1678:      	and	w15, w5, w15
    167c:      	fcsel	s3, s3, s26, ne
    1680:      	stp	q4, q5, [sp, #0x270]
    1684:      	add	x17, sp, #0x270
    1688:      	ldr	s19, [x17, w8, uxtw #2]
    168c:      	tst	w15, #0x1
    1690:      	mov.s	w8, v2[2]
    1694:      	add	x15, sp, #0x1e8
    1698:      	bfxil	x15, x8, #0, #3
    169c:      	ldrb	w15, [x15]
    16a0:      	and	w15, w2, w15
    16a4:      	fcsel	s19, s19, s26, ne
    16a8:      	stp	q4, q5, [sp, #0x250]
    16ac:      	add	x17, sp, #0x250
    16b0:      	ldr	s24, [x17, w8, uxtw #2]
    16b4:      	tst	w15, #0x1
    16b8:      	mov.s	w8, v2[3]
    16bc:      	add	x15, sp, #0x1e8
    16c0:      	bfxil	x15, x8, #0, #3
    16c4:      	ldrb	w15, [x15]
    16c8:      	and	w15, w3, w15
    16cc:      	fcsel	s2, s24, s26, ne
    16d0:      	stp	q4, q5, [sp, #0x230]
    16d4:      	add	x17, sp, #0x230
    16d8:      	ldr	s24, [x17, w8, uxtw #2]
    16dc:      	tst	w15, #0x1
    16e0:      	fcsel	s24, s24, s26, ne
    16e4:      	mov.s	v3[1], v19[0]
    16e8:      	mov.s	v3[2], v2[0]
    16ec:      	mov.s	v3[3], v24[0]
    16f0:      	mov.s	v6[1], v7[0]
    16f4:      	movi.4s	v2, #0x4
    16f8:      	and.16b	v2, v1, v2
    16fc:      	mov.s	v6[2], v17[0]
    1700:      	fmov	w8, s2
    1704:      	add	x15, sp, #0x1e8
    1708:      	orr	x15, x15, x8
    170c:      	ldrb	w15, [x15]
    1710:      	tst	w7, w15
    1714:      	mov.s	v6[3], v16[0]
    1718:      	fadd.4s	v2, v4, v6
    171c:      	fadd.4s	v3, v5, v3
    1720:      	stp	q2, q3, [sp, #0x210]
    1724:      	add	x15, sp, #0x210
    1728:      	ldr	s3, [x15, w8, uxtw #2]
    172c:      	fcsel	s3, s3, s26, ne
    1730:      	tst	w16, #0x1
    1734:      	fadd	s2, s2, s3
    1738:      	fcsel	s3, s2, s26, ne
    173c:      	ldr	w8, [sp, #0xf0]
    1740:      	tst	w8, #0x1
    1744:      	fcsel	s4, s2, s26, ne
    1748:      	ldr	w8, [sp, #0xe0]
    174c:      	tst	w8, #0x1
    1750:      	fcsel	s5, s2, s26, ne
    1754:      	ldr	w8, [sp, #0xd0]
    1758:      	tst	w8, #0x1
    175c:      	fcsel	s6, s2, s26, ne
    1760:      	tst	w4, #0x1
    1764:      	fcsel	s7, s2, s26, ne
    1768:      	ldr	w8, [sp, #0xc0]
    176c:      	tst	w8, #0x1
    1770:      	fcsel	s16, s2, s26, ne
    1774:      	ldr	w8, [sp, #0xb0]
    1778:      	tst	w8, #0x1
    177c:      	fcsel	s17, s2, s26, ne
    1780:      	ldr	w8, [sp, #0x90]
    1784:      	tst	w8, #0x1
    1788:      	mov.s	v3[1], v4[0]
    178c:      	mov.s	v3[2], v5[0]
    1790:      	mov.s	v3[3], v6[0]
    1794:      	mov.s	v7[1], v16[0]
    1798:      	mov.s	v7[2], v17[0]
    179c:      	movi	d16, #0000000000000000
    17a0:      	fcsel	s2, s2, s26, ne
    17a4:      	mov.s	v7[3], v2[0]
    17a8:      	stp	q3, q7, [sp, #0x1f0]
    17ac:      	ldr	x8, [sp, #0xa8]
    17b0:      	and	x8, x8, #0x7
    17b4:      	add	x15, sp, #0x1f0
    17b8:      	ldr	s6, [x15, x8, lsl #2]
    17bc:      	add	x8, x13, x27
    17c0:      	fmov	w13, s18
    17c4:      	movi.2d	v4, #0000000000000000
    17c8:      	movi.2d	v5, #0000000000000000
    17cc:      	tbnz	w13, #0x0, 0x1ae0 <_llm_rows.packet_batch.blocks+0x1714>
    17d0:      	ldr	x17, [sp, #0x170]
    17d4:      	tbnz	w13, #0x1, 0x1aec <_llm_rows.packet_batch.blocks+0x1720>
    17d8:      	ldr	q26, [sp, #0x180]
    17dc:      	tbnz	w13, #0x2, 0x1afc <_llm_rows.packet_batch.blocks+0x1730>
    17e0:      	tbnz	w13, #0x3, 0x1b08 <_llm_rows.packet_batch.blocks+0x173c>
    17e4:      	tbnz	w13, #0x4, 0x1b14 <_llm_rows.packet_batch.blocks+0x1748>
    17e8:      	tbnz	w13, #0x5, 0x1b20 <_llm_rows.packet_batch.blocks+0x1754>
    17ec:      	tbnz	w13, #0x6, 0x1b2c <_llm_rows.packet_batch.blocks+0x1760>
    17f0:      	tbz	w13, #0x7, 0x17fc <_llm_rows.packet_batch.blocks+0x1430>
    17f4:      	add	x8, x8, #0x1c
    17f8:      	ld1.s	{ v5 }[3], [x8]
    17fc:      	mov	x13, #0x0               ; =0
    1800:      	fadd	s2, s6, s16
    1804:      	mov	w8, #0x800              ; =2048
    1808:      	movk	w8, #0x4580, lsl #16
    180c:      	fmov	s3, w8
    1810:      	fdiv	s2, s2, s3
    1814:      	mov	w8, #0xc5ac             ; =50604
    1818:      	movk	w8, #0x3727, lsl #16
    181c:      	fmov	s3, w8
    1820:      	fadd	s2, s2, s3
    1824:      	fsqrt	s2, s2
    1828:      	add	x8, x9, x14
    182c:      	ldp	q3, q6, [x8]
    1830:      	zip2.8b	v7, v26, v0
    1834:      	ushll.4s	v7, v7, #0x0
    1838:      	shl.4s	v7, v7, #0x1f
    183c:      	cmlt.4s	v7, v7, #0
    1840:      	bif.16b	v5, v6, v7
    1844:      	zip1.8b	v6, v26, v0
    1848:      	ushll.4s	v6, v6, #0x0
    184c:      	shl.4s	v6, v6, #0x1f
    1850:      	cmlt.4s	v6, v6, #0
    1854:      	bit.16b	v3, v4, v6
    1858:      	stp	q3, q5, [x8]
    185c:      	dup.4s	v5, v2[0]
    1860:      	ldr	q2, [sp, #0x110]
    1864:      	fmov	x8, d2
    1868:      	add	x8, x17, x8, lsl #2
    186c:      	movi.2d	v4, #0000000000000000
    1870:      	movi.2d	v6, #0000000000000000
    1874:      	movi.2d	v7, #0000000000000000
    1878:      	movi.2d	v16, #0000000000000000
    187c:      	b	0x189c <_llm_rows.packet_batch.blocks+0x14d0>
    1880:      	add.2d	v6, v6, v21
    1884:      	add.2d	v7, v7, v22
    1888:      	add.2d	v16, v16, v20
    188c:      	add.2d	v4, v4, v23
    1890:      	fmov	x13, d4
    1894:      	cmp	x13, #0x200
    1898:      	b.ge	0x1974 <_llm_rows.packet_batch.blocks+0x15a8>
    189c:      	fmov	w15, s8
    18a0:      	lsl	x13, x13, #5
    18a4:      	add	x16, x11, x13
    18a8:      	ldp	q2, q17, [x16]
    18ac:      	and.16b	v2, v1, v2
    18b0:      	fdiv.4s	v2, v2, v5
    18b4:      	add	x16, x10, x13
    18b8:      	ldp	q3, q19, [x16]
    18bc:      	and.16b	v3, v1, v3
    18c0:      	fmul.4s	v2, v2, v3
    18c4:      	add	x16, x9, x13
    18c8:      	ldp	q3, q24, [x16]
    18cc:      	and.16b	v3, v1, v3
    18d0:      	fadd.4s	v25, v2, v3
    18d4:      	add	x13, x8, x13
    18d8:      	tbnz	w15, #0x0, 0x1920 <_llm_rows.packet_batch.blocks+0x1554>
    18dc:      	and	w15, w15, #0xff
    18e0:      	tbnz	w15, #0x1, 0x192c <_llm_rows.packet_batch.blocks+0x1560>
    18e4:      	tbnz	w15, #0x2, 0x1938 <_llm_rows.packet_batch.blocks+0x156c>
    18e8:      	tbz	w15, #0x3, 0x18f4 <_llm_rows.packet_batch.blocks+0x1528>
    18ec:      	add	x16, x13, #0xc
    18f0:      	st1.s	{ v25 }[3], [x16]
    18f4:      	and.16b	v2, v0, v17
    18f8:      	fdiv.4s	v2, v2, v5
    18fc:      	and.16b	v3, v0, v19
    1900:      	fmul.4s	v2, v2, v3
    1904:      	and.16b	v3, v0, v24
    1908:      	fadd.4s	v17, v2, v3
    190c:      	tbnz	w15, #0x4, 0x1948 <_llm_rows.packet_batch.blocks+0x157c>
    1910:      	tbnz	w15, #0x5, 0x1950 <_llm_rows.packet_batch.blocks+0x1584>
    1914:      	tbnz	w15, #0x6, 0x195c <_llm_rows.packet_batch.blocks+0x1590>
    1918:      	tbz	w15, #0x7, 0x1880 <_llm_rows.packet_batch.blocks+0x14b4>
    191c:      	b	0x1968 <_llm_rows.packet_batch.blocks+0x159c>
    1920:      	str	s25, [x13]
    1924:      	and	w15, w15, #0xff
    1928:      	tbz	w15, #0x1, 0x18e4 <_llm_rows.packet_batch.blocks+0x1518>
    192c:      	add	x16, x13, #0x4
    1930:      	st1.s	{ v25 }[1], [x16]
    1934:      	tbz	w15, #0x2, 0x18e8 <_llm_rows.packet_batch.blocks+0x151c>
    1938:      	add	x16, x13, #0x8
    193c:      	st1.s	{ v25 }[2], [x16]
    1940:      	tbnz	w15, #0x3, 0x18ec <_llm_rows.packet_batch.blocks+0x1520>
    1944:      	b	0x18f4 <_llm_rows.packet_batch.blocks+0x1528>
    1948:      	str	s17, [x13, #0x10]
    194c:      	tbz	w15, #0x5, 0x1914 <_llm_rows.packet_batch.blocks+0x1548>
    1950:      	add	x16, x13, #0x14
    1954:      	st1.s	{ v17 }[1], [x16]
    1958:      	tbz	w15, #0x6, 0x1918 <_llm_rows.packet_batch.blocks+0x154c>
    195c:      	add	x16, x13, #0x18
    1960:      	st1.s	{ v17 }[2], [x16]
    1964:      	tbz	w15, #0x7, 0x1880 <_llm_rows.packet_batch.blocks+0x14b4>
    1968:      	add	x13, x13, #0x1c
    196c:      	st1.s	{ v17 }[3], [x13]
    1970:      	b	0x1880 <_llm_rows.packet_batch.blocks+0x14b4>
    1974:      	add	x8, x11, x14
    1978:      	ldp	q1, q0, [x8]
    197c:      	zip1.8b	v2, v26, v0
    1980:      	ushll.4s	v2, v2, #0x0
    1984:      	shl.4s	v2, v2, #0x1f
    1988:      	cmlt.4s	v3, v2, #0
    198c:      	and.16b	v1, v3, v1
    1990:      	fmov	w8, s18
    1994:      	fdiv.4s	v2, v1, v5
    1998:      	add	x10, x10, x14
    199c:      	ldp	q4, q1, [x10]
    19a0:      	and.16b	v4, v3, v4
    19a4:      	fmul.4s	v4, v2, v4
    19a8:      	add	x9, x9, x14
    19ac:      	ldp	q6, q2, [x9]
    19b0:      	and.16b	v3, v3, v6
    19b4:      	fadd.4s	v4, v4, v3
    19b8:      	ldr	q6, [sp, #0x150]
    19bc:      	ldp	q3, q7, [sp, #0x120]
    19c0:      	stp	q6, q7, [sp, #0x1a0]
    19c4:      	str	q3, [sp, #0x1c0]
    19c8:      	ldr	q3, [sp, #0x140]
    19cc:      	str	q3, [sp, #0x1d0]
    19d0:      	and	x9, x12, #0x7
    19d4:      	add	x10, sp, #0x1a0
    19d8:      	ldr	x9, [x10, x9, lsl #3]
    19dc:      	sub	x9, x9, x12
    19e0:      	add	x9, x17, x9, lsl #2
    19e4:      	tbnz	w8, #0x0, 0x1b3c <_llm_rows.packet_batch.blocks+0x1770>
    19e8:      	tbnz	w8, #0x1, 0x1b44 <_llm_rows.packet_batch.blocks+0x1778>
    19ec:      	tbnz	w8, #0x2, 0x1b50 <_llm_rows.packet_batch.blocks+0x1784>
    19f0:      	tbz	w8, #0x3, 0x19fc <_llm_rows.packet_batch.blocks+0x1630>
    19f4:      	add	x10, x9, #0xc
    19f8:      	st1.s	{ v4 }[3], [x10]
    19fc:      	zip2.8b	v3, v26, v0
    1a00:      	ushll.4s	v3, v3, #0x0
    1a04:      	shl.4s	v3, v3, #0x1f
    1a08:      	cmlt.4s	v3, v3, #0
    1a0c:      	and.16b	v0, v3, v0
    1a10:      	fdiv.4s	v0, v0, v5
    1a14:      	and.16b	v1, v3, v1
    1a18:      	fmul.4s	v0, v0, v1
    1a1c:      	and.16b	v1, v3, v2
    1a20:      	fadd.4s	v0, v0, v1
    1a24:      	tbnz	w8, #0x4, 0x1b60 <_llm_rows.packet_batch.blocks+0x1794>
    1a28:      	tbnz	w8, #0x5, 0x1b68 <_llm_rows.packet_batch.blocks+0x179c>
    1a2c:      	tbnz	w8, #0x6, 0x1b74 <_llm_rows.packet_batch.blocks+0x17a8>
    1a30:      	tbz	w8, #0x7, 0x450 <_llm_rows.packet_batch.blocks+0x84>
    1a34:      	b	0x1b80 <_llm_rows.packet_batch.blocks+0x17b4>
    1a38:      	ldr	s26, [x8]
    1a3c:      	tbz	w14, #0x1, 0x7a0 <_llm_rows.packet_batch.blocks+0x3d4>
    1a40:      	add	x16, x8, #0x4
    1a44:      	ld1.s	{ v26 }[1], [x16]
    1a48:      	tbz	w14, #0x2, 0x7a4 <_llm_rows.packet_batch.blocks+0x3d8>
    1a4c:      	add	x16, x8, #0x8
    1a50:      	ld1.s	{ v26 }[2], [x16]
    1a54:      	tbz	w14, #0x3, 0x7a8 <_llm_rows.packet_batch.blocks+0x3dc>
    1a58:      	add	x16, x8, #0xc
    1a5c:      	ld1.s	{ v26 }[3], [x16]
    1a60:      	tbz	w14, #0x4, 0x7ac <_llm_rows.packet_batch.blocks+0x3e0>
    1a64:      	add	x16, x8, #0x10
    1a68:      	ld1.s	{ v27 }[0], [x16]
    1a6c:      	tbz	w14, #0x5, 0x7b0 <_llm_rows.packet_batch.blocks+0x3e4>
    1a70:      	add	x16, x8, #0x14
    1a74:      	ld1.s	{ v27 }[1], [x16]
    1a78:      	tbz	w14, #0x6, 0x7b4 <_llm_rows.packet_batch.blocks+0x3e8>
    1a7c:      	add	x16, x8, #0x18
    1a80:      	ld1.s	{ v27 }[2], [x16]
    1a84:      	tbnz	w14, #0x7, 0x7b8 <_llm_rows.packet_batch.blocks+0x3ec>
    1a88:      	b	0x7c0 <_llm_rows.packet_batch.blocks+0x3f4>
    1a8c:      	ldr	s4, [x15]
    1a90:      	tbz	w8, #0x1, 0x1250 <_llm_rows.packet_batch.blocks+0xe84>
    1a94:      	add	x19, x15, #0x4
    1a98:      	ld1.s	{ v4 }[1], [x19]
    1a9c:      	tbz	w8, #0x2, 0x1254 <_llm_rows.packet_batch.blocks+0xe88>
    1aa0:      	add	x19, x15, #0x8
    1aa4:      	ld1.s	{ v4 }[2], [x19]
    1aa8:      	tbz	w8, #0x3, 0x1258 <_llm_rows.packet_batch.blocks+0xe8c>
    1aac:      	add	x19, x15, #0xc
    1ab0:      	ld1.s	{ v4 }[3], [x19]
    1ab4:      	tbz	w8, #0x4, 0x125c <_llm_rows.packet_batch.blocks+0xe90>
    1ab8:      	add	x19, x15, #0x10
    1abc:      	ld1.s	{ v5 }[0], [x19]
    1ac0:      	tbz	w8, #0x5, 0x1260 <_llm_rows.packet_batch.blocks+0xe94>
    1ac4:      	add	x19, x15, #0x14
    1ac8:      	ld1.s	{ v5 }[1], [x19]
    1acc:      	tbz	w8, #0x6, 0x1264 <_llm_rows.packet_batch.blocks+0xe98>
    1ad0:      	add	x19, x15, #0x18
    1ad4:      	ld1.s	{ v5 }[2], [x19]
    1ad8:      	tbnz	w8, #0x7, 0x1268 <_llm_rows.packet_batch.blocks+0xe9c>
    1adc:      	b	0x1270 <_llm_rows.packet_batch.blocks+0xea4>
    1ae0:      	ldr	s4, [x8]
    1ae4:      	ldr	x17, [sp, #0x170]
    1ae8:      	tbz	w13, #0x1, 0x17d8 <_llm_rows.packet_batch.blocks+0x140c>
    1aec:      	add	x15, x8, #0x4
    1af0:      	ld1.s	{ v4 }[1], [x15]
    1af4:      	ldr	q26, [sp, #0x180]
    1af8:      	tbz	w13, #0x2, 0x17e0 <_llm_rows.packet_batch.blocks+0x1414>
    1afc:      	add	x15, x8, #0x8
    1b00:      	ld1.s	{ v4 }[2], [x15]
    1b04:      	tbz	w13, #0x3, 0x17e4 <_llm_rows.packet_batch.blocks+0x1418>
    1b08:      	add	x15, x8, #0xc
    1b0c:      	ld1.s	{ v4 }[3], [x15]
    1b10:      	tbz	w13, #0x4, 0x17e8 <_llm_rows.packet_batch.blocks+0x141c>
    1b14:      	add	x15, x8, #0x10
    1b18:      	ld1.s	{ v5 }[0], [x15]
    1b1c:      	tbz	w13, #0x5, 0x17ec <_llm_rows.packet_batch.blocks+0x1420>
    1b20:      	add	x15, x8, #0x14
    1b24:      	ld1.s	{ v5 }[1], [x15]
    1b28:      	tbz	w13, #0x6, 0x17f0 <_llm_rows.packet_batch.blocks+0x1424>
    1b2c:      	add	x15, x8, #0x18
    1b30:      	ld1.s	{ v5 }[2], [x15]
    1b34:      	tbnz	w13, #0x7, 0x17f4 <_llm_rows.packet_batch.blocks+0x1428>
    1b38:      	b	0x17fc <_llm_rows.packet_batch.blocks+0x1430>
    1b3c:      	str	s4, [x9]
    1b40:      	tbz	w8, #0x1, 0x19ec <_llm_rows.packet_batch.blocks+0x1620>
    1b44:      	add	x10, x9, #0x4
    1b48:      	st1.s	{ v4 }[1], [x10]
    1b4c:      	tbz	w8, #0x2, 0x19f0 <_llm_rows.packet_batch.blocks+0x1624>
    1b50:      	add	x10, x9, #0x8
    1b54:      	st1.s	{ v4 }[2], [x10]
    1b58:      	tbnz	w8, #0x3, 0x19f4 <_llm_rows.packet_batch.blocks+0x1628>
    1b5c:      	b	0x19fc <_llm_rows.packet_batch.blocks+0x1630>
    1b60:      	str	s0, [x9, #0x10]
    1b64:      	tbz	w8, #0x5, 0x1a2c <_llm_rows.packet_batch.blocks+0x1660>
    1b68:      	add	x10, x9, #0x14
    1b6c:      	st1.s	{ v0 }[1], [x10]
    1b70:      	tbz	w8, #0x6, 0x1a30 <_llm_rows.packet_batch.blocks+0x1664>
    1b74:      	add	x10, x9, #0x18
    1b78:      	st1.s	{ v0 }[2], [x10]
    1b7c:      	tbz	w8, #0x7, 0x450 <_llm_rows.packet_batch.blocks+0x84>
    1b80:      	add	x8, x9, #0x1c
    1b84:      	st1.s	{ v0 }[3], [x8]
    1b88:      	b	0x450 <_llm_rows.packet_batch.blocks+0x84>
    1b8c:      	add	sp, sp, #0x680
    1b90:      	ldp	x29, x30, [sp, #0x90]
    1b94:      	ldp	x20, x19, [sp, #0x80]
    1b98:      	ldp	x22, x21, [sp, #0x70]
    1b9c:      	ldp	x24, x23, [sp, #0x60]
    1ba0:      	ldp	x26, x25, [sp, #0x50]
    1ba4:      	ldp	x28, x27, [sp, #0x40]
    1ba8:      	ldp	d9, d8, [sp, #0x30]
    1bac:      	ldp	d11, d10, [sp, #0x20]
    1bb0:      	ldp	d13, d12, [sp, #0x10]
    1bb4:      	ldp	d15, d14, [sp], #0xa0
    1bb8:      	ret

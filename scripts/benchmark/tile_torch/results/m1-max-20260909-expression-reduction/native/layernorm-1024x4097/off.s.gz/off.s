
/private/tmp/luisa-expression-fusion.qXgTbC/capture/layernorm-1024x4097/off/object/tile_xir_w8_23360_1788930263235173_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	mov	x10, #0x0               ; =0
       4:      	ldr	x8, [x1, #0x88]
       8:      	ldr	x14, [x0]
       c:      	ldr	x13, [x0, #0x10]
      10:      	ldr	w9, [x1]
      14:      	ldr	w11, [x1, #0x24]
      18:      	add	w9, w11, w9, lsl #5
      1c:      	lsr	w9, w9, #3
      20:      	dup.2s	v0, w9
      24:      	ushll.2d	v0, v0, #0x0
      28:      	fmov	x9, d0
      2c:      	mov	w11, #0x4004            ; =16388
      30:      	umaddl	x12, w9, w11, x14
      34:      	ldr	x11, [x0, #0x20]
      38:      	ldr	x9, [x0, #0x30]
      3c:      	add	x15, x12, x10
      40:      	ldp	q1, q2, [x15]
      44:      	add	x15, x8, x10
      48:      	stp	q1, q2, [x15]
      4c:      	add	x10, x10, #0x20
      50:      	cmp	x10, #0x4, lsl #12      ; =0x4000
      54:      	b.ne	0x3c <ltmp0+0x3c>
      58:      	fmov	x10, d0
      5c:      	add	x10, x10, x10, lsl #12
      60:      	lsl	x12, x10, #2
      64:      	add	x10, x12, #0x4, lsl #12 ; =0x4000
      68:      	add	x14, x14, x10
      6c:      	ldr	q0, [x8, #0x4000]
      70:      	ld1.s	{ v0 }[0], [x14]
      74:      	str	q0, [x8, #0x4000]
      78:      	ldp	q1, q2, [x8]
      7c:      	ldp	q6, q7, [x8, #0x20]
      80:      	ldp	q16, q3, [x8, #0x40]
      84:      	ldp	q4, q5, [x8, #0x60]
      88:      	add	x14, x8, #0xe0
      8c:      	mov	w15, #0x4               ; =4
      90:      	ldp	q17, q18, [x14, #-0x60]
      94:      	fadd.4s	v2, v2, v18
      98:      	fadd.4s	v1, v1, v17
      9c:      	ldp	q17, q18, [x14, #-0x40]
      a0:      	fadd.4s	v7, v7, v18
      a4:      	fadd.4s	v6, v6, v17
      a8:      	ldp	q17, q18, [x14, #-0x20]
      ac:      	fadd.4s	v3, v3, v18
      b0:      	fadd.4s	v16, v16, v17
      b4:      	ldp	q17, q18, [x14], #0x80
      b8:      	fadd.4s	v5, v5, v18
      bc:      	fadd.4s	v4, v4, v17
      c0:      	cmp	x15, #0x1fc
      c4:      	add	x15, x15, #0x4
      c8:      	b.lo	0x90 <ltmp0+0x90>
      cc:      	fadd.4s	v17, v0, v1
      d0:      	mov.s	v1[0], v17[0]
      d4:      	fadd.4s	v2, v7, v2
      d8:      	fadd.4s	v1, v6, v1
      dc:      	fadd.4s	v1, v16, v1
      e0:      	fadd.4s	v2, v3, v2
      e4:      	fadd.4s	v2, v5, v2
      e8:      	fadd.4s	v1, v4, v1
      ec:      	rev64.4s	v3, v1
      f0:      	rev64.4s	v4, v2
      f4:      	fadd.4s	v2, v2, v4
      f8:      	fadd.4s	v1, v1, v3
      fc:      	dup.4s	v3, v1[2]
     100:      	dup.4s	v4, v2[2]
     104:      	fadd.4s	v2, v2, v4
     108:      	fadd.4s	v1, v1, v3
     10c:      	fadd.4s	v1, v1, v2
     110:      	movi	d2, #0000000000000000
     114:      	fadd	s1, s1, s2
     118:      	mov	w14, #0x800             ; =2048
     11c:      	movk	w14, #0x4580, lsl #16
     120:      	fmov	s2, w14
     124:      	fdiv	s1, s1, s2
     128:      	dup.4s	v2, v1[0]
     12c:      	mov	w14, #0x200             ; =512
     130:      	mov	x15, x8
     134:      	ldp	q4, q3, [x15]
     138:      	fsub.4s	v4, v4, v2
     13c:      	fsub.4s	v3, v3, v2
     140:      	str	q3, [x15, #0x4030]
     144:      	str	q4, [x15, #0x4020]
     148:      	add	x15, x15, #0x20
     14c:      	subs	x14, x14, #0x1
     150:      	b.ne	0x134 <ltmp0+0x134>
     154:      	fsub.4s	v0, v0, v1
     158:      	ldr	q1, [x8, #0x8020]
     15c:      	mov.s	v1[0], v0[0]
     160:      	str	q1, [x8, #0x8020]
     164:      	ldr	q1, [x8, #0x4020]
     168:      	ldr	q2, [x8, #0x4030]
     16c:      	fmul.4s	v2, v2, v2
     170:      	fmul.4s	v1, v1, v1
     174:      	ldr	q3, [x8, #0x4040]
     178:      	ldr	q4, [x8, #0x4050]
     17c:      	fmul.4s	v4, v4, v4
     180:      	fmul.4s	v3, v3, v3
     184:      	ldr	q6, [x8, #0x4060]
     188:      	ldr	q5, [x8, #0x4070]
     18c:      	fmul.4s	v5, v5, v5
     190:      	fmul.4s	v6, v6, v6
     194:      	ldr	q7, [x8, #0x4080]
     198:      	ldr	q16, [x8, #0x4090]
     19c:      	fmul.4s	v16, v16, v16
     1a0:      	fmul.4s	v7, v7, v7
     1a4:      	mov	w14, #0x4100            ; =16640
     1a8:      	add	x14, x8, x14
     1ac:      	mov	w15, #0x205             ; =517
     1b0:      	ldp	q18, q17, [x14, #-0x60]
     1b4:      	fmul.4s	v18, v18, v18
     1b8:      	fmul.4s	v17, v17, v17
     1bc:      	fadd.4s	v2, v2, v17
     1c0:      	fadd.4s	v1, v1, v18
     1c4:      	ldp	q18, q17, [x14, #-0x40]
     1c8:      	fmul.4s	v18, v18, v18
     1cc:      	fmul.4s	v17, v17, v17
     1d0:      	fadd.4s	v4, v4, v17
     1d4:      	fadd.4s	v3, v3, v18
     1d8:      	ldp	q18, q17, [x14, #-0x20]
     1dc:      	fmul.4s	v18, v18, v18
     1e0:      	fmul.4s	v17, v17, v17
     1e4:      	fadd.4s	v5, v5, v17
     1e8:      	fadd.4s	v6, v6, v18
     1ec:      	ldp	q18, q17, [x14], #0x80
     1f0:      	fmul.4s	v18, v18, v18
     1f4:      	fmul.4s	v17, v17, v17
     1f8:      	fadd.4s	v16, v16, v17
     1fc:      	fadd.4s	v7, v7, v18
     200:      	sub	x16, x15, #0x201
     204:      	add	x15, x15, #0x4
     208:      	cmp	x16, #0x1fc
     20c:      	b.lo	0x1b0 <ltmp0+0x1b0>
     210:      	mov	x14, #0x0               ; =0
     214:      	mov	w15, #0x8040            ; =32832
     218:      	add	x15, x8, x15
     21c:      	add	x16, x13, x14
     220:      	ldp	q17, q18, [x16]
     224:      	add	x16, x15, x14
     228:      	stp	q17, q18, [x16]
     22c:      	add	x14, x14, #0x20
     230:      	cmp	x14, #0x4, lsl #12      ; =0x4000
     234:      	b.ne	0x21c <ltmp0+0x21c>
     238:      	mov	x14, #0x0               ; =0
     23c:      	mov	w15, #0xc060            ; =49248
     240:      	add	x15, x8, x15
     244:      	mov	w16, #0x4000            ; =16384
     248:      	ldr	s17, [x13, x16]
     24c:      	mov	w13, #0xc040            ; =49216
     250:      	str	s17, [x8, x13]
     254:      	add	x13, x11, x14
     258:      	ldp	q17, q18, [x13]
     25c:      	add	x13, x15, x14
     260:      	stp	q17, q18, [x13]
     264:      	add	x14, x14, #0x20
     268:      	cmp	x14, #0x4, lsl #12      ; =0x4000
     26c:      	b.ne	0x254 <ltmp0+0x254>
     270:      	fmul.4s	v0, v0, v0
     274:      	fadd.4s	v0, v0, v1
     278:      	mov.s	v1[0], v0[0]
     27c:      	fadd.4s	v0, v4, v2
     280:      	fadd.4s	v1, v3, v1
     284:      	fadd.4s	v1, v6, v1
     288:      	fadd.4s	v0, v5, v0
     28c:      	fadd.4s	v0, v16, v0
     290:      	fadd.4s	v1, v7, v1
     294:      	rev64.4s	v2, v1
     298:      	rev64.4s	v3, v0
     29c:      	fadd.4s	v0, v0, v3
     2a0:      	fadd.4s	v1, v1, v2
     2a4:      	dup.4s	v2, v1[2]
     2a8:      	dup.4s	v3, v0[2]
     2ac:      	fadd.4s	v0, v0, v3
     2b0:      	fadd.4s	v1, v1, v2
     2b4:      	fadd.4s	v0, v1, v0
     2b8:      	movi	d1, #0000000000000000
     2bc:      	fadd	s0, s0, s1
     2c0:      	mov	w13, #0x800             ; =2048
     2c4:      	movk	w13, #0x4580, lsl #16
     2c8:      	fmov	s1, w13
     2cc:      	fdiv	s0, s0, s1
     2d0:      	mov	w13, #0xc5ac            ; =50604
     2d4:      	movk	w13, #0x3727, lsl #16
     2d8:      	fmov	s1, w13
     2dc:      	fadd	s0, s0, s1
     2e0:      	mov	w13, #0x4000            ; =16384
     2e4:      	ldr	s1, [x11, x13]
     2e8:      	mov	w11, #0x60              ; =96
     2ec:      	movk	w11, #0x1, lsl #16
     2f0:      	str	s1, [x8, x11]
     2f4:      	fsqrt	s0, s0
     2f8:      	dup.4s	v1, v0[0]
     2fc:      	add	x11, x9, x12
     300:      	mov	w12, #0x200             ; =512
     304:      	mov	x13, x8
     308:      	ldr	q2, [x13, #0x4030]
     30c:      	ldr	q3, [x13, #0x4020]
     310:      	fdiv.4s	v3, v3, v1
     314:      	fdiv.4s	v2, v2, v1
     318:      	ldr	q4, [x13, #0x8040]
     31c:      	ldr	q5, [x13, #0x8050]
     320:      	fmul.4s	v2, v2, v5
     324:      	fmul.4s	v3, v3, v4
     328:      	ldr	q4, [x13, #0xc070]
     32c:      	ldr	q5, [x13, #0xc060]
     330:      	fadd.4s	v3, v3, v5
     334:      	fadd.4s	v2, v2, v4
     338:      	stp	q3, q2, [x11], #0x20
     33c:      	add	x13, x13, #0x20
     340:      	subs	x12, x12, #0x1
     344:      	b.ne	0x308 <ltmp0+0x308>
     348:      	ldr	q1, [x8, #0x8020]
     34c:      	fdiv.4s	v0, v1, v0
     350:      	ldr	q1, [x8, #0xc040]
     354:      	fmul.4s	v0, v0, v1
     358:      	add	x11, x8, #0x10, lsl #12 ; =0x10000
     35c:      	ldr	q1, [x11, #0x60]
     360:      	fadd.4s	v0, v0, v1
     364:      	str	s0, [x9, x10]
     368:      	ret

000000000000036c <_llm_rows.packet_batch.blocks>:
     36c:      	cbz	w3, 0x1a7c <_llm_rows.packet_batch.blocks+0x1710>
     370:      	stp	d15, d14, [sp, #-0xa0]!
     374:      	stp	d13, d12, [sp, #0x10]
     378:      	stp	d11, d10, [sp, #0x20]
     37c:      	stp	d9, d8, [sp, #0x30]
     380:      	stp	x28, x27, [sp, #0x40]
     384:      	stp	x26, x25, [sp, #0x50]
     388:      	stp	x24, x23, [sp, #0x60]
     38c:      	stp	x22, x21, [sp, #0x70]
     390:      	stp	x20, x19, [sp, #0x80]
     394:      	stp	x29, x30, [sp, #0x90]
     398:      	sub	sp, sp, #0x6d0
     39c:      	mov	x27, x3
     3a0:      	mov	x20, x2
     3a4:      	mov	x21, x0
     3a8:      	mov	w22, #0x0               ; =0
     3ac:      	ldp	w9, w8, [x2, #0x2c]
     3b0:      	str	w9, [sp, #0x1ec]
     3b4:      	str	w8, [sp, #0x1e8]
     3b8:      	ldp	w25, w24, [x2]
     3bc:      	ldp	w23, w28, [x2, #0x8]
     3c0:      	adrp	x8, 0x0 <ltmp0>
     3c4:      	ldr	q0, [x8]
     3c8:      	str	q0, [sp, #0x10]
     3cc:      	adrp	x8, 0x0 <ltmp0>
     3d0:      	ldr	q0, [x8]
     3d4:      	str	q0, [sp, #0x30]
     3d8:      	adrp	x8, 0x0 <ltmp0>
     3dc:      	ldr	q0, [x8]
     3e0:      	str	q0, [sp, #0x20]
     3e4:      	mov	w26, #0x4               ; =4
     3e8:      	str	w3, [sp, #0x1c4]
     3ec:      	b	0x438 <_llm_rows.packet_batch.blocks+0xcc>
     3f0:      	mov	w8, #0x18               ; =24
     3f4:      	str	w8, [x20, #0x24]
     3f8:      	ldr	w27, [sp, #0x1c4]
     3fc:      	add	w8, w25, #0x1
     400:      	ldr	w9, [sp, #0x1ec]
     404:      	cmp	w8, w9
     408:      	cset	w8, eq
     40c:      	csinc	w25, wzr, w25, eq
     410:      	cinc	w9, w24, eq
     414:      	ldr	w10, [sp, #0x1e8]
     418:      	cmp	w9, w10
     41c:      	cset	w10, eq
     420:      	ands	w8, w8, w10
     424:      	csel	w24, wzr, w9, ne
     428:      	add	w23, w23, w8
     42c:      	add	w22, w22, #0x1
     430:      	cmp	w22, w27
     434:      	b.eq	0x1a50 <_llm_rows.packet_batch.blocks+0x16e4>
     438:      	ubfiz	x8, x25, #5, #32
     43c:      	cmp	x8, x28
     440:      	csel	x9, x8, xzr, ls
     444:      	subs	x10, x28, x9
     448:      	cmp	x10, #0x20
     44c:      	mov	w11, #0x20              ; =32
     450:      	csel	x10, x10, x11, lo
     454:      	cmp	x28, x9
     458:      	stp	w25, w24, [x20]
     45c:      	str	w23, [x20, #0x8]
     460:      	str	wzr, [x20, #0x24]
     464:      	ccmp	x8, x28, #0x2, hi
     468:      	csel	x19, x10, xzr, ls
     46c:      	cmp	x19, #0x20
     470:      	b.lo	0x4c0 <_llm_rows.packet_batch.blocks+0x154>
     474:      	mov	x0, x21
     478:      	mov	x1, x20
     47c:      	bl	0x47c <_llm_rows.packet_batch.blocks+0x110>
     480:      	mov	w8, #0x8                ; =8
     484:      	str	w8, [x20, #0x24]
     488:      	mov	x0, x21
     48c:      	mov	x1, x20
     490:      	bl	0x490 <_llm_rows.packet_batch.blocks+0x124>
     494:      	mov	w8, #0x10               ; =16
     498:      	str	w8, [x20, #0x24]
     49c:      	mov	x0, x21
     4a0:      	mov	x1, x20
     4a4:      	bl	0x4a4 <_llm_rows.packet_batch.blocks+0x138>
     4a8:      	mov	w8, #0x18               ; =24
     4ac:      	str	w8, [x20, #0x24]
     4b0:      	mov	x0, x21
     4b4:      	mov	x1, x20
     4b8:      	bl	0x4b8 <_llm_rows.packet_batch.blocks+0x14c>
     4bc:      	b	0x3fc <_llm_rows.packet_batch.blocks+0x90>
     4c0:      	lsr	x27, x19, #3
     4c4:      	cmp	x19, #0x8
     4c8:      	b.lo	0x514 <_llm_rows.packet_batch.blocks+0x1a8>
     4cc:      	str	wzr, [x20, #0x24]
     4d0:      	mov	x0, x21
     4d4:      	mov	x1, x20
     4d8:      	bl	0x4d8 <_llm_rows.packet_batch.blocks+0x16c>
     4dc:      	cmp	x27, #0x1
     4e0:      	b.eq	0x514 <_llm_rows.packet_batch.blocks+0x1a8>
     4e4:      	mov	w8, #0x8                ; =8
     4e8:      	str	w8, [x20, #0x24]
     4ec:      	mov	x0, x21
     4f0:      	mov	x1, x20
     4f4:      	bl	0x4f4 <_llm_rows.packet_batch.blocks+0x188>
     4f8:      	cmp	x27, #0x2
     4fc:      	b.eq	0x514 <_llm_rows.packet_batch.blocks+0x1a8>
     500:      	mov	w8, #0x10               ; =16
     504:      	str	w8, [x20, #0x24]
     508:      	mov	x0, x21
     50c:      	mov	x1, x20
     510:      	bl	0x510 <_llm_rows.packet_batch.blocks+0x1a4>
     514:      	and	w8, w19, #0x7
     518:      	cbz	w8, 0x3f0 <_llm_rows.packet_batch.blocks+0x84>
     51c:      	dup.4s	v1, w8
     520:      	ldp	q0, q2, [sp, #0x20]
     524:      	cmhi.4s	v0, v1, v0
     528:      	cmhi.4s	v1, v1, v2
     52c:      	uzp1.8h	v3, v1, v0
     530:      	umaxv.8h	h2, v3
     534:      	fmov	w8, s2
     538:      	tbz	w8, #0x0, 0x3f0 <_llm_rows.packet_batch.blocks+0x84>
     53c:      	mov	x12, #0x0               ; =0
     540:      	ldr	x19, [x20, #0x88]
     544:      	mov	w8, #0x4020             ; =16416
     548:      	add	x11, x19, x8
     54c:      	mov	w8, #0x8040             ; =32832
     550:      	add	x10, x19, x8
     554:      	mov	w8, #0xc060             ; =49248
     558:      	add	x9, x19, x8
     55c:      	ldr	x8, [x21]
     560:      	ldr	x15, [x21, #0x10]
     564:      	ldr	x13, [x21, #0x20]
     568:      	ldr	x14, [x21, #0x30]
     56c:      	str	x14, [sp, #0x1b8]
     570:      	ldr	q2, [sp, #0x10]
     574:      	str	q3, [sp, #0x140]
     578:      	and.16b	v2, v3, v2
     57c:      	addv.8h	h2, v2
     580:      	fmov	w14, s2
     584:      	and	w14, w14, #0xff
     588:      	str	w14, [sp, #0x110]
     58c:      	ubfiz	w14, w25, #2, #27
     590:      	orr	w14, w14, w27
     594:      	dup.4s	v3, w14
     598:      	and.16b	v7, v1, v3
     59c:      	and.16b	v3, v0, v3
     5a0:      	ushll2.2d	v4, v3, #0x0
     5a4:      	ushll2.2d	v5, v7, #0x0
     5a8:      	ushll.2d	v6, v3, #0x0
     5ac:      	ushll.2d	v18, v7, #0x0
     5b0:      	fmov	x14, d18
     5b4:      	mov	w16, #0x4004            ; =16388
     5b8:      	umaddl	x14, w14, w16, x8
     5bc:      	fmov	w16, s2
     5c0:      	b	0x5e4 <_llm_rows.packet_batch.blocks+0x278>
     5c4:      	add	x17, x19, x12
     5c8:      	ldp	q17, q19, [x17]
     5cc:      	bif.16b	v7, v19, v0
     5d0:      	bif.16b	v3, v17, v1
     5d4:      	stp	q3, q7, [x17]
     5d8:      	add	x12, x12, #0x20
     5dc:      	cmp	x12, #0x4, lsl #12      ; =0x4000
     5e0:      	b.eq	0x678 <_llm_rows.packet_batch.blocks+0x30c>
     5e4:      	add	x17, x14, x12
     5e8:      	movi.2d	v3, #0000000000000000
     5ec:      	movi.2d	v7, #0000000000000000
     5f0:      	tbnz	w16, #0x0, 0x618 <_llm_rows.packet_batch.blocks+0x2ac>
     5f4:      	and	w0, w16, #0xff
     5f8:      	tbnz	w0, #0x1, 0x624 <_llm_rows.packet_batch.blocks+0x2b8>
     5fc:      	tbnz	w0, #0x2, 0x630 <_llm_rows.packet_batch.blocks+0x2c4>
     600:      	tbnz	w0, #0x3, 0x63c <_llm_rows.packet_batch.blocks+0x2d0>
     604:      	tbnz	w0, #0x4, 0x648 <_llm_rows.packet_batch.blocks+0x2dc>
     608:      	tbnz	w0, #0x5, 0x654 <_llm_rows.packet_batch.blocks+0x2e8>
     60c:      	tbnz	w0, #0x6, 0x660 <_llm_rows.packet_batch.blocks+0x2f4>
     610:      	tbz	w0, #0x7, 0x5c4 <_llm_rows.packet_batch.blocks+0x258>
     614:      	b	0x66c <_llm_rows.packet_batch.blocks+0x300>
     618:      	ldr	s3, [x17]
     61c:      	and	w0, w16, #0xff
     620:      	tbz	w0, #0x1, 0x5fc <_llm_rows.packet_batch.blocks+0x290>
     624:      	add	x1, x17, #0x4
     628:      	ld1.s	{ v3 }[1], [x1]
     62c:      	tbz	w0, #0x2, 0x600 <_llm_rows.packet_batch.blocks+0x294>
     630:      	add	x1, x17, #0x8
     634:      	ld1.s	{ v3 }[2], [x1]
     638:      	tbz	w0, #0x3, 0x604 <_llm_rows.packet_batch.blocks+0x298>
     63c:      	add	x1, x17, #0xc
     640:      	ld1.s	{ v3 }[3], [x1]
     644:      	tbz	w0, #0x4, 0x608 <_llm_rows.packet_batch.blocks+0x29c>
     648:      	add	x1, x17, #0x10
     64c:      	ld1.s	{ v7 }[0], [x1]
     650:      	tbz	w0, #0x5, 0x60c <_llm_rows.packet_batch.blocks+0x2a0>
     654:      	add	x1, x17, #0x14
     658:      	ld1.s	{ v7 }[1], [x1]
     65c:      	tbz	w0, #0x6, 0x610 <_llm_rows.packet_batch.blocks+0x2a4>
     660:      	add	x1, x17, #0x18
     664:      	ld1.s	{ v7 }[2], [x1]
     668:      	tbz	w0, #0x7, 0x5c4 <_llm_rows.packet_batch.blocks+0x258>
     66c:      	add	x17, x17, #0x1c
     670:      	ld1.s	{ v7 }[3], [x17]
     674:      	b	0x5c4 <_llm_rows.packet_batch.blocks+0x258>
     678:      	str	q2, [sp, #0x1a0]
     67c:      	xtn.4h	v3, v1
     680:      	uzp1.8b	v19, v3, v0
     684:      	sshll.2d	v7, v1, #0x0
     688:      	adrp	x12, 0x0 <ltmp0>
     68c:      	ldr	q3, [x12]
     690:      	and.16b	v16, v7, v3
     694:      	movi.2d	v3, #0000000000000000
     698:      	mov.b	v3[0], v19[0]
     69c:      	adrp	x12, 0x0 <ltmp0>
     6a0:      	ldr	d2, [x12]
     6a4:      	str	d2, [sp, #0xb0]
     6a8:      	and.8b	v20, v3, v2
     6ac:      	addv.8b	b20, v20
     6b0:      	fmov	w14, s20
     6b4:      	umaxv.8b	b20, v3
     6b8:      	fmov	w16, s20
     6bc:      	rbit	w12, w14
     6c0:      	clz	w12, w12
     6c4:      	tst	w16, #0x1
     6c8:      	csel	w12, w12, wzr, ne
     6cc:      	mov	w17, #0x1000            ; =4096
     6d0:      	dup.2d	v22, x17
     6d4:      	str	q16, [sp, #0x120]
     6d8:      	orr.16b	v2, v16, v22
     6dc:      	mov	w17, #0x1001            ; =4097
     6e0:      	dup.2s	v21, w17
     6e4:      	xtn.2s	v27, v18
     6e8:      	str	q2, [sp, #0xa0]
     6ec:      	umlal.2d	v2, v27, v21
     6f0:      	movi.2d	v18, #0000000000000000
     6f4:      	mov.b	v18[0], v19[0]
     6f8:      	ushll.2d	v18, v18, #0x0
     6fc:      	shl.2d	v18, v18, #0x3f
     700:      	cmlt.2d	v18, v18, #0
     704:      	str	q2, [sp, #0x190]
     708:      	and.16b	v18, v18, v2
     70c:      	movi.2d	v2, #0000000000000000
     710:      	str	q2, [sp, #0x6b0]
     714:      	str	q2, [sp, #0x6a0]
     718:      	str	q2, [sp, #0x690]
     71c:      	str	q18, [sp, #0x680]
     720:      	and	x17, x12, #0x7
     724:      	add	x0, sp, #0x680
     728:      	ldr	x17, [x0, x17, lsl #3]
     72c:      	sub	x17, x17, x12
     730:      	add	x8, x8, x17, lsl #2
     734:      	movi.2d	v19, #0000000000000000
     738:      	movi.2d	v8, #0000000000000000
     73c:      	tbnz	w16, #0x0, 0x18fc <_llm_rows.packet_batch.blocks+0x1590>
     740:      	tbnz	w14, #0x1, 0x1904 <_llm_rows.packet_batch.blocks+0x1598>
     744:      	tbnz	w14, #0x2, 0x1910 <_llm_rows.packet_batch.blocks+0x15a4>
     748:      	tbnz	w14, #0x3, 0x191c <_llm_rows.packet_batch.blocks+0x15b0>
     74c:      	tbnz	w14, #0x4, 0x1928 <_llm_rows.packet_batch.blocks+0x15bc>
     750:      	tbnz	w14, #0x5, 0x1934 <_llm_rows.packet_batch.blocks+0x15c8>
     754:      	tbnz	w14, #0x6, 0x1940 <_llm_rows.packet_batch.blocks+0x15d4>
     758:      	tbz	w14, #0x7, 0x764 <_llm_rows.packet_batch.blocks+0x3f8>
     75c:      	add	x8, x8, #0x1c
     760:      	ld1.s	{ v8 }[3], [x8]
     764:      	sshll.2d	v25, v0, #0x0
     768:      	sshll2.2d	v28, v1, #0x0
     76c:      	sshll2.2d	v29, v0, #0x0
     770:      	adrp	x8, 0x0 <ltmp0>
     774:      	ldr	q20, [x8]
     778:      	and.16b	v2, v29, v20
     77c:      	adrp	x8, 0x0 <ltmp0>
     780:      	ldr	q23, [x8]
     784:      	and.16b	v16, v28, v23
     788:      	adrp	x8, 0x0 <ltmp0>
     78c:      	ldr	q24, [x8]
     790:      	and.16b	v17, v25, v24
     794:      	adrp	x8, 0x0 <ltmp0>
     798:      	ldr	q26, [x8]
     79c:      	and.16b	v26, v29, v26
     7a0:      	adrp	x8, 0x0 <ltmp0>
     7a4:      	ldr	q30, [x8]
     7a8:      	and.16b	v30, v28, v30
     7ac:      	adrp	x8, 0x0 <ltmp0>
     7b0:      	ldr	q31, [x8]
     7b4:      	and.16b	v25, v25, v31
     7b8:      	adrp	x8, 0x0 <ltmp0>
     7bc:      	ldr	q31, [x8]
     7c0:      	and.16b	v7, v7, v31
     7c4:      	stp	q17, q16, [sp, #0xc0]
     7c8:      	orr.16b	v17, v17, v22
     7cc:      	orr.16b	v18, v16, v22
     7d0:      	str	q2, [sp, #0xe0]
     7d4:      	orr.16b	v16, v2, v22
     7d8:      	umull.2d	v2, v27, v21
     7dc:      	str	q2, [sp, #0x150]
     7e0:      	xtn.2s	v5, v5
     7e4:      	xtn.2s	v6, v6
     7e8:      	xtn.2s	v4, v4
     7ec:      	stp	q17, q16, [sp, #0x80]
     7f0:      	mov.16b	v2, v16
     7f4:      	umlal.2d	v2, v4, v21
     7f8:      	str	q2, [sp, #0x180]
     7fc:      	str	q18, [sp, #0x70]
     800:      	mov.16b	v2, v18
     804:      	umlal.2d	v2, v5, v21
     808:      	str	q2, [sp, #0x170]
     80c:      	mov.16b	v2, v17
     810:      	umlal.2d	v2, v6, v21
     814:      	str	q2, [sp, #0x160]
     818:      	sshll.2d	v4, v1, #0x0
     81c:      	sshll.2d	v5, v0, #0x0
     820:      	str	q7, [sp, #0x640]
     824:      	str	q30, [sp, #0x650]
     828:      	str	q25, [sp, #0x660]
     82c:      	str	q26, [sp, #0x670]
     830:      	and	x8, x12, #0x7
     834:      	add	x16, sp, #0x640
     838:      	ldr	x8, [x16, x8, lsl #3]
     83c:      	orr	x8, x8, #0x4000
     840:      	str	x12, [sp, #0x138]
     844:      	sub	x8, x8, x12, lsl #2
     848:      	tst	w14, #0xff
     84c:      	csel	x8, xzr, x8, eq
     850:      	str	x8, [sp, #0x1c8]
     854:      	add	x8, x19, x8
     858:      	ldp	q6, q21, [x8]
     85c:      	zip2.8b	v22, v3, v0
     860:      	ushll.4s	v22, v22, #0x0
     864:      	shl.4s	v22, v22, #0x1f
     868:      	cmlt.4s	v22, v22, #0
     86c:      	stp	q8, q19, [sp, #0xf0]
     870:      	bit.16b	v21, v8, v22
     874:      	str	q3, [sp, #0x1d0]
     878:      	zip1.8b	v22, v3, v0
     87c:      	ushll.4s	v22, v22, #0x0
     880:      	shl.4s	v22, v22, #0x1f
     884:      	cmlt.4s	v22, v22, #0
     888:      	bit.16b	v6, v19, v22
     88c:      	stp	q6, q21, [x8]
     890:      	fmov	x30, d7
     894:      	dup.2d	v6, x26
     898:      	and.16b	v26, v29, v6
     89c:      	and.16b	v22, v28, v6
     8a0:      	and.16b	v25, v5, v6
     8a4:      	and.16b	v4, v4, v6
     8a8:      	fmov	x27, d4
     8ac:      	ldp	q5, q6, [x19, #0x60]
     8b0:      	and.16b	v27, v0, v6
     8b4:      	and.16b	v30, v1, v5
     8b8:      	ldp	q5, q6, [x19, #0x40]
     8bc:      	and.16b	v9, v0, v6
     8c0:      	and.16b	v31, v1, v5
     8c4:      	ldp	q5, q6, [x19, #0x20]
     8c8:      	and.16b	v10, v0, v6
     8cc:      	and.16b	v11, v1, v5
     8d0:      	add	x8, x19, x30
     8d4:      	ldp	q5, q6, [x8]
     8d8:      	and.16b	v12, v0, v6
     8dc:      	mov	x8, x27
     8e0:      	and.16b	v13, v1, v5
     8e4:      	mov.16b	v21, v4
     8e8:      	mov.16b	v6, v22
     8ec:      	mov.16b	v7, v25
     8f0:      	mov.16b	v5, v26
     8f4:      	sshll.2d	v17, v1, #0x0
     8f8:      	sshll.2d	v8, v0, #0x0
     8fc:      	add	x8, x19, x8, lsl #5
     900:      	ldp	q14, q15, [x8]
     904:      	fadd.4s	v14, v13, v14
     908:      	fadd.4s	v15, v12, v15
     90c:      	ldp	q20, q16, [x8, #0x20]
     910:      	fadd.4s	v20, v11, v20
     914:      	fadd.4s	v16, v10, v16
     918:      	ldp	q24, q23, [x8, #0x40]
     91c:      	fadd.4s	v24, v31, v24
     920:      	fadd.4s	v23, v9, v23
     924:      	ldp	q18, q3, [x8, #0x60]
     928:      	fadd.4s	v18, v30, v18
     92c:      	fadd.4s	v3, v27, v3
     930:      	dup.2d	v19, x26
     934:      	and.16b	v2, v29, v19
     938:      	add.2d	v5, v5, v2
     93c:      	and.16b	v2, v28, v19
     940:      	add.2d	v6, v6, v2
     944:      	and.16b	v2, v8, v19
     948:      	add.2d	v7, v7, v2
     94c:      	and.16b	v2, v17, v19
     950:      	add.2d	v21, v21, v2
     954:      	bit.16b	v12, v15, v0
     958:      	bit.16b	v13, v14, v1
     95c:      	bit.16b	v10, v16, v0
     960:      	bit.16b	v11, v20, v1
     964:      	bit.16b	v9, v23, v0
     968:      	bit.16b	v31, v24, v1
     96c:      	bit.16b	v27, v3, v0
     970:      	bit.16b	v30, v18, v1
     974:      	fmov	x8, d21
     978:      	cmp	x8, #0x200
     97c:      	b.lt	0x8f4 <_llm_rows.packet_batch.blocks+0x588>
     980:      	mov	x8, #0x0                ; =0
     984:      	ldr	q2, [sp, #0x140]
     988:      	xtn.8b	v8, v2
     98c:      	ldp	q2, q3, [sp, #0xf0]
     990:      	fadd.4s	v2, v2, v12
     994:      	fadd.4s	v3, v3, v13
     998:      	ldr	q12, [sp, #0x1d0]
     99c:      	zip1.8b	v5, v12, v0
     9a0:      	ushll.4s	v5, v5, #0x0
     9a4:      	shl.4s	v5, v5, #0x1f
     9a8:      	cmlt.4s	v5, v5, #0
     9ac:      	and.16b	v3, v5, v3
     9b0:      	zip2.8b	v5, v12, v0
     9b4:      	ushll.4s	v5, v5, #0x0
     9b8:      	shl.4s	v5, v5, #0x1f
     9bc:      	cmlt.4s	v5, v5, #0
     9c0:      	and.16b	v2, v5, v2
     9c4:      	zip2.8b	v5, v8, v0
     9c8:      	ushll.4s	v5, v5, #0x0
     9cc:      	shl.4s	v5, v5, #0x1f
     9d0:      	cmlt.4s	v5, v5, #0
     9d4:      	movi.2d	v6, #0000000000000000
     9d8:      	mov.b	v6[2], v8[1]
     9dc:      	mov.b	v6[4], v8[2]
     9e0:      	bit.16b	v2, v15, v5
     9e4:      	mov.b	v6[6], v8[3]
     9e8:      	ushll.4s	v5, v6, #0x0
     9ec:      	shl.4s	v5, v5, #0x1f
     9f0:      	cmlt.4s	v5, v5, #0
     9f4:      	bit.16b	v3, v14, v5
     9f8:      	fadd.4s	v3, v11, v3
     9fc:      	fadd.4s	v2, v10, v2
     a00:      	fadd.4s	v2, v9, v2
     a04:      	fadd.4s	v3, v31, v3
     a08:      	fadd.4s	v18, v30, v3
     a0c:      	fadd.4s	v19, v27, v2
     a10:      	ldr	q2, [sp, #0x120]
     a14:      	ldp	q3, q5, [sp, #0xc0]
     a18:      	uzp1.4s	v16, v2, v5
     a1c:      	ldr	q2, [sp, #0xe0]
     a20:      	uzp1.4s	v17, v3, v2
     a24:      	movi.4s	v3, #0x1
     a28:      	eor.16b	v2, v16, v3
     a2c:      	mov.s	w17, v2[1]
     a30:      	eor.16b	v27, v17, v3
     a34:      	mov.s	w0, v2[2]
     a38:      	mov.s	w3, v2[3]
     a3c:      	fmov	w1, s2
     a40:      	add	x16, sp, #0x4d8
     a44:      	bfxil	x16, x1, #0, #3
     a48:      	str	d8, [sp, #0x4d8]
     a4c:      	ldrb	w4, [x16]
     a50:      	umov.b	w16, v8[0]
     a54:      	and	x1, x1, #0x7
     a58:      	str	q19, [sp, #0x5b0]
     a5c:      	str	q18, [sp, #0x5a0]
     a60:      	add	x2, sp, #0x5a0
     a64:      	ldr	s2, [x2, x1, lsl #2]
     a68:      	ands	w2, w16, #0x1
     a6c:      	tst	w2, w4
     a70:      	movi	d21, #0000000000000000
     a74:      	fcsel	s20, s2, s21, ne
     a78:      	and	x4, x17, #0x7
     a7c:      	add	x1, sp, #0x4d8
     a80:      	bfxil	x1, x17, #0, #3
     a84:      	ldrb	w17, [x1]
     a88:      	umov.b	w14, v8[1]
     a8c:      	str	q19, [sp, #0x590]
     a90:      	str	q18, [sp, #0x580]
     a94:      	add	x5, sp, #0x580
     a98:      	ldr	s2, [x5, x4, lsl #2]
     a9c:      	and	w17, w14, w17
     aa0:      	tst	w17, #0x1
     aa4:      	fcsel	s23, s2, s21, ne
     aa8:      	and	x4, x0, #0x7
     aac:      	add	x17, sp, #0x4d8
     ab0:      	bfxil	x17, x0, #0, #3
     ab4:      	ldrb	w0, [x17]
     ab8:      	umov.b	w1, v8[2]
     abc:      	and	w0, w1, w0
     ac0:      	str	q19, [sp, #0x570]
     ac4:      	str	q18, [sp, #0x560]
     ac8:      	add	x17, sp, #0x560
     acc:      	ldr	s2, [x17, x4, lsl #2]
     ad0:      	tst	w0, #0x1
     ad4:      	fcsel	s24, s2, s21, ne
     ad8:      	and	x4, x3, #0x7
     adc:      	add	x0, sp, #0x4d8
     ae0:      	bfxil	x0, x3, #0, #3
     ae4:      	ldrb	w3, [x0]
     ae8:      	umov.b	w12, v8[3]
     aec:      	and	w3, w12, w3
     af0:      	str	q19, [sp, #0x550]
     af4:      	str	q18, [sp, #0x540]
     af8:      	add	x17, sp, #0x540
     afc:      	ldr	s2, [x17, x4, lsl #2]
     b00:      	tst	w3, #0x1
     b04:      	mov.s	w3, v27[1]
     b08:      	fcsel	s30, s2, s21, ne
     b0c:      	mov.s	w4, v27[2]
     b10:      	mov.s	w5, v27[3]
     b14:      	fmov	w6, s27
     b18:      	and	x7, x6, #0x7
     b1c:      	add	x17, sp, #0x4d8
     b20:      	bfxil	x17, x6, #0, #3
     b24:      	ldrb	w17, [x17]
     b28:      	umov.b	w6, v8[4]
     b2c:      	and	w17, w6, w17
     b30:      	str	q19, [sp, #0x630]
     b34:      	str	q18, [sp, #0x620]
     b38:      	add	x0, sp, #0x620
     b3c:      	ldr	s2, [x0, x7, lsl #2]
     b40:      	tst	w17, #0x1
     b44:      	fcsel	s2, s2, s21, ne
     b48:      	and	x17, x3, #0x7
     b4c:      	add	x7, sp, #0x4d8
     b50:      	bfxil	x7, x3, #0, #3
     b54:      	umov.b	w3, v8[5]
     b58:      	ldrb	w7, [x7]
     b5c:      	and	w7, w3, w7
     b60:      	str	q19, [sp, #0x610]
     b64:      	str	q18, [sp, #0x600]
     b68:      	add	x0, sp, #0x600
     b6c:      	ldr	s3, [x0, x17, lsl #2]
     b70:      	tst	w7, #0x1
     b74:      	fcsel	s3, s3, s21, ne
     b78:      	and	x17, x4, #0x7
     b7c:      	add	x7, sp, #0x4d8
     b80:      	bfxil	x7, x4, #0, #3
     b84:      	ldrb	w7, [x7]
     b88:      	umov.b	w4, v8[6]
     b8c:      	str	q19, [sp, #0x5f0]
     b90:      	str	q18, [sp, #0x5e0]
     b94:      	add	x0, sp, #0x5e0
     b98:      	ldr	s5, [x0, x17, lsl #2]
     b9c:      	and	w17, w4, w7
     ba0:      	tst	w17, #0x1
     ba4:      	fcsel	s5, s5, s21, ne
     ba8:      	and	x17, x5, #0x7
     bac:      	add	x7, sp, #0x4d8
     bb0:      	bfxil	x7, x5, #0, #3
     bb4:      	ldrb	w7, [x7]
     bb8:      	umov.b	w5, v8[7]
     bbc:      	and	w7, w5, w7
     bc0:      	str	q19, [sp, #0x5d0]
     bc4:      	str	q18, [sp, #0x5c0]
     bc8:      	add	x0, sp, #0x5c0
     bcc:      	ldr	s6, [x0, x17, lsl #2]
     bd0:      	tst	w7, #0x1
     bd4:      	fcsel	s6, s6, s21, ne
     bd8:      	mov.s	v2[1], v3[0]
     bdc:      	mov.s	v2[2], v5[0]
     be0:      	mov.s	v2[3], v6[0]
     be4:      	mov.s	v20[1], v23[0]
     be8:      	mov.s	v20[2], v24[0]
     bec:      	mov.s	v20[3], v30[0]
     bf0:      	fadd.4s	v3, v18, v20
     bf4:      	fadd.4s	v2, v19, v2
     bf8:      	movi.4s	v6, #0x2
     bfc:      	eor.16b	v5, v17, v6
     c00:      	eor.16b	v6, v16, v6
     c04:      	fmov	w17, s6
     c08:      	add	x7, sp, #0x4d8
     c0c:      	bfxil	x7, x17, #0, #3
     c10:      	ldrb	w7, [x7]
     c14:      	and	x17, x17, #0x7
     c18:      	str	q2, [sp, #0x530]
     c1c:      	str	q3, [sp, #0x520]
     c20:      	add	x0, sp, #0x520
     c24:      	ldr	s6, [x0, x17, lsl #2]
     c28:      	tst	w2, w7
     c2c:      	fcsel	s6, s6, s21, ne
     c30:      	fmov	w17, s5
     c34:      	and	x2, x17, #0x7
     c38:      	add	x7, sp, #0x4d8
     c3c:      	bfxil	x7, x17, #0, #3
     c40:      	ldrb	w17, [x7]
     c44:      	and	w17, w6, w17
     c48:      	str	q2, [sp, #0x510]
     c4c:      	str	q3, [sp, #0x500]
     c50:      	add	x0, sp, #0x500
     c54:      	ldr	s5, [x0, x2, lsl #2]
     c58:      	tst	w17, #0x1
     c5c:      	fcsel	s5, s5, s21, ne
     c60:      	fadd.4s	v2, v2, v5
     c64:      	and	w2, w16, w6
     c68:      	tst	w2, #0x1
     c6c:      	fcsel	s2, s2, s21, ne
     c70:      	ands	w7, w16, #0x1
     c74:      	fadd.4s	v3, v3, v6
     c78:      	fadd	s2, s3, s2
     c7c:      	fcsel	s3, s2, s21, ne
     c80:      	tst	w2, #0x1
     c84:      	str	w14, [sp, #0x120]
     c88:      	and	w14, w14, w16
     c8c:      	fcsel	s5, s2, s21, ne
     c90:      	str	w14, [sp, #0x100]
     c94:      	tst	w14, #0x1
     c98:      	str	w1, [sp, #0x140]
     c9c:      	and	w14, w1, w16
     ca0:      	mov	x1, x12
     ca4:      	fcsel	s6, s2, s21, ne
     ca8:      	str	w14, [sp, #0xf0]
     cac:      	tst	w14, #0x1
     cb0:      	and	w12, w12, w16
     cb4:      	fcsel	s7, s2, s21, ne
     cb8:      	str	w12, [sp, #0xe0]
     cbc:      	tst	w12, #0x1
     cc0:      	fcsel	s16, s2, s21, ne
     cc4:      	and	w12, w3, w16
     cc8:      	str	w12, [sp, #0xd0]
     ccc:      	tst	w12, #0x1
     cd0:      	fcsel	s17, s2, s21, ne
     cd4:      	and	w12, w4, w16
     cd8:      	str	w12, [sp, #0xbc]
     cdc:      	tst	w12, #0x1
     ce0:      	fcsel	s18, s2, s21, ne
     ce4:      	and	w12, w5, w16
     ce8:      	str	w12, [sp, #0xb8]
     cec:      	tst	w12, #0x1
     cf0:      	fcsel	s2, s2, s21, ne
     cf4:      	mov.s	v3[1], v6[0]
     cf8:      	mov.s	v3[2], v7[0]
     cfc:      	mov.s	v3[3], v16[0]
     d00:      	mov.s	v5[1], v17[0]
     d04:      	mov.s	v5[2], v18[0]
     d08:      	mov.s	v5[3], v2[0]
     d0c:      	ldr	w12, [sp, #0x110]
     d10:      	rbit	w17, w12
     d14:      	clz	w12, w17
     d18:      	str	q5, [sp, #0x4f0]
     d1c:      	str	q3, [sp, #0x4e0]
     d20:      	str	x12, [sp, #0xc0]
     d24:      	and	x17, x12, #0x7
     d28:      	add	x0, sp, #0x4e0
     d2c:      	ldr	s2, [x0, x17, lsl #2]
     d30:      	str	q8, [sp, #0x110]
     d34:      	mov.b	v8[0], wzr
     d38:      	str	q8, [sp, #0x60]
     d3c:      	fadd	s2, s2, s21
     d40:      	mov	w17, #0x800             ; =2048
     d44:      	movk	w17, #0x4580, lsl #16
     d48:      	fmov	s3, w17
     d4c:      	fdiv	s2, s2, s3
     d50:      	dup.4s	v5, v2[0]
     d54:      	mov	w17, #0x1               ; =1
     d58:      	dup.2d	v2, x17
     d5c:      	ushll2.2d	v3, v0, #0x0
     d60:      	and.16b	v17, v3, v2
     d64:      	ushll2.2d	v3, v1, #0x0
     d68:      	and.16b	v18, v3, v2
     d6c:      	ushll.2d	v3, v0, #0x0
     d70:      	and.16b	v19, v3, v2
     d74:      	ushll.2d	v3, v1, #0x0
     d78:      	and.16b	v20, v3, v2
     d7c:      	movi.2d	v6, #0000000000000000
     d80:      	movi.2d	v7, #0000000000000000
     d84:      	movi.2d	v16, #0000000000000000
     d88:      	movi.2d	v23, #0000000000000000
     d8c:      	lsl	x8, x8, #5
     d90:      	add	x17, x19, x8
     d94:      	ldp	q3, q2, [x17]
     d98:      	fsub.4s	v3, v3, v5
     d9c:      	fsub.4s	v2, v2, v5
     da0:      	add	x8, x11, x8
     da4:      	ldp	q24, q30, [x8]
     da8:      	bif.16b	v2, v30, v0
     dac:      	bif.16b	v3, v24, v1
     db0:      	stp	q3, q2, [x8]
     db4:      	add.2d	v7, v7, v18
     db8:      	add.2d	v16, v16, v19
     dbc:      	add.2d	v23, v23, v17
     dc0:      	add.2d	v6, v6, v20
     dc4:      	fmov	x8, d6
     dc8:      	cmp	x8, #0x200
     dcc:      	b.lt	0xd8c <_llm_rows.packet_batch.blocks+0xa20>
     dd0:      	ldr	x14, [sp, #0x1c8]
     dd4:      	add	x8, x19, x14
     dd8:      	ldp	q3, q2, [x8]
     ddc:      	fsub.4s	v6, v3, v5
     de0:      	fsub.4s	v7, v2, v5
     de4:      	add	x8, x11, x14
     de8:      	ldp	q2, q3, [x8]
     dec:      	zip2.8b	v5, v12, v0
     df0:      	ushll.4s	v5, v5, #0x0
     df4:      	shl.4s	v5, v5, #0x1f
     df8:      	cmlt.4s	v5, v5, #0
     dfc:      	stp	q7, q6, [sp, #0x40]
     e00:      	bit.16b	v3, v7, v5
     e04:      	zip1.8b	v5, v12, v0
     e08:      	ushll.4s	v5, v5, #0x0
     e0c:      	shl.4s	v5, v5, #0x1f
     e10:      	cmlt.4s	v5, v5, #0
     e14:      	bit.16b	v2, v6, v5
     e18:      	stp	q2, q3, [x8]
     e1c:      	ldr	q2, [x19, #0x4090]
     e20:      	ldr	q3, [x19, #0x4080]
     e24:      	fmul.4s	v3, v3, v3
     e28:      	fmul.4s	v2, v2, v2
     e2c:      	and.16b	v30, v0, v2
     e30:      	and.16b	v9, v1, v3
     e34:      	ldr	q2, [x19, #0x4070]
     e38:      	ldr	q3, [x19, #0x4060]
     e3c:      	fmul.4s	v3, v3, v3
     e40:      	fmul.4s	v2, v2, v2
     e44:      	and.16b	v12, v0, v2
     e48:      	and.16b	v11, v1, v3
     e4c:      	ldr	q2, [x19, #0x4050]
     e50:      	ldr	q3, [x19, #0x4040]
     e54:      	fmul.4s	v3, v3, v3
     e58:      	fmul.4s	v2, v2, v2
     e5c:      	and.16b	v13, v0, v2
     e60:      	and.16b	v14, v1, v3
     e64:      	add	x8, x11, x30
     e68:      	ldp	q3, q2, [x8]
     e6c:      	fmul.4s	v3, v3, v3
     e70:      	fmul.4s	v2, v2, v2
     e74:      	and.16b	v16, v0, v2
     e78:      	and.16b	v15, v1, v3
     e7c:      	sshll.2d	v2, v1, #0x0
     e80:      	sshll.2d	v3, v0, #0x0
     e84:      	add	x8, x11, x27, lsl #5
     e88:      	ldp	q6, q5, [x8]
     e8c:      	and.16b	v6, v1, v6
     e90:      	and.16b	v5, v0, v5
     e94:      	fmul.4s	v5, v5, v5
     e98:      	fmul.4s	v6, v6, v6
     e9c:      	fadd.4s	v23, v15, v6
     ea0:      	fadd.4s	v24, v16, v5
     ea4:      	ldp	q6, q5, [x8, #0x20]
     ea8:      	and.16b	v6, v1, v6
     eac:      	and.16b	v5, v0, v5
     eb0:      	fmul.4s	v5, v5, v5
     eb4:      	fmul.4s	v6, v6, v6
     eb8:      	fadd.4s	v6, v14, v6
     ebc:      	fadd.4s	v5, v13, v5
     ec0:      	ldp	q8, q7, [x8, #0x40]
     ec4:      	and.16b	v8, v1, v8
     ec8:      	and.16b	v7, v0, v7
     ecc:      	fmul.4s	v7, v7, v7
     ed0:      	fmul.4s	v8, v8, v8
     ed4:      	fadd.4s	v8, v11, v8
     ed8:      	fadd.4s	v7, v12, v7
     edc:      	ldp	q10, q31, [x8, #0x60]
     ee0:      	and.16b	v10, v1, v10
     ee4:      	and.16b	v31, v0, v31
     ee8:      	fmul.4s	v31, v31, v31
     eec:      	fmul.4s	v10, v10, v10
     ef0:      	fadd.4s	v10, v9, v10
     ef4:      	fadd.4s	v31, v30, v31
     ef8:      	dup.2d	v27, x26
     efc:      	and.16b	v21, v29, v27
     f00:      	add.2d	v26, v26, v21
     f04:      	and.16b	v21, v28, v27
     f08:      	add.2d	v22, v22, v21
     f0c:      	and.16b	v3, v3, v27
     f10:      	add.2d	v25, v25, v3
     f14:      	and.16b	v2, v2, v27
     f18:      	add.2d	v4, v4, v2
     f1c:      	bit.16b	v16, v24, v0
     f20:      	bit.16b	v15, v23, v1
     f24:      	bit.16b	v13, v5, v0
     f28:      	bit.16b	v14, v6, v1
     f2c:      	bit.16b	v12, v7, v0
     f30:      	bit.16b	v11, v8, v1
     f34:      	bit.16b	v30, v31, v0
     f38:      	bit.16b	v9, v10, v1
     f3c:      	fmov	x27, d4
     f40:      	cmp	x27, #0x200
     f44:      	b.lt	0xe7c <_llm_rows.packet_batch.blocks+0xb10>
     f48:      	mov	x8, #0x0                ; =0
     f4c:      	movi.2d	v4, #0000000000000000
     f50:      	movi.2d	v5, #0000000000000000
     f54:      	movi.2d	v6, #0000000000000000
     f58:      	movi.2d	v7, #0000000000000000
     f5c:      	ldr	q27, [sp, #0x1a0]
     f60:      	ldr	q31, [sp, #0x1d0]
     f64:      	ldr	x12, [sp, #0x138]
     f68:      	b	0xf9c <_llm_rows.packet_batch.blocks+0xc30>
     f6c:      	add	x8, x10, x8
     f70:      	ldp	q2, q3, [x8]
     f74:      	bit.16b	v3, v29, v0
     f78:      	bit.16b	v2, v28, v1
     f7c:      	stp	q2, q3, [x8]
     f80:      	add.2d	v5, v5, v18
     f84:      	add.2d	v6, v6, v19
     f88:      	add.2d	v7, v7, v17
     f8c:      	add.2d	v4, v4, v20
     f90:      	fmov	x8, d4
     f94:      	cmp	x8, #0x200
     f98:      	b.ge	0x1038 <_llm_rows.packet_batch.blocks+0xccc>
     f9c:      	fmov	w27, s27
     fa0:      	lsl	x8, x8, #5
     fa4:      	add	x19, x15, x8
     fa8:      	movi.2d	v28, #0000000000000000
     fac:      	movi.2d	v29, #0000000000000000
     fb0:      	tbnz	w27, #0x0, 0xfd8 <_llm_rows.packet_batch.blocks+0xc6c>
     fb4:      	and	w27, w27, #0xff
     fb8:      	tbnz	w27, #0x1, 0xfe4 <_llm_rows.packet_batch.blocks+0xc78>
     fbc:      	tbnz	w27, #0x2, 0xff0 <_llm_rows.packet_batch.blocks+0xc84>
     fc0:      	tbnz	w27, #0x3, 0xffc <_llm_rows.packet_batch.blocks+0xc90>
     fc4:      	tbnz	w27, #0x4, 0x1008 <_llm_rows.packet_batch.blocks+0xc9c>
     fc8:      	tbnz	w27, #0x5, 0x1014 <_llm_rows.packet_batch.blocks+0xca8>
     fcc:      	tbnz	w27, #0x6, 0x1020 <_llm_rows.packet_batch.blocks+0xcb4>
     fd0:      	tbz	w27, #0x7, 0xf6c <_llm_rows.packet_batch.blocks+0xc00>
     fd4:      	b	0x102c <_llm_rows.packet_batch.blocks+0xcc0>
     fd8:      	ldr	s28, [x19]
     fdc:      	and	w27, w27, #0xff
     fe0:      	tbz	w27, #0x1, 0xfbc <_llm_rows.packet_batch.blocks+0xc50>
     fe4:      	add	x17, x19, #0x4
     fe8:      	ld1.s	{ v28 }[1], [x17]
     fec:      	tbz	w27, #0x2, 0xfc0 <_llm_rows.packet_batch.blocks+0xc54>
     ff0:      	add	x17, x19, #0x8
     ff4:      	ld1.s	{ v28 }[2], [x17]
     ff8:      	tbz	w27, #0x3, 0xfc4 <_llm_rows.packet_batch.blocks+0xc58>
     ffc:      	add	x17, x19, #0xc
    1000:      	ld1.s	{ v28 }[3], [x17]
    1004:      	tbz	w27, #0x4, 0xfc8 <_llm_rows.packet_batch.blocks+0xc5c>
    1008:      	add	x17, x19, #0x10
    100c:      	ld1.s	{ v29 }[0], [x17]
    1010:      	tbz	w27, #0x5, 0xfcc <_llm_rows.packet_batch.blocks+0xc60>
    1014:      	add	x17, x19, #0x14
    1018:      	ld1.s	{ v29 }[1], [x17]
    101c:      	tbz	w27, #0x6, 0xfd0 <_llm_rows.packet_batch.blocks+0xc64>
    1020:      	add	x17, x19, #0x18
    1024:      	ld1.s	{ v29 }[2], [x17]
    1028:      	tbz	w27, #0x7, 0xf6c <_llm_rows.packet_batch.blocks+0xc00>
    102c:      	add	x17, x19, #0x1c
    1030:      	ld1.s	{ v29 }[3], [x17]
    1034:      	b	0xf6c <_llm_rows.packet_batch.blocks+0xc00>
    1038:      	mov	b2, v31[0]
    103c:      	mov.b	v2[4], v31[1]
    1040:      	ushll.2d	v2, v2, #0x0
    1044:      	shl.2d	v2, v2, #0x3f
    1048:      	cmlt.2d	v2, v2, #0
    104c:      	mov	b3, v31[2]
    1050:      	mov.b	v3[4], v31[3]
    1054:      	ldp	q6, q4, [sp, #0x90]
    1058:      	and.16b	v2, v2, v4
    105c:      	ushll.2d	v3, v3, #0x0
    1060:      	shl.2d	v3, v3, #0x3f
    1064:      	cmlt.2d	v3, v3, #0
    1068:      	ldp	q4, q5, [sp, #0x70]
    106c:      	and.16b	v3, v3, v4
    1070:      	mov	b4, v31[4]
    1074:      	mov.b	v4[4], v31[5]
    1078:      	ushll.2d	v4, v4, #0x0
    107c:      	shl.2d	v4, v4, #0x3f
    1080:      	cmlt.2d	v4, v4, #0
    1084:      	and.16b	v4, v4, v5
    1088:      	mov	b5, v31[6]
    108c:      	mov.b	v5[4], v31[7]
    1090:      	ushll.2d	v5, v5, #0x0
    1094:      	shl.2d	v5, v5, #0x3f
    1098:      	cmlt.2d	v5, v5, #0
    109c:      	and.16b	v5, v5, v6
    10a0:      	shl.8b	v6, v31, #0x7
    10a4:      	cmlt.8b	v6, v6, #0
    10a8:      	ldr	d7, [sp, #0xb0]
    10ac:      	and.8b	v6, v6, v7
    10b0:      	addv.8b	b22, v6
    10b4:      	str	q5, [sp, #0x4c0]
    10b8:      	str	q4, [sp, #0x4b0]
    10bc:      	str	q3, [sp, #0x4a0]
    10c0:      	str	q2, [sp, #0x490]
    10c4:      	and	x8, x12, #0x7
    10c8:      	add	x17, sp, #0x490
    10cc:      	ldr	x17, [x17, x8, lsl #3]
    10d0:      	fmov	w8, s22
    10d4:      	sub	x17, x17, x12
    10d8:      	lsl	x19, x17, #2
    10dc:      	add	x15, x15, x19
    10e0:      	movi.2d	v4, #0000000000000000
    10e4:      	movi.2d	v5, #0000000000000000
    10e8:      	tbnz	w8, #0x0, 0x1950 <_llm_rows.packet_batch.blocks+0x15e4>
    10ec:      	tbnz	w8, #0x1, 0x1958 <_llm_rows.packet_batch.blocks+0x15ec>
    10f0:      	tbnz	w8, #0x2, 0x1964 <_llm_rows.packet_batch.blocks+0x15f8>
    10f4:      	tbnz	w8, #0x3, 0x1970 <_llm_rows.packet_batch.blocks+0x1604>
    10f8:      	tbnz	w8, #0x4, 0x197c <_llm_rows.packet_batch.blocks+0x1610>
    10fc:      	tbnz	w8, #0x5, 0x1988 <_llm_rows.packet_batch.blocks+0x161c>
    1100:      	tbnz	w8, #0x6, 0x1994 <_llm_rows.packet_batch.blocks+0x1628>
    1104:      	tbz	w8, #0x7, 0x1110 <_llm_rows.packet_batch.blocks+0xda4>
    1108:      	add	x8, x15, #0x1c
    110c:      	ld1.s	{ v5 }[3], [x8]
    1110:      	mov	x8, #0x0                ; =0
    1114:      	add	x15, x10, x14
    1118:      	ldp	q2, q3, [x15]
    111c:      	zip2.8b	v6, v31, v0
    1120:      	ushll.4s	v6, v6, #0x0
    1124:      	shl.4s	v6, v6, #0x1f
    1128:      	cmlt.4s	v6, v6, #0
    112c:      	bit.16b	v3, v5, v6
    1130:      	zip1.8b	v5, v31, v0
    1134:      	ushll.4s	v5, v5, #0x0
    1138:      	shl.4s	v5, v5, #0x1f
    113c:      	cmlt.4s	v5, v5, #0
    1140:      	bit.16b	v2, v4, v5
    1144:      	stp	q2, q3, [x15]
    1148:      	movi.2d	v4, #0000000000000000
    114c:      	movi.2d	v5, #0000000000000000
    1150:      	movi.2d	v6, #0000000000000000
    1154:      	movi.2d	v7, #0000000000000000
    1158:      	b	0x118c <_llm_rows.packet_batch.blocks+0xe20>
    115c:      	add	x8, x9, x8
    1160:      	ldp	q2, q3, [x8]
    1164:      	bit.16b	v3, v26, v0
    1168:      	bit.16b	v2, v25, v1
    116c:      	stp	q2, q3, [x8]
    1170:      	add.2d	v5, v5, v18
    1174:      	add.2d	v6, v6, v19
    1178:      	add.2d	v7, v7, v17
    117c:      	add.2d	v4, v4, v20
    1180:      	fmov	x8, d4
    1184:      	cmp	x8, #0x200
    1188:      	b.ge	0x1228 <_llm_rows.packet_batch.blocks+0xebc>
    118c:      	fmov	w27, s27
    1190:      	lsl	x8, x8, #5
    1194:      	add	x15, x13, x8
    1198:      	movi.2d	v25, #0000000000000000
    119c:      	movi.2d	v26, #0000000000000000
    11a0:      	tbnz	w27, #0x0, 0x11c8 <_llm_rows.packet_batch.blocks+0xe5c>
    11a4:      	and	w27, w27, #0xff
    11a8:      	tbnz	w27, #0x1, 0x11d4 <_llm_rows.packet_batch.blocks+0xe68>
    11ac:      	tbnz	w27, #0x2, 0x11e0 <_llm_rows.packet_batch.blocks+0xe74>
    11b0:      	tbnz	w27, #0x3, 0x11ec <_llm_rows.packet_batch.blocks+0xe80>
    11b4:      	tbnz	w27, #0x4, 0x11f8 <_llm_rows.packet_batch.blocks+0xe8c>
    11b8:      	tbnz	w27, #0x5, 0x1204 <_llm_rows.packet_batch.blocks+0xe98>
    11bc:      	tbnz	w27, #0x6, 0x1210 <_llm_rows.packet_batch.blocks+0xea4>
    11c0:      	tbz	w27, #0x7, 0x115c <_llm_rows.packet_batch.blocks+0xdf0>
    11c4:      	b	0x121c <_llm_rows.packet_batch.blocks+0xeb0>
    11c8:      	ldr	s25, [x15]
    11cc:      	and	w27, w27, #0xff
    11d0:      	tbz	w27, #0x1, 0x11ac <_llm_rows.packet_batch.blocks+0xe40>
    11d4:      	add	x17, x15, #0x4
    11d8:      	ld1.s	{ v25 }[1], [x17]
    11dc:      	tbz	w27, #0x2, 0x11b0 <_llm_rows.packet_batch.blocks+0xe44>
    11e0:      	add	x17, x15, #0x8
    11e4:      	ld1.s	{ v25 }[2], [x17]
    11e8:      	tbz	w27, #0x3, 0x11b4 <_llm_rows.packet_batch.blocks+0xe48>
    11ec:      	add	x17, x15, #0xc
    11f0:      	ld1.s	{ v25 }[3], [x17]
    11f4:      	tbz	w27, #0x4, 0x11b8 <_llm_rows.packet_batch.blocks+0xe4c>
    11f8:      	add	x17, x15, #0x10
    11fc:      	ld1.s	{ v26 }[0], [x17]
    1200:      	tbz	w27, #0x5, 0x11bc <_llm_rows.packet_batch.blocks+0xe50>
    1204:      	add	x17, x15, #0x14
    1208:      	ld1.s	{ v26 }[1], [x17]
    120c:      	tbz	w27, #0x6, 0x11c0 <_llm_rows.packet_batch.blocks+0xe54>
    1210:      	add	x17, x15, #0x18
    1214:      	ld1.s	{ v26 }[2], [x17]
    1218:      	tbz	w27, #0x7, 0x115c <_llm_rows.packet_batch.blocks+0xdf0>
    121c:      	add	x15, x15, #0x1c
    1220:      	ld1.s	{ v26 }[3], [x15]
    1224:      	b	0x115c <_llm_rows.packet_batch.blocks+0xdf0>
    1228:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0xc94>
    122c:      	ldr	q2, [x8]
    1230:      	and.16b	v5, v0, v2
    1234:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0xc94>
    1238:      	ldr	q2, [x8]
    123c:      	and.16b	v25, v1, v2
    1240:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0xc94>
    1244:      	ldr	q4, [x8]
    1248:      	zip2.8b	v2, v31, v0
    124c:      	ushll.4s	v2, v2, #0x0
    1250:      	shl.4s	v2, v2, #0x1f
    1254:      	cmlt.4s	v2, v2, #0
    1258:      	ldp	q3, q7, [sp, #0x40]
    125c:      	and.16b	v3, v2, v3
    1260:      	zip1.8b	v6, v31, v0
    1264:      	ushll.4s	v6, v6, #0x0
    1268:      	shl.4s	v6, v6, #0x1f
    126c:      	cmlt.4s	v6, v6, #0
    1270:      	and.16b	v7, v6, v7
    1274:      	fmul.4s	v7, v7, v7
    1278:      	fmul.4s	v3, v3, v3
    127c:      	fadd.4s	v3, v3, v16
    1280:      	fadd.4s	v7, v7, v15
    1284:      	and.16b	v6, v6, v7
    1288:      	and.16b	v2, v2, v3
    128c:      	ldr	q7, [sp, #0x60]
    1290:      	zip2.8b	v3, v7, v0
    1294:      	ushll.4s	v3, v3, #0x0
    1298:      	shl.4s	v3, v3, #0x1f
    129c:      	cmlt.4s	v3, v3, #0
    12a0:      	bit.16b	v2, v24, v3
    12a4:      	zip1.8b	v3, v7, v0
    12a8:      	ushll.4s	v3, v3, #0x0
    12ac:      	shl.4s	v3, v3, #0x1f
    12b0:      	cmlt.4s	v3, v3, #0
    12b4:      	bsl.16b	v3, v23, v6
    12b8:      	fadd.4s	v3, v14, v3
    12bc:      	fadd.4s	v2, v13, v2
    12c0:      	fadd.4s	v2, v12, v2
    12c4:      	fadd.4s	v3, v11, v3
    12c8:      	fadd.4s	v6, v9, v3
    12cc:      	fadd.4s	v7, v30, v2
    12d0:      	fmov	w8, s25
    12d4:      	add	x15, sp, #0x238
    12d8:      	bfxil	x15, x8, #0, #3
    12dc:      	ldr	q2, [sp, #0x110]
    12e0:      	str	d2, [sp, #0x238]
    12e4:      	ldrb	w15, [x15]
    12e8:      	add	x17, sp, #0x460
    12ec:      	orr	x8, x17, x8, lsl #2
    12f0:      	str	q7, [sp, #0x470]
    12f4:      	str	q6, [sp, #0x460]
    12f8:      	ldr	s2, [x8]
    12fc:      	tst	w7, w15
    1300:      	movi	d26, #0000000000000000
    1304:      	fcsel	s16, s2, s26, ne
    1308:      	mov.s	w8, v25[1]
    130c:      	add	x15, sp, #0x238
    1310:      	bfxil	x15, x8, #0, #3
    1314:      	ldrb	w8, [x15]
    1318:      	ldr	w14, [sp, #0x120]
    131c:      	and	w8, w14, w8
    1320:      	str	q6, [sp, #0x440]
    1324:      	ldr	s2, [sp, #0x440]
    1328:      	tst	w8, #0x1
    132c:      	mov.s	w8, v25[2]
    1330:      	fcsel	s21, s2, s26, ne
    1334:      	add	x15, sp, #0x238
    1338:      	bfxil	x15, x8, #0, #3
    133c:      	add	x17, sp, #0x420
    1340:      	orr	x8, x17, x8, lsl #2
    1344:      	ldrb	w15, [x15]
    1348:      	ldr	w0, [sp, #0x140]
    134c:      	and	w15, w0, w15
    1350:      	str	q7, [sp, #0x430]
    1354:      	str	q6, [sp, #0x420]
    1358:      	ldr	s2, [x8]
    135c:      	tst	w15, #0x1
    1360:      	mov.s	w8, v25[3]
    1364:      	fcsel	s23, s2, s26, ne
    1368:      	add	x15, sp, #0x238
    136c:      	bfxil	x15, x8, #0, #3
    1370:      	add	x17, sp, #0x400
    1374:      	orr	x8, x17, x8, lsl #2
    1378:      	ldrb	w15, [x15]
    137c:      	and	w15, w1, w15
    1380:      	str	q7, [sp, #0x410]
    1384:      	str	q6, [sp, #0x400]
    1388:      	ldr	s2, [x8]
    138c:      	tst	w15, #0x1
    1390:      	fcsel	s24, s2, s26, ne
    1394:      	fmov	w8, s5
    1398:      	add	x15, sp, #0x238
    139c:      	bfxil	x15, x8, #0, #3
    13a0:      	ldrb	w15, [x15]
    13a4:      	and	w15, w6, w15
    13a8:      	stp	q6, q7, [sp, #0x3e0]
    13ac:      	add	x17, sp, #0x3e0
    13b0:      	ldr	s2, [x17, w8, uxtw #2]
    13b4:      	tst	w15, #0x1
    13b8:      	fcsel	s2, s2, s26, ne
    13bc:      	mov.s	w8, v5[1]
    13c0:      	add	x15, sp, #0x238
    13c4:      	bfxil	x15, x8, #0, #3
    13c8:      	ldrb	w15, [x15]
    13cc:      	and	w15, w3, w15
    13d0:      	stp	q6, q7, [sp, #0x3c0]
    13d4:      	add	x17, sp, #0x3c0
    13d8:      	ldr	s3, [x17, w8, uxtw #2]
    13dc:      	tst	w15, #0x1
    13e0:      	fcsel	s3, s3, s26, ne
    13e4:      	mov.s	w8, v5[2]
    13e8:      	add	x15, sp, #0x238
    13ec:      	bfxil	x15, x8, #0, #3
    13f0:      	ldrb	w15, [x15]
    13f4:      	and	w15, w4, w15
    13f8:      	stp	q6, q7, [sp, #0x3a0]
    13fc:      	add	x17, sp, #0x3a0
    1400:      	ldr	s25, [x17, w8, uxtw #2]
    1404:      	tst	w15, #0x1
    1408:      	fcsel	s25, s25, s26, ne
    140c:      	mov.s	w8, v5[3]
    1410:      	add	x15, sp, #0x238
    1414:      	bfxil	x15, x8, #0, #3
    1418:      	ldrb	w15, [x15]
    141c:      	and	w15, w5, w15
    1420:      	stp	q6, q7, [sp, #0x380]
    1424:      	add	x17, sp, #0x380
    1428:      	ldr	s5, [x17, w8, uxtw #2]
    142c:      	tst	w15, #0x1
    1430:      	fcsel	s5, s5, s26, ne
    1434:      	mov.s	v2[1], v3[0]
    1438:      	mov.s	v2[2], v25[0]
    143c:      	mov.s	v2[3], v5[0]
    1440:      	mov.s	v16[1], v21[0]
    1444:      	and.16b	v3, v1, v4
    1448:      	mov.s	v16[2], v23[0]
    144c:      	mov.s	v16[3], v24[0]
    1450:      	fadd.4s	v4, v6, v16
    1454:      	fadd.4s	v5, v7, v2
    1458:      	fmov	w8, s3
    145c:      	add	x15, sp, #0x238
    1460:      	bfxil	x15, x8, #0, #3
    1464:      	ldrb	w15, [x15]
    1468:      	add	x17, sp, #0x360
    146c:      	orr	x8, x17, x8, lsl #2
    1470:      	stp	q4, q5, [sp, #0x360]
    1474:      	ldr	s2, [x8]
    1478:      	tst	w7, w15
    147c:      	mov.s	w8, v3[1]
    1480:      	add	x15, sp, #0x238
    1484:      	bfxil	x15, x8, #0, #3
    1488:      	ldrb	w15, [x15]
    148c:      	and	w15, w14, w15
    1490:      	fcsel	s6, s2, s26, ne
    1494:      	add	x17, sp, #0x340
    1498:      	orr	x8, x17, x8, lsl #2
    149c:      	stp	q4, q5, [sp, #0x340]
    14a0:      	ldr	s2, [x8]
    14a4:      	tst	w15, #0x1
    14a8:      	mov.s	w8, v3[2]
    14ac:      	add	x15, sp, #0x238
    14b0:      	bfxil	x15, x8, #0, #3
    14b4:      	fcsel	s7, s2, s26, ne
    14b8:      	ldrb	w8, [x15]
    14bc:      	and	w8, w0, w8
    14c0:      	str	q4, [sp, #0x320]
    14c4:      	tst	w8, #0x1
    14c8:      	mov.s	w8, v3[3]
    14cc:      	add	x15, sp, #0x238
    14d0:      	bfxil	x15, x8, #0, #3
    14d4:      	ldrb	w15, [x15]
    14d8:      	and	w15, w1, w15
    14dc:      	adrp	x17, 0x1000 <_llm_rows.packet_batch.blocks+0xc94>
    14e0:      	ldr	q2, [x17]
    14e4:      	and.16b	v2, v0, v2
    14e8:      	ldr	s3, [sp, #0x320]
    14ec:      	fcsel	s21, s3, s26, ne
    14f0:      	add	x17, sp, #0x300
    14f4:      	orr	x8, x17, x8, lsl #2
    14f8:      	stp	q4, q5, [sp, #0x300]
    14fc:      	ldr	s3, [x8]
    1500:      	tst	w15, #0x1
    1504:      	fmov	w8, s2
    1508:      	add	x15, sp, #0x238
    150c:      	bfxil	x15, x8, #0, #3
    1510:      	ldrb	w15, [x15]
    1514:      	and	w15, w6, w15
    1518:      	fcsel	s16, s3, s26, ne
    151c:      	stp	q4, q5, [sp, #0x2e0]
    1520:      	add	x17, sp, #0x2e0
    1524:      	ldr	s3, [x17, w8, uxtw #2]
    1528:      	tst	w15, #0x1
    152c:      	mov.s	w8, v2[1]
    1530:      	add	x15, sp, #0x238
    1534:      	bfxil	x15, x8, #0, #3
    1538:      	ldrb	w15, [x15]
    153c:      	and	w15, w3, w15
    1540:      	fcsel	s3, s3, s26, ne
    1544:      	stp	q4, q5, [sp, #0x2c0]
    1548:      	add	x17, sp, #0x2c0
    154c:      	ldr	s23, [x17, w8, uxtw #2]
    1550:      	tst	w15, #0x1
    1554:      	mov.s	w8, v2[2]
    1558:      	add	x15, sp, #0x238
    155c:      	bfxil	x15, x8, #0, #3
    1560:      	ldrb	w15, [x15]
    1564:      	and	w15, w4, w15
    1568:      	fcsel	s23, s23, s26, ne
    156c:      	stp	q4, q5, [sp, #0x2a0]
    1570:      	add	x17, sp, #0x2a0
    1574:      	ldr	s24, [x17, w8, uxtw #2]
    1578:      	tst	w15, #0x1
    157c:      	mov.s	w8, v2[3]
    1580:      	add	x15, sp, #0x238
    1584:      	bfxil	x15, x8, #0, #3
    1588:      	ldrb	w15, [x15]
    158c:      	and	w15, w5, w15
    1590:      	fcsel	s2, s24, s26, ne
    1594:      	stp	q4, q5, [sp, #0x280]
    1598:      	add	x17, sp, #0x280
    159c:      	ldr	s24, [x17, w8, uxtw #2]
    15a0:      	tst	w15, #0x1
    15a4:      	fcsel	s24, s24, s26, ne
    15a8:      	mov.s	v3[1], v23[0]
    15ac:      	mov.s	v3[2], v2[0]
    15b0:      	mov.s	v3[3], v24[0]
    15b4:      	mov.s	v6[1], v7[0]
    15b8:      	movi.4s	v2, #0x4
    15bc:      	and.16b	v2, v1, v2
    15c0:      	mov.s	v6[2], v21[0]
    15c4:      	fmov	w8, s2
    15c8:      	add	x15, sp, #0x238
    15cc:      	orr	x15, x15, x8
    15d0:      	ldrb	w15, [x15]
    15d4:      	tst	w7, w15
    15d8:      	mov.s	v6[3], v16[0]
    15dc:      	fadd.4s	v2, v4, v6
    15e0:      	fadd.4s	v3, v5, v3
    15e4:      	stp	q2, q3, [sp, #0x260]
    15e8:      	add	x15, sp, #0x260
    15ec:      	ldr	s3, [x15, w8, uxtw #2]
    15f0:      	fcsel	s3, s3, s26, ne
    15f4:      	tst	w16, #0x1
    15f8:      	fadd	s2, s2, s3
    15fc:      	fcsel	s3, s2, s26, ne
    1600:      	ldr	w8, [sp, #0x100]
    1604:      	tst	w8, #0x1
    1608:      	fcsel	s4, s2, s26, ne
    160c:      	ldr	w8, [sp, #0xf0]
    1610:      	tst	w8, #0x1
    1614:      	fcsel	s5, s2, s26, ne
    1618:      	ldr	w8, [sp, #0xe0]
    161c:      	tst	w8, #0x1
    1620:      	fcsel	s6, s2, s26, ne
    1624:      	tst	w2, #0x1
    1628:      	fcsel	s7, s2, s26, ne
    162c:      	ldr	w8, [sp, #0xd0]
    1630:      	tst	w8, #0x1
    1634:      	fcsel	s16, s2, s26, ne
    1638:      	ldr	w8, [sp, #0xbc]
    163c:      	tst	w8, #0x1
    1640:      	fcsel	s21, s2, s26, ne
    1644:      	ldr	w8, [sp, #0xb8]
    1648:      	tst	w8, #0x1
    164c:      	mov.s	v3[1], v4[0]
    1650:      	mov.s	v3[2], v5[0]
    1654:      	mov.s	v3[3], v6[0]
    1658:      	mov.s	v7[1], v16[0]
    165c:      	mov.s	v7[2], v21[0]
    1660:      	movi	d16, #0000000000000000
    1664:      	fcsel	s2, s2, s26, ne
    1668:      	mov.s	v7[3], v2[0]
    166c:      	stp	q3, q7, [sp, #0x240]
    1670:      	ldr	x8, [sp, #0xc0]
    1674:      	and	x8, x8, #0x7
    1678:      	add	x15, sp, #0x240
    167c:      	ldr	s6, [x15, x8, lsl #2]
    1680:      	add	x8, x13, x19
    1684:      	fmov	w13, s22
    1688:      	movi.2d	v4, #0000000000000000
    168c:      	movi.2d	v5, #0000000000000000
    1690:      	tbnz	w13, #0x0, 0x19a4 <_llm_rows.packet_batch.blocks+0x1638>
    1694:      	ldr	x17, [sp, #0x1b8]
    1698:      	tbnz	w13, #0x1, 0x19b0 <_llm_rows.packet_batch.blocks+0x1644>
    169c:      	ldr	x14, [sp, #0x1c8]
    16a0:      	tbnz	w13, #0x2, 0x19c0 <_llm_rows.packet_batch.blocks+0x1654>
    16a4:      	tbnz	w13, #0x3, 0x19cc <_llm_rows.packet_batch.blocks+0x1660>
    16a8:      	tbnz	w13, #0x4, 0x19d8 <_llm_rows.packet_batch.blocks+0x166c>
    16ac:      	tbnz	w13, #0x5, 0x19e4 <_llm_rows.packet_batch.blocks+0x1678>
    16b0:      	tbnz	w13, #0x6, 0x19f0 <_llm_rows.packet_batch.blocks+0x1684>
    16b4:      	tbz	w13, #0x7, 0x16c0 <_llm_rows.packet_batch.blocks+0x1354>
    16b8:      	add	x8, x8, #0x1c
    16bc:      	ld1.s	{ v5 }[3], [x8]
    16c0:      	mov	x13, #0x0               ; =0
    16c4:      	fadd	s2, s6, s16
    16c8:      	mov	w8, #0x800              ; =2048
    16cc:      	movk	w8, #0x4580, lsl #16
    16d0:      	fmov	s3, w8
    16d4:      	fdiv	s2, s2, s3
    16d8:      	mov	w8, #0xc5ac             ; =50604
    16dc:      	movk	w8, #0x3727, lsl #16
    16e0:      	fmov	s3, w8
    16e4:      	fadd	s2, s2, s3
    16e8:      	fsqrt	s2, s2
    16ec:      	add	x8, x9, x14
    16f0:      	ldp	q3, q6, [x8]
    16f4:      	zip2.8b	v7, v31, v0
    16f8:      	ushll.4s	v7, v7, #0x0
    16fc:      	shl.4s	v7, v7, #0x1f
    1700:      	cmlt.4s	v7, v7, #0
    1704:      	bif.16b	v5, v6, v7
    1708:      	zip1.8b	v6, v31, v0
    170c:      	ushll.4s	v6, v6, #0x0
    1710:      	shl.4s	v6, v6, #0x1f
    1714:      	cmlt.4s	v6, v6, #0
    1718:      	bit.16b	v3, v4, v6
    171c:      	stp	q3, q5, [x8]
    1720:      	dup.4s	v4, v2[0]
    1724:      	ldr	q2, [sp, #0x150]
    1728:      	fmov	x8, d2
    172c:      	add	x8, x17, x8, lsl #2
    1730:      	movi.2d	v5, #0000000000000000
    1734:      	movi.2d	v6, #0000000000000000
    1738:      	movi.2d	v7, #0000000000000000
    173c:      	movi.2d	v16, #0000000000000000
    1740:      	b	0x1760 <_llm_rows.packet_batch.blocks+0x13f4>
    1744:      	add.2d	v6, v6, v18
    1748:      	add.2d	v7, v7, v19
    174c:      	add.2d	v16, v16, v17
    1750:      	add.2d	v5, v5, v20
    1754:      	fmov	x13, d5
    1758:      	cmp	x13, #0x200
    175c:      	b.ge	0x1838 <_llm_rows.packet_batch.blocks+0x14cc>
    1760:      	fmov	w15, s27
    1764:      	lsl	x13, x13, #5
    1768:      	add	x16, x11, x13
    176c:      	ldp	q2, q21, [x16]
    1770:      	and.16b	v2, v1, v2
    1774:      	fdiv.4s	v2, v2, v4
    1778:      	add	x16, x10, x13
    177c:      	ldp	q3, q23, [x16]
    1780:      	and.16b	v3, v1, v3
    1784:      	fmul.4s	v2, v2, v3
    1788:      	add	x16, x9, x13
    178c:      	ldp	q3, q24, [x16]
    1790:      	and.16b	v3, v1, v3
    1794:      	fadd.4s	v25, v2, v3
    1798:      	add	x13, x8, x13
    179c:      	tbnz	w15, #0x0, 0x17e4 <_llm_rows.packet_batch.blocks+0x1478>
    17a0:      	and	w15, w15, #0xff
    17a4:      	tbnz	w15, #0x1, 0x17f0 <_llm_rows.packet_batch.blocks+0x1484>
    17a8:      	tbnz	w15, #0x2, 0x17fc <_llm_rows.packet_batch.blocks+0x1490>
    17ac:      	tbz	w15, #0x3, 0x17b8 <_llm_rows.packet_batch.blocks+0x144c>
    17b0:      	add	x16, x13, #0xc
    17b4:      	st1.s	{ v25 }[3], [x16]
    17b8:      	and.16b	v2, v0, v21
    17bc:      	fdiv.4s	v2, v2, v4
    17c0:      	and.16b	v3, v0, v23
    17c4:      	fmul.4s	v2, v2, v3
    17c8:      	and.16b	v3, v0, v24
    17cc:      	fadd.4s	v21, v2, v3
    17d0:      	tbnz	w15, #0x4, 0x180c <_llm_rows.packet_batch.blocks+0x14a0>
    17d4:      	tbnz	w15, #0x5, 0x1814 <_llm_rows.packet_batch.blocks+0x14a8>
    17d8:      	tbnz	w15, #0x6, 0x1820 <_llm_rows.packet_batch.blocks+0x14b4>
    17dc:      	tbz	w15, #0x7, 0x1744 <_llm_rows.packet_batch.blocks+0x13d8>
    17e0:      	b	0x182c <_llm_rows.packet_batch.blocks+0x14c0>
    17e4:      	str	s25, [x13]
    17e8:      	and	w15, w15, #0xff
    17ec:      	tbz	w15, #0x1, 0x17a8 <_llm_rows.packet_batch.blocks+0x143c>
    17f0:      	add	x16, x13, #0x4
    17f4:      	st1.s	{ v25 }[1], [x16]
    17f8:      	tbz	w15, #0x2, 0x17ac <_llm_rows.packet_batch.blocks+0x1440>
    17fc:      	add	x16, x13, #0x8
    1800:      	st1.s	{ v25 }[2], [x16]
    1804:      	tbnz	w15, #0x3, 0x17b0 <_llm_rows.packet_batch.blocks+0x1444>
    1808:      	b	0x17b8 <_llm_rows.packet_batch.blocks+0x144c>
    180c:      	str	s21, [x13, #0x10]
    1810:      	tbz	w15, #0x5, 0x17d8 <_llm_rows.packet_batch.blocks+0x146c>
    1814:      	add	x16, x13, #0x14
    1818:      	st1.s	{ v21 }[1], [x16]
    181c:      	tbz	w15, #0x6, 0x17dc <_llm_rows.packet_batch.blocks+0x1470>
    1820:      	add	x16, x13, #0x18
    1824:      	st1.s	{ v21 }[2], [x16]
    1828:      	tbz	w15, #0x7, 0x1744 <_llm_rows.packet_batch.blocks+0x13d8>
    182c:      	add	x13, x13, #0x1c
    1830:      	st1.s	{ v21 }[3], [x13]
    1834:      	b	0x1744 <_llm_rows.packet_batch.blocks+0x13d8>
    1838:      	add	x8, x11, x14
    183c:      	ldp	q1, q0, [x8]
    1840:      	zip1.8b	v2, v31, v0
    1844:      	ushll.4s	v2, v2, #0x0
    1848:      	shl.4s	v2, v2, #0x1f
    184c:      	cmlt.4s	v3, v2, #0
    1850:      	and.16b	v1, v3, v1
    1854:      	fmov	w8, s22
    1858:      	fdiv.4s	v2, v1, v4
    185c:      	add	x10, x10, x14
    1860:      	ldp	q5, q1, [x10]
    1864:      	and.16b	v5, v3, v5
    1868:      	fmul.4s	v5, v2, v5
    186c:      	add	x9, x9, x14
    1870:      	ldp	q6, q2, [x9]
    1874:      	and.16b	v3, v3, v6
    1878:      	fadd.4s	v5, v5, v3
    187c:      	ldr	q6, [sp, #0x190]
    1880:      	ldp	q3, q7, [sp, #0x160]
    1884:      	stp	q6, q7, [sp, #0x1f0]
    1888:      	str	q3, [sp, #0x210]
    188c:      	ldr	q3, [sp, #0x180]
    1890:      	str	q3, [sp, #0x220]
    1894:      	and	x9, x12, #0x7
    1898:      	add	x10, sp, #0x1f0
    189c:      	ldr	x9, [x10, x9, lsl #3]
    18a0:      	sub	x9, x9, x12
    18a4:      	add	x9, x17, x9, lsl #2
    18a8:      	tbnz	w8, #0x0, 0x1a00 <_llm_rows.packet_batch.blocks+0x1694>
    18ac:      	tbnz	w8, #0x1, 0x1a08 <_llm_rows.packet_batch.blocks+0x169c>
    18b0:      	tbnz	w8, #0x2, 0x1a14 <_llm_rows.packet_batch.blocks+0x16a8>
    18b4:      	tbz	w8, #0x3, 0x18c0 <_llm_rows.packet_batch.blocks+0x1554>
    18b8:      	add	x10, x9, #0xc
    18bc:      	st1.s	{ v5 }[3], [x10]
    18c0:      	zip2.8b	v3, v31, v0
    18c4:      	ushll.4s	v3, v3, #0x0
    18c8:      	shl.4s	v3, v3, #0x1f
    18cc:      	cmlt.4s	v3, v3, #0
    18d0:      	and.16b	v0, v3, v0
    18d4:      	fdiv.4s	v0, v0, v4
    18d8:      	and.16b	v1, v3, v1
    18dc:      	fmul.4s	v0, v0, v1
    18e0:      	and.16b	v1, v3, v2
    18e4:      	fadd.4s	v0, v0, v1
    18e8:      	tbnz	w8, #0x4, 0x1a24 <_llm_rows.packet_batch.blocks+0x16b8>
    18ec:      	tbnz	w8, #0x5, 0x1a2c <_llm_rows.packet_batch.blocks+0x16c0>
    18f0:      	tbnz	w8, #0x6, 0x1a38 <_llm_rows.packet_batch.blocks+0x16cc>
    18f4:      	tbz	w8, #0x7, 0x3f0 <_llm_rows.packet_batch.blocks+0x84>
    18f8:      	b	0x1a44 <_llm_rows.packet_batch.blocks+0x16d8>
    18fc:      	ldr	s19, [x8]
    1900:      	tbz	w14, #0x1, 0x744 <_llm_rows.packet_batch.blocks+0x3d8>
    1904:      	add	x16, x8, #0x4
    1908:      	ld1.s	{ v19 }[1], [x16]
    190c:      	tbz	w14, #0x2, 0x748 <_llm_rows.packet_batch.blocks+0x3dc>
    1910:      	add	x16, x8, #0x8
    1914:      	ld1.s	{ v19 }[2], [x16]
    1918:      	tbz	w14, #0x3, 0x74c <_llm_rows.packet_batch.blocks+0x3e0>
    191c:      	add	x16, x8, #0xc
    1920:      	ld1.s	{ v19 }[3], [x16]
    1924:      	tbz	w14, #0x4, 0x750 <_llm_rows.packet_batch.blocks+0x3e4>
    1928:      	add	x16, x8, #0x10
    192c:      	ld1.s	{ v8 }[0], [x16]
    1930:      	tbz	w14, #0x5, 0x754 <_llm_rows.packet_batch.blocks+0x3e8>
    1934:      	add	x16, x8, #0x14
    1938:      	ld1.s	{ v8 }[1], [x16]
    193c:      	tbz	w14, #0x6, 0x758 <_llm_rows.packet_batch.blocks+0x3ec>
    1940:      	add	x16, x8, #0x18
    1944:      	ld1.s	{ v8 }[2], [x16]
    1948:      	tbnz	w14, #0x7, 0x75c <_llm_rows.packet_batch.blocks+0x3f0>
    194c:      	b	0x764 <_llm_rows.packet_batch.blocks+0x3f8>
    1950:      	ldr	s4, [x15]
    1954:      	tbz	w8, #0x1, 0x10f0 <_llm_rows.packet_batch.blocks+0xd84>
    1958:      	add	x17, x15, #0x4
    195c:      	ld1.s	{ v4 }[1], [x17]
    1960:      	tbz	w8, #0x2, 0x10f4 <_llm_rows.packet_batch.blocks+0xd88>
    1964:      	add	x17, x15, #0x8
    1968:      	ld1.s	{ v4 }[2], [x17]
    196c:      	tbz	w8, #0x3, 0x10f8 <_llm_rows.packet_batch.blocks+0xd8c>
    1970:      	add	x17, x15, #0xc
    1974:      	ld1.s	{ v4 }[3], [x17]
    1978:      	tbz	w8, #0x4, 0x10fc <_llm_rows.packet_batch.blocks+0xd90>
    197c:      	add	x17, x15, #0x10
    1980:      	ld1.s	{ v5 }[0], [x17]
    1984:      	tbz	w8, #0x5, 0x1100 <_llm_rows.packet_batch.blocks+0xd94>
    1988:      	add	x17, x15, #0x14
    198c:      	ld1.s	{ v5 }[1], [x17]
    1990:      	tbz	w8, #0x6, 0x1104 <_llm_rows.packet_batch.blocks+0xd98>
    1994:      	add	x17, x15, #0x18
    1998:      	ld1.s	{ v5 }[2], [x17]
    199c:      	tbnz	w8, #0x7, 0x1108 <_llm_rows.packet_batch.blocks+0xd9c>
    19a0:      	b	0x1110 <_llm_rows.packet_batch.blocks+0xda4>
    19a4:      	ldr	s4, [x8]
    19a8:      	ldr	x17, [sp, #0x1b8]
    19ac:      	tbz	w13, #0x1, 0x169c <_llm_rows.packet_batch.blocks+0x1330>
    19b0:      	add	x15, x8, #0x4
    19b4:      	ld1.s	{ v4 }[1], [x15]
    19b8:      	ldr	x14, [sp, #0x1c8]
    19bc:      	tbz	w13, #0x2, 0x16a4 <_llm_rows.packet_batch.blocks+0x1338>
    19c0:      	add	x15, x8, #0x8
    19c4:      	ld1.s	{ v4 }[2], [x15]
    19c8:      	tbz	w13, #0x3, 0x16a8 <_llm_rows.packet_batch.blocks+0x133c>
    19cc:      	add	x15, x8, #0xc
    19d0:      	ld1.s	{ v4 }[3], [x15]
    19d4:      	tbz	w13, #0x4, 0x16ac <_llm_rows.packet_batch.blocks+0x1340>
    19d8:      	add	x15, x8, #0x10
    19dc:      	ld1.s	{ v5 }[0], [x15]
    19e0:      	tbz	w13, #0x5, 0x16b0 <_llm_rows.packet_batch.blocks+0x1344>
    19e4:      	add	x15, x8, #0x14
    19e8:      	ld1.s	{ v5 }[1], [x15]
    19ec:      	tbz	w13, #0x6, 0x16b4 <_llm_rows.packet_batch.blocks+0x1348>
    19f0:      	add	x15, x8, #0x18
    19f4:      	ld1.s	{ v5 }[2], [x15]
    19f8:      	tbnz	w13, #0x7, 0x16b8 <_llm_rows.packet_batch.blocks+0x134c>
    19fc:      	b	0x16c0 <_llm_rows.packet_batch.blocks+0x1354>
    1a00:      	str	s5, [x9]
    1a04:      	tbz	w8, #0x1, 0x18b0 <_llm_rows.packet_batch.blocks+0x1544>
    1a08:      	add	x10, x9, #0x4
    1a0c:      	st1.s	{ v5 }[1], [x10]
    1a10:      	tbz	w8, #0x2, 0x18b4 <_llm_rows.packet_batch.blocks+0x1548>
    1a14:      	add	x10, x9, #0x8
    1a18:      	st1.s	{ v5 }[2], [x10]
    1a1c:      	tbnz	w8, #0x3, 0x18b8 <_llm_rows.packet_batch.blocks+0x154c>
    1a20:      	b	0x18c0 <_llm_rows.packet_batch.blocks+0x1554>
    1a24:      	str	s0, [x9, #0x10]
    1a28:      	tbz	w8, #0x5, 0x18f0 <_llm_rows.packet_batch.blocks+0x1584>
    1a2c:      	add	x10, x9, #0x14
    1a30:      	st1.s	{ v0 }[1], [x10]
    1a34:      	tbz	w8, #0x6, 0x18f4 <_llm_rows.packet_batch.blocks+0x1588>
    1a38:      	add	x10, x9, #0x18
    1a3c:      	st1.s	{ v0 }[2], [x10]
    1a40:      	tbz	w8, #0x7, 0x3f0 <_llm_rows.packet_batch.blocks+0x84>
    1a44:      	add	x8, x9, #0x1c
    1a48:      	st1.s	{ v0 }[3], [x8]
    1a4c:      	b	0x3f0 <_llm_rows.packet_batch.blocks+0x84>
    1a50:      	add	sp, sp, #0x6d0
    1a54:      	ldp	x29, x30, [sp, #0x90]
    1a58:      	ldp	x20, x19, [sp, #0x80]
    1a5c:      	ldp	x22, x21, [sp, #0x70]
    1a60:      	ldp	x24, x23, [sp, #0x60]
    1a64:      	ldp	x26, x25, [sp, #0x50]
    1a68:      	ldp	x28, x27, [sp, #0x40]
    1a6c:      	ldp	d9, d8, [sp, #0x30]
    1a70:      	ldp	d11, d10, [sp, #0x20]
    1a74:      	ldp	d13, d12, [sp, #0x10]
    1a78:      	ldp	d15, d14, [sp], #0xa0
    1a7c:      	ret

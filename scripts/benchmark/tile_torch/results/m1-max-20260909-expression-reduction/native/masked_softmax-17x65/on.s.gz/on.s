
/private/tmp/luisa-expression-fusion.qXgTbC/capture/masked_softmax-17x65/on/object/tile_xir_w8_23375_1788930264550395_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x880
      2c:      	mov	x12, #0x0               ; =0
      30:      	ldr	x13, [x0]
      34:      	ldr	x8, [x0, #0x30]
      38:      	add	x11, sp, #0x760
      3c:      	ldr	w9, [x1]
      40:      	ldr	w10, [x1, #0x24]
      44:      	add	w9, w10, w9, lsl #5
      48:      	lsr	w9, w9, #3
      4c:      	dup.4s	v0, w9
      50:      	fmov	s1, w9
      54:      	ushll.2d	v1, v1, #0x0
      58:      	fmov	x9, d1
      5c:      	add	x9, x9, x9, lsl #6
      60:      	lsl	x10, x9, #2
      64:      	add	x9, x13, x10
      68:      	ldp	q1, q2, [x9, #0xc0]
      6c:      	stp	q1, q2, [x11, #0xc0]
      70:      	ldp	q1, q2, [x9, #0xe0]
      74:      	stp	q1, q2, [x11, #0xe0]
      78:      	ldp	q1, q2, [x9, #0x80]
      7c:      	stp	q1, q2, [x11, #0x80]
      80:      	ldp	q1, q2, [x9, #0xa0]
      84:      	stp	q1, q2, [x11, #0xa0]
      88:      	ldp	q1, q2, [x9, #0x40]
      8c:      	stp	q1, q2, [x11, #0x40]
      90:      	ldp	q1, q2, [x9, #0x60]
      94:      	stp	q1, q2, [x11, #0x60]
      98:      	ldp	q1, q2, [x9]
      9c:      	stp	q1, q2, [x11]
      a0:      	ldp	q1, q2, [x9, #0x20]
      a4:      	add	x9, x10, #0x100
      a8:      	ldr	s3, [x13, x9]
      ac:      	stp	q1, q2, [x11, #0x20]
      b0:      	str	q3, [sp, #0x230]
      b4:      	str	q3, [x11, #0x100]
      b8:      	movi.2d	v1, #0000000000000000
      bc:      	adrp	x13, 0x0 <ltmp0>
      c0:      	ldr	q2, [x13]
      c4:      	adrp	x13, 0x0 <ltmp0>
      c8:      	ldr	q3, [x13]
      cc:      	adrp	x13, 0x0 <ltmp0>
      d0:      	ldr	q4, [x13]
      d4:      	adrp	x13, 0x0 <ltmp0>
      d8:      	ldr	q5, [x13]
      dc:      	mov	w13, #0x1               ; =1
      e0:      	dup.2d	v6, x13
      e4:      	add	x13, sp, #0x520
      e8:      	movi.2d	v7, #0000000000000000
      ec:      	movi.2d	v16, #0000000000000000
      f0:      	movi.2d	v17, #0000000000000000
      f4:      	shl.2d	v19, v1, #0x3
      f8:      	shl.2d	v20, v7, #0x3
      fc:      	shl.2d	v21, v16, #0x3
     100:      	shl.2d	v22, v17, #0x3
     104:      	orr.16b	v22, v22, v2
     108:      	orr.16b	v21, v21, v3
     10c:      	orr.16b	v20, v20, v4
     110:      	orr.16b	v19, v19, v5
     114:      	add	x12, x13, x12, lsl #6
     118:      	stp	q19, q20, [x12]
     11c:      	stp	q21, q22, [x12, #0x20]
     120:      	add.2d	v16, v16, v6
     124:      	add.2d	v7, v7, v6
     128:      	add.2d	v17, v17, v6
     12c:      	add.2d	v1, v1, v6
     130:      	fmov	x12, d1
     134:      	cmp	x12, #0x8
     138:      	b.lt	0xf4 <ltmp0+0xf4>
     13c:      	mov	x13, #0x0               ; =0
     140:      	mov	w12, #0x40              ; =64
     144:      	str	x12, [sp, #0x720]
     148:      	mov	w12, #0x3f04            ; =16132
     14c:      	movk	w12, #0x3f0, lsl #16
     150:      	dup.4s	v1, w12
     154:      	umull2.2d	v2, v0, v1
     158:      	umull.2d	v3, v0, v1
     15c:      	uzp2.4s	v3, v3, v2
     160:      	movi.4s	v4, #0x41
     164:      	mov.16b	v5, v0
     168:      	mls.4s	v5, v3, v4
     16c:      	umull.2d	v1, v0, v1
     170:      	uzp2.4s	v1, v1, v2
     174:      	mls.4s	v0, v1, v4
     178:      	ushll2.2d	v1, v0, #0x0
     17c:      	ushll2.2d	v2, v5, #0x0
     180:      	ushll.2d	v3, v0, #0x0
     184:      	ushll.2d	v0, v5, #0x0
     188:      	movi.2d	v4, #0000000000000000
     18c:      	add	x12, sp, #0x4d8
     190:      	dup.2d	v5, x12
     194:      	adrp	x12, 0x0 <ltmp0>
     198:      	ldr	q8, [x12]
     19c:      	adrp	x12, 0x0 <ltmp0>
     1a0:      	ldr	q9, [x12]
     1a4:      	adrp	x12, 0x0 <ltmp0>
     1a8:      	ldr	q10, [x12]
     1ac:      	mov	w12, #0x1               ; =1
     1b0:      	dup.2d	v6, x12
     1b4:      	adrp	x12, 0x0 <ltmp0>
     1b8:      	ldr	q28, [x12]
     1bc:      	add	x12, sp, #0x520
     1c0:      	movi.8b	v7, #0x1
     1c4:      	movi.2d	v16, #0000000000000000
     1c8:      	movi.2d	v17, #0000000000000000
     1cc:      	movi.2d	v19, #0000000000000000
     1d0:      	add	x13, x12, x13, lsl #6
     1d4:      	ldp	q21, q20, [x13, #0x20]
     1d8:      	ldp	q22, q23, [x13]
     1dc:      	add.2d	v24, v19, v28
     1e0:      	add.2d	v24, v24, v5
     1e4:      	add.2d	v25, v17, v10
     1e8:      	add.2d	v26, v16, v9
     1ec:      	add.2d	v27, v4, v8
     1f0:      	add.2d	v27, v27, v5
     1f4:      	cmge.2d	v23, v2, v23
     1f8:      	cmge.2d	v22, v0, v22
     1fc:      	uzp1.4s	v22, v22, v23
     200:      	cmge.2d	v21, v3, v21
     204:      	cmge.2d	v20, v1, v20
     208:      	uzp1.4s	v20, v21, v20
     20c:      	uzp1.8h	v20, v22, v20
     210:      	xtn.8b	v20, v20
     214:      	and.8b	v20, v20, v7
     218:      	mov.d	x13, v27[1]
     21c:      	fmov	x14, d27
     220:      	str	b20, [x14]
     224:      	st1.b	{ v20 }[1], [x13]
     228:      	add.2d	v21, v26, v5
     22c:      	mov.d	x13, v21[1]
     230:      	fmov	x14, d21
     234:      	st1.b	{ v20 }[2], [x14]
     238:      	add.2d	v21, v25, v5
     23c:      	st1.b	{ v20 }[3], [x13]
     240:      	mov.d	x13, v21[1]
     244:      	fmov	x14, d21
     248:      	st1.b	{ v20 }[4], [x14]
     24c:      	st1.b	{ v20 }[5], [x13]
     250:      	mov.d	x13, v24[1]
     254:      	fmov	x14, d24
     258:      	st1.b	{ v20 }[6], [x14]
     25c:      	st1.b	{ v20 }[7], [x13]
     260:      	add.2d	v17, v17, v6
     264:      	add.2d	v16, v16, v6
     268:      	add.2d	v19, v19, v6
     26c:      	add.2d	v4, v4, v6
     270:      	fmov	x13, d4
     274:      	cmp	x13, #0x8
     278:      	b.lt	0x1d0 <ltmp0+0x1d0>
     27c:      	adrp	x12, 0x0 <ltmp0>
     280:      	ldr	q1, [x12]
     284:      	add	x12, sp, #0x4d8
     288:      	dup.2d	v20, x12
     28c:      	adrp	x12, 0x0 <ltmp0>
     290:      	ldr	q2, [x12]
     294:      	add.2d	v19, v20, v2
     298:      	cmgt.2d	v0, v0, v1
     29c:      	xtn.2s	v0, v0
     2a0:      	uzp1.4h	v0, v0, v0
     2a4:      	uzp1.8b	v0, v0, v0
     2a8:      	movi.8b	v1, #0x1
     2ac:      	and.8b	v0, v0, v1
     2b0:      	fmov	x12, d19
     2b4:      	str	b0, [x12]
     2b8:      	add.2d	v0, v20, v28
     2bc:      	add.2d	v1, v20, v10
     2c0:      	add.2d	v2, v20, v9
     2c4:      	add.2d	v21, v20, v8
     2c8:      	fmov	x12, d21
     2cc:      	mov.d	x13, v21[1]
     2d0:      	mov.d	x14, v2[1]
     2d4:      	mov.d	x15, v1[1]
     2d8:      	fmov	x16, d2
     2dc:      	fmov	x17, d1
     2e0:      	mov.d	x0, v0[1]
     2e4:      	fmov	x1, d0
     2e8:      	ldr	b0, [x12]
     2ec:      	ld1.b	{ v0 }[1], [x13]
     2f0:      	ld1.b	{ v0 }[2], [x16]
     2f4:      	ld1.b	{ v0 }[3], [x14]
     2f8:      	ld1.b	{ v0 }[4], [x17]
     2fc:      	ld1.b	{ v0 }[5], [x15]
     300:      	ld1.b	{ v0 }[6], [x1]
     304:      	ld1.b	{ v0 }[7], [x0]
     308:      	cmeq.8b	v0, v0, #0
     30c:      	sshll.8h	v17, v0, #0x0
     310:      	sshll2.4s	v16, v17, #0x0
     314:      	sshll.4s	v0, v17, #0x0
     318:      	ldp	q2, q1, [x11]
     31c:      	mov	w12, #0xf2ca            ; =62154
     320:      	movk	w12, #0xf149, lsl #16
     324:      	dup.4s	v24, w12
     328:      	mov.16b	v22, v0
     32c:      	bsl.16b	v22, v24, v2
     330:      	mov.16b	v23, v16
     334:      	bsl.16b	v23, v24, v1
     338:      	add	x12, sp, #0x2c9
     33c:      	stur	q23, [x12, #0xff]
     340:      	add	x12, sp, #0x2b9
     344:      	stur	q22, [x12, #0xff]
     348:      	adrp	x12, 0x0 <ltmp0>
     34c:      	ldr	q0, [x12]
     350:      	add.2d	v0, v20, v0
     354:      	adrp	x12, 0x0 <ltmp0>
     358:      	ldr	q1, [x12]
     35c:      	add.2d	v1, v20, v1
     360:      	adrp	x12, 0x0 <ltmp0>
     364:      	ldr	q2, [x12]
     368:      	add.2d	v2, v20, v2
     36c:      	adrp	x12, 0x0 <ltmp0>
     370:      	ldr	q3, [x12]
     374:      	add.2d	v3, v20, v3
     378:      	mov.d	x12, v3[1]
     37c:      	fmov	x13, d3
     380:      	mov.d	x14, v2[1]
     384:      	fmov	x15, d2
     388:      	mov.d	x16, v1[1]
     38c:      	fmov	x17, d1
     390:      	mov.d	x0, v0[1]
     394:      	fmov	x1, d0
     398:      	ldr	b0, [x13]
     39c:      	ld1.b	{ v0 }[1], [x12]
     3a0:      	ld1.b	{ v0 }[2], [x15]
     3a4:      	ld1.b	{ v0 }[3], [x14]
     3a8:      	ld1.b	{ v0 }[4], [x17]
     3ac:      	ld1.b	{ v0 }[5], [x16]
     3b0:      	ld1.b	{ v0 }[6], [x1]
     3b4:      	ld1.b	{ v0 }[7], [x0]
     3b8:      	cmeq.8b	v0, v0, #0
     3bc:      	sshll.8h	v0, v0, #0x0
     3c0:      	sshll2.4s	v7, v0, #0x0
     3c4:      	sshll.4s	v1, v0, #0x0
     3c8:      	ldp	q3, q2, [x11, #0x20]
     3cc:      	bsl.16b	v1, v24, v3
     3d0:      	bit.16b	v2, v24, v7
     3d4:      	adrp	x12, 0x0 <ltmp0>
     3d8:      	ldr	q3, [x12]
     3dc:      	str	q3, [sp, #0x1e0]
     3e0:      	add.2d	v3, v20, v3
     3e4:      	adrp	x12, 0x0 <ltmp0>
     3e8:      	ldr	q4, [x12]
     3ec:      	str	q4, [sp, #0x1d0]
     3f0:      	add.2d	v4, v20, v4
     3f4:      	adrp	x12, 0x0 <ltmp0>
     3f8:      	ldr	q5, [x12]
     3fc:      	str	q5, [sp, #0x1c0]
     400:      	add.2d	v5, v20, v5
     404:      	adrp	x12, 0x0 <ltmp0>
     408:      	ldr	q6, [x12]
     40c:      	add.2d	v6, v20, v6
     410:      	mov.d	x12, v6[1]
     414:      	mov.d	x13, v5[1]
     418:      	fmov	x14, d6
     41c:      	fmov	x15, d5
     420:      	mov.d	x16, v4[1]
     424:      	mov.d	x17, v3[1]
     428:      	fmov	x0, d4
     42c:      	ldr	b4, [x14]
     430:      	ld1.b	{ v4 }[1], [x12]
     434:      	ld1.b	{ v4 }[2], [x15]
     438:      	ld1.b	{ v4 }[3], [x13]
     43c:      	ld1.b	{ v4 }[4], [x0]
     440:      	ld1.b	{ v4 }[5], [x16]
     444:      	fmov	x12, d3
     448:      	ld1.b	{ v4 }[6], [x12]
     44c:      	ld1.b	{ v4 }[7], [x17]
     450:      	add	x12, sp, #0x2e9
     454:      	stur	q2, [x12, #0xff]
     458:      	add	x12, sp, #0x2d9
     45c:      	stur	q1, [x12, #0xff]
     460:      	cmeq.8b	v3, v4, #0
     464:      	sshll.8h	v6, v3, #0x0
     468:      	sshll2.4s	v4, v6, #0x0
     46c:      	sshll.4s	v3, v6, #0x0
     470:      	ldp	q25, q5, [x11, #0x40]
     474:      	bsl.16b	v3, v24, v25
     478:      	str	q4, [sp, #0x250]
     47c:      	mov.16b	v25, v4
     480:      	bsl.16b	v25, v24, v5
     484:      	add	x12, sp, #0x309
     488:      	stur	q25, [x12, #0xff]
     48c:      	add	x12, sp, #0x2f9
     490:      	stur	q3, [x12, #0xff]
     494:      	adrp	x12, 0x0 <ltmp0>
     498:      	ldr	q5, [x12]
     49c:      	str	q5, [sp, #0x1b0]
     4a0:      	add.2d	v5, v20, v5
     4a4:      	adrp	x12, 0x0 <ltmp0>
     4a8:      	ldr	q26, [x12]
     4ac:      	str	q26, [sp, #0x1a0]
     4b0:      	add.2d	v26, v20, v26
     4b4:      	adrp	x12, 0x0 <ltmp0>
     4b8:      	ldr	q29, [x12]
     4bc:      	adrp	x12, 0x0 <ltmp0>
     4c0:      	ldr	q27, [x12]
     4c4:      	add.2d	v27, v20, v27
     4c8:      	mov.d	x12, v27[1]
     4cc:      	mov.16b	v12, v28
     4d0:      	str	q29, [sp, #0x190]
     4d4:      	add.2d	v28, v20, v29
     4d8:      	fmov	x13, d27
     4dc:      	mov.d	x14, v28[1]
     4e0:      	mov.d	x15, v26[1]
     4e4:      	fmov	x16, d28
     4e8:      	fmov	x17, d26
     4ec:      	mov.d	x0, v5[1]
     4f0:      	fmov	x1, d5
     4f4:      	ldr	b5, [x13]
     4f8:      	ld1.b	{ v5 }[1], [x12]
     4fc:      	ld1.b	{ v5 }[2], [x16]
     500:      	ld1.b	{ v5 }[3], [x14]
     504:      	ld1.b	{ v5 }[4], [x17]
     508:      	ld1.b	{ v5 }[5], [x15]
     50c:      	ld1.b	{ v5 }[6], [x1]
     510:      	ld1.b	{ v5 }[7], [x0]
     514:      	cmeq.8b	v5, v5, #0
     518:      	sshll.8h	v5, v5, #0x0
     51c:      	sshll2.4s	v4, v5, #0x0
     520:      	str	q5, [sp, #0x260]
     524:      	sshll.4s	v26, v5, #0x0
     528:      	ldp	q28, q27, [x11, #0x60]
     52c:      	bsl.16b	v26, v24, v28
     530:      	stp	q12, q4, [sp, #0x270]
     534:      	bit.16b	v27, v24, v4
     538:      	add	x11, sp, #0x329
     53c:      	stur	q27, [x11, #0xff]
     540:      	add	x11, sp, #0x319
     544:      	stur	q26, [x11, #0xff]
     548:      	mov	w11, #0x4               ; =4
     54c:      	add	x12, sp, #0x760
     550:      	add	x13, sp, #0x3b8
     554:      	mov	w14, #0x1               ; =1
     558:      	mov	w15, #0x2               ; =2
     55c:      	mov	w16, #0x3               ; =3
     560:      	dup.2d	v28, x11
     564:      	mov	w17, #0x4               ; =4
     568:      	mov.16b	v29, v28
     56c:      	mov.16b	v30, v28
     570:      	mov.16b	v31, v28
     574:      	mov.16b	v15, v8
     578:      	mov.16b	v4, v9
     57c:      	mov.16b	v5, v10
     580:      	str	q8, [sp, #0x240]
     584:      	add.2d	v10, v29, v20
     588:      	add.2d	v9, v30, v20
     58c:      	add.2d	v8, v31, v20
     590:      	add.2d	v11, v8, v12
     594:      	add.2d	v12, v9, v5
     598:      	add.2d	v13, v10, v4
     59c:      	add.2d	v14, v28, v15
     5a0:      	add.2d	v14, v14, v20
     5a4:      	mov.d	x1, v14[1]
     5a8:      	fmov	x2, d14
     5ac:      	mov.d	x3, v13[1]
     5b0:      	fmov	x4, d13
     5b4:      	mov.d	x5, v12[1]
     5b8:      	fmov	x6, d12
     5bc:      	mov.d	x0, v11[1]
     5c0:      	ldr	b12, [x2]
     5c4:      	ld1.b	{ v12 }[1], [x1]
     5c8:      	ld1.b	{ v12 }[2], [x4]
     5cc:      	ld1.b	{ v12 }[3], [x3]
     5d0:      	fmov	x1, d11
     5d4:      	ld1.b	{ v12 }[4], [x6]
     5d8:      	lsl	x17, x17, #5
     5dc:      	ld1.b	{ v12 }[5], [x5]
     5e0:      	add	x2, x12, x17
     5e4:      	dup.2d	v11, x14
     5e8:      	orr.16b	v11, v28, v11
     5ec:      	ld1.b	{ v12 }[6], [x1]
     5f0:      	mvn.16b	v13, v20
     5f4:      	add.2d	v14, v11, v21
     5f8:      	mov.d	x1, v14[1]
     5fc:      	ld1.b	{ v12 }[7], [x0]
     600:      	sub.2d	v15, v29, v13
     604:      	fmov	x0, d14
     608:      	sub.2d	v14, v30, v13
     60c:      	sub.2d	v13, v31, v13
     610:      	mov.16b	v18, v4
     614:      	ldr	q4, [sp, #0x270]
     618:      	add.2d	v13, v13, v4
     61c:      	mov.16b	v4, v18
     620:      	cmeq.8b	v12, v12, #0
     624:      	add.2d	v14, v14, v5
     628:      	add.2d	v15, v15, v18
     62c:      	mov.d	x3, v15[1]
     630:      	fmov	x4, d15
     634:      	sshll.8h	v15, v12, #0x0
     638:      	mov.d	x5, v14[1]
     63c:      	fmov	x6, d14
     640:      	mov.d	x7, v13[1]
     644:      	sshll.4s	v14, v15, #0x0
     648:      	ldr	b12, [x0]
     64c:      	fmov	x0, d13
     650:      	ldr	q13, [x2]
     654:      	ld1.b	{ v12 }[1], [x1]
     658:      	bit.16b	v13, v24, v14
     65c:      	ldr	q14, [x2, #0x10]
     660:      	ld1.b	{ v12 }[2], [x4]
     664:      	ld1.b	{ v12 }[3], [x3]
     668:      	sshll2.4s	v15, v15, #0x0
     66c:      	add	x17, x13, x17
     670:      	ld1.b	{ v12 }[4], [x6]
     674:      	ld1.b	{ v12 }[5], [x5]
     678:      	bit.16b	v14, v24, v15
     67c:      	ld1.b	{ v12 }[6], [x0]
     680:      	ld1.b	{ v12 }[7], [x7]
     684:      	stp	q13, q14, [x17]
     688:      	fmov	x17, d11
     68c:      	lsl	x17, x17, #5
     690:      	add	x0, x12, x17
     694:      	dup.2d	v11, x15
     698:      	fmaxnm.4s	v23, v23, v14
     69c:      	orr.16b	v11, v28, v11
     6a0:      	ldr	q14, [sp, #0x1e0]
     6a4:      	add.2d	v14, v8, v14
     6a8:      	add.2d	v15, v11, v21
     6ac:      	mov.d	x1, v15[1]
     6b0:      	fmaxnm.4s	v22, v22, v13
     6b4:      	ldr	q13, [sp, #0x1d0]
     6b8:      	add.2d	v13, v9, v13
     6bc:      	fmov	x2, d15
     6c0:      	ldr	q15, [sp, #0x1c0]
     6c4:      	add.2d	v15, v10, v15
     6c8:      	mov.d	x3, v15[1]
     6cc:      	cmeq.8b	v12, v12, #0
     6d0:      	fmov	x4, d15
     6d4:      	mov.d	x5, v13[1]
     6d8:      	mov.d	x6, v14[1]
     6dc:      	sshll.8h	v12, v12, #0x0
     6e0:      	fmov	x7, d13
     6e4:      	ldr	b13, [x2]
     6e8:      	fmov	x2, d14
     6ec:      	ld1.b	{ v13 }[1], [x1]
     6f0:      	sshll.4s	v14, v12, #0x0
     6f4:      	ldr	q15, [x0]
     6f8:      	ld1.b	{ v13 }[2], [x4]
     6fc:      	ld1.b	{ v13 }[3], [x3]
     700:      	bsl.16b	v14, v24, v15
     704:      	ldr	q15, [x0, #0x10]
     708:      	ld1.b	{ v13 }[4], [x7]
     70c:      	ld1.b	{ v13 }[5], [x5]
     710:      	sshll2.4s	v12, v12, #0x0
     714:      	ld1.b	{ v13 }[6], [x2]
     718:      	ld1.b	{ v13 }[7], [x6]
     71c:      	cmeq.8b	v13, v13, #0
     720:      	bsl.16b	v12, v24, v15
     724:      	sshll.8h	v13, v13, #0x0
     728:      	fmov	x0, d11
     72c:      	lsl	x0, x0, #5
     730:      	add	x1, x12, x0
     734:      	ldr	q11, [x1]
     738:      	sshll.4s	v15, v13, #0x0
     73c:      	bit.16b	v11, v24, v15
     740:      	ldr	q15, [sp, #0x240]
     744:      	add	x17, x13, x17
     748:      	fmaxnm.4s	v2, v2, v12
     74c:      	stp	q14, q12, [x17]
     750:      	fmaxnm.4s	v1, v1, v14
     754:      	ldr	q12, [x1, #0x10]
     758:      	sshll2.4s	v13, v13, #0x0
     75c:      	bit.16b	v12, v24, v13
     760:      	add	x17, x13, x0
     764:      	str	q12, [x17, #0x10]
     768:      	fmaxnm.4s	v25, v25, v12
     76c:      	dup.2d	v12, x16
     770:      	orr.16b	v12, v28, v12
     774:      	add.2d	v13, v12, v21
     778:      	mov.d	x0, v13[1]
     77c:      	fmov	x1, d13
     780:      	ldr	q13, [sp, #0x190]
     784:      	add.2d	v10, v10, v13
     788:      	mov.d	x2, v10[1]
     78c:      	fmov	x3, d10
     790:      	ldr	q10, [sp, #0x1a0]
     794:      	add.2d	v9, v9, v10
     798:      	mov.d	x4, v9[1]
     79c:      	fmov	x5, d9
     7a0:      	ldr	q9, [sp, #0x1b0]
     7a4:      	add.2d	v8, v8, v9
     7a8:      	mov.d	x6, v8[1]
     7ac:      	fmov	x7, d8
     7b0:      	ldr	b8, [x1]
     7b4:      	ld1.b	{ v8 }[1], [x0]
     7b8:      	ld1.b	{ v8 }[2], [x3]
     7bc:      	ld1.b	{ v8 }[3], [x2]
     7c0:      	ld1.b	{ v8 }[4], [x5]
     7c4:      	ld1.b	{ v8 }[5], [x4]
     7c8:      	ld1.b	{ v8 }[6], [x7]
     7cc:      	ld1.b	{ v8 }[7], [x6]
     7d0:      	cmeq.8b	v8, v8, #0
     7d4:      	str	q11, [x17]
     7d8:      	sshll.8h	v8, v8, #0x0
     7dc:      	fmov	x17, d12
     7e0:      	ldr	q12, [sp, #0x270]
     7e4:      	sshll.4s	v9, v8, #0x0
     7e8:      	lsl	x17, x17, #5
     7ec:      	add	x0, x12, x17
     7f0:      	fmaxnm.4s	v3, v3, v11
     7f4:      	ldr	q10, [x0]
     7f8:      	bsl.16b	v9, v24, v10
     7fc:      	ldr	q10, [x0, #0x10]
     800:      	sshll2.4s	v8, v8, #0x0
     804:      	bsl.16b	v8, v24, v10
     808:      	add	x17, x13, x17
     80c:      	fmaxnm.4s	v27, v27, v8
     810:      	stp	q9, q8, [x17]
     814:      	fmaxnm.4s	v26, v26, v9
     818:      	dup.2d	v8, x11
     81c:      	add.2d	v30, v30, v8
     820:      	add.2d	v29, v29, v8
     824:      	add.2d	v31, v31, v8
     828:      	add.2d	v28, v28, v8
     82c:      	fmov	x17, d28
     830:      	cmp	x17, #0x8
     834:      	b.lt	0x584 <ltmp0+0x584>
     838:      	fmov	x11, d19
     83c:      	ldr	b19, [x11]
     840:      	cmeq.8b	v19, v19, #0
     844:      	sshll.8h	v18, v19, #0x0
     848:      	str	q18, [sp, #0x10]
     84c:      	sshll.4s	v19, v18, #0x0
     850:      	movi.2d	v20, #0000000000000000
     854:      	ldr	q18, [sp, #0x230]
     858:      	mov.s	v20[0], v18[0]
     85c:      	mov	w11, #0xf2ca            ; =62154
     860:      	movk	w11, #0xf149, lsl #16
     864:      	dup.4s	v18, w11
     868:      	bif.16b	v18, v20, v19
     86c:      	add	x11, sp, #0x3b9
     870:      	ldur	q19, [x11, #0xff]
     874:      	mov.s	v19[0], v18[0]
     878:      	str	q19, [sp, #0x20]
     87c:      	fmaxnm.4s	v18, v22, v18
     880:      	mov.s	v22[0], v18[0]
     884:      	fmaxnm.4s	v2, v23, v2
     888:      	fmaxnm.4s	v1, v22, v1
     88c:      	fmaxnm.4s	v1, v1, v3
     890:      	fmaxnm.4s	v2, v2, v25
     894:      	fmaxnm.4s	v2, v2, v27
     898:      	fmaxnm.4s	v1, v1, v26
     89c:      	rev64.4s	v3, v1
     8a0:      	rev64.4s	v18, v2
     8a4:      	fmaxnm.4s	v2, v2, v18
     8a8:      	fmaxnm.4s	v1, v1, v3
     8ac:      	ext.16b	v3, v1, v1, #0x8
     8b0:      	ext.16b	v18, v2, v2, #0x8
     8b4:      	fmaxnm.4s	v2, v2, v18
     8b8:      	fmaxnm.4s	v1, v1, v3
     8bc:      	fmaxnm.4s	v1, v1, v2
     8c0:      	mov	w11, #-0x800000         ; =-8388608
     8c4:      	fmov	s2, w11
     8c8:      	fmaxnm	s1, s1, s2
     8cc:      	add	x11, sp, #0x2b9
     8d0:      	ldur	q2, [x11, #0xff]
     8d4:      	add	x11, sp, #0x2c9
     8d8:      	ldur	q3, [x11, #0xff]
     8dc:      	dup.4s	v27, v1[0]
     8e0:      	fsub.4s	v1, v3, v27
     8e4:      	fsub.4s	v2, v2, v27
     8e8:      	mov	w11, #-0x3d300000       ; =-1026555904
     8ec:      	dup.4s	v22, w11
     8f0:      	fcmge.4s	v3, v2, v22
     8f4:      	fcmge.4s	v18, v1, v22
     8f8:      	mov	w11, #0x42c80000        ; =1120403456
     8fc:      	dup.4s	v14, w11
     900:      	fcmge.4s	v19, v14, v2
     904:      	fcmge.4s	v20, v14, v1
     908:      	and.16b	v18, v18, v20
     90c:      	and.16b	v3, v3, v19
     910:      	and.16b	v19, v3, v2
     914:      	and.16b	v20, v18, v1
     918:      	mov	w11, #0xaa3b            ; =43579
     91c:      	movk	w11, #0x3fb8, lsl #16
     920:      	dup.4s	v29, w11
     924:      	fmul.4s	v3, v20, v29
     928:      	fmul.4s	v18, v19, v29
     92c:      	movi.4s	v21, #0x4b, lsl #24
     930:      	mvni.4s	v24, #0x80, lsl #24
     934:      	mov.16b	v23, v24
     938:      	bsl.16b	v23, v21, v18
     93c:      	bsl.16b	v24, v21, v3
     940:      	fadd.4s	v3, v3, v24
     944:      	fadd.4s	v18, v18, v23
     948:      	fsub.4s	v23, v18, v23
     94c:      	fsub.4s	v3, v3, v24
     950:      	fcvtzs.4s	v18, v3
     954:      	fcvtzs.4s	v3, v23
     958:      	scvtf.4s	v23, v3
     95c:      	scvtf.4s	v24, v18
     960:      	mov	w11, #0x7200            ; =29184
     964:      	movk	w11, #0x3f31, lsl #16
     968:      	dup.4s	v8, w11
     96c:      	fmul.4s	v25, v24, v8
     970:      	fmul.4s	v26, v23, v8
     974:      	fsub.4s	v19, v19, v26
     978:      	fsub.4s	v20, v20, v25
     97c:      	mov	w11, #0xbe8e            ; =48782
     980:      	movk	w11, #0x35bf, lsl #16
     984:      	dup.4s	v9, w11
     988:      	fmul.4s	v23, v23, v9
     98c:      	fmul.4s	v24, v24, v9
     990:      	fsub.4s	v20, v20, v24
     994:      	fsub.4s	v19, v19, v23
     998:      	mov	w11, #0x2bda            ; =11226
     99c:      	movk	w11, #0x3950, lsl #16
     9a0:      	dup.4s	v10, w11
     9a4:      	fmul.4s	v23, v19, v10
     9a8:      	mov	w11, #0x96c9            ; =38601
     9ac:      	movk	w11, #0x3ab6, lsl #16
     9b0:      	dup.4s	v11, w11
     9b4:      	fadd.4s	v23, v23, v11
     9b8:      	fmul.4s	v23, v19, v23
     9bc:      	mov	w11, #0x88a6            ; =34982
     9c0:      	movk	w11, #0x3c08, lsl #16
     9c4:      	dup.4s	v13, w11
     9c8:      	fadd.4s	v23, v23, v13
     9cc:      	fmul.4s	v23, v19, v23
     9d0:      	mov	w11, #0xaa7a            ; =43642
     9d4:      	movk	w11, #0x3d2a, lsl #16
     9d8:      	dup.4s	v30, w11
     9dc:      	fadd.4s	v23, v23, v30
     9e0:      	mov	w11, #0xaaab            ; =43691
     9e4:      	movk	w11, #0x3e2a, lsl #16
     9e8:      	dup.4s	v28, w11
     9ec:      	fmul.4s	v23, v19, v23
     9f0:      	fadd.4s	v23, v23, v28
     9f4:      	fmul.4s	v23, v19, v23
     9f8:      	movi.4s	v31, #0x3f, lsl #24
     9fc:      	fadd.4s	v23, v23, v31
     a00:      	fmul.4s	v24, v19, v19
     a04:      	fmul.4s	v23, v24, v23
     a08:      	fmul.4s	v24, v20, v10
     a0c:      	fadd.4s	v24, v24, v11
     a10:      	fmul.4s	v24, v20, v24
     a14:      	fadd.4s	v24, v24, v13
     a18:      	fmul.4s	v24, v20, v24
     a1c:      	fadd.4s	v24, v24, v30
     a20:      	fmul.4s	v24, v20, v24
     a24:      	fadd.4s	v24, v24, v28
     a28:      	fmul.4s	v24, v20, v24
     a2c:      	fadd.4s	v24, v24, v31
     a30:      	fmul.4s	v25, v20, v20
     a34:      	fmul.4s	v24, v25, v24
     a38:      	fadd.4s	v20, v20, v24
     a3c:      	fadd.4s	v19, v19, v23
     a40:      	fmov.4s	v26, #1.00000000
     a44:      	fadd.4s	v20, v20, v26
     a48:      	sshr.4s	v23, v18, #0x1
     a4c:      	shl.4s	v24, v23, #0x17
     a50:      	add.4s	v24, v24, v26
     a54:      	fmul.4s	v20, v20, v24
     a58:      	fadd.4s	v19, v19, v26
     a5c:      	sshr.4s	v24, v3, #0x1
     a60:      	shl.4s	v25, v24, #0x17
     a64:      	add.4s	v25, v25, v26
     a68:      	fmul.4s	v19, v19, v25
     a6c:      	sub.4s	v18, v18, v23
     a70:      	sshll.4s	v17, v17, #0x0
     a74:      	sub.4s	v3, v3, v24
     a78:      	shl.4s	v3, v3, #0x17
     a7c:      	shl.4s	v18, v18, #0x17
     a80:      	add.4s	v18, v18, v26
     a84:      	add.4s	v3, v3, v26
     a88:      	fmul.4s	v3, v19, v3
     a8c:      	fmul.4s	v18, v20, v18
     a90:      	fcmgt.4s	v19, v22, v1
     a94:      	bic.16b	v18, v18, v19
     a98:      	fcmgt.4s	v19, v22, v2
     a9c:      	bic.16b	v3, v3, v19
     aa0:      	fcmgt.4s	v19, v1, v14
     aa4:      	fcmgt.4s	v20, v2, v14
     aa8:      	mvni.4s	v23, #0x7f, msl #16
     aac:      	str	q5, [sp, #0xf0]
     ab0:      	fneg.4s	v5, v23
     ab4:      	bit.16b	v3, v5, v20
     ab8:      	bit.16b	v18, v5, v19
     abc:      	fcmeq.4s	v2, v2, v2
     ac0:      	fcmeq.4s	v1, v1, v1
     ac4:      	mvni.4s	v19, #0x3f, msl #16
     ac8:      	fneg.4s	v21, v19
     acc:      	bsl.16b	v1, v18, v21
     ad0:      	bsl.16b	v2, v3, v21
     ad4:      	bic.16b	v2, v2, v17
     ad8:      	bic.16b	v1, v1, v16
     adc:      	stp	q2, q1, [sp, #0x1f0]
     ae0:      	add	x11, sp, #0x2d9
     ae4:      	ldur	q2, [x11, #0xff]
     ae8:      	add	x11, sp, #0x2e9
     aec:      	ldur	q1, [x11, #0xff]
     af0:      	fsub.4s	v1, v1, v27
     af4:      	fsub.4s	v2, v2, v27
     af8:      	fcmge.4s	v3, v2, v22
     afc:      	fcmge.4s	v16, v1, v22
     b00:      	fcmge.4s	v17, v14, v1
     b04:      	and.16b	v16, v16, v17
     b08:      	fcmge.4s	v17, v14, v2
     b0c:      	and.16b	v3, v3, v17
     b10:      	and.16b	v17, v3, v2
     b14:      	fmul.4s	v3, v17, v29
     b18:      	mvni.4s	v19, #0x80, lsl #24
     b1c:      	movi.4s	v20, #0x4b, lsl #24
     b20:      	mov.16b	v18, v19
     b24:      	bsl.16b	v18, v20, v3
     b28:      	fadd.4s	v3, v3, v18
     b2c:      	fsub.4s	v3, v3, v18
     b30:      	and.16b	v16, v16, v1
     b34:      	fmul.4s	v18, v16, v29
     b38:      	bsl.16b	v19, v20, v18
     b3c:      	movi.4s	v25, #0x4b, lsl #24
     b40:      	mvni.4s	v24, #0x80, lsl #24
     b44:      	fadd.4s	v18, v18, v19
     b48:      	fsub.4s	v18, v18, v19
     b4c:      	fcvtzs.4s	v3, v3
     b50:      	scvtf.4s	v19, v3
     b54:      	fmul.4s	v20, v19, v8
     b58:      	fsub.4s	v17, v17, v20
     b5c:      	fcvtzs.4s	v18, v18
     b60:      	scvtf.4s	v20, v18
     b64:      	fmul.4s	v23, v20, v8
     b68:      	fsub.4s	v16, v16, v23
     b6c:      	fmul.4s	v20, v20, v9
     b70:      	fsub.4s	v16, v16, v20
     b74:      	fmul.4s	v19, v19, v9
     b78:      	fsub.4s	v17, v17, v19
     b7c:      	fmul.4s	v19, v17, v10
     b80:      	fadd.4s	v19, v19, v11
     b84:      	fmul.4s	v19, v17, v19
     b88:      	fadd.4s	v19, v19, v13
     b8c:      	fmul.4s	v19, v17, v19
     b90:      	fadd.4s	v19, v19, v30
     b94:      	fmul.4s	v19, v17, v19
     b98:      	fadd.4s	v19, v19, v28
     b9c:      	fmul.4s	v19, v17, v19
     ba0:      	fadd.4s	v19, v19, v31
     ba4:      	fmul.4s	v20, v17, v17
     ba8:      	fmul.4s	v19, v20, v19
     bac:      	fmul.4s	v20, v16, v10
     bb0:      	fadd.4s	v20, v20, v11
     bb4:      	fmul.4s	v20, v16, v20
     bb8:      	fadd.4s	v20, v20, v13
     bbc:      	fmul.4s	v20, v16, v20
     bc0:      	fadd.4s	v20, v20, v30
     bc4:      	fmul.4s	v20, v16, v20
     bc8:      	fadd.4s	v20, v20, v28
     bcc:      	fmul.4s	v20, v16, v20
     bd0:      	fadd.4s	v20, v20, v31
     bd4:      	fmul.4s	v23, v16, v16
     bd8:      	fmul.4s	v20, v23, v20
     bdc:      	fadd.4s	v16, v16, v20
     be0:      	fadd.4s	v17, v17, v19
     be4:      	fadd.4s	v16, v16, v26
     be8:      	sshr.4s	v19, v18, #0x1
     bec:      	shl.4s	v20, v19, #0x17
     bf0:      	add.4s	v20, v20, v26
     bf4:      	fmul.4s	v16, v16, v20
     bf8:      	fadd.4s	v17, v17, v26
     bfc:      	sshr.4s	v20, v3, #0x1
     c00:      	shl.4s	v23, v20, #0x17
     c04:      	add.4s	v23, v23, v26
     c08:      	fmul.4s	v17, v17, v23
     c0c:      	sub.4s	v18, v18, v19
     c10:      	sub.4s	v3, v3, v20
     c14:      	shl.4s	v3, v3, #0x17
     c18:      	add.4s	v3, v3, v26
     c1c:      	fmul.4s	v3, v17, v3
     c20:      	sshll.4s	v0, v0, #0x0
     c24:      	shl.4s	v17, v18, #0x17
     c28:      	add.4s	v17, v17, v26
     c2c:      	fmul.4s	v16, v16, v17
     c30:      	fcmgt.4s	v17, v22, v1
     c34:      	bic.16b	v16, v16, v17
     c38:      	fcmgt.4s	v17, v22, v2
     c3c:      	bic.16b	v3, v3, v17
     c40:      	fcmgt.4s	v17, v2, v14
     c44:      	bit.16b	v3, v5, v17
     c48:      	fcmgt.4s	v17, v1, v14
     c4c:      	bit.16b	v16, v5, v17
     c50:      	fcmeq.4s	v2, v2, v2
     c54:      	fcmeq.4s	v1, v1, v1
     c58:      	bsl.16b	v1, v16, v21
     c5c:      	bsl.16b	v2, v3, v21
     c60:      	bic.16b	v20, v2, v0
     c64:      	bic.16b	v23, v1, v7
     c68:      	add	x11, sp, #0x2f9
     c6c:      	ldur	q1, [x11, #0xff]
     c70:      	add	x11, sp, #0x309
     c74:      	ldur	q0, [x11, #0xff]
     c78:      	fsub.4s	v0, v0, v27
     c7c:      	fsub.4s	v1, v1, v27
     c80:      	fcmge.4s	v2, v1, v22
     c84:      	fcmge.4s	v3, v0, v22
     c88:      	fcmge.4s	v7, v14, v0
     c8c:      	and.16b	v3, v3, v7
     c90:      	fcmge.4s	v7, v14, v1
     c94:      	and.16b	v2, v2, v7
     c98:      	and.16b	v7, v2, v1
     c9c:      	fmul.4s	v2, v7, v29
     ca0:      	mov.16b	v16, v24
     ca4:      	bsl.16b	v16, v25, v2
     ca8:      	fadd.4s	v2, v2, v16
     cac:      	fsub.4s	v2, v2, v16
     cb0:      	and.16b	v3, v3, v0
     cb4:      	fmul.4s	v16, v3, v29
     cb8:      	mov.16b	v17, v24
     cbc:      	bsl.16b	v17, v25, v16
     cc0:      	fadd.4s	v16, v16, v17
     cc4:      	fsub.4s	v16, v16, v17
     cc8:      	fcvtzs.4s	v2, v2
     ccc:      	scvtf.4s	v17, v2
     cd0:      	fmul.4s	v18, v17, v8
     cd4:      	fsub.4s	v7, v7, v18
     cd8:      	fcvtzs.4s	v16, v16
     cdc:      	scvtf.4s	v18, v16
     ce0:      	fmul.4s	v19, v18, v8
     ce4:      	fsub.4s	v3, v3, v19
     ce8:      	fmul.4s	v18, v18, v9
     cec:      	fsub.4s	v3, v3, v18
     cf0:      	fmul.4s	v17, v17, v9
     cf4:      	fsub.4s	v7, v7, v17
     cf8:      	fmul.4s	v17, v7, v10
     cfc:      	fadd.4s	v17, v17, v11
     d00:      	fmul.4s	v17, v7, v17
     d04:      	fadd.4s	v17, v17, v13
     d08:      	fmul.4s	v17, v7, v17
     d0c:      	fadd.4s	v17, v17, v30
     d10:      	fmul.4s	v17, v7, v17
     d14:      	fadd.4s	v17, v17, v28
     d18:      	fmul.4s	v17, v7, v17
     d1c:      	fadd.4s	v17, v17, v31
     d20:      	fmul.4s	v18, v7, v7
     d24:      	fmul.4s	v17, v18, v17
     d28:      	fmul.4s	v18, v3, v10
     d2c:      	fadd.4s	v18, v18, v11
     d30:      	fmul.4s	v18, v3, v18
     d34:      	fadd.4s	v18, v18, v13
     d38:      	fmul.4s	v18, v3, v18
     d3c:      	fadd.4s	v18, v18, v30
     d40:      	fmul.4s	v18, v3, v18
     d44:      	fadd.4s	v18, v18, v28
     d48:      	fmul.4s	v18, v3, v18
     d4c:      	fadd.4s	v18, v18, v31
     d50:      	fmul.4s	v19, v3, v3
     d54:      	fmul.4s	v18, v19, v18
     d58:      	fadd.4s	v3, v3, v18
     d5c:      	fadd.4s	v7, v7, v17
     d60:      	fadd.4s	v3, v3, v26
     d64:      	sshr.4s	v17, v16, #0x1
     d68:      	shl.4s	v18, v17, #0x17
     d6c:      	add.4s	v18, v18, v26
     d70:      	fmul.4s	v3, v3, v18
     d74:      	fadd.4s	v7, v7, v26
     d78:      	sshr.4s	v18, v2, #0x1
     d7c:      	shl.4s	v19, v18, #0x17
     d80:      	add.4s	v19, v19, v26
     d84:      	fmul.4s	v7, v7, v19
     d88:      	sub.4s	v16, v16, v17
     d8c:      	sub.4s	v2, v2, v18
     d90:      	shl.4s	v2, v2, #0x17
     d94:      	add.4s	v2, v2, v26
     d98:      	fmul.4s	v2, v7, v2
     d9c:      	sshll.4s	v6, v6, #0x0
     da0:      	shl.4s	v7, v16, #0x17
     da4:      	add.4s	v7, v7, v26
     da8:      	fmul.4s	v3, v3, v7
     dac:      	fcmgt.4s	v7, v22, v0
     db0:      	bic.16b	v3, v3, v7
     db4:      	fcmgt.4s	v7, v22, v1
     db8:      	bic.16b	v2, v2, v7
     dbc:      	fcmgt.4s	v7, v1, v14
     dc0:      	bit.16b	v2, v5, v7
     dc4:      	fcmgt.4s	v7, v0, v14
     dc8:      	bit.16b	v3, v5, v7
     dcc:      	fcmeq.4s	v1, v1, v1
     dd0:      	fcmeq.4s	v0, v0, v0
     dd4:      	bsl.16b	v0, v3, v21
     dd8:      	bsl.16b	v1, v2, v21
     ddc:      	bic.16b	v18, v1, v6
     de0:      	ldr	q1, [sp, #0x250]
     de4:      	bic.16b	v19, v0, v1
     de8:      	add	x11, sp, #0x319
     dec:      	ldur	q1, [x11, #0xff]
     df0:      	add	x11, sp, #0x329
     df4:      	ldur	q0, [x11, #0xff]
     df8:      	fsub.4s	v0, v0, v27
     dfc:      	str	q27, [sp, #0x100]
     e00:      	fsub.4s	v1, v1, v27
     e04:      	fcmge.4s	v2, v1, v22
     e08:      	fcmge.4s	v3, v0, v22
     e0c:      	str	q4, [sp, #0x30]
     e10:      	fcmge.4s	v4, v14, v0
     e14:      	and.16b	v3, v3, v4
     e18:      	fcmge.4s	v4, v14, v1
     e1c:      	and.16b	v2, v2, v4
     e20:      	and.16b	v4, v2, v1
     e24:      	fmul.4s	v2, v4, v29
     e28:      	mov.16b	v6, v24
     e2c:      	bsl.16b	v6, v25, v2
     e30:      	fadd.4s	v2, v2, v6
     e34:      	fsub.4s	v2, v2, v6
     e38:      	and.16b	v3, v3, v0
     e3c:      	stp	q8, q29, [sp, #0xd0]
     e40:      	fmul.4s	v6, v3, v29
     e44:      	mov.16b	v7, v24
     e48:      	bsl.16b	v7, v25, v6
     e4c:      	fadd.4s	v6, v6, v7
     e50:      	fsub.4s	v6, v6, v7
     e54:      	fcvtzs.4s	v2, v2
     e58:      	scvtf.4s	v7, v2
     e5c:      	fmul.4s	v16, v7, v8
     e60:      	fsub.4s	v4, v4, v16
     e64:      	fcvtzs.4s	v6, v6
     e68:      	scvtf.4s	v16, v6
     e6c:      	fmul.4s	v17, v16, v8
     e70:      	fsub.4s	v3, v3, v17
     e74:      	fmul.4s	v16, v16, v9
     e78:      	fsub.4s	v3, v3, v16
     e7c:      	stp	q11, q9, [sp, #0xb0]
     e80:      	fmul.4s	v7, v7, v9
     e84:      	fsub.4s	v4, v4, v7
     e88:      	fmul.4s	v7, v4, v10
     e8c:      	fadd.4s	v7, v7, v11
     e90:      	fmul.4s	v7, v4, v7
     e94:      	fadd.4s	v7, v7, v13
     e98:      	fmul.4s	v7, v4, v7
     e9c:      	fadd.4s	v7, v7, v30
     ea0:      	fmul.4s	v7, v4, v7
     ea4:      	fadd.4s	v7, v7, v28
     ea8:      	fmul.4s	v7, v4, v7
     eac:      	fadd.4s	v7, v7, v31
     eb0:      	fmul.4s	v16, v4, v4
     eb4:      	fmul.4s	v7, v16, v7
     eb8:      	str	q10, [sp, #0x180]
     ebc:      	fmul.4s	v16, v3, v10
     ec0:      	fadd.4s	v16, v16, v11
     ec4:      	fmul.4s	v16, v3, v16
     ec8:      	stp	q30, q13, [sp, #0x90]
     ecc:      	fadd.4s	v16, v16, v13
     ed0:      	fmul.4s	v16, v3, v16
     ed4:      	fadd.4s	v16, v16, v30
     ed8:      	fmul.4s	v16, v3, v16
     edc:      	str	q28, [sp, #0x60]
     ee0:      	fadd.4s	v16, v16, v28
     ee4:      	mov.16b	v28, v19
     ee8:      	fmul.4s	v16, v3, v16
     eec:      	fadd.4s	v16, v16, v31
     ef0:      	fmul.4s	v17, v3, v3
     ef4:      	fmul.4s	v16, v17, v16
     ef8:      	fadd.4s	v3, v3, v16
     efc:      	fadd.4s	v4, v4, v7
     f00:      	fadd.4s	v3, v3, v26
     f04:      	sshr.4s	v7, v6, #0x1
     f08:      	shl.4s	v16, v7, #0x17
     f0c:      	add.4s	v16, v16, v26
     f10:      	fmul.4s	v3, v3, v16
     f14:      	fadd.4s	v4, v4, v26
     f18:      	sshr.4s	v16, v2, #0x1
     f1c:      	shl.4s	v17, v16, #0x17
     f20:      	add.4s	v17, v17, v26
     f24:      	fmul.4s	v4, v4, v17
     f28:      	sub.4s	v6, v6, v7
     f2c:      	sub.4s	v2, v2, v16
     f30:      	shl.4s	v2, v2, #0x17
     f34:      	add.4s	v2, v2, v26
     f38:      	fmul.4s	v2, v4, v2
     f3c:      	shl.4s	v4, v6, #0x17
     f40:      	mov.16b	v6, v23
     f44:      	mov.16b	v23, v18
     f48:      	add.4s	v4, v4, v26
     f4c:      	fmul.4s	v3, v3, v4
     f50:      	fcmgt.4s	v4, v22, v0
     f54:      	bic.16b	v3, v3, v4
     f58:      	stp	q14, q22, [sp, #0x70]
     f5c:      	fcmgt.4s	v4, v22, v1
     f60:      	bic.16b	v2, v2, v4
     f64:      	fcmgt.4s	v4, v1, v14
     f68:      	bit.16b	v2, v5, v4
     f6c:      	fcmgt.4s	v4, v0, v14
     f70:      	str	q5, [sp, #0x50]
     f74:      	bit.16b	v3, v5, v4
     f78:      	mov.16b	v5, v20
     f7c:      	ldr	q4, [sp, #0x260]
     f80:      	sshll.4s	v4, v4, #0x0
     f84:      	ldr	q7, [sp, #0x20]
     f88:      	add	x11, sp, #0x3b9
     f8c:      	stur	q7, [x11, #0xff]
     f90:      	ldr	q7, [sp, #0x200]
     f94:      	add	x11, sp, #0x1a9
     f98:      	stur	q7, [x11, #0xff]
     f9c:      	ldr	q7, [sp, #0x1f0]
     fa0:      	add	x11, sp, #0x199
     fa4:      	stur	q7, [x11, #0xff]
     fa8:      	add	x11, sp, #0x1c9
     fac:      	stur	q6, [x11, #0xff]
     fb0:      	add	x11, sp, #0x1b9
     fb4:      	stur	q20, [x11, #0xff]
     fb8:      	add	x11, sp, #0x1e9
     fbc:      	stur	q19, [x11, #0xff]
     fc0:      	add	x11, sp, #0x1d9
     fc4:      	stur	q18, [x11, #0xff]
     fc8:      	fcmeq.4s	v1, v1, v1
     fcc:      	fcmeq.4s	v0, v0, v0
     fd0:      	bsl.16b	v0, v3, v21
     fd4:      	str	q21, [sp, #0x40]
     fd8:      	bsl.16b	v1, v2, v21
     fdc:      	bic.16b	v18, v1, v4
     fe0:      	ldr	q1, [sp, #0x280]
     fe4:      	bic.16b	v19, v0, v1
     fe8:      	add	x11, sp, #0x209
     fec:      	stur	q19, [x11, #0xff]
     ff0:      	add	x11, sp, #0x1f9
     ff4:      	stur	q18, [x11, #0xff]
     ff8:      	mov	w11, #0x4               ; =4
     ffc:      	add	x12, sp, #0x4d8
    1000:      	add	x13, sp, #0x3b8
    1004:      	add	x14, sp, #0x298
    1008:      	mov	w15, #0x1               ; =1
    100c:      	mov	w16, #0x2               ; =2
    1010:      	mov	w17, #0x3               ; =3
    1014:      	dup.2d	v7, x11
    1018:      	mov	w0, #0x4                ; =4
    101c:      	mov.16b	v0, v7
    1020:      	mov.16b	v2, v7
    1024:      	mov.16b	v3, v7
    1028:      	ldp	q10, q11, [sp, #0xf0]
    102c:      	ldp	q22, q21, [sp, #0x80]
    1030:      	ldr	q14, [sp, #0xd0]
    1034:      	ldr	q13, [sp, #0xa0]
    1038:      	stp	q3, q2, [sp, #0x250]
    103c:      	str	q7, [sp, #0x280]
    1040:      	stp	q19, q18, [sp, #0x120]
    1044:      	stp	q28, q23, [sp, #0x140]
    1048:      	stp	q6, q5, [sp, #0x160]
    104c:      	dup.2d	v24, x12
    1050:      	add.2d	v1, v0, v24
    1054:      	stp	q1, q0, [sp, #0x220]
    1058:      	ldp	q0, q3, [sp, #0x250]
    105c:      	add.2d	v2, v3, v24
    1060:      	str	q2, [sp, #0x210]
    1064:      	add.2d	v0, v0, v24
    1068:      	str	q0, [sp, #0x110]
    106c:      	add.2d	v4, v0, v12
    1070:      	add.2d	v19, v2, v10
    1074:      	ldr	q0, [sp, #0x30]
    1078:      	add.2d	v20, v1, v0
    107c:      	add.2d	v18, v7, v15
    1080:      	add.2d	v18, v18, v24
    1084:      	lsl	x20, x0, #5
    1088:      	mov.d	x0, v18[1]
    108c:      	add	x1, x13, x20
    1090:      	ldp	q23, q25, [x1]
    1094:      	fsub.4s	v8, v25, v11
    1098:      	mov.d	x1, v20[1]
    109c:      	fmov	x2, d18
    10a0:      	fsub.4s	v31, v23, v11
    10a4:      	ldr	b18, [x2]
    10a8:      	fcmge.4s	v23, v31, v22
    10ac:      	ld1.b	{ v18 }[1], [x0]
    10b0:      	fmov	x0, d20
    10b4:      	fcmge.4s	v20, v8, v22
    10b8:      	mov.d	x2, v19[1]
    10bc:      	ld1.b	{ v18 }[2], [x0]
    10c0:      	ldr	q7, [sp, #0x70]
    10c4:      	fcmge.4s	v25, v7, v31
    10c8:      	fcmge.4s	v12, v7, v8
    10cc:      	fmov	x0, d19
    10d0:      	and.16b	v19, v20, v12
    10d4:      	ld1.b	{ v18 }[3], [x1]
    10d8:      	and.16b	v20, v23, v25
    10dc:      	mov.d	x21, v4[1]
    10e0:      	and.16b	v20, v20, v31
    10e4:      	ld1.b	{ v18 }[4], [x0]
    10e8:      	fmov	x0, d4
    10ec:      	and.16b	v4, v19, v8
    10f0:      	ldr	q5, [sp, #0xe0]
    10f4:      	fmul.4s	v19, v4, v5
    10f8:      	fmul.4s	v23, v20, v5
    10fc:      	ld1.b	{ v18 }[5], [x2]
    1100:      	movi.4s	v1, #0x4b, lsl #24
    1104:      	mvni.4s	v2, #0x80, lsl #24
    1108:      	mov.16b	v25, v2
    110c:      	bsl.16b	v25, v1, v23
    1110:      	mov.16b	v12, v2
    1114:      	bsl.16b	v12, v1, v19
    1118:      	fadd.4s	v19, v19, v12
    111c:      	fadd.4s	v23, v23, v25
    1120:      	ld1.b	{ v18 }[6], [x0]
    1124:      	fsub.4s	v23, v23, v25
    1128:      	fsub.4s	v19, v19, v12
    112c:      	fcvtzs.4s	v12, v19
    1130:      	fcvtzs.4s	v23, v23
    1134:      	scvtf.4s	v19, v23
    1138:      	scvtf.4s	v25, v12
    113c:      	fmul.4s	v15, v25, v14
    1140:      	fmul.4s	v27, v19, v14
    1144:      	fsub.4s	v20, v20, v27
    1148:      	ldp	q2, q16, [sp, #0xb0]
    114c:      	fmul.4s	v19, v19, v16
    1150:      	fmul.4s	v25, v25, v16
    1154:      	fsub.4s	v4, v4, v15
    1158:      	fsub.4s	v4, v4, v25
    115c:      	fsub.4s	v19, v20, v19
    1160:      	ldr	q1, [sp, #0x180]
    1164:      	fmul.4s	v20, v19, v1
    1168:      	fmul.4s	v25, v4, v1
    116c:      	fadd.4s	v25, v25, v2
    1170:      	fadd.4s	v20, v20, v2
    1174:      	fmul.4s	v20, v19, v20
    1178:      	fmul.4s	v25, v4, v25
    117c:      	fadd.4s	v25, v25, v13
    1180:      	fadd.4s	v20, v20, v13
    1184:      	fmul.4s	v20, v19, v20
    1188:      	fmul.4s	v25, v4, v25
    118c:      	fadd.4s	v25, v25, v21
    1190:      	fadd.4s	v20, v20, v21
    1194:      	fmul.4s	v20, v19, v20
    1198:      	fmul.4s	v25, v4, v25
    119c:      	ldr	q6, [sp, #0x60]
    11a0:      	fadd.4s	v25, v25, v6
    11a4:      	fadd.4s	v20, v20, v6
    11a8:      	fmul.4s	v20, v19, v20
    11ac:      	fmul.4s	v25, v4, v25
    11b0:      	movi.4s	v3, #0x3f, lsl #24
    11b4:      	fadd.4s	v25, v25, v3
    11b8:      	fmul.4s	v27, v4, v4
    11bc:      	fmul.4s	v15, v19, v19
    11c0:      	fadd.4s	v20, v20, v3
    11c4:      	fmul.4s	v20, v15, v20
    11c8:      	sshr.4s	v15, v23, #0x1
    11cc:      	sshr.4s	v28, v12, #0x1
    11d0:      	shl.4s	v29, v28, #0x17
    11d4:      	shl.4s	v30, v15, #0x17
    11d8:      	fmul.4s	v27, v27, v25
    11dc:      	add.4s	v25, v30, v26
    11e0:      	add.4s	v29, v29, v26
    11e4:      	sub.4s	v28, v12, v28
    11e8:      	sub.4s	v23, v23, v15
    11ec:      	shl.4s	v23, v23, #0x17
    11f0:      	fadd.4s	v27, v4, v27
    11f4:      	shl.4s	v4, v28, #0x17
    11f8:      	add.4s	v4, v4, v26
    11fc:      	fcmgt.4s	v15, v22, v8
    1200:      	dup.2d	v28, x15
    1204:      	fadd.4s	v30, v19, v20
    1208:      	fcmgt.4s	v19, v22, v31
    120c:      	ldr	q17, [sp, #0x280]
    1210:      	orr.16b	v20, v17, v28
    1214:      	mvn.16b	v28, v24
    1218:      	ldp	q17, q9, [sp, #0x230]
    121c:      	add.2d	v24, v24, v9
    1220:      	add.2d	v12, v20, v24
    1224:      	add.4s	v23, v23, v26
    1228:      	mov.d	x2, v12[1]
    122c:      	fmov	x3, d12
    1230:      	sub.2d	v12, v17, v28
    1234:      	add.2d	v12, v12, v0
    1238:      	fadd.4s	v30, v30, v26
    123c:      	mov.d	x5, v12[1]
    1240:      	fmov	x7, d12
    1244:      	ldp	q0, q9, [sp, #0x260]
    1248:      	sub.2d	v12, v0, v28
    124c:      	ldr	q0, [sp, #0x250]
    1250:      	sub.2d	v28, v0, v28
    1254:      	fadd.4s	v27, v27, v26
    1258:      	add.2d	v28, v28, v9
    125c:      	ldr	q0, [sp, #0x1f0]
    1260:      	add.2d	v12, v12, v10
    1264:      	mov.d	x6, v12[1]
    1268:      	fmov	x19, d12
    126c:      	fmul.4s	v27, v27, v29
    1270:      	mov.d	x1, v28[1]
    1274:      	fmov	x4, d28
    1278:      	fmov	x0, d20
    127c:      	lsl	x0, x0, #5
    1280:      	fmul.4s	v20, v30, v25
    1284:      	add	x22, x13, x0
    1288:      	ldp	q28, q25, [x22]
    128c:      	fsub.4s	v25, v25, v11
    1290:      	fsub.4s	v12, v28, v11
    1294:      	fmul.4s	v20, v20, v23
    1298:      	fcmge.4s	v23, v12, v22
    129c:      	fcmge.4s	v28, v25, v22
    12a0:      	fcmge.4s	v29, v7, v12
    12a4:      	fcmge.4s	v30, v7, v25
    12a8:      	and.16b	v28, v28, v30
    12ac:      	fmul.4s	v4, v27, v4
    12b0:      	and.16b	v23, v23, v29
    12b4:      	and.16b	v23, v23, v12
    12b8:      	and.16b	v27, v28, v25
    12bc:      	fmul.4s	v28, v27, v5
    12c0:      	fmul.4s	v29, v23, v5
    12c4:      	bic.16b	v30, v4, v15
    12c8:      	mvni.4s	v17, #0x80, lsl #24
    12cc:      	movi.4s	v9, #0x4b, lsl #24
    12d0:      	mov.16b	v4, v17
    12d4:      	bsl.16b	v4, v9, v29
    12d8:      	mov.16b	v15, v17
    12dc:      	bsl.16b	v15, v9, v28
    12e0:      	fadd.4s	v28, v28, v15
    12e4:      	fadd.4s	v29, v29, v4
    12e8:      	fsub.4s	v4, v29, v4
    12ec:      	bic.16b	v20, v20, v19
    12f0:      	fsub.4s	v19, v28, v15
    12f4:      	fcvtzs.4s	v19, v19
    12f8:      	fcvtzs.4s	v4, v4
    12fc:      	scvtf.4s	v28, v4
    1300:      	scvtf.4s	v29, v19
    1304:      	fmul.4s	v15, v28, v14
    1308:      	fsub.4s	v23, v23, v15
    130c:      	fmul.4s	v15, v29, v14
    1310:      	fsub.4s	v27, v27, v15
    1314:      	fcmgt.4s	v15, v8, v7
    1318:      	ld1.b	{ v18 }[7], [x21]
    131c:      	fmul.4s	v29, v29, v16
    1320:      	fsub.4s	v27, v27, v29
    1324:      	fcmgt.4s	v29, v31, v7
    1328:      	fmul.4s	v28, v28, v16
    132c:      	fsub.4s	v23, v23, v28
    1330:      	ldr	q9, [sp, #0x50]
    1334:      	bit.16b	v20, v9, v29
    1338:      	fmul.4s	v28, v23, v1
    133c:      	fmul.4s	v29, v27, v1
    1340:      	fadd.4s	v29, v29, v2
    1344:      	fadd.4s	v28, v28, v2
    1348:      	fmul.4s	v28, v23, v28
    134c:      	fmul.4s	v29, v27, v29
    1350:      	fadd.4s	v29, v29, v13
    1354:      	fadd.4s	v28, v28, v13
    1358:      	fmul.4s	v28, v23, v28
    135c:      	fmul.4s	v29, v27, v29
    1360:      	fadd.4s	v29, v29, v21
    1364:      	fadd.4s	v28, v28, v21
    1368:      	fmul.4s	v28, v23, v28
    136c:      	fmul.4s	v29, v27, v29
    1370:      	fadd.4s	v29, v29, v6
    1374:      	fadd.4s	v28, v28, v6
    1378:      	fmul.4s	v28, v23, v28
    137c:      	bit.16b	v30, v9, v15
    1380:      	fmul.4s	v29, v27, v29
    1384:      	fadd.4s	v28, v28, v3
    1388:      	fmul.4s	v15, v23, v23
    138c:      	fmul.4s	v28, v15, v28
    1390:      	fmul.4s	v15, v27, v27
    1394:      	fadd.4s	v29, v29, v3
    1398:      	fmul.4s	v29, v15, v29
    139c:      	cmeq.8b	v18, v18, #0
    13a0:      	sshll.8h	v18, v18, #0x0
    13a4:      	fadd.4s	v27, v27, v29
    13a8:      	sshll2.4s	v29, v18, #0x0
    13ac:      	sshll.4s	v15, v18, #0x0
    13b0:      	fcmeq.4s	v31, v31, v31
    13b4:      	fcmeq.4s	v8, v8, v8
    13b8:      	add	x30, x14, x20
    13bc:      	fadd.4s	v18, v23, v28
    13c0:      	fadd.4s	v18, v18, v26
    13c4:      	ldr	q10, [sp, #0x40]
    13c8:      	mov.16b	v23, v8
    13cc:      	bsl.16b	v23, v30, v10
    13d0:      	sshr.4s	v28, v4, #0x1
    13d4:      	sshr.4s	v30, v19, #0x1
    13d8:      	sub.4s	v19, v19, v30
    13dc:      	shl.4s	v30, v30, #0x17
    13e0:      	sub.4s	v4, v4, v28
    13e4:      	fadd.4s	v27, v27, v26
    13e8:      	shl.4s	v28, v28, #0x17
    13ec:      	add.4s	v28, v28, v26
    13f0:      	add.4s	v30, v30, v26
    13f4:      	shl.4s	v4, v4, #0x17
    13f8:      	shl.4s	v19, v19, #0x17
    13fc:      	bif.16b	v20, v10, v31
    1400:      	add.4s	v8, v19, v26
    1404:      	add.4s	v4, v4, v26
    1408:      	dup.2d	v19, x16
    140c:      	ldr	q17, [sp, #0x280]
    1410:      	orr.16b	v31, v17, v19
    1414:      	bic.16b	v15, v20, v15
    1418:      	add.2d	v19, v31, v24
    141c:      	mov.d	x21, v19[1]
    1420:      	fmov	x22, d19
    1424:      	fcmgt.4s	v19, v22, v25
    1428:      	bic.16b	v23, v23, v29
    142c:      	ldr	q20, [sp, #0x1c0]
    1430:      	ldp	q17, q3, [sp, #0x210]
    1434:      	add.2d	v20, v3, v20
    1438:      	mov.d	x23, v20[1]
    143c:      	fmov	x24, d20
    1440:      	ldr	q20, [sp, #0x1e0]
    1444:      	ldr	q3, [sp, #0x110]
    1448:      	add.2d	v29, v3, v20
    144c:      	fmul.4s	v20, v27, v30
    1450:      	ldr	q27, [sp, #0x1d0]
    1454:      	add.2d	v27, v17, v27
    1458:      	mov.d	x25, v27[1]
    145c:      	mov.d	x26, v29[1]
    1460:      	fmul.4s	v28, v18, v28
    1464:      	fmov	x28, d27
    1468:      	fmov	x27, d29
    146c:      	fmov	x20, d31
    1470:      	lsl	x20, x20, #5
    1474:      	stp	q15, q23, [x30]
    1478:      	add	x30, x13, x20
    147c:      	ldp	q27, q18, [x30]
    1480:      	fsub.4s	v18, v18, v11
    1484:      	fsub.4s	v31, v27, v11
    1488:      	ldr	q17, [sp, #0x200]
    148c:      	fadd.4s	v17, v17, v23
    1490:      	fcmge.4s	v23, v31, v22
    1494:      	fcmge.4s	v27, v18, v22
    1498:      	fcmge.4s	v29, v7, v18
    149c:      	and.16b	v27, v27, v29
    14a0:      	fcmge.4s	v29, v7, v31
    14a4:      	fadd.4s	v0, v0, v15
    14a8:      	stp	q0, q17, [sp, #0x1f0]
    14ac:      	and.16b	v23, v23, v29
    14b0:      	and.16b	v23, v23, v31
    14b4:      	and.16b	v27, v27, v18
    14b8:      	fmul.4s	v29, v27, v5
    14bc:      	fmul.4s	v30, v23, v5
    14c0:      	fmul.4s	v4, v28, v4
    14c4:      	movi.4s	v0, #0x4b, lsl #24
    14c8:      	mvni.4s	v17, #0x80, lsl #24
    14cc:      	mov.16b	v28, v17
    14d0:      	bsl.16b	v28, v0, v30
    14d4:      	fadd.4s	v30, v30, v28
    14d8:      	fsub.4s	v28, v30, v28
    14dc:      	mov.16b	v30, v17
    14e0:      	bsl.16b	v30, v0, v29
    14e4:      	fadd.4s	v29, v29, v30
    14e8:      	fmul.4s	v20, v20, v8
    14ec:      	fsub.4s	v29, v29, v30
    14f0:      	fcvtzs.4s	v29, v29
    14f4:      	fcvtzs.4s	v28, v28
    14f8:      	scvtf.4s	v30, v28
    14fc:      	scvtf.4s	v8, v29
    1500:      	bic.16b	v19, v20, v19
    1504:      	fmul.4s	v20, v30, v14
    1508:      	fsub.4s	v20, v23, v20
    150c:      	fmul.4s	v23, v8, v14
    1510:      	fsub.4s	v23, v27, v23
    1514:      	fcmgt.4s	v27, v22, v12
    1518:      	fmul.4s	v30, v30, v16
    151c:      	fmul.4s	v8, v8, v16
    1520:      	fsub.4s	v23, v23, v8
    1524:      	fsub.4s	v20, v20, v30
    1528:      	fmul.4s	v30, v20, v1
    152c:      	fmul.4s	v8, v23, v1
    1530:      	mov.16b	v17, v2
    1534:      	fadd.4s	v8, v8, v2
    1538:      	fadd.4s	v30, v30, v2
    153c:      	fmul.4s	v30, v20, v30
    1540:      	fmul.4s	v8, v23, v8
    1544:      	fadd.4s	v8, v8, v13
    1548:      	fadd.4s	v30, v30, v13
    154c:      	fmul.4s	v30, v20, v30
    1550:      	fmul.4s	v8, v23, v8
    1554:      	fadd.4s	v8, v8, v21
    1558:      	fadd.4s	v30, v30, v21
    155c:      	fmul.4s	v30, v20, v30
    1560:      	fmul.4s	v8, v23, v8
    1564:      	fadd.4s	v8, v8, v6
    1568:      	fadd.4s	v30, v30, v6
    156c:      	fmul.4s	v30, v20, v30
    1570:      	fmul.4s	v8, v23, v8
    1574:      	movi.4s	v0, #0x3f, lsl #24
    1578:      	fadd.4s	v8, v8, v0
    157c:      	fadd.4s	v30, v30, v0
    1580:      	bic.16b	v4, v4, v27
    1584:      	fmul.4s	v27, v20, v20
    1588:      	fmul.4s	v27, v27, v30
    158c:      	fmul.4s	v30, v23, v23
    1590:      	fmul.4s	v30, v30, v8
    1594:      	fcmgt.4s	v8, v12, v7
    1598:      	bsl.16b	v8, v9, v4
    159c:      	fcmgt.4s	v4, v25, v7
    15a0:      	fadd.4s	v23, v23, v30
    15a4:      	fadd.4s	v20, v20, v27
    15a8:      	fadd.4s	v23, v23, v26
    15ac:      	sshr.4s	v27, v28, #0x1
    15b0:      	mov.16b	v15, v4
    15b4:      	bsl.16b	v15, v9, v19
    15b8:      	sshr.4s	v4, v29, #0x1
    15bc:      	shl.4s	v19, v4, #0x17
    15c0:      	add.4s	v19, v19, v26
    15c4:      	fmul.4s	v23, v23, v19
    15c8:      	shl.4s	v19, v27, #0x17
    15cc:      	fadd.4s	v20, v20, v26
    15d0:      	add.4s	v19, v19, v26
    15d4:      	fmul.4s	v19, v20, v19
    15d8:      	sub.4s	v20, v29, v4
    15dc:      	sub.4s	v4, v28, v27
    15e0:      	shl.4s	v4, v4, #0x17
    15e4:      	add.4s	v4, v4, v26
    15e8:      	fmul.4s	v27, v19, v4
    15ec:      	ldr	b28, [x3]
    15f0:      	ld1.b	{ v28 }[1], [x2]
    15f4:      	ld1.b	{ v28 }[2], [x7]
    15f8:      	ld1.b	{ v28 }[3], [x5]
    15fc:      	fcmeq.4s	v4, v12, v12
    1600:      	ldp	q12, q0, [sp, #0x270]
    1604:      	fcmeq.4s	v19, v25, v25
    1608:      	ld1.b	{ v28 }[4], [x19]
    160c:      	shl.4s	v20, v20, #0x17
    1610:      	add.4s	v20, v20, v26
    1614:      	fmul.4s	v20, v23, v20
    1618:      	fcmgt.4s	v23, v22, v18
    161c:      	ld1.b	{ v28 }[5], [x6]
    1620:      	bic.16b	v23, v20, v23
    1624:      	fcmgt.4s	v20, v22, v31
    1628:      	bic.16b	v20, v27, v20
    162c:      	fcmgt.4s	v25, v31, v7
    1630:      	ld1.b	{ v28 }[6], [x4]
    1634:      	bsl.16b	v25, v9, v20
    1638:      	dup.2d	v20, x17
    163c:      	orr.16b	v27, v0, v20
    1640:      	ld1.b	{ v28 }[7], [x1]
    1644:      	add.2d	v20, v27, v24
    1648:      	mov.d	x3, v20[1]
    164c:      	fmov	x4, d20
    1650:      	fcmgt.4s	v24, v18, v7
    1654:      	cmeq.8b	v28, v28, #0
    1658:      	fcmeq.4s	v20, v31, v31
    165c:      	fcmeq.4s	v18, v18, v18
    1660:      	ldr	q29, [sp, #0x1b0]
    1664:      	add.2d	v29, v3, v29
    1668:      	ldp	q3, q0, [sp, #0x190]
    166c:      	ldr	q1, [sp, #0x210]
    1670:      	add.2d	v2, v1, v0
    1674:      	ldp	q1, q0, [sp, #0x220]
    1678:      	add.2d	v1, v1, v3
    167c:      	sshll.8h	v3, v28, #0x0
    1680:      	mov.d	x5, v1[1]
    1684:      	fmov	x6, d1
    1688:      	mov.d	x2, v2[1]
    168c:      	bit.16b	v23, v9, v24
    1690:      	fmov	x7, d2
    1694:      	mov.d	x1, v29[1]
    1698:      	fmov	x19, d27
    169c:      	lsl	x19, x19, #5
    16a0:      	mov.16b	v24, v19
    16a4:      	bsl.16b	v24, v15, v10
    16a8:      	ldr	q15, [sp, #0x240]
    16ac:      	add	x30, x13, x19
    16b0:      	ldp	q2, q1, [x30]
    16b4:      	fmov	x30, d29
    16b8:      	fsub.4s	v2, v2, v11
    16bc:      	mov.16b	v27, v4
    16c0:      	bsl.16b	v27, v8, v10
    16c4:      	fsub.4s	v1, v1, v11
    16c8:      	fcmge.4s	v4, v1, v22
    16cc:      	fcmge.4s	v28, v2, v22
    16d0:      	fcmge.4s	v29, v7, v1
    16d4:      	fcmge.4s	v30, v7, v2
    16d8:      	mov.16b	v19, v18
    16dc:      	bsl.16b	v19, v23, v10
    16e0:      	and.16b	v18, v28, v30
    16e4:      	and.16b	v4, v4, v29
    16e8:      	and.16b	v23, v4, v1
    16ec:      	and.16b	v28, v18, v2
    16f0:      	fmul.4s	v4, v28, v5
    16f4:      	bif.16b	v25, v10, v20
    16f8:      	fmul.4s	v18, v23, v5
    16fc:      	ldr	q5, [sp, #0x170]
    1700:      	mvni.4s	v29, #0x80, lsl #24
    1704:      	movi.4s	v30, #0x4b, lsl #24
    1708:      	mov.16b	v20, v29
    170c:      	bsl.16b	v20, v30, v18
    1710:      	bsl.16b	v29, v30, v4
    1714:      	fadd.4s	v4, v4, v29
    1718:      	fadd.4s	v18, v18, v20
    171c:      	sshll.4s	v30, v3, #0x0
    1720:      	fsub.4s	v18, v18, v20
    1724:      	fsub.4s	v4, v4, v29
    1728:      	fcvtzs.4s	v4, v4
    172c:      	fcvtzs.4s	v18, v18
    1730:      	scvtf.4s	v29, v18
    1734:      	bic.16b	v20, v27, v30
    1738:      	scvtf.4s	v27, v4
    173c:      	fmul.4s	v30, v29, v14
    1740:      	fsub.4s	v23, v23, v30
    1744:      	fmul.4s	v30, v27, v14
    1748:      	fsub.4s	v28, v28, v30
    174c:      	fmul.4s	v27, v27, v16
    1750:      	fsub.4s	v27, v28, v27
    1754:      	ldr	b28, [x22]
    1758:      	ld1.b	{ v28 }[1], [x21]
    175c:      	ld1.b	{ v28 }[2], [x24]
    1760:      	ld1.b	{ v28 }[3], [x23]
    1764:      	ld1.b	{ v28 }[4], [x28]
    1768:      	ld1.b	{ v28 }[5], [x25]
    176c:      	ld1.b	{ v28 }[6], [x27]
    1770:      	ld1.b	{ v28 }[7], [x26]
    1774:      	cmeq.8b	v28, v28, #0
    1778:      	sshll2.4s	v3, v3, #0x0
    177c:      	sshll.8h	v28, v28, #0x0
    1780:      	fmul.4s	v29, v29, v16
    1784:      	fsub.4s	v23, v23, v29
    1788:      	ldr	q16, [sp, #0x180]
    178c:      	fmul.4s	v29, v23, v16
    1790:      	fadd.4s	v29, v29, v17
    1794:      	fmul.4s	v29, v23, v29
    1798:      	fadd.4s	v29, v29, v13
    179c:      	fmul.4s	v29, v23, v29
    17a0:      	fadd.4s	v29, v29, v21
    17a4:      	fmul.4s	v29, v23, v29
    17a8:      	fadd.4s	v29, v29, v6
    17ac:      	bic.16b	v3, v24, v3
    17b0:      	fmul.4s	v24, v23, v29
    17b4:      	movi.4s	v30, #0x3f, lsl #24
    17b8:      	fadd.4s	v24, v24, v30
    17bc:      	fmul.4s	v29, v23, v23
    17c0:      	fmul.4s	v24, v29, v24
    17c4:      	sshll.4s	v29, v28, #0x0
    17c8:      	bic.16b	v25, v25, v29
    17cc:      	fmul.4s	v29, v27, v16
    17d0:      	fadd.4s	v29, v29, v17
    17d4:      	fmul.4s	v29, v27, v29
    17d8:      	fadd.4s	v29, v29, v13
    17dc:      	fmul.4s	v29, v27, v29
    17e0:      	sshll2.4s	v28, v28, #0x0
    17e4:      	fadd.4s	v29, v29, v21
    17e8:      	fmul.4s	v29, v27, v29
    17ec:      	fadd.4s	v29, v29, v6
    17f0:      	ldr	q6, [sp, #0x160]
    17f4:      	fmul.4s	v29, v27, v29
    17f8:      	fadd.4s	v29, v29, v30
    17fc:      	bic.16b	v19, v19, v28
    1800:      	fmul.4s	v28, v27, v27
    1804:      	fmul.4s	v28, v28, v29
    1808:      	add	x0, x14, x0
    180c:      	fadd.4s	v6, v6, v3
    1810:      	stp	q20, q3, [x0]
    1814:      	fadd.4s	v3, v27, v28
    1818:      	fadd.4s	v23, v23, v24
    181c:      	fadd.4s	v3, v3, v26
    1820:      	sshr.4s	v24, v18, #0x1
    1824:      	sshr.4s	v27, v4, #0x1
    1828:      	fadd.4s	v5, v5, v20
    182c:      	shl.4s	v20, v27, #0x17
    1830:      	add.4s	v20, v20, v26
    1834:      	fmul.4s	v3, v3, v20
    1838:      	shl.4s	v20, v24, #0x17
    183c:      	add.4s	v20, v20, v26
    1840:      	fadd.4s	v23, v23, v26
    1844:      	fmul.4s	v20, v23, v20
    1848:      	ldp	q28, q23, [sp, #0x140]
    184c:      	add	x0, x14, x20
    1850:      	fadd.4s	v28, v28, v19
    1854:      	stp	q25, q19, [x0]
    1858:      	fadd.4s	v23, v23, v25
    185c:      	sub.4s	v4, v4, v27
    1860:      	sub.4s	v18, v18, v24
    1864:      	shl.4s	v18, v18, #0x17
    1868:      	add.4s	v18, v18, v26
    186c:      	fmul.4s	v18, v20, v18
    1870:      	ldr	b19, [x4]
    1874:      	ld1.b	{ v19 }[1], [x3]
    1878:      	ld1.b	{ v19 }[2], [x6]
    187c:      	ld1.b	{ v19 }[3], [x5]
    1880:      	ld1.b	{ v19 }[4], [x7]
    1884:      	shl.4s	v4, v4, #0x17
    1888:      	add.4s	v4, v4, v26
    188c:      	fmul.4s	v3, v3, v4
    1890:      	fcmgt.4s	v4, v22, v2
    1894:      	bic.16b	v3, v3, v4
    1898:      	fcmgt.4s	v4, v22, v1
    189c:      	bic.16b	v4, v18, v4
    18a0:      	fcmgt.4s	v18, v1, v7
    18a4:      	bit.16b	v4, v9, v18
    18a8:      	fcmgt.4s	v18, v2, v7
    18ac:      	ldr	q7, [sp, #0x280]
    18b0:      	bit.16b	v3, v9, v18
    18b4:      	ld1.b	{ v19 }[5], [x2]
    18b8:      	ld1.b	{ v19 }[6], [x30]
    18bc:      	fcmeq.4s	v2, v2, v2
    18c0:      	bsl.16b	v2, v3, v10
    18c4:      	ld1.b	{ v19 }[7], [x1]
    18c8:      	cmeq.8b	v3, v19, #0
    18cc:      	ldp	q19, q18, [sp, #0x120]
    18d0:      	fcmeq.4s	v1, v1, v1
    18d4:      	sshll.8h	v3, v3, #0x0
    18d8:      	bsl.16b	v1, v4, v10
    18dc:      	ldr	q10, [sp, #0xf0]
    18e0:      	sshll2.4s	v4, v3, #0x0
    18e4:      	bic.16b	v1, v1, v4
    18e8:      	sshll.4s	v3, v3, #0x0
    18ec:      	bic.16b	v2, v2, v3
    18f0:      	add	x0, x14, x19
    18f4:      	fadd.4s	v19, v19, v1
    18f8:      	stp	q2, q1, [x0]
    18fc:      	fadd.4s	v18, v18, v2
    1900:      	ldp	q3, q2, [sp, #0x250]
    1904:      	dup.2d	v1, x11
    1908:      	add.2d	v2, v2, v1
    190c:      	add.2d	v0, v0, v1
    1910:      	add.2d	v3, v3, v1
    1914:      	add.2d	v7, v7, v1
    1918:      	fmov	x0, d7
    191c:      	cmp	x0, #0x8
    1920:      	b.lt	0x1038 <ltmp0+0x1038>
    1924:      	ldp	q0, q1, [sp, #0x10]
    1928:      	sshll.4s	v0, v0, #0x0
    192c:      	ldr	q2, [sp, #0x100]
    1930:      	fsub.4s	v2, v1, v2
    1934:      	movi.2d	v1, #0000000000000000
    1938:      	mov.s	v1[0], v2[0]
    193c:      	mov	w11, #-0x3d300000       ; =-1026555904
    1940:      	dup.4s	v2, w11
    1944:      	fcmge.4s	v3, v1, v2
    1948:      	mov	w11, #0x42c80000        ; =1120403456
    194c:      	dup.4s	v4, w11
    1950:      	fcmge.4s	v7, v4, v1
    1954:      	and.16b	v3, v3, v7
    1958:      	and.16b	v3, v3, v1
    195c:      	mov	w11, #0xaa3b            ; =43579
    1960:      	movk	w11, #0x3fb8, lsl #16
    1964:      	dup.4s	v7, w11
    1968:      	fmul.4s	v7, v3, v7
    196c:      	movi.4s	v16, #0x4b, lsl #24
    1970:      	mvni.4s	v17, #0x80, lsl #24
    1974:      	bif.16b	v16, v7, v17
    1978:      	fadd.4s	v7, v7, v16
    197c:      	fsub.4s	v7, v7, v16
    1980:      	fcvtzs.4s	v7, v7
    1984:      	scvtf.4s	v16, v7
    1988:      	mov	w11, #0x7200            ; =29184
    198c:      	movk	w11, #0xbf31, lsl #16
    1990:      	dup.4s	v17, w11
    1994:      	fmul.4s	v17, v16, v17
    1998:      	fadd.4s	v3, v3, v17
    199c:      	mov	w11, #0xbe8e            ; =48782
    19a0:      	movk	w11, #0xb5bf, lsl #16
    19a4:      	dup.4s	v17, w11
    19a8:      	fmul.4s	v16, v16, v17
    19ac:      	fadd.4s	v3, v3, v16
    19b0:      	mov	w11, #0x2bda            ; =11226
    19b4:      	movk	w11, #0x3950, lsl #16
    19b8:      	dup.4s	v16, w11
    19bc:      	mov	w11, #0x96c9            ; =38601
    19c0:      	movk	w11, #0x3ab6, lsl #16
    19c4:      	dup.4s	v17, w11
    19c8:      	fmul.4s	v16, v3, v16
    19cc:      	fadd.4s	v16, v16, v17
    19d0:      	fmul.4s	v16, v3, v16
    19d4:      	mov	w11, #0x88a6            ; =34982
    19d8:      	movk	w11, #0x3c08, lsl #16
    19dc:      	dup.4s	v17, w11
    19e0:      	fadd.4s	v16, v16, v17
    19e4:      	fmul.4s	v16, v3, v16
    19e8:      	mov	w11, #0xaa7a            ; =43642
    19ec:      	movk	w11, #0x3d2a, lsl #16
    19f0:      	dup.4s	v17, w11
    19f4:      	fadd.4s	v16, v16, v17
    19f8:      	fmul.4s	v16, v3, v16
    19fc:      	mov	w11, #0xaaab            ; =43691
    1a00:      	movk	w11, #0x3e2a, lsl #16
    1a04:      	dup.4s	v17, w11
    1a08:      	fadd.4s	v16, v16, v17
    1a0c:      	fmul.4s	v16, v3, v16
    1a10:      	movi.4s	v17, #0x3f, lsl #24
    1a14:      	fadd.4s	v16, v16, v17
    1a18:      	fmul.4s	v17, v3, v3
    1a1c:      	fmul.4s	v16, v17, v16
    1a20:      	fadd.4s	v3, v3, v16
    1a24:      	fadd.4s	v3, v3, v26
    1a28:      	sshr.4s	v16, v7, #0x1
    1a2c:      	shl.4s	v17, v16, #0x17
    1a30:      	add.4s	v17, v17, v26
    1a34:      	fmul.4s	v3, v3, v17
    1a38:      	sub.4s	v7, v7, v16
    1a3c:      	shl.4s	v7, v7, #0x17
    1a40:      	add.4s	v7, v7, v26
    1a44:      	fmul.4s	v3, v3, v7
    1a48:      	fcmgt.4s	v2, v2, v1
    1a4c:      	bic.16b	v2, v3, v2
    1a50:      	fcmgt.4s	v3, v1, v4
    1a54:      	mvni.4s	v4, #0x7f, msl #16
    1a58:      	fneg.4s	v4, v4
    1a5c:      	bit.16b	v2, v4, v3
    1a60:      	fcmeq.4s	v1, v1, v1
    1a64:      	mvni.4s	v3, #0x3f, msl #16
    1a68:      	fneg.4s	v3, v3
    1a6c:      	bsl.16b	v1, v2, v3
    1a70:      	bic.16b	v0, v1, v0
    1a74:      	ldr	q2, [sp, #0x1f0]
    1a78:      	fadd.4s	v1, v0, v2
    1a7c:      	mov.s	v2[0], v1[0]
    1a80:      	fadd.4s	v1, v5, v2
    1a84:      	ldr	q2, [sp, #0x200]
    1a88:      	fadd.4s	v2, v6, v2
    1a8c:      	fadd.4s	v1, v23, v1
    1a90:      	fadd.4s	v2, v28, v2
    1a94:      	fadd.4s	v1, v18, v1
    1a98:      	fadd.4s	v2, v19, v2
    1a9c:      	rev64.4s	v3, v1
    1aa0:      	rev64.4s	v4, v2
    1aa4:      	fadd.4s	v1, v1, v3
    1aa8:      	fadd.4s	v2, v2, v4
    1aac:      	dup.4s	v3, v1[2]
    1ab0:      	dup.4s	v4, v2[2]
    1ab4:      	fadd.4s	v1, v1, v3
    1ab8:      	fadd.4s	v2, v2, v4
    1abc:      	fadd.4s	v1, v1, v2
    1ac0:      	movi	d2, #0000000000000000
    1ac4:      	fadd	s1, s1, s2
    1ac8:      	dup.4s	v2, v1[0]
    1acc:      	add	x11, sp, #0x1a9
    1ad0:      	ldur	q3, [x11, #0xff]
    1ad4:      	add	x11, sp, #0x199
    1ad8:      	ldur	q4, [x11, #0xff]
    1adc:      	add	x10, x8, x10
    1ae0:      	fdiv.4s	v4, v4, v2
    1ae4:      	fdiv.4s	v3, v3, v2
    1ae8:      	stp	q4, q3, [x10]
    1aec:      	add	x11, sp, #0x1c9
    1af0:      	ldur	q3, [x11, #0xff]
    1af4:      	add	x11, sp, #0x1b9
    1af8:      	ldur	q4, [x11, #0xff]
    1afc:      	fdiv.4s	v4, v4, v2
    1b00:      	fdiv.4s	v3, v3, v2
    1b04:      	stp	q4, q3, [x10, #0x20]
    1b08:      	add	x11, sp, #0x1e9
    1b0c:      	ldur	q3, [x11, #0xff]
    1b10:      	add	x11, sp, #0x1d9
    1b14:      	ldur	q4, [x11, #0xff]
    1b18:      	fdiv.4s	v4, v4, v2
    1b1c:      	fdiv.4s	v3, v3, v2
    1b20:      	stp	q4, q3, [x10, #0x40]
    1b24:      	add	x11, sp, #0x209
    1b28:      	ldur	q3, [x11, #0xff]
    1b2c:      	add	x11, sp, #0x1f9
    1b30:      	ldur	q4, [x11, #0xff]
    1b34:      	fdiv.4s	v4, v4, v2
    1b38:      	fdiv.4s	v3, v3, v2
    1b3c:      	stp	q4, q3, [x10, #0x60]
    1b40:      	add	x11, sp, #0x229
    1b44:      	ldur	q3, [x11, #0xff]
    1b48:      	add	x11, sp, #0x219
    1b4c:      	ldur	q4, [x11, #0xff]
    1b50:      	fdiv.4s	v4, v4, v2
    1b54:      	fdiv.4s	v3, v3, v2
    1b58:      	stp	q4, q3, [x10, #0x80]
    1b5c:      	add	x11, sp, #0x249
    1b60:      	ldur	q3, [x11, #0xff]
    1b64:      	add	x11, sp, #0x239
    1b68:      	ldur	q4, [x11, #0xff]
    1b6c:      	fdiv.4s	v4, v4, v2
    1b70:      	fdiv.4s	v3, v3, v2
    1b74:      	stp	q4, q3, [x10, #0xa0]
    1b78:      	add	x11, sp, #0x269
    1b7c:      	ldur	q3, [x11, #0xff]
    1b80:      	add	x11, sp, #0x259
    1b84:      	ldur	q4, [x11, #0xff]
    1b88:      	fdiv.4s	v4, v4, v2
    1b8c:      	fdiv.4s	v3, v3, v2
    1b90:      	stp	q4, q3, [x10, #0xc0]
    1b94:      	add	x11, sp, #0x289
    1b98:      	ldur	q3, [x11, #0xff]
    1b9c:      	add	x11, sp, #0x279
    1ba0:      	ldur	q4, [x11, #0xff]
    1ba4:      	fdiv.4s	v4, v4, v2
    1ba8:      	fdiv.4s	v2, v3, v2
    1bac:      	stp	q4, q2, [x10, #0xe0]
    1bb0:      	fdiv.4s	v0, v0, v1
    1bb4:      	str	s0, [x8, x9]
    1bb8:      	add	sp, sp, #0x880
    1bbc:      	ldp	x29, x30, [sp, #0x90]
    1bc0:      	ldp	x20, x19, [sp, #0x80]
    1bc4:      	ldp	x22, x21, [sp, #0x70]
    1bc8:      	ldp	x24, x23, [sp, #0x60]
    1bcc:      	ldp	x26, x25, [sp, #0x50]
    1bd0:      	ldp	x28, x27, [sp, #0x40]
    1bd4:      	ldp	d9, d8, [sp, #0x30]
    1bd8:      	ldp	d11, d10, [sp, #0x20]
    1bdc:      	ldp	d13, d12, [sp, #0x10]
    1be0:      	ldp	d15, d14, [sp], #0xa0
    1be4:      	ret

0000000000001be8 <_llm_rows.packet_batch.blocks>:
    1be8:      	stp	d15, d14, [sp, #-0xa0]!
    1bec:      	stp	d13, d12, [sp, #0x10]
    1bf0:      	stp	d11, d10, [sp, #0x20]
    1bf4:      	stp	d9, d8, [sp, #0x30]
    1bf8:      	stp	x28, x27, [sp, #0x40]
    1bfc:      	stp	x26, x25, [sp, #0x50]
    1c00:      	stp	x24, x23, [sp, #0x60]
    1c04:      	stp	x22, x21, [sp, #0x70]
    1c08:      	stp	x20, x19, [sp, #0x80]
    1c0c:      	stp	x29, x30, [sp, #0x90]
    1c10:      	sub	sp, sp, #0x1, lsl #12   ; =0x1000
    1c14:      	sub	sp, sp, #0xe0
    1c18:      	str	x0, [sp, #0x1c8]
    1c1c:      	cbz	w3, 0x5734 <_llm_rows.packet_batch.blocks+0x3b4c>
    1c20:      	mov	x19, x3
    1c24:      	mov	x20, x2
    1c28:      	mov	w22, #0x0               ; =0
    1c2c:      	add	x23, sp, #0xaf8
    1c30:      	add	x8, sp, #0xd38
    1c34:      	dup.2d	v0, x8
    1c38:      	str	q0, [sp, #0x30]
    1c3c:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1c40:      	ldr	q0, [x8]
    1c44:      	str	q0, [sp, #0x20]
    1c48:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1c4c:      	ldr	q0, [x8]
    1c50:      	str	q0, [sp, #0x1a0]
    1c54:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1c58:      	ldr	q0, [x8]
    1c5c:      	str	q0, [sp, #0x190]
    1c60:      	add	x28, sp, #0xfc0
    1c64:      	movi.2s	v8, #0x41
    1c68:      	mov	w8, #0x60               ; =96
    1c6c:      	fmov	d0, x8
    1c70:      	str	q0, [sp, #0x10]
    1c74:      	mvni.4s	v0, #0x7f, msl #16
    1c78:      	fneg.4s	v0, v0
    1c7c:      	str	q0, [sp, #0x2e0]
    1c80:      	mvni.4s	v0, #0x3f, msl #16
    1c84:      	fneg.4s	v0, v0
    1c88:      	str	q0, [sp, #0x3f0]
    1c8c:      	add	x27, sp, #0xc18
    1c90:      	ldp	w9, w8, [x2, #0x2c]
    1c94:      	str	w9, [sp, #0x1c4]
    1c98:      	str	w8, [sp, #0x1c0]
    1c9c:      	ldp	w24, w12, [x2]
    1ca0:      	ldp	w21, w8, [x2, #0x8]
    1ca4:      	str	x8, [sp, #0x1b8]
    1ca8:      	str	w3, [sp, #0x18c]
    1cac:      	b	0x1cf8 <_llm_rows.packet_batch.blocks+0x110>
    1cb0:      	mov	w8, #0x18               ; =24
    1cb4:      	str	w8, [x20, #0x24]
    1cb8:      	ldr	w19, [sp, #0x18c]
    1cbc:      	add	w8, w24, #0x1
    1cc0:      	ldr	w9, [sp, #0x1c4]
    1cc4:      	cmp	w8, w9
    1cc8:      	cset	w8, eq
    1ccc:      	csinc	w24, wzr, w24, eq
    1cd0:      	cinc	w9, w12, eq
    1cd4:      	ldr	w10, [sp, #0x1c0]
    1cd8:      	cmp	w9, w10
    1cdc:      	cset	w10, eq
    1ce0:      	ands	w8, w8, w10
    1ce4:      	csel	w12, wzr, w9, ne
    1ce8:      	add	w21, w21, w8
    1cec:      	add	w22, w22, #0x1
    1cf0:      	cmp	w22, w19
    1cf4:      	b.eq	0x5734 <_llm_rows.packet_batch.blocks+0x3b4c>
    1cf8:      	ubfiz	x8, x24, #5, #32
    1cfc:      	ldr	x13, [sp, #0x1b8]
    1d00:      	cmp	x8, x13
    1d04:      	csel	x9, x8, xzr, ls
    1d08:      	subs	x10, x13, x9
    1d0c:      	cmp	x10, #0x20
    1d10:      	mov	w11, #0x20              ; =32
    1d14:      	csel	x10, x10, x11, lo
    1d18:      	cmp	x13, x9
    1d1c:      	stp	w24, w12, [x20]
    1d20:      	str	w21, [x20, #0x8]
    1d24:      	str	wzr, [x20, #0x24]
    1d28:      	ccmp	x8, x13, #0x2, hi
    1d2c:      	csel	x26, x10, xzr, ls
    1d30:      	cmp	x26, #0x20
    1d34:      	b.lo	0x1d90 <_llm_rows.packet_batch.blocks+0x1a8>
    1d38:      	ldr	x26, [sp, #0x1c8]
    1d3c:      	mov	x0, x26
    1d40:      	mov	x1, x20
    1d44:      	mov	x25, x12
    1d48:      	bl	0x1d48 <_llm_rows.packet_batch.blocks+0x160>
    1d4c:      	mov	w8, #0x8                ; =8
    1d50:      	str	w8, [x20, #0x24]
    1d54:      	mov	x0, x26
    1d58:      	mov	x1, x20
    1d5c:      	bl	0x1d5c <_llm_rows.packet_batch.blocks+0x174>
    1d60:      	mov	w8, #0x10               ; =16
    1d64:      	str	w8, [x20, #0x24]
    1d68:      	mov	x0, x26
    1d6c:      	mov	x1, x20
    1d70:      	bl	0x1d70 <_llm_rows.packet_batch.blocks+0x188>
    1d74:      	mov	w8, #0x18               ; =24
    1d78:      	str	w8, [x20, #0x24]
    1d7c:      	mov	x0, x26
    1d80:      	mov	x1, x20
    1d84:      	bl	0x1d84 <_llm_rows.packet_batch.blocks+0x19c>
    1d88:      	mov	x12, x25
    1d8c:      	b	0x1cbc <_llm_rows.packet_batch.blocks+0xd4>
    1d90:      	lsr	x19, x26, #3
    1d94:      	cmp	x26, #0x8
    1d98:      	b.lo	0x1df4 <_llm_rows.packet_batch.blocks+0x20c>
    1d9c:      	str	wzr, [x20, #0x24]
    1da0:      	ldr	x0, [sp, #0x1c8]
    1da4:      	mov	x1, x20
    1da8:      	mov	x25, x12
    1dac:      	bl	0x1dac <_llm_rows.packet_batch.blocks+0x1c4>
    1db0:      	mov	x12, x25
    1db4:      	cmp	x19, #0x1
    1db8:      	b.eq	0x1df4 <_llm_rows.packet_batch.blocks+0x20c>
    1dbc:      	mov	w8, #0x8                ; =8
    1dc0:      	str	w8, [x20, #0x24]
    1dc4:      	ldr	x0, [sp, #0x1c8]
    1dc8:      	mov	x1, x20
    1dcc:      	bl	0x1dcc <_llm_rows.packet_batch.blocks+0x1e4>
    1dd0:      	mov	x12, x25
    1dd4:      	cmp	x19, #0x2
    1dd8:      	b.eq	0x1df4 <_llm_rows.packet_batch.blocks+0x20c>
    1ddc:      	mov	w8, #0x10               ; =16
    1de0:      	str	w8, [x20, #0x24]
    1de4:      	ldr	x0, [sp, #0x1c8]
    1de8:      	mov	x1, x20
    1dec:      	bl	0x1dec <_llm_rows.packet_batch.blocks+0x204>
    1df0:      	mov	x12, x25
    1df4:      	and	w8, w26, #0x7
    1df8:      	cbz	w8, 0x1cb0 <_llm_rows.packet_batch.blocks+0xc8>
    1dfc:      	dup.4s	v3, w8
    1e00:      	ldp	q0, q1, [sp, #0x190]
    1e04:      	cmhi.4s	v0, v3, v0
    1e08:      	cmhi.4s	v1, v3, v1
    1e0c:      	uzp1.8h	v4, v1, v0
    1e10:      	umaxv.8h	h2, v4
    1e14:      	fmov	w8, s2
    1e18:      	tbz	w8, #0x0, 0x1cb0 <_llm_rows.packet_batch.blocks+0xc8>
    1e1c:      	str	w12, [sp, #0x188]
    1e20:      	mov	x8, #0x0                ; =0
    1e24:      	ldr	x9, [sp, #0x1c8]
    1e28:      	ldr	x10, [x9]
    1e2c:      	ldr	x15, [x9, #0x30]
    1e30:      	ldr	q2, [sp, #0x20]
    1e34:      	str	q4, [sp, #0x3d0]
    1e38:      	and.16b	v2, v4, v2
    1e3c:      	addv.8h	h23, v2
    1e40:      	fmov	w9, s23
    1e44:      	and	w9, w9, #0xff
    1e48:      	str	w9, [sp, #0x3e0]
    1e4c:      	ubfiz	w9, w24, #2, #27
    1e50:      	orr	w9, w9, w19
    1e54:      	dup.4s	v2, w9
    1e58:      	and.16b	v17, v1, v2
    1e5c:      	and.16b	v2, v0, v2
    1e60:      	ushll2.2d	v5, v2, #0x0
    1e64:      	ushll2.2d	v6, v17, #0x0
    1e68:      	ushll.2d	v19, v2, #0x0
    1e6c:      	ushll.2d	v7, v17, #0x0
    1e70:      	fmov	x9, d7
    1e74:      	mov	w11, #0x104             ; =260
    1e78:      	umaddl	x9, w9, w11, x10
    1e7c:      	fmov	w11, s23
    1e80:      	add	x2, sp, #0xd80
    1e84:      	mov	w3, #0x4                ; =4
    1e88:      	b	0x1eac <_llm_rows.packet_batch.blocks+0x2c4>
    1e8c:      	add	x12, x28, x8
    1e90:      	ldp	q18, q20, [x12]
    1e94:      	bif.16b	v16, v20, v0
    1e98:      	bif.16b	v4, v18, v1
    1e9c:      	stp	q4, q16, [x12]
    1ea0:      	add	x8, x8, #0x20
    1ea4:      	cmp	x8, #0x100
    1ea8:      	b.eq	0x1f40 <_llm_rows.packet_batch.blocks+0x358>
    1eac:      	add	x13, x9, x8
    1eb0:      	movi.2d	v4, #0000000000000000
    1eb4:      	movi.2d	v16, #0000000000000000
    1eb8:      	tbnz	w11, #0x0, 0x1ee0 <_llm_rows.packet_batch.blocks+0x2f8>
    1ebc:      	and	w14, w11, #0xff
    1ec0:      	tbnz	w14, #0x1, 0x1eec <_llm_rows.packet_batch.blocks+0x304>
    1ec4:      	tbnz	w14, #0x2, 0x1ef8 <_llm_rows.packet_batch.blocks+0x310>
    1ec8:      	tbnz	w14, #0x3, 0x1f04 <_llm_rows.packet_batch.blocks+0x31c>
    1ecc:      	tbnz	w14, #0x4, 0x1f10 <_llm_rows.packet_batch.blocks+0x328>
    1ed0:      	tbnz	w14, #0x5, 0x1f1c <_llm_rows.packet_batch.blocks+0x334>
    1ed4:      	tbnz	w14, #0x6, 0x1f28 <_llm_rows.packet_batch.blocks+0x340>
    1ed8:      	tbz	w14, #0x7, 0x1e8c <_llm_rows.packet_batch.blocks+0x2a4>
    1edc:      	b	0x1f34 <_llm_rows.packet_batch.blocks+0x34c>
    1ee0:      	ldr	s4, [x13]
    1ee4:      	and	w14, w11, #0xff
    1ee8:      	tbz	w14, #0x1, 0x1ec4 <_llm_rows.packet_batch.blocks+0x2dc>
    1eec:      	add	x12, x13, #0x4
    1ef0:      	ld1.s	{ v4 }[1], [x12]
    1ef4:      	tbz	w14, #0x2, 0x1ec8 <_llm_rows.packet_batch.blocks+0x2e0>
    1ef8:      	add	x12, x13, #0x8
    1efc:      	ld1.s	{ v4 }[2], [x12]
    1f00:      	tbz	w14, #0x3, 0x1ecc <_llm_rows.packet_batch.blocks+0x2e4>
    1f04:      	add	x12, x13, #0xc
    1f08:      	ld1.s	{ v4 }[3], [x12]
    1f0c:      	tbz	w14, #0x4, 0x1ed0 <_llm_rows.packet_batch.blocks+0x2e8>
    1f10:      	add	x12, x13, #0x10
    1f14:      	ld1.s	{ v16 }[0], [x12]
    1f18:      	tbz	w14, #0x5, 0x1ed4 <_llm_rows.packet_batch.blocks+0x2ec>
    1f1c:      	add	x12, x13, #0x14
    1f20:      	ld1.s	{ v16 }[1], [x12]
    1f24:      	tbz	w14, #0x6, 0x1ed8 <_llm_rows.packet_batch.blocks+0x2f0>
    1f28:      	add	x12, x13, #0x18
    1f2c:      	ld1.s	{ v16 }[2], [x12]
    1f30:      	tbz	w14, #0x7, 0x1e8c <_llm_rows.packet_batch.blocks+0x2a4>
    1f34:      	add	x12, x13, #0x1c
    1f38:      	ld1.s	{ v16 }[3], [x12]
    1f3c:      	b	0x1e8c <_llm_rows.packet_batch.blocks+0x2a4>
    1f40:      	xtn.4h	v4, v1
    1f44:      	uzp1.8b	v21, v4, v0
    1f48:      	sshll.2d	v4, v1, #0x0
    1f4c:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1f50:      	ldr	q20, [x8]
    1f54:      	and.16b	v24, v4, v20
    1f58:      	movi.2d	v22, #0000000000000000
    1f5c:      	mov.b	v22[0], v21[0]
    1f60:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1f64:      	ldr	d16, [x8]
    1f68:      	and.8b	v18, v22, v16
    1f6c:      	addv.8b	b18, v18
    1f70:      	fmov	w8, s18
    1f74:      	str	q22, [sp, #0x1d0]
    1f78:      	umaxv.8b	b18, v22
    1f7c:      	fmov	w9, s18
    1f80:      	rbit	w11, w8
    1f84:      	clz	w11, w11
    1f88:      	tst	w9, #0x1
    1f8c:      	csel	w4, w11, wzr, ne
    1f90:      	mov	w11, #0x40              ; =64
    1f94:      	dup.2d	v22, x11
    1f98:      	str	q24, [sp, #0x3c0]
    1f9c:      	orr.16b	v18, v24, v22
    1fa0:      	xtn.2s	v24, v7
    1fa4:      	mov.16b	v25, v18
    1fa8:      	umlal.2d	v25, v24, v8
    1fac:      	movi.2d	v7, #0000000000000000
    1fb0:      	mov.b	v7[0], v21[0]
    1fb4:      	ushll.2d	v7, v7, #0x0
    1fb8:      	shl.2d	v7, v7, #0x3f
    1fbc:      	cmlt.2d	v7, v7, #0
    1fc0:      	str	q25, [sp, #0x160]
    1fc4:      	and.16b	v7, v7, v25
    1fc8:      	movi.2d	v21, #0000000000000000
    1fcc:      	str	q21, [sp, #0xae0]
    1fd0:      	str	q21, [sp, #0xad0]
    1fd4:      	str	q21, [sp, #0xac0]
    1fd8:      	str	q7, [sp, #0xab0]
    1fdc:      	and	x11, x4, #0x7
    1fe0:      	add	x12, sp, #0xab0
    1fe4:      	ldr	x11, [x12, x11, lsl #3]
    1fe8:      	sub	x11, x11, x4
    1fec:      	add	x10, x10, x11, lsl #2
    1ff0:      	movi.2d	v27, #0000000000000000
    1ff4:      	movi.2d	v13, #0000000000000000
    1ff8:      	tbnz	w9, #0x0, 0x2688 <_llm_rows.packet_batch.blocks+0xaa0>
    1ffc:      	tbnz	w8, #0x1, 0x2690 <_llm_rows.packet_batch.blocks+0xaa8>
    2000:      	tbnz	w8, #0x2, 0x269c <_llm_rows.packet_batch.blocks+0xab4>
    2004:      	tbnz	w8, #0x3, 0x26a8 <_llm_rows.packet_batch.blocks+0xac0>
    2008:      	tbnz	w8, #0x4, 0x26b4 <_llm_rows.packet_batch.blocks+0xacc>
    200c:      	tbnz	w8, #0x5, 0x26c0 <_llm_rows.packet_batch.blocks+0xad8>
    2010:      	tbnz	w8, #0x6, 0x26cc <_llm_rows.packet_batch.blocks+0xae4>
    2014:      	str	q23, [sp, #0x360]
    2018:      	tbz	w8, #0x7, 0x2024 <_llm_rows.packet_batch.blocks+0x43c>
    201c:      	add	x9, x10, #0x1c
    2020:      	ld1.s	{ v13 }[3], [x9]
    2024:      	str	x15, [sp, #0x180]
    2028:      	mov	x10, #0x0               ; =0
    202c:      	sshll.2d	v7, v0, #0x0
    2030:      	sshll2.2d	v28, v1, #0x0
    2034:      	sshll2.2d	v15, v0, #0x0
    2038:      	adrp	x9, 0x2000 <_llm_rows.packet_batch.blocks+0x418>
    203c:      	ldr	q21, [x9]
    2040:      	and.16b	v21, v15, v21
    2044:      	adrp	x9, 0x2000 <_llm_rows.packet_batch.blocks+0x418>
    2048:      	ldr	q23, [x9]
    204c:      	and.16b	v23, v28, v23
    2050:      	adrp	x9, 0x2000 <_llm_rows.packet_batch.blocks+0x418>
    2054:      	ldr	q25, [x9]
    2058:      	and.16b	v25, v7, v25
    205c:      	adrp	x9, 0x2000 <_llm_rows.packet_batch.blocks+0x418>
    2060:      	ldr	q26, [x9]
    2064:      	and.16b	v4, v4, v26
    2068:      	str	q4, [sp, #0xa70]
    206c:      	str	q23, [sp, #0xa80]
    2070:      	str	q25, [sp, #0xa90]
    2074:      	str	q21, [sp, #0xaa0]
    2078:      	and	x9, x4, #0x7
    207c:      	add	x11, sp, #0xa70
    2080:      	ldr	x9, [x11, x9, lsl #3]
    2084:      	orr	x9, x9, #0x100
    2088:      	sub	x9, x9, x4, lsl #2
    208c:      	tst	w8, #0xff
    2090:      	csel	x5, xzr, x9, eq
    2094:      	add	x9, x28, x5
    2098:      	ldp	q21, q23, [x9]
    209c:      	ldr	q26, [sp, #0x1d0]
    20a0:      	zip2.8b	v25, v26, v0
    20a4:      	ushll.4s	v25, v25, #0x0
    20a8:      	shl.4s	v25, v25, #0x1f
    20ac:      	cmlt.4s	v25, v25, #0
    20b0:      	bit.16b	v23, v13, v25
    20b4:      	zip1.8b	v25, v26, v0
    20b8:      	ushll.4s	v25, v25, #0x0
    20bc:      	shl.4s	v25, v25, #0x1f
    20c0:      	cmlt.4s	v25, v25, #0
    20c4:      	str	q27, [sp, #0x3b0]
    20c8:      	bit.16b	v21, v27, v25
    20cc:      	stp	q21, q23, [x9]
    20d0:      	adrp	x9, 0x2000 <_llm_rows.packet_batch.blocks+0x418>
    20d4:      	ldr	q25, [x9]
    20d8:      	and.16b	v29, v15, v25
    20dc:      	adrp	x9, 0x2000 <_llm_rows.packet_batch.blocks+0x418>
    20e0:      	ldr	q26, [x9]
    20e4:      	and.16b	v23, v28, v26
    20e8:      	adrp	x9, 0x2000 <_llm_rows.packet_batch.blocks+0x418>
    20ec:      	ldr	q27, [x9]
    20f0:      	and.16b	v7, v7, v27
    20f4:      	stp	q7, q23, [sp, #0x380]
    20f8:      	orr.16b	v21, v7, v22
    20fc:      	orr.16b	v23, v23, v22
    2100:      	str	q29, [sp, #0x3a0]
    2104:      	orr.16b	v22, v29, v22
    2108:      	umull.2d	v7, v24, v8
    210c:      	str	q7, [sp, #0x120]
    2110:      	xtn.2s	v6, v6
    2114:      	xtn.2s	v19, v19
    2118:      	xtn.2s	v5, v5
    211c:      	mov.16b	v7, v22
    2120:      	umlal.2d	v7, v5, v8
    2124:      	str	q7, [sp, #0x150]
    2128:      	mov.16b	v7, v28
    212c:      	mov.16b	v5, v23
    2130:      	umlal.2d	v5, v6, v8
    2134:      	str	q5, [sp, #0x140]
    2138:      	mov.16b	v5, v21
    213c:      	umlal.2d	v5, v19, v8
    2140:      	str	q5, [sp, #0x130]
    2144:      	mov	w9, #0x1                ; =1
    2148:      	dup.2d	v5, x9
    214c:      	ushll2.2d	v6, v0, #0x0
    2150:      	and.16b	v30, v6, v5
    2154:      	ushll2.2d	v6, v1, #0x0
    2158:      	and.16b	v8, v6, v5
    215c:      	ushll.2d	v6, v0, #0x0
    2160:      	and.16b	v9, v6, v5
    2164:      	ushll.2d	v6, v1, #0x0
    2168:      	and.16b	v10, v6, v5
    216c:      	movi.2d	v5, #0000000000000000
    2170:      	movi.2d	v6, #0000000000000000
    2174:      	movi.2d	v19, #0000000000000000
    2178:      	movi.2d	v24, #0000000000000000
    217c:      	stp	q8, q30, [sp, #0x200]
    2180:      	stp	q10, q9, [sp, #0x1e0]
    2184:      	str	q15, [sp, #0x350]
    2188:      	sshll.2d	v28, v0, #0x0
    218c:      	sshll.2d	v29, v1, #0x0
    2190:      	shl.2d	v30, v24, #0x3
    2194:      	shl.2d	v31, v5, #0x3
    2198:      	shl.2d	v8, v19, #0x3
    219c:      	shl.2d	v9, v6, #0x3
    21a0:      	orr.16b	v9, v9, v26
    21a4:      	orr.16b	v8, v8, v27
    21a8:      	orr.16b	v31, v31, v20
    21ac:      	orr.16b	v30, v30, v25
    21b0:      	add	x9, x2, x10, lsl #6
    21b4:      	ldp	q11, q10, [x9]
    21b8:      	ldp	q14, q15, [x9, #0x20]
    21bc:      	ldr	q12, [sp, #0x350]
    21c0:      	bif.16b	v30, v15, v12
    21c4:      	ldr	q15, [sp, #0x350]
    21c8:      	bsl.16b	v29, v31, v11
    21cc:      	bsl.16b	v28, v8, v14
    21d0:      	mov.16b	v31, v7
    21d4:      	bsl.16b	v31, v9, v10
    21d8:      	ldp	q10, q9, [sp, #0x1e0]
    21dc:      	stp	q29, q31, [x9]
    21e0:      	stp	q28, q30, [x9, #0x20]
    21e4:      	ldp	q8, q30, [sp, #0x200]
    21e8:      	add.2d	v6, v6, v8
    21ec:      	add.2d	v19, v19, v9
    21f0:      	add.2d	v24, v24, v30
    21f4:      	add.2d	v5, v5, v10
    21f8:      	fmov	x10, d5
    21fc:      	cmp	x10, #0x8
    2200:      	b.lt	0x2188 <_llm_rows.packet_batch.blocks+0x5a0>
    2204:      	mov	x10, #0x0               ; =0
    2208:      	mov.16b	v27, v7
    220c:      	movi.4s	v7, #0x41
    2210:      	and.16b	v5, v1, v7
    2214:      	mvn.16b	v6, v1
    2218:      	sub.4s	v5, v5, v6
    221c:      	and.16b	v6, v0, v7
    2220:      	mvn.16b	v19, v0
    2224:      	sub.4s	v6, v6, v19
    2228:      	mov.s	w9, v6[1]
    222c:      	mov.s	w11, v2[1]
    2230:      	udiv	w12, w11, w9
    2234:      	msub	w11, w12, w9, w11
    2238:      	mov.s	w9, v6[2]
    223c:      	mov.s	w12, v6[3]
    2240:      	fmov	w13, s6
    2244:      	fmov	w14, s2
    2248:      	udiv	w15, w14, w13
    224c:      	msub	w13, w15, w13, w14
    2250:      	mov.s	w14, v2[2]
    2254:      	udiv	w15, w14, w9
    2258:      	msub	w14, w15, w9, w14
    225c:      	mov.s	w9, v2[3]
    2260:      	udiv	w15, w9, w12
    2264:      	msub	w12, w15, w12, w9
    2268:      	mov.s	w9, v5[1]
    226c:      	mov.s	w15, v17[1]
    2270:      	udiv	w16, w15, w9
    2274:      	msub	w15, w16, w9, w15
    2278:      	mov.s	w9, v5[2]
    227c:      	mov.s	w16, v5[3]
    2280:      	fmov	w17, s5
    2284:      	fmov	w0, s17
    2288:      	udiv	w1, w0, w17
    228c:      	msub	w17, w1, w17, w0
    2290:      	mov.s	w0, v17[2]
    2294:      	udiv	w1, w0, w9
    2298:      	msub	w9, w1, w9, w0
    229c:      	mov.s	w0, v17[3]
    22a0:      	udiv	w1, w0, w16
    22a4:      	msub	w16, w1, w16, w0
    22a8:      	tst	w8, #0xff
    22ac:      	fmov	s19, w13
    22b0:      	mov.s	v19[1], w11
    22b4:      	mov.s	v19[2], w14
    22b8:      	mov.s	v19[3], w12
    22bc:      	fmov	s20, w17
    22c0:      	sshll.2d	v25, v0, #0x0
    22c4:      	sshll.2d	v24, v1, #0x0
    22c8:      	adrp	x8, 0x2000 <_llm_rows.packet_batch.blocks+0x418>
    22cc:      	ldr	q2, [x8]
    22d0:      	and.16b	v2, v24, v2
    22d4:      	adrp	x8, 0x2000 <_llm_rows.packet_batch.blocks+0x418>
    22d8:      	ldr	q5, [x8]
    22dc:      	and.16b	v5, v25, v5
    22e0:      	adrp	x8, 0x2000 <_llm_rows.packet_batch.blocks+0x418>
    22e4:      	ldr	q6, [x8]
    22e8:      	and.16b	v6, v27, v6
    22ec:      	adrp	x8, 0x2000 <_llm_rows.packet_batch.blocks+0x418>
    22f0:      	ldr	q17, [x8]
    22f4:      	and.16b	v17, v15, v17
    22f8:      	str	q17, [sp, #0xa60]
    22fc:      	str	q5, [sp, #0xa50]
    2300:      	str	q6, [sp, #0xa40]
    2304:      	str	q2, [sp, #0xa30]
    2308:      	mov.s	v20[1], w15
    230c:      	and	x8, x4, #0x7
    2310:      	add	x11, sp, #0xa30
    2314:      	ldr	x8, [x11, x8, lsl #3]
    2318:      	orr	x8, x8, #0x200
    231c:      	sub	x8, x8, x4, lsl #3
    2320:      	csel	x8, xzr, x8, eq
    2324:      	add	x8, x2, x8
    2328:      	ldp	q17, q6, [x8, #0x20]
    232c:      	ldr	q7, [sp, #0x1d0]
    2330:      	mov	b2, v7[2]
    2334:      	mov.b	v2[4], v7[3]
    2338:      	ldp	q5, q26, [x8]
    233c:      	ushll.2d	v2, v2, #0x0
    2340:      	shl.2d	v2, v2, #0x3f
    2344:      	cmlt.2d	v2, v2, #0
    2348:      	bsl.16b	v2, v23, v26
    234c:      	mov	b23, v7[0]
    2350:      	mov.b	v23[4], v7[1]
    2354:      	ushll.2d	v23, v23, #0x0
    2358:      	shl.2d	v23, v23, #0x3f
    235c:      	cmlt.2d	v23, v23, #0
    2360:      	bit.16b	v5, v18, v23
    2364:      	mov	b18, v7[6]
    2368:      	mov.b	v18[4], v7[7]
    236c:      	ushll.2d	v18, v18, #0x0
    2370:      	shl.2d	v18, v18, #0x3f
    2374:      	cmlt.2d	v18, v18, #0
    2378:      	bit.16b	v6, v22, v18
    237c:      	mov	b18, v7[4]
    2380:      	mov.b	v18[4], v7[5]
    2384:      	ushll.2d	v18, v18, #0x0
    2388:      	shl.2d	v18, v18, #0x3f
    238c:      	cmlt.2d	v18, v18, #0
    2390:      	bit.16b	v17, v21, v18
    2394:      	mov.s	v20[2], w9
    2398:      	mov.s	v20[3], w16
    239c:      	and.16b	v21, v1, v20
    23a0:      	stp	q17, q6, [x8, #0x20]
    23a4:      	stp	q5, q2, [x8]
    23a8:      	and.16b	v20, v0, v19
    23ac:      	ushll2.2d	v18, v20, #0x0
    23b0:      	ushll2.2d	v19, v21, #0x0
    23b4:      	ushll.2d	v20, v20, #0x0
    23b8:      	ushll.2d	v21, v21, #0x0
    23bc:      	ldr	q7, [sp, #0x30]
    23c0:      	and.16b	v12, v15, v7
    23c4:      	and.16b	v22, v27, v7
    23c8:      	str	q22, [sp, #0x450]
    23cc:      	and.16b	v22, v25, v7
    23d0:      	str	q22, [sp, #0x440]
    23d4:      	and.16b	v7, v24, v7
    23d8:      	str	q7, [sp, #0x430]
    23dc:      	adrp	x8, 0x2000 <_llm_rows.packet_batch.blocks+0x418>
    23e0:      	ldr	q22, [x8]
    23e4:      	and.16b	v7, v15, v22
    23e8:      	str	q7, [sp, #0x340]
    23ec:      	adrp	x8, 0x2000 <_llm_rows.packet_batch.blocks+0x418>
    23f0:      	ldr	q22, [x8]
    23f4:      	str	q27, [sp, #0x300]
    23f8:      	and.16b	v7, v27, v22
    23fc:      	str	q7, [sp, #0x330]
    2400:      	adrp	x8, 0x2000 <_llm_rows.packet_batch.blocks+0x418>
    2404:      	ldr	q22, [x8]
    2408:      	and.16b	v7, v25, v22
    240c:      	str	q7, [sp, #0x320]
    2410:      	adrp	x8, 0x2000 <_llm_rows.packet_batch.blocks+0x418>
    2414:      	ldr	q22, [x8]
    2418:      	and.16b	v7, v24, v22
    241c:      	str	q7, [sp, #0x310]
    2420:      	ldr	q7, [sp, #0x190]
    2424:      	cmhs.4s	v22, v7, v3
    2428:      	ldr	q7, [sp, #0x1a0]
    242c:      	cmhs.4s	v3, v7, v3
    2430:      	uzp1.8h	v3, v3, v22
    2434:      	xtn.8b	v3, v3
    2438:      	movi.2d	v22, #0000000000000000
    243c:      	movi.2d	v23, #0000000000000000
    2440:      	movi.2d	v24, #0000000000000000
    2444:      	movi.2d	v25, #0000000000000000
    2448:      	movi.8b	v7, #0x1
    244c:      	ldr	q11, [sp, #0x360]
    2450:      	b	0x2470 <_llm_rows.packet_batch.blocks+0x888>
    2454:      	add.2d	v23, v23, v8
    2458:      	add.2d	v24, v24, v9
    245c:      	add.2d	v25, v25, v30
    2460:      	add.2d	v22, v22, v10
    2464:      	fmov	x10, d22
    2468:      	cmp	x10, #0x8
    246c:      	b.ge	0x259c <_llm_rows.packet_batch.blocks+0x9b4>
    2470:      	fmov	w8, s11
    2474:      	add	x9, x2, x10, lsl #6
    2478:      	ldp	q27, q26, [x9, #0x20]
    247c:      	ldp	q28, q29, [x9]
    2480:      	cmge.2d	v29, v19, v29
    2484:      	cmge.2d	v28, v21, v28
    2488:      	uzp1.4s	v28, v28, v29
    248c:      	cmge.2d	v27, v20, v27
    2490:      	cmge.2d	v26, v18, v26
    2494:      	uzp1.4s	v26, v27, v26
    2498:      	uzp1.8h	v26, v28, v26
    249c:      	xtn.8b	v26, v26
    24a0:      	orr.8b	v26, v3, v26
    24a4:      	ldr	q27, [sp, #0x310]
    24a8:      	add.2d	v27, v22, v27
    24ac:      	ldr	q28, [sp, #0x430]
    24b0:      	add.2d	v27, v28, v27
    24b4:      	and.8b	v26, v26, v7
    24b8:      	tbnz	w8, #0x0, 0x250c <_llm_rows.packet_batch.blocks+0x924>
    24bc:      	and	w8, w8, #0xff
    24c0:      	tbnz	w8, #0x1, 0x251c <_llm_rows.packet_batch.blocks+0x934>
    24c4:      	ldr	q27, [sp, #0x330]
    24c8:      	add.2d	v27, v23, v27
    24cc:      	ldr	q28, [sp, #0x450]
    24d0:      	add.2d	v27, v28, v27
    24d4:      	tbnz	w8, #0x2, 0x2538 <_llm_rows.packet_batch.blocks+0x950>
    24d8:      	tbnz	w8, #0x3, 0x2544 <_llm_rows.packet_batch.blocks+0x95c>
    24dc:      	ldr	q27, [sp, #0x320]
    24e0:      	add.2d	v27, v24, v27
    24e4:      	ldr	q28, [sp, #0x440]
    24e8:      	add.2d	v27, v28, v27
    24ec:      	tbnz	w8, #0x4, 0x2560 <_llm_rows.packet_batch.blocks+0x978>
    24f0:      	tbnz	w8, #0x5, 0x256c <_llm_rows.packet_batch.blocks+0x984>
    24f4:      	ldr	q27, [sp, #0x340]
    24f8:      	add.2d	v27, v25, v27
    24fc:      	add.2d	v27, v12, v27
    2500:      	tbnz	w8, #0x6, 0x2584 <_llm_rows.packet_batch.blocks+0x99c>
    2504:      	tbz	w8, #0x7, 0x2454 <_llm_rows.packet_batch.blocks+0x86c>
    2508:      	b	0x2590 <_llm_rows.packet_batch.blocks+0x9a8>
    250c:      	fmov	x9, d27
    2510:      	str	b26, [x9]
    2514:      	and	w8, w8, #0xff
    2518:      	tbz	w8, #0x1, 0x24c4 <_llm_rows.packet_batch.blocks+0x8dc>
    251c:      	mov.d	x9, v27[1]
    2520:      	st1.b	{ v26 }[1], [x9]
    2524:      	ldr	q27, [sp, #0x330]
    2528:      	add.2d	v27, v23, v27
    252c:      	ldr	q28, [sp, #0x450]
    2530:      	add.2d	v27, v28, v27
    2534:      	tbz	w8, #0x2, 0x24d8 <_llm_rows.packet_batch.blocks+0x8f0>
    2538:      	fmov	x9, d27
    253c:      	st1.b	{ v26 }[2], [x9]
    2540:      	tbz	w8, #0x3, 0x24dc <_llm_rows.packet_batch.blocks+0x8f4>
    2544:      	mov.d	x9, v27[1]
    2548:      	st1.b	{ v26 }[3], [x9]
    254c:      	ldr	q27, [sp, #0x320]
    2550:      	add.2d	v27, v24, v27
    2554:      	ldr	q28, [sp, #0x440]
    2558:      	add.2d	v27, v28, v27
    255c:      	tbz	w8, #0x4, 0x24f0 <_llm_rows.packet_batch.blocks+0x908>
    2560:      	fmov	x9, d27
    2564:      	st1.b	{ v26 }[4], [x9]
    2568:      	tbz	w8, #0x5, 0x24f4 <_llm_rows.packet_batch.blocks+0x90c>
    256c:      	mov.d	x9, v27[1]
    2570:      	st1.b	{ v26 }[5], [x9]
    2574:      	ldr	q27, [sp, #0x340]
    2578:      	add.2d	v27, v25, v27
    257c:      	add.2d	v27, v12, v27
    2580:      	tbz	w8, #0x6, 0x2504 <_llm_rows.packet_batch.blocks+0x91c>
    2584:      	fmov	x9, d27
    2588:      	st1.b	{ v26 }[6], [x9]
    258c:      	tbz	w8, #0x7, 0x2454 <_llm_rows.packet_batch.blocks+0x86c>
    2590:      	mov.d	x8, v27[1]
    2594:      	st1.b	{ v26 }[7], [x8]
    2598:      	b	0x2454 <_llm_rows.packet_batch.blocks+0x86c>
    259c:      	cmge.2d	v3, v21, v5
    25a0:      	cmge.2d	v2, v19, v2
    25a4:      	uzp1.4s	v2, v3, v2
    25a8:      	cmge.2d	v3, v20, v17
    25ac:      	cmge.2d	v5, v18, v6
    25b0:      	uzp1.4s	v3, v3, v5
    25b4:      	uzp1.8h	v2, v2, v3
    25b8:      	xtn.8b	v2, v2
    25bc:      	ldr	q5, [sp, #0x1d0]
    25c0:      	shl.8b	v3, v5, #0x7
    25c4:      	cmlt.8b	v3, v3, #0
    25c8:      	and.8b	v3, v3, v16
    25cc:      	addv.8b	b3, v3
    25d0:      	str	d3, [sp, #0x1b0]
    25d4:      	fmov	w9, s3
    25d8:      	orn.8b	v2, v2, v5
    25dc:      	ldr	q3, [sp, #0x430]
    25e0:      	ldr	q5, [sp, #0x310]
    25e4:      	add.2d	v5, v5, v3
    25e8:      	mov	w8, #0x8                ; =8
    25ec:      	dup.2d	v3, x8
    25f0:      	add.2d	v20, v5, v3
    25f4:      	and.8b	v2, v2, v7
    25f8:      	tbnz	w9, #0x0, 0x26e0 <_llm_rows.packet_batch.blocks+0xaf8>
    25fc:      	mov.d	x14, v20[1]
    2600:      	ldr	q7, [sp, #0x300]
    2604:      	tbnz	w9, #0x1, 0x26f4 <_llm_rows.packet_batch.blocks+0xb0c>
    2608:      	ldr	q5, [sp, #0x450]
    260c:      	ldr	q6, [sp, #0x330]
    2610:      	add.2d	v5, v6, v5
    2614:      	add.2d	v18, v5, v3
    2618:      	tbnz	w9, #0x2, 0x270c <_llm_rows.packet_batch.blocks+0xb24>
    261c:      	mov.d	x13, v18[1]
    2620:      	tbnz	w9, #0x3, 0x271c <_llm_rows.packet_batch.blocks+0xb34>
    2624:      	ldr	q5, [sp, #0x440]
    2628:      	ldr	q6, [sp, #0x320]
    262c:      	add.2d	v5, v6, v5
    2630:      	add.2d	v5, v5, v3
    2634:      	tbnz	w9, #0x4, 0x2734 <_llm_rows.packet_batch.blocks+0xb4c>
    2638:      	str	q5, [sp, #0xe0]
    263c:      	mov.d	x11, v5[1]
    2640:      	tbnz	w9, #0x5, 0x2748 <_llm_rows.packet_batch.blocks+0xb60>
    2644:      	ldr	q5, [sp, #0x340]
    2648:      	add.2d	v5, v5, v12
    264c:      	add.2d	v5, v5, v3
    2650:      	tbnz	w9, #0x6, 0x275c <_llm_rows.packet_batch.blocks+0xb74>
    2654:      	mov.d	x8, v5[1]
    2658:      	tbnz	w9, #0x7, 0x276c <_llm_rows.packet_batch.blocks+0xb84>
    265c:      	fmov	w9, s11
    2660:      	ldr	q2, [sp, #0x430]
    2664:      	ldr	q3, [sp, #0x310]
    2668:      	add.2d	v3, v2, v3
    266c:      	tbz	w9, #0x0, 0x2784 <_llm_rows.packet_batch.blocks+0xb9c>
    2670:      	fmov	x10, d3
    2674:      	ldr	b2, [x10]
    2678:      	and	w10, w9, #0xff
    267c:      	str	q5, [sp, #0xf0]
    2680:      	tbnz	w10, #0x1, 0x2794 <_llm_rows.packet_batch.blocks+0xbac>
    2684:      	b	0x279c <_llm_rows.packet_batch.blocks+0xbb4>
    2688:      	ldr	s27, [x10]
    268c:      	tbz	w8, #0x1, 0x2000 <_llm_rows.packet_batch.blocks+0x418>
    2690:      	add	x9, x10, #0x4
    2694:      	ld1.s	{ v27 }[1], [x9]
    2698:      	tbz	w8, #0x2, 0x2004 <_llm_rows.packet_batch.blocks+0x41c>
    269c:      	add	x9, x10, #0x8
    26a0:      	ld1.s	{ v27 }[2], [x9]
    26a4:      	tbz	w8, #0x3, 0x2008 <_llm_rows.packet_batch.blocks+0x420>
    26a8:      	add	x9, x10, #0xc
    26ac:      	ld1.s	{ v27 }[3], [x9]
    26b0:      	tbz	w8, #0x4, 0x200c <_llm_rows.packet_batch.blocks+0x424>
    26b4:      	add	x9, x10, #0x10
    26b8:      	ld1.s	{ v13 }[0], [x9]
    26bc:      	tbz	w8, #0x5, 0x2010 <_llm_rows.packet_batch.blocks+0x428>
    26c0:      	add	x9, x10, #0x14
    26c4:      	ld1.s	{ v13 }[1], [x9]
    26c8:      	tbz	w8, #0x6, 0x2014 <_llm_rows.packet_batch.blocks+0x42c>
    26cc:      	add	x9, x10, #0x18
    26d0:      	ld1.s	{ v13 }[2], [x9]
    26d4:      	str	q23, [sp, #0x360]
    26d8:      	tbnz	w8, #0x7, 0x201c <_llm_rows.packet_batch.blocks+0x434>
    26dc:      	b	0x2024 <_llm_rows.packet_batch.blocks+0x43c>
    26e0:      	fmov	x8, d20
    26e4:      	str	b2, [x8]
    26e8:      	mov.d	x14, v20[1]
    26ec:      	ldr	q7, [sp, #0x300]
    26f0:      	tbz	w9, #0x1, 0x2608 <_llm_rows.packet_batch.blocks+0xa20>
    26f4:      	st1.b	{ v2 }[1], [x14]
    26f8:      	ldr	q5, [sp, #0x450]
    26fc:      	ldr	q6, [sp, #0x330]
    2700:      	add.2d	v5, v6, v5
    2704:      	add.2d	v18, v5, v3
    2708:      	tbz	w9, #0x2, 0x261c <_llm_rows.packet_batch.blocks+0xa34>
    270c:      	fmov	x8, d18
    2710:      	st1.b	{ v2 }[2], [x8]
    2714:      	mov.d	x13, v18[1]
    2718:      	tbz	w9, #0x3, 0x2624 <_llm_rows.packet_batch.blocks+0xa3c>
    271c:      	st1.b	{ v2 }[3], [x13]
    2720:      	ldr	q5, [sp, #0x440]
    2724:      	ldr	q6, [sp, #0x320]
    2728:      	add.2d	v5, v6, v5
    272c:      	add.2d	v5, v5, v3
    2730:      	tbz	w9, #0x4, 0x2638 <_llm_rows.packet_batch.blocks+0xa50>
    2734:      	fmov	x8, d5
    2738:      	st1.b	{ v2 }[4], [x8]
    273c:      	str	q5, [sp, #0xe0]
    2740:      	mov.d	x11, v5[1]
    2744:      	tbz	w9, #0x5, 0x2644 <_llm_rows.packet_batch.blocks+0xa5c>
    2748:      	st1.b	{ v2 }[5], [x11]
    274c:      	ldr	q5, [sp, #0x340]
    2750:      	add.2d	v5, v5, v12
    2754:      	add.2d	v5, v5, v3
    2758:      	tbz	w9, #0x6, 0x2654 <_llm_rows.packet_batch.blocks+0xa6c>
    275c:      	fmov	x8, d5
    2760:      	st1.b	{ v2 }[6], [x8]
    2764:      	mov.d	x8, v5[1]
    2768:      	tbz	w9, #0x7, 0x265c <_llm_rows.packet_batch.blocks+0xa74>
    276c:      	st1.b	{ v2 }[7], [x8]
    2770:      	fmov	w9, s11
    2774:      	ldr	q2, [sp, #0x430]
    2778:      	ldr	q3, [sp, #0x310]
    277c:      	add.2d	v3, v2, v3
    2780:      	tbnz	w9, #0x0, 0x2670 <_llm_rows.packet_batch.blocks+0xa88>
    2784:      	movi.2d	v2, #0000000000000000
    2788:      	and	w10, w9, #0xff
    278c:      	str	q5, [sp, #0xf0]
    2790:      	tbz	w10, #0x1, 0x279c <_llm_rows.packet_batch.blocks+0xbb4>
    2794:      	mov.d	x9, v3[1]
    2798:      	ld1.b	{ v2 }[1], [x9]
    279c:      	ldr	q3, [sp, #0x450]
    27a0:      	ldr	q5, [sp, #0x330]
    27a4:      	add.2d	v3, v3, v5
    27a8:      	tbnz	w10, #0x2, 0x2860 <_llm_rows.packet_batch.blocks+0xc78>
    27ac:      	tbnz	w10, #0x3, 0x286c <_llm_rows.packet_batch.blocks+0xc84>
    27b0:      	ldr	q3, [sp, #0x440]
    27b4:      	ldr	q5, [sp, #0x320]
    27b8:      	add.2d	v3, v3, v5
    27bc:      	tbnz	w10, #0x4, 0x2884 <_llm_rows.packet_batch.blocks+0xc9c>
    27c0:      	tbnz	w10, #0x5, 0x2890 <_llm_rows.packet_batch.blocks+0xca8>
    27c4:      	ldr	q3, [sp, #0x340]
    27c8:      	add.2d	v3, v12, v3
    27cc:      	tbnz	w10, #0x6, 0x28a4 <_llm_rows.packet_batch.blocks+0xcbc>
    27d0:      	tbz	w10, #0x7, 0x27dc <_llm_rows.packet_batch.blocks+0xbf4>
    27d4:      	mov.d	x9, v3[1]
    27d8:      	ld1.b	{ v2 }[7], [x9]
    27dc:      	fmov	w9, s11
    27e0:      	cmeq.8b	v2, v2, #0
    27e4:      	sshll.8h	v2, v2, #0x0
    27e8:      	sshll2.4s	v6, v2, #0x0
    27ec:      	stp	q2, q6, [sp, #0x40]
    27f0:      	sshll.4s	v2, v2, #0x0
    27f4:      	fmov	x10, d4
    27f8:      	str	x10, [sp, #0x2f0]
    27fc:      	add	x10, x28, x10
    2800:      	ldp	q3, q4, [x10]
    2804:      	and.16b	v5, v0, v4
    2808:      	and.16b	v3, v1, v3
    280c:      	mov	w10, #0xf2ca            ; =62154
    2810:      	movk	w10, #0xf149, lsl #16
    2814:      	dup.4s	v4, w10
    2818:      	mov.16b	v8, v2
    281c:      	bsl.16b	v8, v4, v3
    2820:      	mov.16b	v30, v6
    2824:      	bsl.16b	v30, v4, v5
    2828:      	stp	q8, q30, [x23, #0x120]
    282c:      	mov	w10, #0x1               ; =1
    2830:      	dup.2d	v3, x10
    2834:      	ldr	q2, [sp, #0x310]
    2838:      	add.2d	v5, v2, v3
    283c:      	ldr	q2, [sp, #0x430]
    2840:      	str	q5, [sp, #0x2d0]
    2844:      	add.2d	v5, v2, v5
    2848:      	tbz	w9, #0x0, 0x28b4 <_llm_rows.packet_batch.blocks+0xccc>
    284c:      	fmov	x10, d5
    2850:      	ldr	b2, [x10]
    2854:      	and	w10, w9, #0xff
    2858:      	tbnz	w10, #0x1, 0x28c0 <_llm_rows.packet_batch.blocks+0xcd8>
    285c:      	b	0x28c8 <_llm_rows.packet_batch.blocks+0xce0>
    2860:      	fmov	x9, d3
    2864:      	ld1.b	{ v2 }[2], [x9]
    2868:      	tbz	w10, #0x3, 0x27b0 <_llm_rows.packet_batch.blocks+0xbc8>
    286c:      	mov.d	x9, v3[1]
    2870:      	ld1.b	{ v2 }[3], [x9]
    2874:      	ldr	q3, [sp, #0x440]
    2878:      	ldr	q5, [sp, #0x320]
    287c:      	add.2d	v3, v3, v5
    2880:      	tbz	w10, #0x4, 0x27c0 <_llm_rows.packet_batch.blocks+0xbd8>
    2884:      	fmov	x9, d3
    2888:      	ld1.b	{ v2 }[4], [x9]
    288c:      	tbz	w10, #0x5, 0x27c4 <_llm_rows.packet_batch.blocks+0xbdc>
    2890:      	mov.d	x9, v3[1]
    2894:      	ld1.b	{ v2 }[5], [x9]
    2898:      	ldr	q3, [sp, #0x340]
    289c:      	add.2d	v3, v12, v3
    28a0:      	tbz	w10, #0x6, 0x27d0 <_llm_rows.packet_batch.blocks+0xbe8>
    28a4:      	fmov	x9, d3
    28a8:      	ld1.b	{ v2 }[6], [x9]
    28ac:      	tbnz	w10, #0x7, 0x27d4 <_llm_rows.packet_batch.blocks+0xbec>
    28b0:      	b	0x27dc <_llm_rows.packet_batch.blocks+0xbf4>
    28b4:      	movi.2d	v2, #0000000000000000
    28b8:      	and	w10, w9, #0xff
    28bc:      	tbz	w10, #0x1, 0x28c8 <_llm_rows.packet_batch.blocks+0xce0>
    28c0:      	mov.d	x9, v5[1]
    28c4:      	ld1.b	{ v2 }[1], [x9]
    28c8:      	ldr	q5, [sp, #0x330]
    28cc:      	add.2d	v6, v5, v3
    28d0:      	ldr	q5, [sp, #0x450]
    28d4:      	str	q6, [sp, #0x2c0]
    28d8:      	add.2d	v5, v5, v6
    28dc:      	tbnz	w10, #0x2, 0x2984 <_llm_rows.packet_batch.blocks+0xd9c>
    28e0:      	tbnz	w10, #0x3, 0x2990 <_llm_rows.packet_batch.blocks+0xda8>
    28e4:      	ldr	q5, [sp, #0x320]
    28e8:      	add.2d	v6, v5, v3
    28ec:      	ldr	q5, [sp, #0x440]
    28f0:      	str	q6, [sp, #0x2b0]
    28f4:      	add.2d	v5, v5, v6
    28f8:      	tbnz	w10, #0x4, 0x29b0 <_llm_rows.packet_batch.blocks+0xdc8>
    28fc:      	tbnz	w10, #0x5, 0x29bc <_llm_rows.packet_batch.blocks+0xdd4>
    2900:      	ldr	q5, [sp, #0x340]
    2904:      	add.2d	v3, v5, v3
    2908:      	str	q3, [sp, #0x2a0]
    290c:      	add.2d	v3, v12, v3
    2910:      	tbnz	w10, #0x6, 0x29d8 <_llm_rows.packet_batch.blocks+0xdf0>
    2914:      	tbz	w10, #0x7, 0x2920 <_llm_rows.packet_batch.blocks+0xd38>
    2918:      	mov.d	x9, v3[1]
    291c:      	ld1.b	{ v2 }[7], [x9]
    2920:      	fmov	w9, s11
    2924:      	cmeq.8b	v2, v2, #0
    2928:      	sshll.8h	v2, v2, #0x0
    292c:      	sshll2.4s	v3, v2, #0x0
    2930:      	sshll.4s	v2, v2, #0x0
    2934:      	ldr	q5, [sp, #0xfe0]
    2938:      	ldr	q6, [sp, #0xff0]
    293c:      	and.16b	v6, v0, v6
    2940:      	and.16b	v5, v1, v5
    2944:      	bit.16b	v5, v4, v2
    2948:      	bit.16b	v6, v4, v3
    294c:      	stp	q5, q6, [x23, #0x140]
    2950:      	mov	w10, #0x2               ; =2
    2954:      	dup.2d	v3, x10
    2958:      	ldr	q2, [sp, #0x310]
    295c:      	add.2d	v16, v2, v3
    2960:      	ldr	q2, [sp, #0x430]
    2964:      	str	q16, [sp, #0x290]
    2968:      	add.2d	v19, v2, v16
    296c:      	tbz	w9, #0x0, 0x29e8 <_llm_rows.packet_batch.blocks+0xe00>
    2970:      	fmov	x10, d19
    2974:      	ldr	b2, [x10]
    2978:      	and	w10, w9, #0xff
    297c:      	tbnz	w10, #0x1, 0x29f4 <_llm_rows.packet_batch.blocks+0xe0c>
    2980:      	b	0x29fc <_llm_rows.packet_batch.blocks+0xe14>
    2984:      	fmov	x9, d5
    2988:      	ld1.b	{ v2 }[2], [x9]
    298c:      	tbz	w10, #0x3, 0x28e4 <_llm_rows.packet_batch.blocks+0xcfc>
    2990:      	mov.d	x9, v5[1]
    2994:      	ld1.b	{ v2 }[3], [x9]
    2998:      	ldr	q5, [sp, #0x320]
    299c:      	add.2d	v6, v5, v3
    29a0:      	ldr	q5, [sp, #0x440]
    29a4:      	str	q6, [sp, #0x2b0]
    29a8:      	add.2d	v5, v5, v6
    29ac:      	tbz	w10, #0x4, 0x28fc <_llm_rows.packet_batch.blocks+0xd14>
    29b0:      	fmov	x9, d5
    29b4:      	ld1.b	{ v2 }[4], [x9]
    29b8:      	tbz	w10, #0x5, 0x2900 <_llm_rows.packet_batch.blocks+0xd18>
    29bc:      	mov.d	x9, v5[1]
    29c0:      	ld1.b	{ v2 }[5], [x9]
    29c4:      	ldr	q5, [sp, #0x340]
    29c8:      	add.2d	v3, v5, v3
    29cc:      	str	q3, [sp, #0x2a0]
    29d0:      	add.2d	v3, v12, v3
    29d4:      	tbz	w10, #0x6, 0x2914 <_llm_rows.packet_batch.blocks+0xd2c>
    29d8:      	fmov	x9, d3
    29dc:      	ld1.b	{ v2 }[6], [x9]
    29e0:      	tbnz	w10, #0x7, 0x2918 <_llm_rows.packet_batch.blocks+0xd30>
    29e4:      	b	0x2920 <_llm_rows.packet_batch.blocks+0xd38>
    29e8:      	movi.2d	v2, #0000000000000000
    29ec:      	and	w10, w9, #0xff
    29f0:      	tbz	w10, #0x1, 0x29fc <_llm_rows.packet_batch.blocks+0xe14>
    29f4:      	mov.d	x9, v19[1]
    29f8:      	ld1.b	{ v2 }[1], [x9]
    29fc:      	ldr	q16, [sp, #0x330]
    2a00:      	add.2d	v17, v16, v3
    2a04:      	ldr	q16, [sp, #0x450]
    2a08:      	str	q17, [sp, #0x280]
    2a0c:      	add.2d	v19, v16, v17
    2a10:      	tbnz	w10, #0x2, 0x2abc <_llm_rows.packet_batch.blocks+0xed4>
    2a14:      	tbnz	w10, #0x3, 0x2ac8 <_llm_rows.packet_batch.blocks+0xee0>
    2a18:      	ldr	q16, [sp, #0x320]
    2a1c:      	add.2d	v17, v16, v3
    2a20:      	ldr	q16, [sp, #0x440]
    2a24:      	str	q17, [sp, #0x270]
    2a28:      	add.2d	v19, v16, v17
    2a2c:      	tbnz	w10, #0x4, 0x2ae8 <_llm_rows.packet_batch.blocks+0xf00>
    2a30:      	tbnz	w10, #0x5, 0x2af4 <_llm_rows.packet_batch.blocks+0xf0c>
    2a34:      	ldr	q16, [sp, #0x340]
    2a38:      	add.2d	v3, v16, v3
    2a3c:      	str	q3, [sp, #0x260]
    2a40:      	add.2d	v3, v12, v3
    2a44:      	tbnz	w10, #0x6, 0x2b10 <_llm_rows.packet_batch.blocks+0xf28>
    2a48:      	tbz	w10, #0x7, 0x2a54 <_llm_rows.packet_batch.blocks+0xe6c>
    2a4c:      	mov.d	x9, v3[1]
    2a50:      	ld1.b	{ v2 }[7], [x9]
    2a54:      	fmov	w9, s11
    2a58:      	cmeq.8b	v2, v2, #0
    2a5c:      	sshll.8h	v2, v2, #0x0
    2a60:      	sshll2.4s	v3, v2, #0x0
    2a64:      	sshll.4s	v2, v2, #0x0
    2a68:      	ldr	q19, [sp, #0x1000]
    2a6c:      	ldr	q21, [sp, #0x1010]
    2a70:      	and.16b	v21, v0, v21
    2a74:      	and.16b	v19, v1, v19
    2a78:      	bsl.16b	v2, v4, v19
    2a7c:      	mov.16b	v22, v3
    2a80:      	bsl.16b	v22, v4, v21
    2a84:      	stp	q2, q22, [x23, #0x160]
    2a88:      	mov	w10, #0x3               ; =3
    2a8c:      	dup.2d	v19, x10
    2a90:      	ldr	q3, [sp, #0x310]
    2a94:      	add.2d	v16, v3, v19
    2a98:      	ldr	q3, [sp, #0x430]
    2a9c:      	str	q16, [sp, #0x250]
    2aa0:      	add.2d	v21, v3, v16
    2aa4:      	tbz	w9, #0x0, 0x2b20 <_llm_rows.packet_batch.blocks+0xf38>
    2aa8:      	fmov	x10, d21
    2aac:      	ldr	b3, [x10]
    2ab0:      	and	w10, w9, #0xff
    2ab4:      	tbnz	w10, #0x1, 0x2b2c <_llm_rows.packet_batch.blocks+0xf44>
    2ab8:      	b	0x2b34 <_llm_rows.packet_batch.blocks+0xf4c>
    2abc:      	fmov	x9, d19
    2ac0:      	ld1.b	{ v2 }[2], [x9]
    2ac4:      	tbz	w10, #0x3, 0x2a18 <_llm_rows.packet_batch.blocks+0xe30>
    2ac8:      	mov.d	x9, v19[1]
    2acc:      	ld1.b	{ v2 }[3], [x9]
    2ad0:      	ldr	q16, [sp, #0x320]
    2ad4:      	add.2d	v17, v16, v3
    2ad8:      	ldr	q16, [sp, #0x440]
    2adc:      	str	q17, [sp, #0x270]
    2ae0:      	add.2d	v19, v16, v17
    2ae4:      	tbz	w10, #0x4, 0x2a30 <_llm_rows.packet_batch.blocks+0xe48>
    2ae8:      	fmov	x9, d19
    2aec:      	ld1.b	{ v2 }[4], [x9]
    2af0:      	tbz	w10, #0x5, 0x2a34 <_llm_rows.packet_batch.blocks+0xe4c>
    2af4:      	mov.d	x9, v19[1]
    2af8:      	ld1.b	{ v2 }[5], [x9]
    2afc:      	ldr	q16, [sp, #0x340]
    2b00:      	add.2d	v3, v16, v3
    2b04:      	str	q3, [sp, #0x260]
    2b08:      	add.2d	v3, v12, v3
    2b0c:      	tbz	w10, #0x6, 0x2a48 <_llm_rows.packet_batch.blocks+0xe60>
    2b10:      	fmov	x9, d3
    2b14:      	ld1.b	{ v2 }[6], [x9]
    2b18:      	tbnz	w10, #0x7, 0x2a4c <_llm_rows.packet_batch.blocks+0xe64>
    2b1c:      	b	0x2a54 <_llm_rows.packet_batch.blocks+0xe6c>
    2b20:      	movi.2d	v3, #0000000000000000
    2b24:      	and	w10, w9, #0xff
    2b28:      	tbz	w10, #0x1, 0x2b34 <_llm_rows.packet_batch.blocks+0xf4c>
    2b2c:      	mov.d	x9, v21[1]
    2b30:      	ld1.b	{ v3 }[1], [x9]
    2b34:      	ldr	q16, [sp, #0x330]
    2b38:      	add.2d	v17, v16, v19
    2b3c:      	ldr	q16, [sp, #0x450]
    2b40:      	str	q17, [sp, #0x240]
    2b44:      	add.2d	v21, v16, v17
    2b48:      	tbnz	w10, #0x2, 0x3160 <_llm_rows.packet_batch.blocks+0x1578>
    2b4c:      	tbnz	w10, #0x3, 0x316c <_llm_rows.packet_batch.blocks+0x1584>
    2b50:      	ldr	q16, [sp, #0x320]
    2b54:      	add.2d	v17, v16, v19
    2b58:      	ldr	q16, [sp, #0x440]
    2b5c:      	str	q17, [sp, #0x230]
    2b60:      	add.2d	v21, v16, v17
    2b64:      	tbnz	w10, #0x4, 0x318c <_llm_rows.packet_batch.blocks+0x15a4>
    2b68:      	tbnz	w10, #0x5, 0x3198 <_llm_rows.packet_batch.blocks+0x15b0>
    2b6c:      	ldr	q16, [sp, #0x340]
    2b70:      	add.2d	v16, v16, v19
    2b74:      	str	q16, [sp, #0x220]
    2b78:      	add.2d	v19, v12, v16
    2b7c:      	tbnz	w10, #0x6, 0x31b4 <_llm_rows.packet_batch.blocks+0x15cc>
    2b80:      	tbz	w10, #0x7, 0x2b8c <_llm_rows.packet_batch.blocks+0xfa4>
    2b84:      	mov.d	x9, v19[1]
    2b88:      	ld1.b	{ v3 }[7], [x9]
    2b8c:      	sshll.2d	v19, v1, #0x0
    2b90:      	sshll.2d	v21, v0, #0x0
    2b94:      	cmeq.8b	v3, v3, #0
    2b98:      	sshll.8h	v3, v3, #0x0
    2b9c:      	sshll2.4s	v23, v3, #0x0
    2ba0:      	sshll.4s	v3, v3, #0x0
    2ba4:      	ldr	q24, [sp, #0x1020]
    2ba8:      	ldr	q25, [sp, #0x1030]
    2bac:      	and.16b	v25, v0, v25
    2bb0:      	and.16b	v24, v1, v24
    2bb4:      	bsl.16b	v3, v4, v24
    2bb8:      	bsl.16b	v23, v4, v25
    2bbc:      	stp	q3, q23, [x23, #0x180]
    2bc0:      	dup.2d	v24, x3
    2bc4:      	and.16b	v9, v15, v24
    2bc8:      	and.16b	v15, v7, v24
    2bcc:      	and.16b	v10, v21, v24
    2bd0:      	and.16b	v14, v19, v24
    2bd4:      	fmov	x10, d14
    2bd8:      	and.16b	v19, v0, v23
    2bdc:      	and.16b	v21, v1, v3
    2be0:      	and.16b	v23, v0, v22
    2be4:      	and.16b	v22, v1, v2
    2be8:      	and.16b	v28, v0, v6
    2bec:      	and.16b	v29, v1, v5
    2bf0:      	and.16b	v30, v0, v30
    2bf4:      	mov	x15, x10
    2bf8:      	and.16b	v8, v1, v8
    2bfc:      	str	q14, [sp, #0x100]
    2c00:      	str	q15, [sp, #0x410]
    2c04:      	str	q10, [sp, #0x400]
    2c08:      	str	q9, [sp, #0x420]
    2c0c:      	b	0x2cd0 <_llm_rows.packet_batch.blocks+0x10e8>
    2c10:      	fmaxnm.4s	v6, v30, v6
    2c14:      	fmaxnm.4s	v5, v8, v5
    2c18:      	fmaxnm.4s	v3, v28, v25
    2c1c:      	fmaxnm.4s	v24, v29, v24
    2c20:      	fmaxnm.4s	v25, v23, v26
    2c24:      	fmaxnm.4s	v2, v22, v2
    2c28:      	sshll.2d	v26, v1, #0x0
    2c2c:      	sshll.2d	v31, v0, #0x0
    2c30:      	cmeq.8b	v27, v27, #0
    2c34:      	sshll.8h	v27, v27, #0x0
    2c38:      	sshll2.4s	v7, v27, #0x0
    2c3c:      	sshll.4s	v27, v27, #0x0
    2c40:      	add	x9, x15, #0x60
    2c44:      	add	x12, x28, x9
    2c48:      	ldp	q16, q17, [x12]
    2c4c:      	and.16b	v17, v0, v17
    2c50:      	and.16b	v16, v1, v16
    2c54:      	bit.16b	v16, v4, v27
    2c58:      	bsl.16b	v7, v4, v17
    2c5c:      	add	x9, x27, x9
    2c60:      	ldp	q17, q27, [x9]
    2c64:      	bit.16b	v27, v7, v0
    2c68:      	bit.16b	v17, v16, v1
    2c6c:      	stp	q17, q27, [x9]
    2c70:      	fmaxnm.4s	v16, v21, v16
    2c74:      	fmaxnm.4s	v7, v19, v7
    2c78:      	dup.2d	v17, x3
    2c7c:      	ldr	q27, [sp, #0x350]
    2c80:      	and.16b	v27, v27, v17
    2c84:      	add.2d	v9, v9, v27
    2c88:      	ldr	q27, [sp, #0x300]
    2c8c:      	and.16b	v27, v27, v17
    2c90:      	add.2d	v15, v15, v27
    2c94:      	and.16b	v27, v31, v17
    2c98:      	add.2d	v10, v10, v27
    2c9c:      	and.16b	v17, v26, v17
    2ca0:      	add.2d	v14, v14, v17
    2ca4:      	bit.16b	v30, v6, v0
    2ca8:      	bit.16b	v8, v5, v1
    2cac:      	bit.16b	v28, v3, v0
    2cb0:      	bit.16b	v29, v24, v1
    2cb4:      	bit.16b	v23, v25, v0
    2cb8:      	bit.16b	v22, v2, v1
    2cbc:      	bit.16b	v19, v7, v0
    2cc0:      	bit.16b	v21, v16, v1
    2cc4:      	fmov	x15, d14
    2cc8:      	cmp	x15, #0x8
    2ccc:      	b.ge	0x3140 <_llm_rows.packet_batch.blocks+0x1558>
    2cd0:      	fmov	w9, s11
    2cd4:      	ldr	q2, [sp, #0x310]
    2cd8:      	add.2d	v2, v14, v2
    2cdc:      	ldr	q3, [sp, #0x430]
    2ce0:      	add.2d	v3, v3, v2
    2ce4:      	tbz	w9, #0x0, 0x2cfc <_llm_rows.packet_batch.blocks+0x1114>
    2ce8:      	fmov	x12, d3
    2cec:      	ldr	b2, [x12]
    2cf0:      	and	w12, w9, #0xff
    2cf4:      	tbnz	w12, #0x1, 0x2d08 <_llm_rows.packet_batch.blocks+0x1120>
    2cf8:      	b	0x2d10 <_llm_rows.packet_batch.blocks+0x1128>
    2cfc:      	movi.2d	v2, #0000000000000000
    2d00:      	and	w12, w9, #0xff
    2d04:      	tbz	w12, #0x1, 0x2d10 <_llm_rows.packet_batch.blocks+0x1128>
    2d08:      	mov.d	x9, v3[1]
    2d0c:      	ld1.b	{ v2 }[1], [x9]
    2d10:      	ldr	q3, [sp, #0x330]
    2d14:      	add.2d	v3, v15, v3
    2d18:      	ldr	q5, [sp, #0x450]
    2d1c:      	add.2d	v3, v5, v3
    2d20:      	tbnz	w12, #0x2, 0x2dc8 <_llm_rows.packet_batch.blocks+0x11e0>
    2d24:      	tbnz	w12, #0x3, 0x2dd4 <_llm_rows.packet_batch.blocks+0x11ec>
    2d28:      	ldr	q3, [sp, #0x320]
    2d2c:      	add.2d	v3, v10, v3
    2d30:      	ldr	q5, [sp, #0x440]
    2d34:      	add.2d	v3, v5, v3
    2d38:      	tbnz	w12, #0x4, 0x2df0 <_llm_rows.packet_batch.blocks+0x1208>
    2d3c:      	tbnz	w12, #0x5, 0x2dfc <_llm_rows.packet_batch.blocks+0x1214>
    2d40:      	ldr	q3, [sp, #0x340]
    2d44:      	add.2d	v3, v9, v3
    2d48:      	add.2d	v3, v12, v3
    2d4c:      	tbnz	w12, #0x6, 0x2e14 <_llm_rows.packet_batch.blocks+0x122c>
    2d50:      	tbz	w12, #0x7, 0x2d5c <_llm_rows.packet_batch.blocks+0x1174>
    2d54:      	mov.d	x9, v3[1]
    2d58:      	ld1.b	{ v2 }[7], [x9]
    2d5c:      	fmov	w9, s11
    2d60:      	cmeq.8b	v2, v2, #0
    2d64:      	sshll.8h	v2, v2, #0x0
    2d68:      	sshll2.4s	v3, v2, #0x0
    2d6c:      	sshll.4s	v2, v2, #0x0
    2d70:      	lsl	x12, x15, #5
    2d74:      	add	x15, x28, x12
    2d78:      	ldp	q5, q6, [x15]
    2d7c:      	and.16b	v6, v0, v6
    2d80:      	and.16b	v5, v1, v5
    2d84:      	bit.16b	v5, v4, v2
    2d88:      	bit.16b	v6, v4, v3
    2d8c:      	add	x12, x27, x12
    2d90:      	ldp	q2, q3, [x12]
    2d94:      	bit.16b	v3, v6, v0
    2d98:      	bit.16b	v2, v5, v1
    2d9c:      	stp	q2, q3, [x12]
    2da0:      	ldr	q2, [sp, #0x2d0]
    2da4:      	add.2d	v2, v14, v2
    2da8:      	ldr	q3, [sp, #0x430]
    2dac:      	add.2d	v3, v3, v2
    2db0:      	tbz	w9, #0x0, 0x2e24 <_llm_rows.packet_batch.blocks+0x123c>
    2db4:      	fmov	x12, d3
    2db8:      	ldr	b2, [x12]
    2dbc:      	and	w12, w9, #0xff
    2dc0:      	tbnz	w12, #0x1, 0x2e30 <_llm_rows.packet_batch.blocks+0x1248>
    2dc4:      	b	0x2e38 <_llm_rows.packet_batch.blocks+0x1250>
    2dc8:      	fmov	x9, d3
    2dcc:      	ld1.b	{ v2 }[2], [x9]
    2dd0:      	tbz	w12, #0x3, 0x2d28 <_llm_rows.packet_batch.blocks+0x1140>
    2dd4:      	mov.d	x9, v3[1]
    2dd8:      	ld1.b	{ v2 }[3], [x9]
    2ddc:      	ldr	q3, [sp, #0x320]
    2de0:      	add.2d	v3, v10, v3
    2de4:      	ldr	q5, [sp, #0x440]
    2de8:      	add.2d	v3, v5, v3
    2dec:      	tbz	w12, #0x4, 0x2d3c <_llm_rows.packet_batch.blocks+0x1154>
    2df0:      	fmov	x9, d3
    2df4:      	ld1.b	{ v2 }[4], [x9]
    2df8:      	tbz	w12, #0x5, 0x2d40 <_llm_rows.packet_batch.blocks+0x1158>
    2dfc:      	mov.d	x9, v3[1]
    2e00:      	ld1.b	{ v2 }[5], [x9]
    2e04:      	ldr	q3, [sp, #0x340]
    2e08:      	add.2d	v3, v9, v3
    2e0c:      	add.2d	v3, v12, v3
    2e10:      	tbz	w12, #0x6, 0x2d50 <_llm_rows.packet_batch.blocks+0x1168>
    2e14:      	fmov	x9, d3
    2e18:      	ld1.b	{ v2 }[6], [x9]
    2e1c:      	tbnz	w12, #0x7, 0x2d54 <_llm_rows.packet_batch.blocks+0x116c>
    2e20:      	b	0x2d5c <_llm_rows.packet_batch.blocks+0x1174>
    2e24:      	movi.2d	v2, #0000000000000000
    2e28:      	and	w12, w9, #0xff
    2e2c:      	tbz	w12, #0x1, 0x2e38 <_llm_rows.packet_batch.blocks+0x1250>
    2e30:      	mov.d	x9, v3[1]
    2e34:      	ld1.b	{ v2 }[1], [x9]
    2e38:      	ldr	q3, [sp, #0x2c0]
    2e3c:      	add.2d	v3, v15, v3
    2e40:      	ldr	q7, [sp, #0x450]
    2e44:      	add.2d	v3, v7, v3
    2e48:      	tbnz	w12, #0x2, 0x2ef8 <_llm_rows.packet_batch.blocks+0x1310>
    2e4c:      	tbnz	w12, #0x3, 0x2f04 <_llm_rows.packet_batch.blocks+0x131c>
    2e50:      	ldr	q3, [sp, #0x2b0]
    2e54:      	add.2d	v3, v10, v3
    2e58:      	ldr	q7, [sp, #0x440]
    2e5c:      	add.2d	v3, v7, v3
    2e60:      	tbnz	w12, #0x4, 0x2f20 <_llm_rows.packet_batch.blocks+0x1338>
    2e64:      	tbnz	w12, #0x5, 0x2f2c <_llm_rows.packet_batch.blocks+0x1344>
    2e68:      	ldr	q3, [sp, #0x2a0]
    2e6c:      	add.2d	v3, v9, v3
    2e70:      	add.2d	v3, v12, v3
    2e74:      	tbnz	w12, #0x6, 0x2f44 <_llm_rows.packet_batch.blocks+0x135c>
    2e78:      	tbz	w12, #0x7, 0x2e84 <_llm_rows.packet_batch.blocks+0x129c>
    2e7c:      	mov.d	x9, v3[1]
    2e80:      	ld1.b	{ v2 }[7], [x9]
    2e84:      	fmov	w9, s11
    2e88:      	cmeq.8b	v2, v2, #0
    2e8c:      	sshll.8h	v2, v2, #0x0
    2e90:      	sshll2.4s	v3, v2, #0x0
    2e94:      	sshll.4s	v2, v2, #0x0
    2e98:      	fmov	x12, d14
    2e9c:      	lsl	x15, x12, #5
    2ea0:      	add	x12, x15, #0x20
    2ea4:      	add	x16, x28, x12
    2ea8:      	ldp	q24, q25, [x16]
    2eac:      	and.16b	v25, v0, v25
    2eb0:      	and.16b	v24, v1, v24
    2eb4:      	bit.16b	v24, v4, v2
    2eb8:      	bit.16b	v25, v4, v3
    2ebc:      	add	x12, x27, x12
    2ec0:      	ldp	q2, q3, [x12]
    2ec4:      	bit.16b	v3, v25, v0
    2ec8:      	bit.16b	v2, v24, v1
    2ecc:      	stp	q2, q3, [x12]
    2ed0:      	ldr	q2, [sp, #0x290]
    2ed4:      	add.2d	v2, v14, v2
    2ed8:      	ldr	q3, [sp, #0x430]
    2edc:      	add.2d	v3, v3, v2
    2ee0:      	tbz	w9, #0x0, 0x2f54 <_llm_rows.packet_batch.blocks+0x136c>
    2ee4:      	fmov	x12, d3
    2ee8:      	ldr	b2, [x12]
    2eec:      	and	w12, w9, #0xff
    2ef0:      	tbnz	w12, #0x1, 0x2f60 <_llm_rows.packet_batch.blocks+0x1378>
    2ef4:      	b	0x2f68 <_llm_rows.packet_batch.blocks+0x1380>
    2ef8:      	fmov	x9, d3
    2efc:      	ld1.b	{ v2 }[2], [x9]
    2f00:      	tbz	w12, #0x3, 0x2e50 <_llm_rows.packet_batch.blocks+0x1268>
    2f04:      	mov.d	x9, v3[1]
    2f08:      	ld1.b	{ v2 }[3], [x9]
    2f0c:      	ldr	q3, [sp, #0x2b0]
    2f10:      	add.2d	v3, v10, v3
    2f14:      	ldr	q7, [sp, #0x440]
    2f18:      	add.2d	v3, v7, v3
    2f1c:      	tbz	w12, #0x4, 0x2e64 <_llm_rows.packet_batch.blocks+0x127c>
    2f20:      	fmov	x9, d3
    2f24:      	ld1.b	{ v2 }[4], [x9]
    2f28:      	tbz	w12, #0x5, 0x2e68 <_llm_rows.packet_batch.blocks+0x1280>
    2f2c:      	mov.d	x9, v3[1]
    2f30:      	ld1.b	{ v2 }[5], [x9]
    2f34:      	ldr	q3, [sp, #0x2a0]
    2f38:      	add.2d	v3, v9, v3
    2f3c:      	add.2d	v3, v12, v3
    2f40:      	tbz	w12, #0x6, 0x2e78 <_llm_rows.packet_batch.blocks+0x1290>
    2f44:      	fmov	x9, d3
    2f48:      	ld1.b	{ v2 }[6], [x9]
    2f4c:      	tbnz	w12, #0x7, 0x2e7c <_llm_rows.packet_batch.blocks+0x1294>
    2f50:      	b	0x2e84 <_llm_rows.packet_batch.blocks+0x129c>
    2f54:      	movi.2d	v2, #0000000000000000
    2f58:      	and	w12, w9, #0xff
    2f5c:      	tbz	w12, #0x1, 0x2f68 <_llm_rows.packet_batch.blocks+0x1380>
    2f60:      	mov.d	x9, v3[1]
    2f64:      	ld1.b	{ v2 }[1], [x9]
    2f68:      	ldr	q3, [sp, #0x280]
    2f6c:      	add.2d	v3, v15, v3
    2f70:      	ldr	q7, [sp, #0x450]
    2f74:      	add.2d	v3, v7, v3
    2f78:      	tbnz	w12, #0x2, 0x3024 <_llm_rows.packet_batch.blocks+0x143c>
    2f7c:      	tbnz	w12, #0x3, 0x3030 <_llm_rows.packet_batch.blocks+0x1448>
    2f80:      	ldr	q3, [sp, #0x270]
    2f84:      	add.2d	v3, v10, v3
    2f88:      	ldr	q7, [sp, #0x440]
    2f8c:      	add.2d	v3, v7, v3
    2f90:      	tbnz	w12, #0x4, 0x304c <_llm_rows.packet_batch.blocks+0x1464>
    2f94:      	tbnz	w12, #0x5, 0x3058 <_llm_rows.packet_batch.blocks+0x1470>
    2f98:      	ldr	q3, [sp, #0x260]
    2f9c:      	add.2d	v3, v9, v3
    2fa0:      	add.2d	v3, v12, v3
    2fa4:      	tbnz	w12, #0x6, 0x3070 <_llm_rows.packet_batch.blocks+0x1488>
    2fa8:      	tbz	w12, #0x7, 0x2fb4 <_llm_rows.packet_batch.blocks+0x13cc>
    2fac:      	mov.d	x9, v3[1]
    2fb0:      	ld1.b	{ v2 }[7], [x9]
    2fb4:      	fmov	w9, s11
    2fb8:      	cmeq.8b	v2, v2, #0
    2fbc:      	sshll.8h	v2, v2, #0x0
    2fc0:      	sshll2.4s	v3, v2, #0x0
    2fc4:      	sshll.4s	v2, v2, #0x0
    2fc8:      	add	x12, x15, #0x40
    2fcc:      	add	x16, x28, x12
    2fd0:      	ldp	q26, q27, [x16]
    2fd4:      	and.16b	v27, v0, v27
    2fd8:      	and.16b	v26, v1, v26
    2fdc:      	bsl.16b	v2, v4, v26
    2fe0:      	mov.16b	v26, v3
    2fe4:      	bsl.16b	v26, v4, v27
    2fe8:      	add	x12, x27, x12
    2fec:      	ldp	q3, q27, [x12]
    2ff0:      	bit.16b	v27, v26, v0
    2ff4:      	bit.16b	v3, v2, v1
    2ff8:      	stp	q3, q27, [x12]
    2ffc:      	ldr	q3, [sp, #0x250]
    3000:      	add.2d	v3, v14, v3
    3004:      	ldr	q7, [sp, #0x430]
    3008:      	add.2d	v3, v7, v3
    300c:      	tbz	w9, #0x0, 0x3080 <_llm_rows.packet_batch.blocks+0x1498>
    3010:      	fmov	x12, d3
    3014:      	ldr	b27, [x12]
    3018:      	and	w12, w9, #0xff
    301c:      	tbnz	w12, #0x1, 0x308c <_llm_rows.packet_batch.blocks+0x14a4>
    3020:      	b	0x3094 <_llm_rows.packet_batch.blocks+0x14ac>
    3024:      	fmov	x9, d3
    3028:      	ld1.b	{ v2 }[2], [x9]
    302c:      	tbz	w12, #0x3, 0x2f80 <_llm_rows.packet_batch.blocks+0x1398>
    3030:      	mov.d	x9, v3[1]
    3034:      	ld1.b	{ v2 }[3], [x9]
    3038:      	ldr	q3, [sp, #0x270]
    303c:      	add.2d	v3, v10, v3
    3040:      	ldr	q7, [sp, #0x440]
    3044:      	add.2d	v3, v7, v3
    3048:      	tbz	w12, #0x4, 0x2f94 <_llm_rows.packet_batch.blocks+0x13ac>
    304c:      	fmov	x9, d3
    3050:      	ld1.b	{ v2 }[4], [x9]
    3054:      	tbz	w12, #0x5, 0x2f98 <_llm_rows.packet_batch.blocks+0x13b0>
    3058:      	mov.d	x9, v3[1]
    305c:      	ld1.b	{ v2 }[5], [x9]
    3060:      	ldr	q3, [sp, #0x260]
    3064:      	add.2d	v3, v9, v3
    3068:      	add.2d	v3, v12, v3
    306c:      	tbz	w12, #0x6, 0x2fa8 <_llm_rows.packet_batch.blocks+0x13c0>
    3070:      	fmov	x9, d3
    3074:      	ld1.b	{ v2 }[6], [x9]
    3078:      	tbnz	w12, #0x7, 0x2fac <_llm_rows.packet_batch.blocks+0x13c4>
    307c:      	b	0x2fb4 <_llm_rows.packet_batch.blocks+0x13cc>
    3080:      	movi.2d	v27, #0000000000000000
    3084:      	and	w12, w9, #0xff
    3088:      	tbz	w12, #0x1, 0x3094 <_llm_rows.packet_batch.blocks+0x14ac>
    308c:      	mov.d	x9, v3[1]
    3090:      	ld1.b	{ v27 }[1], [x9]
    3094:      	ldr	q3, [sp, #0x240]
    3098:      	add.2d	v3, v15, v3
    309c:      	ldr	q7, [sp, #0x450]
    30a0:      	add.2d	v3, v7, v3
    30a4:      	tbnz	w12, #0x2, 0x30dc <_llm_rows.packet_batch.blocks+0x14f4>
    30a8:      	tbnz	w12, #0x3, 0x30e8 <_llm_rows.packet_batch.blocks+0x1500>
    30ac:      	ldr	q3, [sp, #0x230]
    30b0:      	add.2d	v3, v10, v3
    30b4:      	ldr	q7, [sp, #0x440]
    30b8:      	add.2d	v3, v7, v3
    30bc:      	tbnz	w12, #0x4, 0x3104 <_llm_rows.packet_batch.blocks+0x151c>
    30c0:      	tbnz	w12, #0x5, 0x3110 <_llm_rows.packet_batch.blocks+0x1528>
    30c4:      	ldr	q3, [sp, #0x220]
    30c8:      	add.2d	v3, v9, v3
    30cc:      	add.2d	v3, v12, v3
    30d0:      	tbnz	w12, #0x6, 0x3128 <_llm_rows.packet_batch.blocks+0x1540>
    30d4:      	tbz	w12, #0x7, 0x2c10 <_llm_rows.packet_batch.blocks+0x1028>
    30d8:      	b	0x3134 <_llm_rows.packet_batch.blocks+0x154c>
    30dc:      	fmov	x9, d3
    30e0:      	ld1.b	{ v27 }[2], [x9]
    30e4:      	tbz	w12, #0x3, 0x30ac <_llm_rows.packet_batch.blocks+0x14c4>
    30e8:      	mov.d	x9, v3[1]
    30ec:      	ld1.b	{ v27 }[3], [x9]
    30f0:      	ldr	q3, [sp, #0x230]
    30f4:      	add.2d	v3, v10, v3
    30f8:      	ldr	q7, [sp, #0x440]
    30fc:      	add.2d	v3, v7, v3
    3100:      	tbz	w12, #0x4, 0x30c0 <_llm_rows.packet_batch.blocks+0x14d8>
    3104:      	fmov	x9, d3
    3108:      	ld1.b	{ v27 }[4], [x9]
    310c:      	tbz	w12, #0x5, 0x30c4 <_llm_rows.packet_batch.blocks+0x14dc>
    3110:      	mov.d	x9, v3[1]
    3114:      	ld1.b	{ v27 }[5], [x9]
    3118:      	ldr	q3, [sp, #0x220]
    311c:      	add.2d	v3, v9, v3
    3120:      	add.2d	v3, v12, v3
    3124:      	tbz	w12, #0x6, 0x30d4 <_llm_rows.packet_batch.blocks+0x14ec>
    3128:      	fmov	x9, d3
    312c:      	ld1.b	{ v27 }[6], [x9]
    3130:      	tbz	w12, #0x7, 0x2c10 <_llm_rows.packet_batch.blocks+0x1028>
    3134:      	mov.d	x9, v3[1]
    3138:      	ld1.b	{ v27 }[7], [x9]
    313c:      	b	0x2c10 <_llm_rows.packet_batch.blocks+0x1028>
    3140:      	ldr	d2, [sp, #0x1b0]
    3144:      	fmov	w15, s2
    3148:      	tbz	w15, #0x0, 0x31c4 <_llm_rows.packet_batch.blocks+0x15dc>
    314c:      	fmov	x9, d20
    3150:      	ldr	b2, [x9]
    3154:      	ldr	q9, [sp, #0x350]
    3158:      	tbnz	w15, #0x1, 0x31d0 <_llm_rows.packet_batch.blocks+0x15e8>
    315c:      	b	0x31d4 <_llm_rows.packet_batch.blocks+0x15ec>
    3160:      	fmov	x9, d21
    3164:      	ld1.b	{ v3 }[2], [x9]
    3168:      	tbz	w10, #0x3, 0x2b50 <_llm_rows.packet_batch.blocks+0xf68>
    316c:      	mov.d	x9, v21[1]
    3170:      	ld1.b	{ v3 }[3], [x9]
    3174:      	ldr	q16, [sp, #0x320]
    3178:      	add.2d	v17, v16, v19
    317c:      	ldr	q16, [sp, #0x440]
    3180:      	str	q17, [sp, #0x230]
    3184:      	add.2d	v21, v16, v17
    3188:      	tbz	w10, #0x4, 0x2b68 <_llm_rows.packet_batch.blocks+0xf80>
    318c:      	fmov	x9, d21
    3190:      	ld1.b	{ v3 }[4], [x9]
    3194:      	tbz	w10, #0x5, 0x2b6c <_llm_rows.packet_batch.blocks+0xf84>
    3198:      	mov.d	x9, v21[1]
    319c:      	ld1.b	{ v3 }[5], [x9]
    31a0:      	ldr	q16, [sp, #0x340]
    31a4:      	add.2d	v16, v16, v19
    31a8:      	str	q16, [sp, #0x220]
    31ac:      	add.2d	v19, v12, v16
    31b0:      	tbz	w10, #0x6, 0x2b80 <_llm_rows.packet_batch.blocks+0xf98>
    31b4:      	fmov	x9, d19
    31b8:      	ld1.b	{ v3 }[6], [x9]
    31bc:      	tbnz	w10, #0x7, 0x2b84 <_llm_rows.packet_batch.blocks+0xf9c>
    31c0:      	b	0x2b8c <_llm_rows.packet_batch.blocks+0xfa4>
    31c4:      	movi.2d	v2, #0000000000000000
    31c8:      	ldr	q9, [sp, #0x350]
    31cc:      	tbz	w15, #0x1, 0x31d4 <_llm_rows.packet_batch.blocks+0x15ec>
    31d0:      	ld1.b	{ v2 }[1], [x14]
    31d4:      	tbnz	w15, #0x2, 0x3a70 <_llm_rows.packet_batch.blocks+0x1e88>
    31d8:      	tbnz	w15, #0x3, 0x3a7c <_llm_rows.packet_batch.blocks+0x1e94>
    31dc:      	tbnz	w15, #0x4, 0x3a84 <_llm_rows.packet_batch.blocks+0x1e9c>
    31e0:      	tbnz	w15, #0x5, 0x3a94 <_llm_rows.packet_batch.blocks+0x1eac>
    31e4:      	tbz	w15, #0x6, 0x31f4 <_llm_rows.packet_batch.blocks+0x160c>
    31e8:      	ldr	q3, [sp, #0xf0]
    31ec:      	fmov	x9, d3
    31f0:      	ld1.b	{ v2 }[6], [x9]
    31f4:      	ldr	q3, [sp, #0x3d0]
    31f8:      	xtn.8b	v25, v3
    31fc:      	sshll.2d	v10, v1, #0x0
    3200:      	mov.16b	v17, v25
    3204:      	mov.b	v17[0], wzr
    3208:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1418>
    320c:      	ldr	q3, [x9]
    3210:      	and.16b	v31, v10, v3
    3214:      	str	x4, [sp, #0x178]
    3218:      	str	x5, [sp, #0x118]
    321c:      	str	q12, [sp, #0x370]
    3220:      	str	w22, [sp, #0xc0]
    3224:      	tbz	w15, #0x7, 0x322c <_llm_rows.packet_batch.blocks+0x1644>
    3228:      	ld1.b	{ v2 }[7], [x8]
    322c:      	cmeq.8b	v2, v2, #0
    3230:      	sshll.8h	v2, v2, #0x0
    3234:      	sshll2.4s	v3, v2, #0x0
    3238:      	stp	q3, q2, [sp, #0x90]
    323c:      	sshll.4s	v2, v2, #0x0
    3240:      	ldr	q7, [sp, #0x3b0]
    3244:      	mov.16b	v26, v2
    3248:      	bsl.16b	v26, v4, v7
    324c:      	mov.16b	v27, v3
    3250:      	bsl.16b	v27, v4, v13
    3254:      	ldr	q3, [sp, #0x1d0]
    3258:      	zip2.8b	v2, v3, v0
    325c:      	ushll.4s	v2, v2, #0x0
    3260:      	shl.4s	v2, v2, #0x1f
    3264:      	cmlt.4s	v4, v2, #0
    3268:      	zip1.8b	v2, v3, v0
    326c:      	ushll.4s	v2, v2, #0x0
    3270:      	shl.4s	v2, v2, #0x1f
    3274:      	cmlt.4s	v16, v2, #0
    3278:      	fmaxnm.4s	v2, v30, v27
    327c:      	fmaxnm.4s	v3, v8, v26
    3280:      	and.16b	v3, v16, v3
    3284:      	and.16b	v2, v4, v2
    3288:      	zip2.8b	v7, v17, v0
    328c:      	ushll.4s	v7, v7, #0x0
    3290:      	shl.4s	v7, v7, #0x1f
    3294:      	cmlt.4s	v7, v7, #0
    3298:      	bit.16b	v2, v6, v7
    329c:      	str	q17, [sp, #0xb0]
    32a0:      	zip1.8b	v6, v17, v0
    32a4:      	ushll.4s	v6, v6, #0x0
    32a8:      	shl.4s	v6, v6, #0x1f
    32ac:      	cmlt.4s	v6, v6, #0
    32b0:      	bit.16b	v3, v5, v6
    32b4:      	fmaxnm.4s	v3, v3, v29
    32b8:      	fmaxnm.4s	v2, v2, v28
    32bc:      	fmaxnm.4s	v2, v2, v23
    32c0:      	fmaxnm.4s	v3, v3, v22
    32c4:      	fmaxnm.4s	v17, v3, v21
    32c8:      	fmaxnm.4s	v18, v2, v19
    32cc:      	ldr	q2, [sp, #0x3c0]
    32d0:      	ldp	q3, q6, [sp, #0x380]
    32d4:      	uzp1.4s	v5, v2, v6
    32d8:      	ldr	q2, [sp, #0x3a0]
    32dc:      	uzp1.4s	v6, v3, v2
    32e0:      	movi.4s	v3, #0x1
    32e4:      	eor.16b	v2, v5, v3
    32e8:      	mov.s	w9, v2[1]
    32ec:      	eor.16b	v20, v6, v3
    32f0:      	mov.s	w12, v2[2]
    32f4:      	mov.s	w13, v2[3]
    32f8:      	fmov	w8, s2
    32fc:      	add	x11, sp, #0x6f8
    3300:      	bfxil	x11, x8, #0, #3
    3304:      	str	d25, [sp, #0x6f8]
    3308:      	ldrb	w14, [x11]
    330c:      	umov.b	w22, v25[0]
    3310:      	and	x8, x8, #0x7
    3314:      	str	q18, [sp, #0x990]
    3318:      	str	q17, [sp, #0x980]
    331c:      	add	x15, sp, #0x980
    3320:      	ldr	s2, [x15, x8, lsl #2]
    3324:      	ands	w8, w22, #0x1
    3328:      	tst	w8, w14
    332c:      	movi	d24, #0000000000000000
    3330:      	fcsel	s2, s2, s24, ne
    3334:      	and	x14, x9, #0x7
    3338:      	add	x15, sp, #0x6f8
    333c:      	bfxil	x15, x9, #0, #3
    3340:      	ldrb	w9, [x15]
    3344:      	umov.b	w11, v25[1]
    3348:      	str	q18, [sp, #0x970]
    334c:      	str	q17, [sp, #0x960]
    3350:      	add	x16, sp, #0x960
    3354:      	ldr	s3, [x16, x14, lsl #2]
    3358:      	and	w9, w11, w9
    335c:      	tst	w9, #0x1
    3360:      	fcsel	s7, s3, s24, ne
    3364:      	and	x9, x12, #0x7
    3368:      	add	x14, sp, #0x6f8
    336c:      	bfxil	x14, x12, #0, #3
    3370:      	ldrb	w12, [x14]
    3374:      	umov.b	w15, v25[2]
    3378:      	and	w12, w15, w12
    337c:      	str	q18, [sp, #0x950]
    3380:      	str	q17, [sp, #0x940]
    3384:      	add	x16, sp, #0x940
    3388:      	ldr	s3, [x16, x9, lsl #2]
    338c:      	tst	w12, #0x1
    3390:      	fcsel	s19, s3, s24, ne
    3394:      	and	x9, x13, #0x7
    3398:      	add	x12, sp, #0x6f8
    339c:      	bfxil	x12, x13, #0, #3
    33a0:      	ldrb	w12, [x12]
    33a4:      	umov.b	w14, v25[3]
    33a8:      	and	w12, w14, w12
    33ac:      	str	q18, [sp, #0x930]
    33b0:      	str	q17, [sp, #0x920]
    33b4:      	add	x16, sp, #0x920
    33b8:      	ldr	s3, [x16, x9, lsl #2]
    33bc:      	tst	w12, #0x1
    33c0:      	mov.s	w9, v20[1]
    33c4:      	fcsel	s3, s3, s24, ne
    33c8:      	mov.s	w12, v20[2]
    33cc:      	mov.s	w16, v20[3]
    33d0:      	fmov	w17, s20
    33d4:      	and	x0, x17, #0x7
    33d8:      	add	x1, sp, #0x6f8
    33dc:      	bfxil	x1, x17, #0, #3
    33e0:      	ldrb	w17, [x1]
    33e4:      	umov.b	w13, v25[4]
    33e8:      	and	w17, w13, w17
    33ec:      	str	q18, [sp, #0xa10]
    33f0:      	str	q17, [sp, #0xa00]
    33f4:      	add	x2, sp, #0xa00
    33f8:      	ldr	s20, [x2, x0, lsl #2]
    33fc:      	tst	w17, #0x1
    3400:      	fcsel	s20, s20, s24, ne
    3404:      	and	x17, x9, #0x7
    3408:      	add	x2, sp, #0x6f8
    340c:      	bfxil	x2, x9, #0, #3
    3410:      	umov.b	w1, v25[5]
    3414:      	ldrb	w9, [x2]
    3418:      	and	w9, w1, w9
    341c:      	str	q18, [sp, #0x9f0]
    3420:      	str	q17, [sp, #0x9e0]
    3424:      	add	x2, sp, #0x9e0
    3428:      	ldr	s21, [x2, x17, lsl #2]
    342c:      	tst	w9, #0x1
    3430:      	fcsel	s21, s21, s24, ne
    3434:      	and	x9, x12, #0x7
    3438:      	add	x17, sp, #0x6f8
    343c:      	bfxil	x17, x12, #0, #3
    3440:      	ldrb	w12, [x17]
    3444:      	umov.b	w0, v25[6]
    3448:      	str	q18, [sp, #0x9d0]
    344c:      	str	q17, [sp, #0x9c0]
    3450:      	add	x2, sp, #0x9c0
    3454:      	ldr	s22, [x2, x9, lsl #2]
    3458:      	and	w9, w0, w12
    345c:      	tst	w9, #0x1
    3460:      	fcsel	s22, s22, s24, ne
    3464:      	and	x9, x16, #0x7
    3468:      	add	x12, sp, #0x6f8
    346c:      	bfxil	x12, x16, #0, #3
    3470:      	ldrb	w12, [x12]
    3474:      	str	q25, [sp, #0xd0]
    3478:      	umov.b	w17, v25[7]
    347c:      	and	w12, w17, w12
    3480:      	str	q18, [sp, #0x9b0]
    3484:      	str	q17, [sp, #0x9a0]
    3488:      	add	x16, sp, #0x9a0
    348c:      	ldr	s23, [x16, x9, lsl #2]
    3490:      	tst	w12, #0x1
    3494:      	fcsel	s23, s23, s24, ne
    3498:      	mov.s	v20[1], v21[0]
    349c:      	mov.s	v20[2], v22[0]
    34a0:      	mov.s	v20[3], v23[0]
    34a4:      	mov.s	v2[1], v7[0]
    34a8:      	mov.s	v2[2], v19[0]
    34ac:      	mov.s	v2[3], v3[0]
    34b0:      	fmaxnm.4s	v7, v17, v2
    34b4:      	fmaxnm.4s	v17, v18, v20
    34b8:      	movi.4s	v3, #0x2
    34bc:      	eor.16b	v2, v5, v3
    34c0:      	mov.s	w9, v2[1]
    34c4:      	mov.s	w12, v2[2]
    34c8:      	eor.16b	v19, v6, v3
    34cc:      	mov.s	w16, v2[3]
    34d0:      	fmov	w2, s2
    34d4:      	add	x3, sp, #0x6f8
    34d8:      	bfxil	x3, x2, #0, #3
    34dc:      	ldrb	w3, [x3]
    34e0:      	and	x2, x2, #0x7
    34e4:      	str	q17, [sp, #0x910]
    34e8:      	str	q7, [sp, #0x900]
    34ec:      	add	x4, sp, #0x900
    34f0:      	ldr	s2, [x4, x2, lsl #2]
    34f4:      	tst	w8, w3
    34f8:      	fcsel	s2, s2, s24, ne
    34fc:      	and	x2, x9, #0x7
    3500:      	add	x3, sp, #0x6f8
    3504:      	bfxil	x3, x9, #0, #3
    3508:      	ldrb	w9, [x3]
    350c:      	and	w9, w11, w9
    3510:      	str	q17, [sp, #0x8f0]
    3514:      	str	q7, [sp, #0x8e0]
    3518:      	add	x3, sp, #0x8e0
    351c:      	ldr	s3, [x3, x2, lsl #2]
    3520:      	tst	w9, #0x1
    3524:      	fcsel	s6, s3, s24, ne
    3528:      	and	x9, x12, #0x7
    352c:      	add	x2, sp, #0x6f8
    3530:      	bfxil	x2, x12, #0, #3
    3534:      	ldrb	w12, [x2]
    3538:      	and	w12, w15, w12
    353c:      	str	q17, [sp, #0x8d0]
    3540:      	str	q7, [sp, #0x8c0]
    3544:      	add	x2, sp, #0x8c0
    3548:      	ldr	s3, [x2, x9, lsl #2]
    354c:      	tst	w12, #0x1
    3550:      	fcsel	s18, s3, s24, ne
    3554:      	and	x9, x16, #0x7
    3558:      	add	x12, sp, #0x6f8
    355c:      	bfxil	x12, x16, #0, #3
    3560:      	ldrb	w12, [x12]
    3564:      	and	w12, w14, w12
    3568:      	str	q17, [sp, #0x8b0]
    356c:      	str	q7, [sp, #0x8a0]
    3570:      	add	x16, sp, #0x8a0
    3574:      	ldr	s3, [x16, x9, lsl #2]
    3578:      	tst	w12, #0x1
    357c:      	mov.s	w9, v19[3]
    3580:      	fmov	w12, s19
    3584:      	and	x19, x12, #0x7
    3588:      	add	x26, sp, #0x6f8
    358c:      	bfxil	x26, x12, #0, #3
    3590:      	add	x12, sp, #0x6f8
    3594:      	bfxil	x12, x9, #0, #3
    3598:      	ldrb	w16, [x12]
    359c:      	movi.4s	v20, #0x4
    35a0:      	eor.16b	v5, v5, v20
    35a4:      	mov.s	w5, v5[1]
    35a8:      	mov.s	w4, v5[2]
    35ac:      	mov.s	w2, v5[3]
    35b0:      	fmov	w3, s5
    35b4:      	add	x12, sp, #0x6f8
    35b8:      	bfxil	x12, x3, #0, #3
    35bc:      	ldrb	w30, [x12]
    35c0:      	add	x12, sp, #0x6f8
    35c4:      	bfxil	x12, x5, #0, #3
    35c8:      	ldrb	w12, [x12]
    35cc:      	add	x6, sp, #0x6f8
    35d0:      	bfxil	x6, x4, #0, #3
    35d4:      	ldrb	w7, [x6]
    35d8:      	add	x6, sp, #0x6f8
    35dc:      	bfxil	x6, x2, #0, #3
    35e0:      	ldrb	w6, [x6]
    35e4:      	ldrb	w26, [x26]
    35e8:      	str	q17, [sp, #0x890]
    35ec:      	str	q7, [sp, #0x880]
    35f0:      	add	x25, sp, #0x880
    35f4:      	ldr	s5, [x25, x19, lsl #2]
    35f8:      	mov.s	w19, v19[1]
    35fc:      	fcsel	s3, s3, s24, ne
    3600:      	and	w26, w13, w26
    3604:      	tst	w26, #0x1
    3608:      	add	x26, sp, #0x6f8
    360c:      	bfxil	x26, x19, #0, #3
    3610:      	and	x19, x19, #0x7
    3614:      	ldrb	w26, [x26]
    3618:      	str	q17, [sp, #0x870]
    361c:      	str	q7, [sp, #0x860]
    3620:      	add	x25, sp, #0x860
    3624:      	ldr	s20, [x25, x19, lsl #2]
    3628:      	mov.s	w19, v19[2]
    362c:      	fcsel	s5, s5, s24, ne
    3630:      	and	w26, w1, w26
    3634:      	tst	w26, #0x1
    3638:      	add	x26, sp, #0x6f8
    363c:      	bfxil	x26, x19, #0, #3
    3640:      	and	x19, x19, #0x7
    3644:      	ldrb	w26, [x26]
    3648:      	str	q17, [sp, #0x850]
    364c:      	str	q7, [sp, #0x840]
    3650:      	add	x25, sp, #0x840
    3654:      	ldr	s19, [x25, x19, lsl #2]
    3658:      	fcsel	s20, s20, s24, ne
    365c:      	and	w19, w0, w26
    3660:      	tst	w19, #0x1
    3664:      	and	x9, x9, #0x7
    3668:      	str	q17, [sp, #0x830]
    366c:      	str	q7, [sp, #0x820]
    3670:      	add	x19, sp, #0x820
    3674:      	ldr	s21, [x19, x9, lsl #2]
    3678:      	fcsel	s19, s19, s24, ne
    367c:      	and	w9, w17, w16
    3680:      	tst	w9, #0x1
    3684:      	fcsel	s21, s21, s24, ne
    3688:      	mov.s	v5[1], v20[0]
    368c:      	mov.s	v5[2], v19[0]
    3690:      	mov.s	v5[3], v21[0]
    3694:      	mov.s	v2[1], v6[0]
    3698:      	mov.s	v2[2], v18[0]
    369c:      	mov.s	v2[3], v3[0]
    36a0:      	fmaxnm.4s	v2, v7, v2
    36a4:      	fmaxnm.4s	v3, v17, v5
    36a8:      	and	x9, x3, #0x7
    36ac:      	str	q3, [sp, #0x810]
    36b0:      	str	q2, [sp, #0x800]
    36b4:      	add	x16, sp, #0x800
    36b8:      	ldr	s5, [x16, x9, lsl #2]
    36bc:      	tst	w8, w30
    36c0:      	fcsel	s5, s5, s24, ne
    36c4:      	and	x8, x5, #0x7
    36c8:      	and	w9, w11, w12
    36cc:      	str	q3, [sp, #0x7f0]
    36d0:      	str	q2, [sp, #0x7e0]
    36d4:      	add	x12, sp, #0x7e0
    36d8:      	ldr	s6, [x12, x8, lsl #2]
    36dc:      	tst	w9, #0x1
    36e0:      	fcsel	s6, s6, s24, ne
    36e4:      	and	x8, x4, #0x7
    36e8:      	and	w9, w15, w7
    36ec:      	str	q3, [sp, #0x7d0]
    36f0:      	str	q2, [sp, #0x7c0]
    36f4:      	add	x12, sp, #0x7c0
    36f8:      	ldr	s7, [x12, x8, lsl #2]
    36fc:      	tst	w9, #0x1
    3700:      	fcsel	s7, s7, s24, ne
    3704:      	and	x8, x2, #0x7
    3708:      	str	q3, [sp, #0x7b0]
    370c:      	str	q2, [sp, #0x7a0]
    3710:      	add	x9, sp, #0x7a0
    3714:      	ldr	s3, [x9, x8, lsl #2]
    3718:      	and	w8, w14, w6
    371c:      	tst	w8, #0x1
    3720:      	fcsel	s3, s3, s24, ne
    3724:      	ands	w2, w22, #0x1
    3728:      	ldr	x26, [sp, #0x118]
    372c:      	add	x8, x27, x26
    3730:      	ldp	q18, q17, [x8]
    3734:      	stp	q27, q26, [sp, #0x70]
    3738:      	bsl.16b	v16, v26, v18
    373c:      	bsl.16b	v4, v27, v17
    3740:      	mov.s	v5[1], v6[0]
    3744:      	stp	q16, q4, [x8]
    3748:      	mov.s	v5[2], v7[0]
    374c:      	mov.s	v5[3], v3[0]
    3750:      	fmaxnm.4s	v2, v2, v5
    3754:      	fcsel	s3, s2, s24, ne
    3758:      	mov	x4, x11
    375c:      	and	w7, w11, w22
    3760:      	tst	w7, #0x1
    3764:      	fcsel	s4, s2, s24, ne
    3768:      	mov	x25, x15
    376c:      	and	w30, w15, w22
    3770:      	tst	w30, #0x1
    3774:      	fcsel	s5, s2, s24, ne
    3778:      	mov	x15, x14
    377c:      	and	w8, w14, w22
    3780:      	tst	w8, #0x1
    3784:      	fcsel	s6, s2, s24, ne
    3788:      	stp	w13, w1, [sp, #0xc8]
    378c:      	and	w5, w13, w22
    3790:      	tst	w5, #0x1
    3794:      	fcsel	s7, s2, s24, ne
    3798:      	and	w6, w1, w22
    379c:      	tst	w6, #0x1
    37a0:      	fcsel	s16, s2, s24, ne
    37a4:      	str	w0, [sp, #0xe0]
    37a8:      	and	w9, w0, w22
    37ac:      	str	w9, [sp, #0x68]
    37b0:      	tst	w9, #0x1
    37b4:      	fcsel	s17, s2, s24, ne
    37b8:      	str	w17, [sp, #0xf0]
    37bc:      	str	w22, [sp, #0xc4]
    37c0:      	and	w9, w17, w22
    37c4:      	str	w9, [sp, #0x6c]
    37c8:      	tst	w9, #0x1
    37cc:      	fcsel	s2, s2, s24, ne
    37d0:      	mov.s	v3[1], v4[0]
    37d4:      	mov.s	v3[2], v5[0]
    37d8:      	mov.s	v3[3], v6[0]
    37dc:      	mov.s	v7[1], v16[0]
    37e0:      	mov.s	v7[2], v17[0]
    37e4:      	mov.s	v7[3], v2[0]
    37e8:      	ldr	w9, [sp, #0x3e0]
    37ec:      	rbit	w9, w9
    37f0:      	clz	w12, w9
    37f4:      	str	q7, [sp, #0x710]
    37f8:      	str	q3, [sp, #0x700]
    37fc:      	and	x9, x12, #0x7
    3800:      	add	x16, sp, #0x700
    3804:      	ldr	s2, [x16, x9, lsl #2]
    3808:      	mov	w9, #-0x800000          ; =-8388608
    380c:      	fmov	s3, w9
    3810:      	fmaxnm	s2, s2, s3
    3814:      	ldr	x9, [sp, #0x2f0]
    3818:      	add	x9, x27, x9
    381c:      	ldp	q4, q3, [x9]
    3820:      	dup.4s	v18, v2[0]
    3824:      	fsub.4s	v2, v4, v18
    3828:      	fsub.4s	v3, v3, v18
    382c:      	and.16b	v4, v0, v3
    3830:      	and.16b	v2, v1, v2
    3834:      	mov	w9, #-0x3d300000        ; =-1026555904
    3838:      	dup.4s	v12, w9
    383c:      	fcmge.4s	v3, v2, v12
    3840:      	fcmge.4s	v5, v4, v12
    3844:      	mov	w9, #0x42c80000         ; =1120403456
    3848:      	dup.4s	v13, w9
    384c:      	fcmge.4s	v6, v13, v2
    3850:      	fcmge.4s	v7, v13, v4
    3854:      	and.16b	v5, v5, v7
    3858:      	and.16b	v3, v3, v6
    385c:      	and.16b	v3, v3, v2
    3860:      	and.16b	v5, v5, v4
    3864:      	mov	w9, #0xaa3b             ; =43579
    3868:      	movk	w9, #0x3fb8, lsl #16
    386c:      	dup.4s	v7, w9
    3870:      	fmul.4s	v6, v5, v7
    3874:      	str	q7, [sp, #0x3e0]
    3878:      	fmul.4s	v7, v3, v7
    387c:      	movi.4s	v17, #0x4b, lsl #24
    3880:      	mvni.4s	v19, #0x80, lsl #24
    3884:      	mov.16b	v16, v19
    3888:      	bsl.16b	v16, v17, v7
    388c:      	bif.16b	v17, v6, v19
    3890:      	fadd.4s	v6, v6, v17
    3894:      	fadd.4s	v7, v7, v16
    3898:      	fsub.4s	v7, v7, v16
    389c:      	fsub.4s	v6, v6, v17
    38a0:      	fcvtzs.4s	v19, v6
    38a4:      	fcvtzs.4s	v21, v7
    38a8:      	scvtf.4s	v6, v21
    38ac:      	scvtf.4s	v7, v19
    38b0:      	mov	w9, #0x7200             ; =29184
    38b4:      	movk	w9, #0xbf31, lsl #16
    38b8:      	dup.4s	v17, w9
    38bc:      	fmul.4s	v16, v7, v17
    38c0:      	str	q17, [sp, #0x3d0]
    38c4:      	fmul.4s	v17, v6, v17
    38c8:      	fadd.4s	v3, v3, v17
    38cc:      	fadd.4s	v5, v5, v16
    38d0:      	mov	w9, #0xbe8e             ; =48782
    38d4:      	movk	w9, #0xb5bf, lsl #16
    38d8:      	dup.4s	v16, w9
    38dc:      	fmul.4s	v6, v6, v16
    38e0:      	str	q16, [sp, #0x2f0]
    38e4:      	fmul.4s	v7, v7, v16
    38e8:      	fadd.4s	v22, v5, v7
    38ec:      	fadd.4s	v3, v3, v6
    38f0:      	mov	w9, #0x2bda             ; =11226
    38f4:      	movk	w9, #0x3950, lsl #16
    38f8:      	dup.4s	v5, w9
    38fc:      	fmul.4s	v7, v3, v5
    3900:      	str	q5, [sp, #0x3c0]
    3904:      	fmul.4s	v16, v22, v5
    3908:      	mov	w9, #0x96c9             ; =38601
    390c:      	movk	w9, #0x3ab6, lsl #16
    3910:      	dup.4s	v5, w9
    3914:      	fadd.4s	v16, v16, v5
    3918:      	str	q5, [sp, #0x3b0]
    391c:      	fadd.4s	v7, v7, v5
    3920:      	fmul.4s	v17, v3, v7
    3924:      	fmul.4s	v16, v22, v16
    3928:      	mov	w9, #0x88a6             ; =34982
    392c:      	movk	w9, #0x3c08, lsl #16
    3930:      	dup.4s	v5, w9
    3934:      	fadd.4s	v16, v16, v5
    3938:      	str	q5, [sp, #0x3a0]
    393c:      	fadd.4s	v17, v17, v5
    3940:      	fmul.4s	v17, v3, v17
    3944:      	fmul.4s	v23, v22, v16
    3948:      	mov	w9, #0xaa7a             ; =43642
    394c:      	movk	w9, #0x3d2a, lsl #16
    3950:      	dup.4s	v5, w9
    3954:      	fadd.4s	v23, v23, v5
    3958:      	str	q5, [sp, #0x390]
    395c:      	fadd.4s	v17, v17, v5
    3960:      	fmul.4s	v24, v3, v17
    3964:      	fmul.4s	v23, v22, v23
    3968:      	mov	w9, #0xaaab             ; =43691
    396c:      	movk	w9, #0x3e2a, lsl #16
    3970:      	dup.4s	v5, w9
    3974:      	fadd.4s	v23, v23, v5
    3978:      	str	q5, [sp, #0x380]
    397c:      	fadd.4s	v24, v24, v5
    3980:      	fmul.4s	v24, v3, v24
    3984:      	fmul.4s	v23, v22, v23
    3988:      	movi.4s	v5, #0x3f, lsl #24
    398c:      	fadd.4s	v23, v23, v5
    3990:      	fadd.4s	v24, v24, v5
    3994:      	fmul.4s	v25, v22, v22
    3998:      	fmul.4s	v26, v3, v3
    399c:      	fmul.4s	v24, v26, v24
    39a0:      	fmul.4s	v23, v25, v23
    39a4:      	fadd.4s	v22, v22, v23
    39a8:      	fadd.4s	v3, v3, v24
    39ac:      	fmov.4s	v14, #1.00000000
    39b0:      	fadd.4s	v3, v3, v14
    39b4:      	fadd.4s	v22, v22, v14
    39b8:      	sshr.4s	v23, v21, #0x1
    39bc:      	sshr.4s	v24, v19, #0x1
    39c0:      	shl.4s	v25, v24, #0x17
    39c4:      	add.4s	v25, v25, v14
    39c8:      	fmul.4s	v22, v22, v25
    39cc:      	shl.4s	v25, v23, #0x17
    39d0:      	add.4s	v25, v25, v14
    39d4:      	fmul.4s	v3, v3, v25
    39d8:      	sub.4s	v19, v19, v24
    39dc:      	sub.4s	v21, v21, v23
    39e0:      	shl.4s	v21, v21, #0x17
    39e4:      	add.4s	v21, v21, v14
    39e8:      	fmul.4s	v3, v3, v21
    39ec:      	shl.4s	v19, v19, #0x17
    39f0:      	add.4s	v19, v19, v14
    39f4:      	fmul.4s	v19, v22, v19
    39f8:      	fcmgt.4s	v21, v12, v4
    39fc:      	bic.16b	v19, v19, v21
    3a00:      	fcmgt.4s	v21, v12, v2
    3a04:      	bic.16b	v3, v3, v21
    3a08:      	fcmgt.4s	v21, v2, v13
    3a0c:      	ldr	q8, [sp, #0x2e0]
    3a10:      	bit.16b	v3, v8, v21
    3a14:      	fcmgt.4s	v21, v4, v13
    3a18:      	bit.16b	v19, v8, v21
    3a1c:      	fcmeq.4s	v4, v4, v4
    3a20:      	ldr	q5, [sp, #0x3f0]
    3a24:      	bsl.16b	v4, v19, v5
    3a28:      	fcmeq.4s	v2, v2, v2
    3a2c:      	bsl.16b	v2, v3, v5
    3a30:      	ldr	q3, [sp, #0x40]
    3a34:      	sshll.4s	v3, v3, #0x0
    3a38:      	bic.16b	v29, v2, v3
    3a3c:      	ldr	q2, [sp, #0x50]
    3a40:      	bic.16b	v30, v4, v2
    3a44:      	ldp	q2, q3, [x23]
    3a48:      	bit.16b	v3, v30, v0
    3a4c:      	bit.16b	v2, v29, v1
    3a50:      	stp	q2, q3, [x23]
    3a54:      	fmov	w9, s11
    3a58:      	ldr	q2, [sp, #0x430]
    3a5c:      	add.2d	v2, v2, v31
    3a60:      	tbz	w9, #0x0, 0x3aa0 <_llm_rows.packet_batch.blocks+0x1eb8>
    3a64:      	fmov	x16, d2
    3a68:      	ldr	b19, [x16]
    3a6c:      	b	0x3aa4 <_llm_rows.packet_batch.blocks+0x1ebc>
    3a70:      	fmov	x9, d18
    3a74:      	ld1.b	{ v2 }[2], [x9]
    3a78:      	tbz	w15, #0x3, 0x31dc <_llm_rows.packet_batch.blocks+0x15f4>
    3a7c:      	ld1.b	{ v2 }[3], [x13]
    3a80:      	tbz	w15, #0x4, 0x31e0 <_llm_rows.packet_batch.blocks+0x15f8>
    3a84:      	ldr	q3, [sp, #0xe0]
    3a88:      	fmov	x9, d3
    3a8c:      	ld1.b	{ v2 }[4], [x9]
    3a90:      	tbz	w15, #0x5, 0x31e4 <_llm_rows.packet_batch.blocks+0x15fc>
    3a94:      	ld1.b	{ v2 }[5], [x11]
    3a98:      	tbnz	w15, #0x6, 0x31e8 <_llm_rows.packet_batch.blocks+0x1600>
    3a9c:      	b	0x31f4 <_llm_rows.packet_batch.blocks+0x160c>
    3aa0:      	movi.2d	v19, #0000000000000000
    3aa4:      	ldp	q17, q3, [sp, #0x2f0]
    3aa8:      	ldr	q16, [sp, #0x100]
    3aac:      	ldr	w22, [sp, #0xc0]
    3ab0:      	and	w3, w9, #0xff
    3ab4:      	movi.4s	v5, #0x4b, lsl #24
    3ab8:      	mvni.4s	v6, #0x80, lsl #24
    3abc:      	mov	w19, #0x4               ; =4
    3ac0:      	tbnz	w3, #0x1, 0x3d2c <_llm_rows.packet_batch.blocks+0x2144>
    3ac4:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1418>
    3ac8:      	ldr	q2, [x9]
    3acc:      	and.16b	v2, v3, v2
    3ad0:      	ldr	q3, [sp, #0x450]
    3ad4:      	add.2d	v2, v3, v2
    3ad8:      	tbnz	w3, #0x2, 0x3d4c <_llm_rows.packet_batch.blocks+0x2164>
    3adc:      	tbz	w3, #0x3, 0x3ae8 <_llm_rows.packet_batch.blocks+0x1f00>
    3ae0:      	mov.d	x9, v2[1]
    3ae4:      	ld1.b	{ v19 }[3], [x9]
    3ae8:      	sshll.2d	v4, v0, #0x0
    3aec:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1418>
    3af0:      	ldr	q2, [x9]
    3af4:      	and.16b	v2, v4, v2
    3af8:      	ldr	q3, [sp, #0x440]
    3afc:      	add.2d	v2, v3, v2
    3b00:      	tbnz	w3, #0x4, 0x3d5c <_llm_rows.packet_batch.blocks+0x2174>
    3b04:      	tbnz	w3, #0x5, 0x3d68 <_llm_rows.packet_batch.blocks+0x2180>
    3b08:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1418>
    3b0c:      	ldr	q2, [x9]
    3b10:      	and.16b	v2, v9, v2
    3b14:      	ldr	q3, [sp, #0x370]
    3b18:      	add.2d	v2, v3, v2
    3b1c:      	tbnz	w3, #0x6, 0x3d88 <_llm_rows.packet_batch.blocks+0x21a0>
    3b20:      	tbz	w3, #0x7, 0x3b2c <_llm_rows.packet_batch.blocks+0x1f44>
    3b24:      	mov.d	x9, v2[1]
    3b28:      	ld1.b	{ v19 }[7], [x9]
    3b2c:      	mov	w9, #0x20               ; =32
    3b30:      	fmov	d2, x9
    3b34:      	and.16b	v2, v10, v2
    3b38:      	fmov	x9, d2
    3b3c:      	add	x9, x27, x9
    3b40:      	ldp	q3, q2, [x9]
    3b44:      	fsub.4s	v21, v3, v18
    3b48:      	fsub.4s	v2, v2, v18
    3b4c:      	and.16b	v3, v0, v2
    3b50:      	and.16b	v2, v1, v21
    3b54:      	fcmge.4s	v21, v2, v12
    3b58:      	fcmge.4s	v22, v3, v12
    3b5c:      	fcmge.4s	v23, v13, v2
    3b60:      	fcmge.4s	v24, v13, v3
    3b64:      	and.16b	v22, v22, v24
    3b68:      	and.16b	v21, v21, v23
    3b6c:      	and.16b	v21, v21, v2
    3b70:      	and.16b	v22, v22, v3
    3b74:      	ldr	q7, [sp, #0x3e0]
    3b78:      	fmul.4s	v23, v22, v7
    3b7c:      	fmul.4s	v24, v21, v7
    3b80:      	mov.16b	v25, v6
    3b84:      	bsl.16b	v25, v5, v24
    3b88:      	mov.16b	v26, v6
    3b8c:      	bsl.16b	v26, v5, v23
    3b90:      	fadd.4s	v23, v23, v26
    3b94:      	fadd.4s	v24, v24, v25
    3b98:      	fsub.4s	v24, v24, v25
    3b9c:      	fsub.4s	v23, v23, v26
    3ba0:      	fcvtzs.4s	v23, v23
    3ba4:      	fcvtzs.4s	v24, v24
    3ba8:      	scvtf.4s	v25, v24
    3bac:      	scvtf.4s	v26, v23
    3bb0:      	ldr	q7, [sp, #0x3d0]
    3bb4:      	fmul.4s	v27, v25, v7
    3bb8:      	fadd.4s	v21, v21, v27
    3bbc:      	fmul.4s	v27, v26, v7
    3bc0:      	fadd.4s	v22, v22, v27
    3bc4:      	fmul.4s	v25, v25, v17
    3bc8:      	fmul.4s	v26, v26, v17
    3bcc:      	fadd.4s	v22, v22, v26
    3bd0:      	fadd.4s	v21, v21, v25
    3bd4:      	ldr	q7, [sp, #0x3c0]
    3bd8:      	fmul.4s	v25, v21, v7
    3bdc:      	fmul.4s	v26, v22, v7
    3be0:      	ldr	q7, [sp, #0x3b0]
    3be4:      	fadd.4s	v26, v26, v7
    3be8:      	fadd.4s	v25, v25, v7
    3bec:      	fmul.4s	v25, v21, v25
    3bf0:      	fmul.4s	v26, v22, v26
    3bf4:      	ldr	q7, [sp, #0x3a0]
    3bf8:      	fadd.4s	v26, v26, v7
    3bfc:      	fadd.4s	v25, v25, v7
    3c00:      	fmul.4s	v25, v21, v25
    3c04:      	fmul.4s	v26, v22, v26
    3c08:      	ldr	q7, [sp, #0x390]
    3c0c:      	fadd.4s	v26, v26, v7
    3c10:      	fadd.4s	v25, v25, v7
    3c14:      	fmul.4s	v25, v21, v25
    3c18:      	fmul.4s	v26, v22, v26
    3c1c:      	ldr	q7, [sp, #0x380]
    3c20:      	fadd.4s	v26, v26, v7
    3c24:      	fadd.4s	v25, v25, v7
    3c28:      	fmul.4s	v25, v21, v25
    3c2c:      	fmul.4s	v26, v22, v26
    3c30:      	movi.4s	v7, #0x3f, lsl #24
    3c34:      	fadd.4s	v26, v26, v7
    3c38:      	fadd.4s	v25, v25, v7
    3c3c:      	fmul.4s	v27, v21, v21
    3c40:      	fmul.4s	v25, v27, v25
    3c44:      	fmul.4s	v27, v22, v22
    3c48:      	fmul.4s	v26, v27, v26
    3c4c:      	fadd.4s	v22, v22, v26
    3c50:      	fadd.4s	v21, v21, v25
    3c54:      	fadd.4s	v21, v21, v14
    3c58:      	fadd.4s	v22, v22, v14
    3c5c:      	sshr.4s	v25, v24, #0x1
    3c60:      	sshr.4s	v26, v23, #0x1
    3c64:      	shl.4s	v27, v26, #0x17
    3c68:      	add.4s	v27, v27, v14
    3c6c:      	fmul.4s	v22, v22, v27
    3c70:      	shl.4s	v27, v25, #0x17
    3c74:      	add.4s	v27, v27, v14
    3c78:      	fmul.4s	v21, v21, v27
    3c7c:      	sub.4s	v23, v23, v26
    3c80:      	sub.4s	v24, v24, v25
    3c84:      	shl.4s	v24, v24, #0x17
    3c88:      	add.4s	v24, v24, v14
    3c8c:      	fmul.4s	v21, v21, v24
    3c90:      	shl.4s	v23, v23, #0x17
    3c94:      	add.4s	v23, v23, v14
    3c98:      	fmul.4s	v22, v22, v23
    3c9c:      	fcmgt.4s	v23, v12, v3
    3ca0:      	bic.16b	v22, v22, v23
    3ca4:      	fcmgt.4s	v23, v12, v2
    3ca8:      	bic.16b	v21, v21, v23
    3cac:      	fcmgt.4s	v23, v2, v13
    3cb0:      	bit.16b	v21, v8, v23
    3cb4:      	fcmgt.4s	v23, v3, v13
    3cb8:      	bit.16b	v22, v8, v23
    3cbc:      	fcmeq.4s	v3, v3, v3
    3cc0:      	ldr	q7, [sp, #0x3f0]
    3cc4:      	bsl.16b	v3, v22, v7
    3cc8:      	cmeq.8b	v19, v19, #0
    3ccc:      	sshll.8h	v19, v19, #0x0
    3cd0:      	fcmeq.4s	v2, v2, v2
    3cd4:      	bsl.16b	v2, v21, v7
    3cd8:      	sshll2.4s	v21, v19, #0x0
    3cdc:      	sshll.4s	v19, v19, #0x0
    3ce0:      	bic.16b	v28, v2, v19
    3ce4:      	bic.16b	v23, v3, v21
    3ce8:      	ldp	q2, q3, [x23, #0x20]
    3cec:      	bit.16b	v3, v23, v0
    3cf0:      	bit.16b	v2, v28, v1
    3cf4:      	stp	q2, q3, [x23, #0x20]
    3cf8:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1418>
    3cfc:      	ldr	q2, [x9]
    3d00:      	and.16b	v2, v10, v2
    3d04:      	fmov	w9, s11
    3d08:      	ldr	q3, [sp, #0x430]
    3d0c:      	add.2d	v2, v3, v2
    3d10:      	tbz	w9, #0x0, 0x3d98 <_llm_rows.packet_batch.blocks+0x21b0>
    3d14:      	fmov	x16, d2
    3d18:      	ldr	b19, [x16]
    3d1c:      	ldr	q3, [sp, #0x300]
    3d20:      	and	w3, w9, #0xff
    3d24:      	tbnz	w3, #0x1, 0x3da8 <_llm_rows.packet_batch.blocks+0x21c0>
    3d28:      	b	0x3db0 <_llm_rows.packet_batch.blocks+0x21c8>
    3d2c:      	mov.d	x9, v2[1]
    3d30:      	ld1.b	{ v19 }[1], [x9]
    3d34:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1418>
    3d38:      	ldr	q2, [x9]
    3d3c:      	and.16b	v2, v3, v2
    3d40:      	ldr	q3, [sp, #0x450]
    3d44:      	add.2d	v2, v3, v2
    3d48:      	tbz	w3, #0x2, 0x3adc <_llm_rows.packet_batch.blocks+0x1ef4>
    3d4c:      	fmov	x9, d2
    3d50:      	ld1.b	{ v19 }[2], [x9]
    3d54:      	tbnz	w3, #0x3, 0x3ae0 <_llm_rows.packet_batch.blocks+0x1ef8>
    3d58:      	b	0x3ae8 <_llm_rows.packet_batch.blocks+0x1f00>
    3d5c:      	fmov	x9, d2
    3d60:      	ld1.b	{ v19 }[4], [x9]
    3d64:      	tbz	w3, #0x5, 0x3b08 <_llm_rows.packet_batch.blocks+0x1f20>
    3d68:      	mov.d	x9, v2[1]
    3d6c:      	ld1.b	{ v19 }[5], [x9]
    3d70:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1418>
    3d74:      	ldr	q2, [x9]
    3d78:      	and.16b	v2, v9, v2
    3d7c:      	ldr	q3, [sp, #0x370]
    3d80:      	add.2d	v2, v3, v2
    3d84:      	tbz	w3, #0x6, 0x3b20 <_llm_rows.packet_batch.blocks+0x1f38>
    3d88:      	fmov	x9, d2
    3d8c:      	ld1.b	{ v19 }[6], [x9]
    3d90:      	tbnz	w3, #0x7, 0x3b24 <_llm_rows.packet_batch.blocks+0x1f3c>
    3d94:      	b	0x3b2c <_llm_rows.packet_batch.blocks+0x1f44>
    3d98:      	movi.2d	v19, #0000000000000000
    3d9c:      	ldr	q3, [sp, #0x300]
    3da0:      	and	w3, w9, #0xff
    3da4:      	tbz	w3, #0x1, 0x3db0 <_llm_rows.packet_batch.blocks+0x21c8>
    3da8:      	mov.d	x9, v2[1]
    3dac:      	ld1.b	{ v19 }[1], [x9]
    3db0:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1418>
    3db4:      	ldr	q2, [x9]
    3db8:      	and.16b	v2, v3, v2
    3dbc:      	ldr	q3, [sp, #0x450]
    3dc0:      	add.2d	v2, v3, v2
    3dc4:      	tbnz	w3, #0x2, 0x400c <_llm_rows.packet_batch.blocks+0x2424>
    3dc8:      	tbnz	w3, #0x3, 0x4018 <_llm_rows.packet_batch.blocks+0x2430>
    3dcc:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1418>
    3dd0:      	ldr	q2, [x9]
    3dd4:      	and.16b	v2, v4, v2
    3dd8:      	ldr	q3, [sp, #0x440]
    3ddc:      	add.2d	v2, v3, v2
    3de0:      	tbnz	w3, #0x4, 0x4038 <_llm_rows.packet_batch.blocks+0x2450>
    3de4:      	tbnz	w3, #0x5, 0x4044 <_llm_rows.packet_batch.blocks+0x245c>
    3de8:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1418>
    3dec:      	ldr	q2, [x9]
    3df0:      	and.16b	v2, v9, v2
    3df4:      	ldr	q3, [sp, #0x370]
    3df8:      	add.2d	v2, v3, v2
    3dfc:      	tbnz	w3, #0x6, 0x4064 <_llm_rows.packet_batch.blocks+0x247c>
    3e00:      	tbz	w3, #0x7, 0x3e0c <_llm_rows.packet_batch.blocks+0x2224>
    3e04:      	mov.d	x9, v2[1]
    3e08:      	ld1.b	{ v19 }[7], [x9]
    3e0c:      	mov	w9, #0x40               ; =64
    3e10:      	fmov	d2, x9
    3e14:      	and.16b	v2, v10, v2
    3e18:      	fmov	x9, d2
    3e1c:      	add	x9, x27, x9
    3e20:      	ldp	q3, q2, [x9]
    3e24:      	fsub.4s	v21, v3, v18
    3e28:      	fsub.4s	v2, v2, v18
    3e2c:      	and.16b	v3, v0, v2
    3e30:      	and.16b	v2, v1, v21
    3e34:      	fcmge.4s	v21, v2, v12
    3e38:      	fcmge.4s	v22, v3, v12
    3e3c:      	fcmge.4s	v24, v13, v2
    3e40:      	fcmge.4s	v25, v13, v3
    3e44:      	and.16b	v22, v22, v25
    3e48:      	and.16b	v21, v21, v24
    3e4c:      	and.16b	v21, v21, v2
    3e50:      	and.16b	v22, v22, v3
    3e54:      	ldr	q7, [sp, #0x3e0]
    3e58:      	fmul.4s	v24, v22, v7
    3e5c:      	fmul.4s	v25, v21, v7
    3e60:      	mov.16b	v26, v6
    3e64:      	bsl.16b	v26, v5, v25
    3e68:      	mov.16b	v27, v6
    3e6c:      	bsl.16b	v27, v5, v24
    3e70:      	fadd.4s	v24, v24, v27
    3e74:      	fadd.4s	v25, v25, v26
    3e78:      	fsub.4s	v25, v25, v26
    3e7c:      	fsub.4s	v24, v24, v27
    3e80:      	fcvtzs.4s	v24, v24
    3e84:      	fcvtzs.4s	v25, v25
    3e88:      	scvtf.4s	v26, v25
    3e8c:      	scvtf.4s	v27, v24
    3e90:      	ldr	q7, [sp, #0x3d0]
    3e94:      	fmul.4s	v31, v26, v7
    3e98:      	fadd.4s	v21, v21, v31
    3e9c:      	fmul.4s	v31, v27, v7
    3ea0:      	fadd.4s	v22, v22, v31
    3ea4:      	fmul.4s	v26, v26, v17
    3ea8:      	fmul.4s	v27, v27, v17
    3eac:      	fadd.4s	v22, v22, v27
    3eb0:      	fadd.4s	v21, v21, v26
    3eb4:      	ldr	q7, [sp, #0x3c0]
    3eb8:      	fmul.4s	v26, v21, v7
    3ebc:      	fmul.4s	v27, v22, v7
    3ec0:      	ldr	q7, [sp, #0x3b0]
    3ec4:      	fadd.4s	v27, v27, v7
    3ec8:      	fadd.4s	v26, v26, v7
    3ecc:      	fmul.4s	v26, v21, v26
    3ed0:      	fmul.4s	v27, v22, v27
    3ed4:      	ldr	q7, [sp, #0x3a0]
    3ed8:      	fadd.4s	v27, v27, v7
    3edc:      	fadd.4s	v26, v26, v7
    3ee0:      	fmul.4s	v26, v21, v26
    3ee4:      	fmul.4s	v27, v22, v27
    3ee8:      	ldr	q7, [sp, #0x390]
    3eec:      	fadd.4s	v27, v27, v7
    3ef0:      	fadd.4s	v26, v26, v7
    3ef4:      	fmul.4s	v26, v21, v26
    3ef8:      	fmul.4s	v27, v22, v27
    3efc:      	ldr	q7, [sp, #0x380]
    3f00:      	fadd.4s	v27, v27, v7
    3f04:      	fadd.4s	v26, v26, v7
    3f08:      	fmul.4s	v26, v21, v26
    3f0c:      	fmul.4s	v27, v22, v27
    3f10:      	movi.4s	v7, #0x3f, lsl #24
    3f14:      	fadd.4s	v27, v27, v7
    3f18:      	fadd.4s	v26, v26, v7
    3f1c:      	fmul.4s	v31, v21, v21
    3f20:      	fmul.4s	v26, v31, v26
    3f24:      	fmul.4s	v31, v22, v22
    3f28:      	fmul.4s	v27, v31, v27
    3f2c:      	fadd.4s	v22, v22, v27
    3f30:      	fadd.4s	v21, v21, v26
    3f34:      	fadd.4s	v21, v21, v14
    3f38:      	fadd.4s	v22, v22, v14
    3f3c:      	sshr.4s	v26, v25, #0x1
    3f40:      	sshr.4s	v27, v24, #0x1
    3f44:      	shl.4s	v31, v27, #0x17
    3f48:      	add.4s	v31, v31, v14
    3f4c:      	fmul.4s	v22, v22, v31
    3f50:      	shl.4s	v31, v26, #0x17
    3f54:      	add.4s	v31, v31, v14
    3f58:      	fmul.4s	v21, v21, v31
    3f5c:      	sub.4s	v24, v24, v27
    3f60:      	sub.4s	v25, v25, v26
    3f64:      	shl.4s	v25, v25, #0x17
    3f68:      	add.4s	v25, v25, v14
    3f6c:      	fmul.4s	v21, v21, v25
    3f70:      	shl.4s	v24, v24, #0x17
    3f74:      	add.4s	v24, v24, v14
    3f78:      	fmul.4s	v22, v22, v24
    3f7c:      	fcmgt.4s	v24, v12, v3
    3f80:      	bic.16b	v22, v22, v24
    3f84:      	fcmgt.4s	v24, v12, v2
    3f88:      	bic.16b	v21, v21, v24
    3f8c:      	fcmgt.4s	v24, v2, v13
    3f90:      	bit.16b	v21, v8, v24
    3f94:      	fcmgt.4s	v24, v3, v13
    3f98:      	bit.16b	v22, v8, v24
    3f9c:      	fcmeq.4s	v3, v3, v3
    3fa0:      	ldr	q7, [sp, #0x3f0]
    3fa4:      	bsl.16b	v3, v22, v7
    3fa8:      	cmeq.8b	v19, v19, #0
    3fac:      	sshll.8h	v19, v19, #0x0
    3fb0:      	fcmeq.4s	v2, v2, v2
    3fb4:      	bsl.16b	v2, v21, v7
    3fb8:      	sshll2.4s	v21, v19, #0x0
    3fbc:      	sshll.4s	v19, v19, #0x0
    3fc0:      	bic.16b	v24, v2, v19
    3fc4:      	bic.16b	v22, v3, v21
    3fc8:      	ldp	q2, q3, [x23, #0x40]
    3fcc:      	bit.16b	v3, v22, v0
    3fd0:      	bit.16b	v2, v24, v1
    3fd4:      	stp	q2, q3, [x23, #0x40]
    3fd8:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1418>
    3fdc:      	ldr	q2, [x9]
    3fe0:      	and.16b	v2, v10, v2
    3fe4:      	fmov	w9, s11
    3fe8:      	ldr	q3, [sp, #0x430]
    3fec:      	add.2d	v2, v3, v2
    3ff0:      	tbz	w9, #0x0, 0x4074 <_llm_rows.packet_batch.blocks+0x248c>
    3ff4:      	fmov	x16, d2
    3ff8:      	ldr	b19, [x16]
    3ffc:      	ldr	q3, [sp, #0x300]
    4000:      	and	w3, w9, #0xff
    4004:      	tbnz	w3, #0x1, 0x4084 <_llm_rows.packet_batch.blocks+0x249c>
    4008:      	b	0x408c <_llm_rows.packet_batch.blocks+0x24a4>
    400c:      	fmov	x9, d2
    4010:      	ld1.b	{ v19 }[2], [x9]
    4014:      	tbz	w3, #0x3, 0x3dcc <_llm_rows.packet_batch.blocks+0x21e4>
    4018:      	mov.d	x9, v2[1]
    401c:      	ld1.b	{ v19 }[3], [x9]
    4020:      	adrp	x9, 0x4000 <_llm_rows.packet_batch.blocks+0x2418>
    4024:      	ldr	q2, [x9]
    4028:      	and.16b	v2, v4, v2
    402c:      	ldr	q3, [sp, #0x440]
    4030:      	add.2d	v2, v3, v2
    4034:      	tbz	w3, #0x4, 0x3de4 <_llm_rows.packet_batch.blocks+0x21fc>
    4038:      	fmov	x9, d2
    403c:      	ld1.b	{ v19 }[4], [x9]
    4040:      	tbz	w3, #0x5, 0x3de8 <_llm_rows.packet_batch.blocks+0x2200>
    4044:      	mov.d	x9, v2[1]
    4048:      	ld1.b	{ v19 }[5], [x9]
    404c:      	adrp	x9, 0x4000 <_llm_rows.packet_batch.blocks+0x2418>
    4050:      	ldr	q2, [x9]
    4054:      	and.16b	v2, v9, v2
    4058:      	ldr	q3, [sp, #0x370]
    405c:      	add.2d	v2, v3, v2
    4060:      	tbz	w3, #0x6, 0x3e00 <_llm_rows.packet_batch.blocks+0x2218>
    4064:      	fmov	x9, d2
    4068:      	ld1.b	{ v19 }[6], [x9]
    406c:      	tbnz	w3, #0x7, 0x3e04 <_llm_rows.packet_batch.blocks+0x221c>
    4070:      	b	0x3e0c <_llm_rows.packet_batch.blocks+0x2224>
    4074:      	movi.2d	v19, #0000000000000000
    4078:      	ldr	q3, [sp, #0x300]
    407c:      	and	w3, w9, #0xff
    4080:      	tbz	w3, #0x1, 0x408c <_llm_rows.packet_batch.blocks+0x24a4>
    4084:      	mov.d	x9, v2[1]
    4088:      	ld1.b	{ v19 }[1], [x9]
    408c:      	adrp	x9, 0x4000 <_llm_rows.packet_batch.blocks+0x2418>
    4090:      	ldr	q2, [x9]
    4094:      	and.16b	v2, v3, v2
    4098:      	ldr	q3, [sp, #0x450]
    409c:      	add.2d	v2, v3, v2
    40a0:      	tbnz	w3, #0x2, 0x5674 <_llm_rows.packet_batch.blocks+0x3a8c>
    40a4:      	tbnz	w3, #0x3, 0x5680 <_llm_rows.packet_batch.blocks+0x3a98>
    40a8:      	adrp	x9, 0x4000 <_llm_rows.packet_batch.blocks+0x2418>
    40ac:      	ldr	q2, [x9]
    40b0:      	and.16b	v2, v4, v2
    40b4:      	ldr	q3, [sp, #0x440]
    40b8:      	add.2d	v2, v3, v2
    40bc:      	tbnz	w3, #0x4, 0x56a0 <_llm_rows.packet_batch.blocks+0x3ab8>
    40c0:      	tbnz	w3, #0x5, 0x56ac <_llm_rows.packet_batch.blocks+0x3ac4>
    40c4:      	adrp	x9, 0x4000 <_llm_rows.packet_batch.blocks+0x2418>
    40c8:      	ldr	q2, [x9]
    40cc:      	and.16b	v2, v9, v2
    40d0:      	ldr	q3, [sp, #0x370]
    40d4:      	add.2d	v3, v3, v2
    40d8:      	tbnz	w3, #0x6, 0x56cc <_llm_rows.packet_batch.blocks+0x3ae4>
    40dc:      	ldr	q2, [sp, #0x10]
    40e0:      	and.16b	v2, v10, v2
    40e4:      	tbz	w3, #0x7, 0x40f0 <_llm_rows.packet_batch.blocks+0x2508>
    40e8:      	mov.d	x9, v3[1]
    40ec:      	ld1.b	{ v19 }[7], [x9]
    40f0:      	fmov	x9, d2
    40f4:      	add	x9, x27, x9
    40f8:      	ldp	q3, q2, [x9]
    40fc:      	fsub.4s	v4, v3, v18
    4100:      	fsub.4s	v2, v2, v18
    4104:      	and.16b	v3, v0, v2
    4108:      	and.16b	v2, v1, v4
    410c:      	fcmge.4s	v4, v2, v12
    4110:      	fcmge.4s	v21, v3, v12
    4114:      	fcmge.4s	v25, v13, v2
    4118:      	fcmge.4s	v26, v13, v3
    411c:      	and.16b	v21, v21, v26
    4120:      	and.16b	v4, v4, v25
    4124:      	and.16b	v4, v4, v2
    4128:      	and.16b	v21, v21, v3
    412c:      	ldr	q7, [sp, #0x3e0]
    4130:      	fmul.4s	v25, v21, v7
    4134:      	fmul.4s	v26, v4, v7
    4138:      	mov.16b	v27, v6
    413c:      	bsl.16b	v27, v5, v26
    4140:      	mov.16b	v31, v6
    4144:      	bsl.16b	v31, v5, v25
    4148:      	fadd.4s	v25, v25, v31
    414c:      	fadd.4s	v26, v26, v27
    4150:      	fsub.4s	v26, v26, v27
    4154:      	fsub.4s	v25, v25, v31
    4158:      	fcvtzs.4s	v25, v25
    415c:      	fcvtzs.4s	v26, v26
    4160:      	scvtf.4s	v27, v26
    4164:      	scvtf.4s	v31, v25
    4168:      	ldp	q5, q6, [sp, #0x3c0]
    416c:      	fmul.4s	v9, v27, v6
    4170:      	fadd.4s	v4, v4, v9
    4174:      	fmul.4s	v9, v31, v6
    4178:      	fadd.4s	v21, v21, v9
    417c:      	fmul.4s	v27, v27, v17
    4180:      	fmul.4s	v31, v31, v17
    4184:      	fadd.4s	v21, v21, v31
    4188:      	fadd.4s	v4, v4, v27
    418c:      	fmul.4s	v27, v4, v5
    4190:      	fmul.4s	v31, v21, v5
    4194:      	ldp	q5, q6, [sp, #0x3a0]
    4198:      	fadd.4s	v31, v31, v6
    419c:      	fadd.4s	v27, v27, v6
    41a0:      	fmul.4s	v27, v4, v27
    41a4:      	fmul.4s	v31, v21, v31
    41a8:      	fadd.4s	v31, v31, v5
    41ac:      	fadd.4s	v27, v27, v5
    41b0:      	fmul.4s	v27, v4, v27
    41b4:      	fmul.4s	v31, v21, v31
    41b8:      	ldp	q5, q6, [sp, #0x380]
    41bc:      	fadd.4s	v31, v31, v6
    41c0:      	fadd.4s	v27, v27, v6
    41c4:      	fmul.4s	v27, v4, v27
    41c8:      	fmul.4s	v31, v21, v31
    41cc:      	fadd.4s	v31, v31, v5
    41d0:      	fadd.4s	v27, v27, v5
    41d4:      	fmul.4s	v27, v4, v27
    41d8:      	fmul.4s	v31, v21, v31
    41dc:      	movi.4s	v5, #0x3f, lsl #24
    41e0:      	fadd.4s	v31, v31, v5
    41e4:      	fadd.4s	v27, v27, v5
    41e8:      	fmul.4s	v9, v4, v4
    41ec:      	fmul.4s	v27, v9, v27
    41f0:      	fmul.4s	v9, v21, v21
    41f4:      	fmul.4s	v31, v9, v31
    41f8:      	fadd.4s	v21, v21, v31
    41fc:      	fadd.4s	v4, v4, v27
    4200:      	fadd.4s	v4, v4, v14
    4204:      	fadd.4s	v21, v21, v14
    4208:      	sshr.4s	v27, v26, #0x1
    420c:      	sshr.4s	v31, v25, #0x1
    4210:      	shl.4s	v9, v31, #0x17
    4214:      	add.4s	v9, v9, v14
    4218:      	fmul.4s	v21, v21, v9
    421c:      	shl.4s	v9, v27, #0x17
    4220:      	add.4s	v9, v9, v14
    4224:      	fmul.4s	v4, v4, v9
    4228:      	sub.4s	v25, v25, v31
    422c:      	sub.4s	v26, v26, v27
    4230:      	shl.4s	v26, v26, #0x17
    4234:      	add.4s	v26, v26, v14
    4238:      	fmul.4s	v4, v4, v26
    423c:      	shl.4s	v25, v25, #0x17
    4240:      	add.4s	v25, v25, v14
    4244:      	fmul.4s	v21, v21, v25
    4248:      	fcmgt.4s	v25, v12, v3
    424c:      	bic.16b	v21, v21, v25
    4250:      	fcmgt.4s	v25, v12, v2
    4254:      	bic.16b	v4, v4, v25
    4258:      	fcmgt.4s	v25, v2, v13
    425c:      	bit.16b	v4, v8, v25
    4260:      	fcmgt.4s	v25, v3, v13
    4264:      	bit.16b	v21, v8, v25
    4268:      	fcmeq.4s	v3, v3, v3
    426c:      	ldr	q5, [sp, #0x3f0]
    4270:      	bsl.16b	v3, v21, v5
    4274:      	cmeq.8b	v19, v19, #0
    4278:      	sshll.8h	v19, v19, #0x0
    427c:      	fcmeq.4s	v2, v2, v2
    4280:      	bsl.16b	v2, v4, v5
    4284:      	sshll2.4s	v4, v19, #0x0
    4288:      	sshll.4s	v19, v19, #0x0
    428c:      	bic.16b	v2, v2, v19
    4290:      	bic.16b	v3, v3, v4
    4294:      	ldp	q4, q19, [x23, #0x60]
    4298:      	bit.16b	v19, v3, v0
    429c:      	bit.16b	v4, v2, v1
    42a0:      	stp	q4, q19, [x23, #0x60]
    42a4:      	and.16b	v19, v0, v3
    42a8:      	and.16b	v21, v1, v2
    42ac:      	and.16b	v22, v0, v22
    42b0:      	and.16b	v4, v1, v24
    42b4:      	and.16b	v23, v0, v23
    42b8:      	and.16b	v28, v1, v28
    42bc:      	and.16b	v30, v0, v30
    42c0:      	and.16b	v29, v1, v29
    42c4:      	b	0x450c <_llm_rows.packet_batch.blocks+0x2924>
    42c8:      	add	x10, x10, #0x60
    42cc:      	add	x9, x27, x10
    42d0:      	ldp	q5, q3, [x9]
    42d4:      	fsub.4s	v5, v5, v18
    42d8:      	fsub.4s	v3, v3, v18
    42dc:      	and.16b	v31, v0, v3
    42e0:      	and.16b	v3, v1, v5
    42e4:      	fcmge.4s	v5, v3, v12
    42e8:      	fcmge.4s	v20, v31, v12
    42ec:      	fcmge.4s	v8, v13, v3
    42f0:      	fcmge.4s	v11, v13, v31
    42f4:      	and.16b	v20, v20, v11
    42f8:      	and.16b	v5, v5, v8
    42fc:      	and.16b	v5, v5, v3
    4300:      	and.16b	v20, v20, v31
    4304:      	ldp	q17, q11, [sp, #0x3d0]
    4308:      	fmul.4s	v8, v20, v11
    430c:      	fmul.4s	v11, v5, v11
    4310:      	mov.16b	v15, v7
    4314:      	bsl.16b	v15, v6, v11
    4318:      	bif.16b	v6, v8, v7
    431c:      	fadd.4s	v8, v8, v6
    4320:      	fadd.4s	v11, v11, v15
    4324:      	fsub.4s	v11, v11, v15
    4328:      	fsub.4s	v6, v8, v6
    432c:      	fcvtzs.4s	v6, v6
    4330:      	fcvtzs.4s	v8, v11
    4334:      	scvtf.4s	v11, v8
    4338:      	scvtf.4s	v15, v6
    433c:      	fmul.4s	v7, v11, v17
    4340:      	fadd.4s	v5, v5, v7
    4344:      	fmul.4s	v7, v15, v17
    4348:      	fadd.4s	v7, v20, v7
    434c:      	ldr	q17, [sp, #0x2f0]
    4350:      	fmul.4s	v20, v11, v17
    4354:      	fmul.4s	v11, v15, v17
    4358:      	fadd.4s	v7, v7, v11
    435c:      	fadd.4s	v5, v5, v20
    4360:      	ldp	q15, q11, [sp, #0x3b0]
    4364:      	fmul.4s	v20, v5, v11
    4368:      	fmul.4s	v11, v7, v11
    436c:      	fadd.4s	v11, v11, v15
    4370:      	fadd.4s	v20, v20, v15
    4374:      	fmul.4s	v20, v5, v20
    4378:      	fmul.4s	v11, v7, v11
    437c:      	ldr	q15, [sp, #0x3a0]
    4380:      	fadd.4s	v11, v11, v15
    4384:      	fadd.4s	v20, v20, v15
    4388:      	fmul.4s	v20, v5, v20
    438c:      	fmul.4s	v11, v7, v11
    4390:      	ldr	q15, [sp, #0x390]
    4394:      	fadd.4s	v11, v11, v15
    4398:      	fadd.4s	v20, v20, v15
    439c:      	fmul.4s	v20, v5, v20
    43a0:      	fmul.4s	v11, v7, v11
    43a4:      	ldr	q15, [sp, #0x380]
    43a8:      	fadd.4s	v11, v11, v15
    43ac:      	fadd.4s	v20, v20, v15
    43b0:      	fmul.4s	v20, v5, v20
    43b4:      	fmul.4s	v11, v7, v11
    43b8:      	movi.4s	v15, #0x3f, lsl #24
    43bc:      	fadd.4s	v11, v11, v15
    43c0:      	fadd.4s	v20, v20, v15
    43c4:      	fmul.4s	v15, v5, v5
    43c8:      	fmul.4s	v20, v15, v20
    43cc:      	fmul.4s	v15, v7, v7
    43d0:      	fmul.4s	v11, v15, v11
    43d4:      	fadd.4s	v7, v7, v11
    43d8:      	fadd.4s	v5, v5, v20
    43dc:      	fadd.4s	v5, v5, v14
    43e0:      	fadd.4s	v7, v7, v14
    43e4:      	sshr.4s	v20, v8, #0x1
    43e8:      	sshr.4s	v11, v6, #0x1
    43ec:      	shl.4s	v15, v11, #0x17
    43f0:      	add.4s	v15, v15, v14
    43f4:      	fmul.4s	v7, v7, v15
    43f8:      	shl.4s	v15, v20, #0x17
    43fc:      	add.4s	v15, v15, v14
    4400:      	fmul.4s	v5, v5, v15
    4404:      	sub.4s	v6, v6, v11
    4408:      	sub.4s	v20, v8, v20
    440c:      	shl.4s	v20, v20, #0x17
    4410:      	add.4s	v20, v20, v14
    4414:      	fmul.4s	v5, v5, v20
    4418:      	shl.4s	v6, v6, #0x17
    441c:      	add.4s	v6, v6, v14
    4420:      	fmul.4s	v6, v7, v6
    4424:      	fcmgt.4s	v7, v12, v31
    4428:      	bic.16b	v6, v6, v7
    442c:      	fcmgt.4s	v7, v12, v3
    4430:      	bic.16b	v5, v5, v7
    4434:      	fcmgt.4s	v7, v3, v13
    4438:      	ldr	q8, [sp, #0x2e0]
    443c:      	bit.16b	v5, v8, v7
    4440:      	fcmgt.4s	v7, v31, v13
    4444:      	bit.16b	v6, v8, v7
    4448:      	fcmeq.4s	v7, v31, v31
    444c:      	ldr	q20, [sp, #0x3f0]
    4450:      	bif.16b	v6, v20, v7
    4454:      	cmeq.8b	v7, v26, #0
    4458:      	sshll.8h	v7, v7, #0x0
    445c:      	fcmeq.4s	v3, v3, v3
    4460:      	bsl.16b	v3, v5, v20
    4464:      	sshll2.4s	v5, v7, #0x0
    4468:      	sshll.4s	v7, v7, #0x0
    446c:      	bic.16b	v3, v3, v7
    4470:      	bic.16b	v5, v6, v5
    4474:      	add	x9, x23, x10
    4478:      	ldp	q6, q7, [x9]
    447c:      	bit.16b	v7, v5, v0
    4480:      	bit.16b	v6, v3, v1
    4484:      	stp	q6, q7, [x9]
    4488:      	dup.2d	v6, x19
    448c:      	ldr	q7, [sp, #0x350]
    4490:      	and.16b	v7, v7, v6
    4494:      	ldr	q20, [sp, #0x420]
    4498:      	add.2d	v20, v20, v7
    449c:      	str	q20, [sp, #0x420]
    44a0:      	ldr	q7, [sp, #0x300]
    44a4:      	and.16b	v7, v7, v6
    44a8:      	ldr	q20, [sp, #0x410]
    44ac:      	add.2d	v20, v20, v7
    44b0:      	str	q20, [sp, #0x410]
    44b4:      	sshll.2d	v7, v0, #0x0
    44b8:      	and.16b	v7, v7, v6
    44bc:      	ldr	q20, [sp, #0x400]
    44c0:      	add.2d	v20, v20, v7
    44c4:      	str	q20, [sp, #0x400]
    44c8:      	sshll.2d	v7, v1, #0x0
    44cc:      	and.16b	v6, v7, v6
    44d0:      	add.2d	v16, v16, v6
    44d4:      	bit.16b	v23, v25, v0
    44d8:      	bit.16b	v28, v24, v1
    44dc:      	bit.16b	v22, v2, v0
    44e0:      	bit.16b	v4, v27, v1
    44e4:      	fadd.4s	v2, v19, v5
    44e8:      	bit.16b	v19, v2, v0
    44ec:      	fadd.4s	v2, v21, v3
    44f0:      	bit.16b	v21, v2, v1
    44f4:      	bit.16b	v30, v10, v0
    44f8:      	bit.16b	v29, v9, v1
    44fc:      	fmov	x10, d16
    4500:      	cmp	x10, #0x8
    4504:      	ldr	q11, [sp, #0x360]
    4508:      	b.ge	0x4ea8 <_llm_rows.packet_batch.blocks+0x32c0>
    450c:      	fmov	w9, s11
    4510:      	ldr	q2, [sp, #0x310]
    4514:      	add.2d	v2, v16, v2
    4518:      	ldr	q3, [sp, #0x430]
    451c:      	add.2d	v2, v3, v2
    4520:      	tbz	w9, #0x0, 0x4540 <_llm_rows.packet_batch.blocks+0x2958>
    4524:      	fmov	x16, d2
    4528:      	ldr	b24, [x16]
    452c:      	movi.4s	v6, #0x4b, lsl #24
    4530:      	mvni.4s	v7, #0x80, lsl #24
    4534:      	and	w3, w9, #0xff
    4538:      	tbnz	w3, #0x1, 0x4554 <_llm_rows.packet_batch.blocks+0x296c>
    453c:      	b	0x455c <_llm_rows.packet_batch.blocks+0x2974>
    4540:      	movi.2d	v24, #0000000000000000
    4544:      	movi.4s	v6, #0x4b, lsl #24
    4548:      	mvni.4s	v7, #0x80, lsl #24
    454c:      	and	w3, w9, #0xff
    4550:      	tbz	w3, #0x1, 0x455c <_llm_rows.packet_batch.blocks+0x2974>
    4554:      	mov.d	x9, v2[1]
    4558:      	ld1.b	{ v24 }[1], [x9]
    455c:      	ldr	q2, [sp, #0x330]
    4560:      	ldr	q3, [sp, #0x410]
    4564:      	add.2d	v2, v3, v2
    4568:      	ldr	q3, [sp, #0x450]
    456c:      	add.2d	v2, v3, v2
    4570:      	tbnz	w3, #0x2, 0x47ac <_llm_rows.packet_batch.blocks+0x2bc4>
    4574:      	tbnz	w3, #0x3, 0x47b8 <_llm_rows.packet_batch.blocks+0x2bd0>
    4578:      	ldr	q2, [sp, #0x320]
    457c:      	ldr	q3, [sp, #0x400]
    4580:      	add.2d	v2, v3, v2
    4584:      	ldr	q3, [sp, #0x440]
    4588:      	add.2d	v2, v3, v2
    458c:      	tbnz	w3, #0x4, 0x47d8 <_llm_rows.packet_batch.blocks+0x2bf0>
    4590:      	tbnz	w3, #0x5, 0x47e4 <_llm_rows.packet_batch.blocks+0x2bfc>
    4594:      	ldr	q2, [sp, #0x340]
    4598:      	ldr	q3, [sp, #0x420]
    459c:      	add.2d	v2, v3, v2
    45a0:      	ldr	q3, [sp, #0x370]
    45a4:      	add.2d	v2, v3, v2
    45a8:      	tbnz	w3, #0x6, 0x4804 <_llm_rows.packet_batch.blocks+0x2c1c>
    45ac:      	tbz	w3, #0x7, 0x45b8 <_llm_rows.packet_batch.blocks+0x29d0>
    45b0:      	mov.d	x9, v2[1]
    45b4:      	ld1.b	{ v24 }[7], [x9]
    45b8:      	lsl	x10, x10, #5
    45bc:      	add	x9, x27, x10
    45c0:      	ldp	q3, q2, [x9]
    45c4:      	fsub.4s	v25, v3, v18
    45c8:      	fsub.4s	v2, v2, v18
    45cc:      	and.16b	v3, v0, v2
    45d0:      	and.16b	v2, v1, v25
    45d4:      	fcmge.4s	v25, v2, v12
    45d8:      	fcmge.4s	v26, v3, v12
    45dc:      	fcmge.4s	v27, v13, v2
    45e0:      	fcmge.4s	v31, v13, v3
    45e4:      	and.16b	v26, v26, v31
    45e8:      	and.16b	v25, v25, v27
    45ec:      	and.16b	v25, v25, v2
    45f0:      	and.16b	v26, v26, v3
    45f4:      	ldr	q5, [sp, #0x3e0]
    45f8:      	fmul.4s	v27, v26, v5
    45fc:      	fmul.4s	v31, v25, v5
    4600:      	mov.16b	v9, v7
    4604:      	bsl.16b	v9, v6, v31
    4608:      	mov.16b	v10, v7
    460c:      	bsl.16b	v10, v6, v27
    4610:      	fadd.4s	v27, v27, v10
    4614:      	fadd.4s	v31, v31, v9
    4618:      	fsub.4s	v31, v31, v9
    461c:      	fsub.4s	v27, v27, v10
    4620:      	fcvtzs.4s	v27, v27
    4624:      	fcvtzs.4s	v31, v31
    4628:      	scvtf.4s	v9, v31
    462c:      	scvtf.4s	v10, v27
    4630:      	ldr	q5, [sp, #0x3d0]
    4634:      	fmul.4s	v11, v9, v5
    4638:      	fadd.4s	v25, v25, v11
    463c:      	fmul.4s	v11, v10, v5
    4640:      	fadd.4s	v26, v26, v11
    4644:      	fmul.4s	v9, v9, v17
    4648:      	fmul.4s	v10, v10, v17
    464c:      	fadd.4s	v26, v26, v10
    4650:      	fadd.4s	v25, v25, v9
    4654:      	ldr	q5, [sp, #0x3c0]
    4658:      	fmul.4s	v9, v25, v5
    465c:      	fmul.4s	v10, v26, v5
    4660:      	ldr	q5, [sp, #0x3b0]
    4664:      	fadd.4s	v10, v10, v5
    4668:      	fadd.4s	v9, v9, v5
    466c:      	fmul.4s	v9, v25, v9
    4670:      	fmul.4s	v10, v26, v10
    4674:      	ldr	q5, [sp, #0x3a0]
    4678:      	fadd.4s	v10, v10, v5
    467c:      	fadd.4s	v9, v9, v5
    4680:      	fmul.4s	v9, v25, v9
    4684:      	fmul.4s	v10, v26, v10
    4688:      	ldr	q5, [sp, #0x390]
    468c:      	fadd.4s	v10, v10, v5
    4690:      	fadd.4s	v9, v9, v5
    4694:      	fmul.4s	v9, v25, v9
    4698:      	fmul.4s	v10, v26, v10
    469c:      	ldr	q5, [sp, #0x380]
    46a0:      	fadd.4s	v10, v10, v5
    46a4:      	fadd.4s	v9, v9, v5
    46a8:      	fmul.4s	v9, v25, v9
    46ac:      	fmul.4s	v10, v26, v10
    46b0:      	movi.4s	v5, #0x3f, lsl #24
    46b4:      	fadd.4s	v10, v10, v5
    46b8:      	fadd.4s	v9, v9, v5
    46bc:      	fmul.4s	v11, v25, v25
    46c0:      	fmul.4s	v9, v11, v9
    46c4:      	fmul.4s	v11, v26, v26
    46c8:      	fmul.4s	v10, v11, v10
    46cc:      	fadd.4s	v26, v26, v10
    46d0:      	fadd.4s	v25, v25, v9
    46d4:      	fadd.4s	v25, v25, v14
    46d8:      	fadd.4s	v26, v26, v14
    46dc:      	sshr.4s	v9, v31, #0x1
    46e0:      	sshr.4s	v10, v27, #0x1
    46e4:      	shl.4s	v11, v10, #0x17
    46e8:      	add.4s	v11, v11, v14
    46ec:      	fmul.4s	v26, v26, v11
    46f0:      	shl.4s	v11, v9, #0x17
    46f4:      	add.4s	v11, v11, v14
    46f8:      	fmul.4s	v25, v25, v11
    46fc:      	sub.4s	v27, v27, v10
    4700:      	sub.4s	v31, v31, v9
    4704:      	shl.4s	v31, v31, #0x17
    4708:      	add.4s	v31, v31, v14
    470c:      	fmul.4s	v25, v25, v31
    4710:      	shl.4s	v27, v27, #0x17
    4714:      	add.4s	v27, v27, v14
    4718:      	fmul.4s	v26, v26, v27
    471c:      	fcmgt.4s	v27, v12, v3
    4720:      	bic.16b	v26, v26, v27
    4724:      	fcmgt.4s	v27, v12, v2
    4728:      	bic.16b	v25, v25, v27
    472c:      	fcmgt.4s	v27, v2, v13
    4730:      	bit.16b	v25, v8, v27
    4734:      	fcmgt.4s	v27, v3, v13
    4738:      	bit.16b	v26, v8, v27
    473c:      	fcmeq.4s	v3, v3, v3
    4740:      	ldr	q5, [sp, #0x3f0]
    4744:      	bsl.16b	v3, v26, v5
    4748:      	cmeq.8b	v24, v24, #0
    474c:      	sshll.8h	v24, v24, #0x0
    4750:      	fcmeq.4s	v2, v2, v2
    4754:      	bsl.16b	v2, v25, v5
    4758:      	sshll2.4s	v25, v24, #0x0
    475c:      	sshll.4s	v24, v24, #0x0
    4760:      	bic.16b	v9, v2, v24
    4764:      	bic.16b	v10, v3, v25
    4768:      	add	x10, x23, x10
    476c:      	ldp	q2, q3, [x10]
    4770:      	bit.16b	v3, v10, v0
    4774:      	bit.16b	v2, v9, v1
    4778:      	stp	q2, q3, [x10]
    477c:      	ldr	q2, [sp, #0x360]
    4780:      	fmov	w9, s2
    4784:      	ldr	q2, [sp, #0x2d0]
    4788:      	add.2d	v2, v16, v2
    478c:      	ldr	q3, [sp, #0x430]
    4790:      	add.2d	v2, v3, v2
    4794:      	tbz	w9, #0x0, 0x4814 <_llm_rows.packet_batch.blocks+0x2c2c>
    4798:      	fmov	x10, d2
    479c:      	ldr	b24, [x10]
    47a0:      	and	w10, w9, #0xff
    47a4:      	tbnz	w10, #0x1, 0x4820 <_llm_rows.packet_batch.blocks+0x2c38>
    47a8:      	b	0x4828 <_llm_rows.packet_batch.blocks+0x2c40>
    47ac:      	fmov	x9, d2
    47b0:      	ld1.b	{ v24 }[2], [x9]
    47b4:      	tbz	w3, #0x3, 0x4578 <_llm_rows.packet_batch.blocks+0x2990>
    47b8:      	mov.d	x9, v2[1]
    47bc:      	ld1.b	{ v24 }[3], [x9]
    47c0:      	ldr	q2, [sp, #0x320]
    47c4:      	ldr	q3, [sp, #0x400]
    47c8:      	add.2d	v2, v3, v2
    47cc:      	ldr	q3, [sp, #0x440]
    47d0:      	add.2d	v2, v3, v2
    47d4:      	tbz	w3, #0x4, 0x4590 <_llm_rows.packet_batch.blocks+0x29a8>
    47d8:      	fmov	x9, d2
    47dc:      	ld1.b	{ v24 }[4], [x9]
    47e0:      	tbz	w3, #0x5, 0x4594 <_llm_rows.packet_batch.blocks+0x29ac>
    47e4:      	mov.d	x9, v2[1]
    47e8:      	ld1.b	{ v24 }[5], [x9]
    47ec:      	ldr	q2, [sp, #0x340]
    47f0:      	ldr	q3, [sp, #0x420]
    47f4:      	add.2d	v2, v3, v2
    47f8:      	ldr	q3, [sp, #0x370]
    47fc:      	add.2d	v2, v3, v2
    4800:      	tbz	w3, #0x6, 0x45ac <_llm_rows.packet_batch.blocks+0x29c4>
    4804:      	fmov	x9, d2
    4808:      	ld1.b	{ v24 }[6], [x9]
    480c:      	tbnz	w3, #0x7, 0x45b0 <_llm_rows.packet_batch.blocks+0x29c8>
    4810:      	b	0x45b8 <_llm_rows.packet_batch.blocks+0x29d0>
    4814:      	movi.2d	v24, #0000000000000000
    4818:      	and	w10, w9, #0xff
    481c:      	tbz	w10, #0x1, 0x4828 <_llm_rows.packet_batch.blocks+0x2c40>
    4820:      	mov.d	x9, v2[1]
    4824:      	ld1.b	{ v24 }[1], [x9]
    4828:      	ldr	q2, [sp, #0x2c0]
    482c:      	ldr	q3, [sp, #0x410]
    4830:      	add.2d	v2, v3, v2
    4834:      	ldr	q3, [sp, #0x450]
    4838:      	add.2d	v2, v3, v2
    483c:      	tbnz	w10, #0x2, 0x4a80 <_llm_rows.packet_batch.blocks+0x2e98>
    4840:      	tbnz	w10, #0x3, 0x4a8c <_llm_rows.packet_batch.blocks+0x2ea4>
    4844:      	ldr	q2, [sp, #0x2b0]
    4848:      	ldr	q3, [sp, #0x400]
    484c:      	add.2d	v2, v3, v2
    4850:      	ldr	q3, [sp, #0x440]
    4854:      	add.2d	v2, v3, v2
    4858:      	tbnz	w10, #0x4, 0x4aac <_llm_rows.packet_batch.blocks+0x2ec4>
    485c:      	tbnz	w10, #0x5, 0x4ab8 <_llm_rows.packet_batch.blocks+0x2ed0>
    4860:      	ldr	q2, [sp, #0x2a0]
    4864:      	ldr	q3, [sp, #0x420]
    4868:      	add.2d	v2, v3, v2
    486c:      	ldr	q3, [sp, #0x370]
    4870:      	add.2d	v2, v3, v2
    4874:      	tbnz	w10, #0x6, 0x4ad8 <_llm_rows.packet_batch.blocks+0x2ef0>
    4878:      	tbz	w10, #0x7, 0x4884 <_llm_rows.packet_batch.blocks+0x2c9c>
    487c:      	mov.d	x9, v2[1]
    4880:      	ld1.b	{ v24 }[7], [x9]
    4884:      	fmov	x9, d16
    4888:      	lsl	x10, x9, #5
    488c:      	add	x3, x10, #0x20
    4890:      	add	x9, x27, x3
    4894:      	ldp	q3, q2, [x9]
    4898:      	fsub.4s	v25, v3, v18
    489c:      	fsub.4s	v2, v2, v18
    48a0:      	and.16b	v3, v0, v2
    48a4:      	and.16b	v2, v1, v25
    48a8:      	fcmge.4s	v25, v2, v12
    48ac:      	fcmge.4s	v26, v3, v12
    48b0:      	fcmge.4s	v27, v13, v2
    48b4:      	fcmge.4s	v31, v13, v3
    48b8:      	and.16b	v26, v26, v31
    48bc:      	and.16b	v25, v25, v27
    48c0:      	and.16b	v25, v25, v2
    48c4:      	and.16b	v26, v26, v3
    48c8:      	ldr	q5, [sp, #0x3e0]
    48cc:      	fmul.4s	v27, v26, v5
    48d0:      	fmul.4s	v31, v25, v5
    48d4:      	mov.16b	v11, v7
    48d8:      	bsl.16b	v11, v6, v31
    48dc:      	mov.16b	v20, v7
    48e0:      	bsl.16b	v20, v6, v27
    48e4:      	fadd.4s	v27, v27, v20
    48e8:      	fadd.4s	v31, v31, v11
    48ec:      	fsub.4s	v31, v31, v11
    48f0:      	fsub.4s	v20, v27, v20
    48f4:      	fcvtzs.4s	v20, v20
    48f8:      	fcvtzs.4s	v27, v31
    48fc:      	scvtf.4s	v31, v27
    4900:      	scvtf.4s	v11, v20
    4904:      	ldr	q5, [sp, #0x3d0]
    4908:      	fmul.4s	v15, v31, v5
    490c:      	fadd.4s	v25, v25, v15
    4910:      	fmul.4s	v15, v11, v5
    4914:      	fadd.4s	v26, v26, v15
    4918:      	fmul.4s	v31, v31, v17
    491c:      	fmul.4s	v11, v11, v17
    4920:      	fadd.4s	v26, v26, v11
    4924:      	fadd.4s	v25, v25, v31
    4928:      	ldr	q5, [sp, #0x3c0]
    492c:      	fmul.4s	v31, v25, v5
    4930:      	fmul.4s	v11, v26, v5
    4934:      	ldr	q5, [sp, #0x3b0]
    4938:      	fadd.4s	v11, v11, v5
    493c:      	fadd.4s	v31, v31, v5
    4940:      	fmul.4s	v31, v25, v31
    4944:      	fmul.4s	v11, v26, v11
    4948:      	ldr	q5, [sp, #0x3a0]
    494c:      	fadd.4s	v11, v11, v5
    4950:      	fadd.4s	v31, v31, v5
    4954:      	fmul.4s	v31, v25, v31
    4958:      	fmul.4s	v11, v26, v11
    495c:      	ldr	q5, [sp, #0x390]
    4960:      	fadd.4s	v11, v11, v5
    4964:      	fadd.4s	v31, v31, v5
    4968:      	fmul.4s	v31, v25, v31
    496c:      	fmul.4s	v11, v26, v11
    4970:      	ldr	q5, [sp, #0x380]
    4974:      	fadd.4s	v11, v11, v5
    4978:      	fadd.4s	v31, v31, v5
    497c:      	fmul.4s	v31, v25, v31
    4980:      	fmul.4s	v11, v26, v11
    4984:      	movi.4s	v5, #0x3f, lsl #24
    4988:      	fadd.4s	v11, v11, v5
    498c:      	fadd.4s	v31, v31, v5
    4990:      	fmul.4s	v15, v25, v25
    4994:      	fmul.4s	v31, v15, v31
    4998:      	fmul.4s	v15, v26, v26
    499c:      	fmul.4s	v11, v15, v11
    49a0:      	fadd.4s	v26, v26, v11
    49a4:      	fadd.4s	v25, v25, v31
    49a8:      	fadd.4s	v25, v25, v14
    49ac:      	fadd.4s	v26, v26, v14
    49b0:      	sshr.4s	v31, v27, #0x1
    49b4:      	sshr.4s	v11, v20, #0x1
    49b8:      	shl.4s	v15, v11, #0x17
    49bc:      	add.4s	v15, v15, v14
    49c0:      	fmul.4s	v26, v26, v15
    49c4:      	shl.4s	v15, v31, #0x17
    49c8:      	add.4s	v15, v15, v14
    49cc:      	fmul.4s	v25, v25, v15
    49d0:      	sub.4s	v20, v20, v11
    49d4:      	sub.4s	v27, v27, v31
    49d8:      	shl.4s	v27, v27, #0x17
    49dc:      	add.4s	v27, v27, v14
    49e0:      	fmul.4s	v25, v25, v27
    49e4:      	shl.4s	v20, v20, #0x17
    49e8:      	add.4s	v20, v20, v14
    49ec:      	fmul.4s	v20, v26, v20
    49f0:      	fcmgt.4s	v26, v12, v3
    49f4:      	bic.16b	v20, v20, v26
    49f8:      	fcmgt.4s	v26, v12, v2
    49fc:      	bic.16b	v25, v25, v26
    4a00:      	fcmgt.4s	v26, v2, v13
    4a04:      	bit.16b	v25, v8, v26
    4a08:      	fcmgt.4s	v26, v3, v13
    4a0c:      	bit.16b	v20, v8, v26
    4a10:      	fcmeq.4s	v3, v3, v3
    4a14:      	ldr	q5, [sp, #0x3f0]
    4a18:      	bsl.16b	v3, v20, v5
    4a1c:      	cmeq.8b	v20, v24, #0
    4a20:      	sshll.8h	v20, v20, #0x0
    4a24:      	fcmeq.4s	v2, v2, v2
    4a28:      	bsl.16b	v2, v25, v5
    4a2c:      	sshll2.4s	v25, v20, #0x0
    4a30:      	sshll.4s	v20, v20, #0x0
    4a34:      	bic.16b	v24, v2, v20
    4a38:      	bic.16b	v25, v3, v25
    4a3c:      	add	x16, x23, x3
    4a40:      	ldp	q2, q3, [x16]
    4a44:      	bit.16b	v3, v25, v0
    4a48:      	bit.16b	v2, v24, v1
    4a4c:      	stp	q2, q3, [x16]
    4a50:      	ldr	q2, [sp, #0x360]
    4a54:      	fmov	w9, s2
    4a58:      	ldr	q2, [sp, #0x290]
    4a5c:      	add.2d	v2, v16, v2
    4a60:      	ldr	q3, [sp, #0x430]
    4a64:      	add.2d	v2, v3, v2
    4a68:      	tbz	w9, #0x0, 0x4ae8 <_llm_rows.packet_batch.blocks+0x2f00>
    4a6c:      	fmov	x16, d2
    4a70:      	ldr	b26, [x16]
    4a74:      	and	w3, w9, #0xff
    4a78:      	tbnz	w3, #0x1, 0x4af4 <_llm_rows.packet_batch.blocks+0x2f0c>
    4a7c:      	b	0x4afc <_llm_rows.packet_batch.blocks+0x2f14>
    4a80:      	fmov	x9, d2
    4a84:      	ld1.b	{ v24 }[2], [x9]
    4a88:      	tbz	w10, #0x3, 0x4844 <_llm_rows.packet_batch.blocks+0x2c5c>
    4a8c:      	mov.d	x9, v2[1]
    4a90:      	ld1.b	{ v24 }[3], [x9]
    4a94:      	ldr	q2, [sp, #0x2b0]
    4a98:      	ldr	q3, [sp, #0x400]
    4a9c:      	add.2d	v2, v3, v2
    4aa0:      	ldr	q3, [sp, #0x440]
    4aa4:      	add.2d	v2, v3, v2
    4aa8:      	tbz	w10, #0x4, 0x485c <_llm_rows.packet_batch.blocks+0x2c74>
    4aac:      	fmov	x9, d2
    4ab0:      	ld1.b	{ v24 }[4], [x9]
    4ab4:      	tbz	w10, #0x5, 0x4860 <_llm_rows.packet_batch.blocks+0x2c78>
    4ab8:      	mov.d	x9, v2[1]
    4abc:      	ld1.b	{ v24 }[5], [x9]
    4ac0:      	ldr	q2, [sp, #0x2a0]
    4ac4:      	ldr	q3, [sp, #0x420]
    4ac8:      	add.2d	v2, v3, v2
    4acc:      	ldr	q3, [sp, #0x370]
    4ad0:      	add.2d	v2, v3, v2
    4ad4:      	tbz	w10, #0x6, 0x4878 <_llm_rows.packet_batch.blocks+0x2c90>
    4ad8:      	fmov	x9, d2
    4adc:      	ld1.b	{ v24 }[6], [x9]
    4ae0:      	tbnz	w10, #0x7, 0x487c <_llm_rows.packet_batch.blocks+0x2c94>
    4ae4:      	b	0x4884 <_llm_rows.packet_batch.blocks+0x2c9c>
    4ae8:      	movi.2d	v26, #0000000000000000
    4aec:      	and	w3, w9, #0xff
    4af0:      	tbz	w3, #0x1, 0x4afc <_llm_rows.packet_batch.blocks+0x2f14>
    4af4:      	mov.d	x9, v2[1]
    4af8:      	ld1.b	{ v26 }[1], [x9]
    4afc:      	ldr	q2, [sp, #0x280]
    4b00:      	ldr	q3, [sp, #0x410]
    4b04:      	add.2d	v2, v3, v2
    4b08:      	ldr	q3, [sp, #0x450]
    4b0c:      	add.2d	v2, v3, v2
    4b10:      	tbnz	w3, #0x2, 0x4d50 <_llm_rows.packet_batch.blocks+0x3168>
    4b14:      	tbnz	w3, #0x3, 0x4d5c <_llm_rows.packet_batch.blocks+0x3174>
    4b18:      	ldr	q2, [sp, #0x270]
    4b1c:      	ldr	q3, [sp, #0x400]
    4b20:      	add.2d	v2, v3, v2
    4b24:      	ldr	q3, [sp, #0x440]
    4b28:      	add.2d	v2, v3, v2
    4b2c:      	tbnz	w3, #0x4, 0x4d7c <_llm_rows.packet_batch.blocks+0x3194>
    4b30:      	tbnz	w3, #0x5, 0x4d88 <_llm_rows.packet_batch.blocks+0x31a0>
    4b34:      	ldr	q2, [sp, #0x260]
    4b38:      	ldr	q3, [sp, #0x420]
    4b3c:      	add.2d	v2, v3, v2
    4b40:      	ldr	q3, [sp, #0x370]
    4b44:      	add.2d	v2, v3, v2
    4b48:      	tbnz	w3, #0x6, 0x4da8 <_llm_rows.packet_batch.blocks+0x31c0>
    4b4c:      	tbz	w3, #0x7, 0x4b58 <_llm_rows.packet_batch.blocks+0x2f70>
    4b50:      	mov.d	x9, v2[1]
    4b54:      	ld1.b	{ v26 }[7], [x9]
    4b58:      	add	x3, x10, #0x40
    4b5c:      	add	x9, x27, x3
    4b60:      	ldp	q3, q2, [x9]
    4b64:      	fsub.4s	v20, v3, v18
    4b68:      	fsub.4s	v2, v2, v18
    4b6c:      	and.16b	v3, v0, v2
    4b70:      	and.16b	v2, v1, v20
    4b74:      	fcmge.4s	v20, v2, v12
    4b78:      	fcmge.4s	v27, v3, v12
    4b7c:      	fcmge.4s	v31, v13, v2
    4b80:      	fcmge.4s	v11, v13, v3
    4b84:      	and.16b	v27, v27, v11
    4b88:      	and.16b	v20, v20, v31
    4b8c:      	and.16b	v20, v20, v2
    4b90:      	and.16b	v27, v27, v3
    4b94:      	ldp	q17, q5, [sp, #0x3d0]
    4b98:      	fmul.4s	v31, v27, v5
    4b9c:      	fmul.4s	v11, v20, v5
    4ba0:      	mov.16b	v15, v7
    4ba4:      	bsl.16b	v15, v6, v11
    4ba8:      	mov.16b	v8, v7
    4bac:      	bsl.16b	v8, v6, v31
    4bb0:      	fadd.4s	v31, v31, v8
    4bb4:      	fadd.4s	v11, v11, v15
    4bb8:      	fsub.4s	v11, v11, v15
    4bbc:      	fsub.4s	v31, v31, v8
    4bc0:      	fcvtzs.4s	v31, v31
    4bc4:      	fcvtzs.4s	v8, v11
    4bc8:      	scvtf.4s	v11, v8
    4bcc:      	scvtf.4s	v15, v31
    4bd0:      	fmul.4s	v5, v11, v17
    4bd4:      	fadd.4s	v5, v20, v5
    4bd8:      	fmul.4s	v20, v15, v17
    4bdc:      	fadd.4s	v20, v27, v20
    4be0:      	ldr	q17, [sp, #0x2f0]
    4be4:      	fmul.4s	v27, v11, v17
    4be8:      	fmul.4s	v11, v15, v17
    4bec:      	fadd.4s	v20, v20, v11
    4bf0:      	fadd.4s	v5, v5, v27
    4bf4:      	ldr	q17, [sp, #0x3c0]
    4bf8:      	fmul.4s	v27, v5, v17
    4bfc:      	fmul.4s	v11, v20, v17
    4c00:      	ldr	q17, [sp, #0x3b0]
    4c04:      	fadd.4s	v11, v11, v17
    4c08:      	fadd.4s	v27, v27, v17
    4c0c:      	fmul.4s	v27, v5, v27
    4c10:      	fmul.4s	v11, v20, v11
    4c14:      	ldr	q17, [sp, #0x3a0]
    4c18:      	fadd.4s	v11, v11, v17
    4c1c:      	fadd.4s	v27, v27, v17
    4c20:      	fmul.4s	v27, v5, v27
    4c24:      	fmul.4s	v11, v20, v11
    4c28:      	ldr	q17, [sp, #0x390]
    4c2c:      	fadd.4s	v11, v11, v17
    4c30:      	fadd.4s	v27, v27, v17
    4c34:      	fmul.4s	v27, v5, v27
    4c38:      	fmul.4s	v11, v20, v11
    4c3c:      	ldr	q17, [sp, #0x380]
    4c40:      	fadd.4s	v11, v11, v17
    4c44:      	fadd.4s	v27, v27, v17
    4c48:      	fmul.4s	v27, v5, v27
    4c4c:      	fmul.4s	v11, v20, v11
    4c50:      	movi.4s	v15, #0x3f, lsl #24
    4c54:      	fadd.4s	v11, v11, v15
    4c58:      	fadd.4s	v27, v27, v15
    4c5c:      	fmul.4s	v15, v5, v5
    4c60:      	fmul.4s	v27, v15, v27
    4c64:      	fmul.4s	v15, v20, v20
    4c68:      	fmul.4s	v11, v15, v11
    4c6c:      	fadd.4s	v20, v20, v11
    4c70:      	fadd.4s	v5, v5, v27
    4c74:      	fadd.4s	v5, v5, v14
    4c78:      	fadd.4s	v20, v20, v14
    4c7c:      	sshr.4s	v27, v8, #0x1
    4c80:      	sshr.4s	v11, v31, #0x1
    4c84:      	shl.4s	v15, v11, #0x17
    4c88:      	add.4s	v15, v15, v14
    4c8c:      	fmul.4s	v20, v20, v15
    4c90:      	shl.4s	v15, v27, #0x17
    4c94:      	add.4s	v15, v15, v14
    4c98:      	fmul.4s	v5, v5, v15
    4c9c:      	sub.4s	v31, v31, v11
    4ca0:      	sub.4s	v27, v8, v27
    4ca4:      	shl.4s	v27, v27, #0x17
    4ca8:      	add.4s	v27, v27, v14
    4cac:      	fmul.4s	v5, v5, v27
    4cb0:      	shl.4s	v27, v31, #0x17
    4cb4:      	add.4s	v27, v27, v14
    4cb8:      	fmul.4s	v20, v20, v27
    4cbc:      	fcmgt.4s	v27, v12, v3
    4cc0:      	bic.16b	v20, v20, v27
    4cc4:      	fcmgt.4s	v27, v12, v2
    4cc8:      	bic.16b	v5, v5, v27
    4ccc:      	fcmgt.4s	v27, v2, v13
    4cd0:      	ldr	q31, [sp, #0x2e0]
    4cd4:      	bit.16b	v5, v31, v27
    4cd8:      	fcmgt.4s	v27, v3, v13
    4cdc:      	bit.16b	v20, v31, v27
    4ce0:      	fcmeq.4s	v3, v3, v3
    4ce4:      	ldr	q27, [sp, #0x3f0]
    4ce8:      	bsl.16b	v3, v20, v27
    4cec:      	cmeq.8b	v20, v26, #0
    4cf0:      	sshll.8h	v20, v20, #0x0
    4cf4:      	fcmeq.4s	v2, v2, v2
    4cf8:      	bsl.16b	v2, v5, v27
    4cfc:      	sshll2.4s	v5, v20, #0x0
    4d00:      	sshll.4s	v20, v20, #0x0
    4d04:      	bic.16b	v27, v2, v20
    4d08:      	bic.16b	v2, v3, v5
    4d0c:      	add	x16, x23, x3
    4d10:      	ldp	q3, q5, [x16]
    4d14:      	bit.16b	v5, v2, v0
    4d18:      	bit.16b	v3, v27, v1
    4d1c:      	stp	q3, q5, [x16]
    4d20:      	ldr	q3, [sp, #0x360]
    4d24:      	fmov	w9, s3
    4d28:      	ldr	q3, [sp, #0x250]
    4d2c:      	add.2d	v3, v16, v3
    4d30:      	ldr	q5, [sp, #0x430]
    4d34:      	add.2d	v3, v5, v3
    4d38:      	tbz	w9, #0x0, 0x4db8 <_llm_rows.packet_batch.blocks+0x31d0>
    4d3c:      	fmov	x16, d3
    4d40:      	ldr	b26, [x16]
    4d44:      	and	w3, w9, #0xff
    4d48:      	tbnz	w3, #0x1, 0x4dc4 <_llm_rows.packet_batch.blocks+0x31dc>
    4d4c:      	b	0x4dcc <_llm_rows.packet_batch.blocks+0x31e4>
    4d50:      	fmov	x9, d2
    4d54:      	ld1.b	{ v26 }[2], [x9]
    4d58:      	tbz	w3, #0x3, 0x4b18 <_llm_rows.packet_batch.blocks+0x2f30>
    4d5c:      	mov.d	x9, v2[1]
    4d60:      	ld1.b	{ v26 }[3], [x9]
    4d64:      	ldr	q2, [sp, #0x270]
    4d68:      	ldr	q3, [sp, #0x400]
    4d6c:      	add.2d	v2, v3, v2
    4d70:      	ldr	q3, [sp, #0x440]
    4d74:      	add.2d	v2, v3, v2
    4d78:      	tbz	w3, #0x4, 0x4b30 <_llm_rows.packet_batch.blocks+0x2f48>
    4d7c:      	fmov	x9, d2
    4d80:      	ld1.b	{ v26 }[4], [x9]
    4d84:      	tbz	w3, #0x5, 0x4b34 <_llm_rows.packet_batch.blocks+0x2f4c>
    4d88:      	mov.d	x9, v2[1]
    4d8c:      	ld1.b	{ v26 }[5], [x9]
    4d90:      	ldr	q2, [sp, #0x260]
    4d94:      	ldr	q3, [sp, #0x420]
    4d98:      	add.2d	v2, v3, v2
    4d9c:      	ldr	q3, [sp, #0x370]
    4da0:      	add.2d	v2, v3, v2
    4da4:      	tbz	w3, #0x6, 0x4b4c <_llm_rows.packet_batch.blocks+0x2f64>
    4da8:      	fmov	x9, d2
    4dac:      	ld1.b	{ v26 }[6], [x9]
    4db0:      	tbnz	w3, #0x7, 0x4b50 <_llm_rows.packet_batch.blocks+0x2f68>
    4db4:      	b	0x4b58 <_llm_rows.packet_batch.blocks+0x2f70>
    4db8:      	movi.2d	v26, #0000000000000000
    4dbc:      	and	w3, w9, #0xff
    4dc0:      	tbz	w3, #0x1, 0x4dcc <_llm_rows.packet_batch.blocks+0x31e4>
    4dc4:      	mov.d	x9, v3[1]
    4dc8:      	ld1.b	{ v26 }[1], [x9]
    4dcc:      	ldr	q3, [sp, #0x240]
    4dd0:      	ldr	q5, [sp, #0x410]
    4dd4:      	add.2d	v3, v5, v3
    4dd8:      	ldr	q5, [sp, #0x450]
    4ddc:      	add.2d	v3, v5, v3
    4de0:      	tbnz	w3, #0x2, 0x4e4c <_llm_rows.packet_batch.blocks+0x3264>
    4de4:      	tbnz	w3, #0x3, 0x4e58 <_llm_rows.packet_batch.blocks+0x3270>
    4de8:      	ldr	q3, [sp, #0x230]
    4dec:      	ldr	q5, [sp, #0x400]
    4df0:      	add.2d	v3, v5, v3
    4df4:      	ldr	q5, [sp, #0x440]
    4df8:      	add.2d	v3, v5, v3
    4dfc:      	tbnz	w3, #0x4, 0x4e78 <_llm_rows.packet_batch.blocks+0x3290>
    4e00:      	tbnz	w3, #0x5, 0x4e84 <_llm_rows.packet_batch.blocks+0x329c>
    4e04:      	ldr	q3, [sp, #0x220]
    4e08:      	ldr	q5, [sp, #0x420]
    4e0c:      	add.2d	v3, v5, v3
    4e10:      	ldr	q5, [sp, #0x370]
    4e14:      	add.2d	v3, v5, v3
    4e18:      	tbz	w3, #0x6, 0x4e24 <_llm_rows.packet_batch.blocks+0x323c>
    4e1c:      	fmov	x9, d3
    4e20:      	ld1.b	{ v26 }[6], [x9]
    4e24:      	fadd.4s	v10, v30, v10
    4e28:      	fadd.4s	v9, v29, v9
    4e2c:      	fadd.4s	v25, v23, v25
    4e30:      	fadd.4s	v24, v28, v24
    4e34:      	fadd.4s	v2, v22, v2
    4e38:      	fadd.4s	v27, v4, v27
    4e3c:      	tbz	w3, #0x7, 0x42c8 <_llm_rows.packet_batch.blocks+0x26e0>
    4e40:      	mov.d	x9, v3[1]
    4e44:      	ld1.b	{ v26 }[7], [x9]
    4e48:      	b	0x42c8 <_llm_rows.packet_batch.blocks+0x26e0>
    4e4c:      	fmov	x9, d3
    4e50:      	ld1.b	{ v26 }[2], [x9]
    4e54:      	tbz	w3, #0x3, 0x4de8 <_llm_rows.packet_batch.blocks+0x3200>
    4e58:      	mov.d	x9, v3[1]
    4e5c:      	ld1.b	{ v26 }[3], [x9]
    4e60:      	ldr	q3, [sp, #0x230]
    4e64:      	ldr	q5, [sp, #0x400]
    4e68:      	add.2d	v3, v5, v3
    4e6c:      	ldr	q5, [sp, #0x440]
    4e70:      	add.2d	v3, v5, v3
    4e74:      	tbz	w3, #0x4, 0x4e00 <_llm_rows.packet_batch.blocks+0x3218>
    4e78:      	fmov	x9, d3
    4e7c:      	ld1.b	{ v26 }[4], [x9]
    4e80:      	tbz	w3, #0x5, 0x4e04 <_llm_rows.packet_batch.blocks+0x321c>
    4e84:      	mov.d	x9, v3[1]
    4e88:      	ld1.b	{ v26 }[5], [x9]
    4e8c:      	ldr	q3, [sp, #0x220]
    4e90:      	ldr	q5, [sp, #0x420]
    4e94:      	add.2d	v3, v5, v3
    4e98:      	ldr	q5, [sp, #0x370]
    4e9c:      	add.2d	v3, v5, v3
    4ea0:      	tbnz	w3, #0x6, 0x4e1c <_llm_rows.packet_batch.blocks+0x3234>
    4ea4:      	b	0x4e24 <_llm_rows.packet_batch.blocks+0x323c>
    4ea8:      	mov	x10, #0x0               ; =0
    4eac:      	ldp	q2, q5, [sp, #0x70]
    4eb0:      	fsub.4s	v3, v5, v18
    4eb4:      	fsub.4s	v2, v2, v18
    4eb8:      	ldr	q6, [sp, #0x1d0]
    4ebc:      	zip2.8b	v5, v6, v0
    4ec0:      	ushll.4s	v5, v5, #0x0
    4ec4:      	shl.4s	v5, v5, #0x1f
    4ec8:      	cmlt.4s	v18, v5, #0
    4ecc:      	and.16b	v2, v18, v2
    4ed0:      	zip1.8b	v5, v6, v0
    4ed4:      	ushll.4s	v5, v5, #0x0
    4ed8:      	shl.4s	v5, v5, #0x1f
    4edc:      	cmlt.4s	v24, v5, #0
    4ee0:      	and.16b	v3, v24, v3
    4ee4:      	fcmge.4s	v5, v2, v12
    4ee8:      	fcmge.4s	v6, v13, v2
    4eec:      	and.16b	v5, v5, v6
    4ef0:      	fcmge.4s	v6, v3, v12
    4ef4:      	fcmge.4s	v7, v13, v3
    4ef8:      	and.16b	v6, v6, v7
    4efc:      	and.16b	v6, v6, v3
    4f00:      	ldp	q16, q27, [sp, #0x3d0]
    4f04:      	fmul.4s	v7, v6, v27
    4f08:      	movi.4s	v25, #0x4b, lsl #24
    4f0c:      	mvni.4s	v26, #0x80, lsl #24
    4f10:      	mov.16b	v20, v26
    4f14:      	bsl.16b	v20, v25, v7
    4f18:      	fadd.4s	v7, v7, v20
    4f1c:      	fsub.4s	v7, v7, v20
    4f20:      	and.16b	v5, v5, v2
    4f24:      	fmul.4s	v20, v5, v27
    4f28:      	bif.16b	v25, v20, v26
    4f2c:      	fadd.4s	v20, v20, v25
    4f30:      	fsub.4s	v20, v20, v25
    4f34:      	fcvtzs.4s	v25, v7
    4f38:      	scvtf.4s	v7, v25
    4f3c:      	fmul.4s	v26, v7, v16
    4f40:      	fadd.4s	v6, v6, v26
    4f44:      	fcvtzs.4s	v20, v20
    4f48:      	scvtf.4s	v26, v20
    4f4c:      	fmul.4s	v27, v26, v16
    4f50:      	fadd.4s	v5, v5, v27
    4f54:      	fmul.4s	v7, v7, v17
    4f58:      	fmul.4s	v26, v26, v17
    4f5c:      	fadd.4s	v5, v5, v26
    4f60:      	fadd.4s	v6, v6, v7
    4f64:      	ldp	q16, q17, [sp, #0x3b0]
    4f68:      	fmul.4s	v7, v6, v17
    4f6c:      	fmul.4s	v26, v5, v17
    4f70:      	fadd.4s	v26, v26, v16
    4f74:      	fadd.4s	v7, v7, v16
    4f78:      	fmul.4s	v7, v6, v7
    4f7c:      	fmul.4s	v26, v5, v26
    4f80:      	ldp	q16, q17, [sp, #0x390]
    4f84:      	fadd.4s	v26, v26, v17
    4f88:      	fadd.4s	v7, v7, v17
    4f8c:      	fmul.4s	v7, v6, v7
    4f90:      	fmul.4s	v26, v5, v26
    4f94:      	fadd.4s	v26, v26, v16
    4f98:      	fadd.4s	v7, v7, v16
    4f9c:      	fmul.4s	v7, v6, v7
    4fa0:      	fmul.4s	v16, v5, v26
    4fa4:      	ldr	q17, [sp, #0x380]
    4fa8:      	fadd.4s	v16, v16, v17
    4fac:      	fadd.4s	v7, v7, v17
    4fb0:      	fmul.4s	v7, v6, v7
    4fb4:      	fmul.4s	v16, v5, v16
    4fb8:      	movi.4s	v17, #0x3f, lsl #24
    4fbc:      	fadd.4s	v16, v16, v17
    4fc0:      	fadd.4s	v7, v7, v17
    4fc4:      	fmul.4s	v17, v6, v6
    4fc8:      	fmul.4s	v7, v17, v7
    4fcc:      	fmul.4s	v17, v5, v5
    4fd0:      	fmul.4s	v16, v17, v16
    4fd4:      	fadd.4s	v5, v5, v16
    4fd8:      	fadd.4s	v6, v6, v7
    4fdc:      	fadd.4s	v5, v5, v14
    4fe0:      	sshr.4s	v7, v20, #0x1
    4fe4:      	shl.4s	v16, v7, #0x17
    4fe8:      	add.4s	v16, v16, v14
    4fec:      	fmul.4s	v5, v5, v16
    4ff0:      	sub.4s	v7, v20, v7
    4ff4:      	shl.4s	v7, v7, #0x17
    4ff8:      	add.4s	v7, v7, v14
    4ffc:      	fmul.4s	v5, v5, v7
    5000:      	fcmgt.4s	v7, v12, v2
    5004:      	bic.16b	v5, v5, v7
    5008:      	fcmgt.4s	v7, v2, v13
    500c:      	bit.16b	v5, v8, v7
    5010:      	fcmeq.4s	v2, v2, v2
    5014:      	ldr	q17, [sp, #0x3f0]
    5018:      	bsl.16b	v2, v5, v17
    501c:      	fadd.4s	v5, v6, v14
    5020:      	ldr	q6, [sp, #0x90]
    5024:      	bic.16b	v2, v2, v6
    5028:      	fadd.4s	v6, v2, v30
    502c:      	and.16b	v6, v18, v6
    5030:      	ldr	q20, [sp, #0xb0]
    5034:      	zip2.8b	v7, v20, v0
    5038:      	ushll.4s	v7, v7, #0x0
    503c:      	shl.4s	v7, v7, #0x1f
    5040:      	cmlt.4s	v7, v7, #0
    5044:      	bit.16b	v6, v10, v7
    5048:      	sshr.4s	v7, v25, #0x1
    504c:      	shl.4s	v16, v7, #0x17
    5050:      	add.4s	v16, v16, v14
    5054:      	fmul.4s	v5, v5, v16
    5058:      	sub.4s	v7, v25, v7
    505c:      	shl.4s	v7, v7, #0x17
    5060:      	add.4s	v7, v7, v14
    5064:      	fmul.4s	v5, v5, v7
    5068:      	fcmgt.4s	v7, v12, v3
    506c:      	bic.16b	v5, v5, v7
    5070:      	fcmgt.4s	v7, v3, v13
    5074:      	bit.16b	v5, v8, v7
    5078:      	fcmeq.4s	v3, v3, v3
    507c:      	bsl.16b	v3, v5, v17
    5080:      	ldr	q5, [sp, #0xa0]
    5084:      	sshll.4s	v5, v5, #0x0
    5088:      	bic.16b	v3, v3, v5
    508c:      	fadd.4s	v5, v3, v29
    5090:      	and.16b	v5, v24, v5
    5094:      	zip1.8b	v7, v20, v0
    5098:      	ushll.4s	v7, v7, #0x0
    509c:      	shl.4s	v7, v7, #0x1f
    50a0:      	cmlt.4s	v7, v7, #0
    50a4:      	bit.16b	v5, v9, v7
    50a8:      	fadd.4s	v5, v5, v28
    50ac:      	fadd.4s	v6, v6, v23
    50b0:      	adrp	x9, 0x5000 <_llm_rows.packet_batch.blocks+0x3418>
    50b4:      	ldr	q7, [x9]
    50b8:      	and.16b	v20, v0, v7
    50bc:      	fadd.4s	v6, v6, v22
    50c0:      	adrp	x9, 0x5000 <_llm_rows.packet_batch.blocks+0x3418>
    50c4:      	ldr	q7, [x9]
    50c8:      	and.16b	v17, v1, v7
    50cc:      	fadd.4s	v4, v5, v4
    50d0:      	fadd.4s	v4, v4, v21
    50d4:      	fadd.4s	v5, v6, v19
    50d8:      	fmov	w9, s17
    50dc:      	add	x16, sp, #0x4a8
    50e0:      	bfxil	x16, x9, #0, #3
    50e4:      	ldr	q6, [sp, #0xd0]
    50e8:      	str	d6, [sp, #0x4a8]
    50ec:      	ldrb	w16, [x16]
    50f0:      	add	x3, sp, #0x6d0
    50f4:      	orr	x9, x3, x9, lsl #2
    50f8:      	str	q5, [sp, #0x6e0]
    50fc:      	str	q4, [sp, #0x6d0]
    5100:      	ldr	s6, [x9]
    5104:      	tst	w2, w16
    5108:      	movi	d22, #0000000000000000
    510c:      	fcsel	s6, s6, s22, ne
    5110:      	mov.s	w9, v17[1]
    5114:      	add	x16, sp, #0x4a8
    5118:      	bfxil	x16, x9, #0, #3
    511c:      	ldrb	w9, [x16]
    5120:      	mov	x11, x4
    5124:      	and	w9, w4, w9
    5128:      	str	q4, [sp, #0x6b0]
    512c:      	ldr	s7, [sp, #0x6b0]
    5130:      	tst	w9, #0x1
    5134:      	fcsel	s7, s7, s22, ne
    5138:      	mov.s	w9, v17[2]
    513c:      	add	x16, sp, #0x690
    5140:      	orr	x16, x16, x9, lsl #2
    5144:      	add	x3, sp, #0x4a8
    5148:      	bfxil	x3, x9, #0, #3
    514c:      	ldrb	w9, [x3]
    5150:      	mov	x14, x25
    5154:      	and	w9, w25, w9
    5158:      	str	q5, [sp, #0x6a0]
    515c:      	str	q4, [sp, #0x690]
    5160:      	ldr	s16, [x16]
    5164:      	tst	w9, #0x1
    5168:      	fcsel	s16, s16, s22, ne
    516c:      	mov.s	w9, v17[3]
    5170:      	add	x16, sp, #0x670
    5174:      	orr	x16, x16, x9, lsl #2
    5178:      	add	x3, sp, #0x4a8
    517c:      	bfxil	x3, x9, #0, #3
    5180:      	ldrb	w9, [x3]
    5184:      	mov	x13, x15
    5188:      	and	w9, w15, w9
    518c:      	str	q5, [sp, #0x680]
    5190:      	str	q4, [sp, #0x670]
    5194:      	ldr	s17, [x16]
    5198:      	tst	w9, #0x1
    519c:      	fcsel	s17, s17, s22, ne
    51a0:      	fmov	w9, s20
    51a4:      	add	x16, sp, #0x4a8
    51a8:      	bfxil	x16, x9, #0, #3
    51ac:      	ldrb	w16, [x16]
    51b0:      	str	q5, [sp, #0x660]
    51b4:      	str	q4, [sp, #0x650]
    51b8:      	add	x3, sp, #0x650
    51bc:      	ldr	s19, [x3, w9, uxtw #2]
    51c0:      	ldp	w4, w1, [sp, #0xc8]
    51c4:      	and	w9, w4, w16
    51c8:      	tst	w9, #0x1
    51cc:      	mov.s	w9, v20[1]
    51d0:      	add	x16, sp, #0x4a8
    51d4:      	bfxil	x16, x9, #0, #3
    51d8:      	ldrb	w16, [x16]
    51dc:      	mov.s	w3, v20[2]
    51e0:      	mov.s	w19, v20[3]
    51e4:      	str	q5, [sp, #0x640]
    51e8:      	str	q4, [sp, #0x630]
    51ec:      	add	x25, sp, #0x630
    51f0:      	ldr	s20, [x25, w9, uxtw #2]
    51f4:      	fcsel	s19, s19, s22, ne
    51f8:      	and	w9, w1, w16
    51fc:      	tst	w9, #0x1
    5200:      	fcsel	s20, s20, s22, ne
    5204:      	add	x9, sp, #0x4a8
    5208:      	bfxil	x9, x3, #0, #3
    520c:      	ldrb	w9, [x9]
    5210:      	str	q5, [sp, #0x620]
    5214:      	str	q4, [sp, #0x610]
    5218:      	mov.s	v19[1], v20[0]
    521c:      	add	x16, sp, #0x610
    5220:      	ldr	s20, [x16, w3, uxtw #2]
    5224:      	ldr	w0, [sp, #0xe0]
    5228:      	and	w9, w0, w9
    522c:      	tst	w9, #0x1
    5230:      	fcsel	s20, s20, s22, ne
    5234:      	add	x9, sp, #0x4a8
    5238:      	bfxil	x9, x19, #0, #3
    523c:      	ldrb	w9, [x9]
    5240:      	ldr	w17, [sp, #0xf0]
    5244:      	and	w9, w17, w9
    5248:      	str	q5, [sp, #0x600]
    524c:      	str	q4, [sp, #0x5f0]
    5250:      	mov.s	v19[2], v20[0]
    5254:      	add	x16, sp, #0x5f0
    5258:      	ldr	s20, [x16, w19, uxtw #2]
    525c:      	tst	w9, #0x1
    5260:      	fcsel	s20, s20, s22, ne
    5264:      	mov.s	v19[3], v20[0]
    5268:      	adrp	x9, 0x5000 <_llm_rows.packet_batch.blocks+0x3418>
    526c:      	ldr	q20, [x9]
    5270:      	mov.s	v6[1], v7[0]
    5274:      	and.16b	v20, v1, v20
    5278:      	mov.s	v6[2], v16[0]
    527c:      	mov.s	v6[3], v17[0]
    5280:      	fadd.4s	v4, v4, v6
    5284:      	fadd.4s	v5, v5, v19
    5288:      	fmov	w9, s20
    528c:      	add	x16, sp, #0x4a8
    5290:      	bfxil	x16, x9, #0, #3
    5294:      	ldrb	w16, [x16]
    5298:      	add	x3, sp, #0x5d0
    529c:      	orr	x9, x3, x9, lsl #2
    52a0:      	str	q5, [sp, #0x5e0]
    52a4:      	str	q4, [sp, #0x5d0]
    52a8:      	ldr	s6, [x9]
    52ac:      	tst	w2, w16
    52b0:      	mov.s	w9, v20[1]
    52b4:      	add	x16, sp, #0x4a8
    52b8:      	bfxil	x16, x9, #0, #3
    52bc:      	ldrb	w16, [x16]
    52c0:      	and	w15, w11, w16
    52c4:      	fcsel	s6, s6, s22, ne
    52c8:      	add	x16, sp, #0x5b0
    52cc:      	orr	x9, x16, x9, lsl #2
    52d0:      	str	q5, [sp, #0x5c0]
    52d4:      	str	q4, [sp, #0x5b0]
    52d8:      	ldr	s7, [x9]
    52dc:      	tst	w15, #0x1
    52e0:      	mov.s	w9, v20[2]
    52e4:      	add	x15, sp, #0x4a8
    52e8:      	bfxil	x15, x9, #0, #3
    52ec:      	adrp	x9, 0x5000 <_llm_rows.packet_batch.blocks+0x3418>
    52f0:      	ldr	q16, [x9]
    52f4:      	and.16b	v21, v0, v16
    52f8:      	fcsel	s7, s7, s22, ne
    52fc:      	ldrb	w9, [x15]
    5300:      	and	w9, w14, w9
    5304:      	str	q4, [sp, #0x590]
    5308:      	ldr	s16, [sp, #0x590]
    530c:      	tst	w9, #0x1
    5310:      	mov.s	w9, v20[3]
    5314:      	fcsel	s16, s16, s22, ne
    5318:      	add	x14, sp, #0x4a8
    531c:      	bfxil	x14, x9, #0, #3
    5320:      	add	x15, sp, #0x570
    5324:      	orr	x9, x15, x9, lsl #2
    5328:      	ldrb	w14, [x14]
    532c:      	and	w13, w13, w14
    5330:      	str	q5, [sp, #0x580]
    5334:      	str	q4, [sp, #0x570]
    5338:      	ldr	s17, [x9]
    533c:      	tst	w13, #0x1
    5340:      	fcsel	s17, s17, s22, ne
    5344:      	fmov	w9, s21
    5348:      	add	x13, sp, #0x4a8
    534c:      	bfxil	x13, x9, #0, #3
    5350:      	ldrb	w13, [x13]
    5354:      	and	w13, w4, w13
    5358:      	str	q5, [sp, #0x560]
    535c:      	str	q4, [sp, #0x550]
    5360:      	add	x14, sp, #0x550
    5364:      	ldr	s19, [x14, w9, uxtw #2]
    5368:      	tst	w13, #0x1
    536c:      	fcsel	s19, s19, s22, ne
    5370:      	mov.s	w9, v21[1]
    5374:      	add	x13, sp, #0x4a8
    5378:      	bfxil	x13, x9, #0, #3
    537c:      	ldrb	w13, [x13]
    5380:      	and	w13, w1, w13
    5384:      	str	q5, [sp, #0x540]
    5388:      	str	q4, [sp, #0x530]
    538c:      	mov.s	w14, v21[2]
    5390:      	mov.s	w15, v21[3]
    5394:      	add	x16, sp, #0x530
    5398:      	ldr	s20, [x16, w9, uxtw #2]
    539c:      	tst	w13, #0x1
    53a0:      	fcsel	s20, s20, s22, ne
    53a4:      	add	x9, sp, #0x4a8
    53a8:      	bfxil	x9, x14, #0, #3
    53ac:      	ldrb	w9, [x9]
    53b0:      	and	w9, w0, w9
    53b4:      	str	q5, [sp, #0x520]
    53b8:      	str	q4, [sp, #0x510]
    53bc:      	mov.s	v19[1], v20[0]
    53c0:      	add	x13, sp, #0x510
    53c4:      	ldr	s20, [x13, w14, uxtw #2]
    53c8:      	tst	w9, #0x1
    53cc:      	fcsel	s20, s20, s22, ne
    53d0:      	add	x9, sp, #0x4a8
    53d4:      	bfxil	x9, x15, #0, #3
    53d8:      	ldrb	w9, [x9]
    53dc:      	and	w9, w17, w9
    53e0:      	str	q5, [sp, #0x500]
    53e4:      	str	q4, [sp, #0x4f0]
    53e8:      	mov.s	v19[2], v20[0]
    53ec:      	add	x13, sp, #0x4f0
    53f0:      	ldr	s20, [x13, w15, uxtw #2]
    53f4:      	tst	w9, #0x1
    53f8:      	fcsel	s20, s20, s22, ne
    53fc:      	mov.s	v19[3], v20[0]
    5400:      	mov.s	v6[1], v7[0]
    5404:      	mov.s	v6[2], v16[0]
    5408:      	mov.s	v6[3], v17[0]
    540c:      	fadd.4s	v4, v4, v6
    5410:      	fadd.4s	v5, v5, v19
    5414:      	movi.4s	v6, #0x4
    5418:      	and.16b	v6, v1, v6
    541c:      	fmov	w9, s6
    5420:      	add	x13, sp, #0x4a8
    5424:      	orr	x13, x13, x9
    5428:      	ldrb	w13, [x13]
    542c:      	str	q5, [sp, #0x4e0]
    5430:      	str	q4, [sp, #0x4d0]
    5434:      	add	x14, x23, x26
    5438:      	ldp	q5, q6, [x14]
    543c:      	bit.16b	v6, v2, v18
    5440:      	add	x15, sp, #0x4d0
    5444:      	ldr	s7, [x15, w9, uxtw #2]
    5448:      	bit.16b	v5, v3, v24
    544c:      	tst	w2, w13
    5450:      	fcsel	s7, s7, s22, ne
    5454:      	ldr	w9, [sp, #0xc4]
    5458:      	tst	w9, #0x1
    545c:      	stp	q5, q6, [x14]
    5460:      	fadd	s4, s4, s7
    5464:      	fcsel	s5, s4, s22, ne
    5468:      	tst	w7, #0x1
    546c:      	fcsel	s6, s4, s22, ne
    5470:      	tst	w30, #0x1
    5474:      	fcsel	s7, s4, s22, ne
    5478:      	tst	w8, #0x1
    547c:      	mov.s	v5[1], v6[0]
    5480:      	fcsel	s6, s4, s22, ne
    5484:      	mov.s	v5[2], v7[0]
    5488:      	tst	w5, #0x1
    548c:      	fcsel	s7, s4, s22, ne
    5490:      	tst	w6, #0x1
    5494:      	mov.s	v5[3], v6[0]
    5498:      	fcsel	s6, s4, s22, ne
    549c:      	ldp	w9, w8, [sp, #0x68]
    54a0:      	tst	w9, #0x1
    54a4:      	mov.s	v7[1], v6[0]
    54a8:      	fcsel	s6, s4, s22, ne
    54ac:      	tst	w8, #0x1
    54b0:      	fcsel	s4, s4, s22, ne
    54b4:      	mov.s	v7[2], v6[0]
    54b8:      	mov.s	v7[3], v4[0]
    54bc:      	str	q7, [sp, #0x4c0]
    54c0:      	str	q5, [sp, #0x4b0]
    54c4:      	and	x8, x12, #0x7
    54c8:      	add	x9, sp, #0x4b0
    54cc:      	ldr	s4, [x9, x8, lsl #2]
    54d0:      	fadd	s4, s4, s22
    54d4:      	dup.4s	v4, v4[0]
    54d8:      	ldr	q5, [sp, #0x120]
    54dc:      	fmov	x8, d5
    54e0:      	ldp	x14, x13, [sp, #0x178]
    54e4:      	add	x8, x13, x8, lsl #2
    54e8:      	movi.2d	v5, #0000000000000000
    54ec:      	movi.2d	v6, #0000000000000000
    54f0:      	movi.2d	v7, #0000000000000000
    54f4:      	movi.2d	v16, #0000000000000000
    54f8:      	movi.2s	v8, #0x41
    54fc:      	ldr	w12, [sp, #0x188]
    5500:      	ldp	q20, q19, [sp, #0x200]
    5504:      	ldp	q22, q21, [sp, #0x1e0]
    5508:      	b	0x5528 <_llm_rows.packet_batch.blocks+0x3940>
    550c:      	add.2d	v6, v6, v20
    5510:      	add.2d	v7, v7, v21
    5514:      	add.2d	v16, v16, v19
    5518:      	add.2d	v5, v5, v22
    551c:      	fmov	x10, d5
    5520:      	cmp	x10, #0x8
    5524:      	b.ge	0x55d8 <_llm_rows.packet_batch.blocks+0x39f0>
    5528:      	fmov	w11, s11
    552c:      	lsl	x9, x10, #5
    5530:      	add	x10, x23, x9
    5534:      	ldp	q18, q17, [x10]
    5538:      	and.16b	v18, v1, v18
    553c:      	fdiv.4s	v18, v18, v4
    5540:      	add	x9, x8, x9
    5544:      	tbnz	w11, #0x0, 0x5574 <_llm_rows.packet_batch.blocks+0x398c>
    5548:      	and	w10, w11, #0xff
    554c:      	tbnz	w10, #0x1, 0x5580 <_llm_rows.packet_batch.blocks+0x3998>
    5550:      	tbnz	w10, #0x2, 0x558c <_llm_rows.packet_batch.blocks+0x39a4>
    5554:      	tbnz	w10, #0x3, 0x5598 <_llm_rows.packet_batch.blocks+0x39b0>
    5558:      	and.16b	v17, v0, v17
    555c:      	fdiv.4s	v17, v17, v4
    5560:      	tbnz	w10, #0x4, 0x55ac <_llm_rows.packet_batch.blocks+0x39c4>
    5564:      	tbnz	w10, #0x5, 0x55b4 <_llm_rows.packet_batch.blocks+0x39cc>
    5568:      	tbnz	w10, #0x6, 0x55c0 <_llm_rows.packet_batch.blocks+0x39d8>
    556c:      	tbz	w10, #0x7, 0x550c <_llm_rows.packet_batch.blocks+0x3924>
    5570:      	b	0x55cc <_llm_rows.packet_batch.blocks+0x39e4>
    5574:      	str	s18, [x9]
    5578:      	and	w10, w11, #0xff
    557c:      	tbz	w10, #0x1, 0x5550 <_llm_rows.packet_batch.blocks+0x3968>
    5580:      	add	x11, x9, #0x4
    5584:      	st1.s	{ v18 }[1], [x11]
    5588:      	tbz	w10, #0x2, 0x5554 <_llm_rows.packet_batch.blocks+0x396c>
    558c:      	add	x11, x9, #0x8
    5590:      	st1.s	{ v18 }[2], [x11]
    5594:      	tbz	w10, #0x3, 0x5558 <_llm_rows.packet_batch.blocks+0x3970>
    5598:      	add	x11, x9, #0xc
    559c:      	st1.s	{ v18 }[3], [x11]
    55a0:      	and.16b	v17, v0, v17
    55a4:      	fdiv.4s	v17, v17, v4
    55a8:      	tbz	w10, #0x4, 0x5564 <_llm_rows.packet_batch.blocks+0x397c>
    55ac:      	str	s17, [x9, #0x10]
    55b0:      	tbz	w10, #0x5, 0x5568 <_llm_rows.packet_batch.blocks+0x3980>
    55b4:      	add	x11, x9, #0x14
    55b8:      	st1.s	{ v17 }[1], [x11]
    55bc:      	tbz	w10, #0x6, 0x556c <_llm_rows.packet_batch.blocks+0x3984>
    55c0:      	add	x11, x9, #0x18
    55c4:      	st1.s	{ v17 }[2], [x11]
    55c8:      	tbz	w10, #0x7, 0x550c <_llm_rows.packet_batch.blocks+0x3924>
    55cc:      	add	x9, x9, #0x1c
    55d0:      	st1.s	{ v17 }[3], [x9]
    55d4:      	b	0x550c <_llm_rows.packet_batch.blocks+0x3924>
    55d8:      	ldr	d0, [sp, #0x1b0]
    55dc:      	fmov	w8, s0
    55e0:      	ldr	q0, [sp, #0x1d0]
    55e4:      	zip1.8b	v0, v0, v0
    55e8:      	ushll.4s	v0, v0, #0x0
    55ec:      	shl.4s	v0, v0, #0x1f
    55f0:      	cmlt.4s	v0, v0, #0
    55f4:      	and.16b	v0, v0, v3
    55f8:      	fdiv.4s	v0, v0, v4
    55fc:      	ldr	q1, [sp, #0x160]
    5600:      	str	q1, [sp, #0x460]
    5604:      	ldp	q1, q3, [sp, #0x130]
    5608:      	str	q3, [sp, #0x470]
    560c:      	str	q1, [sp, #0x480]
    5610:      	ldr	q1, [sp, #0x150]
    5614:      	str	q1, [sp, #0x490]
    5618:      	and	x9, x14, #0x7
    561c:      	add	x10, sp, #0x460
    5620:      	ldr	x9, [x10, x9, lsl #3]
    5624:      	sub	x9, x9, x14
    5628:      	add	x9, x13, x9, lsl #2
    562c:      	tbnz	w8, #0x0, 0x56e4 <_llm_rows.packet_batch.blocks+0x3afc>
    5630:      	tbnz	w8, #0x1, 0x56ec <_llm_rows.packet_batch.blocks+0x3b04>
    5634:      	tbnz	w8, #0x2, 0x56f8 <_llm_rows.packet_batch.blocks+0x3b10>
    5638:      	tbz	w8, #0x3, 0x5644 <_llm_rows.packet_batch.blocks+0x3a5c>
    563c:      	add	x10, x9, #0xc
    5640:      	st1.s	{ v0 }[3], [x10]
    5644:      	ldr	q0, [sp, #0x1d0]
    5648:      	zip2.8b	v0, v0, v0
    564c:      	ushll.4s	v0, v0, #0x0
    5650:      	shl.4s	v0, v0, #0x1f
    5654:      	cmlt.4s	v0, v0, #0
    5658:      	and.16b	v0, v0, v2
    565c:      	fdiv.4s	v0, v0, v4
    5660:      	tbnz	w8, #0x4, 0x5708 <_llm_rows.packet_batch.blocks+0x3b20>
    5664:      	tbnz	w8, #0x5, 0x5710 <_llm_rows.packet_batch.blocks+0x3b28>
    5668:      	tbnz	w8, #0x6, 0x571c <_llm_rows.packet_batch.blocks+0x3b34>
    566c:      	tbz	w8, #0x7, 0x1cb0 <_llm_rows.packet_batch.blocks+0xc8>
    5670:      	b	0x5728 <_llm_rows.packet_batch.blocks+0x3b40>
    5674:      	fmov	x9, d2
    5678:      	ld1.b	{ v19 }[2], [x9]
    567c:      	tbz	w3, #0x3, 0x40a8 <_llm_rows.packet_batch.blocks+0x24c0>
    5680:      	mov.d	x9, v2[1]
    5684:      	ld1.b	{ v19 }[3], [x9]
    5688:      	adrp	x9, 0x5000 <_llm_rows.packet_batch.blocks+0x3418>
    568c:      	ldr	q2, [x9]
    5690:      	and.16b	v2, v4, v2
    5694:      	ldr	q3, [sp, #0x440]
    5698:      	add.2d	v2, v3, v2
    569c:      	tbz	w3, #0x4, 0x40c0 <_llm_rows.packet_batch.blocks+0x24d8>
    56a0:      	fmov	x9, d2
    56a4:      	ld1.b	{ v19 }[4], [x9]
    56a8:      	tbz	w3, #0x5, 0x40c4 <_llm_rows.packet_batch.blocks+0x24dc>
    56ac:      	mov.d	x9, v2[1]
    56b0:      	ld1.b	{ v19 }[5], [x9]
    56b4:      	adrp	x9, 0x5000 <_llm_rows.packet_batch.blocks+0x3418>
    56b8:      	ldr	q2, [x9]
    56bc:      	and.16b	v2, v9, v2
    56c0:      	ldr	q3, [sp, #0x370]
    56c4:      	add.2d	v3, v3, v2
    56c8:      	tbz	w3, #0x6, 0x40dc <_llm_rows.packet_batch.blocks+0x24f4>
    56cc:      	fmov	x9, d3
    56d0:      	ld1.b	{ v19 }[6], [x9]
    56d4:      	ldr	q2, [sp, #0x10]
    56d8:      	and.16b	v2, v10, v2
    56dc:      	tbnz	w3, #0x7, 0x40e8 <_llm_rows.packet_batch.blocks+0x2500>
    56e0:      	b	0x40f0 <_llm_rows.packet_batch.blocks+0x2508>
    56e4:      	str	s0, [x9]
    56e8:      	tbz	w8, #0x1, 0x5634 <_llm_rows.packet_batch.blocks+0x3a4c>
    56ec:      	add	x10, x9, #0x4
    56f0:      	st1.s	{ v0 }[1], [x10]
    56f4:      	tbz	w8, #0x2, 0x5638 <_llm_rows.packet_batch.blocks+0x3a50>
    56f8:      	add	x10, x9, #0x8
    56fc:      	st1.s	{ v0 }[2], [x10]
    5700:      	tbnz	w8, #0x3, 0x563c <_llm_rows.packet_batch.blocks+0x3a54>
    5704:      	b	0x5644 <_llm_rows.packet_batch.blocks+0x3a5c>
    5708:      	str	s0, [x9, #0x10]
    570c:      	tbz	w8, #0x5, 0x5668 <_llm_rows.packet_batch.blocks+0x3a80>
    5710:      	add	x10, x9, #0x14
    5714:      	st1.s	{ v0 }[1], [x10]
    5718:      	tbz	w8, #0x6, 0x566c <_llm_rows.packet_batch.blocks+0x3a84>
    571c:      	add	x10, x9, #0x18
    5720:      	st1.s	{ v0 }[2], [x10]
    5724:      	tbz	w8, #0x7, 0x1cb0 <_llm_rows.packet_batch.blocks+0xc8>
    5728:      	add	x8, x9, #0x1c
    572c:      	st1.s	{ v0 }[3], [x8]
    5730:      	b	0x1cb0 <_llm_rows.packet_batch.blocks+0xc8>
    5734:      	add	sp, sp, #0x1, lsl #12   ; =0x1000
    5738:      	add	sp, sp, #0xe0
    573c:      	ldp	x29, x30, [sp, #0x90]
    5740:      	ldp	x20, x19, [sp, #0x80]
    5744:      	ldp	x22, x21, [sp, #0x70]
    5748:      	ldp	x24, x23, [sp, #0x60]
    574c:      	ldp	x26, x25, [sp, #0x50]
    5750:      	ldp	x28, x27, [sp, #0x40]
    5754:      	ldp	d9, d8, [sp, #0x30]
    5758:      	ldp	d11, d10, [sp, #0x20]
    575c:      	ldp	d13, d12, [sp, #0x10]
    5760:      	ldp	d15, d14, [sp], #0xa0
    5764:      	ret

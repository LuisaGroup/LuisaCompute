
/private/tmp/luisa-expression-fusion.qXgTbC/capture/masked_softmax-17x65/off/object/tile_xir_w8_23370_1788930264099853_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0x90]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	sub	sp, sp, #0x5f0
      28:      	mov	x11, #0x0               ; =0
      2c:      	ldr	x10, [x0]
      30:      	ldr	w8, [x1]
      34:      	ldr	w9, [x1, #0x24]
      38:      	add	w8, w9, w8, lsl #5
      3c:      	lsr	w8, w8, #3
      40:      	dup.4s	v0, w8
      44:      	fmov	s1, w8
      48:      	ushll.2d	v1, v1, #0x0
      4c:      	fmov	x8, d1
      50:      	add	x8, x8, x8, lsl #6
      54:      	lsl	x8, x8, #2
      58:      	add	x9, x10, x8
      5c:      	ldp	q1, q2, [x9, #0xc0]
      60:      	add	x12, sp, #0x4d0
      64:      	stp	q1, q2, [x12, #0xc0]
      68:      	ldp	q1, q2, [x9, #0xe0]
      6c:      	stp	q1, q2, [x12, #0xe0]
      70:      	ldp	q1, q2, [x9, #0x80]
      74:      	stp	q1, q2, [x12, #0x80]
      78:      	ldp	q1, q2, [x9, #0xa0]
      7c:      	ldp	q3, q5, [x9, #0x40]
      80:      	ldp	q6, q7, [x9, #0x60]
      84:      	ldp	q16, q17, [x9]
      88:      	ldp	q18, q19, [x9, #0x20]
      8c:      	add	x9, x8, #0x100
      90:      	ldr	s4, [x10, x9]
      94:      	ldr	x10, [x0, #0x30]
      98:      	stp	q1, q2, [x12, #0xa0]
      9c:      	stp	q3, q5, [x12, #0x40]
      a0:      	stp	q6, q7, [x12, #0x60]
      a4:      	stp	q16, q17, [x12]
      a8:      	stp	q18, q19, [x12, #0x20]
      ac:      	str	q4, [x12, #0x100]
      b0:      	movi.2d	v1, #0000000000000000
      b4:      	adrp	x12, 0x0 <ltmp0>
      b8:      	ldr	q2, [x12]
      bc:      	adrp	x12, 0x0 <ltmp0>
      c0:      	ldr	q3, [x12]
      c4:      	adrp	x12, 0x0 <ltmp0>
      c8:      	ldr	q5, [x12]
      cc:      	adrp	x12, 0x0 <ltmp0>
      d0:      	ldr	q6, [x12]
      d4:      	mov	w12, #0x1               ; =1
      d8:      	dup.2d	v7, x12
      dc:      	add	x12, sp, #0x290
      e0:      	movi.2d	v16, #0000000000000000
      e4:      	movi.2d	v17, #0000000000000000
      e8:      	movi.2d	v18, #0000000000000000
      ec:      	shl.2d	v19, v1, #0x3
      f0:      	shl.2d	v20, v16, #0x3
      f4:      	shl.2d	v21, v17, #0x3
      f8:      	shl.2d	v22, v18, #0x3
      fc:      	orr.16b	v22, v22, v2
     100:      	orr.16b	v21, v21, v3
     104:      	orr.16b	v20, v20, v5
     108:      	orr.16b	v19, v19, v6
     10c:      	add	x11, x12, x11, lsl #6
     110:      	stp	q19, q20, [x11]
     114:      	stp	q21, q22, [x11, #0x20]
     118:      	add.2d	v17, v17, v7
     11c:      	add.2d	v16, v16, v7
     120:      	add.2d	v18, v18, v7
     124:      	add.2d	v1, v1, v7
     128:      	fmov	x11, d1
     12c:      	cmp	x11, #0x8
     130:      	b.lt	0xec <ltmp0+0xec>
     134:      	mov	x12, #0x0               ; =0
     138:      	mov	w11, #0x40              ; =64
     13c:      	str	x11, [sp, #0x490]
     140:      	mov	w11, #0x3f04            ; =16132
     144:      	movk	w11, #0x3f0, lsl #16
     148:      	dup.4s	v1, w11
     14c:      	umull2.2d	v2, v0, v1
     150:      	umull.2d	v3, v0, v1
     154:      	uzp2.4s	v3, v3, v2
     158:      	movi.4s	v5, #0x41
     15c:      	mov.16b	v7, v0
     160:      	mls.4s	v7, v3, v5
     164:      	umull.2d	v1, v0, v1
     168:      	uzp2.4s	v1, v1, v2
     16c:      	mls.4s	v0, v1, v5
     170:      	ushll2.2d	v5, v0, #0x0
     174:      	ushll2.2d	v6, v7, #0x0
     178:      	ushll.2d	v16, v0, #0x0
     17c:      	ushll.2d	v7, v7, #0x0
     180:      	movi.2d	v17, #0000000000000000
     184:      	add	x11, sp, #0x248
     188:      	dup.2d	v18, x11
     18c:      	adrp	x11, 0x0 <ltmp0>
     190:      	ldr	q0, [x11]
     194:      	adrp	x11, 0x0 <ltmp0>
     198:      	ldr	q1, [x11]
     19c:      	adrp	x11, 0x0 <ltmp0>
     1a0:      	ldr	q2, [x11]
     1a4:      	mov	w11, #0x1               ; =1
     1a8:      	dup.2d	v19, x11
     1ac:      	adrp	x11, 0x0 <ltmp0>
     1b0:      	ldr	q3, [x11]
     1b4:      	add	x11, sp, #0x290
     1b8:      	movi.8b	v20, #0x1
     1bc:      	movi.2d	v21, #0000000000000000
     1c0:      	movi.2d	v22, #0000000000000000
     1c4:      	movi.2d	v23, #0000000000000000
     1c8:      	add	x12, x11, x12, lsl #6
     1cc:      	ldp	q25, q24, [x12, #0x20]
     1d0:      	ldp	q26, q27, [x12]
     1d4:      	add.2d	v28, v23, v3
     1d8:      	add.2d	v28, v28, v18
     1dc:      	add.2d	v29, v22, v2
     1e0:      	add.2d	v30, v21, v1
     1e4:      	add.2d	v31, v17, v0
     1e8:      	add.2d	v31, v31, v18
     1ec:      	cmge.2d	v27, v6, v27
     1f0:      	cmge.2d	v26, v7, v26
     1f4:      	uzp1.4s	v26, v26, v27
     1f8:      	cmge.2d	v25, v16, v25
     1fc:      	cmge.2d	v24, v5, v24
     200:      	uzp1.4s	v24, v25, v24
     204:      	uzp1.8h	v24, v26, v24
     208:      	xtn.8b	v24, v24
     20c:      	and.8b	v24, v24, v20
     210:      	mov.d	x12, v31[1]
     214:      	fmov	x13, d31
     218:      	str	b24, [x13]
     21c:      	st1.b	{ v24 }[1], [x12]
     220:      	add.2d	v25, v30, v18
     224:      	mov.d	x12, v25[1]
     228:      	fmov	x13, d25
     22c:      	st1.b	{ v24 }[2], [x13]
     230:      	add.2d	v25, v29, v18
     234:      	st1.b	{ v24 }[3], [x12]
     238:      	mov.d	x12, v25[1]
     23c:      	fmov	x13, d25
     240:      	st1.b	{ v24 }[4], [x13]
     244:      	st1.b	{ v24 }[5], [x12]
     248:      	mov.d	x12, v28[1]
     24c:      	fmov	x13, d28
     250:      	st1.b	{ v24 }[6], [x13]
     254:      	st1.b	{ v24 }[7], [x12]
     258:      	add.2d	v22, v22, v19
     25c:      	add.2d	v21, v21, v19
     260:      	add.2d	v23, v23, v19
     264:      	add.2d	v17, v17, v19
     268:      	fmov	x12, d17
     26c:      	cmp	x12, #0x8
     270:      	b.lt	0x1c8 <ltmp0+0x1c8>
     274:      	mov	x11, #0x0               ; =0
     278:      	add	x12, sp, #0x248
     27c:      	dup.2d	v5, x12
     280:      	adrp	x12, 0x0 <ltmp0>
     284:      	ldr	q16, [x12]
     288:      	adrp	x12, 0x0 <ltmp0>
     28c:      	ldr	q6, [x12]
     290:      	add.2d	v6, v5, v6
     294:      	cmgt.2d	v7, v7, v16
     298:      	xtn.2s	v7, v7
     29c:      	uzp1.4h	v7, v7, v0
     2a0:      	uzp1.8b	v7, v7, v0
     2a4:      	movi.8b	v16, #0x1
     2a8:      	and.8b	v7, v7, v16
     2ac:      	fmov	x12, d6
     2b0:      	str	b7, [x12]
     2b4:      	movi.2d	v7, #0000000000000000
     2b8:      	add	x12, sp, #0x4d0
     2bc:      	mov	w13, #0xf2ca            ; =62154
     2c0:      	movk	w13, #0xf149, lsl #16
     2c4:      	dup.4s	v16, w13
     2c8:      	mov	w13, #0x1               ; =1
     2cc:      	dup.2d	v17, x13
     2d0:      	add	x13, sp, #0x128
     2d4:      	movi.2d	v18, #0000000000000000
     2d8:      	movi.2d	v19, #0000000000000000
     2dc:      	movi.2d	v20, #0000000000000000
     2e0:      	add.2d	v21, v20, v3
     2e4:      	add.2d	v21, v21, v5
     2e8:      	add.2d	v22, v19, v2
     2ec:      	add.2d	v22, v22, v5
     2f0:      	add.2d	v23, v18, v1
     2f4:      	add.2d	v23, v23, v5
     2f8:      	add.2d	v24, v7, v0
     2fc:      	add.2d	v24, v24, v5
     300:      	mov.d	x14, v24[1]
     304:      	mov.d	x15, v23[1]
     308:      	fmov	x16, d24
     30c:      	fmov	x17, d23
     310:      	mov.d	x0, v22[1]
     314:      	fmov	x1, d22
     318:      	ldr	b22, [x16]
     31c:      	ld1.b	{ v22 }[1], [x14]
     320:      	ld1.b	{ v22 }[2], [x17]
     324:      	mov.d	x14, v21[1]
     328:      	ld1.b	{ v22 }[3], [x15]
     32c:      	ld1.b	{ v22 }[4], [x1]
     330:      	ld1.b	{ v22 }[5], [x0]
     334:      	fmov	x15, d21
     338:      	ld1.b	{ v22 }[6], [x15]
     33c:      	ld1.b	{ v22 }[7], [x14]
     340:      	cmeq.8b	v21, v22, #0
     344:      	sshll.8h	v21, v21, #0x0
     348:      	sshll2.4s	v22, v21, #0x0
     34c:      	lsl	x11, x11, #5
     350:      	add	x14, x12, x11
     354:      	ldp	q24, q23, [x14]
     358:      	sshll.4s	v21, v21, #0x0
     35c:      	bsl.16b	v21, v16, v24
     360:      	bsl.16b	v22, v16, v23
     364:      	add	x11, x13, x11
     368:      	stp	q21, q22, [x11]
     36c:      	add.2d	v19, v19, v17
     370:      	add.2d	v18, v18, v17
     374:      	add.2d	v20, v20, v17
     378:      	add.2d	v7, v7, v17
     37c:      	fmov	x11, d7
     380:      	cmp	x11, #0x8
     384:      	b.lt	0x2e0 <ltmp0+0x2e0>
     388:      	mov	x7, #0x0                ; =0
     38c:      	fmov	x11, d6
     390:      	ldr	b5, [x11]
     394:      	cmeq.8b	v5, v5, #0
     398:      	sshll.8h	v5, v5, #0x0
     39c:      	sshll.4s	v6, v5, #0x0
     3a0:      	mov	w11, #0xf2ca            ; =62154
     3a4:      	movk	w11, #0xf149, lsl #16
     3a8:      	dup.4s	v7, w11
     3ac:      	bsl.16b	v6, v7, v4
     3b0:      	add	x11, sp, #0x129
     3b4:      	ldur	q4, [x11, #0xff]
     3b8:      	mov.s	v4[0], v6[0]
     3bc:      	stur	q4, [x11, #0xff]
     3c0:      	add	x11, sp, #0x29
     3c4:      	ldur	q7, [x11, #0xff]
     3c8:      	add	x11, sp, #0x39
     3cc:      	ldur	q16, [x11, #0xff]
     3d0:      	add	x11, sp, #0x59
     3d4:      	ldur	q17, [x11, #0xff]
     3d8:      	add	x11, sp, #0x49
     3dc:      	ldur	q18, [x11, #0xff]
     3e0:      	add	x11, sp, #0x69
     3e4:      	ldur	q19, [x11, #0xff]
     3e8:      	add	x11, sp, #0x79
     3ec:      	ldur	q20, [x11, #0xff]
     3f0:      	add	x11, sp, #0x99
     3f4:      	ldur	q21, [x11, #0xff]
     3f8:      	add	x11, sp, #0x89
     3fc:      	ldur	q22, [x11, #0xff]
     400:      	add	x11, sp, #0x119
     404:      	ldur	q23, [x11, #0xff]
     408:      	add	x11, sp, #0x109
     40c:      	ldur	q24, [x11, #0xff]
     410:      	fmaxnm.4s	v22, v22, v24
     414:      	fmaxnm.4s	v21, v21, v23
     418:      	add	x11, sp, #0xe9
     41c:      	ldur	q23, [x11, #0xff]
     420:      	add	x11, sp, #0xf9
     424:      	ldur	q24, [x11, #0xff]
     428:      	fmaxnm.4s	v20, v20, v24
     42c:      	fmaxnm.4s	v19, v19, v23
     430:      	add	x11, sp, #0xd9
     434:      	ldur	q23, [x11, #0xff]
     438:      	add	x11, sp, #0xc9
     43c:      	ldur	q24, [x11, #0xff]
     440:      	fmaxnm.4s	v18, v18, v24
     444:      	fmaxnm.4s	v17, v17, v23
     448:      	add	x11, sp, #0xa9
     44c:      	ldur	q23, [x11, #0xff]
     450:      	add	x11, sp, #0xb9
     454:      	ldur	q24, [x11, #0xff]
     458:      	fmaxnm.4s	v16, v16, v24
     45c:      	fmaxnm.4s	v7, v7, v23
     460:      	movi.2d	v23, #0000000000000000
     464:      	mov.s	v23[0], v6[0]
     468:      	movi.2d	v6, #0000000000000000
     46c:      	fmaxnm.4s	v23, v7, v23
     470:      	mov.s	v7[0], v23[0]
     474:      	fmaxnm.4s	v16, v16, v17
     478:      	fmaxnm.4s	v7, v7, v18
     47c:      	fmaxnm.4s	v7, v7, v19
     480:      	fmaxnm.4s	v16, v16, v20
     484:      	fmaxnm.4s	v16, v16, v21
     488:      	fmaxnm.4s	v7, v7, v22
     48c:      	rev64.4s	v17, v7
     490:      	rev64.4s	v18, v16
     494:      	fmaxnm.4s	v16, v16, v18
     498:      	fmaxnm.4s	v7, v7, v17
     49c:      	ext.16b	v17, v7, v7, #0x8
     4a0:      	ext.16b	v18, v16, v16, #0x8
     4a4:      	fmaxnm.4s	v16, v16, v18
     4a8:      	fmaxnm.4s	v7, v7, v17
     4ac:      	fmaxnm.4s	v7, v7, v16
     4b0:      	mov	w11, #-0x800000         ; =-8388608
     4b4:      	fmov	s16, w11
     4b8:      	fmaxnm	s7, s7, s16
     4bc:      	dup.4s	v16, v7[0]
     4c0:      	add	x11, sp, #0x248
     4c4:      	add	x12, sp, #0x128
     4c8:      	mov	w13, #-0x3d300000       ; =-1026555904
     4cc:      	mov	w14, #0x42c80000        ; =1120403456
     4d0:      	mov	w15, #0xaa3b            ; =43579
     4d4:      	movk	w15, #0x3fb8, lsl #16
     4d8:      	movi.4s	v17, #0x4b, lsl #24
     4dc:      	mvni.4s	v18, #0x80, lsl #24
     4e0:      	mov	w16, #0x7200            ; =29184
     4e4:      	movk	w16, #0xbf31, lsl #16
     4e8:      	mov	w17, #0xbe8e            ; =48782
     4ec:      	movk	w17, #0xb5bf, lsl #16
     4f0:      	mov	w0, #0x2bda             ; =11226
     4f4:      	movk	w0, #0x3950, lsl #16
     4f8:      	mov	w1, #0x96c9             ; =38601
     4fc:      	movk	w1, #0x3ab6, lsl #16
     500:      	mov	w2, #0x88a6             ; =34982
     504:      	movk	w2, #0x3c08, lsl #16
     508:      	mov	w3, #0xaa7a             ; =43642
     50c:      	movk	w3, #0x3d2a, lsl #16
     510:      	mov	w4, #0xaaab             ; =43691
     514:      	movk	w4, #0x3e2a, lsl #16
     518:      	movi.4s	v19, #0x3f, lsl #24
     51c:      	mvni.4s	v20, #0x7f, msl #16
     520:      	fneg.4s	v20, v20
     524:      	mvni.4s	v21, #0x3f, msl #16
     528:      	fneg.4s	v21, v21
     52c:      	add	x5, sp, #0x8
     530:      	mov	w6, #0x1                ; =1
     534:      	movi.2d	v22, #0000000000000000
     538:      	movi.2d	v23, #0000000000000000
     53c:      	movi.2d	v24, #0000000000000000
     540:      	dup.2d	v25, x11
     544:      	add.2d	v26, v24, v3
     548:      	add.2d	v26, v26, v25
     54c:      	add.2d	v27, v23, v2
     550:      	add.2d	v27, v27, v25
     554:      	add.2d	v28, v22, v1
     558:      	add.2d	v29, v6, v0
     55c:      	add.2d	v28, v28, v25
     560:      	add.2d	v25, v29, v25
     564:      	mov.d	x22, v25[1]
     568:      	fmov	x23, d25
     56c:      	mov.d	x24, v28[1]
     570:      	fmov	x25, d28
     574:      	mov.d	x20, v27[1]
     578:      	fmov	x26, d27
     57c:      	mov.d	x19, v26[1]
     580:      	fmov	x21, d26
     584:      	ldr	b25, [x23]
     588:      	lsl	x7, x7, #5
     58c:      	add	x23, x12, x7
     590:      	ld1.b	{ v25 }[1], [x22]
     594:      	ldp	q27, q26, [x23]
     598:      	fsub.4s	v26, v26, v16
     59c:      	fsub.4s	v27, v27, v16
     5a0:      	ld1.b	{ v25 }[2], [x25]
     5a4:      	dup.4s	v28, w13
     5a8:      	fcmge.4s	v30, v27, v28
     5ac:      	fcmge.4s	v31, v26, v28
     5b0:      	ld1.b	{ v25 }[3], [x24]
     5b4:      	dup.4s	v29, w14
     5b8:      	fcmge.4s	v8, v29, v27
     5bc:      	fcmge.4s	v9, v29, v26
     5c0:      	ld1.b	{ v25 }[4], [x26]
     5c4:      	and.16b	v31, v31, v9
     5c8:      	and.16b	v30, v30, v8
     5cc:      	and.16b	v30, v30, v27
     5d0:      	and.16b	v31, v31, v26
     5d4:      	ld1.b	{ v25 }[5], [x20]
     5d8:      	dup.4s	v8, w15
     5dc:      	fmul.4s	v9, v31, v8
     5e0:      	fmul.4s	v8, v30, v8
     5e4:      	ld1.b	{ v25 }[6], [x21]
     5e8:      	mov.16b	v10, v18
     5ec:      	bsl.16b	v10, v17, v8
     5f0:      	mov.16b	v11, v18
     5f4:      	bsl.16b	v11, v17, v9
     5f8:      	fadd.4s	v9, v9, v11
     5fc:      	fadd.4s	v8, v8, v10
     600:      	ld1.b	{ v25 }[7], [x19]
     604:      	fsub.4s	v8, v8, v10
     608:      	fsub.4s	v9, v9, v11
     60c:      	fcvtzs.4s	v9, v9
     610:      	fcvtzs.4s	v8, v8
     614:      	scvtf.4s	v10, v8
     618:      	cmeq.8b	v25, v25, #0
     61c:      	scvtf.4s	v11, v9
     620:      	dup.4s	v12, w16
     624:      	fmul.4s	v13, v11, v12
     628:      	fmul.4s	v12, v10, v12
     62c:      	sshll.8h	v25, v25, #0x0
     630:      	fadd.4s	v12, v30, v12
     634:      	fadd.4s	v31, v31, v13
     638:      	dup.4s	v13, w17
     63c:      	fmul.4s	v10, v10, v13
     640:      	sshll2.4s	v30, v25, #0x0
     644:      	fmul.4s	v11, v11, v13
     648:      	fadd.4s	v31, v31, v11
     64c:      	fadd.4s	v10, v12, v10
     650:      	dup.4s	v11, w0
     654:      	fmul.4s	v12, v10, v11
     658:      	fmul.4s	v11, v31, v11
     65c:      	dup.4s	v13, w1
     660:      	fadd.4s	v11, v11, v13
     664:      	fadd.4s	v12, v12, v13
     668:      	fmul.4s	v12, v10, v12
     66c:      	fmul.4s	v11, v31, v11
     670:      	dup.4s	v13, w2
     674:      	fadd.4s	v11, v11, v13
     678:      	fadd.4s	v12, v12, v13
     67c:      	fmul.4s	v12, v10, v12
     680:      	fmul.4s	v11, v31, v11
     684:      	dup.4s	v13, w3
     688:      	fadd.4s	v11, v11, v13
     68c:      	fadd.4s	v12, v12, v13
     690:      	fmul.4s	v12, v10, v12
     694:      	fmul.4s	v11, v31, v11
     698:      	dup.4s	v13, w4
     69c:      	fadd.4s	v11, v11, v13
     6a0:      	fadd.4s	v12, v12, v13
     6a4:      	fmul.4s	v12, v10, v12
     6a8:      	fmul.4s	v11, v31, v11
     6ac:      	fadd.4s	v11, v11, v19
     6b0:      	fadd.4s	v12, v12, v19
     6b4:      	fmul.4s	v13, v31, v31
     6b8:      	fmul.4s	v14, v10, v10
     6bc:      	sshll.4s	v15, v25, #0x0
     6c0:      	fmul.4s	v25, v14, v12
     6c4:      	fmul.4s	v11, v13, v11
     6c8:      	fadd.4s	v31, v31, v11
     6cc:      	fadd.4s	v10, v10, v25
     6d0:      	fmov.4s	v25, #1.00000000
     6d4:      	fadd.4s	v10, v10, v25
     6d8:      	sshr.4s	v11, v8, #0x1
     6dc:      	sshr.4s	v12, v9, #0x1
     6e0:      	shl.4s	v13, v12, #0x17
     6e4:      	shl.4s	v14, v11, #0x17
     6e8:      	add.4s	v14, v14, v25
     6ec:      	fadd.4s	v31, v31, v25
     6f0:      	add.4s	v13, v13, v25
     6f4:      	fmul.4s	v31, v31, v13
     6f8:      	sub.4s	v9, v9, v12
     6fc:      	sub.4s	v8, v8, v11
     700:      	shl.4s	v8, v8, #0x17
     704:      	fmul.4s	v10, v10, v14
     708:      	shl.4s	v9, v9, #0x17
     70c:      	add.4s	v9, v9, v25
     710:      	add.4s	v8, v8, v25
     714:      	fmul.4s	v8, v10, v8
     718:      	fcmgt.4s	v10, v28, v26
     71c:      	fmul.4s	v31, v31, v9
     720:      	bic.16b	v31, v31, v10
     724:      	fcmgt.4s	v28, v28, v27
     728:      	bic.16b	v28, v8, v28
     72c:      	fcmgt.4s	v8, v26, v29
     730:      	fcmgt.4s	v29, v27, v29
     734:      	bit.16b	v28, v20, v29
     738:      	mov.16b	v29, v8
     73c:      	bsl.16b	v29, v20, v31
     740:      	fcmeq.4s	v27, v27, v27
     744:      	fcmeq.4s	v26, v26, v26
     748:      	bsl.16b	v26, v29, v21
     74c:      	bsl.16b	v27, v28, v21
     750:      	bic.16b	v27, v27, v15
     754:      	bic.16b	v26, v26, v30
     758:      	add	x7, x5, x7
     75c:      	dup.2d	v28, x6
     760:      	stp	q27, q26, [x7]
     764:      	add.2d	v23, v23, v28
     768:      	add.2d	v22, v22, v28
     76c:      	add.2d	v24, v24, v28
     770:      	add.2d	v6, v6, v28
     774:      	fmov	x7, d6
     778:      	cmp	x7, #0x8
     77c:      	b.lt	0x540 <ltmp0+0x540>
     780:      	fsub.4s	v1, v4, v7
     784:      	movi.2d	v0, #0000000000000000
     788:      	mov.s	v0[0], v1[0]
     78c:      	mov	w11, #-0x3d300000       ; =-1026555904
     790:      	dup.4s	v2, w11
     794:      	sshll.4s	v1, v5, #0x0
     798:      	fcmge.4s	v3, v0, v2
     79c:      	mov	w11, #0x42c80000        ; =1120403456
     7a0:      	dup.4s	v4, w11
     7a4:      	fcmge.4s	v5, v4, v0
     7a8:      	and.16b	v3, v3, v5
     7ac:      	and.16b	v3, v3, v0
     7b0:      	mov	w11, #0xaa3b            ; =43579
     7b4:      	movk	w11, #0x3fb8, lsl #16
     7b8:      	dup.4s	v5, w11
     7bc:      	fmul.4s	v5, v3, v5
     7c0:      	movi.4s	v6, #0x4b, lsl #24
     7c4:      	mvni.4s	v7, #0x80, lsl #24
     7c8:      	bif.16b	v6, v5, v7
     7cc:      	fadd.4s	v5, v5, v6
     7d0:      	fsub.4s	v5, v5, v6
     7d4:      	fcvtzs.4s	v5, v5
     7d8:      	scvtf.4s	v6, v5
     7dc:      	mov	w11, #0x7200            ; =29184
     7e0:      	movk	w11, #0xbf31, lsl #16
     7e4:      	dup.4s	v7, w11
     7e8:      	fmul.4s	v7, v6, v7
     7ec:      	fadd.4s	v3, v3, v7
     7f0:      	mov	w11, #0xbe8e            ; =48782
     7f4:      	movk	w11, #0xb5bf, lsl #16
     7f8:      	dup.4s	v7, w11
     7fc:      	fmul.4s	v6, v6, v7
     800:      	fadd.4s	v3, v3, v6
     804:      	mov	w11, #0x2bda            ; =11226
     808:      	movk	w11, #0x3950, lsl #16
     80c:      	dup.4s	v6, w11
     810:      	fmul.4s	v6, v3, v6
     814:      	mov	w11, #0x96c9            ; =38601
     818:      	movk	w11, #0x3ab6, lsl #16
     81c:      	dup.4s	v7, w11
     820:      	fadd.4s	v6, v6, v7
     824:      	fmul.4s	v6, v3, v6
     828:      	mov	w11, #0x88a6            ; =34982
     82c:      	movk	w11, #0x3c08, lsl #16
     830:      	dup.4s	v7, w11
     834:      	fadd.4s	v6, v6, v7
     838:      	fmul.4s	v6, v3, v6
     83c:      	mov	w11, #0xaa7a            ; =43642
     840:      	movk	w11, #0x3d2a, lsl #16
     844:      	dup.4s	v7, w11
     848:      	fadd.4s	v6, v6, v7
     84c:      	fmul.4s	v6, v3, v6
     850:      	mov	w11, #0xaaab            ; =43691
     854:      	movk	w11, #0x3e2a, lsl #16
     858:      	dup.4s	v7, w11
     85c:      	fadd.4s	v6, v6, v7
     860:      	fmul.4s	v6, v3, v6
     864:      	movi.4s	v7, #0x3f, lsl #24
     868:      	fadd.4s	v6, v6, v7
     86c:      	fmul.4s	v7, v3, v3
     870:      	fmul.4s	v6, v7, v6
     874:      	fadd.4s	v3, v3, v6
     878:      	fadd.4s	v3, v3, v25
     87c:      	sshr.4s	v6, v5, #0x1
     880:      	shl.4s	v7, v6, #0x17
     884:      	add.4s	v7, v7, v25
     888:      	fmul.4s	v3, v3, v7
     88c:      	sub.4s	v5, v5, v6
     890:      	shl.4s	v5, v5, #0x17
     894:      	add.4s	v5, v5, v25
     898:      	fmul.4s	v3, v3, v5
     89c:      	fcmgt.4s	v2, v2, v0
     8a0:      	bic.16b	v2, v3, v2
     8a4:      	fcmgt.4s	v3, v0, v4
     8a8:      	mvni.4s	v4, #0x7f, msl #16
     8ac:      	fneg.4s	v4, v4
     8b0:      	bit.16b	v2, v4, v3
     8b4:      	fcmeq.4s	v0, v0, v0
     8b8:      	mvni.4s	v3, #0x3f, msl #16
     8bc:      	fneg.4s	v3, v3
     8c0:      	bsl.16b	v0, v2, v3
     8c4:      	bic.16b	v0, v0, v1
     8c8:      	ldur	q3, [sp, #0x8]
     8cc:      	ldur	q4, [sp, #0x18]
     8d0:      	ldur	q5, [sp, #0x28]
     8d4:      	ldur	q6, [sp, #0x38]
     8d8:      	ldur	q7, [sp, #0x48]
     8dc:      	ldur	q16, [sp, #0x58]
     8e0:      	ldur	q17, [sp, #0x68]
     8e4:      	ldur	q18, [sp, #0x78]
     8e8:      	ldur	q1, [sp, #0xe8]
     8ec:      	ldur	q2, [sp, #0xf8]
     8f0:      	fadd.4s	v19, v18, v2
     8f4:      	fadd.4s	v20, v17, v1
     8f8:      	ldur	q21, [sp, #0xc8]
     8fc:      	ldur	q22, [sp, #0xd8]
     900:      	fadd.4s	v23, v16, v22
     904:      	fadd.4s	v24, v7, v21
     908:      	ldur	q25, [sp, #0xa8]
     90c:      	ldur	q26, [sp, #0xb8]
     910:      	fadd.4s	v27, v6, v26
     914:      	fadd.4s	v28, v5, v25
     918:      	ldur	q29, [sp, #0x88]
     91c:      	ldur	q30, [sp, #0x98]
     920:      	fadd.4s	v31, v4, v30
     924:      	fadd.4s	v8, v3, v29
     928:      	fadd.4s	v9, v0, v8
     92c:      	mov.s	v8[0], v9[0]
     930:      	fadd.4s	v28, v28, v8
     934:      	fadd.4s	v27, v27, v31
     938:      	fadd.4s	v24, v24, v28
     93c:      	fadd.4s	v23, v23, v27
     940:      	fadd.4s	v20, v20, v24
     944:      	fadd.4s	v19, v19, v23
     948:      	rev64.4s	v23, v20
     94c:      	rev64.4s	v24, v19
     950:      	fadd.4s	v20, v20, v23
     954:      	fadd.4s	v19, v19, v24
     958:      	dup.4s	v23, v20[2]
     95c:      	dup.4s	v24, v19[2]
     960:      	fadd.4s	v20, v20, v23
     964:      	fadd.4s	v19, v19, v24
     968:      	fadd.4s	v19, v20, v19
     96c:      	movi	d20, #0000000000000000
     970:      	fadd	s19, s19, s20
     974:      	dup.4s	v20, v19[0]
     978:      	add	x8, x10, x8
     97c:      	fdiv.4s	v3, v3, v20
     980:      	fdiv.4s	v4, v4, v20
     984:      	stp	q3, q4, [x8]
     988:      	fdiv.4s	v3, v5, v20
     98c:      	fdiv.4s	v4, v6, v20
     990:      	stp	q3, q4, [x8, #0x20]
     994:      	fdiv.4s	v3, v7, v20
     998:      	fdiv.4s	v4, v16, v20
     99c:      	stp	q3, q4, [x8, #0x40]
     9a0:      	fdiv.4s	v3, v17, v20
     9a4:      	fdiv.4s	v4, v18, v20
     9a8:      	stp	q3, q4, [x8, #0x60]
     9ac:      	fdiv.4s	v3, v29, v20
     9b0:      	fdiv.4s	v4, v30, v20
     9b4:      	stp	q3, q4, [x8, #0x80]
     9b8:      	fdiv.4s	v3, v25, v20
     9bc:      	fdiv.4s	v4, v26, v20
     9c0:      	stp	q3, q4, [x8, #0xa0]
     9c4:      	fdiv.4s	v3, v21, v20
     9c8:      	fdiv.4s	v4, v22, v20
     9cc:      	stp	q3, q4, [x8, #0xc0]
     9d0:      	fdiv.4s	v1, v1, v20
     9d4:      	fdiv.4s	v2, v2, v20
     9d8:      	stp	q1, q2, [x8, #0xe0]
     9dc:      	fdiv.4s	v0, v0, v19
     9e0:      	str	s0, [x10, x9]
     9e4:      	add	sp, sp, #0x5f0
     9e8:      	ldp	x20, x19, [sp, #0x80]
     9ec:      	ldp	x22, x21, [sp, #0x70]
     9f0:      	ldp	x24, x23, [sp, #0x60]
     9f4:      	ldp	x26, x25, [sp, #0x50]
     9f8:      	ldp	x28, x27, [sp, #0x40]
     9fc:      	ldp	d9, d8, [sp, #0x30]
     a00:      	ldp	d11, d10, [sp, #0x20]
     a04:      	ldp	d13, d12, [sp, #0x10]
     a08:      	ldp	d15, d14, [sp], #0x90
     a0c:      	ret

0000000000000a10 <_llm_rows.packet_batch.blocks>:
     a10:      	stp	d15, d14, [sp, #-0xa0]!
     a14:      	stp	d13, d12, [sp, #0x10]
     a18:      	stp	d11, d10, [sp, #0x20]
     a1c:      	stp	d9, d8, [sp, #0x30]
     a20:      	stp	x28, x27, [sp, #0x40]
     a24:      	stp	x26, x25, [sp, #0x50]
     a28:      	stp	x24, x23, [sp, #0x60]
     a2c:      	stp	x22, x21, [sp, #0x70]
     a30:      	stp	x20, x19, [sp, #0x80]
     a34:      	stp	x29, x30, [sp, #0x90]
     a38:      	sub	sp, sp, #0xf80
     a3c:      	str	x0, [sp, #0x208]
     a40:      	cbz	w3, 0x2ab8 <_llm_rows.packet_batch.blocks+0x20a8>
     a44:      	mov	x21, x3
     a48:      	mov	x20, x2
     a4c:      	mov	w22, #0x0               ; =0
     a50:      	add	x23, sp, #0x998
     a54:      	add	x8, sp, #0xbd8
     a58:      	dup.2d	v0, x8
     a5c:      	str	q0, [sp, #0x20]
     a60:      	adrp	x8, 0x0 <ltmp0>
     a64:      	ldr	q0, [x8]
     a68:      	str	q0, [sp, #0x10]
     a6c:      	adrp	x8, 0x0 <ltmp0>
     a70:      	ldr	q0, [x8]
     a74:      	str	q0, [sp, #0x190]
     a78:      	adrp	x8, 0x0 <ltmp0>
     a7c:      	ldr	q0, [x8]
     a80:      	str	q0, [sp, #0x180]
     a84:      	movi.2s	v8, #0x41
     a88:      	mvni.4s	v0, #0x7f, msl #16
     a8c:      	fneg.4s	v1, v0
     a90:      	mvni.4s	v0, #0x3f, msl #16
     a94:      	fneg.4s	v0, v0
     a98:      	stp	q0, q1, [sp, #0x240]
     a9c:      	add	x24, sp, #0xab8
     aa0:      	mov	w27, #0x4               ; =4
     aa4:      	ldp	w9, w8, [x2, #0x2c]
     aa8:      	str	w9, [sp, #0x204]
     aac:      	str	w8, [sp, #0x200]
     ab0:      	ldp	w19, w12, [x2]
     ab4:      	ldp	w25, w8, [x2, #0x8]
     ab8:      	str	x8, [sp, #0x1f8]
     abc:      	str	w3, [sp, #0x17c]
     ac0:      	b	0xb0c <_llm_rows.packet_batch.blocks+0xfc>
     ac4:      	mov	w8, #0x18               ; =24
     ac8:      	str	w8, [x20, #0x24]
     acc:      	ldr	w21, [sp, #0x17c]
     ad0:      	add	w8, w19, #0x1
     ad4:      	ldr	w9, [sp, #0x204]
     ad8:      	cmp	w8, w9
     adc:      	cset	w8, eq
     ae0:      	csinc	w19, wzr, w19, eq
     ae4:      	cinc	w9, w12, eq
     ae8:      	ldr	w10, [sp, #0x200]
     aec:      	cmp	w9, w10
     af0:      	cset	w10, eq
     af4:      	ands	w8, w8, w10
     af8:      	csel	w12, wzr, w9, ne
     afc:      	add	w25, w25, w8
     b00:      	add	w22, w22, #0x1
     b04:      	cmp	w22, w21
     b08:      	b.eq	0x2ab8 <_llm_rows.packet_batch.blocks+0x20a8>
     b0c:      	ubfiz	x8, x19, #5, #32
     b10:      	ldr	x13, [sp, #0x1f8]
     b14:      	cmp	x8, x13
     b18:      	csel	x9, x8, xzr, ls
     b1c:      	subs	x10, x13, x9
     b20:      	cmp	x10, #0x20
     b24:      	mov	w11, #0x20              ; =32
     b28:      	csel	x10, x10, x11, lo
     b2c:      	cmp	x13, x9
     b30:      	stp	w19, w12, [x20]
     b34:      	str	w25, [x20, #0x8]
     b38:      	str	wzr, [x20, #0x24]
     b3c:      	ccmp	x8, x13, #0x2, hi
     b40:      	csel	x28, x10, xzr, ls
     b44:      	cmp	x28, #0x20
     b48:      	b.lo	0xba4 <_llm_rows.packet_batch.blocks+0x194>
     b4c:      	ldr	x28, [sp, #0x208]
     b50:      	mov	x0, x28
     b54:      	mov	x1, x20
     b58:      	mov	x26, x12
     b5c:      	bl	0xb5c <_llm_rows.packet_batch.blocks+0x14c>
     b60:      	mov	w8, #0x8                ; =8
     b64:      	str	w8, [x20, #0x24]
     b68:      	mov	x0, x28
     b6c:      	mov	x1, x20
     b70:      	bl	0xb70 <_llm_rows.packet_batch.blocks+0x160>
     b74:      	mov	w8, #0x10               ; =16
     b78:      	str	w8, [x20, #0x24]
     b7c:      	mov	x0, x28
     b80:      	mov	x1, x20
     b84:      	bl	0xb84 <_llm_rows.packet_batch.blocks+0x174>
     b88:      	mov	w8, #0x18               ; =24
     b8c:      	str	w8, [x20, #0x24]
     b90:      	mov	x0, x28
     b94:      	mov	x1, x20
     b98:      	bl	0xb98 <_llm_rows.packet_batch.blocks+0x188>
     b9c:      	mov	x12, x26
     ba0:      	b	0xad0 <_llm_rows.packet_batch.blocks+0xc0>
     ba4:      	lsr	x21, x28, #3
     ba8:      	cmp	x28, #0x8
     bac:      	b.lo	0xc08 <_llm_rows.packet_batch.blocks+0x1f8>
     bb0:      	str	wzr, [x20, #0x24]
     bb4:      	ldr	x0, [sp, #0x208]
     bb8:      	mov	x1, x20
     bbc:      	mov	x26, x12
     bc0:      	bl	0xbc0 <_llm_rows.packet_batch.blocks+0x1b0>
     bc4:      	mov	x12, x26
     bc8:      	cmp	x21, #0x1
     bcc:      	b.eq	0xc08 <_llm_rows.packet_batch.blocks+0x1f8>
     bd0:      	mov	w8, #0x8                ; =8
     bd4:      	str	w8, [x20, #0x24]
     bd8:      	ldr	x0, [sp, #0x208]
     bdc:      	mov	x1, x20
     be0:      	bl	0xbe0 <_llm_rows.packet_batch.blocks+0x1d0>
     be4:      	mov	x12, x26
     be8:      	cmp	x21, #0x2
     bec:      	b.eq	0xc08 <_llm_rows.packet_batch.blocks+0x1f8>
     bf0:      	mov	w8, #0x10               ; =16
     bf4:      	str	w8, [x20, #0x24]
     bf8:      	ldr	x0, [sp, #0x208]
     bfc:      	mov	x1, x20
     c00:      	bl	0xc00 <_llm_rows.packet_batch.blocks+0x1f0>
     c04:      	mov	x12, x26
     c08:      	and	w8, w28, #0x7
     c0c:      	cbz	w8, 0xac4 <_llm_rows.packet_batch.blocks+0xb4>
     c10:      	dup.4s	v5, w8
     c14:      	ldp	q0, q1, [sp, #0x180]
     c18:      	cmhi.4s	v0, v5, v0
     c1c:      	cmhi.4s	v1, v5, v1
     c20:      	uzp1.8h	v3, v1, v0
     c24:      	umaxv.8h	h2, v3
     c28:      	fmov	w8, s2
     c2c:      	tbz	w8, #0x0, 0xac4 <_llm_rows.packet_batch.blocks+0xb4>
     c30:      	str	w12, [sp, #0x178]
     c34:      	mov	x8, #0x0                ; =0
     c38:      	ldr	x10, [sp, #0x208]
     c3c:      	ldr	x9, [x10]
     c40:      	ldr	x15, [x10, #0x30]
     c44:      	ldr	q2, [sp, #0x10]
     c48:      	str	q3, [sp, #0xe0]
     c4c:      	and.16b	v2, v3, v2
     c50:      	addv.8h	h3, v2
     c54:      	fmov	w10, s3
     c58:      	and	w10, w10, #0xff
     c5c:      	str	w10, [sp, #0xf0]
     c60:      	ubfiz	w10, w19, #2, #27
     c64:      	orr	w10, w10, w21
     c68:      	dup.4s	v2, w10
     c6c:      	and.16b	v24, v1, v2
     c70:      	and.16b	v25, v0, v2
     c74:      	ushll2.2d	v16, v25, #0x0
     c78:      	ushll2.2d	v17, v24, #0x0
     c7c:      	ushll.2d	v18, v25, #0x0
     c80:      	ushll.2d	v6, v24, #0x0
     c84:      	fmov	x10, d6
     c88:      	mov	w11, #0x104             ; =260
     c8c:      	umaddl	x10, w10, w11, x9
     c90:      	str	q3, [sp, #0x280]
     c94:      	fmov	w11, s3
     c98:      	add	x2, sp, #0xe60
     c9c:      	mov	w3, #0xf2ca             ; =62154
     ca0:      	movk	w3, #0xf149, lsl #16
     ca4:      	add	x4, sp, #0xc20
     ca8:      	b	0xccc <_llm_rows.packet_batch.blocks+0x2bc>
     cac:      	add	x12, x2, x8
     cb0:      	ldp	q4, q7, [x12]
     cb4:      	bif.16b	v3, v7, v0
     cb8:      	bif.16b	v2, v4, v1
     cbc:      	stp	q2, q3, [x12]
     cc0:      	add	x8, x8, #0x20
     cc4:      	cmp	x8, #0x100
     cc8:      	b.eq	0xd60 <_llm_rows.packet_batch.blocks+0x350>
     ccc:      	add	x12, x10, x8
     cd0:      	movi.2d	v2, #0000000000000000
     cd4:      	movi.2d	v3, #0000000000000000
     cd8:      	tbnz	w11, #0x0, 0xd00 <_llm_rows.packet_batch.blocks+0x2f0>
     cdc:      	and	w13, w11, #0xff
     ce0:      	tbnz	w13, #0x1, 0xd0c <_llm_rows.packet_batch.blocks+0x2fc>
     ce4:      	tbnz	w13, #0x2, 0xd18 <_llm_rows.packet_batch.blocks+0x308>
     ce8:      	tbnz	w13, #0x3, 0xd24 <_llm_rows.packet_batch.blocks+0x314>
     cec:      	tbnz	w13, #0x4, 0xd30 <_llm_rows.packet_batch.blocks+0x320>
     cf0:      	tbnz	w13, #0x5, 0xd3c <_llm_rows.packet_batch.blocks+0x32c>
     cf4:      	tbnz	w13, #0x6, 0xd48 <_llm_rows.packet_batch.blocks+0x338>
     cf8:      	tbz	w13, #0x7, 0xcac <_llm_rows.packet_batch.blocks+0x29c>
     cfc:      	b	0xd54 <_llm_rows.packet_batch.blocks+0x344>
     d00:      	ldr	s2, [x12]
     d04:      	and	w13, w11, #0xff
     d08:      	tbz	w13, #0x1, 0xce4 <_llm_rows.packet_batch.blocks+0x2d4>
     d0c:      	add	x14, x12, #0x4
     d10:      	ld1.s	{ v2 }[1], [x14]
     d14:      	tbz	w13, #0x2, 0xce8 <_llm_rows.packet_batch.blocks+0x2d8>
     d18:      	add	x14, x12, #0x8
     d1c:      	ld1.s	{ v2 }[2], [x14]
     d20:      	tbz	w13, #0x3, 0xcec <_llm_rows.packet_batch.blocks+0x2dc>
     d24:      	add	x14, x12, #0xc
     d28:      	ld1.s	{ v2 }[3], [x14]
     d2c:      	tbz	w13, #0x4, 0xcf0 <_llm_rows.packet_batch.blocks+0x2e0>
     d30:      	add	x14, x12, #0x10
     d34:      	ld1.s	{ v3 }[0], [x14]
     d38:      	tbz	w13, #0x5, 0xcf4 <_llm_rows.packet_batch.blocks+0x2e4>
     d3c:      	add	x14, x12, #0x14
     d40:      	ld1.s	{ v3 }[1], [x14]
     d44:      	tbz	w13, #0x6, 0xcf8 <_llm_rows.packet_batch.blocks+0x2e8>
     d48:      	add	x14, x12, #0x18
     d4c:      	ld1.s	{ v3 }[2], [x14]
     d50:      	tbz	w13, #0x7, 0xcac <_llm_rows.packet_batch.blocks+0x29c>
     d54:      	add	x12, x12, #0x1c
     d58:      	ld1.s	{ v3 }[3], [x12]
     d5c:      	b	0xcac <_llm_rows.packet_batch.blocks+0x29c>
     d60:      	xtn.4h	v2, v1
     d64:      	uzp1.8b	v2, v2, v0
     d68:      	sshll.2d	v4, v1, #0x0
     d6c:      	adrp	x8, 0x0 <ltmp0>
     d70:      	ldr	q27, [x8]
     d74:      	and.16b	v7, v4, v27
     d78:      	movi.2d	v20, #0000000000000000
     d7c:      	mov.b	v20[0], v2[0]
     d80:      	adrp	x8, 0x0 <ltmp0>
     d84:      	ldr	d3, [x8]
     d88:      	str	d3, [sp, #0x260]
     d8c:      	and.8b	v3, v20, v3
     d90:      	addv.8b	b3, v3
     d94:      	fmov	w8, s3
     d98:      	umaxv.8b	b3, v20
     d9c:      	fmov	w10, s3
     da0:      	rbit	w11, w8
     da4:      	clz	w11, w11
     da8:      	tst	w10, #0x1
     dac:      	csel	w5, w11, wzr, ne
     db0:      	mov	w11, #0x40              ; =64
     db4:      	dup.2d	v19, x11
     db8:      	str	q7, [sp, #0xd0]
     dbc:      	orr.16b	v3, v7, v19
     dc0:      	xtn.2s	v31, v6
     dc4:      	str	q3, [sp, #0x2f0]
     dc8:      	mov.16b	v6, v3
     dcc:      	umlal.2d	v6, v31, v8
     dd0:      	movi.2d	v3, #0000000000000000
     dd4:      	mov.b	v3[0], v2[0]
     dd8:      	ushll.2d	v2, v3, #0x0
     ddc:      	shl.2d	v2, v2, #0x3f
     de0:      	cmlt.2d	v2, v2, #0
     de4:      	str	q6, [sp, #0x150]
     de8:      	and.16b	v2, v2, v6
     dec:      	movi.2d	v3, #0000000000000000
     df0:      	str	q3, [sp, #0x980]
     df4:      	str	q3, [sp, #0x970]
     df8:      	str	q3, [sp, #0x960]
     dfc:      	str	q2, [sp, #0x950]
     e00:      	and	x11, x5, #0x7
     e04:      	add	x12, sp, #0x950
     e08:      	ldr	x11, [x12, x11, lsl #3]
     e0c:      	sub	x11, x11, x5
     e10:      	add	x9, x9, x11, lsl #2
     e14:      	movi.2d	v7, #0000000000000000
     e18:      	movi.2d	v6, #0000000000000000
     e1c:      	tbnz	w10, #0x0, 0x15c8 <_llm_rows.packet_batch.blocks+0xbb8>
     e20:      	tbnz	w8, #0x1, 0x15d0 <_llm_rows.packet_batch.blocks+0xbc0>
     e24:      	tbnz	w8, #0x2, 0x15dc <_llm_rows.packet_batch.blocks+0xbcc>
     e28:      	tbnz	w8, #0x3, 0x15e8 <_llm_rows.packet_batch.blocks+0xbd8>
     e2c:      	tbnz	w8, #0x4, 0x15f4 <_llm_rows.packet_batch.blocks+0xbe4>
     e30:      	tbnz	w8, #0x5, 0x1600 <_llm_rows.packet_batch.blocks+0xbf0>
     e34:      	tbnz	w8, #0x6, 0x160c <_llm_rows.packet_batch.blocks+0xbfc>
     e38:      	tbz	w8, #0x7, 0xe44 <_llm_rows.packet_batch.blocks+0x434>
     e3c:      	add	x9, x9, #0x1c
     e40:      	ld1.s	{ v6 }[3], [x9]
     e44:      	str	x15, [sp, #0x170]
     e48:      	mov	x9, #0x0                ; =0
     e4c:      	sshll.2d	v21, v0, #0x0
     e50:      	sshll2.2d	v26, v1, #0x0
     e54:      	sshll2.2d	v9, v0, #0x0
     e58:      	adrp	x10, 0x0 <ltmp0>
     e5c:      	ldr	q2, [x10]
     e60:      	and.16b	v2, v9, v2
     e64:      	adrp	x10, 0x0 <ltmp0>
     e68:      	ldr	q3, [x10]
     e6c:      	and.16b	v3, v26, v3
     e70:      	adrp	x10, 0x0 <ltmp0>
     e74:      	ldr	q22, [x10]
     e78:      	and.16b	v22, v21, v22
     e7c:      	adrp	x10, 0x0 <ltmp0>
     e80:      	ldr	q23, [x10]
     e84:      	and.16b	v4, v4, v23
     e88:      	str	q4, [sp, #0x90]
     e8c:      	str	q4, [sp, #0x910]
     e90:      	str	q3, [sp, #0x920]
     e94:      	str	q22, [sp, #0x930]
     e98:      	str	q2, [sp, #0x940]
     e9c:      	and	x10, x5, #0x7
     ea0:      	add	x11, sp, #0x910
     ea4:      	ldr	x10, [x11, x10, lsl #3]
     ea8:      	orr	x10, x10, #0x100
     eac:      	sub	x10, x10, x5, lsl #2
     eb0:      	tst	w8, #0xff
     eb4:      	csel	x6, xzr, x10, eq
     eb8:      	add	x10, x2, x6
     ebc:      	ldp	q2, q3, [x10]
     ec0:      	zip2.8b	v4, v20, v0
     ec4:      	ushll.4s	v4, v4, #0x0
     ec8:      	shl.4s	v4, v4, #0x1f
     ecc:      	cmlt.4s	v4, v4, #0
     ed0:      	bit.16b	v3, v6, v4
     ed4:      	str	q20, [sp, #0x1e0]
     ed8:      	zip1.8b	v4, v20, v0
     edc:      	ushll.4s	v4, v4, #0x0
     ee0:      	shl.4s	v4, v4, #0x1f
     ee4:      	cmlt.4s	v4, v4, #0
     ee8:      	str	q7, [sp, #0x1b0]
     eec:      	bit.16b	v2, v7, v4
     ef0:      	stp	q2, q3, [x10]
     ef4:      	adrp	x10, 0x0 <ltmp0>
     ef8:      	ldr	q2, [x10]
     efc:      	and.16b	v7, v9, v2
     f00:      	adrp	x10, 0x0 <ltmp0>
     f04:      	ldr	q3, [x10]
     f08:      	and.16b	v20, v26, v3
     f0c:      	adrp	x10, 0x0 <ltmp0>
     f10:      	ldr	q4, [x10]
     f14:      	and.16b	v21, v21, v4
     f18:      	str	q21, [sp, #0x80]
     f1c:      	orr.16b	v28, v21, v19
     f20:      	stp	q20, q7, [sp, #0xb0]
     f24:      	orr.16b	v30, v20, v19
     f28:      	orr.16b	v7, v7, v19
     f2c:      	umull.2d	v20, v31, v8
     f30:      	xtn.2s	v17, v17
     f34:      	xtn.2s	v18, v18
     f38:      	xtn.2s	v16, v16
     f3c:      	mov.16b	v19, v7
     f40:      	umlal.2d	v19, v16, v8
     f44:      	mov.16b	v16, v30
     f48:      	umlal.2d	v16, v17, v8
     f4c:      	stp	q16, q19, [sp, #0x130]
     f50:      	mov.16b	v16, v28
     f54:      	umlal.2d	v16, v18, v8
     f58:      	stp	q20, q16, [sp, #0x110]
     f5c:      	mov	w10, #0x1               ; =1
     f60:      	dup.2d	v19, x10
     f64:      	ushll2.2d	v16, v0, #0x0
     f68:      	and.16b	v16, v16, v19
     f6c:      	ushll2.2d	v17, v1, #0x0
     f70:      	and.16b	v8, v17, v19
     f74:      	ushll.2d	v18, v0, #0x0
     f78:      	and.16b	v11, v18, v19
     f7c:      	mov.16b	v17, v26
     f80:      	ushll.2d	v21, v1, #0x0
     f84:      	and.16b	v29, v21, v19
     f88:      	mov.16b	v19, v16
     f8c:      	mov.16b	v16, v9
     f90:      	movi.2d	v21, #0000000000000000
     f94:      	movi.2d	v22, #0000000000000000
     f98:      	movi.2d	v31, #0000000000000000
     f9c:      	movi.2d	v9, #0000000000000000
     fa0:      	stp	q11, q8, [sp, #0x290]
     fa4:      	sshll.2d	v10, v0, #0x0
     fa8:      	sshll.2d	v13, v1, #0x0
     fac:      	shl.2d	v14, v9, #0x3
     fb0:      	shl.2d	v15, v21, #0x3
     fb4:      	shl.2d	v23, v31, #0x3
     fb8:      	shl.2d	v12, v22, #0x3
     fbc:      	orr.16b	v12, v12, v3
     fc0:      	orr.16b	v23, v23, v4
     fc4:      	orr.16b	v15, v15, v27
     fc8:      	orr.16b	v14, v14, v2
     fcc:      	add	x9, x4, x9, lsl #6
     fd0:      	ldp	q11, q8, [x9]
     fd4:      	ldp	q20, q26, [x9, #0x20]
     fd8:      	bit.16b	v26, v14, v16
     fdc:      	bit.16b	v11, v15, v13
     fe0:      	bit.16b	v20, v23, v10
     fe4:      	mov.16b	v23, v17
     fe8:      	bsl.16b	v23, v12, v8
     fec:      	stp	q11, q23, [x9]
     ff0:      	ldp	q11, q8, [sp, #0x290]
     ff4:      	stp	q20, q26, [x9, #0x20]
     ff8:      	add.2d	v22, v22, v8
     ffc:      	add.2d	v31, v31, v11
    1000:      	add.2d	v9, v9, v19
    1004:      	add.2d	v21, v21, v29
    1008:      	fmov	x9, d21
    100c:      	cmp	x9, #0x8
    1010:      	b.lt	0xfa4 <_llm_rows.packet_batch.blocks+0x594>
    1014:      	mov	x9, #0x0                ; =0
    1018:      	movi.4s	v4, #0x41
    101c:      	and.16b	v2, v1, v4
    1020:      	mvn.16b	v3, v1
    1024:      	sub.4s	v2, v2, v3
    1028:      	and.16b	v3, v0, v4
    102c:      	mvn.16b	v4, v0
    1030:      	sub.4s	v3, v3, v4
    1034:      	mov.s	w10, v3[1]
    1038:      	mov.s	w11, v25[1]
    103c:      	udiv	w12, w11, w10
    1040:      	msub	w11, w12, w10, w11
    1044:      	mov.s	w10, v3[2]
    1048:      	mov.s	w12, v3[3]
    104c:      	fmov	w13, s3
    1050:      	fmov	w14, s25
    1054:      	udiv	w15, w14, w13
    1058:      	msub	w13, w15, w13, w14
    105c:      	mov.s	w14, v25[2]
    1060:      	udiv	w15, w14, w10
    1064:      	msub	w14, w15, w10, w14
    1068:      	mov.s	w10, v25[3]
    106c:      	udiv	w15, w10, w12
    1070:      	msub	w12, w15, w12, w10
    1074:      	mov.s	w10, v2[1]
    1078:      	mov.s	w15, v24[1]
    107c:      	udiv	w16, w15, w10
    1080:      	msub	w15, w16, w10, w15
    1084:      	mov.s	w10, v2[2]
    1088:      	mov.s	w16, v2[3]
    108c:      	fmov	w17, s2
    1090:      	fmov	w0, s24
    1094:      	udiv	w1, w0, w17
    1098:      	msub	w17, w1, w17, w0
    109c:      	mov.s	w0, v24[2]
    10a0:      	udiv	w1, w0, w10
    10a4:      	msub	w10, w1, w10, w0
    10a8:      	mov.s	w0, v24[3]
    10ac:      	udiv	w1, w0, w16
    10b0:      	msub	w16, w1, w16, w0
    10b4:      	tst	w8, #0xff
    10b8:      	fmov	s2, w13
    10bc:      	mov.s	v2[1], w11
    10c0:      	mov.s	v2[2], w14
    10c4:      	mov.s	v2[3], w12
    10c8:      	fmov	s3, w17
    10cc:      	sshll.2d	v25, v0, #0x0
    10d0:      	sshll.2d	v24, v1, #0x0
    10d4:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5f0>
    10d8:      	ldr	q4, [x8]
    10dc:      	and.16b	v4, v24, v4
    10e0:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5f0>
    10e4:      	ldr	q20, [x8]
    10e8:      	and.16b	v20, v25, v20
    10ec:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5f0>
    10f0:      	ldr	q21, [x8]
    10f4:      	and.16b	v21, v17, v21
    10f8:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5f0>
    10fc:      	ldr	q22, [x8]
    1100:      	and.16b	v22, v16, v22
    1104:      	str	q22, [sp, #0x900]
    1108:      	str	q20, [sp, #0x8f0]
    110c:      	str	q21, [sp, #0x8e0]
    1110:      	str	q4, [sp, #0x8d0]
    1114:      	mov.s	v3[1], w15
    1118:      	and	x8, x5, #0x7
    111c:      	add	x11, sp, #0x8d0
    1120:      	ldr	x8, [x11, x8, lsl #3]
    1124:      	orr	x8, x8, #0x200
    1128:      	sub	x8, x8, x5, lsl #3
    112c:      	csel	x8, xzr, x8, eq
    1130:      	add	x8, x4, x8
    1134:      	ldp	q20, q21, [x8, #0x20]
    1138:      	ldr	q18, [sp, #0x1e0]
    113c:      	mov	b4, v18[2]
    1140:      	mov.b	v4[4], v18[3]
    1144:      	ldp	q22, q23, [x8]
    1148:      	ushll.2d	v4, v4, #0x0
    114c:      	shl.2d	v4, v4, #0x3f
    1150:      	cmlt.2d	v4, v4, #0
    1154:      	mov.16b	v9, v4
    1158:      	bsl.16b	v9, v30, v23
    115c:      	mov	b4, v18[0]
    1160:      	mov.b	v4[4], v18[1]
    1164:      	ushll.2d	v4, v4, #0x0
    1168:      	shl.2d	v4, v4, #0x3f
    116c:      	cmlt.2d	v4, v4, #0
    1170:      	ldr	q23, [sp, #0x2f0]
    1174:      	bsl.16b	v4, v23, v22
    1178:      	mov	b22, v18[6]
    117c:      	mov.b	v22[4], v18[7]
    1180:      	ushll.2d	v22, v22, #0x0
    1184:      	shl.2d	v22, v22, #0x3f
    1188:      	cmlt.2d	v22, v22, #0
    118c:      	mov.16b	v10, v22
    1190:      	bsl.16b	v10, v7, v21
    1194:      	mov	b21, v18[4]
    1198:      	mov.b	v21[4], v18[5]
    119c:      	ushll.2d	v21, v21, #0x0
    11a0:      	shl.2d	v21, v21, #0x3f
    11a4:      	cmlt.2d	v21, v21, #0
    11a8:      	mov.16b	v13, v21
    11ac:      	bsl.16b	v13, v28, v20
    11b0:      	mov.s	v3[2], w10
    11b4:      	mov.s	v3[3], w16
    11b8:      	and.16b	v20, v1, v3
    11bc:      	stp	q13, q10, [x8, #0x20]
    11c0:      	stp	q4, q9, [x8]
    11c4:      	and.16b	v21, v0, v2
    11c8:      	ushll2.2d	v2, v21, #0x0
    11cc:      	ushll2.2d	v3, v20, #0x0
    11d0:      	ushll.2d	v21, v21, #0x0
    11d4:      	ushll.2d	v22, v20, #0x0
    11d8:      	mov.16b	v7, v16
    11dc:      	ldr	q16, [sp, #0x20]
    11e0:      	and.16b	v30, v7, v16
    11e4:      	and.16b	v31, v17, v16
    11e8:      	and.16b	v12, v25, v16
    11ec:      	and.16b	v16, v24, v16
    11f0:      	str	q16, [sp, #0x2f0]
    11f4:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5f0>
    11f8:      	ldr	q20, [x8]
    11fc:      	str	q7, [sp, #0x1c0]
    1200:      	and.16b	v7, v7, v20
    1204:      	str	q7, [sp, #0x2e0]
    1208:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5f0>
    120c:      	ldr	q20, [x8]
    1210:      	str	q17, [sp, #0x1d0]
    1214:      	and.16b	v7, v17, v20
    1218:      	str	q7, [sp, #0x2d0]
    121c:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5f0>
    1220:      	ldr	q20, [x8]
    1224:      	and.16b	v7, v25, v20
    1228:      	str	q7, [sp, #0x2c0]
    122c:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5f0>
    1230:      	ldr	q20, [x8]
    1234:      	and.16b	v7, v24, v20
    1238:      	str	q7, [sp, #0x2b0]
    123c:      	ldp	q7, q16, [sp, #0x180]
    1240:      	cmhs.4s	v20, v7, v5
    1244:      	cmhs.4s	v5, v16, v5
    1248:      	uzp1.8h	v5, v5, v20
    124c:      	xtn.8b	v5, v5
    1250:      	movi.2d	v24, #0000000000000000
    1254:      	movi.2d	v25, #0000000000000000
    1258:      	movi.2d	v26, #0000000000000000
    125c:      	movi.2d	v14, #0000000000000000
    1260:      	movi.8b	v16, #0x1
    1264:      	ldr	q17, [sp, #0x280]
    1268:      	b	0x1288 <_llm_rows.packet_batch.blocks+0x878>
    126c:      	add.2d	v25, v25, v8
    1270:      	add.2d	v26, v26, v11
    1274:      	add.2d	v14, v14, v19
    1278:      	add.2d	v24, v24, v29
    127c:      	fmov	x9, d24
    1280:      	cmp	x9, #0x8
    1284:      	b.ge	0x13a4 <_llm_rows.packet_batch.blocks+0x994>
    1288:      	fmov	w8, s17
    128c:      	add	x9, x4, x9, lsl #6
    1290:      	ldp	q23, q20, [x9, #0x20]
    1294:      	ldp	q27, q28, [x9]
    1298:      	cmge.2d	v28, v3, v28
    129c:      	cmge.2d	v27, v22, v27
    12a0:      	uzp1.4s	v27, v27, v28
    12a4:      	cmge.2d	v23, v21, v23
    12a8:      	cmge.2d	v20, v2, v20
    12ac:      	uzp1.4s	v20, v23, v20
    12b0:      	uzp1.8h	v20, v27, v20
    12b4:      	xtn.8b	v20, v20
    12b8:      	orr.8b	v20, v5, v20
    12bc:      	ldr	q7, [sp, #0x2b0]
    12c0:      	add.2d	v23, v24, v7
    12c4:      	ldr	q7, [sp, #0x2f0]
    12c8:      	add.2d	v28, v7, v23
    12cc:      	and.8b	v27, v20, v16
    12d0:      	tbnz	w8, #0x0, 0x131c <_llm_rows.packet_batch.blocks+0x90c>
    12d4:      	and	w8, w8, #0xff
    12d8:      	tbnz	w8, #0x1, 0x132c <_llm_rows.packet_batch.blocks+0x91c>
    12dc:      	ldr	q7, [sp, #0x2d0]
    12e0:      	add.2d	v20, v25, v7
    12e4:      	add.2d	v28, v31, v20
    12e8:      	tbnz	w8, #0x2, 0x1344 <_llm_rows.packet_batch.blocks+0x934>
    12ec:      	tbnz	w8, #0x3, 0x1350 <_llm_rows.packet_batch.blocks+0x940>
    12f0:      	ldr	q7, [sp, #0x2c0]
    12f4:      	add.2d	v20, v26, v7
    12f8:      	add.2d	v28, v12, v20
    12fc:      	tbnz	w8, #0x4, 0x1368 <_llm_rows.packet_batch.blocks+0x958>
    1300:      	tbnz	w8, #0x5, 0x1374 <_llm_rows.packet_batch.blocks+0x964>
    1304:      	ldr	q7, [sp, #0x2e0]
    1308:      	add.2d	v20, v14, v7
    130c:      	add.2d	v28, v30, v20
    1310:      	tbnz	w8, #0x6, 0x138c <_llm_rows.packet_batch.blocks+0x97c>
    1314:      	tbz	w8, #0x7, 0x126c <_llm_rows.packet_batch.blocks+0x85c>
    1318:      	b	0x1398 <_llm_rows.packet_batch.blocks+0x988>
    131c:      	fmov	x9, d28
    1320:      	str	b27, [x9]
    1324:      	and	w8, w8, #0xff
    1328:      	tbz	w8, #0x1, 0x12dc <_llm_rows.packet_batch.blocks+0x8cc>
    132c:      	mov.d	x9, v28[1]
    1330:      	st1.b	{ v27 }[1], [x9]
    1334:      	ldr	q7, [sp, #0x2d0]
    1338:      	add.2d	v20, v25, v7
    133c:      	add.2d	v28, v31, v20
    1340:      	tbz	w8, #0x2, 0x12ec <_llm_rows.packet_batch.blocks+0x8dc>
    1344:      	fmov	x9, d28
    1348:      	st1.b	{ v27 }[2], [x9]
    134c:      	tbz	w8, #0x3, 0x12f0 <_llm_rows.packet_batch.blocks+0x8e0>
    1350:      	mov.d	x9, v28[1]
    1354:      	st1.b	{ v27 }[3], [x9]
    1358:      	ldr	q7, [sp, #0x2c0]
    135c:      	add.2d	v20, v26, v7
    1360:      	add.2d	v28, v12, v20
    1364:      	tbz	w8, #0x4, 0x1300 <_llm_rows.packet_batch.blocks+0x8f0>
    1368:      	fmov	x9, d28
    136c:      	st1.b	{ v27 }[4], [x9]
    1370:      	tbz	w8, #0x5, 0x1304 <_llm_rows.packet_batch.blocks+0x8f4>
    1374:      	mov.d	x9, v28[1]
    1378:      	st1.b	{ v27 }[5], [x9]
    137c:      	ldr	q7, [sp, #0x2e0]
    1380:      	add.2d	v20, v14, v7
    1384:      	add.2d	v28, v30, v20
    1388:      	tbz	w8, #0x6, 0x1314 <_llm_rows.packet_batch.blocks+0x904>
    138c:      	fmov	x9, d28
    1390:      	st1.b	{ v27 }[6], [x9]
    1394:      	tbz	w8, #0x7, 0x126c <_llm_rows.packet_batch.blocks+0x85c>
    1398:      	mov.d	x8, v28[1]
    139c:      	st1.b	{ v27 }[7], [x8]
    13a0:      	b	0x126c <_llm_rows.packet_batch.blocks+0x85c>
    13a4:      	cmge.2d	v4, v22, v4
    13a8:      	cmge.2d	v3, v3, v9
    13ac:      	uzp1.4s	v3, v4, v3
    13b0:      	cmge.2d	v4, v21, v13
    13b4:      	cmge.2d	v2, v2, v10
    13b8:      	uzp1.4s	v2, v4, v2
    13bc:      	uzp1.8h	v2, v3, v2
    13c0:      	xtn.8b	v2, v2
    13c4:      	shl.8b	v3, v18, #0x7
    13c8:      	cmlt.8b	v3, v3, #0
    13cc:      	ldr	d4, [sp, #0x260]
    13d0:      	and.8b	v3, v3, v4
    13d4:      	addv.8b	b7, v3
    13d8:      	fmov	w12, s7
    13dc:      	orn.8b	v2, v2, v18
    13e0:      	ldr	q3, [sp, #0x2f0]
    13e4:      	ldr	q4, [sp, #0x2b0]
    13e8:      	add.2d	v4, v4, v3
    13ec:      	mov	w8, #0x8                ; =8
    13f0:      	dup.2d	v3, x8
    13f4:      	add.2d	v14, v4, v3
    13f8:      	and.8b	v2, v2, v16
    13fc:      	tbnz	w12, #0x0, 0x161c <_llm_rows.packet_batch.blocks+0xc0c>
    1400:      	mov.d	x11, v14[1]
    1404:      	ldr	q16, [sp, #0x1c0]
    1408:      	tbnz	w12, #0x1, 0x1630 <_llm_rows.packet_batch.blocks+0xc20>
    140c:      	ldr	q4, [sp, #0x2d0]
    1410:      	add.2d	v4, v4, v31
    1414:      	add.2d	v13, v4, v3
    1418:      	tbnz	w12, #0x2, 0x1644 <_llm_rows.packet_batch.blocks+0xc34>
    141c:      	mov.d	x10, v13[1]
    1420:      	tbnz	w12, #0x3, 0x1654 <_llm_rows.packet_batch.blocks+0xc44>
    1424:      	ldr	q4, [sp, #0x2c0]
    1428:      	add.2d	v4, v4, v12
    142c:      	add.2d	v20, v4, v3
    1430:      	tbnz	w12, #0x4, 0x1668 <_llm_rows.packet_batch.blocks+0xc58>
    1434:      	mov.d	x9, v20[1]
    1438:      	tbnz	w12, #0x5, 0x1678 <_llm_rows.packet_batch.blocks+0xc68>
    143c:      	ldr	q4, [sp, #0x2e0]
    1440:      	add.2d	v4, v4, v30
    1444:      	add.2d	v5, v4, v3
    1448:      	tbnz	w12, #0x6, 0x168c <_llm_rows.packet_batch.blocks+0xc7c>
    144c:      	mov.d	x8, v5[1]
    1450:      	tbz	w12, #0x7, 0x1458 <_llm_rows.packet_batch.blocks+0xa48>
    1454:      	st1.b	{ v2 }[7], [x8]
    1458:      	mov	x12, #0x0               ; =0
    145c:      	movi.2d	v9, #0000000000000000
    1460:      	movi.2d	v10, #0000000000000000
    1464:      	movi.2d	v15, #0000000000000000
    1468:      	movi.2d	v4, #0000000000000000
    146c:      	b	0x14d0 <_llm_rows.packet_batch.blocks+0xac0>
    1470:      	cmeq.8b	v2, v2, #0
    1474:      	sshll.8h	v2, v2, #0x0
    1478:      	sshll2.4s	v3, v2, #0x0
    147c:      	sshll.4s	v21, v2, #0x0
    1480:      	lsl	x12, x12, #5
    1484:      	add	x13, x2, x12
    1488:      	ldp	q2, q22, [x13]
    148c:      	and.16b	v22, v0, v22
    1490:      	and.16b	v23, v1, v2
    1494:      	dup.4s	v2, w3
    1498:      	bsl.16b	v21, v2, v23
    149c:      	bsl.16b	v3, v2, v22
    14a0:      	add	x12, x24, x12
    14a4:      	ldp	q22, q23, [x12]
    14a8:      	bif.16b	v3, v23, v0
    14ac:      	bif.16b	v21, v22, v1
    14b0:      	stp	q21, q3, [x12]
    14b4:      	add.2d	v10, v10, v8
    14b8:      	add.2d	v15, v15, v11
    14bc:      	add.2d	v4, v4, v19
    14c0:      	add.2d	v9, v9, v29
    14c4:      	fmov	x12, d9
    14c8:      	cmp	x12, #0x8
    14cc:      	b.ge	0x15b0 <_llm_rows.packet_batch.blocks+0xba0>
    14d0:      	fmov	w13, s17
    14d4:      	ldr	q2, [sp, #0x2b0]
    14d8:      	add.2d	v2, v9, v2
    14dc:      	ldr	q3, [sp, #0x2f0]
    14e0:      	add.2d	v3, v3, v2
    14e4:      	tbz	w13, #0x0, 0x14fc <_llm_rows.packet_batch.blocks+0xaec>
    14e8:      	fmov	x14, d3
    14ec:      	ldr	b2, [x14]
    14f0:      	and	w13, w13, #0xff
    14f4:      	tbnz	w13, #0x1, 0x1508 <_llm_rows.packet_batch.blocks+0xaf8>
    14f8:      	b	0x1510 <_llm_rows.packet_batch.blocks+0xb00>
    14fc:      	movi.2d	v2, #0000000000000000
    1500:      	and	w13, w13, #0xff
    1504:      	tbz	w13, #0x1, 0x1510 <_llm_rows.packet_batch.blocks+0xb00>
    1508:      	mov.d	x14, v3[1]
    150c:      	ld1.b	{ v2 }[1], [x14]
    1510:      	ldr	q3, [sp, #0x2d0]
    1514:      	add.2d	v3, v10, v3
    1518:      	add.2d	v3, v31, v3
    151c:      	tbnz	w13, #0x2, 0x1550 <_llm_rows.packet_batch.blocks+0xb40>
    1520:      	tbnz	w13, #0x3, 0x155c <_llm_rows.packet_batch.blocks+0xb4c>
    1524:      	ldr	q3, [sp, #0x2c0]
    1528:      	add.2d	v3, v15, v3
    152c:      	add.2d	v3, v12, v3
    1530:      	tbnz	w13, #0x4, 0x1574 <_llm_rows.packet_batch.blocks+0xb64>
    1534:      	tbnz	w13, #0x5, 0x1580 <_llm_rows.packet_batch.blocks+0xb70>
    1538:      	ldr	q3, [sp, #0x2e0]
    153c:      	add.2d	v3, v4, v3
    1540:      	add.2d	v3, v30, v3
    1544:      	tbnz	w13, #0x6, 0x1598 <_llm_rows.packet_batch.blocks+0xb88>
    1548:      	tbz	w13, #0x7, 0x1470 <_llm_rows.packet_batch.blocks+0xa60>
    154c:      	b	0x15a4 <_llm_rows.packet_batch.blocks+0xb94>
    1550:      	fmov	x14, d3
    1554:      	ld1.b	{ v2 }[2], [x14]
    1558:      	tbz	w13, #0x3, 0x1524 <_llm_rows.packet_batch.blocks+0xb14>
    155c:      	mov.d	x14, v3[1]
    1560:      	ld1.b	{ v2 }[3], [x14]
    1564:      	ldr	q3, [sp, #0x2c0]
    1568:      	add.2d	v3, v15, v3
    156c:      	add.2d	v3, v12, v3
    1570:      	tbz	w13, #0x4, 0x1534 <_llm_rows.packet_batch.blocks+0xb24>
    1574:      	fmov	x14, d3
    1578:      	ld1.b	{ v2 }[4], [x14]
    157c:      	tbz	w13, #0x5, 0x1538 <_llm_rows.packet_batch.blocks+0xb28>
    1580:      	mov.d	x14, v3[1]
    1584:      	ld1.b	{ v2 }[5], [x14]
    1588:      	ldr	q3, [sp, #0x2e0]
    158c:      	add.2d	v3, v4, v3
    1590:      	add.2d	v3, v30, v3
    1594:      	tbz	w13, #0x6, 0x1548 <_llm_rows.packet_batch.blocks+0xb38>
    1598:      	fmov	x14, d3
    159c:      	ld1.b	{ v2 }[6], [x14]
    15a0:      	tbz	w13, #0x7, 0x1470 <_llm_rows.packet_batch.blocks+0xa60>
    15a4:      	mov.d	x13, v3[1]
    15a8:      	ld1.b	{ v2 }[7], [x13]
    15ac:      	b	0x1470 <_llm_rows.packet_batch.blocks+0xa60>
    15b0:      	fmov	w12, s7
    15b4:      	tbz	w12, #0x0, 0x16a0 <_llm_rows.packet_batch.blocks+0xc90>
    15b8:      	fmov	x13, d14
    15bc:      	ldr	b3, [x13]
    15c0:      	tbnz	w12, #0x1, 0x16a8 <_llm_rows.packet_batch.blocks+0xc98>
    15c4:      	b	0x16ac <_llm_rows.packet_batch.blocks+0xc9c>
    15c8:      	ldr	s7, [x9]
    15cc:      	tbz	w8, #0x1, 0xe24 <_llm_rows.packet_batch.blocks+0x414>
    15d0:      	add	x10, x9, #0x4
    15d4:      	ld1.s	{ v7 }[1], [x10]
    15d8:      	tbz	w8, #0x2, 0xe28 <_llm_rows.packet_batch.blocks+0x418>
    15dc:      	add	x10, x9, #0x8
    15e0:      	ld1.s	{ v7 }[2], [x10]
    15e4:      	tbz	w8, #0x3, 0xe2c <_llm_rows.packet_batch.blocks+0x41c>
    15e8:      	add	x10, x9, #0xc
    15ec:      	ld1.s	{ v7 }[3], [x10]
    15f0:      	tbz	w8, #0x4, 0xe30 <_llm_rows.packet_batch.blocks+0x420>
    15f4:      	add	x10, x9, #0x10
    15f8:      	ld1.s	{ v6 }[0], [x10]
    15fc:      	tbz	w8, #0x5, 0xe34 <_llm_rows.packet_batch.blocks+0x424>
    1600:      	add	x10, x9, #0x14
    1604:      	ld1.s	{ v6 }[1], [x10]
    1608:      	tbz	w8, #0x6, 0xe38 <_llm_rows.packet_batch.blocks+0x428>
    160c:      	add	x10, x9, #0x18
    1610:      	ld1.s	{ v6 }[2], [x10]
    1614:      	tbnz	w8, #0x7, 0xe3c <_llm_rows.packet_batch.blocks+0x42c>
    1618:      	b	0xe44 <_llm_rows.packet_batch.blocks+0x434>
    161c:      	fmov	x8, d14
    1620:      	str	b2, [x8]
    1624:      	mov.d	x11, v14[1]
    1628:      	ldr	q16, [sp, #0x1c0]
    162c:      	tbz	w12, #0x1, 0x140c <_llm_rows.packet_batch.blocks+0x9fc>
    1630:      	st1.b	{ v2 }[1], [x11]
    1634:      	ldr	q4, [sp, #0x2d0]
    1638:      	add.2d	v4, v4, v31
    163c:      	add.2d	v13, v4, v3
    1640:      	tbz	w12, #0x2, 0x141c <_llm_rows.packet_batch.blocks+0xa0c>
    1644:      	fmov	x8, d13
    1648:      	st1.b	{ v2 }[2], [x8]
    164c:      	mov.d	x10, v13[1]
    1650:      	tbz	w12, #0x3, 0x1424 <_llm_rows.packet_batch.blocks+0xa14>
    1654:      	st1.b	{ v2 }[3], [x10]
    1658:      	ldr	q4, [sp, #0x2c0]
    165c:      	add.2d	v4, v4, v12
    1660:      	add.2d	v20, v4, v3
    1664:      	tbz	w12, #0x4, 0x1434 <_llm_rows.packet_batch.blocks+0xa24>
    1668:      	fmov	x8, d20
    166c:      	st1.b	{ v2 }[4], [x8]
    1670:      	mov.d	x9, v20[1]
    1674:      	tbz	w12, #0x5, 0x143c <_llm_rows.packet_batch.blocks+0xa2c>
    1678:      	st1.b	{ v2 }[5], [x9]
    167c:      	ldr	q4, [sp, #0x2e0]
    1680:      	add.2d	v4, v4, v30
    1684:      	add.2d	v5, v4, v3
    1688:      	tbz	w12, #0x6, 0x144c <_llm_rows.packet_batch.blocks+0xa3c>
    168c:      	fmov	x8, d5
    1690:      	st1.b	{ v2 }[6], [x8]
    1694:      	mov.d	x8, v5[1]
    1698:      	tbnz	w12, #0x7, 0x1454 <_llm_rows.packet_batch.blocks+0xa44>
    169c:      	b	0x1458 <_llm_rows.packet_batch.blocks+0xa48>
    16a0:      	movi.2d	v3, #0000000000000000
    16a4:      	tbz	w12, #0x1, 0x16ac <_llm_rows.packet_batch.blocks+0xc9c>
    16a8:      	ld1.b	{ v3 }[1], [x11]
    16ac:      	tbnz	w12, #0x2, 0x2a20 <_llm_rows.packet_batch.blocks+0x2010>
    16b0:      	tbnz	w12, #0x3, 0x2a2c <_llm_rows.packet_batch.blocks+0x201c>
    16b4:      	tbnz	w12, #0x4, 0x2a34 <_llm_rows.packet_batch.blocks+0x2024>
    16b8:      	tbnz	w12, #0x5, 0x2a40 <_llm_rows.packet_batch.blocks+0x2030>
    16bc:      	tbnz	w12, #0x6, 0x2a48 <_llm_rows.packet_batch.blocks+0x2038>
    16c0:      	stp	q29, q19, [sp, #0x260]
    16c4:      	stp	q31, q30, [sp, #0x220]
    16c8:      	str	d7, [sp, #0x108]
    16cc:      	str	q12, [sp, #0x210]
    16d0:      	tbz	w12, #0x7, 0x16d8 <_llm_rows.packet_batch.blocks+0xcc8>
    16d4:      	ld1.b	{ v3 }[7], [x8]
    16d8:      	str	w25, [sp, #0x7c]
    16dc:      	str	w22, [sp, #0xac]
    16e0:      	str	x5, [sp, #0x168]
    16e4:      	sshll.2d	v4, v1, #0x0
    16e8:      	sshll.2d	v5, v0, #0x0
    16ec:      	cmeq.8b	v3, v3, #0
    16f0:      	sshll.8h	v7, v3, #0x0
    16f4:      	sshll.4s	v3, v7, #0x0
    16f8:      	str	q7, [sp, #0x50]
    16fc:      	sshll2.4s	v7, v7, #0x0
    1700:      	str	q7, [sp, #0x60]
    1704:      	bsl.16b	v7, v2, v6
    1708:      	ldr	q6, [sp, #0x1b0]
    170c:      	mov.16b	v17, v3
    1710:      	bsl.16b	v17, v2, v6
    1714:      	str	x6, [sp, #0x100]
    1718:      	add	x8, x24, x6
    171c:      	ldp	q3, q2, [x8]
    1720:      	zip1.8b	v6, v18, v0
    1724:      	ushll.4s	v6, v6, #0x0
    1728:      	shl.4s	v6, v6, #0x1f
    172c:      	cmlt.4s	v6, v6, #0
    1730:      	stp	q17, q7, [sp, #0x1a0]
    1734:      	bit.16b	v3, v17, v6
    1738:      	zip2.8b	v6, v18, v0
    173c:      	ushll.4s	v6, v6, #0x0
    1740:      	shl.4s	v6, v6, #0x1f
    1744:      	cmlt.4s	v6, v6, #0
    1748:      	bit.16b	v2, v7, v6
    174c:      	stp	q3, q2, [x8]
    1750:      	ldr	q2, [sp, #0x90]
    1754:      	fmov	x8, d2
    1758:      	dup.2d	v2, x27
    175c:      	and.16b	v13, v16, v2
    1760:      	ldr	q18, [sp, #0x1d0]
    1764:      	and.16b	v14, v18, v2
    1768:      	and.16b	v15, v5, v2
    176c:      	and.16b	v8, v4, v2
    1770:      	fmov	x13, d8
    1774:      	ldp	q2, q3, [x23, #0x180]
    1778:      	and.16b	v4, v0, v3
    177c:      	and.16b	v5, v1, v2
    1780:      	ldp	q2, q3, [x23, #0x160]
    1784:      	and.16b	v7, v0, v3
    1788:      	and.16b	v6, v1, v2
    178c:      	ldp	q2, q3, [x23, #0x140]
    1790:      	and.16b	v3, v0, v3
    1794:      	and.16b	v2, v1, v2
    1798:      	str	x8, [sp, #0x90]
    179c:      	add	x8, x24, x8
    17a0:      	ldp	q21, q20, [x8]
    17a4:      	and.16b	v20, v0, v20
    17a8:      	mov	x8, x13
    17ac:      	and.16b	v21, v1, v21
    17b0:      	mov.16b	v25, v8
    17b4:      	mov.16b	v26, v14
    17b8:      	mov.16b	v27, v15
    17bc:      	mov.16b	v28, v13
    17c0:      	mov.16b	v19, v16
    17c4:      	sshll.2d	v23, v1, #0x0
    17c8:      	sshll.2d	v9, v0, #0x0
    17cc:      	add	x8, x24, x8, lsl #5
    17d0:      	ldp	q22, q24, [x8]
    17d4:      	and.16b	v24, v0, v24
    17d8:      	and.16b	v22, v1, v22
    17dc:      	fmaxnm.4s	v22, v21, v22
    17e0:      	fmaxnm.4s	v24, v20, v24
    17e4:      	ldp	q10, q11, [x8, #0x20]
    17e8:      	and.16b	v11, v0, v11
    17ec:      	and.16b	v10, v1, v10
    17f0:      	fmaxnm.4s	v10, v2, v10
    17f4:      	fmaxnm.4s	v11, v3, v11
    17f8:      	ldp	q12, q29, [x8, #0x40]
    17fc:      	and.16b	v29, v0, v29
    1800:      	and.16b	v12, v1, v12
    1804:      	fmaxnm.4s	v12, v6, v12
    1808:      	fmaxnm.4s	v29, v7, v29
    180c:      	ldp	q30, q31, [x8, #0x60]
    1810:      	and.16b	v31, v0, v31
    1814:      	and.16b	v30, v1, v30
    1818:      	fmaxnm.4s	v30, v5, v30
    181c:      	fmaxnm.4s	v31, v4, v31
    1820:      	dup.2d	v16, x27
    1824:      	and.16b	v17, v19, v16
    1828:      	add.2d	v28, v28, v17
    182c:      	and.16b	v17, v18, v16
    1830:      	add.2d	v26, v26, v17
    1834:      	and.16b	v17, v9, v16
    1838:      	add.2d	v27, v27, v17
    183c:      	and.16b	v16, v23, v16
    1840:      	add.2d	v25, v25, v16
    1844:      	bit.16b	v20, v24, v0
    1848:      	bit.16b	v21, v22, v1
    184c:      	bit.16b	v3, v11, v0
    1850:      	bit.16b	v2, v10, v1
    1854:      	bit.16b	v7, v29, v0
    1858:      	bit.16b	v6, v12, v1
    185c:      	bit.16b	v4, v31, v0
    1860:      	bit.16b	v5, v30, v1
    1864:      	fmov	x8, d25
    1868:      	cmp	x8, #0x8
    186c:      	b.lt	0x17c4 <_llm_rows.packet_batch.blocks+0xdb4>
    1870:      	mov	x9, #0x0                ; =0
    1874:      	ldr	q16, [sp, #0xe0]
    1878:      	xtn.8b	v19, v16
    187c:      	ldr	q18, [sp, #0x1e0]
    1880:      	zip1.8b	v16, v18, v0
    1884:      	ushll.4s	v16, v16, #0x0
    1888:      	shl.4s	v16, v16, #0x1f
    188c:      	cmlt.4s	v16, v16, #0
    1890:      	ldr	q17, [sp, #0x1a0]
    1894:      	and.16b	v17, v16, v17
    1898:      	zip2.8b	v23, v18, v0
    189c:      	ushll.4s	v23, v23, #0x0
    18a0:      	shl.4s	v23, v23, #0x1f
    18a4:      	cmlt.4s	v23, v23, #0
    18a8:      	ldr	q18, [sp, #0x1b0]
    18ac:      	and.16b	v25, v23, v18
    18b0:      	fmaxnm.4s	v20, v20, v25
    18b4:      	fmaxnm.4s	v17, v21, v17
    18b8:      	and.16b	v16, v16, v17
    18bc:      	and.16b	v17, v23, v20
    18c0:      	zip2.8b	v20, v19, v0
    18c4:      	ushll.4s	v20, v20, #0x0
    18c8:      	shl.4s	v20, v20, #0x1f
    18cc:      	cmlt.4s	v20, v20, #0
    18d0:      	movi.2d	v21, #0000000000000000
    18d4:      	mov.b	v21[2], v19[1]
    18d8:      	mov.b	v21[4], v19[2]
    18dc:      	mov.b	v21[6], v19[3]
    18e0:      	bit.16b	v17, v24, v20
    18e4:      	ushll.4s	v20, v21, #0x0
    18e8:      	shl.4s	v20, v20, #0x1f
    18ec:      	cmlt.4s	v20, v20, #0
    18f0:      	bit.16b	v16, v22, v20
    18f4:      	fmaxnm.4s	v2, v16, v2
    18f8:      	fmaxnm.4s	v3, v17, v3
    18fc:      	fmaxnm.4s	v3, v3, v7
    1900:      	fmaxnm.4s	v2, v2, v6
    1904:      	fmaxnm.4s	v5, v2, v5
    1908:      	fmaxnm.4s	v6, v3, v4
    190c:      	ldp	q2, q4, [sp, #0xc0]
    1910:      	ldr	q3, [sp, #0xb0]
    1914:      	uzp1.4s	v23, v4, v3
    1918:      	ldr	q3, [sp, #0x80]
    191c:      	uzp1.4s	v4, v3, v2
    1920:      	movi.4s	v3, #0x1
    1924:      	eor.16b	v2, v23, v3
    1928:      	mov.s	w10, v2[1]
    192c:      	mov.s	w11, v2[2]
    1930:      	eor.16b	v20, v4, v3
    1934:      	mov.s	w15, v2[3]
    1938:      	fmov	w8, s2
    193c:      	add	x12, sp, #0x598
    1940:      	bfxil	x12, x8, #0, #3
    1944:      	str	d19, [sp, #0x598]
    1948:      	ldrb	w14, [x12]
    194c:      	and	x8, x8, #0x7
    1950:      	umov.b	w27, v19[0]
    1954:      	str	q6, [sp, #0x830]
    1958:      	str	q5, [sp, #0x820]
    195c:      	add	x16, sp, #0x820
    1960:      	ldr	s2, [x16, x8, lsl #2]
    1964:      	ands	w8, w27, #0x1
    1968:      	tst	w8, w14
    196c:      	movi	d18, #0000000000000000
    1970:      	fcsel	s7, s2, s18, ne
    1974:      	and	x14, x10, #0x7
    1978:      	add	x16, sp, #0x598
    197c:      	bfxil	x16, x10, #0, #3
    1980:      	ldrb	w10, [x16]
    1984:      	umov.b	w26, v19[1]
    1988:      	and	w10, w26, w10
    198c:      	str	q6, [sp, #0x810]
    1990:      	str	q5, [sp, #0x800]
    1994:      	add	x17, sp, #0x800
    1998:      	ldr	s2, [x17, x14, lsl #2]
    199c:      	tst	w10, #0x1
    19a0:      	fcsel	s2, s2, s18, ne
    19a4:      	and	x10, x11, #0x7
    19a8:      	add	x17, sp, #0x598
    19ac:      	bfxil	x17, x11, #0, #3
    19b0:      	umov.b	w16, v19[2]
    19b4:      	ldrb	w11, [x17]
    19b8:      	and	w11, w16, w11
    19bc:      	str	q6, [sp, #0x7f0]
    19c0:      	str	q5, [sp, #0x7e0]
    19c4:      	add	x17, sp, #0x7e0
    19c8:      	ldr	s3, [x17, x10, lsl #2]
    19cc:      	tst	w11, #0x1
    19d0:      	fcsel	s3, s3, s18, ne
    19d4:      	and	x10, x15, #0x7
    19d8:      	add	x11, sp, #0x598
    19dc:      	bfxil	x11, x15, #0, #3
    19e0:      	ldrb	w11, [x11]
    19e4:      	umov.b	w15, v19[3]
    19e8:      	str	q6, [sp, #0x7d0]
    19ec:      	str	q5, [sp, #0x7c0]
    19f0:      	add	x17, sp, #0x7c0
    19f4:      	ldr	s16, [x17, x10, lsl #2]
    19f8:      	and	w10, w15, w11
    19fc:      	tst	w10, #0x1
    1a00:      	mov.s	w10, v20[1]
    1a04:      	mov.s	w11, v20[2]
    1a08:      	fcsel	s21, s16, s18, ne
    1a0c:      	mov.s	w17, v20[3]
    1a10:      	fmov	w0, s20
    1a14:      	and	x1, x0, #0x7
    1a18:      	add	x2, sp, #0x598
    1a1c:      	bfxil	x2, x0, #0, #3
    1a20:      	ldrb	w0, [x2]
    1a24:      	umov.b	w14, v19[4]
    1a28:      	and	w0, w14, w0
    1a2c:      	str	q6, [sp, #0x8b0]
    1a30:      	str	q5, [sp, #0x8a0]
    1a34:      	add	x2, sp, #0x8a0
    1a38:      	ldr	s16, [x2, x1, lsl #2]
    1a3c:      	tst	w0, #0x1
    1a40:      	fcsel	s16, s16, s18, ne
    1a44:      	and	x0, x10, #0x7
    1a48:      	add	x1, sp, #0x598
    1a4c:      	bfxil	x1, x10, #0, #3
    1a50:      	ldrb	w10, [x1]
    1a54:      	umov.b	w12, v19[5]
    1a58:      	and	w10, w12, w10
    1a5c:      	str	q6, [sp, #0x890]
    1a60:      	str	q5, [sp, #0x880]
    1a64:      	add	x1, sp, #0x880
    1a68:      	ldr	s17, [x1, x0, lsl #2]
    1a6c:      	tst	w10, #0x1
    1a70:      	fcsel	s17, s17, s18, ne
    1a74:      	and	x10, x11, #0x7
    1a78:      	add	x0, sp, #0x598
    1a7c:      	bfxil	x0, x11, #0, #3
    1a80:      	ldrb	w11, [x0]
    1a84:      	umov.b	w22, v19[6]
    1a88:      	and	w11, w22, w11
    1a8c:      	str	q6, [sp, #0x870]
    1a90:      	str	q5, [sp, #0x860]
    1a94:      	add	x0, sp, #0x860
    1a98:      	ldr	s20, [x0, x10, lsl #2]
    1a9c:      	tst	w11, #0x1
    1aa0:      	fcsel	s20, s20, s18, ne
    1aa4:      	and	x10, x17, #0x7
    1aa8:      	add	x11, sp, #0x598
    1aac:      	bfxil	x11, x17, #0, #3
    1ab0:      	umov.b	w25, v19[7]
    1ab4:      	ldrb	w11, [x11]
    1ab8:      	and	w11, w25, w11
    1abc:      	str	q6, [sp, #0x850]
    1ac0:      	str	q5, [sp, #0x840]
    1ac4:      	add	x17, sp, #0x840
    1ac8:      	ldr	s22, [x17, x10, lsl #2]
    1acc:      	tst	w11, #0x1
    1ad0:      	fcsel	s22, s22, s18, ne
    1ad4:      	mov.s	v16[1], v17[0]
    1ad8:      	mov.s	v16[2], v20[0]
    1adc:      	mov.s	v16[3], v22[0]
    1ae0:      	mov.s	v7[1], v2[0]
    1ae4:      	mov.s	v7[2], v3[0]
    1ae8:      	mov.s	v7[3], v21[0]
    1aec:      	fmaxnm.4s	v5, v5, v7
    1af0:      	fmaxnm.4s	v6, v6, v16
    1af4:      	movi.4s	v3, #0x2
    1af8:      	eor.16b	v2, v23, v3
    1afc:      	mov.s	w10, v2[1]
    1b00:      	mov.s	w11, v2[2]
    1b04:      	mov.s	w17, v2[3]
    1b08:      	eor.16b	v3, v4, v3
    1b0c:      	fmov	w0, s2
    1b10:      	add	x2, sp, #0x598
    1b14:      	bfxil	x2, x0, #0, #3
    1b18:      	ldrb	w2, [x2]
    1b1c:      	and	x0, x0, #0x7
    1b20:      	str	q6, [sp, #0x7b0]
    1b24:      	str	q5, [sp, #0x7a0]
    1b28:      	add	x1, sp, #0x7a0
    1b2c:      	ldr	s2, [x1, x0, lsl #2]
    1b30:      	tst	w8, w2
    1b34:      	fcsel	s4, s2, s18, ne
    1b38:      	and	x0, x10, #0x7
    1b3c:      	add	x2, sp, #0x598
    1b40:      	bfxil	x2, x10, #0, #3
    1b44:      	ldrb	w10, [x2]
    1b48:      	and	w10, w26, w10
    1b4c:      	str	q6, [sp, #0x790]
    1b50:      	str	q5, [sp, #0x780]
    1b54:      	add	x1, sp, #0x780
    1b58:      	ldr	s2, [x1, x0, lsl #2]
    1b5c:      	tst	w10, #0x1
    1b60:      	fcsel	s7, s2, s18, ne
    1b64:      	and	x10, x11, #0x7
    1b68:      	add	x0, sp, #0x598
    1b6c:      	bfxil	x0, x11, #0, #3
    1b70:      	ldrb	w11, [x0]
    1b74:      	and	w11, w16, w11
    1b78:      	str	q6, [sp, #0x770]
    1b7c:      	str	q5, [sp, #0x760]
    1b80:      	add	x0, sp, #0x760
    1b84:      	ldr	s2, [x0, x10, lsl #2]
    1b88:      	tst	w11, #0x1
    1b8c:      	fcsel	s2, s2, s18, ne
    1b90:      	and	x10, x17, #0x7
    1b94:      	add	x11, sp, #0x598
    1b98:      	bfxil	x11, x17, #0, #3
    1b9c:      	ldrb	w11, [x11]
    1ba0:      	str	q6, [sp, #0x750]
    1ba4:      	str	q5, [sp, #0x740]
    1ba8:      	add	x17, sp, #0x740
    1bac:      	ldr	s20, [x17, x10, lsl #2]
    1bb0:      	and	w10, w15, w11
    1bb4:      	tst	w10, #0x1
    1bb8:      	mov.s	w2, v3[3]
    1bbc:      	mov.s	w21, v3[1]
    1bc0:      	fmov	w10, s3
    1bc4:      	and	x28, x10, #0x7
    1bc8:      	add	x1, sp, #0x598
    1bcc:      	bfxil	x1, x10, #0, #3
    1bd0:      	add	x10, sp, #0x598
    1bd4:      	bfxil	x10, x2, #0, #3
    1bd8:      	ldrb	w0, [x10]
    1bdc:      	movi.4s	v16, #0x4
    1be0:      	eor.16b	v16, v23, v16
    1be4:      	mov.s	w5, v16[1]
    1be8:      	mov.s	w11, v16[2]
    1bec:      	mov.s	w10, v16[3]
    1bf0:      	fmov	w17, s16
    1bf4:      	add	x4, sp, #0x598
    1bf8:      	bfxil	x4, x17, #0, #3
    1bfc:      	ldrb	w7, [x4]
    1c00:      	add	x4, sp, #0x598
    1c04:      	bfxil	x4, x5, #0, #3
    1c08:      	ldrb	w30, [x4]
    1c0c:      	add	x4, sp, #0x598
    1c10:      	bfxil	x4, x11, #0, #3
    1c14:      	ldrb	w6, [x4]
    1c18:      	add	x4, sp, #0x598
    1c1c:      	bfxil	x4, x10, #0, #3
    1c20:      	ldrb	w4, [x4]
    1c24:      	ldrb	w1, [x1]
    1c28:      	str	q6, [sp, #0x730]
    1c2c:      	str	q5, [sp, #0x720]
    1c30:      	add	x3, sp, #0x720
    1c34:      	ldr	s16, [x3, x28, lsl #2]
    1c38:      	add	x28, sp, #0x598
    1c3c:      	bfxil	x28, x21, #0, #3
    1c40:      	and	x21, x21, #0x7
    1c44:      	ldrb	w28, [x28]
    1c48:      	str	q6, [sp, #0x710]
    1c4c:      	str	q5, [sp, #0x700]
    1c50:      	add	x3, sp, #0x700
    1c54:      	ldr	s17, [x3, x21, lsl #2]
    1c58:      	fcsel	s20, s20, s18, ne
    1c5c:      	and	w1, w14, w1
    1c60:      	tst	w1, #0x1
    1c64:      	mov.s	w1, v3[2]
    1c68:      	fcsel	s3, s16, s18, ne
    1c6c:      	and	w21, w12, w28
    1c70:      	tst	w21, #0x1
    1c74:      	add	x21, sp, #0x598
    1c78:      	bfxil	x21, x1, #0, #3
    1c7c:      	and	x1, x1, #0x7
    1c80:      	ldrb	w21, [x21]
    1c84:      	str	q6, [sp, #0x6f0]
    1c88:      	str	q5, [sp, #0x6e0]
    1c8c:      	add	x3, sp, #0x6e0
    1c90:      	ldr	s16, [x3, x1, lsl #2]
    1c94:      	fcsel	s17, s17, s18, ne
    1c98:      	and	w1, w22, w21
    1c9c:      	tst	w1, #0x1
    1ca0:      	and	x1, x2, #0x7
    1ca4:      	str	q6, [sp, #0x6d0]
    1ca8:      	str	q5, [sp, #0x6c0]
    1cac:      	add	x2, sp, #0x6c0
    1cb0:      	ldr	s21, [x2, x1, lsl #2]
    1cb4:      	fcsel	s16, s16, s18, ne
    1cb8:      	and	w0, w25, w0
    1cbc:      	tst	w0, #0x1
    1cc0:      	fcsel	s21, s21, s18, ne
    1cc4:      	mov.s	v3[1], v17[0]
    1cc8:      	mov.s	v3[2], v16[0]
    1ccc:      	mov.s	v3[3], v21[0]
    1cd0:      	mov.s	v4[1], v7[0]
    1cd4:      	mov.s	v4[2], v2[0]
    1cd8:      	mov.s	v4[3], v20[0]
    1cdc:      	fmaxnm.4s	v2, v5, v4
    1ce0:      	fmaxnm.4s	v3, v6, v3
    1ce4:      	and	x17, x17, #0x7
    1ce8:      	str	q3, [sp, #0x6b0]
    1cec:      	str	q2, [sp, #0x6a0]
    1cf0:      	add	x0, sp, #0x6a0
    1cf4:      	ldr	s4, [x0, x17, lsl #2]
    1cf8:      	tst	w8, w7
    1cfc:      	fcsel	s4, s4, s18, ne
    1d00:      	and	x8, x5, #0x7
    1d04:      	and	w17, w26, w30
    1d08:      	str	q3, [sp, #0x690]
    1d0c:      	str	q2, [sp, #0x680]
    1d10:      	add	x0, sp, #0x680
    1d14:      	ldr	s5, [x0, x8, lsl #2]
    1d18:      	tst	w17, #0x1
    1d1c:      	fcsel	s5, s5, s18, ne
    1d20:      	and	x8, x11, #0x7
    1d24:      	str	q3, [sp, #0x670]
    1d28:      	str	q2, [sp, #0x660]
    1d2c:      	add	x11, sp, #0x660
    1d30:      	ldr	s6, [x11, x8, lsl #2]
    1d34:      	and	w8, w16, w6
    1d38:      	tst	w8, #0x1
    1d3c:      	fcsel	s6, s6, s18, ne
    1d40:      	and	x8, x10, #0x7
    1d44:      	and	w10, w15, w4
    1d48:      	str	q3, [sp, #0x650]
    1d4c:      	str	q2, [sp, #0x640]
    1d50:      	add	x11, sp, #0x640
    1d54:      	ldr	s3, [x11, x8, lsl #2]
    1d58:      	tst	w10, #0x1
    1d5c:      	fcsel	s3, s3, s18, ne
    1d60:      	ands	w4, w27, #0x1
    1d64:      	mov.s	v4[1], v5[0]
    1d68:      	mov.s	v4[2], v6[0]
    1d6c:      	mov.s	v4[3], v3[0]
    1d70:      	fmaxnm.4s	v2, v2, v4
    1d74:      	fcsel	s3, s2, s18, ne
    1d78:      	str	w26, [sp, #0xc0]
    1d7c:      	and	w8, w26, w27
    1d80:      	mov	x26, x12
    1d84:      	mov	x12, x27
    1d88:      	str	w8, [sp, #0x4c]
    1d8c:      	tst	w8, #0x1
    1d90:      	fcsel	s4, s2, s18, ne
    1d94:      	str	w16, [sp, #0xd0]
    1d98:      	and	w6, w16, w27
    1d9c:      	tst	w6, #0x1
    1da0:      	fcsel	s5, s2, s18, ne
    1da4:      	and	w7, w15, w27
    1da8:      	tst	w7, #0x1
    1dac:      	fcsel	s6, s2, s18, ne
    1db0:      	str	w14, [sp, #0xe0]
    1db4:      	and	w30, w14, w27
    1db8:      	tst	w30, #0x1
    1dbc:      	fcsel	s7, s2, s18, ne
    1dc0:      	and	w11, w26, w27
    1dc4:      	tst	w11, #0x1
    1dc8:      	fcsel	s16, s2, s18, ne
    1dcc:      	str	w22, [sp, #0xb0]
    1dd0:      	and	w8, w22, w27
    1dd4:      	tst	w8, #0x1
    1dd8:      	fcsel	s17, s2, s18, ne
    1ddc:      	str	w25, [sp, #0x80]
    1de0:      	and	w10, w25, w27
    1de4:      	tst	w10, #0x1
    1de8:      	mov.s	v3[1], v4[0]
    1dec:      	mov.s	v3[2], v5[0]
    1df0:      	mov.s	v3[3], v6[0]
    1df4:      	mov.s	v7[1], v16[0]
    1df8:      	fcsel	s2, s2, s18, ne
    1dfc:      	mov.s	v7[2], v17[0]
    1e00:      	mov.s	v7[3], v2[0]
    1e04:      	ldr	w17, [sp, #0xf0]
    1e08:      	rbit	w17, w17
    1e0c:      	clz	w2, w17
    1e10:      	str	q7, [sp, #0x5b0]
    1e14:      	str	q3, [sp, #0x5a0]
    1e18:      	and	x17, x2, #0x7
    1e1c:      	add	x0, sp, #0x5a0
    1e20:      	ldr	s2, [x0, x17, lsl #2]
    1e24:      	str	q19, [sp, #0xf0]
    1e28:      	mov.b	v19[0], wzr
    1e2c:      	str	q19, [sp, #0x30]
    1e30:      	mov	w17, #-0x800000         ; =-8388608
    1e34:      	fmov	s3, w17
    1e38:      	fmaxnm	s2, s2, s3
    1e3c:      	dup.4s	v4, v2[0]
    1e40:      	movi.2d	v12, #0000000000000000
    1e44:      	movi.2d	v20, #0000000000000000
    1e48:      	movi.2d	v5, #0000000000000000
    1e4c:      	movi.2d	v6, #0000000000000000
    1e50:      	mov	w1, #-0x3d300000        ; =-1026555904
    1e54:      	mov	w3, #0x42c80000         ; =1120403456
    1e58:      	mov	w21, #0xaa3b            ; =43579
    1e5c:      	movk	w21, #0x3fb8, lsl #16
    1e60:      	mov	w28, #0xbe8e            ; =48782
    1e64:      	movk	w28, #0xb5bf, lsl #16
    1e68:      	mov	w14, #0x7200            ; =29184
    1e6c:      	movk	w14, #0xbf31, lsl #16
    1e70:      	ldr	w22, [sp, #0xac]
    1e74:      	ldr	w25, [sp, #0x7c]
    1e78:      	b	0x20ac <_llm_rows.packet_batch.blocks+0x169c>
    1e7c:      	lsl	x9, x9, #5
    1e80:      	add	x17, x24, x9
    1e84:      	ldp	q3, q2, [x17]
    1e88:      	fsub.4s	v3, v3, v4
    1e8c:      	fsub.4s	v2, v2, v4
    1e90:      	and.16b	v28, v0, v2
    1e94:      	and.16b	v27, v1, v3
    1e98:      	dup.4s	v9, w1
    1e9c:      	fcmge.4s	v2, v27, v9
    1ea0:      	fcmge.4s	v3, v28, v9
    1ea4:      	dup.4s	v10, w3
    1ea8:      	fcmge.4s	v16, v10, v27
    1eac:      	fcmge.4s	v17, v10, v28
    1eb0:      	and.16b	v3, v3, v17
    1eb4:      	and.16b	v2, v2, v16
    1eb8:      	and.16b	v2, v2, v27
    1ebc:      	and.16b	v16, v3, v28
    1ec0:      	dup.4s	v3, w21
    1ec4:      	fmul.4s	v17, v16, v3
    1ec8:      	fmul.4s	v21, v2, v3
    1ecc:      	movi.4s	v18, #0x4b, lsl #24
    1ed0:      	mvni.4s	v19, #0x80, lsl #24
    1ed4:      	mov.16b	v22, v19
    1ed8:      	bsl.16b	v22, v18, v21
    1edc:      	mov.16b	v23, v19
    1ee0:      	bsl.16b	v23, v18, v17
    1ee4:      	fadd.4s	v17, v17, v23
    1ee8:      	fadd.4s	v21, v21, v22
    1eec:      	fsub.4s	v21, v21, v22
    1ef0:      	fsub.4s	v17, v17, v23
    1ef4:      	fcvtzs.4s	v17, v17
    1ef8:      	fcvtzs.4s	v29, v21
    1efc:      	scvtf.4s	v21, v29
    1f00:      	scvtf.4s	v22, v17
    1f04:      	dup.4s	v11, w14
    1f08:      	fmul.4s	v23, v22, v11
    1f0c:      	fmul.4s	v24, v21, v11
    1f10:      	fadd.4s	v24, v2, v24
    1f14:      	fadd.4s	v16, v16, v23
    1f18:      	dup.4s	v2, w28
    1f1c:      	fmul.4s	v21, v21, v2
    1f20:      	fmul.4s	v22, v22, v2
    1f24:      	fadd.4s	v16, v16, v22
    1f28:      	fadd.4s	v23, v24, v21
    1f2c:      	mov	w17, #0x2bda            ; =11226
    1f30:      	movk	w17, #0x3950, lsl #16
    1f34:      	dup.4s	v21, w17
    1f38:      	fmul.4s	v24, v23, v21
    1f3c:      	fmul.4s	v25, v16, v21
    1f40:      	mov	w17, #0x96c9            ; =38601
    1f44:      	movk	w17, #0x3ab6, lsl #16
    1f48:      	dup.4s	v22, w17
    1f4c:      	fadd.4s	v25, v25, v22
    1f50:      	fadd.4s	v24, v24, v22
    1f54:      	fmul.4s	v26, v23, v24
    1f58:      	fmul.4s	v25, v16, v25
    1f5c:      	mov	w17, #0x88a6            ; =34982
    1f60:      	movk	w17, #0x3c08, lsl #16
    1f64:      	dup.4s	v24, w17
    1f68:      	fadd.4s	v25, v25, v24
    1f6c:      	fadd.4s	v26, v26, v24
    1f70:      	fmul.4s	v26, v23, v26
    1f74:      	fmul.4s	v30, v16, v25
    1f78:      	mov	w17, #0xaa7a            ; =43642
    1f7c:      	movk	w17, #0x3d2a, lsl #16
    1f80:      	dup.4s	v25, w17
    1f84:      	fadd.4s	v30, v30, v25
    1f88:      	fadd.4s	v26, v26, v25
    1f8c:      	fmul.4s	v31, v23, v26
    1f90:      	fmul.4s	v30, v16, v30
    1f94:      	mov	w17, #0xaaab            ; =43691
    1f98:      	movk	w17, #0x3e2a, lsl #16
    1f9c:      	dup.4s	v26, w17
    1fa0:      	fadd.4s	v30, v30, v26
    1fa4:      	fadd.4s	v31, v31, v26
    1fa8:      	fmul.4s	v31, v23, v31
    1fac:      	fmul.4s	v30, v16, v30
    1fb0:      	movi.4s	v18, #0x3f, lsl #24
    1fb4:      	fadd.4s	v30, v30, v18
    1fb8:      	fadd.4s	v31, v31, v18
    1fbc:      	fmul.4s	v18, v16, v16
    1fc0:      	fmul.4s	v19, v23, v23
    1fc4:      	fmul.4s	v19, v19, v31
    1fc8:      	fmul.4s	v18, v18, v30
    1fcc:      	fadd.4s	v16, v16, v18
    1fd0:      	fadd.4s	v18, v23, v19
    1fd4:      	fmov.4s	v23, #1.00000000
    1fd8:      	fadd.4s	v18, v18, v23
    1fdc:      	fadd.4s	v16, v16, v23
    1fe0:      	sshr.4s	v19, v29, #0x1
    1fe4:      	sshr.4s	v30, v17, #0x1
    1fe8:      	shl.4s	v31, v30, #0x17
    1fec:      	add.4s	v31, v31, v23
    1ff0:      	fmul.4s	v16, v16, v31
    1ff4:      	shl.4s	v31, v19, #0x17
    1ff8:      	add.4s	v31, v31, v23
    1ffc:      	fmul.4s	v18, v18, v31
    2000:      	sub.4s	v17, v17, v30
    2004:      	sub.4s	v19, v29, v19
    2008:      	shl.4s	v19, v19, #0x17
    200c:      	add.4s	v19, v19, v23
    2010:      	fmul.4s	v18, v18, v19
    2014:      	shl.4s	v17, v17, #0x17
    2018:      	add.4s	v17, v17, v23
    201c:      	fmul.4s	v16, v16, v17
    2020:      	fcmgt.4s	v17, v9, v28
    2024:      	bic.16b	v16, v16, v17
    2028:      	fcmgt.4s	v17, v9, v27
    202c:      	bic.16b	v17, v18, v17
    2030:      	fcmgt.4s	v18, v27, v10
    2034:      	ldp	q19, q29, [sp, #0x240]
    2038:      	bit.16b	v17, v29, v18
    203c:      	fcmgt.4s	v18, v28, v10
    2040:      	bit.16b	v16, v29, v18
    2044:      	fcmeq.4s	v18, v28, v28
    2048:      	bif.16b	v16, v19, v18
    204c:      	cmeq.8b	v7, v7, #0
    2050:      	sshll.8h	v7, v7, #0x0
    2054:      	fcmeq.4s	v18, v27, v27
    2058:      	bif.16b	v17, v19, v18
    205c:      	sshll.4s	v18, v7, #0x0
    2060:      	bic.16b	v17, v17, v18
    2064:      	sshll2.4s	v7, v7, #0x0
    2068:      	bic.16b	v7, v16, v7
    206c:      	add	x9, x23, x9
    2070:      	ldp	q16, q18, [x9]
    2074:      	bif.16b	v7, v18, v0
    2078:      	bit.16b	v16, v17, v1
    207c:      	stp	q16, q7, [x9]
    2080:      	ldr	q7, [sp, #0x2a0]
    2084:      	add.2d	v20, v20, v7
    2088:      	ldr	q7, [sp, #0x290]
    208c:      	add.2d	v5, v5, v7
    2090:      	ldr	q7, [sp, #0x270]
    2094:      	add.2d	v6, v6, v7
    2098:      	ldr	q7, [sp, #0x260]
    209c:      	add.2d	v12, v12, v7
    20a0:      	fmov	x9, d12
    20a4:      	cmp	x9, #0x8
    20a8:      	b.ge	0x21a0 <_llm_rows.packet_batch.blocks+0x1790>
    20ac:      	ldr	q2, [sp, #0x280]
    20b0:      	fmov	w17, s2
    20b4:      	ldr	q2, [sp, #0x2b0]
    20b8:      	add.2d	v2, v12, v2
    20bc:      	ldr	q3, [sp, #0x2f0]
    20c0:      	add.2d	v2, v3, v2
    20c4:      	tbz	w17, #0x0, 0x20e0 <_llm_rows.packet_batch.blocks+0x16d0>
    20c8:      	fmov	x0, d2
    20cc:      	ldr	b7, [x0]
    20d0:      	ldp	q16, q3, [sp, #0x220]
    20d4:      	and	w5, w17, #0xff
    20d8:      	tbnz	w5, #0x1, 0x20f0 <_llm_rows.packet_batch.blocks+0x16e0>
    20dc:      	b	0x20f8 <_llm_rows.packet_batch.blocks+0x16e8>
    20e0:      	movi.2d	v7, #0000000000000000
    20e4:      	ldp	q16, q3, [sp, #0x220]
    20e8:      	and	w5, w17, #0xff
    20ec:      	tbz	w5, #0x1, 0x20f8 <_llm_rows.packet_batch.blocks+0x16e8>
    20f0:      	mov.d	x17, v2[1]
    20f4:      	ld1.b	{ v7 }[1], [x17]
    20f8:      	ldr	q2, [sp, #0x2d0]
    20fc:      	add.2d	v2, v20, v2
    2100:      	add.2d	v2, v16, v2
    2104:      	tbnz	w5, #0x2, 0x213c <_llm_rows.packet_batch.blocks+0x172c>
    2108:      	tbnz	w5, #0x3, 0x2148 <_llm_rows.packet_batch.blocks+0x1738>
    210c:      	ldr	q2, [sp, #0x2c0]
    2110:      	add.2d	v2, v5, v2
    2114:      	ldr	q16, [sp, #0x210]
    2118:      	add.2d	v2, v16, v2
    211c:      	tbnz	w5, #0x4, 0x2164 <_llm_rows.packet_batch.blocks+0x1754>
    2120:      	tbnz	w5, #0x5, 0x2170 <_llm_rows.packet_batch.blocks+0x1760>
    2124:      	ldr	q2, [sp, #0x2e0]
    2128:      	add.2d	v2, v6, v2
    212c:      	add.2d	v2, v3, v2
    2130:      	tbnz	w5, #0x6, 0x2188 <_llm_rows.packet_batch.blocks+0x1778>
    2134:      	tbz	w5, #0x7, 0x1e7c <_llm_rows.packet_batch.blocks+0x146c>
    2138:      	b	0x2194 <_llm_rows.packet_batch.blocks+0x1784>
    213c:      	fmov	x17, d2
    2140:      	ld1.b	{ v7 }[2], [x17]
    2144:      	tbz	w5, #0x3, 0x210c <_llm_rows.packet_batch.blocks+0x16fc>
    2148:      	mov.d	x17, v2[1]
    214c:      	ld1.b	{ v7 }[3], [x17]
    2150:      	ldr	q2, [sp, #0x2c0]
    2154:      	add.2d	v2, v5, v2
    2158:      	ldr	q16, [sp, #0x210]
    215c:      	add.2d	v2, v16, v2
    2160:      	tbz	w5, #0x4, 0x2120 <_llm_rows.packet_batch.blocks+0x1710>
    2164:      	fmov	x17, d2
    2168:      	ld1.b	{ v7 }[4], [x17]
    216c:      	tbz	w5, #0x5, 0x2124 <_llm_rows.packet_batch.blocks+0x1714>
    2170:      	mov.d	x17, v2[1]
    2174:      	ld1.b	{ v7 }[5], [x17]
    2178:      	ldr	q2, [sp, #0x2e0]
    217c:      	add.2d	v2, v6, v2
    2180:      	add.2d	v2, v3, v2
    2184:      	tbz	w5, #0x6, 0x2134 <_llm_rows.packet_batch.blocks+0x1724>
    2188:      	fmov	x17, d2
    218c:      	ld1.b	{ v7 }[6], [x17]
    2190:      	tbz	w5, #0x7, 0x1e7c <_llm_rows.packet_batch.blocks+0x146c>
    2194:      	mov.d	x17, v2[1]
    2198:      	ld1.b	{ v7 }[7], [x17]
    219c:      	b	0x1e7c <_llm_rows.packet_batch.blocks+0x146c>
    21a0:      	ldr	q5, [sp, #0x50]
    21a4:      	sshll.4s	v5, v5, #0x0
    21a8:      	ldp	q7, q6, [sp, #0x1a0]
    21ac:      	fsub.4s	v16, v7, v4
    21b0:      	fsub.4s	v4, v6, v4
    21b4:      	ldr	q12, [sp, #0x1e0]
    21b8:      	zip2.8b	v6, v12, v0
    21bc:      	ushll.4s	v6, v6, #0x0
    21c0:      	shl.4s	v6, v6, #0x1f
    21c4:      	cmlt.4s	v6, v6, #0
    21c8:      	and.16b	v4, v6, v4
    21cc:      	zip1.8b	v7, v12, v0
    21d0:      	ushll.4s	v7, v7, #0x0
    21d4:      	shl.4s	v7, v7, #0x1f
    21d8:      	cmlt.4s	v7, v7, #0
    21dc:      	and.16b	v20, v7, v16
    21e0:      	fcmge.4s	v16, v20, v9
    21e4:      	fcmge.4s	v17, v4, v9
    21e8:      	fcmge.4s	v18, v10, v20
    21ec:      	fcmge.4s	v19, v10, v4
    21f0:      	and.16b	v17, v17, v19
    21f4:      	and.16b	v16, v16, v18
    21f8:      	and.16b	v16, v16, v20
    21fc:      	and.16b	v17, v17, v4
    2200:      	fmul.4s	v18, v17, v3
    2204:      	fmul.4s	v3, v16, v3
    2208:      	movi.4s	v27, #0x4b, lsl #24
    220c:      	mvni.4s	v28, #0x80, lsl #24
    2210:      	mov.16b	v19, v28
    2214:      	bsl.16b	v19, v27, v3
    2218:      	bif.16b	v27, v18, v28
    221c:      	fadd.4s	v18, v18, v27
    2220:      	fadd.4s	v3, v3, v19
    2224:      	fsub.4s	v3, v3, v19
    2228:      	fsub.4s	v18, v18, v27
    222c:      	fcvtzs.4s	v18, v18
    2230:      	fcvtzs.4s	v3, v3
    2234:      	scvtf.4s	v19, v3
    2238:      	scvtf.4s	v27, v18
    223c:      	fmul.4s	v28, v27, v11
    2240:      	fmul.4s	v29, v19, v11
    2244:      	fadd.4s	v16, v16, v29
    2248:      	fadd.4s	v17, v17, v28
    224c:      	fmul.4s	v19, v19, v2
    2250:      	fmul.4s	v2, v27, v2
    2254:      	fadd.4s	v2, v17, v2
    2258:      	fadd.4s	v16, v16, v19
    225c:      	fmul.4s	v17, v16, v21
    2260:      	fmul.4s	v19, v2, v21
    2264:      	fadd.4s	v19, v19, v22
    2268:      	fadd.4s	v17, v17, v22
    226c:      	fmul.4s	v17, v16, v17
    2270:      	fmul.4s	v19, v2, v19
    2274:      	fadd.4s	v19, v19, v24
    2278:      	fadd.4s	v17, v17, v24
    227c:      	fmul.4s	v17, v16, v17
    2280:      	fmul.4s	v19, v2, v19
    2284:      	fadd.4s	v19, v19, v25
    2288:      	fadd.4s	v17, v17, v25
    228c:      	fmul.4s	v17, v16, v17
    2290:      	fmul.4s	v19, v2, v19
    2294:      	fadd.4s	v19, v19, v26
    2298:      	fadd.4s	v17, v17, v26
    229c:      	fmul.4s	v17, v16, v17
    22a0:      	fmul.4s	v19, v2, v19
    22a4:      	movi.4s	v21, #0x3f, lsl #24
    22a8:      	fadd.4s	v19, v19, v21
    22ac:      	fadd.4s	v17, v17, v21
    22b0:      	fmul.4s	v21, v2, v2
    22b4:      	fmul.4s	v22, v16, v16
    22b8:      	fmul.4s	v17, v22, v17
    22bc:      	fmul.4s	v19, v21, v19
    22c0:      	fadd.4s	v2, v2, v19
    22c4:      	fadd.4s	v16, v16, v17
    22c8:      	fadd.4s	v16, v16, v23
    22cc:      	fadd.4s	v2, v2, v23
    22d0:      	sshr.4s	v17, v3, #0x1
    22d4:      	sshr.4s	v19, v18, #0x1
    22d8:      	shl.4s	v21, v19, #0x17
    22dc:      	shl.4s	v22, v17, #0x17
    22e0:      	add.4s	v22, v22, v23
    22e4:      	add.4s	v21, v21, v23
    22e8:      	fmul.4s	v2, v2, v21
    22ec:      	fmul.4s	v16, v16, v22
    22f0:      	sub.4s	v18, v18, v19
    22f4:      	sub.4s	v3, v3, v17
    22f8:      	shl.4s	v3, v3, #0x17
    22fc:      	shl.4s	v17, v18, #0x17
    2300:      	add.4s	v17, v17, v23
    2304:      	add.4s	v3, v3, v23
    2308:      	fmul.4s	v3, v16, v3
    230c:      	fmul.4s	v2, v2, v17
    2310:      	fcmgt.4s	v16, v9, v4
    2314:      	bic.16b	v2, v2, v16
    2318:      	fcmgt.4s	v16, v9, v20
    231c:      	bic.16b	v3, v3, v16
    2320:      	fcmgt.4s	v16, v4, v10
    2324:      	fcmgt.4s	v17, v20, v10
    2328:      	ldr	q18, [sp, #0x250]
    232c:      	bit.16b	v3, v18, v17
    2330:      	bit.16b	v2, v18, v16
    2334:      	fcmeq.4s	v16, v20, v20
    2338:      	fcmeq.4s	v4, v4, v4
    233c:      	ldr	q17, [sp, #0x240]
    2340:      	bif.16b	v2, v17, v4
    2344:      	bif.16b	v3, v17, v16
    2348:      	bic.16b	v5, v3, v5
    234c:      	ldr	q3, [sp, #0x60]
    2350:      	bic.16b	v4, v2, v3
    2354:      	ldr	x9, [sp, #0x100]
    2358:      	add	x9, x23, x9
    235c:      	ldp	q2, q3, [x9]
    2360:      	bit.16b	v3, v4, v6
    2364:      	bit.16b	v2, v5, v7
    2368:      	stp	q2, q3, [x9]
    236c:      	ldp	q3, q2, [x23, #0x60]
    2370:      	and.16b	v2, v0, v2
    2374:      	and.16b	v3, v1, v3
    2378:      	ldp	q6, q7, [x23, #0x40]
    237c:      	and.16b	v20, v0, v7
    2380:      	and.16b	v7, v1, v6
    2384:      	ldp	q6, q16, [x23, #0x20]
    2388:      	and.16b	v21, v0, v16
    238c:      	and.16b	v22, v1, v6
    2390:      	ldr	x9, [sp, #0x90]
    2394:      	add	x9, x23, x9
    2398:      	ldp	q6, q16, [x9]
    239c:      	and.16b	v25, v0, v16
    23a0:      	and.16b	v24, v1, v6
    23a4:      	ldp	q10, q9, [sp, #0x1c0]
    23a8:      	mov	w27, #0x4               ; =4
    23ac:      	sshll.2d	v6, v1, #0x0
    23b0:      	sshll.2d	v16, v0, #0x0
    23b4:      	add	x9, x23, x13, lsl #5
    23b8:      	ldp	q18, q17, [x9]
    23bc:      	fadd.4s	v26, v24, v18
    23c0:      	fadd.4s	v27, v25, v17
    23c4:      	ldp	q18, q17, [x9, #0x20]
    23c8:      	fadd.4s	v18, v22, v18
    23cc:      	fadd.4s	v17, v21, v17
    23d0:      	ldp	q23, q19, [x9, #0x40]
    23d4:      	fadd.4s	v23, v7, v23
    23d8:      	fadd.4s	v19, v20, v19
    23dc:      	ldp	q29, q28, [x9, #0x60]
    23e0:      	fadd.4s	v29, v3, v29
    23e4:      	fadd.4s	v28, v2, v28
    23e8:      	dup.2d	v30, x27
    23ec:      	and.16b	v31, v10, v30
    23f0:      	add.2d	v13, v13, v31
    23f4:      	and.16b	v31, v9, v30
    23f8:      	add.2d	v14, v14, v31
    23fc:      	and.16b	v16, v16, v30
    2400:      	add.2d	v15, v15, v16
    2404:      	and.16b	v6, v6, v30
    2408:      	add.2d	v8, v8, v6
    240c:      	bit.16b	v25, v27, v0
    2410:      	bit.16b	v24, v26, v1
    2414:      	bit.16b	v21, v17, v0
    2418:      	bit.16b	v22, v18, v1
    241c:      	bit.16b	v20, v19, v0
    2420:      	bit.16b	v7, v23, v1
    2424:      	bit.16b	v2, v28, v0
    2428:      	bit.16b	v3, v29, v1
    242c:      	fmov	x13, d8
    2430:      	cmp	x13, #0x8
    2434:      	b.lt	0x23ac <_llm_rows.packet_batch.blocks+0x199c>
    2438:      	mov	x9, #0x0                ; =0
    243c:      	adrp	x13, 0x2000 <_llm_rows.packet_batch.blocks+0x15f0>
    2440:      	ldr	q6, [x13]
    2444:      	and.16b	v23, v0, v6
    2448:      	adrp	x13, 0x2000 <_llm_rows.packet_batch.blocks+0x15f0>
    244c:      	ldr	q6, [x13]
    2450:      	and.16b	v28, v1, v6
    2454:      	adrp	x13, 0x2000 <_llm_rows.packet_batch.blocks+0x15f0>
    2458:      	ldr	q6, [x13]
    245c:      	and.16b	v6, v1, v6
    2460:      	fadd.4s	v16, v4, v25
    2464:      	fadd.4s	v17, v5, v24
    2468:      	zip1.8b	v18, v12, v0
    246c:      	ushll.4s	v18, v18, #0x0
    2470:      	shl.4s	v18, v18, #0x1f
    2474:      	cmlt.4s	v18, v18, #0
    2478:      	and.16b	v17, v18, v17
    247c:      	zip2.8b	v18, v12, v0
    2480:      	ushll.4s	v18, v18, #0x0
    2484:      	shl.4s	v18, v18, #0x1f
    2488:      	cmlt.4s	v18, v18, #0
    248c:      	and.16b	v16, v18, v16
    2490:      	ldr	q19, [sp, #0x30]
    2494:      	zip2.8b	v18, v19, v0
    2498:      	ushll.4s	v18, v18, #0x0
    249c:      	shl.4s	v18, v18, #0x1f
    24a0:      	cmlt.4s	v18, v18, #0
    24a4:      	bit.16b	v16, v27, v18
    24a8:      	zip1.8b	v18, v19, v0
    24ac:      	ushll.4s	v18, v18, #0x0
    24b0:      	shl.4s	v18, v18, #0x1f
    24b4:      	cmlt.4s	v18, v18, #0
    24b8:      	bit.16b	v17, v26, v18
    24bc:      	fadd.4s	v17, v22, v17
    24c0:      	fadd.4s	v16, v21, v16
    24c4:      	fadd.4s	v16, v20, v16
    24c8:      	fadd.4s	v7, v7, v17
    24cc:      	fadd.4s	v3, v3, v7
    24d0:      	fadd.4s	v7, v2, v16
    24d4:      	fmov	w13, s28
    24d8:      	add	x17, sp, #0x348
    24dc:      	bfxil	x17, x13, #0, #3
    24e0:      	ldr	q2, [sp, #0xf0]
    24e4:      	str	d2, [sp, #0x348]
    24e8:      	ldrb	w17, [x17]
    24ec:      	add	x0, sp, #0x570
    24f0:      	orr	x13, x0, x13, lsl #2
    24f4:      	str	q7, [sp, #0x580]
    24f8:      	str	q3, [sp, #0x570]
    24fc:      	ldr	s2, [x13]
    2500:      	tst	w4, w17
    2504:      	movi	d24, #0000000000000000
    2508:      	fcsel	s2, s2, s24, ne
    250c:      	mov.s	w13, v28[1]
    2510:      	add	x17, sp, #0x348
    2514:      	bfxil	x17, x13, #0, #3
    2518:      	ldrb	w13, [x17]
    251c:      	ldr	w16, [sp, #0xc0]
    2520:      	and	w13, w16, w13
    2524:      	str	q3, [sp, #0x550]
    2528:      	ldr	s16, [sp, #0x550]
    252c:      	tst	w13, #0x1
    2530:      	fcsel	s20, s16, s24, ne
    2534:      	mov.s	w13, v28[2]
    2538:      	add	x17, sp, #0x348
    253c:      	bfxil	x17, x13, #0, #3
    2540:      	add	x0, sp, #0x530
    2544:      	orr	x13, x0, x13, lsl #2
    2548:      	ldrb	w17, [x17]
    254c:      	ldr	w14, [sp, #0xd0]
    2550:      	and	w17, w14, w17
    2554:      	str	q7, [sp, #0x540]
    2558:      	str	q3, [sp, #0x530]
    255c:      	ldr	s16, [x13]
    2560:      	tst	w17, #0x1
    2564:      	fcsel	s21, s16, s24, ne
    2568:      	mov.s	w13, v28[3]
    256c:      	add	x17, sp, #0x348
    2570:      	bfxil	x17, x13, #0, #3
    2574:      	add	x0, sp, #0x510
    2578:      	orr	x13, x0, x13, lsl #2
    257c:      	ldrb	w17, [x17]
    2580:      	and	w17, w15, w17
    2584:      	str	q7, [sp, #0x520]
    2588:      	str	q3, [sp, #0x510]
    258c:      	ldr	s16, [x13]
    2590:      	tst	w17, #0x1
    2594:      	fcsel	s22, s16, s24, ne
    2598:      	fmov	w13, s23
    259c:      	add	x17, sp, #0x348
    25a0:      	bfxil	x17, x13, #0, #3
    25a4:      	ldrb	w17, [x17]
    25a8:      	ldr	w1, [sp, #0xe0]
    25ac:      	and	w17, w1, w17
    25b0:      	str	q7, [sp, #0x500]
    25b4:      	str	q3, [sp, #0x4f0]
    25b8:      	add	x0, sp, #0x4f0
    25bc:      	ldr	s16, [x0, w13, uxtw #2]
    25c0:      	tst	w17, #0x1
    25c4:      	fcsel	s16, s16, s24, ne
    25c8:      	mov.s	w13, v23[1]
    25cc:      	add	x17, sp, #0x348
    25d0:      	bfxil	x17, x13, #0, #3
    25d4:      	ldrb	w17, [x17]
    25d8:      	and	w17, w26, w17
    25dc:      	str	q7, [sp, #0x4e0]
    25e0:      	str	q3, [sp, #0x4d0]
    25e4:      	add	x0, sp, #0x4d0
    25e8:      	ldr	s17, [x0, w13, uxtw #2]
    25ec:      	tst	w17, #0x1
    25f0:      	fcsel	s17, s17, s24, ne
    25f4:      	mov.s	w13, v23[2]
    25f8:      	add	x17, sp, #0x348
    25fc:      	bfxil	x17, x13, #0, #3
    2600:      	ldrb	w17, [x17]
    2604:      	ldr	w3, [sp, #0xb0]
    2608:      	and	w17, w3, w17
    260c:      	str	q7, [sp, #0x4c0]
    2610:      	str	q3, [sp, #0x4b0]
    2614:      	add	x0, sp, #0x4b0
    2618:      	ldr	s18, [x0, w13, uxtw #2]
    261c:      	tst	w17, #0x1
    2620:      	fcsel	s18, s18, s24, ne
    2624:      	mov.s	w13, v23[3]
    2628:      	add	x17, sp, #0x348
    262c:      	bfxil	x17, x13, #0, #3
    2630:      	ldrb	w17, [x17]
    2634:      	ldr	w5, [sp, #0x80]
    2638:      	and	w17, w5, w17
    263c:      	str	q7, [sp, #0x4a0]
    2640:      	str	q3, [sp, #0x490]
    2644:      	add	x0, sp, #0x490
    2648:      	ldr	s19, [x0, w13, uxtw #2]
    264c:      	tst	w17, #0x1
    2650:      	fcsel	s19, s19, s24, ne
    2654:      	mov.s	v16[1], v17[0]
    2658:      	mov.s	v16[2], v18[0]
    265c:      	mov.s	v16[3], v19[0]
    2660:      	mov.s	v2[1], v20[0]
    2664:      	mov.s	v2[2], v21[0]
    2668:      	mov.s	v2[3], v22[0]
    266c:      	fadd.4s	v2, v3, v2
    2670:      	fadd.4s	v3, v7, v16
    2674:      	fmov	w13, s6
    2678:      	add	x17, sp, #0x348
    267c:      	bfxil	x17, x13, #0, #3
    2680:      	ldrb	w17, [x17]
    2684:      	add	x0, sp, #0x470
    2688:      	orr	x13, x0, x13, lsl #2
    268c:      	str	q3, [sp, #0x480]
    2690:      	str	q2, [sp, #0x470]
    2694:      	ldr	s7, [x13]
    2698:      	mov.s	w13, v6[1]
    269c:      	tst	w4, w17
    26a0:      	add	x17, sp, #0x348
    26a4:      	bfxil	x17, x13, #0, #3
    26a8:      	ldrb	w17, [x17]
    26ac:      	and	w16, w16, w17
    26b0:      	fcsel	s7, s7, s24, ne
    26b4:      	add	x17, sp, #0x450
    26b8:      	orr	x13, x17, x13, lsl #2
    26bc:      	str	q3, [sp, #0x460]
    26c0:      	str	q2, [sp, #0x450]
    26c4:      	ldr	s16, [x13]
    26c8:      	mov.s	w13, v6[2]
    26cc:      	tst	w16, #0x1
    26d0:      	add	x16, sp, #0x348
    26d4:      	bfxil	x16, x13, #0, #3
    26d8:      	adrp	x13, 0x2000 <_llm_rows.packet_batch.blocks+0x15f0>
    26dc:      	ldr	q17, [x13]
    26e0:      	and.16b	v17, v0, v17
    26e4:      	movi.4s	v18, #0x4
    26e8:      	and.16b	v20, v1, v18
    26ec:      	fcsel	s21, s16, s24, ne
    26f0:      	ldrb	w13, [x16]
    26f4:      	and	w13, w14, w13
    26f8:      	str	q2, [sp, #0x430]
    26fc:      	ldr	s16, [sp, #0x430]
    2700:      	tst	w13, #0x1
    2704:      	fcsel	s22, s16, s24, ne
    2708:      	mov.s	w13, v6[3]
    270c:      	add	x14, sp, #0x348
    2710:      	bfxil	x14, x13, #0, #3
    2714:      	add	x16, sp, #0x410
    2718:      	orr	x13, x16, x13, lsl #2
    271c:      	ldrb	w14, [x14]
    2720:      	and	w14, w15, w14
    2724:      	str	q3, [sp, #0x420]
    2728:      	str	q2, [sp, #0x410]
    272c:      	ldr	s6, [x13]
    2730:      	tst	w14, #0x1
    2734:      	fcsel	s6, s6, s24, ne
    2738:      	fmov	w13, s17
    273c:      	add	x14, sp, #0x348
    2740:      	bfxil	x14, x13, #0, #3
    2744:      	ldrb	w14, [x14]
    2748:      	and	w14, w1, w14
    274c:      	stp	q2, q3, [sp, #0x3f0]
    2750:      	add	x15, sp, #0x3f0
    2754:      	ldr	s16, [x15, w13, uxtw #2]
    2758:      	tst	w14, #0x1
    275c:      	fcsel	s16, s16, s24, ne
    2760:      	mov.s	w13, v17[1]
    2764:      	add	x14, sp, #0x348
    2768:      	bfxil	x14, x13, #0, #3
    276c:      	ldrb	w14, [x14]
    2770:      	and	w14, w26, w14
    2774:      	stp	q2, q3, [sp, #0x3d0]
    2778:      	add	x15, sp, #0x3d0
    277c:      	ldr	s18, [x15, w13, uxtw #2]
    2780:      	tst	w14, #0x1
    2784:      	fcsel	s18, s18, s24, ne
    2788:      	mov.s	w13, v17[2]
    278c:      	add	x14, sp, #0x348
    2790:      	bfxil	x14, x13, #0, #3
    2794:      	ldrb	w14, [x14]
    2798:      	and	w14, w3, w14
    279c:      	stp	q2, q3, [sp, #0x3b0]
    27a0:      	add	x15, sp, #0x3b0
    27a4:      	ldr	s19, [x15, w13, uxtw #2]
    27a8:      	tst	w14, #0x1
    27ac:      	fcsel	s19, s19, s24, ne
    27b0:      	mov.s	w13, v17[3]
    27b4:      	add	x14, sp, #0x348
    27b8:      	bfxil	x14, x13, #0, #3
    27bc:      	ldrb	w14, [x14]
    27c0:      	and	w14, w5, w14
    27c4:      	stp	q2, q3, [sp, #0x390]
    27c8:      	add	x15, sp, #0x390
    27cc:      	ldr	s17, [x15, w13, uxtw #2]
    27d0:      	tst	w14, #0x1
    27d4:      	fcsel	s17, s17, s24, ne
    27d8:      	mov.s	v16[1], v18[0]
    27dc:      	mov.s	v16[2], v19[0]
    27e0:      	mov.s	v16[3], v17[0]
    27e4:      	mov.s	v7[1], v21[0]
    27e8:      	mov.s	v7[2], v22[0]
    27ec:      	mov.s	v7[3], v6[0]
    27f0:      	fadd.4s	v2, v2, v7
    27f4:      	fadd.4s	v3, v3, v16
    27f8:      	fmov	w13, s20
    27fc:      	add	x14, sp, #0x348
    2800:      	orr	x14, x14, x13
    2804:      	ldrb	w14, [x14]
    2808:      	stp	q2, q3, [sp, #0x370]
    280c:      	add	x15, sp, #0x370
    2810:      	ldr	s3, [x15, w13, uxtw #2]
    2814:      	tst	w4, w14
    2818:      	fcsel	s3, s3, s24, ne
    281c:      	tst	w12, #0x1
    2820:      	fadd	s2, s2, s3
    2824:      	fcsel	s3, s2, s24, ne
    2828:      	ldr	w12, [sp, #0x4c]
    282c:      	tst	w12, #0x1
    2830:      	fcsel	s6, s2, s24, ne
    2834:      	tst	w6, #0x1
    2838:      	fcsel	s7, s2, s24, ne
    283c:      	tst	w7, #0x1
    2840:      	fcsel	s16, s2, s24, ne
    2844:      	tst	w30, #0x1
    2848:      	fcsel	s17, s2, s24, ne
    284c:      	tst	w11, #0x1
    2850:      	fcsel	s18, s2, s24, ne
    2854:      	tst	w8, #0x1
    2858:      	fcsel	s19, s2, s24, ne
    285c:      	tst	w10, #0x1
    2860:      	fcsel	s2, s2, s24, ne
    2864:      	mov.s	v3[1], v6[0]
    2868:      	mov.s	v3[2], v7[0]
    286c:      	mov.s	v3[3], v16[0]
    2870:      	mov.s	v17[1], v18[0]
    2874:      	mov.s	v17[2], v19[0]
    2878:      	mov.s	v17[3], v2[0]
    287c:      	stp	q3, q17, [sp, #0x350]
    2880:      	and	x8, x2, #0x7
    2884:      	add	x10, sp, #0x350
    2888:      	ldr	s2, [x10, x8, lsl #2]
    288c:      	fadd	s2, s2, s24
    2890:      	dup.4s	v3, v2[0]
    2894:      	ldr	q2, [sp, #0x110]
    2898:      	fmov	x8, d2
    289c:      	ldp	x14, x13, [sp, #0x168]
    28a0:      	add	x8, x13, x8, lsl #2
    28a4:      	movi.2d	v2, #0000000000000000
    28a8:      	movi.2d	v6, #0000000000000000
    28ac:      	movi.2d	v7, #0000000000000000
    28b0:      	movi.2d	v20, #0000000000000000
    28b4:      	movi.2s	v8, #0x41
    28b8:      	ldr	w12, [sp, #0x178]
    28bc:      	ldp	q18, q17, [sp, #0x270]
    28c0:      	ldp	q23, q19, [sp, #0x290]
    28c4:      	ldr	q24, [sp, #0x260]
    28c8:      	b	0x28e8 <_llm_rows.packet_batch.blocks+0x1ed8>
    28cc:      	add.2d	v6, v6, v19
    28d0:      	add.2d	v7, v7, v23
    28d4:      	add.2d	v20, v20, v18
    28d8:      	add.2d	v2, v2, v24
    28dc:      	fmov	x9, d2
    28e0:      	cmp	x9, #0x8
    28e4:      	b.ge	0x2998 <_llm_rows.packet_batch.blocks+0x1f88>
    28e8:      	fmov	w10, s17
    28ec:      	lsl	x9, x9, #5
    28f0:      	add	x11, x23, x9
    28f4:      	ldp	q16, q21, [x11]
    28f8:      	and.16b	v16, v1, v16
    28fc:      	fdiv.4s	v22, v16, v3
    2900:      	add	x9, x8, x9
    2904:      	tbnz	w10, #0x0, 0x2934 <_llm_rows.packet_batch.blocks+0x1f24>
    2908:      	and	w10, w10, #0xff
    290c:      	tbnz	w10, #0x1, 0x2940 <_llm_rows.packet_batch.blocks+0x1f30>
    2910:      	tbnz	w10, #0x2, 0x294c <_llm_rows.packet_batch.blocks+0x1f3c>
    2914:      	tbnz	w10, #0x3, 0x2958 <_llm_rows.packet_batch.blocks+0x1f48>
    2918:      	and.16b	v16, v0, v21
    291c:      	fdiv.4s	v21, v16, v3
    2920:      	tbnz	w10, #0x4, 0x296c <_llm_rows.packet_batch.blocks+0x1f5c>
    2924:      	tbnz	w10, #0x5, 0x2974 <_llm_rows.packet_batch.blocks+0x1f64>
    2928:      	tbnz	w10, #0x6, 0x2980 <_llm_rows.packet_batch.blocks+0x1f70>
    292c:      	tbz	w10, #0x7, 0x28cc <_llm_rows.packet_batch.blocks+0x1ebc>
    2930:      	b	0x298c <_llm_rows.packet_batch.blocks+0x1f7c>
    2934:      	str	s22, [x9]
    2938:      	and	w10, w10, #0xff
    293c:      	tbz	w10, #0x1, 0x2910 <_llm_rows.packet_batch.blocks+0x1f00>
    2940:      	add	x11, x9, #0x4
    2944:      	st1.s	{ v22 }[1], [x11]
    2948:      	tbz	w10, #0x2, 0x2914 <_llm_rows.packet_batch.blocks+0x1f04>
    294c:      	add	x11, x9, #0x8
    2950:      	st1.s	{ v22 }[2], [x11]
    2954:      	tbz	w10, #0x3, 0x2918 <_llm_rows.packet_batch.blocks+0x1f08>
    2958:      	add	x11, x9, #0xc
    295c:      	st1.s	{ v22 }[3], [x11]
    2960:      	and.16b	v16, v0, v21
    2964:      	fdiv.4s	v21, v16, v3
    2968:      	tbz	w10, #0x4, 0x2924 <_llm_rows.packet_batch.blocks+0x1f14>
    296c:      	str	s21, [x9, #0x10]
    2970:      	tbz	w10, #0x5, 0x2928 <_llm_rows.packet_batch.blocks+0x1f18>
    2974:      	add	x11, x9, #0x14
    2978:      	st1.s	{ v21 }[1], [x11]
    297c:      	tbz	w10, #0x6, 0x292c <_llm_rows.packet_batch.blocks+0x1f1c>
    2980:      	add	x11, x9, #0x18
    2984:      	st1.s	{ v21 }[2], [x11]
    2988:      	tbz	w10, #0x7, 0x28cc <_llm_rows.packet_batch.blocks+0x1ebc>
    298c:      	add	x9, x9, #0x1c
    2990:      	st1.s	{ v21 }[3], [x9]
    2994:      	b	0x28cc <_llm_rows.packet_batch.blocks+0x1ebc>
    2998:      	ldr	d0, [sp, #0x108]
    299c:      	fmov	w8, s0
    29a0:      	zip1.8b	v0, v12, v0
    29a4:      	ushll.4s	v0, v0, #0x0
    29a8:      	shl.4s	v0, v0, #0x1f
    29ac:      	cmlt.4s	v0, v0, #0
    29b0:      	and.16b	v0, v0, v5
    29b4:      	fdiv.4s	v0, v0, v3
    29b8:      	ldp	q1, q2, [sp, #0x140]
    29bc:      	ldp	q6, q5, [sp, #0x120]
    29c0:      	stp	q2, q5, [sp, #0x300]
    29c4:      	stp	q6, q1, [sp, #0x320]
    29c8:      	and	x9, x14, #0x7
    29cc:      	add	x10, sp, #0x300
    29d0:      	ldr	x9, [x10, x9, lsl #3]
    29d4:      	sub	x9, x9, x14
    29d8:      	add	x9, x13, x9, lsl #2
    29dc:      	tbnz	w8, #0x0, 0x2a68 <_llm_rows.packet_batch.blocks+0x2058>
    29e0:      	tbnz	w8, #0x1, 0x2a70 <_llm_rows.packet_batch.blocks+0x2060>
    29e4:      	tbnz	w8, #0x2, 0x2a7c <_llm_rows.packet_batch.blocks+0x206c>
    29e8:      	tbz	w8, #0x3, 0x29f4 <_llm_rows.packet_batch.blocks+0x1fe4>
    29ec:      	add	x10, x9, #0xc
    29f0:      	st1.s	{ v0 }[3], [x10]
    29f4:      	zip2.8b	v0, v12, v0
    29f8:      	ushll.4s	v0, v0, #0x0
    29fc:      	shl.4s	v0, v0, #0x1f
    2a00:      	cmlt.4s	v0, v0, #0
    2a04:      	and.16b	v0, v0, v4
    2a08:      	fdiv.4s	v0, v0, v3
    2a0c:      	tbnz	w8, #0x4, 0x2a8c <_llm_rows.packet_batch.blocks+0x207c>
    2a10:      	tbnz	w8, #0x5, 0x2a94 <_llm_rows.packet_batch.blocks+0x2084>
    2a14:      	tbnz	w8, #0x6, 0x2aa0 <_llm_rows.packet_batch.blocks+0x2090>
    2a18:      	tbz	w8, #0x7, 0xac4 <_llm_rows.packet_batch.blocks+0xb4>
    2a1c:      	b	0x2aac <_llm_rows.packet_batch.blocks+0x209c>
    2a20:      	fmov	x11, d13
    2a24:      	ld1.b	{ v3 }[2], [x11]
    2a28:      	tbz	w12, #0x3, 0x16b4 <_llm_rows.packet_batch.blocks+0xca4>
    2a2c:      	ld1.b	{ v3 }[3], [x10]
    2a30:      	tbz	w12, #0x4, 0x16b8 <_llm_rows.packet_batch.blocks+0xca8>
    2a34:      	fmov	x10, d20
    2a38:      	ld1.b	{ v3 }[4], [x10]
    2a3c:      	tbz	w12, #0x5, 0x16bc <_llm_rows.packet_batch.blocks+0xcac>
    2a40:      	ld1.b	{ v3 }[5], [x9]
    2a44:      	tbz	w12, #0x6, 0x16c0 <_llm_rows.packet_batch.blocks+0xcb0>
    2a48:      	fmov	x9, d5
    2a4c:      	ld1.b	{ v3 }[6], [x9]
    2a50:      	stp	q29, q19, [sp, #0x260]
    2a54:      	stp	q31, q30, [sp, #0x220]
    2a58:      	str	d7, [sp, #0x108]
    2a5c:      	str	q12, [sp, #0x210]
    2a60:      	tbnz	w12, #0x7, 0x16d4 <_llm_rows.packet_batch.blocks+0xcc4>
    2a64:      	b	0x16d8 <_llm_rows.packet_batch.blocks+0xcc8>
    2a68:      	str	s0, [x9]
    2a6c:      	tbz	w8, #0x1, 0x29e4 <_llm_rows.packet_batch.blocks+0x1fd4>
    2a70:      	add	x10, x9, #0x4
    2a74:      	st1.s	{ v0 }[1], [x10]
    2a78:      	tbz	w8, #0x2, 0x29e8 <_llm_rows.packet_batch.blocks+0x1fd8>
    2a7c:      	add	x10, x9, #0x8
    2a80:      	st1.s	{ v0 }[2], [x10]
    2a84:      	tbnz	w8, #0x3, 0x29ec <_llm_rows.packet_batch.blocks+0x1fdc>
    2a88:      	b	0x29f4 <_llm_rows.packet_batch.blocks+0x1fe4>
    2a8c:      	str	s0, [x9, #0x10]
    2a90:      	tbz	w8, #0x5, 0x2a14 <_llm_rows.packet_batch.blocks+0x2004>
    2a94:      	add	x10, x9, #0x14
    2a98:      	st1.s	{ v0 }[1], [x10]
    2a9c:      	tbz	w8, #0x6, 0x2a18 <_llm_rows.packet_batch.blocks+0x2008>
    2aa0:      	add	x10, x9, #0x18
    2aa4:      	st1.s	{ v0 }[2], [x10]
    2aa8:      	tbz	w8, #0x7, 0xac4 <_llm_rows.packet_batch.blocks+0xb4>
    2aac:      	add	x8, x9, #0x1c
    2ab0:      	st1.s	{ v0 }[3], [x8]
    2ab4:      	b	0xac4 <_llm_rows.packet_batch.blocks+0xb4>
    2ab8:      	add	sp, sp, #0xf80
    2abc:      	ldp	x29, x30, [sp, #0x90]
    2ac0:      	ldp	x20, x19, [sp, #0x80]
    2ac4:      	ldp	x22, x21, [sp, #0x70]
    2ac8:      	ldp	x24, x23, [sp, #0x60]
    2acc:      	ldp	x26, x25, [sp, #0x50]
    2ad0:      	ldp	x28, x27, [sp, #0x40]
    2ad4:      	ldp	d9, d8, [sp, #0x30]
    2ad8:      	ldp	d11, d10, [sp, #0x20]
    2adc:      	ldp	d13, d12, [sp, #0x10]
    2ae0:      	ldp	d15, d14, [sp], #0xa0
    2ae4:      	ret

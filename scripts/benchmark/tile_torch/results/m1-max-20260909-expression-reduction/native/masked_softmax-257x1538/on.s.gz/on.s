
/private/tmp/luisa-expression-fusion.qXgTbC/capture/masked_softmax-257x1538/on/object/tile_xir_w8_23396_1788930266059848_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
      2c:      	sub	sp, sp, #0x140
      30:      	add	x21, sp, #0x3, lsl #12  ; =0x3000
      34:      	add	x21, x21, #0x8e0
      38:      	ldr	x22, [x0]
      3c:      	ldr	x19, [x0, #0x30]
      40:      	ldr	w8, [x1]
      44:      	ldr	w9, [x1, #0x24]
      48:      	add	w8, w9, w8, lsl #5
      4c:      	lsr	w8, w8, #3
      50:      	dup.4s	v0, w8
      54:      	str	q0, [sp, #0x280]
      58:      	fmov	s0, w8
      5c:      	ushll.2d	v0, v0, #0x0
      60:      	fmov	x23, d0
      64:      	mov	w24, #0x1808            ; =6152
      68:      	umull	x20, w23, w24
      6c:      	umaddl	x1, w23, w24, x22
      70:      	mov	w25, #0x1800            ; =6144
      74:      	add	x0, sp, #0x6, lsl #12   ; =0x6000
      78:      	add	x0, x0, #0x920
      7c:      	mov	w2, #0x1800             ; =6144
      80:      	bl	0x80 <ltmp0+0x80>
      84:      	mov	x9, #0x0                ; =0
      88:      	umaddl	x8, w23, w24, x25
      8c:      	add	x10, x22, x8
      90:      	add	x11, x10, #0x4
      94:      	ldr	s18, [x10]
      98:      	ld1.s	{ v18 }[1], [x11]
      9c:      	str	q18, [x21, #0x4840]
      a0:      	movi.2d	v0, #0000000000000000
      a4:      	adrp	x10, 0x0 <ltmp0>
      a8:      	ldr	q1, [x10]
      ac:      	adrp	x10, 0x0 <ltmp0>
      b0:      	ldr	q2, [x10]
      b4:      	adrp	x10, 0x0 <ltmp0>
      b8:      	ldr	q3, [x10]
      bc:      	adrp	x10, 0x0 <ltmp0>
      c0:      	ldr	q4, [x10]
      c4:      	mov	w10, #0x1               ; =1
      c8:      	dup.2d	v5, x10
      cc:      	movi.2d	v6, #0000000000000000
      d0:      	movi.2d	v7, #0000000000000000
      d4:      	movi.2d	v16, #0000000000000000
      d8:      	shl.2d	v17, v0, #0x3
      dc:      	shl.2d	v19, v6, #0x3
      e0:      	shl.2d	v20, v7, #0x3
      e4:      	shl.2d	v21, v16, #0x3
      e8:      	orr.16b	v21, v21, v1
      ec:      	orr.16b	v20, v20, v2
      f0:      	orr.16b	v19, v19, v3
      f4:      	orr.16b	v17, v17, v4
      f8:      	add	x9, x21, x9, lsl #6
      fc:      	stp	q17, q19, [x9]
     100:      	stp	q20, q21, [x9, #0x20]
     104:      	add.2d	v7, v7, v5
     108:      	add.2d	v6, v6, v5
     10c:      	add.2d	v16, v16, v5
     110:      	add.2d	v0, v0, v5
     114:      	fmov	x9, d0
     118:      	cmp	x9, #0xc0
     11c:      	b.lt	0xd8 <ltmp0+0xd8>
     120:      	mov	x10, #0x0               ; =0
     124:      	adrp	x9, 0x0 <ltmp0>
     128:      	ldr	q0, [x9]
     12c:      	str	q0, [x21, #0x3000]
     130:      	mov	w9, #0x1da1             ; =7585
     134:      	movk	w9, #0xaa7, lsl #16
     138:      	dup.4s	v1, w9
     13c:      	ldr	q5, [sp, #0x280]
     140:      	umull2.2d	v2, v5, v1
     144:      	umull.2d	v0, v5, v1
     148:      	uzp2.4s	v0, v0, v2
     14c:      	ushr.4s	v3, v0, #0x6
     150:      	mov	w9, #0x602              ; =1538
     154:      	dup.4s	v4, w9
     158:      	mov.16b	v0, v5
     15c:      	mls.4s	v0, v3, v4
     160:      	umull.2d	v1, v5, v1
     164:      	uzp2.4s	v1, v1, v2
     168:      	ushr.4s	v1, v1, #0x6
     16c:      	mls.4s	v5, v1, v4
     170:      	ushll2.2d	v1, v5, #0x0
     174:      	ushll2.2d	v2, v0, #0x0
     178:      	ushll.2d	v3, v5, #0x0
     17c:      	ushll.2d	v4, v0, #0x0
     180:      	movi.2d	v5, #0000000000000000
     184:      	add	x9, sp, #0x3, lsl #12   ; =0x3000
     188:      	add	x9, x9, #0x2d8
     18c:      	dup.2d	v6, x9
     190:      	adrp	x9, 0x0 <ltmp0>
     194:      	ldr	q8, [x9]
     198:      	adrp	x9, 0x0 <ltmp0>
     19c:      	ldr	q9, [x9]
     1a0:      	adrp	x9, 0x0 <ltmp0>
     1a4:      	ldr	q10, [x9]
     1a8:      	mov	w9, #0x1                ; =1
     1ac:      	dup.2d	v7, x9
     1b0:      	adrp	x9, 0x0 <ltmp0>
     1b4:      	ldr	q29, [x9]
     1b8:      	add	x9, sp, #0x3, lsl #12   ; =0x3000
     1bc:      	add	x9, x9, #0x8e0
     1c0:      	movi.8b	v16, #0x1
     1c4:      	movi.2d	v17, #0000000000000000
     1c8:      	movi.2d	v19, #0000000000000000
     1cc:      	movi.2d	v20, #0000000000000000
     1d0:      	add	x10, x9, x10, lsl #6
     1d4:      	ldp	q22, q21, [x10, #0x20]
     1d8:      	ldp	q23, q24, [x10]
     1dc:      	add.2d	v25, v20, v29
     1e0:      	add.2d	v25, v25, v6
     1e4:      	add.2d	v26, v19, v10
     1e8:      	add.2d	v27, v17, v9
     1ec:      	add.2d	v28, v5, v8
     1f0:      	add.2d	v28, v28, v6
     1f4:      	cmge.2d	v24, v2, v24
     1f8:      	cmge.2d	v23, v4, v23
     1fc:      	uzp1.4s	v23, v23, v24
     200:      	cmge.2d	v22, v3, v22
     204:      	cmge.2d	v21, v1, v21
     208:      	uzp1.4s	v21, v22, v21
     20c:      	uzp1.8h	v21, v23, v21
     210:      	xtn.8b	v21, v21
     214:      	and.8b	v21, v21, v16
     218:      	mov.d	x10, v28[1]
     21c:      	fmov	x11, d28
     220:      	str	b21, [x11]
     224:      	st1.b	{ v21 }[1], [x10]
     228:      	add.2d	v22, v27, v6
     22c:      	mov.d	x10, v22[1]
     230:      	fmov	x11, d22
     234:      	st1.b	{ v21 }[2], [x11]
     238:      	add.2d	v22, v26, v6
     23c:      	st1.b	{ v21 }[3], [x10]
     240:      	mov.d	x10, v22[1]
     244:      	fmov	x11, d22
     248:      	st1.b	{ v21 }[4], [x11]
     24c:      	st1.b	{ v21 }[5], [x10]
     250:      	mov.d	x10, v25[1]
     254:      	fmov	x11, d25
     258:      	st1.b	{ v21 }[6], [x11]
     25c:      	st1.b	{ v21 }[7], [x10]
     260:      	add.2d	v19, v19, v7
     264:      	add.2d	v17, v17, v7
     268:      	add.2d	v20, v20, v7
     26c:      	add.2d	v5, v5, v7
     270:      	fmov	x10, d5
     274:      	cmp	x10, #0xc0
     278:      	b.lt	0x1d0 <ltmp0+0x1d0>
     27c:      	adrp	x9, 0x0 <ltmp0>
     280:      	ldr	q1, [x9]
     284:      	add	x9, sp, #0x3, lsl #12   ; =0x3000
     288:      	add	x9, x9, #0x2d8
     28c:      	dup.2d	v20, x9
     290:      	adrp	x9, 0x0 <ltmp0>
     294:      	ldr	q2, [x9]
     298:      	add.2d	v19, v20, v2
     29c:      	cmhs.4s	v0, v0, v1
     2a0:      	xtn.4h	v0, v0
     2a4:      	uzp1.8b	v0, v0, v0
     2a8:      	movi.8b	v1, #0x1
     2ac:      	and.8b	v0, v0, v1
     2b0:      	fmov	x9, d19
     2b4:      	str	b0, [x9]
     2b8:      	mov.d	x9, v19[1]
     2bc:      	st1.b	{ v0 }[1], [x9]
     2c0:      	add.2d	v0, v20, v29
     2c4:      	add.2d	v1, v20, v10
     2c8:      	add.2d	v2, v20, v9
     2cc:      	add.2d	v21, v20, v8
     2d0:      	fmov	x10, d21
     2d4:      	mov.d	x11, v21[1]
     2d8:      	mov.d	x12, v2[1]
     2dc:      	mov.d	x13, v1[1]
     2e0:      	fmov	x14, d2
     2e4:      	fmov	x15, d1
     2e8:      	mov.d	x16, v0[1]
     2ec:      	fmov	x17, d0
     2f0:      	ldr	b0, [x10]
     2f4:      	ld1.b	{ v0 }[1], [x11]
     2f8:      	ld1.b	{ v0 }[2], [x14]
     2fc:      	ld1.b	{ v0 }[3], [x12]
     300:      	ld1.b	{ v0 }[4], [x15]
     304:      	ld1.b	{ v0 }[5], [x13]
     308:      	ld1.b	{ v0 }[6], [x17]
     30c:      	ld1.b	{ v0 }[7], [x16]
     310:      	cmeq.8b	v0, v0, #0
     314:      	sshll.8h	v17, v0, #0x0
     318:      	sshll2.4s	v3, v17, #0x0
     31c:      	sshll.4s	v0, v17, #0x0
     320:      	ldr	q1, [x21, #0x3050]
     324:      	ldr	q2, [x21, #0x3040]
     328:      	mov	w10, #0xf2ca            ; =62154
     32c:      	movk	w10, #0xf149, lsl #16
     330:      	dup.4s	v24, w10
     334:      	mov.16b	v23, v0
     338:      	bsl.16b	v23, v24, v2
     33c:      	str	q3, [sp, #0x220]
     340:      	mov.16b	v22, v3
     344:      	bsl.16b	v22, v24, v1
     348:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
     34c:      	add	x10, x10, #0x9c9
     350:      	stur	q22, [x10, #0xff]
     354:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
     358:      	add	x10, x10, #0x9b9
     35c:      	stur	q23, [x10, #0xff]
     360:      	adrp	x10, 0x0 <ltmp0>
     364:      	ldr	q0, [x10]
     368:      	add.2d	v0, v20, v0
     36c:      	adrp	x10, 0x0 <ltmp0>
     370:      	ldr	q1, [x10]
     374:      	add.2d	v1, v20, v1
     378:      	adrp	x10, 0x0 <ltmp0>
     37c:      	ldr	q2, [x10]
     380:      	add.2d	v2, v20, v2
     384:      	adrp	x10, 0x0 <ltmp0>
     388:      	ldr	q3, [x10]
     38c:      	add.2d	v3, v20, v3
     390:      	mov.d	x10, v3[1]
     394:      	fmov	x11, d3
     398:      	mov.d	x12, v2[1]
     39c:      	fmov	x13, d2
     3a0:      	mov.d	x14, v1[1]
     3a4:      	fmov	x15, d1
     3a8:      	mov.d	x16, v0[1]
     3ac:      	fmov	x17, d0
     3b0:      	ldr	b0, [x11]
     3b4:      	ld1.b	{ v0 }[1], [x10]
     3b8:      	ld1.b	{ v0 }[2], [x13]
     3bc:      	ld1.b	{ v0 }[3], [x12]
     3c0:      	ld1.b	{ v0 }[4], [x15]
     3c4:      	ld1.b	{ v0 }[5], [x14]
     3c8:      	ld1.b	{ v0 }[6], [x17]
     3cc:      	ld1.b	{ v0 }[7], [x16]
     3d0:      	cmeq.8b	v0, v0, #0
     3d4:      	sshll.8h	v0, v0, #0x0
     3d8:      	sshll2.4s	v4, v0, #0x0
     3dc:      	sshll.4s	v1, v0, #0x0
     3e0:      	ldr	q2, [x21, #0x3070]
     3e4:      	ldr	q3, [x21, #0x3060]
     3e8:      	bsl.16b	v1, v24, v3
     3ec:      	str	q4, [sp, #0x230]
     3f0:      	bit.16b	v2, v24, v4
     3f4:      	adrp	x10, 0x0 <ltmp0>
     3f8:      	ldr	q3, [x10]
     3fc:      	str	q3, [sp, #0x1e0]
     400:      	add.2d	v3, v20, v3
     404:      	adrp	x10, 0x0 <ltmp0>
     408:      	ldr	q4, [x10]
     40c:      	str	q4, [sp, #0x1d0]
     410:      	add.2d	v4, v20, v4
     414:      	adrp	x10, 0x0 <ltmp0>
     418:      	ldr	q5, [x10]
     41c:      	str	q5, [sp, #0x1c0]
     420:      	add.2d	v5, v20, v5
     424:      	adrp	x10, 0x0 <ltmp0>
     428:      	ldr	q6, [x10]
     42c:      	add.2d	v6, v20, v6
     430:      	mov.d	x10, v6[1]
     434:      	mov.d	x11, v5[1]
     438:      	fmov	x12, d6
     43c:      	fmov	x13, d5
     440:      	mov.d	x14, v4[1]
     444:      	mov.d	x15, v3[1]
     448:      	fmov	x16, d4
     44c:      	ldr	b4, [x12]
     450:      	ld1.b	{ v4 }[1], [x10]
     454:      	ld1.b	{ v4 }[2], [x13]
     458:      	ld1.b	{ v4 }[3], [x11]
     45c:      	ld1.b	{ v4 }[4], [x16]
     460:      	ld1.b	{ v4 }[5], [x14]
     464:      	fmov	x10, d3
     468:      	ld1.b	{ v4 }[6], [x10]
     46c:      	ld1.b	{ v4 }[7], [x15]
     470:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
     474:      	add	x10, x10, #0x9e9
     478:      	stur	q2, [x10, #0xff]
     47c:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
     480:      	add	x10, x10, #0x9d9
     484:      	stur	q1, [x10, #0xff]
     488:      	cmeq.8b	v3, v4, #0
     48c:      	sshll.8h	v6, v3, #0x0
     490:      	sshll2.4s	v4, v6, #0x0
     494:      	sshll.4s	v3, v6, #0x0
     498:      	ldr	q5, [x21, #0x3090]
     49c:      	ldr	q25, [x21, #0x3080]
     4a0:      	bsl.16b	v3, v24, v25
     4a4:      	str	q4, [sp, #0x250]
     4a8:      	mov.16b	v25, v4
     4ac:      	bsl.16b	v25, v24, v5
     4b0:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
     4b4:      	add	x10, x10, #0xa09
     4b8:      	stur	q25, [x10, #0xff]
     4bc:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
     4c0:      	add	x10, x10, #0x9f9
     4c4:      	stur	q3, [x10, #0xff]
     4c8:      	adrp	x10, 0x0 <ltmp0>
     4cc:      	ldr	q5, [x10]
     4d0:      	str	q5, [sp, #0x1b0]
     4d4:      	add.2d	v5, v20, v5
     4d8:      	adrp	x10, 0x0 <ltmp0>
     4dc:      	ldr	q26, [x10]
     4e0:      	str	q26, [sp, #0x1a0]
     4e4:      	add.2d	v26, v20, v26
     4e8:      	adrp	x10, 0x0 <ltmp0>
     4ec:      	ldr	q28, [x10]
     4f0:      	adrp	x10, 0x0 <ltmp0>
     4f4:      	ldr	q27, [x10]
     4f8:      	add.2d	v27, v20, v27
     4fc:      	mov.d	x10, v27[1]
     500:      	str	q28, [sp, #0x190]
     504:      	add.2d	v28, v20, v28
     508:      	fmov	x11, d27
     50c:      	mov.d	x12, v28[1]
     510:      	mov.d	x13, v26[1]
     514:      	fmov	x14, d28
     518:      	fmov	x15, d26
     51c:      	mov.d	x16, v5[1]
     520:      	fmov	x17, d5
     524:      	ldr	b5, [x11]
     528:      	ld1.b	{ v5 }[1], [x10]
     52c:      	ld1.b	{ v5 }[2], [x14]
     530:      	ld1.b	{ v5 }[3], [x12]
     534:      	ld1.b	{ v5 }[4], [x15]
     538:      	ld1.b	{ v5 }[5], [x13]
     53c:      	ld1.b	{ v5 }[6], [x17]
     540:      	ld1.b	{ v5 }[7], [x16]
     544:      	cmeq.8b	v5, v5, #0
     548:      	sshll.8h	v5, v5, #0x0
     54c:      	sshll2.4s	v4, v5, #0x0
     550:      	str	q5, [sp, #0x260]
     554:      	sshll.4s	v26, v5, #0x0
     558:      	ldr	q27, [x21, #0x30b0]
     55c:      	ldr	q28, [x21, #0x30a0]
     560:      	bsl.16b	v26, v24, v28
     564:      	str	q4, [sp, #0x280]
     568:      	bit.16b	v27, v24, v4
     56c:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
     570:      	add	x10, x10, #0xa29
     574:      	stur	q27, [x10, #0xff]
     578:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
     57c:      	add	x10, x10, #0xa19
     580:      	stur	q26, [x10, #0xff]
     584:      	mov	w10, #0x4               ; =4
     588:      	add	x11, sp, #0x6, lsl #12  ; =0x6000
     58c:      	add	x11, x11, #0x920
     590:      	add	x12, sp, #0x1, lsl #12  ; =0x1000
     594:      	add	x12, x12, #0xab8
     598:      	mov	w13, #0x1               ; =1
     59c:      	mov	w14, #0x2               ; =2
     5a0:      	mov	w15, #0x3               ; =3
     5a4:      	dup.2d	v28, x10
     5a8:      	mov	w16, #0x4               ; =4
     5ac:      	mov.16b	v12, v29
     5b0:      	mov.16b	v29, v28
     5b4:      	mov.16b	v30, v28
     5b8:      	mov.16b	v31, v28
     5bc:      	mov.16b	v15, v8
     5c0:      	mov.16b	v4, v9
     5c4:      	mov.16b	v7, v10
     5c8:      	str	q12, [sp, #0x270]
     5cc:      	str	q8, [sp, #0x240]
     5d0:      	add.2d	v10, v29, v20
     5d4:      	add.2d	v9, v30, v20
     5d8:      	add.2d	v8, v31, v20
     5dc:      	add.2d	v11, v8, v12
     5e0:      	add.2d	v12, v9, v7
     5e4:      	add.2d	v13, v10, v4
     5e8:      	add.2d	v14, v28, v15
     5ec:      	add.2d	v14, v14, v20
     5f0:      	mov.d	x0, v14[1]
     5f4:      	fmov	x1, d14
     5f8:      	mov.d	x2, v13[1]
     5fc:      	fmov	x3, d13
     600:      	mov.d	x4, v12[1]
     604:      	fmov	x5, d12
     608:      	mov.d	x17, v11[1]
     60c:      	ldr	b12, [x1]
     610:      	ld1.b	{ v12 }[1], [x0]
     614:      	ld1.b	{ v12 }[2], [x3]
     618:      	ld1.b	{ v12 }[3], [x2]
     61c:      	fmov	x0, d11
     620:      	ld1.b	{ v12 }[4], [x5]
     624:      	lsl	x16, x16, #5
     628:      	ld1.b	{ v12 }[5], [x4]
     62c:      	add	x1, x11, x16
     630:      	dup.2d	v11, x13
     634:      	orr.16b	v11, v28, v11
     638:      	ld1.b	{ v12 }[6], [x0]
     63c:      	mvn.16b	v13, v20
     640:      	add.2d	v14, v11, v21
     644:      	mov.d	x0, v14[1]
     648:      	ld1.b	{ v12 }[7], [x17]
     64c:      	sub.2d	v15, v29, v13
     650:      	fmov	x17, d14
     654:      	sub.2d	v14, v30, v13
     658:      	sub.2d	v13, v31, v13
     65c:      	mov.16b	v16, v7
     660:      	mov.16b	v7, v4
     664:      	ldr	q4, [sp, #0x270]
     668:      	add.2d	v13, v13, v4
     66c:      	mov.16b	v4, v7
     670:      	mov.16b	v7, v16
     674:      	cmeq.8b	v12, v12, #0
     678:      	add.2d	v14, v14, v16
     67c:      	add.2d	v15, v15, v4
     680:      	mov.d	x2, v15[1]
     684:      	fmov	x3, d15
     688:      	sshll.8h	v15, v12, #0x0
     68c:      	mov.d	x4, v14[1]
     690:      	fmov	x5, d14
     694:      	mov.d	x6, v13[1]
     698:      	sshll.4s	v14, v15, #0x0
     69c:      	ldr	b12, [x17]
     6a0:      	fmov	x17, d13
     6a4:      	ldr	q13, [x1]
     6a8:      	ld1.b	{ v12 }[1], [x0]
     6ac:      	bit.16b	v13, v24, v14
     6b0:      	ldr	q14, [x1, #0x10]
     6b4:      	ld1.b	{ v12 }[2], [x3]
     6b8:      	ld1.b	{ v12 }[3], [x2]
     6bc:      	sshll2.4s	v15, v15, #0x0
     6c0:      	add	x16, x12, x16
     6c4:      	ld1.b	{ v12 }[4], [x5]
     6c8:      	ld1.b	{ v12 }[5], [x4]
     6cc:      	bit.16b	v14, v24, v15
     6d0:      	ld1.b	{ v12 }[6], [x17]
     6d4:      	ld1.b	{ v12 }[7], [x6]
     6d8:      	stp	q13, q14, [x16]
     6dc:      	fmov	x16, d11
     6e0:      	lsl	x16, x16, #5
     6e4:      	add	x17, x11, x16
     6e8:      	dup.2d	v11, x14
     6ec:      	fmaxnm.4s	v22, v22, v14
     6f0:      	orr.16b	v11, v28, v11
     6f4:      	ldr	q14, [sp, #0x1e0]
     6f8:      	add.2d	v14, v8, v14
     6fc:      	add.2d	v15, v11, v21
     700:      	mov.d	x0, v15[1]
     704:      	fmaxnm.4s	v23, v23, v13
     708:      	ldr	q13, [sp, #0x1d0]
     70c:      	add.2d	v13, v9, v13
     710:      	fmov	x1, d15
     714:      	ldr	q15, [sp, #0x1c0]
     718:      	add.2d	v15, v10, v15
     71c:      	mov.d	x2, v15[1]
     720:      	cmeq.8b	v12, v12, #0
     724:      	fmov	x3, d15
     728:      	mov.d	x4, v13[1]
     72c:      	mov.d	x5, v14[1]
     730:      	sshll.8h	v12, v12, #0x0
     734:      	fmov	x6, d13
     738:      	ldr	b13, [x1]
     73c:      	fmov	x1, d14
     740:      	ld1.b	{ v13 }[1], [x0]
     744:      	sshll.4s	v14, v12, #0x0
     748:      	ldp	q5, q15, [x17]
     74c:      	ld1.b	{ v13 }[2], [x3]
     750:      	ld1.b	{ v13 }[3], [x2]
     754:      	bsl.16b	v14, v24, v5
     758:      	ld1.b	{ v13 }[4], [x6]
     75c:      	ld1.b	{ v13 }[5], [x4]
     760:      	sshll2.4s	v12, v12, #0x0
     764:      	ld1.b	{ v13 }[6], [x1]
     768:      	ld1.b	{ v13 }[7], [x5]
     76c:      	cmeq.8b	v13, v13, #0
     770:      	bsl.16b	v12, v24, v15
     774:      	sshll.8h	v13, v13, #0x0
     778:      	fmov	x17, d11
     77c:      	lsl	x17, x17, #5
     780:      	add	x0, x11, x17
     784:      	ldr	q11, [x0]
     788:      	sshll.4s	v15, v13, #0x0
     78c:      	bit.16b	v11, v24, v15
     790:      	ldr	q15, [sp, #0x240]
     794:      	add	x16, x12, x16
     798:      	fmaxnm.4s	v2, v2, v12
     79c:      	stp	q14, q12, [x16]
     7a0:      	fmaxnm.4s	v1, v1, v14
     7a4:      	ldr	q12, [x0, #0x10]
     7a8:      	sshll2.4s	v13, v13, #0x0
     7ac:      	bit.16b	v12, v24, v13
     7b0:      	add	x16, x12, x17
     7b4:      	str	q12, [x16, #0x10]
     7b8:      	fmaxnm.4s	v25, v25, v12
     7bc:      	dup.2d	v12, x15
     7c0:      	orr.16b	v12, v28, v12
     7c4:      	add.2d	v13, v12, v21
     7c8:      	mov.d	x17, v13[1]
     7cc:      	fmov	x0, d13
     7d0:      	ldr	q13, [sp, #0x190]
     7d4:      	add.2d	v10, v10, v13
     7d8:      	mov.d	x1, v10[1]
     7dc:      	fmov	x2, d10
     7e0:      	ldr	q10, [sp, #0x1a0]
     7e4:      	add.2d	v9, v9, v10
     7e8:      	mov.d	x3, v9[1]
     7ec:      	fmov	x4, d9
     7f0:      	ldr	q9, [sp, #0x1b0]
     7f4:      	add.2d	v8, v8, v9
     7f8:      	mov.d	x5, v8[1]
     7fc:      	fmov	x6, d8
     800:      	ldr	b8, [x0]
     804:      	ld1.b	{ v8 }[1], [x17]
     808:      	ld1.b	{ v8 }[2], [x2]
     80c:      	ld1.b	{ v8 }[3], [x1]
     810:      	ld1.b	{ v8 }[4], [x4]
     814:      	ld1.b	{ v8 }[5], [x3]
     818:      	ld1.b	{ v8 }[6], [x6]
     81c:      	ld1.b	{ v8 }[7], [x5]
     820:      	cmeq.8b	v8, v8, #0
     824:      	str	q11, [x16]
     828:      	sshll.8h	v8, v8, #0x0
     82c:      	fmov	x16, d12
     830:      	ldr	q12, [sp, #0x270]
     834:      	sshll.4s	v9, v8, #0x0
     838:      	lsl	x16, x16, #5
     83c:      	add	x17, x11, x16
     840:      	fmaxnm.4s	v3, v3, v11
     844:      	ldp	q5, q10, [x17]
     848:      	bsl.16b	v9, v24, v5
     84c:      	sshll2.4s	v8, v8, #0x0
     850:      	bsl.16b	v8, v24, v10
     854:      	add	x16, x12, x16
     858:      	fmaxnm.4s	v27, v27, v8
     85c:      	stp	q9, q8, [x16]
     860:      	fmaxnm.4s	v26, v26, v9
     864:      	dup.2d	v8, x10
     868:      	add.2d	v30, v30, v8
     86c:      	add.2d	v29, v29, v8
     870:      	add.2d	v31, v31, v8
     874:      	add.2d	v28, v28, v8
     878:      	fmov	x16, d28
     87c:      	cmp	x16, #0xc0
     880:      	b.lt	0x5d0 <ltmp0+0x5d0>
     884:      	fmov	x10, d19
     888:      	ldr	b19, [x10]
     88c:      	ld1.b	{ v19 }[1], [x9]
     890:      	cmeq.8b	v19, v19, #0
     894:      	sshll.8h	v16, v19, #0x0
     898:      	sshll.4s	v19, v16, #0x0
     89c:      	movi.2d	v20, #0000000000000000
     8a0:      	mov.d	v20[0], v18[0]
     8a4:      	mov	w9, #0xf2ca             ; =62154
     8a8:      	movk	w9, #0xf149, lsl #16
     8ac:      	dup.4s	v18, w9
     8b0:      	mov.16b	v5, v19
     8b4:      	bsl.16b	v5, v18, v20
     8b8:      	add	x9, sp, #0x3, lsl #12   ; =0x3000
     8bc:      	add	x9, x9, #0x1b9
     8c0:      	ldur	q18, [x9, #0xff]
     8c4:      	fmaxnm.4s	v19, v23, v5
     8c8:      	mov.d	v5[1], v18[1]
     8cc:      	stp	q16, q5, [sp, #0x10]
     8d0:      	mov.d	v19[1], v23[1]
     8d4:      	fmaxnm.4s	v1, v19, v1
     8d8:      	fmaxnm.4s	v2, v22, v2
     8dc:      	fmaxnm.4s	v1, v1, v3
     8e0:      	fmaxnm.4s	v2, v2, v25
     8e4:      	fmaxnm.4s	v1, v1, v26
     8e8:      	fmaxnm.4s	v2, v2, v27
     8ec:      	rev64.4s	v3, v1
     8f0:      	rev64.4s	v18, v2
     8f4:      	fmaxnm.4s	v1, v1, v3
     8f8:      	fmaxnm.4s	v2, v2, v18
     8fc:      	ext.16b	v3, v1, v1, #0x8
     900:      	ext.16b	v18, v2, v2, #0x8
     904:      	fmaxnm.4s	v1, v1, v3
     908:      	fmaxnm.4s	v2, v2, v18
     90c:      	fmaxnm.4s	v1, v1, v2
     910:      	mov	w9, #-0x800000          ; =-8388608
     914:      	fmov	s2, w9
     918:      	fmaxnm	s1, s1, s2
     91c:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     920:      	add	x9, x9, #0x9b9
     924:      	ldur	q2, [x9, #0xff]
     928:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     92c:      	add	x9, x9, #0x9c9
     930:      	ldur	q3, [x9, #0xff]
     934:      	dup.4s	v27, v1[0]
     938:      	fsub.4s	v1, v3, v27
     93c:      	fsub.4s	v2, v2, v27
     940:      	mov	w9, #-0x3d300000        ; =-1026555904
     944:      	dup.4s	v22, w9
     948:      	fcmge.4s	v3, v2, v22
     94c:      	fcmge.4s	v18, v1, v22
     950:      	mov	w9, #0x42c80000         ; =1120403456
     954:      	dup.4s	v14, w9
     958:      	fcmge.4s	v19, v14, v2
     95c:      	fcmge.4s	v20, v14, v1
     960:      	and.16b	v18, v18, v20
     964:      	and.16b	v3, v3, v19
     968:      	and.16b	v19, v3, v2
     96c:      	and.16b	v20, v18, v1
     970:      	mov	w9, #0xaa3b             ; =43579
     974:      	movk	w9, #0x3fb8, lsl #16
     978:      	dup.4s	v29, w9
     97c:      	fmul.4s	v3, v20, v29
     980:      	fmul.4s	v18, v19, v29
     984:      	movi.4s	v5, #0x4b, lsl #24
     988:      	mvni.4s	v16, #0x80, lsl #24
     98c:      	mov.16b	v23, v16
     990:      	bsl.16b	v23, v5, v18
     994:      	mov.16b	v24, v16
     998:      	bsl.16b	v24, v5, v3
     99c:      	fadd.4s	v3, v3, v24
     9a0:      	fadd.4s	v18, v18, v23
     9a4:      	fsub.4s	v23, v18, v23
     9a8:      	fsub.4s	v3, v3, v24
     9ac:      	fcvtzs.4s	v18, v3
     9b0:      	fcvtzs.4s	v3, v23
     9b4:      	scvtf.4s	v23, v3
     9b8:      	scvtf.4s	v24, v18
     9bc:      	mov	w9, #0x7200             ; =29184
     9c0:      	movk	w9, #0x3f31, lsl #16
     9c4:      	dup.4s	v8, w9
     9c8:      	fmul.4s	v25, v24, v8
     9cc:      	fmul.4s	v26, v23, v8
     9d0:      	fsub.4s	v19, v19, v26
     9d4:      	fsub.4s	v20, v20, v25
     9d8:      	mov	w9, #0xbe8e             ; =48782
     9dc:      	movk	w9, #0x35bf, lsl #16
     9e0:      	dup.4s	v9, w9
     9e4:      	fmul.4s	v23, v23, v9
     9e8:      	fmul.4s	v24, v24, v9
     9ec:      	fsub.4s	v20, v20, v24
     9f0:      	fsub.4s	v19, v19, v23
     9f4:      	mov	w9, #0x2bda             ; =11226
     9f8:      	movk	w9, #0x3950, lsl #16
     9fc:      	dup.4s	v10, w9
     a00:      	fmul.4s	v23, v19, v10
     a04:      	mov	w9, #0x96c9             ; =38601
     a08:      	movk	w9, #0x3ab6, lsl #16
     a0c:      	dup.4s	v11, w9
     a10:      	fadd.4s	v23, v23, v11
     a14:      	fmul.4s	v23, v19, v23
     a18:      	mov	w9, #0x88a6             ; =34982
     a1c:      	movk	w9, #0x3c08, lsl #16
     a20:      	dup.4s	v13, w9
     a24:      	fadd.4s	v23, v23, v13
     a28:      	fmul.4s	v23, v19, v23
     a2c:      	mov	w9, #0xaa7a             ; =43642
     a30:      	movk	w9, #0x3d2a, lsl #16
     a34:      	dup.4s	v30, w9
     a38:      	fadd.4s	v23, v23, v30
     a3c:      	mov	w9, #0xaaab             ; =43691
     a40:      	movk	w9, #0x3e2a, lsl #16
     a44:      	dup.4s	v28, w9
     a48:      	fmul.4s	v23, v19, v23
     a4c:      	fadd.4s	v23, v23, v28
     a50:      	fmul.4s	v23, v19, v23
     a54:      	movi.4s	v31, #0x3f, lsl #24
     a58:      	fadd.4s	v23, v23, v31
     a5c:      	fmul.4s	v24, v19, v19
     a60:      	fmul.4s	v23, v24, v23
     a64:      	fmul.4s	v24, v20, v10
     a68:      	fadd.4s	v24, v24, v11
     a6c:      	fmul.4s	v24, v20, v24
     a70:      	fadd.4s	v24, v24, v13
     a74:      	fmul.4s	v24, v20, v24
     a78:      	fadd.4s	v24, v24, v30
     a7c:      	fmul.4s	v24, v20, v24
     a80:      	fadd.4s	v24, v24, v28
     a84:      	fmul.4s	v24, v20, v24
     a88:      	fadd.4s	v24, v24, v31
     a8c:      	fmul.4s	v25, v20, v20
     a90:      	fmul.4s	v24, v25, v24
     a94:      	fadd.4s	v20, v20, v24
     a98:      	fadd.4s	v19, v19, v23
     a9c:      	fmov.4s	v26, #1.00000000
     aa0:      	fadd.4s	v20, v20, v26
     aa4:      	sshr.4s	v23, v18, #0x1
     aa8:      	shl.4s	v24, v23, #0x17
     aac:      	add.4s	v24, v24, v26
     ab0:      	fmul.4s	v20, v20, v24
     ab4:      	fadd.4s	v19, v19, v26
     ab8:      	sshr.4s	v24, v3, #0x1
     abc:      	shl.4s	v25, v24, #0x17
     ac0:      	add.4s	v25, v25, v26
     ac4:      	fmul.4s	v19, v19, v25
     ac8:      	sub.4s	v18, v18, v23
     acc:      	sshll.4s	v17, v17, #0x0
     ad0:      	sub.4s	v3, v3, v24
     ad4:      	shl.4s	v3, v3, #0x17
     ad8:      	shl.4s	v18, v18, #0x17
     adc:      	add.4s	v18, v18, v26
     ae0:      	add.4s	v3, v3, v26
     ae4:      	fmul.4s	v3, v19, v3
     ae8:      	fmul.4s	v18, v20, v18
     aec:      	fcmgt.4s	v19, v22, v1
     af0:      	bic.16b	v18, v18, v19
     af4:      	fcmgt.4s	v19, v22, v2
     af8:      	bic.16b	v3, v3, v19
     afc:      	fcmgt.4s	v19, v1, v14
     b00:      	fcmgt.4s	v20, v2, v14
     b04:      	mvni.4s	v23, #0x7f, msl #16
     b08:      	fneg.4s	v5, v23
     b0c:      	bit.16b	v3, v5, v20
     b10:      	bit.16b	v18, v5, v19
     b14:      	fcmeq.4s	v2, v2, v2
     b18:      	fcmeq.4s	v1, v1, v1
     b1c:      	mvni.4s	v19, #0x3f, msl #16
     b20:      	fneg.4s	v21, v19
     b24:      	bsl.16b	v1, v18, v21
     b28:      	bsl.16b	v2, v3, v21
     b2c:      	bic.16b	v3, v2, v17
     b30:      	ldr	q2, [sp, #0x220]
     b34:      	bic.16b	v1, v1, v2
     b38:      	stp	q3, q1, [sp, #0x1f0]
     b3c:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     b40:      	add	x9, x9, #0x9d9
     b44:      	ldur	q2, [x9, #0xff]
     b48:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     b4c:      	add	x9, x9, #0x9e9
     b50:      	ldur	q1, [x9, #0xff]
     b54:      	fsub.4s	v1, v1, v27
     b58:      	fsub.4s	v2, v2, v27
     b5c:      	fcmge.4s	v3, v2, v22
     b60:      	fcmge.4s	v16, v1, v22
     b64:      	fcmge.4s	v17, v14, v1
     b68:      	and.16b	v16, v16, v17
     b6c:      	fcmge.4s	v17, v14, v2
     b70:      	and.16b	v3, v3, v17
     b74:      	and.16b	v17, v3, v2
     b78:      	fmul.4s	v3, v17, v29
     b7c:      	mvni.4s	v19, #0x80, lsl #24
     b80:      	movi.4s	v20, #0x4b, lsl #24
     b84:      	mov.16b	v18, v19
     b88:      	bsl.16b	v18, v20, v3
     b8c:      	fadd.4s	v3, v3, v18
     b90:      	fsub.4s	v3, v3, v18
     b94:      	and.16b	v16, v16, v1
     b98:      	fmul.4s	v18, v16, v29
     b9c:      	bsl.16b	v19, v20, v18
     ba0:      	movi.4s	v25, #0x4b, lsl #24
     ba4:      	mvni.4s	v24, #0x80, lsl #24
     ba8:      	fadd.4s	v18, v18, v19
     bac:      	fsub.4s	v18, v18, v19
     bb0:      	fcvtzs.4s	v3, v3
     bb4:      	scvtf.4s	v19, v3
     bb8:      	fmul.4s	v20, v19, v8
     bbc:      	fsub.4s	v17, v17, v20
     bc0:      	fcvtzs.4s	v18, v18
     bc4:      	scvtf.4s	v20, v18
     bc8:      	fmul.4s	v23, v20, v8
     bcc:      	fsub.4s	v16, v16, v23
     bd0:      	fmul.4s	v20, v20, v9
     bd4:      	fsub.4s	v16, v16, v20
     bd8:      	fmul.4s	v19, v19, v9
     bdc:      	fsub.4s	v17, v17, v19
     be0:      	fmul.4s	v19, v17, v10
     be4:      	fadd.4s	v19, v19, v11
     be8:      	fmul.4s	v19, v17, v19
     bec:      	fadd.4s	v19, v19, v13
     bf0:      	fmul.4s	v19, v17, v19
     bf4:      	fadd.4s	v19, v19, v30
     bf8:      	fmul.4s	v19, v17, v19
     bfc:      	fadd.4s	v19, v19, v28
     c00:      	fmul.4s	v19, v17, v19
     c04:      	fadd.4s	v19, v19, v31
     c08:      	fmul.4s	v20, v17, v17
     c0c:      	fmul.4s	v19, v20, v19
     c10:      	fmul.4s	v20, v16, v10
     c14:      	fadd.4s	v20, v20, v11
     c18:      	fmul.4s	v20, v16, v20
     c1c:      	fadd.4s	v20, v20, v13
     c20:      	fmul.4s	v20, v16, v20
     c24:      	fadd.4s	v20, v20, v30
     c28:      	fmul.4s	v20, v16, v20
     c2c:      	fadd.4s	v20, v20, v28
     c30:      	fmul.4s	v20, v16, v20
     c34:      	fadd.4s	v20, v20, v31
     c38:      	fmul.4s	v23, v16, v16
     c3c:      	fmul.4s	v20, v23, v20
     c40:      	fadd.4s	v16, v16, v20
     c44:      	fadd.4s	v17, v17, v19
     c48:      	fadd.4s	v16, v16, v26
     c4c:      	sshr.4s	v19, v18, #0x1
     c50:      	shl.4s	v20, v19, #0x17
     c54:      	add.4s	v20, v20, v26
     c58:      	fmul.4s	v16, v16, v20
     c5c:      	fadd.4s	v17, v17, v26
     c60:      	sshr.4s	v20, v3, #0x1
     c64:      	shl.4s	v23, v20, #0x17
     c68:      	add.4s	v23, v23, v26
     c6c:      	fmul.4s	v17, v17, v23
     c70:      	sub.4s	v18, v18, v19
     c74:      	sub.4s	v3, v3, v20
     c78:      	shl.4s	v3, v3, #0x17
     c7c:      	add.4s	v3, v3, v26
     c80:      	fmul.4s	v3, v17, v3
     c84:      	sshll.4s	v0, v0, #0x0
     c88:      	shl.4s	v17, v18, #0x17
     c8c:      	add.4s	v17, v17, v26
     c90:      	fmul.4s	v16, v16, v17
     c94:      	fcmgt.4s	v17, v22, v1
     c98:      	bic.16b	v16, v16, v17
     c9c:      	fcmgt.4s	v17, v22, v2
     ca0:      	bic.16b	v3, v3, v17
     ca4:      	fcmgt.4s	v17, v2, v14
     ca8:      	bit.16b	v3, v5, v17
     cac:      	fcmgt.4s	v17, v1, v14
     cb0:      	bit.16b	v16, v5, v17
     cb4:      	fcmeq.4s	v2, v2, v2
     cb8:      	fcmeq.4s	v1, v1, v1
     cbc:      	bsl.16b	v1, v16, v21
     cc0:      	bsl.16b	v2, v3, v21
     cc4:      	bic.16b	v20, v2, v0
     cc8:      	ldr	q0, [sp, #0x230]
     ccc:      	bic.16b	v23, v1, v0
     cd0:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     cd4:      	add	x9, x9, #0x9f9
     cd8:      	ldur	q1, [x9, #0xff]
     cdc:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     ce0:      	add	x9, x9, #0xa09
     ce4:      	ldur	q0, [x9, #0xff]
     ce8:      	fsub.4s	v0, v0, v27
     cec:      	fsub.4s	v1, v1, v27
     cf0:      	fcmge.4s	v2, v1, v22
     cf4:      	fcmge.4s	v3, v0, v22
     cf8:      	str	q7, [sp, #0x40]
     cfc:      	fcmge.4s	v7, v14, v0
     d00:      	and.16b	v3, v3, v7
     d04:      	fcmge.4s	v7, v14, v1
     d08:      	and.16b	v2, v2, v7
     d0c:      	and.16b	v7, v2, v1
     d10:      	fmul.4s	v2, v7, v29
     d14:      	mov.16b	v16, v24
     d18:      	bsl.16b	v16, v25, v2
     d1c:      	fadd.4s	v2, v2, v16
     d20:      	fsub.4s	v2, v2, v16
     d24:      	and.16b	v3, v3, v0
     d28:      	fmul.4s	v16, v3, v29
     d2c:      	mov.16b	v17, v24
     d30:      	bsl.16b	v17, v25, v16
     d34:      	fadd.4s	v16, v16, v17
     d38:      	fsub.4s	v16, v16, v17
     d3c:      	fcvtzs.4s	v2, v2
     d40:      	scvtf.4s	v17, v2
     d44:      	fmul.4s	v18, v17, v8
     d48:      	fsub.4s	v7, v7, v18
     d4c:      	fcvtzs.4s	v16, v16
     d50:      	scvtf.4s	v18, v16
     d54:      	fmul.4s	v19, v18, v8
     d58:      	fsub.4s	v3, v3, v19
     d5c:      	fmul.4s	v18, v18, v9
     d60:      	fsub.4s	v3, v3, v18
     d64:      	fmul.4s	v17, v17, v9
     d68:      	fsub.4s	v7, v7, v17
     d6c:      	fmul.4s	v17, v7, v10
     d70:      	fadd.4s	v17, v17, v11
     d74:      	fmul.4s	v17, v7, v17
     d78:      	fadd.4s	v17, v17, v13
     d7c:      	fmul.4s	v17, v7, v17
     d80:      	fadd.4s	v17, v17, v30
     d84:      	fmul.4s	v17, v7, v17
     d88:      	fadd.4s	v17, v17, v28
     d8c:      	fmul.4s	v17, v7, v17
     d90:      	fadd.4s	v17, v17, v31
     d94:      	fmul.4s	v18, v7, v7
     d98:      	fmul.4s	v17, v18, v17
     d9c:      	fmul.4s	v18, v3, v10
     da0:      	fadd.4s	v18, v18, v11
     da4:      	fmul.4s	v18, v3, v18
     da8:      	fadd.4s	v18, v18, v13
     dac:      	fmul.4s	v18, v3, v18
     db0:      	fadd.4s	v18, v18, v30
     db4:      	fmul.4s	v18, v3, v18
     db8:      	fadd.4s	v18, v18, v28
     dbc:      	fmul.4s	v18, v3, v18
     dc0:      	fadd.4s	v18, v18, v31
     dc4:      	fmul.4s	v19, v3, v3
     dc8:      	fmul.4s	v18, v19, v18
     dcc:      	fadd.4s	v3, v3, v18
     dd0:      	fadd.4s	v7, v7, v17
     dd4:      	fadd.4s	v3, v3, v26
     dd8:      	sshr.4s	v17, v16, #0x1
     ddc:      	shl.4s	v18, v17, #0x17
     de0:      	add.4s	v18, v18, v26
     de4:      	fmul.4s	v3, v3, v18
     de8:      	fadd.4s	v7, v7, v26
     dec:      	sshr.4s	v18, v2, #0x1
     df0:      	shl.4s	v19, v18, #0x17
     df4:      	add.4s	v19, v19, v26
     df8:      	fmul.4s	v7, v7, v19
     dfc:      	sub.4s	v16, v16, v17
     e00:      	sub.4s	v2, v2, v18
     e04:      	shl.4s	v2, v2, #0x17
     e08:      	add.4s	v2, v2, v26
     e0c:      	fmul.4s	v2, v7, v2
     e10:      	sshll.4s	v6, v6, #0x0
     e14:      	shl.4s	v7, v16, #0x17
     e18:      	add.4s	v7, v7, v26
     e1c:      	fmul.4s	v3, v3, v7
     e20:      	fcmgt.4s	v7, v22, v0
     e24:      	bic.16b	v3, v3, v7
     e28:      	fcmgt.4s	v7, v22, v1
     e2c:      	bic.16b	v2, v2, v7
     e30:      	fcmgt.4s	v7, v1, v14
     e34:      	bit.16b	v2, v5, v7
     e38:      	fcmgt.4s	v7, v0, v14
     e3c:      	bit.16b	v3, v5, v7
     e40:      	fcmeq.4s	v1, v1, v1
     e44:      	fcmeq.4s	v0, v0, v0
     e48:      	bsl.16b	v0, v3, v21
     e4c:      	bsl.16b	v1, v2, v21
     e50:      	bic.16b	v7, v1, v6
     e54:      	ldr	q1, [sp, #0x250]
     e58:      	bic.16b	v18, v0, v1
     e5c:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     e60:      	add	x9, x9, #0xa19
     e64:      	ldur	q1, [x9, #0xff]
     e68:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     e6c:      	add	x9, x9, #0xa29
     e70:      	ldur	q0, [x9, #0xff]
     e74:      	fsub.4s	v0, v0, v27
     e78:      	stp	q29, q27, [sp, #0xf0]
     e7c:      	fsub.4s	v1, v1, v27
     e80:      	fcmge.4s	v2, v1, v22
     e84:      	fcmge.4s	v3, v0, v22
     e88:      	str	q4, [sp, #0x30]
     e8c:      	fcmge.4s	v4, v14, v0
     e90:      	and.16b	v3, v3, v4
     e94:      	fcmge.4s	v4, v14, v1
     e98:      	and.16b	v2, v2, v4
     e9c:      	and.16b	v4, v2, v1
     ea0:      	fmul.4s	v2, v4, v29
     ea4:      	mov.16b	v6, v24
     ea8:      	bsl.16b	v6, v25, v2
     eac:      	fadd.4s	v2, v2, v6
     eb0:      	fsub.4s	v2, v2, v6
     eb4:      	and.16b	v3, v3, v0
     eb8:      	fmul.4s	v6, v3, v29
     ebc:      	mov.16b	v29, v23
     ec0:      	mov.16b	v23, v7
     ec4:      	mov.16b	v7, v24
     ec8:      	bsl.16b	v7, v25, v6
     ecc:      	fadd.4s	v6, v6, v7
     ed0:      	fsub.4s	v6, v6, v7
     ed4:      	fcvtzs.4s	v2, v2
     ed8:      	scvtf.4s	v7, v2
     edc:      	fmul.4s	v16, v7, v8
     ee0:      	fsub.4s	v4, v4, v16
     ee4:      	fcvtzs.4s	v6, v6
     ee8:      	scvtf.4s	v16, v6
     eec:      	stp	q9, q8, [sp, #0xd0]
     ef0:      	fmul.4s	v17, v16, v8
     ef4:      	fsub.4s	v3, v3, v17
     ef8:      	fmul.4s	v16, v16, v9
     efc:      	fsub.4s	v3, v3, v16
     f00:      	fmul.4s	v7, v7, v9
     f04:      	fsub.4s	v4, v4, v7
     f08:      	fmul.4s	v7, v4, v10
     f0c:      	fadd.4s	v7, v7, v11
     f10:      	fmul.4s	v7, v4, v7
     f14:      	fadd.4s	v7, v7, v13
     f18:      	fmul.4s	v7, v4, v7
     f1c:      	fadd.4s	v7, v7, v30
     f20:      	fmul.4s	v7, v4, v7
     f24:      	fadd.4s	v7, v7, v28
     f28:      	fmul.4s	v7, v4, v7
     f2c:      	fadd.4s	v7, v7, v31
     f30:      	fmul.4s	v16, v4, v4
     f34:      	fmul.4s	v7, v16, v7
     f38:      	str	q10, [sp, #0x180]
     f3c:      	fmul.4s	v16, v3, v10
     f40:      	stp	q13, q11, [sp, #0xb0]
     f44:      	fadd.4s	v16, v16, v11
     f48:      	fmul.4s	v16, v3, v16
     f4c:      	fadd.4s	v16, v16, v13
     f50:      	fmul.4s	v16, v3, v16
     f54:      	str	q30, [sp, #0xa0]
     f58:      	fadd.4s	v16, v16, v30
     f5c:      	fmul.4s	v16, v3, v16
     f60:      	str	q28, [sp, #0x70]
     f64:      	fadd.4s	v16, v16, v28
     f68:      	mov.16b	v28, v18
     f6c:      	fmul.4s	v16, v3, v16
     f70:      	fadd.4s	v16, v16, v31
     f74:      	fmul.4s	v17, v3, v3
     f78:      	fmul.4s	v16, v17, v16
     f7c:      	fadd.4s	v3, v3, v16
     f80:      	fadd.4s	v4, v4, v7
     f84:      	fadd.4s	v3, v3, v26
     f88:      	sshr.4s	v7, v6, #0x1
     f8c:      	shl.4s	v16, v7, #0x17
     f90:      	add.4s	v16, v16, v26
     f94:      	fmul.4s	v3, v3, v16
     f98:      	fadd.4s	v4, v4, v26
     f9c:      	sshr.4s	v16, v2, #0x1
     fa0:      	shl.4s	v17, v16, #0x17
     fa4:      	add.4s	v17, v17, v26
     fa8:      	fmul.4s	v4, v4, v17
     fac:      	sub.4s	v6, v6, v7
     fb0:      	sub.4s	v2, v2, v16
     fb4:      	shl.4s	v2, v2, #0x17
     fb8:      	add.4s	v2, v2, v26
     fbc:      	fmul.4s	v2, v4, v2
     fc0:      	shl.4s	v4, v6, #0x17
     fc4:      	add.4s	v4, v4, v26
     fc8:      	fmul.4s	v3, v3, v4
     fcc:      	fcmgt.4s	v4, v22, v0
     fd0:      	bic.16b	v3, v3, v4
     fd4:      	stp	q14, q22, [sp, #0x80]
     fd8:      	fcmgt.4s	v4, v22, v1
     fdc:      	bic.16b	v2, v2, v4
     fe0:      	fcmgt.4s	v4, v1, v14
     fe4:      	bit.16b	v2, v5, v4
     fe8:      	fcmgt.4s	v4, v0, v14
     fec:      	str	q5, [sp, #0x60]
     ff0:      	bit.16b	v3, v5, v4
     ff4:      	mov.16b	v5, v20
     ff8:      	ldr	q4, [sp, #0x260]
     ffc:      	sshll.4s	v4, v4, #0x0
    1000:      	ldr	q6, [sp, #0x20]
    1004:      	add	x9, sp, #0x3, lsl #12   ; =0x3000
    1008:      	add	x9, x9, #0x1b9
    100c:      	stur	q6, [x9, #0xff]
    1010:      	ldp	q6, q7, [sp, #0x1f0]
    1014:      	add	x9, sp, #0x1a9
    1018:      	stur	q7, [x9, #0xff]
    101c:      	add	x9, sp, #0x199
    1020:      	stur	q6, [x9, #0xff]
    1024:      	add	x9, sp, #0x1c9
    1028:      	stur	q29, [x9, #0xff]
    102c:      	add	x9, sp, #0x1b9
    1030:      	stur	q20, [x9, #0xff]
    1034:      	add	x9, sp, #0x1e9
    1038:      	stur	q18, [x9, #0xff]
    103c:      	add	x9, sp, #0x1d9
    1040:      	stur	q23, [x9, #0xff]
    1044:      	fcmeq.4s	v1, v1, v1
    1048:      	fcmeq.4s	v0, v0, v0
    104c:      	bsl.16b	v0, v3, v21
    1050:      	str	q21, [sp, #0x50]
    1054:      	bsl.16b	v1, v2, v21
    1058:      	bic.16b	v18, v1, v4
    105c:      	ldr	q1, [sp, #0x280]
    1060:      	bic.16b	v19, v0, v1
    1064:      	add	x9, sp, #0x209
    1068:      	stur	q19, [x9, #0xff]
    106c:      	add	x9, sp, #0x1f9
    1070:      	stur	q18, [x9, #0xff]
    1074:      	mov	w9, #0x4                ; =4
    1078:      	add	x10, sp, #0x3, lsl #12  ; =0x3000
    107c:      	add	x10, x10, #0x2d8
    1080:      	add	x11, sp, #0x1, lsl #12  ; =0x1000
    1084:      	add	x11, x11, #0xab8
    1088:      	add	x12, sp, #0x298
    108c:      	mov	w13, #0x1               ; =1
    1090:      	mov	w14, #0x2               ; =2
    1094:      	mov	w15, #0x3               ; =3
    1098:      	dup.2d	v7, x9
    109c:      	mov	w16, #0x4               ; =4
    10a0:      	mov.16b	v0, v7
    10a4:      	mov.16b	v2, v7
    10a8:      	mov.16b	v3, v7
    10ac:      	ldr	q10, [sp, #0x100]
    10b0:      	ldp	q22, q21, [sp, #0x90]
    10b4:      	ldp	q14, q13, [sp, #0xd0]
    10b8:      	ldr	q17, [sp, #0xb0]
    10bc:      	ldp	q11, q16, [sp, #0x60]
    10c0:      	stp	q3, q2, [sp, #0x250]
    10c4:      	str	q0, [sp, #0x230]
    10c8:      	str	q7, [sp, #0x280]
    10cc:      	stp	q19, q18, [sp, #0x120]
    10d0:      	stp	q28, q23, [sp, #0x140]
    10d4:      	stp	q29, q5, [sp, #0x160]
    10d8:      	dup.2d	v24, x10
    10dc:      	add.2d	v2, v0, v24
    10e0:      	str	q2, [sp, #0x110]
    10e4:      	ldp	q0, q1, [sp, #0x250]
    10e8:      	add.2d	v3, v1, v24
    10ec:      	add.2d	v0, v0, v24
    10f0:      	stp	q3, q0, [sp, #0x210]
    10f4:      	add.2d	v4, v0, v12
    10f8:      	ldp	q0, q1, [sp, #0x30]
    10fc:      	add.2d	v19, v3, v1
    1100:      	add.2d	v20, v2, v0
    1104:      	add.2d	v18, v7, v15
    1108:      	add.2d	v18, v18, v24
    110c:      	lsl	x7, x16, #5
    1110:      	mov.d	x16, v18[1]
    1114:      	add	x17, x11, x7
    1118:      	ldp	q23, q25, [x17]
    111c:      	fsub.4s	v30, v25, v10
    1120:      	mov.d	x17, v20[1]
    1124:      	fmov	x0, d18
    1128:      	fsub.4s	v31, v23, v10
    112c:      	ldr	b18, [x0]
    1130:      	fcmge.4s	v23, v31, v22
    1134:      	ld1.b	{ v18 }[1], [x16]
    1138:      	fmov	x16, d20
    113c:      	fcmge.4s	v20, v30, v22
    1140:      	mov.d	x0, v19[1]
    1144:      	ld1.b	{ v18 }[2], [x16]
    1148:      	ldr	q7, [sp, #0x80]
    114c:      	fcmge.4s	v25, v7, v31
    1150:      	fcmge.4s	v12, v7, v30
    1154:      	fmov	x16, d19
    1158:      	and.16b	v19, v20, v12
    115c:      	ld1.b	{ v18 }[3], [x17]
    1160:      	and.16b	v20, v23, v25
    1164:      	mov.d	x21, v4[1]
    1168:      	and.16b	v20, v20, v31
    116c:      	ld1.b	{ v18 }[4], [x16]
    1170:      	fmov	x16, d4
    1174:      	and.16b	v4, v19, v30
    1178:      	ldr	q5, [sp, #0xf0]
    117c:      	fmul.4s	v19, v4, v5
    1180:      	fmul.4s	v23, v20, v5
    1184:      	ld1.b	{ v18 }[5], [x0]
    1188:      	movi.4s	v2, #0x4b, lsl #24
    118c:      	mvni.4s	v3, #0x80, lsl #24
    1190:      	mov.16b	v25, v3
    1194:      	bsl.16b	v25, v2, v23
    1198:      	mov.16b	v12, v3
    119c:      	bsl.16b	v12, v2, v19
    11a0:      	fadd.4s	v19, v19, v12
    11a4:      	fadd.4s	v23, v23, v25
    11a8:      	ld1.b	{ v18 }[6], [x16]
    11ac:      	fsub.4s	v23, v23, v25
    11b0:      	fsub.4s	v19, v19, v12
    11b4:      	fcvtzs.4s	v12, v19
    11b8:      	fcvtzs.4s	v23, v23
    11bc:      	scvtf.4s	v19, v23
    11c0:      	scvtf.4s	v25, v12
    11c4:      	fmul.4s	v15, v25, v13
    11c8:      	fmul.4s	v27, v19, v13
    11cc:      	fsub.4s	v20, v20, v27
    11d0:      	fmul.4s	v19, v19, v14
    11d4:      	fmul.4s	v25, v25, v14
    11d8:      	fsub.4s	v4, v4, v15
    11dc:      	fsub.4s	v4, v4, v25
    11e0:      	fsub.4s	v19, v20, v19
    11e4:      	ldr	q2, [sp, #0x180]
    11e8:      	fmul.4s	v20, v19, v2
    11ec:      	fmul.4s	v25, v4, v2
    11f0:      	ldr	q3, [sp, #0xc0]
    11f4:      	fadd.4s	v25, v25, v3
    11f8:      	fadd.4s	v20, v20, v3
    11fc:      	fmul.4s	v20, v19, v20
    1200:      	fmul.4s	v25, v4, v25
    1204:      	fadd.4s	v25, v25, v17
    1208:      	fadd.4s	v20, v20, v17
    120c:      	fmul.4s	v20, v19, v20
    1210:      	fmul.4s	v25, v4, v25
    1214:      	fadd.4s	v25, v25, v21
    1218:      	fadd.4s	v20, v20, v21
    121c:      	fmul.4s	v20, v19, v20
    1220:      	fmul.4s	v25, v4, v25
    1224:      	fadd.4s	v25, v25, v16
    1228:      	fadd.4s	v20, v20, v16
    122c:      	fmul.4s	v20, v19, v20
    1230:      	fmul.4s	v25, v4, v25
    1234:      	movi.4s	v6, #0x3f, lsl #24
    1238:      	fadd.4s	v25, v25, v6
    123c:      	fmul.4s	v27, v4, v4
    1240:      	fmul.4s	v15, v19, v19
    1244:      	fadd.4s	v20, v20, v6
    1248:      	fmul.4s	v20, v15, v20
    124c:      	sshr.4s	v15, v23, #0x1
    1250:      	sshr.4s	v28, v12, #0x1
    1254:      	shl.4s	v29, v28, #0x17
    1258:      	shl.4s	v8, v15, #0x17
    125c:      	fmul.4s	v27, v27, v25
    1260:      	add.4s	v25, v8, v26
    1264:      	add.4s	v29, v29, v26
    1268:      	sub.4s	v28, v12, v28
    126c:      	sub.4s	v23, v23, v15
    1270:      	shl.4s	v23, v23, #0x17
    1274:      	fadd.4s	v27, v4, v27
    1278:      	shl.4s	v4, v28, #0x17
    127c:      	add.4s	v4, v4, v26
    1280:      	fcmgt.4s	v15, v22, v30
    1284:      	dup.2d	v28, x13
    1288:      	fadd.4s	v8, v19, v20
    128c:      	fcmgt.4s	v19, v22, v31
    1290:      	ldr	q20, [sp, #0x280]
    1294:      	orr.16b	v20, v20, v28
    1298:      	mvn.16b	v28, v24
    129c:      	ldp	q6, q9, [sp, #0x230]
    12a0:      	add.2d	v24, v24, v9
    12a4:      	add.2d	v12, v20, v24
    12a8:      	add.4s	v23, v23, v26
    12ac:      	mov.d	x0, v12[1]
    12b0:      	fmov	x1, d12
    12b4:      	sub.2d	v12, v6, v28
    12b8:      	add.2d	v12, v12, v0
    12bc:      	fadd.4s	v8, v8, v26
    12c0:      	mov.d	x3, v12[1]
    12c4:      	fmov	x5, d12
    12c8:      	ldp	q0, q6, [sp, #0x250]
    12cc:      	sub.2d	v12, v6, v28
    12d0:      	sub.2d	v28, v0, v28
    12d4:      	fadd.4s	v27, v27, v26
    12d8:      	ldr	q9, [sp, #0x270]
    12dc:      	add.2d	v28, v28, v9
    12e0:      	ldp	q0, q6, [sp, #0x1f0]
    12e4:      	add.2d	v12, v12, v1
    12e8:      	mov.d	x4, v12[1]
    12ec:      	fmov	x6, d12
    12f0:      	fmul.4s	v27, v27, v29
    12f4:      	mov.d	x17, v28[1]
    12f8:      	fmov	x2, d28
    12fc:      	fmov	x16, d20
    1300:      	lsl	x16, x16, #5
    1304:      	fmul.4s	v20, v8, v25
    1308:      	add	x22, x11, x16
    130c:      	ldp	q28, q25, [x22]
    1310:      	fsub.4s	v25, v25, v10
    1314:      	fsub.4s	v12, v28, v10
    1318:      	fmul.4s	v20, v20, v23
    131c:      	fcmge.4s	v23, v12, v22
    1320:      	fcmge.4s	v28, v25, v22
    1324:      	fcmge.4s	v29, v7, v12
    1328:      	fcmge.4s	v8, v7, v25
    132c:      	and.16b	v28, v28, v8
    1330:      	fmul.4s	v4, v27, v4
    1334:      	and.16b	v23, v23, v29
    1338:      	and.16b	v23, v23, v12
    133c:      	and.16b	v27, v28, v25
    1340:      	fmul.4s	v28, v27, v5
    1344:      	fmul.4s	v29, v23, v5
    1348:      	bic.16b	v8, v4, v15
    134c:      	mvni.4s	v1, #0x80, lsl #24
    1350:      	movi.4s	v9, #0x4b, lsl #24
    1354:      	mov.16b	v4, v1
    1358:      	bsl.16b	v4, v9, v29
    135c:      	mov.16b	v15, v1
    1360:      	bsl.16b	v15, v9, v28
    1364:      	fadd.4s	v28, v28, v15
    1368:      	fadd.4s	v29, v29, v4
    136c:      	fsub.4s	v4, v29, v4
    1370:      	bic.16b	v20, v20, v19
    1374:      	fsub.4s	v19, v28, v15
    1378:      	fcvtzs.4s	v19, v19
    137c:      	fcvtzs.4s	v4, v4
    1380:      	scvtf.4s	v28, v4
    1384:      	scvtf.4s	v29, v19
    1388:      	fmul.4s	v15, v28, v13
    138c:      	fsub.4s	v23, v23, v15
    1390:      	fmul.4s	v15, v29, v13
    1394:      	fsub.4s	v27, v27, v15
    1398:      	fcmgt.4s	v15, v30, v7
    139c:      	ld1.b	{ v18 }[7], [x21]
    13a0:      	fmul.4s	v29, v29, v14
    13a4:      	fsub.4s	v27, v27, v29
    13a8:      	fcmgt.4s	v29, v31, v7
    13ac:      	fmul.4s	v28, v28, v14
    13b0:      	fsub.4s	v23, v23, v28
    13b4:      	bit.16b	v20, v11, v29
    13b8:      	fmul.4s	v28, v23, v2
    13bc:      	fmul.4s	v29, v27, v2
    13c0:      	fadd.4s	v29, v29, v3
    13c4:      	fadd.4s	v28, v28, v3
    13c8:      	fmul.4s	v28, v23, v28
    13cc:      	fmul.4s	v29, v27, v29
    13d0:      	fadd.4s	v29, v29, v17
    13d4:      	fadd.4s	v28, v28, v17
    13d8:      	fmul.4s	v28, v23, v28
    13dc:      	fmul.4s	v29, v27, v29
    13e0:      	fadd.4s	v29, v29, v21
    13e4:      	fadd.4s	v28, v28, v21
    13e8:      	fmul.4s	v28, v23, v28
    13ec:      	fmul.4s	v29, v27, v29
    13f0:      	fadd.4s	v29, v29, v16
    13f4:      	fadd.4s	v28, v28, v16
    13f8:      	fmul.4s	v28, v23, v28
    13fc:      	bit.16b	v8, v11, v15
    1400:      	fmul.4s	v29, v27, v29
    1404:      	movi.4s	v1, #0x3f, lsl #24
    1408:      	fadd.4s	v28, v28, v1
    140c:      	fmul.4s	v15, v23, v23
    1410:      	fmul.4s	v28, v15, v28
    1414:      	fmul.4s	v15, v27, v27
    1418:      	fadd.4s	v29, v29, v1
    141c:      	fmul.4s	v29, v15, v29
    1420:      	cmeq.8b	v18, v18, #0
    1424:      	sshll.8h	v18, v18, #0x0
    1428:      	fadd.4s	v27, v27, v29
    142c:      	sshll2.4s	v29, v18, #0x0
    1430:      	sshll.4s	v15, v18, #0x0
    1434:      	fcmeq.4s	v31, v31, v31
    1438:      	fcmeq.4s	v30, v30, v30
    143c:      	add	x30, x12, x7
    1440:      	fadd.4s	v18, v23, v28
    1444:      	fadd.4s	v18, v18, v26
    1448:      	ldr	q9, [sp, #0x50]
    144c:      	mov.16b	v23, v30
    1450:      	bsl.16b	v23, v8, v9
    1454:      	sshr.4s	v28, v4, #0x1
    1458:      	sshr.4s	v30, v19, #0x1
    145c:      	sub.4s	v19, v19, v30
    1460:      	shl.4s	v30, v30, #0x17
    1464:      	sub.4s	v4, v4, v28
    1468:      	fadd.4s	v27, v27, v26
    146c:      	shl.4s	v28, v28, #0x17
    1470:      	add.4s	v28, v28, v26
    1474:      	add.4s	v30, v30, v26
    1478:      	shl.4s	v4, v4, #0x17
    147c:      	shl.4s	v19, v19, #0x17
    1480:      	bif.16b	v20, v9, v31
    1484:      	add.4s	v31, v19, v26
    1488:      	add.4s	v4, v4, v26
    148c:      	dup.2d	v19, x14
    1490:      	ldr	q1, [sp, #0x280]
    1494:      	orr.16b	v8, v1, v19
    1498:      	bic.16b	v15, v20, v15
    149c:      	add.2d	v19, v8, v24
    14a0:      	mov.d	x21, v19[1]
    14a4:      	fmov	x22, d19
    14a8:      	fcmgt.4s	v19, v22, v25
    14ac:      	bic.16b	v23, v23, v29
    14b0:      	ldr	q20, [sp, #0x1c0]
    14b4:      	ldr	q1, [sp, #0x110]
    14b8:      	add.2d	v20, v1, v20
    14bc:      	mov.d	x23, v20[1]
    14c0:      	fmov	x24, d20
    14c4:      	ldr	q20, [sp, #0x1e0]
    14c8:      	ldr	q29, [sp, #0x220]
    14cc:      	add.2d	v29, v29, v20
    14d0:      	fmul.4s	v20, v27, v30
    14d4:      	ldr	q27, [sp, #0x1d0]
    14d8:      	ldr	q30, [sp, #0x210]
    14dc:      	add.2d	v27, v30, v27
    14e0:      	mov.d	x25, v27[1]
    14e4:      	mov.d	x26, v29[1]
    14e8:      	fmul.4s	v28, v18, v28
    14ec:      	fmov	x28, d27
    14f0:      	fmov	x27, d29
    14f4:      	fmov	x7, d8
    14f8:      	lsl	x7, x7, #5
    14fc:      	stp	q15, q23, [x30]
    1500:      	add	x30, x11, x7
    1504:      	ldp	q27, q18, [x30]
    1508:      	fsub.4s	v18, v18, v10
    150c:      	fsub.4s	v30, v27, v10
    1510:      	fadd.4s	v6, v6, v23
    1514:      	fcmge.4s	v23, v30, v22
    1518:      	fcmge.4s	v27, v18, v22
    151c:      	fcmge.4s	v29, v7, v18
    1520:      	and.16b	v27, v27, v29
    1524:      	fcmge.4s	v29, v7, v30
    1528:      	fadd.4s	v0, v0, v15
    152c:      	stp	q0, q6, [sp, #0x1f0]
    1530:      	and.16b	v23, v23, v29
    1534:      	and.16b	v23, v23, v30
    1538:      	and.16b	v27, v27, v18
    153c:      	fmul.4s	v29, v27, v5
    1540:      	fmul.4s	v8, v23, v5
    1544:      	fmul.4s	v4, v28, v4
    1548:      	movi.4s	v0, #0x4b, lsl #24
    154c:      	mvni.4s	v6, #0x80, lsl #24
    1550:      	mov.16b	v28, v6
    1554:      	bsl.16b	v28, v0, v8
    1558:      	fadd.4s	v8, v8, v28
    155c:      	fsub.4s	v28, v8, v28
    1560:      	mov.16b	v8, v6
    1564:      	bsl.16b	v8, v0, v29
    1568:      	fadd.4s	v29, v29, v8
    156c:      	fmul.4s	v20, v20, v31
    1570:      	fsub.4s	v29, v29, v8
    1574:      	fcvtzs.4s	v29, v29
    1578:      	fcvtzs.4s	v28, v28
    157c:      	scvtf.4s	v31, v28
    1580:      	scvtf.4s	v8, v29
    1584:      	bic.16b	v19, v20, v19
    1588:      	fmul.4s	v20, v31, v13
    158c:      	fsub.4s	v20, v23, v20
    1590:      	fmul.4s	v23, v8, v13
    1594:      	fsub.4s	v23, v27, v23
    1598:      	fcmgt.4s	v27, v22, v12
    159c:      	fmul.4s	v31, v31, v14
    15a0:      	fmul.4s	v8, v8, v14
    15a4:      	fsub.4s	v23, v23, v8
    15a8:      	fsub.4s	v20, v20, v31
    15ac:      	fmul.4s	v31, v20, v2
    15b0:      	fmul.4s	v8, v23, v2
    15b4:      	mov.16b	v6, v3
    15b8:      	fadd.4s	v8, v8, v3
    15bc:      	fadd.4s	v31, v31, v3
    15c0:      	fmul.4s	v31, v20, v31
    15c4:      	fmul.4s	v8, v23, v8
    15c8:      	fadd.4s	v8, v8, v17
    15cc:      	fadd.4s	v31, v31, v17
    15d0:      	fmul.4s	v31, v20, v31
    15d4:      	fmul.4s	v8, v23, v8
    15d8:      	fadd.4s	v8, v8, v21
    15dc:      	fadd.4s	v31, v31, v21
    15e0:      	fmul.4s	v31, v20, v31
    15e4:      	fmul.4s	v8, v23, v8
    15e8:      	fadd.4s	v8, v8, v16
    15ec:      	fadd.4s	v31, v31, v16
    15f0:      	fmul.4s	v31, v20, v31
    15f4:      	fmul.4s	v8, v23, v8
    15f8:      	movi.4s	v0, #0x3f, lsl #24
    15fc:      	fadd.4s	v8, v8, v0
    1600:      	fadd.4s	v31, v31, v0
    1604:      	bic.16b	v4, v4, v27
    1608:      	fmul.4s	v27, v20, v20
    160c:      	fmul.4s	v27, v27, v31
    1610:      	fmul.4s	v31, v23, v23
    1614:      	fmul.4s	v8, v31, v8
    1618:      	fcmgt.4s	v31, v12, v7
    161c:      	bsl.16b	v31, v11, v4
    1620:      	fcmgt.4s	v4, v25, v7
    1624:      	fadd.4s	v23, v23, v8
    1628:      	fadd.4s	v20, v20, v27
    162c:      	fadd.4s	v23, v23, v26
    1630:      	sshr.4s	v27, v28, #0x1
    1634:      	mov.16b	v15, v4
    1638:      	bsl.16b	v15, v11, v19
    163c:      	sshr.4s	v4, v29, #0x1
    1640:      	shl.4s	v19, v4, #0x17
    1644:      	add.4s	v19, v19, v26
    1648:      	fmul.4s	v23, v23, v19
    164c:      	shl.4s	v19, v27, #0x17
    1650:      	fadd.4s	v20, v20, v26
    1654:      	add.4s	v19, v19, v26
    1658:      	fmul.4s	v19, v20, v19
    165c:      	sub.4s	v20, v29, v4
    1660:      	sub.4s	v4, v28, v27
    1664:      	shl.4s	v4, v4, #0x17
    1668:      	add.4s	v4, v4, v26
    166c:      	fmul.4s	v27, v19, v4
    1670:      	ldr	b28, [x1]
    1674:      	ld1.b	{ v28 }[1], [x0]
    1678:      	ld1.b	{ v28 }[2], [x5]
    167c:      	ld1.b	{ v28 }[3], [x3]
    1680:      	fcmeq.4s	v4, v12, v12
    1684:      	ldp	q12, q0, [sp, #0x270]
    1688:      	fcmeq.4s	v19, v25, v25
    168c:      	ld1.b	{ v28 }[4], [x6]
    1690:      	shl.4s	v20, v20, #0x17
    1694:      	add.4s	v20, v20, v26
    1698:      	fmul.4s	v20, v23, v20
    169c:      	fcmgt.4s	v23, v22, v18
    16a0:      	ld1.b	{ v28 }[5], [x4]
    16a4:      	bic.16b	v23, v20, v23
    16a8:      	fcmgt.4s	v20, v22, v30
    16ac:      	bic.16b	v20, v27, v20
    16b0:      	fcmgt.4s	v25, v30, v7
    16b4:      	ld1.b	{ v28 }[6], [x2]
    16b8:      	bsl.16b	v25, v11, v20
    16bc:      	dup.2d	v20, x15
    16c0:      	orr.16b	v27, v0, v20
    16c4:      	ldp	q2, q0, [sp, #0x220]
    16c8:      	ld1.b	{ v28 }[7], [x17]
    16cc:      	add.2d	v20, v27, v24
    16d0:      	mov.d	x1, v20[1]
    16d4:      	fmov	x2, d20
    16d8:      	fcmgt.4s	v24, v18, v7
    16dc:      	cmeq.8b	v28, v28, #0
    16e0:      	fcmeq.4s	v20, v30, v30
    16e4:      	fcmeq.4s	v18, v18, v18
    16e8:      	ldp	q3, q29, [sp, #0x1a0]
    16ec:      	add.2d	v29, v2, v29
    16f0:      	ldr	q2, [sp, #0x210]
    16f4:      	add.2d	v2, v2, v3
    16f8:      	ldr	q3, [sp, #0x190]
    16fc:      	add.2d	v1, v1, v3
    1700:      	sshll.8h	v3, v28, #0x0
    1704:      	mov.d	x3, v1[1]
    1708:      	fmov	x4, d1
    170c:      	mov.d	x0, v2[1]
    1710:      	bit.16b	v23, v11, v24
    1714:      	fmov	x5, d2
    1718:      	mov.d	x17, v29[1]
    171c:      	fmov	x6, d27
    1720:      	lsl	x6, x6, #5
    1724:      	mov.16b	v24, v19
    1728:      	bsl.16b	v24, v15, v9
    172c:      	ldr	q15, [sp, #0x240]
    1730:      	add	x30, x11, x6
    1734:      	ldp	q2, q1, [x30]
    1738:      	fmov	x30, d29
    173c:      	fsub.4s	v2, v2, v10
    1740:      	mov.16b	v27, v4
    1744:      	bsl.16b	v27, v31, v9
    1748:      	fsub.4s	v1, v1, v10
    174c:      	fcmge.4s	v4, v1, v22
    1750:      	fcmge.4s	v28, v2, v22
    1754:      	fcmge.4s	v29, v7, v1
    1758:      	fcmge.4s	v30, v7, v2
    175c:      	mov.16b	v19, v18
    1760:      	bsl.16b	v19, v23, v9
    1764:      	and.16b	v18, v28, v30
    1768:      	and.16b	v4, v4, v29
    176c:      	and.16b	v23, v4, v1
    1770:      	and.16b	v28, v18, v2
    1774:      	fmul.4s	v4, v28, v5
    1778:      	bif.16b	v25, v9, v20
    177c:      	fmul.4s	v18, v23, v5
    1780:      	ldr	q5, [sp, #0x170]
    1784:      	mvni.4s	v29, #0x80, lsl #24
    1788:      	movi.4s	v30, #0x4b, lsl #24
    178c:      	mov.16b	v20, v29
    1790:      	bsl.16b	v20, v30, v18
    1794:      	bsl.16b	v29, v30, v4
    1798:      	fadd.4s	v4, v4, v29
    179c:      	fadd.4s	v18, v18, v20
    17a0:      	sshll.4s	v30, v3, #0x0
    17a4:      	fsub.4s	v18, v18, v20
    17a8:      	fsub.4s	v4, v4, v29
    17ac:      	fcvtzs.4s	v4, v4
    17b0:      	fcvtzs.4s	v18, v18
    17b4:      	scvtf.4s	v29, v18
    17b8:      	bic.16b	v20, v27, v30
    17bc:      	scvtf.4s	v27, v4
    17c0:      	fmul.4s	v30, v29, v13
    17c4:      	fsub.4s	v23, v23, v30
    17c8:      	fmul.4s	v30, v27, v13
    17cc:      	fsub.4s	v28, v28, v30
    17d0:      	fmul.4s	v27, v27, v14
    17d4:      	fsub.4s	v27, v28, v27
    17d8:      	ldr	b28, [x22]
    17dc:      	ld1.b	{ v28 }[1], [x21]
    17e0:      	ld1.b	{ v28 }[2], [x24]
    17e4:      	ld1.b	{ v28 }[3], [x23]
    17e8:      	ld1.b	{ v28 }[4], [x28]
    17ec:      	ld1.b	{ v28 }[5], [x25]
    17f0:      	ld1.b	{ v28 }[6], [x27]
    17f4:      	ld1.b	{ v28 }[7], [x26]
    17f8:      	cmeq.8b	v28, v28, #0
    17fc:      	sshll2.4s	v3, v3, #0x0
    1800:      	sshll.8h	v28, v28, #0x0
    1804:      	fmul.4s	v29, v29, v14
    1808:      	fsub.4s	v23, v23, v29
    180c:      	ldr	q30, [sp, #0x180]
    1810:      	fmul.4s	v29, v23, v30
    1814:      	fadd.4s	v29, v29, v6
    1818:      	fmul.4s	v29, v23, v29
    181c:      	fadd.4s	v29, v29, v17
    1820:      	fmul.4s	v29, v23, v29
    1824:      	fadd.4s	v29, v29, v21
    1828:      	fmul.4s	v29, v23, v29
    182c:      	fadd.4s	v29, v29, v16
    1830:      	bic.16b	v3, v24, v3
    1834:      	fmul.4s	v24, v23, v29
    1838:      	movi.4s	v31, #0x3f, lsl #24
    183c:      	fadd.4s	v24, v24, v31
    1840:      	fmul.4s	v29, v23, v23
    1844:      	fmul.4s	v24, v29, v24
    1848:      	sshll.4s	v29, v28, #0x0
    184c:      	bic.16b	v25, v25, v29
    1850:      	fmul.4s	v29, v27, v30
    1854:      	fadd.4s	v29, v29, v6
    1858:      	fmul.4s	v29, v27, v29
    185c:      	fadd.4s	v29, v29, v17
    1860:      	fmul.4s	v29, v27, v29
    1864:      	sshll2.4s	v28, v28, #0x0
    1868:      	fadd.4s	v29, v29, v21
    186c:      	fmul.4s	v29, v27, v29
    1870:      	fadd.4s	v29, v29, v16
    1874:      	fmul.4s	v29, v27, v29
    1878:      	fadd.4s	v29, v29, v31
    187c:      	bic.16b	v19, v19, v28
    1880:      	fmul.4s	v28, v27, v27
    1884:      	fmul.4s	v28, v28, v29
    1888:      	ldr	q29, [sp, #0x160]
    188c:      	add	x16, x12, x16
    1890:      	fadd.4s	v29, v29, v3
    1894:      	stp	q20, q3, [x16]
    1898:      	fadd.4s	v3, v27, v28
    189c:      	fadd.4s	v23, v23, v24
    18a0:      	fadd.4s	v3, v3, v26
    18a4:      	sshr.4s	v24, v18, #0x1
    18a8:      	sshr.4s	v27, v4, #0x1
    18ac:      	fadd.4s	v5, v5, v20
    18b0:      	shl.4s	v20, v27, #0x17
    18b4:      	add.4s	v20, v20, v26
    18b8:      	fmul.4s	v3, v3, v20
    18bc:      	shl.4s	v20, v24, #0x17
    18c0:      	add.4s	v20, v20, v26
    18c4:      	fadd.4s	v23, v23, v26
    18c8:      	fmul.4s	v20, v23, v20
    18cc:      	ldp	q28, q23, [sp, #0x140]
    18d0:      	add	x16, x12, x7
    18d4:      	fadd.4s	v28, v28, v19
    18d8:      	stp	q25, q19, [x16]
    18dc:      	fadd.4s	v23, v23, v25
    18e0:      	sub.4s	v4, v4, v27
    18e4:      	sub.4s	v18, v18, v24
    18e8:      	shl.4s	v18, v18, #0x17
    18ec:      	add.4s	v18, v18, v26
    18f0:      	fmul.4s	v18, v20, v18
    18f4:      	ldr	b19, [x2]
    18f8:      	ld1.b	{ v19 }[1], [x1]
    18fc:      	ld1.b	{ v19 }[2], [x4]
    1900:      	ld1.b	{ v19 }[3], [x3]
    1904:      	ld1.b	{ v19 }[4], [x5]
    1908:      	shl.4s	v4, v4, #0x17
    190c:      	add.4s	v4, v4, v26
    1910:      	fmul.4s	v3, v3, v4
    1914:      	fcmgt.4s	v4, v22, v2
    1918:      	bic.16b	v3, v3, v4
    191c:      	fcmgt.4s	v4, v22, v1
    1920:      	bic.16b	v4, v18, v4
    1924:      	fcmgt.4s	v18, v1, v7
    1928:      	bit.16b	v4, v11, v18
    192c:      	fcmgt.4s	v18, v2, v7
    1930:      	ldr	q7, [sp, #0x280]
    1934:      	bit.16b	v3, v11, v18
    1938:      	ld1.b	{ v19 }[5], [x0]
    193c:      	ld1.b	{ v19 }[6], [x30]
    1940:      	fcmeq.4s	v2, v2, v2
    1944:      	bsl.16b	v2, v3, v9
    1948:      	ld1.b	{ v19 }[7], [x17]
    194c:      	cmeq.8b	v3, v19, #0
    1950:      	ldp	q19, q18, [sp, #0x120]
    1954:      	fcmeq.4s	v1, v1, v1
    1958:      	sshll.8h	v3, v3, #0x0
    195c:      	bsl.16b	v1, v4, v9
    1960:      	sshll2.4s	v4, v3, #0x0
    1964:      	bic.16b	v1, v1, v4
    1968:      	sshll.4s	v3, v3, #0x0
    196c:      	bic.16b	v2, v2, v3
    1970:      	add	x16, x12, x6
    1974:      	fadd.4s	v19, v19, v1
    1978:      	stp	q2, q1, [x16]
    197c:      	fadd.4s	v18, v18, v2
    1980:      	ldp	q3, q2, [sp, #0x250]
    1984:      	dup.2d	v1, x9
    1988:      	add.2d	v2, v2, v1
    198c:      	add.2d	v0, v0, v1
    1990:      	add.2d	v3, v3, v1
    1994:      	add.2d	v7, v7, v1
    1998:      	fmov	x16, d7
    199c:      	cmp	x16, #0xc0
    19a0:      	b.lt	0x10c0 <ltmp0+0x10c0>
    19a4:      	mov	x9, #0x0                ; =0
    19a8:      	ldr	q0, [sp, #0x20]
    19ac:      	ldr	q1, [sp, #0x100]
    19b0:      	fsub.4s	v1, v0, v1
    19b4:      	movi.2d	v0, #0000000000000000
    19b8:      	mov.d	v0[0], v1[0]
    19bc:      	mov	w10, #-0x3d300000       ; =-1026555904
    19c0:      	dup.4s	v2, w10
    19c4:      	ldr	q1, [sp, #0x10]
    19c8:      	sshll.4s	v1, v1, #0x0
    19cc:      	fcmge.4s	v3, v0, v2
    19d0:      	mov	w10, #0x42c80000        ; =1120403456
    19d4:      	dup.4s	v4, w10
    19d8:      	fcmge.4s	v7, v4, v0
    19dc:      	and.16b	v3, v3, v7
    19e0:      	and.16b	v3, v3, v0
    19e4:      	mov	w10, #0xaa3b            ; =43579
    19e8:      	movk	w10, #0x3fb8, lsl #16
    19ec:      	dup.4s	v7, w10
    19f0:      	fmul.4s	v7, v3, v7
    19f4:      	movi.4s	v16, #0x4b, lsl #24
    19f8:      	mvni.4s	v17, #0x80, lsl #24
    19fc:      	bif.16b	v16, v7, v17
    1a00:      	fadd.4s	v7, v7, v16
    1a04:      	fsub.4s	v7, v7, v16
    1a08:      	fcvtzs.4s	v7, v7
    1a0c:      	scvtf.4s	v16, v7
    1a10:      	mov	w10, #0x7200            ; =29184
    1a14:      	movk	w10, #0xbf31, lsl #16
    1a18:      	dup.4s	v17, w10
    1a1c:      	fmul.4s	v17, v16, v17
    1a20:      	fadd.4s	v3, v3, v17
    1a24:      	mov	w10, #0xbe8e            ; =48782
    1a28:      	movk	w10, #0xb5bf, lsl #16
    1a2c:      	dup.4s	v17, w10
    1a30:      	fmul.4s	v16, v16, v17
    1a34:      	fadd.4s	v3, v3, v16
    1a38:      	mov	w10, #0x2bda            ; =11226
    1a3c:      	movk	w10, #0x3950, lsl #16
    1a40:      	dup.4s	v16, w10
    1a44:      	fmul.4s	v16, v3, v16
    1a48:      	mov	w10, #0x96c9            ; =38601
    1a4c:      	movk	w10, #0x3ab6, lsl #16
    1a50:      	dup.4s	v17, w10
    1a54:      	fadd.4s	v16, v16, v17
    1a58:      	fmul.4s	v16, v3, v16
    1a5c:      	mov	w10, #0x88a6            ; =34982
    1a60:      	movk	w10, #0x3c08, lsl #16
    1a64:      	dup.4s	v17, w10
    1a68:      	fadd.4s	v16, v16, v17
    1a6c:      	fmul.4s	v16, v3, v16
    1a70:      	mov	w10, #0xaa7a            ; =43642
    1a74:      	movk	w10, #0x3d2a, lsl #16
    1a78:      	dup.4s	v17, w10
    1a7c:      	fadd.4s	v16, v16, v17
    1a80:      	fmul.4s	v16, v3, v16
    1a84:      	mov	w10, #0xaaab            ; =43691
    1a88:      	movk	w10, #0x3e2a, lsl #16
    1a8c:      	dup.4s	v17, w10
    1a90:      	fadd.4s	v16, v16, v17
    1a94:      	fmul.4s	v16, v3, v16
    1a98:      	movi.4s	v17, #0x3f, lsl #24
    1a9c:      	fadd.4s	v16, v16, v17
    1aa0:      	fmul.4s	v17, v3, v3
    1aa4:      	fmul.4s	v16, v17, v16
    1aa8:      	fadd.4s	v3, v3, v16
    1aac:      	fadd.4s	v3, v3, v26
    1ab0:      	sshr.4s	v16, v7, #0x1
    1ab4:      	shl.4s	v17, v16, #0x17
    1ab8:      	add.4s	v17, v17, v26
    1abc:      	fmul.4s	v3, v3, v17
    1ac0:      	sub.4s	v7, v7, v16
    1ac4:      	shl.4s	v7, v7, #0x17
    1ac8:      	add.4s	v7, v7, v26
    1acc:      	fmul.4s	v3, v3, v7
    1ad0:      	fcmgt.4s	v2, v2, v0
    1ad4:      	bic.16b	v2, v3, v2
    1ad8:      	fcmgt.4s	v3, v0, v4
    1adc:      	mvni.4s	v4, #0x7f, msl #16
    1ae0:      	fneg.4s	v4, v4
    1ae4:      	bit.16b	v2, v4, v3
    1ae8:      	fcmeq.4s	v0, v0, v0
    1aec:      	mvni.4s	v3, #0x3f, msl #16
    1af0:      	fneg.4s	v3, v3
    1af4:      	bsl.16b	v0, v2, v3
    1af8:      	bic.16b	v0, v0, v1
    1afc:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
    1b00:      	add	x10, x10, #0x999
    1b04:      	ldur	q1, [x10, #0xff]
    1b08:      	ldr	q6, [sp, #0x1f0]
    1b0c:      	fadd.4s	v2, v0, v6
    1b10:      	mov.d	v0[1], v1[1]
    1b14:      	mov.d	v2[1], v6[1]
    1b18:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
    1b1c:      	add	x10, x10, #0x999
    1b20:      	stur	q0, [x10, #0xff]
    1b24:      	fadd.4s	v1, v5, v2
    1b28:      	ldr	q2, [sp, #0x200]
    1b2c:      	fadd.4s	v2, v29, v2
    1b30:      	fadd.4s	v1, v23, v1
    1b34:      	fadd.4s	v2, v28, v2
    1b38:      	fadd.4s	v1, v18, v1
    1b3c:      	fadd.4s	v2, v19, v2
    1b40:      	rev64.4s	v3, v1
    1b44:      	rev64.4s	v4, v2
    1b48:      	fadd.4s	v1, v1, v3
    1b4c:      	dup.4s	v3, v1[2]
    1b50:      	fadd.4s	v2, v2, v4
    1b54:      	dup.4s	v4, v2[2]
    1b58:      	fadd.4s	v1, v1, v3
    1b5c:      	fadd.4s	v2, v2, v4
    1b60:      	fadd.4s	v1, v1, v2
    1b64:      	movi	d2, #0000000000000000
    1b68:      	fadd	s1, s1, s2
    1b6c:      	dup.4s	v2, v1[0]
    1b70:      	add	x10, x19, x20
    1b74:      	add	x11, sp, #0x298
    1b78:      	lsl	x12, x9, #5
    1b7c:      	add	x13, x11, x12
    1b80:      	ldp	q4, q3, [x13]
    1b84:      	fdiv.4s	v4, v4, v2
    1b88:      	fdiv.4s	v3, v3, v2
    1b8c:      	add	x12, x10, x12
    1b90:      	stp	q4, q3, [x12]
    1b94:      	add	x9, x9, #0x1
    1b98:      	cmp	x9, #0xc0
    1b9c:      	b.ne	0x1b78 <ltmp0+0x1b78>
    1ba0:      	dup.2s	v1, v1[0]
    1ba4:      	fdiv.2s	v0, v0, v1
    1ba8:      	str	d0, [x19, x8]
    1bac:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
    1bb0:      	add	sp, sp, #0x140
    1bb4:      	ldp	x29, x30, [sp, #0x90]
    1bb8:      	ldp	x20, x19, [sp, #0x80]
    1bbc:      	ldp	x22, x21, [sp, #0x70]
    1bc0:      	ldp	x24, x23, [sp, #0x60]
    1bc4:      	ldp	x26, x25, [sp, #0x50]
    1bc8:      	ldp	x28, x27, [sp, #0x40]
    1bcc:      	ldp	d9, d8, [sp, #0x30]
    1bd0:      	ldp	d11, d10, [sp, #0x20]
    1bd4:      	ldp	d13, d12, [sp, #0x10]
    1bd8:      	ldp	d15, d14, [sp], #0xa0
    1bdc:      	ret

0000000000001be0 <_llm_rows.packet_batch.blocks>:
    1be0:      	stp	d15, d14, [sp, #-0xa0]!
    1be4:      	stp	d13, d12, [sp, #0x10]
    1be8:      	stp	d11, d10, [sp, #0x20]
    1bec:      	stp	d9, d8, [sp, #0x30]
    1bf0:      	stp	x28, x27, [sp, #0x40]
    1bf4:      	stp	x26, x25, [sp, #0x50]
    1bf8:      	stp	x24, x23, [sp, #0x60]
    1bfc:      	stp	x22, x21, [sp, #0x70]
    1c00:      	stp	x20, x19, [sp, #0x80]
    1c04:      	stp	x29, x30, [sp, #0x90]
    1c08:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
    1c0c:      	sub	sp, sp, #0x9a0
    1c10:      	str	x0, [sp, #0x1c8]
    1c14:      	cbz	w3, 0x56fc <_llm_rows.packet_batch.blocks+0x3b1c>
    1c18:      	mov	x19, x3
    1c1c:      	mov	x20, x2
    1c20:      	mov	w22, #0x0               ; =0
    1c24:      	add	x23, sp, #0xaf8
    1c28:      	add	x8, sp, #0x3, lsl #12   ; =0x3000
    1c2c:      	add	x8, x8, #0xb38
    1c30:      	dup.2d	v0, x8
    1c34:      	str	q0, [sp, #0x40]
    1c38:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1c3c:      	ldr	q0, [x8]
    1c40:      	str	q0, [sp, #0x30]
    1c44:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1c48:      	ldr	q0, [x8]
    1c4c:      	str	q0, [sp, #0x180]
    1c50:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1c54:      	ldr	q0, [x8]
    1c58:      	str	q0, [sp, #0x170]
    1c5c:      	add	x28, sp, #0x7, lsl #12  ; =0x7000
    1c60:      	add	x28, x28, #0x180
    1c64:      	mov	w8, #0x40               ; =64
    1c68:      	fmov	d0, x8
    1c6c:      	str	q0, [sp, #0x20]
    1c70:      	mov	w8, #0x60               ; =96
    1c74:      	fmov	d0, x8
    1c78:      	str	q0, [sp, #0x10]
    1c7c:      	mvni.4s	v0, #0x7f, msl #16
    1c80:      	fneg.4s	v1, v0
    1c84:      	mvni.4s	v0, #0x3f, msl #16
    1c88:      	fneg.4s	v0, v0
    1c8c:      	stp	q0, q1, [sp, #0x3e0]
    1c90:      	ldp	w9, w8, [x2, #0x2c]
    1c94:      	str	w9, [sp, #0x1c4]
    1c98:      	str	w8, [sp, #0x1c0]
    1c9c:      	add	x25, sp, #0x2, lsl #12  ; =0x2000
    1ca0:      	add	x25, x25, #0x318
    1ca4:      	ldp	w27, w15, [x2]
    1ca8:      	ldp	w21, w8, [x2, #0x8]
    1cac:      	str	x8, [sp, #0x1b8]
    1cb0:      	str	w3, [sp, #0x16c]
    1cb4:      	b	0x1d00 <_llm_rows.packet_batch.blocks+0x120>
    1cb8:      	mov	w8, #0x18               ; =24
    1cbc:      	str	w8, [x20, #0x24]
    1cc0:      	ldr	w19, [sp, #0x16c]
    1cc4:      	add	w8, w27, #0x1
    1cc8:      	ldr	w9, [sp, #0x1c4]
    1ccc:      	cmp	w8, w9
    1cd0:      	cset	w8, eq
    1cd4:      	csinc	w27, wzr, w27, eq
    1cd8:      	cinc	w9, w15, eq
    1cdc:      	ldr	w10, [sp, #0x1c0]
    1ce0:      	cmp	w9, w10
    1ce4:      	cset	w10, eq
    1ce8:      	ands	w8, w8, w10
    1cec:      	csel	w15, wzr, w9, ne
    1cf0:      	add	w21, w21, w8
    1cf4:      	add	w22, w22, #0x1
    1cf8:      	cmp	w22, w19
    1cfc:      	b.eq	0x56fc <_llm_rows.packet_batch.blocks+0x3b1c>
    1d00:      	ubfiz	x8, x27, #5, #32
    1d04:      	ldr	x12, [sp, #0x1b8]
    1d08:      	cmp	x8, x12
    1d0c:      	csel	x9, x8, xzr, ls
    1d10:      	subs	x10, x12, x9
    1d14:      	cmp	x10, #0x20
    1d18:      	mov	w11, #0x20              ; =32
    1d1c:      	csel	x10, x10, x11, lo
    1d20:      	cmp	x12, x9
    1d24:      	stp	w27, w15, [x20]
    1d28:      	str	w21, [x20, #0x8]
    1d2c:      	str	wzr, [x20, #0x24]
    1d30:      	ccmp	x8, x12, #0x2, hi
    1d34:      	csel	x26, x10, xzr, ls
    1d38:      	cmp	x26, #0x20
    1d3c:      	b.lo	0x1d98 <_llm_rows.packet_batch.blocks+0x1b8>
    1d40:      	ldr	x26, [sp, #0x1c8]
    1d44:      	mov	x0, x26
    1d48:      	mov	x1, x20
    1d4c:      	mov	x24, x15
    1d50:      	bl	0x1d50 <_llm_rows.packet_batch.blocks+0x170>
    1d54:      	mov	w8, #0x8                ; =8
    1d58:      	str	w8, [x20, #0x24]
    1d5c:      	mov	x0, x26
    1d60:      	mov	x1, x20
    1d64:      	bl	0x1d64 <_llm_rows.packet_batch.blocks+0x184>
    1d68:      	mov	w8, #0x10               ; =16
    1d6c:      	str	w8, [x20, #0x24]
    1d70:      	mov	x0, x26
    1d74:      	mov	x1, x20
    1d78:      	bl	0x1d78 <_llm_rows.packet_batch.blocks+0x198>
    1d7c:      	mov	w8, #0x18               ; =24
    1d80:      	str	w8, [x20, #0x24]
    1d84:      	mov	x0, x26
    1d88:      	mov	x1, x20
    1d8c:      	bl	0x1d8c <_llm_rows.packet_batch.blocks+0x1ac>
    1d90:      	mov	x15, x24
    1d94:      	b	0x1cc4 <_llm_rows.packet_batch.blocks+0xe4>
    1d98:      	lsr	x19, x26, #3
    1d9c:      	cmp	x26, #0x8
    1da0:      	b.lo	0x1dfc <_llm_rows.packet_batch.blocks+0x21c>
    1da4:      	str	wzr, [x20, #0x24]
    1da8:      	ldr	x0, [sp, #0x1c8]
    1dac:      	mov	x1, x20
    1db0:      	mov	x24, x15
    1db4:      	bl	0x1db4 <_llm_rows.packet_batch.blocks+0x1d4>
    1db8:      	mov	x15, x24
    1dbc:      	cmp	x19, #0x1
    1dc0:      	b.eq	0x1dfc <_llm_rows.packet_batch.blocks+0x21c>
    1dc4:      	mov	w8, #0x8                ; =8
    1dc8:      	str	w8, [x20, #0x24]
    1dcc:      	ldr	x0, [sp, #0x1c8]
    1dd0:      	mov	x1, x20
    1dd4:      	bl	0x1dd4 <_llm_rows.packet_batch.blocks+0x1f4>
    1dd8:      	mov	x15, x24
    1ddc:      	cmp	x19, #0x2
    1de0:      	b.eq	0x1dfc <_llm_rows.packet_batch.blocks+0x21c>
    1de4:      	mov	w8, #0x10               ; =16
    1de8:      	str	w8, [x20, #0x24]
    1dec:      	ldr	x0, [sp, #0x1c8]
    1df0:      	mov	x1, x20
    1df4:      	bl	0x1df4 <_llm_rows.packet_batch.blocks+0x214>
    1df8:      	mov	x15, x24
    1dfc:      	and	w8, w26, #0x7
    1e00:      	cbz	w8, 0x1cb8 <_llm_rows.packet_batch.blocks+0xd8>
    1e04:      	dup.4s	v3, w8
    1e08:      	ldp	q0, q1, [sp, #0x170]
    1e0c:      	cmhi.4s	v0, v3, v0
    1e10:      	cmhi.4s	v1, v3, v1
    1e14:      	uzp1.8h	v4, v1, v0
    1e18:      	umaxv.8h	h2, v4
    1e1c:      	fmov	w8, s2
    1e20:      	tbz	w8, #0x0, 0x1cb8 <_llm_rows.packet_batch.blocks+0xd8>
    1e24:      	mov	x8, #0x0                ; =0
    1e28:      	ldr	x9, [sp, #0x1c8]
    1e2c:      	ldr	x10, [x9]
    1e30:      	ldr	x16, [x9, #0x30]
    1e34:      	ldr	q2, [sp, #0x30]
    1e38:      	and.16b	v2, v4, v2
    1e3c:      	addv.8h	h13, v2
    1e40:      	fmov	w9, s13
    1e44:      	and	w9, w9, #0xff
    1e48:      	str	w9, [sp, #0x3d0]
    1e4c:      	ubfiz	w9, w27, #2, #27
    1e50:      	orr	w9, w9, w19
    1e54:      	dup.4s	v2, w9
    1e58:      	and.16b	v16, v1, v2
    1e5c:      	and.16b	v2, v0, v2
    1e60:      	ushll2.2d	v5, v2, #0x0
    1e64:      	ushll2.2d	v6, v16, #0x0
    1e68:      	ushll.2d	v18, v2, #0x0
    1e6c:      	ushll.2d	v7, v16, #0x0
    1e70:      	fmov	x9, d7
    1e74:      	mov	w11, #0x1808            ; =6152
    1e78:      	umaddl	x9, w9, w11, x10
    1e7c:      	fmov	w11, s13
    1e80:      	add	x2, sp, #0x4, lsl #12   ; =0x4000
    1e84:      	add	x2, x2, #0x140
    1e88:      	mov	w3, #0x4                ; =4
    1e8c:      	b	0x1eb0 <_llm_rows.packet_batch.blocks+0x2d0>
    1e90:      	add	x12, x28, x8, lsl #5
    1e94:      	ldp	q20, q21, [x12]
    1e98:      	bif.16b	v19, v21, v0
    1e9c:      	bif.16b	v17, v20, v1
    1ea0:      	stp	q17, q19, [x12]
    1ea4:      	add	x8, x8, #0x1
    1ea8:      	cmp	x8, #0xc0
    1eac:      	b.eq	0x1f44 <_llm_rows.packet_batch.blocks+0x364>
    1eb0:      	add	x13, x9, x8, lsl #5
    1eb4:      	movi.2d	v17, #0000000000000000
    1eb8:      	movi.2d	v19, #0000000000000000
    1ebc:      	tbnz	w11, #0x0, 0x1ee4 <_llm_rows.packet_batch.blocks+0x304>
    1ec0:      	and	w14, w11, #0xff
    1ec4:      	tbnz	w14, #0x1, 0x1ef0 <_llm_rows.packet_batch.blocks+0x310>
    1ec8:      	tbnz	w14, #0x2, 0x1efc <_llm_rows.packet_batch.blocks+0x31c>
    1ecc:      	tbnz	w14, #0x3, 0x1f08 <_llm_rows.packet_batch.blocks+0x328>
    1ed0:      	tbnz	w14, #0x4, 0x1f14 <_llm_rows.packet_batch.blocks+0x334>
    1ed4:      	tbnz	w14, #0x5, 0x1f20 <_llm_rows.packet_batch.blocks+0x340>
    1ed8:      	tbnz	w14, #0x6, 0x1f2c <_llm_rows.packet_batch.blocks+0x34c>
    1edc:      	tbz	w14, #0x7, 0x1e90 <_llm_rows.packet_batch.blocks+0x2b0>
    1ee0:      	b	0x1f38 <_llm_rows.packet_batch.blocks+0x358>
    1ee4:      	ldr	s17, [x13]
    1ee8:      	and	w14, w11, #0xff
    1eec:      	tbz	w14, #0x1, 0x1ec8 <_llm_rows.packet_batch.blocks+0x2e8>
    1ef0:      	add	x12, x13, #0x4
    1ef4:      	ld1.s	{ v17 }[1], [x12]
    1ef8:      	tbz	w14, #0x2, 0x1ecc <_llm_rows.packet_batch.blocks+0x2ec>
    1efc:      	add	x12, x13, #0x8
    1f00:      	ld1.s	{ v17 }[2], [x12]
    1f04:      	tbz	w14, #0x3, 0x1ed0 <_llm_rows.packet_batch.blocks+0x2f0>
    1f08:      	add	x12, x13, #0xc
    1f0c:      	ld1.s	{ v17 }[3], [x12]
    1f10:      	tbz	w14, #0x4, 0x1ed4 <_llm_rows.packet_batch.blocks+0x2f4>
    1f14:      	add	x12, x13, #0x10
    1f18:      	ld1.s	{ v19 }[0], [x12]
    1f1c:      	tbz	w14, #0x5, 0x1ed8 <_llm_rows.packet_batch.blocks+0x2f8>
    1f20:      	add	x12, x13, #0x14
    1f24:      	ld1.s	{ v19 }[1], [x12]
    1f28:      	tbz	w14, #0x6, 0x1edc <_llm_rows.packet_batch.blocks+0x2fc>
    1f2c:      	add	x12, x13, #0x18
    1f30:      	ld1.s	{ v19 }[2], [x12]
    1f34:      	tbz	w14, #0x7, 0x1e90 <_llm_rows.packet_batch.blocks+0x2b0>
    1f38:      	add	x12, x13, #0x1c
    1f3c:      	ld1.s	{ v19 }[3], [x12]
    1f40:      	b	0x1e90 <_llm_rows.packet_batch.blocks+0x2b0>
    1f44:      	xtn.8b	v21, v4
    1f48:      	sshll.2d	v4, v1, #0x0
    1f4c:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1f50:      	ldr	q19, [x8]
    1f54:      	and.16b	v22, v4, v19
    1f58:      	movi	d17, #0x0000000000ffff
    1f5c:      	and.8b	v20, v21, v17
    1f60:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1f64:      	ldr	d17, [x8]
    1f68:      	str	q21, [sp, #0x1a0]
    1f6c:      	and.8b	v17, v21, v17
    1f70:      	addv.8b	b17, v17
    1f74:      	fmov	w8, s17
    1f78:      	umaxv.8b	b17, v20
    1f7c:      	fmov	w9, s17
    1f80:      	rbit	w11, w8
    1f84:      	clz	w11, w11
    1f88:      	tst	w9, #0x1
    1f8c:      	csel	w4, w11, wzr, ne
    1f90:      	mov	w9, #0x600              ; =1536
    1f94:      	dup.2d	v21, x9
    1f98:      	str	q22, [sp, #0x3c0]
    1f9c:      	orr.16b	v17, v22, v21
    1fa0:      	mov	w9, #0x602              ; =1538
    1fa4:      	dup.2s	v23, w9
    1fa8:      	xtn.2s	v24, v7
    1fac:      	mov.16b	v22, v17
    1fb0:      	umlal.2d	v22, v24, v23
    1fb4:      	mov	b7, v20[0]
    1fb8:      	str	q20, [sp, #0x1d0]
    1fbc:      	mov.b	v7[4], v20[1]
    1fc0:      	ushll.2d	v7, v7, #0x0
    1fc4:      	shl.2d	v7, v7, #0x3f
    1fc8:      	cmlt.2d	v7, v7, #0
    1fcc:      	str	q22, [sp, #0x140]
    1fd0:      	and.16b	v7, v7, v22
    1fd4:      	movi.2d	v20, #0000000000000000
    1fd8:      	str	q20, [sp, #0xae0]
    1fdc:      	str	q20, [sp, #0xad0]
    1fe0:      	str	q20, [sp, #0xac0]
    1fe4:      	str	q7, [sp, #0xab0]
    1fe8:      	and	x9, x4, #0x7
    1fec:      	add	x11, sp, #0xab0
    1ff0:      	ldr	x9, [x11, x9, lsl #3]
    1ff4:      	sub	x9, x9, x4
    1ff8:      	add	x10, x10, x9, lsl #2
    1ffc:      	movi.2d	v27, #0000000000000000
    2000:      	movi.2d	v15, #0000000000000000
    2004:      	tbnz	w8, #0x0, 0x269c <_llm_rows.packet_batch.blocks+0xabc>
    2008:      	tbnz	w8, #0x1, 0x26a4 <_llm_rows.packet_batch.blocks+0xac4>
    200c:      	tbnz	w8, #0x2, 0x26b0 <_llm_rows.packet_batch.blocks+0xad0>
    2010:      	tbnz	w8, #0x3, 0x26bc <_llm_rows.packet_batch.blocks+0xadc>
    2014:      	tbnz	w8, #0x4, 0x26c8 <_llm_rows.packet_batch.blocks+0xae8>
    2018:      	tbnz	w8, #0x5, 0x26d4 <_llm_rows.packet_batch.blocks+0xaf4>
    201c:      	tbnz	w8, #0x6, 0x26e0 <_llm_rows.packet_batch.blocks+0xb00>
    2020:      	tbz	w8, #0x7, 0x202c <_llm_rows.packet_batch.blocks+0x44c>
    2024:      	add	x9, x10, #0x1c
    2028:      	ld1.s	{ v15 }[3], [x9]
    202c:      	str	x16, [sp, #0x160]
    2030:      	str	w15, [sp, #0x168]
    2034:      	mov	x10, #0x0               ; =0
    2038:      	sshll.2d	v7, v0, #0x0
    203c:      	sshll2.2d	v28, v1, #0x0
    2040:      	sshll2.2d	v12, v0, #0x0
    2044:      	adrp	x9, 0x2000 <_llm_rows.packet_batch.blocks+0x420>
    2048:      	ldr	q20, [x9]
    204c:      	and.16b	v20, v12, v20
    2050:      	adrp	x9, 0x2000 <_llm_rows.packet_batch.blocks+0x420>
    2054:      	ldr	q22, [x9]
    2058:      	and.16b	v22, v28, v22
    205c:      	adrp	x9, 0x2000 <_llm_rows.packet_batch.blocks+0x420>
    2060:      	ldr	q25, [x9]
    2064:      	and.16b	v25, v7, v25
    2068:      	adrp	x9, 0x2000 <_llm_rows.packet_batch.blocks+0x420>
    206c:      	ldr	q26, [x9]
    2070:      	and.16b	v4, v4, v26
    2074:      	str	q4, [sp, #0xa70]
    2078:      	str	q22, [sp, #0xa80]
    207c:      	str	q25, [sp, #0xa90]
    2080:      	str	q20, [sp, #0xaa0]
    2084:      	and	x9, x4, #0x7
    2088:      	add	x11, sp, #0xa70
    208c:      	ldr	x9, [x11, x9, lsl #3]
    2090:      	orr	x9, x9, #0x1800
    2094:      	sub	x9, x9, x4, lsl #2
    2098:      	tst	w8, #0xff
    209c:      	csel	x5, xzr, x9, eq
    20a0:      	add	x9, x28, x5
    20a4:      	ldp	q20, q22, [x9]
    20a8:      	ldr	q26, [sp, #0x1d0]
    20ac:      	zip2.8b	v25, v26, v0
    20b0:      	ushll.4s	v25, v25, #0x0
    20b4:      	shl.4s	v25, v25, #0x1f
    20b8:      	cmlt.4s	v25, v25, #0
    20bc:      	bit.16b	v22, v15, v25
    20c0:      	zip1.8b	v25, v26, v0
    20c4:      	ushll.4s	v25, v25, #0x0
    20c8:      	shl.4s	v25, v25, #0x1f
    20cc:      	cmlt.4s	v25, v25, #0
    20d0:      	str	q27, [sp, #0x3b0]
    20d4:      	bit.16b	v20, v27, v25
    20d8:      	stp	q20, q22, [x9]
    20dc:      	adrp	x9, 0x2000 <_llm_rows.packet_batch.blocks+0x420>
    20e0:      	ldr	q25, [x9]
    20e4:      	and.16b	v29, v12, v25
    20e8:      	adrp	x9, 0x2000 <_llm_rows.packet_batch.blocks+0x420>
    20ec:      	ldr	q26, [x9]
    20f0:      	and.16b	v22, v28, v26
    20f4:      	adrp	x9, 0x2000 <_llm_rows.packet_batch.blocks+0x420>
    20f8:      	ldr	q27, [x9]
    20fc:      	and.16b	v7, v7, v27
    2100:      	stp	q7, q22, [sp, #0x380]
    2104:      	orr.16b	v20, v7, v21
    2108:      	orr.16b	v22, v22, v21
    210c:      	str	q29, [sp, #0x3a0]
    2110:      	orr.16b	v21, v29, v21
    2114:      	umull.2d	v7, v24, v23
    2118:      	str	q7, [sp, #0x100]
    211c:      	xtn.2s	v6, v6
    2120:      	xtn.2s	v18, v18
    2124:      	xtn.2s	v5, v5
    2128:      	mov.16b	v7, v21
    212c:      	umlal.2d	v7, v5, v23
    2130:      	str	q7, [sp, #0x130]
    2134:      	mov.16b	v7, v28
    2138:      	mov.16b	v5, v22
    213c:      	umlal.2d	v5, v6, v23
    2140:      	str	q5, [sp, #0x120]
    2144:      	mov.16b	v5, v20
    2148:      	umlal.2d	v5, v18, v23
    214c:      	str	q5, [sp, #0x110]
    2150:      	mov	w9, #0x1                ; =1
    2154:      	dup.2d	v5, x9
    2158:      	ushll2.2d	v6, v0, #0x0
    215c:      	and.16b	v29, v6, v5
    2160:      	ushll2.2d	v6, v1, #0x0
    2164:      	and.16b	v30, v6, v5
    2168:      	ushll.2d	v6, v0, #0x0
    216c:      	and.16b	v31, v6, v5
    2170:      	ushll.2d	v6, v1, #0x0
    2174:      	and.16b	v8, v6, v5
    2178:      	movi.2d	v5, #0000000000000000
    217c:      	movi.2d	v6, #0000000000000000
    2180:      	movi.2d	v18, #0000000000000000
    2184:      	movi.2d	v23, #0000000000000000
    2188:      	stp	q30, q29, [sp, #0x200]
    218c:      	stp	q8, q31, [sp, #0x1e0]
    2190:      	str	q12, [sp, #0x350]
    2194:      	sshll.2d	v24, v0, #0x0
    2198:      	sshll.2d	v28, v1, #0x0
    219c:      	shl.2d	v29, v23, #0x3
    21a0:      	shl.2d	v30, v5, #0x3
    21a4:      	shl.2d	v31, v18, #0x3
    21a8:      	shl.2d	v8, v6, #0x3
    21ac:      	orr.16b	v8, v8, v26
    21b0:      	orr.16b	v31, v31, v27
    21b4:      	orr.16b	v30, v30, v19
    21b8:      	orr.16b	v29, v29, v25
    21bc:      	add	x9, x2, x10, lsl #6
    21c0:      	ldp	q10, q9, [x9]
    21c4:      	ldp	q11, q12, [x9, #0x20]
    21c8:      	ldr	q14, [sp, #0x350]
    21cc:      	bif.16b	v29, v12, v14
    21d0:      	ldr	q12, [sp, #0x350]
    21d4:      	bsl.16b	v28, v30, v10
    21d8:      	bsl.16b	v24, v31, v11
    21dc:      	mov.16b	v30, v7
    21e0:      	bsl.16b	v30, v8, v9
    21e4:      	ldp	q8, q31, [sp, #0x1e0]
    21e8:      	stp	q28, q30, [x9]
    21ec:      	stp	q24, q29, [x9, #0x20]
    21f0:      	ldp	q30, q29, [sp, #0x200]
    21f4:      	add.2d	v6, v6, v30
    21f8:      	add.2d	v18, v18, v31
    21fc:      	add.2d	v23, v23, v29
    2200:      	add.2d	v5, v5, v8
    2204:      	fmov	x10, d5
    2208:      	cmp	x10, #0xc0
    220c:      	b.lt	0x2194 <_llm_rows.packet_batch.blocks+0x5b4>
    2210:      	mov	x10, #0x0               ; =0
    2214:      	mov	w9, #0x602              ; =1538
    2218:      	dup.4s	v5, w9
    221c:      	and.16b	v6, v1, v5
    2220:      	mvn.16b	v18, v1
    2224:      	sub.4s	v6, v6, v18
    2228:      	and.16b	v5, v0, v5
    222c:      	mvn.16b	v18, v0
    2230:      	sub.4s	v5, v5, v18
    2234:      	mov.s	w9, v5[1]
    2238:      	mov.s	w11, v2[1]
    223c:      	udiv	w12, w11, w9
    2240:      	msub	w11, w12, w9, w11
    2244:      	mov.s	w9, v5[2]
    2248:      	mov.s	w12, v5[3]
    224c:      	fmov	w13, s5
    2250:      	fmov	w14, s2
    2254:      	udiv	w15, w14, w13
    2258:      	msub	w13, w15, w13, w14
    225c:      	mov.s	w14, v2[2]
    2260:      	udiv	w15, w14, w9
    2264:      	msub	w14, w15, w9, w14
    2268:      	mov.s	w9, v2[3]
    226c:      	udiv	w15, w9, w12
    2270:      	msub	w12, w15, w12, w9
    2274:      	mov.s	w9, v6[1]
    2278:      	mov.s	w15, v16[1]
    227c:      	udiv	w16, w15, w9
    2280:      	msub	w15, w16, w9, w15
    2284:      	mov.s	w9, v6[2]
    2288:      	mov.s	w16, v6[3]
    228c:      	fmov	w17, s6
    2290:      	fmov	w0, s16
    2294:      	udiv	w1, w0, w17
    2298:      	msub	w17, w1, w17, w0
    229c:      	mov.s	w0, v16[2]
    22a0:      	udiv	w1, w0, w9
    22a4:      	msub	w9, w1, w9, w0
    22a8:      	mov.s	w0, v16[3]
    22ac:      	udiv	w1, w0, w16
    22b0:      	msub	w16, w1, w16, w0
    22b4:      	tst	w8, #0xff
    22b8:      	fmov	s18, w13
    22bc:      	mov.s	v18[1], w11
    22c0:      	mov.s	v18[2], w14
    22c4:      	mov.s	v18[3], w12
    22c8:      	fmov	s19, w17
    22cc:      	sshll.2d	v24, v0, #0x0
    22d0:      	sshll.2d	v23, v1, #0x0
    22d4:      	adrp	x8, 0x2000 <_llm_rows.packet_batch.blocks+0x420>
    22d8:      	ldr	q2, [x8]
    22dc:      	and.16b	v2, v23, v2
    22e0:      	adrp	x8, 0x2000 <_llm_rows.packet_batch.blocks+0x420>
    22e4:      	ldr	q5, [x8]
    22e8:      	and.16b	v5, v24, v5
    22ec:      	adrp	x8, 0x2000 <_llm_rows.packet_batch.blocks+0x420>
    22f0:      	ldr	q6, [x8]
    22f4:      	and.16b	v6, v7, v6
    22f8:      	adrp	x8, 0x2000 <_llm_rows.packet_batch.blocks+0x420>
    22fc:      	ldr	q16, [x8]
    2300:      	and.16b	v16, v12, v16
    2304:      	str	q16, [sp, #0xa60]
    2308:      	str	q5, [sp, #0xa50]
    230c:      	str	q6, [sp, #0xa40]
    2310:      	str	q2, [sp, #0xa30]
    2314:      	mov.s	v19[1], w15
    2318:      	and	x8, x4, #0x7
    231c:      	add	x11, sp, #0xa30
    2320:      	ldr	x8, [x11, x8, lsl #3]
    2324:      	orr	x8, x8, #0x3000
    2328:      	sub	x8, x8, x4, lsl #3
    232c:      	csel	x8, xzr, x8, eq
    2330:      	add	x8, x2, x8
    2334:      	ldp	q16, q6, [x8, #0x20]
    2338:      	mov.16b	v26, v7
    233c:      	ldr	q7, [sp, #0x1d0]
    2340:      	mov	b2, v7[2]
    2344:      	mov.b	v2[4], v7[3]
    2348:      	ldp	q5, q25, [x8]
    234c:      	ushll.2d	v2, v2, #0x0
    2350:      	shl.2d	v2, v2, #0x3f
    2354:      	cmlt.2d	v2, v2, #0
    2358:      	bsl.16b	v2, v22, v25
    235c:      	mov	b22, v7[0]
    2360:      	mov.b	v22[4], v7[1]
    2364:      	ushll.2d	v22, v22, #0x0
    2368:      	shl.2d	v22, v22, #0x3f
    236c:      	cmlt.2d	v22, v22, #0
    2370:      	bit.16b	v5, v17, v22
    2374:      	mov	b17, v7[6]
    2378:      	mov.b	v17[4], v7[7]
    237c:      	ushll.2d	v17, v17, #0x0
    2380:      	shl.2d	v17, v17, #0x3f
    2384:      	cmlt.2d	v17, v17, #0
    2388:      	bit.16b	v6, v21, v17
    238c:      	mov	b17, v7[4]
    2390:      	mov.b	v17[4], v7[5]
    2394:      	ushll.2d	v17, v17, #0x0
    2398:      	shl.2d	v17, v17, #0x3f
    239c:      	cmlt.2d	v17, v17, #0
    23a0:      	bit.16b	v16, v20, v17
    23a4:      	mov.s	v19[2], w9
    23a8:      	mov.s	v19[3], w16
    23ac:      	and.16b	v20, v1, v19
    23b0:      	stp	q16, q6, [x8, #0x20]
    23b4:      	stp	q5, q2, [x8]
    23b8:      	and.16b	v19, v0, v18
    23bc:      	ushll2.2d	v17, v19, #0x0
    23c0:      	ushll2.2d	v18, v20, #0x0
    23c4:      	ushll.2d	v19, v19, #0x0
    23c8:      	ushll.2d	v20, v20, #0x0
    23cc:      	ldr	q7, [sp, #0x40]
    23d0:      	and.16b	v14, v12, v7
    23d4:      	and.16b	v21, v26, v7
    23d8:      	str	q21, [sp, #0x450]
    23dc:      	and.16b	v21, v24, v7
    23e0:      	str	q21, [sp, #0x440]
    23e4:      	and.16b	v7, v23, v7
    23e8:      	str	q7, [sp, #0x430]
    23ec:      	adrp	x8, 0x2000 <_llm_rows.packet_batch.blocks+0x420>
    23f0:      	ldr	q21, [x8]
    23f4:      	and.16b	v7, v12, v21
    23f8:      	str	q7, [sp, #0x330]
    23fc:      	adrp	x8, 0x2000 <_llm_rows.packet_batch.blocks+0x420>
    2400:      	ldr	q21, [x8]
    2404:      	str	q26, [sp, #0x2f0]
    2408:      	and.16b	v7, v26, v21
    240c:      	str	q7, [sp, #0x320]
    2410:      	adrp	x8, 0x2000 <_llm_rows.packet_batch.blocks+0x420>
    2414:      	ldr	q21, [x8]
    2418:      	and.16b	v7, v24, v21
    241c:      	str	q7, [sp, #0x310]
    2420:      	adrp	x8, 0x2000 <_llm_rows.packet_batch.blocks+0x420>
    2424:      	ldr	q21, [x8]
    2428:      	and.16b	v7, v23, v21
    242c:      	str	q7, [sp, #0x300]
    2430:      	ldr	q7, [sp, #0x170]
    2434:      	cmhs.4s	v21, v7, v3
    2438:      	ldr	q7, [sp, #0x180]
    243c:      	cmhs.4s	v3, v7, v3
    2440:      	uzp1.8h	v3, v3, v21
    2444:      	xtn.8b	v3, v3
    2448:      	movi.2d	v21, #0000000000000000
    244c:      	movi.2d	v22, #0000000000000000
    2450:      	movi.2d	v23, #0000000000000000
    2454:      	movi.2d	v24, #0000000000000000
    2458:      	movi.8b	v7, #0x1
    245c:      	b	0x247c <_llm_rows.packet_batch.blocks+0x89c>
    2460:      	add.2d	v22, v22, v30
    2464:      	add.2d	v23, v23, v31
    2468:      	add.2d	v24, v24, v29
    246c:      	add.2d	v21, v21, v8
    2470:      	fmov	x10, d21
    2474:      	cmp	x10, #0xc0
    2478:      	b.ge	0x25a8 <_llm_rows.packet_batch.blocks+0x9c8>
    247c:      	fmov	w8, s13
    2480:      	add	x9, x2, x10, lsl #6
    2484:      	ldp	q26, q25, [x9, #0x20]
    2488:      	ldp	q27, q28, [x9]
    248c:      	cmge.2d	v28, v18, v28
    2490:      	cmge.2d	v27, v20, v27
    2494:      	uzp1.4s	v27, v27, v28
    2498:      	cmge.2d	v26, v19, v26
    249c:      	cmge.2d	v25, v17, v25
    24a0:      	uzp1.4s	v25, v26, v25
    24a4:      	uzp1.8h	v25, v27, v25
    24a8:      	xtn.8b	v25, v25
    24ac:      	orr.8b	v25, v3, v25
    24b0:      	ldr	q26, [sp, #0x300]
    24b4:      	add.2d	v26, v21, v26
    24b8:      	ldr	q27, [sp, #0x430]
    24bc:      	add.2d	v26, v27, v26
    24c0:      	and.8b	v25, v25, v7
    24c4:      	tbnz	w8, #0x0, 0x2518 <_llm_rows.packet_batch.blocks+0x938>
    24c8:      	and	w8, w8, #0xff
    24cc:      	tbnz	w8, #0x1, 0x2528 <_llm_rows.packet_batch.blocks+0x948>
    24d0:      	ldr	q26, [sp, #0x320]
    24d4:      	add.2d	v26, v22, v26
    24d8:      	ldr	q27, [sp, #0x450]
    24dc:      	add.2d	v26, v27, v26
    24e0:      	tbnz	w8, #0x2, 0x2544 <_llm_rows.packet_batch.blocks+0x964>
    24e4:      	tbnz	w8, #0x3, 0x2550 <_llm_rows.packet_batch.blocks+0x970>
    24e8:      	ldr	q26, [sp, #0x310]
    24ec:      	add.2d	v26, v23, v26
    24f0:      	ldr	q27, [sp, #0x440]
    24f4:      	add.2d	v26, v27, v26
    24f8:      	tbnz	w8, #0x4, 0x256c <_llm_rows.packet_batch.blocks+0x98c>
    24fc:      	tbnz	w8, #0x5, 0x2578 <_llm_rows.packet_batch.blocks+0x998>
    2500:      	ldr	q26, [sp, #0x330]
    2504:      	add.2d	v26, v24, v26
    2508:      	add.2d	v26, v14, v26
    250c:      	tbnz	w8, #0x6, 0x2590 <_llm_rows.packet_batch.blocks+0x9b0>
    2510:      	tbz	w8, #0x7, 0x2460 <_llm_rows.packet_batch.blocks+0x880>
    2514:      	b	0x259c <_llm_rows.packet_batch.blocks+0x9bc>
    2518:      	fmov	x9, d26
    251c:      	str	b25, [x9]
    2520:      	and	w8, w8, #0xff
    2524:      	tbz	w8, #0x1, 0x24d0 <_llm_rows.packet_batch.blocks+0x8f0>
    2528:      	mov.d	x9, v26[1]
    252c:      	st1.b	{ v25 }[1], [x9]
    2530:      	ldr	q26, [sp, #0x320]
    2534:      	add.2d	v26, v22, v26
    2538:      	ldr	q27, [sp, #0x450]
    253c:      	add.2d	v26, v27, v26
    2540:      	tbz	w8, #0x2, 0x24e4 <_llm_rows.packet_batch.blocks+0x904>
    2544:      	fmov	x9, d26
    2548:      	st1.b	{ v25 }[2], [x9]
    254c:      	tbz	w8, #0x3, 0x24e8 <_llm_rows.packet_batch.blocks+0x908>
    2550:      	mov.d	x9, v26[1]
    2554:      	st1.b	{ v25 }[3], [x9]
    2558:      	ldr	q26, [sp, #0x310]
    255c:      	add.2d	v26, v23, v26
    2560:      	ldr	q27, [sp, #0x440]
    2564:      	add.2d	v26, v27, v26
    2568:      	tbz	w8, #0x4, 0x24fc <_llm_rows.packet_batch.blocks+0x91c>
    256c:      	fmov	x9, d26
    2570:      	st1.b	{ v25 }[4], [x9]
    2574:      	tbz	w8, #0x5, 0x2500 <_llm_rows.packet_batch.blocks+0x920>
    2578:      	mov.d	x9, v26[1]
    257c:      	st1.b	{ v25 }[5], [x9]
    2580:      	ldr	q26, [sp, #0x330]
    2584:      	add.2d	v26, v24, v26
    2588:      	add.2d	v26, v14, v26
    258c:      	tbz	w8, #0x6, 0x2510 <_llm_rows.packet_batch.blocks+0x930>
    2590:      	fmov	x9, d26
    2594:      	st1.b	{ v25 }[6], [x9]
    2598:      	tbz	w8, #0x7, 0x2460 <_llm_rows.packet_batch.blocks+0x880>
    259c:      	mov.d	x8, v26[1]
    25a0:      	st1.b	{ v25 }[7], [x8]
    25a4:      	b	0x2460 <_llm_rows.packet_batch.blocks+0x880>
    25a8:      	cmge.2d	v3, v20, v5
    25ac:      	cmge.2d	v2, v18, v2
    25b0:      	uzp1.4s	v2, v3, v2
    25b4:      	cmge.2d	v3, v19, v16
    25b8:      	cmge.2d	v5, v17, v6
    25bc:      	uzp1.4s	v3, v3, v5
    25c0:      	uzp1.8h	v2, v2, v3
    25c4:      	xtn.8b	v2, v2
    25c8:      	adrp	x8, 0x2000 <_llm_rows.packet_batch.blocks+0x420>
    25cc:      	ldr	d3, [x8]
    25d0:      	ldr	q6, [sp, #0x1d0]
    25d4:      	shl.8b	v5, v6, #0x7
    25d8:      	cmlt.8b	v5, v5, #0
    25dc:      	and.8b	v3, v5, v3
    25e0:      	addv.8b	b3, v3
    25e4:      	str	d3, [sp, #0x198]
    25e8:      	fmov	w9, s3
    25ec:      	orn.8b	v2, v2, v6
    25f0:      	ldr	q3, [sp, #0x430]
    25f4:      	ldr	q5, [sp, #0x300]
    25f8:      	add.2d	v5, v5, v3
    25fc:      	mov	w8, #0xc0               ; =192
    2600:      	dup.2d	v3, x8
    2604:      	add.2d	v20, v5, v3
    2608:      	and.8b	v2, v2, v7
    260c:      	tbnz	w9, #0x0, 0x26f0 <_llm_rows.packet_batch.blocks+0xb10>
    2610:      	mov.d	x14, v20[1]
    2614:      	ldr	q7, [sp, #0x2f0]
    2618:      	tbnz	w9, #0x1, 0x2704 <_llm_rows.packet_batch.blocks+0xb24>
    261c:      	ldr	q5, [sp, #0x450]
    2620:      	ldr	q6, [sp, #0x320]
    2624:      	add.2d	v5, v6, v5
    2628:      	add.2d	v18, v5, v3
    262c:      	tbnz	w9, #0x2, 0x271c <_llm_rows.packet_batch.blocks+0xb3c>
    2630:      	mov.d	x13, v18[1]
    2634:      	tbnz	w9, #0x3, 0x272c <_llm_rows.packet_batch.blocks+0xb4c>
    2638:      	ldr	q5, [sp, #0x440]
    263c:      	ldr	q6, [sp, #0x310]
    2640:      	add.2d	v5, v6, v5
    2644:      	add.2d	v5, v5, v3
    2648:      	tbnz	w9, #0x4, 0x2744 <_llm_rows.packet_batch.blocks+0xb64>
    264c:      	str	q5, [sp, #0xe0]
    2650:      	mov.d	x11, v5[1]
    2654:      	tbnz	w9, #0x5, 0x2758 <_llm_rows.packet_batch.blocks+0xb78>
    2658:      	ldr	q5, [sp, #0x330]
    265c:      	add.2d	v5, v5, v14
    2660:      	add.2d	v5, v5, v3
    2664:      	tbnz	w9, #0x6, 0x276c <_llm_rows.packet_batch.blocks+0xb8c>
    2668:      	mov.d	x8, v5[1]
    266c:      	tbnz	w9, #0x7, 0x277c <_llm_rows.packet_batch.blocks+0xb9c>
    2670:      	fmov	w9, s13
    2674:      	ldr	q2, [sp, #0x430]
    2678:      	ldr	q3, [sp, #0x300]
    267c:      	add.2d	v3, v2, v3
    2680:      	tbz	w9, #0x0, 0x2794 <_llm_rows.packet_batch.blocks+0xbb4>
    2684:      	fmov	x10, d3
    2688:      	ldr	b2, [x10]
    268c:      	and	w10, w9, #0xff
    2690:      	str	q5, [sp, #0x2e0]
    2694:      	tbnz	w10, #0x1, 0x27a4 <_llm_rows.packet_batch.blocks+0xbc4>
    2698:      	b	0x27ac <_llm_rows.packet_batch.blocks+0xbcc>
    269c:      	ldr	s27, [x10]
    26a0:      	tbz	w8, #0x1, 0x200c <_llm_rows.packet_batch.blocks+0x42c>
    26a4:      	add	x9, x10, #0x4
    26a8:      	ld1.s	{ v27 }[1], [x9]
    26ac:      	tbz	w8, #0x2, 0x2010 <_llm_rows.packet_batch.blocks+0x430>
    26b0:      	add	x9, x10, #0x8
    26b4:      	ld1.s	{ v27 }[2], [x9]
    26b8:      	tbz	w8, #0x3, 0x2014 <_llm_rows.packet_batch.blocks+0x434>
    26bc:      	add	x9, x10, #0xc
    26c0:      	ld1.s	{ v27 }[3], [x9]
    26c4:      	tbz	w8, #0x4, 0x2018 <_llm_rows.packet_batch.blocks+0x438>
    26c8:      	add	x9, x10, #0x10
    26cc:      	ld1.s	{ v15 }[0], [x9]
    26d0:      	tbz	w8, #0x5, 0x201c <_llm_rows.packet_batch.blocks+0x43c>
    26d4:      	add	x9, x10, #0x14
    26d8:      	ld1.s	{ v15 }[1], [x9]
    26dc:      	tbz	w8, #0x6, 0x2020 <_llm_rows.packet_batch.blocks+0x440>
    26e0:      	add	x9, x10, #0x18
    26e4:      	ld1.s	{ v15 }[2], [x9]
    26e8:      	tbnz	w8, #0x7, 0x2024 <_llm_rows.packet_batch.blocks+0x444>
    26ec:      	b	0x202c <_llm_rows.packet_batch.blocks+0x44c>
    26f0:      	fmov	x8, d20
    26f4:      	str	b2, [x8]
    26f8:      	mov.d	x14, v20[1]
    26fc:      	ldr	q7, [sp, #0x2f0]
    2700:      	tbz	w9, #0x1, 0x261c <_llm_rows.packet_batch.blocks+0xa3c>
    2704:      	st1.b	{ v2 }[1], [x14]
    2708:      	ldr	q5, [sp, #0x450]
    270c:      	ldr	q6, [sp, #0x320]
    2710:      	add.2d	v5, v6, v5
    2714:      	add.2d	v18, v5, v3
    2718:      	tbz	w9, #0x2, 0x2630 <_llm_rows.packet_batch.blocks+0xa50>
    271c:      	fmov	x8, d18
    2720:      	st1.b	{ v2 }[2], [x8]
    2724:      	mov.d	x13, v18[1]
    2728:      	tbz	w9, #0x3, 0x2638 <_llm_rows.packet_batch.blocks+0xa58>
    272c:      	st1.b	{ v2 }[3], [x13]
    2730:      	ldr	q5, [sp, #0x440]
    2734:      	ldr	q6, [sp, #0x310]
    2738:      	add.2d	v5, v6, v5
    273c:      	add.2d	v5, v5, v3
    2740:      	tbz	w9, #0x4, 0x264c <_llm_rows.packet_batch.blocks+0xa6c>
    2744:      	fmov	x8, d5
    2748:      	st1.b	{ v2 }[4], [x8]
    274c:      	str	q5, [sp, #0xe0]
    2750:      	mov.d	x11, v5[1]
    2754:      	tbz	w9, #0x5, 0x2658 <_llm_rows.packet_batch.blocks+0xa78>
    2758:      	st1.b	{ v2 }[5], [x11]
    275c:      	ldr	q5, [sp, #0x330]
    2760:      	add.2d	v5, v5, v14
    2764:      	add.2d	v5, v5, v3
    2768:      	tbz	w9, #0x6, 0x2668 <_llm_rows.packet_batch.blocks+0xa88>
    276c:      	fmov	x8, d5
    2770:      	st1.b	{ v2 }[6], [x8]
    2774:      	mov.d	x8, v5[1]
    2778:      	tbz	w9, #0x7, 0x2670 <_llm_rows.packet_batch.blocks+0xa90>
    277c:      	st1.b	{ v2 }[7], [x8]
    2780:      	fmov	w9, s13
    2784:      	ldr	q2, [sp, #0x430]
    2788:      	ldr	q3, [sp, #0x300]
    278c:      	add.2d	v3, v2, v3
    2790:      	tbnz	w9, #0x0, 0x2684 <_llm_rows.packet_batch.blocks+0xaa4>
    2794:      	movi.2d	v2, #0000000000000000
    2798:      	and	w10, w9, #0xff
    279c:      	str	q5, [sp, #0x2e0]
    27a0:      	tbz	w10, #0x1, 0x27ac <_llm_rows.packet_batch.blocks+0xbcc>
    27a4:      	mov.d	x9, v3[1]
    27a8:      	ld1.b	{ v2 }[1], [x9]
    27ac:      	ldr	q3, [sp, #0x450]
    27b0:      	ldr	q5, [sp, #0x320]
    27b4:      	add.2d	v3, v3, v5
    27b8:      	tbnz	w10, #0x2, 0x2874 <_llm_rows.packet_batch.blocks+0xc94>
    27bc:      	tbnz	w10, #0x3, 0x2880 <_llm_rows.packet_batch.blocks+0xca0>
    27c0:      	ldr	q3, [sp, #0x440]
    27c4:      	ldr	q5, [sp, #0x310]
    27c8:      	add.2d	v3, v3, v5
    27cc:      	tbnz	w10, #0x4, 0x2898 <_llm_rows.packet_batch.blocks+0xcb8>
    27d0:      	tbnz	w10, #0x5, 0x28a4 <_llm_rows.packet_batch.blocks+0xcc4>
    27d4:      	ldr	q3, [sp, #0x330]
    27d8:      	add.2d	v3, v14, v3
    27dc:      	tbnz	w10, #0x6, 0x28b8 <_llm_rows.packet_batch.blocks+0xcd8>
    27e0:      	tbz	w10, #0x7, 0x27ec <_llm_rows.packet_batch.blocks+0xc0c>
    27e4:      	mov.d	x9, v3[1]
    27e8:      	ld1.b	{ v2 }[7], [x9]
    27ec:      	fmov	w9, s13
    27f0:      	cmeq.8b	v2, v2, #0
    27f4:      	sshll.8h	v2, v2, #0x0
    27f8:      	sshll2.4s	v6, v2, #0x0
    27fc:      	stp	q2, q6, [sp, #0x50]
    2800:      	sshll.4s	v2, v2, #0x0
    2804:      	fmov	x10, d4
    2808:      	str	x10, [sp, #0x370]
    280c:      	add	x10, x28, x10
    2810:      	ldp	q3, q4, [x10]
    2814:      	and.16b	v5, v0, v4
    2818:      	and.16b	v3, v1, v3
    281c:      	mov	w10, #0xf2ca            ; =62154
    2820:      	movk	w10, #0xf149, lsl #16
    2824:      	dup.4s	v4, w10
    2828:      	mov.16b	v21, v2
    282c:      	bsl.16b	v21, v4, v3
    2830:      	mov.16b	v31, v6
    2834:      	bsl.16b	v31, v4, v5
    2838:      	str	q31, [x23, #0x1830]
    283c:      	str	q21, [x23, #0x1820]
    2840:      	mov	w10, #0x1               ; =1
    2844:      	dup.2d	v3, x10
    2848:      	ldr	q2, [sp, #0x300]
    284c:      	add.2d	v5, v2, v3
    2850:      	ldr	q2, [sp, #0x430]
    2854:      	str	q5, [sp, #0x2d0]
    2858:      	add.2d	v5, v2, v5
    285c:      	tbz	w9, #0x0, 0x28c8 <_llm_rows.packet_batch.blocks+0xce8>
    2860:      	fmov	x10, d5
    2864:      	ldr	b2, [x10]
    2868:      	and	w10, w9, #0xff
    286c:      	tbnz	w10, #0x1, 0x28d4 <_llm_rows.packet_batch.blocks+0xcf4>
    2870:      	b	0x28dc <_llm_rows.packet_batch.blocks+0xcfc>
    2874:      	fmov	x9, d3
    2878:      	ld1.b	{ v2 }[2], [x9]
    287c:      	tbz	w10, #0x3, 0x27c0 <_llm_rows.packet_batch.blocks+0xbe0>
    2880:      	mov.d	x9, v3[1]
    2884:      	ld1.b	{ v2 }[3], [x9]
    2888:      	ldr	q3, [sp, #0x440]
    288c:      	ldr	q5, [sp, #0x310]
    2890:      	add.2d	v3, v3, v5
    2894:      	tbz	w10, #0x4, 0x27d0 <_llm_rows.packet_batch.blocks+0xbf0>
    2898:      	fmov	x9, d3
    289c:      	ld1.b	{ v2 }[4], [x9]
    28a0:      	tbz	w10, #0x5, 0x27d4 <_llm_rows.packet_batch.blocks+0xbf4>
    28a4:      	mov.d	x9, v3[1]
    28a8:      	ld1.b	{ v2 }[5], [x9]
    28ac:      	ldr	q3, [sp, #0x330]
    28b0:      	add.2d	v3, v14, v3
    28b4:      	tbz	w10, #0x6, 0x27e0 <_llm_rows.packet_batch.blocks+0xc00>
    28b8:      	fmov	x9, d3
    28bc:      	ld1.b	{ v2 }[6], [x9]
    28c0:      	tbnz	w10, #0x7, 0x27e4 <_llm_rows.packet_batch.blocks+0xc04>
    28c4:      	b	0x27ec <_llm_rows.packet_batch.blocks+0xc0c>
    28c8:      	movi.2d	v2, #0000000000000000
    28cc:      	and	w10, w9, #0xff
    28d0:      	tbz	w10, #0x1, 0x28dc <_llm_rows.packet_batch.blocks+0xcfc>
    28d4:      	mov.d	x9, v5[1]
    28d8:      	ld1.b	{ v2 }[1], [x9]
    28dc:      	ldr	q5, [sp, #0x320]
    28e0:      	add.2d	v6, v5, v3
    28e4:      	ldr	q5, [sp, #0x450]
    28e8:      	str	q6, [sp, #0x2c0]
    28ec:      	add.2d	v5, v5, v6
    28f0:      	tbnz	w10, #0x2, 0x299c <_llm_rows.packet_batch.blocks+0xdbc>
    28f4:      	tbnz	w10, #0x3, 0x29a8 <_llm_rows.packet_batch.blocks+0xdc8>
    28f8:      	ldr	q5, [sp, #0x310]
    28fc:      	add.2d	v6, v5, v3
    2900:      	ldr	q5, [sp, #0x440]
    2904:      	str	q6, [sp, #0x2b0]
    2908:      	add.2d	v5, v5, v6
    290c:      	tbnz	w10, #0x4, 0x29c8 <_llm_rows.packet_batch.blocks+0xde8>
    2910:      	tbnz	w10, #0x5, 0x29d4 <_llm_rows.packet_batch.blocks+0xdf4>
    2914:      	ldr	q5, [sp, #0x330]
    2918:      	add.2d	v3, v5, v3
    291c:      	str	q3, [sp, #0x2a0]
    2920:      	add.2d	v3, v14, v3
    2924:      	tbnz	w10, #0x6, 0x29f0 <_llm_rows.packet_batch.blocks+0xe10>
    2928:      	tbz	w10, #0x7, 0x2934 <_llm_rows.packet_batch.blocks+0xd54>
    292c:      	mov.d	x9, v3[1]
    2930:      	ld1.b	{ v2 }[7], [x9]
    2934:      	fmov	w9, s13
    2938:      	cmeq.8b	v2, v2, #0
    293c:      	sshll.8h	v2, v2, #0x0
    2940:      	sshll2.4s	v3, v2, #0x0
    2944:      	sshll.4s	v2, v2, #0x0
    2948:      	ldr	q5, [sp, #0x71a0]
    294c:      	ldr	q6, [sp, #0x71b0]
    2950:      	and.16b	v6, v0, v6
    2954:      	and.16b	v5, v1, v5
    2958:      	bit.16b	v5, v4, v2
    295c:      	bit.16b	v6, v4, v3
    2960:      	str	q6, [x23, #0x1850]
    2964:      	str	q5, [x23, #0x1840]
    2968:      	mov	w10, #0x2               ; =2
    296c:      	dup.2d	v3, x10
    2970:      	ldr	q2, [sp, #0x300]
    2974:      	add.2d	v16, v2, v3
    2978:      	ldr	q2, [sp, #0x430]
    297c:      	str	q16, [sp, #0x290]
    2980:      	add.2d	v19, v2, v16
    2984:      	tbz	w9, #0x0, 0x2a00 <_llm_rows.packet_batch.blocks+0xe20>
    2988:      	fmov	x10, d19
    298c:      	ldr	b2, [x10]
    2990:      	and	w10, w9, #0xff
    2994:      	tbnz	w10, #0x1, 0x2a0c <_llm_rows.packet_batch.blocks+0xe2c>
    2998:      	b	0x2a14 <_llm_rows.packet_batch.blocks+0xe34>
    299c:      	fmov	x9, d5
    29a0:      	ld1.b	{ v2 }[2], [x9]
    29a4:      	tbz	w10, #0x3, 0x28f8 <_llm_rows.packet_batch.blocks+0xd18>
    29a8:      	mov.d	x9, v5[1]
    29ac:      	ld1.b	{ v2 }[3], [x9]
    29b0:      	ldr	q5, [sp, #0x310]
    29b4:      	add.2d	v6, v5, v3
    29b8:      	ldr	q5, [sp, #0x440]
    29bc:      	str	q6, [sp, #0x2b0]
    29c0:      	add.2d	v5, v5, v6
    29c4:      	tbz	w10, #0x4, 0x2910 <_llm_rows.packet_batch.blocks+0xd30>
    29c8:      	fmov	x9, d5
    29cc:      	ld1.b	{ v2 }[4], [x9]
    29d0:      	tbz	w10, #0x5, 0x2914 <_llm_rows.packet_batch.blocks+0xd34>
    29d4:      	mov.d	x9, v5[1]
    29d8:      	ld1.b	{ v2 }[5], [x9]
    29dc:      	ldr	q5, [sp, #0x330]
    29e0:      	add.2d	v3, v5, v3
    29e4:      	str	q3, [sp, #0x2a0]
    29e8:      	add.2d	v3, v14, v3
    29ec:      	tbz	w10, #0x6, 0x2928 <_llm_rows.packet_batch.blocks+0xd48>
    29f0:      	fmov	x9, d3
    29f4:      	ld1.b	{ v2 }[6], [x9]
    29f8:      	tbnz	w10, #0x7, 0x292c <_llm_rows.packet_batch.blocks+0xd4c>
    29fc:      	b	0x2934 <_llm_rows.packet_batch.blocks+0xd54>
    2a00:      	movi.2d	v2, #0000000000000000
    2a04:      	and	w10, w9, #0xff
    2a08:      	tbz	w10, #0x1, 0x2a14 <_llm_rows.packet_batch.blocks+0xe34>
    2a0c:      	mov.d	x9, v19[1]
    2a10:      	ld1.b	{ v2 }[1], [x9]
    2a14:      	ldr	q16, [sp, #0x320]
    2a18:      	add.2d	v17, v16, v3
    2a1c:      	ldr	q16, [sp, #0x450]
    2a20:      	str	q17, [sp, #0x280]
    2a24:      	add.2d	v19, v16, v17
    2a28:      	tbnz	w10, #0x2, 0x2ad8 <_llm_rows.packet_batch.blocks+0xef8>
    2a2c:      	tbnz	w10, #0x3, 0x2ae4 <_llm_rows.packet_batch.blocks+0xf04>
    2a30:      	ldr	q16, [sp, #0x310]
    2a34:      	add.2d	v17, v16, v3
    2a38:      	ldr	q16, [sp, #0x440]
    2a3c:      	str	q17, [sp, #0x270]
    2a40:      	add.2d	v19, v16, v17
    2a44:      	tbnz	w10, #0x4, 0x2b04 <_llm_rows.packet_batch.blocks+0xf24>
    2a48:      	tbnz	w10, #0x5, 0x2b10 <_llm_rows.packet_batch.blocks+0xf30>
    2a4c:      	ldr	q16, [sp, #0x330]
    2a50:      	add.2d	v3, v16, v3
    2a54:      	str	q3, [sp, #0x260]
    2a58:      	add.2d	v3, v14, v3
    2a5c:      	tbnz	w10, #0x6, 0x2b2c <_llm_rows.packet_batch.blocks+0xf4c>
    2a60:      	tbz	w10, #0x7, 0x2a6c <_llm_rows.packet_batch.blocks+0xe8c>
    2a64:      	mov.d	x9, v3[1]
    2a68:      	ld1.b	{ v2 }[7], [x9]
    2a6c:      	fmov	w9, s13
    2a70:      	cmeq.8b	v2, v2, #0
    2a74:      	sshll.8h	v2, v2, #0x0
    2a78:      	sshll2.4s	v3, v2, #0x0
    2a7c:      	sshll.4s	v2, v2, #0x0
    2a80:      	ldr	q19, [sp, #0x71c0]
    2a84:      	ldr	q22, [sp, #0x71d0]
    2a88:      	and.16b	v22, v0, v22
    2a8c:      	and.16b	v19, v1, v19
    2a90:      	bsl.16b	v2, v4, v19
    2a94:      	mov.16b	v23, v3
    2a98:      	bsl.16b	v23, v4, v22
    2a9c:      	str	q23, [x23, #0x1870]
    2aa0:      	str	q2, [x23, #0x1860]
    2aa4:      	mov	w10, #0x3               ; =3
    2aa8:      	dup.2d	v19, x10
    2aac:      	ldr	q3, [sp, #0x300]
    2ab0:      	add.2d	v16, v3, v19
    2ab4:      	ldr	q3, [sp, #0x430]
    2ab8:      	str	q16, [sp, #0x250]
    2abc:      	add.2d	v22, v3, v16
    2ac0:      	tbz	w9, #0x0, 0x2b3c <_llm_rows.packet_batch.blocks+0xf5c>
    2ac4:      	fmov	x10, d22
    2ac8:      	ldr	b3, [x10]
    2acc:      	and	w10, w9, #0xff
    2ad0:      	tbnz	w10, #0x1, 0x2b48 <_llm_rows.packet_batch.blocks+0xf68>
    2ad4:      	b	0x2b50 <_llm_rows.packet_batch.blocks+0xf70>
    2ad8:      	fmov	x9, d19
    2adc:      	ld1.b	{ v2 }[2], [x9]
    2ae0:      	tbz	w10, #0x3, 0x2a30 <_llm_rows.packet_batch.blocks+0xe50>
    2ae4:      	mov.d	x9, v19[1]
    2ae8:      	ld1.b	{ v2 }[3], [x9]
    2aec:      	ldr	q16, [sp, #0x310]
    2af0:      	add.2d	v17, v16, v3
    2af4:      	ldr	q16, [sp, #0x440]
    2af8:      	str	q17, [sp, #0x270]
    2afc:      	add.2d	v19, v16, v17
    2b00:      	tbz	w10, #0x4, 0x2a48 <_llm_rows.packet_batch.blocks+0xe68>
    2b04:      	fmov	x9, d19
    2b08:      	ld1.b	{ v2 }[4], [x9]
    2b0c:      	tbz	w10, #0x5, 0x2a4c <_llm_rows.packet_batch.blocks+0xe6c>
    2b10:      	mov.d	x9, v19[1]
    2b14:      	ld1.b	{ v2 }[5], [x9]
    2b18:      	ldr	q16, [sp, #0x330]
    2b1c:      	add.2d	v3, v16, v3
    2b20:      	str	q3, [sp, #0x260]
    2b24:      	add.2d	v3, v14, v3
    2b28:      	tbz	w10, #0x6, 0x2a60 <_llm_rows.packet_batch.blocks+0xe80>
    2b2c:      	fmov	x9, d3
    2b30:      	ld1.b	{ v2 }[6], [x9]
    2b34:      	tbnz	w10, #0x7, 0x2a64 <_llm_rows.packet_batch.blocks+0xe84>
    2b38:      	b	0x2a6c <_llm_rows.packet_batch.blocks+0xe8c>
    2b3c:      	movi.2d	v3, #0000000000000000
    2b40:      	and	w10, w9, #0xff
    2b44:      	tbz	w10, #0x1, 0x2b50 <_llm_rows.packet_batch.blocks+0xf70>
    2b48:      	mov.d	x9, v22[1]
    2b4c:      	ld1.b	{ v3 }[1], [x9]
    2b50:      	ldr	q16, [sp, #0x320]
    2b54:      	add.2d	v17, v16, v19
    2b58:      	ldr	q16, [sp, #0x450]
    2b5c:      	str	q17, [sp, #0x240]
    2b60:      	add.2d	v22, v16, v17
    2b64:      	tbnz	w10, #0x2, 0x3184 <_llm_rows.packet_batch.blocks+0x15a4>
    2b68:      	tbnz	w10, #0x3, 0x3190 <_llm_rows.packet_batch.blocks+0x15b0>
    2b6c:      	ldr	q16, [sp, #0x310]
    2b70:      	add.2d	v17, v16, v19
    2b74:      	ldr	q16, [sp, #0x440]
    2b78:      	str	q17, [sp, #0x230]
    2b7c:      	add.2d	v22, v16, v17
    2b80:      	tbnz	w10, #0x4, 0x31b0 <_llm_rows.packet_batch.blocks+0x15d0>
    2b84:      	tbnz	w10, #0x5, 0x31bc <_llm_rows.packet_batch.blocks+0x15dc>
    2b88:      	ldr	q16, [sp, #0x330]
    2b8c:      	add.2d	v16, v16, v19
    2b90:      	str	q16, [sp, #0x220]
    2b94:      	add.2d	v19, v14, v16
    2b98:      	tbnz	w10, #0x6, 0x31d8 <_llm_rows.packet_batch.blocks+0x15f8>
    2b9c:      	tbz	w10, #0x7, 0x2ba8 <_llm_rows.packet_batch.blocks+0xfc8>
    2ba0:      	mov.d	x9, v19[1]
    2ba4:      	ld1.b	{ v3 }[7], [x9]
    2ba8:      	sshll.2d	v19, v1, #0x0
    2bac:      	sshll.2d	v22, v0, #0x0
    2bb0:      	cmeq.8b	v3, v3, #0
    2bb4:      	sshll.8h	v3, v3, #0x0
    2bb8:      	sshll2.4s	v24, v3, #0x0
    2bbc:      	sshll.4s	v3, v3, #0x0
    2bc0:      	ldr	q25, [sp, #0x71e0]
    2bc4:      	ldr	q26, [sp, #0x71f0]
    2bc8:      	and.16b	v26, v0, v26
    2bcc:      	and.16b	v25, v1, v25
    2bd0:      	bsl.16b	v3, v4, v25
    2bd4:      	bsl.16b	v24, v4, v26
    2bd8:      	str	q24, [x23, #0x1890]
    2bdc:      	str	q3, [x23, #0x1880]
    2be0:      	dup.2d	v25, x3
    2be4:      	and.16b	v16, v12, v25
    2be8:      	and.16b	v10, v7, v25
    2bec:      	and.16b	v11, v22, v25
    2bf0:      	and.16b	v9, v19, v25
    2bf4:      	fmov	x10, d9
    2bf8:      	and.16b	v19, v0, v24
    2bfc:      	and.16b	v22, v1, v3
    2c00:      	and.16b	v24, v0, v23
    2c04:      	and.16b	v23, v1, v2
    2c08:      	and.16b	v29, v0, v6
    2c0c:      	and.16b	v30, v1, v5
    2c10:      	and.16b	v31, v0, v31
    2c14:      	mov	x15, x10
    2c18:      	and.16b	v8, v1, v21
    2c1c:      	str	q9, [sp, #0x340]
    2c20:      	str	q10, [sp, #0x410]
    2c24:      	str	q11, [sp, #0x400]
    2c28:      	str	q16, [sp, #0x420]
    2c2c:      	mov.16b	v21, v16
    2c30:      	b	0x2cf4 <_llm_rows.packet_batch.blocks+0x1114>
    2c34:      	fmaxnm.4s	v6, v31, v6
    2c38:      	fmaxnm.4s	v5, v8, v5
    2c3c:      	fmaxnm.4s	v3, v29, v26
    2c40:      	fmaxnm.4s	v25, v30, v25
    2c44:      	fmaxnm.4s	v26, v24, v27
    2c48:      	fmaxnm.4s	v2, v23, v2
    2c4c:      	sshll.2d	v27, v1, #0x0
    2c50:      	sshll.2d	v12, v0, #0x0
    2c54:      	cmeq.8b	v28, v28, #0
    2c58:      	sshll.8h	v28, v28, #0x0
    2c5c:      	sshll2.4s	v7, v28, #0x0
    2c60:      	sshll.4s	v28, v28, #0x0
    2c64:      	add	x9, x15, #0x60
    2c68:      	add	x12, x28, x9
    2c6c:      	ldp	q16, q17, [x12]
    2c70:      	and.16b	v17, v0, v17
    2c74:      	and.16b	v16, v1, v16
    2c78:      	bit.16b	v16, v4, v28
    2c7c:      	bsl.16b	v7, v4, v17
    2c80:      	add	x9, x25, x9
    2c84:      	ldp	q17, q28, [x9]
    2c88:      	bit.16b	v28, v7, v0
    2c8c:      	bit.16b	v17, v16, v1
    2c90:      	stp	q17, q28, [x9]
    2c94:      	fmaxnm.4s	v16, v22, v16
    2c98:      	fmaxnm.4s	v7, v19, v7
    2c9c:      	dup.2d	v17, x3
    2ca0:      	ldr	q28, [sp, #0x350]
    2ca4:      	and.16b	v28, v28, v17
    2ca8:      	add.2d	v21, v21, v28
    2cac:      	ldr	q28, [sp, #0x2f0]
    2cb0:      	and.16b	v28, v28, v17
    2cb4:      	add.2d	v10, v10, v28
    2cb8:      	and.16b	v28, v12, v17
    2cbc:      	add.2d	v11, v11, v28
    2cc0:      	and.16b	v17, v27, v17
    2cc4:      	add.2d	v9, v9, v17
    2cc8:      	bit.16b	v31, v6, v0
    2ccc:      	bit.16b	v8, v5, v1
    2cd0:      	bit.16b	v29, v3, v0
    2cd4:      	bit.16b	v30, v25, v1
    2cd8:      	bit.16b	v24, v26, v0
    2cdc:      	bit.16b	v23, v2, v1
    2ce0:      	bit.16b	v19, v7, v0
    2ce4:      	bit.16b	v22, v16, v1
    2ce8:      	fmov	x15, d9
    2cec:      	cmp	x15, #0xc0
    2cf0:      	b.ge	0x3164 <_llm_rows.packet_batch.blocks+0x1584>
    2cf4:      	fmov	w9, s13
    2cf8:      	ldr	q2, [sp, #0x300]
    2cfc:      	add.2d	v2, v9, v2
    2d00:      	ldr	q3, [sp, #0x430]
    2d04:      	add.2d	v3, v3, v2
    2d08:      	tbz	w9, #0x0, 0x2d20 <_llm_rows.packet_batch.blocks+0x1140>
    2d0c:      	fmov	x12, d3
    2d10:      	ldr	b2, [x12]
    2d14:      	and	w12, w9, #0xff
    2d18:      	tbnz	w12, #0x1, 0x2d2c <_llm_rows.packet_batch.blocks+0x114c>
    2d1c:      	b	0x2d34 <_llm_rows.packet_batch.blocks+0x1154>
    2d20:      	movi.2d	v2, #0000000000000000
    2d24:      	and	w12, w9, #0xff
    2d28:      	tbz	w12, #0x1, 0x2d34 <_llm_rows.packet_batch.blocks+0x1154>
    2d2c:      	mov.d	x9, v3[1]
    2d30:      	ld1.b	{ v2 }[1], [x9]
    2d34:      	ldr	q3, [sp, #0x320]
    2d38:      	add.2d	v3, v10, v3
    2d3c:      	ldr	q5, [sp, #0x450]
    2d40:      	add.2d	v3, v5, v3
    2d44:      	tbnz	w12, #0x2, 0x2dec <_llm_rows.packet_batch.blocks+0x120c>
    2d48:      	tbnz	w12, #0x3, 0x2df8 <_llm_rows.packet_batch.blocks+0x1218>
    2d4c:      	ldr	q3, [sp, #0x310]
    2d50:      	add.2d	v3, v11, v3
    2d54:      	ldr	q5, [sp, #0x440]
    2d58:      	add.2d	v3, v5, v3
    2d5c:      	tbnz	w12, #0x4, 0x2e14 <_llm_rows.packet_batch.blocks+0x1234>
    2d60:      	tbnz	w12, #0x5, 0x2e20 <_llm_rows.packet_batch.blocks+0x1240>
    2d64:      	ldr	q3, [sp, #0x330]
    2d68:      	add.2d	v3, v21, v3
    2d6c:      	add.2d	v3, v14, v3
    2d70:      	tbnz	w12, #0x6, 0x2e38 <_llm_rows.packet_batch.blocks+0x1258>
    2d74:      	tbz	w12, #0x7, 0x2d80 <_llm_rows.packet_batch.blocks+0x11a0>
    2d78:      	mov.d	x9, v3[1]
    2d7c:      	ld1.b	{ v2 }[7], [x9]
    2d80:      	fmov	w9, s13
    2d84:      	cmeq.8b	v2, v2, #0
    2d88:      	sshll.8h	v2, v2, #0x0
    2d8c:      	sshll2.4s	v3, v2, #0x0
    2d90:      	sshll.4s	v2, v2, #0x0
    2d94:      	lsl	x12, x15, #5
    2d98:      	add	x15, x28, x12
    2d9c:      	ldp	q5, q6, [x15]
    2da0:      	and.16b	v6, v0, v6
    2da4:      	and.16b	v5, v1, v5
    2da8:      	bit.16b	v5, v4, v2
    2dac:      	bit.16b	v6, v4, v3
    2db0:      	add	x12, x25, x12
    2db4:      	ldp	q2, q3, [x12]
    2db8:      	bit.16b	v3, v6, v0
    2dbc:      	bit.16b	v2, v5, v1
    2dc0:      	stp	q2, q3, [x12]
    2dc4:      	ldr	q2, [sp, #0x2d0]
    2dc8:      	add.2d	v2, v9, v2
    2dcc:      	ldr	q3, [sp, #0x430]
    2dd0:      	add.2d	v3, v3, v2
    2dd4:      	tbz	w9, #0x0, 0x2e48 <_llm_rows.packet_batch.blocks+0x1268>
    2dd8:      	fmov	x12, d3
    2ddc:      	ldr	b2, [x12]
    2de0:      	and	w12, w9, #0xff
    2de4:      	tbnz	w12, #0x1, 0x2e54 <_llm_rows.packet_batch.blocks+0x1274>
    2de8:      	b	0x2e5c <_llm_rows.packet_batch.blocks+0x127c>
    2dec:      	fmov	x9, d3
    2df0:      	ld1.b	{ v2 }[2], [x9]
    2df4:      	tbz	w12, #0x3, 0x2d4c <_llm_rows.packet_batch.blocks+0x116c>
    2df8:      	mov.d	x9, v3[1]
    2dfc:      	ld1.b	{ v2 }[3], [x9]
    2e00:      	ldr	q3, [sp, #0x310]
    2e04:      	add.2d	v3, v11, v3
    2e08:      	ldr	q5, [sp, #0x440]
    2e0c:      	add.2d	v3, v5, v3
    2e10:      	tbz	w12, #0x4, 0x2d60 <_llm_rows.packet_batch.blocks+0x1180>
    2e14:      	fmov	x9, d3
    2e18:      	ld1.b	{ v2 }[4], [x9]
    2e1c:      	tbz	w12, #0x5, 0x2d64 <_llm_rows.packet_batch.blocks+0x1184>
    2e20:      	mov.d	x9, v3[1]
    2e24:      	ld1.b	{ v2 }[5], [x9]
    2e28:      	ldr	q3, [sp, #0x330]
    2e2c:      	add.2d	v3, v21, v3
    2e30:      	add.2d	v3, v14, v3
    2e34:      	tbz	w12, #0x6, 0x2d74 <_llm_rows.packet_batch.blocks+0x1194>
    2e38:      	fmov	x9, d3
    2e3c:      	ld1.b	{ v2 }[6], [x9]
    2e40:      	tbnz	w12, #0x7, 0x2d78 <_llm_rows.packet_batch.blocks+0x1198>
    2e44:      	b	0x2d80 <_llm_rows.packet_batch.blocks+0x11a0>
    2e48:      	movi.2d	v2, #0000000000000000
    2e4c:      	and	w12, w9, #0xff
    2e50:      	tbz	w12, #0x1, 0x2e5c <_llm_rows.packet_batch.blocks+0x127c>
    2e54:      	mov.d	x9, v3[1]
    2e58:      	ld1.b	{ v2 }[1], [x9]
    2e5c:      	ldr	q3, [sp, #0x2c0]
    2e60:      	add.2d	v3, v10, v3
    2e64:      	ldr	q7, [sp, #0x450]
    2e68:      	add.2d	v3, v7, v3
    2e6c:      	tbnz	w12, #0x2, 0x2f1c <_llm_rows.packet_batch.blocks+0x133c>
    2e70:      	tbnz	w12, #0x3, 0x2f28 <_llm_rows.packet_batch.blocks+0x1348>
    2e74:      	ldr	q3, [sp, #0x2b0]
    2e78:      	add.2d	v3, v11, v3
    2e7c:      	ldr	q7, [sp, #0x440]
    2e80:      	add.2d	v3, v7, v3
    2e84:      	tbnz	w12, #0x4, 0x2f44 <_llm_rows.packet_batch.blocks+0x1364>
    2e88:      	tbnz	w12, #0x5, 0x2f50 <_llm_rows.packet_batch.blocks+0x1370>
    2e8c:      	ldr	q3, [sp, #0x2a0]
    2e90:      	add.2d	v3, v21, v3
    2e94:      	add.2d	v3, v14, v3
    2e98:      	tbnz	w12, #0x6, 0x2f68 <_llm_rows.packet_batch.blocks+0x1388>
    2e9c:      	tbz	w12, #0x7, 0x2ea8 <_llm_rows.packet_batch.blocks+0x12c8>
    2ea0:      	mov.d	x9, v3[1]
    2ea4:      	ld1.b	{ v2 }[7], [x9]
    2ea8:      	fmov	w9, s13
    2eac:      	cmeq.8b	v2, v2, #0
    2eb0:      	sshll.8h	v2, v2, #0x0
    2eb4:      	sshll2.4s	v3, v2, #0x0
    2eb8:      	sshll.4s	v2, v2, #0x0
    2ebc:      	fmov	x12, d9
    2ec0:      	lsl	x15, x12, #5
    2ec4:      	add	x12, x15, #0x20
    2ec8:      	add	x16, x28, x12
    2ecc:      	ldp	q25, q26, [x16]
    2ed0:      	and.16b	v26, v0, v26
    2ed4:      	and.16b	v25, v1, v25
    2ed8:      	bit.16b	v25, v4, v2
    2edc:      	bit.16b	v26, v4, v3
    2ee0:      	add	x12, x25, x12
    2ee4:      	ldp	q2, q3, [x12]
    2ee8:      	bit.16b	v3, v26, v0
    2eec:      	bit.16b	v2, v25, v1
    2ef0:      	stp	q2, q3, [x12]
    2ef4:      	ldr	q2, [sp, #0x290]
    2ef8:      	add.2d	v2, v9, v2
    2efc:      	ldr	q3, [sp, #0x430]
    2f00:      	add.2d	v3, v3, v2
    2f04:      	tbz	w9, #0x0, 0x2f78 <_llm_rows.packet_batch.blocks+0x1398>
    2f08:      	fmov	x12, d3
    2f0c:      	ldr	b2, [x12]
    2f10:      	and	w12, w9, #0xff
    2f14:      	tbnz	w12, #0x1, 0x2f84 <_llm_rows.packet_batch.blocks+0x13a4>
    2f18:      	b	0x2f8c <_llm_rows.packet_batch.blocks+0x13ac>
    2f1c:      	fmov	x9, d3
    2f20:      	ld1.b	{ v2 }[2], [x9]
    2f24:      	tbz	w12, #0x3, 0x2e74 <_llm_rows.packet_batch.blocks+0x1294>
    2f28:      	mov.d	x9, v3[1]
    2f2c:      	ld1.b	{ v2 }[3], [x9]
    2f30:      	ldr	q3, [sp, #0x2b0]
    2f34:      	add.2d	v3, v11, v3
    2f38:      	ldr	q7, [sp, #0x440]
    2f3c:      	add.2d	v3, v7, v3
    2f40:      	tbz	w12, #0x4, 0x2e88 <_llm_rows.packet_batch.blocks+0x12a8>
    2f44:      	fmov	x9, d3
    2f48:      	ld1.b	{ v2 }[4], [x9]
    2f4c:      	tbz	w12, #0x5, 0x2e8c <_llm_rows.packet_batch.blocks+0x12ac>
    2f50:      	mov.d	x9, v3[1]
    2f54:      	ld1.b	{ v2 }[5], [x9]
    2f58:      	ldr	q3, [sp, #0x2a0]
    2f5c:      	add.2d	v3, v21, v3
    2f60:      	add.2d	v3, v14, v3
    2f64:      	tbz	w12, #0x6, 0x2e9c <_llm_rows.packet_batch.blocks+0x12bc>
    2f68:      	fmov	x9, d3
    2f6c:      	ld1.b	{ v2 }[6], [x9]
    2f70:      	tbnz	w12, #0x7, 0x2ea0 <_llm_rows.packet_batch.blocks+0x12c0>
    2f74:      	b	0x2ea8 <_llm_rows.packet_batch.blocks+0x12c8>
    2f78:      	movi.2d	v2, #0000000000000000
    2f7c:      	and	w12, w9, #0xff
    2f80:      	tbz	w12, #0x1, 0x2f8c <_llm_rows.packet_batch.blocks+0x13ac>
    2f84:      	mov.d	x9, v3[1]
    2f88:      	ld1.b	{ v2 }[1], [x9]
    2f8c:      	ldr	q3, [sp, #0x280]
    2f90:      	add.2d	v3, v10, v3
    2f94:      	ldr	q7, [sp, #0x450]
    2f98:      	add.2d	v3, v7, v3
    2f9c:      	tbnz	w12, #0x2, 0x3048 <_llm_rows.packet_batch.blocks+0x1468>
    2fa0:      	tbnz	w12, #0x3, 0x3054 <_llm_rows.packet_batch.blocks+0x1474>
    2fa4:      	ldr	q3, [sp, #0x270]
    2fa8:      	add.2d	v3, v11, v3
    2fac:      	ldr	q7, [sp, #0x440]
    2fb0:      	add.2d	v3, v7, v3
    2fb4:      	tbnz	w12, #0x4, 0x3070 <_llm_rows.packet_batch.blocks+0x1490>
    2fb8:      	tbnz	w12, #0x5, 0x307c <_llm_rows.packet_batch.blocks+0x149c>
    2fbc:      	ldr	q3, [sp, #0x260]
    2fc0:      	add.2d	v3, v21, v3
    2fc4:      	add.2d	v3, v14, v3
    2fc8:      	tbnz	w12, #0x6, 0x3094 <_llm_rows.packet_batch.blocks+0x14b4>
    2fcc:      	tbz	w12, #0x7, 0x2fd8 <_llm_rows.packet_batch.blocks+0x13f8>
    2fd0:      	mov.d	x9, v3[1]
    2fd4:      	ld1.b	{ v2 }[7], [x9]
    2fd8:      	fmov	w9, s13
    2fdc:      	cmeq.8b	v2, v2, #0
    2fe0:      	sshll.8h	v2, v2, #0x0
    2fe4:      	sshll2.4s	v3, v2, #0x0
    2fe8:      	sshll.4s	v2, v2, #0x0
    2fec:      	add	x12, x15, #0x40
    2ff0:      	add	x16, x28, x12
    2ff4:      	ldp	q27, q28, [x16]
    2ff8:      	and.16b	v28, v0, v28
    2ffc:      	and.16b	v27, v1, v27
    3000:      	bsl.16b	v2, v4, v27
    3004:      	mov.16b	v27, v3
    3008:      	bsl.16b	v27, v4, v28
    300c:      	add	x12, x25, x12
    3010:      	ldp	q3, q28, [x12]
    3014:      	bit.16b	v28, v27, v0
    3018:      	bit.16b	v3, v2, v1
    301c:      	stp	q3, q28, [x12]
    3020:      	ldr	q3, [sp, #0x250]
    3024:      	add.2d	v3, v9, v3
    3028:      	ldr	q7, [sp, #0x430]
    302c:      	add.2d	v3, v7, v3
    3030:      	tbz	w9, #0x0, 0x30a4 <_llm_rows.packet_batch.blocks+0x14c4>
    3034:      	fmov	x12, d3
    3038:      	ldr	b28, [x12]
    303c:      	and	w12, w9, #0xff
    3040:      	tbnz	w12, #0x1, 0x30b0 <_llm_rows.packet_batch.blocks+0x14d0>
    3044:      	b	0x30b8 <_llm_rows.packet_batch.blocks+0x14d8>
    3048:      	fmov	x9, d3
    304c:      	ld1.b	{ v2 }[2], [x9]
    3050:      	tbz	w12, #0x3, 0x2fa4 <_llm_rows.packet_batch.blocks+0x13c4>
    3054:      	mov.d	x9, v3[1]
    3058:      	ld1.b	{ v2 }[3], [x9]
    305c:      	ldr	q3, [sp, #0x270]
    3060:      	add.2d	v3, v11, v3
    3064:      	ldr	q7, [sp, #0x440]
    3068:      	add.2d	v3, v7, v3
    306c:      	tbz	w12, #0x4, 0x2fb8 <_llm_rows.packet_batch.blocks+0x13d8>
    3070:      	fmov	x9, d3
    3074:      	ld1.b	{ v2 }[4], [x9]
    3078:      	tbz	w12, #0x5, 0x2fbc <_llm_rows.packet_batch.blocks+0x13dc>
    307c:      	mov.d	x9, v3[1]
    3080:      	ld1.b	{ v2 }[5], [x9]
    3084:      	ldr	q3, [sp, #0x260]
    3088:      	add.2d	v3, v21, v3
    308c:      	add.2d	v3, v14, v3
    3090:      	tbz	w12, #0x6, 0x2fcc <_llm_rows.packet_batch.blocks+0x13ec>
    3094:      	fmov	x9, d3
    3098:      	ld1.b	{ v2 }[6], [x9]
    309c:      	tbnz	w12, #0x7, 0x2fd0 <_llm_rows.packet_batch.blocks+0x13f0>
    30a0:      	b	0x2fd8 <_llm_rows.packet_batch.blocks+0x13f8>
    30a4:      	movi.2d	v28, #0000000000000000
    30a8:      	and	w12, w9, #0xff
    30ac:      	tbz	w12, #0x1, 0x30b8 <_llm_rows.packet_batch.blocks+0x14d8>
    30b0:      	mov.d	x9, v3[1]
    30b4:      	ld1.b	{ v28 }[1], [x9]
    30b8:      	ldr	q3, [sp, #0x240]
    30bc:      	add.2d	v3, v10, v3
    30c0:      	ldr	q7, [sp, #0x450]
    30c4:      	add.2d	v3, v7, v3
    30c8:      	tbnz	w12, #0x2, 0x3100 <_llm_rows.packet_batch.blocks+0x1520>
    30cc:      	tbnz	w12, #0x3, 0x310c <_llm_rows.packet_batch.blocks+0x152c>
    30d0:      	ldr	q3, [sp, #0x230]
    30d4:      	add.2d	v3, v11, v3
    30d8:      	ldr	q7, [sp, #0x440]
    30dc:      	add.2d	v3, v7, v3
    30e0:      	tbnz	w12, #0x4, 0x3128 <_llm_rows.packet_batch.blocks+0x1548>
    30e4:      	tbnz	w12, #0x5, 0x3134 <_llm_rows.packet_batch.blocks+0x1554>
    30e8:      	ldr	q3, [sp, #0x220]
    30ec:      	add.2d	v3, v21, v3
    30f0:      	add.2d	v3, v14, v3
    30f4:      	tbnz	w12, #0x6, 0x314c <_llm_rows.packet_batch.blocks+0x156c>
    30f8:      	tbz	w12, #0x7, 0x2c34 <_llm_rows.packet_batch.blocks+0x1054>
    30fc:      	b	0x3158 <_llm_rows.packet_batch.blocks+0x1578>
    3100:      	fmov	x9, d3
    3104:      	ld1.b	{ v28 }[2], [x9]
    3108:      	tbz	w12, #0x3, 0x30d0 <_llm_rows.packet_batch.blocks+0x14f0>
    310c:      	mov.d	x9, v3[1]
    3110:      	ld1.b	{ v28 }[3], [x9]
    3114:      	ldr	q3, [sp, #0x230]
    3118:      	add.2d	v3, v11, v3
    311c:      	ldr	q7, [sp, #0x440]
    3120:      	add.2d	v3, v7, v3
    3124:      	tbz	w12, #0x4, 0x30e4 <_llm_rows.packet_batch.blocks+0x1504>
    3128:      	fmov	x9, d3
    312c:      	ld1.b	{ v28 }[4], [x9]
    3130:      	tbz	w12, #0x5, 0x30e8 <_llm_rows.packet_batch.blocks+0x1508>
    3134:      	mov.d	x9, v3[1]
    3138:      	ld1.b	{ v28 }[5], [x9]
    313c:      	ldr	q3, [sp, #0x220]
    3140:      	add.2d	v3, v21, v3
    3144:      	add.2d	v3, v14, v3
    3148:      	tbz	w12, #0x6, 0x30f8 <_llm_rows.packet_batch.blocks+0x1518>
    314c:      	fmov	x9, d3
    3150:      	ld1.b	{ v28 }[6], [x9]
    3154:      	tbz	w12, #0x7, 0x2c34 <_llm_rows.packet_batch.blocks+0x1054>
    3158:      	mov.d	x9, v3[1]
    315c:      	ld1.b	{ v28 }[7], [x9]
    3160:      	b	0x2c34 <_llm_rows.packet_batch.blocks+0x1054>
    3164:      	ldr	d2, [sp, #0x198]
    3168:      	fmov	w15, s2
    316c:      	tbz	w15, #0x0, 0x31e8 <_llm_rows.packet_batch.blocks+0x1608>
    3170:      	fmov	x9, d20
    3174:      	ldr	b2, [x9]
    3178:      	ldr	q10, [sp, #0x350]
    317c:      	tbnz	w15, #0x1, 0x31f4 <_llm_rows.packet_batch.blocks+0x1614>
    3180:      	b	0x31f8 <_llm_rows.packet_batch.blocks+0x1618>
    3184:      	fmov	x9, d22
    3188:      	ld1.b	{ v3 }[2], [x9]
    318c:      	tbz	w10, #0x3, 0x2b6c <_llm_rows.packet_batch.blocks+0xf8c>
    3190:      	mov.d	x9, v22[1]
    3194:      	ld1.b	{ v3 }[3], [x9]
    3198:      	ldr	q16, [sp, #0x310]
    319c:      	add.2d	v17, v16, v19
    31a0:      	ldr	q16, [sp, #0x440]
    31a4:      	str	q17, [sp, #0x230]
    31a8:      	add.2d	v22, v16, v17
    31ac:      	tbz	w10, #0x4, 0x2b84 <_llm_rows.packet_batch.blocks+0xfa4>
    31b0:      	fmov	x9, d22
    31b4:      	ld1.b	{ v3 }[4], [x9]
    31b8:      	tbz	w10, #0x5, 0x2b88 <_llm_rows.packet_batch.blocks+0xfa8>
    31bc:      	mov.d	x9, v22[1]
    31c0:      	ld1.b	{ v3 }[5], [x9]
    31c4:      	ldr	q16, [sp, #0x330]
    31c8:      	add.2d	v16, v16, v19
    31cc:      	str	q16, [sp, #0x220]
    31d0:      	add.2d	v19, v14, v16
    31d4:      	tbz	w10, #0x6, 0x2b9c <_llm_rows.packet_batch.blocks+0xfbc>
    31d8:      	fmov	x9, d19
    31dc:      	ld1.b	{ v3 }[6], [x9]
    31e0:      	tbnz	w10, #0x7, 0x2ba0 <_llm_rows.packet_batch.blocks+0xfc0>
    31e4:      	b	0x2ba8 <_llm_rows.packet_batch.blocks+0xfc8>
    31e8:      	movi.2d	v2, #0000000000000000
    31ec:      	ldr	q10, [sp, #0x350]
    31f0:      	tbz	w15, #0x1, 0x31f8 <_llm_rows.packet_batch.blocks+0x1618>
    31f4:      	ld1.b	{ v2 }[1], [x14]
    31f8:      	tbnz	w15, #0x2, 0x3aa0 <_llm_rows.packet_batch.blocks+0x1ec0>
    31fc:      	tbnz	w15, #0x3, 0x3aac <_llm_rows.packet_batch.blocks+0x1ecc>
    3200:      	tbnz	w15, #0x4, 0x3ab4 <_llm_rows.packet_batch.blocks+0x1ed4>
    3204:      	tbnz	w15, #0x5, 0x3ac4 <_llm_rows.packet_batch.blocks+0x1ee4>
    3208:      	tbz	w15, #0x6, 0x3218 <_llm_rows.packet_batch.blocks+0x1638>
    320c:      	ldr	q3, [sp, #0x2e0]
    3210:      	fmov	x9, d3
    3214:      	ld1.b	{ v2 }[6], [x9]
    3218:      	sshll.2d	v11, v1, #0x0
    321c:      	movi	d3, #0xffffffffffff0000
    3220:      	ldr	q7, [sp, #0x1a0]
    3224:      	and.8b	v17, v7, v3
    3228:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1420>
    322c:      	ldr	q3, [x9]
    3230:      	and.16b	v9, v11, v3
    3234:      	str	x4, [sp, #0x158]
    3238:      	str	x5, [sp, #0xf8]
    323c:      	str	q14, [sp, #0x360]
    3240:      	str	w22, [sp, #0xcc]
    3244:      	tbz	w15, #0x7, 0x324c <_llm_rows.packet_batch.blocks+0x166c>
    3248:      	ld1.b	{ v2 }[7], [x8]
    324c:      	cmeq.8b	v2, v2, #0
    3250:      	sshll.8h	v2, v2, #0x0
    3254:      	sshll2.4s	v3, v2, #0x0
    3258:      	stp	q3, q2, [sp, #0xa0]
    325c:      	sshll.4s	v2, v2, #0x0
    3260:      	ldr	q7, [sp, #0x3b0]
    3264:      	mov.16b	v25, v2
    3268:      	bsl.16b	v25, v4, v7
    326c:      	mov.16b	v26, v3
    3270:      	bsl.16b	v26, v4, v15
    3274:      	ldr	q3, [sp, #0x1d0]
    3278:      	zip2.8b	v2, v3, v0
    327c:      	ushll.4s	v2, v2, #0x0
    3280:      	shl.4s	v2, v2, #0x1f
    3284:      	cmlt.4s	v4, v2, #0
    3288:      	zip1.8b	v2, v3, v0
    328c:      	ushll.4s	v2, v2, #0x0
    3290:      	shl.4s	v2, v2, #0x1f
    3294:      	cmlt.4s	v16, v2, #0
    3298:      	fmaxnm.4s	v2, v31, v26
    329c:      	fmaxnm.4s	v3, v8, v25
    32a0:      	and.16b	v3, v16, v3
    32a4:      	and.16b	v2, v4, v2
    32a8:      	zip2.8b	v7, v17, v0
    32ac:      	ushll.4s	v7, v7, #0x0
    32b0:      	shl.4s	v7, v7, #0x1f
    32b4:      	cmlt.4s	v7, v7, #0
    32b8:      	bit.16b	v2, v6, v7
    32bc:      	str	d17, [sp, #0xc0]
    32c0:      	zip1.8b	v6, v17, v0
    32c4:      	ushll.4s	v6, v6, #0x0
    32c8:      	shl.4s	v6, v6, #0x1f
    32cc:      	cmlt.4s	v6, v6, #0
    32d0:      	bit.16b	v3, v5, v6
    32d4:      	fmaxnm.4s	v3, v3, v30
    32d8:      	fmaxnm.4s	v2, v2, v29
    32dc:      	fmaxnm.4s	v2, v2, v24
    32e0:      	fmaxnm.4s	v3, v3, v23
    32e4:      	fmaxnm.4s	v17, v3, v22
    32e8:      	fmaxnm.4s	v18, v2, v19
    32ec:      	ldr	q2, [sp, #0x3c0]
    32f0:      	ldp	q3, q6, [sp, #0x380]
    32f4:      	uzp1.4s	v5, v2, v6
    32f8:      	ldr	q2, [sp, #0x3a0]
    32fc:      	uzp1.4s	v6, v3, v2
    3300:      	movi.4s	v3, #0x1
    3304:      	eor.16b	v2, v5, v3
    3308:      	mov.s	w9, v2[1]
    330c:      	eor.16b	v3, v6, v3
    3310:      	mov.s	w12, v2[2]
    3314:      	mov.s	w13, v2[3]
    3318:      	fmov	w8, s2
    331c:      	add	x11, sp, #0x6f8
    3320:      	bfxil	x11, x8, #0, #3
    3324:      	ldr	q23, [sp, #0x1a0]
    3328:      	str	d23, [sp, #0x6f8]
    332c:      	ldrb	w14, [x11]
    3330:      	umov.b	w22, v23[0]
    3334:      	and	x8, x8, #0x7
    3338:      	str	q18, [sp, #0x990]
    333c:      	str	q17, [sp, #0x980]
    3340:      	add	x15, sp, #0x980
    3344:      	ldr	s2, [x15, x8, lsl #2]
    3348:      	ands	w8, w22, #0x1
    334c:      	tst	w8, w14
    3350:      	movi	d24, #0000000000000000
    3354:      	fcsel	s2, s2, s24, ne
    3358:      	and	x14, x9, #0x7
    335c:      	add	x15, sp, #0x6f8
    3360:      	bfxil	x15, x9, #0, #3
    3364:      	ldrb	w9, [x15]
    3368:      	umov.b	w11, v23[1]
    336c:      	str	q18, [sp, #0x970]
    3370:      	str	q17, [sp, #0x960]
    3374:      	add	x16, sp, #0x960
    3378:      	ldr	s7, [x16, x14, lsl #2]
    337c:      	and	w9, w11, w9
    3380:      	tst	w9, #0x1
    3384:      	fcsel	s7, s7, s24, ne
    3388:      	and	x9, x12, #0x7
    338c:      	add	x14, sp, #0x6f8
    3390:      	bfxil	x14, x12, #0, #3
    3394:      	ldrb	w12, [x14]
    3398:      	umov.b	w15, v23[2]
    339c:      	and	w12, w15, w12
    33a0:      	str	q18, [sp, #0x950]
    33a4:      	str	q17, [sp, #0x940]
    33a8:      	add	x16, sp, #0x940
    33ac:      	ldr	s19, [x16, x9, lsl #2]
    33b0:      	tst	w12, #0x1
    33b4:      	fcsel	s19, s19, s24, ne
    33b8:      	and	x9, x13, #0x7
    33bc:      	add	x12, sp, #0x6f8
    33c0:      	bfxil	x12, x13, #0, #3
    33c4:      	ldrb	w12, [x12]
    33c8:      	umov.b	w14, v23[3]
    33cc:      	and	w12, w14, w12
    33d0:      	str	q18, [sp, #0x930]
    33d4:      	str	q17, [sp, #0x920]
    33d8:      	add	x16, sp, #0x920
    33dc:      	ldr	s20, [x16, x9, lsl #2]
    33e0:      	tst	w12, #0x1
    33e4:      	mov.s	w9, v3[1]
    33e8:      	fcsel	s20, s20, s24, ne
    33ec:      	mov.s	w12, v3[2]
    33f0:      	mov.s	w16, v3[3]
    33f4:      	fmov	w17, s3
    33f8:      	and	x0, x17, #0x7
    33fc:      	add	x1, sp, #0x6f8
    3400:      	bfxil	x1, x17, #0, #3
    3404:      	ldrb	w17, [x1]
    3408:      	umov.b	w13, v23[4]
    340c:      	and	w17, w13, w17
    3410:      	str	q18, [sp, #0xa10]
    3414:      	str	q17, [sp, #0xa00]
    3418:      	add	x2, sp, #0xa00
    341c:      	ldr	s3, [x2, x0, lsl #2]
    3420:      	tst	w17, #0x1
    3424:      	fcsel	s3, s3, s24, ne
    3428:      	and	x17, x9, #0x7
    342c:      	add	x2, sp, #0x6f8
    3430:      	bfxil	x2, x9, #0, #3
    3434:      	umov.b	w1, v23[5]
    3438:      	ldrb	w9, [x2]
    343c:      	and	w9, w1, w9
    3440:      	str	q18, [sp, #0x9f0]
    3444:      	str	q17, [sp, #0x9e0]
    3448:      	add	x2, sp, #0x9e0
    344c:      	ldr	s21, [x2, x17, lsl #2]
    3450:      	tst	w9, #0x1
    3454:      	fcsel	s21, s21, s24, ne
    3458:      	and	x9, x12, #0x7
    345c:      	add	x17, sp, #0x6f8
    3460:      	bfxil	x17, x12, #0, #3
    3464:      	ldrb	w12, [x17]
    3468:      	umov.b	w0, v23[6]
    346c:      	str	q18, [sp, #0x9d0]
    3470:      	str	q17, [sp, #0x9c0]
    3474:      	add	x2, sp, #0x9c0
    3478:      	ldr	s22, [x2, x9, lsl #2]
    347c:      	and	w9, w0, w12
    3480:      	tst	w9, #0x1
    3484:      	fcsel	s22, s22, s24, ne
    3488:      	and	x9, x16, #0x7
    348c:      	add	x12, sp, #0x6f8
    3490:      	bfxil	x12, x16, #0, #3
    3494:      	ldrb	w12, [x12]
    3498:      	umov.b	w17, v23[7]
    349c:      	and	w12, w17, w12
    34a0:      	str	q18, [sp, #0x9b0]
    34a4:      	str	q17, [sp, #0x9a0]
    34a8:      	add	x16, sp, #0x9a0
    34ac:      	ldr	s23, [x16, x9, lsl #2]
    34b0:      	tst	w12, #0x1
    34b4:      	fcsel	s23, s23, s24, ne
    34b8:      	mov.s	v3[1], v21[0]
    34bc:      	mov.s	v3[2], v22[0]
    34c0:      	mov.s	v3[3], v23[0]
    34c4:      	mov.s	v2[1], v7[0]
    34c8:      	mov.s	v2[2], v19[0]
    34cc:      	mov.s	v2[3], v20[0]
    34d0:      	fmaxnm.4s	v7, v17, v2
    34d4:      	fmaxnm.4s	v17, v18, v3
    34d8:      	movi.4s	v3, #0x2
    34dc:      	eor.16b	v2, v5, v3
    34e0:      	mov.s	w9, v2[1]
    34e4:      	mov.s	w12, v2[2]
    34e8:      	eor.16b	v19, v6, v3
    34ec:      	mov.s	w16, v2[3]
    34f0:      	fmov	w2, s2
    34f4:      	add	x3, sp, #0x6f8
    34f8:      	bfxil	x3, x2, #0, #3
    34fc:      	ldrb	w3, [x3]
    3500:      	and	x2, x2, #0x7
    3504:      	str	q17, [sp, #0x910]
    3508:      	str	q7, [sp, #0x900]
    350c:      	add	x4, sp, #0x900
    3510:      	ldr	s2, [x4, x2, lsl #2]
    3514:      	tst	w8, w3
    3518:      	fcsel	s2, s2, s24, ne
    351c:      	and	x2, x9, #0x7
    3520:      	add	x3, sp, #0x6f8
    3524:      	bfxil	x3, x9, #0, #3
    3528:      	ldrb	w9, [x3]
    352c:      	and	w9, w11, w9
    3530:      	str	q17, [sp, #0x8f0]
    3534:      	str	q7, [sp, #0x8e0]
    3538:      	add	x3, sp, #0x8e0
    353c:      	ldr	s3, [x3, x2, lsl #2]
    3540:      	tst	w9, #0x1
    3544:      	fcsel	s6, s3, s24, ne
    3548:      	and	x9, x12, #0x7
    354c:      	add	x2, sp, #0x6f8
    3550:      	bfxil	x2, x12, #0, #3
    3554:      	ldrb	w12, [x2]
    3558:      	and	w12, w15, w12
    355c:      	str	q17, [sp, #0x8d0]
    3560:      	str	q7, [sp, #0x8c0]
    3564:      	add	x2, sp, #0x8c0
    3568:      	ldr	s3, [x2, x9, lsl #2]
    356c:      	tst	w12, #0x1
    3570:      	fcsel	s18, s3, s24, ne
    3574:      	and	x9, x16, #0x7
    3578:      	add	x12, sp, #0x6f8
    357c:      	bfxil	x12, x16, #0, #3
    3580:      	ldrb	w12, [x12]
    3584:      	and	w12, w14, w12
    3588:      	str	q17, [sp, #0x8b0]
    358c:      	str	q7, [sp, #0x8a0]
    3590:      	add	x16, sp, #0x8a0
    3594:      	ldr	s3, [x16, x9, lsl #2]
    3598:      	tst	w12, #0x1
    359c:      	mov.s	w9, v19[3]
    35a0:      	fmov	w12, s19
    35a4:      	and	x19, x12, #0x7
    35a8:      	add	x26, sp, #0x6f8
    35ac:      	bfxil	x26, x12, #0, #3
    35b0:      	add	x12, sp, #0x6f8
    35b4:      	bfxil	x12, x9, #0, #3
    35b8:      	ldrb	w16, [x12]
    35bc:      	movi.4s	v20, #0x4
    35c0:      	eor.16b	v5, v5, v20
    35c4:      	mov.s	w5, v5[1]
    35c8:      	mov.s	w4, v5[2]
    35cc:      	mov.s	w2, v5[3]
    35d0:      	fmov	w3, s5
    35d4:      	add	x12, sp, #0x6f8
    35d8:      	bfxil	x12, x3, #0, #3
    35dc:      	ldrb	w30, [x12]
    35e0:      	add	x12, sp, #0x6f8
    35e4:      	bfxil	x12, x5, #0, #3
    35e8:      	ldrb	w12, [x12]
    35ec:      	add	x6, sp, #0x6f8
    35f0:      	bfxil	x6, x4, #0, #3
    35f4:      	ldrb	w7, [x6]
    35f8:      	add	x6, sp, #0x6f8
    35fc:      	bfxil	x6, x2, #0, #3
    3600:      	ldrb	w6, [x6]
    3604:      	ldrb	w26, [x26]
    3608:      	str	q17, [sp, #0x890]
    360c:      	str	q7, [sp, #0x880]
    3610:      	add	x24, sp, #0x880
    3614:      	ldr	s5, [x24, x19, lsl #2]
    3618:      	mov.s	w19, v19[1]
    361c:      	fcsel	s3, s3, s24, ne
    3620:      	and	w26, w13, w26
    3624:      	tst	w26, #0x1
    3628:      	add	x26, sp, #0x6f8
    362c:      	bfxil	x26, x19, #0, #3
    3630:      	and	x19, x19, #0x7
    3634:      	ldrb	w26, [x26]
    3638:      	str	q17, [sp, #0x870]
    363c:      	str	q7, [sp, #0x860]
    3640:      	add	x24, sp, #0x860
    3644:      	ldr	s20, [x24, x19, lsl #2]
    3648:      	mov.s	w19, v19[2]
    364c:      	fcsel	s5, s5, s24, ne
    3650:      	and	w26, w1, w26
    3654:      	tst	w26, #0x1
    3658:      	add	x26, sp, #0x6f8
    365c:      	bfxil	x26, x19, #0, #3
    3660:      	and	x19, x19, #0x7
    3664:      	ldrb	w26, [x26]
    3668:      	str	q17, [sp, #0x850]
    366c:      	str	q7, [sp, #0x840]
    3670:      	add	x24, sp, #0x840
    3674:      	ldr	s19, [x24, x19, lsl #2]
    3678:      	fcsel	s20, s20, s24, ne
    367c:      	and	w19, w0, w26
    3680:      	tst	w19, #0x1
    3684:      	and	x9, x9, #0x7
    3688:      	str	q17, [sp, #0x830]
    368c:      	str	q7, [sp, #0x820]
    3690:      	add	x19, sp, #0x820
    3694:      	ldr	s21, [x19, x9, lsl #2]
    3698:      	fcsel	s19, s19, s24, ne
    369c:      	and	w9, w17, w16
    36a0:      	tst	w9, #0x1
    36a4:      	fcsel	s21, s21, s24, ne
    36a8:      	mov.s	v5[1], v20[0]
    36ac:      	mov.s	v5[2], v19[0]
    36b0:      	mov.s	v5[3], v21[0]
    36b4:      	mov.s	v2[1], v6[0]
    36b8:      	mov.s	v2[2], v18[0]
    36bc:      	mov.s	v2[3], v3[0]
    36c0:      	fmaxnm.4s	v2, v7, v2
    36c4:      	fmaxnm.4s	v3, v17, v5
    36c8:      	and	x9, x3, #0x7
    36cc:      	str	q3, [sp, #0x810]
    36d0:      	str	q2, [sp, #0x800]
    36d4:      	add	x16, sp, #0x800
    36d8:      	ldr	s5, [x16, x9, lsl #2]
    36dc:      	tst	w8, w30
    36e0:      	fcsel	s5, s5, s24, ne
    36e4:      	and	x8, x5, #0x7
    36e8:      	and	w9, w11, w12
    36ec:      	str	q3, [sp, #0x7f0]
    36f0:      	str	q2, [sp, #0x7e0]
    36f4:      	add	x12, sp, #0x7e0
    36f8:      	ldr	s6, [x12, x8, lsl #2]
    36fc:      	tst	w9, #0x1
    3700:      	fcsel	s6, s6, s24, ne
    3704:      	and	x8, x4, #0x7
    3708:      	and	w9, w15, w7
    370c:      	str	q3, [sp, #0x7d0]
    3710:      	str	q2, [sp, #0x7c0]
    3714:      	add	x12, sp, #0x7c0
    3718:      	ldr	s7, [x12, x8, lsl #2]
    371c:      	tst	w9, #0x1
    3720:      	fcsel	s7, s7, s24, ne
    3724:      	and	x8, x2, #0x7
    3728:      	str	q3, [sp, #0x7b0]
    372c:      	str	q2, [sp, #0x7a0]
    3730:      	add	x9, sp, #0x7a0
    3734:      	ldr	s3, [x9, x8, lsl #2]
    3738:      	and	w8, w14, w6
    373c:      	tst	w8, #0x1
    3740:      	fcsel	s3, s3, s24, ne
    3744:      	ands	w2, w22, #0x1
    3748:      	ldr	x26, [sp, #0xf8]
    374c:      	add	x8, x25, x26
    3750:      	ldp	q18, q17, [x8]
    3754:      	stp	q26, q25, [sp, #0x80]
    3758:      	bsl.16b	v16, v25, v18
    375c:      	bsl.16b	v4, v26, v17
    3760:      	mov.s	v5[1], v6[0]
    3764:      	stp	q16, q4, [x8]
    3768:      	mov.s	v5[2], v7[0]
    376c:      	mov.s	v5[3], v3[0]
    3770:      	fmaxnm.4s	v2, v2, v5
    3774:      	fcsel	s3, s2, s24, ne
    3778:      	mov	x4, x11
    377c:      	and	w7, w11, w22
    3780:      	tst	w7, #0x1
    3784:      	fcsel	s4, s2, s24, ne
    3788:      	mov	x24, x15
    378c:      	and	w30, w15, w22
    3790:      	tst	w30, #0x1
    3794:      	fcsel	s5, s2, s24, ne
    3798:      	mov	x15, x14
    379c:      	and	w8, w14, w22
    37a0:      	tst	w8, #0x1
    37a4:      	fcsel	s6, s2, s24, ne
    37a8:      	stp	w13, w1, [sp, #0xd4]
    37ac:      	and	w5, w13, w22
    37b0:      	tst	w5, #0x1
    37b4:      	fcsel	s7, s2, s24, ne
    37b8:      	and	w6, w1, w22
    37bc:      	tst	w6, #0x1
    37c0:      	fcsel	s16, s2, s24, ne
    37c4:      	stp	w0, w17, [sp, #0xdc]
    37c8:      	and	w9, w0, w22
    37cc:      	str	w9, [sp, #0x78]
    37d0:      	tst	w9, #0x1
    37d4:      	fcsel	s17, s2, s24, ne
    37d8:      	str	w22, [sp, #0xd0]
    37dc:      	and	w9, w17, w22
    37e0:      	str	w9, [sp, #0x7c]
    37e4:      	tst	w9, #0x1
    37e8:      	fcsel	s2, s2, s24, ne
    37ec:      	mov.s	v3[1], v4[0]
    37f0:      	mov.s	v3[2], v5[0]
    37f4:      	mov.s	v3[3], v6[0]
    37f8:      	mov.s	v7[1], v16[0]
    37fc:      	mov.s	v7[2], v17[0]
    3800:      	mov.s	v7[3], v2[0]
    3804:      	ldr	w9, [sp, #0x3d0]
    3808:      	rbit	w9, w9
    380c:      	clz	w12, w9
    3810:      	str	q7, [sp, #0x710]
    3814:      	str	q3, [sp, #0x700]
    3818:      	and	x9, x12, #0x7
    381c:      	add	x16, sp, #0x700
    3820:      	ldr	s2, [x16, x9, lsl #2]
    3824:      	mov	w9, #-0x800000          ; =-8388608
    3828:      	fmov	s3, w9
    382c:      	fmaxnm	s2, s2, s3
    3830:      	ldr	x9, [sp, #0x370]
    3834:      	add	x9, x25, x9
    3838:      	ldp	q4, q3, [x9]
    383c:      	dup.4s	v18, v2[0]
    3840:      	fsub.4s	v2, v4, v18
    3844:      	fsub.4s	v3, v3, v18
    3848:      	and.16b	v3, v0, v3
    384c:      	and.16b	v2, v1, v2
    3850:      	mov	w9, #-0x3d300000        ; =-1026555904
    3854:      	dup.4s	v14, w9
    3858:      	fcmge.4s	v4, v2, v14
    385c:      	fcmge.4s	v5, v3, v14
    3860:      	mov	w9, #0x42c80000         ; =1120403456
    3864:      	dup.4s	v15, w9
    3868:      	fcmge.4s	v6, v15, v2
    386c:      	fcmge.4s	v7, v15, v3
    3870:      	and.16b	v5, v5, v7
    3874:      	and.16b	v4, v4, v6
    3878:      	and.16b	v4, v4, v2
    387c:      	and.16b	v5, v5, v3
    3880:      	mov	w9, #0xaa3b             ; =43579
    3884:      	movk	w9, #0x3fb8, lsl #16
    3888:      	dup.4s	v7, w9
    388c:      	fmul.4s	v6, v5, v7
    3890:      	str	q7, [sp, #0x3d0]
    3894:      	fmul.4s	v7, v4, v7
    3898:      	movi.4s	v20, #0x4b, lsl #24
    389c:      	mvni.4s	v22, #0x80, lsl #24
    38a0:      	mov.16b	v16, v22
    38a4:      	bsl.16b	v16, v20, v7
    38a8:      	mov.16b	v17, v22
    38ac:      	bsl.16b	v17, v20, v6
    38b0:      	fadd.4s	v6, v6, v17
    38b4:      	fadd.4s	v7, v7, v16
    38b8:      	fsub.4s	v7, v7, v16
    38bc:      	fsub.4s	v6, v6, v17
    38c0:      	fcvtzs.4s	v19, v6
    38c4:      	fcvtzs.4s	v21, v7
    38c8:      	scvtf.4s	v6, v21
    38cc:      	scvtf.4s	v7, v19
    38d0:      	mov	w9, #0x7200             ; =29184
    38d4:      	movk	w9, #0xbf31, lsl #16
    38d8:      	dup.4s	v17, w9
    38dc:      	fmul.4s	v16, v7, v17
    38e0:      	str	q17, [sp, #0x3c0]
    38e4:      	fmul.4s	v17, v6, v17
    38e8:      	fadd.4s	v4, v4, v17
    38ec:      	fadd.4s	v16, v5, v16
    38f0:      	mov	w9, #0xbe8e             ; =48782
    38f4:      	movk	w9, #0xb5bf, lsl #16
    38f8:      	dup.4s	v5, w9
    38fc:      	fmul.4s	v6, v6, v5
    3900:      	str	q5, [sp, #0x2e0]
    3904:      	fmul.4s	v7, v7, v5
    3908:      	fadd.4s	v23, v16, v7
    390c:      	fadd.4s	v4, v4, v6
    3910:      	mov	w9, #0x2bda             ; =11226
    3914:      	movk	w9, #0x3950, lsl #16
    3918:      	dup.4s	v5, w9
    391c:      	fmul.4s	v16, v4, v5
    3920:      	str	q5, [sp, #0x3b0]
    3924:      	fmul.4s	v17, v23, v5
    3928:      	mov	w9, #0x96c9             ; =38601
    392c:      	movk	w9, #0x3ab6, lsl #16
    3930:      	dup.4s	v5, w9
    3934:      	fadd.4s	v17, v17, v5
    3938:      	str	q5, [sp, #0x3a0]
    393c:      	fadd.4s	v16, v16, v5
    3940:      	fmul.4s	v16, v4, v16
    3944:      	fmul.4s	v17, v23, v17
    3948:      	mov	w9, #0x88a6             ; =34982
    394c:      	movk	w9, #0x3c08, lsl #16
    3950:      	dup.4s	v5, w9
    3954:      	fadd.4s	v17, v17, v5
    3958:      	str	q5, [sp, #0x390]
    395c:      	fadd.4s	v16, v16, v5
    3960:      	fmul.4s	v24, v4, v16
    3964:      	fmul.4s	v17, v23, v17
    3968:      	mov	w9, #0xaa7a             ; =43642
    396c:      	movk	w9, #0x3d2a, lsl #16
    3970:      	dup.4s	v5, w9
    3974:      	fadd.4s	v17, v17, v5
    3978:      	str	q5, [sp, #0x380]
    397c:      	fadd.4s	v24, v24, v5
    3980:      	fmul.4s	v24, v4, v24
    3984:      	fmul.4s	v25, v23, v17
    3988:      	mov	w9, #0xaaab             ; =43691
    398c:      	movk	w9, #0x3e2a, lsl #16
    3990:      	dup.4s	v5, w9
    3994:      	fadd.4s	v25, v25, v5
    3998:      	str	q5, [sp, #0x370]
    399c:      	fadd.4s	v24, v24, v5
    39a0:      	fmul.4s	v24, v4, v24
    39a4:      	fmul.4s	v25, v23, v25
    39a8:      	movi.4s	v5, #0x3f, lsl #24
    39ac:      	fadd.4s	v25, v25, v5
    39b0:      	fadd.4s	v24, v24, v5
    39b4:      	fmul.4s	v26, v23, v23
    39b8:      	fmul.4s	v27, v4, v4
    39bc:      	fmul.4s	v24, v27, v24
    39c0:      	fmul.4s	v25, v26, v25
    39c4:      	fadd.4s	v23, v23, v25
    39c8:      	fadd.4s	v4, v4, v24
    39cc:      	fmov.4s	v8, #1.00000000
    39d0:      	fadd.4s	v4, v4, v8
    39d4:      	fadd.4s	v23, v23, v8
    39d8:      	sshr.4s	v24, v21, #0x1
    39dc:      	sshr.4s	v25, v19, #0x1
    39e0:      	shl.4s	v26, v25, #0x17
    39e4:      	add.4s	v26, v26, v8
    39e8:      	fmul.4s	v23, v23, v26
    39ec:      	shl.4s	v26, v24, #0x17
    39f0:      	add.4s	v26, v26, v8
    39f4:      	fmul.4s	v4, v4, v26
    39f8:      	sub.4s	v19, v19, v25
    39fc:      	sub.4s	v21, v21, v24
    3a00:      	shl.4s	v21, v21, #0x17
    3a04:      	add.4s	v21, v21, v8
    3a08:      	fmul.4s	v4, v4, v21
    3a0c:      	shl.4s	v19, v19, #0x17
    3a10:      	add.4s	v19, v19, v8
    3a14:      	fmul.4s	v19, v23, v19
    3a18:      	fcmgt.4s	v21, v14, v3
    3a1c:      	bic.16b	v19, v19, v21
    3a20:      	fcmgt.4s	v21, v14, v2
    3a24:      	bic.16b	v4, v4, v21
    3a28:      	fcmgt.4s	v21, v2, v15
    3a2c:      	ldp	q5, q6, [sp, #0x3e0]
    3a30:      	bit.16b	v4, v6, v21
    3a34:      	fcmgt.4s	v21, v3, v15
    3a38:      	bit.16b	v19, v6, v21
    3a3c:      	fcmeq.4s	v3, v3, v3
    3a40:      	bsl.16b	v3, v19, v5
    3a44:      	fcmeq.4s	v2, v2, v2
    3a48:      	bsl.16b	v2, v4, v5
    3a4c:      	ldr	q4, [sp, #0x50]
    3a50:      	sshll.4s	v4, v4, #0x0
    3a54:      	bic.16b	v30, v2, v4
    3a58:      	ldr	q2, [sp, #0x60]
    3a5c:      	bic.16b	v31, v3, v2
    3a60:      	ldp	q2, q3, [x23]
    3a64:      	bit.16b	v3, v31, v0
    3a68:      	bit.16b	v2, v30, v1
    3a6c:      	stp	q2, q3, [x23]
    3a70:      	fmov	w9, s13
    3a74:      	ldr	q2, [sp, #0x430]
    3a78:      	add.2d	v2, v2, v9
    3a7c:      	tbz	w9, #0x0, 0x3ad0 <_llm_rows.packet_batch.blocks+0x1ef0>
    3a80:      	fmov	x16, d2
    3a84:      	ldr	b19, [x16]
    3a88:      	ldp	q17, q6, [sp, #0x2e0]
    3a8c:      	ldr	w22, [sp, #0xcc]
    3a90:      	and	w3, w9, #0xff
    3a94:      	mov	w19, #0x4               ; =4
    3a98:      	tbnz	w3, #0x1, 0x3ae8 <_llm_rows.packet_batch.blocks+0x1f08>
    3a9c:      	b	0x3af0 <_llm_rows.packet_batch.blocks+0x1f10>
    3aa0:      	fmov	x9, d18
    3aa4:      	ld1.b	{ v2 }[2], [x9]
    3aa8:      	tbz	w15, #0x3, 0x3200 <_llm_rows.packet_batch.blocks+0x1620>
    3aac:      	ld1.b	{ v2 }[3], [x13]
    3ab0:      	tbz	w15, #0x4, 0x3204 <_llm_rows.packet_batch.blocks+0x1624>
    3ab4:      	ldr	q3, [sp, #0xe0]
    3ab8:      	fmov	x9, d3
    3abc:      	ld1.b	{ v2 }[4], [x9]
    3ac0:      	tbz	w15, #0x5, 0x3208 <_llm_rows.packet_batch.blocks+0x1628>
    3ac4:      	ld1.b	{ v2 }[5], [x11]
    3ac8:      	tbnz	w15, #0x6, 0x320c <_llm_rows.packet_batch.blocks+0x162c>
    3acc:      	b	0x3218 <_llm_rows.packet_batch.blocks+0x1638>
    3ad0:      	movi.2d	v19, #0000000000000000
    3ad4:      	ldp	q17, q6, [sp, #0x2e0]
    3ad8:      	ldr	w22, [sp, #0xcc]
    3adc:      	and	w3, w9, #0xff
    3ae0:      	mov	w19, #0x4               ; =4
    3ae4:      	tbz	w3, #0x1, 0x3af0 <_llm_rows.packet_batch.blocks+0x1f10>
    3ae8:      	mov.d	x9, v2[1]
    3aec:      	ld1.b	{ v19 }[1], [x9]
    3af0:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1420>
    3af4:      	ldr	q2, [x9]
    3af8:      	and.16b	v2, v6, v2
    3afc:      	ldr	q3, [sp, #0x450]
    3b00:      	add.2d	v2, v3, v2
    3b04:      	tbnz	w3, #0x2, 0x3d48 <_llm_rows.packet_batch.blocks+0x2168>
    3b08:      	tbz	w3, #0x3, 0x3b14 <_llm_rows.packet_batch.blocks+0x1f34>
    3b0c:      	mov.d	x9, v2[1]
    3b10:      	ld1.b	{ v19 }[3], [x9]
    3b14:      	sshll.2d	v4, v0, #0x0
    3b18:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1420>
    3b1c:      	ldr	q2, [x9]
    3b20:      	and.16b	v2, v4, v2
    3b24:      	ldr	q3, [sp, #0x440]
    3b28:      	add.2d	v2, v3, v2
    3b2c:      	tbnz	w3, #0x4, 0x3d58 <_llm_rows.packet_batch.blocks+0x2178>
    3b30:      	tbnz	w3, #0x5, 0x3d64 <_llm_rows.packet_batch.blocks+0x2184>
    3b34:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1420>
    3b38:      	ldr	q2, [x9]
    3b3c:      	and.16b	v2, v10, v2
    3b40:      	ldr	q3, [sp, #0x360]
    3b44:      	add.2d	v2, v3, v2
    3b48:      	tbnz	w3, #0x6, 0x3d84 <_llm_rows.packet_batch.blocks+0x21a4>
    3b4c:      	tbz	w3, #0x7, 0x3b58 <_llm_rows.packet_batch.blocks+0x1f78>
    3b50:      	mov.d	x9, v2[1]
    3b54:      	ld1.b	{ v19 }[7], [x9]
    3b58:      	mov	w9, #0x20               ; =32
    3b5c:      	fmov	d2, x9
    3b60:      	and.16b	v2, v11, v2
    3b64:      	fmov	x9, d2
    3b68:      	add	x9, x25, x9
    3b6c:      	ldp	q3, q2, [x9]
    3b70:      	fsub.4s	v21, v3, v18
    3b74:      	fsub.4s	v2, v2, v18
    3b78:      	and.16b	v3, v0, v2
    3b7c:      	and.16b	v2, v1, v21
    3b80:      	fcmge.4s	v21, v2, v14
    3b84:      	fcmge.4s	v23, v3, v14
    3b88:      	fcmge.4s	v24, v15, v2
    3b8c:      	fcmge.4s	v25, v15, v3
    3b90:      	and.16b	v23, v23, v25
    3b94:      	and.16b	v21, v21, v24
    3b98:      	and.16b	v21, v21, v2
    3b9c:      	and.16b	v23, v23, v3
    3ba0:      	ldp	q5, q7, [sp, #0x3c0]
    3ba4:      	fmul.4s	v24, v23, v7
    3ba8:      	fmul.4s	v25, v21, v7
    3bac:      	mov.16b	v26, v22
    3bb0:      	bsl.16b	v26, v20, v25
    3bb4:      	mov.16b	v27, v22
    3bb8:      	bsl.16b	v27, v20, v24
    3bbc:      	fadd.4s	v24, v24, v27
    3bc0:      	fadd.4s	v25, v25, v26
    3bc4:      	fsub.4s	v25, v25, v26
    3bc8:      	fsub.4s	v24, v24, v27
    3bcc:      	fcvtzs.4s	v24, v24
    3bd0:      	fcvtzs.4s	v25, v25
    3bd4:      	scvtf.4s	v26, v25
    3bd8:      	scvtf.4s	v27, v24
    3bdc:      	fmul.4s	v28, v26, v5
    3be0:      	fadd.4s	v21, v21, v28
    3be4:      	fmul.4s	v28, v27, v5
    3be8:      	fadd.4s	v23, v23, v28
    3bec:      	fmul.4s	v26, v26, v17
    3bf0:      	fmul.4s	v27, v27, v17
    3bf4:      	fadd.4s	v23, v23, v27
    3bf8:      	fadd.4s	v21, v21, v26
    3bfc:      	ldp	q5, q7, [sp, #0x3a0]
    3c00:      	fmul.4s	v26, v21, v7
    3c04:      	fmul.4s	v27, v23, v7
    3c08:      	fadd.4s	v27, v27, v5
    3c0c:      	fadd.4s	v26, v26, v5
    3c10:      	fmul.4s	v26, v21, v26
    3c14:      	fmul.4s	v27, v23, v27
    3c18:      	ldp	q5, q7, [sp, #0x380]
    3c1c:      	fadd.4s	v27, v27, v7
    3c20:      	fadd.4s	v26, v26, v7
    3c24:      	fmul.4s	v26, v21, v26
    3c28:      	fmul.4s	v27, v23, v27
    3c2c:      	fadd.4s	v27, v27, v5
    3c30:      	fadd.4s	v26, v26, v5
    3c34:      	fmul.4s	v26, v21, v26
    3c38:      	fmul.4s	v27, v23, v27
    3c3c:      	ldr	q5, [sp, #0x370]
    3c40:      	fadd.4s	v27, v27, v5
    3c44:      	fadd.4s	v26, v26, v5
    3c48:      	fmul.4s	v26, v21, v26
    3c4c:      	fmul.4s	v27, v23, v27
    3c50:      	movi.4s	v5, #0x3f, lsl #24
    3c54:      	fadd.4s	v27, v27, v5
    3c58:      	fadd.4s	v26, v26, v5
    3c5c:      	fmul.4s	v28, v21, v21
    3c60:      	fmul.4s	v26, v28, v26
    3c64:      	fmul.4s	v28, v23, v23
    3c68:      	fmul.4s	v27, v28, v27
    3c6c:      	fadd.4s	v23, v23, v27
    3c70:      	fadd.4s	v21, v21, v26
    3c74:      	fadd.4s	v21, v21, v8
    3c78:      	fadd.4s	v23, v23, v8
    3c7c:      	sshr.4s	v26, v25, #0x1
    3c80:      	sshr.4s	v27, v24, #0x1
    3c84:      	shl.4s	v28, v27, #0x17
    3c88:      	add.4s	v28, v28, v8
    3c8c:      	fmul.4s	v23, v23, v28
    3c90:      	shl.4s	v28, v26, #0x17
    3c94:      	add.4s	v28, v28, v8
    3c98:      	fmul.4s	v21, v21, v28
    3c9c:      	sub.4s	v24, v24, v27
    3ca0:      	sub.4s	v25, v25, v26
    3ca4:      	shl.4s	v25, v25, #0x17
    3ca8:      	add.4s	v25, v25, v8
    3cac:      	fmul.4s	v21, v21, v25
    3cb0:      	shl.4s	v24, v24, #0x17
    3cb4:      	add.4s	v24, v24, v8
    3cb8:      	fmul.4s	v23, v23, v24
    3cbc:      	fcmgt.4s	v24, v14, v3
    3cc0:      	bic.16b	v23, v23, v24
    3cc4:      	fcmgt.4s	v24, v14, v2
    3cc8:      	bic.16b	v21, v21, v24
    3ccc:      	fcmgt.4s	v24, v2, v15
    3cd0:      	ldp	q5, q7, [sp, #0x3e0]
    3cd4:      	bit.16b	v21, v7, v24
    3cd8:      	fcmgt.4s	v24, v3, v15
    3cdc:      	bit.16b	v23, v7, v24
    3ce0:      	fcmeq.4s	v3, v3, v3
    3ce4:      	bsl.16b	v3, v23, v5
    3ce8:      	cmeq.8b	v19, v19, #0
    3cec:      	sshll.8h	v19, v19, #0x0
    3cf0:      	fcmeq.4s	v2, v2, v2
    3cf4:      	bsl.16b	v2, v21, v5
    3cf8:      	sshll2.4s	v23, v19, #0x0
    3cfc:      	sshll.4s	v19, v19, #0x0
    3d00:      	bic.16b	v21, v2, v19
    3d04:      	bic.16b	v24, v3, v23
    3d08:      	ldp	q2, q3, [x23, #0x20]
    3d0c:      	bit.16b	v3, v24, v0
    3d10:      	bit.16b	v2, v21, v1
    3d14:      	stp	q2, q3, [x23, #0x20]
    3d18:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1420>
    3d1c:      	ldr	q2, [x9]
    3d20:      	and.16b	v2, v11, v2
    3d24:      	fmov	w9, s13
    3d28:      	ldr	q3, [sp, #0x430]
    3d2c:      	add.2d	v2, v3, v2
    3d30:      	tbz	w9, #0x0, 0x3d94 <_llm_rows.packet_batch.blocks+0x21b4>
    3d34:      	fmov	x16, d2
    3d38:      	ldr	b19, [x16]
    3d3c:      	and	w3, w9, #0xff
    3d40:      	tbnz	w3, #0x1, 0x3da0 <_llm_rows.packet_batch.blocks+0x21c0>
    3d44:      	b	0x3da8 <_llm_rows.packet_batch.blocks+0x21c8>
    3d48:      	fmov	x9, d2
    3d4c:      	ld1.b	{ v19 }[2], [x9]
    3d50:      	tbnz	w3, #0x3, 0x3b0c <_llm_rows.packet_batch.blocks+0x1f2c>
    3d54:      	b	0x3b14 <_llm_rows.packet_batch.blocks+0x1f34>
    3d58:      	fmov	x9, d2
    3d5c:      	ld1.b	{ v19 }[4], [x9]
    3d60:      	tbz	w3, #0x5, 0x3b34 <_llm_rows.packet_batch.blocks+0x1f54>
    3d64:      	mov.d	x9, v2[1]
    3d68:      	ld1.b	{ v19 }[5], [x9]
    3d6c:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1420>
    3d70:      	ldr	q2, [x9]
    3d74:      	and.16b	v2, v10, v2
    3d78:      	ldr	q3, [sp, #0x360]
    3d7c:      	add.2d	v2, v3, v2
    3d80:      	tbz	w3, #0x6, 0x3b4c <_llm_rows.packet_batch.blocks+0x1f6c>
    3d84:      	fmov	x9, d2
    3d88:      	ld1.b	{ v19 }[6], [x9]
    3d8c:      	tbnz	w3, #0x7, 0x3b50 <_llm_rows.packet_batch.blocks+0x1f70>
    3d90:      	b	0x3b58 <_llm_rows.packet_batch.blocks+0x1f78>
    3d94:      	movi.2d	v19, #0000000000000000
    3d98:      	and	w3, w9, #0xff
    3d9c:      	tbz	w3, #0x1, 0x3da8 <_llm_rows.packet_batch.blocks+0x21c8>
    3da0:      	mov.d	x9, v2[1]
    3da4:      	ld1.b	{ v19 }[1], [x9]
    3da8:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1420>
    3dac:      	ldr	q2, [x9]
    3db0:      	and.16b	v2, v6, v2
    3db4:      	ldr	q3, [sp, #0x450]
    3db8:      	add.2d	v2, v3, v2
    3dbc:      	tbnz	w3, #0x2, 0x3ff0 <_llm_rows.packet_batch.blocks+0x2410>
    3dc0:      	tbnz	w3, #0x3, 0x3ffc <_llm_rows.packet_batch.blocks+0x241c>
    3dc4:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1420>
    3dc8:      	ldr	q2, [x9]
    3dcc:      	and.16b	v2, v4, v2
    3dd0:      	ldr	q3, [sp, #0x440]
    3dd4:      	add.2d	v2, v3, v2
    3dd8:      	tbnz	w3, #0x4, 0x401c <_llm_rows.packet_batch.blocks+0x243c>
    3ddc:      	tbnz	w3, #0x5, 0x4028 <_llm_rows.packet_batch.blocks+0x2448>
    3de0:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1420>
    3de4:      	ldr	q2, [x9]
    3de8:      	and.16b	v2, v10, v2
    3dec:      	ldr	q3, [sp, #0x360]
    3df0:      	add.2d	v2, v3, v2
    3df4:      	tbnz	w3, #0x6, 0x4048 <_llm_rows.packet_batch.blocks+0x2468>
    3df8:      	tbz	w3, #0x7, 0x3e04 <_llm_rows.packet_batch.blocks+0x2224>
    3dfc:      	mov.d	x9, v2[1]
    3e00:      	ld1.b	{ v19 }[7], [x9]
    3e04:      	ldr	q2, [sp, #0x20]
    3e08:      	and.16b	v2, v11, v2
    3e0c:      	fmov	x9, d2
    3e10:      	add	x9, x25, x9
    3e14:      	ldp	q3, q2, [x9]
    3e18:      	fsub.4s	v23, v3, v18
    3e1c:      	fsub.4s	v2, v2, v18
    3e20:      	and.16b	v3, v0, v2
    3e24:      	and.16b	v2, v1, v23
    3e28:      	fcmge.4s	v23, v2, v14
    3e2c:      	fcmge.4s	v25, v3, v14
    3e30:      	fcmge.4s	v26, v15, v2
    3e34:      	fcmge.4s	v27, v15, v3
    3e38:      	and.16b	v25, v25, v27
    3e3c:      	and.16b	v23, v23, v26
    3e40:      	and.16b	v23, v23, v2
    3e44:      	and.16b	v25, v25, v3
    3e48:      	ldp	q5, q7, [sp, #0x3c0]
    3e4c:      	fmul.4s	v26, v25, v7
    3e50:      	fmul.4s	v27, v23, v7
    3e54:      	mov.16b	v28, v22
    3e58:      	bsl.16b	v28, v20, v27
    3e5c:      	mov.16b	v29, v22
    3e60:      	bsl.16b	v29, v20, v26
    3e64:      	fadd.4s	v26, v26, v29
    3e68:      	fadd.4s	v27, v27, v28
    3e6c:      	fsub.4s	v27, v27, v28
    3e70:      	fsub.4s	v26, v26, v29
    3e74:      	fcvtzs.4s	v26, v26
    3e78:      	fcvtzs.4s	v27, v27
    3e7c:      	scvtf.4s	v28, v27
    3e80:      	scvtf.4s	v29, v26
    3e84:      	fmul.4s	v9, v28, v5
    3e88:      	fadd.4s	v23, v23, v9
    3e8c:      	fmul.4s	v9, v29, v5
    3e90:      	fadd.4s	v25, v25, v9
    3e94:      	fmul.4s	v28, v28, v17
    3e98:      	fmul.4s	v29, v29, v17
    3e9c:      	fadd.4s	v25, v25, v29
    3ea0:      	fadd.4s	v23, v23, v28
    3ea4:      	ldp	q5, q7, [sp, #0x3a0]
    3ea8:      	fmul.4s	v28, v23, v7
    3eac:      	fmul.4s	v29, v25, v7
    3eb0:      	fadd.4s	v29, v29, v5
    3eb4:      	fadd.4s	v28, v28, v5
    3eb8:      	fmul.4s	v28, v23, v28
    3ebc:      	fmul.4s	v29, v25, v29
    3ec0:      	ldp	q5, q7, [sp, #0x380]
    3ec4:      	fadd.4s	v29, v29, v7
    3ec8:      	fadd.4s	v28, v28, v7
    3ecc:      	fmul.4s	v28, v23, v28
    3ed0:      	fmul.4s	v29, v25, v29
    3ed4:      	fadd.4s	v29, v29, v5
    3ed8:      	fadd.4s	v28, v28, v5
    3edc:      	fmul.4s	v28, v23, v28
    3ee0:      	fmul.4s	v29, v25, v29
    3ee4:      	ldr	q5, [sp, #0x370]
    3ee8:      	fadd.4s	v29, v29, v5
    3eec:      	fadd.4s	v28, v28, v5
    3ef0:      	fmul.4s	v28, v23, v28
    3ef4:      	fmul.4s	v29, v25, v29
    3ef8:      	movi.4s	v5, #0x3f, lsl #24
    3efc:      	fadd.4s	v29, v29, v5
    3f00:      	fadd.4s	v28, v28, v5
    3f04:      	fmul.4s	v9, v23, v23
    3f08:      	fmul.4s	v28, v9, v28
    3f0c:      	fmul.4s	v9, v25, v25
    3f10:      	fmul.4s	v29, v9, v29
    3f14:      	fadd.4s	v25, v25, v29
    3f18:      	fadd.4s	v23, v23, v28
    3f1c:      	fadd.4s	v23, v23, v8
    3f20:      	fadd.4s	v25, v25, v8
    3f24:      	sshr.4s	v28, v27, #0x1
    3f28:      	sshr.4s	v29, v26, #0x1
    3f2c:      	shl.4s	v9, v29, #0x17
    3f30:      	add.4s	v9, v9, v8
    3f34:      	fmul.4s	v25, v25, v9
    3f38:      	shl.4s	v9, v28, #0x17
    3f3c:      	add.4s	v9, v9, v8
    3f40:      	fmul.4s	v23, v23, v9
    3f44:      	sub.4s	v26, v26, v29
    3f48:      	sub.4s	v27, v27, v28
    3f4c:      	shl.4s	v27, v27, #0x17
    3f50:      	add.4s	v27, v27, v8
    3f54:      	fmul.4s	v23, v23, v27
    3f58:      	shl.4s	v26, v26, #0x17
    3f5c:      	add.4s	v26, v26, v8
    3f60:      	fmul.4s	v25, v25, v26
    3f64:      	fcmgt.4s	v26, v14, v3
    3f68:      	bic.16b	v25, v25, v26
    3f6c:      	fcmgt.4s	v26, v14, v2
    3f70:      	bic.16b	v23, v23, v26
    3f74:      	fcmgt.4s	v26, v2, v15
    3f78:      	ldp	q5, q7, [sp, #0x3e0]
    3f7c:      	bit.16b	v23, v7, v26
    3f80:      	fcmgt.4s	v26, v3, v15
    3f84:      	bit.16b	v25, v7, v26
    3f88:      	fcmeq.4s	v3, v3, v3
    3f8c:      	bsl.16b	v3, v25, v5
    3f90:      	cmeq.8b	v19, v19, #0
    3f94:      	sshll.8h	v19, v19, #0x0
    3f98:      	fcmeq.4s	v2, v2, v2
    3f9c:      	bsl.16b	v2, v23, v5
    3fa0:      	sshll2.4s	v23, v19, #0x0
    3fa4:      	sshll.4s	v19, v19, #0x0
    3fa8:      	bic.16b	v25, v2, v19
    3fac:      	bic.16b	v23, v3, v23
    3fb0:      	ldp	q2, q3, [x23, #0x40]
    3fb4:      	bit.16b	v3, v23, v0
    3fb8:      	bit.16b	v2, v25, v1
    3fbc:      	stp	q2, q3, [x23, #0x40]
    3fc0:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x1420>
    3fc4:      	ldr	q2, [x9]
    3fc8:      	and.16b	v2, v11, v2
    3fcc:      	fmov	w9, s13
    3fd0:      	ldr	q3, [sp, #0x430]
    3fd4:      	add.2d	v2, v3, v2
    3fd8:      	tbz	w9, #0x0, 0x4058 <_llm_rows.packet_batch.blocks+0x2478>
    3fdc:      	fmov	x16, d2
    3fe0:      	ldr	b19, [x16]
    3fe4:      	and	w3, w9, #0xff
    3fe8:      	tbnz	w3, #0x1, 0x4064 <_llm_rows.packet_batch.blocks+0x2484>
    3fec:      	b	0x406c <_llm_rows.packet_batch.blocks+0x248c>
    3ff0:      	fmov	x9, d2
    3ff4:      	ld1.b	{ v19 }[2], [x9]
    3ff8:      	tbz	w3, #0x3, 0x3dc4 <_llm_rows.packet_batch.blocks+0x21e4>
    3ffc:      	mov.d	x9, v2[1]
    4000:      	ld1.b	{ v19 }[3], [x9]
    4004:      	adrp	x9, 0x4000 <_llm_rows.packet_batch.blocks+0x2420>
    4008:      	ldr	q2, [x9]
    400c:      	and.16b	v2, v4, v2
    4010:      	ldr	q3, [sp, #0x440]
    4014:      	add.2d	v2, v3, v2
    4018:      	tbz	w3, #0x4, 0x3ddc <_llm_rows.packet_batch.blocks+0x21fc>
    401c:      	fmov	x9, d2
    4020:      	ld1.b	{ v19 }[4], [x9]
    4024:      	tbz	w3, #0x5, 0x3de0 <_llm_rows.packet_batch.blocks+0x2200>
    4028:      	mov.d	x9, v2[1]
    402c:      	ld1.b	{ v19 }[5], [x9]
    4030:      	adrp	x9, 0x4000 <_llm_rows.packet_batch.blocks+0x2420>
    4034:      	ldr	q2, [x9]
    4038:      	and.16b	v2, v10, v2
    403c:      	ldr	q3, [sp, #0x360]
    4040:      	add.2d	v2, v3, v2
    4044:      	tbz	w3, #0x6, 0x3df8 <_llm_rows.packet_batch.blocks+0x2218>
    4048:      	fmov	x9, d2
    404c:      	ld1.b	{ v19 }[6], [x9]
    4050:      	tbnz	w3, #0x7, 0x3dfc <_llm_rows.packet_batch.blocks+0x221c>
    4054:      	b	0x3e04 <_llm_rows.packet_batch.blocks+0x2224>
    4058:      	movi.2d	v19, #0000000000000000
    405c:      	and	w3, w9, #0xff
    4060:      	tbz	w3, #0x1, 0x406c <_llm_rows.packet_batch.blocks+0x248c>
    4064:      	mov.d	x9, v2[1]
    4068:      	ld1.b	{ v19 }[1], [x9]
    406c:      	adrp	x9, 0x4000 <_llm_rows.packet_batch.blocks+0x2420>
    4070:      	ldr	q2, [x9]
    4074:      	and.16b	v2, v6, v2
    4078:      	ldr	q3, [sp, #0x450]
    407c:      	add.2d	v2, v3, v2
    4080:      	tbnz	w3, #0x2, 0x5638 <_llm_rows.packet_batch.blocks+0x3a58>
    4084:      	ldr	q16, [sp, #0x340]
    4088:      	tbnz	w3, #0x3, 0x5648 <_llm_rows.packet_batch.blocks+0x3a68>
    408c:      	adrp	x9, 0x4000 <_llm_rows.packet_batch.blocks+0x2420>
    4090:      	ldr	q2, [x9]
    4094:      	and.16b	v2, v4, v2
    4098:      	ldr	q3, [sp, #0x440]
    409c:      	add.2d	v2, v3, v2
    40a0:      	tbnz	w3, #0x4, 0x5668 <_llm_rows.packet_batch.blocks+0x3a88>
    40a4:      	tbnz	w3, #0x5, 0x5674 <_llm_rows.packet_batch.blocks+0x3a94>
    40a8:      	adrp	x9, 0x4000 <_llm_rows.packet_batch.blocks+0x2420>
    40ac:      	ldr	q2, [x9]
    40b0:      	and.16b	v2, v10, v2
    40b4:      	ldr	q3, [sp, #0x360]
    40b8:      	add.2d	v3, v3, v2
    40bc:      	tbnz	w3, #0x6, 0x5694 <_llm_rows.packet_batch.blocks+0x3ab4>
    40c0:      	ldr	q2, [sp, #0x10]
    40c4:      	and.16b	v2, v11, v2
    40c8:      	tbz	w3, #0x7, 0x40d4 <_llm_rows.packet_batch.blocks+0x24f4>
    40cc:      	mov.d	x9, v3[1]
    40d0:      	ld1.b	{ v19 }[7], [x9]
    40d4:      	fmov	x9, d2
    40d8:      	add	x9, x25, x9
    40dc:      	ldp	q3, q2, [x9]
    40e0:      	fsub.4s	v4, v3, v18
    40e4:      	fsub.4s	v2, v2, v18
    40e8:      	and.16b	v3, v0, v2
    40ec:      	and.16b	v2, v1, v4
    40f0:      	fcmge.4s	v4, v2, v14
    40f4:      	fcmge.4s	v26, v3, v14
    40f8:      	fcmge.4s	v27, v15, v2
    40fc:      	fcmge.4s	v28, v15, v3
    4100:      	and.16b	v26, v26, v28
    4104:      	and.16b	v4, v4, v27
    4108:      	and.16b	v4, v4, v2
    410c:      	and.16b	v26, v26, v3
    4110:      	ldp	q5, q6, [sp, #0x3c0]
    4114:      	fmul.4s	v27, v26, v6
    4118:      	fmul.4s	v28, v4, v6
    411c:      	mov.16b	v29, v22
    4120:      	bsl.16b	v29, v20, v28
    4124:      	mov.16b	v9, v22
    4128:      	bsl.16b	v9, v20, v27
    412c:      	fadd.4s	v27, v27, v9
    4130:      	fadd.4s	v28, v28, v29
    4134:      	fsub.4s	v28, v28, v29
    4138:      	fsub.4s	v27, v27, v9
    413c:      	fcvtzs.4s	v27, v27
    4140:      	fcvtzs.4s	v28, v28
    4144:      	scvtf.4s	v29, v28
    4148:      	scvtf.4s	v9, v27
    414c:      	fmul.4s	v11, v29, v5
    4150:      	fadd.4s	v4, v4, v11
    4154:      	fmul.4s	v11, v9, v5
    4158:      	fadd.4s	v26, v26, v11
    415c:      	fmul.4s	v29, v29, v17
    4160:      	fmul.4s	v9, v9, v17
    4164:      	fadd.4s	v26, v26, v9
    4168:      	fadd.4s	v4, v4, v29
    416c:      	ldp	q5, q6, [sp, #0x3a0]
    4170:      	fmul.4s	v29, v4, v6
    4174:      	fmul.4s	v9, v26, v6
    4178:      	fadd.4s	v9, v9, v5
    417c:      	fadd.4s	v29, v29, v5
    4180:      	fmul.4s	v29, v4, v29
    4184:      	fmul.4s	v9, v26, v9
    4188:      	ldp	q5, q6, [sp, #0x380]
    418c:      	fadd.4s	v9, v9, v6
    4190:      	fadd.4s	v29, v29, v6
    4194:      	fmul.4s	v29, v4, v29
    4198:      	fmul.4s	v9, v26, v9
    419c:      	fadd.4s	v9, v9, v5
    41a0:      	fadd.4s	v29, v29, v5
    41a4:      	fmul.4s	v29, v4, v29
    41a8:      	fmul.4s	v9, v26, v9
    41ac:      	ldr	q5, [sp, #0x370]
    41b0:      	fadd.4s	v9, v9, v5
    41b4:      	fadd.4s	v29, v29, v5
    41b8:      	fmul.4s	v29, v4, v29
    41bc:      	fmul.4s	v9, v26, v9
    41c0:      	movi.4s	v5, #0x3f, lsl #24
    41c4:      	fadd.4s	v9, v9, v5
    41c8:      	fadd.4s	v29, v29, v5
    41cc:      	fmul.4s	v11, v4, v4
    41d0:      	fmul.4s	v29, v11, v29
    41d4:      	fmul.4s	v11, v26, v26
    41d8:      	fmul.4s	v9, v11, v9
    41dc:      	fadd.4s	v26, v26, v9
    41e0:      	fadd.4s	v4, v4, v29
    41e4:      	fadd.4s	v4, v4, v8
    41e8:      	fadd.4s	v26, v26, v8
    41ec:      	sshr.4s	v29, v28, #0x1
    41f0:      	sshr.4s	v9, v27, #0x1
    41f4:      	shl.4s	v11, v9, #0x17
    41f8:      	add.4s	v11, v11, v8
    41fc:      	fmul.4s	v26, v26, v11
    4200:      	shl.4s	v11, v29, #0x17
    4204:      	add.4s	v11, v11, v8
    4208:      	fmul.4s	v4, v4, v11
    420c:      	sub.4s	v27, v27, v9
    4210:      	sub.4s	v28, v28, v29
    4214:      	shl.4s	v28, v28, #0x17
    4218:      	add.4s	v28, v28, v8
    421c:      	fmul.4s	v4, v4, v28
    4220:      	shl.4s	v27, v27, #0x17
    4224:      	add.4s	v27, v27, v8
    4228:      	fmul.4s	v26, v26, v27
    422c:      	fcmgt.4s	v27, v14, v3
    4230:      	bic.16b	v26, v26, v27
    4234:      	fcmgt.4s	v27, v14, v2
    4238:      	bic.16b	v4, v4, v27
    423c:      	fcmgt.4s	v27, v2, v15
    4240:      	ldp	q5, q6, [sp, #0x3e0]
    4244:      	bit.16b	v4, v6, v27
    4248:      	fcmgt.4s	v27, v3, v15
    424c:      	bit.16b	v26, v6, v27
    4250:      	fcmeq.4s	v3, v3, v3
    4254:      	bsl.16b	v3, v26, v5
    4258:      	cmeq.8b	v19, v19, #0
    425c:      	sshll.8h	v19, v19, #0x0
    4260:      	fcmeq.4s	v2, v2, v2
    4264:      	bsl.16b	v2, v4, v5
    4268:      	sshll2.4s	v4, v19, #0x0
    426c:      	sshll.4s	v19, v19, #0x0
    4270:      	bic.16b	v2, v2, v19
    4274:      	bic.16b	v3, v3, v4
    4278:      	ldp	q4, q19, [x23, #0x60]
    427c:      	bit.16b	v19, v3, v0
    4280:      	bit.16b	v4, v2, v1
    4284:      	stp	q4, q19, [x23, #0x60]
    4288:      	and.16b	v19, v0, v3
    428c:      	and.16b	v4, v1, v2
    4290:      	and.16b	v23, v0, v23
    4294:      	and.16b	v9, v1, v25
    4298:      	and.16b	v24, v0, v24
    429c:      	and.16b	v29, v1, v21
    42a0:      	and.16b	v31, v0, v31
    42a4:      	and.16b	v30, v1, v30
    42a8:      	str	q13, [sp, #0x340]
    42ac:      	b	0x44f0 <_llm_rows.packet_batch.blocks+0x2910>
    42b0:      	add	x10, x10, #0x60
    42b4:      	add	x9, x25, x10
    42b8:      	ldp	q5, q3, [x9]
    42bc:      	fsub.4s	v5, v5, v18
    42c0:      	fsub.4s	v3, v3, v18
    42c4:      	and.16b	v12, v0, v3
    42c8:      	and.16b	v3, v1, v5
    42cc:      	fcmge.4s	v5, v3, v14
    42d0:      	fcmge.4s	v6, v12, v14
    42d4:      	fcmge.4s	v20, v15, v3
    42d8:      	fcmge.4s	v10, v15, v12
    42dc:      	and.16b	v6, v6, v10
    42e0:      	and.16b	v5, v5, v20
    42e4:      	and.16b	v5, v5, v3
    42e8:      	and.16b	v6, v6, v12
    42ec:      	ldp	q17, q10, [sp, #0x3c0]
    42f0:      	fmul.4s	v20, v6, v10
    42f4:      	fmul.4s	v10, v5, v10
    42f8:      	mov.16b	v13, v22
    42fc:      	bsl.16b	v13, v7, v10
    4300:      	bif.16b	v7, v20, v22
    4304:      	fadd.4s	v20, v20, v7
    4308:      	fadd.4s	v10, v10, v13
    430c:      	fsub.4s	v10, v10, v13
    4310:      	fsub.4s	v7, v20, v7
    4314:      	fcvtzs.4s	v7, v7
    4318:      	fcvtzs.4s	v20, v10
    431c:      	scvtf.4s	v10, v20
    4320:      	scvtf.4s	v13, v7
    4324:      	fmul.4s	v22, v10, v17
    4328:      	fadd.4s	v5, v5, v22
    432c:      	fmul.4s	v22, v13, v17
    4330:      	fadd.4s	v6, v6, v22
    4334:      	ldr	q17, [sp, #0x2e0]
    4338:      	fmul.4s	v22, v10, v17
    433c:      	fmul.4s	v10, v13, v17
    4340:      	fadd.4s	v6, v6, v10
    4344:      	fadd.4s	v5, v5, v22
    4348:      	ldp	q13, q10, [sp, #0x3a0]
    434c:      	fmul.4s	v22, v5, v10
    4350:      	fmul.4s	v10, v6, v10
    4354:      	fadd.4s	v10, v10, v13
    4358:      	fadd.4s	v22, v22, v13
    435c:      	fmul.4s	v22, v5, v22
    4360:      	fmul.4s	v10, v6, v10
    4364:      	ldr	q13, [sp, #0x390]
    4368:      	fadd.4s	v10, v10, v13
    436c:      	fadd.4s	v22, v22, v13
    4370:      	fmul.4s	v22, v5, v22
    4374:      	fmul.4s	v10, v6, v10
    4378:      	ldr	q13, [sp, #0x380]
    437c:      	fadd.4s	v10, v10, v13
    4380:      	fadd.4s	v22, v22, v13
    4384:      	fmul.4s	v22, v5, v22
    4388:      	fmul.4s	v10, v6, v10
    438c:      	ldr	q13, [sp, #0x370]
    4390:      	fadd.4s	v10, v10, v13
    4394:      	fadd.4s	v22, v22, v13
    4398:      	fmul.4s	v22, v5, v22
    439c:      	fmul.4s	v10, v6, v10
    43a0:      	movi.4s	v13, #0x3f, lsl #24
    43a4:      	fadd.4s	v10, v10, v13
    43a8:      	fadd.4s	v22, v22, v13
    43ac:      	fmul.4s	v13, v5, v5
    43b0:      	fmul.4s	v22, v13, v22
    43b4:      	fmul.4s	v13, v6, v6
    43b8:      	fmul.4s	v10, v13, v10
    43bc:      	fadd.4s	v6, v6, v10
    43c0:      	fadd.4s	v5, v5, v22
    43c4:      	fadd.4s	v5, v5, v8
    43c8:      	fadd.4s	v6, v6, v8
    43cc:      	sshr.4s	v22, v20, #0x1
    43d0:      	sshr.4s	v10, v7, #0x1
    43d4:      	shl.4s	v13, v10, #0x17
    43d8:      	add.4s	v13, v13, v8
    43dc:      	fmul.4s	v6, v6, v13
    43e0:      	shl.4s	v13, v22, #0x17
    43e4:      	add.4s	v13, v13, v8
    43e8:      	fmul.4s	v5, v5, v13
    43ec:      	sub.4s	v7, v7, v10
    43f0:      	sub.4s	v20, v20, v22
    43f4:      	shl.4s	v20, v20, #0x17
    43f8:      	add.4s	v20, v20, v8
    43fc:      	fmul.4s	v5, v5, v20
    4400:      	shl.4s	v7, v7, #0x17
    4404:      	add.4s	v7, v7, v8
    4408:      	fmul.4s	v6, v6, v7
    440c:      	fcmgt.4s	v7, v14, v12
    4410:      	bic.16b	v6, v6, v7
    4414:      	fcmgt.4s	v7, v14, v3
    4418:      	bic.16b	v5, v5, v7
    441c:      	fcmgt.4s	v7, v3, v15
    4420:      	ldp	q20, q22, [sp, #0x3e0]
    4424:      	bit.16b	v5, v22, v7
    4428:      	fcmgt.4s	v7, v12, v15
    442c:      	bit.16b	v6, v22, v7
    4430:      	fcmeq.4s	v7, v12, v12
    4434:      	bif.16b	v6, v20, v7
    4438:      	cmeq.8b	v7, v28, #0
    443c:      	sshll.8h	v7, v7, #0x0
    4440:      	fcmeq.4s	v3, v3, v3
    4444:      	bsl.16b	v3, v5, v20
    4448:      	sshll2.4s	v5, v7, #0x0
    444c:      	sshll.4s	v7, v7, #0x0
    4450:      	bic.16b	v3, v3, v7
    4454:      	bic.16b	v5, v6, v5
    4458:      	add	x9, x23, x10
    445c:      	ldp	q6, q7, [x9]
    4460:      	bit.16b	v7, v5, v0
    4464:      	bit.16b	v6, v3, v1
    4468:      	stp	q6, q7, [x9]
    446c:      	dup.2d	v6, x19
    4470:      	ldr	q7, [sp, #0x350]
    4474:      	and.16b	v7, v7, v6
    4478:      	ldr	q20, [sp, #0x420]
    447c:      	add.2d	v20, v20, v7
    4480:      	str	q20, [sp, #0x420]
    4484:      	ldr	q7, [sp, #0x2f0]
    4488:      	and.16b	v7, v7, v6
    448c:      	ldr	q20, [sp, #0x410]
    4490:      	add.2d	v20, v20, v7
    4494:      	str	q20, [sp, #0x410]
    4498:      	sshll.2d	v7, v0, #0x0
    449c:      	and.16b	v7, v7, v6
    44a0:      	ldr	q20, [sp, #0x400]
    44a4:      	add.2d	v20, v20, v7
    44a8:      	str	q20, [sp, #0x400]
    44ac:      	sshll.2d	v7, v1, #0x0
    44b0:      	and.16b	v6, v7, v6
    44b4:      	add.2d	v16, v16, v6
    44b8:      	bit.16b	v24, v26, v0
    44bc:      	bit.16b	v29, v21, v1
    44c0:      	bit.16b	v23, v2, v0
    44c4:      	bit.16b	v9, v25, v1
    44c8:      	fadd.4s	v2, v19, v5
    44cc:      	bit.16b	v19, v2, v0
    44d0:      	fadd.4s	v2, v4, v3
    44d4:      	bit.16b	v4, v2, v1
    44d8:      	bit.16b	v31, v27, v0
    44dc:      	bit.16b	v30, v11, v1
    44e0:      	fmov	x10, d16
    44e4:      	cmp	x10, #0xc0
    44e8:      	ldr	q13, [sp, #0x340]
    44ec:      	b.ge	0x4e74 <_llm_rows.packet_batch.blocks+0x3294>
    44f0:      	fmov	w9, s13
    44f4:      	ldr	q2, [sp, #0x300]
    44f8:      	add.2d	v2, v16, v2
    44fc:      	ldr	q3, [sp, #0x430]
    4500:      	add.2d	v2, v3, v2
    4504:      	tbz	w9, #0x0, 0x4524 <_llm_rows.packet_batch.blocks+0x2944>
    4508:      	fmov	x16, d2
    450c:      	ldr	b21, [x16]
    4510:      	movi.4s	v7, #0x4b, lsl #24
    4514:      	mvni.4s	v22, #0x80, lsl #24
    4518:      	and	w3, w9, #0xff
    451c:      	tbnz	w3, #0x1, 0x4538 <_llm_rows.packet_batch.blocks+0x2958>
    4520:      	b	0x4540 <_llm_rows.packet_batch.blocks+0x2960>
    4524:      	movi.2d	v21, #0000000000000000
    4528:      	movi.4s	v7, #0x4b, lsl #24
    452c:      	mvni.4s	v22, #0x80, lsl #24
    4530:      	and	w3, w9, #0xff
    4534:      	tbz	w3, #0x1, 0x4540 <_llm_rows.packet_batch.blocks+0x2960>
    4538:      	mov.d	x9, v2[1]
    453c:      	ld1.b	{ v21 }[1], [x9]
    4540:      	ldr	q2, [sp, #0x320]
    4544:      	ldr	q3, [sp, #0x410]
    4548:      	add.2d	v2, v3, v2
    454c:      	ldr	q3, [sp, #0x450]
    4550:      	add.2d	v2, v3, v2
    4554:      	tbnz	w3, #0x2, 0x4784 <_llm_rows.packet_batch.blocks+0x2ba4>
    4558:      	tbnz	w3, #0x3, 0x4790 <_llm_rows.packet_batch.blocks+0x2bb0>
    455c:      	ldr	q2, [sp, #0x310]
    4560:      	ldr	q3, [sp, #0x400]
    4564:      	add.2d	v2, v3, v2
    4568:      	ldr	q3, [sp, #0x440]
    456c:      	add.2d	v2, v3, v2
    4570:      	tbnz	w3, #0x4, 0x47b0 <_llm_rows.packet_batch.blocks+0x2bd0>
    4574:      	tbnz	w3, #0x5, 0x47bc <_llm_rows.packet_batch.blocks+0x2bdc>
    4578:      	ldr	q2, [sp, #0x330]
    457c:      	ldr	q3, [sp, #0x420]
    4580:      	add.2d	v2, v3, v2
    4584:      	ldr	q3, [sp, #0x360]
    4588:      	add.2d	v2, v3, v2
    458c:      	tbnz	w3, #0x6, 0x47dc <_llm_rows.packet_batch.blocks+0x2bfc>
    4590:      	tbz	w3, #0x7, 0x459c <_llm_rows.packet_batch.blocks+0x29bc>
    4594:      	mov.d	x9, v2[1]
    4598:      	ld1.b	{ v21 }[7], [x9]
    459c:      	lsl	x10, x10, #5
    45a0:      	add	x9, x25, x10
    45a4:      	ldp	q3, q2, [x9]
    45a8:      	fsub.4s	v25, v3, v18
    45ac:      	fsub.4s	v2, v2, v18
    45b0:      	and.16b	v3, v0, v2
    45b4:      	and.16b	v2, v1, v25
    45b8:      	fcmge.4s	v25, v2, v14
    45bc:      	fcmge.4s	v26, v3, v14
    45c0:      	fcmge.4s	v27, v15, v2
    45c4:      	fcmge.4s	v28, v15, v3
    45c8:      	and.16b	v26, v26, v28
    45cc:      	and.16b	v25, v25, v27
    45d0:      	and.16b	v25, v25, v2
    45d4:      	and.16b	v26, v26, v3
    45d8:      	ldp	q5, q6, [sp, #0x3c0]
    45dc:      	fmul.4s	v27, v26, v6
    45e0:      	fmul.4s	v28, v25, v6
    45e4:      	mov.16b	v11, v22
    45e8:      	bsl.16b	v11, v7, v28
    45ec:      	mov.16b	v12, v22
    45f0:      	bsl.16b	v12, v7, v27
    45f4:      	fadd.4s	v27, v27, v12
    45f8:      	fadd.4s	v28, v28, v11
    45fc:      	fsub.4s	v28, v28, v11
    4600:      	fsub.4s	v27, v27, v12
    4604:      	fcvtzs.4s	v27, v27
    4608:      	fcvtzs.4s	v28, v28
    460c:      	scvtf.4s	v11, v28
    4610:      	scvtf.4s	v12, v27
    4614:      	fmul.4s	v13, v11, v5
    4618:      	fadd.4s	v25, v25, v13
    461c:      	fmul.4s	v13, v12, v5
    4620:      	fadd.4s	v26, v26, v13
    4624:      	fmul.4s	v11, v11, v17
    4628:      	fmul.4s	v12, v12, v17
    462c:      	fadd.4s	v26, v26, v12
    4630:      	fadd.4s	v25, v25, v11
    4634:      	ldp	q5, q6, [sp, #0x3a0]
    4638:      	fmul.4s	v11, v25, v6
    463c:      	fmul.4s	v12, v26, v6
    4640:      	fadd.4s	v12, v12, v5
    4644:      	fadd.4s	v11, v11, v5
    4648:      	fmul.4s	v11, v25, v11
    464c:      	fmul.4s	v12, v26, v12
    4650:      	ldp	q5, q6, [sp, #0x380]
    4654:      	fadd.4s	v12, v12, v6
    4658:      	fadd.4s	v11, v11, v6
    465c:      	fmul.4s	v11, v25, v11
    4660:      	fmul.4s	v12, v26, v12
    4664:      	fadd.4s	v12, v12, v5
    4668:      	fadd.4s	v11, v11, v5
    466c:      	fmul.4s	v11, v25, v11
    4670:      	fmul.4s	v12, v26, v12
    4674:      	ldr	q5, [sp, #0x370]
    4678:      	fadd.4s	v12, v12, v5
    467c:      	fadd.4s	v11, v11, v5
    4680:      	fmul.4s	v11, v25, v11
    4684:      	fmul.4s	v12, v26, v12
    4688:      	movi.4s	v5, #0x3f, lsl #24
    468c:      	fadd.4s	v12, v12, v5
    4690:      	fadd.4s	v11, v11, v5
    4694:      	fmul.4s	v13, v25, v25
    4698:      	fmul.4s	v11, v13, v11
    469c:      	fmul.4s	v13, v26, v26
    46a0:      	fmul.4s	v12, v13, v12
    46a4:      	fadd.4s	v26, v26, v12
    46a8:      	fadd.4s	v25, v25, v11
    46ac:      	fadd.4s	v25, v25, v8
    46b0:      	fadd.4s	v26, v26, v8
    46b4:      	sshr.4s	v11, v28, #0x1
    46b8:      	sshr.4s	v12, v27, #0x1
    46bc:      	shl.4s	v13, v12, #0x17
    46c0:      	add.4s	v13, v13, v8
    46c4:      	fmul.4s	v26, v26, v13
    46c8:      	shl.4s	v13, v11, #0x17
    46cc:      	add.4s	v13, v13, v8
    46d0:      	fmul.4s	v25, v25, v13
    46d4:      	sub.4s	v27, v27, v12
    46d8:      	sub.4s	v28, v28, v11
    46dc:      	shl.4s	v28, v28, #0x17
    46e0:      	add.4s	v28, v28, v8
    46e4:      	fmul.4s	v25, v25, v28
    46e8:      	shl.4s	v27, v27, #0x17
    46ec:      	add.4s	v27, v27, v8
    46f0:      	fmul.4s	v26, v26, v27
    46f4:      	fcmgt.4s	v27, v14, v3
    46f8:      	bic.16b	v26, v26, v27
    46fc:      	fcmgt.4s	v27, v14, v2
    4700:      	bic.16b	v25, v25, v27
    4704:      	fcmgt.4s	v27, v2, v15
    4708:      	ldp	q5, q6, [sp, #0x3e0]
    470c:      	bit.16b	v25, v6, v27
    4710:      	fcmgt.4s	v27, v3, v15
    4714:      	bit.16b	v26, v6, v27
    4718:      	fcmeq.4s	v3, v3, v3
    471c:      	bsl.16b	v3, v26, v5
    4720:      	cmeq.8b	v21, v21, #0
    4724:      	sshll.8h	v21, v21, #0x0
    4728:      	fcmeq.4s	v2, v2, v2
    472c:      	bsl.16b	v2, v25, v5
    4730:      	sshll2.4s	v25, v21, #0x0
    4734:      	sshll.4s	v21, v21, #0x0
    4738:      	bic.16b	v21, v2, v21
    473c:      	bic.16b	v11, v3, v25
    4740:      	add	x10, x23, x10
    4744:      	ldp	q2, q3, [x10]
    4748:      	bit.16b	v3, v11, v0
    474c:      	bit.16b	v2, v21, v1
    4750:      	stp	q2, q3, [x10]
    4754:      	ldr	q2, [sp, #0x340]
    4758:      	fmov	w9, s2
    475c:      	ldr	q2, [sp, #0x2d0]
    4760:      	add.2d	v2, v16, v2
    4764:      	ldr	q3, [sp, #0x430]
    4768:      	add.2d	v2, v3, v2
    476c:      	tbz	w9, #0x0, 0x47ec <_llm_rows.packet_batch.blocks+0x2c0c>
    4770:      	fmov	x10, d2
    4774:      	ldr	b25, [x10]
    4778:      	and	w10, w9, #0xff
    477c:      	tbnz	w10, #0x1, 0x47f8 <_llm_rows.packet_batch.blocks+0x2c18>
    4780:      	b	0x4800 <_llm_rows.packet_batch.blocks+0x2c20>
    4784:      	fmov	x9, d2
    4788:      	ld1.b	{ v21 }[2], [x9]
    478c:      	tbz	w3, #0x3, 0x455c <_llm_rows.packet_batch.blocks+0x297c>
    4790:      	mov.d	x9, v2[1]
    4794:      	ld1.b	{ v21 }[3], [x9]
    4798:      	ldr	q2, [sp, #0x310]
    479c:      	ldr	q3, [sp, #0x400]
    47a0:      	add.2d	v2, v3, v2
    47a4:      	ldr	q3, [sp, #0x440]
    47a8:      	add.2d	v2, v3, v2
    47ac:      	tbz	w3, #0x4, 0x4574 <_llm_rows.packet_batch.blocks+0x2994>
    47b0:      	fmov	x9, d2
    47b4:      	ld1.b	{ v21 }[4], [x9]
    47b8:      	tbz	w3, #0x5, 0x4578 <_llm_rows.packet_batch.blocks+0x2998>
    47bc:      	mov.d	x9, v2[1]
    47c0:      	ld1.b	{ v21 }[5], [x9]
    47c4:      	ldr	q2, [sp, #0x330]
    47c8:      	ldr	q3, [sp, #0x420]
    47cc:      	add.2d	v2, v3, v2
    47d0:      	ldr	q3, [sp, #0x360]
    47d4:      	add.2d	v2, v3, v2
    47d8:      	tbz	w3, #0x6, 0x4590 <_llm_rows.packet_batch.blocks+0x29b0>
    47dc:      	fmov	x9, d2
    47e0:      	ld1.b	{ v21 }[6], [x9]
    47e4:      	tbnz	w3, #0x7, 0x4594 <_llm_rows.packet_batch.blocks+0x29b4>
    47e8:      	b	0x459c <_llm_rows.packet_batch.blocks+0x29bc>
    47ec:      	movi.2d	v25, #0000000000000000
    47f0:      	and	w10, w9, #0xff
    47f4:      	tbz	w10, #0x1, 0x4800 <_llm_rows.packet_batch.blocks+0x2c20>
    47f8:      	mov.d	x9, v2[1]
    47fc:      	ld1.b	{ v25 }[1], [x9]
    4800:      	ldr	q2, [sp, #0x2c0]
    4804:      	ldr	q3, [sp, #0x410]
    4808:      	add.2d	v2, v3, v2
    480c:      	ldr	q3, [sp, #0x450]
    4810:      	add.2d	v2, v3, v2
    4814:      	tbnz	w10, #0x2, 0x4a4c <_llm_rows.packet_batch.blocks+0x2e6c>
    4818:      	tbnz	w10, #0x3, 0x4a58 <_llm_rows.packet_batch.blocks+0x2e78>
    481c:      	ldr	q2, [sp, #0x2b0]
    4820:      	ldr	q3, [sp, #0x400]
    4824:      	add.2d	v2, v3, v2
    4828:      	ldr	q3, [sp, #0x440]
    482c:      	add.2d	v2, v3, v2
    4830:      	tbnz	w10, #0x4, 0x4a78 <_llm_rows.packet_batch.blocks+0x2e98>
    4834:      	tbnz	w10, #0x5, 0x4a84 <_llm_rows.packet_batch.blocks+0x2ea4>
    4838:      	ldr	q2, [sp, #0x2a0]
    483c:      	ldr	q3, [sp, #0x420]
    4840:      	add.2d	v2, v3, v2
    4844:      	ldr	q3, [sp, #0x360]
    4848:      	add.2d	v2, v3, v2
    484c:      	tbnz	w10, #0x6, 0x4aa4 <_llm_rows.packet_batch.blocks+0x2ec4>
    4850:      	tbz	w10, #0x7, 0x485c <_llm_rows.packet_batch.blocks+0x2c7c>
    4854:      	mov.d	x9, v2[1]
    4858:      	ld1.b	{ v25 }[7], [x9]
    485c:      	fmov	x9, d16
    4860:      	lsl	x10, x9, #5
    4864:      	add	x3, x10, #0x20
    4868:      	add	x9, x25, x3
    486c:      	ldp	q3, q2, [x9]
    4870:      	fsub.4s	v26, v3, v18
    4874:      	fsub.4s	v2, v2, v18
    4878:      	and.16b	v3, v0, v2
    487c:      	and.16b	v2, v1, v26
    4880:      	fcmge.4s	v26, v2, v14
    4884:      	fcmge.4s	v27, v3, v14
    4888:      	fcmge.4s	v28, v15, v2
    488c:      	fcmge.4s	v12, v15, v3
    4890:      	and.16b	v27, v27, v12
    4894:      	and.16b	v26, v26, v28
    4898:      	and.16b	v26, v26, v2
    489c:      	and.16b	v27, v27, v3
    48a0:      	ldp	q5, q6, [sp, #0x3c0]
    48a4:      	fmul.4s	v28, v27, v6
    48a8:      	fmul.4s	v12, v26, v6
    48ac:      	mov.16b	v13, v22
    48b0:      	bsl.16b	v13, v7, v12
    48b4:      	mov.16b	v20, v22
    48b8:      	bsl.16b	v20, v7, v28
    48bc:      	fadd.4s	v28, v28, v20
    48c0:      	fadd.4s	v12, v12, v13
    48c4:      	fsub.4s	v12, v12, v13
    48c8:      	fsub.4s	v20, v28, v20
    48cc:      	fcvtzs.4s	v20, v20
    48d0:      	fcvtzs.4s	v28, v12
    48d4:      	scvtf.4s	v12, v28
    48d8:      	scvtf.4s	v13, v20
    48dc:      	fmul.4s	v10, v12, v5
    48e0:      	fadd.4s	v26, v26, v10
    48e4:      	fmul.4s	v10, v13, v5
    48e8:      	fadd.4s	v27, v27, v10
    48ec:      	fmul.4s	v10, v12, v17
    48f0:      	fmul.4s	v12, v13, v17
    48f4:      	fadd.4s	v27, v27, v12
    48f8:      	fadd.4s	v26, v26, v10
    48fc:      	ldp	q5, q6, [sp, #0x3a0]
    4900:      	fmul.4s	v10, v26, v6
    4904:      	fmul.4s	v12, v27, v6
    4908:      	fadd.4s	v12, v12, v5
    490c:      	fadd.4s	v10, v10, v5
    4910:      	fmul.4s	v10, v26, v10
    4914:      	fmul.4s	v12, v27, v12
    4918:      	ldp	q5, q6, [sp, #0x380]
    491c:      	fadd.4s	v12, v12, v6
    4920:      	fadd.4s	v10, v10, v6
    4924:      	fmul.4s	v10, v26, v10
    4928:      	fmul.4s	v12, v27, v12
    492c:      	fadd.4s	v12, v12, v5
    4930:      	fadd.4s	v10, v10, v5
    4934:      	fmul.4s	v10, v26, v10
    4938:      	fmul.4s	v12, v27, v12
    493c:      	ldr	q5, [sp, #0x370]
    4940:      	fadd.4s	v12, v12, v5
    4944:      	fadd.4s	v10, v10, v5
    4948:      	fmul.4s	v10, v26, v10
    494c:      	fmul.4s	v12, v27, v12
    4950:      	movi.4s	v5, #0x3f, lsl #24
    4954:      	fadd.4s	v12, v12, v5
    4958:      	fadd.4s	v10, v10, v5
    495c:      	fmul.4s	v13, v26, v26
    4960:      	fmul.4s	v10, v13, v10
    4964:      	fmul.4s	v13, v27, v27
    4968:      	fmul.4s	v12, v13, v12
    496c:      	fadd.4s	v27, v27, v12
    4970:      	fadd.4s	v26, v26, v10
    4974:      	fadd.4s	v26, v26, v8
    4978:      	fadd.4s	v27, v27, v8
    497c:      	sshr.4s	v10, v28, #0x1
    4980:      	sshr.4s	v12, v20, #0x1
    4984:      	shl.4s	v13, v12, #0x17
    4988:      	add.4s	v13, v13, v8
    498c:      	fmul.4s	v27, v27, v13
    4990:      	shl.4s	v13, v10, #0x17
    4994:      	add.4s	v13, v13, v8
    4998:      	fmul.4s	v26, v26, v13
    499c:      	sub.4s	v20, v20, v12
    49a0:      	sub.4s	v28, v28, v10
    49a4:      	shl.4s	v28, v28, #0x17
    49a8:      	add.4s	v28, v28, v8
    49ac:      	fmul.4s	v26, v26, v28
    49b0:      	shl.4s	v20, v20, #0x17
    49b4:      	add.4s	v20, v20, v8
    49b8:      	fmul.4s	v20, v27, v20
    49bc:      	fcmgt.4s	v27, v14, v3
    49c0:      	bic.16b	v20, v20, v27
    49c4:      	fcmgt.4s	v27, v14, v2
    49c8:      	bic.16b	v26, v26, v27
    49cc:      	fcmgt.4s	v27, v2, v15
    49d0:      	ldp	q5, q6, [sp, #0x3e0]
    49d4:      	bit.16b	v26, v6, v27
    49d8:      	fcmgt.4s	v27, v3, v15
    49dc:      	bit.16b	v20, v6, v27
    49e0:      	fcmeq.4s	v3, v3, v3
    49e4:      	bsl.16b	v3, v20, v5
    49e8:      	cmeq.8b	v20, v25, #0
    49ec:      	sshll.8h	v20, v20, #0x0
    49f0:      	fcmeq.4s	v2, v2, v2
    49f4:      	bsl.16b	v2, v26, v5
    49f8:      	sshll2.4s	v26, v20, #0x0
    49fc:      	sshll.4s	v20, v20, #0x0
    4a00:      	bic.16b	v25, v2, v20
    4a04:      	bic.16b	v26, v3, v26
    4a08:      	add	x16, x23, x3
    4a0c:      	ldp	q2, q3, [x16]
    4a10:      	bit.16b	v3, v26, v0
    4a14:      	bit.16b	v2, v25, v1
    4a18:      	stp	q2, q3, [x16]
    4a1c:      	ldr	q2, [sp, #0x340]
    4a20:      	fmov	w9, s2
    4a24:      	ldr	q2, [sp, #0x290]
    4a28:      	add.2d	v2, v16, v2
    4a2c:      	ldr	q3, [sp, #0x430]
    4a30:      	add.2d	v2, v3, v2
    4a34:      	tbz	w9, #0x0, 0x4ab4 <_llm_rows.packet_batch.blocks+0x2ed4>
    4a38:      	fmov	x16, d2
    4a3c:      	ldr	b27, [x16]
    4a40:      	and	w3, w9, #0xff
    4a44:      	tbnz	w3, #0x1, 0x4ac0 <_llm_rows.packet_batch.blocks+0x2ee0>
    4a48:      	b	0x4ac8 <_llm_rows.packet_batch.blocks+0x2ee8>
    4a4c:      	fmov	x9, d2
    4a50:      	ld1.b	{ v25 }[2], [x9]
    4a54:      	tbz	w10, #0x3, 0x481c <_llm_rows.packet_batch.blocks+0x2c3c>
    4a58:      	mov.d	x9, v2[1]
    4a5c:      	ld1.b	{ v25 }[3], [x9]
    4a60:      	ldr	q2, [sp, #0x2b0]
    4a64:      	ldr	q3, [sp, #0x400]
    4a68:      	add.2d	v2, v3, v2
    4a6c:      	ldr	q3, [sp, #0x440]
    4a70:      	add.2d	v2, v3, v2
    4a74:      	tbz	w10, #0x4, 0x4834 <_llm_rows.packet_batch.blocks+0x2c54>
    4a78:      	fmov	x9, d2
    4a7c:      	ld1.b	{ v25 }[4], [x9]
    4a80:      	tbz	w10, #0x5, 0x4838 <_llm_rows.packet_batch.blocks+0x2c58>
    4a84:      	mov.d	x9, v2[1]
    4a88:      	ld1.b	{ v25 }[5], [x9]
    4a8c:      	ldr	q2, [sp, #0x2a0]
    4a90:      	ldr	q3, [sp, #0x420]
    4a94:      	add.2d	v2, v3, v2
    4a98:      	ldr	q3, [sp, #0x360]
    4a9c:      	add.2d	v2, v3, v2
    4aa0:      	tbz	w10, #0x6, 0x4850 <_llm_rows.packet_batch.blocks+0x2c70>
    4aa4:      	fmov	x9, d2
    4aa8:      	ld1.b	{ v25 }[6], [x9]
    4aac:      	tbnz	w10, #0x7, 0x4854 <_llm_rows.packet_batch.blocks+0x2c74>
    4ab0:      	b	0x485c <_llm_rows.packet_batch.blocks+0x2c7c>
    4ab4:      	movi.2d	v27, #0000000000000000
    4ab8:      	and	w3, w9, #0xff
    4abc:      	tbz	w3, #0x1, 0x4ac8 <_llm_rows.packet_batch.blocks+0x2ee8>
    4ac0:      	mov.d	x9, v2[1]
    4ac4:      	ld1.b	{ v27 }[1], [x9]
    4ac8:      	ldr	q2, [sp, #0x280]
    4acc:      	ldr	q3, [sp, #0x410]
    4ad0:      	add.2d	v2, v3, v2
    4ad4:      	ldr	q3, [sp, #0x450]
    4ad8:      	add.2d	v2, v3, v2
    4adc:      	tbnz	w3, #0x2, 0x4d1c <_llm_rows.packet_batch.blocks+0x313c>
    4ae0:      	tbnz	w3, #0x3, 0x4d28 <_llm_rows.packet_batch.blocks+0x3148>
    4ae4:      	ldr	q2, [sp, #0x270]
    4ae8:      	ldr	q3, [sp, #0x400]
    4aec:      	add.2d	v2, v3, v2
    4af0:      	ldr	q3, [sp, #0x440]
    4af4:      	add.2d	v2, v3, v2
    4af8:      	tbnz	w3, #0x4, 0x4d48 <_llm_rows.packet_batch.blocks+0x3168>
    4afc:      	tbnz	w3, #0x5, 0x4d54 <_llm_rows.packet_batch.blocks+0x3174>
    4b00:      	ldr	q2, [sp, #0x260]
    4b04:      	ldr	q3, [sp, #0x420]
    4b08:      	add.2d	v2, v3, v2
    4b0c:      	ldr	q3, [sp, #0x360]
    4b10:      	add.2d	v2, v3, v2
    4b14:      	tbnz	w3, #0x6, 0x4d74 <_llm_rows.packet_batch.blocks+0x3194>
    4b18:      	tbz	w3, #0x7, 0x4b24 <_llm_rows.packet_batch.blocks+0x2f44>
    4b1c:      	mov.d	x9, v2[1]
    4b20:      	ld1.b	{ v27 }[7], [x9]
    4b24:      	add	x3, x10, #0x40
    4b28:      	add	x9, x25, x3
    4b2c:      	ldp	q3, q2, [x9]
    4b30:      	fsub.4s	v20, v3, v18
    4b34:      	fsub.4s	v2, v2, v18
    4b38:      	and.16b	v3, v0, v2
    4b3c:      	and.16b	v2, v1, v20
    4b40:      	fcmge.4s	v20, v2, v14
    4b44:      	fcmge.4s	v28, v3, v14
    4b48:      	fcmge.4s	v10, v15, v2
    4b4c:      	fcmge.4s	v12, v15, v3
    4b50:      	and.16b	v28, v28, v12
    4b54:      	and.16b	v20, v20, v10
    4b58:      	and.16b	v20, v20, v2
    4b5c:      	and.16b	v28, v28, v3
    4b60:      	ldp	q17, q5, [sp, #0x3c0]
    4b64:      	fmul.4s	v10, v28, v5
    4b68:      	fmul.4s	v12, v20, v5
    4b6c:      	mov.16b	v13, v22
    4b70:      	bsl.16b	v13, v7, v12
    4b74:      	mov.16b	v5, v22
    4b78:      	bsl.16b	v5, v7, v10
    4b7c:      	fadd.4s	v10, v10, v5
    4b80:      	fadd.4s	v12, v12, v13
    4b84:      	fsub.4s	v12, v12, v13
    4b88:      	fsub.4s	v5, v10, v5
    4b8c:      	fcvtzs.4s	v5, v5
    4b90:      	fcvtzs.4s	v10, v12
    4b94:      	scvtf.4s	v12, v10
    4b98:      	scvtf.4s	v13, v5
    4b9c:      	fmul.4s	v6, v12, v17
    4ba0:      	fadd.4s	v6, v20, v6
    4ba4:      	fmul.4s	v20, v13, v17
    4ba8:      	fadd.4s	v20, v28, v20
    4bac:      	ldr	q17, [sp, #0x2e0]
    4bb0:      	fmul.4s	v28, v12, v17
    4bb4:      	fmul.4s	v12, v13, v17
    4bb8:      	fadd.4s	v20, v20, v12
    4bbc:      	fadd.4s	v6, v6, v28
    4bc0:      	ldr	q17, [sp, #0x3b0]
    4bc4:      	fmul.4s	v28, v6, v17
    4bc8:      	fmul.4s	v12, v20, v17
    4bcc:      	ldr	q17, [sp, #0x3a0]
    4bd0:      	fadd.4s	v12, v12, v17
    4bd4:      	fadd.4s	v28, v28, v17
    4bd8:      	fmul.4s	v28, v6, v28
    4bdc:      	fmul.4s	v12, v20, v12
    4be0:      	ldr	q17, [sp, #0x390]
    4be4:      	fadd.4s	v12, v12, v17
    4be8:      	fadd.4s	v28, v28, v17
    4bec:      	fmul.4s	v28, v6, v28
    4bf0:      	fmul.4s	v12, v20, v12
    4bf4:      	ldr	q17, [sp, #0x380]
    4bf8:      	fadd.4s	v12, v12, v17
    4bfc:      	fadd.4s	v28, v28, v17
    4c00:      	fmul.4s	v28, v6, v28
    4c04:      	fmul.4s	v12, v20, v12
    4c08:      	ldr	q17, [sp, #0x370]
    4c0c:      	fadd.4s	v12, v12, v17
    4c10:      	fadd.4s	v28, v28, v17
    4c14:      	fmul.4s	v28, v6, v28
    4c18:      	fmul.4s	v12, v20, v12
    4c1c:      	movi.4s	v13, #0x3f, lsl #24
    4c20:      	fadd.4s	v12, v12, v13
    4c24:      	fadd.4s	v28, v28, v13
    4c28:      	fmul.4s	v13, v6, v6
    4c2c:      	fmul.4s	v28, v13, v28
    4c30:      	fmul.4s	v13, v20, v20
    4c34:      	fmul.4s	v12, v13, v12
    4c38:      	fadd.4s	v20, v20, v12
    4c3c:      	fadd.4s	v6, v6, v28
    4c40:      	fadd.4s	v6, v6, v8
    4c44:      	fadd.4s	v20, v20, v8
    4c48:      	sshr.4s	v28, v10, #0x1
    4c4c:      	sshr.4s	v12, v5, #0x1
    4c50:      	shl.4s	v13, v12, #0x17
    4c54:      	add.4s	v13, v13, v8
    4c58:      	fmul.4s	v20, v20, v13
    4c5c:      	shl.4s	v13, v28, #0x17
    4c60:      	add.4s	v13, v13, v8
    4c64:      	fmul.4s	v6, v6, v13
    4c68:      	sub.4s	v5, v5, v12
    4c6c:      	sub.4s	v28, v10, v28
    4c70:      	shl.4s	v28, v28, #0x17
    4c74:      	add.4s	v28, v28, v8
    4c78:      	fmul.4s	v6, v6, v28
    4c7c:      	shl.4s	v5, v5, #0x17
    4c80:      	add.4s	v5, v5, v8
    4c84:      	fmul.4s	v5, v20, v5
    4c88:      	fcmgt.4s	v20, v14, v3
    4c8c:      	bic.16b	v5, v5, v20
    4c90:      	fcmgt.4s	v20, v14, v2
    4c94:      	bic.16b	v6, v6, v20
    4c98:      	fcmgt.4s	v20, v2, v15
    4c9c:      	ldr	q28, [sp, #0x3f0]
    4ca0:      	bit.16b	v6, v28, v20
    4ca4:      	fcmgt.4s	v20, v3, v15
    4ca8:      	bit.16b	v5, v28, v20
    4cac:      	fcmeq.4s	v3, v3, v3
    4cb0:      	ldr	q20, [sp, #0x3e0]
    4cb4:      	bif.16b	v5, v20, v3
    4cb8:      	cmeq.8b	v3, v27, #0
    4cbc:      	sshll.8h	v3, v3, #0x0
    4cc0:      	fcmeq.4s	v2, v2, v2
    4cc4:      	bsl.16b	v2, v6, v20
    4cc8:      	sshll2.4s	v6, v3, #0x0
    4ccc:      	sshll.4s	v3, v3, #0x0
    4cd0:      	bic.16b	v3, v2, v3
    4cd4:      	bic.16b	v2, v5, v6
    4cd8:      	add	x16, x23, x3
    4cdc:      	ldp	q5, q6, [x16]
    4ce0:      	bit.16b	v6, v2, v0
    4ce4:      	bit.16b	v5, v3, v1
    4ce8:      	stp	q5, q6, [x16]
    4cec:      	ldr	q5, [sp, #0x340]
    4cf0:      	fmov	w9, s5
    4cf4:      	ldr	q5, [sp, #0x250]
    4cf8:      	add.2d	v5, v16, v5
    4cfc:      	ldr	q6, [sp, #0x430]
    4d00:      	add.2d	v27, v6, v5
    4d04:      	tbz	w9, #0x0, 0x4d84 <_llm_rows.packet_batch.blocks+0x31a4>
    4d08:      	fmov	x16, d27
    4d0c:      	ldr	b28, [x16]
    4d10:      	and	w3, w9, #0xff
    4d14:      	tbnz	w3, #0x1, 0x4d90 <_llm_rows.packet_batch.blocks+0x31b0>
    4d18:      	b	0x4d98 <_llm_rows.packet_batch.blocks+0x31b8>
    4d1c:      	fmov	x9, d2
    4d20:      	ld1.b	{ v27 }[2], [x9]
    4d24:      	tbz	w3, #0x3, 0x4ae4 <_llm_rows.packet_batch.blocks+0x2f04>
    4d28:      	mov.d	x9, v2[1]
    4d2c:      	ld1.b	{ v27 }[3], [x9]
    4d30:      	ldr	q2, [sp, #0x270]
    4d34:      	ldr	q3, [sp, #0x400]
    4d38:      	add.2d	v2, v3, v2
    4d3c:      	ldr	q3, [sp, #0x440]
    4d40:      	add.2d	v2, v3, v2
    4d44:      	tbz	w3, #0x4, 0x4afc <_llm_rows.packet_batch.blocks+0x2f1c>
    4d48:      	fmov	x9, d2
    4d4c:      	ld1.b	{ v27 }[4], [x9]
    4d50:      	tbz	w3, #0x5, 0x4b00 <_llm_rows.packet_batch.blocks+0x2f20>
    4d54:      	mov.d	x9, v2[1]
    4d58:      	ld1.b	{ v27 }[5], [x9]
    4d5c:      	ldr	q2, [sp, #0x260]
    4d60:      	ldr	q3, [sp, #0x420]
    4d64:      	add.2d	v2, v3, v2
    4d68:      	ldr	q3, [sp, #0x360]
    4d6c:      	add.2d	v2, v3, v2
    4d70:      	tbz	w3, #0x6, 0x4b18 <_llm_rows.packet_batch.blocks+0x2f38>
    4d74:      	fmov	x9, d2
    4d78:      	ld1.b	{ v27 }[6], [x9]
    4d7c:      	tbnz	w3, #0x7, 0x4b1c <_llm_rows.packet_batch.blocks+0x2f3c>
    4d80:      	b	0x4b24 <_llm_rows.packet_batch.blocks+0x2f44>
    4d84:      	movi.2d	v28, #0000000000000000
    4d88:      	and	w3, w9, #0xff
    4d8c:      	tbz	w3, #0x1, 0x4d98 <_llm_rows.packet_batch.blocks+0x31b8>
    4d90:      	mov.d	x9, v27[1]
    4d94:      	ld1.b	{ v28 }[1], [x9]
    4d98:      	ldr	q5, [sp, #0x240]
    4d9c:      	ldr	q6, [sp, #0x410]
    4da0:      	add.2d	v5, v6, v5
    4da4:      	ldr	q6, [sp, #0x450]
    4da8:      	add.2d	v27, v6, v5
    4dac:      	tbnz	w3, #0x2, 0x4e18 <_llm_rows.packet_batch.blocks+0x3238>
    4db0:      	tbnz	w3, #0x3, 0x4e24 <_llm_rows.packet_batch.blocks+0x3244>
    4db4:      	ldr	q5, [sp, #0x230]
    4db8:      	ldr	q6, [sp, #0x400]
    4dbc:      	add.2d	v5, v6, v5
    4dc0:      	ldr	q6, [sp, #0x440]
    4dc4:      	add.2d	v27, v6, v5
    4dc8:      	tbnz	w3, #0x4, 0x4e44 <_llm_rows.packet_batch.blocks+0x3264>
    4dcc:      	tbnz	w3, #0x5, 0x4e50 <_llm_rows.packet_batch.blocks+0x3270>
    4dd0:      	ldr	q5, [sp, #0x220]
    4dd4:      	ldr	q6, [sp, #0x420]
    4dd8:      	add.2d	v5, v6, v5
    4ddc:      	ldr	q6, [sp, #0x360]
    4de0:      	add.2d	v12, v6, v5
    4de4:      	tbz	w3, #0x6, 0x4df0 <_llm_rows.packet_batch.blocks+0x3210>
    4de8:      	fmov	x9, d12
    4dec:      	ld1.b	{ v28 }[6], [x9]
    4df0:      	fadd.4s	v27, v31, v11
    4df4:      	fadd.4s	v11, v30, v21
    4df8:      	fadd.4s	v26, v24, v26
    4dfc:      	fadd.4s	v21, v29, v25
    4e00:      	fadd.4s	v2, v23, v2
    4e04:      	fadd.4s	v25, v9, v3
    4e08:      	tbz	w3, #0x7, 0x42b0 <_llm_rows.packet_batch.blocks+0x26d0>
    4e0c:      	mov.d	x9, v12[1]
    4e10:      	ld1.b	{ v28 }[7], [x9]
    4e14:      	b	0x42b0 <_llm_rows.packet_batch.blocks+0x26d0>
    4e18:      	fmov	x9, d27
    4e1c:      	ld1.b	{ v28 }[2], [x9]
    4e20:      	tbz	w3, #0x3, 0x4db4 <_llm_rows.packet_batch.blocks+0x31d4>
    4e24:      	mov.d	x9, v27[1]
    4e28:      	ld1.b	{ v28 }[3], [x9]
    4e2c:      	ldr	q5, [sp, #0x230]
    4e30:      	ldr	q6, [sp, #0x400]
    4e34:      	add.2d	v5, v6, v5
    4e38:      	ldr	q6, [sp, #0x440]
    4e3c:      	add.2d	v27, v6, v5
    4e40:      	tbz	w3, #0x4, 0x4dcc <_llm_rows.packet_batch.blocks+0x31ec>
    4e44:      	fmov	x9, d27
    4e48:      	ld1.b	{ v28 }[4], [x9]
    4e4c:      	tbz	w3, #0x5, 0x4dd0 <_llm_rows.packet_batch.blocks+0x31f0>
    4e50:      	mov.d	x9, v27[1]
    4e54:      	ld1.b	{ v28 }[5], [x9]
    4e58:      	ldr	q5, [sp, #0x220]
    4e5c:      	ldr	q6, [sp, #0x420]
    4e60:      	add.2d	v5, v6, v5
    4e64:      	ldr	q6, [sp, #0x360]
    4e68:      	add.2d	v12, v6, v5
    4e6c:      	tbnz	w3, #0x6, 0x4de8 <_llm_rows.packet_batch.blocks+0x3208>
    4e70:      	b	0x4df0 <_llm_rows.packet_batch.blocks+0x3210>
    4e74:      	mov	x10, #0x0               ; =0
    4e78:      	ldp	q2, q5, [sp, #0x80]
    4e7c:      	fsub.4s	v3, v5, v18
    4e80:      	fsub.4s	v2, v2, v18
    4e84:      	ldr	q6, [sp, #0x1d0]
    4e88:      	zip2.8b	v5, v6, v0
    4e8c:      	ushll.4s	v5, v5, #0x0
    4e90:      	shl.4s	v5, v5, #0x1f
    4e94:      	cmlt.4s	v18, v5, #0
    4e98:      	and.16b	v2, v18, v2
    4e9c:      	zip1.8b	v5, v6, v0
    4ea0:      	ushll.4s	v5, v5, #0x0
    4ea4:      	shl.4s	v5, v5, #0x1f
    4ea8:      	cmlt.4s	v21, v5, #0
    4eac:      	and.16b	v3, v21, v3
    4eb0:      	fcmge.4s	v5, v2, v14
    4eb4:      	fcmge.4s	v6, v15, v2
    4eb8:      	and.16b	v5, v5, v6
    4ebc:      	fcmge.4s	v6, v3, v14
    4ec0:      	fcmge.4s	v7, v15, v3
    4ec4:      	and.16b	v6, v6, v7
    4ec8:      	and.16b	v6, v6, v3
    4ecc:      	ldp	q16, q26, [sp, #0x3c0]
    4ed0:      	fmul.4s	v7, v6, v26
    4ed4:      	movi.4s	v22, #0x4b, lsl #24
    4ed8:      	mvni.4s	v25, #0x80, lsl #24
    4edc:      	mov.16b	v20, v25
    4ee0:      	bsl.16b	v20, v22, v7
    4ee4:      	fadd.4s	v7, v7, v20
    4ee8:      	fsub.4s	v7, v7, v20
    4eec:      	and.16b	v5, v5, v2
    4ef0:      	fmul.4s	v20, v5, v26
    4ef4:      	bif.16b	v22, v20, v25
    4ef8:      	fadd.4s	v20, v20, v22
    4efc:      	fsub.4s	v20, v20, v22
    4f00:      	fcvtzs.4s	v25, v7
    4f04:      	scvtf.4s	v7, v25
    4f08:      	fmul.4s	v22, v7, v16
    4f0c:      	fadd.4s	v6, v6, v22
    4f10:      	fcvtzs.4s	v20, v20
    4f14:      	scvtf.4s	v22, v20
    4f18:      	fmul.4s	v26, v22, v16
    4f1c:      	fadd.4s	v5, v5, v26
    4f20:      	fmul.4s	v7, v7, v17
    4f24:      	fmul.4s	v22, v22, v17
    4f28:      	fadd.4s	v5, v5, v22
    4f2c:      	fadd.4s	v6, v6, v7
    4f30:      	ldp	q16, q17, [sp, #0x3a0]
    4f34:      	fmul.4s	v7, v6, v17
    4f38:      	fmul.4s	v22, v5, v17
    4f3c:      	fadd.4s	v22, v22, v16
    4f40:      	fadd.4s	v7, v7, v16
    4f44:      	fmul.4s	v7, v6, v7
    4f48:      	fmul.4s	v22, v5, v22
    4f4c:      	ldp	q16, q17, [sp, #0x380]
    4f50:      	fadd.4s	v22, v22, v17
    4f54:      	fadd.4s	v7, v7, v17
    4f58:      	fmul.4s	v7, v6, v7
    4f5c:      	fmul.4s	v22, v5, v22
    4f60:      	fadd.4s	v22, v22, v16
    4f64:      	fadd.4s	v7, v7, v16
    4f68:      	fmul.4s	v7, v6, v7
    4f6c:      	fmul.4s	v16, v5, v22
    4f70:      	ldr	q17, [sp, #0x370]
    4f74:      	fadd.4s	v16, v16, v17
    4f78:      	fadd.4s	v7, v7, v17
    4f7c:      	fmul.4s	v7, v6, v7
    4f80:      	fmul.4s	v16, v5, v16
    4f84:      	movi.4s	v17, #0x3f, lsl #24
    4f88:      	fadd.4s	v16, v16, v17
    4f8c:      	fadd.4s	v7, v7, v17
    4f90:      	fmul.4s	v17, v6, v6
    4f94:      	fmul.4s	v7, v17, v7
    4f98:      	fmul.4s	v17, v5, v5
    4f9c:      	fmul.4s	v16, v17, v16
    4fa0:      	fadd.4s	v5, v5, v16
    4fa4:      	fadd.4s	v6, v6, v7
    4fa8:      	fadd.4s	v5, v5, v8
    4fac:      	sshr.4s	v7, v20, #0x1
    4fb0:      	shl.4s	v16, v7, #0x17
    4fb4:      	add.4s	v16, v16, v8
    4fb8:      	fmul.4s	v5, v5, v16
    4fbc:      	sub.4s	v7, v20, v7
    4fc0:      	shl.4s	v7, v7, #0x17
    4fc4:      	add.4s	v7, v7, v8
    4fc8:      	fmul.4s	v5, v5, v7
    4fcc:      	fcmgt.4s	v7, v14, v2
    4fd0:      	bic.16b	v5, v5, v7
    4fd4:      	fcmgt.4s	v7, v2, v15
    4fd8:      	ldp	q20, q17, [sp, #0x3e0]
    4fdc:      	bit.16b	v5, v17, v7
    4fe0:      	fcmeq.4s	v2, v2, v2
    4fe4:      	bsl.16b	v2, v5, v20
    4fe8:      	fadd.4s	v5, v6, v8
    4fec:      	ldr	q6, [sp, #0xa0]
    4ff0:      	bic.16b	v2, v2, v6
    4ff4:      	fadd.4s	v6, v2, v31
    4ff8:      	and.16b	v6, v18, v6
    4ffc:      	ldr	d22, [sp, #0xc0]
    5000:      	zip2.8b	v7, v22, v0
    5004:      	ushll.4s	v7, v7, #0x0
    5008:      	shl.4s	v7, v7, #0x1f
    500c:      	cmlt.4s	v7, v7, #0
    5010:      	bit.16b	v6, v27, v7
    5014:      	sshr.4s	v7, v25, #0x1
    5018:      	shl.4s	v16, v7, #0x17
    501c:      	add.4s	v16, v16, v8
    5020:      	fmul.4s	v5, v5, v16
    5024:      	sub.4s	v7, v25, v7
    5028:      	shl.4s	v7, v7, #0x17
    502c:      	add.4s	v7, v7, v8
    5030:      	fmul.4s	v5, v5, v7
    5034:      	fcmgt.4s	v7, v14, v3
    5038:      	bic.16b	v5, v5, v7
    503c:      	fcmgt.4s	v7, v3, v15
    5040:      	bit.16b	v5, v17, v7
    5044:      	fcmeq.4s	v3, v3, v3
    5048:      	bsl.16b	v3, v5, v20
    504c:      	ldr	q5, [sp, #0xb0]
    5050:      	sshll.4s	v5, v5, #0x0
    5054:      	bic.16b	v3, v3, v5
    5058:      	fadd.4s	v5, v3, v30
    505c:      	and.16b	v5, v21, v5
    5060:      	zip1.8b	v7, v22, v0
    5064:      	ushll.4s	v7, v7, #0x0
    5068:      	shl.4s	v7, v7, #0x1f
    506c:      	cmlt.4s	v7, v7, #0
    5070:      	bit.16b	v5, v11, v7
    5074:      	fadd.4s	v5, v5, v29
    5078:      	fadd.4s	v6, v6, v24
    507c:      	adrp	x9, 0x5000 <_llm_rows.packet_batch.blocks+0x3420>
    5080:      	ldr	q7, [x9]
    5084:      	and.16b	v20, v0, v7
    5088:      	fadd.4s	v6, v6, v23
    508c:      	adrp	x9, 0x5000 <_llm_rows.packet_batch.blocks+0x3420>
    5090:      	ldr	q7, [x9]
    5094:      	and.16b	v17, v1, v7
    5098:      	fadd.4s	v5, v5, v9
    509c:      	fadd.4s	v4, v5, v4
    50a0:      	fadd.4s	v5, v6, v19
    50a4:      	fmov	w9, s17
    50a8:      	add	x16, sp, #0x4a8
    50ac:      	bfxil	x16, x9, #0, #3
    50b0:      	ldr	q6, [sp, #0x1a0]
    50b4:      	str	d6, [sp, #0x4a8]
    50b8:      	ldrb	w16, [x16]
    50bc:      	add	x3, sp, #0x6d0
    50c0:      	orr	x9, x3, x9, lsl #2
    50c4:      	str	q5, [sp, #0x6e0]
    50c8:      	str	q4, [sp, #0x6d0]
    50cc:      	ldr	s6, [x9]
    50d0:      	tst	w2, w16
    50d4:      	movi	d23, #0000000000000000
    50d8:      	fcsel	s6, s6, s23, ne
    50dc:      	mov.s	w9, v17[1]
    50e0:      	add	x16, sp, #0x4a8
    50e4:      	bfxil	x16, x9, #0, #3
    50e8:      	ldrb	w9, [x16]
    50ec:      	mov	x11, x4
    50f0:      	and	w9, w4, w9
    50f4:      	str	q4, [sp, #0x6b0]
    50f8:      	ldr	s7, [sp, #0x6b0]
    50fc:      	tst	w9, #0x1
    5100:      	fcsel	s7, s7, s23, ne
    5104:      	mov.s	w9, v17[2]
    5108:      	add	x16, sp, #0x690
    510c:      	orr	x16, x16, x9, lsl #2
    5110:      	add	x3, sp, #0x4a8
    5114:      	bfxil	x3, x9, #0, #3
    5118:      	ldrb	w9, [x3]
    511c:      	mov	x14, x24
    5120:      	and	w9, w24, w9
    5124:      	str	q5, [sp, #0x6a0]
    5128:      	str	q4, [sp, #0x690]
    512c:      	ldr	s16, [x16]
    5130:      	tst	w9, #0x1
    5134:      	fcsel	s16, s16, s23, ne
    5138:      	mov.s	w9, v17[3]
    513c:      	add	x16, sp, #0x670
    5140:      	orr	x16, x16, x9, lsl #2
    5144:      	add	x3, sp, #0x4a8
    5148:      	bfxil	x3, x9, #0, #3
    514c:      	ldrb	w9, [x3]
    5150:      	mov	x13, x15
    5154:      	and	w9, w15, w9
    5158:      	str	q5, [sp, #0x680]
    515c:      	str	q4, [sp, #0x670]
    5160:      	ldr	s17, [x16]
    5164:      	tst	w9, #0x1
    5168:      	fcsel	s17, s17, s23, ne
    516c:      	fmov	w9, s20
    5170:      	add	x16, sp, #0x4a8
    5174:      	bfxil	x16, x9, #0, #3
    5178:      	ldrb	w16, [x16]
    517c:      	str	q5, [sp, #0x660]
    5180:      	str	q4, [sp, #0x650]
    5184:      	add	x3, sp, #0x650
    5188:      	ldr	s19, [x3, w9, uxtw #2]
    518c:      	ldp	w4, w1, [sp, #0xd4]
    5190:      	and	w9, w4, w16
    5194:      	tst	w9, #0x1
    5198:      	mov.s	w9, v20[1]
    519c:      	add	x16, sp, #0x4a8
    51a0:      	bfxil	x16, x9, #0, #3
    51a4:      	ldrb	w16, [x16]
    51a8:      	mov.s	w3, v20[2]
    51ac:      	mov.s	w19, v20[3]
    51b0:      	str	q5, [sp, #0x640]
    51b4:      	str	q4, [sp, #0x630]
    51b8:      	add	x24, sp, #0x630
    51bc:      	ldr	s20, [x24, w9, uxtw #2]
    51c0:      	fcsel	s19, s19, s23, ne
    51c4:      	and	w9, w1, w16
    51c8:      	tst	w9, #0x1
    51cc:      	fcsel	s20, s20, s23, ne
    51d0:      	add	x9, sp, #0x4a8
    51d4:      	bfxil	x9, x3, #0, #3
    51d8:      	ldrb	w9, [x9]
    51dc:      	str	q5, [sp, #0x620]
    51e0:      	str	q4, [sp, #0x610]
    51e4:      	mov.s	v19[1], v20[0]
    51e8:      	add	x16, sp, #0x610
    51ec:      	ldr	s20, [x16, w3, uxtw #2]
    51f0:      	ldp	w0, w17, [sp, #0xdc]
    51f4:      	and	w9, w0, w9
    51f8:      	tst	w9, #0x1
    51fc:      	fcsel	s20, s20, s23, ne
    5200:      	add	x9, sp, #0x4a8
    5204:      	bfxil	x9, x19, #0, #3
    5208:      	ldrb	w9, [x9]
    520c:      	and	w9, w17, w9
    5210:      	str	q5, [sp, #0x600]
    5214:      	str	q4, [sp, #0x5f0]
    5218:      	mov.s	v19[2], v20[0]
    521c:      	add	x16, sp, #0x5f0
    5220:      	ldr	s20, [x16, w19, uxtw #2]
    5224:      	tst	w9, #0x1
    5228:      	fcsel	s20, s20, s23, ne
    522c:      	mov.s	v19[3], v20[0]
    5230:      	adrp	x9, 0x5000 <_llm_rows.packet_batch.blocks+0x3420>
    5234:      	ldr	q20, [x9]
    5238:      	mov.s	v6[1], v7[0]
    523c:      	and.16b	v20, v1, v20
    5240:      	mov.s	v6[2], v16[0]
    5244:      	mov.s	v6[3], v17[0]
    5248:      	fadd.4s	v4, v4, v6
    524c:      	fadd.4s	v5, v5, v19
    5250:      	fmov	w9, s20
    5254:      	add	x16, sp, #0x4a8
    5258:      	bfxil	x16, x9, #0, #3
    525c:      	ldrb	w16, [x16]
    5260:      	add	x3, sp, #0x5d0
    5264:      	orr	x9, x3, x9, lsl #2
    5268:      	str	q5, [sp, #0x5e0]
    526c:      	str	q4, [sp, #0x5d0]
    5270:      	ldr	s6, [x9]
    5274:      	tst	w2, w16
    5278:      	mov.s	w9, v20[1]
    527c:      	add	x16, sp, #0x4a8
    5280:      	bfxil	x16, x9, #0, #3
    5284:      	ldrb	w16, [x16]
    5288:      	and	w15, w11, w16
    528c:      	fcsel	s6, s6, s23, ne
    5290:      	add	x16, sp, #0x5b0
    5294:      	orr	x9, x16, x9, lsl #2
    5298:      	str	q5, [sp, #0x5c0]
    529c:      	str	q4, [sp, #0x5b0]
    52a0:      	ldr	s7, [x9]
    52a4:      	tst	w15, #0x1
    52a8:      	mov.s	w9, v20[2]
    52ac:      	add	x15, sp, #0x4a8
    52b0:      	bfxil	x15, x9, #0, #3
    52b4:      	adrp	x9, 0x5000 <_llm_rows.packet_batch.blocks+0x3420>
    52b8:      	ldr	q16, [x9]
    52bc:      	and.16b	v22, v0, v16
    52c0:      	fcsel	s7, s7, s23, ne
    52c4:      	ldrb	w9, [x15]
    52c8:      	and	w9, w14, w9
    52cc:      	str	q4, [sp, #0x590]
    52d0:      	ldr	s16, [sp, #0x590]
    52d4:      	tst	w9, #0x1
    52d8:      	mov.s	w9, v20[3]
    52dc:      	fcsel	s16, s16, s23, ne
    52e0:      	add	x14, sp, #0x4a8
    52e4:      	bfxil	x14, x9, #0, #3
    52e8:      	add	x15, sp, #0x570
    52ec:      	orr	x9, x15, x9, lsl #2
    52f0:      	ldrb	w14, [x14]
    52f4:      	and	w13, w13, w14
    52f8:      	str	q5, [sp, #0x580]
    52fc:      	str	q4, [sp, #0x570]
    5300:      	ldr	s17, [x9]
    5304:      	tst	w13, #0x1
    5308:      	fcsel	s17, s17, s23, ne
    530c:      	fmov	w9, s22
    5310:      	add	x13, sp, #0x4a8
    5314:      	bfxil	x13, x9, #0, #3
    5318:      	ldrb	w13, [x13]
    531c:      	and	w13, w4, w13
    5320:      	str	q5, [sp, #0x560]
    5324:      	str	q4, [sp, #0x550]
    5328:      	add	x14, sp, #0x550
    532c:      	ldr	s19, [x14, w9, uxtw #2]
    5330:      	tst	w13, #0x1
    5334:      	fcsel	s19, s19, s23, ne
    5338:      	mov.s	w9, v22[1]
    533c:      	add	x13, sp, #0x4a8
    5340:      	bfxil	x13, x9, #0, #3
    5344:      	ldrb	w13, [x13]
    5348:      	and	w13, w1, w13
    534c:      	str	q5, [sp, #0x540]
    5350:      	str	q4, [sp, #0x530]
    5354:      	mov.s	w14, v22[2]
    5358:      	mov.s	w15, v22[3]
    535c:      	add	x16, sp, #0x530
    5360:      	ldr	s20, [x16, w9, uxtw #2]
    5364:      	tst	w13, #0x1
    5368:      	fcsel	s20, s20, s23, ne
    536c:      	add	x9, sp, #0x4a8
    5370:      	bfxil	x9, x14, #0, #3
    5374:      	ldrb	w9, [x9]
    5378:      	and	w9, w0, w9
    537c:      	str	q5, [sp, #0x520]
    5380:      	str	q4, [sp, #0x510]
    5384:      	mov.s	v19[1], v20[0]
    5388:      	add	x13, sp, #0x510
    538c:      	ldr	s20, [x13, w14, uxtw #2]
    5390:      	tst	w9, #0x1
    5394:      	fcsel	s20, s20, s23, ne
    5398:      	add	x9, sp, #0x4a8
    539c:      	bfxil	x9, x15, #0, #3
    53a0:      	ldrb	w9, [x9]
    53a4:      	and	w9, w17, w9
    53a8:      	str	q5, [sp, #0x500]
    53ac:      	str	q4, [sp, #0x4f0]
    53b0:      	mov.s	v19[2], v20[0]
    53b4:      	add	x13, sp, #0x4f0
    53b8:      	ldr	s20, [x13, w15, uxtw #2]
    53bc:      	tst	w9, #0x1
    53c0:      	fcsel	s20, s20, s23, ne
    53c4:      	mov.s	v19[3], v20[0]
    53c8:      	mov.s	v6[1], v7[0]
    53cc:      	mov.s	v6[2], v16[0]
    53d0:      	mov.s	v6[3], v17[0]
    53d4:      	fadd.4s	v4, v4, v6
    53d8:      	fadd.4s	v5, v5, v19
    53dc:      	movi.4s	v6, #0x4
    53e0:      	and.16b	v6, v1, v6
    53e4:      	fmov	w9, s6
    53e8:      	add	x13, sp, #0x4a8
    53ec:      	orr	x13, x13, x9
    53f0:      	ldrb	w13, [x13]
    53f4:      	str	q5, [sp, #0x4e0]
    53f8:      	str	q4, [sp, #0x4d0]
    53fc:      	add	x14, x23, x26
    5400:      	ldp	q5, q6, [x14]
    5404:      	bit.16b	v6, v2, v18
    5408:      	add	x15, sp, #0x4d0
    540c:      	ldr	s7, [x15, w9, uxtw #2]
    5410:      	bit.16b	v5, v3, v21
    5414:      	tst	w2, w13
    5418:      	fcsel	s7, s7, s23, ne
    541c:      	ldr	w9, [sp, #0xd0]
    5420:      	tst	w9, #0x1
    5424:      	stp	q5, q6, [x14]
    5428:      	fadd	s4, s4, s7
    542c:      	fcsel	s5, s4, s23, ne
    5430:      	tst	w7, #0x1
    5434:      	fcsel	s6, s4, s23, ne
    5438:      	tst	w30, #0x1
    543c:      	fcsel	s7, s4, s23, ne
    5440:      	tst	w8, #0x1
    5444:      	mov.s	v5[1], v6[0]
    5448:      	fcsel	s6, s4, s23, ne
    544c:      	mov.s	v5[2], v7[0]
    5450:      	tst	w5, #0x1
    5454:      	fcsel	s7, s4, s23, ne
    5458:      	tst	w6, #0x1
    545c:      	mov.s	v5[3], v6[0]
    5460:      	fcsel	s6, s4, s23, ne
    5464:      	ldp	w9, w8, [sp, #0x78]
    5468:      	tst	w9, #0x1
    546c:      	mov.s	v7[1], v6[0]
    5470:      	fcsel	s6, s4, s23, ne
    5474:      	tst	w8, #0x1
    5478:      	fcsel	s4, s4, s23, ne
    547c:      	mov.s	v7[2], v6[0]
    5480:      	mov.s	v7[3], v4[0]
    5484:      	str	q7, [sp, #0x4c0]
    5488:      	str	q5, [sp, #0x4b0]
    548c:      	and	x8, x12, #0x7
    5490:      	add	x9, sp, #0x4b0
    5494:      	ldr	s4, [x9, x8, lsl #2]
    5498:      	fadd	s4, s4, s23
    549c:      	dup.4s	v4, v4[0]
    54a0:      	ldr	q5, [sp, #0x100]
    54a4:      	fmov	x8, d5
    54a8:      	ldp	x13, x12, [sp, #0x158]
    54ac:      	add	x8, x12, x8, lsl #2
    54b0:      	movi.2d	v5, #0000000000000000
    54b4:      	movi.2d	v6, #0000000000000000
    54b8:      	movi.2d	v7, #0000000000000000
    54bc:      	movi.2d	v16, #0000000000000000
    54c0:      	ldr	w15, [sp, #0x168]
    54c4:      	ldp	q20, q19, [sp, #0x200]
    54c8:      	ldp	q22, q21, [sp, #0x1e0]
    54cc:      	b	0x54ec <_llm_rows.packet_batch.blocks+0x390c>
    54d0:      	add.2d	v6, v6, v20
    54d4:      	add.2d	v7, v7, v21
    54d8:      	add.2d	v16, v16, v19
    54dc:      	add.2d	v5, v5, v22
    54e0:      	fmov	x10, d5
    54e4:      	cmp	x10, #0xc0
    54e8:      	b.ge	0x559c <_llm_rows.packet_batch.blocks+0x39bc>
    54ec:      	fmov	w11, s13
    54f0:      	lsl	x9, x10, #5
    54f4:      	add	x10, x23, x9
    54f8:      	ldp	q18, q17, [x10]
    54fc:      	and.16b	v18, v1, v18
    5500:      	fdiv.4s	v18, v18, v4
    5504:      	add	x9, x8, x9
    5508:      	tbnz	w11, #0x0, 0x5538 <_llm_rows.packet_batch.blocks+0x3958>
    550c:      	and	w10, w11, #0xff
    5510:      	tbnz	w10, #0x1, 0x5544 <_llm_rows.packet_batch.blocks+0x3964>
    5514:      	tbnz	w10, #0x2, 0x5550 <_llm_rows.packet_batch.blocks+0x3970>
    5518:      	tbnz	w10, #0x3, 0x555c <_llm_rows.packet_batch.blocks+0x397c>
    551c:      	and.16b	v17, v0, v17
    5520:      	fdiv.4s	v17, v17, v4
    5524:      	tbnz	w10, #0x4, 0x5570 <_llm_rows.packet_batch.blocks+0x3990>
    5528:      	tbnz	w10, #0x5, 0x5578 <_llm_rows.packet_batch.blocks+0x3998>
    552c:      	tbnz	w10, #0x6, 0x5584 <_llm_rows.packet_batch.blocks+0x39a4>
    5530:      	tbz	w10, #0x7, 0x54d0 <_llm_rows.packet_batch.blocks+0x38f0>
    5534:      	b	0x5590 <_llm_rows.packet_batch.blocks+0x39b0>
    5538:      	str	s18, [x9]
    553c:      	and	w10, w11, #0xff
    5540:      	tbz	w10, #0x1, 0x5514 <_llm_rows.packet_batch.blocks+0x3934>
    5544:      	add	x11, x9, #0x4
    5548:      	st1.s	{ v18 }[1], [x11]
    554c:      	tbz	w10, #0x2, 0x5518 <_llm_rows.packet_batch.blocks+0x3938>
    5550:      	add	x11, x9, #0x8
    5554:      	st1.s	{ v18 }[2], [x11]
    5558:      	tbz	w10, #0x3, 0x551c <_llm_rows.packet_batch.blocks+0x393c>
    555c:      	add	x11, x9, #0xc
    5560:      	st1.s	{ v18 }[3], [x11]
    5564:      	and.16b	v17, v0, v17
    5568:      	fdiv.4s	v17, v17, v4
    556c:      	tbz	w10, #0x4, 0x5528 <_llm_rows.packet_batch.blocks+0x3948>
    5570:      	str	s17, [x9, #0x10]
    5574:      	tbz	w10, #0x5, 0x552c <_llm_rows.packet_batch.blocks+0x394c>
    5578:      	add	x11, x9, #0x14
    557c:      	st1.s	{ v17 }[1], [x11]
    5580:      	tbz	w10, #0x6, 0x5530 <_llm_rows.packet_batch.blocks+0x3950>
    5584:      	add	x11, x9, #0x18
    5588:      	st1.s	{ v17 }[2], [x11]
    558c:      	tbz	w10, #0x7, 0x54d0 <_llm_rows.packet_batch.blocks+0x38f0>
    5590:      	add	x9, x9, #0x1c
    5594:      	st1.s	{ v17 }[3], [x9]
    5598:      	b	0x54d0 <_llm_rows.packet_batch.blocks+0x38f0>
    559c:      	ldr	d0, [sp, #0x198]
    55a0:      	fmov	w8, s0
    55a4:      	ldr	q0, [sp, #0x1d0]
    55a8:      	zip1.8b	v0, v0, v0
    55ac:      	ushll.4s	v0, v0, #0x0
    55b0:      	shl.4s	v0, v0, #0x1f
    55b4:      	cmlt.4s	v0, v0, #0
    55b8:      	and.16b	v0, v0, v3
    55bc:      	fdiv.4s	v0, v0, v4
    55c0:      	ldr	q1, [sp, #0x140]
    55c4:      	str	q1, [sp, #0x460]
    55c8:      	ldp	q1, q3, [sp, #0x110]
    55cc:      	str	q3, [sp, #0x470]
    55d0:      	str	q1, [sp, #0x480]
    55d4:      	ldr	q1, [sp, #0x130]
    55d8:      	str	q1, [sp, #0x490]
    55dc:      	and	x9, x13, #0x7
    55e0:      	add	x10, sp, #0x460
    55e4:      	ldr	x9, [x10, x9, lsl #3]
    55e8:      	sub	x9, x9, x13
    55ec:      	add	x9, x12, x9, lsl #2
    55f0:      	tbnz	w8, #0x0, 0x56ac <_llm_rows.packet_batch.blocks+0x3acc>
    55f4:      	tbnz	w8, #0x1, 0x56b4 <_llm_rows.packet_batch.blocks+0x3ad4>
    55f8:      	tbnz	w8, #0x2, 0x56c0 <_llm_rows.packet_batch.blocks+0x3ae0>
    55fc:      	tbz	w8, #0x3, 0x5608 <_llm_rows.packet_batch.blocks+0x3a28>
    5600:      	add	x10, x9, #0xc
    5604:      	st1.s	{ v0 }[3], [x10]
    5608:      	ldr	q0, [sp, #0x1d0]
    560c:      	zip2.8b	v0, v0, v0
    5610:      	ushll.4s	v0, v0, #0x0
    5614:      	shl.4s	v0, v0, #0x1f
    5618:      	cmlt.4s	v0, v0, #0
    561c:      	and.16b	v0, v0, v2
    5620:      	fdiv.4s	v0, v0, v4
    5624:      	tbnz	w8, #0x4, 0x56d0 <_llm_rows.packet_batch.blocks+0x3af0>
    5628:      	tbnz	w8, #0x5, 0x56d8 <_llm_rows.packet_batch.blocks+0x3af8>
    562c:      	tbnz	w8, #0x6, 0x56e4 <_llm_rows.packet_batch.blocks+0x3b04>
    5630:      	tbz	w8, #0x7, 0x1cb8 <_llm_rows.packet_batch.blocks+0xd8>
    5634:      	b	0x56f0 <_llm_rows.packet_batch.blocks+0x3b10>
    5638:      	fmov	x9, d2
    563c:      	ld1.b	{ v19 }[2], [x9]
    5640:      	ldr	q16, [sp, #0x340]
    5644:      	tbz	w3, #0x3, 0x408c <_llm_rows.packet_batch.blocks+0x24ac>
    5648:      	mov.d	x9, v2[1]
    564c:      	ld1.b	{ v19 }[3], [x9]
    5650:      	adrp	x9, 0x5000 <_llm_rows.packet_batch.blocks+0x3420>
    5654:      	ldr	q2, [x9]
    5658:      	and.16b	v2, v4, v2
    565c:      	ldr	q3, [sp, #0x440]
    5660:      	add.2d	v2, v3, v2
    5664:      	tbz	w3, #0x4, 0x40a4 <_llm_rows.packet_batch.blocks+0x24c4>
    5668:      	fmov	x9, d2
    566c:      	ld1.b	{ v19 }[4], [x9]
    5670:      	tbz	w3, #0x5, 0x40a8 <_llm_rows.packet_batch.blocks+0x24c8>
    5674:      	mov.d	x9, v2[1]
    5678:      	ld1.b	{ v19 }[5], [x9]
    567c:      	adrp	x9, 0x5000 <_llm_rows.packet_batch.blocks+0x3420>
    5680:      	ldr	q2, [x9]
    5684:      	and.16b	v2, v10, v2
    5688:      	ldr	q3, [sp, #0x360]
    568c:      	add.2d	v3, v3, v2
    5690:      	tbz	w3, #0x6, 0x40c0 <_llm_rows.packet_batch.blocks+0x24e0>
    5694:      	fmov	x9, d3
    5698:      	ld1.b	{ v19 }[6], [x9]
    569c:      	ldr	q2, [sp, #0x10]
    56a0:      	and.16b	v2, v11, v2
    56a4:      	tbnz	w3, #0x7, 0x40cc <_llm_rows.packet_batch.blocks+0x24ec>
    56a8:      	b	0x40d4 <_llm_rows.packet_batch.blocks+0x24f4>
    56ac:      	str	s0, [x9]
    56b0:      	tbz	w8, #0x1, 0x55f8 <_llm_rows.packet_batch.blocks+0x3a18>
    56b4:      	add	x10, x9, #0x4
    56b8:      	st1.s	{ v0 }[1], [x10]
    56bc:      	tbz	w8, #0x2, 0x55fc <_llm_rows.packet_batch.blocks+0x3a1c>
    56c0:      	add	x10, x9, #0x8
    56c4:      	st1.s	{ v0 }[2], [x10]
    56c8:      	tbnz	w8, #0x3, 0x5600 <_llm_rows.packet_batch.blocks+0x3a20>
    56cc:      	b	0x5608 <_llm_rows.packet_batch.blocks+0x3a28>
    56d0:      	str	s0, [x9, #0x10]
    56d4:      	tbz	w8, #0x5, 0x562c <_llm_rows.packet_batch.blocks+0x3a4c>
    56d8:      	add	x10, x9, #0x14
    56dc:      	st1.s	{ v0 }[1], [x10]
    56e0:      	tbz	w8, #0x6, 0x5630 <_llm_rows.packet_batch.blocks+0x3a50>
    56e4:      	add	x10, x9, #0x18
    56e8:      	st1.s	{ v0 }[2], [x10]
    56ec:      	tbz	w8, #0x7, 0x1cb8 <_llm_rows.packet_batch.blocks+0xd8>
    56f0:      	add	x8, x9, #0x1c
    56f4:      	st1.s	{ v0 }[3], [x8]
    56f8:      	b	0x1cb8 <_llm_rows.packet_batch.blocks+0xd8>
    56fc:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
    5700:      	add	sp, sp, #0x9a0
    5704:      	ldp	x29, x30, [sp, #0x90]
    5708:      	ldp	x20, x19, [sp, #0x80]
    570c:      	ldp	x22, x21, [sp, #0x70]
    5710:      	ldp	x24, x23, [sp, #0x60]
    5714:      	ldp	x26, x25, [sp, #0x50]
    5718:      	ldp	x28, x27, [sp, #0x40]
    571c:      	ldp	d9, d8, [sp, #0x30]
    5720:      	ldp	d11, d10, [sp, #0x20]
    5724:      	ldp	d13, d12, [sp, #0x10]
    5728:      	ldp	d15, d14, [sp], #0xa0
    572c:      	ret


/private/tmp/luisa-expression-fusion.qXgTbC/capture/layernorm-17x65/on/object/tile_xir_w8_23335_1788930261867114_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	cbz	w3, 0x2814 <ltmp0+0x2814>
       4:      	stp	d15, d14, [sp, #-0xa0]!
       8:      	stp	d13, d12, [sp, #0x10]
       c:      	stp	d11, d10, [sp, #0x20]
      10:      	stp	d9, d8, [sp, #0x30]
      14:      	stp	x28, x27, [sp, #0x40]
      18:      	stp	x26, x25, [sp, #0x50]
      1c:      	stp	x24, x23, [sp, #0x60]
      20:      	stp	x22, x21, [sp, #0x70]
      24:      	stp	x20, x19, [sp, #0x80]
      28:      	stp	x29, x30, [sp, #0x90]
      2c:      	sub	sp, sp, #0xb20
      30:      	mov	x19, x3
      34:      	mov	w8, #0x0                ; =0
      38:      	mov	w23, #0x20              ; =32
      3c:      	mov	w10, #0x104             ; =260
      40:      	mov	w11, #0x42820000        ; =1115815936
      44:      	ldp	w24, w25, [x2, #0x2c]
      48:      	mov	w14, #0xc5ac            ; =50604
      4c:      	movk	w14, #0x3727, lsl #16
      50:      	mov	w28, #0x18              ; =24
      54:      	ldp	w1, w7, [x2]
      58:      	add	x6, sp, #0xa00
      5c:      	ldp	w20, w21, [x2, #0x8]
      60:      	mov	w22, #0x4               ; =4
      64:      	add	x26, sp, #0x8e0
      68:      	add	x27, sp, #0x7c0
      6c:      	add	x30, sp, #0x6a0
      70:      	stp	w24, w3, [sp, #0x18]
      74:      	str	w25, [sp, #0x14]
      78:      	b	0xe08 <ltmp0+0xe08>
      7c:      	ldr	x15, [x0]
      80:      	ldr	x13, [x0, #0x10]
      84:      	ldr	x12, [x0, #0x20]
      88:      	ldr	x9, [x0, #0x30]
      8c:      	ubfiz	w17, w1, #2, #27
      90:      	umull	x16, w17, w10
      94:      	umaddl	x3, w17, w10, x15
      98:      	ldp	q0, q1, [x3]
      9c:      	ldp	q3, q2, [x3, #0x20]
      a0:      	ldp	q4, q5, [x3, #0x40]
      a4:      	ldp	q16, q7, [x3, #0x60]
      a8:      	ldp	q17, q18, [x3, #0x80]
      ac:      	ldp	q27, q26, [x3, #0xa0]
      b0:      	ldp	q30, q31, [x3, #0xc0]
      b4:      	ldp	q9, q8, [x3, #0xe0]
      b8:      	add	x16, x16, #0x100
      bc:      	ldr	s10, [x15, x16]
      c0:      	fadd.4s	v6, v16, v9
      c4:      	fadd.4s	v19, v7, v8
      c8:      	fadd.4s	v20, v5, v31
      cc:      	fadd.4s	v21, v4, v30
      d0:      	fadd.4s	v22, v3, v27
      d4:      	fadd.4s	v23, v2, v26
      d8:      	fadd.4s	v24, v1, v18
      dc:      	fadd.4s	v25, v0, v17
      e0:      	fadd.4s	v28, v25, v10
      e4:      	mov.s	v25[0], v28[0]
      e8:      	fadd.4s	v23, v23, v24
      ec:      	fadd.4s	v22, v22, v25
      f0:      	fadd.4s	v21, v21, v22
      f4:      	fadd.4s	v20, v20, v23
      f8:      	fadd.4s	v19, v19, v20
      fc:      	fadd.4s	v6, v6, v21
     100:      	rev64.4s	v20, v6
     104:      	rev64.4s	v21, v19
     108:      	fadd.4s	v19, v19, v21
     10c:      	fadd.4s	v6, v6, v20
     110:      	dup.4s	v20, v6[2]
     114:      	dup.4s	v21, v19[2]
     118:      	fadd.4s	v19, v19, v21
     11c:      	fadd.4s	v6, v6, v20
     120:      	fadd.4s	v6, v6, v19
     124:      	movi	d19, #0000000000000000
     128:      	fadd	s19, s6, s19
     12c:      	movi	d20, #0000000000000000
     130:      	fmov	s6, w11
     134:      	fdiv	s19, s19, s6
     138:      	str	s6, [sp, #0x1a0]
     13c:      	dup.4s	v11, v19[0]
     140:      	fsub.4s	v29, v1, v11
     144:      	fsub.4s	v28, v0, v11
     148:      	fsub.4s	v25, v3, v11
     14c:      	fsub.4s	v12, v2, v11
     150:      	stp	q12, q25, [sp, #0x90]
     154:      	fsub.4s	v24, v5, v11
     158:      	fsub.4s	v23, v4, v11
     15c:      	fsub.4s	v21, v16, v11
     160:      	fsub.4s	v22, v7, v11
     164:      	stp	q23, q22, [sp, #0xe0]
     168:      	fsub.4s	v18, v18, v11
     16c:      	str	q18, [sp, #0xd0]
     170:      	fsub.4s	v19, v17, v11
     174:      	stp	q24, q19, [sp, #0xb0]
     178:      	fsub.4s	v16, v27, v11
     17c:      	stp	q21, q16, [sp, #0x100]
     180:      	fsub.4s	v17, v26, v11
     184:      	fsub.4s	v4, v31, v11
     188:      	fsub.4s	v5, v30, v11
     18c:      	stp	q17, q5, [sp, #0x120]
     190:      	fsub.4s	v1, v9, v11
     194:      	fsub.4s	v2, v8, v11
     198:      	stp	q1, q2, [sp, #0x180]
     19c:      	movi.2d	v0, #0000000000000000
     1a0:      	mov.s	v0[0], v10[0]
     1a4:      	fsub.4s	v3, v0, v11
     1a8:      	ldp	q30, q8, [x13]
     1ac:      	ldp	q7, q0, [x13, #0x20]
     1b0:      	stp	q3, q7, [sp, #0x160]
     1b4:      	stp	q4, q0, [sp, #0x140]
     1b8:      	fmul.4s	v0, v28, v28
     1bc:      	fmul.4s	v7, v29, v29
     1c0:      	fmul.4s	v31, v12, v12
     1c4:      	fmul.4s	v9, v25, v25
     1c8:      	fmul.4s	v10, v23, v23
     1cc:      	fmul.4s	v11, v24, v24
     1d0:      	fmul.4s	v12, v22, v22
     1d4:      	fmul.4s	v13, v21, v21
     1d8:      	fmul.4s	v14, v2, v2
     1dc:      	fmul.4s	v15, v1, v1
     1e0:      	fadd.4s	v2, v13, v15
     1e4:      	fadd.4s	v1, v12, v14
     1e8:      	fmul.4s	v12, v5, v5
     1ec:      	fmul.4s	v13, v4, v4
     1f0:      	fadd.4s	v11, v11, v13
     1f4:      	fadd.4s	v10, v10, v12
     1f8:      	fmul.4s	v12, v17, v17
     1fc:      	fmul.4s	v13, v16, v16
     200:      	fadd.4s	v9, v9, v13
     204:      	fadd.4s	v31, v31, v12
     208:      	fmul.4s	v12, v19, v19
     20c:      	fmul.4s	v13, v18, v18
     210:      	fadd.4s	v7, v7, v13
     214:      	fadd.4s	v0, v0, v12
     218:      	fmul.4s	v12, v3, v3
     21c:      	fadd.4s	v12, v12, v0
     220:      	mov.s	v0[0], v12[0]
     224:      	ldp	q14, q15, [x13, #0x40]
     228:      	fadd.4s	v7, v31, v7
     22c:      	fadd.4s	v0, v9, v0
     230:      	ldp	q12, q13, [x13, #0x60]
     234:      	fadd.4s	v0, v10, v0
     238:      	fadd.4s	v7, v11, v7
     23c:      	ldp	q3, q11, [x13, #0x80]
     240:      	str	q3, [sp, #0x80]
     244:      	fadd.4s	v1, v1, v7
     248:      	fadd.4s	v0, v2, v0
     24c:      	rev64.4s	v2, v0
     250:      	rev64.4s	v7, v1
     254:      	fadd.4s	v1, v1, v7
     258:      	fadd.4s	v0, v0, v2
     25c:      	dup.4s	v2, v0[2]
     260:      	dup.4s	v7, v1[2]
     264:      	fadd.4s	v1, v1, v7
     268:      	fadd.4s	v0, v0, v2
     26c:      	fadd.4s	v0, v0, v1
     270:      	fadd	s0, s0, s20
     274:      	fdiv	s0, s0, s6
     278:      	fmov	s1, w14
     27c:      	str	s1, [sp, #0x1b0]
     280:      	fadd	s0, s0, s1
     284:      	fsqrt	s31, s0
     288:      	dup.4s	v10, v31[0]
     28c:      	fdiv.4s	v0, v29, v10
     290:      	fmul.4s	v0, v8, v0
     294:      	ldp	q2, q1, [x12]
     298:      	fdiv.4s	v28, v28, v10
     29c:      	fmul.4s	v28, v30, v28
     2a0:      	fadd.4s	v3, v2, v28
     2a4:      	ldp	q24, q28, [x13, #0xa0]
     2a8:      	umaddl	x17, w17, w10, x9
     2ac:      	fadd.4s	v0, v1, v0
     2b0:      	ldp	q30, q8, [x13, #0xc0]
     2b4:      	ldp	q26, q29, [x13, #0xe0]
     2b8:      	ldr	s27, [x13, #0x100]
     2bc:      	ldp	q1, q2, [x12, #0x20]
     2c0:      	ldp	q4, q5, [x12, #0x40]
     2c4:      	ldp	q6, q7, [x12, #0x60]
     2c8:      	ldp	q16, q17, [x12, #0x80]
     2cc:      	ldp	q18, q19, [x12, #0xa0]
     2d0:      	ldp	q20, q21, [x12, #0xc0]
     2d4:      	ldp	q22, q23, [x12, #0xe0]
     2d8:      	ldr	s25, [x12, #0x100]
     2dc:      	stp	q3, q0, [x17]
     2e0:      	ldr	q0, [sp, #0x90]
     2e4:      	fdiv.4s	v0, v0, v10
     2e8:      	ldr	q3, [sp, #0x150]
     2ec:      	fmul.4s	v0, v3, v0
     2f0:      	ldr	q3, [sp, #0xa0]
     2f4:      	fdiv.4s	v3, v3, v10
     2f8:      	ldr	q9, [sp, #0x170]
     2fc:      	fmul.4s	v3, v9, v3
     300:      	fadd.4s	v1, v1, v3
     304:      	fadd.4s	v0, v2, v0
     308:      	stp	q1, q0, [x17, #0x20]
     30c:      	ldr	q0, [sp, #0xb0]
     310:      	fdiv.4s	v0, v0, v10
     314:      	fmul.4s	v0, v15, v0
     318:      	ldr	q1, [sp, #0xe0]
     31c:      	fdiv.4s	v1, v1, v10
     320:      	fmul.4s	v1, v14, v1
     324:      	fadd.4s	v1, v4, v1
     328:      	fadd.4s	v0, v5, v0
     32c:      	stp	q1, q0, [x17, #0x40]
     330:      	ldp	q0, q1, [sp, #0xf0]
     334:      	fdiv.4s	v0, v0, v10
     338:      	fmul.4s	v0, v13, v0
     33c:      	fdiv.4s	v1, v1, v10
     340:      	fmul.4s	v1, v12, v1
     344:      	fadd.4s	v1, v6, v1
     348:      	fadd.4s	v0, v7, v0
     34c:      	stp	q1, q0, [x17, #0x60]
     350:      	ldp	q0, q1, [sp, #0xc0]
     354:      	fdiv.4s	v0, v0, v10
     358:      	fdiv.4s	v1, v1, v10
     35c:      	fmul.4s	v1, v11, v1
     360:      	ldr	q2, [sp, #0x80]
     364:      	fmul.4s	v0, v2, v0
     368:      	fadd.4s	v0, v16, v0
     36c:      	fadd.4s	v1, v17, v1
     370:      	stp	q0, q1, [x17, #0x80]
     374:      	ldp	q0, q1, [sp, #0x110]
     378:      	fdiv.4s	v0, v0, v10
     37c:      	fdiv.4s	v1, v1, v10
     380:      	fmul.4s	v1, v28, v1
     384:      	fmul.4s	v0, v24, v0
     388:      	fadd.4s	v0, v18, v0
     38c:      	fadd.4s	v1, v19, v1
     390:      	stp	q0, q1, [x17, #0xa0]
     394:      	ldp	q0, q1, [sp, #0x130]
     398:      	fdiv.4s	v0, v0, v10
     39c:      	fdiv.4s	v1, v1, v10
     3a0:      	fmul.4s	v1, v8, v1
     3a4:      	fmul.4s	v0, v30, v0
     3a8:      	fadd.4s	v0, v20, v0
     3ac:      	fadd.4s	v1, v21, v1
     3b0:      	stp	q0, q1, [x17, #0xc0]
     3b4:      	ldp	q0, q1, [sp, #0x180]
     3b8:      	fdiv.4s	v0, v0, v10
     3bc:      	fdiv.4s	v1, v1, v10
     3c0:      	fmul.4s	v1, v29, v1
     3c4:      	fmul.4s	v0, v26, v0
     3c8:      	fadd.4s	v0, v22, v0
     3cc:      	fadd.4s	v1, v23, v1
     3d0:      	stp	q0, q1, [x17, #0xe0]
     3d4:      	ldr	q0, [sp, #0x160]
     3d8:      	fdiv.4s	v0, v0, v31
     3dc:      	fmul.4s	v0, v27, v0
     3e0:      	fadd.4s	v0, v25, v0
     3e4:      	str	s0, [x9, x16]
     3e8:      	mov	w17, #0x1               ; =1
     3ec:      	bfi	w17, w1, #2, #27
     3f0:      	umull	x16, w17, w10
     3f4:      	umaddl	x3, w17, w10, x15
     3f8:      	ldp	q0, q1, [x3]
     3fc:      	ldp	q3, q2, [x3, #0x20]
     400:      	ldp	q4, q5, [x3, #0x40]
     404:      	ldp	q7, q6, [x3, #0x60]
     408:      	ldp	q16, q17, [x3, #0x80]
     40c:      	ldp	q27, q26, [x3, #0xa0]
     410:      	ldp	q30, q31, [x3, #0xc0]
     414:      	ldp	q9, q8, [x3, #0xe0]
     418:      	add	x16, x16, #0x100
     41c:      	ldr	s10, [x15, x16]
     420:      	fadd.4s	v18, v7, v9
     424:      	fadd.4s	v19, v6, v8
     428:      	fadd.4s	v20, v5, v31
     42c:      	fadd.4s	v21, v4, v30
     430:      	fadd.4s	v22, v3, v27
     434:      	fadd.4s	v23, v2, v26
     438:      	fadd.4s	v24, v1, v17
     43c:      	fadd.4s	v25, v0, v16
     440:      	fadd.4s	v28, v25, v10
     444:      	mov.s	v25[0], v28[0]
     448:      	fadd.4s	v23, v23, v24
     44c:      	fadd.4s	v22, v22, v25
     450:      	fadd.4s	v21, v21, v22
     454:      	fadd.4s	v20, v20, v23
     458:      	fadd.4s	v19, v19, v20
     45c:      	fadd.4s	v18, v18, v21
     460:      	rev64.4s	v20, v18
     464:      	rev64.4s	v21, v19
     468:      	fadd.4s	v19, v19, v21
     46c:      	fadd.4s	v18, v18, v20
     470:      	dup.4s	v20, v18[2]
     474:      	dup.4s	v21, v19[2]
     478:      	fadd.4s	v19, v19, v21
     47c:      	fadd.4s	v18, v18, v20
     480:      	fadd.4s	v18, v18, v19
     484:      	movi	d20, #0000000000000000
     488:      	fadd	s18, s18, s20
     48c:      	ldr	s19, [sp, #0x1a0]
     490:      	fdiv	s18, s18, s19
     494:      	dup.4s	v11, v18[0]
     498:      	fsub.4s	v29, v1, v11
     49c:      	fsub.4s	v28, v0, v11
     4a0:      	fsub.4s	v12, v3, v11
     4a4:      	fsub.4s	v13, v2, v11
     4a8:      	stp	q13, q12, [sp, #0x90]
     4ac:      	fsub.4s	v25, v5, v11
     4b0:      	fsub.4s	v24, v4, v11
     4b4:      	stp	q25, q24, [sp, #0xd0]
     4b8:      	fsub.4s	v22, v7, v11
     4bc:      	fsub.4s	v23, v6, v11
     4c0:      	stp	q23, q22, [sp, #0xf0]
     4c4:      	fsub.4s	v18, v17, v11
     4c8:      	fsub.4s	v21, v16, v11
     4cc:      	stp	q21, q18, [sp, #0xb0]
     4d0:      	fsub.4s	v16, v27, v11
     4d4:      	fsub.4s	v17, v26, v11
     4d8:      	stp	q17, q16, [sp, #0x110]
     4dc:      	fsub.4s	v4, v31, v11
     4e0:      	fsub.4s	v5, v30, v11
     4e4:      	stp	q5, q4, [sp, #0x130]
     4e8:      	fsub.4s	v1, v9, v11
     4ec:      	fsub.4s	v3, v8, v11
     4f0:      	stp	q3, q1, [sp, #0x180]
     4f4:      	movi.2d	v0, #0000000000000000
     4f8:      	mov.s	v0[0], v10[0]
     4fc:      	fsub.4s	v2, v0, v11
     500:      	ldp	q30, q31, [x13]
     504:      	ldp	q6, q0, [x13, #0x20]
     508:      	str	q6, [sp, #0x170]
     50c:      	stp	q2, q0, [sp, #0x150]
     510:      	fmul.4s	v0, v28, v28
     514:      	fmul.4s	v6, v29, v29
     518:      	fmul.4s	v7, v13, v13
     51c:      	fmul.4s	v8, v12, v12
     520:      	fmul.4s	v9, v24, v24
     524:      	fmul.4s	v10, v25, v25
     528:      	fmul.4s	v11, v23, v23
     52c:      	fmul.4s	v12, v22, v22
     530:      	fmul.4s	v13, v1, v1
     534:      	fadd.4s	v1, v12, v13
     538:      	fmul.4s	v12, v3, v3
     53c:      	fadd.4s	v11, v11, v12
     540:      	fmul.4s	v12, v4, v4
     544:      	fadd.4s	v10, v10, v12
     548:      	fmul.4s	v12, v5, v5
     54c:      	fadd.4s	v9, v9, v12
     550:      	fmul.4s	v12, v16, v16
     554:      	fadd.4s	v8, v8, v12
     558:      	fmul.4s	v12, v17, v17
     55c:      	fadd.4s	v7, v7, v12
     560:      	fmul.4s	v12, v18, v18
     564:      	fadd.4s	v6, v6, v12
     568:      	fmul.4s	v12, v21, v21
     56c:      	fadd.4s	v0, v0, v12
     570:      	fmul.4s	v12, v2, v2
     574:      	fadd.4s	v12, v12, v0
     578:      	mov.s	v0[0], v12[0]
     57c:      	fadd.4s	v6, v7, v6
     580:      	ldp	q14, q15, [x13, #0x40]
     584:      	fadd.4s	v0, v8, v0
     588:      	fadd.4s	v0, v9, v0
     58c:      	ldp	q12, q13, [x13, #0x60]
     590:      	fadd.4s	v6, v10, v6
     594:      	fadd.4s	v6, v11, v6
     598:      	ldp	q2, q11, [x13, #0x80]
     59c:      	str	q2, [sp, #0x80]
     5a0:      	fadd.4s	v0, v1, v0
     5a4:      	rev64.4s	v1, v6
     5a8:      	fadd.4s	v1, v6, v1
     5ac:      	rev64.4s	v6, v0
     5b0:      	fadd.4s	v0, v0, v6
     5b4:      	dup.4s	v6, v1[2]
     5b8:      	fadd.4s	v1, v1, v6
     5bc:      	dup.4s	v6, v0[2]
     5c0:      	fadd.4s	v0, v0, v6
     5c4:      	fadd.4s	v0, v0, v1
     5c8:      	fadd	s0, s0, s20
     5cc:      	fdiv	s0, s0, s19
     5d0:      	ldr	s1, [sp, #0x1b0]
     5d4:      	fadd	s0, s0, s1
     5d8:      	fsqrt	s8, s0
     5dc:      	dup.4s	v10, v8[0]
     5e0:      	fdiv.4s	v0, v29, v10
     5e4:      	fmul.4s	v0, v31, v0
     5e8:      	ldp	q6, q1, [x12]
     5ec:      	fdiv.4s	v7, v28, v10
     5f0:      	fmul.4s	v7, v30, v7
     5f4:      	fadd.4s	v6, v6, v7
     5f8:      	ldp	q25, q24, [x13, #0xa0]
     5fc:      	umaddl	x17, w17, w10, x9
     600:      	fadd.4s	v1, v1, v0
     604:      	ldp	q30, q31, [x13, #0xc0]
     608:      	ldp	q27, q29, [x13, #0xe0]
     60c:      	ldr	s28, [x13, #0x100]
     610:      	ldp	q0, q2, [x12, #0x20]
     614:      	ldp	q3, q4, [x12, #0x40]
     618:      	ldp	q5, q7, [x12, #0x60]
     61c:      	ldp	q16, q17, [x12, #0x80]
     620:      	ldp	q18, q19, [x12, #0xa0]
     624:      	ldp	q20, q21, [x12, #0xc0]
     628:      	ldp	q22, q23, [x12, #0xe0]
     62c:      	ldr	s26, [x12, #0x100]
     630:      	stp	q6, q1, [x17]
     634:      	ldr	q1, [sp, #0x90]
     638:      	fdiv.4s	v1, v1, v10
     63c:      	ldp	q6, q9, [sp, #0x160]
     640:      	fmul.4s	v1, v6, v1
     644:      	ldr	q6, [sp, #0xa0]
     648:      	fdiv.4s	v6, v6, v10
     64c:      	fmul.4s	v6, v9, v6
     650:      	fadd.4s	v0, v0, v6
     654:      	fadd.4s	v1, v2, v1
     658:      	stp	q0, q1, [x17, #0x20]
     65c:      	ldp	q0, q1, [sp, #0xd0]
     660:      	fdiv.4s	v0, v0, v10
     664:      	fmul.4s	v0, v15, v0
     668:      	fdiv.4s	v1, v1, v10
     66c:      	fmul.4s	v1, v14, v1
     670:      	fadd.4s	v1, v3, v1
     674:      	fadd.4s	v0, v4, v0
     678:      	stp	q1, q0, [x17, #0x40]
     67c:      	ldp	q0, q1, [sp, #0xf0]
     680:      	fdiv.4s	v0, v0, v10
     684:      	fmul.4s	v0, v13, v0
     688:      	fdiv.4s	v1, v1, v10
     68c:      	fmul.4s	v1, v12, v1
     690:      	fadd.4s	v1, v5, v1
     694:      	fadd.4s	v0, v7, v0
     698:      	stp	q1, q0, [x17, #0x60]
     69c:      	ldp	q0, q1, [sp, #0xb0]
     6a0:      	fdiv.4s	v0, v0, v10
     6a4:      	fdiv.4s	v1, v1, v10
     6a8:      	fmul.4s	v1, v11, v1
     6ac:      	ldr	q2, [sp, #0x80]
     6b0:      	fmul.4s	v0, v2, v0
     6b4:      	fadd.4s	v0, v16, v0
     6b8:      	fadd.4s	v1, v17, v1
     6bc:      	stp	q0, q1, [x17, #0x80]
     6c0:      	ldp	q1, q0, [sp, #0x110]
     6c4:      	fdiv.4s	v0, v0, v10
     6c8:      	fdiv.4s	v1, v1, v10
     6cc:      	fmul.4s	v1, v24, v1
     6d0:      	fmul.4s	v0, v25, v0
     6d4:      	fadd.4s	v0, v18, v0
     6d8:      	fadd.4s	v1, v19, v1
     6dc:      	stp	q0, q1, [x17, #0xa0]
     6e0:      	ldp	q0, q1, [sp, #0x130]
     6e4:      	fdiv.4s	v0, v0, v10
     6e8:      	fdiv.4s	v1, v1, v10
     6ec:      	fmul.4s	v1, v31, v1
     6f0:      	fmul.4s	v0, v30, v0
     6f4:      	fadd.4s	v0, v20, v0
     6f8:      	fadd.4s	v1, v21, v1
     6fc:      	stp	q0, q1, [x17, #0xc0]
     700:      	ldp	q1, q0, [sp, #0x180]
     704:      	fdiv.4s	v0, v0, v10
     708:      	fdiv.4s	v1, v1, v10
     70c:      	fmul.4s	v1, v29, v1
     710:      	fmul.4s	v0, v27, v0
     714:      	fadd.4s	v0, v22, v0
     718:      	fadd.4s	v1, v23, v1
     71c:      	stp	q0, q1, [x17, #0xe0]
     720:      	ldr	q0, [sp, #0x150]
     724:      	fdiv.4s	v0, v0, v8
     728:      	fmul.4s	v0, v28, v0
     72c:      	fadd.4s	v0, v26, v0
     730:      	str	s0, [x9, x16]
     734:      	mov	w17, #0x2               ; =2
     738:      	bfi	w17, w1, #2, #27
     73c:      	umull	x16, w17, w10
     740:      	umaddl	x3, w17, w10, x15
     744:      	ldp	q0, q1, [x3]
     748:      	ldp	q3, q2, [x3, #0x20]
     74c:      	ldp	q4, q5, [x3, #0x40]
     750:      	ldp	q7, q6, [x3, #0x60]
     754:      	ldp	q16, q17, [x3, #0x80]
     758:      	ldp	q27, q26, [x3, #0xa0]
     75c:      	ldp	q30, q31, [x3, #0xc0]
     760:      	ldp	q9, q8, [x3, #0xe0]
     764:      	add	x16, x16, #0x100
     768:      	ldr	s10, [x15, x16]
     76c:      	fadd.4s	v18, v7, v9
     770:      	fadd.4s	v19, v6, v8
     774:      	fadd.4s	v20, v5, v31
     778:      	fadd.4s	v21, v4, v30
     77c:      	fadd.4s	v22, v3, v27
     780:      	fadd.4s	v23, v2, v26
     784:      	fadd.4s	v24, v1, v17
     788:      	fadd.4s	v25, v0, v16
     78c:      	fadd.4s	v28, v25, v10
     790:      	mov.s	v25[0], v28[0]
     794:      	fadd.4s	v23, v23, v24
     798:      	fadd.4s	v22, v22, v25
     79c:      	fadd.4s	v21, v21, v22
     7a0:      	fadd.4s	v20, v20, v23
     7a4:      	fadd.4s	v19, v19, v20
     7a8:      	fadd.4s	v18, v18, v21
     7ac:      	rev64.4s	v20, v18
     7b0:      	rev64.4s	v21, v19
     7b4:      	fadd.4s	v19, v19, v21
     7b8:      	fadd.4s	v18, v18, v20
     7bc:      	dup.4s	v20, v18[2]
     7c0:      	dup.4s	v21, v19[2]
     7c4:      	fadd.4s	v19, v19, v21
     7c8:      	fadd.4s	v18, v18, v20
     7cc:      	fadd.4s	v18, v18, v19
     7d0:      	movi	d19, #0000000000000000
     7d4:      	fadd	s18, s18, s19
     7d8:      	ldr	s20, [sp, #0x1a0]
     7dc:      	fdiv	s18, s18, s20
     7e0:      	dup.4s	v11, v18[0]
     7e4:      	fsub.4s	v29, v1, v11
     7e8:      	fsub.4s	v28, v0, v11
     7ec:      	fsub.4s	v12, v3, v11
     7f0:      	fsub.4s	v13, v2, v11
     7f4:      	stp	q13, q12, [sp, #0x90]
     7f8:      	fsub.4s	v25, v5, v11
     7fc:      	fsub.4s	v24, v4, v11
     800:      	stp	q25, q24, [sp, #0xd0]
     804:      	fsub.4s	v22, v7, v11
     808:      	fsub.4s	v23, v6, v11
     80c:      	stp	q23, q22, [sp, #0xf0]
     810:      	fsub.4s	v18, v17, v11
     814:      	fsub.4s	v21, v16, v11
     818:      	stp	q21, q18, [sp, #0xb0]
     81c:      	fsub.4s	v16, v27, v11
     820:      	fsub.4s	v17, v26, v11
     824:      	stp	q17, q16, [sp, #0x110]
     828:      	fsub.4s	v4, v31, v11
     82c:      	fsub.4s	v5, v30, v11
     830:      	stp	q5, q4, [sp, #0x130]
     834:      	fsub.4s	v1, v9, v11
     838:      	fsub.4s	v3, v8, v11
     83c:      	stp	q3, q1, [sp, #0x180]
     840:      	movi.2d	v0, #0000000000000000
     844:      	mov.s	v0[0], v10[0]
     848:      	fsub.4s	v2, v0, v11
     84c:      	ldp	q30, q31, [x13]
     850:      	ldp	q6, q0, [x13, #0x20]
     854:      	str	q6, [sp, #0x170]
     858:      	stp	q2, q0, [sp, #0x150]
     85c:      	fmul.4s	v0, v28, v28
     860:      	fmul.4s	v6, v29, v29
     864:      	fmul.4s	v7, v13, v13
     868:      	fmul.4s	v8, v12, v12
     86c:      	fmul.4s	v9, v24, v24
     870:      	fmul.4s	v10, v25, v25
     874:      	fmul.4s	v11, v23, v23
     878:      	fmul.4s	v12, v22, v22
     87c:      	fmul.4s	v13, v1, v1
     880:      	fadd.4s	v1, v12, v13
     884:      	fmul.4s	v12, v3, v3
     888:      	fadd.4s	v11, v11, v12
     88c:      	fmul.4s	v12, v4, v4
     890:      	fadd.4s	v10, v10, v12
     894:      	fmul.4s	v12, v5, v5
     898:      	fadd.4s	v9, v9, v12
     89c:      	fmul.4s	v12, v16, v16
     8a0:      	fadd.4s	v8, v8, v12
     8a4:      	fmul.4s	v12, v17, v17
     8a8:      	fadd.4s	v7, v7, v12
     8ac:      	fmul.4s	v12, v18, v18
     8b0:      	fadd.4s	v6, v6, v12
     8b4:      	fmul.4s	v12, v21, v21
     8b8:      	fadd.4s	v0, v0, v12
     8bc:      	fmul.4s	v12, v2, v2
     8c0:      	fadd.4s	v12, v12, v0
     8c4:      	mov.s	v0[0], v12[0]
     8c8:      	fadd.4s	v6, v7, v6
     8cc:      	ldp	q14, q15, [x13, #0x40]
     8d0:      	fadd.4s	v0, v8, v0
     8d4:      	fadd.4s	v0, v9, v0
     8d8:      	ldp	q12, q13, [x13, #0x60]
     8dc:      	fadd.4s	v6, v10, v6
     8e0:      	fadd.4s	v6, v11, v6
     8e4:      	ldp	q2, q11, [x13, #0x80]
     8e8:      	str	q2, [sp, #0x80]
     8ec:      	fadd.4s	v0, v1, v0
     8f0:      	rev64.4s	v1, v6
     8f4:      	fadd.4s	v1, v6, v1
     8f8:      	rev64.4s	v6, v0
     8fc:      	fadd.4s	v0, v0, v6
     900:      	dup.4s	v6, v1[2]
     904:      	fadd.4s	v1, v1, v6
     908:      	dup.4s	v6, v0[2]
     90c:      	fadd.4s	v0, v0, v6
     910:      	fadd.4s	v0, v0, v1
     914:      	fadd	s0, s0, s19
     918:      	fdiv	s0, s0, s20
     91c:      	ldr	s1, [sp, #0x1b0]
     920:      	fadd	s0, s0, s1
     924:      	fsqrt	s8, s0
     928:      	dup.4s	v10, v8[0]
     92c:      	fdiv.4s	v0, v29, v10
     930:      	fmul.4s	v0, v31, v0
     934:      	ldp	q6, q1, [x12]
     938:      	fdiv.4s	v7, v28, v10
     93c:      	fmul.4s	v7, v30, v7
     940:      	fadd.4s	v6, v6, v7
     944:      	ldp	q25, q24, [x13, #0xa0]
     948:      	umaddl	x17, w17, w10, x9
     94c:      	fadd.4s	v1, v1, v0
     950:      	ldp	q30, q31, [x13, #0xc0]
     954:      	ldp	q27, q29, [x13, #0xe0]
     958:      	ldr	s28, [x13, #0x100]
     95c:      	ldp	q0, q2, [x12, #0x20]
     960:      	ldp	q3, q4, [x12, #0x40]
     964:      	ldp	q5, q7, [x12, #0x60]
     968:      	ldp	q16, q17, [x12, #0x80]
     96c:      	ldp	q18, q19, [x12, #0xa0]
     970:      	ldp	q20, q21, [x12, #0xc0]
     974:      	ldp	q22, q23, [x12, #0xe0]
     978:      	ldr	s26, [x12, #0x100]
     97c:      	stp	q6, q1, [x17]
     980:      	ldr	q1, [sp, #0x90]
     984:      	fdiv.4s	v1, v1, v10
     988:      	ldp	q6, q9, [sp, #0x160]
     98c:      	fmul.4s	v1, v6, v1
     990:      	ldr	q6, [sp, #0xa0]
     994:      	fdiv.4s	v6, v6, v10
     998:      	fmul.4s	v6, v9, v6
     99c:      	fadd.4s	v0, v0, v6
     9a0:      	fadd.4s	v1, v2, v1
     9a4:      	stp	q0, q1, [x17, #0x20]
     9a8:      	ldp	q0, q1, [sp, #0xd0]
     9ac:      	fdiv.4s	v0, v0, v10
     9b0:      	fmul.4s	v0, v15, v0
     9b4:      	fdiv.4s	v1, v1, v10
     9b8:      	fmul.4s	v1, v14, v1
     9bc:      	fadd.4s	v1, v3, v1
     9c0:      	fadd.4s	v0, v4, v0
     9c4:      	stp	q1, q0, [x17, #0x40]
     9c8:      	ldp	q0, q1, [sp, #0xf0]
     9cc:      	fdiv.4s	v0, v0, v10
     9d0:      	fmul.4s	v0, v13, v0
     9d4:      	fdiv.4s	v1, v1, v10
     9d8:      	fmul.4s	v1, v12, v1
     9dc:      	fadd.4s	v1, v5, v1
     9e0:      	fadd.4s	v0, v7, v0
     9e4:      	stp	q1, q0, [x17, #0x60]
     9e8:      	ldp	q0, q1, [sp, #0xb0]
     9ec:      	fdiv.4s	v0, v0, v10
     9f0:      	fdiv.4s	v1, v1, v10
     9f4:      	fmul.4s	v1, v11, v1
     9f8:      	ldr	q2, [sp, #0x80]
     9fc:      	fmul.4s	v0, v2, v0
     a00:      	fadd.4s	v0, v16, v0
     a04:      	fadd.4s	v1, v17, v1
     a08:      	stp	q0, q1, [x17, #0x80]
     a0c:      	ldp	q1, q0, [sp, #0x110]
     a10:      	fdiv.4s	v0, v0, v10
     a14:      	fdiv.4s	v1, v1, v10
     a18:      	fmul.4s	v1, v24, v1
     a1c:      	fmul.4s	v0, v25, v0
     a20:      	fadd.4s	v0, v18, v0
     a24:      	fadd.4s	v1, v19, v1
     a28:      	stp	q0, q1, [x17, #0xa0]
     a2c:      	ldp	q0, q1, [sp, #0x130]
     a30:      	fdiv.4s	v0, v0, v10
     a34:      	fdiv.4s	v1, v1, v10
     a38:      	fmul.4s	v1, v31, v1
     a3c:      	fmul.4s	v0, v30, v0
     a40:      	fadd.4s	v0, v20, v0
     a44:      	fadd.4s	v1, v21, v1
     a48:      	stp	q0, q1, [x17, #0xc0]
     a4c:      	ldp	q1, q0, [sp, #0x180]
     a50:      	fdiv.4s	v0, v0, v10
     a54:      	fdiv.4s	v1, v1, v10
     a58:      	fmul.4s	v1, v29, v1
     a5c:      	fmul.4s	v0, v27, v0
     a60:      	fadd.4s	v0, v22, v0
     a64:      	fadd.4s	v1, v23, v1
     a68:      	stp	q0, q1, [x17, #0xe0]
     a6c:      	ldr	q0, [sp, #0x150]
     a70:      	fdiv.4s	v0, v0, v8
     a74:      	fmul.4s	v0, v28, v0
     a78:      	fadd.4s	v0, v26, v0
     a7c:      	str	s0, [x9, x16]
     a80:      	mov	w17, #0x3               ; =3
     a84:      	bfi	w17, w1, #2, #27
     a88:      	umull	x16, w17, w10
     a8c:      	umaddl	x3, w17, w10, x15
     a90:      	ldp	q0, q1, [x3]
     a94:      	ldp	q3, q2, [x3, #0x20]
     a98:      	ldp	q4, q5, [x3, #0x40]
     a9c:      	ldp	q7, q6, [x3, #0x60]
     aa0:      	ldp	q16, q17, [x3, #0x80]
     aa4:      	ldp	q27, q26, [x3, #0xa0]
     aa8:      	ldp	q30, q31, [x3, #0xc0]
     aac:      	ldp	q9, q8, [x3, #0xe0]
     ab0:      	add	x16, x16, #0x100
     ab4:      	ldr	s10, [x15, x16]
     ab8:      	fadd.4s	v18, v7, v9
     abc:      	fadd.4s	v19, v6, v8
     ac0:      	fadd.4s	v20, v5, v31
     ac4:      	fadd.4s	v21, v4, v30
     ac8:      	fadd.4s	v22, v3, v27
     acc:      	fadd.4s	v23, v2, v26
     ad0:      	fadd.4s	v24, v0, v16
     ad4:      	fadd.4s	v25, v24, v10
     ad8:      	mov.s	v24[0], v25[0]
     adc:      	fadd.4s	v25, v1, v17
     ae0:      	fadd.4s	v23, v23, v25
     ae4:      	fadd.4s	v22, v22, v24
     ae8:      	fadd.4s	v21, v21, v22
     aec:      	fadd.4s	v20, v20, v23
     af0:      	fadd.4s	v19, v19, v20
     af4:      	fadd.4s	v18, v18, v21
     af8:      	rev64.4s	v20, v18
     afc:      	rev64.4s	v21, v19
     b00:      	fadd.4s	v18, v18, v20
     b04:      	dup.4s	v20, v18[2]
     b08:      	fadd.4s	v19, v19, v21
     b0c:      	dup.4s	v21, v19[2]
     b10:      	fadd.4s	v19, v19, v21
     b14:      	fadd.4s	v18, v18, v20
     b18:      	fadd.4s	v18, v18, v19
     b1c:      	movi	d19, #0000000000000000
     b20:      	fadd	s18, s18, s19
     b24:      	ldr	s20, [sp, #0x1a0]
     b28:      	fdiv	s18, s18, s20
     b2c:      	dup.4s	v11, v18[0]
     b30:      	fsub.4s	v29, v1, v11
     b34:      	fsub.4s	v28, v0, v11
     b38:      	fsub.4s	v13, v3, v11
     b3c:      	fsub.4s	v14, v2, v11
     b40:      	stp	q14, q13, [sp, #0x90]
     b44:      	fsub.4s	v12, v5, v11
     b48:      	fsub.4s	v25, v4, v11
     b4c:      	stp	q12, q25, [sp, #0xd0]
     b50:      	fsub.4s	v23, v7, v11
     b54:      	fsub.4s	v24, v6, v11
     b58:      	stp	q24, q23, [sp, #0xf0]
     b5c:      	fsub.4s	v22, v17, v11
     b60:      	fsub.4s	v21, v16, v11
     b64:      	stp	q22, q21, [sp, #0xb0]
     b68:      	fsub.4s	v17, v27, v11
     b6c:      	fsub.4s	v18, v26, v11
     b70:      	stp	q18, q17, [sp, #0x110]
     b74:      	fsub.4s	v16, v31, v11
     b78:      	fsub.4s	v5, v30, v11
     b7c:      	stp	q16, q5, [sp, #0x130]
     b80:      	fsub.4s	v3, v9, v11
     b84:      	fsub.4s	v4, v8, v11
     b88:      	stp	q4, q3, [sp, #0x180]
     b8c:      	movi.2d	v0, #0000000000000000
     b90:      	mov.s	v0[0], v10[0]
     b94:      	fsub.4s	v2, v0, v11
     b98:      	ldp	q30, q31, [x13]
     b9c:      	ldp	q1, q0, [x13, #0x20]
     ba0:      	stp	q2, q1, [sp, #0x160]
     ba4:      	str	q0, [sp, #0x150]
     ba8:      	fmul.4s	v0, v28, v28
     bac:      	fmul.4s	v1, v29, v29
     bb0:      	fmul.4s	v6, v14, v14
     bb4:      	fmul.4s	v7, v13, v13
     bb8:      	fmul.4s	v8, v25, v25
     bbc:      	fmul.4s	v9, v12, v12
     bc0:      	fmul.4s	v10, v24, v24
     bc4:      	fmul.4s	v11, v23, v23
     bc8:      	fmul.4s	v12, v3, v3
     bcc:      	fadd.4s	v11, v11, v12
     bd0:      	fmul.4s	v12, v4, v4
     bd4:      	fadd.4s	v13, v10, v12
     bd8:      	fmul.4s	v10, v16, v16
     bdc:      	fadd.4s	v9, v9, v10
     be0:      	fmul.4s	v10, v5, v5
     be4:      	fadd.4s	v8, v8, v10
     be8:      	fmul.4s	v10, v17, v17
     bec:      	fadd.4s	v7, v7, v10
     bf0:      	fmul.4s	v10, v18, v18
     bf4:      	fadd.4s	v6, v6, v10
     bf8:      	fmul.4s	v10, v22, v22
     bfc:      	fadd.4s	v1, v1, v10
     c00:      	fmul.4s	v10, v21, v21
     c04:      	fadd.4s	v0, v0, v10
     c08:      	fmul.4s	v10, v2, v2
     c0c:      	fadd.4s	v10, v10, v0
     c10:      	mov.s	v0[0], v10[0]
     c14:      	fadd.4s	v1, v6, v1
     c18:      	ldp	q14, q15, [x13, #0x40]
     c1c:      	fadd.4s	v0, v7, v0
     c20:      	fadd.4s	v0, v8, v0
     c24:      	ldp	q10, q12, [x13, #0x60]
     c28:      	fadd.4s	v1, v9, v1
     c2c:      	fadd.4s	v1, v13, v1
     c30:      	ldp	q2, q9, [x13, #0x80]
     c34:      	str	q2, [sp, #0x80]
     c38:      	fadd.4s	v0, v11, v0
     c3c:      	rev64.4s	v6, v1
     c40:      	fadd.4s	v1, v1, v6
     c44:      	rev64.4s	v6, v0
     c48:      	fadd.4s	v0, v0, v6
     c4c:      	dup.4s	v6, v1[2]
     c50:      	fadd.4s	v1, v1, v6
     c54:      	dup.4s	v6, v0[2]
     c58:      	fadd.4s	v0, v0, v6
     c5c:      	fadd.4s	v0, v0, v1
     c60:      	ldp	q11, q13, [x13, #0xa0]
     c64:      	fadd	s0, s0, s19
     c68:      	fdiv	s0, s0, s20
     c6c:      	ldr	s1, [sp, #0x1b0]
     c70:      	fadd	s0, s0, s1
     c74:      	fsqrt	s23, s0
     c78:      	dup.4s	v7, v23[0]
     c7c:      	fdiv.4s	v0, v29, v7
     c80:      	fmul.4s	v0, v31, v0
     c84:      	ldp	q1, q29, [x12]
     c88:      	fdiv.4s	v28, v28, v7
     c8c:      	fmul.4s	v28, v30, v28
     c90:      	fadd.4s	v3, v1, v28
     c94:      	ldp	q27, q31, [x13, #0xc0]
     c98:      	umaddl	x15, w17, w10, x9
     c9c:      	fadd.4s	v0, v29, v0
     ca0:      	ldp	q29, q30, [x13, #0xe0]
     ca4:      	ldr	s28, [x13, #0x100]
     ca8:      	ldp	q1, q2, [x12, #0x20]
     cac:      	ldp	q4, q5, [x12, #0x40]
     cb0:      	ldp	q6, q16, [x12, #0x60]
     cb4:      	ldp	q17, q18, [x12, #0x80]
     cb8:      	ldp	q19, q20, [x12, #0xa0]
     cbc:      	ldp	q21, q22, [x12, #0xc0]
     cc0:      	ldp	q24, q25, [x12, #0xe0]
     cc4:      	ldr	s26, [x12, #0x100]
     cc8:      	stp	q3, q0, [x15]
     ccc:      	ldr	q0, [sp, #0x90]
     cd0:      	fdiv.4s	v0, v0, v7
     cd4:      	ldr	q3, [sp, #0x150]
     cd8:      	fmul.4s	v0, v3, v0
     cdc:      	ldr	q3, [sp, #0xa0]
     ce0:      	fdiv.4s	v3, v3, v7
     ce4:      	ldr	q8, [sp, #0x170]
     ce8:      	fmul.4s	v3, v8, v3
     cec:      	fadd.4s	v1, v1, v3
     cf0:      	fadd.4s	v0, v2, v0
     cf4:      	stp	q1, q0, [x15, #0x20]
     cf8:      	ldp	q0, q1, [sp, #0xd0]
     cfc:      	fdiv.4s	v0, v0, v7
     d00:      	fmul.4s	v0, v15, v0
     d04:      	fdiv.4s	v1, v1, v7
     d08:      	fmul.4s	v1, v14, v1
     d0c:      	fadd.4s	v1, v4, v1
     d10:      	fadd.4s	v0, v5, v0
     d14:      	stp	q1, q0, [x15, #0x40]
     d18:      	ldp	q0, q1, [sp, #0xf0]
     d1c:      	fdiv.4s	v0, v0, v7
     d20:      	fmul.4s	v0, v12, v0
     d24:      	fdiv.4s	v1, v1, v7
     d28:      	fmul.4s	v1, v10, v1
     d2c:      	fadd.4s	v1, v6, v1
     d30:      	fadd.4s	v0, v16, v0
     d34:      	stp	q1, q0, [x15, #0x60]
     d38:      	ldp	q0, q1, [sp, #0xb0]
     d3c:      	fdiv.4s	v0, v0, v7
     d40:      	fmul.4s	v0, v9, v0
     d44:      	fdiv.4s	v1, v1, v7
     d48:      	ldr	q2, [sp, #0x80]
     d4c:      	fmul.4s	v1, v2, v1
     d50:      	fadd.4s	v1, v17, v1
     d54:      	fadd.4s	v0, v18, v0
     d58:      	stp	q1, q0, [x15, #0x80]
     d5c:      	ldp	q0, q1, [sp, #0x110]
     d60:      	fdiv.4s	v0, v0, v7
     d64:      	fmul.4s	v0, v13, v0
     d68:      	fdiv.4s	v1, v1, v7
     d6c:      	fmul.4s	v1, v11, v1
     d70:      	fadd.4s	v1, v19, v1
     d74:      	fadd.4s	v0, v20, v0
     d78:      	stp	q1, q0, [x15, #0xa0]
     d7c:      	ldp	q0, q1, [sp, #0x130]
     d80:      	fdiv.4s	v0, v0, v7
     d84:      	fmul.4s	v0, v31, v0
     d88:      	fdiv.4s	v1, v1, v7
     d8c:      	fmul.4s	v1, v27, v1
     d90:      	fadd.4s	v1, v21, v1
     d94:      	fadd.4s	v0, v22, v0
     d98:      	stp	q1, q0, [x15, #0xc0]
     d9c:      	ldp	q1, q0, [sp, #0x180]
     da0:      	fdiv.4s	v0, v0, v7
     da4:      	fdiv.4s	v1, v1, v7
     da8:      	fmul.4s	v1, v30, v1
     dac:      	fmul.4s	v0, v29, v0
     db0:      	fadd.4s	v0, v24, v0
     db4:      	fadd.4s	v1, v25, v1
     db8:      	stp	q0, q1, [x15, #0xe0]
     dbc:      	ldr	q0, [sp, #0x160]
     dc0:      	fdiv.4s	v0, v0, v23
     dc4:      	fmul.4s	v0, v28, v0
     dc8:      	fadd.4s	v0, v26, v0
     dcc:      	str	s0, [x9, x16]
     dd0:      	str	w28, [x2, #0x24]
     dd4:      	add	w9, w1, #0x1
     dd8:      	cmp	w9, w24
     ddc:      	cset	w9, eq
     de0:      	csinc	w1, wzr, w1, eq
     de4:      	cinc	w12, w7, eq
     de8:      	cmp	w12, w25
     dec:      	cset	w13, eq
     df0:      	ands	w9, w9, w13
     df4:      	csel	w7, wzr, w12, ne
     df8:      	add	w20, w20, w9
     dfc:      	add	w8, w8, #0x1
     e00:      	cmp	w8, w19
     e04:      	b.eq	0x27e8 <ltmp0+0x27e8>
     e08:      	ubfiz	x9, x1, #5, #32
     e0c:      	cmp	x9, x21
     e10:      	csel	x12, x9, xzr, ls
     e14:      	subs	x13, x21, x12
     e18:      	cmp	x13, #0x20
     e1c:      	csel	x13, x13, x23, lo
     e20:      	cmp	x21, x12
     e24:      	stp	w1, w7, [x2]
     e28:      	str	w20, [x2, #0x8]
     e2c:      	str	wzr, [x2, #0x24]
     e30:      	ccmp	x9, x21, #0x2, hi
     e34:      	csel	x12, x13, xzr, ls
     e38:      	cmp	x12, #0x20
     e3c:      	b.hs	0x7c <ltmp0+0x7c>
     e40:      	lsr	x9, x12, #3
     e44:      	cmp	x12, #0x8
     e48:      	movi	d30, #0000000000000000
     e4c:      	b.lo	0x11e8 <ltmp0+0x11e8>
     e50:      	ldr	x3, [x0]
     e54:      	ldr	x13, [x0, #0x10]
     e58:      	ldr	x15, [x0, #0x20]
     e5c:      	ldr	x4, [x0, #0x30]
     e60:      	add	x16, x13, #0x100
     e64:      	add	x17, x15, #0x100
     e68:      	and	x5, x1, #0x7ffffff
     e6c:      	add	x5, x5, x5, lsl #6
     e70:      	lsl	x5, x5, #4
     e74:      	add	x3, x3, x5
     e78:      	add	x3, x3, #0x80
     e7c:      	add	x4, x4, x5
     e80:      	add	x4, x4, #0x80
     e84:      	mov	x5, x9
     e88:      	ldp	q0, q1, [x3, #-0x80]
     e8c:      	ldp	q3, q2, [x3, #-0x60]
     e90:      	ldp	q4, q5, [x3, #-0x40]
     e94:      	ldp	q7, q6, [x3, #-0x20]
     e98:      	ldp	q16, q17, [x3]
     e9c:      	ldp	q25, q24, [x3, #0x20]
     ea0:      	ldp	q26, q27, [x3, #0x40]
     ea4:      	ldp	q8, q31, [x3, #0x60]
     ea8:      	ldr	s9, [x3, #0x80]
     eac:      	fadd.4s	v18, v7, v8
     eb0:      	fadd.4s	v19, v5, v27
     eb4:      	fadd.4s	v20, v4, v26
     eb8:      	fadd.4s	v21, v3, v25
     ebc:      	fadd.4s	v22, v2, v24
     ec0:      	fadd.4s	v23, v0, v16
     ec4:      	fadd.4s	v28, v1, v17
     ec8:      	fadd.4s	v29, v23, v9
     ecc:      	mov.s	v23[0], v29[0]
     ed0:      	fadd.4s	v22, v22, v28
     ed4:      	fadd.4s	v21, v21, v23
     ed8:      	fadd.4s	v23, v6, v31
     edc:      	fadd.4s	v20, v20, v21
     ee0:      	fadd.4s	v19, v19, v22
     ee4:      	fadd.4s	v19, v23, v19
     ee8:      	fadd.4s	v18, v18, v20
     eec:      	rev64.4s	v20, v19
     ef0:      	rev64.4s	v21, v18
     ef4:      	fadd.4s	v19, v19, v20
     ef8:      	fadd.4s	v18, v18, v21
     efc:      	dup.4s	v20, v19[2]
     f00:      	dup.4s	v21, v18[2]
     f04:      	fadd.4s	v19, v19, v20
     f08:      	fadd.4s	v18, v18, v21
     f0c:      	fadd.4s	v18, v18, v19
     f10:      	fadd	s18, s18, s30
     f14:      	movi	d19, #0000000000000000
     f18:      	fmov	s30, w11
     f1c:      	fdiv	s18, s18, s30
     f20:      	dup.4s	v10, v18[0]
     f24:      	fsub.4s	v29, v1, v10
     f28:      	fsub.4s	v28, v0, v10
     f2c:      	fsub.4s	v12, v3, v10
     f30:      	fsub.4s	v3, v2, v10
     f34:      	fsub.4s	v11, v5, v10
     f38:      	stp	q12, q11, [sp, #0xb0]
     f3c:      	fsub.4s	v23, v4, v10
     f40:      	fsub.4s	v21, v7, v10
     f44:      	fsub.4s	v22, v6, v10
     f48:      	fsub.4s	v20, v17, v10
     f4c:      	stp	q20, q23, [sp, #0xd0]
     f50:      	fsub.4s	v18, v16, v10
     f54:      	stp	q18, q21, [sp, #0xf0]
     f58:      	fsub.4s	v7, v25, v10
     f5c:      	fsub.4s	v16, v24, v10
     f60:      	fsub.4s	v17, v27, v10
     f64:      	fsub.4s	v24, v26, v10
     f68:      	stp	q24, q16, [sp, #0x110]
     f6c:      	fsub.4s	v5, v8, v10
     f70:      	fsub.4s	v6, v31, v10
     f74:      	stp	q6, q7, [sp, #0x130]
     f78:      	movi.2d	v0, #0000000000000000
     f7c:      	mov.s	v0[0], v9[0]
     f80:      	ldp	q31, q8, [x13]
     f84:      	fsub.4s	v4, v0, v10
     f88:      	ldp	q1, q0, [x13, #0x20]
     f8c:      	stp	q17, q1, [sp, #0x160]
     f90:      	str	q0, [sp, #0x150]
     f94:      	ldp	q1, q0, [x13, #0x40]
     f98:      	stp	q1, q5, [sp, #0x1a0]
     f9c:      	stp	q0, q4, [sp, #0x180]
     fa0:      	fmul.4s	v0, v28, v28
     fa4:      	fmul.4s	v1, v29, v29
     fa8:      	fmul.4s	v2, v3, v3
     fac:      	mov.16b	v27, v3
     fb0:      	fmul.4s	v3, v12, v12
     fb4:      	fmul.4s	v9, v23, v23
     fb8:      	fmul.4s	v10, v11, v11
     fbc:      	fmul.4s	v11, v21, v21
     fc0:      	fmul.4s	v12, v5, v5
     fc4:      	fadd.4s	v13, v11, v12
     fc8:      	fmul.4s	v11, v17, v17
     fcc:      	fadd.4s	v10, v10, v11
     fd0:      	fmul.4s	v11, v7, v7
     fd4:      	fadd.4s	v3, v3, v11
     fd8:      	fmul.4s	v11, v16, v16
     fdc:      	fadd.4s	v2, v2, v11
     fe0:      	fmul.4s	v11, v18, v18
     fe4:      	fadd.4s	v0, v0, v11
     fe8:      	fmul.4s	v11, v20, v20
     fec:      	fadd.4s	v1, v1, v11
     ff0:      	fmul.4s	v11, v4, v4
     ff4:      	fadd.4s	v11, v11, v0
     ff8:      	mov.s	v0[0], v11[0]
     ffc:      	fmul.4s	v11, v24, v24
    1000:      	fadd.4s	v9, v9, v11
    1004:      	ldp	q11, q15, [x13, #0x60]
    1008:      	fadd.4s	v1, v2, v1
    100c:      	fmul.4s	v2, v22, v22
    1010:      	mov.16b	v25, v22
    1014:      	fadd.4s	v0, v3, v0
    1018:      	fmul.4s	v3, v6, v6
    101c:      	fadd.4s	v2, v2, v3
    1020:      	fadd.4s	v0, v9, v0
    1024:      	fadd.4s	v1, v10, v1
    1028:      	ldp	q9, q12, [x13, #0x80]
    102c:      	fadd.4s	v1, v2, v1
    1030:      	fadd.4s	v0, v13, v0
    1034:      	rev64.4s	v2, v0
    1038:      	rev64.4s	v3, v1
    103c:      	fadd.4s	v0, v0, v2
    1040:      	dup.4s	v2, v0[2]
    1044:      	fadd.4s	v1, v1, v3
    1048:      	dup.4s	v3, v1[2]
    104c:      	fadd.4s	v1, v1, v3
    1050:      	fadd.4s	v0, v0, v2
    1054:      	ldp	q13, q14, [x13, #0xa0]
    1058:      	fadd.4s	v0, v0, v1
    105c:      	fadd	s0, s0, s19
    1060:      	fdiv	s0, s0, s30
    1064:      	fmov	s1, w14
    1068:      	fadd	s0, s0, s1
    106c:      	fsqrt	s30, s0
    1070:      	dup.4s	v10, v30[0]
    1074:      	fdiv.4s	v0, v29, v10
    1078:      	fmul.4s	v0, v8, v0
    107c:      	ldp	q1, q2, [x15]
    1080:      	fdiv.4s	v3, v28, v10
    1084:      	fmul.4s	v3, v31, v3
    1088:      	fadd.4s	v3, v1, v3
    108c:      	ldp	q24, q28, [x13, #0xc0]
    1090:      	fadd.4s	v0, v2, v0
    1094:      	ldp	q29, q31, [x13, #0xe0]
    1098:      	ldr	s26, [x16]
    109c:      	ldp	q1, q2, [x15, #0x20]
    10a0:      	ldp	q4, q5, [x15, #0x40]
    10a4:      	ldp	q6, q7, [x15, #0x60]
    10a8:      	ldp	q16, q17, [x15, #0x80]
    10ac:      	ldp	q18, q19, [x15, #0xa0]
    10b0:      	ldp	q20, q21, [x15, #0xc0]
    10b4:      	ldp	q22, q23, [x15, #0xe0]
    10b8:      	ldr	s8, [x17]
    10bc:      	stp	q3, q0, [x4, #-0x80]
    10c0:      	fdiv.4s	v0, v27, v10
    10c4:      	ldr	q3, [sp, #0x150]
    10c8:      	fmul.4s	v0, v3, v0
    10cc:      	ldr	q3, [sp, #0xb0]
    10d0:      	fdiv.4s	v3, v3, v10
    10d4:      	ldr	q27, [sp, #0x170]
    10d8:      	fmul.4s	v3, v27, v3
    10dc:      	fadd.4s	v1, v1, v3
    10e0:      	fadd.4s	v0, v2, v0
    10e4:      	stp	q1, q0, [x4, #-0x60]
    10e8:      	ldr	q0, [sp, #0xc0]
    10ec:      	fdiv.4s	v0, v0, v10
    10f0:      	ldr	q1, [sp, #0x180]
    10f4:      	fmul.4s	v0, v1, v0
    10f8:      	ldr	q1, [sp, #0xe0]
    10fc:      	fdiv.4s	v1, v1, v10
    1100:      	ldr	q2, [sp, #0x1a0]
    1104:      	fmul.4s	v1, v2, v1
    1108:      	fadd.4s	v1, v4, v1
    110c:      	fadd.4s	v0, v5, v0
    1110:      	fdiv.4s	v2, v25, v10
    1114:      	fmul.4s	v2, v15, v2
    1118:      	ldr	q3, [sp, #0x100]
    111c:      	fdiv.4s	v3, v3, v10
    1120:      	fmul.4s	v3, v11, v3
    1124:      	fadd.4s	v3, v6, v3
    1128:      	stp	q1, q0, [x4, #-0x40]
    112c:      	fadd.4s	v0, v7, v2
    1130:      	stp	q3, q0, [x4, #-0x20]
    1134:      	ldr	q0, [sp, #0xd0]
    1138:      	fdiv.4s	v0, v0, v10
    113c:      	fmul.4s	v0, v12, v0
    1140:      	ldr	q1, [sp, #0xf0]
    1144:      	fdiv.4s	v1, v1, v10
    1148:      	fmul.4s	v1, v9, v1
    114c:      	fadd.4s	v1, v16, v1
    1150:      	fadd.4s	v0, v17, v0
    1154:      	stp	q1, q0, [x4]
    1158:      	ldp	q3, q0, [sp, #0x110]
    115c:      	fdiv.4s	v0, v0, v10
    1160:      	fmul.4s	v0, v14, v0
    1164:      	ldr	q1, [sp, #0x140]
    1168:      	fdiv.4s	v1, v1, v10
    116c:      	fmul.4s	v1, v13, v1
    1170:      	fadd.4s	v1, v18, v1
    1174:      	fadd.4s	v0, v19, v0
    1178:      	ldr	q2, [sp, #0x160]
    117c:      	fdiv.4s	v2, v2, v10
    1180:      	fmul.4s	v2, v28, v2
    1184:      	fdiv.4s	v3, v3, v10
    1188:      	fmul.4s	v3, v24, v3
    118c:      	fadd.4s	v3, v20, v3
    1190:      	stp	q1, q0, [x4, #0x20]
    1194:      	fadd.4s	v0, v21, v2
    1198:      	ldr	q1, [sp, #0x1b0]
    119c:      	fdiv.4s	v1, v1, v10
    11a0:      	ldr	q2, [sp, #0x130]
    11a4:      	fdiv.4s	v2, v2, v10
    11a8:      	fmul.4s	v2, v31, v2
    11ac:      	stp	q3, q0, [x4, #0x40]
    11b0:      	fmul.4s	v0, v29, v1
    11b4:      	fadd.4s	v0, v22, v0
    11b8:      	fadd.4s	v1, v23, v2
    11bc:      	ldr	q2, [sp, #0x190]
    11c0:      	fdiv.4s	v2, v2, v30
    11c4:      	movi	d30, #0000000000000000
    11c8:      	stp	q0, q1, [x4, #0x60]
    11cc:      	fmul.4s	v0, v26, v2
    11d0:      	fadd.4s	v0, v8, v0
    11d4:      	str	s0, [x4, #0x80]
    11d8:      	add	x3, x3, #0x104
    11dc:      	add	x4, x4, #0x104
    11e0:      	subs	x5, x5, #0x1
    11e4:      	b.ne	0xe88 <ltmp0+0xe88>
    11e8:      	and	w12, w12, #0x7
    11ec:      	cbz	w12, 0xdd0 <ltmp0+0xdd0>
    11f0:      	dup.4s	v0, w12
    11f4:      	adrp	x12, 0x1000 <ltmp0+0x1000>
    11f8:      	ldr	q1, [x12]
    11fc:      	adrp	x12, 0x1000 <ltmp0+0x1000>
    1200:      	ldr	q2, [x12]
    1204:      	cmhi.4s	v6, v0, v2
    1208:      	cmhi.4s	v7, v0, v1
    120c:      	uzp1.8h	v1, v7, v6
    1210:      	umaxv.8h	h0, v1
    1214:      	fmov	w12, s0
    1218:      	tbz	w12, #0x0, 0xdd0 <ltmp0+0xdd0>
    121c:      	mov	x13, #0x0               ; =0
    1220:      	ldr	x12, [x0]
    1224:      	ldr	x23, [x0, #0x10]
    1228:      	ldr	x17, [x0, #0x20]
    122c:      	ldr	x15, [x0, #0x30]
    1230:      	str	x15, [sp, #0x160]
    1234:      	adrp	x15, 0x1000 <ltmp0+0x1000>
    1238:      	ldr	q0, [x15]
    123c:      	and.16b	v0, v1, v0
    1240:      	addv.8h	h16, v0
    1244:      	ubfiz	w15, w1, #2, #27
    1248:      	orr	w9, w15, w9
    124c:      	fmov	w15, s16
    1250:      	and	w15, w15, #0xff
    1254:      	str	w15, [sp, #0x68]
    1258:      	dup.4s	v0, w9
    125c:      	and.16b	v3, v7, v0
    1260:      	and.16b	v0, v6, v0
    1264:      	ushll2.2d	v2, v0, #0x0
    1268:      	ushll2.2d	v4, v3, #0x0
    126c:      	ushll.2d	v5, v0, #0x0
    1270:      	ushll.2d	v18, v3, #0x0
    1274:      	fmov	x9, d18
    1278:      	umaddl	x9, w9, w10, x12
    127c:      	b	0x12a0 <ltmp0+0x12a0>
    1280:      	add	x15, x6, x13
    1284:      	ldp	q0, q19, [x15]
    1288:      	bif.16b	v17, v19, v6
    128c:      	bit.16b	v0, v3, v7
    1290:      	stp	q0, q17, [x15]
    1294:      	add	x13, x13, #0x20
    1298:      	cmp	x13, #0x100
    129c:      	b.eq	0x1338 <ltmp0+0x1338>
    12a0:      	fmov	w16, s16
    12a4:      	add	x15, x9, x13
    12a8:      	movi.2d	v3, #0000000000000000
    12ac:      	movi.2d	v17, #0000000000000000
    12b0:      	tbnz	w16, #0x0, 0x12d8 <ltmp0+0x12d8>
    12b4:      	and	w16, w16, #0xff
    12b8:      	tbnz	w16, #0x1, 0x12e4 <ltmp0+0x12e4>
    12bc:      	tbnz	w16, #0x2, 0x12f0 <ltmp0+0x12f0>
    12c0:      	tbnz	w16, #0x3, 0x12fc <ltmp0+0x12fc>
    12c4:      	tbnz	w16, #0x4, 0x1308 <ltmp0+0x1308>
    12c8:      	tbnz	w16, #0x5, 0x1314 <ltmp0+0x1314>
    12cc:      	tbnz	w16, #0x6, 0x1320 <ltmp0+0x1320>
    12d0:      	tbz	w16, #0x7, 0x1280 <ltmp0+0x1280>
    12d4:      	b	0x132c <ltmp0+0x132c>
    12d8:      	ldr	s3, [x15]
    12dc:      	and	w16, w16, #0xff
    12e0:      	tbz	w16, #0x1, 0x12bc <ltmp0+0x12bc>
    12e4:      	add	x3, x15, #0x4
    12e8:      	ld1.s	{ v3 }[1], [x3]
    12ec:      	tbz	w16, #0x2, 0x12c0 <ltmp0+0x12c0>
    12f0:      	add	x3, x15, #0x8
    12f4:      	ld1.s	{ v3 }[2], [x3]
    12f8:      	tbz	w16, #0x3, 0x12c4 <ltmp0+0x12c4>
    12fc:      	add	x3, x15, #0xc
    1300:      	ld1.s	{ v3 }[3], [x3]
    1304:      	tbz	w16, #0x4, 0x12c8 <ltmp0+0x12c8>
    1308:      	add	x3, x15, #0x10
    130c:      	ld1.s	{ v17 }[0], [x3]
    1310:      	tbz	w16, #0x5, 0x12cc <ltmp0+0x12cc>
    1314:      	add	x3, x15, #0x14
    1318:      	ld1.s	{ v17 }[1], [x3]
    131c:      	tbz	w16, #0x6, 0x12d0 <ltmp0+0x12d0>
    1320:      	add	x3, x15, #0x18
    1324:      	ld1.s	{ v17 }[2], [x3]
    1328:      	tbz	w16, #0x7, 0x1280 <ltmp0+0x1280>
    132c:      	add	x15, x15, #0x1c
    1330:      	ld1.s	{ v17 }[3], [x15]
    1334:      	b	0x1280 <ltmp0+0x1280>
    1338:      	str	q1, [sp, #0x100]
    133c:      	xtn.4h	v0, v7
    1340:      	uzp1.8b	v0, v0, v0
    1344:      	sshll.2d	v21, v7, #0x0
    1348:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    134c:      	ldr	q3, [x9]
    1350:      	and.16b	v17, v21, v3
    1354:      	movi.2d	v3, #0000000000000000
    1358:      	mov.b	v3[0], v0[0]
    135c:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    1360:      	ldr	d1, [x9]
    1364:      	str	d1, [sp, #0xa0]
    1368:      	and.8b	v19, v3, v1
    136c:      	addv.8b	b19, v19
    1370:      	fmov	w9, s19
    1374:      	umaxv.8b	b19, v3
    1378:      	fmov	w13, s19
    137c:      	rbit	w15, w9
    1380:      	clz	w15, w15
    1384:      	tst	w13, #0x1
    1388:      	csel	w10, w15, wzr, ne
    138c:      	mov	w15, #0x40              ; =64
    1390:      	dup.2d	v22, x15
    1394:      	str	q17, [sp, #0xf0]
    1398:      	orr.16b	v17, v17, v22
    139c:      	xtn.2s	v23, v18
    13a0:      	str	q17, [sp, #0x50]
    13a4:      	movi.2s	v1, #0x41
    13a8:      	umlal.2d	v17, v23, v1
    13ac:      	movi.2d	v18, #0000000000000000
    13b0:      	mov.b	v18[0], v0[0]
    13b4:      	ushll.2d	v0, v18, #0x0
    13b8:      	shl.2d	v0, v0, #0x3f
    13bc:      	cmlt.2d	v0, v0, #0
    13c0:      	str	q17, [sp, #0x150]
    13c4:      	and.16b	v0, v0, v17
    13c8:      	movi.2d	v1, #0000000000000000
    13cc:      	str	q1, [sp, #0x680]
    13d0:      	str	q1, [sp, #0x670]
    13d4:      	str	q1, [sp, #0x660]
    13d8:      	str	q0, [sp, #0x650]
    13dc:      	and	x15, x10, #0x7
    13e0:      	add	x16, sp, #0x650
    13e4:      	ldr	x15, [x16, x15, lsl #3]
    13e8:      	sub	x15, x15, x10
    13ec:      	add	x12, x12, x15, lsl #2
    13f0:      	movi.2d	v24, #0000000000000000
    13f4:      	movi.2d	v27, #0000000000000000
    13f8:      	tbnz	w13, #0x0, 0x2680 <ltmp0+0x2680>
    13fc:      	tbnz	w9, #0x1, 0x2688 <ltmp0+0x2688>
    1400:      	tbnz	w9, #0x2, 0x2694 <ltmp0+0x2694>
    1404:      	tbnz	w9, #0x3, 0x26a0 <ltmp0+0x26a0>
    1408:      	tbnz	w9, #0x4, 0x26ac <ltmp0+0x26ac>
    140c:      	tbnz	w9, #0x5, 0x26b8 <ltmp0+0x26b8>
    1410:      	tbnz	w9, #0x6, 0x26c4 <ltmp0+0x26c4>
    1414:      	str	q16, [sp, #0x1b0]
    1418:      	tbz	w9, #0x7, 0x1424 <ltmp0+0x1424>
    141c:      	add	x12, x12, #0x1c
    1420:      	ld1.s	{ v27 }[3], [x12]
    1424:      	sshll.2d	v0, v6, #0x0
    1428:      	sshll2.2d	v26, v7, #0x0
    142c:      	sshll2.2d	v28, v6, #0x0
    1430:      	adrp	x12, 0x1000 <ltmp0+0x1000>
    1434:      	ldr	q18, [x12]
    1438:      	and.16b	v1, v28, v18
    143c:      	adrp	x12, 0x1000 <ltmp0+0x1000>
    1440:      	ldr	q18, [x12]
    1444:      	and.16b	v16, v26, v18
    1448:      	adrp	x12, 0x1000 <ltmp0+0x1000>
    144c:      	ldr	q18, [x12]
    1450:      	and.16b	v17, v0, v18
    1454:      	adrp	x12, 0x1000 <ltmp0+0x1000>
    1458:      	ldr	q18, [x12]
    145c:      	and.16b	v18, v28, v18
    1460:      	adrp	x12, 0x1000 <ltmp0+0x1000>
    1464:      	ldr	q25, [x12]
    1468:      	and.16b	v25, v26, v25
    146c:      	adrp	x12, 0x1000 <ltmp0+0x1000>
    1470:      	ldr	q29, [x12]
    1474:      	and.16b	v0, v0, v29
    1478:      	adrp	x12, 0x1000 <ltmp0+0x1000>
    147c:      	ldr	q29, [x12]
    1480:      	and.16b	v29, v21, v29
    1484:      	stp	q17, q16, [sp, #0xb0]
    1488:      	orr.16b	v19, v17, v22
    148c:      	orr.16b	v20, v16, v22
    1490:      	str	q1, [sp, #0xe0]
    1494:      	orr.16b	v17, v1, v22
    1498:      	movi.2s	v1, #0x41
    149c:      	umull.2d	v21, v23, v1
    14a0:      	xtn.2s	v4, v4
    14a4:      	xtn.2s	v5, v5
    14a8:      	xtn.2s	v2, v2
    14ac:      	stp	q19, q17, [sp, #0x30]
    14b0:      	mov.16b	v16, v17
    14b4:      	umlal.2d	v16, v2, v1
    14b8:      	str	q20, [sp, #0x20]
    14bc:      	mov.16b	v2, v20
    14c0:      	umlal.2d	v2, v4, v1
    14c4:      	stp	q2, q16, [sp, #0x130]
    14c8:      	mov.16b	v2, v19
    14cc:      	umlal.2d	v2, v5, v1
    14d0:      	stp	q21, q2, [sp, #0x110]
    14d4:      	sshll.2d	v2, v7, #0x0
    14d8:      	sshll.2d	v4, v6, #0x0
    14dc:      	str	q29, [sp, #0x610]
    14e0:      	str	q25, [sp, #0x620]
    14e4:      	str	q0, [sp, #0x630]
    14e8:      	str	q18, [sp, #0x640]
    14ec:      	and	x12, x10, #0x7
    14f0:      	add	x13, sp, #0x610
    14f4:      	ldr	x12, [x13, x12, lsl #3]
    14f8:      	orr	x12, x12, #0x100
    14fc:      	str	x10, [sp, #0xd0]
    1500:      	sub	x12, x12, x10, lsl #2
    1504:      	tst	w9, #0xff
    1508:      	csel	x9, xzr, x12, eq
    150c:      	str	x9, [sp, #0x1a0]
    1510:      	add	x9, x6, x9
    1514:      	ldp	q0, q5, [x9]
    1518:      	zip2.8b	v18, v3, v0
    151c:      	ushll.4s	v18, v18, #0x0
    1520:      	shl.4s	v18, v18, #0x1f
    1524:      	cmlt.4s	v18, v18, #0
    1528:      	stp	q27, q24, [sp, #0x170]
    152c:      	bit.16b	v5, v27, v18
    1530:      	str	q3, [sp, #0x190]
    1534:      	zip1.8b	v18, v3, v0
    1538:      	ushll.4s	v18, v18, #0x0
    153c:      	shl.4s	v18, v18, #0x1f
    1540:      	cmlt.4s	v18, v18, #0
    1544:      	bit.16b	v0, v24, v18
    1548:      	stp	q0, q5, [x9]
    154c:      	dup.2d	v0, x22
    1550:      	and.16b	v9, v28, v0
    1554:      	and.16b	v31, v26, v0
    1558:      	and.16b	v8, v4, v0
    155c:      	and.16b	v22, v2, v0
    1560:      	fmov	x3, d22
    1564:      	ldr	q0, [sp, #0xa60]
    1568:      	ldr	q2, [sp, #0xa70]
    156c:      	and.16b	v5, v6, v2
    1570:      	and.16b	v4, v7, v0
    1574:      	ldr	q0, [sp, #0xa40]
    1578:      	ldr	q2, [sp, #0xa50]
    157c:      	and.16b	v21, v6, v2
    1580:      	and.16b	v18, v7, v0
    1584:      	ldr	q0, [sp, #0xa20]
    1588:      	ldr	q2, [sp, #0xa30]
    158c:      	and.16b	v12, v6, v2
    1590:      	and.16b	v13, v7, v0
    1594:      	fmov	x9, d29
    1598:      	add	x9, x6, x9
    159c:      	ldp	q0, q2, [x9]
    15a0:      	and.16b	v25, v6, v2
    15a4:      	mov	x9, x3
    15a8:      	and.16b	v29, v7, v0
    15ac:      	mov.16b	v0, v22
    15b0:      	mov.16b	v23, v31
    15b4:      	mov.16b	v2, v8
    15b8:      	mov.16b	v30, v9
    15bc:      	sshll.2d	v10, v7, #0x0
    15c0:      	sshll.2d	v3, v6, #0x0
    15c4:      	add	x9, x6, x9, lsl #5
    15c8:      	ldp	q14, q15, [x9]
    15cc:      	fadd.4s	v14, v29, v14
    15d0:      	fadd.4s	v15, v25, v15
    15d4:      	ldp	q27, q24, [x9, #0x20]
    15d8:      	fadd.4s	v27, v13, v27
    15dc:      	fadd.4s	v24, v12, v24
    15e0:      	ldp	q19, q1, [x9, #0x40]
    15e4:      	fadd.4s	v19, v18, v19
    15e8:      	fadd.4s	v1, v21, v1
    15ec:      	ldp	q20, q17, [x9, #0x60]
    15f0:      	fadd.4s	v20, v4, v20
    15f4:      	fadd.4s	v17, v5, v17
    15f8:      	dup.2d	v11, x22
    15fc:      	and.16b	v16, v28, v11
    1600:      	add.2d	v30, v30, v16
    1604:      	and.16b	v16, v26, v11
    1608:      	add.2d	v23, v23, v16
    160c:      	and.16b	v3, v3, v11
    1610:      	add.2d	v2, v2, v3
    1614:      	and.16b	v3, v10, v11
    1618:      	add.2d	v0, v0, v3
    161c:      	bit.16b	v25, v15, v6
    1620:      	bit.16b	v29, v14, v7
    1624:      	bit.16b	v12, v24, v6
    1628:      	bit.16b	v13, v27, v7
    162c:      	bit.16b	v21, v1, v6
    1630:      	bit.16b	v18, v19, v7
    1634:      	bit.16b	v5, v17, v6
    1638:      	bit.16b	v4, v20, v7
    163c:      	fmov	x9, d0
    1640:      	cmp	x9, #0x8
    1644:      	b.lt	0x15bc <ltmp0+0x15bc>
    1648:      	ldr	q0, [sp, #0x100]
    164c:      	xtn.8b	v23, v0
    1650:      	ldp	q0, q1, [sp, #0x170]
    1654:      	fadd.4s	v0, v0, v25
    1658:      	fadd.4s	v1, v1, v29
    165c:      	ldr	q10, [sp, #0x190]
    1660:      	zip1.8b	v2, v10, v0
    1664:      	ushll.4s	v2, v2, #0x0
    1668:      	shl.4s	v2, v2, #0x1f
    166c:      	cmlt.4s	v2, v2, #0
    1670:      	and.16b	v1, v2, v1
    1674:      	zip2.8b	v2, v10, v0
    1678:      	ushll.4s	v2, v2, #0x0
    167c:      	shl.4s	v2, v2, #0x1f
    1680:      	cmlt.4s	v2, v2, #0
    1684:      	and.16b	v0, v2, v0
    1688:      	zip2.8b	v2, v23, v0
    168c:      	ushll.4s	v2, v2, #0x0
    1690:      	shl.4s	v2, v2, #0x1f
    1694:      	cmlt.4s	v2, v2, #0
    1698:      	movi.2d	v3, #0000000000000000
    169c:      	mov.b	v3[2], v23[1]
    16a0:      	bit.16b	v0, v15, v2
    16a4:      	mov.b	v3[4], v23[2]
    16a8:      	mov.b	v3[6], v23[3]
    16ac:      	ushll.4s	v2, v3, #0x0
    16b0:      	shl.4s	v2, v2, #0x1f
    16b4:      	cmlt.4s	v2, v2, #0
    16b8:      	bit.16b	v1, v14, v2
    16bc:      	fadd.4s	v1, v13, v1
    16c0:      	fadd.4s	v0, v12, v0
    16c4:      	fadd.4s	v0, v21, v0
    16c8:      	fadd.4s	v1, v18, v1
    16cc:      	fadd.4s	v4, v4, v1
    16d0:      	fadd.4s	v5, v5, v0
    16d4:      	ldp	q0, q2, [sp, #0xe0]
    16d8:      	ldr	q1, [sp, #0xc0]
    16dc:      	uzp1.4s	v3, v2, v1
    16e0:      	ldr	q1, [sp, #0xb0]
    16e4:      	uzp1.4s	v1, v1, v0
    16e8:      	movi.4s	v2, #0x1
    16ec:      	eor.16b	v0, v3, v2
    16f0:      	mov.s	w9, v0[1]
    16f4:      	mov.s	w12, v0[2]
    16f8:      	mov.s	w13, v0[3]
    16fc:      	fmov	w15, s0
    1700:      	add	x16, sp, #0x4a8
    1704:      	bfxil	x16, x15, #0, #3
    1708:      	str	d23, [sp, #0x4a8]
    170c:      	ldrb	w16, [x16]
    1710:      	and	x15, x15, #0x7
    1714:      	umov.b	w24, v23[0]
    1718:      	str	q5, [sp, #0x580]
    171c:      	str	q4, [sp, #0x570]
    1720:      	add	x4, sp, #0x570
    1724:      	ldr	s0, [x4, x15, lsl #2]
    1728:      	eor.16b	v21, v1, v2
    172c:      	ands	w19, w24, #0x1
    1730:      	tst	w19, w16
    1734:      	movi	d24, #0000000000000000
    1738:      	fcsel	s18, s0, s24, ne
    173c:      	and	x16, x9, #0x7
    1740:      	add	x15, sp, #0x4a8
    1744:      	bfxil	x15, x9, #0, #3
    1748:      	ldrb	w9, [x15]
    174c:      	umov.b	w28, v23[1]
    1750:      	and	w9, w28, w9
    1754:      	str	q5, [sp, #0x560]
    1758:      	str	q4, [sp, #0x550]
    175c:      	add	x4, sp, #0x550
    1760:      	ldr	s0, [x4, x16, lsl #2]
    1764:      	tst	w9, #0x1
    1768:      	fcsel	s19, s0, s24, ne
    176c:      	and	x9, x12, #0x7
    1770:      	add	x16, sp, #0x4a8
    1774:      	bfxil	x16, x12, #0, #3
    1778:      	ldrb	w12, [x16]
    177c:      	umov.b	w10, v23[2]
    1780:      	and	w12, w10, w12
    1784:      	str	q5, [sp, #0x540]
    1788:      	str	q4, [sp, #0x530]
    178c:      	add	x16, sp, #0x530
    1790:      	ldr	s0, [x16, x9, lsl #2]
    1794:      	tst	w12, #0x1
    1798:      	fcsel	s20, s0, s24, ne
    179c:      	and	x9, x13, #0x7
    17a0:      	add	x12, sp, #0x4a8
    17a4:      	bfxil	x12, x13, #0, #3
    17a8:      	ldrb	w12, [x12]
    17ac:      	umov.b	w15, v23[3]
    17b0:      	and	w12, w15, w12
    17b4:      	str	q5, [sp, #0x520]
    17b8:      	str	q4, [sp, #0x510]
    17bc:      	add	x13, sp, #0x510
    17c0:      	ldr	s0, [x13, x9, lsl #2]
    17c4:      	tst	w12, #0x1
    17c8:      	mov.s	w9, v21[1]
    17cc:      	mov.s	w16, v21[2]
    17d0:      	mov.s	w4, v21[3]
    17d4:      	fcsel	s0, s0, s24, ne
    17d8:      	fmov	w12, s21
    17dc:      	and	x25, x12, #0x7
    17e0:      	add	x13, sp, #0x4a8
    17e4:      	bfxil	x13, x12, #0, #3
    17e8:      	ldrb	w12, [x13]
    17ec:      	umov.b	w13, v23[4]
    17f0:      	str	q5, [sp, #0x600]
    17f4:      	str	q4, [sp, #0x5f0]
    17f8:      	add	x5, sp, #0x5f0
    17fc:      	ldr	s2, [x5, x25, lsl #2]
    1800:      	and	w12, w13, w12
    1804:      	tst	w12, #0x1
    1808:      	fcsel	s2, s2, s24, ne
    180c:      	and	x25, x9, #0x7
    1810:      	add	x12, sp, #0x4a8
    1814:      	bfxil	x12, x9, #0, #3
    1818:      	ldrb	w9, [x12]
    181c:      	umov.b	w12, v23[5]
    1820:      	and	w9, w12, w9
    1824:      	str	q5, [sp, #0x5e0]
    1828:      	str	q4, [sp, #0x5d0]
    182c:      	add	x5, sp, #0x5d0
    1830:      	ldr	s16, [x5, x25, lsl #2]
    1834:      	tst	w9, #0x1
    1838:      	fcsel	s16, s16, s24, ne
    183c:      	and	x9, x16, #0x7
    1840:      	add	x25, sp, #0x4a8
    1844:      	bfxil	x25, x16, #0, #3
    1848:      	ldrb	w25, [x25]
    184c:      	umov.b	w16, v23[6]
    1850:      	and	w25, w16, w25
    1854:      	str	q5, [sp, #0x5c0]
    1858:      	str	q4, [sp, #0x5b0]
    185c:      	add	x5, sp, #0x5b0
    1860:      	ldr	s17, [x5, x9, lsl #2]
    1864:      	tst	w25, #0x1
    1868:      	fcsel	s17, s17, s24, ne
    186c:      	and	x25, x4, #0x7
    1870:      	add	x9, sp, #0x4a8
    1874:      	bfxil	x9, x4, #0, #3
    1878:      	ldrb	w4, [x9]
    187c:      	umov.b	w9, v23[7]
    1880:      	and	w4, w9, w4
    1884:      	str	q5, [sp, #0x5a0]
    1888:      	str	q4, [sp, #0x590]
    188c:      	add	x5, sp, #0x590
    1890:      	ldr	s21, [x5, x25, lsl #2]
    1894:      	tst	w4, #0x1
    1898:      	fcsel	s21, s21, s24, ne
    189c:      	mov.s	v2[1], v16[0]
    18a0:      	mov.s	v2[2], v17[0]
    18a4:      	mov.s	v2[3], v21[0]
    18a8:      	mov.s	v18[1], v19[0]
    18ac:      	mov.s	v18[2], v20[0]
    18b0:      	mov.s	v18[3], v0[0]
    18b4:      	fadd.4s	v0, v4, v18
    18b8:      	fadd.4s	v2, v5, v2
    18bc:      	movi.4s	v4, #0x2
    18c0:      	eor.16b	v3, v3, v4
    18c4:      	fmov	w4, s3
    18c8:      	add	x25, sp, #0x4a8
    18cc:      	bfxil	x25, x4, #0, #3
    18d0:      	ldrb	w25, [x25]
    18d4:      	and	x4, x4, #0x7
    18d8:      	str	q2, [sp, #0x500]
    18dc:      	str	q0, [sp, #0x4f0]
    18e0:      	add	x5, sp, #0x4f0
    18e4:      	ldr	s3, [x5, x4, lsl #2]
    18e8:      	eor.16b	v1, v1, v4
    18ec:      	tst	w19, w25
    18f0:      	fcsel	s3, s3, s24, ne
    18f4:      	fmov	w4, s1
    18f8:      	and	x19, x4, #0x7
    18fc:      	add	x25, sp, #0x4a8
    1900:      	bfxil	x25, x4, #0, #3
    1904:      	ldrb	w4, [x25]
    1908:      	str	q2, [sp, #0x4e0]
    190c:      	str	q0, [sp, #0x4d0]
    1910:      	add	x5, sp, #0x4d0
    1914:      	ldr	s1, [x5, x19, lsl #2]
    1918:      	and	w4, w13, w4
    191c:      	tst	w4, #0x1
    1920:      	fcsel	s1, s1, s24, ne
    1924:      	fadd.4s	v1, v2, v1
    1928:      	and	w4, w24, w13
    192c:      	tst	w4, #0x1
    1930:      	fcsel	s1, s1, s24, ne
    1934:      	ands	w5, w24, #0x1
    1938:      	str	w5, [sp, #0xb0]
    193c:      	fadd.4s	v0, v0, v3
    1940:      	fadd	s2, s0, s1
    1944:      	fcsel	s4, s2, s24, ne
    1948:      	str	w4, [sp, #0xc0]
    194c:      	tst	w4, #0x1
    1950:      	sshll.2d	v1, v7, #0x0
    1954:      	mov	w4, #0x20               ; =32
    1958:      	dup.2d	v0, x4
    195c:      	and.16b	v0, v1, v0
    1960:      	mov	w4, #0x40               ; =64
    1964:      	dup.2d	v3, x4
    1968:      	and.16b	v3, v1, v3
    196c:      	mov	w4, #0x60               ; =96
    1970:      	dup.2d	v5, x4
    1974:      	and.16b	v1, v1, v5
    1978:      	str	w28, [sp, #0xe0]
    197c:      	and	w4, w28, w24
    1980:      	fcsel	s5, s2, s24, ne
    1984:      	str	w4, [sp, #0x90]
    1988:      	tst	w4, #0x1
    198c:      	str	w10, [sp, #0x100]
    1990:      	and	w10, w10, w24
    1994:      	fcsel	s16, s2, s24, ne
    1998:      	str	w10, [sp, #0x80]
    199c:      	tst	w10, #0x1
    19a0:      	str	w15, [sp, #0xf0]
    19a4:      	and	w10, w15, w24
    19a8:      	fcsel	s17, s2, s24, ne
    19ac:      	str	w10, [sp, #0x7c]
    19b0:      	tst	w10, #0x1
    19b4:      	fcsel	s18, s2, s24, ne
    19b8:      	and	w10, w12, w24
    19bc:      	str	w10, [sp, #0x78]
    19c0:      	tst	w10, #0x1
    19c4:      	fcsel	s19, s2, s24, ne
    19c8:      	and	w10, w16, w24
    19cc:      	str	w10, [sp, #0x74]
    19d0:      	tst	w10, #0x1
    19d4:      	fcsel	s20, s2, s24, ne
    19d8:      	and	w10, w9, w24
    19dc:      	str	w10, [sp, #0x64]
    19e0:      	tst	w10, #0x1
    19e4:      	mov.s	v4[1], v16[0]
    19e8:      	mov.s	v4[2], v17[0]
    19ec:      	mov.s	v4[3], v18[0]
    19f0:      	mov.s	v5[1], v19[0]
    19f4:      	fcsel	s2, s2, s24, ne
    19f8:      	mov.s	v5[2], v20[0]
    19fc:      	mov.s	v5[3], v2[0]
    1a00:      	ldr	w10, [sp, #0x68]
    1a04:      	rbit	w4, w10
    1a08:      	clz	w10, w4
    1a0c:      	str	q5, [sp, #0x4c0]
    1a10:      	str	q4, [sp, #0x4b0]
    1a14:      	str	x10, [sp, #0x68]
    1a18:      	and	x4, x10, #0x7
    1a1c:      	add	x5, sp, #0x4b0
    1a20:      	ldr	s2, [x5, x4, lsl #2]
    1a24:      	fmov	x4, d0
    1a28:      	add	x4, x6, x4
    1a2c:      	ldp	q0, q4, [x4]
    1a30:      	fmov	x4, d3
    1a34:      	add	x4, x6, x4
    1a38:      	ldp	q3, q5, [x4]
    1a3c:      	fmov	x4, d1
    1a40:      	add	x4, x6, x4
    1a44:      	ldp	q1, q16, [x4]
    1a48:      	mov.16b	v11, v23
    1a4c:      	mov.b	v11[0], wzr
    1a50:      	fadd	s2, s2, s24
    1a54:      	fmov	s17, w11
    1a58:      	fdiv	s2, s2, s17
    1a5c:      	ldr	q17, [sp, #0xa00]
    1a60:      	ldr	q18, [sp, #0xa10]
    1a64:      	and.16b	v18, v6, v18
    1a68:      	and.16b	v17, v7, v17
    1a6c:      	dup.4s	v21, v2[0]
    1a70:      	fsub.4s	v2, v17, v21
    1a74:      	fsub.4s	v17, v18, v21
    1a78:      	ldr	q18, [sp, #0x8e0]
    1a7c:      	ldr	q19, [sp, #0x8f0]
    1a80:      	bit.16b	v19, v17, v6
    1a84:      	bit.16b	v18, v2, v7
    1a88:      	and.16b	v4, v6, v4
    1a8c:      	and.16b	v0, v7, v0
    1a90:      	fsub.4s	v0, v0, v21
    1a94:      	fsub.4s	v4, v4, v21
    1a98:      	str	q18, [sp, #0x8e0]
    1a9c:      	str	q19, [sp, #0x8f0]
    1aa0:      	ldr	q18, [sp, #0x900]
    1aa4:      	ldr	q19, [sp, #0x910]
    1aa8:      	bit.16b	v19, v4, v6
    1aac:      	bit.16b	v18, v0, v7
    1ab0:      	and.16b	v5, v6, v5
    1ab4:      	and.16b	v3, v7, v3
    1ab8:      	fsub.4s	v3, v3, v21
    1abc:      	fsub.4s	v5, v5, v21
    1ac0:      	ldr	q20, [sp, #0x920]
    1ac4:      	ldr	q24, [sp, #0x930]
    1ac8:      	bit.16b	v24, v5, v6
    1acc:      	bit.16b	v20, v3, v7
    1ad0:      	and.16b	v16, v6, v16
    1ad4:      	and.16b	v1, v7, v1
    1ad8:      	fsub.4s	v1, v1, v21
    1adc:      	fsub.4s	v16, v16, v21
    1ae0:      	ldr	q25, [sp, #0x940]
    1ae4:      	ldr	q27, [sp, #0x950]
    1ae8:      	bit.16b	v27, v16, v6
    1aec:      	bit.16b	v25, v1, v7
    1af0:      	fmul.4s	v1, v1, v1
    1af4:      	fmul.4s	v16, v16, v16
    1af8:      	and.16b	v12, v6, v16
    1afc:      	and.16b	v13, v7, v1
    1b00:      	str	q18, [sp, #0x900]
    1b04:      	str	q19, [sp, #0x910]
    1b08:      	str	q20, [sp, #0x920]
    1b0c:      	str	q24, [sp, #0x930]
    1b10:      	str	q25, [sp, #0x940]
    1b14:      	str	q27, [sp, #0x950]
    1b18:      	fmul.4s	v1, v3, v3
    1b1c:      	fmul.4s	v3, v5, v5
    1b20:      	and.16b	v15, v6, v3
    1b24:      	and.16b	v14, v7, v1
    1b28:      	fmul.4s	v0, v0, v0
    1b2c:      	fmul.4s	v1, v4, v4
    1b30:      	and.16b	v5, v6, v1
    1b34:      	and.16b	v3, v7, v0
    1b38:      	fmul.4s	v0, v2, v2
    1b3c:      	fmul.4s	v1, v17, v17
    1b40:      	and.16b	v1, v6, v1
    1b44:      	and.16b	v4, v7, v0
    1b48:      	sshll.2d	v18, v7, #0x0
    1b4c:      	sshll.2d	v25, v6, #0x0
    1b50:      	lsl	x3, x3, #5
    1b54:      	add	x4, x6, x3
    1b58:      	ldp	q0, q2, [x4]
    1b5c:      	and.16b	v2, v6, v2
    1b60:      	and.16b	v0, v7, v0
    1b64:      	fsub.4s	v0, v0, v21
    1b68:      	fsub.4s	v2, v2, v21
    1b6c:      	add	x4, x26, x3
    1b70:      	ldp	q16, q17, [x4]
    1b74:      	bit.16b	v17, v2, v6
    1b78:      	bit.16b	v16, v0, v7
    1b7c:      	stp	q16, q17, [x4]
    1b80:      	fmul.4s	v2, v2, v2
    1b84:      	fmul.4s	v0, v0, v0
    1b88:      	fadd.4s	v19, v4, v0
    1b8c:      	fadd.4s	v20, v1, v2
    1b90:      	add	x4, x3, #0x20
    1b94:      	add	x19, x6, x4
    1b98:      	ldp	q0, q2, [x19]
    1b9c:      	and.16b	v2, v6, v2
    1ba0:      	and.16b	v0, v7, v0
    1ba4:      	fsub.4s	v0, v0, v21
    1ba8:      	fsub.4s	v2, v2, v21
    1bac:      	add	x4, x26, x4
    1bb0:      	ldp	q16, q17, [x4]
    1bb4:      	bit.16b	v17, v2, v6
    1bb8:      	bit.16b	v16, v0, v7
    1bbc:      	stp	q16, q17, [x4]
    1bc0:      	fmul.4s	v2, v2, v2
    1bc4:      	fmul.4s	v0, v0, v0
    1bc8:      	fadd.4s	v0, v3, v0
    1bcc:      	fadd.4s	v2, v5, v2
    1bd0:      	add	x4, x3, #0x40
    1bd4:      	add	x19, x6, x4
    1bd8:      	ldp	q16, q17, [x19]
    1bdc:      	and.16b	v17, v6, v17
    1be0:      	and.16b	v16, v7, v16
    1be4:      	fsub.4s	v16, v16, v21
    1be8:      	fsub.4s	v17, v17, v21
    1bec:      	add	x4, x26, x4
    1bf0:      	ldp	q24, q27, [x4]
    1bf4:      	bit.16b	v27, v17, v6
    1bf8:      	bit.16b	v24, v16, v7
    1bfc:      	stp	q24, q27, [x4]
    1c00:      	fmul.4s	v17, v17, v17
    1c04:      	fmul.4s	v16, v16, v16
    1c08:      	fadd.4s	v16, v14, v16
    1c0c:      	fadd.4s	v17, v15, v17
    1c10:      	add	x3, x3, #0x60
    1c14:      	add	x4, x6, x3
    1c18:      	ldp	q24, q27, [x4]
    1c1c:      	and.16b	v27, v6, v27
    1c20:      	and.16b	v24, v7, v24
    1c24:      	fsub.4s	v24, v24, v21
    1c28:      	fsub.4s	v27, v27, v21
    1c2c:      	add	x3, x26, x3
    1c30:      	ldp	q29, q30, [x3]
    1c34:      	bit.16b	v30, v27, v6
    1c38:      	bit.16b	v29, v24, v7
    1c3c:      	stp	q29, q30, [x3]
    1c40:      	fmul.4s	v27, v27, v27
    1c44:      	fmul.4s	v24, v24, v24
    1c48:      	fadd.4s	v24, v13, v24
    1c4c:      	fadd.4s	v27, v12, v27
    1c50:      	dup.2d	v29, x22
    1c54:      	and.16b	v30, v28, v29
    1c58:      	add.2d	v9, v9, v30
    1c5c:      	and.16b	v30, v26, v29
    1c60:      	add.2d	v31, v31, v30
    1c64:      	and.16b	v25, v25, v29
    1c68:      	add.2d	v8, v8, v25
    1c6c:      	and.16b	v18, v18, v29
    1c70:      	add.2d	v22, v22, v18
    1c74:      	bit.16b	v1, v20, v6
    1c78:      	bit.16b	v4, v19, v7
    1c7c:      	bit.16b	v5, v2, v6
    1c80:      	bit.16b	v3, v0, v7
    1c84:      	bit.16b	v15, v17, v6
    1c88:      	bit.16b	v14, v16, v7
    1c8c:      	bit.16b	v12, v27, v6
    1c90:      	bit.16b	v13, v24, v7
    1c94:      	fmov	x3, d22
    1c98:      	cmp	x3, #0x8
    1c9c:      	b.lt	0x1b48 <ltmp0+0x1b48>
    1ca0:      	mov	x3, #0x0                ; =0
    1ca4:      	ldp	q0, q2, [sp, #0x170]
    1ca8:      	fsub.4s	v26, v2, v21
    1cac:      	fsub.4s	v24, v0, v21
    1cb0:      	ldr	x4, [sp, #0x1a0]
    1cb4:      	add	x4, x26, x4
    1cb8:      	ldp	q0, q2, [x4]
    1cbc:      	zip2.8b	v16, v10, v0
    1cc0:      	ushll.4s	v16, v16, #0x0
    1cc4:      	shl.4s	v16, v16, #0x1f
    1cc8:      	cmlt.4s	v16, v16, #0
    1ccc:      	bit.16b	v2, v24, v16
    1cd0:      	zip1.8b	v16, v10, v0
    1cd4:      	ushll.4s	v16, v16, #0x0
    1cd8:      	shl.4s	v16, v16, #0x1f
    1cdc:      	cmlt.4s	v16, v16, #0
    1ce0:      	bit.16b	v0, v26, v16
    1ce4:      	stp	q0, q2, [x4]
    1ce8:      	mov	w4, #0x1                ; =1
    1cec:      	dup.2d	v0, x4
    1cf0:      	ushll2.2d	v2, v6, #0x0
    1cf4:      	and.16b	v27, v2, v0
    1cf8:      	ushll2.2d	v2, v7, #0x0
    1cfc:      	and.16b	v28, v2, v0
    1d00:      	ushll.2d	v2, v6, #0x0
    1d04:      	and.16b	v30, v2, v0
    1d08:      	ushll.2d	v2, v7, #0x0
    1d0c:      	and.16b	v31, v2, v0
    1d10:      	movi.2d	v2, #0000000000000000
    1d14:      	movi.2d	v21, #0000000000000000
    1d18:      	movi.2d	v22, #0000000000000000
    1d1c:      	movi.2d	v18, #0000000000000000
    1d20:      	ldr	q9, [sp, #0x1b0]
    1d24:      	ldr	x28, [sp, #0xd0]
    1d28:      	b	0x1d5c <ltmp0+0x1d5c>
    1d2c:      	add	x3, x27, x3
    1d30:      	ldp	q0, q16, [x3]
    1d34:      	bit.16b	v16, v29, v6
    1d38:      	bit.16b	v0, v25, v7
    1d3c:      	stp	q0, q16, [x3]
    1d40:      	add.2d	v21, v21, v28
    1d44:      	add.2d	v22, v22, v30
    1d48:      	add.2d	v18, v18, v27
    1d4c:      	add.2d	v2, v2, v31
    1d50:      	fmov	x3, d2
    1d54:      	cmp	x3, #0x8
    1d58:      	b.ge	0x1df8 <ltmp0+0x1df8>
    1d5c:      	fmov	w19, s9
    1d60:      	lsl	x3, x3, #5
    1d64:      	add	x25, x23, x3
    1d68:      	movi.2d	v25, #0000000000000000
    1d6c:      	movi.2d	v29, #0000000000000000
    1d70:      	tbnz	w19, #0x0, 0x1d98 <ltmp0+0x1d98>
    1d74:      	and	w19, w19, #0xff
    1d78:      	tbnz	w19, #0x1, 0x1da4 <ltmp0+0x1da4>
    1d7c:      	tbnz	w19, #0x2, 0x1db0 <ltmp0+0x1db0>
    1d80:      	tbnz	w19, #0x3, 0x1dbc <ltmp0+0x1dbc>
    1d84:      	tbnz	w19, #0x4, 0x1dc8 <ltmp0+0x1dc8>
    1d88:      	tbnz	w19, #0x5, 0x1dd4 <ltmp0+0x1dd4>
    1d8c:      	tbnz	w19, #0x6, 0x1de0 <ltmp0+0x1de0>
    1d90:      	tbz	w19, #0x7, 0x1d2c <ltmp0+0x1d2c>
    1d94:      	b	0x1dec <ltmp0+0x1dec>
    1d98:      	ldr	s25, [x25]
    1d9c:      	and	w19, w19, #0xff
    1da0:      	tbz	w19, #0x1, 0x1d7c <ltmp0+0x1d7c>
    1da4:      	add	x4, x25, #0x4
    1da8:      	ld1.s	{ v25 }[1], [x4]
    1dac:      	tbz	w19, #0x2, 0x1d80 <ltmp0+0x1d80>
    1db0:      	add	x4, x25, #0x8
    1db4:      	ld1.s	{ v25 }[2], [x4]
    1db8:      	tbz	w19, #0x3, 0x1d84 <ltmp0+0x1d84>
    1dbc:      	add	x4, x25, #0xc
    1dc0:      	ld1.s	{ v25 }[3], [x4]
    1dc4:      	tbz	w19, #0x4, 0x1d88 <ltmp0+0x1d88>
    1dc8:      	add	x4, x25, #0x10
    1dcc:      	ld1.s	{ v29 }[0], [x4]
    1dd0:      	tbz	w19, #0x5, 0x1d8c <ltmp0+0x1d8c>
    1dd4:      	add	x4, x25, #0x14
    1dd8:      	ld1.s	{ v29 }[1], [x4]
    1ddc:      	tbz	w19, #0x6, 0x1d90 <ltmp0+0x1d90>
    1de0:      	add	x4, x25, #0x18
    1de4:      	ld1.s	{ v29 }[2], [x4]
    1de8:      	tbz	w19, #0x7, 0x1d2c <ltmp0+0x1d2c>
    1dec:      	add	x4, x25, #0x1c
    1df0:      	ld1.s	{ v29 }[3], [x4]
    1df4:      	b	0x1d2c <ltmp0+0x1d2c>
    1df8:      	mov	b0, v10[0]
    1dfc:      	mov.b	v0[4], v10[1]
    1e00:      	ushll.2d	v0, v0, #0x0
    1e04:      	shl.2d	v0, v0, #0x3f
    1e08:      	cmlt.2d	v0, v0, #0
    1e0c:      	mov	b2, v10[2]
    1e10:      	mov.b	v2[4], v10[3]
    1e14:      	ldp	q18, q16, [sp, #0x40]
    1e18:      	and.16b	v0, v0, v16
    1e1c:      	ushll.2d	v2, v2, #0x0
    1e20:      	shl.2d	v2, v2, #0x3f
    1e24:      	cmlt.2d	v2, v2, #0
    1e28:      	ldp	q16, q17, [sp, #0x20]
    1e2c:      	and.16b	v2, v2, v16
    1e30:      	mov	b16, v10[4]
    1e34:      	mov.b	v16[4], v10[5]
    1e38:      	ushll.2d	v16, v16, #0x0
    1e3c:      	shl.2d	v16, v16, #0x3f
    1e40:      	cmlt.2d	v16, v16, #0
    1e44:      	and.16b	v16, v16, v17
    1e48:      	mov	b17, v10[6]
    1e4c:      	mov.b	v17[4], v10[7]
    1e50:      	ushll.2d	v17, v17, #0x0
    1e54:      	shl.2d	v17, v17, #0x3f
    1e58:      	cmlt.2d	v17, v17, #0
    1e5c:      	and.16b	v17, v17, v18
    1e60:      	shl.8b	v18, v10, #0x7
    1e64:      	cmlt.8b	v18, v18, #0
    1e68:      	ldr	d21, [sp, #0xa0]
    1e6c:      	and.8b	v18, v18, v21
    1e70:      	addv.8b	b29, v18
    1e74:      	str	q17, [sp, #0x490]
    1e78:      	str	q16, [sp, #0x480]
    1e7c:      	str	q2, [sp, #0x470]
    1e80:      	str	q0, [sp, #0x460]
    1e84:      	and	x3, x28, #0x7
    1e88:      	add	x4, sp, #0x460
    1e8c:      	ldr	x3, [x4, x3, lsl #3]
    1e90:      	fmov	w25, s29
    1e94:      	sub	x3, x3, x28
    1e98:      	lsl	x3, x3, #2
    1e9c:      	add	x23, x23, x3
    1ea0:      	movi.2d	v8, #0000000000000000
    1ea4:      	movi.2d	v25, #0000000000000000
    1ea8:      	tbnz	w25, #0x0, 0x26d8 <ltmp0+0x26d8>
    1eac:      	tbnz	w25, #0x1, 0x26e0 <ltmp0+0x26e0>
    1eb0:      	tbnz	w25, #0x2, 0x26ec <ltmp0+0x26ec>
    1eb4:      	tbnz	w25, #0x3, 0x26f8 <ltmp0+0x26f8>
    1eb8:      	tbnz	w25, #0x4, 0x2704 <ltmp0+0x2704>
    1ebc:      	tbnz	w25, #0x5, 0x2710 <ltmp0+0x2710>
    1ec0:      	tbnz	w25, #0x6, 0x271c <ltmp0+0x271c>
    1ec4:      	tbz	w25, #0x7, 0x1ed0 <ltmp0+0x1ed0>
    1ec8:      	add	x4, x23, #0x1c
    1ecc:      	ld1.s	{ v25 }[3], [x4]
    1ed0:      	mov	x19, #0x0               ; =0
    1ed4:      	ldr	x4, [sp, #0x1a0]
    1ed8:      	add	x4, x27, x4
    1edc:      	ldp	q0, q2, [x4]
    1ee0:      	zip2.8b	v16, v10, v0
    1ee4:      	ushll.4s	v16, v16, #0x0
    1ee8:      	shl.4s	v16, v16, #0x1f
    1eec:      	cmlt.4s	v16, v16, #0
    1ef0:      	bit.16b	v2, v25, v16
    1ef4:      	zip1.8b	v16, v10, v0
    1ef8:      	ushll.4s	v16, v16, #0x0
    1efc:      	shl.4s	v16, v16, #0x1f
    1f00:      	cmlt.4s	v16, v16, #0
    1f04:      	bit.16b	v0, v8, v16
    1f08:      	stp	q0, q2, [x4]
    1f0c:      	movi.2d	v2, #0000000000000000
    1f10:      	movi.2d	v21, #0000000000000000
    1f14:      	movi.2d	v22, #0000000000000000
    1f18:      	movi.2d	v18, #0000000000000000
    1f1c:      	b	0x1f54 <ltmp0+0x1f54>
    1f20:      	add	x4, x30, x23
    1f24:      	ldp	q0, q16, [x4]
    1f28:      	bit.16b	v16, v10, v6
    1f2c:      	bit.16b	v0, v9, v7
    1f30:      	stp	q0, q16, [x4]
    1f34:      	add.2d	v21, v21, v28
    1f38:      	add.2d	v22, v22, v30
    1f3c:      	add.2d	v18, v18, v27
    1f40:      	add.2d	v2, v2, v31
    1f44:      	fmov	x19, d2
    1f48:      	cmp	x19, #0x8
    1f4c:      	ldr	q9, [sp, #0x1b0]
    1f50:      	b.ge	0x1ff0 <ltmp0+0x1ff0>
    1f54:      	fmov	w4, s9
    1f58:      	lsl	x23, x19, #5
    1f5c:      	add	x25, x17, x23
    1f60:      	movi.2d	v9, #0000000000000000
    1f64:      	movi.2d	v10, #0000000000000000
    1f68:      	tbnz	w4, #0x0, 0x1f90 <ltmp0+0x1f90>
    1f6c:      	and	w19, w4, #0xff
    1f70:      	tbnz	w19, #0x1, 0x1f9c <ltmp0+0x1f9c>
    1f74:      	tbnz	w19, #0x2, 0x1fa8 <ltmp0+0x1fa8>
    1f78:      	tbnz	w19, #0x3, 0x1fb4 <ltmp0+0x1fb4>
    1f7c:      	tbnz	w19, #0x4, 0x1fc0 <ltmp0+0x1fc0>
    1f80:      	tbnz	w19, #0x5, 0x1fcc <ltmp0+0x1fcc>
    1f84:      	tbnz	w19, #0x6, 0x1fd8 <ltmp0+0x1fd8>
    1f88:      	tbz	w19, #0x7, 0x1f20 <ltmp0+0x1f20>
    1f8c:      	b	0x1fe4 <ltmp0+0x1fe4>
    1f90:      	ldr	s9, [x25]
    1f94:      	and	w19, w4, #0xff
    1f98:      	tbz	w19, #0x1, 0x1f74 <ltmp0+0x1f74>
    1f9c:      	add	x4, x25, #0x4
    1fa0:      	ld1.s	{ v9 }[1], [x4]
    1fa4:      	tbz	w19, #0x2, 0x1f78 <ltmp0+0x1f78>
    1fa8:      	add	x4, x25, #0x8
    1fac:      	ld1.s	{ v9 }[2], [x4]
    1fb0:      	tbz	w19, #0x3, 0x1f7c <ltmp0+0x1f7c>
    1fb4:      	add	x4, x25, #0xc
    1fb8:      	ld1.s	{ v9 }[3], [x4]
    1fbc:      	tbz	w19, #0x4, 0x1f80 <ltmp0+0x1f80>
    1fc0:      	add	x4, x25, #0x10
    1fc4:      	ld1.s	{ v10 }[0], [x4]
    1fc8:      	tbz	w19, #0x5, 0x1f84 <ltmp0+0x1f84>
    1fcc:      	add	x4, x25, #0x14
    1fd0:      	ld1.s	{ v10 }[1], [x4]
    1fd4:      	tbz	w19, #0x6, 0x1f88 <ltmp0+0x1f88>
    1fd8:      	add	x4, x25, #0x18
    1fdc:      	ld1.s	{ v10 }[2], [x4]
    1fe0:      	tbz	w19, #0x7, 0x1f20 <ltmp0+0x1f20>
    1fe4:      	add	x4, x25, #0x1c
    1fe8:      	ld1.s	{ v10 }[3], [x4]
    1fec:      	b	0x1f20 <ltmp0+0x1f20>
    1ff0:      	adrp	x4, 0x1000 <ltmp0+0x1000>
    1ff4:      	ldr	q0, [x4]
    1ff8:      	and.16b	v18, v6, v0
    1ffc:      	adrp	x4, 0x1000 <ltmp0+0x1000>
    2000:      	ldr	q0, [x4]
    2004:      	and.16b	v0, v7, v0
    2008:      	adrp	x4, 0x2000 <ltmp0+0x2000>
    200c:      	ldr	q2, [x4]
    2010:      	fmul.4s	v16, v26, v26
    2014:      	fmul.4s	v17, v24, v24
    2018:      	fadd.4s	v1, v17, v1
    201c:      	fadd.4s	v4, v16, v4
    2020:      	ldr	q10, [sp, #0x190]
    2024:      	zip1.8b	v16, v10, v0
    2028:      	ushll.4s	v16, v16, #0x0
    202c:      	shl.4s	v16, v16, #0x1f
    2030:      	cmlt.4s	v16, v16, #0
    2034:      	and.16b	v4, v16, v4
    2038:      	zip2.8b	v16, v10, v0
    203c:      	ushll.4s	v16, v16, #0x0
    2040:      	shl.4s	v16, v16, #0x1f
    2044:      	cmlt.4s	v16, v16, #0
    2048:      	and.16b	v1, v16, v1
    204c:      	zip2.8b	v16, v11, v0
    2050:      	ushll.4s	v16, v16, #0x0
    2054:      	shl.4s	v16, v16, #0x1f
    2058:      	cmlt.4s	v16, v16, #0
    205c:      	bit.16b	v1, v20, v16
    2060:      	zip1.8b	v16, v11, v0
    2064:      	ushll.4s	v16, v16, #0x0
    2068:      	shl.4s	v16, v16, #0x1f
    206c:      	cmlt.4s	v16, v16, #0
    2070:      	bit.16b	v4, v19, v16
    2074:      	fadd.4s	v3, v3, v4
    2078:      	fadd.4s	v1, v5, v1
    207c:      	fadd.4s	v4, v1, v15
    2080:      	fadd.4s	v1, v3, v14
    2084:      	fadd.4s	v1, v1, v13
    2088:      	fadd.4s	v3, v4, v12
    208c:      	fmov	w4, s0
    2090:      	add	x19, sp, #0x208
    2094:      	bfxil	x19, x4, #0, #3
    2098:      	str	d23, [sp, #0x208]
    209c:      	ldrb	w19, [x19]
    20a0:      	add	x5, sp, #0x430
    20a4:      	orr	x4, x5, x4, lsl #2
    20a8:      	str	q3, [sp, #0x440]
    20ac:      	str	q1, [sp, #0x430]
    20b0:      	ldr	s4, [x4]
    20b4:      	ldr	w25, [sp, #0xb0]
    20b8:      	tst	w25, w19
    20bc:      	movi	d21, #0000000000000000
    20c0:      	fcsel	s4, s4, s21, ne
    20c4:      	mov.s	w4, v0[1]
    20c8:      	add	x19, sp, #0x208
    20cc:      	bfxil	x19, x4, #0, #3
    20d0:      	ldrb	w4, [x19]
    20d4:      	ldr	w15, [sp, #0xe0]
    20d8:      	and	w4, w15, w4
    20dc:      	str	q1, [sp, #0x410]
    20e0:      	ldr	s5, [sp, #0x410]
    20e4:      	tst	w4, #0x1
    20e8:      	mov.s	w4, v0[2]
    20ec:      	fcsel	s5, s5, s21, ne
    20f0:      	add	x19, sp, #0x208
    20f4:      	bfxil	x19, x4, #0, #3
    20f8:      	add	x5, sp, #0x3f0
    20fc:      	orr	x4, x5, x4, lsl #2
    2100:      	ldrb	w19, [x19]
    2104:      	ldr	w23, [sp, #0x100]
    2108:      	and	w19, w23, w19
    210c:      	stp	q1, q3, [sp, #0x3f0]
    2110:      	ldr	s16, [x4]
    2114:      	tst	w19, #0x1
    2118:      	mov.s	w4, v0[3]
    211c:      	fcsel	s19, s16, s21, ne
    2120:      	add	x19, sp, #0x208
    2124:      	bfxil	x19, x4, #0, #3
    2128:      	add	x5, sp, #0x3d0
    212c:      	orr	x4, x5, x4, lsl #2
    2130:      	ldrb	w19, [x19]
    2134:      	ldr	w10, [sp, #0xf0]
    2138:      	and	w19, w10, w19
    213c:      	stp	q1, q3, [sp, #0x3d0]
    2140:      	ldr	s0, [x4]
    2144:      	tst	w19, #0x1
    2148:      	fcsel	s0, s0, s21, ne
    214c:      	fmov	w4, s18
    2150:      	add	x19, sp, #0x208
    2154:      	bfxil	x19, x4, #0, #3
    2158:      	ldrb	w19, [x19]
    215c:      	and	w19, w13, w19
    2160:      	stp	q1, q3, [sp, #0x3b0]
    2164:      	add	x5, sp, #0x3b0
    2168:      	ldr	s16, [x5, w4, uxtw #2]
    216c:      	tst	w19, #0x1
    2170:      	fcsel	s16, s16, s21, ne
    2174:      	mov.s	w4, v18[1]
    2178:      	add	x19, sp, #0x208
    217c:      	bfxil	x19, x4, #0, #3
    2180:      	ldrb	w19, [x19]
    2184:      	and	w19, w12, w19
    2188:      	stp	q1, q3, [sp, #0x390]
    218c:      	add	x5, sp, #0x390
    2190:      	ldr	s17, [x5, w4, uxtw #2]
    2194:      	tst	w19, #0x1
    2198:      	fcsel	s17, s17, s21, ne
    219c:      	mov.s	w4, v18[2]
    21a0:      	add	x19, sp, #0x208
    21a4:      	bfxil	x19, x4, #0, #3
    21a8:      	ldrb	w19, [x19]
    21ac:      	and	w19, w16, w19
    21b0:      	stp	q1, q3, [sp, #0x370]
    21b4:      	add	x5, sp, #0x370
    21b8:      	ldr	s20, [x5, w4, uxtw #2]
    21bc:      	tst	w19, #0x1
    21c0:      	fcsel	s20, s20, s21, ne
    21c4:      	mov.s	w4, v18[3]
    21c8:      	add	x19, sp, #0x208
    21cc:      	bfxil	x19, x4, #0, #3
    21d0:      	ldrb	w19, [x19]
    21d4:      	and	w19, w9, w19
    21d8:      	stp	q1, q3, [sp, #0x350]
    21dc:      	add	x5, sp, #0x350
    21e0:      	ldr	s18, [x5, w4, uxtw #2]
    21e4:      	tst	w19, #0x1
    21e8:      	fcsel	s18, s18, s21, ne
    21ec:      	mov.s	v16[1], v17[0]
    21f0:      	mov.s	v16[2], v20[0]
    21f4:      	mov.s	v16[3], v18[0]
    21f8:      	mov.s	v4[1], v5[0]
    21fc:      	and.16b	v5, v7, v2
    2200:      	mov.s	v4[2], v19[0]
    2204:      	mov.s	v4[3], v0[0]
    2208:      	fadd.4s	v1, v1, v4
    220c:      	fadd.4s	v2, v3, v16
    2210:      	fmov	w4, s5
    2214:      	add	x19, sp, #0x208
    2218:      	bfxil	x19, x4, #0, #3
    221c:      	ldrb	w19, [x19]
    2220:      	add	x5, sp, #0x330
    2224:      	orr	x4, x5, x4, lsl #2
    2228:      	stp	q1, q2, [sp, #0x330]
    222c:      	ldr	s0, [x4]
    2230:      	tst	w25, w19
    2234:      	mov.s	w4, v5[1]
    2238:      	add	x19, sp, #0x208
    223c:      	bfxil	x19, x4, #0, #3
    2240:      	ldrb	w19, [x19]
    2244:      	and	w15, w15, w19
    2248:      	fcsel	s3, s0, s21, ne
    224c:      	add	x5, sp, #0x310
    2250:      	orr	x4, x5, x4, lsl #2
    2254:      	stp	q1, q2, [sp, #0x310]
    2258:      	ldr	s0, [x4]
    225c:      	tst	w15, #0x1
    2260:      	mov.s	w15, v5[2]
    2264:      	add	x4, sp, #0x208
    2268:      	bfxil	x4, x15, #0, #3
    226c:      	fcsel	s4, s0, s21, ne
    2270:      	ldrb	w15, [x4]
    2274:      	and	w15, w23, w15
    2278:      	str	q1, [sp, #0x2f0]
    227c:      	tst	w15, #0x1
    2280:      	mov.s	w15, v5[3]
    2284:      	add	x4, sp, #0x208
    2288:      	bfxil	x4, x15, #0, #3
    228c:      	ldrb	w4, [x4]
    2290:      	and	w4, w10, w4
    2294:      	adrp	x5, 0x2000 <ltmp0+0x2000>
    2298:      	ldr	q0, [x5]
    229c:      	and.16b	v16, v6, v0
    22a0:      	ldr	s0, [sp, #0x2f0]
    22a4:      	fcsel	s5, s0, s21, ne
    22a8:      	add	x5, sp, #0x2d0
    22ac:      	orr	x15, x5, x15, lsl #2
    22b0:      	stp	q1, q2, [sp, #0x2d0]
    22b4:      	ldr	s0, [x15]
    22b8:      	tst	w4, #0x1
    22bc:      	fmov	w15, s16
    22c0:      	add	x4, sp, #0x208
    22c4:      	bfxil	x4, x15, #0, #3
    22c8:      	ldrb	w4, [x4]
    22cc:      	and	w13, w13, w4
    22d0:      	fcsel	s0, s0, s21, ne
    22d4:      	stp	q1, q2, [sp, #0x2b0]
    22d8:      	add	x4, sp, #0x2b0
    22dc:      	ldr	s17, [x4, w15, uxtw #2]
    22e0:      	tst	w13, #0x1
    22e4:      	mov.s	w13, v16[1]
    22e8:      	add	x15, sp, #0x208
    22ec:      	bfxil	x15, x13, #0, #3
    22f0:      	ldrb	w15, [x15]
    22f4:      	and	w12, w12, w15
    22f8:      	fcsel	s17, s17, s21, ne
    22fc:      	stp	q1, q2, [sp, #0x290]
    2300:      	add	x15, sp, #0x290
    2304:      	ldr	s18, [x15, w13, uxtw #2]
    2308:      	tst	w12, #0x1
    230c:      	mov.s	w12, v16[2]
    2310:      	add	x13, sp, #0x208
    2314:      	bfxil	x13, x12, #0, #3
    2318:      	ldrb	w13, [x13]
    231c:      	and	w13, w16, w13
    2320:      	fcsel	s18, s18, s21, ne
    2324:      	stp	q1, q2, [sp, #0x270]
    2328:      	add	x15, sp, #0x270
    232c:      	ldr	s19, [x15, w12, uxtw #2]
    2330:      	tst	w13, #0x1
    2334:      	mov.s	w12, v16[3]
    2338:      	add	x13, sp, #0x208
    233c:      	bfxil	x13, x12, #0, #3
    2340:      	ldrb	w13, [x13]
    2344:      	and	w9, w9, w13
    2348:      	fcsel	s16, s19, s21, ne
    234c:      	stp	q1, q2, [sp, #0x250]
    2350:      	add	x13, sp, #0x250
    2354:      	ldr	s19, [x13, w12, uxtw #2]
    2358:      	tst	w9, #0x1
    235c:      	fcsel	s19, s19, s21, ne
    2360:      	mov.s	v17[1], v18[0]
    2364:      	mov.s	v17[2], v16[0]
    2368:      	mov.s	v17[3], v19[0]
    236c:      	mov.s	v3[1], v4[0]
    2370:      	movi.4s	v4, #0x4
    2374:      	and.16b	v4, v7, v4
    2378:      	mov.s	v3[2], v5[0]
    237c:      	fmov	w9, s4
    2380:      	add	x12, sp, #0x208
    2384:      	orr	x12, x12, x9
    2388:      	ldrb	w12, [x12]
    238c:      	tst	w25, w12
    2390:      	mov.s	v3[3], v0[0]
    2394:      	fadd.4s	v0, v1, v3
    2398:      	fadd.4s	v1, v2, v17
    239c:      	stp	q0, q1, [sp, #0x230]
    23a0:      	add	x12, sp, #0x230
    23a4:      	ldr	s1, [x12, w9, uxtw #2]
    23a8:      	fcsel	s1, s1, s21, ne
    23ac:      	tst	w24, #0x1
    23b0:      	fadd	s0, s0, s1
    23b4:      	fcsel	s1, s0, s21, ne
    23b8:      	ldr	w9, [sp, #0x90]
    23bc:      	tst	w9, #0x1
    23c0:      	fcsel	s2, s0, s21, ne
    23c4:      	ldp	w9, w10, [sp, #0x7c]
    23c8:      	tst	w10, #0x1
    23cc:      	fcsel	s3, s0, s21, ne
    23d0:      	tst	w9, #0x1
    23d4:      	fcsel	s4, s0, s21, ne
    23d8:      	ldr	w9, [sp, #0xc0]
    23dc:      	tst	w9, #0x1
    23e0:      	fcsel	s5, s0, s21, ne
    23e4:      	ldp	w9, w10, [sp, #0x74]
    23e8:      	tst	w10, #0x1
    23ec:      	fcsel	s16, s0, s21, ne
    23f0:      	tst	w9, #0x1
    23f4:      	fcsel	s17, s0, s21, ne
    23f8:      	ldr	w9, [sp, #0x64]
    23fc:      	tst	w9, #0x1
    2400:      	mov.s	v1[1], v2[0]
    2404:      	mov.s	v1[2], v3[0]
    2408:      	mov.s	v1[3], v4[0]
    240c:      	mov.s	v5[1], v16[0]
    2410:      	mov.s	v5[2], v17[0]
    2414:      	fcsel	s0, s0, s21, ne
    2418:      	mov.s	v5[3], v0[0]
    241c:      	stp	q1, q5, [sp, #0x210]
    2420:      	ldr	x9, [sp, #0x68]
    2424:      	and	x9, x9, #0x7
    2428:      	add	x12, sp, #0x210
    242c:      	ldr	s3, [x12, x9, lsl #2]
    2430:      	add	x9, x17, x3
    2434:      	fmov	w12, s29
    2438:      	movi.2d	v2, #0000000000000000
    243c:      	movi.2d	v1, #0000000000000000
    2440:      	tbnz	w12, #0x0, 0x272c <ltmp0+0x272c>
    2444:      	ldp	w24, w19, [sp, #0x18]
    2448:      	mov	w23, #0x20              ; =32
    244c:      	ldr	x16, [sp, #0x160]
    2450:      	mov	w10, #0x104             ; =260
    2454:      	tbnz	w12, #0x1, 0x2744 <ltmp0+0x2744>
    2458:      	tbnz	w12, #0x2, 0x2750 <ltmp0+0x2750>
    245c:      	tbnz	w12, #0x3, 0x275c <ltmp0+0x275c>
    2460:      	tbnz	w12, #0x4, 0x2768 <ltmp0+0x2768>
    2464:      	tbnz	w12, #0x5, 0x2774 <ltmp0+0x2774>
    2468:      	tbnz	w12, #0x6, 0x2780 <ltmp0+0x2780>
    246c:      	tbz	w12, #0x7, 0x2478 <ltmp0+0x2478>
    2470:      	add	x9, x9, #0x1c
    2474:      	ld1.s	{ v1 }[3], [x9]
    2478:      	mov	x12, #0x0               ; =0
    247c:      	fadd	s0, s3, s21
    2480:      	fmov	s3, w11
    2484:      	fdiv	s0, s0, s3
    2488:      	fmov	s3, w14
    248c:      	fadd	s0, s0, s3
    2490:      	fsqrt	s0, s0
    2494:      	ldr	x9, [sp, #0x1a0]
    2498:      	add	x9, x30, x9
    249c:      	ldp	q3, q4, [x9]
    24a0:      	zip2.8b	v5, v10, v0
    24a4:      	ushll.4s	v5, v5, #0x0
    24a8:      	shl.4s	v5, v5, #0x1f
    24ac:      	cmlt.4s	v5, v5, #0
    24b0:      	bit.16b	v4, v1, v5
    24b4:      	zip1.8b	v5, v10, v0
    24b8:      	ushll.4s	v5, v5, #0x0
    24bc:      	shl.4s	v5, v5, #0x1f
    24c0:      	cmlt.4s	v5, v5, #0
    24c4:      	bit.16b	v3, v2, v5
    24c8:      	stp	q3, q4, [x9]
    24cc:      	dup.4s	v3, v0[0]
    24d0:      	ldr	q0, [sp, #0x110]
    24d4:      	fmov	x9, d0
    24d8:      	add	x9, x16, x9, lsl #2
    24dc:      	movi.2d	v4, #0000000000000000
    24e0:      	movi.2d	v5, #0000000000000000
    24e4:      	movi.2d	v18, #0000000000000000
    24e8:      	movi.2d	v19, #0000000000000000
    24ec:      	b	0x250c <ltmp0+0x250c>
    24f0:      	add.2d	v5, v5, v28
    24f4:      	add.2d	v18, v18, v30
    24f8:      	add.2d	v19, v19, v27
    24fc:      	add.2d	v4, v4, v31
    2500:      	fmov	x12, d4
    2504:      	cmp	x12, #0x8
    2508:      	b.ge	0x25e4 <ltmp0+0x25e4>
    250c:      	fmov	w13, s9
    2510:      	lsl	x12, x12, #5
    2514:      	add	x15, x26, x12
    2518:      	ldp	q16, q0, [x15]
    251c:      	and.16b	v16, v7, v16
    2520:      	fdiv.4s	v16, v16, v3
    2524:      	add	x15, x27, x12
    2528:      	ldp	q17, q20, [x15]
    252c:      	and.16b	v17, v7, v17
    2530:      	fmul.4s	v16, v16, v17
    2534:      	add	x15, x30, x12
    2538:      	ldp	q17, q21, [x15]
    253c:      	and.16b	v17, v7, v17
    2540:      	fadd.4s	v22, v16, v17
    2544:      	add	x12, x9, x12
    2548:      	tbnz	w13, #0x0, 0x2590 <ltmp0+0x2590>
    254c:      	and	w13, w13, #0xff
    2550:      	tbnz	w13, #0x1, 0x259c <ltmp0+0x259c>
    2554:      	tbnz	w13, #0x2, 0x25a8 <ltmp0+0x25a8>
    2558:      	tbz	w13, #0x3, 0x2564 <ltmp0+0x2564>
    255c:      	add	x15, x12, #0xc
    2560:      	st1.s	{ v22 }[3], [x15]
    2564:      	and.16b	v0, v6, v0
    2568:      	fdiv.4s	v0, v0, v3
    256c:      	and.16b	v16, v6, v20
    2570:      	fmul.4s	v0, v0, v16
    2574:      	and.16b	v16, v6, v21
    2578:      	fadd.4s	v0, v0, v16
    257c:      	tbnz	w13, #0x4, 0x25b8 <ltmp0+0x25b8>
    2580:      	tbnz	w13, #0x5, 0x25c0 <ltmp0+0x25c0>
    2584:      	tbnz	w13, #0x6, 0x25cc <ltmp0+0x25cc>
    2588:      	tbz	w13, #0x7, 0x24f0 <ltmp0+0x24f0>
    258c:      	b	0x25d8 <ltmp0+0x25d8>
    2590:      	str	s22, [x12]
    2594:      	and	w13, w13, #0xff
    2598:      	tbz	w13, #0x1, 0x2554 <ltmp0+0x2554>
    259c:      	add	x15, x12, #0x4
    25a0:      	st1.s	{ v22 }[1], [x15]
    25a4:      	tbz	w13, #0x2, 0x2558 <ltmp0+0x2558>
    25a8:      	add	x15, x12, #0x8
    25ac:      	st1.s	{ v22 }[2], [x15]
    25b0:      	tbnz	w13, #0x3, 0x255c <ltmp0+0x255c>
    25b4:      	b	0x2564 <ltmp0+0x2564>
    25b8:      	str	s0, [x12, #0x10]
    25bc:      	tbz	w13, #0x5, 0x2584 <ltmp0+0x2584>
    25c0:      	add	x15, x12, #0x14
    25c4:      	st1.s	{ v0 }[1], [x15]
    25c8:      	tbz	w13, #0x6, 0x2588 <ltmp0+0x2588>
    25cc:      	add	x15, x12, #0x18
    25d0:      	st1.s	{ v0 }[2], [x15]
    25d4:      	tbz	w13, #0x7, 0x24f0 <ltmp0+0x24f0>
    25d8:      	add	x12, x12, #0x1c
    25dc:      	st1.s	{ v0 }[3], [x12]
    25e0:      	b	0x24f0 <ltmp0+0x24f0>
    25e4:      	fmov	w9, s29
    25e8:      	zip1.8b	v0, v10, v0
    25ec:      	ushll.4s	v0, v0, #0x0
    25f0:      	shl.4s	v0, v0, #0x1f
    25f4:      	cmlt.4s	v0, v0, #0
    25f8:      	and.16b	v0, v0, v26
    25fc:      	fdiv.4s	v0, v0, v3
    2600:      	fmul.4s	v0, v0, v8
    2604:      	fadd.4s	v0, v0, v2
    2608:      	ldp	q2, q4, [sp, #0x140]
    260c:      	ldp	q6, q5, [sp, #0x120]
    2610:      	stp	q4, q5, [sp, #0x1c0]
    2614:      	stp	q6, q2, [sp, #0x1e0]
    2618:      	and	x12, x28, #0x7
    261c:      	add	x13, sp, #0x1c0
    2620:      	ldr	x12, [x13, x12, lsl #3]
    2624:      	sub	x12, x12, x28
    2628:      	add	x12, x16, x12, lsl #2
    262c:      	tbnz	w9, #0x0, 0x2790 <ltmp0+0x2790>
    2630:      	ldr	w25, [sp, #0x14]
    2634:      	mov	w28, #0x18              ; =24
    2638:      	tbnz	w9, #0x1, 0x27a0 <ltmp0+0x27a0>
    263c:      	tbnz	w9, #0x2, 0x27ac <ltmp0+0x27ac>
    2640:      	tbz	w9, #0x3, 0x264c <ltmp0+0x264c>
    2644:      	add	x13, x12, #0xc
    2648:      	st1.s	{ v0 }[3], [x13]
    264c:      	zip2.8b	v0, v10, v0
    2650:      	ushll.4s	v0, v0, #0x0
    2654:      	shl.4s	v0, v0, #0x1f
    2658:      	cmlt.4s	v0, v0, #0
    265c:      	and.16b	v0, v0, v24
    2660:      	fdiv.4s	v0, v0, v3
    2664:      	fmul.4s	v0, v0, v25
    2668:      	fadd.4s	v0, v0, v1
    266c:      	tbnz	w9, #0x4, 0x27bc <ltmp0+0x27bc>
    2670:      	tbnz	w9, #0x5, 0x27c4 <ltmp0+0x27c4>
    2674:      	tbnz	w9, #0x6, 0x27d0 <ltmp0+0x27d0>
    2678:      	tbz	w9, #0x7, 0xdd0 <ltmp0+0xdd0>
    267c:      	b	0x27dc <ltmp0+0x27dc>
    2680:      	ldr	s24, [x12]
    2684:      	tbz	w9, #0x1, 0x1400 <ltmp0+0x1400>
    2688:      	add	x13, x12, #0x4
    268c:      	ld1.s	{ v24 }[1], [x13]
    2690:      	tbz	w9, #0x2, 0x1404 <ltmp0+0x1404>
    2694:      	add	x13, x12, #0x8
    2698:      	ld1.s	{ v24 }[2], [x13]
    269c:      	tbz	w9, #0x3, 0x1408 <ltmp0+0x1408>
    26a0:      	add	x13, x12, #0xc
    26a4:      	ld1.s	{ v24 }[3], [x13]
    26a8:      	tbz	w9, #0x4, 0x140c <ltmp0+0x140c>
    26ac:      	add	x13, x12, #0x10
    26b0:      	ld1.s	{ v27 }[0], [x13]
    26b4:      	tbz	w9, #0x5, 0x1410 <ltmp0+0x1410>
    26b8:      	add	x13, x12, #0x14
    26bc:      	ld1.s	{ v27 }[1], [x13]
    26c0:      	tbz	w9, #0x6, 0x1414 <ltmp0+0x1414>
    26c4:      	add	x13, x12, #0x18
    26c8:      	ld1.s	{ v27 }[2], [x13]
    26cc:      	str	q16, [sp, #0x1b0]
    26d0:      	tbnz	w9, #0x7, 0x141c <ltmp0+0x141c>
    26d4:      	b	0x1424 <ltmp0+0x1424>
    26d8:      	ldr	s8, [x23]
    26dc:      	tbz	w25, #0x1, 0x1eb0 <ltmp0+0x1eb0>
    26e0:      	add	x4, x23, #0x4
    26e4:      	ld1.s	{ v8 }[1], [x4]
    26e8:      	tbz	w25, #0x2, 0x1eb4 <ltmp0+0x1eb4>
    26ec:      	add	x4, x23, #0x8
    26f0:      	ld1.s	{ v8 }[2], [x4]
    26f4:      	tbz	w25, #0x3, 0x1eb8 <ltmp0+0x1eb8>
    26f8:      	add	x4, x23, #0xc
    26fc:      	ld1.s	{ v8 }[3], [x4]
    2700:      	tbz	w25, #0x4, 0x1ebc <ltmp0+0x1ebc>
    2704:      	add	x4, x23, #0x10
    2708:      	ld1.s	{ v25 }[0], [x4]
    270c:      	tbz	w25, #0x5, 0x1ec0 <ltmp0+0x1ec0>
    2710:      	add	x4, x23, #0x14
    2714:      	ld1.s	{ v25 }[1], [x4]
    2718:      	tbz	w25, #0x6, 0x1ec4 <ltmp0+0x1ec4>
    271c:      	add	x4, x23, #0x18
    2720:      	ld1.s	{ v25 }[2], [x4]
    2724:      	tbnz	w25, #0x7, 0x1ec8 <ltmp0+0x1ec8>
    2728:      	b	0x1ed0 <ltmp0+0x1ed0>
    272c:      	ldr	s2, [x9]
    2730:      	ldp	w24, w19, [sp, #0x18]
    2734:      	mov	w23, #0x20              ; =32
    2738:      	ldr	x16, [sp, #0x160]
    273c:      	mov	w10, #0x104             ; =260
    2740:      	tbz	w12, #0x1, 0x2458 <ltmp0+0x2458>
    2744:      	add	x13, x9, #0x4
    2748:      	ld1.s	{ v2 }[1], [x13]
    274c:      	tbz	w12, #0x2, 0x245c <ltmp0+0x245c>
    2750:      	add	x13, x9, #0x8
    2754:      	ld1.s	{ v2 }[2], [x13]
    2758:      	tbz	w12, #0x3, 0x2460 <ltmp0+0x2460>
    275c:      	add	x13, x9, #0xc
    2760:      	ld1.s	{ v2 }[3], [x13]
    2764:      	tbz	w12, #0x4, 0x2464 <ltmp0+0x2464>
    2768:      	add	x13, x9, #0x10
    276c:      	ld1.s	{ v1 }[0], [x13]
    2770:      	tbz	w12, #0x5, 0x2468 <ltmp0+0x2468>
    2774:      	add	x13, x9, #0x14
    2778:      	ld1.s	{ v1 }[1], [x13]
    277c:      	tbz	w12, #0x6, 0x246c <ltmp0+0x246c>
    2780:      	add	x13, x9, #0x18
    2784:      	ld1.s	{ v1 }[2], [x13]
    2788:      	tbnz	w12, #0x7, 0x2470 <ltmp0+0x2470>
    278c:      	b	0x2478 <ltmp0+0x2478>
    2790:      	str	s0, [x12]
    2794:      	ldr	w25, [sp, #0x14]
    2798:      	mov	w28, #0x18              ; =24
    279c:      	tbz	w9, #0x1, 0x263c <ltmp0+0x263c>
    27a0:      	add	x13, x12, #0x4
    27a4:      	st1.s	{ v0 }[1], [x13]
    27a8:      	tbz	w9, #0x2, 0x2640 <ltmp0+0x2640>
    27ac:      	add	x13, x12, #0x8
    27b0:      	st1.s	{ v0 }[2], [x13]
    27b4:      	tbnz	w9, #0x3, 0x2644 <ltmp0+0x2644>
    27b8:      	b	0x264c <ltmp0+0x264c>
    27bc:      	str	s0, [x12, #0x10]
    27c0:      	tbz	w9, #0x5, 0x2674 <ltmp0+0x2674>
    27c4:      	add	x13, x12, #0x14
    27c8:      	st1.s	{ v0 }[1], [x13]
    27cc:      	tbz	w9, #0x6, 0x2678 <ltmp0+0x2678>
    27d0:      	add	x13, x12, #0x18
    27d4:      	st1.s	{ v0 }[2], [x13]
    27d8:      	tbz	w9, #0x7, 0xdd0 <ltmp0+0xdd0>
    27dc:      	add	x9, x12, #0x1c
    27e0:      	st1.s	{ v0 }[3], [x9]
    27e4:      	b	0xdd0 <ltmp0+0xdd0>
    27e8:      	add	sp, sp, #0xb20
    27ec:      	ldp	x29, x30, [sp, #0x90]
    27f0:      	ldp	x20, x19, [sp, #0x80]
    27f4:      	ldp	x22, x21, [sp, #0x70]
    27f8:      	ldp	x24, x23, [sp, #0x60]
    27fc:      	ldp	x26, x25, [sp, #0x50]
    2800:      	ldp	x28, x27, [sp, #0x40]
    2804:      	ldp	d9, d8, [sp, #0x30]
    2808:      	ldp	d11, d10, [sp, #0x20]
    280c:      	ldp	d13, d12, [sp, #0x10]
    2810:      	ldp	d15, d14, [sp], #0xa0
    2814:      	ret


/private/tmp/luisa-expression-fusion.qXgTbC/capture/layernorm-17x65/off/object/tile_xir_w8_23330_1788930261539240_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	cbz	w3, 0x2704 <ltmp0+0x2704>
       4:      	stp	d15, d14, [sp, #-0xa0]!
       8:      	stp	d13, d12, [sp, #0x10]
       c:      	stp	d11, d10, [sp, #0x20]
      10:      	stp	d9, d8, [sp, #0x30]
      14:      	stp	x28, x27, [sp, #0x40]
      18:      	stp	x26, x25, [sp, #0x50]
      1c:      	stp	x24, x23, [sp, #0x60]
      20:      	stp	x22, x21, [sp, #0x70]
      24:      	stp	x20, x19, [sp, #0x80]
      28:      	stp	x29, x30, [sp, #0x90]
      2c:      	sub	sp, sp, #0xb60
      30:      	mov	w8, #0x0                ; =0
      34:      	mov	w23, #0x20              ; =32
      38:      	mov	w26, #0x104             ; =260
      3c:      	mov	w11, #0x42820000        ; =1115815936
      40:      	ldp	w28, w30, [x2, #0x2c]
      44:      	mov	w14, #0xc5ac            ; =50604
      48:      	movk	w14, #0x3727, lsl #16
      4c:      	ldp	w1, w7, [x2]
      50:      	add	x6, sp, #0xa40
      54:      	ldp	w20, w21, [x2, #0x8]
      58:      	mov	w22, #0x4               ; =4
      5c:      	add	x24, sp, #0x920
      60:      	add	x25, sp, #0x800
      64:      	add	x27, sp, #0x6e0
      68:      	stp	w28, w3, [sp, #0x20]
      6c:      	str	x0, [sp, #0x10]
      70:      	str	w30, [sp, #0x1c]
      74:      	b	0xde0 <ltmp0+0xde0>
      78:      	ldr	x15, [x0]
      7c:      	ldr	x13, [x0, #0x10]
      80:      	ldr	x12, [x0, #0x20]
      84:      	ldr	x9, [x0, #0x30]
      88:      	ubfiz	w17, w1, #2, #27
      8c:      	umull	x10, w17, w26
      90:      	umaddl	x16, w17, w26, x15
      94:      	ldp	q0, q1, [x16]
      98:      	ldp	q3, q2, [x16, #0x20]
      9c:      	ldp	q4, q5, [x16, #0x40]
      a0:      	ldp	q16, q7, [x16, #0x60]
      a4:      	ldp	q17, q18, [x16, #0x80]
      a8:      	ldp	q27, q26, [x16, #0xa0]
      ac:      	ldp	q30, q31, [x16, #0xc0]
      b0:      	ldp	q9, q8, [x16, #0xe0]
      b4:      	add	x16, x10, #0x100
      b8:      	ldr	s10, [x15, x16]
      bc:      	fadd.4s	v6, v16, v9
      c0:      	fadd.4s	v19, v7, v8
      c4:      	fadd.4s	v20, v5, v31
      c8:      	fadd.4s	v21, v4, v30
      cc:      	fadd.4s	v22, v3, v27
      d0:      	fadd.4s	v23, v2, v26
      d4:      	fadd.4s	v24, v1, v18
      d8:      	fadd.4s	v25, v0, v17
      dc:      	fadd.4s	v28, v25, v10
      e0:      	mov.s	v25[0], v28[0]
      e4:      	fadd.4s	v23, v23, v24
      e8:      	fadd.4s	v22, v22, v25
      ec:      	fadd.4s	v21, v21, v22
      f0:      	fadd.4s	v20, v20, v23
      f4:      	fadd.4s	v19, v19, v20
      f8:      	fadd.4s	v6, v6, v21
      fc:      	rev64.4s	v20, v6
     100:      	rev64.4s	v21, v19
     104:      	fadd.4s	v19, v19, v21
     108:      	fadd.4s	v6, v6, v20
     10c:      	dup.4s	v20, v6[2]
     110:      	dup.4s	v21, v19[2]
     114:      	fadd.4s	v19, v19, v21
     118:      	fadd.4s	v6, v6, v20
     11c:      	fadd.4s	v6, v6, v19
     120:      	movi	d19, #0000000000000000
     124:      	fadd	s19, s6, s19
     128:      	movi	d20, #0000000000000000
     12c:      	fmov	s6, w11
     130:      	fdiv	s11, s19, s6
     134:      	str	s6, [sp, #0x1e0]
     138:      	dup.4s	v12, v11[0]
     13c:      	fsub.4s	v29, v1, v12
     140:      	fsub.4s	v28, v0, v12
     144:      	fsub.4s	v25, v3, v12
     148:      	fsub.4s	v13, v2, v12
     14c:      	stp	q13, q25, [sp, #0xd0]
     150:      	fsub.4s	v24, v5, v12
     154:      	fsub.4s	v23, v4, v12
     158:      	fsub.4s	v21, v16, v12
     15c:      	fsub.4s	v22, v7, v12
     160:      	stp	q23, q22, [sp, #0x120]
     164:      	fsub.4s	v18, v18, v12
     168:      	str	q18, [sp, #0x110]
     16c:      	fsub.4s	v19, v17, v12
     170:      	stp	q24, q19, [sp, #0xf0]
     174:      	fsub.4s	v16, v27, v12
     178:      	stp	q21, q16, [sp, #0x140]
     17c:      	fsub.4s	v17, v26, v12
     180:      	fsub.4s	v4, v31, v12
     184:      	fsub.4s	v5, v30, v12
     188:      	stp	q17, q5, [sp, #0x160]
     18c:      	fsub.4s	v2, v9, v12
     190:      	fsub.4s	v3, v8, v12
     194:      	stp	q2, q3, [sp, #0x1c0]
     198:      	fsub.4s	v1, v10, v11
     19c:      	ldp	q30, q8, [x13]
     1a0:      	ldp	q7, q0, [x13, #0x20]
     1a4:      	stp	q1, q7, [sp, #0x1a0]
     1a8:      	stp	q4, q0, [sp, #0x180]
     1ac:      	fmul.4s	v0, v28, v28
     1b0:      	fmul.4s	v7, v29, v29
     1b4:      	fmul.4s	v31, v13, v13
     1b8:      	fmul.4s	v9, v25, v25
     1bc:      	fmul.4s	v10, v23, v23
     1c0:      	fmul.4s	v11, v24, v24
     1c4:      	fmul.4s	v12, v22, v22
     1c8:      	fmul.4s	v13, v21, v21
     1cc:      	fmul.4s	v14, v3, v3
     1d0:      	fmul.4s	v15, v2, v2
     1d4:      	fadd.4s	v13, v13, v15
     1d8:      	fadd.4s	v12, v12, v14
     1dc:      	fmul.4s	v14, v5, v5
     1e0:      	fmul.4s	v15, v4, v4
     1e4:      	fadd.4s	v15, v11, v15
     1e8:      	fadd.4s	v14, v10, v14
     1ec:      	fmul.4s	v10, v17, v17
     1f0:      	fmul.4s	v11, v16, v16
     1f4:      	fadd.4s	v9, v9, v11
     1f8:      	fadd.4s	v31, v31, v10
     1fc:      	fmul.4s	v10, v19, v19
     200:      	fmul.4s	v11, v18, v18
     204:      	fadd.4s	v0, v0, v10
     208:      	fmul.4s	v10, v1, v1
     20c:      	fadd.4s	v10, v10, v0
     210:      	mov.s	v0[0], v10[0]
     214:      	fadd.4s	v7, v7, v11
     218:      	ldp	q1, q11, [x13, #0x40]
     21c:      	str	q1, [sp, #0xc0]
     220:      	fadd.4s	v7, v31, v7
     224:      	fadd.4s	v0, v9, v0
     228:      	fadd.4s	v0, v14, v0
     22c:      	fadd.4s	v7, v15, v7
     230:      	fadd.4s	v7, v12, v7
     234:      	fadd.4s	v0, v13, v0
     238:      	rev64.4s	v31, v0
     23c:      	rev64.4s	v9, v7
     240:      	fadd.4s	v7, v7, v9
     244:      	fadd.4s	v0, v0, v31
     248:      	dup.4s	v31, v0[2]
     24c:      	dup.4s	v9, v7[2]
     250:      	ldp	q12, q13, [x13, #0x60]
     254:      	fadd.4s	v7, v7, v9
     258:      	fadd.4s	v0, v0, v31
     25c:      	fadd.4s	v0, v0, v7
     260:      	fadd	s0, s0, s20
     264:      	fdiv	s0, s0, s6
     268:      	fmov	s1, w14
     26c:      	str	s1, [sp, #0x1f0]
     270:      	fadd	s0, s0, s1
     274:      	fsqrt	s31, s0
     278:      	dup.4s	v9, v31[0]
     27c:      	ldp	q14, q15, [x13, #0x80]
     280:      	fdiv.4s	v0, v29, v9
     284:      	fmul.4s	v0, v8, v0
     288:      	ldp	q8, q29, [x12]
     28c:      	fdiv.4s	v28, v28, v9
     290:      	fmul.4s	v28, v30, v28
     294:      	fadd.4s	v3, v8, v28
     298:      	ldp	q25, q24, [x13, #0xa0]
     29c:      	umaddl	x10, w17, w26, x9
     2a0:      	fadd.4s	v0, v29, v0
     2a4:      	ldp	q30, q8, [x13, #0xc0]
     2a8:      	ldp	q27, q29, [x13, #0xe0]
     2ac:      	ldr	s28, [x13, #0x100]
     2b0:      	ldp	q1, q2, [x12, #0x20]
     2b4:      	ldp	q4, q5, [x12, #0x40]
     2b8:      	ldp	q6, q7, [x12, #0x60]
     2bc:      	ldp	q16, q17, [x12, #0x80]
     2c0:      	ldp	q18, q19, [x12, #0xa0]
     2c4:      	ldp	q20, q21, [x12, #0xc0]
     2c8:      	ldp	q22, q23, [x12, #0xe0]
     2cc:      	ldr	s26, [x12, #0x100]
     2d0:      	stp	q3, q0, [x10]
     2d4:      	ldr	q0, [sp, #0xd0]
     2d8:      	fdiv.4s	v0, v0, v9
     2dc:      	ldr	q3, [sp, #0x190]
     2e0:      	fmul.4s	v0, v3, v0
     2e4:      	ldr	q3, [sp, #0xe0]
     2e8:      	fdiv.4s	v3, v3, v9
     2ec:      	ldr	q10, [sp, #0x1b0]
     2f0:      	fmul.4s	v3, v10, v3
     2f4:      	fadd.4s	v1, v1, v3
     2f8:      	fadd.4s	v0, v2, v0
     2fc:      	stp	q1, q0, [x10, #0x20]
     300:      	ldr	q0, [sp, #0xf0]
     304:      	fdiv.4s	v0, v0, v9
     308:      	fmul.4s	v0, v11, v0
     30c:      	ldr	q1, [sp, #0x120]
     310:      	fdiv.4s	v1, v1, v9
     314:      	ldr	q2, [sp, #0xc0]
     318:      	fmul.4s	v1, v2, v1
     31c:      	fadd.4s	v1, v4, v1
     320:      	fadd.4s	v0, v5, v0
     324:      	stp	q1, q0, [x10, #0x40]
     328:      	ldp	q0, q1, [sp, #0x130]
     32c:      	fdiv.4s	v0, v0, v9
     330:      	fmul.4s	v0, v13, v0
     334:      	fdiv.4s	v1, v1, v9
     338:      	fmul.4s	v1, v12, v1
     33c:      	fadd.4s	v1, v6, v1
     340:      	fadd.4s	v0, v7, v0
     344:      	stp	q1, q0, [x10, #0x60]
     348:      	ldp	q0, q1, [sp, #0x100]
     34c:      	fdiv.4s	v0, v0, v9
     350:      	fdiv.4s	v1, v1, v9
     354:      	fmul.4s	v1, v15, v1
     358:      	fmul.4s	v0, v14, v0
     35c:      	fadd.4s	v0, v16, v0
     360:      	fadd.4s	v1, v17, v1
     364:      	stp	q0, q1, [x10, #0x80]
     368:      	ldp	q0, q1, [sp, #0x150]
     36c:      	fdiv.4s	v0, v0, v9
     370:      	fdiv.4s	v1, v1, v9
     374:      	fmul.4s	v1, v24, v1
     378:      	fmul.4s	v0, v25, v0
     37c:      	fadd.4s	v0, v18, v0
     380:      	fadd.4s	v1, v19, v1
     384:      	stp	q0, q1, [x10, #0xa0]
     388:      	ldp	q0, q1, [sp, #0x170]
     38c:      	fdiv.4s	v0, v0, v9
     390:      	fdiv.4s	v1, v1, v9
     394:      	fmul.4s	v1, v8, v1
     398:      	fmul.4s	v0, v30, v0
     39c:      	fadd.4s	v0, v20, v0
     3a0:      	fadd.4s	v1, v21, v1
     3a4:      	stp	q0, q1, [x10, #0xc0]
     3a8:      	ldp	q0, q1, [sp, #0x1c0]
     3ac:      	fdiv.4s	v0, v0, v9
     3b0:      	fdiv.4s	v1, v1, v9
     3b4:      	fmul.4s	v1, v29, v1
     3b8:      	fmul.4s	v0, v27, v0
     3bc:      	fadd.4s	v0, v22, v0
     3c0:      	fadd.4s	v1, v23, v1
     3c4:      	stp	q0, q1, [x10, #0xe0]
     3c8:      	ldr	q0, [sp, #0x1a0]
     3cc:      	fdiv.4s	v0, v0, v31
     3d0:      	fmul.4s	v0, v28, v0
     3d4:      	fadd.4s	v0, v26, v0
     3d8:      	str	s0, [x9, x16]
     3dc:      	mov	w17, #0x1               ; =1
     3e0:      	bfi	w17, w1, #2, #27
     3e4:      	umull	x10, w17, w26
     3e8:      	umaddl	x16, w17, w26, x15
     3ec:      	ldp	q0, q1, [x16]
     3f0:      	ldp	q3, q2, [x16, #0x20]
     3f4:      	ldp	q4, q5, [x16, #0x40]
     3f8:      	ldp	q7, q6, [x16, #0x60]
     3fc:      	ldp	q16, q17, [x16, #0x80]
     400:      	ldp	q27, q26, [x16, #0xa0]
     404:      	ldp	q30, q31, [x16, #0xc0]
     408:      	ldp	q9, q8, [x16, #0xe0]
     40c:      	add	x16, x10, #0x100
     410:      	ldr	s10, [x15, x16]
     414:      	fadd.4s	v18, v7, v9
     418:      	fadd.4s	v19, v6, v8
     41c:      	fadd.4s	v20, v5, v31
     420:      	fadd.4s	v21, v4, v30
     424:      	fadd.4s	v22, v3, v27
     428:      	fadd.4s	v23, v2, v26
     42c:      	fadd.4s	v24, v1, v17
     430:      	fadd.4s	v25, v0, v16
     434:      	fadd.4s	v28, v25, v10
     438:      	mov.s	v25[0], v28[0]
     43c:      	fadd.4s	v23, v23, v24
     440:      	fadd.4s	v22, v22, v25
     444:      	fadd.4s	v21, v21, v22
     448:      	fadd.4s	v20, v20, v23
     44c:      	fadd.4s	v19, v19, v20
     450:      	fadd.4s	v18, v18, v21
     454:      	rev64.4s	v20, v18
     458:      	rev64.4s	v21, v19
     45c:      	fadd.4s	v19, v19, v21
     460:      	fadd.4s	v18, v18, v20
     464:      	dup.4s	v20, v18[2]
     468:      	dup.4s	v21, v19[2]
     46c:      	fadd.4s	v19, v19, v21
     470:      	fadd.4s	v18, v18, v20
     474:      	fadd.4s	v18, v18, v19
     478:      	movi	d20, #0000000000000000
     47c:      	fadd	s18, s18, s20
     480:      	ldr	s19, [sp, #0x1e0]
     484:      	fdiv	s11, s18, s19
     488:      	dup.4s	v12, v11[0]
     48c:      	fsub.4s	v29, v1, v12
     490:      	fsub.4s	v28, v0, v12
     494:      	fsub.4s	v13, v3, v12
     498:      	fsub.4s	v14, v2, v12
     49c:      	stp	q14, q13, [sp, #0xe0]
     4a0:      	fsub.4s	v25, v5, v12
     4a4:      	fsub.4s	v24, v4, v12
     4a8:      	stp	q25, q24, [sp, #0x120]
     4ac:      	fsub.4s	v22, v7, v12
     4b0:      	fsub.4s	v23, v6, v12
     4b4:      	stp	q23, q22, [sp, #0x140]
     4b8:      	fsub.4s	v18, v17, v12
     4bc:      	fsub.4s	v21, v16, v12
     4c0:      	stp	q21, q18, [sp, #0x100]
     4c4:      	fsub.4s	v16, v27, v12
     4c8:      	fsub.4s	v17, v26, v12
     4cc:      	stp	q17, q16, [sp, #0x160]
     4d0:      	fsub.4s	v4, v31, v12
     4d4:      	fsub.4s	v5, v30, v12
     4d8:      	stp	q5, q4, [sp, #0x180]
     4dc:      	fsub.4s	v2, v9, v12
     4e0:      	fsub.4s	v3, v8, v12
     4e4:      	stp	q3, q2, [sp, #0x1c0]
     4e8:      	fsub.4s	v1, v10, v11
     4ec:      	ldp	q30, q8, [x13]
     4f0:      	ldp	q0, q27, [x13, #0x20]
     4f4:      	stp	q1, q0, [sp, #0x1a0]
     4f8:      	fmul.4s	v0, v28, v28
     4fc:      	fmul.4s	v6, v29, v29
     500:      	fmul.4s	v7, v14, v14
     504:      	fmul.4s	v31, v13, v13
     508:      	fmul.4s	v9, v24, v24
     50c:      	fmul.4s	v10, v25, v25
     510:      	fmul.4s	v11, v23, v23
     514:      	fmul.4s	v12, v22, v22
     518:      	fmul.4s	v13, v2, v2
     51c:      	fadd.4s	v14, v12, v13
     520:      	fmul.4s	v12, v3, v3
     524:      	fadd.4s	v15, v11, v12
     528:      	fmul.4s	v11, v4, v4
     52c:      	fadd.4s	v10, v10, v11
     530:      	fmul.4s	v11, v5, v5
     534:      	fadd.4s	v9, v9, v11
     538:      	fmul.4s	v11, v16, v16
     53c:      	fadd.4s	v31, v31, v11
     540:      	fmul.4s	v11, v17, v17
     544:      	fadd.4s	v7, v7, v11
     548:      	fmul.4s	v11, v18, v18
     54c:      	fadd.4s	v6, v6, v11
     550:      	fmul.4s	v11, v21, v21
     554:      	fadd.4s	v0, v0, v11
     558:      	fmul.4s	v11, v1, v1
     55c:      	fadd.4s	v11, v11, v0
     560:      	mov.s	v0[0], v11[0]
     564:      	fadd.4s	v7, v7, v6
     568:      	ldp	q12, q13, [x13, #0x40]
     56c:      	fadd.4s	v0, v31, v0
     570:      	fadd.4s	v0, v9, v0
     574:      	ldp	q1, q11, [x13, #0x60]
     578:      	str	q1, [sp, #0xd0]
     57c:      	fadd.4s	v7, v10, v7
     580:      	fadd.4s	v7, v15, v7
     584:      	fadd.4s	v0, v14, v0
     588:      	rev64.4s	v31, v0
     58c:      	rev64.4s	v9, v7
     590:      	fadd.4s	v7, v7, v9
     594:      	fadd.4s	v0, v0, v31
     598:      	dup.4s	v31, v0[2]
     59c:      	dup.4s	v9, v7[2]
     5a0:      	fadd.4s	v7, v7, v9
     5a4:      	fadd.4s	v0, v0, v31
     5a8:      	fadd.4s	v0, v0, v7
     5ac:      	fadd	s0, s0, s20
     5b0:      	fdiv	s0, s0, s19
     5b4:      	ldr	s1, [sp, #0x1f0]
     5b8:      	fadd	s0, s0, s1
     5bc:      	fsqrt	s31, s0
     5c0:      	dup.4s	v9, v31[0]
     5c4:      	ldp	q14, q15, [x13, #0x80]
     5c8:      	fdiv.4s	v0, v29, v9
     5cc:      	fmul.4s	v0, v8, v0
     5d0:      	ldp	q29, q7, [x12]
     5d4:      	fdiv.4s	v28, v28, v9
     5d8:      	fmul.4s	v28, v30, v28
     5dc:      	fadd.4s	v10, v29, v28
     5e0:      	ldp	q23, q28, [x13, #0xa0]
     5e4:      	umaddl	x10, w17, w26, x9
     5e8:      	fadd.4s	v0, v7, v0
     5ec:      	ldp	q30, q8, [x13, #0xc0]
     5f0:      	ldp	q25, q29, [x13, #0xe0]
     5f4:      	ldr	s26, [x13, #0x100]
     5f8:      	ldp	q1, q2, [x12, #0x20]
     5fc:      	ldp	q3, q4, [x12, #0x40]
     600:      	ldp	q5, q6, [x12, #0x60]
     604:      	ldp	q7, q16, [x12, #0x80]
     608:      	ldp	q17, q18, [x12, #0xa0]
     60c:      	ldp	q19, q20, [x12, #0xc0]
     610:      	ldp	q21, q22, [x12, #0xe0]
     614:      	ldr	s24, [x12, #0x100]
     618:      	stp	q10, q0, [x10]
     61c:      	ldr	q0, [sp, #0xe0]
     620:      	fdiv.4s	v0, v0, v9
     624:      	fmul.4s	v0, v27, v0
     628:      	ldr	q27, [sp, #0xf0]
     62c:      	fdiv.4s	v10, v27, v9
     630:      	ldr	q27, [sp, #0x1b0]
     634:      	fmul.4s	v10, v27, v10
     638:      	fadd.4s	v1, v1, v10
     63c:      	fadd.4s	v0, v2, v0
     640:      	stp	q1, q0, [x10, #0x20]
     644:      	ldp	q0, q1, [sp, #0x120]
     648:      	fdiv.4s	v0, v0, v9
     64c:      	fmul.4s	v0, v13, v0
     650:      	fdiv.4s	v1, v1, v9
     654:      	fmul.4s	v1, v12, v1
     658:      	fadd.4s	v1, v3, v1
     65c:      	fadd.4s	v0, v4, v0
     660:      	stp	q1, q0, [x10, #0x40]
     664:      	ldp	q0, q1, [sp, #0x140]
     668:      	fdiv.4s	v0, v0, v9
     66c:      	fmul.4s	v0, v11, v0
     670:      	fdiv.4s	v1, v1, v9
     674:      	ldr	q2, [sp, #0xd0]
     678:      	fmul.4s	v1, v2, v1
     67c:      	fadd.4s	v1, v5, v1
     680:      	fadd.4s	v0, v6, v0
     684:      	stp	q1, q0, [x10, #0x60]
     688:      	ldp	q0, q1, [sp, #0x100]
     68c:      	fdiv.4s	v0, v0, v9
     690:      	fdiv.4s	v1, v1, v9
     694:      	fmul.4s	v1, v15, v1
     698:      	fmul.4s	v0, v14, v0
     69c:      	fadd.4s	v0, v7, v0
     6a0:      	fadd.4s	v1, v16, v1
     6a4:      	stp	q0, q1, [x10, #0x80]
     6a8:      	ldp	q1, q0, [sp, #0x160]
     6ac:      	fdiv.4s	v0, v0, v9
     6b0:      	fdiv.4s	v1, v1, v9
     6b4:      	fmul.4s	v1, v28, v1
     6b8:      	fmul.4s	v0, v23, v0
     6bc:      	fadd.4s	v0, v17, v0
     6c0:      	fadd.4s	v1, v18, v1
     6c4:      	stp	q0, q1, [x10, #0xa0]
     6c8:      	ldp	q0, q1, [sp, #0x180]
     6cc:      	fdiv.4s	v0, v0, v9
     6d0:      	fdiv.4s	v1, v1, v9
     6d4:      	fmul.4s	v1, v8, v1
     6d8:      	fmul.4s	v0, v30, v0
     6dc:      	fadd.4s	v0, v19, v0
     6e0:      	fadd.4s	v1, v20, v1
     6e4:      	stp	q0, q1, [x10, #0xc0]
     6e8:      	ldp	q1, q0, [sp, #0x1c0]
     6ec:      	fdiv.4s	v0, v0, v9
     6f0:      	fdiv.4s	v1, v1, v9
     6f4:      	fmul.4s	v1, v29, v1
     6f8:      	fmul.4s	v0, v25, v0
     6fc:      	fadd.4s	v0, v21, v0
     700:      	fadd.4s	v1, v22, v1
     704:      	stp	q0, q1, [x10, #0xe0]
     708:      	ldr	q0, [sp, #0x1a0]
     70c:      	fdiv.4s	v0, v0, v31
     710:      	fmul.4s	v0, v26, v0
     714:      	fadd.4s	v0, v24, v0
     718:      	str	s0, [x9, x16]
     71c:      	mov	w17, #0x2               ; =2
     720:      	bfi	w17, w1, #2, #27
     724:      	umull	x10, w17, w26
     728:      	umaddl	x16, w17, w26, x15
     72c:      	ldp	q0, q1, [x16]
     730:      	ldp	q3, q2, [x16, #0x20]
     734:      	ldp	q4, q5, [x16, #0x40]
     738:      	ldp	q7, q6, [x16, #0x60]
     73c:      	ldp	q16, q17, [x16, #0x80]
     740:      	ldp	q27, q26, [x16, #0xa0]
     744:      	ldp	q30, q31, [x16, #0xc0]
     748:      	ldp	q9, q8, [x16, #0xe0]
     74c:      	add	x16, x10, #0x100
     750:      	ldr	s10, [x15, x16]
     754:      	fadd.4s	v18, v7, v9
     758:      	fadd.4s	v19, v6, v8
     75c:      	fadd.4s	v20, v5, v31
     760:      	fadd.4s	v21, v4, v30
     764:      	fadd.4s	v22, v3, v27
     768:      	fadd.4s	v23, v2, v26
     76c:      	fadd.4s	v24, v1, v17
     770:      	fadd.4s	v25, v0, v16
     774:      	fadd.4s	v28, v25, v10
     778:      	mov.s	v25[0], v28[0]
     77c:      	fadd.4s	v23, v23, v24
     780:      	fadd.4s	v22, v22, v25
     784:      	fadd.4s	v21, v21, v22
     788:      	fadd.4s	v20, v20, v23
     78c:      	fadd.4s	v19, v19, v20
     790:      	fadd.4s	v18, v18, v21
     794:      	rev64.4s	v20, v18
     798:      	rev64.4s	v21, v19
     79c:      	fadd.4s	v19, v19, v21
     7a0:      	fadd.4s	v18, v18, v20
     7a4:      	dup.4s	v20, v18[2]
     7a8:      	dup.4s	v21, v19[2]
     7ac:      	fadd.4s	v19, v19, v21
     7b0:      	fadd.4s	v18, v18, v20
     7b4:      	fadd.4s	v18, v18, v19
     7b8:      	movi	d19, #0000000000000000
     7bc:      	fadd	s18, s18, s19
     7c0:      	ldr	s20, [sp, #0x1e0]
     7c4:      	fdiv	s11, s18, s20
     7c8:      	dup.4s	v12, v11[0]
     7cc:      	fsub.4s	v29, v1, v12
     7d0:      	fsub.4s	v28, v0, v12
     7d4:      	fsub.4s	v13, v3, v12
     7d8:      	fsub.4s	v14, v2, v12
     7dc:      	stp	q14, q13, [sp, #0xe0]
     7e0:      	fsub.4s	v25, v5, v12
     7e4:      	fsub.4s	v24, v4, v12
     7e8:      	stp	q25, q24, [sp, #0x120]
     7ec:      	fsub.4s	v22, v7, v12
     7f0:      	fsub.4s	v23, v6, v12
     7f4:      	stp	q23, q22, [sp, #0x140]
     7f8:      	fsub.4s	v18, v17, v12
     7fc:      	fsub.4s	v21, v16, v12
     800:      	stp	q21, q18, [sp, #0x100]
     804:      	fsub.4s	v16, v27, v12
     808:      	fsub.4s	v17, v26, v12
     80c:      	stp	q17, q16, [sp, #0x160]
     810:      	fsub.4s	v4, v31, v12
     814:      	fsub.4s	v5, v30, v12
     818:      	stp	q5, q4, [sp, #0x180]
     81c:      	fsub.4s	v2, v9, v12
     820:      	fsub.4s	v3, v8, v12
     824:      	stp	q3, q2, [sp, #0x1c0]
     828:      	fsub.4s	v1, v10, v11
     82c:      	ldp	q30, q8, [x13]
     830:      	ldp	q0, q27, [x13, #0x20]
     834:      	stp	q1, q0, [sp, #0x1a0]
     838:      	fmul.4s	v0, v28, v28
     83c:      	fmul.4s	v6, v29, v29
     840:      	fmul.4s	v7, v14, v14
     844:      	fmul.4s	v31, v13, v13
     848:      	fmul.4s	v9, v24, v24
     84c:      	fmul.4s	v10, v25, v25
     850:      	fmul.4s	v11, v23, v23
     854:      	fmul.4s	v12, v22, v22
     858:      	fmul.4s	v13, v2, v2
     85c:      	fadd.4s	v14, v12, v13
     860:      	fmul.4s	v12, v3, v3
     864:      	fadd.4s	v15, v11, v12
     868:      	fmul.4s	v11, v4, v4
     86c:      	fadd.4s	v10, v10, v11
     870:      	fmul.4s	v11, v5, v5
     874:      	fadd.4s	v9, v9, v11
     878:      	fmul.4s	v11, v16, v16
     87c:      	fadd.4s	v31, v31, v11
     880:      	fmul.4s	v11, v17, v17
     884:      	fadd.4s	v7, v7, v11
     888:      	fmul.4s	v11, v18, v18
     88c:      	fadd.4s	v6, v6, v11
     890:      	fmul.4s	v11, v21, v21
     894:      	fadd.4s	v0, v0, v11
     898:      	fmul.4s	v11, v1, v1
     89c:      	fadd.4s	v11, v11, v0
     8a0:      	mov.s	v0[0], v11[0]
     8a4:      	fadd.4s	v7, v7, v6
     8a8:      	ldp	q12, q13, [x13, #0x40]
     8ac:      	fadd.4s	v0, v31, v0
     8b0:      	fadd.4s	v0, v9, v0
     8b4:      	ldp	q1, q11, [x13, #0x60]
     8b8:      	str	q1, [sp, #0xd0]
     8bc:      	fadd.4s	v7, v10, v7
     8c0:      	fadd.4s	v7, v15, v7
     8c4:      	fadd.4s	v0, v14, v0
     8c8:      	rev64.4s	v31, v0
     8cc:      	rev64.4s	v9, v7
     8d0:      	fadd.4s	v7, v7, v9
     8d4:      	fadd.4s	v0, v0, v31
     8d8:      	dup.4s	v31, v0[2]
     8dc:      	dup.4s	v9, v7[2]
     8e0:      	fadd.4s	v7, v7, v9
     8e4:      	fadd.4s	v0, v0, v31
     8e8:      	fadd.4s	v0, v0, v7
     8ec:      	fadd	s0, s0, s19
     8f0:      	fdiv	s0, s0, s20
     8f4:      	ldr	s1, [sp, #0x1f0]
     8f8:      	fadd	s0, s0, s1
     8fc:      	fsqrt	s31, s0
     900:      	dup.4s	v9, v31[0]
     904:      	ldp	q14, q15, [x13, #0x80]
     908:      	fdiv.4s	v0, v29, v9
     90c:      	fmul.4s	v0, v8, v0
     910:      	ldp	q29, q7, [x12]
     914:      	fdiv.4s	v28, v28, v9
     918:      	fmul.4s	v28, v30, v28
     91c:      	fadd.4s	v10, v29, v28
     920:      	ldp	q23, q28, [x13, #0xa0]
     924:      	umaddl	x10, w17, w26, x9
     928:      	fadd.4s	v0, v7, v0
     92c:      	ldp	q30, q8, [x13, #0xc0]
     930:      	ldp	q25, q29, [x13, #0xe0]
     934:      	ldr	s26, [x13, #0x100]
     938:      	ldp	q1, q2, [x12, #0x20]
     93c:      	ldp	q3, q4, [x12, #0x40]
     940:      	ldp	q5, q6, [x12, #0x60]
     944:      	ldp	q7, q16, [x12, #0x80]
     948:      	ldp	q17, q18, [x12, #0xa0]
     94c:      	ldp	q19, q20, [x12, #0xc0]
     950:      	ldp	q21, q22, [x12, #0xe0]
     954:      	ldr	s24, [x12, #0x100]
     958:      	stp	q10, q0, [x10]
     95c:      	ldr	q0, [sp, #0xe0]
     960:      	fdiv.4s	v0, v0, v9
     964:      	fmul.4s	v0, v27, v0
     968:      	ldr	q27, [sp, #0xf0]
     96c:      	fdiv.4s	v10, v27, v9
     970:      	ldr	q27, [sp, #0x1b0]
     974:      	fmul.4s	v10, v27, v10
     978:      	fadd.4s	v1, v1, v10
     97c:      	fadd.4s	v0, v2, v0
     980:      	stp	q1, q0, [x10, #0x20]
     984:      	ldp	q0, q1, [sp, #0x120]
     988:      	fdiv.4s	v0, v0, v9
     98c:      	fmul.4s	v0, v13, v0
     990:      	fdiv.4s	v1, v1, v9
     994:      	fmul.4s	v1, v12, v1
     998:      	fadd.4s	v1, v3, v1
     99c:      	fadd.4s	v0, v4, v0
     9a0:      	stp	q1, q0, [x10, #0x40]
     9a4:      	ldp	q0, q1, [sp, #0x140]
     9a8:      	fdiv.4s	v0, v0, v9
     9ac:      	fmul.4s	v0, v11, v0
     9b0:      	fdiv.4s	v1, v1, v9
     9b4:      	ldr	q2, [sp, #0xd0]
     9b8:      	fmul.4s	v1, v2, v1
     9bc:      	fadd.4s	v1, v5, v1
     9c0:      	fadd.4s	v0, v6, v0
     9c4:      	stp	q1, q0, [x10, #0x60]
     9c8:      	ldp	q0, q1, [sp, #0x100]
     9cc:      	fdiv.4s	v0, v0, v9
     9d0:      	fdiv.4s	v1, v1, v9
     9d4:      	fmul.4s	v1, v15, v1
     9d8:      	fmul.4s	v0, v14, v0
     9dc:      	fadd.4s	v0, v7, v0
     9e0:      	fadd.4s	v1, v16, v1
     9e4:      	stp	q0, q1, [x10, #0x80]
     9e8:      	ldp	q1, q0, [sp, #0x160]
     9ec:      	fdiv.4s	v0, v0, v9
     9f0:      	fdiv.4s	v1, v1, v9
     9f4:      	fmul.4s	v1, v28, v1
     9f8:      	fmul.4s	v0, v23, v0
     9fc:      	fadd.4s	v0, v17, v0
     a00:      	fadd.4s	v1, v18, v1
     a04:      	stp	q0, q1, [x10, #0xa0]
     a08:      	ldp	q0, q1, [sp, #0x180]
     a0c:      	fdiv.4s	v0, v0, v9
     a10:      	fdiv.4s	v1, v1, v9
     a14:      	fmul.4s	v1, v8, v1
     a18:      	fmul.4s	v0, v30, v0
     a1c:      	fadd.4s	v0, v19, v0
     a20:      	fadd.4s	v1, v20, v1
     a24:      	stp	q0, q1, [x10, #0xc0]
     a28:      	ldp	q1, q0, [sp, #0x1c0]
     a2c:      	fdiv.4s	v0, v0, v9
     a30:      	fdiv.4s	v1, v1, v9
     a34:      	fmul.4s	v1, v29, v1
     a38:      	fmul.4s	v0, v25, v0
     a3c:      	fadd.4s	v0, v21, v0
     a40:      	fadd.4s	v1, v22, v1
     a44:      	stp	q0, q1, [x10, #0xe0]
     a48:      	ldr	q0, [sp, #0x1a0]
     a4c:      	fdiv.4s	v0, v0, v31
     a50:      	fmul.4s	v0, v26, v0
     a54:      	fadd.4s	v0, v24, v0
     a58:      	str	s0, [x9, x16]
     a5c:      	mov	w17, #0x3               ; =3
     a60:      	bfi	w17, w1, #2, #27
     a64:      	umull	x10, w17, w26
     a68:      	umaddl	x16, w17, w26, x15
     a6c:      	ldp	q0, q1, [x16]
     a70:      	ldp	q3, q2, [x16, #0x20]
     a74:      	ldp	q4, q5, [x16, #0x40]
     a78:      	ldp	q7, q6, [x16, #0x60]
     a7c:      	ldp	q16, q17, [x16, #0x80]
     a80:      	ldp	q27, q26, [x16, #0xa0]
     a84:      	ldp	q30, q31, [x16, #0xc0]
     a88:      	ldp	q9, q8, [x16, #0xe0]
     a8c:      	add	x16, x10, #0x100
     a90:      	ldr	s10, [x15, x16]
     a94:      	fadd.4s	v18, v7, v9
     a98:      	fadd.4s	v19, v6, v8
     a9c:      	fadd.4s	v20, v5, v31
     aa0:      	fadd.4s	v21, v4, v30
     aa4:      	fadd.4s	v22, v3, v27
     aa8:      	fadd.4s	v23, v2, v26
     aac:      	fadd.4s	v24, v1, v17
     ab0:      	fadd.4s	v25, v0, v16
     ab4:      	fadd.4s	v28, v25, v10
     ab8:      	mov.s	v25[0], v28[0]
     abc:      	fadd.4s	v23, v23, v24
     ac0:      	fadd.4s	v22, v22, v25
     ac4:      	fadd.4s	v21, v21, v22
     ac8:      	fadd.4s	v20, v20, v23
     acc:      	fadd.4s	v19, v19, v20
     ad0:      	fadd.4s	v18, v18, v21
     ad4:      	rev64.4s	v20, v18
     ad8:      	rev64.4s	v21, v19
     adc:      	fadd.4s	v19, v19, v21
     ae0:      	fadd.4s	v18, v18, v20
     ae4:      	dup.4s	v20, v18[2]
     ae8:      	dup.4s	v21, v19[2]
     aec:      	fadd.4s	v19, v19, v21
     af0:      	fadd.4s	v18, v18, v20
     af4:      	fadd.4s	v18, v18, v19
     af8:      	movi	d19, #0000000000000000
     afc:      	fadd	s18, s18, s19
     b00:      	ldr	s20, [sp, #0x1e0]
     b04:      	fdiv	s11, s18, s20
     b08:      	dup.4s	v12, v11[0]
     b0c:      	fsub.4s	v29, v1, v12
     b10:      	fsub.4s	v28, v0, v12
     b14:      	fsub.4s	v14, v3, v12
     b18:      	fsub.4s	v15, v2, v12
     b1c:      	stp	q15, q14, [sp, #0xd0]
     b20:      	fsub.4s	v13, v5, v12
     b24:      	fsub.4s	v25, v4, v12
     b28:      	stp	q13, q25, [sp, #0x110]
     b2c:      	fsub.4s	v23, v7, v12
     b30:      	fsub.4s	v24, v6, v12
     b34:      	stp	q24, q23, [sp, #0x130]
     b38:      	fsub.4s	v22, v17, v12
     b3c:      	fsub.4s	v21, v16, v12
     b40:      	stp	q22, q21, [sp, #0xf0]
     b44:      	fsub.4s	v17, v27, v12
     b48:      	fsub.4s	v18, v26, v12
     b4c:      	stp	q18, q17, [sp, #0x150]
     b50:      	fsub.4s	v16, v31, v12
     b54:      	fsub.4s	v5, v30, v12
     b58:      	stp	q16, q5, [sp, #0x170]
     b5c:      	fsub.4s	v3, v9, v12
     b60:      	fsub.4s	v4, v8, v12
     b64:      	stp	q4, q3, [sp, #0x1c0]
     b68:      	fsub.4s	v2, v10, v11
     b6c:      	ldp	q30, q31, [x13]
     b70:      	ldp	q1, q0, [x13, #0x20]
     b74:      	stp	q2, q1, [sp, #0x1a0]
     b78:      	str	q0, [sp, #0x190]
     b7c:      	fmul.4s	v0, v28, v28
     b80:      	fmul.4s	v1, v29, v29
     b84:      	fmul.4s	v6, v15, v15
     b88:      	fmul.4s	v7, v14, v14
     b8c:      	fmul.4s	v8, v25, v25
     b90:      	fmul.4s	v9, v13, v13
     b94:      	fmul.4s	v10, v24, v24
     b98:      	fmul.4s	v11, v23, v23
     b9c:      	fmul.4s	v12, v3, v3
     ba0:      	fadd.4s	v11, v11, v12
     ba4:      	fmul.4s	v12, v4, v4
     ba8:      	fadd.4s	v13, v10, v12
     bac:      	fmul.4s	v10, v16, v16
     bb0:      	fadd.4s	v9, v9, v10
     bb4:      	fmul.4s	v10, v5, v5
     bb8:      	fadd.4s	v8, v8, v10
     bbc:      	fmul.4s	v10, v17, v17
     bc0:      	fadd.4s	v7, v7, v10
     bc4:      	fmul.4s	v10, v18, v18
     bc8:      	fadd.4s	v6, v6, v10
     bcc:      	fmul.4s	v10, v22, v22
     bd0:      	fadd.4s	v1, v1, v10
     bd4:      	fmul.4s	v10, v21, v21
     bd8:      	fadd.4s	v0, v0, v10
     bdc:      	fmul.4s	v10, v2, v2
     be0:      	fadd.4s	v10, v10, v0
     be4:      	mov.s	v0[0], v10[0]
     be8:      	fadd.4s	v1, v6, v1
     bec:      	ldp	q14, q15, [x13, #0x40]
     bf0:      	fadd.4s	v0, v7, v0
     bf4:      	fadd.4s	v0, v8, v0
     bf8:      	ldp	q10, q12, [x13, #0x60]
     bfc:      	fadd.4s	v1, v9, v1
     c00:      	fadd.4s	v1, v13, v1
     c04:      	ldp	q2, q9, [x13, #0x80]
     c08:      	str	q2, [sp, #0xc0]
     c0c:      	fadd.4s	v0, v11, v0
     c10:      	rev64.4s	v6, v1
     c14:      	fadd.4s	v1, v1, v6
     c18:      	rev64.4s	v6, v0
     c1c:      	fadd.4s	v0, v0, v6
     c20:      	dup.4s	v6, v1[2]
     c24:      	fadd.4s	v1, v1, v6
     c28:      	dup.4s	v6, v0[2]
     c2c:      	fadd.4s	v0, v0, v6
     c30:      	fadd.4s	v0, v0, v1
     c34:      	ldp	q11, q13, [x13, #0xa0]
     c38:      	fadd	s0, s0, s19
     c3c:      	fdiv	s0, s0, s20
     c40:      	ldr	s1, [sp, #0x1f0]
     c44:      	fadd	s0, s0, s1
     c48:      	fsqrt	s23, s0
     c4c:      	dup.4s	v7, v23[0]
     c50:      	fdiv.4s	v0, v29, v7
     c54:      	fmul.4s	v0, v31, v0
     c58:      	ldp	q1, q29, [x12]
     c5c:      	fdiv.4s	v28, v28, v7
     c60:      	fmul.4s	v28, v30, v28
     c64:      	fadd.4s	v3, v1, v28
     c68:      	ldp	q27, q31, [x13, #0xc0]
     c6c:      	umaddl	x10, w17, w26, x9
     c70:      	fadd.4s	v0, v29, v0
     c74:      	ldp	q29, q30, [x13, #0xe0]
     c78:      	ldr	s28, [x13, #0x100]
     c7c:      	ldp	q1, q2, [x12, #0x20]
     c80:      	ldp	q4, q5, [x12, #0x40]
     c84:      	ldp	q6, q16, [x12, #0x60]
     c88:      	ldp	q17, q18, [x12, #0x80]
     c8c:      	ldp	q19, q20, [x12, #0xa0]
     c90:      	ldp	q21, q22, [x12, #0xc0]
     c94:      	ldp	q24, q25, [x12, #0xe0]
     c98:      	ldr	s26, [x12, #0x100]
     c9c:      	stp	q3, q0, [x10]
     ca0:      	ldr	q0, [sp, #0xd0]
     ca4:      	fdiv.4s	v0, v0, v7
     ca8:      	ldr	q3, [sp, #0x190]
     cac:      	fmul.4s	v0, v3, v0
     cb0:      	ldr	q3, [sp, #0xe0]
     cb4:      	fdiv.4s	v3, v3, v7
     cb8:      	ldr	q8, [sp, #0x1b0]
     cbc:      	fmul.4s	v3, v8, v3
     cc0:      	fadd.4s	v1, v1, v3
     cc4:      	fadd.4s	v0, v2, v0
     cc8:      	stp	q1, q0, [x10, #0x20]
     ccc:      	ldp	q0, q1, [sp, #0x110]
     cd0:      	fdiv.4s	v0, v0, v7
     cd4:      	fmul.4s	v0, v15, v0
     cd8:      	fdiv.4s	v1, v1, v7
     cdc:      	fmul.4s	v1, v14, v1
     ce0:      	fadd.4s	v1, v4, v1
     ce4:      	fadd.4s	v0, v5, v0
     ce8:      	stp	q1, q0, [x10, #0x40]
     cec:      	ldp	q0, q1, [sp, #0x130]
     cf0:      	fdiv.4s	v0, v0, v7
     cf4:      	fmul.4s	v0, v12, v0
     cf8:      	fdiv.4s	v1, v1, v7
     cfc:      	fmul.4s	v1, v10, v1
     d00:      	fadd.4s	v1, v6, v1
     d04:      	fadd.4s	v0, v16, v0
     d08:      	stp	q1, q0, [x10, #0x60]
     d0c:      	ldp	q0, q1, [sp, #0xf0]
     d10:      	fdiv.4s	v0, v0, v7
     d14:      	fmul.4s	v0, v9, v0
     d18:      	fdiv.4s	v1, v1, v7
     d1c:      	ldr	q2, [sp, #0xc0]
     d20:      	fmul.4s	v1, v2, v1
     d24:      	fadd.4s	v1, v17, v1
     d28:      	fadd.4s	v0, v18, v0
     d2c:      	stp	q1, q0, [x10, #0x80]
     d30:      	ldp	q0, q1, [sp, #0x150]
     d34:      	fdiv.4s	v0, v0, v7
     d38:      	fmul.4s	v0, v13, v0
     d3c:      	fdiv.4s	v1, v1, v7
     d40:      	fmul.4s	v1, v11, v1
     d44:      	fadd.4s	v1, v19, v1
     d48:      	fadd.4s	v0, v20, v0
     d4c:      	stp	q1, q0, [x10, #0xa0]
     d50:      	ldp	q0, q1, [sp, #0x170]
     d54:      	fdiv.4s	v0, v0, v7
     d58:      	fmul.4s	v0, v31, v0
     d5c:      	fdiv.4s	v1, v1, v7
     d60:      	fmul.4s	v1, v27, v1
     d64:      	fadd.4s	v1, v21, v1
     d68:      	fadd.4s	v0, v22, v0
     d6c:      	stp	q1, q0, [x10, #0xc0]
     d70:      	ldp	q1, q0, [sp, #0x1c0]
     d74:      	fdiv.4s	v0, v0, v7
     d78:      	fdiv.4s	v1, v1, v7
     d7c:      	fmul.4s	v1, v30, v1
     d80:      	fmul.4s	v0, v29, v0
     d84:      	fadd.4s	v0, v24, v0
     d88:      	fadd.4s	v1, v25, v1
     d8c:      	stp	q0, q1, [x10, #0xe0]
     d90:      	ldr	q0, [sp, #0x1a0]
     d94:      	fdiv.4s	v0, v0, v23
     d98:      	fmul.4s	v0, v28, v0
     d9c:      	fadd.4s	v0, v26, v0
     da0:      	str	s0, [x9, x16]
     da4:      	mov	w9, #0x18               ; =24
     da8:      	str	w9, [x2, #0x24]
     dac:      	add	w9, w1, #0x1
     db0:      	cmp	w9, w28
     db4:      	cset	w9, eq
     db8:      	csinc	w1, wzr, w1, eq
     dbc:      	cinc	w10, w7, eq
     dc0:      	cmp	w10, w30
     dc4:      	cset	w12, eq
     dc8:      	ands	w9, w9, w12
     dcc:      	csel	w7, wzr, w10, ne
     dd0:      	add	w20, w20, w9
     dd4:      	add	w8, w8, #0x1
     dd8:      	cmp	w8, w3
     ddc:      	b.eq	0x26d8 <ltmp0+0x26d8>
     de0:      	ubfiz	x9, x1, #5, #32
     de4:      	cmp	x9, x21
     de8:      	csel	x10, x9, xzr, ls
     dec:      	subs	x12, x21, x10
     df0:      	cmp	x12, #0x20
     df4:      	csel	x12, x12, x23, lo
     df8:      	cmp	x21, x10
     dfc:      	stp	w1, w7, [x2]
     e00:      	str	w20, [x2, #0x8]
     e04:      	str	wzr, [x2, #0x24]
     e08:      	ccmp	x9, x21, #0x2, hi
     e0c:      	csel	x12, x12, xzr, ls
     e10:      	cmp	x12, #0x20
     e14:      	b.hs	0x78 <ltmp0+0x78>
     e18:      	lsr	x9, x12, #3
     e1c:      	cmp	x12, #0x8
     e20:      	movi	d10, #0000000000000000
     e24:      	b.lo	0x11b8 <ltmp0+0x11b8>
     e28:      	ldr	x10, [x0]
     e2c:      	ldr	x13, [x0, #0x10]
     e30:      	ldr	x15, [x0, #0x20]
     e34:      	ldr	x4, [x0, #0x30]
     e38:      	add	x16, x13, #0x100
     e3c:      	add	x17, x15, #0x100
     e40:      	and	x5, x1, #0x7ffffff
     e44:      	add	x5, x5, x5, lsl #6
     e48:      	lsl	x5, x5, #4
     e4c:      	add	x10, x10, x5
     e50:      	add	x19, x10, #0x80
     e54:      	add	x10, x4, x5
     e58:      	add	x4, x10, #0x80
     e5c:      	mov	x5, x9
     e60:      	ldp	q0, q1, [x19, #-0x80]
     e64:      	ldp	q3, q2, [x19, #-0x60]
     e68:      	ldp	q4, q5, [x19, #-0x40]
     e6c:      	ldp	q7, q6, [x19, #-0x20]
     e70:      	ldp	q16, q17, [x19]
     e74:      	ldp	q25, q24, [x19, #0x20]
     e78:      	ldp	q26, q27, [x19, #0x40]
     e7c:      	ldp	q31, q8, [x19, #0x60]
     e80:      	ldr	s9, [x19, #0x80]
     e84:      	fadd.4s	v18, v7, v31
     e88:      	fadd.4s	v19, v6, v8
     e8c:      	fadd.4s	v20, v5, v27
     e90:      	fadd.4s	v21, v4, v26
     e94:      	fadd.4s	v22, v3, v25
     e98:      	fadd.4s	v23, v2, v24
     e9c:      	fadd.4s	v28, v0, v16
     ea0:      	fadd.4s	v29, v28, v9
     ea4:      	fadd.4s	v30, v1, v17
     ea8:      	mov.s	v28[0], v29[0]
     eac:      	fadd.4s	v23, v23, v30
     eb0:      	fadd.4s	v22, v22, v28
     eb4:      	fadd.4s	v20, v20, v23
     eb8:      	fadd.4s	v21, v21, v22
     ebc:      	fadd.4s	v19, v19, v20
     ec0:      	fadd.4s	v18, v18, v21
     ec4:      	rev64.4s	v20, v18
     ec8:      	rev64.4s	v21, v19
     ecc:      	fadd.4s	v19, v19, v21
     ed0:      	fadd.4s	v18, v18, v20
     ed4:      	dup.4s	v20, v18[2]
     ed8:      	dup.4s	v21, v19[2]
     edc:      	fadd.4s	v19, v19, v21
     ee0:      	fadd.4s	v18, v18, v20
     ee4:      	fadd.4s	v18, v18, v19
     ee8:      	fadd	s18, s18, s10
     eec:      	fmov	s30, w11
     ef0:      	movi	d19, #0000000000000000
     ef4:      	fdiv	s10, s18, s30
     ef8:      	dup.4s	v11, v10[0]
     efc:      	fsub.4s	v29, v1, v11
     f00:      	fsub.4s	v28, v0, v11
     f04:      	fsub.4s	v14, v3, v11
     f08:      	fsub.4s	v3, v2, v11
     f0c:      	fsub.4s	v13, v5, v11
     f10:      	stp	q14, q13, [sp, #0xf0]
     f14:      	fsub.4s	v12, v4, v11
     f18:      	fsub.4s	v22, v7, v11
     f1c:      	fsub.4s	v23, v6, v11
     f20:      	fsub.4s	v20, v17, v11
     f24:      	stp	q20, q12, [sp, #0x110]
     f28:      	fsub.4s	v17, v16, v11
     f2c:      	stp	q17, q22, [sp, #0x130]
     f30:      	fsub.4s	v7, v25, v11
     f34:      	fsub.4s	v16, v24, v11
     f38:      	fsub.4s	v21, v27, v11
     f3c:      	fsub.4s	v18, v26, v11
     f40:      	stp	q18, q16, [sp, #0x150]
     f44:      	fsub.4s	v5, v31, v11
     f48:      	fsub.4s	v4, v9, v10
     f4c:      	fsub.4s	v6, v8, v11
     f50:      	stp	q6, q7, [sp, #0x170]
     f54:      	ldp	q31, q8, [x13]
     f58:      	ldp	q1, q0, [x13, #0x20]
     f5c:      	stp	q21, q1, [sp, #0x1a0]
     f60:      	str	q0, [sp, #0x190]
     f64:      	ldp	q1, q0, [x13, #0x40]
     f68:      	stp	q1, q5, [sp, #0x1e0]
     f6c:      	stp	q0, q4, [sp, #0x1c0]
     f70:      	fmul.4s	v0, v28, v28
     f74:      	fmul.4s	v1, v29, v29
     f78:      	fmul.4s	v2, v3, v3
     f7c:      	mov.16b	v27, v3
     f80:      	fmul.4s	v3, v14, v14
     f84:      	fmul.4s	v9, v12, v12
     f88:      	fmul.4s	v10, v13, v13
     f8c:      	fmul.4s	v11, v22, v22
     f90:      	fmul.4s	v12, v5, v5
     f94:      	fadd.4s	v13, v11, v12
     f98:      	fmul.4s	v11, v21, v21
     f9c:      	fadd.4s	v10, v10, v11
     fa0:      	fmul.4s	v11, v7, v7
     fa4:      	fadd.4s	v3, v3, v11
     fa8:      	fmul.4s	v11, v16, v16
     fac:      	fadd.4s	v2, v2, v11
     fb0:      	fmul.4s	v11, v17, v17
     fb4:      	fadd.4s	v0, v0, v11
     fb8:      	fmul.4s	v11, v20, v20
     fbc:      	fadd.4s	v1, v1, v11
     fc0:      	fmul.4s	v11, v4, v4
     fc4:      	fadd.4s	v11, v11, v0
     fc8:      	mov.s	v0[0], v11[0]
     fcc:      	fmul.4s	v11, v18, v18
     fd0:      	fadd.4s	v9, v9, v11
     fd4:      	ldp	q11, q15, [x13, #0x60]
     fd8:      	fadd.4s	v1, v2, v1
     fdc:      	fmul.4s	v2, v23, v23
     fe0:      	mov.16b	v25, v23
     fe4:      	fadd.4s	v0, v3, v0
     fe8:      	fmul.4s	v3, v6, v6
     fec:      	fadd.4s	v2, v2, v3
     ff0:      	fadd.4s	v0, v9, v0
     ff4:      	fadd.4s	v1, v10, v1
     ff8:      	ldp	q9, q12, [x13, #0x80]
     ffc:      	fadd.4s	v1, v2, v1
    1000:      	fadd.4s	v0, v13, v0
    1004:      	rev64.4s	v2, v0
    1008:      	rev64.4s	v3, v1
    100c:      	fadd.4s	v0, v0, v2
    1010:      	dup.4s	v2, v0[2]
    1014:      	fadd.4s	v1, v1, v3
    1018:      	dup.4s	v3, v1[2]
    101c:      	fadd.4s	v1, v1, v3
    1020:      	fadd.4s	v0, v0, v2
    1024:      	ldp	q13, q14, [x13, #0xa0]
    1028:      	fadd.4s	v0, v0, v1
    102c:      	fadd	s0, s0, s19
    1030:      	fdiv	s0, s0, s30
    1034:      	fmov	s1, w14
    1038:      	fadd	s0, s0, s1
    103c:      	fsqrt	s30, s0
    1040:      	dup.4s	v10, v30[0]
    1044:      	fdiv.4s	v0, v29, v10
    1048:      	fmul.4s	v0, v8, v0
    104c:      	ldp	q1, q2, [x15]
    1050:      	fdiv.4s	v3, v28, v10
    1054:      	fmul.4s	v3, v31, v3
    1058:      	fadd.4s	v3, v1, v3
    105c:      	ldp	q24, q28, [x13, #0xc0]
    1060:      	fadd.4s	v0, v2, v0
    1064:      	ldp	q29, q31, [x13, #0xe0]
    1068:      	ldr	s26, [x16]
    106c:      	ldp	q1, q2, [x15, #0x20]
    1070:      	ldp	q4, q5, [x15, #0x40]
    1074:      	ldp	q6, q7, [x15, #0x60]
    1078:      	ldp	q16, q17, [x15, #0x80]
    107c:      	ldp	q18, q19, [x15, #0xa0]
    1080:      	ldp	q20, q21, [x15, #0xc0]
    1084:      	ldp	q22, q23, [x15, #0xe0]
    1088:      	ldr	s8, [x17]
    108c:      	stp	q3, q0, [x4, #-0x80]
    1090:      	fdiv.4s	v0, v27, v10
    1094:      	ldr	q3, [sp, #0x190]
    1098:      	fmul.4s	v0, v3, v0
    109c:      	ldr	q3, [sp, #0xf0]
    10a0:      	fdiv.4s	v3, v3, v10
    10a4:      	ldr	q27, [sp, #0x1b0]
    10a8:      	fmul.4s	v3, v27, v3
    10ac:      	fadd.4s	v1, v1, v3
    10b0:      	fadd.4s	v0, v2, v0
    10b4:      	stp	q1, q0, [x4, #-0x60]
    10b8:      	ldr	q0, [sp, #0x100]
    10bc:      	fdiv.4s	v0, v0, v10
    10c0:      	ldr	q1, [sp, #0x1c0]
    10c4:      	fmul.4s	v0, v1, v0
    10c8:      	ldr	q1, [sp, #0x120]
    10cc:      	fdiv.4s	v1, v1, v10
    10d0:      	ldr	q2, [sp, #0x1e0]
    10d4:      	fmul.4s	v1, v2, v1
    10d8:      	fadd.4s	v1, v4, v1
    10dc:      	fadd.4s	v0, v5, v0
    10e0:      	fdiv.4s	v2, v25, v10
    10e4:      	fmul.4s	v2, v15, v2
    10e8:      	ldr	q3, [sp, #0x140]
    10ec:      	fdiv.4s	v3, v3, v10
    10f0:      	fmul.4s	v3, v11, v3
    10f4:      	fadd.4s	v3, v6, v3
    10f8:      	stp	q1, q0, [x4, #-0x40]
    10fc:      	fadd.4s	v0, v7, v2
    1100:      	stp	q3, q0, [x4, #-0x20]
    1104:      	ldr	q0, [sp, #0x110]
    1108:      	fdiv.4s	v0, v0, v10
    110c:      	fmul.4s	v0, v12, v0
    1110:      	ldr	q1, [sp, #0x130]
    1114:      	fdiv.4s	v1, v1, v10
    1118:      	fmul.4s	v1, v9, v1
    111c:      	fadd.4s	v1, v16, v1
    1120:      	fadd.4s	v0, v17, v0
    1124:      	stp	q1, q0, [x4]
    1128:      	ldp	q3, q0, [sp, #0x150]
    112c:      	fdiv.4s	v0, v0, v10
    1130:      	fmul.4s	v0, v14, v0
    1134:      	ldr	q1, [sp, #0x180]
    1138:      	fdiv.4s	v1, v1, v10
    113c:      	fmul.4s	v1, v13, v1
    1140:      	fadd.4s	v1, v18, v1
    1144:      	fadd.4s	v0, v19, v0
    1148:      	ldr	q2, [sp, #0x1a0]
    114c:      	fdiv.4s	v2, v2, v10
    1150:      	fmul.4s	v2, v28, v2
    1154:      	fdiv.4s	v3, v3, v10
    1158:      	fmul.4s	v3, v24, v3
    115c:      	fadd.4s	v3, v20, v3
    1160:      	stp	q1, q0, [x4, #0x20]
    1164:      	fadd.4s	v0, v21, v2
    1168:      	ldr	q1, [sp, #0x1f0]
    116c:      	fdiv.4s	v1, v1, v10
    1170:      	ldr	q2, [sp, #0x170]
    1174:      	fdiv.4s	v2, v2, v10
    1178:      	movi	d10, #0000000000000000
    117c:      	fmul.4s	v2, v31, v2
    1180:      	stp	q3, q0, [x4, #0x40]
    1184:      	fmul.4s	v0, v29, v1
    1188:      	fadd.4s	v0, v22, v0
    118c:      	fadd.4s	v1, v23, v2
    1190:      	ldr	q2, [sp, #0x1d0]
    1194:      	fdiv.4s	v2, v2, v30
    1198:      	stp	q0, q1, [x4, #0x60]
    119c:      	fmul.4s	v0, v26, v2
    11a0:      	fadd.4s	v0, v8, v0
    11a4:      	str	s0, [x4, #0x80]
    11a8:      	add	x19, x19, #0x104
    11ac:      	add	x4, x4, #0x104
    11b0:      	subs	x5, x5, #0x1
    11b4:      	b.ne	0xe60 <ltmp0+0xe60>
    11b8:      	and	w10, w12, #0x7
    11bc:      	cbz	w10, 0xda4 <ltmp0+0xda4>
    11c0:      	dup.4s	v0, w10
    11c4:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    11c8:      	ldr	q1, [x10]
    11cc:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    11d0:      	ldr	q2, [x10]
    11d4:      	cmhi.4s	v6, v0, v2
    11d8:      	cmhi.4s	v7, v0, v1
    11dc:      	uzp1.8h	v1, v7, v6
    11e0:      	umaxv.8h	h0, v1
    11e4:      	fmov	w10, s0
    11e8:      	tbz	w10, #0x0, 0xda4 <ltmp0+0xda4>
    11ec:      	mov	x13, #0x0               ; =0
    11f0:      	ldr	x12, [x0]
    11f4:      	ldr	x23, [x0, #0x10]
    11f8:      	ldr	x17, [x0, #0x20]
    11fc:      	ldr	x10, [x0, #0x30]
    1200:      	str	x10, [sp, #0x1d0]
    1204:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    1208:      	ldr	q0, [x10]
    120c:      	and.16b	v0, v1, v0
    1210:      	addv.8h	h16, v0
    1214:      	ubfiz	w10, w1, #2, #27
    1218:      	orr	w9, w10, w9
    121c:      	fmov	w10, s16
    1220:      	and	w10, w10, #0xff
    1224:      	str	w10, [sp, #0x120]
    1228:      	dup.4s	v0, w9
    122c:      	and.16b	v2, v7, v0
    1230:      	and.16b	v0, v6, v0
    1234:      	ushll2.2d	v3, v0, #0x0
    1238:      	ushll2.2d	v4, v2, #0x0
    123c:      	ushll.2d	v5, v0, #0x0
    1240:      	ushll.2d	v19, v2, #0x0
    1244:      	fmov	x9, d19
    1248:      	umaddl	x9, w9, w26, x12
    124c:      	b	0x1270 <ltmp0+0x1270>
    1250:      	add	x10, x6, x13
    1254:      	ldp	q0, q18, [x10]
    1258:      	bif.16b	v17, v18, v6
    125c:      	bit.16b	v0, v2, v7
    1260:      	stp	q0, q17, [x10]
    1264:      	add	x13, x13, #0x20
    1268:      	cmp	x13, #0x100
    126c:      	b.eq	0x1308 <ltmp0+0x1308>
    1270:      	fmov	w15, s16
    1274:      	add	x10, x9, x13
    1278:      	movi.2d	v2, #0000000000000000
    127c:      	movi.2d	v17, #0000000000000000
    1280:      	tbnz	w15, #0x0, 0x12a8 <ltmp0+0x12a8>
    1284:      	and	w15, w15, #0xff
    1288:      	tbnz	w15, #0x1, 0x12b4 <ltmp0+0x12b4>
    128c:      	tbnz	w15, #0x2, 0x12c0 <ltmp0+0x12c0>
    1290:      	tbnz	w15, #0x3, 0x12cc <ltmp0+0x12cc>
    1294:      	tbnz	w15, #0x4, 0x12d8 <ltmp0+0x12d8>
    1298:      	tbnz	w15, #0x5, 0x12e4 <ltmp0+0x12e4>
    129c:      	tbnz	w15, #0x6, 0x12f0 <ltmp0+0x12f0>
    12a0:      	tbz	w15, #0x7, 0x1250 <ltmp0+0x1250>
    12a4:      	b	0x12fc <ltmp0+0x12fc>
    12a8:      	ldr	s2, [x10]
    12ac:      	and	w15, w15, #0xff
    12b0:      	tbz	w15, #0x1, 0x128c <ltmp0+0x128c>
    12b4:      	add	x16, x10, #0x4
    12b8:      	ld1.s	{ v2 }[1], [x16]
    12bc:      	tbz	w15, #0x2, 0x1290 <ltmp0+0x1290>
    12c0:      	add	x16, x10, #0x8
    12c4:      	ld1.s	{ v2 }[2], [x16]
    12c8:      	tbz	w15, #0x3, 0x1294 <ltmp0+0x1294>
    12cc:      	add	x16, x10, #0xc
    12d0:      	ld1.s	{ v2 }[3], [x16]
    12d4:      	tbz	w15, #0x4, 0x1298 <ltmp0+0x1298>
    12d8:      	add	x16, x10, #0x10
    12dc:      	ld1.s	{ v17 }[0], [x16]
    12e0:      	tbz	w15, #0x5, 0x129c <ltmp0+0x129c>
    12e4:      	add	x16, x10, #0x14
    12e8:      	ld1.s	{ v17 }[1], [x16]
    12ec:      	tbz	w15, #0x6, 0x12a0 <ltmp0+0x12a0>
    12f0:      	add	x16, x10, #0x18
    12f4:      	ld1.s	{ v17 }[2], [x16]
    12f8:      	tbz	w15, #0x7, 0x1250 <ltmp0+0x1250>
    12fc:      	add	x10, x10, #0x1c
    1300:      	ld1.s	{ v17 }[3], [x10]
    1304:      	b	0x1250 <ltmp0+0x1250>
    1308:      	str	q1, [sp, #0x150]
    130c:      	xtn.4h	v0, v7
    1310:      	uzp1.8b	v0, v0, v0
    1314:      	sshll.2d	v17, v7, #0x0
    1318:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    131c:      	ldr	q2, [x9]
    1320:      	and.16b	v2, v17, v2
    1324:      	movi.2d	v18, #0000000000000000
    1328:      	mov.b	v18[0], v0[0]
    132c:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    1330:      	ldr	d1, [x9]
    1334:      	str	d1, [sp, #0xb8]
    1338:      	and.8b	v20, v18, v1
    133c:      	addv.8b	b20, v20
    1340:      	fmov	w9, s20
    1344:      	umaxv.8b	b20, v18
    1348:      	fmov	w13, s20
    134c:      	rbit	w10, w9
    1350:      	clz	w10, w10
    1354:      	tst	w13, #0x1
    1358:      	csel	w15, w10, wzr, ne
    135c:      	mov	w10, #0x40              ; =64
    1360:      	dup.2d	v20, x10
    1364:      	str	q2, [sp, #0x140]
    1368:      	orr.16b	v2, v2, v20
    136c:      	xtn.2s	v19, v19
    1370:      	str	q2, [sp, #0x90]
    1374:      	movi.2s	v1, #0x41
    1378:      	umlal.2d	v2, v19, v1
    137c:      	movi.2d	v21, #0000000000000000
    1380:      	mov.b	v21[0], v0[0]
    1384:      	ushll.2d	v0, v21, #0x0
    1388:      	shl.2d	v0, v0, #0x3f
    138c:      	cmlt.2d	v0, v0, #0
    1390:      	str	q2, [sp, #0x1b0]
    1394:      	and.16b	v0, v0, v2
    1398:      	movi.2d	v1, #0000000000000000
    139c:      	str	q1, [sp, #0x6c0]
    13a0:      	str	q1, [sp, #0x6b0]
    13a4:      	str	q1, [sp, #0x6a0]
    13a8:      	str	q0, [sp, #0x690]
    13ac:      	and	x10, x15, #0x7
    13b0:      	add	x16, sp, #0x690
    13b4:      	ldr	x10, [x16, x10, lsl #3]
    13b8:      	str	x15, [sp, #0x1f0]
    13bc:      	sub	x10, x10, x15
    13c0:      	add	x10, x12, x10, lsl #2
    13c4:      	movi.2d	v24, #0000000000000000
    13c8:      	movi.2d	v27, #0000000000000000
    13cc:      	tbnz	w13, #0x0, 0x2558 <ltmp0+0x2558>
    13d0:      	tbnz	w9, #0x1, 0x2560 <ltmp0+0x2560>
    13d4:      	tbnz	w9, #0x2, 0x256c <ltmp0+0x256c>
    13d8:      	tbnz	w9, #0x3, 0x2578 <ltmp0+0x2578>
    13dc:      	tbnz	w9, #0x4, 0x2584 <ltmp0+0x2584>
    13e0:      	tbnz	w9, #0x5, 0x2590 <ltmp0+0x2590>
    13e4:      	tbnz	w9, #0x6, 0x259c <ltmp0+0x259c>
    13e8:      	str	q16, [sp, #0x1c0]
    13ec:      	tbz	w9, #0x7, 0x13f8 <ltmp0+0x13f8>
    13f0:      	add	x10, x10, #0x1c
    13f4:      	ld1.s	{ v27 }[3], [x10]
    13f8:      	sshll.2d	v0, v6, #0x0
    13fc:      	sshll2.2d	v10, v7, #0x0
    1400:      	sshll2.2d	v11, v6, #0x0
    1404:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    1408:      	ldr	q21, [x10]
    140c:      	and.16b	v1, v11, v21
    1410:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    1414:      	ldr	q21, [x10]
    1418:      	and.16b	v2, v10, v21
    141c:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    1420:      	ldr	q21, [x10]
    1424:      	and.16b	v16, v0, v21
    1428:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    142c:      	ldr	q21, [x10]
    1430:      	and.16b	v21, v11, v21
    1434:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    1438:      	ldr	q25, [x10]
    143c:      	and.16b	v25, v10, v25
    1440:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    1444:      	ldr	q26, [x10]
    1448:      	and.16b	v0, v0, v26
    144c:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    1450:      	ldr	q26, [x10]
    1454:      	and.16b	v17, v17, v26
    1458:      	stp	q16, q2, [sp, #0x100]
    145c:      	orr.16b	v22, v16, v20
    1460:      	orr.16b	v23, v2, v20
    1464:      	str	q1, [sp, #0x130]
    1468:      	orr.16b	v16, v1, v20
    146c:      	movi.2s	v1, #0x41
    1470:      	umull.2d	v2, v19, v1
    1474:      	str	q2, [sp, #0x170]
    1478:      	xtn.2s	v4, v4
    147c:      	xtn.2s	v5, v5
    1480:      	xtn.2s	v3, v3
    1484:      	stp	q22, q16, [sp, #0x70]
    1488:      	mov.16b	v2, v16
    148c:      	umlal.2d	v2, v3, v1
    1490:      	str	q2, [sp, #0x1a0]
    1494:      	str	q23, [sp, #0x60]
    1498:      	mov.16b	v2, v23
    149c:      	umlal.2d	v2, v4, v1
    14a0:      	str	q2, [sp, #0x190]
    14a4:      	mov.16b	v2, v22
    14a8:      	umlal.2d	v2, v5, v1
    14ac:      	str	q2, [sp, #0x180]
    14b0:      	sshll.2d	v3, v7, #0x0
    14b4:      	sshll.2d	v4, v6, #0x0
    14b8:      	str	q17, [sp, #0x650]
    14bc:      	str	q25, [sp, #0x660]
    14c0:      	str	q0, [sp, #0x670]
    14c4:      	str	q21, [sp, #0x680]
    14c8:      	ldr	x13, [sp, #0x1f0]
    14cc:      	and	x10, x13, #0x7
    14d0:      	add	x12, sp, #0x650
    14d4:      	ldr	x10, [x12, x10, lsl #3]
    14d8:      	orr	x10, x10, #0x100
    14dc:      	sub	x10, x10, x13, lsl #2
    14e0:      	tst	w9, #0xff
    14e4:      	csel	x9, xzr, x10, eq
    14e8:      	str	x9, [sp, #0x160]
    14ec:      	add	x9, x6, x9
    14f0:      	ldp	q0, q5, [x9]
    14f4:      	zip2.8b	v19, v18, v0
    14f8:      	ushll.4s	v19, v19, #0x0
    14fc:      	shl.4s	v19, v19, #0x1f
    1500:      	cmlt.4s	v19, v19, #0
    1504:      	stp	q27, q24, [sp, #0x30]
    1508:      	bit.16b	v5, v27, v19
    150c:      	str	q18, [sp, #0x1e0]
    1510:      	zip1.8b	v19, v18, v0
    1514:      	ushll.4s	v19, v19, #0x0
    1518:      	shl.4s	v19, v19, #0x1f
    151c:      	cmlt.4s	v19, v19, #0
    1520:      	bit.16b	v0, v24, v19
    1524:      	stp	q0, q5, [x9]
    1528:      	fmov	x9, d17
    152c:      	dup.2d	v0, x22
    1530:      	and.16b	v30, v11, v0
    1534:      	and.16b	v20, v10, v0
    1538:      	and.16b	v21, v4, v0
    153c:      	and.16b	v17, v3, v0
    1540:      	fmov	x19, d17
    1544:      	ldr	q0, [sp, #0xaa0]
    1548:      	ldr	q3, [sp, #0xab0]
    154c:      	and.16b	v4, v6, v3
    1550:      	and.16b	v3, v7, v0
    1554:      	ldr	q0, [sp, #0xa80]
    1558:      	ldr	q5, [sp, #0xa90]
    155c:      	and.16b	v25, v6, v5
    1560:      	and.16b	v5, v7, v0
    1564:      	ldr	q0, [sp, #0xa60]
    1568:      	ldr	q19, [sp, #0xa70]
    156c:      	and.16b	v26, v6, v19
    1570:      	and.16b	v31, v7, v0
    1574:      	str	x9, [sp, #0x28]
    1578:      	add	x10, x6, x9
    157c:      	ldp	q0, q19, [x10]
    1580:      	and.16b	v9, v6, v19
    1584:      	mov	x10, x19
    1588:      	and.16b	v14, v7, v0
    158c:      	mov.16b	v0, v17
    1590:      	mov.16b	v27, v20
    1594:      	mov.16b	v15, v21
    1598:      	mov.16b	v19, v30
    159c:      	sshll.2d	v29, v7, #0x0
    15a0:      	sshll.2d	v2, v6, #0x0
    15a4:      	add	x10, x6, x10, lsl #5
    15a8:      	ldp	q8, q28, [x10]
    15ac:      	fadd.4s	v8, v14, v8
    15b0:      	fadd.4s	v28, v9, v28
    15b4:      	ldp	q12, q1, [x10, #0x20]
    15b8:      	fadd.4s	v12, v31, v12
    15bc:      	fadd.4s	v1, v26, v1
    15c0:      	ldp	q22, q13, [x10, #0x40]
    15c4:      	fadd.4s	v22, v5, v22
    15c8:      	fadd.4s	v13, v25, v13
    15cc:      	ldp	q24, q23, [x10, #0x60]
    15d0:      	fadd.4s	v24, v3, v24
    15d4:      	fadd.4s	v23, v4, v23
    15d8:      	dup.2d	v18, x22
    15dc:      	and.16b	v16, v11, v18
    15e0:      	add.2d	v19, v19, v16
    15e4:      	and.16b	v16, v10, v18
    15e8:      	add.2d	v27, v27, v16
    15ec:      	and.16b	v2, v2, v18
    15f0:      	add.2d	v15, v15, v2
    15f4:      	and.16b	v2, v29, v18
    15f8:      	add.2d	v0, v0, v2
    15fc:      	bit.16b	v9, v28, v6
    1600:      	bit.16b	v14, v8, v7
    1604:      	bit.16b	v26, v1, v6
    1608:      	bit.16b	v31, v12, v7
    160c:      	bit.16b	v25, v13, v6
    1610:      	bit.16b	v5, v22, v7
    1614:      	bit.16b	v4, v23, v6
    1618:      	bit.16b	v3, v24, v7
    161c:      	fmov	x10, d0
    1620:      	cmp	x10, #0x8
    1624:      	b.lt	0x159c <ltmp0+0x159c>
    1628:      	mov	x3, #0x0                ; =0
    162c:      	ldr	q0, [sp, #0x150]
    1630:      	xtn.8b	v29, v0
    1634:      	ldr	q12, [sp, #0x30]
    1638:      	fadd.4s	v0, v12, v9
    163c:      	ldr	q9, [sp, #0x40]
    1640:      	fadd.4s	v1, v9, v14
    1644:      	ldr	q27, [sp, #0x1e0]
    1648:      	zip2.8b	v2, v27, v0
    164c:      	ushll.4s	v2, v2, #0x0
    1650:      	shl.4s	v2, v2, #0x1f
    1654:      	cmlt.4s	v2, v2, #0
    1658:      	and.16b	v0, v2, v0
    165c:      	zip2.8b	v2, v29, v0
    1660:      	ushll.4s	v2, v2, #0x0
    1664:      	shl.4s	v2, v2, #0x1f
    1668:      	cmlt.4s	v2, v2, #0
    166c:      	bit.16b	v0, v28, v2
    1670:      	zip1.8b	v2, v27, v0
    1674:      	ushll.4s	v2, v2, #0x0
    1678:      	shl.4s	v2, v2, #0x1f
    167c:      	cmlt.4s	v2, v2, #0
    1680:      	movi.2d	v16, #0000000000000000
    1684:      	mov.b	v16[2], v29[1]
    1688:      	mov.b	v16[4], v29[2]
    168c:      	and.16b	v1, v2, v1
    1690:      	mov.b	v16[6], v29[3]
    1694:      	ushll.4s	v2, v16, #0x0
    1698:      	shl.4s	v2, v2, #0x1f
    169c:      	cmlt.4s	v2, v2, #0
    16a0:      	bit.16b	v1, v8, v2
    16a4:      	fadd.4s	v1, v31, v1
    16a8:      	fadd.4s	v0, v26, v0
    16ac:      	fadd.4s	v0, v25, v0
    16b0:      	fadd.4s	v1, v5, v1
    16b4:      	fadd.4s	v3, v3, v1
    16b8:      	fadd.4s	v4, v4, v0
    16bc:      	ldp	q0, q2, [sp, #0x130]
    16c0:      	ldr	q1, [sp, #0x110]
    16c4:      	uzp1.4s	v1, v2, v1
    16c8:      	ldr	q2, [sp, #0x100]
    16cc:      	uzp1.4s	v2, v2, v0
    16d0:      	movi.4s	v5, #0x1
    16d4:      	eor.16b	v0, v1, v5
    16d8:      	mov.s	w12, v0[1]
    16dc:      	eor.16b	v24, v2, v5
    16e0:      	mov.s	w13, v0[2]
    16e4:      	mov.s	w16, v0[3]
    16e8:      	fmov	w10, s0
    16ec:      	add	x4, sp, #0x4e8
    16f0:      	bfxil	x4, x10, #0, #3
    16f4:      	str	d29, [sp, #0x4e8]
    16f8:      	ldrb	w4, [x4]
    16fc:      	umov.b	w26, v29[0]
    1700:      	and	x10, x10, #0x7
    1704:      	str	q4, [sp, #0x5c0]
    1708:      	str	q3, [sp, #0x5b0]
    170c:      	add	x5, sp, #0x5b0
    1710:      	ldr	s0, [x5, x10, lsl #2]
    1714:      	ands	w10, w26, #0x1
    1718:      	tst	w10, w4
    171c:      	movi	d26, #0000000000000000
    1720:      	fcsel	s5, s0, s26, ne
    1724:      	and	x4, x12, #0x7
    1728:      	add	x5, sp, #0x4e8
    172c:      	bfxil	x5, x12, #0, #3
    1730:      	ldrb	w12, [x5]
    1734:      	umov.b	w0, v29[1]
    1738:      	str	q4, [sp, #0x5a0]
    173c:      	str	q3, [sp, #0x590]
    1740:      	add	x5, sp, #0x590
    1744:      	ldr	s0, [x5, x4, lsl #2]
    1748:      	and	w12, w0, w12
    174c:      	tst	w12, #0x1
    1750:      	fcsel	s22, s0, s26, ne
    1754:      	and	x12, x13, #0x7
    1758:      	add	x4, sp, #0x4e8
    175c:      	bfxil	x4, x13, #0, #3
    1760:      	ldrb	w13, [x4]
    1764:      	umov.b	w15, v29[2]
    1768:      	and	w13, w15, w13
    176c:      	str	q4, [sp, #0x580]
    1770:      	str	q3, [sp, #0x570]
    1774:      	add	x4, sp, #0x570
    1778:      	ldr	s0, [x4, x12, lsl #2]
    177c:      	tst	w13, #0x1
    1780:      	fcsel	s23, s0, s26, ne
    1784:      	and	x12, x16, #0x7
    1788:      	add	x13, sp, #0x4e8
    178c:      	bfxil	x13, x16, #0, #3
    1790:      	ldrb	w13, [x13]
    1794:      	umov.b	w9, v29[3]
    1798:      	and	w13, w9, w13
    179c:      	str	q4, [sp, #0x560]
    17a0:      	str	q3, [sp, #0x550]
    17a4:      	add	x16, sp, #0x550
    17a8:      	ldr	s0, [x16, x12, lsl #2]
    17ac:      	tst	w13, #0x1
    17b0:      	mov.s	w12, v24[1]
    17b4:      	fcsel	s25, s0, s26, ne
    17b8:      	mov.s	w30, v24[2]
    17bc:      	mov.s	w28, v24[3]
    17c0:      	fmov	w13, s24
    17c4:      	and	x16, x13, #0x7
    17c8:      	add	x4, sp, #0x4e8
    17cc:      	bfxil	x4, x13, #0, #3
    17d0:      	ldrb	w4, [x4]
    17d4:      	umov.b	w13, v29[4]
    17d8:      	and	w4, w13, w4
    17dc:      	str	q4, [sp, #0x640]
    17e0:      	str	q3, [sp, #0x630]
    17e4:      	add	x5, sp, #0x630
    17e8:      	ldr	s0, [x5, x16, lsl #2]
    17ec:      	tst	w4, #0x1
    17f0:      	fcsel	s0, s0, s26, ne
    17f4:      	and	x4, x12, #0x7
    17f8:      	add	x5, sp, #0x4e8
    17fc:      	bfxil	x5, x12, #0, #3
    1800:      	umov.b	w16, v29[5]
    1804:      	ldrb	w12, [x5]
    1808:      	and	w12, w16, w12
    180c:      	str	q4, [sp, #0x620]
    1810:      	str	q3, [sp, #0x610]
    1814:      	add	x5, sp, #0x610
    1818:      	ldr	s16, [x5, x4, lsl #2]
    181c:      	tst	w12, #0x1
    1820:      	fcsel	s16, s16, s26, ne
    1824:      	and	x12, x30, #0x7
    1828:      	add	x4, sp, #0x4e8
    182c:      	bfxil	x4, x30, #0, #3
    1830:      	ldrb	w4, [x4]
    1834:      	umov.b	w30, v29[6]
    1838:      	str	q4, [sp, #0x600]
    183c:      	str	q3, [sp, #0x5f0]
    1840:      	add	x5, sp, #0x5f0
    1844:      	ldr	s18, [x5, x12, lsl #2]
    1848:      	and	w12, w30, w4
    184c:      	tst	w12, #0x1
    1850:      	fcsel	s18, s18, s26, ne
    1854:      	and	x4, x28, #0x7
    1858:      	add	x12, sp, #0x4e8
    185c:      	bfxil	x12, x28, #0, #3
    1860:      	ldrb	w5, [x12]
    1864:      	umov.b	w12, v29[7]
    1868:      	and	w5, w12, w5
    186c:      	str	q4, [sp, #0x5e0]
    1870:      	str	q3, [sp, #0x5d0]
    1874:      	add	x28, sp, #0x5d0
    1878:      	ldr	s19, [x28, x4, lsl #2]
    187c:      	tst	w5, #0x1
    1880:      	fcsel	s19, s19, s26, ne
    1884:      	mov.s	v0[1], v16[0]
    1888:      	mov.s	v0[2], v18[0]
    188c:      	mov.s	v0[3], v19[0]
    1890:      	mov.s	v5[1], v22[0]
    1894:      	mov.s	v5[2], v23[0]
    1898:      	mov.s	v5[3], v25[0]
    189c:      	fadd.4s	v3, v3, v5
    18a0:      	fadd.4s	v0, v4, v0
    18a4:      	movi.4s	v4, #0x2
    18a8:      	eor.16b	v2, v2, v4
    18ac:      	eor.16b	v1, v1, v4
    18b0:      	fmov	w4, s1
    18b4:      	add	x5, sp, #0x4e8
    18b8:      	bfxil	x5, x4, #0, #3
    18bc:      	ldrb	w5, [x5]
    18c0:      	and	x4, x4, #0x7
    18c4:      	str	q0, [sp, #0x540]
    18c8:      	str	q3, [sp, #0x530]
    18cc:      	add	x28, sp, #0x530
    18d0:      	ldr	s1, [x28, x4, lsl #2]
    18d4:      	tst	w10, w5
    18d8:      	fcsel	s1, s1, s26, ne
    18dc:      	fmov	w10, s2
    18e0:      	and	x4, x10, #0x7
    18e4:      	add	x5, sp, #0x4e8
    18e8:      	bfxil	x5, x10, #0, #3
    18ec:      	ldrb	w10, [x5]
    18f0:      	and	w10, w13, w10
    18f4:      	str	q0, [sp, #0x520]
    18f8:      	str	q3, [sp, #0x510]
    18fc:      	add	x5, sp, #0x510
    1900:      	ldr	s2, [x5, x4, lsl #2]
    1904:      	tst	w10, #0x1
    1908:      	fcsel	s2, s2, s26, ne
    190c:      	fadd.4s	v0, v0, v2
    1910:      	and	w10, w26, w13
    1914:      	tst	w10, #0x1
    1918:      	fcsel	s0, s0, s26, ne
    191c:      	ands	w4, w26, #0x1
    1920:      	str	w4, [sp, #0xb4]
    1924:      	fadd.4s	v1, v3, v1
    1928:      	fadd	s0, s1, s0
    192c:      	fcsel	s1, s0, s26, ne
    1930:      	str	w10, [sp, #0x110]
    1934:      	tst	w10, #0x1
    1938:      	str	w0, [sp, #0x130]
    193c:      	and	w10, w0, w26
    1940:      	fcsel	s2, s0, s26, ne
    1944:      	str	w10, [sp, #0x100]
    1948:      	tst	w10, #0x1
    194c:      	str	w15, [sp, #0x150]
    1950:      	and	w10, w15, w26
    1954:      	fcsel	s3, s0, s26, ne
    1958:      	str	w10, [sp, #0xf0]
    195c:      	tst	w10, #0x1
    1960:      	str	w9, [sp, #0x140]
    1964:      	and	w9, w9, w26
    1968:      	fcsel	s4, s0, s26, ne
    196c:      	str	w9, [sp, #0xe0]
    1970:      	tst	w9, #0x1
    1974:      	fcsel	s5, s0, s26, ne
    1978:      	and	w9, w16, w26
    197c:      	str	w9, [sp, #0xd0]
    1980:      	tst	w9, #0x1
    1984:      	fcsel	s16, s0, s26, ne
    1988:      	and	w9, w30, w26
    198c:      	str	w9, [sp, #0xb0]
    1990:      	tst	w9, #0x1
    1994:      	fcsel	s18, s0, s26, ne
    1998:      	and	w9, w12, w26
    199c:      	str	w9, [sp, #0xac]
    19a0:      	tst	w9, #0x1
    19a4:      	fcsel	s0, s0, s26, ne
    19a8:      	mov.s	v1[1], v3[0]
    19ac:      	mov.s	v1[2], v4[0]
    19b0:      	mov.s	v1[3], v5[0]
    19b4:      	mov.s	v2[1], v16[0]
    19b8:      	mov.s	v2[2], v18[0]
    19bc:      	mov.s	v2[3], v0[0]
    19c0:      	ldr	w9, [sp, #0x120]
    19c4:      	rbit	w10, w9
    19c8:      	clz	w9, w10
    19cc:      	str	q2, [sp, #0x500]
    19d0:      	str	q1, [sp, #0x4f0]
    19d4:      	str	x9, [sp, #0xc0]
    19d8:      	and	x10, x9, #0x7
    19dc:      	add	x4, sp, #0x4f0
    19e0:      	ldr	s0, [x4, x10, lsl #2]
    19e4:      	str	q29, [sp, #0x120]
    19e8:      	mov.b	v29[0], wzr
    19ec:      	str	q29, [sp, #0x50]
    19f0:      	fadd	s0, s0, s26
    19f4:      	fmov	s1, w11
    19f8:      	fdiv	s0, s0, s1
    19fc:      	dup.4s	v0, v0[0]
    1a00:      	mov	w10, #0x1               ; =1
    1a04:      	dup.2d	v1, x10
    1a08:      	ushll2.2d	v2, v6, #0x0
    1a0c:      	and.16b	v23, v2, v1
    1a10:      	ushll2.2d	v2, v7, #0x0
    1a14:      	and.16b	v24, v2, v1
    1a18:      	ushll.2d	v2, v6, #0x0
    1a1c:      	and.16b	v25, v2, v1
    1a20:      	ushll.2d	v2, v7, #0x0
    1a24:      	and.16b	v26, v2, v1
    1a28:      	movi.2d	v1, #0000000000000000
    1a2c:      	movi.2d	v2, #0000000000000000
    1a30:      	movi.2d	v3, #0000000000000000
    1a34:      	movi.2d	v4, #0000000000000000
    1a38:      	lsl	x10, x3, #5
    1a3c:      	add	x3, x6, x10
    1a40:      	ldp	q16, q5, [x3]
    1a44:      	fsub.4s	v16, v16, v0
    1a48:      	fsub.4s	v5, v5, v0
    1a4c:      	add	x10, x24, x10
    1a50:      	ldp	q18, q19, [x10]
    1a54:      	bif.16b	v5, v19, v6
    1a58:      	bif.16b	v16, v18, v7
    1a5c:      	stp	q16, q5, [x10]
    1a60:      	add.2d	v2, v2, v24
    1a64:      	add.2d	v3, v3, v25
    1a68:      	add.2d	v4, v4, v23
    1a6c:      	add.2d	v1, v1, v26
    1a70:      	fmov	x3, d1
    1a74:      	cmp	x3, #0x8
    1a78:      	b.lt	0x1a38 <ltmp0+0x1a38>
    1a7c:      	fsub.4s	v3, v9, v0
    1a80:      	fsub.4s	v4, v12, v0
    1a84:      	ldr	x5, [sp, #0x160]
    1a88:      	add	x10, x24, x5
    1a8c:      	ldp	q0, q1, [x10]
    1a90:      	zip2.8b	v2, v27, v0
    1a94:      	ushll.4s	v2, v2, #0x0
    1a98:      	shl.4s	v2, v2, #0x1f
    1a9c:      	cmlt.4s	v2, v2, #0
    1aa0:      	stp	q4, q3, [sp, #0x30]
    1aa4:      	bit.16b	v1, v4, v2
    1aa8:      	zip1.8b	v2, v27, v0
    1aac:      	ushll.4s	v2, v2, #0x0
    1ab0:      	shl.4s	v2, v2, #0x1f
    1ab4:      	cmlt.4s	v2, v2, #0
    1ab8:      	bit.16b	v0, v3, v2
    1abc:      	stp	q0, q1, [x10]
    1ac0:      	ldr	q0, [sp, #0x990]
    1ac4:      	ldr	q1, [sp, #0x980]
    1ac8:      	fmul.4s	v1, v1, v1
    1acc:      	fmul.4s	v0, v0, v0
    1ad0:      	and.16b	v12, v6, v0
    1ad4:      	and.16b	v13, v7, v1
    1ad8:      	ldr	q0, [sp, #0x970]
    1adc:      	ldr	q1, [sp, #0x960]
    1ae0:      	fmul.4s	v1, v1, v1
    1ae4:      	fmul.4s	v0, v0, v0
    1ae8:      	and.16b	v3, v6, v0
    1aec:      	and.16b	v5, v7, v1
    1af0:      	ldr	q0, [sp, #0x950]
    1af4:      	ldr	q1, [sp, #0x940]
    1af8:      	fmul.4s	v1, v1, v1
    1afc:      	fmul.4s	v0, v0, v0
    1b00:      	and.16b	v4, v6, v0
    1b04:      	and.16b	v1, v7, v1
    1b08:      	ldr	x9, [sp, #0x28]
    1b0c:      	add	x9, x24, x9
    1b10:      	ldp	q2, q0, [x9]
    1b14:      	fmul.4s	v2, v2, v2
    1b18:      	fmul.4s	v0, v0, v0
    1b1c:      	and.16b	v22, v6, v0
    1b20:      	and.16b	v2, v7, v2
    1b24:      	sshll.2d	v0, v7, #0x0
    1b28:      	sshll.2d	v16, v6, #0x0
    1b2c:      	add	x9, x24, x19, lsl #5
    1b30:      	ldp	q19, q18, [x9]
    1b34:      	and.16b	v19, v7, v19
    1b38:      	and.16b	v18, v6, v18
    1b3c:      	fmul.4s	v18, v18, v18
    1b40:      	fmul.4s	v19, v19, v19
    1b44:      	fadd.4s	v31, v2, v19
    1b48:      	fadd.4s	v8, v22, v18
    1b4c:      	ldp	q19, q18, [x9, #0x20]
    1b50:      	and.16b	v19, v7, v19
    1b54:      	and.16b	v18, v6, v18
    1b58:      	fmul.4s	v18, v18, v18
    1b5c:      	fmul.4s	v19, v19, v19
    1b60:      	fadd.4s	v19, v1, v19
    1b64:      	fadd.4s	v18, v4, v18
    1b68:      	ldp	q29, q28, [x9, #0x40]
    1b6c:      	and.16b	v29, v7, v29
    1b70:      	and.16b	v28, v6, v28
    1b74:      	fmul.4s	v28, v28, v28
    1b78:      	fmul.4s	v29, v29, v29
    1b7c:      	fadd.4s	v29, v5, v29
    1b80:      	fadd.4s	v28, v3, v28
    1b84:      	ldp	q15, q14, [x9, #0x60]
    1b88:      	and.16b	v15, v7, v15
    1b8c:      	and.16b	v14, v6, v14
    1b90:      	fmul.4s	v14, v14, v14
    1b94:      	fmul.4s	v15, v15, v15
    1b98:      	fadd.4s	v15, v13, v15
    1b9c:      	fadd.4s	v14, v12, v14
    1ba0:      	dup.2d	v9, x22
    1ba4:      	and.16b	v27, v11, v9
    1ba8:      	add.2d	v30, v30, v27
    1bac:      	and.16b	v27, v10, v9
    1bb0:      	add.2d	v20, v20, v27
    1bb4:      	and.16b	v16, v16, v9
    1bb8:      	add.2d	v21, v21, v16
    1bbc:      	and.16b	v0, v0, v9
    1bc0:      	add.2d	v17, v17, v0
    1bc4:      	bit.16b	v22, v8, v6
    1bc8:      	bit.16b	v2, v31, v7
    1bcc:      	bit.16b	v4, v18, v6
    1bd0:      	bit.16b	v1, v19, v7
    1bd4:      	bit.16b	v3, v28, v6
    1bd8:      	bit.16b	v5, v29, v7
    1bdc:      	bit.16b	v12, v14, v6
    1be0:      	bit.16b	v13, v15, v7
    1be4:      	fmov	x19, d17
    1be8:      	cmp	x19, #0x8
    1bec:      	b.lt	0x1b24 <ltmp0+0x1b24>
    1bf0:      	mov	x9, #0x0                ; =0
    1bf4:      	movi.2d	v17, #0000000000000000
    1bf8:      	movi.2d	v19, #0000000000000000
    1bfc:      	movi.2d	v20, #0000000000000000
    1c00:      	movi.2d	v21, #0000000000000000
    1c04:      	ldr	w0, [sp, #0x20]
    1c08:      	ldr	q9, [sp, #0x1c0]
    1c0c:      	ldr	q14, [sp, #0x1e0]
    1c10:      	b	0x1c44 <ltmp0+0x1c44>
    1c14:      	add	x9, x25, x9
    1c18:      	ldp	q0, q16, [x9]
    1c1c:      	bit.16b	v16, v11, v6
    1c20:      	bit.16b	v0, v10, v7
    1c24:      	stp	q0, q16, [x9]
    1c28:      	add.2d	v19, v19, v24
    1c2c:      	add.2d	v20, v20, v25
    1c30:      	add.2d	v21, v21, v23
    1c34:      	add.2d	v17, v17, v26
    1c38:      	fmov	x9, d17
    1c3c:      	cmp	x9, #0x8
    1c40:      	b.ge	0x1ce0 <ltmp0+0x1ce0>
    1c44:      	fmov	w3, s9
    1c48:      	lsl	x9, x9, #5
    1c4c:      	add	x10, x23, x9
    1c50:      	movi.2d	v10, #0000000000000000
    1c54:      	movi.2d	v11, #0000000000000000
    1c58:      	tbnz	w3, #0x0, 0x1c80 <ltmp0+0x1c80>
    1c5c:      	and	w3, w3, #0xff
    1c60:      	tbnz	w3, #0x1, 0x1c8c <ltmp0+0x1c8c>
    1c64:      	tbnz	w3, #0x2, 0x1c98 <ltmp0+0x1c98>
    1c68:      	tbnz	w3, #0x3, 0x1ca4 <ltmp0+0x1ca4>
    1c6c:      	tbnz	w3, #0x4, 0x1cb0 <ltmp0+0x1cb0>
    1c70:      	tbnz	w3, #0x5, 0x1cbc <ltmp0+0x1cbc>
    1c74:      	tbnz	w3, #0x6, 0x1cc8 <ltmp0+0x1cc8>
    1c78:      	tbz	w3, #0x7, 0x1c14 <ltmp0+0x1c14>
    1c7c:      	b	0x1cd4 <ltmp0+0x1cd4>
    1c80:      	ldr	s10, [x10]
    1c84:      	and	w3, w3, #0xff
    1c88:      	tbz	w3, #0x1, 0x1c64 <ltmp0+0x1c64>
    1c8c:      	add	x4, x10, #0x4
    1c90:      	ld1.s	{ v10 }[1], [x4]
    1c94:      	tbz	w3, #0x2, 0x1c68 <ltmp0+0x1c68>
    1c98:      	add	x4, x10, #0x8
    1c9c:      	ld1.s	{ v10 }[2], [x4]
    1ca0:      	tbz	w3, #0x3, 0x1c6c <ltmp0+0x1c6c>
    1ca4:      	add	x4, x10, #0xc
    1ca8:      	ld1.s	{ v10 }[3], [x4]
    1cac:      	tbz	w3, #0x4, 0x1c70 <ltmp0+0x1c70>
    1cb0:      	add	x4, x10, #0x10
    1cb4:      	ld1.s	{ v11 }[0], [x4]
    1cb8:      	tbz	w3, #0x5, 0x1c74 <ltmp0+0x1c74>
    1cbc:      	add	x4, x10, #0x14
    1cc0:      	ld1.s	{ v11 }[1], [x4]
    1cc4:      	tbz	w3, #0x6, 0x1c78 <ltmp0+0x1c78>
    1cc8:      	add	x4, x10, #0x18
    1ccc:      	ld1.s	{ v11 }[2], [x4]
    1cd0:      	tbz	w3, #0x7, 0x1c14 <ltmp0+0x1c14>
    1cd4:      	add	x10, x10, #0x1c
    1cd8:      	ld1.s	{ v11 }[3], [x10]
    1cdc:      	b	0x1c14 <ltmp0+0x1c14>
    1ce0:      	mov	b0, v14[0]
    1ce4:      	mov.b	v0[4], v14[1]
    1ce8:      	ushll.2d	v0, v0, #0x0
    1cec:      	shl.2d	v0, v0, #0x3f
    1cf0:      	cmlt.2d	v0, v0, #0
    1cf4:      	mov	b16, v14[2]
    1cf8:      	mov.b	v16[4], v14[3]
    1cfc:      	ldp	q19, q17, [sp, #0x80]
    1d00:      	and.16b	v0, v0, v17
    1d04:      	ushll.2d	v16, v16, #0x0
    1d08:      	shl.2d	v16, v16, #0x3f
    1d0c:      	cmlt.2d	v16, v16, #0
    1d10:      	ldp	q17, q18, [sp, #0x60]
    1d14:      	and.16b	v16, v16, v17
    1d18:      	mov	b17, v14[4]
    1d1c:      	mov.b	v17[4], v14[5]
    1d20:      	ushll.2d	v17, v17, #0x0
    1d24:      	shl.2d	v17, v17, #0x3f
    1d28:      	cmlt.2d	v17, v17, #0
    1d2c:      	and.16b	v17, v17, v18
    1d30:      	mov	b18, v14[6]
    1d34:      	mov.b	v18[4], v14[7]
    1d38:      	ushll.2d	v18, v18, #0x0
    1d3c:      	shl.2d	v18, v18, #0x3f
    1d40:      	cmlt.2d	v18, v18, #0
    1d44:      	and.16b	v18, v18, v19
    1d48:      	shl.8b	v19, v14, #0x7
    1d4c:      	cmlt.8b	v19, v19, #0
    1d50:      	ldr	d20, [sp, #0xb8]
    1d54:      	and.8b	v19, v19, v20
    1d58:      	addv.8b	b29, v19
    1d5c:      	str	q18, [sp, #0x4d0]
    1d60:      	str	q17, [sp, #0x4c0]
    1d64:      	str	q16, [sp, #0x4b0]
    1d68:      	str	q0, [sp, #0x4a0]
    1d6c:      	ldr	x15, [sp, #0x1f0]
    1d70:      	and	x9, x15, #0x7
    1d74:      	add	x10, sp, #0x4a0
    1d78:      	ldr	x10, [x10, x9, lsl #3]
    1d7c:      	fmov	w9, s29
    1d80:      	sub	x10, x10, x15
    1d84:      	lsl	x19, x10, #2
    1d88:      	add	x10, x23, x19
    1d8c:      	movi.2d	v30, #0000000000000000
    1d90:      	movi.2d	v28, #0000000000000000
    1d94:      	tbnz	w9, #0x0, 0x25b0 <ltmp0+0x25b0>
    1d98:      	tbnz	w9, #0x1, 0x25b8 <ltmp0+0x25b8>
    1d9c:      	tbnz	w9, #0x2, 0x25c4 <ltmp0+0x25c4>
    1da0:      	tbnz	w9, #0x3, 0x25d0 <ltmp0+0x25d0>
    1da4:      	tbnz	w9, #0x4, 0x25dc <ltmp0+0x25dc>
    1da8:      	tbnz	w9, #0x5, 0x25e8 <ltmp0+0x25e8>
    1dac:      	tbnz	w9, #0x6, 0x25f4 <ltmp0+0x25f4>
    1db0:      	tbz	w9, #0x7, 0x1dbc <ltmp0+0x1dbc>
    1db4:      	add	x9, x10, #0x1c
    1db8:      	ld1.s	{ v28 }[3], [x9]
    1dbc:      	mov	x9, #0x0                ; =0
    1dc0:      	add	x10, x25, x5
    1dc4:      	ldp	q0, q16, [x10]
    1dc8:      	zip2.8b	v17, v14, v0
    1dcc:      	ushll.4s	v17, v17, #0x0
    1dd0:      	shl.4s	v17, v17, #0x1f
    1dd4:      	cmlt.4s	v17, v17, #0
    1dd8:      	bit.16b	v16, v28, v17
    1ddc:      	zip1.8b	v17, v14, v0
    1de0:      	ushll.4s	v17, v17, #0x0
    1de4:      	shl.4s	v17, v17, #0x1f
    1de8:      	cmlt.4s	v17, v17, #0
    1dec:      	bit.16b	v0, v30, v17
    1df0:      	stp	q0, q16, [x10]
    1df4:      	movi.2d	v17, #0000000000000000
    1df8:      	movi.2d	v19, #0000000000000000
    1dfc:      	movi.2d	v20, #0000000000000000
    1e00:      	movi.2d	v21, #0000000000000000
    1e04:      	b	0x1e38 <ltmp0+0x1e38>
    1e08:      	add	x9, x27, x9
    1e0c:      	ldp	q0, q16, [x9]
    1e10:      	bit.16b	v16, v11, v6
    1e14:      	bit.16b	v0, v10, v7
    1e18:      	stp	q0, q16, [x9]
    1e1c:      	add.2d	v19, v19, v24
    1e20:      	add.2d	v20, v20, v25
    1e24:      	add.2d	v21, v21, v23
    1e28:      	add.2d	v17, v17, v26
    1e2c:      	fmov	x9, d17
    1e30:      	cmp	x9, #0x8
    1e34:      	b.ge	0x1ed4 <ltmp0+0x1ed4>
    1e38:      	fmov	w3, s9
    1e3c:      	lsl	x9, x9, #5
    1e40:      	add	x10, x17, x9
    1e44:      	movi.2d	v10, #0000000000000000
    1e48:      	movi.2d	v11, #0000000000000000
    1e4c:      	tbnz	w3, #0x0, 0x1e74 <ltmp0+0x1e74>
    1e50:      	and	w3, w3, #0xff
    1e54:      	tbnz	w3, #0x1, 0x1e80 <ltmp0+0x1e80>
    1e58:      	tbnz	w3, #0x2, 0x1e8c <ltmp0+0x1e8c>
    1e5c:      	tbnz	w3, #0x3, 0x1e98 <ltmp0+0x1e98>
    1e60:      	tbnz	w3, #0x4, 0x1ea4 <ltmp0+0x1ea4>
    1e64:      	tbnz	w3, #0x5, 0x1eb0 <ltmp0+0x1eb0>
    1e68:      	tbnz	w3, #0x6, 0x1ebc <ltmp0+0x1ebc>
    1e6c:      	tbz	w3, #0x7, 0x1e08 <ltmp0+0x1e08>
    1e70:      	b	0x1ec8 <ltmp0+0x1ec8>
    1e74:      	ldr	s10, [x10]
    1e78:      	and	w3, w3, #0xff
    1e7c:      	tbz	w3, #0x1, 0x1e58 <ltmp0+0x1e58>
    1e80:      	add	x4, x10, #0x4
    1e84:      	ld1.s	{ v10 }[1], [x4]
    1e88:      	tbz	w3, #0x2, 0x1e5c <ltmp0+0x1e5c>
    1e8c:      	add	x4, x10, #0x8
    1e90:      	ld1.s	{ v10 }[2], [x4]
    1e94:      	tbz	w3, #0x3, 0x1e60 <ltmp0+0x1e60>
    1e98:      	add	x4, x10, #0xc
    1e9c:      	ld1.s	{ v10 }[3], [x4]
    1ea0:      	tbz	w3, #0x4, 0x1e64 <ltmp0+0x1e64>
    1ea4:      	add	x4, x10, #0x10
    1ea8:      	ld1.s	{ v11 }[0], [x4]
    1eac:      	tbz	w3, #0x5, 0x1e68 <ltmp0+0x1e68>
    1eb0:      	add	x4, x10, #0x14
    1eb4:      	ld1.s	{ v11 }[1], [x4]
    1eb8:      	tbz	w3, #0x6, 0x1e6c <ltmp0+0x1e6c>
    1ebc:      	add	x4, x10, #0x18
    1ec0:      	ld1.s	{ v11 }[2], [x4]
    1ec4:      	tbz	w3, #0x7, 0x1e08 <ltmp0+0x1e08>
    1ec8:      	add	x10, x10, #0x1c
    1ecc:      	ld1.s	{ v11 }[3], [x10]
    1ed0:      	b	0x1e08 <ltmp0+0x1e08>
    1ed4:      	mov	x23, x0
    1ed8:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    1edc:      	ldr	q0, [x9]
    1ee0:      	and.16b	v21, v6, v0
    1ee4:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    1ee8:      	ldr	q0, [x9]
    1eec:      	and.16b	v10, v7, v0
    1ef0:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    1ef4:      	ldr	q20, [x9]
    1ef8:      	zip2.8b	v0, v14, v0
    1efc:      	ushll.4s	v0, v0, #0x0
    1f00:      	shl.4s	v0, v0, #0x1f
    1f04:      	cmlt.4s	v0, v0, #0
    1f08:      	ldp	q16, q18, [sp, #0x30]
    1f0c:      	and.16b	v17, v0, v16
    1f10:      	zip1.8b	v16, v14, v0
    1f14:      	ushll.4s	v16, v16, #0x0
    1f18:      	shl.4s	v16, v16, #0x1f
    1f1c:      	cmlt.4s	v16, v16, #0
    1f20:      	and.16b	v19, v16, v18
    1f24:      	fmul.4s	v18, v19, v19
    1f28:      	fmul.4s	v27, v17, v17
    1f2c:      	fadd.4s	v22, v27, v22
    1f30:      	fadd.4s	v2, v18, v2
    1f34:      	and.16b	v2, v16, v2
    1f38:      	and.16b	v0, v0, v22
    1f3c:      	ldr	q18, [sp, #0x50]
    1f40:      	zip2.8b	v16, v18, v0
    1f44:      	ushll.4s	v16, v16, #0x0
    1f48:      	shl.4s	v16, v16, #0x1f
    1f4c:      	cmlt.4s	v16, v16, #0
    1f50:      	bit.16b	v0, v8, v16
    1f54:      	zip1.8b	v16, v18, v0
    1f58:      	ushll.4s	v16, v16, #0x0
    1f5c:      	shl.4s	v16, v16, #0x1f
    1f60:      	cmlt.4s	v16, v16, #0
    1f64:      	bit.16b	v2, v31, v16
    1f68:      	fadd.4s	v1, v1, v2
    1f6c:      	fadd.4s	v0, v4, v0
    1f70:      	fadd.4s	v0, v3, v0
    1f74:      	fadd.4s	v1, v5, v1
    1f78:      	fadd.4s	v1, v13, v1
    1f7c:      	fadd.4s	v2, v12, v0
    1f80:      	fmov	w9, s10
    1f84:      	add	x10, sp, #0x248
    1f88:      	bfxil	x10, x9, #0, #3
    1f8c:      	ldr	q0, [sp, #0x120]
    1f90:      	str	d0, [sp, #0x248]
    1f94:      	ldrb	w10, [x10]
    1f98:      	add	x3, sp, #0x470
    1f9c:      	orr	x9, x3, x9, lsl #2
    1fa0:      	str	q2, [sp, #0x480]
    1fa4:      	str	q1, [sp, #0x470]
    1fa8:      	ldr	s0, [x9]
    1fac:      	ldr	w28, [sp, #0xb4]
    1fb0:      	tst	w28, w10
    1fb4:      	movi	d27, #0000000000000000
    1fb8:      	fcsel	s3, s0, s27, ne
    1fbc:      	mov.s	w9, v10[1]
    1fc0:      	add	x10, sp, #0x248
    1fc4:      	bfxil	x10, x9, #0, #3
    1fc8:      	ldrb	w9, [x10]
    1fcc:      	ldr	w4, [sp, #0x130]
    1fd0:      	and	w9, w4, w9
    1fd4:      	str	q1, [sp, #0x450]
    1fd8:      	ldr	s0, [sp, #0x450]
    1fdc:      	tst	w9, #0x1
    1fe0:      	mov.s	w9, v10[2]
    1fe4:      	fcsel	s4, s0, s27, ne
    1fe8:      	add	x10, sp, #0x248
    1fec:      	bfxil	x10, x9, #0, #3
    1ff0:      	add	x3, sp, #0x430
    1ff4:      	orr	x9, x3, x9, lsl #2
    1ff8:      	ldrb	w10, [x10]
    1ffc:      	ldr	w15, [sp, #0x150]
    2000:      	and	w10, w15, w10
    2004:      	str	q2, [sp, #0x440]
    2008:      	str	q1, [sp, #0x430]
    200c:      	ldr	s0, [x9]
    2010:      	tst	w10, #0x1
    2014:      	mov.s	w9, v10[3]
    2018:      	fcsel	s5, s0, s27, ne
    201c:      	add	x10, sp, #0x248
    2020:      	bfxil	x10, x9, #0, #3
    2024:      	add	x3, sp, #0x410
    2028:      	orr	x9, x3, x9, lsl #2
    202c:      	ldrb	w10, [x10]
    2030:      	ldr	w0, [sp, #0x140]
    2034:      	and	w10, w0, w10
    2038:      	str	q2, [sp, #0x420]
    203c:      	str	q1, [sp, #0x410]
    2040:      	ldr	s0, [x9]
    2044:      	tst	w10, #0x1
    2048:      	fcsel	s0, s0, s27, ne
    204c:      	fmov	w9, s21
    2050:      	add	x10, sp, #0x248
    2054:      	bfxil	x10, x9, #0, #3
    2058:      	ldrb	w10, [x10]
    205c:      	and	w10, w13, w10
    2060:      	stp	q1, q2, [sp, #0x3f0]
    2064:      	add	x3, sp, #0x3f0
    2068:      	ldr	s16, [x3, w9, uxtw #2]
    206c:      	tst	w10, #0x1
    2070:      	fcsel	s16, s16, s27, ne
    2074:      	mov.s	w9, v21[1]
    2078:      	add	x10, sp, #0x248
    207c:      	bfxil	x10, x9, #0, #3
    2080:      	ldrb	w10, [x10]
    2084:      	and	w10, w16, w10
    2088:      	stp	q1, q2, [sp, #0x3d0]
    208c:      	add	x3, sp, #0x3d0
    2090:      	ldr	s18, [x3, w9, uxtw #2]
    2094:      	tst	w10, #0x1
    2098:      	fcsel	s18, s18, s27, ne
    209c:      	mov.s	w9, v21[2]
    20a0:      	add	x10, sp, #0x248
    20a4:      	bfxil	x10, x9, #0, #3
    20a8:      	ldrb	w10, [x10]
    20ac:      	and	w10, w30, w10
    20b0:      	stp	q1, q2, [sp, #0x3b0]
    20b4:      	add	x3, sp, #0x3b0
    20b8:      	ldr	s22, [x3, w9, uxtw #2]
    20bc:      	tst	w10, #0x1
    20c0:      	fcsel	s22, s22, s27, ne
    20c4:      	mov.s	w9, v21[3]
    20c8:      	add	x10, sp, #0x248
    20cc:      	bfxil	x10, x9, #0, #3
    20d0:      	ldrb	w10, [x10]
    20d4:      	and	w10, w12, w10
    20d8:      	stp	q1, q2, [sp, #0x390]
    20dc:      	add	x3, sp, #0x390
    20e0:      	ldr	s21, [x3, w9, uxtw #2]
    20e4:      	tst	w10, #0x1
    20e8:      	fcsel	s21, s21, s27, ne
    20ec:      	mov.s	v16[1], v18[0]
    20f0:      	mov.s	v16[2], v22[0]
    20f4:      	mov.s	v16[3], v21[0]
    20f8:      	mov.s	v3[1], v4[0]
    20fc:      	and.16b	v18, v7, v20
    2100:      	mov.s	v3[2], v5[0]
    2104:      	mov.s	v3[3], v0[0]
    2108:      	fadd.4s	v1, v1, v3
    210c:      	fadd.4s	v2, v2, v16
    2110:      	fmov	w9, s18
    2114:      	add	x10, sp, #0x248
    2118:      	bfxil	x10, x9, #0, #3
    211c:      	ldrb	w10, [x10]
    2120:      	add	x3, sp, #0x370
    2124:      	orr	x9, x3, x9, lsl #2
    2128:      	stp	q1, q2, [sp, #0x370]
    212c:      	ldr	s0, [x9]
    2130:      	tst	w28, w10
    2134:      	mov.s	w9, v18[1]
    2138:      	add	x10, sp, #0x248
    213c:      	bfxil	x10, x9, #0, #3
    2140:      	ldrb	w10, [x10]
    2144:      	and	w10, w4, w10
    2148:      	fcsel	s3, s0, s27, ne
    214c:      	add	x3, sp, #0x350
    2150:      	orr	x9, x3, x9, lsl #2
    2154:      	stp	q1, q2, [sp, #0x350]
    2158:      	ldr	s0, [x9]
    215c:      	tst	w10, #0x1
    2160:      	mov.s	w9, v18[2]
    2164:      	add	x10, sp, #0x248
    2168:      	bfxil	x10, x9, #0, #3
    216c:      	fcsel	s4, s0, s27, ne
    2170:      	ldrb	w9, [x10]
    2174:      	and	w9, w15, w9
    2178:      	str	q1, [sp, #0x330]
    217c:      	tst	w9, #0x1
    2180:      	mov.s	w9, v18[3]
    2184:      	add	x10, sp, #0x248
    2188:      	bfxil	x10, x9, #0, #3
    218c:      	ldrb	w10, [x10]
    2190:      	and	w10, w0, w10
    2194:      	adrp	x3, 0x2000 <ltmp0+0x2000>
    2198:      	ldr	q0, [x3]
    219c:      	and.16b	v16, v6, v0
    21a0:      	ldr	s0, [sp, #0x330]
    21a4:      	fcsel	s5, s0, s27, ne
    21a8:      	add	x3, sp, #0x310
    21ac:      	orr	x9, x3, x9, lsl #2
    21b0:      	stp	q1, q2, [sp, #0x310]
    21b4:      	ldr	s0, [x9]
    21b8:      	tst	w10, #0x1
    21bc:      	fmov	w9, s16
    21c0:      	add	x10, sp, #0x248
    21c4:      	bfxil	x10, x9, #0, #3
    21c8:      	ldrb	w10, [x10]
    21cc:      	and	w10, w13, w10
    21d0:      	fcsel	s0, s0, s27, ne
    21d4:      	stp	q1, q2, [sp, #0x2f0]
    21d8:      	add	x13, sp, #0x2f0
    21dc:      	ldr	s18, [x13, w9, uxtw #2]
    21e0:      	tst	w10, #0x1
    21e4:      	mov.s	w9, v16[1]
    21e8:      	add	x10, sp, #0x248
    21ec:      	bfxil	x10, x9, #0, #3
    21f0:      	ldrb	w10, [x10]
    21f4:      	and	w10, w16, w10
    21f8:      	fcsel	s18, s18, s27, ne
    21fc:      	stp	q1, q2, [sp, #0x2d0]
    2200:      	add	x13, sp, #0x2d0
    2204:      	ldr	s20, [x13, w9, uxtw #2]
    2208:      	tst	w10, #0x1
    220c:      	mov.s	w9, v16[2]
    2210:      	add	x10, sp, #0x248
    2214:      	bfxil	x10, x9, #0, #3
    2218:      	ldrb	w10, [x10]
    221c:      	and	w10, w30, w10
    2220:      	fcsel	s20, s20, s27, ne
    2224:      	stp	q1, q2, [sp, #0x2b0]
    2228:      	add	x13, sp, #0x2b0
    222c:      	ldr	s21, [x13, w9, uxtw #2]
    2230:      	tst	w10, #0x1
    2234:      	mov.s	w9, v16[3]
    2238:      	add	x10, sp, #0x248
    223c:      	bfxil	x10, x9, #0, #3
    2240:      	ldrb	w10, [x10]
    2244:      	and	w10, w12, w10
    2248:      	fcsel	s16, s21, s27, ne
    224c:      	stp	q1, q2, [sp, #0x290]
    2250:      	add	x12, sp, #0x290
    2254:      	ldr	s21, [x12, w9, uxtw #2]
    2258:      	tst	w10, #0x1
    225c:      	fcsel	s21, s21, s27, ne
    2260:      	mov.s	v18[1], v20[0]
    2264:      	mov.s	v18[2], v16[0]
    2268:      	mov.s	v18[3], v21[0]
    226c:      	mov.s	v3[1], v4[0]
    2270:      	movi.4s	v4, #0x4
    2274:      	and.16b	v4, v7, v4
    2278:      	mov.s	v3[2], v5[0]
    227c:      	fmov	w9, s4
    2280:      	add	x10, sp, #0x248
    2284:      	orr	x10, x10, x9
    2288:      	ldrb	w10, [x10]
    228c:      	tst	w28, w10
    2290:      	mov.s	v3[3], v0[0]
    2294:      	fadd.4s	v0, v1, v3
    2298:      	fadd.4s	v1, v2, v18
    229c:      	stp	q0, q1, [sp, #0x270]
    22a0:      	add	x10, sp, #0x270
    22a4:      	ldr	s1, [x10, w9, uxtw #2]
    22a8:      	fcsel	s1, s1, s27, ne
    22ac:      	tst	w26, #0x1
    22b0:      	fadd	s0, s0, s1
    22b4:      	fcsel	s1, s0, s27, ne
    22b8:      	ldr	w9, [sp, #0x100]
    22bc:      	tst	w9, #0x1
    22c0:      	fcsel	s2, s0, s27, ne
    22c4:      	ldr	w9, [sp, #0xf0]
    22c8:      	tst	w9, #0x1
    22cc:      	fcsel	s3, s0, s27, ne
    22d0:      	ldr	w9, [sp, #0xe0]
    22d4:      	tst	w9, #0x1
    22d8:      	fcsel	s4, s0, s27, ne
    22dc:      	ldr	w9, [sp, #0x110]
    22e0:      	tst	w9, #0x1
    22e4:      	fcsel	s5, s0, s27, ne
    22e8:      	ldr	w9, [sp, #0xd0]
    22ec:      	tst	w9, #0x1
    22f0:      	fcsel	s16, s0, s27, ne
    22f4:      	ldp	w9, w10, [sp, #0xac]
    22f8:      	tst	w10, #0x1
    22fc:      	fcsel	s18, s0, s27, ne
    2300:      	tst	w9, #0x1
    2304:      	mov.s	v1[1], v2[0]
    2308:      	mov.s	v1[2], v3[0]
    230c:      	mov.s	v1[3], v4[0]
    2310:      	mov.s	v5[1], v16[0]
    2314:      	mov.s	v5[2], v18[0]
    2318:      	fcsel	s0, s0, s27, ne
    231c:      	mov.s	v5[3], v0[0]
    2320:      	stp	q1, q5, [sp, #0x250]
    2324:      	ldr	x9, [sp, #0xc0]
    2328:      	and	x9, x9, #0x7
    232c:      	add	x10, sp, #0x250
    2330:      	ldr	s3, [x10, x9, lsl #2]
    2334:      	add	x9, x17, x19
    2338:      	fmov	w10, s29
    233c:      	movi.2d	v2, #0000000000000000
    2340:      	movi.2d	v1, #0000000000000000
    2344:      	tbnz	w10, #0x0, 0x2604 <ltmp0+0x2604>
    2348:      	ldr	w3, [sp, #0x24]
    234c:      	mov	w26, #0x104             ; =260
    2350:      	ldr	w30, [sp, #0x1c]
    2354:      	ldr	x16, [sp, #0x1d0]
    2358:      	ldr	x0, [sp, #0x10]
    235c:      	tbnz	w10, #0x1, 0x2620 <ltmp0+0x2620>
    2360:      	mov	x28, x23
    2364:      	mov	w23, #0x20              ; =32
    2368:      	tbnz	w10, #0x2, 0x2634 <ltmp0+0x2634>
    236c:      	tbnz	w10, #0x3, 0x2640 <ltmp0+0x2640>
    2370:      	tbnz	w10, #0x4, 0x264c <ltmp0+0x264c>
    2374:      	tbnz	w10, #0x5, 0x2658 <ltmp0+0x2658>
    2378:      	tbnz	w10, #0x6, 0x2664 <ltmp0+0x2664>
    237c:      	tbz	w10, #0x7, 0x2388 <ltmp0+0x2388>
    2380:      	add	x9, x9, #0x1c
    2384:      	ld1.s	{ v1 }[3], [x9]
    2388:      	mov	x10, #0x0               ; =0
    238c:      	fadd	s0, s3, s27
    2390:      	fmov	s3, w11
    2394:      	fdiv	s0, s0, s3
    2398:      	fmov	s3, w14
    239c:      	fadd	s0, s0, s3
    23a0:      	fsqrt	s0, s0
    23a4:      	add	x9, x27, x5
    23a8:      	ldp	q3, q4, [x9]
    23ac:      	zip2.8b	v5, v14, v0
    23b0:      	ushll.4s	v5, v5, #0x0
    23b4:      	shl.4s	v5, v5, #0x1f
    23b8:      	cmlt.4s	v5, v5, #0
    23bc:      	bit.16b	v4, v1, v5
    23c0:      	zip1.8b	v5, v14, v0
    23c4:      	ushll.4s	v5, v5, #0x0
    23c8:      	shl.4s	v5, v5, #0x1f
    23cc:      	cmlt.4s	v5, v5, #0
    23d0:      	bit.16b	v3, v2, v5
    23d4:      	stp	q3, q4, [x9]
    23d8:      	dup.4s	v3, v0[0]
    23dc:      	ldr	q0, [sp, #0x170]
    23e0:      	fmov	x9, d0
    23e4:      	add	x9, x16, x9, lsl #2
    23e8:      	movi.2d	v4, #0000000000000000
    23ec:      	movi.2d	v5, #0000000000000000
    23f0:      	movi.2d	v18, #0000000000000000
    23f4:      	movi.2d	v20, #0000000000000000
    23f8:      	b	0x2418 <ltmp0+0x2418>
    23fc:      	add.2d	v5, v5, v24
    2400:      	add.2d	v18, v18, v25
    2404:      	add.2d	v20, v20, v23
    2408:      	add.2d	v4, v4, v26
    240c:      	fmov	x10, d4
    2410:      	cmp	x10, #0x8
    2414:      	b.ge	0x24f0 <ltmp0+0x24f0>
    2418:      	fmov	w12, s9
    241c:      	lsl	x10, x10, #5
    2420:      	add	x13, x24, x10
    2424:      	ldp	q16, q0, [x13]
    2428:      	and.16b	v16, v7, v16
    242c:      	fdiv.4s	v16, v16, v3
    2430:      	add	x13, x25, x10
    2434:      	ldp	q22, q21, [x13]
    2438:      	and.16b	v22, v7, v22
    243c:      	fmul.4s	v16, v16, v22
    2440:      	add	x13, x27, x10
    2444:      	ldp	q27, q22, [x13]
    2448:      	and.16b	v27, v7, v27
    244c:      	fadd.4s	v27, v16, v27
    2450:      	add	x10, x9, x10
    2454:      	tbnz	w12, #0x0, 0x249c <ltmp0+0x249c>
    2458:      	and	w12, w12, #0xff
    245c:      	tbnz	w12, #0x1, 0x24a8 <ltmp0+0x24a8>
    2460:      	tbnz	w12, #0x2, 0x24b4 <ltmp0+0x24b4>
    2464:      	tbz	w12, #0x3, 0x2470 <ltmp0+0x2470>
    2468:      	add	x13, x10, #0xc
    246c:      	st1.s	{ v27 }[3], [x13]
    2470:      	and.16b	v0, v6, v0
    2474:      	fdiv.4s	v0, v0, v3
    2478:      	and.16b	v16, v6, v21
    247c:      	fmul.4s	v0, v0, v16
    2480:      	and.16b	v16, v6, v22
    2484:      	fadd.4s	v0, v0, v16
    2488:      	tbnz	w12, #0x4, 0x24c4 <ltmp0+0x24c4>
    248c:      	tbnz	w12, #0x5, 0x24cc <ltmp0+0x24cc>
    2490:      	tbnz	w12, #0x6, 0x24d8 <ltmp0+0x24d8>
    2494:      	tbz	w12, #0x7, 0x23fc <ltmp0+0x23fc>
    2498:      	b	0x24e4 <ltmp0+0x24e4>
    249c:      	str	s27, [x10]
    24a0:      	and	w12, w12, #0xff
    24a4:      	tbz	w12, #0x1, 0x2460 <ltmp0+0x2460>
    24a8:      	add	x13, x10, #0x4
    24ac:      	st1.s	{ v27 }[1], [x13]
    24b0:      	tbz	w12, #0x2, 0x2464 <ltmp0+0x2464>
    24b4:      	add	x13, x10, #0x8
    24b8:      	st1.s	{ v27 }[2], [x13]
    24bc:      	tbnz	w12, #0x3, 0x2468 <ltmp0+0x2468>
    24c0:      	b	0x2470 <ltmp0+0x2470>
    24c4:      	str	s0, [x10, #0x10]
    24c8:      	tbz	w12, #0x5, 0x2490 <ltmp0+0x2490>
    24cc:      	add	x13, x10, #0x14
    24d0:      	st1.s	{ v0 }[1], [x13]
    24d4:      	tbz	w12, #0x6, 0x2494 <ltmp0+0x2494>
    24d8:      	add	x13, x10, #0x18
    24dc:      	st1.s	{ v0 }[2], [x13]
    24e0:      	tbz	w12, #0x7, 0x23fc <ltmp0+0x23fc>
    24e4:      	add	x10, x10, #0x1c
    24e8:      	st1.s	{ v0 }[3], [x10]
    24ec:      	b	0x23fc <ltmp0+0x23fc>
    24f0:      	fdiv.4s	v0, v19, v3
    24f4:      	fmul.4s	v0, v0, v30
    24f8:      	fadd.4s	v0, v0, v2
    24fc:      	ldp	q2, q4, [sp, #0x1a0]
    2500:      	ldp	q6, q5, [sp, #0x180]
    2504:      	stp	q4, q5, [sp, #0x200]
    2508:      	stp	q6, q2, [sp, #0x220]
    250c:      	ldr	x12, [sp, #0x1f0]
    2510:      	and	x9, x12, #0x7
    2514:      	add	x10, sp, #0x200
    2518:      	ldr	x9, [x10, x9, lsl #3]
    251c:      	sub	x9, x9, x12
    2520:      	add	x9, x16, x9, lsl #2
    2524:      	fmov	w10, s29
    2528:      	tbnz	w10, #0x0, 0x2674 <ltmp0+0x2674>
    252c:      	tbnz	w10, #0x1, 0x267c <ltmp0+0x267c>
    2530:      	tbnz	w10, #0x2, 0x2688 <ltmp0+0x2688>
    2534:      	tbnz	w10, #0x3, 0x2694 <ltmp0+0x2694>
    2538:      	fdiv.4s	v0, v17, v3
    253c:      	fmul.4s	v0, v0, v28
    2540:      	fadd.4s	v0, v0, v1
    2544:      	tbnz	w10, #0x4, 0x26ac <ltmp0+0x26ac>
    2548:      	tbnz	w10, #0x5, 0x26b4 <ltmp0+0x26b4>
    254c:      	tbnz	w10, #0x6, 0x26c0 <ltmp0+0x26c0>
    2550:      	tbz	w10, #0x7, 0xda4 <ltmp0+0xda4>
    2554:      	b	0x26cc <ltmp0+0x26cc>
    2558:      	ldr	s24, [x10]
    255c:      	tbz	w9, #0x1, 0x13d4 <ltmp0+0x13d4>
    2560:      	add	x12, x10, #0x4
    2564:      	ld1.s	{ v24 }[1], [x12]
    2568:      	tbz	w9, #0x2, 0x13d8 <ltmp0+0x13d8>
    256c:      	add	x12, x10, #0x8
    2570:      	ld1.s	{ v24 }[2], [x12]
    2574:      	tbz	w9, #0x3, 0x13dc <ltmp0+0x13dc>
    2578:      	add	x12, x10, #0xc
    257c:      	ld1.s	{ v24 }[3], [x12]
    2580:      	tbz	w9, #0x4, 0x13e0 <ltmp0+0x13e0>
    2584:      	add	x12, x10, #0x10
    2588:      	ld1.s	{ v27 }[0], [x12]
    258c:      	tbz	w9, #0x5, 0x13e4 <ltmp0+0x13e4>
    2590:      	add	x12, x10, #0x14
    2594:      	ld1.s	{ v27 }[1], [x12]
    2598:      	tbz	w9, #0x6, 0x13e8 <ltmp0+0x13e8>
    259c:      	add	x12, x10, #0x18
    25a0:      	ld1.s	{ v27 }[2], [x12]
    25a4:      	str	q16, [sp, #0x1c0]
    25a8:      	tbnz	w9, #0x7, 0x13f0 <ltmp0+0x13f0>
    25ac:      	b	0x13f8 <ltmp0+0x13f8>
    25b0:      	ldr	s30, [x10]
    25b4:      	tbz	w9, #0x1, 0x1d9c <ltmp0+0x1d9c>
    25b8:      	add	x3, x10, #0x4
    25bc:      	ld1.s	{ v30 }[1], [x3]
    25c0:      	tbz	w9, #0x2, 0x1da0 <ltmp0+0x1da0>
    25c4:      	add	x3, x10, #0x8
    25c8:      	ld1.s	{ v30 }[2], [x3]
    25cc:      	tbz	w9, #0x3, 0x1da4 <ltmp0+0x1da4>
    25d0:      	add	x3, x10, #0xc
    25d4:      	ld1.s	{ v30 }[3], [x3]
    25d8:      	tbz	w9, #0x4, 0x1da8 <ltmp0+0x1da8>
    25dc:      	add	x3, x10, #0x10
    25e0:      	ld1.s	{ v28 }[0], [x3]
    25e4:      	tbz	w9, #0x5, 0x1dac <ltmp0+0x1dac>
    25e8:      	add	x3, x10, #0x14
    25ec:      	ld1.s	{ v28 }[1], [x3]
    25f0:      	tbz	w9, #0x6, 0x1db0 <ltmp0+0x1db0>
    25f4:      	add	x3, x10, #0x18
    25f8:      	ld1.s	{ v28 }[2], [x3]
    25fc:      	tbnz	w9, #0x7, 0x1db4 <ltmp0+0x1db4>
    2600:      	b	0x1dbc <ltmp0+0x1dbc>
    2604:      	ldr	s2, [x9]
    2608:      	ldr	w3, [sp, #0x24]
    260c:      	mov	w26, #0x104             ; =260
    2610:      	ldr	w30, [sp, #0x1c]
    2614:      	ldr	x16, [sp, #0x1d0]
    2618:      	ldr	x0, [sp, #0x10]
    261c:      	tbz	w10, #0x1, 0x2360 <ltmp0+0x2360>
    2620:      	add	x12, x9, #0x4
    2624:      	ld1.s	{ v2 }[1], [x12]
    2628:      	mov	x28, x23
    262c:      	mov	w23, #0x20              ; =32
    2630:      	tbz	w10, #0x2, 0x236c <ltmp0+0x236c>
    2634:      	add	x12, x9, #0x8
    2638:      	ld1.s	{ v2 }[2], [x12]
    263c:      	tbz	w10, #0x3, 0x2370 <ltmp0+0x2370>
    2640:      	add	x12, x9, #0xc
    2644:      	ld1.s	{ v2 }[3], [x12]
    2648:      	tbz	w10, #0x4, 0x2374 <ltmp0+0x2374>
    264c:      	add	x12, x9, #0x10
    2650:      	ld1.s	{ v1 }[0], [x12]
    2654:      	tbz	w10, #0x5, 0x2378 <ltmp0+0x2378>
    2658:      	add	x12, x9, #0x14
    265c:      	ld1.s	{ v1 }[1], [x12]
    2660:      	tbz	w10, #0x6, 0x237c <ltmp0+0x237c>
    2664:      	add	x12, x9, #0x18
    2668:      	ld1.s	{ v1 }[2], [x12]
    266c:      	tbnz	w10, #0x7, 0x2380 <ltmp0+0x2380>
    2670:      	b	0x2388 <ltmp0+0x2388>
    2674:      	str	s0, [x9]
    2678:      	tbz	w10, #0x1, 0x2530 <ltmp0+0x2530>
    267c:      	add	x12, x9, #0x4
    2680:      	st1.s	{ v0 }[1], [x12]
    2684:      	tbz	w10, #0x2, 0x2534 <ltmp0+0x2534>
    2688:      	add	x12, x9, #0x8
    268c:      	st1.s	{ v0 }[2], [x12]
    2690:      	tbz	w10, #0x3, 0x2538 <ltmp0+0x2538>
    2694:      	add	x12, x9, #0xc
    2698:      	st1.s	{ v0 }[3], [x12]
    269c:      	fdiv.4s	v0, v17, v3
    26a0:      	fmul.4s	v0, v0, v28
    26a4:      	fadd.4s	v0, v0, v1
    26a8:      	tbz	w10, #0x4, 0x2548 <ltmp0+0x2548>
    26ac:      	str	s0, [x9, #0x10]
    26b0:      	tbz	w10, #0x5, 0x254c <ltmp0+0x254c>
    26b4:      	add	x12, x9, #0x14
    26b8:      	st1.s	{ v0 }[1], [x12]
    26bc:      	tbz	w10, #0x6, 0x2550 <ltmp0+0x2550>
    26c0:      	add	x12, x9, #0x18
    26c4:      	st1.s	{ v0 }[2], [x12]
    26c8:      	tbz	w10, #0x7, 0xda4 <ltmp0+0xda4>
    26cc:      	add	x9, x9, #0x1c
    26d0:      	st1.s	{ v0 }[3], [x9]
    26d4:      	b	0xda4 <ltmp0+0xda4>
    26d8:      	add	sp, sp, #0xb60
    26dc:      	ldp	x29, x30, [sp, #0x90]
    26e0:      	ldp	x20, x19, [sp, #0x80]
    26e4:      	ldp	x22, x21, [sp, #0x70]
    26e8:      	ldp	x24, x23, [sp, #0x60]
    26ec:      	ldp	x26, x25, [sp, #0x50]
    26f0:      	ldp	x28, x27, [sp, #0x40]
    26f4:      	ldp	d9, d8, [sp, #0x30]
    26f8:      	ldp	d11, d10, [sp, #0x20]
    26fc:      	ldp	d13, d12, [sp, #0x10]
    2700:      	ldp	d15, d14, [sp], #0xa0
    2704:      	ret

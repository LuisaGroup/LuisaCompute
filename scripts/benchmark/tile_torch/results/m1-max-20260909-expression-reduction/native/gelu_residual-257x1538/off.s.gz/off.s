
/private/tmp/luisa-expression-fusion.qXgTbC/capture/gelu_residual-257x1538/off/object/tile_xir_w8_23473_1788930271526447_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0x90]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x26, x25, [sp, #0x40]
      14:      	stp	x24, x23, [sp, #0x50]
      18:      	stp	x22, x21, [sp, #0x60]
      1c:      	stp	x20, x19, [sp, #0x70]
      20:      	stp	x29, x30, [sp, #0x80]
      24:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
      28:      	sub	sp, sp, #0x160
      2c:      	ldr	x22, [x0]
      30:      	ldr	x23, [x0, #0x10]
      34:      	ldr	x19, [x0, #0x30]
      38:      	ldr	w8, [x1]
      3c:      	ldr	w9, [x1, #0x24]
      40:      	add	w8, w9, w8, lsl #5
      44:      	lsr	w8, w8, #3
      48:      	fmov	s0, w8
      4c:      	ushll.2d	v0, v0, #0x0
      50:      	fmov	x24, d0
      54:      	mov	w25, #0x1808            ; =6152
      58:      	umaddl	x1, w24, w25, x22
      5c:      	mov	w20, #0x1800            ; =6144
      60:      	add	x21, sp, #0x1, lsl #12  ; =0x1000
      64:      	add	x21, x21, #0x940
      68:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
      6c:      	add	x0, x0, #0x940
      70:      	mov	w2, #0x1800             ; =6144
      74:      	bl	0x74 <ltmp0+0x74>
      78:      	umaddl	x20, w24, w25, x20
      7c:      	add	x8, x22, x20
      80:      	add	x9, x8, #0x4
      84:      	ldr	s0, [x8]
      88:      	ld1.s	{ v0 }[1], [x9]
      8c:      	str	q0, [sp]
      90:      	str	q0, [sp, #0x3140]
      94:      	umaddl	x1, w24, w25, x23
      98:      	add	x22, sp, #0x120
      9c:      	add	x0, sp, #0x120
      a0:      	mov	w2, #0x1800             ; =6144
      a4:      	bl	0xa4 <ltmp0+0xa4>
      a8:      	mov	x8, #0x0                ; =0
      ac:      	add	x9, x23, x20
      b0:      	ldr	s0, [x9], #0x4
      b4:      	ld1.s	{ v0 }[1], [x9]
      b8:      	str	q0, [sp, #0x10]
      bc:      	str	q0, [sp, #0x1920]
      c0:      	umaddl	x9, w24, w25, x19
      c4:      	mov	w10, #0x2713            ; =10003
      c8:      	movk	w10, #0x3d37, lsl #16
      cc:      	dup.4s	v1, w10
      d0:      	mov	w10, #0x422a            ; =16938
      d4:      	movk	w10, #0x3f4c, lsl #16
      d8:      	dup.4s	v0, w10
      dc:      	stp	q0, q1, [sp, #0xf0]
      e0:      	fmov.4s	v18, #1.00000000
      e4:      	mov	w10, #0x9231            ; =37425
      e8:      	movk	w10, #0x2f30, lsl #16
      ec:      	dup.4s	v1, w10
      f0:      	mov	w10, #0x322b            ; =12843
      f4:      	movk	w10, #0x32d7, lsl #16
      f8:      	dup.4s	v0, w10
      fc:      	stp	q0, q1, [sp, #0xd0]
     100:      	mov	w10, #0xef1d            ; =61213
     104:      	movk	w10, #0x3638, lsl #16
     108:      	dup.4s	v1, w10
     10c:      	mov	w10, #0xd01             ; =3329
     110:      	movk	w10, #0x3950, lsl #16
     114:      	dup.4s	v0, w10
     118:      	stp	q0, q1, [sp, #0xb0]
     11c:      	mov	w10, #0x8889            ; =34953
     120:      	movk	w10, #0x3c08, lsl #16
     124:      	dup.4s	v1, w10
     128:      	mov	w10, #0xaaab            ; =43691
     12c:      	movk	w10, #0x3e2a, lsl #16
     130:      	dup.4s	v21, w10
     134:      	mov	w10, #0x76c7            ; =30407
     138:      	movk	w10, #0x310f, lsl #16
     13c:      	dup.4s	v0, w10
     140:      	stp	q0, q1, [sp, #0x90]
     144:      	mov	w10, #0xf27e            ; =62078
     148:      	movk	w10, #0x3493, lsl #16
     14c:      	dup.4s	v1, w10
     150:      	mov	w10, #0xd01             ; =3329
     154:      	movk	w10, #0x37d0, lsl #16
     158:      	dup.4s	v0, w10
     15c:      	stp	q0, q1, [sp, #0x70]
     160:      	mov	w10, #0xb61             ; =2913
     164:      	movk	w10, #0x3ab6, lsl #16
     168:      	dup.4s	v1, w10
     16c:      	mov	w10, #0xaaab            ; =43691
     170:      	movk	w10, #0x3d2a, lsl #16
     174:      	dup.4s	v0, w10
     178:      	stp	q0, q1, [sp, #0x50]
     17c:      	mov	w10, #-0x3d300000       ; =-1026555904
     180:      	dup.4s	v1, w10
     184:      	mov	w10, #0x42c80000        ; =1120403456
     188:      	dup.4s	v26, w10
     18c:      	fmov.4s	v0, #9.00000000
     190:      	str	q0, [sp, #0x110]
     194:      	mov	w10, #0xaa3b            ; =43579
     198:      	movk	w10, #0x3fb8, lsl #16
     19c:      	dup.4s	v0, w10
     1a0:      	stp	q0, q1, [sp, #0x30]
     1a4:      	mov	w10, #0x7200            ; =29184
     1a8:      	movk	w10, #0xbf31, lsl #16
     1ac:      	dup.4s	v0, w10
     1b0:      	str	q0, [sp, #0x20]
     1b4:      	mov	w10, #0xbe8e            ; =48782
     1b8:      	movk	w10, #0xb5bf, lsl #16
     1bc:      	dup.4s	v31, w10
     1c0:      	mov	w10, #0x2bda            ; =11226
     1c4:      	movk	w10, #0x3950, lsl #16
     1c8:      	dup.4s	v8, w10
     1cc:      	mov	w10, #0x96c9            ; =38601
     1d0:      	movk	w10, #0x3ab6, lsl #16
     1d4:      	dup.4s	v9, w10
     1d8:      	mov	w10, #0x88a6            ; =34982
     1dc:      	movk	w10, #0x3c08, lsl #16
     1e0:      	dup.4s	v10, w10
     1e4:      	mov	w10, #0xaa7a            ; =43642
     1e8:      	movk	w10, #0x3d2a, lsl #16
     1ec:      	dup.4s	v11, w10
     1f0:      	mvni.4s	v1, #0x7f, msl #16
     1f4:      	fneg.4s	v13, v1
     1f8:      	mvni.4s	v1, #0x3f, msl #16
     1fc:      	fneg.4s	v15, v1
     200:      	lsl	x10, x8, #5
     204:      	add	x11, x21, x10
     208:      	ldp	q28, q29, [x11]
     20c:      	ldp	q0, q3, [sp, #0xf0]
     210:      	fmul.4s	v1, v28, v3
     214:      	fmul.4s	v2, v29, v3
     218:      	fmul.4s	v2, v29, v2
     21c:      	fmul.4s	v1, v28, v1
     220:      	fmul.4s	v1, v28, v1
     224:      	fmul.4s	v2, v29, v2
     228:      	fadd.4s	v2, v29, v2
     22c:      	fadd.4s	v1, v28, v1
     230:      	fmul.4s	v14, v1, v0
     234:      	fmul.4s	v12, v2, v0
     238:      	fabs.4s	v3, v12
     23c:      	fabs.4s	v2, v14
     240:      	fmul.4s	v17, v14, v14
     244:      	ldp	q4, q0, [sp, #0xd0]
     248:      	mov.16b	v1, v4
     24c:      	fmul.4s	v20, v12, v12
     250:      	fmla.4s	v1, v17, v0
     254:      	fmla.4s	v4, v20, v0
     258:      	ldp	q0, q6, [sp, #0xb0]
     25c:      	mov.16b	v5, v6
     260:      	fmla.4s	v5, v17, v1
     264:      	fmla.4s	v6, v20, v4
     268:      	mov.16b	v4, v0
     26c:      	fmla.4s	v4, v17, v5
     270:      	mov.16b	v5, v0
     274:      	ldr	q0, [sp, #0xa0]
     278:      	mov.16b	v7, v0
     27c:      	fmla.4s	v5, v20, v6
     280:      	mov.16b	v6, v0
     284:      	mov.16b	v19, v21
     288:      	mov.16b	v16, v21
     28c:      	mov.16b	v1, v18
     290:      	mov.16b	v25, v18
     294:      	fmla.4s	v7, v17, v4
     298:      	ldp	q22, q0, [sp, #0x80]
     29c:      	mov.16b	v4, v22
     2a0:      	fmla.4s	v4, v20, v0
     2a4:      	fmla.4s	v22, v17, v0
     2a8:      	ldr	q0, [sp, #0x70]
     2ac:      	mov.16b	v23, v0
     2b0:      	fmla.4s	v6, v20, v5
     2b4:      	fmla.4s	v23, v20, v4
     2b8:      	mov.16b	v4, v0
     2bc:      	fmla.4s	v4, v17, v22
     2c0:      	ldp	q22, q0, [sp, #0x50]
     2c4:      	mov.16b	v5, v0
     2c8:      	fmla.4s	v5, v20, v23
     2cc:      	fmla.4s	v19, v17, v7
     2d0:      	mov.16b	v7, v0
     2d4:      	fmla.4s	v7, v17, v4
     2d8:      	mov.16b	v4, v22
     2dc:      	fmla.4s	v4, v20, v5
     2e0:      	fmla.4s	v16, v20, v6
     2e4:      	fmla.4s	v22, v17, v7
     2e8:      	movi.4s	v23, #0x3f, lsl #24
     2ec:      	fmla.4s	v23, v20, v4
     2f0:      	movi.4s	v24, #0x3f, lsl #24
     2f4:      	mov.16b	v6, v18
     2f8:      	fmla.4s	v25, v20, v16
     2fc:      	mov.16b	v0, v18
     300:      	ldr	q5, [sp, #0x110]
     304:      	fcmge.4s	v4, v5, v2
     308:      	fcmge.4s	v5, v5, v3
     30c:      	and.16b	v7, v5, v3
     310:      	and.16b	v16, v4, v2
     314:      	fmla.4s	v6, v20, v23
     318:      	ldr	q23, [sp, #0x40]
     31c:      	fcmge.4s	v20, v16, v23
     320:      	fcmge.4s	v23, v7, v23
     324:      	fcmge.4s	v27, v26, v7
     328:      	and.16b	v23, v23, v27
     32c:      	fcmge.4s	v27, v26, v16
     330:      	fmla.4s	v24, v17, v22
     334:      	and.16b	v20, v20, v27
     338:      	and.16b	v20, v20, v16
     33c:      	and.16b	v22, v23, v7
     340:      	ldr	q27, [sp, #0x30]
     344:      	fmul.4s	v23, v22, v27
     348:      	fmul.4s	v27, v20, v27
     34c:      	fmla.4s	v1, v17, v19
     350:      	movi.4s	v30, #0x4b, lsl #24
     354:      	fadd.4s	v19, v27, v30
     358:      	fadd.4s	v23, v23, v30
     35c:      	movi.4s	v27, #0xcb, lsl #24
     360:      	fadd.4s	v23, v23, v27
     364:      	fadd.4s	v19, v19, v27
     368:      	fcvtzs.4s	v19, v19
     36c:      	fmla.4s	v0, v17, v24
     370:      	fcvtzs.4s	v23, v23
     374:      	scvtf.4s	v17, v23
     378:      	scvtf.4s	v24, v19
     37c:      	ldr	q30, [sp, #0x20]
     380:      	fmul.4s	v27, v17, v30
     384:      	fadd.4s	v22, v22, v27
     388:      	fmul.4s	v27, v24, v30
     38c:      	fadd.4s	v20, v20, v27
     390:      	fmul.4s	v17, v17, v31
     394:      	fmul.4s	v24, v24, v31
     398:      	fadd.4s	v20, v20, v24
     39c:      	fadd.4s	v22, v22, v17
     3a0:      	fmul.4s	v17, v22, v8
     3a4:      	fmul.4s	v24, v20, v8
     3a8:      	fadd.4s	v24, v24, v9
     3ac:      	fadd.4s	v17, v17, v9
     3b0:      	fmul.4s	v17, v22, v17
     3b4:      	fmul.4s	v24, v20, v24
     3b8:      	fmul.4s	v1, v2, v1
     3bc:      	fadd.4s	v24, v24, v10
     3c0:      	fadd.4s	v17, v17, v10
     3c4:      	fmul.4s	v27, v22, v17
     3c8:      	fmul.4s	v17, v20, v24
     3cc:      	fadd.4s	v24, v17, v11
     3d0:      	fdiv.4s	v17, v1, v0
     3d4:      	fadd.4s	v0, v27, v11
     3d8:      	fmul.4s	v0, v22, v0
     3dc:      	fmul.4s	v1, v20, v24
     3e0:      	fadd.4s	v1, v1, v21
     3e4:      	fadd.4s	v0, v0, v21
     3e8:      	fmul.4s	v0, v22, v0
     3ec:      	fmul.4s	v1, v20, v1
     3f0:      	movi.4s	v27, #0x3f, lsl #24
     3f4:      	fadd.4s	v1, v1, v27
     3f8:      	fadd.4s	v0, v0, v27
     3fc:      	fmul.4s	v24, v22, v22
     400:      	fmul.4s	v0, v24, v0
     404:      	fmul.4s	v24, v20, v20
     408:      	fmul.4s	v1, v24, v1
     40c:      	fadd.4s	v1, v20, v1
     410:      	fadd.4s	v0, v22, v0
     414:      	fadd.4s	v0, v0, v18
     418:      	movi.2d	v20, #0xffffffffffffffff
     41c:      	add.4s	v19, v19, v20
     420:      	fadd.4s	v1, v1, v18
     424:      	add.4s	v20, v23, v20
     428:      	sshr.4s	v22, v20, #0x1
     42c:      	sshr.4s	v23, v19, #0x1
     430:      	shl.4s	v24, v23, #0x17
     434:      	add.4s	v24, v24, v18
     438:      	fmul.4s	v1, v1, v24
     43c:      	shl.4s	v24, v22, #0x17
     440:      	add.4s	v24, v24, v18
     444:      	fmul.4s	v0, v0, v24
     448:      	sub.4s	v19, v19, v23
     44c:      	sub.4s	v20, v20, v22
     450:      	shl.4s	v20, v20, #0x17
     454:      	add.4s	v20, v20, v18
     458:      	fmul.4s	v0, v0, v20
     45c:      	shl.4s	v19, v19, #0x17
     460:      	add.4s	v19, v19, v18
     464:      	fmul.4s	v1, v1, v19
     468:      	fmul.4s	v19, v3, v25
     46c:      	fcmgt.4s	v7, v7, v26
     470:      	fcmgt.4s	v16, v16, v26
     474:      	bsl.16b	v16, v13, v1
     478:      	bit.16b	v0, v13, v7
     47c:      	fmov.4s	v1, #0.25000000
     480:      	fdiv.4s	v6, v19, v6
     484:      	fdiv.4s	v7, v1, v0
     488:      	fsub.4s	v19, v0, v7
     48c:      	fadd.4s	v0, v0, v7
     490:      	fdiv.4s	v0, v19, v0
     494:      	bif.16b	v0, v18, v5
     498:      	fcmge.4s	v3, v18, v3
     49c:      	bit.16b	v0, v6, v3
     4a0:      	fdiv.4s	v3, v1, v16
     4a4:      	fsub.4s	v5, v16, v3
     4a8:      	fadd.4s	v3, v16, v3
     4ac:      	fdiv.4s	v3, v5, v3
     4b0:      	bif.16b	v3, v18, v4
     4b4:      	fcmge.4s	v2, v18, v2
     4b8:      	bsl.16b	v2, v17, v3
     4bc:      	mvni.4s	v4, #0x80, lsl #24
     4c0:      	bif.16b	v2, v14, v4
     4c4:      	fcmeq.4s	v3, v14, v14
     4c8:      	fadd.4s	v2, v2, v18
     4cc:      	bif.16b	v2, v15, v3
     4d0:      	bif.16b	v0, v12, v4
     4d4:      	fcmeq.4s	v3, v12, v12
     4d8:      	fadd.4s	v0, v0, v18
     4dc:      	bif.16b	v0, v15, v3
     4e0:      	fmul.4s	v3, v29, v27
     4e4:      	fmul.4s	v0, v3, v0
     4e8:      	fmul.4s	v3, v28, v27
     4ec:      	fmul.4s	v2, v3, v2
     4f0:      	add	x11, x22, x10
     4f4:      	ldp	q4, q3, [x11]
     4f8:      	fadd.4s	v2, v4, v2
     4fc:      	fadd.4s	v0, v3, v0
     500:      	add	x10, x9, x10
     504:      	stp	q2, q0, [x10]
     508:      	add	x8, x8, #0x1
     50c:      	cmp	x8, #0xc0
     510:      	b.ne	0x200 <ltmp0+0x200>
     514:      	movi.2d	v3, #0000000000000000
     518:      	movi.2d	v2, #0000000000000000
     51c:      	ldr	q5, [sp]
     520:      	mov.d	v2[0], v5[0]
     524:      	mov	w8, #0x2713             ; =10003
     528:      	movk	w8, #0x3d37, lsl #16
     52c:      	dup.4s	v0, w8
     530:      	fmul.4s	v0, v2, v0
     534:      	fmul.4s	v0, v5, v0
     538:      	fmul.4s	v0, v5, v0
     53c:      	mov	w8, #0x422a             ; =16938
     540:      	movk	w8, #0x3f4c, lsl #16
     544:      	dup.4s	v4, w8
     548:      	fadd.4s	v0, v5, v0
     54c:      	fmul.4s	v0, v0, v4
     550:      	mov.d	v3[0], v0[0]
     554:      	fabs.4s	v5, v3
     558:      	fmul.4s	v4, v3, v3
     55c:      	mov	w8, #0x9231             ; =37425
     560:      	movk	w8, #0x2f30, lsl #16
     564:      	dup.4s	v0, w8
     568:      	mov	w8, #0x322b             ; =12843
     56c:      	movk	w8, #0x32d7, lsl #16
     570:      	dup.4s	v6, w8
     574:      	fmla.4s	v6, v4, v0
     578:      	mov	w8, #0xef1d             ; =61213
     57c:      	movk	w8, #0x3638, lsl #16
     580:      	dup.4s	v0, w8
     584:      	fmla.4s	v0, v4, v6
     588:      	mov	w8, #0xd01              ; =3329
     58c:      	movk	w8, #0x3950, lsl #16
     590:      	dup.4s	v6, w8
     594:      	fmla.4s	v6, v4, v0
     598:      	mov	w8, #0x8889             ; =34953
     59c:      	movk	w8, #0x3c08, lsl #16
     5a0:      	dup.4s	v16, w8
     5a4:      	fmla.4s	v16, v4, v6
     5a8:      	mov	w8, #0xaaab             ; =43691
     5ac:      	movk	w8, #0x3e2a, lsl #16
     5b0:      	dup.4s	v0, w8
     5b4:      	ldr	q6, [sp, #0x110]
     5b8:      	fcmge.4s	v6, v6, v5
     5bc:      	and.16b	v7, v6, v5
     5c0:      	mov	w8, #-0x3d300000        ; =-1026555904
     5c4:      	dup.4s	v19, w8
     5c8:      	mov	w8, #0x42c80000         ; =1120403456
     5cc:      	dup.4s	v17, w8
     5d0:      	fcmge.4s	v19, v7, v19
     5d4:      	fcmge.4s	v20, v17, v7
     5d8:      	and.16b	v19, v19, v20
     5dc:      	mov	w8, #0xaa3b             ; =43579
     5e0:      	movk	w8, #0x3fb8, lsl #16
     5e4:      	dup.4s	v20, w8
     5e8:      	and.16b	v19, v19, v7
     5ec:      	fmul.4s	v20, v19, v20
     5f0:      	movi.4s	v21, #0x4b, lsl #24
     5f4:      	fadd.4s	v20, v20, v21
     5f8:      	movi.4s	v21, #0xcb, lsl #24
     5fc:      	fadd.4s	v20, v20, v21
     600:      	fcvtzs.4s	v20, v20
     604:      	scvtf.4s	v21, v20
     608:      	mov	w8, #0x7200             ; =29184
     60c:      	movk	w8, #0xbf31, lsl #16
     610:      	dup.4s	v22, w8
     614:      	fmul.4s	v22, v21, v22
     618:      	fadd.4s	v19, v19, v22
     61c:      	mov	w8, #0xbe8e             ; =48782
     620:      	movk	w8, #0xb5bf, lsl #16
     624:      	dup.4s	v22, w8
     628:      	fmul.4s	v21, v21, v22
     62c:      	fadd.4s	v19, v19, v21
     630:      	mov	w8, #0x2bda             ; =11226
     634:      	movk	w8, #0x3950, lsl #16
     638:      	dup.4s	v21, w8
     63c:      	mov	w8, #0x96c9             ; =38601
     640:      	movk	w8, #0x3ab6, lsl #16
     644:      	dup.4s	v22, w8
     648:      	fmul.4s	v21, v19, v21
     64c:      	fadd.4s	v21, v21, v22
     650:      	fmul.4s	v21, v19, v21
     654:      	mov	w8, #0x88a6             ; =34982
     658:      	movk	w8, #0x3c08, lsl #16
     65c:      	dup.4s	v22, w8
     660:      	fadd.4s	v21, v21, v22
     664:      	fmul.4s	v21, v19, v21
     668:      	mov	w8, #0xaa7a             ; =43642
     66c:      	movk	w8, #0x3d2a, lsl #16
     670:      	dup.4s	v22, w8
     674:      	fadd.4s	v21, v21, v22
     678:      	fcmge.4s	v22, v18, v5
     67c:      	fmul.4s	v21, v19, v21
     680:      	fadd.4s	v21, v21, v0
     684:      	fmla.4s	v0, v4, v16
     688:      	mov.16b	v16, v18
     68c:      	fmla.4s	v16, v4, v0
     690:      	fmul.4s	v0, v5, v16
     694:      	mov	w8, #0x76c7             ; =30407
     698:      	movk	w8, #0x310f, lsl #16
     69c:      	dup.4s	v5, w8
     6a0:      	mov	w8, #0xf27e             ; =62078
     6a4:      	movk	w8, #0x3493, lsl #16
     6a8:      	dup.4s	v16, w8
     6ac:      	fmla.4s	v16, v4, v5
     6b0:      	mov	w8, #0xd01              ; =3329
     6b4:      	movk	w8, #0x37d0, lsl #16
     6b8:      	dup.4s	v5, w8
     6bc:      	fmla.4s	v5, v4, v16
     6c0:      	mov	w8, #0xb61              ; =2913
     6c4:      	movk	w8, #0x3ab6, lsl #16
     6c8:      	dup.4s	v16, w8
     6cc:      	fmla.4s	v16, v4, v5
     6d0:      	mov	w8, #0xaaab             ; =43691
     6d4:      	movk	w8, #0x3d2a, lsl #16
     6d8:      	dup.4s	v5, w8
     6dc:      	fmla.4s	v5, v4, v16
     6e0:      	movi.4s	v16, #0x3f, lsl #24
     6e4:      	fmla.4s	v16, v4, v5
     6e8:      	mov.16b	v5, v18
     6ec:      	fmla.4s	v5, v4, v16
     6f0:      	movi.4s	v4, #0x3f, lsl #24
     6f4:      	fdiv.4s	v0, v0, v5
     6f8:      	fmul.4s	v5, v19, v21
     6fc:      	fadd.4s	v4, v5, v4
     700:      	fmul.4s	v5, v19, v19
     704:      	fmul.4s	v4, v5, v4
     708:      	fadd.4s	v4, v19, v4
     70c:      	fadd.4s	v4, v4, v18
     710:      	movi.2d	v5, #0xffffffffffffffff
     714:      	add.4s	v5, v20, v5
     718:      	sshr.4s	v16, v5, #0x1
     71c:      	shl.4s	v19, v16, #0x17
     720:      	add.4s	v19, v19, v18
     724:      	fmul.4s	v4, v4, v19
     728:      	sub.4s	v5, v5, v16
     72c:      	shl.4s	v5, v5, #0x17
     730:      	add.4s	v5, v5, v18
     734:      	fmul.4s	v4, v4, v5
     738:      	fcmgt.4s	v5, v7, v17
     73c:      	mvni.4s	v7, #0x7f, msl #16
     740:      	fneg.4s	v7, v7
     744:      	bit.16b	v4, v7, v5
     748:      	fdiv.4s	v1, v1, v4
     74c:      	fsub.4s	v5, v4, v1
     750:      	fadd.4s	v1, v4, v1
     754:      	fdiv.4s	v1, v5, v1
     758:      	bif.16b	v1, v18, v6
     75c:      	bif.16b	v0, v1, v22
     760:      	mvni.4s	v1, #0x80, lsl #24
     764:      	bif.16b	v0, v3, v1
     768:      	fcmeq.4s	v1, v3, v3
     76c:      	fadd.4s	v0, v0, v18
     770:      	mvni.4s	v3, #0x3f, msl #16
     774:      	fneg.4s	v3, v3
     778:      	bif.16b	v0, v3, v1
     77c:      	movi.2s	v1, #0x3f, lsl #24
     780:      	fmul.2s	v1, v2, v1
     784:      	fmul.2s	v0, v1, v0
     788:      	ldr	q1, [sp, #0x10]
     78c:      	fadd.2s	v0, v0, v1
     790:      	str	d0, [x19, x20]
     794:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
     798:      	add	sp, sp, #0x160
     79c:      	ldp	x29, x30, [sp, #0x80]
     7a0:      	ldp	x20, x19, [sp, #0x70]
     7a4:      	ldp	x22, x21, [sp, #0x60]
     7a8:      	ldp	x24, x23, [sp, #0x50]
     7ac:      	ldp	x26, x25, [sp, #0x40]
     7b0:      	ldp	d9, d8, [sp, #0x30]
     7b4:      	ldp	d11, d10, [sp, #0x20]
     7b8:      	ldp	d13, d12, [sp, #0x10]
     7bc:      	ldp	d15, d14, [sp], #0x90
     7c0:      	ret

00000000000007c4 <_llm_rows.packet_batch.blocks>:
     7c4:      	stp	d15, d14, [sp, #-0xa0]!
     7c8:      	stp	d13, d12, [sp, #0x10]
     7cc:      	stp	d11, d10, [sp, #0x20]
     7d0:      	stp	d9, d8, [sp, #0x30]
     7d4:      	stp	x28, x27, [sp, #0x40]
     7d8:      	stp	x26, x25, [sp, #0x50]
     7dc:      	stp	x24, x23, [sp, #0x60]
     7e0:      	stp	x22, x21, [sp, #0x70]
     7e4:      	stp	x20, x19, [sp, #0x80]
     7e8:      	stp	x29, x30, [sp, #0x90]
     7ec:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
     7f0:      	sub	sp, sp, #0x340
     7f4:      	str	x0, [sp, #0xf8]
     7f8:      	cbz	w3, 0x1870 <_llm_rows.packet_batch.blocks+0x10ac>
     7fc:      	mov	x27, x3
     800:      	mov	x20, x2
     804:      	mov	w22, #0x0               ; =0
     808:      	ldp	w9, w8, [x2, #0x2c]
     80c:      	stp	w8, w9, [sp, #0xf0]
     810:      	adrp	x8, 0x0 <ltmp0>
     814:      	ldr	q0, [x8]
     818:      	str	q0, [sp, #0x30]
     81c:      	adrp	x8, 0x0 <ltmp0>
     820:      	ldr	q0, [x8]
     824:      	str	q0, [sp, #0x20]
     828:      	add	x25, sp, #0x1, lsl #12  ; =0x1000
     82c:      	add	x25, x25, #0xb20
     830:      	adrp	x8, 0x0 <ltmp0>
     834:      	ldr	q0, [x8]
     838:      	str	q0, [sp, #0x10]
     83c:      	add	x24, sp, #0x300
     840:      	mvni.4s	v0, #0x7f, msl #16
     844:      	fneg.4s	v1, v0
     848:      	mvni.4s	v0, #0x3f, msl #16
     84c:      	fneg.4s	v0, v0
     850:      	stp	q0, q1, [sp, #0x200]
     854:      	ldp	w28, w21, [x2]
     858:      	mov	w30, #0xf27e            ; =62078
     85c:      	movk	w30, #0x3493, lsl #16
     860:      	ldp	w19, w23, [x2, #0x8]
     864:      	str	w3, [sp, #0xdc]
     868:      	b	0x8b0 <_llm_rows.packet_batch.blocks+0xec>
     86c:      	mov	w8, #0x18               ; =24
     870:      	str	w8, [x20, #0x24]
     874:      	ldr	w27, [sp, #0xdc]
     878:      	add	w8, w28, #0x1
     87c:      	ldp	w10, w9, [sp, #0xf0]
     880:      	cmp	w8, w9
     884:      	cset	w8, eq
     888:      	csinc	w28, wzr, w28, eq
     88c:      	cinc	w9, w21, eq
     890:      	cmp	w9, w10
     894:      	cset	w10, eq
     898:      	ands	w8, w8, w10
     89c:      	csel	w21, wzr, w9, ne
     8a0:      	add	w19, w19, w8
     8a4:      	add	w22, w22, #0x1
     8a8:      	cmp	w22, w27
     8ac:      	b.eq	0x1870 <_llm_rows.packet_batch.blocks+0x10ac>
     8b0:      	ubfiz	x8, x28, #5, #32
     8b4:      	cmp	x8, x23
     8b8:      	csel	x9, x8, xzr, ls
     8bc:      	subs	x10, x23, x9
     8c0:      	cmp	x10, #0x20
     8c4:      	mov	w11, #0x20              ; =32
     8c8:      	csel	x10, x10, x11, lo
     8cc:      	cmp	x23, x9
     8d0:      	stp	w28, w21, [x20]
     8d4:      	str	w19, [x20, #0x8]
     8d8:      	str	wzr, [x20, #0x24]
     8dc:      	ccmp	x8, x23, #0x2, hi
     8e0:      	csel	x26, x10, xzr, ls
     8e4:      	cmp	x26, #0x20
     8e8:      	b.lo	0x944 <_llm_rows.packet_batch.blocks+0x180>
     8ec:      	ldr	x26, [sp, #0xf8]
     8f0:      	mov	x0, x26
     8f4:      	mov	x1, x20
     8f8:      	bl	0x8f8 <_llm_rows.packet_batch.blocks+0x134>
     8fc:      	mov	w8, #0x8                ; =8
     900:      	str	w8, [x20, #0x24]
     904:      	mov	x0, x26
     908:      	mov	x1, x20
     90c:      	bl	0x90c <_llm_rows.packet_batch.blocks+0x148>
     910:      	mov	w8, #0x10               ; =16
     914:      	str	w8, [x20, #0x24]
     918:      	mov	x0, x26
     91c:      	mov	x1, x20
     920:      	bl	0x920 <_llm_rows.packet_batch.blocks+0x15c>
     924:      	mov	w8, #0x18               ; =24
     928:      	str	w8, [x20, #0x24]
     92c:      	mov	x0, x26
     930:      	mov	x1, x20
     934:      	bl	0x934 <_llm_rows.packet_batch.blocks+0x170>
     938:      	mov	w30, #0xf27e            ; =62078
     93c:      	movk	w30, #0x3493, lsl #16
     940:      	b	0x878 <_llm_rows.packet_batch.blocks+0xb4>
     944:      	lsr	x27, x26, #3
     948:      	cmp	x26, #0x8
     94c:      	b.lo	0x9b0 <_llm_rows.packet_batch.blocks+0x1ec>
     950:      	str	wzr, [x20, #0x24]
     954:      	ldr	x0, [sp, #0xf8]
     958:      	mov	x1, x20
     95c:      	bl	0x95c <_llm_rows.packet_batch.blocks+0x198>
     960:      	mov	w30, #0xf27e            ; =62078
     964:      	movk	w30, #0x3493, lsl #16
     968:      	cmp	x27, #0x1
     96c:      	b.eq	0x9b0 <_llm_rows.packet_batch.blocks+0x1ec>
     970:      	mov	w8, #0x8                ; =8
     974:      	str	w8, [x20, #0x24]
     978:      	ldr	x0, [sp, #0xf8]
     97c:      	mov	x1, x20
     980:      	bl	0x980 <_llm_rows.packet_batch.blocks+0x1bc>
     984:      	mov	w30, #0xf27e            ; =62078
     988:      	movk	w30, #0x3493, lsl #16
     98c:      	cmp	x27, #0x2
     990:      	b.eq	0x9b0 <_llm_rows.packet_batch.blocks+0x1ec>
     994:      	mov	w8, #0x10               ; =16
     998:      	str	w8, [x20, #0x24]
     99c:      	ldr	x0, [sp, #0xf8]
     9a0:      	mov	x1, x20
     9a4:      	bl	0x9a4 <_llm_rows.packet_batch.blocks+0x1e0>
     9a8:      	mov	w30, #0xf27e            ; =62078
     9ac:      	movk	w30, #0x3493, lsl #16
     9b0:      	and	w8, w26, #0x7
     9b4:      	cbz	w8, 0x86c <_llm_rows.packet_batch.blocks+0xa8>
     9b8:      	dup.4s	v0, w8
     9bc:      	ldp	q2, q1, [sp, #0x20]
     9c0:      	cmhi.4s	v30, v0, v2
     9c4:      	cmhi.4s	v9, v0, v1
     9c8:      	uzp1.8h	v3, v9, v30
     9cc:      	umaxv.8h	h0, v3
     9d0:      	fmov	w8, s0
     9d4:      	tbz	w8, #0x0, 0x86c <_llm_rows.packet_batch.blocks+0xa8>
     9d8:      	mov	x9, #0x0                ; =0
     9dc:      	ldr	x11, [sp, #0xf8]
     9e0:      	ldr	x12, [x11]
     9e4:      	ldr	x10, [x11, #0x10]
     9e8:      	ubfiz	w8, w28, #2, #27
     9ec:      	orr	w8, w8, w27
     9f0:      	dup.4s	v0, w8
     9f4:      	ldr	x8, [x11, #0x30]
     9f8:      	and.16b	v1, v9, v0
     9fc:      	and.16b	v0, v30, v0
     a00:      	ushll2.2d	v5, v0, #0x0
     a04:      	ushll2.2d	v2, v1, #0x0
     a08:      	ushll.2d	v4, v0, #0x0
     a0c:      	ushll.2d	v6, v1, #0x0
     a10:      	fmov	x11, d6
     a14:      	mov	w13, #0x1808            ; =6152
     a18:      	umaddl	x11, w11, w13, x12
     a1c:      	ldr	q0, [sp, #0x10]
     a20:      	and.16b	v0, v3, v0
     a24:      	addv.8h	h0, v0
     a28:      	str	q0, [sp, #0x140]
     a2c:      	fmov	w13, s0
     a30:      	b	0xa54 <_llm_rows.packet_batch.blocks+0x290>
     a34:      	add	x14, x25, x9, lsl #5
     a38:      	ldp	q0, q1, [x14]
     a3c:      	bit.16b	v1, v16, v30
     a40:      	bit.16b	v0, v7, v9
     a44:      	stp	q0, q1, [x14]
     a48:      	add	x9, x9, #0x1
     a4c:      	cmp	x9, #0xc0
     a50:      	b.eq	0xae8 <_llm_rows.packet_batch.blocks+0x324>
     a54:      	add	x14, x11, x9, lsl #5
     a58:      	movi.2d	v7, #0000000000000000
     a5c:      	movi.2d	v16, #0000000000000000
     a60:      	tbnz	w13, #0x0, 0xa88 <_llm_rows.packet_batch.blocks+0x2c4>
     a64:      	and	w15, w13, #0xff
     a68:      	tbnz	w15, #0x1, 0xa94 <_llm_rows.packet_batch.blocks+0x2d0>
     a6c:      	tbnz	w15, #0x2, 0xaa0 <_llm_rows.packet_batch.blocks+0x2dc>
     a70:      	tbnz	w15, #0x3, 0xaac <_llm_rows.packet_batch.blocks+0x2e8>
     a74:      	tbnz	w15, #0x4, 0xab8 <_llm_rows.packet_batch.blocks+0x2f4>
     a78:      	tbnz	w15, #0x5, 0xac4 <_llm_rows.packet_batch.blocks+0x300>
     a7c:      	tbnz	w15, #0x6, 0xad0 <_llm_rows.packet_batch.blocks+0x30c>
     a80:      	tbz	w15, #0x7, 0xa34 <_llm_rows.packet_batch.blocks+0x270>
     a84:      	b	0xadc <_llm_rows.packet_batch.blocks+0x318>
     a88:      	ldr	s7, [x14]
     a8c:      	and	w15, w13, #0xff
     a90:      	tbz	w15, #0x1, 0xa6c <_llm_rows.packet_batch.blocks+0x2a8>
     a94:      	add	x16, x14, #0x4
     a98:      	ld1.s	{ v7 }[1], [x16]
     a9c:      	tbz	w15, #0x2, 0xa70 <_llm_rows.packet_batch.blocks+0x2ac>
     aa0:      	add	x16, x14, #0x8
     aa4:      	ld1.s	{ v7 }[2], [x16]
     aa8:      	tbz	w15, #0x3, 0xa74 <_llm_rows.packet_batch.blocks+0x2b0>
     aac:      	add	x16, x14, #0xc
     ab0:      	ld1.s	{ v7 }[3], [x16]
     ab4:      	tbz	w15, #0x4, 0xa78 <_llm_rows.packet_batch.blocks+0x2b4>
     ab8:      	add	x16, x14, #0x10
     abc:      	ld1.s	{ v16 }[0], [x16]
     ac0:      	tbz	w15, #0x5, 0xa7c <_llm_rows.packet_batch.blocks+0x2b8>
     ac4:      	add	x16, x14, #0x14
     ac8:      	ld1.s	{ v16 }[1], [x16]
     acc:      	tbz	w15, #0x6, 0xa80 <_llm_rows.packet_batch.blocks+0x2bc>
     ad0:      	add	x16, x14, #0x18
     ad4:      	ld1.s	{ v16 }[2], [x16]
     ad8:      	tbz	w15, #0x7, 0xa34 <_llm_rows.packet_batch.blocks+0x270>
     adc:      	add	x14, x14, #0x1c
     ae0:      	ld1.s	{ v16 }[3], [x14]
     ae4:      	b	0xa34 <_llm_rows.packet_batch.blocks+0x270>
     ae8:      	xtn.8b	v0, v3
     aec:      	sshll.2d	v1, v9, #0x0
     af0:      	movi	d3, #0x0000000000ffff
     af4:      	and.8b	v20, v0, v3
     af8:      	adrp	x9, 0x0 <ltmp0>
     afc:      	ldr	d3, [x9]
     b00:      	and.8b	v0, v0, v3
     b04:      	addv.8b	b0, v0
     b08:      	fmov	w13, s0
     b0c:      	umaxv.8b	b0, v20
     b10:      	fmov	w9, s0
     b14:      	rbit	w11, w13
     b18:      	clz	w11, w11
     b1c:      	tst	w9, #0x1
     b20:      	csel	w9, w11, wzr, ne
     b24:      	adrp	x11, 0x0 <ltmp0>
     b28:      	ldr	q0, [x11]
     b2c:      	mov	w11, #0x600             ; =1536
     b30:      	dup.2d	v7, x11
     b34:      	bsl.16b	v1, v0, v7
     b38:      	mov	w11, #0x602             ; =1538
     b3c:      	dup.2s	v3, w11
     b40:      	xtn.2s	v6, v6
     b44:      	mov	b0, v20[0]
     b48:      	mov.b	v0[4], v20[1]
     b4c:      	umlal.2d	v1, v6, v3
     b50:      	ushll.2d	v0, v0, #0x0
     b54:      	shl.2d	v0, v0, #0x3f
     b58:      	cmlt.2d	v0, v0, #0
     b5c:      	str	q1, [sp, #0xb0]
     b60:      	and.16b	v0, v0, v1
     b64:      	movi.2d	v1, #0000000000000000
     b68:      	stp	q1, q1, [sp, #0x2d0]
     b6c:      	stp	q0, q1, [sp, #0x2b0]
     b70:      	and	x11, x9, #0x7
     b74:      	add	x14, sp, #0x2b0
     b78:      	ldr	x11, [x14, x11, lsl #3]
     b7c:      	sub	x11, x11, x9
     b80:      	lsl	x11, x11, #2
     b84:      	add	x12, x12, x11
     b88:      	movi.2d	v21, #0000000000000000
     b8c:      	movi.2d	v19, #0000000000000000
     b90:      	tbz	w13, #0x0, 0xb98 <_llm_rows.packet_batch.blocks+0x3d4>
     b94:      	ldr	s21, [x12]
     b98:      	mov	w1, #0x2713             ; =10003
     b9c:      	movk	w1, #0x3d37, lsl #16
     ba0:      	mov	w2, #0x422a             ; =16938
     ba4:      	movk	w2, #0x3f4c, lsl #16
     ba8:      	mov	w3, #0x9231             ; =37425
     bac:      	movk	w3, #0x2f30, lsl #16
     bb0:      	mov	w4, #0x322b             ; =12843
     bb4:      	movk	w4, #0x32d7, lsl #16
     bb8:      	mov	w5, #0xef1d             ; =61213
     bbc:      	movk	w5, #0x3638, lsl #16
     bc0:      	mov	w6, #0xd01              ; =3329
     bc4:      	movk	w6, #0x3950, lsl #16
     bc8:      	mov	w7, #0x8889             ; =34953
     bcc:      	movk	w7, #0x3c08, lsl #16
     bd0:      	mov	w26, #0xaaab            ; =43691
     bd4:      	movk	w26, #0x3e2a, lsl #16
     bd8:      	mov	w27, #0x76c7            ; =30407
     bdc:      	movk	w27, #0x310f, lsl #16
     be0:      	tbnz	w13, #0x1, 0x1754 <_llm_rows.packet_batch.blocks+0xf90>
     be4:      	tbnz	w13, #0x2, 0x1760 <_llm_rows.packet_batch.blocks+0xf9c>
     be8:      	tbnz	w13, #0x3, 0x176c <_llm_rows.packet_batch.blocks+0xfa8>
     bec:      	tbnz	w13, #0x4, 0x1778 <_llm_rows.packet_batch.blocks+0xfb4>
     bf0:      	tbnz	w13, #0x5, 0x1784 <_llm_rows.packet_batch.blocks+0xfc0>
     bf4:      	tbnz	w13, #0x6, 0x1790 <_llm_rows.packet_batch.blocks+0xfcc>
     bf8:      	tbz	w13, #0x7, 0xc04 <_llm_rows.packet_batch.blocks+0x440>
     bfc:      	add	x12, x12, #0x1c
     c00:      	ld1.s	{ v19 }[3], [x12]
     c04:      	mov	x15, #0x0               ; =0
     c08:      	sshll2.2d	v0, v30, #0x0
     c0c:      	sshll2.2d	v1, v9, #0x0
     c10:      	sshll.2d	v16, v30, #0x0
     c14:      	adrp	x12, 0x0 <ltmp0>
     c18:      	ldr	q17, [x12]
     c1c:      	mov.16b	v22, v16
     c20:      	bsl.16b	v22, v17, v7
     c24:      	adrp	x12, 0x0 <ltmp0>
     c28:      	ldr	q16, [x12]
     c2c:      	mov.16b	v23, v1
     c30:      	bsl.16b	v23, v16, v7
     c34:      	adrp	x12, 0x0 <ltmp0>
     c38:      	ldr	q16, [x12]
     c3c:      	mov.16b	v24, v0
     c40:      	bsl.16b	v24, v16, v7
     c44:      	adrp	x12, 0x0 <ltmp0>
     c48:      	ldr	q7, [x12]
     c4c:      	mov	w12, #0x1800            ; =6144
     c50:      	dup.2d	v16, x12
     c54:      	sshll.2d	v17, v9, #0x0
     c58:      	bif.16b	v7, v16, v17
     c5c:      	adrp	x12, 0x0 <ltmp0>
     c60:      	ldr	q17, [x12]
     c64:      	sshll.2d	v18, v30, #0x0
     c68:      	bif.16b	v17, v16, v18
     c6c:      	adrp	x12, 0x0 <ltmp0>
     c70:      	ldr	q18, [x12]
     c74:      	bsl.16b	v1, v18, v16
     c78:      	adrp	x12, 0x0 <ltmp0>
     c7c:      	ldr	q18, [x12]
     c80:      	bsl.16b	v0, v18, v16
     c84:      	xtn.2s	v5, v5
     c88:      	umlal.2d	v24, v5, v3
     c8c:      	umull.2d	v5, v6, v3
     c90:      	xtn.2s	v2, v2
     c94:      	xtn.2s	v4, v4
     c98:      	umlal.2d	v23, v2, v3
     c9c:      	stp	q24, q23, [sp, #0x70]
     ca0:      	stp	q17, q0, [sp, #0x290]
     ca4:      	stp	q7, q1, [sp, #0x270]
     ca8:      	and	x12, x9, #0x7
     cac:      	add	x14, sp, #0x270
     cb0:      	ldr	x12, [x14, x12, lsl #3]
     cb4:      	umlal.2d	v22, v4, v3
     cb8:      	str	q22, [sp, #0x90]
     cbc:      	sub	x12, x12, x9, lsl #2
     cc0:      	tst	w13, #0xff
     cc4:      	csel	x12, xzr, x12, eq
     cc8:      	add	x13, x25, x12
     ccc:      	ldp	q0, q1, [x13]
     cd0:      	zip2.8b	v2, v20, v0
     cd4:      	ushll.4s	v2, v2, #0x0
     cd8:      	shl.4s	v2, v2, #0x1f
     cdc:      	cmlt.4s	v2, v2, #0
     ce0:      	bit.16b	v1, v19, v2
     ce4:      	zip1.8b	v2, v20, v0
     ce8:      	ushll.4s	v2, v2, #0x0
     cec:      	shl.4s	v2, v2, #0x1f
     cf0:      	cmlt.4s	v2, v2, #0
     cf4:      	bit.16b	v0, v21, v2
     cf8:      	stp	q0, q1, [x13]
     cfc:      	fmov	x13, d5
     d00:      	lsl	x13, x13, #2
     d04:      	add	x14, x10, x13
     d08:      	mov	w16, #0x1               ; =1
     d0c:      	dup.2d	v0, x16
     d10:      	ushll2.2d	v1, v30, #0x0
     d14:      	and.16b	v16, v1, v0
     d18:      	ushll2.2d	v1, v9, #0x0
     d1c:      	and.16b	v17, v1, v0
     d20:      	ushll.2d	v1, v30, #0x0
     d24:      	and.16b	v22, v1, v0
     d28:      	ushll.2d	v1, v9, #0x0
     d2c:      	and.16b	v28, v1, v0
     d30:      	movi.2d	v2, #0000000000000000
     d34:      	movi.2d	v3, #0000000000000000
     d38:      	movi.2d	v4, #0000000000000000
     d3c:      	movi.2d	v5, #0000000000000000
     d40:      	b	0xd74 <_llm_rows.packet_batch.blocks+0x5b0>
     d44:      	add	x15, x24, x15
     d48:      	ldp	q0, q1, [x15]
     d4c:      	bit.16b	v1, v7, v30
     d50:      	bit.16b	v0, v6, v9
     d54:      	stp	q0, q1, [x15]
     d58:      	add.2d	v3, v3, v17
     d5c:      	add.2d	v4, v4, v22
     d60:      	add.2d	v5, v5, v16
     d64:      	add.2d	v2, v2, v28
     d68:      	fmov	x15, d2
     d6c:      	cmp	x15, #0xc0
     d70:      	b.ge	0xe14 <_llm_rows.packet_batch.blocks+0x650>
     d74:      	ldr	q0, [sp, #0x140]
     d78:      	fmov	w17, s0
     d7c:      	lsl	x15, x15, #5
     d80:      	add	x16, x14, x15
     d84:      	movi.2d	v6, #0000000000000000
     d88:      	movi.2d	v7, #0000000000000000
     d8c:      	tbnz	w17, #0x0, 0xdb4 <_llm_rows.packet_batch.blocks+0x5f0>
     d90:      	and	w17, w17, #0xff
     d94:      	tbnz	w17, #0x1, 0xdc0 <_llm_rows.packet_batch.blocks+0x5fc>
     d98:      	tbnz	w17, #0x2, 0xdcc <_llm_rows.packet_batch.blocks+0x608>
     d9c:      	tbnz	w17, #0x3, 0xdd8 <_llm_rows.packet_batch.blocks+0x614>
     da0:      	tbnz	w17, #0x4, 0xde4 <_llm_rows.packet_batch.blocks+0x620>
     da4:      	tbnz	w17, #0x5, 0xdf0 <_llm_rows.packet_batch.blocks+0x62c>
     da8:      	tbnz	w17, #0x6, 0xdfc <_llm_rows.packet_batch.blocks+0x638>
     dac:      	tbz	w17, #0x7, 0xd44 <_llm_rows.packet_batch.blocks+0x580>
     db0:      	b	0xe08 <_llm_rows.packet_batch.blocks+0x644>
     db4:      	ldr	s6, [x16]
     db8:      	and	w17, w17, #0xff
     dbc:      	tbz	w17, #0x1, 0xd98 <_llm_rows.packet_batch.blocks+0x5d4>
     dc0:      	add	x0, x16, #0x4
     dc4:      	ld1.s	{ v6 }[1], [x0]
     dc8:      	tbz	w17, #0x2, 0xd9c <_llm_rows.packet_batch.blocks+0x5d8>
     dcc:      	add	x0, x16, #0x8
     dd0:      	ld1.s	{ v6 }[2], [x0]
     dd4:      	tbz	w17, #0x3, 0xda0 <_llm_rows.packet_batch.blocks+0x5dc>
     dd8:      	add	x0, x16, #0xc
     ddc:      	ld1.s	{ v6 }[3], [x0]
     de0:      	tbz	w17, #0x4, 0xda4 <_llm_rows.packet_batch.blocks+0x5e0>
     de4:      	add	x0, x16, #0x10
     de8:      	ld1.s	{ v7 }[0], [x0]
     dec:      	tbz	w17, #0x5, 0xda8 <_llm_rows.packet_batch.blocks+0x5e4>
     df0:      	add	x0, x16, #0x14
     df4:      	ld1.s	{ v7 }[1], [x0]
     df8:      	tbz	w17, #0x6, 0xdac <_llm_rows.packet_batch.blocks+0x5e8>
     dfc:      	add	x0, x16, #0x18
     e00:      	ld1.s	{ v7 }[2], [x0]
     e04:      	tbz	w17, #0x7, 0xd44 <_llm_rows.packet_batch.blocks+0x580>
     e08:      	add	x16, x16, #0x1c
     e0c:      	ld1.s	{ v7 }[3], [x16]
     e10:      	b	0xd44 <_llm_rows.packet_batch.blocks+0x580>
     e14:      	add	x10, x10, x11
     e18:      	adrp	x11, 0x0 <ltmp0>
     e1c:      	ldr	d0, [x11]
     e20:      	shl.8b	v1, v20, #0x7
     e24:      	cmlt.8b	v1, v1, #0
     e28:      	and.8b	v0, v1, v0
     e2c:      	addv.8b	b0, v0
     e30:      	str	d0, [sp, #0x48]
     e34:      	fmov	w11, s0
     e38:      	movi.2d	v4, #0000000000000000
     e3c:      	movi.2d	v3, #0000000000000000
     e40:      	tbnz	w11, #0x0, 0x17a0 <_llm_rows.packet_batch.blocks+0xfdc>
     e44:      	mov	w15, #0xb61             ; =2913
     e48:      	movk	w15, #0x3ab6, lsl #16
     e4c:      	mov	w16, #0xaaab            ; =43691
     e50:      	movk	w16, #0x3d2a, lsl #16
     e54:      	mov	w17, #-0x3d300000       ; =-1026555904
     e58:      	tbnz	w11, #0x1, 0x17bc <_llm_rows.packet_batch.blocks+0xff8>
     e5c:      	tbnz	w11, #0x2, 0x17c8 <_llm_rows.packet_batch.blocks+0x1004>
     e60:      	tbnz	w11, #0x3, 0x17d4 <_llm_rows.packet_batch.blocks+0x1010>
     e64:      	tbnz	w11, #0x4, 0x17e0 <_llm_rows.packet_batch.blocks+0x101c>
     e68:      	tbnz	w11, #0x5, 0x17ec <_llm_rows.packet_batch.blocks+0x1028>
     e6c:      	tbnz	w11, #0x6, 0x17f8 <_llm_rows.packet_batch.blocks+0x1034>
     e70:      	mov	w14, #0xd01             ; =3329
     e74:      	movk	w14, #0x37d0, lsl #16
     e78:      	str	q19, [sp, #0xc0]
     e7c:      	str	q21, [sp, #0xa0]
     e80:      	tbz	w11, #0x7, 0xe8c <_llm_rows.packet_batch.blocks+0x6c8>
     e84:      	add	x10, x10, #0x1c
     e88:      	ld1.s	{ v3 }[3], [x10]
     e8c:      	mov	x11, #0x0               ; =0
     e90:      	add	x10, x24, x12
     e94:      	ldp	q0, q1, [x10]
     e98:      	zip2.8b	v2, v20, v0
     e9c:      	ushll.4s	v2, v2, #0x0
     ea0:      	shl.4s	v2, v2, #0x1f
     ea4:      	cmlt.4s	v2, v2, #0
     ea8:      	stp	q4, q3, [sp, #0x50]
     eac:      	bit.16b	v1, v3, v2
     eb0:      	str	q20, [sp, #0xe0]
     eb4:      	zip1.8b	v2, v20, v0
     eb8:      	ushll.4s	v2, v2, #0x0
     ebc:      	shl.4s	v2, v2, #0x1f
     ec0:      	cmlt.4s	v2, v2, #0
     ec4:      	bit.16b	v0, v4, v2
     ec8:      	stp	q0, q1, [x10]
     ecc:      	add	x10, x8, x13
     ed0:      	movi.2d	v3, #0000000000000000
     ed4:      	movi.2d	v19, #0000000000000000
     ed8:      	movi.2d	v20, #0000000000000000
     edc:      	movi.2d	v21, #0000000000000000
     ee0:      	stp	q17, q16, [sp, #0x120]
     ee4:      	stp	q28, q22, [sp, #0x100]
     ee8:      	b	0xf08 <_llm_rows.packet_batch.blocks+0x744>
     eec:      	add.2d	v19, v19, v17
     ef0:      	add.2d	v20, v20, v22
     ef4:      	add.2d	v21, v21, v16
     ef8:      	add.2d	v3, v3, v28
     efc:      	fmov	x11, d3
     f00:      	cmp	x11, #0xc0
     f04:      	b.ge	0x13ac <_llm_rows.packet_batch.blocks+0xbe8>
     f08:      	lsl	x11, x11, #5
     f0c:      	add	x12, x25, x11
     f10:      	ldr	q0, [x12]
     f14:      	and.16b	v22, v9, v0
     f18:      	dup.4s	v0, w1
     f1c:      	str	q0, [sp, #0x1c0]
     f20:      	fmul.4s	v0, v22, v0
     f24:      	fmul.4s	v0, v22, v0
     f28:      	fmul.4s	v0, v22, v0
     f2c:      	fadd.4s	v0, v22, v0
     f30:      	dup.4s	v1, w2
     f34:      	str	q1, [sp, #0x1a0]
     f38:      	fmul.4s	v0, v0, v1
     f3c:      	and.16b	v0, v9, v0
     f40:      	fabs.4s	v1, v0
     f44:      	fmov.4s	v25, #1.00000000
     f48:      	dup.4s	v5, w3
     f4c:      	dup.4s	v4, w4
     f50:      	fmul.4s	v2, v0, v0
     f54:      	stp	q5, q4, [sp, #0x1e0]
     f58:      	fmla.4s	v4, v2, v5
     f5c:      	dup.4s	v5, w5
     f60:      	str	q5, [sp, #0x1d0]
     f64:      	fmla.4s	v5, v2, v4
     f68:      	dup.4s	v4, w6
     f6c:      	str	q4, [sp, #0x1b0]
     f70:      	dup.4s	v11, w7
     f74:      	fmla.4s	v4, v2, v5
     f78:      	mov.16b	v5, v11
     f7c:      	fmla.4s	v5, v2, v4
     f80:      	dup.4s	v26, w26
     f84:      	mov.16b	v4, v26
     f88:      	fmla.4s	v4, v2, v5
     f8c:      	mov.16b	v5, v25
     f90:      	fmla.4s	v5, v2, v4
     f94:      	fmul.4s	v4, v1, v5
     f98:      	dup.4s	v6, w27
     f9c:      	dup.4s	v12, w30
     fa0:      	mov.16b	v5, v12
     fa4:      	str	q6, [sp, #0x190]
     fa8:      	fmla.4s	v5, v2, v6
     fac:      	dup.4s	v14, w14
     fb0:      	mov.16b	v6, v14
     fb4:      	fmla.4s	v6, v2, v5
     fb8:      	dup.4s	v15, w15
     fbc:      	mov.16b	v5, v15
     fc0:      	fmla.4s	v5, v2, v6
     fc4:      	dup.4s	v8, w16
     fc8:      	mov.16b	v6, v8
     fcc:      	fmla.4s	v6, v2, v5
     fd0:      	movi.4s	v5, #0x3f, lsl #24
     fd4:      	fmla.4s	v5, v2, v6
     fd8:      	mov.16b	v6, v25
     fdc:      	fmla.4s	v6, v2, v5
     fe0:      	fdiv.4s	v29, v4, v6
     fe4:      	fmov.4s	v2, #9.00000000
     fe8:      	str	q2, [sp, #0x180]
     fec:      	fcmge.4s	v31, v2, v1
     ff0:      	and.16b	v23, v31, v1
     ff4:      	dup.4s	v2, w17
     ff8:      	str	q2, [sp, #0x170]
     ffc:      	fcmge.4s	v2, v23, v2
    1000:      	mov	w13, #0x42c80000        ; =1120403456
    1004:      	dup.4s	v27, w13
    1008:      	fcmge.4s	v4, v27, v23
    100c:      	and.16b	v2, v2, v4
    1010:      	and.16b	v2, v2, v23
    1014:      	mov	w13, #0xaa3b            ; =43579
    1018:      	movk	w13, #0x3fb8, lsl #16
    101c:      	dup.4s	v4, w13
    1020:      	str	q4, [sp, #0x160]
    1024:      	fmul.4s	v4, v2, v4
    1028:      	movi.4s	v5, #0x4b, lsl #24
    102c:      	fadd.4s	v4, v4, v5
    1030:      	movi.4s	v5, #0xcb, lsl #24
    1034:      	fadd.4s	v4, v4, v5
    1038:      	fcvtzs.4s	v10, v4
    103c:      	scvtf.4s	v4, v10
    1040:      	mov	w13, #0x7200            ; =29184
    1044:      	movk	w13, #0xbf31, lsl #16
    1048:      	dup.4s	v5, w13
    104c:      	str	q5, [sp, #0x150]
    1050:      	fmul.4s	v6, v4, v5
    1054:      	fadd.4s	v2, v2, v6
    1058:      	mov	w13, #0xbe8e            ; =48782
    105c:      	movk	w13, #0xb5bf, lsl #16
    1060:      	dup.4s	v24, w13
    1064:      	fmul.4s	v6, v4, v24
    1068:      	mov	w13, #0x2bda            ; =11226
    106c:      	movk	w13, #0x3950, lsl #16
    1070:      	dup.4s	v4, w13
    1074:      	fadd.4s	v13, v2, v6
    1078:      	fmul.4s	v6, v13, v4
    107c:      	mov	w13, #0x96c9            ; =38601
    1080:      	movk	w13, #0x3ab6, lsl #16
    1084:      	dup.4s	v2, w13
    1088:      	fadd.4s	v6, v6, v2
    108c:      	fmul.4s	v6, v13, v6
    1090:      	mov	w13, #0x88a6            ; =34982
    1094:      	movk	w13, #0x3c08, lsl #16
    1098:      	dup.4s	v18, w13
    109c:      	fadd.4s	v6, v6, v18
    10a0:      	fmul.4s	v7, v13, v6
    10a4:      	mov	w13, #0xaa7a            ; =43642
    10a8:      	movk	w13, #0x3d2a, lsl #16
    10ac:      	dup.4s	v6, w13
    10b0:      	fadd.4s	v7, v7, v6
    10b4:      	fmul.4s	v7, v13, v7
    10b8:      	fadd.4s	v7, v7, v26
    10bc:      	fmul.4s	v7, v13, v7
    10c0:      	movi.4s	v16, #0x3f, lsl #24
    10c4:      	fadd.4s	v7, v7, v16
    10c8:      	fmul.4s	v28, v13, v13
    10cc:      	fmul.4s	v7, v28, v7
    10d0:      	fadd.4s	v7, v13, v7
    10d4:      	fadd.4s	v7, v7, v25
    10d8:      	movi.2d	v17, #0xffffffffffffffff
    10dc:      	add.4s	v28, v10, v17
    10e0:      	sshr.4s	v10, v28, #0x1
    10e4:      	shl.4s	v13, v10, #0x17
    10e8:      	add.4s	v13, v13, v25
    10ec:      	fmul.4s	v7, v7, v13
    10f0:      	sub.4s	v28, v28, v10
    10f4:      	shl.4s	v28, v28, #0x17
    10f8:      	add.4s	v28, v28, v25
    10fc:      	fmul.4s	v7, v7, v28
    1100:      	fcmgt.4s	v23, v23, v27
    1104:      	ldr	q17, [sp, #0x210]
    1108:      	bit.16b	v7, v17, v23
    110c:      	fmov.4s	v23, #0.25000000
    1110:      	fdiv.4s	v28, v23, v7
    1114:      	fsub.4s	v10, v7, v28
    1118:      	fadd.4s	v7, v7, v28
    111c:      	fdiv.4s	v7, v10, v7
    1120:      	bif.16b	v7, v25, v31
    1124:      	fcmge.4s	v1, v25, v1
    1128:      	bsl.16b	v1, v29, v7
    112c:      	mvni.4s	v7, #0x80, lsl #24
    1130:      	bif.16b	v1, v0, v7
    1134:      	fcmeq.4s	v0, v0, v0
    1138:      	fadd.4s	v1, v1, v25
    113c:      	ldr	q7, [sp, #0x200]
    1140:      	bif.16b	v1, v7, v0
    1144:      	ldr	q0, [x12, #0x10]
    1148:      	fmul.4s	v7, v22, v16
    114c:      	fmul.4s	v1, v7, v1
    1150:      	add	x12, x24, x11
    1154:      	ldp	q7, q22, [x12]
    1158:      	and.16b	v7, v9, v7
    115c:      	fadd.4s	v1, v7, v1
    1160:      	ldr	q5, [sp, #0x140]
    1164:      	fmov	w12, s5
    1168:      	add	x11, x10, x11
    116c:      	tbnz	w12, #0x0, 0x1348 <_llm_rows.packet_batch.blocks+0xb84>
    1170:      	and	w12, w12, #0xff
    1174:      	tbnz	w12, #0x1, 0x1354 <_llm_rows.packet_batch.blocks+0xb90>
    1178:      	tbnz	w12, #0x2, 0x1360 <_llm_rows.packet_batch.blocks+0xb9c>
    117c:      	mov.16b	v5, v9
    1180:      	tbz	w12, #0x3, 0x118c <_llm_rows.packet_batch.blocks+0x9c8>
    1184:      	add	x13, x11, #0xc
    1188:      	st1.s	{ v1 }[3], [x13]
    118c:      	and.16b	v0, v30, v0
    1190:      	ldp	q1, q31, [sp, #0x1c0]
    1194:      	fmul.4s	v1, v0, v1
    1198:      	fmul.4s	v1, v0, v1
    119c:      	fmul.4s	v1, v0, v1
    11a0:      	fadd.4s	v1, v0, v1
    11a4:      	ldr	q7, [sp, #0x1a0]
    11a8:      	fmul.4s	v1, v1, v7
    11ac:      	and.16b	v1, v30, v1
    11b0:      	fabs.4s	v29, v1
    11b4:      	fmul.4s	v7, v1, v1
    11b8:      	ldp	q16, q28, [sp, #0x1e0]
    11bc:      	fmla.4s	v28, v7, v16
    11c0:      	fmla.4s	v31, v7, v28
    11c4:      	ldr	q28, [sp, #0x1b0]
    11c8:      	fmla.4s	v28, v7, v31
    11cc:      	mov.16b	v31, v11
    11d0:      	fmla.4s	v31, v7, v28
    11d4:      	mov.16b	v28, v26
    11d8:      	fmla.4s	v28, v7, v31
    11dc:      	mov.16b	v31, v25
    11e0:      	fmla.4s	v31, v7, v28
    11e4:      	fmul.4s	v28, v29, v31
    11e8:      	mov.16b	v31, v12
    11ec:      	ldp	q16, q17, [sp, #0x180]
    11f0:      	fmla.4s	v31, v7, v17
    11f4:      	mov.16b	v10, v14
    11f8:      	fmla.4s	v10, v7, v31
    11fc:      	mov.16b	v31, v15
    1200:      	fmla.4s	v31, v7, v10
    1204:      	mov.16b	v10, v8
    1208:      	fmla.4s	v10, v7, v31
    120c:      	movi.4s	v31, #0x3f, lsl #24
    1210:      	fmla.4s	v31, v7, v10
    1214:      	mov.16b	v10, v25
    1218:      	fmla.4s	v10, v7, v31
    121c:      	fdiv.4s	v7, v28, v10
    1220:      	fcmge.4s	v28, v16, v29
    1224:      	and.16b	v31, v28, v29
    1228:      	ldp	q16, q17, [sp, #0x160]
    122c:      	fcmge.4s	v10, v31, v17
    1230:      	fcmge.4s	v13, v27, v31
    1234:      	and.16b	v10, v10, v13
    1238:      	and.16b	v10, v10, v31
    123c:      	fmul.4s	v13, v10, v16
    1240:      	movi.4s	v16, #0x4b, lsl #24
    1244:      	fadd.4s	v13, v13, v16
    1248:      	movi.4s	v16, #0xcb, lsl #24
    124c:      	fadd.4s	v13, v13, v16
    1250:      	fcvtzs.4s	v13, v13
    1254:      	scvtf.4s	v16, v13
    1258:      	mov.16b	v9, v30
    125c:      	ldr	q17, [sp, #0x150]
    1260:      	fmul.4s	v30, v16, v17
    1264:      	fadd.4s	v30, v10, v30
    1268:      	fmul.4s	v16, v16, v24
    126c:      	fadd.4s	v16, v30, v16
    1270:      	fmul.4s	v30, v16, v4
    1274:      	fadd.4s	v30, v30, v2
    1278:      	fmul.4s	v30, v16, v30
    127c:      	fadd.4s	v30, v30, v18
    1280:      	fmul.4s	v30, v16, v30
    1284:      	fadd.4s	v30, v30, v6
    1288:      	fmul.4s	v30, v16, v30
    128c:      	fadd.4s	v30, v30, v26
    1290:      	fmul.4s	v30, v16, v30
    1294:      	movi.4s	v17, #0x3f, lsl #24
    1298:      	fadd.4s	v30, v30, v17
    129c:      	fmul.4s	v10, v16, v16
    12a0:      	fmul.4s	v30, v10, v30
    12a4:      	fadd.4s	v16, v16, v30
    12a8:      	fadd.4s	v16, v16, v25
    12ac:      	movi.2d	v30, #0xffffffffffffffff
    12b0:      	add.4s	v30, v13, v30
    12b4:      	sshr.4s	v10, v30, #0x1
    12b8:      	shl.4s	v13, v10, #0x17
    12bc:      	add.4s	v13, v13, v25
    12c0:      	fmul.4s	v16, v16, v13
    12c4:      	sub.4s	v30, v30, v10
    12c8:      	shl.4s	v30, v30, #0x17
    12cc:      	add.4s	v30, v30, v25
    12d0:      	fmul.4s	v16, v16, v30
    12d4:      	fcmgt.4s	v30, v31, v27
    12d8:      	ldr	q31, [sp, #0x210]
    12dc:      	bit.16b	v16, v31, v30
    12e0:      	fdiv.4s	v30, v23, v16
    12e4:      	fsub.4s	v31, v16, v30
    12e8:      	fadd.4s	v16, v16, v30
    12ec:      	mov.16b	v30, v9
    12f0:      	fdiv.4s	v16, v31, v16
    12f4:      	bif.16b	v16, v25, v28
    12f8:      	fcmge.4s	v28, v25, v29
    12fc:      	bif.16b	v7, v16, v28
    1300:      	mvni.4s	v16, #0x80, lsl #24
    1304:      	bif.16b	v7, v1, v16
    1308:      	fcmeq.4s	v1, v1, v1
    130c:      	fadd.4s	v7, v7, v25
    1310:      	ldr	q16, [sp, #0x200]
    1314:      	bsl.16b	v1, v7, v16
    1318:      	fmul.4s	v0, v0, v17
    131c:      	fmul.4s	v0, v0, v1
    1320:      	and.16b	v1, v9, v22
    1324:      	fadd.4s	v0, v1, v0
    1328:      	tbnz	w12, #0x4, 0x1374 <_llm_rows.packet_batch.blocks+0xbb0>
    132c:      	mov.16b	v9, v5
    1330:      	ldp	q17, q16, [sp, #0x120]
    1334:      	ldp	q28, q22, [sp, #0x100]
    1338:      	tbnz	w12, #0x5, 0x1388 <_llm_rows.packet_batch.blocks+0xbc4>
    133c:      	tbnz	w12, #0x6, 0x1394 <_llm_rows.packet_batch.blocks+0xbd0>
    1340:      	tbz	w12, #0x7, 0xeec <_llm_rows.packet_batch.blocks+0x728>
    1344:      	b	0x13a0 <_llm_rows.packet_batch.blocks+0xbdc>
    1348:      	str	s1, [x11]
    134c:      	and	w12, w12, #0xff
    1350:      	tbz	w12, #0x1, 0x1178 <_llm_rows.packet_batch.blocks+0x9b4>
    1354:      	add	x13, x11, #0x4
    1358:      	st1.s	{ v1 }[1], [x13]
    135c:      	tbz	w12, #0x2, 0x117c <_llm_rows.packet_batch.blocks+0x9b8>
    1360:      	add	x13, x11, #0x8
    1364:      	st1.s	{ v1 }[2], [x13]
    1368:      	mov.16b	v5, v9
    136c:      	tbnz	w12, #0x3, 0x1184 <_llm_rows.packet_batch.blocks+0x9c0>
    1370:      	b	0x118c <_llm_rows.packet_batch.blocks+0x9c8>
    1374:      	str	s0, [x11, #0x10]
    1378:      	mov.16b	v9, v5
    137c:      	ldp	q17, q16, [sp, #0x120]
    1380:      	ldp	q28, q22, [sp, #0x100]
    1384:      	tbz	w12, #0x5, 0x133c <_llm_rows.packet_batch.blocks+0xb78>
    1388:      	add	x13, x11, #0x14
    138c:      	st1.s	{ v0 }[1], [x13]
    1390:      	tbz	w12, #0x6, 0x1340 <_llm_rows.packet_batch.blocks+0xb7c>
    1394:      	add	x13, x11, #0x18
    1398:      	st1.s	{ v0 }[2], [x13]
    139c:      	tbz	w12, #0x7, 0xeec <_llm_rows.packet_batch.blocks+0x728>
    13a0:      	add	x11, x11, #0x1c
    13a4:      	st1.s	{ v0 }[3], [x11]
    13a8:      	b	0xeec <_llm_rows.packet_batch.blocks+0x728>
    13ac:      	ldr	q5, [sp, #0xa0]
    13b0:      	ldr	q0, [sp, #0x1c0]
    13b4:      	fmul.4s	v0, v5, v0
    13b8:      	fmul.4s	v0, v5, v0
    13bc:      	fmul.4s	v0, v5, v0
    13c0:      	fadd.4s	v0, v5, v0
    13c4:      	ldr	q1, [sp, #0x1a0]
    13c8:      	fmul.4s	v0, v0, v1
    13cc:      	ldr	q1, [sp, #0xe0]
    13d0:      	zip1.8b	v1, v1, v0
    13d4:      	ushll.4s	v1, v1, #0x0
    13d8:      	shl.4s	v1, v1, #0x1f
    13dc:      	cmlt.4s	v1, v1, #0
    13e0:      	and.16b	v0, v1, v0
    13e4:      	fabs.4s	v1, v0
    13e8:      	fmul.4s	v3, v0, v0
    13ec:      	ldp	q16, q7, [sp, #0x1e0]
    13f0:      	fmla.4s	v7, v3, v16
    13f4:      	ldr	q16, [sp, #0x1d0]
    13f8:      	fmla.4s	v16, v3, v7
    13fc:      	ldr	q7, [sp, #0x1b0]
    1400:      	fmla.4s	v7, v3, v16
    1404:      	mov.16b	v16, v11
    1408:      	fmla.4s	v16, v3, v7
    140c:      	mov.16b	v7, v26
    1410:      	fmla.4s	v7, v3, v16
    1414:      	mov.16b	v16, v25
    1418:      	fmla.4s	v16, v3, v7
    141c:      	fmul.4s	v7, v1, v16
    1420:      	mov.16b	v16, v12
    1424:      	ldr	q17, [sp, #0x190]
    1428:      	fmla.4s	v16, v3, v17
    142c:      	mov.16b	v19, v14
    1430:      	fmla.4s	v19, v3, v16
    1434:      	mov.16b	v16, v15
    1438:      	fmla.4s	v16, v3, v19
    143c:      	mov.16b	v19, v8
    1440:      	fmla.4s	v19, v3, v16
    1444:      	movi.4s	v16, #0x3f, lsl #24
    1448:      	fmla.4s	v16, v3, v19
    144c:      	mov.16b	v19, v25
    1450:      	fmla.4s	v19, v3, v16
    1454:      	fdiv.4s	v3, v7, v19
    1458:      	ldp	q17, q7, [sp, #0x170]
    145c:      	fcmge.4s	v7, v7, v1
    1460:      	and.16b	v16, v7, v1
    1464:      	fcmge.4s	v19, v16, v17
    1468:      	fcmge.4s	v20, v27, v16
    146c:      	and.16b	v19, v19, v20
    1470:      	and.16b	v19, v19, v16
    1474:      	ldr	q17, [sp, #0x160]
    1478:      	fmul.4s	v20, v19, v17
    147c:      	movi.4s	v17, #0x4b, lsl #24
    1480:      	fadd.4s	v20, v20, v17
    1484:      	movi.4s	v17, #0xcb, lsl #24
    1488:      	fadd.4s	v20, v20, v17
    148c:      	fcvtzs.4s	v20, v20
    1490:      	scvtf.4s	v21, v20
    1494:      	ldr	q17, [sp, #0x150]
    1498:      	fmul.4s	v22, v21, v17
    149c:      	fadd.4s	v19, v19, v22
    14a0:      	fmul.4s	v21, v21, v24
    14a4:      	fadd.4s	v19, v19, v21
    14a8:      	fmul.4s	v21, v19, v4
    14ac:      	fadd.4s	v21, v21, v2
    14b0:      	fmul.4s	v21, v19, v21
    14b4:      	fadd.4s	v21, v21, v18
    14b8:      	fmul.4s	v21, v19, v21
    14bc:      	fadd.4s	v21, v21, v6
    14c0:      	fmul.4s	v21, v19, v21
    14c4:      	fadd.4s	v21, v21, v26
    14c8:      	fmul.4s	v21, v19, v21
    14cc:      	movi.4s	v17, #0x3f, lsl #24
    14d0:      	fadd.4s	v21, v21, v17
    14d4:      	fmul.4s	v22, v19, v19
    14d8:      	fmul.4s	v21, v22, v21
    14dc:      	fadd.4s	v19, v19, v21
    14e0:      	fadd.4s	v19, v19, v25
    14e4:      	movi.2d	v21, #0xffffffffffffffff
    14e8:      	add.4s	v20, v20, v21
    14ec:      	sshr.4s	v21, v20, #0x1
    14f0:      	shl.4s	v22, v21, #0x17
    14f4:      	add.4s	v22, v22, v25
    14f8:      	fmul.4s	v19, v19, v22
    14fc:      	sub.4s	v20, v20, v21
    1500:      	shl.4s	v20, v20, #0x17
    1504:      	add.4s	v20, v20, v25
    1508:      	fmul.4s	v19, v19, v20
    150c:      	fcmgt.4s	v16, v16, v27
    1510:      	ldr	q20, [sp, #0x210]
    1514:      	bsl.16b	v16, v20, v19
    1518:      	fdiv.4s	v19, v23, v16
    151c:      	fsub.4s	v20, v16, v19
    1520:      	fadd.4s	v16, v16, v19
    1524:      	fdiv.4s	v16, v20, v16
    1528:      	bsl.16b	v7, v16, v25
    152c:      	fcmge.4s	v1, v25, v1
    1530:      	bsl.16b	v1, v3, v7
    1534:      	ldr	d3, [sp, #0x48]
    1538:      	fmov	w10, s3
    153c:      	mvni.4s	v3, #0x80, lsl #24
    1540:      	bif.16b	v1, v0, v3
    1544:      	fcmeq.4s	v0, v0, v0
    1548:      	fadd.4s	v1, v1, v25
    154c:      	ldr	q3, [sp, #0x200]
    1550:      	bsl.16b	v0, v1, v3
    1554:      	fmul.4s	v1, v5, v17
    1558:      	fmul.4s	v0, v1, v0
    155c:      	ldr	q1, [sp, #0x50]
    1560:      	fadd.4s	v0, v0, v1
    1564:      	ldr	q3, [sp, #0xb0]
    1568:      	ldp	q5, q7, [sp, #0x80]
    156c:      	stp	q3, q5, [sp, #0x220]
    1570:      	ldr	q1, [sp, #0x70]
    1574:      	stp	q7, q1, [sp, #0x240]
    1578:      	and	x11, x9, #0x7
    157c:      	add	x12, sp, #0x220
    1580:      	ldr	x11, [x12, x11, lsl #3]
    1584:      	sub	x9, x11, x9
    1588:      	add	x8, x8, x9, lsl #2
    158c:      	tbnz	w10, #0x0, 0x1818 <_llm_rows.packet_batch.blocks+0x1054>
    1590:      	ldr	q21, [sp, #0xc0]
    1594:      	tbnz	w10, #0x1, 0x1824 <_llm_rows.packet_batch.blocks+0x1060>
    1598:      	ldr	q1, [sp, #0xe0]
    159c:      	tbnz	w10, #0x2, 0x1834 <_llm_rows.packet_batch.blocks+0x1070>
    15a0:      	tbz	w10, #0x3, 0x15ac <_llm_rows.packet_batch.blocks+0xde8>
    15a4:      	add	x9, x8, #0xc
    15a8:      	st1.s	{ v0 }[3], [x9]
    15ac:      	ldr	q0, [sp, #0x1c0]
    15b0:      	fmul.4s	v0, v21, v0
    15b4:      	fmul.4s	v0, v21, v0
    15b8:      	fmul.4s	v0, v21, v0
    15bc:      	fadd.4s	v0, v21, v0
    15c0:      	ldr	q3, [sp, #0x1a0]
    15c4:      	fmul.4s	v0, v0, v3
    15c8:      	zip2.8b	v1, v1, v0
    15cc:      	ushll.4s	v1, v1, #0x0
    15d0:      	shl.4s	v1, v1, #0x1f
    15d4:      	cmlt.4s	v1, v1, #0
    15d8:      	and.16b	v0, v1, v0
    15dc:      	fmul.4s	v1, v0, v0
    15e0:      	ldp	q5, q3, [sp, #0x1e0]
    15e4:      	fmla.4s	v3, v1, v5
    15e8:      	ldr	q5, [sp, #0x1d0]
    15ec:      	fmla.4s	v5, v1, v3
    15f0:      	ldr	q3, [sp, #0x1b0]
    15f4:      	fmla.4s	v3, v1, v5
    15f8:      	fmla.4s	v11, v1, v3
    15fc:      	mov.16b	v3, v26
    1600:      	fmla.4s	v3, v1, v11
    1604:      	mov.16b	v7, v25
    1608:      	fmla.4s	v7, v1, v3
    160c:      	ldp	q5, q3, [sp, #0x180]
    1610:      	fmla.4s	v12, v1, v3
    1614:      	fmla.4s	v14, v1, v12
    1618:      	fmla.4s	v15, v1, v14
    161c:      	fmla.4s	v8, v1, v15
    1620:      	movi.4s	v3, #0x3f, lsl #24
    1624:      	fmla.4s	v3, v1, v8
    1628:      	mov.16b	v16, v25
    162c:      	fmla.4s	v16, v1, v3
    1630:      	fabs.4s	v1, v0
    1634:      	fmul.4s	v3, v1, v7
    1638:      	fdiv.4s	v3, v3, v16
    163c:      	fcmge.4s	v7, v5, v1
    1640:      	and.16b	v16, v7, v1
    1644:      	ldr	q5, [sp, #0x170]
    1648:      	fcmge.4s	v19, v16, v5
    164c:      	fcmge.4s	v20, v27, v16
    1650:      	and.16b	v19, v19, v20
    1654:      	and.16b	v19, v19, v16
    1658:      	ldr	q5, [sp, #0x160]
    165c:      	fmul.4s	v17, v19, v5
    1660:      	movi.4s	v20, #0x4b, lsl #24
    1664:      	fadd.4s	v17, v17, v20
    1668:      	movi.4s	v20, #0xcb, lsl #24
    166c:      	fadd.4s	v17, v17, v20
    1670:      	fcvtzs.4s	v17, v17
    1674:      	scvtf.4s	v20, v17
    1678:      	ldr	q5, [sp, #0x150]
    167c:      	fmul.4s	v5, v20, v5
    1680:      	fadd.4s	v5, v19, v5
    1684:      	fmul.4s	v19, v20, v24
    1688:      	fadd.4s	v5, v5, v19
    168c:      	fmul.4s	v4, v5, v4
    1690:      	fadd.4s	v2, v4, v2
    1694:      	fmul.4s	v2, v5, v2
    1698:      	fadd.4s	v2, v2, v18
    169c:      	fmul.4s	v2, v5, v2
    16a0:      	fadd.4s	v2, v2, v6
    16a4:      	fmul.4s	v2, v5, v2
    16a8:      	fadd.4s	v2, v2, v26
    16ac:      	fmul.4s	v2, v5, v2
    16b0:      	movi.4s	v18, #0x3f, lsl #24
    16b4:      	fadd.4s	v2, v2, v18
    16b8:      	fmul.4s	v4, v5, v5
    16bc:      	fmul.4s	v2, v4, v2
    16c0:      	fadd.4s	v2, v5, v2
    16c4:      	fadd.4s	v2, v2, v25
    16c8:      	movi.2d	v4, #0xffffffffffffffff
    16cc:      	add.4s	v4, v17, v4
    16d0:      	sshr.4s	v5, v4, #0x1
    16d4:      	shl.4s	v6, v5, #0x17
    16d8:      	add.4s	v6, v6, v25
    16dc:      	fmul.4s	v2, v2, v6
    16e0:      	sub.4s	v4, v4, v5
    16e4:      	shl.4s	v4, v4, #0x17
    16e8:      	add.4s	v4, v4, v25
    16ec:      	fmul.4s	v2, v2, v4
    16f0:      	fcmgt.4s	v4, v16, v27
    16f4:      	ldr	q5, [sp, #0x210]
    16f8:      	bit.16b	v2, v5, v4
    16fc:      	fdiv.4s	v4, v23, v2
    1700:      	fsub.4s	v5, v2, v4
    1704:      	fadd.4s	v2, v2, v4
    1708:      	fdiv.4s	v2, v5, v2
    170c:      	bif.16b	v2, v25, v7
    1710:      	fcmge.4s	v1, v25, v1
    1714:      	bsl.16b	v1, v3, v2
    1718:      	mvni.4s	v2, #0x80, lsl #24
    171c:      	bif.16b	v1, v0, v2
    1720:      	fadd.4s	v1, v1, v25
    1724:      	fcmeq.4s	v0, v0, v0
    1728:      	ldr	q2, [sp, #0x200]
    172c:      	bsl.16b	v0, v1, v2
    1730:      	fmul.4s	v1, v21, v18
    1734:      	fmul.4s	v0, v1, v0
    1738:      	ldr	q1, [sp, #0x60]
    173c:      	fadd.4s	v0, v0, v1
    1740:      	tbnz	w10, #0x4, 0x1844 <_llm_rows.packet_batch.blocks+0x1080>
    1744:      	tbnz	w10, #0x5, 0x184c <_llm_rows.packet_batch.blocks+0x1088>
    1748:      	tbnz	w10, #0x6, 0x1858 <_llm_rows.packet_batch.blocks+0x1094>
    174c:      	tbz	w10, #0x7, 0x86c <_llm_rows.packet_batch.blocks+0xa8>
    1750:      	b	0x1864 <_llm_rows.packet_batch.blocks+0x10a0>
    1754:      	add	x14, x12, #0x4
    1758:      	ld1.s	{ v21 }[1], [x14]
    175c:      	tbz	w13, #0x2, 0xbe8 <_llm_rows.packet_batch.blocks+0x424>
    1760:      	add	x14, x12, #0x8
    1764:      	ld1.s	{ v21 }[2], [x14]
    1768:      	tbz	w13, #0x3, 0xbec <_llm_rows.packet_batch.blocks+0x428>
    176c:      	add	x14, x12, #0xc
    1770:      	ld1.s	{ v21 }[3], [x14]
    1774:      	tbz	w13, #0x4, 0xbf0 <_llm_rows.packet_batch.blocks+0x42c>
    1778:      	add	x14, x12, #0x10
    177c:      	ld1.s	{ v19 }[0], [x14]
    1780:      	tbz	w13, #0x5, 0xbf4 <_llm_rows.packet_batch.blocks+0x430>
    1784:      	add	x14, x12, #0x14
    1788:      	ld1.s	{ v19 }[1], [x14]
    178c:      	tbz	w13, #0x6, 0xbf8 <_llm_rows.packet_batch.blocks+0x434>
    1790:      	add	x14, x12, #0x18
    1794:      	ld1.s	{ v19 }[2], [x14]
    1798:      	tbnz	w13, #0x7, 0xbfc <_llm_rows.packet_batch.blocks+0x438>
    179c:      	b	0xc04 <_llm_rows.packet_batch.blocks+0x440>
    17a0:      	ldr	s4, [x10]
    17a4:      	mov	w15, #0xb61             ; =2913
    17a8:      	movk	w15, #0x3ab6, lsl #16
    17ac:      	mov	w16, #0xaaab            ; =43691
    17b0:      	movk	w16, #0x3d2a, lsl #16
    17b4:      	mov	w17, #-0x3d300000       ; =-1026555904
    17b8:      	tbz	w11, #0x1, 0xe5c <_llm_rows.packet_batch.blocks+0x698>
    17bc:      	add	x14, x10, #0x4
    17c0:      	ld1.s	{ v4 }[1], [x14]
    17c4:      	tbz	w11, #0x2, 0xe60 <_llm_rows.packet_batch.blocks+0x69c>
    17c8:      	add	x14, x10, #0x8
    17cc:      	ld1.s	{ v4 }[2], [x14]
    17d0:      	tbz	w11, #0x3, 0xe64 <_llm_rows.packet_batch.blocks+0x6a0>
    17d4:      	add	x14, x10, #0xc
    17d8:      	ld1.s	{ v4 }[3], [x14]
    17dc:      	tbz	w11, #0x4, 0xe68 <_llm_rows.packet_batch.blocks+0x6a4>
    17e0:      	add	x14, x10, #0x10
    17e4:      	ld1.s	{ v3 }[0], [x14]
    17e8:      	tbz	w11, #0x5, 0xe6c <_llm_rows.packet_batch.blocks+0x6a8>
    17ec:      	add	x14, x10, #0x14
    17f0:      	ld1.s	{ v3 }[1], [x14]
    17f4:      	tbz	w11, #0x6, 0xe70 <_llm_rows.packet_batch.blocks+0x6ac>
    17f8:      	add	x14, x10, #0x18
    17fc:      	ld1.s	{ v3 }[2], [x14]
    1800:      	mov	w14, #0xd01             ; =3329
    1804:      	movk	w14, #0x37d0, lsl #16
    1808:      	str	q19, [sp, #0xc0]
    180c:      	str	q21, [sp, #0xa0]
    1810:      	tbnz	w11, #0x7, 0xe84 <_llm_rows.packet_batch.blocks+0x6c0>
    1814:      	b	0xe8c <_llm_rows.packet_batch.blocks+0x6c8>
    1818:      	str	s0, [x8]
    181c:      	ldr	q21, [sp, #0xc0]
    1820:      	tbz	w10, #0x1, 0x1598 <_llm_rows.packet_batch.blocks+0xdd4>
    1824:      	add	x9, x8, #0x4
    1828:      	st1.s	{ v0 }[1], [x9]
    182c:      	ldr	q1, [sp, #0xe0]
    1830:      	tbz	w10, #0x2, 0x15a0 <_llm_rows.packet_batch.blocks+0xddc>
    1834:      	add	x9, x8, #0x8
    1838:      	st1.s	{ v0 }[2], [x9]
    183c:      	tbnz	w10, #0x3, 0x15a4 <_llm_rows.packet_batch.blocks+0xde0>
    1840:      	b	0x15ac <_llm_rows.packet_batch.blocks+0xde8>
    1844:      	str	s0, [x8, #0x10]
    1848:      	tbz	w10, #0x5, 0x1748 <_llm_rows.packet_batch.blocks+0xf84>
    184c:      	add	x9, x8, #0x14
    1850:      	st1.s	{ v0 }[1], [x9]
    1854:      	tbz	w10, #0x6, 0x174c <_llm_rows.packet_batch.blocks+0xf88>
    1858:      	add	x9, x8, #0x18
    185c:      	st1.s	{ v0 }[2], [x9]
    1860:      	tbz	w10, #0x7, 0x86c <_llm_rows.packet_batch.blocks+0xa8>
    1864:      	add	x8, x8, #0x1c
    1868:      	st1.s	{ v0 }[3], [x8]
    186c:      	b	0x86c <_llm_rows.packet_batch.blocks+0xa8>
    1870:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
    1874:      	add	sp, sp, #0x340
    1878:      	ldp	x29, x30, [sp, #0x90]
    187c:      	ldp	x20, x19, [sp, #0x80]
    1880:      	ldp	x22, x21, [sp, #0x70]
    1884:      	ldp	x24, x23, [sp, #0x60]
    1888:      	ldp	x26, x25, [sp, #0x50]
    188c:      	ldp	x28, x27, [sp, #0x40]
    1890:      	ldp	d9, d8, [sp, #0x30]
    1894:      	ldp	d11, d10, [sp, #0x20]
    1898:      	ldp	d13, d12, [sp, #0x10]
    189c:      	ldp	d15, d14, [sp], #0xa0
    18a0:      	ret


/private/tmp/luisa-expression-fusion.qXgTbC/capture/swiglu-129x768/off/object/tile_xir_w8_23421_1788930268402731_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d9, d8, [sp, #-0x70]!
       4:      	stp	x28, x27, [sp, #0x10]
       8:      	stp	x26, x25, [sp, #0x20]
       c:      	stp	x24, x23, [sp, #0x30]
      10:      	stp	x22, x21, [sp, #0x40]
      14:      	stp	x20, x19, [sp, #0x50]
      18:      	stp	x29, x30, [sp, #0x60]
      1c:      	sub	sp, sp, #0x1, lsl #12   ; =0x1000
      20:      	sub	sp, sp, #0x930
      24:      	str	x0, [sp, #0x20]
      28:      	cbz	w3, 0x102c <ltmp0+0x102c>
      2c:      	mov	x20, x3
      30:      	mov	w22, #0x0               ; =0
      34:      	ldp	w3, w8, [x2, #0x2c]
      38:      	str	w8, [sp, #0x38]
      3c:      	add	x27, sp, #0xd30
      40:      	add	x28, sp, #0x130
      44:      	mov	w8, #0x42d00000         ; =1120927744
      48:      	dup.4s	v1, w8
      4c:      	mov	w8, #-0x3d380000        ; =-1027080192
      50:      	dup.4s	v0, w8
      54:      	stp	q0, q1, [sp, #0x100]
      58:      	mov	w8, #0xaa3b             ; =43579
      5c:      	movk	w8, #0x3fb8, lsl #16
      60:      	dup.4s	v20, w8
      64:      	movi.4s	v21, #0x4b, lsl #24
      68:      	mvni.4s	v22, #0x80, lsl #24
      6c:      	mov	w8, #0x7200             ; =29184
      70:      	movk	w8, #0xbf31, lsl #16
      74:      	dup.4s	v23, w8
      78:      	mov	w8, #0xbe8e             ; =48782
      7c:      	movk	w8, #0xb5bf, lsl #16
      80:      	dup.4s	v24, w8
      84:      	mov	w8, #0x2bda             ; =11226
      88:      	movk	w8, #0x3950, lsl #16
      8c:      	dup.4s	v25, w8
      90:      	mov	w8, #0x96c9             ; =38601
      94:      	movk	w8, #0x3ab6, lsl #16
      98:      	dup.4s	v26, w8
      9c:      	mov	w8, #0x88a6             ; =34982
      a0:      	movk	w8, #0x3c08, lsl #16
      a4:      	dup.4s	v27, w8
      a8:      	mov	w8, #0xaa7a             ; =43642
      ac:      	movk	w8, #0x3d2a, lsl #16
      b0:      	dup.4s	v28, w8
      b4:      	ldp	w8, w9, [x2]
      b8:      	mov	w11, #0xaaab            ; =43691
      bc:      	movk	w11, #0x3e2a, lsl #16
      c0:      	movi.4s	v29, #0x3f, lsl #24
      c4:      	fmov.4s	v30, #1.00000000
      c8:      	mvni.4s	v0, #0x7f, msl #16
      cc:      	ldp	w10, w12, [x2, #0x8]
      d0:      	str	x2, [sp, #0x10]
      d4:      	str	x12, [sp, #0x30]
      d8:      	fneg.4s	v31, v0
      dc:      	dup.4s	v8, w11
      e0:      	mvni.4s	v0, #0x3f, msl #16
      e4:      	fneg.4s	v9, v0
      e8:      	stp	q23, q20, [sp, #0xe0]
      ec:      	stp	q25, q24, [sp, #0xc0]
      f0:      	stp	q27, q26, [sp, #0xa0]
      f4:      	stp	q30, q28, [sp, #0x80]
      f8:      	stp	q8, q31, [sp, #0x60]
      fc:      	str	q9, [sp, #0x50]
     100:      	str	w20, [sp, #0x1c]
     104:      	str	w3, [sp, #0x3c]
     108:      	b	0x148 <ltmp0+0x148>
     10c:      	add	w8, w1, #0x1
     110:      	cmp	w8, w3
     114:      	cset	w9, eq
     118:      	csinc	w8, wzr, w1, eq
     11c:      	ldp	w13, w12, [sp, #0x40]
     120:      	cinc	w10, w13, eq
     124:      	ldr	w11, [sp, #0x38]
     128:      	cmp	w10, w11
     12c:      	cset	w11, eq
     130:      	ands	w11, w9, w11
     134:      	csel	w9, wzr, w10, ne
     138:      	add	w10, w12, w11
     13c:      	add	w22, w22, #0x1
     140:      	cmp	w22, w20
     144:      	b.eq	0x1018 <ltmp0+0x1018>
     148:      	str	w10, [sp, #0x44]
     14c:      	mov	x13, x9
     150:      	mov	x14, x8
     154:      	ubfiz	x8, x8, #5, #32
     158:      	ldr	x12, [sp, #0x30]
     15c:      	cmp	x8, x12
     160:      	csel	x9, x8, xzr, ls
     164:      	subs	x10, x12, x9
     168:      	cmp	x10, #0x20
     16c:      	mov	w11, #0x20              ; =32
     170:      	csel	x10, x10, x11, lo
     174:      	cmp	x12, x9
     178:      	ccmp	x8, x12, #0x2, hi
     17c:      	csel	x23, x10, xzr, ls
     180:      	cmp	x23, #0x20
     184:      	str	w13, [sp, #0x40]
     188:      	str	x14, [sp, #0x48]
     18c:      	b.lo	0x97c <ltmp0+0x97c>
     190:      	ldr	x8, [sp, #0x20]
     194:      	ldr	x25, [x8]
     198:      	ldr	x26, [x8, #0x10]
     19c:      	ldr	x21, [x8, #0x30]
     1a0:      	ubfiz	w23, w14, #2, #27
     1a4:      	mov	w19, #0xc00             ; =3072
     1a8:      	umaddl	x1, w23, w19, x25
     1ac:      	add	x0, sp, #0xd30
     1b0:      	mov	w2, #0xc00              ; =3072
     1b4:      	bl	0x1b4 <ltmp0+0x1b4>
     1b8:      	umaddl	x1, w23, w19, x26
     1bc:      	add	x0, sp, #0x130
     1c0:      	mov	w2, #0xc00              ; =3072
     1c4:      	bl	0x1c4 <ltmp0+0x1c4>
     1c8:      	ldp	q9, q8, [sp, #0x50]
     1cc:      	ldp	q31, q30, [sp, #0x70]
     1d0:      	movi.4s	v29, #0x3f, lsl #24
     1d4:      	ldp	q28, q27, [sp, #0x90]
     1d8:      	ldp	q26, q25, [sp, #0xb0]
     1dc:      	ldp	q24, q23, [sp, #0xd0]
     1e0:      	mvni.4s	v22, #0x80, lsl #24
     1e4:      	movi.4s	v21, #0x4b, lsl #24
     1e8:      	ldp	q20, q19, [sp, #0xf0]
     1ec:      	ldr	q18, [sp, #0x110]
     1f0:      	mov	x8, #0x0                ; =0
     1f4:      	umaddl	x9, w23, w19, x21
     1f8:      	add	x10, x27, x8
     1fc:      	ldp	q0, q1, [x10]
     200:      	fneg.4s	v2, v1
     204:      	fneg.4s	v3, v0
     208:      	fcmge.4s	v4, v18, v0
     20c:      	fcmge.4s	v5, v18, v1
     210:      	fcmge.4s	v6, v0, v19
     214:      	fcmge.4s	v7, v1, v19
     218:      	and.16b	v5, v5, v7
     21c:      	and.16b	v4, v4, v6
     220:      	and.16b	v3, v4, v3
     224:      	and.16b	v2, v5, v2
     228:      	fmul.4s	v4, v2, v20
     22c:      	fmul.4s	v5, v3, v20
     230:      	mov.16b	v6, v22
     234:      	bsl.16b	v6, v21, v5
     238:      	mov.16b	v7, v22
     23c:      	bsl.16b	v7, v21, v4
     240:      	fadd.4s	v4, v4, v7
     244:      	fadd.4s	v5, v5, v6
     248:      	fsub.4s	v5, v5, v6
     24c:      	fsub.4s	v4, v4, v7
     250:      	fcvtzs.4s	v4, v4
     254:      	fcvtzs.4s	v5, v5
     258:      	scvtf.4s	v6, v5
     25c:      	scvtf.4s	v7, v4
     260:      	fmul.4s	v16, v7, v23
     264:      	fmul.4s	v17, v6, v23
     268:      	fadd.4s	v3, v3, v17
     26c:      	fadd.4s	v2, v2, v16
     270:      	fmul.4s	v6, v6, v24
     274:      	fmul.4s	v7, v7, v24
     278:      	fadd.4s	v2, v2, v7
     27c:      	fadd.4s	v3, v3, v6
     280:      	fmul.4s	v6, v3, v25
     284:      	fmul.4s	v7, v2, v25
     288:      	fadd.4s	v7, v7, v26
     28c:      	fadd.4s	v6, v6, v26
     290:      	fmul.4s	v6, v3, v6
     294:      	fmul.4s	v7, v2, v7
     298:      	fadd.4s	v7, v7, v27
     29c:      	fadd.4s	v6, v6, v27
     2a0:      	fmul.4s	v6, v3, v6
     2a4:      	fmul.4s	v7, v2, v7
     2a8:      	fadd.4s	v7, v7, v28
     2ac:      	fadd.4s	v6, v6, v28
     2b0:      	fmul.4s	v6, v3, v6
     2b4:      	fmul.4s	v7, v2, v7
     2b8:      	fadd.4s	v7, v7, v8
     2bc:      	fadd.4s	v6, v6, v8
     2c0:      	fmul.4s	v6, v3, v6
     2c4:      	fmul.4s	v7, v2, v7
     2c8:      	fadd.4s	v7, v7, v29
     2cc:      	fadd.4s	v6, v6, v29
     2d0:      	fmul.4s	v16, v2, v2
     2d4:      	fmul.4s	v17, v3, v3
     2d8:      	fmul.4s	v6, v17, v6
     2dc:      	fmul.4s	v7, v16, v7
     2e0:      	fadd.4s	v2, v2, v7
     2e4:      	fadd.4s	v3, v3, v6
     2e8:      	sshr.4s	v6, v5, #0x1
     2ec:      	fadd.4s	v3, v3, v30
     2f0:      	sshr.4s	v7, v4, #0x1
     2f4:      	shl.4s	v16, v7, #0x17
     2f8:      	shl.4s	v17, v6, #0x17
     2fc:      	add.4s	v17, v17, v30
     300:      	add.4s	v16, v16, v30
     304:      	fadd.4s	v2, v2, v30
     308:      	fmul.4s	v2, v2, v16
     30c:      	sub.4s	v4, v4, v7
     310:      	sub.4s	v5, v5, v6
     314:      	shl.4s	v5, v5, #0x17
     318:      	shl.4s	v4, v4, #0x17
     31c:      	fmul.4s	v3, v3, v17
     320:      	add.4s	v4, v4, v30
     324:      	add.4s	v5, v5, v30
     328:      	fmul.4s	v3, v3, v5
     32c:      	fmul.4s	v2, v2, v4
     330:      	fcmgt.4s	v4, v1, v18
     334:      	fcmgt.4s	v5, v0, v18
     338:      	fcmgt.4s	v6, v19, v0
     33c:      	fcmgt.4s	v7, v19, v1
     340:      	fcmeq.4s	v16, v1, v1
     344:      	fadd.4s	v2, v2, v30
     348:      	fadd.4s	v3, v3, v30
     34c:      	fcmeq.4s	v17, v0, v0
     350:      	bit.16b	v3, v30, v5
     354:      	bit.16b	v2, v30, v4
     358:      	bit.16b	v2, v31, v7
     35c:      	bit.16b	v3, v31, v6
     360:      	bif.16b	v3, v9, v17
     364:      	bif.16b	v2, v9, v16
     368:      	fdiv.4s	v1, v1, v2
     36c:      	fdiv.4s	v0, v0, v3
     370:      	add	x10, x28, x8
     374:      	ldp	q3, q2, [x10]
     378:      	fmul.4s	v0, v3, v0
     37c:      	fmul.4s	v1, v2, v1
     380:      	add	x10, x9, x8
     384:      	stp	q0, q1, [x10]
     388:      	add	x8, x8, #0x20
     38c:      	cmp	x8, #0xc00
     390:      	b.ne	0x1f8 <ltmp0+0x1f8>
     394:      	orr	w19, w23, #0x1
     398:      	mov	w24, #0xc00             ; =3072
     39c:      	umaddl	x1, w19, w24, x25
     3a0:      	add	x0, sp, #0xd30
     3a4:      	mov	w2, #0xc00              ; =3072
     3a8:      	bl	0x3a8 <ltmp0+0x3a8>
     3ac:      	umaddl	x1, w19, w24, x26
     3b0:      	add	x0, sp, #0x130
     3b4:      	mov	w2, #0xc00              ; =3072
     3b8:      	bl	0x3b8 <ltmp0+0x3b8>
     3bc:      	ldp	q9, q8, [sp, #0x50]
     3c0:      	ldp	q31, q30, [sp, #0x70]
     3c4:      	movi.4s	v29, #0x3f, lsl #24
     3c8:      	ldp	q28, q27, [sp, #0x90]
     3cc:      	ldp	q26, q25, [sp, #0xb0]
     3d0:      	ldp	q24, q23, [sp, #0xd0]
     3d4:      	mvni.4s	v22, #0x80, lsl #24
     3d8:      	movi.4s	v21, #0x4b, lsl #24
     3dc:      	ldp	q20, q19, [sp, #0xf0]
     3e0:      	ldr	q18, [sp, #0x110]
     3e4:      	mov	x8, #0x0                ; =0
     3e8:      	umaddl	x9, w19, w24, x21
     3ec:      	add	x10, x27, x8
     3f0:      	ldp	q0, q1, [x10]
     3f4:      	fneg.4s	v2, v1
     3f8:      	fneg.4s	v3, v0
     3fc:      	fcmge.4s	v4, v18, v0
     400:      	fcmge.4s	v5, v18, v1
     404:      	fcmge.4s	v6, v0, v19
     408:      	fcmge.4s	v7, v1, v19
     40c:      	and.16b	v5, v5, v7
     410:      	and.16b	v4, v4, v6
     414:      	and.16b	v3, v4, v3
     418:      	and.16b	v2, v5, v2
     41c:      	fmul.4s	v4, v2, v20
     420:      	fmul.4s	v5, v3, v20
     424:      	mov.16b	v6, v22
     428:      	bsl.16b	v6, v21, v5
     42c:      	mov.16b	v7, v22
     430:      	bsl.16b	v7, v21, v4
     434:      	fadd.4s	v4, v4, v7
     438:      	fadd.4s	v5, v5, v6
     43c:      	fsub.4s	v5, v5, v6
     440:      	fsub.4s	v4, v4, v7
     444:      	fcvtzs.4s	v4, v4
     448:      	fcvtzs.4s	v5, v5
     44c:      	scvtf.4s	v6, v5
     450:      	scvtf.4s	v7, v4
     454:      	fmul.4s	v16, v7, v23
     458:      	fmul.4s	v17, v6, v23
     45c:      	fadd.4s	v3, v3, v17
     460:      	fadd.4s	v2, v2, v16
     464:      	fmul.4s	v6, v6, v24
     468:      	fmul.4s	v7, v7, v24
     46c:      	fadd.4s	v2, v2, v7
     470:      	fadd.4s	v3, v3, v6
     474:      	fmul.4s	v6, v3, v25
     478:      	fmul.4s	v7, v2, v25
     47c:      	fadd.4s	v7, v7, v26
     480:      	fadd.4s	v6, v6, v26
     484:      	fmul.4s	v6, v3, v6
     488:      	fmul.4s	v7, v2, v7
     48c:      	fadd.4s	v7, v7, v27
     490:      	fadd.4s	v6, v6, v27
     494:      	fmul.4s	v6, v3, v6
     498:      	fmul.4s	v7, v2, v7
     49c:      	fadd.4s	v7, v7, v28
     4a0:      	fadd.4s	v6, v6, v28
     4a4:      	fmul.4s	v6, v3, v6
     4a8:      	fmul.4s	v7, v2, v7
     4ac:      	fadd.4s	v7, v7, v8
     4b0:      	fadd.4s	v6, v6, v8
     4b4:      	fmul.4s	v6, v3, v6
     4b8:      	fmul.4s	v7, v2, v7
     4bc:      	fadd.4s	v7, v7, v29
     4c0:      	fadd.4s	v6, v6, v29
     4c4:      	fmul.4s	v16, v2, v2
     4c8:      	fmul.4s	v17, v3, v3
     4cc:      	fmul.4s	v6, v17, v6
     4d0:      	fmul.4s	v7, v16, v7
     4d4:      	fadd.4s	v2, v2, v7
     4d8:      	fadd.4s	v3, v3, v6
     4dc:      	sshr.4s	v6, v5, #0x1
     4e0:      	fadd.4s	v3, v3, v30
     4e4:      	sshr.4s	v7, v4, #0x1
     4e8:      	shl.4s	v16, v7, #0x17
     4ec:      	shl.4s	v17, v6, #0x17
     4f0:      	add.4s	v17, v17, v30
     4f4:      	add.4s	v16, v16, v30
     4f8:      	fadd.4s	v2, v2, v30
     4fc:      	fmul.4s	v2, v2, v16
     500:      	sub.4s	v4, v4, v7
     504:      	sub.4s	v5, v5, v6
     508:      	shl.4s	v5, v5, #0x17
     50c:      	shl.4s	v4, v4, #0x17
     510:      	fmul.4s	v3, v3, v17
     514:      	add.4s	v4, v4, v30
     518:      	add.4s	v5, v5, v30
     51c:      	fmul.4s	v3, v3, v5
     520:      	fmul.4s	v2, v2, v4
     524:      	fcmgt.4s	v4, v1, v18
     528:      	fcmgt.4s	v5, v0, v18
     52c:      	fcmgt.4s	v6, v19, v0
     530:      	fcmgt.4s	v7, v19, v1
     534:      	fcmeq.4s	v16, v1, v1
     538:      	fadd.4s	v2, v2, v30
     53c:      	fadd.4s	v3, v3, v30
     540:      	fcmeq.4s	v17, v0, v0
     544:      	bit.16b	v3, v30, v5
     548:      	bit.16b	v2, v30, v4
     54c:      	bit.16b	v2, v31, v7
     550:      	bit.16b	v3, v31, v6
     554:      	bif.16b	v3, v9, v17
     558:      	bif.16b	v2, v9, v16
     55c:      	fdiv.4s	v1, v1, v2
     560:      	fdiv.4s	v0, v0, v3
     564:      	add	x10, x28, x8
     568:      	ldp	q3, q2, [x10]
     56c:      	fmul.4s	v0, v3, v0
     570:      	fmul.4s	v1, v2, v1
     574:      	add	x10, x9, x8
     578:      	stp	q0, q1, [x10]
     57c:      	add	x8, x8, #0x20
     580:      	cmp	x8, #0xc00
     584:      	b.ne	0x3ec <ltmp0+0x3ec>
     588:      	orr	w19, w23, #0x2
     58c:      	mov	w24, #0xc00             ; =3072
     590:      	umaddl	x1, w19, w24, x25
     594:      	add	x0, sp, #0xd30
     598:      	mov	w2, #0xc00              ; =3072
     59c:      	bl	0x59c <ltmp0+0x59c>
     5a0:      	umaddl	x1, w19, w24, x26
     5a4:      	add	x0, sp, #0x130
     5a8:      	mov	w2, #0xc00              ; =3072
     5ac:      	bl	0x5ac <ltmp0+0x5ac>
     5b0:      	ldp	q9, q8, [sp, #0x50]
     5b4:      	ldp	q31, q30, [sp, #0x70]
     5b8:      	movi.4s	v29, #0x3f, lsl #24
     5bc:      	ldp	q28, q27, [sp, #0x90]
     5c0:      	ldp	q26, q25, [sp, #0xb0]
     5c4:      	ldp	q24, q23, [sp, #0xd0]
     5c8:      	mvni.4s	v22, #0x80, lsl #24
     5cc:      	movi.4s	v21, #0x4b, lsl #24
     5d0:      	ldp	q20, q19, [sp, #0xf0]
     5d4:      	ldr	q18, [sp, #0x110]
     5d8:      	mov	x8, #0x0                ; =0
     5dc:      	umaddl	x9, w19, w24, x21
     5e0:      	add	x10, x27, x8
     5e4:      	ldp	q0, q1, [x10]
     5e8:      	fneg.4s	v2, v1
     5ec:      	fneg.4s	v3, v0
     5f0:      	fcmge.4s	v4, v18, v0
     5f4:      	fcmge.4s	v5, v18, v1
     5f8:      	fcmge.4s	v6, v0, v19
     5fc:      	fcmge.4s	v7, v1, v19
     600:      	and.16b	v5, v5, v7
     604:      	and.16b	v4, v4, v6
     608:      	and.16b	v3, v4, v3
     60c:      	and.16b	v2, v5, v2
     610:      	fmul.4s	v4, v2, v20
     614:      	fmul.4s	v5, v3, v20
     618:      	mov.16b	v6, v22
     61c:      	bsl.16b	v6, v21, v5
     620:      	mov.16b	v7, v22
     624:      	bsl.16b	v7, v21, v4
     628:      	fadd.4s	v4, v4, v7
     62c:      	fadd.4s	v5, v5, v6
     630:      	fsub.4s	v5, v5, v6
     634:      	fsub.4s	v4, v4, v7
     638:      	fcvtzs.4s	v4, v4
     63c:      	fcvtzs.4s	v5, v5
     640:      	scvtf.4s	v6, v5
     644:      	scvtf.4s	v7, v4
     648:      	fmul.4s	v16, v7, v23
     64c:      	fmul.4s	v17, v6, v23
     650:      	fadd.4s	v3, v3, v17
     654:      	fadd.4s	v2, v2, v16
     658:      	fmul.4s	v6, v6, v24
     65c:      	fmul.4s	v7, v7, v24
     660:      	fadd.4s	v2, v2, v7
     664:      	fadd.4s	v3, v3, v6
     668:      	fmul.4s	v6, v3, v25
     66c:      	fmul.4s	v7, v2, v25
     670:      	fadd.4s	v7, v7, v26
     674:      	fadd.4s	v6, v6, v26
     678:      	fmul.4s	v6, v3, v6
     67c:      	fmul.4s	v7, v2, v7
     680:      	fadd.4s	v7, v7, v27
     684:      	fadd.4s	v6, v6, v27
     688:      	fmul.4s	v6, v3, v6
     68c:      	fmul.4s	v7, v2, v7
     690:      	fadd.4s	v7, v7, v28
     694:      	fadd.4s	v6, v6, v28
     698:      	fmul.4s	v6, v3, v6
     69c:      	fmul.4s	v7, v2, v7
     6a0:      	fadd.4s	v7, v7, v8
     6a4:      	fadd.4s	v6, v6, v8
     6a8:      	fmul.4s	v6, v3, v6
     6ac:      	fmul.4s	v7, v2, v7
     6b0:      	fadd.4s	v7, v7, v29
     6b4:      	fadd.4s	v6, v6, v29
     6b8:      	fmul.4s	v16, v2, v2
     6bc:      	fmul.4s	v17, v3, v3
     6c0:      	fmul.4s	v6, v17, v6
     6c4:      	fmul.4s	v7, v16, v7
     6c8:      	fadd.4s	v2, v2, v7
     6cc:      	fadd.4s	v3, v3, v6
     6d0:      	sshr.4s	v6, v5, #0x1
     6d4:      	fadd.4s	v3, v3, v30
     6d8:      	sshr.4s	v7, v4, #0x1
     6dc:      	shl.4s	v16, v7, #0x17
     6e0:      	shl.4s	v17, v6, #0x17
     6e4:      	add.4s	v17, v17, v30
     6e8:      	add.4s	v16, v16, v30
     6ec:      	fadd.4s	v2, v2, v30
     6f0:      	fmul.4s	v2, v2, v16
     6f4:      	sub.4s	v4, v4, v7
     6f8:      	sub.4s	v5, v5, v6
     6fc:      	shl.4s	v5, v5, #0x17
     700:      	shl.4s	v4, v4, #0x17
     704:      	fmul.4s	v3, v3, v17
     708:      	add.4s	v4, v4, v30
     70c:      	add.4s	v5, v5, v30
     710:      	fmul.4s	v3, v3, v5
     714:      	fmul.4s	v2, v2, v4
     718:      	fcmgt.4s	v4, v1, v18
     71c:      	fcmgt.4s	v5, v0, v18
     720:      	fcmgt.4s	v6, v19, v0
     724:      	fcmgt.4s	v7, v19, v1
     728:      	fcmeq.4s	v16, v1, v1
     72c:      	fadd.4s	v2, v2, v30
     730:      	fadd.4s	v3, v3, v30
     734:      	fcmeq.4s	v17, v0, v0
     738:      	bit.16b	v3, v30, v5
     73c:      	bit.16b	v2, v30, v4
     740:      	bit.16b	v2, v31, v7
     744:      	bit.16b	v3, v31, v6
     748:      	bif.16b	v3, v9, v17
     74c:      	bif.16b	v2, v9, v16
     750:      	fdiv.4s	v1, v1, v2
     754:      	fdiv.4s	v0, v0, v3
     758:      	add	x10, x28, x8
     75c:      	ldp	q3, q2, [x10]
     760:      	fmul.4s	v0, v3, v0
     764:      	fmul.4s	v1, v2, v1
     768:      	add	x10, x9, x8
     76c:      	stp	q0, q1, [x10]
     770:      	add	x8, x8, #0x20
     774:      	cmp	x8, #0xc00
     778:      	b.ne	0x5e0 <ltmp0+0x5e0>
     77c:      	orr	w19, w23, #0x3
     780:      	mov	w23, #0xc00             ; =3072
     784:      	umaddl	x1, w19, w23, x25
     788:      	add	x0, sp, #0xd30
     78c:      	mov	w2, #0xc00              ; =3072
     790:      	bl	0x790 <ltmp0+0x790>
     794:      	umaddl	x1, w19, w23, x26
     798:      	add	x0, sp, #0x130
     79c:      	mov	w2, #0xc00              ; =3072
     7a0:      	bl	0x7a0 <ltmp0+0x7a0>
     7a4:      	ldp	q9, q8, [sp, #0x50]
     7a8:      	ldp	q31, q30, [sp, #0x70]
     7ac:      	movi.4s	v29, #0x3f, lsl #24
     7b0:      	ldp	q28, q27, [sp, #0x90]
     7b4:      	ldp	q26, q25, [sp, #0xb0]
     7b8:      	ldp	q24, q23, [sp, #0xd0]
     7bc:      	mvni.4s	v22, #0x80, lsl #24
     7c0:      	movi.4s	v21, #0x4b, lsl #24
     7c4:      	ldp	q20, q19, [sp, #0xf0]
     7c8:      	ldr	q18, [sp, #0x110]
     7cc:      	mov	x8, #0x0                ; =0
     7d0:      	umaddl	x9, w19, w23, x21
     7d4:      	add	x10, x27, x8
     7d8:      	ldp	q0, q1, [x10]
     7dc:      	fneg.4s	v2, v1
     7e0:      	fneg.4s	v3, v0
     7e4:      	fcmge.4s	v4, v18, v0
     7e8:      	fcmge.4s	v5, v18, v1
     7ec:      	fcmge.4s	v6, v0, v19
     7f0:      	fcmge.4s	v7, v1, v19
     7f4:      	and.16b	v5, v5, v7
     7f8:      	and.16b	v4, v4, v6
     7fc:      	and.16b	v3, v4, v3
     800:      	and.16b	v2, v5, v2
     804:      	fmul.4s	v4, v2, v20
     808:      	fmul.4s	v5, v3, v20
     80c:      	mov.16b	v6, v22
     810:      	bsl.16b	v6, v21, v5
     814:      	mov.16b	v7, v22
     818:      	bsl.16b	v7, v21, v4
     81c:      	fadd.4s	v4, v4, v7
     820:      	fadd.4s	v5, v5, v6
     824:      	fsub.4s	v5, v5, v6
     828:      	fsub.4s	v4, v4, v7
     82c:      	fcvtzs.4s	v4, v4
     830:      	fcvtzs.4s	v5, v5
     834:      	scvtf.4s	v6, v5
     838:      	scvtf.4s	v7, v4
     83c:      	fmul.4s	v16, v7, v23
     840:      	fmul.4s	v17, v6, v23
     844:      	fadd.4s	v3, v3, v17
     848:      	fadd.4s	v2, v2, v16
     84c:      	fmul.4s	v6, v6, v24
     850:      	fmul.4s	v7, v7, v24
     854:      	fadd.4s	v2, v2, v7
     858:      	fadd.4s	v3, v3, v6
     85c:      	fmul.4s	v6, v3, v25
     860:      	fmul.4s	v7, v2, v25
     864:      	fadd.4s	v7, v7, v26
     868:      	fadd.4s	v6, v6, v26
     86c:      	fmul.4s	v6, v3, v6
     870:      	fmul.4s	v7, v2, v7
     874:      	fadd.4s	v7, v7, v27
     878:      	fadd.4s	v6, v6, v27
     87c:      	fmul.4s	v6, v3, v6
     880:      	fmul.4s	v7, v2, v7
     884:      	fadd.4s	v7, v7, v28
     888:      	fadd.4s	v6, v6, v28
     88c:      	fmul.4s	v6, v3, v6
     890:      	fmul.4s	v7, v2, v7
     894:      	fadd.4s	v7, v7, v8
     898:      	fadd.4s	v6, v6, v8
     89c:      	fmul.4s	v6, v3, v6
     8a0:      	fmul.4s	v7, v2, v7
     8a4:      	fadd.4s	v7, v7, v29
     8a8:      	fadd.4s	v6, v6, v29
     8ac:      	fmul.4s	v16, v2, v2
     8b0:      	fmul.4s	v17, v3, v3
     8b4:      	fmul.4s	v6, v17, v6
     8b8:      	fmul.4s	v7, v16, v7
     8bc:      	fadd.4s	v2, v2, v7
     8c0:      	fadd.4s	v3, v3, v6
     8c4:      	sshr.4s	v6, v5, #0x1
     8c8:      	fadd.4s	v3, v3, v30
     8cc:      	sshr.4s	v7, v4, #0x1
     8d0:      	shl.4s	v16, v7, #0x17
     8d4:      	shl.4s	v17, v6, #0x17
     8d8:      	add.4s	v17, v17, v30
     8dc:      	add.4s	v16, v16, v30
     8e0:      	fadd.4s	v2, v2, v30
     8e4:      	fmul.4s	v2, v2, v16
     8e8:      	sub.4s	v4, v4, v7
     8ec:      	sub.4s	v5, v5, v6
     8f0:      	shl.4s	v5, v5, #0x17
     8f4:      	shl.4s	v4, v4, #0x17
     8f8:      	fmul.4s	v3, v3, v17
     8fc:      	add.4s	v4, v4, v30
     900:      	add.4s	v5, v5, v30
     904:      	fmul.4s	v3, v3, v5
     908:      	fmul.4s	v2, v2, v4
     90c:      	fcmgt.4s	v4, v1, v18
     910:      	fcmgt.4s	v5, v0, v18
     914:      	fcmgt.4s	v6, v19, v0
     918:      	fcmgt.4s	v7, v19, v1
     91c:      	fcmeq.4s	v16, v1, v1
     920:      	fadd.4s	v2, v2, v30
     924:      	fadd.4s	v3, v3, v30
     928:      	fcmeq.4s	v17, v0, v0
     92c:      	bit.16b	v3, v30, v5
     930:      	bit.16b	v2, v30, v4
     934:      	bit.16b	v2, v31, v7
     938:      	bit.16b	v3, v31, v6
     93c:      	bif.16b	v3, v9, v17
     940:      	bif.16b	v2, v9, v16
     944:      	fdiv.4s	v1, v1, v2
     948:      	fdiv.4s	v0, v0, v3
     94c:      	add	x10, x28, x8
     950:      	ldp	q3, q2, [x10]
     954:      	fmul.4s	v0, v3, v0
     958:      	fmul.4s	v1, v2, v1
     95c:      	add	x10, x9, x8
     960:      	stp	q0, q1, [x10]
     964:      	add	x8, x8, #0x20
     968:      	cmp	x8, #0xc00
     96c:      	b.ne	0x7d4 <ltmp0+0x7d4>
     970:      	ldr	x1, [sp, #0x48]
     974:      	ldr	w3, [sp, #0x3c]
     978:      	b	0x10c <ltmp0+0x10c>
     97c:      	str	w22, [sp, #0x2c]
     980:      	lsr	x21, x23, #3
     984:      	cmp	x23, #0x8
     988:      	b.lo	0xbbc <ltmp0+0xbbc>
     98c:      	mov	x25, #0x0               ; =0
     990:      	ldr	x8, [sp, #0x20]
     994:      	ldr	x26, [x8]
     998:      	ldr	x24, [x8, #0x10]
     99c:      	ldr	x8, [x8, #0x30]
     9a0:      	ldr	x9, [sp, #0x48]
     9a4:      	lsl	w19, w9, #2
     9a8:      	and	x9, x9, #0x7ffffff
     9ac:      	mov	w10, #0x3000            ; =12288
     9b0:      	umaddl	x20, w9, w10, x8
     9b4:      	add	w8, w25, w19
     9b8:      	and	x8, x8, #0x1fffffff
     9bc:      	add	x8, x8, x8, lsl #1
     9c0:      	lsl	x22, x8, #10
     9c4:      	add	x0, sp, #0xd30
     9c8:      	add	x1, x26, x22
     9cc:      	mov	w2, #0xc00              ; =3072
     9d0:      	bl	0x9d0 <ltmp0+0x9d0>
     9d4:      	add	x0, sp, #0x130
     9d8:      	add	x1, x24, x22
     9dc:      	mov	w2, #0xc00              ; =3072
     9e0:      	bl	0x9e0 <ltmp0+0x9e0>
     9e4:      	ldp	q9, q8, [sp, #0x50]
     9e8:      	ldp	q31, q30, [sp, #0x70]
     9ec:      	movi.4s	v29, #0x3f, lsl #24
     9f0:      	ldp	q28, q27, [sp, #0x90]
     9f4:      	ldp	q26, q25, [sp, #0xb0]
     9f8:      	ldp	q24, q23, [sp, #0xd0]
     9fc:      	mvni.4s	v22, #0x80, lsl #24
     a00:      	movi.4s	v21, #0x4b, lsl #24
     a04:      	ldp	q20, q19, [sp, #0xf0]
     a08:      	ldr	q18, [sp, #0x110]
     a0c:      	mov	x8, #0x0                ; =0
     a10:      	add	x9, x27, x8
     a14:      	ldp	q0, q1, [x9]
     a18:      	fneg.4s	v2, v1
     a1c:      	fneg.4s	v3, v0
     a20:      	fcmge.4s	v4, v18, v0
     a24:      	fcmge.4s	v5, v18, v1
     a28:      	fcmge.4s	v6, v0, v19
     a2c:      	fcmge.4s	v7, v1, v19
     a30:      	and.16b	v5, v5, v7
     a34:      	and.16b	v4, v4, v6
     a38:      	and.16b	v3, v4, v3
     a3c:      	and.16b	v2, v5, v2
     a40:      	fmul.4s	v4, v2, v20
     a44:      	fmul.4s	v5, v3, v20
     a48:      	mov.16b	v6, v22
     a4c:      	bsl.16b	v6, v21, v5
     a50:      	mov.16b	v7, v22
     a54:      	bsl.16b	v7, v21, v4
     a58:      	fadd.4s	v4, v4, v7
     a5c:      	fadd.4s	v5, v5, v6
     a60:      	fsub.4s	v5, v5, v6
     a64:      	fsub.4s	v4, v4, v7
     a68:      	fcvtzs.4s	v4, v4
     a6c:      	fcvtzs.4s	v5, v5
     a70:      	scvtf.4s	v6, v5
     a74:      	scvtf.4s	v7, v4
     a78:      	fmul.4s	v16, v7, v23
     a7c:      	fmul.4s	v17, v6, v23
     a80:      	fadd.4s	v3, v3, v17
     a84:      	fadd.4s	v2, v2, v16
     a88:      	fmul.4s	v6, v6, v24
     a8c:      	fmul.4s	v7, v7, v24
     a90:      	fadd.4s	v2, v2, v7
     a94:      	fadd.4s	v3, v3, v6
     a98:      	fmul.4s	v6, v3, v25
     a9c:      	fmul.4s	v7, v2, v25
     aa0:      	fadd.4s	v7, v7, v26
     aa4:      	fadd.4s	v6, v6, v26
     aa8:      	fmul.4s	v6, v3, v6
     aac:      	fmul.4s	v7, v2, v7
     ab0:      	fadd.4s	v7, v7, v27
     ab4:      	fadd.4s	v6, v6, v27
     ab8:      	fmul.4s	v6, v3, v6
     abc:      	fmul.4s	v7, v2, v7
     ac0:      	fadd.4s	v7, v7, v28
     ac4:      	fadd.4s	v6, v6, v28
     ac8:      	fmul.4s	v6, v3, v6
     acc:      	fmul.4s	v7, v2, v7
     ad0:      	fadd.4s	v7, v7, v8
     ad4:      	fadd.4s	v6, v6, v8
     ad8:      	fmul.4s	v6, v3, v6
     adc:      	fmul.4s	v7, v2, v7
     ae0:      	fadd.4s	v7, v7, v29
     ae4:      	fadd.4s	v6, v6, v29
     ae8:      	fmul.4s	v16, v2, v2
     aec:      	fmul.4s	v17, v3, v3
     af0:      	fmul.4s	v6, v17, v6
     af4:      	fmul.4s	v7, v16, v7
     af8:      	fadd.4s	v2, v2, v7
     afc:      	fadd.4s	v3, v3, v6
     b00:      	sshr.4s	v6, v5, #0x1
     b04:      	fadd.4s	v3, v3, v30
     b08:      	sshr.4s	v7, v4, #0x1
     b0c:      	shl.4s	v16, v7, #0x17
     b10:      	shl.4s	v17, v6, #0x17
     b14:      	add.4s	v17, v17, v30
     b18:      	add.4s	v16, v16, v30
     b1c:      	fadd.4s	v2, v2, v30
     b20:      	fmul.4s	v2, v2, v16
     b24:      	sub.4s	v4, v4, v7
     b28:      	sub.4s	v5, v5, v6
     b2c:      	shl.4s	v5, v5, #0x17
     b30:      	shl.4s	v4, v4, #0x17
     b34:      	fmul.4s	v3, v3, v17
     b38:      	add.4s	v4, v4, v30
     b3c:      	add.4s	v5, v5, v30
     b40:      	fmul.4s	v3, v3, v5
     b44:      	fmul.4s	v2, v2, v4
     b48:      	fcmgt.4s	v4, v1, v18
     b4c:      	fcmgt.4s	v5, v0, v18
     b50:      	fcmgt.4s	v6, v19, v0
     b54:      	fcmgt.4s	v7, v19, v1
     b58:      	fcmeq.4s	v16, v1, v1
     b5c:      	fadd.4s	v2, v2, v30
     b60:      	fadd.4s	v3, v3, v30
     b64:      	fcmeq.4s	v17, v0, v0
     b68:      	bit.16b	v3, v30, v5
     b6c:      	bit.16b	v2, v30, v4
     b70:      	bit.16b	v2, v31, v7
     b74:      	bit.16b	v3, v31, v6
     b78:      	bif.16b	v3, v9, v17
     b7c:      	bif.16b	v2, v9, v16
     b80:      	fdiv.4s	v1, v1, v2
     b84:      	fdiv.4s	v0, v0, v3
     b88:      	add	x9, x28, x8
     b8c:      	ldp	q3, q2, [x9]
     b90:      	fmul.4s	v0, v3, v0
     b94:      	fmul.4s	v1, v2, v1
     b98:      	add	x9, x20, x8
     b9c:      	stp	q0, q1, [x9]
     ba0:      	add	x8, x8, #0x20
     ba4:      	cmp	x8, #0xc00
     ba8:      	b.ne	0xa10 <ltmp0+0xa10>
     bac:      	add	x25, x25, #0x1
     bb0:      	add	x20, x20, #0xc00
     bb4:      	cmp	x25, x21
     bb8:      	b.ne	0x9b4 <ltmp0+0x9b4>
     bbc:      	and	w8, w23, #0x7
     bc0:      	ldr	w20, [sp, #0x1c]
     bc4:      	ldr	w22, [sp, #0x2c]
     bc8:      	ldr	w3, [sp, #0x3c]
     bcc:      	mov	w17, #-0x3d300000       ; =-1026555904
     bd0:      	mov	w0, #0x42c80000         ; =1120403456
     bd4:      	ldr	x1, [sp, #0x48]
     bd8:      	cbz	w8, 0x10c <ltmp0+0x10c>
     bdc:      	dup.4s	v1, w8
     be0:      	adrp	x8, 0x0 <ltmp0>
     be4:      	ldr	q2, [x8]
     be8:      	adrp	x8, 0x0 <ltmp0>
     bec:      	ldr	q0, [x8]
     bf0:      	cmhi.4s	v0, v1, v0
     bf4:      	cmhi.4s	v1, v1, v2
     bf8:      	uzp1.8h	v3, v1, v0
     bfc:      	umaxv.8h	h2, v3
     c00:      	fmov	w8, s2
     c04:      	tbz	w8, #0x0, 0x10c <ltmp0+0x10c>
     c08:      	mov	x11, #0x0               ; =0
     c0c:      	ldr	x9, [sp, #0x20]
     c10:      	ldr	x10, [x9, #0x10]
     c14:      	ldr	x8, [x9, #0x30]
     c18:      	ldr	x12, [x9]
     c1c:      	ubfiz	w9, w1, #2, #27
     c20:      	orr	w9, w9, w21
     c24:      	fmov	s2, w9
     c28:      	and.16b	v2, v1, v2
     c2c:      	fmov	w13, s2
     c30:      	mov	w14, #0xc00             ; =3072
     c34:      	umull	x9, w13, w14
     c38:      	umaddl	x12, w13, w14, x12
     c3c:      	adrp	x16, 0x0 <ltmp0>
     c40:      	b	0xc64 <ltmp0+0xc64>
     c44:      	add	x13, x27, x11
     c48:      	ldp	q6, q7, [x13]
     c4c:      	bif.16b	v5, v7, v0
     c50:      	bif.16b	v4, v6, v1
     c54:      	stp	q4, q5, [x13]
     c58:      	add	x11, x11, #0x20
     c5c:      	cmp	x11, #0xc00
     c60:      	b.eq	0xd08 <ltmp0+0xd08>
     c64:      	ldr	q2, [x16]
     c68:      	and.16b	v2, v3, v2
     c6c:      	addv.8h	h2, v2
     c70:      	fmov	w14, s2
     c74:      	add	x13, x12, x11
     c78:      	movi.2d	v4, #0000000000000000
     c7c:      	movi.2d	v5, #0000000000000000
     c80:      	tbnz	w14, #0x0, 0xca8 <ltmp0+0xca8>
     c84:      	and	w14, w14, #0xff
     c88:      	tbnz	w14, #0x1, 0xcb4 <ltmp0+0xcb4>
     c8c:      	tbnz	w14, #0x2, 0xcc0 <ltmp0+0xcc0>
     c90:      	tbnz	w14, #0x3, 0xccc <ltmp0+0xccc>
     c94:      	tbnz	w14, #0x4, 0xcd8 <ltmp0+0xcd8>
     c98:      	tbnz	w14, #0x5, 0xce4 <ltmp0+0xce4>
     c9c:      	tbnz	w14, #0x6, 0xcf0 <ltmp0+0xcf0>
     ca0:      	tbz	w14, #0x7, 0xc44 <ltmp0+0xc44>
     ca4:      	b	0xcfc <ltmp0+0xcfc>
     ca8:      	ldr	s4, [x13]
     cac:      	and	w14, w14, #0xff
     cb0:      	tbz	w14, #0x1, 0xc8c <ltmp0+0xc8c>
     cb4:      	add	x15, x13, #0x4
     cb8:      	ld1.s	{ v4 }[1], [x15]
     cbc:      	tbz	w14, #0x2, 0xc90 <ltmp0+0xc90>
     cc0:      	add	x15, x13, #0x8
     cc4:      	ld1.s	{ v4 }[2], [x15]
     cc8:      	tbz	w14, #0x3, 0xc94 <ltmp0+0xc94>
     ccc:      	add	x15, x13, #0xc
     cd0:      	ld1.s	{ v4 }[3], [x15]
     cd4:      	tbz	w14, #0x4, 0xc98 <ltmp0+0xc98>
     cd8:      	add	x15, x13, #0x10
     cdc:      	ld1.s	{ v5 }[0], [x15]
     ce0:      	tbz	w14, #0x5, 0xc9c <ltmp0+0xc9c>
     ce4:      	add	x15, x13, #0x14
     ce8:      	ld1.s	{ v5 }[1], [x15]
     cec:      	tbz	w14, #0x6, 0xca0 <ltmp0+0xca0>
     cf0:      	add	x15, x13, #0x18
     cf4:      	ld1.s	{ v5 }[2], [x15]
     cf8:      	tbz	w14, #0x7, 0xc44 <ltmp0+0xc44>
     cfc:      	add	x13, x13, #0x1c
     d00:      	ld1.s	{ v5 }[3], [x13]
     d04:      	b	0xc44 <ltmp0+0xc44>
     d08:      	mov	x11, #0x0               ; =0
     d0c:      	add	x10, x10, x9
     d10:      	b	0xd34 <ltmp0+0xd34>
     d14:      	add	x12, x28, x11
     d18:      	ldp	q5, q6, [x12]
     d1c:      	bif.16b	v4, v6, v0
     d20:      	bif.16b	v3, v5, v1
     d24:      	stp	q3, q4, [x12]
     d28:      	add	x11, x11, #0x20
     d2c:      	cmp	x11, #0xc00
     d30:      	b.eq	0xdcc <ltmp0+0xdcc>
     d34:      	fmov	w13, s2
     d38:      	add	x12, x10, x11
     d3c:      	movi.2d	v3, #0000000000000000
     d40:      	movi.2d	v4, #0000000000000000
     d44:      	tbnz	w13, #0x0, 0xd6c <ltmp0+0xd6c>
     d48:      	and	w13, w13, #0xff
     d4c:      	tbnz	w13, #0x1, 0xd78 <ltmp0+0xd78>
     d50:      	tbnz	w13, #0x2, 0xd84 <ltmp0+0xd84>
     d54:      	tbnz	w13, #0x3, 0xd90 <ltmp0+0xd90>
     d58:      	tbnz	w13, #0x4, 0xd9c <ltmp0+0xd9c>
     d5c:      	tbnz	w13, #0x5, 0xda8 <ltmp0+0xda8>
     d60:      	tbnz	w13, #0x6, 0xdb4 <ltmp0+0xdb4>
     d64:      	tbz	w13, #0x7, 0xd14 <ltmp0+0xd14>
     d68:      	b	0xdc0 <ltmp0+0xdc0>
     d6c:      	ldr	s3, [x12]
     d70:      	and	w13, w13, #0xff
     d74:      	tbz	w13, #0x1, 0xd50 <ltmp0+0xd50>
     d78:      	add	x14, x12, #0x4
     d7c:      	ld1.s	{ v3 }[1], [x14]
     d80:      	tbz	w13, #0x2, 0xd54 <ltmp0+0xd54>
     d84:      	add	x14, x12, #0x8
     d88:      	ld1.s	{ v3 }[2], [x14]
     d8c:      	tbz	w13, #0x3, 0xd58 <ltmp0+0xd58>
     d90:      	add	x14, x12, #0xc
     d94:      	ld1.s	{ v3 }[3], [x14]
     d98:      	tbz	w13, #0x4, 0xd5c <ltmp0+0xd5c>
     d9c:      	add	x14, x12, #0x10
     da0:      	ld1.s	{ v4 }[0], [x14]
     da4:      	tbz	w13, #0x5, 0xd60 <ltmp0+0xd60>
     da8:      	add	x14, x12, #0x14
     dac:      	ld1.s	{ v4 }[1], [x14]
     db0:      	tbz	w13, #0x6, 0xd64 <ltmp0+0xd64>
     db4:      	add	x14, x12, #0x18
     db8:      	ld1.s	{ v4 }[2], [x14]
     dbc:      	tbz	w13, #0x7, 0xd14 <ltmp0+0xd14>
     dc0:      	add	x12, x12, #0x1c
     dc4:      	ld1.s	{ v4 }[3], [x12]
     dc8:      	b	0xd14 <ltmp0+0xd14>
     dcc:      	mov	x10, #0x0               ; =0
     dd0:      	add	x8, x8, x9
     dd4:      	b	0xde4 <ltmp0+0xde4>
     dd8:      	add	x10, x10, #0x20
     ddc:      	cmp	x10, #0xc00
     de0:      	b.eq	0x10c <ltmp0+0x10c>
     de4:      	fmov	w11, s2
     de8:      	add	x9, x27, x10
     dec:      	ldp	q3, q5, [x9]
     df0:      	and.16b	v6, v1, v3
     df4:      	fneg.4s	v3, v6
     df8:      	and.16b	v7, v1, v3
     dfc:      	dup.4s	v3, w17
     e00:      	fcmge.4s	v16, v7, v3
     e04:      	dup.4s	v4, w0
     e08:      	fcmge.4s	v17, v4, v7
     e0c:      	and.16b	v16, v16, v17
     e10:      	and.16b	v16, v16, v7
     e14:      	fmul.4s	v17, v16, v20
     e18:      	mov.16b	v18, v22
     e1c:      	bsl.16b	v18, v21, v17
     e20:      	fadd.4s	v17, v17, v18
     e24:      	fsub.4s	v17, v17, v18
     e28:      	fcvtzs.4s	v17, v17
     e2c:      	scvtf.4s	v18, v17
     e30:      	fmul.4s	v19, v18, v23
     e34:      	fadd.4s	v16, v16, v19
     e38:      	fmul.4s	v18, v18, v24
     e3c:      	fadd.4s	v16, v16, v18
     e40:      	fmul.4s	v18, v16, v25
     e44:      	fadd.4s	v18, v18, v26
     e48:      	fmul.4s	v18, v16, v18
     e4c:      	fadd.4s	v18, v18, v27
     e50:      	fmul.4s	v18, v16, v18
     e54:      	fadd.4s	v18, v18, v28
     e58:      	fmul.4s	v18, v16, v18
     e5c:      	fadd.4s	v18, v18, v8
     e60:      	fmul.4s	v18, v16, v18
     e64:      	fadd.4s	v18, v18, v29
     e68:      	fmul.4s	v19, v16, v16
     e6c:      	fmul.4s	v18, v19, v18
     e70:      	fadd.4s	v16, v16, v18
     e74:      	fadd.4s	v16, v16, v30
     e78:      	sshr.4s	v18, v17, #0x1
     e7c:      	shl.4s	v19, v18, #0x17
     e80:      	add.4s	v19, v19, v30
     e84:      	fmul.4s	v16, v16, v19
     e88:      	sub.4s	v17, v17, v18
     e8c:      	shl.4s	v17, v17, #0x17
     e90:      	add.4s	v17, v17, v30
     e94:      	fmul.4s	v16, v16, v17
     e98:      	fcmgt.4s	v17, v3, v7
     e9c:      	fcmgt.4s	v18, v7, v4
     ea0:      	fcmeq.4s	v7, v7, v7
     ea4:      	fadd.4s	v16, v16, v30
     ea8:      	bit.16b	v16, v30, v17
     eac:      	bit.16b	v16, v31, v18
     eb0:      	bsl.16b	v7, v16, v9
     eb4:      	fdiv.4s	v7, v6, v7
     eb8:      	add	x9, x28, x10
     ebc:      	ldp	q16, q6, [x9]
     ec0:      	and.16b	v16, v1, v16
     ec4:      	fmul.4s	v7, v16, v7
     ec8:      	add	x9, x8, x10
     ecc:      	tbnz	w11, #0x0, 0xfc4 <ltmp0+0xfc4>
     ed0:      	and	w11, w11, #0xff
     ed4:      	tbnz	w11, #0x1, 0xfd0 <ltmp0+0xfd0>
     ed8:      	tbnz	w11, #0x2, 0xfdc <ltmp0+0xfdc>
     edc:      	tbz	w11, #0x3, 0xee8 <ltmp0+0xee8>
     ee0:      	add	x12, x9, #0xc
     ee4:      	st1.s	{ v7 }[3], [x12]
     ee8:      	and.16b	v5, v0, v5
     eec:      	fneg.4s	v7, v5
     ef0:      	and.16b	v7, v0, v7
     ef4:      	fcmge.4s	v16, v7, v3
     ef8:      	fcmge.4s	v17, v4, v7
     efc:      	and.16b	v16, v16, v17
     f00:      	and.16b	v16, v16, v7
     f04:      	fmul.4s	v17, v16, v20
     f08:      	mov.16b	v18, v22
     f0c:      	bsl.16b	v18, v21, v17
     f10:      	fadd.4s	v17, v17, v18
     f14:      	fsub.4s	v17, v17, v18
     f18:      	fcvtzs.4s	v17, v17
     f1c:      	scvtf.4s	v18, v17
     f20:      	fmul.4s	v19, v18, v23
     f24:      	fadd.4s	v16, v16, v19
     f28:      	fmul.4s	v18, v18, v24
     f2c:      	fadd.4s	v16, v16, v18
     f30:      	fmul.4s	v18, v16, v25
     f34:      	fadd.4s	v18, v18, v26
     f38:      	fmul.4s	v18, v16, v18
     f3c:      	fadd.4s	v18, v18, v27
     f40:      	fmul.4s	v18, v16, v18
     f44:      	fadd.4s	v18, v18, v28
     f48:      	fmul.4s	v18, v16, v18
     f4c:      	fadd.4s	v18, v18, v8
     f50:      	fmul.4s	v18, v16, v18
     f54:      	fadd.4s	v18, v18, v29
     f58:      	fmul.4s	v19, v16, v16
     f5c:      	fmul.4s	v18, v19, v18
     f60:      	fadd.4s	v16, v16, v18
     f64:      	fadd.4s	v16, v16, v30
     f68:      	sshr.4s	v18, v17, #0x1
     f6c:      	shl.4s	v19, v18, #0x17
     f70:      	add.4s	v19, v19, v30
     f74:      	fmul.4s	v16, v16, v19
     f78:      	sub.4s	v17, v17, v18
     f7c:      	shl.4s	v17, v17, #0x17
     f80:      	add.4s	v17, v17, v30
     f84:      	fmul.4s	v16, v16, v17
     f88:      	fcmgt.4s	v3, v3, v7
     f8c:      	fcmgt.4s	v4, v7, v4
     f90:      	fcmeq.4s	v7, v7, v7
     f94:      	fadd.4s	v16, v16, v30
     f98:      	bsl.16b	v3, v30, v16
     f9c:      	bit.16b	v3, v31, v4
     fa0:      	bif.16b	v3, v9, v7
     fa4:      	fdiv.4s	v3, v5, v3
     fa8:      	and.16b	v4, v0, v6
     fac:      	fmul.4s	v3, v4, v3
     fb0:      	tbnz	w11, #0x4, 0xfec <ltmp0+0xfec>
     fb4:      	tbnz	w11, #0x5, 0xff4 <ltmp0+0xff4>
     fb8:      	tbnz	w11, #0x6, 0x1000 <ltmp0+0x1000>
     fbc:      	tbz	w11, #0x7, 0xdd8 <ltmp0+0xdd8>
     fc0:      	b	0x100c <ltmp0+0x100c>
     fc4:      	str	s7, [x9]
     fc8:      	and	w11, w11, #0xff
     fcc:      	tbz	w11, #0x1, 0xed8 <ltmp0+0xed8>
     fd0:      	add	x12, x9, #0x4
     fd4:      	st1.s	{ v7 }[1], [x12]
     fd8:      	tbz	w11, #0x2, 0xedc <ltmp0+0xedc>
     fdc:      	add	x12, x9, #0x8
     fe0:      	st1.s	{ v7 }[2], [x12]
     fe4:      	tbnz	w11, #0x3, 0xee0 <ltmp0+0xee0>
     fe8:      	b	0xee8 <ltmp0+0xee8>
     fec:      	str	s3, [x9, #0x10]
     ff0:      	tbz	w11, #0x5, 0xfb8 <ltmp0+0xfb8>
     ff4:      	add	x12, x9, #0x14
     ff8:      	st1.s	{ v3 }[1], [x12]
     ffc:      	tbz	w11, #0x6, 0xfbc <ltmp0+0xfbc>
    1000:      	add	x12, x9, #0x18
    1004:      	st1.s	{ v3 }[2], [x12]
    1008:      	tbz	w11, #0x7, 0xdd8 <ltmp0+0xdd8>
    100c:      	add	x9, x9, #0x1c
    1010:      	st1.s	{ v3 }[3], [x9]
    1014:      	b	0xdd8 <ltmp0+0xdd8>
    1018:      	ldr	x9, [sp, #0x10]
    101c:      	stp	w1, w13, [x9]
    1020:      	str	w12, [x9, #0x8]
    1024:      	mov	w8, #0x18               ; =24
    1028:      	str	w8, [x9, #0x24]
    102c:      	add	sp, sp, #0x1, lsl #12   ; =0x1000
    1030:      	add	sp, sp, #0x930
    1034:      	ldp	x29, x30, [sp, #0x60]
    1038:      	ldp	x20, x19, [sp, #0x50]
    103c:      	ldp	x22, x21, [sp, #0x40]
    1040:      	ldp	x24, x23, [sp, #0x30]
    1044:      	ldp	x26, x25, [sp, #0x20]
    1048:      	ldp	x28, x27, [sp, #0x10]
    104c:      	ldp	d9, d8, [sp], #0x70
    1050:      	ret

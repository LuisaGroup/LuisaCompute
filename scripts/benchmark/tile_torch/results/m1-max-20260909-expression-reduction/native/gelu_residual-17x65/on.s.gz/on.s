
/private/tmp/luisa-expression-fusion.qXgTbC/capture/gelu_residual-17x65/on/object/tile_xir_w8_23458_1788930270767890_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0x50]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	sub	sp, sp, #0x360
      18:      	mov	x10, #0x0               ; =0
      1c:      	ldr	x13, [x0]
      20:      	ldr	x11, [x0, #0x10]
      24:      	ldr	x8, [x0, #0x30]
      28:      	ldr	w9, [x1]
      2c:      	ldr	w12, [x1, #0x24]
      30:      	add	w9, w12, w9, lsl #5
      34:      	lsr	w9, w9, #3
      38:      	fmov	s0, w9
      3c:      	ushll.2d	v0, v0, #0x0
      40:      	fmov	x9, d0
      44:      	add	x9, x9, x9, lsl #6
      48:      	lsl	x12, x9, #2
      4c:      	add	x9, x13, x12
      50:      	ldp	q0, q1, [x9, #0xc0]
      54:      	stp	q0, q1, [sp, #0x300]
      58:      	ldp	q0, q1, [x9, #0xe0]
      5c:      	stp	q0, q1, [sp, #0x320]
      60:      	ldp	q0, q1, [x9, #0x80]
      64:      	stp	q0, q1, [sp, #0x2c0]
      68:      	ldp	q0, q1, [x9, #0xa0]
      6c:      	stp	q0, q1, [sp, #0x2e0]
      70:      	ldp	q0, q1, [x9, #0x40]
      74:      	stp	q0, q1, [sp, #0x280]
      78:      	ldp	q0, q1, [x9, #0x60]
      7c:      	stp	q0, q1, [sp, #0x2a0]
      80:      	ldp	q0, q1, [x9]
      84:      	stp	q0, q1, [sp, #0x240]
      88:      	ldp	q0, q1, [x9, #0x20]
      8c:      	stp	q0, q1, [sp, #0x260]
      90:      	add	x9, x12, #0x100
      94:      	ldr	s0, [x13, x9]
      98:      	str	q0, [sp, #0x10]
      9c:      	str	q0, [sp, #0x340]
      a0:      	add	x13, x11, x12
      a4:      	ldp	q0, q1, [x13, #0xc0]
      a8:      	stp	q0, q1, [sp, #0x1e0]
      ac:      	ldp	q0, q1, [x13, #0xe0]
      b0:      	stp	q0, q1, [sp, #0x200]
      b4:      	ldp	q0, q1, [x13, #0x80]
      b8:      	stp	q0, q1, [sp, #0x1a0]
      bc:      	ldp	q0, q1, [x13, #0xa0]
      c0:      	stp	q0, q1, [sp, #0x1c0]
      c4:      	ldp	q0, q1, [x13, #0x40]
      c8:      	stp	q0, q1, [sp, #0x160]
      cc:      	ldp	q0, q1, [x13, #0x60]
      d0:      	stp	q0, q1, [sp, #0x180]
      d4:      	ldp	q3, q4, [x13]
      d8:      	ldp	q1, q2, [x13, #0x20]
      dc:      	ldr	s0, [x11, x9]
      e0:      	add	x11, x8, x12
      e4:      	add	x12, sp, #0x240
      e8:      	mov	w13, #0x2713            ; =10003
      ec:      	movk	w13, #0x3d37, lsl #16
      f0:      	dup.4s	v6, w13
      f4:      	mov	w13, #0x422a            ; =16938
      f8:      	movk	w13, #0x3f4c, lsl #16
      fc:      	dup.4s	v5, w13
     100:      	stp	q5, q6, [sp, #0xf0]
     104:      	fmov.4s	v19, #1.00000000
     108:      	mov	w13, #0x9231            ; =37425
     10c:      	movk	w13, #0x2f30, lsl #16
     110:      	dup.4s	v6, w13
     114:      	mov	w13, #0x322b            ; =12843
     118:      	movk	w13, #0x32d7, lsl #16
     11c:      	dup.4s	v5, w13
     120:      	stp	q5, q6, [sp, #0xd0]
     124:      	mov	w13, #0xef1d            ; =61213
     128:      	movk	w13, #0x3638, lsl #16
     12c:      	dup.4s	v6, w13
     130:      	mov	w13, #0xd01             ; =3329
     134:      	movk	w13, #0x3950, lsl #16
     138:      	dup.4s	v5, w13
     13c:      	stp	q5, q6, [sp, #0xb0]
     140:      	mov	w13, #0x8889            ; =34953
     144:      	movk	w13, #0x3c08, lsl #16
     148:      	dup.4s	v6, w13
     14c:      	mov	w13, #0xaaab            ; =43691
     150:      	movk	w13, #0x3e2a, lsl #16
     154:      	dup.4s	v22, w13
     158:      	mov	w13, #0x76c7            ; =30407
     15c:      	movk	w13, #0x310f, lsl #16
     160:      	dup.4s	v5, w13
     164:      	stp	q5, q6, [sp, #0x90]
     168:      	mov	w13, #0xf27e            ; =62078
     16c:      	movk	w13, #0x3493, lsl #16
     170:      	dup.4s	v6, w13
     174:      	mov	w13, #0xd01             ; =3329
     178:      	movk	w13, #0x37d0, lsl #16
     17c:      	dup.4s	v5, w13
     180:      	stp	q5, q6, [sp, #0x70]
     184:      	mov	w13, #0xb61             ; =2913
     188:      	movk	w13, #0x3ab6, lsl #16
     18c:      	dup.4s	v6, w13
     190:      	mov	w13, #0xaaab            ; =43691
     194:      	movk	w13, #0x3d2a, lsl #16
     198:      	dup.4s	v5, w13
     19c:      	stp	q5, q6, [sp, #0x50]
     1a0:      	mov	w13, #-0x3d300000       ; =-1026555904
     1a4:      	dup.4s	v6, w13
     1a8:      	mov	w13, #0x42c80000        ; =1120403456
     1ac:      	dup.4s	v27, w13
     1b0:      	fmov.4s	v5, #9.00000000
     1b4:      	str	q5, [sp, #0x110]
     1b8:      	mov	w13, #0xaa3b            ; =43579
     1bc:      	movk	w13, #0x3fb8, lsl #16
     1c0:      	dup.4s	v5, w13
     1c4:      	stp	q5, q6, [sp, #0x30]
     1c8:      	mov	w13, #0x7200            ; =29184
     1cc:      	movk	w13, #0xbf31, lsl #16
     1d0:      	dup.4s	v5, w13
     1d4:      	str	q5, [sp, #0x20]
     1d8:      	mov	w13, #0xbe8e            ; =48782
     1dc:      	movk	w13, #0xb5bf, lsl #16
     1e0:      	dup.4s	v8, w13
     1e4:      	mov	w13, #0x2bda            ; =11226
     1e8:      	movk	w13, #0x3950, lsl #16
     1ec:      	dup.4s	v9, w13
     1f0:      	mov	w13, #0x96c9            ; =38601
     1f4:      	movk	w13, #0x3ab6, lsl #16
     1f8:      	dup.4s	v10, w13
     1fc:      	mov	w13, #0x88a6            ; =34982
     200:      	movk	w13, #0x3c08, lsl #16
     204:      	dup.4s	v11, w13
     208:      	mov	w13, #0xaa7a            ; =43642
     20c:      	movk	w13, #0x3d2a, lsl #16
     210:      	stp	q3, q4, [sp, #0x120]
     214:      	mvni.4s	v3, #0x7f, msl #16
     218:      	fneg.4s	v13, v3
     21c:      	stp	q1, q2, [sp, #0x140]
     220:      	mvni.4s	v1, #0x3f, msl #16
     224:      	dup.4s	v14, w13
     228:      	fneg.4s	v15, v1
     22c:      	add	x13, sp, #0x120
     230:      	str	q0, [sp]
     234:      	str	q0, [sp, #0x220]
     238:      	add	x14, x12, x10
     23c:      	ldp	q29, q30, [x14]
     240:      	ldp	q0, q3, [sp, #0xf0]
     244:      	fmul.4s	v1, v29, v3
     248:      	fmul.4s	v2, v30, v3
     24c:      	fmul.4s	v2, v30, v2
     250:      	fmul.4s	v1, v29, v1
     254:      	fmul.4s	v1, v29, v1
     258:      	fmul.4s	v2, v30, v2
     25c:      	fadd.4s	v2, v30, v2
     260:      	fadd.4s	v1, v29, v1
     264:      	fmul.4s	v1, v1, v0
     268:      	fmul.4s	v12, v2, v0
     26c:      	fabs.4s	v4, v12
     270:      	fabs.4s	v3, v1
     274:      	fmul.4s	v18, v1, v1
     278:      	ldp	q5, q0, [sp, #0xd0]
     27c:      	mov.16b	v2, v5
     280:      	fmul.4s	v21, v12, v12
     284:      	fmla.4s	v2, v18, v0
     288:      	fmla.4s	v5, v21, v0
     28c:      	ldp	q0, q7, [sp, #0xb0]
     290:      	mov.16b	v6, v7
     294:      	fmla.4s	v6, v18, v2
     298:      	fmla.4s	v7, v21, v5
     29c:      	mov.16b	v5, v0
     2a0:      	fmla.4s	v5, v18, v6
     2a4:      	mov.16b	v6, v0
     2a8:      	ldr	q0, [sp, #0xa0]
     2ac:      	mov.16b	v16, v0
     2b0:      	fmla.4s	v6, v21, v7
     2b4:      	mov.16b	v7, v0
     2b8:      	mov.16b	v20, v22
     2bc:      	mov.16b	v17, v22
     2c0:      	mov.16b	v2, v19
     2c4:      	mov.16b	v26, v19
     2c8:      	fmla.4s	v16, v18, v5
     2cc:      	ldp	q23, q0, [sp, #0x80]
     2d0:      	mov.16b	v5, v23
     2d4:      	fmla.4s	v5, v21, v0
     2d8:      	fmla.4s	v23, v18, v0
     2dc:      	ldr	q0, [sp, #0x70]
     2e0:      	mov.16b	v24, v0
     2e4:      	fmla.4s	v7, v21, v6
     2e8:      	fmla.4s	v24, v21, v5
     2ec:      	mov.16b	v5, v0
     2f0:      	fmla.4s	v5, v18, v23
     2f4:      	ldp	q23, q0, [sp, #0x50]
     2f8:      	mov.16b	v6, v0
     2fc:      	fmla.4s	v6, v21, v24
     300:      	fmla.4s	v20, v18, v16
     304:      	mov.16b	v16, v0
     308:      	fmla.4s	v16, v18, v5
     30c:      	mov.16b	v5, v23
     310:      	fmla.4s	v5, v21, v6
     314:      	fmla.4s	v17, v21, v7
     318:      	fmla.4s	v23, v18, v16
     31c:      	movi.4s	v24, #0x3f, lsl #24
     320:      	fmla.4s	v24, v21, v5
     324:      	movi.4s	v25, #0x3f, lsl #24
     328:      	mov.16b	v7, v19
     32c:      	fmla.4s	v26, v21, v17
     330:      	mov.16b	v0, v19
     334:      	ldr	q6, [sp, #0x110]
     338:      	fcmge.4s	v5, v6, v3
     33c:      	fcmge.4s	v6, v6, v4
     340:      	and.16b	v16, v6, v4
     344:      	and.16b	v17, v5, v3
     348:      	fmla.4s	v7, v21, v24
     34c:      	ldr	q24, [sp, #0x40]
     350:      	fcmge.4s	v21, v17, v24
     354:      	fcmge.4s	v24, v16, v24
     358:      	fcmge.4s	v28, v27, v16
     35c:      	and.16b	v24, v24, v28
     360:      	fcmge.4s	v28, v27, v17
     364:      	fmla.4s	v25, v18, v23
     368:      	and.16b	v21, v21, v28
     36c:      	and.16b	v21, v21, v17
     370:      	and.16b	v23, v24, v16
     374:      	ldr	q28, [sp, #0x30]
     378:      	fmul.4s	v24, v23, v28
     37c:      	fmul.4s	v28, v21, v28
     380:      	fmla.4s	v2, v18, v20
     384:      	movi.4s	v31, #0x4b, lsl #24
     388:      	fadd.4s	v20, v28, v31
     38c:      	fadd.4s	v24, v24, v31
     390:      	movi.4s	v28, #0xcb, lsl #24
     394:      	fadd.4s	v24, v24, v28
     398:      	fadd.4s	v20, v20, v28
     39c:      	fcvtzs.4s	v20, v20
     3a0:      	fmla.4s	v0, v18, v25
     3a4:      	fcvtzs.4s	v24, v24
     3a8:      	scvtf.4s	v18, v24
     3ac:      	scvtf.4s	v25, v20
     3b0:      	ldr	q31, [sp, #0x20]
     3b4:      	fmul.4s	v28, v18, v31
     3b8:      	fadd.4s	v23, v23, v28
     3bc:      	fmul.4s	v28, v25, v31
     3c0:      	fadd.4s	v21, v21, v28
     3c4:      	fmul.4s	v18, v18, v8
     3c8:      	fmul.4s	v25, v25, v8
     3cc:      	fadd.4s	v21, v21, v25
     3d0:      	fadd.4s	v23, v23, v18
     3d4:      	fmul.4s	v18, v23, v9
     3d8:      	fmul.4s	v25, v21, v9
     3dc:      	fadd.4s	v25, v25, v10
     3e0:      	fadd.4s	v18, v18, v10
     3e4:      	fmul.4s	v18, v23, v18
     3e8:      	fmul.4s	v25, v21, v25
     3ec:      	fmul.4s	v2, v3, v2
     3f0:      	fadd.4s	v25, v25, v11
     3f4:      	fadd.4s	v18, v18, v11
     3f8:      	fmul.4s	v28, v23, v18
     3fc:      	fmul.4s	v18, v21, v25
     400:      	fadd.4s	v25, v18, v14
     404:      	fdiv.4s	v18, v2, v0
     408:      	fadd.4s	v0, v28, v14
     40c:      	fmul.4s	v0, v23, v0
     410:      	fmul.4s	v2, v21, v25
     414:      	fadd.4s	v2, v2, v22
     418:      	fadd.4s	v0, v0, v22
     41c:      	fmul.4s	v0, v23, v0
     420:      	fmul.4s	v2, v21, v2
     424:      	movi.4s	v28, #0x3f, lsl #24
     428:      	fadd.4s	v2, v2, v28
     42c:      	fadd.4s	v0, v0, v28
     430:      	fmul.4s	v25, v23, v23
     434:      	fmul.4s	v0, v25, v0
     438:      	fmul.4s	v25, v21, v21
     43c:      	fmul.4s	v2, v25, v2
     440:      	fadd.4s	v2, v21, v2
     444:      	fadd.4s	v0, v23, v0
     448:      	fadd.4s	v0, v0, v19
     44c:      	movi.2d	v21, #0xffffffffffffffff
     450:      	add.4s	v20, v20, v21
     454:      	fadd.4s	v2, v2, v19
     458:      	add.4s	v21, v24, v21
     45c:      	sshr.4s	v23, v21, #0x1
     460:      	sshr.4s	v24, v20, #0x1
     464:      	shl.4s	v25, v24, #0x17
     468:      	add.4s	v25, v25, v19
     46c:      	fmul.4s	v2, v2, v25
     470:      	shl.4s	v25, v23, #0x17
     474:      	add.4s	v25, v25, v19
     478:      	fmul.4s	v0, v0, v25
     47c:      	sub.4s	v20, v20, v24
     480:      	sub.4s	v21, v21, v23
     484:      	shl.4s	v21, v21, #0x17
     488:      	add.4s	v21, v21, v19
     48c:      	fmul.4s	v0, v0, v21
     490:      	shl.4s	v20, v20, #0x17
     494:      	add.4s	v20, v20, v19
     498:      	fmul.4s	v2, v2, v20
     49c:      	fmul.4s	v20, v4, v26
     4a0:      	fcmgt.4s	v16, v16, v27
     4a4:      	fcmgt.4s	v17, v17, v27
     4a8:      	bsl.16b	v17, v13, v2
     4ac:      	bit.16b	v0, v13, v16
     4b0:      	fmov.4s	v2, #0.25000000
     4b4:      	fdiv.4s	v7, v20, v7
     4b8:      	fdiv.4s	v16, v2, v0
     4bc:      	fsub.4s	v20, v0, v16
     4c0:      	fadd.4s	v0, v0, v16
     4c4:      	fdiv.4s	v0, v20, v0
     4c8:      	bif.16b	v0, v19, v6
     4cc:      	fcmge.4s	v4, v19, v4
     4d0:      	bit.16b	v0, v7, v4
     4d4:      	fdiv.4s	v4, v2, v17
     4d8:      	fsub.4s	v6, v17, v4
     4dc:      	fadd.4s	v4, v17, v4
     4e0:      	fdiv.4s	v4, v6, v4
     4e4:      	bif.16b	v4, v19, v5
     4e8:      	fcmge.4s	v3, v19, v3
     4ec:      	bsl.16b	v3, v18, v4
     4f0:      	mvni.4s	v4, #0x80, lsl #24
     4f4:      	bif.16b	v3, v1, v4
     4f8:      	fcmeq.4s	v1, v1, v1
     4fc:      	fadd.4s	v3, v3, v19
     500:      	bsl.16b	v1, v3, v15
     504:      	bif.16b	v0, v12, v4
     508:      	fcmeq.4s	v3, v12, v12
     50c:      	fadd.4s	v0, v0, v19
     510:      	bif.16b	v0, v15, v3
     514:      	fmul.4s	v3, v30, v28
     518:      	fmul.4s	v0, v3, v0
     51c:      	fmul.4s	v3, v29, v28
     520:      	fmul.4s	v1, v3, v1
     524:      	add	x14, x13, x10
     528:      	ldp	q4, q3, [x14]
     52c:      	fadd.4s	v1, v4, v1
     530:      	fadd.4s	v0, v3, v0
     534:      	add	x14, x11, x10
     538:      	stp	q1, q0, [x14]
     53c:      	add	x10, x10, #0x20
     540:      	cmp	x10, #0x100
     544:      	b.ne	0x238 <ltmp0+0x238>
     548:      	movi.2d	v1, #0000000000000000
     54c:      	movi.2d	v0, #0000000000000000
     550:      	ldr	q23, [sp, #0x10]
     554:      	mov.s	v0[0], v23[0]
     558:      	mov	w10, #0x2713            ; =10003
     55c:      	movk	w10, #0x3d37, lsl #16
     560:      	fmov	s3, w10
     564:      	fmul.4s	v0, v0, v3
     568:      	fmul.4s	v0, v23, v0
     56c:      	fmul.4s	v0, v23, v0
     570:      	fadd.4s	v0, v23, v0
     574:      	mov	w10, #0x422a            ; =16938
     578:      	movk	w10, #0x3f4c, lsl #16
     57c:      	fmov	s3, w10
     580:      	fmul.4s	v0, v0, v3
     584:      	mov.s	v1[0], v0[0]
     588:      	fabs.4s	v3, v1
     58c:      	mov	w10, #0x9231            ; =37425
     590:      	movk	w10, #0x2f30, lsl #16
     594:      	dup.4s	v0, w10
     598:      	mov	w10, #0x322b            ; =12843
     59c:      	movk	w10, #0x32d7, lsl #16
     5a0:      	dup.4s	v5, w10
     5a4:      	fmul.4s	v4, v1, v1
     5a8:      	fmla.4s	v5, v4, v0
     5ac:      	mov	w10, #0xef1d            ; =61213
     5b0:      	movk	w10, #0x3638, lsl #16
     5b4:      	dup.4s	v0, w10
     5b8:      	fmla.4s	v0, v4, v5
     5bc:      	mov	w10, #0xd01             ; =3329
     5c0:      	movk	w10, #0x3950, lsl #16
     5c4:      	dup.4s	v5, w10
     5c8:      	mov	w10, #0x8889            ; =34953
     5cc:      	movk	w10, #0x3c08, lsl #16
     5d0:      	dup.4s	v16, w10
     5d4:      	fmla.4s	v5, v4, v0
     5d8:      	fmla.4s	v16, v4, v5
     5dc:      	mov	w10, #0xaaab            ; =43691
     5e0:      	movk	w10, #0x3e2a, lsl #16
     5e4:      	dup.4s	v17, w10
     5e8:      	ldr	q0, [sp, #0x110]
     5ec:      	fcmge.4s	v5, v0, v3
     5f0:      	and.16b	v6, v5, v3
     5f4:      	mov	w10, #-0x3d300000       ; =-1026555904
     5f8:      	dup.4s	v0, w10
     5fc:      	fcmge.4s	v0, v6, v0
     600:      	mov	w10, #0x42c80000        ; =1120403456
     604:      	dup.4s	v7, w10
     608:      	fcmge.4s	v18, v7, v6
     60c:      	and.16b	v0, v0, v18
     610:      	and.16b	v0, v0, v6
     614:      	mov	w10, #0xaa3b            ; =43579
     618:      	movk	w10, #0x3fb8, lsl #16
     61c:      	dup.4s	v18, w10
     620:      	fmul.4s	v18, v0, v18
     624:      	movi.4s	v20, #0x4b, lsl #24
     628:      	fadd.4s	v18, v18, v20
     62c:      	movi.4s	v20, #0xcb, lsl #24
     630:      	fadd.4s	v18, v18, v20
     634:      	fcvtzs.4s	v18, v18
     638:      	scvtf.4s	v20, v18
     63c:      	mov	w10, #0x7200            ; =29184
     640:      	movk	w10, #0xbf31, lsl #16
     644:      	dup.4s	v21, w10
     648:      	fmul.4s	v21, v20, v21
     64c:      	fadd.4s	v0, v0, v21
     650:      	mov	w10, #0xbe8e            ; =48782
     654:      	movk	w10, #0xb5bf, lsl #16
     658:      	dup.4s	v21, w10
     65c:      	fmul.4s	v20, v20, v21
     660:      	fadd.4s	v0, v0, v20
     664:      	mov	w10, #0x2bda            ; =11226
     668:      	movk	w10, #0x3950, lsl #16
     66c:      	dup.4s	v20, w10
     670:      	fmul.4s	v20, v0, v20
     674:      	mov	w10, #0x96c9            ; =38601
     678:      	movk	w10, #0x3ab6, lsl #16
     67c:      	dup.4s	v21, w10
     680:      	fadd.4s	v20, v20, v21
     684:      	mov	w10, #0x88a6            ; =34982
     688:      	movk	w10, #0x3c08, lsl #16
     68c:      	dup.4s	v21, w10
     690:      	fmul.4s	v20, v0, v20
     694:      	fadd.4s	v20, v20, v21
     698:      	fmul.4s	v20, v0, v20
     69c:      	mov	w10, #0xaa7a            ; =43642
     6a0:      	movk	w10, #0x3d2a, lsl #16
     6a4:      	dup.4s	v21, w10
     6a8:      	fadd.4s	v20, v20, v21
     6ac:      	fmul.4s	v20, v0, v20
     6b0:      	fadd.4s	v20, v20, v17
     6b4:      	fmla.4s	v17, v4, v16
     6b8:      	mov.16b	v16, v19
     6bc:      	mov	w10, #0x76c7            ; =30407
     6c0:      	movk	w10, #0x310f, lsl #16
     6c4:      	dup.4s	v21, w10
     6c8:      	mov	w10, #0xf27e            ; =62078
     6cc:      	movk	w10, #0x3493, lsl #16
     6d0:      	dup.4s	v22, w10
     6d4:      	fmla.4s	v16, v4, v17
     6d8:      	fmla.4s	v22, v4, v21
     6dc:      	mov	w10, #0xd01             ; =3329
     6e0:      	movk	w10, #0x37d0, lsl #16
     6e4:      	dup.4s	v17, w10
     6e8:      	fmla.4s	v17, v4, v22
     6ec:      	mov	w10, #0xb61             ; =2913
     6f0:      	movk	w10, #0x3ab6, lsl #16
     6f4:      	dup.4s	v21, w10
     6f8:      	mov	w10, #0xaaab            ; =43691
     6fc:      	movk	w10, #0x3d2a, lsl #16
     700:      	dup.4s	v22, w10
     704:      	fmla.4s	v21, v4, v17
     708:      	fmla.4s	v22, v4, v21
     70c:      	movi.4s	v17, #0x3f, lsl #24
     710:      	fmla.4s	v17, v4, v22
     714:      	mov.16b	v21, v19
     718:      	fmla.4s	v21, v4, v17
     71c:      	movi.4s	v4, #0x3f, lsl #24
     720:      	fmul.4s	v17, v23, v4
     724:      	fcmge.4s	v22, v19, v3
     728:      	fmul.4s	v3, v3, v16
     72c:      	fdiv.4s	v3, v3, v21
     730:      	fmul.4s	v16, v0, v20
     734:      	fadd.4s	v4, v16, v4
     738:      	fmul.4s	v16, v0, v0
     73c:      	fmul.4s	v4, v16, v4
     740:      	fadd.4s	v0, v0, v4
     744:      	fadd.4s	v0, v0, v19
     748:      	movi.2d	v4, #0xffffffffffffffff
     74c:      	add.4s	v4, v18, v4
     750:      	sshr.4s	v16, v4, #0x1
     754:      	shl.4s	v18, v16, #0x17
     758:      	add.4s	v18, v18, v19
     75c:      	fmul.4s	v0, v0, v18
     760:      	sub.4s	v4, v4, v16
     764:      	shl.4s	v4, v4, #0x17
     768:      	add.4s	v4, v4, v19
     76c:      	fmul.4s	v0, v0, v4
     770:      	fcmgt.4s	v4, v6, v7
     774:      	mvni.4s	v6, #0x7f, msl #16
     778:      	fneg.4s	v6, v6
     77c:      	bit.16b	v0, v6, v4
     780:      	fdiv.4s	v2, v2, v0
     784:      	fsub.4s	v4, v0, v2
     788:      	fadd.4s	v0, v0, v2
     78c:      	fdiv.4s	v0, v4, v0
     790:      	bif.16b	v0, v19, v5
     794:      	bit.16b	v0, v3, v22
     798:      	mvni.4s	v2, #0x80, lsl #24
     79c:      	bif.16b	v0, v1, v2
     7a0:      	fcmeq.4s	v1, v1, v1
     7a4:      	fadd.4s	v0, v0, v19
     7a8:      	mvni.4s	v2, #0x3f, msl #16
     7ac:      	fneg.4s	v2, v2
     7b0:      	bif.16b	v0, v2, v1
     7b4:      	fmul.4s	v0, v17, v0
     7b8:      	ldr	q1, [sp]
     7bc:      	fadd.4s	v0, v0, v1
     7c0:      	str	s0, [x8, x9]
     7c4:      	add	sp, sp, #0x360
     7c8:      	ldp	x28, x27, [sp, #0x40]
     7cc:      	ldp	d9, d8, [sp, #0x30]
     7d0:      	ldp	d11, d10, [sp, #0x20]
     7d4:      	ldp	d13, d12, [sp, #0x10]
     7d8:      	ldp	d15, d14, [sp], #0x50
     7dc:      	ret

00000000000007e0 <_llm_rows.packet_batch.blocks>:
     7e0:      	stp	d15, d14, [sp, #-0xa0]!
     7e4:      	stp	d13, d12, [sp, #0x10]
     7e8:      	stp	d11, d10, [sp, #0x20]
     7ec:      	stp	d9, d8, [sp, #0x30]
     7f0:      	stp	x28, x27, [sp, #0x40]
     7f4:      	stp	x26, x25, [sp, #0x50]
     7f8:      	stp	x24, x23, [sp, #0x60]
     7fc:      	stp	x22, x21, [sp, #0x70]
     800:      	stp	x20, x19, [sp, #0x80]
     804:      	stp	x29, x30, [sp, #0x90]
     808:      	sub	sp, sp, #0x540
     80c:      	str	x0, [sp, #0xf8]
     810:      	cbz	w3, 0x1878 <_llm_rows.packet_batch.blocks+0x1098>
     814:      	mov	x23, x3
     818:      	mov	x20, x2
     81c:      	mov	w22, #0x0               ; =0
     820:      	ldp	w9, w8, [x2, #0x2c]
     824:      	stp	w8, w9, [sp, #0xf0]
     828:      	adrp	x8, 0x0 <ltmp0>
     82c:      	ldr	q0, [x8]
     830:      	str	q0, [sp, #0x30]
     834:      	adrp	x8, 0x0 <ltmp0>
     838:      	ldr	q0, [x8]
     83c:      	str	q0, [sp, #0x20]
     840:      	add	x25, sp, #0x420
     844:      	adrp	x8, 0x0 <ltmp0>
     848:      	ldr	q0, [x8]
     84c:      	str	q0, [sp, #0x10]
     850:      	movi.2s	v8, #0x41
     854:      	add	x24, sp, #0x300
     858:      	mvni.4s	v0, #0x7f, msl #16
     85c:      	fneg.4s	v1, v0
     860:      	mvni.4s	v0, #0x3f, msl #16
     864:      	fneg.4s	v0, v0
     868:      	stp	q0, q1, [sp, #0x200]
     86c:      	ldp	w28, w21, [x2]
     870:      	mov	w30, #0xf27e            ; =62078
     874:      	movk	w30, #0x3493, lsl #16
     878:      	ldp	w26, w27, [x2, #0x8]
     87c:      	str	w3, [sp, #0xdc]
     880:      	b	0x8c8 <_llm_rows.packet_batch.blocks+0xe8>
     884:      	mov	w8, #0x18               ; =24
     888:      	str	w8, [x20, #0x24]
     88c:      	ldr	w23, [sp, #0xdc]
     890:      	add	w8, w28, #0x1
     894:      	ldp	w10, w9, [sp, #0xf0]
     898:      	cmp	w8, w9
     89c:      	cset	w8, eq
     8a0:      	csinc	w28, wzr, w28, eq
     8a4:      	cinc	w9, w21, eq
     8a8:      	cmp	w9, w10
     8ac:      	cset	w10, eq
     8b0:      	ands	w8, w8, w10
     8b4:      	csel	w21, wzr, w9, ne
     8b8:      	add	w26, w26, w8
     8bc:      	add	w22, w22, #0x1
     8c0:      	cmp	w22, w23
     8c4:      	b.eq	0x1878 <_llm_rows.packet_batch.blocks+0x1098>
     8c8:      	ubfiz	x8, x28, #5, #32
     8cc:      	cmp	x8, x27
     8d0:      	csel	x9, x8, xzr, ls
     8d4:      	subs	x10, x27, x9
     8d8:      	cmp	x10, #0x20
     8dc:      	mov	w11, #0x20              ; =32
     8e0:      	csel	x10, x10, x11, lo
     8e4:      	cmp	x27, x9
     8e8:      	stp	w28, w21, [x20]
     8ec:      	str	w26, [x20, #0x8]
     8f0:      	str	wzr, [x20, #0x24]
     8f4:      	ccmp	x8, x27, #0x2, hi
     8f8:      	csel	x19, x10, xzr, ls
     8fc:      	cmp	x19, #0x20
     900:      	b.lo	0x95c <_llm_rows.packet_batch.blocks+0x17c>
     904:      	ldr	x19, [sp, #0xf8]
     908:      	mov	x0, x19
     90c:      	mov	x1, x20
     910:      	bl	0x910 <_llm_rows.packet_batch.blocks+0x130>
     914:      	mov	w8, #0x8                ; =8
     918:      	str	w8, [x20, #0x24]
     91c:      	mov	x0, x19
     920:      	mov	x1, x20
     924:      	bl	0x924 <_llm_rows.packet_batch.blocks+0x144>
     928:      	mov	w8, #0x10               ; =16
     92c:      	str	w8, [x20, #0x24]
     930:      	mov	x0, x19
     934:      	mov	x1, x20
     938:      	bl	0x938 <_llm_rows.packet_batch.blocks+0x158>
     93c:      	mov	w8, #0x18               ; =24
     940:      	str	w8, [x20, #0x24]
     944:      	mov	x0, x19
     948:      	mov	x1, x20
     94c:      	bl	0x94c <_llm_rows.packet_batch.blocks+0x16c>
     950:      	mov	w30, #0xf27e            ; =62078
     954:      	movk	w30, #0x3493, lsl #16
     958:      	b	0x890 <_llm_rows.packet_batch.blocks+0xb0>
     95c:      	lsr	x23, x19, #3
     960:      	cmp	x19, #0x8
     964:      	b.lo	0x9c8 <_llm_rows.packet_batch.blocks+0x1e8>
     968:      	str	wzr, [x20, #0x24]
     96c:      	ldr	x0, [sp, #0xf8]
     970:      	mov	x1, x20
     974:      	bl	0x974 <_llm_rows.packet_batch.blocks+0x194>
     978:      	mov	w30, #0xf27e            ; =62078
     97c:      	movk	w30, #0x3493, lsl #16
     980:      	cmp	x23, #0x1
     984:      	b.eq	0x9c8 <_llm_rows.packet_batch.blocks+0x1e8>
     988:      	mov	w8, #0x8                ; =8
     98c:      	str	w8, [x20, #0x24]
     990:      	ldr	x0, [sp, #0xf8]
     994:      	mov	x1, x20
     998:      	bl	0x998 <_llm_rows.packet_batch.blocks+0x1b8>
     99c:      	mov	w30, #0xf27e            ; =62078
     9a0:      	movk	w30, #0x3493, lsl #16
     9a4:      	cmp	x23, #0x2
     9a8:      	b.eq	0x9c8 <_llm_rows.packet_batch.blocks+0x1e8>
     9ac:      	mov	w8, #0x10               ; =16
     9b0:      	str	w8, [x20, #0x24]
     9b4:      	ldr	x0, [sp, #0xf8]
     9b8:      	mov	x1, x20
     9bc:      	bl	0x9bc <_llm_rows.packet_batch.blocks+0x1dc>
     9c0:      	mov	w30, #0xf27e            ; =62078
     9c4:      	movk	w30, #0x3493, lsl #16
     9c8:      	and	w8, w19, #0x7
     9cc:      	cbz	w8, 0x884 <_llm_rows.packet_batch.blocks+0xa4>
     9d0:      	dup.4s	v0, w8
     9d4:      	ldp	q2, q1, [sp, #0x20]
     9d8:      	cmhi.4s	v30, v0, v2
     9dc:      	cmhi.4s	v9, v0, v1
     9e0:      	uzp1.8h	v0, v9, v30
     9e4:      	umaxv.8h	h1, v0
     9e8:      	fmov	w8, s1
     9ec:      	tbz	w8, #0x0, 0x884 <_llm_rows.packet_batch.blocks+0xa4>
     9f0:      	mov	x9, #0x0                ; =0
     9f4:      	ldr	x11, [sp, #0xf8]
     9f8:      	ldr	x12, [x11]
     9fc:      	ldr	x10, [x11, #0x10]
     a00:      	ubfiz	w8, w28, #2, #27
     a04:      	orr	w8, w8, w23
     a08:      	dup.4s	v1, w8
     a0c:      	ldr	x8, [x11, #0x30]
     a10:      	and.16b	v3, v9, v1
     a14:      	and.16b	v1, v30, v1
     a18:      	ushll2.2d	v2, v1, #0x0
     a1c:      	ushll2.2d	v4, v3, #0x0
     a20:      	ushll.2d	v6, v1, #0x0
     a24:      	ushll.2d	v3, v3, #0x0
     a28:      	fmov	x11, d3
     a2c:      	mov	w13, #0x104             ; =260
     a30:      	umaddl	x11, w11, w13, x12
     a34:      	ldr	q1, [sp, #0x10]
     a38:      	and.16b	v0, v0, v1
     a3c:      	addv.8h	h0, v0
     a40:      	str	q0, [sp, #0x140]
     a44:      	fmov	w13, s0
     a48:      	b	0xa6c <_llm_rows.packet_batch.blocks+0x28c>
     a4c:      	add	x14, x25, x9
     a50:      	ldp	q0, q1, [x14]
     a54:      	bit.16b	v1, v7, v30
     a58:      	bit.16b	v0, v5, v9
     a5c:      	stp	q0, q1, [x14]
     a60:      	add	x9, x9, #0x20
     a64:      	cmp	x9, #0x100
     a68:      	b.eq	0xb00 <_llm_rows.packet_batch.blocks+0x320>
     a6c:      	add	x14, x11, x9
     a70:      	movi.2d	v5, #0000000000000000
     a74:      	movi.2d	v7, #0000000000000000
     a78:      	tbnz	w13, #0x0, 0xaa0 <_llm_rows.packet_batch.blocks+0x2c0>
     a7c:      	and	w15, w13, #0xff
     a80:      	tbnz	w15, #0x1, 0xaac <_llm_rows.packet_batch.blocks+0x2cc>
     a84:      	tbnz	w15, #0x2, 0xab8 <_llm_rows.packet_batch.blocks+0x2d8>
     a88:      	tbnz	w15, #0x3, 0xac4 <_llm_rows.packet_batch.blocks+0x2e4>
     a8c:      	tbnz	w15, #0x4, 0xad0 <_llm_rows.packet_batch.blocks+0x2f0>
     a90:      	tbnz	w15, #0x5, 0xadc <_llm_rows.packet_batch.blocks+0x2fc>
     a94:      	tbnz	w15, #0x6, 0xae8 <_llm_rows.packet_batch.blocks+0x308>
     a98:      	tbz	w15, #0x7, 0xa4c <_llm_rows.packet_batch.blocks+0x26c>
     a9c:      	b	0xaf4 <_llm_rows.packet_batch.blocks+0x314>
     aa0:      	ldr	s5, [x14]
     aa4:      	and	w15, w13, #0xff
     aa8:      	tbz	w15, #0x1, 0xa84 <_llm_rows.packet_batch.blocks+0x2a4>
     aac:      	add	x16, x14, #0x4
     ab0:      	ld1.s	{ v5 }[1], [x16]
     ab4:      	tbz	w15, #0x2, 0xa88 <_llm_rows.packet_batch.blocks+0x2a8>
     ab8:      	add	x16, x14, #0x8
     abc:      	ld1.s	{ v5 }[2], [x16]
     ac0:      	tbz	w15, #0x3, 0xa8c <_llm_rows.packet_batch.blocks+0x2ac>
     ac4:      	add	x16, x14, #0xc
     ac8:      	ld1.s	{ v5 }[3], [x16]
     acc:      	tbz	w15, #0x4, 0xa90 <_llm_rows.packet_batch.blocks+0x2b0>
     ad0:      	add	x16, x14, #0x10
     ad4:      	ld1.s	{ v7 }[0], [x16]
     ad8:      	tbz	w15, #0x5, 0xa94 <_llm_rows.packet_batch.blocks+0x2b4>
     adc:      	add	x16, x14, #0x14
     ae0:      	ld1.s	{ v7 }[1], [x16]
     ae4:      	tbz	w15, #0x6, 0xa98 <_llm_rows.packet_batch.blocks+0x2b8>
     ae8:      	add	x16, x14, #0x18
     aec:      	ld1.s	{ v7 }[2], [x16]
     af0:      	tbz	w15, #0x7, 0xa4c <_llm_rows.packet_batch.blocks+0x26c>
     af4:      	add	x14, x14, #0x1c
     af8:      	ld1.s	{ v7 }[3], [x14]
     afc:      	b	0xa4c <_llm_rows.packet_batch.blocks+0x26c>
     b00:      	sshll.2d	v0, v9, #0x0
     b04:      	xtn.4h	v1, v9
     b08:      	uzp1.8b	v1, v1, v0
     b0c:      	movi.2d	v19, #0000000000000000
     b10:      	mov.b	v19[0], v1[0]
     b14:      	adrp	x9, 0x0 <ltmp0>
     b18:      	ldr	d5, [x9]
     b1c:      	and.8b	v7, v19, v5
     b20:      	addv.8b	b7, v7
     b24:      	fmov	w13, s7
     b28:      	umaxv.8b	b7, v19
     b2c:      	fmov	w14, s7
     b30:      	rbit	w9, w13
     b34:      	clz	w9, w9
     b38:      	tst	w14, #0x1
     b3c:      	csel	w9, w9, wzr, ne
     b40:      	mov	w11, #0x40              ; =64
     b44:      	dup.2d	v7, x11
     b48:      	adrp	x11, 0x0 <ltmp0>
     b4c:      	ldr	q16, [x11]
     b50:      	bif.16b	v16, v7, v0
     b54:      	xtn.2s	v3, v3
     b58:      	movi.2d	v0, #0000000000000000
     b5c:      	mov.b	v0[0], v1[0]
     b60:      	umlal.2d	v16, v3, v8
     b64:      	ushll.2d	v0, v0, #0x0
     b68:      	shl.2d	v0, v0, #0x3f
     b6c:      	cmlt.2d	v0, v0, #0
     b70:      	str	q16, [sp, #0xb0]
     b74:      	and.16b	v0, v0, v16
     b78:      	movi.2d	v1, #0000000000000000
     b7c:      	stp	q1, q1, [sp, #0x2d0]
     b80:      	stp	q0, q1, [sp, #0x2b0]
     b84:      	and	x11, x9, #0x7
     b88:      	add	x15, sp, #0x2b0
     b8c:      	ldr	x11, [x15, x11, lsl #3]
     b90:      	sub	x11, x11, x9
     b94:      	lsl	x11, x11, #2
     b98:      	add	x12, x12, x11
     b9c:      	movi.2d	v20, #0000000000000000
     ba0:      	movi.2d	v18, #0000000000000000
     ba4:      	tbz	w14, #0x0, 0xbac <_llm_rows.packet_batch.blocks+0x3cc>
     ba8:      	ldr	s20, [x12]
     bac:      	mov	w1, #0x2713             ; =10003
     bb0:      	movk	w1, #0x3d37, lsl #16
     bb4:      	mov	w2, #0x422a             ; =16938
     bb8:      	movk	w2, #0x3f4c, lsl #16
     bbc:      	mov	w3, #0x9231             ; =37425
     bc0:      	movk	w3, #0x2f30, lsl #16
     bc4:      	mov	w4, #0x322b             ; =12843
     bc8:      	movk	w4, #0x32d7, lsl #16
     bcc:      	mov	w5, #0xef1d             ; =61213
     bd0:      	movk	w5, #0x3638, lsl #16
     bd4:      	mov	w6, #0xd01              ; =3329
     bd8:      	movk	w6, #0x3950, lsl #16
     bdc:      	mov	w7, #0x8889             ; =34953
     be0:      	movk	w7, #0x3c08, lsl #16
     be4:      	mov	w19, #0xaaab            ; =43691
     be8:      	movk	w19, #0x3e2a, lsl #16
     bec:      	mov	w23, #0x76c7            ; =30407
     bf0:      	movk	w23, #0x310f, lsl #16
     bf4:      	tbnz	w13, #0x1, 0x175c <_llm_rows.packet_batch.blocks+0xf7c>
     bf8:      	tbnz	w13, #0x2, 0x1768 <_llm_rows.packet_batch.blocks+0xf88>
     bfc:      	tbnz	w13, #0x3, 0x1774 <_llm_rows.packet_batch.blocks+0xf94>
     c00:      	tbnz	w13, #0x4, 0x1780 <_llm_rows.packet_batch.blocks+0xfa0>
     c04:      	tbnz	w13, #0x5, 0x178c <_llm_rows.packet_batch.blocks+0xfac>
     c08:      	tbnz	w13, #0x6, 0x1798 <_llm_rows.packet_batch.blocks+0xfb8>
     c0c:      	tbz	w13, #0x7, 0xc18 <_llm_rows.packet_batch.blocks+0x438>
     c10:      	add	x12, x12, #0x1c
     c14:      	ld1.s	{ v18 }[3], [x12]
     c18:      	mov	x15, #0x0               ; =0
     c1c:      	sshll2.2d	v0, v30, #0x0
     c20:      	sshll2.2d	v1, v9, #0x0
     c24:      	sshll.2d	v16, v30, #0x0
     c28:      	adrp	x12, 0x0 <ltmp0>
     c2c:      	ldr	q17, [x12]
     c30:      	bif.16b	v17, v7, v16
     c34:      	adrp	x12, 0x0 <ltmp0>
     c38:      	ldr	q16, [x12]
     c3c:      	mov.16b	v21, v1
     c40:      	bsl.16b	v21, v16, v7
     c44:      	adrp	x12, 0x0 <ltmp0>
     c48:      	ldr	q16, [x12]
     c4c:      	bit.16b	v7, v16, v0
     c50:      	umull.2d	v3, v3, v8
     c54:      	xtn.2s	v4, v4
     c58:      	xtn.2s	v6, v6
     c5c:      	xtn.2s	v2, v2
     c60:      	umlal.2d	v7, v2, v8
     c64:      	umlal.2d	v21, v4, v8
     c68:      	stp	q7, q21, [sp, #0x70]
     c6c:      	adrp	x12, 0x0 <ltmp0>
     c70:      	ldr	q2, [x12]
     c74:      	mov	w12, #0x100             ; =256
     c78:      	dup.2d	v4, x12
     c7c:      	sshll.2d	v7, v9, #0x0
     c80:      	bif.16b	v2, v4, v7
     c84:      	adrp	x12, 0x0 <ltmp0>
     c88:      	ldr	q7, [x12]
     c8c:      	sshll.2d	v16, v30, #0x0
     c90:      	bif.16b	v7, v4, v16
     c94:      	adrp	x12, 0x0 <ltmp0>
     c98:      	ldr	q16, [x12]
     c9c:      	bsl.16b	v1, v16, v4
     ca0:      	adrp	x12, 0x0 <ltmp0>
     ca4:      	ldr	q16, [x12]
     ca8:      	bsl.16b	v0, v16, v4
     cac:      	stp	q7, q0, [sp, #0x290]
     cb0:      	stp	q2, q1, [sp, #0x270]
     cb4:      	and	x12, x9, #0x7
     cb8:      	add	x14, sp, #0x270
     cbc:      	ldr	x12, [x14, x12, lsl #3]
     cc0:      	umlal.2d	v17, v6, v8
     cc4:      	str	q17, [sp, #0x90]
     cc8:      	sub	x12, x12, x9, lsl #2
     ccc:      	tst	w13, #0xff
     cd0:      	csel	x12, xzr, x12, eq
     cd4:      	add	x13, x25, x12
     cd8:      	ldp	q0, q1, [x13]
     cdc:      	zip2.8b	v2, v19, v0
     ce0:      	ushll.4s	v2, v2, #0x0
     ce4:      	shl.4s	v2, v2, #0x1f
     ce8:      	cmlt.4s	v2, v2, #0
     cec:      	bit.16b	v1, v18, v2
     cf0:      	zip1.8b	v2, v19, v0
     cf4:      	ushll.4s	v2, v2, #0x0
     cf8:      	shl.4s	v2, v2, #0x1f
     cfc:      	cmlt.4s	v2, v2, #0
     d00:      	bit.16b	v0, v20, v2
     d04:      	stp	q0, q1, [x13]
     d08:      	fmov	x13, d3
     d0c:      	lsl	x13, x13, #2
     d10:      	add	x14, x10, x13
     d14:      	mov	w16, #0x1               ; =1
     d18:      	dup.2d	v0, x16
     d1c:      	ushll2.2d	v1, v30, #0x0
     d20:      	and.16b	v17, v1, v0
     d24:      	ushll2.2d	v1, v9, #0x0
     d28:      	and.16b	v22, v1, v0
     d2c:      	ushll.2d	v1, v30, #0x0
     d30:      	and.16b	v28, v1, v0
     d34:      	ushll.2d	v1, v9, #0x0
     d38:      	and.16b	v29, v1, v0
     d3c:      	movi.2d	v2, #0000000000000000
     d40:      	movi.2d	v3, #0000000000000000
     d44:      	movi.2d	v4, #0000000000000000
     d48:      	movi.2d	v6, #0000000000000000
     d4c:      	b	0xd80 <_llm_rows.packet_batch.blocks+0x5a0>
     d50:      	add	x15, x24, x15
     d54:      	ldp	q0, q1, [x15]
     d58:      	bit.16b	v1, v16, v30
     d5c:      	bit.16b	v0, v7, v9
     d60:      	stp	q0, q1, [x15]
     d64:      	add.2d	v3, v3, v22
     d68:      	add.2d	v4, v4, v28
     d6c:      	add.2d	v6, v6, v17
     d70:      	add.2d	v2, v2, v29
     d74:      	fmov	x15, d2
     d78:      	cmp	x15, #0x8
     d7c:      	b.ge	0xe20 <_llm_rows.packet_batch.blocks+0x640>
     d80:      	ldr	q0, [sp, #0x140]
     d84:      	fmov	w17, s0
     d88:      	lsl	x15, x15, #5
     d8c:      	add	x16, x14, x15
     d90:      	movi.2d	v7, #0000000000000000
     d94:      	movi.2d	v16, #0000000000000000
     d98:      	tbnz	w17, #0x0, 0xdc0 <_llm_rows.packet_batch.blocks+0x5e0>
     d9c:      	and	w17, w17, #0xff
     da0:      	tbnz	w17, #0x1, 0xdcc <_llm_rows.packet_batch.blocks+0x5ec>
     da4:      	tbnz	w17, #0x2, 0xdd8 <_llm_rows.packet_batch.blocks+0x5f8>
     da8:      	tbnz	w17, #0x3, 0xde4 <_llm_rows.packet_batch.blocks+0x604>
     dac:      	tbnz	w17, #0x4, 0xdf0 <_llm_rows.packet_batch.blocks+0x610>
     db0:      	tbnz	w17, #0x5, 0xdfc <_llm_rows.packet_batch.blocks+0x61c>
     db4:      	tbnz	w17, #0x6, 0xe08 <_llm_rows.packet_batch.blocks+0x628>
     db8:      	tbz	w17, #0x7, 0xd50 <_llm_rows.packet_batch.blocks+0x570>
     dbc:      	b	0xe14 <_llm_rows.packet_batch.blocks+0x634>
     dc0:      	ldr	s7, [x16]
     dc4:      	and	w17, w17, #0xff
     dc8:      	tbz	w17, #0x1, 0xda4 <_llm_rows.packet_batch.blocks+0x5c4>
     dcc:      	add	x0, x16, #0x4
     dd0:      	ld1.s	{ v7 }[1], [x0]
     dd4:      	tbz	w17, #0x2, 0xda8 <_llm_rows.packet_batch.blocks+0x5c8>
     dd8:      	add	x0, x16, #0x8
     ddc:      	ld1.s	{ v7 }[2], [x0]
     de0:      	tbz	w17, #0x3, 0xdac <_llm_rows.packet_batch.blocks+0x5cc>
     de4:      	add	x0, x16, #0xc
     de8:      	ld1.s	{ v7 }[3], [x0]
     dec:      	tbz	w17, #0x4, 0xdb0 <_llm_rows.packet_batch.blocks+0x5d0>
     df0:      	add	x0, x16, #0x10
     df4:      	ld1.s	{ v16 }[0], [x0]
     df8:      	tbz	w17, #0x5, 0xdb4 <_llm_rows.packet_batch.blocks+0x5d4>
     dfc:      	add	x0, x16, #0x14
     e00:      	ld1.s	{ v16 }[1], [x0]
     e04:      	tbz	w17, #0x6, 0xdb8 <_llm_rows.packet_batch.blocks+0x5d8>
     e08:      	add	x0, x16, #0x18
     e0c:      	ld1.s	{ v16 }[2], [x0]
     e10:      	tbz	w17, #0x7, 0xd50 <_llm_rows.packet_batch.blocks+0x570>
     e14:      	add	x16, x16, #0x1c
     e18:      	ld1.s	{ v16 }[3], [x16]
     e1c:      	b	0xd50 <_llm_rows.packet_batch.blocks+0x570>
     e20:      	add	x10, x10, x11
     e24:      	shl.8b	v0, v19, #0x7
     e28:      	cmlt.8b	v0, v0, #0
     e2c:      	and.8b	v0, v0, v5
     e30:      	addv.8b	b0, v0
     e34:      	str	d0, [sp, #0x48]
     e38:      	fmov	w11, s0
     e3c:      	movi.2d	v4, #0000000000000000
     e40:      	movi.2d	v3, #0000000000000000
     e44:      	tbnz	w11, #0x0, 0x17a8 <_llm_rows.packet_batch.blocks+0xfc8>
     e48:      	mov	w15, #0xb61             ; =2913
     e4c:      	movk	w15, #0x3ab6, lsl #16
     e50:      	mov	w16, #0xaaab            ; =43691
     e54:      	movk	w16, #0x3d2a, lsl #16
     e58:      	mov	w17, #-0x3d300000       ; =-1026555904
     e5c:      	tbnz	w11, #0x1, 0x17c4 <_llm_rows.packet_batch.blocks+0xfe4>
     e60:      	tbnz	w11, #0x2, 0x17d0 <_llm_rows.packet_batch.blocks+0xff0>
     e64:      	tbnz	w11, #0x3, 0x17dc <_llm_rows.packet_batch.blocks+0xffc>
     e68:      	tbnz	w11, #0x4, 0x17e8 <_llm_rows.packet_batch.blocks+0x1008>
     e6c:      	tbnz	w11, #0x5, 0x17f4 <_llm_rows.packet_batch.blocks+0x1014>
     e70:      	tbnz	w11, #0x6, 0x1800 <_llm_rows.packet_batch.blocks+0x1020>
     e74:      	mov	w14, #0xd01             ; =3329
     e78:      	movk	w14, #0x37d0, lsl #16
     e7c:      	str	q18, [sp, #0xc0]
     e80:      	str	q20, [sp, #0xa0]
     e84:      	tbz	w11, #0x7, 0xe90 <_llm_rows.packet_batch.blocks+0x6b0>
     e88:      	add	x10, x10, #0x1c
     e8c:      	ld1.s	{ v3 }[3], [x10]
     e90:      	mov	x11, #0x0               ; =0
     e94:      	add	x10, x24, x12
     e98:      	ldp	q0, q1, [x10]
     e9c:      	zip2.8b	v2, v19, v0
     ea0:      	ushll.4s	v2, v2, #0x0
     ea4:      	shl.4s	v2, v2, #0x1f
     ea8:      	cmlt.4s	v2, v2, #0
     eac:      	stp	q4, q3, [sp, #0x50]
     eb0:      	bit.16b	v1, v3, v2
     eb4:      	str	q19, [sp, #0xe0]
     eb8:      	zip1.8b	v2, v19, v0
     ebc:      	ushll.4s	v2, v2, #0x0
     ec0:      	shl.4s	v2, v2, #0x1f
     ec4:      	cmlt.4s	v2, v2, #0
     ec8:      	bit.16b	v0, v4, v2
     ecc:      	stp	q0, q1, [x10]
     ed0:      	add	x10, x8, x13
     ed4:      	movi.2d	v3, #0000000000000000
     ed8:      	movi.2d	v19, #0000000000000000
     edc:      	movi.2d	v20, #0000000000000000
     ee0:      	movi.2d	v21, #0000000000000000
     ee4:      	stp	q22, q17, [sp, #0x120]
     ee8:      	stp	q29, q28, [sp, #0x100]
     eec:      	b	0xf0c <_llm_rows.packet_batch.blocks+0x72c>
     ef0:      	add.2d	v19, v19, v22
     ef4:      	add.2d	v20, v20, v28
     ef8:      	add.2d	v21, v21, v17
     efc:      	add.2d	v3, v3, v29
     f00:      	fmov	x11, d3
     f04:      	cmp	x11, #0x8
     f08:      	b.ge	0x13b0 <_llm_rows.packet_batch.blocks+0xbd0>
     f0c:      	lsl	x11, x11, #5
     f10:      	add	x12, x25, x11
     f14:      	ldr	q0, [x12]
     f18:      	and.16b	v22, v9, v0
     f1c:      	dup.4s	v0, w1
     f20:      	str	q0, [sp, #0x1c0]
     f24:      	fmul.4s	v0, v22, v0
     f28:      	fmul.4s	v0, v22, v0
     f2c:      	fmul.4s	v0, v22, v0
     f30:      	fadd.4s	v0, v22, v0
     f34:      	dup.4s	v1, w2
     f38:      	str	q1, [sp, #0x1a0]
     f3c:      	fmul.4s	v0, v0, v1
     f40:      	and.16b	v0, v9, v0
     f44:      	fabs.4s	v1, v0
     f48:      	fmov.4s	v25, #1.00000000
     f4c:      	dup.4s	v5, w3
     f50:      	dup.4s	v4, w4
     f54:      	fmul.4s	v2, v0, v0
     f58:      	stp	q5, q4, [sp, #0x1e0]
     f5c:      	fmla.4s	v4, v2, v5
     f60:      	dup.4s	v5, w5
     f64:      	str	q5, [sp, #0x1d0]
     f68:      	fmla.4s	v5, v2, v4
     f6c:      	dup.4s	v4, w6
     f70:      	str	q4, [sp, #0x1b0]
     f74:      	dup.4s	v11, w7
     f78:      	fmla.4s	v4, v2, v5
     f7c:      	mov.16b	v5, v11
     f80:      	fmla.4s	v5, v2, v4
     f84:      	dup.4s	v26, w19
     f88:      	mov.16b	v4, v26
     f8c:      	fmla.4s	v4, v2, v5
     f90:      	mov.16b	v5, v25
     f94:      	fmla.4s	v5, v2, v4
     f98:      	fmul.4s	v4, v1, v5
     f9c:      	dup.4s	v6, w23
     fa0:      	dup.4s	v12, w30
     fa4:      	mov.16b	v5, v12
     fa8:      	str	q6, [sp, #0x190]
     fac:      	fmla.4s	v5, v2, v6
     fb0:      	dup.4s	v14, w14
     fb4:      	mov.16b	v6, v14
     fb8:      	fmla.4s	v6, v2, v5
     fbc:      	dup.4s	v15, w15
     fc0:      	mov.16b	v5, v15
     fc4:      	fmla.4s	v5, v2, v6
     fc8:      	dup.4s	v8, w16
     fcc:      	mov.16b	v6, v8
     fd0:      	fmla.4s	v6, v2, v5
     fd4:      	movi.4s	v5, #0x3f, lsl #24
     fd8:      	fmla.4s	v5, v2, v6
     fdc:      	mov.16b	v6, v25
     fe0:      	fmla.4s	v6, v2, v5
     fe4:      	fdiv.4s	v29, v4, v6
     fe8:      	fmov.4s	v2, #9.00000000
     fec:      	str	q2, [sp, #0x180]
     ff0:      	fcmge.4s	v31, v2, v1
     ff4:      	and.16b	v4, v31, v1
     ff8:      	dup.4s	v2, w17
     ffc:      	str	q2, [sp, #0x170]
    1000:      	fcmge.4s	v2, v4, v2
    1004:      	mov	w13, #0x42c80000        ; =1120403456
    1008:      	dup.4s	v27, w13
    100c:      	fcmge.4s	v5, v27, v4
    1010:      	and.16b	v2, v2, v5
    1014:      	and.16b	v2, v2, v4
    1018:      	mov	w13, #0xaa3b            ; =43579
    101c:      	movk	w13, #0x3fb8, lsl #16
    1020:      	dup.4s	v5, w13
    1024:      	str	q5, [sp, #0x160]
    1028:      	fmul.4s	v5, v2, v5
    102c:      	movi.4s	v6, #0x4b, lsl #24
    1030:      	fadd.4s	v5, v5, v6
    1034:      	movi.4s	v6, #0xcb, lsl #24
    1038:      	fadd.4s	v5, v5, v6
    103c:      	fcvtzs.4s	v10, v5
    1040:      	scvtf.4s	v6, v10
    1044:      	mov	w13, #0x7200            ; =29184
    1048:      	movk	w13, #0xbf31, lsl #16
    104c:      	dup.4s	v5, w13
    1050:      	str	q5, [sp, #0x150]
    1054:      	fmul.4s	v18, v6, v5
    1058:      	fadd.4s	v2, v2, v18
    105c:      	mov	w13, #0xbe8e            ; =48782
    1060:      	movk	w13, #0xb5bf, lsl #16
    1064:      	dup.4s	v24, w13
    1068:      	fmul.4s	v6, v6, v24
    106c:      	mov	w13, #0x2bda            ; =11226
    1070:      	movk	w13, #0x3950, lsl #16
    1074:      	dup.4s	v18, w13
    1078:      	fadd.4s	v13, v2, v6
    107c:      	fmul.4s	v6, v13, v18
    1080:      	mov	w13, #0x96c9            ; =38601
    1084:      	movk	w13, #0x3ab6, lsl #16
    1088:      	dup.4s	v2, w13
    108c:      	fadd.4s	v6, v6, v2
    1090:      	fmul.4s	v23, v13, v6
    1094:      	mov	w13, #0x88a6            ; =34982
    1098:      	movk	w13, #0x3c08, lsl #16
    109c:      	dup.4s	v6, w13
    10a0:      	fadd.4s	v23, v23, v6
    10a4:      	fmul.4s	v7, v13, v23
    10a8:      	mov	w13, #0xaa7a            ; =43642
    10ac:      	movk	w13, #0x3d2a, lsl #16
    10b0:      	dup.4s	v23, w13
    10b4:      	fadd.4s	v7, v7, v23
    10b8:      	fmul.4s	v7, v13, v7
    10bc:      	fadd.4s	v7, v7, v26
    10c0:      	fmul.4s	v7, v13, v7
    10c4:      	movi.4s	v16, #0x3f, lsl #24
    10c8:      	fadd.4s	v7, v7, v16
    10cc:      	fmul.4s	v28, v13, v13
    10d0:      	fmul.4s	v7, v28, v7
    10d4:      	fadd.4s	v7, v13, v7
    10d8:      	fadd.4s	v7, v7, v25
    10dc:      	movi.2d	v17, #0xffffffffffffffff
    10e0:      	add.4s	v28, v10, v17
    10e4:      	sshr.4s	v10, v28, #0x1
    10e8:      	shl.4s	v13, v10, #0x17
    10ec:      	add.4s	v13, v13, v25
    10f0:      	fmul.4s	v7, v7, v13
    10f4:      	sub.4s	v28, v28, v10
    10f8:      	shl.4s	v28, v28, #0x17
    10fc:      	add.4s	v28, v28, v25
    1100:      	fmul.4s	v7, v7, v28
    1104:      	fcmgt.4s	v4, v4, v27
    1108:      	ldr	q17, [sp, #0x210]
    110c:      	bit.16b	v7, v17, v4
    1110:      	fmov.4s	v4, #0.25000000
    1114:      	fdiv.4s	v28, v4, v7
    1118:      	fsub.4s	v10, v7, v28
    111c:      	fadd.4s	v7, v7, v28
    1120:      	fdiv.4s	v7, v10, v7
    1124:      	bif.16b	v7, v25, v31
    1128:      	fcmge.4s	v1, v25, v1
    112c:      	bsl.16b	v1, v29, v7
    1130:      	mvni.4s	v7, #0x80, lsl #24
    1134:      	bif.16b	v1, v0, v7
    1138:      	fcmeq.4s	v0, v0, v0
    113c:      	fadd.4s	v1, v1, v25
    1140:      	ldr	q7, [sp, #0x200]
    1144:      	bif.16b	v1, v7, v0
    1148:      	ldr	q0, [x12, #0x10]
    114c:      	fmul.4s	v7, v22, v16
    1150:      	fmul.4s	v1, v7, v1
    1154:      	add	x12, x24, x11
    1158:      	ldp	q7, q22, [x12]
    115c:      	and.16b	v7, v9, v7
    1160:      	fadd.4s	v1, v7, v1
    1164:      	ldr	q5, [sp, #0x140]
    1168:      	fmov	w12, s5
    116c:      	add	x11, x10, x11
    1170:      	tbnz	w12, #0x0, 0x134c <_llm_rows.packet_batch.blocks+0xb6c>
    1174:      	and	w12, w12, #0xff
    1178:      	tbnz	w12, #0x1, 0x1358 <_llm_rows.packet_batch.blocks+0xb78>
    117c:      	tbnz	w12, #0x2, 0x1364 <_llm_rows.packet_batch.blocks+0xb84>
    1180:      	mov.16b	v5, v9
    1184:      	tbz	w12, #0x3, 0x1190 <_llm_rows.packet_batch.blocks+0x9b0>
    1188:      	add	x13, x11, #0xc
    118c:      	st1.s	{ v1 }[3], [x13]
    1190:      	and.16b	v0, v30, v0
    1194:      	ldp	q1, q31, [sp, #0x1c0]
    1198:      	fmul.4s	v1, v0, v1
    119c:      	fmul.4s	v1, v0, v1
    11a0:      	fmul.4s	v1, v0, v1
    11a4:      	fadd.4s	v1, v0, v1
    11a8:      	ldr	q7, [sp, #0x1a0]
    11ac:      	fmul.4s	v1, v1, v7
    11b0:      	and.16b	v1, v30, v1
    11b4:      	fabs.4s	v29, v1
    11b8:      	fmul.4s	v7, v1, v1
    11bc:      	ldp	q16, q28, [sp, #0x1e0]
    11c0:      	fmla.4s	v28, v7, v16
    11c4:      	fmla.4s	v31, v7, v28
    11c8:      	ldr	q28, [sp, #0x1b0]
    11cc:      	fmla.4s	v28, v7, v31
    11d0:      	mov.16b	v31, v11
    11d4:      	fmla.4s	v31, v7, v28
    11d8:      	mov.16b	v28, v26
    11dc:      	fmla.4s	v28, v7, v31
    11e0:      	mov.16b	v31, v25
    11e4:      	fmla.4s	v31, v7, v28
    11e8:      	fmul.4s	v28, v29, v31
    11ec:      	mov.16b	v31, v12
    11f0:      	ldp	q16, q17, [sp, #0x180]
    11f4:      	fmla.4s	v31, v7, v17
    11f8:      	mov.16b	v10, v14
    11fc:      	fmla.4s	v10, v7, v31
    1200:      	mov.16b	v31, v15
    1204:      	fmla.4s	v31, v7, v10
    1208:      	mov.16b	v10, v8
    120c:      	fmla.4s	v10, v7, v31
    1210:      	movi.4s	v31, #0x3f, lsl #24
    1214:      	fmla.4s	v31, v7, v10
    1218:      	mov.16b	v10, v25
    121c:      	fmla.4s	v10, v7, v31
    1220:      	fdiv.4s	v7, v28, v10
    1224:      	fcmge.4s	v28, v16, v29
    1228:      	and.16b	v31, v28, v29
    122c:      	ldp	q16, q17, [sp, #0x160]
    1230:      	fcmge.4s	v10, v31, v17
    1234:      	fcmge.4s	v13, v27, v31
    1238:      	and.16b	v10, v10, v13
    123c:      	and.16b	v10, v10, v31
    1240:      	fmul.4s	v13, v10, v16
    1244:      	movi.4s	v16, #0x4b, lsl #24
    1248:      	fadd.4s	v13, v13, v16
    124c:      	movi.4s	v16, #0xcb, lsl #24
    1250:      	fadd.4s	v13, v13, v16
    1254:      	fcvtzs.4s	v13, v13
    1258:      	scvtf.4s	v16, v13
    125c:      	mov.16b	v9, v30
    1260:      	ldr	q17, [sp, #0x150]
    1264:      	fmul.4s	v30, v16, v17
    1268:      	fadd.4s	v30, v10, v30
    126c:      	fmul.4s	v16, v16, v24
    1270:      	fadd.4s	v16, v30, v16
    1274:      	fmul.4s	v30, v16, v18
    1278:      	fadd.4s	v30, v30, v2
    127c:      	fmul.4s	v30, v16, v30
    1280:      	fadd.4s	v30, v30, v6
    1284:      	fmul.4s	v30, v16, v30
    1288:      	fadd.4s	v30, v30, v23
    128c:      	fmul.4s	v30, v16, v30
    1290:      	fadd.4s	v30, v30, v26
    1294:      	fmul.4s	v30, v16, v30
    1298:      	movi.4s	v17, #0x3f, lsl #24
    129c:      	fadd.4s	v30, v30, v17
    12a0:      	fmul.4s	v10, v16, v16
    12a4:      	fmul.4s	v30, v10, v30
    12a8:      	fadd.4s	v16, v16, v30
    12ac:      	fadd.4s	v16, v16, v25
    12b0:      	movi.2d	v30, #0xffffffffffffffff
    12b4:      	add.4s	v30, v13, v30
    12b8:      	sshr.4s	v10, v30, #0x1
    12bc:      	shl.4s	v13, v10, #0x17
    12c0:      	add.4s	v13, v13, v25
    12c4:      	fmul.4s	v16, v16, v13
    12c8:      	sub.4s	v30, v30, v10
    12cc:      	shl.4s	v30, v30, #0x17
    12d0:      	add.4s	v30, v30, v25
    12d4:      	fmul.4s	v16, v16, v30
    12d8:      	fcmgt.4s	v30, v31, v27
    12dc:      	ldr	q31, [sp, #0x210]
    12e0:      	bit.16b	v16, v31, v30
    12e4:      	fdiv.4s	v30, v4, v16
    12e8:      	fsub.4s	v31, v16, v30
    12ec:      	fadd.4s	v16, v16, v30
    12f0:      	mov.16b	v30, v9
    12f4:      	fdiv.4s	v16, v31, v16
    12f8:      	bif.16b	v16, v25, v28
    12fc:      	fcmge.4s	v28, v25, v29
    1300:      	bif.16b	v7, v16, v28
    1304:      	mvni.4s	v16, #0x80, lsl #24
    1308:      	bif.16b	v7, v1, v16
    130c:      	fcmeq.4s	v1, v1, v1
    1310:      	fadd.4s	v7, v7, v25
    1314:      	ldr	q16, [sp, #0x200]
    1318:      	bsl.16b	v1, v7, v16
    131c:      	fmul.4s	v0, v0, v17
    1320:      	fmul.4s	v0, v0, v1
    1324:      	and.16b	v1, v9, v22
    1328:      	fadd.4s	v0, v1, v0
    132c:      	tbnz	w12, #0x4, 0x1378 <_llm_rows.packet_batch.blocks+0xb98>
    1330:      	mov.16b	v9, v5
    1334:      	ldp	q22, q17, [sp, #0x120]
    1338:      	ldp	q29, q28, [sp, #0x100]
    133c:      	tbnz	w12, #0x5, 0x138c <_llm_rows.packet_batch.blocks+0xbac>
    1340:      	tbnz	w12, #0x6, 0x1398 <_llm_rows.packet_batch.blocks+0xbb8>
    1344:      	tbz	w12, #0x7, 0xef0 <_llm_rows.packet_batch.blocks+0x710>
    1348:      	b	0x13a4 <_llm_rows.packet_batch.blocks+0xbc4>
    134c:      	str	s1, [x11]
    1350:      	and	w12, w12, #0xff
    1354:      	tbz	w12, #0x1, 0x117c <_llm_rows.packet_batch.blocks+0x99c>
    1358:      	add	x13, x11, #0x4
    135c:      	st1.s	{ v1 }[1], [x13]
    1360:      	tbz	w12, #0x2, 0x1180 <_llm_rows.packet_batch.blocks+0x9a0>
    1364:      	add	x13, x11, #0x8
    1368:      	st1.s	{ v1 }[2], [x13]
    136c:      	mov.16b	v5, v9
    1370:      	tbnz	w12, #0x3, 0x1188 <_llm_rows.packet_batch.blocks+0x9a8>
    1374:      	b	0x1190 <_llm_rows.packet_batch.blocks+0x9b0>
    1378:      	str	s0, [x11, #0x10]
    137c:      	mov.16b	v9, v5
    1380:      	ldp	q22, q17, [sp, #0x120]
    1384:      	ldp	q29, q28, [sp, #0x100]
    1388:      	tbz	w12, #0x5, 0x1340 <_llm_rows.packet_batch.blocks+0xb60>
    138c:      	add	x13, x11, #0x14
    1390:      	st1.s	{ v0 }[1], [x13]
    1394:      	tbz	w12, #0x6, 0x1344 <_llm_rows.packet_batch.blocks+0xb64>
    1398:      	add	x13, x11, #0x18
    139c:      	st1.s	{ v0 }[2], [x13]
    13a0:      	tbz	w12, #0x7, 0xef0 <_llm_rows.packet_batch.blocks+0x710>
    13a4:      	add	x11, x11, #0x1c
    13a8:      	st1.s	{ v0 }[3], [x11]
    13ac:      	b	0xef0 <_llm_rows.packet_batch.blocks+0x710>
    13b0:      	ldr	q5, [sp, #0xa0]
    13b4:      	ldr	q0, [sp, #0x1c0]
    13b8:      	fmul.4s	v0, v5, v0
    13bc:      	fmul.4s	v0, v5, v0
    13c0:      	fmul.4s	v0, v5, v0
    13c4:      	fadd.4s	v0, v5, v0
    13c8:      	ldr	q1, [sp, #0x1a0]
    13cc:      	fmul.4s	v0, v0, v1
    13d0:      	ldr	q1, [sp, #0xe0]
    13d4:      	zip1.8b	v1, v1, v0
    13d8:      	ushll.4s	v1, v1, #0x0
    13dc:      	shl.4s	v1, v1, #0x1f
    13e0:      	cmlt.4s	v1, v1, #0
    13e4:      	and.16b	v0, v1, v0
    13e8:      	fabs.4s	v1, v0
    13ec:      	fmul.4s	v3, v0, v0
    13f0:      	ldp	q16, q7, [sp, #0x1e0]
    13f4:      	fmla.4s	v7, v3, v16
    13f8:      	ldr	q16, [sp, #0x1d0]
    13fc:      	fmla.4s	v16, v3, v7
    1400:      	ldr	q7, [sp, #0x1b0]
    1404:      	fmla.4s	v7, v3, v16
    1408:      	mov.16b	v16, v11
    140c:      	fmla.4s	v16, v3, v7
    1410:      	mov.16b	v7, v26
    1414:      	fmla.4s	v7, v3, v16
    1418:      	mov.16b	v16, v25
    141c:      	fmla.4s	v16, v3, v7
    1420:      	fmul.4s	v7, v1, v16
    1424:      	mov.16b	v16, v12
    1428:      	ldr	q17, [sp, #0x190]
    142c:      	fmla.4s	v16, v3, v17
    1430:      	mov.16b	v19, v14
    1434:      	fmla.4s	v19, v3, v16
    1438:      	mov.16b	v16, v15
    143c:      	fmla.4s	v16, v3, v19
    1440:      	mov.16b	v19, v8
    1444:      	fmla.4s	v19, v3, v16
    1448:      	movi.4s	v16, #0x3f, lsl #24
    144c:      	fmla.4s	v16, v3, v19
    1450:      	mov.16b	v19, v25
    1454:      	fmla.4s	v19, v3, v16
    1458:      	fdiv.4s	v3, v7, v19
    145c:      	ldp	q17, q7, [sp, #0x170]
    1460:      	fcmge.4s	v7, v7, v1
    1464:      	and.16b	v16, v7, v1
    1468:      	fcmge.4s	v19, v16, v17
    146c:      	fcmge.4s	v20, v27, v16
    1470:      	and.16b	v19, v19, v20
    1474:      	and.16b	v19, v19, v16
    1478:      	ldr	q17, [sp, #0x160]
    147c:      	fmul.4s	v20, v19, v17
    1480:      	movi.4s	v17, #0x4b, lsl #24
    1484:      	fadd.4s	v20, v20, v17
    1488:      	movi.4s	v17, #0xcb, lsl #24
    148c:      	fadd.4s	v20, v20, v17
    1490:      	fcvtzs.4s	v20, v20
    1494:      	scvtf.4s	v21, v20
    1498:      	ldr	q17, [sp, #0x150]
    149c:      	fmul.4s	v22, v21, v17
    14a0:      	fadd.4s	v19, v19, v22
    14a4:      	fmul.4s	v21, v21, v24
    14a8:      	fadd.4s	v19, v19, v21
    14ac:      	fmul.4s	v21, v19, v18
    14b0:      	fadd.4s	v21, v21, v2
    14b4:      	fmul.4s	v21, v19, v21
    14b8:      	fadd.4s	v21, v21, v6
    14bc:      	fmul.4s	v21, v19, v21
    14c0:      	fadd.4s	v21, v21, v23
    14c4:      	fmul.4s	v21, v19, v21
    14c8:      	fadd.4s	v21, v21, v26
    14cc:      	fmul.4s	v21, v19, v21
    14d0:      	movi.4s	v17, #0x3f, lsl #24
    14d4:      	fadd.4s	v21, v21, v17
    14d8:      	fmul.4s	v22, v19, v19
    14dc:      	fmul.4s	v21, v22, v21
    14e0:      	fadd.4s	v19, v19, v21
    14e4:      	fadd.4s	v19, v19, v25
    14e8:      	movi.2d	v21, #0xffffffffffffffff
    14ec:      	add.4s	v20, v20, v21
    14f0:      	sshr.4s	v21, v20, #0x1
    14f4:      	shl.4s	v22, v21, #0x17
    14f8:      	add.4s	v22, v22, v25
    14fc:      	fmul.4s	v19, v19, v22
    1500:      	sub.4s	v20, v20, v21
    1504:      	shl.4s	v20, v20, #0x17
    1508:      	add.4s	v20, v20, v25
    150c:      	fmul.4s	v19, v19, v20
    1510:      	fcmgt.4s	v16, v16, v27
    1514:      	ldr	q20, [sp, #0x210]
    1518:      	bsl.16b	v16, v20, v19
    151c:      	fdiv.4s	v19, v4, v16
    1520:      	fsub.4s	v20, v16, v19
    1524:      	fadd.4s	v16, v16, v19
    1528:      	fdiv.4s	v16, v20, v16
    152c:      	bsl.16b	v7, v16, v25
    1530:      	fcmge.4s	v1, v25, v1
    1534:      	bsl.16b	v1, v3, v7
    1538:      	ldr	d3, [sp, #0x48]
    153c:      	fmov	w10, s3
    1540:      	mvni.4s	v3, #0x80, lsl #24
    1544:      	bif.16b	v1, v0, v3
    1548:      	fcmeq.4s	v0, v0, v0
    154c:      	fadd.4s	v1, v1, v25
    1550:      	ldr	q3, [sp, #0x200]
    1554:      	bsl.16b	v0, v1, v3
    1558:      	fmul.4s	v1, v5, v17
    155c:      	fmul.4s	v0, v1, v0
    1560:      	ldr	q1, [sp, #0x50]
    1564:      	fadd.4s	v0, v0, v1
    1568:      	ldr	q3, [sp, #0xb0]
    156c:      	ldp	q5, q7, [sp, #0x80]
    1570:      	stp	q3, q5, [sp, #0x220]
    1574:      	ldr	q1, [sp, #0x70]
    1578:      	stp	q7, q1, [sp, #0x240]
    157c:      	and	x11, x9, #0x7
    1580:      	add	x12, sp, #0x220
    1584:      	ldr	x11, [x12, x11, lsl #3]
    1588:      	sub	x9, x11, x9
    158c:      	add	x8, x8, x9, lsl #2
    1590:      	tbnz	w10, #0x0, 0x1820 <_llm_rows.packet_batch.blocks+0x1040>
    1594:      	tbnz	w10, #0x1, 0x1828 <_llm_rows.packet_batch.blocks+0x1048>
    1598:      	ldr	q1, [sp, #0xe0]
    159c:      	tbnz	w10, #0x2, 0x1838 <_llm_rows.packet_batch.blocks+0x1058>
    15a0:      	tbz	w10, #0x3, 0x15ac <_llm_rows.packet_batch.blocks+0xdcc>
    15a4:      	add	x9, x8, #0xc
    15a8:      	st1.s	{ v0 }[3], [x9]
    15ac:      	ldr	q21, [sp, #0xc0]
    15b0:      	ldr	q0, [sp, #0x1c0]
    15b4:      	fmul.4s	v0, v21, v0
    15b8:      	fmul.4s	v0, v21, v0
    15bc:      	fmul.4s	v0, v21, v0
    15c0:      	fadd.4s	v0, v21, v0
    15c4:      	ldr	q3, [sp, #0x1a0]
    15c8:      	fmul.4s	v0, v0, v3
    15cc:      	zip2.8b	v1, v1, v0
    15d0:      	ushll.4s	v1, v1, #0x0
    15d4:      	shl.4s	v1, v1, #0x1f
    15d8:      	cmlt.4s	v1, v1, #0
    15dc:      	and.16b	v0, v1, v0
    15e0:      	fmul.4s	v1, v0, v0
    15e4:      	ldp	q5, q3, [sp, #0x1e0]
    15e8:      	fmla.4s	v3, v1, v5
    15ec:      	ldr	q5, [sp, #0x1d0]
    15f0:      	fmla.4s	v5, v1, v3
    15f4:      	ldr	q3, [sp, #0x1b0]
    15f8:      	fmla.4s	v3, v1, v5
    15fc:      	fmla.4s	v11, v1, v3
    1600:      	mov.16b	v3, v26
    1604:      	fmla.4s	v3, v1, v11
    1608:      	mov.16b	v7, v25
    160c:      	fmla.4s	v7, v1, v3
    1610:      	ldp	q5, q3, [sp, #0x180]
    1614:      	fmla.4s	v12, v1, v3
    1618:      	fmla.4s	v14, v1, v12
    161c:      	fmla.4s	v15, v1, v14
    1620:      	fmla.4s	v8, v1, v15
    1624:      	movi.4s	v3, #0x3f, lsl #24
    1628:      	fmla.4s	v3, v1, v8
    162c:      	mov.16b	v16, v25
    1630:      	fmla.4s	v16, v1, v3
    1634:      	fabs.4s	v1, v0
    1638:      	fmul.4s	v3, v1, v7
    163c:      	fdiv.4s	v3, v3, v16
    1640:      	fcmge.4s	v7, v5, v1
    1644:      	and.16b	v16, v7, v1
    1648:      	ldr	q5, [sp, #0x170]
    164c:      	fcmge.4s	v19, v16, v5
    1650:      	fcmge.4s	v20, v27, v16
    1654:      	and.16b	v19, v19, v20
    1658:      	and.16b	v19, v19, v16
    165c:      	ldr	q5, [sp, #0x160]
    1660:      	fmul.4s	v17, v19, v5
    1664:      	movi.4s	v20, #0x4b, lsl #24
    1668:      	fadd.4s	v17, v17, v20
    166c:      	movi.4s	v20, #0xcb, lsl #24
    1670:      	fadd.4s	v17, v17, v20
    1674:      	fcvtzs.4s	v17, v17
    1678:      	scvtf.4s	v20, v17
    167c:      	ldr	q5, [sp, #0x150]
    1680:      	fmul.4s	v5, v20, v5
    1684:      	fadd.4s	v5, v19, v5
    1688:      	fmul.4s	v19, v20, v24
    168c:      	fadd.4s	v5, v5, v19
    1690:      	fmul.4s	v18, v5, v18
    1694:      	fadd.4s	v2, v18, v2
    1698:      	fmul.4s	v2, v5, v2
    169c:      	fadd.4s	v2, v2, v6
    16a0:      	fmul.4s	v2, v5, v2
    16a4:      	fadd.4s	v2, v2, v23
    16a8:      	fmul.4s	v2, v5, v2
    16ac:      	fadd.4s	v2, v2, v26
    16b0:      	fmul.4s	v2, v5, v2
    16b4:      	movi.4s	v18, #0x3f, lsl #24
    16b8:      	fadd.4s	v2, v2, v18
    16bc:      	fmul.4s	v6, v5, v5
    16c0:      	fmul.4s	v2, v6, v2
    16c4:      	fadd.4s	v2, v5, v2
    16c8:      	fadd.4s	v2, v2, v25
    16cc:      	movi.2d	v5, #0xffffffffffffffff
    16d0:      	add.4s	v5, v17, v5
    16d4:      	sshr.4s	v6, v5, #0x1
    16d8:      	shl.4s	v17, v6, #0x17
    16dc:      	add.4s	v17, v17, v25
    16e0:      	fmul.4s	v2, v2, v17
    16e4:      	sub.4s	v5, v5, v6
    16e8:      	shl.4s	v5, v5, #0x17
    16ec:      	add.4s	v5, v5, v25
    16f0:      	fmul.4s	v2, v2, v5
    16f4:      	fcmgt.4s	v5, v16, v27
    16f8:      	ldr	q6, [sp, #0x210]
    16fc:      	bit.16b	v2, v6, v5
    1700:      	fdiv.4s	v4, v4, v2
    1704:      	fsub.4s	v5, v2, v4
    1708:      	fadd.4s	v2, v2, v4
    170c:      	fdiv.4s	v2, v5, v2
    1710:      	bif.16b	v2, v25, v7
    1714:      	fcmge.4s	v1, v25, v1
    1718:      	bsl.16b	v1, v3, v2
    171c:      	mvni.4s	v2, #0x80, lsl #24
    1720:      	bif.16b	v1, v0, v2
    1724:      	fadd.4s	v1, v1, v25
    1728:      	fcmeq.4s	v0, v0, v0
    172c:      	ldr	q2, [sp, #0x200]
    1730:      	bsl.16b	v0, v1, v2
    1734:      	fmul.4s	v1, v21, v18
    1738:      	fmul.4s	v0, v1, v0
    173c:      	ldr	q1, [sp, #0x60]
    1740:      	fadd.4s	v0, v0, v1
    1744:      	tbnz	w10, #0x4, 0x1848 <_llm_rows.packet_batch.blocks+0x1068>
    1748:      	movi.2s	v8, #0x41
    174c:      	tbnz	w10, #0x5, 0x1854 <_llm_rows.packet_batch.blocks+0x1074>
    1750:      	tbnz	w10, #0x6, 0x1860 <_llm_rows.packet_batch.blocks+0x1080>
    1754:      	tbz	w10, #0x7, 0x884 <_llm_rows.packet_batch.blocks+0xa4>
    1758:      	b	0x186c <_llm_rows.packet_batch.blocks+0x108c>
    175c:      	add	x14, x12, #0x4
    1760:      	ld1.s	{ v20 }[1], [x14]
    1764:      	tbz	w13, #0x2, 0xbfc <_llm_rows.packet_batch.blocks+0x41c>
    1768:      	add	x14, x12, #0x8
    176c:      	ld1.s	{ v20 }[2], [x14]
    1770:      	tbz	w13, #0x3, 0xc00 <_llm_rows.packet_batch.blocks+0x420>
    1774:      	add	x14, x12, #0xc
    1778:      	ld1.s	{ v20 }[3], [x14]
    177c:      	tbz	w13, #0x4, 0xc04 <_llm_rows.packet_batch.blocks+0x424>
    1780:      	add	x14, x12, #0x10
    1784:      	ld1.s	{ v18 }[0], [x14]
    1788:      	tbz	w13, #0x5, 0xc08 <_llm_rows.packet_batch.blocks+0x428>
    178c:      	add	x14, x12, #0x14
    1790:      	ld1.s	{ v18 }[1], [x14]
    1794:      	tbz	w13, #0x6, 0xc0c <_llm_rows.packet_batch.blocks+0x42c>
    1798:      	add	x14, x12, #0x18
    179c:      	ld1.s	{ v18 }[2], [x14]
    17a0:      	tbnz	w13, #0x7, 0xc10 <_llm_rows.packet_batch.blocks+0x430>
    17a4:      	b	0xc18 <_llm_rows.packet_batch.blocks+0x438>
    17a8:      	ldr	s4, [x10]
    17ac:      	mov	w15, #0xb61             ; =2913
    17b0:      	movk	w15, #0x3ab6, lsl #16
    17b4:      	mov	w16, #0xaaab            ; =43691
    17b8:      	movk	w16, #0x3d2a, lsl #16
    17bc:      	mov	w17, #-0x3d300000       ; =-1026555904
    17c0:      	tbz	w11, #0x1, 0xe60 <_llm_rows.packet_batch.blocks+0x680>
    17c4:      	add	x14, x10, #0x4
    17c8:      	ld1.s	{ v4 }[1], [x14]
    17cc:      	tbz	w11, #0x2, 0xe64 <_llm_rows.packet_batch.blocks+0x684>
    17d0:      	add	x14, x10, #0x8
    17d4:      	ld1.s	{ v4 }[2], [x14]
    17d8:      	tbz	w11, #0x3, 0xe68 <_llm_rows.packet_batch.blocks+0x688>
    17dc:      	add	x14, x10, #0xc
    17e0:      	ld1.s	{ v4 }[3], [x14]
    17e4:      	tbz	w11, #0x4, 0xe6c <_llm_rows.packet_batch.blocks+0x68c>
    17e8:      	add	x14, x10, #0x10
    17ec:      	ld1.s	{ v3 }[0], [x14]
    17f0:      	tbz	w11, #0x5, 0xe70 <_llm_rows.packet_batch.blocks+0x690>
    17f4:      	add	x14, x10, #0x14
    17f8:      	ld1.s	{ v3 }[1], [x14]
    17fc:      	tbz	w11, #0x6, 0xe74 <_llm_rows.packet_batch.blocks+0x694>
    1800:      	add	x14, x10, #0x18
    1804:      	ld1.s	{ v3 }[2], [x14]
    1808:      	mov	w14, #0xd01             ; =3329
    180c:      	movk	w14, #0x37d0, lsl #16
    1810:      	str	q18, [sp, #0xc0]
    1814:      	str	q20, [sp, #0xa0]
    1818:      	tbnz	w11, #0x7, 0xe88 <_llm_rows.packet_batch.blocks+0x6a8>
    181c:      	b	0xe90 <_llm_rows.packet_batch.blocks+0x6b0>
    1820:      	str	s0, [x8]
    1824:      	tbz	w10, #0x1, 0x1598 <_llm_rows.packet_batch.blocks+0xdb8>
    1828:      	add	x9, x8, #0x4
    182c:      	st1.s	{ v0 }[1], [x9]
    1830:      	ldr	q1, [sp, #0xe0]
    1834:      	tbz	w10, #0x2, 0x15a0 <_llm_rows.packet_batch.blocks+0xdc0>
    1838:      	add	x9, x8, #0x8
    183c:      	st1.s	{ v0 }[2], [x9]
    1840:      	tbnz	w10, #0x3, 0x15a4 <_llm_rows.packet_batch.blocks+0xdc4>
    1844:      	b	0x15ac <_llm_rows.packet_batch.blocks+0xdcc>
    1848:      	str	s0, [x8, #0x10]
    184c:      	movi.2s	v8, #0x41
    1850:      	tbz	w10, #0x5, 0x1750 <_llm_rows.packet_batch.blocks+0xf70>
    1854:      	add	x9, x8, #0x14
    1858:      	st1.s	{ v0 }[1], [x9]
    185c:      	tbz	w10, #0x6, 0x1754 <_llm_rows.packet_batch.blocks+0xf74>
    1860:      	add	x9, x8, #0x18
    1864:      	st1.s	{ v0 }[2], [x9]
    1868:      	tbz	w10, #0x7, 0x884 <_llm_rows.packet_batch.blocks+0xa4>
    186c:      	add	x8, x8, #0x1c
    1870:      	st1.s	{ v0 }[3], [x8]
    1874:      	b	0x884 <_llm_rows.packet_batch.blocks+0xa4>
    1878:      	add	sp, sp, #0x540
    187c:      	ldp	x29, x30, [sp, #0x90]
    1880:      	ldp	x20, x19, [sp, #0x80]
    1884:      	ldp	x22, x21, [sp, #0x70]
    1888:      	ldp	x24, x23, [sp, #0x60]
    188c:      	ldp	x26, x25, [sp, #0x50]
    1890:      	ldp	x28, x27, [sp, #0x40]
    1894:      	ldp	d9, d8, [sp, #0x30]
    1898:      	ldp	d11, d10, [sp, #0x20]
    189c:      	ldp	d13, d12, [sp, #0x10]
    18a0:      	ldp	d15, d14, [sp], #0xa0
    18a4:      	ret

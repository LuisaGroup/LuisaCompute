
/private/tmp/luisa-expression-fusion.qXgTbC/capture/layernorm-257x1538/off/object/tile_xir_w8_23350_1788930262618555_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	x28, x27, [sp, #-0x60]!
       4:      	stp	x26, x25, [sp, #0x10]
       8:      	stp	x24, x23, [sp, #0x20]
       c:      	stp	x22, x21, [sp, #0x30]
      10:      	stp	x20, x19, [sp, #0x40]
      14:      	stp	x29, x30, [sp, #0x50]
      18:      	sub	sp, sp, #0x6, lsl #12   ; =0x6000
      1c:      	sub	sp, sp, #0x130
      20:      	ldr	x24, [x0]
      24:      	ldr	x20, [x0, #0x10]
      28:      	ldr	x19, [x0, #0x20]
      2c:      	ldr	x21, [x0, #0x30]
      30:      	ldr	w8, [x1]
      34:      	ldr	w9, [x1, #0x24]
      38:      	add	w8, w9, w8, lsl #5
      3c:      	lsr	w8, w8, #3
      40:      	fmov	s0, w8
      44:      	ushll.2d	v0, v0, #0x0
      48:      	fmov	x22, d0
      4c:      	mov	w25, #0x1808            ; =6152
      50:      	umull	x23, w22, w25
      54:      	umaddl	x1, w22, w25, x24
      58:      	mov	w26, #0x1800            ; =6144
      5c:      	add	x27, sp, #0x4, lsl #12  ; =0x4000
      60:      	add	x27, x27, #0x910
      64:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
      68:      	add	x0, x0, #0x910
      6c:      	mov	w2, #0x1800             ; =6144
      70:      	bl	0x70 <ltmp0+0x70>
      74:      	umaddl	x22, w22, w25, x26
      78:      	add	x8, x24, x22
      7c:      	add	x9, x8, #0x4
      80:      	ldr	s0, [x8]
      84:      	ld1.s	{ v0 }[1], [x9]
      88:      	str	q0, [sp, #0x6110]
      8c:      	ldr	q1, [sp, #0x4920]
      90:      	ldr	q7, [sp, #0x4910]
      94:      	ldr	q6, [sp, #0x4940]
      98:      	ldr	q5, [sp, #0x4930]
      9c:      	ldr	q2, [sp, #0x4960]
      a0:      	ldr	q16, [sp, #0x4950]
      a4:      	ldr	q4, [sp, #0x4980]
      a8:      	ldr	q3, [sp, #0x4970]
      ac:      	add	x8, x27, #0xe0
      b0:      	mov	w9, #0x4                ; =4
      b4:      	ldp	q17, q18, [x8, #-0x60]
      b8:      	fadd.4s	v1, v1, v18
      bc:      	fadd.4s	v7, v7, v17
      c0:      	ldp	q17, q18, [x8, #-0x40]
      c4:      	fadd.4s	v6, v6, v18
      c8:      	fadd.4s	v5, v5, v17
      cc:      	ldp	q17, q18, [x8, #-0x20]
      d0:      	fadd.4s	v2, v2, v18
      d4:      	fadd.4s	v16, v16, v17
      d8:      	ldp	q17, q18, [x8], #0x80
      dc:      	fadd.4s	v4, v4, v18
      e0:      	fadd.4s	v3, v3, v17
      e4:      	cmp	x9, #0xbc
      e8:      	add	x9, x9, #0x4
      ec:      	b.lo	0xb4 <ltmp0+0xb4>
      f0:      	mov	x8, #0x0                ; =0
      f4:      	fadd.4s	v17, v0, v7
      f8:      	mov.d	v17[1], v7[1]
      fc:      	fadd.4s	v1, v6, v1
     100:      	fadd.4s	v5, v5, v17
     104:      	fadd.4s	v5, v16, v5
     108:      	fadd.4s	v1, v2, v1
     10c:      	fadd.4s	v1, v4, v1
     110:      	fadd.4s	v2, v3, v5
     114:      	rev64.4s	v3, v2
     118:      	rev64.4s	v4, v1
     11c:      	fadd.4s	v1, v1, v4
     120:      	fadd.4s	v2, v2, v3
     124:      	dup.4s	v3, v2[2]
     128:      	dup.4s	v4, v1[2]
     12c:      	fadd.4s	v1, v1, v4
     130:      	fadd.4s	v2, v2, v3
     134:      	fadd.4s	v1, v2, v1
     138:      	movi	d2, #0000000000000000
     13c:      	fadd	s1, s1, s2
     140:      	mov	w9, #0x4000             ; =16384
     144:      	movk	w9, #0x44c0, lsl #16
     148:      	fmov	s2, w9
     14c:      	fdiv	s1, s1, s2
     150:      	dup.4s	v2, v1[0]
     154:      	add	x9, sp, #0x4, lsl #12   ; =0x4000
     158:      	add	x9, x9, #0x910
     15c:      	add	x10, sp, #0x3, lsl #12  ; =0x3000
     160:      	add	x10, x10, #0xf0
     164:      	lsl	x11, x8, #5
     168:      	add	x12, x9, x11
     16c:      	ldp	q4, q3, [x12]
     170:      	fsub.4s	v4, v4, v2
     174:      	fsub.4s	v3, v3, v2
     178:      	add	x11, x10, x11
     17c:      	stp	q4, q3, [x11]
     180:      	add	x8, x8, #0x1
     184:      	cmp	x8, #0xc0
     188:      	b.ne	0x164 <ltmp0+0x164>
     18c:      	dup.4s	v1, v1[0]
     190:      	fsub.4s	v1, v0, v1
     194:      	ldr	q0, [sp, #0x48f0]
     198:      	str	q1, [sp, #0x90]
     19c:      	mov.d	v1[1], v0[1]
     1a0:      	str	q1, [sp, #0xa0]
     1a4:      	str	q1, [sp, #0x48f0]
     1a8:      	ldr	q0, [sp, #0x30f0]
     1ac:      	ldr	q1, [sp, #0x3100]
     1b0:      	fmul.4s	v2, v1, v1
     1b4:      	fmul.4s	v3, v0, v0
     1b8:      	ldr	q0, [sp, #0x3110]
     1bc:      	ldr	q1, [sp, #0x3120]
     1c0:      	fmul.4s	v5, v1, v1
     1c4:      	fmul.4s	v4, v0, v0
     1c8:      	ldr	q0, [sp, #0x3130]
     1cc:      	ldr	q1, [sp, #0x3140]
     1d0:      	fmul.4s	v6, v1, v1
     1d4:      	fmul.4s	v7, v0, v0
     1d8:      	ldr	q0, [sp, #0x3150]
     1dc:      	ldr	q1, [sp, #0x3160]
     1e0:      	fmul.4s	v17, v1, v1
     1e4:      	fmul.4s	v16, v0, v0
     1e8:      	add	x8, sp, #0x3, lsl #12   ; =0x3000
     1ec:      	add	x8, x8, #0xf0
     1f0:      	add	x8, x8, #0xe0
     1f4:      	mov	w9, #0x4                ; =4
     1f8:      	ldp	q1, q0, [x8, #-0x60]
     1fc:      	fmul.4s	v1, v1, v1
     200:      	fmul.4s	v0, v0, v0
     204:      	fadd.4s	v2, v2, v0
     208:      	fadd.4s	v3, v3, v1
     20c:      	ldp	q1, q0, [x8, #-0x40]
     210:      	fmul.4s	v1, v1, v1
     214:      	fmul.4s	v0, v0, v0
     218:      	fadd.4s	v5, v5, v0
     21c:      	fadd.4s	v4, v4, v1
     220:      	ldp	q1, q0, [x8, #-0x20]
     224:      	fmul.4s	v1, v1, v1
     228:      	fmul.4s	v0, v0, v0
     22c:      	fadd.4s	v6, v6, v0
     230:      	fadd.4s	v7, v7, v1
     234:      	ldp	q1, q0, [x8], #0x80
     238:      	fmul.4s	v1, v1, v1
     23c:      	fmul.4s	v0, v0, v0
     240:      	fadd.4s	v17, v17, v0
     244:      	fadd.4s	v16, v16, v1
     248:      	cmp	x9, #0xbc
     24c:      	add	x9, x9, #0x4
     250:      	b.lo	0x1f8 <ltmp0+0x1f8>
     254:      	add	x24, sp, #0x1, lsl #12  ; =0x1000
     258:      	add	x24, x24, #0x8d0
     25c:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     260:      	add	x0, x0, #0x8d0
     264:      	mov	x1, x20
     268:      	mov	w2, #0x1800             ; =6144
     26c:      	stp	q5, q2, [sp, #0x10]
     270:      	str	q3, [sp]
     274:      	stp	q7, q4, [sp, #0x30]
     278:      	stp	q6, q16, [sp, #0x60]
     27c:      	str	q17, [sp, #0x50]
     280:      	bl	0x280 <ltmp0+0x280>
     284:      	mov	w25, #0x1804            ; =6148
     288:      	add	x8, x20, x25
     28c:      	ldr	s0, [x20, #0x1800]
     290:      	ld1.s	{ v0 }[1], [x8]
     294:      	str	q0, [sp, #0x80]
     298:      	str	q0, [sp, #0x30d0]
     29c:      	add	x20, sp, #0xb0
     2a0:      	add	x0, sp, #0xb0
     2a4:      	mov	x1, x19
     2a8:      	mov	w2, #0x1800             ; =6144
     2ac:      	bl	0x2ac <ltmp0+0x2ac>
     2b0:      	mov	x8, #0x0                ; =0
     2b4:      	ldr	q0, [sp, #0x90]
     2b8:      	fmul.4s	v0, v0, v0
     2bc:      	ldp	q1, q2, [sp]
     2c0:      	fadd.4s	v0, v0, v1
     2c4:      	mov.d	v0[1], v1[1]
     2c8:      	ldr	q1, [sp, #0x20]
     2cc:      	fadd.4s	v1, v2, v1
     2d0:      	ldp	q2, q3, [sp, #0x30]
     2d4:      	fadd.4s	v0, v3, v0
     2d8:      	fadd.4s	v0, v2, v0
     2dc:      	ldp	q2, q3, [sp, #0x50]
     2e0:      	fadd.4s	v1, v3, v1
     2e4:      	fadd.4s	v1, v2, v1
     2e8:      	ldr	q2, [sp, #0x70]
     2ec:      	fadd.4s	v0, v2, v0
     2f0:      	rev64.4s	v2, v0
     2f4:      	rev64.4s	v3, v1
     2f8:      	fadd.4s	v0, v0, v2
     2fc:      	dup.4s	v2, v0[2]
     300:      	fadd.4s	v1, v1, v3
     304:      	dup.4s	v3, v1[2]
     308:      	mov	w9, #0x4000             ; =16384
     30c:      	movk	w9, #0x44c0, lsl #16
     310:      	fmov	s4, w9
     314:      	mov	w9, #0xc5ac             ; =50604
     318:      	movk	w9, #0x3727, lsl #16
     31c:      	fmov	s5, w9
     320:      	fadd.4s	v1, v1, v3
     324:      	fadd.4s	v0, v0, v2
     328:      	fadd.4s	v0, v0, v1
     32c:      	movi	d1, #0000000000000000
     330:      	fadd	s0, s0, s1
     334:      	fdiv	s0, s0, s4
     338:      	fadd	s1, s0, s5
     33c:      	add	x9, x19, x25
     340:      	ldr	s0, [x19, #0x1800]
     344:      	ld1.s	{ v0 }[1], [x9]
     348:      	fsqrt	s1, s1
     34c:      	str	q0, [sp, #0x18b0]
     350:      	dup.4s	v2, v1[0]
     354:      	add	x9, x21, x23
     358:      	add	x10, sp, #0x3, lsl #12  ; =0x3000
     35c:      	add	x10, x10, #0xf0
     360:      	lsl	x11, x8, #5
     364:      	add	x12, x10, x11
     368:      	ldp	q4, q3, [x12]
     36c:      	fdiv.4s	v4, v4, v2
     370:      	fdiv.4s	v3, v3, v2
     374:      	add	x12, x24, x11
     378:      	ldp	q5, q6, [x12]
     37c:      	fmul.4s	v3, v3, v6
     380:      	fmul.4s	v4, v4, v5
     384:      	add	x12, x20, x11
     388:      	ldp	q6, q5, [x12]
     38c:      	fadd.4s	v4, v4, v6
     390:      	fadd.4s	v3, v3, v5
     394:      	add	x11, x9, x11
     398:      	stp	q4, q3, [x11]
     39c:      	add	x8, x8, #0x1
     3a0:      	cmp	x8, #0xc0
     3a4:      	b.ne	0x360 <ltmp0+0x360>
     3a8:      	dup.2s	v1, v1[0]
     3ac:      	ldr	q2, [sp, #0xa0]
     3b0:      	fdiv.2s	v1, v2, v1
     3b4:      	ldr	q2, [sp, #0x80]
     3b8:      	fmul.2s	v1, v1, v2
     3bc:      	fadd.2s	v0, v1, v0
     3c0:      	str	d0, [x21, x22]
     3c4:      	add	sp, sp, #0x6, lsl #12   ; =0x6000
     3c8:      	add	sp, sp, #0x130
     3cc:      	ldp	x29, x30, [sp, #0x50]
     3d0:      	ldp	x20, x19, [sp, #0x40]
     3d4:      	ldp	x22, x21, [sp, #0x30]
     3d8:      	ldp	x24, x23, [sp, #0x20]
     3dc:      	ldp	x26, x25, [sp, #0x10]
     3e0:      	ldp	x28, x27, [sp], #0x60
     3e4:      	ret

00000000000003e8 <_llm_rows.packet_batch.blocks>:
     3e8:      	stp	d15, d14, [sp, #-0xa0]!
     3ec:      	stp	d13, d12, [sp, #0x10]
     3f0:      	stp	d11, d10, [sp, #0x20]
     3f4:      	stp	d9, d8, [sp, #0x30]
     3f8:      	stp	x28, x27, [sp, #0x40]
     3fc:      	stp	x26, x25, [sp, #0x50]
     400:      	stp	x24, x23, [sp, #0x60]
     404:      	stp	x22, x21, [sp, #0x70]
     408:      	stp	x20, x19, [sp, #0x80]
     40c:      	stp	x29, x30, [sp, #0x90]
     410:      	sub	sp, sp, #0x6, lsl #12   ; =0x6000
     414:      	sub	sp, sp, #0x700
     418:      	str	x0, [sp, #0x198]
     41c:      	cbz	w3, 0x1a64 <_llm_rows.packet_batch.blocks+0x167c>
     420:      	mov	x23, x3
     424:      	mov	x20, x2
     428:      	mov	w22, #0x0               ; =0
     42c:      	ldp	w9, w8, [x2, #0x2c]
     430:      	str	w9, [sp, #0x194]
     434:      	str	w8, [sp, #0x190]
     438:      	add	x25, sp, #0x4, lsl #12  ; =0x4000
     43c:      	add	x25, x25, #0xee0
     440:      	ldp	w24, w13, [x2]
     444:      	adrp	x8, 0x0 <ltmp0>
     448:      	ldr	q0, [x8]
     44c:      	str	q0, [sp, #0x10]
     450:      	adrp	x8, 0x0 <ltmp0>
     454:      	ldr	q0, [x8]
     458:      	str	q0, [sp, #0x30]
     45c:      	adrp	x8, 0x0 <ltmp0>
     460:      	ldr	q0, [x8]
     464:      	str	q0, [sp, #0x20]
     468:      	ldp	w26, w8, [x2, #0x8]
     46c:      	str	x8, [sp, #0x188]
     470:      	add	x19, sp, #0x3, lsl #12  ; =0x3000
     474:      	add	x19, x19, #0x6c0
     478:      	add	x27, sp, #0x680
     47c:      	str	w3, [sp, #0x15c]
     480:      	b	0x4cc <_llm_rows.packet_batch.blocks+0xe4>
     484:      	mov	w8, #0x18               ; =24
     488:      	str	w8, [x20, #0x24]
     48c:      	ldr	w23, [sp, #0x15c]
     490:      	add	w8, w24, #0x1
     494:      	ldr	w9, [sp, #0x194]
     498:      	cmp	w8, w9
     49c:      	cset	w8, eq
     4a0:      	csinc	w24, wzr, w24, eq
     4a4:      	cinc	w9, w13, eq
     4a8:      	ldr	w10, [sp, #0x190]
     4ac:      	cmp	w9, w10
     4b0:      	cset	w10, eq
     4b4:      	ands	w8, w8, w10
     4b8:      	csel	w13, wzr, w9, ne
     4bc:      	add	w26, w26, w8
     4c0:      	add	w22, w22, #0x1
     4c4:      	cmp	w22, w23
     4c8:      	b.eq	0x1a64 <_llm_rows.packet_batch.blocks+0x167c>
     4cc:      	ubfiz	x8, x24, #5, #32
     4d0:      	ldr	x12, [sp, #0x188]
     4d4:      	cmp	x8, x12
     4d8:      	csel	x9, x8, xzr, ls
     4dc:      	subs	x10, x12, x9
     4e0:      	cmp	x10, #0x20
     4e4:      	mov	w11, #0x20              ; =32
     4e8:      	csel	x10, x10, x11, lo
     4ec:      	cmp	x12, x9
     4f0:      	stp	w24, w13, [x20]
     4f4:      	str	w26, [x20, #0x8]
     4f8:      	str	wzr, [x20, #0x24]
     4fc:      	ccmp	x8, x12, #0x2, hi
     500:      	csel	x28, x10, xzr, ls
     504:      	cmp	x28, #0x20
     508:      	b.lo	0x564 <_llm_rows.packet_batch.blocks+0x17c>
     50c:      	ldr	x28, [sp, #0x198]
     510:      	mov	x0, x28
     514:      	mov	x1, x20
     518:      	mov	x21, x13
     51c:      	bl	0x51c <_llm_rows.packet_batch.blocks+0x134>
     520:      	mov	w8, #0x8                ; =8
     524:      	str	w8, [x20, #0x24]
     528:      	mov	x0, x28
     52c:      	mov	x1, x20
     530:      	bl	0x530 <_llm_rows.packet_batch.blocks+0x148>
     534:      	mov	w8, #0x10               ; =16
     538:      	str	w8, [x20, #0x24]
     53c:      	mov	x0, x28
     540:      	mov	x1, x20
     544:      	bl	0x544 <_llm_rows.packet_batch.blocks+0x15c>
     548:      	mov	w8, #0x18               ; =24
     54c:      	str	w8, [x20, #0x24]
     550:      	mov	x0, x28
     554:      	mov	x1, x20
     558:      	bl	0x558 <_llm_rows.packet_batch.blocks+0x170>
     55c:      	mov	x13, x21
     560:      	b	0x490 <_llm_rows.packet_batch.blocks+0xa8>
     564:      	lsr	x23, x28, #3
     568:      	cmp	x28, #0x8
     56c:      	b.lo	0x5c8 <_llm_rows.packet_batch.blocks+0x1e0>
     570:      	str	wzr, [x20, #0x24]
     574:      	ldr	x0, [sp, #0x198]
     578:      	mov	x1, x20
     57c:      	mov	x21, x13
     580:      	bl	0x580 <_llm_rows.packet_batch.blocks+0x198>
     584:      	mov	x13, x21
     588:      	cmp	x23, #0x1
     58c:      	b.eq	0x5c8 <_llm_rows.packet_batch.blocks+0x1e0>
     590:      	mov	w8, #0x8                ; =8
     594:      	str	w8, [x20, #0x24]
     598:      	ldr	x0, [sp, #0x198]
     59c:      	mov	x1, x20
     5a0:      	bl	0x5a0 <_llm_rows.packet_batch.blocks+0x1b8>
     5a4:      	mov	x13, x21
     5a8:      	cmp	x23, #0x2
     5ac:      	b.eq	0x5c8 <_llm_rows.packet_batch.blocks+0x1e0>
     5b0:      	mov	w8, #0x10               ; =16
     5b4:      	str	w8, [x20, #0x24]
     5b8:      	ldr	x0, [sp, #0x198]
     5bc:      	mov	x1, x20
     5c0:      	bl	0x5c0 <_llm_rows.packet_batch.blocks+0x1d8>
     5c4:      	mov	x13, x21
     5c8:      	and	w8, w28, #0x7
     5cc:      	mov	w21, #0x4               ; =4
     5d0:      	cbz	w8, 0x484 <_llm_rows.packet_batch.blocks+0x9c>
     5d4:      	dup.4s	v1, w8
     5d8:      	ldp	q0, q2, [sp, #0x20]
     5dc:      	cmhi.4s	v0, v1, v0
     5e0:      	cmhi.4s	v1, v1, v2
     5e4:      	uzp1.8h	v3, v1, v0
     5e8:      	umaxv.8h	h2, v3
     5ec:      	fmov	w8, s2
     5f0:      	tbz	w8, #0x0, 0x484 <_llm_rows.packet_batch.blocks+0x9c>
     5f4:      	str	w13, [sp, #0x158]
     5f8:      	mov	x9, #0x0                ; =0
     5fc:      	ldr	x11, [sp, #0x198]
     600:      	ldr	x8, [x11]
     604:      	ldr	x13, [x11, #0x10]
     608:      	ldr	x10, [x11, #0x20]
     60c:      	ldr	x11, [x11, #0x30]
     610:      	str	x11, [sp, #0x150]
     614:      	ldr	q2, [sp, #0x10]
     618:      	and.16b	v2, v3, v2
     61c:      	addv.8h	h21, v2
     620:      	fmov	w11, s21
     624:      	and	w28, w11, #0xff
     628:      	ubfiz	w11, w24, #2, #27
     62c:      	orr	w11, w11, w23
     630:      	dup.4s	v4, w11
     634:      	and.16b	v16, v1, v4
     638:      	and.16b	v4, v0, v4
     63c:      	ushll2.2d	v5, v4, #0x0
     640:      	ushll2.2d	v6, v16, #0x0
     644:      	ushll.2d	v7, v4, #0x0
     648:      	ushll.2d	v19, v16, #0x0
     64c:      	fmov	x11, d19
     650:      	mov	w12, #0x1808            ; =6152
     654:      	umaddl	x11, w11, w12, x8
     658:      	fmov	w12, s21
     65c:      	b	0x680 <_llm_rows.packet_batch.blocks+0x298>
     660:      	add	x14, x25, x9, lsl #5
     664:      	ldp	q17, q18, [x14]
     668:      	bif.16b	v16, v18, v0
     66c:      	bif.16b	v4, v17, v1
     670:      	stp	q4, q16, [x14]
     674:      	add	x9, x9, #0x1
     678:      	cmp	x9, #0xc0
     67c:      	b.eq	0x714 <_llm_rows.packet_batch.blocks+0x32c>
     680:      	add	x14, x11, x9, lsl #5
     684:      	movi.2d	v4, #0000000000000000
     688:      	movi.2d	v16, #0000000000000000
     68c:      	tbnz	w12, #0x0, 0x6b4 <_llm_rows.packet_batch.blocks+0x2cc>
     690:      	and	w15, w12, #0xff
     694:      	tbnz	w15, #0x1, 0x6c0 <_llm_rows.packet_batch.blocks+0x2d8>
     698:      	tbnz	w15, #0x2, 0x6cc <_llm_rows.packet_batch.blocks+0x2e4>
     69c:      	tbnz	w15, #0x3, 0x6d8 <_llm_rows.packet_batch.blocks+0x2f0>
     6a0:      	tbnz	w15, #0x4, 0x6e4 <_llm_rows.packet_batch.blocks+0x2fc>
     6a4:      	tbnz	w15, #0x5, 0x6f0 <_llm_rows.packet_batch.blocks+0x308>
     6a8:      	tbnz	w15, #0x6, 0x6fc <_llm_rows.packet_batch.blocks+0x314>
     6ac:      	tbz	w15, #0x7, 0x660 <_llm_rows.packet_batch.blocks+0x278>
     6b0:      	b	0x708 <_llm_rows.packet_batch.blocks+0x320>
     6b4:      	ldr	s4, [x14]
     6b8:      	and	w15, w12, #0xff
     6bc:      	tbz	w15, #0x1, 0x698 <_llm_rows.packet_batch.blocks+0x2b0>
     6c0:      	add	x16, x14, #0x4
     6c4:      	ld1.s	{ v4 }[1], [x16]
     6c8:      	tbz	w15, #0x2, 0x69c <_llm_rows.packet_batch.blocks+0x2b4>
     6cc:      	add	x16, x14, #0x8
     6d0:      	ld1.s	{ v4 }[2], [x16]
     6d4:      	tbz	w15, #0x3, 0x6a0 <_llm_rows.packet_batch.blocks+0x2b8>
     6d8:      	add	x16, x14, #0xc
     6dc:      	ld1.s	{ v4 }[3], [x16]
     6e0:      	tbz	w15, #0x4, 0x6a4 <_llm_rows.packet_batch.blocks+0x2bc>
     6e4:      	add	x16, x14, #0x10
     6e8:      	ld1.s	{ v16 }[0], [x16]
     6ec:      	tbz	w15, #0x5, 0x6a8 <_llm_rows.packet_batch.blocks+0x2c0>
     6f0:      	add	x16, x14, #0x14
     6f4:      	ld1.s	{ v16 }[1], [x16]
     6f8:      	tbz	w15, #0x6, 0x6ac <_llm_rows.packet_batch.blocks+0x2c4>
     6fc:      	add	x16, x14, #0x18
     700:      	ld1.s	{ v16 }[2], [x16]
     704:      	tbz	w15, #0x7, 0x660 <_llm_rows.packet_batch.blocks+0x278>
     708:      	add	x14, x14, #0x1c
     70c:      	ld1.s	{ v16 }[3], [x14]
     710:      	b	0x660 <_llm_rows.packet_batch.blocks+0x278>
     714:      	xtn.8b	v4, v3
     718:      	sshll.2d	v16, v1, #0x0
     71c:      	adrp	x9, 0x0 <ltmp0>
     720:      	ldr	q3, [x9]
     724:      	and.16b	v17, v16, v3
     728:      	movi	d2, #0x0000000000ffff
     72c:      	and.8b	v3, v4, v2
     730:      	adrp	x9, 0x0 <ltmp0>
     734:      	ldr	d18, [x9]
     738:      	str	q4, [sp, #0x160]
     73c:      	and.8b	v18, v4, v18
     740:      	addv.8b	b18, v18
     744:      	fmov	w11, s18
     748:      	umaxv.8b	b18, v3
     74c:      	fmov	w9, s18
     750:      	rbit	w12, w11
     754:      	clz	w12, w12
     758:      	tst	w9, #0x1
     75c:      	csel	w9, w12, wzr, ne
     760:      	mov	w12, #0x600             ; =1536
     764:      	dup.2d	v22, x12
     768:      	str	q17, [sp, #0xe0]
     76c:      	orr.16b	v2, v17, v22
     770:      	mov	w12, #0x602             ; =1538
     774:      	dup.2s	v18, w12
     778:      	xtn.2s	v19, v19
     77c:      	str	q2, [sp, #0x90]
     780:      	umlal.2d	v2, v19, v18
     784:      	mov	b20, v3[0]
     788:      	mov.b	v20[4], v3[1]
     78c:      	ushll.2d	v20, v20, #0x0
     790:      	shl.2d	v20, v20, #0x3f
     794:      	cmlt.2d	v20, v20, #0
     798:      	str	q2, [sp, #0x130]
     79c:      	and.16b	v20, v20, v2
     7a0:      	movi.2d	v2, #0000000000000000
     7a4:      	str	q2, [sp, #0x660]
     7a8:      	str	q2, [sp, #0x650]
     7ac:      	str	q2, [sp, #0x640]
     7b0:      	str	q20, [sp, #0x630]
     7b4:      	and	x12, x9, #0x7
     7b8:      	add	x14, sp, #0x630
     7bc:      	ldr	x12, [x14, x12, lsl #3]
     7c0:      	sub	x12, x12, x9
     7c4:      	add	x8, x8, x12, lsl #2
     7c8:      	movi.2d	v27, #0000000000000000
     7cc:      	movi.2d	v31, #0000000000000000
     7d0:      	tbnz	w11, #0x0, 0x18f8 <_llm_rows.packet_batch.blocks+0x1510>
     7d4:      	tbnz	w11, #0x1, 0x1900 <_llm_rows.packet_batch.blocks+0x1518>
     7d8:      	tbnz	w11, #0x2, 0x190c <_llm_rows.packet_batch.blocks+0x1524>
     7dc:      	tbnz	w11, #0x3, 0x1918 <_llm_rows.packet_batch.blocks+0x1530>
     7e0:      	tbnz	w11, #0x4, 0x1924 <_llm_rows.packet_batch.blocks+0x153c>
     7e4:      	tbnz	w11, #0x5, 0x1930 <_llm_rows.packet_batch.blocks+0x1548>
     7e8:      	tbnz	w11, #0x6, 0x193c <_llm_rows.packet_batch.blocks+0x1554>
     7ec:      	str	q21, [sp, #0x140]
     7f0:      	tbz	w11, #0x7, 0x7fc <_llm_rows.packet_batch.blocks+0x414>
     7f4:      	add	x8, x8, #0x1c
     7f8:      	ld1.s	{ v31 }[3], [x8]
     7fc:      	sshll.2d	v23, v0, #0x0
     800:      	sshll2.2d	v28, v1, #0x0
     804:      	sshll2.2d	v30, v0, #0x0
     808:      	adrp	x8, 0x0 <ltmp0>
     80c:      	ldr	q20, [x8]
     810:      	and.16b	v2, v30, v20
     814:      	adrp	x8, 0x0 <ltmp0>
     818:      	ldr	q21, [x8]
     81c:      	and.16b	v4, v28, v21
     820:      	adrp	x8, 0x0 <ltmp0>
     824:      	ldr	q24, [x8]
     828:      	and.16b	v17, v23, v24
     82c:      	adrp	x8, 0x0 <ltmp0>
     830:      	ldr	q25, [x8]
     834:      	and.16b	v25, v30, v25
     838:      	adrp	x8, 0x0 <ltmp0>
     83c:      	ldr	q26, [x8]
     840:      	and.16b	v26, v28, v26
     844:      	adrp	x8, 0x0 <ltmp0>
     848:      	ldr	q29, [x8]
     84c:      	and.16b	v23, v23, v29
     850:      	adrp	x8, 0x0 <ltmp0>
     854:      	ldr	q29, [x8]
     858:      	and.16b	v16, v16, v29
     85c:      	stp	q17, q4, [sp, #0xb0]
     860:      	orr.16b	v17, v17, v22
     864:      	orr.16b	v20, v4, v22
     868:      	str	q2, [sp, #0xd0]
     86c:      	orr.16b	v4, v2, v22
     870:      	umull.2d	v2, v19, v18
     874:      	str	q2, [sp, #0xf0]
     878:      	xtn.2s	v6, v6
     87c:      	xtn.2s	v7, v7
     880:      	xtn.2s	v5, v5
     884:      	stp	q17, q4, [sp, #0x70]
     888:      	mov.16b	v2, v4
     88c:      	umlal.2d	v2, v5, v18
     890:      	str	q2, [sp, #0x120]
     894:      	str	q20, [sp, #0x60]
     898:      	mov.16b	v2, v20
     89c:      	umlal.2d	v2, v6, v18
     8a0:      	str	q2, [sp, #0x110]
     8a4:      	mov.16b	v2, v17
     8a8:      	umlal.2d	v2, v7, v18
     8ac:      	str	q2, [sp, #0x100]
     8b0:      	sshll.2d	v6, v1, #0x0
     8b4:      	sshll.2d	v7, v0, #0x0
     8b8:      	str	q16, [sp, #0x5f0]
     8bc:      	str	q26, [sp, #0x600]
     8c0:      	str	q23, [sp, #0x610]
     8c4:      	str	q25, [sp, #0x620]
     8c8:      	and	x8, x9, #0x7
     8cc:      	add	x12, sp, #0x5f0
     8d0:      	ldr	x8, [x12, x8, lsl #3]
     8d4:      	orr	x8, x8, #0x1800
     8d8:      	sub	x8, x8, x9, lsl #2
     8dc:      	tst	w11, #0xff
     8e0:      	csel	x11, xzr, x8, eq
     8e4:      	add	x8, x25, x11
     8e8:      	ldp	q5, q18, [x8]
     8ec:      	zip2.8b	v19, v3, v0
     8f0:      	ushll.4s	v19, v19, #0x0
     8f4:      	shl.4s	v19, v19, #0x1f
     8f8:      	cmlt.4s	v19, v19, #0
     8fc:      	stp	q31, q27, [sp, #0x40]
     900:      	bit.16b	v18, v31, v19
     904:      	str	q3, [sp, #0x170]
     908:      	zip1.8b	v19, v3, v0
     90c:      	ushll.4s	v19, v19, #0x0
     910:      	shl.4s	v19, v19, #0x1f
     914:      	cmlt.4s	v19, v19, #0
     918:      	bit.16b	v5, v27, v19
     91c:      	stp	q5, q18, [x8]
     920:      	fmov	x7, d16
     924:      	dup.2d	v16, x21
     928:      	and.16b	v25, v30, v16
     92c:      	and.16b	v5, v28, v16
     930:      	and.16b	v23, v7, v16
     934:      	and.16b	v7, v6, v16
     938:      	fmov	x6, d7
     93c:      	ldr	q6, [sp, #0x4f40]
     940:      	ldr	q16, [sp, #0x4f50]
     944:      	and.16b	v19, v0, v16
     948:      	and.16b	v18, v1, v6
     94c:      	ldr	q6, [sp, #0x4f20]
     950:      	ldr	q16, [sp, #0x4f30]
     954:      	and.16b	v8, v0, v16
     958:      	and.16b	v29, v1, v6
     95c:      	ldr	q6, [sp, #0x4f00]
     960:      	ldr	q16, [sp, #0x4f10]
     964:      	and.16b	v9, v0, v16
     968:      	and.16b	v11, v1, v6
     96c:      	add	x8, x25, x7
     970:      	ldp	q6, q16, [x8]
     974:      	and.16b	v12, v0, v16
     978:      	mov	x8, x6
     97c:      	and.16b	v13, v1, v6
     980:      	mov.16b	v22, v7
     984:      	mov.16b	v15, v5
     988:      	mov.16b	v6, v23
     98c:      	mov.16b	v16, v25
     990:      	sshll.2d	v3, v1, #0x0
     994:      	sshll.2d	v10, v0, #0x0
     998:      	add	x8, x25, x8, lsl #5
     99c:      	ldp	q14, q26, [x8]
     9a0:      	fadd.4s	v14, v13, v14
     9a4:      	fadd.4s	v26, v12, v26
     9a8:      	ldp	q27, q17, [x8, #0x20]
     9ac:      	fadd.4s	v27, v11, v27
     9b0:      	fadd.4s	v17, v9, v17
     9b4:      	ldp	q4, q31, [x8, #0x40]
     9b8:      	fadd.4s	v4, v29, v4
     9bc:      	fadd.4s	v31, v8, v31
     9c0:      	ldp	q21, q20, [x8, #0x60]
     9c4:      	fadd.4s	v21, v18, v21
     9c8:      	fadd.4s	v20, v19, v20
     9cc:      	dup.2d	v24, x21
     9d0:      	and.16b	v2, v30, v24
     9d4:      	add.2d	v16, v16, v2
     9d8:      	and.16b	v2, v28, v24
     9dc:      	add.2d	v15, v15, v2
     9e0:      	and.16b	v2, v10, v24
     9e4:      	add.2d	v6, v6, v2
     9e8:      	and.16b	v2, v3, v24
     9ec:      	add.2d	v22, v22, v2
     9f0:      	bit.16b	v12, v26, v0
     9f4:      	bit.16b	v13, v14, v1
     9f8:      	bit.16b	v9, v17, v0
     9fc:      	bit.16b	v11, v27, v1
     a00:      	bit.16b	v8, v31, v0
     a04:      	bit.16b	v29, v4, v1
     a08:      	bit.16b	v19, v20, v0
     a0c:      	bit.16b	v18, v21, v1
     a10:      	fmov	x8, d22
     a14:      	cmp	x8, #0xc0
     a18:      	b.lt	0x990 <_llm_rows.packet_batch.blocks+0x5a8>
     a1c:      	mov	x30, #0x0               ; =0
     a20:      	movi	d2, #0xffffffffffff0000
     a24:      	ldp	q16, q6, [sp, #0x160]
     a28:      	and.8b	v17, v16, v2
     a2c:      	ldp	q10, q31, [sp, #0x40]
     a30:      	fadd.4s	v2, v10, v12
     a34:      	fadd.4s	v3, v31, v13
     a38:      	zip1.8b	v4, v6, v0
     a3c:      	ushll.4s	v4, v4, #0x0
     a40:      	shl.4s	v4, v4, #0x1f
     a44:      	cmlt.4s	v4, v4, #0
     a48:      	and.16b	v3, v4, v3
     a4c:      	zip2.8b	v4, v6, v0
     a50:      	ushll.4s	v4, v4, #0x0
     a54:      	shl.4s	v4, v4, #0x1f
     a58:      	cmlt.4s	v4, v4, #0
     a5c:      	and.16b	v2, v4, v2
     a60:      	zip2.8b	v4, v17, v0
     a64:      	ushll.4s	v4, v4, #0x0
     a68:      	shl.4s	v4, v4, #0x1f
     a6c:      	cmlt.4s	v4, v4, #0
     a70:      	bit.16b	v2, v26, v4
     a74:      	str	d17, [sp, #0xa0]
     a78:      	zip1.8b	v4, v17, v0
     a7c:      	ushll.4s	v4, v4, #0x0
     a80:      	shl.4s	v4, v4, #0x1f
     a84:      	cmlt.4s	v4, v4, #0
     a88:      	bit.16b	v3, v14, v4
     a8c:      	fadd.4s	v3, v11, v3
     a90:      	fadd.4s	v2, v9, v2
     a94:      	fadd.4s	v2, v8, v2
     a98:      	fadd.4s	v3, v29, v3
     a9c:      	fadd.4s	v18, v18, v3
     aa0:      	fadd.4s	v19, v19, v2
     aa4:      	ldp	q2, q4, [sp, #0xd0]
     aa8:      	ldr	q3, [sp, #0xc0]
     aac:      	uzp1.4s	v3, v4, v3
     ab0:      	ldr	q4, [sp, #0xb0]
     ab4:      	uzp1.4s	v20, v4, v2
     ab8:      	movi.4s	v4, #0x1
     abc:      	eor.16b	v2, v3, v4
     ac0:      	mov.s	w14, v2[1]
     ac4:      	mov.s	w15, v2[2]
     ac8:      	eor.16b	v8, v20, v4
     acc:      	mov.s	w17, v2[3]
     ad0:      	fmov	w8, s2
     ad4:      	add	x12, sp, #0x488
     ad8:      	bfxil	x12, x8, #0, #3
     adc:      	str	d16, [sp, #0x488]
     ae0:      	ldrb	w16, [x12]
     ae4:      	and	x8, x8, #0x7
     ae8:      	umov.b	w12, v16[0]
     aec:      	str	q19, [sp, #0x560]
     af0:      	str	q18, [sp, #0x550]
     af4:      	add	x0, sp, #0x550
     af8:      	ldr	s2, [x0, x8, lsl #2]
     afc:      	ands	w8, w12, #0x1
     b00:      	tst	w8, w16
     b04:      	movi	d22, #0000000000000000
     b08:      	fcsel	s21, s2, s22, ne
     b0c:      	and	x0, x14, #0x7
     b10:      	add	x16, sp, #0x488
     b14:      	bfxil	x16, x14, #0, #3
     b18:      	ldrb	w14, [x16]
     b1c:      	umov.b	w16, v16[1]
     b20:      	and	w14, w16, w14
     b24:      	str	q19, [sp, #0x540]
     b28:      	str	q18, [sp, #0x530]
     b2c:      	add	x1, sp, #0x530
     b30:      	ldr	s2, [x1, x0, lsl #2]
     b34:      	tst	w14, #0x1
     b38:      	fcsel	s24, s2, s22, ne
     b3c:      	and	x0, x15, #0x7
     b40:      	add	x1, sp, #0x488
     b44:      	bfxil	x1, x15, #0, #3
     b48:      	umov.b	w14, v16[2]
     b4c:      	ldrb	w15, [x1]
     b50:      	and	w15, w14, w15
     b54:      	str	q19, [sp, #0x520]
     b58:      	str	q18, [sp, #0x510]
     b5c:      	add	x1, sp, #0x510
     b60:      	ldr	s2, [x1, x0, lsl #2]
     b64:      	tst	w15, #0x1
     b68:      	fcsel	s29, s2, s22, ne
     b6c:      	and	x0, x17, #0x7
     b70:      	add	x15, sp, #0x488
     b74:      	bfxil	x15, x17, #0, #3
     b78:      	ldrb	w17, [x15]
     b7c:      	umov.b	w15, v16[3]
     b80:      	str	q19, [sp, #0x500]
     b84:      	str	q18, [sp, #0x4f0]
     b88:      	add	x1, sp, #0x4f0
     b8c:      	ldr	s2, [x1, x0, lsl #2]
     b90:      	and	w17, w15, w17
     b94:      	tst	w17, #0x1
     b98:      	mov.s	w17, v8[1]
     b9c:      	mov.s	w0, v8[2]
     ba0:      	fcsel	s9, s2, s22, ne
     ba4:      	mov.s	w1, v8[3]
     ba8:      	fmov	w2, s8
     bac:      	and	x4, x2, #0x7
     bb0:      	add	x3, sp, #0x488
     bb4:      	bfxil	x3, x2, #0, #3
     bb8:      	ldrb	w2, [x3]
     bbc:      	umov.b	w3, v16[4]
     bc0:      	and	w2, w3, w2
     bc4:      	str	q19, [sp, #0x5e0]
     bc8:      	str	q18, [sp, #0x5d0]
     bcc:      	add	x5, sp, #0x5d0
     bd0:      	ldr	s2, [x5, x4, lsl #2]
     bd4:      	tst	w2, #0x1
     bd8:      	fcsel	s2, s2, s22, ne
     bdc:      	and	x4, x17, #0x7
     be0:      	add	x2, sp, #0x488
     be4:      	bfxil	x2, x17, #0, #3
     be8:      	ldrb	w17, [x2]
     bec:      	umov.b	w2, v16[5]
     bf0:      	and	w17, w2, w17
     bf4:      	str	q19, [sp, #0x5c0]
     bf8:      	str	q18, [sp, #0x5b0]
     bfc:      	add	x5, sp, #0x5b0
     c00:      	ldr	s4, [x5, x4, lsl #2]
     c04:      	tst	w17, #0x1
     c08:      	fcsel	s4, s4, s22, ne
     c0c:      	and	x17, x0, #0x7
     c10:      	add	x4, sp, #0x488
     c14:      	bfxil	x4, x0, #0, #3
     c18:      	ldrb	w4, [x4]
     c1c:      	umov.b	w0, v16[6]
     c20:      	and	w4, w0, w4
     c24:      	str	q19, [sp, #0x5a0]
     c28:      	str	q18, [sp, #0x590]
     c2c:      	add	x5, sp, #0x590
     c30:      	ldr	s6, [x5, x17, lsl #2]
     c34:      	tst	w4, #0x1
     c38:      	fcsel	s6, s6, s22, ne
     c3c:      	and	x17, x1, #0x7
     c40:      	add	x4, sp, #0x488
     c44:      	bfxil	x4, x1, #0, #3
     c48:      	umov.b	w1, v16[7]
     c4c:      	ldrb	w4, [x4]
     c50:      	and	w4, w1, w4
     c54:      	str	q19, [sp, #0x580]
     c58:      	str	q18, [sp, #0x570]
     c5c:      	add	x5, sp, #0x570
     c60:      	ldr	s16, [x5, x17, lsl #2]
     c64:      	tst	w4, #0x1
     c68:      	fcsel	s16, s16, s22, ne
     c6c:      	mov.s	v2[1], v4[0]
     c70:      	mov.s	v2[2], v6[0]
     c74:      	mov.s	v2[3], v16[0]
     c78:      	mov.s	v21[1], v24[0]
     c7c:      	mov.s	v21[2], v29[0]
     c80:      	mov.s	v21[3], v9[0]
     c84:      	fadd.4s	v4, v18, v21
     c88:      	fadd.4s	v2, v19, v2
     c8c:      	movi.4s	v16, #0x2
     c90:      	eor.16b	v6, v20, v16
     c94:      	eor.16b	v3, v3, v16
     c98:      	fmov	w17, s3
     c9c:      	add	x4, sp, #0x488
     ca0:      	bfxil	x4, x17, #0, #3
     ca4:      	ldrb	w4, [x4]
     ca8:      	and	x17, x17, #0x7
     cac:      	str	q2, [sp, #0x4e0]
     cb0:      	str	q4, [sp, #0x4d0]
     cb4:      	add	x5, sp, #0x4d0
     cb8:      	ldr	s3, [x5, x17, lsl #2]
     cbc:      	tst	w8, w4
     cc0:      	fcsel	s3, s3, s22, ne
     cc4:      	fmov	w8, s6
     cc8:      	and	x17, x8, #0x7
     ccc:      	add	x4, sp, #0x488
     cd0:      	bfxil	x4, x8, #0, #3
     cd4:      	ldrb	w8, [x4]
     cd8:      	and	w8, w3, w8
     cdc:      	str	q2, [sp, #0x4c0]
     ce0:      	str	q4, [sp, #0x4b0]
     ce4:      	add	x4, sp, #0x4b0
     ce8:      	ldr	s6, [x4, x17, lsl #2]
     cec:      	tst	w8, #0x1
     cf0:      	fcsel	s6, s6, s22, ne
     cf4:      	fadd.4s	v2, v2, v6
     cf8:      	and	w17, w12, w3
     cfc:      	tst	w17, #0x1
     d00:      	fcsel	s2, s2, s22, ne
     d04:      	ands	w5, w12, #0x1
     d08:      	fadd.4s	v3, v4, v3
     d0c:      	fadd	s2, s3, s2
     d10:      	fcsel	s3, s2, s22, ne
     d14:      	tst	w17, #0x1
     d18:      	and	w8, w16, w12
     d1c:      	fcsel	s4, s2, s22, ne
     d20:      	str	w8, [sp, #0xe0]
     d24:      	tst	w8, #0x1
     d28:      	and	w8, w14, w12
     d2c:      	fcsel	s6, s2, s22, ne
     d30:      	str	w8, [sp, #0xd0]
     d34:      	tst	w8, #0x1
     d38:      	and	w8, w15, w12
     d3c:      	fcsel	s16, s2, s22, ne
     d40:      	str	w8, [sp, #0xc0]
     d44:      	tst	w8, #0x1
     d48:      	fcsel	s17, s2, s22, ne
     d4c:      	and	w8, w2, w12
     d50:      	str	w8, [sp, #0xb0]
     d54:      	tst	w8, #0x1
     d58:      	fcsel	s18, s2, s22, ne
     d5c:      	and	w8, w0, w12
     d60:      	tst	w8, #0x1
     d64:      	fcsel	s19, s2, s22, ne
     d68:      	and	w4, w1, w12
     d6c:      	tst	w4, #0x1
     d70:      	fcsel	s2, s2, s22, ne
     d74:      	mov.s	v3[1], v6[0]
     d78:      	mov.s	v3[2], v16[0]
     d7c:      	mov.s	v3[3], v17[0]
     d80:      	mov.s	v4[1], v18[0]
     d84:      	mov.s	v4[2], v19[0]
     d88:      	mov.s	v4[3], v2[0]
     d8c:      	rbit	w23, w28
     d90:      	clz	w23, w23
     d94:      	str	q4, [sp, #0x4a0]
     d98:      	str	q3, [sp, #0x490]
     d9c:      	str	x23, [sp, #0xa8]
     da0:      	and	x23, x23, #0x7
     da4:      	add	x28, sp, #0x490
     da8:      	ldr	s2, [x28, x23, lsl #2]
     dac:      	fadd	s2, s2, s22
     db0:      	mov	w23, #0x4000            ; =16384
     db4:      	movk	w23, #0x44c0, lsl #16
     db8:      	fmov	s3, w23
     dbc:      	fdiv	s2, s2, s3
     dc0:      	dup.4s	v3, v2[0]
     dc4:      	mov	w23, #0x1               ; =1
     dc8:      	dup.2d	v2, x23
     dcc:      	ushll2.2d	v4, v0, #0x0
     dd0:      	and.16b	v18, v4, v2
     dd4:      	ushll2.2d	v4, v1, #0x0
     dd8:      	and.16b	v19, v4, v2
     ddc:      	ushll.2d	v4, v0, #0x0
     de0:      	and.16b	v20, v4, v2
     de4:      	ushll.2d	v4, v1, #0x0
     de8:      	and.16b	v21, v4, v2
     dec:      	movi.2d	v6, #0000000000000000
     df0:      	movi.2d	v16, #0000000000000000
     df4:      	movi.2d	v24, #0000000000000000
     df8:      	movi.2d	v26, #0000000000000000
     dfc:      	lsl	x23, x30, #5
     e00:      	add	x28, x25, x23
     e04:      	ldp	q4, q2, [x28]
     e08:      	fsub.4s	v4, v4, v3
     e0c:      	fsub.4s	v2, v2, v3
     e10:      	add	x23, x19, x23
     e14:      	ldp	q17, q27, [x23]
     e18:      	bif.16b	v2, v27, v0
     e1c:      	bif.16b	v4, v17, v1
     e20:      	stp	q4, q2, [x23]
     e24:      	add.2d	v16, v16, v19
     e28:      	add.2d	v24, v24, v20
     e2c:      	add.2d	v26, v26, v18
     e30:      	add.2d	v6, v6, v21
     e34:      	fmov	x30, d6
     e38:      	cmp	x30, #0xc0
     e3c:      	b.lt	0xdfc <_llm_rows.packet_batch.blocks+0xa14>
     e40:      	fsub.4s	v16, v31, v3
     e44:      	fsub.4s	v17, v10, v3
     e48:      	add	x23, x19, x11
     e4c:      	ldp	q2, q3, [x23]
     e50:      	ldr	q6, [sp, #0x170]
     e54:      	zip2.8b	v4, v6, v0
     e58:      	ushll.4s	v4, v4, #0x0
     e5c:      	shl.4s	v4, v4, #0x1f
     e60:      	cmlt.4s	v4, v4, #0
     e64:      	stp	q17, q16, [sp, #0x40]
     e68:      	bit.16b	v3, v17, v4
     e6c:      	zip1.8b	v4, v6, v0
     e70:      	ushll.4s	v4, v4, #0x0
     e74:      	shl.4s	v4, v4, #0x1f
     e78:      	cmlt.4s	v4, v4, #0
     e7c:      	bit.16b	v2, v16, v4
     e80:      	stp	q2, q3, [x23]
     e84:      	ldr	q2, [sp, #0x3730]
     e88:      	ldr	q3, [sp, #0x3720]
     e8c:      	fmul.4s	v3, v3, v3
     e90:      	fmul.4s	v2, v2, v2
     e94:      	and.16b	v27, v0, v2
     e98:      	and.16b	v31, v1, v3
     e9c:      	ldr	q2, [sp, #0x3710]
     ea0:      	ldr	q3, [sp, #0x3700]
     ea4:      	fmul.4s	v3, v3, v3
     ea8:      	fmul.4s	v2, v2, v2
     eac:      	and.16b	v13, v0, v2
     eb0:      	and.16b	v12, v1, v3
     eb4:      	ldr	q2, [sp, #0x36f0]
     eb8:      	ldr	q3, [sp, #0x36e0]
     ebc:      	fmul.4s	v3, v3, v3
     ec0:      	fmul.4s	v2, v2, v2
     ec4:      	and.16b	v14, v0, v2
     ec8:      	and.16b	v15, v1, v3
     ecc:      	add	x7, x19, x7
     ed0:      	ldp	q3, q2, [x7]
     ed4:      	fmul.4s	v3, v3, v3
     ed8:      	fmul.4s	v2, v2, v2
     edc:      	and.16b	v9, v0, v2
     ee0:      	and.16b	v8, v1, v3
     ee4:      	sshll.2d	v2, v1, #0x0
     ee8:      	sshll.2d	v4, v0, #0x0
     eec:      	add	x6, x19, x6, lsl #5
     ef0:      	ldp	q6, q3, [x6]
     ef4:      	and.16b	v6, v1, v6
     ef8:      	and.16b	v3, v0, v3
     efc:      	fmul.4s	v16, v3, v3
     f00:      	fmul.4s	v3, v6, v6
     f04:      	fadd.4s	v3, v8, v3
     f08:      	fadd.4s	v24, v9, v16
     f0c:      	ldp	q16, q6, [x6, #0x20]
     f10:      	and.16b	v16, v1, v16
     f14:      	and.16b	v6, v0, v6
     f18:      	fmul.4s	v6, v6, v6
     f1c:      	fmul.4s	v16, v16, v16
     f20:      	fadd.4s	v16, v15, v16
     f24:      	fadd.4s	v6, v14, v6
     f28:      	ldp	q26, q17, [x6, #0x40]
     f2c:      	and.16b	v26, v1, v26
     f30:      	and.16b	v17, v0, v17
     f34:      	fmul.4s	v17, v17, v17
     f38:      	fmul.4s	v26, v26, v26
     f3c:      	fadd.4s	v26, v12, v26
     f40:      	fadd.4s	v17, v13, v17
     f44:      	ldp	q29, q10, [x6, #0x60]
     f48:      	and.16b	v29, v1, v29
     f4c:      	and.16b	v10, v0, v10
     f50:      	fmul.4s	v10, v10, v10
     f54:      	fmul.4s	v29, v29, v29
     f58:      	fadd.4s	v29, v31, v29
     f5c:      	fadd.4s	v10, v27, v10
     f60:      	dup.2d	v11, x21
     f64:      	and.16b	v22, v30, v11
     f68:      	add.2d	v25, v25, v22
     f6c:      	and.16b	v22, v28, v11
     f70:      	add.2d	v5, v5, v22
     f74:      	and.16b	v4, v4, v11
     f78:      	add.2d	v23, v23, v4
     f7c:      	and.16b	v2, v2, v11
     f80:      	add.2d	v7, v7, v2
     f84:      	bit.16b	v9, v24, v0
     f88:      	bit.16b	v8, v3, v1
     f8c:      	bit.16b	v14, v6, v0
     f90:      	bit.16b	v15, v16, v1
     f94:      	bit.16b	v13, v17, v0
     f98:      	bit.16b	v12, v26, v1
     f9c:      	bit.16b	v27, v10, v0
     fa0:      	bit.16b	v31, v29, v1
     fa4:      	fmov	x6, d7
     fa8:      	cmp	x6, #0xc0
     fac:      	b.lt	0xee4 <_llm_rows.packet_batch.blocks+0xafc>
     fb0:      	mov	x6, #0x0                ; =0
     fb4:      	movi.2d	v5, #0000000000000000
     fb8:      	movi.2d	v6, #0000000000000000
     fbc:      	movi.2d	v7, #0000000000000000
     fc0:      	movi.2d	v16, #0000000000000000
     fc4:      	add	x21, sp, #0x1, lsl #12  ; =0x1000
     fc8:      	add	x21, x21, #0xea0
     fcc:      	ldr	q10, [sp, #0x140]
     fd0:      	ldr	q11, [sp, #0x170]
     fd4:      	b	0x1008 <_llm_rows.packet_batch.blocks+0xc20>
     fd8:      	add	x6, x21, x6
     fdc:      	ldp	q2, q4, [x6]
     fe0:      	bit.16b	v4, v30, v0
     fe4:      	bit.16b	v2, v28, v1
     fe8:      	stp	q2, q4, [x6]
     fec:      	add.2d	v6, v6, v19
     ff0:      	add.2d	v7, v7, v20
     ff4:      	add.2d	v16, v16, v18
     ff8:      	add.2d	v5, v5, v21
     ffc:      	fmov	x6, d5
    1000:      	cmp	x6, #0xc0
    1004:      	b.ge	0x10a4 <_llm_rows.packet_batch.blocks+0xcbc>
    1008:      	fmov	w23, s10
    100c:      	lsl	x6, x6, #5
    1010:      	add	x7, x13, x6
    1014:      	movi.2d	v28, #0000000000000000
    1018:      	movi.2d	v30, #0000000000000000
    101c:      	tbnz	w23, #0x0, 0x1044 <_llm_rows.packet_batch.blocks+0xc5c>
    1020:      	and	w30, w23, #0xff
    1024:      	tbnz	w30, #0x1, 0x1050 <_llm_rows.packet_batch.blocks+0xc68>
    1028:      	tbnz	w30, #0x2, 0x105c <_llm_rows.packet_batch.blocks+0xc74>
    102c:      	tbnz	w30, #0x3, 0x1068 <_llm_rows.packet_batch.blocks+0xc80>
    1030:      	tbnz	w30, #0x4, 0x1074 <_llm_rows.packet_batch.blocks+0xc8c>
    1034:      	tbnz	w30, #0x5, 0x1080 <_llm_rows.packet_batch.blocks+0xc98>
    1038:      	tbnz	w30, #0x6, 0x108c <_llm_rows.packet_batch.blocks+0xca4>
    103c:      	tbz	w30, #0x7, 0xfd8 <_llm_rows.packet_batch.blocks+0xbf0>
    1040:      	b	0x1098 <_llm_rows.packet_batch.blocks+0xcb0>
    1044:      	ldr	s28, [x7]
    1048:      	and	w30, w23, #0xff
    104c:      	tbz	w30, #0x1, 0x1028 <_llm_rows.packet_batch.blocks+0xc40>
    1050:      	add	x23, x7, #0x4
    1054:      	ld1.s	{ v28 }[1], [x23]
    1058:      	tbz	w30, #0x2, 0x102c <_llm_rows.packet_batch.blocks+0xc44>
    105c:      	add	x23, x7, #0x8
    1060:      	ld1.s	{ v28 }[2], [x23]
    1064:      	tbz	w30, #0x3, 0x1030 <_llm_rows.packet_batch.blocks+0xc48>
    1068:      	add	x23, x7, #0xc
    106c:      	ld1.s	{ v28 }[3], [x23]
    1070:      	tbz	w30, #0x4, 0x1034 <_llm_rows.packet_batch.blocks+0xc4c>
    1074:      	add	x23, x7, #0x10
    1078:      	ld1.s	{ v30 }[0], [x23]
    107c:      	tbz	w30, #0x5, 0x1038 <_llm_rows.packet_batch.blocks+0xc50>
    1080:      	add	x23, x7, #0x14
    1084:      	ld1.s	{ v30 }[1], [x23]
    1088:      	tbz	w30, #0x6, 0x103c <_llm_rows.packet_batch.blocks+0xc54>
    108c:      	add	x23, x7, #0x18
    1090:      	ld1.s	{ v30 }[2], [x23]
    1094:      	tbz	w30, #0x7, 0xfd8 <_llm_rows.packet_batch.blocks+0xbf0>
    1098:      	add	x7, x7, #0x1c
    109c:      	ld1.s	{ v30 }[3], [x7]
    10a0:      	b	0xfd8 <_llm_rows.packet_batch.blocks+0xbf0>
    10a4:      	mov	b2, v11[0]
    10a8:      	mov.b	v2[4], v11[1]
    10ac:      	ushll.2d	v2, v2, #0x0
    10b0:      	shl.2d	v2, v2, #0x3f
    10b4:      	cmlt.2d	v2, v2, #0
    10b8:      	ldr	q4, [sp, #0x90]
    10bc:      	and.16b	v2, v2, v4
    10c0:      	mov	b4, v11[2]
    10c4:      	mov.b	v4[4], v11[3]
    10c8:      	ushll.2d	v4, v4, #0x0
    10cc:      	shl.2d	v4, v4, #0x3f
    10d0:      	cmlt.2d	v4, v4, #0
    10d4:      	mov	b5, v11[4]
    10d8:      	mov.b	v5[4], v11[5]
    10dc:      	ldp	q7, q6, [sp, #0x60]
    10e0:      	and.16b	v4, v4, v7
    10e4:      	ushll.2d	v5, v5, #0x0
    10e8:      	shl.2d	v5, v5, #0x3f
    10ec:      	cmlt.2d	v5, v5, #0
    10f0:      	and.16b	v6, v5, v6
    10f4:      	mov	b5, v11[6]
    10f8:      	mov.b	v5[4], v11[7]
    10fc:      	ushll.2d	v5, v5, #0x0
    1100:      	shl.2d	v5, v5, #0x3f
    1104:      	cmlt.2d	v5, v5, #0
    1108:      	ldr	q7, [sp, #0x80]
    110c:      	and.16b	v7, v5, v7
    1110:      	adrp	x6, 0x1000 <_llm_rows.packet_batch.blocks+0xc18>
    1114:      	ldr	d5, [x6]
    1118:      	shl.8b	v16, v11, #0x7
    111c:      	cmlt.8b	v16, v16, #0
    1120:      	and.8b	v5, v16, v5
    1124:      	addv.8b	b5, v5
    1128:      	str	q7, [sp, #0x470]
    112c:      	str	q6, [sp, #0x460]
    1130:      	str	q4, [sp, #0x450]
    1134:      	str	q2, [sp, #0x440]
    1138:      	and	x6, x9, #0x7
    113c:      	add	x7, sp, #0x440
    1140:      	ldr	x6, [x7, x6, lsl #3]
    1144:      	fmov	w7, s5
    1148:      	sub	x6, x6, x9
    114c:      	lsl	x6, x6, #2
    1150:      	add	x13, x13, x6
    1154:      	movi.2d	v25, #0000000000000000
    1158:      	movi.2d	v23, #0000000000000000
    115c:      	tbnz	w7, #0x0, 0x1950 <_llm_rows.packet_batch.blocks+0x1568>
    1160:      	tbnz	w7, #0x1, 0x1958 <_llm_rows.packet_batch.blocks+0x1570>
    1164:      	tbnz	w7, #0x2, 0x1964 <_llm_rows.packet_batch.blocks+0x157c>
    1168:      	tbnz	w7, #0x3, 0x1970 <_llm_rows.packet_batch.blocks+0x1588>
    116c:      	tbnz	w7, #0x4, 0x197c <_llm_rows.packet_batch.blocks+0x1594>
    1170:      	tbnz	w7, #0x5, 0x1988 <_llm_rows.packet_batch.blocks+0x15a0>
    1174:      	tbnz	w7, #0x6, 0x1994 <_llm_rows.packet_batch.blocks+0x15ac>
    1178:      	tbz	w7, #0x7, 0x1184 <_llm_rows.packet_batch.blocks+0xd9c>
    117c:      	add	x13, x13, #0x1c
    1180:      	ld1.s	{ v23 }[3], [x13]
    1184:      	mov	x13, #0x0               ; =0
    1188:      	add	x7, x21, x11
    118c:      	ldp	q2, q4, [x7]
    1190:      	zip2.8b	v6, v11, v0
    1194:      	ushll.4s	v6, v6, #0x0
    1198:      	shl.4s	v6, v6, #0x1f
    119c:      	cmlt.4s	v6, v6, #0
    11a0:      	bit.16b	v4, v23, v6
    11a4:      	zip1.8b	v6, v11, v0
    11a8:      	ushll.4s	v6, v6, #0x0
    11ac:      	shl.4s	v6, v6, #0x1f
    11b0:      	cmlt.4s	v6, v6, #0
    11b4:      	bit.16b	v2, v25, v6
    11b8:      	stp	q2, q4, [x7]
    11bc:      	movi.2d	v6, #0000000000000000
    11c0:      	movi.2d	v7, #0000000000000000
    11c4:      	movi.2d	v16, #0000000000000000
    11c8:      	movi.2d	v26, #0000000000000000
    11cc:      	b	0x1200 <_llm_rows.packet_batch.blocks+0xe18>
    11d0:      	add	x13, x27, x13
    11d4:      	ldp	q2, q4, [x13]
    11d8:      	bit.16b	v4, v30, v0
    11dc:      	bit.16b	v2, v28, v1
    11e0:      	stp	q2, q4, [x13]
    11e4:      	add.2d	v7, v7, v19
    11e8:      	add.2d	v16, v16, v20
    11ec:      	add.2d	v26, v26, v18
    11f0:      	add.2d	v6, v6, v21
    11f4:      	fmov	x13, d6
    11f8:      	cmp	x13, #0xc0
    11fc:      	b.ge	0x129c <_llm_rows.packet_batch.blocks+0xeb4>
    1200:      	fmov	w23, s10
    1204:      	lsl	x13, x13, #5
    1208:      	add	x7, x10, x13
    120c:      	movi.2d	v28, #0000000000000000
    1210:      	movi.2d	v30, #0000000000000000
    1214:      	tbnz	w23, #0x0, 0x123c <_llm_rows.packet_batch.blocks+0xe54>
    1218:      	and	w30, w23, #0xff
    121c:      	tbnz	w30, #0x1, 0x1248 <_llm_rows.packet_batch.blocks+0xe60>
    1220:      	tbnz	w30, #0x2, 0x1254 <_llm_rows.packet_batch.blocks+0xe6c>
    1224:      	tbnz	w30, #0x3, 0x1260 <_llm_rows.packet_batch.blocks+0xe78>
    1228:      	tbnz	w30, #0x4, 0x126c <_llm_rows.packet_batch.blocks+0xe84>
    122c:      	tbnz	w30, #0x5, 0x1278 <_llm_rows.packet_batch.blocks+0xe90>
    1230:      	tbnz	w30, #0x6, 0x1284 <_llm_rows.packet_batch.blocks+0xe9c>
    1234:      	tbz	w30, #0x7, 0x11d0 <_llm_rows.packet_batch.blocks+0xde8>
    1238:      	b	0x1290 <_llm_rows.packet_batch.blocks+0xea8>
    123c:      	ldr	s28, [x7]
    1240:      	and	w30, w23, #0xff
    1244:      	tbz	w30, #0x1, 0x1220 <_llm_rows.packet_batch.blocks+0xe38>
    1248:      	add	x23, x7, #0x4
    124c:      	ld1.s	{ v28 }[1], [x23]
    1250:      	tbz	w30, #0x2, 0x1224 <_llm_rows.packet_batch.blocks+0xe3c>
    1254:      	add	x23, x7, #0x8
    1258:      	ld1.s	{ v28 }[2], [x23]
    125c:      	tbz	w30, #0x3, 0x1228 <_llm_rows.packet_batch.blocks+0xe40>
    1260:      	add	x23, x7, #0xc
    1264:      	ld1.s	{ v28 }[3], [x23]
    1268:      	tbz	w30, #0x4, 0x122c <_llm_rows.packet_batch.blocks+0xe44>
    126c:      	add	x23, x7, #0x10
    1270:      	ld1.s	{ v30 }[0], [x23]
    1274:      	tbz	w30, #0x5, 0x1230 <_llm_rows.packet_batch.blocks+0xe48>
    1278:      	add	x23, x7, #0x14
    127c:      	ld1.s	{ v30 }[1], [x23]
    1280:      	tbz	w30, #0x6, 0x1234 <_llm_rows.packet_batch.blocks+0xe4c>
    1284:      	add	x23, x7, #0x18
    1288:      	ld1.s	{ v30 }[2], [x23]
    128c:      	tbz	w30, #0x7, 0x11d0 <_llm_rows.packet_batch.blocks+0xde8>
    1290:      	add	x7, x7, #0x1c
    1294:      	ld1.s	{ v30 }[3], [x7]
    1298:      	b	0x11d0 <_llm_rows.packet_batch.blocks+0xde8>
    129c:      	adrp	x13, 0x1000 <_llm_rows.packet_batch.blocks+0xc18>
    12a0:      	ldr	q2, [x13]
    12a4:      	and.16b	v16, v0, v2
    12a8:      	adrp	x13, 0x1000 <_llm_rows.packet_batch.blocks+0xc18>
    12ac:      	ldr	q2, [x13]
    12b0:      	and.16b	v28, v1, v2
    12b4:      	adrp	x13, 0x1000 <_llm_rows.packet_batch.blocks+0xc18>
    12b8:      	ldr	q7, [x13]
    12bc:      	zip2.8b	v2, v11, v0
    12c0:      	ushll.4s	v2, v2, #0x0
    12c4:      	shl.4s	v2, v2, #0x1f
    12c8:      	cmlt.4s	v2, v2, #0
    12cc:      	ldp	q4, q6, [sp, #0x40]
    12d0:      	and.16b	v26, v2, v4
    12d4:      	zip1.8b	v4, v11, v0
    12d8:      	ushll.4s	v4, v4, #0x0
    12dc:      	shl.4s	v4, v4, #0x1f
    12e0:      	cmlt.4s	v4, v4, #0
    12e4:      	and.16b	v6, v4, v6
    12e8:      	fmul.4s	v17, v6, v6
    12ec:      	fmul.4s	v22, v26, v26
    12f0:      	fadd.4s	v22, v22, v9
    12f4:      	fadd.4s	v17, v17, v8
    12f8:      	and.16b	v4, v4, v17
    12fc:      	and.16b	v2, v2, v22
    1300:      	ldr	d22, [sp, #0xa0]
    1304:      	zip2.8b	v17, v22, v0
    1308:      	ushll.4s	v17, v17, #0x0
    130c:      	shl.4s	v17, v17, #0x1f
    1310:      	cmlt.4s	v17, v17, #0
    1314:      	bit.16b	v2, v24, v17
    1318:      	zip1.8b	v17, v22, v0
    131c:      	ushll.4s	v17, v17, #0x0
    1320:      	shl.4s	v17, v17, #0x1f
    1324:      	cmlt.4s	v17, v17, #0
    1328:      	bif.16b	v3, v4, v17
    132c:      	fadd.4s	v3, v15, v3
    1330:      	fadd.4s	v2, v14, v2
    1334:      	fadd.4s	v2, v13, v2
    1338:      	fadd.4s	v3, v12, v3
    133c:      	fadd.4s	v3, v31, v3
    1340:      	fadd.4s	v22, v27, v2
    1344:      	fmov	w13, s28
    1348:      	add	x7, sp, #0x1e8
    134c:      	bfxil	x7, x13, #0, #3
    1350:      	ldr	q2, [sp, #0x160]
    1354:      	str	d2, [sp, #0x1e8]
    1358:      	ldrb	w7, [x7]
    135c:      	add	x23, sp, #0x410
    1360:      	orr	x13, x23, x13, lsl #2
    1364:      	str	q22, [sp, #0x420]
    1368:      	str	q3, [sp, #0x410]
    136c:      	ldr	s2, [x13]
    1370:      	tst	w5, w7
    1374:      	movi	d30, #0000000000000000
    1378:      	fcsel	s17, s2, s30, ne
    137c:      	mov.s	w13, v28[1]
    1380:      	add	x7, sp, #0x1e8
    1384:      	bfxil	x7, x13, #0, #3
    1388:      	ldrb	w13, [x7]
    138c:      	and	w13, w16, w13
    1390:      	str	q3, [sp, #0x3f0]
    1394:      	ldr	s2, [sp, #0x3f0]
    1398:      	tst	w13, #0x1
    139c:      	mov.s	w13, v28[2]
    13a0:      	fcsel	s24, s2, s30, ne
    13a4:      	add	x7, sp, #0x1e8
    13a8:      	bfxil	x7, x13, #0, #3
    13ac:      	add	x23, sp, #0x3d0
    13b0:      	orr	x13, x23, x13, lsl #2
    13b4:      	ldrb	w7, [x7]
    13b8:      	and	w7, w14, w7
    13bc:      	stp	q3, q22, [sp, #0x3d0]
    13c0:      	ldr	s2, [x13]
    13c4:      	tst	w7, #0x1
    13c8:      	mov.s	w13, v28[3]
    13cc:      	fcsel	s27, s2, s30, ne
    13d0:      	add	x7, sp, #0x1e8
    13d4:      	bfxil	x7, x13, #0, #3
    13d8:      	add	x23, sp, #0x3b0
    13dc:      	orr	x13, x23, x13, lsl #2
    13e0:      	ldrb	w7, [x7]
    13e4:      	and	w7, w15, w7
    13e8:      	stp	q3, q22, [sp, #0x3b0]
    13ec:      	ldr	s2, [x13]
    13f0:      	tst	w7, #0x1
    13f4:      	fcsel	s28, s2, s30, ne
    13f8:      	fmov	w13, s16
    13fc:      	add	x7, sp, #0x1e8
    1400:      	bfxil	x7, x13, #0, #3
    1404:      	ldrb	w7, [x7]
    1408:      	and	w7, w3, w7
    140c:      	stp	q3, q22, [sp, #0x390]
    1410:      	add	x23, sp, #0x390
    1414:      	ldr	s2, [x23, w13, uxtw #2]
    1418:      	tst	w7, #0x1
    141c:      	fcsel	s2, s2, s30, ne
    1420:      	mov.s	w13, v16[1]
    1424:      	add	x7, sp, #0x1e8
    1428:      	bfxil	x7, x13, #0, #3
    142c:      	ldrb	w7, [x7]
    1430:      	and	w7, w2, w7
    1434:      	stp	q3, q22, [sp, #0x370]
    1438:      	add	x23, sp, #0x370
    143c:      	ldr	s4, [x23, w13, uxtw #2]
    1440:      	tst	w7, #0x1
    1444:      	fcsel	s4, s4, s30, ne
    1448:      	mov.s	w13, v16[2]
    144c:      	add	x7, sp, #0x1e8
    1450:      	bfxil	x7, x13, #0, #3
    1454:      	ldrb	w7, [x7]
    1458:      	and	w7, w0, w7
    145c:      	stp	q3, q22, [sp, #0x350]
    1460:      	add	x23, sp, #0x350
    1464:      	ldr	s29, [x23, w13, uxtw #2]
    1468:      	tst	w7, #0x1
    146c:      	fcsel	s29, s29, s30, ne
    1470:      	mov.s	w13, v16[3]
    1474:      	add	x7, sp, #0x1e8
    1478:      	bfxil	x7, x13, #0, #3
    147c:      	ldrb	w7, [x7]
    1480:      	and	w7, w1, w7
    1484:      	stp	q3, q22, [sp, #0x330]
    1488:      	add	x23, sp, #0x330
    148c:      	ldr	s16, [x23, w13, uxtw #2]
    1490:      	tst	w7, #0x1
    1494:      	fcsel	s16, s16, s30, ne
    1498:      	mov.s	v2[1], v4[0]
    149c:      	mov.s	v2[2], v29[0]
    14a0:      	mov.s	v2[3], v16[0]
    14a4:      	mov.s	v17[1], v24[0]
    14a8:      	and.16b	v4, v1, v7
    14ac:      	mov.s	v17[2], v27[0]
    14b0:      	mov.s	v17[3], v28[0]
    14b4:      	fadd.4s	v3, v3, v17
    14b8:      	fadd.4s	v7, v22, v2
    14bc:      	fmov	w13, s4
    14c0:      	add	x7, sp, #0x1e8
    14c4:      	bfxil	x7, x13, #0, #3
    14c8:      	ldrb	w7, [x7]
    14cc:      	add	x23, sp, #0x310
    14d0:      	orr	x13, x23, x13, lsl #2
    14d4:      	stp	q3, q7, [sp, #0x310]
    14d8:      	ldr	s2, [x13]
    14dc:      	tst	w5, w7
    14e0:      	mov.s	w13, v4[1]
    14e4:      	add	x7, sp, #0x1e8
    14e8:      	bfxil	x7, x13, #0, #3
    14ec:      	ldrb	w7, [x7]
    14f0:      	and	w16, w16, w7
    14f4:      	fcsel	s16, s2, s30, ne
    14f8:      	add	x7, sp, #0x2f0
    14fc:      	orr	x13, x7, x13, lsl #2
    1500:      	stp	q3, q7, [sp, #0x2f0]
    1504:      	ldr	s2, [x13]
    1508:      	tst	w16, #0x1
    150c:      	mov.s	w13, v4[2]
    1510:      	add	x16, sp, #0x1e8
    1514:      	bfxil	x16, x13, #0, #3
    1518:      	fcsel	s17, s2, s30, ne
    151c:      	ldrb	w13, [x16]
    1520:      	and	w13, w14, w13
    1524:      	str	q3, [sp, #0x2d0]
    1528:      	tst	w13, #0x1
    152c:      	mov.s	w13, v4[3]
    1530:      	add	x14, sp, #0x1e8
    1534:      	bfxil	x14, x13, #0, #3
    1538:      	ldrb	w14, [x14]
    153c:      	and	w14, w15, w14
    1540:      	adrp	x15, 0x1000 <_llm_rows.packet_batch.blocks+0xc18>
    1544:      	ldr	q2, [x15]
    1548:      	and.16b	v2, v0, v2
    154c:      	ldr	s4, [sp, #0x2d0]
    1550:      	fcsel	s24, s4, s30, ne
    1554:      	add	x15, sp, #0x2b0
    1558:      	orr	x13, x15, x13, lsl #2
    155c:      	stp	q3, q7, [sp, #0x2b0]
    1560:      	ldr	s4, [x13]
    1564:      	tst	w14, #0x1
    1568:      	fmov	w13, s2
    156c:      	add	x14, sp, #0x1e8
    1570:      	bfxil	x14, x13, #0, #3
    1574:      	ldrb	w14, [x14]
    1578:      	and	w14, w3, w14
    157c:      	fcsel	s22, s4, s30, ne
    1580:      	stp	q3, q7, [sp, #0x290]
    1584:      	add	x15, sp, #0x290
    1588:      	ldr	s4, [x15, w13, uxtw #2]
    158c:      	tst	w14, #0x1
    1590:      	mov.s	w13, v2[1]
    1594:      	add	x14, sp, #0x1e8
    1598:      	bfxil	x14, x13, #0, #3
    159c:      	ldrb	w14, [x14]
    15a0:      	and	w14, w2, w14
    15a4:      	fcsel	s4, s4, s30, ne
    15a8:      	stp	q3, q7, [sp, #0x270]
    15ac:      	add	x15, sp, #0x270
    15b0:      	ldr	s27, [x15, w13, uxtw #2]
    15b4:      	tst	w14, #0x1
    15b8:      	mov.s	w13, v2[2]
    15bc:      	add	x14, sp, #0x1e8
    15c0:      	bfxil	x14, x13, #0, #3
    15c4:      	ldrb	w14, [x14]
    15c8:      	and	w14, w0, w14
    15cc:      	fcsel	s27, s27, s30, ne
    15d0:      	stp	q3, q7, [sp, #0x250]
    15d4:      	add	x15, sp, #0x250
    15d8:      	ldr	s28, [x15, w13, uxtw #2]
    15dc:      	tst	w14, #0x1
    15e0:      	mov.s	w13, v2[3]
    15e4:      	add	x14, sp, #0x1e8
    15e8:      	bfxil	x14, x13, #0, #3
    15ec:      	ldrb	w14, [x14]
    15f0:      	and	w14, w1, w14
    15f4:      	fcsel	s2, s28, s30, ne
    15f8:      	stp	q3, q7, [sp, #0x230]
    15fc:      	add	x15, sp, #0x230
    1600:      	ldr	s28, [x15, w13, uxtw #2]
    1604:      	tst	w14, #0x1
    1608:      	fcsel	s28, s28, s30, ne
    160c:      	mov.s	v4[1], v27[0]
    1610:      	mov.s	v4[2], v2[0]
    1614:      	mov.s	v4[3], v28[0]
    1618:      	mov.s	v16[1], v17[0]
    161c:      	movi.4s	v2, #0x4
    1620:      	and.16b	v2, v1, v2
    1624:      	mov.s	v16[2], v24[0]
    1628:      	fmov	w13, s2
    162c:      	add	x14, sp, #0x1e8
    1630:      	orr	x14, x14, x13
    1634:      	ldrb	w14, [x14]
    1638:      	tst	w5, w14
    163c:      	mov.s	v16[3], v22[0]
    1640:      	fadd.4s	v2, v3, v16
    1644:      	fadd.4s	v3, v7, v4
    1648:      	stp	q2, q3, [sp, #0x210]
    164c:      	add	x14, sp, #0x210
    1650:      	ldr	s3, [x14, w13, uxtw #2]
    1654:      	fcsel	s3, s3, s30, ne
    1658:      	tst	w12, #0x1
    165c:      	fadd	s2, s2, s3
    1660:      	fcsel	s3, s2, s30, ne
    1664:      	ldr	w12, [sp, #0xe0]
    1668:      	tst	w12, #0x1
    166c:      	fcsel	s4, s2, s30, ne
    1670:      	ldr	w12, [sp, #0xd0]
    1674:      	tst	w12, #0x1
    1678:      	fcsel	s7, s2, s30, ne
    167c:      	ldr	w12, [sp, #0xc0]
    1680:      	tst	w12, #0x1
    1684:      	fcsel	s16, s2, s30, ne
    1688:      	tst	w17, #0x1
    168c:      	fcsel	s17, s2, s30, ne
    1690:      	ldr	w12, [sp, #0xb0]
    1694:      	tst	w12, #0x1
    1698:      	fcsel	s22, s2, s30, ne
    169c:      	tst	w8, #0x1
    16a0:      	fcsel	s24, s2, s30, ne
    16a4:      	tst	w4, #0x1
    16a8:      	mov.s	v3[1], v4[0]
    16ac:      	mov.s	v3[2], v7[0]
    16b0:      	mov.s	v3[3], v16[0]
    16b4:      	mov.s	v17[1], v22[0]
    16b8:      	mov.s	v17[2], v24[0]
    16bc:      	movi	d4, #0000000000000000
    16c0:      	fcsel	s2, s2, s30, ne
    16c4:      	mov.s	v17[3], v2[0]
    16c8:      	stp	q3, q17, [sp, #0x1f0]
    16cc:      	ldr	x8, [sp, #0xa8]
    16d0:      	and	x8, x8, #0x7
    16d4:      	add	x12, sp, #0x1f0
    16d8:      	ldr	s16, [x12, x8, lsl #2]
    16dc:      	add	x8, x10, x6
    16e0:      	fmov	w10, s5
    16e4:      	movi.2d	v7, #0000000000000000
    16e8:      	movi.2d	v3, #0000000000000000
    16ec:      	tbnz	w10, #0x0, 0x19a4 <_llm_rows.packet_batch.blocks+0x15bc>
    16f0:      	ldr	w13, [sp, #0x158]
    16f4:      	ldr	x14, [sp, #0x150]
    16f8:      	tbnz	w10, #0x1, 0x19b4 <_llm_rows.packet_batch.blocks+0x15cc>
    16fc:      	tbnz	w10, #0x2, 0x19c0 <_llm_rows.packet_batch.blocks+0x15d8>
    1700:      	tbnz	w10, #0x3, 0x19cc <_llm_rows.packet_batch.blocks+0x15e4>
    1704:      	tbnz	w10, #0x4, 0x19d8 <_llm_rows.packet_batch.blocks+0x15f0>
    1708:      	tbnz	w10, #0x5, 0x19e4 <_llm_rows.packet_batch.blocks+0x15fc>
    170c:      	tbnz	w10, #0x6, 0x19f0 <_llm_rows.packet_batch.blocks+0x1608>
    1710:      	tbz	w10, #0x7, 0x171c <_llm_rows.packet_batch.blocks+0x1334>
    1714:      	add	x8, x8, #0x1c
    1718:      	ld1.s	{ v3 }[3], [x8]
    171c:      	mov	x10, #0x0               ; =0
    1720:      	fadd	s2, s16, s4
    1724:      	mov	w8, #0x4000             ; =16384
    1728:      	movk	w8, #0x44c0, lsl #16
    172c:      	fmov	s4, w8
    1730:      	fdiv	s2, s2, s4
    1734:      	mov	w8, #0xc5ac             ; =50604
    1738:      	movk	w8, #0x3727, lsl #16
    173c:      	fmov	s4, w8
    1740:      	fadd	s2, s2, s4
    1744:      	fsqrt	s2, s2
    1748:      	add	x8, x27, x11
    174c:      	ldp	q4, q16, [x8]
    1750:      	zip2.8b	v17, v11, v0
    1754:      	ushll.4s	v17, v17, #0x0
    1758:      	shl.4s	v17, v17, #0x1f
    175c:      	cmlt.4s	v17, v17, #0
    1760:      	bit.16b	v16, v3, v17
    1764:      	zip1.8b	v17, v11, v0
    1768:      	ushll.4s	v17, v17, #0x0
    176c:      	shl.4s	v17, v17, #0x1f
    1770:      	cmlt.4s	v17, v17, #0
    1774:      	bit.16b	v4, v7, v17
    1778:      	stp	q4, q16, [x8]
    177c:      	dup.4s	v4, v2[0]
    1780:      	ldr	q2, [sp, #0xf0]
    1784:      	fmov	x8, d2
    1788:      	add	x8, x14, x8, lsl #2
    178c:      	movi.2d	v16, #0000000000000000
    1790:      	movi.2d	v17, #0000000000000000
    1794:      	movi.2d	v22, #0000000000000000
    1798:      	movi.2d	v24, #0000000000000000
    179c:      	b	0x17bc <_llm_rows.packet_batch.blocks+0x13d4>
    17a0:      	add.2d	v17, v17, v19
    17a4:      	add.2d	v22, v22, v20
    17a8:      	add.2d	v24, v24, v18
    17ac:      	add.2d	v16, v16, v21
    17b0:      	fmov	x10, d16
    17b4:      	cmp	x10, #0xc0
    17b8:      	b.ge	0x1894 <_llm_rows.packet_batch.blocks+0x14ac>
    17bc:      	fmov	w11, s10
    17c0:      	lsl	x10, x10, #5
    17c4:      	add	x12, x19, x10
    17c8:      	ldp	q2, q27, [x12]
    17cc:      	and.16b	v2, v1, v2
    17d0:      	fdiv.4s	v2, v2, v4
    17d4:      	add	x12, x21, x10
    17d8:      	ldp	q29, q28, [x12]
    17dc:      	and.16b	v29, v1, v29
    17e0:      	fmul.4s	v2, v2, v29
    17e4:      	add	x12, x27, x10
    17e8:      	ldp	q30, q29, [x12]
    17ec:      	and.16b	v30, v1, v30
    17f0:      	fadd.4s	v30, v2, v30
    17f4:      	add	x10, x8, x10
    17f8:      	tbnz	w11, #0x0, 0x1840 <_llm_rows.packet_batch.blocks+0x1458>
    17fc:      	and	w11, w11, #0xff
    1800:      	tbnz	w11, #0x1, 0x184c <_llm_rows.packet_batch.blocks+0x1464>
    1804:      	tbnz	w11, #0x2, 0x1858 <_llm_rows.packet_batch.blocks+0x1470>
    1808:      	tbz	w11, #0x3, 0x1814 <_llm_rows.packet_batch.blocks+0x142c>
    180c:      	add	x12, x10, #0xc
    1810:      	st1.s	{ v30 }[3], [x12]
    1814:      	and.16b	v2, v0, v27
    1818:      	fdiv.4s	v2, v2, v4
    181c:      	and.16b	v27, v0, v28
    1820:      	fmul.4s	v2, v2, v27
    1824:      	and.16b	v27, v0, v29
    1828:      	fadd.4s	v27, v2, v27
    182c:      	tbnz	w11, #0x4, 0x1868 <_llm_rows.packet_batch.blocks+0x1480>
    1830:      	tbnz	w11, #0x5, 0x1870 <_llm_rows.packet_batch.blocks+0x1488>
    1834:      	tbnz	w11, #0x6, 0x187c <_llm_rows.packet_batch.blocks+0x1494>
    1838:      	tbz	w11, #0x7, 0x17a0 <_llm_rows.packet_batch.blocks+0x13b8>
    183c:      	b	0x1888 <_llm_rows.packet_batch.blocks+0x14a0>
    1840:      	str	s30, [x10]
    1844:      	and	w11, w11, #0xff
    1848:      	tbz	w11, #0x1, 0x1804 <_llm_rows.packet_batch.blocks+0x141c>
    184c:      	add	x12, x10, #0x4
    1850:      	st1.s	{ v30 }[1], [x12]
    1854:      	tbz	w11, #0x2, 0x1808 <_llm_rows.packet_batch.blocks+0x1420>
    1858:      	add	x12, x10, #0x8
    185c:      	st1.s	{ v30 }[2], [x12]
    1860:      	tbnz	w11, #0x3, 0x180c <_llm_rows.packet_batch.blocks+0x1424>
    1864:      	b	0x1814 <_llm_rows.packet_batch.blocks+0x142c>
    1868:      	str	s27, [x10, #0x10]
    186c:      	tbz	w11, #0x5, 0x1834 <_llm_rows.packet_batch.blocks+0x144c>
    1870:      	add	x12, x10, #0x14
    1874:      	st1.s	{ v27 }[1], [x12]
    1878:      	tbz	w11, #0x6, 0x1838 <_llm_rows.packet_batch.blocks+0x1450>
    187c:      	add	x12, x10, #0x18
    1880:      	st1.s	{ v27 }[2], [x12]
    1884:      	tbz	w11, #0x7, 0x17a0 <_llm_rows.packet_batch.blocks+0x13b8>
    1888:      	add	x10, x10, #0x1c
    188c:      	st1.s	{ v27 }[3], [x10]
    1890:      	b	0x17a0 <_llm_rows.packet_batch.blocks+0x13b8>
    1894:      	fdiv.4s	v0, v6, v4
    1898:      	fmul.4s	v0, v0, v25
    189c:      	fadd.4s	v0, v0, v7
    18a0:      	ldp	q1, q2, [sp, #0x120]
    18a4:      	ldp	q7, q6, [sp, #0x100]
    18a8:      	stp	q2, q6, [sp, #0x1a0]
    18ac:      	stp	q7, q1, [sp, #0x1c0]
    18b0:      	and	x8, x9, #0x7
    18b4:      	add	x10, sp, #0x1a0
    18b8:      	ldr	x8, [x10, x8, lsl #3]
    18bc:      	sub	x8, x8, x9
    18c0:      	add	x8, x14, x8, lsl #2
    18c4:      	fmov	w9, s5
    18c8:      	tbnz	w9, #0x0, 0x1a00 <_llm_rows.packet_batch.blocks+0x1618>
    18cc:      	tbnz	w9, #0x1, 0x1a08 <_llm_rows.packet_batch.blocks+0x1620>
    18d0:      	tbnz	w9, #0x2, 0x1a14 <_llm_rows.packet_batch.blocks+0x162c>
    18d4:      	tbnz	w9, #0x3, 0x1a20 <_llm_rows.packet_batch.blocks+0x1638>
    18d8:      	fdiv.4s	v0, v26, v4
    18dc:      	fmul.4s	v0, v0, v23
    18e0:      	fadd.4s	v0, v0, v3
    18e4:      	tbnz	w9, #0x4, 0x1a38 <_llm_rows.packet_batch.blocks+0x1650>
    18e8:      	tbnz	w9, #0x5, 0x1a40 <_llm_rows.packet_batch.blocks+0x1658>
    18ec:      	tbnz	w9, #0x6, 0x1a4c <_llm_rows.packet_batch.blocks+0x1664>
    18f0:      	tbz	w9, #0x7, 0x484 <_llm_rows.packet_batch.blocks+0x9c>
    18f4:      	b	0x1a58 <_llm_rows.packet_batch.blocks+0x1670>
    18f8:      	ldr	s27, [x8]
    18fc:      	tbz	w11, #0x1, 0x7d8 <_llm_rows.packet_batch.blocks+0x3f0>
    1900:      	add	x12, x8, #0x4
    1904:      	ld1.s	{ v27 }[1], [x12]
    1908:      	tbz	w11, #0x2, 0x7dc <_llm_rows.packet_batch.blocks+0x3f4>
    190c:      	add	x12, x8, #0x8
    1910:      	ld1.s	{ v27 }[2], [x12]
    1914:      	tbz	w11, #0x3, 0x7e0 <_llm_rows.packet_batch.blocks+0x3f8>
    1918:      	add	x12, x8, #0xc
    191c:      	ld1.s	{ v27 }[3], [x12]
    1920:      	tbz	w11, #0x4, 0x7e4 <_llm_rows.packet_batch.blocks+0x3fc>
    1924:      	add	x12, x8, #0x10
    1928:      	ld1.s	{ v31 }[0], [x12]
    192c:      	tbz	w11, #0x5, 0x7e8 <_llm_rows.packet_batch.blocks+0x400>
    1930:      	add	x12, x8, #0x14
    1934:      	ld1.s	{ v31 }[1], [x12]
    1938:      	tbz	w11, #0x6, 0x7ec <_llm_rows.packet_batch.blocks+0x404>
    193c:      	add	x12, x8, #0x18
    1940:      	ld1.s	{ v31 }[2], [x12]
    1944:      	str	q21, [sp, #0x140]
    1948:      	tbnz	w11, #0x7, 0x7f4 <_llm_rows.packet_batch.blocks+0x40c>
    194c:      	b	0x7fc <_llm_rows.packet_batch.blocks+0x414>
    1950:      	ldr	s25, [x13]
    1954:      	tbz	w7, #0x1, 0x1164 <_llm_rows.packet_batch.blocks+0xd7c>
    1958:      	add	x23, x13, #0x4
    195c:      	ld1.s	{ v25 }[1], [x23]
    1960:      	tbz	w7, #0x2, 0x1168 <_llm_rows.packet_batch.blocks+0xd80>
    1964:      	add	x23, x13, #0x8
    1968:      	ld1.s	{ v25 }[2], [x23]
    196c:      	tbz	w7, #0x3, 0x116c <_llm_rows.packet_batch.blocks+0xd84>
    1970:      	add	x23, x13, #0xc
    1974:      	ld1.s	{ v25 }[3], [x23]
    1978:      	tbz	w7, #0x4, 0x1170 <_llm_rows.packet_batch.blocks+0xd88>
    197c:      	add	x23, x13, #0x10
    1980:      	ld1.s	{ v23 }[0], [x23]
    1984:      	tbz	w7, #0x5, 0x1174 <_llm_rows.packet_batch.blocks+0xd8c>
    1988:      	add	x23, x13, #0x14
    198c:      	ld1.s	{ v23 }[1], [x23]
    1990:      	tbz	w7, #0x6, 0x1178 <_llm_rows.packet_batch.blocks+0xd90>
    1994:      	add	x23, x13, #0x18
    1998:      	ld1.s	{ v23 }[2], [x23]
    199c:      	tbnz	w7, #0x7, 0x117c <_llm_rows.packet_batch.blocks+0xd94>
    19a0:      	b	0x1184 <_llm_rows.packet_batch.blocks+0xd9c>
    19a4:      	ldr	s7, [x8]
    19a8:      	ldr	w13, [sp, #0x158]
    19ac:      	ldr	x14, [sp, #0x150]
    19b0:      	tbz	w10, #0x1, 0x16fc <_llm_rows.packet_batch.blocks+0x1314>
    19b4:      	add	x12, x8, #0x4
    19b8:      	ld1.s	{ v7 }[1], [x12]
    19bc:      	tbz	w10, #0x2, 0x1700 <_llm_rows.packet_batch.blocks+0x1318>
    19c0:      	add	x12, x8, #0x8
    19c4:      	ld1.s	{ v7 }[2], [x12]
    19c8:      	tbz	w10, #0x3, 0x1704 <_llm_rows.packet_batch.blocks+0x131c>
    19cc:      	add	x12, x8, #0xc
    19d0:      	ld1.s	{ v7 }[3], [x12]
    19d4:      	tbz	w10, #0x4, 0x1708 <_llm_rows.packet_batch.blocks+0x1320>
    19d8:      	add	x12, x8, #0x10
    19dc:      	ld1.s	{ v3 }[0], [x12]
    19e0:      	tbz	w10, #0x5, 0x170c <_llm_rows.packet_batch.blocks+0x1324>
    19e4:      	add	x12, x8, #0x14
    19e8:      	ld1.s	{ v3 }[1], [x12]
    19ec:      	tbz	w10, #0x6, 0x1710 <_llm_rows.packet_batch.blocks+0x1328>
    19f0:      	add	x12, x8, #0x18
    19f4:      	ld1.s	{ v3 }[2], [x12]
    19f8:      	tbnz	w10, #0x7, 0x1714 <_llm_rows.packet_batch.blocks+0x132c>
    19fc:      	b	0x171c <_llm_rows.packet_batch.blocks+0x1334>
    1a00:      	str	s0, [x8]
    1a04:      	tbz	w9, #0x1, 0x18d0 <_llm_rows.packet_batch.blocks+0x14e8>
    1a08:      	add	x10, x8, #0x4
    1a0c:      	st1.s	{ v0 }[1], [x10]
    1a10:      	tbz	w9, #0x2, 0x18d4 <_llm_rows.packet_batch.blocks+0x14ec>
    1a14:      	add	x10, x8, #0x8
    1a18:      	st1.s	{ v0 }[2], [x10]
    1a1c:      	tbz	w9, #0x3, 0x18d8 <_llm_rows.packet_batch.blocks+0x14f0>
    1a20:      	add	x10, x8, #0xc
    1a24:      	st1.s	{ v0 }[3], [x10]
    1a28:      	fdiv.4s	v0, v26, v4
    1a2c:      	fmul.4s	v0, v0, v23
    1a30:      	fadd.4s	v0, v0, v3
    1a34:      	tbz	w9, #0x4, 0x18e8 <_llm_rows.packet_batch.blocks+0x1500>
    1a38:      	str	s0, [x8, #0x10]
    1a3c:      	tbz	w9, #0x5, 0x18ec <_llm_rows.packet_batch.blocks+0x1504>
    1a40:      	add	x10, x8, #0x14
    1a44:      	st1.s	{ v0 }[1], [x10]
    1a48:      	tbz	w9, #0x6, 0x18f0 <_llm_rows.packet_batch.blocks+0x1508>
    1a4c:      	add	x10, x8, #0x18
    1a50:      	st1.s	{ v0 }[2], [x10]
    1a54:      	tbz	w9, #0x7, 0x484 <_llm_rows.packet_batch.blocks+0x9c>
    1a58:      	add	x8, x8, #0x1c
    1a5c:      	st1.s	{ v0 }[3], [x8]
    1a60:      	b	0x484 <_llm_rows.packet_batch.blocks+0x9c>
    1a64:      	add	sp, sp, #0x6, lsl #12   ; =0x6000
    1a68:      	add	sp, sp, #0x700
    1a6c:      	ldp	x29, x30, [sp, #0x90]
    1a70:      	ldp	x20, x19, [sp, #0x80]
    1a74:      	ldp	x22, x21, [sp, #0x70]
    1a78:      	ldp	x24, x23, [sp, #0x60]
    1a7c:      	ldp	x26, x25, [sp, #0x50]
    1a80:      	ldp	x28, x27, [sp, #0x40]
    1a84:      	ldp	d9, d8, [sp, #0x30]
    1a88:      	ldp	d11, d10, [sp, #0x20]
    1a8c:      	ldp	d13, d12, [sp, #0x10]
    1a90:      	ldp	d15, d14, [sp], #0xa0
    1a94:      	ret


/private/tmp/luisa-expression-fusion.qXgTbC/capture/layernorm-257x1538/on/object/tile_xir_w8_23355_1788930262899224_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	x28, x27, [sp, #-0x60]!
       4:      	stp	x26, x25, [sp, #0x10]
       8:      	stp	x24, x23, [sp, #0x20]
       c:      	stp	x22, x21, [sp, #0x30]
      10:      	stp	x20, x19, [sp, #0x40]
      14:      	stp	x29, x30, [sp, #0x50]
      18:      	sub	sp, sp, #0x6, lsl #12   ; =0x6000
      1c:      	sub	sp, sp, #0x130
      20:      	ldr	x24, [x0]
      24:      	ldr	x20, [x0, #0x10]
      28:      	ldr	x19, [x0, #0x20]
      2c:      	ldr	x21, [x0, #0x30]
      30:      	ldr	w8, [x1]
      34:      	ldr	w9, [x1, #0x24]
      38:      	add	w8, w9, w8, lsl #5
      3c:      	lsr	w8, w8, #3
      40:      	fmov	s0, w8
      44:      	ushll.2d	v0, v0, #0x0
      48:      	fmov	x22, d0
      4c:      	mov	w25, #0x1808            ; =6152
      50:      	umull	x23, w22, w25
      54:      	umaddl	x1, w22, w25, x24
      58:      	mov	w26, #0x1800            ; =6144
      5c:      	add	x27, sp, #0x4, lsl #12  ; =0x4000
      60:      	add	x27, x27, #0x910
      64:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
      68:      	add	x0, x0, #0x910
      6c:      	mov	w2, #0x1800             ; =6144
      70:      	bl	0x70 <ltmp0+0x70>
      74:      	umaddl	x22, w22, w25, x26
      78:      	add	x8, x24, x22
      7c:      	add	x9, x8, #0x4
      80:      	ldr	s0, [x8]
      84:      	ld1.s	{ v0 }[1], [x9]
      88:      	str	q0, [sp, #0x6110]
      8c:      	ldr	q6, [sp, #0x4920]
      90:      	ldr	q7, [sp, #0x4910]
      94:      	ldr	q4, [sp, #0x4960]
      98:      	ldr	q5, [sp, #0x4950]
      9c:      	ldr	q2, [sp, #0x4980]
      a0:      	ldr	q3, [sp, #0x4970]
      a4:      	add	x8, x27, #0xe0
      a8:      	mov	w9, #0x4                ; =4
      ac:      	mov.16b	v1, v3
      b0:      	mov.16b	v18, v2
      b4:      	mov.16b	v19, v5
      b8:      	mov.16b	v20, v4
      bc:      	ldr	q16, [sp, #0x4940]
      c0:      	ldr	q17, [sp, #0x4930]
      c4:      	mov.16b	v21, v17
      c8:      	mov.16b	v22, v16
      cc:      	mov.16b	v23, v7
      d0:      	mov.16b	v24, v6
      d4:      	ldp	q25, q26, [x8, #-0x60]
      d8:      	fadd.4s	v24, v24, v26
      dc:      	fadd.4s	v23, v23, v25
      e0:      	ldp	q25, q26, [x8, #-0x40]
      e4:      	fadd.4s	v22, v22, v26
      e8:      	fadd.4s	v21, v21, v25
      ec:      	ldp	q25, q26, [x8, #-0x20]
      f0:      	fadd.4s	v20, v20, v26
      f4:      	fadd.4s	v19, v19, v25
      f8:      	ldp	q25, q26, [x8], #0x80
      fc:      	fadd.4s	v18, v18, v26
     100:      	fadd.4s	v1, v1, v25
     104:      	cmp	x9, #0xbc
     108:      	add	x9, x9, #0x4
     10c:      	b.lo	0xd4 <ltmp0+0xd4>
     110:      	mov	x8, #0x0                ; =0
     114:      	fadd.4s	v25, v0, v23
     118:      	mov.d	v25[1], v23[1]
     11c:      	fadd.4s	v22, v22, v24
     120:      	fadd.4s	v21, v21, v25
     124:      	fadd.4s	v19, v19, v21
     128:      	fadd.4s	v20, v20, v22
     12c:      	fadd.4s	v18, v18, v20
     130:      	fadd.4s	v1, v1, v19
     134:      	rev64.4s	v19, v1
     138:      	rev64.4s	v20, v18
     13c:      	fadd.4s	v18, v18, v20
     140:      	fadd.4s	v1, v1, v19
     144:      	dup.4s	v19, v1[2]
     148:      	dup.4s	v20, v18[2]
     14c:      	fadd.4s	v18, v18, v20
     150:      	fadd.4s	v1, v1, v19
     154:      	fadd.4s	v1, v1, v18
     158:      	movi	d18, #0000000000000000
     15c:      	fadd	s1, s1, s18
     160:      	mov	w9, #0x4000             ; =16384
     164:      	movk	w9, #0x44c0, lsl #16
     168:      	fmov	s18, w9
     16c:      	fdiv	s1, s1, s18
     170:      	dup.4s	v1, v1[0]
     174:      	fsub.4s	v7, v7, v1
     178:      	fsub.4s	v6, v6, v1
     17c:      	str	q6, [sp, #0x3100]
     180:      	str	q7, [sp, #0x30f0]
     184:      	fmul.4s	v18, v6, v6
     188:      	fmul.4s	v19, v7, v7
     18c:      	fsub.4s	v6, v17, v1
     190:      	fsub.4s	v7, v16, v1
     194:      	str	q7, [sp, #0x3120]
     198:      	str	q6, [sp, #0x3110]
     19c:      	fmul.4s	v7, v7, v7
     1a0:      	fmul.4s	v6, v6, v6
     1a4:      	fsub.4s	v5, v5, v1
     1a8:      	fsub.4s	v4, v4, v1
     1ac:      	str	q4, [sp, #0x3140]
     1b0:      	str	q5, [sp, #0x3130]
     1b4:      	fmul.4s	v4, v4, v4
     1b8:      	fmul.4s	v5, v5, v5
     1bc:      	fsub.4s	v3, v3, v1
     1c0:      	fsub.4s	v2, v2, v1
     1c4:      	str	q2, [sp, #0x3160]
     1c8:      	str	q3, [sp, #0x3150]
     1cc:      	fmul.4s	v17, v2, v2
     1d0:      	fmul.4s	v16, v3, v3
     1d4:      	add	x9, sp, #0x4, lsl #12   ; =0x4000
     1d8:      	add	x9, x9, #0x910
     1dc:      	add	x9, x9, #0xe0
     1e0:      	add	x10, sp, #0x3, lsl #12  ; =0x3000
     1e4:      	add	x10, x10, #0xf0
     1e8:      	add	x10, x10, #0xe0
     1ec:      	ldp	q3, q2, [x9, #-0x60]
     1f0:      	fsub.4s	v3, v3, v1
     1f4:      	fsub.4s	v2, v2, v1
     1f8:      	stp	q3, q2, [x10, #-0x60]
     1fc:      	fmul.4s	v3, v3, v3
     200:      	fmul.4s	v2, v2, v2
     204:      	fadd.4s	v18, v18, v2
     208:      	fadd.4s	v19, v19, v3
     20c:      	ldp	q3, q2, [x9, #-0x40]
     210:      	fsub.4s	v3, v3, v1
     214:      	fsub.4s	v2, v2, v1
     218:      	stp	q3, q2, [x10, #-0x40]
     21c:      	fmul.4s	v3, v3, v3
     220:      	fmul.4s	v2, v2, v2
     224:      	fadd.4s	v7, v7, v2
     228:      	fadd.4s	v6, v6, v3
     22c:      	ldp	q3, q2, [x9, #-0x20]
     230:      	fsub.4s	v3, v3, v1
     234:      	fsub.4s	v2, v2, v1
     238:      	stp	q3, q2, [x10, #-0x20]
     23c:      	fmul.4s	v3, v3, v3
     240:      	fmul.4s	v2, v2, v2
     244:      	fadd.4s	v4, v4, v2
     248:      	fadd.4s	v5, v5, v3
     24c:      	ldp	q3, q2, [x9], #0x80
     250:      	fsub.4s	v3, v3, v1
     254:      	fsub.4s	v2, v2, v1
     258:      	stp	q3, q2, [x10], #0x80
     25c:      	fmul.4s	v3, v3, v3
     260:      	fmul.4s	v2, v2, v2
     264:      	fadd.4s	v17, v17, v2
     268:      	fadd.4s	v16, v16, v3
     26c:      	add	x8, x8, #0x4
     270:      	cmp	x8, #0xbc
     274:      	b.lo	0x1ec <ltmp0+0x1ec>
     278:      	movi.2d	v2, #0000000000000000
     27c:      	mov.d	v2[0], v0[0]
     280:      	fsub.4s	v1, v2, v1
     284:      	stp	q16, q1, [sp, #0x70]
     288:      	ldr	q0, [sp, #0x48f0]
     28c:      	mov.d	v1[1], v0[1]
     290:      	str	q1, [sp, #0xa0]
     294:      	str	q1, [sp, #0x48f0]
     298:      	add	x24, sp, #0x1, lsl #12  ; =0x1000
     29c:      	add	x24, x24, #0x8d0
     2a0:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     2a4:      	add	x0, x0, #0x8d0
     2a8:      	mov	x1, x20
     2ac:      	mov	w2, #0x1800             ; =6144
     2b0:      	stp	q7, q18, [sp, #0x10]
     2b4:      	str	q19, [sp]
     2b8:      	stp	q5, q6, [sp, #0x30]
     2bc:      	stp	q17, q4, [sp, #0x50]
     2c0:      	bl	0x2c0 <ltmp0+0x2c0>
     2c4:      	mov	w25, #0x1804            ; =6148
     2c8:      	add	x8, x20, x25
     2cc:      	ldr	s0, [x20, #0x1800]
     2d0:      	ld1.s	{ v0 }[1], [x8]
     2d4:      	str	q0, [sp, #0x90]
     2d8:      	str	q0, [sp, #0x30d0]
     2dc:      	add	x20, sp, #0xb0
     2e0:      	add	x0, sp, #0xb0
     2e4:      	mov	x1, x19
     2e8:      	mov	w2, #0x1800             ; =6144
     2ec:      	bl	0x2ec <ltmp0+0x2ec>
     2f0:      	mov	x8, #0x0                ; =0
     2f4:      	ldr	q0, [sp, #0x80]
     2f8:      	fmul.4s	v0, v0, v0
     2fc:      	ldp	q1, q2, [sp]
     300:      	fadd.4s	v0, v0, v1
     304:      	mov.d	v0[1], v1[1]
     308:      	ldr	q1, [sp, #0x20]
     30c:      	fadd.4s	v1, v2, v1
     310:      	ldp	q2, q3, [sp, #0x30]
     314:      	fadd.4s	v0, v3, v0
     318:      	fadd.4s	v0, v2, v0
     31c:      	ldp	q2, q3, [sp, #0x50]
     320:      	fadd.4s	v1, v3, v1
     324:      	fadd.4s	v1, v2, v1
     328:      	ldr	q2, [sp, #0x70]
     32c:      	fadd.4s	v0, v2, v0
     330:      	rev64.4s	v2, v0
     334:      	rev64.4s	v3, v1
     338:      	fadd.4s	v0, v0, v2
     33c:      	dup.4s	v2, v0[2]
     340:      	fadd.4s	v1, v1, v3
     344:      	dup.4s	v3, v1[2]
     348:      	mov	w9, #0x4000             ; =16384
     34c:      	movk	w9, #0x44c0, lsl #16
     350:      	fmov	s4, w9
     354:      	mov	w9, #0xc5ac             ; =50604
     358:      	movk	w9, #0x3727, lsl #16
     35c:      	fmov	s5, w9
     360:      	fadd.4s	v1, v1, v3
     364:      	fadd.4s	v0, v0, v2
     368:      	fadd.4s	v0, v0, v1
     36c:      	movi	d1, #0000000000000000
     370:      	fadd	s0, s0, s1
     374:      	fdiv	s0, s0, s4
     378:      	fadd	s1, s0, s5
     37c:      	add	x9, x19, x25
     380:      	ldr	s0, [x19, #0x1800]
     384:      	ld1.s	{ v0 }[1], [x9]
     388:      	fsqrt	s1, s1
     38c:      	str	q0, [sp, #0x18b0]
     390:      	dup.4s	v2, v1[0]
     394:      	add	x9, x21, x23
     398:      	add	x10, sp, #0x3, lsl #12  ; =0x3000
     39c:      	add	x10, x10, #0xf0
     3a0:      	lsl	x11, x8, #5
     3a4:      	add	x12, x10, x11
     3a8:      	ldp	q4, q3, [x12]
     3ac:      	fdiv.4s	v4, v4, v2
     3b0:      	fdiv.4s	v3, v3, v2
     3b4:      	add	x12, x24, x11
     3b8:      	ldp	q5, q6, [x12]
     3bc:      	fmul.4s	v3, v3, v6
     3c0:      	fmul.4s	v4, v4, v5
     3c4:      	add	x12, x20, x11
     3c8:      	ldp	q6, q5, [x12]
     3cc:      	fadd.4s	v4, v4, v6
     3d0:      	fadd.4s	v3, v3, v5
     3d4:      	add	x11, x9, x11
     3d8:      	stp	q4, q3, [x11]
     3dc:      	add	x8, x8, #0x1
     3e0:      	cmp	x8, #0xc0
     3e4:      	b.ne	0x3a0 <ltmp0+0x3a0>
     3e8:      	dup.2s	v1, v1[0]
     3ec:      	ldp	q2, q3, [sp, #0x90]
     3f0:      	fdiv.2s	v1, v3, v1
     3f4:      	fmul.2s	v1, v1, v2
     3f8:      	fadd.2s	v0, v1, v0
     3fc:      	str	d0, [x21, x22]
     400:      	add	sp, sp, #0x6, lsl #12   ; =0x6000
     404:      	add	sp, sp, #0x130
     408:      	ldp	x29, x30, [sp, #0x50]
     40c:      	ldp	x20, x19, [sp, #0x40]
     410:      	ldp	x22, x21, [sp, #0x30]
     414:      	ldp	x24, x23, [sp, #0x20]
     418:      	ldp	x26, x25, [sp, #0x10]
     41c:      	ldp	x28, x27, [sp], #0x60
     420:      	ret

0000000000000424 <_llm_rows.packet_batch.blocks>:
     424:      	stp	d15, d14, [sp, #-0xa0]!
     428:      	stp	d13, d12, [sp, #0x10]
     42c:      	stp	d11, d10, [sp, #0x20]
     430:      	stp	d9, d8, [sp, #0x30]
     434:      	stp	x28, x27, [sp, #0x40]
     438:      	stp	x26, x25, [sp, #0x50]
     43c:      	stp	x24, x23, [sp, #0x60]
     440:      	stp	x22, x21, [sp, #0x70]
     444:      	stp	x20, x19, [sp, #0x80]
     448:      	stp	x29, x30, [sp, #0x90]
     44c:      	sub	sp, sp, #0x6, lsl #12   ; =0x6000
     450:      	sub	sp, sp, #0x700
     454:      	str	x0, [sp, #0x188]
     458:      	cbz	w3, 0x1bc4 <_llm_rows.packet_batch.blocks+0x17a0>
     45c:      	mov	x28, x3
     460:      	mov	x20, x2
     464:      	mov	w22, #0x0               ; =0
     468:      	ldp	w9, w8, [x2, #0x2c]
     46c:      	str	w9, [sp, #0x184]
     470:      	str	w8, [sp, #0x180]
     474:      	add	x25, sp, #0x4, lsl #12  ; =0x4000
     478:      	add	x25, x25, #0xee0
     47c:      	ldp	w24, w13, [x2]
     480:      	adrp	x8, 0x0 <ltmp0>
     484:      	ldr	q0, [x8]
     488:      	str	q0, [sp, #0x10]
     48c:      	adrp	x8, 0x0 <ltmp0>
     490:      	ldr	q0, [x8]
     494:      	str	q0, [sp, #0x30]
     498:      	adrp	x8, 0x0 <ltmp0>
     49c:      	ldr	q0, [x8]
     4a0:      	str	q0, [sp, #0x20]
     4a4:      	ldp	w26, w8, [x2, #0x8]
     4a8:      	str	x8, [sp, #0x178]
     4ac:      	add	x19, sp, #0x3, lsl #12  ; =0x3000
     4b0:      	add	x19, x19, #0x6c0
     4b4:      	add	x27, sp, #0x680
     4b8:      	str	w3, [sp, #0x12c]
     4bc:      	b	0x508 <_llm_rows.packet_batch.blocks+0xe4>
     4c0:      	mov	w8, #0x18               ; =24
     4c4:      	str	w8, [x20, #0x24]
     4c8:      	ldr	w28, [sp, #0x12c]
     4cc:      	add	w8, w24, #0x1
     4d0:      	ldr	w9, [sp, #0x184]
     4d4:      	cmp	w8, w9
     4d8:      	cset	w8, eq
     4dc:      	csinc	w24, wzr, w24, eq
     4e0:      	cinc	w9, w13, eq
     4e4:      	ldr	w10, [sp, #0x180]
     4e8:      	cmp	w9, w10
     4ec:      	cset	w10, eq
     4f0:      	ands	w8, w8, w10
     4f4:      	csel	w13, wzr, w9, ne
     4f8:      	add	w26, w26, w8
     4fc:      	add	w22, w22, #0x1
     500:      	cmp	w22, w28
     504:      	b.eq	0x1bc4 <_llm_rows.packet_batch.blocks+0x17a0>
     508:      	ubfiz	x8, x24, #5, #32
     50c:      	ldr	x12, [sp, #0x178]
     510:      	cmp	x8, x12
     514:      	csel	x9, x8, xzr, ls
     518:      	subs	x10, x12, x9
     51c:      	cmp	x10, #0x20
     520:      	mov	w11, #0x20              ; =32
     524:      	csel	x10, x10, x11, lo
     528:      	cmp	x12, x9
     52c:      	stp	w24, w13, [x20]
     530:      	str	w26, [x20, #0x8]
     534:      	str	wzr, [x20, #0x24]
     538:      	ccmp	x8, x12, #0x2, hi
     53c:      	csel	x23, x10, xzr, ls
     540:      	cmp	x23, #0x20
     544:      	b.lo	0x5a0 <_llm_rows.packet_batch.blocks+0x17c>
     548:      	ldr	x23, [sp, #0x188]
     54c:      	mov	x0, x23
     550:      	mov	x1, x20
     554:      	mov	x21, x13
     558:      	bl	0x558 <_llm_rows.packet_batch.blocks+0x134>
     55c:      	mov	w8, #0x8                ; =8
     560:      	str	w8, [x20, #0x24]
     564:      	mov	x0, x23
     568:      	mov	x1, x20
     56c:      	bl	0x56c <_llm_rows.packet_batch.blocks+0x148>
     570:      	mov	w8, #0x10               ; =16
     574:      	str	w8, [x20, #0x24]
     578:      	mov	x0, x23
     57c:      	mov	x1, x20
     580:      	bl	0x580 <_llm_rows.packet_batch.blocks+0x15c>
     584:      	mov	w8, #0x18               ; =24
     588:      	str	w8, [x20, #0x24]
     58c:      	mov	x0, x23
     590:      	mov	x1, x20
     594:      	bl	0x594 <_llm_rows.packet_batch.blocks+0x170>
     598:      	mov	x13, x21
     59c:      	b	0x4cc <_llm_rows.packet_batch.blocks+0xa8>
     5a0:      	lsr	x28, x23, #3
     5a4:      	cmp	x23, #0x8
     5a8:      	b.lo	0x604 <_llm_rows.packet_batch.blocks+0x1e0>
     5ac:      	str	wzr, [x20, #0x24]
     5b0:      	ldr	x0, [sp, #0x188]
     5b4:      	mov	x1, x20
     5b8:      	mov	x21, x13
     5bc:      	bl	0x5bc <_llm_rows.packet_batch.blocks+0x198>
     5c0:      	mov	x13, x21
     5c4:      	cmp	x28, #0x1
     5c8:      	b.eq	0x604 <_llm_rows.packet_batch.blocks+0x1e0>
     5cc:      	mov	w8, #0x8                ; =8
     5d0:      	str	w8, [x20, #0x24]
     5d4:      	ldr	x0, [sp, #0x188]
     5d8:      	mov	x1, x20
     5dc:      	bl	0x5dc <_llm_rows.packet_batch.blocks+0x1b8>
     5e0:      	mov	x13, x21
     5e4:      	cmp	x28, #0x2
     5e8:      	b.eq	0x604 <_llm_rows.packet_batch.blocks+0x1e0>
     5ec:      	mov	w8, #0x10               ; =16
     5f0:      	str	w8, [x20, #0x24]
     5f4:      	ldr	x0, [sp, #0x188]
     5f8:      	mov	x1, x20
     5fc:      	bl	0x5fc <_llm_rows.packet_batch.blocks+0x1d8>
     600:      	mov	x13, x21
     604:      	and	w8, w23, #0x7
     608:      	cbz	w8, 0x4c0 <_llm_rows.packet_batch.blocks+0x9c>
     60c:      	dup.4s	v1, w8
     610:      	ldp	q0, q2, [sp, #0x20]
     614:      	cmhi.4s	v0, v1, v0
     618:      	cmhi.4s	v1, v1, v2
     61c:      	uzp1.8h	v3, v1, v0
     620:      	umaxv.8h	h2, v3
     624:      	fmov	w8, s2
     628:      	tbz	w8, #0x0, 0x4c0 <_llm_rows.packet_batch.blocks+0x9c>
     62c:      	str	w13, [sp, #0x128]
     630:      	mov	x9, #0x0                ; =0
     634:      	ldr	x11, [sp, #0x188]
     638:      	ldr	x8, [x11]
     63c:      	ldr	x13, [x11, #0x10]
     640:      	ldr	x10, [x11, #0x20]
     644:      	ldr	x11, [x11, #0x30]
     648:      	str	x11, [sp, #0x120]
     64c:      	ldr	q2, [sp, #0x10]
     650:      	and.16b	v2, v3, v2
     654:      	addv.8h	h2, v2
     658:      	fmov	w11, s2
     65c:      	and	w7, w11, #0xff
     660:      	ubfiz	w11, w24, #2, #27
     664:      	orr	w11, w11, w28
     668:      	dup.4s	v4, w11
     66c:      	and.16b	v5, v1, v4
     670:      	and.16b	v4, v0, v4
     674:      	ushll2.2d	v6, v4, #0x0
     678:      	ushll2.2d	v7, v5, #0x0
     67c:      	ushll.2d	v16, v4, #0x0
     680:      	ushll.2d	v4, v5, #0x0
     684:      	fmov	x11, d4
     688:      	mov	w12, #0x1808            ; =6152
     68c:      	umaddl	x11, w11, w12, x8
     690:      	str	q2, [sp, #0x190]
     694:      	fmov	w12, s2
     698:      	mov	w21, #0x4               ; =4
     69c:      	b	0x6c0 <_llm_rows.packet_batch.blocks+0x29c>
     6a0:      	add	x14, x25, x9, lsl #5
     6a4:      	ldp	q18, q19, [x14]
     6a8:      	bif.16b	v17, v19, v0
     6ac:      	bif.16b	v5, v18, v1
     6b0:      	stp	q5, q17, [x14]
     6b4:      	add	x9, x9, #0x1
     6b8:      	cmp	x9, #0xc0
     6bc:      	b.eq	0x754 <_llm_rows.packet_batch.blocks+0x330>
     6c0:      	add	x14, x11, x9, lsl #5
     6c4:      	movi.2d	v5, #0000000000000000
     6c8:      	movi.2d	v17, #0000000000000000
     6cc:      	tbnz	w12, #0x0, 0x6f4 <_llm_rows.packet_batch.blocks+0x2d0>
     6d0:      	and	w15, w12, #0xff
     6d4:      	tbnz	w15, #0x1, 0x700 <_llm_rows.packet_batch.blocks+0x2dc>
     6d8:      	tbnz	w15, #0x2, 0x70c <_llm_rows.packet_batch.blocks+0x2e8>
     6dc:      	tbnz	w15, #0x3, 0x718 <_llm_rows.packet_batch.blocks+0x2f4>
     6e0:      	tbnz	w15, #0x4, 0x724 <_llm_rows.packet_batch.blocks+0x300>
     6e4:      	tbnz	w15, #0x5, 0x730 <_llm_rows.packet_batch.blocks+0x30c>
     6e8:      	tbnz	w15, #0x6, 0x73c <_llm_rows.packet_batch.blocks+0x318>
     6ec:      	tbz	w15, #0x7, 0x6a0 <_llm_rows.packet_batch.blocks+0x27c>
     6f0:      	b	0x748 <_llm_rows.packet_batch.blocks+0x324>
     6f4:      	ldr	s5, [x14]
     6f8:      	and	w15, w12, #0xff
     6fc:      	tbz	w15, #0x1, 0x6d8 <_llm_rows.packet_batch.blocks+0x2b4>
     700:      	add	x16, x14, #0x4
     704:      	ld1.s	{ v5 }[1], [x16]
     708:      	tbz	w15, #0x2, 0x6dc <_llm_rows.packet_batch.blocks+0x2b8>
     70c:      	add	x16, x14, #0x8
     710:      	ld1.s	{ v5 }[2], [x16]
     714:      	tbz	w15, #0x3, 0x6e0 <_llm_rows.packet_batch.blocks+0x2bc>
     718:      	add	x16, x14, #0xc
     71c:      	ld1.s	{ v5 }[3], [x16]
     720:      	tbz	w15, #0x4, 0x6e4 <_llm_rows.packet_batch.blocks+0x2c0>
     724:      	add	x16, x14, #0x10
     728:      	ld1.s	{ v17 }[0], [x16]
     72c:      	tbz	w15, #0x5, 0x6e8 <_llm_rows.packet_batch.blocks+0x2c4>
     730:      	add	x16, x14, #0x14
     734:      	ld1.s	{ v17 }[1], [x16]
     738:      	tbz	w15, #0x6, 0x6ec <_llm_rows.packet_batch.blocks+0x2c8>
     73c:      	add	x16, x14, #0x18
     740:      	ld1.s	{ v17 }[2], [x16]
     744:      	tbz	w15, #0x7, 0x6a0 <_llm_rows.packet_batch.blocks+0x27c>
     748:      	add	x14, x14, #0x1c
     74c:      	ld1.s	{ v17 }[3], [x14]
     750:      	b	0x6a0 <_llm_rows.packet_batch.blocks+0x27c>
     754:      	xtn.8b	v5, v3
     758:      	sshll.2d	v19, v1, #0x0
     75c:      	adrp	x9, 0x0 <ltmp0>
     760:      	ldr	q3, [x9]
     764:      	and.16b	v17, v19, v3
     768:      	movi	d2, #0x0000000000ffff
     76c:      	and.8b	v3, v5, v2
     770:      	adrp	x9, 0x0 <ltmp0>
     774:      	ldr	d18, [x9]
     778:      	str	q5, [sp, #0x150]
     77c:      	and.8b	v18, v5, v18
     780:      	addv.8b	b18, v18
     784:      	fmov	w11, s18
     788:      	umaxv.8b	b18, v3
     78c:      	fmov	w9, s18
     790:      	rbit	w12, w11
     794:      	clz	w12, w12
     798:      	tst	w9, #0x1
     79c:      	csel	w9, w12, wzr, ne
     7a0:      	mov	w12, #0x600             ; =1536
     7a4:      	dup.2d	v24, x12
     7a8:      	str	q17, [sp, #0xc0]
     7ac:      	orr.16b	v2, v17, v24
     7b0:      	mov	w12, #0x602             ; =1538
     7b4:      	dup.2s	v23, w12
     7b8:      	xtn.2s	v29, v4
     7bc:      	str	q2, [sp, #0x70]
     7c0:      	umlal.2d	v2, v29, v23
     7c4:      	mov	b4, v3[0]
     7c8:      	mov.b	v4[4], v3[1]
     7cc:      	ushll.2d	v4, v4, #0x0
     7d0:      	shl.2d	v4, v4, #0x3f
     7d4:      	cmlt.2d	v4, v4, #0
     7d8:      	str	q2, [sp, #0x110]
     7dc:      	and.16b	v4, v4, v2
     7e0:      	movi.2d	v2, #0000000000000000
     7e4:      	str	q2, [sp, #0x660]
     7e8:      	str	q2, [sp, #0x650]
     7ec:      	str	q2, [sp, #0x640]
     7f0:      	str	q4, [sp, #0x630]
     7f4:      	and	x12, x9, #0x7
     7f8:      	add	x14, sp, #0x630
     7fc:      	ldr	x12, [x14, x12, lsl #3]
     800:      	sub	x12, x12, x9
     804:      	add	x8, x8, x12, lsl #2
     808:      	movi.2d	v21, #0000000000000000
     80c:      	movi.2d	v28, #0000000000000000
     810:      	tbnz	w11, #0x0, 0x1a64 <_llm_rows.packet_batch.blocks+0x1640>
     814:      	add	x28, sp, #0x1, lsl #12  ; =0x1000
     818:      	add	x28, x28, #0xea0
     81c:      	tbnz	w11, #0x1, 0x1a74 <_llm_rows.packet_batch.blocks+0x1650>
     820:      	tbnz	w11, #0x2, 0x1a80 <_llm_rows.packet_batch.blocks+0x165c>
     824:      	tbnz	w11, #0x3, 0x1a8c <_llm_rows.packet_batch.blocks+0x1668>
     828:      	tbnz	w11, #0x4, 0x1a98 <_llm_rows.packet_batch.blocks+0x1674>
     82c:      	tbnz	w11, #0x5, 0x1aa4 <_llm_rows.packet_batch.blocks+0x1680>
     830:      	tbnz	w11, #0x6, 0x1ab0 <_llm_rows.packet_batch.blocks+0x168c>
     834:      	tbz	w11, #0x7, 0x840 <_llm_rows.packet_batch.blocks+0x41c>
     838:      	add	x8, x8, #0x1c
     83c:      	ld1.s	{ v28 }[3], [x8]
     840:      	sshll.2d	v4, v0, #0x0
     844:      	sshll2.2d	v20, v1, #0x0
     848:      	sshll2.2d	v22, v0, #0x0
     84c:      	adrp	x8, 0x0 <ltmp0>
     850:      	ldr	q25, [x8]
     854:      	and.16b	v2, v22, v25
     858:      	adrp	x8, 0x0 <ltmp0>
     85c:      	ldr	q25, [x8]
     860:      	and.16b	v5, v20, v25
     864:      	adrp	x8, 0x0 <ltmp0>
     868:      	ldr	q25, [x8]
     86c:      	and.16b	v17, v4, v25
     870:      	adrp	x8, 0x0 <ltmp0>
     874:      	ldr	q25, [x8]
     878:      	and.16b	v25, v22, v25
     87c:      	adrp	x8, 0x0 <ltmp0>
     880:      	ldr	q26, [x8]
     884:      	and.16b	v26, v20, v26
     888:      	adrp	x8, 0x0 <ltmp0>
     88c:      	ldr	q27, [x8]
     890:      	and.16b	v4, v4, v27
     894:      	adrp	x8, 0x0 <ltmp0>
     898:      	ldr	q27, [x8]
     89c:      	and.16b	v19, v19, v27
     8a0:      	stp	q17, q5, [sp, #0x90]
     8a4:      	orr.16b	v17, v17, v24
     8a8:      	orr.16b	v18, v5, v24
     8ac:      	str	q2, [sp, #0xb0]
     8b0:      	orr.16b	v5, v2, v24
     8b4:      	umull.2d	v2, v29, v23
     8b8:      	str	q2, [sp, #0xd0]
     8bc:      	xtn.2s	v7, v7
     8c0:      	xtn.2s	v16, v16
     8c4:      	xtn.2s	v6, v6
     8c8:      	stp	q17, q5, [sp, #0x50]
     8cc:      	mov.16b	v2, v5
     8d0:      	umlal.2d	v2, v6, v23
     8d4:      	str	q2, [sp, #0x100]
     8d8:      	str	q18, [sp, #0x40]
     8dc:      	mov.16b	v2, v18
     8e0:      	umlal.2d	v2, v7, v23
     8e4:      	str	q2, [sp, #0xf0]
     8e8:      	mov.16b	v2, v17
     8ec:      	umlal.2d	v2, v16, v23
     8f0:      	str	q2, [sp, #0xe0]
     8f4:      	sshll.2d	v6, v1, #0x0
     8f8:      	sshll.2d	v7, v0, #0x0
     8fc:      	str	q19, [sp, #0x5f0]
     900:      	str	q26, [sp, #0x600]
     904:      	str	q4, [sp, #0x610]
     908:      	str	q25, [sp, #0x620]
     90c:      	and	x8, x9, #0x7
     910:      	add	x12, sp, #0x5f0
     914:      	ldr	x8, [x12, x8, lsl #3]
     918:      	orr	x8, x8, #0x1800
     91c:      	sub	x8, x8, x9, lsl #2
     920:      	tst	w11, #0xff
     924:      	csel	x11, xzr, x8, eq
     928:      	add	x8, x25, x11
     92c:      	ldp	q4, q16, [x8]
     930:      	zip2.8b	v23, v3, v0
     934:      	ushll.4s	v23, v23, #0x0
     938:      	shl.4s	v23, v23, #0x1f
     93c:      	cmlt.4s	v23, v23, #0
     940:      	stp	q28, q21, [sp, #0x130]
     944:      	bit.16b	v16, v28, v23
     948:      	str	q3, [sp, #0x160]
     94c:      	zip1.8b	v23, v3, v0
     950:      	ushll.4s	v23, v23, #0x0
     954:      	shl.4s	v23, v23, #0x1f
     958:      	cmlt.4s	v23, v23, #0
     95c:      	bit.16b	v4, v21, v23
     960:      	stp	q4, q16, [x8]
     964:      	dup.2d	v4, x21
     968:      	and.16b	v27, v22, v4
     96c:      	and.16b	v24, v20, v4
     970:      	and.16b	v26, v7, v4
     974:      	and.16b	v9, v6, v4
     978:      	fmov	x8, d9
     97c:      	ldr	q4, [sp, #0x4f40]
     980:      	ldr	q6, [sp, #0x4f50]
     984:      	and.16b	v6, v0, v6
     988:      	and.16b	v7, v1, v4
     98c:      	ldr	q4, [sp, #0x4f20]
     990:      	ldr	q16, [sp, #0x4f30]
     994:      	and.16b	v29, v0, v16
     998:      	and.16b	v16, v1, v4
     99c:      	ldr	q23, [sp, #0x4f00]
     9a0:      	ldr	q4, [sp, #0x4f10]
     9a4:      	and.16b	v4, v0, v4
     9a8:      	and.16b	v25, v1, v23
     9ac:      	fmov	x12, d19
     9b0:      	add	x12, x25, x12
     9b4:      	ldp	q19, q23, [x12]
     9b8:      	and.16b	v12, v0, v23
     9bc:      	mov	x12, x8
     9c0:      	and.16b	v13, v1, v19
     9c4:      	mov.16b	v19, v9
     9c8:      	mov.16b	v15, v24
     9cc:      	mov.16b	v8, v26
     9d0:      	mov.16b	v23, v27
     9d4:      	sshll.2d	v5, v1, #0x0
     9d8:      	sshll.2d	v18, v0, #0x0
     9dc:      	add	x12, x25, x12, lsl #5
     9e0:      	ldp	q14, q28, [x12]
     9e4:      	fadd.4s	v14, v13, v14
     9e8:      	fadd.4s	v28, v12, v28
     9ec:      	ldp	q10, q17, [x12, #0x20]
     9f0:      	fadd.4s	v10, v25, v10
     9f4:      	fadd.4s	v17, v4, v17
     9f8:      	ldp	q3, q21, [x12, #0x40]
     9fc:      	fadd.4s	v3, v16, v3
     a00:      	fadd.4s	v21, v29, v21
     a04:      	ldp	q31, q30, [x12, #0x60]
     a08:      	fadd.4s	v31, v7, v31
     a0c:      	fadd.4s	v30, v6, v30
     a10:      	dup.2d	v11, x21
     a14:      	and.16b	v2, v22, v11
     a18:      	add.2d	v23, v23, v2
     a1c:      	and.16b	v2, v20, v11
     a20:      	add.2d	v15, v15, v2
     a24:      	and.16b	v2, v18, v11
     a28:      	add.2d	v8, v8, v2
     a2c:      	and.16b	v2, v5, v11
     a30:      	add.2d	v19, v19, v2
     a34:      	bit.16b	v12, v28, v0
     a38:      	bit.16b	v13, v14, v1
     a3c:      	bit.16b	v4, v17, v0
     a40:      	bit.16b	v25, v10, v1
     a44:      	bit.16b	v29, v21, v0
     a48:      	bit.16b	v16, v3, v1
     a4c:      	bit.16b	v6, v30, v0
     a50:      	bit.16b	v7, v31, v1
     a54:      	fmov	x12, d19
     a58:      	cmp	x12, #0xc0
     a5c:      	b.lt	0x9d4 <_llm_rows.packet_batch.blocks+0x5b0>
     a60:      	movi	d2, #0xffffffffffff0000
     a64:      	ldp	q3, q18, [sp, #0x140]
     a68:      	and.8b	v19, v18, v2
     a6c:      	ldr	q2, [sp, #0x130]
     a70:      	fadd.4s	v2, v2, v12
     a74:      	fadd.4s	v3, v3, v13
     a78:      	ldr	q17, [sp, #0x160]
     a7c:      	zip1.8b	v5, v17, v0
     a80:      	ushll.4s	v5, v5, #0x0
     a84:      	shl.4s	v5, v5, #0x1f
     a88:      	cmlt.4s	v5, v5, #0
     a8c:      	and.16b	v3, v5, v3
     a90:      	zip2.8b	v5, v17, v0
     a94:      	ushll.4s	v5, v5, #0x0
     a98:      	shl.4s	v5, v5, #0x1f
     a9c:      	cmlt.4s	v5, v5, #0
     aa0:      	and.16b	v2, v5, v2
     aa4:      	zip2.8b	v5, v19, v0
     aa8:      	ushll.4s	v5, v5, #0x0
     aac:      	shl.4s	v5, v5, #0x1f
     ab0:      	cmlt.4s	v5, v5, #0
     ab4:      	bit.16b	v2, v28, v5
     ab8:      	zip1.8b	v5, v19, v0
     abc:      	ushll.4s	v5, v5, #0x0
     ac0:      	shl.4s	v5, v5, #0x1f
     ac4:      	cmlt.4s	v5, v5, #0
     ac8:      	bit.16b	v3, v14, v5
     acc:      	fadd.4s	v3, v25, v3
     ad0:      	fadd.4s	v2, v4, v2
     ad4:      	fadd.4s	v2, v29, v2
     ad8:      	fadd.4s	v3, v16, v3
     adc:      	fadd.4s	v16, v7, v3
     ae0:      	fadd.4s	v29, v6, v2
     ae4:      	ldp	q2, q4, [sp, #0xb0]
     ae8:      	ldp	q3, q6, [sp, #0x90]
     aec:      	uzp1.4s	v5, v4, v6
     af0:      	uzp1.4s	v30, v3, v2
     af4:      	movi.4s	v3, #0x1
     af8:      	eor.16b	v2, v5, v3
     afc:      	mov.s	w14, v2[1]
     b00:      	mov.s	w15, v2[2]
     b04:      	eor.16b	v25, v30, v3
     b08:      	mov.s	w0, v2[3]
     b0c:      	fmov	w12, s2
     b10:      	add	x16, sp, #0x488
     b14:      	bfxil	x16, x12, #0, #3
     b18:      	str	d18, [sp, #0x488]
     b1c:      	ldrb	w16, [x16]
     b20:      	and	x17, x12, #0x7
     b24:      	umov.b	w12, v18[0]
     b28:      	str	q29, [sp, #0x560]
     b2c:      	str	q16, [sp, #0x550]
     b30:      	add	x1, sp, #0x550
     b34:      	ldr	s2, [x1, x17, lsl #2]
     b38:      	ands	w17, w12, #0x1
     b3c:      	tst	w17, w16
     b40:      	movi	d10, #0000000000000000
     b44:      	fcsel	s6, s2, s10, ne
     b48:      	and	x1, x14, #0x7
     b4c:      	add	x16, sp, #0x488
     b50:      	bfxil	x16, x14, #0, #3
     b54:      	ldrb	w14, [x16]
     b58:      	umov.b	w16, v18[1]
     b5c:      	and	w14, w16, w14
     b60:      	str	q29, [sp, #0x540]
     b64:      	str	q16, [sp, #0x530]
     b68:      	add	x2, sp, #0x530
     b6c:      	ldr	s2, [x2, x1, lsl #2]
     b70:      	tst	w14, #0x1
     b74:      	fcsel	s7, s2, s10, ne
     b78:      	and	x1, x15, #0x7
     b7c:      	add	x2, sp, #0x488
     b80:      	bfxil	x2, x15, #0, #3
     b84:      	umov.b	w14, v18[2]
     b88:      	ldrb	w15, [x2]
     b8c:      	and	w15, w14, w15
     b90:      	str	q29, [sp, #0x520]
     b94:      	str	q16, [sp, #0x510]
     b98:      	add	x2, sp, #0x510
     b9c:      	ldr	s2, [x2, x1, lsl #2]
     ba0:      	tst	w15, #0x1
     ba4:      	fcsel	s4, s2, s10, ne
     ba8:      	and	x1, x0, #0x7
     bac:      	add	x15, sp, #0x488
     bb0:      	bfxil	x15, x0, #0, #3
     bb4:      	ldrb	w0, [x15]
     bb8:      	umov.b	w15, v18[3]
     bbc:      	str	q29, [sp, #0x500]
     bc0:      	str	q16, [sp, #0x4f0]
     bc4:      	add	x2, sp, #0x4f0
     bc8:      	ldr	s2, [x2, x1, lsl #2]
     bcc:      	and	w0, w15, w0
     bd0:      	tst	w0, #0x1
     bd4:      	mov.s	w0, v25[1]
     bd8:      	mov.s	w1, v25[2]
     bdc:      	fcsel	s31, s2, s10, ne
     be0:      	mov.s	w4, v25[3]
     be4:      	fmov	w2, s25
     be8:      	and	x5, x2, #0x7
     bec:      	add	x3, sp, #0x488
     bf0:      	bfxil	x3, x2, #0, #3
     bf4:      	ldrb	w2, [x3]
     bf8:      	umov.b	w3, v18[4]
     bfc:      	and	w2, w3, w2
     c00:      	str	q29, [sp, #0x5e0]
     c04:      	str	q16, [sp, #0x5d0]
     c08:      	add	x6, sp, #0x5d0
     c0c:      	ldr	s2, [x6, x5, lsl #2]
     c10:      	tst	w2, #0x1
     c14:      	fcsel	s2, s2, s10, ne
     c18:      	and	x5, x0, #0x7
     c1c:      	add	x2, sp, #0x488
     c20:      	bfxil	x2, x0, #0, #3
     c24:      	ldrb	w0, [x2]
     c28:      	umov.b	w2, v18[5]
     c2c:      	and	w0, w2, w0
     c30:      	str	q29, [sp, #0x5c0]
     c34:      	str	q16, [sp, #0x5b0]
     c38:      	add	x6, sp, #0x5b0
     c3c:      	ldr	s3, [x6, x5, lsl #2]
     c40:      	tst	w0, #0x1
     c44:      	fcsel	s3, s3, s10, ne
     c48:      	and	x5, x1, #0x7
     c4c:      	add	x0, sp, #0x488
     c50:      	bfxil	x0, x1, #0, #3
     c54:      	ldrb	w1, [x0]
     c58:      	umov.b	w0, v18[6]
     c5c:      	and	w1, w0, w1
     c60:      	str	q29, [sp, #0x5a0]
     c64:      	str	q16, [sp, #0x590]
     c68:      	add	x6, sp, #0x590
     c6c:      	ldr	s17, [x6, x5, lsl #2]
     c70:      	tst	w1, #0x1
     c74:      	fcsel	s17, s17, s10, ne
     c78:      	and	x5, x4, #0x7
     c7c:      	add	x6, sp, #0x488
     c80:      	bfxil	x6, x4, #0, #3
     c84:      	umov.b	w1, v18[7]
     c88:      	ldrb	w4, [x6]
     c8c:      	and	w4, w1, w4
     c90:      	str	q29, [sp, #0x580]
     c94:      	str	q16, [sp, #0x570]
     c98:      	add	x6, sp, #0x570
     c9c:      	ldr	s18, [x6, x5, lsl #2]
     ca0:      	tst	w4, #0x1
     ca4:      	fcsel	s18, s18, s10, ne
     ca8:      	mov.s	v2[1], v3[0]
     cac:      	mov.s	v2[2], v17[0]
     cb0:      	mov.s	v2[3], v18[0]
     cb4:      	mov.s	v6[1], v7[0]
     cb8:      	mov.s	v6[2], v4[0]
     cbc:      	mov.s	v6[3], v31[0]
     cc0:      	fadd.4s	v3, v16, v6
     cc4:      	fadd.4s	v2, v29, v2
     cc8:      	movi.4s	v6, #0x2
     ccc:      	eor.16b	v4, v30, v6
     cd0:      	eor.16b	v5, v5, v6
     cd4:      	fmov	w4, s5
     cd8:      	add	x5, sp, #0x488
     cdc:      	bfxil	x5, x4, #0, #3
     ce0:      	ldrb	w5, [x5]
     ce4:      	and	x4, x4, #0x7
     ce8:      	str	q2, [sp, #0x4e0]
     cec:      	str	q3, [sp, #0x4d0]
     cf0:      	add	x6, sp, #0x4d0
     cf4:      	ldr	s5, [x6, x4, lsl #2]
     cf8:      	tst	w17, w5
     cfc:      	fcsel	s5, s5, s10, ne
     d00:      	fmov	w17, s4
     d04:      	and	x4, x17, #0x7
     d08:      	add	x5, sp, #0x488
     d0c:      	bfxil	x5, x17, #0, #3
     d10:      	ldrb	w17, [x5]
     d14:      	and	w17, w3, w17
     d18:      	str	q2, [sp, #0x4c0]
     d1c:      	str	q3, [sp, #0x4b0]
     d20:      	add	x5, sp, #0x4b0
     d24:      	ldr	s4, [x5, x4, lsl #2]
     d28:      	tst	w17, #0x1
     d2c:      	fcsel	s4, s4, s10, ne
     d30:      	fadd.4s	v2, v2, v4
     d34:      	and	w17, w12, w3
     d38:      	tst	w17, #0x1
     d3c:      	fcsel	s2, s2, s10, ne
     d40:      	ands	w4, w12, #0x1
     d44:      	fadd.4s	v3, v3, v5
     d48:      	fadd	s2, s3, s2
     d4c:      	fcsel	s3, s2, s10, ne
     d50:      	tst	w17, #0x1
     d54:      	sshll.2d	v4, v1, #0x0
     d58:      	mov	w5, #0x20               ; =32
     d5c:      	dup.2d	v5, x5
     d60:      	and.16b	v6, v4, v5
     d64:      	mov	w5, #0x40               ; =64
     d68:      	dup.2d	v5, x5
     d6c:      	and.16b	v5, v4, v5
     d70:      	mov	w5, #0x60               ; =96
     d74:      	dup.2d	v7, x5
     d78:      	and.16b	v4, v4, v7
     d7c:      	and	w5, w16, w12
     d80:      	fcsel	s7, s2, s10, ne
     d84:      	str	w5, [sp, #0xc0]
     d88:      	tst	w5, #0x1
     d8c:      	and	w5, w14, w12
     d90:      	fcsel	s16, s2, s10, ne
     d94:      	str	w5, [sp, #0xb0]
     d98:      	tst	w5, #0x1
     d9c:      	and	w5, w15, w12
     da0:      	fcsel	s17, s2, s10, ne
     da4:      	str	w5, [sp, #0xa0]
     da8:      	tst	w5, #0x1
     dac:      	fcsel	s18, s2, s10, ne
     db0:      	and	w5, w2, w12
     db4:      	str	w5, [sp, #0x90]
     db8:      	tst	w5, #0x1
     dbc:      	fcsel	s21, s2, s10, ne
     dc0:      	and	w5, w0, w12
     dc4:      	tst	w5, #0x1
     dc8:      	fcsel	s23, s2, s10, ne
     dcc:      	and	w6, w1, w12
     dd0:      	tst	w6, #0x1
     dd4:      	fcsel	s2, s2, s10, ne
     dd8:      	mov.s	v3[1], v16[0]
     ddc:      	mov.s	v3[2], v17[0]
     de0:      	mov.s	v3[3], v18[0]
     de4:      	mov.s	v7[1], v21[0]
     de8:      	mov.s	v7[2], v23[0]
     dec:      	mov.s	v7[3], v2[0]
     df0:      	rbit	w7, w7
     df4:      	clz	w7, w7
     df8:      	str	q7, [sp, #0x4a0]
     dfc:      	str	q3, [sp, #0x490]
     e00:      	str	x7, [sp, #0x88]
     e04:      	and	x7, x7, #0x7
     e08:      	add	x23, sp, #0x490
     e0c:      	ldr	s2, [x23, x7, lsl #2]
     e10:      	fmov	x7, d6
     e14:      	add	x7, x25, x7
     e18:      	ldp	q3, q7, [x7]
     e1c:      	fmov	x7, d5
     e20:      	add	x7, x25, x7
     e24:      	ldp	q5, q16, [x7]
     e28:      	fmov	x7, d4
     e2c:      	add	x7, x25, x7
     e30:      	ldp	q4, q17, [x7]
     e34:      	fadd	s2, s2, s10
     e38:      	mov	w7, #0x4000             ; =16384
     e3c:      	movk	w7, #0x44c0, lsl #16
     e40:      	fmov	s6, w7
     e44:      	fdiv	s2, s2, s6
     e48:      	ldr	q6, [sp, #0x4ee0]
     e4c:      	ldr	q18, [sp, #0x4ef0]
     e50:      	and.16b	v18, v0, v18
     e54:      	and.16b	v21, v1, v6
     e58:      	dup.4s	v6, v2[0]
     e5c:      	fsub.4s	v2, v21, v6
     e60:      	fsub.4s	v18, v18, v6
     e64:      	ldr	q21, [sp, #0x36c0]
     e68:      	ldr	q23, [sp, #0x36d0]
     e6c:      	bit.16b	v23, v18, v0
     e70:      	bit.16b	v21, v2, v1
     e74:      	and.16b	v7, v0, v7
     e78:      	and.16b	v3, v1, v3
     e7c:      	fsub.4s	v3, v3, v6
     e80:      	fsub.4s	v7, v7, v6
     e84:      	str	q21, [sp, #0x36c0]
     e88:      	str	q23, [sp, #0x36d0]
     e8c:      	ldr	q21, [sp, #0x36e0]
     e90:      	ldr	q23, [sp, #0x36f0]
     e94:      	bit.16b	v23, v7, v0
     e98:      	bit.16b	v21, v3, v1
     e9c:      	and.16b	v16, v0, v16
     ea0:      	and.16b	v5, v1, v5
     ea4:      	fsub.4s	v5, v5, v6
     ea8:      	fsub.4s	v16, v16, v6
     eac:      	ldr	q25, [sp, #0x3700]
     eb0:      	ldr	q28, [sp, #0x3710]
     eb4:      	bit.16b	v28, v16, v0
     eb8:      	bit.16b	v25, v5, v1
     ebc:      	and.16b	v17, v0, v17
     ec0:      	and.16b	v4, v1, v4
     ec4:      	fsub.4s	v4, v4, v6
     ec8:      	fsub.4s	v17, v17, v6
     ecc:      	ldr	q29, [sp, #0x3720]
     ed0:      	ldr	q30, [sp, #0x3730]
     ed4:      	mov.16b	v31, v0
     ed8:      	bsl.16b	v31, v17, v30
     edc:      	mov.16b	v8, v1
     ee0:      	bsl.16b	v8, v4, v29
     ee4:      	fmul.4s	v4, v4, v4
     ee8:      	fmul.4s	v17, v17, v17
     eec:      	and.16b	v29, v0, v17
     ef0:      	and.16b	v30, v1, v4
     ef4:      	str	q21, [sp, #0x36e0]
     ef8:      	str	q23, [sp, #0x36f0]
     efc:      	str	q25, [sp, #0x3700]
     f00:      	str	q28, [sp, #0x3710]
     f04:      	str	q8, [sp, #0x3720]
     f08:      	str	q31, [sp, #0x3730]
     f0c:      	fmul.4s	v4, v5, v5
     f10:      	fmul.4s	v5, v16, v16
     f14:      	and.16b	v11, v0, v5
     f18:      	and.16b	v31, v1, v4
     f1c:      	fmul.4s	v3, v3, v3
     f20:      	fmul.4s	v4, v7, v7
     f24:      	and.16b	v12, v0, v4
     f28:      	and.16b	v13, v1, v3
     f2c:      	fmul.4s	v2, v2, v2
     f30:      	fmul.4s	v3, v18, v18
     f34:      	and.16b	v15, v0, v3
     f38:      	and.16b	v14, v1, v2
     f3c:      	sshll.2d	v4, v1, #0x0
     f40:      	sshll.2d	v7, v0, #0x0
     f44:      	lsl	x8, x8, #5
     f48:      	add	x7, x25, x8
     f4c:      	ldp	q2, q3, [x7]
     f50:      	and.16b	v3, v0, v3
     f54:      	and.16b	v2, v1, v2
     f58:      	fsub.4s	v2, v2, v6
     f5c:      	fsub.4s	v3, v3, v6
     f60:      	add	x7, x19, x8
     f64:      	ldp	q5, q16, [x7]
     f68:      	bit.16b	v16, v3, v0
     f6c:      	bit.16b	v5, v2, v1
     f70:      	stp	q5, q16, [x7]
     f74:      	fmul.4s	v3, v3, v3
     f78:      	fmul.4s	v2, v2, v2
     f7c:      	fadd.4s	v16, v14, v2
     f80:      	fadd.4s	v5, v15, v3
     f84:      	add	x7, x8, #0x20
     f88:      	add	x23, x25, x7
     f8c:      	ldp	q2, q3, [x23]
     f90:      	and.16b	v3, v0, v3
     f94:      	and.16b	v2, v1, v2
     f98:      	fsub.4s	v2, v2, v6
     f9c:      	fsub.4s	v3, v3, v6
     fa0:      	add	x7, x19, x7
     fa4:      	ldp	q17, q18, [x7]
     fa8:      	bit.16b	v18, v3, v0
     fac:      	bit.16b	v17, v2, v1
     fb0:      	stp	q17, q18, [x7]
     fb4:      	fmul.4s	v3, v3, v3
     fb8:      	fmul.4s	v2, v2, v2
     fbc:      	fadd.4s	v2, v13, v2
     fc0:      	fadd.4s	v3, v12, v3
     fc4:      	add	x7, x8, #0x40
     fc8:      	add	x23, x25, x7
     fcc:      	ldp	q17, q18, [x23]
     fd0:      	and.16b	v18, v0, v18
     fd4:      	and.16b	v17, v1, v17
     fd8:      	fsub.4s	v17, v17, v6
     fdc:      	fsub.4s	v18, v18, v6
     fe0:      	add	x7, x19, x7
     fe4:      	ldp	q21, q23, [x7]
     fe8:      	bit.16b	v23, v18, v0
     fec:      	bit.16b	v21, v17, v1
     ff0:      	stp	q21, q23, [x7]
     ff4:      	fmul.4s	v18, v18, v18
     ff8:      	fmul.4s	v17, v17, v17
     ffc:      	fadd.4s	v17, v31, v17
    1000:      	fadd.4s	v18, v11, v18
    1004:      	add	x8, x8, #0x60
    1008:      	add	x7, x25, x8
    100c:      	ldp	q21, q23, [x7]
    1010:      	and.16b	v23, v0, v23
    1014:      	and.16b	v21, v1, v21
    1018:      	fsub.4s	v21, v21, v6
    101c:      	fsub.4s	v23, v23, v6
    1020:      	add	x8, x19, x8
    1024:      	ldp	q25, q28, [x8]
    1028:      	bit.16b	v28, v23, v0
    102c:      	bit.16b	v25, v21, v1
    1030:      	stp	q25, q28, [x8]
    1034:      	fmul.4s	v23, v23, v23
    1038:      	fmul.4s	v21, v21, v21
    103c:      	fadd.4s	v21, v30, v21
    1040:      	fadd.4s	v23, v29, v23
    1044:      	dup.2d	v25, x21
    1048:      	and.16b	v28, v22, v25
    104c:      	add.2d	v27, v27, v28
    1050:      	and.16b	v28, v20, v25
    1054:      	add.2d	v24, v24, v28
    1058:      	and.16b	v7, v7, v25
    105c:      	add.2d	v26, v26, v7
    1060:      	and.16b	v4, v4, v25
    1064:      	add.2d	v9, v9, v4
    1068:      	bit.16b	v15, v5, v0
    106c:      	bit.16b	v14, v16, v1
    1070:      	bit.16b	v12, v3, v0
    1074:      	bit.16b	v13, v2, v1
    1078:      	bit.16b	v11, v18, v0
    107c:      	bit.16b	v31, v17, v1
    1080:      	bit.16b	v29, v23, v0
    1084:      	bit.16b	v30, v21, v1
    1088:      	fmov	x8, d9
    108c:      	cmp	x8, #0xc0
    1090:      	b.lt	0xf3c <_llm_rows.packet_batch.blocks+0xb18>
    1094:      	mov	x8, #0x0                ; =0
    1098:      	ldp	q2, q3, [sp, #0x130]
    109c:      	fsub.4s	v20, v3, v6
    10a0:      	fsub.4s	v18, v2, v6
    10a4:      	add	x7, x19, x11
    10a8:      	ldp	q2, q3, [x7]
    10ac:      	ldr	q6, [sp, #0x160]
    10b0:      	zip2.8b	v4, v6, v0
    10b4:      	ushll.4s	v4, v4, #0x0
    10b8:      	shl.4s	v4, v4, #0x1f
    10bc:      	cmlt.4s	v4, v4, #0
    10c0:      	bit.16b	v3, v18, v4
    10c4:      	zip1.8b	v4, v6, v0
    10c8:      	ushll.4s	v4, v4, #0x0
    10cc:      	shl.4s	v4, v4, #0x1f
    10d0:      	cmlt.4s	v4, v4, #0
    10d4:      	bit.16b	v2, v20, v4
    10d8:      	stp	q2, q3, [x7]
    10dc:      	mov	w7, #0x1                ; =1
    10e0:      	dup.2d	v2, x7
    10e4:      	ushll2.2d	v3, v0, #0x0
    10e8:      	and.16b	v21, v3, v2
    10ec:      	ushll2.2d	v3, v1, #0x0
    10f0:      	and.16b	v22, v3, v2
    10f4:      	ushll.2d	v3, v0, #0x0
    10f8:      	and.16b	v23, v3, v2
    10fc:      	ushll.2d	v3, v1, #0x0
    1100:      	and.16b	v24, v3, v2
    1104:      	movi.2d	v6, #0000000000000000
    1108:      	movi.2d	v8, #0000000000000000
    110c:      	movi.2d	v9, #0000000000000000
    1110:      	movi.2d	v7, #0000000000000000
    1114:      	ldr	q17, [sp, #0x190]
    1118:      	b	0x114c <_llm_rows.packet_batch.blocks+0xd28>
    111c:      	add	x8, x28, x8
    1120:      	ldp	q2, q3, [x8]
    1124:      	bit.16b	v3, v25, v0
    1128:      	bit.16b	v2, v4, v1
    112c:      	stp	q2, q3, [x8]
    1130:      	add.2d	v8, v8, v22
    1134:      	add.2d	v9, v9, v23
    1138:      	add.2d	v7, v7, v21
    113c:      	add.2d	v6, v6, v24
    1140:      	fmov	x8, d6
    1144:      	cmp	x8, #0xc0
    1148:      	b.ge	0x11e8 <_llm_rows.packet_batch.blocks+0xdc4>
    114c:      	fmov	w23, s17
    1150:      	lsl	x8, x8, #5
    1154:      	add	x7, x13, x8
    1158:      	movi.2d	v4, #0000000000000000
    115c:      	movi.2d	v25, #0000000000000000
    1160:      	tbnz	w23, #0x0, 0x1188 <_llm_rows.packet_batch.blocks+0xd64>
    1164:      	and	w30, w23, #0xff
    1168:      	tbnz	w30, #0x1, 0x1194 <_llm_rows.packet_batch.blocks+0xd70>
    116c:      	tbnz	w30, #0x2, 0x11a0 <_llm_rows.packet_batch.blocks+0xd7c>
    1170:      	tbnz	w30, #0x3, 0x11ac <_llm_rows.packet_batch.blocks+0xd88>
    1174:      	tbnz	w30, #0x4, 0x11b8 <_llm_rows.packet_batch.blocks+0xd94>
    1178:      	tbnz	w30, #0x5, 0x11c4 <_llm_rows.packet_batch.blocks+0xda0>
    117c:      	tbnz	w30, #0x6, 0x11d0 <_llm_rows.packet_batch.blocks+0xdac>
    1180:      	tbz	w30, #0x7, 0x111c <_llm_rows.packet_batch.blocks+0xcf8>
    1184:      	b	0x11dc <_llm_rows.packet_batch.blocks+0xdb8>
    1188:      	ldr	s4, [x7]
    118c:      	and	w30, w23, #0xff
    1190:      	tbz	w30, #0x1, 0x116c <_llm_rows.packet_batch.blocks+0xd48>
    1194:      	add	x23, x7, #0x4
    1198:      	ld1.s	{ v4 }[1], [x23]
    119c:      	tbz	w30, #0x2, 0x1170 <_llm_rows.packet_batch.blocks+0xd4c>
    11a0:      	add	x23, x7, #0x8
    11a4:      	ld1.s	{ v4 }[2], [x23]
    11a8:      	tbz	w30, #0x3, 0x1174 <_llm_rows.packet_batch.blocks+0xd50>
    11ac:      	add	x23, x7, #0xc
    11b0:      	ld1.s	{ v4 }[3], [x23]
    11b4:      	tbz	w30, #0x4, 0x1178 <_llm_rows.packet_batch.blocks+0xd54>
    11b8:      	add	x23, x7, #0x10
    11bc:      	ld1.s	{ v25 }[0], [x23]
    11c0:      	tbz	w30, #0x5, 0x117c <_llm_rows.packet_batch.blocks+0xd58>
    11c4:      	add	x23, x7, #0x14
    11c8:      	ld1.s	{ v25 }[1], [x23]
    11cc:      	tbz	w30, #0x6, 0x1180 <_llm_rows.packet_batch.blocks+0xd5c>
    11d0:      	add	x23, x7, #0x18
    11d4:      	ld1.s	{ v25 }[2], [x23]
    11d8:      	tbz	w30, #0x7, 0x111c <_llm_rows.packet_batch.blocks+0xcf8>
    11dc:      	add	x7, x7, #0x1c
    11e0:      	ld1.s	{ v25 }[3], [x7]
    11e4:      	b	0x111c <_llm_rows.packet_batch.blocks+0xcf8>
    11e8:      	ldr	q28, [sp, #0x160]
    11ec:      	mov	b2, v28[0]
    11f0:      	mov.b	v2[4], v28[1]
    11f4:      	ushll.2d	v2, v2, #0x0
    11f8:      	shl.2d	v2, v2, #0x3f
    11fc:      	cmlt.2d	v2, v2, #0
    1200:      	ldr	q3, [sp, #0x70]
    1204:      	and.16b	v2, v2, v3
    1208:      	mov	b3, v28[2]
    120c:      	mov.b	v3[4], v28[3]
    1210:      	ushll.2d	v3, v3, #0x0
    1214:      	shl.2d	v3, v3, #0x3f
    1218:      	cmlt.2d	v3, v3, #0
    121c:      	mov	b4, v28[4]
    1220:      	mov.b	v4[4], v28[5]
    1224:      	ldp	q7, q6, [sp, #0x40]
    1228:      	and.16b	v3, v3, v7
    122c:      	ushll.2d	v4, v4, #0x0
    1230:      	shl.2d	v4, v4, #0x3f
    1234:      	cmlt.2d	v4, v4, #0
    1238:      	and.16b	v4, v4, v6
    123c:      	mov	b6, v28[6]
    1240:      	mov.b	v6[4], v28[7]
    1244:      	ushll.2d	v6, v6, #0x0
    1248:      	shl.2d	v6, v6, #0x3f
    124c:      	cmlt.2d	v6, v6, #0
    1250:      	ldr	q7, [sp, #0x60]
    1254:      	and.16b	v6, v6, v7
    1258:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0xbdc>
    125c:      	ldr	d7, [x8]
    1260:      	shl.8b	v17, v28, #0x7
    1264:      	cmlt.8b	v17, v17, #0
    1268:      	and.8b	v7, v17, v7
    126c:      	addv.8b	b26, v7
    1270:      	str	q6, [sp, #0x470]
    1274:      	str	q4, [sp, #0x460]
    1278:      	str	q3, [sp, #0x450]
    127c:      	str	q2, [sp, #0x440]
    1280:      	and	x8, x9, #0x7
    1284:      	add	x7, sp, #0x440
    1288:      	ldr	x8, [x7, x8, lsl #3]
    128c:      	fmov	w7, s26
    1290:      	sub	x8, x8, x9
    1294:      	lsl	x8, x8, #2
    1298:      	add	x13, x13, x8
    129c:      	movi.2d	v27, #0000000000000000
    12a0:      	movi.2d	v25, #0000000000000000
    12a4:      	tbnz	w7, #0x0, 0x1ac0 <_llm_rows.packet_batch.blocks+0x169c>
    12a8:      	tbnz	w7, #0x1, 0x1ac8 <_llm_rows.packet_batch.blocks+0x16a4>
    12ac:      	ldr	q17, [sp, #0x190]
    12b0:      	tbnz	w7, #0x2, 0x1ad8 <_llm_rows.packet_batch.blocks+0x16b4>
    12b4:      	tbnz	w7, #0x3, 0x1ae4 <_llm_rows.packet_batch.blocks+0x16c0>
    12b8:      	tbnz	w7, #0x4, 0x1af0 <_llm_rows.packet_batch.blocks+0x16cc>
    12bc:      	tbnz	w7, #0x5, 0x1afc <_llm_rows.packet_batch.blocks+0x16d8>
    12c0:      	tbnz	w7, #0x6, 0x1b08 <_llm_rows.packet_batch.blocks+0x16e4>
    12c4:      	tbz	w7, #0x7, 0x12d0 <_llm_rows.packet_batch.blocks+0xeac>
    12c8:      	add	x13, x13, #0x1c
    12cc:      	ld1.s	{ v25 }[3], [x13]
    12d0:      	mov	x13, #0x0               ; =0
    12d4:      	add	x7, x28, x11
    12d8:      	ldp	q2, q3, [x7]
    12dc:      	zip2.8b	v4, v28, v0
    12e0:      	ushll.4s	v4, v4, #0x0
    12e4:      	shl.4s	v4, v4, #0x1f
    12e8:      	cmlt.4s	v4, v4, #0
    12ec:      	bit.16b	v3, v25, v4
    12f0:      	zip1.8b	v4, v28, v0
    12f4:      	ushll.4s	v4, v4, #0x0
    12f8:      	shl.4s	v4, v4, #0x1f
    12fc:      	cmlt.4s	v4, v4, #0
    1300:      	bit.16b	v2, v27, v4
    1304:      	stp	q2, q3, [x7]
    1308:      	movi.2d	v6, #0000000000000000
    130c:      	movi.2d	v28, #0000000000000000
    1310:      	movi.2d	v8, #0000000000000000
    1314:      	movi.2d	v7, #0000000000000000
    1318:      	b	0x134c <_llm_rows.packet_batch.blocks+0xf28>
    131c:      	add	x13, x27, x13
    1320:      	ldp	q2, q3, [x13]
    1324:      	bit.16b	v3, v9, v0
    1328:      	bit.16b	v2, v4, v1
    132c:      	stp	q2, q3, [x13]
    1330:      	add.2d	v28, v28, v22
    1334:      	add.2d	v8, v8, v23
    1338:      	add.2d	v7, v7, v21
    133c:      	add.2d	v6, v6, v24
    1340:      	fmov	x13, d6
    1344:      	cmp	x13, #0xc0
    1348:      	b.ge	0x13e8 <_llm_rows.packet_batch.blocks+0xfc4>
    134c:      	fmov	w23, s17
    1350:      	lsl	x13, x13, #5
    1354:      	add	x7, x10, x13
    1358:      	movi.2d	v4, #0000000000000000
    135c:      	movi.2d	v9, #0000000000000000
    1360:      	tbnz	w23, #0x0, 0x1388 <_llm_rows.packet_batch.blocks+0xf64>
    1364:      	and	w30, w23, #0xff
    1368:      	tbnz	w30, #0x1, 0x1394 <_llm_rows.packet_batch.blocks+0xf70>
    136c:      	tbnz	w30, #0x2, 0x13a0 <_llm_rows.packet_batch.blocks+0xf7c>
    1370:      	tbnz	w30, #0x3, 0x13ac <_llm_rows.packet_batch.blocks+0xf88>
    1374:      	tbnz	w30, #0x4, 0x13b8 <_llm_rows.packet_batch.blocks+0xf94>
    1378:      	tbnz	w30, #0x5, 0x13c4 <_llm_rows.packet_batch.blocks+0xfa0>
    137c:      	tbnz	w30, #0x6, 0x13d0 <_llm_rows.packet_batch.blocks+0xfac>
    1380:      	tbz	w30, #0x7, 0x131c <_llm_rows.packet_batch.blocks+0xef8>
    1384:      	b	0x13dc <_llm_rows.packet_batch.blocks+0xfb8>
    1388:      	ldr	s4, [x7]
    138c:      	and	w30, w23, #0xff
    1390:      	tbz	w30, #0x1, 0x136c <_llm_rows.packet_batch.blocks+0xf48>
    1394:      	add	x23, x7, #0x4
    1398:      	ld1.s	{ v4 }[1], [x23]
    139c:      	tbz	w30, #0x2, 0x1370 <_llm_rows.packet_batch.blocks+0xf4c>
    13a0:      	add	x23, x7, #0x8
    13a4:      	ld1.s	{ v4 }[2], [x23]
    13a8:      	tbz	w30, #0x3, 0x1374 <_llm_rows.packet_batch.blocks+0xf50>
    13ac:      	add	x23, x7, #0xc
    13b0:      	ld1.s	{ v4 }[3], [x23]
    13b4:      	tbz	w30, #0x4, 0x1378 <_llm_rows.packet_batch.blocks+0xf54>
    13b8:      	add	x23, x7, #0x10
    13bc:      	ld1.s	{ v9 }[0], [x23]
    13c0:      	tbz	w30, #0x5, 0x137c <_llm_rows.packet_batch.blocks+0xf58>
    13c4:      	add	x23, x7, #0x14
    13c8:      	ld1.s	{ v9 }[1], [x23]
    13cc:      	tbz	w30, #0x6, 0x1380 <_llm_rows.packet_batch.blocks+0xf5c>
    13d0:      	add	x23, x7, #0x18
    13d4:      	ld1.s	{ v9 }[2], [x23]
    13d8:      	tbz	w30, #0x7, 0x131c <_llm_rows.packet_batch.blocks+0xef8>
    13dc:      	add	x7, x7, #0x1c
    13e0:      	ld1.s	{ v9 }[3], [x7]
    13e4:      	b	0x131c <_llm_rows.packet_batch.blocks+0xef8>
    13e8:      	adrp	x13, 0x1000 <_llm_rows.packet_batch.blocks+0xbdc>
    13ec:      	ldr	q2, [x13]
    13f0:      	and.16b	v7, v0, v2
    13f4:      	adrp	x13, 0x1000 <_llm_rows.packet_batch.blocks+0xbdc>
    13f8:      	ldr	q2, [x13]
    13fc:      	and.16b	v28, v1, v2
    1400:      	adrp	x13, 0x1000 <_llm_rows.packet_batch.blocks+0xbdc>
    1404:      	ldr	q6, [x13]
    1408:      	fmul.4s	v2, v20, v20
    140c:      	fmul.4s	v3, v18, v18
    1410:      	fadd.4s	v3, v3, v15
    1414:      	fadd.4s	v2, v2, v14
    1418:      	ldr	q8, [sp, #0x160]
    141c:      	zip1.8b	v4, v8, v0
    1420:      	ushll.4s	v4, v4, #0x0
    1424:      	shl.4s	v4, v4, #0x1f
    1428:      	cmlt.4s	v4, v4, #0
    142c:      	and.16b	v2, v4, v2
    1430:      	zip2.8b	v4, v8, v0
    1434:      	ushll.4s	v4, v4, #0x0
    1438:      	shl.4s	v4, v4, #0x1f
    143c:      	cmlt.4s	v4, v4, #0
    1440:      	and.16b	v3, v4, v3
    1444:      	zip2.8b	v4, v19, v0
    1448:      	ushll.4s	v4, v4, #0x0
    144c:      	shl.4s	v4, v4, #0x1f
    1450:      	cmlt.4s	v4, v4, #0
    1454:      	bit.16b	v3, v5, v4
    1458:      	zip1.8b	v4, v19, v0
    145c:      	ushll.4s	v4, v4, #0x0
    1460:      	shl.4s	v4, v4, #0x1f
    1464:      	cmlt.4s	v4, v4, #0
    1468:      	bit.16b	v2, v16, v4
    146c:      	fadd.4s	v2, v13, v2
    1470:      	fadd.4s	v3, v12, v3
    1474:      	fadd.4s	v3, v3, v11
    1478:      	fadd.4s	v2, v2, v31
    147c:      	fadd.4s	v4, v2, v30
    1480:      	fadd.4s	v16, v3, v29
    1484:      	fmov	w13, s28
    1488:      	add	x7, sp, #0x1e8
    148c:      	bfxil	x7, x13, #0, #3
    1490:      	ldr	q2, [sp, #0x150]
    1494:      	str	d2, [sp, #0x1e8]
    1498:      	ldrb	w7, [x7]
    149c:      	add	x21, sp, #0x410
    14a0:      	orr	x13, x21, x13, lsl #2
    14a4:      	str	q16, [sp, #0x420]
    14a8:      	str	q4, [sp, #0x410]
    14ac:      	ldr	s2, [x13]
    14b0:      	tst	w4, w7
    14b4:      	fcsel	s5, s2, s10, ne
    14b8:      	mov.s	w13, v28[1]
    14bc:      	add	x7, sp, #0x1e8
    14c0:      	bfxil	x7, x13, #0, #3
    14c4:      	ldrb	w13, [x7]
    14c8:      	and	w13, w16, w13
    14cc:      	str	q4, [sp, #0x3f0]
    14d0:      	ldr	s2, [sp, #0x3f0]
    14d4:      	tst	w13, #0x1
    14d8:      	mov.s	w13, v28[2]
    14dc:      	fcsel	s17, s2, s10, ne
    14e0:      	add	x7, sp, #0x1e8
    14e4:      	bfxil	x7, x13, #0, #3
    14e8:      	add	x21, sp, #0x3d0
    14ec:      	orr	x13, x21, x13, lsl #2
    14f0:      	ldrb	w7, [x7]
    14f4:      	and	w7, w14, w7
    14f8:      	stp	q4, q16, [sp, #0x3d0]
    14fc:      	ldr	s2, [x13]
    1500:      	tst	w7, #0x1
    1504:      	mov.s	w13, v28[3]
    1508:      	fcsel	s19, s2, s10, ne
    150c:      	add	x7, sp, #0x1e8
    1510:      	bfxil	x7, x13, #0, #3
    1514:      	add	x21, sp, #0x3b0
    1518:      	orr	x13, x21, x13, lsl #2
    151c:      	ldrb	w7, [x7]
    1520:      	and	w7, w15, w7
    1524:      	stp	q4, q16, [sp, #0x3b0]
    1528:      	ldr	s2, [x13]
    152c:      	tst	w7, #0x1
    1530:      	fcsel	s28, s2, s10, ne
    1534:      	fmov	w13, s7
    1538:      	add	x7, sp, #0x1e8
    153c:      	bfxil	x7, x13, #0, #3
    1540:      	ldrb	w7, [x7]
    1544:      	and	w7, w3, w7
    1548:      	stp	q4, q16, [sp, #0x390]
    154c:      	add	x21, sp, #0x390
    1550:      	ldr	s2, [x21, w13, uxtw #2]
    1554:      	tst	w7, #0x1
    1558:      	fcsel	s2, s2, s10, ne
    155c:      	mov.s	w13, v7[1]
    1560:      	add	x7, sp, #0x1e8
    1564:      	bfxil	x7, x13, #0, #3
    1568:      	ldrb	w7, [x7]
    156c:      	and	w7, w2, w7
    1570:      	stp	q4, q16, [sp, #0x370]
    1574:      	add	x21, sp, #0x370
    1578:      	ldr	s3, [x21, w13, uxtw #2]
    157c:      	tst	w7, #0x1
    1580:      	fcsel	s3, s3, s10, ne
    1584:      	mov.s	w13, v7[2]
    1588:      	add	x7, sp, #0x1e8
    158c:      	bfxil	x7, x13, #0, #3
    1590:      	ldrb	w7, [x7]
    1594:      	and	w7, w0, w7
    1598:      	stp	q4, q16, [sp, #0x350]
    159c:      	add	x21, sp, #0x350
    15a0:      	ldr	s29, [x21, w13, uxtw #2]
    15a4:      	tst	w7, #0x1
    15a8:      	fcsel	s29, s29, s10, ne
    15ac:      	mov.s	w13, v7[3]
    15b0:      	add	x7, sp, #0x1e8
    15b4:      	bfxil	x7, x13, #0, #3
    15b8:      	ldrb	w7, [x7]
    15bc:      	and	w7, w1, w7
    15c0:      	stp	q4, q16, [sp, #0x330]
    15c4:      	add	x21, sp, #0x330
    15c8:      	ldr	s7, [x21, w13, uxtw #2]
    15cc:      	tst	w7, #0x1
    15d0:      	fcsel	s7, s7, s10, ne
    15d4:      	mov.s	v2[1], v3[0]
    15d8:      	mov.s	v2[2], v29[0]
    15dc:      	mov.s	v2[3], v7[0]
    15e0:      	mov.s	v5[1], v17[0]
    15e4:      	and.16b	v3, v1, v6
    15e8:      	mov.s	v5[2], v19[0]
    15ec:      	mov.s	v5[3], v28[0]
    15f0:      	fadd.4s	v5, v4, v5
    15f4:      	fadd.4s	v6, v16, v2
    15f8:      	fmov	w13, s3
    15fc:      	add	x7, sp, #0x1e8
    1600:      	bfxil	x7, x13, #0, #3
    1604:      	ldrb	w7, [x7]
    1608:      	add	x21, sp, #0x310
    160c:      	orr	x13, x21, x13, lsl #2
    1610:      	stp	q5, q6, [sp, #0x310]
    1614:      	ldr	s2, [x13]
    1618:      	tst	w4, w7
    161c:      	mov.s	w13, v3[1]
    1620:      	add	x7, sp, #0x1e8
    1624:      	bfxil	x7, x13, #0, #3
    1628:      	ldrb	w7, [x7]
    162c:      	and	w16, w16, w7
    1630:      	fcsel	s4, s2, s10, ne
    1634:      	add	x7, sp, #0x2f0
    1638:      	orr	x13, x7, x13, lsl #2
    163c:      	stp	q5, q6, [sp, #0x2f0]
    1640:      	ldr	s2, [x13]
    1644:      	tst	w16, #0x1
    1648:      	mov.s	w13, v3[2]
    164c:      	add	x16, sp, #0x1e8
    1650:      	bfxil	x16, x13, #0, #3
    1654:      	fcsel	s7, s2, s10, ne
    1658:      	ldrb	w13, [x16]
    165c:      	and	w13, w14, w13
    1660:      	str	q5, [sp, #0x2d0]
    1664:      	tst	w13, #0x1
    1668:      	mov.s	w13, v3[3]
    166c:      	add	x14, sp, #0x1e8
    1670:      	bfxil	x14, x13, #0, #3
    1674:      	ldrb	w14, [x14]
    1678:      	and	w14, w15, w14
    167c:      	adrp	x15, 0x1000 <_llm_rows.packet_batch.blocks+0xbdc>
    1680:      	ldr	q2, [x15]
    1684:      	and.16b	v2, v0, v2
    1688:      	ldr	s3, [sp, #0x2d0]
    168c:      	fcsel	s17, s3, s10, ne
    1690:      	add	x15, sp, #0x2b0
    1694:      	orr	x13, x15, x13, lsl #2
    1698:      	stp	q5, q6, [sp, #0x2b0]
    169c:      	ldr	s3, [x13]
    16a0:      	tst	w14, #0x1
    16a4:      	fmov	w13, s2
    16a8:      	add	x14, sp, #0x1e8
    16ac:      	bfxil	x14, x13, #0, #3
    16b0:      	ldrb	w14, [x14]
    16b4:      	and	w14, w3, w14
    16b8:      	fcsel	s16, s3, s10, ne
    16bc:      	stp	q5, q6, [sp, #0x290]
    16c0:      	add	x15, sp, #0x290
    16c4:      	ldr	s3, [x15, w13, uxtw #2]
    16c8:      	tst	w14, #0x1
    16cc:      	mov.s	w13, v2[1]
    16d0:      	add	x14, sp, #0x1e8
    16d4:      	bfxil	x14, x13, #0, #3
    16d8:      	ldrb	w14, [x14]
    16dc:      	and	w14, w2, w14
    16e0:      	fcsel	s3, s3, s10, ne
    16e4:      	stp	q5, q6, [sp, #0x270]
    16e8:      	add	x15, sp, #0x270
    16ec:      	ldr	s19, [x15, w13, uxtw #2]
    16f0:      	tst	w14, #0x1
    16f4:      	mov.s	w13, v2[2]
    16f8:      	add	x14, sp, #0x1e8
    16fc:      	bfxil	x14, x13, #0, #3
    1700:      	ldrb	w14, [x14]
    1704:      	and	w14, w0, w14
    1708:      	fcsel	s19, s19, s10, ne
    170c:      	stp	q5, q6, [sp, #0x250]
    1710:      	add	x15, sp, #0x250
    1714:      	ldr	s28, [x15, w13, uxtw #2]
    1718:      	tst	w14, #0x1
    171c:      	mov.s	w13, v2[3]
    1720:      	add	x14, sp, #0x1e8
    1724:      	bfxil	x14, x13, #0, #3
    1728:      	ldrb	w14, [x14]
    172c:      	and	w14, w1, w14
    1730:      	fcsel	s2, s28, s10, ne
    1734:      	stp	q5, q6, [sp, #0x230]
    1738:      	add	x15, sp, #0x230
    173c:      	ldr	s28, [x15, w13, uxtw #2]
    1740:      	tst	w14, #0x1
    1744:      	fcsel	s28, s28, s10, ne
    1748:      	mov.s	v3[1], v19[0]
    174c:      	mov.s	v3[2], v2[0]
    1750:      	mov.s	v3[3], v28[0]
    1754:      	mov.s	v4[1], v7[0]
    1758:      	movi.4s	v2, #0x4
    175c:      	and.16b	v2, v1, v2
    1760:      	mov.s	v4[2], v17[0]
    1764:      	fmov	w13, s2
    1768:      	add	x14, sp, #0x1e8
    176c:      	orr	x14, x14, x13
    1770:      	ldrb	w14, [x14]
    1774:      	tst	w4, w14
    1778:      	mov.s	v4[3], v16[0]
    177c:      	fadd.4s	v2, v5, v4
    1780:      	fadd.4s	v3, v6, v3
    1784:      	stp	q2, q3, [sp, #0x210]
    1788:      	add	x14, sp, #0x210
    178c:      	ldr	s3, [x14, w13, uxtw #2]
    1790:      	fcsel	s3, s3, s10, ne
    1794:      	tst	w12, #0x1
    1798:      	fadd	s2, s2, s3
    179c:      	fcsel	s3, s2, s10, ne
    17a0:      	ldr	w12, [sp, #0xc0]
    17a4:      	tst	w12, #0x1
    17a8:      	fcsel	s4, s2, s10, ne
    17ac:      	ldr	w12, [sp, #0xb0]
    17b0:      	tst	w12, #0x1
    17b4:      	fcsel	s5, s2, s10, ne
    17b8:      	ldr	w12, [sp, #0xa0]
    17bc:      	tst	w12, #0x1
    17c0:      	fcsel	s6, s2, s10, ne
    17c4:      	tst	w17, #0x1
    17c8:      	fcsel	s7, s2, s10, ne
    17cc:      	ldr	w12, [sp, #0x90]
    17d0:      	tst	w12, #0x1
    17d4:      	fcsel	s16, s2, s10, ne
    17d8:      	tst	w5, #0x1
    17dc:      	fcsel	s17, s2, s10, ne
    17e0:      	tst	w6, #0x1
    17e4:      	mov.s	v3[1], v4[0]
    17e8:      	mov.s	v3[2], v5[0]
    17ec:      	mov.s	v3[3], v6[0]
    17f0:      	mov.s	v7[1], v16[0]
    17f4:      	mov.s	v7[2], v17[0]
    17f8:      	fcsel	s2, s2, s10, ne
    17fc:      	mov.s	v7[3], v2[0]
    1800:      	stp	q3, q7, [sp, #0x1f0]
    1804:      	ldr	x12, [sp, #0x88]
    1808:      	and	x12, x12, #0x7
    180c:      	add	x13, sp, #0x1f0
    1810:      	ldr	s6, [x13, x12, lsl #2]
    1814:      	add	x8, x10, x8
    1818:      	fmov	w10, s26
    181c:      	movi.2d	v16, #0000000000000000
    1820:      	movi.2d	v5, #0000000000000000
    1824:      	tbnz	w10, #0x0, 0x1b18 <_llm_rows.packet_batch.blocks+0x16f4>
    1828:      	ldr	w13, [sp, #0x128]
    182c:      	ldr	x14, [sp, #0x120]
    1830:      	tbnz	w10, #0x1, 0x1b28 <_llm_rows.packet_batch.blocks+0x1704>
    1834:      	tbnz	w10, #0x2, 0x1b34 <_llm_rows.packet_batch.blocks+0x1710>
    1838:      	tbnz	w10, #0x3, 0x1b40 <_llm_rows.packet_batch.blocks+0x171c>
    183c:      	tbnz	w10, #0x4, 0x1b4c <_llm_rows.packet_batch.blocks+0x1728>
    1840:      	tbnz	w10, #0x5, 0x1b58 <_llm_rows.packet_batch.blocks+0x1734>
    1844:      	tbnz	w10, #0x6, 0x1b64 <_llm_rows.packet_batch.blocks+0x1740>
    1848:      	tbz	w10, #0x7, 0x1854 <_llm_rows.packet_batch.blocks+0x1430>
    184c:      	add	x8, x8, #0x1c
    1850:      	ld1.s	{ v5 }[3], [x8]
    1854:      	mov	x10, #0x0               ; =0
    1858:      	fadd	s2, s6, s10
    185c:      	mov	w8, #0x4000             ; =16384
    1860:      	movk	w8, #0x44c0, lsl #16
    1864:      	fmov	s3, w8
    1868:      	fdiv	s2, s2, s3
    186c:      	mov	w8, #0xc5ac             ; =50604
    1870:      	movk	w8, #0x3727, lsl #16
    1874:      	fmov	s3, w8
    1878:      	fadd	s2, s2, s3
    187c:      	fsqrt	s2, s2
    1880:      	add	x8, x27, x11
    1884:      	ldp	q3, q4, [x8]
    1888:      	zip2.8b	v6, v8, v0
    188c:      	ushll.4s	v6, v6, #0x0
    1890:      	shl.4s	v6, v6, #0x1f
    1894:      	cmlt.4s	v6, v6, #0
    1898:      	bit.16b	v4, v5, v6
    189c:      	zip1.8b	v6, v8, v0
    18a0:      	ushll.4s	v6, v6, #0x0
    18a4:      	shl.4s	v6, v6, #0x1f
    18a8:      	cmlt.4s	v6, v6, #0
    18ac:      	bit.16b	v3, v16, v6
    18b0:      	stp	q3, q4, [x8]
    18b4:      	dup.4s	v6, v2[0]
    18b8:      	ldr	q2, [sp, #0xd0]
    18bc:      	fmov	x8, d2
    18c0:      	add	x8, x14, x8, lsl #2
    18c4:      	movi.2d	v4, #0000000000000000
    18c8:      	movi.2d	v7, #0000000000000000
    18cc:      	movi.2d	v17, #0000000000000000
    18d0:      	movi.2d	v19, #0000000000000000
    18d4:      	b	0x18f4 <_llm_rows.packet_batch.blocks+0x14d0>
    18d8:      	add.2d	v7, v7, v22
    18dc:      	add.2d	v17, v17, v23
    18e0:      	add.2d	v19, v19, v21
    18e4:      	add.2d	v4, v4, v24
    18e8:      	fmov	x10, d4
    18ec:      	cmp	x10, #0xc0
    18f0:      	b.ge	0x19d0 <_llm_rows.packet_batch.blocks+0x15ac>
    18f4:      	ldr	q2, [sp, #0x190]
    18f8:      	fmov	w11, s2
    18fc:      	lsl	x10, x10, #5
    1900:      	add	x12, x19, x10
    1904:      	ldp	q2, q28, [x12]
    1908:      	and.16b	v2, v1, v2
    190c:      	fdiv.4s	v2, v2, v6
    1910:      	add	x12, x28, x10
    1914:      	ldp	q3, q29, [x12]
    1918:      	and.16b	v3, v1, v3
    191c:      	fmul.4s	v2, v2, v3
    1920:      	add	x12, x27, x10
    1924:      	ldp	q3, q30, [x12]
    1928:      	and.16b	v3, v1, v3
    192c:      	fadd.4s	v31, v2, v3
    1930:      	add	x10, x8, x10
    1934:      	tbnz	w11, #0x0, 0x197c <_llm_rows.packet_batch.blocks+0x1558>
    1938:      	and	w11, w11, #0xff
    193c:      	tbnz	w11, #0x1, 0x1988 <_llm_rows.packet_batch.blocks+0x1564>
    1940:      	tbnz	w11, #0x2, 0x1994 <_llm_rows.packet_batch.blocks+0x1570>
    1944:      	tbz	w11, #0x3, 0x1950 <_llm_rows.packet_batch.blocks+0x152c>
    1948:      	add	x12, x10, #0xc
    194c:      	st1.s	{ v31 }[3], [x12]
    1950:      	and.16b	v2, v0, v28
    1954:      	fdiv.4s	v2, v2, v6
    1958:      	and.16b	v3, v0, v29
    195c:      	fmul.4s	v2, v2, v3
    1960:      	and.16b	v3, v0, v30
    1964:      	fadd.4s	v28, v2, v3
    1968:      	tbnz	w11, #0x4, 0x19a4 <_llm_rows.packet_batch.blocks+0x1580>
    196c:      	tbnz	w11, #0x5, 0x19ac <_llm_rows.packet_batch.blocks+0x1588>
    1970:      	tbnz	w11, #0x6, 0x19b8 <_llm_rows.packet_batch.blocks+0x1594>
    1974:      	tbz	w11, #0x7, 0x18d8 <_llm_rows.packet_batch.blocks+0x14b4>
    1978:      	b	0x19c4 <_llm_rows.packet_batch.blocks+0x15a0>
    197c:      	str	s31, [x10]
    1980:      	and	w11, w11, #0xff
    1984:      	tbz	w11, #0x1, 0x1940 <_llm_rows.packet_batch.blocks+0x151c>
    1988:      	add	x12, x10, #0x4
    198c:      	st1.s	{ v31 }[1], [x12]
    1990:      	tbz	w11, #0x2, 0x1944 <_llm_rows.packet_batch.blocks+0x1520>
    1994:      	add	x12, x10, #0x8
    1998:      	st1.s	{ v31 }[2], [x12]
    199c:      	tbnz	w11, #0x3, 0x1948 <_llm_rows.packet_batch.blocks+0x1524>
    19a0:      	b	0x1950 <_llm_rows.packet_batch.blocks+0x152c>
    19a4:      	str	s28, [x10, #0x10]
    19a8:      	tbz	w11, #0x5, 0x1970 <_llm_rows.packet_batch.blocks+0x154c>
    19ac:      	add	x12, x10, #0x14
    19b0:      	st1.s	{ v28 }[1], [x12]
    19b4:      	tbz	w11, #0x6, 0x1974 <_llm_rows.packet_batch.blocks+0x1550>
    19b8:      	add	x12, x10, #0x18
    19bc:      	st1.s	{ v28 }[2], [x12]
    19c0:      	tbz	w11, #0x7, 0x18d8 <_llm_rows.packet_batch.blocks+0x14b4>
    19c4:      	add	x10, x10, #0x1c
    19c8:      	st1.s	{ v28 }[3], [x10]
    19cc:      	b	0x18d8 <_llm_rows.packet_batch.blocks+0x14b4>
    19d0:      	fmov	w8, s26
    19d4:      	zip1.8b	v0, v8, v0
    19d8:      	ushll.4s	v0, v0, #0x0
    19dc:      	shl.4s	v0, v0, #0x1f
    19e0:      	cmlt.4s	v0, v0, #0
    19e4:      	and.16b	v0, v0, v20
    19e8:      	fdiv.4s	v0, v0, v6
    19ec:      	fmul.4s	v0, v0, v27
    19f0:      	fadd.4s	v0, v0, v16
    19f4:      	ldp	q1, q2, [sp, #0x100]
    19f8:      	ldp	q4, q3, [sp, #0xe0]
    19fc:      	stp	q2, q3, [sp, #0x1a0]
    1a00:      	stp	q4, q1, [sp, #0x1c0]
    1a04:      	and	x10, x9, #0x7
    1a08:      	add	x11, sp, #0x1a0
    1a0c:      	ldr	x10, [x11, x10, lsl #3]
    1a10:      	sub	x9, x10, x9
    1a14:      	add	x9, x14, x9, lsl #2
    1a18:      	tbnz	w8, #0x0, 0x1b74 <_llm_rows.packet_batch.blocks+0x1750>
    1a1c:      	tbnz	w8, #0x1, 0x1b7c <_llm_rows.packet_batch.blocks+0x1758>
    1a20:      	tbnz	w8, #0x2, 0x1b88 <_llm_rows.packet_batch.blocks+0x1764>
    1a24:      	tbz	w8, #0x3, 0x1a30 <_llm_rows.packet_batch.blocks+0x160c>
    1a28:      	add	x10, x9, #0xc
    1a2c:      	st1.s	{ v0 }[3], [x10]
    1a30:      	zip2.8b	v0, v8, v0
    1a34:      	ushll.4s	v0, v0, #0x0
    1a38:      	shl.4s	v0, v0, #0x1f
    1a3c:      	cmlt.4s	v0, v0, #0
    1a40:      	and.16b	v0, v0, v18
    1a44:      	fdiv.4s	v0, v0, v6
    1a48:      	fmul.4s	v0, v0, v25
    1a4c:      	fadd.4s	v0, v0, v5
    1a50:      	tbnz	w8, #0x4, 0x1b98 <_llm_rows.packet_batch.blocks+0x1774>
    1a54:      	tbnz	w8, #0x5, 0x1ba0 <_llm_rows.packet_batch.blocks+0x177c>
    1a58:      	tbnz	w8, #0x6, 0x1bac <_llm_rows.packet_batch.blocks+0x1788>
    1a5c:      	tbz	w8, #0x7, 0x4c0 <_llm_rows.packet_batch.blocks+0x9c>
    1a60:      	b	0x1bb8 <_llm_rows.packet_batch.blocks+0x1794>
    1a64:      	ldr	s21, [x8]
    1a68:      	add	x28, sp, #0x1, lsl #12  ; =0x1000
    1a6c:      	add	x28, x28, #0xea0
    1a70:      	tbz	w11, #0x1, 0x820 <_llm_rows.packet_batch.blocks+0x3fc>
    1a74:      	add	x12, x8, #0x4
    1a78:      	ld1.s	{ v21 }[1], [x12]
    1a7c:      	tbz	w11, #0x2, 0x824 <_llm_rows.packet_batch.blocks+0x400>
    1a80:      	add	x12, x8, #0x8
    1a84:      	ld1.s	{ v21 }[2], [x12]
    1a88:      	tbz	w11, #0x3, 0x828 <_llm_rows.packet_batch.blocks+0x404>
    1a8c:      	add	x12, x8, #0xc
    1a90:      	ld1.s	{ v21 }[3], [x12]
    1a94:      	tbz	w11, #0x4, 0x82c <_llm_rows.packet_batch.blocks+0x408>
    1a98:      	add	x12, x8, #0x10
    1a9c:      	ld1.s	{ v28 }[0], [x12]
    1aa0:      	tbz	w11, #0x5, 0x830 <_llm_rows.packet_batch.blocks+0x40c>
    1aa4:      	add	x12, x8, #0x14
    1aa8:      	ld1.s	{ v28 }[1], [x12]
    1aac:      	tbz	w11, #0x6, 0x834 <_llm_rows.packet_batch.blocks+0x410>
    1ab0:      	add	x12, x8, #0x18
    1ab4:      	ld1.s	{ v28 }[2], [x12]
    1ab8:      	tbnz	w11, #0x7, 0x838 <_llm_rows.packet_batch.blocks+0x414>
    1abc:      	b	0x840 <_llm_rows.packet_batch.blocks+0x41c>
    1ac0:      	ldr	s27, [x13]
    1ac4:      	tbz	w7, #0x1, 0x12ac <_llm_rows.packet_batch.blocks+0xe88>
    1ac8:      	add	x23, x13, #0x4
    1acc:      	ld1.s	{ v27 }[1], [x23]
    1ad0:      	ldr	q17, [sp, #0x190]
    1ad4:      	tbz	w7, #0x2, 0x12b4 <_llm_rows.packet_batch.blocks+0xe90>
    1ad8:      	add	x23, x13, #0x8
    1adc:      	ld1.s	{ v27 }[2], [x23]
    1ae0:      	tbz	w7, #0x3, 0x12b8 <_llm_rows.packet_batch.blocks+0xe94>
    1ae4:      	add	x23, x13, #0xc
    1ae8:      	ld1.s	{ v27 }[3], [x23]
    1aec:      	tbz	w7, #0x4, 0x12bc <_llm_rows.packet_batch.blocks+0xe98>
    1af0:      	add	x23, x13, #0x10
    1af4:      	ld1.s	{ v25 }[0], [x23]
    1af8:      	tbz	w7, #0x5, 0x12c0 <_llm_rows.packet_batch.blocks+0xe9c>
    1afc:      	add	x23, x13, #0x14
    1b00:      	ld1.s	{ v25 }[1], [x23]
    1b04:      	tbz	w7, #0x6, 0x12c4 <_llm_rows.packet_batch.blocks+0xea0>
    1b08:      	add	x23, x13, #0x18
    1b0c:      	ld1.s	{ v25 }[2], [x23]
    1b10:      	tbnz	w7, #0x7, 0x12c8 <_llm_rows.packet_batch.blocks+0xea4>
    1b14:      	b	0x12d0 <_llm_rows.packet_batch.blocks+0xeac>
    1b18:      	ldr	s16, [x8]
    1b1c:      	ldr	w13, [sp, #0x128]
    1b20:      	ldr	x14, [sp, #0x120]
    1b24:      	tbz	w10, #0x1, 0x1834 <_llm_rows.packet_batch.blocks+0x1410>
    1b28:      	add	x12, x8, #0x4
    1b2c:      	ld1.s	{ v16 }[1], [x12]
    1b30:      	tbz	w10, #0x2, 0x1838 <_llm_rows.packet_batch.blocks+0x1414>
    1b34:      	add	x12, x8, #0x8
    1b38:      	ld1.s	{ v16 }[2], [x12]
    1b3c:      	tbz	w10, #0x3, 0x183c <_llm_rows.packet_batch.blocks+0x1418>
    1b40:      	add	x12, x8, #0xc
    1b44:      	ld1.s	{ v16 }[3], [x12]
    1b48:      	tbz	w10, #0x4, 0x1840 <_llm_rows.packet_batch.blocks+0x141c>
    1b4c:      	add	x12, x8, #0x10
    1b50:      	ld1.s	{ v5 }[0], [x12]
    1b54:      	tbz	w10, #0x5, 0x1844 <_llm_rows.packet_batch.blocks+0x1420>
    1b58:      	add	x12, x8, #0x14
    1b5c:      	ld1.s	{ v5 }[1], [x12]
    1b60:      	tbz	w10, #0x6, 0x1848 <_llm_rows.packet_batch.blocks+0x1424>
    1b64:      	add	x12, x8, #0x18
    1b68:      	ld1.s	{ v5 }[2], [x12]
    1b6c:      	tbnz	w10, #0x7, 0x184c <_llm_rows.packet_batch.blocks+0x1428>
    1b70:      	b	0x1854 <_llm_rows.packet_batch.blocks+0x1430>
    1b74:      	str	s0, [x9]
    1b78:      	tbz	w8, #0x1, 0x1a20 <_llm_rows.packet_batch.blocks+0x15fc>
    1b7c:      	add	x10, x9, #0x4
    1b80:      	st1.s	{ v0 }[1], [x10]
    1b84:      	tbz	w8, #0x2, 0x1a24 <_llm_rows.packet_batch.blocks+0x1600>
    1b88:      	add	x10, x9, #0x8
    1b8c:      	st1.s	{ v0 }[2], [x10]
    1b90:      	tbnz	w8, #0x3, 0x1a28 <_llm_rows.packet_batch.blocks+0x1604>
    1b94:      	b	0x1a30 <_llm_rows.packet_batch.blocks+0x160c>
    1b98:      	str	s0, [x9, #0x10]
    1b9c:      	tbz	w8, #0x5, 0x1a58 <_llm_rows.packet_batch.blocks+0x1634>
    1ba0:      	add	x10, x9, #0x14
    1ba4:      	st1.s	{ v0 }[1], [x10]
    1ba8:      	tbz	w8, #0x6, 0x1a5c <_llm_rows.packet_batch.blocks+0x1638>
    1bac:      	add	x10, x9, #0x18
    1bb0:      	st1.s	{ v0 }[2], [x10]
    1bb4:      	tbz	w8, #0x7, 0x4c0 <_llm_rows.packet_batch.blocks+0x9c>
    1bb8:      	add	x8, x9, #0x1c
    1bbc:      	st1.s	{ v0 }[3], [x8]
    1bc0:      	b	0x4c0 <_llm_rows.packet_batch.blocks+0x9c>
    1bc4:      	add	sp, sp, #0x6, lsl #12   ; =0x6000
    1bc8:      	add	sp, sp, #0x700
    1bcc:      	ldp	x29, x30, [sp, #0x90]
    1bd0:      	ldp	x20, x19, [sp, #0x80]
    1bd4:      	ldp	x22, x21, [sp, #0x70]
    1bd8:      	ldp	x24, x23, [sp, #0x60]
    1bdc:      	ldp	x26, x25, [sp, #0x50]
    1be0:      	ldp	x28, x27, [sp, #0x40]
    1be4:      	ldp	d9, d8, [sp, #0x30]
    1be8:      	ldp	d11, d10, [sp, #0x20]
    1bec:      	ldp	d13, d12, [sp, #0x10]
    1bf0:      	ldp	d15, d14, [sp], #0xa0
    1bf4:      	ret

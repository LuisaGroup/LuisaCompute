
/private/tmp/luisa-expression-fusion.qXgTbC/capture/rope-129x768/on/object/tile_xir_w8_23511_1788930274333159_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	x28, x27, [sp, #-0x60]!
       4:      	stp	x26, x25, [sp, #0x10]
       8:      	stp	x24, x23, [sp, #0x20]
       c:      	stp	x22, x21, [sp, #0x30]
      10:      	stp	x20, x19, [sp, #0x40]
      14:      	stp	x29, x30, [sp, #0x50]
      18:      	sub	sp, sp, #0x1, lsl #12   ; =0x1000
      1c:      	sub	sp, sp, #0x8a0
      20:      	str	x0, [sp, #0x48]
      24:      	str	w3, [sp, #0x68]
      28:      	cbz	w3, 0xc54 <ltmp0+0xc54>
      2c:      	mov	w1, #0x0                ; =0
      30:      	ldp	w9, w8, [x2, #0x2c]
      34:      	stp	w8, w9, [sp, #0x60]
      38:      	ldp	w8, w9, [x2]
      3c:      	add	x27, sp, #0x1, lsl #12  ; =0x1000
      40:      	add	x27, x27, #0x2a0
      44:      	add	x28, sp, #0xca0
      48:      	add	x19, sp, #0x6a0
      4c:      	add	x26, sp, #0xa0
      50:      	adrp	x10, 0x0 <ltmp0>
      54:      	ldr	q0, [x10]
      58:      	str	q0, [sp, #0x30]
      5c:      	adrp	x10, 0x0 <ltmp0>
      60:      	ldr	q0, [x10]
      64:      	str	q0, [sp, #0x20]
      68:      	adrp	x10, 0x0 <ltmp0>
      6c:      	ldr	q0, [x10]
      70:      	str	q0, [sp, #0x10]
      74:      	ldp	w10, w11, [x2, #0x8]
      78:      	str	x2, [sp, #0x8]
      7c:      	str	x11, [sp, #0x58]
      80:      	b	0xc0 <ltmp0+0xc0>
      84:      	add	w8, w4, #0x1
      88:      	ldp	w11, w9, [sp, #0x60]
      8c:      	cmp	w8, w9
      90:      	cset	w9, eq
      94:      	csinc	w8, wzr, w4, eq
      98:      	cinc	w10, w3, eq
      9c:      	cmp	w10, w11
      a0:      	cset	w11, eq
      a4:      	ands	w11, w9, w11
      a8:      	csel	w9, wzr, w10, ne
      ac:      	add	w10, w2, w11
      b0:      	add	w1, w1, #0x1
      b4:      	ldr	w11, [sp, #0x68]
      b8:      	cmp	w1, w11
      bc:      	b.eq	0xc40 <ltmp0+0xc40>
      c0:      	stp	w10, w1, [sp, #0x70]
      c4:      	str	w9, [sp, #0x6c]
      c8:      	mov	x13, x8
      cc:      	ubfiz	x8, x8, #5, #32
      d0:      	ldr	x12, [sp, #0x58]
      d4:      	cmp	x8, x12
      d8:      	csel	x9, x8, xzr, ls
      dc:      	subs	x10, x12, x9
      e0:      	cmp	x10, #0x20
      e4:      	mov	w11, #0x20              ; =32
      e8:      	csel	x10, x10, x11, lo
      ec:      	cmp	x12, x9
      f0:      	ccmp	x8, x12, #0x2, hi
      f4:      	csel	x9, x10, xzr, ls
      f8:      	cmp	x9, #0x20
      fc:      	str	x13, [sp, #0x78]
     100:      	b.lo	0x568 <ltmp0+0x568>
     104:      	ldr	x8, [sp, #0x48]
     108:      	ldr	x9, [x8]
     10c:      	ldr	x23, [x8, #0x10]
     110:      	ldr	x20, [x8, #0x20]
     114:      	ldr	x25, [x8, #0x30]
     118:      	ubfiz	w8, w13, #2, #27
     11c:      	str	x8, [sp, #0x80]
     120:      	add	x21, x8, w8, uxtw #1
     124:      	lsl	x24, x21, #10
     128:      	str	x9, [sp, #0x50]
     12c:      	add	x22, x9, x24
     130:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     134:      	add	x0, x0, #0x2a0
     138:      	mov	x1, x22
     13c:      	mov	w2, #0x600              ; =1536
     140:      	bl	0x140 <ltmp0+0x140>
     144:      	add	x0, sp, #0xca0
     148:      	add	x1, x22, #0x600
     14c:      	mov	w2, #0x600              ; =1536
     150:      	bl	0x150 <ltmp0+0x150>
     154:      	lsl	x21, x21, #9
     158:      	add	x0, sp, #0x6a0
     15c:      	str	x23, [sp, #0x88]
     160:      	add	x1, x23, x21
     164:      	mov	w2, #0x600              ; =1536
     168:      	bl	0x168 <ltmp0+0x168>
     16c:      	add	x0, sp, #0xa0
     170:      	mov	x23, x20
     174:      	add	x1, x20, x21
     178:      	mov	w2, #0x600              ; =1536
     17c:      	bl	0x17c <ltmp0+0x17c>
     180:      	mov	x9, #0x0                ; =0
     184:      	str	x25, [sp, #0x90]
     188:      	add	x8, x25, x24
     18c:      	add	x10, x27, x9
     190:      	ldp	q0, q1, [x10]
     194:      	add	x10, x19, x9
     198:      	ldp	q2, q3, [x10]
     19c:      	fmul.4s	v1, v1, v3
     1a0:      	fmul.4s	v0, v0, v2
     1a4:      	add	x10, x28, x9
     1a8:      	ldp	q2, q3, [x10]
     1ac:      	add	x10, x26, x9
     1b0:      	ldp	q4, q5, [x10]
     1b4:      	fmul.4s	v3, v3, v5
     1b8:      	fmul.4s	v2, v2, v4
     1bc:      	fsub.4s	v0, v0, v2
     1c0:      	fsub.4s	v1, v1, v3
     1c4:      	add	x10, x8, x9
     1c8:      	stp	q0, q1, [x10]
     1cc:      	add	x9, x9, #0x20
     1d0:      	cmp	x9, #0x600
     1d4:      	b.ne	0x18c <ltmp0+0x18c>
     1d8:      	mov	x9, #0x0                ; =0
     1dc:      	add	x8, x8, #0x600
     1e0:      	add	x10, x27, x9
     1e4:      	ldp	q0, q1, [x10]
     1e8:      	add	x10, x26, x9
     1ec:      	ldp	q2, q3, [x10]
     1f0:      	fmul.4s	v1, v1, v3
     1f4:      	fmul.4s	v0, v0, v2
     1f8:      	add	x10, x28, x9
     1fc:      	ldp	q2, q3, [x10]
     200:      	add	x10, x19, x9
     204:      	ldp	q4, q5, [x10]
     208:      	fmul.4s	v3, v3, v5
     20c:      	fmul.4s	v2, v2, v4
     210:      	fadd.4s	v0, v0, v2
     214:      	fadd.4s	v1, v1, v3
     218:      	add	x10, x8, x9
     21c:      	stp	q0, q1, [x10]
     220:      	add	x9, x9, #0x20
     224:      	cmp	x9, #0x600
     228:      	b.ne	0x1e0 <ltmp0+0x1e0>
     22c:      	ldr	x8, [sp, #0x80]
     230:      	orr	w8, w8, #0x1
     234:      	add	x21, x8, w8, uxtw #1
     238:      	lsl	x24, x21, #10
     23c:      	ldr	x20, [sp, #0x50]
     240:      	add	x22, x20, x24
     244:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     248:      	add	x0, x0, #0x2a0
     24c:      	mov	x1, x22
     250:      	mov	w2, #0x600              ; =1536
     254:      	bl	0x254 <ltmp0+0x254>
     258:      	add	x0, sp, #0xca0
     25c:      	add	x1, x22, #0x600
     260:      	mov	w2, #0x600              ; =1536
     264:      	bl	0x264 <ltmp0+0x264>
     268:      	lsl	x21, x21, #9
     26c:      	add	x0, sp, #0x6a0
     270:      	ldr	x8, [sp, #0x88]
     274:      	add	x1, x8, x21
     278:      	mov	w2, #0x600              ; =1536
     27c:      	bl	0x27c <ltmp0+0x27c>
     280:      	add	x0, sp, #0xa0
     284:      	mov	x25, x23
     288:      	add	x1, x23, x21
     28c:      	mov	w2, #0x600              ; =1536
     290:      	bl	0x290 <ltmp0+0x290>
     294:      	mov	x9, #0x0                ; =0
     298:      	ldr	x8, [sp, #0x90]
     29c:      	add	x8, x8, x24
     2a0:      	add	x10, x27, x9
     2a4:      	ldp	q0, q1, [x10]
     2a8:      	add	x10, x19, x9
     2ac:      	ldp	q2, q3, [x10]
     2b0:      	fmul.4s	v1, v1, v3
     2b4:      	fmul.4s	v0, v0, v2
     2b8:      	add	x10, x28, x9
     2bc:      	ldp	q2, q3, [x10]
     2c0:      	add	x10, x26, x9
     2c4:      	ldp	q4, q5, [x10]
     2c8:      	fmul.4s	v3, v3, v5
     2cc:      	fmul.4s	v2, v2, v4
     2d0:      	fsub.4s	v0, v0, v2
     2d4:      	fsub.4s	v1, v1, v3
     2d8:      	add	x10, x8, x9
     2dc:      	stp	q0, q1, [x10]
     2e0:      	add	x9, x9, #0x20
     2e4:      	cmp	x9, #0x600
     2e8:      	b.ne	0x2a0 <ltmp0+0x2a0>
     2ec:      	mov	x9, #0x0                ; =0
     2f0:      	add	x8, x8, #0x600
     2f4:      	add	x10, x27, x9
     2f8:      	ldp	q0, q1, [x10]
     2fc:      	add	x10, x26, x9
     300:      	ldp	q2, q3, [x10]
     304:      	fmul.4s	v1, v1, v3
     308:      	fmul.4s	v0, v0, v2
     30c:      	add	x10, x28, x9
     310:      	ldp	q2, q3, [x10]
     314:      	add	x10, x19, x9
     318:      	ldp	q4, q5, [x10]
     31c:      	fmul.4s	v3, v3, v5
     320:      	fmul.4s	v2, v2, v4
     324:      	fadd.4s	v0, v0, v2
     328:      	fadd.4s	v1, v1, v3
     32c:      	add	x10, x8, x9
     330:      	stp	q0, q1, [x10]
     334:      	add	x9, x9, #0x20
     338:      	cmp	x9, #0x600
     33c:      	b.ne	0x2f4 <ltmp0+0x2f4>
     340:      	ldr	x8, [sp, #0x80]
     344:      	orr	w8, w8, #0x2
     348:      	add	x21, x8, w8, uxtw #1
     34c:      	lsl	x24, x21, #10
     350:      	add	x22, x20, x24
     354:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     358:      	add	x0, x0, #0x2a0
     35c:      	mov	x1, x22
     360:      	mov	w2, #0x600              ; =1536
     364:      	bl	0x364 <ltmp0+0x364>
     368:      	add	x0, sp, #0xca0
     36c:      	add	x1, x22, #0x600
     370:      	mov	w2, #0x600              ; =1536
     374:      	bl	0x374 <ltmp0+0x374>
     378:      	lsl	x21, x21, #9
     37c:      	add	x0, sp, #0x6a0
     380:      	ldr	x8, [sp, #0x88]
     384:      	add	x1, x8, x21
     388:      	mov	w2, #0x600              ; =1536
     38c:      	bl	0x38c <ltmp0+0x38c>
     390:      	add	x0, sp, #0xa0
     394:      	add	x1, x25, x21
     398:      	mov	w2, #0x600              ; =1536
     39c:      	bl	0x39c <ltmp0+0x39c>
     3a0:      	mov	x9, #0x0                ; =0
     3a4:      	ldr	x8, [sp, #0x90]
     3a8:      	add	x8, x8, x24
     3ac:      	add	x10, x27, x9
     3b0:      	ldp	q0, q1, [x10]
     3b4:      	add	x10, x19, x9
     3b8:      	ldp	q2, q3, [x10]
     3bc:      	fmul.4s	v1, v1, v3
     3c0:      	fmul.4s	v0, v0, v2
     3c4:      	add	x10, x28, x9
     3c8:      	ldp	q2, q3, [x10]
     3cc:      	add	x10, x26, x9
     3d0:      	ldp	q4, q5, [x10]
     3d4:      	fmul.4s	v3, v3, v5
     3d8:      	fmul.4s	v2, v2, v4
     3dc:      	fsub.4s	v0, v0, v2
     3e0:      	fsub.4s	v1, v1, v3
     3e4:      	add	x10, x8, x9
     3e8:      	stp	q0, q1, [x10]
     3ec:      	add	x9, x9, #0x20
     3f0:      	cmp	x9, #0x600
     3f4:      	b.ne	0x3ac <ltmp0+0x3ac>
     3f8:      	mov	x9, #0x0                ; =0
     3fc:      	add	x8, x8, #0x600
     400:      	add	x10, x27, x9
     404:      	ldp	q0, q1, [x10]
     408:      	add	x10, x26, x9
     40c:      	ldp	q2, q3, [x10]
     410:      	fmul.4s	v1, v1, v3
     414:      	fmul.4s	v0, v0, v2
     418:      	add	x10, x28, x9
     41c:      	ldp	q2, q3, [x10]
     420:      	add	x10, x19, x9
     424:      	ldp	q4, q5, [x10]
     428:      	fmul.4s	v3, v3, v5
     42c:      	fmul.4s	v2, v2, v4
     430:      	fadd.4s	v0, v0, v2
     434:      	fadd.4s	v1, v1, v3
     438:      	add	x10, x8, x9
     43c:      	stp	q0, q1, [x10]
     440:      	add	x9, x9, #0x20
     444:      	cmp	x9, #0x600
     448:      	b.ne	0x400 <ltmp0+0x400>
     44c:      	ldr	x8, [sp, #0x80]
     450:      	orr	w8, w8, #0x3
     454:      	add	x21, x8, w8, uxtw #1
     458:      	lsl	x23, x21, #10
     45c:      	add	x22, x20, x23
     460:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     464:      	add	x0, x0, #0x2a0
     468:      	mov	x1, x22
     46c:      	mov	w2, #0x600              ; =1536
     470:      	bl	0x470 <ltmp0+0x470>
     474:      	add	x0, sp, #0xca0
     478:      	add	x1, x22, #0x600
     47c:      	mov	w2, #0x600              ; =1536
     480:      	bl	0x480 <ltmp0+0x480>
     484:      	lsl	x20, x21, #9
     488:      	add	x0, sp, #0x6a0
     48c:      	ldr	x8, [sp, #0x88]
     490:      	add	x1, x8, x20
     494:      	mov	w2, #0x600              ; =1536
     498:      	bl	0x498 <ltmp0+0x498>
     49c:      	add	x0, sp, #0xa0
     4a0:      	add	x1, x25, x20
     4a4:      	mov	w2, #0x600              ; =1536
     4a8:      	bl	0x4a8 <ltmp0+0x4a8>
     4ac:      	mov	x9, #0x0                ; =0
     4b0:      	ldr	x8, [sp, #0x90]
     4b4:      	add	x8, x8, x23
     4b8:      	add	x10, x27, x9
     4bc:      	ldp	q0, q1, [x10]
     4c0:      	add	x10, x19, x9
     4c4:      	ldp	q2, q3, [x10]
     4c8:      	fmul.4s	v1, v1, v3
     4cc:      	fmul.4s	v0, v0, v2
     4d0:      	add	x10, x28, x9
     4d4:      	ldp	q2, q3, [x10]
     4d8:      	add	x10, x26, x9
     4dc:      	ldp	q4, q5, [x10]
     4e0:      	fmul.4s	v3, v3, v5
     4e4:      	fmul.4s	v2, v2, v4
     4e8:      	fsub.4s	v0, v0, v2
     4ec:      	fsub.4s	v1, v1, v3
     4f0:      	add	x10, x8, x9
     4f4:      	stp	q0, q1, [x10]
     4f8:      	add	x9, x9, #0x20
     4fc:      	cmp	x9, #0x600
     500:      	b.ne	0x4b8 <ltmp0+0x4b8>
     504:      	mov	x9, #0x0                ; =0
     508:      	add	x8, x8, #0x600
     50c:      	ldp	w2, w1, [sp, #0x70]
     510:      	ldr	w3, [sp, #0x6c]
     514:      	ldr	x4, [sp, #0x78]
     518:      	add	x10, x27, x9
     51c:      	ldp	q0, q1, [x10]
     520:      	add	x10, x26, x9
     524:      	ldp	q2, q3, [x10]
     528:      	fmul.4s	v1, v1, v3
     52c:      	fmul.4s	v0, v0, v2
     530:      	add	x10, x28, x9
     534:      	ldp	q2, q3, [x10]
     538:      	add	x10, x19, x9
     53c:      	ldp	q4, q5, [x10]
     540:      	fmul.4s	v3, v3, v5
     544:      	fmul.4s	v2, v2, v4
     548:      	fadd.4s	v0, v0, v2
     54c:      	fadd.4s	v1, v1, v3
     550:      	add	x10, x8, x9
     554:      	stp	q0, q1, [x10]
     558:      	add	x9, x9, #0x20
     55c:      	cmp	x9, #0x600
     560:      	b.ne	0x518 <ltmp0+0x518>
     564:      	b	0x84 <ltmp0+0x84>
     568:      	lsr	x8, x9, #3
     56c:      	str	x8, [sp, #0x90]
     570:      	str	x9, [sp, #0x50]
     574:      	cmp	x9, #0x8
     578:      	b.lo	0x6c8 <ltmp0+0x6c8>
     57c:      	mov	x23, #0x0               ; =0
     580:      	ldr	x8, [sp, #0x48]
     584:      	ldr	x10, [x8]
     588:      	ldr	x9, [x8, #0x10]
     58c:      	stp	x9, x10, [sp, #0x80]
     590:      	ldr	x21, [x8, #0x20]
     594:      	ldr	x8, [x8, #0x30]
     598:      	ldr	x9, [sp, #0x78]
     59c:      	lsl	w20, w9, #2
     5a0:      	and	x9, x9, #0x7ffffff
     5a4:      	mov	w10, #0x3000            ; =12288
     5a8:      	umaddl	x24, w9, w10, x8
     5ac:      	add	w8, w23, w20
     5b0:      	and	x25, x8, #0x1fffffff
     5b4:      	mov	w8, #0xc00              ; =3072
     5b8:      	ldr	x9, [sp, #0x88]
     5bc:      	umaddl	x22, w25, w8, x9
     5c0:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     5c4:      	add	x0, x0, #0x2a0
     5c8:      	mov	x1, x22
     5cc:      	mov	w2, #0x600              ; =1536
     5d0:      	bl	0x5d0 <ltmp0+0x5d0>
     5d4:      	add	x0, sp, #0xca0
     5d8:      	add	x1, x22, #0x600
     5dc:      	mov	w2, #0x600              ; =1536
     5e0:      	bl	0x5e0 <ltmp0+0x5e0>
     5e4:      	add	x8, x25, x25, lsl #1
     5e8:      	lsl	x22, x8, #9
     5ec:      	add	x0, sp, #0x6a0
     5f0:      	ldr	x8, [sp, #0x80]
     5f4:      	add	x1, x8, x22
     5f8:      	mov	w2, #0x600              ; =1536
     5fc:      	bl	0x5fc <ltmp0+0x5fc>
     600:      	add	x0, sp, #0xa0
     604:      	add	x1, x21, x22
     608:      	mov	w2, #0x600              ; =1536
     60c:      	bl	0x60c <ltmp0+0x60c>
     610:      	mov	x8, #0x0                ; =0
     614:      	add	x9, x27, x8
     618:      	ldp	q0, q1, [x9]
     61c:      	add	x9, x19, x8
     620:      	ldp	q2, q3, [x9]
     624:      	fmul.4s	v1, v1, v3
     628:      	fmul.4s	v0, v0, v2
     62c:      	add	x9, x28, x8
     630:      	ldp	q2, q3, [x9]
     634:      	add	x9, x26, x8
     638:      	ldp	q4, q5, [x9]
     63c:      	fmul.4s	v3, v3, v5
     640:      	fmul.4s	v2, v2, v4
     644:      	fsub.4s	v0, v0, v2
     648:      	fsub.4s	v1, v1, v3
     64c:      	add	x9, x24, x8
     650:      	stp	q0, q1, [x9]
     654:      	add	x8, x8, #0x20
     658:      	cmp	x8, #0x600
     65c:      	b.ne	0x614 <ltmp0+0x614>
     660:      	mov	x8, #0x0                ; =0
     664:      	add	x9, x27, x8
     668:      	ldp	q0, q1, [x9]
     66c:      	add	x9, x26, x8
     670:      	ldp	q2, q3, [x9]
     674:      	fmul.4s	v1, v1, v3
     678:      	fmul.4s	v0, v0, v2
     67c:      	add	x9, x28, x8
     680:      	ldp	q2, q3, [x9]
     684:      	add	x9, x19, x8
     688:      	ldp	q4, q5, [x9]
     68c:      	fmul.4s	v3, v3, v5
     690:      	fmul.4s	v2, v2, v4
     694:      	fadd.4s	v0, v0, v2
     698:      	fadd.4s	v1, v1, v3
     69c:      	add	x9, x24, x8
     6a0:      	str	q1, [x9, #0x610]
     6a4:      	str	q0, [x9, #0x600]
     6a8:      	add	x8, x8, #0x20
     6ac:      	cmp	x8, #0x600
     6b0:      	b.ne	0x664 <ltmp0+0x664>
     6b4:      	add	x23, x23, #0x1
     6b8:      	add	x24, x24, #0xc00
     6bc:      	ldr	x8, [sp, #0x90]
     6c0:      	cmp	x23, x8
     6c4:      	b.ne	0x5ac <ltmp0+0x5ac>
     6c8:      	ldr	x8, [sp, #0x50]
     6cc:      	and	w8, w8, #0x7
     6d0:      	ldp	w2, w1, [sp, #0x70]
     6d4:      	ldr	w3, [sp, #0x6c]
     6d8:      	ldr	x4, [sp, #0x78]
     6dc:      	cbz	w8, 0x84 <ltmp0+0x84>
     6e0:      	dup.4s	v1, w8
     6e4:      	ldp	q0, q2, [sp, #0x20]
     6e8:      	cmhi.4s	v0, v1, v0
     6ec:      	cmhi.4s	v1, v1, v2
     6f0:      	uzp1.8h	v2, v1, v0
     6f4:      	umaxv.8h	h3, v2
     6f8:      	fmov	w8, s3
     6fc:      	tbz	w8, #0x0, 0x84 <ltmp0+0x84>
     700:      	mov	x13, #0x0               ; =0
     704:      	ldr	x9, [sp, #0x48]
     708:      	ldr	x11, [x9, #0x10]
     70c:      	ldr	x10, [x9, #0x20]
     710:      	ldr	x8, [x9, #0x30]
     714:      	ldr	x14, [x9]
     718:      	ubfiz	w9, w4, #2, #27
     71c:      	ldr	x12, [sp, #0x90]
     720:      	orr	w9, w9, w12
     724:      	fmov	s3, w9
     728:      	and.16b	v3, v1, v3
     72c:      	fmov	w12, s3
     730:      	add	x9, x12, w12, uxtw #1
     734:      	lsl	x9, x9, #10
     738:      	add	x14, x14, x9
     73c:      	ldr	q3, [sp, #0x10]
     740:      	and.16b	v2, v2, v3
     744:      	addv.8h	h2, v2
     748:      	fmov	w15, s2
     74c:      	b	0x770 <ltmp0+0x770>
     750:      	add	x16, x27, x13
     754:      	ldp	q5, q6, [x16]
     758:      	bif.16b	v4, v6, v0
     75c:      	bif.16b	v3, v5, v1
     760:      	stp	q3, q4, [x16]
     764:      	add	x13, x13, #0x20
     768:      	cmp	x13, #0x600
     76c:      	b.eq	0x804 <ltmp0+0x804>
     770:      	add	x16, x14, x13
     774:      	movi.2d	v3, #0000000000000000
     778:      	movi.2d	v4, #0000000000000000
     77c:      	tbnz	w15, #0x0, 0x7a4 <ltmp0+0x7a4>
     780:      	and	w17, w15, #0xff
     784:      	tbnz	w17, #0x1, 0x7b0 <ltmp0+0x7b0>
     788:      	tbnz	w17, #0x2, 0x7bc <ltmp0+0x7bc>
     78c:      	tbnz	w17, #0x3, 0x7c8 <ltmp0+0x7c8>
     790:      	tbnz	w17, #0x4, 0x7d4 <ltmp0+0x7d4>
     794:      	tbnz	w17, #0x5, 0x7e0 <ltmp0+0x7e0>
     798:      	tbnz	w17, #0x6, 0x7ec <ltmp0+0x7ec>
     79c:      	tbz	w17, #0x7, 0x750 <ltmp0+0x750>
     7a0:      	b	0x7f8 <ltmp0+0x7f8>
     7a4:      	ldr	s3, [x16]
     7a8:      	and	w17, w15, #0xff
     7ac:      	tbz	w17, #0x1, 0x788 <ltmp0+0x788>
     7b0:      	add	x0, x16, #0x4
     7b4:      	ld1.s	{ v3 }[1], [x0]
     7b8:      	tbz	w17, #0x2, 0x78c <ltmp0+0x78c>
     7bc:      	add	x0, x16, #0x8
     7c0:      	ld1.s	{ v3 }[2], [x0]
     7c4:      	tbz	w17, #0x3, 0x790 <ltmp0+0x790>
     7c8:      	add	x0, x16, #0xc
     7cc:      	ld1.s	{ v3 }[3], [x0]
     7d0:      	tbz	w17, #0x4, 0x794 <ltmp0+0x794>
     7d4:      	add	x0, x16, #0x10
     7d8:      	ld1.s	{ v4 }[0], [x0]
     7dc:      	tbz	w17, #0x5, 0x798 <ltmp0+0x798>
     7e0:      	add	x0, x16, #0x14
     7e4:      	ld1.s	{ v4 }[1], [x0]
     7e8:      	tbz	w17, #0x6, 0x79c <ltmp0+0x79c>
     7ec:      	add	x0, x16, #0x18
     7f0:      	ld1.s	{ v4 }[2], [x0]
     7f4:      	tbz	w17, #0x7, 0x750 <ltmp0+0x750>
     7f8:      	add	x16, x16, #0x1c
     7fc:      	ld1.s	{ v4 }[3], [x16]
     800:      	b	0x750 <ltmp0+0x750>
     804:      	mov	x13, #0x0               ; =0
     808:      	add	x14, x14, #0x600
     80c:      	b	0x830 <ltmp0+0x830>
     810:      	add	x15, x28, x13
     814:      	ldp	q5, q6, [x15]
     818:      	bif.16b	v4, v6, v0
     81c:      	bif.16b	v3, v5, v1
     820:      	stp	q3, q4, [x15]
     824:      	add	x13, x13, #0x20
     828:      	cmp	x13, #0x600
     82c:      	b.eq	0x8c8 <ltmp0+0x8c8>
     830:      	fmov	w16, s2
     834:      	add	x15, x14, x13
     838:      	movi.2d	v3, #0000000000000000
     83c:      	movi.2d	v4, #0000000000000000
     840:      	tbnz	w16, #0x0, 0x868 <ltmp0+0x868>
     844:      	and	w16, w16, #0xff
     848:      	tbnz	w16, #0x1, 0x874 <ltmp0+0x874>
     84c:      	tbnz	w16, #0x2, 0x880 <ltmp0+0x880>
     850:      	tbnz	w16, #0x3, 0x88c <ltmp0+0x88c>
     854:      	tbnz	w16, #0x4, 0x898 <ltmp0+0x898>
     858:      	tbnz	w16, #0x5, 0x8a4 <ltmp0+0x8a4>
     85c:      	tbnz	w16, #0x6, 0x8b0 <ltmp0+0x8b0>
     860:      	tbz	w16, #0x7, 0x810 <ltmp0+0x810>
     864:      	b	0x8bc <ltmp0+0x8bc>
     868:      	ldr	s3, [x15]
     86c:      	and	w16, w16, #0xff
     870:      	tbz	w16, #0x1, 0x84c <ltmp0+0x84c>
     874:      	add	x17, x15, #0x4
     878:      	ld1.s	{ v3 }[1], [x17]
     87c:      	tbz	w16, #0x2, 0x850 <ltmp0+0x850>
     880:      	add	x17, x15, #0x8
     884:      	ld1.s	{ v3 }[2], [x17]
     888:      	tbz	w16, #0x3, 0x854 <ltmp0+0x854>
     88c:      	add	x17, x15, #0xc
     890:      	ld1.s	{ v3 }[3], [x17]
     894:      	tbz	w16, #0x4, 0x858 <ltmp0+0x858>
     898:      	add	x17, x15, #0x10
     89c:      	ld1.s	{ v4 }[0], [x17]
     8a0:      	tbz	w16, #0x5, 0x85c <ltmp0+0x85c>
     8a4:      	add	x17, x15, #0x14
     8a8:      	ld1.s	{ v4 }[1], [x17]
     8ac:      	tbz	w16, #0x6, 0x860 <ltmp0+0x860>
     8b0:      	add	x17, x15, #0x18
     8b4:      	ld1.s	{ v4 }[2], [x17]
     8b8:      	tbz	w16, #0x7, 0x810 <ltmp0+0x810>
     8bc:      	add	x15, x15, #0x1c
     8c0:      	ld1.s	{ v4 }[3], [x15]
     8c4:      	b	0x810 <ltmp0+0x810>
     8c8:      	mov	x13, #0x0               ; =0
     8cc:      	add	x12, x12, x12, lsl #1
     8d0:      	lsl	x12, x12, #9
     8d4:      	add	x11, x11, x12
     8d8:      	b	0x8fc <ltmp0+0x8fc>
     8dc:      	add	x14, x19, x13
     8e0:      	ldp	q5, q6, [x14]
     8e4:      	bif.16b	v4, v6, v0
     8e8:      	bif.16b	v3, v5, v1
     8ec:      	stp	q3, q4, [x14]
     8f0:      	add	x13, x13, #0x20
     8f4:      	cmp	x13, #0x600
     8f8:      	b.eq	0x994 <ltmp0+0x994>
     8fc:      	fmov	w15, s2
     900:      	add	x14, x11, x13
     904:      	movi.2d	v3, #0000000000000000
     908:      	movi.2d	v4, #0000000000000000
     90c:      	tbnz	w15, #0x0, 0x934 <ltmp0+0x934>
     910:      	and	w15, w15, #0xff
     914:      	tbnz	w15, #0x1, 0x940 <ltmp0+0x940>
     918:      	tbnz	w15, #0x2, 0x94c <ltmp0+0x94c>
     91c:      	tbnz	w15, #0x3, 0x958 <ltmp0+0x958>
     920:      	tbnz	w15, #0x4, 0x964 <ltmp0+0x964>
     924:      	tbnz	w15, #0x5, 0x970 <ltmp0+0x970>
     928:      	tbnz	w15, #0x6, 0x97c <ltmp0+0x97c>
     92c:      	tbz	w15, #0x7, 0x8dc <ltmp0+0x8dc>
     930:      	b	0x988 <ltmp0+0x988>
     934:      	ldr	s3, [x14]
     938:      	and	w15, w15, #0xff
     93c:      	tbz	w15, #0x1, 0x918 <ltmp0+0x918>
     940:      	add	x16, x14, #0x4
     944:      	ld1.s	{ v3 }[1], [x16]
     948:      	tbz	w15, #0x2, 0x91c <ltmp0+0x91c>
     94c:      	add	x16, x14, #0x8
     950:      	ld1.s	{ v3 }[2], [x16]
     954:      	tbz	w15, #0x3, 0x920 <ltmp0+0x920>
     958:      	add	x16, x14, #0xc
     95c:      	ld1.s	{ v3 }[3], [x16]
     960:      	tbz	w15, #0x4, 0x924 <ltmp0+0x924>
     964:      	add	x16, x14, #0x10
     968:      	ld1.s	{ v4 }[0], [x16]
     96c:      	tbz	w15, #0x5, 0x928 <ltmp0+0x928>
     970:      	add	x16, x14, #0x14
     974:      	ld1.s	{ v4 }[1], [x16]
     978:      	tbz	w15, #0x6, 0x92c <ltmp0+0x92c>
     97c:      	add	x16, x14, #0x18
     980:      	ld1.s	{ v4 }[2], [x16]
     984:      	tbz	w15, #0x7, 0x8dc <ltmp0+0x8dc>
     988:      	add	x14, x14, #0x1c
     98c:      	ld1.s	{ v4 }[3], [x14]
     990:      	b	0x8dc <ltmp0+0x8dc>
     994:      	mov	x11, #0x0               ; =0
     998:      	add	x10, x10, x12
     99c:      	b	0x9c0 <ltmp0+0x9c0>
     9a0:      	add	x12, x26, x11
     9a4:      	ldp	q5, q6, [x12]
     9a8:      	bif.16b	v4, v6, v0
     9ac:      	bif.16b	v3, v5, v1
     9b0:      	stp	q3, q4, [x12]
     9b4:      	add	x11, x11, #0x20
     9b8:      	cmp	x11, #0x600
     9bc:      	b.eq	0xa58 <ltmp0+0xa58>
     9c0:      	fmov	w13, s2
     9c4:      	add	x12, x10, x11
     9c8:      	movi.2d	v3, #0000000000000000
     9cc:      	movi.2d	v4, #0000000000000000
     9d0:      	tbnz	w13, #0x0, 0x9f8 <ltmp0+0x9f8>
     9d4:      	and	w13, w13, #0xff
     9d8:      	tbnz	w13, #0x1, 0xa04 <ltmp0+0xa04>
     9dc:      	tbnz	w13, #0x2, 0xa10 <ltmp0+0xa10>
     9e0:      	tbnz	w13, #0x3, 0xa1c <ltmp0+0xa1c>
     9e4:      	tbnz	w13, #0x4, 0xa28 <ltmp0+0xa28>
     9e8:      	tbnz	w13, #0x5, 0xa34 <ltmp0+0xa34>
     9ec:      	tbnz	w13, #0x6, 0xa40 <ltmp0+0xa40>
     9f0:      	tbz	w13, #0x7, 0x9a0 <ltmp0+0x9a0>
     9f4:      	b	0xa4c <ltmp0+0xa4c>
     9f8:      	ldr	s3, [x12]
     9fc:      	and	w13, w13, #0xff
     a00:      	tbz	w13, #0x1, 0x9dc <ltmp0+0x9dc>
     a04:      	add	x14, x12, #0x4
     a08:      	ld1.s	{ v3 }[1], [x14]
     a0c:      	tbz	w13, #0x2, 0x9e0 <ltmp0+0x9e0>
     a10:      	add	x14, x12, #0x8
     a14:      	ld1.s	{ v3 }[2], [x14]
     a18:      	tbz	w13, #0x3, 0x9e4 <ltmp0+0x9e4>
     a1c:      	add	x14, x12, #0xc
     a20:      	ld1.s	{ v3 }[3], [x14]
     a24:      	tbz	w13, #0x4, 0x9e8 <ltmp0+0x9e8>
     a28:      	add	x14, x12, #0x10
     a2c:      	ld1.s	{ v4 }[0], [x14]
     a30:      	tbz	w13, #0x5, 0x9ec <ltmp0+0x9ec>
     a34:      	add	x14, x12, #0x14
     a38:      	ld1.s	{ v4 }[1], [x14]
     a3c:      	tbz	w13, #0x6, 0x9f0 <ltmp0+0x9f0>
     a40:      	add	x14, x12, #0x18
     a44:      	ld1.s	{ v4 }[2], [x14]
     a48:      	tbz	w13, #0x7, 0x9a0 <ltmp0+0x9a0>
     a4c:      	add	x12, x12, #0x1c
     a50:      	ld1.s	{ v4 }[3], [x12]
     a54:      	b	0x9a0 <ltmp0+0x9a0>
     a58:      	mov	x10, #0x0               ; =0
     a5c:      	add	x8, x8, x9
     a60:      	b	0xa70 <ltmp0+0xa70>
     a64:      	add	x10, x10, #0x20
     a68:      	cmp	x10, #0x600
     a6c:      	b.eq	0xb4c <ltmp0+0xb4c>
     a70:      	fmov	w11, s2
     a74:      	add	x9, x27, x10
     a78:      	ldp	q5, q3, [x9]
     a7c:      	add	x9, x19, x10
     a80:      	ldp	q6, q4, [x9]
     a84:      	fmul.4s	v7, v5, v6
     a88:      	add	x9, x28, x10
     a8c:      	ldp	q16, q5, [x9]
     a90:      	add	x9, x26, x10
     a94:      	ldp	q17, q6, [x9]
     a98:      	fmul.4s	v16, v16, v17
     a9c:      	fsub.4s	v7, v7, v16
     aa0:      	and.16b	v7, v1, v7
     aa4:      	add	x9, x8, x10
     aa8:      	tbnz	w11, #0x0, 0xae0 <ltmp0+0xae0>
     aac:      	and	w11, w11, #0xff
     ab0:      	tbnz	w11, #0x1, 0xaec <ltmp0+0xaec>
     ab4:      	tbnz	w11, #0x2, 0xaf8 <ltmp0+0xaf8>
     ab8:      	tbnz	w11, #0x3, 0xb04 <ltmp0+0xb04>
     abc:      	fmul.4s	v3, v3, v4
     ac0:      	fmul.4s	v4, v5, v6
     ac4:      	fsub.4s	v3, v3, v4
     ac8:      	and.16b	v3, v0, v3
     acc:      	tbnz	w11, #0x4, 0xb20 <ltmp0+0xb20>
     ad0:      	tbnz	w11, #0x5, 0xb28 <ltmp0+0xb28>
     ad4:      	tbnz	w11, #0x6, 0xb34 <ltmp0+0xb34>
     ad8:      	tbz	w11, #0x7, 0xa64 <ltmp0+0xa64>
     adc:      	b	0xb40 <ltmp0+0xb40>
     ae0:      	str	s7, [x9]
     ae4:      	and	w11, w11, #0xff
     ae8:      	tbz	w11, #0x1, 0xab4 <ltmp0+0xab4>
     aec:      	add	x12, x9, #0x4
     af0:      	st1.s	{ v7 }[1], [x12]
     af4:      	tbz	w11, #0x2, 0xab8 <ltmp0+0xab8>
     af8:      	add	x12, x9, #0x8
     afc:      	st1.s	{ v7 }[2], [x12]
     b00:      	tbz	w11, #0x3, 0xabc <ltmp0+0xabc>
     b04:      	add	x12, x9, #0xc
     b08:      	st1.s	{ v7 }[3], [x12]
     b0c:      	fmul.4s	v3, v3, v4
     b10:      	fmul.4s	v4, v5, v6
     b14:      	fsub.4s	v3, v3, v4
     b18:      	and.16b	v3, v0, v3
     b1c:      	tbz	w11, #0x4, 0xad0 <ltmp0+0xad0>
     b20:      	str	s3, [x9, #0x10]
     b24:      	tbz	w11, #0x5, 0xad4 <ltmp0+0xad4>
     b28:      	add	x12, x9, #0x14
     b2c:      	st1.s	{ v3 }[1], [x12]
     b30:      	tbz	w11, #0x6, 0xad8 <ltmp0+0xad8>
     b34:      	add	x12, x9, #0x18
     b38:      	st1.s	{ v3 }[2], [x12]
     b3c:      	tbz	w11, #0x7, 0xa64 <ltmp0+0xa64>
     b40:      	add	x9, x9, #0x1c
     b44:      	st1.s	{ v3 }[3], [x9]
     b48:      	b	0xa64 <ltmp0+0xa64>
     b4c:      	mov	x9, #0x0                ; =0
     b50:      	add	x8, x8, #0x600
     b54:      	b	0xb64 <ltmp0+0xb64>
     b58:      	add	x9, x9, #0x20
     b5c:      	cmp	x9, #0x600
     b60:      	b.eq	0x84 <ltmp0+0x84>
     b64:      	fmov	w11, s2
     b68:      	add	x10, x27, x9
     b6c:      	ldp	q5, q3, [x10]
     b70:      	add	x10, x26, x9
     b74:      	ldp	q6, q4, [x10]
     b78:      	fmul.4s	v7, v5, v6
     b7c:      	add	x10, x28, x9
     b80:      	ldp	q16, q5, [x10]
     b84:      	add	x10, x19, x9
     b88:      	ldp	q17, q6, [x10]
     b8c:      	fmul.4s	v16, v16, v17
     b90:      	fadd.4s	v7, v7, v16
     b94:      	and.16b	v7, v1, v7
     b98:      	add	x10, x8, x9
     b9c:      	tbnz	w11, #0x0, 0xbd4 <ltmp0+0xbd4>
     ba0:      	and	w11, w11, #0xff
     ba4:      	tbnz	w11, #0x1, 0xbe0 <ltmp0+0xbe0>
     ba8:      	tbnz	w11, #0x2, 0xbec <ltmp0+0xbec>
     bac:      	tbnz	w11, #0x3, 0xbf8 <ltmp0+0xbf8>
     bb0:      	fmul.4s	v3, v3, v4
     bb4:      	fmul.4s	v4, v5, v6
     bb8:      	fadd.4s	v3, v3, v4
     bbc:      	and.16b	v3, v0, v3
     bc0:      	tbnz	w11, #0x4, 0xc14 <ltmp0+0xc14>
     bc4:      	tbnz	w11, #0x5, 0xc1c <ltmp0+0xc1c>
     bc8:      	tbnz	w11, #0x6, 0xc28 <ltmp0+0xc28>
     bcc:      	tbz	w11, #0x7, 0xb58 <ltmp0+0xb58>
     bd0:      	b	0xc34 <ltmp0+0xc34>
     bd4:      	str	s7, [x10]
     bd8:      	and	w11, w11, #0xff
     bdc:      	tbz	w11, #0x1, 0xba8 <ltmp0+0xba8>
     be0:      	add	x12, x10, #0x4
     be4:      	st1.s	{ v7 }[1], [x12]
     be8:      	tbz	w11, #0x2, 0xbac <ltmp0+0xbac>
     bec:      	add	x12, x10, #0x8
     bf0:      	st1.s	{ v7 }[2], [x12]
     bf4:      	tbz	w11, #0x3, 0xbb0 <ltmp0+0xbb0>
     bf8:      	add	x12, x10, #0xc
     bfc:      	st1.s	{ v7 }[3], [x12]
     c00:      	fmul.4s	v3, v3, v4
     c04:      	fmul.4s	v4, v5, v6
     c08:      	fadd.4s	v3, v3, v4
     c0c:      	and.16b	v3, v0, v3
     c10:      	tbz	w11, #0x4, 0xbc4 <ltmp0+0xbc4>
     c14:      	str	s3, [x10, #0x10]
     c18:      	tbz	w11, #0x5, 0xbc8 <ltmp0+0xbc8>
     c1c:      	add	x12, x10, #0x14
     c20:      	st1.s	{ v3 }[1], [x12]
     c24:      	tbz	w11, #0x6, 0xbcc <ltmp0+0xbcc>
     c28:      	add	x12, x10, #0x18
     c2c:      	st1.s	{ v3 }[2], [x12]
     c30:      	tbz	w11, #0x7, 0xb58 <ltmp0+0xb58>
     c34:      	add	x10, x10, #0x1c
     c38:      	st1.s	{ v3 }[3], [x10]
     c3c:      	b	0xb58 <ltmp0+0xb58>
     c40:      	ldr	x9, [sp, #0x8]
     c44:      	stp	w4, w3, [x9]
     c48:      	str	w2, [x9, #0x8]
     c4c:      	mov	w8, #0x18               ; =24
     c50:      	str	w8, [x9, #0x24]
     c54:      	add	sp, sp, #0x1, lsl #12   ; =0x1000
     c58:      	add	sp, sp, #0x8a0
     c5c:      	ldp	x29, x30, [sp, #0x50]
     c60:      	ldp	x20, x19, [sp, #0x40]
     c64:      	ldp	x22, x21, [sp, #0x30]
     c68:      	ldp	x24, x23, [sp, #0x20]
     c6c:      	ldp	x26, x25, [sp, #0x10]
     c70:      	ldp	x28, x27, [sp], #0x60
     c74:      	ret

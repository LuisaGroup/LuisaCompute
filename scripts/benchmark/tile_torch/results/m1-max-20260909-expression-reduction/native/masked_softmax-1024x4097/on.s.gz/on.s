
/private/tmp/luisa-expression-fusion.qXgTbC/capture/masked_softmax-1024x4097/on/object/tile_xir_w8_23406_1788930267442623_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x290
      2c:      	mov	x11, #0x0               ; =0
      30:      	ldr	x8, [x1, #0x88]
      34:      	add	x10, x8, #0x11, lsl #12 ; =0x11000
      38:      	add	x13, x10, #0x68
      3c:      	mov	w10, #0xd068            ; =53352
      40:      	add	x14, x8, x10
      44:      	ldr	x16, [x0]
      48:      	ldr	w10, [x1]
      4c:      	ldr	w12, [x1, #0x24]
      50:      	add	w10, w12, w10, lsl #5
      54:      	lsr	w10, w10, #3
      58:      	dup.4s	v0, w10
      5c:      	ushll.2d	v1, v0, #0x0
      60:      	fmov	x10, d1
      64:      	mov	w12, #0x4004            ; =16388
      68:      	umaddl	x12, w10, w12, x16
      6c:      	mov	w15, #0xc020            ; =49184
      70:      	ldr	x9, [x0, #0x30]
      74:      	str	x9, [sp, #0x18]
      78:      	add	x17, x12, x11
      7c:      	ldp	q2, q3, [x17]
      80:      	add	x17, x8, x11
      84:      	stp	q2, q3, [x17]
      88:      	add	x11, x11, #0x20
      8c:      	cmp	x11, #0x4, lsl #12      ; =0x4000
      90:      	b.ne	0x78 <ltmp0+0x78>
      94:      	mov	x17, #0x0               ; =0
      98:      	fmov	x11, d1
      9c:      	add	x11, x11, x11, lsl #12
      a0:      	lsl	x9, x11, #2
      a4:      	str	x9, [sp, #0x8]
      a8:      	add	x9, x9, #0x4, lsl #12   ; =0x4000
      ac:      	str	x9, [sp, #0x10]
      b0:      	ldr	s1, [x16, x9]
      b4:      	mov	w16, #0x4000            ; =16384
      b8:      	str	s1, [x8, x16]
      bc:      	adrp	x16, 0x0 <ltmp0>
      c0:      	ldr	q1, [x16]
      c4:      	adrp	x16, 0x0 <ltmp0>
      c8:      	ldr	q2, [x16]
      cc:      	adrp	x16, 0x0 <ltmp0>
      d0:      	ldr	q3, [x16]
      d4:      	adrp	x16, 0x0 <ltmp0>
      d8:      	ldr	q4, [x16]
      dc:      	mov	w16, #0x1               ; =1
      e0:      	dup.2d	v5, x16
      e4:      	mov	w16, #0x4020            ; =16416
      e8:      	add	x16, x8, x16
      ec:      	movi.2d	v6, #0000000000000000
      f0:      	movi.2d	v7, #0000000000000000
      f4:      	movi.2d	v16, #0000000000000000
      f8:      	movi.2d	v17, #0000000000000000
      fc:      	shl.2d	v18, v6, #0x3
     100:      	shl.2d	v19, v7, #0x3
     104:      	shl.2d	v20, v16, #0x3
     108:      	shl.2d	v21, v17, #0x3
     10c:      	orr.16b	v21, v21, v1
     110:      	orr.16b	v20, v20, v2
     114:      	orr.16b	v19, v19, v3
     118:      	orr.16b	v18, v18, v4
     11c:      	add	x17, x16, x17, lsl #6
     120:      	stp	q18, q19, [x17]
     124:      	stp	q20, q21, [x17, #0x20]
     128:      	add.2d	v16, v16, v5
     12c:      	add.2d	v7, v7, v5
     130:      	add.2d	v17, v17, v5
     134:      	add.2d	v6, v6, v5
     138:      	fmov	x17, d6
     13c:      	cmp	x17, #0x200
     140:      	b.lt	0xfc <ltmp0+0xfc>
     144:      	mov	x17, #0x0               ; =0
     148:      	mov	w0, #0x1000             ; =4096
     14c:      	str	x0, [x8, x15]
     150:      	mov	w0, #0xf001             ; =61441
     154:      	movk	w0, #0xff, lsl #16
     158:      	dup.4s	v1, w0
     15c:      	mov	w0, #0x1001             ; =4097
     160:      	dup.4s	v2, w0
     164:      	mov	w0, #0xc060             ; =49248
     168:      	add	x0, x8, x0
     16c:      	umull2.2d	v3, v0, v1
     170:      	umull.2d	v4, v0, v1
     174:      	uzp2.4s	v4, v4, v3
     178:      	ushr.4s	v4, v4, #0x4
     17c:      	mov.16b	v5, v0
     180:      	mls.4s	v5, v4, v2
     184:      	umull.2d	v1, v0, v1
     188:      	uzp2.4s	v1, v1, v3
     18c:      	ushr.4s	v1, v1, #0x4
     190:      	mls.4s	v0, v1, v2
     194:      	ushll2.2d	v2, v0, #0x0
     198:      	ushll2.2d	v3, v5, #0x0
     19c:      	ushll.2d	v4, v0, #0x0
     1a0:      	ushll.2d	v1, v5, #0x0
     1a4:      	movi.2d	v5, #0000000000000000
     1a8:      	dup.2d	v0, x0
     1ac:      	adrp	x0, 0x0 <ltmp0>
     1b0:      	ldr	q6, [x0]
     1b4:      	str	q6, [sp, #0x280]
     1b8:      	adrp	x0, 0x0 <ltmp0>
     1bc:      	ldr	q15, [x0]
     1c0:      	adrp	x0, 0x0 <ltmp0>
     1c4:      	ldr	q28, [x0]
     1c8:      	adrp	x0, 0x0 <ltmp0>
     1cc:      	ldr	q29, [x0]
     1d0:      	movi.8b	v6, #0x1
     1d4:      	mov	w0, #0x1                ; =1
     1d8:      	dup.2d	v7, x0
     1dc:      	movi.2d	v16, #0000000000000000
     1e0:      	movi.2d	v17, #0000000000000000
     1e4:      	movi.2d	v18, #0000000000000000
     1e8:      	add	x17, x16, x17, lsl #6
     1ec:      	ldp	q20, q19, [x17, #0x20]
     1f0:      	ldp	q21, q22, [x17]
     1f4:      	add.2d	v23, v18, v29
     1f8:      	add.2d	v23, v23, v0
     1fc:      	add.2d	v24, v17, v28
     200:      	add.2d	v25, v16, v15
     204:      	ldr	q26, [sp, #0x280]
     208:      	add.2d	v26, v5, v26
     20c:      	add.2d	v26, v26, v0
     210:      	cmge.2d	v22, v3, v22
     214:      	cmge.2d	v21, v1, v21
     218:      	uzp1.4s	v21, v21, v22
     21c:      	cmge.2d	v20, v4, v20
     220:      	cmge.2d	v19, v2, v19
     224:      	uzp1.4s	v19, v20, v19
     228:      	uzp1.8h	v19, v21, v19
     22c:      	xtn.8b	v19, v19
     230:      	and.8b	v19, v19, v6
     234:      	mov.d	x17, v26[1]
     238:      	fmov	x0, d26
     23c:      	str	b19, [x0]
     240:      	st1.b	{ v19 }[1], [x17]
     244:      	add.2d	v20, v25, v0
     248:      	mov.d	x17, v20[1]
     24c:      	fmov	x0, d20
     250:      	st1.b	{ v19 }[2], [x0]
     254:      	add.2d	v20, v24, v0
     258:      	st1.b	{ v19 }[3], [x17]
     25c:      	mov.d	x17, v20[1]
     260:      	fmov	x0, d20
     264:      	st1.b	{ v19 }[4], [x0]
     268:      	st1.b	{ v19 }[5], [x17]
     26c:      	mov.d	x17, v23[1]
     270:      	fmov	x0, d23
     274:      	st1.b	{ v19 }[6], [x0]
     278:      	st1.b	{ v19 }[7], [x17]
     27c:      	add.2d	v17, v17, v7
     280:      	add.2d	v16, v16, v7
     284:      	add.2d	v18, v18, v7
     288:      	add.2d	v5, v5, v7
     28c:      	fmov	x17, d5
     290:      	cmp	x17, #0x200
     294:      	b.lt	0x1e8 <ltmp0+0x1e8>
     298:      	ldr	d2, [x8, x15]
     29c:      	adrp	x15, 0x0 <ltmp0>
     2a0:      	ldr	q3, [x15]
     2a4:      	add.2d	v3, v0, v3
     2a8:      	cmge.2d	v1, v1, v2
     2ac:      	xtn.2s	v1, v1
     2b0:      	uzp1.4h	v1, v1, v0
     2b4:      	uzp1.8b	v1, v1, v0
     2b8:      	movi.8b	v2, #0x1
     2bc:      	and.8b	v1, v1, v2
     2c0:      	str	q3, [sp, #0x20]
     2c4:      	fmov	x15, d3
     2c8:      	str	b1, [x15]
     2cc:      	add.2d	v1, v0, v29
     2d0:      	add.2d	v2, v0, v28
     2d4:      	add.2d	v3, v0, v15
     2d8:      	ldr	q4, [sp, #0x280]
     2dc:      	add.2d	v4, v0, v4
     2e0:      	fmov	x16, d4
     2e4:      	str	q4, [sp, #0x250]
     2e8:      	mov.d	x15, v4[1]
     2ec:      	fmov	x17, d3
     2f0:      	mov.d	x21, v3[1]
     2f4:      	fmov	x0, d2
     2f8:      	mov.d	x22, v2[1]
     2fc:      	fmov	x1, d1
     300:      	mov.d	x23, v1[1]
     304:      	ldr	b4, [x16]
     308:      	ld1.b	{ v4 }[1], [x15]
     30c:      	ld1.b	{ v4 }[2], [x17]
     310:      	ld1.b	{ v4 }[3], [x21]
     314:      	ld1.b	{ v4 }[4], [x0]
     318:      	ld1.b	{ v4 }[5], [x22]
     31c:      	ld1.b	{ v4 }[6], [x1]
     320:      	ld1.b	{ v4 }[7], [x23]
     324:      	cmeq.8b	v4, v4, #0
     328:      	sshll.8h	v4, v4, #0x0
     32c:      	sshll2.4s	v5, v4, #0x0
     330:      	sshll.4s	v4, v4, #0x0
     334:      	ldp	q7, q6, [x8]
     338:      	mov	w16, #0xf2ca            ; =62154
     33c:      	movk	w16, #0xf149, lsl #16
     340:      	dup.4s	v22, w16
     344:      	bsl.16b	v4, v22, v7
     348:      	bsl.16b	v5, v22, v6
     34c:      	stp	q4, q5, [x14]
     350:      	adrp	x16, 0x0 <ltmp0>
     354:      	ldr	q6, [x16]
     358:      	add.2d	v7, v0, v6
     35c:      	adrp	x16, 0x0 <ltmp0>
     360:      	ldr	q6, [x16]
     364:      	add.2d	v16, v0, v6
     368:      	adrp	x16, 0x0 <ltmp0>
     36c:      	ldr	q6, [x16]
     370:      	add.2d	v19, v0, v6
     374:      	adrp	x16, 0x0 <ltmp0>
     378:      	ldr	q6, [x16]
     37c:      	add.2d	v20, v0, v6
     380:      	fmov	x16, d20
     384:      	mov.d	x6, v20[1]
     388:      	fmov	x17, d19
     38c:      	mov.d	x7, v19[1]
     390:      	fmov	x0, d16
     394:      	stp	q16, q7, [sp, #0x230]
     398:      	mov.d	x19, v16[1]
     39c:      	fmov	x1, d7
     3a0:      	mov.d	x20, v7[1]
     3a4:      	ldr	b6, [x16]
     3a8:      	ld1.b	{ v6 }[1], [x6]
     3ac:      	ld1.b	{ v6 }[2], [x17]
     3b0:      	ld1.b	{ v6 }[3], [x7]
     3b4:      	ld1.b	{ v6 }[4], [x0]
     3b8:      	ld1.b	{ v6 }[5], [x19]
     3bc:      	ld1.b	{ v6 }[6], [x1]
     3c0:      	ld1.b	{ v6 }[7], [x20]
     3c4:      	cmeq.8b	v6, v6, #0
     3c8:      	sshll.8h	v6, v6, #0x0
     3cc:      	sshll2.4s	v17, v6, #0x0
     3d0:      	sshll.4s	v6, v6, #0x0
     3d4:      	ldp	q21, q18, [x8, #0x20]
     3d8:      	bsl.16b	v6, v22, v21
     3dc:      	mov.16b	v23, v17
     3e0:      	bsl.16b	v23, v22, v18
     3e4:      	stp	q6, q23, [x14, #0x20]
     3e8:      	adrp	x16, 0x0 <ltmp0>
     3ec:      	ldr	q17, [x16]
     3f0:      	str	q17, [sp, #0x200]
     3f4:      	add.2d	v7, v0, v17
     3f8:      	adrp	x16, 0x0 <ltmp0>
     3fc:      	ldr	q17, [x16]
     400:      	str	q17, [sp, #0x1f0]
     404:      	add.2d	v16, v0, v17
     408:      	adrp	x16, 0x0 <ltmp0>
     40c:      	ldr	q17, [x16]
     410:      	str	q17, [sp, #0x1e0]
     414:      	add.2d	v17, v0, v17
     418:      	adrp	x16, 0x0 <ltmp0>
     41c:      	ldr	q18, [x16]
     420:      	add.2d	v18, v0, v18
     424:      	fmov	x16, d18
     428:      	stp	q18, q17, [sp, #0x160]
     42c:      	mov.d	x3, v18[1]
     430:      	fmov	x17, d17
     434:      	mov.d	x4, v17[1]
     438:      	fmov	x0, d16
     43c:      	stp	q16, q7, [sp, #0x210]
     440:      	mov.d	x5, v16[1]
     444:      	fmov	x1, d7
     448:      	mov.d	x2, v7[1]
     44c:      	ldr	b21, [x16]
     450:      	ld1.b	{ v21 }[1], [x3]
     454:      	ld1.b	{ v21 }[2], [x17]
     458:      	ld1.b	{ v21 }[3], [x4]
     45c:      	ld1.b	{ v21 }[4], [x0]
     460:      	ld1.b	{ v21 }[5], [x5]
     464:      	ld1.b	{ v21 }[6], [x1]
     468:      	ld1.b	{ v21 }[7], [x2]
     46c:      	cmeq.8b	v21, v21, #0
     470:      	sshll.8h	v21, v21, #0x0
     474:      	sshll2.4s	v25, v21, #0x0
     478:      	sshll.4s	v21, v21, #0x0
     47c:      	ldp	q24, q26, [x8, #0x40]
     480:      	bit.16b	v24, v22, v21
     484:      	bsl.16b	v25, v22, v26
     488:      	stp	q24, q25, [x14, #0x40]
     48c:      	adrp	x16, 0x0 <ltmp0>
     490:      	ldr	q17, [x16]
     494:      	add.2d	v7, v0, v17
     498:      	adrp	x16, 0x0 <ltmp0>
     49c:      	ldr	q10, [x16]
     4a0:      	add.2d	v16, v0, v10
     4a4:      	adrp	x16, 0x0 <ltmp0>
     4a8:      	ldr	q21, [x16]
     4ac:      	str	q21, [sp, #0x1b0]
     4b0:      	add.2d	v18, v0, v21
     4b4:      	adrp	x16, 0x0 <ltmp0>
     4b8:      	ldr	q21, [x16]
     4bc:      	add.2d	v21, v0, v21
     4c0:      	fmov	x24, d21
     4c4:      	stp	q21, q18, [sp, #0x180]
     4c8:      	mov.d	x17, v21[1]
     4cc:      	mov.d	x0, v18[1]
     4d0:      	fmov	x25, d18
     4d4:      	fmov	x26, d16
     4d8:      	stp	q16, q7, [sp, #0x260]
     4dc:      	mov.d	x1, v16[1]
     4e0:      	mov.d	x16, v7[1]
     4e4:      	fmov	x27, d7
     4e8:      	ldr	b21, [x24]
     4ec:      	ld1.b	{ v21 }[1], [x17]
     4f0:      	ld1.b	{ v21 }[2], [x25]
     4f4:      	ld1.b	{ v21 }[3], [x0]
     4f8:      	ld1.b	{ v21 }[4], [x26]
     4fc:      	ld1.b	{ v21 }[5], [x1]
     500:      	ld1.b	{ v21 }[6], [x27]
     504:      	ld1.b	{ v21 }[7], [x16]
     508:      	cmeq.8b	v21, v21, #0
     50c:      	sshll.8h	v21, v21, #0x0
     510:      	sshll.4s	v26, v21, #0x0
     514:      	ldp	q16, q27, [x8, #0x60]
     518:      	bsl.16b	v26, v22, v16
     51c:      	sshll2.4s	v21, v21, #0x0
     520:      	bit.16b	v27, v22, v21
     524:      	stp	q26, q27, [x14, #0x60]
     528:      	mov	w24, #0x4               ; =4
     52c:      	mov	w25, #0x1               ; =1
     530:      	mov	w26, #0x2               ; =2
     534:      	mov	w27, #0x3               ; =3
     538:      	mov	w28, #0x4               ; =4
     53c:      	str	q28, [sp, #0x1a0]
     540:      	dup.2d	v28, x24
     544:      	mov.16b	v18, v29
     548:      	mov.16b	v29, v28
     54c:      	mov.16b	v30, v28
     550:      	mov.16b	v31, v28
     554:      	stp	q10, q17, [sp, #0x1c0]
     558:      	add.2d	v10, v29, v0
     55c:      	add.2d	v8, v30, v0
     560:      	add.2d	v9, v31, v0
     564:      	add.2d	v21, v9, v18
     568:      	ldr	q7, [sp, #0x280]
     56c:      	add.2d	v11, v28, v7
     570:      	add.2d	v11, v11, v0
     574:      	mov.d	x30, v11[1]
     578:      	mov.16b	v16, v18
     57c:      	ldr	q18, [sp, #0x1a0]
     580:      	add.2d	v12, v8, v18
     584:      	add.2d	v13, v10, v15
     588:      	fmov	x9, d11
     58c:      	mov.d	x10, v13[1]
     590:      	mov.d	x11, v12[1]
     594:      	fmov	x12, d13
     598:      	ldr	b11, [x9]
     59c:      	ld1.b	{ v11 }[1], [x30]
     5a0:      	mov.d	x9, v21[1]
     5a4:      	fmov	x30, d12
     5a8:      	ld1.b	{ v11 }[2], [x12]
     5ac:      	ld1.b	{ v11 }[3], [x10]
     5b0:      	fmov	x10, d21
     5b4:      	ld1.b	{ v11 }[4], [x30]
     5b8:      	ld1.b	{ v11 }[5], [x11]
     5bc:      	ld1.b	{ v11 }[6], [x10]
     5c0:      	ld1.b	{ v11 }[7], [x9]
     5c4:      	cmeq.8b	v21, v11, #0
     5c8:      	sshll.8h	v21, v21, #0x0
     5cc:      	sshll2.4s	v11, v21, #0x0
     5d0:      	sshll.4s	v21, v21, #0x0
     5d4:      	lsl	x9, x28, #5
     5d8:      	add	x10, x8, x9
     5dc:      	ldp	q13, q12, [x10]
     5e0:      	bsl.16b	v21, v22, v13
     5e4:      	bit.16b	v12, v22, v11
     5e8:      	dup.2d	v11, x25
     5ec:      	orr.16b	v11, v28, v11
     5f0:      	mvn.16b	v7, v0
     5f4:      	ldr	q17, [sp, #0x250]
     5f8:      	add.2d	v13, v11, v17
     5fc:      	mov.d	x10, v13[1]
     600:      	fmov	x11, d13
     604:      	sub.2d	v13, v29, v7
     608:      	add.2d	v13, v13, v15
     60c:      	add	x9, x14, x9
     610:      	mov.d	x12, v13[1]
     614:      	fmov	x28, d13
     618:      	sub.2d	v13, v30, v7
     61c:      	stp	q21, q12, [x9]
     620:      	add.2d	v13, v13, v18
     624:      	mov.16b	v18, v16
     628:      	mov.d	x9, v13[1]
     62c:      	fmov	x30, d13
     630:      	sub.2d	v13, v31, v7
     634:      	fmaxnm.4s	v5, v5, v12
     638:      	ldr	b12, [x11]
     63c:      	ld1.b	{ v12 }[1], [x10]
     640:      	ld1.b	{ v12 }[2], [x28]
     644:      	add.2d	v13, v13, v16
     648:      	ld1.b	{ v12 }[3], [x12]
     64c:      	ld1.b	{ v12 }[4], [x30]
     650:      	mov.d	x10, v13[1]
     654:      	fmov	x11, d13
     658:      	ld1.b	{ v12 }[5], [x9]
     65c:      	ld1.b	{ v12 }[6], [x11]
     660:      	fmaxnm.4s	v4, v4, v21
     664:      	ld1.b	{ v12 }[7], [x10]
     668:      	cmeq.8b	v21, v12, #0
     66c:      	sshll.8h	v21, v21, #0x0
     670:      	sshll2.4s	v12, v21, #0x0
     674:      	sshll.4s	v21, v21, #0x0
     678:      	fmov	x9, d11
     67c:      	lsl	x9, x9, #5
     680:      	add	x10, x8, x9
     684:      	ldp	q13, q11, [x10]
     688:      	bsl.16b	v21, v22, v13
     68c:      	bit.16b	v11, v22, v12
     690:      	add	x9, x14, x9
     694:      	stp	q21, q11, [x9]
     698:      	dup.2d	v12, x26
     69c:      	fmaxnm.4s	v23, v23, v11
     6a0:      	orr.16b	v11, v28, v12
     6a4:      	ldr	q12, [sp, #0x1f0]
     6a8:      	add.2d	v12, v8, v12
     6ac:      	add.2d	v13, v11, v17
     6b0:      	mov.d	x10, v13[1]
     6b4:      	fmov	x9, d13
     6b8:      	ldr	q13, [sp, #0x1e0]
     6bc:      	add.2d	v13, v10, v13
     6c0:      	mov.d	x11, v13[1]
     6c4:      	mov.d	x12, v12[1]
     6c8:      	fmov	x28, d13
     6cc:      	fmov	x30, d12
     6d0:      	ldr	b12, [x9]
     6d4:      	ld1.b	{ v12 }[1], [x10]
     6d8:      	ldr	q13, [sp, #0x200]
     6dc:      	add.2d	v13, v9, v13
     6e0:      	ld1.b	{ v12 }[2], [x28]
     6e4:      	ld1.b	{ v12 }[3], [x11]
     6e8:      	mov.d	x9, v13[1]
     6ec:      	fmov	x10, d13
     6f0:      	ld1.b	{ v12 }[4], [x30]
     6f4:      	ld1.b	{ v12 }[5], [x12]
     6f8:      	fmaxnm.4s	v6, v6, v21
     6fc:      	ld1.b	{ v12 }[6], [x10]
     700:      	ld1.b	{ v12 }[7], [x9]
     704:      	cmeq.8b	v21, v12, #0
     708:      	sshll.8h	v21, v21, #0x0
     70c:      	sshll2.4s	v12, v21, #0x0
     710:      	fmov	x9, d11
     714:      	lsl	x9, x9, #5
     718:      	add	x10, x8, x9
     71c:      	ldp	q13, q11, [x10]
     720:      	sshll.4s	v21, v21, #0x0
     724:      	bsl.16b	v21, v22, v13
     728:      	dup.2d	v13, x27
     72c:      	orr.16b	v13, v28, v13
     730:      	bit.16b	v11, v22, v12
     734:      	ldr	q12, [sp, #0x1b0]
     738:      	add.2d	v10, v10, v12
     73c:      	add.2d	v12, v13, v17
     740:      	mov.d	x10, v12[1]
     744:      	mov.d	x11, v10[1]
     748:      	fmov	x12, d12
     74c:      	fmov	x28, d10
     750:      	ldp	q10, q17, [sp, #0x1c0]
     754:      	add	x9, x14, x9
     758:      	fmaxnm.4s	v25, v25, v11
     75c:      	stp	q21, q11, [x9]
     760:      	add.2d	v9, v9, v17
     764:      	add.2d	v8, v8, v10
     768:      	mov.d	x9, v8[1]
     76c:      	fmov	x30, d8
     770:      	ldr	b8, [x12]
     774:      	ld1.b	{ v8 }[1], [x10]
     778:      	ld1.b	{ v8 }[2], [x28]
     77c:      	mov.d	x10, v9[1]
     780:      	ld1.b	{ v8 }[3], [x11]
     784:      	ld1.b	{ v8 }[4], [x30]
     788:      	ld1.b	{ v8 }[5], [x9]
     78c:      	fmov	x9, d9
     790:      	ld1.b	{ v8 }[6], [x9]
     794:      	ld1.b	{ v8 }[7], [x10]
     798:      	fmaxnm.4s	v24, v24, v21
     79c:      	cmeq.8b	v21, v8, #0
     7a0:      	sshll.8h	v21, v21, #0x0
     7a4:      	fmov	x9, d13
     7a8:      	lsl	x9, x9, #5
     7ac:      	add	x10, x8, x9
     7b0:      	sshll.4s	v8, v21, #0x0
     7b4:      	ldr	q9, [x10]
     7b8:      	bsl.16b	v8, v22, v9
     7bc:      	ldr	q9, [x10, #0x10]
     7c0:      	sshll2.4s	v21, v21, #0x0
     7c4:      	bsl.16b	v21, v22, v9
     7c8:      	add	x9, x14, x9
     7cc:      	fmaxnm.4s	v27, v27, v21
     7d0:      	stp	q8, q21, [x9]
     7d4:      	fmaxnm.4s	v26, v26, v8
     7d8:      	dup.2d	v21, x24
     7dc:      	add.2d	v30, v30, v21
     7e0:      	add.2d	v29, v29, v21
     7e4:      	add.2d	v31, v31, v21
     7e8:      	add.2d	v28, v28, v21
     7ec:      	fmov	x28, d28
     7f0:      	cmp	x28, #0x200
     7f4:      	b.lt	0x558 <ltmp0+0x558>
     7f8:      	ldr	q21, [sp, #0x20]
     7fc:      	fmov	x9, d21
     800:      	ldr	b21, [x9]
     804:      	cmeq.8b	v21, v21, #0
     808:      	sshll.8h	v21, v21, #0x0
     80c:      	sshll.4s	v21, v21, #0x0
     810:      	mov	w9, #0x4000             ; =16384
     814:      	ldr	s22, [x8, x9]
     818:      	mov	w9, #0xf2ca             ; =62154
     81c:      	movk	w9, #0xf149, lsl #16
     820:      	dup.4s	v28, w9
     824:      	bsl.16b	v21, v28, v22
     828:      	ldr	q22, [x13]
     82c:      	mov.s	v22[0], v21[0]
     830:      	str	q22, [x13]
     834:      	fmaxnm.4s	v21, v4, v21
     838:      	mov.s	v4[0], v21[0]
     83c:      	fmaxnm.4s	v5, v5, v23
     840:      	fmaxnm.4s	v4, v4, v6
     844:      	fmaxnm.4s	v4, v4, v24
     848:      	fmaxnm.4s	v5, v5, v25
     84c:      	fmaxnm.4s	v5, v5, v27
     850:      	fmaxnm.4s	v4, v4, v26
     854:      	rev64.4s	v6, v4
     858:      	rev64.4s	v21, v5
     85c:      	fmaxnm.4s	v5, v5, v21
     860:      	fmaxnm.4s	v4, v4, v6
     864:      	ext.16b	v6, v4, v4, #0x8
     868:      	ext.16b	v21, v5, v5, #0x8
     86c:      	fmaxnm.4s	v5, v5, v21
     870:      	fmaxnm.4s	v4, v4, v6
     874:      	fmaxnm.4s	v4, v4, v5
     878:      	mov	w9, #-0x800000          ; =-8388608
     87c:      	fmov	s5, w9
     880:      	fmaxnm	s4, s4, s5
     884:      	fmov	x26, d3
     888:      	fmov	x25, d2
     88c:      	fmov	x24, d1
     890:      	dup.4s	v22, v4[0]
     894:      	ldp	q2, q1, [x14]
     898:      	fsub.4s	v2, v2, v22
     89c:      	mov	w9, #-0x3d300000        ; =-1026555904
     8a0:      	dup.4s	v25, w9
     8a4:      	mov	w9, #0x42c80000         ; =1120403456
     8a8:      	dup.4s	v26, w9
     8ac:      	fcmge.4s	v3, v2, v25
     8b0:      	fcmge.4s	v4, v26, v2
     8b4:      	and.16b	v3, v3, v4
     8b8:      	mov	w9, #0xaa3b             ; =43579
     8bc:      	movk	w9, #0x3fb8, lsl #16
     8c0:      	dup.4s	v24, w9
     8c4:      	and.16b	v3, v3, v2
     8c8:      	fmul.4s	v4, v3, v24
     8cc:      	movi.4s	v27, #0x4b, lsl #24
     8d0:      	mvni.4s	v28, #0x80, lsl #24
     8d4:      	mov.16b	v5, v28
     8d8:      	bsl.16b	v5, v27, v4
     8dc:      	fadd.4s	v4, v4, v5
     8e0:      	fsub.4s	v4, v4, v5
     8e4:      	fcvtzs.4s	v4, v4
     8e8:      	scvtf.4s	v5, v4
     8ec:      	mov	w9, #0x7200             ; =29184
     8f0:      	movk	w9, #0x3f31, lsl #16
     8f4:      	dup.4s	v29, w9
     8f8:      	fmul.4s	v6, v5, v29
     8fc:      	fsub.4s	v3, v3, v6
     900:      	mov	w9, #0xbe8e             ; =48782
     904:      	movk	w9, #0x35bf, lsl #16
     908:      	dup.4s	v30, w9
     90c:      	fmul.4s	v5, v5, v30
     910:      	fsub.4s	v3, v3, v5
     914:      	mov	w9, #0x2bda             ; =11226
     918:      	movk	w9, #0x3950, lsl #16
     91c:      	dup.4s	v31, w9
     920:      	fmul.4s	v5, v3, v31
     924:      	mov	w9, #0x96c9             ; =38601
     928:      	movk	w9, #0x3ab6, lsl #16
     92c:      	dup.4s	v8, w9
     930:      	fadd.4s	v5, v5, v8
     934:      	mov	w9, #0x88a6             ; =34982
     938:      	movk	w9, #0x3c08, lsl #16
     93c:      	dup.4s	v9, w9
     940:      	fmul.4s	v5, v3, v5
     944:      	fadd.4s	v5, v5, v9
     948:      	fmul.4s	v5, v3, v5
     94c:      	mov	w9, #0xaa7a             ; =43642
     950:      	movk	w9, #0x3d2a, lsl #16
     954:      	dup.4s	v10, w9
     958:      	fadd.4s	v5, v5, v10
     95c:      	fmul.4s	v5, v3, v5
     960:      	mov	w9, #0xaaab             ; =43691
     964:      	movk	w9, #0x3e2a, lsl #16
     968:      	dup.4s	v11, w9
     96c:      	fadd.4s	v5, v5, v11
     970:      	fmul.4s	v5, v3, v5
     974:      	movi.4s	v12, #0x3f, lsl #24
     978:      	fadd.4s	v5, v5, v12
     97c:      	fmul.4s	v6, v3, v3
     980:      	fmul.4s	v5, v6, v5
     984:      	fadd.4s	v3, v3, v5
     988:      	fmov.4s	v23, #1.00000000
     98c:      	fadd.4s	v3, v3, v23
     990:      	sshr.4s	v5, v4, #0x1
     994:      	shl.4s	v6, v5, #0x17
     998:      	add.4s	v6, v6, v23
     99c:      	fmul.4s	v3, v3, v6
     9a0:      	ldr	q6, [sp, #0x250]
     9a4:      	fmov	x9, d6
     9a8:      	sub.4s	v4, v4, v5
     9ac:      	shl.4s	v4, v4, #0x17
     9b0:      	add.4s	v4, v4, v23
     9b4:      	fmul.4s	v3, v3, v4
     9b8:      	fcmgt.4s	v4, v25, v2
     9bc:      	bic.16b	v3, v3, v4
     9c0:      	fcmgt.4s	v4, v2, v26
     9c4:      	mvni.4s	v5, #0x7f, msl #16
     9c8:      	str	q15, [sp, #0x90]
     9cc:      	fneg.4s	v13, v5
     9d0:      	bit.16b	v3, v13, v4
     9d4:      	fcmeq.4s	v2, v2, v2
     9d8:      	mvni.4s	v4, #0x3f, msl #16
     9dc:      	fneg.4s	v15, v4
     9e0:      	bsl.16b	v2, v3, v15
     9e4:      	ldr	b3, [x9]
     9e8:      	ld1.b	{ v3 }[1], [x15]
     9ec:      	ld1.b	{ v3 }[2], [x26]
     9f0:      	ld1.b	{ v3 }[3], [x21]
     9f4:      	ld1.b	{ v3 }[4], [x25]
     9f8:      	ld1.b	{ v3 }[5], [x22]
     9fc:      	ld1.b	{ v3 }[6], [x24]
     a00:      	ld1.b	{ v3 }[7], [x23]
     a04:      	cmeq.8b	v3, v3, #0
     a08:      	sshll.8h	v3, v3, #0x0
     a0c:      	sshll.4s	v4, v3, #0x0
     a10:      	bic.16b	v17, v2, v4
     a14:      	fsub.4s	v1, v1, v22
     a18:      	fcmge.4s	v2, v1, v25
     a1c:      	fcmge.4s	v4, v26, v1
     a20:      	and.16b	v2, v2, v4
     a24:      	and.16b	v2, v2, v1
     a28:      	fmul.4s	v4, v2, v24
     a2c:      	mov.16b	v6, v28
     a30:      	bsl.16b	v6, v27, v4
     a34:      	fadd.4s	v4, v4, v6
     a38:      	fsub.4s	v4, v4, v6
     a3c:      	fcvtzs.4s	v4, v4
     a40:      	scvtf.4s	v6, v4
     a44:      	fmul.4s	v21, v6, v29
     a48:      	fsub.4s	v2, v2, v21
     a4c:      	fmul.4s	v6, v6, v30
     a50:      	fsub.4s	v2, v2, v6
     a54:      	fmul.4s	v6, v2, v31
     a58:      	fadd.4s	v6, v6, v8
     a5c:      	fmul.4s	v6, v2, v6
     a60:      	fadd.4s	v6, v6, v9
     a64:      	fmul.4s	v6, v2, v6
     a68:      	fadd.4s	v6, v6, v10
     a6c:      	fmul.4s	v6, v2, v6
     a70:      	fadd.4s	v6, v6, v11
     a74:      	fmul.4s	v6, v2, v6
     a78:      	fadd.4s	v6, v6, v12
     a7c:      	fmul.4s	v21, v2, v2
     a80:      	fmul.4s	v6, v21, v6
     a84:      	fadd.4s	v2, v2, v6
     a88:      	fadd.4s	v2, v2, v23
     a8c:      	sshr.4s	v6, v4, #0x1
     a90:      	shl.4s	v21, v6, #0x17
     a94:      	add.4s	v21, v21, v23
     a98:      	fmul.4s	v2, v2, v21
     a9c:      	sub.4s	v4, v4, v6
     aa0:      	shl.4s	v4, v4, #0x17
     aa4:      	add.4s	v4, v4, v23
     aa8:      	fmul.4s	v2, v2, v4
     aac:      	fcmgt.4s	v4, v25, v1
     ab0:      	bic.16b	v2, v2, v4
     ab4:      	fcmgt.4s	v4, v1, v26
     ab8:      	bit.16b	v2, v13, v4
     abc:      	fcmeq.4s	v1, v1, v1
     ac0:      	bsl.16b	v1, v2, v15
     ac4:      	sshll2.4s	v2, v3, #0x0
     ac8:      	bic.16b	v5, v1, v2
     acc:      	fmov	x24, d20
     ad0:      	fmov	x23, d19
     ad4:      	ldr	q1, [sp, #0x230]
     ad8:      	fmov	x22, d1
     adc:      	ldr	q1, [sp, #0x240]
     ae0:      	fmov	x21, d1
     ae4:      	ldp	q1, q2, [x14, #0x20]
     ae8:      	fsub.4s	v2, v2, v22
     aec:      	fsub.4s	v1, v1, v22
     af0:      	fcmge.4s	v3, v1, v25
     af4:      	fcmge.4s	v4, v2, v25
     af8:      	fcmge.4s	v6, v26, v2
     afc:      	and.16b	v4, v4, v6
     b00:      	fcmge.4s	v6, v26, v1
     b04:      	and.16b	v3, v3, v6
     b08:      	and.16b	v6, v3, v1
     b0c:      	fmul.4s	v3, v6, v24
     b10:      	str	q7, [sp, #0x60]
     b14:      	mov.16b	v7, v28
     b18:      	bsl.16b	v7, v27, v3
     b1c:      	fadd.4s	v3, v3, v7
     b20:      	fsub.4s	v3, v3, v7
     b24:      	and.16b	v4, v4, v2
     b28:      	fmul.4s	v7, v4, v24
     b2c:      	mov.16b	v16, v28
     b30:      	bsl.16b	v16, v27, v7
     b34:      	fadd.4s	v7, v7, v16
     b38:      	fsub.4s	v7, v7, v16
     b3c:      	fcvtzs.4s	v3, v3
     b40:      	scvtf.4s	v16, v3
     b44:      	fmul.4s	v19, v16, v29
     b48:      	fsub.4s	v6, v6, v19
     b4c:      	fcvtzs.4s	v7, v7
     b50:      	scvtf.4s	v19, v7
     b54:      	fmul.4s	v20, v19, v29
     b58:      	fsub.4s	v4, v4, v20
     b5c:      	fmul.4s	v19, v19, v30
     b60:      	fsub.4s	v4, v4, v19
     b64:      	fmul.4s	v16, v16, v30
     b68:      	fsub.4s	v6, v6, v16
     b6c:      	fmul.4s	v16, v6, v31
     b70:      	fadd.4s	v16, v16, v8
     b74:      	fmul.4s	v16, v6, v16
     b78:      	fadd.4s	v16, v16, v9
     b7c:      	fmul.4s	v16, v6, v16
     b80:      	fadd.4s	v16, v16, v10
     b84:      	fmul.4s	v16, v6, v16
     b88:      	fadd.4s	v16, v16, v11
     b8c:      	fmul.4s	v16, v6, v16
     b90:      	fadd.4s	v16, v16, v12
     b94:      	fmul.4s	v19, v6, v6
     b98:      	fmul.4s	v16, v19, v16
     b9c:      	fmul.4s	v19, v4, v31
     ba0:      	fadd.4s	v19, v19, v8
     ba4:      	fmul.4s	v19, v4, v19
     ba8:      	fadd.4s	v19, v19, v9
     bac:      	fmul.4s	v19, v4, v19
     bb0:      	fadd.4s	v19, v19, v10
     bb4:      	fmul.4s	v19, v4, v19
     bb8:      	fadd.4s	v19, v19, v11
     bbc:      	fmul.4s	v19, v4, v19
     bc0:      	fadd.4s	v19, v19, v12
     bc4:      	fmul.4s	v20, v4, v4
     bc8:      	fmul.4s	v19, v20, v19
     bcc:      	fadd.4s	v4, v4, v19
     bd0:      	fadd.4s	v6, v6, v16
     bd4:      	fadd.4s	v4, v4, v23
     bd8:      	sshr.4s	v16, v7, #0x1
     bdc:      	shl.4s	v19, v16, #0x17
     be0:      	add.4s	v19, v19, v23
     be4:      	fmul.4s	v4, v4, v19
     be8:      	fadd.4s	v6, v6, v23
     bec:      	sshr.4s	v19, v3, #0x1
     bf0:      	shl.4s	v20, v19, #0x17
     bf4:      	add.4s	v20, v20, v23
     bf8:      	fmul.4s	v6, v6, v20
     bfc:      	sub.4s	v7, v7, v16
     c00:      	sub.4s	v3, v3, v19
     c04:      	shl.4s	v3, v3, #0x17
     c08:      	add.4s	v3, v3, v23
     c0c:      	fmul.4s	v3, v6, v3
     c10:      	mov	x15, x13
     c14:      	stp	q5, q17, [sp, #0x230]
     c18:      	stp	q17, q5, [x15, #0x20]!
     c1c:      	shl.4s	v6, v7, #0x17
     c20:      	add.4s	v6, v6, v23
     c24:      	fmul.4s	v4, v4, v6
     c28:      	fcmgt.4s	v6, v25, v2
     c2c:      	bic.16b	v4, v4, v6
     c30:      	fcmgt.4s	v6, v25, v1
     c34:      	bic.16b	v3, v3, v6
     c38:      	fcmgt.4s	v6, v1, v26
     c3c:      	bit.16b	v3, v13, v6
     c40:      	fcmgt.4s	v6, v2, v26
     c44:      	bit.16b	v4, v13, v6
     c48:      	ldr	b6, [x24]
     c4c:      	ld1.b	{ v6 }[1], [x6]
     c50:      	ld1.b	{ v6 }[2], [x23]
     c54:      	ld1.b	{ v6 }[3], [x7]
     c58:      	ld1.b	{ v6 }[4], [x22]
     c5c:      	ld1.b	{ v6 }[5], [x19]
     c60:      	ld1.b	{ v6 }[6], [x21]
     c64:      	ld1.b	{ v6 }[7], [x20]
     c68:      	cmeq.8b	v6, v6, #0
     c6c:      	sshll.8h	v6, v6, #0x0
     c70:      	fcmeq.4s	v2, v2, v2
     c74:      	bsl.16b	v2, v4, v15
     c78:      	sshll2.4s	v4, v6, #0x0
     c7c:      	sshll.4s	v6, v6, #0x0
     c80:      	fcmeq.4s	v1, v1, v1
     c84:      	bsl.16b	v1, v3, v15
     c88:      	bic.16b	v5, v1, v6
     c8c:      	bic.16b	v16, v2, v4
     c90:      	ldr	q1, [sp, #0x160]
     c94:      	fmov	x20, d1
     c98:      	ldr	q1, [sp, #0x170]
     c9c:      	fmov	x19, d1
     ca0:      	ldr	q1, [sp, #0x210]
     ca4:      	fmov	x7, d1
     ca8:      	ldr	q1, [sp, #0x220]
     cac:      	fmov	x6, d1
     cb0:      	ldp	q2, q1, [x14, #0x40]
     cb4:      	fsub.4s	v1, v1, v22
     cb8:      	fsub.4s	v2, v2, v22
     cbc:      	fcmge.4s	v3, v2, v25
     cc0:      	fcmge.4s	v4, v1, v25
     cc4:      	fcmge.4s	v6, v26, v2
     cc8:      	fcmge.4s	v7, v26, v1
     ccc:      	and.16b	v4, v4, v7
     cd0:      	and.16b	v3, v3, v6
     cd4:      	and.16b	v6, v3, v2
     cd8:      	and.16b	v4, v4, v1
     cdc:      	fmul.4s	v3, v4, v24
     ce0:      	fmul.4s	v7, v6, v24
     ce4:      	mov.16b	v17, v28
     ce8:      	bsl.16b	v17, v27, v7
     cec:      	fadd.4s	v7, v7, v17
     cf0:      	fsub.4s	v7, v7, v17
     cf4:      	mov.16b	v17, v28
     cf8:      	bsl.16b	v17, v27, v3
     cfc:      	fadd.4s	v3, v3, v17
     d00:      	fsub.4s	v17, v3, v17
     d04:      	fcvtzs.4s	v3, v7
     d08:      	scvtf.4s	v7, v3
     d0c:      	str	q18, [sp, #0x50]
     d10:      	fmul.4s	v18, v7, v29
     d14:      	fsub.4s	v6, v6, v18
     d18:      	fcvtzs.4s	v17, v17
     d1c:      	scvtf.4s	v18, v17
     d20:      	fmul.4s	v19, v18, v29
     d24:      	fsub.4s	v4, v4, v19
     d28:      	fmul.4s	v18, v18, v30
     d2c:      	fsub.4s	v4, v4, v18
     d30:      	fmul.4s	v7, v7, v30
     d34:      	fsub.4s	v6, v6, v7
     d38:      	fmul.4s	v7, v6, v31
     d3c:      	fadd.4s	v7, v7, v8
     d40:      	fmul.4s	v7, v6, v7
     d44:      	fadd.4s	v7, v7, v9
     d48:      	fmul.4s	v7, v6, v7
     d4c:      	fadd.4s	v7, v7, v10
     d50:      	fmul.4s	v7, v6, v7
     d54:      	fadd.4s	v7, v7, v11
     d58:      	fmul.4s	v7, v6, v7
     d5c:      	fadd.4s	v7, v7, v12
     d60:      	fmul.4s	v18, v6, v6
     d64:      	fmul.4s	v7, v18, v7
     d68:      	fmul.4s	v18, v4, v31
     d6c:      	fadd.4s	v18, v18, v8
     d70:      	fmul.4s	v18, v4, v18
     d74:      	fadd.4s	v18, v18, v9
     d78:      	fmul.4s	v18, v4, v18
     d7c:      	fadd.4s	v18, v18, v10
     d80:      	fmul.4s	v18, v4, v18
     d84:      	fadd.4s	v18, v18, v11
     d88:      	fmul.4s	v18, v4, v18
     d8c:      	fadd.4s	v18, v18, v12
     d90:      	fmul.4s	v19, v4, v4
     d94:      	fmul.4s	v18, v19, v18
     d98:      	fadd.4s	v4, v4, v18
     d9c:      	fadd.4s	v6, v6, v7
     da0:      	fadd.4s	v4, v4, v23
     da4:      	sshr.4s	v7, v17, #0x1
     da8:      	shl.4s	v18, v7, #0x17
     dac:      	add.4s	v18, v18, v23
     db0:      	fmul.4s	v4, v4, v18
     db4:      	fadd.4s	v6, v6, v23
     db8:      	sshr.4s	v18, v3, #0x1
     dbc:      	shl.4s	v19, v18, #0x17
     dc0:      	add.4s	v19, v19, v23
     dc4:      	fmul.4s	v6, v6, v19
     dc8:      	sub.4s	v7, v17, v7
     dcc:      	stp	q16, q5, [sp, #0x210]
     dd0:      	stp	q5, q16, [x15, #0x20]
     dd4:      	ldr	b17, [x20]
     dd8:      	ld1.b	{ v17 }[1], [x3]
     ddc:      	ld1.b	{ v17 }[2], [x19]
     de0:      	ld1.b	{ v17 }[3], [x4]
     de4:      	ld1.b	{ v17 }[4], [x7]
     de8:      	ld1.b	{ v17 }[5], [x5]
     dec:      	sub.4s	v3, v3, v18
     df0:      	ld1.b	{ v17 }[6], [x6]
     df4:      	ld1.b	{ v17 }[7], [x2]
     df8:      	cmeq.8b	v17, v17, #0
     dfc:      	sshll.8h	v17, v17, #0x0
     e00:      	shl.4s	v3, v3, #0x17
     e04:      	add.4s	v3, v3, v23
     e08:      	fmul.4s	v3, v6, v3
     e0c:      	sshll2.4s	v6, v17, #0x0
     e10:      	sshll.4s	v17, v17, #0x0
     e14:      	shl.4s	v7, v7, #0x17
     e18:      	add.4s	v7, v7, v23
     e1c:      	fmul.4s	v4, v4, v7
     e20:      	fcmgt.4s	v7, v25, v1
     e24:      	bic.16b	v4, v4, v7
     e28:      	fcmgt.4s	v7, v25, v2
     e2c:      	bic.16b	v3, v3, v7
     e30:      	fcmgt.4s	v7, v2, v26
     e34:      	bit.16b	v3, v13, v7
     e38:      	fcmgt.4s	v7, v1, v26
     e3c:      	bit.16b	v4, v13, v7
     e40:      	fcmeq.4s	v2, v2, v2
     e44:      	fcmeq.4s	v1, v1, v1
     e48:      	bsl.16b	v1, v4, v15
     e4c:      	bsl.16b	v2, v3, v15
     e50:      	bic.16b	v5, v2, v17
     e54:      	bic.16b	v16, v1, v6
     e58:      	ldr	q1, [sp, #0x180]
     e5c:      	fmov	x5, d1
     e60:      	ldr	q1, [sp, #0x190]
     e64:      	fmov	x4, d1
     e68:      	ldr	q1, [sp, #0x260]
     e6c:      	fmov	x3, d1
     e70:      	ldr	q1, [sp, #0x270]
     e74:      	fmov	x2, d1
     e78:      	ldp	q2, q1, [x14, #0x60]
     e7c:      	fsub.4s	v1, v1, v22
     e80:      	str	q22, [sp, #0x130]
     e84:      	fsub.4s	v2, v2, v22
     e88:      	fcmge.4s	v3, v2, v25
     e8c:      	fcmge.4s	v4, v1, v25
     e90:      	fcmge.4s	v6, v26, v2
     e94:      	fcmge.4s	v7, v26, v1
     e98:      	and.16b	v4, v4, v7
     e9c:      	and.16b	v3, v3, v6
     ea0:      	and.16b	v3, v3, v2
     ea4:      	and.16b	v4, v4, v1
     ea8:      	fmul.4s	v6, v4, v24
     eac:      	stp	q29, q24, [sp, #0x100]
     eb0:      	fmul.4s	v7, v3, v24
     eb4:      	mov.16b	v19, v28
     eb8:      	bsl.16b	v19, v27, v7
     ebc:      	mov.16b	v20, v28
     ec0:      	bsl.16b	v20, v27, v6
     ec4:      	fadd.4s	v6, v6, v20
     ec8:      	fadd.4s	v7, v7, v19
     ecc:      	fsub.4s	v7, v7, v19
     ed0:      	fsub.4s	v6, v6, v20
     ed4:      	fcvtzs.4s	v6, v6
     ed8:      	fcvtzs.4s	v7, v7
     edc:      	scvtf.4s	v19, v7
     ee0:      	scvtf.4s	v20, v6
     ee4:      	fmul.4s	v21, v19, v29
     ee8:      	fsub.4s	v3, v3, v21
     eec:      	fmul.4s	v21, v20, v29
     ef0:      	fsub.4s	v4, v4, v21
     ef4:      	fmul.4s	v19, v19, v30
     ef8:      	stp	q31, q30, [sp, #0xe0]
     efc:      	fmul.4s	v20, v20, v30
     f00:      	fsub.4s	v4, v4, v20
     f04:      	fsub.4s	v3, v3, v19
     f08:      	fmul.4s	v19, v3, v31
     f0c:      	fmul.4s	v20, v4, v31
     f10:      	fadd.4s	v20, v20, v8
     f14:      	stp	q9, q8, [sp, #0xc0]
     f18:      	fadd.4s	v19, v19, v8
     f1c:      	fmul.4s	v19, v3, v19
     f20:      	fmul.4s	v20, v4, v20
     f24:      	fadd.4s	v20, v20, v9
     f28:      	fadd.4s	v19, v19, v9
     f2c:      	fmul.4s	v19, v3, v19
     f30:      	fmul.4s	v20, v4, v20
     f34:      	fadd.4s	v20, v20, v10
     f38:      	stp	q11, q10, [sp, #0xa0]
     f3c:      	fadd.4s	v19, v19, v10
     f40:      	fmul.4s	v19, v3, v19
     f44:      	fmul.4s	v20, v4, v20
     f48:      	fadd.4s	v20, v20, v11
     f4c:      	fadd.4s	v19, v19, v11
     f50:      	fmul.4s	v19, v3, v19
     f54:      	fmul.4s	v20, v4, v20
     f58:      	fadd.4s	v20, v20, v12
     f5c:      	fadd.4s	v19, v19, v12
     f60:      	fmul.4s	v21, v3, v3
     f64:      	fmul.4s	v19, v21, v19
     f68:      	fmul.4s	v21, v4, v4
     f6c:      	fmul.4s	v20, v21, v20
     f70:      	fadd.4s	v4, v4, v20
     f74:      	fadd.4s	v3, v3, v19
     f78:      	fadd.4s	v3, v3, v23
     f7c:      	fadd.4s	v4, v4, v23
     f80:      	sshr.4s	v19, v7, #0x1
     f84:      	sshr.4s	v20, v6, #0x1
     f88:      	shl.4s	v21, v20, #0x17
     f8c:      	add.4s	v21, v21, v23
     f90:      	fmul.4s	v4, v4, v21
     f94:      	shl.4s	v21, v19, #0x17
     f98:      	add.4s	v21, v21, v23
     f9c:      	fmul.4s	v3, v3, v21
     fa0:      	sub.4s	v6, v6, v20
     fa4:      	mov.16b	v20, v5
     fa8:      	mov.16b	v29, v16
     fac:      	stp	q5, q16, [x15, #0x40]
     fb0:      	sub.4s	v7, v7, v19
     fb4:      	ldr	b19, [x5]
     fb8:      	ld1.b	{ v19 }[1], [x17]
     fbc:      	ld1.b	{ v19 }[2], [x4]
     fc0:      	ld1.b	{ v19 }[3], [x0]
     fc4:      	ld1.b	{ v19 }[4], [x3]
     fc8:      	ld1.b	{ v19 }[5], [x1]
     fcc:      	ld1.b	{ v19 }[6], [x2]
     fd0:      	shl.4s	v7, v7, #0x17
     fd4:      	add.4s	v7, v7, v23
     fd8:      	fmul.4s	v3, v3, v7
     fdc:      	ld1.b	{ v19 }[7], [x16]
     fe0:      	cmeq.8b	v7, v19, #0
     fe4:      	sshll.8h	v7, v7, #0x0
     fe8:      	shl.4s	v6, v6, #0x17
     fec:      	add.4s	v6, v6, v23
     ff0:      	fmul.4s	v4, v4, v6
     ff4:      	fcmgt.4s	v6, v25, v1
     ff8:      	bic.16b	v4, v4, v6
     ffc:      	stp	q26, q25, [sp, #0x30]
    1000:      	fcmgt.4s	v6, v25, v2
    1004:      	bic.16b	v3, v3, v6
    1008:      	fcmgt.4s	v6, v2, v26
    100c:      	bit.16b	v3, v13, v6
    1010:      	fcmgt.4s	v6, v1, v26
    1014:      	stp	q15, q13, [sp, #0x70]
    1018:      	bit.16b	v4, v13, v6
    101c:      	sshll2.4s	v6, v7, #0x0
    1020:      	sshll.4s	v7, v7, #0x0
    1024:      	fcmeq.4s	v2, v2, v2
    1028:      	fcmeq.4s	v1, v1, v1
    102c:      	bsl.16b	v1, v4, v15
    1030:      	bsl.16b	v2, v3, v15
    1034:      	bic.16b	v16, v2, v7
    1038:      	bic.16b	v17, v1, v6
    103c:      	stp	q16, q17, [x15, #0x60]
    1040:      	mov	w16, #0x4               ; =4
    1044:      	mov	w17, #0x1               ; =1
    1048:      	mov	w0, #0x2                ; =2
    104c:      	mov	w1, #0x3                ; =3
    1050:      	dup.2d	v4, x16
    1054:      	mov	w2, #0x4                ; =4
    1058:      	mov.16b	v2, v4
    105c:      	mov.16b	v3, v4
    1060:      	mov.16b	v1, v4
    1064:      	str	q0, [sp, #0x120]
    1068:      	ldr	q26, [sp, #0x40]
    106c:      	ldp	q12, q8, [sp, #0x100]
    1070:      	ldp	q15, q13, [sp, #0xe0]
    1074:      	ldr	q19, [sp, #0xc0]
    1078:      	ldp	q9, q11, [sp, #0x70]
    107c:      	stp	q29, q17, [sp, #0x160]
    1080:      	stp	q1, q2, [sp, #0x260]
    1084:      	stp	q16, q20, [sp, #0x180]
    1088:      	add.2d	v2, v2, v0
    108c:      	add.2d	v6, v3, v0
    1090:      	add.2d	v1, v1, v0
    1094:      	stp	q2, q1, [sp, #0x140]
    1098:      	mov.16b	v25, v3
    109c:      	ldr	q3, [sp, #0x50]
    10a0:      	add.2d	v7, v1, v3
    10a4:      	ldr	q31, [sp, #0x1a0]
    10a8:      	add.2d	v21, v6, v31
    10ac:      	ldr	q1, [sp, #0x280]
    10b0:      	add.2d	v24, v4, v1
    10b4:      	add.2d	v24, v24, v0
    10b8:      	mov.d	x9, v24[1]
    10bc:      	ldr	q29, [sp, #0x90]
    10c0:      	add.2d	v10, v2, v29
    10c4:      	fmov	x10, d24
    10c8:      	mov.d	x11, v10[1]
    10cc:      	mov.d	x12, v21[1]
    10d0:      	fmov	x3, d10
    10d4:      	fmov	x4, d21
    10d8:      	mov.d	x5, v7[1]
    10dc:      	fmov	x6, d7
    10e0:      	ldr	b7, [x10]
    10e4:      	ld1.b	{ v7 }[1], [x9]
    10e8:      	ld1.b	{ v7 }[2], [x3]
    10ec:      	ld1.b	{ v7 }[3], [x11]
    10f0:      	lsl	x2, x2, #5
    10f4:      	add	x9, x14, x2
    10f8:      	ldp	q21, q24, [x9]
    10fc:      	ld1.b	{ v7 }[4], [x4]
    1100:      	ldr	q0, [sp, #0x130]
    1104:      	fsub.4s	v24, v24, v0
    1108:      	fsub.4s	v10, v21, v0
    110c:      	fcmge.4s	v21, v10, v26
    1110:      	fcmge.4s	v14, v24, v26
    1114:      	ld1.b	{ v7 }[5], [x12]
    1118:      	ldr	q1, [sp, #0x30]
    111c:      	fcmge.4s	v16, v1, v10
    1120:      	fcmge.4s	v22, v1, v24
    1124:      	and.16b	v22, v14, v22
    1128:      	and.16b	v16, v21, v16
    112c:      	ld1.b	{ v7 }[6], [x6]
    1130:      	and.16b	v16, v16, v10
    1134:      	and.16b	v21, v22, v24
    1138:      	fmul.4s	v22, v21, v8
    113c:      	fmul.4s	v14, v16, v8
    1140:      	ld1.b	{ v7 }[7], [x5]
    1144:      	movi.4s	v2, #0x4b, lsl #24
    1148:      	mvni.4s	v5, #0x80, lsl #24
    114c:      	mov.16b	v17, v5
    1150:      	bsl.16b	v17, v2, v14
    1154:      	mov.16b	v18, v5
    1158:      	bsl.16b	v18, v2, v22
    115c:      	movi.4s	v28, #0x4b, lsl #24
    1160:      	fadd.4s	v22, v22, v18
    1164:      	fadd.4s	v14, v14, v17
    1168:      	fsub.4s	v17, v14, v17
    116c:      	cmeq.8b	v7, v7, #0
    1170:      	fsub.4s	v18, v22, v18
    1174:      	fcvtzs.4s	v18, v18
    1178:      	fcvtzs.4s	v17, v17
    117c:      	scvtf.4s	v22, v17
    1180:      	scvtf.4s	v14, v18
    1184:      	fmul.4s	v27, v22, v12
    1188:      	fsub.4s	v16, v16, v27
    118c:      	fmul.4s	v27, v14, v12
    1190:      	fsub.4s	v21, v21, v27
    1194:      	fmul.4s	v22, v22, v13
    1198:      	fmul.4s	v27, v14, v13
    119c:      	fsub.4s	v21, v21, v27
    11a0:      	fsub.4s	v16, v16, v22
    11a4:      	fmul.4s	v22, v16, v15
    11a8:      	fmul.4s	v27, v21, v15
    11ac:      	ldr	q5, [sp, #0xd0]
    11b0:      	fadd.4s	v27, v27, v5
    11b4:      	fadd.4s	v22, v22, v5
    11b8:      	fmul.4s	v22, v16, v22
    11bc:      	fmul.4s	v27, v21, v27
    11c0:      	fadd.4s	v27, v27, v19
    11c4:      	fadd.4s	v22, v22, v19
    11c8:      	fmul.4s	v22, v16, v22
    11cc:      	fmul.4s	v27, v21, v27
    11d0:      	ldp	q2, q20, [sp, #0xa0]
    11d4:      	fadd.4s	v27, v27, v20
    11d8:      	fadd.4s	v22, v22, v20
    11dc:      	fmul.4s	v22, v16, v22
    11e0:      	fmul.4s	v27, v21, v27
    11e4:      	fadd.4s	v27, v27, v2
    11e8:      	fadd.4s	v22, v22, v2
    11ec:      	sshll.8h	v7, v7, #0x0
    11f0:      	fmul.4s	v22, v16, v22
    11f4:      	fmul.4s	v27, v21, v27
    11f8:      	movi.4s	v30, #0x3f, lsl #24
    11fc:      	fadd.4s	v27, v27, v30
    1200:      	fadd.4s	v22, v22, v30
    1204:      	fmul.4s	v14, v16, v16
    1208:      	fmul.4s	v22, v14, v22
    120c:      	fmul.4s	v14, v21, v21
    1210:      	fmul.4s	v27, v14, v27
    1214:      	sshll2.4s	v30, v7, #0x0
    1218:      	fadd.4s	v21, v21, v27
    121c:      	fadd.4s	v16, v16, v22
    1220:      	sshll.4s	v7, v7, #0x0
    1224:      	fadd.4s	v16, v16, v23
    1228:      	fadd.4s	v21, v21, v23
    122c:      	sshr.4s	v22, v18, #0x1
    1230:      	shl.4s	v27, v22, #0x17
    1234:      	add.4s	v27, v27, v23
    1238:      	fmul.4s	v21, v21, v27
    123c:      	sshr.4s	v27, v17, #0x1
    1240:      	sub.4s	v18, v18, v22
    1244:      	shl.4s	v22, v27, #0x17
    1248:      	add.4s	v22, v22, v23
    124c:      	sub.4s	v17, v17, v27
    1250:      	fmul.4s	v16, v16, v22
    1254:      	shl.4s	v17, v17, #0x17
    1258:      	shl.4s	v18, v18, #0x17
    125c:      	add.4s	v18, v18, v23
    1260:      	add.4s	v17, v17, v23
    1264:      	fmul.4s	v16, v16, v17
    1268:      	fmul.4s	v17, v21, v18
    126c:      	fcmgt.4s	v18, v26, v24
    1270:      	bic.16b	v17, v17, v18
    1274:      	fcmgt.4s	v18, v26, v10
    1278:      	fcmgt.4s	v21, v24, v1
    127c:      	fcmgt.4s	v22, v10, v1
    1280:      	bic.16b	v16, v16, v18
    1284:      	bit.16b	v16, v11, v22
    1288:      	bit.16b	v17, v11, v21
    128c:      	fcmeq.4s	v18, v10, v10
    1290:      	fcmeq.4s	v21, v24, v24
    1294:      	bif.16b	v17, v9, v21
    1298:      	bif.16b	v16, v9, v18
    129c:      	dup.2d	v18, x17
    12a0:      	orr.16b	v18, v4, v18
    12a4:      	ldr	q24, [sp, #0x60]
    12a8:      	ldp	q27, q21, [sp, #0x260]
    12ac:      	sub.2d	v21, v21, v24
    12b0:      	sub.2d	v22, v25, v24
    12b4:      	add	x9, x15, x2
    12b8:      	sub.2d	v24, v27, v24
    12bc:      	add.2d	v24, v24, v3
    12c0:      	mov.16b	v3, v25
    12c4:      	add.2d	v22, v22, v31
    12c8:      	add.2d	v21, v21, v29
    12cc:      	ldr	q31, [sp, #0x250]
    12d0:      	add.2d	v27, v18, v31
    12d4:      	bic.16b	v14, v16, v7
    12d8:      	mov.d	x3, v27[1]
    12dc:      	fmov	x5, d27
    12e0:      	mov.d	x4, v21[1]
    12e4:      	bic.16b	v7, v17, v30
    12e8:      	fmov	x7, d21
    12ec:      	mov.d	x6, v22[1]
    12f0:      	fmov	x19, d22
    12f4:      	stp	q14, q7, [x9]
    12f8:      	mov.d	x20, v24[1]
    12fc:      	fmov	x9, d18
    1300:      	lsl	x2, x9, #5
    1304:      	add	x9, x14, x2
    1308:      	ldr	q16, [sp, #0x230]
    130c:      	fadd.4s	v16, v16, v7
    1310:      	str	q16, [sp, #0x230]
    1314:      	ldp	q7, q16, [x9]
    1318:      	fmov	x21, d24
    131c:      	fsub.4s	v24, v16, v0
    1320:      	fsub.4s	v10, v7, v0
    1324:      	fcmge.4s	v7, v10, v26
    1328:      	fcmge.4s	v16, v24, v26
    132c:      	fcmge.4s	v17, v1, v10
    1330:      	fcmge.4s	v18, v1, v24
    1334:      	and.16b	v16, v16, v18
    1338:      	and.16b	v7, v7, v17
    133c:      	and.16b	v17, v7, v10
    1340:      	and.16b	v16, v16, v24
    1344:      	fmul.4s	v7, v16, v8
    1348:      	fmul.4s	v18, v17, v8
    134c:      	mvni.4s	v22, #0x80, lsl #24
    1350:      	mov.16b	v21, v22
    1354:      	bsl.16b	v21, v28, v18
    1358:      	bsl.16b	v22, v28, v7
    135c:      	fadd.4s	v7, v7, v22
    1360:      	fadd.4s	v18, v18, v21
    1364:      	fsub.4s	v18, v18, v21
    1368:      	fsub.4s	v7, v7, v22
    136c:      	fcvtzs.4s	v7, v7
    1370:      	fcvtzs.4s	v21, v18
    1374:      	scvtf.4s	v18, v21
    1378:      	scvtf.4s	v22, v7
    137c:      	fmul.4s	v27, v18, v12
    1380:      	fsub.4s	v17, v17, v27
    1384:      	fmul.4s	v27, v22, v12
    1388:      	fsub.4s	v16, v16, v27
    138c:      	fmul.4s	v18, v18, v13
    1390:      	fmul.4s	v22, v22, v13
    1394:      	fsub.4s	v16, v16, v22
    1398:      	fsub.4s	v17, v17, v18
    139c:      	fmul.4s	v18, v17, v15
    13a0:      	fmul.4s	v22, v16, v15
    13a4:      	fadd.4s	v22, v22, v5
    13a8:      	fadd.4s	v18, v18, v5
    13ac:      	fmul.4s	v18, v17, v18
    13b0:      	fmul.4s	v22, v16, v22
    13b4:      	fadd.4s	v22, v22, v19
    13b8:      	fadd.4s	v18, v18, v19
    13bc:      	fmul.4s	v18, v17, v18
    13c0:      	fmul.4s	v22, v16, v22
    13c4:      	fadd.4s	v22, v22, v20
    13c8:      	fadd.4s	v18, v18, v20
    13cc:      	fmul.4s	v18, v17, v18
    13d0:      	fmul.4s	v22, v16, v22
    13d4:      	fadd.4s	v22, v22, v2
    13d8:      	fadd.4s	v18, v18, v2
    13dc:      	fmul.4s	v18, v17, v18
    13e0:      	fmul.4s	v22, v16, v22
    13e4:      	movi.4s	v25, #0x3f, lsl #24
    13e8:      	fadd.4s	v22, v22, v25
    13ec:      	fmul.4s	v27, v17, v17
    13f0:      	fadd.4s	v18, v18, v25
    13f4:      	fmul.4s	v18, v27, v18
    13f8:      	fmul.4s	v27, v16, v16
    13fc:      	fmul.4s	v22, v27, v22
    1400:      	ldr	b27, [x5]
    1404:      	ld1.b	{ v27 }[1], [x3]
    1408:      	ld1.b	{ v27 }[2], [x7]
    140c:      	ld1.b	{ v27 }[3], [x4]
    1410:      	ld1.b	{ v27 }[4], [x19]
    1414:      	ld1.b	{ v27 }[5], [x6]
    1418:      	ld1.b	{ v27 }[6], [x21]
    141c:      	ld1.b	{ v27 }[7], [x20]
    1420:      	cmeq.8b	v27, v27, #0
    1424:      	sshll.8h	v27, v27, #0x0
    1428:      	fadd.4s	v16, v16, v22
    142c:      	fadd.4s	v17, v17, v18
    1430:      	sshr.4s	v18, v7, #0x1
    1434:      	fadd.4s	v16, v16, v23
    1438:      	shl.4s	v22, v18, #0x17
    143c:      	add.4s	v22, v22, v23
    1440:      	fmul.4s	v16, v16, v22
    1444:      	sshll2.4s	v22, v27, #0x0
    1448:      	sshll.4s	v27, v27, #0x0
    144c:      	fadd.4s	v17, v17, v23
    1450:      	sub.4s	v7, v7, v18
    1454:      	sshr.4s	v18, v21, #0x1
    1458:      	sub.4s	v21, v21, v18
    145c:      	shl.4s	v18, v18, #0x17
    1460:      	add.4s	v18, v18, v23
    1464:      	fmul.4s	v17, v17, v18
    1468:      	shl.4s	v18, v21, #0x17
    146c:      	shl.4s	v7, v7, #0x17
    1470:      	add.4s	v7, v7, v23
    1474:      	add.4s	v18, v18, v23
    1478:      	fmul.4s	v17, v17, v18
    147c:      	fmul.4s	v7, v16, v7
    1480:      	fcmgt.4s	v16, v26, v24
    1484:      	bic.16b	v7, v7, v16
    1488:      	fcmgt.4s	v16, v26, v10
    148c:      	fcmgt.4s	v18, v24, v1
    1490:      	fcmgt.4s	v21, v10, v1
    1494:      	bic.16b	v16, v17, v16
    1498:      	bit.16b	v16, v11, v21
    149c:      	bit.16b	v7, v11, v18
    14a0:      	fcmeq.4s	v17, v10, v10
    14a4:      	fcmeq.4s	v18, v24, v24
    14a8:      	bif.16b	v7, v9, v18
    14ac:      	bif.16b	v16, v9, v17
    14b0:      	add	x9, x15, x2
    14b4:      	dup.2d	v17, x0
    14b8:      	orr.16b	v17, v4, v17
    14bc:      	ldr	q18, [sp, #0x200]
    14c0:      	ldp	q29, q28, [sp, #0x140]
    14c4:      	add.2d	v18, v28, v18
    14c8:      	ldr	q21, [sp, #0x240]
    14cc:      	fadd.4s	v21, v21, v14
    14d0:      	str	q21, [sp, #0x240]
    14d4:      	ldp	q24, q21, [sp, #0x1e0]
    14d8:      	mov.16b	v25, v6
    14dc:      	add.2d	v21, v6, v21
    14e0:      	add.2d	v24, v29, v24
    14e4:      	add.2d	v30, v17, v31
    14e8:      	mov.d	x2, v30[1]
    14ec:      	bic.16b	v14, v16, v27
    14f0:      	fmov	x5, d30
    14f4:      	mov.d	x3, v24[1]
    14f8:      	mov.d	x4, v21[1]
    14fc:      	bic.16b	v7, v7, v22
    1500:      	fmov	x19, d24
    1504:      	fmov	x7, d21
    1508:      	mov.d	x6, v18[1]
    150c:      	stp	q14, q7, [x9]
    1510:      	fmov	x9, d17
    1514:      	lsl	x20, x9, #5
    1518:      	add	x9, x14, x20
    151c:      	ldp	q16, q17, [x9]
    1520:      	ldr	q21, [sp, #0x210]
    1524:      	fadd.4s	v21, v21, v7
    1528:      	str	q21, [sp, #0x210]
    152c:      	fmov	x21, d18
    1530:      	fsub.4s	v24, v17, v0
    1534:      	fsub.4s	v10, v16, v0
    1538:      	fcmge.4s	v7, v10, v26
    153c:      	fcmge.4s	v16, v24, v26
    1540:      	fcmge.4s	v17, v1, v10
    1544:      	fcmge.4s	v18, v1, v24
    1548:      	and.16b	v16, v16, v18
    154c:      	and.16b	v7, v7, v17
    1550:      	and.16b	v7, v7, v10
    1554:      	and.16b	v16, v16, v24
    1558:      	fmul.4s	v17, v16, v8
    155c:      	fmul.4s	v18, v7, v8
    1560:      	mvni.4s	v6, #0x80, lsl #24
    1564:      	movi.4s	v22, #0x4b, lsl #24
    1568:      	mov.16b	v21, v6
    156c:      	bsl.16b	v21, v22, v18
    1570:      	bif.16b	v22, v17, v6
    1574:      	mvni.4s	v30, #0x80, lsl #24
    1578:      	fadd.4s	v17, v17, v22
    157c:      	fadd.4s	v18, v18, v21
    1580:      	fsub.4s	v18, v18, v21
    1584:      	fsub.4s	v17, v17, v22
    1588:      	fcvtzs.4s	v17, v17
    158c:      	fcvtzs.4s	v18, v18
    1590:      	scvtf.4s	v21, v18
    1594:      	scvtf.4s	v22, v17
    1598:      	fmul.4s	v27, v21, v12
    159c:      	fsub.4s	v7, v7, v27
    15a0:      	fmul.4s	v27, v22, v12
    15a4:      	fsub.4s	v16, v16, v27
    15a8:      	fmul.4s	v21, v21, v13
    15ac:      	fmul.4s	v22, v22, v13
    15b0:      	fsub.4s	v16, v16, v22
    15b4:      	fsub.4s	v7, v7, v21
    15b8:      	fmul.4s	v21, v7, v15
    15bc:      	fmul.4s	v22, v16, v15
    15c0:      	fadd.4s	v22, v22, v5
    15c4:      	fadd.4s	v21, v21, v5
    15c8:      	fmul.4s	v21, v7, v21
    15cc:      	fmul.4s	v22, v16, v22
    15d0:      	fadd.4s	v22, v22, v19
    15d4:      	fadd.4s	v21, v21, v19
    15d8:      	fmul.4s	v21, v7, v21
    15dc:      	fmul.4s	v22, v16, v22
    15e0:      	fadd.4s	v22, v22, v20
    15e4:      	fadd.4s	v21, v21, v20
    15e8:      	fmul.4s	v21, v7, v21
    15ec:      	fmul.4s	v22, v16, v22
    15f0:      	fadd.4s	v22, v22, v2
    15f4:      	fadd.4s	v21, v21, v2
    15f8:      	ldr	q27, [sp, #0x220]
    15fc:      	fadd.4s	v27, v27, v14
    1600:      	str	q27, [sp, #0x220]
    1604:      	fmul.4s	v21, v7, v21
    1608:      	fmul.4s	v22, v16, v22
    160c:      	movi.4s	v6, #0x3f, lsl #24
    1610:      	fadd.4s	v22, v22, v6
    1614:      	fadd.4s	v21, v21, v6
    1618:      	movi.4s	v14, #0x3f, lsl #24
    161c:      	fmul.4s	v27, v7, v7
    1620:      	fmul.4s	v21, v27, v21
    1624:      	fmul.4s	v27, v16, v16
    1628:      	fmul.4s	v22, v27, v22
    162c:      	fadd.4s	v16, v16, v22
    1630:      	fadd.4s	v7, v7, v21
    1634:      	sshr.4s	v21, v18, #0x1
    1638:      	fadd.4s	v16, v16, v23
    163c:      	sshr.4s	v22, v17, #0x1
    1640:      	shl.4s	v27, v22, #0x17
    1644:      	add.4s	v27, v27, v23
    1648:      	fmul.4s	v16, v16, v27
    164c:      	shl.4s	v27, v21, #0x17
    1650:      	fadd.4s	v7, v7, v23
    1654:      	add.4s	v27, v27, v23
    1658:      	fmul.4s	v7, v7, v27
    165c:      	sub.4s	v17, v17, v22
    1660:      	ldr	b22, [x5]
    1664:      	ld1.b	{ v22 }[1], [x2]
    1668:      	ld1.b	{ v22 }[2], [x19]
    166c:      	ld1.b	{ v22 }[3], [x3]
    1670:      	ld1.b	{ v22 }[4], [x7]
    1674:      	ld1.b	{ v22 }[5], [x4]
    1678:      	ld1.b	{ v22 }[6], [x21]
    167c:      	ld1.b	{ v22 }[7], [x6]
    1680:      	sub.4s	v18, v18, v21
    1684:      	cmeq.8b	v21, v22, #0
    1688:      	sshll.8h	v21, v21, #0x0
    168c:      	shl.4s	v18, v18, #0x17
    1690:      	add.4s	v18, v18, v23
    1694:      	fmul.4s	v7, v7, v18
    1698:      	sshll2.4s	v18, v21, #0x0
    169c:      	shl.4s	v17, v17, #0x17
    16a0:      	add.4s	v17, v17, v23
    16a4:      	fmul.4s	v16, v16, v17
    16a8:      	fcmgt.4s	v17, v26, v24
    16ac:      	bic.16b	v16, v16, v17
    16b0:      	fcmgt.4s	v17, v26, v10
    16b4:      	bic.16b	v7, v7, v17
    16b8:      	fcmgt.4s	v17, v10, v1
    16bc:      	bit.16b	v7, v11, v17
    16c0:      	fcmgt.4s	v17, v24, v1
    16c4:      	sshll.4s	v21, v21, #0x0
    16c8:      	bit.16b	v16, v11, v17
    16cc:      	fcmeq.4s	v17, v10, v10
    16d0:      	fcmeq.4s	v22, v24, v24
    16d4:      	bif.16b	v16, v9, v22
    16d8:      	add	x9, x15, x20
    16dc:      	bif.16b	v7, v9, v17
    16e0:      	dup.2d	v17, x1
    16e4:      	orr.16b	v17, v4, v17
    16e8:      	ldp	q24, q22, [sp, #0x1c0]
    16ec:      	add.2d	v22, v28, v22
    16f0:      	add.2d	v27, v25, v24
    16f4:      	bic.16b	v24, v7, v21
    16f8:      	ldr	q7, [sp, #0x1b0]
    16fc:      	add.2d	v6, v29, v7
    1700:      	add.2d	v7, v17, v31
    1704:      	mov.d	x4, v7[1]
    1708:      	fmov	x5, d7
    170c:      	bic.16b	v7, v16, v18
    1710:      	mov.d	x6, v6[1]
    1714:      	mov.d	x2, v27[1]
    1718:      	stp	q24, q7, [x9]
    171c:      	fmov	x19, d6
    1720:      	fmov	x7, d27
    1724:      	mov.d	x3, v22[1]
    1728:      	fmov	x9, d17
    172c:      	ldr	q29, [sp, #0x160]
    1730:      	fadd.4s	v29, v29, v7
    1734:      	lsl	x20, x9, #5
    1738:      	add	x9, x14, x20
    173c:      	ldp	q6, q7, [x9]
    1740:      	fmov	x21, d22
    1744:      	fsub.4s	v28, v7, v0
    1748:      	fsub.4s	v6, v6, v0
    174c:      	ldr	q0, [sp, #0x120]
    1750:      	fcmge.4s	v7, v6, v26
    1754:      	fcmge.4s	v16, v28, v26
    1758:      	fcmge.4s	v17, v1, v6
    175c:      	fcmge.4s	v18, v1, v28
    1760:      	and.16b	v16, v16, v18
    1764:      	and.16b	v7, v7, v17
    1768:      	and.16b	v7, v7, v6
    176c:      	and.16b	v16, v16, v28
    1770:      	fmul.4s	v17, v16, v8
    1774:      	fmul.4s	v18, v7, v8
    1778:      	movi.4s	v22, #0x4b, lsl #24
    177c:      	mov.16b	v21, v30
    1780:      	bsl.16b	v21, v22, v18
    1784:      	bif.16b	v22, v17, v30
    1788:      	fadd.4s	v17, v17, v22
    178c:      	fadd.4s	v18, v18, v21
    1790:      	fsub.4s	v18, v18, v21
    1794:      	fsub.4s	v17, v17, v22
    1798:      	fcvtzs.4s	v17, v17
    179c:      	fcvtzs.4s	v18, v18
    17a0:      	scvtf.4s	v21, v18
    17a4:      	scvtf.4s	v22, v17
    17a8:      	fmul.4s	v27, v21, v12
    17ac:      	fsub.4s	v7, v7, v27
    17b0:      	fmul.4s	v27, v22, v12
    17b4:      	fsub.4s	v16, v16, v27
    17b8:      	fmul.4s	v21, v21, v13
    17bc:      	fmul.4s	v22, v22, v13
    17c0:      	fsub.4s	v16, v16, v22
    17c4:      	fsub.4s	v7, v7, v21
    17c8:      	fmul.4s	v21, v7, v15
    17cc:      	fmul.4s	v22, v16, v15
    17d0:      	fadd.4s	v22, v22, v5
    17d4:      	fadd.4s	v21, v21, v5
    17d8:      	fmul.4s	v21, v7, v21
    17dc:      	fmul.4s	v22, v16, v22
    17e0:      	fadd.4s	v22, v22, v19
    17e4:      	fadd.4s	v21, v21, v19
    17e8:      	fmul.4s	v21, v7, v21
    17ec:      	fmul.4s	v22, v16, v22
    17f0:      	fadd.4s	v22, v22, v20
    17f4:      	fadd.4s	v21, v21, v20
    17f8:      	ldr	q20, [sp, #0x190]
    17fc:      	fadd.4s	v20, v20, v24
    1800:      	fmul.4s	v21, v7, v21
    1804:      	fmul.4s	v22, v16, v22
    1808:      	fadd.4s	v22, v22, v2
    180c:      	fadd.4s	v21, v21, v2
    1810:      	ldr	q2, [sp, #0x270]
    1814:      	fmul.4s	v21, v7, v21
    1818:      	fmul.4s	v22, v16, v22
    181c:      	fadd.4s	v22, v22, v14
    1820:      	fadd.4s	v21, v21, v14
    1824:      	fmul.4s	v24, v7, v7
    1828:      	fmul.4s	v21, v24, v21
    182c:      	fmul.4s	v24, v16, v16
    1830:      	fmul.4s	v22, v24, v22
    1834:      	fadd.4s	v16, v16, v22
    1838:      	fadd.4s	v7, v7, v21
    183c:      	fadd.4s	v7, v7, v23
    1840:      	sshr.4s	v21, v18, #0x1
    1844:      	sshr.4s	v22, v17, #0x1
    1848:      	fadd.4s	v16, v16, v23
    184c:      	shl.4s	v24, v22, #0x17
    1850:      	add.4s	v24, v24, v23
    1854:      	fmul.4s	v16, v16, v24
    1858:      	shl.4s	v24, v21, #0x17
    185c:      	add.4s	v24, v24, v23
    1860:      	fmul.4s	v7, v7, v24
    1864:      	sub.4s	v17, v17, v22
    1868:      	sub.4s	v18, v18, v21
    186c:      	shl.4s	v18, v18, #0x17
    1870:      	add.4s	v18, v18, v23
    1874:      	fmul.4s	v7, v7, v18
    1878:      	ldr	b18, [x5]
    187c:      	ld1.b	{ v18 }[1], [x4]
    1880:      	ld1.b	{ v18 }[2], [x19]
    1884:      	ld1.b	{ v18 }[3], [x6]
    1888:      	ld1.b	{ v18 }[4], [x7]
    188c:      	shl.4s	v17, v17, #0x17
    1890:      	add.4s	v17, v17, v23
    1894:      	fmul.4s	v16, v16, v17
    1898:      	fcmgt.4s	v17, v26, v28
    189c:      	bic.16b	v16, v16, v17
    18a0:      	fcmgt.4s	v17, v26, v6
    18a4:      	bic.16b	v7, v7, v17
    18a8:      	fcmgt.4s	v17, v6, v1
    18ac:      	bit.16b	v7, v11, v17
    18b0:      	fcmgt.4s	v17, v28, v1
    18b4:      	ldr	q1, [sp, #0x260]
    18b8:      	bit.16b	v16, v11, v17
    18bc:      	ld1.b	{ v18 }[5], [x2]
    18c0:      	ld1.b	{ v18 }[6], [x21]
    18c4:      	fcmeq.4s	v17, v28, v28
    18c8:      	bif.16b	v16, v9, v17
    18cc:      	ld1.b	{ v18 }[7], [x3]
    18d0:      	cmeq.8b	v17, v18, #0
    18d4:      	fcmeq.4s	v6, v6, v6
    18d8:      	sshll.8h	v17, v17, #0x0
    18dc:      	bsl.16b	v6, v7, v9
    18e0:      	sshll.4s	v7, v17, #0x0
    18e4:      	bic.16b	v6, v6, v7
    18e8:      	sshll2.4s	v7, v17, #0x0
    18ec:      	bic.16b	v7, v16, v7
    18f0:      	ldp	q17, q16, [sp, #0x170]
    18f4:      	add	x9, x15, x20
    18f8:      	fadd.4s	v17, v17, v7
    18fc:      	stp	q6, q7, [x9]
    1900:      	fadd.4s	v16, v16, v6
    1904:      	dup.2d	v6, x16
    1908:      	add.2d	v3, v3, v6
    190c:      	add.2d	v2, v2, v6
    1910:      	add.2d	v1, v1, v6
    1914:      	add.2d	v4, v4, v6
    1918:      	fmov	x2, d4
    191c:      	cmp	x2, #0x200
    1920:      	b.lt	0x107c <ltmp0+0x107c>
    1924:      	mov	x14, #0x0               ; =0
    1928:      	ldr	q0, [sp, #0x20]
    192c:      	fmov	x9, d0
    1930:      	ldr	b0, [x9]
    1934:      	cmeq.8b	v0, v0, #0
    1938:      	sshll.8h	v0, v0, #0x0
    193c:      	sshll.4s	v0, v0, #0x0
    1940:      	ldr	q1, [x13]
    1944:      	ldr	q2, [sp, #0x130]
    1948:      	fsub.4s	v2, v1, v2
    194c:      	movi.2d	v1, #0000000000000000
    1950:      	mov.s	v1[0], v2[0]
    1954:      	mov	w9, #-0x3d300000        ; =-1026555904
    1958:      	dup.4s	v2, w9
    195c:      	fcmge.4s	v3, v1, v2
    1960:      	mov	w9, #0x42c80000         ; =1120403456
    1964:      	dup.4s	v4, w9
    1968:      	fcmge.4s	v5, v4, v1
    196c:      	and.16b	v3, v3, v5
    1970:      	and.16b	v3, v3, v1
    1974:      	mov	w9, #0xaa3b             ; =43579
    1978:      	movk	w9, #0x3fb8, lsl #16
    197c:      	dup.4s	v5, w9
    1980:      	fmul.4s	v5, v3, v5
    1984:      	movi.4s	v6, #0x4b, lsl #24
    1988:      	mvni.4s	v7, #0x80, lsl #24
    198c:      	bif.16b	v6, v5, v7
    1990:      	fadd.4s	v5, v5, v6
    1994:      	fsub.4s	v5, v5, v6
    1998:      	fcvtzs.4s	v5, v5
    199c:      	scvtf.4s	v6, v5
    19a0:      	mov	w9, #0x7200             ; =29184
    19a4:      	movk	w9, #0xbf31, lsl #16
    19a8:      	dup.4s	v7, w9
    19ac:      	fmul.4s	v7, v6, v7
    19b0:      	fadd.4s	v3, v3, v7
    19b4:      	mov	w9, #0xbe8e             ; =48782
    19b8:      	movk	w9, #0xb5bf, lsl #16
    19bc:      	dup.4s	v7, w9
    19c0:      	fmul.4s	v6, v6, v7
    19c4:      	mov	w9, #0x2bda             ; =11226
    19c8:      	movk	w9, #0x3950, lsl #16
    19cc:      	dup.4s	v7, w9
    19d0:      	fadd.4s	v3, v3, v6
    19d4:      	fmul.4s	v6, v3, v7
    19d8:      	mov	w9, #0x96c9             ; =38601
    19dc:      	movk	w9, #0x3ab6, lsl #16
    19e0:      	dup.4s	v7, w9
    19e4:      	fadd.4s	v6, v6, v7
    19e8:      	fmul.4s	v6, v3, v6
    19ec:      	mov	w9, #0x88a6             ; =34982
    19f0:      	movk	w9, #0x3c08, lsl #16
    19f4:      	dup.4s	v7, w9
    19f8:      	fadd.4s	v6, v6, v7
    19fc:      	fmul.4s	v6, v3, v6
    1a00:      	mov	w9, #0xaa7a             ; =43642
    1a04:      	movk	w9, #0x3d2a, lsl #16
    1a08:      	dup.4s	v7, w9
    1a0c:      	fadd.4s	v6, v6, v7
    1a10:      	fmul.4s	v6, v3, v6
    1a14:      	mov	w9, #0xaaab             ; =43691
    1a18:      	movk	w9, #0x3e2a, lsl #16
    1a1c:      	dup.4s	v7, w9
    1a20:      	fadd.4s	v6, v6, v7
    1a24:      	fmul.4s	v6, v3, v6
    1a28:      	movi.4s	v7, #0x3f, lsl #24
    1a2c:      	fadd.4s	v6, v6, v7
    1a30:      	fmul.4s	v7, v3, v3
    1a34:      	fmul.4s	v6, v7, v6
    1a38:      	fadd.4s	v3, v3, v6
    1a3c:      	fadd.4s	v3, v3, v23
    1a40:      	sshr.4s	v6, v5, #0x1
    1a44:      	shl.4s	v7, v6, #0x17
    1a48:      	add.4s	v7, v7, v23
    1a4c:      	fmul.4s	v3, v3, v7
    1a50:      	sub.4s	v5, v5, v6
    1a54:      	shl.4s	v5, v5, #0x17
    1a58:      	add.4s	v5, v5, v23
    1a5c:      	fmul.4s	v3, v3, v5
    1a60:      	fcmgt.4s	v2, v2, v1
    1a64:      	bic.16b	v2, v3, v2
    1a68:      	fcmgt.4s	v3, v1, v4
    1a6c:      	mvni.4s	v4, #0x7f, msl #16
    1a70:      	fneg.4s	v4, v4
    1a74:      	bit.16b	v2, v4, v3
    1a78:      	fcmeq.4s	v1, v1, v1
    1a7c:      	mvni.4s	v3, #0x3f, msl #16
    1a80:      	fneg.4s	v3, v3
    1a84:      	bsl.16b	v1, v2, v3
    1a88:      	mov	w10, #0x5088            ; =20616
    1a8c:      	movk	w10, #0x1, lsl #16
    1a90:      	ldr	q2, [x8, x10]
    1a94:      	bic.16b	v0, v1, v0
    1a98:      	mov.s	v2[0], v0[0]
    1a9c:      	str	q2, [x8, x10]
    1aa0:      	ldr	q1, [sp, #0x240]
    1aa4:      	fadd.4s	v0, v1, v0
    1aa8:      	mov.s	v1[0], v0[0]
    1aac:      	ldp	q2, q0, [sp, #0x210]
    1ab0:      	fadd.4s	v0, v0, v1
    1ab4:      	ldr	q1, [sp, #0x230]
    1ab8:      	fadd.4s	v1, v2, v1
    1abc:      	fadd.4s	v0, v20, v0
    1ac0:      	fadd.4s	v1, v29, v1
    1ac4:      	fadd.4s	v0, v16, v0
    1ac8:      	fadd.4s	v1, v17, v1
    1acc:      	rev64.4s	v2, v0
    1ad0:      	rev64.4s	v3, v1
    1ad4:      	fadd.4s	v0, v0, v2
    1ad8:      	fadd.4s	v1, v1, v3
    1adc:      	dup.4s	v2, v0[2]
    1ae0:      	dup.4s	v3, v1[2]
    1ae4:      	fadd.4s	v0, v0, v2
    1ae8:      	fadd.4s	v1, v1, v3
    1aec:      	fadd.4s	v0, v0, v1
    1af0:      	movi	d1, #0000000000000000
    1af4:      	fadd	s0, s0, s1
    1af8:      	dup.4s	v1, v0[0]
    1afc:      	ldr	x11, [sp, #0x18]
    1b00:      	ldr	x9, [sp, #0x8]
    1b04:      	add	x12, x11, x9
    1b08:      	add	x9, x15, x14
    1b0c:      	ldp	q3, q2, [x9]
    1b10:      	fdiv.4s	v3, v3, v1
    1b14:      	fdiv.4s	v2, v2, v1
    1b18:      	add	x9, x12, x14
    1b1c:      	stp	q3, q2, [x9]
    1b20:      	add	x14, x14, #0x20
    1b24:      	cmp	x14, #0x4, lsl #12      ; =0x4000
    1b28:      	b.ne	0x1b08 <ltmp0+0x1b08>
    1b2c:      	ldr	q1, [x8, x10]
    1b30:      	fdiv.4s	v0, v1, v0
    1b34:      	ldr	x8, [sp, #0x10]
    1b38:      	str	s0, [x11, x8]
    1b3c:      	add	sp, sp, #0x290
    1b40:      	ldp	x29, x30, [sp, #0x90]
    1b44:      	ldp	x20, x19, [sp, #0x80]
    1b48:      	ldp	x22, x21, [sp, #0x70]
    1b4c:      	ldp	x24, x23, [sp, #0x60]
    1b50:      	ldp	x26, x25, [sp, #0x50]
    1b54:      	ldp	x28, x27, [sp, #0x40]
    1b58:      	ldp	d9, d8, [sp, #0x30]
    1b5c:      	ldp	d11, d10, [sp, #0x20]
    1b60:      	ldp	d13, d12, [sp, #0x10]
    1b64:      	ldp	d15, d14, [sp], #0xa0
    1b68:      	ret

0000000000001b6c <_llm_rows.packet_batch.blocks>:
    1b6c:      	cbz	w3, 0x5900 <_llm_rows.packet_batch.blocks+0x3d94>
    1b70:      	stp	d15, d14, [sp, #-0xa0]!
    1b74:      	stp	d13, d12, [sp, #0x10]
    1b78:      	stp	d11, d10, [sp, #0x20]
    1b7c:      	stp	d9, d8, [sp, #0x30]
    1b80:      	stp	x28, x27, [sp, #0x40]
    1b84:      	stp	x26, x25, [sp, #0x50]
    1b88:      	stp	x24, x23, [sp, #0x60]
    1b8c:      	stp	x22, x21, [sp, #0x70]
    1b90:      	stp	x20, x19, [sp, #0x80]
    1b94:      	stp	x29, x30, [sp, #0x90]
    1b98:      	sub	sp, sp, #0xb00
    1b9c:      	mov	x19, x3
    1ba0:      	mov	x20, x2
    1ba4:      	mov	x21, x0
    1ba8:      	mov	w22, #0x0               ; =0
    1bac:      	ldp	w9, w8, [x2, #0x2c]
    1bb0:      	str	w9, [sp, #0x1bc]
    1bb4:      	str	w8, [sp, #0x1b8]
    1bb8:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1bbc:      	ldr	q0, [x8]
    1bc0:      	str	q0, [sp, #0x40]
    1bc4:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1bc8:      	ldr	q0, [x8]
    1bcc:      	str	q0, [sp, #0x190]
    1bd0:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1bd4:      	ldr	q0, [x8]
    1bd8:      	str	q0, [sp, #0x180]
    1bdc:      	mov	w8, #0x40               ; =64
    1be0:      	fmov	d0, x8
    1be4:      	str	q0, [sp, #0x30]
    1be8:      	mov	w8, #0x60               ; =96
    1bec:      	fmov	d0, x8
    1bf0:      	str	q0, [sp, #0x20]
    1bf4:      	mvni.4s	v0, #0x7f, msl #16
    1bf8:      	fneg.4s	v0, v0
    1bfc:      	str	q0, [sp, #0x410]
    1c00:      	mvni.4s	v0, #0x3f, msl #16
    1c04:      	fneg.4s	v0, v0
    1c08:      	str	q0, [sp, #0x400]
    1c0c:      	ldp	w25, w24, [x2]
    1c10:      	ldp	w28, w23, [x2, #0x8]
    1c14:      	mov	w26, #0x4               ; =4
    1c18:      	stp	x23, x0, [sp, #0x10]
    1c1c:      	str	w3, [sp, #0x17c]
    1c20:      	b	0x1c6c <_llm_rows.packet_batch.blocks+0x100>
    1c24:      	mov	w8, #0x18               ; =24
    1c28:      	str	w8, [x20, #0x24]
    1c2c:      	ldr	w19, [sp, #0x17c]
    1c30:      	add	w8, w25, #0x1
    1c34:      	ldr	w9, [sp, #0x1bc]
    1c38:      	cmp	w8, w9
    1c3c:      	cset	w8, eq
    1c40:      	csinc	w25, wzr, w25, eq
    1c44:      	cinc	w9, w24, eq
    1c48:      	ldr	w10, [sp, #0x1b8]
    1c4c:      	cmp	w9, w10
    1c50:      	cset	w10, eq
    1c54:      	ands	w8, w8, w10
    1c58:      	csel	w24, wzr, w9, ne
    1c5c:      	add	w28, w28, w8
    1c60:      	add	w22, w22, #0x1
    1c64:      	cmp	w22, w19
    1c68:      	b.eq	0x58d4 <_llm_rows.packet_batch.blocks+0x3d68>
    1c6c:      	ubfiz	x8, x25, #5, #32
    1c70:      	cmp	x8, x23
    1c74:      	csel	x9, x8, xzr, ls
    1c78:      	subs	x10, x23, x9
    1c7c:      	cmp	x10, #0x20
    1c80:      	mov	w11, #0x20              ; =32
    1c84:      	csel	x10, x10, x11, lo
    1c88:      	cmp	x23, x9
    1c8c:      	stp	w25, w24, [x20]
    1c90:      	str	w28, [x20, #0x8]
    1c94:      	str	wzr, [x20, #0x24]
    1c98:      	ccmp	x8, x23, #0x2, hi
    1c9c:      	csel	x27, x10, xzr, ls
    1ca0:      	cmp	x27, #0x20
    1ca4:      	b.lo	0x1cf4 <_llm_rows.packet_batch.blocks+0x188>
    1ca8:      	mov	x0, x21
    1cac:      	mov	x1, x20
    1cb0:      	bl	0x1cb0 <_llm_rows.packet_batch.blocks+0x144>
    1cb4:      	mov	w8, #0x8                ; =8
    1cb8:      	str	w8, [x20, #0x24]
    1cbc:      	mov	x0, x21
    1cc0:      	mov	x1, x20
    1cc4:      	bl	0x1cc4 <_llm_rows.packet_batch.blocks+0x158>
    1cc8:      	mov	w8, #0x10               ; =16
    1ccc:      	str	w8, [x20, #0x24]
    1cd0:      	mov	x0, x21
    1cd4:      	mov	x1, x20
    1cd8:      	bl	0x1cd8 <_llm_rows.packet_batch.blocks+0x16c>
    1cdc:      	mov	w8, #0x18               ; =24
    1ce0:      	str	w8, [x20, #0x24]
    1ce4:      	mov	x0, x21
    1ce8:      	mov	x1, x20
    1cec:      	bl	0x1cec <_llm_rows.packet_batch.blocks+0x180>
    1cf0:      	b	0x1c30 <_llm_rows.packet_batch.blocks+0xc4>
    1cf4:      	lsr	x19, x27, #3
    1cf8:      	cmp	x27, #0x8
    1cfc:      	b.lo	0x1d48 <_llm_rows.packet_batch.blocks+0x1dc>
    1d00:      	str	wzr, [x20, #0x24]
    1d04:      	mov	x0, x21
    1d08:      	mov	x1, x20
    1d0c:      	bl	0x1d0c <_llm_rows.packet_batch.blocks+0x1a0>
    1d10:      	cmp	x19, #0x1
    1d14:      	b.eq	0x1d48 <_llm_rows.packet_batch.blocks+0x1dc>
    1d18:      	mov	w8, #0x8                ; =8
    1d1c:      	str	w8, [x20, #0x24]
    1d20:      	mov	x0, x21
    1d24:      	mov	x1, x20
    1d28:      	bl	0x1d28 <_llm_rows.packet_batch.blocks+0x1bc>
    1d2c:      	cmp	x19, #0x2
    1d30:      	b.eq	0x1d48 <_llm_rows.packet_batch.blocks+0x1dc>
    1d34:      	mov	w8, #0x10               ; =16
    1d38:      	str	w8, [x20, #0x24]
    1d3c:      	mov	x0, x21
    1d40:      	mov	x1, x20
    1d44:      	bl	0x1d44 <_llm_rows.packet_batch.blocks+0x1d8>
    1d48:      	and	w8, w27, #0x7
    1d4c:      	cbz	w8, 0x1c24 <_llm_rows.packet_batch.blocks+0xb8>
    1d50:      	dup.4s	v3, w8
    1d54:      	ldp	q0, q1, [sp, #0x180]
    1d58:      	cmhi.4s	v0, v3, v0
    1d5c:      	cmhi.4s	v1, v3, v1
    1d60:      	uzp1.8h	v5, v1, v0
    1d64:      	umaxv.8h	h2, v5
    1d68:      	fmov	w8, s2
    1d6c:      	tbz	w8, #0x0, 0x1c24 <_llm_rows.packet_batch.blocks+0xb8>
    1d70:      	mov	x10, #0x0               ; =0
    1d74:      	ldr	x13, [x20, #0x88]
    1d78:      	mov	w8, #0x1088             ; =4232
    1d7c:      	movk	w8, #0x1, lsl #16
    1d80:      	add	x9, x13, x8
    1d84:      	mov	w8, #0xd068             ; =53352
    1d88:      	add	x12, x13, x8
    1d8c:      	mov	w8, #0x4020             ; =16416
    1d90:      	add	x8, x13, x8
    1d94:      	mov	w11, #0xc060            ; =49248
    1d98:      	add	x11, x13, x11
    1d9c:      	dup.2d	v4, x11
    1da0:      	ldr	x11, [x21]
    1da4:      	ldr	x14, [x21, #0x30]
    1da8:      	str	x14, [sp, #0x170]
    1dac:      	ldr	q2, [sp, #0x40]
    1db0:      	str	q5, [sp, #0x3c0]
    1db4:      	and.16b	v2, v5, v2
    1db8:      	addv.8h	h21, v2
    1dbc:      	fmov	w14, s21
    1dc0:      	and	w14, w14, #0xff
    1dc4:      	str	w14, [sp, #0x3d0]
    1dc8:      	ubfiz	w14, w25, #2, #27
    1dcc:      	orr	w14, w14, w19
    1dd0:      	dup.4s	v2, w14
    1dd4:      	and.16b	v17, v1, v2
    1dd8:      	and.16b	v2, v0, v2
    1ddc:      	ushll2.2d	v19, v2, #0x0
    1de0:      	ushll2.2d	v20, v17, #0x0
    1de4:      	ushll.2d	v22, v2, #0x0
    1de8:      	ushll.2d	v6, v17, #0x0
    1dec:      	fmov	x14, d6
    1df0:      	mov	w15, #0x4004            ; =16388
    1df4:      	umaddl	x14, w14, w15, x11
    1df8:      	fmov	w15, s21
    1dfc:      	b	0x1e20 <_llm_rows.packet_batch.blocks+0x2b4>
    1e00:      	add	x16, x13, x10
    1e04:      	ldp	q16, q18, [x16]
    1e08:      	bif.16b	v7, v18, v0
    1e0c:      	bif.16b	v5, v16, v1
    1e10:      	stp	q5, q7, [x16]
    1e14:      	add	x10, x10, #0x20
    1e18:      	cmp	x10, #0x4, lsl #12      ; =0x4000
    1e1c:      	b.eq	0x1eb4 <_llm_rows.packet_batch.blocks+0x348>
    1e20:      	add	x16, x14, x10
    1e24:      	movi.2d	v5, #0000000000000000
    1e28:      	movi.2d	v7, #0000000000000000
    1e2c:      	tbnz	w15, #0x0, 0x1e54 <_llm_rows.packet_batch.blocks+0x2e8>
    1e30:      	and	w17, w15, #0xff
    1e34:      	tbnz	w17, #0x1, 0x1e60 <_llm_rows.packet_batch.blocks+0x2f4>
    1e38:      	tbnz	w17, #0x2, 0x1e6c <_llm_rows.packet_batch.blocks+0x300>
    1e3c:      	tbnz	w17, #0x3, 0x1e78 <_llm_rows.packet_batch.blocks+0x30c>
    1e40:      	tbnz	w17, #0x4, 0x1e84 <_llm_rows.packet_batch.blocks+0x318>
    1e44:      	tbnz	w17, #0x5, 0x1e90 <_llm_rows.packet_batch.blocks+0x324>
    1e48:      	tbnz	w17, #0x6, 0x1e9c <_llm_rows.packet_batch.blocks+0x330>
    1e4c:      	tbz	w17, #0x7, 0x1e00 <_llm_rows.packet_batch.blocks+0x294>
    1e50:      	b	0x1ea8 <_llm_rows.packet_batch.blocks+0x33c>
    1e54:      	ldr	s5, [x16]
    1e58:      	and	w17, w15, #0xff
    1e5c:      	tbz	w17, #0x1, 0x1e38 <_llm_rows.packet_batch.blocks+0x2cc>
    1e60:      	add	x0, x16, #0x4
    1e64:      	ld1.s	{ v5 }[1], [x0]
    1e68:      	tbz	w17, #0x2, 0x1e3c <_llm_rows.packet_batch.blocks+0x2d0>
    1e6c:      	add	x0, x16, #0x8
    1e70:      	ld1.s	{ v5 }[2], [x0]
    1e74:      	tbz	w17, #0x3, 0x1e40 <_llm_rows.packet_batch.blocks+0x2d4>
    1e78:      	add	x0, x16, #0xc
    1e7c:      	ld1.s	{ v5 }[3], [x0]
    1e80:      	tbz	w17, #0x4, 0x1e44 <_llm_rows.packet_batch.blocks+0x2d8>
    1e84:      	add	x0, x16, #0x10
    1e88:      	ld1.s	{ v7 }[0], [x0]
    1e8c:      	tbz	w17, #0x5, 0x1e48 <_llm_rows.packet_batch.blocks+0x2dc>
    1e90:      	add	x0, x16, #0x14
    1e94:      	ld1.s	{ v7 }[1], [x0]
    1e98:      	tbz	w17, #0x6, 0x1e4c <_llm_rows.packet_batch.blocks+0x2e0>
    1e9c:      	add	x0, x16, #0x18
    1ea0:      	ld1.s	{ v7 }[2], [x0]
    1ea4:      	tbz	w17, #0x7, 0x1e00 <_llm_rows.packet_batch.blocks+0x294>
    1ea8:      	add	x16, x16, #0x1c
    1eac:      	ld1.s	{ v7 }[3], [x16]
    1eb0:      	b	0x1e00 <_llm_rows.packet_batch.blocks+0x294>
    1eb4:      	xtn.4h	v5, v1
    1eb8:      	uzp1.8b	v7, v5, v0
    1ebc:      	sshll.2d	v5, v1, #0x0
    1ec0:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    1ec4:      	ldr	q23, [x10]
    1ec8:      	and.16b	v16, v5, v23
    1ecc:      	movi.2d	v24, #0000000000000000
    1ed0:      	mov.b	v24[0], v7[0]
    1ed4:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    1ed8:      	ldr	d18, [x10]
    1edc:      	str	d18, [sp, #0x3f0]
    1ee0:      	and.8b	v18, v24, v18
    1ee4:      	addv.8b	b18, v18
    1ee8:      	fmov	w14, s18
    1eec:      	str	q24, [sp, #0x1c0]
    1ef0:      	umaxv.8b	b18, v24
    1ef4:      	fmov	w10, s18
    1ef8:      	rbit	w15, w14
    1efc:      	clz	w15, w15
    1f00:      	tst	w10, #0x1
    1f04:      	csel	w6, w15, wzr, ne
    1f08:      	mov	w15, #0x1000            ; =4096
    1f0c:      	dup.2d	v25, x15
    1f10:      	str	q16, [sp, #0x3b0]
    1f14:      	orr.16b	v18, v16, v25
    1f18:      	mov	w15, #0x1001            ; =4097
    1f1c:      	dup.2s	v27, w15
    1f20:      	xtn.2s	v28, v6
    1f24:      	mov.16b	v24, v18
    1f28:      	umlal.2d	v24, v28, v27
    1f2c:      	movi.2d	v6, #0000000000000000
    1f30:      	mov.b	v6[0], v7[0]
    1f34:      	ushll.2d	v6, v6, #0x0
    1f38:      	shl.2d	v6, v6, #0x3f
    1f3c:      	cmlt.2d	v6, v6, #0
    1f40:      	str	q24, [sp, #0x160]
    1f44:      	and.16b	v6, v6, v24
    1f48:      	movi.2d	v7, #0000000000000000
    1f4c:      	str	q7, [sp, #0xae0]
    1f50:      	str	q7, [sp, #0xad0]
    1f54:      	str	q7, [sp, #0xac0]
    1f58:      	str	q6, [sp, #0xab0]
    1f5c:      	and	x15, x6, #0x7
    1f60:      	add	x16, sp, #0xab0
    1f64:      	ldr	x15, [x16, x15, lsl #3]
    1f68:      	sub	x15, x15, x6
    1f6c:      	add	x11, x11, x15, lsl #2
    1f70:      	movi.2d	v6, #0000000000000000
    1f74:      	tbnz	w10, #0x0, 0x261c <_llm_rows.packet_batch.blocks+0xab0>
    1f78:      	tbnz	w14, #0x1, 0x2624 <_llm_rows.packet_batch.blocks+0xab8>
    1f7c:      	tbnz	w14, #0x2, 0x2630 <_llm_rows.packet_batch.blocks+0xac4>
    1f80:      	tbnz	w14, #0x3, 0x263c <_llm_rows.packet_batch.blocks+0xad0>
    1f84:      	tbnz	w14, #0x4, 0x2648 <_llm_rows.packet_batch.blocks+0xadc>
    1f88:      	tbnz	w14, #0x5, 0x2654 <_llm_rows.packet_batch.blocks+0xae8>
    1f8c:      	tbnz	w14, #0x6, 0x2660 <_llm_rows.packet_batch.blocks+0xaf4>
    1f90:      	str	q21, [sp, #0x360]
    1f94:      	tbz	w14, #0x7, 0x1fa0 <_llm_rows.packet_batch.blocks+0x434>
    1f98:      	add	x10, x11, #0x1c
    1f9c:      	ld1.s	{ v7 }[3], [x10]
    1fa0:      	mov	x15, #0x0               ; =0
    1fa4:      	sshll.2d	v24, v0, #0x0
    1fa8:      	sshll2.2d	v31, v1, #0x0
    1fac:      	sshll2.2d	v16, v0, #0x0
    1fb0:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    1fb4:      	ldr	q21, [x10]
    1fb8:      	and.16b	v26, v16, v21
    1fbc:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    1fc0:      	ldr	q21, [x10]
    1fc4:      	and.16b	v29, v31, v21
    1fc8:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    1fcc:      	ldr	q21, [x10]
    1fd0:      	and.16b	v30, v24, v21
    1fd4:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    1fd8:      	ldr	q21, [x10]
    1fdc:      	and.16b	v21, v5, v21
    1fe0:      	str	q21, [sp, #0xa70]
    1fe4:      	str	q29, [sp, #0xa80]
    1fe8:      	str	q30, [sp, #0xa90]
    1fec:      	str	q26, [sp, #0xaa0]
    1ff0:      	and	x10, x6, #0x7
    1ff4:      	add	x11, sp, #0xa70
    1ff8:      	ldr	x10, [x11, x10, lsl #3]
    1ffc:      	orr	x10, x10, #0x4000
    2000:      	sub	x10, x10, x6, lsl #2
    2004:      	tst	w14, #0xff
    2008:      	csel	x10, xzr, x10, eq
    200c:      	str	x10, [sp, #0x1b0]
    2010:      	add	x10, x13, x10
    2014:      	ldp	q5, q26, [x10]
    2018:      	ldr	q30, [sp, #0x1c0]
    201c:      	zip2.8b	v29, v30, v0
    2020:      	ushll.4s	v29, v29, #0x0
    2024:      	shl.4s	v29, v29, #0x1f
    2028:      	cmlt.4s	v29, v29, #0
    202c:      	bif.16b	v7, v26, v29
    2030:      	zip1.8b	v26, v30, v0
    2034:      	ushll.4s	v26, v26, #0x0
    2038:      	shl.4s	v26, v26, #0x1f
    203c:      	cmlt.4s	v26, v26, #0
    2040:      	bit.16b	v5, v6, v26
    2044:      	stp	q5, q7, [x10]
    2048:      	adrp	x10, 0x2000 <_llm_rows.packet_batch.blocks+0x494>
    204c:      	ldr	q5, [x10]
    2050:      	and.16b	v6, v16, v5
    2054:      	adrp	x10, 0x2000 <_llm_rows.packet_batch.blocks+0x494>
    2058:      	ldr	q29, [x10]
    205c:      	and.16b	v7, v31, v29
    2060:      	adrp	x10, 0x2000 <_llm_rows.packet_batch.blocks+0x494>
    2064:      	ldr	q30, [x10]
    2068:      	and.16b	v24, v24, v30
    206c:      	stp	q24, q7, [sp, #0x380]
    2070:      	orr.16b	v24, v24, v25
    2074:      	orr.16b	v26, v7, v25
    2078:      	str	q6, [sp, #0x3a0]
    207c:      	orr.16b	v25, v6, v25
    2080:      	umull.2d	v7, v28, v27
    2084:      	xtn.2s	v20, v20
    2088:      	xtn.2s	v22, v22
    208c:      	xtn.2s	v19, v19
    2090:      	mov.16b	v6, v25
    2094:      	umlal.2d	v6, v19, v27
    2098:      	str	q6, [sp, #0x150]
    209c:      	mov.16b	v6, v26
    20a0:      	umlal.2d	v6, v20, v27
    20a4:      	str	q6, [sp, #0x140]
    20a8:      	mov.16b	v6, v24
    20ac:      	umlal.2d	v6, v22, v27
    20b0:      	stp	q7, q6, [sp, #0x120]
    20b4:      	mov.16b	v6, v31
    20b8:      	mov	w10, #0x1               ; =1
    20bc:      	dup.2d	v19, x10
    20c0:      	ushll2.2d	v20, v0, #0x0
    20c4:      	and.16b	v7, v20, v19
    20c8:      	ushll2.2d	v20, v1, #0x0
    20cc:      	and.16b	v31, v20, v19
    20d0:      	ushll.2d	v20, v0, #0x0
    20d4:      	and.16b	v8, v20, v19
    20d8:      	ushll.2d	v20, v1, #0x0
    20dc:      	and.16b	v10, v20, v19
    20e0:      	movi.2d	v19, #0000000000000000
    20e4:      	movi.2d	v20, #0000000000000000
    20e8:      	movi.2d	v22, #0000000000000000
    20ec:      	movi.2d	v27, #0000000000000000
    20f0:      	stp	q31, q7, [sp, #0x1f0]
    20f4:      	stp	q10, q8, [sp, #0x1d0]
    20f8:      	sshll.2d	v28, v0, #0x0
    20fc:      	sshll.2d	v31, v1, #0x0
    2100:      	shl.2d	v8, v27, #0x3
    2104:      	shl.2d	v9, v19, #0x3
    2108:      	shl.2d	v10, v22, #0x3
    210c:      	shl.2d	v11, v20, #0x3
    2110:      	orr.16b	v11, v11, v29
    2114:      	orr.16b	v10, v10, v30
    2118:      	orr.16b	v9, v9, v23
    211c:      	orr.16b	v8, v8, v5
    2120:      	add	x10, x8, x15, lsl #6
    2124:      	ldp	q13, q12, [x10]
    2128:      	ldp	q14, q15, [x10, #0x20]
    212c:      	bif.16b	v8, v15, v16
    2130:      	bsl.16b	v31, v9, v13
    2134:      	bsl.16b	v28, v10, v14
    2138:      	mov.16b	v9, v6
    213c:      	bsl.16b	v9, v11, v12
    2140:      	stp	q31, q9, [x10]
    2144:      	stp	q28, q8, [x10, #0x20]
    2148:      	ldp	q10, q8, [sp, #0x1d0]
    214c:      	ldp	q31, q7, [sp, #0x1f0]
    2150:      	add.2d	v20, v20, v31
    2154:      	add.2d	v22, v22, v8
    2158:      	add.2d	v27, v27, v7
    215c:      	add.2d	v19, v19, v10
    2160:      	fmov	x15, d19
    2164:      	cmp	x15, #0x200
    2168:      	b.lt	0x20f8 <_llm_rows.packet_batch.blocks+0x58c>
    216c:      	mov	x15, #0x0               ; =0
    2170:      	mov	w10, #0x1001            ; =4097
    2174:      	dup.4s	v5, w10
    2178:      	and.16b	v19, v1, v5
    217c:      	mvn.16b	v20, v1
    2180:      	sub.4s	v19, v19, v20
    2184:      	and.16b	v5, v0, v5
    2188:      	mvn.16b	v20, v0
    218c:      	sub.4s	v5, v5, v20
    2190:      	mov.s	w10, v5[1]
    2194:      	mov.s	w11, v2[1]
    2198:      	udiv	w16, w11, w10
    219c:      	msub	w11, w16, w10, w11
    21a0:      	mov.s	w10, v5[2]
    21a4:      	mov.s	w16, v5[3]
    21a8:      	fmov	w17, s5
    21ac:      	fmov	w0, s2
    21b0:      	udiv	w1, w0, w17
    21b4:      	msub	w17, w1, w17, w0
    21b8:      	mov.s	w0, v2[2]
    21bc:      	udiv	w1, w0, w10
    21c0:      	msub	w0, w1, w10, w0
    21c4:      	mov.s	w10, v2[3]
    21c8:      	udiv	w1, w10, w16
    21cc:      	msub	w16, w1, w16, w10
    21d0:      	mov.s	w10, v19[1]
    21d4:      	mov.s	w1, v17[1]
    21d8:      	udiv	w2, w1, w10
    21dc:      	msub	w1, w2, w10, w1
    21e0:      	mov.s	w10, v19[2]
    21e4:      	mov.s	w2, v19[3]
    21e8:      	fmov	w3, s19
    21ec:      	fmov	w4, s17
    21f0:      	udiv	w5, w4, w3
    21f4:      	msub	w3, w5, w3, w4
    21f8:      	mov.s	w4, v17[2]
    21fc:      	udiv	w5, w4, w10
    2200:      	msub	w10, w5, w10, w4
    2204:      	mov.s	w4, v17[3]
    2208:      	udiv	w5, w4, w2
    220c:      	msub	w2, w5, w2, w4
    2210:      	tst	w14, #0xff
    2214:      	fmov	s2, w17
    2218:      	mov.s	v2[1], w11
    221c:      	mov.s	v2[2], w0
    2220:      	mov.s	v2[3], w16
    2224:      	sshll.2d	v20, v0, #0x0
    2228:      	sshll.2d	v5, v1, #0x0
    222c:      	adrp	x11, 0x2000 <_llm_rows.packet_batch.blocks+0x494>
    2230:      	ldr	q17, [x11]
    2234:      	and.16b	v17, v5, v17
    2238:      	adrp	x11, 0x2000 <_llm_rows.packet_batch.blocks+0x494>
    223c:      	ldr	q19, [x11]
    2240:      	and.16b	v19, v20, v19
    2244:      	adrp	x11, 0x2000 <_llm_rows.packet_batch.blocks+0x494>
    2248:      	ldr	q22, [x11]
    224c:      	and.16b	v22, v6, v22
    2250:      	adrp	x11, 0x2000 <_llm_rows.packet_batch.blocks+0x494>
    2254:      	ldr	q23, [x11]
    2258:      	and.16b	v23, v16, v23
    225c:      	str	q23, [sp, #0xa60]
    2260:      	str	q19, [sp, #0xa50]
    2264:      	str	q22, [sp, #0xa40]
    2268:      	str	q17, [sp, #0xa30]
    226c:      	fmov	s17, w3
    2270:      	and	x11, x6, #0x7
    2274:      	add	x14, sp, #0xa30
    2278:      	ldr	x11, [x14, x11, lsl #3]
    227c:      	orr	x11, x11, #0x8000
    2280:      	sub	x11, x11, x6, lsl #3
    2284:      	csel	x14, xzr, x11, eq
    2288:      	mov.s	v17[1], w1
    228c:      	add	x11, x8, x14
    2290:      	ldp	q19, q22, [x11, #0x20]
    2294:      	mov.16b	v29, v6
    2298:      	ldr	q6, [sp, #0x1c0]
    229c:      	mov	b23, v6[2]
    22a0:      	mov.b	v23[4], v6[3]
    22a4:      	ldp	q27, q28, [x11]
    22a8:      	ushll.2d	v23, v23, #0x0
    22ac:      	shl.2d	v23, v23, #0x3f
    22b0:      	cmlt.2d	v23, v23, #0
    22b4:      	bsl.16b	v23, v26, v28
    22b8:      	mov	b26, v6[0]
    22bc:      	mov.b	v26[4], v6[1]
    22c0:      	ushll.2d	v26, v26, #0x0
    22c4:      	shl.2d	v26, v26, #0x3f
    22c8:      	cmlt.2d	v26, v26, #0
    22cc:      	bif.16b	v18, v27, v26
    22d0:      	mov	b26, v6[6]
    22d4:      	mov.b	v26[4], v6[7]
    22d8:      	ushll.2d	v26, v26, #0x0
    22dc:      	shl.2d	v26, v26, #0x3f
    22e0:      	cmlt.2d	v26, v26, #0
    22e4:      	bit.16b	v22, v25, v26
    22e8:      	mov	b25, v6[4]
    22ec:      	mov.b	v25[4], v6[5]
    22f0:      	ushll.2d	v25, v25, #0x0
    22f4:      	shl.2d	v25, v25, #0x3f
    22f8:      	cmlt.2d	v25, v25, #0
    22fc:      	bit.16b	v19, v24, v25
    2300:      	mov.s	v17[2], w10
    2304:      	mov.s	v17[3], w2
    2308:      	and.16b	v24, v1, v17
    230c:      	stp	q19, q22, [x11, #0x20]
    2310:      	stp	q18, q23, [x11]
    2314:      	and.16b	v17, v0, v2
    2318:      	ushll2.2d	v2, v17, #0x0
    231c:      	ushll2.2d	v18, v24, #0x0
    2320:      	ushll.2d	v17, v17, #0x0
    2324:      	ushll.2d	v19, v24, #0x0
    2328:      	and.16b	v6, v16, v4
    232c:      	str	q6, [sp, #0x450]
    2330:      	and.16b	v6, v29, v4
    2334:      	str	q6, [sp, #0x440]
    2338:      	and.16b	v6, v20, v4
    233c:      	str	q6, [sp, #0x430]
    2340:      	and.16b	v4, v5, v4
    2344:      	str	q4, [sp, #0x420]
    2348:      	adrp	x10, 0x2000 <_llm_rows.packet_batch.blocks+0x494>
    234c:      	ldr	q4, [x10]
    2350:      	and.16b	v4, v16, v4
    2354:      	str	q4, [sp, #0x350]
    2358:      	adrp	x10, 0x2000 <_llm_rows.packet_batch.blocks+0x494>
    235c:      	ldr	q4, [x10]
    2360:      	str	q29, [sp, #0x310]
    2364:      	and.16b	v4, v29, v4
    2368:      	str	q4, [sp, #0x340]
    236c:      	adrp	x10, 0x2000 <_llm_rows.packet_batch.blocks+0x494>
    2370:      	ldr	q4, [x10]
    2374:      	and.16b	v4, v20, v4
    2378:      	str	q4, [sp, #0x330]
    237c:      	adrp	x10, 0x2000 <_llm_rows.packet_batch.blocks+0x494>
    2380:      	ldr	q4, [x10]
    2384:      	and.16b	v4, v5, v4
    2388:      	str	q4, [sp, #0x320]
    238c:      	ldp	q4, q5, [sp, #0x180]
    2390:      	cmhs.4s	v4, v4, v3
    2394:      	cmhs.4s	v3, v5, v3
    2398:      	uzp1.8h	v3, v3, v4
    239c:      	xtn.8b	v3, v3
    23a0:      	movi.2d	v4, #0000000000000000
    23a4:      	movi.2d	v5, #0000000000000000
    23a8:      	movi.2d	v20, #0000000000000000
    23ac:      	movi.2d	v22, #0000000000000000
    23b0:      	movi.8b	v6, #0x1
    23b4:      	ldr	q14, [sp, #0x360]
    23b8:      	mov.16b	v28, v16
    23bc:      	b	0x23dc <_llm_rows.packet_batch.blocks+0x870>
    23c0:      	add.2d	v5, v5, v31
    23c4:      	add.2d	v20, v20, v8
    23c8:      	add.2d	v22, v22, v7
    23cc:      	add.2d	v4, v4, v10
    23d0:      	fmov	x15, d4
    23d4:      	cmp	x15, #0x200
    23d8:      	b.ge	0x2510 <_llm_rows.packet_batch.blocks+0x9a4>
    23dc:      	fmov	w10, s14
    23e0:      	add	x11, x8, x15, lsl #6
    23e4:      	ldp	q24, q23, [x11, #0x20]
    23e8:      	ldp	q25, q26, [x11]
    23ec:      	cmge.2d	v26, v18, v26
    23f0:      	cmge.2d	v25, v19, v25
    23f4:      	uzp1.4s	v25, v25, v26
    23f8:      	cmge.2d	v24, v17, v24
    23fc:      	cmge.2d	v23, v2, v23
    2400:      	uzp1.4s	v23, v24, v23
    2404:      	uzp1.8h	v23, v25, v23
    2408:      	xtn.8b	v23, v23
    240c:      	orr.8b	v23, v3, v23
    2410:      	ldr	q16, [sp, #0x320]
    2414:      	add.2d	v24, v4, v16
    2418:      	ldr	q16, [sp, #0x420]
    241c:      	add.2d	v24, v16, v24
    2420:      	and.8b	v23, v23, v6
    2424:      	tbnz	w10, #0x0, 0x247c <_llm_rows.packet_batch.blocks+0x910>
    2428:      	and	w10, w10, #0xff
    242c:      	tbnz	w10, #0x1, 0x248c <_llm_rows.packet_batch.blocks+0x920>
    2430:      	ldr	q16, [sp, #0x340]
    2434:      	add.2d	v24, v5, v16
    2438:      	ldr	q16, [sp, #0x440]
    243c:      	add.2d	v24, v16, v24
    2440:      	tbnz	w10, #0x2, 0x24a8 <_llm_rows.packet_batch.blocks+0x93c>
    2444:      	tbnz	w10, #0x3, 0x24b4 <_llm_rows.packet_batch.blocks+0x948>
    2448:      	ldr	q16, [sp, #0x330]
    244c:      	add.2d	v24, v20, v16
    2450:      	ldr	q16, [sp, #0x430]
    2454:      	add.2d	v24, v16, v24
    2458:      	tbnz	w10, #0x4, 0x24d0 <_llm_rows.packet_batch.blocks+0x964>
    245c:      	tbnz	w10, #0x5, 0x24dc <_llm_rows.packet_batch.blocks+0x970>
    2460:      	ldr	q16, [sp, #0x350]
    2464:      	add.2d	v24, v22, v16
    2468:      	ldr	q16, [sp, #0x450]
    246c:      	add.2d	v24, v16, v24
    2470:      	tbnz	w10, #0x6, 0x24f8 <_llm_rows.packet_batch.blocks+0x98c>
    2474:      	tbz	w10, #0x7, 0x23c0 <_llm_rows.packet_batch.blocks+0x854>
    2478:      	b	0x2504 <_llm_rows.packet_batch.blocks+0x998>
    247c:      	fmov	x11, d24
    2480:      	str	b23, [x11]
    2484:      	and	w10, w10, #0xff
    2488:      	tbz	w10, #0x1, 0x2430 <_llm_rows.packet_batch.blocks+0x8c4>
    248c:      	mov.d	x11, v24[1]
    2490:      	st1.b	{ v23 }[1], [x11]
    2494:      	ldr	q16, [sp, #0x340]
    2498:      	add.2d	v24, v5, v16
    249c:      	ldr	q16, [sp, #0x440]
    24a0:      	add.2d	v24, v16, v24
    24a4:      	tbz	w10, #0x2, 0x2444 <_llm_rows.packet_batch.blocks+0x8d8>
    24a8:      	fmov	x11, d24
    24ac:      	st1.b	{ v23 }[2], [x11]
    24b0:      	tbz	w10, #0x3, 0x2448 <_llm_rows.packet_batch.blocks+0x8dc>
    24b4:      	mov.d	x11, v24[1]
    24b8:      	st1.b	{ v23 }[3], [x11]
    24bc:      	ldr	q16, [sp, #0x330]
    24c0:      	add.2d	v24, v20, v16
    24c4:      	ldr	q16, [sp, #0x430]
    24c8:      	add.2d	v24, v16, v24
    24cc:      	tbz	w10, #0x4, 0x245c <_llm_rows.packet_batch.blocks+0x8f0>
    24d0:      	fmov	x11, d24
    24d4:      	st1.b	{ v23 }[4], [x11]
    24d8:      	tbz	w10, #0x5, 0x2460 <_llm_rows.packet_batch.blocks+0x8f4>
    24dc:      	mov.d	x11, v24[1]
    24e0:      	st1.b	{ v23 }[5], [x11]
    24e4:      	ldr	q16, [sp, #0x350]
    24e8:      	add.2d	v24, v22, v16
    24ec:      	ldr	q16, [sp, #0x450]
    24f0:      	add.2d	v24, v16, v24
    24f4:      	tbz	w10, #0x6, 0x2474 <_llm_rows.packet_batch.blocks+0x908>
    24f8:      	fmov	x11, d24
    24fc:      	st1.b	{ v23 }[6], [x11]
    2500:      	tbz	w10, #0x7, 0x23c0 <_llm_rows.packet_batch.blocks+0x854>
    2504:      	mov.d	x10, v24[1]
    2508:      	st1.b	{ v23 }[7], [x10]
    250c:      	b	0x23c0 <_llm_rows.packet_batch.blocks+0x854>
    2510:      	add	x8, x8, x14
    2514:      	ldp	q4, q3, [x8, #0x20]
    2518:      	ldp	q5, q20, [x8]
    251c:      	cmge.2d	v18, v18, v20
    2520:      	cmge.2d	v5, v19, v5
    2524:      	uzp1.4s	v5, v5, v18
    2528:      	cmge.2d	v4, v17, v4
    252c:      	cmge.2d	v2, v2, v3
    2530:      	uzp1.4s	v2, v4, v2
    2534:      	uzp1.8h	v2, v5, v2
    2538:      	xtn.8b	v2, v2
    253c:      	ldr	q4, [sp, #0x1c0]
    2540:      	shl.8b	v3, v4, #0x7
    2544:      	cmlt.8b	v3, v3, #0
    2548:      	ldr	d5, [sp, #0x3f0]
    254c:      	and.8b	v3, v3, v5
    2550:      	addv.8b	b3, v3
    2554:      	str	d3, [sp, #0x1a8]
    2558:      	fmov	w8, s3
    255c:      	orn.8b	v2, v2, v4
    2560:      	ldr	q3, [sp, #0x420]
    2564:      	ldr	q4, [sp, #0x320]
    2568:      	add.2d	v4, v4, v3
    256c:      	mov	w10, #0x200             ; =512
    2570:      	dup.2d	v3, x10
    2574:      	add.2d	v4, v4, v3
    2578:      	and.8b	v2, v2, v6
    257c:      	tbnz	w8, #0x0, 0x2674 <_llm_rows.packet_batch.blocks+0xb08>
    2580:      	str	q4, [sp, #0xe0]
    2584:      	mov.d	x1, v4[1]
    2588:      	ldr	q6, [sp, #0x310]
    258c:      	tbnz	w8, #0x1, 0x268c <_llm_rows.packet_batch.blocks+0xb20>
    2590:      	ldr	q4, [sp, #0x440]
    2594:      	ldr	q5, [sp, #0x340]
    2598:      	add.2d	v4, v5, v4
    259c:      	add.2d	v4, v4, v3
    25a0:      	tbnz	w8, #0x2, 0x26a4 <_llm_rows.packet_batch.blocks+0xb38>
    25a4:      	str	q4, [sp, #0xf0]
    25a8:      	mov.d	x0, v4[1]
    25ac:      	tbnz	w8, #0x3, 0x26b8 <_llm_rows.packet_batch.blocks+0xb4c>
    25b0:      	ldr	q4, [sp, #0x430]
    25b4:      	ldr	q5, [sp, #0x330]
    25b8:      	add.2d	v4, v5, v4
    25bc:      	add.2d	v4, v4, v3
    25c0:      	tbnz	w8, #0x4, 0x26d0 <_llm_rows.packet_batch.blocks+0xb64>
    25c4:      	str	q4, [sp, #0x100]
    25c8:      	mov.d	x17, v4[1]
    25cc:      	tbnz	w8, #0x5, 0x26e4 <_llm_rows.packet_batch.blocks+0xb78>
    25d0:      	ldr	q4, [sp, #0x450]
    25d4:      	ldr	q5, [sp, #0x350]
    25d8:      	add.2d	v4, v5, v4
    25dc:      	add.2d	v4, v4, v3
    25e0:      	tbnz	w8, #0x6, 0x26fc <_llm_rows.packet_batch.blocks+0xb90>
    25e4:      	mov.d	x16, v4[1]
    25e8:      	tbnz	w8, #0x7, 0x270c <_llm_rows.packet_batch.blocks+0xba0>
    25ec:      	fmov	w8, s14
    25f0:      	ldr	q2, [sp, #0x420]
    25f4:      	ldr	q3, [sp, #0x320]
    25f8:      	add.2d	v16, v2, v3
    25fc:      	tbz	w8, #0x0, 0x2724 <_llm_rows.packet_batch.blocks+0xbb8>
    2600:      	fmov	x10, d16
    2604:      	ldr	b2, [x10]
    2608:      	and	w8, w8, #0xff
    260c:      	mov.d	x10, v16[1]
    2610:      	str	q4, [sp, #0x110]
    2614:      	tbnz	w8, #0x1, 0x2738 <_llm_rows.packet_batch.blocks+0xbcc>
    2618:      	b	0x273c <_llm_rows.packet_batch.blocks+0xbd0>
    261c:      	ldr	s6, [x11]
    2620:      	tbz	w14, #0x1, 0x1f7c <_llm_rows.packet_batch.blocks+0x410>
    2624:      	add	x10, x11, #0x4
    2628:      	ld1.s	{ v6 }[1], [x10]
    262c:      	tbz	w14, #0x2, 0x1f80 <_llm_rows.packet_batch.blocks+0x414>
    2630:      	add	x10, x11, #0x8
    2634:      	ld1.s	{ v6 }[2], [x10]
    2638:      	tbz	w14, #0x3, 0x1f84 <_llm_rows.packet_batch.blocks+0x418>
    263c:      	add	x10, x11, #0xc
    2640:      	ld1.s	{ v6 }[3], [x10]
    2644:      	tbz	w14, #0x4, 0x1f88 <_llm_rows.packet_batch.blocks+0x41c>
    2648:      	add	x10, x11, #0x10
    264c:      	ld1.s	{ v7 }[0], [x10]
    2650:      	tbz	w14, #0x5, 0x1f8c <_llm_rows.packet_batch.blocks+0x420>
    2654:      	add	x10, x11, #0x14
    2658:      	ld1.s	{ v7 }[1], [x10]
    265c:      	tbz	w14, #0x6, 0x1f90 <_llm_rows.packet_batch.blocks+0x424>
    2660:      	add	x10, x11, #0x18
    2664:      	ld1.s	{ v7 }[2], [x10]
    2668:      	str	q21, [sp, #0x360]
    266c:      	tbnz	w14, #0x7, 0x1f98 <_llm_rows.packet_batch.blocks+0x42c>
    2670:      	b	0x1fa0 <_llm_rows.packet_batch.blocks+0x434>
    2674:      	fmov	x10, d4
    2678:      	str	b2, [x10]
    267c:      	str	q4, [sp, #0xe0]
    2680:      	mov.d	x1, v4[1]
    2684:      	ldr	q6, [sp, #0x310]
    2688:      	tbz	w8, #0x1, 0x2590 <_llm_rows.packet_batch.blocks+0xa24>
    268c:      	st1.b	{ v2 }[1], [x1]
    2690:      	ldr	q4, [sp, #0x440]
    2694:      	ldr	q5, [sp, #0x340]
    2698:      	add.2d	v4, v5, v4
    269c:      	add.2d	v4, v4, v3
    26a0:      	tbz	w8, #0x2, 0x25a4 <_llm_rows.packet_batch.blocks+0xa38>
    26a4:      	fmov	x10, d4
    26a8:      	st1.b	{ v2 }[2], [x10]
    26ac:      	str	q4, [sp, #0xf0]
    26b0:      	mov.d	x0, v4[1]
    26b4:      	tbz	w8, #0x3, 0x25b0 <_llm_rows.packet_batch.blocks+0xa44>
    26b8:      	st1.b	{ v2 }[3], [x0]
    26bc:      	ldr	q4, [sp, #0x430]
    26c0:      	ldr	q5, [sp, #0x330]
    26c4:      	add.2d	v4, v5, v4
    26c8:      	add.2d	v4, v4, v3
    26cc:      	tbz	w8, #0x4, 0x25c4 <_llm_rows.packet_batch.blocks+0xa58>
    26d0:      	fmov	x10, d4
    26d4:      	st1.b	{ v2 }[4], [x10]
    26d8:      	str	q4, [sp, #0x100]
    26dc:      	mov.d	x17, v4[1]
    26e0:      	tbz	w8, #0x5, 0x25d0 <_llm_rows.packet_batch.blocks+0xa64>
    26e4:      	st1.b	{ v2 }[5], [x17]
    26e8:      	ldr	q4, [sp, #0x450]
    26ec:      	ldr	q5, [sp, #0x350]
    26f0:      	add.2d	v4, v5, v4
    26f4:      	add.2d	v4, v4, v3
    26f8:      	tbz	w8, #0x6, 0x25e4 <_llm_rows.packet_batch.blocks+0xa78>
    26fc:      	fmov	x10, d4
    2700:      	st1.b	{ v2 }[6], [x10]
    2704:      	mov.d	x16, v4[1]
    2708:      	tbz	w8, #0x7, 0x25ec <_llm_rows.packet_batch.blocks+0xa80>
    270c:      	st1.b	{ v2 }[7], [x16]
    2710:      	fmov	w8, s14
    2714:      	ldr	q2, [sp, #0x420]
    2718:      	ldr	q3, [sp, #0x320]
    271c:      	add.2d	v16, v2, v3
    2720:      	tbnz	w8, #0x0, 0x2600 <_llm_rows.packet_batch.blocks+0xa94>
    2724:      	movi.2d	v2, #0000000000000000
    2728:      	and	w8, w8, #0xff
    272c:      	mov.d	x10, v16[1]
    2730:      	str	q4, [sp, #0x110]
    2734:      	tbz	w8, #0x1, 0x273c <_llm_rows.packet_batch.blocks+0xbd0>
    2738:      	ld1.b	{ v2 }[1], [x10]
    273c:      	ldr	q3, [sp, #0x440]
    2740:      	ldr	q4, [sp, #0x340]
    2744:      	add.2d	v17, v3, v4
    2748:      	str	x10, [sp, #0x210]
    274c:      	tbnz	w8, #0x2, 0x2820 <_llm_rows.packet_batch.blocks+0xcb4>
    2750:      	mov.d	x10, v17[1]
    2754:      	tbnz	w8, #0x3, 0x2830 <_llm_rows.packet_batch.blocks+0xcc4>
    2758:      	ldr	q3, [sp, #0x430]
    275c:      	ldr	q4, [sp, #0x330]
    2760:      	add.2d	v18, v3, v4
    2764:      	str	x10, [sp, #0x60]
    2768:      	tbnz	w8, #0x4, 0x2848 <_llm_rows.packet_batch.blocks+0xcdc>
    276c:      	mov.d	x10, v18[1]
    2770:      	tbnz	w8, #0x5, 0x2858 <_llm_rows.packet_batch.blocks+0xcec>
    2774:      	ldr	q3, [sp, #0x450]
    2778:      	ldr	q4, [sp, #0x350]
    277c:      	add.2d	v19, v3, v4
    2780:      	str	x10, [sp, #0x58]
    2784:      	tbnz	w8, #0x6, 0x2870 <_llm_rows.packet_batch.blocks+0xd04>
    2788:      	mov.d	x10, v19[1]
    278c:      	str	x10, [sp, #0x50]
    2790:      	tbz	w8, #0x7, 0x2798 <_llm_rows.packet_batch.blocks+0xc2c>
    2794:      	ld1.b	{ v2 }[7], [x10]
    2798:      	fmov	w8, s14
    279c:      	cmeq.8b	v2, v2, #0
    27a0:      	sshll.8h	v2, v2, #0x0
    27a4:      	sshll2.4s	v3, v2, #0x0
    27a8:      	sshll.4s	v2, v2, #0x0
    27ac:      	fmov	x10, d21
    27b0:      	str	x10, [sp, #0x370]
    27b4:      	add	x10, x13, x10
    27b8:      	ldp	q4, q5, [x10]
    27bc:      	and.16b	v5, v0, v5
    27c0:      	and.16b	v20, v1, v4
    27c4:      	mov	w10, #0xf2ca            ; =62154
    27c8:      	movk	w10, #0xf149, lsl #16
    27cc:      	dup.4s	v4, w10
    27d0:      	bsl.16b	v2, v4, v20
    27d4:      	mov.16b	v8, v3
    27d8:      	bsl.16b	v8, v4, v5
    27dc:      	ldp	q3, q5, [x12]
    27e0:      	bit.16b	v5, v8, v0
    27e4:      	bit.16b	v3, v2, v1
    27e8:      	stp	q3, q5, [x12]
    27ec:      	mov	w10, #0x1               ; =1
    27f0:      	dup.2d	v5, x10
    27f4:      	ldr	q3, [sp, #0x320]
    27f8:      	add.2d	v7, v3, v5
    27fc:      	ldr	q3, [sp, #0x420]
    2800:      	str	q7, [sp, #0x2e0]
    2804:      	add.2d	v20, v3, v7
    2808:      	tbz	w8, #0x0, 0x2888 <_llm_rows.packet_batch.blocks+0xd1c>
    280c:      	fmov	x10, d20
    2810:      	ldr	b3, [x10]
    2814:      	and	w8, w8, #0xff
    2818:      	tbnz	w8, #0x1, 0x2894 <_llm_rows.packet_batch.blocks+0xd28>
    281c:      	b	0x289c <_llm_rows.packet_batch.blocks+0xd30>
    2820:      	fmov	x10, d17
    2824:      	ld1.b	{ v2 }[2], [x10]
    2828:      	mov.d	x10, v17[1]
    282c:      	tbz	w8, #0x3, 0x2758 <_llm_rows.packet_batch.blocks+0xbec>
    2830:      	ld1.b	{ v2 }[3], [x10]
    2834:      	ldr	q3, [sp, #0x430]
    2838:      	ldr	q4, [sp, #0x330]
    283c:      	add.2d	v18, v3, v4
    2840:      	str	x10, [sp, #0x60]
    2844:      	tbz	w8, #0x4, 0x276c <_llm_rows.packet_batch.blocks+0xc00>
    2848:      	fmov	x10, d18
    284c:      	ld1.b	{ v2 }[4], [x10]
    2850:      	mov.d	x10, v18[1]
    2854:      	tbz	w8, #0x5, 0x2774 <_llm_rows.packet_batch.blocks+0xc08>
    2858:      	ld1.b	{ v2 }[5], [x10]
    285c:      	ldr	q3, [sp, #0x450]
    2860:      	ldr	q4, [sp, #0x350]
    2864:      	add.2d	v19, v3, v4
    2868:      	str	x10, [sp, #0x58]
    286c:      	tbz	w8, #0x6, 0x2788 <_llm_rows.packet_batch.blocks+0xc1c>
    2870:      	fmov	x10, d19
    2874:      	ld1.b	{ v2 }[6], [x10]
    2878:      	mov.d	x10, v19[1]
    287c:      	str	x10, [sp, #0x50]
    2880:      	tbnz	w8, #0x7, 0x2794 <_llm_rows.packet_batch.blocks+0xc28>
    2884:      	b	0x2798 <_llm_rows.packet_batch.blocks+0xc2c>
    2888:      	movi.2d	v3, #0000000000000000
    288c:      	and	w8, w8, #0xff
    2890:      	tbz	w8, #0x1, 0x289c <_llm_rows.packet_batch.blocks+0xd30>
    2894:      	mov.d	x10, v20[1]
    2898:      	ld1.b	{ v3 }[1], [x10]
    289c:      	ldr	q7, [sp, #0x340]
    28a0:      	add.2d	v20, v7, v5
    28a4:      	ldr	q7, [sp, #0x440]
    28a8:      	str	q20, [sp, #0x2d0]
    28ac:      	add.2d	v20, v7, v20
    28b0:      	tbnz	w8, #0x2, 0x296c <_llm_rows.packet_batch.blocks+0xe00>
    28b4:      	tbnz	w8, #0x3, 0x2978 <_llm_rows.packet_batch.blocks+0xe0c>
    28b8:      	ldr	q7, [sp, #0x330]
    28bc:      	add.2d	v20, v7, v5
    28c0:      	ldr	q7, [sp, #0x430]
    28c4:      	str	q20, [sp, #0x2c0]
    28c8:      	add.2d	v20, v7, v20
    28cc:      	tbnz	w8, #0x4, 0x2998 <_llm_rows.packet_batch.blocks+0xe2c>
    28d0:      	tbnz	w8, #0x5, 0x29a4 <_llm_rows.packet_batch.blocks+0xe38>
    28d4:      	ldr	q7, [sp, #0x350]
    28d8:      	add.2d	v7, v7, v5
    28dc:      	ldr	q5, [sp, #0x450]
    28e0:      	str	q7, [sp, #0x2b0]
    28e4:      	add.2d	v5, v5, v7
    28e8:      	tbnz	w8, #0x6, 0x29c4 <_llm_rows.packet_batch.blocks+0xe58>
    28ec:      	tbz	w8, #0x7, 0x28f8 <_llm_rows.packet_batch.blocks+0xd8c>
    28f0:      	mov.d	x8, v5[1]
    28f4:      	ld1.b	{ v3 }[7], [x8]
    28f8:      	fmov	w8, s14
    28fc:      	cmeq.8b	v3, v3, #0
    2900:      	sshll.8h	v3, v3, #0x0
    2904:      	sshll.4s	v5, v3, #0x0
    2908:      	sshll2.4s	v3, v3, #0x0
    290c:      	ldp	q21, q20, [x13, #0x20]
    2910:      	and.16b	v21, v1, v21
    2914:      	and.16b	v20, v0, v20
    2918:      	mov.16b	v24, v3
    291c:      	bsl.16b	v24, v4, v20
    2920:      	mov.16b	v20, v5
    2924:      	bsl.16b	v20, v4, v21
    2928:      	ldp	q5, q3, [x12, #0x20]
    292c:      	bit.16b	v5, v20, v1
    2930:      	bit.16b	v3, v24, v0
    2934:      	stp	q5, q3, [x12, #0x20]
    2938:      	mov	w10, #0x2               ; =2
    293c:      	dup.2d	v5, x10
    2940:      	ldr	q3, [sp, #0x320]
    2944:      	add.2d	v7, v3, v5
    2948:      	ldr	q3, [sp, #0x420]
    294c:      	str	q7, [sp, #0x2a0]
    2950:      	add.2d	v21, v3, v7
    2954:      	tbz	w8, #0x0, 0x29d4 <_llm_rows.packet_batch.blocks+0xe68>
    2958:      	fmov	x10, d21
    295c:      	ldr	b3, [x10]
    2960:      	and	w8, w8, #0xff
    2964:      	tbnz	w8, #0x1, 0x29e0 <_llm_rows.packet_batch.blocks+0xe74>
    2968:      	b	0x29e8 <_llm_rows.packet_batch.blocks+0xe7c>
    296c:      	fmov	x10, d20
    2970:      	ld1.b	{ v3 }[2], [x10]
    2974:      	tbz	w8, #0x3, 0x28b8 <_llm_rows.packet_batch.blocks+0xd4c>
    2978:      	mov.d	x10, v20[1]
    297c:      	ld1.b	{ v3 }[3], [x10]
    2980:      	ldr	q7, [sp, #0x330]
    2984:      	add.2d	v20, v7, v5
    2988:      	ldr	q7, [sp, #0x430]
    298c:      	str	q20, [sp, #0x2c0]
    2990:      	add.2d	v20, v7, v20
    2994:      	tbz	w8, #0x4, 0x28d0 <_llm_rows.packet_batch.blocks+0xd64>
    2998:      	fmov	x10, d20
    299c:      	ld1.b	{ v3 }[4], [x10]
    29a0:      	tbz	w8, #0x5, 0x28d4 <_llm_rows.packet_batch.blocks+0xd68>
    29a4:      	mov.d	x10, v20[1]
    29a8:      	ld1.b	{ v3 }[5], [x10]
    29ac:      	ldr	q7, [sp, #0x350]
    29b0:      	add.2d	v7, v7, v5
    29b4:      	ldr	q5, [sp, #0x450]
    29b8:      	str	q7, [sp, #0x2b0]
    29bc:      	add.2d	v5, v5, v7
    29c0:      	tbz	w8, #0x6, 0x28ec <_llm_rows.packet_batch.blocks+0xd80>
    29c4:      	fmov	x10, d5
    29c8:      	ld1.b	{ v3 }[6], [x10]
    29cc:      	tbnz	w8, #0x7, 0x28f0 <_llm_rows.packet_batch.blocks+0xd84>
    29d0:      	b	0x28f8 <_llm_rows.packet_batch.blocks+0xd8c>
    29d4:      	movi.2d	v3, #0000000000000000
    29d8:      	and	w8, w8, #0xff
    29dc:      	tbz	w8, #0x1, 0x29e8 <_llm_rows.packet_batch.blocks+0xe7c>
    29e0:      	mov.d	x10, v21[1]
    29e4:      	ld1.b	{ v3 }[1], [x10]
    29e8:      	ldr	q7, [sp, #0x340]
    29ec:      	add.2d	v21, v7, v5
    29f0:      	ldr	q7, [sp, #0x440]
    29f4:      	str	q21, [sp, #0x290]
    29f8:      	add.2d	v21, v7, v21
    29fc:      	tbnz	w8, #0x2, 0x2ab8 <_llm_rows.packet_batch.blocks+0xf4c>
    2a00:      	tbnz	w8, #0x3, 0x2ac4 <_llm_rows.packet_batch.blocks+0xf58>
    2a04:      	ldr	q7, [sp, #0x330]
    2a08:      	add.2d	v21, v7, v5
    2a0c:      	ldr	q7, [sp, #0x430]
    2a10:      	str	q21, [sp, #0x280]
    2a14:      	add.2d	v21, v7, v21
    2a18:      	tbnz	w8, #0x4, 0x2ae4 <_llm_rows.packet_batch.blocks+0xf78>
    2a1c:      	tbnz	w8, #0x5, 0x2af0 <_llm_rows.packet_batch.blocks+0xf84>
    2a20:      	ldr	q7, [sp, #0x350]
    2a24:      	add.2d	v7, v7, v5
    2a28:      	ldr	q5, [sp, #0x450]
    2a2c:      	str	q7, [sp, #0x270]
    2a30:      	add.2d	v5, v5, v7
    2a34:      	tbnz	w8, #0x6, 0x2b10 <_llm_rows.packet_batch.blocks+0xfa4>
    2a38:      	tbz	w8, #0x7, 0x2a44 <_llm_rows.packet_batch.blocks+0xed8>
    2a3c:      	mov.d	x8, v5[1]
    2a40:      	ld1.b	{ v3 }[7], [x8]
    2a44:      	fmov	w8, s14
    2a48:      	cmeq.8b	v3, v3, #0
    2a4c:      	sshll.8h	v3, v3, #0x0
    2a50:      	sshll.4s	v5, v3, #0x0
    2a54:      	sshll2.4s	v3, v3, #0x0
    2a58:      	ldp	q22, q21, [x13, #0x40]
    2a5c:      	and.16b	v22, v1, v22
    2a60:      	and.16b	v21, v0, v21
    2a64:      	mov.16b	v25, v3
    2a68:      	bsl.16b	v25, v4, v21
    2a6c:      	mov.16b	v23, v5
    2a70:      	bsl.16b	v23, v4, v22
    2a74:      	ldp	q5, q3, [x12, #0x40]
    2a78:      	bit.16b	v5, v23, v1
    2a7c:      	bit.16b	v3, v25, v0
    2a80:      	stp	q5, q3, [x12, #0x40]
    2a84:      	mov	w10, #0x3               ; =3
    2a88:      	dup.2d	v5, x10
    2a8c:      	ldr	q3, [sp, #0x320]
    2a90:      	add.2d	v7, v3, v5
    2a94:      	ldr	q3, [sp, #0x420]
    2a98:      	str	q7, [sp, #0x260]
    2a9c:      	add.2d	v21, v3, v7
    2aa0:      	tbz	w8, #0x0, 0x2b20 <_llm_rows.packet_batch.blocks+0xfb4>
    2aa4:      	fmov	x10, d21
    2aa8:      	ldr	b3, [x10]
    2aac:      	and	w8, w8, #0xff
    2ab0:      	tbnz	w8, #0x1, 0x2b2c <_llm_rows.packet_batch.blocks+0xfc0>
    2ab4:      	b	0x2b34 <_llm_rows.packet_batch.blocks+0xfc8>
    2ab8:      	fmov	x10, d21
    2abc:      	ld1.b	{ v3 }[2], [x10]
    2ac0:      	tbz	w8, #0x3, 0x2a04 <_llm_rows.packet_batch.blocks+0xe98>
    2ac4:      	mov.d	x10, v21[1]
    2ac8:      	ld1.b	{ v3 }[3], [x10]
    2acc:      	ldr	q7, [sp, #0x330]
    2ad0:      	add.2d	v21, v7, v5
    2ad4:      	ldr	q7, [sp, #0x430]
    2ad8:      	str	q21, [sp, #0x280]
    2adc:      	add.2d	v21, v7, v21
    2ae0:      	tbz	w8, #0x4, 0x2a1c <_llm_rows.packet_batch.blocks+0xeb0>
    2ae4:      	fmov	x10, d21
    2ae8:      	ld1.b	{ v3 }[4], [x10]
    2aec:      	tbz	w8, #0x5, 0x2a20 <_llm_rows.packet_batch.blocks+0xeb4>
    2af0:      	mov.d	x10, v21[1]
    2af4:      	ld1.b	{ v3 }[5], [x10]
    2af8:      	ldr	q7, [sp, #0x350]
    2afc:      	add.2d	v7, v7, v5
    2b00:      	ldr	q5, [sp, #0x450]
    2b04:      	str	q7, [sp, #0x270]
    2b08:      	add.2d	v5, v5, v7
    2b0c:      	tbz	w8, #0x6, 0x2a38 <_llm_rows.packet_batch.blocks+0xecc>
    2b10:      	fmov	x10, d5
    2b14:      	ld1.b	{ v3 }[6], [x10]
    2b18:      	tbnz	w8, #0x7, 0x2a3c <_llm_rows.packet_batch.blocks+0xed0>
    2b1c:      	b	0x2a44 <_llm_rows.packet_batch.blocks+0xed8>
    2b20:      	movi.2d	v3, #0000000000000000
    2b24:      	and	w8, w8, #0xff
    2b28:      	tbz	w8, #0x1, 0x2b34 <_llm_rows.packet_batch.blocks+0xfc8>
    2b2c:      	mov.d	x10, v21[1]
    2b30:      	ld1.b	{ v3 }[1], [x10]
    2b34:      	ldr	q7, [sp, #0x340]
    2b38:      	add.2d	v21, v7, v5
    2b3c:      	ldr	q7, [sp, #0x440]
    2b40:      	str	q21, [sp, #0x250]
    2b44:      	add.2d	v21, v7, v21
    2b48:      	tbnz	w8, #0x2, 0x3198 <_llm_rows.packet_batch.blocks+0x162c>
    2b4c:      	tbnz	w8, #0x3, 0x31a4 <_llm_rows.packet_batch.blocks+0x1638>
    2b50:      	ldr	q7, [sp, #0x330]
    2b54:      	add.2d	v21, v7, v5
    2b58:      	ldr	q7, [sp, #0x430]
    2b5c:      	str	q21, [sp, #0x240]
    2b60:      	add.2d	v21, v7, v21
    2b64:      	tbnz	w8, #0x4, 0x31c4 <_llm_rows.packet_batch.blocks+0x1658>
    2b68:      	tbnz	w8, #0x5, 0x31d0 <_llm_rows.packet_batch.blocks+0x1664>
    2b6c:      	ldr	q7, [sp, #0x350]
    2b70:      	add.2d	v7, v7, v5
    2b74:      	ldr	q5, [sp, #0x450]
    2b78:      	str	q7, [sp, #0x230]
    2b7c:      	add.2d	v5, v5, v7
    2b80:      	tbnz	w8, #0x6, 0x31f0 <_llm_rows.packet_batch.blocks+0x1684>
    2b84:      	tbz	w8, #0x7, 0x2b90 <_llm_rows.packet_batch.blocks+0x1024>
    2b88:      	mov.d	x8, v5[1]
    2b8c:      	ld1.b	{ v3 }[7], [x8]
    2b90:      	sshll.2d	v5, v1, #0x0
    2b94:      	sshll.2d	v21, v0, #0x0
    2b98:      	cmeq.8b	v3, v3, #0
    2b9c:      	sshll.8h	v3, v3, #0x0
    2ba0:      	sshll.4s	v22, v3, #0x0
    2ba4:      	sshll2.4s	v3, v3, #0x0
    2ba8:      	ldp	q27, q26, [x13, #0x60]
    2bac:      	and.16b	v27, v1, v27
    2bb0:      	and.16b	v26, v0, v26
    2bb4:      	bsl.16b	v3, v4, v26
    2bb8:      	bsl.16b	v22, v4, v27
    2bbc:      	ldp	q27, q26, [x12, #0x60]
    2bc0:      	bit.16b	v27, v22, v1
    2bc4:      	bit.16b	v26, v3, v0
    2bc8:      	stp	q27, q26, [x12, #0x60]
    2bcc:      	dup.2d	v26, x26
    2bd0:      	str	q28, [sp, #0x300]
    2bd4:      	and.16b	v7, v28, v26
    2bd8:      	and.16b	v13, v6, v26
    2bdc:      	and.16b	v15, v21, v26
    2be0:      	and.16b	v12, v5, v26
    2be4:      	fmov	x8, d12
    2be8:      	and.16b	v21, v0, v3
    2bec:      	and.16b	v22, v1, v22
    2bf0:      	and.16b	v28, v0, v25
    2bf4:      	and.16b	v23, v1, v23
    2bf8:      	and.16b	v29, v0, v24
    2bfc:      	and.16b	v30, v1, v20
    2c00:      	and.16b	v10, v0, v8
    2c04:      	mov	x15, x8
    2c08:      	and.16b	v11, v1, v2
    2c0c:      	stp	q12, q7, [sp, #0x3e0]
    2c10:      	str	q13, [sp, #0x2f0]
    2c14:      	str	q15, [sp, #0x220]
    2c18:      	mov.16b	v8, v7
    2c1c:      	b	0x2ce4 <_llm_rows.packet_batch.blocks+0x1178>
    2c20:      	fmaxnm.4s	v26, v10, v20
    2c24:      	fmaxnm.4s	v20, v11, v2
    2c28:      	fmaxnm.4s	v2, v29, v25
    2c2c:      	fmaxnm.4s	v3, v30, v24
    2c30:      	fmaxnm.4s	v24, v28, v31
    2c34:      	fmaxnm.4s	v25, v23, v27
    2c38:      	sshll.2d	v27, v1, #0x0
    2c3c:      	sshll.2d	v31, v0, #0x0
    2c40:      	cmeq.8b	v5, v5, #0
    2c44:      	sshll.8h	v5, v5, #0x0
    2c48:      	sshll2.4s	v9, v5, #0x0
    2c4c:      	sshll.4s	v5, v5, #0x0
    2c50:      	add	x10, x15, #0x60
    2c54:      	add	x11, x13, x10
    2c58:      	ldp	q6, q7, [x11]
    2c5c:      	and.16b	v7, v0, v7
    2c60:      	and.16b	v6, v1, v6
    2c64:      	bsl.16b	v5, v4, v6
    2c68:      	mov.16b	v6, v9
    2c6c:      	bsl.16b	v6, v4, v7
    2c70:      	add	x10, x12, x10
    2c74:      	ldp	q7, q9, [x10]
    2c78:      	bit.16b	v9, v6, v0
    2c7c:      	bit.16b	v7, v5, v1
    2c80:      	stp	q7, q9, [x10]
    2c84:      	fmaxnm.4s	v5, v22, v5
    2c88:      	fmaxnm.4s	v6, v21, v6
    2c8c:      	dup.2d	v7, x26
    2c90:      	ldr	q9, [sp, #0x300]
    2c94:      	and.16b	v9, v9, v7
    2c98:      	add.2d	v8, v8, v9
    2c9c:      	ldr	q9, [sp, #0x310]
    2ca0:      	and.16b	v9, v9, v7
    2ca4:      	add.2d	v13, v13, v9
    2ca8:      	and.16b	v31, v31, v7
    2cac:      	add.2d	v15, v15, v31
    2cb0:      	and.16b	v7, v27, v7
    2cb4:      	add.2d	v12, v12, v7
    2cb8:      	bit.16b	v10, v26, v0
    2cbc:      	bit.16b	v11, v20, v1
    2cc0:      	bit.16b	v29, v2, v0
    2cc4:      	bit.16b	v30, v3, v1
    2cc8:      	bit.16b	v28, v24, v0
    2ccc:      	bit.16b	v23, v25, v1
    2cd0:      	bit.16b	v21, v6, v0
    2cd4:      	bit.16b	v22, v5, v1
    2cd8:      	fmov	x15, d12
    2cdc:      	cmp	x15, #0x200
    2ce0:      	b.ge	0x3174 <_llm_rows.packet_batch.blocks+0x1608>
    2ce4:      	fmov	w10, s14
    2ce8:      	ldr	q2, [sp, #0x320]
    2cec:      	add.2d	v2, v12, v2
    2cf0:      	ldr	q3, [sp, #0x420]
    2cf4:      	add.2d	v3, v3, v2
    2cf8:      	tbz	w10, #0x0, 0x2d10 <_llm_rows.packet_batch.blocks+0x11a4>
    2cfc:      	fmov	x11, d3
    2d00:      	ldr	b2, [x11]
    2d04:      	and	w11, w10, #0xff
    2d08:      	tbnz	w11, #0x1, 0x2d1c <_llm_rows.packet_batch.blocks+0x11b0>
    2d0c:      	b	0x2d24 <_llm_rows.packet_batch.blocks+0x11b8>
    2d10:      	movi.2d	v2, #0000000000000000
    2d14:      	and	w11, w10, #0xff
    2d18:      	tbz	w11, #0x1, 0x2d24 <_llm_rows.packet_batch.blocks+0x11b8>
    2d1c:      	mov.d	x10, v3[1]
    2d20:      	ld1.b	{ v2 }[1], [x10]
    2d24:      	ldr	q3, [sp, #0x340]
    2d28:      	add.2d	v3, v13, v3
    2d2c:      	ldr	q5, [sp, #0x440]
    2d30:      	add.2d	v3, v5, v3
    2d34:      	tbnz	w11, #0x2, 0x2de0 <_llm_rows.packet_batch.blocks+0x1274>
    2d38:      	tbnz	w11, #0x3, 0x2dec <_llm_rows.packet_batch.blocks+0x1280>
    2d3c:      	ldr	q3, [sp, #0x330]
    2d40:      	add.2d	v3, v15, v3
    2d44:      	ldr	q5, [sp, #0x430]
    2d48:      	add.2d	v3, v5, v3
    2d4c:      	tbnz	w11, #0x4, 0x2e08 <_llm_rows.packet_batch.blocks+0x129c>
    2d50:      	tbnz	w11, #0x5, 0x2e14 <_llm_rows.packet_batch.blocks+0x12a8>
    2d54:      	ldr	q3, [sp, #0x350]
    2d58:      	add.2d	v3, v8, v3
    2d5c:      	ldr	q5, [sp, #0x450]
    2d60:      	add.2d	v3, v5, v3
    2d64:      	tbnz	w11, #0x6, 0x2e30 <_llm_rows.packet_batch.blocks+0x12c4>
    2d68:      	tbz	w11, #0x7, 0x2d74 <_llm_rows.packet_batch.blocks+0x1208>
    2d6c:      	mov.d	x10, v3[1]
    2d70:      	ld1.b	{ v2 }[7], [x10]
    2d74:      	fmov	w10, s14
    2d78:      	cmeq.8b	v2, v2, #0
    2d7c:      	sshll.8h	v2, v2, #0x0
    2d80:      	sshll2.4s	v3, v2, #0x0
    2d84:      	sshll.4s	v2, v2, #0x0
    2d88:      	lsl	x11, x15, #5
    2d8c:      	add	x14, x13, x11
    2d90:      	ldp	q5, q20, [x14]
    2d94:      	and.16b	v20, v0, v20
    2d98:      	and.16b	v5, v1, v5
    2d9c:      	bsl.16b	v2, v4, v5
    2da0:      	bit.16b	v20, v4, v3
    2da4:      	add	x11, x12, x11
    2da8:      	ldp	q3, q5, [x11]
    2dac:      	bit.16b	v5, v20, v0
    2db0:      	bit.16b	v3, v2, v1
    2db4:      	stp	q3, q5, [x11]
    2db8:      	ldr	q3, [sp, #0x2e0]
    2dbc:      	add.2d	v3, v12, v3
    2dc0:      	ldr	q5, [sp, #0x420]
    2dc4:      	add.2d	v3, v5, v3
    2dc8:      	tbz	w10, #0x0, 0x2e40 <_llm_rows.packet_batch.blocks+0x12d4>
    2dcc:      	fmov	x11, d3
    2dd0:      	ldr	b5, [x11]
    2dd4:      	and	w11, w10, #0xff
    2dd8:      	tbnz	w11, #0x1, 0x2e4c <_llm_rows.packet_batch.blocks+0x12e0>
    2ddc:      	b	0x2e54 <_llm_rows.packet_batch.blocks+0x12e8>
    2de0:      	fmov	x10, d3
    2de4:      	ld1.b	{ v2 }[2], [x10]
    2de8:      	tbz	w11, #0x3, 0x2d3c <_llm_rows.packet_batch.blocks+0x11d0>
    2dec:      	mov.d	x10, v3[1]
    2df0:      	ld1.b	{ v2 }[3], [x10]
    2df4:      	ldr	q3, [sp, #0x330]
    2df8:      	add.2d	v3, v15, v3
    2dfc:      	ldr	q5, [sp, #0x430]
    2e00:      	add.2d	v3, v5, v3
    2e04:      	tbz	w11, #0x4, 0x2d50 <_llm_rows.packet_batch.blocks+0x11e4>
    2e08:      	fmov	x10, d3
    2e0c:      	ld1.b	{ v2 }[4], [x10]
    2e10:      	tbz	w11, #0x5, 0x2d54 <_llm_rows.packet_batch.blocks+0x11e8>
    2e14:      	mov.d	x10, v3[1]
    2e18:      	ld1.b	{ v2 }[5], [x10]
    2e1c:      	ldr	q3, [sp, #0x350]
    2e20:      	add.2d	v3, v8, v3
    2e24:      	ldr	q5, [sp, #0x450]
    2e28:      	add.2d	v3, v5, v3
    2e2c:      	tbz	w11, #0x6, 0x2d68 <_llm_rows.packet_batch.blocks+0x11fc>
    2e30:      	fmov	x10, d3
    2e34:      	ld1.b	{ v2 }[6], [x10]
    2e38:      	tbnz	w11, #0x7, 0x2d6c <_llm_rows.packet_batch.blocks+0x1200>
    2e3c:      	b	0x2d74 <_llm_rows.packet_batch.blocks+0x1208>
    2e40:      	movi.2d	v5, #0000000000000000
    2e44:      	and	w11, w10, #0xff
    2e48:      	tbz	w11, #0x1, 0x2e54 <_llm_rows.packet_batch.blocks+0x12e8>
    2e4c:      	mov.d	x10, v3[1]
    2e50:      	ld1.b	{ v5 }[1], [x10]
    2e54:      	ldr	q3, [sp, #0x2d0]
    2e58:      	add.2d	v3, v13, v3
    2e5c:      	ldr	q6, [sp, #0x440]
    2e60:      	add.2d	v3, v6, v3
    2e64:      	tbnz	w11, #0x2, 0x2f18 <_llm_rows.packet_batch.blocks+0x13ac>
    2e68:      	tbnz	w11, #0x3, 0x2f24 <_llm_rows.packet_batch.blocks+0x13b8>
    2e6c:      	ldr	q3, [sp, #0x2c0]
    2e70:      	add.2d	v3, v15, v3
    2e74:      	ldr	q6, [sp, #0x430]
    2e78:      	add.2d	v3, v6, v3
    2e7c:      	tbnz	w11, #0x4, 0x2f40 <_llm_rows.packet_batch.blocks+0x13d4>
    2e80:      	tbnz	w11, #0x5, 0x2f4c <_llm_rows.packet_batch.blocks+0x13e0>
    2e84:      	ldr	q3, [sp, #0x2b0]
    2e88:      	add.2d	v3, v8, v3
    2e8c:      	ldr	q6, [sp, #0x450]
    2e90:      	add.2d	v3, v6, v3
    2e94:      	tbnz	w11, #0x6, 0x2f68 <_llm_rows.packet_batch.blocks+0x13fc>
    2e98:      	tbz	w11, #0x7, 0x2ea4 <_llm_rows.packet_batch.blocks+0x1338>
    2e9c:      	mov.d	x10, v3[1]
    2ea0:      	ld1.b	{ v5 }[7], [x10]
    2ea4:      	fmov	w10, s14
    2ea8:      	cmeq.8b	v3, v5, #0
    2eac:      	sshll.8h	v3, v3, #0x0
    2eb0:      	sshll2.4s	v5, v3, #0x0
    2eb4:      	sshll.4s	v3, v3, #0x0
    2eb8:      	fmov	x11, d12
    2ebc:      	lsl	x15, x11, #5
    2ec0:      	add	x11, x15, #0x20
    2ec4:      	add	x14, x13, x11
    2ec8:      	ldp	q24, q25, [x14]
    2ecc:      	and.16b	v25, v0, v25
    2ed0:      	and.16b	v24, v1, v24
    2ed4:      	bit.16b	v24, v4, v3
    2ed8:      	bit.16b	v25, v4, v5
    2edc:      	add	x11, x12, x11
    2ee0:      	ldp	q3, q5, [x11]
    2ee4:      	bit.16b	v5, v25, v0
    2ee8:      	bit.16b	v3, v24, v1
    2eec:      	stp	q3, q5, [x11]
    2ef0:      	ldr	q3, [sp, #0x2a0]
    2ef4:      	add.2d	v3, v12, v3
    2ef8:      	ldr	q5, [sp, #0x420]
    2efc:      	add.2d	v3, v5, v3
    2f00:      	tbz	w10, #0x0, 0x2f78 <_llm_rows.packet_batch.blocks+0x140c>
    2f04:      	fmov	x11, d3
    2f08:      	ldr	b5, [x11]
    2f0c:      	and	w11, w10, #0xff
    2f10:      	tbnz	w11, #0x1, 0x2f84 <_llm_rows.packet_batch.blocks+0x1418>
    2f14:      	b	0x2f8c <_llm_rows.packet_batch.blocks+0x1420>
    2f18:      	fmov	x10, d3
    2f1c:      	ld1.b	{ v5 }[2], [x10]
    2f20:      	tbz	w11, #0x3, 0x2e6c <_llm_rows.packet_batch.blocks+0x1300>
    2f24:      	mov.d	x10, v3[1]
    2f28:      	ld1.b	{ v5 }[3], [x10]
    2f2c:      	ldr	q3, [sp, #0x2c0]
    2f30:      	add.2d	v3, v15, v3
    2f34:      	ldr	q6, [sp, #0x430]
    2f38:      	add.2d	v3, v6, v3
    2f3c:      	tbz	w11, #0x4, 0x2e80 <_llm_rows.packet_batch.blocks+0x1314>
    2f40:      	fmov	x10, d3
    2f44:      	ld1.b	{ v5 }[4], [x10]
    2f48:      	tbz	w11, #0x5, 0x2e84 <_llm_rows.packet_batch.blocks+0x1318>
    2f4c:      	mov.d	x10, v3[1]
    2f50:      	ld1.b	{ v5 }[5], [x10]
    2f54:      	ldr	q3, [sp, #0x2b0]
    2f58:      	add.2d	v3, v8, v3
    2f5c:      	ldr	q6, [sp, #0x450]
    2f60:      	add.2d	v3, v6, v3
    2f64:      	tbz	w11, #0x6, 0x2e98 <_llm_rows.packet_batch.blocks+0x132c>
    2f68:      	fmov	x10, d3
    2f6c:      	ld1.b	{ v5 }[6], [x10]
    2f70:      	tbnz	w11, #0x7, 0x2e9c <_llm_rows.packet_batch.blocks+0x1330>
    2f74:      	b	0x2ea4 <_llm_rows.packet_batch.blocks+0x1338>
    2f78:      	movi.2d	v5, #0000000000000000
    2f7c:      	and	w11, w10, #0xff
    2f80:      	tbz	w11, #0x1, 0x2f8c <_llm_rows.packet_batch.blocks+0x1420>
    2f84:      	mov.d	x10, v3[1]
    2f88:      	ld1.b	{ v5 }[1], [x10]
    2f8c:      	ldr	q3, [sp, #0x290]
    2f90:      	add.2d	v3, v13, v3
    2f94:      	ldr	q6, [sp, #0x440]
    2f98:      	add.2d	v3, v6, v3
    2f9c:      	tbnz	w11, #0x2, 0x304c <_llm_rows.packet_batch.blocks+0x14e0>
    2fa0:      	tbnz	w11, #0x3, 0x3058 <_llm_rows.packet_batch.blocks+0x14ec>
    2fa4:      	ldr	q3, [sp, #0x280]
    2fa8:      	add.2d	v3, v15, v3
    2fac:      	ldr	q6, [sp, #0x430]
    2fb0:      	add.2d	v3, v6, v3
    2fb4:      	tbnz	w11, #0x4, 0x3074 <_llm_rows.packet_batch.blocks+0x1508>
    2fb8:      	tbnz	w11, #0x5, 0x3080 <_llm_rows.packet_batch.blocks+0x1514>
    2fbc:      	ldr	q3, [sp, #0x270]
    2fc0:      	add.2d	v3, v8, v3
    2fc4:      	ldr	q6, [sp, #0x450]
    2fc8:      	add.2d	v3, v6, v3
    2fcc:      	tbnz	w11, #0x6, 0x309c <_llm_rows.packet_batch.blocks+0x1530>
    2fd0:      	tbz	w11, #0x7, 0x2fdc <_llm_rows.packet_batch.blocks+0x1470>
    2fd4:      	mov.d	x10, v3[1]
    2fd8:      	ld1.b	{ v5 }[7], [x10]
    2fdc:      	fmov	w10, s14
    2fe0:      	cmeq.8b	v3, v5, #0
    2fe4:      	sshll.8h	v3, v3, #0x0
    2fe8:      	sshll2.4s	v5, v3, #0x0
    2fec:      	sshll.4s	v3, v3, #0x0
    2ff0:      	add	x11, x15, #0x40
    2ff4:      	add	x14, x13, x11
    2ff8:      	ldp	q26, q27, [x14]
    2ffc:      	and.16b	v31, v0, v27
    3000:      	and.16b	v26, v1, v26
    3004:      	mov.16b	v27, v3
    3008:      	bsl.16b	v27, v4, v26
    300c:      	bit.16b	v31, v4, v5
    3010:      	add	x11, x12, x11
    3014:      	ldp	q3, q5, [x11]
    3018:      	bit.16b	v5, v31, v0
    301c:      	bit.16b	v3, v27, v1
    3020:      	stp	q3, q5, [x11]
    3024:      	ldr	q3, [sp, #0x260]
    3028:      	add.2d	v3, v12, v3
    302c:      	ldr	q5, [sp, #0x420]
    3030:      	add.2d	v3, v5, v3
    3034:      	tbz	w10, #0x0, 0x30ac <_llm_rows.packet_batch.blocks+0x1540>
    3038:      	fmov	x11, d3
    303c:      	ldr	b5, [x11]
    3040:      	and	w11, w10, #0xff
    3044:      	tbnz	w11, #0x1, 0x30b8 <_llm_rows.packet_batch.blocks+0x154c>
    3048:      	b	0x30c0 <_llm_rows.packet_batch.blocks+0x1554>
    304c:      	fmov	x10, d3
    3050:      	ld1.b	{ v5 }[2], [x10]
    3054:      	tbz	w11, #0x3, 0x2fa4 <_llm_rows.packet_batch.blocks+0x1438>
    3058:      	mov.d	x10, v3[1]
    305c:      	ld1.b	{ v5 }[3], [x10]
    3060:      	ldr	q3, [sp, #0x280]
    3064:      	add.2d	v3, v15, v3
    3068:      	ldr	q6, [sp, #0x430]
    306c:      	add.2d	v3, v6, v3
    3070:      	tbz	w11, #0x4, 0x2fb8 <_llm_rows.packet_batch.blocks+0x144c>
    3074:      	fmov	x10, d3
    3078:      	ld1.b	{ v5 }[4], [x10]
    307c:      	tbz	w11, #0x5, 0x2fbc <_llm_rows.packet_batch.blocks+0x1450>
    3080:      	mov.d	x10, v3[1]
    3084:      	ld1.b	{ v5 }[5], [x10]
    3088:      	ldr	q3, [sp, #0x270]
    308c:      	add.2d	v3, v8, v3
    3090:      	ldr	q6, [sp, #0x450]
    3094:      	add.2d	v3, v6, v3
    3098:      	tbz	w11, #0x6, 0x2fd0 <_llm_rows.packet_batch.blocks+0x1464>
    309c:      	fmov	x10, d3
    30a0:      	ld1.b	{ v5 }[6], [x10]
    30a4:      	tbnz	w11, #0x7, 0x2fd4 <_llm_rows.packet_batch.blocks+0x1468>
    30a8:      	b	0x2fdc <_llm_rows.packet_batch.blocks+0x1470>
    30ac:      	movi.2d	v5, #0000000000000000
    30b0:      	and	w11, w10, #0xff
    30b4:      	tbz	w11, #0x1, 0x30c0 <_llm_rows.packet_batch.blocks+0x1554>
    30b8:      	mov.d	x10, v3[1]
    30bc:      	ld1.b	{ v5 }[1], [x10]
    30c0:      	ldr	q3, [sp, #0x250]
    30c4:      	add.2d	v3, v13, v3
    30c8:      	ldr	q6, [sp, #0x440]
    30cc:      	add.2d	v3, v6, v3
    30d0:      	tbnz	w11, #0x2, 0x310c <_llm_rows.packet_batch.blocks+0x15a0>
    30d4:      	tbnz	w11, #0x3, 0x3118 <_llm_rows.packet_batch.blocks+0x15ac>
    30d8:      	ldr	q3, [sp, #0x240]
    30dc:      	add.2d	v3, v15, v3
    30e0:      	ldr	q6, [sp, #0x430]
    30e4:      	add.2d	v3, v6, v3
    30e8:      	tbnz	w11, #0x4, 0x3134 <_llm_rows.packet_batch.blocks+0x15c8>
    30ec:      	tbnz	w11, #0x5, 0x3140 <_llm_rows.packet_batch.blocks+0x15d4>
    30f0:      	ldr	q3, [sp, #0x230]
    30f4:      	add.2d	v3, v8, v3
    30f8:      	ldr	q6, [sp, #0x450]
    30fc:      	add.2d	v3, v6, v3
    3100:      	tbnz	w11, #0x6, 0x315c <_llm_rows.packet_batch.blocks+0x15f0>
    3104:      	tbz	w11, #0x7, 0x2c20 <_llm_rows.packet_batch.blocks+0x10b4>
    3108:      	b	0x3168 <_llm_rows.packet_batch.blocks+0x15fc>
    310c:      	fmov	x10, d3
    3110:      	ld1.b	{ v5 }[2], [x10]
    3114:      	tbz	w11, #0x3, 0x30d8 <_llm_rows.packet_batch.blocks+0x156c>
    3118:      	mov.d	x10, v3[1]
    311c:      	ld1.b	{ v5 }[3], [x10]
    3120:      	ldr	q3, [sp, #0x240]
    3124:      	add.2d	v3, v15, v3
    3128:      	ldr	q6, [sp, #0x430]
    312c:      	add.2d	v3, v6, v3
    3130:      	tbz	w11, #0x4, 0x30ec <_llm_rows.packet_batch.blocks+0x1580>
    3134:      	fmov	x10, d3
    3138:      	ld1.b	{ v5 }[4], [x10]
    313c:      	tbz	w11, #0x5, 0x30f0 <_llm_rows.packet_batch.blocks+0x1584>
    3140:      	mov.d	x10, v3[1]
    3144:      	ld1.b	{ v5 }[5], [x10]
    3148:      	ldr	q3, [sp, #0x230]
    314c:      	add.2d	v3, v8, v3
    3150:      	ldr	q6, [sp, #0x450]
    3154:      	add.2d	v3, v6, v3
    3158:      	tbz	w11, #0x6, 0x3104 <_llm_rows.packet_batch.blocks+0x1598>
    315c:      	fmov	x10, d3
    3160:      	ld1.b	{ v5 }[6], [x10]
    3164:      	tbz	w11, #0x7, 0x2c20 <_llm_rows.packet_batch.blocks+0x10b4>
    3168:      	mov.d	x10, v3[1]
    316c:      	ld1.b	{ v5 }[7], [x10]
    3170:      	b	0x2c20 <_llm_rows.packet_batch.blocks+0x10b4>
    3174:      	ldr	d2, [sp, #0x1a8]
    3178:      	fmov	w15, s2
    317c:      	ldr	q5, [sp, #0x3c0]
    3180:      	tbz	w15, #0x0, 0x3200 <_llm_rows.packet_batch.blocks+0x1694>
    3184:      	ldr	q2, [sp, #0xe0]
    3188:      	fmov	x10, d2
    318c:      	ldr	b2, [x10]
    3190:      	tbnz	w15, #0x1, 0x3208 <_llm_rows.packet_batch.blocks+0x169c>
    3194:      	b	0x320c <_llm_rows.packet_batch.blocks+0x16a0>
    3198:      	fmov	x10, d21
    319c:      	ld1.b	{ v3 }[2], [x10]
    31a0:      	tbz	w8, #0x3, 0x2b50 <_llm_rows.packet_batch.blocks+0xfe4>
    31a4:      	mov.d	x10, v21[1]
    31a8:      	ld1.b	{ v3 }[3], [x10]
    31ac:      	ldr	q7, [sp, #0x330]
    31b0:      	add.2d	v21, v7, v5
    31b4:      	ldr	q7, [sp, #0x430]
    31b8:      	str	q21, [sp, #0x240]
    31bc:      	add.2d	v21, v7, v21
    31c0:      	tbz	w8, #0x4, 0x2b68 <_llm_rows.packet_batch.blocks+0xffc>
    31c4:      	fmov	x10, d21
    31c8:      	ld1.b	{ v3 }[4], [x10]
    31cc:      	tbz	w8, #0x5, 0x2b6c <_llm_rows.packet_batch.blocks+0x1000>
    31d0:      	mov.d	x10, v21[1]
    31d4:      	ld1.b	{ v3 }[5], [x10]
    31d8:      	ldr	q7, [sp, #0x350]
    31dc:      	add.2d	v7, v7, v5
    31e0:      	ldr	q5, [sp, #0x450]
    31e4:      	str	q7, [sp, #0x230]
    31e8:      	add.2d	v5, v5, v7
    31ec:      	tbz	w8, #0x6, 0x2b84 <_llm_rows.packet_batch.blocks+0x1018>
    31f0:      	fmov	x10, d5
    31f4:      	ld1.b	{ v3 }[6], [x10]
    31f8:      	tbnz	w8, #0x7, 0x2b88 <_llm_rows.packet_batch.blocks+0x101c>
    31fc:      	b	0x2b90 <_llm_rows.packet_batch.blocks+0x1024>
    3200:      	movi.2d	v2, #0000000000000000
    3204:      	tbz	w15, #0x1, 0x320c <_llm_rows.packet_batch.blocks+0x16a0>
    3208:      	ld1.b	{ v2 }[1], [x1]
    320c:      	tbnz	w15, #0x2, 0x3844 <_llm_rows.packet_batch.blocks+0x1cd8>
    3210:      	tbnz	w15, #0x3, 0x3854 <_llm_rows.packet_batch.blocks+0x1ce8>
    3214:      	tbnz	w15, #0x4, 0x385c <_llm_rows.packet_batch.blocks+0x1cf0>
    3218:      	tbnz	w15, #0x5, 0x386c <_llm_rows.packet_batch.blocks+0x1d00>
    321c:      	tbz	w15, #0x6, 0x322c <_llm_rows.packet_batch.blocks+0x16c0>
    3220:      	ldr	q3, [sp, #0x110]
    3224:      	fmov	x10, d3
    3228:      	ld1.b	{ v2 }[6], [x10]
    322c:      	xtn.8b	v27, v5
    3230:      	mov.16b	v25, v27
    3234:      	mov.b	v25[0], wzr
    3238:      	stp	x17, x16, [sp, #0x78]
    323c:      	stp	x1, x0, [sp, #0x68]
    3240:      	str	x6, [sp, #0xd8]
    3244:      	str	w24, [sp, #0xc8]
    3248:      	str	w22, [sp, #0xac]
    324c:      	tbz	w15, #0x7, 0x3254 <_llm_rows.packet_batch.blocks+0x16e8>
    3250:      	ld1.b	{ v2 }[7], [x16]
    3254:      	cmeq.8b	v2, v2, #0
    3258:      	sshll.8h	v2, v2, #0x0
    325c:      	sshll2.4s	v3, v2, #0x0
    3260:      	sshll.4s	v5, v2, #0x0
    3264:      	ldr	x1, [sp, #0x1b0]
    3268:      	add	x10, x13, x1
    326c:      	ldp	q6, q7, [x10]
    3270:      	ldr	q24, [sp, #0x1c0]
    3274:      	zip2.8b	v2, v24, v0
    3278:      	ushll.4s	v2, v2, #0x0
    327c:      	shl.4s	v2, v2, #0x1f
    3280:      	cmlt.4s	v2, v2, #0
    3284:      	and.16b	v7, v2, v7
    3288:      	zip1.8b	v24, v24, v0
    328c:      	ushll.4s	v24, v24, #0x0
    3290:      	shl.4s	v24, v24, #0x1f
    3294:      	cmlt.4s	v8, v24, #0
    3298:      	and.16b	v6, v8, v6
    329c:      	mov.16b	v12, v5
    32a0:      	bsl.16b	v12, v4, v6
    32a4:      	bif.16b	v4, v7, v3
    32a8:      	fmaxnm.4s	v3, v10, v4
    32ac:      	fmaxnm.4s	v5, v11, v12
    32b0:      	and.16b	v5, v8, v5
    32b4:      	and.16b	v3, v2, v3
    32b8:      	zip2.8b	v6, v25, v0
    32bc:      	ushll.4s	v6, v6, #0x0
    32c0:      	shl.4s	v6, v6, #0x1f
    32c4:      	cmlt.4s	v6, v6, #0
    32c8:      	bit.16b	v3, v26, v6
    32cc:      	str	q25, [sp, #0x90]
    32d0:      	zip1.8b	v6, v25, v0
    32d4:      	ushll.4s	v6, v6, #0x0
    32d8:      	shl.4s	v6, v6, #0x1f
    32dc:      	cmlt.4s	v6, v6, #0
    32e0:      	bit.16b	v5, v20, v6
    32e4:      	fmaxnm.4s	v5, v5, v30
    32e8:      	fmaxnm.4s	v3, v3, v29
    32ec:      	fmaxnm.4s	v3, v3, v28
    32f0:      	fmaxnm.4s	v5, v5, v23
    32f4:      	fmaxnm.4s	v20, v5, v22
    32f8:      	fmaxnm.4s	v21, v3, v21
    32fc:      	ldp	q3, q7, [sp, #0x3a0]
    3300:      	ldr	q5, [sp, #0x390]
    3304:      	uzp1.4s	v6, v7, v5
    3308:      	ldr	q5, [sp, #0x380]
    330c:      	uzp1.4s	v5, v5, v3
    3310:      	movi.4s	v7, #0x1
    3314:      	eor.16b	v3, v6, v7
    3318:      	mov.s	w10, v3[1]
    331c:      	eor.16b	v24, v5, v7
    3320:      	mov.s	w11, v3[2]
    3324:      	mov.s	w14, v3[3]
    3328:      	fmov	w13, s3
    332c:      	add	x15, sp, #0x6f8
    3330:      	bfxil	x15, x13, #0, #3
    3334:      	str	d27, [sp, #0x6f8]
    3338:      	ldrb	w15, [x15]
    333c:      	umov.b	w24, v27[0]
    3340:      	and	x13, x13, #0x7
    3344:      	str	q21, [sp, #0x990]
    3348:      	str	q20, [sp, #0x980]
    334c:      	add	x16, sp, #0x980
    3350:      	ldr	s3, [x16, x13, lsl #2]
    3354:      	ands	w13, w24, #0x1
    3358:      	tst	w13, w15
    335c:      	movi	d28, #0000000000000000
    3360:      	fcsel	s7, s3, s28, ne
    3364:      	and	x15, x10, #0x7
    3368:      	add	x16, sp, #0x6f8
    336c:      	bfxil	x16, x10, #0, #3
    3370:      	ldrb	w10, [x16]
    3374:      	umov.b	w23, v27[1]
    3378:      	str	q21, [sp, #0x970]
    337c:      	str	q20, [sp, #0x960]
    3380:      	add	x16, sp, #0x960
    3384:      	ldr	s3, [x16, x15, lsl #2]
    3388:      	and	w10, w23, w10
    338c:      	tst	w10, #0x1
    3390:      	fcsel	s22, s3, s28, ne
    3394:      	and	x10, x11, #0x7
    3398:      	add	x15, sp, #0x6f8
    339c:      	bfxil	x15, x11, #0, #3
    33a0:      	ldrb	w11, [x15]
    33a4:      	umov.b	w21, v27[2]
    33a8:      	and	w11, w21, w11
    33ac:      	str	q21, [sp, #0x950]
    33b0:      	str	q20, [sp, #0x940]
    33b4:      	add	x15, sp, #0x940
    33b8:      	ldr	s3, [x15, x10, lsl #2]
    33bc:      	tst	w11, #0x1
    33c0:      	fcsel	s23, s3, s28, ne
    33c4:      	and	x10, x14, #0x7
    33c8:      	add	x11, sp, #0x6f8
    33cc:      	bfxil	x11, x14, #0, #3
    33d0:      	ldrb	w11, [x11]
    33d4:      	umov.b	w2, v27[3]
    33d8:      	and	w11, w2, w11
    33dc:      	str	q21, [sp, #0x930]
    33e0:      	str	q20, [sp, #0x920]
    33e4:      	add	x14, sp, #0x920
    33e8:      	ldr	s3, [x14, x10, lsl #2]
    33ec:      	tst	w11, #0x1
    33f0:      	mov.s	w10, v24[1]
    33f4:      	fcsel	s3, s3, s28, ne
    33f8:      	mov.s	w11, v24[2]
    33fc:      	mov.s	w14, v24[3]
    3400:      	fmov	w15, s24
    3404:      	and	x16, x15, #0x7
    3408:      	add	x3, sp, #0x6f8
    340c:      	bfxil	x3, x15, #0, #3
    3410:      	ldrb	w15, [x3]
    3414:      	umov.b	w22, v27[4]
    3418:      	and	w15, w22, w15
    341c:      	str	q21, [sp, #0xa10]
    3420:      	str	q20, [sp, #0xa00]
    3424:      	add	x3, sp, #0xa00
    3428:      	ldr	s24, [x3, x16, lsl #2]
    342c:      	tst	w15, #0x1
    3430:      	fcsel	s24, s24, s28, ne
    3434:      	and	x15, x10, #0x7
    3438:      	add	x16, sp, #0x6f8
    343c:      	bfxil	x16, x10, #0, #3
    3440:      	umov.b	w26, v27[5]
    3444:      	ldrb	w10, [x16]
    3448:      	and	w10, w26, w10
    344c:      	str	q21, [sp, #0x9f0]
    3450:      	str	q20, [sp, #0x9e0]
    3454:      	add	x16, sp, #0x9e0
    3458:      	ldr	s25, [x16, x15, lsl #2]
    345c:      	tst	w10, #0x1
    3460:      	fcsel	s25, s25, s28, ne
    3464:      	and	x10, x11, #0x7
    3468:      	add	x15, sp, #0x6f8
    346c:      	bfxil	x15, x11, #0, #3
    3470:      	ldrb	w11, [x15]
    3474:      	umov.b	w17, v27[6]
    3478:      	str	q21, [sp, #0x9d0]
    347c:      	str	q20, [sp, #0x9c0]
    3480:      	add	x15, sp, #0x9c0
    3484:      	ldr	s26, [x15, x10, lsl #2]
    3488:      	and	w10, w17, w11
    348c:      	tst	w10, #0x1
    3490:      	fcsel	s26, s26, s28, ne
    3494:      	and	x10, x14, #0x7
    3498:      	add	x11, sp, #0x6f8
    349c:      	bfxil	x11, x14, #0, #3
    34a0:      	ldrb	w11, [x11]
    34a4:      	str	q27, [sp, #0xb0]
    34a8:      	umov.b	w0, v27[7]
    34ac:      	and	w11, w0, w11
    34b0:      	str	q21, [sp, #0x9b0]
    34b4:      	str	q20, [sp, #0x9a0]
    34b8:      	add	x14, sp, #0x9a0
    34bc:      	ldr	s27, [x14, x10, lsl #2]
    34c0:      	tst	w11, #0x1
    34c4:      	fcsel	s27, s27, s28, ne
    34c8:      	mov.s	v24[1], v25[0]
    34cc:      	mov.s	v24[2], v26[0]
    34d0:      	mov.s	v24[3], v27[0]
    34d4:      	mov.s	v7[1], v22[0]
    34d8:      	mov.s	v7[2], v23[0]
    34dc:      	mov.s	v7[3], v3[0]
    34e0:      	fmaxnm.4s	v7, v20, v7
    34e4:      	fmaxnm.4s	v20, v21, v24
    34e8:      	movi.4s	v21, #0x2
    34ec:      	eor.16b	v3, v6, v21
    34f0:      	mov.s	w10, v3[1]
    34f4:      	mov.s	w11, v3[2]
    34f8:      	eor.16b	v23, v5, v21
    34fc:      	mov.s	w14, v3[3]
    3500:      	fmov	w15, s3
    3504:      	add	x16, sp, #0x6f8
    3508:      	bfxil	x16, x15, #0, #3
    350c:      	ldrb	w16, [x16]
    3510:      	and	x15, x15, #0x7
    3514:      	str	q20, [sp, #0x910]
    3518:      	str	q7, [sp, #0x900]
    351c:      	add	x3, sp, #0x900
    3520:      	ldr	s3, [x3, x15, lsl #2]
    3524:      	tst	w13, w16
    3528:      	fcsel	s5, s3, s28, ne
    352c:      	and	x15, x10, #0x7
    3530:      	add	x16, sp, #0x6f8
    3534:      	bfxil	x16, x10, #0, #3
    3538:      	ldrb	w10, [x16]
    353c:      	and	w10, w23, w10
    3540:      	str	q20, [sp, #0x8f0]
    3544:      	str	q7, [sp, #0x8e0]
    3548:      	add	x16, sp, #0x8e0
    354c:      	ldr	s3, [x16, x15, lsl #2]
    3550:      	tst	w10, #0x1
    3554:      	fcsel	s21, s3, s28, ne
    3558:      	and	x10, x11, #0x7
    355c:      	add	x15, sp, #0x6f8
    3560:      	bfxil	x15, x11, #0, #3
    3564:      	ldrb	w11, [x15]
    3568:      	and	w11, w21, w11
    356c:      	str	q20, [sp, #0x8d0]
    3570:      	str	q7, [sp, #0x8c0]
    3574:      	add	x15, sp, #0x8c0
    3578:      	ldr	s3, [x15, x10, lsl #2]
    357c:      	tst	w11, #0x1
    3580:      	fcsel	s22, s3, s28, ne
    3584:      	and	x10, x14, #0x7
    3588:      	add	x11, sp, #0x6f8
    358c:      	bfxil	x11, x14, #0, #3
    3590:      	ldrb	w11, [x11]
    3594:      	and	w11, w2, w11
    3598:      	str	q20, [sp, #0x8b0]
    359c:      	str	q7, [sp, #0x8a0]
    35a0:      	add	x14, sp, #0x8a0
    35a4:      	ldr	s3, [x14, x10, lsl #2]
    35a8:      	tst	w11, #0x1
    35ac:      	mov.s	w10, v23[3]
    35b0:      	fmov	w11, s23
    35b4:      	and	x4, x11, #0x7
    35b8:      	add	x5, sp, #0x6f8
    35bc:      	bfxil	x5, x11, #0, #3
    35c0:      	add	x11, sp, #0x6f8
    35c4:      	bfxil	x11, x10, #0, #3
    35c8:      	ldrb	w3, [x11]
    35cc:      	movi.4s	v24, #0x4
    35d0:      	eor.16b	v6, v6, v24
    35d4:      	mov.s	w19, v6[1]
    35d8:      	mov.s	w16, v6[2]
    35dc:      	mov.s	w15, v6[3]
    35e0:      	fmov	w14, s6
    35e4:      	add	x11, sp, #0x6f8
    35e8:      	bfxil	x11, x14, #0, #3
    35ec:      	ldrb	w7, [x11]
    35f0:      	add	x11, sp, #0x6f8
    35f4:      	bfxil	x11, x19, #0, #3
    35f8:      	ldrb	w11, [x11]
    35fc:      	add	x27, sp, #0x6f8
    3600:      	bfxil	x27, x16, #0, #3
    3604:      	ldrb	w30, [x27]
    3608:      	add	x27, sp, #0x6f8
    360c:      	bfxil	x27, x15, #0, #3
    3610:      	ldrb	w27, [x27]
    3614:      	ldrb	w5, [x5]
    3618:      	str	q20, [sp, #0x890]
    361c:      	str	q7, [sp, #0x880]
    3620:      	add	x6, sp, #0x880
    3624:      	ldr	s6, [x6, x4, lsl #2]
    3628:      	mov.s	w4, v23[1]
    362c:      	fcsel	s3, s3, s28, ne
    3630:      	and	w5, w22, w5
    3634:      	tst	w5, #0x1
    3638:      	add	x5, sp, #0x6f8
    363c:      	bfxil	x5, x4, #0, #3
    3640:      	and	x4, x4, #0x7
    3644:      	ldrb	w5, [x5]
    3648:      	str	q20, [sp, #0x870]
    364c:      	str	q7, [sp, #0x860]
    3650:      	add	x6, sp, #0x860
    3654:      	ldr	s24, [x6, x4, lsl #2]
    3658:      	mov.s	w4, v23[2]
    365c:      	fcsel	s6, s6, s28, ne
    3660:      	and	w5, w26, w5
    3664:      	tst	w5, #0x1
    3668:      	add	x5, sp, #0x6f8
    366c:      	bfxil	x5, x4, #0, #3
    3670:      	and	x4, x4, #0x7
    3674:      	ldrb	w5, [x5]
    3678:      	str	q20, [sp, #0x850]
    367c:      	str	q7, [sp, #0x840]
    3680:      	add	x6, sp, #0x840
    3684:      	ldr	s23, [x6, x4, lsl #2]
    3688:      	mov	x6, x23
    368c:      	fcsel	s24, s24, s28, ne
    3690:      	and	w4, w17, w5
    3694:      	mov	x5, x21
    3698:      	tst	w4, #0x1
    369c:      	and	x10, x10, #0x7
    36a0:      	str	q20, [sp, #0x830]
    36a4:      	str	q7, [sp, #0x820]
    36a8:      	add	x4, sp, #0x820
    36ac:      	ldr	s25, [x4, x10, lsl #2]
    36b0:      	fcsel	s23, s23, s28, ne
    36b4:      	and	w10, w0, w3
    36b8:      	tst	w10, #0x1
    36bc:      	fcsel	s25, s25, s28, ne
    36c0:      	mov.s	v6[1], v24[0]
    36c4:      	mov.s	v6[2], v23[0]
    36c8:      	mov.s	v6[3], v25[0]
    36cc:      	mov.s	v5[1], v21[0]
    36d0:      	mov.s	v5[2], v22[0]
    36d4:      	mov.s	v5[3], v3[0]
    36d8:      	fmaxnm.4s	v3, v7, v5
    36dc:      	fmaxnm.4s	v5, v20, v6
    36e0:      	and	x10, x14, #0x7
    36e4:      	str	q5, [sp, #0x810]
    36e8:      	str	q3, [sp, #0x800]
    36ec:      	add	x14, sp, #0x800
    36f0:      	ldr	s6, [x14, x10, lsl #2]
    36f4:      	tst	w13, w7
    36f8:      	fcsel	s6, s6, s28, ne
    36fc:      	and	x10, x19, #0x7
    3700:      	and	w11, w23, w11
    3704:      	str	q5, [sp, #0x7f0]
    3708:      	str	q3, [sp, #0x7e0]
    370c:      	add	x13, sp, #0x7e0
    3710:      	ldr	s7, [x13, x10, lsl #2]
    3714:      	tst	w11, #0x1
    3718:      	fcsel	s7, s7, s28, ne
    371c:      	and	x10, x16, #0x7
    3720:      	and	w11, w21, w30
    3724:      	str	q5, [sp, #0x7d0]
    3728:      	str	q3, [sp, #0x7c0]
    372c:      	add	x13, sp, #0x7c0
    3730:      	ldr	s20, [x13, x10, lsl #2]
    3734:      	tst	w11, #0x1
    3738:      	fcsel	s20, s20, s28, ne
    373c:      	and	x10, x15, #0x7
    3740:      	str	q5, [sp, #0x7b0]
    3744:      	str	q3, [sp, #0x7a0]
    3748:      	add	x11, sp, #0x7a0
    374c:      	ldr	s5, [x11, x10, lsl #2]
    3750:      	and	w10, w2, w27
    3754:      	tst	w10, #0x1
    3758:      	fcsel	s5, s5, s28, ne
    375c:      	ands	w30, w24, #0x1
    3760:      	add	x10, x12, x1
    3764:      	ldp	q21, q22, [x10]
    3768:      	bsl.16b	v2, v4, v22
    376c:      	mov.16b	v4, v8
    3770:      	bsl.16b	v4, v12, v21
    3774:      	mov.s	v6[1], v7[0]
    3778:      	stp	q4, q2, [x10]
    377c:      	mov.s	v6[2], v20[0]
    3780:      	mov.s	v6[3], v5[0]
    3784:      	fmaxnm.4s	v2, v3, v6
    3788:      	fcsel	s3, s2, s28, ne
    378c:      	and	w16, w23, w24
    3790:      	tst	w16, #0x1
    3794:      	fcsel	s4, s2, s28, ne
    3798:      	and	w27, w21, w24
    379c:      	tst	w27, #0x1
    37a0:      	fcsel	s5, s2, s28, ne
    37a4:      	and	w19, w2, w24
    37a8:      	tst	w19, #0x1
    37ac:      	fcsel	s6, s2, s28, ne
    37b0:      	mov	x3, x22
    37b4:      	and	w13, w22, w24
    37b8:      	tst	w13, #0x1
    37bc:      	fcsel	s7, s2, s28, ne
    37c0:      	str	w26, [sp, #0xc4]
    37c4:      	and	w15, w26, w24
    37c8:      	tst	w15, #0x1
    37cc:      	fcsel	s20, s2, s28, ne
    37d0:      	stp	w17, w0, [sp, #0xd0]
    37d4:      	and	w10, w17, w24
    37d8:      	str	w10, [sp, #0x88]
    37dc:      	tst	w10, #0x1
    37e0:      	fcsel	s21, s2, s28, ne
    37e4:      	str	w24, [sp, #0xcc]
    37e8:      	and	w10, w0, w24
    37ec:      	str	w10, [sp, #0x8c]
    37f0:      	tst	w10, #0x1
    37f4:      	fcsel	s2, s2, s28, ne
    37f8:      	mov.s	v3[1], v4[0]
    37fc:      	mov.s	v3[2], v5[0]
    3800:      	mov.s	v3[3], v6[0]
    3804:      	mov.s	v7[1], v20[0]
    3808:      	mov.s	v7[2], v21[0]
    380c:      	mov.s	v7[3], v2[0]
    3810:      	ldr	w10, [sp, #0x3d0]
    3814:      	rbit	w10, w10
    3818:      	clz	w7, w10
    381c:      	str	q7, [sp, #0x710]
    3820:      	str	q3, [sp, #0x700]
    3824:      	and	x10, x7, #0x7
    3828:      	add	x11, sp, #0x700
    382c:      	ldr	s4, [x11, x10, lsl #2]
    3830:      	fmov	w10, s14
    3834:      	tbz	w10, #0x0, 0x3878 <_llm_rows.packet_batch.blocks+0x1d0c>
    3838:      	fmov	x11, d16
    383c:      	ldr	b2, [x11]
    3840:      	b	0x387c <_llm_rows.packet_batch.blocks+0x1d10>
    3844:      	ldr	q3, [sp, #0xf0]
    3848:      	fmov	x10, d3
    384c:      	ld1.b	{ v2 }[2], [x10]
    3850:      	tbz	w15, #0x3, 0x3214 <_llm_rows.packet_batch.blocks+0x16a8>
    3854:      	ld1.b	{ v2 }[3], [x0]
    3858:      	tbz	w15, #0x4, 0x3218 <_llm_rows.packet_batch.blocks+0x16ac>
    385c:      	ldr	q3, [sp, #0x100]
    3860:      	fmov	x10, d3
    3864:      	ld1.b	{ v2 }[4], [x10]
    3868:      	tbz	w15, #0x5, 0x321c <_llm_rows.packet_batch.blocks+0x16b0>
    386c:      	ld1.b	{ v2 }[5], [x17]
    3870:      	tbnz	w15, #0x6, 0x3220 <_llm_rows.packet_batch.blocks+0x16b4>
    3874:      	b	0x322c <_llm_rows.packet_batch.blocks+0x16c0>
    3878:      	movi.2d	v2, #0000000000000000
    387c:      	ldr	x4, [sp, #0xd8]
    3880:      	ldr	q10, [sp, #0x300]
    3884:      	ldp	q12, q11, [sp, #0x3e0]
    3888:      	ldp	x23, x21, [sp, #0x10]
    388c:      	ldr	w24, [sp, #0xc8]
    3890:      	and	w10, w10, #0xff
    3894:      	mov	w26, #0x4               ; =4
    3898:      	tbnz	w10, #0x1, 0x3b54 <_llm_rows.packet_batch.blocks+0x1fe8>
    389c:      	tbnz	w10, #0x2, 0x3b60 <_llm_rows.packet_batch.blocks+0x1ff4>
    38a0:      	tbnz	w10, #0x3, 0x3b6c <_llm_rows.packet_batch.blocks+0x2000>
    38a4:      	tbnz	w10, #0x4, 0x3b78 <_llm_rows.packet_batch.blocks+0x200c>
    38a8:      	tbnz	w10, #0x5, 0x3b84 <_llm_rows.packet_batch.blocks+0x2018>
    38ac:      	tbnz	w10, #0x6, 0x3b90 <_llm_rows.packet_batch.blocks+0x2024>
    38b0:      	tbz	w10, #0x7, 0x38bc <_llm_rows.packet_batch.blocks+0x1d50>
    38b4:      	ldr	x10, [sp, #0x50]
    38b8:      	ld1.b	{ v2 }[7], [x10]
    38bc:      	mov	w10, #-0x800000         ; =-8388608
    38c0:      	fmov	s3, w10
    38c4:      	fmaxnm	s3, s4, s3
    38c8:      	ldr	x10, [sp, #0x370]
    38cc:      	add	x10, x12, x10
    38d0:      	ldp	q5, q4, [x10]
    38d4:      	dup.4s	v6, v3[0]
    38d8:      	fsub.4s	v3, v5, v6
    38dc:      	str	q6, [sp, #0x370]
    38e0:      	fsub.4s	v4, v4, v6
    38e4:      	and.16b	v21, v0, v4
    38e8:      	and.16b	v4, v1, v3
    38ec:      	mov	w10, #-0x3d300000       ; =-1026555904
    38f0:      	dup.4s	v15, w10
    38f4:      	fcmge.4s	v3, v4, v15
    38f8:      	fcmge.4s	v5, v21, v15
    38fc:      	mov	w10, #0x42c80000        ; =1120403456
    3900:      	dup.4s	v20, w10
    3904:      	fcmge.4s	v6, v20, v4
    3908:      	fcmge.4s	v7, v20, v21
    390c:      	and.16b	v5, v5, v7
    3910:      	and.16b	v3, v3, v6
    3914:      	and.16b	v3, v3, v4
    3918:      	and.16b	v5, v5, v21
    391c:      	mov	w10, #0xaa3b            ; =43579
    3920:      	movk	w10, #0x3fb8, lsl #16
    3924:      	dup.4s	v6, w10
    3928:      	fmul.4s	v7, v5, v6
    392c:      	str	q6, [sp, #0x3f0]
    3930:      	fmul.4s	v16, v3, v6
    3934:      	movi.4s	v6, #0x4b, lsl #24
    3938:      	mvni.4s	v18, #0x80, lsl #24
    393c:      	mov.16b	v17, v18
    3940:      	bsl.16b	v17, v6, v16
    3944:      	bsl.16b	v18, v6, v7
    3948:      	fadd.4s	v7, v7, v18
    394c:      	fadd.4s	v16, v16, v17
    3950:      	fsub.4s	v16, v16, v17
    3954:      	fsub.4s	v7, v7, v18
    3958:      	fcvtzs.4s	v22, v7
    395c:      	fcvtzs.4s	v23, v16
    3960:      	scvtf.4s	v16, v23
    3964:      	scvtf.4s	v17, v22
    3968:      	mov	w10, #0x7200            ; =29184
    396c:      	movk	w10, #0xbf31, lsl #16
    3970:      	dup.4s	v6, w10
    3974:      	fmul.4s	v18, v17, v6
    3978:      	str	q6, [sp, #0x3e0]
    397c:      	fmul.4s	v19, v16, v6
    3980:      	fadd.4s	v3, v3, v19
    3984:      	fadd.4s	v5, v5, v18
    3988:      	mov	w10, #0xbe8e            ; =48782
    398c:      	movk	w10, #0xb5bf, lsl #16
    3990:      	dup.4s	v6, w10
    3994:      	fmul.4s	v16, v16, v6
    3998:      	str	q6, [sp, #0x3d0]
    399c:      	fmul.4s	v17, v17, v6
    39a0:      	fadd.4s	v5, v5, v17
    39a4:      	fadd.4s	v3, v3, v16
    39a8:      	mov	w10, #0x2bda            ; =11226
    39ac:      	movk	w10, #0x3950, lsl #16
    39b0:      	dup.4s	v6, w10
    39b4:      	fmul.4s	v17, v3, v6
    39b8:      	str	q6, [sp, #0x3c0]
    39bc:      	fmul.4s	v18, v5, v6
    39c0:      	mov	w10, #0x96c9            ; =38601
    39c4:      	movk	w10, #0x3ab6, lsl #16
    39c8:      	dup.4s	v6, w10
    39cc:      	fadd.4s	v18, v18, v6
    39d0:      	str	q6, [sp, #0x3b0]
    39d4:      	fadd.4s	v17, v17, v6
    39d8:      	fmul.4s	v19, v3, v17
    39dc:      	fmul.4s	v18, v5, v18
    39e0:      	mov	w10, #0x88a6            ; =34982
    39e4:      	movk	w10, #0x3c08, lsl #16
    39e8:      	dup.4s	v6, w10
    39ec:      	fadd.4s	v18, v18, v6
    39f0:      	str	q6, [sp, #0x3a0]
    39f4:      	fadd.4s	v19, v19, v6
    39f8:      	fmul.4s	v19, v3, v19
    39fc:      	fmul.4s	v24, v5, v18
    3a00:      	mov	w10, #0xaa7a            ; =43642
    3a04:      	movk	w10, #0x3d2a, lsl #16
    3a08:      	dup.4s	v6, w10
    3a0c:      	fadd.4s	v24, v24, v6
    3a10:      	str	q6, [sp, #0x390]
    3a14:      	fadd.4s	v19, v19, v6
    3a18:      	fmul.4s	v25, v3, v19
    3a1c:      	fmul.4s	v24, v5, v24
    3a20:      	mov	w10, #0xaaab            ; =43691
    3a24:      	movk	w10, #0x3e2a, lsl #16
    3a28:      	dup.4s	v6, w10
    3a2c:      	fadd.4s	v24, v24, v6
    3a30:      	str	q6, [sp, #0x380]
    3a34:      	fadd.4s	v25, v25, v6
    3a38:      	fmul.4s	v25, v3, v25
    3a3c:      	fmul.4s	v24, v5, v24
    3a40:      	movi.4s	v6, #0x3f, lsl #24
    3a44:      	fadd.4s	v24, v24, v6
    3a48:      	fadd.4s	v25, v25, v6
    3a4c:      	fmul.4s	v26, v5, v5
    3a50:      	fmul.4s	v27, v3, v3
    3a54:      	fmul.4s	v25, v27, v25
    3a58:      	fmul.4s	v24, v26, v24
    3a5c:      	fadd.4s	v24, v5, v24
    3a60:      	fadd.4s	v3, v3, v25
    3a64:      	fmov.4s	v5, #1.00000000
    3a68:      	fadd.4s	v3, v3, v5
    3a6c:      	fadd.4s	v24, v24, v5
    3a70:      	sshr.4s	v25, v23, #0x1
    3a74:      	sshr.4s	v26, v22, #0x1
    3a78:      	shl.4s	v27, v26, #0x17
    3a7c:      	add.4s	v27, v27, v5
    3a80:      	fmul.4s	v24, v24, v27
    3a84:      	shl.4s	v27, v25, #0x17
    3a88:      	add.4s	v27, v27, v5
    3a8c:      	fmul.4s	v3, v3, v27
    3a90:      	sub.4s	v22, v22, v26
    3a94:      	sub.4s	v23, v23, v25
    3a98:      	shl.4s	v23, v23, #0x17
    3a9c:      	add.4s	v23, v23, v5
    3aa0:      	fmul.4s	v3, v3, v23
    3aa4:      	shl.4s	v22, v22, #0x17
    3aa8:      	add.4s	v22, v22, v5
    3aac:      	fmul.4s	v22, v24, v22
    3ab0:      	fcmgt.4s	v23, v15, v21
    3ab4:      	bic.16b	v22, v22, v23
    3ab8:      	fcmgt.4s	v23, v15, v4
    3abc:      	bic.16b	v3, v3, v23
    3ac0:      	fcmgt.4s	v23, v4, v20
    3ac4:      	ldr	q6, [sp, #0x410]
    3ac8:      	bit.16b	v3, v6, v23
    3acc:      	fcmgt.4s	v23, v21, v20
    3ad0:      	bit.16b	v22, v6, v23
    3ad4:      	fcmeq.4s	v21, v21, v21
    3ad8:      	ldr	q6, [sp, #0x400]
    3adc:      	bsl.16b	v21, v22, v6
    3ae0:      	cmeq.8b	v2, v2, #0
    3ae4:      	sshll.8h	v2, v2, #0x0
    3ae8:      	fcmeq.4s	v4, v4, v4
    3aec:      	bif.16b	v3, v6, v4
    3af0:      	sshll2.4s	v4, v2, #0x0
    3af4:      	sshll.4s	v2, v2, #0x0
    3af8:      	bic.16b	v29, v3, v2
    3afc:      	bic.16b	v30, v21, v4
    3b00:      	ldp	q2, q3, [x9]
    3b04:      	bit.16b	v3, v30, v0
    3b08:      	bit.16b	v2, v29, v1
    3b0c:      	stp	q2, q3, [x9]
    3b10:      	sshll.2d	v4, v1, #0x0
    3b14:      	adrp	x10, 0x3000 <_llm_rows.packet_batch.blocks+0x1494>
    3b18:      	ldr	q2, [x10]
    3b1c:      	and.16b	v2, v4, v2
    3b20:      	fmov	w10, s14
    3b24:      	ldr	q3, [sp, #0x420]
    3b28:      	add.2d	v3, v3, v2
    3b2c:      	tbz	w10, #0x0, 0x3ba0 <_llm_rows.packet_batch.blocks+0x2034>
    3b30:      	fmov	x11, d3
    3b34:      	ldr	b2, [x11]
    3b38:      	ldr	q18, [sp, #0x2f0]
    3b3c:      	ldr	q19, [sp, #0x220]
    3b40:      	and	w14, w10, #0xff
    3b44:      	movi.4s	v6, #0x4b, lsl #24
    3b48:      	mvni.4s	v7, #0x80, lsl #24
    3b4c:      	tbnz	w14, #0x1, 0x3bbc <_llm_rows.packet_batch.blocks+0x2050>
    3b50:      	b	0x3bc4 <_llm_rows.packet_batch.blocks+0x2058>
    3b54:      	ldr	x11, [sp, #0x210]
    3b58:      	ld1.b	{ v2 }[1], [x11]
    3b5c:      	tbz	w10, #0x2, 0x38a0 <_llm_rows.packet_batch.blocks+0x1d34>
    3b60:      	fmov	x11, d17
    3b64:      	ld1.b	{ v2 }[2], [x11]
    3b68:      	tbz	w10, #0x3, 0x38a4 <_llm_rows.packet_batch.blocks+0x1d38>
    3b6c:      	ldr	x11, [sp, #0x60]
    3b70:      	ld1.b	{ v2 }[3], [x11]
    3b74:      	tbz	w10, #0x4, 0x38a8 <_llm_rows.packet_batch.blocks+0x1d3c>
    3b78:      	fmov	x11, d18
    3b7c:      	ld1.b	{ v2 }[4], [x11]
    3b80:      	tbz	w10, #0x5, 0x38ac <_llm_rows.packet_batch.blocks+0x1d40>
    3b84:      	ldr	x11, [sp, #0x58]
    3b88:      	ld1.b	{ v2 }[5], [x11]
    3b8c:      	tbz	w10, #0x6, 0x38b0 <_llm_rows.packet_batch.blocks+0x1d44>
    3b90:      	fmov	x11, d19
    3b94:      	ld1.b	{ v2 }[6], [x11]
    3b98:      	tbnz	w10, #0x7, 0x38b4 <_llm_rows.packet_batch.blocks+0x1d48>
    3b9c:      	b	0x38bc <_llm_rows.packet_batch.blocks+0x1d50>
    3ba0:      	movi.2d	v2, #0000000000000000
    3ba4:      	ldr	q18, [sp, #0x2f0]
    3ba8:      	ldr	q19, [sp, #0x220]
    3bac:      	and	w14, w10, #0xff
    3bb0:      	movi.4s	v6, #0x4b, lsl #24
    3bb4:      	mvni.4s	v7, #0x80, lsl #24
    3bb8:      	tbz	w14, #0x1, 0x3bc4 <_llm_rows.packet_batch.blocks+0x2058>
    3bbc:      	mov.d	x10, v3[1]
    3bc0:      	ld1.b	{ v2 }[1], [x10]
    3bc4:      	adrp	x10, 0x3000 <_llm_rows.packet_batch.blocks+0x1494>
    3bc8:      	ldr	q3, [x10]
    3bcc:      	ldr	q16, [sp, #0x310]
    3bd0:      	and.16b	v3, v16, v3
    3bd4:      	ldr	q16, [sp, #0x440]
    3bd8:      	add.2d	v3, v16, v3
    3bdc:      	tbz	w14, #0x2, 0x3be8 <_llm_rows.packet_batch.blocks+0x207c>
    3be0:      	fmov	x10, d3
    3be4:      	ld1.b	{ v2 }[2], [x10]
    3be8:      	tbz	w14, #0x3, 0x3bf4 <_llm_rows.packet_batch.blocks+0x2088>
    3bec:      	mov.d	x10, v3[1]
    3bf0:      	ld1.b	{ v2 }[3], [x10]
    3bf4:      	sshll.2d	v21, v0, #0x0
    3bf8:      	adrp	x10, 0x3000 <_llm_rows.packet_batch.blocks+0x1494>
    3bfc:      	ldr	q3, [x10]
    3c00:      	and.16b	v3, v21, v3
    3c04:      	ldr	q16, [sp, #0x430]
    3c08:      	add.2d	v3, v16, v3
    3c0c:      	tbnz	w14, #0x4, 0x3e30 <_llm_rows.packet_batch.blocks+0x22c4>
    3c10:      	tbnz	w14, #0x5, 0x3e3c <_llm_rows.packet_batch.blocks+0x22d0>
    3c14:      	adrp	x10, 0x3000 <_llm_rows.packet_batch.blocks+0x1494>
    3c18:      	ldr	q3, [x10]
    3c1c:      	and.16b	v3, v10, v3
    3c20:      	ldr	q16, [sp, #0x450]
    3c24:      	add.2d	v3, v16, v3
    3c28:      	tbnz	w14, #0x6, 0x3e5c <_llm_rows.packet_batch.blocks+0x22f0>
    3c2c:      	tbz	w14, #0x7, 0x3c38 <_llm_rows.packet_batch.blocks+0x20cc>
    3c30:      	mov.d	x10, v3[1]
    3c34:      	ld1.b	{ v2 }[7], [x10]
    3c38:      	mov	w10, #0x20              ; =32
    3c3c:      	fmov	d3, x10
    3c40:      	and.16b	v3, v4, v3
    3c44:      	fmov	x10, d3
    3c48:      	add	x10, x12, x10
    3c4c:      	ldp	q22, q3, [x10]
    3c50:      	ldr	q16, [sp, #0x370]
    3c54:      	fsub.4s	v22, v22, v16
    3c58:      	fsub.4s	v3, v3, v16
    3c5c:      	and.16b	v3, v0, v3
    3c60:      	and.16b	v22, v1, v22
    3c64:      	fcmge.4s	v23, v22, v15
    3c68:      	fcmge.4s	v24, v3, v15
    3c6c:      	fcmge.4s	v25, v20, v22
    3c70:      	fcmge.4s	v26, v20, v3
    3c74:      	and.16b	v24, v24, v26
    3c78:      	and.16b	v23, v23, v25
    3c7c:      	and.16b	v23, v23, v22
    3c80:      	and.16b	v24, v24, v3
    3c84:      	ldp	q16, q17, [sp, #0x3e0]
    3c88:      	fmul.4s	v25, v24, v17
    3c8c:      	fmul.4s	v26, v23, v17
    3c90:      	mov.16b	v27, v7
    3c94:      	bsl.16b	v27, v6, v26
    3c98:      	mov.16b	v28, v7
    3c9c:      	bsl.16b	v28, v6, v25
    3ca0:      	fadd.4s	v25, v25, v28
    3ca4:      	fadd.4s	v26, v26, v27
    3ca8:      	fsub.4s	v26, v26, v27
    3cac:      	fsub.4s	v25, v25, v28
    3cb0:      	fcvtzs.4s	v25, v25
    3cb4:      	fcvtzs.4s	v26, v26
    3cb8:      	scvtf.4s	v27, v26
    3cbc:      	scvtf.4s	v28, v25
    3cc0:      	fmul.4s	v31, v27, v16
    3cc4:      	fadd.4s	v23, v23, v31
    3cc8:      	fmul.4s	v31, v28, v16
    3ccc:      	fadd.4s	v24, v24, v31
    3cd0:      	ldp	q16, q17, [sp, #0x3c0]
    3cd4:      	fmul.4s	v27, v27, v17
    3cd8:      	fmul.4s	v28, v28, v17
    3cdc:      	fadd.4s	v24, v24, v28
    3ce0:      	fadd.4s	v23, v23, v27
    3ce4:      	fmul.4s	v27, v23, v16
    3ce8:      	fmul.4s	v28, v24, v16
    3cec:      	ldp	q16, q17, [sp, #0x3a0]
    3cf0:      	fadd.4s	v28, v28, v17
    3cf4:      	fadd.4s	v27, v27, v17
    3cf8:      	fmul.4s	v27, v23, v27
    3cfc:      	fmul.4s	v28, v24, v28
    3d00:      	fadd.4s	v28, v28, v16
    3d04:      	fadd.4s	v27, v27, v16
    3d08:      	fmul.4s	v27, v23, v27
    3d0c:      	fmul.4s	v28, v24, v28
    3d10:      	ldp	q16, q17, [sp, #0x380]
    3d14:      	fadd.4s	v28, v28, v17
    3d18:      	fadd.4s	v27, v27, v17
    3d1c:      	fmul.4s	v27, v23, v27
    3d20:      	fmul.4s	v28, v24, v28
    3d24:      	fadd.4s	v28, v28, v16
    3d28:      	fadd.4s	v27, v27, v16
    3d2c:      	fmul.4s	v27, v23, v27
    3d30:      	fmul.4s	v28, v24, v28
    3d34:      	movi.4s	v16, #0x3f, lsl #24
    3d38:      	fadd.4s	v28, v28, v16
    3d3c:      	fadd.4s	v27, v27, v16
    3d40:      	fmul.4s	v31, v23, v23
    3d44:      	fmul.4s	v27, v31, v27
    3d48:      	fmul.4s	v31, v24, v24
    3d4c:      	fmul.4s	v28, v31, v28
    3d50:      	fadd.4s	v24, v24, v28
    3d54:      	fadd.4s	v23, v23, v27
    3d58:      	fadd.4s	v23, v23, v5
    3d5c:      	fadd.4s	v24, v24, v5
    3d60:      	sshr.4s	v27, v26, #0x1
    3d64:      	sshr.4s	v28, v25, #0x1
    3d68:      	shl.4s	v31, v28, #0x17
    3d6c:      	add.4s	v31, v31, v5
    3d70:      	fmul.4s	v24, v24, v31
    3d74:      	shl.4s	v31, v27, #0x17
    3d78:      	add.4s	v31, v31, v5
    3d7c:      	fmul.4s	v23, v23, v31
    3d80:      	sub.4s	v25, v25, v28
    3d84:      	sub.4s	v26, v26, v27
    3d88:      	shl.4s	v26, v26, #0x17
    3d8c:      	add.4s	v26, v26, v5
    3d90:      	fmul.4s	v23, v23, v26
    3d94:      	shl.4s	v25, v25, #0x17
    3d98:      	add.4s	v25, v25, v5
    3d9c:      	fmul.4s	v24, v24, v25
    3da0:      	fcmgt.4s	v25, v15, v3
    3da4:      	bic.16b	v24, v24, v25
    3da8:      	fcmgt.4s	v25, v15, v22
    3dac:      	bic.16b	v23, v23, v25
    3db0:      	fcmgt.4s	v25, v22, v20
    3db4:      	ldr	q16, [sp, #0x410]
    3db8:      	bit.16b	v23, v16, v25
    3dbc:      	fcmgt.4s	v25, v3, v20
    3dc0:      	bit.16b	v24, v16, v25
    3dc4:      	fcmeq.4s	v3, v3, v3
    3dc8:      	ldr	q16, [sp, #0x400]
    3dcc:      	bsl.16b	v3, v24, v16
    3dd0:      	cmeq.8b	v2, v2, #0
    3dd4:      	sshll.8h	v2, v2, #0x0
    3dd8:      	fcmeq.4s	v22, v22, v22
    3ddc:      	bsl.16b	v22, v23, v16
    3de0:      	sshll2.4s	v23, v2, #0x0
    3de4:      	sshll.4s	v2, v2, #0x0
    3de8:      	bic.16b	v2, v22, v2
    3dec:      	bic.16b	v23, v3, v23
    3df0:      	ldp	q3, q22, [x9, #0x20]
    3df4:      	bit.16b	v22, v23, v0
    3df8:      	bit.16b	v3, v2, v1
    3dfc:      	stp	q3, q22, [x9, #0x20]
    3e00:      	adrp	x10, 0x3000 <_llm_rows.packet_batch.blocks+0x1494>
    3e04:      	ldr	q3, [x10]
    3e08:      	and.16b	v3, v4, v3
    3e0c:      	fmov	w10, s14
    3e10:      	ldr	q16, [sp, #0x420]
    3e14:      	add.2d	v3, v16, v3
    3e18:      	tbz	w10, #0x0, 0x3e6c <_llm_rows.packet_batch.blocks+0x2300>
    3e1c:      	fmov	x11, d3
    3e20:      	ldr	b22, [x11]
    3e24:      	and	w14, w10, #0xff
    3e28:      	tbnz	w14, #0x1, 0x3e78 <_llm_rows.packet_batch.blocks+0x230c>
    3e2c:      	b	0x3e80 <_llm_rows.packet_batch.blocks+0x2314>
    3e30:      	fmov	x10, d3
    3e34:      	ld1.b	{ v2 }[4], [x10]
    3e38:      	tbz	w14, #0x5, 0x3c14 <_llm_rows.packet_batch.blocks+0x20a8>
    3e3c:      	mov.d	x10, v3[1]
    3e40:      	ld1.b	{ v2 }[5], [x10]
    3e44:      	adrp	x10, 0x3000 <_llm_rows.packet_batch.blocks+0x1494>
    3e48:      	ldr	q3, [x10]
    3e4c:      	and.16b	v3, v10, v3
    3e50:      	ldr	q16, [sp, #0x450]
    3e54:      	add.2d	v3, v16, v3
    3e58:      	tbz	w14, #0x6, 0x3c2c <_llm_rows.packet_batch.blocks+0x20c0>
    3e5c:      	fmov	x10, d3
    3e60:      	ld1.b	{ v2 }[6], [x10]
    3e64:      	tbnz	w14, #0x7, 0x3c30 <_llm_rows.packet_batch.blocks+0x20c4>
    3e68:      	b	0x3c38 <_llm_rows.packet_batch.blocks+0x20cc>
    3e6c:      	movi.2d	v22, #0000000000000000
    3e70:      	and	w14, w10, #0xff
    3e74:      	tbz	w14, #0x1, 0x3e80 <_llm_rows.packet_batch.blocks+0x2314>
    3e78:      	mov.d	x10, v3[1]
    3e7c:      	ld1.b	{ v22 }[1], [x10]
    3e80:      	adrp	x10, 0x3000 <_llm_rows.packet_batch.blocks+0x1494>
    3e84:      	ldr	q3, [x10]
    3e88:      	ldr	q16, [sp, #0x310]
    3e8c:      	and.16b	v3, v16, v3
    3e90:      	ldr	q16, [sp, #0x440]
    3e94:      	add.2d	v3, v16, v3
    3e98:      	tbnz	w14, #0x2, 0x40d4 <_llm_rows.packet_batch.blocks+0x2568>
    3e9c:      	tbnz	w14, #0x3, 0x40e0 <_llm_rows.packet_batch.blocks+0x2574>
    3ea0:      	adrp	x10, 0x3000 <_llm_rows.packet_batch.blocks+0x1494>
    3ea4:      	ldr	q3, [x10]
    3ea8:      	and.16b	v3, v21, v3
    3eac:      	ldr	q16, [sp, #0x430]
    3eb0:      	add.2d	v3, v16, v3
    3eb4:      	tbnz	w14, #0x4, 0x4100 <_llm_rows.packet_batch.blocks+0x2594>
    3eb8:      	tbnz	w14, #0x5, 0x410c <_llm_rows.packet_batch.blocks+0x25a0>
    3ebc:      	adrp	x10, 0x3000 <_llm_rows.packet_batch.blocks+0x1494>
    3ec0:      	ldr	q3, [x10]
    3ec4:      	and.16b	v3, v10, v3
    3ec8:      	ldr	q16, [sp, #0x450]
    3ecc:      	add.2d	v3, v16, v3
    3ed0:      	tbnz	w14, #0x6, 0x412c <_llm_rows.packet_batch.blocks+0x25c0>
    3ed4:      	tbz	w14, #0x7, 0x3ee0 <_llm_rows.packet_batch.blocks+0x2374>
    3ed8:      	mov.d	x10, v3[1]
    3edc:      	ld1.b	{ v22 }[7], [x10]
    3ee0:      	ldr	q3, [sp, #0x30]
    3ee4:      	and.16b	v3, v4, v3
    3ee8:      	fmov	x10, d3
    3eec:      	add	x10, x12, x10
    3ef0:      	ldp	q24, q3, [x10]
    3ef4:      	ldr	q16, [sp, #0x370]
    3ef8:      	fsub.4s	v24, v24, v16
    3efc:      	fsub.4s	v3, v3, v16
    3f00:      	and.16b	v3, v0, v3
    3f04:      	and.16b	v24, v1, v24
    3f08:      	fcmge.4s	v25, v24, v15
    3f0c:      	fcmge.4s	v26, v3, v15
    3f10:      	fcmge.4s	v27, v20, v24
    3f14:      	fcmge.4s	v28, v20, v3
    3f18:      	and.16b	v26, v26, v28
    3f1c:      	and.16b	v25, v25, v27
    3f20:      	and.16b	v25, v25, v24
    3f24:      	and.16b	v26, v26, v3
    3f28:      	ldp	q16, q17, [sp, #0x3e0]
    3f2c:      	fmul.4s	v27, v26, v17
    3f30:      	fmul.4s	v28, v25, v17
    3f34:      	mov.16b	v31, v7
    3f38:      	bsl.16b	v31, v6, v28
    3f3c:      	mov.16b	v8, v7
    3f40:      	bsl.16b	v8, v6, v27
    3f44:      	fadd.4s	v27, v27, v8
    3f48:      	fadd.4s	v28, v28, v31
    3f4c:      	fsub.4s	v28, v28, v31
    3f50:      	fsub.4s	v27, v27, v8
    3f54:      	fcvtzs.4s	v27, v27
    3f58:      	fcvtzs.4s	v28, v28
    3f5c:      	scvtf.4s	v31, v28
    3f60:      	scvtf.4s	v8, v27
    3f64:      	fmul.4s	v9, v31, v16
    3f68:      	fadd.4s	v25, v25, v9
    3f6c:      	fmul.4s	v9, v8, v16
    3f70:      	fadd.4s	v26, v26, v9
    3f74:      	ldp	q16, q17, [sp, #0x3c0]
    3f78:      	fmul.4s	v31, v31, v17
    3f7c:      	fmul.4s	v8, v8, v17
    3f80:      	fadd.4s	v26, v26, v8
    3f84:      	fadd.4s	v25, v25, v31
    3f88:      	fmul.4s	v31, v25, v16
    3f8c:      	fmul.4s	v8, v26, v16
    3f90:      	ldp	q16, q17, [sp, #0x3a0]
    3f94:      	fadd.4s	v8, v8, v17
    3f98:      	fadd.4s	v31, v31, v17
    3f9c:      	fmul.4s	v31, v25, v31
    3fa0:      	fmul.4s	v8, v26, v8
    3fa4:      	fadd.4s	v8, v8, v16
    3fa8:      	fadd.4s	v31, v31, v16
    3fac:      	fmul.4s	v31, v25, v31
    3fb0:      	fmul.4s	v8, v26, v8
    3fb4:      	ldp	q16, q17, [sp, #0x380]
    3fb8:      	fadd.4s	v8, v8, v17
    3fbc:      	fadd.4s	v31, v31, v17
    3fc0:      	fmul.4s	v31, v25, v31
    3fc4:      	fmul.4s	v8, v26, v8
    3fc8:      	fadd.4s	v8, v8, v16
    3fcc:      	fadd.4s	v31, v31, v16
    3fd0:      	fmul.4s	v31, v25, v31
    3fd4:      	fmul.4s	v8, v26, v8
    3fd8:      	movi.4s	v16, #0x3f, lsl #24
    3fdc:      	fadd.4s	v8, v8, v16
    3fe0:      	fadd.4s	v31, v31, v16
    3fe4:      	fmul.4s	v9, v25, v25
    3fe8:      	fmul.4s	v31, v9, v31
    3fec:      	fmul.4s	v9, v26, v26
    3ff0:      	fmul.4s	v8, v9, v8
    3ff4:      	fadd.4s	v26, v26, v8
    3ff8:      	fadd.4s	v25, v25, v31
    3ffc:      	fadd.4s	v25, v25, v5
    4000:      	fadd.4s	v26, v26, v5
    4004:      	sshr.4s	v31, v28, #0x1
    4008:      	sshr.4s	v8, v27, #0x1
    400c:      	shl.4s	v9, v8, #0x17
    4010:      	add.4s	v9, v9, v5
    4014:      	fmul.4s	v26, v26, v9
    4018:      	shl.4s	v9, v31, #0x17
    401c:      	add.4s	v9, v9, v5
    4020:      	fmul.4s	v25, v25, v9
    4024:      	sub.4s	v27, v27, v8
    4028:      	sub.4s	v28, v28, v31
    402c:      	shl.4s	v28, v28, #0x17
    4030:      	add.4s	v28, v28, v5
    4034:      	fmul.4s	v25, v25, v28
    4038:      	shl.4s	v27, v27, #0x17
    403c:      	add.4s	v27, v27, v5
    4040:      	fmul.4s	v26, v26, v27
    4044:      	fcmgt.4s	v27, v15, v3
    4048:      	bic.16b	v26, v26, v27
    404c:      	fcmgt.4s	v27, v15, v24
    4050:      	bic.16b	v25, v25, v27
    4054:      	fcmgt.4s	v27, v24, v20
    4058:      	ldr	q16, [sp, #0x410]
    405c:      	bit.16b	v25, v16, v27
    4060:      	fcmgt.4s	v27, v3, v20
    4064:      	bit.16b	v26, v16, v27
    4068:      	fcmeq.4s	v3, v3, v3
    406c:      	ldr	q16, [sp, #0x400]
    4070:      	bsl.16b	v3, v26, v16
    4074:      	cmeq.8b	v22, v22, #0
    4078:      	sshll.8h	v22, v22, #0x0
    407c:      	fcmeq.4s	v24, v24, v24
    4080:      	bsl.16b	v24, v25, v16
    4084:      	sshll2.4s	v25, v22, #0x0
    4088:      	sshll.4s	v22, v22, #0x0
    408c:      	bic.16b	v24, v24, v22
    4090:      	bic.16b	v22, v3, v25
    4094:      	ldp	q3, q25, [x9, #0x40]
    4098:      	bit.16b	v25, v22, v0
    409c:      	bit.16b	v3, v24, v1
    40a0:      	stp	q3, q25, [x9, #0x40]
    40a4:      	adrp	x10, 0x4000 <_llm_rows.packet_batch.blocks+0x2494>
    40a8:      	ldr	q3, [x10]
    40ac:      	and.16b	v3, v4, v3
    40b0:      	fmov	w10, s14
    40b4:      	ldr	q16, [sp, #0x420]
    40b8:      	add.2d	v3, v16, v3
    40bc:      	tbz	w10, #0x0, 0x413c <_llm_rows.packet_batch.blocks+0x25d0>
    40c0:      	fmov	x11, d3
    40c4:      	ldr	b25, [x11]
    40c8:      	and	w14, w10, #0xff
    40cc:      	tbnz	w14, #0x1, 0x4148 <_llm_rows.packet_batch.blocks+0x25dc>
    40d0:      	b	0x4150 <_llm_rows.packet_batch.blocks+0x25e4>
    40d4:      	fmov	x10, d3
    40d8:      	ld1.b	{ v22 }[2], [x10]
    40dc:      	tbz	w14, #0x3, 0x3ea0 <_llm_rows.packet_batch.blocks+0x2334>
    40e0:      	mov.d	x10, v3[1]
    40e4:      	ld1.b	{ v22 }[3], [x10]
    40e8:      	adrp	x10, 0x4000 <_llm_rows.packet_batch.blocks+0x2494>
    40ec:      	ldr	q3, [x10]
    40f0:      	and.16b	v3, v21, v3
    40f4:      	ldr	q16, [sp, #0x430]
    40f8:      	add.2d	v3, v16, v3
    40fc:      	tbz	w14, #0x4, 0x3eb8 <_llm_rows.packet_batch.blocks+0x234c>
    4100:      	fmov	x10, d3
    4104:      	ld1.b	{ v22 }[4], [x10]
    4108:      	tbz	w14, #0x5, 0x3ebc <_llm_rows.packet_batch.blocks+0x2350>
    410c:      	mov.d	x10, v3[1]
    4110:      	ld1.b	{ v22 }[5], [x10]
    4114:      	adrp	x10, 0x4000 <_llm_rows.packet_batch.blocks+0x2494>
    4118:      	ldr	q3, [x10]
    411c:      	and.16b	v3, v10, v3
    4120:      	ldr	q16, [sp, #0x450]
    4124:      	add.2d	v3, v16, v3
    4128:      	tbz	w14, #0x6, 0x3ed4 <_llm_rows.packet_batch.blocks+0x2368>
    412c:      	fmov	x10, d3
    4130:      	ld1.b	{ v22 }[6], [x10]
    4134:      	tbnz	w14, #0x7, 0x3ed8 <_llm_rows.packet_batch.blocks+0x236c>
    4138:      	b	0x3ee0 <_llm_rows.packet_batch.blocks+0x2374>
    413c:      	movi.2d	v25, #0000000000000000
    4140:      	and	w14, w10, #0xff
    4144:      	tbz	w14, #0x1, 0x4150 <_llm_rows.packet_batch.blocks+0x25e4>
    4148:      	mov.d	x10, v3[1]
    414c:      	ld1.b	{ v25 }[1], [x10]
    4150:      	adrp	x10, 0x4000 <_llm_rows.packet_batch.blocks+0x2494>
    4154:      	ldr	q3, [x10]
    4158:      	ldr	q16, [sp, #0x310]
    415c:      	and.16b	v3, v16, v3
    4160:      	ldr	q16, [sp, #0x440]
    4164:      	add.2d	v3, v16, v3
    4168:      	tbnz	w14, #0x2, 0x4f64 <_llm_rows.packet_batch.blocks+0x33f8>
    416c:      	tbnz	w14, #0x3, 0x4f70 <_llm_rows.packet_batch.blocks+0x3404>
    4170:      	adrp	x10, 0x4000 <_llm_rows.packet_batch.blocks+0x2494>
    4174:      	ldr	q3, [x10]
    4178:      	and.16b	v3, v21, v3
    417c:      	ldr	q16, [sp, #0x430]
    4180:      	add.2d	v3, v16, v3
    4184:      	tbnz	w14, #0x4, 0x4f90 <_llm_rows.packet_batch.blocks+0x3424>
    4188:      	tbnz	w14, #0x5, 0x4f9c <_llm_rows.packet_batch.blocks+0x3430>
    418c:      	adrp	x10, 0x4000 <_llm_rows.packet_batch.blocks+0x2494>
    4190:      	ldr	q3, [x10]
    4194:      	and.16b	v3, v10, v3
    4198:      	ldr	q16, [sp, #0x450]
    419c:      	add.2d	v21, v16, v3
    41a0:      	tbnz	w14, #0x6, 0x4fbc <_llm_rows.packet_batch.blocks+0x3450>
    41a4:      	ldr	q3, [sp, #0x20]
    41a8:      	and.16b	v3, v4, v3
    41ac:      	tbz	w14, #0x7, 0x41b8 <_llm_rows.packet_batch.blocks+0x264c>
    41b0:      	mov.d	x10, v21[1]
    41b4:      	ld1.b	{ v25 }[7], [x10]
    41b8:      	fmov	x10, d3
    41bc:      	add	x10, x12, x10
    41c0:      	ldp	q4, q3, [x10]
    41c4:      	ldr	q16, [sp, #0x370]
    41c8:      	fsub.4s	v4, v4, v16
    41cc:      	fsub.4s	v3, v3, v16
    41d0:      	and.16b	v3, v0, v3
    41d4:      	and.16b	v4, v1, v4
    41d8:      	fcmge.4s	v21, v4, v15
    41dc:      	fcmge.4s	v26, v3, v15
    41e0:      	fcmge.4s	v27, v20, v4
    41e4:      	fcmge.4s	v28, v20, v3
    41e8:      	and.16b	v26, v26, v28
    41ec:      	and.16b	v21, v21, v27
    41f0:      	and.16b	v21, v21, v4
    41f4:      	and.16b	v26, v26, v3
    41f8:      	ldr	q16, [sp, #0x3f0]
    41fc:      	fmul.4s	v27, v26, v16
    4200:      	fmul.4s	v28, v21, v16
    4204:      	mov.16b	v31, v7
    4208:      	bsl.16b	v31, v6, v28
    420c:      	mov.16b	v8, v7
    4210:      	bsl.16b	v8, v6, v27
    4214:      	fadd.4s	v27, v27, v8
    4218:      	fadd.4s	v28, v28, v31
    421c:      	fsub.4s	v28, v28, v31
    4220:      	fsub.4s	v27, v27, v8
    4224:      	fcvtzs.4s	v27, v27
    4228:      	fcvtzs.4s	v28, v28
    422c:      	scvtf.4s	v31, v28
    4230:      	scvtf.4s	v8, v27
    4234:      	ldp	q6, q7, [sp, #0x3d0]
    4238:      	fmul.4s	v9, v31, v7
    423c:      	fadd.4s	v21, v21, v9
    4240:      	fmul.4s	v9, v8, v7
    4244:      	fadd.4s	v26, v26, v9
    4248:      	fmul.4s	v31, v31, v6
    424c:      	fmul.4s	v8, v8, v6
    4250:      	fadd.4s	v26, v26, v8
    4254:      	fadd.4s	v21, v21, v31
    4258:      	ldp	q6, q7, [sp, #0x3b0]
    425c:      	fmul.4s	v31, v21, v7
    4260:      	fmul.4s	v8, v26, v7
    4264:      	fadd.4s	v8, v8, v6
    4268:      	fadd.4s	v31, v31, v6
    426c:      	fmul.4s	v31, v21, v31
    4270:      	fmul.4s	v8, v26, v8
    4274:      	ldp	q6, q7, [sp, #0x390]
    4278:      	fadd.4s	v8, v8, v7
    427c:      	fadd.4s	v31, v31, v7
    4280:      	fmul.4s	v31, v21, v31
    4284:      	fmul.4s	v8, v26, v8
    4288:      	fadd.4s	v8, v8, v6
    428c:      	fadd.4s	v31, v31, v6
    4290:      	fmul.4s	v31, v21, v31
    4294:      	fmul.4s	v8, v26, v8
    4298:      	ldr	q6, [sp, #0x380]
    429c:      	fadd.4s	v8, v8, v6
    42a0:      	fadd.4s	v31, v31, v6
    42a4:      	fmul.4s	v31, v21, v31
    42a8:      	fmul.4s	v8, v26, v8
    42ac:      	movi.4s	v6, #0x3f, lsl #24
    42b0:      	fadd.4s	v8, v8, v6
    42b4:      	fadd.4s	v31, v31, v6
    42b8:      	fmul.4s	v9, v21, v21
    42bc:      	fmul.4s	v31, v9, v31
    42c0:      	fmul.4s	v9, v26, v26
    42c4:      	fmul.4s	v8, v9, v8
    42c8:      	fadd.4s	v26, v26, v8
    42cc:      	fadd.4s	v21, v21, v31
    42d0:      	fadd.4s	v21, v21, v5
    42d4:      	fadd.4s	v26, v26, v5
    42d8:      	sshr.4s	v31, v28, #0x1
    42dc:      	sshr.4s	v8, v27, #0x1
    42e0:      	shl.4s	v9, v8, #0x17
    42e4:      	add.4s	v9, v9, v5
    42e8:      	fmul.4s	v26, v26, v9
    42ec:      	shl.4s	v9, v31, #0x17
    42f0:      	add.4s	v9, v9, v5
    42f4:      	fmul.4s	v21, v21, v9
    42f8:      	sub.4s	v27, v27, v8
    42fc:      	sub.4s	v28, v28, v31
    4300:      	shl.4s	v28, v28, #0x17
    4304:      	add.4s	v28, v28, v5
    4308:      	fmul.4s	v21, v21, v28
    430c:      	shl.4s	v27, v27, #0x17
    4310:      	add.4s	v27, v27, v5
    4314:      	fmul.4s	v26, v26, v27
    4318:      	fcmgt.4s	v27, v15, v3
    431c:      	bic.16b	v26, v26, v27
    4320:      	fcmgt.4s	v27, v15, v4
    4324:      	bic.16b	v21, v21, v27
    4328:      	fcmgt.4s	v27, v4, v20
    432c:      	ldr	q6, [sp, #0x410]
    4330:      	bit.16b	v21, v6, v27
    4334:      	fcmgt.4s	v27, v3, v20
    4338:      	bit.16b	v26, v6, v27
    433c:      	fcmeq.4s	v3, v3, v3
    4340:      	ldr	q6, [sp, #0x400]
    4344:      	bsl.16b	v3, v26, v6
    4348:      	cmeq.8b	v25, v25, #0
    434c:      	sshll.8h	v25, v25, #0x0
    4350:      	fcmeq.4s	v4, v4, v4
    4354:      	bsl.16b	v4, v21, v6
    4358:      	sshll2.4s	v21, v25, #0x0
    435c:      	sshll.4s	v25, v25, #0x0
    4360:      	bic.16b	v4, v4, v25
    4364:      	bic.16b	v3, v3, v21
    4368:      	ldp	q21, q25, [x9, #0x60]
    436c:      	bit.16b	v25, v3, v0
    4370:      	bit.16b	v21, v4, v1
    4374:      	stp	q21, q25, [x9, #0x60]
    4378:      	and.16b	v3, v0, v3
    437c:      	str	q3, [sp, #0x2f0]
    4380:      	and.16b	v4, v1, v4
    4384:      	and.16b	v22, v0, v22
    4388:      	and.16b	v21, v1, v24
    438c:      	and.16b	v23, v0, v23
    4390:      	and.16b	v28, v1, v2
    4394:      	and.16b	v30, v0, v30
    4398:      	and.16b	v29, v1, v29
    439c:      	b	0x45dc <_llm_rows.packet_batch.blocks+0x2a70>
    43a0:      	add	x8, x8, #0x60
    43a4:      	add	x10, x12, x8
    43a8:      	ldp	q6, q3, [x10]
    43ac:      	ldr	q2, [sp, #0x370]
    43b0:      	fsub.4s	v6, v6, v2
    43b4:      	fsub.4s	v3, v3, v2
    43b8:      	and.16b	v9, v0, v3
    43bc:      	and.16b	v3, v1, v6
    43c0:      	fcmge.4s	v6, v3, v15
    43c4:      	fcmge.4s	v7, v9, v15
    43c8:      	fcmge.4s	v10, v20, v3
    43cc:      	fcmge.4s	v11, v20, v9
    43d0:      	and.16b	v7, v7, v11
    43d4:      	and.16b	v6, v6, v10
    43d8:      	and.16b	v6, v6, v3
    43dc:      	and.16b	v7, v7, v9
    43e0:      	ldp	q2, q11, [sp, #0x3e0]
    43e4:      	fmul.4s	v10, v7, v11
    43e8:      	fmul.4s	v11, v6, v11
    43ec:      	mov.16b	v14, v17
    43f0:      	bsl.16b	v14, v16, v11
    43f4:      	bif.16b	v16, v10, v17
    43f8:      	fadd.4s	v10, v10, v16
    43fc:      	fadd.4s	v11, v11, v14
    4400:      	fsub.4s	v11, v11, v14
    4404:      	fsub.4s	v16, v10, v16
    4408:      	fcvtzs.4s	v16, v16
    440c:      	fcvtzs.4s	v10, v11
    4410:      	scvtf.4s	v11, v10
    4414:      	scvtf.4s	v14, v16
    4418:      	fmul.4s	v17, v11, v2
    441c:      	fadd.4s	v6, v6, v17
    4420:      	fmul.4s	v17, v14, v2
    4424:      	fadd.4s	v7, v7, v17
    4428:      	ldr	q2, [sp, #0x3d0]
    442c:      	fmul.4s	v17, v11, v2
    4430:      	fmul.4s	v11, v14, v2
    4434:      	fadd.4s	v7, v7, v11
    4438:      	fadd.4s	v6, v6, v17
    443c:      	ldr	q2, [sp, #0x3c0]
    4440:      	fmul.4s	v17, v6, v2
    4444:      	fmul.4s	v11, v7, v2
    4448:      	ldr	q2, [sp, #0x3b0]
    444c:      	fadd.4s	v11, v11, v2
    4450:      	fadd.4s	v17, v17, v2
    4454:      	fmul.4s	v17, v6, v17
    4458:      	fmul.4s	v11, v7, v11
    445c:      	ldr	q2, [sp, #0x3a0]
    4460:      	fadd.4s	v11, v11, v2
    4464:      	fadd.4s	v17, v17, v2
    4468:      	fmul.4s	v17, v6, v17
    446c:      	fmul.4s	v11, v7, v11
    4470:      	ldr	q2, [sp, #0x390]
    4474:      	fadd.4s	v11, v11, v2
    4478:      	fadd.4s	v17, v17, v2
    447c:      	fmul.4s	v17, v6, v17
    4480:      	fmul.4s	v11, v7, v11
    4484:      	ldr	q2, [sp, #0x380]
    4488:      	fadd.4s	v11, v11, v2
    448c:      	fadd.4s	v17, v17, v2
    4490:      	fmul.4s	v17, v6, v17
    4494:      	fmul.4s	v11, v7, v11
    4498:      	movi.4s	v14, #0x3f, lsl #24
    449c:      	fadd.4s	v11, v11, v14
    44a0:      	fadd.4s	v17, v17, v14
    44a4:      	fmul.4s	v14, v6, v6
    44a8:      	fmul.4s	v17, v14, v17
    44ac:      	fmul.4s	v14, v7, v7
    44b0:      	fmul.4s	v11, v14, v11
    44b4:      	fadd.4s	v7, v7, v11
    44b8:      	fadd.4s	v6, v6, v17
    44bc:      	fadd.4s	v6, v6, v5
    44c0:      	fadd.4s	v7, v7, v5
    44c4:      	sshr.4s	v17, v10, #0x1
    44c8:      	sshr.4s	v11, v16, #0x1
    44cc:      	shl.4s	v14, v11, #0x17
    44d0:      	add.4s	v14, v14, v5
    44d4:      	fmul.4s	v7, v7, v14
    44d8:      	shl.4s	v14, v17, #0x17
    44dc:      	add.4s	v14, v14, v5
    44e0:      	fmul.4s	v6, v6, v14
    44e4:      	sub.4s	v16, v16, v11
    44e8:      	sub.4s	v17, v10, v17
    44ec:      	shl.4s	v17, v17, #0x17
    44f0:      	add.4s	v17, v17, v5
    44f4:      	fmul.4s	v6, v6, v17
    44f8:      	shl.4s	v16, v16, #0x17
    44fc:      	add.4s	v16, v16, v5
    4500:      	fmul.4s	v7, v7, v16
    4504:      	fcmgt.4s	v16, v15, v9
    4508:      	bic.16b	v7, v7, v16
    450c:      	fcmgt.4s	v16, v15, v3
    4510:      	bic.16b	v6, v6, v16
    4514:      	fcmgt.4s	v16, v3, v20
    4518:      	ldr	q17, [sp, #0x410]
    451c:      	bit.16b	v6, v17, v16
    4520:      	fcmgt.4s	v16, v9, v20
    4524:      	bit.16b	v7, v17, v16
    4528:      	fcmeq.4s	v16, v9, v9
    452c:      	ldr	q17, [sp, #0x400]
    4530:      	bif.16b	v7, v17, v16
    4534:      	cmeq.8b	v16, v26, #0
    4538:      	sshll.8h	v16, v16, #0x0
    453c:      	fcmeq.4s	v3, v3, v3
    4540:      	bsl.16b	v3, v6, v17
    4544:      	sshll2.4s	v6, v16, #0x0
    4548:      	sshll.4s	v16, v16, #0x0
    454c:      	bic.16b	v3, v3, v16
    4550:      	bic.16b	v6, v7, v6
    4554:      	add	x8, x9, x8
    4558:      	ldp	q7, q16, [x8]
    455c:      	bit.16b	v16, v6, v0
    4560:      	bit.16b	v7, v3, v1
    4564:      	stp	q7, q16, [x8]
    4568:      	dup.2d	v7, x26
    456c:      	ldp	q2, q16, [sp, #0x2f0]
    4570:      	and.16b	v16, v16, v7
    4574:      	add.2d	v11, v18, v16
    4578:      	ldr	q16, [sp, #0x310]
    457c:      	and.16b	v16, v16, v7
    4580:      	add.2d	v18, v19, v16
    4584:      	sshll.2d	v16, v0, #0x0
    4588:      	and.16b	v16, v16, v7
    458c:      	add.2d	v19, v12, v16
    4590:      	sshll.2d	v16, v1, #0x0
    4594:      	and.16b	v7, v16, v7
    4598:      	add.2d	v12, v8, v7
    459c:      	bit.16b	v23, v25, v0
    45a0:      	bit.16b	v28, v24, v1
    45a4:      	bit.16b	v22, v31, v0
    45a8:      	bit.16b	v21, v27, v1
    45ac:      	fadd.4s	v6, v2, v6
    45b0:      	bit.16b	v2, v6, v0
    45b4:      	str	q2, [sp, #0x2f0]
    45b8:      	fadd.4s	v3, v4, v3
    45bc:      	bit.16b	v4, v3, v1
    45c0:      	ldr	q2, [sp, #0x220]
    45c4:      	bit.16b	v30, v2, v0
    45c8:      	bit.16b	v29, v13, v1
    45cc:      	fmov	x8, d12
    45d0:      	cmp	x8, #0x200
    45d4:      	ldr	q14, [sp, #0x360]
    45d8:      	b.ge	0x4f44 <_llm_rows.packet_batch.blocks+0x33d8>
    45dc:      	fmov	w10, s14
    45e0:      	ldr	q2, [sp, #0x320]
    45e4:      	add.2d	v2, v12, v2
    45e8:      	ldr	q3, [sp, #0x420]
    45ec:      	add.2d	v3, v3, v2
    45f0:      	tbz	w10, #0x0, 0x4610 <_llm_rows.packet_batch.blocks+0x2aa4>
    45f4:      	fmov	x11, d3
    45f8:      	ldr	b2, [x11]
    45fc:      	movi.4s	v16, #0x4b, lsl #24
    4600:      	mvni.4s	v17, #0x80, lsl #24
    4604:      	and	w11, w10, #0xff
    4608:      	tbnz	w11, #0x1, 0x4624 <_llm_rows.packet_batch.blocks+0x2ab8>
    460c:      	b	0x462c <_llm_rows.packet_batch.blocks+0x2ac0>
    4610:      	movi.2d	v2, #0000000000000000
    4614:      	movi.4s	v16, #0x4b, lsl #24
    4618:      	mvni.4s	v17, #0x80, lsl #24
    461c:      	and	w11, w10, #0xff
    4620:      	tbz	w11, #0x1, 0x462c <_llm_rows.packet_batch.blocks+0x2ac0>
    4624:      	mov.d	x10, v3[1]
    4628:      	ld1.b	{ v2 }[1], [x10]
    462c:      	ldr	q3, [sp, #0x340]
    4630:      	add.2d	v3, v18, v3
    4634:      	ldr	q6, [sp, #0x440]
    4638:      	add.2d	v3, v6, v3
    463c:      	tbnz	w11, #0x2, 0x4870 <_llm_rows.packet_batch.blocks+0x2d04>
    4640:      	tbnz	w11, #0x3, 0x487c <_llm_rows.packet_batch.blocks+0x2d10>
    4644:      	ldr	q3, [sp, #0x330]
    4648:      	add.2d	v3, v19, v3
    464c:      	ldr	q6, [sp, #0x430]
    4650:      	add.2d	v3, v6, v3
    4654:      	tbnz	w11, #0x4, 0x4898 <_llm_rows.packet_batch.blocks+0x2d2c>
    4658:      	tbnz	w11, #0x5, 0x48a4 <_llm_rows.packet_batch.blocks+0x2d38>
    465c:      	ldr	q3, [sp, #0x350]
    4660:      	add.2d	v3, v11, v3
    4664:      	ldr	q6, [sp, #0x450]
    4668:      	add.2d	v3, v6, v3
    466c:      	tbnz	w11, #0x6, 0x48c0 <_llm_rows.packet_batch.blocks+0x2d54>
    4670:      	tbz	w11, #0x7, 0x467c <_llm_rows.packet_batch.blocks+0x2b10>
    4674:      	mov.d	x10, v3[1]
    4678:      	ld1.b	{ v2 }[7], [x10]
    467c:      	lsl	x8, x8, #5
    4680:      	add	x10, x12, x8
    4684:      	ldp	q24, q3, [x10]
    4688:      	ldr	q6, [sp, #0x370]
    468c:      	fsub.4s	v24, v24, v6
    4690:      	fsub.4s	v3, v3, v6
    4694:      	and.16b	v3, v0, v3
    4698:      	and.16b	v24, v1, v24
    469c:      	fcmge.4s	v25, v24, v15
    46a0:      	fcmge.4s	v26, v3, v15
    46a4:      	fcmge.4s	v27, v20, v24
    46a8:      	fcmge.4s	v31, v20, v3
    46ac:      	and.16b	v26, v26, v31
    46b0:      	and.16b	v25, v25, v27
    46b4:      	and.16b	v25, v25, v24
    46b8:      	and.16b	v26, v26, v3
    46bc:      	ldp	q6, q7, [sp, #0x3e0]
    46c0:      	fmul.4s	v27, v26, v7
    46c4:      	fmul.4s	v31, v25, v7
    46c8:      	mov.16b	v8, v17
    46cc:      	bsl.16b	v8, v16, v31
    46d0:      	mov.16b	v9, v17
    46d4:      	bsl.16b	v9, v16, v27
    46d8:      	fadd.4s	v27, v27, v9
    46dc:      	fadd.4s	v31, v31, v8
    46e0:      	fsub.4s	v31, v31, v8
    46e4:      	fsub.4s	v27, v27, v9
    46e8:      	fcvtzs.4s	v27, v27
    46ec:      	fcvtzs.4s	v31, v31
    46f0:      	scvtf.4s	v8, v31
    46f4:      	scvtf.4s	v9, v27
    46f8:      	fmul.4s	v14, v8, v6
    46fc:      	fadd.4s	v25, v25, v14
    4700:      	fmul.4s	v14, v9, v6
    4704:      	fadd.4s	v26, v26, v14
    4708:      	ldp	q6, q7, [sp, #0x3c0]
    470c:      	fmul.4s	v8, v8, v7
    4710:      	fmul.4s	v9, v9, v7
    4714:      	fadd.4s	v26, v26, v9
    4718:      	fadd.4s	v25, v25, v8
    471c:      	fmul.4s	v8, v25, v6
    4720:      	fmul.4s	v9, v26, v6
    4724:      	ldp	q6, q7, [sp, #0x3a0]
    4728:      	fadd.4s	v9, v9, v7
    472c:      	fadd.4s	v8, v8, v7
    4730:      	fmul.4s	v8, v25, v8
    4734:      	fmul.4s	v9, v26, v9
    4738:      	fadd.4s	v9, v9, v6
    473c:      	fadd.4s	v8, v8, v6
    4740:      	fmul.4s	v8, v25, v8
    4744:      	fmul.4s	v9, v26, v9
    4748:      	ldp	q6, q7, [sp, #0x380]
    474c:      	fadd.4s	v9, v9, v7
    4750:      	fadd.4s	v8, v8, v7
    4754:      	fmul.4s	v8, v25, v8
    4758:      	fmul.4s	v9, v26, v9
    475c:      	fadd.4s	v9, v9, v6
    4760:      	fadd.4s	v8, v8, v6
    4764:      	fmul.4s	v8, v25, v8
    4768:      	fmul.4s	v9, v26, v9
    476c:      	movi.4s	v6, #0x3f, lsl #24
    4770:      	fadd.4s	v9, v9, v6
    4774:      	fadd.4s	v8, v8, v6
    4778:      	fmul.4s	v14, v25, v25
    477c:      	fmul.4s	v8, v14, v8
    4780:      	fmul.4s	v14, v26, v26
    4784:      	fmul.4s	v9, v14, v9
    4788:      	fadd.4s	v26, v26, v9
    478c:      	fadd.4s	v25, v25, v8
    4790:      	fadd.4s	v25, v25, v5
    4794:      	fadd.4s	v26, v26, v5
    4798:      	sshr.4s	v8, v31, #0x1
    479c:      	sshr.4s	v9, v27, #0x1
    47a0:      	shl.4s	v14, v9, #0x17
    47a4:      	add.4s	v14, v14, v5
    47a8:      	fmul.4s	v26, v26, v14
    47ac:      	shl.4s	v14, v8, #0x17
    47b0:      	add.4s	v14, v14, v5
    47b4:      	fmul.4s	v25, v25, v14
    47b8:      	sub.4s	v27, v27, v9
    47bc:      	sub.4s	v31, v31, v8
    47c0:      	shl.4s	v31, v31, #0x17
    47c4:      	add.4s	v31, v31, v5
    47c8:      	fmul.4s	v25, v25, v31
    47cc:      	shl.4s	v27, v27, #0x17
    47d0:      	add.4s	v27, v27, v5
    47d4:      	fmul.4s	v26, v26, v27
    47d8:      	fcmgt.4s	v27, v15, v3
    47dc:      	bic.16b	v26, v26, v27
    47e0:      	fcmgt.4s	v27, v15, v24
    47e4:      	bic.16b	v25, v25, v27
    47e8:      	fcmgt.4s	v27, v24, v20
    47ec:      	ldr	q6, [sp, #0x410]
    47f0:      	bit.16b	v25, v6, v27
    47f4:      	fcmgt.4s	v27, v3, v20
    47f8:      	bit.16b	v26, v6, v27
    47fc:      	fcmeq.4s	v3, v3, v3
    4800:      	ldr	q6, [sp, #0x400]
    4804:      	bsl.16b	v3, v26, v6
    4808:      	cmeq.8b	v2, v2, #0
    480c:      	sshll.8h	v2, v2, #0x0
    4810:      	fcmeq.4s	v24, v24, v24
    4814:      	bsl.16b	v24, v25, v6
    4818:      	sshll2.4s	v25, v2, #0x0
    481c:      	sshll.4s	v2, v2, #0x0
    4820:      	bic.16b	v2, v24, v2
    4824:      	bic.16b	v6, v3, v25
    4828:      	add	x10, x9, x8
    482c:      	ldp	q3, q24, [x10]
    4830:      	stp	q2, q6, [sp, #0x210]
    4834:      	bit.16b	v24, v6, v0
    4838:      	bit.16b	v3, v2, v1
    483c:      	stp	q3, q24, [x10]
    4840:      	ldr	q3, [sp, #0x360]
    4844:      	fmov	w8, s3
    4848:      	ldr	q3, [sp, #0x2e0]
    484c:      	add.2d	v3, v12, v3
    4850:      	ldr	q6, [sp, #0x420]
    4854:      	add.2d	v3, v6, v3
    4858:      	tbz	w8, #0x0, 0x48d0 <_llm_rows.packet_batch.blocks+0x2d64>
    485c:      	fmov	x10, d3
    4860:      	ldr	b24, [x10]
    4864:      	and	w8, w8, #0xff
    4868:      	tbnz	w8, #0x1, 0x48dc <_llm_rows.packet_batch.blocks+0x2d70>
    486c:      	b	0x48e4 <_llm_rows.packet_batch.blocks+0x2d78>
    4870:      	fmov	x10, d3
    4874:      	ld1.b	{ v2 }[2], [x10]
    4878:      	tbz	w11, #0x3, 0x4644 <_llm_rows.packet_batch.blocks+0x2ad8>
    487c:      	mov.d	x10, v3[1]
    4880:      	ld1.b	{ v2 }[3], [x10]
    4884:      	ldr	q3, [sp, #0x330]
    4888:      	add.2d	v3, v19, v3
    488c:      	ldr	q6, [sp, #0x430]
    4890:      	add.2d	v3, v6, v3
    4894:      	tbz	w11, #0x4, 0x4658 <_llm_rows.packet_batch.blocks+0x2aec>
    4898:      	fmov	x10, d3
    489c:      	ld1.b	{ v2 }[4], [x10]
    48a0:      	tbz	w11, #0x5, 0x465c <_llm_rows.packet_batch.blocks+0x2af0>
    48a4:      	mov.d	x10, v3[1]
    48a8:      	ld1.b	{ v2 }[5], [x10]
    48ac:      	ldr	q3, [sp, #0x350]
    48b0:      	add.2d	v3, v11, v3
    48b4:      	ldr	q6, [sp, #0x450]
    48b8:      	add.2d	v3, v6, v3
    48bc:      	tbz	w11, #0x6, 0x4670 <_llm_rows.packet_batch.blocks+0x2b04>
    48c0:      	fmov	x10, d3
    48c4:      	ld1.b	{ v2 }[6], [x10]
    48c8:      	tbnz	w11, #0x7, 0x4674 <_llm_rows.packet_batch.blocks+0x2b08>
    48cc:      	b	0x467c <_llm_rows.packet_batch.blocks+0x2b10>
    48d0:      	movi.2d	v24, #0000000000000000
    48d4:      	and	w8, w8, #0xff
    48d8:      	tbz	w8, #0x1, 0x48e4 <_llm_rows.packet_batch.blocks+0x2d78>
    48dc:      	mov.d	x10, v3[1]
    48e0:      	ld1.b	{ v24 }[1], [x10]
    48e4:      	ldr	q3, [sp, #0x2d0]
    48e8:      	add.2d	v3, v18, v3
    48ec:      	ldr	q6, [sp, #0x440]
    48f0:      	add.2d	v3, v6, v3
    48f4:      	tbnz	w8, #0x2, 0x4b38 <_llm_rows.packet_batch.blocks+0x2fcc>
    48f8:      	tbnz	w8, #0x3, 0x4b44 <_llm_rows.packet_batch.blocks+0x2fd8>
    48fc:      	ldr	q3, [sp, #0x2c0]
    4900:      	add.2d	v3, v19, v3
    4904:      	ldr	q6, [sp, #0x430]
    4908:      	add.2d	v3, v6, v3
    490c:      	tbnz	w8, #0x4, 0x4b60 <_llm_rows.packet_batch.blocks+0x2ff4>
    4910:      	tbnz	w8, #0x5, 0x4b6c <_llm_rows.packet_batch.blocks+0x3000>
    4914:      	ldr	q3, [sp, #0x2b0]
    4918:      	add.2d	v3, v11, v3
    491c:      	ldr	q6, [sp, #0x450]
    4920:      	add.2d	v3, v6, v3
    4924:      	tbnz	w8, #0x6, 0x4b88 <_llm_rows.packet_batch.blocks+0x301c>
    4928:      	tbz	w8, #0x7, 0x4934 <_llm_rows.packet_batch.blocks+0x2dc8>
    492c:      	mov.d	x8, v3[1]
    4930:      	ld1.b	{ v24 }[7], [x8]
    4934:      	fmov	x8, d12
    4938:      	lsl	x8, x8, #5
    493c:      	add	x14, x8, #0x20
    4940:      	add	x10, x12, x14
    4944:      	ldp	q25, q3, [x10]
    4948:      	ldr	q2, [sp, #0x370]
    494c:      	fsub.4s	v25, v25, v2
    4950:      	fsub.4s	v3, v3, v2
    4954:      	and.16b	v3, v0, v3
    4958:      	and.16b	v25, v1, v25
    495c:      	fcmge.4s	v26, v25, v15
    4960:      	fcmge.4s	v27, v3, v15
    4964:      	fcmge.4s	v31, v20, v25
    4968:      	fcmge.4s	v9, v20, v3
    496c:      	and.16b	v27, v27, v9
    4970:      	and.16b	v26, v26, v31
    4974:      	and.16b	v26, v26, v25
    4978:      	and.16b	v27, v27, v3
    497c:      	ldp	q8, q6, [sp, #0x3e0]
    4980:      	fmul.4s	v31, v27, v6
    4984:      	fmul.4s	v9, v26, v6
    4988:      	mov.16b	v14, v17
    498c:      	bsl.16b	v14, v16, v9
    4990:      	mov.16b	v6, v17
    4994:      	bsl.16b	v6, v16, v31
    4998:      	fadd.4s	v31, v31, v6
    499c:      	fadd.4s	v9, v9, v14
    49a0:      	fsub.4s	v9, v9, v14
    49a4:      	fsub.4s	v6, v31, v6
    49a8:      	fcvtzs.4s	v6, v6
    49ac:      	fcvtzs.4s	v31, v9
    49b0:      	scvtf.4s	v9, v31
    49b4:      	scvtf.4s	v14, v6
    49b8:      	fmul.4s	v7, v9, v8
    49bc:      	fadd.4s	v7, v26, v7
    49c0:      	fmul.4s	v26, v14, v8
    49c4:      	fadd.4s	v26, v27, v26
    49c8:      	ldr	q2, [sp, #0x3d0]
    49cc:      	fmul.4s	v27, v9, v2
    49d0:      	fmul.4s	v9, v14, v2
    49d4:      	fadd.4s	v26, v26, v9
    49d8:      	fadd.4s	v7, v7, v27
    49dc:      	ldr	q2, [sp, #0x3c0]
    49e0:      	fmul.4s	v27, v7, v2
    49e4:      	fmul.4s	v9, v26, v2
    49e8:      	ldr	q2, [sp, #0x3b0]
    49ec:      	fadd.4s	v9, v9, v2
    49f0:      	fadd.4s	v27, v27, v2
    49f4:      	fmul.4s	v27, v7, v27
    49f8:      	fmul.4s	v9, v26, v9
    49fc:      	ldr	q2, [sp, #0x3a0]
    4a00:      	fadd.4s	v9, v9, v2
    4a04:      	fadd.4s	v27, v27, v2
    4a08:      	fmul.4s	v27, v7, v27
    4a0c:      	fmul.4s	v9, v26, v9
    4a10:      	ldr	q2, [sp, #0x390]
    4a14:      	fadd.4s	v9, v9, v2
    4a18:      	fadd.4s	v27, v27, v2
    4a1c:      	fmul.4s	v27, v7, v27
    4a20:      	fmul.4s	v9, v26, v9
    4a24:      	ldr	q2, [sp, #0x380]
    4a28:      	fadd.4s	v9, v9, v2
    4a2c:      	fadd.4s	v27, v27, v2
    4a30:      	fmul.4s	v27, v7, v27
    4a34:      	fmul.4s	v9, v26, v9
    4a38:      	movi.4s	v10, #0x3f, lsl #24
    4a3c:      	fadd.4s	v9, v9, v10
    4a40:      	fadd.4s	v27, v27, v10
    4a44:      	fmul.4s	v14, v7, v7
    4a48:      	fmul.4s	v27, v14, v27
    4a4c:      	fmul.4s	v14, v26, v26
    4a50:      	fmul.4s	v9, v14, v9
    4a54:      	fadd.4s	v26, v26, v9
    4a58:      	fadd.4s	v7, v7, v27
    4a5c:      	fadd.4s	v7, v7, v5
    4a60:      	fadd.4s	v26, v26, v5
    4a64:      	sshr.4s	v27, v31, #0x1
    4a68:      	sshr.4s	v9, v6, #0x1
    4a6c:      	shl.4s	v14, v9, #0x17
    4a70:      	add.4s	v14, v14, v5
    4a74:      	fmul.4s	v26, v26, v14
    4a78:      	shl.4s	v14, v27, #0x17
    4a7c:      	add.4s	v14, v14, v5
    4a80:      	fmul.4s	v7, v7, v14
    4a84:      	sub.4s	v6, v6, v9
    4a88:      	sub.4s	v27, v31, v27
    4a8c:      	shl.4s	v27, v27, #0x17
    4a90:      	add.4s	v27, v27, v5
    4a94:      	fmul.4s	v7, v7, v27
    4a98:      	shl.4s	v6, v6, #0x17
    4a9c:      	add.4s	v6, v6, v5
    4aa0:      	fmul.4s	v6, v26, v6
    4aa4:      	fcmgt.4s	v26, v15, v3
    4aa8:      	bic.16b	v6, v6, v26
    4aac:      	fcmgt.4s	v26, v15, v25
    4ab0:      	bic.16b	v7, v7, v26
    4ab4:      	fcmgt.4s	v26, v25, v20
    4ab8:      	ldr	q27, [sp, #0x410]
    4abc:      	bit.16b	v7, v27, v26
    4ac0:      	fcmgt.4s	v26, v3, v20
    4ac4:      	bit.16b	v6, v27, v26
    4ac8:      	fcmeq.4s	v3, v3, v3
    4acc:      	ldr	q26, [sp, #0x400]
    4ad0:      	bsl.16b	v3, v6, v26
    4ad4:      	cmeq.8b	v6, v24, #0
    4ad8:      	sshll.8h	v6, v6, #0x0
    4adc:      	fcmeq.4s	v24, v25, v25
    4ae0:      	bif.16b	v7, v26, v24
    4ae4:      	sshll2.4s	v25, v6, #0x0
    4ae8:      	sshll.4s	v6, v6, #0x0
    4aec:      	bic.16b	v24, v7, v6
    4af0:      	bic.16b	v25, v3, v25
    4af4:      	add	x11, x9, x14
    4af8:      	ldp	q3, q6, [x11]
    4afc:      	bit.16b	v6, v25, v0
    4b00:      	bit.16b	v3, v24, v1
    4b04:      	stp	q3, q6, [x11]
    4b08:      	ldr	q3, [sp, #0x360]
    4b0c:      	fmov	w10, s3
    4b10:      	ldr	q3, [sp, #0x2a0]
    4b14:      	add.2d	v3, v12, v3
    4b18:      	ldr	q6, [sp, #0x420]
    4b1c:      	add.2d	v3, v6, v3
    4b20:      	tbz	w10, #0x0, 0x4b98 <_llm_rows.packet_batch.blocks+0x302c>
    4b24:      	fmov	x11, d3
    4b28:      	ldr	b26, [x11]
    4b2c:      	and	w11, w10, #0xff
    4b30:      	tbnz	w11, #0x1, 0x4ba4 <_llm_rows.packet_batch.blocks+0x3038>
    4b34:      	b	0x4bac <_llm_rows.packet_batch.blocks+0x3040>
    4b38:      	fmov	x10, d3
    4b3c:      	ld1.b	{ v24 }[2], [x10]
    4b40:      	tbz	w8, #0x3, 0x48fc <_llm_rows.packet_batch.blocks+0x2d90>
    4b44:      	mov.d	x10, v3[1]
    4b48:      	ld1.b	{ v24 }[3], [x10]
    4b4c:      	ldr	q3, [sp, #0x2c0]
    4b50:      	add.2d	v3, v19, v3
    4b54:      	ldr	q6, [sp, #0x430]
    4b58:      	add.2d	v3, v6, v3
    4b5c:      	tbz	w8, #0x4, 0x4910 <_llm_rows.packet_batch.blocks+0x2da4>
    4b60:      	fmov	x10, d3
    4b64:      	ld1.b	{ v24 }[4], [x10]
    4b68:      	tbz	w8, #0x5, 0x4914 <_llm_rows.packet_batch.blocks+0x2da8>
    4b6c:      	mov.d	x10, v3[1]
    4b70:      	ld1.b	{ v24 }[5], [x10]
    4b74:      	ldr	q3, [sp, #0x2b0]
    4b78:      	add.2d	v3, v11, v3
    4b7c:      	ldr	q6, [sp, #0x450]
    4b80:      	add.2d	v3, v6, v3
    4b84:      	tbz	w8, #0x6, 0x4928 <_llm_rows.packet_batch.blocks+0x2dbc>
    4b88:      	fmov	x10, d3
    4b8c:      	ld1.b	{ v24 }[6], [x10]
    4b90:      	tbnz	w8, #0x7, 0x492c <_llm_rows.packet_batch.blocks+0x2dc0>
    4b94:      	b	0x4934 <_llm_rows.packet_batch.blocks+0x2dc8>
    4b98:      	movi.2d	v26, #0000000000000000
    4b9c:      	and	w11, w10, #0xff
    4ba0:      	tbz	w11, #0x1, 0x4bac <_llm_rows.packet_batch.blocks+0x3040>
    4ba4:      	mov.d	x10, v3[1]
    4ba8:      	ld1.b	{ v26 }[1], [x10]
    4bac:      	ldr	q3, [sp, #0x290]
    4bb0:      	add.2d	v3, v18, v3
    4bb4:      	ldr	q6, [sp, #0x440]
    4bb8:      	add.2d	v3, v6, v3
    4bbc:      	tbnz	w11, #0x2, 0x4e1c <_llm_rows.packet_batch.blocks+0x32b0>
    4bc0:      	tbnz	w11, #0x3, 0x4e28 <_llm_rows.packet_batch.blocks+0x32bc>
    4bc4:      	ldr	q3, [sp, #0x280]
    4bc8:      	add.2d	v3, v19, v3
    4bcc:      	ldr	q6, [sp, #0x430]
    4bd0:      	add.2d	v3, v6, v3
    4bd4:      	tbnz	w11, #0x4, 0x4e44 <_llm_rows.packet_batch.blocks+0x32d8>
    4bd8:      	mov.16b	v8, v12
    4bdc:      	tbz	w11, #0x5, 0x4be8 <_llm_rows.packet_batch.blocks+0x307c>
    4be0:      	mov.d	x10, v3[1]
    4be4:      	ld1.b	{ v26 }[5], [x10]
    4be8:      	mov.16b	v12, v19
    4bec:      	ldr	q3, [sp, #0x270]
    4bf0:      	add.2d	v3, v11, v3
    4bf4:      	ldr	q6, [sp, #0x450]
    4bf8:      	add.2d	v3, v6, v3
    4bfc:      	mov.16b	v19, v18
    4c00:      	tbz	w11, #0x6, 0x4c0c <_llm_rows.packet_batch.blocks+0x30a0>
    4c04:      	fmov	x10, d3
    4c08:      	ld1.b	{ v26 }[6], [x10]
    4c0c:      	mov.16b	v18, v11
    4c10:      	tbz	w11, #0x7, 0x4c1c <_llm_rows.packet_batch.blocks+0x30b0>
    4c14:      	mov.d	x10, v3[1]
    4c18:      	ld1.b	{ v26 }[7], [x10]
    4c1c:      	add	x14, x8, #0x40
    4c20:      	add	x10, x12, x14
    4c24:      	ldp	q6, q3, [x10]
    4c28:      	ldr	q2, [sp, #0x370]
    4c2c:      	fsub.4s	v6, v6, v2
    4c30:      	fsub.4s	v3, v3, v2
    4c34:      	and.16b	v3, v0, v3
    4c38:      	and.16b	v27, v1, v6
    4c3c:      	fcmge.4s	v6, v27, v15
    4c40:      	fcmge.4s	v7, v3, v15
    4c44:      	fcmge.4s	v31, v20, v27
    4c48:      	fcmge.4s	v9, v20, v3
    4c4c:      	and.16b	v7, v7, v9
    4c50:      	and.16b	v6, v6, v31
    4c54:      	and.16b	v6, v6, v27
    4c58:      	and.16b	v7, v7, v3
    4c5c:      	ldp	q2, q9, [sp, #0x3e0]
    4c60:      	fmul.4s	v31, v7, v9
    4c64:      	fmul.4s	v9, v6, v9
    4c68:      	mov.16b	v14, v17
    4c6c:      	bsl.16b	v14, v16, v9
    4c70:      	mov.16b	v10, v17
    4c74:      	bsl.16b	v10, v16, v31
    4c78:      	fadd.4s	v31, v31, v10
    4c7c:      	fadd.4s	v9, v9, v14
    4c80:      	fsub.4s	v9, v9, v14
    4c84:      	fsub.4s	v31, v31, v10
    4c88:      	fcvtzs.4s	v31, v31
    4c8c:      	fcvtzs.4s	v9, v9
    4c90:      	scvtf.4s	v10, v9
    4c94:      	scvtf.4s	v14, v31
    4c98:      	fmul.4s	v11, v10, v2
    4c9c:      	fadd.4s	v6, v6, v11
    4ca0:      	fmul.4s	v11, v14, v2
    4ca4:      	fadd.4s	v7, v7, v11
    4ca8:      	ldr	q2, [sp, #0x3d0]
    4cac:      	fmul.4s	v10, v10, v2
    4cb0:      	fmul.4s	v11, v14, v2
    4cb4:      	fadd.4s	v7, v7, v11
    4cb8:      	fadd.4s	v6, v6, v10
    4cbc:      	ldr	q2, [sp, #0x3c0]
    4cc0:      	fmul.4s	v10, v6, v2
    4cc4:      	fmul.4s	v11, v7, v2
    4cc8:      	ldr	q2, [sp, #0x3b0]
    4ccc:      	fadd.4s	v11, v11, v2
    4cd0:      	fadd.4s	v10, v10, v2
    4cd4:      	fmul.4s	v10, v6, v10
    4cd8:      	fmul.4s	v11, v7, v11
    4cdc:      	ldr	q2, [sp, #0x3a0]
    4ce0:      	fadd.4s	v11, v11, v2
    4ce4:      	fadd.4s	v10, v10, v2
    4ce8:      	fmul.4s	v10, v6, v10
    4cec:      	fmul.4s	v11, v7, v11
    4cf0:      	ldr	q2, [sp, #0x390]
    4cf4:      	fadd.4s	v11, v11, v2
    4cf8:      	fadd.4s	v10, v10, v2
    4cfc:      	fmul.4s	v10, v6, v10
    4d00:      	fmul.4s	v11, v7, v11
    4d04:      	ldr	q2, [sp, #0x380]
    4d08:      	fadd.4s	v11, v11, v2
    4d0c:      	fadd.4s	v10, v10, v2
    4d10:      	fmul.4s	v10, v6, v10
    4d14:      	fmul.4s	v11, v7, v11
    4d18:      	movi.4s	v14, #0x3f, lsl #24
    4d1c:      	fadd.4s	v11, v11, v14
    4d20:      	fadd.4s	v10, v10, v14
    4d24:      	fmul.4s	v14, v6, v6
    4d28:      	fmul.4s	v10, v14, v10
    4d2c:      	fmul.4s	v14, v7, v7
    4d30:      	fmul.4s	v11, v14, v11
    4d34:      	fadd.4s	v7, v7, v11
    4d38:      	fadd.4s	v6, v6, v10
    4d3c:      	fadd.4s	v6, v6, v5
    4d40:      	fadd.4s	v7, v7, v5
    4d44:      	sshr.4s	v10, v9, #0x1
    4d48:      	sshr.4s	v11, v31, #0x1
    4d4c:      	shl.4s	v14, v11, #0x17
    4d50:      	add.4s	v14, v14, v5
    4d54:      	fmul.4s	v7, v7, v14
    4d58:      	shl.4s	v14, v10, #0x17
    4d5c:      	add.4s	v14, v14, v5
    4d60:      	fmul.4s	v6, v6, v14
    4d64:      	sub.4s	v31, v31, v11
    4d68:      	sub.4s	v9, v9, v10
    4d6c:      	shl.4s	v9, v9, #0x17
    4d70:      	add.4s	v9, v9, v5
    4d74:      	fmul.4s	v6, v6, v9
    4d78:      	shl.4s	v31, v31, #0x17
    4d7c:      	add.4s	v31, v31, v5
    4d80:      	fmul.4s	v7, v7, v31
    4d84:      	fcmgt.4s	v31, v15, v3
    4d88:      	bic.16b	v7, v7, v31
    4d8c:      	fcmgt.4s	v31, v15, v27
    4d90:      	bic.16b	v6, v6, v31
    4d94:      	fcmgt.4s	v31, v27, v20
    4d98:      	ldr	q9, [sp, #0x410]
    4d9c:      	bit.16b	v6, v9, v31
    4da0:      	fcmgt.4s	v31, v3, v20
    4da4:      	bit.16b	v7, v9, v31
    4da8:      	fcmeq.4s	v3, v3, v3
    4dac:      	ldr	q31, [sp, #0x400]
    4db0:      	bsl.16b	v3, v7, v31
    4db4:      	cmeq.8b	v7, v26, #0
    4db8:      	sshll.8h	v7, v7, #0x0
    4dbc:      	fcmeq.4s	v26, v27, v27
    4dc0:      	bif.16b	v6, v31, v26
    4dc4:      	sshll2.4s	v26, v7, #0x0
    4dc8:      	sshll.4s	v7, v7, #0x0
    4dcc:      	bic.16b	v27, v6, v7
    4dd0:      	bic.16b	v31, v3, v26
    4dd4:      	add	x11, x9, x14
    4dd8:      	ldp	q3, q6, [x11]
    4ddc:      	bit.16b	v6, v31, v0
    4de0:      	bit.16b	v3, v27, v1
    4de4:      	stp	q3, q6, [x11]
    4de8:      	ldr	q3, [sp, #0x360]
    4dec:      	fmov	w10, s3
    4df0:      	ldr	q3, [sp, #0x260]
    4df4:      	add.2d	v3, v8, v3
    4df8:      	ldr	q6, [sp, #0x420]
    4dfc:      	add.2d	v3, v6, v3
    4e00:      	tbz	w10, #0x0, 0x4e58 <_llm_rows.packet_batch.blocks+0x32ec>
    4e04:      	fmov	x11, d3
    4e08:      	ldr	b26, [x11]
    4e0c:      	and	w14, w10, #0xff
    4e10:      	mov.16b	v7, v18
    4e14:      	tbnz	w14, #0x1, 0x4e68 <_llm_rows.packet_batch.blocks+0x32fc>
    4e18:      	b	0x4e70 <_llm_rows.packet_batch.blocks+0x3304>
    4e1c:      	fmov	x10, d3
    4e20:      	ld1.b	{ v26 }[2], [x10]
    4e24:      	tbz	w11, #0x3, 0x4bc4 <_llm_rows.packet_batch.blocks+0x3058>
    4e28:      	mov.d	x10, v3[1]
    4e2c:      	ld1.b	{ v26 }[3], [x10]
    4e30:      	ldr	q3, [sp, #0x280]
    4e34:      	add.2d	v3, v19, v3
    4e38:      	ldr	q6, [sp, #0x430]
    4e3c:      	add.2d	v3, v6, v3
    4e40:      	tbz	w11, #0x4, 0x4bd8 <_llm_rows.packet_batch.blocks+0x306c>
    4e44:      	fmov	x10, d3
    4e48:      	ld1.b	{ v26 }[4], [x10]
    4e4c:      	mov.16b	v8, v12
    4e50:      	tbnz	w11, #0x5, 0x4be0 <_llm_rows.packet_batch.blocks+0x3074>
    4e54:      	b	0x4be8 <_llm_rows.packet_batch.blocks+0x307c>
    4e58:      	movi.2d	v26, #0000000000000000
    4e5c:      	and	w14, w10, #0xff
    4e60:      	mov.16b	v7, v18
    4e64:      	tbz	w14, #0x1, 0x4e70 <_llm_rows.packet_batch.blocks+0x3304>
    4e68:      	mov.d	x10, v3[1]
    4e6c:      	ld1.b	{ v26 }[1], [x10]
    4e70:      	ldr	q3, [sp, #0x250]
    4e74:      	add.2d	v3, v19, v3
    4e78:      	ldr	q6, [sp, #0x440]
    4e7c:      	add.2d	v3, v6, v3
    4e80:      	tbnz	w14, #0x2, 0x4ef0 <_llm_rows.packet_batch.blocks+0x3384>
    4e84:      	tbnz	w14, #0x3, 0x4efc <_llm_rows.packet_batch.blocks+0x3390>
    4e88:      	ldr	q3, [sp, #0x240]
    4e8c:      	add.2d	v3, v12, v3
    4e90:      	ldr	q6, [sp, #0x430]
    4e94:      	add.2d	v3, v6, v3
    4e98:      	tbnz	w14, #0x4, 0x4f18 <_llm_rows.packet_batch.blocks+0x33ac>
    4e9c:      	tbnz	w14, #0x5, 0x4f24 <_llm_rows.packet_batch.blocks+0x33b8>
    4ea0:      	ldr	q3, [sp, #0x230]
    4ea4:      	add.2d	v3, v7, v3
    4ea8:      	ldr	q6, [sp, #0x450]
    4eac:      	add.2d	v3, v6, v3
    4eb0:      	tbz	w14, #0x6, 0x4ebc <_llm_rows.packet_batch.blocks+0x3350>
    4eb4:      	fmov	x10, d3
    4eb8:      	ld1.b	{ v26 }[6], [x10]
    4ebc:      	ldr	q2, [sp, #0x220]
    4ec0:      	fadd.4s	v2, v30, v2
    4ec4:      	str	q2, [sp, #0x220]
    4ec8:      	ldr	q2, [sp, #0x210]
    4ecc:      	fadd.4s	v13, v29, v2
    4ed0:      	fadd.4s	v25, v23, v25
    4ed4:      	fadd.4s	v24, v28, v24
    4ed8:      	fadd.4s	v31, v22, v31
    4edc:      	fadd.4s	v27, v21, v27
    4ee0:      	tbz	w14, #0x7, 0x43a0 <_llm_rows.packet_batch.blocks+0x2834>
    4ee4:      	mov.d	x10, v3[1]
    4ee8:      	ld1.b	{ v26 }[7], [x10]
    4eec:      	b	0x43a0 <_llm_rows.packet_batch.blocks+0x2834>
    4ef0:      	fmov	x10, d3
    4ef4:      	ld1.b	{ v26 }[2], [x10]
    4ef8:      	tbz	w14, #0x3, 0x4e88 <_llm_rows.packet_batch.blocks+0x331c>
    4efc:      	mov.d	x10, v3[1]
    4f00:      	ld1.b	{ v26 }[3], [x10]
    4f04:      	ldr	q3, [sp, #0x240]
    4f08:      	add.2d	v3, v12, v3
    4f0c:      	ldr	q6, [sp, #0x430]
    4f10:      	add.2d	v3, v6, v3
    4f14:      	tbz	w14, #0x4, 0x4e9c <_llm_rows.packet_batch.blocks+0x3330>
    4f18:      	fmov	x10, d3
    4f1c:      	ld1.b	{ v26 }[4], [x10]
    4f20:      	tbz	w14, #0x5, 0x4ea0 <_llm_rows.packet_batch.blocks+0x3334>
    4f24:      	mov.d	x10, v3[1]
    4f28:      	ld1.b	{ v26 }[5], [x10]
    4f2c:      	ldr	q3, [sp, #0x230]
    4f30:      	add.2d	v3, v7, v3
    4f34:      	ldr	q6, [sp, #0x450]
    4f38:      	add.2d	v3, v6, v3
    4f3c:      	tbnz	w14, #0x6, 0x4eb4 <_llm_rows.packet_batch.blocks+0x3348>
    4f40:      	b	0x4ebc <_llm_rows.packet_batch.blocks+0x3350>
    4f44:      	ldr	d3, [sp, #0x1a8]
    4f48:      	fmov	w8, s3
    4f4c:      	tbz	w8, #0x0, 0x4fd4 <_llm_rows.packet_batch.blocks+0x3468>
    4f50:      	ldr	q3, [sp, #0xe0]
    4f54:      	fmov	x10, d3
    4f58:      	ldr	b9, [x10]
    4f5c:      	tbnz	w8, #0x1, 0x4fdc <_llm_rows.packet_batch.blocks+0x3470>
    4f60:      	b	0x4fe4 <_llm_rows.packet_batch.blocks+0x3478>
    4f64:      	fmov	x10, d3
    4f68:      	ld1.b	{ v25 }[2], [x10]
    4f6c:      	tbz	w14, #0x3, 0x4170 <_llm_rows.packet_batch.blocks+0x2604>
    4f70:      	mov.d	x10, v3[1]
    4f74:      	ld1.b	{ v25 }[3], [x10]
    4f78:      	adrp	x10, 0x4000 <_llm_rows.packet_batch.blocks+0x2494>
    4f7c:      	ldr	q3, [x10]
    4f80:      	and.16b	v3, v21, v3
    4f84:      	ldr	q16, [sp, #0x430]
    4f88:      	add.2d	v3, v16, v3
    4f8c:      	tbz	w14, #0x4, 0x4188 <_llm_rows.packet_batch.blocks+0x261c>
    4f90:      	fmov	x10, d3
    4f94:      	ld1.b	{ v25 }[4], [x10]
    4f98:      	tbz	w14, #0x5, 0x418c <_llm_rows.packet_batch.blocks+0x2620>
    4f9c:      	mov.d	x10, v3[1]
    4fa0:      	ld1.b	{ v25 }[5], [x10]
    4fa4:      	adrp	x10, 0x4000 <_llm_rows.packet_batch.blocks+0x2494>
    4fa8:      	ldr	q3, [x10]
    4fac:      	and.16b	v3, v10, v3
    4fb0:      	ldr	q16, [sp, #0x450]
    4fb4:      	add.2d	v21, v16, v3
    4fb8:      	tbz	w14, #0x6, 0x41a4 <_llm_rows.packet_batch.blocks+0x2638>
    4fbc:      	fmov	x10, d21
    4fc0:      	ld1.b	{ v25 }[6], [x10]
    4fc4:      	ldr	q3, [sp, #0x20]
    4fc8:      	and.16b	v3, v4, v3
    4fcc:      	tbnz	w14, #0x7, 0x41b0 <_llm_rows.packet_batch.blocks+0x2644>
    4fd0:      	b	0x41b8 <_llm_rows.packet_batch.blocks+0x264c>
    4fd4:      	movi.2d	v9, #0000000000000000
    4fd8:      	tbz	w8, #0x1, 0x4fe4 <_llm_rows.packet_batch.blocks+0x3478>
    4fdc:      	ldr	x10, [sp, #0x68]
    4fe0:      	ld1.b	{ v9 }[1], [x10]
    4fe4:      	tbnz	w8, #0x2, 0x5848 <_llm_rows.packet_batch.blocks+0x3cdc>
    4fe8:      	tbnz	w8, #0x3, 0x5858 <_llm_rows.packet_batch.blocks+0x3cec>
    4fec:      	tbnz	w8, #0x4, 0x5864 <_llm_rows.packet_batch.blocks+0x3cf8>
    4ff0:      	tbnz	w8, #0x5, 0x5874 <_llm_rows.packet_batch.blocks+0x3d08>
    4ff4:      	tbz	w8, #0x6, 0x5004 <_llm_rows.packet_batch.blocks+0x3498>
    4ff8:      	ldr	q3, [sp, #0x110]
    4ffc:      	fmov	x10, d3
    5000:      	ld1.b	{ v9 }[6], [x10]
    5004:      	adrp	x10, 0x5000 <_llm_rows.packet_batch.blocks+0x3494>
    5008:      	ldr	q3, [x10]
    500c:      	and.16b	v31, v0, v3
    5010:      	adrp	x10, 0x5000 <_llm_rows.packet_batch.blocks+0x3494>
    5014:      	ldr	q3, [x10]
    5018:      	and.16b	v14, v1, v3
    501c:      	adrp	x10, 0x5000 <_llm_rows.packet_batch.blocks+0x3494>
    5020:      	ldr	q3, [x10]
    5024:      	and.16b	v26, v0, v3
    5028:      	adrp	x10, 0x5000 <_llm_rows.packet_batch.blocks+0x3494>
    502c:      	ldr	q3, [x10]
    5030:      	and.16b	v27, v1, v3
    5034:      	movi.4s	v3, #0x4
    5038:      	and.16b	v2, v1, v3
    503c:      	str	q2, [sp, #0x450]
    5040:      	mov.16b	v8, v13
    5044:      	tbz	w8, #0x7, 0x5050 <_llm_rows.packet_batch.blocks+0x34e4>
    5048:      	ldr	x8, [sp, #0x80]
    504c:      	ld1.b	{ v9 }[7], [x8]
    5050:      	mov	x8, #0x0                ; =0
    5054:      	ldr	x1, [sp, #0x1b0]
    5058:      	add	x10, x12, x1
    505c:      	ldp	q7, q3, [x10]
    5060:      	ldr	q2, [sp, #0x370]
    5064:      	fsub.4s	v6, v7, v2
    5068:      	fsub.4s	v7, v3, v2
    506c:      	ldr	q17, [sp, #0x1c0]
    5070:      	zip2.8b	v3, v17, v0
    5074:      	ushll.4s	v3, v3, #0x0
    5078:      	shl.4s	v3, v3, #0x1f
    507c:      	cmlt.4s	v13, v3, #0
    5080:      	and.16b	v25, v13, v7
    5084:      	fcmge.4s	v7, v25, v15
    5088:      	fcmge.4s	v16, v20, v25
    508c:      	and.16b	v7, v7, v16
    5090:      	zip1.8b	v16, v17, v0
    5094:      	ushll.4s	v16, v16, #0x0
    5098:      	shl.4s	v16, v16, #0x1f
    509c:      	cmlt.4s	v24, v16, #0
    50a0:      	and.16b	v12, v24, v6
    50a4:      	fcmge.4s	v6, v12, v15
    50a8:      	fcmge.4s	v16, v20, v12
    50ac:      	and.16b	v6, v6, v16
    50b0:      	and.16b	v16, v6, v12
    50b4:      	ldp	q2, q18, [sp, #0x3e0]
    50b8:      	fmul.4s	v6, v16, v18
    50bc:      	movi.4s	v3, #0x4b, lsl #24
    50c0:      	mvni.4s	v10, #0x80, lsl #24
    50c4:      	mov.16b	v17, v10
    50c8:      	bsl.16b	v17, v3, v6
    50cc:      	fadd.4s	v6, v6, v17
    50d0:      	fsub.4s	v6, v6, v17
    50d4:      	and.16b	v7, v7, v25
    50d8:      	fmul.4s	v17, v7, v18
    50dc:      	bsl.16b	v10, v3, v17
    50e0:      	fadd.4s	v17, v17, v10
    50e4:      	fsub.4s	v17, v17, v10
    50e8:      	fcvtzs.4s	v6, v6
    50ec:      	scvtf.4s	v10, v6
    50f0:      	fmul.4s	v11, v10, v2
    50f4:      	fadd.4s	v16, v16, v11
    50f8:      	fcvtzs.4s	v17, v17
    50fc:      	scvtf.4s	v11, v17
    5100:      	fmul.4s	v3, v11, v2
    5104:      	fadd.4s	v3, v7, v3
    5108:      	ldr	q2, [sp, #0x3d0]
    510c:      	fmul.4s	v7, v10, v2
    5110:      	fmul.4s	v10, v11, v2
    5114:      	fadd.4s	v3, v3, v10
    5118:      	fadd.4s	v7, v16, v7
    511c:      	ldr	q2, [sp, #0x3c0]
    5120:      	fmul.4s	v16, v7, v2
    5124:      	fmul.4s	v10, v3, v2
    5128:      	ldr	q2, [sp, #0x3b0]
    512c:      	fadd.4s	v10, v10, v2
    5130:      	fadd.4s	v16, v16, v2
    5134:      	fmul.4s	v16, v7, v16
    5138:      	fmul.4s	v10, v3, v10
    513c:      	ldr	q2, [sp, #0x3a0]
    5140:      	fadd.4s	v10, v10, v2
    5144:      	fadd.4s	v16, v16, v2
    5148:      	fmul.4s	v16, v7, v16
    514c:      	fmul.4s	v10, v3, v10
    5150:      	ldr	q2, [sp, #0x390]
    5154:      	fadd.4s	v10, v10, v2
    5158:      	fadd.4s	v16, v16, v2
    515c:      	fmul.4s	v16, v7, v16
    5160:      	fmul.4s	v18, v3, v10
    5164:      	ldr	q2, [sp, #0x380]
    5168:      	fadd.4s	v18, v18, v2
    516c:      	fadd.4s	v16, v16, v2
    5170:      	fmul.4s	v16, v7, v16
    5174:      	movi.4s	v10, #0x3f, lsl #24
    5178:      	fadd.4s	v16, v16, v10
    517c:      	fmul.4s	v19, v7, v7
    5180:      	fmul.4s	v16, v19, v16
    5184:      	fmul.4s	v18, v3, v18
    5188:      	fadd.4s	v18, v18, v10
    518c:      	fmul.4s	v19, v3, v3
    5190:      	fmul.4s	v18, v19, v18
    5194:      	fadd.4s	v3, v3, v18
    5198:      	fadd.4s	v7, v7, v16
    519c:      	fadd.4s	v3, v3, v5
    51a0:      	sshr.4s	v16, v17, #0x1
    51a4:      	shl.4s	v18, v16, #0x17
    51a8:      	add.4s	v18, v18, v5
    51ac:      	fmul.4s	v3, v3, v18
    51b0:      	sub.4s	v16, v17, v16
    51b4:      	shl.4s	v16, v16, #0x17
    51b8:      	add.4s	v16, v16, v5
    51bc:      	fmul.4s	v3, v3, v16
    51c0:      	fcmgt.4s	v16, v15, v25
    51c4:      	bic.16b	v3, v3, v16
    51c8:      	fcmgt.4s	v16, v25, v20
    51cc:      	ldr	q18, [sp, #0x410]
    51d0:      	bit.16b	v3, v18, v16
    51d4:      	cmeq.8b	v16, v9, #0
    51d8:      	sshll.8h	v16, v16, #0x0
    51dc:      	fcmeq.4s	v17, v25, v25
    51e0:      	ldr	q25, [sp, #0x400]
    51e4:      	bif.16b	v3, v25, v17
    51e8:      	sshll2.4s	v17, v16, #0x0
    51ec:      	fadd.4s	v7, v7, v5
    51f0:      	bic.16b	v19, v3, v17
    51f4:      	fadd.4s	v3, v30, v19
    51f8:      	and.16b	v3, v13, v3
    51fc:      	ldr	q30, [sp, #0x90]
    5200:      	zip2.8b	v17, v30, v0
    5204:      	ushll.4s	v17, v17, #0x0
    5208:      	shl.4s	v17, v17, #0x1f
    520c:      	cmlt.4s	v17, v17, #0
    5210:      	ldr	q2, [sp, #0x220]
    5214:      	bit.16b	v3, v2, v17
    5218:      	sshr.4s	v2, v6, #0x1
    521c:      	shl.4s	v17, v2, #0x17
    5220:      	add.4s	v17, v17, v5
    5224:      	fmul.4s	v7, v7, v17
    5228:      	sub.4s	v2, v6, v2
    522c:      	shl.4s	v2, v2, #0x17
    5230:      	add.4s	v2, v2, v5
    5234:      	fmul.4s	v2, v7, v2
    5238:      	fcmgt.4s	v5, v15, v12
    523c:      	bic.16b	v2, v2, v5
    5240:      	fcmgt.4s	v5, v12, v20
    5244:      	bit.16b	v2, v18, v5
    5248:      	fcmeq.4s	v5, v12, v12
    524c:      	bif.16b	v2, v25, v5
    5250:      	sshll.4s	v5, v16, #0x0
    5254:      	bic.16b	v2, v2, v5
    5258:      	fadd.4s	v5, v29, v2
    525c:      	and.16b	v5, v24, v5
    5260:      	zip1.8b	v6, v30, v0
    5264:      	ushll.4s	v6, v6, #0x0
    5268:      	shl.4s	v6, v6, #0x1f
    526c:      	cmlt.4s	v6, v6, #0
    5270:      	bit.16b	v5, v8, v6
    5274:      	fadd.4s	v5, v28, v5
    5278:      	fadd.4s	v3, v23, v3
    527c:      	fadd.4s	v3, v22, v3
    5280:      	fadd.4s	v5, v21, v5
    5284:      	fadd.4s	v4, v4, v5
    5288:      	ldr	q5, [sp, #0x2f0]
    528c:      	fadd.4s	v5, v5, v3
    5290:      	fmov	w10, s14
    5294:      	add	x11, sp, #0x4a8
    5298:      	bfxil	x11, x10, #0, #3
    529c:      	ldr	q3, [sp, #0xb0]
    52a0:      	str	d3, [sp, #0x4a8]
    52a4:      	ldrb	w11, [x11]
    52a8:      	and	x10, x10, #0x7
    52ac:      	str	q5, [sp, #0x660]
    52b0:      	str	q4, [sp, #0x650]
    52b4:      	add	x12, sp, #0x650
    52b8:      	ldr	s3, [x12, x10, lsl #2]
    52bc:      	tst	w30, w11
    52c0:      	movi	d20, #0000000000000000
    52c4:      	fcsel	s7, s3, s20, ne
    52c8:      	mov.s	w10, v14[1]
    52cc:      	and	x11, x10, #0x7
    52d0:      	add	x12, sp, #0x4a8
    52d4:      	bfxil	x12, x10, #0, #3
    52d8:      	ldrb	w10, [x12]
    52dc:      	str	q5, [sp, #0x640]
    52e0:      	str	q4, [sp, #0x630]
    52e4:      	add	x12, sp, #0x630
    52e8:      	ldr	s3, [x12, x11, lsl #2]
    52ec:      	and	w10, w6, w10
    52f0:      	tst	w10, #0x1
    52f4:      	fcsel	s16, s3, s20, ne
    52f8:      	mov.s	w10, v14[2]
    52fc:      	and	x11, x10, #0x7
    5300:      	add	x12, sp, #0x4a8
    5304:      	bfxil	x12, x10, #0, #3
    5308:      	ldrb	w10, [x12]
    530c:      	and	w10, w5, w10
    5310:      	str	q5, [sp, #0x620]
    5314:      	str	q4, [sp, #0x610]
    5318:      	add	x12, sp, #0x610
    531c:      	ldr	s3, [x12, x11, lsl #2]
    5320:      	tst	w10, #0x1
    5324:      	fcsel	s17, s3, s20, ne
    5328:      	mov.s	w10, v14[3]
    532c:      	and	x11, x10, #0x7
    5330:      	add	x12, sp, #0x4a8
    5334:      	bfxil	x12, x10, #0, #3
    5338:      	ldrb	w10, [x12]
    533c:      	and	w10, w2, w10
    5340:      	str	q5, [sp, #0x600]
    5344:      	str	q4, [sp, #0x5f0]
    5348:      	add	x12, sp, #0x5f0
    534c:      	ldr	s3, [x12, x11, lsl #2]
    5350:      	tst	w10, #0x1
    5354:      	fcsel	s18, s3, s20, ne
    5358:      	fmov	w10, s31
    535c:      	and	x11, x10, #0x7
    5360:      	add	x12, sp, #0x4a8
    5364:      	bfxil	x12, x10, #0, #3
    5368:      	ldrb	w10, [x12]
    536c:      	mov	x22, x3
    5370:      	and	w10, w3, w10
    5374:      	str	q5, [sp, #0x6e0]
    5378:      	str	q4, [sp, #0x6d0]
    537c:      	add	x12, sp, #0x6d0
    5380:      	ldr	s3, [x12, x11, lsl #2]
    5384:      	tst	w10, #0x1
    5388:      	mov.s	w10, v31[1]
    538c:      	and	x11, x10, #0x7
    5390:      	add	x12, sp, #0x4a8
    5394:      	bfxil	x12, x10, #0, #3
    5398:      	ldrb	w10, [x12]
    539c:      	str	q5, [sp, #0x6c0]
    53a0:      	str	q4, [sp, #0x6b0]
    53a4:      	mov.s	w12, v31[2]
    53a8:      	mov.s	w14, v31[3]
    53ac:      	add	x3, sp, #0x6b0
    53b0:      	ldr	s6, [x3, x11, lsl #2]
    53b4:      	fcsel	s3, s3, s20, ne
    53b8:      	ldr	w0, [sp, #0xc4]
    53bc:      	and	w10, w0, w10
    53c0:      	tst	w10, #0x1
    53c4:      	fcsel	s6, s6, s20, ne
    53c8:      	add	x10, sp, #0x4a8
    53cc:      	bfxil	x10, x12, #0, #3
    53d0:      	and	x11, x12, #0x7
    53d4:      	ldrb	w10, [x10]
    53d8:      	str	q5, [sp, #0x6a0]
    53dc:      	str	q4, [sp, #0x690]
    53e0:      	mov.s	v3[1], v6[0]
    53e4:      	add	x12, sp, #0x690
    53e8:      	ldr	s6, [x12, x11, lsl #2]
    53ec:      	ldp	w17, w3, [sp, #0xd0]
    53f0:      	and	w10, w17, w10
    53f4:      	tst	w10, #0x1
    53f8:      	fcsel	s6, s6, s20, ne
    53fc:      	add	x10, sp, #0x4a8
    5400:      	bfxil	x10, x14, #0, #3
    5404:      	and	x11, x14, #0x7
    5408:      	ldrb	w10, [x10]
    540c:      	and	w10, w3, w10
    5410:      	str	q5, [sp, #0x680]
    5414:      	str	q4, [sp, #0x670]
    5418:      	mov.s	v3[2], v6[0]
    541c:      	add	x12, sp, #0x670
    5420:      	ldr	s6, [x12, x11, lsl #2]
    5424:      	tst	w10, #0x1
    5428:      	fcsel	s6, s6, s20, ne
    542c:      	mov.s	v3[3], v6[0]
    5430:      	mov.s	v7[1], v16[0]
    5434:      	mov.s	v7[2], v17[0]
    5438:      	mov.s	v7[3], v18[0]
    543c:      	fadd.4s	v4, v4, v7
    5440:      	fadd.4s	v5, v5, v3
    5444:      	fmov	w10, s27
    5448:      	add	x11, sp, #0x4a8
    544c:      	bfxil	x11, x10, #0, #3
    5450:      	ldrb	w11, [x11]
    5454:      	and	x10, x10, #0x7
    5458:      	str	q5, [sp, #0x560]
    545c:      	str	q4, [sp, #0x550]
    5460:      	add	x12, sp, #0x550
    5464:      	ldr	s3, [x12, x10, lsl #2]
    5468:      	tst	w30, w11
    546c:      	mov.s	w10, v27[1]
    5470:      	add	x11, sp, #0x4a8
    5474:      	bfxil	x11, x10, #0, #3
    5478:      	ldrb	w11, [x11]
    547c:      	and	w11, w6, w11
    5480:      	fcsel	s7, s3, s20, ne
    5484:      	and	x10, x10, #0x7
    5488:      	str	q5, [sp, #0x540]
    548c:      	str	q4, [sp, #0x530]
    5490:      	add	x12, sp, #0x530
    5494:      	ldr	s3, [x12, x10, lsl #2]
    5498:      	tst	w11, #0x1
    549c:      	mov.s	w10, v27[2]
    54a0:      	fcsel	s16, s3, s20, ne
    54a4:      	add	x11, sp, #0x4a8
    54a8:      	bfxil	x11, x10, #0, #3
    54ac:      	and	x10, x10, #0x7
    54b0:      	ldrb	w11, [x11]
    54b4:      	and	w11, w5, w11
    54b8:      	str	q5, [sp, #0x520]
    54bc:      	str	q4, [sp, #0x510]
    54c0:      	add	x12, sp, #0x510
    54c4:      	ldr	s3, [x12, x10, lsl #2]
    54c8:      	tst	w11, #0x1
    54cc:      	fcsel	s17, s3, s20, ne
    54d0:      	mov.s	w10, v27[3]
    54d4:      	and	x11, x10, #0x7
    54d8:      	add	x12, sp, #0x4a8
    54dc:      	bfxil	x12, x10, #0, #3
    54e0:      	ldrb	w10, [x12]
    54e4:      	and	w10, w2, w10
    54e8:      	str	q5, [sp, #0x500]
    54ec:      	str	q4, [sp, #0x4f0]
    54f0:      	add	x12, sp, #0x4f0
    54f4:      	ldr	s3, [x12, x11, lsl #2]
    54f8:      	tst	w10, #0x1
    54fc:      	fcsel	s6, s3, s20, ne
    5500:      	fmov	w10, s26
    5504:      	and	x11, x10, #0x7
    5508:      	add	x12, sp, #0x4a8
    550c:      	bfxil	x12, x10, #0, #3
    5510:      	ldrb	w10, [x12]
    5514:      	and	w10, w22, w10
    5518:      	str	q5, [sp, #0x5e0]
    551c:      	str	q4, [sp, #0x5d0]
    5520:      	add	x12, sp, #0x5d0
    5524:      	ldr	s3, [x12, x11, lsl #2]
    5528:      	tst	w10, #0x1
    552c:      	fcsel	s18, s3, s20, ne
    5530:      	mov.s	w10, v26[1]
    5534:      	and	x11, x10, #0x7
    5538:      	add	x12, sp, #0x4a8
    553c:      	bfxil	x12, x10, #0, #3
    5540:      	ldrb	w10, [x12]
    5544:      	and	w10, w0, w10
    5548:      	str	q5, [sp, #0x5c0]
    554c:      	str	q4, [sp, #0x5b0]
    5550:      	mov.s	w12, v26[2]
    5554:      	mov.s	w14, v26[3]
    5558:      	add	x0, sp, #0x5b0
    555c:      	ldr	s3, [x0, x11, lsl #2]
    5560:      	tst	w10, #0x1
    5564:      	fcsel	s3, s3, s20, ne
    5568:      	and	x10, x12, #0x7
    556c:      	add	x11, sp, #0x4a8
    5570:      	bfxil	x11, x12, #0, #3
    5574:      	ldrb	w11, [x11]
    5578:      	and	w11, w17, w11
    557c:      	str	q5, [sp, #0x5a0]
    5580:      	str	q4, [sp, #0x590]
    5584:      	mov.s	v18[1], v3[0]
    5588:      	add	x12, sp, #0x590
    558c:      	ldr	s3, [x12, x10, lsl #2]
    5590:      	tst	w11, #0x1
    5594:      	fcsel	s3, s3, s20, ne
    5598:      	and	x10, x14, #0x7
    559c:      	add	x11, sp, #0x4a8
    55a0:      	bfxil	x11, x14, #0, #3
    55a4:      	ldrb	w11, [x11]
    55a8:      	and	w11, w3, w11
    55ac:      	str	q5, [sp, #0x580]
    55b0:      	str	q4, [sp, #0x570]
    55b4:      	mov.s	v18[2], v3[0]
    55b8:      	add	x12, sp, #0x570
    55bc:      	ldr	s3, [x12, x10, lsl #2]
    55c0:      	tst	w11, #0x1
    55c4:      	fcsel	s3, s3, s20, ne
    55c8:      	mov.s	v18[3], v3[0]
    55cc:      	mov.s	v7[1], v16[0]
    55d0:      	mov.s	v7[2], v17[0]
    55d4:      	mov.s	v7[3], v6[0]
    55d8:      	fadd.4s	v3, v4, v7
    55dc:      	fadd.4s	v4, v5, v18
    55e0:      	ldr	q5, [sp, #0x450]
    55e4:      	fmov	w10, s5
    55e8:      	add	x11, sp, #0x4a8
    55ec:      	orr	x11, x11, x10
    55f0:      	ldrb	w11, [x11]
    55f4:      	str	q4, [sp, #0x4e0]
    55f8:      	str	q3, [sp, #0x4d0]
    55fc:      	add	x12, x9, x1
    5600:      	ldp	q5, q4, [x12]
    5604:      	bit.16b	v4, v19, v13
    5608:      	add	x14, sp, #0x4d0
    560c:      	ldr	s6, [x14, w10, uxtw #2]
    5610:      	bif.16b	v2, v5, v24
    5614:      	tst	w30, w11
    5618:      	fcsel	s5, s6, s20, ne
    561c:      	ldr	w10, [sp, #0xcc]
    5620:      	tst	w10, #0x1
    5624:      	stp	q2, q4, [x12]
    5628:      	fadd	s2, s3, s5
    562c:      	fcsel	s3, s2, s20, ne
    5630:      	tst	w16, #0x1
    5634:      	fcsel	s4, s2, s20, ne
    5638:      	tst	w27, #0x1
    563c:      	fcsel	s5, s2, s20, ne
    5640:      	tst	w19, #0x1
    5644:      	mov.s	v3[1], v4[0]
    5648:      	fcsel	s4, s2, s20, ne
    564c:      	mov.s	v3[2], v5[0]
    5650:      	tst	w13, #0x1
    5654:      	fcsel	s5, s2, s20, ne
    5658:      	tst	w15, #0x1
    565c:      	mov.s	v3[3], v4[0]
    5660:      	fcsel	s4, s2, s20, ne
    5664:      	ldp	w11, w10, [sp, #0x88]
    5668:      	tst	w11, #0x1
    566c:      	mov.s	v5[1], v4[0]
    5670:      	fcsel	s4, s2, s20, ne
    5674:      	tst	w10, #0x1
    5678:      	fcsel	s2, s2, s20, ne
    567c:      	mov.s	v5[2], v4[0]
    5680:      	mov.s	v5[3], v2[0]
    5684:      	str	q5, [sp, #0x4c0]
    5688:      	str	q3, [sp, #0x4b0]
    568c:      	and	x10, x7, #0x7
    5690:      	add	x11, sp, #0x4b0
    5694:      	ldr	s2, [x11, x10, lsl #2]
    5698:      	fadd	s2, s2, s20
    569c:      	dup.4s	v2, v2[0]
    56a0:      	ldr	q3, [sp, #0x120]
    56a4:      	fmov	x10, d3
    56a8:      	ldr	x13, [sp, #0x170]
    56ac:      	add	x12, x13, x10, lsl #2
    56b0:      	movi.2d	v3, #0000000000000000
    56b4:      	movi.2d	v4, #0000000000000000
    56b8:      	movi.2d	v5, #0000000000000000
    56bc:      	movi.2d	v6, #0000000000000000
    56c0:      	ldr	q17, [sp, #0x360]
    56c4:      	ldp	q19, q18, [sp, #0x1f0]
    56c8:      	ldp	q21, q20, [sp, #0x1d0]
    56cc:      	ldr	w22, [sp, #0xac]
    56d0:      	b	0x56f0 <_llm_rows.packet_batch.blocks+0x3b84>
    56d4:      	add.2d	v4, v4, v19
    56d8:      	add.2d	v5, v5, v20
    56dc:      	add.2d	v6, v6, v18
    56e0:      	add.2d	v3, v3, v21
    56e4:      	fmov	x8, d3
    56e8:      	cmp	x8, #0x200
    56ec:      	b.ge	0x57a0 <_llm_rows.packet_batch.blocks+0x3c34>
    56f0:      	fmov	w10, s17
    56f4:      	lsl	x8, x8, #5
    56f8:      	add	x11, x9, x8
    56fc:      	ldp	q16, q7, [x11]
    5700:      	and.16b	v16, v1, v16
    5704:      	fdiv.4s	v16, v16, v2
    5708:      	add	x8, x12, x8
    570c:      	tbnz	w10, #0x0, 0x573c <_llm_rows.packet_batch.blocks+0x3bd0>
    5710:      	and	w10, w10, #0xff
    5714:      	tbnz	w10, #0x1, 0x5748 <_llm_rows.packet_batch.blocks+0x3bdc>
    5718:      	tbnz	w10, #0x2, 0x5754 <_llm_rows.packet_batch.blocks+0x3be8>
    571c:      	tbnz	w10, #0x3, 0x5760 <_llm_rows.packet_batch.blocks+0x3bf4>
    5720:      	and.16b	v7, v0, v7
    5724:      	fdiv.4s	v7, v7, v2
    5728:      	tbnz	w10, #0x4, 0x5774 <_llm_rows.packet_batch.blocks+0x3c08>
    572c:      	tbnz	w10, #0x5, 0x577c <_llm_rows.packet_batch.blocks+0x3c10>
    5730:      	tbnz	w10, #0x6, 0x5788 <_llm_rows.packet_batch.blocks+0x3c1c>
    5734:      	tbz	w10, #0x7, 0x56d4 <_llm_rows.packet_batch.blocks+0x3b68>
    5738:      	b	0x5794 <_llm_rows.packet_batch.blocks+0x3c28>
    573c:      	str	s16, [x8]
    5740:      	and	w10, w10, #0xff
    5744:      	tbz	w10, #0x1, 0x5718 <_llm_rows.packet_batch.blocks+0x3bac>
    5748:      	add	x11, x8, #0x4
    574c:      	st1.s	{ v16 }[1], [x11]
    5750:      	tbz	w10, #0x2, 0x571c <_llm_rows.packet_batch.blocks+0x3bb0>
    5754:      	add	x11, x8, #0x8
    5758:      	st1.s	{ v16 }[2], [x11]
    575c:      	tbz	w10, #0x3, 0x5720 <_llm_rows.packet_batch.blocks+0x3bb4>
    5760:      	add	x11, x8, #0xc
    5764:      	st1.s	{ v16 }[3], [x11]
    5768:      	and.16b	v7, v0, v7
    576c:      	fdiv.4s	v7, v7, v2
    5770:      	tbz	w10, #0x4, 0x572c <_llm_rows.packet_batch.blocks+0x3bc0>
    5774:      	str	s7, [x8, #0x10]
    5778:      	tbz	w10, #0x5, 0x5730 <_llm_rows.packet_batch.blocks+0x3bc4>
    577c:      	add	x11, x8, #0x14
    5780:      	st1.s	{ v7 }[1], [x11]
    5784:      	tbz	w10, #0x6, 0x5734 <_llm_rows.packet_batch.blocks+0x3bc8>
    5788:      	add	x11, x8, #0x18
    578c:      	st1.s	{ v7 }[2], [x11]
    5790:      	tbz	w10, #0x7, 0x56d4 <_llm_rows.packet_batch.blocks+0x3b68>
    5794:      	add	x8, x8, #0x1c
    5798:      	st1.s	{ v7 }[3], [x8]
    579c:      	b	0x56d4 <_llm_rows.packet_batch.blocks+0x3b68>
    57a0:      	ldr	x8, [sp, #0x1b0]
    57a4:      	add	x8, x9, x8
    57a8:      	ldp	q1, q0, [x8]
    57ac:      	ldr	q3, [sp, #0x1c0]
    57b0:      	zip1.8b	v3, v3, v0
    57b4:      	ushll.4s	v3, v3, #0x0
    57b8:      	shl.4s	v3, v3, #0x1f
    57bc:      	cmlt.4s	v3, v3, #0
    57c0:      	and.16b	v1, v3, v1
    57c4:      	ldr	d3, [sp, #0x1a8]
    57c8:      	fmov	w8, s3
    57cc:      	fdiv.4s	v1, v1, v2
    57d0:      	ldr	q3, [sp, #0x160]
    57d4:      	str	q3, [sp, #0x460]
    57d8:      	ldp	q3, q4, [sp, #0x130]
    57dc:      	str	q4, [sp, #0x470]
    57e0:      	str	q3, [sp, #0x480]
    57e4:      	ldr	q3, [sp, #0x150]
    57e8:      	str	q3, [sp, #0x490]
    57ec:      	and	x9, x4, #0x7
    57f0:      	add	x10, sp, #0x460
    57f4:      	ldr	x9, [x10, x9, lsl #3]
    57f8:      	sub	x9, x9, x4
    57fc:      	add	x9, x13, x9, lsl #2
    5800:      	tbnz	w8, #0x0, 0x5884 <_llm_rows.packet_batch.blocks+0x3d18>
    5804:      	tbnz	w8, #0x1, 0x588c <_llm_rows.packet_batch.blocks+0x3d20>
    5808:      	tbnz	w8, #0x2, 0x5898 <_llm_rows.packet_batch.blocks+0x3d2c>
    580c:      	tbz	w8, #0x3, 0x5818 <_llm_rows.packet_batch.blocks+0x3cac>
    5810:      	add	x10, x9, #0xc
    5814:      	st1.s	{ v1 }[3], [x10]
    5818:      	ldr	q1, [sp, #0x1c0]
    581c:      	zip2.8b	v1, v1, v0
    5820:      	ushll.4s	v1, v1, #0x0
    5824:      	shl.4s	v1, v1, #0x1f
    5828:      	cmlt.4s	v1, v1, #0
    582c:      	and.16b	v0, v1, v0
    5830:      	fdiv.4s	v0, v0, v2
    5834:      	tbnz	w8, #0x4, 0x58a8 <_llm_rows.packet_batch.blocks+0x3d3c>
    5838:      	tbnz	w8, #0x5, 0x58b0 <_llm_rows.packet_batch.blocks+0x3d44>
    583c:      	tbnz	w8, #0x6, 0x58bc <_llm_rows.packet_batch.blocks+0x3d50>
    5840:      	tbz	w8, #0x7, 0x1c24 <_llm_rows.packet_batch.blocks+0xb8>
    5844:      	b	0x58c8 <_llm_rows.packet_batch.blocks+0x3d5c>
    5848:      	ldr	q3, [sp, #0xf0]
    584c:      	fmov	x10, d3
    5850:      	ld1.b	{ v9 }[2], [x10]
    5854:      	tbz	w8, #0x3, 0x4fec <_llm_rows.packet_batch.blocks+0x3480>
    5858:      	ldr	x10, [sp, #0x70]
    585c:      	ld1.b	{ v9 }[3], [x10]
    5860:      	tbz	w8, #0x4, 0x4ff0 <_llm_rows.packet_batch.blocks+0x3484>
    5864:      	ldr	q3, [sp, #0x100]
    5868:      	fmov	x10, d3
    586c:      	ld1.b	{ v9 }[4], [x10]
    5870:      	tbz	w8, #0x5, 0x4ff4 <_llm_rows.packet_batch.blocks+0x3488>
    5874:      	ldr	x10, [sp, #0x78]
    5878:      	ld1.b	{ v9 }[5], [x10]
    587c:      	tbnz	w8, #0x6, 0x4ff8 <_llm_rows.packet_batch.blocks+0x348c>
    5880:      	b	0x5004 <_llm_rows.packet_batch.blocks+0x3498>
    5884:      	str	s1, [x9]
    5888:      	tbz	w8, #0x1, 0x5808 <_llm_rows.packet_batch.blocks+0x3c9c>
    588c:      	add	x10, x9, #0x4
    5890:      	st1.s	{ v1 }[1], [x10]
    5894:      	tbz	w8, #0x2, 0x580c <_llm_rows.packet_batch.blocks+0x3ca0>
    5898:      	add	x10, x9, #0x8
    589c:      	st1.s	{ v1 }[2], [x10]
    58a0:      	tbnz	w8, #0x3, 0x5810 <_llm_rows.packet_batch.blocks+0x3ca4>
    58a4:      	b	0x5818 <_llm_rows.packet_batch.blocks+0x3cac>
    58a8:      	str	s0, [x9, #0x10]
    58ac:      	tbz	w8, #0x5, 0x583c <_llm_rows.packet_batch.blocks+0x3cd0>
    58b0:      	add	x10, x9, #0x14
    58b4:      	st1.s	{ v0 }[1], [x10]
    58b8:      	tbz	w8, #0x6, 0x5840 <_llm_rows.packet_batch.blocks+0x3cd4>
    58bc:      	add	x10, x9, #0x18
    58c0:      	st1.s	{ v0 }[2], [x10]
    58c4:      	tbz	w8, #0x7, 0x1c24 <_llm_rows.packet_batch.blocks+0xb8>
    58c8:      	add	x8, x9, #0x1c
    58cc:      	st1.s	{ v0 }[3], [x8]
    58d0:      	b	0x1c24 <_llm_rows.packet_batch.blocks+0xb8>
    58d4:      	add	sp, sp, #0xb00
    58d8:      	ldp	x29, x30, [sp, #0x90]
    58dc:      	ldp	x20, x19, [sp, #0x80]
    58e0:      	ldp	x22, x21, [sp, #0x70]
    58e4:      	ldp	x24, x23, [sp, #0x60]
    58e8:      	ldp	x26, x25, [sp, #0x50]
    58ec:      	ldp	x28, x27, [sp, #0x40]
    58f0:      	ldp	d9, d8, [sp, #0x30]
    58f4:      	ldp	d11, d10, [sp, #0x20]
    58f8:      	ldp	d13, d12, [sp, #0x10]
    58fc:      	ldp	d15, d14, [sp], #0xa0
    5900:      	ret

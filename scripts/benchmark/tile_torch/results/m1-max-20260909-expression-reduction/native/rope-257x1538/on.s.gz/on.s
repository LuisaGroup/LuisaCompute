
/private/tmp/luisa-expression-fusion.qXgTbC/capture/rope-257x1538/on/object/tile_xir_w8_23521_1788930274887170_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
      2c:      	sub	sp, sp, #0x360
      30:      	str	x0, [sp, #0x48]
      34:      	cbz	w3, 0x17d0 <ltmp0+0x17d0>
      38:      	mov	w7, #0x0                ; =0
      3c:      	ldp	w9, w8, [x2, #0x2c]
      40:      	stp	w8, w9, [sp, #0x70]
      44:      	add	x4, sp, #0x2, lsl #12   ; =0x2000
      48:      	add	x4, x4, #0x740
      4c:      	add	x19, sp, #0x1, lsl #12  ; =0x1000
      50:      	add	x19, x19, #0xb20
      54:      	ldp	w8, w9, [x2]
      58:      	add	x28, sp, #0xf00
      5c:      	add	x20, sp, #0x2e0
      60:      	ldp	w10, w11, [x2, #0x8]
      64:      	str	x2, [sp, #0x8]
      68:      	str	x11, [sp, #0x68]
      6c:      	adrp	x11, 0x0 <ltmp0>
      70:      	ldr	q0, [x11]
      74:      	str	q0, [sp, #0x30]
      78:      	adrp	x11, 0x0 <ltmp0>
      7c:      	ldr	q0, [x11]
      80:      	str	q0, [sp, #0x20]
      84:      	adrp	x11, 0x0 <ltmp0>
      88:      	ldr	q0, [x11]
      8c:      	str	q0, [sp, #0x10]
      90:      	str	w3, [sp, #0x78]
      94:      	b	0xd4 <ltmp0+0xd4>
      98:      	add	w8, w6, #0x1
      9c:      	ldp	w11, w9, [sp, #0x70]
      a0:      	cmp	w8, w9
      a4:      	cset	w9, eq
      a8:      	csinc	w8, wzr, w6, eq
      ac:      	cinc	w10, w5, eq
      b0:      	cmp	w10, w11
      b4:      	cset	w11, eq
      b8:      	ands	w11, w9, w11
      bc:      	csel	w9, wzr, w10, ne
      c0:      	ldr	w12, [sp, #0x80]
      c4:      	add	w10, w12, w11
      c8:      	add	w7, w7, #0x1
      cc:      	cmp	w7, w3
      d0:      	b.eq	0x17bc <ltmp0+0x17bc>
      d4:      	stp	w10, w7, [sp, #0x80]
      d8:      	str	w9, [sp, #0x7c]
      dc:      	mov	x13, x8
      e0:      	ubfiz	x8, x8, #5, #32
      e4:      	ldr	x12, [sp, #0x68]
      e8:      	cmp	x8, x12
      ec:      	csel	x9, x8, xzr, ls
      f0:      	subs	x10, x12, x9
      f4:      	cmp	x10, #0x20
      f8:      	mov	w11, #0x20              ; =32
      fc:      	csel	x10, x10, x11, lo
     100:      	cmp	x12, x9
     104:      	ccmp	x8, x12, #0x2, hi
     108:      	csel	x9, x10, xzr, ls
     10c:      	cmp	x9, #0x20
     110:      	str	x13, [sp, #0x88]
     114:      	b.lo	0x77c <ltmp0+0x77c>
     118:      	ldr	x8, [sp, #0x48]
     11c:      	ldr	x23, [x8]
     120:      	ldr	x24, [x8, #0x10]
     124:      	ldr	x25, [x8, #0x20]
     128:      	ldr	x8, [x8, #0x30]
     12c:      	str	x8, [sp, #0x100]
     130:      	ubfiz	w27, w13, #2, #27
     134:      	mov	w26, #0x1808            ; =6152
     138:      	umull	x21, w27, w26
     13c:      	umaddl	x22, w27, w26, x23
     140:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
     144:      	add	x0, x0, #0x740
     148:      	mov	x1, x22
     14c:      	mov	w2, #0xc00              ; =3072
     150:      	bl	0x150 <ltmp0+0x150>
     154:      	add	x21, x21, #0xc00
     158:      	ldr	s0, [x23, x21]
     15c:      	str	q0, [sp, #0xb0]
     160:      	str	q0, [sp, #0x3340]
     164:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     168:      	add	x0, x0, #0xb20
     16c:      	add	x1, x22, #0xc04
     170:      	mov	w2, #0xc00              ; =3072
     174:      	bl	0x174 <ltmp0+0x174>
     178:      	mov	w8, #0x1804             ; =6148
     17c:      	umaddl	x8, w27, w26, x8
     180:      	str	x23, [sp, #0xc0]
     184:      	str	x8, [sp, #0xa8]
     188:      	ldr	s0, [x23, x8]
     18c:      	str	q0, [sp, #0x90]
     190:      	str	q0, [sp, #0x2720]
     194:      	mov	w22, #0xc04             ; =3076
     198:      	umull	x23, w27, w22
     19c:      	umaddl	x1, w27, w22, x24
     1a0:      	add	x0, sp, #0xf00
     1a4:      	mov	w2, #0xc00              ; =3072
     1a8:      	bl	0x1a8 <ltmp0+0x1a8>
     1ac:      	add	x23, x23, #0xc00
     1b0:      	str	x24, [sp, #0xe0]
     1b4:      	ldr	s0, [x24, x23]
     1b8:      	ldr	x24, [sp, #0x100]
     1bc:      	str	q0, [sp, #0x50]
     1c0:      	str	q0, [sp, #0x1b00]
     1c4:      	umaddl	x1, w27, w22, x25
     1c8:      	add	x0, sp, #0x2e0
     1cc:      	mov	w2, #0xc00              ; =3072
     1d0:      	bl	0x1d0 <ltmp0+0x1d0>
     1d4:      	add	x11, sp, #0x2, lsl #12  ; =0x2000
     1d8:      	add	x11, x11, #0x740
     1dc:      	mov	x9, #0x0                ; =0
     1e0:      	str	x25, [sp, #0xf0]
     1e4:      	ldr	s0, [x25, x23]
     1e8:      	str	q0, [sp, #0xee0]
     1ec:      	str	w27, [sp, #0xd0]
     1f0:      	umaddl	x8, w27, w26, x24
     1f4:      	add	x10, x11, x9
     1f8:      	ldp	q1, q2, [x10]
     1fc:      	add	x10, x28, x9
     200:      	ldp	q3, q4, [x10]
     204:      	fmul.4s	v2, v2, v4
     208:      	fmul.4s	v1, v1, v3
     20c:      	add	x10, x19, x9
     210:      	ldp	q3, q4, [x10]
     214:      	add	x10, x20, x9
     218:      	ldp	q5, q6, [x10]
     21c:      	fmul.4s	v4, v4, v6
     220:      	fmul.4s	v3, v3, v5
     224:      	fsub.4s	v1, v1, v3
     228:      	fsub.4s	v2, v2, v4
     22c:      	add	x10, x8, x9
     230:      	stp	q1, q2, [x10]
     234:      	add	x9, x9, #0x20
     238:      	cmp	x9, #0xc00
     23c:      	b.ne	0x1f4 <ltmp0+0x1f4>
     240:      	mov	x9, #0x0                ; =0
     244:      	ldr	q7, [sp, #0xb0]
     248:      	ldr	q17, [sp, #0x50]
     24c:      	fmul.4s	v1, v7, v17
     250:      	ldr	q16, [sp, #0x90]
     254:      	fmul.4s	v2, v16, v0
     258:      	fsub.4s	v1, v1, v2
     25c:      	str	s1, [x24, x21]
     260:      	add	x8, x8, #0xc04
     264:      	add	x10, x11, x9
     268:      	ldp	q1, q2, [x10]
     26c:      	add	x10, x20, x9
     270:      	ldp	q3, q4, [x10]
     274:      	fmul.4s	v2, v2, v4
     278:      	fmul.4s	v1, v1, v3
     27c:      	add	x10, x19, x9
     280:      	ldp	q3, q4, [x10]
     284:      	add	x10, x28, x9
     288:      	ldp	q5, q6, [x10]
     28c:      	fmul.4s	v4, v4, v6
     290:      	fmul.4s	v3, v3, v5
     294:      	fadd.4s	v1, v1, v3
     298:      	fadd.4s	v2, v2, v4
     29c:      	add	x10, x8, x9
     2a0:      	stp	q1, q2, [x10]
     2a4:      	add	x9, x9, #0x20
     2a8:      	cmp	x9, #0xc00
     2ac:      	b.ne	0x264 <ltmp0+0x264>
     2b0:      	fmul.4s	v0, v7, v0
     2b4:      	fmul.4s	v1, v16, v17
     2b8:      	fadd.4s	v0, v1, v0
     2bc:      	ldr	x8, [sp, #0xa8]
     2c0:      	str	s0, [x24, x8]
     2c4:      	ldr	w8, [sp, #0xd0]
     2c8:      	orr	w23, w8, #0x1
     2cc:      	mov	w26, #0x1808            ; =6152
     2d0:      	umull	x21, w23, w26
     2d4:      	ldr	x27, [sp, #0xc0]
     2d8:      	umaddl	x22, w23, w26, x27
     2dc:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
     2e0:      	add	x0, x0, #0x740
     2e4:      	mov	x1, x22
     2e8:      	mov	w2, #0xc00              ; =3072
     2ec:      	bl	0x2ec <ltmp0+0x2ec>
     2f0:      	add	x21, x21, #0xc00
     2f4:      	ldr	s0, [x27, x21]
     2f8:      	str	q0, [sp, #0xb0]
     2fc:      	str	q0, [sp, #0x3340]
     300:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     304:      	add	x0, x0, #0xb20
     308:      	add	x1, x22, #0xc04
     30c:      	mov	w2, #0xc00              ; =3072
     310:      	bl	0x310 <ltmp0+0x310>
     314:      	mov	w8, #0x1804             ; =6148
     318:      	umaddl	x8, w23, w26, x8
     31c:      	str	x8, [sp, #0xa8]
     320:      	ldr	s0, [x27, x8]
     324:      	str	q0, [sp, #0x90]
     328:      	str	q0, [sp, #0x2720]
     32c:      	mov	w24, #0xc04             ; =3076
     330:      	umull	x22, w23, w24
     334:      	ldr	x25, [sp, #0xe0]
     338:      	umaddl	x1, w23, w24, x25
     33c:      	add	x0, sp, #0xf00
     340:      	mov	w2, #0xc00              ; =3072
     344:      	bl	0x344 <ltmp0+0x344>
     348:      	add	x22, x22, #0xc00
     34c:      	ldr	s0, [x25, x22]
     350:      	str	q0, [sp, #0x50]
     354:      	str	q0, [sp, #0x1b00]
     358:      	ldr	x25, [sp, #0xf0]
     35c:      	umaddl	x1, w23, w24, x25
     360:      	ldr	x24, [sp, #0x100]
     364:      	add	x0, sp, #0x2e0
     368:      	mov	w2, #0xc00              ; =3072
     36c:      	bl	0x36c <ltmp0+0x36c>
     370:      	add	x11, sp, #0x2, lsl #12  ; =0x2000
     374:      	add	x11, x11, #0x740
     378:      	mov	x9, #0x0                ; =0
     37c:      	ldr	s0, [x25, x22]
     380:      	str	q0, [sp, #0xee0]
     384:      	umaddl	x8, w23, w26, x24
     388:      	add	x10, x11, x9
     38c:      	ldp	q1, q2, [x10]
     390:      	add	x10, x28, x9
     394:      	ldp	q3, q4, [x10]
     398:      	fmul.4s	v2, v2, v4
     39c:      	fmul.4s	v1, v1, v3
     3a0:      	add	x10, x19, x9
     3a4:      	ldp	q3, q4, [x10]
     3a8:      	add	x10, x20, x9
     3ac:      	ldp	q5, q6, [x10]
     3b0:      	fmul.4s	v4, v4, v6
     3b4:      	fmul.4s	v3, v3, v5
     3b8:      	fsub.4s	v1, v1, v3
     3bc:      	fsub.4s	v2, v2, v4
     3c0:      	add	x10, x8, x9
     3c4:      	stp	q1, q2, [x10]
     3c8:      	add	x9, x9, #0x20
     3cc:      	cmp	x9, #0xc00
     3d0:      	b.ne	0x388 <ltmp0+0x388>
     3d4:      	mov	x9, #0x0                ; =0
     3d8:      	ldr	q7, [sp, #0xb0]
     3dc:      	ldr	q17, [sp, #0x50]
     3e0:      	fmul.4s	v1, v7, v17
     3e4:      	ldr	q16, [sp, #0x90]
     3e8:      	fmul.4s	v2, v16, v0
     3ec:      	fsub.4s	v1, v1, v2
     3f0:      	str	s1, [x24, x21]
     3f4:      	add	x8, x8, #0xc04
     3f8:      	add	x10, x11, x9
     3fc:      	ldp	q1, q2, [x10]
     400:      	add	x10, x20, x9
     404:      	ldp	q3, q4, [x10]
     408:      	fmul.4s	v2, v2, v4
     40c:      	fmul.4s	v1, v1, v3
     410:      	add	x10, x19, x9
     414:      	ldp	q3, q4, [x10]
     418:      	add	x10, x28, x9
     41c:      	ldp	q5, q6, [x10]
     420:      	fmul.4s	v4, v4, v6
     424:      	fmul.4s	v3, v3, v5
     428:      	fadd.4s	v1, v1, v3
     42c:      	fadd.4s	v2, v2, v4
     430:      	add	x10, x8, x9
     434:      	stp	q1, q2, [x10]
     438:      	add	x9, x9, #0x20
     43c:      	cmp	x9, #0xc00
     440:      	b.ne	0x3f8 <ltmp0+0x3f8>
     444:      	fmul.4s	v0, v7, v0
     448:      	fmul.4s	v1, v16, v17
     44c:      	fadd.4s	v0, v1, v0
     450:      	ldr	x8, [sp, #0xa8]
     454:      	str	s0, [x24, x8]
     458:      	ldr	w8, [sp, #0xd0]
     45c:      	orr	w23, w8, #0x2
     460:      	mov	w26, #0x1808            ; =6152
     464:      	umull	x21, w23, w26
     468:      	umaddl	x22, w23, w26, x27
     46c:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
     470:      	add	x0, x0, #0x740
     474:      	mov	x1, x22
     478:      	mov	w2, #0xc00              ; =3072
     47c:      	bl	0x47c <ltmp0+0x47c>
     480:      	add	x21, x21, #0xc00
     484:      	ldr	s0, [x27, x21]
     488:      	str	q0, [sp, #0xb0]
     48c:      	str	q0, [sp, #0x3340]
     490:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     494:      	add	x0, x0, #0xb20
     498:      	add	x1, x22, #0xc04
     49c:      	mov	w2, #0xc00              ; =3072
     4a0:      	bl	0x4a0 <ltmp0+0x4a0>
     4a4:      	mov	w8, #0x1804             ; =6148
     4a8:      	umaddl	x8, w23, w26, x8
     4ac:      	str	x8, [sp, #0xa8]
     4b0:      	ldr	s0, [x27, x8]
     4b4:      	str	q0, [sp, #0x90]
     4b8:      	str	q0, [sp, #0x2720]
     4bc:      	mov	w24, #0xc04             ; =3076
     4c0:      	umull	x22, w23, w24
     4c4:      	ldr	x25, [sp, #0xe0]
     4c8:      	umaddl	x1, w23, w24, x25
     4cc:      	add	x0, sp, #0xf00
     4d0:      	mov	w2, #0xc00              ; =3072
     4d4:      	bl	0x4d4 <ltmp0+0x4d4>
     4d8:      	add	x22, x22, #0xc00
     4dc:      	ldr	s0, [x25, x22]
     4e0:      	str	q0, [sp, #0x50]
     4e4:      	str	q0, [sp, #0x1b00]
     4e8:      	ldr	x25, [sp, #0xf0]
     4ec:      	umaddl	x1, w23, w24, x25
     4f0:      	ldr	x24, [sp, #0x100]
     4f4:      	add	x0, sp, #0x2e0
     4f8:      	mov	w2, #0xc00              ; =3072
     4fc:      	bl	0x4fc <ltmp0+0x4fc>
     500:      	add	x11, sp, #0x2, lsl #12  ; =0x2000
     504:      	add	x11, x11, #0x740
     508:      	mov	x9, #0x0                ; =0
     50c:      	ldr	s0, [x25, x22]
     510:      	str	q0, [sp, #0xee0]
     514:      	umaddl	x8, w23, w26, x24
     518:      	add	x10, x11, x9
     51c:      	ldp	q1, q2, [x10]
     520:      	add	x10, x28, x9
     524:      	ldp	q3, q4, [x10]
     528:      	fmul.4s	v2, v2, v4
     52c:      	fmul.4s	v1, v1, v3
     530:      	add	x10, x19, x9
     534:      	ldp	q3, q4, [x10]
     538:      	add	x10, x20, x9
     53c:      	ldp	q5, q6, [x10]
     540:      	fmul.4s	v4, v4, v6
     544:      	fmul.4s	v3, v3, v5
     548:      	fsub.4s	v1, v1, v3
     54c:      	fsub.4s	v2, v2, v4
     550:      	add	x10, x8, x9
     554:      	stp	q1, q2, [x10]
     558:      	add	x9, x9, #0x20
     55c:      	cmp	x9, #0xc00
     560:      	b.ne	0x518 <ltmp0+0x518>
     564:      	mov	x9, #0x0                ; =0
     568:      	ldr	q7, [sp, #0xb0]
     56c:      	ldr	q17, [sp, #0x50]
     570:      	fmul.4s	v1, v7, v17
     574:      	ldr	q16, [sp, #0x90]
     578:      	fmul.4s	v2, v16, v0
     57c:      	fsub.4s	v1, v1, v2
     580:      	str	s1, [x24, x21]
     584:      	add	x8, x8, #0xc04
     588:      	add	x10, x11, x9
     58c:      	ldp	q1, q2, [x10]
     590:      	add	x10, x20, x9
     594:      	ldp	q3, q4, [x10]
     598:      	fmul.4s	v2, v2, v4
     59c:      	fmul.4s	v1, v1, v3
     5a0:      	add	x10, x19, x9
     5a4:      	ldp	q3, q4, [x10]
     5a8:      	add	x10, x28, x9
     5ac:      	ldp	q5, q6, [x10]
     5b0:      	fmul.4s	v4, v4, v6
     5b4:      	fmul.4s	v3, v3, v5
     5b8:      	fadd.4s	v1, v1, v3
     5bc:      	fadd.4s	v2, v2, v4
     5c0:      	add	x10, x8, x9
     5c4:      	stp	q1, q2, [x10]
     5c8:      	add	x9, x9, #0x20
     5cc:      	cmp	x9, #0xc00
     5d0:      	b.ne	0x588 <ltmp0+0x588>
     5d4:      	fmul.4s	v0, v7, v0
     5d8:      	fmul.4s	v1, v16, v17
     5dc:      	fadd.4s	v0, v1, v0
     5e0:      	ldr	x8, [sp, #0xa8]
     5e4:      	str	s0, [x24, x8]
     5e8:      	ldr	w8, [sp, #0xd0]
     5ec:      	orr	w23, w8, #0x3
     5f0:      	mov	w26, #0x1808            ; =6152
     5f4:      	umull	x21, w23, w26
     5f8:      	umaddl	x22, w23, w26, x27
     5fc:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
     600:      	add	x0, x0, #0x740
     604:      	mov	x1, x22
     608:      	mov	w2, #0xc00              ; =3072
     60c:      	bl	0x60c <ltmp0+0x60c>
     610:      	add	x21, x21, #0xc00
     614:      	ldr	s0, [x27, x21]
     618:      	str	q0, [sp, #0xd0]
     61c:      	str	q0, [sp, #0x3340]
     620:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     624:      	add	x0, x0, #0xb20
     628:      	add	x1, x22, #0xc04
     62c:      	mov	w2, #0xc00              ; =3072
     630:      	bl	0x630 <ltmp0+0x630>
     634:      	mov	w8, #0x1804             ; =6148
     638:      	umaddl	x22, w23, w26, x8
     63c:      	ldr	s0, [x27, x22]
     640:      	str	q0, [sp, #0xc0]
     644:      	str	q0, [sp, #0x2720]
     648:      	mov	w24, #0xc04             ; =3076
     64c:      	umull	x25, w23, w24
     650:      	ldr	x27, [sp, #0xe0]
     654:      	umaddl	x1, w23, w24, x27
     658:      	add	x0, sp, #0xf00
     65c:      	mov	w2, #0xc00              ; =3072
     660:      	bl	0x660 <ltmp0+0x660>
     664:      	add	x25, x25, #0xc00
     668:      	ldr	s0, [x27, x25]
     66c:      	str	q0, [sp, #0xe0]
     670:      	str	q0, [sp, #0x1b00]
     674:      	ldr	x27, [sp, #0xf0]
     678:      	umaddl	x1, w23, w24, x27
     67c:      	ldr	x24, [sp, #0x100]
     680:      	add	x0, sp, #0x2e0
     684:      	mov	w2, #0xc00              ; =3072
     688:      	bl	0x688 <ltmp0+0x688>
     68c:      	add	x4, sp, #0x2, lsl #12   ; =0x2000
     690:      	add	x4, x4, #0x740
     694:      	mov	x9, #0x0                ; =0
     698:      	ldr	s0, [x27, x25]
     69c:      	str	q0, [sp, #0xee0]
     6a0:      	umaddl	x8, w23, w26, x24
     6a4:      	add	x10, x4, x9
     6a8:      	ldp	q1, q2, [x10]
     6ac:      	add	x10, x28, x9
     6b0:      	ldp	q3, q4, [x10]
     6b4:      	fmul.4s	v2, v2, v4
     6b8:      	fmul.4s	v1, v1, v3
     6bc:      	add	x10, x19, x9
     6c0:      	ldp	q3, q4, [x10]
     6c4:      	add	x10, x20, x9
     6c8:      	ldp	q5, q6, [x10]
     6cc:      	fmul.4s	v4, v4, v6
     6d0:      	fmul.4s	v3, v3, v5
     6d4:      	fsub.4s	v1, v1, v3
     6d8:      	fsub.4s	v2, v2, v4
     6dc:      	add	x10, x8, x9
     6e0:      	stp	q1, q2, [x10]
     6e4:      	add	x9, x9, #0x20
     6e8:      	cmp	x9, #0xc00
     6ec:      	b.ne	0x6a4 <ltmp0+0x6a4>
     6f0:      	mov	x9, #0x0                ; =0
     6f4:      	ldp	q7, q17, [sp, #0xd0]
     6f8:      	fmul.4s	v1, v7, v17
     6fc:      	ldr	q16, [sp, #0xc0]
     700:      	fmul.4s	v2, v16, v0
     704:      	fsub.4s	v1, v1, v2
     708:      	str	s1, [x24, x21]
     70c:      	add	x8, x8, #0xc04
     710:      	ldr	w7, [sp, #0x84]
     714:      	ldp	w3, w5, [sp, #0x78]
     718:      	ldr	x6, [sp, #0x88]
     71c:      	add	x10, x4, x9
     720:      	ldp	q1, q2, [x10]
     724:      	add	x10, x20, x9
     728:      	ldp	q3, q4, [x10]
     72c:      	fmul.4s	v2, v2, v4
     730:      	fmul.4s	v1, v1, v3
     734:      	add	x10, x19, x9
     738:      	ldp	q3, q4, [x10]
     73c:      	add	x10, x28, x9
     740:      	ldp	q5, q6, [x10]
     744:      	fmul.4s	v4, v4, v6
     748:      	fmul.4s	v3, v3, v5
     74c:      	fadd.4s	v1, v1, v3
     750:      	fadd.4s	v2, v2, v4
     754:      	add	x10, x8, x9
     758:      	stp	q1, q2, [x10]
     75c:      	add	x9, x9, #0x20
     760:      	cmp	x9, #0xc00
     764:      	b.ne	0x71c <ltmp0+0x71c>
     768:      	fmul.4s	v0, v7, v0
     76c:      	fmul.4s	v1, v16, v17
     770:      	fadd.4s	v0, v1, v0
     774:      	str	s0, [x24, x22]
     778:      	b	0x98 <ltmp0+0x98>
     77c:      	lsr	x8, x9, #3
     780:      	str	x8, [sp, #0xd0]
     784:      	str	x9, [sp, #0x50]
     788:      	cmp	x9, #0x8
     78c:      	mov	w26, #0x1808            ; =6152
     790:      	b.lo	0x974 <ltmp0+0x974>
     794:      	mov	x24, #0x0               ; =0
     798:      	ldr	x8, [sp, #0x48]
     79c:      	ldr	x10, [x8]
     7a0:      	ldr	x9, [x8, #0x10]
     7a4:      	str	x9, [sp, #0xc0]
     7a8:      	ldr	x9, [x8, #0x20]
     7ac:      	stp	x10, x9, [sp, #0xa8]
     7b0:      	ldr	x25, [x8, #0x30]
     7b4:      	ldr	x8, [sp, #0x88]
     7b8:      	lsl	w9, w8, #2
     7bc:      	str	x9, [sp, #0x90]
     7c0:      	and	x8, x8, #0x7ffffff
     7c4:      	mov	w9, #0x6020             ; =24608
     7c8:      	umaddl	x27, w8, w9, x25
     7cc:      	ldr	x8, [sp, #0x90]
     7d0:      	add	w8, w24, w8
     7d4:      	and	x21, x8, #0x1fffffff
     7d8:      	umull	x23, w21, w26
     7dc:      	ldr	x19, [sp, #0xa8]
     7e0:      	umaddl	x22, w21, w26, x19
     7e4:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
     7e8:      	add	x0, x0, #0x740
     7ec:      	mov	x1, x22
     7f0:      	mov	w2, #0xc00              ; =3072
     7f4:      	bl	0x7f4 <ltmp0+0x7f4>
     7f8:      	add	x23, x23, #0xc00
     7fc:      	ldr	s0, [x19, x23]
     800:      	str	q0, [sp, #0x100]
     804:      	str	q0, [sp, #0x3340]
     808:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     80c:      	add	x0, x0, #0xb20
     810:      	add	x1, x22, #0xc04
     814:      	mov	w2, #0xc00              ; =3072
     818:      	bl	0x818 <ltmp0+0x818>
     81c:      	mov	w8, #0x1804             ; =6148
     820:      	umaddl	x22, w21, w26, x8
     824:      	ldr	s0, [x19, x22]
     828:      	str	q0, [sp, #0xf0]
     82c:      	str	q0, [sp, #0x2720]
     830:      	mov	w19, #0xc04             ; =3076
     834:      	umull	x26, w21, w19
     838:      	ldr	x28, [sp, #0xc0]
     83c:      	umaddl	x1, w21, w19, x28
     840:      	add	x0, sp, #0xf00
     844:      	mov	w2, #0xc00              ; =3072
     848:      	bl	0x848 <ltmp0+0x848>
     84c:      	add	x26, x26, #0xc00
     850:      	ldr	s0, [x28, x26]
     854:      	add	x28, sp, #0xf00
     858:      	str	q0, [sp, #0xe0]
     85c:      	str	q0, [sp, #0x1b00]
     860:      	ldr	x20, [sp, #0xb0]
     864:      	umaddl	x1, w21, w19, x20
     868:      	add	x19, sp, #0x1, lsl #12  ; =0x1000
     86c:      	add	x19, x19, #0xb20
     870:      	add	x0, sp, #0x2e0
     874:      	mov	w2, #0xc00              ; =3072
     878:      	bl	0x878 <ltmp0+0x878>
     87c:      	add	x4, sp, #0x2, lsl #12   ; =0x2000
     880:      	add	x4, x4, #0x740
     884:      	mov	x8, #0x0                ; =0
     888:      	ldr	s0, [x20, x26]
     88c:      	add	x20, sp, #0x2e0
     890:      	str	q0, [sp, #0xee0]
     894:      	add	x9, x4, x8
     898:      	ldp	q1, q2, [x9]
     89c:      	add	x9, x28, x8
     8a0:      	ldp	q3, q4, [x9]
     8a4:      	fmul.4s	v2, v2, v4
     8a8:      	fmul.4s	v1, v1, v3
     8ac:      	add	x9, x19, x8
     8b0:      	ldp	q3, q4, [x9]
     8b4:      	add	x9, x20, x8
     8b8:      	ldp	q5, q6, [x9]
     8bc:      	fmul.4s	v4, v4, v6
     8c0:      	fmul.4s	v3, v3, v5
     8c4:      	fsub.4s	v1, v1, v3
     8c8:      	fsub.4s	v2, v2, v4
     8cc:      	add	x9, x27, x8
     8d0:      	stp	q1, q2, [x9]
     8d4:      	add	x8, x8, #0x20
     8d8:      	cmp	x8, #0xc00
     8dc:      	b.ne	0x894 <ltmp0+0x894>
     8e0:      	mov	x8, #0x0                ; =0
     8e4:      	ldp	q16, q7, [sp, #0xf0]
     8e8:      	ldr	q17, [sp, #0xe0]
     8ec:      	fmul.4s	v1, v7, v17
     8f0:      	fmul.4s	v2, v16, v0
     8f4:      	fsub.4s	v1, v1, v2
     8f8:      	str	s1, [x25, x23]
     8fc:      	add	x9, x4, x8
     900:      	ldp	q1, q2, [x9]
     904:      	add	x9, x20, x8
     908:      	ldp	q3, q4, [x9]
     90c:      	fmul.4s	v2, v2, v4
     910:      	fmul.4s	v1, v1, v3
     914:      	add	x9, x19, x8
     918:      	ldp	q3, q4, [x9]
     91c:      	add	x9, x28, x8
     920:      	ldp	q5, q6, [x9]
     924:      	fmul.4s	v4, v4, v6
     928:      	fmul.4s	v3, v3, v5
     92c:      	fadd.4s	v1, v1, v3
     930:      	fadd.4s	v2, v2, v4
     934:      	add	x9, x27, x8
     938:      	add	x9, x9, #0xc04
     93c:      	stp	q1, q2, [x9]
     940:      	add	x8, x8, #0x20
     944:      	cmp	x8, #0xc00
     948:      	b.ne	0x8fc <ltmp0+0x8fc>
     94c:      	fmul.4s	v0, v7, v0
     950:      	fmul.4s	v1, v16, v17
     954:      	fadd.4s	v0, v1, v0
     958:      	str	s0, [x25, x22]
     95c:      	add	x24, x24, #0x1
     960:      	mov	w26, #0x1808            ; =6152
     964:      	add	x27, x27, x26
     968:      	ldr	x8, [sp, #0xd0]
     96c:      	cmp	x24, x8
     970:      	b.ne	0x7cc <ltmp0+0x7cc>
     974:      	mov	w12, #0x1808            ; =6152
     978:      	ldr	x8, [sp, #0x50]
     97c:      	and	w8, w8, #0x7
     980:      	ldp	w3, w5, [sp, #0x78]
     984:      	ldr	w7, [sp, #0x84]
     988:      	ldr	x6, [sp, #0x88]
     98c:      	cbz	w8, 0x98 <ltmp0+0x98>
     990:      	dup.4s	v1, w8
     994:      	ldp	q0, q2, [sp, #0x20]
     998:      	cmhi.4s	v0, v1, v0
     99c:      	cmhi.4s	v1, v1, v2
     9a0:      	uzp1.8h	v2, v1, v0
     9a4:      	umaxv.8h	h3, v2
     9a8:      	fmov	w8, s3
     9ac:      	tbz	w8, #0x0, 0x98 <ltmp0+0x98>
     9b0:      	mov	x9, #0x0                ; =0
     9b4:      	ldr	x11, [sp, #0x48]
     9b8:      	ldr	x15, [x11]
     9bc:      	ldr	x13, [x11, #0x10]
     9c0:      	ldr	x10, [x11, #0x20]
     9c4:      	ubfiz	w8, w6, #2, #27
     9c8:      	ldr	x14, [sp, #0xd0]
     9cc:      	orr	w8, w8, w14
     9d0:      	dup.4s	v3, w8
     9d4:      	ldr	x8, [x11, #0x30]
     9d8:      	and.16b	v5, v1, v3
     9dc:      	and.16b	v3, v0, v3
     9e0:      	ushll2.2d	v4, v3, #0x0
     9e4:      	ushll2.2d	v6, v5, #0x0
     9e8:      	ushll.2d	v7, v3, #0x0
     9ec:      	ushll.2d	v5, v5, #0x0
     9f0:      	fmov	x14, d5
     9f4:      	umaddl	x11, w14, w12, x15
     9f8:      	ldr	q3, [sp, #0x10]
     9fc:      	and.16b	v2, v2, v3
     a00:      	addv.8h	h2, v2
     a04:      	fmov	w12, s2
     a08:      	b	0xa2c <ltmp0+0xa2c>
     a0c:      	add	x16, x4, x9
     a10:      	ldp	q17, q18, [x16]
     a14:      	bif.16b	v16, v18, v0
     a18:      	bif.16b	v3, v17, v1
     a1c:      	stp	q3, q16, [x16]
     a20:      	add	x9, x9, #0x20
     a24:      	cmp	x9, #0xc00
     a28:      	b.eq	0xac0 <ltmp0+0xac0>
     a2c:      	add	x16, x11, x9
     a30:      	movi.2d	v3, #0000000000000000
     a34:      	movi.2d	v16, #0000000000000000
     a38:      	tbnz	w12, #0x0, 0xa60 <ltmp0+0xa60>
     a3c:      	and	w17, w12, #0xff
     a40:      	tbnz	w17, #0x1, 0xa6c <ltmp0+0xa6c>
     a44:      	tbnz	w17, #0x2, 0xa78 <ltmp0+0xa78>
     a48:      	tbnz	w17, #0x3, 0xa84 <ltmp0+0xa84>
     a4c:      	tbnz	w17, #0x4, 0xa90 <ltmp0+0xa90>
     a50:      	tbnz	w17, #0x5, 0xa9c <ltmp0+0xa9c>
     a54:      	tbnz	w17, #0x6, 0xaa8 <ltmp0+0xaa8>
     a58:      	tbz	w17, #0x7, 0xa0c <ltmp0+0xa0c>
     a5c:      	b	0xab4 <ltmp0+0xab4>
     a60:      	ldr	s3, [x16]
     a64:      	and	w17, w12, #0xff
     a68:      	tbz	w17, #0x1, 0xa44 <ltmp0+0xa44>
     a6c:      	add	x0, x16, #0x4
     a70:      	ld1.s	{ v3 }[1], [x0]
     a74:      	tbz	w17, #0x2, 0xa48 <ltmp0+0xa48>
     a78:      	add	x0, x16, #0x8
     a7c:      	ld1.s	{ v3 }[2], [x0]
     a80:      	tbz	w17, #0x3, 0xa4c <ltmp0+0xa4c>
     a84:      	add	x0, x16, #0xc
     a88:      	ld1.s	{ v3 }[3], [x0]
     a8c:      	tbz	w17, #0x4, 0xa50 <ltmp0+0xa50>
     a90:      	add	x0, x16, #0x10
     a94:      	ld1.s	{ v16 }[0], [x0]
     a98:      	tbz	w17, #0x5, 0xa54 <ltmp0+0xa54>
     a9c:      	add	x0, x16, #0x14
     aa0:      	ld1.s	{ v16 }[1], [x0]
     aa4:      	tbz	w17, #0x6, 0xa58 <ltmp0+0xa58>
     aa8:      	add	x0, x16, #0x18
     aac:      	ld1.s	{ v16 }[2], [x0]
     ab0:      	tbz	w17, #0x7, 0xa0c <ltmp0+0xa0c>
     ab4:      	add	x16, x16, #0x1c
     ab8:      	ld1.s	{ v16 }[3], [x16]
     abc:      	b	0xa0c <ltmp0+0xa0c>
     ac0:      	xtn.4h	v3, v1
     ac4:      	uzp1.8b	v16, v3, v0
     ac8:      	ushll.2d	v3, v1, #0x0
     acc:      	adrp	x9, 0x0 <ltmp0>
     ad0:      	ldr	q17, [x9]
     ad4:      	and.16b	v22, v3, v17
     ad8:      	movi.2d	v3, #0000000000000000
     adc:      	mov.b	v3[0], v16[0]
     ae0:      	adrp	x9, 0x0 <ltmp0>
     ae4:      	ldr	d17, [x9]
     ae8:      	str	d17, [sp, #0xa8]
     aec:      	and.8b	v17, v3, v17
     af0:      	addv.8b	b17, v17
     af4:      	fmov	w11, s17
     af8:      	umaxv.8b	b17, v3
     afc:      	fmov	w16, s17
     b00:      	rbit	w9, w11
     b04:      	clz	w9, w9
     b08:      	tst	w16, #0x1
     b0c:      	csel	w9, w9, wzr, ne
     b10:      	mov	w12, #0x300             ; =768
     b14:      	dup.2d	v19, x12
     b18:      	orr.16b	v17, v22, v19
     b1c:      	mov	w12, #0x602             ; =1538
     b20:      	dup.2s	v18, w12
     b24:      	xtn.2s	v26, v5
     b28:      	str	q17, [sp, #0xb0]
     b2c:      	mov.16b	v5, v17
     b30:      	umlal.2d	v5, v26, v18
     b34:      	movi.2d	v17, #0000000000000000
     b38:      	mov.b	v17[0], v16[0]
     b3c:      	ushll.2d	v16, v17, #0x0
     b40:      	shl.2d	v16, v16, #0x3f
     b44:      	cmlt.2d	v16, v16, #0
     b48:      	str	q5, [sp, #0x100]
     b4c:      	and.16b	v16, v16, v5
     b50:      	movi.2d	v5, #0000000000000000
     b54:      	stp	q5, q5, [sp, #0x2b0]
     b58:      	stp	q16, q5, [sp, #0x290]
     b5c:      	and	x12, x9, #0x7
     b60:      	add	x17, sp, #0x290
     b64:      	ldr	x12, [x17, x12, lsl #3]
     b68:      	sub	x12, x12, x9
     b6c:      	add	x12, x15, x12, lsl #2
     b70:      	movi.2d	v16, #0000000000000000
     b74:      	movi.2d	v17, #0000000000000000
     b78:      	tbnz	w16, #0x0, 0x15c8 <ltmp0+0x15c8>
     b7c:      	tbnz	w11, #0x1, 0x15d0 <ltmp0+0x15d0>
     b80:      	tbnz	w11, #0x2, 0x15dc <ltmp0+0x15dc>
     b84:      	tbnz	w11, #0x3, 0x15e8 <ltmp0+0x15e8>
     b88:      	tbnz	w11, #0x4, 0x15f4 <ltmp0+0x15f4>
     b8c:      	tbnz	w11, #0x5, 0x1600 <ltmp0+0x1600>
     b90:      	tbnz	w11, #0x6, 0x160c <ltmp0+0x160c>
     b94:      	tbz	w11, #0x7, 0xba0 <ltmp0+0xba0>
     b98:      	add	x12, x12, #0x1c
     b9c:      	ld1.s	{ v17 }[3], [x12]
     ba0:      	mov	x17, #0x0               ; =0
     ba4:      	sshll.2d	v20, v0, #0x0
     ba8:      	sshll2.2d	v21, v1, #0x0
     bac:      	sshll2.2d	v15, v0, #0x0
     bb0:      	adrp	x12, 0x0 <ltmp0>
     bb4:      	ldr	q23, [x12]
     bb8:      	and.16b	v23, v15, v23
     bbc:      	adrp	x12, 0x0 <ltmp0>
     bc0:      	ldr	q24, [x12]
     bc4:      	and.16b	v24, v21, v24
     bc8:      	adrp	x12, 0x0 <ltmp0>
     bcc:      	ldr	q25, [x12]
     bd0:      	and.16b	v25, v20, v25
     bd4:      	orr.16b	v8, v25, v19
     bd8:      	orr.16b	v9, v24, v19
     bdc:      	orr.16b	v31, v23, v19
     be0:      	str	d26, [sp, #0xc0]
     be4:      	umull.2d	v27, v26, v18
     be8:      	xtn.2s	v10, v6
     bec:      	umull.2d	v28, v10, v18
     bf0:      	xtn.2s	v11, v7
     bf4:      	umull.2d	v13, v11, v18
     bf8:      	xtn.2s	v12, v4
     bfc:      	umull.2d	v14, v12, v18
     c00:      	mov.16b	v4, v31
     c04:      	umlal.2d	v4, v12, v18
     c08:      	str	q4, [sp, #0xf0]
     c0c:      	mov.16b	v4, v9
     c10:      	umlal.2d	v4, v10, v18
     c14:      	str	q4, [sp, #0xe0]
     c18:      	mov.16b	v4, v8
     c1c:      	umlal.2d	v4, v11, v18
     c20:      	str	q4, [sp, #0xd0]
     c24:      	adrp	x12, 0x0 <ltmp0>
     c28:      	ldr	q4, [x12]
     c2c:      	mov	w12, #0xc00             ; =3072
     c30:      	dup.2d	v6, x12
     c34:      	sshll.2d	v7, v1, #0x0
     c38:      	bif.16b	v4, v6, v7
     c3c:      	adrp	x12, 0x0 <ltmp0>
     c40:      	ldr	q7, [x12]
     c44:      	sshll.2d	v18, v0, #0x0
     c48:      	bif.16b	v7, v6, v18
     c4c:      	adrp	x12, 0x0 <ltmp0>
     c50:      	ldr	q18, [x12]
     c54:      	bif.16b	v18, v6, v21
     c58:      	adrp	x12, 0x0 <ltmp0>
     c5c:      	ldr	q19, [x12]
     c60:      	bit.16b	v6, v19, v15
     c64:      	stp	q7, q6, [sp, #0x270]
     c68:      	stp	q4, q18, [sp, #0x250]
     c6c:      	and	x12, x9, #0x7
     c70:      	add	x16, sp, #0x250
     c74:      	ldr	x12, [x16, x12, lsl #3]
     c78:      	sub	x12, x12, x9, lsl #2
     c7c:      	tst	w11, #0xff
     c80:      	csel	x11, xzr, x12, eq
     c84:      	add	x12, x4, x11
     c88:      	ldp	q4, q6, [x12]
     c8c:      	zip2.8b	v7, v3, v0
     c90:      	ushll.4s	v7, v7, #0x0
     c94:      	shl.4s	v7, v7, #0x1f
     c98:      	cmlt.4s	v7, v7, #0
     c9c:      	mov.16b	v5, v7
     ca0:      	bsl.16b	v5, v17, v6
     ca4:      	zip1.8b	v6, v3, v0
     ca8:      	ushll.4s	v6, v6, #0x0
     cac:      	shl.4s	v6, v6, #0x1f
     cb0:      	cmlt.4s	v6, v6, #0
     cb4:      	bit.16b	v4, v16, v6
     cb8:      	mov.16b	v30, v4
     cbc:      	stp	q4, q5, [x12]
     cc0:      	mov.16b	v26, v5
     cc4:      	fmov	x12, d27
     cc8:      	ushll2.2d	v4, v0, #0x0
     ccc:      	mov	w16, #0x1               ; =1
     cd0:      	dup.2d	v6, x16
     cd4:      	and.16b	v7, v4, v6
     cd8:      	ushll2.2d	v4, v1, #0x0
     cdc:      	and.16b	v16, v4, v6
     ce0:      	ushll.2d	v4, v0, #0x0
     ce4:      	and.16b	v17, v4, v6
     ce8:      	ushll.2d	v4, v1, #0x0
     cec:      	and.16b	v18, v4, v6
     cf0:      	lsl	x12, x12, #2
     cf4:      	add	x16, x15, x12
     cf8:      	add	x16, x16, #0xc04
     cfc:      	movi.2d	v15, #0000000000000000
     d00:      	movi.2d	v4, #0000000000000000
     d04:      	movi.2d	v6, #0000000000000000
     d08:      	movi.2d	v19, #0000000000000000
     d0c:      	b	0xd40 <ltmp0+0xd40>
     d10:      	add	x17, x19, x17
     d14:      	ldp	q5, q29, [x17]
     d18:      	bif.16b	v21, v29, v0
     d1c:      	bit.16b	v5, v20, v1
     d20:      	stp	q5, q21, [x17]
     d24:      	add.2d	v4, v4, v16
     d28:      	add.2d	v6, v6, v17
     d2c:      	add.2d	v19, v19, v7
     d30:      	add.2d	v15, v15, v18
     d34:      	fmov	x17, d15
     d38:      	cmp	x17, #0x60
     d3c:      	b.ge	0xddc <ltmp0+0xddc>
     d40:      	fmov	w1, s2
     d44:      	lsl	x17, x17, #5
     d48:      	add	x0, x16, x17
     d4c:      	movi.2d	v20, #0000000000000000
     d50:      	movi.2d	v21, #0000000000000000
     d54:      	tbnz	w1, #0x0, 0xd7c <ltmp0+0xd7c>
     d58:      	and	w1, w1, #0xff
     d5c:      	tbnz	w1, #0x1, 0xd88 <ltmp0+0xd88>
     d60:      	tbnz	w1, #0x2, 0xd94 <ltmp0+0xd94>
     d64:      	tbnz	w1, #0x3, 0xda0 <ltmp0+0xda0>
     d68:      	tbnz	w1, #0x4, 0xdac <ltmp0+0xdac>
     d6c:      	tbnz	w1, #0x5, 0xdb8 <ltmp0+0xdb8>
     d70:      	tbnz	w1, #0x6, 0xdc4 <ltmp0+0xdc4>
     d74:      	tbz	w1, #0x7, 0xd10 <ltmp0+0xd10>
     d78:      	b	0xdd0 <ltmp0+0xdd0>
     d7c:      	ldr	s20, [x0]
     d80:      	and	w1, w1, #0xff
     d84:      	tbz	w1, #0x1, 0xd60 <ltmp0+0xd60>
     d88:      	add	x2, x0, #0x4
     d8c:      	ld1.s	{ v20 }[1], [x2]
     d90:      	tbz	w1, #0x2, 0xd64 <ltmp0+0xd64>
     d94:      	add	x2, x0, #0x8
     d98:      	ld1.s	{ v20 }[2], [x2]
     d9c:      	tbz	w1, #0x3, 0xd68 <ltmp0+0xd68>
     da0:      	add	x2, x0, #0xc
     da4:      	ld1.s	{ v20 }[3], [x2]
     da8:      	tbz	w1, #0x4, 0xd6c <ltmp0+0xd6c>
     dac:      	add	x2, x0, #0x10
     db0:      	ld1.s	{ v21 }[0], [x2]
     db4:      	tbz	w1, #0x5, 0xd70 <ltmp0+0xd70>
     db8:      	add	x2, x0, #0x14
     dbc:      	ld1.s	{ v21 }[1], [x2]
     dc0:      	tbz	w1, #0x6, 0xd74 <ltmp0+0xd74>
     dc4:      	add	x2, x0, #0x18
     dc8:      	ld1.s	{ v21 }[2], [x2]
     dcc:      	tbz	w1, #0x7, 0xd10 <ltmp0+0xd10>
     dd0:      	add	x0, x0, #0x1c
     dd4:      	ld1.s	{ v21 }[3], [x0]
     dd8:      	b	0xd10 <ltmp0+0xd10>
     ddc:      	add.2d	v4, v22, v27
     de0:      	add.2d	v5, v24, v28
     de4:      	add.2d	v6, v25, v13
     de8:      	add.2d	v19, v23, v14
     dec:      	mov	w16, #0x601             ; =1537
     df0:      	dup.2d	v20, x16
     df4:      	add.2d	v22, v19, v20
     df8:      	add.2d	v23, v6, v20
     dfc:      	add.2d	v24, v5, v20
     e00:      	mov	b5, v3[0]
     e04:      	mov.b	v5[4], v3[1]
     e08:      	add.2d	v25, v4, v20
     e0c:      	ushll.2d	v4, v5, #0x0
     e10:      	shl.2d	v4, v4, #0x3f
     e14:      	cmlt.2d	v4, v4, #0
     e18:      	and.16b	v4, v4, v25
     e1c:      	mov	b5, v3[2]
     e20:      	mov.b	v5[4], v3[3]
     e24:      	ushll.2d	v5, v5, #0x0
     e28:      	shl.2d	v5, v5, #0x3f
     e2c:      	cmlt.2d	v5, v5, #0
     e30:      	and.16b	v5, v5, v24
     e34:      	mov	b6, v3[4]
     e38:      	mov.b	v6[4], v3[5]
     e3c:      	ushll.2d	v6, v6, #0x0
     e40:      	shl.2d	v6, v6, #0x3f
     e44:      	cmlt.2d	v6, v6, #0
     e48:      	and.16b	v6, v6, v23
     e4c:      	mov	b19, v3[6]
     e50:      	mov.b	v19[4], v3[7]
     e54:      	ushll.2d	v19, v19, #0x0
     e58:      	shl.2d	v19, v19, #0x3f
     e5c:      	cmlt.2d	v19, v19, #0
     e60:      	and.16b	v19, v19, v22
     e64:      	shl.8b	v20, v3, #0x7
     e68:      	cmlt.8b	v20, v20, #0
     e6c:      	ldr	d21, [sp, #0xa8]
     e70:      	and.8b	v20, v20, v21
     e74:      	addv.8b	b15, v20
     e78:      	fmov	w16, s15
     e7c:      	stp	q6, q19, [sp, #0x220]
     e80:      	stp	q4, q5, [sp, #0x200]
     e84:      	and	x17, x9, #0x7
     e88:      	add	x0, sp, #0x200
     e8c:      	ldr	x17, [x0, x17, lsl #3]
     e90:      	sub	x17, x17, x9
     e94:      	add	x15, x15, x17, lsl #2
     e98:      	movi.2d	v4, #0000000000000000
     e9c:      	movi.2d	v6, #0000000000000000
     ea0:      	tbnz	w16, #0x0, 0x161c <ltmp0+0x161c>
     ea4:      	mov.16b	v14, v26
     ea8:      	tbnz	w16, #0x1, 0x1628 <ltmp0+0x1628>
     eac:      	mov.16b	v26, v30
     eb0:      	ldr	d30, [sp, #0xc0]
     eb4:      	tbnz	w16, #0x2, 0x163c <ltmp0+0x163c>
     eb8:      	tbnz	w16, #0x3, 0x1648 <ltmp0+0x1648>
     ebc:      	tbnz	w16, #0x4, 0x1654 <ltmp0+0x1654>
     ec0:      	tbnz	w16, #0x5, 0x1660 <ltmp0+0x1660>
     ec4:      	tbnz	w16, #0x6, 0x166c <ltmp0+0x166c>
     ec8:      	tbz	w16, #0x7, 0xed4 <ltmp0+0xed4>
     ecc:      	add	x15, x15, #0x1c
     ed0:      	ld1.s	{ v6 }[3], [x15]
     ed4:      	mov	x15, #0x0               ; =0
     ed8:      	add	x16, x19, x11
     edc:      	ldp	q5, q19, [x16]
     ee0:      	zip2.8b	v20, v3, v0
     ee4:      	ushll.4s	v20, v20, #0x0
     ee8:      	shl.4s	v20, v20, #0x1f
     eec:      	cmlt.4s	v20, v20, #0
     ef0:      	mov.16b	v27, v20
     ef4:      	bsl.16b	v27, v6, v19
     ef8:      	zip1.8b	v6, v3, v0
     efc:      	ushll.4s	v6, v6, #0x0
     f00:      	shl.4s	v6, v6, #0x1f
     f04:      	cmlt.4s	v6, v6, #0
     f08:      	mov.16b	v28, v6
     f0c:      	bsl.16b	v28, v4, v5
     f10:      	stp	q28, q27, [x16]
     f14:      	mov	w16, #0xc04             ; =3076
     f18:      	umaddl	x14, w14, w16, x13
     f1c:      	movi.2d	v13, #0000000000000000
     f20:      	movi.2d	v4, #0000000000000000
     f24:      	movi.2d	v6, #0000000000000000
     f28:      	movi.2d	v19, #0000000000000000
     f2c:      	b	0xf60 <ltmp0+0xf60>
     f30:      	add	x15, x28, x15
     f34:      	ldp	q5, q29, [x15]
     f38:      	bif.16b	v21, v29, v0
     f3c:      	bit.16b	v5, v20, v1
     f40:      	stp	q5, q21, [x15]
     f44:      	add.2d	v4, v4, v16
     f48:      	add.2d	v6, v6, v17
     f4c:      	add.2d	v19, v19, v7
     f50:      	add.2d	v13, v13, v18
     f54:      	fmov	x15, d13
     f58:      	cmp	x15, #0x60
     f5c:      	b.ge	0xffc <ltmp0+0xffc>
     f60:      	fmov	w17, s2
     f64:      	lsl	x15, x15, #5
     f68:      	add	x16, x14, x15
     f6c:      	movi.2d	v20, #0000000000000000
     f70:      	movi.2d	v21, #0000000000000000
     f74:      	tbnz	w17, #0x0, 0xf9c <ltmp0+0xf9c>
     f78:      	and	w17, w17, #0xff
     f7c:      	tbnz	w17, #0x1, 0xfa8 <ltmp0+0xfa8>
     f80:      	tbnz	w17, #0x2, 0xfb4 <ltmp0+0xfb4>
     f84:      	tbnz	w17, #0x3, 0xfc0 <ltmp0+0xfc0>
     f88:      	tbnz	w17, #0x4, 0xfcc <ltmp0+0xfcc>
     f8c:      	tbnz	w17, #0x5, 0xfd8 <ltmp0+0xfd8>
     f90:      	tbnz	w17, #0x6, 0xfe4 <ltmp0+0xfe4>
     f94:      	tbz	w17, #0x7, 0xf30 <ltmp0+0xf30>
     f98:      	b	0xff0 <ltmp0+0xff0>
     f9c:      	ldr	s20, [x16]
     fa0:      	and	w17, w17, #0xff
     fa4:      	tbz	w17, #0x1, 0xf80 <ltmp0+0xf80>
     fa8:      	add	x0, x16, #0x4
     fac:      	ld1.s	{ v20 }[1], [x0]
     fb0:      	tbz	w17, #0x2, 0xf84 <ltmp0+0xf84>
     fb4:      	add	x0, x16, #0x8
     fb8:      	ld1.s	{ v20 }[2], [x0]
     fbc:      	tbz	w17, #0x3, 0xf88 <ltmp0+0xf88>
     fc0:      	add	x0, x16, #0xc
     fc4:      	ld1.s	{ v20 }[3], [x0]
     fc8:      	tbz	w17, #0x4, 0xf8c <ltmp0+0xf8c>
     fcc:      	add	x0, x16, #0x10
     fd0:      	ld1.s	{ v21 }[0], [x0]
     fd4:      	tbz	w17, #0x5, 0xf90 <ltmp0+0xf90>
     fd8:      	add	x0, x16, #0x14
     fdc:      	ld1.s	{ v21 }[1], [x0]
     fe0:      	tbz	w17, #0x6, 0xf94 <ltmp0+0xf94>
     fe4:      	add	x0, x16, #0x18
     fe8:      	ld1.s	{ v21 }[2], [x0]
     fec:      	tbz	w17, #0x7, 0xf30 <ltmp0+0xf30>
     ff0:      	add	x16, x16, #0x1c
     ff4:      	ld1.s	{ v21 }[3], [x16]
     ff8:      	b	0xf30 <ltmp0+0xf30>
     ffc:      	mov	w14, #0x301             ; =769
    1000:      	dup.2s	v13, w14
    1004:      	umlal.2d	v31, v12, v13
    1008:      	umlal.2d	v8, v11, v13
    100c:      	umlal.2d	v9, v10, v13
    1010:      	ldr	q5, [sp, #0xb0]
    1014:      	umlal.2d	v5, v30, v13
    1018:      	mov	b4, v3[0]
    101c:      	mov.b	v4[4], v3[1]
    1020:      	ushll.2d	v4, v4, #0x0
    1024:      	shl.2d	v4, v4, #0x3f
    1028:      	cmlt.2d	v4, v4, #0
    102c:      	and.16b	v4, v4, v5
    1030:      	mov	b5, v3[2]
    1034:      	mov.b	v5[4], v3[3]
    1038:      	ushll.2d	v5, v5, #0x0
    103c:      	shl.2d	v5, v5, #0x3f
    1040:      	cmlt.2d	v5, v5, #0
    1044:      	and.16b	v5, v5, v9
    1048:      	mov	b6, v3[4]
    104c:      	mov.b	v6[4], v3[5]
    1050:      	ushll.2d	v6, v6, #0x0
    1054:      	shl.2d	v6, v6, #0x3f
    1058:      	cmlt.2d	v6, v6, #0
    105c:      	mov	b19, v3[6]
    1060:      	mov.b	v19[4], v3[7]
    1064:      	and.16b	v6, v6, v8
    1068:      	ushll.2d	v19, v19, #0x0
    106c:      	shl.2d	v19, v19, #0x3f
    1070:      	cmlt.2d	v19, v19, #0
    1074:      	and.16b	v19, v19, v31
    1078:      	stp	q6, q19, [sp, #0x1d0]
    107c:      	stp	q4, q5, [sp, #0x1b0]
    1080:      	and	x14, x9, #0x7
    1084:      	add	x15, sp, #0x1b0
    1088:      	ldr	x14, [x15, x14, lsl #3]
    108c:      	fmov	w15, s15
    1090:      	sub	x14, x14, x9
    1094:      	lsl	x14, x14, #2
    1098:      	add	x13, x13, x14
    109c:      	movi.2d	v4, #0000000000000000
    10a0:      	movi.2d	v6, #0000000000000000
    10a4:      	tbnz	w15, #0x0, 0x167c <ltmp0+0x167c>
    10a8:      	tbnz	w15, #0x1, 0x1684 <ltmp0+0x1684>
    10ac:      	tbnz	w15, #0x2, 0x1690 <ltmp0+0x1690>
    10b0:      	tbnz	w15, #0x3, 0x169c <ltmp0+0x169c>
    10b4:      	tbnz	w15, #0x4, 0x16a8 <ltmp0+0x16a8>
    10b8:      	tbnz	w15, #0x5, 0x16b4 <ltmp0+0x16b4>
    10bc:      	tbnz	w15, #0x6, 0x16c0 <ltmp0+0x16c0>
    10c0:      	tbz	w15, #0x7, 0x10cc <ltmp0+0x10cc>
    10c4:      	add	x13, x13, #0x1c
    10c8:      	ld1.s	{ v6 }[3], [x13]
    10cc:      	mov	x15, #0x0               ; =0
    10d0:      	umull.2d	v5, v30, v13
    10d4:      	add	x13, x28, x11
    10d8:      	ldp	q19, q20, [x13]
    10dc:      	zip2.8b	v21, v3, v0
    10e0:      	ushll.4s	v21, v21, #0x0
    10e4:      	shl.4s	v21, v21, #0x1f
    10e8:      	cmlt.4s	v21, v21, #0
    10ec:      	mov.16b	v29, v21
    10f0:      	bsl.16b	v29, v6, v20
    10f4:      	zip1.8b	v6, v3, v0
    10f8:      	ushll.4s	v6, v6, #0x0
    10fc:      	shl.4s	v6, v6, #0x1f
    1100:      	cmlt.4s	v6, v6, #0
    1104:      	mov.16b	v30, v6
    1108:      	bsl.16b	v30, v4, v19
    110c:      	stp	q30, q29, [x13]
    1110:      	fmov	x13, d5
    1114:      	add	x13, x10, x13, lsl #2
    1118:      	movi.2d	v31, #0000000000000000
    111c:      	movi.2d	v4, #0000000000000000
    1120:      	movi.2d	v6, #0000000000000000
    1124:      	movi.2d	v19, #0000000000000000
    1128:      	b	0x115c <ltmp0+0x115c>
    112c:      	add	x15, x20, x15
    1130:      	ldp	q5, q8, [x15]
    1134:      	bif.16b	v21, v8, v0
    1138:      	bit.16b	v5, v20, v1
    113c:      	stp	q5, q21, [x15]
    1140:      	add.2d	v4, v4, v16
    1144:      	add.2d	v6, v6, v17
    1148:      	add.2d	v19, v19, v7
    114c:      	add.2d	v31, v31, v18
    1150:      	fmov	x15, d31
    1154:      	cmp	x15, #0x60
    1158:      	b.ge	0x11f8 <ltmp0+0x11f8>
    115c:      	fmov	w17, s2
    1160:      	lsl	x15, x15, #5
    1164:      	add	x16, x13, x15
    1168:      	movi.2d	v20, #0000000000000000
    116c:      	movi.2d	v21, #0000000000000000
    1170:      	tbnz	w17, #0x0, 0x1198 <ltmp0+0x1198>
    1174:      	and	w17, w17, #0xff
    1178:      	tbnz	w17, #0x1, 0x11a4 <ltmp0+0x11a4>
    117c:      	tbnz	w17, #0x2, 0x11b0 <ltmp0+0x11b0>
    1180:      	tbnz	w17, #0x3, 0x11bc <ltmp0+0x11bc>
    1184:      	tbnz	w17, #0x4, 0x11c8 <ltmp0+0x11c8>
    1188:      	tbnz	w17, #0x5, 0x11d4 <ltmp0+0x11d4>
    118c:      	tbnz	w17, #0x6, 0x11e0 <ltmp0+0x11e0>
    1190:      	tbz	w17, #0x7, 0x112c <ltmp0+0x112c>
    1194:      	b	0x11ec <ltmp0+0x11ec>
    1198:      	ldr	s20, [x16]
    119c:      	and	w17, w17, #0xff
    11a0:      	tbz	w17, #0x1, 0x117c <ltmp0+0x117c>
    11a4:      	add	x0, x16, #0x4
    11a8:      	ld1.s	{ v20 }[1], [x0]
    11ac:      	tbz	w17, #0x2, 0x1180 <ltmp0+0x1180>
    11b0:      	add	x0, x16, #0x8
    11b4:      	ld1.s	{ v20 }[2], [x0]
    11b8:      	tbz	w17, #0x3, 0x1184 <ltmp0+0x1184>
    11bc:      	add	x0, x16, #0xc
    11c0:      	ld1.s	{ v20 }[3], [x0]
    11c4:      	tbz	w17, #0x4, 0x1188 <ltmp0+0x1188>
    11c8:      	add	x0, x16, #0x10
    11cc:      	ld1.s	{ v21 }[0], [x0]
    11d0:      	tbz	w17, #0x5, 0x118c <ltmp0+0x118c>
    11d4:      	add	x0, x16, #0x14
    11d8:      	ld1.s	{ v21 }[1], [x0]
    11dc:      	tbz	w17, #0x6, 0x1190 <ltmp0+0x1190>
    11e0:      	add	x0, x16, #0x18
    11e4:      	ld1.s	{ v21 }[2], [x0]
    11e8:      	tbz	w17, #0x7, 0x112c <ltmp0+0x112c>
    11ec:      	add	x16, x16, #0x1c
    11f0:      	ld1.s	{ v21 }[3], [x16]
    11f4:      	b	0x112c <ltmp0+0x112c>
    11f8:      	add	x10, x10, x14
    11fc:      	fmov	w13, s15
    1200:      	movi.2d	v4, #0000000000000000
    1204:      	movi.2d	v6, #0000000000000000
    1208:      	tbnz	w13, #0x0, 0x16d0 <ltmp0+0x16d0>
    120c:      	tbnz	w13, #0x1, 0x16d8 <ltmp0+0x16d8>
    1210:      	tbnz	w13, #0x2, 0x16e4 <ltmp0+0x16e4>
    1214:      	tbnz	w13, #0x3, 0x16f0 <ltmp0+0x16f0>
    1218:      	tbnz	w13, #0x4, 0x16fc <ltmp0+0x16fc>
    121c:      	tbnz	w13, #0x5, 0x1708 <ltmp0+0x1708>
    1220:      	tbnz	w13, #0x6, 0x1714 <ltmp0+0x1714>
    1224:      	tbz	w13, #0x7, 0x1230 <ltmp0+0x1230>
    1228:      	add	x10, x10, #0x1c
    122c:      	ld1.s	{ v6 }[3], [x10]
    1230:      	mov	x13, #0x0               ; =0
    1234:      	add	x10, x20, x11
    1238:      	ldp	q5, q19, [x10]
    123c:      	zip2.8b	v20, v3, v0
    1240:      	ushll.4s	v20, v20, #0x0
    1244:      	shl.4s	v20, v20, #0x1f
    1248:      	cmlt.4s	v20, v20, #0
    124c:      	mov.16b	v31, v20
    1250:      	bsl.16b	v31, v6, v19
    1254:      	zip1.8b	v6, v3, v0
    1258:      	ushll.4s	v6, v6, #0x0
    125c:      	shl.4s	v6, v6, #0x1f
    1260:      	cmlt.4s	v6, v6, #0
    1264:      	mov.16b	v8, v6
    1268:      	bsl.16b	v8, v4, v5
    126c:      	stp	q8, q31, [x10]
    1270:      	add	x10, x8, x12
    1274:      	movi.2d	v4, #0000000000000000
    1278:      	movi.2d	v6, #0000000000000000
    127c:      	movi.2d	v19, #0000000000000000
    1280:      	movi.2d	v20, #0000000000000000
    1284:      	b	0x12a4 <ltmp0+0x12a4>
    1288:      	add.2d	v6, v6, v16
    128c:      	add.2d	v19, v19, v17
    1290:      	add.2d	v20, v20, v7
    1294:      	add.2d	v4, v4, v18
    1298:      	fmov	x13, d4
    129c:      	cmp	x13, #0x60
    12a0:      	b.ge	0x1384 <ltmp0+0x1384>
    12a4:      	fmov	w12, s2
    12a8:      	lsl	x11, x13, #5
    12ac:      	add	x13, x4, x11
    12b0:      	ldp	q5, q21, [x13]
    12b4:      	add	x13, x28, x11
    12b8:      	ldp	q10, q9, [x13]
    12bc:      	fmul.4s	v5, v5, v10
    12c0:      	add	x13, x19, x11
    12c4:      	ldp	q12, q10, [x13]
    12c8:      	add	x13, x20, x11
    12cc:      	ldp	q13, q11, [x13]
    12d0:      	fmul.4s	v12, v12, v13
    12d4:      	fsub.4s	v5, v5, v12
    12d8:      	and.16b	v12, v1, v5
    12dc:      	add	x11, x10, x11
    12e0:      	tbnz	w12, #0x0, 0x1318 <ltmp0+0x1318>
    12e4:      	and	w12, w12, #0xff
    12e8:      	tbnz	w12, #0x1, 0x1324 <ltmp0+0x1324>
    12ec:      	tbnz	w12, #0x2, 0x1330 <ltmp0+0x1330>
    12f0:      	tbnz	w12, #0x3, 0x133c <ltmp0+0x133c>
    12f4:      	fmul.4s	v5, v21, v9
    12f8:      	fmul.4s	v21, v10, v11
    12fc:      	fsub.4s	v5, v5, v21
    1300:      	and.16b	v21, v0, v5
    1304:      	tbnz	w12, #0x4, 0x1358 <ltmp0+0x1358>
    1308:      	tbnz	w12, #0x5, 0x1360 <ltmp0+0x1360>
    130c:      	tbnz	w12, #0x6, 0x136c <ltmp0+0x136c>
    1310:      	tbz	w12, #0x7, 0x1288 <ltmp0+0x1288>
    1314:      	b	0x1378 <ltmp0+0x1378>
    1318:      	str	s12, [x11]
    131c:      	and	w12, w12, #0xff
    1320:      	tbz	w12, #0x1, 0x12ec <ltmp0+0x12ec>
    1324:      	add	x13, x11, #0x4
    1328:      	st1.s	{ v12 }[1], [x13]
    132c:      	tbz	w12, #0x2, 0x12f0 <ltmp0+0x12f0>
    1330:      	add	x13, x11, #0x8
    1334:      	st1.s	{ v12 }[2], [x13]
    1338:      	tbz	w12, #0x3, 0x12f4 <ltmp0+0x12f4>
    133c:      	add	x13, x11, #0xc
    1340:      	st1.s	{ v12 }[3], [x13]
    1344:      	fmul.4s	v5, v21, v9
    1348:      	fmul.4s	v21, v10, v11
    134c:      	fsub.4s	v5, v5, v21
    1350:      	and.16b	v21, v0, v5
    1354:      	tbz	w12, #0x4, 0x1308 <ltmp0+0x1308>
    1358:      	str	s21, [x11, #0x10]
    135c:      	tbz	w12, #0x5, 0x130c <ltmp0+0x130c>
    1360:      	add	x13, x11, #0x14
    1364:      	st1.s	{ v21 }[1], [x13]
    1368:      	tbz	w12, #0x6, 0x1310 <ltmp0+0x1310>
    136c:      	add	x13, x11, #0x18
    1370:      	st1.s	{ v21 }[2], [x13]
    1374:      	tbz	w12, #0x7, 0x1288 <ltmp0+0x1288>
    1378:      	add	x11, x11, #0x1c
    137c:      	st1.s	{ v21 }[3], [x11]
    1380:      	b	0x1288 <ltmp0+0x1288>
    1384:      	fmul.4s	v4, v26, v30
    1388:      	fmul.4s	v5, v28, v8
    138c:      	fsub.4s	v4, v4, v5
    1390:      	zip1.8b	v5, v3, v0
    1394:      	ushll.4s	v5, v5, #0x0
    1398:      	shl.4s	v5, v5, #0x1f
    139c:      	cmlt.4s	v5, v5, #0
    13a0:      	and.16b	v4, v5, v4
    13a4:      	fmov	w11, s15
    13a8:      	ldr	q6, [sp, #0x100]
    13ac:      	ldr	q5, [sp, #0xe0]
    13b0:      	stp	q6, q5, [sp, #0x160]
    13b4:      	ldr	q6, [sp, #0xd0]
    13b8:      	ldr	q5, [sp, #0xf0]
    13bc:      	stp	q6, q5, [sp, #0x180]
    13c0:      	and	x12, x9, #0x7
    13c4:      	add	x13, sp, #0x160
    13c8:      	ldr	x12, [x13, x12, lsl #3]
    13cc:      	sub	x12, x12, x9
    13d0:      	add	x12, x8, x12, lsl #2
    13d4:      	tbnz	w11, #0x0, 0x1724 <ltmp0+0x1724>
    13d8:      	tbnz	w11, #0x1, 0x172c <ltmp0+0x172c>
    13dc:      	tbnz	w11, #0x2, 0x1738 <ltmp0+0x1738>
    13e0:      	tbz	w11, #0x3, 0x13ec <ltmp0+0x13ec>
    13e4:      	add	x13, x12, #0xc
    13e8:      	st1.s	{ v4 }[3], [x13]
    13ec:      	fmul.4s	v4, v14, v29
    13f0:      	fmul.4s	v5, v27, v31
    13f4:      	fsub.4s	v4, v4, v5
    13f8:      	zip2.8b	v5, v3, v0
    13fc:      	ushll.4s	v5, v5, #0x0
    1400:      	shl.4s	v5, v5, #0x1f
    1404:      	cmlt.4s	v5, v5, #0
    1408:      	and.16b	v4, v5, v4
    140c:      	tbnz	w11, #0x4, 0x1748 <ltmp0+0x1748>
    1410:      	tbnz	w11, #0x5, 0x1750 <ltmp0+0x1750>
    1414:      	tbnz	w11, #0x6, 0x175c <ltmp0+0x175c>
    1418:      	tbz	w11, #0x7, 0x1424 <ltmp0+0x1424>
    141c:      	add	x11, x12, #0x1c
    1420:      	st1.s	{ v4 }[3], [x11]
    1424:      	mov	x11, #0x0               ; =0
    1428:      	add	x10, x10, #0xc04
    142c:      	movi.2d	v4, #0000000000000000
    1430:      	movi.2d	v5, #0000000000000000
    1434:      	movi.2d	v6, #0000000000000000
    1438:      	movi.2d	v19, #0000000000000000
    143c:      	b	0x145c <ltmp0+0x145c>
    1440:      	add.2d	v5, v5, v16
    1444:      	add.2d	v6, v6, v17
    1448:      	add.2d	v19, v19, v7
    144c:      	add.2d	v4, v4, v18
    1450:      	fmov	x11, d4
    1454:      	cmp	x11, #0x60
    1458:      	b.ge	0x153c <ltmp0+0x153c>
    145c:      	fmov	w12, s2
    1460:      	lsl	x11, x11, #5
    1464:      	add	x13, x4, x11
    1468:      	ldp	q9, q20, [x13]
    146c:      	add	x13, x20, x11
    1470:      	ldp	q10, q21, [x13]
    1474:      	fmul.4s	v11, v9, v10
    1478:      	add	x13, x19, x11
    147c:      	ldp	q12, q9, [x13]
    1480:      	add	x13, x28, x11
    1484:      	ldp	q13, q10, [x13]
    1488:      	fmul.4s	v12, v12, v13
    148c:      	fadd.4s	v11, v11, v12
    1490:      	and.16b	v11, v1, v11
    1494:      	add	x11, x10, x11
    1498:      	tbnz	w12, #0x0, 0x14d0 <ltmp0+0x14d0>
    149c:      	and	w12, w12, #0xff
    14a0:      	tbnz	w12, #0x1, 0x14dc <ltmp0+0x14dc>
    14a4:      	tbnz	w12, #0x2, 0x14e8 <ltmp0+0x14e8>
    14a8:      	tbnz	w12, #0x3, 0x14f4 <ltmp0+0x14f4>
    14ac:      	fmul.4s	v20, v20, v21
    14b0:      	fmul.4s	v21, v9, v10
    14b4:      	fadd.4s	v20, v20, v21
    14b8:      	and.16b	v20, v0, v20
    14bc:      	tbnz	w12, #0x4, 0x1510 <ltmp0+0x1510>
    14c0:      	tbnz	w12, #0x5, 0x1518 <ltmp0+0x1518>
    14c4:      	tbnz	w12, #0x6, 0x1524 <ltmp0+0x1524>
    14c8:      	tbz	w12, #0x7, 0x1440 <ltmp0+0x1440>
    14cc:      	b	0x1530 <ltmp0+0x1530>
    14d0:      	str	s11, [x11]
    14d4:      	and	w12, w12, #0xff
    14d8:      	tbz	w12, #0x1, 0x14a4 <ltmp0+0x14a4>
    14dc:      	add	x13, x11, #0x4
    14e0:      	st1.s	{ v11 }[1], [x13]
    14e4:      	tbz	w12, #0x2, 0x14a8 <ltmp0+0x14a8>
    14e8:      	add	x13, x11, #0x8
    14ec:      	st1.s	{ v11 }[2], [x13]
    14f0:      	tbz	w12, #0x3, 0x14ac <ltmp0+0x14ac>
    14f4:      	add	x13, x11, #0xc
    14f8:      	st1.s	{ v11 }[3], [x13]
    14fc:      	fmul.4s	v20, v20, v21
    1500:      	fmul.4s	v21, v9, v10
    1504:      	fadd.4s	v20, v20, v21
    1508:      	and.16b	v20, v0, v20
    150c:      	tbz	w12, #0x4, 0x14c0 <ltmp0+0x14c0>
    1510:      	str	s20, [x11, #0x10]
    1514:      	tbz	w12, #0x5, 0x14c4 <ltmp0+0x14c4>
    1518:      	add	x13, x11, #0x14
    151c:      	st1.s	{ v20 }[1], [x13]
    1520:      	tbz	w12, #0x6, 0x14c8 <ltmp0+0x14c8>
    1524:      	add	x13, x11, #0x18
    1528:      	st1.s	{ v20 }[2], [x13]
    152c:      	tbz	w12, #0x7, 0x1440 <ltmp0+0x1440>
    1530:      	add	x11, x11, #0x1c
    1534:      	st1.s	{ v20 }[3], [x11]
    1538:      	b	0x1440 <ltmp0+0x1440>
    153c:      	fmul.4s	v0, v26, v8
    1540:      	fmul.4s	v1, v28, v30
    1544:      	fadd.4s	v0, v1, v0
    1548:      	zip1.8b	v1, v3, v0
    154c:      	ushll.4s	v1, v1, #0x0
    1550:      	shl.4s	v1, v1, #0x1f
    1554:      	cmlt.4s	v1, v1, #0
    1558:      	and.16b	v0, v1, v0
    155c:      	fmov	w10, s15
    1560:      	stp	q25, q24, [sp, #0x110]
    1564:      	stp	q23, q22, [sp, #0x130]
    1568:      	and	x11, x9, #0x7
    156c:      	add	x12, sp, #0x110
    1570:      	ldr	x11, [x12, x11, lsl #3]
    1574:      	sub	x9, x11, x9
    1578:      	add	x8, x8, x9, lsl #2
    157c:      	tbnz	w10, #0x0, 0x176c <ltmp0+0x176c>
    1580:      	tbnz	w10, #0x1, 0x1774 <ltmp0+0x1774>
    1584:      	tbnz	w10, #0x2, 0x1780 <ltmp0+0x1780>
    1588:      	tbz	w10, #0x3, 0x1594 <ltmp0+0x1594>
    158c:      	add	x9, x8, #0xc
    1590:      	st1.s	{ v0 }[3], [x9]
    1594:      	fmul.4s	v0, v14, v31
    1598:      	fmul.4s	v1, v27, v29
    159c:      	fadd.4s	v0, v1, v0
    15a0:      	zip2.8b	v1, v3, v0
    15a4:      	ushll.4s	v1, v1, #0x0
    15a8:      	shl.4s	v1, v1, #0x1f
    15ac:      	cmlt.4s	v1, v1, #0
    15b0:      	and.16b	v0, v1, v0
    15b4:      	tbnz	w10, #0x4, 0x1790 <ltmp0+0x1790>
    15b8:      	tbnz	w10, #0x5, 0x1798 <ltmp0+0x1798>
    15bc:      	tbnz	w10, #0x6, 0x17a4 <ltmp0+0x17a4>
    15c0:      	tbz	w10, #0x7, 0x98 <ltmp0+0x98>
    15c4:      	b	0x17b0 <ltmp0+0x17b0>
    15c8:      	ldr	s16, [x12]
    15cc:      	tbz	w11, #0x1, 0xb80 <ltmp0+0xb80>
    15d0:      	add	x16, x12, #0x4
    15d4:      	ld1.s	{ v16 }[1], [x16]
    15d8:      	tbz	w11, #0x2, 0xb84 <ltmp0+0xb84>
    15dc:      	add	x16, x12, #0x8
    15e0:      	ld1.s	{ v16 }[2], [x16]
    15e4:      	tbz	w11, #0x3, 0xb88 <ltmp0+0xb88>
    15e8:      	add	x16, x12, #0xc
    15ec:      	ld1.s	{ v16 }[3], [x16]
    15f0:      	tbz	w11, #0x4, 0xb8c <ltmp0+0xb8c>
    15f4:      	add	x16, x12, #0x10
    15f8:      	ld1.s	{ v17 }[0], [x16]
    15fc:      	tbz	w11, #0x5, 0xb90 <ltmp0+0xb90>
    1600:      	add	x16, x12, #0x14
    1604:      	ld1.s	{ v17 }[1], [x16]
    1608:      	tbz	w11, #0x6, 0xb94 <ltmp0+0xb94>
    160c:      	add	x16, x12, #0x18
    1610:      	ld1.s	{ v17 }[2], [x16]
    1614:      	tbnz	w11, #0x7, 0xb98 <ltmp0+0xb98>
    1618:      	b	0xba0 <ltmp0+0xba0>
    161c:      	ldr	s4, [x15]
    1620:      	mov.16b	v14, v26
    1624:      	tbz	w16, #0x1, 0xeac <ltmp0+0xeac>
    1628:      	add	x17, x15, #0x4
    162c:      	ld1.s	{ v4 }[1], [x17]
    1630:      	mov.16b	v26, v30
    1634:      	ldr	d30, [sp, #0xc0]
    1638:      	tbz	w16, #0x2, 0xeb8 <ltmp0+0xeb8>
    163c:      	add	x17, x15, #0x8
    1640:      	ld1.s	{ v4 }[2], [x17]
    1644:      	tbz	w16, #0x3, 0xebc <ltmp0+0xebc>
    1648:      	add	x17, x15, #0xc
    164c:      	ld1.s	{ v4 }[3], [x17]
    1650:      	tbz	w16, #0x4, 0xec0 <ltmp0+0xec0>
    1654:      	add	x17, x15, #0x10
    1658:      	ld1.s	{ v6 }[0], [x17]
    165c:      	tbz	w16, #0x5, 0xec4 <ltmp0+0xec4>
    1660:      	add	x17, x15, #0x14
    1664:      	ld1.s	{ v6 }[1], [x17]
    1668:      	tbz	w16, #0x6, 0xec8 <ltmp0+0xec8>
    166c:      	add	x17, x15, #0x18
    1670:      	ld1.s	{ v6 }[2], [x17]
    1674:      	tbnz	w16, #0x7, 0xecc <ltmp0+0xecc>
    1678:      	b	0xed4 <ltmp0+0xed4>
    167c:      	ldr	s4, [x13]
    1680:      	tbz	w15, #0x1, 0x10ac <ltmp0+0x10ac>
    1684:      	add	x16, x13, #0x4
    1688:      	ld1.s	{ v4 }[1], [x16]
    168c:      	tbz	w15, #0x2, 0x10b0 <ltmp0+0x10b0>
    1690:      	add	x16, x13, #0x8
    1694:      	ld1.s	{ v4 }[2], [x16]
    1698:      	tbz	w15, #0x3, 0x10b4 <ltmp0+0x10b4>
    169c:      	add	x16, x13, #0xc
    16a0:      	ld1.s	{ v4 }[3], [x16]
    16a4:      	tbz	w15, #0x4, 0x10b8 <ltmp0+0x10b8>
    16a8:      	add	x16, x13, #0x10
    16ac:      	ld1.s	{ v6 }[0], [x16]
    16b0:      	tbz	w15, #0x5, 0x10bc <ltmp0+0x10bc>
    16b4:      	add	x16, x13, #0x14
    16b8:      	ld1.s	{ v6 }[1], [x16]
    16bc:      	tbz	w15, #0x6, 0x10c0 <ltmp0+0x10c0>
    16c0:      	add	x16, x13, #0x18
    16c4:      	ld1.s	{ v6 }[2], [x16]
    16c8:      	tbnz	w15, #0x7, 0x10c4 <ltmp0+0x10c4>
    16cc:      	b	0x10cc <ltmp0+0x10cc>
    16d0:      	ldr	s4, [x10]
    16d4:      	tbz	w13, #0x1, 0x1210 <ltmp0+0x1210>
    16d8:      	add	x14, x10, #0x4
    16dc:      	ld1.s	{ v4 }[1], [x14]
    16e0:      	tbz	w13, #0x2, 0x1214 <ltmp0+0x1214>
    16e4:      	add	x14, x10, #0x8
    16e8:      	ld1.s	{ v4 }[2], [x14]
    16ec:      	tbz	w13, #0x3, 0x1218 <ltmp0+0x1218>
    16f0:      	add	x14, x10, #0xc
    16f4:      	ld1.s	{ v4 }[3], [x14]
    16f8:      	tbz	w13, #0x4, 0x121c <ltmp0+0x121c>
    16fc:      	add	x14, x10, #0x10
    1700:      	ld1.s	{ v6 }[0], [x14]
    1704:      	tbz	w13, #0x5, 0x1220 <ltmp0+0x1220>
    1708:      	add	x14, x10, #0x14
    170c:      	ld1.s	{ v6 }[1], [x14]
    1710:      	tbz	w13, #0x6, 0x1224 <ltmp0+0x1224>
    1714:      	add	x14, x10, #0x18
    1718:      	ld1.s	{ v6 }[2], [x14]
    171c:      	tbnz	w13, #0x7, 0x1228 <ltmp0+0x1228>
    1720:      	b	0x1230 <ltmp0+0x1230>
    1724:      	str	s4, [x12]
    1728:      	tbz	w11, #0x1, 0x13dc <ltmp0+0x13dc>
    172c:      	add	x13, x12, #0x4
    1730:      	st1.s	{ v4 }[1], [x13]
    1734:      	tbz	w11, #0x2, 0x13e0 <ltmp0+0x13e0>
    1738:      	add	x13, x12, #0x8
    173c:      	st1.s	{ v4 }[2], [x13]
    1740:      	tbnz	w11, #0x3, 0x13e4 <ltmp0+0x13e4>
    1744:      	b	0x13ec <ltmp0+0x13ec>
    1748:      	str	s4, [x12, #0x10]
    174c:      	tbz	w11, #0x5, 0x1414 <ltmp0+0x1414>
    1750:      	add	x13, x12, #0x14
    1754:      	st1.s	{ v4 }[1], [x13]
    1758:      	tbz	w11, #0x6, 0x1418 <ltmp0+0x1418>
    175c:      	add	x13, x12, #0x18
    1760:      	st1.s	{ v4 }[2], [x13]
    1764:      	tbnz	w11, #0x7, 0x141c <ltmp0+0x141c>
    1768:      	b	0x1424 <ltmp0+0x1424>
    176c:      	str	s0, [x8]
    1770:      	tbz	w10, #0x1, 0x1584 <ltmp0+0x1584>
    1774:      	add	x9, x8, #0x4
    1778:      	st1.s	{ v0 }[1], [x9]
    177c:      	tbz	w10, #0x2, 0x1588 <ltmp0+0x1588>
    1780:      	add	x9, x8, #0x8
    1784:      	st1.s	{ v0 }[2], [x9]
    1788:      	tbnz	w10, #0x3, 0x158c <ltmp0+0x158c>
    178c:      	b	0x1594 <ltmp0+0x1594>
    1790:      	str	s0, [x8, #0x10]
    1794:      	tbz	w10, #0x5, 0x15bc <ltmp0+0x15bc>
    1798:      	add	x9, x8, #0x14
    179c:      	st1.s	{ v0 }[1], [x9]
    17a0:      	tbz	w10, #0x6, 0x15c0 <ltmp0+0x15c0>
    17a4:      	add	x9, x8, #0x18
    17a8:      	st1.s	{ v0 }[2], [x9]
    17ac:      	tbz	w10, #0x7, 0x98 <ltmp0+0x98>
    17b0:      	add	x8, x8, #0x1c
    17b4:      	st1.s	{ v0 }[3], [x8]
    17b8:      	b	0x98 <ltmp0+0x98>
    17bc:      	ldr	x9, [sp, #0x8]
    17c0:      	stp	w6, w5, [x9]
    17c4:      	str	w12, [x9, #0x8]
    17c8:      	mov	w8, #0x18               ; =24
    17cc:      	str	w8, [x9, #0x24]
    17d0:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
    17d4:      	add	sp, sp, #0x360
    17d8:      	ldp	x29, x30, [sp, #0x90]
    17dc:      	ldp	x20, x19, [sp, #0x80]
    17e0:      	ldp	x22, x21, [sp, #0x70]
    17e4:      	ldp	x24, x23, [sp, #0x60]
    17e8:      	ldp	x26, x25, [sp, #0x50]
    17ec:      	ldp	x28, x27, [sp, #0x40]
    17f0:      	ldp	d9, d8, [sp, #0x30]
    17f4:      	ldp	d11, d10, [sp, #0x20]
    17f8:      	ldp	d13, d12, [sp, #0x10]
    17fc:      	ldp	d15, d14, [sp], #0xa0
    1800:      	ret

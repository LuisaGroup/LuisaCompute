
/private/tmp/luisa-expression-fusion.qXgTbC/capture/gelu_residual-129x768/on/object/tile_xir_w8_23468_1788930271269196_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x1, lsl #12   ; =0x1000
      2c:      	sub	sp, sp, #0xa10
      30:      	str	x0, [sp, #0x20]
      34:      	cbz	w3, 0x1a60 <ltmp0+0x1a60>
      38:      	mov	x20, x3
      3c:      	mov	w22, #0x0               ; =0
      40:      	ldp	w1, w8, [x2, #0x2c]
      44:      	str	w8, [sp, #0x38]
      48:      	add	x27, sp, #0xe10
      4c:      	add	x28, sp, #0x210
      50:      	ldp	w8, w9, [x2]
      54:      	mov	w10, #0x2713            ; =10003
      58:      	movk	w10, #0x3d37, lsl #16
      5c:      	mov	w11, #0x422a            ; =16938
      60:      	movk	w11, #0x3f4c, lsl #16
      64:      	dup.4s	v31, w10
      68:      	fmov.4s	v8, #1.00000000
      6c:      	dup.4s	v25, w11
      70:      	mov	w10, #0x9231            ; =37425
      74:      	movk	w10, #0x2f30, lsl #16
      78:      	dup.4s	v1, w10
      7c:      	mov	w10, #0x322b            ; =12843
      80:      	movk	w10, #0x32d7, lsl #16
      84:      	dup.4s	v0, w10
      88:      	stp	q0, q1, [sp, #0x120]
      8c:      	mov	w10, #0xef1d            ; =61213
      90:      	movk	w10, #0x3638, lsl #16
      94:      	dup.4s	v1, w10
      98:      	mov	w10, #0xd01             ; =3329
      9c:      	movk	w10, #0x3950, lsl #16
      a0:      	dup.4s	v0, w10
      a4:      	stp	q0, q1, [sp, #0x100]
      a8:      	mov	w10, #0x8889            ; =34953
      ac:      	movk	w10, #0x3c08, lsl #16
      b0:      	dup.4s	v18, w10
      b4:      	mov	w10, #0xaaab            ; =43691
      b8:      	movk	w10, #0x3e2a, lsl #16
      bc:      	dup.4s	v0, w10
      c0:      	str	q0, [sp, #0x70]
      c4:      	mov	w10, #0x76c7            ; =30407
      c8:      	movk	w10, #0x310f, lsl #16
      cc:      	dup.4s	v0, w10
      d0:      	str	q0, [sp, #0x1f0]
      d4:      	mov	w11, #0xf27e            ; =62078
      d8:      	movk	w11, #0x3493, lsl #16
      dc:      	mov	w12, #0xd01             ; =3329
      e0:      	movk	w12, #0x37d0, lsl #16
      e4:      	mov	w13, #0xb61             ; =2913
      e8:      	movk	w13, #0x3ab6, lsl #16
      ec:      	mov	w14, #0xaaab            ; =43691
      f0:      	movk	w14, #0x3d2a, lsl #16
      f4:      	ldp	w10, w15, [x2, #0x8]
      f8:      	str	x2, [sp, #0x10]
      fc:      	str	x15, [sp, #0x30]
     100:      	fmov.4s	v15, #9.00000000
     104:      	dup.4s	v20, w11
     108:      	mov	w11, #-0x3d300000       ; =-1026555904
     10c:      	dup.4s	v13, w12
     110:      	mov	w12, #0x42c80000        ; =1120403456
     114:      	dup.4s	v11, w13
     118:      	mov	w13, #0xaa3b            ; =43579
     11c:      	movk	w13, #0x3fb8, lsl #16
     120:      	dup.4s	v14, w14
     124:      	dup.4s	v22, w11
     128:      	dup.4s	v2, w12
     12c:      	mov	w11, #0x7200            ; =29184
     130:      	movk	w11, #0xbf31, lsl #16
     134:      	dup.4s	v1, w13
     138:      	mov	w12, #0xbe8e            ; =48782
     13c:      	movk	w12, #0xb5bf, lsl #16
     140:      	dup.4s	v0, w11
     144:      	stp	q0, q1, [sp, #0x1d0]
     148:      	mov	w11, #0x2bda            ; =11226
     14c:      	movk	w11, #0x3950, lsl #16
     150:      	dup.4s	v27, w12
     154:      	mov	w12, #0x96c9            ; =38601
     158:      	movk	w12, #0x3ab6, lsl #16
     15c:      	dup.4s	v28, w11
     160:      	mov	w11, #0x88a6            ; =34982
     164:      	movk	w11, #0x3c08, lsl #16
     168:      	dup.4s	v29, w12
     16c:      	mov	w12, #0xaa7a            ; =43642
     170:      	movk	w12, #0x3d2a, lsl #16
     174:      	dup.4s	v30, w11
     178:      	dup.4s	v21, w12
     17c:      	mvni.4s	v0, #0x7f, msl #16
     180:      	fneg.4s	v1, v0
     184:      	fmov.4s	v0, #0.25000000
     188:      	stp	q0, q1, [sp, #0xa0]
     18c:      	mvni.4s	v0, #0x3f, msl #16
     190:      	fneg.4s	v23, v0
     194:      	stp	q25, q31, [sp, #0xe0]
     198:      	stp	q18, q8, [sp, #0x50]
     19c:      	str	w3, [sp, #0x1c]
     1a0:      	str	w1, [sp, #0x3c]
     1a4:      	stp	q20, q15, [sp, #0x180]
     1a8:      	stp	q11, q13, [sp, #0x160]
     1ac:      	stp	q22, q14, [sp, #0x140]
     1b0:      	stp	q21, q2, [sp, #0xc0]
     1b4:      	stp	q28, q27, [sp, #0x1b0]
     1b8:      	str	q29, [sp, #0x1a0]
     1bc:      	stp	q30, q23, [sp, #0x80]
     1c0:      	b	0x200 <ltmp0+0x200>
     1c4:      	add	w8, w0, #0x1
     1c8:      	cmp	w8, w1
     1cc:      	cset	w9, eq
     1d0:      	csinc	w8, wzr, w0, eq
     1d4:      	cinc	w10, w17, eq
     1d8:      	ldr	w11, [sp, #0x38]
     1dc:      	cmp	w10, w11
     1e0:      	cset	w11, eq
     1e4:      	ands	w11, w9, w11
     1e8:      	csel	w9, wzr, w10, ne
     1ec:      	ldr	w12, [sp, #0x44]
     1f0:      	add	w10, w12, w11
     1f4:      	add	w22, w22, #0x1
     1f8:      	cmp	w22, w20
     1fc:      	b.eq	0x1a4c <ltmp0+0x1a4c>
     200:      	stp	w9, w10, [sp, #0x40]
     204:      	mov	x13, x8
     208:      	ubfiz	x8, x8, #5, #32
     20c:      	ldr	x12, [sp, #0x30]
     210:      	cmp	x8, x12
     214:      	csel	x9, x8, xzr, ls
     218:      	subs	x10, x12, x9
     21c:      	cmp	x10, #0x20
     220:      	mov	w11, #0x20              ; =32
     224:      	csel	x10, x10, x11, lo
     228:      	cmp	x12, x9
     22c:      	ccmp	x8, x12, #0x2, hi
     230:      	csel	x23, x10, xzr, ls
     234:      	cmp	x23, #0x20
     238:      	str	x13, [sp, #0x48]
     23c:      	b.lo	0x1028 <ltmp0+0x1028>
     240:      	ldr	x8, [sp, #0x20]
     244:      	ldr	x21, [x8]
     248:      	ldr	x24, [x8, #0x10]
     24c:      	ldr	x23, [x8, #0x30]
     250:      	ubfiz	w26, w13, #2, #27
     254:      	mov	w19, #0xc00             ; =3072
     258:      	umaddl	x1, w26, w19, x21
     25c:      	add	x0, sp, #0xe10
     260:      	mov	w2, #0xc00              ; =3072
     264:      	bl	0x264 <ltmp0+0x264>
     268:      	umaddl	x1, w26, w19, x24
     26c:      	add	x0, sp, #0x210
     270:      	mov	w2, #0xc00              ; =3072
     274:      	bl	0x274 <ltmp0+0x274>
     278:      	ldp	q8, q15, [sp, #0x60]
     27c:      	ldr	q14, [sp, #0x50]
     280:      	ldp	q13, q12, [sp, #0x100]
     284:      	ldp	q11, q10, [sp, #0x120]
     288:      	ldp	q9, q31, [sp, #0xe0]
     28c:      	mov	x8, #0x0                ; =0
     290:      	umaddl	x9, w26, w19, x23
     294:      	add	x10, x27, x8
     298:      	ldp	q0, q1, [x10]
     29c:      	fmul.4s	v2, v0, v31
     2a0:      	fmul.4s	v3, v1, v31
     2a4:      	fmul.4s	v3, v1, v3
     2a8:      	fmul.4s	v2, v0, v2
     2ac:      	fmul.4s	v2, v0, v2
     2b0:      	fmul.4s	v3, v1, v3
     2b4:      	fadd.4s	v4, v1, v3
     2b8:      	fadd.4s	v2, v0, v2
     2bc:      	fmul.4s	v3, v2, v9
     2c0:      	fmul.4s	v2, v4, v9
     2c4:      	fabs.4s	v5, v2
     2c8:      	fabs.4s	v4, v3
     2cc:      	fmul.4s	v19, v3, v3
     2d0:      	fmul.4s	v21, v2, v2
     2d4:      	mov.16b	v6, v11
     2d8:      	fmla.4s	v6, v19, v10
     2dc:      	mov.16b	v7, v11
     2e0:      	fmla.4s	v7, v21, v10
     2e4:      	mov.16b	v16, v12
     2e8:      	fmla.4s	v16, v19, v6
     2ec:      	mov.16b	v6, v12
     2f0:      	fmla.4s	v6, v21, v7
     2f4:      	mov.16b	v7, v13
     2f8:      	fmla.4s	v7, v19, v16
     2fc:      	mov.16b	v16, v13
     300:      	fmla.4s	v16, v21, v6
     304:      	mov.16b	v17, v14
     308:      	mov.16b	v18, v14
     30c:      	mov.16b	v22, v15
     310:      	mov.16b	v23, v15
     314:      	mov.16b	v6, v8
     318:      	fmla.4s	v17, v19, v7
     31c:      	ldp	q25, q20, [sp, #0x170]
     320:      	mov.16b	v7, v20
     324:      	ldr	q24, [sp, #0x1f0]
     328:      	fmla.4s	v7, v21, v24
     32c:      	fmla.4s	v20, v19, v24
     330:      	mov.16b	v24, v25
     334:      	fmla.4s	v18, v21, v16
     338:      	fmla.4s	v24, v21, v7
     33c:      	mov.16b	v7, v25
     340:      	fmla.4s	v7, v19, v20
     344:      	ldr	q20, [sp, #0x160]
     348:      	mov.16b	v16, v20
     34c:      	fmla.4s	v16, v21, v24
     350:      	fmla.4s	v22, v19, v17
     354:      	mov.16b	v17, v20
     358:      	fmla.4s	v17, v19, v7
     35c:      	ldp	q28, q24, [sp, #0x140]
     360:      	mov.16b	v20, v24
     364:      	fmla.4s	v20, v21, v16
     368:      	fmla.4s	v23, v21, v18
     36c:      	fmla.4s	v24, v19, v17
     370:      	movi.4s	v25, #0x3f, lsl #24
     374:      	movi.4s	v26, #0x3f, lsl #24
     378:      	mov.16b	v17, v8
     37c:      	ldr	q16, [sp, #0x190]
     380:      	fcmge.4s	v7, v16, v4
     384:      	fmla.4s	v25, v21, v20
     388:      	fcmge.4s	v16, v16, v5
     38c:      	and.16b	v18, v16, v5
     390:      	and.16b	v20, v7, v4
     394:      	fcmge.4s	v27, v20, v28
     398:      	fcmge.4s	v28, v18, v28
     39c:      	ldr	q29, [sp, #0xd0]
     3a0:      	fcmge.4s	v29, v29, v18
     3a4:      	and.16b	v28, v28, v29
     3a8:      	ldr	q29, [sp, #0xd0]
     3ac:      	fcmge.4s	v29, v29, v20
     3b0:      	and.16b	v27, v27, v29
     3b4:      	and.16b	v27, v27, v20
     3b8:      	and.16b	v28, v28, v18
     3bc:      	fmla.4s	v6, v21, v23
     3c0:      	ldr	q29, [sp, #0x1e0]
     3c4:      	fmul.4s	v23, v28, v29
     3c8:      	fmul.4s	v29, v27, v29
     3cc:      	movi.4s	v30, #0x4b, lsl #24
     3d0:      	fadd.4s	v29, v29, v30
     3d4:      	fadd.4s	v23, v23, v30
     3d8:      	movi.4s	v30, #0xcb, lsl #24
     3dc:      	fadd.4s	v23, v23, v30
     3e0:      	fmla.4s	v17, v21, v25
     3e4:      	fadd.4s	v21, v29, v30
     3e8:      	fcvtzs.4s	v21, v21
     3ec:      	fcvtzs.4s	v23, v23
     3f0:      	scvtf.4s	v25, v23
     3f4:      	scvtf.4s	v29, v21
     3f8:      	fmla.4s	v26, v19, v24
     3fc:      	ldr	q30, [sp, #0x1d0]
     400:      	fmul.4s	v24, v25, v30
     404:      	fadd.4s	v24, v28, v24
     408:      	fmul.4s	v28, v29, v30
     40c:      	fadd.4s	v27, v27, v28
     410:      	mov.16b	v28, v8
     414:      	fmla.4s	v28, v19, v22
     418:      	ldr	q30, [sp, #0x1c0]
     41c:      	fmul.4s	v22, v29, v30
     420:      	fadd.4s	v22, v27, v22
     424:      	fmul.4s	v25, v25, v30
     428:      	fadd.4s	v24, v24, v25
     42c:      	mov.16b	v25, v8
     430:      	fmla.4s	v25, v19, v26
     434:      	ldp	q27, q26, [sp, #0x1a0]
     438:      	fmul.4s	v19, v24, v26
     43c:      	fmul.4s	v26, v22, v26
     440:      	fadd.4s	v26, v26, v27
     444:      	fadd.4s	v19, v19, v27
     448:      	fmul.4s	v19, v24, v19
     44c:      	fmul.4s	v27, v4, v28
     450:      	fmul.4s	v26, v22, v26
     454:      	ldr	q28, [sp, #0x80]
     458:      	fadd.4s	v26, v26, v28
     45c:      	fadd.4s	v19, v19, v28
     460:      	fmul.4s	v19, v24, v19
     464:      	fmul.4s	v26, v22, v26
     468:      	ldp	q28, q29, [sp, #0xc0]
     46c:      	fadd.4s	v26, v26, v28
     470:      	fadd.4s	v19, v19, v28
     474:      	fmul.4s	v19, v24, v19
     478:      	fmul.4s	v26, v22, v26
     47c:      	fadd.4s	v26, v26, v15
     480:      	fadd.4s	v28, v19, v15
     484:      	fdiv.4s	v19, v27, v25
     488:      	fmul.4s	v25, v24, v28
     48c:      	fmul.4s	v26, v22, v26
     490:      	movi.4s	v28, #0x3f, lsl #24
     494:      	fadd.4s	v26, v26, v28
     498:      	fadd.4s	v25, v25, v28
     49c:      	fmul.4s	v27, v24, v24
     4a0:      	fmul.4s	v25, v27, v25
     4a4:      	fmul.4s	v27, v22, v22
     4a8:      	fmul.4s	v26, v27, v26
     4ac:      	fadd.4s	v22, v22, v26
     4b0:      	fadd.4s	v24, v24, v25
     4b4:      	movi.2d	v27, #0xffffffffffffffff
     4b8:      	add.4s	v21, v21, v27
     4bc:      	fadd.4s	v22, v22, v8
     4c0:      	sshr.4s	v25, v21, #0x1
     4c4:      	shl.4s	v26, v25, #0x17
     4c8:      	add.4s	v26, v26, v8
     4cc:      	fmul.4s	v22, v22, v26
     4d0:      	add.4s	v23, v23, v27
     4d4:      	fadd.4s	v24, v24, v8
     4d8:      	sub.4s	v21, v21, v25
     4dc:      	sshr.4s	v25, v23, #0x1
     4e0:      	sub.4s	v23, v23, v25
     4e4:      	shl.4s	v25, v25, #0x17
     4e8:      	add.4s	v25, v25, v8
     4ec:      	fmul.4s	v24, v24, v25
     4f0:      	shl.4s	v23, v23, #0x17
     4f4:      	add.4s	v23, v23, v8
     4f8:      	fmul.4s	v23, v24, v23
     4fc:      	shl.4s	v21, v21, #0x17
     500:      	add.4s	v21, v21, v8
     504:      	fmul.4s	v21, v22, v21
     508:      	fcmgt.4s	v20, v20, v29
     50c:      	ldp	q22, q24, [sp, #0xa0]
     510:      	bsl.16b	v20, v24, v21
     514:      	fmul.4s	v6, v5, v6
     518:      	fcmgt.4s	v18, v18, v29
     51c:      	bsl.16b	v18, v24, v23
     520:      	fdiv.4s	v6, v6, v17
     524:      	fdiv.4s	v17, v22, v18
     528:      	fsub.4s	v21, v18, v17
     52c:      	fadd.4s	v17, v18, v17
     530:      	fdiv.4s	v17, v21, v17
     534:      	bsl.16b	v16, v17, v8
     538:      	fcmge.4s	v5, v8, v5
     53c:      	bsl.16b	v5, v6, v16
     540:      	fdiv.4s	v6, v22, v20
     544:      	fsub.4s	v16, v20, v6
     548:      	fadd.4s	v6, v20, v6
     54c:      	fdiv.4s	v6, v16, v6
     550:      	bif.16b	v6, v8, v7
     554:      	fcmge.4s	v4, v8, v4
     558:      	bsl.16b	v4, v19, v6
     55c:      	mvni.4s	v7, #0x80, lsl #24
     560:      	bif.16b	v4, v3, v7
     564:      	fcmeq.4s	v3, v3, v3
     568:      	fadd.4s	v4, v4, v8
     56c:      	ldr	q6, [sp, #0x90]
     570:      	bsl.16b	v3, v4, v6
     574:      	mov.16b	v4, v7
     578:      	bsl.16b	v4, v5, v2
     57c:      	fcmeq.4s	v2, v2, v2
     580:      	fadd.4s	v4, v4, v8
     584:      	bsl.16b	v2, v4, v6
     588:      	fmul.4s	v1, v1, v28
     58c:      	fmul.4s	v1, v1, v2
     590:      	fmul.4s	v0, v0, v28
     594:      	fmul.4s	v0, v0, v3
     598:      	add	x10, x28, x8
     59c:      	ldp	q3, q2, [x10]
     5a0:      	fadd.4s	v0, v3, v0
     5a4:      	fadd.4s	v1, v2, v1
     5a8:      	add	x10, x9, x8
     5ac:      	stp	q0, q1, [x10]
     5b0:      	add	x8, x8, #0x20
     5b4:      	cmp	x8, #0xc00
     5b8:      	b.ne	0x294 <ltmp0+0x294>
     5bc:      	orr	w19, w26, #0x1
     5c0:      	mov	w25, #0xc00             ; =3072
     5c4:      	umaddl	x1, w19, w25, x21
     5c8:      	add	x0, sp, #0xe10
     5cc:      	mov	w2, #0xc00              ; =3072
     5d0:      	bl	0x5d0 <ltmp0+0x5d0>
     5d4:      	umaddl	x1, w19, w25, x24
     5d8:      	add	x0, sp, #0x210
     5dc:      	mov	w2, #0xc00              ; =3072
     5e0:      	bl	0x5e0 <ltmp0+0x5e0>
     5e4:      	ldp	q8, q15, [sp, #0x60]
     5e8:      	ldr	q14, [sp, #0x50]
     5ec:      	ldp	q13, q12, [sp, #0x100]
     5f0:      	ldp	q11, q10, [sp, #0x120]
     5f4:      	ldp	q9, q31, [sp, #0xe0]
     5f8:      	mov	x8, #0x0                ; =0
     5fc:      	umaddl	x9, w19, w25, x23
     600:      	add	x10, x27, x8
     604:      	ldp	q0, q1, [x10]
     608:      	fmul.4s	v2, v0, v31
     60c:      	fmul.4s	v3, v1, v31
     610:      	fmul.4s	v3, v1, v3
     614:      	fmul.4s	v2, v0, v2
     618:      	fmul.4s	v2, v0, v2
     61c:      	fmul.4s	v3, v1, v3
     620:      	fadd.4s	v4, v1, v3
     624:      	fadd.4s	v2, v0, v2
     628:      	fmul.4s	v3, v2, v9
     62c:      	fmul.4s	v2, v4, v9
     630:      	fabs.4s	v5, v2
     634:      	fabs.4s	v4, v3
     638:      	fmul.4s	v19, v3, v3
     63c:      	fmul.4s	v21, v2, v2
     640:      	mov.16b	v6, v11
     644:      	fmla.4s	v6, v19, v10
     648:      	mov.16b	v7, v11
     64c:      	fmla.4s	v7, v21, v10
     650:      	mov.16b	v16, v12
     654:      	fmla.4s	v16, v19, v6
     658:      	mov.16b	v6, v12
     65c:      	fmla.4s	v6, v21, v7
     660:      	mov.16b	v7, v13
     664:      	fmla.4s	v7, v19, v16
     668:      	mov.16b	v16, v13
     66c:      	fmla.4s	v16, v21, v6
     670:      	mov.16b	v17, v14
     674:      	mov.16b	v18, v14
     678:      	mov.16b	v22, v15
     67c:      	mov.16b	v23, v15
     680:      	mov.16b	v6, v8
     684:      	fmla.4s	v17, v19, v7
     688:      	ldp	q25, q20, [sp, #0x170]
     68c:      	mov.16b	v7, v20
     690:      	ldr	q24, [sp, #0x1f0]
     694:      	fmla.4s	v7, v21, v24
     698:      	fmla.4s	v20, v19, v24
     69c:      	mov.16b	v24, v25
     6a0:      	fmla.4s	v18, v21, v16
     6a4:      	fmla.4s	v24, v21, v7
     6a8:      	mov.16b	v7, v25
     6ac:      	fmla.4s	v7, v19, v20
     6b0:      	ldr	q20, [sp, #0x160]
     6b4:      	mov.16b	v16, v20
     6b8:      	fmla.4s	v16, v21, v24
     6bc:      	fmla.4s	v22, v19, v17
     6c0:      	mov.16b	v17, v20
     6c4:      	fmla.4s	v17, v19, v7
     6c8:      	ldp	q28, q24, [sp, #0x140]
     6cc:      	mov.16b	v20, v24
     6d0:      	fmla.4s	v20, v21, v16
     6d4:      	fmla.4s	v23, v21, v18
     6d8:      	fmla.4s	v24, v19, v17
     6dc:      	movi.4s	v25, #0x3f, lsl #24
     6e0:      	movi.4s	v26, #0x3f, lsl #24
     6e4:      	mov.16b	v17, v8
     6e8:      	ldr	q16, [sp, #0x190]
     6ec:      	fcmge.4s	v7, v16, v4
     6f0:      	fmla.4s	v25, v21, v20
     6f4:      	fcmge.4s	v16, v16, v5
     6f8:      	and.16b	v18, v16, v5
     6fc:      	and.16b	v20, v7, v4
     700:      	fcmge.4s	v27, v20, v28
     704:      	fcmge.4s	v28, v18, v28
     708:      	ldr	q29, [sp, #0xd0]
     70c:      	fcmge.4s	v29, v29, v18
     710:      	and.16b	v28, v28, v29
     714:      	ldr	q29, [sp, #0xd0]
     718:      	fcmge.4s	v29, v29, v20
     71c:      	and.16b	v27, v27, v29
     720:      	and.16b	v27, v27, v20
     724:      	and.16b	v28, v28, v18
     728:      	fmla.4s	v6, v21, v23
     72c:      	ldr	q29, [sp, #0x1e0]
     730:      	fmul.4s	v23, v28, v29
     734:      	fmul.4s	v29, v27, v29
     738:      	movi.4s	v30, #0x4b, lsl #24
     73c:      	fadd.4s	v29, v29, v30
     740:      	fadd.4s	v23, v23, v30
     744:      	movi.4s	v30, #0xcb, lsl #24
     748:      	fadd.4s	v23, v23, v30
     74c:      	fmla.4s	v17, v21, v25
     750:      	fadd.4s	v21, v29, v30
     754:      	fcvtzs.4s	v21, v21
     758:      	fcvtzs.4s	v23, v23
     75c:      	scvtf.4s	v25, v23
     760:      	scvtf.4s	v29, v21
     764:      	fmla.4s	v26, v19, v24
     768:      	ldr	q30, [sp, #0x1d0]
     76c:      	fmul.4s	v24, v25, v30
     770:      	fadd.4s	v24, v28, v24
     774:      	fmul.4s	v28, v29, v30
     778:      	fadd.4s	v27, v27, v28
     77c:      	mov.16b	v28, v8
     780:      	fmla.4s	v28, v19, v22
     784:      	ldr	q30, [sp, #0x1c0]
     788:      	fmul.4s	v22, v29, v30
     78c:      	fadd.4s	v22, v27, v22
     790:      	fmul.4s	v25, v25, v30
     794:      	fadd.4s	v24, v24, v25
     798:      	mov.16b	v25, v8
     79c:      	fmla.4s	v25, v19, v26
     7a0:      	ldp	q27, q26, [sp, #0x1a0]
     7a4:      	fmul.4s	v19, v24, v26
     7a8:      	fmul.4s	v26, v22, v26
     7ac:      	fadd.4s	v26, v26, v27
     7b0:      	fadd.4s	v19, v19, v27
     7b4:      	fmul.4s	v19, v24, v19
     7b8:      	fmul.4s	v27, v4, v28
     7bc:      	fmul.4s	v26, v22, v26
     7c0:      	ldr	q28, [sp, #0x80]
     7c4:      	fadd.4s	v26, v26, v28
     7c8:      	fadd.4s	v19, v19, v28
     7cc:      	fmul.4s	v19, v24, v19
     7d0:      	fmul.4s	v26, v22, v26
     7d4:      	ldp	q28, q29, [sp, #0xc0]
     7d8:      	fadd.4s	v26, v26, v28
     7dc:      	fadd.4s	v19, v19, v28
     7e0:      	fmul.4s	v19, v24, v19
     7e4:      	fmul.4s	v26, v22, v26
     7e8:      	fadd.4s	v26, v26, v15
     7ec:      	fadd.4s	v28, v19, v15
     7f0:      	fdiv.4s	v19, v27, v25
     7f4:      	fmul.4s	v25, v24, v28
     7f8:      	fmul.4s	v26, v22, v26
     7fc:      	movi.4s	v28, #0x3f, lsl #24
     800:      	fadd.4s	v26, v26, v28
     804:      	fadd.4s	v25, v25, v28
     808:      	fmul.4s	v27, v24, v24
     80c:      	fmul.4s	v25, v27, v25
     810:      	fmul.4s	v27, v22, v22
     814:      	fmul.4s	v26, v27, v26
     818:      	fadd.4s	v22, v22, v26
     81c:      	fadd.4s	v24, v24, v25
     820:      	movi.2d	v27, #0xffffffffffffffff
     824:      	add.4s	v21, v21, v27
     828:      	fadd.4s	v22, v22, v8
     82c:      	sshr.4s	v25, v21, #0x1
     830:      	shl.4s	v26, v25, #0x17
     834:      	add.4s	v26, v26, v8
     838:      	fmul.4s	v22, v22, v26
     83c:      	add.4s	v23, v23, v27
     840:      	fadd.4s	v24, v24, v8
     844:      	sub.4s	v21, v21, v25
     848:      	sshr.4s	v25, v23, #0x1
     84c:      	sub.4s	v23, v23, v25
     850:      	shl.4s	v25, v25, #0x17
     854:      	add.4s	v25, v25, v8
     858:      	fmul.4s	v24, v24, v25
     85c:      	shl.4s	v23, v23, #0x17
     860:      	add.4s	v23, v23, v8
     864:      	fmul.4s	v23, v24, v23
     868:      	shl.4s	v21, v21, #0x17
     86c:      	add.4s	v21, v21, v8
     870:      	fmul.4s	v21, v22, v21
     874:      	fcmgt.4s	v20, v20, v29
     878:      	ldp	q22, q24, [sp, #0xa0]
     87c:      	bsl.16b	v20, v24, v21
     880:      	fmul.4s	v6, v5, v6
     884:      	fcmgt.4s	v18, v18, v29
     888:      	bsl.16b	v18, v24, v23
     88c:      	fdiv.4s	v6, v6, v17
     890:      	fdiv.4s	v17, v22, v18
     894:      	fsub.4s	v21, v18, v17
     898:      	fadd.4s	v17, v18, v17
     89c:      	fdiv.4s	v17, v21, v17
     8a0:      	bsl.16b	v16, v17, v8
     8a4:      	fcmge.4s	v5, v8, v5
     8a8:      	bsl.16b	v5, v6, v16
     8ac:      	fdiv.4s	v6, v22, v20
     8b0:      	fsub.4s	v16, v20, v6
     8b4:      	fadd.4s	v6, v20, v6
     8b8:      	fdiv.4s	v6, v16, v6
     8bc:      	bif.16b	v6, v8, v7
     8c0:      	fcmge.4s	v4, v8, v4
     8c4:      	bsl.16b	v4, v19, v6
     8c8:      	mvni.4s	v7, #0x80, lsl #24
     8cc:      	bif.16b	v4, v3, v7
     8d0:      	fcmeq.4s	v3, v3, v3
     8d4:      	fadd.4s	v4, v4, v8
     8d8:      	ldr	q6, [sp, #0x90]
     8dc:      	bsl.16b	v3, v4, v6
     8e0:      	mov.16b	v4, v7
     8e4:      	bsl.16b	v4, v5, v2
     8e8:      	fcmeq.4s	v2, v2, v2
     8ec:      	fadd.4s	v4, v4, v8
     8f0:      	bsl.16b	v2, v4, v6
     8f4:      	fmul.4s	v1, v1, v28
     8f8:      	fmul.4s	v1, v1, v2
     8fc:      	fmul.4s	v0, v0, v28
     900:      	fmul.4s	v0, v0, v3
     904:      	add	x10, x28, x8
     908:      	ldp	q3, q2, [x10]
     90c:      	fadd.4s	v0, v3, v0
     910:      	fadd.4s	v1, v2, v1
     914:      	add	x10, x9, x8
     918:      	stp	q0, q1, [x10]
     91c:      	add	x8, x8, #0x20
     920:      	cmp	x8, #0xc00
     924:      	b.ne	0x600 <ltmp0+0x600>
     928:      	orr	w19, w26, #0x2
     92c:      	mov	w25, #0xc00             ; =3072
     930:      	umaddl	x1, w19, w25, x21
     934:      	add	x0, sp, #0xe10
     938:      	mov	w2, #0xc00              ; =3072
     93c:      	bl	0x93c <ltmp0+0x93c>
     940:      	umaddl	x1, w19, w25, x24
     944:      	add	x0, sp, #0x210
     948:      	mov	w2, #0xc00              ; =3072
     94c:      	bl	0x94c <ltmp0+0x94c>
     950:      	ldp	q8, q15, [sp, #0x60]
     954:      	ldr	q14, [sp, #0x50]
     958:      	ldp	q13, q12, [sp, #0x100]
     95c:      	ldp	q11, q10, [sp, #0x120]
     960:      	ldp	q9, q31, [sp, #0xe0]
     964:      	mov	x8, #0x0                ; =0
     968:      	umaddl	x9, w19, w25, x23
     96c:      	add	x10, x27, x8
     970:      	ldp	q0, q1, [x10]
     974:      	fmul.4s	v2, v0, v31
     978:      	fmul.4s	v3, v1, v31
     97c:      	fmul.4s	v3, v1, v3
     980:      	fmul.4s	v2, v0, v2
     984:      	fmul.4s	v2, v0, v2
     988:      	fmul.4s	v3, v1, v3
     98c:      	fadd.4s	v4, v1, v3
     990:      	fadd.4s	v2, v0, v2
     994:      	fmul.4s	v3, v2, v9
     998:      	fmul.4s	v2, v4, v9
     99c:      	fabs.4s	v5, v2
     9a0:      	fabs.4s	v4, v3
     9a4:      	fmul.4s	v19, v3, v3
     9a8:      	fmul.4s	v21, v2, v2
     9ac:      	mov.16b	v6, v11
     9b0:      	fmla.4s	v6, v19, v10
     9b4:      	mov.16b	v7, v11
     9b8:      	fmla.4s	v7, v21, v10
     9bc:      	mov.16b	v16, v12
     9c0:      	fmla.4s	v16, v19, v6
     9c4:      	mov.16b	v6, v12
     9c8:      	fmla.4s	v6, v21, v7
     9cc:      	mov.16b	v7, v13
     9d0:      	fmla.4s	v7, v19, v16
     9d4:      	mov.16b	v16, v13
     9d8:      	fmla.4s	v16, v21, v6
     9dc:      	mov.16b	v17, v14
     9e0:      	mov.16b	v18, v14
     9e4:      	mov.16b	v22, v15
     9e8:      	mov.16b	v23, v15
     9ec:      	mov.16b	v6, v8
     9f0:      	fmla.4s	v17, v19, v7
     9f4:      	ldp	q25, q20, [sp, #0x170]
     9f8:      	mov.16b	v7, v20
     9fc:      	ldr	q24, [sp, #0x1f0]
     a00:      	fmla.4s	v7, v21, v24
     a04:      	fmla.4s	v20, v19, v24
     a08:      	mov.16b	v24, v25
     a0c:      	fmla.4s	v18, v21, v16
     a10:      	fmla.4s	v24, v21, v7
     a14:      	mov.16b	v7, v25
     a18:      	fmla.4s	v7, v19, v20
     a1c:      	ldr	q20, [sp, #0x160]
     a20:      	mov.16b	v16, v20
     a24:      	fmla.4s	v16, v21, v24
     a28:      	fmla.4s	v22, v19, v17
     a2c:      	mov.16b	v17, v20
     a30:      	fmla.4s	v17, v19, v7
     a34:      	ldp	q28, q24, [sp, #0x140]
     a38:      	mov.16b	v20, v24
     a3c:      	fmla.4s	v20, v21, v16
     a40:      	fmla.4s	v23, v21, v18
     a44:      	fmla.4s	v24, v19, v17
     a48:      	movi.4s	v25, #0x3f, lsl #24
     a4c:      	movi.4s	v26, #0x3f, lsl #24
     a50:      	mov.16b	v17, v8
     a54:      	ldr	q16, [sp, #0x190]
     a58:      	fcmge.4s	v7, v16, v4
     a5c:      	fmla.4s	v25, v21, v20
     a60:      	fcmge.4s	v16, v16, v5
     a64:      	and.16b	v18, v16, v5
     a68:      	and.16b	v20, v7, v4
     a6c:      	fcmge.4s	v27, v20, v28
     a70:      	fcmge.4s	v28, v18, v28
     a74:      	ldr	q29, [sp, #0xd0]
     a78:      	fcmge.4s	v29, v29, v18
     a7c:      	and.16b	v28, v28, v29
     a80:      	ldr	q29, [sp, #0xd0]
     a84:      	fcmge.4s	v29, v29, v20
     a88:      	and.16b	v27, v27, v29
     a8c:      	and.16b	v27, v27, v20
     a90:      	and.16b	v28, v28, v18
     a94:      	fmla.4s	v6, v21, v23
     a98:      	ldr	q29, [sp, #0x1e0]
     a9c:      	fmul.4s	v23, v28, v29
     aa0:      	fmul.4s	v29, v27, v29
     aa4:      	movi.4s	v30, #0x4b, lsl #24
     aa8:      	fadd.4s	v29, v29, v30
     aac:      	fadd.4s	v23, v23, v30
     ab0:      	movi.4s	v30, #0xcb, lsl #24
     ab4:      	fadd.4s	v23, v23, v30
     ab8:      	fmla.4s	v17, v21, v25
     abc:      	fadd.4s	v21, v29, v30
     ac0:      	fcvtzs.4s	v21, v21
     ac4:      	fcvtzs.4s	v23, v23
     ac8:      	scvtf.4s	v25, v23
     acc:      	scvtf.4s	v29, v21
     ad0:      	fmla.4s	v26, v19, v24
     ad4:      	ldr	q30, [sp, #0x1d0]
     ad8:      	fmul.4s	v24, v25, v30
     adc:      	fadd.4s	v24, v28, v24
     ae0:      	fmul.4s	v28, v29, v30
     ae4:      	fadd.4s	v27, v27, v28
     ae8:      	mov.16b	v28, v8
     aec:      	fmla.4s	v28, v19, v22
     af0:      	ldr	q30, [sp, #0x1c0]
     af4:      	fmul.4s	v22, v29, v30
     af8:      	fadd.4s	v22, v27, v22
     afc:      	fmul.4s	v25, v25, v30
     b00:      	fadd.4s	v24, v24, v25
     b04:      	mov.16b	v25, v8
     b08:      	fmla.4s	v25, v19, v26
     b0c:      	ldp	q27, q26, [sp, #0x1a0]
     b10:      	fmul.4s	v19, v24, v26
     b14:      	fmul.4s	v26, v22, v26
     b18:      	fadd.4s	v26, v26, v27
     b1c:      	fadd.4s	v19, v19, v27
     b20:      	fmul.4s	v19, v24, v19
     b24:      	fmul.4s	v27, v4, v28
     b28:      	fmul.4s	v26, v22, v26
     b2c:      	ldr	q28, [sp, #0x80]
     b30:      	fadd.4s	v26, v26, v28
     b34:      	fadd.4s	v19, v19, v28
     b38:      	fmul.4s	v19, v24, v19
     b3c:      	fmul.4s	v26, v22, v26
     b40:      	ldp	q28, q29, [sp, #0xc0]
     b44:      	fadd.4s	v26, v26, v28
     b48:      	fadd.4s	v19, v19, v28
     b4c:      	fmul.4s	v19, v24, v19
     b50:      	fmul.4s	v26, v22, v26
     b54:      	fadd.4s	v26, v26, v15
     b58:      	fadd.4s	v28, v19, v15
     b5c:      	fdiv.4s	v19, v27, v25
     b60:      	fmul.4s	v25, v24, v28
     b64:      	fmul.4s	v26, v22, v26
     b68:      	movi.4s	v28, #0x3f, lsl #24
     b6c:      	fadd.4s	v26, v26, v28
     b70:      	fadd.4s	v25, v25, v28
     b74:      	fmul.4s	v27, v24, v24
     b78:      	fmul.4s	v25, v27, v25
     b7c:      	fmul.4s	v27, v22, v22
     b80:      	fmul.4s	v26, v27, v26
     b84:      	fadd.4s	v22, v22, v26
     b88:      	fadd.4s	v24, v24, v25
     b8c:      	movi.2d	v27, #0xffffffffffffffff
     b90:      	add.4s	v21, v21, v27
     b94:      	fadd.4s	v22, v22, v8
     b98:      	sshr.4s	v25, v21, #0x1
     b9c:      	shl.4s	v26, v25, #0x17
     ba0:      	add.4s	v26, v26, v8
     ba4:      	fmul.4s	v22, v22, v26
     ba8:      	add.4s	v23, v23, v27
     bac:      	fadd.4s	v24, v24, v8
     bb0:      	sub.4s	v21, v21, v25
     bb4:      	sshr.4s	v25, v23, #0x1
     bb8:      	sub.4s	v23, v23, v25
     bbc:      	shl.4s	v25, v25, #0x17
     bc0:      	add.4s	v25, v25, v8
     bc4:      	fmul.4s	v24, v24, v25
     bc8:      	shl.4s	v23, v23, #0x17
     bcc:      	add.4s	v23, v23, v8
     bd0:      	fmul.4s	v23, v24, v23
     bd4:      	shl.4s	v21, v21, #0x17
     bd8:      	add.4s	v21, v21, v8
     bdc:      	fmul.4s	v21, v22, v21
     be0:      	fcmgt.4s	v20, v20, v29
     be4:      	ldp	q22, q24, [sp, #0xa0]
     be8:      	bsl.16b	v20, v24, v21
     bec:      	fmul.4s	v6, v5, v6
     bf0:      	fcmgt.4s	v18, v18, v29
     bf4:      	bsl.16b	v18, v24, v23
     bf8:      	fdiv.4s	v6, v6, v17
     bfc:      	fdiv.4s	v17, v22, v18
     c00:      	fsub.4s	v21, v18, v17
     c04:      	fadd.4s	v17, v18, v17
     c08:      	fdiv.4s	v17, v21, v17
     c0c:      	bsl.16b	v16, v17, v8
     c10:      	fcmge.4s	v5, v8, v5
     c14:      	bsl.16b	v5, v6, v16
     c18:      	fdiv.4s	v6, v22, v20
     c1c:      	fsub.4s	v16, v20, v6
     c20:      	fadd.4s	v6, v20, v6
     c24:      	fdiv.4s	v6, v16, v6
     c28:      	bif.16b	v6, v8, v7
     c2c:      	fcmge.4s	v4, v8, v4
     c30:      	bsl.16b	v4, v19, v6
     c34:      	mvni.4s	v7, #0x80, lsl #24
     c38:      	bif.16b	v4, v3, v7
     c3c:      	fcmeq.4s	v3, v3, v3
     c40:      	fadd.4s	v4, v4, v8
     c44:      	ldr	q6, [sp, #0x90]
     c48:      	bsl.16b	v3, v4, v6
     c4c:      	mov.16b	v4, v7
     c50:      	bsl.16b	v4, v5, v2
     c54:      	fcmeq.4s	v2, v2, v2
     c58:      	fadd.4s	v4, v4, v8
     c5c:      	bsl.16b	v2, v4, v6
     c60:      	fmul.4s	v1, v1, v28
     c64:      	fmul.4s	v1, v1, v2
     c68:      	fmul.4s	v0, v0, v28
     c6c:      	fmul.4s	v0, v0, v3
     c70:      	add	x10, x28, x8
     c74:      	ldp	q3, q2, [x10]
     c78:      	fadd.4s	v0, v3, v0
     c7c:      	fadd.4s	v1, v2, v1
     c80:      	add	x10, x9, x8
     c84:      	stp	q0, q1, [x10]
     c88:      	add	x8, x8, #0x20
     c8c:      	cmp	x8, #0xc00
     c90:      	b.ne	0x96c <ltmp0+0x96c>
     c94:      	orr	w19, w26, #0x3
     c98:      	mov	w25, #0xc00             ; =3072
     c9c:      	umaddl	x1, w19, w25, x21
     ca0:      	add	x0, sp, #0xe10
     ca4:      	mov	w2, #0xc00              ; =3072
     ca8:      	bl	0xca8 <ltmp0+0xca8>
     cac:      	umaddl	x1, w19, w25, x24
     cb0:      	add	x0, sp, #0x210
     cb4:      	mov	w2, #0xc00              ; =3072
     cb8:      	bl	0xcb8 <ltmp0+0xcb8>
     cbc:      	ldp	q8, q29, [sp, #0x60]
     cc0:      	ldr	q18, [sp, #0x50]
     cc4:      	mov	x8, #0x0                ; =0
     cc8:      	umaddl	x9, w19, w25, x23
     ccc:      	ldp	q20, q15, [sp, #0x180]
     cd0:      	ldp	q11, q13, [sp, #0x160]
     cd4:      	ldp	q9, q10, [sp, #0x140]
     cd8:      	ldr	q31, [sp, #0xd0]
     cdc:      	add	x10, x27, x8
     ce0:      	ldp	q0, q1, [x10]
     ce4:      	ldp	q5, q3, [sp, #0xe0]
     ce8:      	fmul.4s	v2, v0, v3
     cec:      	fmul.4s	v3, v1, v3
     cf0:      	fmul.4s	v3, v1, v3
     cf4:      	fmul.4s	v2, v0, v2
     cf8:      	fmul.4s	v2, v0, v2
     cfc:      	fmul.4s	v3, v1, v3
     d00:      	fadd.4s	v4, v1, v3
     d04:      	fadd.4s	v2, v0, v2
     d08:      	fmul.4s	v3, v2, v5
     d0c:      	fmul.4s	v2, v4, v5
     d10:      	fabs.4s	v5, v2
     d14:      	fabs.4s	v4, v3
     d18:      	fmul.4s	v19, v3, v3
     d1c:      	fmul.4s	v21, v2, v2
     d20:      	ldp	q7, q16, [sp, #0x120]
     d24:      	mov.16b	v6, v7
     d28:      	fmla.4s	v6, v19, v16
     d2c:      	fmla.4s	v7, v21, v16
     d30:      	ldr	q17, [sp, #0x110]
     d34:      	mov.16b	v16, v17
     d38:      	fmla.4s	v16, v19, v6
     d3c:      	mov.16b	v6, v17
     d40:      	fmla.4s	v6, v21, v7
     d44:      	ldr	q17, [sp, #0x100]
     d48:      	mov.16b	v7, v17
     d4c:      	fmla.4s	v7, v19, v16
     d50:      	mov.16b	v16, v17
     d54:      	fmla.4s	v16, v21, v6
     d58:      	mov.16b	v17, v18
     d5c:      	mov.16b	v30, v18
     d60:      	mov.16b	v22, v29
     d64:      	mov.16b	v23, v29
     d68:      	mov.16b	v6, v8
     d6c:      	fmla.4s	v17, v19, v7
     d70:      	mov.16b	v7, v20
     d74:      	ldr	q24, [sp, #0x1f0]
     d78:      	fmla.4s	v7, v21, v24
     d7c:      	mov.16b	v14, v20
     d80:      	fmla.4s	v20, v19, v24
     d84:      	mov.16b	v24, v13
     d88:      	fmla.4s	v18, v21, v16
     d8c:      	fmla.4s	v24, v21, v7
     d90:      	mov.16b	v7, v13
     d94:      	fmla.4s	v7, v19, v20
     d98:      	mov.16b	v16, v11
     d9c:      	fmla.4s	v16, v21, v24
     da0:      	fmla.4s	v22, v19, v17
     da4:      	mov.16b	v17, v11
     da8:      	fmla.4s	v17, v19, v7
     dac:      	mov.16b	v20, v10
     db0:      	fmla.4s	v20, v21, v16
     db4:      	mov.16b	v24, v10
     db8:      	fmla.4s	v23, v21, v18
     dbc:      	fmla.4s	v24, v19, v17
     dc0:      	movi.4s	v25, #0x3f, lsl #24
     dc4:      	movi.4s	v26, #0x3f, lsl #24
     dc8:      	mov.16b	v17, v8
     dcc:      	fcmge.4s	v7, v15, v4
     dd0:      	fmla.4s	v25, v21, v20
     dd4:      	fcmge.4s	v16, v15, v5
     dd8:      	and.16b	v18, v16, v5
     ddc:      	and.16b	v20, v7, v4
     de0:      	fcmge.4s	v27, v20, v9
     de4:      	fcmge.4s	v28, v18, v9
     de8:      	fcmge.4s	v29, v31, v18
     dec:      	and.16b	v28, v28, v29
     df0:      	fcmge.4s	v29, v31, v20
     df4:      	and.16b	v27, v27, v29
     df8:      	and.16b	v27, v27, v20
     dfc:      	and.16b	v28, v28, v18
     e00:      	fmla.4s	v6, v21, v23
     e04:      	ldr	q29, [sp, #0x1e0]
     e08:      	fmul.4s	v23, v28, v29
     e0c:      	fmul.4s	v29, v27, v29
     e10:      	movi.4s	v12, #0x4b, lsl #24
     e14:      	fadd.4s	v29, v29, v12
     e18:      	fadd.4s	v23, v23, v12
     e1c:      	movi.4s	v12, #0xcb, lsl #24
     e20:      	fadd.4s	v23, v23, v12
     e24:      	fmla.4s	v17, v21, v25
     e28:      	fadd.4s	v21, v29, v12
     e2c:      	fcvtzs.4s	v21, v21
     e30:      	fcvtzs.4s	v23, v23
     e34:      	scvtf.4s	v25, v23
     e38:      	scvtf.4s	v29, v21
     e3c:      	fmla.4s	v26, v19, v24
     e40:      	mov.16b	v12, v13
     e44:      	mov.16b	v13, v15
     e48:      	ldr	q15, [sp, #0x1d0]
     e4c:      	fmul.4s	v24, v25, v15
     e50:      	fadd.4s	v24, v28, v24
     e54:      	fmul.4s	v28, v29, v15
     e58:      	fadd.4s	v27, v27, v28
     e5c:      	mov.16b	v28, v8
     e60:      	fmla.4s	v28, v19, v22
     e64:      	ldr	q15, [sp, #0x1c0]
     e68:      	fmul.4s	v22, v29, v15
     e6c:      	fadd.4s	v22, v27, v22
     e70:      	fmul.4s	v25, v25, v15
     e74:      	mov.16b	v15, v13
     e78:      	mov.16b	v13, v12
     e7c:      	fadd.4s	v24, v24, v25
     e80:      	mov.16b	v25, v8
     e84:      	fmla.4s	v25, v19, v26
     e88:      	ldp	q27, q26, [sp, #0x1a0]
     e8c:      	fmul.4s	v19, v24, v26
     e90:      	fmul.4s	v26, v22, v26
     e94:      	fadd.4s	v26, v26, v27
     e98:      	fadd.4s	v19, v19, v27
     e9c:      	fmul.4s	v19, v24, v19
     ea0:      	fmul.4s	v27, v4, v28
     ea4:      	fmul.4s	v26, v22, v26
     ea8:      	ldp	q29, q28, [sp, #0x70]
     eac:      	fadd.4s	v26, v26, v28
     eb0:      	fadd.4s	v19, v19, v28
     eb4:      	fmul.4s	v19, v24, v19
     eb8:      	fmul.4s	v26, v22, v26
     ebc:      	ldr	q28, [sp, #0xc0]
     ec0:      	fadd.4s	v26, v26, v28
     ec4:      	fadd.4s	v19, v19, v28
     ec8:      	fmul.4s	v19, v24, v19
     ecc:      	fmul.4s	v26, v22, v26
     ed0:      	fadd.4s	v26, v26, v29
     ed4:      	fadd.4s	v28, v19, v29
     ed8:      	fdiv.4s	v19, v27, v25
     edc:      	fmul.4s	v25, v24, v28
     ee0:      	fmul.4s	v26, v22, v26
     ee4:      	movi.4s	v28, #0x3f, lsl #24
     ee8:      	fadd.4s	v26, v26, v28
     eec:      	fadd.4s	v25, v25, v28
     ef0:      	fmul.4s	v27, v24, v24
     ef4:      	fmul.4s	v25, v27, v25
     ef8:      	fmul.4s	v27, v22, v22
     efc:      	fmul.4s	v26, v27, v26
     f00:      	fadd.4s	v22, v22, v26
     f04:      	fadd.4s	v24, v24, v25
     f08:      	movi.2d	v27, #0xffffffffffffffff
     f0c:      	add.4s	v21, v21, v27
     f10:      	fadd.4s	v22, v22, v8
     f14:      	sshr.4s	v25, v21, #0x1
     f18:      	shl.4s	v26, v25, #0x17
     f1c:      	add.4s	v26, v26, v8
     f20:      	fmul.4s	v22, v22, v26
     f24:      	add.4s	v23, v23, v27
     f28:      	fadd.4s	v24, v24, v8
     f2c:      	sub.4s	v21, v21, v25
     f30:      	sshr.4s	v25, v23, #0x1
     f34:      	sub.4s	v23, v23, v25
     f38:      	shl.4s	v25, v25, #0x17
     f3c:      	add.4s	v25, v25, v8
     f40:      	fmul.4s	v24, v24, v25
     f44:      	shl.4s	v23, v23, #0x17
     f48:      	add.4s	v23, v23, v8
     f4c:      	fmul.4s	v23, v24, v23
     f50:      	shl.4s	v21, v21, #0x17
     f54:      	add.4s	v21, v21, v8
     f58:      	fmul.4s	v21, v22, v21
     f5c:      	fcmgt.4s	v20, v20, v31
     f60:      	ldp	q22, q24, [sp, #0xa0]
     f64:      	bsl.16b	v20, v24, v21
     f68:      	fmul.4s	v6, v5, v6
     f6c:      	fcmgt.4s	v18, v18, v31
     f70:      	bsl.16b	v18, v24, v23
     f74:      	fdiv.4s	v6, v6, v17
     f78:      	fdiv.4s	v17, v22, v18
     f7c:      	fsub.4s	v21, v18, v17
     f80:      	fadd.4s	v17, v18, v17
     f84:      	mov.16b	v18, v30
     f88:      	fdiv.4s	v17, v21, v17
     f8c:      	bsl.16b	v16, v17, v8
     f90:      	fcmge.4s	v5, v8, v5
     f94:      	bsl.16b	v5, v6, v16
     f98:      	fdiv.4s	v6, v22, v20
     f9c:      	fsub.4s	v16, v20, v6
     fa0:      	fadd.4s	v6, v20, v6
     fa4:      	mov.16b	v20, v14
     fa8:      	fdiv.4s	v6, v16, v6
     fac:      	bif.16b	v6, v8, v7
     fb0:      	fcmge.4s	v4, v8, v4
     fb4:      	bsl.16b	v4, v19, v6
     fb8:      	mvni.4s	v7, #0x80, lsl #24
     fbc:      	bif.16b	v4, v3, v7
     fc0:      	fcmeq.4s	v3, v3, v3
     fc4:      	fadd.4s	v4, v4, v8
     fc8:      	ldr	q6, [sp, #0x90]
     fcc:      	bsl.16b	v3, v4, v6
     fd0:      	mov.16b	v4, v7
     fd4:      	bsl.16b	v4, v5, v2
     fd8:      	fcmeq.4s	v2, v2, v2
     fdc:      	fadd.4s	v4, v4, v8
     fe0:      	bsl.16b	v2, v4, v6
     fe4:      	fmul.4s	v1, v1, v28
     fe8:      	fmul.4s	v1, v1, v2
     fec:      	fmul.4s	v0, v0, v28
     ff0:      	fmul.4s	v0, v0, v3
     ff4:      	add	x10, x28, x8
     ff8:      	ldp	q3, q2, [x10]
     ffc:      	fadd.4s	v0, v3, v0
    1000:      	fadd.4s	v1, v2, v1
    1004:      	add	x10, x9, x8
    1008:      	stp	q0, q1, [x10]
    100c:      	add	x8, x8, #0x20
    1010:      	cmp	x8, #0xc00
    1014:      	b.ne	0xcdc <ltmp0+0xcdc>
    1018:      	ldp	w1, w17, [sp, #0x3c]
    101c:      	ldr	x0, [sp, #0x48]
    1020:      	ldp	q25, q31, [sp, #0xe0]
    1024:      	b	0x1c4 <ltmp0+0x1c4>
    1028:      	mov.16b	v9, v25
    102c:      	mov.16b	v24, v31
    1030:      	str	w22, [sp, #0x2c]
    1034:      	lsr	x21, x23, #3
    1038:      	cmp	x23, #0x8
    103c:      	b.lo	0x13e4 <ltmp0+0x13e4>
    1040:      	mov	x24, #0x0               ; =0
    1044:      	ldr	x8, [sp, #0x20]
    1048:      	ldr	x26, [x8]
    104c:      	ldr	x25, [x8, #0x10]
    1050:      	ldr	x8, [x8, #0x30]
    1054:      	ldr	x9, [sp, #0x48]
    1058:      	lsl	w19, w9, #2
    105c:      	and	x9, x9, #0x7ffffff
    1060:      	mov	w10, #0x3000            ; =12288
    1064:      	umaddl	x20, w9, w10, x8
    1068:      	add	w8, w24, w19
    106c:      	and	x8, x8, #0x1fffffff
    1070:      	add	x8, x8, x8, lsl #1
    1074:      	lsl	x22, x8, #10
    1078:      	add	x0, sp, #0xe10
    107c:      	add	x1, x26, x22
    1080:      	mov	w2, #0xc00              ; =3072
    1084:      	bl	0x1084 <ltmp0+0x1084>
    1088:      	add	x0, sp, #0x210
    108c:      	add	x1, x25, x22
    1090:      	mov	w2, #0xc00              ; =3072
    1094:      	bl	0x1094 <ltmp0+0x1094>
    1098:      	ldp	q8, q10, [sp, #0x60]
    109c:      	ldr	q18, [sp, #0x50]
    10a0:      	mov	x8, #0x0                ; =0
    10a4:      	ldp	q13, q14, [sp, #0xc0]
    10a8:      	ldp	q12, q31, [sp, #0x80]
    10ac:      	ldp	q15, q30, [sp, #0xa0]
    10b0:      	add	x9, x27, x8
    10b4:      	ldp	q0, q1, [x9]
    10b8:      	ldp	q5, q3, [sp, #0xe0]
    10bc:      	fmul.4s	v2, v0, v3
    10c0:      	fmul.4s	v3, v1, v3
    10c4:      	fmul.4s	v3, v1, v3
    10c8:      	fmul.4s	v2, v0, v2
    10cc:      	fmul.4s	v2, v0, v2
    10d0:      	fmul.4s	v3, v1, v3
    10d4:      	fadd.4s	v4, v1, v3
    10d8:      	fadd.4s	v2, v0, v2
    10dc:      	fmul.4s	v3, v2, v5
    10e0:      	fmul.4s	v2, v4, v5
    10e4:      	fabs.4s	v5, v2
    10e8:      	fabs.4s	v4, v3
    10ec:      	fmul.4s	v19, v3, v3
    10f0:      	fmul.4s	v21, v2, v2
    10f4:      	ldp	q7, q16, [sp, #0x120]
    10f8:      	mov.16b	v6, v7
    10fc:      	fmla.4s	v6, v19, v16
    1100:      	fmla.4s	v7, v21, v16
    1104:      	ldr	q17, [sp, #0x110]
    1108:      	mov.16b	v16, v17
    110c:      	fmla.4s	v16, v19, v6
    1110:      	mov.16b	v6, v17
    1114:      	fmla.4s	v6, v21, v7
    1118:      	ldr	q17, [sp, #0x100]
    111c:      	mov.16b	v7, v17
    1120:      	fmla.4s	v7, v19, v16
    1124:      	mov.16b	v16, v17
    1128:      	fmla.4s	v16, v21, v6
    112c:      	mov.16b	v17, v18
    1130:      	mov.16b	v9, v18
    1134:      	mov.16b	v22, v10
    1138:      	mov.16b	v23, v10
    113c:      	mov.16b	v6, v8
    1140:      	fmla.4s	v17, v19, v7
    1144:      	ldp	q25, q20, [sp, #0x170]
    1148:      	mov.16b	v7, v20
    114c:      	ldr	q24, [sp, #0x1f0]
    1150:      	fmla.4s	v7, v21, v24
    1154:      	fmla.4s	v20, v19, v24
    1158:      	mov.16b	v24, v25
    115c:      	fmla.4s	v18, v21, v16
    1160:      	fmla.4s	v24, v21, v7
    1164:      	mov.16b	v7, v25
    1168:      	fmla.4s	v7, v19, v20
    116c:      	ldr	q20, [sp, #0x160]
    1170:      	mov.16b	v16, v20
    1174:      	fmla.4s	v16, v21, v24
    1178:      	fmla.4s	v22, v19, v17
    117c:      	mov.16b	v17, v20
    1180:      	fmla.4s	v17, v19, v7
    1184:      	ldp	q28, q24, [sp, #0x140]
    1188:      	mov.16b	v20, v24
    118c:      	fmla.4s	v20, v21, v16
    1190:      	fmla.4s	v23, v21, v18
    1194:      	fmla.4s	v24, v19, v17
    1198:      	movi.4s	v25, #0x3f, lsl #24
    119c:      	movi.4s	v26, #0x3f, lsl #24
    11a0:      	mov.16b	v17, v8
    11a4:      	ldr	q16, [sp, #0x190]
    11a8:      	fcmge.4s	v7, v16, v4
    11ac:      	fmla.4s	v25, v21, v20
    11b0:      	fcmge.4s	v16, v16, v5
    11b4:      	and.16b	v18, v16, v5
    11b8:      	and.16b	v20, v7, v4
    11bc:      	fcmge.4s	v27, v20, v28
    11c0:      	fcmge.4s	v28, v18, v28
    11c4:      	fcmge.4s	v29, v14, v18
    11c8:      	and.16b	v28, v28, v29
    11cc:      	fcmge.4s	v29, v14, v20
    11d0:      	and.16b	v27, v27, v29
    11d4:      	and.16b	v27, v27, v20
    11d8:      	and.16b	v28, v28, v18
    11dc:      	fmla.4s	v6, v21, v23
    11e0:      	ldr	q29, [sp, #0x1e0]
    11e4:      	fmul.4s	v23, v28, v29
    11e8:      	fmul.4s	v29, v27, v29
    11ec:      	movi.4s	v11, #0x4b, lsl #24
    11f0:      	fadd.4s	v29, v29, v11
    11f4:      	fadd.4s	v23, v23, v11
    11f8:      	movi.4s	v11, #0xcb, lsl #24
    11fc:      	fadd.4s	v23, v23, v11
    1200:      	fmla.4s	v17, v21, v25
    1204:      	fadd.4s	v21, v29, v11
    1208:      	fcvtzs.4s	v21, v21
    120c:      	fcvtzs.4s	v23, v23
    1210:      	scvtf.4s	v25, v23
    1214:      	scvtf.4s	v29, v21
    1218:      	fmla.4s	v26, v19, v24
    121c:      	ldr	q11, [sp, #0x1d0]
    1220:      	fmul.4s	v24, v25, v11
    1224:      	fadd.4s	v24, v28, v24
    1228:      	fmul.4s	v28, v29, v11
    122c:      	fadd.4s	v27, v27, v28
    1230:      	mov.16b	v28, v8
    1234:      	fmla.4s	v28, v19, v22
    1238:      	ldr	q11, [sp, #0x1c0]
    123c:      	fmul.4s	v22, v29, v11
    1240:      	fadd.4s	v22, v27, v22
    1244:      	fmul.4s	v25, v25, v11
    1248:      	fadd.4s	v24, v24, v25
    124c:      	mov.16b	v25, v8
    1250:      	fmla.4s	v25, v19, v26
    1254:      	ldp	q27, q26, [sp, #0x1a0]
    1258:      	fmul.4s	v19, v24, v26
    125c:      	fmul.4s	v26, v22, v26
    1260:      	fadd.4s	v26, v26, v27
    1264:      	fadd.4s	v19, v19, v27
    1268:      	fmul.4s	v19, v24, v19
    126c:      	fmul.4s	v27, v4, v28
    1270:      	fmul.4s	v26, v22, v26
    1274:      	fadd.4s	v26, v26, v12
    1278:      	fadd.4s	v19, v19, v12
    127c:      	fmul.4s	v19, v24, v19
    1280:      	fmul.4s	v26, v22, v26
    1284:      	fadd.4s	v26, v26, v13
    1288:      	fadd.4s	v19, v19, v13
    128c:      	fmul.4s	v19, v24, v19
    1290:      	fmul.4s	v26, v22, v26
    1294:      	fadd.4s	v26, v26, v10
    1298:      	fadd.4s	v28, v19, v10
    129c:      	fdiv.4s	v19, v27, v25
    12a0:      	fmul.4s	v25, v24, v28
    12a4:      	movi.4s	v28, #0x3f, lsl #24
    12a8:      	fmul.4s	v26, v22, v26
    12ac:      	fadd.4s	v26, v26, v28
    12b0:      	fadd.4s	v25, v25, v28
    12b4:      	fmul.4s	v27, v24, v24
    12b8:      	fmul.4s	v25, v27, v25
    12bc:      	fmul.4s	v27, v22, v22
    12c0:      	fmul.4s	v26, v27, v26
    12c4:      	fadd.4s	v22, v22, v26
    12c8:      	fadd.4s	v24, v24, v25
    12cc:      	movi.2d	v27, #0xffffffffffffffff
    12d0:      	add.4s	v21, v21, v27
    12d4:      	fadd.4s	v22, v22, v8
    12d8:      	sshr.4s	v25, v21, #0x1
    12dc:      	shl.4s	v26, v25, #0x17
    12e0:      	add.4s	v26, v26, v8
    12e4:      	fmul.4s	v22, v22, v26
    12e8:      	add.4s	v23, v23, v27
    12ec:      	fadd.4s	v24, v24, v8
    12f0:      	sub.4s	v21, v21, v25
    12f4:      	sshr.4s	v25, v23, #0x1
    12f8:      	sub.4s	v23, v23, v25
    12fc:      	shl.4s	v25, v25, #0x17
    1300:      	add.4s	v25, v25, v8
    1304:      	fmul.4s	v24, v24, v25
    1308:      	shl.4s	v23, v23, #0x17
    130c:      	add.4s	v23, v23, v8
    1310:      	fmul.4s	v23, v24, v23
    1314:      	shl.4s	v21, v21, #0x17
    1318:      	add.4s	v21, v21, v8
    131c:      	fmul.4s	v21, v22, v21
    1320:      	fcmgt.4s	v20, v20, v14
    1324:      	bsl.16b	v20, v30, v21
    1328:      	fmul.4s	v6, v5, v6
    132c:      	fcmgt.4s	v18, v18, v14
    1330:      	bsl.16b	v18, v30, v23
    1334:      	fdiv.4s	v6, v6, v17
    1338:      	fdiv.4s	v17, v15, v18
    133c:      	fsub.4s	v21, v18, v17
    1340:      	fadd.4s	v17, v18, v17
    1344:      	mov.16b	v18, v9
    1348:      	fdiv.4s	v17, v21, v17
    134c:      	bsl.16b	v16, v17, v8
    1350:      	fcmge.4s	v5, v8, v5
    1354:      	bsl.16b	v5, v6, v16
    1358:      	fdiv.4s	v6, v15, v20
    135c:      	fsub.4s	v16, v20, v6
    1360:      	fadd.4s	v6, v20, v6
    1364:      	fdiv.4s	v6, v16, v6
    1368:      	bif.16b	v6, v8, v7
    136c:      	fcmge.4s	v4, v8, v4
    1370:      	bsl.16b	v4, v19, v6
    1374:      	mvni.4s	v6, #0x80, lsl #24
    1378:      	bif.16b	v4, v3, v6
    137c:      	fcmeq.4s	v3, v3, v3
    1380:      	fadd.4s	v4, v4, v8
    1384:      	bsl.16b	v3, v4, v31
    1388:      	mov.16b	v4, v6
    138c:      	bsl.16b	v4, v5, v2
    1390:      	fcmeq.4s	v2, v2, v2
    1394:      	fadd.4s	v4, v4, v8
    1398:      	bsl.16b	v2, v4, v31
    139c:      	fmul.4s	v1, v1, v28
    13a0:      	fmul.4s	v1, v1, v2
    13a4:      	fmul.4s	v0, v0, v28
    13a8:      	fmul.4s	v0, v0, v3
    13ac:      	add	x9, x28, x8
    13b0:      	ldp	q3, q2, [x9]
    13b4:      	fadd.4s	v0, v3, v0
    13b8:      	fadd.4s	v1, v2, v1
    13bc:      	add	x9, x20, x8
    13c0:      	stp	q0, q1, [x9]
    13c4:      	add	x8, x8, #0x20
    13c8:      	cmp	x8, #0xc00
    13cc:      	b.ne	0x10b0 <ltmp0+0x10b0>
    13d0:      	ldp	q9, q24, [sp, #0xe0]
    13d4:      	add	x24, x24, #0x1
    13d8:      	add	x20, x20, #0xc00
    13dc:      	cmp	x24, x21
    13e0:      	b.ne	0x1068 <ltmp0+0x1068>
    13e4:      	and	w8, w23, #0x7
    13e8:      	ldr	w20, [sp, #0x1c]
    13ec:      	ldr	w22, [sp, #0x2c]
    13f0:      	ldp	w1, w17, [sp, #0x3c]
    13f4:      	ldp	q20, q15, [sp, #0x180]
    13f8:      	ldp	q11, q13, [sp, #0x160]
    13fc:      	ldp	q22, q14, [sp, #0x140]
    1400:      	ldp	q28, q27, [sp, #0x1b0]
    1404:      	ldr	q29, [sp, #0x1a0]
    1408:      	ldp	q30, q23, [sp, #0x80]
    140c:      	ldr	q21, [sp, #0xc0]
    1410:      	ldr	x0, [sp, #0x48]
    1414:      	mov.16b	v31, v24
    1418:      	mov.16b	v25, v9
    141c:      	cbz	w8, 0x1c4 <ltmp0+0x1c4>
    1420:      	dup.4s	v1, w8
    1424:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1428:      	ldr	q2, [x8]
    142c:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1430:      	ldr	q0, [x8]
    1434:      	cmhi.4s	v0, v1, v0
    1438:      	cmhi.4s	v1, v1, v2
    143c:      	uzp1.8h	v3, v1, v0
    1440:      	umaxv.8h	h2, v3
    1444:      	fmov	w8, s2
    1448:      	tbz	w8, #0x0, 0x1c4 <ltmp0+0x1c4>
    144c:      	mov.16b	v10, v13
    1450:      	mov	x11, #0x0               ; =0
    1454:      	ldr	x9, [sp, #0x20]
    1458:      	ldr	x10, [x9, #0x10]
    145c:      	ldr	x8, [x9, #0x30]
    1460:      	ldr	x12, [x9]
    1464:      	ubfiz	w9, w0, #2, #27
    1468:      	orr	w9, w9, w21
    146c:      	fmov	s2, w9
    1470:      	and.16b	v2, v1, v2
    1474:      	fmov	w13, s2
    1478:      	mov	w14, #0xc00             ; =3072
    147c:      	umull	x9, w13, w14
    1480:      	umaddl	x12, w13, w14, x12
    1484:      	adrp	x16, 0x1000 <ltmp0+0x1000>
    1488:      	b	0x14ac <ltmp0+0x14ac>
    148c:      	add	x13, x27, x11
    1490:      	ldp	q6, q7, [x13]
    1494:      	bif.16b	v5, v7, v0
    1498:      	bif.16b	v4, v6, v1
    149c:      	stp	q4, q5, [x13]
    14a0:      	add	x11, x11, #0x20
    14a4:      	cmp	x11, #0xc00
    14a8:      	b.eq	0x1550 <ltmp0+0x1550>
    14ac:      	ldr	q2, [x16]
    14b0:      	and.16b	v2, v3, v2
    14b4:      	addv.8h	h2, v2
    14b8:      	fmov	w14, s2
    14bc:      	add	x13, x12, x11
    14c0:      	movi.2d	v4, #0000000000000000
    14c4:      	movi.2d	v5, #0000000000000000
    14c8:      	tbnz	w14, #0x0, 0x14f0 <ltmp0+0x14f0>
    14cc:      	and	w14, w14, #0xff
    14d0:      	tbnz	w14, #0x1, 0x14fc <ltmp0+0x14fc>
    14d4:      	tbnz	w14, #0x2, 0x1508 <ltmp0+0x1508>
    14d8:      	tbnz	w14, #0x3, 0x1514 <ltmp0+0x1514>
    14dc:      	tbnz	w14, #0x4, 0x1520 <ltmp0+0x1520>
    14e0:      	tbnz	w14, #0x5, 0x152c <ltmp0+0x152c>
    14e4:      	tbnz	w14, #0x6, 0x1538 <ltmp0+0x1538>
    14e8:      	tbz	w14, #0x7, 0x148c <ltmp0+0x148c>
    14ec:      	b	0x1544 <ltmp0+0x1544>
    14f0:      	ldr	s4, [x13]
    14f4:      	and	w14, w14, #0xff
    14f8:      	tbz	w14, #0x1, 0x14d4 <ltmp0+0x14d4>
    14fc:      	add	x15, x13, #0x4
    1500:      	ld1.s	{ v4 }[1], [x15]
    1504:      	tbz	w14, #0x2, 0x14d8 <ltmp0+0x14d8>
    1508:      	add	x15, x13, #0x8
    150c:      	ld1.s	{ v4 }[2], [x15]
    1510:      	tbz	w14, #0x3, 0x14dc <ltmp0+0x14dc>
    1514:      	add	x15, x13, #0xc
    1518:      	ld1.s	{ v4 }[3], [x15]
    151c:      	tbz	w14, #0x4, 0x14e0 <ltmp0+0x14e0>
    1520:      	add	x15, x13, #0x10
    1524:      	ld1.s	{ v5 }[0], [x15]
    1528:      	tbz	w14, #0x5, 0x14e4 <ltmp0+0x14e4>
    152c:      	add	x15, x13, #0x14
    1530:      	ld1.s	{ v5 }[1], [x15]
    1534:      	tbz	w14, #0x6, 0x14e8 <ltmp0+0x14e8>
    1538:      	add	x15, x13, #0x18
    153c:      	ld1.s	{ v5 }[2], [x15]
    1540:      	tbz	w14, #0x7, 0x148c <ltmp0+0x148c>
    1544:      	add	x13, x13, #0x1c
    1548:      	ld1.s	{ v5 }[3], [x13]
    154c:      	b	0x148c <ltmp0+0x148c>
    1550:      	mov	x11, #0x0               ; =0
    1554:      	add	x10, x10, x9
    1558:      	b	0x157c <ltmp0+0x157c>
    155c:      	add	x12, x28, x11
    1560:      	ldp	q5, q6, [x12]
    1564:      	bif.16b	v4, v6, v0
    1568:      	bif.16b	v3, v5, v1
    156c:      	stp	q3, q4, [x12]
    1570:      	add	x11, x11, #0x20
    1574:      	cmp	x11, #0xc00
    1578:      	b.eq	0x1614 <ltmp0+0x1614>
    157c:      	fmov	w13, s2
    1580:      	add	x12, x10, x11
    1584:      	movi.2d	v3, #0000000000000000
    1588:      	movi.2d	v4, #0000000000000000
    158c:      	tbnz	w13, #0x0, 0x15b4 <ltmp0+0x15b4>
    1590:      	and	w13, w13, #0xff
    1594:      	tbnz	w13, #0x1, 0x15c0 <ltmp0+0x15c0>
    1598:      	tbnz	w13, #0x2, 0x15cc <ltmp0+0x15cc>
    159c:      	tbnz	w13, #0x3, 0x15d8 <ltmp0+0x15d8>
    15a0:      	tbnz	w13, #0x4, 0x15e4 <ltmp0+0x15e4>
    15a4:      	tbnz	w13, #0x5, 0x15f0 <ltmp0+0x15f0>
    15a8:      	tbnz	w13, #0x6, 0x15fc <ltmp0+0x15fc>
    15ac:      	tbz	w13, #0x7, 0x155c <ltmp0+0x155c>
    15b0:      	b	0x1608 <ltmp0+0x1608>
    15b4:      	ldr	s3, [x12]
    15b8:      	and	w13, w13, #0xff
    15bc:      	tbz	w13, #0x1, 0x1598 <ltmp0+0x1598>
    15c0:      	add	x14, x12, #0x4
    15c4:      	ld1.s	{ v3 }[1], [x14]
    15c8:      	tbz	w13, #0x2, 0x159c <ltmp0+0x159c>
    15cc:      	add	x14, x12, #0x8
    15d0:      	ld1.s	{ v3 }[2], [x14]
    15d4:      	tbz	w13, #0x3, 0x15a0 <ltmp0+0x15a0>
    15d8:      	add	x14, x12, #0xc
    15dc:      	ld1.s	{ v3 }[3], [x14]
    15e0:      	tbz	w13, #0x4, 0x15a4 <ltmp0+0x15a4>
    15e4:      	add	x14, x12, #0x10
    15e8:      	ld1.s	{ v4 }[0], [x14]
    15ec:      	tbz	w13, #0x5, 0x15a8 <ltmp0+0x15a8>
    15f0:      	add	x14, x12, #0x14
    15f4:      	ld1.s	{ v4 }[1], [x14]
    15f8:      	tbz	w13, #0x6, 0x15ac <ltmp0+0x15ac>
    15fc:      	add	x14, x12, #0x18
    1600:      	ld1.s	{ v4 }[2], [x14]
    1604:      	tbz	w13, #0x7, 0x155c <ltmp0+0x155c>
    1608:      	add	x12, x12, #0x1c
    160c:      	ld1.s	{ v4 }[3], [x12]
    1610:      	b	0x155c <ltmp0+0x155c>
    1614:      	mov	x10, #0x0               ; =0
    1618:      	add	x8, x8, x9
    161c:      	b	0x162c <ltmp0+0x162c>
    1620:      	add	x10, x10, #0x20
    1624:      	cmp	x10, #0xc00
    1628:      	b.eq	0x1c4 <ltmp0+0x1c4>
    162c:      	add	x9, x27, x10
    1630:      	ldr	q3, [x9]
    1634:      	and.16b	v3, v1, v3
    1638:      	fmul.4s	v4, v3, v31
    163c:      	fmul.4s	v4, v3, v4
    1640:      	fmul.4s	v4, v3, v4
    1644:      	fadd.4s	v4, v3, v4
    1648:      	mov.16b	v26, v25
    164c:      	fmul.4s	v4, v4, v25
    1650:      	and.16b	v4, v1, v4
    1654:      	fabs.4s	v5, v4
    1658:      	fmul.4s	v6, v4, v4
    165c:      	ldp	q7, q16, [sp, #0x120]
    1660:      	fmla.4s	v7, v6, v16
    1664:      	ldr	q16, [sp, #0x110]
    1668:      	fmla.4s	v16, v6, v7
    166c:      	ldr	q7, [sp, #0x100]
    1670:      	fmla.4s	v7, v6, v16
    1674:      	mov.16b	v13, v18
    1678:      	mov.16b	v16, v18
    167c:      	fmla.4s	v16, v6, v7
    1680:      	ldr	q25, [sp, #0x70]
    1684:      	mov.16b	v7, v25
    1688:      	fmla.4s	v7, v6, v16
    168c:      	mov.16b	v16, v8
    1690:      	fmla.4s	v16, v6, v7
    1694:      	fmul.4s	v7, v5, v16
    1698:      	mov.16b	v9, v20
    169c:      	mov.16b	v16, v20
    16a0:      	ldr	q17, [sp, #0x1f0]
    16a4:      	fmla.4s	v16, v6, v17
    16a8:      	mov.16b	v17, v10
    16ac:      	fmla.4s	v17, v6, v16
    16b0:      	mov.16b	v12, v11
    16b4:      	fmla.4s	v11, v6, v17
    16b8:      	mov.16b	v17, v14
    16bc:      	fmla.4s	v17, v6, v11
    16c0:      	movi.4s	v16, #0x3f, lsl #24
    16c4:      	fmla.4s	v16, v6, v17
    16c8:      	mov.16b	v17, v8
    16cc:      	fmla.4s	v17, v6, v16
    16d0:      	fdiv.4s	v6, v7, v17
    16d4:      	fcmge.4s	v7, v15, v5
    16d8:      	and.16b	v16, v7, v5
    16dc:      	fcmge.4s	v17, v16, v22
    16e0:      	ldr	q11, [sp, #0xd0]
    16e4:      	fcmge.4s	v18, v11, v16
    16e8:      	and.16b	v17, v17, v18
    16ec:      	and.16b	v17, v17, v16
    16f0:      	ldp	q20, q18, [sp, #0x1d0]
    16f4:      	fmul.4s	v18, v17, v18
    16f8:      	movi.4s	v19, #0x4b, lsl #24
    16fc:      	fadd.4s	v18, v18, v19
    1700:      	movi.4s	v19, #0xcb, lsl #24
    1704:      	fadd.4s	v18, v18, v19
    1708:      	fcvtzs.4s	v18, v18
    170c:      	scvtf.4s	v19, v18
    1710:      	fmul.4s	v20, v19, v20
    1714:      	fadd.4s	v17, v17, v20
    1718:      	fmul.4s	v19, v19, v27
    171c:      	fadd.4s	v17, v17, v19
    1720:      	fmul.4s	v19, v17, v28
    1724:      	fadd.4s	v19, v19, v29
    1728:      	fmul.4s	v19, v17, v19
    172c:      	fadd.4s	v19, v19, v30
    1730:      	fmul.4s	v19, v17, v19
    1734:      	fadd.4s	v19, v19, v21
    1738:      	fmul.4s	v19, v17, v19
    173c:      	fadd.4s	v19, v19, v25
    1740:      	fmul.4s	v19, v17, v19
    1744:      	movi.4s	v21, #0x3f, lsl #24
    1748:      	fadd.4s	v19, v19, v21
    174c:      	fmul.4s	v20, v17, v17
    1750:      	fmul.4s	v19, v20, v19
    1754:      	fadd.4s	v17, v17, v19
    1758:      	fadd.4s	v17, v17, v8
    175c:      	movi.2d	v19, #0xffffffffffffffff
    1760:      	add.4s	v18, v18, v19
    1764:      	sshr.4s	v19, v18, #0x1
    1768:      	shl.4s	v20, v19, #0x17
    176c:      	add.4s	v20, v20, v8
    1770:      	fmul.4s	v17, v17, v20
    1774:      	sub.4s	v18, v18, v19
    1778:      	shl.4s	v18, v18, #0x17
    177c:      	add.4s	v18, v18, v8
    1780:      	fmul.4s	v17, v17, v18
    1784:      	fcmgt.4s	v16, v16, v11
    1788:      	ldr	q18, [sp, #0xb0]
    178c:      	bsl.16b	v16, v18, v17
    1790:      	ldr	q17, [sp, #0xa0]
    1794:      	fdiv.4s	v17, v17, v16
    1798:      	fsub.4s	v18, v16, v17
    179c:      	fadd.4s	v16, v16, v17
    17a0:      	fdiv.4s	v16, v18, v16
    17a4:      	bsl.16b	v7, v16, v8
    17a8:      	fcmge.4s	v5, v8, v5
    17ac:      	bsl.16b	v5, v6, v7
    17b0:      	mvni.4s	v6, #0x80, lsl #24
    17b4:      	bif.16b	v5, v4, v6
    17b8:      	fcmeq.4s	v4, v4, v4
    17bc:      	fadd.4s	v5, v5, v8
    17c0:      	bif.16b	v5, v23, v4
    17c4:      	ldr	q4, [x9, #0x10]
    17c8:      	fmul.4s	v3, v3, v21
    17cc:      	fmul.4s	v3, v3, v5
    17d0:      	add	x9, x28, x10
    17d4:      	ldr	q5, [x9]
    17d8:      	and.16b	v5, v1, v5
    17dc:      	fadd.4s	v5, v5, v3
    17e0:      	ldr	q3, [x9, #0x10]
    17e4:      	fmov	w11, s2
    17e8:      	add	x9, x8, x10
    17ec:      	tbnz	w11, #0x0, 0x19d4 <ltmp0+0x19d4>
    17f0:      	and	w11, w11, #0xff
    17f4:      	tbnz	w11, #0x1, 0x19e0 <ltmp0+0x19e0>
    17f8:      	mov.16b	v18, v13
    17fc:      	mov.16b	v19, v9
    1800:      	mov.16b	v25, v26
    1804:      	tbnz	w11, #0x2, 0x19f8 <ltmp0+0x19f8>
    1808:      	mvni.4s	v23, #0x80, lsl #24
    180c:      	tbz	w11, #0x3, 0x1818 <ltmp0+0x1818>
    1810:      	add	x12, x9, #0xc
    1814:      	st1.s	{ v5 }[3], [x12]
    1818:      	and.16b	v4, v0, v4
    181c:      	fmul.4s	v5, v4, v31
    1820:      	fmul.4s	v5, v4, v5
    1824:      	fmul.4s	v5, v4, v5
    1828:      	fadd.4s	v5, v4, v5
    182c:      	fmul.4s	v5, v5, v25
    1830:      	and.16b	v5, v0, v5
    1834:      	fabs.4s	v6, v5
    1838:      	fmul.4s	v7, v5, v5
    183c:      	ldp	q16, q17, [sp, #0x120]
    1840:      	fmla.4s	v16, v7, v17
    1844:      	ldr	q17, [sp, #0x110]
    1848:      	fmla.4s	v17, v7, v16
    184c:      	ldr	q16, [sp, #0x100]
    1850:      	fmla.4s	v16, v7, v17
    1854:      	mov.16b	v17, v18
    1858:      	fmla.4s	v17, v7, v16
    185c:      	ldr	q31, [sp, #0x70]
    1860:      	mov.16b	v16, v31
    1864:      	fmla.4s	v16, v7, v17
    1868:      	mov.16b	v17, v8
    186c:      	fmla.4s	v17, v7, v16
    1870:      	fmul.4s	v16, v6, v17
    1874:      	mov.16b	v17, v19
    1878:      	ldr	q18, [sp, #0x1f0]
    187c:      	fmla.4s	v17, v7, v18
    1880:      	mov.16b	v18, v10
    1884:      	fmla.4s	v18, v7, v17
    1888:      	mov.16b	v17, v12
    188c:      	fmla.4s	v17, v7, v18
    1890:      	mov.16b	v18, v14
    1894:      	fmla.4s	v18, v7, v17
    1898:      	movi.4s	v17, #0x3f, lsl #24
    189c:      	fmla.4s	v17, v7, v18
    18a0:      	mov.16b	v18, v8
    18a4:      	fmla.4s	v18, v7, v17
    18a8:      	fdiv.4s	v7, v16, v18
    18ac:      	fcmge.4s	v16, v15, v6
    18b0:      	and.16b	v17, v16, v6
    18b4:      	fcmge.4s	v18, v17, v22
    18b8:      	fcmge.4s	v19, v11, v17
    18bc:      	and.16b	v18, v18, v19
    18c0:      	and.16b	v18, v18, v17
    18c4:      	ldp	q21, q19, [sp, #0x1d0]
    18c8:      	fmul.4s	v19, v18, v19
    18cc:      	movi.4s	v20, #0x4b, lsl #24
    18d0:      	fadd.4s	v19, v19, v20
    18d4:      	movi.4s	v20, #0xcb, lsl #24
    18d8:      	fadd.4s	v19, v19, v20
    18dc:      	fcvtzs.4s	v19, v19
    18e0:      	scvtf.4s	v20, v19
    18e4:      	fmul.4s	v21, v20, v21
    18e8:      	fadd.4s	v18, v18, v21
    18ec:      	fmul.4s	v20, v20, v27
    18f0:      	fadd.4s	v18, v18, v20
    18f4:      	fmul.4s	v20, v18, v28
    18f8:      	fadd.4s	v20, v20, v29
    18fc:      	fmul.4s	v20, v18, v20
    1900:      	fadd.4s	v20, v20, v30
    1904:      	fmul.4s	v20, v18, v20
    1908:      	ldr	q21, [sp, #0xc0]
    190c:      	fadd.4s	v20, v20, v21
    1910:      	fmul.4s	v20, v18, v20
    1914:      	fadd.4s	v20, v20, v31
    1918:      	fmul.4s	v20, v18, v20
    191c:      	movi.4s	v31, #0x3f, lsl #24
    1920:      	fadd.4s	v20, v20, v31
    1924:      	fmul.4s	v21, v18, v18
    1928:      	fmul.4s	v20, v21, v20
    192c:      	fadd.4s	v18, v18, v20
    1930:      	fadd.4s	v18, v18, v8
    1934:      	movi.2d	v20, #0xffffffffffffffff
    1938:      	add.4s	v19, v19, v20
    193c:      	sshr.4s	v20, v19, #0x1
    1940:      	shl.4s	v21, v20, #0x17
    1944:      	add.4s	v21, v21, v8
    1948:      	fmul.4s	v18, v18, v21
    194c:      	sub.4s	v19, v19, v20
    1950:      	shl.4s	v19, v19, #0x17
    1954:      	add.4s	v19, v19, v8
    1958:      	fmul.4s	v18, v18, v19
    195c:      	fcmgt.4s	v17, v17, v11
    1960:      	ldr	q19, [sp, #0xb0]
    1964:      	bsl.16b	v17, v19, v18
    1968:      	ldr	q18, [sp, #0xa0]
    196c:      	fdiv.4s	v18, v18, v17
    1970:      	fsub.4s	v19, v17, v18
    1974:      	fadd.4s	v17, v17, v18
    1978:      	fdiv.4s	v17, v19, v17
    197c:      	bsl.16b	v16, v17, v8
    1980:      	fcmge.4s	v6, v8, v6
    1984:      	bsl.16b	v6, v7, v16
    1988:      	bif.16b	v6, v5, v23
    198c:      	fcmeq.4s	v5, v5, v5
    1990:      	fadd.4s	v6, v6, v8
    1994:      	ldr	q23, [sp, #0x90]
    1998:      	bsl.16b	v5, v6, v23
    199c:      	fmul.4s	v4, v4, v31
    19a0:      	fmul.4s	v4, v4, v5
    19a4:      	and.16b	v3, v0, v3
    19a8:      	fadd.4s	v3, v3, v4
    19ac:      	tbnz	w11, #0x4, 0x1a0c <ltmp0+0x1a0c>
    19b0:      	tbnz	w11, #0x5, 0x1a14 <ltmp0+0x1a14>
    19b4:      	ldr	q21, [sp, #0xc0]
    19b8:      	mov.16b	v31, v24
    19bc:      	mov.16b	v18, v13
    19c0:      	mov.16b	v20, v9
    19c4:      	mov.16b	v11, v12
    19c8:      	tbnz	w11, #0x6, 0x1a34 <ltmp0+0x1a34>
    19cc:      	tbz	w11, #0x7, 0x1620 <ltmp0+0x1620>
    19d0:      	b	0x1a40 <ltmp0+0x1a40>
    19d4:      	str	s5, [x9]
    19d8:      	and	w11, w11, #0xff
    19dc:      	tbz	w11, #0x1, 0x17f8 <ltmp0+0x17f8>
    19e0:      	add	x12, x9, #0x4
    19e4:      	st1.s	{ v5 }[1], [x12]
    19e8:      	mov.16b	v18, v13
    19ec:      	mov.16b	v19, v9
    19f0:      	mov.16b	v25, v26
    19f4:      	tbz	w11, #0x2, 0x1808 <ltmp0+0x1808>
    19f8:      	add	x12, x9, #0x8
    19fc:      	st1.s	{ v5 }[2], [x12]
    1a00:      	mvni.4s	v23, #0x80, lsl #24
    1a04:      	tbnz	w11, #0x3, 0x1810 <ltmp0+0x1810>
    1a08:      	b	0x1818 <ltmp0+0x1818>
    1a0c:      	str	s3, [x9, #0x10]
    1a10:      	tbz	w11, #0x5, 0x19b4 <ltmp0+0x19b4>
    1a14:      	add	x12, x9, #0x14
    1a18:      	st1.s	{ v3 }[1], [x12]
    1a1c:      	ldr	q21, [sp, #0xc0]
    1a20:      	mov.16b	v31, v24
    1a24:      	mov.16b	v18, v13
    1a28:      	mov.16b	v20, v9
    1a2c:      	mov.16b	v11, v12
    1a30:      	tbz	w11, #0x6, 0x19cc <ltmp0+0x19cc>
    1a34:      	add	x12, x9, #0x18
    1a38:      	st1.s	{ v3 }[2], [x12]
    1a3c:      	tbz	w11, #0x7, 0x1620 <ltmp0+0x1620>
    1a40:      	add	x9, x9, #0x1c
    1a44:      	st1.s	{ v3 }[3], [x9]
    1a48:      	b	0x1620 <ltmp0+0x1620>
    1a4c:      	ldr	x9, [sp, #0x10]
    1a50:      	stp	w0, w17, [x9]
    1a54:      	str	w12, [x9, #0x8]
    1a58:      	mov	w8, #0x18               ; =24
    1a5c:      	str	w8, [x9, #0x24]
    1a60:      	add	sp, sp, #0x1, lsl #12   ; =0x1000
    1a64:      	add	sp, sp, #0xa10
    1a68:      	ldp	x29, x30, [sp, #0x90]
    1a6c:      	ldp	x20, x19, [sp, #0x80]
    1a70:      	ldp	x22, x21, [sp, #0x70]
    1a74:      	ldp	x24, x23, [sp, #0x60]
    1a78:      	ldp	x26, x25, [sp, #0x50]
    1a7c:      	ldp	x28, x27, [sp, #0x40]
    1a80:      	ldp	d9, d8, [sp, #0x30]
    1a84:      	ldp	d11, d10, [sp, #0x20]
    1a88:      	ldp	d13, d12, [sp, #0x10]
    1a8c:      	ldp	d15, d14, [sp], #0xa0
    1a90:      	ret

declare <4 x float> @llvm.roundeven.v4f32(<4 x float>)
define <4 x float> @round_probe(<4 x float> %x) {
entry:
  %y = call <4 x float> @llvm.roundeven.v4f32(<4 x float> %x)
  ret <4 x float> %y
}

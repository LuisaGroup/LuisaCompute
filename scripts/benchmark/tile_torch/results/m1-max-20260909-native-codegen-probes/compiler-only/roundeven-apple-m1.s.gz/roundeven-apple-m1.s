	.section	__TEXT,__text,regular,pure_instructions
	.globl	_round_probe                    ; -- Begin function round_probe
	.p2align	2
_round_probe:                           ; @round_probe
	.cfi_startproc
; %bb.0:                                ; %entry
	frintn.4s	v0, v0
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols

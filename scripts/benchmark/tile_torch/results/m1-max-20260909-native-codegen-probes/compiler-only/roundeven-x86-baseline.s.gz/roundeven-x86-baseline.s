	.file	"roundeven-probe.ll"
	.text
	.globl	round_probe                     # -- Begin function round_probe
	.p2align	4
	.type	round_probe,@function
round_probe:                            # @round_probe
	.cfi_startproc
# %bb.0:                                # %entry
	subq	$56, %rsp
	.cfi_def_cfa_offset 64
	movaps	%xmm0, 16(%rsp)                 # 16-byte Spill
	shufps	$255, %xmm0, %xmm0              # xmm0 = xmm0[3,3,3,3]
	callq	roundevenf@PLT
	movaps	%xmm0, (%rsp)                   # 16-byte Spill
	movaps	16(%rsp), %xmm0                 # 16-byte Reload
	movhlps	%xmm0, %xmm0                    # xmm0 = xmm0[1,1]
	callq	roundevenf@PLT
	unpcklps	(%rsp), %xmm0                   # 16-byte Folded Reload
                                        # xmm0 = xmm0[0],mem[0],xmm0[1],mem[1]
	movaps	%xmm0, (%rsp)                   # 16-byte Spill
	movaps	16(%rsp), %xmm0                 # 16-byte Reload
	callq	roundevenf@PLT
	movaps	%xmm0, 32(%rsp)                 # 16-byte Spill
	movaps	16(%rsp), %xmm0                 # 16-byte Reload
	shufps	$85, %xmm0, %xmm0               # xmm0 = xmm0[1,1,1,1]
	callq	roundevenf@PLT
	movaps	32(%rsp), %xmm1                 # 16-byte Reload
	unpcklps	%xmm0, %xmm1                    # xmm1 = xmm1[0],xmm0[0],xmm1[1],xmm0[1]
	unpcklpd	(%rsp), %xmm1                   # 16-byte Folded Reload
                                        # xmm1 = xmm1[0],mem[0]
	movaps	%xmm1, %xmm0
	addq	$56, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end0:
	.size	round_probe, .Lfunc_end0-round_probe
	.cfi_endproc
                                        # -- End function
	.section	".note.GNU-stack","",@progbits

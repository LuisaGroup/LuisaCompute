	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_3:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_4:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_5:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_6:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d9, d8, [sp, #-112]!            ; 16-byte Folded Spill
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #2256
	str	x0, [sp, #72]                   ; 8-byte Folded Spill
	str	w3, [sp, #104]                  ; 4-byte Folded Spill
	cbz	w3, LBB0_235
; %bb.1:                                ; %block.batch.loop.preheader
	mov	w12, #0                         ; =0x0
	ldp	w9, w8, [x2, #44]
	stp	w8, w9, [sp, #96]               ; 8-byte Folded Spill
	ldp	w8, w9, [x2]
	movi.2s	v8, #3, lsl #8
	add	x28, sp, #1, lsl #12            ; =4096
	add	x28, x28, #720
	add	x4, sp, #3280
	add	x27, sp, #1744
	add	x24, sp, #208
Lloh0:
	adrp	x10, lCPI0_0@PAGE
Lloh1:
	ldr	q0, [x10, lCPI0_0@PAGEOFF]
	str	q0, [sp, #48]                   ; 16-byte Folded Spill
Lloh2:
	adrp	x10, lCPI0_1@PAGE
Lloh3:
	ldr	q0, [x10, lCPI0_1@PAGEOFF]
	str	q0, [sp, #32]                   ; 16-byte Folded Spill
Lloh4:
	adrp	x10, lCPI0_5@PAGE
Lloh5:
	ldr	q0, [x10, lCPI0_5@PAGEOFF]
	str	q0, [sp, #16]                   ; 16-byte Folded Spill
Lloh6:
	adrp	x10, lCPI0_6@PAGE
Lloh7:
	ldr	q0, [x10, lCPI0_6@PAGEOFF]
	str	q0, [sp, #128]                  ; 16-byte Folded Spill
	ldp	w10, w11, [x2, #8]
	str	x2, [sp, #8]                    ; 8-byte Folded Spill
	str	x11, [sp, #88]                  ; 8-byte Folded Spill
	b	LBB0_3
LBB0_2:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x15, [sp, #120]                 ; 8-byte Folded Reload
	add	w8, w15, #1
	ldp	w11, w9, [sp, #96]              ; 8-byte Folded Reload
	cmp	w8, w9
	cset	w9, eq
	csinc	w8, wzr, w15, eq
	ldp	w14, w13, [sp, #108]            ; 8-byte Folded Reload
	cinc	w10, w14, eq
	cmp	w10, w11
	cset	w11, eq
	ands	w11, w9, w11
	csel	w9, wzr, w10, ne
	add	w10, w13, w11
	ldr	w12, [sp, #116]                 ; 4-byte Folded Reload
	add	w12, w12, #1
	ldr	w11, [sp, #104]                 ; 4-byte Folded Reload
	cmp	w12, w11
	b.eq	LBB0_234
LBB0_3:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_119 Depth 2
                                        ;       Child Loop BB0_123 Depth 3
                                        ;       Child Loop BB0_125 Depth 3
                                        ;       Child Loop BB0_121 Depth 3
                                        ;     Child Loop BB0_128 Depth 2
                                        ;     Child Loop BB0_146 Depth 2
                                        ;     Child Loop BB0_164 Depth 2
                                        ;     Child Loop BB0_182 Depth 2
                                        ;     Child Loop BB0_200 Depth 2
                                        ;     Child Loop BB0_218 Depth 2
                                        ;     Child Loop BB0_21 Depth 2
                                        ;     Child Loop BB0_6 Depth 2
                                        ;       Child Loop BB0_10 Depth 3
                                        ;       Child Loop BB0_12 Depth 3
                                        ;       Child Loop BB0_8 Depth 3
	stp	w10, w12, [sp, #112]            ; 8-byte Folded Spill
	str	w9, [sp, #108]                  ; 4-byte Folded Spill
	mov	x13, x8
	ubfiz	x8, x8, #5, #32
	ldr	x12, [sp, #88]                  ; 8-byte Folded Reload
	cmp	x8, x12
	csel	x9, x8, xzr, ls
	subs	x10, x12, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x12, x9
	ccmp	x8, x12, #2, hi
	csel	x8, x10, xzr, ls
	cmp	x8, #32
	str	x13, [sp, #120]                 ; 8-byte Folded Spill
	b.lo	LBB0_13
; %bb.4:                                ; %packet.batch.full.loop.preheader.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	w20, #0                         ; =0x0
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x21, [x8]
	ldr	x22, [x8, #16]
	ldr	x23, [x8, #32]
	ldr	x25, [x8, #48]
	subs	x8, x21, x25
	mov	w11, #3071                      ; =0xbff
	movk	w11, #6, lsl #16
	ccmp	x8, x11, #0, hs
	cset	w8, hi
	subs	x9, x25, x21
	ccmp	x9, x11, #0, hs
	csinc	w8, w8, wzr, ls
	subs	x9, x22, x25
	ccmp	x9, x11, #0, hs
	cset	w9, hi
	subs	x10, x25, x22
	mov	w12, #1535                      ; =0x5ff
	movk	w12, #3, lsl #16
	ccmp	x10, x12, #0, hs
	csinc	w9, w9, wzr, ls
	and	w8, w8, w9
	subs	x9, x23, x25
	ccmp	x9, x11, #0, hs
	cset	w9, hi
	subs	x10, x25, x23
	ccmp	x10, x12, #0, hs
	csinc	w9, w9, wzr, ls
	and	w15, w9, w8
	add	x8, x21, #1536
	str	x8, [sp, #184]                  ; 8-byte Folded Spill
	add	x16, x25, #1536
	lsl	w17, w13, #2
	str	w15, [sp, #180]                 ; 4-byte Folded Spill
	str	x16, [sp, #168]                 ; 8-byte Folded Spill
	str	w17, [sp, #160]                 ; 4-byte Folded Spill
	b	LBB0_6
LBB0_5:                                 ; %llm_rows.full_packet.exit.i
                                        ;   in Loop: Header=BB0_6 Depth=2
	add	w20, w20, #1
	cmp	w20, #4
	b.eq	LBB0_2
LBB0_6:                                 ; %packet.batch.full.loop.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_10 Depth 3
                                        ;       Child Loop BB0_12 Depth 3
                                        ;       Child Loop BB0_8 Depth 3
	add	w8, w20, w17
	and	w8, w8, #0x1fffffff
	dup.2s	v0, w8
	ushll.2d	v1, v0, #0
	tbz	w15, #0, LBB0_9
; %bb.7:                                ; %direct.schedule.2.i.preheader.i
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	x8, #0                          ; =0x0
	xtn.2s	v0, v1
	umull.2d	v0, v0, v8
	fmov	x10, d0
	fmov	x9, d1
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #7
	lsl	x11, x10, #2
	add	x10, x16, x11
	ldr	x12, [sp, #184]                 ; 8-byte Folded Reload
	add	x11, x12, x11
LBB0_8:                                 ; %direct.true30.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	d1, x8
	add.2d	v1, v1, v0
	fmov	x12, d1
	lsl	x12, x12, #2
	add	x13, x21, x12
	ldp	q1, q2, [x13]
	ldp	q3, q4, [x11], #32
	add	x13, x8, x9
	lsl	x13, x13, #2
	add	x14, x22, x13
	ldp	q5, q6, [x14]
	add	x13, x23, x13
	ldp	q7, q16, [x13]
	fmul.4s	v17, v2, v6
	fmul.4s	v18, v1, v5
	fmul.4s	v19, v4, v16
	fmul.4s	v20, v3, v7
	fsub.4s	v18, v18, v20
	fsub.4s	v17, v17, v19
	add	x12, x25, x12
	stp	q18, q17, [x12]
	fmul.4s	v2, v2, v16
	fmul.4s	v1, v1, v7
	fmul.4s	v4, v4, v6
	fmul.4s	v3, v3, v5
	fadd.4s	v1, v3, v1
	fadd.4s	v2, v4, v2
	stp	q1, q2, [x10], #32
	add	x8, x8, #8
	cmp	x8, #384
	b.ne	LBB0_8
	b	LBB0_5
LBB0_9:                                 ; %direct.schedule.6.i.preheader.i
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x8, d1
	add	x19, x8, x8, lsl #1
	lsl	x26, x19, #10
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #720
	add	x1, x21, x26
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	add	x0, sp, #3280
	ldr	x8, [sp, #184]                  ; 8-byte Folded Reload
	add	x1, x8, x26
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	lsl	x19, x19, #9
	add	x0, sp, #1744
	add	x1, x22, x19
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	add	x0, sp, #208
	add	x1, x23, x19
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	add	x4, sp, #3280
	mov	x8, #0                          ; =0x0
	add	x9, x25, x26
LBB0_10:                                ; %direct.true111.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x10, x28, x8
	ldp	q0, q1, [x10]
	add	x10, x27, x8
	ldp	q2, q3, [x10]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	add	x10, x4, x8
	ldp	q2, q3, [x10]
	add	x10, x24, x8
	ldp	q4, q5, [x10]
	fmul.4s	v3, v3, v5
	fmul.4s	v2, v2, v4
	fsub.4s	v0, v0, v2
	fsub.4s	v1, v1, v3
	add	x10, x9, x8
	stp	q0, q1, [x10]
	add	x8, x8, #32
	cmp	x8, #1536
	b.ne	LBB0_10
; %bb.11:                               ; %direct.schedule.21.i.preheader.i
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	x8, #0                          ; =0x0
	ldr	x16, [sp, #168]                 ; 8-byte Folded Reload
	add	x9, x16, x26
	ldr	w15, [sp, #180]                 ; 4-byte Folded Reload
	ldr	w17, [sp, #160]                 ; 4-byte Folded Reload
LBB0_12:                                ; %direct.true144.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x10, x28, x8
	ldp	q0, q1, [x10]
	add	x10, x24, x8
	ldp	q2, q3, [x10]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	add	x10, x4, x8
	ldp	q2, q3, [x10]
	add	x10, x27, x8
	ldp	q4, q5, [x10]
	fmul.4s	v3, v3, v5
	fmul.4s	v2, v2, v4
	fadd.4s	v0, v0, v2
	fadd.4s	v1, v1, v3
	add	x10, x9, x8
	stp	q0, q1, [x10]
	add	x8, x8, #32
	cmp	x8, #1536
	b.ne	LBB0_12
	b	LBB0_5
LBB0_13:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	lsr	x15, x8, #3
	str	x8, [sp, #80]                   ; 8-byte Folded Spill
	cmp	x8, #8
	b.hs	LBB0_117
LBB0_14:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	and	w8, w8, #0x7
	cbz	w8, LBB0_2
; %bb.15:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	dup.4s	v0, w8
	ldp	q1, q2, [sp, #32]               ; 32-byte Folded Reload
	cmhi.4s	v1, v0, v1
	cmhi.4s	v0, v0, v2
	uzp1.8h	v3, v0, v1
	umaxv.8h	h2, v3
	fmov	w8, s2
	tbz	w8, #0, LBB0_2
; %bb.16:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x11, [x8]
	ldr	x10, [x8, #16]
	ldr	x9, [x8, #32]
	ldr	x8, [x8, #48]
	ldr	x12, [sp, #120]                 ; 8-byte Folded Reload
	ubfiz	w12, w12, #2, #27
	orr	w12, w12, w15
	dup.4s	v2, w12
	and.16b	v2, v0, v2
	ushll.2d	v2, v2, #0
	subs	x12, x11, x8
	mov	w15, #3071                      ; =0xbff
	movk	w15, #6, lsl #16
	ccmp	x12, x15, #0, hs
	cset	w12, hi
	subs	x13, x8, x11
	ccmp	x13, x15, #0, hs
	csinc	w12, w12, wzr, ls
	subs	x13, x10, x8
	ccmp	x13, x15, #0, hs
	cset	w13, hi
	subs	x14, x8, x10
	mov	w16, #1535                      ; =0x5ff
	movk	w16, #3, lsl #16
	ccmp	x14, x16, #0, hs
	csinc	w13, w13, wzr, ls
	subs	x14, x9, x8
	ccmp	x14, x15, #0, hs
	cset	w14, hi
	subs	x15, x8, x9
	ccmp	x15, x16, #0, hs
	csinc	w14, w14, wzr, ls
	cmp	w14, #1
	b.ne	LBB0_126
; %bb.17:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	cbz	w12, LBB0_126
; %bb.18:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w13, #0, LBB0_126
; %bb.19:                               ; %direct.schedule.2.preheader.i75.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x12, #0                         ; =0x0
	sshll.2d	v0, v0, #0
	ldr	q1, [sp, #16]                   ; 16-byte Folded Reload
	and.16b	v0, v0, v1
	xtn.2s	v1, v2
	umull.2d	v1, v1, v8
	fmov	x13, d1
	add	x13, x13, #384
	fmov	x14, d2
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #7
	ldr	q2, [sp, #128]                  ; 16-byte Folded Reload
	and.16b	v2, v3, v2
	addv.8h	h2, v2
	fmov	w15, s2
	b	LBB0_21
LBB0_20:                                ; %else210
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x12, x12, #8
	cmp	x12, #384
	b.eq	LBB0_2
LBB0_21:                                ; %direct.true30.i76.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v3, x12
	orr.16b	v5, v3, v0
	add.2d	v3, v5, v1
	fmov	x16, d3
	lsl	x16, x16, #2
	add	x17, x11, x16
	movi.2d	v4, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w15, #0, LBB0_71
; %bb.22:                               ; %else
                                        ;   in Loop: Header=BB0_21 Depth=2
	and	w0, w15, #0xff
	tbnz	w0, #1, LBB0_72
LBB0_23:                                ; %else83
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w0, #2, LBB0_73
LBB0_24:                                ; %else86
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w0, #3, LBB0_74
LBB0_25:                                ; %else89
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w0, #4, LBB0_75
LBB0_26:                                ; %else92
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w0, #5, LBB0_76
LBB0_27:                                ; %else95
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w0, #6, LBB0_77
LBB0_28:                                ; %else98
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbz	w0, #7, LBB0_30
LBB0_29:                                ; %cond.load100
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x17, x17, #28
	ld1.s	{ v3 }[3], [x17]
LBB0_30:                                ; %else101
                                        ;   in Loop: Header=BB0_21 Depth=2
	fmov	w2, s2
	fmov	x0, d5
	add	x17, x13, x0
	lsl	x17, x17, #2
	add	x1, x11, x17
	movi.2d	v6, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbnz	w2, #0, LBB0_78
; %bb.31:                               ; %else105
                                        ;   in Loop: Header=BB0_21 Depth=2
	and	w2, w2, #0xff
	tbnz	w2, #1, LBB0_79
LBB0_32:                                ; %else108
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w2, #2, LBB0_80
LBB0_33:                                ; %else111
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w2, #3, LBB0_81
LBB0_34:                                ; %else114
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w2, #4, LBB0_82
LBB0_35:                                ; %else117
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w2, #5, LBB0_83
LBB0_36:                                ; %else120
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w2, #6, LBB0_84
LBB0_37:                                ; %else123
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbz	w2, #7, LBB0_39
LBB0_38:                                ; %cond.load125
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x1, x1, #28
	ld1.s	{ v5 }[3], [x1]
LBB0_39:                                ; %else126
                                        ;   in Loop: Header=BB0_21 Depth=2
	fmov	w2, s2
	add	x0, x0, x14
	lsl	x0, x0, #2
	add	x1, x10, x0
	movi.2d	v16, #0000000000000000
	movi.2d	v7, #0000000000000000
	tbnz	w2, #0, LBB0_85
; %bb.40:                               ; %else130
                                        ;   in Loop: Header=BB0_21 Depth=2
	and	w2, w2, #0xff
	tbnz	w2, #1, LBB0_86
LBB0_41:                                ; %else133
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w2, #2, LBB0_87
LBB0_42:                                ; %else136
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w2, #3, LBB0_88
LBB0_43:                                ; %else139
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w2, #4, LBB0_89
LBB0_44:                                ; %else142
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w2, #5, LBB0_90
LBB0_45:                                ; %else145
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w2, #6, LBB0_91
LBB0_46:                                ; %else148
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w2, #7, LBB0_92
LBB0_47:                                ; %else151
                                        ;   in Loop: Header=BB0_21 Depth=2
	fmov	w1, s2
	add	x0, x9, x0
	movi.2d	v18, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbnz	w1, #0, LBB0_93
LBB0_48:                                ; %else155
                                        ;   in Loop: Header=BB0_21 Depth=2
	and	w1, w1, #0xff
	tbnz	w1, #1, LBB0_94
LBB0_49:                                ; %else158
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w1, #2, LBB0_95
LBB0_50:                                ; %else161
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w1, #3, LBB0_96
LBB0_51:                                ; %else164
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w1, #4, LBB0_97
LBB0_52:                                ; %else167
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w1, #5, LBB0_98
LBB0_53:                                ; %else170
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w1, #6, LBB0_99
LBB0_54:                                ; %else173
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w1, #7, LBB0_100
LBB0_55:                                ; %else176
                                        ;   in Loop: Header=BB0_21 Depth=2
	fmov	w0, s2
	fmul.4s	v19, v4, v16
	fmul.4s	v20, v6, v18
	fsub.4s	v19, v19, v20
	add	x16, x8, x16
	tbnz	w0, #0, LBB0_101
LBB0_56:                                ; %else179
                                        ;   in Loop: Header=BB0_21 Depth=2
	and	w0, w0, #0xff
	tbnz	w0, #1, LBB0_102
LBB0_57:                                ; %else181
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w0, #2, LBB0_103
LBB0_58:                                ; %else183
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w0, #3, LBB0_104
LBB0_59:                                ; %else185
                                        ;   in Loop: Header=BB0_21 Depth=2
	fmul.4s	v19, v3, v7
	fmul.4s	v20, v5, v17
	fsub.4s	v19, v19, v20
	tbnz	w0, #4, LBB0_105
LBB0_60:                                ; %else187
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w0, #5, LBB0_106
LBB0_61:                                ; %else189
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w0, #6, LBB0_107
LBB0_62:                                ; %else191
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w0, #7, LBB0_108
LBB0_63:                                ; %else193
                                        ;   in Loop: Header=BB0_21 Depth=2
	fmov	w0, s2
	fmul.4s	v4, v4, v18
	fmul.4s	v6, v6, v16
	fadd.4s	v4, v6, v4
	add	x16, x8, x17
	tbnz	w0, #0, LBB0_109
LBB0_64:                                ; %else196
                                        ;   in Loop: Header=BB0_21 Depth=2
	and	w17, w0, #0xff
	tbnz	w17, #1, LBB0_110
LBB0_65:                                ; %else198
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w17, #2, LBB0_111
LBB0_66:                                ; %else200
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w17, #3, LBB0_112
LBB0_67:                                ; %else202
                                        ;   in Loop: Header=BB0_21 Depth=2
	fmul.4s	v3, v3, v17
	fmul.4s	v4, v5, v7
	fadd.4s	v3, v4, v3
	tbnz	w17, #4, LBB0_113
LBB0_68:                                ; %else204
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w17, #5, LBB0_114
LBB0_69:                                ; %else206
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbnz	w17, #6, LBB0_115
LBB0_70:                                ; %else208
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbz	w17, #7, LBB0_20
	b	LBB0_116
LBB0_71:                                ; %cond.load
                                        ;   in Loop: Header=BB0_21 Depth=2
	ldr	s4, [x17]
	and	w0, w15, #0xff
	tbz	w0, #1, LBB0_23
LBB0_72:                                ; %cond.load82
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x1, x17, #4
	ld1.s	{ v4 }[1], [x1]
	tbz	w0, #2, LBB0_24
LBB0_73:                                ; %cond.load85
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x1, x17, #8
	ld1.s	{ v4 }[2], [x1]
	tbz	w0, #3, LBB0_25
LBB0_74:                                ; %cond.load88
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x1, x17, #12
	ld1.s	{ v4 }[3], [x1]
	tbz	w0, #4, LBB0_26
LBB0_75:                                ; %cond.load91
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x1, x17, #16
	ld1.s	{ v3 }[0], [x1]
	tbz	w0, #5, LBB0_27
LBB0_76:                                ; %cond.load94
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x1, x17, #20
	ld1.s	{ v3 }[1], [x1]
	tbz	w0, #6, LBB0_28
LBB0_77:                                ; %cond.load97
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x1, x17, #24
	ld1.s	{ v3 }[2], [x1]
	tbnz	w0, #7, LBB0_29
	b	LBB0_30
LBB0_78:                                ; %cond.load104
                                        ;   in Loop: Header=BB0_21 Depth=2
	ldr	s6, [x1]
	and	w2, w2, #0xff
	tbz	w2, #1, LBB0_32
LBB0_79:                                ; %cond.load107
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x3, x1, #4
	ld1.s	{ v6 }[1], [x3]
	tbz	w2, #2, LBB0_33
LBB0_80:                                ; %cond.load110
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x3, x1, #8
	ld1.s	{ v6 }[2], [x3]
	tbz	w2, #3, LBB0_34
LBB0_81:                                ; %cond.load113
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x3, x1, #12
	ld1.s	{ v6 }[3], [x3]
	tbz	w2, #4, LBB0_35
LBB0_82:                                ; %cond.load116
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x3, x1, #16
	ld1.s	{ v5 }[0], [x3]
	tbz	w2, #5, LBB0_36
LBB0_83:                                ; %cond.load119
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x3, x1, #20
	ld1.s	{ v5 }[1], [x3]
	tbz	w2, #6, LBB0_37
LBB0_84:                                ; %cond.load122
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x3, x1, #24
	ld1.s	{ v5 }[2], [x3]
	tbnz	w2, #7, LBB0_38
	b	LBB0_39
LBB0_85:                                ; %cond.load129
                                        ;   in Loop: Header=BB0_21 Depth=2
	ldr	s16, [x1]
	and	w2, w2, #0xff
	tbz	w2, #1, LBB0_41
LBB0_86:                                ; %cond.load132
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x3, x1, #4
	ld1.s	{ v16 }[1], [x3]
	tbz	w2, #2, LBB0_42
LBB0_87:                                ; %cond.load135
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x3, x1, #8
	ld1.s	{ v16 }[2], [x3]
	tbz	w2, #3, LBB0_43
LBB0_88:                                ; %cond.load138
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x3, x1, #12
	ld1.s	{ v16 }[3], [x3]
	tbz	w2, #4, LBB0_44
LBB0_89:                                ; %cond.load141
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x3, x1, #16
	ld1.s	{ v7 }[0], [x3]
	tbz	w2, #5, LBB0_45
LBB0_90:                                ; %cond.load144
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x3, x1, #20
	ld1.s	{ v7 }[1], [x3]
	tbz	w2, #6, LBB0_46
LBB0_91:                                ; %cond.load147
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x3, x1, #24
	ld1.s	{ v7 }[2], [x3]
	tbz	w2, #7, LBB0_47
LBB0_92:                                ; %cond.load150
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x1, x1, #28
	ld1.s	{ v7 }[3], [x1]
	fmov	w1, s2
	add	x0, x9, x0
	movi.2d	v18, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbz	w1, #0, LBB0_48
LBB0_93:                                ; %cond.load154
                                        ;   in Loop: Header=BB0_21 Depth=2
	ldr	s18, [x0]
	and	w1, w1, #0xff
	tbz	w1, #1, LBB0_49
LBB0_94:                                ; %cond.load157
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x2, x0, #4
	ld1.s	{ v18 }[1], [x2]
	tbz	w1, #2, LBB0_50
LBB0_95:                                ; %cond.load160
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x2, x0, #8
	ld1.s	{ v18 }[2], [x2]
	tbz	w1, #3, LBB0_51
LBB0_96:                                ; %cond.load163
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x2, x0, #12
	ld1.s	{ v18 }[3], [x2]
	tbz	w1, #4, LBB0_52
LBB0_97:                                ; %cond.load166
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x2, x0, #16
	ld1.s	{ v17 }[0], [x2]
	tbz	w1, #5, LBB0_53
LBB0_98:                                ; %cond.load169
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x2, x0, #20
	ld1.s	{ v17 }[1], [x2]
	tbz	w1, #6, LBB0_54
LBB0_99:                                ; %cond.load172
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x2, x0, #24
	ld1.s	{ v17 }[2], [x2]
	tbz	w1, #7, LBB0_55
LBB0_100:                               ; %cond.load175
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x0, x0, #28
	ld1.s	{ v17 }[3], [x0]
	fmov	w0, s2
	fmul.4s	v19, v4, v16
	fmul.4s	v20, v6, v18
	fsub.4s	v19, v19, v20
	add	x16, x8, x16
	tbz	w0, #0, LBB0_56
LBB0_101:                               ; %cond.store
                                        ;   in Loop: Header=BB0_21 Depth=2
	str	s19, [x16]
	and	w0, w0, #0xff
	tbz	w0, #1, LBB0_57
LBB0_102:                               ; %cond.store180
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x1, x16, #4
	st1.s	{ v19 }[1], [x1]
	tbz	w0, #2, LBB0_58
LBB0_103:                               ; %cond.store182
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x1, x16, #8
	st1.s	{ v19 }[2], [x1]
	tbz	w0, #3, LBB0_59
LBB0_104:                               ; %cond.store184
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x1, x16, #12
	st1.s	{ v19 }[3], [x1]
	fmul.4s	v19, v3, v7
	fmul.4s	v20, v5, v17
	fsub.4s	v19, v19, v20
	tbz	w0, #4, LBB0_60
LBB0_105:                               ; %cond.store186
                                        ;   in Loop: Header=BB0_21 Depth=2
	str	s19, [x16, #16]
	tbz	w0, #5, LBB0_61
LBB0_106:                               ; %cond.store188
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x1, x16, #20
	st1.s	{ v19 }[1], [x1]
	tbz	w0, #6, LBB0_62
LBB0_107:                               ; %cond.store190
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x1, x16, #24
	st1.s	{ v19 }[2], [x1]
	tbz	w0, #7, LBB0_63
LBB0_108:                               ; %cond.store192
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x16, x16, #28
	st1.s	{ v19 }[3], [x16]
	fmov	w0, s2
	fmul.4s	v4, v4, v18
	fmul.4s	v6, v6, v16
	fadd.4s	v4, v6, v4
	add	x16, x8, x17
	tbz	w0, #0, LBB0_64
LBB0_109:                               ; %cond.store195
                                        ;   in Loop: Header=BB0_21 Depth=2
	str	s4, [x16]
	and	w17, w0, #0xff
	tbz	w17, #1, LBB0_65
LBB0_110:                               ; %cond.store197
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x0, x16, #4
	st1.s	{ v4 }[1], [x0]
	tbz	w17, #2, LBB0_66
LBB0_111:                               ; %cond.store199
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x0, x16, #8
	st1.s	{ v4 }[2], [x0]
	tbz	w17, #3, LBB0_67
LBB0_112:                               ; %cond.store201
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x0, x16, #12
	st1.s	{ v4 }[3], [x0]
	fmul.4s	v3, v3, v17
	fmul.4s	v4, v5, v7
	fadd.4s	v3, v4, v3
	tbz	w17, #4, LBB0_68
LBB0_113:                               ; %cond.store203
                                        ;   in Loop: Header=BB0_21 Depth=2
	str	s3, [x16, #16]
	tbz	w17, #5, LBB0_69
LBB0_114:                               ; %cond.store205
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x0, x16, #20
	st1.s	{ v3 }[1], [x0]
	tbz	w17, #6, LBB0_70
LBB0_115:                               ; %cond.store207
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x0, x16, #24
	st1.s	{ v3 }[2], [x0]
	tbz	w17, #7, LBB0_20
LBB0_116:                               ; %cond.store209
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x16, x16, #28
	st1.s	{ v3 }[3], [x16]
	b	LBB0_20
LBB0_117:                               ; %packet.batch.partial.full.loop.preheader.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	w25, #0                         ; =0x0
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x20, [x8]
	ldr	x23, [x8, #16]
	ldr	x21, [x8, #32]
	ldr	x26, [x8, #48]
	subs	x8, x20, x26
	mov	w11, #3071                      ; =0xbff
	movk	w11, #6, lsl #16
	ccmp	x8, x11, #0, hs
	cset	w8, hi
	subs	x9, x26, x20
	ccmp	x9, x11, #0, hs
	csinc	w8, w8, wzr, ls
	subs	x9, x23, x26
	ccmp	x9, x11, #0, hs
	cset	w9, hi
	subs	x10, x26, x23
	mov	w12, #1535                      ; =0x5ff
	movk	w12, #3, lsl #16
	ccmp	x10, x12, #0, hs
	csinc	w9, w9, wzr, ls
	and	w8, w8, w9
	subs	x9, x21, x26
	ccmp	x9, x11, #0, hs
	cset	w9, hi
	subs	x10, x26, x21
	ccmp	x10, x12, #0, hs
	csinc	w9, w9, wzr, ls
	and	w16, w9, w8
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	lsl	w17, w8, #2
	add	x9, x26, #1536
	add	x8, x20, #1536
	stp	x8, x9, [sp, #152]              ; 16-byte Folded Spill
	str	x15, [sp, #184]                 ; 8-byte Folded Spill
	str	w16, [sp, #180]                 ; 4-byte Folded Spill
	str	w17, [sp, #168]                 ; 4-byte Folded Spill
	b	LBB0_119
LBB0_118:                               ; %llm_rows.full_packet.exit38.i
                                        ;   in Loop: Header=BB0_119 Depth=2
	add	w25, w25, #1
	cmp	w25, w15
	b.eq	LBB0_14
LBB0_119:                               ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_123 Depth 3
                                        ;       Child Loop BB0_125 Depth 3
                                        ;       Child Loop BB0_121 Depth 3
	add	w8, w25, w17
	and	w8, w8, #0x1fffffff
	dup.2s	v0, w8
	ushll.2d	v1, v0, #0
	tbz	w16, #0, LBB0_122
; %bb.120:                              ; %direct.schedule.2.preheader.i.i
                                        ;   in Loop: Header=BB0_119 Depth=2
	mov	x8, #0                          ; =0x0
	xtn.2s	v0, v1
	umull.2d	v0, v0, v8
	fmov	x10, d0
	fmov	x9, d1
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #7
	lsl	x11, x10, #2
	ldp	x12, x10, [sp, #152]            ; 16-byte Folded Reload
	add	x10, x10, x11
	add	x11, x12, x11
LBB0_121:                               ; %direct.true30.i25.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_119 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	d1, x8
	add.2d	v1, v1, v0
	fmov	x12, d1
	lsl	x12, x12, #2
	add	x13, x20, x12
	ldp	q1, q2, [x13]
	ldp	q3, q4, [x11], #32
	add	x13, x8, x9
	lsl	x13, x13, #2
	add	x14, x23, x13
	ldp	q5, q6, [x14]
	add	x13, x21, x13
	ldp	q7, q16, [x13]
	fmul.4s	v17, v2, v6
	fmul.4s	v18, v1, v5
	fmul.4s	v19, v4, v16
	fmul.4s	v20, v3, v7
	fsub.4s	v18, v18, v20
	fsub.4s	v17, v17, v19
	add	x12, x26, x12
	stp	q18, q17, [x12]
	fmul.4s	v2, v2, v16
	fmul.4s	v1, v1, v7
	fmul.4s	v4, v4, v6
	fmul.4s	v3, v3, v5
	fadd.4s	v1, v3, v1
	fadd.4s	v2, v4, v2
	stp	q1, q2, [x10], #32
	add	x8, x8, #8
	cmp	x8, #384
	b.ne	LBB0_121
	b	LBB0_118
LBB0_122:                               ; %direct.schedule.6.preheader.i.i
                                        ;   in Loop: Header=BB0_119 Depth=2
	fmov	x8, d1
	add	x19, x8, x8, lsl #1
	lsl	x28, x19, #10
	add	x22, x20, x28
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #720
	mov	x1, x22
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	add	x0, sp, #3280
	add	x1, x22, #1536
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	lsl	x19, x19, #9
	add	x0, sp, #1744
	add	x1, x23, x19
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	add	x0, sp, #208
	add	x1, x21, x19
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	add	x4, sp, #3280
	mov	x9, #0                          ; =0x0
	add	x8, x26, x28
	add	x28, sp, #1, lsl #12            ; =4096
	add	x28, x28, #720
LBB0_123:                               ; %direct.true111.i7.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_119 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x10, x28, x9
	ldp	q0, q1, [x10]
	add	x10, x27, x9
	ldp	q2, q3, [x10]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	add	x10, x4, x9
	ldp	q2, q3, [x10]
	add	x10, x24, x9
	ldp	q4, q5, [x10]
	fmul.4s	v3, v3, v5
	fmul.4s	v2, v2, v4
	fsub.4s	v0, v0, v2
	fsub.4s	v1, v1, v3
	add	x10, x8, x9
	stp	q0, q1, [x10]
	add	x9, x9, #32
	cmp	x9, #1536
	b.ne	LBB0_123
; %bb.124:                              ; %direct.schedule.21.preheader.i.i
                                        ;   in Loop: Header=BB0_119 Depth=2
	mov	x9, #0                          ; =0x0
	add	x8, x8, #1536
	ldr	x15, [sp, #184]                 ; 8-byte Folded Reload
	ldr	w16, [sp, #180]                 ; 4-byte Folded Reload
	ldr	w17, [sp, #168]                 ; 4-byte Folded Reload
LBB0_125:                               ; %direct.true144.i16.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_119 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x10, x28, x9
	ldp	q0, q1, [x10]
	add	x10, x24, x9
	ldp	q2, q3, [x10]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	add	x10, x4, x9
	ldp	q2, q3, [x10]
	add	x10, x27, x9
	ldp	q4, q5, [x10]
	fmul.4s	v3, v3, v5
	fmul.4s	v2, v2, v4
	fadd.4s	v0, v0, v2
	fadd.4s	v1, v1, v3
	add	x10, x8, x9
	stp	q0, q1, [x10]
	add	x9, x9, #32
	cmp	x9, #1536
	b.ne	LBB0_125
	b	LBB0_118
LBB0_126:                               ; %direct.schedule.6.preheader.i44.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x14, #0                         ; =0x0
	fmov	x12, d2
	add	x13, x12, x12, lsl #1
	lsl	x12, x13, #10
	add	x11, x11, x12
	b	LBB0_128
LBB0_127:                               ; %else234
                                        ;   in Loop: Header=BB0_128 Depth=2
	add	x15, x28, x14
	ldp	q6, q7, [x15]
	bif.16b	v5, v7, v1
	bif.16b	v4, v6, v0
	stp	q4, q5, [x15]
	add	x14, x14, #32
	cmp	x14, #1536
	b.eq	LBB0_144
LBB0_128:                               ; %direct.true46.i46.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [sp, #128]                  ; 16-byte Folded Reload
	and.16b	v2, v3, v2
	addv.8h	h2, v2
	fmov	w16, s2
	add	x15, x11, x14
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbnz	w16, #0, LBB0_136
; %bb.129:                              ; %else213
                                        ;   in Loop: Header=BB0_128 Depth=2
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_137
LBB0_130:                               ; %else216
                                        ;   in Loop: Header=BB0_128 Depth=2
	tbnz	w16, #2, LBB0_138
LBB0_131:                               ; %else219
                                        ;   in Loop: Header=BB0_128 Depth=2
	tbnz	w16, #3, LBB0_139
LBB0_132:                               ; %else222
                                        ;   in Loop: Header=BB0_128 Depth=2
	tbnz	w16, #4, LBB0_140
LBB0_133:                               ; %else225
                                        ;   in Loop: Header=BB0_128 Depth=2
	tbnz	w16, #5, LBB0_141
LBB0_134:                               ; %else228
                                        ;   in Loop: Header=BB0_128 Depth=2
	tbnz	w16, #6, LBB0_142
LBB0_135:                               ; %else231
                                        ;   in Loop: Header=BB0_128 Depth=2
	tbz	w16, #7, LBB0_127
	b	LBB0_143
LBB0_136:                               ; %cond.load212
                                        ;   in Loop: Header=BB0_128 Depth=2
	ldr	s4, [x15]
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_130
LBB0_137:                               ; %cond.load215
                                        ;   in Loop: Header=BB0_128 Depth=2
	add	x17, x15, #4
	ld1.s	{ v4 }[1], [x17]
	tbz	w16, #2, LBB0_131
LBB0_138:                               ; %cond.load218
                                        ;   in Loop: Header=BB0_128 Depth=2
	add	x17, x15, #8
	ld1.s	{ v4 }[2], [x17]
	tbz	w16, #3, LBB0_132
LBB0_139:                               ; %cond.load221
                                        ;   in Loop: Header=BB0_128 Depth=2
	add	x17, x15, #12
	ld1.s	{ v4 }[3], [x17]
	tbz	w16, #4, LBB0_133
LBB0_140:                               ; %cond.load224
                                        ;   in Loop: Header=BB0_128 Depth=2
	add	x17, x15, #16
	ld1.s	{ v5 }[0], [x17]
	tbz	w16, #5, LBB0_134
LBB0_141:                               ; %cond.load227
                                        ;   in Loop: Header=BB0_128 Depth=2
	add	x17, x15, #20
	ld1.s	{ v5 }[1], [x17]
	tbz	w16, #6, LBB0_135
LBB0_142:                               ; %cond.load230
                                        ;   in Loop: Header=BB0_128 Depth=2
	add	x17, x15, #24
	ld1.s	{ v5 }[2], [x17]
	tbz	w16, #7, LBB0_127
LBB0_143:                               ; %cond.load233
                                        ;   in Loop: Header=BB0_128 Depth=2
	add	x15, x15, #28
	ld1.s	{ v5 }[3], [x15]
	b	LBB0_127
LBB0_144:                               ; %direct.schedule.9.preheader.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x14, #0                         ; =0x0
	add	x11, x11, #1536
	b	LBB0_146
LBB0_145:                               ; %else259
                                        ;   in Loop: Header=BB0_146 Depth=2
	add	x15, x4, x14
	ldp	q5, q6, [x15]
	bif.16b	v4, v6, v1
	bif.16b	v3, v5, v0
	stp	q3, q4, [x15]
	add	x14, x14, #32
	cmp	x14, #1536
	b.eq	LBB0_162
LBB0_146:                               ; %direct.true60.i49.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w16, s2
	add	x15, x11, x14
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbnz	w16, #0, LBB0_154
; %bb.147:                              ; %else238
                                        ;   in Loop: Header=BB0_146 Depth=2
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_155
LBB0_148:                               ; %else241
                                        ;   in Loop: Header=BB0_146 Depth=2
	tbnz	w16, #2, LBB0_156
LBB0_149:                               ; %else244
                                        ;   in Loop: Header=BB0_146 Depth=2
	tbnz	w16, #3, LBB0_157
LBB0_150:                               ; %else247
                                        ;   in Loop: Header=BB0_146 Depth=2
	tbnz	w16, #4, LBB0_158
LBB0_151:                               ; %else250
                                        ;   in Loop: Header=BB0_146 Depth=2
	tbnz	w16, #5, LBB0_159
LBB0_152:                               ; %else253
                                        ;   in Loop: Header=BB0_146 Depth=2
	tbnz	w16, #6, LBB0_160
LBB0_153:                               ; %else256
                                        ;   in Loop: Header=BB0_146 Depth=2
	tbz	w16, #7, LBB0_145
	b	LBB0_161
LBB0_154:                               ; %cond.load237
                                        ;   in Loop: Header=BB0_146 Depth=2
	ldr	s3, [x15]
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_148
LBB0_155:                               ; %cond.load240
                                        ;   in Loop: Header=BB0_146 Depth=2
	add	x17, x15, #4
	ld1.s	{ v3 }[1], [x17]
	tbz	w16, #2, LBB0_149
LBB0_156:                               ; %cond.load243
                                        ;   in Loop: Header=BB0_146 Depth=2
	add	x17, x15, #8
	ld1.s	{ v3 }[2], [x17]
	tbz	w16, #3, LBB0_150
LBB0_157:                               ; %cond.load246
                                        ;   in Loop: Header=BB0_146 Depth=2
	add	x17, x15, #12
	ld1.s	{ v3 }[3], [x17]
	tbz	w16, #4, LBB0_151
LBB0_158:                               ; %cond.load249
                                        ;   in Loop: Header=BB0_146 Depth=2
	add	x17, x15, #16
	ld1.s	{ v4 }[0], [x17]
	tbz	w16, #5, LBB0_152
LBB0_159:                               ; %cond.load252
                                        ;   in Loop: Header=BB0_146 Depth=2
	add	x17, x15, #20
	ld1.s	{ v4 }[1], [x17]
	tbz	w16, #6, LBB0_153
LBB0_160:                               ; %cond.load255
                                        ;   in Loop: Header=BB0_146 Depth=2
	add	x17, x15, #24
	ld1.s	{ v4 }[2], [x17]
	tbz	w16, #7, LBB0_145
LBB0_161:                               ; %cond.load258
                                        ;   in Loop: Header=BB0_146 Depth=2
	add	x15, x15, #28
	ld1.s	{ v4 }[3], [x15]
	b	LBB0_145
LBB0_162:                               ; %direct.schedule.12.preheader.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x14, #0                         ; =0x0
	lsl	x11, x13, #9
	add	x10, x10, x11
	b	LBB0_164
LBB0_163:                               ; %else284
                                        ;   in Loop: Header=BB0_164 Depth=2
	add	x13, x27, x14
	ldp	q5, q6, [x13]
	bif.16b	v4, v6, v1
	bif.16b	v3, v5, v0
	stp	q3, q4, [x13]
	add	x14, x14, #32
	cmp	x14, #1536
	b.eq	LBB0_180
LBB0_164:                               ; %direct.true77.i51.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w15, s2
	add	x13, x10, x14
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbnz	w15, #0, LBB0_172
; %bb.165:                              ; %else263
                                        ;   in Loop: Header=BB0_164 Depth=2
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB0_173
LBB0_166:                               ; %else266
                                        ;   in Loop: Header=BB0_164 Depth=2
	tbnz	w15, #2, LBB0_174
LBB0_167:                               ; %else269
                                        ;   in Loop: Header=BB0_164 Depth=2
	tbnz	w15, #3, LBB0_175
LBB0_168:                               ; %else272
                                        ;   in Loop: Header=BB0_164 Depth=2
	tbnz	w15, #4, LBB0_176
LBB0_169:                               ; %else275
                                        ;   in Loop: Header=BB0_164 Depth=2
	tbnz	w15, #5, LBB0_177
LBB0_170:                               ; %else278
                                        ;   in Loop: Header=BB0_164 Depth=2
	tbnz	w15, #6, LBB0_178
LBB0_171:                               ; %else281
                                        ;   in Loop: Header=BB0_164 Depth=2
	tbz	w15, #7, LBB0_163
	b	LBB0_179
LBB0_172:                               ; %cond.load262
                                        ;   in Loop: Header=BB0_164 Depth=2
	ldr	s3, [x13]
	and	w15, w15, #0xff
	tbz	w15, #1, LBB0_166
LBB0_173:                               ; %cond.load265
                                        ;   in Loop: Header=BB0_164 Depth=2
	add	x16, x13, #4
	ld1.s	{ v3 }[1], [x16]
	tbz	w15, #2, LBB0_167
LBB0_174:                               ; %cond.load268
                                        ;   in Loop: Header=BB0_164 Depth=2
	add	x16, x13, #8
	ld1.s	{ v3 }[2], [x16]
	tbz	w15, #3, LBB0_168
LBB0_175:                               ; %cond.load271
                                        ;   in Loop: Header=BB0_164 Depth=2
	add	x16, x13, #12
	ld1.s	{ v3 }[3], [x16]
	tbz	w15, #4, LBB0_169
LBB0_176:                               ; %cond.load274
                                        ;   in Loop: Header=BB0_164 Depth=2
	add	x16, x13, #16
	ld1.s	{ v4 }[0], [x16]
	tbz	w15, #5, LBB0_170
LBB0_177:                               ; %cond.load277
                                        ;   in Loop: Header=BB0_164 Depth=2
	add	x16, x13, #20
	ld1.s	{ v4 }[1], [x16]
	tbz	w15, #6, LBB0_171
LBB0_178:                               ; %cond.load280
                                        ;   in Loop: Header=BB0_164 Depth=2
	add	x16, x13, #24
	ld1.s	{ v4 }[2], [x16]
	tbz	w15, #7, LBB0_163
LBB0_179:                               ; %cond.load283
                                        ;   in Loop: Header=BB0_164 Depth=2
	add	x13, x13, #28
	ld1.s	{ v4 }[3], [x13]
	b	LBB0_163
LBB0_180:                               ; %direct.schedule.15.preheader.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x10, #0                         ; =0x0
	add	x9, x9, x11
	b	LBB0_182
LBB0_181:                               ; %else309
                                        ;   in Loop: Header=BB0_182 Depth=2
	add	x11, x24, x10
	ldp	q5, q6, [x11]
	bif.16b	v4, v6, v1
	bif.16b	v3, v5, v0
	stp	q3, q4, [x11]
	add	x10, x10, #32
	cmp	x10, #1536
	b.eq	LBB0_198
LBB0_182:                               ; %direct.true94.i53.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w13, s2
	add	x11, x9, x10
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbnz	w13, #0, LBB0_190
; %bb.183:                              ; %else288
                                        ;   in Loop: Header=BB0_182 Depth=2
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB0_191
LBB0_184:                               ; %else291
                                        ;   in Loop: Header=BB0_182 Depth=2
	tbnz	w13, #2, LBB0_192
LBB0_185:                               ; %else294
                                        ;   in Loop: Header=BB0_182 Depth=2
	tbnz	w13, #3, LBB0_193
LBB0_186:                               ; %else297
                                        ;   in Loop: Header=BB0_182 Depth=2
	tbnz	w13, #4, LBB0_194
LBB0_187:                               ; %else300
                                        ;   in Loop: Header=BB0_182 Depth=2
	tbnz	w13, #5, LBB0_195
LBB0_188:                               ; %else303
                                        ;   in Loop: Header=BB0_182 Depth=2
	tbnz	w13, #6, LBB0_196
LBB0_189:                               ; %else306
                                        ;   in Loop: Header=BB0_182 Depth=2
	tbz	w13, #7, LBB0_181
	b	LBB0_197
LBB0_190:                               ; %cond.load287
                                        ;   in Loop: Header=BB0_182 Depth=2
	ldr	s3, [x11]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB0_184
LBB0_191:                               ; %cond.load290
                                        ;   in Loop: Header=BB0_182 Depth=2
	add	x14, x11, #4
	ld1.s	{ v3 }[1], [x14]
	tbz	w13, #2, LBB0_185
LBB0_192:                               ; %cond.load293
                                        ;   in Loop: Header=BB0_182 Depth=2
	add	x14, x11, #8
	ld1.s	{ v3 }[2], [x14]
	tbz	w13, #3, LBB0_186
LBB0_193:                               ; %cond.load296
                                        ;   in Loop: Header=BB0_182 Depth=2
	add	x14, x11, #12
	ld1.s	{ v3 }[3], [x14]
	tbz	w13, #4, LBB0_187
LBB0_194:                               ; %cond.load299
                                        ;   in Loop: Header=BB0_182 Depth=2
	add	x14, x11, #16
	ld1.s	{ v4 }[0], [x14]
	tbz	w13, #5, LBB0_188
LBB0_195:                               ; %cond.load302
                                        ;   in Loop: Header=BB0_182 Depth=2
	add	x14, x11, #20
	ld1.s	{ v4 }[1], [x14]
	tbz	w13, #6, LBB0_189
LBB0_196:                               ; %cond.load305
                                        ;   in Loop: Header=BB0_182 Depth=2
	add	x14, x11, #24
	ld1.s	{ v4 }[2], [x14]
	tbz	w13, #7, LBB0_181
LBB0_197:                               ; %cond.load308
                                        ;   in Loop: Header=BB0_182 Depth=2
	add	x11, x11, #28
	ld1.s	{ v4 }[3], [x11]
	b	LBB0_181
LBB0_198:                               ; %direct.schedule.18.preheader.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x9, #0                          ; =0x0
	add	x8, x8, x12
	b	LBB0_200
LBB0_199:                               ; %else327
                                        ;   in Loop: Header=BB0_200 Depth=2
	add	x9, x9, #32
	cmp	x9, #1536
	b.eq	LBB0_216
LBB0_200:                               ; %direct.true111.i55.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w11, s2
	add	x10, x28, x9
	ldp	q5, q3, [x10]
	add	x10, x27, x9
	ldp	q6, q4, [x10]
	fmul.4s	v7, v5, v6
	add	x10, x4, x9
	ldp	q16, q5, [x10]
	add	x10, x24, x9
	ldp	q17, q6, [x10]
	fmul.4s	v16, v16, v17
	fsub.4s	v7, v7, v16
	and.16b	v7, v0, v7
	add	x10, x8, x9
	tbnz	w11, #0, LBB0_208
; %bb.201:                              ; %else313
                                        ;   in Loop: Header=BB0_200 Depth=2
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB0_209
LBB0_202:                               ; %else315
                                        ;   in Loop: Header=BB0_200 Depth=2
	tbnz	w11, #2, LBB0_210
LBB0_203:                               ; %else317
                                        ;   in Loop: Header=BB0_200 Depth=2
	tbnz	w11, #3, LBB0_211
LBB0_204:                               ; %else319
                                        ;   in Loop: Header=BB0_200 Depth=2
	fmul.4s	v3, v3, v4
	fmul.4s	v4, v5, v6
	fsub.4s	v3, v3, v4
	and.16b	v3, v1, v3
	tbnz	w11, #4, LBB0_212
LBB0_205:                               ; %else321
                                        ;   in Loop: Header=BB0_200 Depth=2
	tbnz	w11, #5, LBB0_213
LBB0_206:                               ; %else323
                                        ;   in Loop: Header=BB0_200 Depth=2
	tbnz	w11, #6, LBB0_214
LBB0_207:                               ; %else325
                                        ;   in Loop: Header=BB0_200 Depth=2
	tbz	w11, #7, LBB0_199
	b	LBB0_215
LBB0_208:                               ; %cond.store312
                                        ;   in Loop: Header=BB0_200 Depth=2
	str	s7, [x10]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB0_202
LBB0_209:                               ; %cond.store314
                                        ;   in Loop: Header=BB0_200 Depth=2
	add	x12, x10, #4
	st1.s	{ v7 }[1], [x12]
	tbz	w11, #2, LBB0_203
LBB0_210:                               ; %cond.store316
                                        ;   in Loop: Header=BB0_200 Depth=2
	add	x12, x10, #8
	st1.s	{ v7 }[2], [x12]
	tbz	w11, #3, LBB0_204
LBB0_211:                               ; %cond.store318
                                        ;   in Loop: Header=BB0_200 Depth=2
	add	x12, x10, #12
	st1.s	{ v7 }[3], [x12]
	fmul.4s	v3, v3, v4
	fmul.4s	v4, v5, v6
	fsub.4s	v3, v3, v4
	and.16b	v3, v1, v3
	tbz	w11, #4, LBB0_205
LBB0_212:                               ; %cond.store320
                                        ;   in Loop: Header=BB0_200 Depth=2
	str	s3, [x10, #16]
	tbz	w11, #5, LBB0_206
LBB0_213:                               ; %cond.store322
                                        ;   in Loop: Header=BB0_200 Depth=2
	add	x12, x10, #20
	st1.s	{ v3 }[1], [x12]
	tbz	w11, #6, LBB0_207
LBB0_214:                               ; %cond.store324
                                        ;   in Loop: Header=BB0_200 Depth=2
	add	x12, x10, #24
	st1.s	{ v3 }[2], [x12]
	tbz	w11, #7, LBB0_199
LBB0_215:                               ; %cond.store326
                                        ;   in Loop: Header=BB0_200 Depth=2
	add	x10, x10, #28
	st1.s	{ v3 }[3], [x10]
	b	LBB0_199
LBB0_216:                               ; %direct.schedule.21.preheader.i64.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x9, #0                          ; =0x0
	add	x8, x8, #1536
	b	LBB0_218
LBB0_217:                               ; %else344
                                        ;   in Loop: Header=BB0_218 Depth=2
	add	x9, x9, #32
	cmp	x9, #1536
	b.eq	LBB0_2
LBB0_218:                               ; %direct.true144.i66.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w11, s2
	add	x10, x28, x9
	ldp	q5, q3, [x10]
	add	x10, x24, x9
	ldp	q6, q4, [x10]
	fmul.4s	v7, v5, v6
	add	x10, x4, x9
	ldp	q16, q5, [x10]
	add	x10, x27, x9
	ldp	q17, q6, [x10]
	fmul.4s	v16, v16, v17
	fadd.4s	v7, v7, v16
	and.16b	v7, v0, v7
	add	x10, x8, x9
	tbnz	w11, #0, LBB0_226
; %bb.219:                              ; %else330
                                        ;   in Loop: Header=BB0_218 Depth=2
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB0_227
LBB0_220:                               ; %else332
                                        ;   in Loop: Header=BB0_218 Depth=2
	tbnz	w11, #2, LBB0_228
LBB0_221:                               ; %else334
                                        ;   in Loop: Header=BB0_218 Depth=2
	tbnz	w11, #3, LBB0_229
LBB0_222:                               ; %else336
                                        ;   in Loop: Header=BB0_218 Depth=2
	fmul.4s	v3, v3, v4
	fmul.4s	v4, v5, v6
	fadd.4s	v3, v3, v4
	and.16b	v3, v1, v3
	tbnz	w11, #4, LBB0_230
LBB0_223:                               ; %else338
                                        ;   in Loop: Header=BB0_218 Depth=2
	tbnz	w11, #5, LBB0_231
LBB0_224:                               ; %else340
                                        ;   in Loop: Header=BB0_218 Depth=2
	tbnz	w11, #6, LBB0_232
LBB0_225:                               ; %else342
                                        ;   in Loop: Header=BB0_218 Depth=2
	tbz	w11, #7, LBB0_217
	b	LBB0_233
LBB0_226:                               ; %cond.store329
                                        ;   in Loop: Header=BB0_218 Depth=2
	str	s7, [x10]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB0_220
LBB0_227:                               ; %cond.store331
                                        ;   in Loop: Header=BB0_218 Depth=2
	add	x12, x10, #4
	st1.s	{ v7 }[1], [x12]
	tbz	w11, #2, LBB0_221
LBB0_228:                               ; %cond.store333
                                        ;   in Loop: Header=BB0_218 Depth=2
	add	x12, x10, #8
	st1.s	{ v7 }[2], [x12]
	tbz	w11, #3, LBB0_222
LBB0_229:                               ; %cond.store335
                                        ;   in Loop: Header=BB0_218 Depth=2
	add	x12, x10, #12
	st1.s	{ v7 }[3], [x12]
	fmul.4s	v3, v3, v4
	fmul.4s	v4, v5, v6
	fadd.4s	v3, v3, v4
	and.16b	v3, v1, v3
	tbz	w11, #4, LBB0_223
LBB0_230:                               ; %cond.store337
                                        ;   in Loop: Header=BB0_218 Depth=2
	str	s3, [x10, #16]
	tbz	w11, #5, LBB0_224
LBB0_231:                               ; %cond.store339
                                        ;   in Loop: Header=BB0_218 Depth=2
	add	x12, x10, #20
	st1.s	{ v3 }[1], [x12]
	tbz	w11, #6, LBB0_225
LBB0_232:                               ; %cond.store341
                                        ;   in Loop: Header=BB0_218 Depth=2
	add	x12, x10, #24
	st1.s	{ v3 }[2], [x12]
	tbz	w11, #7, LBB0_217
LBB0_233:                               ; %cond.store343
                                        ;   in Loop: Header=BB0_218 Depth=2
	add	x10, x10, #28
	st1.s	{ v3 }[3], [x10]
	b	LBB0_217
LBB0_234:                               ; %block.batch.exit.loopexit
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	stp	w15, w14, [x9]
	str	w13, [x9, #8]
	mov	w8, #24                         ; =0x18
	str	w8, [x9, #36]
LBB0_235:                               ; %block.batch.exit
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #2256
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp], #112              ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
                                        ; -- End function
.subsections_via_symbols

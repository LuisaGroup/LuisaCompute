; ModuleID = '/tmp/luisa-packet-inline.UY1lIE/rope-no-slp.ll'
source_filename = "luisa-simd-kernel"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-darwin"

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), i32 immarg, <8 x i1>, <8 x float>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), i32 immarg, <8 x i1>) #1

; Function Attrs: nofree norecurse nosync nounwind
define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly captures(none) %argument_buffer, ptr readnone captures(none) %return_lanes, ptr noalias nonnull captures(none) %launch_config, i32 %block_count) local_unnamed_addr #2 {
block.batch.prologue:
  %tile_snapshot.local.i39.i = alloca [1536 x i8], align 4
  %tile_snapshot.local1.i40.i = alloca [1536 x i8], align 4
  %tile_snapshot.local4.i41.i = alloca [1536 x i8], align 4
  %tile_snapshot.local7.i42.i = alloca [1536 x i8], align 4
  %tile_snapshot.local.i3.i = alloca [1536 x i8], align 4
  %tile_snapshot.local1.i4.i = alloca [1536 x i8], align 4
  %tile_snapshot.local4.i5.i = alloca [1536 x i8], align 4
  %tile_snapshot.local7.i6.i = alloca [1536 x i8], align 4
  %tile_snapshot.local.i.i = alloca [1536 x i8], align 4
  %tile_snapshot.local1.i.i = alloca [1536 x i8], align 4
  %tile_snapshot.local4.i.i = alloca [1536 x i8], align 4
  %tile_snapshot.local7.i.i = alloca [1536 x i8], align 4
  %block.y.address = getelementptr inbounds nuw i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds nuw i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds nuw i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds nuw i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds nuw i8, ptr %launch_config, i64 48
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop.preheader

block.batch.loop.preheader:                       ; preds = %block.batch.prologue
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.x = load i32, ptr %launch_config, align 4
  %dispatch.size.x.address.i = getelementptr inbounds nuw i8, ptr %launch_config, i64 12
  %dispatch.size.x.i = load i32, ptr %dispatch.size.x.address.i, align 4, !alias.scope !0, !noalias !3
  %dispatch.size.x.i64.i = zext i32 %dispatch.size.x.i to i64
  %0 = getelementptr i8, ptr %argument_buffer, i64 16
  %1 = getelementptr i8, ptr %argument_buffer, i64 32
  %2 = getelementptr i8, ptr %argument_buffer, i64 48
  br label %block.batch.loop

block.batch.loop:                                 ; preds = %llm_rows.packet_batch.exit, %block.batch.loop.preheader
  %block.index = phi i32 [ %block.index.next, %llm_rows.packet_batch.exit ], [ 0, %block.batch.loop.preheader ]
  %block.x = phi i32 [ %block.x.next, %llm_rows.packet_batch.exit ], [ %initial.block.x, %block.batch.loop.preheader ]
  %block.y = phi i32 [ %block.y.next, %llm_rows.packet_batch.exit ], [ %initial.block.y, %block.batch.loop.preheader ]
  %block.z = phi i32 [ %block.z.next, %llm_rows.packet_batch.exit ], [ %initial.block.z, %block.batch.loop.preheader ]
  tail call void @llvm.experimental.noalias.scope.decl(metadata !3)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !0)
  %3 = zext i32 %block.x to i64
  %block.origin.x.i = shl nuw nsw i64 %3, 5
  %block.origin.in.range.i = icmp samesign ule i64 %block.origin.x.i, %dispatch.size.x.i64.i
  %block.origin.safe.i = select i1 %block.origin.in.range.i, i64 %block.origin.x.i, i64 0
  %4 = icmp samesign ult i64 %block.origin.safe.i, %dispatch.size.x.i64.i
  %5 = sub nsw i64 %dispatch.size.x.i64.i, %block.origin.safe.i
  %6 = tail call i64 @llvm.umin.i64(i64 %5, i64 32)
  %7 = and i1 %block.origin.in.range.i, %4
  %packet.range.remaining.i = select i1 %7, i64 %6, i64 0
  %8 = icmp samesign ugt i64 %packet.range.remaining.i, 31
  br i1 %8, label %packet.batch.full.loop.preheader.i, label %packet.batch.partial.i

packet.batch.full.loop.preheader.i:               ; preds = %block.batch.loop
  %9 = load ptr, ptr %argument_buffer, align 16, !alias.scope !5, !noalias !8
  %10 = load ptr, ptr %0, align 16, !alias.scope !5, !noalias !8
  %11 = load ptr, ptr %1, align 16, !alias.scope !5, !noalias !8
  %12 = load ptr, ptr %2, align 16, !alias.scope !5, !noalias !8
  %13 = ptrtoint ptr %9 to i64
  %14 = ptrtoint ptr %12 to i64
  %15 = icmp uge ptr %9, %12
  %16 = sub i64 %13, %14
  %17 = icmp ugt i64 %16, 396287
  %18 = and i1 %15, %17
  %19 = icmp uge ptr %12, %9
  %20 = sub i64 %14, %13
  %21 = icmp ugt i64 %20, 396287
  %22 = and i1 %19, %21
  %23 = or i1 %18, %22
  %24 = ptrtoint ptr %10 to i64
  %25 = icmp uge ptr %10, %12
  %26 = sub i64 %24, %14
  %27 = icmp ugt i64 %26, 396287
  %28 = and i1 %25, %27
  %29 = icmp uge ptr %12, %10
  %30 = sub i64 %14, %24
  %31 = icmp ugt i64 %30, 198143
  %32 = and i1 %29, %31
  %33 = or i1 %28, %32
  %34 = and i1 %23, %33
  %35 = ptrtoint ptr %11 to i64
  %36 = icmp uge ptr %11, %12
  %37 = sub i64 %35, %14
  %38 = icmp ugt i64 %37, 396287
  %39 = and i1 %36, %38
  %40 = icmp uge ptr %12, %11
  %41 = sub i64 %14, %35
  %42 = icmp ugt i64 %41, 198143
  %43 = and i1 %40, %42
  %44 = or i1 %39, %43
  %45 = and i1 %44, %34
  %scevgep.i = getelementptr i8, ptr %9, i64 1536
  %invariant.gep117.i = getelementptr i8, ptr %12, i64 1536
  %46 = shl i32 %block.x, 2
  br label %packet.batch.full.loop.i

packet.batch.partial.i:                           ; preds = %block.batch.loop
  %packet.full.count.i641.i = lshr i64 %packet.range.remaining.i, 3
  %packet.full.count.i = trunc nuw nsw i64 %packet.full.count.i641.i to i32
  %47 = trunc nuw nsw i64 %packet.range.remaining.i to i32
  %packet.tail.lane.count.i = and i32 %47, 7
  %.not.i = icmp samesign ult i64 %packet.range.remaining.i, 8
  br i1 %.not.i, label %packet.batch.tail.check.i, label %packet.batch.partial.full.loop.preheader.i

packet.batch.partial.full.loop.preheader.i:       ; preds = %packet.batch.partial.i
  %48 = load ptr, ptr %argument_buffer, align 16, !alias.scope !10, !noalias !13
  %49 = load ptr, ptr %0, align 16, !alias.scope !10, !noalias !13
  %50 = load ptr, ptr %1, align 16, !alias.scope !10, !noalias !13
  %51 = load ptr, ptr %2, align 16, !alias.scope !10, !noalias !13
  %52 = ptrtoint ptr %48 to i64
  %53 = ptrtoint ptr %51 to i64
  %54 = icmp uge ptr %48, %51
  %55 = sub i64 %52, %53
  %56 = icmp ugt i64 %55, 396287
  %57 = and i1 %54, %56
  %58 = icmp uge ptr %51, %48
  %59 = sub i64 %53, %52
  %60 = icmp ugt i64 %59, 396287
  %61 = and i1 %58, %60
  %62 = or i1 %57, %61
  %63 = ptrtoint ptr %49 to i64
  %64 = icmp uge ptr %49, %51
  %65 = sub i64 %63, %53
  %66 = icmp ugt i64 %65, 396287
  %67 = and i1 %64, %66
  %68 = icmp uge ptr %51, %49
  %69 = sub i64 %53, %63
  %70 = icmp ugt i64 %69, 198143
  %71 = and i1 %68, %70
  %72 = or i1 %67, %71
  %73 = and i1 %62, %72
  %74 = ptrtoint ptr %50 to i64
  %75 = icmp uge ptr %50, %51
  %76 = sub i64 %74, %53
  %77 = icmp ugt i64 %76, 396287
  %78 = and i1 %75, %77
  %79 = icmp uge ptr %51, %50
  %80 = sub i64 %53, %74
  %81 = icmp ugt i64 %80, 198143
  %82 = and i1 %79, %81
  %83 = or i1 %78, %82
  %84 = and i1 %83, %73
  %85 = shl i32 %block.x, 2
  br label %packet.batch.partial.full.loop.i

packet.batch.full.loop.i:                         ; preds = %llm_rows.full_packet.exit.i, %packet.batch.full.loop.preheader.i
  %packet.index.i = phi i32 [ %packet.index.next.i, %llm_rows.full_packet.exit.i ], [ 0, %packet.batch.full.loop.preheader.i ]
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  call void @llvm.lifetime.start.p0(i64 1536, ptr nonnull %tile_snapshot.local.i.i), !noalias !16
  call void @llvm.lifetime.start.p0(i64 1536, ptr nonnull %tile_snapshot.local1.i.i), !noalias !16
  call void @llvm.lifetime.start.p0(i64 1536, ptr nonnull %tile_snapshot.local4.i.i), !noalias !16
  call void @llvm.lifetime.start.p0(i64 1536, ptr nonnull %tile_snapshot.local7.i.i), !noalias !16
  %86 = add nuw nsw i32 %packet.index.i, %46
  %.scalar109.i = and i32 %86, 536870911
  %87 = insertelement <8 x i32> poison, i32 %.scalar109.i, i64 0
  %88 = shufflevector <8 x i32> %87, <8 x i32> poison, <8 x i32> zeroinitializer
  %89 = zext nneg <8 x i32> %88 to <8 x i64>
  br i1 %45, label %direct.schedule.2.i.preheader.i, label %direct.schedule.6.i.preheader.i

direct.schedule.6.i.preheader.i:                  ; preds = %packet.batch.full.loop.i
  %90 = extractelement <8 x i64> %89, i64 0
  %91 = mul nuw nsw i64 %90, 3072
  %invariant.gep.i = getelementptr i8, ptr %9, i64 %91
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(1536) %tile_snapshot.local.i.i, ptr noundef nonnull align 1 dereferenceable(1536) %invariant.gep.i, i64 1536, i1 false), !noalias !17
  %scevgep104.i = getelementptr i8, ptr %scevgep.i, i64 %91
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(1536) %tile_snapshot.local1.i.i, ptr noundef nonnull align 1 dereferenceable(1536) %scevgep104.i, i64 1536, i1 false), !noalias !17
  %92 = mul nuw nsw i64 %90, 1536
  %invariant.gep90.i = getelementptr i8, ptr %10, i64 %92
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(1536) %tile_snapshot.local4.i.i, ptr noundef nonnull align 1 dereferenceable(1536) %invariant.gep90.i, i64 1536, i1 false), !noalias !17
  %invariant.gep93.i = getelementptr i8, ptr %11, i64 %92
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(1536) %tile_snapshot.local7.i.i, ptr noundef nonnull align 1 dereferenceable(1536) %invariant.gep93.i, i64 1536, i1 false), !noalias !17
  %invariant.gep96.i = getelementptr i8, ptr %12, i64 %91
  br label %direct.true111.i.i

direct.schedule.2.i.preheader.i:                  ; preds = %packet.batch.full.loop.i
  %93 = mul nuw nsw <8 x i64> %89, splat (i64 768)
  %94 = extractelement <8 x i64> %93, i64 0
  %95 = add nuw nsw i64 %94, 384
  %96 = extractelement <8 x i64> %89, i64 0
  %97 = mul nuw nsw i64 %96, 384
  br label %direct.true30.i.i

direct.schedule.21.i.preheader.i:                 ; preds = %direct.true111.i.i
  %gep.i = getelementptr i8, ptr %invariant.gep117.i, i64 %91
  br label %direct.true144.i.i

direct.true30.i.i:                                ; preds = %direct.true30.i.i, %direct.schedule.2.i.preheader.i
  %.slot.0.i100.i = phi i64 [ 0, %direct.schedule.2.i.preheader.i ], [ %114, %direct.true30.i.i ]
  %98 = shl nuw nsw i64 %.slot.0.i100.i, 3
  %.splatinsert33.i.i = insertelement <8 x i64> poison, i64 %98, i64 0
  %.splat34.i.i = shufflevector <8 x i64> %.splatinsert33.i.i, <8 x i64> poison, <8 x i32> zeroinitializer
  %99 = or disjoint <8 x i64> %.splat34.i.i, <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>
  %100 = add nuw nsw <8 x i64> %99, %93
  %101 = extractelement <8 x i64> %100, i64 0
  %102 = shl i64 %101, 2
  %buffer.contiguous.address.i.i = getelementptr i8, ptr %9, i64 %102
  %unmaskedload96.i.i = load <8 x float>, ptr %buffer.contiguous.address.i.i, align 1, !noalias !17
  %103 = add nuw nsw i64 %95, %98
  %104 = shl nuw nsw i64 %103, 2
  %buffer.contiguous.address36.i.i = getelementptr i8, ptr %9, i64 %104
  %unmaskedload97.i.i = load <8 x float>, ptr %buffer.contiguous.address36.i.i, align 1, !noalias !17
  %105 = extractelement <8 x i64> %99, i64 0
  %106 = add nuw nsw i64 %105, %97
  %107 = shl i64 %106, 2
  %buffer.contiguous.address38.i.i = getelementptr i8, ptr %10, i64 %107
  %unmaskedload98.i.i = load <8 x float>, ptr %buffer.contiguous.address38.i.i, align 1, !noalias !17
  %buffer.contiguous.address40.i.i = getelementptr i8, ptr %11, i64 %107
  %unmaskedload99.i.i = load <8 x float>, ptr %buffer.contiguous.address40.i.i, align 1, !noalias !17
  %108 = fmul <8 x float> %unmaskedload96.i.i, %unmaskedload98.i.i
  %109 = fmul <8 x float> %unmaskedload97.i.i, %unmaskedload99.i.i
  %110 = fsub <8 x float> %108, %109
  %buffer.contiguous.address42.i.i = getelementptr i8, ptr %12, i64 %102
  store <8 x float> %110, ptr %buffer.contiguous.address42.i.i, align 1, !noalias !17
  %111 = fmul <8 x float> %unmaskedload96.i.i, %unmaskedload99.i.i
  %112 = fmul <8 x float> %unmaskedload97.i.i, %unmaskedload98.i.i
  %113 = fadd <8 x float> %112, %111
  %buffer.contiguous.address43.i.i = getelementptr i8, ptr %12, i64 %104
  store <8 x float> %113, ptr %buffer.contiguous.address43.i.i, align 1, !noalias !17
  %114 = add nuw nsw i64 %.slot.0.i100.i, 1
  %exitcond107.not.i = icmp eq i64 %114, 48
  br i1 %exitcond107.not.i, label %llm_rows.full_packet.exit.i, label %direct.true30.i.i

direct.true111.i.i:                               ; preds = %direct.true111.i.i, %direct.schedule.6.i.preheader.i
  %.slot18.0.i98.i = phi i64 [ 0, %direct.schedule.6.i.preheader.i ], [ %119, %direct.true111.i.i ]
  %115 = shl nuw nsw i64 %.slot18.0.i98.i, 5
  %private.contiguous.address122.i.i = getelementptr i8, ptr %tile_snapshot.local.i.i, i64 %115
  %private.contiguous.load.i.i = load <8 x float>, ptr %private.contiguous.address122.i.i, align 4, !noalias !17
  %private.contiguous.address127.i.i = getelementptr i8, ptr %tile_snapshot.local4.i.i, i64 %115
  %private.contiguous.load128.i.i = load <8 x float>, ptr %private.contiguous.address127.i.i, align 4, !noalias !17
  %116 = fmul <8 x float> %private.contiguous.load.i.i, %private.contiguous.load128.i.i
  %private.contiguous.address133.i.i = getelementptr i8, ptr %tile_snapshot.local1.i.i, i64 %115
  %private.contiguous.load134.i.i = load <8 x float>, ptr %private.contiguous.address133.i.i, align 4, !noalias !17
  %private.contiguous.address139.i.i = getelementptr i8, ptr %tile_snapshot.local7.i.i, i64 %115
  %private.contiguous.load140.i.i = load <8 x float>, ptr %private.contiguous.address139.i.i, align 4, !noalias !17
  %117 = fmul <8 x float> %private.contiguous.load134.i.i, %private.contiguous.load140.i.i
  %118 = fsub <8 x float> %116, %117
  %gep97.i = getelementptr i8, ptr %invariant.gep96.i, i64 %115
  store <8 x float> %118, ptr %gep97.i, align 1, !noalias !17
  %119 = add nuw nsw i64 %.slot18.0.i98.i, 1
  %exitcond105.not.i = icmp eq i64 %119, 48
  br i1 %exitcond105.not.i, label %direct.schedule.21.i.preheader.i, label %direct.true111.i.i

direct.true144.i.i:                               ; preds = %direct.true144.i.i, %direct.schedule.21.i.preheader.i
  %.slot19.0.i99.i = phi i64 [ 0, %direct.schedule.21.i.preheader.i ], [ %124, %direct.true144.i.i ]
  %120 = shl i64 %.slot19.0.i99.i, 5
  %private.contiguous.address155.i.i = getelementptr i8, ptr %tile_snapshot.local.i.i, i64 %120
  %private.contiguous.load156.i.i = load <8 x float>, ptr %private.contiguous.address155.i.i, align 4, !noalias !17
  %private.contiguous.address161.i.i = getelementptr i8, ptr %tile_snapshot.local7.i.i, i64 %120
  %private.contiguous.load162.i.i = load <8 x float>, ptr %private.contiguous.address161.i.i, align 4, !noalias !17
  %121 = fmul <8 x float> %private.contiguous.load156.i.i, %private.contiguous.load162.i.i
  %private.contiguous.address167.i.i = getelementptr i8, ptr %tile_snapshot.local1.i.i, i64 %120
  %private.contiguous.load168.i.i = load <8 x float>, ptr %private.contiguous.address167.i.i, align 4, !noalias !17
  %private.contiguous.address173.i.i = getelementptr i8, ptr %tile_snapshot.local4.i.i, i64 %120
  %private.contiguous.load174.i.i = load <8 x float>, ptr %private.contiguous.address173.i.i, align 4, !noalias !17
  %122 = fmul <8 x float> %private.contiguous.load168.i.i, %private.contiguous.load174.i.i
  %123 = fadd <8 x float> %121, %122
  %gep115.i = getelementptr i8, ptr %gep.i, i64 %120
  store <8 x float> %123, ptr %gep115.i, align 1, !noalias !17
  %124 = add nuw nsw i64 %.slot19.0.i99.i, 1
  %exitcond106.not.i = icmp eq i64 %124, 48
  br i1 %exitcond106.not.i, label %llm_rows.full_packet.exit.i, label %direct.true144.i.i

llm_rows.full_packet.exit.i:                      ; preds = %direct.true144.i.i, %direct.true30.i.i
  call void @llvm.lifetime.end.p0(i64 1536, ptr nonnull %tile_snapshot.local.i.i), !noalias !16
  call void @llvm.lifetime.end.p0(i64 1536, ptr nonnull %tile_snapshot.local1.i.i), !noalias !16
  call void @llvm.lifetime.end.p0(i64 1536, ptr nonnull %tile_snapshot.local4.i.i), !noalias !16
  call void @llvm.lifetime.end.p0(i64 1536, ptr nonnull %tile_snapshot.local7.i.i), !noalias !16
  %packet.index.next.i = add nuw nsw i32 %packet.index.i, 1
  %exitcond108.not.i = icmp eq i32 %packet.index.next.i, 4
  br i1 %exitcond108.not.i, label %llm_rows.packet_batch.exit, label %packet.batch.full.loop.i

packet.batch.partial.full.loop.i:                 ; preds = %llm_rows.full_packet.exit38.i, %packet.batch.partial.full.loop.preheader.i
  %partial.packet.index.i = phi i32 [ %partial.packet.index.next.i, %llm_rows.full_packet.exit38.i ], [ 0, %packet.batch.partial.full.loop.preheader.i ]
  tail call void @llvm.experimental.noalias.scope.decl(metadata !18)
  call void @llvm.lifetime.start.p0(i64 1536, ptr nonnull %tile_snapshot.local.i3.i), !noalias !16
  call void @llvm.lifetime.start.p0(i64 1536, ptr nonnull %tile_snapshot.local1.i4.i), !noalias !16
  call void @llvm.lifetime.start.p0(i64 1536, ptr nonnull %tile_snapshot.local4.i5.i), !noalias !16
  call void @llvm.lifetime.start.p0(i64 1536, ptr nonnull %tile_snapshot.local7.i6.i), !noalias !16
  %125 = add nuw nsw i32 %partial.packet.index.i, %85
  %.scalar117.i.i = and i32 %125, 536870911
  %126 = insertelement <8 x i32> poison, i32 %.scalar117.i.i, i64 0
  %127 = shufflevector <8 x i32> %126, <8 x i32> poison, <8 x i32> zeroinitializer
  %128 = zext nneg <8 x i32> %127 to <8 x i64>
  br i1 %84, label %direct.schedule.2.preheader.i.i, label %direct.schedule.6.preheader.i.i

direct.schedule.6.preheader.i.i:                  ; preds = %packet.batch.partial.full.loop.i
  %129 = extractelement <8 x i64> %128, i64 0
  %130 = mul nuw nsw i64 %129, 3072
  %invariant.gep.i.i = getelementptr i8, ptr %48, i64 %130
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(1536) %tile_snapshot.local.i3.i, ptr noundef nonnull align 1 dereferenceable(1536) %invariant.gep.i.i, i64 1536, i1 false), !noalias !19
  %scevgep.i.i = getelementptr i8, ptr %invariant.gep.i.i, i64 1536
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(1536) %tile_snapshot.local1.i4.i, ptr noundef nonnull align 1 dereferenceable(1536) %scevgep.i.i, i64 1536, i1 false), !noalias !19
  %131 = mul nuw nsw i64 %129, 1536
  %invariant.gep103.i.i = getelementptr i8, ptr %49, i64 %131
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(1536) %tile_snapshot.local4.i5.i, ptr noundef nonnull align 1 dereferenceable(1536) %invariant.gep103.i.i, i64 1536, i1 false), !noalias !19
  %invariant.gep106.i.i = getelementptr i8, ptr %50, i64 %131
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(1536) %tile_snapshot.local7.i6.i, ptr noundef nonnull align 1 dereferenceable(1536) %invariant.gep106.i.i, i64 1536, i1 false), !noalias !19
  %invariant.gep109.i.i = getelementptr i8, ptr %51, i64 %130
  br label %direct.true111.i7.i

direct.schedule.2.preheader.i.i:                  ; preds = %packet.batch.partial.full.loop.i
  %132 = mul nuw nsw <8 x i64> %128, splat (i64 768)
  %133 = extractelement <8 x i64> %132, i64 0
  %134 = add nuw nsw i64 %133, 384
  %135 = extractelement <8 x i64> %128, i64 0
  %136 = mul nuw nsw i64 %135, 384
  br label %direct.true30.i25.i

direct.schedule.21.preheader.i.i:                 ; preds = %direct.true111.i7.i
  %invariant.gep120.i.i = getelementptr i8, ptr %invariant.gep109.i.i, i64 1536
  br label %direct.true144.i16.i

direct.true30.i25.i:                              ; preds = %direct.true30.i25.i, %direct.schedule.2.preheader.i.i
  %.slot.0113.i.i = phi i64 [ 0, %direct.schedule.2.preheader.i.i ], [ %153, %direct.true30.i25.i ]
  %137 = shl nuw nsw i64 %.slot.0113.i.i, 3
  %.splatinsert33.i26.i = insertelement <8 x i64> poison, i64 %137, i64 0
  %.splat34.i27.i = shufflevector <8 x i64> %.splatinsert33.i26.i, <8 x i64> poison, <8 x i32> zeroinitializer
  %138 = or disjoint <8 x i64> %.splat34.i27.i, <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>
  %139 = add nuw nsw <8 x i64> %138, %132
  %140 = extractelement <8 x i64> %139, i64 0
  %141 = shl i64 %140, 2
  %buffer.contiguous.address.i28.i = getelementptr i8, ptr %48, i64 %141
  %unmaskedload96.i29.i = load <8 x float>, ptr %buffer.contiguous.address.i28.i, align 1, !noalias !19
  %142 = add nuw nsw i64 %134, %137
  %143 = shl nuw nsw i64 %142, 2
  %buffer.contiguous.address36.i30.i = getelementptr i8, ptr %48, i64 %143
  %unmaskedload97.i31.i = load <8 x float>, ptr %buffer.contiguous.address36.i30.i, align 1, !noalias !19
  %144 = extractelement <8 x i64> %138, i64 0
  %145 = add nuw nsw i64 %144, %136
  %146 = shl i64 %145, 2
  %buffer.contiguous.address38.i32.i = getelementptr i8, ptr %49, i64 %146
  %unmaskedload98.i33.i = load <8 x float>, ptr %buffer.contiguous.address38.i32.i, align 1, !noalias !19
  %buffer.contiguous.address40.i34.i = getelementptr i8, ptr %50, i64 %146
  %unmaskedload99.i35.i = load <8 x float>, ptr %buffer.contiguous.address40.i34.i, align 1, !noalias !19
  %147 = fmul <8 x float> %unmaskedload96.i29.i, %unmaskedload98.i33.i
  %148 = fmul <8 x float> %unmaskedload97.i31.i, %unmaskedload99.i35.i
  %149 = fsub <8 x float> %147, %148
  %buffer.contiguous.address42.i36.i = getelementptr i8, ptr %51, i64 %141
  store <8 x float> %149, ptr %buffer.contiguous.address42.i36.i, align 1, !noalias !19
  %150 = fmul <8 x float> %unmaskedload96.i29.i, %unmaskedload99.i35.i
  %151 = fmul <8 x float> %unmaskedload97.i31.i, %unmaskedload98.i33.i
  %152 = fadd <8 x float> %151, %150
  %buffer.contiguous.address43.i37.i = getelementptr i8, ptr %51, i64 %143
  store <8 x float> %152, ptr %buffer.contiguous.address43.i37.i, align 1, !noalias !19
  %153 = add nuw nsw i64 %.slot.0113.i.i, 1
  %exitcond116.not.i.i = icmp eq i64 %153, 48
  br i1 %exitcond116.not.i.i, label %llm_rows.full_packet.exit38.i, label %direct.true30.i25.i

direct.true111.i7.i:                              ; preds = %direct.true111.i7.i, %direct.schedule.6.preheader.i.i
  %.slot18.0111.i.i = phi i64 [ 0, %direct.schedule.6.preheader.i.i ], [ %158, %direct.true111.i7.i ]
  %154 = shl nuw nsw i64 %.slot18.0111.i.i, 5
  %private.contiguous.address122.i8.i = getelementptr i8, ptr %tile_snapshot.local.i3.i, i64 %154
  %private.contiguous.load.i9.i = load <8 x float>, ptr %private.contiguous.address122.i8.i, align 4, !noalias !19
  %private.contiguous.address127.i10.i = getelementptr i8, ptr %tile_snapshot.local4.i5.i, i64 %154
  %private.contiguous.load128.i11.i = load <8 x float>, ptr %private.contiguous.address127.i10.i, align 4, !noalias !19
  %155 = fmul <8 x float> %private.contiguous.load.i9.i, %private.contiguous.load128.i11.i
  %private.contiguous.address133.i12.i = getelementptr i8, ptr %tile_snapshot.local1.i4.i, i64 %154
  %private.contiguous.load134.i13.i = load <8 x float>, ptr %private.contiguous.address133.i12.i, align 4, !noalias !19
  %private.contiguous.address139.i14.i = getelementptr i8, ptr %tile_snapshot.local7.i6.i, i64 %154
  %private.contiguous.load140.i15.i = load <8 x float>, ptr %private.contiguous.address139.i14.i, align 4, !noalias !19
  %156 = fmul <8 x float> %private.contiguous.load134.i13.i, %private.contiguous.load140.i15.i
  %157 = fsub <8 x float> %155, %156
  %gep110.i.i = getelementptr i8, ptr %invariant.gep109.i.i, i64 %154
  store <8 x float> %157, ptr %gep110.i.i, align 1, !noalias !19
  %158 = add nuw nsw i64 %.slot18.0111.i.i, 1
  %exitcond.not.i.i = icmp eq i64 %158, 48
  br i1 %exitcond.not.i.i, label %direct.schedule.21.preheader.i.i, label %direct.true111.i7.i

direct.true144.i16.i:                             ; preds = %direct.true144.i16.i, %direct.schedule.21.preheader.i.i
  %.slot19.0112.i.i = phi i64 [ 0, %direct.schedule.21.preheader.i.i ], [ %163, %direct.true144.i16.i ]
  %159 = shl i64 %.slot19.0112.i.i, 5
  %private.contiguous.address155.i17.i = getelementptr i8, ptr %tile_snapshot.local.i3.i, i64 %159
  %private.contiguous.load156.i18.i = load <8 x float>, ptr %private.contiguous.address155.i17.i, align 4, !noalias !19
  %private.contiguous.address161.i19.i = getelementptr i8, ptr %tile_snapshot.local7.i6.i, i64 %159
  %private.contiguous.load162.i20.i = load <8 x float>, ptr %private.contiguous.address161.i19.i, align 4, !noalias !19
  %160 = fmul <8 x float> %private.contiguous.load156.i18.i, %private.contiguous.load162.i20.i
  %private.contiguous.address167.i21.i = getelementptr i8, ptr %tile_snapshot.local1.i4.i, i64 %159
  %private.contiguous.load168.i22.i = load <8 x float>, ptr %private.contiguous.address167.i21.i, align 4, !noalias !19
  %private.contiguous.address173.i23.i = getelementptr i8, ptr %tile_snapshot.local4.i5.i, i64 %159
  %private.contiguous.load174.i24.i = load <8 x float>, ptr %private.contiguous.address173.i23.i, align 4, !noalias !19
  %161 = fmul <8 x float> %private.contiguous.load168.i22.i, %private.contiguous.load174.i24.i
  %162 = fadd <8 x float> %160, %161
  %gep121.i.i = getelementptr i8, ptr %invariant.gep120.i.i, i64 %159
  store <8 x float> %162, ptr %gep121.i.i, align 1, !noalias !19
  %163 = add nuw nsw i64 %.slot19.0112.i.i, 1
  %exitcond115.not.i.i = icmp eq i64 %163, 48
  br i1 %exitcond115.not.i.i, label %llm_rows.full_packet.exit38.i, label %direct.true144.i16.i

llm_rows.full_packet.exit38.i:                    ; preds = %direct.true144.i16.i, %direct.true30.i25.i
  call void @llvm.lifetime.end.p0(i64 1536, ptr nonnull %tile_snapshot.local.i3.i), !noalias !16
  call void @llvm.lifetime.end.p0(i64 1536, ptr nonnull %tile_snapshot.local1.i4.i), !noalias !16
  call void @llvm.lifetime.end.p0(i64 1536, ptr nonnull %tile_snapshot.local4.i5.i), !noalias !16
  call void @llvm.lifetime.end.p0(i64 1536, ptr nonnull %tile_snapshot.local7.i6.i), !noalias !16
  %partial.packet.index.next.i = add nuw nsw i32 %partial.packet.index.i, 1
  %exitcond.not.i = icmp eq i32 %partial.packet.index.next.i, %packet.full.count.i
  br i1 %exitcond.not.i, label %packet.batch.tail.check.i, label %packet.batch.partial.full.loop.i

packet.batch.tail.check.i:                        ; preds = %llm_rows.full_packet.exit38.i, %packet.batch.partial.i
  %.not2.i = icmp eq i32 %packet.tail.lane.count.i, 0
  br i1 %.not2.i, label %llm_rows.packet_batch.exit, label %packet.batch.tail.call.i

packet.batch.tail.call.i:                         ; preds = %packet.batch.tail.check.i
  tail call void @llvm.experimental.noalias.scope.decl(metadata !20)
  call void @llvm.lifetime.start.p0(i64 1536, ptr nonnull %tile_snapshot.local.i39.i), !noalias !16
  call void @llvm.lifetime.start.p0(i64 1536, ptr nonnull %tile_snapshot.local1.i40.i), !noalias !16
  call void @llvm.lifetime.start.p0(i64 1536, ptr nonnull %tile_snapshot.local4.i41.i), !noalias !16
  call void @llvm.lifetime.start.p0(i64 1536, ptr nonnull %tile_snapshot.local7.i42.i), !noalias !16
  %164 = load ptr, ptr %argument_buffer, align 16, !alias.scope !23, !noalias !24
  %165 = load ptr, ptr %0, align 16, !alias.scope !23, !noalias !24
  %166 = load ptr, ptr %1, align 16, !alias.scope !23, !noalias !24
  %167 = load ptr, ptr %2, align 16, !alias.scope !23, !noalias !24
  %.splatinsert28.i.i = insertelement <8 x i32> poison, i32 %packet.tail.lane.count.i, i64 0
  %.splat29.i.i = shufflevector <8 x i32> %.splatinsert28.i.i, <8 x i32> poison, <8 x i32> zeroinitializer
  %168 = icmp samesign ugt <8 x i32> %.splat29.i.i, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %169 = bitcast <8 x i1> %168 to i8
  %.not.i.i = icmp eq i8 %169, 0
  br i1 %.not.i.i, label %llm_rows.exit.i, label %direct.activate.i.i

direct.schedule.9.preheader.i.i:                  ; preds = %direct.true46.i46.i
  %invariant.gep118.i.i = getelementptr i8, ptr %invariant.gep.i45.i, i64 1536
  br label %direct.true60.i49.i

direct.schedule.12.preheader.i.i:                 ; preds = %direct.true60.i49.i
  %170 = mul nuw nsw i64 %210, 1536
  %invariant.gep96.i.i = getelementptr i8, ptr %165, i64 %170
  br label %direct.true77.i51.i

direct.schedule.15.preheader.i.i:                 ; preds = %direct.true77.i51.i
  %invariant.gep99.i.i = getelementptr i8, ptr %166, i64 %170
  br label %direct.true94.i53.i

direct.schedule.18.preheader.i.i:                 ; preds = %direct.true94.i53.i
  %invariant.gep102.i.i = getelementptr i8, ptr %167, i64 %211
  br label %direct.true111.i55.i

direct.schedule.21.preheader.i64.i:               ; preds = %direct.true111.i55.i
  %invariant.gep122.i.i = getelementptr i8, ptr %invariant.gep102.i.i, i64 1536
  br label %direct.true144.i66.i

direct.activate.i.i:                              ; preds = %packet.batch.tail.call.i
  %171 = select <8 x i1> %168, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> zeroinitializer
  %172 = shl i32 %block.x, 2
  %173 = and i32 %172, 536870908
  %.scalar114.i.i = or disjoint i32 %173, %packet.full.count.i
  %174 = insertelement <8 x i32> poison, i32 %.scalar114.i.i, i64 0
  %175 = shufflevector <8 x i32> %174, <8 x i32> poison, <8 x i32> zeroinitializer
  %narrow.i.i = select <8 x i1> %168, <8 x i32> %175, <8 x i32> zeroinitializer
  %176 = zext nneg <8 x i32> %narrow.i.i to <8 x i64>
  %177 = ptrtoint ptr %164 to i64
  %178 = ptrtoint ptr %167 to i64
  %179 = icmp uge ptr %164, %167
  %180 = sub i64 %177, %178
  %181 = icmp ugt i64 %180, 396287
  %182 = and i1 %179, %181
  %183 = icmp uge ptr %167, %164
  %184 = sub i64 %178, %177
  %185 = icmp ugt i64 %184, 396287
  %186 = and i1 %183, %185
  %187 = or i1 %182, %186
  %188 = ptrtoint ptr %165 to i64
  %189 = icmp uge ptr %165, %167
  %190 = sub i64 %188, %178
  %191 = icmp ugt i64 %190, 396287
  %192 = and i1 %189, %191
  %193 = icmp uge ptr %167, %165
  %194 = sub i64 %178, %188
  %195 = icmp ugt i64 %194, 198143
  %196 = and i1 %193, %195
  %197 = or i1 %192, %196
  %198 = and i1 %187, %197
  %199 = ptrtoint ptr %166 to i64
  %200 = icmp uge ptr %166, %167
  %201 = sub i64 %199, %178
  %202 = icmp ugt i64 %201, 396287
  %203 = and i1 %200, %202
  %204 = icmp uge ptr %167, %166
  %205 = sub i64 %178, %199
  %206 = icmp ugt i64 %205, 198143
  %207 = and i1 %204, %206
  %208 = or i1 %203, %207
  %209 = and i1 %208, %198
  br i1 %209, label %direct.schedule.2.preheader.i75.i, label %direct.schedule.6.preheader.i44.i

direct.schedule.6.preheader.i44.i:                ; preds = %direct.activate.i.i
  %210 = extractelement <8 x i64> %176, i64 0
  %211 = mul nuw nsw i64 %210, 3072
  %invariant.gep.i45.i = getelementptr i8, ptr %164, i64 %211
  br label %direct.true46.i46.i

direct.schedule.2.preheader.i75.i:                ; preds = %direct.activate.i.i
  %212 = mul nuw nsw <8 x i64> %176, splat (i64 768)
  %213 = extractelement <8 x i64> %212, i64 0
  %214 = add nuw nsw i64 %213, 384
  %215 = extractelement <8 x i64> %176, i64 0
  %216 = mul nuw nsw i64 %215, 384
  br label %direct.true30.i76.i

direct.true30.i76.i:                              ; preds = %direct.true30.i76.i, %direct.schedule.2.preheader.i75.i
  %.slot.0106.i.i = phi i64 [ 0, %direct.schedule.2.preheader.i75.i ], [ %233, %direct.true30.i76.i ]
  %217 = shl nuw nsw i64 %.slot.0106.i.i, 3
  %.splatinsert33.i77.i = insertelement <8 x i64> poison, i64 %217, i64 0
  %.splat34.i78.i = shufflevector <8 x i64> %.splatinsert33.i77.i, <8 x i64> poison, <8 x i32> zeroinitializer
  %218 = or disjoint <8 x i64> %.splat34.i78.i, %171
  %219 = add nuw nsw <8 x i64> %218, %212
  %220 = extractelement <8 x i64> %219, i64 0
  %221 = shl i64 %220, 2
  %buffer.contiguous.address.i79.i = getelementptr i8, ptr %164, i64 %221
  %buffer.contiguous.load.i.i = tail call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address.i79.i, i32 1, <8 x i1> %168, <8 x float> zeroinitializer), !noalias !26
  %222 = extractelement <8 x i64> %218, i64 0
  %223 = add nuw nsw i64 %214, %222
  %224 = shl i64 %223, 2
  %buffer.contiguous.address36.i80.i = getelementptr i8, ptr %164, i64 %224
  %buffer.contiguous.load37.i.i = tail call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address36.i80.i, i32 1, <8 x i1> %168, <8 x float> zeroinitializer), !noalias !26
  %225 = add nuw nsw i64 %222, %216
  %226 = shl i64 %225, 2
  %buffer.contiguous.address38.i81.i = getelementptr i8, ptr %165, i64 %226
  %buffer.contiguous.load39.i.i = tail call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address38.i81.i, i32 1, <8 x i1> %168, <8 x float> zeroinitializer), !noalias !26
  %buffer.contiguous.address40.i82.i = getelementptr i8, ptr %166, i64 %226
  %buffer.contiguous.load41.i.i = tail call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address40.i82.i, i32 1, <8 x i1> %168, <8 x float> zeroinitializer), !noalias !26
  %227 = fmul <8 x float> %buffer.contiguous.load.i.i, %buffer.contiguous.load39.i.i
  %228 = fmul <8 x float> %buffer.contiguous.load37.i.i, %buffer.contiguous.load41.i.i
  %229 = fsub <8 x float> %227, %228
  %buffer.contiguous.address42.i83.i = getelementptr i8, ptr %167, i64 %221
  tail call void @llvm.masked.store.v8f32.p0(<8 x float> %229, ptr %buffer.contiguous.address42.i83.i, i32 1, <8 x i1> %168), !noalias !26
  %230 = fmul <8 x float> %buffer.contiguous.load.i.i, %buffer.contiguous.load41.i.i
  %231 = fmul <8 x float> %buffer.contiguous.load37.i.i, %buffer.contiguous.load39.i.i
  %232 = fadd <8 x float> %231, %230
  %buffer.contiguous.address43.i84.i = getelementptr i8, ptr %167, i64 %224
  tail call void @llvm.masked.store.v8f32.p0(<8 x float> %232, ptr %buffer.contiguous.address43.i84.i, i32 1, <8 x i1> %168), !noalias !26
  %233 = add nuw nsw i64 %.slot.0106.i.i, 1
  %exitcond113.not.i.i = icmp eq i64 %233, 48
  br i1 %exitcond113.not.i.i, label %llm_rows.exit.i, label %direct.true30.i76.i

direct.true46.i46.i:                              ; preds = %direct.true46.i46.i, %direct.schedule.6.preheader.i44.i
  %.slot11.094.i.i = phi i64 [ 0, %direct.schedule.6.preheader.i44.i ], [ %236, %direct.true46.i46.i ]
  %234 = shl nuw nsw i64 %.slot11.094.i.i, 5
  %gep.i.i = getelementptr i8, ptr %invariant.gep.i45.i, i64 %234
  %buffer.contiguous.load54.i.i = tail call <8 x float> @llvm.masked.load.v8f32.p0(ptr %gep.i.i, i32 1, <8 x i1> %168, <8 x float> zeroinitializer), !noalias !26
  %private.contiguous.address.i47.i = getelementptr i8, ptr %tile_snapshot.local.i39.i, i64 %234
  %private.contiguous.preserve.i.i = load <8 x float>, ptr %private.contiguous.address.i47.i, align 4, !noalias !26
  %235 = select <8 x i1> %168, <8 x float> %buffer.contiguous.load54.i.i, <8 x float> %private.contiguous.preserve.i.i
  store <8 x float> %235, ptr %private.contiguous.address.i47.i, align 4, !noalias !26
  %236 = add nuw nsw i64 %.slot11.094.i.i, 1
  %exitcond.not.i48.i = icmp eq i64 %236, 48
  br i1 %exitcond.not.i48.i, label %direct.schedule.9.preheader.i.i, label %direct.true46.i46.i

direct.true60.i49.i:                              ; preds = %direct.true60.i49.i, %direct.schedule.9.preheader.i.i
  %.slot13.095.i.i = phi i64 [ 0, %direct.schedule.9.preheader.i.i ], [ %239, %direct.true60.i49.i ]
  %237 = shl i64 %.slot13.095.i.i, 5
  %gep119.i.i = getelementptr i8, ptr %invariant.gep118.i.i, i64 %237
  %buffer.contiguous.load68.i.i = tail call <8 x float> @llvm.masked.load.v8f32.p0(ptr %gep119.i.i, i32 1, <8 x i1> %168, <8 x float> zeroinitializer), !noalias !26
  %private.contiguous.address73.i50.i = getelementptr i8, ptr %tile_snapshot.local1.i40.i, i64 %237
  %private.contiguous.preserve74.i.i = load <8 x float>, ptr %private.contiguous.address73.i50.i, align 4, !noalias !26
  %238 = select <8 x i1> %168, <8 x float> %buffer.contiguous.load68.i.i, <8 x float> %private.contiguous.preserve74.i.i
  store <8 x float> %238, ptr %private.contiguous.address73.i50.i, align 4, !noalias !26
  %239 = add nuw nsw i64 %.slot13.095.i.i, 1
  %exitcond108.not.i.i = icmp eq i64 %239, 48
  br i1 %exitcond108.not.i.i, label %direct.schedule.12.preheader.i.i, label %direct.true60.i49.i

direct.true77.i51.i:                              ; preds = %direct.true77.i51.i, %direct.schedule.12.preheader.i.i
  %.slot15.098.i.i = phi i64 [ 0, %direct.schedule.12.preheader.i.i ], [ %242, %direct.true77.i51.i ]
  %240 = shl nuw nsw i64 %.slot15.098.i.i, 5
  %gep97.i.i = getelementptr i8, ptr %invariant.gep96.i.i, i64 %240
  %buffer.contiguous.load85.i.i = tail call <8 x float> @llvm.masked.load.v8f32.p0(ptr %gep97.i.i, i32 1, <8 x i1> %168, <8 x float> zeroinitializer), !noalias !26
  %private.contiguous.address90.i52.i = getelementptr i8, ptr %tile_snapshot.local4.i41.i, i64 %240
  %private.contiguous.preserve91.i.i = load <8 x float>, ptr %private.contiguous.address90.i52.i, align 4, !noalias !26
  %241 = select <8 x i1> %168, <8 x float> %buffer.contiguous.load85.i.i, <8 x float> %private.contiguous.preserve91.i.i
  store <8 x float> %241, ptr %private.contiguous.address90.i52.i, align 4, !noalias !26
  %242 = add nuw nsw i64 %.slot15.098.i.i, 1
  %exitcond109.not.i.i = icmp eq i64 %242, 48
  br i1 %exitcond109.not.i.i, label %direct.schedule.15.preheader.i.i, label %direct.true77.i51.i

direct.true94.i53.i:                              ; preds = %direct.true94.i53.i, %direct.schedule.15.preheader.i.i
  %.slot17.0101.i.i = phi i64 [ 0, %direct.schedule.15.preheader.i.i ], [ %245, %direct.true94.i53.i ]
  %243 = shl nuw nsw i64 %.slot17.0101.i.i, 5
  %gep100.i.i = getelementptr i8, ptr %invariant.gep99.i.i, i64 %243
  %buffer.contiguous.load102.i.i = tail call <8 x float> @llvm.masked.load.v8f32.p0(ptr %gep100.i.i, i32 1, <8 x i1> %168, <8 x float> zeroinitializer), !noalias !26
  %private.contiguous.address107.i54.i = getelementptr i8, ptr %tile_snapshot.local7.i42.i, i64 %243
  %private.contiguous.preserve108.i.i = load <8 x float>, ptr %private.contiguous.address107.i54.i, align 4, !noalias !26
  %244 = select <8 x i1> %168, <8 x float> %buffer.contiguous.load102.i.i, <8 x float> %private.contiguous.preserve108.i.i
  store <8 x float> %244, ptr %private.contiguous.address107.i54.i, align 4, !noalias !26
  %245 = add nuw nsw i64 %.slot17.0101.i.i, 1
  %exitcond110.not.i.i = icmp eq i64 %245, 48
  br i1 %exitcond110.not.i.i, label %direct.schedule.18.preheader.i.i, label %direct.true94.i53.i

direct.true111.i55.i:                             ; preds = %direct.true111.i55.i, %direct.schedule.18.preheader.i.i
  %.slot18.0104.i.i = phi i64 [ 0, %direct.schedule.18.preheader.i.i ], [ %251, %direct.true111.i55.i ]
  %246 = shl nuw nsw i64 %.slot18.0104.i.i, 5
  %private.contiguous.address122.i56.i = getelementptr i8, ptr %tile_snapshot.local.i39.i, i64 %246
  %private.contiguous.load.i57.i = load <8 x float>, ptr %private.contiguous.address122.i56.i, align 4, !noalias !26
  %private.contiguous.address127.i58.i = getelementptr i8, ptr %tile_snapshot.local4.i41.i, i64 %246
  %private.contiguous.load128.i59.i = load <8 x float>, ptr %private.contiguous.address127.i58.i, align 4, !noalias !26
  %247 = fmul <8 x float> %private.contiguous.load.i57.i, %private.contiguous.load128.i59.i
  %private.contiguous.address133.i60.i = getelementptr i8, ptr %tile_snapshot.local1.i40.i, i64 %246
  %private.contiguous.load134.i61.i = load <8 x float>, ptr %private.contiguous.address133.i60.i, align 4, !noalias !26
  %private.contiguous.address139.i62.i = getelementptr i8, ptr %tile_snapshot.local7.i42.i, i64 %246
  %private.contiguous.load140.i63.i = load <8 x float>, ptr %private.contiguous.address139.i62.i, align 4, !noalias !26
  %248 = fmul <8 x float> %private.contiguous.load134.i61.i, %private.contiguous.load140.i63.i
  %249 = fsub <8 x float> %247, %248
  %250 = select <8 x i1> %168, <8 x float> %249, <8 x float> zeroinitializer
  %gep103.i.i = getelementptr i8, ptr %invariant.gep102.i.i, i64 %246
  tail call void @llvm.masked.store.v8f32.p0(<8 x float> %250, ptr %gep103.i.i, i32 1, <8 x i1> %168), !noalias !26
  %251 = add nuw nsw i64 %.slot18.0104.i.i, 1
  %exitcond111.not.i.i = icmp eq i64 %251, 48
  br i1 %exitcond111.not.i.i, label %direct.schedule.21.preheader.i64.i, label %direct.true111.i55.i

direct.true144.i66.i:                             ; preds = %direct.true144.i66.i, %direct.schedule.21.preheader.i64.i
  %.slot19.0105.i.i = phi i64 [ 0, %direct.schedule.21.preheader.i64.i ], [ %257, %direct.true144.i66.i ]
  %252 = shl i64 %.slot19.0105.i.i, 5
  %private.contiguous.address155.i67.i = getelementptr i8, ptr %tile_snapshot.local.i39.i, i64 %252
  %private.contiguous.load156.i68.i = load <8 x float>, ptr %private.contiguous.address155.i67.i, align 4, !noalias !26
  %private.contiguous.address161.i69.i = getelementptr i8, ptr %tile_snapshot.local7.i42.i, i64 %252
  %private.contiguous.load162.i70.i = load <8 x float>, ptr %private.contiguous.address161.i69.i, align 4, !noalias !26
  %253 = fmul <8 x float> %private.contiguous.load156.i68.i, %private.contiguous.load162.i70.i
  %private.contiguous.address167.i71.i = getelementptr i8, ptr %tile_snapshot.local1.i40.i, i64 %252
  %private.contiguous.load168.i72.i = load <8 x float>, ptr %private.contiguous.address167.i71.i, align 4, !noalias !26
  %private.contiguous.address173.i73.i = getelementptr i8, ptr %tile_snapshot.local4.i41.i, i64 %252
  %private.contiguous.load174.i74.i = load <8 x float>, ptr %private.contiguous.address173.i73.i, align 4, !noalias !26
  %254 = fmul <8 x float> %private.contiguous.load168.i72.i, %private.contiguous.load174.i74.i
  %255 = fadd <8 x float> %253, %254
  %256 = select <8 x i1> %168, <8 x float> %255, <8 x float> zeroinitializer
  %gep123.i.i = getelementptr i8, ptr %invariant.gep122.i.i, i64 %252
  tail call void @llvm.masked.store.v8f32.p0(<8 x float> %256, ptr %gep123.i.i, i32 1, <8 x i1> %168), !noalias !26
  %257 = add nuw nsw i64 %.slot19.0105.i.i, 1
  %exitcond112.not.i.i = icmp eq i64 %257, 48
  br i1 %exitcond112.not.i.i, label %llm_rows.exit.i, label %direct.true144.i66.i

llm_rows.exit.i:                                  ; preds = %direct.true144.i66.i, %direct.true30.i76.i, %packet.batch.tail.call.i
  call void @llvm.lifetime.end.p0(i64 1536, ptr nonnull %tile_snapshot.local.i39.i), !noalias !16
  call void @llvm.lifetime.end.p0(i64 1536, ptr nonnull %tile_snapshot.local1.i40.i), !noalias !16
  call void @llvm.lifetime.end.p0(i64 1536, ptr nonnull %tile_snapshot.local4.i41.i), !noalias !16
  call void @llvm.lifetime.end.p0(i64 1536, ptr nonnull %tile_snapshot.local7.i42.i), !noalias !16
  br label %llm_rows.packet_batch.exit

llm_rows.packet_batch.exit:                       ; preds = %llm_rows.exit.i, %packet.batch.tail.check.i, %llm_rows.full_packet.exit.i
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add nuw i32 %block.index, 1
  %exitcond.not = icmp eq i32 %block.index.next, %block_count
  br i1 %exitcond.not, label %block.batch.exit.loopexit, label %block.batch.loop

block.batch.exit.loopexit:                        ; preds = %llm_rows.packet_batch.exit
  store i32 %block.x, ptr %launch_config, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 24, ptr %thread.index.address, align 4
  br label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.exit.loopexit, %block.batch.prologue
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #4

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr captures(none)) #5

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr captures(none)) #5

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #6

attributes #0 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #2 = { nofree norecurse nosync nounwind "target-cpu"="apple-m1" }
attributes #3 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }

!0 = !{!1}
!1 = distinct !{!1, !2, !"llm_rows.packet_batch: %launch_config"}
!2 = distinct !{!2, !"llm_rows.packet_batch"}
!3 = !{!4}
!4 = distinct !{!4, !2, !"llm_rows.packet_batch: %argument_buffer"}
!5 = !{!6, !4}
!6 = distinct !{!6, !7, !"llm_rows.full_packet: %argument_buffer"}
!7 = distinct !{!7, !"llm_rows.full_packet"}
!8 = !{!9, !1}
!9 = distinct !{!9, !7, !"llm_rows.full_packet: %launch_config"}
!10 = !{!11, !4}
!11 = distinct !{!11, !12, !"llm_rows.full_packet: %argument_buffer"}
!12 = distinct !{!12, !"llm_rows.full_packet"}
!13 = !{!14, !1}
!14 = distinct !{!14, !12, !"llm_rows.full_packet: %launch_config"}
!15 = !{!6}
!16 = !{!4, !1}
!17 = !{!6, !9, !4, !1}
!18 = !{!11}
!19 = !{!11, !14, !4, !1}
!20 = !{!21}
!21 = distinct !{!21, !22, !"llm_rows: %argument_buffer"}
!22 = distinct !{!22, !"llm_rows"}
!23 = !{!21, !4}
!24 = !{!25, !1}
!25 = distinct !{!25, !22, !"llm_rows: %launch_config"}
!26 = !{!21, !25, !4, !1}

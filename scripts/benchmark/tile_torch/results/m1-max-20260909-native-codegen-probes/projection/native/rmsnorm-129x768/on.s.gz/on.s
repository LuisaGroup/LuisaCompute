
/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/rmsnorm-129x768/on/object/tile_xir_w8_37863_1788936533445771_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d9, d8, [sp, #-0x70]!
       4:      	stp	x28, x27, [sp, #0x10]
       8:      	stp	x26, x25, [sp, #0x20]
       c:      	stp	x24, x23, [sp, #0x30]
      10:      	stp	x22, x21, [sp, #0x40]
      14:      	stp	x20, x19, [sp, #0x50]
      18:      	stp	x29, x30, [sp, #0x60]
      1c:      	sub	sp, sp, #0x1, lsl #12   ; =0x1000
      20:      	sub	sp, sp, #0xa10
      24:      	str	x0, [sp, #0x18]
      28:      	cbz	w3, 0xfb8 <ltmp0+0xfb8>
      2c:      	mov	w23, #0x0               ; =0
      30:      	add	x24, sp, #0x160
      34:      	add	x25, sp, #0xe10
      38:      	add	x8, x25, #0xe0
      3c:      	stp	x2, x8, [sp, #0x8]
      40:      	ldp	w9, w8, [x2, #0x2c]
      44:      	stp	w8, w9, [sp, #0x34]
      48:      	add	x26, sp, #0x210
      4c:      	ldp	w8, w9, [x2]
      50:      	ldp	w10, w11, [x2, #0x8]
      54:      	str	x11, [sp, #0x28]
      58:      	movi	d8, #0000000000000000
      5c:      	str	w3, [sp, #0x3c]
      60:      	b	0xa0 <ltmp0+0xa0>
      64:      	add	w8, w22, #0x1
      68:      	ldp	w11, w9, [sp, #0x34]
      6c:      	cmp	w8, w9
      70:      	cset	w9, eq
      74:      	csinc	w8, wzr, w22, eq
      78:      	cinc	w10, w19, eq
      7c:      	cmp	w10, w11
      80:      	cset	w11, eq
      84:      	ands	w11, w9, w11
      88:      	csel	w9, wzr, w10, ne
      8c:      	ldr	w12, [sp, #0x4c]
      90:      	add	w10, w12, w11
      94:      	add	w23, w23, #0x1
      98:      	cmp	w23, w21
      9c:      	b.eq	0xfa4 <ltmp0+0xfa4>
      a0:      	stp	w9, w10, [sp, #0x48]
      a4:      	mov	x13, x8
      a8:      	ubfiz	x8, x8, #5, #32
      ac:      	ldr	x12, [sp, #0x28]
      b0:      	cmp	x8, x12
      b4:      	csel	x9, x8, xzr, ls
      b8:      	subs	x10, x12, x9
      bc:      	cmp	x10, #0x20
      c0:      	mov	w11, #0x20              ; =32
      c4:      	csel	x10, x10, x11, lo
      c8:      	cmp	x12, x9
      cc:      	ccmp	x8, x12, #0x2, hi
      d0:      	csel	x27, x10, xzr, ls
      d4:      	cmp	x27, #0x20
      d8:      	b.lo	0x760 <ltmp0+0x760>
      dc:      	ldr	x8, [sp, #0x18]
      e0:      	ldr	x27, [x8]
      e4:      	ldr	x22, [x8, #0x10]
      e8:      	ldr	x20, [x8, #0x30]
      ec:      	mov	x21, x13
      f0:      	ubfiz	w28, w13, #2, #27
      f4:      	mov	w8, #0xc00              ; =3072
      f8:      	umull	x19, w28, w8
      fc:      	umaddl	x1, w28, w8, x27
     100:      	add	x0, sp, #0xe10
     104:      	mov	w2, #0xc00              ; =3072
     108:      	bl	0x108 <ltmp0+0x108>
     10c:      	mov	x8, #0x0                ; =0
     110:      	ldr	q0, [x24, #0xcb0]
     114:      	ldr	q1, [x24, #0xcc0]
     118:      	fmul.4s	v2, v1, v1
     11c:      	fmul.4s	v3, v0, v0
     120:      	ldr	q0, [x24, #0xcd0]
     124:      	ldr	q1, [x24, #0xce0]
     128:      	fmul.4s	v4, v1, v1
     12c:      	fmul.4s	v5, v0, v0
     130:      	ldr	q0, [x24, #0xcf0]
     134:      	ldr	q1, [x24, #0xd00]
     138:      	fmul.4s	v7, v1, v1
     13c:      	fmul.4s	v6, v0, v0
     140:      	ldr	q0, [x24, #0xd10]
     144:      	ldr	q1, [x24, #0xd20]
     148:      	fmul.4s	v16, v1, v1
     14c:      	fmul.4s	v17, v0, v0
     150:      	add	x9, x25, x8, lsl #5
     154:      	ldp	q1, q0, [x9, #0x80]
     158:      	fmul.4s	v1, v1, v1
     15c:      	fmul.4s	v0, v0, v0
     160:      	fadd.4s	v2, v2, v0
     164:      	fadd.4s	v3, v3, v1
     168:      	ldp	q1, q0, [x9, #0xa0]
     16c:      	fmul.4s	v1, v1, v1
     170:      	fmul.4s	v0, v0, v0
     174:      	fadd.4s	v4, v4, v0
     178:      	fadd.4s	v5, v5, v1
     17c:      	ldp	q1, q0, [x9, #0xc0]
     180:      	fmul.4s	v1, v1, v1
     184:      	fmul.4s	v0, v0, v0
     188:      	fadd.4s	v7, v7, v0
     18c:      	fadd.4s	v6, v6, v1
     190:      	ldp	q1, q0, [x9, #0xe0]
     194:      	fmul.4s	v1, v1, v1
     198:      	fmul.4s	v0, v0, v0
     19c:      	fadd.4s	v16, v16, v0
     1a0:      	fadd.4s	v17, v17, v1
     1a4:      	add	x8, x8, #0x4
     1a8:      	cmp	x8, #0x5c
     1ac:      	b.lo	0x150 <ltmp0+0x150>
     1b0:      	add	x0, sp, #0x210
     1b4:      	mov	x1, x22
     1b8:      	mov	w2, #0xc00              ; =3072
     1bc:      	stp	q4, q2, [sp, #0x80]
     1c0:      	stp	q5, q3, [sp, #0x50]
     1c4:      	stp	q6, q16, [sp, #0xb0]
     1c8:      	str	q7, [sp, #0x70]
     1cc:      	str	q17, [sp, #0xa0]
     1d0:      	bl	0x1d0 <ltmp0+0x1d0>
     1d4:      	mov	x8, #0x0                ; =0
     1d8:      	ldp	q1, q0, [sp, #0x50]
     1dc:      	fadd.4s	v0, v0, v1
     1e0:      	ldp	q2, q1, [sp, #0x80]
     1e4:      	fadd.4s	v1, v1, v2
     1e8:      	ldr	q2, [sp, #0x70]
     1ec:      	fadd.4s	v1, v1, v2
     1f0:      	ldp	q2, q3, [sp, #0xa0]
     1f4:      	fadd.4s	v0, v0, v3
     1f8:      	fadd.4s	v0, v0, v2
     1fc:      	ldr	q2, [sp, #0xc0]
     200:      	fadd.4s	v1, v1, v2
     204:      	rev64.4s	v2, v1
     208:      	rev64.4s	v3, v0
     20c:      	fadd.4s	v0, v0, v3
     210:      	fadd.4s	v1, v1, v2
     214:      	dup.4s	v2, v1[2]
     218:      	dup.4s	v3, v0[2]
     21c:      	fadd.4s	v0, v0, v3
     220:      	fadd.4s	v1, v1, v2
     224:      	fadd.4s	v0, v0, v1
     228:      	fadd	s0, s0, s8
     22c:      	mov	w9, #0x44400000         ; =1145044992
     230:      	fmov	s1, w9
     234:      	fdiv	s0, s0, s1
     238:      	mov	w9, #0xc5ac             ; =50604
     23c:      	movk	w9, #0x3727, lsl #16
     240:      	fmov	s1, w9
     244:      	fadd	s0, s0, s1
     248:      	fsqrt	s0, s0
     24c:      	dup.4s	v0, v0[0]
     250:      	add	x9, x20, x19
     254:      	add	x10, x25, x8
     258:      	ldp	q1, q2, [x10]
     25c:      	fdiv.4s	v2, v2, v0
     260:      	fdiv.4s	v1, v1, v0
     264:      	add	x10, x26, x8
     268:      	ldp	q4, q3, [x10]
     26c:      	fmul.4s	v1, v1, v4
     270:      	fmul.4s	v2, v2, v3
     274:      	add	x10, x9, x8
     278:      	stp	q1, q2, [x10]
     27c:      	add	x8, x8, #0x20
     280:      	cmp	x8, #0xc00
     284:      	b.ne	0x254 <ltmp0+0x254>
     288:      	orr	w8, w28, #0x1
     28c:      	mov	w9, #0xc00              ; =3072
     290:      	umull	x19, w8, w9
     294:      	umaddl	x1, w8, w9, x27
     298:      	add	x0, sp, #0xe10
     29c:      	mov	w2, #0xc00              ; =3072
     2a0:      	bl	0x2a0 <ltmp0+0x2a0>
     2a4:      	mov	x8, #0x0                ; =0
     2a8:      	ldr	q0, [x24, #0xcb0]
     2ac:      	ldr	q1, [x24, #0xcc0]
     2b0:      	fmul.4s	v2, v1, v1
     2b4:      	fmul.4s	v3, v0, v0
     2b8:      	ldr	q0, [x24, #0xcd0]
     2bc:      	ldr	q1, [x24, #0xce0]
     2c0:      	fmul.4s	v4, v1, v1
     2c4:      	fmul.4s	v5, v0, v0
     2c8:      	ldr	q0, [x24, #0xcf0]
     2cc:      	ldr	q1, [x24, #0xd00]
     2d0:      	fmul.4s	v7, v1, v1
     2d4:      	fmul.4s	v6, v0, v0
     2d8:      	ldr	q0, [x24, #0xd10]
     2dc:      	ldr	q1, [x24, #0xd20]
     2e0:      	fmul.4s	v16, v1, v1
     2e4:      	fmul.4s	v17, v0, v0
     2e8:      	add	x9, x25, x8, lsl #5
     2ec:      	ldp	q1, q0, [x9, #0x80]
     2f0:      	fmul.4s	v1, v1, v1
     2f4:      	fmul.4s	v0, v0, v0
     2f8:      	fadd.4s	v2, v2, v0
     2fc:      	fadd.4s	v3, v3, v1
     300:      	ldp	q1, q0, [x9, #0xa0]
     304:      	fmul.4s	v1, v1, v1
     308:      	fmul.4s	v0, v0, v0
     30c:      	fadd.4s	v4, v4, v0
     310:      	fadd.4s	v5, v5, v1
     314:      	ldp	q1, q0, [x9, #0xc0]
     318:      	fmul.4s	v1, v1, v1
     31c:      	fmul.4s	v0, v0, v0
     320:      	fadd.4s	v7, v7, v0
     324:      	fadd.4s	v6, v6, v1
     328:      	ldp	q1, q0, [x9, #0xe0]
     32c:      	fmul.4s	v1, v1, v1
     330:      	fmul.4s	v0, v0, v0
     334:      	fadd.4s	v16, v16, v0
     338:      	fadd.4s	v17, v17, v1
     33c:      	add	x8, x8, #0x4
     340:      	cmp	x8, #0x5c
     344:      	b.lo	0x2e8 <ltmp0+0x2e8>
     348:      	add	x0, sp, #0x210
     34c:      	mov	x1, x22
     350:      	mov	w2, #0xc00              ; =3072
     354:      	stp	q4, q2, [sp, #0x80]
     358:      	stp	q5, q3, [sp, #0x50]
     35c:      	stp	q6, q16, [sp, #0xb0]
     360:      	str	q7, [sp, #0x70]
     364:      	str	q17, [sp, #0xa0]
     368:      	bl	0x368 <ltmp0+0x368>
     36c:      	mov	x8, #0x0                ; =0
     370:      	ldp	q1, q0, [sp, #0x50]
     374:      	fadd.4s	v0, v0, v1
     378:      	ldp	q2, q1, [sp, #0x80]
     37c:      	fadd.4s	v1, v1, v2
     380:      	ldr	q2, [sp, #0x70]
     384:      	fadd.4s	v1, v1, v2
     388:      	ldp	q2, q3, [sp, #0xa0]
     38c:      	fadd.4s	v0, v0, v3
     390:      	fadd.4s	v0, v0, v2
     394:      	ldr	q2, [sp, #0xc0]
     398:      	fadd.4s	v1, v1, v2
     39c:      	rev64.4s	v2, v1
     3a0:      	rev64.4s	v3, v0
     3a4:      	fadd.4s	v0, v0, v3
     3a8:      	fadd.4s	v1, v1, v2
     3ac:      	dup.4s	v2, v1[2]
     3b0:      	dup.4s	v3, v0[2]
     3b4:      	fadd.4s	v0, v0, v3
     3b8:      	fadd.4s	v1, v1, v2
     3bc:      	fadd.4s	v0, v0, v1
     3c0:      	fadd	s0, s0, s8
     3c4:      	mov	w9, #0x44400000         ; =1145044992
     3c8:      	fmov	s1, w9
     3cc:      	fdiv	s0, s0, s1
     3d0:      	mov	w9, #0xc5ac             ; =50604
     3d4:      	movk	w9, #0x3727, lsl #16
     3d8:      	fmov	s1, w9
     3dc:      	fadd	s0, s0, s1
     3e0:      	fsqrt	s0, s0
     3e4:      	dup.4s	v0, v0[0]
     3e8:      	add	x9, x20, x19
     3ec:      	add	x10, x25, x8
     3f0:      	ldp	q1, q2, [x10]
     3f4:      	fdiv.4s	v2, v2, v0
     3f8:      	fdiv.4s	v1, v1, v0
     3fc:      	add	x10, x26, x8
     400:      	ldp	q4, q3, [x10]
     404:      	fmul.4s	v1, v1, v4
     408:      	fmul.4s	v2, v2, v3
     40c:      	add	x10, x9, x8
     410:      	stp	q1, q2, [x10]
     414:      	add	x8, x8, #0x20
     418:      	cmp	x8, #0xc00
     41c:      	b.ne	0x3ec <ltmp0+0x3ec>
     420:      	orr	w8, w28, #0x2
     424:      	mov	w9, #0xc00              ; =3072
     428:      	umull	x19, w8, w9
     42c:      	umaddl	x1, w8, w9, x27
     430:      	add	x0, sp, #0xe10
     434:      	mov	w2, #0xc00              ; =3072
     438:      	bl	0x438 <ltmp0+0x438>
     43c:      	mov	x8, #0x0                ; =0
     440:      	ldr	q0, [x24, #0xcb0]
     444:      	ldr	q1, [x24, #0xcc0]
     448:      	fmul.4s	v2, v1, v1
     44c:      	fmul.4s	v3, v0, v0
     450:      	ldr	q0, [x24, #0xcd0]
     454:      	ldr	q1, [x24, #0xce0]
     458:      	fmul.4s	v4, v1, v1
     45c:      	fmul.4s	v5, v0, v0
     460:      	ldr	q0, [x24, #0xcf0]
     464:      	ldr	q1, [x24, #0xd00]
     468:      	fmul.4s	v7, v1, v1
     46c:      	fmul.4s	v6, v0, v0
     470:      	ldr	q0, [x24, #0xd10]
     474:      	ldr	q1, [x24, #0xd20]
     478:      	fmul.4s	v16, v1, v1
     47c:      	fmul.4s	v17, v0, v0
     480:      	add	x9, x25, x8, lsl #5
     484:      	ldp	q1, q0, [x9, #0x80]
     488:      	fmul.4s	v1, v1, v1
     48c:      	fmul.4s	v0, v0, v0
     490:      	fadd.4s	v2, v2, v0
     494:      	fadd.4s	v3, v3, v1
     498:      	ldp	q1, q0, [x9, #0xa0]
     49c:      	fmul.4s	v1, v1, v1
     4a0:      	fmul.4s	v0, v0, v0
     4a4:      	fadd.4s	v4, v4, v0
     4a8:      	fadd.4s	v5, v5, v1
     4ac:      	ldp	q1, q0, [x9, #0xc0]
     4b0:      	fmul.4s	v1, v1, v1
     4b4:      	fmul.4s	v0, v0, v0
     4b8:      	fadd.4s	v7, v7, v0
     4bc:      	fadd.4s	v6, v6, v1
     4c0:      	ldp	q1, q0, [x9, #0xe0]
     4c4:      	fmul.4s	v1, v1, v1
     4c8:      	fmul.4s	v0, v0, v0
     4cc:      	fadd.4s	v16, v16, v0
     4d0:      	fadd.4s	v17, v17, v1
     4d4:      	add	x8, x8, #0x4
     4d8:      	cmp	x8, #0x5c
     4dc:      	b.lo	0x480 <ltmp0+0x480>
     4e0:      	add	x0, sp, #0x210
     4e4:      	mov	x1, x22
     4e8:      	mov	w2, #0xc00              ; =3072
     4ec:      	stp	q4, q2, [sp, #0x80]
     4f0:      	stp	q5, q3, [sp, #0x50]
     4f4:      	stp	q6, q16, [sp, #0xb0]
     4f8:      	str	q7, [sp, #0x70]
     4fc:      	str	q17, [sp, #0xa0]
     500:      	bl	0x500 <ltmp0+0x500>
     504:      	mov	x8, #0x0                ; =0
     508:      	ldp	q1, q0, [sp, #0x50]
     50c:      	fadd.4s	v0, v0, v1
     510:      	ldp	q2, q1, [sp, #0x80]
     514:      	fadd.4s	v1, v1, v2
     518:      	ldr	q2, [sp, #0x70]
     51c:      	fadd.4s	v1, v1, v2
     520:      	ldp	q2, q3, [sp, #0xa0]
     524:      	fadd.4s	v0, v0, v3
     528:      	fadd.4s	v0, v0, v2
     52c:      	ldr	q2, [sp, #0xc0]
     530:      	fadd.4s	v1, v1, v2
     534:      	rev64.4s	v2, v1
     538:      	rev64.4s	v3, v0
     53c:      	fadd.4s	v0, v0, v3
     540:      	fadd.4s	v1, v1, v2
     544:      	dup.4s	v2, v1[2]
     548:      	dup.4s	v3, v0[2]
     54c:      	fadd.4s	v0, v0, v3
     550:      	fadd.4s	v1, v1, v2
     554:      	fadd.4s	v0, v0, v1
     558:      	fadd	s0, s0, s8
     55c:      	mov	w9, #0x44400000         ; =1145044992
     560:      	fmov	s1, w9
     564:      	fdiv	s0, s0, s1
     568:      	mov	w9, #0xc5ac             ; =50604
     56c:      	movk	w9, #0x3727, lsl #16
     570:      	fmov	s1, w9
     574:      	fadd	s0, s0, s1
     578:      	fsqrt	s0, s0
     57c:      	dup.4s	v0, v0[0]
     580:      	add	x9, x20, x19
     584:      	add	x10, x25, x8
     588:      	ldp	q1, q2, [x10]
     58c:      	fdiv.4s	v2, v2, v0
     590:      	fdiv.4s	v1, v1, v0
     594:      	add	x10, x26, x8
     598:      	ldp	q4, q3, [x10]
     59c:      	fmul.4s	v1, v1, v4
     5a0:      	fmul.4s	v2, v2, v3
     5a4:      	add	x10, x9, x8
     5a8:      	stp	q1, q2, [x10]
     5ac:      	add	x8, x8, #0x20
     5b0:      	cmp	x8, #0xc00
     5b4:      	b.ne	0x584 <ltmp0+0x584>
     5b8:      	orr	w8, w28, #0x3
     5bc:      	mov	w9, #0xc00              ; =3072
     5c0:      	umull	x19, w8, w9
     5c4:      	umaddl	x1, w8, w9, x27
     5c8:      	add	x0, sp, #0xe10
     5cc:      	mov	w2, #0xc00              ; =3072
     5d0:      	bl	0x5d0 <ltmp0+0x5d0>
     5d4:      	mov	x8, #0x0                ; =0
     5d8:      	ldr	q0, [x24, #0xcb0]
     5dc:      	ldr	q1, [x24, #0xcc0]
     5e0:      	fmul.4s	v2, v1, v1
     5e4:      	fmul.4s	v3, v0, v0
     5e8:      	ldr	q0, [x24, #0xcd0]
     5ec:      	ldr	q1, [x24, #0xce0]
     5f0:      	fmul.4s	v4, v1, v1
     5f4:      	fmul.4s	v5, v0, v0
     5f8:      	ldr	q0, [x24, #0xcf0]
     5fc:      	ldr	q1, [x24, #0xd00]
     600:      	fmul.4s	v7, v1, v1
     604:      	fmul.4s	v6, v0, v0
     608:      	ldr	q0, [x24, #0xd10]
     60c:      	ldr	q1, [x24, #0xd20]
     610:      	fmul.4s	v16, v1, v1
     614:      	fmul.4s	v17, v0, v0
     618:      	add	x9, x25, x8, lsl #5
     61c:      	ldp	q1, q0, [x9, #0x80]
     620:      	fmul.4s	v1, v1, v1
     624:      	fmul.4s	v0, v0, v0
     628:      	fadd.4s	v2, v2, v0
     62c:      	fadd.4s	v3, v3, v1
     630:      	ldp	q1, q0, [x9, #0xa0]
     634:      	fmul.4s	v1, v1, v1
     638:      	fmul.4s	v0, v0, v0
     63c:      	fadd.4s	v4, v4, v0
     640:      	fadd.4s	v5, v5, v1
     644:      	ldp	q1, q0, [x9, #0xc0]
     648:      	fmul.4s	v1, v1, v1
     64c:      	fmul.4s	v0, v0, v0
     650:      	fadd.4s	v7, v7, v0
     654:      	fadd.4s	v6, v6, v1
     658:      	ldp	q1, q0, [x9, #0xe0]
     65c:      	fmul.4s	v1, v1, v1
     660:      	fmul.4s	v0, v0, v0
     664:      	fadd.4s	v16, v16, v0
     668:      	fadd.4s	v17, v17, v1
     66c:      	add	x8, x8, #0x4
     670:      	cmp	x8, #0x5c
     674:      	b.lo	0x618 <ltmp0+0x618>
     678:      	add	x0, sp, #0x210
     67c:      	mov	x1, x22
     680:      	mov	w2, #0xc00              ; =3072
     684:      	stp	q4, q2, [sp, #0x80]
     688:      	stp	q5, q3, [sp, #0x50]
     68c:      	stp	q6, q16, [sp, #0xb0]
     690:      	str	q7, [sp, #0x70]
     694:      	str	q17, [sp, #0xa0]
     698:      	bl	0x698 <ltmp0+0x698>
     69c:      	mov	x8, #0x0                ; =0
     6a0:      	ldp	q1, q0, [sp, #0x50]
     6a4:      	fadd.4s	v0, v0, v1
     6a8:      	ldp	q2, q1, [sp, #0x80]
     6ac:      	fadd.4s	v1, v1, v2
     6b0:      	ldr	q2, [sp, #0x70]
     6b4:      	fadd.4s	v1, v1, v2
     6b8:      	ldp	q2, q3, [sp, #0xa0]
     6bc:      	fadd.4s	v0, v0, v3
     6c0:      	fadd.4s	v0, v0, v2
     6c4:      	ldr	q2, [sp, #0xc0]
     6c8:      	fadd.4s	v1, v1, v2
     6cc:      	rev64.4s	v2, v1
     6d0:      	rev64.4s	v3, v0
     6d4:      	fadd.4s	v0, v0, v3
     6d8:      	fadd.4s	v1, v1, v2
     6dc:      	dup.4s	v2, v1[2]
     6e0:      	dup.4s	v3, v0[2]
     6e4:      	add	x9, x20, x19
     6e8:      	fadd.4s	v0, v0, v3
     6ec:      	fadd.4s	v1, v1, v2
     6f0:      	fadd.4s	v0, v0, v1
     6f4:      	fadd	s0, s0, s8
     6f8:      	mov	w10, #0x44400000        ; =1145044992
     6fc:      	fmov	s1, w10
     700:      	fdiv	s0, s0, s1
     704:      	mov	w10, #0xc5ac            ; =50604
     708:      	movk	w10, #0x3727, lsl #16
     70c:      	fmov	s1, w10
     710:      	fadd	s0, s0, s1
     714:      	fsqrt	s0, s0
     718:      	dup.4s	v0, v0[0]
     71c:      	mov	x22, x21
     720:      	add	x10, x25, x8
     724:      	ldp	q1, q2, [x10]
     728:      	fdiv.4s	v2, v2, v0
     72c:      	fdiv.4s	v1, v1, v0
     730:      	add	x10, x26, x8
     734:      	ldp	q4, q3, [x10]
     738:      	fmul.4s	v1, v1, v4
     73c:      	fmul.4s	v2, v2, v3
     740:      	add	x10, x9, x8
     744:      	stp	q1, q2, [x10]
     748:      	add	x8, x8, #0x20
     74c:      	cmp	x8, #0xc00
     750:      	b.ne	0x720 <ltmp0+0x720>
     754:      	ldr	w19, [sp, #0x48]
     758:      	ldr	w21, [sp, #0x3c]
     75c:      	b	0x64 <ltmp0+0x64>
     760:      	str	x13, [sp, #0x40]
     764:      	str	w23, [sp, #0x24]
     768:      	lsr	x20, x27, #3
     76c:      	cmp	x27, #0x8
     770:      	b.lo	0x940 <ltmp0+0x940>
     774:      	mov	x28, #0x0               ; =0
     778:      	ldr	x8, [sp, #0x18]
     77c:      	ldr	x21, [x8]
     780:      	ldr	x22, [x8, #0x10]
     784:      	ldr	x8, [x8, #0x30]
     788:      	ldr	x9, [sp, #0x40]
     78c:      	lsl	w19, w9, #2
     790:      	and	x9, x9, #0x7ffffff
     794:      	mov	w10, #0x3000            ; =12288
     798:      	umaddl	x23, w9, w10, x8
     79c:      	add	w8, w28, w19
     7a0:      	and	x8, x8, #0x1fffffff
     7a4:      	mov	w9, #0xc00              ; =3072
     7a8:      	umaddl	x1, w8, w9, x21
     7ac:      	add	x0, sp, #0xe10
     7b0:      	mov	w2, #0xc00              ; =3072
     7b4:      	bl	0x7b4 <ltmp0+0x7b4>
     7b8:      	mov	x8, #0x0                ; =0
     7bc:      	ldr	q0, [x24, #0xcb0]
     7c0:      	ldr	q1, [x24, #0xcc0]
     7c4:      	fmul.4s	v2, v1, v1
     7c8:      	fmul.4s	v3, v0, v0
     7cc:      	ldr	q0, [x24, #0xcd0]
     7d0:      	ldr	q1, [x24, #0xce0]
     7d4:      	fmul.4s	v4, v1, v1
     7d8:      	fmul.4s	v5, v0, v0
     7dc:      	ldr	q0, [x24, #0xcf0]
     7e0:      	ldr	q1, [x24, #0xd00]
     7e4:      	fmul.4s	v7, v1, v1
     7e8:      	fmul.4s	v6, v0, v0
     7ec:      	ldr	q0, [x24, #0xd10]
     7f0:      	ldr	q1, [x24, #0xd20]
     7f4:      	fmul.4s	v16, v1, v1
     7f8:      	fmul.4s	v17, v0, v0
     7fc:      	add	x9, x25, x8, lsl #5
     800:      	ldp	q1, q0, [x9, #0x80]
     804:      	fmul.4s	v1, v1, v1
     808:      	fmul.4s	v0, v0, v0
     80c:      	fadd.4s	v2, v2, v0
     810:      	fadd.4s	v3, v3, v1
     814:      	ldp	q1, q0, [x9, #0xa0]
     818:      	fmul.4s	v1, v1, v1
     81c:      	fmul.4s	v0, v0, v0
     820:      	fadd.4s	v4, v4, v0
     824:      	fadd.4s	v5, v5, v1
     828:      	ldp	q1, q0, [x9, #0xc0]
     82c:      	fmul.4s	v1, v1, v1
     830:      	fmul.4s	v0, v0, v0
     834:      	fadd.4s	v7, v7, v0
     838:      	fadd.4s	v6, v6, v1
     83c:      	ldp	q1, q0, [x9, #0xe0]
     840:      	fmul.4s	v1, v1, v1
     844:      	fmul.4s	v0, v0, v0
     848:      	fadd.4s	v16, v16, v0
     84c:      	fadd.4s	v17, v17, v1
     850:      	add	x8, x8, #0x4
     854:      	cmp	x8, #0x5c
     858:      	b.lo	0x7fc <ltmp0+0x7fc>
     85c:      	add	x0, sp, #0x210
     860:      	mov	x1, x22
     864:      	mov	w2, #0xc00              ; =3072
     868:      	stp	q4, q2, [sp, #0x80]
     86c:      	stp	q5, q3, [sp, #0x50]
     870:      	stp	q6, q16, [sp, #0xb0]
     874:      	str	q7, [sp, #0x70]
     878:      	str	q17, [sp, #0xa0]
     87c:      	bl	0x87c <ltmp0+0x87c>
     880:      	mov	x8, #0x0                ; =0
     884:      	ldp	q1, q0, [sp, #0x50]
     888:      	fadd.4s	v0, v0, v1
     88c:      	ldp	q2, q1, [sp, #0x80]
     890:      	fadd.4s	v1, v1, v2
     894:      	ldr	q2, [sp, #0x70]
     898:      	fadd.4s	v1, v1, v2
     89c:      	ldp	q2, q3, [sp, #0xa0]
     8a0:      	fadd.4s	v0, v0, v3
     8a4:      	fadd.4s	v0, v0, v2
     8a8:      	ldr	q2, [sp, #0xc0]
     8ac:      	fadd.4s	v1, v1, v2
     8b0:      	rev64.4s	v2, v1
     8b4:      	rev64.4s	v3, v0
     8b8:      	fadd.4s	v0, v0, v3
     8bc:      	fadd.4s	v1, v1, v2
     8c0:      	dup.4s	v2, v1[2]
     8c4:      	dup.4s	v3, v0[2]
     8c8:      	fadd.4s	v0, v0, v3
     8cc:      	fadd.4s	v1, v1, v2
     8d0:      	fadd.4s	v0, v0, v1
     8d4:      	fadd	s0, s0, s8
     8d8:      	mov	w9, #0x44400000         ; =1145044992
     8dc:      	fmov	s1, w9
     8e0:      	fdiv	s0, s0, s1
     8e4:      	mov	w9, #0xc5ac             ; =50604
     8e8:      	movk	w9, #0x3727, lsl #16
     8ec:      	fmov	s1, w9
     8f0:      	fadd	s0, s0, s1
     8f4:      	fsqrt	s0, s0
     8f8:      	dup.4s	v0, v0[0]
     8fc:      	add	x9, x25, x8
     900:      	ldp	q1, q2, [x9]
     904:      	fdiv.4s	v2, v2, v0
     908:      	fdiv.4s	v1, v1, v0
     90c:      	add	x9, x26, x8
     910:      	ldp	q4, q3, [x9]
     914:      	fmul.4s	v1, v1, v4
     918:      	fmul.4s	v2, v2, v3
     91c:      	add	x9, x23, x8
     920:      	stp	q1, q2, [x9]
     924:      	add	x8, x8, #0x20
     928:      	cmp	x8, #0xc00
     92c:      	b.ne	0x8fc <ltmp0+0x8fc>
     930:      	add	x28, x28, #0x1
     934:      	add	x23, x23, #0xc00
     938:      	cmp	x28, x20
     93c:      	b.ne	0x79c <ltmp0+0x79c>
     940:      	and	w8, w27, #0x7
     944:      	ldr	w21, [sp, #0x3c]
     948:      	ldr	w23, [sp, #0x24]
     94c:      	ldr	w19, [sp, #0x48]
     950:      	ldr	x22, [sp, #0x40]
     954:      	cbz	w8, 0x64 <ltmp0+0x64>
     958:      	dup.4s	v4, w8
     95c:      	adrp	x8, 0x0 <ltmp0>
     960:      	ldr	q1, [x8]
     964:      	adrp	x8, 0x0 <ltmp0>
     968:      	ldr	q0, [x8]
     96c:      	cmhi.4s	v0, v4, v0
     970:      	cmhi.4s	v1, v4, v1
     974:      	uzp1.8h	v3, v1, v0
     978:      	umaxv.8h	h2, v3
     97c:      	fmov	w8, s2
     980:      	tbz	w8, #0x0, 0x64 <ltmp0+0x64>
     984:      	mov	x13, #0x0               ; =0
     988:      	ldr	x11, [sp, #0x18]
     98c:      	ldr	x12, [x11, #0x10]
     990:      	ldr	x8, [x11, #0x30]
     994:      	adrp	x9, 0x0 <ltmp0>
     998:      	ldr	q2, [x9]
     99c:      	and.16b	v2, v3, v2
     9a0:      	addv.8h	h2, v2
     9a4:      	fmov	w9, s2
     9a8:      	and	w10, w9, #0xff
     9ac:      	ldr	x14, [x11]
     9b0:      	ubfiz	w9, w22, #2, #27
     9b4:      	orr	w9, w9, w20
     9b8:      	fmov	w11, s4
     9bc:      	cmp	w11, #0x0
     9c0:      	cset	w11, ne
     9c4:      	mov	w15, #0xc00             ; =3072
     9c8:      	umull	x9, w9, w15
     9cc:      	csel	x9, x9, xzr, ne
     9d0:      	add	x14, x14, x9
     9d4:      	b	0x9f8 <ltmp0+0x9f8>
     9d8:      	add	x15, x25, x13
     9dc:      	ldp	q6, q7, [x15]
     9e0:      	bif.16b	v5, v7, v0
     9e4:      	bif.16b	v4, v6, v1
     9e8:      	stp	q4, q5, [x15]
     9ec:      	add	x13, x13, #0x20
     9f0:      	cmp	x13, #0xc00
     9f4:      	b.eq	0xa90 <ltmp0+0xa90>
     9f8:      	fmov	w16, s2
     9fc:      	add	x15, x14, x13
     a00:      	movi.2d	v4, #0000000000000000
     a04:      	movi.2d	v5, #0000000000000000
     a08:      	tbnz	w16, #0x0, 0xa30 <ltmp0+0xa30>
     a0c:      	and	w16, w16, #0xff
     a10:      	tbnz	w16, #0x1, 0xa3c <ltmp0+0xa3c>
     a14:      	tbnz	w16, #0x2, 0xa48 <ltmp0+0xa48>
     a18:      	tbnz	w16, #0x3, 0xa54 <ltmp0+0xa54>
     a1c:      	tbnz	w16, #0x4, 0xa60 <ltmp0+0xa60>
     a20:      	tbnz	w16, #0x5, 0xa6c <ltmp0+0xa6c>
     a24:      	tbnz	w16, #0x6, 0xa78 <ltmp0+0xa78>
     a28:      	tbz	w16, #0x7, 0x9d8 <ltmp0+0x9d8>
     a2c:      	b	0xa84 <ltmp0+0xa84>
     a30:      	ldr	s4, [x15]
     a34:      	and	w16, w16, #0xff
     a38:      	tbz	w16, #0x1, 0xa14 <ltmp0+0xa14>
     a3c:      	add	x17, x15, #0x4
     a40:      	ld1.s	{ v4 }[1], [x17]
     a44:      	tbz	w16, #0x2, 0xa18 <ltmp0+0xa18>
     a48:      	add	x17, x15, #0x8
     a4c:      	ld1.s	{ v4 }[2], [x17]
     a50:      	tbz	w16, #0x3, 0xa1c <ltmp0+0xa1c>
     a54:      	add	x17, x15, #0xc
     a58:      	ld1.s	{ v4 }[3], [x17]
     a5c:      	tbz	w16, #0x4, 0xa20 <ltmp0+0xa20>
     a60:      	add	x17, x15, #0x10
     a64:      	ld1.s	{ v5 }[0], [x17]
     a68:      	tbz	w16, #0x5, 0xa24 <ltmp0+0xa24>
     a6c:      	add	x17, x15, #0x14
     a70:      	ld1.s	{ v5 }[1], [x17]
     a74:      	tbz	w16, #0x6, 0xa28 <ltmp0+0xa28>
     a78:      	add	x17, x15, #0x18
     a7c:      	ld1.s	{ v5 }[2], [x17]
     a80:      	tbz	w16, #0x7, 0x9d8 <ltmp0+0x9d8>
     a84:      	add	x15, x15, #0x1c
     a88:      	ld1.s	{ v5 }[3], [x15]
     a8c:      	b	0x9d8 <ltmp0+0x9d8>
     a90:      	ldr	q4, [x24, #0xcc0]
     a94:      	ldr	q5, [x24, #0xcb0]
     a98:      	fmul.4s	v6, v5, v5
     a9c:      	fmul.4s	v4, v4, v4
     aa0:      	ldr	q5, [x24, #0xce0]
     aa4:      	ldr	q7, [x24, #0xcd0]
     aa8:      	fmul.4s	v7, v7, v7
     aac:      	fmul.4s	v16, v5, v5
     ab0:      	ldr	q5, [x24, #0xd00]
     ab4:      	ldr	q17, [x24, #0xcf0]
     ab8:      	fmul.4s	v19, v17, v17
     abc:      	fmul.4s	v20, v5, v5
     ac0:      	ldr	q5, [x24, #0xd20]
     ac4:      	ldr	q17, [x24, #0xd10]
     ac8:      	fmul.4s	v21, v17, v17
     acc:      	fmul.4s	v22, v5, v5
     ad0:      	and.16b	v5, v0, v4
     ad4:      	and.16b	v4, v1, v6
     ad8:      	and.16b	v18, v0, v16
     adc:      	and.16b	v17, v1, v7
     ae0:      	and.16b	v6, v0, v20
     ae4:      	and.16b	v19, v1, v19
     ae8:      	and.16b	v16, v0, v22
     aec:      	and.16b	v7, v1, v21
     af0:      	ldr	x13, [sp, #0x10]
     af4:      	mov	w14, #0x4               ; =4
     af8:      	ldp	q21, q20, [x13, #-0x60]
     afc:      	and.16b	v21, v1, v21
     b00:      	and.16b	v20, v0, v20
     b04:      	fmul.4s	v20, v20, v20
     b08:      	fmul.4s	v21, v21, v21
     b0c:      	fadd.4s	v21, v4, v21
     b10:      	fadd.4s	v20, v5, v20
     b14:      	ldp	q23, q22, [x13, #-0x40]
     b18:      	and.16b	v23, v1, v23
     b1c:      	and.16b	v22, v0, v22
     b20:      	fmul.4s	v22, v22, v22
     b24:      	fmul.4s	v23, v23, v23
     b28:      	fadd.4s	v23, v17, v23
     b2c:      	fadd.4s	v22, v18, v22
     b30:      	ldp	q25, q24, [x13, #-0x20]
     b34:      	and.16b	v25, v1, v25
     b38:      	and.16b	v24, v0, v24
     b3c:      	fmul.4s	v24, v24, v24
     b40:      	fmul.4s	v25, v25, v25
     b44:      	fadd.4s	v25, v19, v25
     b48:      	fadd.4s	v24, v6, v24
     b4c:      	ldp	q27, q26, [x13], #0x80
     b50:      	and.16b	v27, v1, v27
     b54:      	and.16b	v26, v0, v26
     b58:      	fmul.4s	v26, v26, v26
     b5c:      	fmul.4s	v27, v27, v27
     b60:      	fadd.4s	v27, v7, v27
     b64:      	fadd.4s	v26, v16, v26
     b68:      	bit.16b	v5, v20, v0
     b6c:      	bit.16b	v4, v21, v1
     b70:      	bit.16b	v18, v22, v0
     b74:      	bit.16b	v17, v23, v1
     b78:      	bit.16b	v6, v24, v0
     b7c:      	bit.16b	v19, v25, v1
     b80:      	bit.16b	v16, v26, v0
     b84:      	bit.16b	v7, v27, v1
     b88:      	cmp	x14, #0x5c
     b8c:      	add	x14, x14, #0x4
     b90:      	b.lo	0xaf8 <ltmp0+0xaf8>
     b94:      	mov	x13, #0x0               ; =0
     b98:      	b	0xbbc <ltmp0+0xbbc>
     b9c:      	add	x14, x26, x13
     ba0:      	ldp	q22, q23, [x14]
     ba4:      	bif.16b	v21, v23, v0
     ba8:      	bif.16b	v20, v22, v1
     bac:      	stp	q20, q21, [x14]
     bb0:      	add	x13, x13, #0x20
     bb4:      	cmp	x13, #0xc00
     bb8:      	b.eq	0xc54 <ltmp0+0xc54>
     bbc:      	fmov	w15, s2
     bc0:      	add	x14, x12, x13
     bc4:      	movi.2d	v20, #0000000000000000
     bc8:      	movi.2d	v21, #0000000000000000
     bcc:      	tbnz	w15, #0x0, 0xbf4 <ltmp0+0xbf4>
     bd0:      	and	w15, w15, #0xff
     bd4:      	tbnz	w15, #0x1, 0xc00 <ltmp0+0xc00>
     bd8:      	tbnz	w15, #0x2, 0xc0c <ltmp0+0xc0c>
     bdc:      	tbnz	w15, #0x3, 0xc18 <ltmp0+0xc18>
     be0:      	tbnz	w15, #0x4, 0xc24 <ltmp0+0xc24>
     be4:      	tbnz	w15, #0x5, 0xc30 <ltmp0+0xc30>
     be8:      	tbnz	w15, #0x6, 0xc3c <ltmp0+0xc3c>
     bec:      	tbz	w15, #0x7, 0xb9c <ltmp0+0xb9c>
     bf0:      	b	0xc48 <ltmp0+0xc48>
     bf4:      	ldr	s20, [x14]
     bf8:      	and	w15, w15, #0xff
     bfc:      	tbz	w15, #0x1, 0xbd8 <ltmp0+0xbd8>
     c00:      	add	x16, x14, #0x4
     c04:      	ld1.s	{ v20 }[1], [x16]
     c08:      	tbz	w15, #0x2, 0xbdc <ltmp0+0xbdc>
     c0c:      	add	x16, x14, #0x8
     c10:      	ld1.s	{ v20 }[2], [x16]
     c14:      	tbz	w15, #0x3, 0xbe0 <ltmp0+0xbe0>
     c18:      	add	x16, x14, #0xc
     c1c:      	ld1.s	{ v20 }[3], [x16]
     c20:      	tbz	w15, #0x4, 0xbe4 <ltmp0+0xbe4>
     c24:      	add	x16, x14, #0x10
     c28:      	ld1.s	{ v21 }[0], [x16]
     c2c:      	tbz	w15, #0x5, 0xbe8 <ltmp0+0xbe8>
     c30:      	add	x16, x14, #0x14
     c34:      	ld1.s	{ v21 }[1], [x16]
     c38:      	tbz	w15, #0x6, 0xbec <ltmp0+0xbec>
     c3c:      	add	x16, x14, #0x18
     c40:      	ld1.s	{ v21 }[2], [x16]
     c44:      	tbz	w15, #0x7, 0xb9c <ltmp0+0xb9c>
     c48:      	add	x14, x14, #0x1c
     c4c:      	ld1.s	{ v21 }[3], [x14]
     c50:      	b	0xb9c <ltmp0+0xb9c>
     c54:      	mov	x12, #0x0               ; =0
     c58:      	xtn.8b	v20, v3
     c5c:      	fadd.4s	v3, v5, v18
     c60:      	fadd.4s	v4, v4, v17
     c64:      	fadd.4s	v4, v4, v19
     c68:      	fadd.4s	v3, v3, v6
     c6c:      	fadd.4s	v3, v3, v16
     c70:      	fadd.4s	v4, v4, v7
     c74:      	umov.b	w13, v20[1]
     c78:      	mov	s5, v4[1]
     c7c:      	tst	w11, w13
     c80:      	fcsel	s5, s5, s8, ne
     c84:      	mvn	w14, w13
     c88:      	add	x15, sp, #0x1e0
     c8c:      	bfi	x15, x14, #2, #1
     c90:      	add	x16, sp, #0xd8
     c94:      	bfxil	x16, x14, #0, #1
     c98:      	str	d20, [sp, #0xd8]
     c9c:      	ldrb	w14, [x16]
     ca0:      	and	w14, w13, w14
     ca4:      	stp	q4, q3, [x24, #0x80]
     ca8:      	ldr	s6, [x15]
     cac:      	tst	w14, #0x1
     cb0:      	fcsel	s6, s6, s8, ne
     cb4:      	umov.b	w14, v20[2]
     cb8:      	ands	w14, w14, #0x1
     cbc:      	mov	w15, #0x3               ; =3
     cc0:      	csinc	w15, w15, wzr, ne
     cc4:      	add	x6, sp, #0xd8
     cc8:      	orr	x16, x6, x15
     ccc:      	ldrb	w16, [x16]
     cd0:      	add	x17, sp, #0x1c0
     cd4:      	orr	x15, x17, x15, lsl #2
     cd8:      	stp	q4, q3, [x24, #0x60]
     cdc:      	ldr	s7, [x15]
     ce0:      	tst	w14, w16
     ce4:      	fcsel	s7, s7, s8, ne
     ce8:      	umov.b	w15, v20[3]
     cec:      	ands	w16, w15, #0x1
     cf0:      	mov	w17, #0x1               ; =1
     cf4:      	cinc	w17, w17, ne
     cf8:      	add	x0, sp, #0xd8
     cfc:      	bfxil	x0, x17, #0, #3
     d00:      	ldrb	w0, [x0]
     d04:      	add	x1, sp, #0x1a0
     d08:      	orr	x17, x1, x17, lsl #2
     d0c:      	stp	q4, q3, [x24, #0x40]
     d10:      	ldr	s16, [x17]
     d14:      	tst	w16, w0
     d18:      	fcsel	s16, s16, s8, ne
     d1c:      	umov.b	w16, v20[4]
     d20:      	ands	w16, w16, #0x1
     d24:      	mov	w17, #0x5               ; =5
     d28:      	csinc	w17, w17, wzr, ne
     d2c:      	orr	x0, x6, x17
     d30:      	ldrb	w0, [x0]
     d34:      	stp	q4, q3, [x24, #0x20]
     d38:      	add	x1, sp, #0x180
     d3c:      	ldr	s17, [x1, w17, uxtw #2]
     d40:      	mov	w17, #0x2               ; =2
     d44:      	mov	w5, #0x6                ; =6
     d48:      	csel	w2, w5, w17, ne
     d4c:      	tst	w16, w0
     d50:      	umov.b	w17, v20[5]
     d54:      	fcsel	s17, s17, s8, ne
     d58:      	ands	w0, w17, #0x1
     d5c:      	mov	w1, #0x4                ; =4
     d60:      	csinc	w1, w1, wzr, ne
     d64:      	orr	x3, x6, x1
     d68:      	ldrb	w3, [x3]
     d6c:      	stp	q4, q3, [x24]
     d70:      	ldr	s18, [x24, w1, uxtw #2]
     d74:      	tst	w0, w3
     d78:      	umov.b	w0, v20[6]
     d7c:      	fcsel	s18, s18, s8, ne
     d80:      	ands	w1, w0, #0x1
     d84:      	mov	w3, #0x7                ; =7
     d88:      	csinc	w3, w3, wzr, ne
     d8c:      	orr	x4, x6, x3
     d90:      	ldrb	w4, [x4]
     d94:      	stp	q4, q3, [sp, #0x140]
     d98:      	add	x7, sp, #0x140
     d9c:      	ldr	s19, [x7, w3, uxtw #2]
     da0:      	tst	w1, w4
     da4:      	umov.b	w1, v20[7]
     da8:      	fcsel	s19, s19, s8, ne
     dac:      	ands	w3, w1, #0x1
     db0:      	csinc	w4, w5, wzr, ne
     db4:      	orr	x5, x6, x4
     db8:      	ldrb	w5, [x5]
     dbc:      	tst	w3, w5
     dc0:      	stp	q4, q3, [sp, #0x120]
     dc4:      	add	x3, sp, #0x120
     dc8:      	ldr	s20, [x3, w4, uxtw #2]
     dcc:      	fcsel	s20, s20, s8, ne
     dd0:      	mov.s	v5[1], v6[0]
     dd4:      	mov.s	v5[2], v7[0]
     dd8:      	mov.s	v5[3], v16[0]
     ddc:      	mov.s	v17[1], v18[0]
     de0:      	mov.s	v17[2], v19[0]
     de4:      	mov.s	v17[3], v20[0]
     de8:      	fadd.4s	v3, v3, v17
     dec:      	fadd.4s	v4, v4, v5
     df0:      	orr	x3, x6, x2
     df4:      	ldrb	w3, [x3]
     df8:      	stp	q4, q3, [sp, #0x100]
     dfc:      	add	x4, sp, #0x100
     e00:      	ldr	s5, [x4, w2, uxtw #2]
     e04:      	mov	s6, v4[2]
     e08:      	tst	w14, w11
     e0c:      	fcsel	s6, s6, s8, ne
     e10:      	tst	w16, w3
     e14:      	fcsel	s5, s5, s8, ne
     e18:      	fadd.4s	v3, v3, v5
     e1c:      	tst	w16, w11
     e20:      	fcsel	s3, s3, s8, ne
     e24:      	tst	w11, w13
     e28:      	fadd.4s	v4, v4, v6
     e2c:      	fadd	s3, s4, s3
     e30:      	fcsel	s4, s3, s8, ne
     e34:      	tst	w14, w11
     e38:      	fcsel	s5, s3, s8, ne
     e3c:      	cmp	w11, #0x0
     e40:      	fcsel	s6, s3, s8, ne
     e44:      	tst	w15, #0x1
     e48:      	fcsel	s7, s6, s8, ne
     e4c:      	tst	w16, w11
     e50:      	fcsel	s3, s3, s8, ne
     e54:      	tst	w17, #0x1
     e58:      	fcsel	s16, s6, s8, ne
     e5c:      	tst	w0, #0x1
     e60:      	fcsel	s17, s6, s8, ne
     e64:      	tst	w1, #0x1
     e68:      	fcsel	s18, s6, s8, ne
     e6c:      	mov.s	v3[1], v16[0]
     e70:      	mov.s	v3[2], v17[0]
     e74:      	mov.s	v3[3], v18[0]
     e78:      	mov.s	v6[1], v4[0]
     e7c:      	mov.s	v6[2], v5[0]
     e80:      	mov.s	v6[3], v7[0]
     e84:      	rbit	w10, w10
     e88:      	clz	w10, w10
     e8c:      	stp	q6, q3, [sp, #0xe0]
     e90:      	and	x10, x10, #0x7
     e94:      	add	x11, sp, #0xe0
     e98:      	ldr	s3, [x11, x10, lsl #2]
     e9c:      	fadd	s3, s3, s8
     ea0:      	mov	w10, #0x44400000        ; =1145044992
     ea4:      	fmov	s4, w10
     ea8:      	fdiv	s3, s3, s4
     eac:      	mov	w10, #0xc5ac            ; =50604
     eb0:      	movk	w10, #0x3727, lsl #16
     eb4:      	fmov	s4, w10
     eb8:      	fadd	s3, s3, s4
     ebc:      	fsqrt	s3, s3
     ec0:      	add	x8, x8, x9
     ec4:      	dup.4s	v3, v3[0]
     ec8:      	b	0xed8 <ltmp0+0xed8>
     ecc:      	add	x12, x12, #0x20
     ed0:      	cmp	x12, #0xc00
     ed4:      	b.eq	0x64 <ltmp0+0x64>
     ed8:      	fmov	w10, s2
     edc:      	add	x9, x25, x12
     ee0:      	ldp	q5, q4, [x9]
     ee4:      	and.16b	v5, v1, v5
     ee8:      	fdiv.4s	v6, v5, v3
     eec:      	add	x9, x26, x12
     ef0:      	ldp	q7, q5, [x9]
     ef4:      	and.16b	v7, v1, v7
     ef8:      	fmul.4s	v6, v6, v7
     efc:      	add	x9, x8, x12
     f00:      	tbnz	w10, #0x0, 0xf38 <ltmp0+0xf38>
     f04:      	and	w10, w10, #0xff
     f08:      	tbnz	w10, #0x1, 0xf44 <ltmp0+0xf44>
     f0c:      	tbnz	w10, #0x2, 0xf50 <ltmp0+0xf50>
     f10:      	tbnz	w10, #0x3, 0xf5c <ltmp0+0xf5c>
     f14:      	and.16b	v4, v0, v4
     f18:      	fdiv.4s	v4, v4, v3
     f1c:      	and.16b	v5, v0, v5
     f20:      	fmul.4s	v4, v4, v5
     f24:      	tbnz	w10, #0x4, 0xf78 <ltmp0+0xf78>
     f28:      	tbnz	w10, #0x5, 0xf80 <ltmp0+0xf80>
     f2c:      	tbnz	w10, #0x6, 0xf8c <ltmp0+0xf8c>
     f30:      	tbz	w10, #0x7, 0xecc <ltmp0+0xecc>
     f34:      	b	0xf98 <ltmp0+0xf98>
     f38:      	str	s6, [x9]
     f3c:      	and	w10, w10, #0xff
     f40:      	tbz	w10, #0x1, 0xf0c <ltmp0+0xf0c>
     f44:      	add	x11, x9, #0x4
     f48:      	st1.s	{ v6 }[1], [x11]
     f4c:      	tbz	w10, #0x2, 0xf10 <ltmp0+0xf10>
     f50:      	add	x11, x9, #0x8
     f54:      	st1.s	{ v6 }[2], [x11]
     f58:      	tbz	w10, #0x3, 0xf14 <ltmp0+0xf14>
     f5c:      	add	x11, x9, #0xc
     f60:      	st1.s	{ v6 }[3], [x11]
     f64:      	and.16b	v4, v0, v4
     f68:      	fdiv.4s	v4, v4, v3
     f6c:      	and.16b	v5, v0, v5
     f70:      	fmul.4s	v4, v4, v5
     f74:      	tbz	w10, #0x4, 0xf28 <ltmp0+0xf28>
     f78:      	str	s4, [x9, #0x10]
     f7c:      	tbz	w10, #0x5, 0xf2c <ltmp0+0xf2c>
     f80:      	add	x11, x9, #0x14
     f84:      	st1.s	{ v4 }[1], [x11]
     f88:      	tbz	w10, #0x6, 0xf30 <ltmp0+0xf30>
     f8c:      	add	x11, x9, #0x18
     f90:      	st1.s	{ v4 }[2], [x11]
     f94:      	tbz	w10, #0x7, 0xecc <ltmp0+0xecc>
     f98:      	add	x9, x9, #0x1c
     f9c:      	st1.s	{ v4 }[3], [x9]
     fa0:      	b	0xecc <ltmp0+0xecc>
     fa4:      	ldr	x9, [sp, #0x8]
     fa8:      	stp	w22, w19, [x9]
     fac:      	str	w12, [x9, #0x8]
     fb0:      	mov	w8, #0x18               ; =24
     fb4:      	str	w8, [x9, #0x24]
     fb8:      	add	sp, sp, #0x1, lsl #12   ; =0x1000
     fbc:      	add	sp, sp, #0xa10
     fc0:      	ldp	x29, x30, [sp, #0x60]
     fc4:      	ldp	x20, x19, [sp, #0x50]
     fc8:      	ldp	x22, x21, [sp, #0x40]
     fcc:      	ldp	x24, x23, [sp, #0x30]
     fd0:      	ldp	x26, x25, [sp, #0x20]
     fd4:      	ldp	x28, x27, [sp, #0x10]
     fd8:      	ldp	d9, d8, [sp], #0x70
     fdc:      	ret


/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/rmsnorm-1024x4097/on/object/tile_xir_w8_37883_1788936534684708_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
      2c:      	sub	sp, sp, #0x380
      30:      	str	x0, [sp, #0x18]
      34:      	cbz	w3, 0x1648 <ltmp0+0x1648>
      38:      	mov	w25, #0x0               ; =0
      3c:      	add	x26, sp, #0x4, lsl #12  ; =0x4000
      40:      	add	x26, x26, #0x360
      44:      	ldp	w9, w8, [x2, #0x2c]
      48:      	stp	w8, w9, [sp, #0x34]
      4c:      	add	x19, sp, #0x340
      50:      	ldp	w8, w9, [x2]
      54:      	ldp	w10, w11, [x2, #0x8]
      58:      	str	x2, [sp, #0x10]
      5c:      	str	x11, [sp, #0x28]
      60:      	movi	d8, #0000000000000000
      64:      	str	w3, [sp, #0x3c]
      68:      	b	0xac <ltmp0+0xac>
      6c:      	ldr	w25, [sp, #0x54]
      70:      	add	w8, w27, #0x1
      74:      	ldp	w11, w9, [sp, #0x34]
      78:      	cmp	w8, w9
      7c:      	cset	w9, eq
      80:      	csinc	w8, wzr, w27, eq
      84:      	ldp	w13, w12, [sp, #0x4c]
      88:      	cinc	w10, w13, eq
      8c:      	cmp	w10, w11
      90:      	cset	w11, eq
      94:      	ands	w11, w9, w11
      98:      	csel	w9, wzr, w10, ne
      9c:      	add	w10, w12, w11
      a0:      	add	w25, w25, #0x1
      a4:      	cmp	w25, w28
      a8:      	b.eq	0x1634 <ltmp0+0x1634>
      ac:      	stp	w9, w10, [sp, #0x4c]
      b0:      	mov	x13, x8
      b4:      	ubfiz	x8, x8, #5, #32
      b8:      	ldr	x12, [sp, #0x28]
      bc:      	cmp	x8, x12
      c0:      	csel	x9, x8, xzr, ls
      c4:      	subs	x10, x12, x9
      c8:      	cmp	x10, #0x20
      cc:      	mov	w11, #0x20              ; =32
      d0:      	csel	x10, x10, x11, lo
      d4:      	cmp	x12, x9
      d8:      	ccmp	x8, x12, #0x2, hi
      dc:      	csel	x9, x10, xzr, ls
      e0:      	cmp	x9, #0x20
      e4:      	str	w25, [sp, #0x54]
      e8:      	b.lo	0x854 <ltmp0+0x854>
      ec:      	ldr	x8, [sp, #0x18]
      f0:      	ldr	x28, [x8]
      f4:      	ldr	x22, [x8, #0x10]
      f8:      	ldr	x20, [x8, #0x30]
      fc:      	mov	x25, x13
     100:      	ubfiz	w27, w13, #2, #27
     104:      	mov	w8, #0x4004             ; =16388
     108:      	umull	x23, w27, w8
     10c:      	umaddl	x1, w27, w8, x28
     110:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
     114:      	add	x0, x0, #0x360
     118:      	mov	w2, #0x4000             ; =16384
     11c:      	bl	0x11c <ltmp0+0x11c>
     120:      	mov	x8, #0x0                ; =0
     124:      	add	x21, x23, #0x4, lsl #12 ; =0x4000
     128:      	ldr	s0, [x28, x21]
     12c:      	str	q0, [sp, #0xe0]
     130:      	str	q0, [sp, #0x8360]
     134:      	ldr	q0, [sp, #0x4360]
     138:      	ldr	q1, [sp, #0x4370]
     13c:      	fmul.4s	v3, v1, v1
     140:      	fmul.4s	v2, v0, v0
     144:      	ldr	q0, [sp, #0x4380]
     148:      	ldr	q1, [sp, #0x4390]
     14c:      	fmul.4s	v5, v1, v1
     150:      	fmul.4s	v4, v0, v0
     154:      	ldr	q0, [sp, #0x43a0]
     158:      	ldr	q1, [sp, #0x43b0]
     15c:      	fmul.4s	v6, v1, v1
     160:      	fmul.4s	v7, v0, v0
     164:      	ldr	q0, [sp, #0x43c0]
     168:      	ldr	q1, [sp, #0x43d0]
     16c:      	fmul.4s	v17, v1, v1
     170:      	fmul.4s	v16, v0, v0
     174:      	add	x9, x26, x8, lsl #5
     178:      	ldp	q1, q0, [x9, #0x80]
     17c:      	fmul.4s	v1, v1, v1
     180:      	fmul.4s	v0, v0, v0
     184:      	fadd.4s	v3, v3, v0
     188:      	fadd.4s	v2, v2, v1
     18c:      	ldp	q1, q0, [x9, #0xa0]
     190:      	fmul.4s	v1, v1, v1
     194:      	fmul.4s	v0, v0, v0
     198:      	fadd.4s	v5, v5, v0
     19c:      	fadd.4s	v4, v4, v1
     1a0:      	ldp	q1, q0, [x9, #0xc0]
     1a4:      	fmul.4s	v1, v1, v1
     1a8:      	fmul.4s	v0, v0, v0
     1ac:      	fadd.4s	v6, v6, v0
     1b0:      	fadd.4s	v7, v7, v1
     1b4:      	ldp	q1, q0, [x9, #0xe0]
     1b8:      	fmul.4s	v1, v1, v1
     1bc:      	fmul.4s	v0, v0, v0
     1c0:      	fadd.4s	v17, v17, v0
     1c4:      	fadd.4s	v16, v16, v1
     1c8:      	add	x8, x8, #0x4
     1cc:      	cmp	x8, #0x1fc
     1d0:      	b.lo	0x174 <ltmp0+0x174>
     1d4:      	add	x0, sp, #0x340
     1d8:      	mov	x1, x22
     1dc:      	mov	w2, #0x4000             ; =16384
     1e0:      	stp	q2, q5, [sp, #0x60]
     1e4:      	stp	q3, q7, [sp, #0x80]
     1e8:      	stp	q4, q17, [sp, #0xa0]
     1ec:      	stp	q6, q16, [sp, #0xc0]
     1f0:      	bl	0x1f0 <ltmp0+0x1f0>
     1f4:      	mov	x8, #0x0                ; =0
     1f8:      	ldr	q7, [sp, #0xe0]
     1fc:      	fmul.4s	v0, v7, v7
     200:      	ldp	q1, q2, [sp, #0x60]
     204:      	fadd.4s	v0, v0, v1
     208:      	mov.s	v1[0], v0[0]
     20c:      	ldr	q0, [sp, #0x80]
     210:      	fadd.4s	v0, v2, v0
     214:      	ldp	q2, q3, [sp, #0x90]
     218:      	fadd.4s	v1, v3, v1
     21c:      	fadd.4s	v1, v2, v1
     220:      	ldp	q2, q3, [sp, #0xb0]
     224:      	fadd.4s	v0, v3, v0
     228:      	fadd.4s	v0, v2, v0
     22c:      	ldr	q2, [sp, #0xd0]
     230:      	fadd.4s	v1, v2, v1
     234:      	rev64.4s	v2, v1
     238:      	rev64.4s	v3, v0
     23c:      	fadd.4s	v1, v1, v2
     240:      	dup.4s	v2, v1[2]
     244:      	fadd.4s	v0, v0, v3
     248:      	dup.4s	v3, v0[2]
     24c:      	fadd.4s	v0, v0, v3
     250:      	fadd.4s	v1, v1, v2
     254:      	fadd.4s	v0, v1, v0
     258:      	fadd	s0, s0, s8
     25c:      	mov	w9, #0x800              ; =2048
     260:      	movk	w9, #0x4580, lsl #16
     264:      	fmov	s1, w9
     268:      	fdiv	s1, s0, s1
     26c:      	add	x24, x22, #0x4, lsl #12 ; =0x4000
     270:      	ldr	s0, [x24]
     274:      	str	q0, [sp, #0x4340]
     278:      	mov	w9, #0xc5ac             ; =50604
     27c:      	movk	w9, #0x3727, lsl #16
     280:      	fmov	s2, w9
     284:      	fadd	s1, s1, s2
     288:      	fsqrt	s1, s1
     28c:      	dup.4s	v2, v1[0]
     290:      	add	x9, x20, x23
     294:      	add	x10, x26, x8
     298:      	ldp	q3, q4, [x10]
     29c:      	fdiv.4s	v4, v4, v2
     2a0:      	fdiv.4s	v3, v3, v2
     2a4:      	add	x10, x19, x8
     2a8:      	ldp	q6, q5, [x10]
     2ac:      	fmul.4s	v3, v3, v6
     2b0:      	fmul.4s	v4, v4, v5
     2b4:      	add	x10, x9, x8
     2b8:      	stp	q3, q4, [x10]
     2bc:      	add	x8, x8, #0x20
     2c0:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     2c4:      	b.ne	0x294 <ltmp0+0x294>
     2c8:      	fdiv.4s	v1, v7, v1
     2cc:      	fmul.4s	v0, v1, v0
     2d0:      	str	s0, [x20, x21]
     2d4:      	orr	w8, w27, #0x1
     2d8:      	mov	w9, #0x4004             ; =16388
     2dc:      	umull	x23, w8, w9
     2e0:      	umaddl	x1, w8, w9, x28
     2e4:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
     2e8:      	add	x0, x0, #0x360
     2ec:      	mov	w2, #0x4000             ; =16384
     2f0:      	bl	0x2f0 <ltmp0+0x2f0>
     2f4:      	mov	x8, #0x0                ; =0
     2f8:      	add	x21, x23, #0x4, lsl #12 ; =0x4000
     2fc:      	ldr	s0, [x28, x21]
     300:      	str	q0, [sp, #0xe0]
     304:      	str	q0, [sp, #0x8360]
     308:      	ldr	q0, [sp, #0x4360]
     30c:      	ldr	q1, [sp, #0x4370]
     310:      	fmul.4s	v3, v1, v1
     314:      	fmul.4s	v2, v0, v0
     318:      	ldr	q0, [sp, #0x4380]
     31c:      	ldr	q1, [sp, #0x4390]
     320:      	fmul.4s	v5, v1, v1
     324:      	fmul.4s	v4, v0, v0
     328:      	ldr	q0, [sp, #0x43a0]
     32c:      	ldr	q1, [sp, #0x43b0]
     330:      	fmul.4s	v6, v1, v1
     334:      	fmul.4s	v7, v0, v0
     338:      	ldr	q0, [sp, #0x43c0]
     33c:      	ldr	q1, [sp, #0x43d0]
     340:      	fmul.4s	v17, v1, v1
     344:      	fmul.4s	v16, v0, v0
     348:      	add	x9, x26, x8, lsl #5
     34c:      	ldp	q1, q0, [x9, #0x80]
     350:      	fmul.4s	v1, v1, v1
     354:      	fmul.4s	v0, v0, v0
     358:      	fadd.4s	v3, v3, v0
     35c:      	fadd.4s	v2, v2, v1
     360:      	ldp	q1, q0, [x9, #0xa0]
     364:      	fmul.4s	v1, v1, v1
     368:      	fmul.4s	v0, v0, v0
     36c:      	fadd.4s	v5, v5, v0
     370:      	fadd.4s	v4, v4, v1
     374:      	ldp	q1, q0, [x9, #0xc0]
     378:      	fmul.4s	v1, v1, v1
     37c:      	fmul.4s	v0, v0, v0
     380:      	fadd.4s	v6, v6, v0
     384:      	fadd.4s	v7, v7, v1
     388:      	ldp	q1, q0, [x9, #0xe0]
     38c:      	fmul.4s	v1, v1, v1
     390:      	fmul.4s	v0, v0, v0
     394:      	fadd.4s	v17, v17, v0
     398:      	fadd.4s	v16, v16, v1
     39c:      	add	x8, x8, #0x4
     3a0:      	cmp	x8, #0x1fc
     3a4:      	b.lo	0x348 <ltmp0+0x348>
     3a8:      	add	x0, sp, #0x340
     3ac:      	mov	x1, x22
     3b0:      	mov	w2, #0x4000             ; =16384
     3b4:      	stp	q2, q5, [sp, #0x60]
     3b8:      	stp	q3, q7, [sp, #0x80]
     3bc:      	stp	q4, q17, [sp, #0xa0]
     3c0:      	stp	q6, q16, [sp, #0xc0]
     3c4:      	bl	0x3c4 <ltmp0+0x3c4>
     3c8:      	mov	x8, #0x0                ; =0
     3cc:      	ldr	q7, [sp, #0xe0]
     3d0:      	fmul.4s	v0, v7, v7
     3d4:      	ldp	q1, q2, [sp, #0x60]
     3d8:      	fadd.4s	v0, v0, v1
     3dc:      	mov.s	v1[0], v0[0]
     3e0:      	ldr	q0, [sp, #0x80]
     3e4:      	fadd.4s	v0, v2, v0
     3e8:      	ldp	q2, q3, [sp, #0x90]
     3ec:      	fadd.4s	v1, v3, v1
     3f0:      	fadd.4s	v1, v2, v1
     3f4:      	ldp	q2, q3, [sp, #0xb0]
     3f8:      	fadd.4s	v0, v3, v0
     3fc:      	fadd.4s	v0, v2, v0
     400:      	ldr	q2, [sp, #0xd0]
     404:      	fadd.4s	v1, v2, v1
     408:      	rev64.4s	v2, v1
     40c:      	rev64.4s	v3, v0
     410:      	fadd.4s	v0, v0, v3
     414:      	fadd.4s	v1, v1, v2
     418:      	dup.4s	v2, v1[2]
     41c:      	dup.4s	v3, v0[2]
     420:      	fadd.4s	v0, v0, v3
     424:      	fadd.4s	v1, v1, v2
     428:      	fadd.4s	v0, v1, v0
     42c:      	fadd	s0, s0, s8
     430:      	mov	w9, #0x800              ; =2048
     434:      	movk	w9, #0x4580, lsl #16
     438:      	fmov	s1, w9
     43c:      	fdiv	s1, s0, s1
     440:      	ldr	s0, [x24]
     444:      	str	q0, [sp, #0x4340]
     448:      	mov	w9, #0xc5ac             ; =50604
     44c:      	movk	w9, #0x3727, lsl #16
     450:      	fmov	s2, w9
     454:      	fadd	s1, s1, s2
     458:      	fsqrt	s1, s1
     45c:      	dup.4s	v2, v1[0]
     460:      	add	x9, x20, x23
     464:      	add	x10, x26, x8
     468:      	ldp	q3, q4, [x10]
     46c:      	fdiv.4s	v4, v4, v2
     470:      	fdiv.4s	v3, v3, v2
     474:      	add	x10, x19, x8
     478:      	ldp	q6, q5, [x10]
     47c:      	fmul.4s	v3, v3, v6
     480:      	fmul.4s	v4, v4, v5
     484:      	add	x10, x9, x8
     488:      	stp	q3, q4, [x10]
     48c:      	add	x8, x8, #0x20
     490:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     494:      	b.ne	0x464 <ltmp0+0x464>
     498:      	fdiv.4s	v1, v7, v1
     49c:      	fmul.4s	v0, v1, v0
     4a0:      	str	s0, [x20, x21]
     4a4:      	orr	w8, w27, #0x2
     4a8:      	mov	w9, #0x4004             ; =16388
     4ac:      	umull	x23, w8, w9
     4b0:      	umaddl	x1, w8, w9, x28
     4b4:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
     4b8:      	add	x0, x0, #0x360
     4bc:      	mov	w2, #0x4000             ; =16384
     4c0:      	bl	0x4c0 <ltmp0+0x4c0>
     4c4:      	mov	x8, #0x0                ; =0
     4c8:      	add	x21, x23, #0x4, lsl #12 ; =0x4000
     4cc:      	ldr	s0, [x28, x21]
     4d0:      	str	q0, [sp, #0xe0]
     4d4:      	str	q0, [sp, #0x8360]
     4d8:      	ldr	q0, [sp, #0x4360]
     4dc:      	ldr	q1, [sp, #0x4370]
     4e0:      	fmul.4s	v3, v1, v1
     4e4:      	fmul.4s	v2, v0, v0
     4e8:      	ldr	q0, [sp, #0x4380]
     4ec:      	ldr	q1, [sp, #0x4390]
     4f0:      	fmul.4s	v5, v1, v1
     4f4:      	fmul.4s	v4, v0, v0
     4f8:      	ldr	q0, [sp, #0x43a0]
     4fc:      	ldr	q1, [sp, #0x43b0]
     500:      	fmul.4s	v6, v1, v1
     504:      	fmul.4s	v7, v0, v0
     508:      	ldr	q0, [sp, #0x43c0]
     50c:      	ldr	q1, [sp, #0x43d0]
     510:      	fmul.4s	v17, v1, v1
     514:      	fmul.4s	v16, v0, v0
     518:      	add	x9, x26, x8, lsl #5
     51c:      	ldp	q1, q0, [x9, #0x80]
     520:      	fmul.4s	v1, v1, v1
     524:      	fmul.4s	v0, v0, v0
     528:      	fadd.4s	v3, v3, v0
     52c:      	fadd.4s	v2, v2, v1
     530:      	ldp	q1, q0, [x9, #0xa0]
     534:      	fmul.4s	v1, v1, v1
     538:      	fmul.4s	v0, v0, v0
     53c:      	fadd.4s	v5, v5, v0
     540:      	fadd.4s	v4, v4, v1
     544:      	ldp	q1, q0, [x9, #0xc0]
     548:      	fmul.4s	v1, v1, v1
     54c:      	fmul.4s	v0, v0, v0
     550:      	fadd.4s	v6, v6, v0
     554:      	fadd.4s	v7, v7, v1
     558:      	ldp	q1, q0, [x9, #0xe0]
     55c:      	fmul.4s	v1, v1, v1
     560:      	fmul.4s	v0, v0, v0
     564:      	fadd.4s	v17, v17, v0
     568:      	fadd.4s	v16, v16, v1
     56c:      	add	x8, x8, #0x4
     570:      	cmp	x8, #0x1fc
     574:      	b.lo	0x518 <ltmp0+0x518>
     578:      	add	x0, sp, #0x340
     57c:      	mov	x1, x22
     580:      	mov	w2, #0x4000             ; =16384
     584:      	stp	q2, q5, [sp, #0x60]
     588:      	stp	q3, q7, [sp, #0x80]
     58c:      	stp	q4, q17, [sp, #0xa0]
     590:      	stp	q6, q16, [sp, #0xc0]
     594:      	bl	0x594 <ltmp0+0x594>
     598:      	mov	x8, #0x0                ; =0
     59c:      	ldr	q7, [sp, #0xe0]
     5a0:      	fmul.4s	v0, v7, v7
     5a4:      	ldp	q1, q2, [sp, #0x60]
     5a8:      	fadd.4s	v0, v0, v1
     5ac:      	mov.s	v1[0], v0[0]
     5b0:      	ldr	q0, [sp, #0x80]
     5b4:      	fadd.4s	v0, v2, v0
     5b8:      	ldp	q2, q3, [sp, #0x90]
     5bc:      	fadd.4s	v1, v3, v1
     5c0:      	fadd.4s	v1, v2, v1
     5c4:      	ldp	q2, q3, [sp, #0xb0]
     5c8:      	fadd.4s	v0, v3, v0
     5cc:      	fadd.4s	v0, v2, v0
     5d0:      	ldr	q2, [sp, #0xd0]
     5d4:      	fadd.4s	v1, v2, v1
     5d8:      	rev64.4s	v2, v1
     5dc:      	rev64.4s	v3, v0
     5e0:      	fadd.4s	v0, v0, v3
     5e4:      	fadd.4s	v1, v1, v2
     5e8:      	dup.4s	v2, v1[2]
     5ec:      	dup.4s	v3, v0[2]
     5f0:      	fadd.4s	v0, v0, v3
     5f4:      	fadd.4s	v1, v1, v2
     5f8:      	fadd.4s	v0, v1, v0
     5fc:      	fadd	s0, s0, s8
     600:      	mov	w9, #0x800              ; =2048
     604:      	movk	w9, #0x4580, lsl #16
     608:      	fmov	s1, w9
     60c:      	fdiv	s1, s0, s1
     610:      	ldr	s0, [x24]
     614:      	str	q0, [sp, #0x4340]
     618:      	mov	w9, #0xc5ac             ; =50604
     61c:      	movk	w9, #0x3727, lsl #16
     620:      	fmov	s2, w9
     624:      	fadd	s1, s1, s2
     628:      	fsqrt	s1, s1
     62c:      	dup.4s	v2, v1[0]
     630:      	add	x9, x20, x23
     634:      	add	x10, x26, x8
     638:      	ldp	q3, q4, [x10]
     63c:      	fdiv.4s	v4, v4, v2
     640:      	fdiv.4s	v3, v3, v2
     644:      	add	x10, x19, x8
     648:      	ldp	q6, q5, [x10]
     64c:      	fmul.4s	v3, v3, v6
     650:      	fmul.4s	v4, v4, v5
     654:      	add	x10, x9, x8
     658:      	stp	q3, q4, [x10]
     65c:      	add	x8, x8, #0x20
     660:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     664:      	b.ne	0x634 <ltmp0+0x634>
     668:      	fdiv.4s	v1, v7, v1
     66c:      	fmul.4s	v0, v1, v0
     670:      	str	s0, [x20, x21]
     674:      	orr	w8, w27, #0x3
     678:      	mov	w9, #0x4004             ; =16388
     67c:      	umull	x23, w8, w9
     680:      	umaddl	x1, w8, w9, x28
     684:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
     688:      	add	x0, x0, #0x360
     68c:      	mov	w2, #0x4000             ; =16384
     690:      	bl	0x690 <ltmp0+0x690>
     694:      	mov	x8, #0x0                ; =0
     698:      	add	x21, x23, #0x4, lsl #12 ; =0x4000
     69c:      	ldr	s0, [x28, x21]
     6a0:      	str	q0, [sp, #0xe0]
     6a4:      	str	q0, [sp, #0x8360]
     6a8:      	ldr	q0, [sp, #0x4360]
     6ac:      	ldr	q1, [sp, #0x4370]
     6b0:      	fmul.4s	v3, v1, v1
     6b4:      	fmul.4s	v2, v0, v0
     6b8:      	ldr	q0, [sp, #0x4380]
     6bc:      	ldr	q1, [sp, #0x4390]
     6c0:      	fmul.4s	v5, v1, v1
     6c4:      	fmul.4s	v4, v0, v0
     6c8:      	ldr	q0, [sp, #0x43a0]
     6cc:      	ldr	q1, [sp, #0x43b0]
     6d0:      	fmul.4s	v6, v1, v1
     6d4:      	fmul.4s	v7, v0, v0
     6d8:      	ldr	q0, [sp, #0x43c0]
     6dc:      	ldr	q1, [sp, #0x43d0]
     6e0:      	fmul.4s	v17, v1, v1
     6e4:      	fmul.4s	v16, v0, v0
     6e8:      	add	x9, x26, x8, lsl #5
     6ec:      	ldp	q1, q0, [x9, #0x80]
     6f0:      	fmul.4s	v1, v1, v1
     6f4:      	fmul.4s	v0, v0, v0
     6f8:      	fadd.4s	v3, v3, v0
     6fc:      	fadd.4s	v2, v2, v1
     700:      	ldp	q1, q0, [x9, #0xa0]
     704:      	fmul.4s	v1, v1, v1
     708:      	fmul.4s	v0, v0, v0
     70c:      	fadd.4s	v5, v5, v0
     710:      	fadd.4s	v4, v4, v1
     714:      	ldp	q1, q0, [x9, #0xc0]
     718:      	fmul.4s	v1, v1, v1
     71c:      	fmul.4s	v0, v0, v0
     720:      	fadd.4s	v6, v6, v0
     724:      	fadd.4s	v7, v7, v1
     728:      	ldp	q1, q0, [x9, #0xe0]
     72c:      	fmul.4s	v1, v1, v1
     730:      	fmul.4s	v0, v0, v0
     734:      	fadd.4s	v17, v17, v0
     738:      	fadd.4s	v16, v16, v1
     73c:      	add	x8, x8, #0x4
     740:      	cmp	x8, #0x1fc
     744:      	b.lo	0x6e8 <ltmp0+0x6e8>
     748:      	add	x0, sp, #0x340
     74c:      	mov	x1, x22
     750:      	mov	w2, #0x4000             ; =16384
     754:      	stp	q2, q5, [sp, #0x60]
     758:      	stp	q3, q7, [sp, #0x80]
     75c:      	stp	q4, q17, [sp, #0xa0]
     760:      	stp	q6, q16, [sp, #0xc0]
     764:      	bl	0x764 <ltmp0+0x764>
     768:      	mov	x8, #0x0                ; =0
     76c:      	ldr	q7, [sp, #0xe0]
     770:      	fmul.4s	v0, v7, v7
     774:      	ldp	q1, q3, [sp, #0x60]
     778:      	fadd.4s	v0, v0, v1
     77c:      	mov.s	v1[0], v0[0]
     780:      	mov.16b	v2, v1
     784:      	ldr	s0, [x24]
     788:      	ldr	q1, [sp, #0x80]
     78c:      	fadd.4s	v1, v3, v1
     790:      	ldp	q3, q4, [sp, #0x90]
     794:      	fadd.4s	v2, v4, v2
     798:      	fadd.4s	v2, v3, v2
     79c:      	ldp	q3, q4, [sp, #0xb0]
     7a0:      	fadd.4s	v1, v4, v1
     7a4:      	fadd.4s	v1, v3, v1
     7a8:      	ldr	q3, [sp, #0xd0]
     7ac:      	fadd.4s	v2, v3, v2
     7b0:      	rev64.4s	v3, v2
     7b4:      	rev64.4s	v4, v1
     7b8:      	fadd.4s	v1, v1, v4
     7bc:      	fadd.4s	v2, v2, v3
     7c0:      	dup.4s	v3, v2[2]
     7c4:      	dup.4s	v4, v1[2]
     7c8:      	fadd.4s	v1, v1, v4
     7cc:      	fadd.4s	v2, v2, v3
     7d0:      	fadd.4s	v1, v2, v1
     7d4:      	fadd	s1, s1, s8
     7d8:      	mov	w9, #0x800              ; =2048
     7dc:      	movk	w9, #0x4580, lsl #16
     7e0:      	fmov	s2, w9
     7e4:      	fdiv	s1, s1, s2
     7e8:      	str	q0, [sp, #0x4340]
     7ec:      	mov	w9, #0xc5ac             ; =50604
     7f0:      	movk	w9, #0x3727, lsl #16
     7f4:      	fmov	s2, w9
     7f8:      	fadd	s1, s1, s2
     7fc:      	fsqrt	s1, s1
     800:      	dup.4s	v2, v1[0]
     804:      	add	x9, x20, x23
     808:      	mov	x27, x25
     80c:      	ldr	w28, [sp, #0x3c]
     810:      	add	x10, x26, x8
     814:      	ldp	q3, q4, [x10]
     818:      	fdiv.4s	v4, v4, v2
     81c:      	fdiv.4s	v3, v3, v2
     820:      	add	x10, x19, x8
     824:      	ldp	q6, q5, [x10]
     828:      	fmul.4s	v3, v3, v6
     82c:      	fmul.4s	v4, v4, v5
     830:      	add	x10, x9, x8
     834:      	stp	q3, q4, [x10]
     838:      	add	x8, x8, #0x20
     83c:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     840:      	b.ne	0x810 <ltmp0+0x810>
     844:      	fdiv.4s	v1, v7, v1
     848:      	fmul.4s	v0, v1, v0
     84c:      	str	s0, [x20, x21]
     850:      	b	0x6c <ltmp0+0x6c>
     854:      	str	x13, [sp, #0x40]
     858:      	lsr	x8, x9, #3
     85c:      	str	x8, [sp, #0x58]
     860:      	str	x9, [sp, #0x20]
     864:      	cmp	x9, #0x8
     868:      	b.lo	0xa84 <ltmp0+0xa84>
     86c:      	mov	x27, #0x0               ; =0
     870:      	ldr	x8, [sp, #0x18]
     874:      	ldr	x28, [x8]
     878:      	ldr	x22, [x8, #0x10]
     87c:      	ldr	x21, [x8, #0x30]
     880:      	add	x25, x22, #0x4, lsl #12 ; =0x4000
     884:      	ldr	x8, [sp, #0x40]
     888:      	lsl	w23, w8, #2
     88c:      	and	x8, x8, #0x7ffffff
     890:      	mov	w9, #0x10               ; =16
     894:      	movk	w9, #0x1, lsl #16
     898:      	umaddl	x24, w8, w9, x21
     89c:      	add	w8, w27, w23
     8a0:      	and	x8, x8, #0x1fffffff
     8a4:      	add	x8, x8, x8, lsl #12
     8a8:      	lsl	x20, x8, #2
     8ac:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
     8b0:      	add	x0, x0, #0x360
     8b4:      	add	x1, x28, x20
     8b8:      	mov	w2, #0x4000             ; =16384
     8bc:      	bl	0x8bc <ltmp0+0x8bc>
     8c0:      	mov	x8, #0x0                ; =0
     8c4:      	add	x20, x20, #0x4, lsl #12 ; =0x4000
     8c8:      	ldr	s0, [x28, x20]
     8cc:      	str	q0, [sp, #0xe0]
     8d0:      	str	q0, [sp, #0x8360]
     8d4:      	ldr	q0, [sp, #0x4360]
     8d8:      	ldr	q1, [sp, #0x4370]
     8dc:      	fmul.4s	v3, v1, v1
     8e0:      	fmul.4s	v2, v0, v0
     8e4:      	ldr	q0, [sp, #0x4380]
     8e8:      	ldr	q1, [sp, #0x4390]
     8ec:      	fmul.4s	v5, v1, v1
     8f0:      	fmul.4s	v4, v0, v0
     8f4:      	ldr	q0, [sp, #0x43a0]
     8f8:      	ldr	q1, [sp, #0x43b0]
     8fc:      	fmul.4s	v6, v1, v1
     900:      	fmul.4s	v7, v0, v0
     904:      	ldr	q0, [sp, #0x43c0]
     908:      	ldr	q1, [sp, #0x43d0]
     90c:      	fmul.4s	v17, v1, v1
     910:      	fmul.4s	v16, v0, v0
     914:      	add	x9, x26, x8, lsl #5
     918:      	ldp	q1, q0, [x9, #0x80]
     91c:      	fmul.4s	v1, v1, v1
     920:      	fmul.4s	v0, v0, v0
     924:      	fadd.4s	v3, v3, v0
     928:      	fadd.4s	v2, v2, v1
     92c:      	ldp	q1, q0, [x9, #0xa0]
     930:      	fmul.4s	v1, v1, v1
     934:      	fmul.4s	v0, v0, v0
     938:      	fadd.4s	v5, v5, v0
     93c:      	fadd.4s	v4, v4, v1
     940:      	ldp	q1, q0, [x9, #0xc0]
     944:      	fmul.4s	v1, v1, v1
     948:      	fmul.4s	v0, v0, v0
     94c:      	fadd.4s	v6, v6, v0
     950:      	fadd.4s	v7, v7, v1
     954:      	ldp	q1, q0, [x9, #0xe0]
     958:      	fmul.4s	v1, v1, v1
     95c:      	fmul.4s	v0, v0, v0
     960:      	fadd.4s	v17, v17, v0
     964:      	fadd.4s	v16, v16, v1
     968:      	add	x8, x8, #0x4
     96c:      	cmp	x8, #0x1fc
     970:      	b.lo	0x914 <ltmp0+0x914>
     974:      	add	x0, sp, #0x340
     978:      	mov	x1, x22
     97c:      	mov	w2, #0x4000             ; =16384
     980:      	stp	q2, q5, [sp, #0x60]
     984:      	stp	q3, q7, [sp, #0x80]
     988:      	stp	q4, q17, [sp, #0xa0]
     98c:      	stp	q6, q16, [sp, #0xc0]
     990:      	bl	0x990 <ltmp0+0x990>
     994:      	mov	x8, #0x0                ; =0
     998:      	ldr	q7, [sp, #0xe0]
     99c:      	fmul.4s	v0, v7, v7
     9a0:      	ldp	q1, q2, [sp, #0x60]
     9a4:      	fadd.4s	v0, v0, v1
     9a8:      	mov.s	v1[0], v0[0]
     9ac:      	ldr	q0, [sp, #0x80]
     9b0:      	fadd.4s	v0, v2, v0
     9b4:      	ldp	q2, q3, [sp, #0x90]
     9b8:      	fadd.4s	v1, v3, v1
     9bc:      	fadd.4s	v1, v2, v1
     9c0:      	ldp	q2, q3, [sp, #0xb0]
     9c4:      	fadd.4s	v0, v3, v0
     9c8:      	fadd.4s	v0, v2, v0
     9cc:      	ldr	q2, [sp, #0xd0]
     9d0:      	fadd.4s	v1, v2, v1
     9d4:      	rev64.4s	v2, v1
     9d8:      	rev64.4s	v3, v0
     9dc:      	fadd.4s	v0, v0, v3
     9e0:      	fadd.4s	v1, v1, v2
     9e4:      	dup.4s	v2, v1[2]
     9e8:      	dup.4s	v3, v0[2]
     9ec:      	fadd.4s	v0, v0, v3
     9f0:      	fadd.4s	v1, v1, v2
     9f4:      	fadd.4s	v0, v1, v0
     9f8:      	fadd	s0, s0, s8
     9fc:      	mov	w9, #0x800              ; =2048
     a00:      	movk	w9, #0x4580, lsl #16
     a04:      	fmov	s1, w9
     a08:      	fdiv	s1, s0, s1
     a0c:      	ldr	s0, [x25]
     a10:      	str	q0, [sp, #0x4340]
     a14:      	mov	w9, #0xc5ac             ; =50604
     a18:      	movk	w9, #0x3727, lsl #16
     a1c:      	fmov	s2, w9
     a20:      	fadd	s1, s1, s2
     a24:      	fsqrt	s1, s1
     a28:      	dup.4s	v2, v1[0]
     a2c:      	add	x9, x26, x8
     a30:      	ldp	q3, q4, [x9]
     a34:      	fdiv.4s	v4, v4, v2
     a38:      	fdiv.4s	v3, v3, v2
     a3c:      	add	x9, x19, x8
     a40:      	ldp	q6, q5, [x9]
     a44:      	fmul.4s	v3, v3, v6
     a48:      	fmul.4s	v4, v4, v5
     a4c:      	add	x9, x24, x8
     a50:      	stp	q3, q4, [x9]
     a54:      	add	x8, x8, #0x20
     a58:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     a5c:      	b.ne	0xa2c <ltmp0+0xa2c>
     a60:      	fdiv.4s	v1, v7, v1
     a64:      	fmul.4s	v0, v1, v0
     a68:      	str	s0, [x21, x20]
     a6c:      	add	x27, x27, #0x1
     a70:      	mov	w8, #0x4004             ; =16388
     a74:      	add	x24, x24, x8
     a78:      	ldr	x8, [sp, #0x58]
     a7c:      	cmp	x27, x8
     a80:      	b.ne	0x89c <ltmp0+0x89c>
     a84:      	ldr	x8, [sp, #0x20]
     a88:      	and	w8, w8, #0x7
     a8c:      	ldr	w28, [sp, #0x3c]
     a90:      	ldr	w25, [sp, #0x54]
     a94:      	ldr	x27, [sp, #0x40]
     a98:      	cbz	w8, 0x70 <ltmp0+0x70>
     a9c:      	dup.4s	v1, w8
     aa0:      	adrp	x8, 0x0 <ltmp0>
     aa4:      	ldr	q2, [x8]
     aa8:      	adrp	x8, 0x0 <ltmp0>
     aac:      	ldr	q0, [x8]
     ab0:      	cmhi.4s	v0, v1, v0
     ab4:      	cmhi.4s	v1, v1, v2
     ab8:      	uzp1.8h	v3, v1, v0
     abc:      	umaxv.8h	h2, v3
     ac0:      	fmov	w8, s2
     ac4:      	mov	w20, #0x4               ; =4
     ac8:      	tbz	w8, #0x0, 0x6c <ltmp0+0x6c>
     acc:      	mov	x10, #0x0               ; =0
     ad0:      	ldr	x8, [sp, #0x18]
     ad4:      	ldr	x14, [x8]
     ad8:      	ldr	x11, [x8, #0x10]
     adc:      	ldr	x8, [x8, #0x30]
     ae0:      	adrp	x9, 0x0 <ltmp0>
     ae4:      	ldr	q2, [x9]
     ae8:      	str	q3, [sp, #0x80]
     aec:      	and.16b	v2, v3, v2
     af0:      	addv.8h	h2, v2
     af4:      	fmov	w9, s2
     af8:      	and	w12, w9, #0xff
     afc:      	xtn.4h	v4, v1
     b00:      	uzp1.8b	v5, v4, v0
     b04:      	ubfiz	w9, w27, #2, #27
     b08:      	ldr	x13, [sp, #0x58]
     b0c:      	orr	w9, w9, w13
     b10:      	dup.4s	v3, w9
     b14:      	and.16b	v6, v1, v3
     b18:      	and.16b	v3, v0, v3
     b1c:      	ushll2.2d	v20, v3, #0x0
     b20:      	ushll2.2d	v21, v6, #0x0
     b24:      	ushll.2d	v22, v3, #0x0
     b28:      	ushll.2d	v3, v6, #0x0
     b2c:      	umov.b	w13, v5[0]
     b30:      	mov	w15, #0x4004            ; =16388
     b34:      	umull	x9, w9, w15
     b38:      	tst	w13, #0x1
     b3c:      	csel	x9, x9, xzr, ne
     b40:      	add	x15, x14, x9
     b44:      	b	0xb68 <ltmp0+0xb68>
     b48:      	add	x16, x26, x10
     b4c:      	ldp	q7, q16, [x16]
     b50:      	bif.16b	v6, v16, v0
     b54:      	bif.16b	v5, v7, v1
     b58:      	stp	q5, q6, [x16]
     b5c:      	add	x10, x10, #0x20
     b60:      	cmp	x10, #0x4, lsl #12      ; =0x4000
     b64:      	b.eq	0xc00 <ltmp0+0xc00>
     b68:      	fmov	w17, s2
     b6c:      	add	x16, x15, x10
     b70:      	movi.2d	v5, #0000000000000000
     b74:      	movi.2d	v6, #0000000000000000
     b78:      	tbnz	w17, #0x0, 0xba0 <ltmp0+0xba0>
     b7c:      	and	w17, w17, #0xff
     b80:      	tbnz	w17, #0x1, 0xbac <ltmp0+0xbac>
     b84:      	tbnz	w17, #0x2, 0xbb8 <ltmp0+0xbb8>
     b88:      	tbnz	w17, #0x3, 0xbc4 <ltmp0+0xbc4>
     b8c:      	tbnz	w17, #0x4, 0xbd0 <ltmp0+0xbd0>
     b90:      	tbnz	w17, #0x5, 0xbdc <ltmp0+0xbdc>
     b94:      	tbnz	w17, #0x6, 0xbe8 <ltmp0+0xbe8>
     b98:      	tbz	w17, #0x7, 0xb48 <ltmp0+0xb48>
     b9c:      	b	0xbf4 <ltmp0+0xbf4>
     ba0:      	ldr	s5, [x16]
     ba4:      	and	w17, w17, #0xff
     ba8:      	tbz	w17, #0x1, 0xb84 <ltmp0+0xb84>
     bac:      	add	x0, x16, #0x4
     bb0:      	ld1.s	{ v5 }[1], [x0]
     bb4:      	tbz	w17, #0x2, 0xb88 <ltmp0+0xb88>
     bb8:      	add	x0, x16, #0x8
     bbc:      	ld1.s	{ v5 }[2], [x0]
     bc0:      	tbz	w17, #0x3, 0xb8c <ltmp0+0xb8c>
     bc4:      	add	x0, x16, #0xc
     bc8:      	ld1.s	{ v5 }[3], [x0]
     bcc:      	tbz	w17, #0x4, 0xb90 <ltmp0+0xb90>
     bd0:      	add	x0, x16, #0x10
     bd4:      	ld1.s	{ v6 }[0], [x0]
     bd8:      	tbz	w17, #0x5, 0xb94 <ltmp0+0xb94>
     bdc:      	add	x0, x16, #0x14
     be0:      	ld1.s	{ v6 }[1], [x0]
     be4:      	tbz	w17, #0x6, 0xb98 <ltmp0+0xb98>
     be8:      	add	x0, x16, #0x18
     bec:      	ld1.s	{ v6 }[2], [x0]
     bf0:      	tbz	w17, #0x7, 0xb48 <ltmp0+0xb48>
     bf4:      	add	x16, x16, #0x1c
     bf8:      	ld1.s	{ v6 }[3], [x16]
     bfc:      	b	0xb48 <ltmp0+0xb48>
     c00:      	uzp1.8b	v5, v4, v0
     c04:      	sshll.2d	v7, v1, #0x0
     c08:      	movi.2d	v6, #0000000000000000
     c0c:      	mov.b	v6[0], v5[0]
     c10:      	adrp	x10, 0x0 <ltmp0>
     c14:      	ldr	d4, [x10]
     c18:      	str	d4, [sp, #0x90]
     c1c:      	and.8b	v4, v6, v4
     c20:      	addv.8b	b4, v4
     c24:      	fmov	w15, s4
     c28:      	umaxv.8b	b4, v6
     c2c:      	fmov	w16, s4
     c30:      	rbit	w10, w15
     c34:      	clz	w10, w10
     c38:      	tst	w16, #0x1
     c3c:      	csel	w10, w10, wzr, ne
     c40:      	mov	w17, #0x1000            ; =4096
     c44:      	dup.2d	v17, x17
     c48:      	adrp	x17, 0x0 <ltmp0>
     c4c:      	ldr	q4, [x17]
     c50:      	bif.16b	v4, v17, v7
     c54:      	xtn.2s	v3, v3
     c58:      	mov	w17, #0x1001            ; =4097
     c5c:      	dup.2s	v24, w17
     c60:      	umlal.2d	v4, v3, v24
     c64:      	movi.2d	v3, #0000000000000000
     c68:      	mov.b	v3[0], v5[0]
     c6c:      	ushll.2d	v3, v3, #0x0
     c70:      	shl.2d	v3, v3, #0x3f
     c74:      	cmlt.2d	v3, v3, #0
     c78:      	str	q4, [sp, #0xe0]
     c7c:      	and.16b	v3, v3, v4
     c80:      	movi.2d	v4, #0000000000000000
     c84:      	stp	q4, q4, [sp, #0x310]
     c88:      	stp	q3, q4, [sp, #0x2f0]
     c8c:      	and	x17, x10, #0x7
     c90:      	add	x0, sp, #0x2f0
     c94:      	ldr	x17, [x0, x17, lsl #3]
     c98:      	sub	x17, x17, x10
     c9c:      	add	x14, x14, x17, lsl #2
     ca0:      	movi.2d	v3, #0000000000000000
     ca4:      	tbnz	w16, #0x0, 0x152c <ltmp0+0x152c>
     ca8:      	tbnz	w15, #0x1, 0x1534 <ltmp0+0x1534>
     cac:      	tbnz	w15, #0x2, 0x1540 <ltmp0+0x1540>
     cb0:      	tbnz	w15, #0x3, 0x154c <ltmp0+0x154c>
     cb4:      	tbnz	w15, #0x4, 0x1558 <ltmp0+0x1558>
     cb8:      	tbnz	w15, #0x5, 0x1564 <ltmp0+0x1564>
     cbc:      	tbnz	w15, #0x6, 0x1570 <ltmp0+0x1570>
     cc0:      	tbz	w15, #0x7, 0xccc <ltmp0+0xccc>
     cc4:      	add	x14, x14, #0x1c
     cc8:      	ld1.s	{ v3 }[3], [x14]
     ccc:      	sshll.2d	v16, v0, #0x0
     cd0:      	sshll2.2d	v23, v1, #0x0
     cd4:      	sshll2.2d	v11, v0, #0x0
     cd8:      	adrp	x14, 0x0 <ltmp0>
     cdc:      	ldr	q18, [x14]
     ce0:      	and.16b	v18, v11, v18
     ce4:      	adrp	x14, 0x0 <ltmp0>
     ce8:      	ldr	q25, [x14]
     cec:      	and.16b	v25, v23, v25
     cf0:      	adrp	x14, 0x0 <ltmp0>
     cf4:      	ldr	q26, [x14]
     cf8:      	and.16b	v26, v16, v26
     cfc:      	adrp	x14, 0x0 <ltmp0>
     d00:      	ldr	q27, [x14]
     d04:      	and.16b	v27, v7, v27
     d08:      	adrp	x14, 0x0 <ltmp0>
     d0c:      	ldr	q7, [x14]
     d10:      	mov.16b	v5, v16
     d14:      	bsl.16b	v5, v7, v17
     d18:      	adrp	x14, 0x0 <ltmp0>
     d1c:      	ldr	q16, [x14]
     d20:      	mov.16b	v7, v23
     d24:      	bsl.16b	v7, v16, v17
     d28:      	adrp	x14, 0x0 <ltmp0>
     d2c:      	ldr	q28, [x14]
     d30:      	mov.16b	v16, v11
     d34:      	bsl.16b	v16, v28, v17
     d38:      	xtn.2s	v22, v22
     d3c:      	xtn.2s	v21, v21
     d40:      	xtn.2s	v20, v20
     d44:      	umlal.2d	v16, v20, v24
     d48:      	umlal.2d	v7, v21, v24
     d4c:      	stp	q16, q7, [sp, #0xa0]
     d50:      	umlal.2d	v5, v22, v24
     d54:      	str	q5, [sp, #0xc0]
     d58:      	sshll.2d	v24, v1, #0x0
     d5c:      	sshll.2d	v22, v0, #0x0
     d60:      	stp	q27, q25, [sp, #0x2b0]
     d64:      	stp	q26, q18, [sp, #0x2d0]
     d68:      	and	x14, x10, #0x7
     d6c:      	add	x16, sp, #0x2b0
     d70:      	ldr	x14, [x16, x14, lsl #3]
     d74:      	orr	x14, x14, #0x4000
     d78:      	sub	x14, x14, x10, lsl #2
     d7c:      	tst	w15, #0xff
     d80:      	csel	x14, xzr, x14, eq
     d84:      	add	x15, x26, x14
     d88:      	ldp	q18, q20, [x15]
     d8c:      	zip2.8b	v21, v6, v0
     d90:      	ushll.4s	v21, v21, #0x0
     d94:      	shl.4s	v21, v21, #0x1f
     d98:      	cmlt.4s	v21, v21, #0
     d9c:      	bit.16b	v20, v3, v21
     da0:      	zip1.8b	v21, v6, v0
     da4:      	ushll.4s	v21, v21, #0x0
     da8:      	shl.4s	v21, v21, #0x1f
     dac:      	cmlt.4s	v21, v21, #0
     db0:      	str	q4, [sp, #0xd0]
     db4:      	bit.16b	v18, v4, v21
     db8:      	stp	q18, q20, [x15]
     dbc:      	dup.2d	v18, x20
     dc0:      	and.16b	v20, v11, v18
     dc4:      	and.16b	v21, v23, v18
     dc8:      	and.16b	v22, v22, v18
     dcc:      	and.16b	v18, v24, v18
     dd0:      	tst	w13, #0x1
     dd4:      	csel	x15, x20, xzr, ne
     dd8:      	ldr	q24, [sp, #0x43d0]
     ddc:      	ldr	q25, [sp, #0x43c0]
     de0:      	fmul.4s	v26, v25, v25
     de4:      	fmul.4s	v24, v24, v24
     de8:      	and.16b	v25, v0, v24
     dec:      	and.16b	v24, v1, v26
     df0:      	ldr	q26, [sp, #0x43b0]
     df4:      	ldr	q27, [sp, #0x43a0]
     df8:      	fmul.4s	v27, v27, v27
     dfc:      	fmul.4s	v26, v26, v26
     e00:      	and.16b	v26, v0, v26
     e04:      	and.16b	v27, v1, v27
     e08:      	ldr	q28, [sp, #0x4390]
     e0c:      	ldr	q29, [sp, #0x4380]
     e10:      	fmul.4s	v30, v29, v29
     e14:      	fmul.4s	v28, v28, v28
     e18:      	and.16b	v29, v0, v28
     e1c:      	and.16b	v28, v1, v30
     e20:      	ldr	q30, [sp, #0x4370]
     e24:      	ldr	q31, [sp, #0x4360]
     e28:      	fmul.4s	v31, v31, v31
     e2c:      	fmul.4s	v30, v30, v30
     e30:      	and.16b	v30, v0, v30
     e34:      	and.16b	v31, v1, v31
     e38:      	sshll.2d	v12, v1, #0x0
     e3c:      	sshll.2d	v13, v0, #0x0
     e40:      	add	x15, x26, x15, lsl #5
     e44:      	ldp	q10, q9, [x15]
     e48:      	and.16b	v10, v1, v10
     e4c:      	and.16b	v9, v0, v9
     e50:      	fmul.4s	v9, v9, v9
     e54:      	fmul.4s	v10, v10, v10
     e58:      	fadd.4s	v10, v31, v10
     e5c:      	fadd.4s	v9, v30, v9
     e60:      	ldp	q15, q14, [x15, #0x20]
     e64:      	and.16b	v15, v1, v15
     e68:      	and.16b	v14, v0, v14
     e6c:      	fmul.4s	v14, v14, v14
     e70:      	fmul.4s	v15, v15, v15
     e74:      	fadd.4s	v15, v28, v15
     e78:      	fadd.4s	v14, v29, v14
     e7c:      	ldp	q16, q7, [x15, #0x40]
     e80:      	and.16b	v16, v1, v16
     e84:      	and.16b	v7, v0, v7
     e88:      	fmul.4s	v7, v7, v7
     e8c:      	fmul.4s	v16, v16, v16
     e90:      	fadd.4s	v16, v27, v16
     e94:      	fadd.4s	v7, v26, v7
     e98:      	ldp	q4, q17, [x15, #0x60]
     e9c:      	and.16b	v4, v1, v4
     ea0:      	and.16b	v17, v0, v17
     ea4:      	fmul.4s	v17, v17, v17
     ea8:      	fmul.4s	v4, v4, v4
     eac:      	fadd.4s	v4, v24, v4
     eb0:      	fadd.4s	v17, v25, v17
     eb4:      	dup.2d	v19, x20
     eb8:      	and.16b	v5, v11, v19
     ebc:      	add.2d	v20, v20, v5
     ec0:      	and.16b	v5, v23, v19
     ec4:      	add.2d	v21, v21, v5
     ec8:      	and.16b	v5, v13, v19
     ecc:      	add.2d	v22, v22, v5
     ed0:      	and.16b	v5, v12, v19
     ed4:      	add.2d	v5, v18, v5
     ed8:      	bit.16b	v30, v9, v0
     edc:      	bit.16b	v31, v10, v1
     ee0:      	bit.16b	v29, v14, v0
     ee4:      	bit.16b	v28, v15, v1
     ee8:      	bit.16b	v26, v7, v0
     eec:      	bit.16b	v27, v16, v1
     ef0:      	bit.16b	v25, v17, v0
     ef4:      	bit.16b	v24, v4, v1
     ef8:      	fmov	x15, d18
     efc:      	add	x17, x15, #0x4
     f00:      	ands	w16, w13, #0x1
     f04:      	csel	x15, x17, x15, ne
     f08:      	mov.16b	v18, v5
     f0c:      	cmp	x15, #0x200
     f10:      	b.lt	0xe38 <ltmp0+0xe38>
     f14:      	mov	x17, #0x0               ; =0
     f18:      	ushll2.2d	v4, v0, #0x0
     f1c:      	mov	w15, #0x1               ; =1
     f20:      	dup.2d	v5, x15
     f24:      	and.16b	v20, v4, v5
     f28:      	ushll2.2d	v4, v1, #0x0
     f2c:      	and.16b	v21, v4, v5
     f30:      	ushll.2d	v4, v0, #0x0
     f34:      	and.16b	v22, v4, v5
     f38:      	ushll.2d	v4, v1, #0x0
     f3c:      	and.16b	v23, v4, v5
     f40:      	movi.2d	v11, #0000000000000000
     f44:      	and	x15, x13, #0x1
     f48:      	movi.2d	v12, #0000000000000000
     f4c:      	movi.2d	v13, #0000000000000000
     f50:      	movi.2d	v14, #0000000000000000
     f54:      	b	0xf90 <ltmp0+0xf90>
     f58:      	add	x17, x19, x17
     f5c:      	ldp	q4, q5, [x17]
     f60:      	bit.16b	v5, v18, v0
     f64:      	bit.16b	v4, v15, v1
     f68:      	stp	q4, q5, [x17]
     f6c:      	add.2d	v4, v11, v23
     f70:      	add.2d	v12, v12, v21
     f74:      	add.2d	v13, v13, v22
     f78:      	add.2d	v14, v14, v20
     f7c:      	fmov	x17, d11
     f80:      	add	x17, x17, x15
     f84:      	mov.16b	v11, v4
     f88:      	cmp	x17, #0x200
     f8c:      	b.ge	0x102c <ltmp0+0x102c>
     f90:      	fmov	w1, s2
     f94:      	lsl	x17, x17, #5
     f98:      	add	x0, x11, x17
     f9c:      	movi.2d	v15, #0000000000000000
     fa0:      	movi.2d	v18, #0000000000000000
     fa4:      	tbnz	w1, #0x0, 0xfcc <ltmp0+0xfcc>
     fa8:      	and	w1, w1, #0xff
     fac:      	tbnz	w1, #0x1, 0xfd8 <ltmp0+0xfd8>
     fb0:      	tbnz	w1, #0x2, 0xfe4 <ltmp0+0xfe4>
     fb4:      	tbnz	w1, #0x3, 0xff0 <ltmp0+0xff0>
     fb8:      	tbnz	w1, #0x4, 0xffc <ltmp0+0xffc>
     fbc:      	tbnz	w1, #0x5, 0x1008 <ltmp0+0x1008>
     fc0:      	tbnz	w1, #0x6, 0x1014 <ltmp0+0x1014>
     fc4:      	tbz	w1, #0x7, 0xf58 <ltmp0+0xf58>
     fc8:      	b	0x1020 <ltmp0+0x1020>
     fcc:      	ldr	s15, [x0]
     fd0:      	and	w1, w1, #0xff
     fd4:      	tbz	w1, #0x1, 0xfb0 <ltmp0+0xfb0>
     fd8:      	add	x2, x0, #0x4
     fdc:      	ld1.s	{ v15 }[1], [x2]
     fe0:      	tbz	w1, #0x2, 0xfb4 <ltmp0+0xfb4>
     fe4:      	add	x2, x0, #0x8
     fe8:      	ld1.s	{ v15 }[2], [x2]
     fec:      	tbz	w1, #0x3, 0xfb8 <ltmp0+0xfb8>
     ff0:      	add	x2, x0, #0xc
     ff4:      	ld1.s	{ v15 }[3], [x2]
     ff8:      	tbz	w1, #0x4, 0xfbc <ltmp0+0xfbc>
     ffc:      	add	x2, x0, #0x10
    1000:      	ld1.s	{ v18 }[0], [x2]
    1004:      	tbz	w1, #0x5, 0xfc0 <ltmp0+0xfc0>
    1008:      	add	x2, x0, #0x14
    100c:      	ld1.s	{ v18 }[1], [x2]
    1010:      	tbz	w1, #0x6, 0xfc4 <ltmp0+0xfc4>
    1014:      	add	x2, x0, #0x18
    1018:      	ld1.s	{ v18 }[2], [x2]
    101c:      	tbz	w1, #0x7, 0xf58 <ltmp0+0xf58>
    1020:      	add	x0, x0, #0x1c
    1024:      	ld1.s	{ v18 }[3], [x0]
    1028:      	b	0xf58 <ltmp0+0xf58>
    102c:      	ldr	q4, [sp, #0x80]
    1030:      	xtn.8b	v11, v4
    1034:      	fmul.4s	v4, v3, v3
    1038:      	ldr	q12, [sp, #0xd0]
    103c:      	fmul.4s	v5, v12, v12
    1040:      	fadd.4s	v5, v5, v31
    1044:      	fadd.4s	v4, v4, v30
    1048:      	zip2.8b	v7, v6, v0
    104c:      	ushll.4s	v7, v7, #0x0
    1050:      	shl.4s	v7, v7, #0x1f
    1054:      	cmlt.4s	v7, v7, #0
    1058:      	and.16b	v4, v7, v4
    105c:      	zip1.8b	v7, v6, v0
    1060:      	ushll.4s	v7, v7, #0x0
    1064:      	shl.4s	v7, v7, #0x1f
    1068:      	cmlt.4s	v7, v7, #0
    106c:      	movi.2d	v16, #0000000000000000
    1070:      	mov.b	v16[2], v11[1]
    1074:      	mov.b	v16[4], v11[2]
    1078:      	mov.b	v16[6], v11[3]
    107c:      	and.16b	v5, v7, v5
    1080:      	ushll.4s	v7, v16, #0x0
    1084:      	shl.4s	v7, v7, #0x1f
    1088:      	cmlt.4s	v7, v7, #0
    108c:      	bit.16b	v5, v10, v7
    1090:      	zip2.8b	v7, v11, v0
    1094:      	ushll.4s	v7, v7, #0x0
    1098:      	shl.4s	v7, v7, #0x1f
    109c:      	cmlt.4s	v7, v7, #0
    10a0:      	bit.16b	v4, v9, v7
    10a4:      	fadd.4s	v4, v29, v4
    10a8:      	fadd.4s	v5, v28, v5
    10ac:      	fadd.4s	v5, v27, v5
    10b0:      	fadd.4s	v4, v26, v4
    10b4:      	fadd.4s	v19, v25, v4
    10b8:      	fadd.4s	v18, v24, v5
    10bc:      	umov.b	w17, v11[1]
    10c0:      	mov	s4, v18[1]
    10c4:      	tst	w16, w17
    10c8:      	fcsel	s24, s4, s8, ne
    10cc:      	mvn	w0, w17
    10d0:      	add	x1, sp, #0x280
    10d4:      	bfi	x1, x0, #2, #1
    10d8:      	add	x2, sp, #0x138
    10dc:      	bfxil	x2, x0, #0, #1
    10e0:      	str	d11, [sp, #0x138]
    10e4:      	ldrb	w0, [x2]
    10e8:      	and	w0, w17, w0
    10ec:      	stp	q18, q19, [sp, #0x280]
    10f0:      	ldr	s4, [x1]
    10f4:      	tst	w0, #0x1
    10f8:      	fcsel	s25, s4, s8, ne
    10fc:      	umov.b	w0, v11[2]
    1100:      	ands	w1, w0, #0x1
    1104:      	mov	w2, #0x3                ; =3
    1108:      	csinc	w2, w2, wzr, ne
    110c:      	add	x23, sp, #0x138
    1110:      	orr	x3, x23, x2
    1114:      	ldrb	w3, [x3]
    1118:      	add	x4, sp, #0x260
    111c:      	orr	x2, x4, x2, lsl #2
    1120:      	stp	q18, q19, [sp, #0x260]
    1124:      	ldr	s4, [x2]
    1128:      	tst	w1, w3
    112c:      	fcsel	s26, s4, s8, ne
    1130:      	umov.b	w1, v11[3]
    1134:      	ands	w2, w1, #0x1
    1138:      	mov	w3, #0x1                ; =1
    113c:      	cinc	w3, w3, ne
    1140:      	add	x4, sp, #0x138
    1144:      	bfxil	x4, x3, #0, #3
    1148:      	ldrb	w4, [x4]
    114c:      	add	x5, sp, #0x240
    1150:      	orr	x3, x5, x3, lsl #2
    1154:      	stp	q18, q19, [sp, #0x240]
    1158:      	ldr	s4, [x3]
    115c:      	tst	w2, w4
    1160:      	umov.b	w2, v11[4]
    1164:      	fcsel	s4, s4, s8, ne
    1168:      	ands	w5, w2, #0x1
    116c:      	mov	w3, #0x5                ; =5
    1170:      	csinc	w3, w3, wzr, ne
    1174:      	orr	x4, x23, x3
    1178:      	ldrb	w4, [x4]
    117c:      	stp	q18, q19, [sp, #0x220]
    1180:      	add	x6, sp, #0x220
    1184:      	ldr	s5, [x6, w3, uxtw #2]
    1188:      	mov	w3, #0x2                ; =2
    118c:      	mov	w22, #0x6               ; =6
    1190:      	csel	w7, w22, w3, ne
    1194:      	umov.b	w3, v11[5]
    1198:      	tst	w5, w4
    119c:      	fcsel	s27, s5, s8, ne
    11a0:      	ands	w6, w3, #0x1
    11a4:      	csinc	w4, w20, wzr, ne
    11a8:      	orr	x20, x23, x4
    11ac:      	ldrb	w20, [x20]
    11b0:      	stp	q18, q19, [sp, #0x200]
    11b4:      	add	x21, sp, #0x200
    11b8:      	ldr	s5, [x21, w4, uxtw #2]
    11bc:      	umov.b	w4, v11[6]
    11c0:      	tst	w6, w20
    11c4:      	fcsel	s5, s5, s8, ne
    11c8:      	ands	w20, w4, #0x1
    11cc:      	mov	w6, #0x7                ; =7
    11d0:      	csinc	w6, w6, wzr, ne
    11d4:      	orr	x21, x23, x6
    11d8:      	ldrb	w21, [x21]
    11dc:      	stp	q18, q19, [sp, #0x1e0]
    11e0:      	add	x24, sp, #0x1e0
    11e4:      	ldr	s7, [x24, w6, uxtw #2]
    11e8:      	umov.b	w6, v11[7]
    11ec:      	tst	w20, w21
    11f0:      	fcsel	s7, s7, s8, ne
    11f4:      	ands	w20, w6, #0x1
    11f8:      	csinc	w21, w22, wzr, ne
    11fc:      	orr	x22, x23, x21
    1200:      	ldrb	w22, [x22]
    1204:      	tst	w20, w22
    1208:      	stp	q18, q19, [sp, #0x1c0]
    120c:      	add	x20, sp, #0x1c0
    1210:      	ldr	s16, [x20, w21, uxtw #2]
    1214:      	fcsel	s16, s16, s8, ne
    1218:      	mov.s	v24[1], v25[0]
    121c:      	mov.s	v24[2], v26[0]
    1220:      	mov.s	v24[3], v4[0]
    1224:      	mov.s	v27[1], v5[0]
    1228:      	mov.s	v27[2], v7[0]
    122c:      	mov.s	v27[3], v16[0]
    1230:      	fadd.4s	v4, v18, v24
    1234:      	mov	s5, v4[2]
    1238:      	tst	w16, w0
    123c:      	fcsel	s5, s5, s8, ne
    1240:      	orr	x20, x23, x7
    1244:      	ldrb	w20, [x20]
    1248:      	tst	w5, w20
    124c:      	fadd.4s	v7, v19, v27
    1250:      	stp	q4, q7, [sp, #0x1a0]
    1254:      	add	x5, sp, #0x1a0
    1258:      	ldr	s16, [x5, w7, uxtw #2]
    125c:      	fcsel	s16, s16, s8, ne
    1260:      	tst	w16, w2
    1264:      	fadd.4s	v7, v7, v16
    1268:      	fcsel	s7, s7, s8, ne
    126c:      	ands	w13, w13, #0x1
    1270:      	fadd.4s	v4, v4, v5
    1274:      	fadd	s4, s4, s7
    1278:      	fcsel	s5, s4, s8, ne
    127c:      	tst	w13, w17
    1280:      	fcsel	s7, s4, s8, ne
    1284:      	tst	w13, w0
    1288:      	fcsel	s16, s4, s8, ne
    128c:      	tst	w1, #0x1
    1290:      	fcsel	s17, s5, s8, ne
    1294:      	tst	w13, w2
    1298:      	fcsel	s4, s4, s8, ne
    129c:      	tst	w3, #0x1
    12a0:      	fcsel	s18, s5, s8, ne
    12a4:      	tst	w4, #0x1
    12a8:      	fcsel	s19, s5, s8, ne
    12ac:      	tst	w6, #0x1
    12b0:      	sshll.2d	v24, v1, #0x0
    12b4:      	shl.8b	v25, v6, #0x7
    12b8:      	cmlt.8b	v25, v25, #0
    12bc:      	ldr	d26, [sp, #0x90]
    12c0:      	and.8b	v26, v25, v26
    12c4:      	fcsel	s25, s5, s8, ne
    12c8:      	mov.s	v4[1], v18[0]
    12cc:      	mov.s	v4[2], v19[0]
    12d0:      	mov.s	v4[3], v25[0]
    12d4:      	mov.s	v5[1], v7[0]
    12d8:      	mov.s	v5[2], v16[0]
    12dc:      	mov.s	v5[3], v17[0]
    12e0:      	rbit	w12, w12
    12e4:      	clz	w12, w12
    12e8:      	stp	q5, q4, [sp, #0x180]
    12ec:      	and	x12, x12, #0x7
    12f0:      	add	x13, sp, #0x180
    12f4:      	ldr	s25, [x13, x12, lsl #2]
    12f8:      	adrp	x12, 0x1000 <ltmp0+0x1000>
    12fc:      	ldr	q4, [x12]
    1300:      	and.16b	v4, v24, v4
    1304:      	movi.2d	v5, #0000000000000000
    1308:      	stp	q5, q5, [sp, #0x160]
    130c:      	stp	q4, q5, [sp, #0x140]
    1310:      	and	x12, x10, #0x7
    1314:      	add	x13, sp, #0x140
    1318:      	ldr	x12, [x13, x12, lsl #3]
    131c:      	addv.8b	b19, v26
    1320:      	sub	x12, x12, x10
    1324:      	add	x11, x11, x12, lsl #2
    1328:      	fmov	w12, s19
    132c:      	movi.2d	v24, #0000000000000000
    1330:      	movi.2d	v18, #0000000000000000
    1334:      	tbnz	w12, #0x0, 0x1580 <ltmp0+0x1580>
    1338:      	tbnz	w12, #0x1, 0x1588 <ltmp0+0x1588>
    133c:      	tbnz	w12, #0x2, 0x1594 <ltmp0+0x1594>
    1340:      	tbnz	w12, #0x3, 0x15a0 <ltmp0+0x15a0>
    1344:      	tbnz	w12, #0x4, 0x15ac <ltmp0+0x15ac>
    1348:      	tbnz	w12, #0x5, 0x15b8 <ltmp0+0x15b8>
    134c:      	tbnz	w12, #0x6, 0x15c4 <ltmp0+0x15c4>
    1350:      	tbz	w12, #0x7, 0x135c <ltmp0+0x135c>
    1354:      	add	x11, x11, #0x1c
    1358:      	ld1.s	{ v18 }[3], [x11]
    135c:      	mov	x11, #0x0               ; =0
    1360:      	fadd	s4, s25, s8
    1364:      	mov	w12, #0x800             ; =2048
    1368:      	movk	w12, #0x4580, lsl #16
    136c:      	fmov	s5, w12
    1370:      	fdiv	s4, s4, s5
    1374:      	add	x12, x19, x14
    1378:      	ldp	q5, q7, [x12]
    137c:      	zip2.8b	v16, v6, v0
    1380:      	ushll.4s	v16, v16, #0x0
    1384:      	shl.4s	v16, v16, #0x1f
    1388:      	cmlt.4s	v16, v16, #0
    138c:      	bit.16b	v7, v18, v16
    1390:      	zip1.8b	v6, v6, v0
    1394:      	ushll.4s	v6, v6, #0x0
    1398:      	shl.4s	v6, v6, #0x1f
    139c:      	cmlt.4s	v6, v6, #0
    13a0:      	bit.16b	v5, v24, v6
    13a4:      	mov	w13, #0xc5ac            ; =50604
    13a8:      	movk	w13, #0x3727, lsl #16
    13ac:      	fmov	s6, w13
    13b0:      	fadd	s4, s4, s6
    13b4:      	fsqrt	s4, s4
    13b8:      	dup.4s	v6, v4[0]
    13bc:      	stp	q5, q7, [x12]
    13c0:      	add	x9, x8, x9
    13c4:      	movi.2d	v25, #0000000000000000
    13c8:      	movi.2d	v26, #0000000000000000
    13cc:      	movi.2d	v27, #0000000000000000
    13d0:      	movi.2d	v28, #0000000000000000
    13d4:      	b	0x13fc <ltmp0+0x13fc>
    13d8:      	add.2d	v4, v25, v23
    13dc:      	add.2d	v26, v26, v21
    13e0:      	add.2d	v27, v27, v22
    13e4:      	add.2d	v28, v28, v20
    13e8:      	fmov	x11, d25
    13ec:      	add	x11, x11, x15
    13f0:      	mov.16b	v25, v4
    13f4:      	cmp	x11, #0x200
    13f8:      	b.ge	0x14cc <ltmp0+0x14cc>
    13fc:      	fmov	w12, s2
    1400:      	lsl	x11, x11, #5
    1404:      	add	x13, x26, x11
    1408:      	ldp	q4, q29, [x13]
    140c:      	and.16b	v4, v1, v4
    1410:      	fdiv.4s	v4, v4, v6
    1414:      	add	x13, x19, x11
    1418:      	ldp	q5, q30, [x13]
    141c:      	and.16b	v5, v1, v5
    1420:      	fmul.4s	v31, v4, v5
    1424:      	add	x11, x9, x11
    1428:      	tbnz	w12, #0x0, 0x1460 <ltmp0+0x1460>
    142c:      	and	w12, w12, #0xff
    1430:      	tbnz	w12, #0x1, 0x146c <ltmp0+0x146c>
    1434:      	tbnz	w12, #0x2, 0x1478 <ltmp0+0x1478>
    1438:      	tbnz	w12, #0x3, 0x1484 <ltmp0+0x1484>
    143c:      	and.16b	v4, v0, v29
    1440:      	fdiv.4s	v4, v4, v6
    1444:      	and.16b	v5, v0, v30
    1448:      	fmul.4s	v29, v4, v5
    144c:      	tbnz	w12, #0x4, 0x14a0 <ltmp0+0x14a0>
    1450:      	tbnz	w12, #0x5, 0x14a8 <ltmp0+0x14a8>
    1454:      	tbnz	w12, #0x6, 0x14b4 <ltmp0+0x14b4>
    1458:      	tbz	w12, #0x7, 0x13d8 <ltmp0+0x13d8>
    145c:      	b	0x14c0 <ltmp0+0x14c0>
    1460:      	str	s31, [x11]
    1464:      	and	w12, w12, #0xff
    1468:      	tbz	w12, #0x1, 0x1434 <ltmp0+0x1434>
    146c:      	add	x13, x11, #0x4
    1470:      	st1.s	{ v31 }[1], [x13]
    1474:      	tbz	w12, #0x2, 0x1438 <ltmp0+0x1438>
    1478:      	add	x13, x11, #0x8
    147c:      	st1.s	{ v31 }[2], [x13]
    1480:      	tbz	w12, #0x3, 0x143c <ltmp0+0x143c>
    1484:      	add	x13, x11, #0xc
    1488:      	st1.s	{ v31 }[3], [x13]
    148c:      	and.16b	v4, v0, v29
    1490:      	fdiv.4s	v4, v4, v6
    1494:      	and.16b	v5, v0, v30
    1498:      	fmul.4s	v29, v4, v5
    149c:      	tbz	w12, #0x4, 0x1450 <ltmp0+0x1450>
    14a0:      	str	s29, [x11, #0x10]
    14a4:      	tbz	w12, #0x5, 0x1454 <ltmp0+0x1454>
    14a8:      	add	x13, x11, #0x14
    14ac:      	st1.s	{ v29 }[1], [x13]
    14b0:      	tbz	w12, #0x6, 0x1458 <ltmp0+0x1458>
    14b4:      	add	x13, x11, #0x18
    14b8:      	st1.s	{ v29 }[2], [x13]
    14bc:      	tbz	w12, #0x7, 0x13d8 <ltmp0+0x13d8>
    14c0:      	add	x11, x11, #0x1c
    14c4:      	st1.s	{ v29 }[3], [x11]
    14c8:      	b	0x13d8 <ltmp0+0x13d8>
    14cc:      	fdiv.4s	v0, v12, v6
    14d0:      	fmul.4s	v0, v0, v24
    14d4:      	ldr	q2, [sp, #0xe0]
    14d8:      	ldp	q4, q5, [sp, #0xb0]
    14dc:      	stp	q2, q4, [sp, #0xf0]
    14e0:      	ldr	q1, [sp, #0xa0]
    14e4:      	stp	q5, q1, [sp, #0x110]
    14e8:      	and	x9, x10, #0x7
    14ec:      	add	x11, sp, #0xf0
    14f0:      	ldr	x9, [x11, x9, lsl #3]
    14f4:      	sub	x9, x9, x10
    14f8:      	add	x8, x8, x9, lsl #2
    14fc:      	fmov	w9, s19
    1500:      	tbnz	w9, #0x0, 0x15d4 <ltmp0+0x15d4>
    1504:      	tbnz	w9, #0x1, 0x15dc <ltmp0+0x15dc>
    1508:      	tbnz	w9, #0x2, 0x15e8 <ltmp0+0x15e8>
    150c:      	tbnz	w9, #0x3, 0x15f4 <ltmp0+0x15f4>
    1510:      	fdiv.4s	v0, v3, v6
    1514:      	fmul.4s	v0, v0, v18
    1518:      	tbnz	w9, #0x4, 0x1608 <ltmp0+0x1608>
    151c:      	tbnz	w9, #0x5, 0x1610 <ltmp0+0x1610>
    1520:      	tbnz	w9, #0x6, 0x161c <ltmp0+0x161c>
    1524:      	tbz	w9, #0x7, 0x6c <ltmp0+0x6c>
    1528:      	b	0x1628 <ltmp0+0x1628>
    152c:      	ldr	s4, [x14]
    1530:      	tbz	w15, #0x1, 0xcac <ltmp0+0xcac>
    1534:      	add	x16, x14, #0x4
    1538:      	ld1.s	{ v4 }[1], [x16]
    153c:      	tbz	w15, #0x2, 0xcb0 <ltmp0+0xcb0>
    1540:      	add	x16, x14, #0x8
    1544:      	ld1.s	{ v4 }[2], [x16]
    1548:      	tbz	w15, #0x3, 0xcb4 <ltmp0+0xcb4>
    154c:      	add	x16, x14, #0xc
    1550:      	ld1.s	{ v4 }[3], [x16]
    1554:      	tbz	w15, #0x4, 0xcb8 <ltmp0+0xcb8>
    1558:      	add	x16, x14, #0x10
    155c:      	ld1.s	{ v3 }[0], [x16]
    1560:      	tbz	w15, #0x5, 0xcbc <ltmp0+0xcbc>
    1564:      	add	x16, x14, #0x14
    1568:      	ld1.s	{ v3 }[1], [x16]
    156c:      	tbz	w15, #0x6, 0xcc0 <ltmp0+0xcc0>
    1570:      	add	x16, x14, #0x18
    1574:      	ld1.s	{ v3 }[2], [x16]
    1578:      	tbnz	w15, #0x7, 0xcc4 <ltmp0+0xcc4>
    157c:      	b	0xccc <ltmp0+0xccc>
    1580:      	ldr	s24, [x11]
    1584:      	tbz	w12, #0x1, 0x133c <ltmp0+0x133c>
    1588:      	add	x13, x11, #0x4
    158c:      	ld1.s	{ v24 }[1], [x13]
    1590:      	tbz	w12, #0x2, 0x1340 <ltmp0+0x1340>
    1594:      	add	x13, x11, #0x8
    1598:      	ld1.s	{ v24 }[2], [x13]
    159c:      	tbz	w12, #0x3, 0x1344 <ltmp0+0x1344>
    15a0:      	add	x13, x11, #0xc
    15a4:      	ld1.s	{ v24 }[3], [x13]
    15a8:      	tbz	w12, #0x4, 0x1348 <ltmp0+0x1348>
    15ac:      	add	x13, x11, #0x10
    15b0:      	ld1.s	{ v18 }[0], [x13]
    15b4:      	tbz	w12, #0x5, 0x134c <ltmp0+0x134c>
    15b8:      	add	x13, x11, #0x14
    15bc:      	ld1.s	{ v18 }[1], [x13]
    15c0:      	tbz	w12, #0x6, 0x1350 <ltmp0+0x1350>
    15c4:      	add	x13, x11, #0x18
    15c8:      	ld1.s	{ v18 }[2], [x13]
    15cc:      	tbnz	w12, #0x7, 0x1354 <ltmp0+0x1354>
    15d0:      	b	0x135c <ltmp0+0x135c>
    15d4:      	str	s0, [x8]
    15d8:      	tbz	w9, #0x1, 0x1508 <ltmp0+0x1508>
    15dc:      	add	x10, x8, #0x4
    15e0:      	st1.s	{ v0 }[1], [x10]
    15e4:      	tbz	w9, #0x2, 0x150c <ltmp0+0x150c>
    15e8:      	add	x10, x8, #0x8
    15ec:      	st1.s	{ v0 }[2], [x10]
    15f0:      	tbz	w9, #0x3, 0x1510 <ltmp0+0x1510>
    15f4:      	add	x10, x8, #0xc
    15f8:      	st1.s	{ v0 }[3], [x10]
    15fc:      	fdiv.4s	v0, v3, v6
    1600:      	fmul.4s	v0, v0, v18
    1604:      	tbz	w9, #0x4, 0x151c <ltmp0+0x151c>
    1608:      	str	s0, [x8, #0x10]
    160c:      	tbz	w9, #0x5, 0x1520 <ltmp0+0x1520>
    1610:      	add	x10, x8, #0x14
    1614:      	st1.s	{ v0 }[1], [x10]
    1618:      	tbz	w9, #0x6, 0x1524 <ltmp0+0x1524>
    161c:      	add	x10, x8, #0x18
    1620:      	st1.s	{ v0 }[2], [x10]
    1624:      	tbz	w9, #0x7, 0x6c <ltmp0+0x6c>
    1628:      	add	x8, x8, #0x1c
    162c:      	st1.s	{ v0 }[3], [x8]
    1630:      	b	0x6c <ltmp0+0x6c>
    1634:      	ldr	x9, [sp, #0x10]
    1638:      	stp	w27, w13, [x9]
    163c:      	str	w12, [x9, #0x8]
    1640:      	mov	w8, #0x18               ; =24
    1644:      	str	w8, [x9, #0x24]
    1648:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
    164c:      	add	sp, sp, #0x380
    1650:      	ldp	x29, x30, [sp, #0x90]
    1654:      	ldp	x20, x19, [sp, #0x80]
    1658:      	ldp	x22, x21, [sp, #0x70]
    165c:      	ldp	x24, x23, [sp, #0x60]
    1660:      	ldp	x26, x25, [sp, #0x50]
    1664:      	ldp	x28, x27, [sp, #0x40]
    1668:      	ldp	d9, d8, [sp, #0x30]
    166c:      	ldp	d11, d10, [sp, #0x20]
    1670:      	ldp	d13, d12, [sp, #0x10]
    1674:      	ldp	d15, d14, [sp], #0xa0
    1678:      	ret


/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/masked_softmax-1024x4097/on/object/tile_xir_w8_37968_1788936540315643_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	sub	sp, sp, #0x90
       4:      	stp	d15, d14, [sp, #0x10]
       8:      	stp	d13, d12, [sp, #0x20]
       c:      	stp	d11, d10, [sp, #0x30]
      10:      	stp	d9, d8, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	mov	x12, #0x0               ; =0
      28:      	ldr	x8, [x1, #0x88]
      2c:      	mov	w9, #0x5088             ; =20616
      30:      	movk	w9, #0x1, lsl #16
      34:      	add	x10, x8, #0x11, lsl #12 ; =0x11000
      38:      	add	x13, x10, #0x68
      3c:      	mov	w10, #0xd068            ; =53352
      40:      	add	x14, x8, x10
      44:      	ldr	x16, [x0]
      48:      	ldr	w10, [x1]
      4c:      	ldr	w11, [x1, #0x24]
      50:      	add	w10, w11, w10, lsl #5
      54:      	lsr	w10, w10, #3
      58:      	mov	w15, #0x4004            ; =16388
      5c:      	umull	x11, w10, w15
      60:      	umaddl	x17, w10, w15, x16
      64:      	fmov	s0, w10
      68:      	mov	w15, #0xc020            ; =49184
      6c:      	ldr	x10, [x0, #0x30]
      70:      	add	x0, x17, x12
      74:      	ldp	q1, q2, [x0]
      78:      	add	x0, x8, x12
      7c:      	stp	q1, q2, [x0]
      80:      	add	x12, x12, #0x20
      84:      	cmp	x12, #0x4, lsl #12      ; =0x4000
      88:      	b.ne	0x70 <ltmp0+0x70>
      8c:      	mov	x17, #0x0               ; =0
      90:      	add	x12, x11, #0x4, lsl #12 ; =0x4000
      94:      	ldr	s1, [x16, x12]
      98:      	mov	w16, #0x4000            ; =16384
      9c:      	str	s1, [x8, x16]
      a0:      	adrp	x16, 0x0 <ltmp0>
      a4:      	ldr	q1, [x16]
      a8:      	adrp	x16, 0x0 <ltmp0>
      ac:      	ldr	q2, [x16]
      b0:      	adrp	x16, 0x0 <ltmp0>
      b4:      	ldr	q3, [x16]
      b8:      	adrp	x16, 0x0 <ltmp0>
      bc:      	ldr	q4, [x16]
      c0:      	mov	w16, #0x1               ; =1
      c4:      	dup.2d	v5, x16
      c8:      	mov	w16, #0x4020            ; =16416
      cc:      	add	x16, x8, x16
      d0:      	movi.2d	v16, #0000000000000000
      d4:      	movi.2d	v6, #0000000000000000
      d8:      	movi.2d	v7, #0000000000000000
      dc:      	movi.2d	v17, #0000000000000000
      e0:      	shl.2d	v18, v16, #0x3
      e4:      	shl.2d	v19, v6, #0x3
      e8:      	shl.2d	v20, v7, #0x3
      ec:      	shl.2d	v21, v17, #0x3
      f0:      	orr.16b	v21, v21, v1
      f4:      	orr.16b	v20, v20, v2
      f8:      	orr.16b	v19, v19, v3
      fc:      	orr.16b	v18, v18, v4
     100:      	add	x17, x16, x17, lsl #6
     104:      	stp	q18, q19, [x17]
     108:      	stp	q20, q21, [x17, #0x20]
     10c:      	add.2d	v7, v7, v5
     110:      	add.2d	v6, v6, v5
     114:      	add.2d	v18, v16, v5
     118:      	add.2d	v17, v17, v5
     11c:      	fmov	x17, d16
     120:      	add	x17, x17, #0x1
     124:      	mov.16b	v16, v18
     128:      	cmp	x17, #0x200
     12c:      	b.lt	0xe0 <ltmp0+0xe0>
     130:      	mov	x17, #0x0               ; =0
     134:      	mov	w0, #0x1000             ; =4096
     138:      	str	x0, [x8, x15]
     13c:      	mov	w0, #0xf001             ; =61441
     140:      	movk	w0, #0xff, lsl #16
     144:      	fmov	s1, w0
     148:      	mov	w0, #0x1001             ; =4097
     14c:      	fmov	s2, w0
     150:      	mov	w0, #0xc060             ; =49248
     154:      	add	x0, x8, x0
     158:      	umull2.2d	v3, v0, v1
     15c:      	umull.2d	v1, v0, v1
     160:      	uzp2.4s	v1, v1, v3
     164:      	ushr.4s	v1, v1, #0x4
     168:      	mls.4s	v0, v1, v2
     16c:      	dup.4s	v0, v0[0]
     170:      	ushll2.2d	v5, v0, #0x0
     174:      	ushll.2d	v6, v0, #0x0
     178:      	movi.2d	v7, #0000000000000000
     17c:      	dup.2d	v0, x0
     180:      	adrp	x0, 0x0 <ltmp0>
     184:      	ldr	q1, [x0]
     188:      	adrp	x0, 0x0 <ltmp0>
     18c:      	ldr	q2, [x0]
     190:      	adrp	x0, 0x0 <ltmp0>
     194:      	ldr	q3, [x0]
     198:      	adrp	x0, 0x0 <ltmp0>
     19c:      	ldr	q4, [x0]
     1a0:      	movi.8b	v16, #0x1
     1a4:      	mov	w0, #0x1                ; =1
     1a8:      	dup.2d	v17, x0
     1ac:      	movi.2d	v18, #0000000000000000
     1b0:      	movi.2d	v19, #0000000000000000
     1b4:      	movi.2d	v20, #0000000000000000
     1b8:      	add	x17, x16, x17, lsl #6
     1bc:      	ldp	q22, q21, [x17, #0x20]
     1c0:      	ldp	q23, q24, [x17]
     1c4:      	add.2d	v25, v20, v4
     1c8:      	add.2d	v26, v18, v2
     1cc:      	add.2d	v26, v26, v0
     1d0:      	add.2d	v27, v7, v1
     1d4:      	add.2d	v27, v27, v0
     1d8:      	cmge.2d	v24, v5, v24
     1dc:      	cmge.2d	v23, v6, v23
     1e0:      	uzp1.4s	v23, v23, v24
     1e4:      	cmge.2d	v22, v6, v22
     1e8:      	cmge.2d	v21, v5, v21
     1ec:      	uzp1.4s	v21, v22, v21
     1f0:      	uzp1.8h	v21, v23, v21
     1f4:      	xtn.8b	v21, v21
     1f8:      	and.8b	v21, v21, v16
     1fc:      	mov.d	x17, v27[1]
     200:      	fmov	x0, d27
     204:      	str	b21, [x0]
     208:      	st1.b	{ v21 }[1], [x17]
     20c:      	mov.d	x17, v26[1]
     210:      	add.2d	v22, v19, v3
     214:      	fmov	x0, d26
     218:      	st1.b	{ v21 }[2], [x0]
     21c:      	st1.b	{ v21 }[3], [x17]
     220:      	add.2d	v22, v22, v0
     224:      	mov.d	x17, v22[1]
     228:      	fmov	x0, d22
     22c:      	st1.b	{ v21 }[4], [x0]
     230:      	add.2d	v22, v25, v0
     234:      	st1.b	{ v21 }[5], [x17]
     238:      	mov.d	x17, v22[1]
     23c:      	fmov	x0, d22
     240:      	st1.b	{ v21 }[6], [x0]
     244:      	st1.b	{ v21 }[7], [x17]
     248:      	add.2d	v19, v19, v17
     24c:      	add.2d	v18, v18, v17
     250:      	add.2d	v21, v7, v17
     254:      	add.2d	v20, v20, v17
     258:      	fmov	x17, d7
     25c:      	add	x17, x17, #0x1
     260:      	mov.16b	v7, v21
     264:      	cmp	x17, #0x200
     268:      	b.lt	0x1b8 <ltmp0+0x1b8>
     26c:      	mov	x16, #0x0               ; =0
     270:      	ldr	d7, [x8, x15]
     274:      	adrp	x15, 0x0 <ltmp0>
     278:      	ldr	q5, [x15]
     27c:      	add.2d	v5, v0, v5
     280:      	cmge.2d	v6, v6, v7
     284:      	xtn.2s	v6, v6
     288:      	uzp1.4h	v6, v6, v0
     28c:      	uzp1.8b	v6, v6, v0
     290:      	movi.8b	v7, #0x1
     294:      	and.8b	v6, v6, v7
     298:      	fmov	x15, d5
     29c:      	str	b6, [x15]
     2a0:      	mov	w15, #0xf2ca            ; =62154
     2a4:      	movk	w15, #0xf149, lsl #16
     2a8:      	dup.4s	v6, w15
     2ac:      	mov	w15, #0x1               ; =1
     2b0:      	dup.2d	v7, x15
     2b4:      	movi.2d	v18, #0000000000000000
     2b8:      	movi.2d	v16, #0000000000000000
     2bc:      	movi.2d	v17, #0000000000000000
     2c0:      	movi.2d	v19, #0000000000000000
     2c4:      	add.2d	v20, v19, v4
     2c8:      	add.2d	v21, v17, v3
     2cc:      	add.2d	v20, v20, v0
     2d0:      	add.2d	v22, v16, v2
     2d4:      	add.2d	v23, v18, v1
     2d8:      	add.2d	v23, v23, v0
     2dc:      	mov.d	x15, v23[1]
     2e0:      	add.2d	v21, v21, v0
     2e4:      	add.2d	v22, v22, v0
     2e8:      	fmov	x17, d23
     2ec:      	mov.d	x0, v22[1]
     2f0:      	mov.d	x1, v21[1]
     2f4:      	fmov	x2, d22
     2f8:      	ldr	b22, [x17]
     2fc:      	ld1.b	{ v22 }[1], [x15]
     300:      	mov.d	x15, v20[1]
     304:      	fmov	x17, d21
     308:      	ld1.b	{ v22 }[2], [x2]
     30c:      	ld1.b	{ v22 }[3], [x0]
     310:      	fmov	x0, d20
     314:      	ld1.b	{ v22 }[4], [x17]
     318:      	ld1.b	{ v22 }[5], [x1]
     31c:      	ld1.b	{ v22 }[6], [x0]
     320:      	ld1.b	{ v22 }[7], [x15]
     324:      	cmeq.8b	v20, v22, #0
     328:      	sshll.8h	v20, v20, #0x0
     32c:      	sshll2.4s	v21, v20, #0x0
     330:      	sshll.4s	v20, v20, #0x0
     334:      	lsl	x15, x16, #5
     338:      	add	x16, x8, x15
     33c:      	ldp	q23, q22, [x16]
     340:      	bsl.16b	v20, v6, v23
     344:      	bsl.16b	v21, v6, v22
     348:      	add	x15, x14, x15
     34c:      	add.2d	v17, v17, v7
     350:      	add.2d	v16, v16, v7
     354:      	stp	q20, q21, [x15]
     358:      	add.2d	v20, v18, v7
     35c:      	add.2d	v19, v19, v7
     360:      	fmov	x15, d18
     364:      	add	x16, x15, #0x1
     368:      	mov.16b	v18, v20
     36c:      	cmp	x16, #0x200
     370:      	b.lt	0x2c4 <ltmp0+0x2c4>
     374:      	mov	x15, #0x0               ; =0
     378:      	str	q5, [sp]
     37c:      	fmov	x16, d5
     380:      	ldr	b6, [x16]
     384:      	cmeq.8b	v6, v6, #0
     388:      	sshll.8h	v6, v6, #0x0
     38c:      	sshll.4s	v6, v6, #0x0
     390:      	ldr	q7, [x8, #0x4000]
     394:      	mov	w16, #0xf2ca            ; =62154
     398:      	movk	w16, #0xf149, lsl #16
     39c:      	fmov	s16, w16
     3a0:      	bsl.16b	v6, v16, v7
     3a4:      	ldr	q7, [x13]
     3a8:      	mov.s	v7[0], v6[0]
     3ac:      	str	q7, [x13]
     3b0:      	ldp	q7, q16, [x14]
     3b4:      	ldp	q20, q21, [x14, #0x20]
     3b8:      	ldp	q22, q17, [x14, #0x40]
     3bc:      	ldp	q18, q19, [x14, #0x60]
     3c0:      	mov	w16, #0xd128            ; =53544
     3c4:      	add	x16, x8, x16
     3c8:      	add	x17, x16, x15, lsl #5
     3cc:      	ldp	q23, q24, [x17, #-0x40]
     3d0:      	fmaxnm.4s	v16, v16, v24
     3d4:      	fmaxnm.4s	v7, v7, v23
     3d8:      	ldp	q23, q24, [x17, #-0x20]
     3dc:      	fmaxnm.4s	v21, v21, v24
     3e0:      	fmaxnm.4s	v20, v20, v23
     3e4:      	ldp	q23, q24, [x17]
     3e8:      	fmaxnm.4s	v17, v17, v24
     3ec:      	fmaxnm.4s	v22, v22, v23
     3f0:      	ldp	q23, q24, [x17, #0x20]
     3f4:      	fmaxnm.4s	v19, v19, v24
     3f8:      	fmaxnm.4s	v18, v18, v23
     3fc:      	add	x15, x15, #0x4
     400:      	cmp	x15, #0x1fc
     404:      	b.lo	0x3c8 <ltmp0+0x3c8>
     408:      	mov	x6, #0x0                ; =0
     40c:      	add	x15, x13, #0x20
     410:      	movi.2d	v23, #0000000000000000
     414:      	mov.s	v23[0], v6[0]
     418:      	fmaxnm.4s	v6, v7, v23
     41c:      	mov.s	v7[0], v6[0]
     420:      	movi.2d	v6, #0000000000000000
     424:      	fmaxnm.4s	v16, v16, v21
     428:      	fmaxnm.4s	v7, v7, v20
     42c:      	fmaxnm.4s	v7, v7, v22
     430:      	fmaxnm.4s	v16, v16, v17
     434:      	fmaxnm.4s	v16, v16, v19
     438:      	fmaxnm.4s	v7, v7, v18
     43c:      	rev64.4s	v17, v7
     440:      	rev64.4s	v18, v16
     444:      	fmaxnm.4s	v16, v16, v18
     448:      	fmaxnm.4s	v7, v7, v17
     44c:      	ext.16b	v17, v7, v7, #0x8
     450:      	ext.16b	v18, v16, v16, #0x8
     454:      	fmaxnm.4s	v16, v16, v18
     458:      	fmaxnm.4s	v7, v7, v17
     45c:      	fmaxnm.4s	v7, v7, v16
     460:      	mov	w16, #-0x800000         ; =-8388608
     464:      	fmov	s16, w16
     468:      	fmaxnm	s7, s7, s16
     46c:      	dup.4s	v16, v7[0]
     470:      	mov	w16, #-0x3d300000       ; =-1026555904
     474:      	dup.4s	v17, w16
     478:      	mov	w16, #0x42c80000        ; =1120403456
     47c:      	dup.4s	v18, w16
     480:      	mov	w16, #0xaa3b            ; =43579
     484:      	movk	w16, #0x3fb8, lsl #16
     488:      	dup.4s	v19, w16
     48c:      	movi.4s	v20, #0x4b, lsl #24
     490:      	mvni.4s	v21, #0x80, lsl #24
     494:      	mov	w16, #0x7200            ; =29184
     498:      	movk	w16, #0xbf31, lsl #16
     49c:      	mov	w17, #0xbe8e            ; =48782
     4a0:      	movk	w17, #0xb5bf, lsl #16
     4a4:      	mov	w0, #0x2bda             ; =11226
     4a8:      	movk	w0, #0x3950, lsl #16
     4ac:      	mov	w1, #0x96c9             ; =38601
     4b0:      	movk	w1, #0x3ab6, lsl #16
     4b4:      	mov	w2, #0x88a6             ; =34982
     4b8:      	movk	w2, #0x3c08, lsl #16
     4bc:      	mov	w3, #0xaa7a             ; =43642
     4c0:      	movk	w3, #0x3d2a, lsl #16
     4c4:      	mov	w4, #0xaaab             ; =43691
     4c8:      	movk	w4, #0x3e2a, lsl #16
     4cc:      	movi.4s	v22, #0x3f, lsl #24
     4d0:      	mvni.4s	v23, #0x7f, msl #16
     4d4:      	fneg.4s	v23, v23
     4d8:      	mvni.4s	v24, #0x3f, msl #16
     4dc:      	fneg.4s	v24, v24
     4e0:      	mov	w5, #0x1                ; =1
     4e4:      	movi.2d	v25, #0000000000000000
     4e8:      	movi.2d	v26, #0000000000000000
     4ec:      	movi.2d	v27, #0000000000000000
     4f0:      	add.2d	v28, v27, v4
     4f4:      	add.2d	v29, v26, v3
     4f8:      	add.2d	v28, v28, v0
     4fc:      	add.2d	v29, v29, v0
     500:      	add.2d	v30, v25, v2
     504:      	add.2d	v31, v6, v1
     508:      	add.2d	v31, v31, v0
     50c:      	mov.d	x7, v31[1]
     510:      	add.2d	v30, v30, v0
     514:      	fmov	x19, d31
     518:      	mov.d	x20, v30[1]
     51c:      	mov.d	x21, v29[1]
     520:      	fmov	x22, d30
     524:      	fmov	x23, d29
     528:      	mov.d	x24, v28[1]
     52c:      	fmov	x25, d28
     530:      	ldr	b28, [x19]
     534:      	ld1.b	{ v28 }[1], [x7]
     538:      	ld1.b	{ v28 }[2], [x22]
     53c:      	ld1.b	{ v28 }[3], [x20]
     540:      	ld1.b	{ v28 }[4], [x23]
     544:      	lsl	x6, x6, #5
     548:      	add	x7, x14, x6
     54c:      	ld1.b	{ v28 }[5], [x21]
     550:      	ldp	q30, q29, [x7]
     554:      	fsub.4s	v29, v29, v16
     558:      	fsub.4s	v30, v30, v16
     55c:      	ld1.b	{ v28 }[6], [x25]
     560:      	fcmge.4s	v31, v30, v17
     564:      	fcmge.4s	v8, v29, v17
     568:      	fcmge.4s	v9, v18, v30
     56c:      	fcmge.4s	v10, v18, v29
     570:      	ld1.b	{ v28 }[7], [x24]
     574:      	and.16b	v8, v8, v10
     578:      	and.16b	v31, v31, v9
     57c:      	and.16b	v10, v31, v30
     580:      	and.16b	v11, v8, v29
     584:      	fmul.4s	v31, v11, v19
     588:      	cmeq.8b	v28, v28, #0
     58c:      	fmul.4s	v8, v10, v19
     590:      	mov.16b	v9, v21
     594:      	bsl.16b	v9, v20, v8
     598:      	mov.16b	v12, v21
     59c:      	bsl.16b	v12, v20, v31
     5a0:      	fadd.4s	v31, v31, v12
     5a4:      	fadd.4s	v8, v8, v9
     5a8:      	sshll.8h	v28, v28, #0x0
     5ac:      	fsub.4s	v9, v8, v9
     5b0:      	fsub.4s	v31, v31, v12
     5b4:      	fcvtzs.4s	v8, v31
     5b8:      	fcvtzs.4s	v9, v9
     5bc:      	scvtf.4s	v12, v9
     5c0:      	sshll2.4s	v31, v28, #0x0
     5c4:      	scvtf.4s	v13, v8
     5c8:      	dup.4s	v14, w16
     5cc:      	fmul.4s	v15, v13, v14
     5d0:      	fmul.4s	v14, v12, v14
     5d4:      	fadd.4s	v10, v10, v14
     5d8:      	fadd.4s	v11, v11, v15
     5dc:      	dup.4s	v14, w17
     5e0:      	fmul.4s	v12, v12, v14
     5e4:      	fmul.4s	v13, v13, v14
     5e8:      	fadd.4s	v11, v11, v13
     5ec:      	fadd.4s	v10, v10, v12
     5f0:      	dup.4s	v12, w0
     5f4:      	dup.4s	v13, w1
     5f8:      	fmul.4s	v14, v10, v12
     5fc:      	fmul.4s	v12, v11, v12
     600:      	fadd.4s	v12, v12, v13
     604:      	fadd.4s	v13, v14, v13
     608:      	dup.4s	v14, w2
     60c:      	fmul.4s	v13, v10, v13
     610:      	fmul.4s	v12, v11, v12
     614:      	fadd.4s	v12, v12, v14
     618:      	fadd.4s	v13, v13, v14
     61c:      	dup.4s	v14, w3
     620:      	fmul.4s	v13, v10, v13
     624:      	fmul.4s	v12, v11, v12
     628:      	fadd.4s	v12, v12, v14
     62c:      	fadd.4s	v13, v13, v14
     630:      	dup.4s	v14, w4
     634:      	fmul.4s	v13, v10, v13
     638:      	fmul.4s	v12, v11, v12
     63c:      	fadd.4s	v12, v12, v14
     640:      	fadd.4s	v13, v13, v14
     644:      	fmul.4s	v13, v10, v13
     648:      	fmul.4s	v12, v11, v12
     64c:      	fadd.4s	v12, v12, v22
     650:      	fadd.4s	v13, v13, v22
     654:      	fmul.4s	v14, v11, v11
     658:      	fmul.4s	v15, v10, v10
     65c:      	fmul.4s	v13, v15, v13
     660:      	fmul.4s	v12, v14, v12
     664:      	sshll.4s	v14, v28, #0x0
     668:      	fadd.4s	v11, v11, v12
     66c:      	fadd.4s	v10, v10, v13
     670:      	fmov.4s	v28, #1.00000000
     674:      	fadd.4s	v10, v10, v28
     678:      	sshr.4s	v12, v9, #0x1
     67c:      	fadd.4s	v11, v11, v28
     680:      	sshr.4s	v13, v8, #0x1
     684:      	shl.4s	v15, v13, #0x17
     688:      	shl.4s	v5, v12, #0x17
     68c:      	add.4s	v5, v5, v28
     690:      	add.4s	v15, v15, v28
     694:      	fmul.4s	v11, v11, v15
     698:      	sub.4s	v8, v8, v13
     69c:      	sub.4s	v9, v9, v12
     6a0:      	shl.4s	v9, v9, #0x17
     6a4:      	shl.4s	v8, v8, #0x17
     6a8:      	add.4s	v8, v8, v28
     6ac:      	fmul.4s	v5, v10, v5
     6b0:      	add.4s	v9, v9, v28
     6b4:      	fmul.4s	v5, v5, v9
     6b8:      	fmul.4s	v8, v11, v8
     6bc:      	fcmgt.4s	v9, v17, v29
     6c0:      	fcmgt.4s	v10, v17, v30
     6c4:      	bic.16b	v8, v8, v9
     6c8:      	bic.16b	v5, v5, v10
     6cc:      	fcmgt.4s	v9, v29, v18
     6d0:      	fcmgt.4s	v10, v30, v18
     6d4:      	bit.16b	v5, v23, v10
     6d8:      	fcmeq.4s	v30, v30, v30
     6dc:      	bit.16b	v8, v23, v9
     6e0:      	fcmeq.4s	v29, v29, v29
     6e4:      	bsl.16b	v29, v8, v24
     6e8:      	bif.16b	v5, v24, v30
     6ec:      	bic.16b	v5, v5, v14
     6f0:      	add	x6, x15, x6
     6f4:      	bic.16b	v29, v29, v31
     6f8:      	dup.2d	v30, x5
     6fc:      	add.2d	v26, v26, v30
     700:      	add.2d	v25, v25, v30
     704:      	stp	q5, q29, [x6]
     708:      	add.2d	v5, v6, v30
     70c:      	add.2d	v27, v27, v30
     710:      	fmov	x6, d6
     714:      	add	x6, x6, #0x1
     718:      	mov.16b	v6, v5
     71c:      	cmp	x6, #0x200
     720:      	b.lt	0x4f0 <ltmp0+0x4f0>
     724:      	mov	x14, #0x0               ; =0
     728:      	ldr	q0, [sp]
     72c:      	fmov	x16, d0
     730:      	ldr	q0, [x13]
     734:      	fsub.4s	v1, v0, v7
     738:      	movi.2d	v0, #0000000000000000
     73c:      	mov.s	v0[0], v1[0]
     740:      	mov	w17, #-0x3d300000       ; =-1026555904
     744:      	dup.4s	v1, w17
     748:      	fcmge.4s	v3, v0, v1
     74c:      	mov	w17, #0x42c80000        ; =1120403456
     750:      	dup.4s	v2, w17
     754:      	fcmge.4s	v4, v2, v0
     758:      	and.16b	v3, v3, v4
     75c:      	and.16b	v3, v3, v0
     760:      	mov	w17, #0xaa3b            ; =43579
     764:      	movk	w17, #0x3fb8, lsl #16
     768:      	dup.4s	v4, w17
     76c:      	fmul.4s	v4, v3, v4
     770:      	movi.4s	v5, #0x4b, lsl #24
     774:      	mvni.4s	v6, #0x80, lsl #24
     778:      	bif.16b	v5, v4, v6
     77c:      	fadd.4s	v4, v4, v5
     780:      	fsub.4s	v4, v4, v5
     784:      	fcvtzs.4s	v4, v4
     788:      	scvtf.4s	v5, v4
     78c:      	mov	w17, #0x7200            ; =29184
     790:      	movk	w17, #0xbf31, lsl #16
     794:      	dup.4s	v6, w17
     798:      	fmul.4s	v6, v5, v6
     79c:      	mov	w17, #0xbe8e            ; =48782
     7a0:      	movk	w17, #0xb5bf, lsl #16
     7a4:      	dup.4s	v7, w17
     7a8:      	fadd.4s	v3, v3, v6
     7ac:      	fmul.4s	v5, v5, v7
     7b0:      	fadd.4s	v3, v3, v5
     7b4:      	mov	w17, #0x2bda            ; =11226
     7b8:      	movk	w17, #0x3950, lsl #16
     7bc:      	dup.4s	v5, w17
     7c0:      	fmul.4s	v5, v3, v5
     7c4:      	mov	w17, #0x96c9            ; =38601
     7c8:      	movk	w17, #0x3ab6, lsl #16
     7cc:      	dup.4s	v6, w17
     7d0:      	fadd.4s	v5, v5, v6
     7d4:      	fmul.4s	v5, v3, v5
     7d8:      	mov	w17, #0x88a6            ; =34982
     7dc:      	movk	w17, #0x3c08, lsl #16
     7e0:      	dup.4s	v6, w17
     7e4:      	mov	w17, #0xaa7a            ; =43642
     7e8:      	movk	w17, #0x3d2a, lsl #16
     7ec:      	dup.4s	v7, w17
     7f0:      	fadd.4s	v5, v5, v6
     7f4:      	mov	w17, #0xaaab            ; =43691
     7f8:      	movk	w17, #0x3e2a, lsl #16
     7fc:      	dup.4s	v6, w17
     800:      	fmul.4s	v5, v3, v5
     804:      	fadd.4s	v5, v5, v7
     808:      	ldr	b7, [x16]
     80c:      	cmeq.8b	v7, v7, #0
     810:      	sshll.8h	v7, v7, #0x0
     814:      	sshll.4s	v7, v7, #0x0
     818:      	fmul.4s	v5, v3, v5
     81c:      	fadd.4s	v5, v5, v6
     820:      	fmul.4s	v5, v3, v5
     824:      	movi.4s	v6, #0x3f, lsl #24
     828:      	fadd.4s	v5, v5, v6
     82c:      	fmul.4s	v6, v3, v3
     830:      	fmul.4s	v5, v6, v5
     834:      	fadd.4s	v3, v3, v5
     838:      	fadd.4s	v3, v3, v28
     83c:      	sshr.4s	v5, v4, #0x1
     840:      	shl.4s	v6, v5, #0x17
     844:      	add.4s	v6, v6, v28
     848:      	fmul.4s	v3, v3, v6
     84c:      	sub.4s	v4, v4, v5
     850:      	shl.4s	v4, v4, #0x17
     854:      	add.4s	v4, v4, v28
     858:      	fmul.4s	v3, v3, v4
     85c:      	fcmgt.4s	v1, v1, v0
     860:      	bic.16b	v1, v3, v1
     864:      	fcmgt.4s	v2, v0, v2
     868:      	mvni.4s	v3, #0x7f, msl #16
     86c:      	fneg.4s	v3, v3
     870:      	bit.16b	v1, v3, v2
     874:      	fcmeq.4s	v0, v0, v0
     878:      	mvni.4s	v2, #0x3f, msl #16
     87c:      	fneg.4s	v2, v2
     880:      	bsl.16b	v0, v1, v2
     884:      	bic.16b	v1, v0, v7
     888:      	ldr	q0, [x8, x9]
     88c:      	mov.s	v0[0], v1[0]
     890:      	str	q0, [x8, x9]
     894:      	ldp	q1, q2, [x13, #0x20]
     898:      	ldp	q6, q7, [x13, #0x40]
     89c:      	ldp	q16, q3, [x13, #0x60]
     8a0:      	ldp	q4, q5, [x13, #0x80]
     8a4:      	add	x13, x8, #0x11, lsl #12 ; =0x11000
     8a8:      	add	x13, x13, #0x148
     8ac:      	add	x16, x13, x14, lsl #5
     8b0:      	ldp	q17, q18, [x16, #-0x40]
     8b4:      	fadd.4s	v2, v2, v18
     8b8:      	fadd.4s	v1, v1, v17
     8bc:      	ldp	q17, q18, [x16, #-0x20]
     8c0:      	fadd.4s	v7, v7, v18
     8c4:      	fadd.4s	v6, v6, v17
     8c8:      	ldp	q17, q18, [x16]
     8cc:      	fadd.4s	v3, v3, v18
     8d0:      	fadd.4s	v16, v16, v17
     8d4:      	ldp	q17, q18, [x16, #0x20]
     8d8:      	fadd.4s	v5, v5, v18
     8dc:      	fadd.4s	v4, v4, v17
     8e0:      	add	x14, x14, #0x4
     8e4:      	cmp	x14, #0x1fc
     8e8:      	b.lo	0x8ac <ltmp0+0x8ac>
     8ec:      	mov	x13, #0x0               ; =0
     8f0:      	fadd.4s	v0, v0, v1
     8f4:      	mov.s	v1[0], v0[0]
     8f8:      	fadd.4s	v0, v7, v2
     8fc:      	fadd.4s	v1, v6, v1
     900:      	fadd.4s	v1, v16, v1
     904:      	fadd.4s	v0, v3, v0
     908:      	fadd.4s	v0, v5, v0
     90c:      	fadd.4s	v1, v4, v1
     910:      	rev64.4s	v2, v1
     914:      	rev64.4s	v3, v0
     918:      	fadd.4s	v0, v0, v3
     91c:      	fadd.4s	v1, v1, v2
     920:      	dup.4s	v2, v1[2]
     924:      	dup.4s	v3, v0[2]
     928:      	fadd.4s	v0, v0, v3
     92c:      	fadd.4s	v1, v1, v2
     930:      	fadd.4s	v0, v1, v0
     934:      	movi	d1, #0000000000000000
     938:      	fadd	s0, s0, s1
     93c:      	dup.4s	v1, v0[0]
     940:      	add	x11, x10, x11
     944:      	add	x14, x15, x13
     948:      	ldp	q3, q2, [x14]
     94c:      	fdiv.4s	v3, v3, v1
     950:      	fdiv.4s	v2, v2, v1
     954:      	add	x14, x11, x13
     958:      	stp	q3, q2, [x14]
     95c:      	add	x13, x13, #0x20
     960:      	cmp	x13, #0x4, lsl #12      ; =0x4000
     964:      	b.ne	0x944 <ltmp0+0x944>
     968:      	ldr	q1, [x8, x9]
     96c:      	fdiv.4s	v0, v1, v0
     970:      	str	s0, [x10, x12]
     974:      	ldp	x20, x19, [sp, #0x80]
     978:      	ldp	x22, x21, [sp, #0x70]
     97c:      	ldp	x24, x23, [sp, #0x60]
     980:      	ldp	x26, x25, [sp, #0x50]
     984:      	ldp	d9, d8, [sp, #0x40]
     988:      	ldp	d11, d10, [sp, #0x30]
     98c:      	ldp	d13, d12, [sp, #0x20]
     990:      	ldp	d15, d14, [sp, #0x10]
     994:      	add	sp, sp, #0x90
     998:      	ret

000000000000099c <_llm_rows.packet_batch.blocks>:
     99c:      	cbz	w3, 0x29d4 <_llm_rows.packet_batch.blocks+0x2038>
     9a0:      	stp	d15, d14, [sp, #-0xa0]!
     9a4:      	stp	d13, d12, [sp, #0x10]
     9a8:      	stp	d11, d10, [sp, #0x20]
     9ac:      	stp	d9, d8, [sp, #0x30]
     9b0:      	stp	x28, x27, [sp, #0x40]
     9b4:      	stp	x26, x25, [sp, #0x50]
     9b8:      	stp	x24, x23, [sp, #0x60]
     9bc:      	stp	x22, x21, [sp, #0x70]
     9c0:      	stp	x20, x19, [sp, #0x80]
     9c4:      	stp	x29, x30, [sp, #0x90]
     9c8:      	sub	sp, sp, #0x920
     9cc:      	mov	x21, x3
     9d0:      	mov	x20, x2
     9d4:      	mov	x22, x0
     9d8:      	mov	w27, #0x0               ; =0
     9dc:      	ldp	w23, w8, [x2, #0x2c]
     9e0:      	str	w8, [sp, #0x21c]
     9e4:      	adrp	x8, 0x0 <ltmp0>
     9e8:      	ldr	q0, [x8]
     9ec:      	str	q0, [sp, #0x10]
     9f0:      	adrp	x8, 0x0 <ltmp0>
     9f4:      	ldr	q0, [x8]
     9f8:      	str	q0, [sp, #0x1c0]
     9fc:      	adrp	x8, 0x0 <ltmp0>
     a00:      	ldr	q0, [x8]
     a04:      	str	q0, [sp, #0x1b0]
     a08:      	movi.8b	v10, #0x1
     a0c:      	mvni.4s	v0, #0x7f, msl #16
     a10:      	fneg.4s	v1, v0
     a14:      	mvni.4s	v0, #0x3f, msl #16
     a18:      	fneg.4s	v0, v0
     a1c:      	stp	q0, q1, [sp, #0x2a0]
     a20:      	ldp	w19, w11, [x2]
     a24:      	ldp	w26, w28, [x2, #0x8]
     a28:      	mov	w24, #0x4               ; =4
     a2c:      	str	w3, [sp, #0x2c]
     a30:      	str	x0, [sp, #0x20]
     a34:      	str	w23, [sp, #0x1ac]
     a38:      	str	x28, [sp, #0x1a0]
     a3c:      	str	x2, [sp, #0x8]
     a40:      	b	0xa8c <_llm_rows.packet_batch.blocks+0xf0>
     a44:      	mov	w8, #0x18               ; =24
     a48:      	str	w8, [x20, #0x24]
     a4c:      	ldr	w23, [sp, #0x1ac]
     a50:      	ldr	x28, [sp, #0x1a0]
     a54:      	add	w8, w19, #0x1
     a58:      	cmp	w8, w23
     a5c:      	cset	w8, eq
     a60:      	csinc	w19, wzr, w19, eq
     a64:      	cinc	w9, w11, eq
     a68:      	ldr	w10, [sp, #0x21c]
     a6c:      	cmp	w9, w10
     a70:      	cset	w10, eq
     a74:      	ands	w8, w8, w10
     a78:      	csel	w11, wzr, w9, ne
     a7c:      	add	w26, w26, w8
     a80:      	add	w27, w27, #0x1
     a84:      	cmp	w27, w21
     a88:      	b.eq	0x29a8 <_llm_rows.packet_batch.blocks+0x200c>
     a8c:      	ubfiz	x8, x19, #5, #32
     a90:      	cmp	x8, x28
     a94:      	csel	x9, x8, xzr, ls
     a98:      	subs	x10, x28, x9
     a9c:      	cmp	x10, #0x20
     aa0:      	mov	w12, #0x20              ; =32
     aa4:      	csel	x10, x10, x12, lo
     aa8:      	cmp	x28, x9
     aac:      	stp	w19, w11, [x20]
     ab0:      	str	w26, [x20, #0x8]
     ab4:      	str	wzr, [x20, #0x24]
     ab8:      	ccmp	x8, x28, #0x2, hi
     abc:      	csel	x25, x10, xzr, ls
     ac0:      	cmp	x25, #0x20
     ac4:      	b.lo	0xb1c <_llm_rows.packet_batch.blocks+0x180>
     ac8:      	mov	x0, x22
     acc:      	mov	x1, x20
     ad0:      	mov	x25, x11
     ad4:      	bl	0xad4 <_llm_rows.packet_batch.blocks+0x138>
     ad8:      	mov	w8, #0x8                ; =8
     adc:      	str	w8, [x20, #0x24]
     ae0:      	mov	x0, x22
     ae4:      	mov	x1, x20
     ae8:      	bl	0xae8 <_llm_rows.packet_batch.blocks+0x14c>
     aec:      	mov	w8, #0x10               ; =16
     af0:      	str	w8, [x20, #0x24]
     af4:      	mov	x0, x22
     af8:      	mov	x1, x20
     afc:      	bl	0xafc <_llm_rows.packet_batch.blocks+0x160>
     b00:      	mov	w8, #0x18               ; =24
     b04:      	str	w8, [x20, #0x24]
     b08:      	mov	x0, x22
     b0c:      	mov	x1, x20
     b10:      	bl	0xb10 <_llm_rows.packet_batch.blocks+0x174>
     b14:      	mov	x11, x25
     b18:      	b	0xa54 <_llm_rows.packet_batch.blocks+0xb8>
     b1c:      	lsr	x23, x25, #3
     b20:      	cmp	x25, #0x8
     b24:      	b.lo	0xb80 <_llm_rows.packet_batch.blocks+0x1e4>
     b28:      	str	wzr, [x20, #0x24]
     b2c:      	mov	x0, x22
     b30:      	mov	x1, x20
     b34:      	mov	x28, x11
     b38:      	bl	0xb38 <_llm_rows.packet_batch.blocks+0x19c>
     b3c:      	mov	x11, x28
     b40:      	cmp	x23, #0x1
     b44:      	b.eq	0xb80 <_llm_rows.packet_batch.blocks+0x1e4>
     b48:      	mov	w8, #0x8                ; =8
     b4c:      	str	w8, [x20, #0x24]
     b50:      	mov	x0, x22
     b54:      	mov	x1, x20
     b58:      	bl	0xb58 <_llm_rows.packet_batch.blocks+0x1bc>
     b5c:      	mov	x11, x28
     b60:      	cmp	x23, #0x2
     b64:      	b.eq	0xb80 <_llm_rows.packet_batch.blocks+0x1e4>
     b68:      	mov	w8, #0x10               ; =16
     b6c:      	str	w8, [x20, #0x24]
     b70:      	mov	x0, x22
     b74:      	mov	x1, x20
     b78:      	bl	0xb78 <_llm_rows.packet_batch.blocks+0x1dc>
     b7c:      	mov	x11, x28
     b80:      	and	w8, w25, #0x7
     b84:      	cbz	w8, 0xa44 <_llm_rows.packet_batch.blocks+0xa8>
     b88:      	dup.4s	v5, w8
     b8c:      	ldp	q0, q1, [sp, #0x1b0]
     b90:      	cmhi.4s	v0, v5, v0
     b94:      	cmhi.4s	v1, v5, v1
     b98:      	uzp1.8h	v3, v1, v0
     b9c:      	umaxv.8h	h2, v3
     ba0:      	fmov	w8, s2
     ba4:      	tbz	w8, #0x0, 0xa44 <_llm_rows.packet_batch.blocks+0xa8>
     ba8:      	mov	x28, x26
     bac:      	str	w11, [sp, #0x198]
     bb0:      	mov	x10, #0x0               ; =0
     bb4:      	ldr	x17, [x20, #0x88]
     bb8:      	mov	w8, #0x1088             ; =4232
     bbc:      	movk	w8, #0x1, lsl #16
     bc0:      	add	x9, x17, x8
     bc4:      	mov	w8, #0xd068             ; =53352
     bc8:      	add	x15, x17, x8
     bcc:      	mov	w8, #0x4020             ; =16416
     bd0:      	add	x8, x17, x8
     bd4:      	mov	w11, #0xc060            ; =49248
     bd8:      	add	x11, x17, x11
     bdc:      	dup.2d	v6, x11
     be0:      	ldr	x12, [x22]
     be4:      	ldr	x11, [x22, #0x30]
     be8:      	str	x11, [sp, #0x188]
     bec:      	ldr	q2, [sp, #0x10]
     bf0:      	str	q3, [sp, #0x1d0]
     bf4:      	and.16b	v2, v3, v2
     bf8:      	addv.8h	h23, v2
     bfc:      	fmov	w11, s23
     c00:      	and	w11, w11, #0xff
     c04:      	str	w11, [sp, #0x120]
     c08:      	xtn.4h	v2, v1
     c0c:      	uzp1.8b	v3, v2, v0
     c10:      	ubfiz	w11, w19, #2, #27
     c14:      	orr	w13, w11, w23
     c18:      	dup.4s	v4, w13
     c1c:      	and.16b	v7, v1, v4
     c20:      	and.16b	v24, v0, v4
     c24:      	ushll2.2d	v4, v24, #0x0
     c28:      	ushll2.2d	v16, v7, #0x0
     c2c:      	ushll.2d	v17, v24, #0x0
     c30:      	umov.b	w26, v3[0]
     c34:      	ushll.2d	v3, v7, #0x0
     c38:      	mov	w14, #0x4004            ; =16388
     c3c:      	umull	x13, w13, w14
     c40:      	tst	w26, #0x1
     c44:      	csel	x13, x13, xzr, ne
     c48:      	str	x13, [sp, #0x180]
     c4c:      	add	x13, x12, x13
     c50:      	fmov	w14, s23
     c54:      	adrp	x2, 0x0 <ltmp0>
     c58:      	adrp	x3, 0x0 <ltmp0>
     c5c:      	adrp	x4, 0x0 <ltmp0>
     c60:      	adrp	x5, 0x0 <ltmp0>
     c64:      	mov	w23, #0xf2ca            ; =62154
     c68:      	movk	w23, #0xf149, lsl #16
     c6c:      	b	0xc90 <_llm_rows.packet_batch.blocks+0x2f4>
     c70:      	add	x16, x17, x10
     c74:      	ldp	q20, q21, [x16]
     c78:      	bif.16b	v19, v21, v0
     c7c:      	bif.16b	v18, v20, v1
     c80:      	stp	q18, q19, [x16]
     c84:      	add	x10, x10, #0x20
     c88:      	cmp	x10, #0x4, lsl #12      ; =0x4000
     c8c:      	b.eq	0xd24 <_llm_rows.packet_batch.blocks+0x388>
     c90:      	add	x16, x13, x10
     c94:      	movi.2d	v18, #0000000000000000
     c98:      	movi.2d	v19, #0000000000000000
     c9c:      	tbnz	w14, #0x0, 0xcc4 <_llm_rows.packet_batch.blocks+0x328>
     ca0:      	and	w0, w14, #0xff
     ca4:      	tbnz	w0, #0x1, 0xcd0 <_llm_rows.packet_batch.blocks+0x334>
     ca8:      	tbnz	w0, #0x2, 0xcdc <_llm_rows.packet_batch.blocks+0x340>
     cac:      	tbnz	w0, #0x3, 0xce8 <_llm_rows.packet_batch.blocks+0x34c>
     cb0:      	tbnz	w0, #0x4, 0xcf4 <_llm_rows.packet_batch.blocks+0x358>
     cb4:      	tbnz	w0, #0x5, 0xd00 <_llm_rows.packet_batch.blocks+0x364>
     cb8:      	tbnz	w0, #0x6, 0xd0c <_llm_rows.packet_batch.blocks+0x370>
     cbc:      	tbz	w0, #0x7, 0xc70 <_llm_rows.packet_batch.blocks+0x2d4>
     cc0:      	b	0xd18 <_llm_rows.packet_batch.blocks+0x37c>
     cc4:      	ldr	s18, [x16]
     cc8:      	and	w0, w14, #0xff
     ccc:      	tbz	w0, #0x1, 0xca8 <_llm_rows.packet_batch.blocks+0x30c>
     cd0:      	add	x1, x16, #0x4
     cd4:      	ld1.s	{ v18 }[1], [x1]
     cd8:      	tbz	w0, #0x2, 0xcac <_llm_rows.packet_batch.blocks+0x310>
     cdc:      	add	x1, x16, #0x8
     ce0:      	ld1.s	{ v18 }[2], [x1]
     ce4:      	tbz	w0, #0x3, 0xcb0 <_llm_rows.packet_batch.blocks+0x314>
     ce8:      	add	x1, x16, #0xc
     cec:      	ld1.s	{ v18 }[3], [x1]
     cf0:      	tbz	w0, #0x4, 0xcb4 <_llm_rows.packet_batch.blocks+0x318>
     cf4:      	add	x1, x16, #0x10
     cf8:      	ld1.s	{ v19 }[0], [x1]
     cfc:      	tbz	w0, #0x5, 0xcb8 <_llm_rows.packet_batch.blocks+0x31c>
     d00:      	add	x1, x16, #0x14
     d04:      	ld1.s	{ v19 }[1], [x1]
     d08:      	tbz	w0, #0x6, 0xcbc <_llm_rows.packet_batch.blocks+0x320>
     d0c:      	add	x1, x16, #0x18
     d10:      	ld1.s	{ v19 }[2], [x1]
     d14:      	tbz	w0, #0x7, 0xc70 <_llm_rows.packet_batch.blocks+0x2d4>
     d18:      	add	x16, x16, #0x1c
     d1c:      	ld1.s	{ v19 }[3], [x16]
     d20:      	b	0xc70 <_llm_rows.packet_batch.blocks+0x2d4>
     d24:      	uzp1.8b	v20, v2, v0
     d28:      	sshll.2d	v2, v1, #0x0
     d2c:      	movi.2d	v11, #0000000000000000
     d30:      	mov.b	v11[0], v20[0]
     d34:      	adrp	x10, 0x0 <ltmp0>
     d38:      	ldr	d18, [x10]
     d3c:      	str	d18, [sp, #0x300]
     d40:      	and.8b	v18, v11, v18
     d44:      	addv.8b	b18, v18
     d48:      	fmov	w10, s18
     d4c:      	umaxv.8b	b18, v11
     d50:      	fmov	w13, s18
     d54:      	rbit	w14, w10
     d58:      	clz	w14, w14
     d5c:      	tst	w13, #0x1
     d60:      	csel	w25, w14, wzr, ne
     d64:      	mov	w14, #0x1000            ; =4096
     d68:      	dup.2d	v19, x14
     d6c:      	adrp	x14, 0x0 <ltmp0>
     d70:      	ldr	q18, [x14]
     d74:      	str	q18, [sp, #0x290]
     d78:      	mov.16b	v21, v2
     d7c:      	bsl.16b	v21, v18, v19
     d80:      	xtn.2s	v3, v3
     d84:      	mov	w14, #0x1001            ; =4097
     d88:      	dup.2s	v18, w14
     d8c:      	umlal.2d	v21, v3, v18
     d90:      	movi.2d	v3, #0000000000000000
     d94:      	mov.b	v3[0], v20[0]
     d98:      	ushll.2d	v3, v3, #0x0
     d9c:      	shl.2d	v3, v3, #0x3f
     da0:      	cmlt.2d	v3, v3, #0
     da4:      	str	q21, [sp, #0x160]
     da8:      	and.16b	v3, v3, v21
     dac:      	movi.2d	v20, #0000000000000000
     db0:      	str	q20, [sp, #0x900]
     db4:      	str	q20, [sp, #0x8f0]
     db8:      	str	q20, [sp, #0x8e0]
     dbc:      	str	q3, [sp, #0x8d0]
     dc0:      	and	x14, x25, #0x7
     dc4:      	add	x16, sp, #0x8d0
     dc8:      	ldr	x14, [x16, x14, lsl #3]
     dcc:      	sub	x14, x14, x25
     dd0:      	add	x12, x12, x14, lsl #2
     dd4:      	movi.2d	v3, #0000000000000000
     dd8:      	tbnz	w13, #0x0, 0x150c <_llm_rows.packet_batch.blocks+0xb70>
     ddc:      	tbnz	w10, #0x1, 0x1514 <_llm_rows.packet_batch.blocks+0xb78>
     de0:      	tbnz	w10, #0x2, 0x1520 <_llm_rows.packet_batch.blocks+0xb84>
     de4:      	tbnz	w10, #0x3, 0x152c <_llm_rows.packet_batch.blocks+0xb90>
     de8:      	tbnz	w10, #0x4, 0x1538 <_llm_rows.packet_batch.blocks+0xb9c>
     dec:      	tbnz	w10, #0x5, 0x1544 <_llm_rows.packet_batch.blocks+0xba8>
     df0:      	tbnz	w10, #0x6, 0x1550 <_llm_rows.packet_batch.blocks+0xbb4>
     df4:      	tbz	w10, #0x7, 0xe00 <_llm_rows.packet_batch.blocks+0x464>
     df8:      	add	x12, x12, #0x1c
     dfc:      	ld1.s	{ v20 }[3], [x12]
     e00:      	mov	x12, #0x0               ; =0
     e04:      	sshll.2d	v21, v0, #0x0
     e08:      	sshll2.2d	v22, v1, #0x0
     e0c:      	sshll2.2d	v9, v0, #0x0
     e10:      	adrp	x13, 0x0 <ltmp0>
     e14:      	ldr	q26, [x13]
     e18:      	and.16b	v29, v9, v26
     e1c:      	adrp	x13, 0x0 <ltmp0>
     e20:      	ldr	q26, [x13]
     e24:      	and.16b	v30, v22, v26
     e28:      	adrp	x13, 0x0 <ltmp0>
     e2c:      	ldr	q26, [x13]
     e30:      	and.16b	v31, v21, v26
     e34:      	adrp	x13, 0x0 <ltmp0>
     e38:      	ldr	q26, [x13]
     e3c:      	and.16b	v2, v2, v26
     e40:      	adrp	x13, 0x0 <ltmp0>
     e44:      	ldr	q26, [x13]
     e48:      	bsl.16b	v21, v26, v19
     e4c:      	adrp	x13, 0x0 <ltmp0>
     e50:      	ldr	q28, [x13]
     e54:      	mov.16b	v8, v22
     e58:      	bsl.16b	v8, v28, v19
     e5c:      	adrp	x13, 0x0 <ltmp0>
     e60:      	ldr	q27, [x13]
     e64:      	bit.16b	v19, v27, v9
     e68:      	xtn.2s	v17, v17
     e6c:      	xtn.2s	v16, v16
     e70:      	xtn.2s	v4, v4
     e74:      	umlal.2d	v19, v4, v18
     e78:      	umlal.2d	v8, v16, v18
     e7c:      	stp	q19, q8, [sp, #0x130]
     e80:      	umlal.2d	v21, v17, v18
     e84:      	str	q21, [sp, #0x150]
     e88:      	str	q2, [sp, #0x890]
     e8c:      	str	q30, [sp, #0x8a0]
     e90:      	str	q31, [sp, #0x8b0]
     e94:      	str	q29, [sp, #0x8c0]
     e98:      	and	x13, x25, #0x7
     e9c:      	add	x14, sp, #0x890
     ea0:      	ldr	x13, [x14, x13, lsl #3]
     ea4:      	orr	x13, x13, #0x4000
     ea8:      	sub	x13, x13, x25, lsl #2
     eac:      	tst	w10, #0xff
     eb0:      	csel	x13, xzr, x13, eq
     eb4:      	str	x13, [sp, #0x1f8]
     eb8:      	add	x13, x17, x13
     ebc:      	ldp	q2, q4, [x13]
     ec0:      	zip2.8b	v16, v11, v0
     ec4:      	ushll.4s	v16, v16, #0x0
     ec8:      	shl.4s	v16, v16, #0x1f
     ecc:      	cmlt.4s	v16, v16, #0
     ed0:      	bit.16b	v4, v20, v16
     ed4:      	zip1.8b	v16, v11, v0
     ed8:      	ushll.4s	v16, v16, #0x0
     edc:      	shl.4s	v16, v16, #0x1f
     ee0:      	cmlt.4s	v16, v16, #0
     ee4:      	bit.16b	v2, v3, v16
     ee8:      	stp	q2, q4, [x13]
     eec:      	ushll2.2d	v2, v0, #0x0
     ef0:      	mov	w13, #0x1               ; =1
     ef4:      	dup.2d	v3, x13
     ef8:      	and.16b	v12, v2, v3
     efc:      	ushll2.2d	v2, v1, #0x0
     f00:      	and.16b	v13, v2, v3
     f04:      	ushll.2d	v2, v0, #0x0
     f08:      	and.16b	v14, v2, v3
     f0c:      	ushll.2d	v2, v1, #0x0
     f10:      	and.16b	v15, v2, v3
     f14:      	movi.2d	v2, #0000000000000000
     f18:      	and	x14, x26, #0x1
     f1c:      	movi.2d	v3, #0000000000000000
     f20:      	movi.2d	v4, #0000000000000000
     f24:      	movi.2d	v16, #0000000000000000
     f28:      	str	q9, [sp, #0x310]
     f2c:      	sshll.2d	v17, v0, #0x0
     f30:      	sshll.2d	v18, v1, #0x0
     f34:      	shl.2d	v19, v16, #0x3
     f38:      	shl.2d	v20, v2, #0x3
     f3c:      	shl.2d	v21, v4, #0x3
     f40:      	shl.2d	v29, v3, #0x3
     f44:      	ldr	q30, [x2]
     f48:      	orr.16b	v29, v29, v30
     f4c:      	ldr	q30, [x3]
     f50:      	orr.16b	v21, v21, v30
     f54:      	ldr	q30, [x4]
     f58:      	orr.16b	v20, v20, v30
     f5c:      	ldr	q30, [x5]
     f60:      	orr.16b	v19, v19, v30
     f64:      	add	x12, x8, x12, lsl #6
     f68:      	ldp	q31, q30, [x12]
     f6c:      	ldp	q8, q9, [x12, #0x20]
     f70:      	ldr	q25, [sp, #0x310]
     f74:      	bif.16b	v19, v9, v25
     f78:      	ldr	q9, [sp, #0x310]
     f7c:      	bsl.16b	v18, v20, v31
     f80:      	bsl.16b	v17, v21, v8
     f84:      	mov.16b	v20, v22
     f88:      	bsl.16b	v20, v29, v30
     f8c:      	stp	q18, q20, [x12]
     f90:      	stp	q17, q19, [x12, #0x20]
     f94:      	add.2d	v17, v2, v15
     f98:      	add.2d	v3, v3, v13
     f9c:      	add.2d	v4, v4, v14
     fa0:      	add.2d	v16, v16, v12
     fa4:      	fmov	x12, d2
     fa8:      	add	x12, x12, x14
     fac:      	mov.16b	v2, v17
     fb0:      	cmp	x12, #0x200
     fb4:      	b.lt	0xf2c <_llm_rows.packet_batch.blocks+0x590>
     fb8:      	mov	x13, #0x0               ; =0
     fbc:      	mov	w12, #0x1001            ; =4097
     fc0:      	dup.4s	v2, w12
     fc4:      	and.16b	v3, v1, v2
     fc8:      	mvn.16b	v4, v1
     fcc:      	sub.4s	v3, v3, v4
     fd0:      	and.16b	v2, v0, v2
     fd4:      	mvn.16b	v4, v0
     fd8:      	sub.4s	v2, v2, v4
     fdc:      	mov.s	w12, v2[1]
     fe0:      	mov.s	w16, v24[1]
     fe4:      	udiv	w0, w16, w12
     fe8:      	msub	w16, w0, w12, w16
     fec:      	mov.s	w12, v2[2]
     ff0:      	mov.s	w0, v2[3]
     ff4:      	fmov	w1, s2
     ff8:      	fmov	w2, s24
     ffc:      	udiv	w3, w2, w1
    1000:      	msub	w1, w3, w1, w2
    1004:      	mov.s	w2, v24[2]
    1008:      	udiv	w3, w2, w12
    100c:      	msub	w2, w3, w12, w2
    1010:      	mov.s	w12, v24[3]
    1014:      	udiv	w3, w12, w0
    1018:      	msub	w0, w3, w0, w12
    101c:      	mov.s	w12, v3[1]
    1020:      	mov.s	w3, v7[1]
    1024:      	udiv	w4, w3, w12
    1028:      	msub	w3, w4, w12, w3
    102c:      	mov.s	w12, v3[2]
    1030:      	mov.s	w4, v3[3]
    1034:      	fmov	w5, s3
    1038:      	fmov	w6, s7
    103c:      	udiv	w7, w6, w5
    1040:      	msub	w5, w7, w5, w6
    1044:      	mov.s	w6, v7[2]
    1048:      	udiv	w7, w6, w12
    104c:      	msub	w12, w7, w12, w6
    1050:      	mov.s	w6, v7[3]
    1054:      	udiv	w7, w6, w4
    1058:      	msub	w4, w7, w4, w6
    105c:      	tst	w10, #0xff
    1060:      	fmov	s2, w1
    1064:      	mov.s	v2[1], w16
    1068:      	mov.s	v2[2], w2
    106c:      	mov.s	v2[3], w0
    1070:      	sshll.2d	v17, v0, #0x0
    1074:      	sshll.2d	v16, v1, #0x0
    1078:      	adrp	x10, 0x1000 <_llm_rows.packet_batch.blocks+0x664>
    107c:      	ldr	q3, [x10]
    1080:      	and.16b	v3, v16, v3
    1084:      	adrp	x10, 0x1000 <_llm_rows.packet_batch.blocks+0x664>
    1088:      	ldr	q4, [x10]
    108c:      	and.16b	v4, v17, v4
    1090:      	adrp	x10, 0x1000 <_llm_rows.packet_batch.blocks+0x664>
    1094:      	ldr	q7, [x10]
    1098:      	and.16b	v7, v22, v7
    109c:      	adrp	x10, 0x1000 <_llm_rows.packet_batch.blocks+0x664>
    10a0:      	ldr	q18, [x10]
    10a4:      	and.16b	v18, v9, v18
    10a8:      	str	q18, [sp, #0x880]
    10ac:      	str	q4, [sp, #0x870]
    10b0:      	str	q7, [sp, #0x860]
    10b4:      	str	q3, [sp, #0x850]
    10b8:      	fmov	s3, w5
    10bc:      	and	x10, x25, #0x7
    10c0:      	add	x16, sp, #0x850
    10c4:      	ldr	x10, [x16, x10, lsl #3]
    10c8:      	orr	x10, x10, #0x8000
    10cc:      	sub	x10, x10, x25, lsl #3
    10d0:      	csel	x10, xzr, x10, eq
    10d4:      	mov.s	v3[1], w3
    10d8:      	add	x16, x8, x10
    10dc:      	ldp	q4, q7, [x16, #0x20]
    10e0:      	mov	b18, v11[2]
    10e4:      	mov.b	v18[4], v11[3]
    10e8:      	ldp	q19, q20, [x16]
    10ec:      	ushll.2d	v18, v18, #0x0
    10f0:      	shl.2d	v18, v18, #0x3f
    10f4:      	cmlt.2d	v18, v18, #0
    10f8:      	bsl.16b	v18, v28, v20
    10fc:      	mov	b20, v11[0]
    1100:      	mov.b	v20[4], v11[1]
    1104:      	ushll.2d	v20, v20, #0x0
    1108:      	shl.2d	v20, v20, #0x3f
    110c:      	cmlt.2d	v20, v20, #0
    1110:      	ldr	q21, [sp, #0x290]
    1114:      	bit.16b	v19, v21, v20
    1118:      	mov	b20, v11[6]
    111c:      	mov.b	v20[4], v11[7]
    1120:      	ushll.2d	v20, v20, #0x0
    1124:      	shl.2d	v20, v20, #0x3f
    1128:      	cmlt.2d	v20, v20, #0
    112c:      	bit.16b	v7, v27, v20
    1130:      	mov	b20, v11[4]
    1134:      	mov.b	v20[4], v11[5]
    1138:      	ushll.2d	v20, v20, #0x0
    113c:      	shl.2d	v20, v20, #0x3f
    1140:      	cmlt.2d	v20, v20, #0
    1144:      	bit.16b	v4, v26, v20
    1148:      	mov.s	v3[2], w12
    114c:      	mov.s	v3[3], w4
    1150:      	and.16b	v20, v1, v3
    1154:      	stp	q4, q7, [x16, #0x20]
    1158:      	stp	q19, q18, [x16]
    115c:      	and.16b	v3, v0, v2
    1160:      	ushll2.2d	v2, v3, #0x0
    1164:      	ushll2.2d	v4, v20, #0x0
    1168:      	ushll.2d	v3, v3, #0x0
    116c:      	ushll.2d	v7, v20, #0x0
    1170:      	and.16b	v25, v9, v6
    1174:      	and.16b	v26, v22, v6
    1178:      	and.16b	v27, v17, v6
    117c:      	and.16b	v28, v16, v6
    1180:      	adrp	x12, 0x1000 <_llm_rows.packet_batch.blocks+0x664>
    1184:      	ldr	q6, [x12]
    1188:      	and.16b	v29, v9, v6
    118c:      	adrp	x12, 0x1000 <_llm_rows.packet_batch.blocks+0x664>
    1190:      	ldr	q6, [x12]
    1194:      	str	q22, [sp, #0x1e0]
    1198:      	and.16b	v22, v22, v6
    119c:      	adrp	x12, 0x1000 <_llm_rows.packet_batch.blocks+0x664>
    11a0:      	ldr	q6, [x12]
    11a4:      	and.16b	v30, v17, v6
    11a8:      	adrp	x12, 0x1000 <_llm_rows.packet_batch.blocks+0x664>
    11ac:      	ldr	q6, [x12]
    11b0:      	and.16b	v31, v16, v6
    11b4:      	ldp	q6, q16, [sp, #0x1b0]
    11b8:      	cmhs.4s	v6, v6, v5
    11bc:      	cmhs.4s	v5, v16, v5
    11c0:      	uzp1.8h	v5, v5, v6
    11c4:      	xtn.8b	v5, v5
    11c8:      	movi.2d	v6, #0000000000000000
    11cc:      	movi.2d	v16, #0000000000000000
    11d0:      	movi.2d	v17, #0000000000000000
    11d4:      	movi.2d	v18, #0000000000000000
    11d8:      	b	0x1200 <_llm_rows.packet_batch.blocks+0x864>
    11dc:      	add.2d	v19, v6, v15
    11e0:      	add.2d	v16, v16, v13
    11e4:      	add.2d	v17, v17, v14
    11e8:      	add.2d	v18, v18, v12
    11ec:      	fmov	x12, d6
    11f0:      	add	x13, x12, x14
    11f4:      	mov.16b	v6, v19
    11f8:      	cmp	x13, #0x200
    11fc:      	b.ge	0x12fc <_llm_rows.packet_batch.blocks+0x960>
    1200:      	fmov	w12, s23
    1204:      	add	x13, x8, x13, lsl #6
    1208:      	ldp	q20, q19, [x13, #0x20]
    120c:      	ldp	q21, q24, [x13]
    1210:      	cmge.2d	v24, v4, v24
    1214:      	cmge.2d	v21, v7, v21
    1218:      	uzp1.4s	v21, v21, v24
    121c:      	cmge.2d	v20, v3, v20
    1220:      	cmge.2d	v19, v2, v19
    1224:      	uzp1.4s	v19, v20, v19
    1228:      	uzp1.8h	v19, v21, v19
    122c:      	xtn.8b	v19, v19
    1230:      	orr.8b	v19, v5, v19
    1234:      	add.2d	v20, v6, v31
    1238:      	add.2d	v20, v28, v20
    123c:      	and.8b	v19, v19, v10
    1240:      	tbnz	w12, #0x0, 0x1280 <_llm_rows.packet_batch.blocks+0x8e4>
    1244:      	and	w12, w12, #0xff
    1248:      	tbnz	w12, #0x1, 0x1290 <_llm_rows.packet_batch.blocks+0x8f4>
    124c:      	add.2d	v20, v16, v22
    1250:      	add.2d	v20, v26, v20
    1254:      	tbnz	w12, #0x2, 0x12a4 <_llm_rows.packet_batch.blocks+0x908>
    1258:      	tbnz	w12, #0x3, 0x12b0 <_llm_rows.packet_batch.blocks+0x914>
    125c:      	add.2d	v20, v17, v30
    1260:      	add.2d	v20, v27, v20
    1264:      	tbnz	w12, #0x4, 0x12c4 <_llm_rows.packet_batch.blocks+0x928>
    1268:      	tbnz	w12, #0x5, 0x12d0 <_llm_rows.packet_batch.blocks+0x934>
    126c:      	add.2d	v20, v18, v29
    1270:      	add.2d	v20, v25, v20
    1274:      	tbnz	w12, #0x6, 0x12e4 <_llm_rows.packet_batch.blocks+0x948>
    1278:      	tbz	w12, #0x7, 0x11dc <_llm_rows.packet_batch.blocks+0x840>
    127c:      	b	0x12f0 <_llm_rows.packet_batch.blocks+0x954>
    1280:      	fmov	x13, d20
    1284:      	str	b19, [x13]
    1288:      	and	w12, w12, #0xff
    128c:      	tbz	w12, #0x1, 0x124c <_llm_rows.packet_batch.blocks+0x8b0>
    1290:      	mov.d	x13, v20[1]
    1294:      	st1.b	{ v19 }[1], [x13]
    1298:      	add.2d	v20, v16, v22
    129c:      	add.2d	v20, v26, v20
    12a0:      	tbz	w12, #0x2, 0x1258 <_llm_rows.packet_batch.blocks+0x8bc>
    12a4:      	fmov	x13, d20
    12a8:      	st1.b	{ v19 }[2], [x13]
    12ac:      	tbz	w12, #0x3, 0x125c <_llm_rows.packet_batch.blocks+0x8c0>
    12b0:      	mov.d	x13, v20[1]
    12b4:      	st1.b	{ v19 }[3], [x13]
    12b8:      	add.2d	v20, v17, v30
    12bc:      	add.2d	v20, v27, v20
    12c0:      	tbz	w12, #0x4, 0x1268 <_llm_rows.packet_batch.blocks+0x8cc>
    12c4:      	fmov	x13, d20
    12c8:      	st1.b	{ v19 }[4], [x13]
    12cc:      	tbz	w12, #0x5, 0x126c <_llm_rows.packet_batch.blocks+0x8d0>
    12d0:      	mov.d	x13, v20[1]
    12d4:      	st1.b	{ v19 }[5], [x13]
    12d8:      	add.2d	v20, v18, v29
    12dc:      	add.2d	v20, v25, v20
    12e0:      	tbz	w12, #0x6, 0x1278 <_llm_rows.packet_batch.blocks+0x8dc>
    12e4:      	fmov	x13, d20
    12e8:      	st1.b	{ v19 }[6], [x13]
    12ec:      	tbz	w12, #0x7, 0x11dc <_llm_rows.packet_batch.blocks+0x840>
    12f0:      	mov.d	x12, v20[1]
    12f4:      	st1.b	{ v19 }[7], [x12]
    12f8:      	b	0x11dc <_llm_rows.packet_batch.blocks+0x840>
    12fc:      	add	x8, x8, x10
    1300:      	ldp	q6, q5, [x8, #0x20]
    1304:      	ldp	q16, q17, [x8]
    1308:      	cmge.2d	v4, v4, v17
    130c:      	cmge.2d	v7, v7, v16
    1310:      	uzp1.4s	v4, v7, v4
    1314:      	cmge.2d	v3, v3, v6
    1318:      	cmge.2d	v2, v2, v5
    131c:      	uzp1.4s	v2, v3, v2
    1320:      	uzp1.8h	v2, v4, v2
    1324:      	xtn.8b	v2, v2
    1328:      	shl.8b	v3, v11, #0x7
    132c:      	cmlt.8b	v3, v3, #0
    1330:      	ldr	d4, [sp, #0x300]
    1334:      	and.8b	v3, v3, v4
    1338:      	addv.8b	b3, v3
    133c:      	str	d3, [sp, #0x1f0]
    1340:      	fmov	w8, s3
    1344:      	orn.8b	v2, v2, v11
    1348:      	add.2d	v4, v31, v28
    134c:      	mov	w10, #0x200             ; =512
    1350:      	dup.2d	v3, x10
    1354:      	add.2d	v8, v4, v3
    1358:      	and.8b	v2, v2, v10
    135c:      	tbnz	w8, #0x0, 0x1560 <_llm_rows.packet_batch.blocks+0xbc4>
    1360:      	mov.d	x1, v8[1]
    1364:      	ldr	q20, [sp, #0x1e0]
    1368:      	tbnz	w8, #0x1, 0x1574 <_llm_rows.packet_batch.blocks+0xbd8>
    136c:      	add.2d	v4, v22, v26
    1370:      	add.2d	v24, v4, v3
    1374:      	tbnz	w8, #0x2, 0x1584 <_llm_rows.packet_batch.blocks+0xbe8>
    1378:      	mov.d	x0, v24[1]
    137c:      	tbnz	w8, #0x3, 0x1594 <_llm_rows.packet_batch.blocks+0xbf8>
    1380:      	add.2d	v4, v30, v27
    1384:      	add.2d	v21, v4, v3
    1388:      	tbnz	w8, #0x4, 0x15a4 <_llm_rows.packet_batch.blocks+0xc08>
    138c:      	mov.d	x16, v21[1]
    1390:      	tbnz	w8, #0x5, 0x15b4 <_llm_rows.packet_batch.blocks+0xc18>
    1394:      	add.2d	v4, v29, v25
    1398:      	add.2d	v19, v4, v3
    139c:      	tbnz	w8, #0x6, 0x15c4 <_llm_rows.packet_batch.blocks+0xc28>
    13a0:      	mov.d	x13, v19[1]
    13a4:      	tbz	w8, #0x7, 0x13ac <_llm_rows.packet_batch.blocks+0xa10>
    13a8:      	st1.b	{ v2 }[7], [x13]
    13ac:      	mov	x8, #0x0                ; =0
    13b0:      	movi.2d	v2, #0000000000000000
    13b4:      	movi.2d	v3, #0000000000000000
    13b8:      	movi.2d	v4, #0000000000000000
    13bc:      	movi.2d	v5, #0000000000000000
    13c0:      	b	0x142c <_llm_rows.packet_batch.blocks+0xa90>
    13c4:      	cmeq.8b	v6, v6, #0
    13c8:      	sshll.8h	v6, v6, #0x0
    13cc:      	sshll2.4s	v7, v6, #0x0
    13d0:      	sshll.4s	v16, v6, #0x0
    13d4:      	lsl	x8, x8, #5
    13d8:      	add	x10, x17, x8
    13dc:      	ldp	q17, q6, [x10]
    13e0:      	and.16b	v18, v0, v6
    13e4:      	dup.4s	v6, w23
    13e8:      	and.16b	v17, v1, v17
    13ec:      	bsl.16b	v16, v6, v17
    13f0:      	bsl.16b	v7, v6, v18
    13f4:      	add	x8, x15, x8
    13f8:      	ldp	q17, q18, [x8]
    13fc:      	bif.16b	v7, v18, v0
    1400:      	bif.16b	v16, v17, v1
    1404:      	stp	q16, q7, [x8]
    1408:      	add.2d	v7, v2, v15
    140c:      	add.2d	v3, v3, v13
    1410:      	add.2d	v4, v4, v14
    1414:      	add.2d	v5, v5, v12
    1418:      	fmov	x8, d2
    141c:      	add	x8, x8, x14
    1420:      	mov.16b	v2, v7
    1424:      	cmp	x8, #0x200
    1428:      	b.ge	0x14f0 <_llm_rows.packet_batch.blocks+0xb54>
    142c:      	fmov	w10, s23
    1430:      	add.2d	v6, v2, v31
    1434:      	add.2d	v7, v28, v6
    1438:      	tbz	w10, #0x0, 0x1450 <_llm_rows.packet_batch.blocks+0xab4>
    143c:      	fmov	x12, d7
    1440:      	ldr	b6, [x12]
    1444:      	and	w10, w10, #0xff
    1448:      	tbnz	w10, #0x1, 0x145c <_llm_rows.packet_batch.blocks+0xac0>
    144c:      	b	0x1464 <_llm_rows.packet_batch.blocks+0xac8>
    1450:      	movi.2d	v6, #0000000000000000
    1454:      	and	w10, w10, #0xff
    1458:      	tbz	w10, #0x1, 0x1464 <_llm_rows.packet_batch.blocks+0xac8>
    145c:      	mov.d	x12, v7[1]
    1460:      	ld1.b	{ v6 }[1], [x12]
    1464:      	add.2d	v7, v3, v22
    1468:      	add.2d	v7, v26, v7
    146c:      	tbnz	w10, #0x2, 0x1498 <_llm_rows.packet_batch.blocks+0xafc>
    1470:      	tbnz	w10, #0x3, 0x14a4 <_llm_rows.packet_batch.blocks+0xb08>
    1474:      	add.2d	v7, v4, v30
    1478:      	add.2d	v7, v27, v7
    147c:      	tbnz	w10, #0x4, 0x14b8 <_llm_rows.packet_batch.blocks+0xb1c>
    1480:      	tbnz	w10, #0x5, 0x14c4 <_llm_rows.packet_batch.blocks+0xb28>
    1484:      	add.2d	v7, v5, v29
    1488:      	add.2d	v7, v25, v7
    148c:      	tbnz	w10, #0x6, 0x14d8 <_llm_rows.packet_batch.blocks+0xb3c>
    1490:      	tbz	w10, #0x7, 0x13c4 <_llm_rows.packet_batch.blocks+0xa28>
    1494:      	b	0x14e4 <_llm_rows.packet_batch.blocks+0xb48>
    1498:      	fmov	x12, d7
    149c:      	ld1.b	{ v6 }[2], [x12]
    14a0:      	tbz	w10, #0x3, 0x1474 <_llm_rows.packet_batch.blocks+0xad8>
    14a4:      	mov.d	x12, v7[1]
    14a8:      	ld1.b	{ v6 }[3], [x12]
    14ac:      	add.2d	v7, v4, v30
    14b0:      	add.2d	v7, v27, v7
    14b4:      	tbz	w10, #0x4, 0x1480 <_llm_rows.packet_batch.blocks+0xae4>
    14b8:      	fmov	x12, d7
    14bc:      	ld1.b	{ v6 }[4], [x12]
    14c0:      	tbz	w10, #0x5, 0x1484 <_llm_rows.packet_batch.blocks+0xae8>
    14c4:      	mov.d	x12, v7[1]
    14c8:      	ld1.b	{ v6 }[5], [x12]
    14cc:      	add.2d	v7, v5, v29
    14d0:      	add.2d	v7, v25, v7
    14d4:      	tbz	w10, #0x6, 0x1490 <_llm_rows.packet_batch.blocks+0xaf4>
    14d8:      	fmov	x12, d7
    14dc:      	ld1.b	{ v6 }[6], [x12]
    14e0:      	tbz	w10, #0x7, 0x13c4 <_llm_rows.packet_batch.blocks+0xa28>
    14e4:      	mov.d	x10, v7[1]
    14e8:      	ld1.b	{ v6 }[7], [x10]
    14ec:      	b	0x13c4 <_llm_rows.packet_batch.blocks+0xa28>
    14f0:      	ldr	d2, [sp, #0x1f0]
    14f4:      	fmov	w8, s2
    14f8:      	tbz	w8, #0x0, 0x15d8 <_llm_rows.packet_batch.blocks+0xc3c>
    14fc:      	fmov	x10, d8
    1500:      	ldr	b2, [x10]
    1504:      	tbnz	w8, #0x1, 0x15e0 <_llm_rows.packet_batch.blocks+0xc44>
    1508:      	b	0x15e4 <_llm_rows.packet_batch.blocks+0xc48>
    150c:      	ldr	s3, [x12]
    1510:      	tbz	w10, #0x1, 0xde0 <_llm_rows.packet_batch.blocks+0x444>
    1514:      	add	x13, x12, #0x4
    1518:      	ld1.s	{ v3 }[1], [x13]
    151c:      	tbz	w10, #0x2, 0xde4 <_llm_rows.packet_batch.blocks+0x448>
    1520:      	add	x13, x12, #0x8
    1524:      	ld1.s	{ v3 }[2], [x13]
    1528:      	tbz	w10, #0x3, 0xde8 <_llm_rows.packet_batch.blocks+0x44c>
    152c:      	add	x13, x12, #0xc
    1530:      	ld1.s	{ v3 }[3], [x13]
    1534:      	tbz	w10, #0x4, 0xdec <_llm_rows.packet_batch.blocks+0x450>
    1538:      	add	x13, x12, #0x10
    153c:      	ld1.s	{ v20 }[0], [x13]
    1540:      	tbz	w10, #0x5, 0xdf0 <_llm_rows.packet_batch.blocks+0x454>
    1544:      	add	x13, x12, #0x14
    1548:      	ld1.s	{ v20 }[1], [x13]
    154c:      	tbz	w10, #0x6, 0xdf4 <_llm_rows.packet_batch.blocks+0x458>
    1550:      	add	x13, x12, #0x18
    1554:      	ld1.s	{ v20 }[2], [x13]
    1558:      	tbnz	w10, #0x7, 0xdf8 <_llm_rows.packet_batch.blocks+0x45c>
    155c:      	b	0xe00 <_llm_rows.packet_batch.blocks+0x464>
    1560:      	fmov	x10, d8
    1564:      	str	b2, [x10]
    1568:      	mov.d	x1, v8[1]
    156c:      	ldr	q20, [sp, #0x1e0]
    1570:      	tbz	w8, #0x1, 0x136c <_llm_rows.packet_batch.blocks+0x9d0>
    1574:      	st1.b	{ v2 }[1], [x1]
    1578:      	add.2d	v4, v22, v26
    157c:      	add.2d	v24, v4, v3
    1580:      	tbz	w8, #0x2, 0x1378 <_llm_rows.packet_batch.blocks+0x9dc>
    1584:      	fmov	x10, d24
    1588:      	st1.b	{ v2 }[2], [x10]
    158c:      	mov.d	x0, v24[1]
    1590:      	tbz	w8, #0x3, 0x1380 <_llm_rows.packet_batch.blocks+0x9e4>
    1594:      	st1.b	{ v2 }[3], [x0]
    1598:      	add.2d	v4, v30, v27
    159c:      	add.2d	v21, v4, v3
    15a0:      	tbz	w8, #0x4, 0x138c <_llm_rows.packet_batch.blocks+0x9f0>
    15a4:      	fmov	x10, d21
    15a8:      	st1.b	{ v2 }[4], [x10]
    15ac:      	mov.d	x16, v21[1]
    15b0:      	tbz	w8, #0x5, 0x1394 <_llm_rows.packet_batch.blocks+0x9f8>
    15b4:      	st1.b	{ v2 }[5], [x16]
    15b8:      	add.2d	v4, v29, v25
    15bc:      	add.2d	v19, v4, v3
    15c0:      	tbz	w8, #0x6, 0x13a0 <_llm_rows.packet_batch.blocks+0xa04>
    15c4:      	fmov	x10, d19
    15c8:      	st1.b	{ v2 }[6], [x10]
    15cc:      	mov.d	x13, v19[1]
    15d0:      	tbnz	w8, #0x7, 0x13a8 <_llm_rows.packet_batch.blocks+0xa0c>
    15d4:      	b	0x13ac <_llm_rows.packet_batch.blocks+0xa10>
    15d8:      	movi.2d	v2, #0000000000000000
    15dc:      	tbz	w8, #0x1, 0x15e4 <_llm_rows.packet_batch.blocks+0xc48>
    15e0:      	ld1.b	{ v2 }[1], [x1]
    15e4:      	tbnz	w8, #0x2, 0x2080 <_llm_rows.packet_batch.blocks+0x16e4>
    15e8:      	tbnz	w8, #0x3, 0x208c <_llm_rows.packet_batch.blocks+0x16f0>
    15ec:      	tbnz	w8, #0x4, 0x2094 <_llm_rows.packet_batch.blocks+0x16f8>
    15f0:      	tbnz	w8, #0x5, 0x20a0 <_llm_rows.packet_batch.blocks+0x1704>
    15f4:      	tbz	w8, #0x6, 0x1600 <_llm_rows.packet_batch.blocks+0xc64>
    15f8:      	fmov	x10, d19
    15fc:      	ld1.b	{ v2 }[6], [x10]
    1600:      	stp	q26, q25, [sp, #0x280]
    1604:      	stp	q28, q27, [sp, #0x260]
    1608:      	stp	q22, q29, [sp, #0x240]
    160c:      	stp	q31, q30, [sp, #0x220]
    1610:      	stp	q13, q12, [sp, #0x2e0]
    1614:      	stp	q15, q14, [sp, #0x2c0]
    1618:      	str	q19, [sp, #0x90]
    161c:      	str	q21, [sp, #0x70]
    1620:      	str	q24, [sp, #0x50]
    1624:      	str	q8, [sp, #0x30]
    1628:      	tbz	w8, #0x7, 0x1630 <_llm_rows.packet_batch.blocks+0xc94>
    162c:      	ld1.b	{ v2 }[7], [x13]
    1630:      	str	x19, [sp, #0xe8]
    1634:      	str	x1, [sp, #0x48]
    1638:      	str	x0, [sp, #0x68]
    163c:      	str	x16, [sp, #0x88]
    1640:      	str	x13, [sp, #0xa0]
    1644:      	str	x25, [sp, #0x178]
    1648:      	str	q23, [sp, #0x300]
    164c:      	str	w28, [sp, #0x194]
    1650:      	str	w27, [sp, #0x19c]
    1654:      	sshll.2d	v3, v1, #0x0
    1658:      	sshll.2d	v4, v0, #0x0
    165c:      	cmeq.8b	v2, v2, #0
    1660:      	sshll.8h	v2, v2, #0x0
    1664:      	sshll2.4s	v5, v2, #0x0
    1668:      	sshll.4s	v2, v2, #0x0
    166c:      	ldr	x10, [sp, #0x1f8]
    1670:      	add	x8, x17, x10
    1674:      	ldp	q7, q16, [x8]
    1678:      	zip2.8b	v17, v11, v0
    167c:      	ushll.4s	v17, v17, #0x0
    1680:      	shl.4s	v17, v17, #0x1f
    1684:      	cmlt.4s	v17, v17, #0
    1688:      	and.16b	v18, v17, v16
    168c:      	str	q11, [sp, #0x200]
    1690:      	zip1.8b	v16, v11, v0
    1694:      	ushll.4s	v16, v16, #0x0
    1698:      	shl.4s	v16, v16, #0x1f
    169c:      	cmlt.4s	v19, v16, #0
    16a0:      	and.16b	v7, v19, v7
    16a4:      	bit.16b	v7, v6, v2
    16a8:      	bif.16b	v6, v18, v5
    16ac:      	add	x8, x15, x10
    16b0:      	ldp	q2, q5, [x8]
    16b4:      	stp	q6, q7, [sp, #0x100]
    16b8:      	bit.16b	v5, v6, v17
    16bc:      	bit.16b	v2, v7, v19
    16c0:      	stp	q2, q5, [x8]
    16c4:      	dup.2d	v2, x24
    16c8:      	and.16b	v14, v9, v2
    16cc:      	and.16b	v15, v20, v2
    16d0:      	and.16b	v5, v4, v2
    16d4:      	and.16b	v6, v3, v2
    16d8:      	tst	w26, #0x1
    16dc:      	csel	x7, x24, xzr, ne
    16e0:      	ldp	q2, q3, [x15, #0x60]
    16e4:      	and.16b	v3, v0, v3
    16e8:      	and.16b	v2, v1, v2
    16ec:      	ldp	q7, q4, [x15, #0x40]
    16f0:      	and.16b	v4, v0, v4
    16f4:      	and.16b	v7, v1, v7
    16f8:      	ldp	q17, q18, [x15, #0x20]
    16fc:      	and.16b	v18, v0, v18
    1700:      	and.16b	v17, v1, v17
    1704:      	ldp	q19, q21, [x15]
    1708:      	and.16b	v21, v0, v21
    170c:      	mov	x8, x7
    1710:      	and.16b	v22, v1, v19
    1714:      	mov.16b	v11, v6
    1718:      	mov.16b	v8, v15
    171c:      	mov.16b	v31, v9
    1720:      	mov.16b	v9, v5
    1724:      	mov.16b	v30, v20
    1728:      	mov.16b	v10, v14
    172c:      	sshll.2d	v12, v1, #0x0
    1730:      	sshll.2d	v13, v0, #0x0
    1734:      	add	x8, x15, x8, lsl #5
    1738:      	ldp	q19, q24, [x8]
    173c:      	and.16b	v23, v0, v24
    1740:      	and.16b	v19, v1, v19
    1744:      	fmaxnm.4s	v24, v22, v19
    1748:      	fmaxnm.4s	v19, v21, v23
    174c:      	ldp	q23, q16, [x8, #0x20]
    1750:      	and.16b	v16, v0, v16
    1754:      	and.16b	v23, v1, v23
    1758:      	fmaxnm.4s	v23, v17, v23
    175c:      	fmaxnm.4s	v16, v18, v16
    1760:      	ldp	q20, q25, [x8, #0x40]
    1764:      	and.16b	v25, v0, v25
    1768:      	and.16b	v20, v1, v20
    176c:      	fmaxnm.4s	v20, v7, v20
    1770:      	fmaxnm.4s	v25, v4, v25
    1774:      	ldp	q26, q27, [x8, #0x60]
    1778:      	and.16b	v27, v0, v27
    177c:      	and.16b	v26, v1, v26
    1780:      	fmaxnm.4s	v26, v2, v26
    1784:      	fmaxnm.4s	v27, v3, v27
    1788:      	dup.2d	v28, x24
    178c:      	and.16b	v29, v31, v28
    1790:      	add.2d	v10, v10, v29
    1794:      	and.16b	v29, v30, v28
    1798:      	add.2d	v8, v8, v29
    179c:      	and.16b	v29, v13, v28
    17a0:      	add.2d	v9, v9, v29
    17a4:      	and.16b	v28, v12, v28
    17a8:      	add.2d	v28, v11, v28
    17ac:      	bit.16b	v21, v19, v0
    17b0:      	bit.16b	v22, v24, v1
    17b4:      	bit.16b	v18, v16, v0
    17b8:      	bit.16b	v17, v23, v1
    17bc:      	bit.16b	v4, v25, v0
    17c0:      	bit.16b	v7, v20, v1
    17c4:      	bit.16b	v3, v27, v0
    17c8:      	bit.16b	v2, v26, v1
    17cc:      	fmov	x8, d11
    17d0:      	add	x10, x8, #0x4
    17d4:      	tst	w26, #0x1
    17d8:      	csel	x8, x10, x8, ne
    17dc:      	mov.16b	v11, v28
    17e0:      	cmp	x8, #0x200
    17e4:      	b.lt	0x172c <_llm_rows.packet_batch.blocks+0xd90>
    17e8:      	mov	x13, #0x0               ; =0
    17ec:      	ldr	q16, [sp, #0x1d0]
    17f0:      	xtn.8b	v26, v16
    17f4:      	ldr	q23, [sp, #0x200]
    17f8:      	zip2.8b	v16, v23, v0
    17fc:      	ushll.4s	v16, v16, #0x0
    1800:      	shl.4s	v16, v16, #0x1f
    1804:      	cmlt.4s	v16, v16, #0
    1808:      	ldp	q20, q25, [sp, #0x100]
    180c:      	and.16b	v20, v16, v20
    1810:      	zip1.8b	v23, v23, v0
    1814:      	ushll.4s	v23, v23, #0x0
    1818:      	shl.4s	v23, v23, #0x1f
    181c:      	cmlt.4s	v23, v23, #0
    1820:      	and.16b	v25, v23, v25
    1824:      	fmaxnm.4s	v22, v22, v25
    1828:      	fmaxnm.4s	v20, v21, v20
    182c:      	and.16b	v16, v16, v20
    1830:      	and.16b	v20, v23, v22
    1834:      	movi.2d	v21, #0000000000000000
    1838:      	mov.b	v21[2], v26[1]
    183c:      	mov.b	v21[4], v26[2]
    1840:      	mov.b	v21[6], v26[3]
    1844:      	ushll.4s	v21, v21, #0x0
    1848:      	shl.4s	v21, v21, #0x1f
    184c:      	cmlt.4s	v21, v21, #0
    1850:      	bit.16b	v20, v24, v21
    1854:      	zip2.8b	v21, v26, v0
    1858:      	ushll.4s	v21, v21, #0x0
    185c:      	shl.4s	v21, v21, #0x1f
    1860:      	cmlt.4s	v21, v21, #0
    1864:      	bit.16b	v16, v19, v21
    1868:      	fmaxnm.4s	v16, v16, v18
    186c:      	fmaxnm.4s	v17, v20, v17
    1870:      	fmaxnm.4s	v7, v17, v7
    1874:      	fmaxnm.4s	v4, v16, v4
    1878:      	fmaxnm.4s	v3, v4, v3
    187c:      	fmaxnm.4s	v2, v7, v2
    1880:      	umov.b	w20, v26[1]
    1884:      	and	w8, w26, w20
    1888:      	str	w8, [sp, #0xbc]
    188c:      	mov	s4, v2[1]
    1890:      	tst	w8, #0x1
    1894:      	movi	d22, #0000000000000000
    1898:      	fcsel	s4, s4, s22, ne
    189c:      	mvn	w8, w20
    18a0:      	add	x10, sp, #0x578
    18a4:      	bfxil	x10, x8, #0, #1
    18a8:      	str	d26, [sp, #0x578]
    18ac:      	ldrb	w10, [x10]
    18b0:      	add	x12, sp, #0x820
    18b4:      	bfi	x12, x8, #2, #1
    18b8:      	str	q3, [sp, #0x830]
    18bc:      	str	q2, [sp, #0x820]
    18c0:      	ldr	s7, [x12]
    18c4:      	and	w30, w20, #0x1
    18c8:      	tst	w30, w10
    18cc:      	fcsel	s7, s7, s22, ne
    18d0:      	umov.b	w11, v26[2]
    18d4:      	umov.b	w8, v26[3]
    18d8:      	str	x8, [sp, #0xb0]
    18dc:      	ands	w1, w8, #0x1
    18e0:      	mov	w8, #0x1                ; =1
    18e4:      	cinc	w10, w8, ne
    18e8:      	cinc	w17, w8, eq
    18ec:      	mov	w4, #0x7                ; =7
    18f0:      	csel	w8, w4, w24, ne
    18f4:      	str	x8, [sp, #0x100]
    18f8:      	ands	w2, w11, #0x1
    18fc:      	stp	w1, w2, [sp, #0xe0]
    1900:      	mov	w8, #0x3                ; =3
    1904:      	csinc	w8, w8, wzr, ne
    1908:      	add	x19, sp, #0x578
    190c:      	orr	x16, x19, x8
    1910:      	ldrb	w16, [x16]
    1914:      	add	x0, sp, #0x800
    1918:      	orr	x8, x0, x8, lsl #2
    191c:      	str	q3, [sp, #0x810]
    1920:      	str	q2, [sp, #0x800]
    1924:      	ldr	s16, [x8]
    1928:      	mov	w22, #0x4               ; =4
    192c:      	mov	w24, #0x2               ; =2
    1930:      	csel	w12, wzr, w24, ne
    1934:      	mov	w8, #0x6                ; =6
    1938:      	csel	w0, w8, w22, ne
    193c:      	str	x0, [sp, #0xf8]
    1940:      	tst	w2, w16
    1944:      	add	x16, sp, #0x578
    1948:      	bfxil	x16, x10, #0, #3
    194c:      	ldrb	w16, [x16]
    1950:      	add	x0, sp, #0x7e0
    1954:      	orr	x10, x0, x10, lsl #2
    1958:      	str	q3, [sp, #0x7f0]
    195c:      	str	q2, [sp, #0x7e0]
    1960:      	ldr	s17, [x10]
    1964:      	fcsel	s16, s16, s22, ne
    1968:      	tst	w1, w16
    196c:      	umov.b	w10, v26[4]
    1970:      	umov.b	w3, v26[5]
    1974:      	str	w3, [sp, #0x1d0]
    1978:      	umov.b	w0, v26[6]
    197c:      	str	w0, [sp, #0xac]
    1980:      	umov.b	w28, v26[7]
    1984:      	fcsel	s17, s17, s22, ne
    1988:      	ands	w2, w28, #0x1
    198c:      	csinc	w5, w8, wzr, ne
    1990:      	mov	w23, #0x5               ; =5
    1994:      	csel	w16, w23, w24, ne
    1998:      	ands	w1, w0, #0x1
    199c:      	csinc	w21, w4, wzr, ne
    19a0:      	csel	w0, w22, w24, ne
    19a4:      	ands	w6, w3, #0x1
    19a8:      	csinc	w27, w22, wzr, ne
    19ac:      	csel	w4, w4, w24, ne
    19b0:      	ands	w25, w10, #0x1
    19b4:      	csinc	w23, w23, wzr, ne
    19b8:      	orr	x22, x19, x23
    19bc:      	ldrb	w22, [x22]
    19c0:      	str	q3, [sp, #0x7d0]
    19c4:      	str	q2, [sp, #0x7c0]
    19c8:      	add	x3, sp, #0x7c0
    19cc:      	ldr	s18, [x3, w23, uxtw #2]
    19d0:      	csel	w23, w8, w24, ne
    19d4:      	mov	w24, #0x4               ; =4
    19d8:      	tst	w25, w22
    19dc:      	orr	x22, x19, x27
    19e0:      	ldrb	w22, [x22]
    19e4:      	str	q3, [sp, #0x7b0]
    19e8:      	str	q2, [sp, #0x7a0]
    19ec:      	add	x8, sp, #0x7a0
    19f0:      	ldr	s19, [x8, w27, uxtw #2]
    19f4:      	mov	x27, x11
    19f8:      	fcsel	s18, s18, s22, ne
    19fc:      	tst	w6, w22
    1a00:      	orr	x22, x19, x21
    1a04:      	ldrb	w22, [x22]
    1a08:      	str	q3, [sp, #0x790]
    1a0c:      	str	q2, [sp, #0x780]
    1a10:      	add	x8, sp, #0x780
    1a14:      	ldr	s20, [x8, w21, uxtw #2]
    1a18:      	fcsel	s19, s19, s22, ne
    1a1c:      	tst	w1, w22
    1a20:      	orr	x21, x19, x5
    1a24:      	ldrb	w21, [x21]
    1a28:      	str	q3, [sp, #0x770]
    1a2c:      	str	q2, [sp, #0x760]
    1a30:      	add	x8, sp, #0x760
    1a34:      	ldr	s21, [x8, w5, uxtw #2]
    1a38:      	fcsel	s20, s20, s22, ne
    1a3c:      	tst	w2, w21
    1a40:      	mov.s	v4[1], v7[0]
    1a44:      	mov.s	v4[2], v16[0]
    1a48:      	mov.s	v4[3], v17[0]
    1a4c:      	mov.s	v18[1], v19[0]
    1a50:      	fcsel	s7, s21, s22, ne
    1a54:      	mov.s	v18[2], v20[0]
    1a58:      	mov.s	v18[3], v7[0]
    1a5c:      	fmaxnm.4s	v7, v3, v18
    1a60:      	fmaxnm.4s	v2, v2, v4
    1a64:      	and	w3, w26, w11
    1a68:      	mov	s3, v2[2]
    1a6c:      	mov	w5, #0x2                ; =2
    1a70:      	bfxil	w5, w20, #0, #1
    1a74:      	orr	x21, x19, x5
    1a78:      	ldrb	w21, [x21]
    1a7c:      	add	x8, sp, #0x740
    1a80:      	orr	x5, x8, x5, lsl #2
    1a84:      	str	q7, [sp, #0x750]
    1a88:      	str	q2, [sp, #0x740]
    1a8c:      	ldr	s4, [x5]
    1a90:      	tst	w3, #0x1
    1a94:      	fcsel	s3, s3, s22, ne
    1a98:      	tst	w30, w21
    1a9c:      	lsr	x5, x12, #1
    1aa0:      	add	x21, sp, #0x720
    1aa4:      	bfi	x21, x5, #3, #1
    1aa8:      	orr	x5, x19, x12
    1aac:      	ldrb	w5, [x5]
    1ab0:      	str	q7, [sp, #0x730]
    1ab4:      	str	q2, [sp, #0x720]
    1ab8:      	ldr	s16, [x21]
    1abc:      	fcsel	s4, s4, s22, ne
    1ac0:      	ldp	w21, w12, [sp, #0xe0]
    1ac4:      	tst	w12, w5
    1ac8:      	add	x5, sp, #0x578
    1acc:      	bfxil	x5, x17, #0, #3
    1ad0:      	ldrb	w5, [x5]
    1ad4:      	add	x8, sp, #0x700
    1ad8:      	orr	x17, x8, x17, lsl #2
    1adc:      	str	q7, [sp, #0x710]
    1ae0:      	str	q2, [sp, #0x700]
    1ae4:      	ldr	s17, [x17]
    1ae8:      	fcsel	s16, s16, s22, ne
    1aec:      	tst	w21, w5
    1af0:      	fcsel	s17, s17, s22, ne
    1af4:      	orr	x17, x19, x23
    1af8:      	ldrb	w17, [x17]
    1afc:      	tst	w25, w17
    1b00:      	str	q7, [sp, #0x6f0]
    1b04:      	str	q2, [sp, #0x6e0]
    1b08:      	add	x8, sp, #0x6e0
    1b0c:      	ldr	s18, [x8, w23, uxtw #2]
    1b10:      	orr	x17, x19, x4
    1b14:      	ldrb	w17, [x17]
    1b18:      	str	q7, [sp, #0x6d0]
    1b1c:      	str	q2, [sp, #0x6c0]
    1b20:      	add	x8, sp, #0x6c0
    1b24:      	ldr	s19, [x8, w4, uxtw #2]
    1b28:      	fcsel	s18, s18, s22, ne
    1b2c:      	tst	w6, w17
    1b30:      	fcsel	s19, s19, s22, ne
    1b34:      	orr	x17, x19, x0
    1b38:      	ldrb	w17, [x17]
    1b3c:      	tst	w1, w17
    1b40:      	str	q7, [sp, #0x6b0]
    1b44:      	str	q2, [sp, #0x6a0]
    1b48:      	add	x8, sp, #0x6a0
    1b4c:      	ldr	s20, [x8, w0, uxtw #2]
    1b50:      	fcsel	s20, s20, s22, ne
    1b54:      	orr	x17, x19, x16
    1b58:      	ldrb	w17, [x17]
    1b5c:      	str	q7, [sp, #0x690]
    1b60:      	str	q2, [sp, #0x680]
    1b64:      	add	x8, sp, #0x680
    1b68:      	ldr	s21, [x8, w16, uxtw #2]
    1b6c:      	tst	w2, w17
    1b70:      	fcsel	s21, s21, s22, ne
    1b74:      	mov.s	v18[1], v19[0]
    1b78:      	mov.s	v18[2], v20[0]
    1b7c:      	mov.s	v18[3], v21[0]
    1b80:      	fmaxnm.4s	v7, v7, v18
    1b84:      	str	w10, [sp, #0xf4]
    1b88:      	and	w17, w26, w10
    1b8c:      	mov	x10, x24
    1b90:      	str	w20, [sp, #0x110]
    1b94:      	bfxil	w10, w20, #0, #1
    1b98:      	orr	x16, x19, x10
    1b9c:      	ldrb	w16, [x16]
    1ba0:      	tst	w17, #0x1
    1ba4:      	fcsel	s18, s7, s22, ne
    1ba8:      	tst	w30, w16
    1bac:      	mov.s	v3[1], v4[0]
    1bb0:      	mov.s	v3[2], v16[0]
    1bb4:      	mov.s	v3[3], v17[0]
    1bb8:      	fmaxnm.4s	v2, v2, v3
    1bbc:      	str	q7, [sp, #0x670]
    1bc0:      	str	q2, [sp, #0x660]
    1bc4:      	add	x8, sp, #0x660
    1bc8:      	ldr	s3, [x8, w10, uxtw #2]
    1bcc:      	fcsel	s3, s3, s22, ne
    1bd0:      	ldr	x11, [sp, #0xf8]
    1bd4:      	orr	x10, x19, x11
    1bd8:      	ldrb	w10, [x10]
    1bdc:      	str	q7, [sp, #0x650]
    1be0:      	str	q2, [sp, #0x640]
    1be4:      	add	x8, sp, #0x640
    1be8:      	ldr	s4, [x8, w11, uxtw #2]
    1bec:      	tst	w12, w10
    1bf0:      	fcsel	s4, s4, s22, ne
    1bf4:      	ldr	x11, [sp, #0x100]
    1bf8:      	orr	x8, x19, x11
    1bfc:      	ldrb	w8, [x8]
    1c00:      	str	q7, [sp, #0x630]
    1c04:      	str	q2, [sp, #0x620]
    1c08:      	add	x10, sp, #0x620
    1c0c:      	ldr	s7, [x10, w11, uxtw #2]
    1c10:      	tst	w21, w8
    1c14:      	fcsel	s7, s7, s22, ne
    1c18:      	mov.s	v18[1], v3[0]
    1c1c:      	mov.s	v18[2], v4[0]
    1c20:      	ldr	w8, [sp, #0xbc]
    1c24:      	mov	x25, x8
    1c28:      	tst	w8, #0x1
    1c2c:      	mov.s	v18[3], v7[0]
    1c30:      	fmaxnm.4s	v2, v2, v18
    1c34:      	fcsel	s3, s2, s22, ne
    1c38:      	str	w3, [sp, #0x100]
    1c3c:      	tst	w3, #0x1
    1c40:      	fcsel	s4, s2, s22, ne
    1c44:      	str	w17, [sp, #0xf8]
    1c48:      	tst	w17, #0x1
    1c4c:      	fcsel	s7, s2, s22, ne
    1c50:      	tst	w26, #0x1
    1c54:      	ldr	x8, [sp, #0xb0]
    1c58:      	mov	x3, x8
    1c5c:      	and	w8, w8, w26
    1c60:      	fcsel	s16, s2, s22, ne
    1c64:      	str	w8, [sp, #0xe4]
    1c68:      	tst	w8, #0x1
    1c6c:      	fcsel	s17, s2, s22, ne
    1c70:      	ldr	w8, [sp, #0x1d0]
    1c74:      	and	w8, w8, w26
    1c78:      	str	w8, [sp, #0xe0]
    1c7c:      	tst	w8, #0x1
    1c80:      	fcsel	s18, s2, s22, ne
    1c84:      	ldr	w8, [sp, #0xac]
    1c88:      	mov	x11, x8
    1c8c:      	and	w8, w8, w26
    1c90:      	str	w8, [sp, #0xdc]
    1c94:      	tst	w8, #0x1
    1c98:      	fcsel	s19, s2, s22, ne
    1c9c:      	and	w8, w28, w26
    1ca0:      	str	w8, [sp, #0xd8]
    1ca4:      	tst	w8, #0x1
    1ca8:      	mov.s	v16[1], v3[0]
    1cac:      	mov.s	v16[2], v4[0]
    1cb0:      	mov.s	v16[3], v17[0]
    1cb4:      	mov.s	v7[1], v18[0]
    1cb8:      	fcsel	s2, s2, s22, ne
    1cbc:      	mov.s	v7[2], v19[0]
    1cc0:      	mov.s	v7[3], v2[0]
    1cc4:      	ldr	w8, [sp, #0x120]
    1cc8:      	rbit	w8, w8
    1ccc:      	clz	w8, w8
    1cd0:      	str	q7, [sp, #0x590]
    1cd4:      	str	q16, [sp, #0x580]
    1cd8:      	str	x8, [sp, #0xd0]
    1cdc:      	and	x8, x8, #0x7
    1ce0:      	add	x10, sp, #0x580
    1ce4:      	ldr	s2, [x10, x8, lsl #2]
    1ce8:      	str	q26, [sp, #0x120]
    1cec:      	mov.b	v26[0], wzr
    1cf0:      	str	q26, [sp, #0xc0]
    1cf4:      	mov	w8, #-0x800000          ; =-8388608
    1cf8:      	fmov	s3, w8
    1cfc:      	fmaxnm	s2, s2, s3
    1d00:      	dup.4s	v4, v2[0]
    1d04:      	movi.2d	v13, #0000000000000000
    1d08:      	movi.2d	v11, #0000000000000000
    1d0c:      	movi.2d	v12, #0000000000000000
    1d10:      	movi.2d	v8, #0000000000000000
    1d14:      	mov	w12, #-0x3d300000       ; =-1026555904
    1d18:      	mov	w16, #0x42c80000        ; =1120403456
    1d1c:      	mov	w17, #0xaa3b            ; =43579
    1d20:      	movk	w17, #0x3fb8, lsl #16
    1d24:      	mov	w0, #0x7200             ; =29184
    1d28:      	movk	w0, #0xbf31, lsl #16
    1d2c:      	mov	w1, #0xbe8e             ; =48782
    1d30:      	movk	w1, #0xb5bf, lsl #16
    1d34:      	mov	w4, #0x2bda             ; =11226
    1d38:      	movk	w4, #0x3950, lsl #16
    1d3c:      	mov	w5, #0x96c9             ; =38601
    1d40:      	movk	w5, #0x3ab6, lsl #16
    1d44:      	mov	w6, #0x88a6             ; =34982
    1d48:      	movk	w6, #0x3c08, lsl #16
    1d4c:      	mov	w21, #0xaa7a            ; =43642
    1d50:      	movk	w21, #0x3d2a, lsl #16
    1d54:      	mov	w22, #0xaaab            ; =43691
    1d58:      	movk	w22, #0x3e2a, lsl #16
    1d5c:      	ldr	x20, [sp, #0x8]
    1d60:      	ldr	x19, [sp, #0xe8]
    1d64:      	b	0x1f70 <_llm_rows.packet_batch.blocks+0x15d4>
    1d68:      	lsl	x8, x13, #5
    1d6c:      	add	x10, x15, x8
    1d70:      	ldp	q3, q2, [x10]
    1d74:      	fsub.4s	v3, v3, v4
    1d78:      	fsub.4s	v2, v2, v4
    1d7c:      	and.16b	v24, v0, v2
    1d80:      	and.16b	v19, v1, v3
    1d84:      	dup.4s	v22, w12
    1d88:      	fcmge.4s	v2, v19, v22
    1d8c:      	fcmge.4s	v3, v24, v22
    1d90:      	dup.4s	v10, w16
    1d94:      	fcmge.4s	v7, v10, v19
    1d98:      	fcmge.4s	v16, v10, v24
    1d9c:      	and.16b	v3, v3, v16
    1da0:      	and.16b	v2, v2, v7
    1da4:      	and.16b	v2, v2, v19
    1da8:      	and.16b	v7, v3, v24
    1dac:      	dup.4s	v9, w17
    1db0:      	fmul.4s	v3, v7, v9
    1db4:      	fmul.4s	v16, v2, v9
    1db8:      	movi.4s	v20, #0x4b, lsl #24
    1dbc:      	mvni.4s	v21, #0x80, lsl #24
    1dc0:      	mov.16b	v17, v21
    1dc4:      	bsl.16b	v17, v20, v16
    1dc8:      	bif.16b	v20, v3, v21
    1dcc:      	fadd.4s	v3, v3, v20
    1dd0:      	fadd.4s	v16, v16, v17
    1dd4:      	fsub.4s	v16, v16, v17
    1dd8:      	fsub.4s	v3, v3, v20
    1ddc:      	fcvtzs.4s	v25, v3
    1de0:      	fcvtzs.4s	v26, v16
    1de4:      	scvtf.4s	v16, v26
    1de8:      	scvtf.4s	v17, v25
    1dec:      	dup.4s	v3, w0
    1df0:      	fmul.4s	v20, v17, v3
    1df4:      	fmul.4s	v21, v16, v3
    1df8:      	fadd.4s	v2, v2, v21
    1dfc:      	fadd.4s	v7, v7, v20
    1e00:      	dup.4s	v23, w1
    1e04:      	fmul.4s	v16, v16, v23
    1e08:      	fmul.4s	v17, v17, v23
    1e0c:      	fadd.4s	v7, v7, v17
    1e10:      	fadd.4s	v27, v2, v16
    1e14:      	dup.4s	v2, w4
    1e18:      	fmul.4s	v16, v27, v2
    1e1c:      	fmul.4s	v17, v7, v2
    1e20:      	dup.4s	v20, w5
    1e24:      	fadd.4s	v17, v17, v20
    1e28:      	fadd.4s	v16, v16, v20
    1e2c:      	fmul.4s	v16, v27, v16
    1e30:      	fmul.4s	v17, v7, v17
    1e34:      	dup.4s	v21, w6
    1e38:      	fadd.4s	v17, v17, v21
    1e3c:      	fadd.4s	v16, v16, v21
    1e40:      	fmul.4s	v28, v27, v16
    1e44:      	fmul.4s	v17, v7, v17
    1e48:      	dup.4s	v16, w21
    1e4c:      	fadd.4s	v17, v17, v16
    1e50:      	fadd.4s	v28, v28, v16
    1e54:      	fmul.4s	v28, v27, v28
    1e58:      	fmul.4s	v29, v7, v17
    1e5c:      	dup.4s	v17, w22
    1e60:      	fadd.4s	v29, v29, v17
    1e64:      	fadd.4s	v28, v28, v17
    1e68:      	fmul.4s	v28, v27, v28
    1e6c:      	fmul.4s	v29, v7, v29
    1e70:      	movi.4s	v30, #0x3f, lsl #24
    1e74:      	fadd.4s	v29, v29, v30
    1e78:      	fadd.4s	v28, v28, v30
    1e7c:      	fmul.4s	v30, v7, v7
    1e80:      	fmul.4s	v31, v27, v27
    1e84:      	fmul.4s	v28, v31, v28
    1e88:      	fmul.4s	v29, v30, v29
    1e8c:      	fadd.4s	v29, v7, v29
    1e90:      	fadd.4s	v27, v27, v28
    1e94:      	fmov.4s	v7, #1.00000000
    1e98:      	fadd.4s	v27, v27, v7
    1e9c:      	fadd.4s	v28, v29, v7
    1ea0:      	sshr.4s	v29, v26, #0x1
    1ea4:      	sshr.4s	v30, v25, #0x1
    1ea8:      	shl.4s	v31, v30, #0x17
    1eac:      	add.4s	v31, v31, v7
    1eb0:      	fmul.4s	v28, v28, v31
    1eb4:      	shl.4s	v31, v29, #0x17
    1eb8:      	add.4s	v31, v31, v7
    1ebc:      	fmul.4s	v27, v27, v31
    1ec0:      	sub.4s	v25, v25, v30
    1ec4:      	sub.4s	v26, v26, v29
    1ec8:      	shl.4s	v26, v26, #0x17
    1ecc:      	add.4s	v26, v26, v7
    1ed0:      	fmul.4s	v26, v27, v26
    1ed4:      	shl.4s	v25, v25, #0x17
    1ed8:      	add.4s	v25, v25, v7
    1edc:      	fmul.4s	v25, v28, v25
    1ee0:      	fcmgt.4s	v27, v22, v24
    1ee4:      	bic.16b	v25, v25, v27
    1ee8:      	fcmgt.4s	v27, v22, v19
    1eec:      	bic.16b	v26, v26, v27
    1ef0:      	fcmgt.4s	v27, v19, v10
    1ef4:      	ldr	q28, [sp, #0x2b0]
    1ef8:      	bit.16b	v26, v28, v27
    1efc:      	fcmgt.4s	v27, v24, v10
    1f00:      	bit.16b	v25, v28, v27
    1f04:      	fcmeq.4s	v24, v24, v24
    1f08:      	ldr	q27, [sp, #0x2a0]
    1f0c:      	bsl.16b	v24, v25, v27
    1f10:      	cmeq.8b	v18, v18, #0
    1f14:      	sshll.8h	v18, v18, #0x0
    1f18:      	fcmeq.4s	v19, v19, v19
    1f1c:      	bsl.16b	v19, v26, v27
    1f20:      	sshll.4s	v25, v18, #0x0
    1f24:      	bic.16b	v19, v19, v25
    1f28:      	sshll2.4s	v18, v18, #0x0
    1f2c:      	bic.16b	v18, v24, v18
    1f30:      	add	x8, x9, x8
    1f34:      	ldp	q24, q25, [x8]
    1f38:      	bif.16b	v18, v25, v0
    1f3c:      	bif.16b	v19, v24, v1
    1f40:      	stp	q19, q18, [x8]
    1f44:      	fmov	x8, d13
    1f48:      	ldr	q18, [sp, #0x2c0]
    1f4c:      	add.2d	v13, v13, v18
    1f50:      	ldp	q18, q19, [sp, #0x2d0]
    1f54:      	add.2d	v11, v11, v19
    1f58:      	add.2d	v12, v12, v18
    1f5c:      	ldr	q18, [sp, #0x2f0]
    1f60:      	add.2d	v8, v8, v18
    1f64:      	add	x13, x8, x14
    1f68:      	cmp	x13, #0x200
    1f6c:      	b.ge	0x2058 <_llm_rows.packet_batch.blocks+0x16bc>
    1f70:      	ldr	q2, [sp, #0x300]
    1f74:      	fmov	w8, s2
    1f78:      	ldp	q2, q20, [sp, #0x220]
    1f7c:      	add.2d	v2, v13, v2
    1f80:      	ldr	q3, [sp, #0x260]
    1f84:      	add.2d	v2, v3, v2
    1f88:      	tbz	w8, #0x0, 0x1fac <_llm_rows.packet_batch.blocks+0x1610>
    1f8c:      	fmov	x10, d2
    1f90:      	ldr	b18, [x10]
    1f94:      	ldp	q7, q3, [sp, #0x280]
    1f98:      	ldr	q16, [sp, #0x270]
    1f9c:      	ldp	q19, q17, [sp, #0x240]
    1fa0:      	and	w8, w8, #0xff
    1fa4:      	tbnz	w8, #0x1, 0x1fc4 <_llm_rows.packet_batch.blocks+0x1628>
    1fa8:      	b	0x1fcc <_llm_rows.packet_batch.blocks+0x1630>
    1fac:      	movi.2d	v18, #0000000000000000
    1fb0:      	ldp	q7, q3, [sp, #0x280]
    1fb4:      	ldr	q16, [sp, #0x270]
    1fb8:      	ldp	q19, q17, [sp, #0x240]
    1fbc:      	and	w8, w8, #0xff
    1fc0:      	tbz	w8, #0x1, 0x1fcc <_llm_rows.packet_batch.blocks+0x1630>
    1fc4:      	mov.d	x10, v2[1]
    1fc8:      	ld1.b	{ v18 }[1], [x10]
    1fcc:      	add.2d	v2, v11, v19
    1fd0:      	add.2d	v2, v7, v2
    1fd4:      	tbnz	w8, #0x2, 0x2000 <_llm_rows.packet_batch.blocks+0x1664>
    1fd8:      	tbnz	w8, #0x3, 0x200c <_llm_rows.packet_batch.blocks+0x1670>
    1fdc:      	add.2d	v2, v12, v20
    1fe0:      	add.2d	v2, v16, v2
    1fe4:      	tbnz	w8, #0x4, 0x2020 <_llm_rows.packet_batch.blocks+0x1684>
    1fe8:      	tbnz	w8, #0x5, 0x202c <_llm_rows.packet_batch.blocks+0x1690>
    1fec:      	add.2d	v2, v8, v17
    1ff0:      	add.2d	v2, v3, v2
    1ff4:      	tbnz	w8, #0x6, 0x2040 <_llm_rows.packet_batch.blocks+0x16a4>
    1ff8:      	tbz	w8, #0x7, 0x1d68 <_llm_rows.packet_batch.blocks+0x13cc>
    1ffc:      	b	0x204c <_llm_rows.packet_batch.blocks+0x16b0>
    2000:      	fmov	x10, d2
    2004:      	ld1.b	{ v18 }[2], [x10]
    2008:      	tbz	w8, #0x3, 0x1fdc <_llm_rows.packet_batch.blocks+0x1640>
    200c:      	mov.d	x10, v2[1]
    2010:      	ld1.b	{ v18 }[3], [x10]
    2014:      	add.2d	v2, v12, v20
    2018:      	add.2d	v2, v16, v2
    201c:      	tbz	w8, #0x4, 0x1fe8 <_llm_rows.packet_batch.blocks+0x164c>
    2020:      	fmov	x10, d2
    2024:      	ld1.b	{ v18 }[4], [x10]
    2028:      	tbz	w8, #0x5, 0x1fec <_llm_rows.packet_batch.blocks+0x1650>
    202c:      	mov.d	x10, v2[1]
    2030:      	ld1.b	{ v18 }[5], [x10]
    2034:      	add.2d	v2, v8, v17
    2038:      	add.2d	v2, v3, v2
    203c:      	tbz	w8, #0x6, 0x1ff8 <_llm_rows.packet_batch.blocks+0x165c>
    2040:      	fmov	x10, d2
    2044:      	ld1.b	{ v18 }[6], [x10]
    2048:      	tbz	w8, #0x7, 0x1d68 <_llm_rows.packet_batch.blocks+0x13cc>
    204c:      	mov.d	x8, v2[1]
    2050:      	ld1.b	{ v18 }[7], [x8]
    2054:      	b	0x1d68 <_llm_rows.packet_batch.blocks+0x13cc>
    2058:      	ldr	d18, [sp, #0x1f0]
    205c:      	fmov	w8, s18
    2060:      	tbz	w8, #0x0, 0x20ac <_llm_rows.packet_batch.blocks+0x1710>
    2064:      	ldr	q18, [sp, #0x30]
    2068:      	fmov	x10, d18
    206c:      	ldr	b18, [x10]
    2070:      	ldr	q27, [sp, #0x200]
    2074:      	ldp	q13, q12, [sp, #0x2e0]
    2078:      	tbnz	w8, #0x1, 0x20bc <_llm_rows.packet_batch.blocks+0x1720>
    207c:      	b	0x20c4 <_llm_rows.packet_batch.blocks+0x1728>
    2080:      	fmov	x10, d24
    2084:      	ld1.b	{ v2 }[2], [x10]
    2088:      	tbz	w8, #0x3, 0x15ec <_llm_rows.packet_batch.blocks+0xc50>
    208c:      	ld1.b	{ v2 }[3], [x0]
    2090:      	tbz	w8, #0x4, 0x15f0 <_llm_rows.packet_batch.blocks+0xc54>
    2094:      	fmov	x10, d21
    2098:      	ld1.b	{ v2 }[4], [x10]
    209c:      	tbz	w8, #0x5, 0x15f4 <_llm_rows.packet_batch.blocks+0xc58>
    20a0:      	ld1.b	{ v2 }[5], [x16]
    20a4:      	tbnz	w8, #0x6, 0x15f8 <_llm_rows.packet_batch.blocks+0xc5c>
    20a8:      	b	0x1600 <_llm_rows.packet_batch.blocks+0xc64>
    20ac:      	movi.2d	v18, #0000000000000000
    20b0:      	ldr	q27, [sp, #0x200]
    20b4:      	ldp	q13, q12, [sp, #0x2e0]
    20b8:      	tbz	w8, #0x1, 0x20c4 <_llm_rows.packet_batch.blocks+0x1728>
    20bc:      	ldr	x10, [sp, #0x48]
    20c0:      	ld1.b	{ v18 }[1], [x10]
    20c4:      	tbnz	w8, #0x2, 0x290c <_llm_rows.packet_batch.blocks+0x1f70>
    20c8:      	tbnz	w8, #0x3, 0x291c <_llm_rows.packet_batch.blocks+0x1f80>
    20cc:      	tbnz	w8, #0x4, 0x2928 <_llm_rows.packet_batch.blocks+0x1f8c>
    20d0:      	tbnz	w8, #0x5, 0x2938 <_llm_rows.packet_batch.blocks+0x1f9c>
    20d4:      	tbnz	w8, #0x6, 0x2944 <_llm_rows.packet_batch.blocks+0x1fa8>
    20d8:      	tbz	w8, #0x7, 0x20e4 <_llm_rows.packet_batch.blocks+0x1748>
    20dc:      	ldr	x8, [sp, #0xa0]
    20e0:      	ld1.b	{ v18 }[7], [x8]
    20e4:      	cmeq.8b	v18, v18, #0
    20e8:      	sshll.8h	v18, v18, #0x0
    20ec:      	sshll2.4s	v24, v18, #0x0
    20f0:      	sshll.4s	v18, v18, #0x0
    20f4:      	ldr	x10, [sp, #0x1f8]
    20f8:      	add	x8, x15, x10
    20fc:      	ldp	q25, q19, [x8]
    2100:      	fsub.4s	v26, v25, v4
    2104:      	fsub.4s	v19, v19, v4
    2108:      	zip2.8b	v4, v27, v0
    210c:      	ushll.4s	v4, v4, #0x0
    2110:      	shl.4s	v4, v4, #0x1f
    2114:      	cmlt.4s	v4, v4, #0
    2118:      	and.16b	v25, v4, v19
    211c:      	zip1.8b	v19, v27, v0
    2120:      	ushll.4s	v19, v19, #0x0
    2124:      	shl.4s	v19, v19, #0x1f
    2128:      	cmlt.4s	v19, v19, #0
    212c:      	and.16b	v26, v19, v26
    2130:      	fcmge.4s	v27, v26, v22
    2134:      	fcmge.4s	v28, v25, v22
    2138:      	fcmge.4s	v29, v10, v26
    213c:      	fcmge.4s	v30, v10, v25
    2140:      	and.16b	v28, v28, v30
    2144:      	and.16b	v27, v27, v29
    2148:      	and.16b	v27, v27, v26
    214c:      	and.16b	v28, v28, v25
    2150:      	fmul.4s	v29, v28, v9
    2154:      	fmul.4s	v30, v27, v9
    2158:      	movi.4s	v8, #0x4b, lsl #24
    215c:      	mvni.4s	v9, #0x80, lsl #24
    2160:      	mov.16b	v31, v9
    2164:      	bsl.16b	v31, v8, v30
    2168:      	bif.16b	v8, v29, v9
    216c:      	fadd.4s	v29, v29, v8
    2170:      	fadd.4s	v30, v30, v31
    2174:      	fsub.4s	v30, v30, v31
    2178:      	fsub.4s	v29, v29, v8
    217c:      	fcvtzs.4s	v29, v29
    2180:      	fcvtzs.4s	v30, v30
    2184:      	scvtf.4s	v31, v30
    2188:      	scvtf.4s	v8, v29
    218c:      	fmul.4s	v9, v8, v3
    2190:      	fmul.4s	v3, v31, v3
    2194:      	fadd.4s	v3, v27, v3
    2198:      	fadd.4s	v27, v28, v9
    219c:      	fmul.4s	v28, v31, v23
    21a0:      	fmul.4s	v23, v8, v23
    21a4:      	fadd.4s	v23, v27, v23
    21a8:      	fadd.4s	v3, v3, v28
    21ac:      	fmul.4s	v27, v3, v2
    21b0:      	fmul.4s	v2, v23, v2
    21b4:      	fadd.4s	v2, v2, v20
    21b8:      	fadd.4s	v20, v27, v20
    21bc:      	fmul.4s	v20, v3, v20
    21c0:      	fmul.4s	v2, v23, v2
    21c4:      	fadd.4s	v2, v2, v21
    21c8:      	fadd.4s	v20, v20, v21
    21cc:      	fmul.4s	v20, v3, v20
    21d0:      	fmul.4s	v2, v23, v2
    21d4:      	fadd.4s	v2, v2, v16
    21d8:      	fadd.4s	v16, v20, v16
    21dc:      	fmul.4s	v16, v3, v16
    21e0:      	fmul.4s	v2, v23, v2
    21e4:      	fadd.4s	v2, v2, v17
    21e8:      	fadd.4s	v16, v16, v17
    21ec:      	fmul.4s	v16, v3, v16
    21f0:      	fmul.4s	v2, v23, v2
    21f4:      	movi.4s	v17, #0x3f, lsl #24
    21f8:      	fadd.4s	v2, v2, v17
    21fc:      	fadd.4s	v16, v16, v17
    2200:      	fmul.4s	v17, v23, v23
    2204:      	fmul.4s	v20, v3, v3
    2208:      	fmul.4s	v16, v20, v16
    220c:      	fmul.4s	v2, v17, v2
    2210:      	fadd.4s	v2, v23, v2
    2214:      	fadd.4s	v3, v3, v16
    2218:      	fadd.4s	v3, v3, v7
    221c:      	fadd.4s	v2, v2, v7
    2220:      	sshr.4s	v16, v30, #0x1
    2224:      	sshr.4s	v17, v29, #0x1
    2228:      	shl.4s	v20, v17, #0x17
    222c:      	shl.4s	v21, v16, #0x17
    2230:      	add.4s	v21, v21, v7
    2234:      	add.4s	v20, v20, v7
    2238:      	fmul.4s	v2, v2, v20
    223c:      	fmul.4s	v3, v3, v21
    2240:      	sub.4s	v17, v29, v17
    2244:      	sub.4s	v16, v30, v16
    2248:      	shl.4s	v16, v16, #0x17
    224c:      	shl.4s	v17, v17, #0x17
    2250:      	add.4s	v17, v17, v7
    2254:      	add.4s	v7, v16, v7
    2258:      	fmul.4s	v3, v3, v7
    225c:      	fmul.4s	v2, v2, v17
    2260:      	fcmgt.4s	v7, v22, v25
    2264:      	bic.16b	v2, v2, v7
    2268:      	fcmgt.4s	v7, v22, v26
    226c:      	bic.16b	v3, v3, v7
    2270:      	fcmgt.4s	v7, v25, v10
    2274:      	fcmgt.4s	v16, v26, v10
    2278:      	ldp	q17, q20, [sp, #0x2a0]
    227c:      	bit.16b	v3, v20, v16
    2280:      	bit.16b	v2, v20, v7
    2284:      	fcmeq.4s	v7, v26, v26
    2288:      	fcmeq.4s	v16, v25, v25
    228c:      	bif.16b	v2, v17, v16
    2290:      	bif.16b	v3, v17, v7
    2294:      	bic.16b	v18, v3, v18
    2298:      	bic.16b	v20, v2, v24
    229c:      	add	x8, x9, x10
    22a0:      	ldp	q2, q3, [x8]
    22a4:      	bit.16b	v3, v20, v4
    22a8:      	bit.16b	v2, v18, v19
    22ac:      	stp	q2, q3, [x8]
    22b0:      	ldp	q3, q2, [x9, #0x60]
    22b4:      	and.16b	v2, v0, v2
    22b8:      	and.16b	v3, v1, v3
    22bc:      	ldp	q4, q7, [x9, #0x40]
    22c0:      	and.16b	v7, v0, v7
    22c4:      	and.16b	v4, v1, v4
    22c8:      	ldp	q17, q16, [x9, #0x20]
    22cc:      	and.16b	v16, v0, v16
    22d0:      	and.16b	v17, v1, v17
    22d4:      	ldp	q19, q21, [x9]
    22d8:      	and.16b	v21, v0, v21
    22dc:      	and.16b	v19, v1, v19
    22e0:      	ldr	q10, [sp, #0x1e0]
    22e4:      	ldr	q11, [sp, #0x310]
    22e8:      	sshll.2d	v24, v1, #0x0
    22ec:      	sshll.2d	v25, v0, #0x0
    22f0:      	add	x8, x9, x7, lsl #5
    22f4:      	ldp	q22, q23, [x8]
    22f8:      	fadd.4s	v22, v19, v22
    22fc:      	fadd.4s	v23, v21, v23
    2300:      	ldp	q27, q26, [x8, #0x20]
    2304:      	fadd.4s	v27, v17, v27
    2308:      	fadd.4s	v26, v16, v26
    230c:      	ldp	q29, q28, [x8, #0x40]
    2310:      	fadd.4s	v29, v4, v29
    2314:      	fadd.4s	v28, v7, v28
    2318:      	ldp	q31, q30, [x8, #0x60]
    231c:      	fadd.4s	v31, v3, v31
    2320:      	fadd.4s	v30, v2, v30
    2324:      	dup.2d	v8, x24
    2328:      	and.16b	v9, v11, v8
    232c:      	add.2d	v14, v14, v9
    2330:      	and.16b	v9, v10, v8
    2334:      	add.2d	v15, v15, v9
    2338:      	and.16b	v25, v25, v8
    233c:      	add.2d	v5, v5, v25
    2340:      	and.16b	v24, v24, v8
    2344:      	add.2d	v24, v6, v24
    2348:      	bit.16b	v21, v23, v0
    234c:      	bit.16b	v19, v22, v1
    2350:      	bit.16b	v16, v26, v0
    2354:      	bit.16b	v17, v27, v1
    2358:      	bit.16b	v7, v28, v0
    235c:      	bit.16b	v4, v29, v1
    2360:      	bit.16b	v2, v30, v0
    2364:      	bit.16b	v3, v31, v1
    2368:      	fmov	x8, d6
    236c:      	add	x10, x8, #0x4
    2370:      	tst	w26, #0x1
    2374:      	csel	x7, x10, x8, ne
    2378:      	mov.16b	v6, v24
    237c:      	cmp	x7, #0x200
    2380:      	b.lt	0x22e8 <_llm_rows.packet_batch.blocks+0x194c>
    2384:      	mov	x13, #0x0               ; =0
    2388:      	fadd.4s	v5, v20, v21
    238c:      	fadd.4s	v6, v18, v19
    2390:      	ldr	q21, [sp, #0x200]
    2394:      	zip1.8b	v18, v21, v0
    2398:      	ushll.4s	v18, v18, #0x0
    239c:      	shl.4s	v18, v18, #0x1f
    23a0:      	cmlt.4s	v18, v18, #0
    23a4:      	and.16b	v6, v18, v6
    23a8:      	zip2.8b	v18, v21, v0
    23ac:      	ushll.4s	v18, v18, #0x0
    23b0:      	shl.4s	v18, v18, #0x1f
    23b4:      	cmlt.4s	v18, v18, #0
    23b8:      	and.16b	v5, v18, v5
    23bc:      	ldr	q19, [sp, #0xc0]
    23c0:      	zip2.8b	v18, v19, v0
    23c4:      	ushll.4s	v18, v18, #0x0
    23c8:      	shl.4s	v18, v18, #0x1f
    23cc:      	cmlt.4s	v18, v18, #0
    23d0:      	bit.16b	v5, v23, v18
    23d4:      	zip1.8b	v18, v19, v0
    23d8:      	ushll.4s	v18, v18, #0x0
    23dc:      	shl.4s	v18, v18, #0x1f
    23e0:      	cmlt.4s	v18, v18, #0
    23e4:      	bit.16b	v6, v22, v18
    23e8:      	fadd.4s	v6, v17, v6
    23ec:      	fadd.4s	v5, v16, v5
    23f0:      	fadd.4s	v5, v7, v5
    23f4:      	fadd.4s	v4, v4, v6
    23f8:      	fadd.4s	v3, v3, v4
    23fc:      	fadd.4s	v2, v2, v5
    2400:      	add	x8, sp, #0x368
    2404:      	bfxil	x8, x26, #0, #1
    2408:      	ldr	q4, [sp, #0x120]
    240c:      	str	d4, [sp, #0x368]
    2410:      	ldrb	w8, [x8]
    2414:      	add	x10, sp, #0x550
    2418:      	bfi	x10, x26, #2, #1
    241c:      	str	q2, [sp, #0x560]
    2420:      	str	q3, [sp, #0x550]
    2424:      	ldr	s4, [x10]
    2428:      	ands	w12, w26, #0x1
    242c:      	mov	w17, #0x2               ; =2
    2430:      	csel	w30, w17, wzr, ne
    2434:      	csel	w15, w24, wzr, ne
    2438:      	tst	w12, w8
    243c:      	movi	d20, #0000000000000000
    2440:      	fcsel	s4, s4, s20, ne
    2444:      	tst	w25, #0x1
    2448:      	fcsel	s5, s3, s20, ne
    244c:      	ands	w8, w27, #0x1
    2450:      	mov	w10, #0x3               ; =3
    2454:      	csel	w10, w10, wzr, ne
    2458:      	add	x2, sp, #0x368
    245c:      	orr	x16, x2, x10
    2460:      	ldrb	w16, [x16]
    2464:      	add	x0, sp, #0x530
    2468:      	orr	x10, x0, x10, lsl #2
    246c:      	str	q2, [sp, #0x540]
    2470:      	str	q3, [sp, #0x530]
    2474:      	ldr	s6, [x10]
    2478:      	tst	w8, w16
    247c:      	fcsel	s6, s6, s20, ne
    2480:      	mov	x27, x3
    2484:      	ands	w7, w27, #0x1
    2488:      	csel	w8, w17, wzr, ne
    248c:      	orr	x10, x2, x8
    2490:      	ldrb	w10, [x10]
    2494:      	lsr	x8, x8, #1
    2498:      	add	x16, sp, #0x510
    249c:      	bfi	x16, x8, #3, #1
    24a0:      	str	q2, [sp, #0x520]
    24a4:      	str	q3, [sp, #0x510]
    24a8:      	ldr	s7, [x16]
    24ac:      	tst	w7, w10
    24b0:      	fcsel	s7, s7, s20, ne
    24b4:      	ands	w8, w28, #0x1
    24b8:      	mov	w28, #0x6               ; =6
    24bc:      	csel	w5, w28, wzr, ne
    24c0:      	mov	w4, #0x5                ; =5
    24c4:      	csel	w10, w4, wzr, ne
    24c8:      	ands	w0, w11, #0x1
    24cc:      	mov	w17, #0x7               ; =7
    24d0:      	csel	w21, w17, wzr, ne
    24d4:      	csel	w16, w24, wzr, ne
    24d8:      	ldr	w11, [sp, #0x1d0]
    24dc:      	ands	w1, w11, #0x1
    24e0:      	csel	w22, w24, wzr, ne
    24e4:      	csel	w17, w17, wzr, ne
    24e8:      	ldr	w3, [sp, #0xf4]
    24ec:      	ands	w6, w3, #0x1
    24f0:      	csel	w4, w4, wzr, ne
    24f4:      	orr	x23, x2, x4
    24f8:      	ldrb	w23, [x23]
    24fc:      	str	q2, [sp, #0x500]
    2500:      	str	q3, [sp, #0x4f0]
    2504:      	add	x3, sp, #0x4f0
    2508:      	ldr	s16, [x3, w4, uxtw #2]
    250c:      	csel	w4, w28, wzr, ne
    2510:      	tst	w6, w23
    2514:      	orr	x23, x2, x22
    2518:      	ldrb	w23, [x23]
    251c:      	str	q2, [sp, #0x4e0]
    2520:      	str	q3, [sp, #0x4d0]
    2524:      	add	x3, sp, #0x4d0
    2528:      	ldr	s17, [x3, w22, uxtw #2]
    252c:      	orr	x22, x2, x21
    2530:      	ldrb	w22, [x22]
    2534:      	str	q2, [sp, #0x4c0]
    2538:      	str	q3, [sp, #0x4b0]
    253c:      	add	x3, sp, #0x4b0
    2540:      	ldr	s18, [x3, w21, uxtw #2]
    2544:      	fcsel	s16, s16, s20, ne
    2548:      	tst	w1, w23
    254c:      	fcsel	s17, s17, s20, ne
    2550:      	tst	w0, w22
    2554:      	orr	x21, x2, x5
    2558:      	ldrb	w21, [x21]
    255c:      	str	q2, [sp, #0x4a0]
    2560:      	str	q3, [sp, #0x490]
    2564:      	add	x3, sp, #0x490
    2568:      	ldr	s19, [x3, w5, uxtw #2]
    256c:      	fcsel	s18, s18, s20, ne
    2570:      	tst	w8, w21
    2574:      	fcsel	s19, s19, s20, ne
    2578:      	mov.s	v16[1], v17[0]
    257c:      	mov.s	v16[2], v18[0]
    2580:      	mov.s	v16[3], v19[0]
    2584:      	mov.s	v4[1], v5[0]
    2588:      	mov.s	v4[2], v6[0]
    258c:      	lsr	x5, x30, #1
    2590:      	add	x21, sp, #0x470
    2594:      	bfi	x21, x5, #3, #1
    2598:      	mov.s	v4[3], v7[0]
    259c:      	fadd.4s	v3, v3, v4
    25a0:      	fadd.4s	v2, v2, v16
    25a4:      	orr	x5, x2, x30
    25a8:      	ldrb	w5, [x5]
    25ac:      	str	q2, [sp, #0x480]
    25b0:      	str	q3, [sp, #0x470]
    25b4:      	ldr	s4, [x21]
    25b8:      	tst	w12, w5
    25bc:      	fcsel	s4, s4, s20, ne
    25c0:      	ldr	w3, [sp, #0x110]
    25c4:      	ands	w5, w3, #0x1
    25c8:      	mov	w11, #0x3               ; =3
    25cc:      	csel	w21, w11, wzr, ne
    25d0:      	orr	x22, x2, x21
    25d4:      	ldrb	w22, [x22]
    25d8:      	tst	w5, w22
    25dc:      	add	x3, sp, #0x3b0
    25e0:      	orr	x5, x3, x21, lsl #2
    25e4:      	stp	q3, q2, [sp, #0x3b0]
    25e8:      	ldr	s5, [x5]
    25ec:      	add	x5, sp, #0x368
    25f0:      	bfxil	x5, x27, #0, #1
    25f4:      	ldrb	w5, [x5]
    25f8:      	fcsel	s5, s5, s20, ne
    25fc:      	ldr	w21, [sp, #0x100]
    2600:      	tst	w21, #0x1
    2604:      	fcsel	s6, s3, s20, ne
    2608:      	tst	w7, w5
    260c:      	add	x5, sp, #0x450
    2610:      	bfi	x5, x27, #2, #1
    2614:      	str	q2, [sp, #0x460]
    2618:      	str	q3, [sp, #0x450]
    261c:      	ldr	s7, [x5]
    2620:      	fcsel	s7, s7, s20, ne
    2624:      	orr	x5, x2, x4
    2628:      	ldrb	w5, [x5]
    262c:      	tst	w6, w5
    2630:      	str	q2, [sp, #0x440]
    2634:      	str	q3, [sp, #0x430]
    2638:      	add	x3, sp, #0x430
    263c:      	ldr	s16, [x3, w4, uxtw #2]
    2640:      	orr	x4, x2, x17
    2644:      	ldrb	w4, [x4]
    2648:      	str	q2, [sp, #0x420]
    264c:      	str	q3, [sp, #0x410]
    2650:      	add	x3, sp, #0x410
    2654:      	ldr	s17, [x3, w17, uxtw #2]
    2658:      	fcsel	s16, s16, s20, ne
    265c:      	tst	w1, w4
    2660:      	fcsel	s17, s17, s20, ne
    2664:      	orr	x17, x2, x16
    2668:      	ldrb	w17, [x17]
    266c:      	stp	q3, q2, [sp, #0x3f0]
    2670:      	add	x1, sp, #0x3f0
    2674:      	ldr	s18, [x1, w16, uxtw #2]
    2678:      	tst	w0, w17
    267c:      	fcsel	s18, s18, s20, ne
    2680:      	orr	x16, x2, x10
    2684:      	ldrb	w16, [x16]
    2688:      	stp	q3, q2, [sp, #0x3d0]
    268c:      	add	x17, sp, #0x3d0
    2690:      	ldr	s19, [x17, w10, uxtw #2]
    2694:      	tst	w8, w16
    2698:      	fcsel	s19, s19, s20, ne
    269c:      	mov.s	v4[1], v5[0]
    26a0:      	mov.s	v4[2], v6[0]
    26a4:      	mov.s	v4[3], v7[0]
    26a8:      	mov.s	v16[1], v17[0]
    26ac:      	mov.s	v16[2], v18[0]
    26b0:      	mov.s	v16[3], v19[0]
    26b4:      	fadd.4s	v3, v3, v4
    26b8:      	fadd.4s	v2, v2, v16
    26bc:      	orr	x8, x2, x15
    26c0:      	ldrb	w8, [x8]
    26c4:      	stp	q3, q2, [sp, #0x390]
    26c8:      	add	x10, sp, #0x390
    26cc:      	ldr	s2, [x10, w15, uxtw #2]
    26d0:      	tst	w12, w8
    26d4:      	fcsel	s2, s2, s20, ne
    26d8:      	tst	w26, #0x1
    26dc:      	fadd	s2, s3, s2
    26e0:      	fcsel	s3, s2, s20, ne
    26e4:      	tst	w25, #0x1
    26e8:      	fcsel	s4, s2, s20, ne
    26ec:      	tst	w21, #0x1
    26f0:      	fcsel	s5, s2, s20, ne
    26f4:      	ldr	w8, [sp, #0xe4]
    26f8:      	tst	w8, #0x1
    26fc:      	fcsel	s6, s2, s20, ne
    2700:      	ldr	w8, [sp, #0xf8]
    2704:      	tst	w8, #0x1
    2708:      	fcsel	s7, s2, s20, ne
    270c:      	ldp	w8, w10, [sp, #0xdc]
    2710:      	tst	w10, #0x1
    2714:      	fcsel	s16, s2, s20, ne
    2718:      	tst	w8, #0x1
    271c:      	fcsel	s17, s2, s20, ne
    2720:      	ldr	w8, [sp, #0xd8]
    2724:      	tst	w8, #0x1
    2728:      	fcsel	s2, s2, s20, ne
    272c:      	mov.s	v3[1], v4[0]
    2730:      	mov.s	v3[2], v5[0]
    2734:      	mov.s	v3[3], v6[0]
    2738:      	mov.s	v7[1], v16[0]
    273c:      	mov.s	v7[2], v17[0]
    2740:      	mov.s	v7[3], v2[0]
    2744:      	stp	q3, q7, [sp, #0x370]
    2748:      	ldr	x8, [sp, #0xd0]
    274c:      	and	x8, x8, #0x7
    2750:      	add	x10, sp, #0x370
    2754:      	ldr	s2, [x10, x8, lsl #2]
    2758:      	fadd	s2, s2, s20
    275c:      	dup.4s	v2, v2[0]
    2760:      	ldp	x8, x15, [sp, #0x180]
    2764:      	add	x8, x15, x8
    2768:      	movi.2d	v3, #0000000000000000
    276c:      	movi.2d	v4, #0000000000000000
    2770:      	movi.2d	v5, #0000000000000000
    2774:      	movi.2d	v6, #0000000000000000
    2778:      	ldr	w21, [sp, #0x2c]
    277c:      	ldr	x22, [sp, #0x20]
    2780:      	movi.8b	v10, #0x1
    2784:      	ldr	q17, [sp, #0x300]
    2788:      	ldr	x16, [sp, #0x178]
    278c:      	ldp	q19, q18, [sp, #0x2c0]
    2790:      	ldr	w27, [sp, #0x19c]
    2794:      	ldr	w26, [sp, #0x194]
    2798:      	b	0x27c0 <_llm_rows.packet_batch.blocks+0x1e24>
    279c:      	add.2d	v7, v3, v19
    27a0:      	add.2d	v4, v4, v13
    27a4:      	add.2d	v5, v5, v18
    27a8:      	add.2d	v6, v6, v12
    27ac:      	fmov	x10, d3
    27b0:      	add	x13, x10, x14
    27b4:      	mov.16b	v3, v7
    27b8:      	cmp	x13, #0x200
    27bc:      	b.ge	0x2870 <_llm_rows.packet_batch.blocks+0x1ed4>
    27c0:      	fmov	w11, s17
    27c4:      	lsl	x10, x13, #5
    27c8:      	add	x12, x9, x10
    27cc:      	ldp	q16, q7, [x12]
    27d0:      	and.16b	v16, v1, v16
    27d4:      	fdiv.4s	v16, v16, v2
    27d8:      	add	x10, x8, x10
    27dc:      	tbnz	w11, #0x0, 0x280c <_llm_rows.packet_batch.blocks+0x1e70>
    27e0:      	and	w11, w11, #0xff
    27e4:      	tbnz	w11, #0x1, 0x2818 <_llm_rows.packet_batch.blocks+0x1e7c>
    27e8:      	tbnz	w11, #0x2, 0x2824 <_llm_rows.packet_batch.blocks+0x1e88>
    27ec:      	tbnz	w11, #0x3, 0x2830 <_llm_rows.packet_batch.blocks+0x1e94>
    27f0:      	and.16b	v7, v0, v7
    27f4:      	fdiv.4s	v7, v7, v2
    27f8:      	tbnz	w11, #0x4, 0x2844 <_llm_rows.packet_batch.blocks+0x1ea8>
    27fc:      	tbnz	w11, #0x5, 0x284c <_llm_rows.packet_batch.blocks+0x1eb0>
    2800:      	tbnz	w11, #0x6, 0x2858 <_llm_rows.packet_batch.blocks+0x1ebc>
    2804:      	tbz	w11, #0x7, 0x279c <_llm_rows.packet_batch.blocks+0x1e00>
    2808:      	b	0x2864 <_llm_rows.packet_batch.blocks+0x1ec8>
    280c:      	str	s16, [x10]
    2810:      	and	w11, w11, #0xff
    2814:      	tbz	w11, #0x1, 0x27e8 <_llm_rows.packet_batch.blocks+0x1e4c>
    2818:      	add	x12, x10, #0x4
    281c:      	st1.s	{ v16 }[1], [x12]
    2820:      	tbz	w11, #0x2, 0x27ec <_llm_rows.packet_batch.blocks+0x1e50>
    2824:      	add	x12, x10, #0x8
    2828:      	st1.s	{ v16 }[2], [x12]
    282c:      	tbz	w11, #0x3, 0x27f0 <_llm_rows.packet_batch.blocks+0x1e54>
    2830:      	add	x12, x10, #0xc
    2834:      	st1.s	{ v16 }[3], [x12]
    2838:      	and.16b	v7, v0, v7
    283c:      	fdiv.4s	v7, v7, v2
    2840:      	tbz	w11, #0x4, 0x27fc <_llm_rows.packet_batch.blocks+0x1e60>
    2844:      	str	s7, [x10, #0x10]
    2848:      	tbz	w11, #0x5, 0x2800 <_llm_rows.packet_batch.blocks+0x1e64>
    284c:      	add	x12, x10, #0x14
    2850:      	st1.s	{ v7 }[1], [x12]
    2854:      	tbz	w11, #0x6, 0x2804 <_llm_rows.packet_batch.blocks+0x1e68>
    2858:      	add	x12, x10, #0x18
    285c:      	st1.s	{ v7 }[2], [x12]
    2860:      	tbz	w11, #0x7, 0x279c <_llm_rows.packet_batch.blocks+0x1e00>
    2864:      	add	x10, x10, #0x1c
    2868:      	st1.s	{ v7 }[3], [x10]
    286c:      	b	0x279c <_llm_rows.packet_batch.blocks+0x1e00>
    2870:      	ldr	x8, [sp, #0x1f8]
    2874:      	add	x8, x9, x8
    2878:      	ldp	q1, q0, [x8]
    287c:      	zip1.8b	v3, v21, v0
    2880:      	ushll.4s	v3, v3, #0x0
    2884:      	shl.4s	v3, v3, #0x1f
    2888:      	cmlt.4s	v3, v3, #0
    288c:      	and.16b	v1, v3, v1
    2890:      	ldr	d3, [sp, #0x1f0]
    2894:      	fmov	w8, s3
    2898:      	fdiv.4s	v1, v1, v2
    289c:      	ldr	q4, [sp, #0x160]
    28a0:      	ldp	q5, q6, [sp, #0x140]
    28a4:      	stp	q4, q5, [sp, #0x320]
    28a8:      	ldr	q3, [sp, #0x130]
    28ac:      	stp	q6, q3, [sp, #0x340]
    28b0:      	and	x9, x16, #0x7
    28b4:      	add	x10, sp, #0x320
    28b8:      	ldr	x9, [x10, x9, lsl #3]
    28bc:      	sub	x9, x9, x16
    28c0:      	add	x9, x15, x9, lsl #2
    28c4:      	ldr	w11, [sp, #0x198]
    28c8:      	tbnz	w8, #0x0, 0x2958 <_llm_rows.packet_batch.blocks+0x1fbc>
    28cc:      	tbnz	w8, #0x1, 0x2960 <_llm_rows.packet_batch.blocks+0x1fc4>
    28d0:      	tbnz	w8, #0x2, 0x296c <_llm_rows.packet_batch.blocks+0x1fd0>
    28d4:      	tbz	w8, #0x3, 0x28e0 <_llm_rows.packet_batch.blocks+0x1f44>
    28d8:      	add	x10, x9, #0xc
    28dc:      	st1.s	{ v1 }[3], [x10]
    28e0:      	zip2.8b	v1, v21, v0
    28e4:      	ushll.4s	v1, v1, #0x0
    28e8:      	shl.4s	v1, v1, #0x1f
    28ec:      	cmlt.4s	v1, v1, #0
    28f0:      	and.16b	v0, v1, v0
    28f4:      	fdiv.4s	v0, v0, v2
    28f8:      	tbnz	w8, #0x4, 0x297c <_llm_rows.packet_batch.blocks+0x1fe0>
    28fc:      	tbnz	w8, #0x5, 0x2984 <_llm_rows.packet_batch.blocks+0x1fe8>
    2900:      	tbnz	w8, #0x6, 0x2990 <_llm_rows.packet_batch.blocks+0x1ff4>
    2904:      	tbz	w8, #0x7, 0xa44 <_llm_rows.packet_batch.blocks+0xa8>
    2908:      	b	0x299c <_llm_rows.packet_batch.blocks+0x2000>
    290c:      	ldr	q19, [sp, #0x50]
    2910:      	fmov	x10, d19
    2914:      	ld1.b	{ v18 }[2], [x10]
    2918:      	tbz	w8, #0x3, 0x20cc <_llm_rows.packet_batch.blocks+0x1730>
    291c:      	ldr	x10, [sp, #0x68]
    2920:      	ld1.b	{ v18 }[3], [x10]
    2924:      	tbz	w8, #0x4, 0x20d0 <_llm_rows.packet_batch.blocks+0x1734>
    2928:      	ldr	q19, [sp, #0x70]
    292c:      	fmov	x10, d19
    2930:      	ld1.b	{ v18 }[4], [x10]
    2934:      	tbz	w8, #0x5, 0x20d4 <_llm_rows.packet_batch.blocks+0x1738>
    2938:      	ldr	x10, [sp, #0x88]
    293c:      	ld1.b	{ v18 }[5], [x10]
    2940:      	tbz	w8, #0x6, 0x20d8 <_llm_rows.packet_batch.blocks+0x173c>
    2944:      	ldr	q19, [sp, #0x90]
    2948:      	fmov	x10, d19
    294c:      	ld1.b	{ v18 }[6], [x10]
    2950:      	tbnz	w8, #0x7, 0x20dc <_llm_rows.packet_batch.blocks+0x1740>
    2954:      	b	0x20e4 <_llm_rows.packet_batch.blocks+0x1748>
    2958:      	str	s1, [x9]
    295c:      	tbz	w8, #0x1, 0x28d0 <_llm_rows.packet_batch.blocks+0x1f34>
    2960:      	add	x10, x9, #0x4
    2964:      	st1.s	{ v1 }[1], [x10]
    2968:      	tbz	w8, #0x2, 0x28d4 <_llm_rows.packet_batch.blocks+0x1f38>
    296c:      	add	x10, x9, #0x8
    2970:      	st1.s	{ v1 }[2], [x10]
    2974:      	tbnz	w8, #0x3, 0x28d8 <_llm_rows.packet_batch.blocks+0x1f3c>
    2978:      	b	0x28e0 <_llm_rows.packet_batch.blocks+0x1f44>
    297c:      	str	s0, [x9, #0x10]
    2980:      	tbz	w8, #0x5, 0x2900 <_llm_rows.packet_batch.blocks+0x1f64>
    2984:      	add	x10, x9, #0x14
    2988:      	st1.s	{ v0 }[1], [x10]
    298c:      	tbz	w8, #0x6, 0x2904 <_llm_rows.packet_batch.blocks+0x1f68>
    2990:      	add	x10, x9, #0x18
    2994:      	st1.s	{ v0 }[2], [x10]
    2998:      	tbz	w8, #0x7, 0xa44 <_llm_rows.packet_batch.blocks+0xa8>
    299c:      	add	x8, x9, #0x1c
    29a0:      	st1.s	{ v0 }[3], [x8]
    29a4:      	b	0xa44 <_llm_rows.packet_batch.blocks+0xa8>
    29a8:      	add	sp, sp, #0x920
    29ac:      	ldp	x29, x30, [sp, #0x90]
    29b0:      	ldp	x20, x19, [sp, #0x80]
    29b4:      	ldp	x22, x21, [sp, #0x70]
    29b8:      	ldp	x24, x23, [sp, #0x60]
    29bc:      	ldp	x26, x25, [sp, #0x50]
    29c0:      	ldp	x28, x27, [sp, #0x40]
    29c4:      	ldp	d9, d8, [sp, #0x30]
    29c8:      	ldp	d11, d10, [sp, #0x20]
    29cc:      	ldp	d13, d12, [sp, #0x10]
    29d0:      	ldp	d15, d14, [sp], #0xa0
    29d4:      	ret

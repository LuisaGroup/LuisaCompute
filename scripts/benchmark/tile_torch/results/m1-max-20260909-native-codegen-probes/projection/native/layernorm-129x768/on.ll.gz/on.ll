; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [3072 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [3072 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local4 = alloca [3072 x i8], align 4
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local7 = alloca [3072 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill10 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill10, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill11 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill11, align 4
  %.spill12 = alloca i64, align 8
  store i64 0, ptr %.spill12, align 4
  %.slot13 = alloca i64, align 8
  store i64 0, ptr %.slot13, align 4
  %.slot14 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot14, align 32
  %.slot15 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot15, align 32
  %.slot16 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot16, align 32
  %.slot17 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot17, align 32
  %.spill18 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill18, align 32
  %.spill19 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill19, align 32
  %.spill20 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill20, align 32
  %.spill21 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill21, align 4
  %.spill22 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill22, align 4
  %tile_snapshot.spill23 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill23, align 64
  %.slot24 = alloca i64, align 8
  store i64 0, ptr %.slot24, align 4
  %.slot25 = alloca i64, align 8
  store i64 0, ptr %.slot25, align 4
  %.slot26 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot26, align 32
  %.slot27 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot27, align 32
  %.slot28 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot28, align 32
  %.slot29 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot29, align 32
  %.spill30 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill30, align 4
  %tile_snapshot.spill31 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill31, align 64
  %.slot32 = alloca i64, align 8
  store i64 0, ptr %.slot32, align 4
  %.spill33 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill33, align 4
  %.slot34 = alloca i64, align 8
  store i64 0, ptr %.slot34, align 4
  %tile_snapshot.spill35 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill35, align 64
  %.slot36 = alloca i64, align 8
  store i64 0, ptr %.slot36, align 4
  %.slot37 = alloca i64, align 8
  store i64 0, ptr %.slot37, align 4
  %8 = getelementptr i8, ptr %argument_buffer, i64 0
  %9 = load ptr, ptr %8, align 16
  %10 = getelementptr i8, ptr %8, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = insertvalue { ptr, i64 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %11, 1
  %14 = getelementptr i8, ptr %argument_buffer, i64 16
  %15 = load ptr, ptr %14, align 16
  %16 = getelementptr i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = insertvalue { ptr, i64 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i64 } %18, i64 %17, 1
  %20 = getelementptr i8, ptr %argument_buffer, i64 32
  %21 = load ptr, ptr %20, align 16
  %22 = getelementptr i8, ptr %20, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = insertvalue { ptr, i64 } poison, ptr %21, 0
  %25 = insertvalue { ptr, i64 } %24, i64 %23, 1
  %26 = getelementptr i8, ptr %argument_buffer, i64 48
  %27 = load ptr, ptr %26, align 16
  %28 = getelementptr i8, ptr %26, i64 8
  %29 = load i64, ptr %28, align 8
  %30 = insertvalue { ptr, i64 } poison, ptr %27, 0
  %31 = insertvalue { ptr, i64 } %30, i64 %29, 1
  %32 = load i32, ptr %launch_config, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 12
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 4
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 16
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 8
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 20
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 36
  %44 = load i32, ptr %43, align 4
  %.splatinsert38 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat39 = shufflevector <8 x i32> %.splatinsert38, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat39, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %46 = mul i32 %32, 32
  %.splatinsert40 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat41 = shufflevector <8 x i32> %.splatinsert40, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat41, %45
  %48 = mul i32 %36, 1
  %.splatinsert42 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat43 = shufflevector <8 x i32> %.splatinsert42, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat43, zeroinitializer
  %50 = mul i32 %40, 1
  %.splatinsert44 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat45 = shufflevector <8 x i32> %.splatinsert44, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat45, zeroinitializer
  %52 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %47, 0
  %53 = insertvalue [3 x <8 x i32>] %52, <8 x i32> %49, 1
  %54 = insertvalue [3 x <8 x i32>] %53, <8 x i32> %51, 2
  %.splatinsert46 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat47 = shufflevector <8 x i32> %.splatinsert46, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat47
  %56 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  br i1 %56, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %57 = extractvalue [3 x <8 x i32>] %54, 0
  %58 = load <8 x i64>, ptr %.spill, align 64
  %59 = select <8 x i1> %55, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %58
  store <8 x i64> %59, ptr %.spill, align 64
  %60 = sub <8 x i32> %57, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %61 = select <8 x i1> %55, <8 x i32> %60, <8 x i32> zeroinitializer
  %62 = select <8 x i1> %55, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %63 = lshr <8 x i32> %61, %62
  %64 = zext <8 x i32> %63 to <8 x i64>
  %65 = select <8 x i1> %55, <8 x i64> %64, <8 x i64> zeroinitializer
  %66 = select <8 x i1> %55, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %67 = sdiv <8 x i64> %65, %66
  %68 = load <8 x i64>, ptr %.spill10, align 64
  %69 = select <8 x i1> %55, <8 x i64> %67, <8 x i64> %68
  store <8 x i64> %69, ptr %.spill10, align 64
  %70 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %71 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %72 = extractvalue { <8 x ptr>, <8 x i64> } %70, 0
  %73 = select <8 x i1> %55, <8 x ptr> %71, <8 x ptr> %72
  %74 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %75 = extractvalue { <8 x ptr>, <8 x i64> } %70, 1
  %76 = select <8 x i1> %55, <8 x i64> %74, <8 x i64> %75
  %77 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %73, 0
  %78 = insertvalue { <8 x ptr>, <8 x i64> } %77, <8 x i64> %76, 1
  store { <8 x ptr>, <8 x i64> } %78, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %79 = icmp slt i64 %.state, 96
  br i1 %79, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state48 = load i64, ptr %.slot, align 4
  %80 = mul i64 %.state48, 8
  %.splatinsert49 = insertelement <8 x i64> poison, i64 %80, i64 0
  %.splat50 = shufflevector <8 x i64> %.splatinsert49, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %81 = add <8 x i64> %.splat50, %.spill.load
  %.spill.load51 = load <8 x i64>, ptr %.spill10, align 64
  %82 = add <8 x i64> %.spill.load51, zeroinitializer
  %83 = add <8 x i64> zeroinitializer, %82
  %84 = add <8 x i64> zeroinitializer, %81
  %85 = mul <8 x i64> %83, splat (i64 768)
  %86 = add <8 x i64> %85, %84
  %87 = extractvalue { ptr, i64 } %13, 0
  %88 = extractelement <8 x i64> %86, i32 0
  %89 = sub i64 %88, 0
  %90 = mul i64 %89, 4
  %buffer.contiguous.address = getelementptr i8, ptr %87, i64 %90
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %91 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %92 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state52 = load i64, ptr %.slot, align 4
  %.splatinsert53 = insertelement <8 x i64> poison, i64 %.state52, i64 0
  %.splat54 = shufflevector <8 x i64> %.splatinsert53, <8 x i64> poison, <8 x i32> zeroinitializer
  %93 = mul <8 x i64> %.splat54, splat (i64 32)
  %94 = add <8 x i64> %92, %93
  %95 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %91, 0
  %96 = insertvalue { <8 x ptr>, <8 x i64> } %95, <8 x i64> %94, 1
  %97 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %96, 1
  %99 = extractelement <8 x ptr> %97, i32 0
  %100 = extractelement <8 x i64> %98, i32 0
  %101 = sub i64 %100, 0
  %102 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %103 = select i1 %102, i64 %101, i64 0
  %private.contiguous.address = getelementptr i8, ptr %99, i64 %103
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %104 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %104, ptr %private.contiguous.address, align 4
  %.state55 = load i64, ptr %.slot, align 4
  %105 = add i64 %.state55, 1
  store i64 %105, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store float 0.000000e+00, ptr %.spill11, align 4
  store i64 0, ptr %.spill12, align 4
  %tile_snapshot.spill.load56 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %106 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load56, 0
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load56, 1
  %108 = add <8 x i64> %107, zeroinitializer
  %109 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %106, 0
  %110 = insertvalue { <8 x ptr>, <8 x i64> } %109, <8 x i64> %108, 1
  %111 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %112 = extractvalue { <8 x ptr>, <8 x i64> } %110, 1
  %113 = extractelement <8 x ptr> %111, i32 0
  %114 = extractelement <8 x i64> %112, i32 0
  %115 = sub i64 %114, 0
  %116 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %117 = select i1 %116, i64 %115, i64 0
  %private.contiguous.address57 = getelementptr i8, ptr %113, i64 %117
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address57, align 4
  %118 = select <8 x i1> %55, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load58 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %119 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load58, 0
  %120 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load58, 1
  %121 = add <8 x i64> %120, splat (i64 32)
  %122 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %119, 0
  %123 = insertvalue { <8 x ptr>, <8 x i64> } %122, <8 x i64> %121, 1
  %124 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %123, 1
  %126 = extractelement <8 x ptr> %124, i32 0
  %127 = extractelement <8 x i64> %125, i32 0
  %128 = sub i64 %127, 0
  %129 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %130 = select i1 %129, i64 %128, i64 0
  %private.contiguous.address59 = getelementptr i8, ptr %126, i64 %130
  %private.contiguous.load60 = load <8 x float>, ptr %private.contiguous.address59, align 4
  %131 = select <8 x i1> %55, <8 x float> %private.contiguous.load60, <8 x float> zeroinitializer
  %tile_snapshot.spill.load61 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %132 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load61, 0
  %133 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load61, 1
  %134 = add <8 x i64> %133, splat (i64 64)
  %135 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %132, 0
  %136 = insertvalue { <8 x ptr>, <8 x i64> } %135, <8 x i64> %134, 1
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %138 = extractvalue { <8 x ptr>, <8 x i64> } %136, 1
  %139 = extractelement <8 x ptr> %137, i32 0
  %140 = extractelement <8 x i64> %138, i32 0
  %141 = sub i64 %140, 0
  %142 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %143 = select i1 %142, i64 %141, i64 0
  %private.contiguous.address62 = getelementptr i8, ptr %139, i64 %143
  %private.contiguous.load63 = load <8 x float>, ptr %private.contiguous.address62, align 4
  %144 = select <8 x i1> %55, <8 x float> %private.contiguous.load63, <8 x float> zeroinitializer
  %tile_snapshot.spill.load64 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %145 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 0
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 1
  %147 = add <8 x i64> %146, splat (i64 96)
  %148 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %145, 0
  %149 = insertvalue { <8 x ptr>, <8 x i64> } %148, <8 x i64> %147, 1
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %151 = extractvalue { <8 x ptr>, <8 x i64> } %149, 1
  %152 = extractelement <8 x ptr> %150, i32 0
  %153 = extractelement <8 x i64> %151, i32 0
  %154 = sub i64 %153, 0
  %155 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %156 = select i1 %155, i64 %154, i64 0
  %private.contiguous.address65 = getelementptr i8, ptr %152, i64 %156
  %private.contiguous.load66 = load <8 x float>, ptr %private.contiguous.address65, align 4
  %157 = select <8 x i1> %55, <8 x float> %private.contiguous.load66, <8 x float> zeroinitializer
  store i64 4, ptr %.slot13, align 4
  %158 = load <8 x float>, ptr %.slot14, align 32
  %159 = select <8 x i1> %55, <8 x float> %118, <8 x float> %158
  store <8 x float> %159, ptr %.slot14, align 32
  %160 = load <8 x float>, ptr %.slot15, align 32
  %161 = select <8 x i1> %55, <8 x float> %131, <8 x float> %160
  store <8 x float> %161, ptr %.slot15, align 32
  %162 = load <8 x float>, ptr %.slot16, align 32
  %163 = select <8 x i1> %55, <8 x float> %144, <8 x float> %162
  store <8 x float> %163, ptr %.slot16, align 32
  %164 = load <8 x float>, ptr %.slot17, align 32
  %165 = select <8 x i1> %55, <8 x float> %157, <8 x float> %164
  store <8 x float> %165, ptr %.slot17, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state67 = load i64, ptr %.slot13, align 4
  %166 = icmp slt i64 %.state67, 96
  br i1 %166, label %direct.true68, label %direct.false69

direct.schedule.5:                                ; preds = %direct.true68
  %.state70 = load i64, ptr %.slot13, align 4
  %167 = add i64 %.state70, 0
  %tile_snapshot.spill.load71 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %168 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load71, 0
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load71, 1
  %.splatinsert72 = insertelement <8 x i64> poison, i64 %167, i64 0
  %.splat73 = shufflevector <8 x i64> %.splatinsert72, <8 x i64> poison, <8 x i32> zeroinitializer
  %170 = mul <8 x i64> %.splat73, splat (i64 32)
  %171 = add <8 x i64> %169, %170
  %172 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %168, 0
  %173 = insertvalue { <8 x ptr>, <8 x i64> } %172, <8 x i64> %171, 1
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %173, 1
  %176 = extractelement <8 x ptr> %174, i32 0
  %177 = extractelement <8 x i64> %175, i32 0
  %178 = sub i64 %177, 0
  %179 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %180 = select i1 %179, i64 %178, i64 0
  %private.contiguous.address74 = getelementptr i8, ptr %176, i64 %180
  %private.contiguous.load75 = load <8 x float>, ptr %private.contiguous.address74, align 4
  %181 = select <8 x i1> %55, <8 x float> %private.contiguous.load75, <8 x float> zeroinitializer
  %.state76 = load <8 x float>, ptr %.slot14, align 32
  %182 = fadd <8 x float> %.state76, %181
  %.state77 = load i64, ptr %.slot13, align 4
  %183 = add i64 %.state77, 1
  %tile_snapshot.spill.load78 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %184 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load78, 0
  %185 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load78, 1
  %.splatinsert79 = insertelement <8 x i64> poison, i64 %183, i64 0
  %.splat80 = shufflevector <8 x i64> %.splatinsert79, <8 x i64> poison, <8 x i32> zeroinitializer
  %186 = mul <8 x i64> %.splat80, splat (i64 32)
  %187 = add <8 x i64> %185, %186
  %188 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %184, 0
  %189 = insertvalue { <8 x ptr>, <8 x i64> } %188, <8 x i64> %187, 1
  %190 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %191 = extractvalue { <8 x ptr>, <8 x i64> } %189, 1
  %192 = extractelement <8 x ptr> %190, i32 0
  %193 = extractelement <8 x i64> %191, i32 0
  %194 = sub i64 %193, 0
  %195 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %196 = select i1 %195, i64 %194, i64 0
  %private.contiguous.address81 = getelementptr i8, ptr %192, i64 %196
  %private.contiguous.load82 = load <8 x float>, ptr %private.contiguous.address81, align 4
  %197 = select <8 x i1> %55, <8 x float> %private.contiguous.load82, <8 x float> zeroinitializer
  %.state83 = load <8 x float>, ptr %.slot15, align 32
  %198 = fadd <8 x float> %.state83, %197
  %.state84 = load i64, ptr %.slot13, align 4
  %199 = add i64 %.state84, 2
  %tile_snapshot.spill.load85 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %200 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load85, 0
  %201 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load85, 1
  %.splatinsert86 = insertelement <8 x i64> poison, i64 %199, i64 0
  %.splat87 = shufflevector <8 x i64> %.splatinsert86, <8 x i64> poison, <8 x i32> zeroinitializer
  %202 = mul <8 x i64> %.splat87, splat (i64 32)
  %203 = add <8 x i64> %201, %202
  %204 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %200, 0
  %205 = insertvalue { <8 x ptr>, <8 x i64> } %204, <8 x i64> %203, 1
  %206 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %207 = extractvalue { <8 x ptr>, <8 x i64> } %205, 1
  %208 = extractelement <8 x ptr> %206, i32 0
  %209 = extractelement <8 x i64> %207, i32 0
  %210 = sub i64 %209, 0
  %211 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %212 = select i1 %211, i64 %210, i64 0
  %private.contiguous.address88 = getelementptr i8, ptr %208, i64 %212
  %private.contiguous.load89 = load <8 x float>, ptr %private.contiguous.address88, align 4
  %213 = select <8 x i1> %55, <8 x float> %private.contiguous.load89, <8 x float> zeroinitializer
  %.state90 = load <8 x float>, ptr %.slot16, align 32
  %214 = fadd <8 x float> %.state90, %213
  %.state91 = load i64, ptr %.slot13, align 4
  %215 = add i64 %.state91, 3
  %tile_snapshot.spill.load92 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load92, 0
  %217 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load92, 1
  %.splatinsert93 = insertelement <8 x i64> poison, i64 %215, i64 0
  %.splat94 = shufflevector <8 x i64> %.splatinsert93, <8 x i64> poison, <8 x i32> zeroinitializer
  %218 = mul <8 x i64> %.splat94, splat (i64 32)
  %219 = add <8 x i64> %217, %218
  %220 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %216, 0
  %221 = insertvalue { <8 x ptr>, <8 x i64> } %220, <8 x i64> %219, 1
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %221, 1
  %224 = extractelement <8 x ptr> %222, i32 0
  %225 = extractelement <8 x i64> %223, i32 0
  %226 = sub i64 %225, 0
  %227 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %228 = select i1 %227, i64 %226, i64 0
  %private.contiguous.address95 = getelementptr i8, ptr %224, i64 %228
  %private.contiguous.load96 = load <8 x float>, ptr %private.contiguous.address95, align 4
  %229 = select <8 x i1> %55, <8 x float> %private.contiguous.load96, <8 x float> zeroinitializer
  %.state97 = load <8 x float>, ptr %.slot17, align 32
  %230 = fadd <8 x float> %.state97, %229
  %.state98 = load i64, ptr %.slot13, align 4
  %231 = add i64 %.state98, 4
  store i64 %231, ptr %.slot13, align 4
  %232 = load <8 x float>, ptr %.slot14, align 32
  %233 = select <8 x i1> %55, <8 x float> %182, <8 x float> %232
  store <8 x float> %233, ptr %.slot14, align 32
  %234 = load <8 x float>, ptr %.slot15, align 32
  %235 = select <8 x i1> %55, <8 x float> %198, <8 x float> %234
  store <8 x float> %235, ptr %.slot15, align 32
  %236 = load <8 x float>, ptr %.slot16, align 32
  %237 = select <8 x i1> %55, <8 x float> %214, <8 x float> %236
  store <8 x float> %237, ptr %.slot16, align 32
  %238 = load <8 x float>, ptr %.slot17, align 32
  %239 = select <8 x i1> %55, <8 x float> %230, <8 x float> %238
  store <8 x float> %239, ptr %.slot17, align 32
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false69
  %.state99 = load <8 x float>, ptr %.slot14, align 32
  %.state100 = load <8 x float>, ptr %.slot15, align 32
  %240 = fadd <8 x float> %.state99, %.state100
  %.state101 = load <8 x float>, ptr %.slot16, align 32
  %241 = fadd <8 x float> %240, %.state101
  %.state102 = load <8 x float>, ptr %.slot17, align 32
  %242 = fadd <8 x float> %241, %.state102
  %.spill.load103 = load <8 x i64>, ptr %.spill, align 64
  %243 = trunc <8 x i64> %.spill.load103 to <8 x i32>
  %244 = xor <8 x i32> %243, splat (i32 1)
  %245 = load <8 x i32>, ptr %.spill18, align 32
  %246 = select <8 x i1> %55, <8 x i32> %244, <8 x i32> %245
  store <8 x i32> %246, ptr %.spill18, align 32
  %247 = extractelement <8 x i32> %244, i64 0
  %248 = icmp ult i32 %247, 8
  %249 = select i1 %248, i32 %247, i32 0
  %250 = extractelement <8 x i1> %55, i32 %249
  %251 = extractelement <8 x i1> %55, i64 0
  %252 = and i1 %248, %250
  %253 = and i1 %251, %252
  %254 = extractelement <8 x float> %242, i32 %249
  %255 = select i1 %253, float %254, float 0.000000e+00
  %256 = insertelement <8 x float> poison, float %255, i64 0
  %257 = xor i1 %253, true
  %258 = and i1 %251, %257
  %259 = insertelement <8 x i1> poison, i1 %258, i64 0
  %260 = extractelement <8 x i32> %244, i64 1
  %261 = icmp ult i32 %260, 8
  %262 = select i1 %261, i32 %260, i32 0
  %263 = extractelement <8 x i1> %55, i32 %262
  %264 = extractelement <8 x i1> %55, i64 1
  %265 = and i1 %261, %263
  %266 = and i1 %264, %265
  %267 = extractelement <8 x float> %242, i32 %262
  %268 = select i1 %266, float %267, float 0.000000e+00
  %269 = insertelement <8 x float> %256, float %268, i64 1
  %270 = xor i1 %266, true
  %271 = and i1 %264, %270
  %272 = insertelement <8 x i1> %259, i1 %271, i64 1
  %273 = extractelement <8 x i32> %244, i64 2
  %274 = icmp ult i32 %273, 8
  %275 = select i1 %274, i32 %273, i32 0
  %276 = extractelement <8 x i1> %55, i32 %275
  %277 = extractelement <8 x i1> %55, i64 2
  %278 = and i1 %274, %276
  %279 = and i1 %277, %278
  %280 = extractelement <8 x float> %242, i32 %275
  %281 = select i1 %279, float %280, float 0.000000e+00
  %282 = insertelement <8 x float> %269, float %281, i64 2
  %283 = xor i1 %279, true
  %284 = and i1 %277, %283
  %285 = insertelement <8 x i1> %272, i1 %284, i64 2
  %286 = extractelement <8 x i32> %244, i64 3
  %287 = icmp ult i32 %286, 8
  %288 = select i1 %287, i32 %286, i32 0
  %289 = extractelement <8 x i1> %55, i32 %288
  %290 = extractelement <8 x i1> %55, i64 3
  %291 = and i1 %287, %289
  %292 = and i1 %290, %291
  %293 = extractelement <8 x float> %242, i32 %288
  %294 = select i1 %292, float %293, float 0.000000e+00
  %295 = insertelement <8 x float> %282, float %294, i64 3
  %296 = xor i1 %292, true
  %297 = and i1 %290, %296
  %298 = insertelement <8 x i1> %285, i1 %297, i64 3
  %299 = extractelement <8 x i32> %244, i64 4
  %300 = icmp ult i32 %299, 8
  %301 = select i1 %300, i32 %299, i32 0
  %302 = extractelement <8 x i1> %55, i32 %301
  %303 = extractelement <8 x i1> %55, i64 4
  %304 = and i1 %300, %302
  %305 = and i1 %303, %304
  %306 = extractelement <8 x float> %242, i32 %301
  %307 = select i1 %305, float %306, float 0.000000e+00
  %308 = insertelement <8 x float> %295, float %307, i64 4
  %309 = xor i1 %305, true
  %310 = and i1 %303, %309
  %311 = insertelement <8 x i1> %298, i1 %310, i64 4
  %312 = extractelement <8 x i32> %244, i64 5
  %313 = icmp ult i32 %312, 8
  %314 = select i1 %313, i32 %312, i32 0
  %315 = extractelement <8 x i1> %55, i32 %314
  %316 = extractelement <8 x i1> %55, i64 5
  %317 = and i1 %313, %315
  %318 = and i1 %316, %317
  %319 = extractelement <8 x float> %242, i32 %314
  %320 = select i1 %318, float %319, float 0.000000e+00
  %321 = insertelement <8 x float> %308, float %320, i64 5
  %322 = xor i1 %318, true
  %323 = and i1 %316, %322
  %324 = insertelement <8 x i1> %311, i1 %323, i64 5
  %325 = extractelement <8 x i32> %244, i64 6
  %326 = icmp ult i32 %325, 8
  %327 = select i1 %326, i32 %325, i32 0
  %328 = extractelement <8 x i1> %55, i32 %327
  %329 = extractelement <8 x i1> %55, i64 6
  %330 = and i1 %326, %328
  %331 = and i1 %329, %330
  %332 = extractelement <8 x float> %242, i32 %327
  %333 = select i1 %331, float %332, float 0.000000e+00
  %334 = insertelement <8 x float> %321, float %333, i64 6
  %335 = xor i1 %331, true
  %336 = and i1 %329, %335
  %337 = insertelement <8 x i1> %324, i1 %336, i64 6
  %338 = extractelement <8 x i32> %244, i64 7
  %339 = icmp ult i32 %338, 8
  %340 = select i1 %339, i32 %338, i32 0
  %341 = extractelement <8 x i1> %55, i32 %340
  %342 = extractelement <8 x i1> %55, i64 7
  %343 = and i1 %339, %341
  %344 = and i1 %342, %343
  %345 = extractelement <8 x float> %242, i32 %340
  %346 = select i1 %344, float %345, float 0.000000e+00
  %347 = insertelement <8 x float> %334, float %346, i64 7
  %348 = xor i1 %344, true
  %349 = and i1 %342, %348
  %350 = insertelement <8 x i1> %337, i1 %349, i64 7
  %351 = fadd <8 x float> %242, %347
  %352 = xor <8 x i32> %243, splat (i32 2)
  %353 = load <8 x i32>, ptr %.spill19, align 32
  %354 = select <8 x i1> %55, <8 x i32> %352, <8 x i32> %353
  store <8 x i32> %354, ptr %.spill19, align 32
  %355 = extractelement <8 x i32> %352, i64 0
  %356 = icmp ult i32 %355, 8
  %357 = select i1 %356, i32 %355, i32 0
  %358 = extractelement <8 x i1> %55, i32 %357
  %359 = extractelement <8 x i1> %55, i64 0
  %360 = and i1 %356, %358
  %361 = and i1 %359, %360
  %362 = extractelement <8 x float> %351, i32 %357
  %363 = select i1 %361, float %362, float 0.000000e+00
  %364 = insertelement <8 x float> poison, float %363, i64 0
  %365 = xor i1 %361, true
  %366 = and i1 %359, %365
  %367 = insertelement <8 x i1> poison, i1 %366, i64 0
  %368 = extractelement <8 x i32> %352, i64 1
  %369 = icmp ult i32 %368, 8
  %370 = select i1 %369, i32 %368, i32 0
  %371 = extractelement <8 x i1> %55, i32 %370
  %372 = extractelement <8 x i1> %55, i64 1
  %373 = and i1 %369, %371
  %374 = and i1 %372, %373
  %375 = extractelement <8 x float> %351, i32 %370
  %376 = select i1 %374, float %375, float 0.000000e+00
  %377 = insertelement <8 x float> %364, float %376, i64 1
  %378 = xor i1 %374, true
  %379 = and i1 %372, %378
  %380 = insertelement <8 x i1> %367, i1 %379, i64 1
  %381 = extractelement <8 x i32> %352, i64 2
  %382 = icmp ult i32 %381, 8
  %383 = select i1 %382, i32 %381, i32 0
  %384 = extractelement <8 x i1> %55, i32 %383
  %385 = extractelement <8 x i1> %55, i64 2
  %386 = and i1 %382, %384
  %387 = and i1 %385, %386
  %388 = extractelement <8 x float> %351, i32 %383
  %389 = select i1 %387, float %388, float 0.000000e+00
  %390 = insertelement <8 x float> %377, float %389, i64 2
  %391 = xor i1 %387, true
  %392 = and i1 %385, %391
  %393 = insertelement <8 x i1> %380, i1 %392, i64 2
  %394 = extractelement <8 x i32> %352, i64 3
  %395 = icmp ult i32 %394, 8
  %396 = select i1 %395, i32 %394, i32 0
  %397 = extractelement <8 x i1> %55, i32 %396
  %398 = extractelement <8 x i1> %55, i64 3
  %399 = and i1 %395, %397
  %400 = and i1 %398, %399
  %401 = extractelement <8 x float> %351, i32 %396
  %402 = select i1 %400, float %401, float 0.000000e+00
  %403 = insertelement <8 x float> %390, float %402, i64 3
  %404 = xor i1 %400, true
  %405 = and i1 %398, %404
  %406 = insertelement <8 x i1> %393, i1 %405, i64 3
  %407 = extractelement <8 x i32> %352, i64 4
  %408 = icmp ult i32 %407, 8
  %409 = select i1 %408, i32 %407, i32 0
  %410 = extractelement <8 x i1> %55, i32 %409
  %411 = extractelement <8 x i1> %55, i64 4
  %412 = and i1 %408, %410
  %413 = and i1 %411, %412
  %414 = extractelement <8 x float> %351, i32 %409
  %415 = select i1 %413, float %414, float 0.000000e+00
  %416 = insertelement <8 x float> %403, float %415, i64 4
  %417 = xor i1 %413, true
  %418 = and i1 %411, %417
  %419 = insertelement <8 x i1> %406, i1 %418, i64 4
  %420 = extractelement <8 x i32> %352, i64 5
  %421 = icmp ult i32 %420, 8
  %422 = select i1 %421, i32 %420, i32 0
  %423 = extractelement <8 x i1> %55, i32 %422
  %424 = extractelement <8 x i1> %55, i64 5
  %425 = and i1 %421, %423
  %426 = and i1 %424, %425
  %427 = extractelement <8 x float> %351, i32 %422
  %428 = select i1 %426, float %427, float 0.000000e+00
  %429 = insertelement <8 x float> %416, float %428, i64 5
  %430 = xor i1 %426, true
  %431 = and i1 %424, %430
  %432 = insertelement <8 x i1> %419, i1 %431, i64 5
  %433 = extractelement <8 x i32> %352, i64 6
  %434 = icmp ult i32 %433, 8
  %435 = select i1 %434, i32 %433, i32 0
  %436 = extractelement <8 x i1> %55, i32 %435
  %437 = extractelement <8 x i1> %55, i64 6
  %438 = and i1 %434, %436
  %439 = and i1 %437, %438
  %440 = extractelement <8 x float> %351, i32 %435
  %441 = select i1 %439, float %440, float 0.000000e+00
  %442 = insertelement <8 x float> %429, float %441, i64 6
  %443 = xor i1 %439, true
  %444 = and i1 %437, %443
  %445 = insertelement <8 x i1> %432, i1 %444, i64 6
  %446 = extractelement <8 x i32> %352, i64 7
  %447 = icmp ult i32 %446, 8
  %448 = select i1 %447, i32 %446, i32 0
  %449 = extractelement <8 x i1> %55, i32 %448
  %450 = extractelement <8 x i1> %55, i64 7
  %451 = and i1 %447, %449
  %452 = and i1 %450, %451
  %453 = extractelement <8 x float> %351, i32 %448
  %454 = select i1 %452, float %453, float 0.000000e+00
  %455 = insertelement <8 x float> %442, float %454, i64 7
  %456 = xor i1 %452, true
  %457 = and i1 %450, %456
  %458 = insertelement <8 x i1> %445, i1 %457, i64 7
  %459 = fadd <8 x float> %351, %455
  %460 = xor <8 x i32> %243, splat (i32 4)
  %461 = load <8 x i32>, ptr %.spill20, align 32
  %462 = select <8 x i1> %55, <8 x i32> %460, <8 x i32> %461
  store <8 x i32> %462, ptr %.spill20, align 32
  %463 = extractelement <8 x i32> %460, i64 0
  %464 = icmp ult i32 %463, 8
  %465 = select i1 %464, i32 %463, i32 0
  %466 = extractelement <8 x i1> %55, i32 %465
  %467 = extractelement <8 x i1> %55, i64 0
  %468 = and i1 %464, %466
  %469 = and i1 %467, %468
  %470 = extractelement <8 x float> %459, i32 %465
  %471 = select i1 %469, float %470, float 0.000000e+00
  %472 = insertelement <8 x float> poison, float %471, i64 0
  %473 = xor i1 %469, true
  %474 = and i1 %467, %473
  %475 = insertelement <8 x i1> poison, i1 %474, i64 0
  %476 = extractelement <8 x i32> %460, i64 1
  %477 = icmp ult i32 %476, 8
  %478 = select i1 %477, i32 %476, i32 0
  %479 = extractelement <8 x i1> %55, i32 %478
  %480 = extractelement <8 x i1> %55, i64 1
  %481 = and i1 %477, %479
  %482 = and i1 %480, %481
  %483 = extractelement <8 x float> %459, i32 %478
  %484 = select i1 %482, float %483, float 0.000000e+00
  %485 = insertelement <8 x float> %472, float %484, i64 1
  %486 = xor i1 %482, true
  %487 = and i1 %480, %486
  %488 = insertelement <8 x i1> %475, i1 %487, i64 1
  %489 = extractelement <8 x i32> %460, i64 2
  %490 = icmp ult i32 %489, 8
  %491 = select i1 %490, i32 %489, i32 0
  %492 = extractelement <8 x i1> %55, i32 %491
  %493 = extractelement <8 x i1> %55, i64 2
  %494 = and i1 %490, %492
  %495 = and i1 %493, %494
  %496 = extractelement <8 x float> %459, i32 %491
  %497 = select i1 %495, float %496, float 0.000000e+00
  %498 = insertelement <8 x float> %485, float %497, i64 2
  %499 = xor i1 %495, true
  %500 = and i1 %493, %499
  %501 = insertelement <8 x i1> %488, i1 %500, i64 2
  %502 = extractelement <8 x i32> %460, i64 3
  %503 = icmp ult i32 %502, 8
  %504 = select i1 %503, i32 %502, i32 0
  %505 = extractelement <8 x i1> %55, i32 %504
  %506 = extractelement <8 x i1> %55, i64 3
  %507 = and i1 %503, %505
  %508 = and i1 %506, %507
  %509 = extractelement <8 x float> %459, i32 %504
  %510 = select i1 %508, float %509, float 0.000000e+00
  %511 = insertelement <8 x float> %498, float %510, i64 3
  %512 = xor i1 %508, true
  %513 = and i1 %506, %512
  %514 = insertelement <8 x i1> %501, i1 %513, i64 3
  %515 = extractelement <8 x i32> %460, i64 4
  %516 = icmp ult i32 %515, 8
  %517 = select i1 %516, i32 %515, i32 0
  %518 = extractelement <8 x i1> %55, i32 %517
  %519 = extractelement <8 x i1> %55, i64 4
  %520 = and i1 %516, %518
  %521 = and i1 %519, %520
  %522 = extractelement <8 x float> %459, i32 %517
  %523 = select i1 %521, float %522, float 0.000000e+00
  %524 = insertelement <8 x float> %511, float %523, i64 4
  %525 = xor i1 %521, true
  %526 = and i1 %519, %525
  %527 = insertelement <8 x i1> %514, i1 %526, i64 4
  %528 = extractelement <8 x i32> %460, i64 5
  %529 = icmp ult i32 %528, 8
  %530 = select i1 %529, i32 %528, i32 0
  %531 = extractelement <8 x i1> %55, i32 %530
  %532 = extractelement <8 x i1> %55, i64 5
  %533 = and i1 %529, %531
  %534 = and i1 %532, %533
  %535 = extractelement <8 x float> %459, i32 %530
  %536 = select i1 %534, float %535, float 0.000000e+00
  %537 = insertelement <8 x float> %524, float %536, i64 5
  %538 = xor i1 %534, true
  %539 = and i1 %532, %538
  %540 = insertelement <8 x i1> %527, i1 %539, i64 5
  %541 = extractelement <8 x i32> %460, i64 6
  %542 = icmp ult i32 %541, 8
  %543 = select i1 %542, i32 %541, i32 0
  %544 = extractelement <8 x i1> %55, i32 %543
  %545 = extractelement <8 x i1> %55, i64 6
  %546 = and i1 %542, %544
  %547 = and i1 %545, %546
  %548 = extractelement <8 x float> %459, i32 %543
  %549 = select i1 %547, float %548, float 0.000000e+00
  %550 = insertelement <8 x float> %537, float %549, i64 6
  %551 = xor i1 %547, true
  %552 = and i1 %545, %551
  %553 = insertelement <8 x i1> %540, i1 %552, i64 6
  %554 = extractelement <8 x i32> %460, i64 7
  %555 = icmp ult i32 %554, 8
  %556 = select i1 %555, i32 %554, i32 0
  %557 = extractelement <8 x i1> %55, i32 %556
  %558 = extractelement <8 x i1> %55, i64 7
  %559 = and i1 %555, %557
  %560 = and i1 %558, %559
  %561 = extractelement <8 x float> %459, i32 %556
  %562 = select i1 %560, float %561, float 0.000000e+00
  %563 = insertelement <8 x float> %550, float %562, i64 7
  %564 = xor i1 %560, true
  %565 = and i1 %558, %564
  %566 = insertelement <8 x i1> %553, i1 %565, i64 7
  %567 = fadd <8 x float> %459, %563
  %568 = extractelement <8 x i1> %55, i32 0
  %569 = extractelement <8 x i1> %55, i64 0
  %570 = and i1 true, %568
  %571 = and i1 %569, %570
  %572 = extractelement <8 x float> %567, i32 0
  %573 = select i1 %571, float %572, float 0.000000e+00
  %574 = insertelement <8 x float> poison, float %573, i64 0
  %575 = xor i1 %571, true
  %576 = and i1 %569, %575
  %577 = insertelement <8 x i1> poison, i1 %576, i64 0
  %578 = extractelement <8 x i1> %55, i32 0
  %579 = extractelement <8 x i1> %55, i64 1
  %580 = and i1 true, %578
  %581 = and i1 %579, %580
  %582 = extractelement <8 x float> %567, i32 0
  %583 = select i1 %581, float %582, float 0.000000e+00
  %584 = insertelement <8 x float> %574, float %583, i64 1
  %585 = xor i1 %581, true
  %586 = and i1 %579, %585
  %587 = insertelement <8 x i1> %577, i1 %586, i64 1
  %588 = extractelement <8 x i1> %55, i32 0
  %589 = extractelement <8 x i1> %55, i64 2
  %590 = and i1 true, %588
  %591 = and i1 %589, %590
  %592 = extractelement <8 x float> %567, i32 0
  %593 = select i1 %591, float %592, float 0.000000e+00
  %594 = insertelement <8 x float> %584, float %593, i64 2
  %595 = xor i1 %591, true
  %596 = and i1 %589, %595
  %597 = insertelement <8 x i1> %587, i1 %596, i64 2
  %598 = extractelement <8 x i1> %55, i32 0
  %599 = extractelement <8 x i1> %55, i64 3
  %600 = and i1 true, %598
  %601 = and i1 %599, %600
  %602 = extractelement <8 x float> %567, i32 0
  %603 = select i1 %601, float %602, float 0.000000e+00
  %604 = insertelement <8 x float> %594, float %603, i64 3
  %605 = xor i1 %601, true
  %606 = and i1 %599, %605
  %607 = insertelement <8 x i1> %597, i1 %606, i64 3
  %608 = extractelement <8 x i1> %55, i32 0
  %609 = extractelement <8 x i1> %55, i64 4
  %610 = and i1 true, %608
  %611 = and i1 %609, %610
  %612 = extractelement <8 x float> %567, i32 0
  %613 = select i1 %611, float %612, float 0.000000e+00
  %614 = insertelement <8 x float> %604, float %613, i64 4
  %615 = xor i1 %611, true
  %616 = and i1 %609, %615
  %617 = insertelement <8 x i1> %607, i1 %616, i64 4
  %618 = extractelement <8 x i1> %55, i32 0
  %619 = extractelement <8 x i1> %55, i64 5
  %620 = and i1 true, %618
  %621 = and i1 %619, %620
  %622 = extractelement <8 x float> %567, i32 0
  %623 = select i1 %621, float %622, float 0.000000e+00
  %624 = insertelement <8 x float> %614, float %623, i64 5
  %625 = xor i1 %621, true
  %626 = and i1 %619, %625
  %627 = insertelement <8 x i1> %617, i1 %626, i64 5
  %628 = extractelement <8 x i1> %55, i32 0
  %629 = extractelement <8 x i1> %55, i64 6
  %630 = and i1 true, %628
  %631 = and i1 %629, %630
  %632 = extractelement <8 x float> %567, i32 0
  %633 = select i1 %631, float %632, float 0.000000e+00
  %634 = insertelement <8 x float> %624, float %633, i64 6
  %635 = xor i1 %631, true
  %636 = and i1 %629, %635
  %637 = insertelement <8 x i1> %627, i1 %636, i64 6
  %638 = extractelement <8 x i1> %55, i32 0
  %639 = extractelement <8 x i1> %55, i64 7
  %640 = and i1 true, %638
  %641 = and i1 %639, %640
  %642 = extractelement <8 x float> %567, i32 0
  %643 = select i1 %641, float %642, float 0.000000e+00
  %644 = insertelement <8 x float> %634, float %643, i64 7
  %645 = xor i1 %641, true
  %646 = and i1 %639, %645
  %647 = insertelement <8 x i1> %637, i1 %646, i64 7
  %648 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %649 = bitcast <8 x i1> %55 to i8
  %650 = call i8 @llvm.cttz.i8(i8 %649, i1 false)
  %651 = zext i8 %650 to i32
  %652 = select i1 %648, i32 %651, i32 0
  %653 = extractelement <8 x float> %644, i32 %652
  %.spill.load104 = load float, ptr %.spill11, align 4
  %654 = fadd float %.spill.load104, %653
  store float 7.680000e+02, ptr %.spill21, align 4
  %655 = fdiv float %654, 7.680000e+02
  store float %655, ptr %.spill22, align 4
  %656 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %657 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %658 = extractvalue { <8 x ptr>, <8 x i64> } %656, 0
  %659 = select <8 x i1> %55, <8 x ptr> %657, <8 x ptr> %658
  %660 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %661 = extractvalue { <8 x ptr>, <8 x i64> } %656, 1
  %662 = select <8 x i1> %55, <8 x i64> %660, <8 x i64> %661
  %663 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %659, 0
  %664 = insertvalue { <8 x ptr>, <8 x i64> } %663, <8 x i64> %662, 1
  store { <8 x ptr>, <8 x i64> } %664, ptr %tile_snapshot.spill23, align 64
  store i64 0, ptr %.slot24, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state105 = load i64, ptr %.slot24, align 4
  %665 = icmp slt i64 %.state105, 96
  br i1 %665, label %direct.true106, label %direct.false107

direct.schedule.8:                                ; preds = %direct.true106
  %tile_snapshot.spill.load108 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %666 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load108, 0
  %667 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load108, 1
  %.state109 = load i64, ptr %.slot24, align 4
  %.splatinsert110 = insertelement <8 x i64> poison, i64 %.state109, i64 0
  %.splat111 = shufflevector <8 x i64> %.splatinsert110, <8 x i64> poison, <8 x i32> zeroinitializer
  %668 = mul <8 x i64> %.splat111, splat (i64 32)
  %669 = add <8 x i64> %667, %668
  %670 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %666, 0
  %671 = insertvalue { <8 x ptr>, <8 x i64> } %670, <8 x i64> %669, 1
  %672 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %673 = extractvalue { <8 x ptr>, <8 x i64> } %671, 1
  %674 = extractelement <8 x ptr> %672, i32 0
  %675 = extractelement <8 x i64> %673, i32 0
  %676 = sub i64 %675, 0
  %677 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %678 = select i1 %677, i64 %676, i64 0
  %private.contiguous.address112 = getelementptr i8, ptr %674, i64 %678
  %private.contiguous.load113 = load <8 x float>, ptr %private.contiguous.address112, align 4
  %679 = select <8 x i1> %55, <8 x float> %private.contiguous.load113, <8 x float> zeroinitializer
  %.spill.load114 = load float, ptr %.spill22, align 4
  %.splatinsert115 = insertelement <8 x float> poison, float %.spill.load114, i64 0
  %.splat116 = shufflevector <8 x float> %.splatinsert115, <8 x float> poison, <8 x i32> zeroinitializer
  %680 = fsub <8 x float> %679, %.splat116
  %tile_snapshot.spill.load117 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %681 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load117, 0
  %682 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load117, 1
  %.state118 = load i64, ptr %.slot24, align 4
  %.splatinsert119 = insertelement <8 x i64> poison, i64 %.state118, i64 0
  %.splat120 = shufflevector <8 x i64> %.splatinsert119, <8 x i64> poison, <8 x i32> zeroinitializer
  %683 = mul <8 x i64> %.splat120, splat (i64 32)
  %684 = add <8 x i64> %682, %683
  %685 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %681, 0
  %686 = insertvalue { <8 x ptr>, <8 x i64> } %685, <8 x i64> %684, 1
  %687 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %688 = extractvalue { <8 x ptr>, <8 x i64> } %686, 1
  %689 = extractelement <8 x ptr> %687, i32 0
  %690 = extractelement <8 x i64> %688, i32 0
  %691 = sub i64 %690, 0
  %692 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %693 = select i1 %692, i64 %691, i64 0
  %private.contiguous.address121 = getelementptr i8, ptr %689, i64 %693
  %private.contiguous.preserve122 = load <8 x float>, ptr %private.contiguous.address121, align 4
  %694 = select <8 x i1> %55, <8 x float> %680, <8 x float> %private.contiguous.preserve122
  store <8 x float> %694, ptr %private.contiguous.address121, align 4
  %.state123 = load i64, ptr %.slot24, align 4
  %695 = add i64 %.state123, 1
  store i64 %695, ptr %.slot24, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false107
  %tile_snapshot.spill.load124 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %696 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load124, 0
  %697 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load124, 1
  %698 = add <8 x i64> %697, zeroinitializer
  %699 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %696, 0
  %700 = insertvalue { <8 x ptr>, <8 x i64> } %699, <8 x i64> %698, 1
  %701 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %702 = extractvalue { <8 x ptr>, <8 x i64> } %700, 1
  %703 = extractelement <8 x ptr> %701, i32 0
  %704 = extractelement <8 x i64> %702, i32 0
  %705 = sub i64 %704, 0
  %706 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %707 = select i1 %706, i64 %705, i64 0
  %private.contiguous.address125 = getelementptr i8, ptr %703, i64 %707
  %private.contiguous.load126 = load <8 x float>, ptr %private.contiguous.address125, align 4
  %708 = select <8 x i1> %55, <8 x float> %private.contiguous.load126, <8 x float> zeroinitializer
  %709 = fmul <8 x float> %708, %708
  %tile_snapshot.spill.load127 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %710 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load127, 0
  %711 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load127, 1
  %712 = add <8 x i64> %711, splat (i64 32)
  %713 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %710, 0
  %714 = insertvalue { <8 x ptr>, <8 x i64> } %713, <8 x i64> %712, 1
  %715 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %716 = extractvalue { <8 x ptr>, <8 x i64> } %714, 1
  %717 = extractelement <8 x ptr> %715, i32 0
  %718 = extractelement <8 x i64> %716, i32 0
  %719 = sub i64 %718, 0
  %720 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %721 = select i1 %720, i64 %719, i64 0
  %private.contiguous.address128 = getelementptr i8, ptr %717, i64 %721
  %private.contiguous.load129 = load <8 x float>, ptr %private.contiguous.address128, align 4
  %722 = select <8 x i1> %55, <8 x float> %private.contiguous.load129, <8 x float> zeroinitializer
  %723 = fmul <8 x float> %722, %722
  %tile_snapshot.spill.load130 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %724 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load130, 0
  %725 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load130, 1
  %726 = add <8 x i64> %725, splat (i64 64)
  %727 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %724, 0
  %728 = insertvalue { <8 x ptr>, <8 x i64> } %727, <8 x i64> %726, 1
  %729 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %730 = extractvalue { <8 x ptr>, <8 x i64> } %728, 1
  %731 = extractelement <8 x ptr> %729, i32 0
  %732 = extractelement <8 x i64> %730, i32 0
  %733 = sub i64 %732, 0
  %734 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %735 = select i1 %734, i64 %733, i64 0
  %private.contiguous.address131 = getelementptr i8, ptr %731, i64 %735
  %private.contiguous.load132 = load <8 x float>, ptr %private.contiguous.address131, align 4
  %736 = select <8 x i1> %55, <8 x float> %private.contiguous.load132, <8 x float> zeroinitializer
  %737 = fmul <8 x float> %736, %736
  %tile_snapshot.spill.load133 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %738 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load133, 0
  %739 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load133, 1
  %740 = add <8 x i64> %739, splat (i64 96)
  %741 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %738, 0
  %742 = insertvalue { <8 x ptr>, <8 x i64> } %741, <8 x i64> %740, 1
  %743 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %744 = extractvalue { <8 x ptr>, <8 x i64> } %742, 1
  %745 = extractelement <8 x ptr> %743, i32 0
  %746 = extractelement <8 x i64> %744, i32 0
  %747 = sub i64 %746, 0
  %748 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %749 = select i1 %748, i64 %747, i64 0
  %private.contiguous.address134 = getelementptr i8, ptr %745, i64 %749
  %private.contiguous.load135 = load <8 x float>, ptr %private.contiguous.address134, align 4
  %750 = select <8 x i1> %55, <8 x float> %private.contiguous.load135, <8 x float> zeroinitializer
  %751 = fmul <8 x float> %750, %750
  store i64 4, ptr %.slot25, align 4
  %752 = load <8 x float>, ptr %.slot26, align 32
  %753 = select <8 x i1> %55, <8 x float> %709, <8 x float> %752
  store <8 x float> %753, ptr %.slot26, align 32
  %754 = load <8 x float>, ptr %.slot27, align 32
  %755 = select <8 x i1> %55, <8 x float> %723, <8 x float> %754
  store <8 x float> %755, ptr %.slot27, align 32
  %756 = load <8 x float>, ptr %.slot28, align 32
  %757 = select <8 x i1> %55, <8 x float> %737, <8 x float> %756
  store <8 x float> %757, ptr %.slot28, align 32
  %758 = load <8 x float>, ptr %.slot29, align 32
  %759 = select <8 x i1> %55, <8 x float> %751, <8 x float> %758
  store <8 x float> %759, ptr %.slot29, align 32
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state136 = load i64, ptr %.slot25, align 4
  %760 = icmp slt i64 %.state136, 96
  br i1 %760, label %direct.true137, label %direct.false138

direct.schedule.11:                               ; preds = %direct.true137
  %.state139 = load i64, ptr %.slot25, align 4
  %761 = add i64 %.state139, 0
  %tile_snapshot.spill.load140 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %762 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load140, 0
  %763 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load140, 1
  %.splatinsert141 = insertelement <8 x i64> poison, i64 %761, i64 0
  %.splat142 = shufflevector <8 x i64> %.splatinsert141, <8 x i64> poison, <8 x i32> zeroinitializer
  %764 = mul <8 x i64> %.splat142, splat (i64 32)
  %765 = add <8 x i64> %763, %764
  %766 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %762, 0
  %767 = insertvalue { <8 x ptr>, <8 x i64> } %766, <8 x i64> %765, 1
  %768 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %769 = extractvalue { <8 x ptr>, <8 x i64> } %767, 1
  %770 = extractelement <8 x ptr> %768, i32 0
  %771 = extractelement <8 x i64> %769, i32 0
  %772 = sub i64 %771, 0
  %773 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %774 = select i1 %773, i64 %772, i64 0
  %private.contiguous.address143 = getelementptr i8, ptr %770, i64 %774
  %private.contiguous.load144 = load <8 x float>, ptr %private.contiguous.address143, align 4
  %775 = select <8 x i1> %55, <8 x float> %private.contiguous.load144, <8 x float> zeroinitializer
  %776 = fmul <8 x float> %775, %775
  %.state145 = load <8 x float>, ptr %.slot26, align 32
  %777 = fadd <8 x float> %.state145, %776
  %.state146 = load i64, ptr %.slot25, align 4
  %778 = add i64 %.state146, 1
  %tile_snapshot.spill.load147 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %779 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 0
  %780 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 1
  %.splatinsert148 = insertelement <8 x i64> poison, i64 %778, i64 0
  %.splat149 = shufflevector <8 x i64> %.splatinsert148, <8 x i64> poison, <8 x i32> zeroinitializer
  %781 = mul <8 x i64> %.splat149, splat (i64 32)
  %782 = add <8 x i64> %780, %781
  %783 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %779, 0
  %784 = insertvalue { <8 x ptr>, <8 x i64> } %783, <8 x i64> %782, 1
  %785 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %786 = extractvalue { <8 x ptr>, <8 x i64> } %784, 1
  %787 = extractelement <8 x ptr> %785, i32 0
  %788 = extractelement <8 x i64> %786, i32 0
  %789 = sub i64 %788, 0
  %790 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %791 = select i1 %790, i64 %789, i64 0
  %private.contiguous.address150 = getelementptr i8, ptr %787, i64 %791
  %private.contiguous.load151 = load <8 x float>, ptr %private.contiguous.address150, align 4
  %792 = select <8 x i1> %55, <8 x float> %private.contiguous.load151, <8 x float> zeroinitializer
  %793 = fmul <8 x float> %792, %792
  %.state152 = load <8 x float>, ptr %.slot27, align 32
  %794 = fadd <8 x float> %.state152, %793
  %.state153 = load i64, ptr %.slot25, align 4
  %795 = add i64 %.state153, 2
  %tile_snapshot.spill.load154 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %796 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load154, 0
  %797 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load154, 1
  %.splatinsert155 = insertelement <8 x i64> poison, i64 %795, i64 0
  %.splat156 = shufflevector <8 x i64> %.splatinsert155, <8 x i64> poison, <8 x i32> zeroinitializer
  %798 = mul <8 x i64> %.splat156, splat (i64 32)
  %799 = add <8 x i64> %797, %798
  %800 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %796, 0
  %801 = insertvalue { <8 x ptr>, <8 x i64> } %800, <8 x i64> %799, 1
  %802 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %803 = extractvalue { <8 x ptr>, <8 x i64> } %801, 1
  %804 = extractelement <8 x ptr> %802, i32 0
  %805 = extractelement <8 x i64> %803, i32 0
  %806 = sub i64 %805, 0
  %807 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %808 = select i1 %807, i64 %806, i64 0
  %private.contiguous.address157 = getelementptr i8, ptr %804, i64 %808
  %private.contiguous.load158 = load <8 x float>, ptr %private.contiguous.address157, align 4
  %809 = select <8 x i1> %55, <8 x float> %private.contiguous.load158, <8 x float> zeroinitializer
  %810 = fmul <8 x float> %809, %809
  %.state159 = load <8 x float>, ptr %.slot28, align 32
  %811 = fadd <8 x float> %.state159, %810
  %.state160 = load i64, ptr %.slot25, align 4
  %812 = add i64 %.state160, 3
  %tile_snapshot.spill.load161 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %813 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load161, 0
  %814 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load161, 1
  %.splatinsert162 = insertelement <8 x i64> poison, i64 %812, i64 0
  %.splat163 = shufflevector <8 x i64> %.splatinsert162, <8 x i64> poison, <8 x i32> zeroinitializer
  %815 = mul <8 x i64> %.splat163, splat (i64 32)
  %816 = add <8 x i64> %814, %815
  %817 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %813, 0
  %818 = insertvalue { <8 x ptr>, <8 x i64> } %817, <8 x i64> %816, 1
  %819 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %820 = extractvalue { <8 x ptr>, <8 x i64> } %818, 1
  %821 = extractelement <8 x ptr> %819, i32 0
  %822 = extractelement <8 x i64> %820, i32 0
  %823 = sub i64 %822, 0
  %824 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %825 = select i1 %824, i64 %823, i64 0
  %private.contiguous.address164 = getelementptr i8, ptr %821, i64 %825
  %private.contiguous.load165 = load <8 x float>, ptr %private.contiguous.address164, align 4
  %826 = select <8 x i1> %55, <8 x float> %private.contiguous.load165, <8 x float> zeroinitializer
  %827 = fmul <8 x float> %826, %826
  %.state166 = load <8 x float>, ptr %.slot29, align 32
  %828 = fadd <8 x float> %.state166, %827
  %.state167 = load i64, ptr %.slot25, align 4
  %829 = add i64 %.state167, 4
  store i64 %829, ptr %.slot25, align 4
  %830 = load <8 x float>, ptr %.slot26, align 32
  %831 = select <8 x i1> %55, <8 x float> %777, <8 x float> %830
  store <8 x float> %831, ptr %.slot26, align 32
  %832 = load <8 x float>, ptr %.slot27, align 32
  %833 = select <8 x i1> %55, <8 x float> %794, <8 x float> %832
  store <8 x float> %833, ptr %.slot27, align 32
  %834 = load <8 x float>, ptr %.slot28, align 32
  %835 = select <8 x i1> %55, <8 x float> %811, <8 x float> %834
  store <8 x float> %835, ptr %.slot28, align 32
  %836 = load <8 x float>, ptr %.slot29, align 32
  %837 = select <8 x i1> %55, <8 x float> %828, <8 x float> %836
  store <8 x float> %837, ptr %.slot29, align 32
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false138
  %.state168 = load <8 x float>, ptr %.slot26, align 32
  %.state169 = load <8 x float>, ptr %.slot27, align 32
  %838 = fadd <8 x float> %.state168, %.state169
  %.state170 = load <8 x float>, ptr %.slot28, align 32
  %839 = fadd <8 x float> %838, %.state170
  %.state171 = load <8 x float>, ptr %.slot29, align 32
  %840 = fadd <8 x float> %839, %.state171
  %.spill.load172 = load <8 x i32>, ptr %.spill18, align 32
  %841 = extractelement <8 x i32> %.spill.load172, i64 0
  %842 = icmp ult i32 %841, 8
  %843 = select i1 %842, i32 %841, i32 0
  %844 = extractelement <8 x i1> %55, i32 %843
  %845 = extractelement <8 x i1> %55, i64 0
  %846 = and i1 %842, %844
  %847 = and i1 %845, %846
  %848 = extractelement <8 x float> %840, i32 %843
  %849 = select i1 %847, float %848, float 0.000000e+00
  %850 = insertelement <8 x float> poison, float %849, i64 0
  %851 = xor i1 %847, true
  %852 = and i1 %845, %851
  %853 = insertelement <8 x i1> poison, i1 %852, i64 0
  %854 = extractelement <8 x i32> %.spill.load172, i64 1
  %855 = icmp ult i32 %854, 8
  %856 = select i1 %855, i32 %854, i32 0
  %857 = extractelement <8 x i1> %55, i32 %856
  %858 = extractelement <8 x i1> %55, i64 1
  %859 = and i1 %855, %857
  %860 = and i1 %858, %859
  %861 = extractelement <8 x float> %840, i32 %856
  %862 = select i1 %860, float %861, float 0.000000e+00
  %863 = insertelement <8 x float> %850, float %862, i64 1
  %864 = xor i1 %860, true
  %865 = and i1 %858, %864
  %866 = insertelement <8 x i1> %853, i1 %865, i64 1
  %867 = extractelement <8 x i32> %.spill.load172, i64 2
  %868 = icmp ult i32 %867, 8
  %869 = select i1 %868, i32 %867, i32 0
  %870 = extractelement <8 x i1> %55, i32 %869
  %871 = extractelement <8 x i1> %55, i64 2
  %872 = and i1 %868, %870
  %873 = and i1 %871, %872
  %874 = extractelement <8 x float> %840, i32 %869
  %875 = select i1 %873, float %874, float 0.000000e+00
  %876 = insertelement <8 x float> %863, float %875, i64 2
  %877 = xor i1 %873, true
  %878 = and i1 %871, %877
  %879 = insertelement <8 x i1> %866, i1 %878, i64 2
  %880 = extractelement <8 x i32> %.spill.load172, i64 3
  %881 = icmp ult i32 %880, 8
  %882 = select i1 %881, i32 %880, i32 0
  %883 = extractelement <8 x i1> %55, i32 %882
  %884 = extractelement <8 x i1> %55, i64 3
  %885 = and i1 %881, %883
  %886 = and i1 %884, %885
  %887 = extractelement <8 x float> %840, i32 %882
  %888 = select i1 %886, float %887, float 0.000000e+00
  %889 = insertelement <8 x float> %876, float %888, i64 3
  %890 = xor i1 %886, true
  %891 = and i1 %884, %890
  %892 = insertelement <8 x i1> %879, i1 %891, i64 3
  %893 = extractelement <8 x i32> %.spill.load172, i64 4
  %894 = icmp ult i32 %893, 8
  %895 = select i1 %894, i32 %893, i32 0
  %896 = extractelement <8 x i1> %55, i32 %895
  %897 = extractelement <8 x i1> %55, i64 4
  %898 = and i1 %894, %896
  %899 = and i1 %897, %898
  %900 = extractelement <8 x float> %840, i32 %895
  %901 = select i1 %899, float %900, float 0.000000e+00
  %902 = insertelement <8 x float> %889, float %901, i64 4
  %903 = xor i1 %899, true
  %904 = and i1 %897, %903
  %905 = insertelement <8 x i1> %892, i1 %904, i64 4
  %906 = extractelement <8 x i32> %.spill.load172, i64 5
  %907 = icmp ult i32 %906, 8
  %908 = select i1 %907, i32 %906, i32 0
  %909 = extractelement <8 x i1> %55, i32 %908
  %910 = extractelement <8 x i1> %55, i64 5
  %911 = and i1 %907, %909
  %912 = and i1 %910, %911
  %913 = extractelement <8 x float> %840, i32 %908
  %914 = select i1 %912, float %913, float 0.000000e+00
  %915 = insertelement <8 x float> %902, float %914, i64 5
  %916 = xor i1 %912, true
  %917 = and i1 %910, %916
  %918 = insertelement <8 x i1> %905, i1 %917, i64 5
  %919 = extractelement <8 x i32> %.spill.load172, i64 6
  %920 = icmp ult i32 %919, 8
  %921 = select i1 %920, i32 %919, i32 0
  %922 = extractelement <8 x i1> %55, i32 %921
  %923 = extractelement <8 x i1> %55, i64 6
  %924 = and i1 %920, %922
  %925 = and i1 %923, %924
  %926 = extractelement <8 x float> %840, i32 %921
  %927 = select i1 %925, float %926, float 0.000000e+00
  %928 = insertelement <8 x float> %915, float %927, i64 6
  %929 = xor i1 %925, true
  %930 = and i1 %923, %929
  %931 = insertelement <8 x i1> %918, i1 %930, i64 6
  %932 = extractelement <8 x i32> %.spill.load172, i64 7
  %933 = icmp ult i32 %932, 8
  %934 = select i1 %933, i32 %932, i32 0
  %935 = extractelement <8 x i1> %55, i32 %934
  %936 = extractelement <8 x i1> %55, i64 7
  %937 = and i1 %933, %935
  %938 = and i1 %936, %937
  %939 = extractelement <8 x float> %840, i32 %934
  %940 = select i1 %938, float %939, float 0.000000e+00
  %941 = insertelement <8 x float> %928, float %940, i64 7
  %942 = xor i1 %938, true
  %943 = and i1 %936, %942
  %944 = insertelement <8 x i1> %931, i1 %943, i64 7
  %945 = fadd <8 x float> %840, %941
  %.spill.load173 = load <8 x i32>, ptr %.spill19, align 32
  %946 = extractelement <8 x i32> %.spill.load173, i64 0
  %947 = icmp ult i32 %946, 8
  %948 = select i1 %947, i32 %946, i32 0
  %949 = extractelement <8 x i1> %55, i32 %948
  %950 = extractelement <8 x i1> %55, i64 0
  %951 = and i1 %947, %949
  %952 = and i1 %950, %951
  %953 = extractelement <8 x float> %945, i32 %948
  %954 = select i1 %952, float %953, float 0.000000e+00
  %955 = insertelement <8 x float> poison, float %954, i64 0
  %956 = xor i1 %952, true
  %957 = and i1 %950, %956
  %958 = insertelement <8 x i1> poison, i1 %957, i64 0
  %959 = extractelement <8 x i32> %.spill.load173, i64 1
  %960 = icmp ult i32 %959, 8
  %961 = select i1 %960, i32 %959, i32 0
  %962 = extractelement <8 x i1> %55, i32 %961
  %963 = extractelement <8 x i1> %55, i64 1
  %964 = and i1 %960, %962
  %965 = and i1 %963, %964
  %966 = extractelement <8 x float> %945, i32 %961
  %967 = select i1 %965, float %966, float 0.000000e+00
  %968 = insertelement <8 x float> %955, float %967, i64 1
  %969 = xor i1 %965, true
  %970 = and i1 %963, %969
  %971 = insertelement <8 x i1> %958, i1 %970, i64 1
  %972 = extractelement <8 x i32> %.spill.load173, i64 2
  %973 = icmp ult i32 %972, 8
  %974 = select i1 %973, i32 %972, i32 0
  %975 = extractelement <8 x i1> %55, i32 %974
  %976 = extractelement <8 x i1> %55, i64 2
  %977 = and i1 %973, %975
  %978 = and i1 %976, %977
  %979 = extractelement <8 x float> %945, i32 %974
  %980 = select i1 %978, float %979, float 0.000000e+00
  %981 = insertelement <8 x float> %968, float %980, i64 2
  %982 = xor i1 %978, true
  %983 = and i1 %976, %982
  %984 = insertelement <8 x i1> %971, i1 %983, i64 2
  %985 = extractelement <8 x i32> %.spill.load173, i64 3
  %986 = icmp ult i32 %985, 8
  %987 = select i1 %986, i32 %985, i32 0
  %988 = extractelement <8 x i1> %55, i32 %987
  %989 = extractelement <8 x i1> %55, i64 3
  %990 = and i1 %986, %988
  %991 = and i1 %989, %990
  %992 = extractelement <8 x float> %945, i32 %987
  %993 = select i1 %991, float %992, float 0.000000e+00
  %994 = insertelement <8 x float> %981, float %993, i64 3
  %995 = xor i1 %991, true
  %996 = and i1 %989, %995
  %997 = insertelement <8 x i1> %984, i1 %996, i64 3
  %998 = extractelement <8 x i32> %.spill.load173, i64 4
  %999 = icmp ult i32 %998, 8
  %1000 = select i1 %999, i32 %998, i32 0
  %1001 = extractelement <8 x i1> %55, i32 %1000
  %1002 = extractelement <8 x i1> %55, i64 4
  %1003 = and i1 %999, %1001
  %1004 = and i1 %1002, %1003
  %1005 = extractelement <8 x float> %945, i32 %1000
  %1006 = select i1 %1004, float %1005, float 0.000000e+00
  %1007 = insertelement <8 x float> %994, float %1006, i64 4
  %1008 = xor i1 %1004, true
  %1009 = and i1 %1002, %1008
  %1010 = insertelement <8 x i1> %997, i1 %1009, i64 4
  %1011 = extractelement <8 x i32> %.spill.load173, i64 5
  %1012 = icmp ult i32 %1011, 8
  %1013 = select i1 %1012, i32 %1011, i32 0
  %1014 = extractelement <8 x i1> %55, i32 %1013
  %1015 = extractelement <8 x i1> %55, i64 5
  %1016 = and i1 %1012, %1014
  %1017 = and i1 %1015, %1016
  %1018 = extractelement <8 x float> %945, i32 %1013
  %1019 = select i1 %1017, float %1018, float 0.000000e+00
  %1020 = insertelement <8 x float> %1007, float %1019, i64 5
  %1021 = xor i1 %1017, true
  %1022 = and i1 %1015, %1021
  %1023 = insertelement <8 x i1> %1010, i1 %1022, i64 5
  %1024 = extractelement <8 x i32> %.spill.load173, i64 6
  %1025 = icmp ult i32 %1024, 8
  %1026 = select i1 %1025, i32 %1024, i32 0
  %1027 = extractelement <8 x i1> %55, i32 %1026
  %1028 = extractelement <8 x i1> %55, i64 6
  %1029 = and i1 %1025, %1027
  %1030 = and i1 %1028, %1029
  %1031 = extractelement <8 x float> %945, i32 %1026
  %1032 = select i1 %1030, float %1031, float 0.000000e+00
  %1033 = insertelement <8 x float> %1020, float %1032, i64 6
  %1034 = xor i1 %1030, true
  %1035 = and i1 %1028, %1034
  %1036 = insertelement <8 x i1> %1023, i1 %1035, i64 6
  %1037 = extractelement <8 x i32> %.spill.load173, i64 7
  %1038 = icmp ult i32 %1037, 8
  %1039 = select i1 %1038, i32 %1037, i32 0
  %1040 = extractelement <8 x i1> %55, i32 %1039
  %1041 = extractelement <8 x i1> %55, i64 7
  %1042 = and i1 %1038, %1040
  %1043 = and i1 %1041, %1042
  %1044 = extractelement <8 x float> %945, i32 %1039
  %1045 = select i1 %1043, float %1044, float 0.000000e+00
  %1046 = insertelement <8 x float> %1033, float %1045, i64 7
  %1047 = xor i1 %1043, true
  %1048 = and i1 %1041, %1047
  %1049 = insertelement <8 x i1> %1036, i1 %1048, i64 7
  %1050 = fadd <8 x float> %945, %1046
  %.spill.load174 = load <8 x i32>, ptr %.spill20, align 32
  %1051 = extractelement <8 x i32> %.spill.load174, i64 0
  %1052 = icmp ult i32 %1051, 8
  %1053 = select i1 %1052, i32 %1051, i32 0
  %1054 = extractelement <8 x i1> %55, i32 %1053
  %1055 = extractelement <8 x i1> %55, i64 0
  %1056 = and i1 %1052, %1054
  %1057 = and i1 %1055, %1056
  %1058 = extractelement <8 x float> %1050, i32 %1053
  %1059 = select i1 %1057, float %1058, float 0.000000e+00
  %1060 = insertelement <8 x float> poison, float %1059, i64 0
  %1061 = xor i1 %1057, true
  %1062 = and i1 %1055, %1061
  %1063 = insertelement <8 x i1> poison, i1 %1062, i64 0
  %1064 = extractelement <8 x i32> %.spill.load174, i64 1
  %1065 = icmp ult i32 %1064, 8
  %1066 = select i1 %1065, i32 %1064, i32 0
  %1067 = extractelement <8 x i1> %55, i32 %1066
  %1068 = extractelement <8 x i1> %55, i64 1
  %1069 = and i1 %1065, %1067
  %1070 = and i1 %1068, %1069
  %1071 = extractelement <8 x float> %1050, i32 %1066
  %1072 = select i1 %1070, float %1071, float 0.000000e+00
  %1073 = insertelement <8 x float> %1060, float %1072, i64 1
  %1074 = xor i1 %1070, true
  %1075 = and i1 %1068, %1074
  %1076 = insertelement <8 x i1> %1063, i1 %1075, i64 1
  %1077 = extractelement <8 x i32> %.spill.load174, i64 2
  %1078 = icmp ult i32 %1077, 8
  %1079 = select i1 %1078, i32 %1077, i32 0
  %1080 = extractelement <8 x i1> %55, i32 %1079
  %1081 = extractelement <8 x i1> %55, i64 2
  %1082 = and i1 %1078, %1080
  %1083 = and i1 %1081, %1082
  %1084 = extractelement <8 x float> %1050, i32 %1079
  %1085 = select i1 %1083, float %1084, float 0.000000e+00
  %1086 = insertelement <8 x float> %1073, float %1085, i64 2
  %1087 = xor i1 %1083, true
  %1088 = and i1 %1081, %1087
  %1089 = insertelement <8 x i1> %1076, i1 %1088, i64 2
  %1090 = extractelement <8 x i32> %.spill.load174, i64 3
  %1091 = icmp ult i32 %1090, 8
  %1092 = select i1 %1091, i32 %1090, i32 0
  %1093 = extractelement <8 x i1> %55, i32 %1092
  %1094 = extractelement <8 x i1> %55, i64 3
  %1095 = and i1 %1091, %1093
  %1096 = and i1 %1094, %1095
  %1097 = extractelement <8 x float> %1050, i32 %1092
  %1098 = select i1 %1096, float %1097, float 0.000000e+00
  %1099 = insertelement <8 x float> %1086, float %1098, i64 3
  %1100 = xor i1 %1096, true
  %1101 = and i1 %1094, %1100
  %1102 = insertelement <8 x i1> %1089, i1 %1101, i64 3
  %1103 = extractelement <8 x i32> %.spill.load174, i64 4
  %1104 = icmp ult i32 %1103, 8
  %1105 = select i1 %1104, i32 %1103, i32 0
  %1106 = extractelement <8 x i1> %55, i32 %1105
  %1107 = extractelement <8 x i1> %55, i64 4
  %1108 = and i1 %1104, %1106
  %1109 = and i1 %1107, %1108
  %1110 = extractelement <8 x float> %1050, i32 %1105
  %1111 = select i1 %1109, float %1110, float 0.000000e+00
  %1112 = insertelement <8 x float> %1099, float %1111, i64 4
  %1113 = xor i1 %1109, true
  %1114 = and i1 %1107, %1113
  %1115 = insertelement <8 x i1> %1102, i1 %1114, i64 4
  %1116 = extractelement <8 x i32> %.spill.load174, i64 5
  %1117 = icmp ult i32 %1116, 8
  %1118 = select i1 %1117, i32 %1116, i32 0
  %1119 = extractelement <8 x i1> %55, i32 %1118
  %1120 = extractelement <8 x i1> %55, i64 5
  %1121 = and i1 %1117, %1119
  %1122 = and i1 %1120, %1121
  %1123 = extractelement <8 x float> %1050, i32 %1118
  %1124 = select i1 %1122, float %1123, float 0.000000e+00
  %1125 = insertelement <8 x float> %1112, float %1124, i64 5
  %1126 = xor i1 %1122, true
  %1127 = and i1 %1120, %1126
  %1128 = insertelement <8 x i1> %1115, i1 %1127, i64 5
  %1129 = extractelement <8 x i32> %.spill.load174, i64 6
  %1130 = icmp ult i32 %1129, 8
  %1131 = select i1 %1130, i32 %1129, i32 0
  %1132 = extractelement <8 x i1> %55, i32 %1131
  %1133 = extractelement <8 x i1> %55, i64 6
  %1134 = and i1 %1130, %1132
  %1135 = and i1 %1133, %1134
  %1136 = extractelement <8 x float> %1050, i32 %1131
  %1137 = select i1 %1135, float %1136, float 0.000000e+00
  %1138 = insertelement <8 x float> %1125, float %1137, i64 6
  %1139 = xor i1 %1135, true
  %1140 = and i1 %1133, %1139
  %1141 = insertelement <8 x i1> %1128, i1 %1140, i64 6
  %1142 = extractelement <8 x i32> %.spill.load174, i64 7
  %1143 = icmp ult i32 %1142, 8
  %1144 = select i1 %1143, i32 %1142, i32 0
  %1145 = extractelement <8 x i1> %55, i32 %1144
  %1146 = extractelement <8 x i1> %55, i64 7
  %1147 = and i1 %1143, %1145
  %1148 = and i1 %1146, %1147
  %1149 = extractelement <8 x float> %1050, i32 %1144
  %1150 = select i1 %1148, float %1149, float 0.000000e+00
  %1151 = insertelement <8 x float> %1138, float %1150, i64 7
  %1152 = xor i1 %1148, true
  %1153 = and i1 %1146, %1152
  %1154 = insertelement <8 x i1> %1141, i1 %1153, i64 7
  %1155 = fadd <8 x float> %1050, %1151
  %1156 = extractelement <8 x i1> %55, i32 0
  %1157 = extractelement <8 x i1> %55, i64 0
  %1158 = and i1 true, %1156
  %1159 = and i1 %1157, %1158
  %1160 = extractelement <8 x float> %1155, i32 0
  %1161 = select i1 %1159, float %1160, float 0.000000e+00
  %1162 = insertelement <8 x float> poison, float %1161, i64 0
  %1163 = xor i1 %1159, true
  %1164 = and i1 %1157, %1163
  %1165 = insertelement <8 x i1> poison, i1 %1164, i64 0
  %1166 = extractelement <8 x i1> %55, i32 0
  %1167 = extractelement <8 x i1> %55, i64 1
  %1168 = and i1 true, %1166
  %1169 = and i1 %1167, %1168
  %1170 = extractelement <8 x float> %1155, i32 0
  %1171 = select i1 %1169, float %1170, float 0.000000e+00
  %1172 = insertelement <8 x float> %1162, float %1171, i64 1
  %1173 = xor i1 %1169, true
  %1174 = and i1 %1167, %1173
  %1175 = insertelement <8 x i1> %1165, i1 %1174, i64 1
  %1176 = extractelement <8 x i1> %55, i32 0
  %1177 = extractelement <8 x i1> %55, i64 2
  %1178 = and i1 true, %1176
  %1179 = and i1 %1177, %1178
  %1180 = extractelement <8 x float> %1155, i32 0
  %1181 = select i1 %1179, float %1180, float 0.000000e+00
  %1182 = insertelement <8 x float> %1172, float %1181, i64 2
  %1183 = xor i1 %1179, true
  %1184 = and i1 %1177, %1183
  %1185 = insertelement <8 x i1> %1175, i1 %1184, i64 2
  %1186 = extractelement <8 x i1> %55, i32 0
  %1187 = extractelement <8 x i1> %55, i64 3
  %1188 = and i1 true, %1186
  %1189 = and i1 %1187, %1188
  %1190 = extractelement <8 x float> %1155, i32 0
  %1191 = select i1 %1189, float %1190, float 0.000000e+00
  %1192 = insertelement <8 x float> %1182, float %1191, i64 3
  %1193 = xor i1 %1189, true
  %1194 = and i1 %1187, %1193
  %1195 = insertelement <8 x i1> %1185, i1 %1194, i64 3
  %1196 = extractelement <8 x i1> %55, i32 0
  %1197 = extractelement <8 x i1> %55, i64 4
  %1198 = and i1 true, %1196
  %1199 = and i1 %1197, %1198
  %1200 = extractelement <8 x float> %1155, i32 0
  %1201 = select i1 %1199, float %1200, float 0.000000e+00
  %1202 = insertelement <8 x float> %1192, float %1201, i64 4
  %1203 = xor i1 %1199, true
  %1204 = and i1 %1197, %1203
  %1205 = insertelement <8 x i1> %1195, i1 %1204, i64 4
  %1206 = extractelement <8 x i1> %55, i32 0
  %1207 = extractelement <8 x i1> %55, i64 5
  %1208 = and i1 true, %1206
  %1209 = and i1 %1207, %1208
  %1210 = extractelement <8 x float> %1155, i32 0
  %1211 = select i1 %1209, float %1210, float 0.000000e+00
  %1212 = insertelement <8 x float> %1202, float %1211, i64 5
  %1213 = xor i1 %1209, true
  %1214 = and i1 %1207, %1213
  %1215 = insertelement <8 x i1> %1205, i1 %1214, i64 5
  %1216 = extractelement <8 x i1> %55, i32 0
  %1217 = extractelement <8 x i1> %55, i64 6
  %1218 = and i1 true, %1216
  %1219 = and i1 %1217, %1218
  %1220 = extractelement <8 x float> %1155, i32 0
  %1221 = select i1 %1219, float %1220, float 0.000000e+00
  %1222 = insertelement <8 x float> %1212, float %1221, i64 6
  %1223 = xor i1 %1219, true
  %1224 = and i1 %1217, %1223
  %1225 = insertelement <8 x i1> %1215, i1 %1224, i64 6
  %1226 = extractelement <8 x i1> %55, i32 0
  %1227 = extractelement <8 x i1> %55, i64 7
  %1228 = and i1 true, %1226
  %1229 = and i1 %1227, %1228
  %1230 = extractelement <8 x float> %1155, i32 0
  %1231 = select i1 %1229, float %1230, float 0.000000e+00
  %1232 = insertelement <8 x float> %1222, float %1231, i64 7
  %1233 = xor i1 %1229, true
  %1234 = and i1 %1227, %1233
  %1235 = insertelement <8 x i1> %1225, i1 %1234, i64 7
  %1236 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1237 = bitcast <8 x i1> %55 to i8
  %1238 = call i8 @llvm.cttz.i8(i8 %1237, i1 false)
  %1239 = zext i8 %1238 to i32
  %1240 = select i1 %1236, i32 %1239, i32 0
  %1241 = extractelement <8 x float> %1232, i32 %1240
  %.spill.load175 = load float, ptr %.spill11, align 4
  %1242 = fadd float %.spill.load175, %1241
  %.spill.load176 = load float, ptr %.spill21, align 4
  %1243 = fdiv float %1242, %.spill.load176
  store float %1243, ptr %.spill30, align 4
  %1244 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1245 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1246 = extractvalue { <8 x ptr>, <8 x i64> } %1244, 0
  %1247 = select <8 x i1> %55, <8 x ptr> %1245, <8 x ptr> %1246
  %1248 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1249 = extractvalue { <8 x ptr>, <8 x i64> } %1244, 1
  %1250 = select <8 x i1> %55, <8 x i64> %1248, <8 x i64> %1249
  %1251 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1247, 0
  %1252 = insertvalue { <8 x ptr>, <8 x i64> } %1251, <8 x i64> %1250, 1
  store { <8 x ptr>, <8 x i64> } %1252, ptr %tile_snapshot.spill31, align 64
  store i64 0, ptr %.slot32, align 4
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state177 = load i64, ptr %.slot32, align 4
  %1253 = icmp slt i64 %.state177, 96
  br i1 %1253, label %direct.true178, label %direct.false179

direct.schedule.14:                               ; preds = %direct.true178
  %.state180 = load i64, ptr %.slot32, align 4
  %1254 = mul i64 %.state180, 8
  %.splatinsert181 = insertelement <8 x i64> poison, i64 %1254, i64 0
  %.splat182 = shufflevector <8 x i64> %.splatinsert181, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load183 = load <8 x i64>, ptr %.spill, align 64
  %1255 = add <8 x i64> %.splat182, %.spill.load183
  %.spill.load184 = load i64, ptr %.spill12, align 4
  %1256 = add i64 %.spill.load184, 0
  %1257 = add <8 x i64> zeroinitializer, %1255
  %1258 = mul i64 %1256, 768
  %.splatinsert185 = insertelement <8 x i64> poison, i64 %1258, i64 0
  %.splat186 = shufflevector <8 x i64> %.splatinsert185, <8 x i64> poison, <8 x i32> zeroinitializer
  %1259 = add <8 x i64> %.splat186, %1257
  %1260 = extractvalue { ptr, i64 } %19, 0
  %1261 = extractelement <8 x i64> %1259, i32 0
  %1262 = sub i64 %1261, 0
  %1263 = mul i64 %1262, 4
  %buffer.contiguous.address187 = getelementptr i8, ptr %1260, i64 %1263
  %buffer.contiguous.load188 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address187, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load189 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1264 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 0
  %1265 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 1
  %.state190 = load i64, ptr %.slot32, align 4
  %.splatinsert191 = insertelement <8 x i64> poison, i64 %.state190, i64 0
  %.splat192 = shufflevector <8 x i64> %.splatinsert191, <8 x i64> poison, <8 x i32> zeroinitializer
  %1266 = mul <8 x i64> %.splat192, splat (i64 32)
  %1267 = add <8 x i64> %1265, %1266
  %1268 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1264, 0
  %1269 = insertvalue { <8 x ptr>, <8 x i64> } %1268, <8 x i64> %1267, 1
  %1270 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1271 = extractvalue { <8 x ptr>, <8 x i64> } %1269, 1
  %1272 = extractelement <8 x ptr> %1270, i32 0
  %1273 = extractelement <8 x i64> %1271, i32 0
  %1274 = sub i64 %1273, 0
  %1275 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1276 = select i1 %1275, i64 %1274, i64 0
  %private.contiguous.address193 = getelementptr i8, ptr %1272, i64 %1276
  %private.contiguous.preserve194 = load <8 x float>, ptr %private.contiguous.address193, align 4
  %1277 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load188, <8 x float> %private.contiguous.preserve194
  store <8 x float> %1277, ptr %private.contiguous.address193, align 4
  %.state195 = load i64, ptr %.slot32, align 4
  %1278 = add i64 %.state195, 1
  store i64 %1278, ptr %.slot32, align 4
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false179
  %.spill.load196 = load float, ptr %.spill30, align 4
  %1279 = fadd float %.spill.load196, 0x3EE4F8B580000000
  %1280 = call float @llvm.sqrt.f32(float %1279)
  store float %1280, ptr %.spill33, align 4
  %1281 = extractvalue { ptr, i64 } %25, 1
  %1282 = extractvalue { ptr, i64 } %25, 0
  %1283 = ptrtoint ptr %1282 to i64
  %1284 = extractvalue { ptr, i64 } %31, 1
  %1285 = extractvalue { ptr, i64 } %31, 0
  %1286 = ptrtoint ptr %1285 to i64
  %1287 = icmp uge i64 %1283, %1286
  %1288 = sub i64 %1283, %1286
  %1289 = icmp uge i64 %1288, 396288
  %1290 = and i1 %1287, %1289
  %1291 = icmp uge i64 %1286, %1283
  %1292 = sub i64 %1286, %1283
  %1293 = icmp uge i64 %1292, 3072
  %1294 = and i1 %1291, %1293
  %1295 = or i1 %1290, %1294
  %1296 = and i1 true, %1295
  br i1 %1296, label %direct.true197, label %direct.false198

direct.schedule.16:                               ; preds = %direct.true197
  store i64 0, ptr %.slot34, align 4
  br label %direct.schedule.17

direct.schedule.17:                               ; preds = %direct.schedule.18, %direct.schedule.16
  %.state199 = load i64, ptr %.slot34, align 4
  %1297 = icmp slt i64 %.state199, 96
  br i1 %1297, label %direct.true200, label %direct.false201

direct.schedule.18:                               ; preds = %direct.true200
  %.state202 = load i64, ptr %.slot34, align 4
  %1298 = mul i64 %.state202, 8
  %.splatinsert203 = insertelement <8 x i64> poison, i64 %1298, i64 0
  %.splat204 = shufflevector <8 x i64> %.splatinsert203, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load205 = load <8 x i64>, ptr %.spill, align 64
  %1299 = add <8 x i64> %.splat204, %.spill.load205
  %tile_snapshot.spill.load206 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %1300 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load206, 0
  %1301 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load206, 1
  %.state207 = load i64, ptr %.slot34, align 4
  %.splatinsert208 = insertelement <8 x i64> poison, i64 %.state207, i64 0
  %.splat209 = shufflevector <8 x i64> %.splatinsert208, <8 x i64> poison, <8 x i32> zeroinitializer
  %1302 = mul <8 x i64> %.splat209, splat (i64 32)
  %1303 = add <8 x i64> %1301, %1302
  %1304 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1300, 0
  %1305 = insertvalue { <8 x ptr>, <8 x i64> } %1304, <8 x i64> %1303, 1
  %1306 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1307 = extractvalue { <8 x ptr>, <8 x i64> } %1305, 1
  %1308 = extractelement <8 x ptr> %1306, i32 0
  %1309 = extractelement <8 x i64> %1307, i32 0
  %1310 = sub i64 %1309, 0
  %1311 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1312 = select i1 %1311, i64 %1310, i64 0
  %private.contiguous.address210 = getelementptr i8, ptr %1308, i64 %1312
  %private.contiguous.load211 = load <8 x float>, ptr %private.contiguous.address210, align 4
  %1313 = select <8 x i1> %55, <8 x float> %private.contiguous.load211, <8 x float> zeroinitializer
  %.spill.load212 = load float, ptr %.spill33, align 4
  %.splatinsert213 = insertelement <8 x float> poison, float %.spill.load212, i64 0
  %.splat214 = shufflevector <8 x float> %.splatinsert213, <8 x float> poison, <8 x i32> zeroinitializer
  %1314 = fdiv <8 x float> %1313, %.splat214
  %tile_snapshot.spill.load215 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1315 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load215, 0
  %1316 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load215, 1
  %.state216 = load i64, ptr %.slot34, align 4
  %.splatinsert217 = insertelement <8 x i64> poison, i64 %.state216, i64 0
  %.splat218 = shufflevector <8 x i64> %.splatinsert217, <8 x i64> poison, <8 x i32> zeroinitializer
  %1317 = mul <8 x i64> %.splat218, splat (i64 32)
  %1318 = add <8 x i64> %1316, %1317
  %1319 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1315, 0
  %1320 = insertvalue { <8 x ptr>, <8 x i64> } %1319, <8 x i64> %1318, 1
  %1321 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1322 = extractvalue { <8 x ptr>, <8 x i64> } %1320, 1
  %1323 = extractelement <8 x ptr> %1321, i32 0
  %1324 = extractelement <8 x i64> %1322, i32 0
  %1325 = sub i64 %1324, 0
  %1326 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1327 = select i1 %1326, i64 %1325, i64 0
  %private.contiguous.address219 = getelementptr i8, ptr %1323, i64 %1327
  %private.contiguous.load220 = load <8 x float>, ptr %private.contiguous.address219, align 4
  %1328 = select <8 x i1> %55, <8 x float> %private.contiguous.load220, <8 x float> zeroinitializer
  %1329 = fmul <8 x float> %1314, %1328
  %.spill.load221 = load i64, ptr %.spill12, align 4
  %1330 = add i64 %.spill.load221, 0
  %1331 = add <8 x i64> zeroinitializer, %1299
  %1332 = mul i64 %1330, 768
  %.splatinsert222 = insertelement <8 x i64> poison, i64 %1332, i64 0
  %.splat223 = shufflevector <8 x i64> %.splatinsert222, <8 x i64> poison, <8 x i32> zeroinitializer
  %1333 = add <8 x i64> %.splat223, %1331
  %1334 = extractvalue { ptr, i64 } %25, 0
  %1335 = extractelement <8 x i64> %1333, i32 0
  %1336 = sub i64 %1335, 0
  %1337 = mul i64 %1336, 4
  %buffer.contiguous.address224 = getelementptr i8, ptr %1334, i64 %1337
  %buffer.contiguous.load225 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address224, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %1338 = fadd <8 x float> %1329, %buffer.contiguous.load225
  %.spill.load226 = load <8 x i64>, ptr %.spill10, align 64
  %1339 = add <8 x i64> %.spill.load226, zeroinitializer
  %1340 = add <8 x i64> zeroinitializer, %1339
  %1341 = mul <8 x i64> %1340, splat (i64 768)
  %1342 = add <8 x i64> %1341, %1331
  %1343 = extractvalue { ptr, i64 } %31, 0
  %1344 = extractelement <8 x i64> %1342, i32 0
  %1345 = sub i64 %1344, 0
  %1346 = mul i64 %1345, 4
  %buffer.contiguous.address227 = getelementptr i8, ptr %1343, i64 %1346
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1338, ptr %buffer.contiguous.address227, i32 1, <8 x i1> %55)
  %.state228 = load i64, ptr %.slot34, align 4
  %1347 = add i64 %.state228, 1
  store i64 %1347, ptr %.slot34, align 4
  br label %direct.schedule.17

direct.schedule.19:                               ; preds = %direct.false250, %direct.false201
  ret void

direct.schedule.20:                               ; preds = %direct.false198
  %1348 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1349 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1350 = extractvalue { <8 x ptr>, <8 x i64> } %1348, 0
  %1351 = select <8 x i1> %55, <8 x ptr> %1349, <8 x ptr> %1350
  %1352 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %1353 = extractvalue { <8 x ptr>, <8 x i64> } %1348, 1
  %1354 = select <8 x i1> %55, <8 x i64> %1352, <8 x i64> %1353
  %1355 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1351, 0
  %1356 = insertvalue { <8 x ptr>, <8 x i64> } %1355, <8 x i64> %1354, 1
  store { <8 x ptr>, <8 x i64> } %1356, ptr %tile_snapshot.spill35, align 64
  store i64 0, ptr %.slot36, align 4
  br label %direct.schedule.21

direct.schedule.21:                               ; preds = %direct.schedule.22, %direct.schedule.20
  %.state229 = load i64, ptr %.slot36, align 4
  %1357 = icmp slt i64 %.state229, 96
  br i1 %1357, label %direct.true230, label %direct.false231

direct.schedule.22:                               ; preds = %direct.true230
  %.state232 = load i64, ptr %.slot36, align 4
  %1358 = mul i64 %.state232, 8
  %.splatinsert233 = insertelement <8 x i64> poison, i64 %1358, i64 0
  %.splat234 = shufflevector <8 x i64> %.splatinsert233, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load235 = load <8 x i64>, ptr %.spill, align 64
  %1359 = add <8 x i64> %.splat234, %.spill.load235
  %.spill.load236 = load i64, ptr %.spill12, align 4
  %1360 = add i64 %.spill.load236, 0
  %1361 = add <8 x i64> zeroinitializer, %1359
  %1362 = mul i64 %1360, 768
  %.splatinsert237 = insertelement <8 x i64> poison, i64 %1362, i64 0
  %.splat238 = shufflevector <8 x i64> %.splatinsert237, <8 x i64> poison, <8 x i32> zeroinitializer
  %1363 = add <8 x i64> %.splat238, %1361
  %1364 = extractvalue { ptr, i64 } %25, 0
  %1365 = extractelement <8 x i64> %1363, i32 0
  %1366 = sub i64 %1365, 0
  %1367 = mul i64 %1366, 4
  %buffer.contiguous.address239 = getelementptr i8, ptr %1364, i64 %1367
  %buffer.contiguous.load240 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address239, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load241 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1368 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load241, 0
  %1369 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load241, 1
  %.state242 = load i64, ptr %.slot36, align 4
  %.splatinsert243 = insertelement <8 x i64> poison, i64 %.state242, i64 0
  %.splat244 = shufflevector <8 x i64> %.splatinsert243, <8 x i64> poison, <8 x i32> zeroinitializer
  %1370 = mul <8 x i64> %.splat244, splat (i64 32)
  %1371 = add <8 x i64> %1369, %1370
  %1372 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1368, 0
  %1373 = insertvalue { <8 x ptr>, <8 x i64> } %1372, <8 x i64> %1371, 1
  %1374 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1375 = extractvalue { <8 x ptr>, <8 x i64> } %1373, 1
  %1376 = extractelement <8 x ptr> %1374, i32 0
  %1377 = extractelement <8 x i64> %1375, i32 0
  %1378 = sub i64 %1377, 0
  %1379 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1380 = select i1 %1379, i64 %1378, i64 0
  %private.contiguous.address245 = getelementptr i8, ptr %1376, i64 %1380
  %private.contiguous.preserve246 = load <8 x float>, ptr %private.contiguous.address245, align 4
  %1381 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load240, <8 x float> %private.contiguous.preserve246
  store <8 x float> %1381, ptr %private.contiguous.address245, align 4
  %.state247 = load i64, ptr %.slot36, align 4
  %1382 = add i64 %.state247, 1
  store i64 %1382, ptr %.slot36, align 4
  br label %direct.schedule.21

direct.schedule.23:                               ; preds = %direct.false231
  store i64 0, ptr %.slot37, align 4
  br label %direct.schedule.24

direct.schedule.24:                               ; preds = %direct.schedule.25, %direct.schedule.23
  %.state248 = load i64, ptr %.slot37, align 4
  %1383 = icmp slt i64 %.state248, 96
  br i1 %1383, label %direct.true249, label %direct.false250

direct.schedule.25:                               ; preds = %direct.true249
  %.state251 = load i64, ptr %.slot37, align 4
  %1384 = mul i64 %.state251, 8
  %.splatinsert252 = insertelement <8 x i64> poison, i64 %1384, i64 0
  %.splat253 = shufflevector <8 x i64> %.splatinsert252, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load254 = load <8 x i64>, ptr %.spill, align 64
  %1385 = add <8 x i64> %.splat253, %.spill.load254
  %.spill.load255 = load <8 x i64>, ptr %.spill10, align 64
  %1386 = add <8 x i64> %.spill.load255, zeroinitializer
  %1387 = add <8 x i64> zeroinitializer, %1386
  %1388 = add <8 x i64> zeroinitializer, %1385
  %1389 = mul <8 x i64> %1387, splat (i64 768)
  %1390 = add <8 x i64> %1389, %1388
  %tile_snapshot.spill.load256 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %1391 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load256, 0
  %1392 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load256, 1
  %.state257 = load i64, ptr %.slot37, align 4
  %.splatinsert258 = insertelement <8 x i64> poison, i64 %.state257, i64 0
  %.splat259 = shufflevector <8 x i64> %.splatinsert258, <8 x i64> poison, <8 x i32> zeroinitializer
  %1393 = mul <8 x i64> %.splat259, splat (i64 32)
  %1394 = add <8 x i64> %1392, %1393
  %1395 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1391, 0
  %1396 = insertvalue { <8 x ptr>, <8 x i64> } %1395, <8 x i64> %1394, 1
  %1397 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1398 = extractvalue { <8 x ptr>, <8 x i64> } %1396, 1
  %1399 = extractelement <8 x ptr> %1397, i32 0
  %1400 = extractelement <8 x i64> %1398, i32 0
  %1401 = sub i64 %1400, 0
  %1402 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1403 = select i1 %1402, i64 %1401, i64 0
  %private.contiguous.address260 = getelementptr i8, ptr %1399, i64 %1403
  %private.contiguous.load261 = load <8 x float>, ptr %private.contiguous.address260, align 4
  %1404 = select <8 x i1> %55, <8 x float> %private.contiguous.load261, <8 x float> zeroinitializer
  %.spill.load262 = load float, ptr %.spill33, align 4
  %.splatinsert263 = insertelement <8 x float> poison, float %.spill.load262, i64 0
  %.splat264 = shufflevector <8 x float> %.splatinsert263, <8 x float> poison, <8 x i32> zeroinitializer
  %1405 = fdiv <8 x float> %1404, %.splat264
  %tile_snapshot.spill.load265 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1406 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load265, 0
  %1407 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load265, 1
  %.state266 = load i64, ptr %.slot37, align 4
  %.splatinsert267 = insertelement <8 x i64> poison, i64 %.state266, i64 0
  %.splat268 = shufflevector <8 x i64> %.splatinsert267, <8 x i64> poison, <8 x i32> zeroinitializer
  %1408 = mul <8 x i64> %.splat268, splat (i64 32)
  %1409 = add <8 x i64> %1407, %1408
  %1410 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1406, 0
  %1411 = insertvalue { <8 x ptr>, <8 x i64> } %1410, <8 x i64> %1409, 1
  %1412 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1413 = extractvalue { <8 x ptr>, <8 x i64> } %1411, 1
  %1414 = extractelement <8 x ptr> %1412, i32 0
  %1415 = extractelement <8 x i64> %1413, i32 0
  %1416 = sub i64 %1415, 0
  %1417 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1418 = select i1 %1417, i64 %1416, i64 0
  %private.contiguous.address269 = getelementptr i8, ptr %1414, i64 %1418
  %private.contiguous.load270 = load <8 x float>, ptr %private.contiguous.address269, align 4
  %1419 = select <8 x i1> %55, <8 x float> %private.contiguous.load270, <8 x float> zeroinitializer
  %1420 = fmul <8 x float> %1405, %1419
  %tile_snapshot.spill.load271 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1421 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 0
  %1422 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 1
  %.state272 = load i64, ptr %.slot37, align 4
  %.splatinsert273 = insertelement <8 x i64> poison, i64 %.state272, i64 0
  %.splat274 = shufflevector <8 x i64> %.splatinsert273, <8 x i64> poison, <8 x i32> zeroinitializer
  %1423 = mul <8 x i64> %.splat274, splat (i64 32)
  %1424 = add <8 x i64> %1422, %1423
  %1425 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1421, 0
  %1426 = insertvalue { <8 x ptr>, <8 x i64> } %1425, <8 x i64> %1424, 1
  %1427 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1428 = extractvalue { <8 x ptr>, <8 x i64> } %1426, 1
  %1429 = extractelement <8 x ptr> %1427, i32 0
  %1430 = extractelement <8 x i64> %1428, i32 0
  %1431 = sub i64 %1430, 0
  %1432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1433 = select i1 %1432, i64 %1431, i64 0
  %private.contiguous.address275 = getelementptr i8, ptr %1429, i64 %1433
  %private.contiguous.load276 = load <8 x float>, ptr %private.contiguous.address275, align 4
  %1434 = select <8 x i1> %55, <8 x float> %private.contiguous.load276, <8 x float> zeroinitializer
  %1435 = fadd <8 x float> %1420, %1434
  %1436 = extractvalue { ptr, i64 } %31, 0
  %1437 = extractelement <8 x i64> %1390, i32 0
  %1438 = sub i64 %1437, 0
  %1439 = mul i64 %1438, 4
  %buffer.contiguous.address277 = getelementptr i8, ptr %1436, i64 %1439
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1435, ptr %buffer.contiguous.address277, i32 1, <8 x i1> %55)
  %.state278 = load i64, ptr %.slot37, align 4
  %1440 = add i64 %.state278, 1
  store i64 %1440, ptr %.slot37, align 4
  br label %direct.schedule.24

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true68:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false69:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true106:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false107:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true137:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false138:                                  ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true178:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false179:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true197:                                   ; preds = %direct.schedule.15
  br label %direct.schedule.16

direct.false198:                                  ; preds = %direct.schedule.15
  br label %direct.schedule.20

direct.true200:                                   ; preds = %direct.schedule.17
  br label %direct.schedule.18

direct.false201:                                  ; preds = %direct.schedule.17
  br label %direct.schedule.19

direct.true230:                                   ; preds = %direct.schedule.21
  br label %direct.schedule.22

direct.false231:                                  ; preds = %direct.schedule.21
  br label %direct.schedule.23

direct.true249:                                   ; preds = %direct.schedule.24
  br label %direct.schedule.25

direct.false250:                                  ; preds = %direct.schedule.24
  br label %direct.schedule.19
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.sqrt.f32(float) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), i32 immarg, <8 x i1>) #2

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %tile_snapshot.local = alloca [3072 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [3072 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local4 = alloca [3072 x i8], align 4
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local7 = alloca [3072 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill10 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill10, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill11 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill11, align 4
  %.spill12 = alloca i64, align 8
  store i64 0, ptr %.spill12, align 4
  %.slot13 = alloca i64, align 8
  store i64 0, ptr %.slot13, align 4
  %.slot14 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot14, align 32
  %.slot15 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot15, align 32
  %.slot16 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot16, align 32
  %.slot17 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot17, align 32
  %.spill18 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill18, align 32
  %.spill19 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill19, align 32
  %.spill20 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill20, align 32
  %.spill21 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill21, align 4
  %.spill22 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill22, align 4
  %tile_snapshot.spill23 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill23, align 64
  %.slot24 = alloca i64, align 8
  store i64 0, ptr %.slot24, align 4
  %.slot25 = alloca i64, align 8
  store i64 0, ptr %.slot25, align 4
  %.slot26 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot26, align 32
  %.slot27 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot27, align 32
  %.slot28 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot28, align 32
  %.slot29 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot29, align 32
  %.spill30 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill30, align 4
  %tile_snapshot.spill31 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill31, align 64
  %.slot32 = alloca i64, align 8
  store i64 0, ptr %.slot32, align 4
  %.spill33 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill33, align 4
  %.slot34 = alloca i64, align 8
  store i64 0, ptr %.slot34, align 4
  %tile_snapshot.spill35 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill35, align 64
  %.slot36 = alloca i64, align 8
  store i64 0, ptr %.slot36, align 4
  %.slot37 = alloca i64, align 8
  store i64 0, ptr %.slot37, align 4
  %8 = getelementptr i8, ptr %argument_buffer, i64 0
  %9 = load ptr, ptr %8, align 16
  %10 = getelementptr i8, ptr %8, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = insertvalue { ptr, i64 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %11, 1
  %14 = getelementptr i8, ptr %argument_buffer, i64 16
  %15 = load ptr, ptr %14, align 16
  %16 = getelementptr i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = insertvalue { ptr, i64 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i64 } %18, i64 %17, 1
  %20 = getelementptr i8, ptr %argument_buffer, i64 32
  %21 = load ptr, ptr %20, align 16
  %22 = getelementptr i8, ptr %20, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = insertvalue { ptr, i64 } poison, ptr %21, 0
  %25 = insertvalue { ptr, i64 } %24, i64 %23, 1
  %26 = getelementptr i8, ptr %argument_buffer, i64 48
  %27 = load ptr, ptr %26, align 16
  %28 = getelementptr i8, ptr %26, i64 8
  %29 = load i64, ptr %28, align 8
  %30 = insertvalue { ptr, i64 } poison, ptr %27, 0
  %31 = insertvalue { ptr, i64 } %30, i64 %29, 1
  %32 = load i32, ptr %launch_config, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 12
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 4
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 16
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 8
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 20
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 36
  %44 = load i32, ptr %43, align 4
  %.splatinsert38 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat39 = shufflevector <8 x i32> %.splatinsert38, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat39, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %46 = mul i32 %32, 32
  %.splatinsert40 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat41 = shufflevector <8 x i32> %.splatinsert40, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat41, %45
  %48 = mul i32 %36, 1
  %.splatinsert42 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat43 = shufflevector <8 x i32> %.splatinsert42, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat43, zeroinitializer
  %50 = mul i32 %40, 1
  %.splatinsert44 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat45 = shufflevector <8 x i32> %.splatinsert44, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat45, zeroinitializer
  %52 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %47, 0
  %53 = insertvalue [3 x <8 x i32>] %52, <8 x i32> %49, 1
  %54 = insertvalue [3 x <8 x i32>] %53, <8 x i32> %51, 2
  %.splatinsert46 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat47 = shufflevector <8 x i32> %.splatinsert46, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat47
  %56 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  br i1 %56, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %57 = extractvalue [3 x <8 x i32>] %54, 0
  %58 = load <8 x i64>, ptr %.spill, align 64
  %59 = select <8 x i1> %55, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %58
  store <8 x i64> %59, ptr %.spill, align 64
  %60 = sub <8 x i32> %57, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %61 = select <8 x i1> %55, <8 x i32> %60, <8 x i32> zeroinitializer
  %62 = select <8 x i1> %55, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %63 = lshr <8 x i32> %61, %62
  %64 = zext <8 x i32> %63 to <8 x i64>
  %65 = select <8 x i1> %55, <8 x i64> %64, <8 x i64> zeroinitializer
  %66 = select <8 x i1> %55, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %67 = sdiv <8 x i64> %65, %66
  %68 = load <8 x i64>, ptr %.spill10, align 64
  %69 = select <8 x i1> %55, <8 x i64> %67, <8 x i64> %68
  store <8 x i64> %69, ptr %.spill10, align 64
  %70 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %71 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %72 = extractvalue { <8 x ptr>, <8 x i64> } %70, 0
  %73 = select <8 x i1> %55, <8 x ptr> %71, <8 x ptr> %72
  %74 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %75 = extractvalue { <8 x ptr>, <8 x i64> } %70, 1
  %76 = select <8 x i1> %55, <8 x i64> %74, <8 x i64> %75
  %77 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %73, 0
  %78 = insertvalue { <8 x ptr>, <8 x i64> } %77, <8 x i64> %76, 1
  store { <8 x ptr>, <8 x i64> } %78, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %79 = icmp slt i64 %.state, 96
  br i1 %79, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state48 = load i64, ptr %.slot, align 4
  %80 = mul i64 %.state48, 8
  %.splatinsert49 = insertelement <8 x i64> poison, i64 %80, i64 0
  %.splat50 = shufflevector <8 x i64> %.splatinsert49, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %81 = add <8 x i64> %.splat50, %.spill.load
  %.spill.load51 = load <8 x i64>, ptr %.spill10, align 64
  %82 = add <8 x i64> %.spill.load51, zeroinitializer
  %83 = add <8 x i64> zeroinitializer, %82
  %84 = add <8 x i64> zeroinitializer, %81
  %85 = mul <8 x i64> %83, splat (i64 768)
  %86 = add <8 x i64> %85, %84
  %87 = extractvalue { ptr, i64 } %13, 0
  %88 = extractelement <8 x i64> %86, i32 0
  %89 = sub i64 %88, 0
  %90 = mul i64 %89, 4
  %buffer.contiguous.address = getelementptr i8, ptr %87, i64 %90
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %91 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %92 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state52 = load i64, ptr %.slot, align 4
  %.splatinsert53 = insertelement <8 x i64> poison, i64 %.state52, i64 0
  %.splat54 = shufflevector <8 x i64> %.splatinsert53, <8 x i64> poison, <8 x i32> zeroinitializer
  %93 = mul <8 x i64> %.splat54, splat (i64 32)
  %94 = add <8 x i64> %92, %93
  %95 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %91, 0
  %96 = insertvalue { <8 x ptr>, <8 x i64> } %95, <8 x i64> %94, 1
  %97 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %96, 1
  %99 = extractelement <8 x ptr> %97, i32 0
  %100 = extractelement <8 x i64> %98, i32 0
  %101 = sub i64 %100, 0
  %102 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %103 = select i1 %102, i64 %101, i64 0
  %private.contiguous.address = getelementptr i8, ptr %99, i64 %103
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %104 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %104, ptr %private.contiguous.address, align 4
  %.state55 = load i64, ptr %.slot, align 4
  %105 = add i64 %.state55, 1
  store i64 %105, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store float 0.000000e+00, ptr %.spill11, align 4
  store i64 0, ptr %.spill12, align 4
  %tile_snapshot.spill.load56 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %106 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load56, 0
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load56, 1
  %108 = add <8 x i64> %107, zeroinitializer
  %109 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %106, 0
  %110 = insertvalue { <8 x ptr>, <8 x i64> } %109, <8 x i64> %108, 1
  %111 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %112 = extractvalue { <8 x ptr>, <8 x i64> } %110, 1
  %113 = extractelement <8 x ptr> %111, i32 0
  %114 = extractelement <8 x i64> %112, i32 0
  %115 = sub i64 %114, 0
  %116 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %117 = select i1 %116, i64 %115, i64 0
  %private.contiguous.address57 = getelementptr i8, ptr %113, i64 %117
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address57, align 4
  %118 = select <8 x i1> %55, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load58 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %119 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load58, 0
  %120 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load58, 1
  %121 = add <8 x i64> %120, splat (i64 32)
  %122 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %119, 0
  %123 = insertvalue { <8 x ptr>, <8 x i64> } %122, <8 x i64> %121, 1
  %124 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %123, 1
  %126 = extractelement <8 x ptr> %124, i32 0
  %127 = extractelement <8 x i64> %125, i32 0
  %128 = sub i64 %127, 0
  %129 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %130 = select i1 %129, i64 %128, i64 0
  %private.contiguous.address59 = getelementptr i8, ptr %126, i64 %130
  %private.contiguous.load60 = load <8 x float>, ptr %private.contiguous.address59, align 4
  %131 = select <8 x i1> %55, <8 x float> %private.contiguous.load60, <8 x float> zeroinitializer
  %tile_snapshot.spill.load61 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %132 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load61, 0
  %133 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load61, 1
  %134 = add <8 x i64> %133, splat (i64 64)
  %135 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %132, 0
  %136 = insertvalue { <8 x ptr>, <8 x i64> } %135, <8 x i64> %134, 1
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %138 = extractvalue { <8 x ptr>, <8 x i64> } %136, 1
  %139 = extractelement <8 x ptr> %137, i32 0
  %140 = extractelement <8 x i64> %138, i32 0
  %141 = sub i64 %140, 0
  %142 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %143 = select i1 %142, i64 %141, i64 0
  %private.contiguous.address62 = getelementptr i8, ptr %139, i64 %143
  %private.contiguous.load63 = load <8 x float>, ptr %private.contiguous.address62, align 4
  %144 = select <8 x i1> %55, <8 x float> %private.contiguous.load63, <8 x float> zeroinitializer
  %tile_snapshot.spill.load64 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %145 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 0
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 1
  %147 = add <8 x i64> %146, splat (i64 96)
  %148 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %145, 0
  %149 = insertvalue { <8 x ptr>, <8 x i64> } %148, <8 x i64> %147, 1
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %151 = extractvalue { <8 x ptr>, <8 x i64> } %149, 1
  %152 = extractelement <8 x ptr> %150, i32 0
  %153 = extractelement <8 x i64> %151, i32 0
  %154 = sub i64 %153, 0
  %155 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %156 = select i1 %155, i64 %154, i64 0
  %private.contiguous.address65 = getelementptr i8, ptr %152, i64 %156
  %private.contiguous.load66 = load <8 x float>, ptr %private.contiguous.address65, align 4
  %157 = select <8 x i1> %55, <8 x float> %private.contiguous.load66, <8 x float> zeroinitializer
  store i64 4, ptr %.slot13, align 4
  %158 = load <8 x float>, ptr %.slot14, align 32
  %159 = select <8 x i1> %55, <8 x float> %118, <8 x float> %158
  store <8 x float> %159, ptr %.slot14, align 32
  %160 = load <8 x float>, ptr %.slot15, align 32
  %161 = select <8 x i1> %55, <8 x float> %131, <8 x float> %160
  store <8 x float> %161, ptr %.slot15, align 32
  %162 = load <8 x float>, ptr %.slot16, align 32
  %163 = select <8 x i1> %55, <8 x float> %144, <8 x float> %162
  store <8 x float> %163, ptr %.slot16, align 32
  %164 = load <8 x float>, ptr %.slot17, align 32
  %165 = select <8 x i1> %55, <8 x float> %157, <8 x float> %164
  store <8 x float> %165, ptr %.slot17, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state67 = load i64, ptr %.slot13, align 4
  %166 = icmp slt i64 %.state67, 96
  br i1 %166, label %direct.true68, label %direct.false69

direct.schedule.5:                                ; preds = %direct.true68
  %.state70 = load i64, ptr %.slot13, align 4
  %167 = add i64 %.state70, 0
  %tile_snapshot.spill.load71 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %168 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load71, 0
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load71, 1
  %.splatinsert72 = insertelement <8 x i64> poison, i64 %167, i64 0
  %.splat73 = shufflevector <8 x i64> %.splatinsert72, <8 x i64> poison, <8 x i32> zeroinitializer
  %170 = mul <8 x i64> %.splat73, splat (i64 32)
  %171 = add <8 x i64> %169, %170
  %172 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %168, 0
  %173 = insertvalue { <8 x ptr>, <8 x i64> } %172, <8 x i64> %171, 1
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %173, 1
  %176 = extractelement <8 x ptr> %174, i32 0
  %177 = extractelement <8 x i64> %175, i32 0
  %178 = sub i64 %177, 0
  %179 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %180 = select i1 %179, i64 %178, i64 0
  %private.contiguous.address74 = getelementptr i8, ptr %176, i64 %180
  %private.contiguous.load75 = load <8 x float>, ptr %private.contiguous.address74, align 4
  %181 = select <8 x i1> %55, <8 x float> %private.contiguous.load75, <8 x float> zeroinitializer
  %.state76 = load <8 x float>, ptr %.slot14, align 32
  %182 = fadd <8 x float> %.state76, %181
  %.state77 = load i64, ptr %.slot13, align 4
  %183 = add i64 %.state77, 1
  %tile_snapshot.spill.load78 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %184 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load78, 0
  %185 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load78, 1
  %.splatinsert79 = insertelement <8 x i64> poison, i64 %183, i64 0
  %.splat80 = shufflevector <8 x i64> %.splatinsert79, <8 x i64> poison, <8 x i32> zeroinitializer
  %186 = mul <8 x i64> %.splat80, splat (i64 32)
  %187 = add <8 x i64> %185, %186
  %188 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %184, 0
  %189 = insertvalue { <8 x ptr>, <8 x i64> } %188, <8 x i64> %187, 1
  %190 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %191 = extractvalue { <8 x ptr>, <8 x i64> } %189, 1
  %192 = extractelement <8 x ptr> %190, i32 0
  %193 = extractelement <8 x i64> %191, i32 0
  %194 = sub i64 %193, 0
  %195 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %196 = select i1 %195, i64 %194, i64 0
  %private.contiguous.address81 = getelementptr i8, ptr %192, i64 %196
  %private.contiguous.load82 = load <8 x float>, ptr %private.contiguous.address81, align 4
  %197 = select <8 x i1> %55, <8 x float> %private.contiguous.load82, <8 x float> zeroinitializer
  %.state83 = load <8 x float>, ptr %.slot15, align 32
  %198 = fadd <8 x float> %.state83, %197
  %.state84 = load i64, ptr %.slot13, align 4
  %199 = add i64 %.state84, 2
  %tile_snapshot.spill.load85 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %200 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load85, 0
  %201 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load85, 1
  %.splatinsert86 = insertelement <8 x i64> poison, i64 %199, i64 0
  %.splat87 = shufflevector <8 x i64> %.splatinsert86, <8 x i64> poison, <8 x i32> zeroinitializer
  %202 = mul <8 x i64> %.splat87, splat (i64 32)
  %203 = add <8 x i64> %201, %202
  %204 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %200, 0
  %205 = insertvalue { <8 x ptr>, <8 x i64> } %204, <8 x i64> %203, 1
  %206 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %207 = extractvalue { <8 x ptr>, <8 x i64> } %205, 1
  %208 = extractelement <8 x ptr> %206, i32 0
  %209 = extractelement <8 x i64> %207, i32 0
  %210 = sub i64 %209, 0
  %211 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %212 = select i1 %211, i64 %210, i64 0
  %private.contiguous.address88 = getelementptr i8, ptr %208, i64 %212
  %private.contiguous.load89 = load <8 x float>, ptr %private.contiguous.address88, align 4
  %213 = select <8 x i1> %55, <8 x float> %private.contiguous.load89, <8 x float> zeroinitializer
  %.state90 = load <8 x float>, ptr %.slot16, align 32
  %214 = fadd <8 x float> %.state90, %213
  %.state91 = load i64, ptr %.slot13, align 4
  %215 = add i64 %.state91, 3
  %tile_snapshot.spill.load92 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load92, 0
  %217 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load92, 1
  %.splatinsert93 = insertelement <8 x i64> poison, i64 %215, i64 0
  %.splat94 = shufflevector <8 x i64> %.splatinsert93, <8 x i64> poison, <8 x i32> zeroinitializer
  %218 = mul <8 x i64> %.splat94, splat (i64 32)
  %219 = add <8 x i64> %217, %218
  %220 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %216, 0
  %221 = insertvalue { <8 x ptr>, <8 x i64> } %220, <8 x i64> %219, 1
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %221, 1
  %224 = extractelement <8 x ptr> %222, i32 0
  %225 = extractelement <8 x i64> %223, i32 0
  %226 = sub i64 %225, 0
  %227 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %228 = select i1 %227, i64 %226, i64 0
  %private.contiguous.address95 = getelementptr i8, ptr %224, i64 %228
  %private.contiguous.load96 = load <8 x float>, ptr %private.contiguous.address95, align 4
  %229 = select <8 x i1> %55, <8 x float> %private.contiguous.load96, <8 x float> zeroinitializer
  %.state97 = load <8 x float>, ptr %.slot17, align 32
  %230 = fadd <8 x float> %.state97, %229
  %.state98 = load i64, ptr %.slot13, align 4
  %231 = add i64 %.state98, 4
  store i64 %231, ptr %.slot13, align 4
  %232 = load <8 x float>, ptr %.slot14, align 32
  %233 = select <8 x i1> %55, <8 x float> %182, <8 x float> %232
  store <8 x float> %233, ptr %.slot14, align 32
  %234 = load <8 x float>, ptr %.slot15, align 32
  %235 = select <8 x i1> %55, <8 x float> %198, <8 x float> %234
  store <8 x float> %235, ptr %.slot15, align 32
  %236 = load <8 x float>, ptr %.slot16, align 32
  %237 = select <8 x i1> %55, <8 x float> %214, <8 x float> %236
  store <8 x float> %237, ptr %.slot16, align 32
  %238 = load <8 x float>, ptr %.slot17, align 32
  %239 = select <8 x i1> %55, <8 x float> %230, <8 x float> %238
  store <8 x float> %239, ptr %.slot17, align 32
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false69
  %.state99 = load <8 x float>, ptr %.slot14, align 32
  %.state100 = load <8 x float>, ptr %.slot15, align 32
  %240 = fadd <8 x float> %.state99, %.state100
  %.state101 = load <8 x float>, ptr %.slot16, align 32
  %241 = fadd <8 x float> %240, %.state101
  %.state102 = load <8 x float>, ptr %.slot17, align 32
  %242 = fadd <8 x float> %241, %.state102
  %.spill.load103 = load <8 x i64>, ptr %.spill, align 64
  %243 = trunc <8 x i64> %.spill.load103 to <8 x i32>
  %244 = xor <8 x i32> %243, splat (i32 1)
  %245 = load <8 x i32>, ptr %.spill18, align 32
  %246 = select <8 x i1> %55, <8 x i32> %244, <8 x i32> %245
  store <8 x i32> %246, ptr %.spill18, align 32
  %247 = extractelement <8 x i32> %244, i64 0
  %248 = icmp ult i32 %247, 8
  %249 = select i1 %248, i32 %247, i32 0
  %250 = extractelement <8 x i1> %55, i32 %249
  %251 = extractelement <8 x i1> %55, i64 0
  %252 = and i1 %248, %250
  %253 = and i1 %251, %252
  %254 = extractelement <8 x float> %242, i32 %249
  %255 = select i1 %253, float %254, float 0.000000e+00
  %256 = insertelement <8 x float> poison, float %255, i64 0
  %257 = xor i1 %253, true
  %258 = and i1 %251, %257
  %259 = insertelement <8 x i1> poison, i1 %258, i64 0
  %260 = extractelement <8 x i32> %244, i64 1
  %261 = icmp ult i32 %260, 8
  %262 = select i1 %261, i32 %260, i32 0
  %263 = extractelement <8 x i1> %55, i32 %262
  %264 = extractelement <8 x i1> %55, i64 1
  %265 = and i1 %261, %263
  %266 = and i1 %264, %265
  %267 = extractelement <8 x float> %242, i32 %262
  %268 = select i1 %266, float %267, float 0.000000e+00
  %269 = insertelement <8 x float> %256, float %268, i64 1
  %270 = xor i1 %266, true
  %271 = and i1 %264, %270
  %272 = insertelement <8 x i1> %259, i1 %271, i64 1
  %273 = extractelement <8 x i32> %244, i64 2
  %274 = icmp ult i32 %273, 8
  %275 = select i1 %274, i32 %273, i32 0
  %276 = extractelement <8 x i1> %55, i32 %275
  %277 = extractelement <8 x i1> %55, i64 2
  %278 = and i1 %274, %276
  %279 = and i1 %277, %278
  %280 = extractelement <8 x float> %242, i32 %275
  %281 = select i1 %279, float %280, float 0.000000e+00
  %282 = insertelement <8 x float> %269, float %281, i64 2
  %283 = xor i1 %279, true
  %284 = and i1 %277, %283
  %285 = insertelement <8 x i1> %272, i1 %284, i64 2
  %286 = extractelement <8 x i32> %244, i64 3
  %287 = icmp ult i32 %286, 8
  %288 = select i1 %287, i32 %286, i32 0
  %289 = extractelement <8 x i1> %55, i32 %288
  %290 = extractelement <8 x i1> %55, i64 3
  %291 = and i1 %287, %289
  %292 = and i1 %290, %291
  %293 = extractelement <8 x float> %242, i32 %288
  %294 = select i1 %292, float %293, float 0.000000e+00
  %295 = insertelement <8 x float> %282, float %294, i64 3
  %296 = xor i1 %292, true
  %297 = and i1 %290, %296
  %298 = insertelement <8 x i1> %285, i1 %297, i64 3
  %299 = extractelement <8 x i32> %244, i64 4
  %300 = icmp ult i32 %299, 8
  %301 = select i1 %300, i32 %299, i32 0
  %302 = extractelement <8 x i1> %55, i32 %301
  %303 = extractelement <8 x i1> %55, i64 4
  %304 = and i1 %300, %302
  %305 = and i1 %303, %304
  %306 = extractelement <8 x float> %242, i32 %301
  %307 = select i1 %305, float %306, float 0.000000e+00
  %308 = insertelement <8 x float> %295, float %307, i64 4
  %309 = xor i1 %305, true
  %310 = and i1 %303, %309
  %311 = insertelement <8 x i1> %298, i1 %310, i64 4
  %312 = extractelement <8 x i32> %244, i64 5
  %313 = icmp ult i32 %312, 8
  %314 = select i1 %313, i32 %312, i32 0
  %315 = extractelement <8 x i1> %55, i32 %314
  %316 = extractelement <8 x i1> %55, i64 5
  %317 = and i1 %313, %315
  %318 = and i1 %316, %317
  %319 = extractelement <8 x float> %242, i32 %314
  %320 = select i1 %318, float %319, float 0.000000e+00
  %321 = insertelement <8 x float> %308, float %320, i64 5
  %322 = xor i1 %318, true
  %323 = and i1 %316, %322
  %324 = insertelement <8 x i1> %311, i1 %323, i64 5
  %325 = extractelement <8 x i32> %244, i64 6
  %326 = icmp ult i32 %325, 8
  %327 = select i1 %326, i32 %325, i32 0
  %328 = extractelement <8 x i1> %55, i32 %327
  %329 = extractelement <8 x i1> %55, i64 6
  %330 = and i1 %326, %328
  %331 = and i1 %329, %330
  %332 = extractelement <8 x float> %242, i32 %327
  %333 = select i1 %331, float %332, float 0.000000e+00
  %334 = insertelement <8 x float> %321, float %333, i64 6
  %335 = xor i1 %331, true
  %336 = and i1 %329, %335
  %337 = insertelement <8 x i1> %324, i1 %336, i64 6
  %338 = extractelement <8 x i32> %244, i64 7
  %339 = icmp ult i32 %338, 8
  %340 = select i1 %339, i32 %338, i32 0
  %341 = extractelement <8 x i1> %55, i32 %340
  %342 = extractelement <8 x i1> %55, i64 7
  %343 = and i1 %339, %341
  %344 = and i1 %342, %343
  %345 = extractelement <8 x float> %242, i32 %340
  %346 = select i1 %344, float %345, float 0.000000e+00
  %347 = insertelement <8 x float> %334, float %346, i64 7
  %348 = xor i1 %344, true
  %349 = and i1 %342, %348
  %350 = insertelement <8 x i1> %337, i1 %349, i64 7
  %351 = fadd <8 x float> %242, %347
  %352 = xor <8 x i32> %243, splat (i32 2)
  %353 = load <8 x i32>, ptr %.spill19, align 32
  %354 = select <8 x i1> %55, <8 x i32> %352, <8 x i32> %353
  store <8 x i32> %354, ptr %.spill19, align 32
  %355 = extractelement <8 x i32> %352, i64 0
  %356 = icmp ult i32 %355, 8
  %357 = select i1 %356, i32 %355, i32 0
  %358 = extractelement <8 x i1> %55, i32 %357
  %359 = extractelement <8 x i1> %55, i64 0
  %360 = and i1 %356, %358
  %361 = and i1 %359, %360
  %362 = extractelement <8 x float> %351, i32 %357
  %363 = select i1 %361, float %362, float 0.000000e+00
  %364 = insertelement <8 x float> poison, float %363, i64 0
  %365 = xor i1 %361, true
  %366 = and i1 %359, %365
  %367 = insertelement <8 x i1> poison, i1 %366, i64 0
  %368 = extractelement <8 x i32> %352, i64 1
  %369 = icmp ult i32 %368, 8
  %370 = select i1 %369, i32 %368, i32 0
  %371 = extractelement <8 x i1> %55, i32 %370
  %372 = extractelement <8 x i1> %55, i64 1
  %373 = and i1 %369, %371
  %374 = and i1 %372, %373
  %375 = extractelement <8 x float> %351, i32 %370
  %376 = select i1 %374, float %375, float 0.000000e+00
  %377 = insertelement <8 x float> %364, float %376, i64 1
  %378 = xor i1 %374, true
  %379 = and i1 %372, %378
  %380 = insertelement <8 x i1> %367, i1 %379, i64 1
  %381 = extractelement <8 x i32> %352, i64 2
  %382 = icmp ult i32 %381, 8
  %383 = select i1 %382, i32 %381, i32 0
  %384 = extractelement <8 x i1> %55, i32 %383
  %385 = extractelement <8 x i1> %55, i64 2
  %386 = and i1 %382, %384
  %387 = and i1 %385, %386
  %388 = extractelement <8 x float> %351, i32 %383
  %389 = select i1 %387, float %388, float 0.000000e+00
  %390 = insertelement <8 x float> %377, float %389, i64 2
  %391 = xor i1 %387, true
  %392 = and i1 %385, %391
  %393 = insertelement <8 x i1> %380, i1 %392, i64 2
  %394 = extractelement <8 x i32> %352, i64 3
  %395 = icmp ult i32 %394, 8
  %396 = select i1 %395, i32 %394, i32 0
  %397 = extractelement <8 x i1> %55, i32 %396
  %398 = extractelement <8 x i1> %55, i64 3
  %399 = and i1 %395, %397
  %400 = and i1 %398, %399
  %401 = extractelement <8 x float> %351, i32 %396
  %402 = select i1 %400, float %401, float 0.000000e+00
  %403 = insertelement <8 x float> %390, float %402, i64 3
  %404 = xor i1 %400, true
  %405 = and i1 %398, %404
  %406 = insertelement <8 x i1> %393, i1 %405, i64 3
  %407 = extractelement <8 x i32> %352, i64 4
  %408 = icmp ult i32 %407, 8
  %409 = select i1 %408, i32 %407, i32 0
  %410 = extractelement <8 x i1> %55, i32 %409
  %411 = extractelement <8 x i1> %55, i64 4
  %412 = and i1 %408, %410
  %413 = and i1 %411, %412
  %414 = extractelement <8 x float> %351, i32 %409
  %415 = select i1 %413, float %414, float 0.000000e+00
  %416 = insertelement <8 x float> %403, float %415, i64 4
  %417 = xor i1 %413, true
  %418 = and i1 %411, %417
  %419 = insertelement <8 x i1> %406, i1 %418, i64 4
  %420 = extractelement <8 x i32> %352, i64 5
  %421 = icmp ult i32 %420, 8
  %422 = select i1 %421, i32 %420, i32 0
  %423 = extractelement <8 x i1> %55, i32 %422
  %424 = extractelement <8 x i1> %55, i64 5
  %425 = and i1 %421, %423
  %426 = and i1 %424, %425
  %427 = extractelement <8 x float> %351, i32 %422
  %428 = select i1 %426, float %427, float 0.000000e+00
  %429 = insertelement <8 x float> %416, float %428, i64 5
  %430 = xor i1 %426, true
  %431 = and i1 %424, %430
  %432 = insertelement <8 x i1> %419, i1 %431, i64 5
  %433 = extractelement <8 x i32> %352, i64 6
  %434 = icmp ult i32 %433, 8
  %435 = select i1 %434, i32 %433, i32 0
  %436 = extractelement <8 x i1> %55, i32 %435
  %437 = extractelement <8 x i1> %55, i64 6
  %438 = and i1 %434, %436
  %439 = and i1 %437, %438
  %440 = extractelement <8 x float> %351, i32 %435
  %441 = select i1 %439, float %440, float 0.000000e+00
  %442 = insertelement <8 x float> %429, float %441, i64 6
  %443 = xor i1 %439, true
  %444 = and i1 %437, %443
  %445 = insertelement <8 x i1> %432, i1 %444, i64 6
  %446 = extractelement <8 x i32> %352, i64 7
  %447 = icmp ult i32 %446, 8
  %448 = select i1 %447, i32 %446, i32 0
  %449 = extractelement <8 x i1> %55, i32 %448
  %450 = extractelement <8 x i1> %55, i64 7
  %451 = and i1 %447, %449
  %452 = and i1 %450, %451
  %453 = extractelement <8 x float> %351, i32 %448
  %454 = select i1 %452, float %453, float 0.000000e+00
  %455 = insertelement <8 x float> %442, float %454, i64 7
  %456 = xor i1 %452, true
  %457 = and i1 %450, %456
  %458 = insertelement <8 x i1> %445, i1 %457, i64 7
  %459 = fadd <8 x float> %351, %455
  %460 = xor <8 x i32> %243, splat (i32 4)
  %461 = load <8 x i32>, ptr %.spill20, align 32
  %462 = select <8 x i1> %55, <8 x i32> %460, <8 x i32> %461
  store <8 x i32> %462, ptr %.spill20, align 32
  %463 = extractelement <8 x i32> %460, i64 0
  %464 = icmp ult i32 %463, 8
  %465 = select i1 %464, i32 %463, i32 0
  %466 = extractelement <8 x i1> %55, i32 %465
  %467 = extractelement <8 x i1> %55, i64 0
  %468 = and i1 %464, %466
  %469 = and i1 %467, %468
  %470 = extractelement <8 x float> %459, i32 %465
  %471 = select i1 %469, float %470, float 0.000000e+00
  %472 = insertelement <8 x float> poison, float %471, i64 0
  %473 = xor i1 %469, true
  %474 = and i1 %467, %473
  %475 = insertelement <8 x i1> poison, i1 %474, i64 0
  %476 = extractelement <8 x i32> %460, i64 1
  %477 = icmp ult i32 %476, 8
  %478 = select i1 %477, i32 %476, i32 0
  %479 = extractelement <8 x i1> %55, i32 %478
  %480 = extractelement <8 x i1> %55, i64 1
  %481 = and i1 %477, %479
  %482 = and i1 %480, %481
  %483 = extractelement <8 x float> %459, i32 %478
  %484 = select i1 %482, float %483, float 0.000000e+00
  %485 = insertelement <8 x float> %472, float %484, i64 1
  %486 = xor i1 %482, true
  %487 = and i1 %480, %486
  %488 = insertelement <8 x i1> %475, i1 %487, i64 1
  %489 = extractelement <8 x i32> %460, i64 2
  %490 = icmp ult i32 %489, 8
  %491 = select i1 %490, i32 %489, i32 0
  %492 = extractelement <8 x i1> %55, i32 %491
  %493 = extractelement <8 x i1> %55, i64 2
  %494 = and i1 %490, %492
  %495 = and i1 %493, %494
  %496 = extractelement <8 x float> %459, i32 %491
  %497 = select i1 %495, float %496, float 0.000000e+00
  %498 = insertelement <8 x float> %485, float %497, i64 2
  %499 = xor i1 %495, true
  %500 = and i1 %493, %499
  %501 = insertelement <8 x i1> %488, i1 %500, i64 2
  %502 = extractelement <8 x i32> %460, i64 3
  %503 = icmp ult i32 %502, 8
  %504 = select i1 %503, i32 %502, i32 0
  %505 = extractelement <8 x i1> %55, i32 %504
  %506 = extractelement <8 x i1> %55, i64 3
  %507 = and i1 %503, %505
  %508 = and i1 %506, %507
  %509 = extractelement <8 x float> %459, i32 %504
  %510 = select i1 %508, float %509, float 0.000000e+00
  %511 = insertelement <8 x float> %498, float %510, i64 3
  %512 = xor i1 %508, true
  %513 = and i1 %506, %512
  %514 = insertelement <8 x i1> %501, i1 %513, i64 3
  %515 = extractelement <8 x i32> %460, i64 4
  %516 = icmp ult i32 %515, 8
  %517 = select i1 %516, i32 %515, i32 0
  %518 = extractelement <8 x i1> %55, i32 %517
  %519 = extractelement <8 x i1> %55, i64 4
  %520 = and i1 %516, %518
  %521 = and i1 %519, %520
  %522 = extractelement <8 x float> %459, i32 %517
  %523 = select i1 %521, float %522, float 0.000000e+00
  %524 = insertelement <8 x float> %511, float %523, i64 4
  %525 = xor i1 %521, true
  %526 = and i1 %519, %525
  %527 = insertelement <8 x i1> %514, i1 %526, i64 4
  %528 = extractelement <8 x i32> %460, i64 5
  %529 = icmp ult i32 %528, 8
  %530 = select i1 %529, i32 %528, i32 0
  %531 = extractelement <8 x i1> %55, i32 %530
  %532 = extractelement <8 x i1> %55, i64 5
  %533 = and i1 %529, %531
  %534 = and i1 %532, %533
  %535 = extractelement <8 x float> %459, i32 %530
  %536 = select i1 %534, float %535, float 0.000000e+00
  %537 = insertelement <8 x float> %524, float %536, i64 5
  %538 = xor i1 %534, true
  %539 = and i1 %532, %538
  %540 = insertelement <8 x i1> %527, i1 %539, i64 5
  %541 = extractelement <8 x i32> %460, i64 6
  %542 = icmp ult i32 %541, 8
  %543 = select i1 %542, i32 %541, i32 0
  %544 = extractelement <8 x i1> %55, i32 %543
  %545 = extractelement <8 x i1> %55, i64 6
  %546 = and i1 %542, %544
  %547 = and i1 %545, %546
  %548 = extractelement <8 x float> %459, i32 %543
  %549 = select i1 %547, float %548, float 0.000000e+00
  %550 = insertelement <8 x float> %537, float %549, i64 6
  %551 = xor i1 %547, true
  %552 = and i1 %545, %551
  %553 = insertelement <8 x i1> %540, i1 %552, i64 6
  %554 = extractelement <8 x i32> %460, i64 7
  %555 = icmp ult i32 %554, 8
  %556 = select i1 %555, i32 %554, i32 0
  %557 = extractelement <8 x i1> %55, i32 %556
  %558 = extractelement <8 x i1> %55, i64 7
  %559 = and i1 %555, %557
  %560 = and i1 %558, %559
  %561 = extractelement <8 x float> %459, i32 %556
  %562 = select i1 %560, float %561, float 0.000000e+00
  %563 = insertelement <8 x float> %550, float %562, i64 7
  %564 = xor i1 %560, true
  %565 = and i1 %558, %564
  %566 = insertelement <8 x i1> %553, i1 %565, i64 7
  %567 = fadd <8 x float> %459, %563
  %568 = extractelement <8 x i1> %55, i32 0
  %569 = extractelement <8 x i1> %55, i64 0
  %570 = and i1 true, %568
  %571 = and i1 %569, %570
  %572 = extractelement <8 x float> %567, i32 0
  %573 = select i1 %571, float %572, float 0.000000e+00
  %574 = insertelement <8 x float> poison, float %573, i64 0
  %575 = xor i1 %571, true
  %576 = and i1 %569, %575
  %577 = insertelement <8 x i1> poison, i1 %576, i64 0
  %578 = extractelement <8 x i1> %55, i32 0
  %579 = extractelement <8 x i1> %55, i64 1
  %580 = and i1 true, %578
  %581 = and i1 %579, %580
  %582 = extractelement <8 x float> %567, i32 0
  %583 = select i1 %581, float %582, float 0.000000e+00
  %584 = insertelement <8 x float> %574, float %583, i64 1
  %585 = xor i1 %581, true
  %586 = and i1 %579, %585
  %587 = insertelement <8 x i1> %577, i1 %586, i64 1
  %588 = extractelement <8 x i1> %55, i32 0
  %589 = extractelement <8 x i1> %55, i64 2
  %590 = and i1 true, %588
  %591 = and i1 %589, %590
  %592 = extractelement <8 x float> %567, i32 0
  %593 = select i1 %591, float %592, float 0.000000e+00
  %594 = insertelement <8 x float> %584, float %593, i64 2
  %595 = xor i1 %591, true
  %596 = and i1 %589, %595
  %597 = insertelement <8 x i1> %587, i1 %596, i64 2
  %598 = extractelement <8 x i1> %55, i32 0
  %599 = extractelement <8 x i1> %55, i64 3
  %600 = and i1 true, %598
  %601 = and i1 %599, %600
  %602 = extractelement <8 x float> %567, i32 0
  %603 = select i1 %601, float %602, float 0.000000e+00
  %604 = insertelement <8 x float> %594, float %603, i64 3
  %605 = xor i1 %601, true
  %606 = and i1 %599, %605
  %607 = insertelement <8 x i1> %597, i1 %606, i64 3
  %608 = extractelement <8 x i1> %55, i32 0
  %609 = extractelement <8 x i1> %55, i64 4
  %610 = and i1 true, %608
  %611 = and i1 %609, %610
  %612 = extractelement <8 x float> %567, i32 0
  %613 = select i1 %611, float %612, float 0.000000e+00
  %614 = insertelement <8 x float> %604, float %613, i64 4
  %615 = xor i1 %611, true
  %616 = and i1 %609, %615
  %617 = insertelement <8 x i1> %607, i1 %616, i64 4
  %618 = extractelement <8 x i1> %55, i32 0
  %619 = extractelement <8 x i1> %55, i64 5
  %620 = and i1 true, %618
  %621 = and i1 %619, %620
  %622 = extractelement <8 x float> %567, i32 0
  %623 = select i1 %621, float %622, float 0.000000e+00
  %624 = insertelement <8 x float> %614, float %623, i64 5
  %625 = xor i1 %621, true
  %626 = and i1 %619, %625
  %627 = insertelement <8 x i1> %617, i1 %626, i64 5
  %628 = extractelement <8 x i1> %55, i32 0
  %629 = extractelement <8 x i1> %55, i64 6
  %630 = and i1 true, %628
  %631 = and i1 %629, %630
  %632 = extractelement <8 x float> %567, i32 0
  %633 = select i1 %631, float %632, float 0.000000e+00
  %634 = insertelement <8 x float> %624, float %633, i64 6
  %635 = xor i1 %631, true
  %636 = and i1 %629, %635
  %637 = insertelement <8 x i1> %627, i1 %636, i64 6
  %638 = extractelement <8 x i1> %55, i32 0
  %639 = extractelement <8 x i1> %55, i64 7
  %640 = and i1 true, %638
  %641 = and i1 %639, %640
  %642 = extractelement <8 x float> %567, i32 0
  %643 = select i1 %641, float %642, float 0.000000e+00
  %644 = insertelement <8 x float> %634, float %643, i64 7
  %645 = xor i1 %641, true
  %646 = and i1 %639, %645
  %647 = insertelement <8 x i1> %637, i1 %646, i64 7
  %648 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %649 = bitcast <8 x i1> %55 to i8
  %650 = call i8 @llvm.cttz.i8(i8 %649, i1 false)
  %651 = zext i8 %650 to i32
  %652 = select i1 %648, i32 %651, i32 0
  %653 = extractelement <8 x float> %644, i32 %652
  %.spill.load104 = load float, ptr %.spill11, align 4
  %654 = fadd float %.spill.load104, %653
  store float 7.680000e+02, ptr %.spill21, align 4
  %655 = fdiv float %654, 7.680000e+02
  store float %655, ptr %.spill22, align 4
  %656 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %657 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %658 = extractvalue { <8 x ptr>, <8 x i64> } %656, 0
  %659 = select <8 x i1> %55, <8 x ptr> %657, <8 x ptr> %658
  %660 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %661 = extractvalue { <8 x ptr>, <8 x i64> } %656, 1
  %662 = select <8 x i1> %55, <8 x i64> %660, <8 x i64> %661
  %663 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %659, 0
  %664 = insertvalue { <8 x ptr>, <8 x i64> } %663, <8 x i64> %662, 1
  store { <8 x ptr>, <8 x i64> } %664, ptr %tile_snapshot.spill23, align 64
  store i64 0, ptr %.slot24, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state105 = load i64, ptr %.slot24, align 4
  %665 = icmp slt i64 %.state105, 96
  br i1 %665, label %direct.true106, label %direct.false107

direct.schedule.8:                                ; preds = %direct.true106
  %tile_snapshot.spill.load108 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %666 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load108, 0
  %667 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load108, 1
  %.state109 = load i64, ptr %.slot24, align 4
  %.splatinsert110 = insertelement <8 x i64> poison, i64 %.state109, i64 0
  %.splat111 = shufflevector <8 x i64> %.splatinsert110, <8 x i64> poison, <8 x i32> zeroinitializer
  %668 = mul <8 x i64> %.splat111, splat (i64 32)
  %669 = add <8 x i64> %667, %668
  %670 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %666, 0
  %671 = insertvalue { <8 x ptr>, <8 x i64> } %670, <8 x i64> %669, 1
  %672 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %673 = extractvalue { <8 x ptr>, <8 x i64> } %671, 1
  %674 = extractelement <8 x ptr> %672, i32 0
  %675 = extractelement <8 x i64> %673, i32 0
  %676 = sub i64 %675, 0
  %677 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %678 = select i1 %677, i64 %676, i64 0
  %private.contiguous.address112 = getelementptr i8, ptr %674, i64 %678
  %private.contiguous.load113 = load <8 x float>, ptr %private.contiguous.address112, align 4
  %679 = select <8 x i1> %55, <8 x float> %private.contiguous.load113, <8 x float> zeroinitializer
  %.spill.load114 = load float, ptr %.spill22, align 4
  %.splatinsert115 = insertelement <8 x float> poison, float %.spill.load114, i64 0
  %.splat116 = shufflevector <8 x float> %.splatinsert115, <8 x float> poison, <8 x i32> zeroinitializer
  %680 = fsub <8 x float> %679, %.splat116
  %tile_snapshot.spill.load117 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %681 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load117, 0
  %682 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load117, 1
  %.state118 = load i64, ptr %.slot24, align 4
  %.splatinsert119 = insertelement <8 x i64> poison, i64 %.state118, i64 0
  %.splat120 = shufflevector <8 x i64> %.splatinsert119, <8 x i64> poison, <8 x i32> zeroinitializer
  %683 = mul <8 x i64> %.splat120, splat (i64 32)
  %684 = add <8 x i64> %682, %683
  %685 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %681, 0
  %686 = insertvalue { <8 x ptr>, <8 x i64> } %685, <8 x i64> %684, 1
  %687 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %688 = extractvalue { <8 x ptr>, <8 x i64> } %686, 1
  %689 = extractelement <8 x ptr> %687, i32 0
  %690 = extractelement <8 x i64> %688, i32 0
  %691 = sub i64 %690, 0
  %692 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %693 = select i1 %692, i64 %691, i64 0
  %private.contiguous.address121 = getelementptr i8, ptr %689, i64 %693
  %private.contiguous.preserve122 = load <8 x float>, ptr %private.contiguous.address121, align 4
  %694 = select <8 x i1> %55, <8 x float> %680, <8 x float> %private.contiguous.preserve122
  store <8 x float> %694, ptr %private.contiguous.address121, align 4
  %.state123 = load i64, ptr %.slot24, align 4
  %695 = add i64 %.state123, 1
  store i64 %695, ptr %.slot24, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false107
  %tile_snapshot.spill.load124 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %696 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load124, 0
  %697 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load124, 1
  %698 = add <8 x i64> %697, zeroinitializer
  %699 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %696, 0
  %700 = insertvalue { <8 x ptr>, <8 x i64> } %699, <8 x i64> %698, 1
  %701 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %702 = extractvalue { <8 x ptr>, <8 x i64> } %700, 1
  %703 = extractelement <8 x ptr> %701, i32 0
  %704 = extractelement <8 x i64> %702, i32 0
  %705 = sub i64 %704, 0
  %706 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %707 = select i1 %706, i64 %705, i64 0
  %private.contiguous.address125 = getelementptr i8, ptr %703, i64 %707
  %private.contiguous.load126 = load <8 x float>, ptr %private.contiguous.address125, align 4
  %708 = select <8 x i1> %55, <8 x float> %private.contiguous.load126, <8 x float> zeroinitializer
  %709 = fmul <8 x float> %708, %708
  %tile_snapshot.spill.load127 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %710 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load127, 0
  %711 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load127, 1
  %712 = add <8 x i64> %711, splat (i64 32)
  %713 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %710, 0
  %714 = insertvalue { <8 x ptr>, <8 x i64> } %713, <8 x i64> %712, 1
  %715 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %716 = extractvalue { <8 x ptr>, <8 x i64> } %714, 1
  %717 = extractelement <8 x ptr> %715, i32 0
  %718 = extractelement <8 x i64> %716, i32 0
  %719 = sub i64 %718, 0
  %720 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %721 = select i1 %720, i64 %719, i64 0
  %private.contiguous.address128 = getelementptr i8, ptr %717, i64 %721
  %private.contiguous.load129 = load <8 x float>, ptr %private.contiguous.address128, align 4
  %722 = select <8 x i1> %55, <8 x float> %private.contiguous.load129, <8 x float> zeroinitializer
  %723 = fmul <8 x float> %722, %722
  %tile_snapshot.spill.load130 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %724 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load130, 0
  %725 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load130, 1
  %726 = add <8 x i64> %725, splat (i64 64)
  %727 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %724, 0
  %728 = insertvalue { <8 x ptr>, <8 x i64> } %727, <8 x i64> %726, 1
  %729 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %730 = extractvalue { <8 x ptr>, <8 x i64> } %728, 1
  %731 = extractelement <8 x ptr> %729, i32 0
  %732 = extractelement <8 x i64> %730, i32 0
  %733 = sub i64 %732, 0
  %734 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %735 = select i1 %734, i64 %733, i64 0
  %private.contiguous.address131 = getelementptr i8, ptr %731, i64 %735
  %private.contiguous.load132 = load <8 x float>, ptr %private.contiguous.address131, align 4
  %736 = select <8 x i1> %55, <8 x float> %private.contiguous.load132, <8 x float> zeroinitializer
  %737 = fmul <8 x float> %736, %736
  %tile_snapshot.spill.load133 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %738 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load133, 0
  %739 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load133, 1
  %740 = add <8 x i64> %739, splat (i64 96)
  %741 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %738, 0
  %742 = insertvalue { <8 x ptr>, <8 x i64> } %741, <8 x i64> %740, 1
  %743 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %744 = extractvalue { <8 x ptr>, <8 x i64> } %742, 1
  %745 = extractelement <8 x ptr> %743, i32 0
  %746 = extractelement <8 x i64> %744, i32 0
  %747 = sub i64 %746, 0
  %748 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %749 = select i1 %748, i64 %747, i64 0
  %private.contiguous.address134 = getelementptr i8, ptr %745, i64 %749
  %private.contiguous.load135 = load <8 x float>, ptr %private.contiguous.address134, align 4
  %750 = select <8 x i1> %55, <8 x float> %private.contiguous.load135, <8 x float> zeroinitializer
  %751 = fmul <8 x float> %750, %750
  store i64 4, ptr %.slot25, align 4
  %752 = load <8 x float>, ptr %.slot26, align 32
  %753 = select <8 x i1> %55, <8 x float> %709, <8 x float> %752
  store <8 x float> %753, ptr %.slot26, align 32
  %754 = load <8 x float>, ptr %.slot27, align 32
  %755 = select <8 x i1> %55, <8 x float> %723, <8 x float> %754
  store <8 x float> %755, ptr %.slot27, align 32
  %756 = load <8 x float>, ptr %.slot28, align 32
  %757 = select <8 x i1> %55, <8 x float> %737, <8 x float> %756
  store <8 x float> %757, ptr %.slot28, align 32
  %758 = load <8 x float>, ptr %.slot29, align 32
  %759 = select <8 x i1> %55, <8 x float> %751, <8 x float> %758
  store <8 x float> %759, ptr %.slot29, align 32
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state136 = load i64, ptr %.slot25, align 4
  %760 = icmp slt i64 %.state136, 96
  br i1 %760, label %direct.true137, label %direct.false138

direct.schedule.11:                               ; preds = %direct.true137
  %.state139 = load i64, ptr %.slot25, align 4
  %761 = add i64 %.state139, 0
  %tile_snapshot.spill.load140 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %762 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load140, 0
  %763 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load140, 1
  %.splatinsert141 = insertelement <8 x i64> poison, i64 %761, i64 0
  %.splat142 = shufflevector <8 x i64> %.splatinsert141, <8 x i64> poison, <8 x i32> zeroinitializer
  %764 = mul <8 x i64> %.splat142, splat (i64 32)
  %765 = add <8 x i64> %763, %764
  %766 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %762, 0
  %767 = insertvalue { <8 x ptr>, <8 x i64> } %766, <8 x i64> %765, 1
  %768 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %769 = extractvalue { <8 x ptr>, <8 x i64> } %767, 1
  %770 = extractelement <8 x ptr> %768, i32 0
  %771 = extractelement <8 x i64> %769, i32 0
  %772 = sub i64 %771, 0
  %773 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %774 = select i1 %773, i64 %772, i64 0
  %private.contiguous.address143 = getelementptr i8, ptr %770, i64 %774
  %private.contiguous.load144 = load <8 x float>, ptr %private.contiguous.address143, align 4
  %775 = select <8 x i1> %55, <8 x float> %private.contiguous.load144, <8 x float> zeroinitializer
  %776 = fmul <8 x float> %775, %775
  %.state145 = load <8 x float>, ptr %.slot26, align 32
  %777 = fadd <8 x float> %.state145, %776
  %.state146 = load i64, ptr %.slot25, align 4
  %778 = add i64 %.state146, 1
  %tile_snapshot.spill.load147 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %779 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 0
  %780 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 1
  %.splatinsert148 = insertelement <8 x i64> poison, i64 %778, i64 0
  %.splat149 = shufflevector <8 x i64> %.splatinsert148, <8 x i64> poison, <8 x i32> zeroinitializer
  %781 = mul <8 x i64> %.splat149, splat (i64 32)
  %782 = add <8 x i64> %780, %781
  %783 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %779, 0
  %784 = insertvalue { <8 x ptr>, <8 x i64> } %783, <8 x i64> %782, 1
  %785 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %786 = extractvalue { <8 x ptr>, <8 x i64> } %784, 1
  %787 = extractelement <8 x ptr> %785, i32 0
  %788 = extractelement <8 x i64> %786, i32 0
  %789 = sub i64 %788, 0
  %790 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %791 = select i1 %790, i64 %789, i64 0
  %private.contiguous.address150 = getelementptr i8, ptr %787, i64 %791
  %private.contiguous.load151 = load <8 x float>, ptr %private.contiguous.address150, align 4
  %792 = select <8 x i1> %55, <8 x float> %private.contiguous.load151, <8 x float> zeroinitializer
  %793 = fmul <8 x float> %792, %792
  %.state152 = load <8 x float>, ptr %.slot27, align 32
  %794 = fadd <8 x float> %.state152, %793
  %.state153 = load i64, ptr %.slot25, align 4
  %795 = add i64 %.state153, 2
  %tile_snapshot.spill.load154 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %796 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load154, 0
  %797 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load154, 1
  %.splatinsert155 = insertelement <8 x i64> poison, i64 %795, i64 0
  %.splat156 = shufflevector <8 x i64> %.splatinsert155, <8 x i64> poison, <8 x i32> zeroinitializer
  %798 = mul <8 x i64> %.splat156, splat (i64 32)
  %799 = add <8 x i64> %797, %798
  %800 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %796, 0
  %801 = insertvalue { <8 x ptr>, <8 x i64> } %800, <8 x i64> %799, 1
  %802 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %803 = extractvalue { <8 x ptr>, <8 x i64> } %801, 1
  %804 = extractelement <8 x ptr> %802, i32 0
  %805 = extractelement <8 x i64> %803, i32 0
  %806 = sub i64 %805, 0
  %807 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %808 = select i1 %807, i64 %806, i64 0
  %private.contiguous.address157 = getelementptr i8, ptr %804, i64 %808
  %private.contiguous.load158 = load <8 x float>, ptr %private.contiguous.address157, align 4
  %809 = select <8 x i1> %55, <8 x float> %private.contiguous.load158, <8 x float> zeroinitializer
  %810 = fmul <8 x float> %809, %809
  %.state159 = load <8 x float>, ptr %.slot28, align 32
  %811 = fadd <8 x float> %.state159, %810
  %.state160 = load i64, ptr %.slot25, align 4
  %812 = add i64 %.state160, 3
  %tile_snapshot.spill.load161 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %813 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load161, 0
  %814 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load161, 1
  %.splatinsert162 = insertelement <8 x i64> poison, i64 %812, i64 0
  %.splat163 = shufflevector <8 x i64> %.splatinsert162, <8 x i64> poison, <8 x i32> zeroinitializer
  %815 = mul <8 x i64> %.splat163, splat (i64 32)
  %816 = add <8 x i64> %814, %815
  %817 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %813, 0
  %818 = insertvalue { <8 x ptr>, <8 x i64> } %817, <8 x i64> %816, 1
  %819 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %820 = extractvalue { <8 x ptr>, <8 x i64> } %818, 1
  %821 = extractelement <8 x ptr> %819, i32 0
  %822 = extractelement <8 x i64> %820, i32 0
  %823 = sub i64 %822, 0
  %824 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %825 = select i1 %824, i64 %823, i64 0
  %private.contiguous.address164 = getelementptr i8, ptr %821, i64 %825
  %private.contiguous.load165 = load <8 x float>, ptr %private.contiguous.address164, align 4
  %826 = select <8 x i1> %55, <8 x float> %private.contiguous.load165, <8 x float> zeroinitializer
  %827 = fmul <8 x float> %826, %826
  %.state166 = load <8 x float>, ptr %.slot29, align 32
  %828 = fadd <8 x float> %.state166, %827
  %.state167 = load i64, ptr %.slot25, align 4
  %829 = add i64 %.state167, 4
  store i64 %829, ptr %.slot25, align 4
  %830 = load <8 x float>, ptr %.slot26, align 32
  %831 = select <8 x i1> %55, <8 x float> %777, <8 x float> %830
  store <8 x float> %831, ptr %.slot26, align 32
  %832 = load <8 x float>, ptr %.slot27, align 32
  %833 = select <8 x i1> %55, <8 x float> %794, <8 x float> %832
  store <8 x float> %833, ptr %.slot27, align 32
  %834 = load <8 x float>, ptr %.slot28, align 32
  %835 = select <8 x i1> %55, <8 x float> %811, <8 x float> %834
  store <8 x float> %835, ptr %.slot28, align 32
  %836 = load <8 x float>, ptr %.slot29, align 32
  %837 = select <8 x i1> %55, <8 x float> %828, <8 x float> %836
  store <8 x float> %837, ptr %.slot29, align 32
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false138
  %.state168 = load <8 x float>, ptr %.slot26, align 32
  %.state169 = load <8 x float>, ptr %.slot27, align 32
  %838 = fadd <8 x float> %.state168, %.state169
  %.state170 = load <8 x float>, ptr %.slot28, align 32
  %839 = fadd <8 x float> %838, %.state170
  %.state171 = load <8 x float>, ptr %.slot29, align 32
  %840 = fadd <8 x float> %839, %.state171
  %.spill.load172 = load <8 x i32>, ptr %.spill18, align 32
  %841 = extractelement <8 x i32> %.spill.load172, i64 0
  %842 = icmp ult i32 %841, 8
  %843 = select i1 %842, i32 %841, i32 0
  %844 = extractelement <8 x i1> %55, i32 %843
  %845 = extractelement <8 x i1> %55, i64 0
  %846 = and i1 %842, %844
  %847 = and i1 %845, %846
  %848 = extractelement <8 x float> %840, i32 %843
  %849 = select i1 %847, float %848, float 0.000000e+00
  %850 = insertelement <8 x float> poison, float %849, i64 0
  %851 = xor i1 %847, true
  %852 = and i1 %845, %851
  %853 = insertelement <8 x i1> poison, i1 %852, i64 0
  %854 = extractelement <8 x i32> %.spill.load172, i64 1
  %855 = icmp ult i32 %854, 8
  %856 = select i1 %855, i32 %854, i32 0
  %857 = extractelement <8 x i1> %55, i32 %856
  %858 = extractelement <8 x i1> %55, i64 1
  %859 = and i1 %855, %857
  %860 = and i1 %858, %859
  %861 = extractelement <8 x float> %840, i32 %856
  %862 = select i1 %860, float %861, float 0.000000e+00
  %863 = insertelement <8 x float> %850, float %862, i64 1
  %864 = xor i1 %860, true
  %865 = and i1 %858, %864
  %866 = insertelement <8 x i1> %853, i1 %865, i64 1
  %867 = extractelement <8 x i32> %.spill.load172, i64 2
  %868 = icmp ult i32 %867, 8
  %869 = select i1 %868, i32 %867, i32 0
  %870 = extractelement <8 x i1> %55, i32 %869
  %871 = extractelement <8 x i1> %55, i64 2
  %872 = and i1 %868, %870
  %873 = and i1 %871, %872
  %874 = extractelement <8 x float> %840, i32 %869
  %875 = select i1 %873, float %874, float 0.000000e+00
  %876 = insertelement <8 x float> %863, float %875, i64 2
  %877 = xor i1 %873, true
  %878 = and i1 %871, %877
  %879 = insertelement <8 x i1> %866, i1 %878, i64 2
  %880 = extractelement <8 x i32> %.spill.load172, i64 3
  %881 = icmp ult i32 %880, 8
  %882 = select i1 %881, i32 %880, i32 0
  %883 = extractelement <8 x i1> %55, i32 %882
  %884 = extractelement <8 x i1> %55, i64 3
  %885 = and i1 %881, %883
  %886 = and i1 %884, %885
  %887 = extractelement <8 x float> %840, i32 %882
  %888 = select i1 %886, float %887, float 0.000000e+00
  %889 = insertelement <8 x float> %876, float %888, i64 3
  %890 = xor i1 %886, true
  %891 = and i1 %884, %890
  %892 = insertelement <8 x i1> %879, i1 %891, i64 3
  %893 = extractelement <8 x i32> %.spill.load172, i64 4
  %894 = icmp ult i32 %893, 8
  %895 = select i1 %894, i32 %893, i32 0
  %896 = extractelement <8 x i1> %55, i32 %895
  %897 = extractelement <8 x i1> %55, i64 4
  %898 = and i1 %894, %896
  %899 = and i1 %897, %898
  %900 = extractelement <8 x float> %840, i32 %895
  %901 = select i1 %899, float %900, float 0.000000e+00
  %902 = insertelement <8 x float> %889, float %901, i64 4
  %903 = xor i1 %899, true
  %904 = and i1 %897, %903
  %905 = insertelement <8 x i1> %892, i1 %904, i64 4
  %906 = extractelement <8 x i32> %.spill.load172, i64 5
  %907 = icmp ult i32 %906, 8
  %908 = select i1 %907, i32 %906, i32 0
  %909 = extractelement <8 x i1> %55, i32 %908
  %910 = extractelement <8 x i1> %55, i64 5
  %911 = and i1 %907, %909
  %912 = and i1 %910, %911
  %913 = extractelement <8 x float> %840, i32 %908
  %914 = select i1 %912, float %913, float 0.000000e+00
  %915 = insertelement <8 x float> %902, float %914, i64 5
  %916 = xor i1 %912, true
  %917 = and i1 %910, %916
  %918 = insertelement <8 x i1> %905, i1 %917, i64 5
  %919 = extractelement <8 x i32> %.spill.load172, i64 6
  %920 = icmp ult i32 %919, 8
  %921 = select i1 %920, i32 %919, i32 0
  %922 = extractelement <8 x i1> %55, i32 %921
  %923 = extractelement <8 x i1> %55, i64 6
  %924 = and i1 %920, %922
  %925 = and i1 %923, %924
  %926 = extractelement <8 x float> %840, i32 %921
  %927 = select i1 %925, float %926, float 0.000000e+00
  %928 = insertelement <8 x float> %915, float %927, i64 6
  %929 = xor i1 %925, true
  %930 = and i1 %923, %929
  %931 = insertelement <8 x i1> %918, i1 %930, i64 6
  %932 = extractelement <8 x i32> %.spill.load172, i64 7
  %933 = icmp ult i32 %932, 8
  %934 = select i1 %933, i32 %932, i32 0
  %935 = extractelement <8 x i1> %55, i32 %934
  %936 = extractelement <8 x i1> %55, i64 7
  %937 = and i1 %933, %935
  %938 = and i1 %936, %937
  %939 = extractelement <8 x float> %840, i32 %934
  %940 = select i1 %938, float %939, float 0.000000e+00
  %941 = insertelement <8 x float> %928, float %940, i64 7
  %942 = xor i1 %938, true
  %943 = and i1 %936, %942
  %944 = insertelement <8 x i1> %931, i1 %943, i64 7
  %945 = fadd <8 x float> %840, %941
  %.spill.load173 = load <8 x i32>, ptr %.spill19, align 32
  %946 = extractelement <8 x i32> %.spill.load173, i64 0
  %947 = icmp ult i32 %946, 8
  %948 = select i1 %947, i32 %946, i32 0
  %949 = extractelement <8 x i1> %55, i32 %948
  %950 = extractelement <8 x i1> %55, i64 0
  %951 = and i1 %947, %949
  %952 = and i1 %950, %951
  %953 = extractelement <8 x float> %945, i32 %948
  %954 = select i1 %952, float %953, float 0.000000e+00
  %955 = insertelement <8 x float> poison, float %954, i64 0
  %956 = xor i1 %952, true
  %957 = and i1 %950, %956
  %958 = insertelement <8 x i1> poison, i1 %957, i64 0
  %959 = extractelement <8 x i32> %.spill.load173, i64 1
  %960 = icmp ult i32 %959, 8
  %961 = select i1 %960, i32 %959, i32 0
  %962 = extractelement <8 x i1> %55, i32 %961
  %963 = extractelement <8 x i1> %55, i64 1
  %964 = and i1 %960, %962
  %965 = and i1 %963, %964
  %966 = extractelement <8 x float> %945, i32 %961
  %967 = select i1 %965, float %966, float 0.000000e+00
  %968 = insertelement <8 x float> %955, float %967, i64 1
  %969 = xor i1 %965, true
  %970 = and i1 %963, %969
  %971 = insertelement <8 x i1> %958, i1 %970, i64 1
  %972 = extractelement <8 x i32> %.spill.load173, i64 2
  %973 = icmp ult i32 %972, 8
  %974 = select i1 %973, i32 %972, i32 0
  %975 = extractelement <8 x i1> %55, i32 %974
  %976 = extractelement <8 x i1> %55, i64 2
  %977 = and i1 %973, %975
  %978 = and i1 %976, %977
  %979 = extractelement <8 x float> %945, i32 %974
  %980 = select i1 %978, float %979, float 0.000000e+00
  %981 = insertelement <8 x float> %968, float %980, i64 2
  %982 = xor i1 %978, true
  %983 = and i1 %976, %982
  %984 = insertelement <8 x i1> %971, i1 %983, i64 2
  %985 = extractelement <8 x i32> %.spill.load173, i64 3
  %986 = icmp ult i32 %985, 8
  %987 = select i1 %986, i32 %985, i32 0
  %988 = extractelement <8 x i1> %55, i32 %987
  %989 = extractelement <8 x i1> %55, i64 3
  %990 = and i1 %986, %988
  %991 = and i1 %989, %990
  %992 = extractelement <8 x float> %945, i32 %987
  %993 = select i1 %991, float %992, float 0.000000e+00
  %994 = insertelement <8 x float> %981, float %993, i64 3
  %995 = xor i1 %991, true
  %996 = and i1 %989, %995
  %997 = insertelement <8 x i1> %984, i1 %996, i64 3
  %998 = extractelement <8 x i32> %.spill.load173, i64 4
  %999 = icmp ult i32 %998, 8
  %1000 = select i1 %999, i32 %998, i32 0
  %1001 = extractelement <8 x i1> %55, i32 %1000
  %1002 = extractelement <8 x i1> %55, i64 4
  %1003 = and i1 %999, %1001
  %1004 = and i1 %1002, %1003
  %1005 = extractelement <8 x float> %945, i32 %1000
  %1006 = select i1 %1004, float %1005, float 0.000000e+00
  %1007 = insertelement <8 x float> %994, float %1006, i64 4
  %1008 = xor i1 %1004, true
  %1009 = and i1 %1002, %1008
  %1010 = insertelement <8 x i1> %997, i1 %1009, i64 4
  %1011 = extractelement <8 x i32> %.spill.load173, i64 5
  %1012 = icmp ult i32 %1011, 8
  %1013 = select i1 %1012, i32 %1011, i32 0
  %1014 = extractelement <8 x i1> %55, i32 %1013
  %1015 = extractelement <8 x i1> %55, i64 5
  %1016 = and i1 %1012, %1014
  %1017 = and i1 %1015, %1016
  %1018 = extractelement <8 x float> %945, i32 %1013
  %1019 = select i1 %1017, float %1018, float 0.000000e+00
  %1020 = insertelement <8 x float> %1007, float %1019, i64 5
  %1021 = xor i1 %1017, true
  %1022 = and i1 %1015, %1021
  %1023 = insertelement <8 x i1> %1010, i1 %1022, i64 5
  %1024 = extractelement <8 x i32> %.spill.load173, i64 6
  %1025 = icmp ult i32 %1024, 8
  %1026 = select i1 %1025, i32 %1024, i32 0
  %1027 = extractelement <8 x i1> %55, i32 %1026
  %1028 = extractelement <8 x i1> %55, i64 6
  %1029 = and i1 %1025, %1027
  %1030 = and i1 %1028, %1029
  %1031 = extractelement <8 x float> %945, i32 %1026
  %1032 = select i1 %1030, float %1031, float 0.000000e+00
  %1033 = insertelement <8 x float> %1020, float %1032, i64 6
  %1034 = xor i1 %1030, true
  %1035 = and i1 %1028, %1034
  %1036 = insertelement <8 x i1> %1023, i1 %1035, i64 6
  %1037 = extractelement <8 x i32> %.spill.load173, i64 7
  %1038 = icmp ult i32 %1037, 8
  %1039 = select i1 %1038, i32 %1037, i32 0
  %1040 = extractelement <8 x i1> %55, i32 %1039
  %1041 = extractelement <8 x i1> %55, i64 7
  %1042 = and i1 %1038, %1040
  %1043 = and i1 %1041, %1042
  %1044 = extractelement <8 x float> %945, i32 %1039
  %1045 = select i1 %1043, float %1044, float 0.000000e+00
  %1046 = insertelement <8 x float> %1033, float %1045, i64 7
  %1047 = xor i1 %1043, true
  %1048 = and i1 %1041, %1047
  %1049 = insertelement <8 x i1> %1036, i1 %1048, i64 7
  %1050 = fadd <8 x float> %945, %1046
  %.spill.load174 = load <8 x i32>, ptr %.spill20, align 32
  %1051 = extractelement <8 x i32> %.spill.load174, i64 0
  %1052 = icmp ult i32 %1051, 8
  %1053 = select i1 %1052, i32 %1051, i32 0
  %1054 = extractelement <8 x i1> %55, i32 %1053
  %1055 = extractelement <8 x i1> %55, i64 0
  %1056 = and i1 %1052, %1054
  %1057 = and i1 %1055, %1056
  %1058 = extractelement <8 x float> %1050, i32 %1053
  %1059 = select i1 %1057, float %1058, float 0.000000e+00
  %1060 = insertelement <8 x float> poison, float %1059, i64 0
  %1061 = xor i1 %1057, true
  %1062 = and i1 %1055, %1061
  %1063 = insertelement <8 x i1> poison, i1 %1062, i64 0
  %1064 = extractelement <8 x i32> %.spill.load174, i64 1
  %1065 = icmp ult i32 %1064, 8
  %1066 = select i1 %1065, i32 %1064, i32 0
  %1067 = extractelement <8 x i1> %55, i32 %1066
  %1068 = extractelement <8 x i1> %55, i64 1
  %1069 = and i1 %1065, %1067
  %1070 = and i1 %1068, %1069
  %1071 = extractelement <8 x float> %1050, i32 %1066
  %1072 = select i1 %1070, float %1071, float 0.000000e+00
  %1073 = insertelement <8 x float> %1060, float %1072, i64 1
  %1074 = xor i1 %1070, true
  %1075 = and i1 %1068, %1074
  %1076 = insertelement <8 x i1> %1063, i1 %1075, i64 1
  %1077 = extractelement <8 x i32> %.spill.load174, i64 2
  %1078 = icmp ult i32 %1077, 8
  %1079 = select i1 %1078, i32 %1077, i32 0
  %1080 = extractelement <8 x i1> %55, i32 %1079
  %1081 = extractelement <8 x i1> %55, i64 2
  %1082 = and i1 %1078, %1080
  %1083 = and i1 %1081, %1082
  %1084 = extractelement <8 x float> %1050, i32 %1079
  %1085 = select i1 %1083, float %1084, float 0.000000e+00
  %1086 = insertelement <8 x float> %1073, float %1085, i64 2
  %1087 = xor i1 %1083, true
  %1088 = and i1 %1081, %1087
  %1089 = insertelement <8 x i1> %1076, i1 %1088, i64 2
  %1090 = extractelement <8 x i32> %.spill.load174, i64 3
  %1091 = icmp ult i32 %1090, 8
  %1092 = select i1 %1091, i32 %1090, i32 0
  %1093 = extractelement <8 x i1> %55, i32 %1092
  %1094 = extractelement <8 x i1> %55, i64 3
  %1095 = and i1 %1091, %1093
  %1096 = and i1 %1094, %1095
  %1097 = extractelement <8 x float> %1050, i32 %1092
  %1098 = select i1 %1096, float %1097, float 0.000000e+00
  %1099 = insertelement <8 x float> %1086, float %1098, i64 3
  %1100 = xor i1 %1096, true
  %1101 = and i1 %1094, %1100
  %1102 = insertelement <8 x i1> %1089, i1 %1101, i64 3
  %1103 = extractelement <8 x i32> %.spill.load174, i64 4
  %1104 = icmp ult i32 %1103, 8
  %1105 = select i1 %1104, i32 %1103, i32 0
  %1106 = extractelement <8 x i1> %55, i32 %1105
  %1107 = extractelement <8 x i1> %55, i64 4
  %1108 = and i1 %1104, %1106
  %1109 = and i1 %1107, %1108
  %1110 = extractelement <8 x float> %1050, i32 %1105
  %1111 = select i1 %1109, float %1110, float 0.000000e+00
  %1112 = insertelement <8 x float> %1099, float %1111, i64 4
  %1113 = xor i1 %1109, true
  %1114 = and i1 %1107, %1113
  %1115 = insertelement <8 x i1> %1102, i1 %1114, i64 4
  %1116 = extractelement <8 x i32> %.spill.load174, i64 5
  %1117 = icmp ult i32 %1116, 8
  %1118 = select i1 %1117, i32 %1116, i32 0
  %1119 = extractelement <8 x i1> %55, i32 %1118
  %1120 = extractelement <8 x i1> %55, i64 5
  %1121 = and i1 %1117, %1119
  %1122 = and i1 %1120, %1121
  %1123 = extractelement <8 x float> %1050, i32 %1118
  %1124 = select i1 %1122, float %1123, float 0.000000e+00
  %1125 = insertelement <8 x float> %1112, float %1124, i64 5
  %1126 = xor i1 %1122, true
  %1127 = and i1 %1120, %1126
  %1128 = insertelement <8 x i1> %1115, i1 %1127, i64 5
  %1129 = extractelement <8 x i32> %.spill.load174, i64 6
  %1130 = icmp ult i32 %1129, 8
  %1131 = select i1 %1130, i32 %1129, i32 0
  %1132 = extractelement <8 x i1> %55, i32 %1131
  %1133 = extractelement <8 x i1> %55, i64 6
  %1134 = and i1 %1130, %1132
  %1135 = and i1 %1133, %1134
  %1136 = extractelement <8 x float> %1050, i32 %1131
  %1137 = select i1 %1135, float %1136, float 0.000000e+00
  %1138 = insertelement <8 x float> %1125, float %1137, i64 6
  %1139 = xor i1 %1135, true
  %1140 = and i1 %1133, %1139
  %1141 = insertelement <8 x i1> %1128, i1 %1140, i64 6
  %1142 = extractelement <8 x i32> %.spill.load174, i64 7
  %1143 = icmp ult i32 %1142, 8
  %1144 = select i1 %1143, i32 %1142, i32 0
  %1145 = extractelement <8 x i1> %55, i32 %1144
  %1146 = extractelement <8 x i1> %55, i64 7
  %1147 = and i1 %1143, %1145
  %1148 = and i1 %1146, %1147
  %1149 = extractelement <8 x float> %1050, i32 %1144
  %1150 = select i1 %1148, float %1149, float 0.000000e+00
  %1151 = insertelement <8 x float> %1138, float %1150, i64 7
  %1152 = xor i1 %1148, true
  %1153 = and i1 %1146, %1152
  %1154 = insertelement <8 x i1> %1141, i1 %1153, i64 7
  %1155 = fadd <8 x float> %1050, %1151
  %1156 = extractelement <8 x i1> %55, i32 0
  %1157 = extractelement <8 x i1> %55, i64 0
  %1158 = and i1 true, %1156
  %1159 = and i1 %1157, %1158
  %1160 = extractelement <8 x float> %1155, i32 0
  %1161 = select i1 %1159, float %1160, float 0.000000e+00
  %1162 = insertelement <8 x float> poison, float %1161, i64 0
  %1163 = xor i1 %1159, true
  %1164 = and i1 %1157, %1163
  %1165 = insertelement <8 x i1> poison, i1 %1164, i64 0
  %1166 = extractelement <8 x i1> %55, i32 0
  %1167 = extractelement <8 x i1> %55, i64 1
  %1168 = and i1 true, %1166
  %1169 = and i1 %1167, %1168
  %1170 = extractelement <8 x float> %1155, i32 0
  %1171 = select i1 %1169, float %1170, float 0.000000e+00
  %1172 = insertelement <8 x float> %1162, float %1171, i64 1
  %1173 = xor i1 %1169, true
  %1174 = and i1 %1167, %1173
  %1175 = insertelement <8 x i1> %1165, i1 %1174, i64 1
  %1176 = extractelement <8 x i1> %55, i32 0
  %1177 = extractelement <8 x i1> %55, i64 2
  %1178 = and i1 true, %1176
  %1179 = and i1 %1177, %1178
  %1180 = extractelement <8 x float> %1155, i32 0
  %1181 = select i1 %1179, float %1180, float 0.000000e+00
  %1182 = insertelement <8 x float> %1172, float %1181, i64 2
  %1183 = xor i1 %1179, true
  %1184 = and i1 %1177, %1183
  %1185 = insertelement <8 x i1> %1175, i1 %1184, i64 2
  %1186 = extractelement <8 x i1> %55, i32 0
  %1187 = extractelement <8 x i1> %55, i64 3
  %1188 = and i1 true, %1186
  %1189 = and i1 %1187, %1188
  %1190 = extractelement <8 x float> %1155, i32 0
  %1191 = select i1 %1189, float %1190, float 0.000000e+00
  %1192 = insertelement <8 x float> %1182, float %1191, i64 3
  %1193 = xor i1 %1189, true
  %1194 = and i1 %1187, %1193
  %1195 = insertelement <8 x i1> %1185, i1 %1194, i64 3
  %1196 = extractelement <8 x i1> %55, i32 0
  %1197 = extractelement <8 x i1> %55, i64 4
  %1198 = and i1 true, %1196
  %1199 = and i1 %1197, %1198
  %1200 = extractelement <8 x float> %1155, i32 0
  %1201 = select i1 %1199, float %1200, float 0.000000e+00
  %1202 = insertelement <8 x float> %1192, float %1201, i64 4
  %1203 = xor i1 %1199, true
  %1204 = and i1 %1197, %1203
  %1205 = insertelement <8 x i1> %1195, i1 %1204, i64 4
  %1206 = extractelement <8 x i1> %55, i32 0
  %1207 = extractelement <8 x i1> %55, i64 5
  %1208 = and i1 true, %1206
  %1209 = and i1 %1207, %1208
  %1210 = extractelement <8 x float> %1155, i32 0
  %1211 = select i1 %1209, float %1210, float 0.000000e+00
  %1212 = insertelement <8 x float> %1202, float %1211, i64 5
  %1213 = xor i1 %1209, true
  %1214 = and i1 %1207, %1213
  %1215 = insertelement <8 x i1> %1205, i1 %1214, i64 5
  %1216 = extractelement <8 x i1> %55, i32 0
  %1217 = extractelement <8 x i1> %55, i64 6
  %1218 = and i1 true, %1216
  %1219 = and i1 %1217, %1218
  %1220 = extractelement <8 x float> %1155, i32 0
  %1221 = select i1 %1219, float %1220, float 0.000000e+00
  %1222 = insertelement <8 x float> %1212, float %1221, i64 6
  %1223 = xor i1 %1219, true
  %1224 = and i1 %1217, %1223
  %1225 = insertelement <8 x i1> %1215, i1 %1224, i64 6
  %1226 = extractelement <8 x i1> %55, i32 0
  %1227 = extractelement <8 x i1> %55, i64 7
  %1228 = and i1 true, %1226
  %1229 = and i1 %1227, %1228
  %1230 = extractelement <8 x float> %1155, i32 0
  %1231 = select i1 %1229, float %1230, float 0.000000e+00
  %1232 = insertelement <8 x float> %1222, float %1231, i64 7
  %1233 = xor i1 %1229, true
  %1234 = and i1 %1227, %1233
  %1235 = insertelement <8 x i1> %1225, i1 %1234, i64 7
  %1236 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1237 = bitcast <8 x i1> %55 to i8
  %1238 = call i8 @llvm.cttz.i8(i8 %1237, i1 false)
  %1239 = zext i8 %1238 to i32
  %1240 = select i1 %1236, i32 %1239, i32 0
  %1241 = extractelement <8 x float> %1232, i32 %1240
  %.spill.load175 = load float, ptr %.spill11, align 4
  %1242 = fadd float %.spill.load175, %1241
  %.spill.load176 = load float, ptr %.spill21, align 4
  %1243 = fdiv float %1242, %.spill.load176
  store float %1243, ptr %.spill30, align 4
  %1244 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1245 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1246 = extractvalue { <8 x ptr>, <8 x i64> } %1244, 0
  %1247 = select <8 x i1> %55, <8 x ptr> %1245, <8 x ptr> %1246
  %1248 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1249 = extractvalue { <8 x ptr>, <8 x i64> } %1244, 1
  %1250 = select <8 x i1> %55, <8 x i64> %1248, <8 x i64> %1249
  %1251 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1247, 0
  %1252 = insertvalue { <8 x ptr>, <8 x i64> } %1251, <8 x i64> %1250, 1
  store { <8 x ptr>, <8 x i64> } %1252, ptr %tile_snapshot.spill31, align 64
  store i64 0, ptr %.slot32, align 4
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state177 = load i64, ptr %.slot32, align 4
  %1253 = icmp slt i64 %.state177, 96
  br i1 %1253, label %direct.true178, label %direct.false179

direct.schedule.14:                               ; preds = %direct.true178
  %.state180 = load i64, ptr %.slot32, align 4
  %1254 = mul i64 %.state180, 8
  %.splatinsert181 = insertelement <8 x i64> poison, i64 %1254, i64 0
  %.splat182 = shufflevector <8 x i64> %.splatinsert181, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load183 = load <8 x i64>, ptr %.spill, align 64
  %1255 = add <8 x i64> %.splat182, %.spill.load183
  %.spill.load184 = load i64, ptr %.spill12, align 4
  %1256 = add i64 %.spill.load184, 0
  %1257 = add <8 x i64> zeroinitializer, %1255
  %1258 = mul i64 %1256, 768
  %.splatinsert185 = insertelement <8 x i64> poison, i64 %1258, i64 0
  %.splat186 = shufflevector <8 x i64> %.splatinsert185, <8 x i64> poison, <8 x i32> zeroinitializer
  %1259 = add <8 x i64> %.splat186, %1257
  %1260 = extractvalue { ptr, i64 } %19, 0
  %1261 = extractelement <8 x i64> %1259, i32 0
  %1262 = sub i64 %1261, 0
  %1263 = mul i64 %1262, 4
  %buffer.contiguous.address187 = getelementptr i8, ptr %1260, i64 %1263
  %buffer.contiguous.load188 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address187, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load189 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1264 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 0
  %1265 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 1
  %.state190 = load i64, ptr %.slot32, align 4
  %.splatinsert191 = insertelement <8 x i64> poison, i64 %.state190, i64 0
  %.splat192 = shufflevector <8 x i64> %.splatinsert191, <8 x i64> poison, <8 x i32> zeroinitializer
  %1266 = mul <8 x i64> %.splat192, splat (i64 32)
  %1267 = add <8 x i64> %1265, %1266
  %1268 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1264, 0
  %1269 = insertvalue { <8 x ptr>, <8 x i64> } %1268, <8 x i64> %1267, 1
  %1270 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1271 = extractvalue { <8 x ptr>, <8 x i64> } %1269, 1
  %1272 = extractelement <8 x ptr> %1270, i32 0
  %1273 = extractelement <8 x i64> %1271, i32 0
  %1274 = sub i64 %1273, 0
  %1275 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1276 = select i1 %1275, i64 %1274, i64 0
  %private.contiguous.address193 = getelementptr i8, ptr %1272, i64 %1276
  %private.contiguous.preserve194 = load <8 x float>, ptr %private.contiguous.address193, align 4
  %1277 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load188, <8 x float> %private.contiguous.preserve194
  store <8 x float> %1277, ptr %private.contiguous.address193, align 4
  %.state195 = load i64, ptr %.slot32, align 4
  %1278 = add i64 %.state195, 1
  store i64 %1278, ptr %.slot32, align 4
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false179
  %.spill.load196 = load float, ptr %.spill30, align 4
  %1279 = fadd float %.spill.load196, 0x3EE4F8B580000000
  %1280 = call float @llvm.sqrt.f32(float %1279)
  store float %1280, ptr %.spill33, align 4
  %1281 = extractvalue { ptr, i64 } %25, 1
  %1282 = extractvalue { ptr, i64 } %25, 0
  %1283 = ptrtoint ptr %1282 to i64
  %1284 = extractvalue { ptr, i64 } %31, 1
  %1285 = extractvalue { ptr, i64 } %31, 0
  %1286 = ptrtoint ptr %1285 to i64
  %1287 = icmp uge i64 %1283, %1286
  %1288 = sub i64 %1283, %1286
  %1289 = icmp uge i64 %1288, 396288
  %1290 = and i1 %1287, %1289
  %1291 = icmp uge i64 %1286, %1283
  %1292 = sub i64 %1286, %1283
  %1293 = icmp uge i64 %1292, 3072
  %1294 = and i1 %1291, %1293
  %1295 = or i1 %1290, %1294
  %1296 = and i1 true, %1295
  br i1 %1296, label %direct.true197, label %direct.false198

direct.schedule.16:                               ; preds = %direct.true197
  store i64 0, ptr %.slot34, align 4
  br label %direct.schedule.17

direct.schedule.17:                               ; preds = %direct.schedule.18, %direct.schedule.16
  %.state199 = load i64, ptr %.slot34, align 4
  %1297 = icmp slt i64 %.state199, 96
  br i1 %1297, label %direct.true200, label %direct.false201

direct.schedule.18:                               ; preds = %direct.true200
  %.state202 = load i64, ptr %.slot34, align 4
  %1298 = mul i64 %.state202, 8
  %.splatinsert203 = insertelement <8 x i64> poison, i64 %1298, i64 0
  %.splat204 = shufflevector <8 x i64> %.splatinsert203, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load205 = load <8 x i64>, ptr %.spill, align 64
  %1299 = add <8 x i64> %.splat204, %.spill.load205
  %tile_snapshot.spill.load206 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %1300 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load206, 0
  %1301 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load206, 1
  %.state207 = load i64, ptr %.slot34, align 4
  %.splatinsert208 = insertelement <8 x i64> poison, i64 %.state207, i64 0
  %.splat209 = shufflevector <8 x i64> %.splatinsert208, <8 x i64> poison, <8 x i32> zeroinitializer
  %1302 = mul <8 x i64> %.splat209, splat (i64 32)
  %1303 = add <8 x i64> %1301, %1302
  %1304 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1300, 0
  %1305 = insertvalue { <8 x ptr>, <8 x i64> } %1304, <8 x i64> %1303, 1
  %1306 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1307 = extractvalue { <8 x ptr>, <8 x i64> } %1305, 1
  %1308 = extractelement <8 x ptr> %1306, i32 0
  %1309 = extractelement <8 x i64> %1307, i32 0
  %1310 = sub i64 %1309, 0
  %1311 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1312 = select i1 %1311, i64 %1310, i64 0
  %private.contiguous.address210 = getelementptr i8, ptr %1308, i64 %1312
  %private.contiguous.load211 = load <8 x float>, ptr %private.contiguous.address210, align 4
  %1313 = select <8 x i1> %55, <8 x float> %private.contiguous.load211, <8 x float> zeroinitializer
  %.spill.load212 = load float, ptr %.spill33, align 4
  %.splatinsert213 = insertelement <8 x float> poison, float %.spill.load212, i64 0
  %.splat214 = shufflevector <8 x float> %.splatinsert213, <8 x float> poison, <8 x i32> zeroinitializer
  %1314 = fdiv <8 x float> %1313, %.splat214
  %tile_snapshot.spill.load215 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1315 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load215, 0
  %1316 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load215, 1
  %.state216 = load i64, ptr %.slot34, align 4
  %.splatinsert217 = insertelement <8 x i64> poison, i64 %.state216, i64 0
  %.splat218 = shufflevector <8 x i64> %.splatinsert217, <8 x i64> poison, <8 x i32> zeroinitializer
  %1317 = mul <8 x i64> %.splat218, splat (i64 32)
  %1318 = add <8 x i64> %1316, %1317
  %1319 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1315, 0
  %1320 = insertvalue { <8 x ptr>, <8 x i64> } %1319, <8 x i64> %1318, 1
  %1321 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1322 = extractvalue { <8 x ptr>, <8 x i64> } %1320, 1
  %1323 = extractelement <8 x ptr> %1321, i32 0
  %1324 = extractelement <8 x i64> %1322, i32 0
  %1325 = sub i64 %1324, 0
  %1326 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1327 = select i1 %1326, i64 %1325, i64 0
  %private.contiguous.address219 = getelementptr i8, ptr %1323, i64 %1327
  %private.contiguous.load220 = load <8 x float>, ptr %private.contiguous.address219, align 4
  %1328 = select <8 x i1> %55, <8 x float> %private.contiguous.load220, <8 x float> zeroinitializer
  %1329 = fmul <8 x float> %1314, %1328
  %.spill.load221 = load i64, ptr %.spill12, align 4
  %1330 = add i64 %.spill.load221, 0
  %1331 = add <8 x i64> zeroinitializer, %1299
  %1332 = mul i64 %1330, 768
  %.splatinsert222 = insertelement <8 x i64> poison, i64 %1332, i64 0
  %.splat223 = shufflevector <8 x i64> %.splatinsert222, <8 x i64> poison, <8 x i32> zeroinitializer
  %1333 = add <8 x i64> %.splat223, %1331
  %1334 = extractvalue { ptr, i64 } %25, 0
  %1335 = extractelement <8 x i64> %1333, i32 0
  %1336 = sub i64 %1335, 0
  %1337 = mul i64 %1336, 4
  %buffer.contiguous.address224 = getelementptr i8, ptr %1334, i64 %1337
  %buffer.contiguous.load225 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address224, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %1338 = fadd <8 x float> %1329, %buffer.contiguous.load225
  %.spill.load226 = load <8 x i64>, ptr %.spill10, align 64
  %1339 = add <8 x i64> %.spill.load226, zeroinitializer
  %1340 = add <8 x i64> zeroinitializer, %1339
  %1341 = mul <8 x i64> %1340, splat (i64 768)
  %1342 = add <8 x i64> %1341, %1331
  %1343 = extractvalue { ptr, i64 } %31, 0
  %1344 = extractelement <8 x i64> %1342, i32 0
  %1345 = sub i64 %1344, 0
  %1346 = mul i64 %1345, 4
  %buffer.contiguous.address227 = getelementptr i8, ptr %1343, i64 %1346
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1338, ptr %buffer.contiguous.address227, i32 1, <8 x i1> %55)
  %.state228 = load i64, ptr %.slot34, align 4
  %1347 = add i64 %.state228, 1
  store i64 %1347, ptr %.slot34, align 4
  br label %direct.schedule.17

direct.schedule.19:                               ; preds = %direct.false250, %direct.false201
  ret void

direct.schedule.20:                               ; preds = %direct.false198
  %1348 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1349 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1350 = extractvalue { <8 x ptr>, <8 x i64> } %1348, 0
  %1351 = select <8 x i1> %55, <8 x ptr> %1349, <8 x ptr> %1350
  %1352 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %1353 = extractvalue { <8 x ptr>, <8 x i64> } %1348, 1
  %1354 = select <8 x i1> %55, <8 x i64> %1352, <8 x i64> %1353
  %1355 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1351, 0
  %1356 = insertvalue { <8 x ptr>, <8 x i64> } %1355, <8 x i64> %1354, 1
  store { <8 x ptr>, <8 x i64> } %1356, ptr %tile_snapshot.spill35, align 64
  store i64 0, ptr %.slot36, align 4
  br label %direct.schedule.21

direct.schedule.21:                               ; preds = %direct.schedule.22, %direct.schedule.20
  %.state229 = load i64, ptr %.slot36, align 4
  %1357 = icmp slt i64 %.state229, 96
  br i1 %1357, label %direct.true230, label %direct.false231

direct.schedule.22:                               ; preds = %direct.true230
  %.state232 = load i64, ptr %.slot36, align 4
  %1358 = mul i64 %.state232, 8
  %.splatinsert233 = insertelement <8 x i64> poison, i64 %1358, i64 0
  %.splat234 = shufflevector <8 x i64> %.splatinsert233, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load235 = load <8 x i64>, ptr %.spill, align 64
  %1359 = add <8 x i64> %.splat234, %.spill.load235
  %.spill.load236 = load i64, ptr %.spill12, align 4
  %1360 = add i64 %.spill.load236, 0
  %1361 = add <8 x i64> zeroinitializer, %1359
  %1362 = mul i64 %1360, 768
  %.splatinsert237 = insertelement <8 x i64> poison, i64 %1362, i64 0
  %.splat238 = shufflevector <8 x i64> %.splatinsert237, <8 x i64> poison, <8 x i32> zeroinitializer
  %1363 = add <8 x i64> %.splat238, %1361
  %1364 = extractvalue { ptr, i64 } %25, 0
  %1365 = extractelement <8 x i64> %1363, i32 0
  %1366 = sub i64 %1365, 0
  %1367 = mul i64 %1366, 4
  %buffer.contiguous.address239 = getelementptr i8, ptr %1364, i64 %1367
  %buffer.contiguous.load240 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address239, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load241 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1368 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load241, 0
  %1369 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load241, 1
  %.state242 = load i64, ptr %.slot36, align 4
  %.splatinsert243 = insertelement <8 x i64> poison, i64 %.state242, i64 0
  %.splat244 = shufflevector <8 x i64> %.splatinsert243, <8 x i64> poison, <8 x i32> zeroinitializer
  %1370 = mul <8 x i64> %.splat244, splat (i64 32)
  %1371 = add <8 x i64> %1369, %1370
  %1372 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1368, 0
  %1373 = insertvalue { <8 x ptr>, <8 x i64> } %1372, <8 x i64> %1371, 1
  %1374 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1375 = extractvalue { <8 x ptr>, <8 x i64> } %1373, 1
  %1376 = extractelement <8 x ptr> %1374, i32 0
  %1377 = extractelement <8 x i64> %1375, i32 0
  %1378 = sub i64 %1377, 0
  %1379 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1380 = select i1 %1379, i64 %1378, i64 0
  %private.contiguous.address245 = getelementptr i8, ptr %1376, i64 %1380
  %private.contiguous.preserve246 = load <8 x float>, ptr %private.contiguous.address245, align 4
  %1381 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load240, <8 x float> %private.contiguous.preserve246
  store <8 x float> %1381, ptr %private.contiguous.address245, align 4
  %.state247 = load i64, ptr %.slot36, align 4
  %1382 = add i64 %.state247, 1
  store i64 %1382, ptr %.slot36, align 4
  br label %direct.schedule.21

direct.schedule.23:                               ; preds = %direct.false231
  store i64 0, ptr %.slot37, align 4
  br label %direct.schedule.24

direct.schedule.24:                               ; preds = %direct.schedule.25, %direct.schedule.23
  %.state248 = load i64, ptr %.slot37, align 4
  %1383 = icmp slt i64 %.state248, 96
  br i1 %1383, label %direct.true249, label %direct.false250

direct.schedule.25:                               ; preds = %direct.true249
  %.state251 = load i64, ptr %.slot37, align 4
  %1384 = mul i64 %.state251, 8
  %.splatinsert252 = insertelement <8 x i64> poison, i64 %1384, i64 0
  %.splat253 = shufflevector <8 x i64> %.splatinsert252, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load254 = load <8 x i64>, ptr %.spill, align 64
  %1385 = add <8 x i64> %.splat253, %.spill.load254
  %.spill.load255 = load <8 x i64>, ptr %.spill10, align 64
  %1386 = add <8 x i64> %.spill.load255, zeroinitializer
  %1387 = add <8 x i64> zeroinitializer, %1386
  %1388 = add <8 x i64> zeroinitializer, %1385
  %1389 = mul <8 x i64> %1387, splat (i64 768)
  %1390 = add <8 x i64> %1389, %1388
  %tile_snapshot.spill.load256 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %1391 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load256, 0
  %1392 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load256, 1
  %.state257 = load i64, ptr %.slot37, align 4
  %.splatinsert258 = insertelement <8 x i64> poison, i64 %.state257, i64 0
  %.splat259 = shufflevector <8 x i64> %.splatinsert258, <8 x i64> poison, <8 x i32> zeroinitializer
  %1393 = mul <8 x i64> %.splat259, splat (i64 32)
  %1394 = add <8 x i64> %1392, %1393
  %1395 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1391, 0
  %1396 = insertvalue { <8 x ptr>, <8 x i64> } %1395, <8 x i64> %1394, 1
  %1397 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1398 = extractvalue { <8 x ptr>, <8 x i64> } %1396, 1
  %1399 = extractelement <8 x ptr> %1397, i32 0
  %1400 = extractelement <8 x i64> %1398, i32 0
  %1401 = sub i64 %1400, 0
  %1402 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1403 = select i1 %1402, i64 %1401, i64 0
  %private.contiguous.address260 = getelementptr i8, ptr %1399, i64 %1403
  %private.contiguous.load261 = load <8 x float>, ptr %private.contiguous.address260, align 4
  %1404 = select <8 x i1> %55, <8 x float> %private.contiguous.load261, <8 x float> zeroinitializer
  %.spill.load262 = load float, ptr %.spill33, align 4
  %.splatinsert263 = insertelement <8 x float> poison, float %.spill.load262, i64 0
  %.splat264 = shufflevector <8 x float> %.splatinsert263, <8 x float> poison, <8 x i32> zeroinitializer
  %1405 = fdiv <8 x float> %1404, %.splat264
  %tile_snapshot.spill.load265 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1406 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load265, 0
  %1407 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load265, 1
  %.state266 = load i64, ptr %.slot37, align 4
  %.splatinsert267 = insertelement <8 x i64> poison, i64 %.state266, i64 0
  %.splat268 = shufflevector <8 x i64> %.splatinsert267, <8 x i64> poison, <8 x i32> zeroinitializer
  %1408 = mul <8 x i64> %.splat268, splat (i64 32)
  %1409 = add <8 x i64> %1407, %1408
  %1410 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1406, 0
  %1411 = insertvalue { <8 x ptr>, <8 x i64> } %1410, <8 x i64> %1409, 1
  %1412 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1413 = extractvalue { <8 x ptr>, <8 x i64> } %1411, 1
  %1414 = extractelement <8 x ptr> %1412, i32 0
  %1415 = extractelement <8 x i64> %1413, i32 0
  %1416 = sub i64 %1415, 0
  %1417 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1418 = select i1 %1417, i64 %1416, i64 0
  %private.contiguous.address269 = getelementptr i8, ptr %1414, i64 %1418
  %private.contiguous.load270 = load <8 x float>, ptr %private.contiguous.address269, align 4
  %1419 = select <8 x i1> %55, <8 x float> %private.contiguous.load270, <8 x float> zeroinitializer
  %1420 = fmul <8 x float> %1405, %1419
  %tile_snapshot.spill.load271 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1421 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 0
  %1422 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 1
  %.state272 = load i64, ptr %.slot37, align 4
  %.splatinsert273 = insertelement <8 x i64> poison, i64 %.state272, i64 0
  %.splat274 = shufflevector <8 x i64> %.splatinsert273, <8 x i64> poison, <8 x i32> zeroinitializer
  %1423 = mul <8 x i64> %.splat274, splat (i64 32)
  %1424 = add <8 x i64> %1422, %1423
  %1425 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1421, 0
  %1426 = insertvalue { <8 x ptr>, <8 x i64> } %1425, <8 x i64> %1424, 1
  %1427 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1428 = extractvalue { <8 x ptr>, <8 x i64> } %1426, 1
  %1429 = extractelement <8 x ptr> %1427, i32 0
  %1430 = extractelement <8 x i64> %1428, i32 0
  %1431 = sub i64 %1430, 0
  %1432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1433 = select i1 %1432, i64 %1431, i64 0
  %private.contiguous.address275 = getelementptr i8, ptr %1429, i64 %1433
  %private.contiguous.load276 = load <8 x float>, ptr %private.contiguous.address275, align 4
  %1434 = select <8 x i1> %55, <8 x float> %private.contiguous.load276, <8 x float> zeroinitializer
  %1435 = fadd <8 x float> %1420, %1434
  %1436 = extractvalue { ptr, i64 } %31, 0
  %1437 = extractelement <8 x i64> %1390, i32 0
  %1438 = sub i64 %1437, 0
  %1439 = mul i64 %1438, 4
  %buffer.contiguous.address277 = getelementptr i8, ptr %1436, i64 %1439
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1435, ptr %buffer.contiguous.address277, i32 1, <8 x i1> %55)
  %.state278 = load i64, ptr %.slot37, align 4
  %1440 = add i64 %.state278, 1
  store i64 %1440, ptr %.slot37, align 4
  br label %direct.schedule.24

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true68:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false69:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true106:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false107:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true137:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false138:                                  ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true178:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false179:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true197:                                   ; preds = %direct.schedule.15
  br label %direct.schedule.16

direct.false198:                                  ; preds = %direct.schedule.15
  br label %direct.schedule.20

direct.true200:                                   ; preds = %direct.schedule.17
  br label %direct.schedule.18

direct.false201:                                  ; preds = %direct.schedule.17
  br label %direct.schedule.19

direct.true230:                                   ; preds = %direct.schedule.21
  br label %direct.schedule.22

direct.false231:                                  ; preds = %direct.schedule.21
  br label %direct.schedule.23

direct.true249:                                   ; preds = %direct.schedule.24
  br label %direct.schedule.25

direct.false250:                                  ; preds = %direct.schedule.24
  br label %direct.schedule.19
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

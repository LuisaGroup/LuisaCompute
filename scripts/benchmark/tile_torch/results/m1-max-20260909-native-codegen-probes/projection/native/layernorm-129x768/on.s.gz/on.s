
/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/layernorm-129x768/on/object/tile_xir_w8_37905_1788936535819221_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	x24, x23, [sp, #-0x40]!
       4:      	stp	x22, x21, [sp, #0x10]
       8:      	stp	x20, x19, [sp, #0x20]
       c:      	stp	x29, x30, [sp, #0x30]
      10:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
      14:      	sub	sp, sp, #0x80
      18:      	ldr	x8, [x0]
      1c:      	ldr	x20, [x0, #0x10]
      20:      	ldr	x19, [x0, #0x20]
      24:      	ldr	x21, [x0, #0x30]
      28:      	ldr	w9, [x1]
      2c:      	ldr	w10, [x1, #0x24]
      30:      	add	w9, w10, w9, lsl #5
      34:      	lsr	w9, w9, #3
      38:      	mov	w10, #0xc00             ; =3072
      3c:      	umull	x22, w9, w10
      40:      	umaddl	x1, w9, w10, x8
      44:      	add	x23, sp, #0x2, lsl #12  ; =0x2000
      48:      	add	x23, x23, #0x480
      4c:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
      50:      	add	x0, x0, #0x480
      54:      	mov	w2, #0xc00              ; =3072
      58:      	bl	0x58 <ltmp0+0x58>
      5c:      	ldr	q0, [sp, #0x2490]
      60:      	ldr	q2, [sp, #0x2480]
      64:      	ldr	q1, [sp, #0x24b0]
      68:      	ldr	q5, [sp, #0x24a0]
      6c:      	ldr	q4, [sp, #0x24d0]
      70:      	ldr	q3, [sp, #0x24c0]
      74:      	add	x8, x23, #0xe0
      78:      	mov	w9, #0x4                ; =4
      7c:      	ldr	q6, [sp, #0x24f0]
      80:      	ldr	q7, [sp, #0x24e0]
      84:      	ldp	q16, q17, [x8, #-0x60]
      88:      	fadd.4s	v0, v0, v17
      8c:      	fadd.4s	v2, v2, v16
      90:      	ldp	q16, q17, [x8, #-0x40]
      94:      	fadd.4s	v1, v1, v17
      98:      	fadd.4s	v5, v5, v16
      9c:      	ldp	q16, q17, [x8, #-0x20]
      a0:      	fadd.4s	v4, v4, v17
      a4:      	fadd.4s	v3, v3, v16
      a8:      	ldp	q16, q17, [x8], #0x80
      ac:      	fadd.4s	v6, v6, v17
      b0:      	fadd.4s	v7, v7, v16
      b4:      	cmp	x9, #0x5c
      b8:      	add	x9, x9, #0x4
      bc:      	b.lo	0x84 <ltmp0+0x84>
      c0:      	mov	x8, #0x0                ; =0
      c4:      	fadd.4s	v2, v2, v5
      c8:      	fadd.4s	v0, v0, v1
      cc:      	fadd.4s	v0, v0, v4
      d0:      	fadd.4s	v1, v2, v3
      d4:      	fadd.4s	v1, v1, v7
      d8:      	fadd.4s	v0, v0, v6
      dc:      	rev64.4s	v2, v0
      e0:      	rev64.4s	v3, v1
      e4:      	fadd.4s	v1, v1, v3
      e8:      	fadd.4s	v0, v0, v2
      ec:      	dup.4s	v2, v0[2]
      f0:      	dup.4s	v3, v1[2]
      f4:      	fadd.4s	v1, v1, v3
      f8:      	fadd.4s	v0, v0, v2
      fc:      	fadd.4s	v0, v1, v0
     100:      	movi	d1, #0000000000000000
     104:      	fadd	s0, s0, s1
     108:      	mov	w9, #0x44400000         ; =1145044992
     10c:      	fmov	s1, w9
     110:      	fdiv	s0, s0, s1
     114:      	dup.4s	v0, v0[0]
     118:      	add	x9, sp, #0x2, lsl #12   ; =0x2000
     11c:      	add	x9, x9, #0x480
     120:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
     124:      	add	x10, x10, #0x880
     128:      	add	x11, x9, x8
     12c:      	ldp	q2, q1, [x11]
     130:      	fsub.4s	v2, v2, v0
     134:      	fsub.4s	v1, v1, v0
     138:      	add	x11, x10, x8
     13c:      	stp	q2, q1, [x11]
     140:      	add	x8, x8, #0x20
     144:      	cmp	x8, #0xc00
     148:      	b.ne	0x128 <ltmp0+0x128>
     14c:      	ldr	q0, [sp, #0x1880]
     150:      	ldr	q1, [sp, #0x1890]
     154:      	fmul.4s	v2, v1, v1
     158:      	fmul.4s	v3, v0, v0
     15c:      	ldr	q0, [sp, #0x18a0]
     160:      	ldr	q1, [sp, #0x18b0]
     164:      	fmul.4s	v4, v1, v1
     168:      	fmul.4s	v5, v0, v0
     16c:      	ldr	q0, [sp, #0x18c0]
     170:      	ldr	q1, [sp, #0x18d0]
     174:      	fmul.4s	v7, v1, v1
     178:      	fmul.4s	v6, v0, v0
     17c:      	ldr	q0, [sp, #0x18e0]
     180:      	ldr	q1, [sp, #0x18f0]
     184:      	fmul.4s	v16, v1, v1
     188:      	fmul.4s	v17, v0, v0
     18c:      	add	x8, sp, #0x1, lsl #12   ; =0x1000
     190:      	add	x8, x8, #0x880
     194:      	add	x8, x8, #0xe0
     198:      	mov	w9, #0x4                ; =4
     19c:      	ldp	q1, q0, [x8, #-0x60]
     1a0:      	fmul.4s	v1, v1, v1
     1a4:      	fmul.4s	v0, v0, v0
     1a8:      	fadd.4s	v2, v2, v0
     1ac:      	fadd.4s	v3, v3, v1
     1b0:      	ldp	q1, q0, [x8, #-0x40]
     1b4:      	fmul.4s	v1, v1, v1
     1b8:      	fmul.4s	v0, v0, v0
     1bc:      	fadd.4s	v4, v4, v0
     1c0:      	fadd.4s	v5, v5, v1
     1c4:      	ldp	q1, q0, [x8, #-0x20]
     1c8:      	fmul.4s	v1, v1, v1
     1cc:      	fmul.4s	v0, v0, v0
     1d0:      	fadd.4s	v7, v7, v0
     1d4:      	fadd.4s	v6, v6, v1
     1d8:      	ldp	q1, q0, [x8], #0x80
     1dc:      	fmul.4s	v1, v1, v1
     1e0:      	fmul.4s	v0, v0, v0
     1e4:      	fadd.4s	v16, v16, v0
     1e8:      	fadd.4s	v17, v17, v1
     1ec:      	cmp	x9, #0x5c
     1f0:      	add	x9, x9, #0x4
     1f4:      	b.lo	0x19c <ltmp0+0x19c>
     1f8:      	add	x23, sp, #0xc80
     1fc:      	add	x0, sp, #0xc80
     200:      	mov	x1, x20
     204:      	mov	w2, #0xc00              ; =3072
     208:      	stp	q4, q2, [sp, #0x30]
     20c:      	stp	q5, q3, [sp]
     210:      	stp	q6, q16, [sp, #0x60]
     214:      	str	q7, [sp, #0x20]
     218:      	str	q17, [sp, #0x50]
     21c:      	bl	0x21c <ltmp0+0x21c>
     220:      	ldp	q1, q0, [sp]
     224:      	fadd.4s	v0, v0, v1
     228:      	ldp	q2, q1, [sp, #0x30]
     22c:      	fadd.4s	v1, v1, v2
     230:      	ldr	q2, [sp, #0x20]
     234:      	fadd.4s	v1, v1, v2
     238:      	ldp	q2, q3, [sp, #0x50]
     23c:      	fadd.4s	v0, v0, v3
     240:      	fadd.4s	v0, v0, v2
     244:      	ldr	q2, [sp, #0x70]
     248:      	fadd.4s	v1, v1, v2
     24c:      	rev64.4s	v2, v1
     250:      	rev64.4s	v3, v0
     254:      	fadd.4s	v0, v0, v3
     258:      	fadd.4s	v1, v1, v2
     25c:      	dup.4s	v2, v1[2]
     260:      	dup.4s	v3, v0[2]
     264:      	fadd.4s	v0, v0, v3
     268:      	fadd.4s	v1, v1, v2
     26c:      	fadd.4s	v0, v0, v1
     270:      	movi	d1, #0000000000000000
     274:      	fadd	s0, s0, s1
     278:      	mov	w8, #0x44400000         ; =1145044992
     27c:      	fmov	s1, w8
     280:      	fdiv	s0, s0, s1
     284:      	mov	w8, #0xc5ac             ; =50604
     288:      	movk	w8, #0x3727, lsl #16
     28c:      	fmov	s1, w8
     290:      	fadd	s0, s0, s1
     294:      	fsqrt	s0, s0
     298:      	sub	x8, x19, x21
     29c:      	lsr	x9, x8, #10
     2a0:      	subs	x8, x21, x19
     2a4:      	mov	w10, #0xbff             ; =3071
     2a8:      	ccmp	x8, x10, #0x0, hs
     2ac:      	cset	w8, hi
     2b0:      	cmp	x9, #0x182
     2b4:      	ccmp	x19, x21, #0x0, hi
     2b8:      	b.hs	0x33c <ltmp0+0x33c>
     2bc:      	tbnz	w8, #0x0, 0x33c <ltmp0+0x33c>
     2c0:      	add	x20, sp, #0x80
     2c4:      	add	x0, sp, #0x80
     2c8:      	mov	x1, x19
     2cc:      	mov	w2, #0xc00              ; =3072
     2d0:      	str	q0, [sp, #0x70]
     2d4:      	bl	0x2d4 <ltmp0+0x2d4>
     2d8:      	mov	x8, #0x0                ; =0
     2dc:      	ldr	q0, [sp, #0x70]
     2e0:      	dup.4s	v0, v0[0]
     2e4:      	add	x9, x21, x22
     2e8:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
     2ec:      	add	x10, x10, #0x880
     2f0:      	add	x11, sp, #0xc80
     2f4:      	add	x12, x10, x8
     2f8:      	ldp	q2, q1, [x12]
     2fc:      	fdiv.4s	v2, v2, v0
     300:      	fdiv.4s	v1, v1, v0
     304:      	add	x12, x11, x8
     308:      	ldp	q3, q4, [x12]
     30c:      	fmul.4s	v1, v1, v4
     310:      	fmul.4s	v2, v2, v3
     314:      	add	x12, x20, x8
     318:      	ldp	q4, q3, [x12]
     31c:      	fadd.4s	v2, v2, v4
     320:      	fadd.4s	v1, v1, v3
     324:      	add	x12, x9, x8
     328:      	stp	q2, q1, [x12]
     32c:      	add	x8, x8, #0x20
     330:      	cmp	x8, #0xc00
     334:      	b.ne	0x2f4 <ltmp0+0x2f4>
     338:      	b	0x394 <ltmp0+0x394>
     33c:      	mov	x8, #0x0                ; =0
     340:      	dup.4s	v0, v0[0]
     344:      	add	x9, x21, x22
     348:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
     34c:      	add	x10, x10, #0x880
     350:      	add	x11, x10, x8
     354:      	ldp	q2, q1, [x11]
     358:      	fdiv.4s	v2, v2, v0
     35c:      	fdiv.4s	v1, v1, v0
     360:      	add	x11, x23, x8
     364:      	ldp	q3, q4, [x11]
     368:      	fmul.4s	v1, v1, v4
     36c:      	fmul.4s	v2, v2, v3
     370:      	add	x11, x19, x8
     374:      	ldp	q4, q3, [x11]
     378:      	fadd.4s	v2, v2, v4
     37c:      	fadd.4s	v1, v1, v3
     380:      	add	x11, x9, x8
     384:      	stp	q2, q1, [x11]
     388:      	add	x8, x8, #0x20
     38c:      	cmp	x8, #0xc00
     390:      	b.ne	0x350 <ltmp0+0x350>
     394:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
     398:      	add	sp, sp, #0x80
     39c:      	ldp	x29, x30, [sp, #0x30]
     3a0:      	ldp	x20, x19, [sp, #0x20]
     3a4:      	ldp	x22, x21, [sp, #0x10]
     3a8:      	ldp	x24, x23, [sp], #0x40
     3ac:      	ret

00000000000003b0 <_llm_rows.packet_batch.blocks>:
     3b0:      	stp	d9, d8, [sp, #-0x70]!
     3b4:      	stp	x28, x27, [sp, #0x10]
     3b8:      	stp	x26, x25, [sp, #0x20]
     3bc:      	stp	x24, x23, [sp, #0x30]
     3c0:      	stp	x22, x21, [sp, #0x40]
     3c4:      	stp	x20, x19, [sp, #0x50]
     3c8:      	stp	x29, x30, [sp, #0x60]
     3cc:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
     3d0:      	sub	sp, sp, #0x400
     3d4:      	str	x0, [sp, #0xa8]
     3d8:      	cbz	w3, 0x12dc <_llm_rows.packet_batch.blocks+0xf2c>
     3dc:      	mov	x19, x3
     3e0:      	mov	x20, x2
     3e4:      	mov	w22, #0x0               ; =0
     3e8:      	add	x24, sp, #0x2, lsl #12  ; =0x2000
     3ec:      	add	x24, x24, #0x800
     3f0:      	add	x9, x24, #0xe0
     3f4:      	ldp	w10, w8, [x2, #0x2c]
     3f8:      	stp	w8, w10, [sp, #0xa0]
     3fc:      	add	x28, sp, #0x1, lsl #12  ; =0x1000
     400:      	add	x28, x28, #0xc00
     404:      	add	x8, x28, #0xe0
     408:      	stp	x8, x9, [sp, #0x20]
     40c:      	ldp	w25, w16, [x2]
     410:      	ldp	w27, w8, [x2, #0x8]
     414:      	str	x8, [sp, #0x98]
     418:      	adrp	x8, 0x0 <ltmp0>
     41c:      	ldr	q0, [x8]
     420:      	str	q0, [sp, #0x10]
     424:      	adrp	x8, 0x0 <ltmp0>
     428:      	ldr	q0, [x8]
     42c:      	str	q0, [sp, #0x40]
     430:      	adrp	x8, 0x0 <ltmp0>
     434:      	ldr	q0, [x8]
     438:      	str	q0, [sp, #0x30]
     43c:      	movi	d8, #0000000000000000
     440:      	add	x21, sp, #0x1, lsl #12  ; =0x1000
     444:      	str	w3, [sp, #0x94]
     448:      	b	0x490 <_llm_rows.packet_batch.blocks+0xe0>
     44c:      	mov	w8, #0x18               ; =24
     450:      	str	w8, [x20, #0x24]
     454:      	ldr	w19, [sp, #0x94]
     458:      	add	w8, w25, #0x1
     45c:      	ldp	w10, w9, [sp, #0xa0]
     460:      	cmp	w8, w9
     464:      	cset	w8, eq
     468:      	csinc	w25, wzr, w25, eq
     46c:      	cinc	w9, w16, eq
     470:      	cmp	w9, w10
     474:      	cset	w10, eq
     478:      	ands	w8, w8, w10
     47c:      	csel	w16, wzr, w9, ne
     480:      	add	w27, w27, w8
     484:      	add	w22, w22, #0x1
     488:      	cmp	w22, w19
     48c:      	b.eq	0x12dc <_llm_rows.packet_batch.blocks+0xf2c>
     490:      	ubfiz	x8, x25, #5, #32
     494:      	ldr	x12, [sp, #0x98]
     498:      	cmp	x8, x12
     49c:      	csel	x9, x8, xzr, ls
     4a0:      	subs	x10, x12, x9
     4a4:      	cmp	x10, #0x20
     4a8:      	mov	w11, #0x20              ; =32
     4ac:      	csel	x10, x10, x11, lo
     4b0:      	cmp	x12, x9
     4b4:      	stp	w25, w16, [x20]
     4b8:      	str	w27, [x20, #0x8]
     4bc:      	str	wzr, [x20, #0x24]
     4c0:      	ccmp	x8, x12, #0x2, hi
     4c4:      	csel	x26, x10, xzr, ls
     4c8:      	cmp	x26, #0x20
     4cc:      	b.lo	0x528 <_llm_rows.packet_batch.blocks+0x178>
     4d0:      	ldr	x26, [sp, #0xa8]
     4d4:      	mov	x23, x16
     4d8:      	mov	x0, x26
     4dc:      	mov	x1, x20
     4e0:      	bl	0x4e0 <_llm_rows.packet_batch.blocks+0x130>
     4e4:      	mov	w8, #0x8                ; =8
     4e8:      	str	w8, [x20, #0x24]
     4ec:      	mov	x0, x26
     4f0:      	mov	x1, x20
     4f4:      	bl	0x4f4 <_llm_rows.packet_batch.blocks+0x144>
     4f8:      	mov	w8, #0x10               ; =16
     4fc:      	str	w8, [x20, #0x24]
     500:      	mov	x0, x26
     504:      	mov	x1, x20
     508:      	bl	0x508 <_llm_rows.packet_batch.blocks+0x158>
     50c:      	mov	w8, #0x18               ; =24
     510:      	str	w8, [x20, #0x24]
     514:      	mov	x0, x26
     518:      	mov	x1, x20
     51c:      	bl	0x51c <_llm_rows.packet_batch.blocks+0x16c>
     520:      	mov	x16, x23
     524:      	b	0x458 <_llm_rows.packet_batch.blocks+0xa8>
     528:      	lsr	x19, x26, #3
     52c:      	cmp	x26, #0x8
     530:      	b.lo	0x58c <_llm_rows.packet_batch.blocks+0x1dc>
     534:      	str	wzr, [x20, #0x24]
     538:      	mov	x23, x16
     53c:      	ldr	x0, [sp, #0xa8]
     540:      	mov	x1, x20
     544:      	bl	0x544 <_llm_rows.packet_batch.blocks+0x194>
     548:      	mov	x16, x23
     54c:      	cmp	x19, #0x1
     550:      	b.eq	0x58c <_llm_rows.packet_batch.blocks+0x1dc>
     554:      	mov	w8, #0x8                ; =8
     558:      	str	w8, [x20, #0x24]
     55c:      	ldr	x0, [sp, #0xa8]
     560:      	mov	x1, x20
     564:      	bl	0x564 <_llm_rows.packet_batch.blocks+0x1b4>
     568:      	mov	x16, x23
     56c:      	cmp	x19, #0x2
     570:      	b.eq	0x58c <_llm_rows.packet_batch.blocks+0x1dc>
     574:      	mov	w8, #0x10               ; =16
     578:      	str	w8, [x20, #0x24]
     57c:      	ldr	x0, [sp, #0xa8]
     580:      	mov	x1, x20
     584:      	bl	0x584 <_llm_rows.packet_batch.blocks+0x1d4>
     588:      	mov	x16, x23
     58c:      	and	w8, w26, #0x7
     590:      	cbz	w8, 0x44c <_llm_rows.packet_batch.blocks+0x9c>
     594:      	dup.4s	v4, w8
     598:      	ldp	q0, q1, [sp, #0x30]
     59c:      	cmhi.4s	v0, v4, v0
     5a0:      	cmhi.4s	v1, v4, v1
     5a4:      	uzp1.8h	v3, v1, v0
     5a8:      	umaxv.8h	h2, v3
     5ac:      	fmov	w8, s2
     5b0:      	tbz	w8, #0x0, 0x44c <_llm_rows.packet_batch.blocks+0x9c>
     5b4:      	str	w16, [sp, #0x90]
     5b8:      	mov	x10, #0x0               ; =0
     5bc:      	ldr	x9, [sp, #0xa8]
     5c0:      	ldr	x12, [x9, #0x10]
     5c4:      	ldr	x8, [x9, #0x20]
     5c8:      	ldr	x11, [x9, #0x30]
     5cc:      	str	x11, [sp, #0x88]
     5d0:      	ldr	q2, [sp, #0x10]
     5d4:      	and.16b	v2, v3, v2
     5d8:      	addv.8h	h2, v2
     5dc:      	fmov	w11, s2
     5e0:      	and	w0, w11, #0xff
     5e4:      	ldr	x13, [x9]
     5e8:      	ubfiz	w11, w25, #2, #27
     5ec:      	orr	w14, w11, w19
     5f0:      	fmov	w11, s4
     5f4:      	cmp	w11, #0x0
     5f8:      	cset	w11, ne
     5fc:      	mov	w9, #0xc00              ; =3072
     600:      	umull	x14, w14, w9
     604:      	csel	x9, x14, xzr, ne
     608:      	str	x9, [sp, #0x80]
     60c:      	add	x13, x13, x9
     610:      	fmov	w14, s2
     614:      	add	x9, sp, #0x140
     618:      	b	0x63c <_llm_rows.packet_batch.blocks+0x28c>
     61c:      	add	x15, x24, x10
     620:      	ldp	q6, q7, [x15]
     624:      	bif.16b	v5, v7, v0
     628:      	bif.16b	v4, v6, v1
     62c:      	stp	q4, q5, [x15]
     630:      	add	x10, x10, #0x20
     634:      	cmp	x10, #0xc00
     638:      	b.eq	0x6d0 <_llm_rows.packet_batch.blocks+0x320>
     63c:      	add	x15, x13, x10
     640:      	movi.2d	v4, #0000000000000000
     644:      	movi.2d	v5, #0000000000000000
     648:      	tbnz	w14, #0x0, 0x670 <_llm_rows.packet_batch.blocks+0x2c0>
     64c:      	and	w16, w14, #0xff
     650:      	tbnz	w16, #0x1, 0x67c <_llm_rows.packet_batch.blocks+0x2cc>
     654:      	tbnz	w16, #0x2, 0x688 <_llm_rows.packet_batch.blocks+0x2d8>
     658:      	tbnz	w16, #0x3, 0x694 <_llm_rows.packet_batch.blocks+0x2e4>
     65c:      	tbnz	w16, #0x4, 0x6a0 <_llm_rows.packet_batch.blocks+0x2f0>
     660:      	tbnz	w16, #0x5, 0x6ac <_llm_rows.packet_batch.blocks+0x2fc>
     664:      	tbnz	w16, #0x6, 0x6b8 <_llm_rows.packet_batch.blocks+0x308>
     668:      	tbz	w16, #0x7, 0x61c <_llm_rows.packet_batch.blocks+0x26c>
     66c:      	b	0x6c4 <_llm_rows.packet_batch.blocks+0x314>
     670:      	ldr	s4, [x15]
     674:      	and	w16, w14, #0xff
     678:      	tbz	w16, #0x1, 0x654 <_llm_rows.packet_batch.blocks+0x2a4>
     67c:      	add	x17, x15, #0x4
     680:      	ld1.s	{ v4 }[1], [x17]
     684:      	tbz	w16, #0x2, 0x658 <_llm_rows.packet_batch.blocks+0x2a8>
     688:      	add	x17, x15, #0x8
     68c:      	ld1.s	{ v4 }[2], [x17]
     690:      	tbz	w16, #0x3, 0x65c <_llm_rows.packet_batch.blocks+0x2ac>
     694:      	add	x17, x15, #0xc
     698:      	ld1.s	{ v4 }[3], [x17]
     69c:      	tbz	w16, #0x4, 0x660 <_llm_rows.packet_batch.blocks+0x2b0>
     6a0:      	add	x17, x15, #0x10
     6a4:      	ld1.s	{ v5 }[0], [x17]
     6a8:      	tbz	w16, #0x5, 0x664 <_llm_rows.packet_batch.blocks+0x2b4>
     6ac:      	add	x17, x15, #0x14
     6b0:      	ld1.s	{ v5 }[1], [x17]
     6b4:      	tbz	w16, #0x6, 0x668 <_llm_rows.packet_batch.blocks+0x2b8>
     6b8:      	add	x17, x15, #0x18
     6bc:      	ld1.s	{ v5 }[2], [x17]
     6c0:      	tbz	w16, #0x7, 0x61c <_llm_rows.packet_batch.blocks+0x26c>
     6c4:      	add	x15, x15, #0x1c
     6c8:      	ld1.s	{ v5 }[3], [x15]
     6cc:      	b	0x61c <_llm_rows.packet_batch.blocks+0x26c>
     6d0:      	ldr	q4, [x9, #0x26c0]
     6d4:      	ldr	q5, [x9, #0x26d0]
     6d8:      	ldr	q6, [x9, #0x26e0]
     6dc:      	ldr	q7, [x9, #0x26f0]
     6e0:      	ldr	q16, [x9, #0x2700]
     6e4:      	ldr	q19, [x9, #0x2710]
     6e8:      	ldr	q20, [x9, #0x2720]
     6ec:      	and.16b	v5, v0, v5
     6f0:      	and.16b	v4, v1, v4
     6f4:      	ldr	q21, [x9, #0x2730]
     6f8:      	and.16b	v18, v0, v7
     6fc:      	and.16b	v17, v1, v6
     700:      	and.16b	v6, v0, v19
     704:      	and.16b	v19, v1, v16
     708:      	and.16b	v16, v0, v21
     70c:      	and.16b	v7, v1, v20
     710:      	ldr	x10, [sp, #0x28]
     714:      	mov	w13, #0x4               ; =4
     718:      	ldp	q21, q20, [x10, #-0x60]
     71c:      	fadd.4s	v21, v4, v21
     720:      	fadd.4s	v20, v5, v20
     724:      	ldp	q23, q22, [x10, #-0x40]
     728:      	fadd.4s	v23, v17, v23
     72c:      	fadd.4s	v22, v18, v22
     730:      	ldp	q25, q24, [x10, #-0x20]
     734:      	fadd.4s	v25, v19, v25
     738:      	fadd.4s	v24, v6, v24
     73c:      	ldp	q27, q26, [x10], #0x80
     740:      	fadd.4s	v27, v7, v27
     744:      	fadd.4s	v26, v16, v26
     748:      	bit.16b	v5, v20, v0
     74c:      	bit.16b	v4, v21, v1
     750:      	bit.16b	v18, v22, v0
     754:      	bit.16b	v17, v23, v1
     758:      	bit.16b	v6, v24, v0
     75c:      	bit.16b	v19, v25, v1
     760:      	bit.16b	v16, v26, v0
     764:      	bit.16b	v7, v27, v1
     768:      	cmp	x13, #0x5c
     76c:      	add	x13, x13, #0x4
     770:      	b.lo	0x718 <_llm_rows.packet_batch.blocks+0x368>
     774:      	mov	x16, #0x0               ; =0
     778:      	xtn.8b	v3, v3
     77c:      	fadd.4s	v5, v5, v18
     780:      	fadd.4s	v4, v4, v17
     784:      	fadd.4s	v17, v4, v19
     788:      	fadd.4s	v4, v5, v6
     78c:      	fadd.4s	v4, v4, v16
     790:      	fadd.4s	v5, v17, v7
     794:      	umov.b	w13, v3[1]
     798:      	mov	s6, v5[1]
     79c:      	tst	w11, w13
     7a0:      	fcsel	s6, s6, s8, ne
     7a4:      	mvn	w10, w13
     7a8:      	add	x14, sp, #0x3d0
     7ac:      	bfi	x14, x10, #2, #1
     7b0:      	add	x15, sp, #0x2c8
     7b4:      	bfxil	x15, x10, #0, #1
     7b8:      	str	d3, [x9, #0x188]
     7bc:      	ldrb	w10, [x15]
     7c0:      	and	w10, w13, w10
     7c4:      	stp	q5, q4, [x9, #0x290]
     7c8:      	ldr	s7, [x14]
     7cc:      	tst	w10, #0x1
     7d0:      	fcsel	s7, s7, s8, ne
     7d4:      	umov.b	w6, v3[2]
     7d8:      	ands	w10, w6, #0x1
     7dc:      	mov	w14, #0x3               ; =3
     7e0:      	csinc	w14, w14, wzr, ne
     7e4:      	add	x4, sp, #0x2c8
     7e8:      	orr	x15, x4, x14
     7ec:      	ldrb	w15, [x15]
     7f0:      	add	x17, sp, #0x3b0
     7f4:      	orr	x14, x17, x14, lsl #2
     7f8:      	stp	q5, q4, [x9, #0x270]
     7fc:      	ldr	s16, [x14]
     800:      	tst	w10, w15
     804:      	fcsel	s16, s16, s8, ne
     808:      	umov.b	w23, v3[3]
     80c:      	ands	w10, w23, #0x1
     810:      	mov	w15, #0x1               ; =1
     814:      	cinc	w15, w15, ne
     818:      	add	x17, sp, #0x2c8
     81c:      	bfxil	x17, x15, #0, #3
     820:      	ldrb	w17, [x17]
     824:      	add	x1, sp, #0x390
     828:      	orr	x15, x1, x15, lsl #2
     82c:      	stp	q5, q4, [x9, #0x250]
     830:      	ldr	s17, [x15]
     834:      	tst	w10, w17
     838:      	umov.b	w5, v3[4]
     83c:      	fcsel	s17, s17, s8, ne
     840:      	ands	w15, w5, #0x1
     844:      	mov	w10, #0x5               ; =5
     848:      	csinc	w10, w10, wzr, ne
     84c:      	orr	x17, x4, x10
     850:      	ldrb	w1, [x17]
     854:      	stp	q5, q4, [x9, #0x230]
     858:      	add	x17, sp, #0x370
     85c:      	ldr	s18, [x17, w10, uxtw #2]
     860:      	mov	w10, #0x2               ; =2
     864:      	mov	w3, #0x6                ; =6
     868:      	csel	w17, w3, w10, ne
     86c:      	umov.b	w7, v3[5]
     870:      	tst	w15, w1
     874:      	fcsel	s18, s18, s8, ne
     878:      	ands	w10, w7, #0x1
     87c:      	mov	w1, #0x4                ; =4
     880:      	csinc	w1, w1, wzr, ne
     884:      	orr	x2, x4, x1
     888:      	ldrb	w2, [x2]
     88c:      	stp	q5, q4, [x9, #0x210]
     890:      	add	x19, sp, #0x350
     894:      	ldr	s19, [x19, w1, uxtw #2]
     898:      	umov.b	w30, v3[6]
     89c:      	tst	w10, w2
     8a0:      	fcsel	s19, s19, s8, ne
     8a4:      	ands	w1, w30, #0x1
     8a8:      	mov	w10, #0x7               ; =7
     8ac:      	csinc	w10, w10, wzr, ne
     8b0:      	orr	x2, x4, x10
     8b4:      	ldrb	w2, [x2]
     8b8:      	stp	q5, q4, [x9, #0x1f0]
     8bc:      	add	x19, sp, #0x330
     8c0:      	ldr	s20, [x19, w10, uxtw #2]
     8c4:      	umov.b	w10, v3[7]
     8c8:      	tst	w1, w2
     8cc:      	fcsel	s20, s20, s8, ne
     8d0:      	ands	w1, w10, #0x1
     8d4:      	csinc	w2, w3, wzr, ne
     8d8:      	orr	x3, x4, x2
     8dc:      	ldrb	w3, [x3]
     8e0:      	stp	q5, q4, [x9, #0x1d0]
     8e4:      	add	x19, sp, #0x310
     8e8:      	ldr	s21, [x19, w2, uxtw #2]
     8ec:      	tst	w1, w3
     8f0:      	fcsel	s21, s21, s8, ne
     8f4:      	mov.s	v6[1], v7[0]
     8f8:      	mov.s	v6[2], v16[0]
     8fc:      	mov.s	v6[3], v17[0]
     900:      	mov.s	v18[1], v19[0]
     904:      	mov.s	v18[2], v20[0]
     908:      	mov.s	v18[3], v21[0]
     90c:      	fadd.4s	v4, v4, v18
     910:      	fadd.4s	v5, v5, v6
     914:      	mov	s6, v5[2]
     918:      	tst	w11, w6
     91c:      	fcsel	s6, s6, s8, ne
     920:      	orr	x1, x4, x17
     924:      	ldrb	w1, [x1]
     928:      	stp	q5, q4, [x9, #0x1b0]
     92c:      	add	x2, sp, #0x2f0
     930:      	ldr	s7, [x2, w17, uxtw #2]
     934:      	tst	w15, w1
     938:      	fcsel	s7, s7, s8, ne
     93c:      	fadd.4s	v4, v4, v7
     940:      	tst	w11, w5
     944:      	fcsel	s4, s4, s8, ne
     948:      	str	w13, [sp, #0x7c]
     94c:      	ands	w13, w11, w13
     950:      	fadd.4s	v5, v5, v6
     954:      	fadd	s4, s5, s4
     958:      	fcsel	s5, s4, s8, ne
     95c:      	ands	w14, w11, w6
     960:      	str	w14, [sp, #0x74]
     964:      	fcsel	s6, s4, s8, ne
     968:      	ands	w14, w11, w5
     96c:      	str	w14, [sp, #0x78]
     970:      	fcsel	s7, s4, s8, ne
     974:      	cmp	w11, #0x0
     978:      	fcsel	s16, s4, s8, ne
     97c:      	ands	w14, w23, w11
     980:      	str	w14, [sp, #0x58]
     984:      	fcsel	s17, s4, s8, ne
     988:      	ands	w14, w7, w11
     98c:      	str	w14, [sp, #0x64]
     990:      	fcsel	s18, s4, s8, ne
     994:      	ands	w14, w30, w11
     998:      	str	w14, [sp, #0x60]
     99c:      	fcsel	s19, s4, s8, ne
     9a0:      	ands	w14, w10, w11
     9a4:      	str	w14, [sp, #0x5c]
     9a8:      	mov.s	v16[1], v5[0]
     9ac:      	mov.s	v16[2], v6[0]
     9b0:      	mov.s	v16[3], v17[0]
     9b4:      	mov.s	v7[1], v18[0]
     9b8:      	fcsel	s4, s4, s8, ne
     9bc:      	mov.s	v7[2], v19[0]
     9c0:      	mov.s	v7[3], v4[0]
     9c4:      	rbit	w0, w0
     9c8:      	clz	w14, w0
     9cc:      	stp	q16, q7, [x9, #0x190]
     9d0:      	str	x14, [sp, #0x68]
     9d4:      	and	x1, x14, #0x7
     9d8:      	add	x15, sp, #0x2d0
     9dc:      	ldr	s4, [x15, x1, lsl #2]
     9e0:      	fadd	s4, s4, s8
     9e4:      	mov	w15, #0x44400000        ; =1145044992
     9e8:      	fmov	s5, w15
     9ec:      	fdiv	s4, s4, s5
     9f0:      	dup.4s	v4, v4[0]
     9f4:      	add	x1, x24, x16
     9f8:      	ldp	q6, q5, [x1]
     9fc:      	fsub.4s	v6, v6, v4
     a00:      	fsub.4s	v5, v5, v4
     a04:      	add	x1, x28, x16
     a08:      	ldp	q7, q16, [x1]
     a0c:      	bif.16b	v5, v16, v0
     a10:      	bif.16b	v6, v7, v1
     a14:      	stp	q6, q5, [x1]
     a18:      	add	x16, x16, #0x20
     a1c:      	cmp	x16, #0xc00
     a20:      	b.ne	0x9f4 <_llm_rows.packet_batch.blocks+0x644>
     a24:      	ldr	q4, [x9, #0x1ad0]
     a28:      	ldr	q5, [x9, #0x1ac0]
     a2c:      	fmul.4s	v6, v5, v5
     a30:      	fmul.4s	v4, v4, v4
     a34:      	ldr	q5, [x9, #0x1af0]
     a38:      	ldr	q7, [x9, #0x1ae0]
     a3c:      	fmul.4s	v7, v7, v7
     a40:      	fmul.4s	v16, v5, v5
     a44:      	ldr	q5, [x9, #0x1b10]
     a48:      	ldr	q17, [x9, #0x1b00]
     a4c:      	fmul.4s	v19, v17, v17
     a50:      	fmul.4s	v20, v5, v5
     a54:      	ldr	q5, [x9, #0x1b30]
     a58:      	ldr	q17, [x9, #0x1b20]
     a5c:      	fmul.4s	v21, v17, v17
     a60:      	fmul.4s	v22, v5, v5
     a64:      	and.16b	v5, v0, v4
     a68:      	and.16b	v4, v1, v6
     a6c:      	and.16b	v18, v0, v16
     a70:      	and.16b	v17, v1, v7
     a74:      	and.16b	v6, v0, v20
     a78:      	and.16b	v19, v1, v19
     a7c:      	and.16b	v16, v0, v22
     a80:      	and.16b	v7, v1, v21
     a84:      	ldr	x16, [sp, #0x20]
     a88:      	mov	w1, #0x4                ; =4
     a8c:      	ldp	q21, q20, [x16, #-0x60]
     a90:      	and.16b	v21, v1, v21
     a94:      	and.16b	v20, v0, v20
     a98:      	fmul.4s	v20, v20, v20
     a9c:      	fmul.4s	v21, v21, v21
     aa0:      	fadd.4s	v21, v4, v21
     aa4:      	fadd.4s	v20, v5, v20
     aa8:      	ldp	q23, q22, [x16, #-0x40]
     aac:      	and.16b	v23, v1, v23
     ab0:      	and.16b	v22, v0, v22
     ab4:      	fmul.4s	v22, v22, v22
     ab8:      	fmul.4s	v23, v23, v23
     abc:      	fadd.4s	v23, v17, v23
     ac0:      	fadd.4s	v22, v18, v22
     ac4:      	ldp	q25, q24, [x16, #-0x20]
     ac8:      	and.16b	v25, v1, v25
     acc:      	and.16b	v24, v0, v24
     ad0:      	fmul.4s	v24, v24, v24
     ad4:      	fmul.4s	v25, v25, v25
     ad8:      	fadd.4s	v25, v19, v25
     adc:      	fadd.4s	v24, v6, v24
     ae0:      	ldp	q27, q26, [x16], #0x80
     ae4:      	and.16b	v27, v1, v27
     ae8:      	and.16b	v26, v0, v26
     aec:      	fmul.4s	v26, v26, v26
     af0:      	fmul.4s	v27, v27, v27
     af4:      	fadd.4s	v27, v7, v27
     af8:      	fadd.4s	v26, v16, v26
     afc:      	bit.16b	v5, v20, v0
     b00:      	bit.16b	v4, v21, v1
     b04:      	bit.16b	v18, v22, v0
     b08:      	bit.16b	v17, v23, v1
     b0c:      	bit.16b	v6, v24, v0
     b10:      	bit.16b	v19, v25, v1
     b14:      	bit.16b	v16, v26, v0
     b18:      	bit.16b	v7, v27, v1
     b1c:      	cmp	x1, #0x5c
     b20:      	add	x1, x1, #0x4
     b24:      	b.lo	0xa8c <_llm_rows.packet_batch.blocks+0x6dc>
     b28:      	mov	x16, #0x0               ; =0
     b2c:      	b	0xb50 <_llm_rows.packet_batch.blocks+0x7a0>
     b30:      	add	x1, x21, x16
     b34:      	ldp	q22, q23, [x1]
     b38:      	bif.16b	v21, v23, v0
     b3c:      	bif.16b	v20, v22, v1
     b40:      	stp	q20, q21, [x1]
     b44:      	add	x16, x16, #0x20
     b48:      	cmp	x16, #0xc00
     b4c:      	b.eq	0xbe8 <_llm_rows.packet_batch.blocks+0x838>
     b50:      	fmov	w2, s2
     b54:      	add	x1, x12, x16
     b58:      	movi.2d	v20, #0000000000000000
     b5c:      	movi.2d	v21, #0000000000000000
     b60:      	tbnz	w2, #0x0, 0xb88 <_llm_rows.packet_batch.blocks+0x7d8>
     b64:      	and	w2, w2, #0xff
     b68:      	tbnz	w2, #0x1, 0xb94 <_llm_rows.packet_batch.blocks+0x7e4>
     b6c:      	tbnz	w2, #0x2, 0xba0 <_llm_rows.packet_batch.blocks+0x7f0>
     b70:      	tbnz	w2, #0x3, 0xbac <_llm_rows.packet_batch.blocks+0x7fc>
     b74:      	tbnz	w2, #0x4, 0xbb8 <_llm_rows.packet_batch.blocks+0x808>
     b78:      	tbnz	w2, #0x5, 0xbc4 <_llm_rows.packet_batch.blocks+0x814>
     b7c:      	tbnz	w2, #0x6, 0xbd0 <_llm_rows.packet_batch.blocks+0x820>
     b80:      	tbz	w2, #0x7, 0xb30 <_llm_rows.packet_batch.blocks+0x780>
     b84:      	b	0xbdc <_llm_rows.packet_batch.blocks+0x82c>
     b88:      	ldr	s20, [x1]
     b8c:      	and	w2, w2, #0xff
     b90:      	tbz	w2, #0x1, 0xb6c <_llm_rows.packet_batch.blocks+0x7bc>
     b94:      	add	x3, x1, #0x4
     b98:      	ld1.s	{ v20 }[1], [x3]
     b9c:      	tbz	w2, #0x2, 0xb70 <_llm_rows.packet_batch.blocks+0x7c0>
     ba0:      	add	x3, x1, #0x8
     ba4:      	ld1.s	{ v20 }[2], [x3]
     ba8:      	tbz	w2, #0x3, 0xb74 <_llm_rows.packet_batch.blocks+0x7c4>
     bac:      	add	x3, x1, #0xc
     bb0:      	ld1.s	{ v20 }[3], [x3]
     bb4:      	tbz	w2, #0x4, 0xb78 <_llm_rows.packet_batch.blocks+0x7c8>
     bb8:      	add	x3, x1, #0x10
     bbc:      	ld1.s	{ v21 }[0], [x3]
     bc0:      	tbz	w2, #0x5, 0xb7c <_llm_rows.packet_batch.blocks+0x7cc>
     bc4:      	add	x3, x1, #0x14
     bc8:      	ld1.s	{ v21 }[1], [x3]
     bcc:      	tbz	w2, #0x6, 0xb80 <_llm_rows.packet_batch.blocks+0x7d0>
     bd0:      	add	x3, x1, #0x18
     bd4:      	ld1.s	{ v21 }[2], [x3]
     bd8:      	tbz	w2, #0x7, 0xb30 <_llm_rows.packet_batch.blocks+0x780>
     bdc:      	add	x1, x1, #0x1c
     be0:      	ld1.s	{ v21 }[3], [x1]
     be4:      	b	0xb30 <_llm_rows.packet_batch.blocks+0x780>
     be8:      	fadd.4s	v5, v5, v18
     bec:      	fadd.4s	v4, v4, v17
     bf0:      	fadd.4s	v17, v4, v19
     bf4:      	fadd.4s	v4, v5, v6
     bf8:      	fadd.4s	v4, v4, v16
     bfc:      	fadd.4s	v5, v17, v7
     c00:      	add	x14, sp, #0xb8
     c04:      	orr	x12, x14, x11
     c08:      	str	d3, [sp, #0xb8]
     c0c:      	ldrb	w12, [x12]
     c10:      	add	x15, sp, #0x2a0
     c14:      	orr	x16, x15, x11, lsl #2
     c18:      	stp	q5, q4, [x9, #0x160]
     c1c:      	ldr	s3, [x16]
     c20:      	tst	w11, w12
     c24:      	fcsel	s3, s3, s8, ne
     c28:      	tst	w13, #0x1
     c2c:      	fcsel	s6, s5, s8, ne
     c30:      	ands	w12, w6, #0x1
     c34:      	mov	w15, #0x3               ; =3
     c38:      	csel	w16, w15, wzr, ne
     c3c:      	orr	x1, x14, x16
     c40:      	ldrb	w1, [x1]
     c44:      	add	x15, sp, #0x280
     c48:      	orr	x16, x15, x16, lsl #2
     c4c:      	stp	q5, q4, [x9, #0x140]
     c50:      	ldr	s7, [x16]
     c54:      	tst	w12, w1
     c58:      	fcsel	s7, s7, s8, ne
     c5c:      	ands	w2, w23, #0x1
     c60:      	mov	w15, #0x2               ; =2
     c64:      	csel	w12, w15, wzr, ne
     c68:      	orr	x16, x14, x12
     c6c:      	ldrb	w16, [x16]
     c70:      	lsr	x12, x12, #1
     c74:      	add	x1, sp, #0x260
     c78:      	bfi	x1, x12, #3, #1
     c7c:      	stp	q5, q4, [x9, #0x120]
     c80:      	ldr	s16, [x1]
     c84:      	tst	w2, w16
     c88:      	fcsel	s16, s16, s8, ne
     c8c:      	cmp	w11, #0x0
     c90:      	csel	w4, w15, wzr, ne
     c94:      	mov	w9, #0x4                ; =4
     c98:      	csel	w17, w9, wzr, ne
     c9c:      	ands	w16, w10, #0x1
     ca0:      	mov	w0, #0x6                ; =6
     ca4:      	csel	w19, w0, wzr, ne
     ca8:      	mov	w15, #0x5               ; =5
     cac:      	csel	w12, w15, wzr, ne
     cb0:      	ands	w30, w30, #0x1
     cb4:      	mov	w3, #0x7                ; =7
     cb8:      	csel	w26, w3, wzr, ne
     cbc:      	csel	w6, w9, wzr, ne
     cc0:      	ands	w1, w7, #0x1
     cc4:      	mov	x10, x23
     cc8:      	add	x23, sp, #0x140
     ccc:      	csel	w9, w9, wzr, ne
     cd0:      	csel	w7, w3, wzr, ne
     cd4:      	ands	w5, w5, #0x1
     cd8:      	csel	w3, w15, wzr, ne
     cdc:      	orr	x15, x14, x3
     ce0:      	ldrb	w15, [x15]
     ce4:      	stp	q5, q4, [x23, #0x100]
     ce8:      	str	w13, [sp, #0x54]
     cec:      	add	x13, sp, #0x240
     cf0:      	ldr	s17, [x13, w3, uxtw #2]
     cf4:      	csel	w3, w0, wzr, ne
     cf8:      	tst	w5, w15
     cfc:      	orr	x15, x14, x9
     d00:      	ldrb	w15, [x15]
     d04:      	stp	q5, q4, [x23, #0xe0]
     d08:      	add	x13, sp, #0x220
     d0c:      	ldr	s18, [x13, w9, uxtw #2]
     d10:      	fcsel	s17, s17, s8, ne
     d14:      	tst	w1, w15
     d18:      	orr	x9, x14, x26
     d1c:      	ldrb	w9, [x9]
     d20:      	stp	q5, q4, [x23, #0xc0]
     d24:      	add	x13, sp, #0x200
     d28:      	ldr	s19, [x13, w26, uxtw #2]
     d2c:      	fcsel	s18, s18, s8, ne
     d30:      	tst	w30, w9
     d34:      	orr	x9, x14, x19
     d38:      	ldrb	w9, [x9]
     d3c:      	stp	q5, q4, [x23, #0xa0]
     d40:      	add	x13, sp, #0x1e0
     d44:      	ldr	s20, [x13, w19, uxtw #2]
     d48:      	fcsel	s19, s19, s8, ne
     d4c:      	tst	w16, w9
     d50:      	lsr	x9, x4, #1
     d54:      	add	x15, sp, #0x1c0
     d58:      	bfi	x15, x9, #3, #1
     d5c:      	fcsel	s20, s20, s8, ne
     d60:      	mov.s	v17[1], v18[0]
     d64:      	mov.s	v17[2], v19[0]
     d68:      	mov.s	v17[3], v20[0]
     d6c:      	mov.s	v3[1], v6[0]
     d70:      	mov.s	v3[2], v7[0]
     d74:      	mov.s	v3[3], v16[0]
     d78:      	fadd.4s	v3, v5, v3
     d7c:      	fadd.4s	v4, v4, v17
     d80:      	orr	x9, x14, x4
     d84:      	ldrb	w9, [x9]
     d88:      	stp	q3, q4, [x23, #0x80]
     d8c:      	ldr	s5, [x15]
     d90:      	tst	w11, w9
     d94:      	fcsel	s5, s5, s8, ne
     d98:      	ldr	w9, [sp, #0x7c]
     d9c:      	ands	w9, w9, #0x1
     da0:      	mov	w13, #0x3               ; =3
     da4:      	csel	w13, w13, wzr, ne
     da8:      	orr	x15, x14, x13
     dac:      	ldrb	w15, [x15]
     db0:      	tst	w9, w15
     db4:      	add	x9, sp, #0x100
     db8:      	orr	x9, x9, x13, lsl #2
     dbc:      	stp	q3, q4, [sp, #0x100]
     dc0:      	ldr	s6, [x9]
     dc4:      	add	x9, sp, #0xb8
     dc8:      	bfxil	x9, x10, #0, #1
     dcc:      	ldrb	w9, [x9]
     dd0:      	fcsel	s6, s6, s8, ne
     dd4:      	ldr	w13, [sp, #0x74]
     dd8:      	tst	w13, #0x1
     ddc:      	fcsel	s7, s3, s8, ne
     de0:      	tst	w2, w9
     de4:      	add	x9, sp, #0x1a0
     de8:      	bfi	x9, x10, #2, #1
     dec:      	stp	q3, q4, [x23, #0x60]
     df0:      	ldr	s16, [x9]
     df4:      	fcsel	s16, s16, s8, ne
     df8:      	orr	x9, x14, x3
     dfc:      	ldrb	w9, [x9]
     e00:      	tst	w5, w9
     e04:      	stp	q3, q4, [x23, #0x40]
     e08:      	add	x9, sp, #0x180
     e0c:      	ldr	s17, [x9, w3, uxtw #2]
     e10:      	fcsel	s17, s17, s8, ne
     e14:      	orr	x9, x14, x7
     e18:      	ldrb	w9, [x9]
     e1c:      	tst	w1, w9
     e20:      	stp	q3, q4, [x23, #0x20]
     e24:      	add	x9, sp, #0x160
     e28:      	ldr	s18, [x9, w7, uxtw #2]
     e2c:      	fcsel	s18, s18, s8, ne
     e30:      	orr	x9, x14, x6
     e34:      	ldrb	w9, [x9]
     e38:      	tst	w30, w9
     e3c:      	stp	q3, q4, [x23]
     e40:      	ldr	s19, [x23, w6, uxtw #2]
     e44:      	fcsel	s19, s19, s8, ne
     e48:      	orr	x9, x14, x12
     e4c:      	ldrb	w9, [x9]
     e50:      	tst	w16, w9
     e54:      	stp	q3, q4, [sp, #0x120]
     e58:      	add	x9, sp, #0x120
     e5c:      	ldr	s20, [x9, w12, uxtw #2]
     e60:      	mov.s	v5[1], v6[0]
     e64:      	mov.s	v5[2], v7[0]
     e68:      	mov.s	v5[3], v16[0]
     e6c:      	mov.s	v17[1], v18[0]
     e70:      	mov.s	v17[2], v19[0]
     e74:      	fcsel	s6, s20, s8, ne
     e78:      	mov.s	v17[3], v6[0]
     e7c:      	fadd.4s	v3, v3, v5
     e80:      	fadd.4s	v4, v4, v17
     e84:      	orr	x9, x14, x17
     e88:      	ldrb	w9, [x9]
     e8c:      	stp	q3, q4, [sp, #0xe0]
     e90:      	add	x10, sp, #0xe0
     e94:      	ldr	s4, [x10, w17, uxtw #2]
     e98:      	tst	w11, w9
     e9c:      	fcsel	s4, s4, s8, ne
     ea0:      	cmp	w11, #0x0
     ea4:      	fadd	s3, s3, s4
     ea8:      	fcsel	s4, s3, s8, ne
     eac:      	ldp	w10, w9, [sp, #0x54]
     eb0:      	tst	w10, #0x1
     eb4:      	fcsel	s5, s3, s8, ne
     eb8:      	tst	w13, #0x1
     ebc:      	fcsel	s6, s3, s8, ne
     ec0:      	tst	w9, #0x1
     ec4:      	fcsel	s7, s3, s8, ne
     ec8:      	ldr	w9, [sp, #0x78]
     ecc:      	tst	w9, #0x1
     ed0:      	fcsel	s16, s3, s8, ne
     ed4:      	ldp	w9, w10, [sp, #0x60]
     ed8:      	tst	w10, #0x1
     edc:      	fcsel	s17, s3, s8, ne
     ee0:      	tst	w9, #0x1
     ee4:      	fcsel	s18, s3, s8, ne
     ee8:      	ldr	w9, [sp, #0x5c]
     eec:      	tst	w9, #0x1
     ef0:      	fcsel	s3, s3, s8, ne
     ef4:      	mov.s	v4[1], v5[0]
     ef8:      	mov.s	v4[2], v6[0]
     efc:      	mov.s	v4[3], v7[0]
     f00:      	mov.s	v16[1], v17[0]
     f04:      	mov.s	v16[2], v18[0]
     f08:      	mov.s	v16[3], v3[0]
     f0c:      	stp	q4, q16, [sp, #0xc0]
     f10:      	ldr	x9, [sp, #0x68]
     f14:      	and	x9, x9, #0x7
     f18:      	add	x10, sp, #0xc0
     f1c:      	ldr	s3, [x10, x9, lsl #2]
     f20:      	ldr	x13, [sp, #0x88]
     f24:      	sub	x9, x8, x13
     f28:      	lsr	x9, x9, #10
     f2c:      	subs	x10, x13, x8
     f30:      	mov	w11, #0xbff             ; =3071
     f34:      	ccmp	x10, x11, #0x0, hs
     f38:      	cset	w10, hi
     f3c:      	cmp	x9, #0x182
     f40:      	fadd	s3, s3, s8
     f44:      	mov	w9, #0x44400000         ; =1145044992
     f48:      	fmov	s4, w9
     f4c:      	fdiv	s3, s3, s4
     f50:      	mov	w9, #0xc5ac             ; =50604
     f54:      	movk	w9, #0x3727, lsl #16
     f58:      	fmov	s4, w9
     f5c:      	fadd	s3, s3, s4
     f60:      	fsqrt	s3, s3
     f64:      	ccmp	x8, x13, #0x0, hi
     f68:      	b.hs	0x1038 <_llm_rows.packet_batch.blocks+0xc88>
     f6c:      	tbnz	w10, #0x0, 0x1038 <_llm_rows.packet_batch.blocks+0xc88>
     f70:      	mov	x10, #0x0               ; =0
     f74:      	ldr	w16, [sp, #0x90]
     f78:      	add	x14, sp, #0x400
     f7c:      	b	0xfa0 <_llm_rows.packet_batch.blocks+0xbf0>
     f80:      	add	x9, x14, x10
     f84:      	ldp	q6, q7, [x9]
     f88:      	bif.16b	v5, v7, v0
     f8c:      	bif.16b	v4, v6, v1
     f90:      	stp	q4, q5, [x9]
     f94:      	add	x10, x10, #0x20
     f98:      	cmp	x10, #0xc00
     f9c:      	b.eq	0x11d8 <_llm_rows.packet_batch.blocks+0xe28>
     fa0:      	fmov	w12, s2
     fa4:      	add	x11, x8, x10
     fa8:      	movi.2d	v4, #0000000000000000
     fac:      	movi.2d	v5, #0000000000000000
     fb0:      	tbnz	w12, #0x0, 0xfd8 <_llm_rows.packet_batch.blocks+0xc28>
     fb4:      	and	w12, w12, #0xff
     fb8:      	tbnz	w12, #0x1, 0xfe4 <_llm_rows.packet_batch.blocks+0xc34>
     fbc:      	tbnz	w12, #0x2, 0xff0 <_llm_rows.packet_batch.blocks+0xc40>
     fc0:      	tbnz	w12, #0x3, 0xffc <_llm_rows.packet_batch.blocks+0xc4c>
     fc4:      	tbnz	w12, #0x4, 0x1008 <_llm_rows.packet_batch.blocks+0xc58>
     fc8:      	tbnz	w12, #0x5, 0x1014 <_llm_rows.packet_batch.blocks+0xc64>
     fcc:      	tbnz	w12, #0x6, 0x1020 <_llm_rows.packet_batch.blocks+0xc70>
     fd0:      	tbz	w12, #0x7, 0xf80 <_llm_rows.packet_batch.blocks+0xbd0>
     fd4:      	b	0x102c <_llm_rows.packet_batch.blocks+0xc7c>
     fd8:      	ldr	s4, [x11]
     fdc:      	and	w12, w12, #0xff
     fe0:      	tbz	w12, #0x1, 0xfbc <_llm_rows.packet_batch.blocks+0xc0c>
     fe4:      	add	x9, x11, #0x4
     fe8:      	ld1.s	{ v4 }[1], [x9]
     fec:      	tbz	w12, #0x2, 0xfc0 <_llm_rows.packet_batch.blocks+0xc10>
     ff0:      	add	x9, x11, #0x8
     ff4:      	ld1.s	{ v4 }[2], [x9]
     ff8:      	tbz	w12, #0x3, 0xfc4 <_llm_rows.packet_batch.blocks+0xc14>
     ffc:      	add	x9, x11, #0xc
    1000:      	ld1.s	{ v4 }[3], [x9]
    1004:      	tbz	w12, #0x4, 0xfc8 <_llm_rows.packet_batch.blocks+0xc18>
    1008:      	add	x9, x11, #0x10
    100c:      	ld1.s	{ v5 }[0], [x9]
    1010:      	tbz	w12, #0x5, 0xfcc <_llm_rows.packet_batch.blocks+0xc1c>
    1014:      	add	x9, x11, #0x14
    1018:      	ld1.s	{ v5 }[1], [x9]
    101c:      	tbz	w12, #0x6, 0xfd0 <_llm_rows.packet_batch.blocks+0xc20>
    1020:      	add	x9, x11, #0x18
    1024:      	ld1.s	{ v5 }[2], [x9]
    1028:      	tbz	w12, #0x7, 0xf80 <_llm_rows.packet_batch.blocks+0xbd0>
    102c:      	add	x9, x11, #0x1c
    1030:      	ld1.s	{ v5 }[3], [x9]
    1034:      	b	0xf80 <_llm_rows.packet_batch.blocks+0xbd0>
    1038:      	mov	x10, #0x0               ; =0
    103c:      	dup.4s	v3, v3[0]
    1040:      	ldr	x9, [sp, #0x80]
    1044:      	add	x9, x13, x9
    1048:      	ldr	w16, [sp, #0x90]
    104c:      	b	0x105c <_llm_rows.packet_batch.blocks+0xcac>
    1050:      	add	x10, x10, #0x20
    1054:      	cmp	x10, #0xc00
    1058:      	b.eq	0x44c <_llm_rows.packet_batch.blocks+0x9c>
    105c:      	fmov	w12, s2
    1060:      	add	x11, x8, x10
    1064:      	movi.2d	v5, #0000000000000000
    1068:      	movi.2d	v4, #0000000000000000
    106c:      	tbnz	w12, #0x0, 0x1108 <_llm_rows.packet_batch.blocks+0xd58>
    1070:      	and	w12, w12, #0xff
    1074:      	tbnz	w12, #0x1, 0x1114 <_llm_rows.packet_batch.blocks+0xd64>
    1078:      	tbnz	w12, #0x2, 0x1120 <_llm_rows.packet_batch.blocks+0xd70>
    107c:      	tbnz	w12, #0x3, 0x112c <_llm_rows.packet_batch.blocks+0xd7c>
    1080:      	tbnz	w12, #0x4, 0x1138 <_llm_rows.packet_batch.blocks+0xd88>
    1084:      	tbnz	w12, #0x5, 0x1144 <_llm_rows.packet_batch.blocks+0xd94>
    1088:      	tbnz	w12, #0x6, 0x1150 <_llm_rows.packet_batch.blocks+0xda0>
    108c:      	tbz	w12, #0x7, 0x1098 <_llm_rows.packet_batch.blocks+0xce8>
    1090:      	add	x11, x11, #0x1c
    1094:      	ld1.s	{ v4 }[3], [x11]
    1098:      	add	x13, x28, x10
    109c:      	ldr	q6, [x13]
    10a0:      	and.16b	v6, v1, v6
    10a4:      	fdiv.4s	v6, v6, v3
    10a8:      	add	x14, x21, x10
    10ac:      	ldr	q7, [x14]
    10b0:      	and.16b	v7, v1, v7
    10b4:      	fmul.4s	v6, v6, v7
    10b8:      	fmov	w12, s2
    10bc:      	fadd.4s	v5, v5, v6
    10c0:      	add	x11, x9, x10
    10c4:      	tbnz	w12, #0x0, 0x1160 <_llm_rows.packet_batch.blocks+0xdb0>
    10c8:      	and	w12, w12, #0xff
    10cc:      	tbnz	w12, #0x1, 0x116c <_llm_rows.packet_batch.blocks+0xdbc>
    10d0:      	ldr	q7, [x13, #0x10]
    10d4:      	ldr	q6, [x14, #0x10]
    10d8:      	tbnz	w12, #0x2, 0x1180 <_llm_rows.packet_batch.blocks+0xdd0>
    10dc:      	tbnz	w12, #0x3, 0x118c <_llm_rows.packet_batch.blocks+0xddc>
    10e0:      	and.16b	v5, v0, v7
    10e4:      	fdiv.4s	v5, v5, v3
    10e8:      	and.16b	v6, v0, v6
    10ec:      	fmul.4s	v5, v5, v6
    10f0:      	fadd.4s	v4, v4, v5
    10f4:      	tbnz	w12, #0x4, 0x11ac <_llm_rows.packet_batch.blocks+0xdfc>
    10f8:      	tbnz	w12, #0x5, 0x11b4 <_llm_rows.packet_batch.blocks+0xe04>
    10fc:      	tbnz	w12, #0x6, 0x11c0 <_llm_rows.packet_batch.blocks+0xe10>
    1100:      	tbz	w12, #0x7, 0x1050 <_llm_rows.packet_batch.blocks+0xca0>
    1104:      	b	0x11cc <_llm_rows.packet_batch.blocks+0xe1c>
    1108:      	ldr	s5, [x11]
    110c:      	and	w12, w12, #0xff
    1110:      	tbz	w12, #0x1, 0x1078 <_llm_rows.packet_batch.blocks+0xcc8>
    1114:      	add	x13, x11, #0x4
    1118:      	ld1.s	{ v5 }[1], [x13]
    111c:      	tbz	w12, #0x2, 0x107c <_llm_rows.packet_batch.blocks+0xccc>
    1120:      	add	x13, x11, #0x8
    1124:      	ld1.s	{ v5 }[2], [x13]
    1128:      	tbz	w12, #0x3, 0x1080 <_llm_rows.packet_batch.blocks+0xcd0>
    112c:      	add	x13, x11, #0xc
    1130:      	ld1.s	{ v5 }[3], [x13]
    1134:      	tbz	w12, #0x4, 0x1084 <_llm_rows.packet_batch.blocks+0xcd4>
    1138:      	add	x13, x11, #0x10
    113c:      	ld1.s	{ v4 }[0], [x13]
    1140:      	tbz	w12, #0x5, 0x1088 <_llm_rows.packet_batch.blocks+0xcd8>
    1144:      	add	x13, x11, #0x14
    1148:      	ld1.s	{ v4 }[1], [x13]
    114c:      	tbz	w12, #0x6, 0x108c <_llm_rows.packet_batch.blocks+0xcdc>
    1150:      	add	x13, x11, #0x18
    1154:      	ld1.s	{ v4 }[2], [x13]
    1158:      	tbnz	w12, #0x7, 0x1090 <_llm_rows.packet_batch.blocks+0xce0>
    115c:      	b	0x1098 <_llm_rows.packet_batch.blocks+0xce8>
    1160:      	str	s5, [x11]
    1164:      	and	w12, w12, #0xff
    1168:      	tbz	w12, #0x1, 0x10d0 <_llm_rows.packet_batch.blocks+0xd20>
    116c:      	add	x15, x11, #0x4
    1170:      	st1.s	{ v5 }[1], [x15]
    1174:      	ldr	q7, [x13, #0x10]
    1178:      	ldr	q6, [x14, #0x10]
    117c:      	tbz	w12, #0x2, 0x10dc <_llm_rows.packet_batch.blocks+0xd2c>
    1180:      	add	x13, x11, #0x8
    1184:      	st1.s	{ v5 }[2], [x13]
    1188:      	tbz	w12, #0x3, 0x10e0 <_llm_rows.packet_batch.blocks+0xd30>
    118c:      	add	x13, x11, #0xc
    1190:      	st1.s	{ v5 }[3], [x13]
    1194:      	and.16b	v5, v0, v7
    1198:      	fdiv.4s	v5, v5, v3
    119c:      	and.16b	v6, v0, v6
    11a0:      	fmul.4s	v5, v5, v6
    11a4:      	fadd.4s	v4, v4, v5
    11a8:      	tbz	w12, #0x4, 0x10f8 <_llm_rows.packet_batch.blocks+0xd48>
    11ac:      	str	s4, [x11, #0x10]
    11b0:      	tbz	w12, #0x5, 0x10fc <_llm_rows.packet_batch.blocks+0xd4c>
    11b4:      	add	x13, x11, #0x14
    11b8:      	st1.s	{ v4 }[1], [x13]
    11bc:      	tbz	w12, #0x6, 0x1100 <_llm_rows.packet_batch.blocks+0xd50>
    11c0:      	add	x13, x11, #0x18
    11c4:      	st1.s	{ v4 }[2], [x13]
    11c8:      	tbz	w12, #0x7, 0x1050 <_llm_rows.packet_batch.blocks+0xca0>
    11cc:      	add	x11, x11, #0x1c
    11d0:      	st1.s	{ v4 }[3], [x11]
    11d4:      	b	0x1050 <_llm_rows.packet_batch.blocks+0xca0>
    11d8:      	mov	x8, #0x0                ; =0
    11dc:      	dup.4s	v3, v3[0]
    11e0:      	ldr	x9, [sp, #0x80]
    11e4:      	add	x9, x13, x9
    11e8:      	b	0x11f8 <_llm_rows.packet_batch.blocks+0xe48>
    11ec:      	add	x8, x8, #0x20
    11f0:      	cmp	x8, #0xc00
    11f4:      	b.eq	0x44c <_llm_rows.packet_batch.blocks+0x9c>
    11f8:      	fmov	w11, s2
    11fc:      	add	x12, x28, x8
    1200:      	ldr	q4, [x12]
    1204:      	and.16b	v4, v1, v4
    1208:      	fdiv.4s	v4, v4, v3
    120c:      	add	x13, x21, x8
    1210:      	ldr	q5, [x13]
    1214:      	and.16b	v5, v1, v5
    1218:      	fmul.4s	v5, v4, v5
    121c:      	add	x10, x14, x8
    1220:      	ldp	q6, q4, [x10]
    1224:      	and.16b	v6, v1, v6
    1228:      	fadd.4s	v5, v5, v6
    122c:      	add	x10, x9, x8
    1230:      	tbnz	w11, #0x0, 0x1280 <_llm_rows.packet_batch.blocks+0xed0>
    1234:      	and	w11, w11, #0xff
    1238:      	ldr	q7, [x12, #0x10]
    123c:      	ldr	q6, [x13, #0x10]
    1240:      	tbnz	w11, #0x1, 0x1294 <_llm_rows.packet_batch.blocks+0xee4>
    1244:      	tbnz	w11, #0x2, 0x12a0 <_llm_rows.packet_batch.blocks+0xef0>
    1248:      	tbz	w11, #0x3, 0x1254 <_llm_rows.packet_batch.blocks+0xea4>
    124c:      	add	x12, x10, #0xc
    1250:      	st1.s	{ v5 }[3], [x12]
    1254:      	and.16b	v5, v0, v7
    1258:      	fdiv.4s	v5, v5, v3
    125c:      	and.16b	v6, v0, v6
    1260:      	fmul.4s	v5, v5, v6
    1264:      	and.16b	v4, v0, v4
    1268:      	fadd.4s	v4, v5, v4
    126c:      	tbnz	w11, #0x4, 0x12b0 <_llm_rows.packet_batch.blocks+0xf00>
    1270:      	tbnz	w11, #0x5, 0x12b8 <_llm_rows.packet_batch.blocks+0xf08>
    1274:      	tbnz	w11, #0x6, 0x12c4 <_llm_rows.packet_batch.blocks+0xf14>
    1278:      	tbz	w11, #0x7, 0x11ec <_llm_rows.packet_batch.blocks+0xe3c>
    127c:      	b	0x12d0 <_llm_rows.packet_batch.blocks+0xf20>
    1280:      	str	s5, [x10]
    1284:      	and	w11, w11, #0xff
    1288:      	ldr	q7, [x12, #0x10]
    128c:      	ldr	q6, [x13, #0x10]
    1290:      	tbz	w11, #0x1, 0x1244 <_llm_rows.packet_batch.blocks+0xe94>
    1294:      	add	x12, x10, #0x4
    1298:      	st1.s	{ v5 }[1], [x12]
    129c:      	tbz	w11, #0x2, 0x1248 <_llm_rows.packet_batch.blocks+0xe98>
    12a0:      	add	x12, x10, #0x8
    12a4:      	st1.s	{ v5 }[2], [x12]
    12a8:      	tbnz	w11, #0x3, 0x124c <_llm_rows.packet_batch.blocks+0xe9c>
    12ac:      	b	0x1254 <_llm_rows.packet_batch.blocks+0xea4>
    12b0:      	str	s4, [x10, #0x10]
    12b4:      	tbz	w11, #0x5, 0x1274 <_llm_rows.packet_batch.blocks+0xec4>
    12b8:      	add	x12, x10, #0x14
    12bc:      	st1.s	{ v4 }[1], [x12]
    12c0:      	tbz	w11, #0x6, 0x1278 <_llm_rows.packet_batch.blocks+0xec8>
    12c4:      	add	x12, x10, #0x18
    12c8:      	st1.s	{ v4 }[2], [x12]
    12cc:      	tbz	w11, #0x7, 0x11ec <_llm_rows.packet_batch.blocks+0xe3c>
    12d0:      	add	x10, x10, #0x1c
    12d4:      	st1.s	{ v4 }[3], [x10]
    12d8:      	b	0x11ec <_llm_rows.packet_batch.blocks+0xe3c>
    12dc:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
    12e0:      	add	sp, sp, #0x400
    12e4:      	ldp	x29, x30, [sp, #0x60]
    12e8:      	ldp	x20, x19, [sp, #0x50]
    12ec:      	ldp	x22, x21, [sp, #0x40]
    12f0:      	ldp	x24, x23, [sp, #0x30]
    12f4:      	ldp	x26, x25, [sp, #0x20]
    12f8:      	ldp	x28, x27, [sp, #0x10]
    12fc:      	ldp	d9, d8, [sp], #0x70
    1300:      	ret

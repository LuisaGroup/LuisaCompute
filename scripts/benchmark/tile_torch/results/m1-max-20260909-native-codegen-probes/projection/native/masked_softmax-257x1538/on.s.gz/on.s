
/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/masked_softmax-257x1538/on/object/tile_xir_w8_37958_1788936539107113_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0x90]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x26, x25, [sp, #0x40]
      14:      	stp	x24, x23, [sp, #0x50]
      18:      	stp	x22, x21, [sp, #0x60]
      1c:      	stp	x20, x19, [sp, #0x70]
      20:      	stp	x29, x30, [sp, #0x80]
      24:      	sub	sp, sp, #0x7, lsl #12   ; =0x7000
      28:      	sub	sp, sp, #0xed0
      2c:      	add	x21, sp, #0x3, lsl #12  ; =0x3000
      30:      	add	x21, x21, #0x670
      34:      	ldr	x22, [x0]
      38:      	ldr	x19, [x0, #0x30]
      3c:      	ldr	w8, [x1]
      40:      	ldr	w9, [x1, #0x24]
      44:      	add	w8, w9, w8, lsl #5
      48:      	lsr	w23, w8, #3
      4c:      	fmov	s0, w23
      50:      	str	q0, [sp, #0x10]
      54:      	mov	w24, #0x1808            ; =6152
      58:      	umull	x20, w23, w24
      5c:      	umaddl	x1, w23, w24, x22
      60:      	mov	w25, #0x1800            ; =6144
      64:      	add	x0, sp, #0x6, lsl #12   ; =0x6000
      68:      	add	x0, x0, #0x6b0
      6c:      	mov	w2, #0x1800             ; =6144
      70:      	bl	0x70 <ltmp0+0x70>
      74:      	mov	x9, #0x0                ; =0
      78:      	umaddl	x8, w23, w24, x25
      7c:      	add	x10, x22, x8
      80:      	add	x11, x10, #0x4
      84:      	ldr	s5, [x10]
      88:      	ld1.s	{ v5 }[1], [x11]
      8c:      	str	q5, [x21, #0x4840]
      90:      	movi.2d	v1, #0000000000000000
      94:      	adrp	x10, 0x0 <ltmp0>
      98:      	ldr	q0, [x10]
      9c:      	adrp	x10, 0x0 <ltmp0>
      a0:      	ldr	q2, [x10]
      a4:      	adrp	x10, 0x0 <ltmp0>
      a8:      	ldr	q3, [x10]
      ac:      	adrp	x10, 0x0 <ltmp0>
      b0:      	ldr	q4, [x10]
      b4:      	mov	w10, #0x1               ; =1
      b8:      	dup.2d	v6, x10
      bc:      	movi.2d	v7, #0000000000000000
      c0:      	movi.2d	v16, #0000000000000000
      c4:      	movi.2d	v17, #0000000000000000
      c8:      	shl.2d	v18, v1, #0x3
      cc:      	shl.2d	v19, v7, #0x3
      d0:      	shl.2d	v20, v16, #0x3
      d4:      	shl.2d	v21, v17, #0x3
      d8:      	orr.16b	v21, v21, v0
      dc:      	orr.16b	v20, v20, v2
      e0:      	orr.16b	v19, v19, v3
      e4:      	orr.16b	v18, v18, v4
      e8:      	add	x9, x21, x9, lsl #6
      ec:      	stp	q18, q19, [x9]
      f0:      	stp	q20, q21, [x9, #0x20]
      f4:      	add.2d	v16, v16, v6
      f8:      	add.2d	v7, v7, v6
      fc:      	add.2d	v18, v1, v6
     100:      	add.2d	v17, v17, v6
     104:      	fmov	x9, d1
     108:      	add	x9, x9, #0x1
     10c:      	mov.16b	v1, v18
     110:      	cmp	x9, #0xc0
     114:      	b.lt	0xc8 <ltmp0+0xc8>
     118:      	mov	x10, #0x0               ; =0
     11c:      	adrp	x9, 0x0 <ltmp0>
     120:      	ldr	q0, [x9]
     124:      	str	q0, [x21, #0x3000]
     128:      	mov	w9, #0xda0d             ; =55821
     12c:      	movk	w9, #0xaa71, lsl #16
     130:      	fmov	s0, w9
     134:      	ldr	q2, [sp, #0x10]
     138:      	umull2.2d	v1, v2, v0
     13c:      	umull.2d	v0, v2, v0
     140:      	uzp2.4s	v0, v0, v1
     144:      	ushr.4s	v0, v0, #0xa
     148:      	mov	w9, #0x602              ; =1538
     14c:      	fmov	s1, w9
     150:      	mls.4s	v2, v0, v1
     154:      	dup.4s	v7, v2[0]
     158:      	ushll2.2d	v4, v7, #0x0
     15c:      	ushll.2d	v6, v7, #0x0
     160:      	movi.2d	v16, #0000000000000000
     164:      	add	x9, sp, #0x3, lsl #12   ; =0x3000
     168:      	add	x9, x9, #0x68
     16c:      	dup.2d	v17, x9
     170:      	adrp	x9, 0x0 <ltmp0>
     174:      	ldr	q0, [x9]
     178:      	adrp	x9, 0x0 <ltmp0>
     17c:      	ldr	q1, [x9]
     180:      	adrp	x9, 0x0 <ltmp0>
     184:      	ldr	q2, [x9]
     188:      	mov	w9, #0x1                ; =1
     18c:      	dup.2d	v18, x9
     190:      	adrp	x9, 0x0 <ltmp0>
     194:      	ldr	q3, [x9]
     198:      	add	x9, sp, #0x3, lsl #12   ; =0x3000
     19c:      	add	x9, x9, #0x670
     1a0:      	movi.8b	v19, #0x1
     1a4:      	movi.2d	v20, #0000000000000000
     1a8:      	movi.2d	v21, #0000000000000000
     1ac:      	movi.2d	v22, #0000000000000000
     1b0:      	add	x10, x9, x10, lsl #6
     1b4:      	ldp	q24, q23, [x10, #0x20]
     1b8:      	ldp	q25, q26, [x10]
     1bc:      	add.2d	v27, v22, v3
     1c0:      	add.2d	v28, v20, v1
     1c4:      	add.2d	v28, v28, v17
     1c8:      	add.2d	v29, v16, v0
     1cc:      	add.2d	v29, v29, v17
     1d0:      	cmge.2d	v26, v4, v26
     1d4:      	cmge.2d	v25, v6, v25
     1d8:      	uzp1.4s	v25, v25, v26
     1dc:      	cmge.2d	v24, v6, v24
     1e0:      	cmge.2d	v23, v4, v23
     1e4:      	uzp1.4s	v23, v24, v23
     1e8:      	uzp1.8h	v23, v25, v23
     1ec:      	xtn.8b	v23, v23
     1f0:      	and.8b	v23, v23, v19
     1f4:      	mov.d	x10, v29[1]
     1f8:      	fmov	x11, d29
     1fc:      	str	b23, [x11]
     200:      	st1.b	{ v23 }[1], [x10]
     204:      	mov.d	x10, v28[1]
     208:      	add.2d	v24, v21, v2
     20c:      	fmov	x11, d28
     210:      	st1.b	{ v23 }[2], [x11]
     214:      	st1.b	{ v23 }[3], [x10]
     218:      	add.2d	v24, v24, v17
     21c:      	mov.d	x10, v24[1]
     220:      	fmov	x11, d24
     224:      	st1.b	{ v23 }[4], [x11]
     228:      	add.2d	v24, v27, v17
     22c:      	st1.b	{ v23 }[5], [x10]
     230:      	mov.d	x10, v24[1]
     234:      	fmov	x11, d24
     238:      	st1.b	{ v23 }[6], [x11]
     23c:      	st1.b	{ v23 }[7], [x10]
     240:      	add.2d	v21, v21, v18
     244:      	add.2d	v20, v20, v18
     248:      	add.2d	v23, v16, v18
     24c:      	add.2d	v22, v22, v18
     250:      	fmov	x10, d16
     254:      	add	x10, x10, #0x1
     258:      	mov.16b	v16, v23
     25c:      	cmp	x10, #0xc0
     260:      	b.lt	0x1b0 <ltmp0+0x1b0>
     264:      	mov	x10, #0x0               ; =0
     268:      	adrp	x9, 0x0 <ltmp0>
     26c:      	ldr	q16, [x9]
     270:      	add	x9, sp, #0x3, lsl #12   ; =0x3000
     274:      	add	x9, x9, #0x68
     278:      	dup.2d	v4, x9
     27c:      	adrp	x9, 0x0 <ltmp0>
     280:      	ldr	q6, [x9]
     284:      	add.2d	v6, v4, v6
     288:      	cmhs.4s	v7, v7, v16
     28c:      	xtn.4h	v7, v7
     290:      	uzp1.8b	v7, v7, v0
     294:      	movi.8b	v16, #0x1
     298:      	and.8b	v7, v7, v16
     29c:      	fmov	x9, d6
     2a0:      	str	b7, [x9]
     2a4:      	mov.d	x9, v6[1]
     2a8:      	st1.b	{ v7 }[1], [x9]
     2ac:      	movi.2d	v7, #0000000000000000
     2b0:      	add	x11, sp, #0x6, lsl #12  ; =0x6000
     2b4:      	add	x11, x11, #0x6b0
     2b8:      	mov	w12, #0xf2ca            ; =62154
     2bc:      	movk	w12, #0xf149, lsl #16
     2c0:      	dup.4s	v16, w12
     2c4:      	mov	w12, #0x1               ; =1
     2c8:      	dup.2d	v17, x12
     2cc:      	add	x12, sp, #0x1, lsl #12  ; =0x1000
     2d0:      	add	x12, x12, #0x848
     2d4:      	movi.2d	v18, #0000000000000000
     2d8:      	movi.2d	v19, #0000000000000000
     2dc:      	movi.2d	v20, #0000000000000000
     2e0:      	add.2d	v21, v20, v3
     2e4:      	add.2d	v22, v19, v2
     2e8:      	add.2d	v21, v21, v4
     2ec:      	add.2d	v23, v18, v1
     2f0:      	add.2d	v24, v7, v0
     2f4:      	add.2d	v24, v24, v4
     2f8:      	mov.d	x13, v24[1]
     2fc:      	add.2d	v22, v22, v4
     300:      	add.2d	v23, v23, v4
     304:      	fmov	x14, d24
     308:      	mov.d	x15, v23[1]
     30c:      	mov.d	x16, v22[1]
     310:      	fmov	x17, d23
     314:      	ldr	b23, [x14]
     318:      	ld1.b	{ v23 }[1], [x13]
     31c:      	mov.d	x13, v21[1]
     320:      	fmov	x14, d22
     324:      	ld1.b	{ v23 }[2], [x17]
     328:      	ld1.b	{ v23 }[3], [x15]
     32c:      	fmov	x15, d21
     330:      	ld1.b	{ v23 }[4], [x14]
     334:      	ld1.b	{ v23 }[5], [x16]
     338:      	ld1.b	{ v23 }[6], [x15]
     33c:      	ld1.b	{ v23 }[7], [x13]
     340:      	cmeq.8b	v21, v23, #0
     344:      	sshll.8h	v21, v21, #0x0
     348:      	sshll2.4s	v22, v21, #0x0
     34c:      	sshll.4s	v21, v21, #0x0
     350:      	lsl	x10, x10, #5
     354:      	add	x13, x11, x10
     358:      	ldp	q24, q23, [x13]
     35c:      	bsl.16b	v21, v16, v24
     360:      	bsl.16b	v22, v16, v23
     364:      	add	x10, x12, x10
     368:      	add.2d	v19, v19, v17
     36c:      	add.2d	v18, v18, v17
     370:      	stp	q21, q22, [x10]
     374:      	add.2d	v21, v7, v17
     378:      	add.2d	v20, v20, v17
     37c:      	fmov	x10, d7
     380:      	add	x10, x10, #0x1
     384:      	mov.16b	v7, v21
     388:      	cmp	x10, #0xc0
     38c:      	b.lt	0x2e0 <ltmp0+0x2e0>
     390:      	fmov	x10, d6
     394:      	ldr	b4, [x10]
     398:      	ld1.b	{ v4 }[1], [x9]
     39c:      	cmeq.8b	v4, v4, #0
     3a0:      	sshll.8h	v4, v4, #0x0
     3a4:      	mov	w9, #0xf2ca             ; =62154
     3a8:      	movk	w9, #0xf149, lsl #16
     3ac:      	dup.4s	v6, w9
     3b0:      	str	q4, [sp, #0x10]
     3b4:      	sshll.4s	v7, v4, #0x0
     3b8:      	bif.16b	v6, v5, v7
     3bc:      	add	x9, sp, #0x2, lsl #12   ; =0x2000
     3c0:      	add	x9, x9, #0xf49
     3c4:      	ldur	q7, [x9, #0xff]
     3c8:      	mov.16b	v5, v6
     3cc:      	mov.d	v5[1], v7[1]
     3d0:      	add	x9, sp, #0x2, lsl #12   ; =0x2000
     3d4:      	add	x9, x9, #0xf49
     3d8:      	stur	q5, [x9, #0xff]
     3dc:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     3e0:      	add	x9, x9, #0x759
     3e4:      	ldur	q7, [x9, #0xff]
     3e8:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     3ec:      	add	x9, x9, #0x749
     3f0:      	ldur	q21, [x9, #0xff]
     3f4:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     3f8:      	add	x9, x9, #0x779
     3fc:      	ldur	q20, [x9, #0xff]
     400:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     404:      	add	x9, x9, #0x769
     408:      	ldur	q19, [x9, #0xff]
     40c:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     410:      	add	x9, x9, #0x799
     414:      	ldur	q16, [x9, #0xff]
     418:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     41c:      	add	x9, x9, #0x789
     420:      	ldur	q22, [x9, #0xff]
     424:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     428:      	add	x9, x9, #0x7b9
     42c:      	ldur	q18, [x9, #0xff]
     430:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     434:      	add	x9, x9, #0x7a9
     438:      	ldur	q17, [x9, #0xff]
     43c:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     440:      	add	x9, x9, #0x848
     444:      	add	x9, x9, #0xe0
     448:      	mov	w10, #0x4               ; =4
     44c:      	ldp	q23, q24, [x9, #-0x60]
     450:      	fmaxnm.4s	v7, v7, v24
     454:      	fmaxnm.4s	v21, v21, v23
     458:      	ldp	q23, q24, [x9, #-0x40]
     45c:      	fmaxnm.4s	v20, v20, v24
     460:      	fmaxnm.4s	v19, v19, v23
     464:      	ldp	q23, q24, [x9, #-0x20]
     468:      	fmaxnm.4s	v16, v16, v24
     46c:      	fmaxnm.4s	v22, v22, v23
     470:      	ldp	q23, q24, [x9], #0x80
     474:      	fmaxnm.4s	v18, v18, v24
     478:      	fmaxnm.4s	v17, v17, v23
     47c:      	cmp	x10, #0xbc
     480:      	add	x10, x10, #0x4
     484:      	b.lo	0x44c <ltmp0+0x44c>
     488:      	mov	x1, #0x0                ; =0
     48c:      	movi.2d	v23, #0000000000000000
     490:      	mov.d	v23[0], v6[0]
     494:      	fmaxnm.4s	v6, v21, v23
     498:      	mov.d	v6[1], v21[1]
     49c:      	fmaxnm.4s	v7, v7, v20
     4a0:      	fmaxnm.4s	v6, v6, v19
     4a4:      	fmaxnm.4s	v6, v6, v22
     4a8:      	fmaxnm.4s	v7, v7, v16
     4ac:      	fmaxnm.4s	v7, v7, v18
     4b0:      	fmaxnm.4s	v6, v6, v17
     4b4:      	rev64.4s	v16, v6
     4b8:      	rev64.4s	v17, v7
     4bc:      	fmaxnm.4s	v7, v7, v17
     4c0:      	fmaxnm.4s	v6, v6, v16
     4c4:      	ext.16b	v16, v6, v6, #0x8
     4c8:      	ext.16b	v17, v7, v7, #0x8
     4cc:      	fmaxnm.4s	v7, v7, v17
     4d0:      	fmaxnm.4s	v6, v6, v16
     4d4:      	fmaxnm.4s	v6, v6, v7
     4d8:      	mov	w9, #-0x800000          ; =-8388608
     4dc:      	fmov	s7, w9
     4e0:      	fmaxnm	s4, s6, s7
     4e4:      	str	q4, [sp]
     4e8:      	dup.4s	v7, v4[0]
     4ec:      	add	x9, sp, #0x3, lsl #12   ; =0x3000
     4f0:      	add	x9, x9, #0x68
     4f4:      	dup.2d	v16, x9
     4f8:      	movi.2d	v19, #0000000000000000
     4fc:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     500:      	add	x9, x9, #0x848
     504:      	mov	w10, #-0x3d300000       ; =-1026555904
     508:      	dup.4s	v17, w10
     50c:      	mov	w10, #0x42c80000        ; =1120403456
     510:      	dup.4s	v18, w10
     514:      	mov	w10, #0xaa3b            ; =43579
     518:      	movk	w10, #0x3fb8, lsl #16
     51c:      	dup.4s	v20, w10
     520:      	movi.4s	v21, #0x4b, lsl #24
     524:      	mvni.4s	v22, #0x80, lsl #24
     528:      	mov	w10, #0x7200            ; =29184
     52c:      	movk	w10, #0xbf31, lsl #16
     530:      	mov	w11, #0xbe8e            ; =48782
     534:      	movk	w11, #0xb5bf, lsl #16
     538:      	mov	w12, #0x2bda            ; =11226
     53c:      	movk	w12, #0x3950, lsl #16
     540:      	mov	w13, #0x96c9            ; =38601
     544:      	movk	w13, #0x3ab6, lsl #16
     548:      	mov	w14, #0x88a6            ; =34982
     54c:      	movk	w14, #0x3c08, lsl #16
     550:      	mov	w15, #0xaa7a            ; =43642
     554:      	movk	w15, #0x3d2a, lsl #16
     558:      	mov	w16, #0xaaab            ; =43691
     55c:      	movk	w16, #0x3e2a, lsl #16
     560:      	movi.4s	v23, #0x3f, lsl #24
     564:      	mvni.4s	v24, #0x7f, msl #16
     568:      	fneg.4s	v24, v24
     56c:      	mvni.4s	v25, #0x3f, msl #16
     570:      	fneg.4s	v25, v25
     574:      	add	x17, sp, #0x28
     578:      	mov	w0, #0x1                ; =1
     57c:      	movi.2d	v26, #0000000000000000
     580:      	movi.2d	v27, #0000000000000000
     584:      	movi.2d	v28, #0000000000000000
     588:      	add.2d	v29, v28, v3
     58c:      	add.2d	v30, v27, v2
     590:      	add.2d	v29, v29, v16
     594:      	add.2d	v30, v30, v16
     598:      	add.2d	v31, v26, v1
     59c:      	add.2d	v8, v19, v0
     5a0:      	add.2d	v8, v8, v16
     5a4:      	mov.d	x2, v8[1]
     5a8:      	add.2d	v31, v31, v16
     5ac:      	fmov	x3, d8
     5b0:      	mov.d	x4, v31[1]
     5b4:      	mov.d	x5, v30[1]
     5b8:      	fmov	x6, d31
     5bc:      	fmov	x7, d30
     5c0:      	mov.d	x21, v29[1]
     5c4:      	fmov	x22, d29
     5c8:      	ldr	b29, [x3]
     5cc:      	ld1.b	{ v29 }[1], [x2]
     5d0:      	ld1.b	{ v29 }[2], [x6]
     5d4:      	ld1.b	{ v29 }[3], [x4]
     5d8:      	ld1.b	{ v29 }[4], [x7]
     5dc:      	lsl	x1, x1, #5
     5e0:      	add	x2, x9, x1
     5e4:      	ld1.b	{ v29 }[5], [x5]
     5e8:      	ldp	q31, q30, [x2]
     5ec:      	fsub.4s	v30, v30, v7
     5f0:      	fsub.4s	v31, v31, v7
     5f4:      	ld1.b	{ v29 }[6], [x22]
     5f8:      	fcmge.4s	v8, v31, v17
     5fc:      	fcmge.4s	v9, v30, v17
     600:      	fcmge.4s	v10, v18, v31
     604:      	fcmge.4s	v11, v18, v30
     608:      	ld1.b	{ v29 }[7], [x21]
     60c:      	and.16b	v9, v9, v11
     610:      	and.16b	v8, v8, v10
     614:      	and.16b	v11, v8, v31
     618:      	and.16b	v12, v9, v30
     61c:      	fmul.4s	v8, v12, v20
     620:      	cmeq.8b	v29, v29, #0
     624:      	fmul.4s	v9, v11, v20
     628:      	mov.16b	v10, v22
     62c:      	bsl.16b	v10, v21, v9
     630:      	mov.16b	v13, v22
     634:      	bsl.16b	v13, v21, v8
     638:      	fadd.4s	v8, v8, v13
     63c:      	fadd.4s	v9, v9, v10
     640:      	sshll.8h	v29, v29, #0x0
     644:      	fsub.4s	v10, v9, v10
     648:      	fsub.4s	v8, v8, v13
     64c:      	fcvtzs.4s	v9, v8
     650:      	fcvtzs.4s	v10, v10
     654:      	scvtf.4s	v13, v10
     658:      	sshll2.4s	v8, v29, #0x0
     65c:      	scvtf.4s	v14, v9
     660:      	dup.4s	v15, w10
     664:      	fmul.4s	v4, v14, v15
     668:      	fmul.4s	v15, v13, v15
     66c:      	fadd.4s	v11, v11, v15
     670:      	fadd.4s	v4, v12, v4
     674:      	dup.4s	v12, w11
     678:      	fmul.4s	v13, v13, v12
     67c:      	fmul.4s	v12, v14, v12
     680:      	fadd.4s	v4, v4, v12
     684:      	fadd.4s	v11, v11, v13
     688:      	dup.4s	v12, w12
     68c:      	dup.4s	v13, w13
     690:      	fmul.4s	v14, v11, v12
     694:      	fmul.4s	v12, v4, v12
     698:      	fadd.4s	v12, v12, v13
     69c:      	fadd.4s	v13, v14, v13
     6a0:      	dup.4s	v14, w14
     6a4:      	fmul.4s	v13, v11, v13
     6a8:      	fmul.4s	v12, v4, v12
     6ac:      	fadd.4s	v12, v12, v14
     6b0:      	fadd.4s	v13, v13, v14
     6b4:      	dup.4s	v14, w15
     6b8:      	fmul.4s	v13, v11, v13
     6bc:      	fmul.4s	v12, v4, v12
     6c0:      	fadd.4s	v12, v12, v14
     6c4:      	fadd.4s	v13, v13, v14
     6c8:      	dup.4s	v14, w16
     6cc:      	fmul.4s	v13, v11, v13
     6d0:      	fmul.4s	v12, v4, v12
     6d4:      	fadd.4s	v12, v12, v14
     6d8:      	fadd.4s	v13, v13, v14
     6dc:      	fmul.4s	v13, v11, v13
     6e0:      	fmul.4s	v12, v4, v12
     6e4:      	fadd.4s	v12, v12, v23
     6e8:      	fadd.4s	v13, v13, v23
     6ec:      	fmul.4s	v14, v4, v4
     6f0:      	fmul.4s	v15, v11, v11
     6f4:      	fmul.4s	v13, v15, v13
     6f8:      	fmul.4s	v12, v14, v12
     6fc:      	sshll.4s	v14, v29, #0x0
     700:      	fadd.4s	v4, v4, v12
     704:      	fadd.4s	v11, v11, v13
     708:      	fmov.4s	v29, #1.00000000
     70c:      	fadd.4s	v11, v11, v29
     710:      	sshr.4s	v12, v10, #0x1
     714:      	fadd.4s	v4, v4, v29
     718:      	sshr.4s	v13, v9, #0x1
     71c:      	shl.4s	v15, v13, #0x17
     720:      	shl.4s	v6, v12, #0x17
     724:      	add.4s	v6, v6, v29
     728:      	add.4s	v15, v15, v29
     72c:      	fmul.4s	v4, v4, v15
     730:      	sub.4s	v9, v9, v13
     734:      	sub.4s	v10, v10, v12
     738:      	shl.4s	v10, v10, #0x17
     73c:      	shl.4s	v9, v9, #0x17
     740:      	add.4s	v9, v9, v29
     744:      	fmul.4s	v6, v11, v6
     748:      	add.4s	v10, v10, v29
     74c:      	fmul.4s	v6, v6, v10
     750:      	fmul.4s	v4, v4, v9
     754:      	fcmgt.4s	v9, v17, v30
     758:      	fcmgt.4s	v10, v17, v31
     75c:      	bic.16b	v4, v4, v9
     760:      	bic.16b	v6, v6, v10
     764:      	fcmgt.4s	v9, v30, v18
     768:      	fcmgt.4s	v10, v31, v18
     76c:      	bit.16b	v6, v24, v10
     770:      	fcmeq.4s	v31, v31, v31
     774:      	bit.16b	v4, v24, v9
     778:      	fcmeq.4s	v30, v30, v30
     77c:      	bif.16b	v4, v25, v30
     780:      	bif.16b	v6, v25, v31
     784:      	bic.16b	v6, v6, v14
     788:      	add	x1, x17, x1
     78c:      	bic.16b	v4, v4, v8
     790:      	dup.2d	v30, x0
     794:      	add.2d	v27, v27, v30
     798:      	add.2d	v26, v26, v30
     79c:      	stp	q6, q4, [x1]
     7a0:      	add.2d	v4, v19, v30
     7a4:      	add.2d	v28, v28, v30
     7a8:      	fmov	x1, d19
     7ac:      	add	x1, x1, #0x1
     7b0:      	mov.16b	v19, v4
     7b4:      	cmp	x1, #0xc0
     7b8:      	b.lt	0x588 <ltmp0+0x588>
     7bc:      	ldr	q0, [sp]
     7c0:      	dup.4s	v0, v0[0]
     7c4:      	fsub.4s	v0, v5, v0
     7c8:      	movi.2d	v1, #0000000000000000
     7cc:      	mov.d	v1[0], v0[0]
     7d0:      	ldr	q0, [sp, #0x10]
     7d4:      	sshll.4s	v0, v0, #0x0
     7d8:      	mov	w9, #-0x3d300000        ; =-1026555904
     7dc:      	dup.4s	v2, w9
     7e0:      	fcmge.4s	v3, v1, v2
     7e4:      	mov	w9, #0x42c80000         ; =1120403456
     7e8:      	dup.4s	v4, w9
     7ec:      	fcmge.4s	v5, v4, v1
     7f0:      	and.16b	v3, v3, v5
     7f4:      	and.16b	v3, v3, v1
     7f8:      	mov	w9, #0xaa3b             ; =43579
     7fc:      	movk	w9, #0x3fb8, lsl #16
     800:      	dup.4s	v5, w9
     804:      	fmul.4s	v5, v3, v5
     808:      	movi.4s	v6, #0x4b, lsl #24
     80c:      	mvni.4s	v7, #0x80, lsl #24
     810:      	bif.16b	v6, v5, v7
     814:      	fadd.4s	v5, v5, v6
     818:      	fsub.4s	v5, v5, v6
     81c:      	fcvtzs.4s	v5, v5
     820:      	mov	w9, #0x7200             ; =29184
     824:      	movk	w9, #0xbf31, lsl #16
     828:      	dup.4s	v6, w9
     82c:      	scvtf.4s	v7, v5
     830:      	fmul.4s	v6, v7, v6
     834:      	fadd.4s	v3, v3, v6
     838:      	mov	w9, #0xbe8e             ; =48782
     83c:      	movk	w9, #0xb5bf, lsl #16
     840:      	dup.4s	v6, w9
     844:      	fmul.4s	v6, v7, v6
     848:      	fadd.4s	v3, v3, v6
     84c:      	mov	w9, #0x2bda             ; =11226
     850:      	movk	w9, #0x3950, lsl #16
     854:      	dup.4s	v6, w9
     858:      	fmul.4s	v6, v3, v6
     85c:      	mov	w9, #0x96c9             ; =38601
     860:      	movk	w9, #0x3ab6, lsl #16
     864:      	dup.4s	v7, w9
     868:      	fadd.4s	v6, v6, v7
     86c:      	fmul.4s	v6, v3, v6
     870:      	mov	w9, #0x88a6             ; =34982
     874:      	movk	w9, #0x3c08, lsl #16
     878:      	dup.4s	v7, w9
     87c:      	fadd.4s	v6, v6, v7
     880:      	mov	w9, #0xaa7a             ; =43642
     884:      	movk	w9, #0x3d2a, lsl #16
     888:      	dup.4s	v7, w9
     88c:      	fmul.4s	v6, v3, v6
     890:      	fadd.4s	v6, v6, v7
     894:      	fmul.4s	v6, v3, v6
     898:      	mov	w9, #0xaaab             ; =43691
     89c:      	movk	w9, #0x3e2a, lsl #16
     8a0:      	dup.4s	v7, w9
     8a4:      	fadd.4s	v6, v6, v7
     8a8:      	fmul.4s	v6, v3, v6
     8ac:      	movi.4s	v7, #0x3f, lsl #24
     8b0:      	fadd.4s	v6, v6, v7
     8b4:      	fmul.4s	v7, v3, v3
     8b8:      	fmul.4s	v6, v7, v6
     8bc:      	fadd.4s	v3, v3, v6
     8c0:      	fadd.4s	v3, v3, v29
     8c4:      	sshr.4s	v6, v5, #0x1
     8c8:      	shl.4s	v7, v6, #0x17
     8cc:      	add.4s	v7, v7, v29
     8d0:      	fmul.4s	v3, v3, v7
     8d4:      	sub.4s	v5, v5, v6
     8d8:      	shl.4s	v5, v5, #0x17
     8dc:      	add.4s	v5, v5, v29
     8e0:      	fmul.4s	v3, v3, v5
     8e4:      	fcmgt.4s	v2, v2, v1
     8e8:      	bic.16b	v2, v3, v2
     8ec:      	fcmgt.4s	v3, v1, v4
     8f0:      	mvni.4s	v4, #0x7f, msl #16
     8f4:      	fneg.4s	v4, v4
     8f8:      	bit.16b	v2, v4, v3
     8fc:      	fcmeq.4s	v1, v1, v1
     900:      	mvni.4s	v3, #0x3f, msl #16
     904:      	fneg.4s	v3, v3
     908:      	bsl.16b	v1, v2, v3
     90c:      	bic.16b	v0, v1, v0
     910:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     914:      	add	x9, x9, #0x729
     918:      	ldur	q1, [x9, #0xff]
     91c:      	mov.d	v0[1], v1[1]
     920:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     924:      	add	x9, x9, #0x729
     928:      	stur	q0, [x9, #0xff]
     92c:      	ldur	q1, [sp, #0x38]
     930:      	ldur	q7, [sp, #0x28]
     934:      	ldur	q6, [sp, #0x58]
     938:      	ldur	q5, [sp, #0x48]
     93c:      	ldur	q2, [sp, #0x78]
     940:      	ldur	q16, [sp, #0x68]
     944:      	ldur	q4, [sp, #0x98]
     948:      	ldur	q3, [sp, #0x88]
     94c:      	add	x9, sp, #0x28
     950:      	add	x9, x9, #0xe0
     954:      	mov	w10, #0x4               ; =4
     958:      	ldp	q17, q18, [x9, #-0x60]
     95c:      	fadd.4s	v1, v1, v18
     960:      	fadd.4s	v7, v7, v17
     964:      	ldp	q17, q18, [x9, #-0x40]
     968:      	fadd.4s	v6, v6, v18
     96c:      	fadd.4s	v5, v5, v17
     970:      	ldp	q17, q18, [x9, #-0x20]
     974:      	fadd.4s	v2, v2, v18
     978:      	fadd.4s	v16, v16, v17
     97c:      	ldp	q17, q18, [x9], #0x80
     980:      	fadd.4s	v4, v4, v18
     984:      	fadd.4s	v3, v3, v17
     988:      	cmp	x10, #0xbc
     98c:      	add	x10, x10, #0x4
     990:      	b.lo	0x958 <ltmp0+0x958>
     994:      	mov	x9, #0x0                ; =0
     998:      	fadd.4s	v17, v0, v7
     99c:      	mov.d	v17[1], v7[1]
     9a0:      	fadd.4s	v1, v6, v1
     9a4:      	fadd.4s	v5, v5, v17
     9a8:      	fadd.4s	v5, v16, v5
     9ac:      	fadd.4s	v1, v2, v1
     9b0:      	fadd.4s	v1, v4, v1
     9b4:      	fadd.4s	v2, v3, v5
     9b8:      	rev64.4s	v3, v2
     9bc:      	rev64.4s	v4, v1
     9c0:      	fadd.4s	v2, v2, v3
     9c4:      	dup.4s	v3, v2[2]
     9c8:      	fadd.4s	v1, v1, v4
     9cc:      	dup.4s	v4, v1[2]
     9d0:      	fadd.4s	v1, v1, v4
     9d4:      	fadd.4s	v2, v2, v3
     9d8:      	fadd.4s	v1, v2, v1
     9dc:      	movi	d2, #0000000000000000
     9e0:      	fadd	s1, s1, s2
     9e4:      	dup.4s	v2, v1[0]
     9e8:      	add	x10, x19, x20
     9ec:      	add	x11, sp, #0x28
     9f0:      	lsl	x12, x9, #5
     9f4:      	add	x13, x11, x12
     9f8:      	ldp	q4, q3, [x13]
     9fc:      	fdiv.4s	v4, v4, v2
     a00:      	fdiv.4s	v3, v3, v2
     a04:      	add	x12, x10, x12
     a08:      	stp	q4, q3, [x12]
     a0c:      	add	x9, x9, #0x1
     a10:      	cmp	x9, #0xc0
     a14:      	b.ne	0x9f0 <ltmp0+0x9f0>
     a18:      	dup.2s	v1, v1[0]
     a1c:      	fdiv.2s	v0, v0, v1
     a20:      	str	d0, [x19, x8]
     a24:      	add	sp, sp, #0x7, lsl #12   ; =0x7000
     a28:      	add	sp, sp, #0xed0
     a2c:      	ldp	x29, x30, [sp, #0x80]
     a30:      	ldp	x20, x19, [sp, #0x70]
     a34:      	ldp	x22, x21, [sp, #0x60]
     a38:      	ldp	x24, x23, [sp, #0x50]
     a3c:      	ldp	x26, x25, [sp, #0x40]
     a40:      	ldp	d9, d8, [sp, #0x30]
     a44:      	ldp	d11, d10, [sp, #0x20]
     a48:      	ldp	d13, d12, [sp, #0x10]
     a4c:      	ldp	d15, d14, [sp], #0x90
     a50:      	ret

0000000000000a54 <_llm_rows.packet_batch.blocks>:
     a54:      	stp	d15, d14, [sp, #-0xa0]!
     a58:      	stp	d13, d12, [sp, #0x10]
     a5c:      	stp	d11, d10, [sp, #0x20]
     a60:      	stp	d9, d8, [sp, #0x30]
     a64:      	stp	x28, x27, [sp, #0x40]
     a68:      	stp	x26, x25, [sp, #0x50]
     a6c:      	stp	x24, x23, [sp, #0x60]
     a70:      	stp	x22, x21, [sp, #0x70]
     a74:      	stp	x20, x19, [sp, #0x80]
     a78:      	stp	x29, x30, [sp, #0x90]
     a7c:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
     a80:      	sub	sp, sp, #0x770
     a84:      	str	x0, [sp, #0x1d0]
     a88:      	cbz	w3, 0x2a84 <_llm_rows.packet_batch.blocks+0x2030>
     a8c:      	mov	x19, x3
     a90:      	mov	x20, x2
     a94:      	mov	w22, #0x0               ; =0
     a98:      	add	x23, sp, #0x8c8
     a9c:      	add	x8, sp, #0x3, lsl #12   ; =0x3000
     aa0:      	add	x8, x8, #0x908
     aa4:      	dup.2d	v0, x8
     aa8:      	str	q0, [sp, #0x20]
     aac:      	adrp	x8, 0x0 <ltmp0>
     ab0:      	ldr	q0, [x8]
     ab4:      	str	q0, [sp, #0x10]
     ab8:      	adrp	x8, 0x0 <ltmp0>
     abc:      	ldr	q0, [x8]
     ac0:      	str	q0, [sp, #0x140]
     ac4:      	adrp	x8, 0x0 <ltmp0>
     ac8:      	ldr	q0, [x8]
     acc:      	str	q0, [sp, #0x130]
     ad0:      	add	x4, sp, #0x6, lsl #12   ; =0x6000
     ad4:      	add	x4, x4, #0xf50
     ad8:      	adrp	x16, 0x0 <ltmp0>
     adc:      	adrp	x17, 0x0 <ltmp0>
     ae0:      	adrp	x0, 0x0 <ltmp0>
     ae4:      	adrp	x1, 0x0 <ltmp0>
     ae8:      	add	x5, sp, #0x3, lsl #12   ; =0x3000
     aec:      	add	x5, x5, #0xf10
     af0:      	movi.8b	v10, #0x1
     af4:      	mvni.4s	v0, #0x7f, msl #16
     af8:      	fneg.4s	v1, v0
     afc:      	mvni.4s	v0, #0x3f, msl #16
     b00:      	fneg.4s	v0, v0
     b04:      	stp	q0, q1, [sp, #0x220]
     b08:      	ldp	w9, w8, [x2, #0x2c]
     b0c:      	str	w9, [sp, #0x1cc]
     b10:      	str	w8, [sp, #0x1c8]
     b14:      	ldp	w21, w12, [x2]
     b18:      	add	x25, sp, #0x2, lsl #12  ; =0x2000
     b1c:      	add	x25, x25, #0xe8
     b20:      	ldp	w26, w8, [x2, #0x8]
     b24:      	str	x8, [sp, #0x1c0]
     b28:      	str	w3, [sp, #0x38]
     b2c:      	str	x2, [sp, #0x8]
     b30:      	b	0xb7c <_llm_rows.packet_batch.blocks+0x128>
     b34:      	mov	w8, #0x18               ; =24
     b38:      	str	w8, [x20, #0x24]
     b3c:      	add	w8, w21, #0x1
     b40:      	ldr	w9, [sp, #0x1cc]
     b44:      	cmp	w8, w9
     b48:      	cset	w8, eq
     b4c:      	csinc	w21, wzr, w21, eq
     b50:      	ldr	w9, [sp, #0x1dc]
     b54:      	cinc	w9, w9, eq
     b58:      	ldr	w10, [sp, #0x1c8]
     b5c:      	cmp	w9, w10
     b60:      	cset	w10, eq
     b64:      	ands	w8, w8, w10
     b68:      	csel	w12, wzr, w9, ne
     b6c:      	add	w26, w26, w8
     b70:      	add	w22, w22, #0x1
     b74:      	cmp	w22, w19
     b78:      	b.eq	0x2a84 <_llm_rows.packet_batch.blocks+0x2030>
     b7c:      	ubfiz	x8, x21, #5, #32
     b80:      	ldr	x13, [sp, #0x1c0]
     b84:      	cmp	x8, x13
     b88:      	csel	x9, x8, xzr, ls
     b8c:      	subs	x10, x13, x9
     b90:      	cmp	x10, #0x20
     b94:      	mov	w11, #0x20              ; =32
     b98:      	csel	x10, x10, x11, lo
     b9c:      	cmp	x13, x9
     ba0:      	stp	w21, w12, [x20]
     ba4:      	str	w12, [sp, #0x1dc]
     ba8:      	str	w26, [x20, #0x8]
     bac:      	str	wzr, [x20, #0x24]
     bb0:      	ccmp	x8, x13, #0x2, hi
     bb4:      	csel	x28, x10, xzr, ls
     bb8:      	cmp	x28, #0x20
     bbc:      	b.lo	0xc30 <_llm_rows.packet_batch.blocks+0x1dc>
     bc0:      	ldr	x27, [sp, #0x1d0]
     bc4:      	mov	x0, x27
     bc8:      	mov	x1, x20
     bcc:      	bl	0xbcc <_llm_rows.packet_batch.blocks+0x178>
     bd0:      	mov	w8, #0x8                ; =8
     bd4:      	str	w8, [x20, #0x24]
     bd8:      	mov	x0, x27
     bdc:      	mov	x1, x20
     be0:      	bl	0xbe0 <_llm_rows.packet_batch.blocks+0x18c>
     be4:      	mov	w8, #0x10               ; =16
     be8:      	str	w8, [x20, #0x24]
     bec:      	mov	x0, x27
     bf0:      	mov	x1, x20
     bf4:      	bl	0xbf4 <_llm_rows.packet_batch.blocks+0x1a0>
     bf8:      	mov	w8, #0x18               ; =24
     bfc:      	str	w8, [x20, #0x24]
     c00:      	mov	x0, x27
     c04:      	mov	x1, x20
     c08:      	bl	0xc08 <_llm_rows.packet_batch.blocks+0x1b4>
     c0c:      	add	x5, sp, #0x3, lsl #12   ; =0x3000
     c10:      	add	x5, x5, #0xf10
     c14:      	adrp	x1, 0x0 <ltmp0>
     c18:      	adrp	x0, 0x0 <ltmp0>
     c1c:      	adrp	x17, 0x0 <ltmp0>
     c20:      	adrp	x16, 0x0 <ltmp0>
     c24:      	add	x4, sp, #0x6, lsl #12   ; =0x6000
     c28:      	add	x4, x4, #0xf50
     c2c:      	b	0xb3c <_llm_rows.packet_batch.blocks+0xe8>
     c30:      	lsr	x27, x28, #3
     c34:      	cmp	x28, #0x8
     c38:      	b.lo	0xce4 <_llm_rows.packet_batch.blocks+0x290>
     c3c:      	str	wzr, [x20, #0x24]
     c40:      	ldr	x0, [sp, #0x1d0]
     c44:      	mov	x1, x20
     c48:      	bl	0xc48 <_llm_rows.packet_batch.blocks+0x1f4>
     c4c:      	add	x5, sp, #0x3, lsl #12   ; =0x3000
     c50:      	add	x5, x5, #0xf10
     c54:      	adrp	x1, 0x0 <ltmp0>
     c58:      	adrp	x0, 0x0 <ltmp0>
     c5c:      	adrp	x17, 0x0 <ltmp0>
     c60:      	adrp	x16, 0x0 <ltmp0>
     c64:      	add	x4, sp, #0x6, lsl #12   ; =0x6000
     c68:      	add	x4, x4, #0xf50
     c6c:      	cmp	x27, #0x1
     c70:      	b.eq	0xce4 <_llm_rows.packet_batch.blocks+0x290>
     c74:      	mov	w8, #0x8                ; =8
     c78:      	str	w8, [x20, #0x24]
     c7c:      	ldr	x0, [sp, #0x1d0]
     c80:      	mov	x1, x20
     c84:      	bl	0xc84 <_llm_rows.packet_batch.blocks+0x230>
     c88:      	add	x5, sp, #0x3, lsl #12   ; =0x3000
     c8c:      	add	x5, x5, #0xf10
     c90:      	adrp	x1, 0x0 <ltmp0>
     c94:      	adrp	x0, 0x0 <ltmp0>
     c98:      	adrp	x17, 0x0 <ltmp0>
     c9c:      	adrp	x16, 0x0 <ltmp0>
     ca0:      	add	x4, sp, #0x6, lsl #12   ; =0x6000
     ca4:      	add	x4, x4, #0xf50
     ca8:      	cmp	x27, #0x2
     cac:      	b.eq	0xce4 <_llm_rows.packet_batch.blocks+0x290>
     cb0:      	mov	w8, #0x10               ; =16
     cb4:      	str	w8, [x20, #0x24]
     cb8:      	ldr	x0, [sp, #0x1d0]
     cbc:      	mov	x1, x20
     cc0:      	bl	0xcc0 <_llm_rows.packet_batch.blocks+0x26c>
     cc4:      	add	x5, sp, #0x3, lsl #12   ; =0x3000
     cc8:      	add	x5, x5, #0xf10
     ccc:      	adrp	x1, 0x0 <ltmp0>
     cd0:      	adrp	x0, 0x0 <ltmp0>
     cd4:      	adrp	x17, 0x0 <ltmp0>
     cd8:      	adrp	x16, 0x0 <ltmp0>
     cdc:      	add	x4, sp, #0x6, lsl #12   ; =0x6000
     ce0:      	add	x4, x4, #0xf50
     ce4:      	and	w8, w28, #0x7
     ce8:      	cbz	w8, 0xb34 <_llm_rows.packet_batch.blocks+0xe0>
     cec:      	dup.4s	v5, w8
     cf0:      	ldp	q0, q1, [sp, #0x130]
     cf4:      	cmhi.4s	v0, v5, v0
     cf8:      	cmhi.4s	v1, v5, v1
     cfc:      	uzp1.8h	v3, v1, v0
     d00:      	umaxv.8h	h2, v3
     d04:      	fmov	w8, s2
     d08:      	tbz	w8, #0x0, 0xb34 <_llm_rows.packet_batch.blocks+0xe0>
     d0c:      	mov	x8, #0x0                ; =0
     d10:      	ldr	x10, [sp, #0x1d0]
     d14:      	ldr	x9, [x10]
     d18:      	ldr	x10, [x10, #0x30]
     d1c:      	str	x10, [sp, #0x120]
     d20:      	ldr	q2, [sp, #0x10]
     d24:      	and.16b	v2, v3, v2
     d28:      	addv.8h	h31, v2
     d2c:      	fmov	w10, s31
     d30:      	and	w10, w10, #0xff
     d34:      	str	w10, [sp, #0xb8]
     d38:      	xtn.4h	v2, v1
     d3c:      	uzp1.8b	v2, v2, v0
     d40:      	ubfiz	w10, w21, #2, #27
     d44:      	orr	w11, w10, w27
     d48:      	dup.4s	v4, w11
     d4c:      	and.16b	v6, v1, v4
     d50:      	and.16b	v7, v0, v4
     d54:      	ushll2.2d	v16, v7, #0x0
     d58:      	ushll2.2d	v17, v6, #0x0
     d5c:      	ushll.2d	v18, v7, #0x0
     d60:      	umov.b	w10, v2[0]
     d64:      	ushll.2d	v19, v6, #0x0
     d68:      	mov	w12, #0x1808            ; =6152
     d6c:      	umull	x11, w11, w12
     d70:      	tst	w10, #0x1
     d74:      	csel	x11, x11, xzr, ne
     d78:      	str	x11, [sp, #0x118]
     d7c:      	add	x11, x9, x11
     d80:      	fmov	w12, s31
     d84:      	b	0xda8 <_llm_rows.packet_batch.blocks+0x354>
     d88:      	add	x13, x4, x8, lsl #5
     d8c:      	ldp	q20, q21, [x13]
     d90:      	bif.16b	v4, v21, v0
     d94:      	bif.16b	v2, v20, v1
     d98:      	stp	q2, q4, [x13]
     d9c:      	add	x8, x8, #0x1
     da0:      	cmp	x8, #0xc0
     da4:      	b.eq	0xe3c <_llm_rows.packet_batch.blocks+0x3e8>
     da8:      	add	x13, x11, x8, lsl #5
     dac:      	movi.2d	v2, #0000000000000000
     db0:      	movi.2d	v4, #0000000000000000
     db4:      	tbnz	w12, #0x0, 0xddc <_llm_rows.packet_batch.blocks+0x388>
     db8:      	and	w14, w12, #0xff
     dbc:      	tbnz	w14, #0x1, 0xde8 <_llm_rows.packet_batch.blocks+0x394>
     dc0:      	tbnz	w14, #0x2, 0xdf4 <_llm_rows.packet_batch.blocks+0x3a0>
     dc4:      	tbnz	w14, #0x3, 0xe00 <_llm_rows.packet_batch.blocks+0x3ac>
     dc8:      	tbnz	w14, #0x4, 0xe0c <_llm_rows.packet_batch.blocks+0x3b8>
     dcc:      	tbnz	w14, #0x5, 0xe18 <_llm_rows.packet_batch.blocks+0x3c4>
     dd0:      	tbnz	w14, #0x6, 0xe24 <_llm_rows.packet_batch.blocks+0x3d0>
     dd4:      	tbz	w14, #0x7, 0xd88 <_llm_rows.packet_batch.blocks+0x334>
     dd8:      	b	0xe30 <_llm_rows.packet_batch.blocks+0x3dc>
     ddc:      	ldr	s2, [x13]
     de0:      	and	w14, w12, #0xff
     de4:      	tbz	w14, #0x1, 0xdc0 <_llm_rows.packet_batch.blocks+0x36c>
     de8:      	add	x15, x13, #0x4
     dec:      	ld1.s	{ v2 }[1], [x15]
     df0:      	tbz	w14, #0x2, 0xdc4 <_llm_rows.packet_batch.blocks+0x370>
     df4:      	add	x15, x13, #0x8
     df8:      	ld1.s	{ v2 }[2], [x15]
     dfc:      	tbz	w14, #0x3, 0xdc8 <_llm_rows.packet_batch.blocks+0x374>
     e00:      	add	x15, x13, #0xc
     e04:      	ld1.s	{ v2 }[3], [x15]
     e08:      	tbz	w14, #0x4, 0xdcc <_llm_rows.packet_batch.blocks+0x378>
     e0c:      	add	x15, x13, #0x10
     e10:      	ld1.s	{ v4 }[0], [x15]
     e14:      	tbz	w14, #0x5, 0xdd0 <_llm_rows.packet_batch.blocks+0x37c>
     e18:      	add	x15, x13, #0x14
     e1c:      	ld1.s	{ v4 }[1], [x15]
     e20:      	tbz	w14, #0x6, 0xdd4 <_llm_rows.packet_batch.blocks+0x380>
     e24:      	add	x15, x13, #0x18
     e28:      	ld1.s	{ v4 }[2], [x15]
     e2c:      	tbz	w14, #0x7, 0xd88 <_llm_rows.packet_batch.blocks+0x334>
     e30:      	add	x13, x13, #0x1c
     e34:      	ld1.s	{ v4 }[3], [x13]
     e38:      	b	0xd88 <_llm_rows.packet_batch.blocks+0x334>
     e3c:      	xtn.8b	v3, v3
     e40:      	sshll.2d	v4, v1, #0x0
     e44:      	movi	d2, #0x0000000000ffff
     e48:      	and.8b	v11, v3, v2
     e4c:      	adrp	x8, 0x0 <ltmp0>
     e50:      	ldr	d2, [x8]
     e54:      	str	q3, [sp, #0x1a0]
     e58:      	and.8b	v2, v3, v2
     e5c:      	addv.8b	b2, v2
     e60:      	fmov	w8, s2
     e64:      	umaxv.8b	b2, v11
     e68:      	fmov	w11, s2
     e6c:      	rbit	w12, w8
     e70:      	clz	w12, w12
     e74:      	tst	w11, #0x1
     e78:      	csel	w6, w12, wzr, ne
     e7c:      	mov	w11, #0x600             ; =1536
     e80:      	dup.2d	v27, x11
     e84:      	adrp	x11, 0x0 <ltmp0>
     e88:      	ldr	q23, [x11]
     e8c:      	mov.16b	v3, v4
     e90:      	bsl.16b	v3, v23, v27
     e94:      	xtn.2s	v2, v19
     e98:      	mov	w11, #0x602             ; =1538
     e9c:      	dup.2s	v19, w11
     ea0:      	umlal.2d	v3, v2, v19
     ea4:      	mov	b2, v11[0]
     ea8:      	mov.b	v2[4], v11[1]
     eac:      	ushll.2d	v2, v2, #0x0
     eb0:      	shl.2d	v2, v2, #0x3f
     eb4:      	cmlt.2d	v2, v2, #0
     eb8:      	str	q3, [sp, #0x100]
     ebc:      	and.16b	v2, v2, v3
     ec0:      	movi.2d	v3, #0000000000000000
     ec4:      	str	q3, [sp, #0x8b0]
     ec8:      	str	q3, [sp, #0x8a0]
     ecc:      	str	q3, [sp, #0x890]
     ed0:      	str	q2, [sp, #0x880]
     ed4:      	and	x11, x6, #0x7
     ed8:      	add	x12, sp, #0x880
     edc:      	ldr	x11, [x12, x11, lsl #3]
     ee0:      	sub	x11, x11, x6
     ee4:      	add	x9, x9, x11, lsl #2
     ee8:      	movi.2d	v12, #0000000000000000
     eec:      	movi.2d	v13, #0000000000000000
     ef0:      	tbnz	w8, #0x0, 0x1674 <_llm_rows.packet_batch.blocks+0xc20>
     ef4:      	tbnz	w8, #0x1, 0x167c <_llm_rows.packet_batch.blocks+0xc28>
     ef8:      	tbnz	w8, #0x2, 0x1688 <_llm_rows.packet_batch.blocks+0xc34>
     efc:      	tbnz	w8, #0x3, 0x1694 <_llm_rows.packet_batch.blocks+0xc40>
     f00:      	tbnz	w8, #0x4, 0x16a0 <_llm_rows.packet_batch.blocks+0xc4c>
     f04:      	tbnz	w8, #0x5, 0x16ac <_llm_rows.packet_batch.blocks+0xc58>
     f08:      	tbnz	w8, #0x6, 0x16b8 <_llm_rows.packet_batch.blocks+0xc64>
     f0c:      	tbz	w8, #0x7, 0xf18 <_llm_rows.packet_batch.blocks+0x4c4>
     f10:      	add	x9, x9, #0x1c
     f14:      	ld1.s	{ v13 }[3], [x9]
     f18:      	mov	x9, #0x0                ; =0
     f1c:      	sshll.2d	v2, v0, #0x0
     f20:      	sshll2.2d	v8, v1, #0x0
     f24:      	sshll2.2d	v9, v0, #0x0
     f28:      	adrp	x11, 0x0 <ltmp0>
     f2c:      	ldr	q3, [x11]
     f30:      	and.16b	v3, v9, v3
     f34:      	adrp	x11, 0x0 <ltmp0>
     f38:      	ldr	q20, [x11]
     f3c:      	and.16b	v20, v8, v20
     f40:      	adrp	x11, 0x0 <ltmp0>
     f44:      	ldr	q21, [x11]
     f48:      	and.16b	v21, v2, v21
     f4c:      	adrp	x11, 0x0 <ltmp0>
     f50:      	ldr	q22, [x11]
     f54:      	and.16b	v4, v4, v22
     f58:      	adrp	x11, 0x0 <ltmp0>
     f5c:      	ldr	q24, [x11]
     f60:      	mov.16b	v22, v2
     f64:      	bsl.16b	v22, v24, v27
     f68:      	adrp	x11, 0x0 <ltmp0>
     f6c:      	ldr	q26, [x11]
     f70:      	mov.16b	v28, v8
     f74:      	bsl.16b	v28, v26, v27
     f78:      	adrp	x11, 0x0 <ltmp0>
     f7c:      	ldr	q25, [x11]
     f80:      	bit.16b	v27, v25, v9
     f84:      	xtn.2s	v2, v18
     f88:      	xtn.2s	v17, v17
     f8c:      	xtn.2s	v16, v16
     f90:      	umlal.2d	v27, v16, v19
     f94:      	umlal.2d	v28, v17, v19
     f98:      	stp	q27, q28, [sp, #0xd0]
     f9c:      	umlal.2d	v22, v2, v19
     fa0:      	str	q22, [sp, #0xf0]
     fa4:      	str	q4, [sp, #0x840]
     fa8:      	str	q20, [sp, #0x850]
     fac:      	str	q21, [sp, #0x860]
     fb0:      	str	q3, [sp, #0x870]
     fb4:      	and	x11, x6, #0x7
     fb8:      	add	x12, sp, #0x840
     fbc:      	ldr	x11, [x12, x11, lsl #3]
     fc0:      	orr	x11, x11, #0x1800
     fc4:      	sub	x11, x11, x6, lsl #2
     fc8:      	tst	w8, #0xff
     fcc:      	csel	x7, xzr, x11, eq
     fd0:      	add	x11, x4, x7
     fd4:      	ldp	q2, q3, [x11]
     fd8:      	zip2.8b	v4, v11, v0
     fdc:      	ushll.4s	v4, v4, #0x0
     fe0:      	shl.4s	v4, v4, #0x1f
     fe4:      	cmlt.4s	v4, v4, #0
     fe8:      	bit.16b	v3, v13, v4
     fec:      	zip1.8b	v4, v11, v0
     ff0:      	ushll.4s	v4, v4, #0x0
     ff4:      	shl.4s	v4, v4, #0x1f
     ff8:      	cmlt.4s	v4, v4, #0
     ffc:      	bit.16b	v2, v12, v4
    1000:      	stp	q2, q3, [x11]
    1004:      	ushll2.2d	v2, v0, #0x0
    1008:      	mov	w11, #0x1               ; =1
    100c:      	dup.2d	v3, x11
    1010:      	and.16b	v14, v2, v3
    1014:      	ushll2.2d	v2, v1, #0x0
    1018:      	and.16b	v15, v2, v3
    101c:      	ushll.2d	v2, v0, #0x0
    1020:      	and.16b	v30, v2, v3
    1024:      	ushll.2d	v2, v1, #0x0
    1028:      	and.16b	v27, v2, v3
    102c:      	movi.2d	v2, #0000000000000000
    1030:      	and	x12, x10, #0x1
    1034:      	movi.2d	v3, #0000000000000000
    1038:      	movi.2d	v4, #0000000000000000
    103c:      	movi.2d	v16, #0000000000000000
    1040:      	stp	q27, q30, [sp, #0x270]
    1044:      	sshll.2d	v17, v0, #0x0
    1048:      	sshll.2d	v18, v1, #0x0
    104c:      	shl.2d	v19, v16, #0x3
    1050:      	shl.2d	v20, v2, #0x3
    1054:      	shl.2d	v21, v4, #0x3
    1058:      	shl.2d	v22, v3, #0x3
    105c:      	ldr	q27, [x16]
    1060:      	orr.16b	v22, v22, v27
    1064:      	ldr	q27, [x17]
    1068:      	orr.16b	v21, v21, v27
    106c:      	ldr	q27, [x0]
    1070:      	orr.16b	v20, v20, v27
    1074:      	ldr	q27, [x1]
    1078:      	orr.16b	v19, v19, v27
    107c:      	add	x9, x5, x9, lsl #6
    1080:      	ldp	q28, q27, [x9]
    1084:      	ldp	q29, q30, [x9, #0x20]
    1088:      	bif.16b	v19, v30, v9
    108c:      	bsl.16b	v18, v20, v28
    1090:      	bsl.16b	v17, v21, v29
    1094:      	mov.16b	v20, v8
    1098:      	bsl.16b	v20, v22, v27
    109c:      	ldp	q27, q30, [sp, #0x270]
    10a0:      	stp	q18, q20, [x9]
    10a4:      	stp	q17, q19, [x9, #0x20]
    10a8:      	add.2d	v17, v2, v27
    10ac:      	add.2d	v3, v3, v15
    10b0:      	add.2d	v4, v4, v30
    10b4:      	add.2d	v16, v16, v14
    10b8:      	fmov	x9, d2
    10bc:      	add	x9, x9, x12
    10c0:      	mov.16b	v2, v17
    10c4:      	cmp	x9, #0xc0
    10c8:      	b.lt	0x1044 <_llm_rows.packet_batch.blocks+0x5f0>
    10cc:      	mov	x9, #0x0                ; =0
    10d0:      	mov	w11, #0x602             ; =1538
    10d4:      	dup.4s	v2, w11
    10d8:      	and.16b	v3, v1, v2
    10dc:      	mvn.16b	v4, v1
    10e0:      	sub.4s	v3, v3, v4
    10e4:      	and.16b	v2, v0, v2
    10e8:      	mvn.16b	v4, v0
    10ec:      	sub.4s	v2, v2, v4
    10f0:      	mov.s	w11, v2[1]
    10f4:      	mov.s	w13, v7[1]
    10f8:      	udiv	w14, w13, w11
    10fc:      	msub	w13, w14, w11, w13
    1100:      	mov.s	w11, v2[2]
    1104:      	mov.s	w14, v2[3]
    1108:      	fmov	w15, s2
    110c:      	fmov	w16, s7
    1110:      	udiv	w17, w16, w15
    1114:      	msub	w15, w17, w15, w16
    1118:      	mov.s	w16, v7[2]
    111c:      	udiv	w17, w16, w11
    1120:      	msub	w16, w17, w11, w16
    1124:      	mov.s	w11, v7[3]
    1128:      	udiv	w17, w11, w14
    112c:      	msub	w14, w17, w14, w11
    1130:      	mov.s	w11, v3[1]
    1134:      	mov.s	w17, v6[1]
    1138:      	udiv	w0, w17, w11
    113c:      	msub	w17, w0, w11, w17
    1140:      	mov.s	w11, v3[2]
    1144:      	mov.s	w0, v3[3]
    1148:      	fmov	w1, s3
    114c:      	fmov	w2, s6
    1150:      	udiv	w3, w2, w1
    1154:      	msub	w1, w3, w1, w2
    1158:      	mov.s	w2, v6[2]
    115c:      	udiv	w3, w2, w11
    1160:      	msub	w11, w3, w11, w2
    1164:      	mov.s	w2, v6[3]
    1168:      	udiv	w3, w2, w0
    116c:      	msub	w0, w3, w0, w2
    1170:      	tst	w8, #0xff
    1174:      	fmov	s2, w15
    1178:      	mov.s	v2[1], w13
    117c:      	mov.s	v2[2], w16
    1180:      	mov.s	v2[3], w14
    1184:      	fmov	s3, w1
    1188:      	sshll.2d	v19, v0, #0x0
    118c:      	sshll.2d	v18, v1, #0x0
    1190:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5ac>
    1194:      	ldr	q4, [x8]
    1198:      	and.16b	v4, v18, v4
    119c:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5ac>
    11a0:      	ldr	q6, [x8]
    11a4:      	and.16b	v6, v19, v6
    11a8:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5ac>
    11ac:      	ldr	q7, [x8]
    11b0:      	and.16b	v7, v8, v7
    11b4:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5ac>
    11b8:      	ldr	q16, [x8]
    11bc:      	and.16b	v16, v9, v16
    11c0:      	str	q16, [sp, #0x830]
    11c4:      	str	q6, [sp, #0x820]
    11c8:      	str	q7, [sp, #0x810]
    11cc:      	str	q4, [sp, #0x800]
    11d0:      	mov.s	v3[1], w17
    11d4:      	and	x8, x6, #0x7
    11d8:      	add	x13, sp, #0x800
    11dc:      	ldr	x8, [x13, x8, lsl #3]
    11e0:      	orr	x8, x8, #0x3000
    11e4:      	sub	x8, x8, x6, lsl #3
    11e8:      	csel	x8, xzr, x8, eq
    11ec:      	add	x8, x5, x8
    11f0:      	ldp	q16, q7, [x8, #0x20]
    11f4:      	mov	b4, v11[2]
    11f8:      	mov.b	v4[4], v11[3]
    11fc:      	ldp	q6, q17, [x8]
    1200:      	ushll.2d	v4, v4, #0x0
    1204:      	shl.2d	v4, v4, #0x3f
    1208:      	cmlt.2d	v4, v4, #0
    120c:      	bsl.16b	v4, v26, v17
    1210:      	mov	b17, v11[0]
    1214:      	mov.b	v17[4], v11[1]
    1218:      	ushll.2d	v17, v17, #0x0
    121c:      	shl.2d	v17, v17, #0x3f
    1220:      	cmlt.2d	v17, v17, #0
    1224:      	bit.16b	v6, v23, v17
    1228:      	mov	b17, v11[6]
    122c:      	mov.b	v17[4], v11[7]
    1230:      	ushll.2d	v17, v17, #0x0
    1234:      	shl.2d	v17, v17, #0x3f
    1238:      	cmlt.2d	v17, v17, #0
    123c:      	bit.16b	v7, v25, v17
    1240:      	mov	b17, v11[4]
    1244:      	mov.b	v17[4], v11[5]
    1248:      	ushll.2d	v17, v17, #0x0
    124c:      	shl.2d	v17, v17, #0x3f
    1250:      	cmlt.2d	v17, v17, #0
    1254:      	mov.16b	v20, v17
    1258:      	bsl.16b	v20, v24, v16
    125c:      	mov.s	v3[2], w11
    1260:      	mov.s	v3[3], w0
    1264:      	and.16b	v17, v1, v3
    1268:      	stp	q20, q7, [x8, #0x20]
    126c:      	stp	q6, q4, [x8]
    1270:      	and.16b	v16, v0, v2
    1274:      	ushll2.2d	v2, v16, #0x0
    1278:      	ushll2.2d	v3, v17, #0x0
    127c:      	ushll.2d	v16, v16, #0x0
    1280:      	ushll.2d	v17, v17, #0x0
    1284:      	ldr	q21, [sp, #0x20]
    1288:      	and.16b	v25, v9, v21
    128c:      	and.16b	v26, v8, v21
    1290:      	and.16b	v28, v19, v21
    1294:      	and.16b	v29, v18, v21
    1298:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5ac>
    129c:      	ldr	q21, [x8]
    12a0:      	and.16b	v21, v9, v21
    12a4:      	str	q21, [sp, #0x2c0]
    12a8:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5ac>
    12ac:      	ldr	q21, [x8]
    12b0:      	and.16b	v21, v8, v21
    12b4:      	str	q21, [sp, #0x2b0]
    12b8:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5ac>
    12bc:      	ldr	q21, [x8]
    12c0:      	and.16b	v19, v19, v21
    12c4:      	str	q19, [sp, #0x2a0]
    12c8:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5ac>
    12cc:      	ldr	q19, [x8]
    12d0:      	and.16b	v18, v18, v19
    12d4:      	str	q18, [sp, #0x290]
    12d8:      	ldp	q18, q19, [sp, #0x130]
    12dc:      	cmhs.4s	v18, v18, v5
    12e0:      	cmhs.4s	v5, v19, v5
    12e4:      	uzp1.8h	v5, v5, v18
    12e8:      	xtn.8b	v5, v5
    12ec:      	movi.2d	v18, #0000000000000000
    12f0:      	movi.2d	v21, #0000000000000000
    12f4:      	movi.2d	v22, #0000000000000000
    12f8:      	movi.2d	v23, #0000000000000000
    12fc:      	mov	w17, #0xf2ca            ; =62154
    1300:      	movk	w17, #0xf149, lsl #16
    1304:      	mov	w0, #0x4                ; =4
    1308:      	stp	q9, q8, [sp, #0x180]
    130c:      	b	0x1334 <_llm_rows.packet_batch.blocks+0x8e0>
    1310:      	add.2d	v19, v18, v27
    1314:      	add.2d	v21, v21, v15
    1318:      	add.2d	v22, v22, v30
    131c:      	add.2d	v23, v23, v14
    1320:      	fmov	x8, d18
    1324:      	add	x9, x8, x12
    1328:      	mov.16b	v18, v19
    132c:      	cmp	x9, #0xc0
    1330:      	b.ge	0x144c <_llm_rows.packet_batch.blocks+0x9f8>
    1334:      	fmov	w8, s31
    1338:      	add	x9, x5, x9, lsl #6
    133c:      	ldp	q24, q19, [x9, #0x20]
    1340:      	ldp	q8, q9, [x9]
    1344:      	cmge.2d	v9, v3, v9
    1348:      	cmge.2d	v8, v17, v8
    134c:      	uzp1.4s	v8, v8, v9
    1350:      	cmge.2d	v24, v16, v24
    1354:      	cmge.2d	v19, v2, v19
    1358:      	uzp1.4s	v19, v24, v19
    135c:      	uzp1.8h	v19, v8, v19
    1360:      	xtn.8b	v19, v19
    1364:      	orr.8b	v19, v5, v19
    1368:      	ldr	q24, [sp, #0x290]
    136c:      	add.2d	v24, v18, v24
    1370:      	add.2d	v24, v29, v24
    1374:      	and.8b	v19, v19, v10
    1378:      	tbnz	w8, #0x0, 0x13c4 <_llm_rows.packet_batch.blocks+0x970>
    137c:      	and	w8, w8, #0xff
    1380:      	tbnz	w8, #0x1, 0x13d4 <_llm_rows.packet_batch.blocks+0x980>
    1384:      	ldr	q24, [sp, #0x2b0]
    1388:      	add.2d	v24, v21, v24
    138c:      	add.2d	v24, v26, v24
    1390:      	tbnz	w8, #0x2, 0x13ec <_llm_rows.packet_batch.blocks+0x998>
    1394:      	tbnz	w8, #0x3, 0x13f8 <_llm_rows.packet_batch.blocks+0x9a4>
    1398:      	ldr	q24, [sp, #0x2a0]
    139c:      	add.2d	v24, v22, v24
    13a0:      	add.2d	v24, v28, v24
    13a4:      	tbnz	w8, #0x4, 0x1410 <_llm_rows.packet_batch.blocks+0x9bc>
    13a8:      	tbnz	w8, #0x5, 0x141c <_llm_rows.packet_batch.blocks+0x9c8>
    13ac:      	ldr	q24, [sp, #0x2c0]
    13b0:      	add.2d	v24, v23, v24
    13b4:      	add.2d	v24, v25, v24
    13b8:      	tbnz	w8, #0x6, 0x1434 <_llm_rows.packet_batch.blocks+0x9e0>
    13bc:      	tbz	w8, #0x7, 0x1310 <_llm_rows.packet_batch.blocks+0x8bc>
    13c0:      	b	0x1440 <_llm_rows.packet_batch.blocks+0x9ec>
    13c4:      	fmov	x9, d24
    13c8:      	str	b19, [x9]
    13cc:      	and	w8, w8, #0xff
    13d0:      	tbz	w8, #0x1, 0x1384 <_llm_rows.packet_batch.blocks+0x930>
    13d4:      	mov.d	x9, v24[1]
    13d8:      	st1.b	{ v19 }[1], [x9]
    13dc:      	ldr	q24, [sp, #0x2b0]
    13e0:      	add.2d	v24, v21, v24
    13e4:      	add.2d	v24, v26, v24
    13e8:      	tbz	w8, #0x2, 0x1394 <_llm_rows.packet_batch.blocks+0x940>
    13ec:      	fmov	x9, d24
    13f0:      	st1.b	{ v19 }[2], [x9]
    13f4:      	tbz	w8, #0x3, 0x1398 <_llm_rows.packet_batch.blocks+0x944>
    13f8:      	mov.d	x9, v24[1]
    13fc:      	st1.b	{ v19 }[3], [x9]
    1400:      	ldr	q24, [sp, #0x2a0]
    1404:      	add.2d	v24, v22, v24
    1408:      	add.2d	v24, v28, v24
    140c:      	tbz	w8, #0x4, 0x13a8 <_llm_rows.packet_batch.blocks+0x954>
    1410:      	fmov	x9, d24
    1414:      	st1.b	{ v19 }[4], [x9]
    1418:      	tbz	w8, #0x5, 0x13ac <_llm_rows.packet_batch.blocks+0x958>
    141c:      	mov.d	x9, v24[1]
    1420:      	st1.b	{ v19 }[5], [x9]
    1424:      	ldr	q24, [sp, #0x2c0]
    1428:      	add.2d	v24, v23, v24
    142c:      	add.2d	v24, v25, v24
    1430:      	tbz	w8, #0x6, 0x13bc <_llm_rows.packet_batch.blocks+0x968>
    1434:      	fmov	x9, d24
    1438:      	st1.b	{ v19 }[6], [x9]
    143c:      	tbz	w8, #0x7, 0x1310 <_llm_rows.packet_batch.blocks+0x8bc>
    1440:      	mov.d	x8, v24[1]
    1444:      	st1.b	{ v19 }[7], [x8]
    1448:      	b	0x1310 <_llm_rows.packet_batch.blocks+0x8bc>
    144c:      	cmge.2d	v5, v17, v6
    1450:      	cmge.2d	v3, v3, v4
    1454:      	uzp1.4s	v3, v5, v3
    1458:      	cmge.2d	v4, v16, v20
    145c:      	cmge.2d	v2, v2, v7
    1460:      	uzp1.4s	v2, v4, v2
    1464:      	uzp1.8h	v2, v3, v2
    1468:      	xtn.8b	v2, v2
    146c:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5ac>
    1470:      	ldr	d3, [x8]
    1474:      	shl.8b	v4, v11, #0x7
    1478:      	cmlt.8b	v4, v4, #0
    147c:      	and.8b	v3, v4, v3
    1480:      	addv.8b	b19, v3
    1484:      	fmov	w11, s19
    1488:      	orn.8b	v2, v2, v11
    148c:      	ldr	q3, [sp, #0x290]
    1490:      	add.2d	v4, v3, v29
    1494:      	mov	w8, #0xc0               ; =192
    1498:      	dup.2d	v3, x8
    149c:      	add.2d	v7, v4, v3
    14a0:      	and.8b	v2, v2, v10
    14a4:      	tbnz	w11, #0x0, 0x16c8 <_llm_rows.packet_batch.blocks+0xc74>
    14a8:      	mov.d	x14, v7[1]
    14ac:      	tbnz	w11, #0x1, 0x16d8 <_llm_rows.packet_batch.blocks+0xc84>
    14b0:      	ldr	q4, [sp, #0x2b0]
    14b4:      	add.2d	v4, v4, v26
    14b8:      	add.2d	v6, v4, v3
    14bc:      	tbnz	w11, #0x2, 0x16ec <_llm_rows.packet_batch.blocks+0xc98>
    14c0:      	mov.d	x13, v6[1]
    14c4:      	tbnz	w11, #0x3, 0x16fc <_llm_rows.packet_batch.blocks+0xca8>
    14c8:      	ldr	q4, [sp, #0x2a0]
    14cc:      	add.2d	v4, v4, v28
    14d0:      	add.2d	v5, v4, v3
    14d4:      	tbnz	w11, #0x4, 0x1710 <_llm_rows.packet_batch.blocks+0xcbc>
    14d8:      	mov.d	x9, v5[1]
    14dc:      	tbnz	w11, #0x5, 0x1720 <_llm_rows.packet_batch.blocks+0xccc>
    14e0:      	ldr	q4, [sp, #0x2c0]
    14e4:      	add.2d	v4, v4, v25
    14e8:      	add.2d	v4, v4, v3
    14ec:      	tbnz	w11, #0x6, 0x1734 <_llm_rows.packet_batch.blocks+0xce0>
    14f0:      	mov.d	x8, v4[1]
    14f4:      	tbz	w11, #0x7, 0x14fc <_llm_rows.packet_batch.blocks+0xaa8>
    14f8:      	st1.b	{ v2 }[7], [x8]
    14fc:      	mov	x11, #0x0               ; =0
    1500:      	movi.2d	v23, #0000000000000000
    1504:      	movi.2d	v8, #0000000000000000
    1508:      	movi.2d	v9, #0000000000000000
    150c:      	movi.2d	v10, #0000000000000000
    1510:      	b	0x157c <_llm_rows.packet_batch.blocks+0xb28>
    1514:      	cmeq.8b	v2, v2, #0
    1518:      	sshll.8h	v2, v2, #0x0
    151c:      	sshll2.4s	v3, v2, #0x0
    1520:      	sshll.4s	v16, v2, #0x0
    1524:      	lsl	x11, x11, #5
    1528:      	add	x15, x4, x11
    152c:      	ldp	q17, q2, [x15]
    1530:      	and.16b	v18, v0, v2
    1534:      	dup.4s	v2, w17
    1538:      	and.16b	v17, v1, v17
    153c:      	bsl.16b	v16, v2, v17
    1540:      	bsl.16b	v3, v2, v18
    1544:      	add	x11, x25, x11
    1548:      	ldp	q17, q18, [x11]
    154c:      	bif.16b	v3, v18, v0
    1550:      	bif.16b	v16, v17, v1
    1554:      	stp	q16, q3, [x11]
    1558:      	add.2d	v3, v23, v27
    155c:      	add.2d	v8, v8, v15
    1560:      	add.2d	v9, v9, v30
    1564:      	add.2d	v10, v10, v14
    1568:      	fmov	x11, d23
    156c:      	add	x11, x11, x12
    1570:      	mov.16b	v23, v3
    1574:      	cmp	x11, #0xc0
    1578:      	b.ge	0x1658 <_llm_rows.packet_batch.blocks+0xc04>
    157c:      	fmov	w15, s31
    1580:      	ldr	q2, [sp, #0x290]
    1584:      	add.2d	v2, v23, v2
    1588:      	add.2d	v3, v29, v2
    158c:      	tbz	w15, #0x0, 0x15a4 <_llm_rows.packet_batch.blocks+0xb50>
    1590:      	fmov	x16, d3
    1594:      	ldr	b2, [x16]
    1598:      	and	w15, w15, #0xff
    159c:      	tbnz	w15, #0x1, 0x15b0 <_llm_rows.packet_batch.blocks+0xb5c>
    15a0:      	b	0x15b8 <_llm_rows.packet_batch.blocks+0xb64>
    15a4:      	movi.2d	v2, #0000000000000000
    15a8:      	and	w15, w15, #0xff
    15ac:      	tbz	w15, #0x1, 0x15b8 <_llm_rows.packet_batch.blocks+0xb64>
    15b0:      	mov.d	x16, v3[1]
    15b4:      	ld1.b	{ v2 }[1], [x16]
    15b8:      	ldr	q3, [sp, #0x2b0]
    15bc:      	add.2d	v3, v8, v3
    15c0:      	add.2d	v3, v26, v3
    15c4:      	tbnz	w15, #0x2, 0x15f8 <_llm_rows.packet_batch.blocks+0xba4>
    15c8:      	tbnz	w15, #0x3, 0x1604 <_llm_rows.packet_batch.blocks+0xbb0>
    15cc:      	ldr	q3, [sp, #0x2a0]
    15d0:      	add.2d	v3, v9, v3
    15d4:      	add.2d	v3, v28, v3
    15d8:      	tbnz	w15, #0x4, 0x161c <_llm_rows.packet_batch.blocks+0xbc8>
    15dc:      	tbnz	w15, #0x5, 0x1628 <_llm_rows.packet_batch.blocks+0xbd4>
    15e0:      	ldr	q3, [sp, #0x2c0]
    15e4:      	add.2d	v3, v10, v3
    15e8:      	add.2d	v3, v25, v3
    15ec:      	tbnz	w15, #0x6, 0x1640 <_llm_rows.packet_batch.blocks+0xbec>
    15f0:      	tbz	w15, #0x7, 0x1514 <_llm_rows.packet_batch.blocks+0xac0>
    15f4:      	b	0x164c <_llm_rows.packet_batch.blocks+0xbf8>
    15f8:      	fmov	x16, d3
    15fc:      	ld1.b	{ v2 }[2], [x16]
    1600:      	tbz	w15, #0x3, 0x15cc <_llm_rows.packet_batch.blocks+0xb78>
    1604:      	mov.d	x16, v3[1]
    1608:      	ld1.b	{ v2 }[3], [x16]
    160c:      	ldr	q3, [sp, #0x2a0]
    1610:      	add.2d	v3, v9, v3
    1614:      	add.2d	v3, v28, v3
    1618:      	tbz	w15, #0x4, 0x15dc <_llm_rows.packet_batch.blocks+0xb88>
    161c:      	fmov	x16, d3
    1620:      	ld1.b	{ v2 }[4], [x16]
    1624:      	tbz	w15, #0x5, 0x15e0 <_llm_rows.packet_batch.blocks+0xb8c>
    1628:      	mov.d	x16, v3[1]
    162c:      	ld1.b	{ v2 }[5], [x16]
    1630:      	ldr	q3, [sp, #0x2c0]
    1634:      	add.2d	v3, v10, v3
    1638:      	add.2d	v3, v25, v3
    163c:      	tbz	w15, #0x6, 0x15f0 <_llm_rows.packet_batch.blocks+0xb9c>
    1640:      	fmov	x16, d3
    1644:      	ld1.b	{ v2 }[6], [x16]
    1648:      	tbz	w15, #0x7, 0x1514 <_llm_rows.packet_batch.blocks+0xac0>
    164c:      	mov.d	x15, v3[1]
    1650:      	ld1.b	{ v2 }[7], [x15]
    1654:      	b	0x1514 <_llm_rows.packet_batch.blocks+0xac0>
    1658:      	fmov	w11, s19
    165c:      	tbz	w11, #0x0, 0x1748 <_llm_rows.packet_batch.blocks+0xcf4>
    1660:      	fmov	x15, d7
    1664:      	ldr	b3, [x15]
    1668:      	ldp	q22, q18, [sp, #0x180]
    166c:      	tbnz	w11, #0x1, 0x1754 <_llm_rows.packet_batch.blocks+0xd00>
    1670:      	b	0x1758 <_llm_rows.packet_batch.blocks+0xd04>
    1674:      	ldr	s12, [x9]
    1678:      	tbz	w8, #0x1, 0xef8 <_llm_rows.packet_batch.blocks+0x4a4>
    167c:      	add	x11, x9, #0x4
    1680:      	ld1.s	{ v12 }[1], [x11]
    1684:      	tbz	w8, #0x2, 0xefc <_llm_rows.packet_batch.blocks+0x4a8>
    1688:      	add	x11, x9, #0x8
    168c:      	ld1.s	{ v12 }[2], [x11]
    1690:      	tbz	w8, #0x3, 0xf00 <_llm_rows.packet_batch.blocks+0x4ac>
    1694:      	add	x11, x9, #0xc
    1698:      	ld1.s	{ v12 }[3], [x11]
    169c:      	tbz	w8, #0x4, 0xf04 <_llm_rows.packet_batch.blocks+0x4b0>
    16a0:      	add	x11, x9, #0x10
    16a4:      	ld1.s	{ v13 }[0], [x11]
    16a8:      	tbz	w8, #0x5, 0xf08 <_llm_rows.packet_batch.blocks+0x4b4>
    16ac:      	add	x11, x9, #0x14
    16b0:      	ld1.s	{ v13 }[1], [x11]
    16b4:      	tbz	w8, #0x6, 0xf0c <_llm_rows.packet_batch.blocks+0x4b8>
    16b8:      	add	x11, x9, #0x18
    16bc:      	ld1.s	{ v13 }[2], [x11]
    16c0:      	tbnz	w8, #0x7, 0xf10 <_llm_rows.packet_batch.blocks+0x4bc>
    16c4:      	b	0xf18 <_llm_rows.packet_batch.blocks+0x4c4>
    16c8:      	fmov	x8, d7
    16cc:      	str	b2, [x8]
    16d0:      	mov.d	x14, v7[1]
    16d4:      	tbz	w11, #0x1, 0x14b0 <_llm_rows.packet_batch.blocks+0xa5c>
    16d8:      	st1.b	{ v2 }[1], [x14]
    16dc:      	ldr	q4, [sp, #0x2b0]
    16e0:      	add.2d	v4, v4, v26
    16e4:      	add.2d	v6, v4, v3
    16e8:      	tbz	w11, #0x2, 0x14c0 <_llm_rows.packet_batch.blocks+0xa6c>
    16ec:      	fmov	x8, d6
    16f0:      	st1.b	{ v2 }[2], [x8]
    16f4:      	mov.d	x13, v6[1]
    16f8:      	tbz	w11, #0x3, 0x14c8 <_llm_rows.packet_batch.blocks+0xa74>
    16fc:      	st1.b	{ v2 }[3], [x13]
    1700:      	ldr	q4, [sp, #0x2a0]
    1704:      	add.2d	v4, v4, v28
    1708:      	add.2d	v5, v4, v3
    170c:      	tbz	w11, #0x4, 0x14d8 <_llm_rows.packet_batch.blocks+0xa84>
    1710:      	fmov	x8, d5
    1714:      	st1.b	{ v2 }[4], [x8]
    1718:      	mov.d	x9, v5[1]
    171c:      	tbz	w11, #0x5, 0x14e0 <_llm_rows.packet_batch.blocks+0xa8c>
    1720:      	st1.b	{ v2 }[5], [x9]
    1724:      	ldr	q4, [sp, #0x2c0]
    1728:      	add.2d	v4, v4, v25
    172c:      	add.2d	v4, v4, v3
    1730:      	tbz	w11, #0x6, 0x14f0 <_llm_rows.packet_batch.blocks+0xa9c>
    1734:      	fmov	x8, d4
    1738:      	st1.b	{ v2 }[6], [x8]
    173c:      	mov.d	x8, v4[1]
    1740:      	tbnz	w11, #0x7, 0x14f8 <_llm_rows.packet_batch.blocks+0xaa4>
    1744:      	b	0x14fc <_llm_rows.packet_batch.blocks+0xaa8>
    1748:      	movi.2d	v3, #0000000000000000
    174c:      	ldp	q22, q18, [sp, #0x180]
    1750:      	tbz	w11, #0x1, 0x1758 <_llm_rows.packet_batch.blocks+0xd04>
    1754:      	ld1.b	{ v3 }[1], [x14]
    1758:      	tbnz	w11, #0x2, 0x29e4 <_llm_rows.packet_batch.blocks+0x1f90>
    175c:      	tbnz	w11, #0x3, 0x29f0 <_llm_rows.packet_batch.blocks+0x1f9c>
    1760:      	tbnz	w11, #0x4, 0x29f8 <_llm_rows.packet_batch.blocks+0x1fa4>
    1764:      	tbnz	w11, #0x5, 0x2a04 <_llm_rows.packet_batch.blocks+0x1fb0>
    1768:      	tbnz	w11, #0x6, 0x2a0c <_llm_rows.packet_batch.blocks+0x1fb8>
    176c:      	stp	q26, q25, [sp, #0x200]
    1770:      	stp	q29, q28, [sp, #0x1e0]
    1774:      	stp	q14, q31, [sp, #0x250]
    1778:      	str	q15, [sp, #0x240]
    177c:      	str	d19, [sp, #0xc8]
    1780:      	tbz	w11, #0x7, 0x1788 <_llm_rows.packet_batch.blocks+0xd34>
    1784:      	ld1.b	{ v3 }[7], [x8]
    1788:      	str	x21, [sp, #0x70]
    178c:      	str	x6, [sp, #0x110]
    1790:      	str	w26, [sp, #0x128]
    1794:      	str	w22, [sp, #0x12c]
    1798:      	sshll.2d	v4, v1, #0x0
    179c:      	sshll.2d	v5, v0, #0x0
    17a0:      	cmeq.8b	v3, v3, #0
    17a4:      	sshll.8h	v6, v3, #0x0
    17a8:      	sshll.4s	v3, v6, #0x0
    17ac:      	str	q6, [sp, #0x50]
    17b0:      	sshll2.4s	v6, v6, #0x0
    17b4:      	str	q6, [sp, #0x90]
    17b8:      	mov.16b	v7, v6
    17bc:      	bsl.16b	v7, v2, v13
    17c0:      	mov.16b	v16, v3
    17c4:      	bsl.16b	v16, v2, v12
    17c8:      	str	x7, [sp, #0xc0]
    17cc:      	add	x8, x25, x7
    17d0:      	ldp	q3, q2, [x8]
    17d4:      	zip1.8b	v6, v11, v0
    17d8:      	ushll.4s	v6, v6, #0x0
    17dc:      	shl.4s	v6, v6, #0x1f
    17e0:      	cmlt.4s	v6, v6, #0
    17e4:      	stp	q16, q7, [sp, #0x150]
    17e8:      	bit.16b	v3, v16, v6
    17ec:      	str	q11, [sp, #0x1b0]
    17f0:      	zip2.8b	v6, v11, v0
    17f4:      	ushll.4s	v6, v6, #0x0
    17f8:      	shl.4s	v6, v6, #0x1f
    17fc:      	cmlt.4s	v6, v6, #0
    1800:      	bit.16b	v2, v7, v6
    1804:      	stp	q3, q2, [x8]
    1808:      	dup.2d	v2, x0
    180c:      	and.16b	v12, v22, v2
    1810:      	and.16b	v13, v18, v2
    1814:      	and.16b	v14, v5, v2
    1818:      	and.16b	v15, v4, v2
    181c:      	tst	w10, #0x1
    1820:      	csel	x1, x0, xzr, ne
    1824:      	ldr	q2, [x23, #0x1880]
    1828:      	ldr	q3, [x23, #0x1890]
    182c:      	and.16b	v3, v0, v3
    1830:      	and.16b	v2, v1, v2
    1834:      	ldr	q5, [x23, #0x1860]
    1838:      	ldr	q4, [x23, #0x1870]
    183c:      	and.16b	v4, v0, v4
    1840:      	and.16b	v5, v1, v5
    1844:      	ldr	q6, [x23, #0x1840]
    1848:      	ldr	q7, [x23, #0x1850]
    184c:      	and.16b	v7, v0, v7
    1850:      	and.16b	v6, v1, v6
    1854:      	ldr	q17, [x23, #0x1820]
    1858:      	ldr	q16, [x23, #0x1830]
    185c:      	and.16b	v16, v0, v16
    1860:      	mov	x8, x1
    1864:      	and.16b	v17, v1, v17
    1868:      	mov.16b	v23, v15
    186c:      	mov.16b	v19, v13
    1870:      	mov.16b	v20, v14
    1874:      	mov.16b	v21, v12
    1878:      	mov.16b	v30, v18
    187c:      	mov.16b	v31, v22
    1880:      	sshll.2d	v24, v1, #0x0
    1884:      	sshll.2d	v8, v0, #0x0
    1888:      	add	x8, x25, x8, lsl #5
    188c:      	ldp	q18, q22, [x8]
    1890:      	and.16b	v9, v0, v22
    1894:      	and.16b	v18, v1, v18
    1898:      	fmaxnm.4s	v22, v17, v18
    189c:      	fmaxnm.4s	v18, v16, v9
    18a0:      	ldp	q9, q10, [x8, #0x20]
    18a4:      	and.16b	v10, v0, v10
    18a8:      	and.16b	v9, v1, v9
    18ac:      	fmaxnm.4s	v9, v6, v9
    18b0:      	fmaxnm.4s	v10, v7, v10
    18b4:      	ldp	q11, q25, [x8, #0x40]
    18b8:      	and.16b	v25, v0, v25
    18bc:      	and.16b	v11, v1, v11
    18c0:      	fmaxnm.4s	v11, v5, v11
    18c4:      	fmaxnm.4s	v25, v4, v25
    18c8:      	ldp	q26, q27, [x8, #0x60]
    18cc:      	and.16b	v27, v0, v27
    18d0:      	and.16b	v26, v1, v26
    18d4:      	fmaxnm.4s	v26, v2, v26
    18d8:      	fmaxnm.4s	v27, v3, v27
    18dc:      	dup.2d	v28, x0
    18e0:      	and.16b	v29, v31, v28
    18e4:      	add.2d	v21, v21, v29
    18e8:      	and.16b	v29, v30, v28
    18ec:      	add.2d	v19, v19, v29
    18f0:      	and.16b	v29, v8, v28
    18f4:      	add.2d	v20, v20, v29
    18f8:      	and.16b	v24, v24, v28
    18fc:      	add.2d	v24, v23, v24
    1900:      	bit.16b	v16, v18, v0
    1904:      	bit.16b	v17, v22, v1
    1908:      	bit.16b	v7, v10, v0
    190c:      	bit.16b	v6, v9, v1
    1910:      	bit.16b	v4, v25, v0
    1914:      	bit.16b	v5, v11, v1
    1918:      	bit.16b	v3, v27, v0
    191c:      	bit.16b	v2, v26, v1
    1920:      	fmov	x8, d23
    1924:      	add	x9, x8, #0x4
    1928:      	tst	w10, #0x1
    192c:      	csel	x8, x9, x8, ne
    1930:      	mov.16b	v23, v24
    1934:      	cmp	x8, #0xc0
    1938:      	b.lt	0x1880 <_llm_rows.packet_batch.blocks+0xe2c>
    193c:      	mov	x8, #0x0                ; =0
    1940:      	movi	d19, #0xffffffffffff0000
    1944:      	ldp	q24, q21, [sp, #0x1a0]
    1948:      	and.8b	v25, v24, v19
    194c:      	zip2.8b	v19, v21, v0
    1950:      	ushll.4s	v19, v19, #0x0
    1954:      	shl.4s	v19, v19, #0x1f
    1958:      	cmlt.4s	v19, v19, #0
    195c:      	ldp	q23, q20, [sp, #0x150]
    1960:      	and.16b	v20, v19, v20
    1964:      	zip1.8b	v21, v21, v0
    1968:      	ushll.4s	v21, v21, #0x0
    196c:      	shl.4s	v21, v21, #0x1f
    1970:      	cmlt.4s	v21, v21, #0
    1974:      	and.16b	v23, v21, v23
    1978:      	fmaxnm.4s	v17, v17, v23
    197c:      	fmaxnm.4s	v16, v16, v20
    1980:      	and.16b	v16, v19, v16
    1984:      	and.16b	v17, v21, v17
    1988:      	zip1.8b	v19, v25, v0
    198c:      	ushll.4s	v19, v19, #0x0
    1990:      	shl.4s	v19, v19, #0x1f
    1994:      	cmlt.4s	v19, v19, #0
    1998:      	bit.16b	v17, v22, v19
    199c:      	str	d25, [sp, #0x88]
    19a0:      	zip2.8b	v19, v25, v0
    19a4:      	ushll.4s	v19, v19, #0x0
    19a8:      	shl.4s	v19, v19, #0x1f
    19ac:      	cmlt.4s	v19, v19, #0
    19b0:      	bit.16b	v16, v18, v19
    19b4:      	fmaxnm.4s	v7, v16, v7
    19b8:      	fmaxnm.4s	v6, v17, v6
    19bc:      	fmaxnm.4s	v5, v6, v5
    19c0:      	fmaxnm.4s	v4, v7, v4
    19c4:      	fmaxnm.4s	v3, v4, v3
    19c8:      	umov.b	w20, v24[1]
    19cc:      	fmaxnm.4s	v2, v5, v2
    19d0:      	and	w9, w10, w20
    19d4:      	str	w9, [sp, #0x4c]
    19d8:      	mov	s4, v2[1]
    19dc:      	tst	w9, #0x1
    19e0:      	movi	d20, #0000000000000000
    19e4:      	fcsel	s4, s4, s20, ne
    19e8:      	mvn	w9, w20
    19ec:      	add	x11, sp, #0x528
    19f0:      	bfxil	x11, x9, #0, #1
    19f4:      	str	d24, [sp, #0x528]
    19f8:      	ldrb	w11, [x11]
    19fc:      	add	x13, sp, #0x7d0
    1a00:      	bfi	x13, x9, #2, #1
    1a04:      	str	q3, [sp, #0x7e0]
    1a08:      	str	q2, [sp, #0x7d0]
    1a0c:      	ldr	s5, [x13]
    1a10:      	and	w14, w20, #0x1
    1a14:      	tst	w14, w11
    1a18:      	fcsel	s5, s5, s20, ne
    1a1c:      	umov.b	w21, v24[2]
    1a20:      	umov.b	w9, v24[3]
    1a24:      	str	x9, [sp, #0x40]
    1a28:      	ands	w9, w9, #0x1
    1a2c:      	str	w9, [sp, #0x6c]
    1a30:      	mov	w11, #0x1               ; =1
    1a34:      	cinc	w15, w11, ne
    1a38:      	cinc	w4, w11, eq
    1a3c:      	mov	w13, #0x7               ; =7
    1a40:      	csel	w11, w13, w0, ne
    1a44:      	str	x11, [sp, #0xa8]
    1a48:      	ands	w30, w21, #0x1
    1a4c:      	mov	w11, #0x3               ; =3
    1a50:      	csinc	w11, w11, wzr, ne
    1a54:      	add	x22, sp, #0x528
    1a58:      	orr	x16, x22, x11
    1a5c:      	ldrb	w16, [x16]
    1a60:      	add	x17, sp, #0x7b0
    1a64:      	orr	x11, x17, x11, lsl #2
    1a68:      	str	q3, [sp, #0x7c0]
    1a6c:      	str	q2, [sp, #0x7b0]
    1a70:      	ldr	s6, [x11]
    1a74:      	mov	w26, #0x2               ; =2
    1a78:      	mov	w17, #0x4               ; =4
    1a7c:      	csel	w0, wzr, w26, ne
    1a80:      	mov	w24, #0x6               ; =6
    1a84:      	csel	w11, w24, w17, ne
    1a88:      	str	x11, [sp, #0x80]
    1a8c:      	tst	w30, w16
    1a90:      	add	x16, sp, #0x528
    1a94:      	bfxil	x16, x15, #0, #3
    1a98:      	ldrb	w16, [x16]
    1a9c:      	add	x2, sp, #0x790
    1aa0:      	orr	x15, x2, x15, lsl #2
    1aa4:      	str	q3, [sp, #0x7a0]
    1aa8:      	str	q2, [sp, #0x790]
    1aac:      	ldr	s7, [x15]
    1ab0:      	fcsel	s6, s6, s20, ne
    1ab4:      	tst	w9, w16
    1ab8:      	umov.b	w11, v24[4]
    1abc:      	umov.b	w16, v24[5]
    1ac0:      	str	w16, [sp, #0x17c]
    1ac4:      	umov.b	w15, v24[6]
    1ac8:      	str	w15, [sp, #0x178]
    1acc:      	umov.b	w9, v24[7]
    1ad0:      	str	w9, [sp, #0x3c]
    1ad4:      	fcsel	s7, s7, s20, ne
    1ad8:      	ands	w2, w9, #0x1
    1adc:      	csinc	w27, w24, wzr, ne
    1ae0:      	mov	w9, #0x5                ; =5
    1ae4:      	csel	w3, w9, w26, ne
    1ae8:      	ands	w15, w15, #0x1
    1aec:      	csinc	w28, w13, wzr, ne
    1af0:      	csel	w5, w17, w26, ne
    1af4:      	ands	w7, w16, #0x1
    1af8:      	csinc	w19, w17, wzr, ne
    1afc:      	csel	w6, w13, w26, ne
    1b00:      	ands	w16, w11, #0x1
    1b04:      	csinc	w17, w9, wzr, ne
    1b08:      	orr	x13, x22, x17
    1b0c:      	ldrb	w13, [x13]
    1b10:      	str	q3, [sp, #0x780]
    1b14:      	str	q2, [sp, #0x770]
    1b18:      	add	x9, sp, #0x770
    1b1c:      	ldr	s16, [x9, w17, uxtw #2]
    1b20:      	csel	w17, w24, w26, ne
    1b24:      	tst	w16, w13
    1b28:      	orr	x13, x22, x19
    1b2c:      	ldrb	w13, [x13]
    1b30:      	str	q3, [sp, #0x760]
    1b34:      	str	q2, [sp, #0x750]
    1b38:      	add	x9, sp, #0x750
    1b3c:      	ldr	s17, [x9, w19, uxtw #2]
    1b40:      	fcsel	s16, s16, s20, ne
    1b44:      	tst	w7, w13
    1b48:      	orr	x13, x22, x28
    1b4c:      	ldrb	w13, [x13]
    1b50:      	str	q3, [sp, #0x740]
    1b54:      	str	q2, [sp, #0x730]
    1b58:      	add	x9, sp, #0x730
    1b5c:      	ldr	s18, [x9, w28, uxtw #2]
    1b60:      	mov	x28, x21
    1b64:      	fcsel	s17, s17, s20, ne
    1b68:      	tst	w15, w13
    1b6c:      	orr	x13, x22, x27
    1b70:      	ldrb	w13, [x13]
    1b74:      	str	q3, [sp, #0x720]
    1b78:      	str	q2, [sp, #0x710]
    1b7c:      	add	x9, sp, #0x710
    1b80:      	ldr	s19, [x9, w27, uxtw #2]
    1b84:      	fcsel	s18, s18, s20, ne
    1b88:      	tst	w2, w13
    1b8c:      	mov.s	v4[1], v5[0]
    1b90:      	mov.s	v4[2], v6[0]
    1b94:      	mov.s	v4[3], v7[0]
    1b98:      	mov.s	v16[1], v17[0]
    1b9c:      	mov.s	v16[2], v18[0]
    1ba0:      	fcsel	s5, s19, s20, ne
    1ba4:      	mov.s	v16[3], v5[0]
    1ba8:      	fmaxnm.4s	v3, v3, v16
    1bac:      	fmaxnm.4s	v2, v2, v4
    1bb0:      	and	w24, w10, w21
    1bb4:      	mov	s4, v2[2]
    1bb8:      	mov	w13, #0x2               ; =2
    1bbc:      	bfxil	w13, w20, #0, #1
    1bc0:      	orr	x19, x22, x13
    1bc4:      	ldrb	w19, [x19]
    1bc8:      	add	x9, sp, #0x6f0
    1bcc:      	orr	x13, x9, x13, lsl #2
    1bd0:      	str	q3, [sp, #0x700]
    1bd4:      	str	q2, [sp, #0x6f0]
    1bd8:      	ldr	s5, [x13]
    1bdc:      	tst	w24, #0x1
    1be0:      	fcsel	s4, s4, s20, ne
    1be4:      	tst	w14, w19
    1be8:      	lsr	x13, x0, #1
    1bec:      	add	x19, sp, #0x6d0
    1bf0:      	bfi	x19, x13, #3, #1
    1bf4:      	orr	x13, x22, x0
    1bf8:      	ldrb	w13, [x13]
    1bfc:      	str	q3, [sp, #0x6e0]
    1c00:      	str	q2, [sp, #0x6d0]
    1c04:      	ldr	s6, [x19]
    1c08:      	fcsel	s5, s5, s20, ne
    1c0c:      	tst	w30, w13
    1c10:      	add	x13, sp, #0x528
    1c14:      	bfxil	x13, x4, #0, #3
    1c18:      	ldrb	w13, [x13]
    1c1c:      	add	x9, sp, #0x6b0
    1c20:      	orr	x0, x9, x4, lsl #2
    1c24:      	str	q3, [sp, #0x6c0]
    1c28:      	str	q2, [sp, #0x6b0]
    1c2c:      	ldr	s7, [x0]
    1c30:      	mov	w0, #0x4                ; =4
    1c34:      	fcsel	s6, s6, s20, ne
    1c38:      	ldr	w4, [sp, #0x6c]
    1c3c:      	tst	w4, w13
    1c40:      	fcsel	s7, s7, s20, ne
    1c44:      	orr	x13, x22, x17
    1c48:      	ldrb	w13, [x13]
    1c4c:      	tst	w16, w13
    1c50:      	str	q3, [sp, #0x6a0]
    1c54:      	str	q2, [sp, #0x690]
    1c58:      	add	x9, sp, #0x690
    1c5c:      	ldr	s16, [x9, w17, uxtw #2]
    1c60:      	fcsel	s16, s16, s20, ne
    1c64:      	orr	x13, x22, x6
    1c68:      	ldrb	w13, [x13]
    1c6c:      	tst	w7, w13
    1c70:      	str	q3, [sp, #0x680]
    1c74:      	str	q2, [sp, #0x670]
    1c78:      	add	x9, sp, #0x670
    1c7c:      	ldr	s17, [x9, w6, uxtw #2]
    1c80:      	orr	x13, x22, x5
    1c84:      	ldrb	w13, [x13]
    1c88:      	str	q3, [sp, #0x660]
    1c8c:      	str	q2, [sp, #0x650]
    1c90:      	add	x9, sp, #0x650
    1c94:      	ldr	s18, [x9, w5, uxtw #2]
    1c98:      	orr	x16, x22, x3
    1c9c:      	ldrb	w16, [x16]
    1ca0:      	str	q3, [sp, #0x640]
    1ca4:      	str	q2, [sp, #0x630]
    1ca8:      	add	x9, sp, #0x630
    1cac:      	ldr	s19, [x9, w3, uxtw #2]
    1cb0:      	fcsel	s17, s17, s20, ne
    1cb4:      	tst	w15, w13
    1cb8:      	fcsel	s18, s18, s20, ne
    1cbc:      	tst	w2, w16
    1cc0:      	fcsel	s19, s19, s20, ne
    1cc4:      	mov.s	v16[1], v17[0]
    1cc8:      	mov.s	v16[2], v18[0]
    1ccc:      	mov.s	v16[3], v19[0]
    1cd0:      	mov.s	v4[1], v5[0]
    1cd4:      	mov.s	v4[2], v6[0]
    1cd8:      	mov.s	v4[3], v7[0]
    1cdc:      	fmaxnm.4s	v2, v2, v4
    1ce0:      	fmaxnm.4s	v3, v3, v16
    1ce4:      	mov	x13, x0
    1ce8:      	str	w20, [sp, #0xb4]
    1cec:      	bfxil	w13, w20, #0, #1
    1cf0:      	orr	x15, x22, x13
    1cf4:      	ldrb	w15, [x15]
    1cf8:      	str	q3, [sp, #0x620]
    1cfc:      	str	q2, [sp, #0x610]
    1d00:      	add	x9, sp, #0x610
    1d04:      	ldr	s4, [x9, w13, uxtw #2]
    1d08:      	str	w11, [sp, #0x7c]
    1d0c:      	and	w16, w10, w11
    1d10:      	tst	w16, #0x1
    1d14:      	fcsel	s5, s3, s20, ne
    1d18:      	tst	w14, w15
    1d1c:      	fcsel	s4, s4, s20, ne
    1d20:      	ldr	x11, [sp, #0x80]
    1d24:      	orr	x13, x22, x11
    1d28:      	ldrb	w13, [x13]
    1d2c:      	str	q3, [sp, #0x600]
    1d30:      	str	q2, [sp, #0x5f0]
    1d34:      	add	x9, sp, #0x5f0
    1d38:      	ldr	s6, [x9, w11, uxtw #2]
    1d3c:      	tst	w30, w13
    1d40:      	fcsel	s6, s6, s20, ne
    1d44:      	ldr	x13, [sp, #0xa8]
    1d48:      	orr	x11, x22, x13
    1d4c:      	ldrb	w11, [x11]
    1d50:      	str	q3, [sp, #0x5e0]
    1d54:      	str	q2, [sp, #0x5d0]
    1d58:      	add	x9, sp, #0x5d0
    1d5c:      	ldr	s3, [x9, w13, uxtw #2]
    1d60:      	tst	w4, w11
    1d64:      	fcsel	s3, s3, s20, ne
    1d68:      	mov.s	v5[1], v4[0]
    1d6c:      	mov.s	v5[2], v6[0]
    1d70:      	mov.s	v5[3], v3[0]
    1d74:      	ldr	w9, [sp, #0x4c]
    1d78:      	mov	x27, x9
    1d7c:      	tst	w9, #0x1
    1d80:      	fmaxnm.4s	v2, v2, v5
    1d84:      	fcsel	s3, s2, s20, ne
    1d88:      	str	w24, [sp, #0xa8]
    1d8c:      	tst	w24, #0x1
    1d90:      	ldr	w24, [sp, #0x3c]
    1d94:      	fcsel	s4, s2, s20, ne
    1d98:      	str	w16, [sp, #0x80]
    1d9c:      	tst	w16, #0x1
    1da0:      	fcsel	s5, s2, s20, ne
    1da4:      	tst	w10, #0x1
    1da8:      	ldr	x9, [sp, #0x40]
    1dac:      	mov	x19, x9
    1db0:      	and	w9, w9, w10
    1db4:      	fcsel	s6, s2, s20, ne
    1db8:      	str	w9, [sp, #0x6c]
    1dbc:      	tst	w9, #0x1
    1dc0:      	fcsel	s7, s2, s20, ne
    1dc4:      	ldr	w9, [sp, #0x17c]
    1dc8:      	and	w9, w9, w10
    1dcc:      	str	w9, [sp, #0x68]
    1dd0:      	tst	w9, #0x1
    1dd4:      	fcsel	s16, s2, s20, ne
    1dd8:      	ldr	w9, [sp, #0x178]
    1ddc:      	and	w9, w9, w10
    1de0:      	str	w9, [sp, #0x64]
    1de4:      	tst	w9, #0x1
    1de8:      	fcsel	s17, s2, s20, ne
    1dec:      	and	w9, w24, w10
    1df0:      	str	w9, [sp, #0x60]
    1df4:      	tst	w9, #0x1
    1df8:      	mov.s	v6[1], v3[0]
    1dfc:      	mov.s	v6[2], v4[0]
    1e00:      	mov.s	v6[3], v7[0]
    1e04:      	mov.s	v5[1], v16[0]
    1e08:      	mov.s	v5[2], v17[0]
    1e0c:      	fcsel	s2, s2, s20, ne
    1e10:      	mov.s	v5[3], v2[0]
    1e14:      	ldr	w9, [sp, #0xb8]
    1e18:      	rbit	w9, w9
    1e1c:      	clz	w9, w9
    1e20:      	str	q5, [sp, #0x540]
    1e24:      	str	q6, [sp, #0x530]
    1e28:      	str	x9, [sp, #0xb8]
    1e2c:      	and	x9, x9, #0x7
    1e30:      	add	x11, sp, #0x530
    1e34:      	ldr	s2, [x11, x9, lsl #2]
    1e38:      	mov	w9, #-0x800000          ; =-8388608
    1e3c:      	fmov	s3, w9
    1e40:      	fmaxnm	s2, s2, s3
    1e44:      	dup.4s	v4, v2[0]
    1e48:      	movi.2d	v5, #0000000000000000
    1e4c:      	movi.2d	v23, #0000000000000000
    1e50:      	movi.2d	v8, #0000000000000000
    1e54:      	movi.2d	v6, #0000000000000000
    1e58:      	ldr	w26, [sp, #0x128]
    1e5c:      	mov	w13, #-0x3d300000       ; =-1026555904
    1e60:      	mov	w14, #0x42c80000        ; =1120403456
    1e64:      	mov	w15, #0xaa3b            ; =43579
    1e68:      	movk	w15, #0x3fb8, lsl #16
    1e6c:      	mov	w16, #0x7200            ; =29184
    1e70:      	movk	w16, #0xbf31, lsl #16
    1e74:      	mov	w17, #0xbe8e            ; =48782
    1e78:      	movk	w17, #0xb5bf, lsl #16
    1e7c:      	mov	w3, #0x2bda             ; =11226
    1e80:      	movk	w3, #0x3950, lsl #16
    1e84:      	mov	w4, #0x96c9             ; =38601
    1e88:      	movk	w4, #0x3ab6, lsl #16
    1e8c:      	mov	w5, #0x88a6             ; =34982
    1e90:      	movk	w5, #0x3c08, lsl #16
    1e94:      	mov	w6, #0xaa7a             ; =43642
    1e98:      	movk	w6, #0x3d2a, lsl #16
    1e9c:      	mov	w7, #0xaaab             ; =43691
    1ea0:      	movk	w7, #0x3e2a, lsl #16
    1ea4:      	ldr	x20, [sp, #0x8]
    1ea8:      	ldr	x21, [sp, #0x70]
    1eac:      	b	0x20bc <_llm_rows.packet_batch.blocks+0x1668>
    1eb0:      	lsl	x8, x8, #5
    1eb4:      	add	x9, x25, x8
    1eb8:      	ldp	q3, q2, [x9]
    1ebc:      	fsub.4s	v3, v3, v4
    1ec0:      	fsub.4s	v2, v2, v4
    1ec4:      	and.16b	v24, v0, v2
    1ec8:      	and.16b	v19, v1, v3
    1ecc:      	dup.4s	v7, w13
    1ed0:      	fcmge.4s	v2, v19, v7
    1ed4:      	fcmge.4s	v3, v24, v7
    1ed8:      	dup.4s	v10, w14
    1edc:      	fcmge.4s	v16, v10, v19
    1ee0:      	fcmge.4s	v17, v10, v24
    1ee4:      	and.16b	v3, v3, v17
    1ee8:      	and.16b	v2, v2, v16
    1eec:      	and.16b	v2, v2, v19
    1ef0:      	and.16b	v16, v3, v24
    1ef4:      	dup.4s	v11, w15
    1ef8:      	fmul.4s	v3, v16, v11
    1efc:      	fmul.4s	v17, v2, v11
    1f00:      	movi.4s	v20, #0x4b, lsl #24
    1f04:      	mvni.4s	v21, #0x80, lsl #24
    1f08:      	mov.16b	v18, v21
    1f0c:      	bsl.16b	v18, v20, v17
    1f10:      	bif.16b	v20, v3, v21
    1f14:      	fadd.4s	v3, v3, v20
    1f18:      	fadd.4s	v17, v17, v18
    1f1c:      	fsub.4s	v17, v17, v18
    1f20:      	fsub.4s	v3, v3, v20
    1f24:      	fcvtzs.4s	v25, v3
    1f28:      	fcvtzs.4s	v26, v17
    1f2c:      	scvtf.4s	v17, v26
    1f30:      	scvtf.4s	v18, v25
    1f34:      	dup.4s	v3, w16
    1f38:      	fmul.4s	v20, v18, v3
    1f3c:      	fmul.4s	v21, v17, v3
    1f40:      	fadd.4s	v21, v2, v21
    1f44:      	fadd.4s	v16, v16, v20
    1f48:      	dup.4s	v2, w17
    1f4c:      	fmul.4s	v17, v17, v2
    1f50:      	fmul.4s	v18, v18, v2
    1f54:      	fadd.4s	v20, v16, v18
    1f58:      	fadd.4s	v27, v21, v17
    1f5c:      	dup.4s	v21, w3
    1f60:      	fmul.4s	v16, v27, v21
    1f64:      	fmul.4s	v17, v20, v21
    1f68:      	dup.4s	v22, w4
    1f6c:      	fadd.4s	v17, v17, v22
    1f70:      	fadd.4s	v16, v16, v22
    1f74:      	fmul.4s	v18, v27, v16
    1f78:      	fmul.4s	v17, v20, v17
    1f7c:      	dup.4s	v16, w5
    1f80:      	fadd.4s	v17, v17, v16
    1f84:      	fadd.4s	v18, v18, v16
    1f88:      	fmul.4s	v18, v27, v18
    1f8c:      	fmul.4s	v28, v20, v17
    1f90:      	dup.4s	v17, w6
    1f94:      	fadd.4s	v28, v28, v17
    1f98:      	fadd.4s	v18, v18, v17
    1f9c:      	fmul.4s	v29, v27, v18
    1fa0:      	fmul.4s	v28, v20, v28
    1fa4:      	dup.4s	v18, w7
    1fa8:      	fadd.4s	v28, v28, v18
    1fac:      	fadd.4s	v29, v29, v18
    1fb0:      	fmul.4s	v29, v27, v29
    1fb4:      	fmul.4s	v28, v20, v28
    1fb8:      	movi.4s	v30, #0x3f, lsl #24
    1fbc:      	fadd.4s	v28, v28, v30
    1fc0:      	fadd.4s	v29, v29, v30
    1fc4:      	fmul.4s	v30, v20, v20
    1fc8:      	fmul.4s	v31, v27, v27
    1fcc:      	fmul.4s	v29, v31, v29
    1fd0:      	fmul.4s	v28, v30, v28
    1fd4:      	fadd.4s	v28, v20, v28
    1fd8:      	fadd.4s	v27, v27, v29
    1fdc:      	fmov.4s	v20, #1.00000000
    1fe0:      	fadd.4s	v27, v27, v20
    1fe4:      	fadd.4s	v28, v28, v20
    1fe8:      	sshr.4s	v29, v26, #0x1
    1fec:      	sshr.4s	v30, v25, #0x1
    1ff0:      	shl.4s	v31, v30, #0x17
    1ff4:      	add.4s	v31, v31, v20
    1ff8:      	fmul.4s	v28, v28, v31
    1ffc:      	shl.4s	v31, v29, #0x17
    2000:      	add.4s	v31, v31, v20
    2004:      	fmul.4s	v27, v27, v31
    2008:      	sub.4s	v25, v25, v30
    200c:      	sub.4s	v26, v26, v29
    2010:      	shl.4s	v26, v26, #0x17
    2014:      	add.4s	v26, v26, v20
    2018:      	fmul.4s	v26, v27, v26
    201c:      	shl.4s	v25, v25, #0x17
    2020:      	add.4s	v25, v25, v20
    2024:      	fmul.4s	v25, v28, v25
    2028:      	fcmgt.4s	v27, v7, v24
    202c:      	bic.16b	v25, v25, v27
    2030:      	fcmgt.4s	v27, v7, v19
    2034:      	bic.16b	v26, v26, v27
    2038:      	fcmgt.4s	v27, v19, v10
    203c:      	ldr	q28, [sp, #0x230]
    2040:      	bit.16b	v26, v28, v27
    2044:      	fcmgt.4s	v27, v24, v10
    2048:      	bit.16b	v25, v28, v27
    204c:      	fcmeq.4s	v24, v24, v24
    2050:      	ldr	q27, [sp, #0x220]
    2054:      	bsl.16b	v24, v25, v27
    2058:      	cmeq.8b	v25, v9, #0
    205c:      	sshll.8h	v25, v25, #0x0
    2060:      	fcmeq.4s	v19, v19, v19
    2064:      	bsl.16b	v19, v26, v27
    2068:      	sshll.4s	v26, v25, #0x0
    206c:      	bic.16b	v19, v19, v26
    2070:      	sshll2.4s	v25, v25, #0x0
    2074:      	bic.16b	v24, v24, v25
    2078:      	add	x8, x23, x8
    207c:      	ldp	q25, q26, [x8]
    2080:      	bif.16b	v24, v26, v0
    2084:      	bif.16b	v19, v25, v1
    2088:      	stp	q19, q24, [x8]
    208c:      	fmov	x8, d5
    2090:      	ldr	q19, [sp, #0x270]
    2094:      	add.2d	v5, v5, v19
    2098:      	ldr	q19, [sp, #0x240]
    209c:      	add.2d	v23, v23, v19
    20a0:      	ldr	q19, [sp, #0x280]
    20a4:      	add.2d	v8, v8, v19
    20a8:      	ldr	q19, [sp, #0x250]
    20ac:      	add.2d	v6, v6, v19
    20b0:      	add	x8, x8, x12
    20b4:      	cmp	x8, #0xc0
    20b8:      	b.ge	0x21b0 <_llm_rows.packet_batch.blocks+0x175c>
    20bc:      	ldr	q2, [sp, #0x260]
    20c0:      	fmov	w9, s2
    20c4:      	ldr	q2, [sp, #0x290]
    20c8:      	add.2d	v2, v5, v2
    20cc:      	ldr	q3, [sp, #0x1e0]
    20d0:      	add.2d	v2, v3, v2
    20d4:      	tbz	w9, #0x0, 0x20f4 <_llm_rows.packet_batch.blocks+0x16a0>
    20d8:      	fmov	x11, d2
    20dc:      	ldr	b9, [x11]
    20e0:      	ldp	q7, q3, [sp, #0x200]
    20e4:      	ldr	q16, [sp, #0x1f0]
    20e8:      	and	w9, w9, #0xff
    20ec:      	tbnz	w9, #0x1, 0x2108 <_llm_rows.packet_batch.blocks+0x16b4>
    20f0:      	b	0x2110 <_llm_rows.packet_batch.blocks+0x16bc>
    20f4:      	movi.2d	v9, #0000000000000000
    20f8:      	ldp	q7, q3, [sp, #0x200]
    20fc:      	ldr	q16, [sp, #0x1f0]
    2100:      	and	w9, w9, #0xff
    2104:      	tbz	w9, #0x1, 0x2110 <_llm_rows.packet_batch.blocks+0x16bc>
    2108:      	mov.d	x11, v2[1]
    210c:      	ld1.b	{ v9 }[1], [x11]
    2110:      	ldr	q2, [sp, #0x2b0]
    2114:      	add.2d	v2, v23, v2
    2118:      	add.2d	v2, v7, v2
    211c:      	tbnz	w9, #0x2, 0x2150 <_llm_rows.packet_batch.blocks+0x16fc>
    2120:      	tbnz	w9, #0x3, 0x215c <_llm_rows.packet_batch.blocks+0x1708>
    2124:      	ldr	q2, [sp, #0x2a0]
    2128:      	add.2d	v2, v8, v2
    212c:      	add.2d	v2, v16, v2
    2130:      	tbnz	w9, #0x4, 0x2174 <_llm_rows.packet_batch.blocks+0x1720>
    2134:      	tbnz	w9, #0x5, 0x2180 <_llm_rows.packet_batch.blocks+0x172c>
    2138:      	ldr	q2, [sp, #0x2c0]
    213c:      	add.2d	v2, v6, v2
    2140:      	add.2d	v2, v3, v2
    2144:      	tbnz	w9, #0x6, 0x2198 <_llm_rows.packet_batch.blocks+0x1744>
    2148:      	tbz	w9, #0x7, 0x1eb0 <_llm_rows.packet_batch.blocks+0x145c>
    214c:      	b	0x21a4 <_llm_rows.packet_batch.blocks+0x1750>
    2150:      	fmov	x11, d2
    2154:      	ld1.b	{ v9 }[2], [x11]
    2158:      	tbz	w9, #0x3, 0x2124 <_llm_rows.packet_batch.blocks+0x16d0>
    215c:      	mov.d	x11, v2[1]
    2160:      	ld1.b	{ v9 }[3], [x11]
    2164:      	ldr	q2, [sp, #0x2a0]
    2168:      	add.2d	v2, v8, v2
    216c:      	add.2d	v2, v16, v2
    2170:      	tbz	w9, #0x4, 0x2134 <_llm_rows.packet_batch.blocks+0x16e0>
    2174:      	fmov	x11, d2
    2178:      	ld1.b	{ v9 }[4], [x11]
    217c:      	tbz	w9, #0x5, 0x2138 <_llm_rows.packet_batch.blocks+0x16e4>
    2180:      	mov.d	x11, v2[1]
    2184:      	ld1.b	{ v9 }[5], [x11]
    2188:      	ldr	q2, [sp, #0x2c0]
    218c:      	add.2d	v2, v6, v2
    2190:      	add.2d	v2, v3, v2
    2194:      	tbz	w9, #0x6, 0x2148 <_llm_rows.packet_batch.blocks+0x16f4>
    2198:      	fmov	x11, d2
    219c:      	ld1.b	{ v9 }[6], [x11]
    21a0:      	tbz	w9, #0x7, 0x1eb0 <_llm_rows.packet_batch.blocks+0x145c>
    21a4:      	mov.d	x9, v2[1]
    21a8:      	ld1.b	{ v9 }[7], [x9]
    21ac:      	b	0x1eb0 <_llm_rows.packet_batch.blocks+0x145c>
    21b0:      	ldr	q5, [sp, #0x50]
    21b4:      	sshll.4s	v5, v5, #0x0
    21b8:      	ldr	q6, [sp, #0x150]
    21bc:      	fsub.4s	v23, v6, v4
    21c0:      	ldr	q6, [sp, #0x160]
    21c4:      	fsub.4s	v6, v6, v4
    21c8:      	ldr	q19, [sp, #0x1b0]
    21cc:      	zip2.8b	v4, v19, v0
    21d0:      	ushll.4s	v4, v4, #0x0
    21d4:      	shl.4s	v4, v4, #0x1f
    21d8:      	cmlt.4s	v4, v4, #0
    21dc:      	and.16b	v6, v4, v6
    21e0:      	zip1.8b	v19, v19, v0
    21e4:      	ushll.4s	v19, v19, #0x0
    21e8:      	shl.4s	v19, v19, #0x1f
    21ec:      	cmlt.4s	v19, v19, #0
    21f0:      	and.16b	v23, v19, v23
    21f4:      	fcmge.4s	v24, v23, v7
    21f8:      	fcmge.4s	v25, v6, v7
    21fc:      	fcmge.4s	v26, v10, v23
    2200:      	fcmge.4s	v27, v10, v6
    2204:      	and.16b	v25, v25, v27
    2208:      	and.16b	v24, v24, v26
    220c:      	and.16b	v24, v24, v23
    2210:      	and.16b	v25, v25, v6
    2214:      	fmul.4s	v26, v25, v11
    2218:      	fmul.4s	v27, v24, v11
    221c:      	movi.4s	v29, #0x4b, lsl #24
    2220:      	mvni.4s	v30, #0x80, lsl #24
    2224:      	mov.16b	v28, v30
    2228:      	bsl.16b	v28, v29, v27
    222c:      	bif.16b	v29, v26, v30
    2230:      	fadd.4s	v26, v26, v29
    2234:      	fadd.4s	v27, v27, v28
    2238:      	fsub.4s	v27, v27, v28
    223c:      	fsub.4s	v26, v26, v29
    2240:      	fcvtzs.4s	v26, v26
    2244:      	fcvtzs.4s	v27, v27
    2248:      	scvtf.4s	v28, v27
    224c:      	scvtf.4s	v29, v26
    2250:      	fmul.4s	v30, v29, v3
    2254:      	fmul.4s	v3, v28, v3
    2258:      	fadd.4s	v3, v24, v3
    225c:      	fadd.4s	v24, v25, v30
    2260:      	fmul.4s	v25, v28, v2
    2264:      	fmul.4s	v2, v29, v2
    2268:      	fadd.4s	v2, v24, v2
    226c:      	fadd.4s	v3, v3, v25
    2270:      	fmul.4s	v24, v3, v21
    2274:      	fmul.4s	v21, v2, v21
    2278:      	fadd.4s	v21, v21, v22
    227c:      	fadd.4s	v22, v24, v22
    2280:      	fmul.4s	v22, v3, v22
    2284:      	fmul.4s	v21, v2, v21
    2288:      	fadd.4s	v21, v21, v16
    228c:      	fadd.4s	v16, v22, v16
    2290:      	fmul.4s	v16, v3, v16
    2294:      	fmul.4s	v21, v2, v21
    2298:      	fadd.4s	v21, v21, v17
    229c:      	fadd.4s	v16, v16, v17
    22a0:      	fmul.4s	v16, v3, v16
    22a4:      	fmul.4s	v17, v2, v21
    22a8:      	fadd.4s	v17, v17, v18
    22ac:      	fadd.4s	v16, v16, v18
    22b0:      	fmul.4s	v16, v3, v16
    22b4:      	fmul.4s	v17, v2, v17
    22b8:      	movi.4s	v18, #0x3f, lsl #24
    22bc:      	fadd.4s	v17, v17, v18
    22c0:      	fadd.4s	v16, v16, v18
    22c4:      	fmul.4s	v18, v2, v2
    22c8:      	fmul.4s	v21, v3, v3
    22cc:      	fmul.4s	v16, v21, v16
    22d0:      	fmul.4s	v17, v18, v17
    22d4:      	fadd.4s	v2, v2, v17
    22d8:      	fadd.4s	v3, v3, v16
    22dc:      	fadd.4s	v3, v3, v20
    22e0:      	fadd.4s	v2, v2, v20
    22e4:      	sshr.4s	v16, v27, #0x1
    22e8:      	sshr.4s	v17, v26, #0x1
    22ec:      	shl.4s	v18, v17, #0x17
    22f0:      	shl.4s	v21, v16, #0x17
    22f4:      	add.4s	v21, v21, v20
    22f8:      	add.4s	v18, v18, v20
    22fc:      	fmul.4s	v2, v2, v18
    2300:      	fmul.4s	v3, v3, v21
    2304:      	sub.4s	v17, v26, v17
    2308:      	sub.4s	v16, v27, v16
    230c:      	shl.4s	v16, v16, #0x17
    2310:      	shl.4s	v17, v17, #0x17
    2314:      	add.4s	v17, v17, v20
    2318:      	add.4s	v16, v16, v20
    231c:      	fmul.4s	v3, v3, v16
    2320:      	fmul.4s	v2, v2, v17
    2324:      	fcmgt.4s	v16, v7, v6
    2328:      	bic.16b	v2, v2, v16
    232c:      	fcmgt.4s	v7, v7, v23
    2330:      	bic.16b	v3, v3, v7
    2334:      	fcmgt.4s	v7, v6, v10
    2338:      	fcmgt.4s	v16, v23, v10
    233c:      	ldr	q17, [sp, #0x230]
    2340:      	bit.16b	v3, v17, v16
    2344:      	bit.16b	v2, v17, v7
    2348:      	fcmeq.4s	v7, v23, v23
    234c:      	fcmeq.4s	v6, v6, v6
    2350:      	ldr	q16, [sp, #0x220]
    2354:      	bif.16b	v2, v16, v6
    2358:      	bif.16b	v3, v16, v7
    235c:      	bic.16b	v6, v3, v5
    2360:      	ldr	q3, [sp, #0x90]
    2364:      	bic.16b	v5, v2, v3
    2368:      	ldr	x8, [sp, #0xc0]
    236c:      	add	x8, x23, x8
    2370:      	ldp	q2, q3, [x8]
    2374:      	bit.16b	v3, v5, v4
    2378:      	bit.16b	v2, v6, v19
    237c:      	stp	q2, q3, [x8]
    2380:      	ldp	q3, q2, [x23, #0x60]
    2384:      	and.16b	v2, v0, v2
    2388:      	and.16b	v3, v1, v3
    238c:      	ldp	q4, q7, [x23, #0x40]
    2390:      	and.16b	v7, v0, v7
    2394:      	and.16b	v4, v1, v4
    2398:      	ldp	q17, q16, [x23, #0x20]
    239c:      	and.16b	v16, v0, v16
    23a0:      	and.16b	v17, v1, v17
    23a4:      	ldp	q18, q19, [x23]
    23a8:      	and.16b	v19, v0, v19
    23ac:      	and.16b	v18, v1, v18
    23b0:      	ldp	q9, q8, [sp, #0x180]
    23b4:      	sshll.2d	v22, v1, #0x0
    23b8:      	sshll.2d	v23, v0, #0x0
    23bc:      	add	x8, x23, x1, lsl #5
    23c0:      	ldp	q20, q21, [x8]
    23c4:      	fadd.4s	v20, v18, v20
    23c8:      	fadd.4s	v21, v19, v21
    23cc:      	ldp	q25, q24, [x8, #0x20]
    23d0:      	fadd.4s	v25, v17, v25
    23d4:      	fadd.4s	v24, v16, v24
    23d8:      	ldp	q27, q26, [x8, #0x40]
    23dc:      	fadd.4s	v27, v4, v27
    23e0:      	fadd.4s	v26, v7, v26
    23e4:      	ldp	q29, q28, [x8, #0x60]
    23e8:      	fadd.4s	v29, v3, v29
    23ec:      	fadd.4s	v28, v2, v28
    23f0:      	dup.2d	v30, x0
    23f4:      	and.16b	v31, v9, v30
    23f8:      	add.2d	v12, v12, v31
    23fc:      	and.16b	v31, v8, v30
    2400:      	add.2d	v13, v13, v31
    2404:      	and.16b	v23, v23, v30
    2408:      	add.2d	v14, v14, v23
    240c:      	and.16b	v22, v22, v30
    2410:      	add.2d	v22, v15, v22
    2414:      	bit.16b	v19, v21, v0
    2418:      	bit.16b	v18, v20, v1
    241c:      	bit.16b	v16, v24, v0
    2420:      	bit.16b	v17, v25, v1
    2424:      	bit.16b	v7, v26, v0
    2428:      	bit.16b	v4, v27, v1
    242c:      	bit.16b	v2, v28, v0
    2430:      	bit.16b	v3, v29, v1
    2434:      	fmov	x8, d15
    2438:      	add	x9, x8, #0x4
    243c:      	tst	w10, #0x1
    2440:      	csel	x1, x9, x8, ne
    2444:      	mov.16b	v15, v22
    2448:      	cmp	x1, #0xc0
    244c:      	b.lt	0x23b4 <_llm_rows.packet_batch.blocks+0x1960>
    2450:      	mov	x8, #0x0                ; =0
    2454:      	fadd.4s	v19, v5, v19
    2458:      	fadd.4s	v18, v6, v18
    245c:      	ldr	q23, [sp, #0x1b0]
    2460:      	zip1.8b	v22, v23, v0
    2464:      	ushll.4s	v22, v22, #0x0
    2468:      	shl.4s	v22, v22, #0x1f
    246c:      	cmlt.4s	v22, v22, #0
    2470:      	and.16b	v18, v22, v18
    2474:      	zip2.8b	v22, v23, v0
    2478:      	ushll.4s	v22, v22, #0x0
    247c:      	shl.4s	v22, v22, #0x1f
    2480:      	cmlt.4s	v22, v22, #0
    2484:      	and.16b	v19, v22, v19
    2488:      	ldr	d24, [sp, #0x88]
    248c:      	zip2.8b	v22, v24, v0
    2490:      	ushll.4s	v22, v22, #0x0
    2494:      	shl.4s	v22, v22, #0x1f
    2498:      	cmlt.4s	v22, v22, #0
    249c:      	bit.16b	v19, v21, v22
    24a0:      	zip1.8b	v21, v24, v0
    24a4:      	ushll.4s	v21, v21, #0x0
    24a8:      	shl.4s	v21, v21, #0x1f
    24ac:      	cmlt.4s	v21, v21, #0
    24b0:      	bit.16b	v18, v20, v21
    24b4:      	fadd.4s	v17, v17, v18
    24b8:      	fadd.4s	v16, v16, v19
    24bc:      	fadd.4s	v7, v7, v16
    24c0:      	fadd.4s	v4, v4, v17
    24c4:      	fadd.4s	v3, v3, v4
    24c8:      	fadd.4s	v2, v2, v7
    24cc:      	add	x9, sp, #0x318
    24d0:      	bfxil	x9, x10, #0, #1
    24d4:      	ldr	q4, [sp, #0x1a0]
    24d8:      	str	d4, [sp, #0x318]
    24dc:      	ldrb	w9, [x9]
    24e0:      	add	x11, sp, #0x500
    24e4:      	bfi	x11, x10, #2, #1
    24e8:      	str	q2, [sp, #0x510]
    24ec:      	str	q3, [sp, #0x500]
    24f0:      	ldr	s4, [x11]
    24f4:      	ands	w1, w10, #0x1
    24f8:      	mov	w15, #0x2               ; =2
    24fc:      	csel	w13, w15, wzr, ne
    2500:      	csel	w30, w0, wzr, ne
    2504:      	tst	w1, w9
    2508:      	movi	d22, #0000000000000000
    250c:      	fcsel	s4, s4, s22, ne
    2510:      	tst	w27, #0x1
    2514:      	fcsel	s7, s3, s22, ne
    2518:      	ands	w9, w28, #0x1
    251c:      	mov	w11, #0x3               ; =3
    2520:      	csel	w11, w11, wzr, ne
    2524:      	add	x28, sp, #0x318
    2528:      	orr	x14, x28, x11
    252c:      	ldrb	w14, [x14]
    2530:      	add	x16, sp, #0x4e0
    2534:      	orr	x11, x16, x11, lsl #2
    2538:      	str	q2, [sp, #0x4f0]
    253c:      	str	q3, [sp, #0x4e0]
    2540:      	ldr	s16, [x11]
    2544:      	tst	w9, w14
    2548:      	fcsel	s16, s16, s22, ne
    254c:      	mov	x22, x19
    2550:      	ands	w14, w22, #0x1
    2554:      	csel	w9, w15, wzr, ne
    2558:      	orr	x11, x28, x9
    255c:      	ldrb	w11, [x11]
    2560:      	lsr	x9, x9, #1
    2564:      	add	x15, sp, #0x4c0
    2568:      	bfi	x15, x9, #3, #1
    256c:      	str	q2, [sp, #0x4d0]
    2570:      	str	q3, [sp, #0x4c0]
    2574:      	ldr	s17, [x15]
    2578:      	tst	w14, w11
    257c:      	fcsel	s17, s17, s22, ne
    2580:      	ands	w11, w24, #0x1
    2584:      	mov	w24, #0x6               ; =6
    2588:      	csel	w16, w24, wzr, ne
    258c:      	mov	w19, #0x5               ; =5
    2590:      	csel	w4, w19, wzr, ne
    2594:      	ldr	w9, [sp, #0x178]
    2598:      	ands	w6, w9, #0x1
    259c:      	mov	w9, #0x7                ; =7
    25a0:      	csel	w17, w9, wzr, ne
    25a4:      	csel	w15, w0, wzr, ne
    25a8:      	ldr	w0, [sp, #0x17c]
    25ac:      	ands	w3, w0, #0x1
    25b0:      	mov	w0, #0x4                ; =4
    25b4:      	csel	w0, w0, wzr, ne
    25b8:      	csel	w5, w9, wzr, ne
    25bc:      	ldr	w9, [sp, #0x7c]
    25c0:      	ands	w7, w9, #0x1
    25c4:      	csel	w9, w19, wzr, ne
    25c8:      	orr	x19, x28, x9
    25cc:      	ldrb	w19, [x19]
    25d0:      	str	q2, [sp, #0x4b0]
    25d4:      	str	q3, [sp, #0x4a0]
    25d8:      	add	x2, sp, #0x4a0
    25dc:      	ldr	s18, [x2, w9, uxtw #2]
    25e0:      	csel	w9, w24, wzr, ne
    25e4:      	tst	w7, w19
    25e8:      	orr	x19, x28, x0
    25ec:      	ldrb	w19, [x19]
    25f0:      	str	q2, [sp, #0x490]
    25f4:      	str	q3, [sp, #0x480]
    25f8:      	add	x2, sp, #0x480
    25fc:      	ldr	s19, [x2, w0, uxtw #2]
    2600:      	orr	x0, x28, x17
    2604:      	ldrb	w0, [x0]
    2608:      	str	q2, [sp, #0x470]
    260c:      	str	q3, [sp, #0x460]
    2610:      	add	x2, sp, #0x460
    2614:      	ldr	s20, [x2, w17, uxtw #2]
    2618:      	fcsel	s18, s18, s22, ne
    261c:      	tst	w3, w19
    2620:      	fcsel	s19, s19, s22, ne
    2624:      	tst	w6, w0
    2628:      	orr	x17, x28, x16
    262c:      	ldrb	w17, [x17]
    2630:      	str	q2, [sp, #0x450]
    2634:      	str	q3, [sp, #0x440]
    2638:      	add	x0, sp, #0x440
    263c:      	ldr	s21, [x0, w16, uxtw #2]
    2640:      	fcsel	s20, s20, s22, ne
    2644:      	tst	w11, w17
    2648:      	fcsel	s21, s21, s22, ne
    264c:      	mov.s	v18[1], v19[0]
    2650:      	mov.s	v18[2], v20[0]
    2654:      	mov.s	v18[3], v21[0]
    2658:      	mov.s	v4[1], v7[0]
    265c:      	mov.s	v4[2], v16[0]
    2660:      	lsr	x16, x13, #1
    2664:      	add	x17, sp, #0x420
    2668:      	bfi	x17, x16, #3, #1
    266c:      	mov.s	v4[3], v17[0]
    2670:      	fadd.4s	v3, v3, v4
    2674:      	fadd.4s	v2, v2, v18
    2678:      	orr	x13, x28, x13
    267c:      	ldrb	w13, [x13]
    2680:      	str	q2, [sp, #0x430]
    2684:      	str	q3, [sp, #0x420]
    2688:      	ldr	s4, [x17]
    268c:      	tst	w1, w13
    2690:      	fcsel	s4, s4, s22, ne
    2694:      	ldr	w13, [sp, #0xb4]
    2698:      	ands	w13, w13, #0x1
    269c:      	mov	w16, #0x3               ; =3
    26a0:      	csel	w16, w16, wzr, ne
    26a4:      	orr	x17, x28, x16
    26a8:      	ldrb	w17, [x17]
    26ac:      	tst	w13, w17
    26b0:      	add	x13, sp, #0x360
    26b4:      	orr	x13, x13, x16, lsl #2
    26b8:      	stp	q3, q2, [sp, #0x360]
    26bc:      	ldr	s7, [x13]
    26c0:      	add	x13, sp, #0x318
    26c4:      	bfxil	x13, x22, #0, #1
    26c8:      	ldrb	w13, [x13]
    26cc:      	fcsel	s7, s7, s22, ne
    26d0:      	ldr	w16, [sp, #0xa8]
    26d4:      	tst	w16, #0x1
    26d8:      	fcsel	s16, s3, s22, ne
    26dc:      	tst	w14, w13
    26e0:      	add	x13, sp, #0x400
    26e4:      	bfi	x13, x22, #2, #1
    26e8:      	str	q2, [sp, #0x410]
    26ec:      	str	q3, [sp, #0x400]
    26f0:      	ldr	s17, [x13]
    26f4:      	fcsel	s17, s17, s22, ne
    26f8:      	orr	x13, x28, x9
    26fc:      	ldrb	w13, [x13]
    2700:      	tst	w7, w13
    2704:      	stp	q3, q2, [sp, #0x3e0]
    2708:      	add	x13, sp, #0x3e0
    270c:      	ldr	s18, [x13, w9, uxtw #2]
    2710:      	orr	x9, x28, x5
    2714:      	ldrb	w9, [x9]
    2718:      	stp	q3, q2, [sp, #0x3c0]
    271c:      	add	x13, sp, #0x3c0
    2720:      	ldr	s19, [x13, w5, uxtw #2]
    2724:      	fcsel	s18, s18, s22, ne
    2728:      	tst	w3, w9
    272c:      	fcsel	s19, s19, s22, ne
    2730:      	orr	x9, x28, x15
    2734:      	ldrb	w9, [x9]
    2738:      	stp	q3, q2, [sp, #0x3a0]
    273c:      	add	x13, sp, #0x3a0
    2740:      	ldr	s20, [x13, w15, uxtw #2]
    2744:      	tst	w6, w9
    2748:      	fcsel	s20, s20, s22, ne
    274c:      	orr	x9, x28, x4
    2750:      	ldrb	w9, [x9]
    2754:      	stp	q3, q2, [sp, #0x380]
    2758:      	add	x13, sp, #0x380
    275c:      	ldr	s21, [x13, w4, uxtw #2]
    2760:      	tst	w11, w9
    2764:      	fcsel	s21, s21, s22, ne
    2768:      	mov.s	v4[1], v7[0]
    276c:      	mov.s	v4[2], v16[0]
    2770:      	mov.s	v4[3], v17[0]
    2774:      	mov.s	v18[1], v19[0]
    2778:      	mov.s	v18[2], v20[0]
    277c:      	mov.s	v18[3], v21[0]
    2780:      	fadd.4s	v3, v3, v4
    2784:      	fadd.4s	v2, v2, v18
    2788:      	orr	x9, x28, x30
    278c:      	ldrb	w9, [x9]
    2790:      	stp	q3, q2, [sp, #0x340]
    2794:      	add	x11, sp, #0x340
    2798:      	ldr	s2, [x11, w30, uxtw #2]
    279c:      	tst	w1, w9
    27a0:      	fcsel	s2, s2, s22, ne
    27a4:      	tst	w10, #0x1
    27a8:      	fadd	s2, s3, s2
    27ac:      	fcsel	s3, s2, s22, ne
    27b0:      	tst	w27, #0x1
    27b4:      	fcsel	s4, s2, s22, ne
    27b8:      	tst	w16, #0x1
    27bc:      	fcsel	s7, s2, s22, ne
    27c0:      	ldr	w9, [sp, #0x6c]
    27c4:      	tst	w9, #0x1
    27c8:      	fcsel	s16, s2, s22, ne
    27cc:      	ldr	w9, [sp, #0x80]
    27d0:      	tst	w9, #0x1
    27d4:      	fcsel	s17, s2, s22, ne
    27d8:      	ldp	w9, w11, [sp, #0x64]
    27dc:      	tst	w11, #0x1
    27e0:      	fcsel	s18, s2, s22, ne
    27e4:      	tst	w9, #0x1
    27e8:      	fcsel	s19, s2, s22, ne
    27ec:      	ldr	w9, [sp, #0x60]
    27f0:      	tst	w9, #0x1
    27f4:      	fcsel	s2, s2, s22, ne
    27f8:      	mov.s	v3[1], v4[0]
    27fc:      	mov.s	v3[2], v7[0]
    2800:      	mov.s	v3[3], v16[0]
    2804:      	mov.s	v17[1], v18[0]
    2808:      	mov.s	v17[2], v19[0]
    280c:      	mov.s	v17[3], v2[0]
    2810:      	stp	q3, q17, [sp, #0x320]
    2814:      	ldr	x9, [sp, #0xb8]
    2818:      	and	x9, x9, #0x7
    281c:      	add	x10, sp, #0x320
    2820:      	ldr	s2, [x10, x9, lsl #2]
    2824:      	fadd	s2, s2, s22
    2828:      	dup.4s	v2, v2[0]
    282c:      	ldp	x9, x13, [sp, #0x118]
    2830:      	add	x9, x13, x9
    2834:      	movi.2d	v3, #0000000000000000
    2838:      	movi.2d	v4, #0000000000000000
    283c:      	movi.2d	v7, #0000000000000000
    2840:      	movi.2d	v16, #0000000000000000
    2844:      	ldr	w19, [sp, #0x38]
    2848:      	add	x4, sp, #0x6, lsl #12   ; =0x6000
    284c:      	add	x4, x4, #0xf50
    2850:      	adrp	x16, 0x2000 <_llm_rows.packet_batch.blocks+0x15ac>
    2854:      	adrp	x17, 0x2000 <_llm_rows.packet_batch.blocks+0x15ac>
    2858:      	adrp	x0, 0x2000 <_llm_rows.packet_batch.blocks+0x15ac>
    285c:      	adrp	x1, 0x2000 <_llm_rows.packet_batch.blocks+0x15ac>
    2860:      	add	x5, sp, #0x3, lsl #12   ; =0x3000
    2864:      	add	x5, x5, #0xf10
    2868:      	movi.8b	v10, #0x1
    286c:      	ldp	q20, q19, [sp, #0x250]
    2870:      	ldr	x14, [sp, #0x110]
    2874:      	ldr	q21, [sp, #0x240]
    2878:      	ldp	q24, q22, [sp, #0x270]
    287c:      	b	0x28a4 <_llm_rows.packet_batch.blocks+0x1e50>
    2880:      	add.2d	v17, v3, v24
    2884:      	add.2d	v4, v4, v21
    2888:      	add.2d	v7, v7, v22
    288c:      	add.2d	v16, v16, v20
    2890:      	fmov	x8, d3
    2894:      	add	x8, x8, x12
    2898:      	mov.16b	v3, v17
    289c:      	cmp	x8, #0xc0
    28a0:      	b.ge	0x2954 <_llm_rows.packet_batch.blocks+0x1f00>
    28a4:      	fmov	w10, s19
    28a8:      	lsl	x8, x8, #5
    28ac:      	add	x11, x23, x8
    28b0:      	ldp	q18, q17, [x11]
    28b4:      	and.16b	v18, v1, v18
    28b8:      	fdiv.4s	v18, v18, v2
    28bc:      	add	x8, x9, x8
    28c0:      	tbnz	w10, #0x0, 0x28f0 <_llm_rows.packet_batch.blocks+0x1e9c>
    28c4:      	and	w10, w10, #0xff
    28c8:      	tbnz	w10, #0x1, 0x28fc <_llm_rows.packet_batch.blocks+0x1ea8>
    28cc:      	tbnz	w10, #0x2, 0x2908 <_llm_rows.packet_batch.blocks+0x1eb4>
    28d0:      	tbnz	w10, #0x3, 0x2914 <_llm_rows.packet_batch.blocks+0x1ec0>
    28d4:      	and.16b	v17, v0, v17
    28d8:      	fdiv.4s	v17, v17, v2
    28dc:      	tbnz	w10, #0x4, 0x2928 <_llm_rows.packet_batch.blocks+0x1ed4>
    28e0:      	tbnz	w10, #0x5, 0x2930 <_llm_rows.packet_batch.blocks+0x1edc>
    28e4:      	tbnz	w10, #0x6, 0x293c <_llm_rows.packet_batch.blocks+0x1ee8>
    28e8:      	tbz	w10, #0x7, 0x2880 <_llm_rows.packet_batch.blocks+0x1e2c>
    28ec:      	b	0x2948 <_llm_rows.packet_batch.blocks+0x1ef4>
    28f0:      	str	s18, [x8]
    28f4:      	and	w10, w10, #0xff
    28f8:      	tbz	w10, #0x1, 0x28cc <_llm_rows.packet_batch.blocks+0x1e78>
    28fc:      	add	x11, x8, #0x4
    2900:      	st1.s	{ v18 }[1], [x11]
    2904:      	tbz	w10, #0x2, 0x28d0 <_llm_rows.packet_batch.blocks+0x1e7c>
    2908:      	add	x11, x8, #0x8
    290c:      	st1.s	{ v18 }[2], [x11]
    2910:      	tbz	w10, #0x3, 0x28d4 <_llm_rows.packet_batch.blocks+0x1e80>
    2914:      	add	x11, x8, #0xc
    2918:      	st1.s	{ v18 }[3], [x11]
    291c:      	and.16b	v17, v0, v17
    2920:      	fdiv.4s	v17, v17, v2
    2924:      	tbz	w10, #0x4, 0x28e0 <_llm_rows.packet_batch.blocks+0x1e8c>
    2928:      	str	s17, [x8, #0x10]
    292c:      	tbz	w10, #0x5, 0x28e4 <_llm_rows.packet_batch.blocks+0x1e90>
    2930:      	add	x11, x8, #0x14
    2934:      	st1.s	{ v17 }[1], [x11]
    2938:      	tbz	w10, #0x6, 0x28e8 <_llm_rows.packet_batch.blocks+0x1e94>
    293c:      	add	x11, x8, #0x18
    2940:      	st1.s	{ v17 }[2], [x11]
    2944:      	tbz	w10, #0x7, 0x2880 <_llm_rows.packet_batch.blocks+0x1e2c>
    2948:      	add	x8, x8, #0x1c
    294c:      	st1.s	{ v17 }[3], [x8]
    2950:      	b	0x2880 <_llm_rows.packet_batch.blocks+0x1e2c>
    2954:      	ldr	d0, [sp, #0xc8]
    2958:      	fmov	w8, s0
    295c:      	zip1.8b	v0, v23, v0
    2960:      	ushll.4s	v0, v0, #0x0
    2964:      	shl.4s	v0, v0, #0x1f
    2968:      	cmlt.4s	v0, v0, #0
    296c:      	and.16b	v0, v0, v6
    2970:      	fdiv.4s	v0, v0, v2
    2974:      	ldr	q3, [sp, #0x100]
    2978:      	ldp	q4, q6, [sp, #0xe0]
    297c:      	stp	q3, q4, [sp, #0x2d0]
    2980:      	ldr	q1, [sp, #0xd0]
    2984:      	stp	q6, q1, [sp, #0x2f0]
    2988:      	and	x9, x14, #0x7
    298c:      	add	x10, sp, #0x2d0
    2990:      	ldr	x9, [x10, x9, lsl #3]
    2994:      	sub	x9, x9, x14
    2998:      	add	x9, x13, x9, lsl #2
    299c:      	tbnz	w8, #0x0, 0x2a30 <_llm_rows.packet_batch.blocks+0x1fdc>
    29a0:      	ldr	w22, [sp, #0x12c]
    29a4:      	tbnz	w8, #0x1, 0x2a3c <_llm_rows.packet_batch.blocks+0x1fe8>
    29a8:      	tbnz	w8, #0x2, 0x2a48 <_llm_rows.packet_batch.blocks+0x1ff4>
    29ac:      	tbz	w8, #0x3, 0x29b8 <_llm_rows.packet_batch.blocks+0x1f64>
    29b0:      	add	x10, x9, #0xc
    29b4:      	st1.s	{ v0 }[3], [x10]
    29b8:      	zip2.8b	v0, v23, v0
    29bc:      	ushll.4s	v0, v0, #0x0
    29c0:      	shl.4s	v0, v0, #0x1f
    29c4:      	cmlt.4s	v0, v0, #0
    29c8:      	and.16b	v0, v0, v5
    29cc:      	fdiv.4s	v0, v0, v2
    29d0:      	tbnz	w8, #0x4, 0x2a58 <_llm_rows.packet_batch.blocks+0x2004>
    29d4:      	tbnz	w8, #0x5, 0x2a60 <_llm_rows.packet_batch.blocks+0x200c>
    29d8:      	tbnz	w8, #0x6, 0x2a6c <_llm_rows.packet_batch.blocks+0x2018>
    29dc:      	tbz	w8, #0x7, 0xb34 <_llm_rows.packet_batch.blocks+0xe0>
    29e0:      	b	0x2a78 <_llm_rows.packet_batch.blocks+0x2024>
    29e4:      	fmov	x14, d6
    29e8:      	ld1.b	{ v3 }[2], [x14]
    29ec:      	tbz	w11, #0x3, 0x1760 <_llm_rows.packet_batch.blocks+0xd0c>
    29f0:      	ld1.b	{ v3 }[3], [x13]
    29f4:      	tbz	w11, #0x4, 0x1764 <_llm_rows.packet_batch.blocks+0xd10>
    29f8:      	fmov	x13, d5
    29fc:      	ld1.b	{ v3 }[4], [x13]
    2a00:      	tbz	w11, #0x5, 0x1768 <_llm_rows.packet_batch.blocks+0xd14>
    2a04:      	ld1.b	{ v3 }[5], [x9]
    2a08:      	tbz	w11, #0x6, 0x176c <_llm_rows.packet_batch.blocks+0xd18>
    2a0c:      	fmov	x9, d4
    2a10:      	ld1.b	{ v3 }[6], [x9]
    2a14:      	stp	q26, q25, [sp, #0x200]
    2a18:      	stp	q29, q28, [sp, #0x1e0]
    2a1c:      	stp	q14, q31, [sp, #0x250]
    2a20:      	str	q15, [sp, #0x240]
    2a24:      	str	d19, [sp, #0xc8]
    2a28:      	tbnz	w11, #0x7, 0x1784 <_llm_rows.packet_batch.blocks+0xd30>
    2a2c:      	b	0x1788 <_llm_rows.packet_batch.blocks+0xd34>
    2a30:      	str	s0, [x9]
    2a34:      	ldr	w22, [sp, #0x12c]
    2a38:      	tbz	w8, #0x1, 0x29a8 <_llm_rows.packet_batch.blocks+0x1f54>
    2a3c:      	add	x10, x9, #0x4
    2a40:      	st1.s	{ v0 }[1], [x10]
    2a44:      	tbz	w8, #0x2, 0x29ac <_llm_rows.packet_batch.blocks+0x1f58>
    2a48:      	add	x10, x9, #0x8
    2a4c:      	st1.s	{ v0 }[2], [x10]
    2a50:      	tbnz	w8, #0x3, 0x29b0 <_llm_rows.packet_batch.blocks+0x1f5c>
    2a54:      	b	0x29b8 <_llm_rows.packet_batch.blocks+0x1f64>
    2a58:      	str	s0, [x9, #0x10]
    2a5c:      	tbz	w8, #0x5, 0x29d8 <_llm_rows.packet_batch.blocks+0x1f84>
    2a60:      	add	x10, x9, #0x14
    2a64:      	st1.s	{ v0 }[1], [x10]
    2a68:      	tbz	w8, #0x6, 0x29dc <_llm_rows.packet_batch.blocks+0x1f88>
    2a6c:      	add	x10, x9, #0x18
    2a70:      	st1.s	{ v0 }[2], [x10]
    2a74:      	tbz	w8, #0x7, 0xb34 <_llm_rows.packet_batch.blocks+0xe0>
    2a78:      	add	x8, x9, #0x1c
    2a7c:      	st1.s	{ v0 }[3], [x8]
    2a80:      	b	0xb34 <_llm_rows.packet_batch.blocks+0xe0>
    2a84:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
    2a88:      	add	sp, sp, #0x770
    2a8c:      	ldp	x29, x30, [sp, #0x90]
    2a90:      	ldp	x20, x19, [sp, #0x80]
    2a94:      	ldp	x22, x21, [sp, #0x70]
    2a98:      	ldp	x24, x23, [sp, #0x60]
    2a9c:      	ldp	x26, x25, [sp, #0x50]
    2aa0:      	ldp	x28, x27, [sp, #0x40]
    2aa4:      	ldp	d9, d8, [sp, #0x30]
    2aa8:      	ldp	d11, d10, [sp, #0x20]
    2aac:      	ldp	d13, d12, [sp, #0x10]
    2ab0:      	ldp	d15, d14, [sp], #0xa0
    2ab4:      	ret

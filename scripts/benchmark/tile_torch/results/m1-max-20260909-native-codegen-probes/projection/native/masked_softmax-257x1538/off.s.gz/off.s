
/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/masked_softmax-257x1538/off/object/tile_xir_w8_37953_1788936538770988_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0x90]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x26, x25, [sp, #0x40]
      14:      	stp	x24, x23, [sp, #0x50]
      18:      	stp	x22, x21, [sp, #0x60]
      1c:      	stp	x20, x19, [sp, #0x70]
      20:      	stp	x29, x30, [sp, #0x80]
      24:      	sub	sp, sp, #0x7, lsl #12   ; =0x7000
      28:      	sub	sp, sp, #0xed0
      2c:      	add	x21, sp, #0x3, lsl #12  ; =0x3000
      30:      	add	x21, x21, #0x670
      34:      	ldr	x22, [x0]
      38:      	ldr	x19, [x0, #0x30]
      3c:      	ldr	w8, [x1]
      40:      	ldr	w9, [x1, #0x24]
      44:      	add	w8, w9, w8, lsl #5
      48:      	lsr	w8, w8, #3
      4c:      	dup.4s	v0, w8
      50:      	str	q0, [sp, #0x10]
      54:      	fmov	s0, w8
      58:      	ushll.2d	v0, v0, #0x0
      5c:      	fmov	x23, d0
      60:      	mov	w24, #0x1808            ; =6152
      64:      	umull	x20, w23, w24
      68:      	umaddl	x1, w23, w24, x22
      6c:      	mov	w25, #0x1800            ; =6144
      70:      	add	x0, sp, #0x6, lsl #12   ; =0x6000
      74:      	add	x0, x0, #0x6b0
      78:      	mov	w2, #0x1800             ; =6144
      7c:      	bl	0x7c <ltmp0+0x7c>
      80:      	mov	x9, #0x0                ; =0
      84:      	umaddl	x8, w23, w24, x25
      88:      	add	x10, x22, x8
      8c:      	add	x11, x10, #0x4
      90:      	ldr	s5, [x10]
      94:      	ld1.s	{ v5 }[1], [x11]
      98:      	str	q5, [x21, #0x4840]
      9c:      	movi.2d	v0, #0000000000000000
      a0:      	adrp	x10, 0x0 <ltmp0>
      a4:      	ldr	q1, [x10]
      a8:      	adrp	x10, 0x0 <ltmp0>
      ac:      	ldr	q2, [x10]
      b0:      	adrp	x10, 0x0 <ltmp0>
      b4:      	ldr	q3, [x10]
      b8:      	adrp	x10, 0x0 <ltmp0>
      bc:      	ldr	q4, [x10]
      c0:      	mov	w10, #0x1               ; =1
      c4:      	dup.2d	v6, x10
      c8:      	movi.2d	v7, #0000000000000000
      cc:      	movi.2d	v16, #0000000000000000
      d0:      	movi.2d	v17, #0000000000000000
      d4:      	shl.2d	v18, v0, #0x3
      d8:      	shl.2d	v19, v7, #0x3
      dc:      	shl.2d	v20, v16, #0x3
      e0:      	shl.2d	v21, v17, #0x3
      e4:      	orr.16b	v21, v21, v1
      e8:      	orr.16b	v20, v20, v2
      ec:      	orr.16b	v19, v19, v3
      f0:      	orr.16b	v18, v18, v4
      f4:      	add	x9, x21, x9, lsl #6
      f8:      	stp	q18, q19, [x9]
      fc:      	stp	q20, q21, [x9, #0x20]
     100:      	add.2d	v16, v16, v6
     104:      	add.2d	v7, v7, v6
     108:      	add.2d	v17, v17, v6
     10c:      	add.2d	v0, v0, v6
     110:      	fmov	x9, d0
     114:      	cmp	x9, #0xc0
     118:      	b.lt	0xd4 <ltmp0+0xd4>
     11c:      	mov	x10, #0x0               ; =0
     120:      	adrp	x9, 0x0 <ltmp0>
     124:      	ldr	q0, [x9]
     128:      	str	q0, [x21, #0x3000]
     12c:      	mov	w9, #0x1da1             ; =7585
     130:      	movk	w9, #0xaa7, lsl #16
     134:      	dup.4s	v0, w9
     138:      	ldr	q16, [sp, #0x10]
     13c:      	umull2.2d	v1, v16, v0
     140:      	umull.2d	v2, v16, v0
     144:      	uzp2.4s	v2, v2, v1
     148:      	ushr.4s	v2, v2, #0x6
     14c:      	mov	w9, #0x602              ; =1538
     150:      	dup.4s	v3, w9
     154:      	mov.16b	v4, v16
     158:      	mls.4s	v4, v2, v3
     15c:      	umull.2d	v0, v16, v0
     160:      	uzp2.4s	v0, v0, v1
     164:      	ushr.4s	v0, v0, #0x6
     168:      	mls.4s	v16, v0, v3
     16c:      	ushll2.2d	v6, v16, #0x0
     170:      	ushll2.2d	v7, v4, #0x0
     174:      	ushll.2d	v16, v16, #0x0
     178:      	ushll.2d	v17, v4, #0x0
     17c:      	movi.2d	v18, #0000000000000000
     180:      	add	x9, sp, #0x3, lsl #12   ; =0x3000
     184:      	add	x9, x9, #0x68
     188:      	dup.2d	v19, x9
     18c:      	adrp	x9, 0x0 <ltmp0>
     190:      	ldr	q0, [x9]
     194:      	adrp	x9, 0x0 <ltmp0>
     198:      	ldr	q1, [x9]
     19c:      	adrp	x9, 0x0 <ltmp0>
     1a0:      	ldr	q2, [x9]
     1a4:      	mov	w9, #0x1                ; =1
     1a8:      	dup.2d	v20, x9
     1ac:      	adrp	x9, 0x0 <ltmp0>
     1b0:      	ldr	q3, [x9]
     1b4:      	add	x9, sp, #0x3, lsl #12   ; =0x3000
     1b8:      	add	x9, x9, #0x670
     1bc:      	movi.8b	v21, #0x1
     1c0:      	movi.2d	v22, #0000000000000000
     1c4:      	movi.2d	v23, #0000000000000000
     1c8:      	movi.2d	v24, #0000000000000000
     1cc:      	add	x10, x9, x10, lsl #6
     1d0:      	ldp	q26, q25, [x10, #0x20]
     1d4:      	ldp	q27, q28, [x10]
     1d8:      	add.2d	v29, v24, v3
     1dc:      	add.2d	v29, v29, v19
     1e0:      	add.2d	v30, v23, v2
     1e4:      	add.2d	v31, v22, v1
     1e8:      	add.2d	v8, v18, v0
     1ec:      	add.2d	v8, v8, v19
     1f0:      	cmge.2d	v28, v7, v28
     1f4:      	cmge.2d	v27, v17, v27
     1f8:      	uzp1.4s	v27, v27, v28
     1fc:      	cmge.2d	v26, v16, v26
     200:      	cmge.2d	v25, v6, v25
     204:      	uzp1.4s	v25, v26, v25
     208:      	uzp1.8h	v25, v27, v25
     20c:      	xtn.8b	v25, v25
     210:      	and.8b	v25, v25, v21
     214:      	mov.d	x10, v8[1]
     218:      	fmov	x11, d8
     21c:      	str	b25, [x11]
     220:      	st1.b	{ v25 }[1], [x10]
     224:      	add.2d	v26, v31, v19
     228:      	mov.d	x10, v26[1]
     22c:      	fmov	x11, d26
     230:      	st1.b	{ v25 }[2], [x11]
     234:      	add.2d	v26, v30, v19
     238:      	st1.b	{ v25 }[3], [x10]
     23c:      	mov.d	x10, v26[1]
     240:      	fmov	x11, d26
     244:      	st1.b	{ v25 }[4], [x11]
     248:      	st1.b	{ v25 }[5], [x10]
     24c:      	mov.d	x10, v29[1]
     250:      	fmov	x11, d29
     254:      	st1.b	{ v25 }[6], [x11]
     258:      	st1.b	{ v25 }[7], [x10]
     25c:      	add.2d	v23, v23, v20
     260:      	add.2d	v22, v22, v20
     264:      	add.2d	v24, v24, v20
     268:      	add.2d	v18, v18, v20
     26c:      	fmov	x10, d18
     270:      	cmp	x10, #0xc0
     274:      	b.lt	0x1cc <ltmp0+0x1cc>
     278:      	mov	x10, #0x0               ; =0
     27c:      	adrp	x9, 0x0 <ltmp0>
     280:      	ldr	q16, [x9]
     284:      	add	x9, sp, #0x3, lsl #12   ; =0x3000
     288:      	add	x9, x9, #0x68
     28c:      	dup.2d	v6, x9
     290:      	adrp	x9, 0x0 <ltmp0>
     294:      	ldr	q7, [x9]
     298:      	add.2d	v7, v6, v7
     29c:      	cmhs.4s	v4, v4, v16
     2a0:      	xtn.4h	v4, v4
     2a4:      	uzp1.8b	v4, v4, v0
     2a8:      	movi.8b	v16, #0x1
     2ac:      	and.8b	v4, v4, v16
     2b0:      	fmov	x9, d7
     2b4:      	str	b4, [x9]
     2b8:      	mov.d	x9, v7[1]
     2bc:      	st1.b	{ v4 }[1], [x9]
     2c0:      	movi.2d	v4, #0000000000000000
     2c4:      	add	x11, sp, #0x6, lsl #12  ; =0x6000
     2c8:      	add	x11, x11, #0x6b0
     2cc:      	mov	w12, #0xf2ca            ; =62154
     2d0:      	movk	w12, #0xf149, lsl #16
     2d4:      	dup.4s	v16, w12
     2d8:      	mov	w12, #0x1               ; =1
     2dc:      	dup.2d	v17, x12
     2e0:      	add	x12, sp, #0x1, lsl #12  ; =0x1000
     2e4:      	add	x12, x12, #0x848
     2e8:      	movi.2d	v18, #0000000000000000
     2ec:      	movi.2d	v19, #0000000000000000
     2f0:      	movi.2d	v20, #0000000000000000
     2f4:      	add.2d	v21, v20, v3
     2f8:      	add.2d	v21, v21, v6
     2fc:      	add.2d	v22, v19, v2
     300:      	add.2d	v22, v22, v6
     304:      	add.2d	v23, v18, v1
     308:      	add.2d	v23, v23, v6
     30c:      	add.2d	v24, v4, v0
     310:      	add.2d	v24, v24, v6
     314:      	mov.d	x13, v24[1]
     318:      	mov.d	x14, v23[1]
     31c:      	fmov	x15, d24
     320:      	fmov	x16, d23
     324:      	mov.d	x17, v22[1]
     328:      	fmov	x0, d22
     32c:      	ldr	b22, [x15]
     330:      	ld1.b	{ v22 }[1], [x13]
     334:      	ld1.b	{ v22 }[2], [x16]
     338:      	mov.d	x13, v21[1]
     33c:      	ld1.b	{ v22 }[3], [x14]
     340:      	ld1.b	{ v22 }[4], [x0]
     344:      	ld1.b	{ v22 }[5], [x17]
     348:      	fmov	x14, d21
     34c:      	ld1.b	{ v22 }[6], [x14]
     350:      	ld1.b	{ v22 }[7], [x13]
     354:      	cmeq.8b	v21, v22, #0
     358:      	sshll.8h	v21, v21, #0x0
     35c:      	sshll2.4s	v22, v21, #0x0
     360:      	lsl	x10, x10, #5
     364:      	add	x13, x11, x10
     368:      	ldp	q24, q23, [x13]
     36c:      	sshll.4s	v21, v21, #0x0
     370:      	bsl.16b	v21, v16, v24
     374:      	bsl.16b	v22, v16, v23
     378:      	add	x10, x12, x10
     37c:      	stp	q21, q22, [x10]
     380:      	add.2d	v19, v19, v17
     384:      	add.2d	v18, v18, v17
     388:      	add.2d	v20, v20, v17
     38c:      	add.2d	v4, v4, v17
     390:      	fmov	x10, d4
     394:      	cmp	x10, #0xc0
     398:      	b.lt	0x2f4 <ltmp0+0x2f4>
     39c:      	fmov	x10, d7
     3a0:      	ldr	b4, [x10]
     3a4:      	ld1.b	{ v4 }[1], [x9]
     3a8:      	cmeq.8b	v4, v4, #0
     3ac:      	sshll.8h	v4, v4, #0x0
     3b0:      	mov	w9, #0xf2ca             ; =62154
     3b4:      	movk	w9, #0xf149, lsl #16
     3b8:      	dup.4s	v6, w9
     3bc:      	str	q4, [sp, #0x10]
     3c0:      	sshll.4s	v7, v4, #0x0
     3c4:      	bif.16b	v6, v5, v7
     3c8:      	add	x9, sp, #0x2, lsl #12   ; =0x2000
     3cc:      	add	x9, x9, #0xf49
     3d0:      	ldur	q7, [x9, #0xff]
     3d4:      	mov.16b	v5, v6
     3d8:      	mov.d	v5[1], v7[1]
     3dc:      	add	x9, sp, #0x2, lsl #12   ; =0x2000
     3e0:      	add	x9, x9, #0xf49
     3e4:      	stur	q5, [x9, #0xff]
     3e8:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     3ec:      	add	x9, x9, #0x759
     3f0:      	ldur	q7, [x9, #0xff]
     3f4:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     3f8:      	add	x9, x9, #0x749
     3fc:      	ldur	q21, [x9, #0xff]
     400:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     404:      	add	x9, x9, #0x779
     408:      	ldur	q20, [x9, #0xff]
     40c:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     410:      	add	x9, x9, #0x769
     414:      	ldur	q19, [x9, #0xff]
     418:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     41c:      	add	x9, x9, #0x799
     420:      	ldur	q16, [x9, #0xff]
     424:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     428:      	add	x9, x9, #0x789
     42c:      	ldur	q22, [x9, #0xff]
     430:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     434:      	add	x9, x9, #0x7b9
     438:      	ldur	q18, [x9, #0xff]
     43c:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     440:      	add	x9, x9, #0x7a9
     444:      	ldur	q17, [x9, #0xff]
     448:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     44c:      	add	x9, x9, #0x848
     450:      	add	x9, x9, #0xe0
     454:      	mov	w10, #0x4               ; =4
     458:      	ldp	q23, q24, [x9, #-0x60]
     45c:      	fmaxnm.4s	v7, v7, v24
     460:      	fmaxnm.4s	v21, v21, v23
     464:      	ldp	q23, q24, [x9, #-0x40]
     468:      	fmaxnm.4s	v20, v20, v24
     46c:      	fmaxnm.4s	v19, v19, v23
     470:      	ldp	q23, q24, [x9, #-0x20]
     474:      	fmaxnm.4s	v16, v16, v24
     478:      	fmaxnm.4s	v22, v22, v23
     47c:      	ldp	q23, q24, [x9], #0x80
     480:      	fmaxnm.4s	v18, v18, v24
     484:      	fmaxnm.4s	v17, v17, v23
     488:      	cmp	x10, #0xbc
     48c:      	add	x10, x10, #0x4
     490:      	b.lo	0x458 <ltmp0+0x458>
     494:      	mov	x1, #0x0                ; =0
     498:      	movi.2d	v23, #0000000000000000
     49c:      	mov.d	v23[0], v6[0]
     4a0:      	fmaxnm.4s	v6, v21, v23
     4a4:      	mov.d	v6[1], v21[1]
     4a8:      	fmaxnm.4s	v7, v7, v20
     4ac:      	fmaxnm.4s	v6, v6, v19
     4b0:      	fmaxnm.4s	v6, v6, v22
     4b4:      	fmaxnm.4s	v7, v7, v16
     4b8:      	fmaxnm.4s	v7, v7, v18
     4bc:      	fmaxnm.4s	v6, v6, v17
     4c0:      	rev64.4s	v16, v6
     4c4:      	rev64.4s	v17, v7
     4c8:      	fmaxnm.4s	v7, v7, v17
     4cc:      	fmaxnm.4s	v6, v6, v16
     4d0:      	ext.16b	v16, v6, v6, #0x8
     4d4:      	ext.16b	v17, v7, v7, #0x8
     4d8:      	fmaxnm.4s	v7, v7, v17
     4dc:      	fmaxnm.4s	v6, v6, v16
     4e0:      	fmaxnm.4s	v6, v6, v7
     4e4:      	mov	w9, #-0x800000          ; =-8388608
     4e8:      	fmov	s7, w9
     4ec:      	fmaxnm	s4, s6, s7
     4f0:      	str	q4, [sp]
     4f4:      	dup.4s	v7, v4[0]
     4f8:      	add	x9, sp, #0x3, lsl #12   ; =0x3000
     4fc:      	add	x9, x9, #0x68
     500:      	dup.2d	v16, x9
     504:      	movi.2d	v17, #0000000000000000
     508:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     50c:      	add	x9, x9, #0x848
     510:      	mov	w10, #-0x3d300000       ; =-1026555904
     514:      	dup.4s	v18, w10
     518:      	mov	w10, #0x42c80000        ; =1120403456
     51c:      	dup.4s	v19, w10
     520:      	mov	w10, #0xaa3b            ; =43579
     524:      	movk	w10, #0x3fb8, lsl #16
     528:      	dup.4s	v20, w10
     52c:      	movi.4s	v21, #0x4b, lsl #24
     530:      	mvni.4s	v22, #0x80, lsl #24
     534:      	mov	w10, #0x7200            ; =29184
     538:      	movk	w10, #0xbf31, lsl #16
     53c:      	mov	w11, #0xbe8e            ; =48782
     540:      	movk	w11, #0xb5bf, lsl #16
     544:      	mov	w12, #0x2bda            ; =11226
     548:      	movk	w12, #0x3950, lsl #16
     54c:      	mov	w13, #0x96c9            ; =38601
     550:      	movk	w13, #0x3ab6, lsl #16
     554:      	mov	w14, #0x88a6            ; =34982
     558:      	movk	w14, #0x3c08, lsl #16
     55c:      	mov	w15, #0xaa7a            ; =43642
     560:      	movk	w15, #0x3d2a, lsl #16
     564:      	mov	w16, #0xaaab            ; =43691
     568:      	movk	w16, #0x3e2a, lsl #16
     56c:      	movi.4s	v23, #0x3f, lsl #24
     570:      	mvni.4s	v24, #0x7f, msl #16
     574:      	fneg.4s	v24, v24
     578:      	mvni.4s	v25, #0x3f, msl #16
     57c:      	fneg.4s	v25, v25
     580:      	add	x17, sp, #0x28
     584:      	mov	w0, #0x1                ; =1
     588:      	movi.2d	v26, #0000000000000000
     58c:      	movi.2d	v27, #0000000000000000
     590:      	movi.2d	v28, #0000000000000000
     594:      	add.2d	v29, v28, v3
     598:      	add.2d	v29, v29, v16
     59c:      	add.2d	v30, v27, v2
     5a0:      	add.2d	v30, v30, v16
     5a4:      	add.2d	v31, v26, v1
     5a8:      	add.2d	v8, v17, v0
     5ac:      	add.2d	v31, v31, v16
     5b0:      	add.2d	v8, v8, v16
     5b4:      	mov.d	x2, v8[1]
     5b8:      	fmov	x3, d8
     5bc:      	mov.d	x4, v31[1]
     5c0:      	fmov	x5, d31
     5c4:      	mov.d	x6, v30[1]
     5c8:      	fmov	x7, d30
     5cc:      	mov.d	x21, v29[1]
     5d0:      	fmov	x22, d29
     5d4:      	ldr	b29, [x3]
     5d8:      	ld1.b	{ v29 }[1], [x2]
     5dc:      	ld1.b	{ v29 }[2], [x5]
     5e0:      	ld1.b	{ v29 }[3], [x4]
     5e4:      	lsl	x1, x1, #5
     5e8:      	add	x2, x9, x1
     5ec:      	ld1.b	{ v29 }[4], [x7]
     5f0:      	ldp	q31, q30, [x2]
     5f4:      	fsub.4s	v30, v30, v7
     5f8:      	fsub.4s	v31, v31, v7
     5fc:      	ld1.b	{ v29 }[5], [x6]
     600:      	fcmge.4s	v8, v31, v18
     604:      	fcmge.4s	v9, v30, v18
     608:      	fcmge.4s	v10, v19, v31
     60c:      	fcmge.4s	v11, v19, v30
     610:      	ld1.b	{ v29 }[6], [x22]
     614:      	and.16b	v9, v9, v11
     618:      	and.16b	v8, v8, v10
     61c:      	and.16b	v8, v8, v31
     620:      	and.16b	v9, v9, v30
     624:      	ld1.b	{ v29 }[7], [x21]
     628:      	fmul.4s	v10, v9, v20
     62c:      	fmul.4s	v11, v8, v20
     630:      	mov.16b	v12, v22
     634:      	bsl.16b	v12, v21, v11
     638:      	mov.16b	v13, v22
     63c:      	bsl.16b	v13, v21, v10
     640:      	fadd.4s	v10, v10, v13
     644:      	cmeq.8b	v29, v29, #0
     648:      	fadd.4s	v11, v11, v12
     64c:      	fsub.4s	v11, v11, v12
     650:      	fsub.4s	v10, v10, v13
     654:      	fcvtzs.4s	v10, v10
     658:      	fcvtzs.4s	v11, v11
     65c:      	sshll.8h	v29, v29, #0x0
     660:      	scvtf.4s	v12, v11
     664:      	scvtf.4s	v13, v10
     668:      	dup.4s	v14, w10
     66c:      	fmul.4s	v15, v13, v14
     670:      	fmul.4s	v14, v12, v14
     674:      	fadd.4s	v14, v8, v14
     678:      	fadd.4s	v9, v9, v15
     67c:      	dup.4s	v15, w11
     680:      	fmul.4s	v12, v12, v15
     684:      	sshll2.4s	v8, v29, #0x0
     688:      	fmul.4s	v13, v13, v15
     68c:      	fadd.4s	v9, v9, v13
     690:      	fadd.4s	v12, v14, v12
     694:      	dup.4s	v13, w12
     698:      	fmul.4s	v14, v12, v13
     69c:      	fmul.4s	v13, v9, v13
     6a0:      	dup.4s	v15, w13
     6a4:      	fadd.4s	v13, v13, v15
     6a8:      	fadd.4s	v14, v14, v15
     6ac:      	fmul.4s	v14, v12, v14
     6b0:      	fmul.4s	v13, v9, v13
     6b4:      	dup.4s	v15, w14
     6b8:      	fadd.4s	v13, v13, v15
     6bc:      	fadd.4s	v14, v14, v15
     6c0:      	fmul.4s	v14, v12, v14
     6c4:      	fmul.4s	v13, v9, v13
     6c8:      	dup.4s	v15, w15
     6cc:      	fadd.4s	v13, v13, v15
     6d0:      	fadd.4s	v14, v14, v15
     6d4:      	fmul.4s	v14, v12, v14
     6d8:      	fmul.4s	v13, v9, v13
     6dc:      	dup.4s	v15, w16
     6e0:      	fadd.4s	v13, v13, v15
     6e4:      	fadd.4s	v14, v14, v15
     6e8:      	fmul.4s	v14, v12, v14
     6ec:      	fmul.4s	v13, v9, v13
     6f0:      	fadd.4s	v13, v13, v23
     6f4:      	fadd.4s	v14, v14, v23
     6f8:      	fmul.4s	v15, v9, v9
     6fc:      	fmul.4s	v4, v12, v12
     700:      	sshll.4s	v6, v29, #0x0
     704:      	fmul.4s	v4, v4, v14
     708:      	fmul.4s	v29, v15, v13
     70c:      	fadd.4s	v9, v9, v29
     710:      	fadd.4s	v4, v12, v4
     714:      	fmov.4s	v29, #1.00000000
     718:      	fadd.4s	v4, v4, v29
     71c:      	sshr.4s	v12, v11, #0x1
     720:      	sshr.4s	v13, v10, #0x1
     724:      	shl.4s	v14, v13, #0x17
     728:      	shl.4s	v15, v12, #0x17
     72c:      	add.4s	v15, v15, v29
     730:      	fadd.4s	v9, v9, v29
     734:      	add.4s	v14, v14, v29
     738:      	fmul.4s	v9, v9, v14
     73c:      	sub.4s	v10, v10, v13
     740:      	sub.4s	v11, v11, v12
     744:      	shl.4s	v11, v11, #0x17
     748:      	fmul.4s	v4, v4, v15
     74c:      	shl.4s	v10, v10, #0x17
     750:      	add.4s	v10, v10, v29
     754:      	add.4s	v11, v11, v29
     758:      	fmul.4s	v4, v4, v11
     75c:      	fcmgt.4s	v11, v18, v30
     760:      	fmul.4s	v9, v9, v10
     764:      	bic.16b	v9, v9, v11
     768:      	fcmgt.4s	v10, v18, v31
     76c:      	bic.16b	v4, v4, v10
     770:      	fcmgt.4s	v10, v30, v19
     774:      	fcmgt.4s	v11, v31, v19
     778:      	bit.16b	v4, v24, v11
     77c:      	bit.16b	v9, v24, v10
     780:      	fcmeq.4s	v31, v31, v31
     784:      	fcmeq.4s	v30, v30, v30
     788:      	bsl.16b	v30, v9, v25
     78c:      	bif.16b	v4, v25, v31
     790:      	bic.16b	v4, v4, v6
     794:      	bic.16b	v6, v30, v8
     798:      	add	x1, x17, x1
     79c:      	dup.2d	v30, x0
     7a0:      	stp	q4, q6, [x1]
     7a4:      	add.2d	v27, v27, v30
     7a8:      	add.2d	v26, v26, v30
     7ac:      	add.2d	v28, v28, v30
     7b0:      	add.2d	v17, v17, v30
     7b4:      	fmov	x1, d17
     7b8:      	cmp	x1, #0xc0
     7bc:      	b.lt	0x594 <ltmp0+0x594>
     7c0:      	ldr	q0, [sp]
     7c4:      	dup.4s	v0, v0[0]
     7c8:      	fsub.4s	v0, v5, v0
     7cc:      	movi.2d	v1, #0000000000000000
     7d0:      	mov.d	v1[0], v0[0]
     7d4:      	ldr	q0, [sp, #0x10]
     7d8:      	sshll.4s	v0, v0, #0x0
     7dc:      	mov	w9, #-0x3d300000        ; =-1026555904
     7e0:      	dup.4s	v2, w9
     7e4:      	fcmge.4s	v3, v1, v2
     7e8:      	mov	w9, #0x42c80000         ; =1120403456
     7ec:      	dup.4s	v4, w9
     7f0:      	fcmge.4s	v5, v4, v1
     7f4:      	and.16b	v3, v3, v5
     7f8:      	and.16b	v3, v3, v1
     7fc:      	mov	w9, #0xaa3b             ; =43579
     800:      	movk	w9, #0x3fb8, lsl #16
     804:      	dup.4s	v5, w9
     808:      	fmul.4s	v5, v3, v5
     80c:      	movi.4s	v6, #0x4b, lsl #24
     810:      	mvni.4s	v7, #0x80, lsl #24
     814:      	bif.16b	v6, v5, v7
     818:      	fadd.4s	v5, v5, v6
     81c:      	fsub.4s	v5, v5, v6
     820:      	fcvtzs.4s	v5, v5
     824:      	mov	w9, #0x7200             ; =29184
     828:      	movk	w9, #0xbf31, lsl #16
     82c:      	dup.4s	v6, w9
     830:      	scvtf.4s	v7, v5
     834:      	fmul.4s	v6, v7, v6
     838:      	fadd.4s	v3, v3, v6
     83c:      	mov	w9, #0xbe8e             ; =48782
     840:      	movk	w9, #0xb5bf, lsl #16
     844:      	dup.4s	v6, w9
     848:      	fmul.4s	v6, v7, v6
     84c:      	fadd.4s	v3, v3, v6
     850:      	mov	w9, #0x2bda             ; =11226
     854:      	movk	w9, #0x3950, lsl #16
     858:      	dup.4s	v6, w9
     85c:      	fmul.4s	v6, v3, v6
     860:      	mov	w9, #0x96c9             ; =38601
     864:      	movk	w9, #0x3ab6, lsl #16
     868:      	dup.4s	v7, w9
     86c:      	fadd.4s	v6, v6, v7
     870:      	fmul.4s	v6, v3, v6
     874:      	mov	w9, #0x88a6             ; =34982
     878:      	movk	w9, #0x3c08, lsl #16
     87c:      	dup.4s	v7, w9
     880:      	fadd.4s	v6, v6, v7
     884:      	mov	w9, #0xaa7a             ; =43642
     888:      	movk	w9, #0x3d2a, lsl #16
     88c:      	dup.4s	v7, w9
     890:      	fmul.4s	v6, v3, v6
     894:      	fadd.4s	v6, v6, v7
     898:      	fmul.4s	v6, v3, v6
     89c:      	mov	w9, #0xaaab             ; =43691
     8a0:      	movk	w9, #0x3e2a, lsl #16
     8a4:      	dup.4s	v7, w9
     8a8:      	fadd.4s	v6, v6, v7
     8ac:      	fmul.4s	v6, v3, v6
     8b0:      	movi.4s	v7, #0x3f, lsl #24
     8b4:      	fadd.4s	v6, v6, v7
     8b8:      	fmul.4s	v7, v3, v3
     8bc:      	fmul.4s	v6, v7, v6
     8c0:      	fadd.4s	v3, v3, v6
     8c4:      	fadd.4s	v3, v3, v29
     8c8:      	sshr.4s	v6, v5, #0x1
     8cc:      	shl.4s	v7, v6, #0x17
     8d0:      	add.4s	v7, v7, v29
     8d4:      	fmul.4s	v3, v3, v7
     8d8:      	sub.4s	v5, v5, v6
     8dc:      	shl.4s	v5, v5, #0x17
     8e0:      	add.4s	v5, v5, v29
     8e4:      	fmul.4s	v3, v3, v5
     8e8:      	fcmgt.4s	v2, v2, v1
     8ec:      	bic.16b	v2, v3, v2
     8f0:      	fcmgt.4s	v3, v1, v4
     8f4:      	mvni.4s	v4, #0x7f, msl #16
     8f8:      	fneg.4s	v4, v4
     8fc:      	bit.16b	v2, v4, v3
     900:      	fcmeq.4s	v1, v1, v1
     904:      	mvni.4s	v3, #0x3f, msl #16
     908:      	fneg.4s	v3, v3
     90c:      	bsl.16b	v1, v2, v3
     910:      	bic.16b	v0, v1, v0
     914:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     918:      	add	x9, x9, #0x729
     91c:      	ldur	q1, [x9, #0xff]
     920:      	mov.d	v0[1], v1[1]
     924:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     928:      	add	x9, x9, #0x729
     92c:      	stur	q0, [x9, #0xff]
     930:      	ldur	q1, [sp, #0x38]
     934:      	ldur	q7, [sp, #0x28]
     938:      	ldur	q6, [sp, #0x58]
     93c:      	ldur	q5, [sp, #0x48]
     940:      	ldur	q2, [sp, #0x78]
     944:      	ldur	q16, [sp, #0x68]
     948:      	ldur	q4, [sp, #0x98]
     94c:      	ldur	q3, [sp, #0x88]
     950:      	add	x9, sp, #0x28
     954:      	add	x9, x9, #0xe0
     958:      	mov	w10, #0x4               ; =4
     95c:      	ldp	q17, q18, [x9, #-0x60]
     960:      	fadd.4s	v1, v1, v18
     964:      	fadd.4s	v7, v7, v17
     968:      	ldp	q17, q18, [x9, #-0x40]
     96c:      	fadd.4s	v6, v6, v18
     970:      	fadd.4s	v5, v5, v17
     974:      	ldp	q17, q18, [x9, #-0x20]
     978:      	fadd.4s	v2, v2, v18
     97c:      	fadd.4s	v16, v16, v17
     980:      	ldp	q17, q18, [x9], #0x80
     984:      	fadd.4s	v4, v4, v18
     988:      	fadd.4s	v3, v3, v17
     98c:      	cmp	x10, #0xbc
     990:      	add	x10, x10, #0x4
     994:      	b.lo	0x95c <ltmp0+0x95c>
     998:      	mov	x9, #0x0                ; =0
     99c:      	fadd.4s	v17, v0, v7
     9a0:      	mov.d	v17[1], v7[1]
     9a4:      	fadd.4s	v1, v6, v1
     9a8:      	fadd.4s	v5, v5, v17
     9ac:      	fadd.4s	v5, v16, v5
     9b0:      	fadd.4s	v1, v2, v1
     9b4:      	fadd.4s	v1, v4, v1
     9b8:      	fadd.4s	v2, v3, v5
     9bc:      	rev64.4s	v3, v2
     9c0:      	rev64.4s	v4, v1
     9c4:      	fadd.4s	v2, v2, v3
     9c8:      	dup.4s	v3, v2[2]
     9cc:      	fadd.4s	v1, v1, v4
     9d0:      	dup.4s	v4, v1[2]
     9d4:      	fadd.4s	v1, v1, v4
     9d8:      	fadd.4s	v2, v2, v3
     9dc:      	fadd.4s	v1, v2, v1
     9e0:      	movi	d2, #0000000000000000
     9e4:      	fadd	s1, s1, s2
     9e8:      	dup.4s	v2, v1[0]
     9ec:      	add	x10, x19, x20
     9f0:      	add	x11, sp, #0x28
     9f4:      	lsl	x12, x9, #5
     9f8:      	add	x13, x11, x12
     9fc:      	ldp	q4, q3, [x13]
     a00:      	fdiv.4s	v4, v4, v2
     a04:      	fdiv.4s	v3, v3, v2
     a08:      	add	x12, x10, x12
     a0c:      	stp	q4, q3, [x12]
     a10:      	add	x9, x9, #0x1
     a14:      	cmp	x9, #0xc0
     a18:      	b.ne	0x9f4 <ltmp0+0x9f4>
     a1c:      	dup.2s	v1, v1[0]
     a20:      	fdiv.2s	v0, v0, v1
     a24:      	str	d0, [x19, x8]
     a28:      	add	sp, sp, #0x7, lsl #12   ; =0x7000
     a2c:      	add	sp, sp, #0xed0
     a30:      	ldp	x29, x30, [sp, #0x80]
     a34:      	ldp	x20, x19, [sp, #0x70]
     a38:      	ldp	x22, x21, [sp, #0x60]
     a3c:      	ldp	x24, x23, [sp, #0x50]
     a40:      	ldp	x26, x25, [sp, #0x40]
     a44:      	ldp	d9, d8, [sp, #0x30]
     a48:      	ldp	d11, d10, [sp, #0x20]
     a4c:      	ldp	d13, d12, [sp, #0x10]
     a50:      	ldp	d15, d14, [sp], #0x90
     a54:      	ret

0000000000000a58 <_llm_rows.packet_batch.blocks>:
     a58:      	stp	d15, d14, [sp, #-0xa0]!
     a5c:      	stp	d13, d12, [sp, #0x10]
     a60:      	stp	d11, d10, [sp, #0x20]
     a64:      	stp	d9, d8, [sp, #0x30]
     a68:      	stp	x28, x27, [sp, #0x40]
     a6c:      	stp	x26, x25, [sp, #0x50]
     a70:      	stp	x24, x23, [sp, #0x60]
     a74:      	stp	x22, x21, [sp, #0x70]
     a78:      	stp	x20, x19, [sp, #0x80]
     a7c:      	stp	x29, x30, [sp, #0x90]
     a80:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
     a84:      	sub	sp, sp, #0x830
     a88:      	str	x0, [sp, #0x1f8]
     a8c:      	cbz	w3, 0x2b24 <_llm_rows.packet_batch.blocks+0x20cc>
     a90:      	mov	x21, x3
     a94:      	mov	x20, x2
     a98:      	mov	w22, #0x0               ; =0
     a9c:      	add	x23, sp, #0x988
     aa0:      	add	x8, sp, #0x3, lsl #12   ; =0x3000
     aa4:      	add	x8, x8, #0x9c8
     aa8:      	dup.2d	v0, x8
     aac:      	str	q0, [sp, #0x20]
     ab0:      	adrp	x8, 0x0 <ltmp0>
     ab4:      	ldr	q0, [x8]
     ab8:      	str	q0, [sp, #0x10]
     abc:      	adrp	x8, 0x0 <ltmp0>
     ac0:      	ldr	q0, [x8]
     ac4:      	str	q0, [sp, #0x170]
     ac8:      	adrp	x8, 0x0 <ltmp0>
     acc:      	ldr	q0, [x8]
     ad0:      	str	q0, [sp, #0x160]
     ad4:      	mvni.4s	v0, #0x7f, msl #16
     ad8:      	fneg.4s	v1, v0
     adc:      	mvni.4s	v0, #0x3f, msl #16
     ae0:      	fneg.4s	v0, v0
     ae4:      	stp	q0, q1, [sp, #0x210]
     ae8:      	add	x24, sp, #0x2, lsl #12  ; =0x2000
     aec:      	add	x24, x24, #0x1a8
     af0:      	mov	w27, #0x4               ; =4
     af4:      	ldp	w9, w8, [x2, #0x2c]
     af8:      	str	w9, [sp, #0x1f4]
     afc:      	str	w8, [sp, #0x1f0]
     b00:      	ldp	w19, w12, [x2]
     b04:      	ldp	w25, w8, [x2, #0x8]
     b08:      	str	x8, [sp, #0x1e8]
     b0c:      	str	w3, [sp, #0x15c]
     b10:      	b	0xb5c <_llm_rows.packet_batch.blocks+0x104>
     b14:      	mov	w8, #0x18               ; =24
     b18:      	str	w8, [x20, #0x24]
     b1c:      	ldr	w21, [sp, #0x15c]
     b20:      	add	w8, w19, #0x1
     b24:      	ldr	w9, [sp, #0x1f4]
     b28:      	cmp	w8, w9
     b2c:      	cset	w8, eq
     b30:      	csinc	w19, wzr, w19, eq
     b34:      	cinc	w9, w12, eq
     b38:      	ldr	w10, [sp, #0x1f0]
     b3c:      	cmp	w9, w10
     b40:      	cset	w10, eq
     b44:      	ands	w8, w8, w10
     b48:      	csel	w12, wzr, w9, ne
     b4c:      	add	w25, w25, w8
     b50:      	add	w22, w22, #0x1
     b54:      	cmp	w22, w21
     b58:      	b.eq	0x2b24 <_llm_rows.packet_batch.blocks+0x20cc>
     b5c:      	ubfiz	x8, x19, #5, #32
     b60:      	ldr	x13, [sp, #0x1e8]
     b64:      	cmp	x8, x13
     b68:      	csel	x9, x8, xzr, ls
     b6c:      	subs	x10, x13, x9
     b70:      	cmp	x10, #0x20
     b74:      	mov	w11, #0x20              ; =32
     b78:      	csel	x10, x10, x11, lo
     b7c:      	cmp	x13, x9
     b80:      	stp	w19, w12, [x20]
     b84:      	str	w25, [x20, #0x8]
     b88:      	str	wzr, [x20, #0x24]
     b8c:      	ccmp	x8, x13, #0x2, hi
     b90:      	csel	x28, x10, xzr, ls
     b94:      	cmp	x28, #0x20
     b98:      	b.lo	0xbf4 <_llm_rows.packet_batch.blocks+0x19c>
     b9c:      	ldr	x28, [sp, #0x1f8]
     ba0:      	mov	x0, x28
     ba4:      	mov	x1, x20
     ba8:      	mov	x26, x12
     bac:      	bl	0xbac <_llm_rows.packet_batch.blocks+0x154>
     bb0:      	mov	w8, #0x8                ; =8
     bb4:      	str	w8, [x20, #0x24]
     bb8:      	mov	x0, x28
     bbc:      	mov	x1, x20
     bc0:      	bl	0xbc0 <_llm_rows.packet_batch.blocks+0x168>
     bc4:      	mov	w8, #0x10               ; =16
     bc8:      	str	w8, [x20, #0x24]
     bcc:      	mov	x0, x28
     bd0:      	mov	x1, x20
     bd4:      	bl	0xbd4 <_llm_rows.packet_batch.blocks+0x17c>
     bd8:      	mov	w8, #0x18               ; =24
     bdc:      	str	w8, [x20, #0x24]
     be0:      	mov	x0, x28
     be4:      	mov	x1, x20
     be8:      	bl	0xbe8 <_llm_rows.packet_batch.blocks+0x190>
     bec:      	mov	x12, x26
     bf0:      	b	0xb20 <_llm_rows.packet_batch.blocks+0xc8>
     bf4:      	lsr	x21, x28, #3
     bf8:      	cmp	x28, #0x8
     bfc:      	b.lo	0xc58 <_llm_rows.packet_batch.blocks+0x200>
     c00:      	str	wzr, [x20, #0x24]
     c04:      	ldr	x0, [sp, #0x1f8]
     c08:      	mov	x1, x20
     c0c:      	mov	x26, x12
     c10:      	bl	0xc10 <_llm_rows.packet_batch.blocks+0x1b8>
     c14:      	mov	x12, x26
     c18:      	cmp	x21, #0x1
     c1c:      	b.eq	0xc58 <_llm_rows.packet_batch.blocks+0x200>
     c20:      	mov	w8, #0x8                ; =8
     c24:      	str	w8, [x20, #0x24]
     c28:      	ldr	x0, [sp, #0x1f8]
     c2c:      	mov	x1, x20
     c30:      	bl	0xc30 <_llm_rows.packet_batch.blocks+0x1d8>
     c34:      	mov	x12, x26
     c38:      	cmp	x21, #0x2
     c3c:      	b.eq	0xc58 <_llm_rows.packet_batch.blocks+0x200>
     c40:      	mov	w8, #0x10               ; =16
     c44:      	str	w8, [x20, #0x24]
     c48:      	ldr	x0, [sp, #0x1f8]
     c4c:      	mov	x1, x20
     c50:      	bl	0xc50 <_llm_rows.packet_batch.blocks+0x1f8>
     c54:      	mov	x12, x26
     c58:      	and	w8, w28, #0x7
     c5c:      	cbz	w8, 0xb14 <_llm_rows.packet_batch.blocks+0xbc>
     c60:      	dup.4s	v20, w8
     c64:      	ldp	q0, q1, [sp, #0x160]
     c68:      	cmhi.4s	v0, v20, v0
     c6c:      	cmhi.4s	v1, v20, v1
     c70:      	uzp1.8h	v3, v1, v0
     c74:      	umaxv.8h	h2, v3
     c78:      	fmov	w8, s2
     c7c:      	tbz	w8, #0x0, 0xb14 <_llm_rows.packet_batch.blocks+0xbc>
     c80:      	str	w12, [sp, #0x158]
     c84:      	mov	x8, #0x0                ; =0
     c88:      	ldr	x10, [sp, #0x1f8]
     c8c:      	ldr	x9, [x10]
     c90:      	ldr	x15, [x10, #0x30]
     c94:      	ldr	q2, [sp, #0x10]
     c98:      	and.16b	v2, v3, v2
     c9c:      	addv.8h	h4, v2
     ca0:      	fmov	w10, s4
     ca4:      	and	w10, w10, #0xff
     ca8:      	str	w10, [sp, #0xdc]
     cac:      	ubfiz	w10, w19, #2, #27
     cb0:      	orr	w10, w10, w21
     cb4:      	dup.4s	v2, w10
     cb8:      	and.16b	v24, v1, v2
     cbc:      	and.16b	v25, v0, v2
     cc0:      	ushll2.2d	v16, v25, #0x0
     cc4:      	ushll2.2d	v17, v24, #0x0
     cc8:      	ushll.2d	v18, v25, #0x0
     ccc:      	ushll.2d	v5, v24, #0x0
     cd0:      	fmov	x10, d5
     cd4:      	mov	w11, #0x1808            ; =6152
     cd8:      	umaddl	x10, w10, w11, x9
     cdc:      	str	q4, [sp, #0x230]
     ce0:      	fmov	w11, s4
     ce4:      	add	x2, sp, #0x7, lsl #12   ; =0x7000
     ce8:      	add	x2, x2, #0x10
     cec:      	mov	w3, #0xf2ca             ; =62154
     cf0:      	movk	w3, #0xf149, lsl #16
     cf4:      	add	x4, sp, #0x3, lsl #12   ; =0x3000
     cf8:      	add	x4, x4, #0xfd0
     cfc:      	b	0xd20 <_llm_rows.packet_batch.blocks+0x2c8>
     d00:      	add	x12, x2, x8, lsl #5
     d04:      	ldp	q6, q7, [x12]
     d08:      	bif.16b	v4, v7, v0
     d0c:      	bif.16b	v2, v6, v1
     d10:      	stp	q2, q4, [x12]
     d14:      	add	x8, x8, #0x1
     d18:      	cmp	x8, #0xc0
     d1c:      	b.eq	0xdb4 <_llm_rows.packet_batch.blocks+0x35c>
     d20:      	add	x12, x10, x8, lsl #5
     d24:      	movi.2d	v2, #0000000000000000
     d28:      	movi.2d	v4, #0000000000000000
     d2c:      	tbnz	w11, #0x0, 0xd54 <_llm_rows.packet_batch.blocks+0x2fc>
     d30:      	and	w13, w11, #0xff
     d34:      	tbnz	w13, #0x1, 0xd60 <_llm_rows.packet_batch.blocks+0x308>
     d38:      	tbnz	w13, #0x2, 0xd6c <_llm_rows.packet_batch.blocks+0x314>
     d3c:      	tbnz	w13, #0x3, 0xd78 <_llm_rows.packet_batch.blocks+0x320>
     d40:      	tbnz	w13, #0x4, 0xd84 <_llm_rows.packet_batch.blocks+0x32c>
     d44:      	tbnz	w13, #0x5, 0xd90 <_llm_rows.packet_batch.blocks+0x338>
     d48:      	tbnz	w13, #0x6, 0xd9c <_llm_rows.packet_batch.blocks+0x344>
     d4c:      	tbz	w13, #0x7, 0xd00 <_llm_rows.packet_batch.blocks+0x2a8>
     d50:      	b	0xda8 <_llm_rows.packet_batch.blocks+0x350>
     d54:      	ldr	s2, [x12]
     d58:      	and	w13, w11, #0xff
     d5c:      	tbz	w13, #0x1, 0xd38 <_llm_rows.packet_batch.blocks+0x2e0>
     d60:      	add	x14, x12, #0x4
     d64:      	ld1.s	{ v2 }[1], [x14]
     d68:      	tbz	w13, #0x2, 0xd3c <_llm_rows.packet_batch.blocks+0x2e4>
     d6c:      	add	x14, x12, #0x8
     d70:      	ld1.s	{ v2 }[2], [x14]
     d74:      	tbz	w13, #0x3, 0xd40 <_llm_rows.packet_batch.blocks+0x2e8>
     d78:      	add	x14, x12, #0xc
     d7c:      	ld1.s	{ v2 }[3], [x14]
     d80:      	tbz	w13, #0x4, 0xd44 <_llm_rows.packet_batch.blocks+0x2ec>
     d84:      	add	x14, x12, #0x10
     d88:      	ld1.s	{ v4 }[0], [x14]
     d8c:      	tbz	w13, #0x5, 0xd48 <_llm_rows.packet_batch.blocks+0x2f0>
     d90:      	add	x14, x12, #0x14
     d94:      	ld1.s	{ v4 }[1], [x14]
     d98:      	tbz	w13, #0x6, 0xd4c <_llm_rows.packet_batch.blocks+0x2f4>
     d9c:      	add	x14, x12, #0x18
     da0:      	ld1.s	{ v4 }[2], [x14]
     da4:      	tbz	w13, #0x7, 0xd00 <_llm_rows.packet_batch.blocks+0x2a8>
     da8:      	add	x12, x12, #0x1c
     dac:      	ld1.s	{ v4 }[3], [x12]
     db0:      	b	0xd00 <_llm_rows.packet_batch.blocks+0x2a8>
     db4:      	xtn.8b	v3, v3
     db8:      	sshll.2d	v4, v1, #0x0
     dbc:      	adrp	x8, 0x0 <ltmp0>
     dc0:      	ldr	q27, [x8]
     dc4:      	and.16b	v6, v4, v27
     dc8:      	movi	d2, #0x0000000000ffff
     dcc:      	and.8b	v22, v3, v2
     dd0:      	adrp	x8, 0x0 <ltmp0>
     dd4:      	ldr	d2, [x8]
     dd8:      	str	q3, [sp, #0x1c0]
     ddc:      	and.8b	v2, v3, v2
     de0:      	addv.8b	b2, v2
     de4:      	fmov	w8, s2
     de8:      	umaxv.8b	b2, v22
     dec:      	fmov	w10, s2
     df0:      	rbit	w11, w8
     df4:      	clz	w11, w11
     df8:      	tst	w10, #0x1
     dfc:      	csel	w5, w11, wzr, ne
     e00:      	mov	w10, #0x600             ; =1536
     e04:      	dup.2d	v29, x10
     e08:      	str	q6, [sp, #0xc0]
     e0c:      	orr.16b	v3, v6, v29
     e10:      	mov	w10, #0x602             ; =1538
     e14:      	dup.2s	v19, w10
     e18:      	xtn.2s	v31, v5
     e1c:      	str	q3, [sp, #0x2e0]
     e20:      	umlal.2d	v3, v31, v19
     e24:      	mov	b2, v22[0]
     e28:      	mov.b	v2[4], v22[1]
     e2c:      	ushll.2d	v2, v2, #0x0
     e30:      	shl.2d	v2, v2, #0x3f
     e34:      	cmlt.2d	v2, v2, #0
     e38:      	str	q3, [sp, #0x130]
     e3c:      	and.16b	v2, v2, v3
     e40:      	movi.2d	v3, #0000000000000000
     e44:      	str	q3, [sp, #0x970]
     e48:      	str	q3, [sp, #0x960]
     e4c:      	str	q3, [sp, #0x950]
     e50:      	str	q2, [sp, #0x940]
     e54:      	and	x10, x5, #0x7
     e58:      	add	x11, sp, #0x940
     e5c:      	ldr	x10, [x11, x10, lsl #3]
     e60:      	sub	x10, x10, x5
     e64:      	add	x9, x9, x10, lsl #2
     e68:      	movi.2d	v5, #0000000000000000
     e6c:      	movi.2d	v8, #0000000000000000
     e70:      	tbnz	w8, #0x0, 0x1654 <_llm_rows.packet_batch.blocks+0xbfc>
     e74:      	tbnz	w8, #0x1, 0x165c <_llm_rows.packet_batch.blocks+0xc04>
     e78:      	tbnz	w8, #0x2, 0x1668 <_llm_rows.packet_batch.blocks+0xc10>
     e7c:      	tbnz	w8, #0x3, 0x1674 <_llm_rows.packet_batch.blocks+0xc1c>
     e80:      	tbnz	w8, #0x4, 0x1680 <_llm_rows.packet_batch.blocks+0xc28>
     e84:      	tbnz	w8, #0x5, 0x168c <_llm_rows.packet_batch.blocks+0xc34>
     e88:      	tbnz	w8, #0x6, 0x1698 <_llm_rows.packet_batch.blocks+0xc40>
     e8c:      	tbz	w8, #0x7, 0xe98 <_llm_rows.packet_batch.blocks+0x440>
     e90:      	add	x9, x9, #0x1c
     e94:      	ld1.s	{ v8 }[3], [x9]
     e98:      	str	x15, [sp, #0x150]
     e9c:      	mov	x9, #0x0                ; =0
     ea0:      	sshll.2d	v7, v0, #0x0
     ea4:      	sshll2.2d	v23, v1, #0x0
     ea8:      	sshll2.2d	v26, v0, #0x0
     eac:      	adrp	x10, 0x0 <ltmp0>
     eb0:      	ldr	q2, [x10]
     eb4:      	and.16b	v2, v26, v2
     eb8:      	adrp	x10, 0x0 <ltmp0>
     ebc:      	ldr	q3, [x10]
     ec0:      	and.16b	v3, v23, v3
     ec4:      	adrp	x10, 0x0 <ltmp0>
     ec8:      	ldr	q6, [x10]
     ecc:      	and.16b	v6, v7, v6
     ed0:      	adrp	x10, 0x0 <ltmp0>
     ed4:      	ldr	q21, [x10]
     ed8:      	and.16b	v4, v4, v21
     edc:      	str	q4, [sp, #0x80]
     ee0:      	str	q4, [sp, #0x900]
     ee4:      	str	q3, [sp, #0x910]
     ee8:      	str	q6, [sp, #0x920]
     eec:      	str	q2, [sp, #0x930]
     ef0:      	and	x10, x5, #0x7
     ef4:      	add	x11, sp, #0x900
     ef8:      	ldr	x10, [x11, x10, lsl #3]
     efc:      	orr	x10, x10, #0x1800
     f00:      	sub	x10, x10, x5, lsl #2
     f04:      	tst	w8, #0xff
     f08:      	csel	x6, xzr, x10, eq
     f0c:      	add	x10, x2, x6
     f10:      	ldp	q2, q3, [x10]
     f14:      	zip2.8b	v4, v22, v0
     f18:      	ushll.4s	v4, v4, #0x0
     f1c:      	shl.4s	v4, v4, #0x1f
     f20:      	cmlt.4s	v4, v4, #0
     f24:      	bit.16b	v3, v8, v4
     f28:      	str	q22, [sp, #0x1d0]
     f2c:      	zip1.8b	v4, v22, v0
     f30:      	ushll.4s	v4, v4, #0x0
     f34:      	shl.4s	v4, v4, #0x1f
     f38:      	cmlt.4s	v4, v4, #0
     f3c:      	bit.16b	v2, v5, v4
     f40:      	stp	q2, q3, [x10]
     f44:      	adrp	x10, 0x0 <ltmp0>
     f48:      	ldr	q2, [x10]
     f4c:      	and.16b	v4, v26, v2
     f50:      	adrp	x10, 0x0 <ltmp0>
     f54:      	ldr	q3, [x10]
     f58:      	and.16b	v21, v23, v3
     f5c:      	adrp	x10, 0x0 <ltmp0>
     f60:      	ldr	q6, [x10]
     f64:      	and.16b	v7, v7, v6
     f68:      	stp	q7, q21, [sp, #0x90]
     f6c:      	orr.16b	v28, v7, v29
     f70:      	orr.16b	v30, v21, v29
     f74:      	str	q4, [sp, #0xb0]
     f78:      	orr.16b	v29, v4, v29
     f7c:      	umull.2d	v4, v31, v19
     f80:      	str	q4, [sp, #0xf0]
     f84:      	xtn.2s	v7, v17
     f88:      	xtn.2s	v17, v18
     f8c:      	xtn.2s	v16, v16
     f90:      	mov.16b	v4, v29
     f94:      	umlal.2d	v4, v16, v19
     f98:      	str	q4, [sp, #0x120]
     f9c:      	mov.16b	v4, v30
     fa0:      	umlal.2d	v4, v7, v19
     fa4:      	str	q4, [sp, #0x110]
     fa8:      	mov.16b	v4, v28
     fac:      	umlal.2d	v4, v17, v19
     fb0:      	str	q4, [sp, #0x100]
     fb4:      	mov	w10, #0x1               ; =1
     fb8:      	dup.2d	v7, x10
     fbc:      	ushll2.2d	v16, v0, #0x0
     fc0:      	and.16b	v4, v16, v7
     fc4:      	ushll2.2d	v17, v1, #0x0
     fc8:      	and.16b	v11, v17, v7
     fcc:      	mov.16b	v17, v26
     fd0:      	ushll.2d	v18, v0, #0x0
     fd4:      	and.16b	v12, v18, v7
     fd8:      	mov.16b	v16, v23
     fdc:      	ushll.2d	v19, v1, #0x0
     fe0:      	and.16b	v31, v19, v7
     fe4:      	mov.16b	v19, v4
     fe8:      	movi.2d	v7, #0000000000000000
     fec:      	movi.2d	v21, #0000000000000000
     ff0:      	movi.2d	v22, #0000000000000000
     ff4:      	movi.2d	v23, #0000000000000000
     ff8:      	stp	q31, q11, [sp, #0x250]
     ffc:      	str	q12, [sp, #0x240]
    1000:      	sshll.2d	v31, v0, #0x0
    1004:      	sshll.2d	v9, v1, #0x0
    1008:      	shl.2d	v11, v23, #0x3
    100c:      	shl.2d	v12, v7, #0x3
    1010:      	shl.2d	v13, v22, #0x3
    1014:      	shl.2d	v14, v21, #0x3
    1018:      	orr.16b	v14, v14, v3
    101c:      	orr.16b	v13, v13, v6
    1020:      	orr.16b	v12, v12, v27
    1024:      	orr.16b	v11, v11, v2
    1028:      	add	x9, x4, x9, lsl #6
    102c:      	ldp	q4, q15, [x9]
    1030:      	ldp	q10, q26, [x9, #0x20]
    1034:      	bit.16b	v26, v11, v17
    1038:      	bit.16b	v4, v12, v9
    103c:      	ldr	q12, [sp, #0x240]
    1040:      	bsl.16b	v31, v13, v10
    1044:      	mov.16b	v9, v16
    1048:      	bsl.16b	v9, v14, v15
    104c:      	stp	q4, q9, [x9]
    1050:      	stp	q31, q26, [x9, #0x20]
    1054:      	ldp	q31, q11, [sp, #0x250]
    1058:      	add.2d	v21, v21, v11
    105c:      	add.2d	v22, v22, v12
    1060:      	add.2d	v23, v23, v19
    1064:      	add.2d	v7, v7, v31
    1068:      	fmov	x9, d7
    106c:      	cmp	x9, #0xc0
    1070:      	b.lt	0x1000 <_llm_rows.packet_batch.blocks+0x5a8>
    1074:      	mov	x9, #0x0                ; =0
    1078:      	mov	w10, #0x602             ; =1538
    107c:      	dup.4s	v2, w10
    1080:      	and.16b	v3, v1, v2
    1084:      	mvn.16b	v4, v1
    1088:      	sub.4s	v3, v3, v4
    108c:      	and.16b	v2, v0, v2
    1090:      	mvn.16b	v4, v0
    1094:      	sub.4s	v2, v2, v4
    1098:      	mov.s	w10, v2[1]
    109c:      	mov.s	w11, v25[1]
    10a0:      	udiv	w12, w11, w10
    10a4:      	msub	w11, w12, w10, w11
    10a8:      	mov.s	w10, v2[2]
    10ac:      	mov.s	w12, v2[3]
    10b0:      	fmov	w13, s2
    10b4:      	fmov	w14, s25
    10b8:      	udiv	w15, w14, w13
    10bc:      	msub	w13, w15, w13, w14
    10c0:      	mov.s	w14, v25[2]
    10c4:      	udiv	w15, w14, w10
    10c8:      	msub	w14, w15, w10, w14
    10cc:      	mov.s	w10, v25[3]
    10d0:      	udiv	w15, w10, w12
    10d4:      	msub	w12, w15, w12, w10
    10d8:      	mov.s	w10, v3[1]
    10dc:      	mov.s	w15, v24[1]
    10e0:      	udiv	w16, w15, w10
    10e4:      	msub	w15, w16, w10, w15
    10e8:      	mov.s	w10, v3[2]
    10ec:      	mov.s	w16, v3[3]
    10f0:      	fmov	w17, s3
    10f4:      	fmov	w0, s24
    10f8:      	udiv	w1, w0, w17
    10fc:      	msub	w17, w1, w17, w0
    1100:      	mov.s	w0, v24[2]
    1104:      	udiv	w1, w0, w10
    1108:      	msub	w10, w1, w10, w0
    110c:      	mov.s	w0, v24[3]
    1110:      	udiv	w1, w0, w16
    1114:      	msub	w16, w1, w16, w0
    1118:      	tst	w8, #0xff
    111c:      	fmov	s2, w13
    1120:      	mov.s	v2[1], w11
    1124:      	mov.s	v2[2], w14
    1128:      	mov.s	v2[3], w12
    112c:      	fmov	s3, w17
    1130:      	sshll.2d	v27, v0, #0x0
    1134:      	sshll.2d	v25, v1, #0x0
    1138:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5a8>
    113c:      	ldr	q4, [x8]
    1140:      	and.16b	v4, v25, v4
    1144:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5a8>
    1148:      	ldr	q6, [x8]
    114c:      	and.16b	v6, v27, v6
    1150:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5a8>
    1154:      	ldr	q7, [x8]
    1158:      	and.16b	v7, v16, v7
    115c:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5a8>
    1160:      	ldr	q21, [x8]
    1164:      	and.16b	v21, v17, v21
    1168:      	str	q21, [sp, #0x8f0]
    116c:      	str	q6, [sp, #0x8e0]
    1170:      	str	q7, [sp, #0x8d0]
    1174:      	str	q4, [sp, #0x8c0]
    1178:      	mov.s	v3[1], w15
    117c:      	and	x8, x5, #0x7
    1180:      	add	x11, sp, #0x8c0
    1184:      	ldr	x8, [x11, x8, lsl #3]
    1188:      	orr	x8, x8, #0x3000
    118c:      	sub	x8, x8, x5, lsl #3
    1190:      	csel	x8, xzr, x8, eq
    1194:      	add	x8, x4, x8
    1198:      	ldp	q4, q7, [x8, #0x20]
    119c:      	ldr	q18, [sp, #0x1d0]
    11a0:      	mov	b6, v18[2]
    11a4:      	mov.b	v6[4], v18[3]
    11a8:      	ldp	q21, q22, [x8]
    11ac:      	ushll.2d	v6, v6, #0x0
    11b0:      	shl.2d	v6, v6, #0x3f
    11b4:      	cmlt.2d	v6, v6, #0
    11b8:      	mov.16b	v24, v6
    11bc:      	bsl.16b	v24, v30, v22
    11c0:      	mov	b6, v18[0]
    11c4:      	mov.b	v6[4], v18[1]
    11c8:      	ushll.2d	v6, v6, #0x0
    11cc:      	shl.2d	v6, v6, #0x3f
    11d0:      	cmlt.2d	v6, v6, #0
    11d4:      	ldr	q22, [sp, #0x2e0]
    11d8:      	bsl.16b	v6, v22, v21
    11dc:      	mov	b21, v18[6]
    11e0:      	mov.b	v21[4], v18[7]
    11e4:      	ushll.2d	v21, v21, #0x0
    11e8:      	shl.2d	v21, v21, #0x3f
    11ec:      	cmlt.2d	v21, v21, #0
    11f0:      	bit.16b	v7, v29, v21
    11f4:      	mov	b21, v18[4]
    11f8:      	mov.b	v21[4], v18[5]
    11fc:      	ushll.2d	v21, v21, #0x0
    1200:      	shl.2d	v21, v21, #0x3f
    1204:      	cmlt.2d	v21, v21, #0
    1208:      	bsl.16b	v21, v28, v4
    120c:      	mov.s	v3[2], w10
    1210:      	mov.s	v3[3], w16
    1214:      	and.16b	v4, v1, v3
    1218:      	stp	q21, q7, [x8, #0x20]
    121c:      	stp	q6, q24, [x8]
    1220:      	and.16b	v22, v0, v2
    1224:      	ushll2.2d	v2, v22, #0x0
    1228:      	ushll2.2d	v3, v4, #0x0
    122c:      	ushll.2d	v22, v22, #0x0
    1230:      	ushll.2d	v23, v4, #0x0
    1234:      	ldr	q4, [sp, #0x20]
    1238:      	and.16b	v30, v17, v4
    123c:      	and.16b	v28, v16, v4
    1240:      	and.16b	v26, v27, v4
    1244:      	stp	q26, q28, [sp, #0x2d0]
    1248:      	and.16b	v4, v25, v4
    124c:      	str	q4, [sp, #0x2c0]
    1250:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5a8>
    1254:      	ldr	q4, [x8]
    1258:      	str	q17, [sp, #0x1a0]
    125c:      	and.16b	v4, v17, v4
    1260:      	str	q4, [sp, #0x2b0]
    1264:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5a8>
    1268:      	ldr	q4, [x8]
    126c:      	str	q16, [sp, #0x1b0]
    1270:      	and.16b	v4, v16, v4
    1274:      	str	q4, [sp, #0x2a0]
    1278:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5a8>
    127c:      	ldr	q4, [x8]
    1280:      	and.16b	v4, v27, v4
    1284:      	str	q4, [sp, #0x290]
    1288:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5a8>
    128c:      	ldr	q4, [x8]
    1290:      	and.16b	v4, v25, v4
    1294:      	str	q4, [sp, #0x280]
    1298:      	ldp	q4, q16, [sp, #0x160]
    129c:      	cmhs.4s	v4, v4, v20
    12a0:      	cmhs.4s	v20, v16, v20
    12a4:      	uzp1.8h	v4, v20, v4
    12a8:      	xtn.8b	v20, v4
    12ac:      	movi.2d	v25, #0000000000000000
    12b0:      	movi.2d	v26, #0000000000000000
    12b4:      	movi.2d	v27, #0000000000000000
    12b8:      	movi.2d	v9, #0000000000000000
    12bc:      	movi.8b	v16, #0x1
    12c0:      	ldr	q17, [sp, #0x230]
    12c4:      	b	0x12e4 <_llm_rows.packet_batch.blocks+0x88c>
    12c8:      	add.2d	v26, v26, v11
    12cc:      	add.2d	v27, v27, v12
    12d0:      	add.2d	v9, v9, v19
    12d4:      	add.2d	v25, v25, v31
    12d8:      	fmov	x9, d25
    12dc:      	cmp	x9, #0xc0
    12e0:      	b.ge	0x1410 <_llm_rows.packet_batch.blocks+0x9b8>
    12e4:      	fmov	w8, s17
    12e8:      	add	x9, x4, x9, lsl #6
    12ec:      	ldp	q28, q4, [x9, #0x20]
    12f0:      	ldp	q29, q10, [x9]
    12f4:      	cmge.2d	v10, v3, v10
    12f8:      	cmge.2d	v29, v23, v29
    12fc:      	uzp1.4s	v29, v29, v10
    1300:      	cmge.2d	v28, v22, v28
    1304:      	cmge.2d	v4, v2, v4
    1308:      	uzp1.4s	v4, v28, v4
    130c:      	uzp1.8h	v4, v29, v4
    1310:      	xtn.8b	v4, v4
    1314:      	orr.8b	v4, v20, v4
    1318:      	ldr	q28, [sp, #0x280]
    131c:      	add.2d	v28, v25, v28
    1320:      	ldr	q29, [sp, #0x2c0]
    1324:      	add.2d	v29, v29, v28
    1328:      	and.8b	v28, v4, v16
    132c:      	tbnz	w8, #0x0, 0x1380 <_llm_rows.packet_batch.blocks+0x928>
    1330:      	and	w8, w8, #0xff
    1334:      	tbnz	w8, #0x1, 0x1390 <_llm_rows.packet_batch.blocks+0x938>
    1338:      	ldr	q4, [sp, #0x2a0]
    133c:      	add.2d	v4, v26, v4
    1340:      	ldr	q29, [sp, #0x2e0]
    1344:      	add.2d	v29, v29, v4
    1348:      	tbnz	w8, #0x2, 0x13ac <_llm_rows.packet_batch.blocks+0x954>
    134c:      	tbnz	w8, #0x3, 0x13b8 <_llm_rows.packet_batch.blocks+0x960>
    1350:      	ldr	q4, [sp, #0x290]
    1354:      	add.2d	v4, v27, v4
    1358:      	ldr	q29, [sp, #0x2d0]
    135c:      	add.2d	v29, v29, v4
    1360:      	tbnz	w8, #0x4, 0x13d4 <_llm_rows.packet_batch.blocks+0x97c>
    1364:      	tbnz	w8, #0x5, 0x13e0 <_llm_rows.packet_batch.blocks+0x988>
    1368:      	ldr	q4, [sp, #0x2b0]
    136c:      	add.2d	v4, v9, v4
    1370:      	add.2d	v29, v30, v4
    1374:      	tbnz	w8, #0x6, 0x13f8 <_llm_rows.packet_batch.blocks+0x9a0>
    1378:      	tbz	w8, #0x7, 0x12c8 <_llm_rows.packet_batch.blocks+0x870>
    137c:      	b	0x1404 <_llm_rows.packet_batch.blocks+0x9ac>
    1380:      	fmov	x9, d29
    1384:      	str	b28, [x9]
    1388:      	and	w8, w8, #0xff
    138c:      	tbz	w8, #0x1, 0x1338 <_llm_rows.packet_batch.blocks+0x8e0>
    1390:      	mov.d	x9, v29[1]
    1394:      	st1.b	{ v28 }[1], [x9]
    1398:      	ldr	q4, [sp, #0x2a0]
    139c:      	add.2d	v4, v26, v4
    13a0:      	ldr	q29, [sp, #0x2e0]
    13a4:      	add.2d	v29, v29, v4
    13a8:      	tbz	w8, #0x2, 0x134c <_llm_rows.packet_batch.blocks+0x8f4>
    13ac:      	fmov	x9, d29
    13b0:      	st1.b	{ v28 }[2], [x9]
    13b4:      	tbz	w8, #0x3, 0x1350 <_llm_rows.packet_batch.blocks+0x8f8>
    13b8:      	mov.d	x9, v29[1]
    13bc:      	st1.b	{ v28 }[3], [x9]
    13c0:      	ldr	q4, [sp, #0x290]
    13c4:      	add.2d	v4, v27, v4
    13c8:      	ldr	q29, [sp, #0x2d0]
    13cc:      	add.2d	v29, v29, v4
    13d0:      	tbz	w8, #0x4, 0x1364 <_llm_rows.packet_batch.blocks+0x90c>
    13d4:      	fmov	x9, d29
    13d8:      	st1.b	{ v28 }[4], [x9]
    13dc:      	tbz	w8, #0x5, 0x1368 <_llm_rows.packet_batch.blocks+0x910>
    13e0:      	mov.d	x9, v29[1]
    13e4:      	st1.b	{ v28 }[5], [x9]
    13e8:      	ldr	q4, [sp, #0x2b0]
    13ec:      	add.2d	v4, v9, v4
    13f0:      	add.2d	v29, v30, v4
    13f4:      	tbz	w8, #0x6, 0x1378 <_llm_rows.packet_batch.blocks+0x920>
    13f8:      	fmov	x9, d29
    13fc:      	st1.b	{ v28 }[6], [x9]
    1400:      	tbz	w8, #0x7, 0x12c8 <_llm_rows.packet_batch.blocks+0x870>
    1404:      	mov.d	x8, v29[1]
    1408:      	st1.b	{ v28 }[7], [x8]
    140c:      	b	0x12c8 <_llm_rows.packet_batch.blocks+0x870>
    1410:      	str	q19, [sp, #0x270]
    1414:      	cmge.2d	v4, v23, v6
    1418:      	cmge.2d	v3, v3, v24
    141c:      	uzp1.4s	v3, v4, v3
    1420:      	cmge.2d	v4, v22, v21
    1424:      	cmge.2d	v2, v2, v7
    1428:      	uzp1.4s	v2, v4, v2
    142c:      	uzp1.8h	v2, v3, v2
    1430:      	xtn.8b	v2, v2
    1434:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5a8>
    1438:      	ldr	d3, [x8]
    143c:      	shl.8b	v4, v18, #0x7
    1440:      	cmlt.8b	v4, v4, #0
    1444:      	and.8b	v3, v4, v3
    1448:      	addv.8b	b19, v3
    144c:      	fmov	w12, s19
    1450:      	orn.8b	v2, v2, v18
    1454:      	ldr	q3, [sp, #0x2c0]
    1458:      	ldr	q4, [sp, #0x280]
    145c:      	add.2d	v4, v4, v3
    1460:      	mov	w8, #0xc0               ; =192
    1464:      	dup.2d	v3, x8
    1468:      	add.2d	v14, v4, v3
    146c:      	and.8b	v2, v2, v16
    1470:      	tbnz	w12, #0x0, 0x16a8 <_llm_rows.packet_batch.blocks+0xc50>
    1474:      	mov.d	x11, v14[1]
    1478:      	tbnz	w12, #0x1, 0x16b8 <_llm_rows.packet_batch.blocks+0xc60>
    147c:      	ldr	q4, [sp, #0x2e0]
    1480:      	ldr	q6, [sp, #0x2a0]
    1484:      	add.2d	v4, v6, v4
    1488:      	add.2d	v13, v4, v3
    148c:      	tbnz	w12, #0x2, 0x16d0 <_llm_rows.packet_batch.blocks+0xc78>
    1490:      	mov.d	x10, v13[1]
    1494:      	tbnz	w12, #0x3, 0x16e0 <_llm_rows.packet_batch.blocks+0xc88>
    1498:      	ldr	q4, [sp, #0x2d0]
    149c:      	ldr	q6, [sp, #0x290]
    14a0:      	add.2d	v4, v6, v4
    14a4:      	add.2d	v24, v4, v3
    14a8:      	tbnz	w12, #0x4, 0x16f8 <_llm_rows.packet_batch.blocks+0xca0>
    14ac:      	mov.d	x9, v24[1]
    14b0:      	tbnz	w12, #0x5, 0x1708 <_llm_rows.packet_batch.blocks+0xcb0>
    14b4:      	ldr	q4, [sp, #0x2b0]
    14b8:      	add.2d	v4, v4, v30
    14bc:      	add.2d	v20, v4, v3
    14c0:      	tbnz	w12, #0x6, 0x171c <_llm_rows.packet_batch.blocks+0xcc4>
    14c4:      	mov.d	x8, v20[1]
    14c8:      	tbz	w12, #0x7, 0x14d0 <_llm_rows.packet_batch.blocks+0xa78>
    14cc:      	st1.b	{ v2 }[7], [x8]
    14d0:      	mov	x12, #0x0               ; =0
    14d4:      	movi.2d	v9, #0000000000000000
    14d8:      	movi.2d	v15, #0000000000000000
    14dc:      	movi.2d	v6, #0000000000000000
    14e0:      	movi.2d	v7, #0000000000000000
    14e4:      	b	0x154c <_llm_rows.packet_batch.blocks+0xaf4>
    14e8:      	cmeq.8b	v2, v2, #0
    14ec:      	sshll.8h	v2, v2, #0x0
    14f0:      	sshll2.4s	v3, v2, #0x0
    14f4:      	sshll.4s	v4, v2, #0x0
    14f8:      	lsl	x12, x12, #5
    14fc:      	add	x13, x2, x12
    1500:      	ldp	q2, q21, [x13]
    1504:      	and.16b	v21, v0, v21
    1508:      	and.16b	v22, v1, v2
    150c:      	dup.4s	v2, w3
    1510:      	bsl.16b	v4, v2, v22
    1514:      	bsl.16b	v3, v2, v21
    1518:      	add	x12, x24, x12
    151c:      	ldp	q21, q22, [x12]
    1520:      	bif.16b	v3, v22, v0
    1524:      	bif.16b	v4, v21, v1
    1528:      	stp	q4, q3, [x12]
    152c:      	add.2d	v15, v15, v11
    1530:      	add.2d	v6, v6, v12
    1534:      	ldr	q3, [sp, #0x270]
    1538:      	add.2d	v7, v7, v3
    153c:      	add.2d	v9, v9, v31
    1540:      	fmov	x12, d9
    1544:      	cmp	x12, #0xc0
    1548:      	b.ge	0x1638 <_llm_rows.packet_batch.blocks+0xbe0>
    154c:      	fmov	w13, s17
    1550:      	ldr	q2, [sp, #0x280]
    1554:      	add.2d	v2, v9, v2
    1558:      	ldr	q3, [sp, #0x2c0]
    155c:      	add.2d	v3, v3, v2
    1560:      	tbz	w13, #0x0, 0x1578 <_llm_rows.packet_batch.blocks+0xb20>
    1564:      	fmov	x14, d3
    1568:      	ldr	b2, [x14]
    156c:      	and	w13, w13, #0xff
    1570:      	tbnz	w13, #0x1, 0x1584 <_llm_rows.packet_batch.blocks+0xb2c>
    1574:      	b	0x158c <_llm_rows.packet_batch.blocks+0xb34>
    1578:      	movi.2d	v2, #0000000000000000
    157c:      	and	w13, w13, #0xff
    1580:      	tbz	w13, #0x1, 0x158c <_llm_rows.packet_batch.blocks+0xb34>
    1584:      	mov.d	x14, v3[1]
    1588:      	ld1.b	{ v2 }[1], [x14]
    158c:      	ldr	q3, [sp, #0x2a0]
    1590:      	add.2d	v3, v15, v3
    1594:      	ldr	q4, [sp, #0x2e0]
    1598:      	add.2d	v3, v4, v3
    159c:      	tbnz	w13, #0x2, 0x15d4 <_llm_rows.packet_batch.blocks+0xb7c>
    15a0:      	tbnz	w13, #0x3, 0x15e0 <_llm_rows.packet_batch.blocks+0xb88>
    15a4:      	ldr	q3, [sp, #0x290]
    15a8:      	add.2d	v3, v6, v3
    15ac:      	ldr	q4, [sp, #0x2d0]
    15b0:      	add.2d	v3, v4, v3
    15b4:      	tbnz	w13, #0x4, 0x15fc <_llm_rows.packet_batch.blocks+0xba4>
    15b8:      	tbnz	w13, #0x5, 0x1608 <_llm_rows.packet_batch.blocks+0xbb0>
    15bc:      	ldr	q3, [sp, #0x2b0]
    15c0:      	add.2d	v3, v7, v3
    15c4:      	add.2d	v3, v30, v3
    15c8:      	tbnz	w13, #0x6, 0x1620 <_llm_rows.packet_batch.blocks+0xbc8>
    15cc:      	tbz	w13, #0x7, 0x14e8 <_llm_rows.packet_batch.blocks+0xa90>
    15d0:      	b	0x162c <_llm_rows.packet_batch.blocks+0xbd4>
    15d4:      	fmov	x14, d3
    15d8:      	ld1.b	{ v2 }[2], [x14]
    15dc:      	tbz	w13, #0x3, 0x15a4 <_llm_rows.packet_batch.blocks+0xb4c>
    15e0:      	mov.d	x14, v3[1]
    15e4:      	ld1.b	{ v2 }[3], [x14]
    15e8:      	ldr	q3, [sp, #0x290]
    15ec:      	add.2d	v3, v6, v3
    15f0:      	ldr	q4, [sp, #0x2d0]
    15f4:      	add.2d	v3, v4, v3
    15f8:      	tbz	w13, #0x4, 0x15b8 <_llm_rows.packet_batch.blocks+0xb60>
    15fc:      	fmov	x14, d3
    1600:      	ld1.b	{ v2 }[4], [x14]
    1604:      	tbz	w13, #0x5, 0x15bc <_llm_rows.packet_batch.blocks+0xb64>
    1608:      	mov.d	x14, v3[1]
    160c:      	ld1.b	{ v2 }[5], [x14]
    1610:      	ldr	q3, [sp, #0x2b0]
    1614:      	add.2d	v3, v7, v3
    1618:      	add.2d	v3, v30, v3
    161c:      	tbz	w13, #0x6, 0x15cc <_llm_rows.packet_batch.blocks+0xb74>
    1620:      	fmov	x14, d3
    1624:      	ld1.b	{ v2 }[6], [x14]
    1628:      	tbz	w13, #0x7, 0x14e8 <_llm_rows.packet_batch.blocks+0xa90>
    162c:      	mov.d	x13, v3[1]
    1630:      	ld1.b	{ v2 }[7], [x13]
    1634:      	b	0x14e8 <_llm_rows.packet_batch.blocks+0xa90>
    1638:      	fmov	w12, s19
    163c:      	tbz	w12, #0x0, 0x1730 <_llm_rows.packet_batch.blocks+0xcd8>
    1640:      	fmov	x13, d14
    1644:      	ldr	b3, [x13]
    1648:      	ldr	q16, [sp, #0x1a0]
    164c:      	tbnz	w12, #0x1, 0x173c <_llm_rows.packet_batch.blocks+0xce4>
    1650:      	b	0x1740 <_llm_rows.packet_batch.blocks+0xce8>
    1654:      	ldr	s5, [x9]
    1658:      	tbz	w8, #0x1, 0xe78 <_llm_rows.packet_batch.blocks+0x420>
    165c:      	add	x10, x9, #0x4
    1660:      	ld1.s	{ v5 }[1], [x10]
    1664:      	tbz	w8, #0x2, 0xe7c <_llm_rows.packet_batch.blocks+0x424>
    1668:      	add	x10, x9, #0x8
    166c:      	ld1.s	{ v5 }[2], [x10]
    1670:      	tbz	w8, #0x3, 0xe80 <_llm_rows.packet_batch.blocks+0x428>
    1674:      	add	x10, x9, #0xc
    1678:      	ld1.s	{ v5 }[3], [x10]
    167c:      	tbz	w8, #0x4, 0xe84 <_llm_rows.packet_batch.blocks+0x42c>
    1680:      	add	x10, x9, #0x10
    1684:      	ld1.s	{ v8 }[0], [x10]
    1688:      	tbz	w8, #0x5, 0xe88 <_llm_rows.packet_batch.blocks+0x430>
    168c:      	add	x10, x9, #0x14
    1690:      	ld1.s	{ v8 }[1], [x10]
    1694:      	tbz	w8, #0x6, 0xe8c <_llm_rows.packet_batch.blocks+0x434>
    1698:      	add	x10, x9, #0x18
    169c:      	ld1.s	{ v8 }[2], [x10]
    16a0:      	tbnz	w8, #0x7, 0xe90 <_llm_rows.packet_batch.blocks+0x438>
    16a4:      	b	0xe98 <_llm_rows.packet_batch.blocks+0x440>
    16a8:      	fmov	x8, d14
    16ac:      	str	b2, [x8]
    16b0:      	mov.d	x11, v14[1]
    16b4:      	tbz	w12, #0x1, 0x147c <_llm_rows.packet_batch.blocks+0xa24>
    16b8:      	st1.b	{ v2 }[1], [x11]
    16bc:      	ldr	q4, [sp, #0x2e0]
    16c0:      	ldr	q6, [sp, #0x2a0]
    16c4:      	add.2d	v4, v6, v4
    16c8:      	add.2d	v13, v4, v3
    16cc:      	tbz	w12, #0x2, 0x1490 <_llm_rows.packet_batch.blocks+0xa38>
    16d0:      	fmov	x8, d13
    16d4:      	st1.b	{ v2 }[2], [x8]
    16d8:      	mov.d	x10, v13[1]
    16dc:      	tbz	w12, #0x3, 0x1498 <_llm_rows.packet_batch.blocks+0xa40>
    16e0:      	st1.b	{ v2 }[3], [x10]
    16e4:      	ldr	q4, [sp, #0x2d0]
    16e8:      	ldr	q6, [sp, #0x290]
    16ec:      	add.2d	v4, v6, v4
    16f0:      	add.2d	v24, v4, v3
    16f4:      	tbz	w12, #0x4, 0x14ac <_llm_rows.packet_batch.blocks+0xa54>
    16f8:      	fmov	x8, d24
    16fc:      	st1.b	{ v2 }[4], [x8]
    1700:      	mov.d	x9, v24[1]
    1704:      	tbz	w12, #0x5, 0x14b4 <_llm_rows.packet_batch.blocks+0xa5c>
    1708:      	st1.b	{ v2 }[5], [x9]
    170c:      	ldr	q4, [sp, #0x2b0]
    1710:      	add.2d	v4, v4, v30
    1714:      	add.2d	v20, v4, v3
    1718:      	tbz	w12, #0x6, 0x14c4 <_llm_rows.packet_batch.blocks+0xa6c>
    171c:      	fmov	x8, d20
    1720:      	st1.b	{ v2 }[6], [x8]
    1724:      	mov.d	x8, v20[1]
    1728:      	tbnz	w12, #0x7, 0x14cc <_llm_rows.packet_batch.blocks+0xa74>
    172c:      	b	0x14d0 <_llm_rows.packet_batch.blocks+0xa78>
    1730:      	movi.2d	v3, #0000000000000000
    1734:      	ldr	q16, [sp, #0x1a0]
    1738:      	tbz	w12, #0x1, 0x1740 <_llm_rows.packet_batch.blocks+0xce8>
    173c:      	ld1.b	{ v3 }[1], [x11]
    1740:      	tbnz	w12, #0x2, 0x2a94 <_llm_rows.packet_batch.blocks+0x203c>
    1744:      	tbnz	w12, #0x3, 0x2aa0 <_llm_rows.packet_batch.blocks+0x2048>
    1748:      	tbnz	w12, #0x4, 0x2aa8 <_llm_rows.packet_batch.blocks+0x2050>
    174c:      	tbnz	w12, #0x5, 0x2ab4 <_llm_rows.packet_batch.blocks+0x205c>
    1750:      	tbnz	w12, #0x6, 0x2abc <_llm_rows.packet_batch.blocks+0x2064>
    1754:      	str	q30, [sp, #0x200]
    1758:      	str	d19, [sp, #0xe8]
    175c:      	tbz	w12, #0x7, 0x1764 <_llm_rows.packet_batch.blocks+0xd0c>
    1760:      	ld1.b	{ v3 }[7], [x8]
    1764:      	str	w22, [sp, #0x78]
    1768:      	str	x5, [sp, #0x148]
    176c:      	sshll.2d	v4, v1, #0x0
    1770:      	sshll.2d	v6, v0, #0x0
    1774:      	cmeq.8b	v3, v3, #0
    1778:      	sshll.8h	v7, v3, #0x0
    177c:      	sshll.4s	v3, v7, #0x0
    1780:      	str	q7, [sp, #0x40]
    1784:      	sshll2.4s	v7, v7, #0x0
    1788:      	str	q7, [sp, #0x60]
    178c:      	bsl.16b	v7, v2, v8
    1790:      	mov.16b	v17, v3
    1794:      	bsl.16b	v17, v2, v5
    1798:      	str	x6, [sp, #0xe0]
    179c:      	add	x8, x24, x6
    17a0:      	ldp	q3, q2, [x8]
    17a4:      	zip1.8b	v5, v18, v0
    17a8:      	ushll.4s	v5, v5, #0x0
    17ac:      	shl.4s	v5, v5, #0x1f
    17b0:      	cmlt.4s	v5, v5, #0
    17b4:      	stp	q17, q7, [sp, #0x180]
    17b8:      	bit.16b	v3, v17, v5
    17bc:      	zip2.8b	v5, v18, v0
    17c0:      	ushll.4s	v5, v5, #0x0
    17c4:      	shl.4s	v5, v5, #0x1f
    17c8:      	cmlt.4s	v5, v5, #0
    17cc:      	bit.16b	v2, v7, v5
    17d0:      	stp	q3, q2, [x8]
    17d4:      	ldr	q2, [sp, #0x80]
    17d8:      	fmov	x8, d2
    17dc:      	dup.2d	v2, x27
    17e0:      	and.16b	v14, v16, v2
    17e4:      	ldr	q18, [sp, #0x1b0]
    17e8:      	and.16b	v15, v18, v2
    17ec:      	and.16b	v8, v6, v2
    17f0:      	and.16b	v10, v4, v2
    17f4:      	fmov	x16, d10
    17f8:      	ldr	q3, [x23, #0x1880]
    17fc:      	ldr	q2, [x23, #0x1890]
    1800:      	and.16b	v2, v0, v2
    1804:      	and.16b	v3, v1, v3
    1808:      	ldr	q4, [x23, #0x1860]
    180c:      	ldr	q5, [x23, #0x1870]
    1810:      	and.16b	v6, v0, v5
    1814:      	and.16b	v5, v1, v4
    1818:      	ldr	q4, [x23, #0x1840]
    181c:      	ldr	q7, [x23, #0x1850]
    1820:      	and.16b	v7, v0, v7
    1824:      	and.16b	v20, v1, v4
    1828:      	str	x8, [sp, #0x70]
    182c:      	add	x8, x24, x8
    1830:      	ldp	q4, q21, [x8]
    1834:      	and.16b	v21, v0, v21
    1838:      	mov	x8, x16
    183c:      	and.16b	v22, v1, v4
    1840:      	mov.16b	v24, v10
    1844:      	mov.16b	v25, v15
    1848:      	mov.16b	v26, v8
    184c:      	mov.16b	v27, v14
    1850:      	mov.16b	v19, v16
    1854:      	sshll.2d	v4, v1, #0x0
    1858:      	sshll.2d	v29, v0, #0x0
    185c:      	add	x8, x24, x8, lsl #5
    1860:      	ldp	q23, q28, [x8]
    1864:      	and.16b	v28, v0, v28
    1868:      	and.16b	v23, v1, v23
    186c:      	fmaxnm.4s	v23, v22, v23
    1870:      	fmaxnm.4s	v28, v21, v28
    1874:      	ldp	q9, q11, [x8, #0x20]
    1878:      	and.16b	v11, v0, v11
    187c:      	and.16b	v9, v1, v9
    1880:      	fmaxnm.4s	v9, v20, v9
    1884:      	fmaxnm.4s	v11, v7, v11
    1888:      	ldp	q13, q30, [x8, #0x40]
    188c:      	and.16b	v30, v0, v30
    1890:      	and.16b	v13, v1, v13
    1894:      	fmaxnm.4s	v13, v5, v13
    1898:      	fmaxnm.4s	v30, v6, v30
    189c:      	ldp	q31, q12, [x8, #0x60]
    18a0:      	and.16b	v12, v0, v12
    18a4:      	and.16b	v31, v1, v31
    18a8:      	fmaxnm.4s	v31, v3, v31
    18ac:      	fmaxnm.4s	v12, v2, v12
    18b0:      	dup.2d	v16, x27
    18b4:      	and.16b	v17, v19, v16
    18b8:      	add.2d	v27, v27, v17
    18bc:      	and.16b	v17, v18, v16
    18c0:      	add.2d	v25, v25, v17
    18c4:      	and.16b	v17, v29, v16
    18c8:      	add.2d	v26, v26, v17
    18cc:      	and.16b	v4, v4, v16
    18d0:      	add.2d	v24, v24, v4
    18d4:      	bit.16b	v21, v28, v0
    18d8:      	bit.16b	v22, v23, v1
    18dc:      	bit.16b	v7, v11, v0
    18e0:      	bit.16b	v20, v9, v1
    18e4:      	bit.16b	v6, v30, v0
    18e8:      	bit.16b	v5, v13, v1
    18ec:      	bit.16b	v2, v12, v0
    18f0:      	bit.16b	v3, v31, v1
    18f4:      	fmov	x8, d24
    18f8:      	cmp	x8, #0xc0
    18fc:      	b.lt	0x1854 <_llm_rows.packet_batch.blocks+0xdfc>
    1900:      	mov	x9, #0x0                ; =0
    1904:      	movi	d4, #0xffffffffffff0000
    1908:      	ldp	q25, q17, [sp, #0x1c0]
    190c:      	and.8b	v18, v25, v4
    1910:      	zip1.8b	v4, v17, v0
    1914:      	ushll.4s	v4, v4, #0x0
    1918:      	shl.4s	v4, v4, #0x1f
    191c:      	cmlt.4s	v4, v4, #0
    1920:      	ldp	q16, q19, [sp, #0x180]
    1924:      	and.16b	v16, v4, v16
    1928:      	zip2.8b	v17, v17, v0
    192c:      	ushll.4s	v17, v17, #0x0
    1930:      	shl.4s	v17, v17, #0x1f
    1934:      	cmlt.4s	v17, v17, #0
    1938:      	and.16b	v24, v17, v19
    193c:      	fmaxnm.4s	v21, v21, v24
    1940:      	fmaxnm.4s	v16, v22, v16
    1944:      	and.16b	v4, v4, v16
    1948:      	and.16b	v16, v17, v21
    194c:      	zip2.8b	v17, v18, v0
    1950:      	ushll.4s	v17, v17, #0x0
    1954:      	shl.4s	v17, v17, #0x1f
    1958:      	cmlt.4s	v17, v17, #0
    195c:      	bit.16b	v16, v28, v17
    1960:      	str	d18, [sp, #0x58]
    1964:      	zip1.8b	v17, v18, v0
    1968:      	ushll.4s	v17, v17, #0x0
    196c:      	shl.4s	v17, v17, #0x1f
    1970:      	cmlt.4s	v17, v17, #0
    1974:      	bit.16b	v4, v23, v17
    1978:      	fmaxnm.4s	v4, v4, v20
    197c:      	fmaxnm.4s	v7, v16, v7
    1980:      	fmaxnm.4s	v6, v7, v6
    1984:      	fmaxnm.4s	v4, v4, v5
    1988:      	fmaxnm.4s	v5, v4, v3
    198c:      	fmaxnm.4s	v20, v6, v2
    1990:      	ldp	q2, q4, [sp, #0xb0]
    1994:      	ldp	q3, q6, [sp, #0x90]
    1998:      	uzp1.4s	v7, v4, v6
    199c:      	uzp1.4s	v4, v3, v2
    19a0:      	movi.4s	v3, #0x1
    19a4:      	eor.16b	v2, v7, v3
    19a8:      	mov.s	w10, v2[1]
    19ac:      	eor.16b	v21, v4, v3
    19b0:      	mov.s	w11, v2[2]
    19b4:      	mov.s	w14, v2[3]
    19b8:      	fmov	w8, s2
    19bc:      	add	x12, sp, #0x588
    19c0:      	bfxil	x12, x8, #0, #3
    19c4:      	str	d25, [sp, #0x588]
    19c8:      	ldrb	w13, [x12]
    19cc:      	umov.b	w27, v25[0]
    19d0:      	and	x8, x8, #0x7
    19d4:      	str	q20, [sp, #0x820]
    19d8:      	str	q5, [sp, #0x810]
    19dc:      	add	x15, sp, #0x810
    19e0:      	ldr	s2, [x15, x8, lsl #2]
    19e4:      	ands	w8, w27, #0x1
    19e8:      	tst	w8, w13
    19ec:      	movi	d18, #0000000000000000
    19f0:      	fcsel	s6, s2, s18, ne
    19f4:      	and	x13, x10, #0x7
    19f8:      	add	x15, sp, #0x588
    19fc:      	bfxil	x15, x10, #0, #3
    1a00:      	ldrb	w10, [x15]
    1a04:      	umov.b	w12, v25[1]
    1a08:      	str	q20, [sp, #0x800]
    1a0c:      	str	q5, [sp, #0x7f0]
    1a10:      	add	x17, sp, #0x7f0
    1a14:      	ldr	s2, [x17, x13, lsl #2]
    1a18:      	and	w10, w12, w10
    1a1c:      	tst	w10, #0x1
    1a20:      	fcsel	s2, s2, s18, ne
    1a24:      	and	x10, x11, #0x7
    1a28:      	add	x13, sp, #0x588
    1a2c:      	bfxil	x13, x11, #0, #3
    1a30:      	ldrb	w11, [x13]
    1a34:      	umov.b	w22, v25[2]
    1a38:      	and	w11, w22, w11
    1a3c:      	str	q20, [sp, #0x7e0]
    1a40:      	str	q5, [sp, #0x7d0]
    1a44:      	add	x17, sp, #0x7d0
    1a48:      	ldr	s3, [x17, x10, lsl #2]
    1a4c:      	tst	w11, #0x1
    1a50:      	fcsel	s3, s3, s18, ne
    1a54:      	and	x10, x14, #0x7
    1a58:      	add	x11, sp, #0x588
    1a5c:      	bfxil	x11, x14, #0, #3
    1a60:      	ldrb	w11, [x11]
    1a64:      	umov.b	w14, v25[3]
    1a68:      	and	w11, w14, w11
    1a6c:      	str	q20, [sp, #0x7c0]
    1a70:      	str	q5, [sp, #0x7b0]
    1a74:      	add	x17, sp, #0x7b0
    1a78:      	ldr	s16, [x17, x10, lsl #2]
    1a7c:      	tst	w11, #0x1
    1a80:      	mov.s	w10, v21[1]
    1a84:      	fcsel	s22, s16, s18, ne
    1a88:      	mov.s	w11, v21[2]
    1a8c:      	mov.s	w17, v21[3]
    1a90:      	fmov	w0, s21
    1a94:      	and	x1, x0, #0x7
    1a98:      	add	x2, sp, #0x588
    1a9c:      	bfxil	x2, x0, #0, #3
    1aa0:      	ldrb	w0, [x2]
    1aa4:      	umov.b	w13, v25[4]
    1aa8:      	and	w0, w13, w0
    1aac:      	str	q20, [sp, #0x8a0]
    1ab0:      	str	q5, [sp, #0x890]
    1ab4:      	add	x2, sp, #0x890
    1ab8:      	ldr	s16, [x2, x1, lsl #2]
    1abc:      	tst	w0, #0x1
    1ac0:      	fcsel	s16, s16, s18, ne
    1ac4:      	and	x0, x10, #0x7
    1ac8:      	add	x1, sp, #0x588
    1acc:      	bfxil	x1, x10, #0, #3
    1ad0:      	umov.b	w2, v25[5]
    1ad4:      	ldrb	w10, [x1]
    1ad8:      	and	w10, w2, w10
    1adc:      	str	q20, [sp, #0x880]
    1ae0:      	str	q5, [sp, #0x870]
    1ae4:      	add	x1, sp, #0x870
    1ae8:      	ldr	s17, [x1, x0, lsl #2]
    1aec:      	tst	w10, #0x1
    1af0:      	fcsel	s17, s17, s18, ne
    1af4:      	and	x10, x11, #0x7
    1af8:      	add	x0, sp, #0x588
    1afc:      	bfxil	x0, x11, #0, #3
    1b00:      	ldrb	w11, [x0]
    1b04:      	umov.b	w15, v25[6]
    1b08:      	str	q20, [sp, #0x860]
    1b0c:      	str	q5, [sp, #0x850]
    1b10:      	add	x0, sp, #0x850
    1b14:      	ldr	s21, [x0, x10, lsl #2]
    1b18:      	and	w10, w15, w11
    1b1c:      	tst	w10, #0x1
    1b20:      	fcsel	s21, s21, s18, ne
    1b24:      	and	x10, x17, #0x7
    1b28:      	add	x11, sp, #0x588
    1b2c:      	bfxil	x11, x17, #0, #3
    1b30:      	ldrb	w11, [x11]
    1b34:      	umov.b	w1, v25[7]
    1b38:      	and	w11, w1, w11
    1b3c:      	str	q20, [sp, #0x840]
    1b40:      	str	q5, [sp, #0x830]
    1b44:      	add	x17, sp, #0x830
    1b48:      	ldr	s23, [x17, x10, lsl #2]
    1b4c:      	tst	w11, #0x1
    1b50:      	fcsel	s23, s23, s18, ne
    1b54:      	mov.s	v16[1], v17[0]
    1b58:      	mov.s	v16[2], v21[0]
    1b5c:      	mov.s	v16[3], v23[0]
    1b60:      	mov.s	v6[1], v2[0]
    1b64:      	mov.s	v6[2], v3[0]
    1b68:      	mov.s	v6[3], v22[0]
    1b6c:      	fmaxnm.4s	v5, v5, v6
    1b70:      	fmaxnm.4s	v6, v20, v16
    1b74:      	movi.4s	v3, #0x2
    1b78:      	eor.16b	v2, v7, v3
    1b7c:      	mov.s	w10, v2[1]
    1b80:      	mov.s	w11, v2[2]
    1b84:      	eor.16b	v20, v4, v3
    1b88:      	mov.s	w17, v2[3]
    1b8c:      	fmov	w0, s2
    1b90:      	add	x3, sp, #0x588
    1b94:      	bfxil	x3, x0, #0, #3
    1b98:      	ldrb	w3, [x3]
    1b9c:      	and	x0, x0, #0x7
    1ba0:      	str	q6, [sp, #0x7a0]
    1ba4:      	str	q5, [sp, #0x790]
    1ba8:      	add	x4, sp, #0x790
    1bac:      	ldr	s2, [x4, x0, lsl #2]
    1bb0:      	tst	w8, w3
    1bb4:      	fcsel	s4, s2, s18, ne
    1bb8:      	and	x0, x10, #0x7
    1bbc:      	add	x3, sp, #0x588
    1bc0:      	bfxil	x3, x10, #0, #3
    1bc4:      	ldrb	w10, [x3]
    1bc8:      	and	w10, w12, w10
    1bcc:      	str	q6, [sp, #0x780]
    1bd0:      	str	q5, [sp, #0x770]
    1bd4:      	add	x3, sp, #0x770
    1bd8:      	ldr	s2, [x3, x0, lsl #2]
    1bdc:      	tst	w10, #0x1
    1be0:      	fcsel	s2, s2, s18, ne
    1be4:      	and	x10, x11, #0x7
    1be8:      	add	x0, sp, #0x588
    1bec:      	bfxil	x0, x11, #0, #3
    1bf0:      	ldrb	w11, [x0]
    1bf4:      	and	w11, w22, w11
    1bf8:      	str	q6, [sp, #0x760]
    1bfc:      	str	q5, [sp, #0x750]
    1c00:      	add	x0, sp, #0x750
    1c04:      	ldr	s3, [x0, x10, lsl #2]
    1c08:      	tst	w11, #0x1
    1c0c:      	fcsel	s3, s3, s18, ne
    1c10:      	and	x10, x17, #0x7
    1c14:      	add	x11, sp, #0x588
    1c18:      	bfxil	x11, x17, #0, #3
    1c1c:      	ldrb	w11, [x11]
    1c20:      	and	w11, w14, w11
    1c24:      	str	q6, [sp, #0x740]
    1c28:      	str	q5, [sp, #0x730]
    1c2c:      	add	x17, sp, #0x730
    1c30:      	ldr	s16, [x17, x10, lsl #2]
    1c34:      	tst	w11, #0x1
    1c38:      	mov.s	w17, v20[3]
    1c3c:      	fmov	w10, s20
    1c40:      	and	x21, x10, #0x7
    1c44:      	add	x28, sp, #0x588
    1c48:      	bfxil	x28, x10, #0, #3
    1c4c:      	add	x10, sp, #0x588
    1c50:      	bfxil	x10, x17, #0, #3
    1c54:      	ldrb	w0, [x10]
    1c58:      	movi.4s	v17, #0x4
    1c5c:      	eor.16b	v7, v7, v17
    1c60:      	mov.s	w3, v7[1]
    1c64:      	mov.s	w11, v7[2]
    1c68:      	mov.s	w10, v7[3]
    1c6c:      	fmov	w30, s7
    1c70:      	add	x4, sp, #0x588
    1c74:      	bfxil	x4, x30, #0, #3
    1c78:      	ldrb	w6, [x4]
    1c7c:      	add	x4, sp, #0x588
    1c80:      	bfxil	x4, x3, #0, #3
    1c84:      	ldrb	w7, [x4]
    1c88:      	add	x4, sp, #0x588
    1c8c:      	bfxil	x4, x11, #0, #3
    1c90:      	ldrb	w5, [x4]
    1c94:      	add	x4, sp, #0x588
    1c98:      	bfxil	x4, x10, #0, #3
    1c9c:      	ldrb	w4, [x4]
    1ca0:      	ldrb	w28, [x28]
    1ca4:      	str	q6, [sp, #0x720]
    1ca8:      	str	q5, [sp, #0x710]
    1cac:      	add	x26, sp, #0x710
    1cb0:      	ldr	s7, [x26, x21, lsl #2]
    1cb4:      	mov.s	w21, v20[1]
    1cb8:      	fcsel	s16, s16, s18, ne
    1cbc:      	and	w28, w13, w28
    1cc0:      	tst	w28, #0x1
    1cc4:      	add	x28, sp, #0x588
    1cc8:      	bfxil	x28, x21, #0, #3
    1ccc:      	and	x21, x21, #0x7
    1cd0:      	ldrb	w28, [x28]
    1cd4:      	str	q6, [sp, #0x700]
    1cd8:      	str	q5, [sp, #0x6f0]
    1cdc:      	add	x26, sp, #0x6f0
    1ce0:      	ldr	s17, [x26, x21, lsl #2]
    1ce4:      	mov.s	w21, v20[2]
    1ce8:      	fcsel	s7, s7, s18, ne
    1cec:      	and	w28, w2, w28
    1cf0:      	tst	w28, #0x1
    1cf4:      	add	x28, sp, #0x588
    1cf8:      	bfxil	x28, x21, #0, #3
    1cfc:      	and	x21, x21, #0x7
    1d00:      	ldrb	w28, [x28]
    1d04:      	str	q6, [sp, #0x6e0]
    1d08:      	str	q5, [sp, #0x6d0]
    1d0c:      	add	x26, sp, #0x6d0
    1d10:      	ldr	s20, [x26, x21, lsl #2]
    1d14:      	fcsel	s17, s17, s18, ne
    1d18:      	and	w21, w15, w28
    1d1c:      	tst	w21, #0x1
    1d20:      	and	x17, x17, #0x7
    1d24:      	str	q6, [sp, #0x6c0]
    1d28:      	str	q5, [sp, #0x6b0]
    1d2c:      	add	x21, sp, #0x6b0
    1d30:      	ldr	s21, [x21, x17, lsl #2]
    1d34:      	fcsel	s20, s20, s18, ne
    1d38:      	and	w17, w1, w0
    1d3c:      	tst	w17, #0x1
    1d40:      	fcsel	s21, s21, s18, ne
    1d44:      	mov.s	v7[1], v17[0]
    1d48:      	mov.s	v7[2], v20[0]
    1d4c:      	mov.s	v7[3], v21[0]
    1d50:      	mov.s	v4[1], v2[0]
    1d54:      	mov.s	v4[2], v3[0]
    1d58:      	mov.s	v4[3], v16[0]
    1d5c:      	fmaxnm.4s	v2, v5, v4
    1d60:      	fmaxnm.4s	v3, v6, v7
    1d64:      	and	x17, x30, #0x7
    1d68:      	str	q3, [sp, #0x6a0]
    1d6c:      	str	q2, [sp, #0x690]
    1d70:      	add	x0, sp, #0x690
    1d74:      	ldr	s4, [x0, x17, lsl #2]
    1d78:      	tst	w8, w6
    1d7c:      	fcsel	s4, s4, s18, ne
    1d80:      	and	x8, x3, #0x7
    1d84:      	and	w17, w12, w7
    1d88:      	str	q3, [sp, #0x680]
    1d8c:      	str	q2, [sp, #0x670]
    1d90:      	add	x0, sp, #0x670
    1d94:      	ldr	s5, [x0, x8, lsl #2]
    1d98:      	tst	w17, #0x1
    1d9c:      	fcsel	s5, s5, s18, ne
    1da0:      	and	x8, x11, #0x7
    1da4:      	and	w11, w22, w5
    1da8:      	str	q3, [sp, #0x660]
    1dac:      	str	q2, [sp, #0x650]
    1db0:      	add	x17, sp, #0x650
    1db4:      	ldr	s6, [x17, x8, lsl #2]
    1db8:      	tst	w11, #0x1
    1dbc:      	fcsel	s6, s6, s18, ne
    1dc0:      	and	x8, x10, #0x7
    1dc4:      	str	q3, [sp, #0x640]
    1dc8:      	str	q2, [sp, #0x630]
    1dcc:      	add	x10, sp, #0x630
    1dd0:      	ldr	s3, [x10, x8, lsl #2]
    1dd4:      	and	w8, w14, w4
    1dd8:      	tst	w8, #0x1
    1ddc:      	fcsel	s3, s3, s18, ne
    1de0:      	ands	w4, w27, #0x1
    1de4:      	mov.s	v4[1], v5[0]
    1de8:      	mov.s	v4[2], v6[0]
    1dec:      	mov.s	v4[3], v3[0]
    1df0:      	fmaxnm.4s	v2, v2, v4
    1df4:      	fcsel	s3, s2, s18, ne
    1df8:      	str	w12, [sp, #0x90]
    1dfc:      	and	w8, w12, w27
    1e00:      	str	w8, [sp, #0x3c]
    1e04:      	tst	w8, #0x1
    1e08:      	fcsel	s4, s2, s18, ne
    1e0c:      	str	w22, [sp, #0xa0]
    1e10:      	and	w6, w22, w27
    1e14:      	tst	w6, #0x1
    1e18:      	fcsel	s5, s2, s18, ne
    1e1c:      	and	w7, w14, w27
    1e20:      	tst	w7, #0x1
    1e24:      	fcsel	s6, s2, s18, ne
    1e28:      	str	w13, [sp, #0xb0]
    1e2c:      	and	w30, w13, w27
    1e30:      	tst	w30, #0x1
    1e34:      	fcsel	s7, s2, s18, ne
    1e38:      	str	w2, [sp, #0xc0]
    1e3c:      	and	w8, w2, w27
    1e40:      	tst	w8, #0x1
    1e44:      	fcsel	s16, s2, s18, ne
    1e48:      	stp	w15, w27, [sp, #0x7c]
    1e4c:      	and	w11, w15, w27
    1e50:      	tst	w11, #0x1
    1e54:      	fcsel	s17, s2, s18, ne
    1e58:      	and	w10, w1, w27
    1e5c:      	tst	w10, #0x1
    1e60:      	mov.s	v3[1], v4[0]
    1e64:      	mov.s	v3[2], v5[0]
    1e68:      	mov.s	v3[3], v6[0]
    1e6c:      	mov.s	v7[1], v16[0]
    1e70:      	mov.s	v7[2], v17[0]
    1e74:      	fcsel	s2, s2, s18, ne
    1e78:      	mov.s	v7[3], v2[0]
    1e7c:      	ldr	w17, [sp, #0xdc]
    1e80:      	rbit	w17, w17
    1e84:      	clz	w3, w17
    1e88:      	str	q7, [sp, #0x5a0]
    1e8c:      	str	q3, [sp, #0x590]
    1e90:      	and	x17, x3, #0x7
    1e94:      	add	x0, sp, #0x590
    1e98:      	ldr	s2, [x0, x17, lsl #2]
    1e9c:      	mov	w17, #-0x800000         ; =-8388608
    1ea0:      	fmov	s3, w17
    1ea4:      	fmaxnm	s2, s2, s3
    1ea8:      	dup.4s	v4, v2[0]
    1eac:      	movi.2d	v6, #0000000000000000
    1eb0:      	movi.2d	v7, #0000000000000000
    1eb4:      	movi.2d	v24, #0000000000000000
    1eb8:      	movi.2d	v13, #0000000000000000
    1ebc:      	mov	w21, #-0x3d300000       ; =-1026555904
    1ec0:      	mov	w26, #0x42c80000        ; =1120403456
    1ec4:      	mov	w28, #0xaa3b            ; =43579
    1ec8:      	movk	w28, #0x3fb8, lsl #16
    1ecc:      	ldr	w22, [sp, #0x78]
    1ed0:      	b	0x2114 <_llm_rows.packet_batch.blocks+0x16bc>
    1ed4:      	lsl	x9, x9, #5
    1ed8:      	add	x17, x24, x9
    1edc:      	ldp	q3, q2, [x17]
    1ee0:      	fsub.4s	v3, v3, v4
    1ee4:      	fsub.4s	v2, v2, v4
    1ee8:      	and.16b	v29, v0, v2
    1eec:      	and.16b	v28, v1, v3
    1ef0:      	dup.4s	v5, w21
    1ef4:      	fcmge.4s	v2, v28, v5
    1ef8:      	fcmge.4s	v3, v29, v5
    1efc:      	dup.4s	v9, w26
    1f00:      	fcmge.4s	v16, v9, v28
    1f04:      	fcmge.4s	v17, v9, v29
    1f08:      	and.16b	v3, v3, v17
    1f0c:      	and.16b	v2, v2, v16
    1f10:      	and.16b	v2, v2, v28
    1f14:      	and.16b	v16, v3, v29
    1f18:      	dup.4s	v11, w28
    1f1c:      	fmul.4s	v3, v16, v11
    1f20:      	fmul.4s	v17, v2, v11
    1f24:      	movi.4s	v18, #0x4b, lsl #24
    1f28:      	mvni.4s	v19, #0x80, lsl #24
    1f2c:      	mov.16b	v21, v19
    1f30:      	bsl.16b	v21, v18, v17
    1f34:      	mov.16b	v22, v19
    1f38:      	bsl.16b	v22, v18, v3
    1f3c:      	fadd.4s	v3, v3, v22
    1f40:      	fadd.4s	v17, v17, v21
    1f44:      	fsub.4s	v17, v17, v21
    1f48:      	fsub.4s	v3, v3, v22
    1f4c:      	fcvtzs.4s	v30, v3
    1f50:      	fcvtzs.4s	v17, v17
    1f54:      	scvtf.4s	v21, v17
    1f58:      	scvtf.4s	v22, v30
    1f5c:      	mov	w17, #0x7200            ; =29184
    1f60:      	movk	w17, #0xbf31, lsl #16
    1f64:      	dup.4s	v3, w17
    1f68:      	fmul.4s	v23, v22, v3
    1f6c:      	fmul.4s	v25, v21, v3
    1f70:      	fadd.4s	v25, v2, v25
    1f74:      	fadd.4s	v16, v16, v23
    1f78:      	mov	w17, #0xbe8e            ; =48782
    1f7c:      	movk	w17, #0xb5bf, lsl #16
    1f80:      	dup.4s	v2, w17
    1f84:      	fmul.4s	v21, v21, v2
    1f88:      	fmul.4s	v22, v22, v2
    1f8c:      	fadd.4s	v16, v16, v22
    1f90:      	fadd.4s	v21, v25, v21
    1f94:      	mov	w17, #0x2bda            ; =11226
    1f98:      	movk	w17, #0x3950, lsl #16
    1f9c:      	dup.4s	v22, w17
    1fa0:      	fmul.4s	v25, v21, v22
    1fa4:      	fmul.4s	v26, v16, v22
    1fa8:      	mov	w17, #0x96c9            ; =38601
    1fac:      	movk	w17, #0x3ab6, lsl #16
    1fb0:      	dup.4s	v23, w17
    1fb4:      	fadd.4s	v26, v26, v23
    1fb8:      	fadd.4s	v25, v25, v23
    1fbc:      	fmul.4s	v27, v21, v25
    1fc0:      	fmul.4s	v26, v16, v26
    1fc4:      	mov	w17, #0x88a6            ; =34982
    1fc8:      	movk	w17, #0x3c08, lsl #16
    1fcc:      	dup.4s	v25, w17
    1fd0:      	fadd.4s	v26, v26, v25
    1fd4:      	fadd.4s	v27, v27, v25
    1fd8:      	fmul.4s	v27, v21, v27
    1fdc:      	fmul.4s	v31, v16, v26
    1fe0:      	mov	w17, #0xaa7a            ; =43642
    1fe4:      	movk	w17, #0x3d2a, lsl #16
    1fe8:      	dup.4s	v26, w17
    1fec:      	fadd.4s	v31, v31, v26
    1ff0:      	fadd.4s	v27, v27, v26
    1ff4:      	fmul.4s	v12, v21, v27
    1ff8:      	fmul.4s	v31, v16, v31
    1ffc:      	mov	w17, #0xaaab            ; =43691
    2000:      	movk	w17, #0x3e2a, lsl #16
    2004:      	dup.4s	v27, w17
    2008:      	fadd.4s	v31, v31, v27
    200c:      	fadd.4s	v12, v12, v27
    2010:      	fmul.4s	v12, v21, v12
    2014:      	fmul.4s	v31, v16, v31
    2018:      	movi.4s	v18, #0x3f, lsl #24
    201c:      	fadd.4s	v31, v31, v18
    2020:      	fadd.4s	v12, v12, v18
    2024:      	fmul.4s	v18, v16, v16
    2028:      	fmul.4s	v19, v21, v21
    202c:      	fmul.4s	v19, v19, v12
    2030:      	fmul.4s	v18, v18, v31
    2034:      	fadd.4s	v16, v16, v18
    2038:      	fadd.4s	v18, v21, v19
    203c:      	fmov.4s	v21, #1.00000000
    2040:      	fadd.4s	v18, v18, v21
    2044:      	fadd.4s	v16, v16, v21
    2048:      	sshr.4s	v19, v17, #0x1
    204c:      	sshr.4s	v31, v30, #0x1
    2050:      	shl.4s	v12, v31, #0x17
    2054:      	add.4s	v12, v12, v21
    2058:      	fmul.4s	v16, v16, v12
    205c:      	shl.4s	v12, v19, #0x17
    2060:      	add.4s	v12, v12, v21
    2064:      	fmul.4s	v18, v18, v12
    2068:      	sub.4s	v30, v30, v31
    206c:      	sub.4s	v17, v17, v19
    2070:      	shl.4s	v17, v17, #0x17
    2074:      	add.4s	v17, v17, v21
    2078:      	fmul.4s	v17, v18, v17
    207c:      	shl.4s	v18, v30, #0x17
    2080:      	add.4s	v18, v18, v21
    2084:      	fmul.4s	v16, v16, v18
    2088:      	fcmgt.4s	v18, v5, v29
    208c:      	bic.16b	v16, v16, v18
    2090:      	fcmgt.4s	v18, v5, v28
    2094:      	bic.16b	v17, v17, v18
    2098:      	fcmgt.4s	v18, v28, v9
    209c:      	ldr	q19, [sp, #0x220]
    20a0:      	bit.16b	v17, v19, v18
    20a4:      	fcmgt.4s	v18, v29, v9
    20a8:      	bit.16b	v16, v19, v18
    20ac:      	fcmeq.4s	v18, v29, v29
    20b0:      	ldr	q29, [sp, #0x210]
    20b4:      	bif.16b	v16, v29, v18
    20b8:      	cmeq.8b	v18, v20, #0
    20bc:      	sshll.8h	v18, v18, #0x0
    20c0:      	fcmeq.4s	v19, v28, v28
    20c4:      	bif.16b	v17, v29, v19
    20c8:      	sshll.4s	v19, v18, #0x0
    20cc:      	bic.16b	v17, v17, v19
    20d0:      	sshll2.4s	v18, v18, #0x0
    20d4:      	bic.16b	v16, v16, v18
    20d8:      	add	x9, x23, x9
    20dc:      	ldp	q18, q19, [x9]
    20e0:      	bif.16b	v16, v19, v0
    20e4:      	bif.16b	v17, v18, v1
    20e8:      	stp	q17, q16, [x9]
    20ec:      	ldp	q17, q16, [sp, #0x260]
    20f0:      	add.2d	v7, v7, v17
    20f4:      	ldr	q12, [sp, #0x240]
    20f8:      	add.2d	v24, v24, v12
    20fc:      	add.2d	v13, v13, v16
    2100:      	ldr	q16, [sp, #0x250]
    2104:      	add.2d	v6, v6, v16
    2108:      	fmov	x9, d6
    210c:      	cmp	x9, #0xc0
    2110:      	b.ge	0x220c <_llm_rows.packet_batch.blocks+0x17b4>
    2114:      	ldr	q2, [sp, #0x230]
    2118:      	fmov	w17, s2
    211c:      	ldr	q2, [sp, #0x280]
    2120:      	add.2d	v2, v6, v2
    2124:      	ldr	q3, [sp, #0x2c0]
    2128:      	add.2d	v2, v3, v2
    212c:      	tbz	w17, #0x0, 0x2148 <_llm_rows.packet_batch.blocks+0x16f0>
    2130:      	fmov	x0, d2
    2134:      	ldr	b20, [x0]
    2138:      	ldr	q3, [sp, #0x200]
    213c:      	and	w5, w17, #0xff
    2140:      	tbnz	w5, #0x1, 0x2158 <_llm_rows.packet_batch.blocks+0x1700>
    2144:      	b	0x2160 <_llm_rows.packet_batch.blocks+0x1708>
    2148:      	movi.2d	v20, #0000000000000000
    214c:      	ldr	q3, [sp, #0x200]
    2150:      	and	w5, w17, #0xff
    2154:      	tbz	w5, #0x1, 0x2160 <_llm_rows.packet_batch.blocks+0x1708>
    2158:      	mov.d	x17, v2[1]
    215c:      	ld1.b	{ v20 }[1], [x17]
    2160:      	ldr	q2, [sp, #0x2a0]
    2164:      	add.2d	v2, v7, v2
    2168:      	ldr	q5, [sp, #0x2e0]
    216c:      	add.2d	v2, v5, v2
    2170:      	tbnz	w5, #0x2, 0x21a8 <_llm_rows.packet_batch.blocks+0x1750>
    2174:      	tbnz	w5, #0x3, 0x21b4 <_llm_rows.packet_batch.blocks+0x175c>
    2178:      	ldr	q2, [sp, #0x290]
    217c:      	add.2d	v2, v24, v2
    2180:      	ldr	q5, [sp, #0x2d0]
    2184:      	add.2d	v2, v5, v2
    2188:      	tbnz	w5, #0x4, 0x21d0 <_llm_rows.packet_batch.blocks+0x1778>
    218c:      	tbnz	w5, #0x5, 0x21dc <_llm_rows.packet_batch.blocks+0x1784>
    2190:      	ldr	q2, [sp, #0x2b0]
    2194:      	add.2d	v2, v13, v2
    2198:      	add.2d	v2, v3, v2
    219c:      	tbnz	w5, #0x6, 0x21f4 <_llm_rows.packet_batch.blocks+0x179c>
    21a0:      	tbz	w5, #0x7, 0x1ed4 <_llm_rows.packet_batch.blocks+0x147c>
    21a4:      	b	0x2200 <_llm_rows.packet_batch.blocks+0x17a8>
    21a8:      	fmov	x17, d2
    21ac:      	ld1.b	{ v20 }[2], [x17]
    21b0:      	tbz	w5, #0x3, 0x2178 <_llm_rows.packet_batch.blocks+0x1720>
    21b4:      	mov.d	x17, v2[1]
    21b8:      	ld1.b	{ v20 }[3], [x17]
    21bc:      	ldr	q2, [sp, #0x290]
    21c0:      	add.2d	v2, v24, v2
    21c4:      	ldr	q5, [sp, #0x2d0]
    21c8:      	add.2d	v2, v5, v2
    21cc:      	tbz	w5, #0x4, 0x218c <_llm_rows.packet_batch.blocks+0x1734>
    21d0:      	fmov	x17, d2
    21d4:      	ld1.b	{ v20 }[4], [x17]
    21d8:      	tbz	w5, #0x5, 0x2190 <_llm_rows.packet_batch.blocks+0x1738>
    21dc:      	mov.d	x17, v2[1]
    21e0:      	ld1.b	{ v20 }[5], [x17]
    21e4:      	ldr	q2, [sp, #0x2b0]
    21e8:      	add.2d	v2, v13, v2
    21ec:      	add.2d	v2, v3, v2
    21f0:      	tbz	w5, #0x6, 0x21a0 <_llm_rows.packet_batch.blocks+0x1748>
    21f4:      	fmov	x17, d2
    21f8:      	ld1.b	{ v20 }[6], [x17]
    21fc:      	tbz	w5, #0x7, 0x1ed4 <_llm_rows.packet_batch.blocks+0x147c>
    2200:      	mov.d	x17, v2[1]
    2204:      	ld1.b	{ v20 }[7], [x17]
    2208:      	b	0x1ed4 <_llm_rows.packet_batch.blocks+0x147c>
    220c:      	ldr	q6, [sp, #0x40]
    2210:      	sshll.4s	v6, v6, #0x0
    2214:      	ldr	q7, [sp, #0x180]
    2218:      	fsub.4s	v16, v7, v4
    221c:      	ldr	q7, [sp, #0x190]
    2220:      	fsub.4s	v4, v7, v4
    2224:      	ldr	q17, [sp, #0x1d0]
    2228:      	zip2.8b	v7, v17, v0
    222c:      	ushll.4s	v7, v7, #0x0
    2230:      	shl.4s	v7, v7, #0x1f
    2234:      	cmlt.4s	v7, v7, #0
    2238:      	and.16b	v4, v7, v4
    223c:      	zip1.8b	v17, v17, v0
    2240:      	ushll.4s	v17, v17, #0x0
    2244:      	shl.4s	v17, v17, #0x1f
    2248:      	cmlt.4s	v20, v17, #0
    224c:      	and.16b	v24, v20, v16
    2250:      	fcmge.4s	v16, v24, v5
    2254:      	fcmge.4s	v17, v4, v5
    2258:      	fcmge.4s	v18, v9, v24
    225c:      	fcmge.4s	v19, v9, v4
    2260:      	and.16b	v17, v17, v19
    2264:      	and.16b	v16, v16, v18
    2268:      	and.16b	v16, v16, v24
    226c:      	and.16b	v17, v17, v4
    2270:      	fmul.4s	v18, v17, v11
    2274:      	fmul.4s	v19, v16, v11
    2278:      	movi.4s	v29, #0x4b, lsl #24
    227c:      	mvni.4s	v30, #0x80, lsl #24
    2280:      	mov.16b	v28, v30
    2284:      	bsl.16b	v28, v29, v19
    2288:      	bif.16b	v29, v18, v30
    228c:      	fadd.4s	v18, v18, v29
    2290:      	fadd.4s	v19, v19, v28
    2294:      	fsub.4s	v19, v19, v28
    2298:      	fsub.4s	v18, v18, v29
    229c:      	fcvtzs.4s	v18, v18
    22a0:      	fcvtzs.4s	v19, v19
    22a4:      	scvtf.4s	v28, v19
    22a8:      	scvtf.4s	v29, v18
    22ac:      	fmul.4s	v30, v29, v3
    22b0:      	fmul.4s	v3, v28, v3
    22b4:      	fadd.4s	v3, v16, v3
    22b8:      	fadd.4s	v16, v17, v30
    22bc:      	fmul.4s	v17, v28, v2
    22c0:      	fmul.4s	v2, v29, v2
    22c4:      	fadd.4s	v2, v16, v2
    22c8:      	fadd.4s	v3, v3, v17
    22cc:      	fmul.4s	v16, v3, v22
    22d0:      	fmul.4s	v17, v2, v22
    22d4:      	fadd.4s	v17, v17, v23
    22d8:      	fadd.4s	v16, v16, v23
    22dc:      	fmul.4s	v16, v3, v16
    22e0:      	fmul.4s	v17, v2, v17
    22e4:      	fadd.4s	v17, v17, v25
    22e8:      	fadd.4s	v16, v16, v25
    22ec:      	fmul.4s	v16, v3, v16
    22f0:      	fmul.4s	v17, v2, v17
    22f4:      	fadd.4s	v17, v17, v26
    22f8:      	fadd.4s	v16, v16, v26
    22fc:      	fmul.4s	v16, v3, v16
    2300:      	fmul.4s	v17, v2, v17
    2304:      	fadd.4s	v17, v17, v27
    2308:      	fadd.4s	v16, v16, v27
    230c:      	fmul.4s	v16, v3, v16
    2310:      	fmul.4s	v17, v2, v17
    2314:      	movi.4s	v22, #0x3f, lsl #24
    2318:      	fadd.4s	v17, v17, v22
    231c:      	fadd.4s	v16, v16, v22
    2320:      	fmul.4s	v22, v2, v2
    2324:      	fmul.4s	v23, v3, v3
    2328:      	fmul.4s	v16, v23, v16
    232c:      	fmul.4s	v17, v22, v17
    2330:      	fadd.4s	v2, v2, v17
    2334:      	fadd.4s	v3, v3, v16
    2338:      	fadd.4s	v3, v3, v21
    233c:      	fadd.4s	v2, v2, v21
    2340:      	sshr.4s	v16, v19, #0x1
    2344:      	sshr.4s	v17, v18, #0x1
    2348:      	shl.4s	v22, v17, #0x17
    234c:      	shl.4s	v23, v16, #0x17
    2350:      	add.4s	v23, v23, v21
    2354:      	add.4s	v22, v22, v21
    2358:      	fmul.4s	v2, v2, v22
    235c:      	fmul.4s	v3, v3, v23
    2360:      	sub.4s	v17, v18, v17
    2364:      	sub.4s	v16, v19, v16
    2368:      	shl.4s	v16, v16, #0x17
    236c:      	shl.4s	v17, v17, #0x17
    2370:      	add.4s	v17, v17, v21
    2374:      	add.4s	v16, v16, v21
    2378:      	fmul.4s	v3, v3, v16
    237c:      	fmul.4s	v2, v2, v17
    2380:      	fcmgt.4s	v16, v5, v4
    2384:      	bic.16b	v2, v2, v16
    2388:      	fcmgt.4s	v5, v5, v24
    238c:      	bic.16b	v3, v3, v5
    2390:      	fcmgt.4s	v5, v4, v9
    2394:      	fcmgt.4s	v16, v24, v9
    2398:      	ldr	q17, [sp, #0x220]
    239c:      	bit.16b	v3, v17, v16
    23a0:      	bit.16b	v2, v17, v5
    23a4:      	fcmeq.4s	v5, v24, v24
    23a8:      	fcmeq.4s	v4, v4, v4
    23ac:      	ldr	q16, [sp, #0x210]
    23b0:      	bif.16b	v2, v16, v4
    23b4:      	bif.16b	v3, v16, v5
    23b8:      	bic.16b	v6, v3, v6
    23bc:      	ldr	q3, [sp, #0x60]
    23c0:      	bic.16b	v4, v2, v3
    23c4:      	ldr	x9, [sp, #0xe0]
    23c8:      	add	x9, x23, x9
    23cc:      	ldp	q2, q3, [x9]
    23d0:      	bit.16b	v3, v4, v7
    23d4:      	bit.16b	v2, v6, v20
    23d8:      	stp	q2, q3, [x9]
    23dc:      	ldp	q3, q2, [x23, #0x60]
    23e0:      	and.16b	v2, v0, v2
    23e4:      	and.16b	v3, v1, v3
    23e8:      	ldp	q5, q7, [x23, #0x40]
    23ec:      	and.16b	v20, v0, v7
    23f0:      	and.16b	v7, v1, v5
    23f4:      	ldp	q5, q16, [x23, #0x20]
    23f8:      	and.16b	v21, v0, v16
    23fc:      	and.16b	v22, v1, v5
    2400:      	ldr	x9, [sp, #0x70]
    2404:      	add	x9, x23, x9
    2408:      	ldp	q5, q16, [x9]
    240c:      	and.16b	v25, v0, v16
    2410:      	and.16b	v24, v1, v5
    2414:      	ldp	q11, q9, [sp, #0x1a0]
    2418:      	mov	w27, #0x4               ; =4
    241c:      	sshll.2d	v5, v1, #0x0
    2420:      	sshll.2d	v16, v0, #0x0
    2424:      	add	x9, x23, x16, lsl #5
    2428:      	ldp	q18, q17, [x9]
    242c:      	fadd.4s	v26, v24, v18
    2430:      	fadd.4s	v27, v25, v17
    2434:      	ldp	q18, q17, [x9, #0x20]
    2438:      	fadd.4s	v18, v22, v18
    243c:      	fadd.4s	v17, v21, v17
    2440:      	ldp	q23, q19, [x9, #0x40]
    2444:      	fadd.4s	v23, v7, v23
    2448:      	fadd.4s	v19, v20, v19
    244c:      	ldp	q29, q28, [x9, #0x60]
    2450:      	fadd.4s	v29, v3, v29
    2454:      	fadd.4s	v28, v2, v28
    2458:      	dup.2d	v30, x27
    245c:      	and.16b	v31, v11, v30
    2460:      	add.2d	v14, v14, v31
    2464:      	and.16b	v31, v9, v30
    2468:      	add.2d	v15, v15, v31
    246c:      	and.16b	v16, v16, v30
    2470:      	add.2d	v8, v8, v16
    2474:      	and.16b	v5, v5, v30
    2478:      	add.2d	v10, v10, v5
    247c:      	bit.16b	v25, v27, v0
    2480:      	bit.16b	v24, v26, v1
    2484:      	bit.16b	v21, v17, v0
    2488:      	bit.16b	v22, v18, v1
    248c:      	bit.16b	v20, v19, v0
    2490:      	bit.16b	v7, v23, v1
    2494:      	bit.16b	v2, v28, v0
    2498:      	bit.16b	v3, v29, v1
    249c:      	fmov	x16, d10
    24a0:      	cmp	x16, #0xc0
    24a4:      	b.lt	0x241c <_llm_rows.packet_batch.blocks+0x19c4>
    24a8:      	mov	x9, #0x0                ; =0
    24ac:      	adrp	x16, 0x2000 <_llm_rows.packet_batch.blocks+0x15a8>
    24b0:      	ldr	q5, [x16]
    24b4:      	and.16b	v23, v0, v5
    24b8:      	adrp	x16, 0x2000 <_llm_rows.packet_batch.blocks+0x15a8>
    24bc:      	ldr	q5, [x16]
    24c0:      	and.16b	v28, v1, v5
    24c4:      	adrp	x16, 0x2000 <_llm_rows.packet_batch.blocks+0x15a8>
    24c8:      	ldr	q5, [x16]
    24cc:      	and.16b	v5, v1, v5
    24d0:      	fadd.4s	v16, v4, v25
    24d4:      	fadd.4s	v17, v6, v24
    24d8:      	ldr	q25, [sp, #0x1d0]
    24dc:      	zip1.8b	v18, v25, v0
    24e0:      	ushll.4s	v18, v18, #0x0
    24e4:      	shl.4s	v18, v18, #0x1f
    24e8:      	cmlt.4s	v18, v18, #0
    24ec:      	and.16b	v17, v18, v17
    24f0:      	zip2.8b	v18, v25, v0
    24f4:      	ushll.4s	v18, v18, #0x0
    24f8:      	shl.4s	v18, v18, #0x1f
    24fc:      	cmlt.4s	v18, v18, #0
    2500:      	and.16b	v16, v18, v16
    2504:      	ldr	d19, [sp, #0x58]
    2508:      	zip2.8b	v18, v19, v0
    250c:      	ushll.4s	v18, v18, #0x0
    2510:      	shl.4s	v18, v18, #0x1f
    2514:      	cmlt.4s	v18, v18, #0
    2518:      	bit.16b	v16, v27, v18
    251c:      	zip1.8b	v18, v19, v0
    2520:      	ushll.4s	v18, v18, #0x0
    2524:      	shl.4s	v18, v18, #0x1f
    2528:      	cmlt.4s	v18, v18, #0
    252c:      	bit.16b	v17, v26, v18
    2530:      	fadd.4s	v17, v22, v17
    2534:      	fadd.4s	v16, v21, v16
    2538:      	fadd.4s	v16, v20, v16
    253c:      	fadd.4s	v7, v7, v17
    2540:      	fadd.4s	v3, v3, v7
    2544:      	fadd.4s	v7, v2, v16
    2548:      	fmov	w16, s28
    254c:      	add	x17, sp, #0x338
    2550:      	bfxil	x17, x16, #0, #3
    2554:      	ldr	q2, [sp, #0x1c0]
    2558:      	str	d2, [sp, #0x338]
    255c:      	ldrb	w17, [x17]
    2560:      	add	x0, sp, #0x560
    2564:      	orr	x16, x0, x16, lsl #2
    2568:      	str	q7, [sp, #0x570]
    256c:      	str	q3, [sp, #0x560]
    2570:      	ldr	s2, [x16]
    2574:      	tst	w4, w17
    2578:      	movi	d24, #0000000000000000
    257c:      	fcsel	s2, s2, s24, ne
    2580:      	mov.s	w16, v28[1]
    2584:      	add	x17, sp, #0x338
    2588:      	bfxil	x17, x16, #0, #3
    258c:      	ldrb	w16, [x17]
    2590:      	ldr	w12, [sp, #0x90]
    2594:      	and	w16, w12, w16
    2598:      	str	q3, [sp, #0x540]
    259c:      	ldr	s16, [sp, #0x540]
    25a0:      	tst	w16, #0x1
    25a4:      	fcsel	s20, s16, s24, ne
    25a8:      	mov.s	w16, v28[2]
    25ac:      	add	x17, sp, #0x338
    25b0:      	bfxil	x17, x16, #0, #3
    25b4:      	add	x0, sp, #0x520
    25b8:      	orr	x16, x0, x16, lsl #2
    25bc:      	ldrb	w17, [x17]
    25c0:      	ldr	w13, [sp, #0xa0]
    25c4:      	and	w17, w13, w17
    25c8:      	str	q7, [sp, #0x530]
    25cc:      	str	q3, [sp, #0x520]
    25d0:      	ldr	s16, [x16]
    25d4:      	tst	w17, #0x1
    25d8:      	fcsel	s21, s16, s24, ne
    25dc:      	mov.s	w16, v28[3]
    25e0:      	add	x17, sp, #0x338
    25e4:      	bfxil	x17, x16, #0, #3
    25e8:      	add	x0, sp, #0x500
    25ec:      	orr	x16, x0, x16, lsl #2
    25f0:      	ldrb	w17, [x17]
    25f4:      	and	w17, w14, w17
    25f8:      	str	q7, [sp, #0x510]
    25fc:      	str	q3, [sp, #0x500]
    2600:      	ldr	s16, [x16]
    2604:      	tst	w17, #0x1
    2608:      	fcsel	s22, s16, s24, ne
    260c:      	fmov	w16, s23
    2610:      	add	x17, sp, #0x338
    2614:      	bfxil	x17, x16, #0, #3
    2618:      	ldrb	w17, [x17]
    261c:      	ldr	w5, [sp, #0xb0]
    2620:      	and	w17, w5, w17
    2624:      	str	q7, [sp, #0x4f0]
    2628:      	str	q3, [sp, #0x4e0]
    262c:      	add	x0, sp, #0x4e0
    2630:      	ldr	s16, [x0, w16, uxtw #2]
    2634:      	tst	w17, #0x1
    2638:      	fcsel	s16, s16, s24, ne
    263c:      	mov.s	w16, v23[1]
    2640:      	add	x17, sp, #0x338
    2644:      	bfxil	x17, x16, #0, #3
    2648:      	ldrb	w17, [x17]
    264c:      	ldr	w2, [sp, #0xc0]
    2650:      	and	w17, w2, w17
    2654:      	str	q7, [sp, #0x4d0]
    2658:      	str	q3, [sp, #0x4c0]
    265c:      	add	x0, sp, #0x4c0
    2660:      	ldr	s17, [x0, w16, uxtw #2]
    2664:      	tst	w17, #0x1
    2668:      	fcsel	s17, s17, s24, ne
    266c:      	mov.s	w16, v23[2]
    2670:      	add	x17, sp, #0x338
    2674:      	bfxil	x17, x16, #0, #3
    2678:      	ldrb	w17, [x17]
    267c:      	ldr	w21, [sp, #0x7c]
    2680:      	and	w17, w21, w17
    2684:      	str	q7, [sp, #0x4b0]
    2688:      	str	q3, [sp, #0x4a0]
    268c:      	add	x0, sp, #0x4a0
    2690:      	ldr	s18, [x0, w16, uxtw #2]
    2694:      	tst	w17, #0x1
    2698:      	fcsel	s18, s18, s24, ne
    269c:      	mov.s	w16, v23[3]
    26a0:      	add	x17, sp, #0x338
    26a4:      	bfxil	x17, x16, #0, #3
    26a8:      	ldrb	w17, [x17]
    26ac:      	and	w17, w1, w17
    26b0:      	str	q7, [sp, #0x490]
    26b4:      	str	q3, [sp, #0x480]
    26b8:      	add	x0, sp, #0x480
    26bc:      	ldr	s19, [x0, w16, uxtw #2]
    26c0:      	tst	w17, #0x1
    26c4:      	fcsel	s19, s19, s24, ne
    26c8:      	mov.s	v16[1], v17[0]
    26cc:      	mov.s	v16[2], v18[0]
    26d0:      	mov.s	v16[3], v19[0]
    26d4:      	mov.s	v2[1], v20[0]
    26d8:      	mov.s	v2[2], v21[0]
    26dc:      	mov.s	v2[3], v22[0]
    26e0:      	fadd.4s	v2, v3, v2
    26e4:      	fadd.4s	v3, v7, v16
    26e8:      	fmov	w16, s5
    26ec:      	add	x17, sp, #0x338
    26f0:      	bfxil	x17, x16, #0, #3
    26f4:      	ldrb	w17, [x17]
    26f8:      	add	x0, sp, #0x460
    26fc:      	orr	x16, x0, x16, lsl #2
    2700:      	str	q3, [sp, #0x470]
    2704:      	str	q2, [sp, #0x460]
    2708:      	ldr	s7, [x16]
    270c:      	mov.s	w16, v5[1]
    2710:      	tst	w4, w17
    2714:      	add	x17, sp, #0x338
    2718:      	bfxil	x17, x16, #0, #3
    271c:      	ldrb	w17, [x17]
    2720:      	and	w15, w12, w17
    2724:      	fcsel	s7, s7, s24, ne
    2728:      	add	x17, sp, #0x440
    272c:      	orr	x16, x17, x16, lsl #2
    2730:      	str	q3, [sp, #0x450]
    2734:      	str	q2, [sp, #0x440]
    2738:      	ldr	s16, [x16]
    273c:      	mov.s	w16, v5[2]
    2740:      	tst	w15, #0x1
    2744:      	add	x15, sp, #0x338
    2748:      	bfxil	x15, x16, #0, #3
    274c:      	adrp	x16, 0x2000 <_llm_rows.packet_batch.blocks+0x15a8>
    2750:      	ldr	q17, [x16]
    2754:      	and.16b	v17, v0, v17
    2758:      	movi.4s	v18, #0x4
    275c:      	and.16b	v20, v1, v18
    2760:      	fcsel	s21, s16, s24, ne
    2764:      	ldrb	w15, [x15]
    2768:      	and	w13, w13, w15
    276c:      	str	q2, [sp, #0x420]
    2770:      	ldr	s16, [sp, #0x420]
    2774:      	tst	w13, #0x1
    2778:      	fcsel	s22, s16, s24, ne
    277c:      	mov.s	w13, v5[3]
    2780:      	add	x15, sp, #0x338
    2784:      	bfxil	x15, x13, #0, #3
    2788:      	add	x16, sp, #0x400
    278c:      	orr	x13, x16, x13, lsl #2
    2790:      	ldrb	w15, [x15]
    2794:      	and	w14, w14, w15
    2798:      	str	q3, [sp, #0x410]
    279c:      	str	q2, [sp, #0x400]
    27a0:      	ldr	s5, [x13]
    27a4:      	tst	w14, #0x1
    27a8:      	fcsel	s5, s5, s24, ne
    27ac:      	fmov	w13, s17
    27b0:      	add	x14, sp, #0x338
    27b4:      	bfxil	x14, x13, #0, #3
    27b8:      	ldrb	w14, [x14]
    27bc:      	and	w14, w5, w14
    27c0:      	stp	q2, q3, [sp, #0x3e0]
    27c4:      	add	x15, sp, #0x3e0
    27c8:      	ldr	s16, [x15, w13, uxtw #2]
    27cc:      	tst	w14, #0x1
    27d0:      	fcsel	s16, s16, s24, ne
    27d4:      	mov.s	w13, v17[1]
    27d8:      	add	x14, sp, #0x338
    27dc:      	bfxil	x14, x13, #0, #3
    27e0:      	ldrb	w14, [x14]
    27e4:      	and	w14, w2, w14
    27e8:      	stp	q2, q3, [sp, #0x3c0]
    27ec:      	add	x15, sp, #0x3c0
    27f0:      	ldr	s18, [x15, w13, uxtw #2]
    27f4:      	tst	w14, #0x1
    27f8:      	fcsel	s18, s18, s24, ne
    27fc:      	mov.s	w13, v17[2]
    2800:      	add	x14, sp, #0x338
    2804:      	bfxil	x14, x13, #0, #3
    2808:      	ldrb	w14, [x14]
    280c:      	and	w14, w21, w14
    2810:      	stp	q2, q3, [sp, #0x3a0]
    2814:      	add	x15, sp, #0x3a0
    2818:      	ldr	s19, [x15, w13, uxtw #2]
    281c:      	tst	w14, #0x1
    2820:      	fcsel	s19, s19, s24, ne
    2824:      	mov.s	w13, v17[3]
    2828:      	add	x14, sp, #0x338
    282c:      	bfxil	x14, x13, #0, #3
    2830:      	ldrb	w14, [x14]
    2834:      	and	w14, w1, w14
    2838:      	stp	q2, q3, [sp, #0x380]
    283c:      	add	x15, sp, #0x380
    2840:      	ldr	s17, [x15, w13, uxtw #2]
    2844:      	tst	w14, #0x1
    2848:      	fcsel	s17, s17, s24, ne
    284c:      	mov.s	v16[1], v18[0]
    2850:      	mov.s	v16[2], v19[0]
    2854:      	mov.s	v16[3], v17[0]
    2858:      	mov.s	v7[1], v21[0]
    285c:      	mov.s	v7[2], v22[0]
    2860:      	mov.s	v7[3], v5[0]
    2864:      	fadd.4s	v2, v2, v7
    2868:      	fadd.4s	v3, v3, v16
    286c:      	fmov	w13, s20
    2870:      	add	x14, sp, #0x338
    2874:      	orr	x14, x14, x13
    2878:      	ldrb	w14, [x14]
    287c:      	stp	q2, q3, [sp, #0x360]
    2880:      	add	x15, sp, #0x360
    2884:      	ldr	s3, [x15, w13, uxtw #2]
    2888:      	tst	w4, w14
    288c:      	fcsel	s3, s3, s24, ne
    2890:      	ldr	w12, [sp, #0x80]
    2894:      	tst	w12, #0x1
    2898:      	fadd	s2, s2, s3
    289c:      	fcsel	s3, s2, s24, ne
    28a0:      	ldr	w12, [sp, #0x3c]
    28a4:      	tst	w12, #0x1
    28a8:      	fcsel	s5, s2, s24, ne
    28ac:      	tst	w6, #0x1
    28b0:      	fcsel	s7, s2, s24, ne
    28b4:      	tst	w7, #0x1
    28b8:      	fcsel	s16, s2, s24, ne
    28bc:      	tst	w30, #0x1
    28c0:      	fcsel	s17, s2, s24, ne
    28c4:      	tst	w8, #0x1
    28c8:      	fcsel	s18, s2, s24, ne
    28cc:      	tst	w11, #0x1
    28d0:      	fcsel	s19, s2, s24, ne
    28d4:      	tst	w10, #0x1
    28d8:      	fcsel	s2, s2, s24, ne
    28dc:      	mov.s	v3[1], v5[0]
    28e0:      	mov.s	v3[2], v7[0]
    28e4:      	mov.s	v3[3], v16[0]
    28e8:      	mov.s	v17[1], v18[0]
    28ec:      	mov.s	v17[2], v19[0]
    28f0:      	mov.s	v17[3], v2[0]
    28f4:      	stp	q3, q17, [sp, #0x340]
    28f8:      	and	x8, x3, #0x7
    28fc:      	add	x10, sp, #0x340
    2900:      	ldr	s2, [x10, x8, lsl #2]
    2904:      	fadd	s2, s2, s24
    2908:      	dup.4s	v5, v2[0]
    290c:      	ldr	q2, [sp, #0xf0]
    2910:      	fmov	x8, d2
    2914:      	ldp	x14, x13, [sp, #0x148]
    2918:      	add	x8, x13, x8, lsl #2
    291c:      	movi.2d	v2, #0000000000000000
    2920:      	movi.2d	v3, #0000000000000000
    2924:      	movi.2d	v7, #0000000000000000
    2928:      	movi.2d	v20, #0000000000000000
    292c:      	ldr	w12, [sp, #0x158]
    2930:      	ldr	q17, [sp, #0x230]
    2934:      	ldp	q19, q18, [sp, #0x260]
    2938:      	ldr	q23, [sp, #0x250]
    293c:      	b	0x295c <_llm_rows.packet_batch.blocks+0x1f04>
    2940:      	add.2d	v3, v3, v19
    2944:      	add.2d	v7, v7, v12
    2948:      	add.2d	v20, v20, v18
    294c:      	add.2d	v2, v2, v23
    2950:      	fmov	x9, d2
    2954:      	cmp	x9, #0xc0
    2958:      	b.ge	0x2a0c <_llm_rows.packet_batch.blocks+0x1fb4>
    295c:      	fmov	w10, s17
    2960:      	lsl	x9, x9, #5
    2964:      	add	x11, x23, x9
    2968:      	ldp	q16, q21, [x11]
    296c:      	and.16b	v16, v1, v16
    2970:      	fdiv.4s	v22, v16, v5
    2974:      	add	x9, x8, x9
    2978:      	tbnz	w10, #0x0, 0x29a8 <_llm_rows.packet_batch.blocks+0x1f50>
    297c:      	and	w10, w10, #0xff
    2980:      	tbnz	w10, #0x1, 0x29b4 <_llm_rows.packet_batch.blocks+0x1f5c>
    2984:      	tbnz	w10, #0x2, 0x29c0 <_llm_rows.packet_batch.blocks+0x1f68>
    2988:      	tbnz	w10, #0x3, 0x29cc <_llm_rows.packet_batch.blocks+0x1f74>
    298c:      	and.16b	v16, v0, v21
    2990:      	fdiv.4s	v21, v16, v5
    2994:      	tbnz	w10, #0x4, 0x29e0 <_llm_rows.packet_batch.blocks+0x1f88>
    2998:      	tbnz	w10, #0x5, 0x29e8 <_llm_rows.packet_batch.blocks+0x1f90>
    299c:      	tbnz	w10, #0x6, 0x29f4 <_llm_rows.packet_batch.blocks+0x1f9c>
    29a0:      	tbz	w10, #0x7, 0x2940 <_llm_rows.packet_batch.blocks+0x1ee8>
    29a4:      	b	0x2a00 <_llm_rows.packet_batch.blocks+0x1fa8>
    29a8:      	str	s22, [x9]
    29ac:      	and	w10, w10, #0xff
    29b0:      	tbz	w10, #0x1, 0x2984 <_llm_rows.packet_batch.blocks+0x1f2c>
    29b4:      	add	x11, x9, #0x4
    29b8:      	st1.s	{ v22 }[1], [x11]
    29bc:      	tbz	w10, #0x2, 0x2988 <_llm_rows.packet_batch.blocks+0x1f30>
    29c0:      	add	x11, x9, #0x8
    29c4:      	st1.s	{ v22 }[2], [x11]
    29c8:      	tbz	w10, #0x3, 0x298c <_llm_rows.packet_batch.blocks+0x1f34>
    29cc:      	add	x11, x9, #0xc
    29d0:      	st1.s	{ v22 }[3], [x11]
    29d4:      	and.16b	v16, v0, v21
    29d8:      	fdiv.4s	v21, v16, v5
    29dc:      	tbz	w10, #0x4, 0x2998 <_llm_rows.packet_batch.blocks+0x1f40>
    29e0:      	str	s21, [x9, #0x10]
    29e4:      	tbz	w10, #0x5, 0x299c <_llm_rows.packet_batch.blocks+0x1f44>
    29e8:      	add	x11, x9, #0x14
    29ec:      	st1.s	{ v21 }[1], [x11]
    29f0:      	tbz	w10, #0x6, 0x29a0 <_llm_rows.packet_batch.blocks+0x1f48>
    29f4:      	add	x11, x9, #0x18
    29f8:      	st1.s	{ v21 }[2], [x11]
    29fc:      	tbz	w10, #0x7, 0x2940 <_llm_rows.packet_batch.blocks+0x1ee8>
    2a00:      	add	x9, x9, #0x1c
    2a04:      	st1.s	{ v21 }[3], [x9]
    2a08:      	b	0x2940 <_llm_rows.packet_batch.blocks+0x1ee8>
    2a0c:      	ldr	d0, [sp, #0xe8]
    2a10:      	fmov	w8, s0
    2a14:      	zip1.8b	v0, v25, v0
    2a18:      	ushll.4s	v0, v0, #0x0
    2a1c:      	shl.4s	v0, v0, #0x1f
    2a20:      	cmlt.4s	v0, v0, #0
    2a24:      	and.16b	v0, v0, v6
    2a28:      	fdiv.4s	v0, v0, v5
    2a2c:      	ldp	q1, q2, [sp, #0x120]
    2a30:      	ldp	q6, q3, [sp, #0x100]
    2a34:      	stp	q2, q3, [sp, #0x2f0]
    2a38:      	stp	q6, q1, [sp, #0x310]
    2a3c:      	and	x9, x14, #0x7
    2a40:      	add	x10, sp, #0x2f0
    2a44:      	ldr	x9, [x10, x9, lsl #3]
    2a48:      	sub	x9, x9, x14
    2a4c:      	add	x9, x13, x9, lsl #2
    2a50:      	tbnz	w8, #0x0, 0x2ad4 <_llm_rows.packet_batch.blocks+0x207c>
    2a54:      	tbnz	w8, #0x1, 0x2adc <_llm_rows.packet_batch.blocks+0x2084>
    2a58:      	tbnz	w8, #0x2, 0x2ae8 <_llm_rows.packet_batch.blocks+0x2090>
    2a5c:      	tbz	w8, #0x3, 0x2a68 <_llm_rows.packet_batch.blocks+0x2010>
    2a60:      	add	x10, x9, #0xc
    2a64:      	st1.s	{ v0 }[3], [x10]
    2a68:      	zip2.8b	v0, v25, v0
    2a6c:      	ushll.4s	v0, v0, #0x0
    2a70:      	shl.4s	v0, v0, #0x1f
    2a74:      	cmlt.4s	v0, v0, #0
    2a78:      	and.16b	v0, v0, v4
    2a7c:      	fdiv.4s	v0, v0, v5
    2a80:      	tbnz	w8, #0x4, 0x2af8 <_llm_rows.packet_batch.blocks+0x20a0>
    2a84:      	tbnz	w8, #0x5, 0x2b00 <_llm_rows.packet_batch.blocks+0x20a8>
    2a88:      	tbnz	w8, #0x6, 0x2b0c <_llm_rows.packet_batch.blocks+0x20b4>
    2a8c:      	tbz	w8, #0x7, 0xb14 <_llm_rows.packet_batch.blocks+0xbc>
    2a90:      	b	0x2b18 <_llm_rows.packet_batch.blocks+0x20c0>
    2a94:      	fmov	x11, d13
    2a98:      	ld1.b	{ v3 }[2], [x11]
    2a9c:      	tbz	w12, #0x3, 0x1748 <_llm_rows.packet_batch.blocks+0xcf0>
    2aa0:      	ld1.b	{ v3 }[3], [x10]
    2aa4:      	tbz	w12, #0x4, 0x174c <_llm_rows.packet_batch.blocks+0xcf4>
    2aa8:      	fmov	x10, d24
    2aac:      	ld1.b	{ v3 }[4], [x10]
    2ab0:      	tbz	w12, #0x5, 0x1750 <_llm_rows.packet_batch.blocks+0xcf8>
    2ab4:      	ld1.b	{ v3 }[5], [x9]
    2ab8:      	tbz	w12, #0x6, 0x1754 <_llm_rows.packet_batch.blocks+0xcfc>
    2abc:      	fmov	x9, d20
    2ac0:      	ld1.b	{ v3 }[6], [x9]
    2ac4:      	str	q30, [sp, #0x200]
    2ac8:      	str	d19, [sp, #0xe8]
    2acc:      	tbnz	w12, #0x7, 0x1760 <_llm_rows.packet_batch.blocks+0xd08>
    2ad0:      	b	0x1764 <_llm_rows.packet_batch.blocks+0xd0c>
    2ad4:      	str	s0, [x9]
    2ad8:      	tbz	w8, #0x1, 0x2a58 <_llm_rows.packet_batch.blocks+0x2000>
    2adc:      	add	x10, x9, #0x4
    2ae0:      	st1.s	{ v0 }[1], [x10]
    2ae4:      	tbz	w8, #0x2, 0x2a5c <_llm_rows.packet_batch.blocks+0x2004>
    2ae8:      	add	x10, x9, #0x8
    2aec:      	st1.s	{ v0 }[2], [x10]
    2af0:      	tbnz	w8, #0x3, 0x2a60 <_llm_rows.packet_batch.blocks+0x2008>
    2af4:      	b	0x2a68 <_llm_rows.packet_batch.blocks+0x2010>
    2af8:      	str	s0, [x9, #0x10]
    2afc:      	tbz	w8, #0x5, 0x2a88 <_llm_rows.packet_batch.blocks+0x2030>
    2b00:      	add	x10, x9, #0x14
    2b04:      	st1.s	{ v0 }[1], [x10]
    2b08:      	tbz	w8, #0x6, 0x2a8c <_llm_rows.packet_batch.blocks+0x2034>
    2b0c:      	add	x10, x9, #0x18
    2b10:      	st1.s	{ v0 }[2], [x10]
    2b14:      	tbz	w8, #0x7, 0xb14 <_llm_rows.packet_batch.blocks+0xbc>
    2b18:      	add	x8, x9, #0x1c
    2b1c:      	st1.s	{ v0 }[3], [x8]
    2b20:      	b	0xb14 <_llm_rows.packet_batch.blocks+0xbc>
    2b24:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
    2b28:      	add	sp, sp, #0x830
    2b2c:      	ldp	x29, x30, [sp, #0x90]
    2b30:      	ldp	x20, x19, [sp, #0x80]
    2b34:      	ldp	x22, x21, [sp, #0x70]
    2b38:      	ldp	x24, x23, [sp, #0x60]
    2b3c:      	ldp	x26, x25, [sp, #0x50]
    2b40:      	ldp	x28, x27, [sp, #0x40]
    2b44:      	ldp	d9, d8, [sp, #0x30]
    2b48:      	ldp	d11, d10, [sp, #0x20]
    2b4c:      	ldp	d13, d12, [sp, #0x10]
    2b50:      	ldp	d15, d14, [sp], #0xa0
    2b54:      	ret

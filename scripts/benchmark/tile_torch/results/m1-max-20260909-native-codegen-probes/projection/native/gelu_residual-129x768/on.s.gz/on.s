
/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/gelu_residual-129x768/on/object/tile_xir_w8_38043_1788936544411556_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0x80]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x24, x23, [sp, #0x40]
      14:      	stp	x22, x21, [sp, #0x50]
      18:      	stp	x20, x19, [sp, #0x60]
      1c:      	stp	x29, x30, [sp, #0x70]
      20:      	sub	sp, sp, #0x1, lsl #12   ; =0x1000
      24:      	sub	sp, sp, #0x930
      28:      	ldr	x11, [x0]
      2c:      	ldr	x23, [x0, #0x10]
      30:      	ldr	x21, [x0, #0x30]
      34:      	ldr	w8, [x1]
      38:      	ldr	w9, [x1, #0x24]
      3c:      	add	w8, w9, w8, lsl #5
      40:      	lsr	w8, w8, #3
      44:      	subs	x9, x11, x21
      48:      	lsr	x9, x9, #10
      4c:      	mov	w10, #0x182             ; =386
      50:      	ccmp	x9, x10, #0x0, hs
      54:      	cset	w9, hi
      58:      	subs	x12, x21, x11
      5c:      	lsr	x12, x12, #10
      60:      	ccmp	x12, x10, #0x0, hs
      64:      	csinc	w9, w9, wzr, ls
      68:      	subs	x12, x23, x21
      6c:      	lsr	x12, x12, #10
      70:      	ccmp	x12, x10, #0x0, hs
      74:      	cset	w12, hi
      78:      	subs	x13, x21, x23
      7c:      	lsr	x13, x13, #10
      80:      	ccmp	x13, x10, #0x0, hs
      84:      	csinc	w10, w12, wzr, ls
      88:      	mov	w12, #0xc00             ; =3072
      8c:      	umull	x22, w8, w12
      90:      	cmp	w9, #0x1
      94:      	ccmp	w10, #0x0, #0x4, eq
      98:      	b.ne	0x528 <ltmp0+0x528>
      9c:      	add	x19, sp, #0xd30
      a0:      	add	x0, sp, #0xd30
      a4:      	add	x1, x11, x22
      a8:      	mov	w2, #0xc00              ; =3072
      ac:      	bl	0xac <ltmp0+0xac>
      b0:      	add	x20, sp, #0x130
      b4:      	add	x0, sp, #0x130
      b8:      	add	x1, x23, x22
      bc:      	mov	w2, #0xc00              ; =3072
      c0:      	bl	0xc0 <ltmp0+0xc0>
      c4:      	mov	x8, #0x0                ; =0
      c8:      	mov	w9, #0x2713             ; =10003
      cc:      	movk	w9, #0x3d37, lsl #16
      d0:      	dup.4s	v1, w9
      d4:      	mov	w9, #0x422a             ; =16938
      d8:      	movk	w9, #0x3f4c, lsl #16
      dc:      	dup.4s	v0, w9
      e0:      	stp	q0, q1, [sp, #0x110]
      e4:      	mov	w9, #0x9231             ; =37425
      e8:      	movk	w9, #0x2f30, lsl #16
      ec:      	dup.4s	v1, w9
      f0:      	mov	w9, #0x322b             ; =12843
      f4:      	movk	w9, #0x32d7, lsl #16
      f8:      	dup.4s	v0, w9
      fc:      	stp	q0, q1, [sp, #0xf0]
     100:      	mov	w9, #0xef1d             ; =61213
     104:      	movk	w9, #0x3638, lsl #16
     108:      	dup.4s	v1, w9
     10c:      	mov	w9, #0xd01              ; =3329
     110:      	movk	w9, #0x3950, lsl #16
     114:      	dup.4s	v0, w9
     118:      	stp	q0, q1, [sp, #0xd0]
     11c:      	mov	w9, #0x8889             ; =34953
     120:      	movk	w9, #0x3c08, lsl #16
     124:      	dup.4s	v1, w9
     128:      	mov	w9, #0xaaab             ; =43691
     12c:      	movk	w9, #0x3e2a, lsl #16
     130:      	dup.4s	v20, w9
     134:      	mov	w9, #0x76c7             ; =30407
     138:      	movk	w9, #0x310f, lsl #16
     13c:      	dup.4s	v0, w9
     140:      	stp	q0, q1, [sp, #0xb0]
     144:      	mov	w9, #0xf27e             ; =62078
     148:      	movk	w9, #0x3493, lsl #16
     14c:      	dup.4s	v1, w9
     150:      	mov	w9, #0xd01              ; =3329
     154:      	movk	w9, #0x37d0, lsl #16
     158:      	dup.4s	v0, w9
     15c:      	stp	q0, q1, [sp, #0x90]
     160:      	mov	w9, #0xb61              ; =2913
     164:      	movk	w9, #0x3ab6, lsl #16
     168:      	dup.4s	v1, w9
     16c:      	mov	w9, #0xaaab             ; =43691
     170:      	movk	w9, #0x3d2a, lsl #16
     174:      	dup.4s	v0, w9
     178:      	stp	q0, q1, [sp, #0x70]
     17c:      	mov	w9, #-0x3d300000        ; =-1026555904
     180:      	dup.4s	v1, w9
     184:      	mov	w9, #0x42c80000         ; =1120403456
     188:      	dup.4s	v22, w9
     18c:      	mov	w9, #0xaa3b             ; =43579
     190:      	movk	w9, #0x3fb8, lsl #16
     194:      	dup.4s	v0, w9
     198:      	stp	q0, q1, [sp, #0x50]
     19c:      	mov	w9, #0x7200             ; =29184
     1a0:      	movk	w9, #0xbf31, lsl #16
     1a4:      	dup.4s	v1, w9
     1a8:      	mov	w9, #0xbe8e             ; =48782
     1ac:      	movk	w9, #0xb5bf, lsl #16
     1b0:      	dup.4s	v0, w9
     1b4:      	stp	q0, q1, [sp, #0x30]
     1b8:      	mov	w9, #0x2bda             ; =11226
     1bc:      	movk	w9, #0x3950, lsl #16
     1c0:      	dup.4s	v1, w9
     1c4:      	mov	w9, #0x96c9             ; =38601
     1c8:      	movk	w9, #0x3ab6, lsl #16
     1cc:      	dup.4s	v0, w9
     1d0:      	stp	q0, q1, [sp, #0x10]
     1d4:      	mov	w9, #0x88a6             ; =34982
     1d8:      	movk	w9, #0x3c08, lsl #16
     1dc:      	dup.4s	v0, w9
     1e0:      	str	q0, [sp]
     1e4:      	mov	w9, #0xaa7a             ; =43642
     1e8:      	movk	w9, #0x3d2a, lsl #16
     1ec:      	dup.4s	v29, w9
     1f0:      	add	x9, x21, x22
     1f4:      	movi.4s	v30, #0x3f, lsl #24
     1f8:      	fmov.4s	v31, #1.00000000
     1fc:      	fmov.4s	v8, #9.00000000
     200:      	mvni.4s	v0, #0x7f, msl #16
     204:      	fneg.4s	v12, v0
     208:      	fmov.4s	v13, #0.25000000
     20c:      	mvni.4s	v0, #0x3f, msl #16
     210:      	fneg.4s	v15, v0
     214:      	add	x10, x19, x8
     218:      	ldp	q9, q10, [x10]
     21c:      	ldp	q2, q1, [sp, #0x110]
     220:      	fmul.4s	v0, v9, v1
     224:      	fmul.4s	v1, v10, v1
     228:      	fmul.4s	v1, v10, v1
     22c:      	fmul.4s	v0, v9, v0
     230:      	fmul.4s	v0, v9, v0
     234:      	fmul.4s	v1, v10, v1
     238:      	fadd.4s	v1, v10, v1
     23c:      	fadd.4s	v0, v9, v0
     240:      	fmul.4s	v14, v0, v2
     244:      	fmul.4s	v11, v1, v2
     248:      	fabs.4s	v1, v11
     24c:      	fabs.4s	v0, v14
     250:      	fmul.4s	v16, v14, v14
     254:      	fmul.4s	v18, v11, v11
     258:      	ldp	q3, q4, [sp, #0xf0]
     25c:      	mov.16b	v2, v3
     260:      	fmla.4s	v2, v16, v4
     264:      	fmla.4s	v3, v18, v4
     268:      	ldr	q5, [sp, #0xe0]
     26c:      	mov.16b	v4, v5
     270:      	fmla.4s	v4, v16, v2
     274:      	mov.16b	v2, v5
     278:      	fmla.4s	v2, v18, v3
     27c:      	ldp	q6, q5, [sp, #0xc0]
     280:      	mov.16b	v3, v5
     284:      	fmla.4s	v3, v16, v4
     288:      	mov.16b	v4, v5
     28c:      	fmla.4s	v4, v18, v2
     290:      	mov.16b	v5, v6
     294:      	mov.16b	v7, v20
     298:      	mov.16b	v19, v20
     29c:      	mov.16b	v2, v31
     2a0:      	fmla.4s	v5, v16, v3
     2a4:      	ldp	q17, q21, [sp, #0xa0]
     2a8:      	mov.16b	v3, v17
     2ac:      	fmla.4s	v3, v18, v21
     2b0:      	fmla.4s	v17, v16, v21
     2b4:      	ldr	q23, [sp, #0x90]
     2b8:      	mov.16b	v21, v23
     2bc:      	fmla.4s	v6, v18, v4
     2c0:      	fmla.4s	v21, v18, v3
     2c4:      	mov.16b	v3, v23
     2c8:      	fmla.4s	v3, v16, v17
     2cc:      	ldr	q17, [sp, #0x80]
     2d0:      	mov.16b	v4, v17
     2d4:      	fmla.4s	v4, v18, v21
     2d8:      	fmla.4s	v7, v16, v5
     2dc:      	mov.16b	v5, v17
     2e0:      	fmla.4s	v5, v16, v3
     2e4:      	ldp	q26, q21, [sp, #0x60]
     2e8:      	mov.16b	v17, v21
     2ec:      	fmla.4s	v17, v18, v4
     2f0:      	fmla.4s	v19, v18, v6
     2f4:      	fmla.4s	v21, v16, v5
     2f8:      	movi.4s	v23, #0x3f, lsl #24
     2fc:      	movi.4s	v24, #0x3f, lsl #24
     300:      	mov.16b	v5, v31
     304:      	fcmge.4s	v3, v8, v0
     308:      	fmla.4s	v23, v18, v17
     30c:      	fcmge.4s	v4, v8, v1
     310:      	and.16b	v6, v4, v1
     314:      	and.16b	v17, v3, v0
     318:      	fcmge.4s	v25, v17, v26
     31c:      	fcmge.4s	v26, v6, v26
     320:      	fcmge.4s	v27, v22, v6
     324:      	and.16b	v26, v26, v27
     328:      	fcmge.4s	v27, v22, v17
     32c:      	and.16b	v25, v25, v27
     330:      	and.16b	v25, v25, v17
     334:      	and.16b	v26, v26, v6
     338:      	fmla.4s	v2, v18, v19
     33c:      	ldr	q27, [sp, #0x50]
     340:      	fmul.4s	v19, v26, v27
     344:      	fmul.4s	v27, v25, v27
     348:      	movi.4s	v28, #0x4b, lsl #24
     34c:      	fadd.4s	v27, v27, v28
     350:      	fadd.4s	v19, v19, v28
     354:      	movi.4s	v28, #0xcb, lsl #24
     358:      	fadd.4s	v19, v19, v28
     35c:      	fmla.4s	v5, v18, v23
     360:      	fadd.4s	v18, v27, v28
     364:      	fcvtzs.4s	v18, v18
     368:      	fcvtzs.4s	v19, v19
     36c:      	scvtf.4s	v23, v19
     370:      	scvtf.4s	v27, v18
     374:      	fmla.4s	v24, v16, v21
     378:      	ldr	q28, [sp, #0x40]
     37c:      	fmul.4s	v21, v23, v28
     380:      	fadd.4s	v21, v26, v21
     384:      	fmul.4s	v26, v27, v28
     388:      	fadd.4s	v25, v25, v26
     38c:      	mov.16b	v26, v31
     390:      	fmla.4s	v26, v16, v7
     394:      	ldr	q28, [sp, #0x30]
     398:      	fmul.4s	v7, v27, v28
     39c:      	fadd.4s	v25, v25, v7
     3a0:      	fmul.4s	v7, v23, v28
     3a4:      	fadd.4s	v21, v21, v7
     3a8:      	mov.16b	v7, v31
     3ac:      	fmla.4s	v7, v16, v24
     3b0:      	ldp	q24, q23, [sp, #0x10]
     3b4:      	fmul.4s	v16, v21, v23
     3b8:      	fmul.4s	v23, v25, v23
     3bc:      	fadd.4s	v23, v23, v24
     3c0:      	fadd.4s	v16, v16, v24
     3c4:      	fmul.4s	v16, v21, v16
     3c8:      	fmul.4s	v24, v0, v26
     3cc:      	fmul.4s	v23, v25, v23
     3d0:      	ldr	q26, [sp]
     3d4:      	fadd.4s	v23, v23, v26
     3d8:      	fadd.4s	v16, v16, v26
     3dc:      	fmul.4s	v16, v21, v16
     3e0:      	fmul.4s	v23, v25, v23
     3e4:      	fadd.4s	v23, v23, v29
     3e8:      	fadd.4s	v16, v16, v29
     3ec:      	fmul.4s	v16, v21, v16
     3f0:      	fmul.4s	v23, v25, v23
     3f4:      	fadd.4s	v23, v23, v20
     3f8:      	fadd.4s	v16, v16, v20
     3fc:      	fdiv.4s	v7, v24, v7
     400:      	fmul.4s	v16, v21, v16
     404:      	fmul.4s	v23, v25, v23
     408:      	fadd.4s	v23, v23, v30
     40c:      	fadd.4s	v16, v16, v30
     410:      	fmul.4s	v24, v21, v21
     414:      	fmul.4s	v16, v24, v16
     418:      	fmul.4s	v24, v25, v25
     41c:      	fmul.4s	v23, v24, v23
     420:      	fadd.4s	v23, v25, v23
     424:      	fadd.4s	v16, v21, v16
     428:      	movi.2d	v25, #0xffffffffffffffff
     42c:      	add.4s	v18, v18, v25
     430:      	fadd.4s	v21, v23, v31
     434:      	sshr.4s	v23, v18, #0x1
     438:      	shl.4s	v24, v23, #0x17
     43c:      	add.4s	v24, v24, v31
     440:      	fmul.4s	v21, v21, v24
     444:      	add.4s	v19, v19, v25
     448:      	fadd.4s	v16, v16, v31
     44c:      	sub.4s	v18, v18, v23
     450:      	sshr.4s	v23, v19, #0x1
     454:      	sub.4s	v19, v19, v23
     458:      	shl.4s	v23, v23, #0x17
     45c:      	add.4s	v23, v23, v31
     460:      	fmul.4s	v16, v16, v23
     464:      	shl.4s	v19, v19, #0x17
     468:      	add.4s	v19, v19, v31
     46c:      	fmul.4s	v16, v16, v19
     470:      	shl.4s	v18, v18, #0x17
     474:      	add.4s	v18, v18, v31
     478:      	fmul.4s	v18, v21, v18
     47c:      	fcmgt.4s	v17, v17, v22
     480:      	bsl.16b	v17, v12, v18
     484:      	fmul.4s	v2, v1, v2
     488:      	fcmgt.4s	v6, v6, v22
     48c:      	bsl.16b	v6, v12, v16
     490:      	fdiv.4s	v2, v2, v5
     494:      	fdiv.4s	v5, v13, v6
     498:      	fsub.4s	v16, v6, v5
     49c:      	fadd.4s	v5, v6, v5
     4a0:      	fdiv.4s	v5, v16, v5
     4a4:      	bsl.16b	v4, v5, v31
     4a8:      	fcmge.4s	v1, v31, v1
     4ac:      	bsl.16b	v1, v2, v4
     4b0:      	fdiv.4s	v2, v13, v17
     4b4:      	fsub.4s	v4, v17, v2
     4b8:      	fadd.4s	v2, v17, v2
     4bc:      	fdiv.4s	v2, v4, v2
     4c0:      	bif.16b	v2, v31, v3
     4c4:      	fcmge.4s	v0, v31, v0
     4c8:      	bsl.16b	v0, v7, v2
     4cc:      	mvni.4s	v3, #0x80, lsl #24
     4d0:      	bif.16b	v0, v14, v3
     4d4:      	fcmeq.4s	v2, v14, v14
     4d8:      	fadd.4s	v0, v0, v31
     4dc:      	bif.16b	v0, v15, v2
     4e0:      	bif.16b	v1, v11, v3
     4e4:      	fcmeq.4s	v2, v11, v11
     4e8:      	fadd.4s	v1, v1, v31
     4ec:      	bif.16b	v1, v15, v2
     4f0:      	fmul.4s	v2, v10, v30
     4f4:      	fmul.4s	v1, v2, v1
     4f8:      	fmul.4s	v2, v9, v30
     4fc:      	fmul.4s	v0, v2, v0
     500:      	add	x10, x20, x8
     504:      	ldp	q3, q2, [x10]
     508:      	fadd.4s	v0, v3, v0
     50c:      	fadd.4s	v1, v2, v1
     510:      	add	x10, x9, x8
     514:      	stp	q0, q1, [x10]
     518:      	add	x8, x8, #0x20
     51c:      	cmp	x8, #0xc00
     520:      	b.ne	0x214 <ltmp0+0x214>
     524:      	b	0x990 <ltmp0+0x990>
     528:      	mov	x8, #0x0                ; =0
     52c:      	mov	w9, #0x2713             ; =10003
     530:      	movk	w9, #0x3d37, lsl #16
     534:      	dup.4s	v1, w9
     538:      	mov	w9, #0x422a             ; =16938
     53c:      	movk	w9, #0x3f4c, lsl #16
     540:      	dup.4s	v0, w9
     544:      	stp	q0, q1, [sp, #0x110]
     548:      	mov	w9, #0x9231             ; =37425
     54c:      	movk	w9, #0x2f30, lsl #16
     550:      	dup.4s	v1, w9
     554:      	mov	w9, #0x322b             ; =12843
     558:      	movk	w9, #0x32d7, lsl #16
     55c:      	dup.4s	v0, w9
     560:      	stp	q0, q1, [sp, #0xf0]
     564:      	mov	w9, #0xef1d             ; =61213
     568:      	movk	w9, #0x3638, lsl #16
     56c:      	dup.4s	v1, w9
     570:      	mov	w9, #0xd01              ; =3329
     574:      	movk	w9, #0x3950, lsl #16
     578:      	dup.4s	v0, w9
     57c:      	stp	q0, q1, [sp, #0xd0]
     580:      	mov	w9, #0x8889             ; =34953
     584:      	movk	w9, #0x3c08, lsl #16
     588:      	dup.4s	v1, w9
     58c:      	mov	w9, #0xaaab             ; =43691
     590:      	movk	w9, #0x3e2a, lsl #16
     594:      	dup.4s	v20, w9
     598:      	mov	w9, #0x76c7             ; =30407
     59c:      	movk	w9, #0x310f, lsl #16
     5a0:      	dup.4s	v0, w9
     5a4:      	stp	q0, q1, [sp, #0xb0]
     5a8:      	mov	w9, #0xf27e             ; =62078
     5ac:      	movk	w9, #0x3493, lsl #16
     5b0:      	dup.4s	v1, w9
     5b4:      	mov	w9, #0xd01              ; =3329
     5b8:      	movk	w9, #0x37d0, lsl #16
     5bc:      	dup.4s	v0, w9
     5c0:      	stp	q0, q1, [sp, #0x90]
     5c4:      	mov	w9, #0xb61              ; =2913
     5c8:      	movk	w9, #0x3ab6, lsl #16
     5cc:      	dup.4s	v1, w9
     5d0:      	mov	w9, #0xaaab             ; =43691
     5d4:      	movk	w9, #0x3d2a, lsl #16
     5d8:      	dup.4s	v0, w9
     5dc:      	stp	q0, q1, [sp, #0x70]
     5e0:      	mov	w9, #-0x3d300000        ; =-1026555904
     5e4:      	dup.4s	v1, w9
     5e8:      	mov	w9, #0x42c80000         ; =1120403456
     5ec:      	dup.4s	v22, w9
     5f0:      	mov	w9, #0xaa3b             ; =43579
     5f4:      	movk	w9, #0x3fb8, lsl #16
     5f8:      	dup.4s	v0, w9
     5fc:      	stp	q0, q1, [sp, #0x50]
     600:      	mov	w9, #0x7200             ; =29184
     604:      	movk	w9, #0xbf31, lsl #16
     608:      	dup.4s	v1, w9
     60c:      	mov	w9, #0xbe8e             ; =48782
     610:      	movk	w9, #0xb5bf, lsl #16
     614:      	dup.4s	v0, w9
     618:      	stp	q0, q1, [sp, #0x30]
     61c:      	mov	w9, #0x2bda             ; =11226
     620:      	movk	w9, #0x3950, lsl #16
     624:      	dup.4s	v1, w9
     628:      	mov	w9, #0x96c9             ; =38601
     62c:      	movk	w9, #0x3ab6, lsl #16
     630:      	dup.4s	v0, w9
     634:      	stp	q0, q1, [sp, #0x10]
     638:      	mov	w9, #0x88a6             ; =34982
     63c:      	movk	w9, #0x3c08, lsl #16
     640:      	dup.4s	v0, w9
     644:      	str	q0, [sp]
     648:      	mov	w9, #0xaa7a             ; =43642
     64c:      	movk	w9, #0x3d2a, lsl #16
     650:      	dup.4s	v29, w9
     654:      	add	x9, x21, x22
     658:      	add	x10, x23, x22
     65c:      	add	x11, x11, x22
     660:      	movi.4s	v30, #0x3f, lsl #24
     664:      	fmov.4s	v31, #1.00000000
     668:      	fmov.4s	v8, #9.00000000
     66c:      	mvni.4s	v0, #0x7f, msl #16
     670:      	fneg.4s	v12, v0
     674:      	fmov.4s	v13, #0.25000000
     678:      	mvni.4s	v0, #0x3f, msl #16
     67c:      	fneg.4s	v15, v0
     680:      	add	x12, x11, x8
     684:      	ldp	q9, q10, [x12]
     688:      	ldp	q2, q1, [sp, #0x110]
     68c:      	fmul.4s	v0, v9, v1
     690:      	fmul.4s	v1, v10, v1
     694:      	fmul.4s	v1, v10, v1
     698:      	fmul.4s	v0, v9, v0
     69c:      	fmul.4s	v0, v9, v0
     6a0:      	fmul.4s	v1, v10, v1
     6a4:      	fadd.4s	v1, v10, v1
     6a8:      	fadd.4s	v0, v9, v0
     6ac:      	fmul.4s	v14, v0, v2
     6b0:      	fmul.4s	v11, v1, v2
     6b4:      	fabs.4s	v1, v11
     6b8:      	fabs.4s	v0, v14
     6bc:      	fmul.4s	v16, v14, v14
     6c0:      	fmul.4s	v18, v11, v11
     6c4:      	ldp	q3, q4, [sp, #0xf0]
     6c8:      	mov.16b	v2, v3
     6cc:      	fmla.4s	v2, v16, v4
     6d0:      	fmla.4s	v3, v18, v4
     6d4:      	ldr	q5, [sp, #0xe0]
     6d8:      	mov.16b	v4, v5
     6dc:      	fmla.4s	v4, v16, v2
     6e0:      	mov.16b	v2, v5
     6e4:      	fmla.4s	v2, v18, v3
     6e8:      	ldp	q6, q5, [sp, #0xc0]
     6ec:      	mov.16b	v3, v5
     6f0:      	fmla.4s	v3, v16, v4
     6f4:      	mov.16b	v4, v5
     6f8:      	fmla.4s	v4, v18, v2
     6fc:      	mov.16b	v5, v6
     700:      	mov.16b	v7, v20
     704:      	mov.16b	v19, v20
     708:      	mov.16b	v2, v31
     70c:      	fmla.4s	v5, v16, v3
     710:      	ldp	q17, q21, [sp, #0xa0]
     714:      	mov.16b	v3, v17
     718:      	fmla.4s	v3, v18, v21
     71c:      	fmla.4s	v17, v16, v21
     720:      	ldr	q23, [sp, #0x90]
     724:      	mov.16b	v21, v23
     728:      	fmla.4s	v6, v18, v4
     72c:      	fmla.4s	v21, v18, v3
     730:      	mov.16b	v3, v23
     734:      	fmla.4s	v3, v16, v17
     738:      	ldr	q17, [sp, #0x80]
     73c:      	mov.16b	v4, v17
     740:      	fmla.4s	v4, v18, v21
     744:      	fmla.4s	v7, v16, v5
     748:      	mov.16b	v5, v17
     74c:      	fmla.4s	v5, v16, v3
     750:      	ldp	q26, q21, [sp, #0x60]
     754:      	mov.16b	v17, v21
     758:      	fmla.4s	v17, v18, v4
     75c:      	fmla.4s	v19, v18, v6
     760:      	fmla.4s	v21, v16, v5
     764:      	movi.4s	v23, #0x3f, lsl #24
     768:      	movi.4s	v24, #0x3f, lsl #24
     76c:      	mov.16b	v5, v31
     770:      	fcmge.4s	v3, v8, v0
     774:      	fmla.4s	v23, v18, v17
     778:      	fcmge.4s	v4, v8, v1
     77c:      	and.16b	v6, v4, v1
     780:      	and.16b	v17, v3, v0
     784:      	fcmge.4s	v25, v17, v26
     788:      	fcmge.4s	v26, v6, v26
     78c:      	fcmge.4s	v27, v22, v6
     790:      	and.16b	v26, v26, v27
     794:      	fcmge.4s	v27, v22, v17
     798:      	and.16b	v25, v25, v27
     79c:      	and.16b	v25, v25, v17
     7a0:      	and.16b	v26, v26, v6
     7a4:      	fmla.4s	v2, v18, v19
     7a8:      	ldr	q27, [sp, #0x50]
     7ac:      	fmul.4s	v19, v26, v27
     7b0:      	fmul.4s	v27, v25, v27
     7b4:      	movi.4s	v28, #0x4b, lsl #24
     7b8:      	fadd.4s	v27, v27, v28
     7bc:      	fadd.4s	v19, v19, v28
     7c0:      	movi.4s	v28, #0xcb, lsl #24
     7c4:      	fadd.4s	v19, v19, v28
     7c8:      	fmla.4s	v5, v18, v23
     7cc:      	fadd.4s	v18, v27, v28
     7d0:      	fcvtzs.4s	v18, v18
     7d4:      	fcvtzs.4s	v19, v19
     7d8:      	scvtf.4s	v23, v19
     7dc:      	scvtf.4s	v27, v18
     7e0:      	fmla.4s	v24, v16, v21
     7e4:      	ldr	q28, [sp, #0x40]
     7e8:      	fmul.4s	v21, v23, v28
     7ec:      	fadd.4s	v21, v26, v21
     7f0:      	fmul.4s	v26, v27, v28
     7f4:      	fadd.4s	v25, v25, v26
     7f8:      	mov.16b	v26, v31
     7fc:      	fmla.4s	v26, v16, v7
     800:      	ldr	q28, [sp, #0x30]
     804:      	fmul.4s	v7, v27, v28
     808:      	fadd.4s	v25, v25, v7
     80c:      	fmul.4s	v7, v23, v28
     810:      	fadd.4s	v21, v21, v7
     814:      	mov.16b	v7, v31
     818:      	fmla.4s	v7, v16, v24
     81c:      	ldp	q24, q23, [sp, #0x10]
     820:      	fmul.4s	v16, v21, v23
     824:      	fmul.4s	v23, v25, v23
     828:      	fadd.4s	v23, v23, v24
     82c:      	fadd.4s	v16, v16, v24
     830:      	fmul.4s	v16, v21, v16
     834:      	fmul.4s	v24, v0, v26
     838:      	fmul.4s	v23, v25, v23
     83c:      	ldr	q26, [sp]
     840:      	fadd.4s	v23, v23, v26
     844:      	fadd.4s	v16, v16, v26
     848:      	fmul.4s	v16, v21, v16
     84c:      	fmul.4s	v23, v25, v23
     850:      	fadd.4s	v23, v23, v29
     854:      	fadd.4s	v16, v16, v29
     858:      	fmul.4s	v16, v21, v16
     85c:      	fmul.4s	v23, v25, v23
     860:      	fadd.4s	v23, v23, v20
     864:      	fadd.4s	v16, v16, v20
     868:      	fdiv.4s	v7, v24, v7
     86c:      	fmul.4s	v16, v21, v16
     870:      	fmul.4s	v23, v25, v23
     874:      	fadd.4s	v23, v23, v30
     878:      	fadd.4s	v16, v16, v30
     87c:      	fmul.4s	v24, v21, v21
     880:      	fmul.4s	v16, v24, v16
     884:      	fmul.4s	v24, v25, v25
     888:      	fmul.4s	v23, v24, v23
     88c:      	fadd.4s	v23, v25, v23
     890:      	fadd.4s	v16, v21, v16
     894:      	movi.2d	v25, #0xffffffffffffffff
     898:      	add.4s	v18, v18, v25
     89c:      	fadd.4s	v21, v23, v31
     8a0:      	sshr.4s	v23, v18, #0x1
     8a4:      	shl.4s	v24, v23, #0x17
     8a8:      	add.4s	v24, v24, v31
     8ac:      	fmul.4s	v21, v21, v24
     8b0:      	add.4s	v19, v19, v25
     8b4:      	fadd.4s	v16, v16, v31
     8b8:      	sub.4s	v18, v18, v23
     8bc:      	sshr.4s	v23, v19, #0x1
     8c0:      	sub.4s	v19, v19, v23
     8c4:      	shl.4s	v23, v23, #0x17
     8c8:      	add.4s	v23, v23, v31
     8cc:      	fmul.4s	v16, v16, v23
     8d0:      	shl.4s	v19, v19, #0x17
     8d4:      	add.4s	v19, v19, v31
     8d8:      	fmul.4s	v16, v16, v19
     8dc:      	shl.4s	v18, v18, #0x17
     8e0:      	add.4s	v18, v18, v31
     8e4:      	fmul.4s	v18, v21, v18
     8e8:      	fcmgt.4s	v17, v17, v22
     8ec:      	bsl.16b	v17, v12, v18
     8f0:      	fmul.4s	v2, v1, v2
     8f4:      	fcmgt.4s	v6, v6, v22
     8f8:      	bsl.16b	v6, v12, v16
     8fc:      	fdiv.4s	v2, v2, v5
     900:      	fdiv.4s	v5, v13, v6
     904:      	fsub.4s	v16, v6, v5
     908:      	fadd.4s	v5, v6, v5
     90c:      	fdiv.4s	v5, v16, v5
     910:      	bsl.16b	v4, v5, v31
     914:      	fcmge.4s	v1, v31, v1
     918:      	bsl.16b	v1, v2, v4
     91c:      	fdiv.4s	v2, v13, v17
     920:      	fsub.4s	v4, v17, v2
     924:      	fadd.4s	v2, v17, v2
     928:      	fdiv.4s	v2, v4, v2
     92c:      	bif.16b	v2, v31, v3
     930:      	fcmge.4s	v0, v31, v0
     934:      	bsl.16b	v0, v7, v2
     938:      	mvni.4s	v3, #0x80, lsl #24
     93c:      	bif.16b	v0, v14, v3
     940:      	fcmeq.4s	v2, v14, v14
     944:      	fadd.4s	v0, v0, v31
     948:      	bif.16b	v0, v15, v2
     94c:      	bif.16b	v1, v11, v3
     950:      	fcmeq.4s	v2, v11, v11
     954:      	fadd.4s	v1, v1, v31
     958:      	bif.16b	v1, v15, v2
     95c:      	fmul.4s	v2, v10, v30
     960:      	fmul.4s	v1, v2, v1
     964:      	fmul.4s	v2, v9, v30
     968:      	fmul.4s	v0, v2, v0
     96c:      	add	x12, x10, x8
     970:      	ldp	q3, q2, [x12]
     974:      	fadd.4s	v0, v3, v0
     978:      	fadd.4s	v1, v2, v1
     97c:      	add	x12, x9, x8
     980:      	stp	q0, q1, [x12]
     984:      	add	x8, x8, #0x20
     988:      	cmp	x8, #0xc00
     98c:      	b.ne	0x680 <ltmp0+0x680>
     990:      	add	sp, sp, #0x1, lsl #12   ; =0x1000
     994:      	add	sp, sp, #0x930
     998:      	ldp	x29, x30, [sp, #0x70]
     99c:      	ldp	x20, x19, [sp, #0x60]
     9a0:      	ldp	x22, x21, [sp, #0x50]
     9a4:      	ldp	x24, x23, [sp, #0x40]
     9a8:      	ldp	d9, d8, [sp, #0x30]
     9ac:      	ldp	d11, d10, [sp, #0x20]
     9b0:      	ldp	d13, d12, [sp, #0x10]
     9b4:      	ldp	d15, d14, [sp], #0x80
     9b8:      	ret

00000000000009bc <_llm_rows.packet_batch.blocks>:
     9bc:      	stp	d15, d14, [sp, #-0xa0]!
     9c0:      	stp	d13, d12, [sp, #0x10]
     9c4:      	stp	d11, d10, [sp, #0x20]
     9c8:      	stp	d9, d8, [sp, #0x30]
     9cc:      	stp	x28, x27, [sp, #0x40]
     9d0:      	stp	x26, x25, [sp, #0x50]
     9d4:      	stp	x24, x23, [sp, #0x60]
     9d8:      	stp	x22, x21, [sp, #0x70]
     9dc:      	stp	x20, x19, [sp, #0x80]
     9e0:      	stp	x29, x30, [sp, #0x90]
     9e4:      	sub	sp, sp, #0x1, lsl #12   ; =0x1000
     9e8:      	sub	sp, sp, #0x920
     9ec:      	str	x0, [sp, #0x48]
     9f0:      	cbz	w3, 0x17a4 <_llm_rows.packet_batch.blocks+0xde8>
     9f4:      	mov	x19, x3
     9f8:      	mov	x20, x2
     9fc:      	mov	w22, #0x0               ; =0
     a00:      	ldp	w9, w8, [x2, #0x2c]
     a04:      	stp	w8, w9, [sp, #0x40]
     a08:      	ldp	w27, w25, [x2]
     a0c:      	movi.4s	v25, #0x3f, lsl #24
     a10:      	adrp	x8, 0x0 <ltmp0>
     a14:      	ldr	q0, [x8]
     a18:      	str	q0, [sp, #0x20]
     a1c:      	adrp	x8, 0x0 <ltmp0>
     a20:      	ldr	q0, [x8]
     a24:      	str	q0, [sp, #0x10]
     a28:      	adrp	x8, 0x0 <ltmp0>
     a2c:      	ldr	q1, [x8]
     a30:      	mvni.4s	v0, #0x7f, msl #16
     a34:      	fneg.4s	v0, v0
     a38:      	str	q0, [sp, #0x70]
     a3c:      	mvni.4s	v0, #0x3f, msl #16
     a40:      	fneg.4s	v0, v0
     a44:      	stp	q1, q0, [sp, #0x50]
     a48:      	ldp	w26, w28, [x2, #0x8]
     a4c:      	add	x23, sp, #0xd20
     a50:      	add	x24, sp, #0x120
     a54:      	str	w3, [sp, #0x3c]
     a58:      	b	0xaa0 <_llm_rows.packet_batch.blocks+0xe4>
     a5c:      	mov	w8, #0x18               ; =24
     a60:      	str	w8, [x20, #0x24]
     a64:      	ldr	w19, [sp, #0x3c]
     a68:      	add	w8, w27, #0x1
     a6c:      	ldp	w10, w9, [sp, #0x40]
     a70:      	cmp	w8, w9
     a74:      	cset	w8, eq
     a78:      	csinc	w27, wzr, w27, eq
     a7c:      	cinc	w9, w25, eq
     a80:      	cmp	w9, w10
     a84:      	cset	w10, eq
     a88:      	ands	w8, w8, w10
     a8c:      	csel	w25, wzr, w9, ne
     a90:      	add	w26, w26, w8
     a94:      	add	w22, w22, #0x1
     a98:      	cmp	w22, w19
     a9c:      	b.eq	0x17a4 <_llm_rows.packet_batch.blocks+0xde8>
     aa0:      	ubfiz	x8, x27, #5, #32
     aa4:      	cmp	x8, x28
     aa8:      	csel	x9, x8, xzr, ls
     aac:      	subs	x10, x28, x9
     ab0:      	cmp	x10, #0x20
     ab4:      	mov	w11, #0x20              ; =32
     ab8:      	csel	x10, x10, x11, lo
     abc:      	cmp	x28, x9
     ac0:      	stp	w27, w25, [x20]
     ac4:      	str	w26, [x20, #0x8]
     ac8:      	str	wzr, [x20, #0x24]
     acc:      	ccmp	x8, x28, #0x2, hi
     ad0:      	csel	x21, x10, xzr, ls
     ad4:      	cmp	x21, #0x20
     ad8:      	b.lo	0xb30 <_llm_rows.packet_batch.blocks+0x174>
     adc:      	ldr	x21, [sp, #0x48]
     ae0:      	mov	x0, x21
     ae4:      	mov	x1, x20
     ae8:      	bl	0xae8 <_llm_rows.packet_batch.blocks+0x12c>
     aec:      	mov	w8, #0x8                ; =8
     af0:      	str	w8, [x20, #0x24]
     af4:      	mov	x0, x21
     af8:      	mov	x1, x20
     afc:      	bl	0xafc <_llm_rows.packet_batch.blocks+0x140>
     b00:      	mov	w8, #0x10               ; =16
     b04:      	str	w8, [x20, #0x24]
     b08:      	mov	x0, x21
     b0c:      	mov	x1, x20
     b10:      	bl	0xb10 <_llm_rows.packet_batch.blocks+0x154>
     b14:      	mov	w8, #0x18               ; =24
     b18:      	str	w8, [x20, #0x24]
     b1c:      	mov	x0, x21
     b20:      	mov	x1, x20
     b24:      	bl	0xb24 <_llm_rows.packet_batch.blocks+0x168>
     b28:      	movi.4s	v25, #0x3f, lsl #24
     b2c:      	b	0xa68 <_llm_rows.packet_batch.blocks+0xac>
     b30:      	lsr	x19, x21, #3
     b34:      	cmp	x21, #0x8
     b38:      	b.lo	0xb90 <_llm_rows.packet_batch.blocks+0x1d4>
     b3c:      	str	wzr, [x20, #0x24]
     b40:      	ldr	x0, [sp, #0x48]
     b44:      	mov	x1, x20
     b48:      	bl	0xb48 <_llm_rows.packet_batch.blocks+0x18c>
     b4c:      	movi.4s	v25, #0x3f, lsl #24
     b50:      	cmp	x19, #0x1
     b54:      	b.eq	0xb90 <_llm_rows.packet_batch.blocks+0x1d4>
     b58:      	mov	w8, #0x8                ; =8
     b5c:      	str	w8, [x20, #0x24]
     b60:      	ldr	x0, [sp, #0x48]
     b64:      	mov	x1, x20
     b68:      	bl	0xb68 <_llm_rows.packet_batch.blocks+0x1ac>
     b6c:      	movi.4s	v25, #0x3f, lsl #24
     b70:      	cmp	x19, #0x2
     b74:      	b.eq	0xb90 <_llm_rows.packet_batch.blocks+0x1d4>
     b78:      	mov	w8, #0x10               ; =16
     b7c:      	str	w8, [x20, #0x24]
     b80:      	ldr	x0, [sp, #0x48]
     b84:      	mov	x1, x20
     b88:      	bl	0xb88 <_llm_rows.packet_batch.blocks+0x1cc>
     b8c:      	movi.4s	v25, #0x3f, lsl #24
     b90:      	and	w8, w21, #0x7
     b94:      	cbz	w8, 0xa5c <_llm_rows.packet_batch.blocks+0xa0>
     b98:      	dup.4s	v2, w8
     b9c:      	ldp	q0, q1, [sp, #0x10]
     ba0:      	cmhi.4s	v0, v2, v0
     ba4:      	cmhi.4s	v1, v2, v1
     ba8:      	uzp1.8h	v12, v1, v0
     bac:      	umaxv.8h	h3, v12
     bb0:      	fmov	w8, s3
     bb4:      	tbz	w8, #0x0, 0xa5c <_llm_rows.packet_batch.blocks+0xa0>
     bb8:      	ldr	x8, [sp, #0x48]
     bbc:      	ldr	x12, [x8]
     bc0:      	ldr	x10, [x8, #0x10]
     bc4:      	ldr	x9, [x8, #0x30]
     bc8:      	ubfiz	w8, w27, #2, #27
     bcc:      	orr	w11, w8, w19
     bd0:      	subs	x8, x12, x9
     bd4:      	mov	w15, #0xbff             ; =3071
     bd8:      	movk	w15, #0x6, lsl #16
     bdc:      	ccmp	x8, x15, #0x0, hs
     be0:      	cset	w8, hi
     be4:      	subs	x13, x9, x12
     be8:      	ccmp	x13, x15, #0x0, hs
     bec:      	csinc	w13, w8, wzr, ls
     bf0:      	subs	x8, x10, x9
     bf4:      	ccmp	x8, x15, #0x0, hs
     bf8:      	cset	w8, hi
     bfc:      	subs	x14, x9, x10
     c00:      	ccmp	x14, x15, #0x0, hs
     c04:      	csinc	w8, w8, wzr, ls
     c08:      	fmov	w14, s2
     c0c:      	cmp	w14, #0x0
     c10:      	mov	w14, #0x2713            ; =10003
     c14:      	movk	w14, #0x3d37, lsl #16
     c18:      	dup.4s	v16, w14
     c1c:      	mov	w14, #0x422a            ; =16938
     c20:      	movk	w14, #0x3f4c, lsl #16
     c24:      	dup.4s	v3, w14
     c28:      	mov	w14, #0x9231            ; =37425
     c2c:      	movk	w14, #0x2f30, lsl #16
     c30:      	dup.4s	v2, w14
     c34:      	stp	q2, q3, [sp, #0xf0]
     c38:      	mov	w14, #0x322b            ; =12843
     c3c:      	movk	w14, #0x32d7, lsl #16
     c40:      	dup.4s	v3, w14
     c44:      	mov	w14, #0xef1d            ; =61213
     c48:      	movk	w14, #0x3638, lsl #16
     c4c:      	dup.4s	v2, w14
     c50:      	stp	q2, q3, [sp, #0xd0]
     c54:      	mov	w14, #0xd01             ; =3329
     c58:      	movk	w14, #0x3950, lsl #16
     c5c:      	dup.4s	v3, w14
     c60:      	mov	w14, #0x8889            ; =34953
     c64:      	movk	w14, #0x3c08, lsl #16
     c68:      	dup.4s	v2, w14
     c6c:      	stp	q2, q3, [sp, #0xb0]
     c70:      	mov	w14, #0xaaab            ; =43691
     c74:      	movk	w14, #0x3e2a, lsl #16
     c78:      	dup.4s	v17, w14
     c7c:      	mov	w14, #0xc00             ; =3072
     c80:      	umull	x11, w11, w14
     c84:      	csel	x11, x11, xzr, ne
     c88:      	mov	w14, #0x76c7            ; =30407
     c8c:      	movk	w14, #0x310f, lsl #16
     c90:      	dup.4s	v3, w14
     c94:      	mov	w14, #0xf27e            ; =62078
     c98:      	movk	w14, #0x3493, lsl #16
     c9c:      	dup.4s	v19, w14
     ca0:      	mov	w14, #0xd01             ; =3329
     ca4:      	movk	w14, #0x37d0, lsl #16
     ca8:      	dup.4s	v18, w14
     cac:      	mov	w14, #0xb61             ; =2913
     cb0:      	movk	w14, #0x3ab6, lsl #16
     cb4:      	dup.4s	v21, w14
     cb8:      	fmov.4s	v22, #1.00000000
     cbc:      	mov	w14, #0xaaab            ; =43691
     cc0:      	movk	w14, #0x3d2a, lsl #16
     cc4:      	dup.4s	v23, w14
     cc8:      	fmov.4s	v2, #9.00000000
     ccc:      	stp	q2, q3, [sp, #0x90]
     cd0:      	mov	w14, #-0x3d300000       ; =-1026555904
     cd4:      	dup.4s	v2, w14
     cd8:      	str	q2, [sp, #0x80]
     cdc:      	mov	w14, #0x42c80000        ; =1120403456
     ce0:      	dup.4s	v26, w14
     ce4:      	mov	w14, #0xaa3b            ; =43579
     ce8:      	movk	w14, #0x3fb8, lsl #16
     cec:      	dup.4s	v27, w14
     cf0:      	mov	w14, #0x7200            ; =29184
     cf4:      	movk	w14, #0xbf31, lsl #16
     cf8:      	dup.4s	v28, w14
     cfc:      	mov	w14, #0xbe8e            ; =48782
     d00:      	movk	w14, #0xb5bf, lsl #16
     d04:      	dup.4s	v29, w14
     d08:      	mov	w14, #0x2bda            ; =11226
     d0c:      	movk	w14, #0x3950, lsl #16
     d10:      	dup.4s	v30, w14
     d14:      	mov	w14, #0x96c9            ; =38601
     d18:      	movk	w14, #0x3ab6, lsl #16
     d1c:      	dup.4s	v31, w14
     d20:      	mov	w14, #0x88a6            ; =34982
     d24:      	movk	w14, #0x3c08, lsl #16
     d28:      	dup.4s	v8, w14
     d2c:      	mov	w14, #0xaa7a            ; =43642
     d30:      	movk	w14, #0x3d2a, lsl #16
     d34:      	dup.4s	v9, w14
     d38:      	fmov.4s	v10, #0.25000000
     d3c:      	cmp	w13, #0x1
     d40:      	b.ne	0x1248 <_llm_rows.packet_batch.blocks+0x88c>
     d44:      	cbz	w8, 0x1248 <_llm_rows.packet_batch.blocks+0x88c>
     d48:      	mov	x8, #0x0                ; =0
     d4c:      	add	x9, x9, x11
     d50:      	add	x10, x10, x11
     d54:      	add	x11, x12, x11
     d58:      	ldr	q2, [sp, #0x50]
     d5c:      	and.16b	v2, v12, v2
     d60:      	addv.8h	h11, v2
     d64:      	fmov	w12, s11
     d68:      	b	0xd78 <_llm_rows.packet_batch.blocks+0x3bc>
     d6c:      	add	x8, x8, #0x20
     d70:      	cmp	x8, #0xc00
     d74:      	b.eq	0xa5c <_llm_rows.packet_batch.blocks+0xa0>
     d78:      	add	x13, x11, x8
     d7c:      	movi.2d	v13, #0000000000000000
     d80:      	movi.2d	v12, #0000000000000000
     d84:      	tbnz	w12, #0x0, 0x1128 <_llm_rows.packet_batch.blocks+0x76c>
     d88:      	and	w14, w12, #0xff
     d8c:      	tbnz	w14, #0x1, 0x1134 <_llm_rows.packet_batch.blocks+0x778>
     d90:      	tbnz	w14, #0x2, 0x1140 <_llm_rows.packet_batch.blocks+0x784>
     d94:      	tbnz	w14, #0x3, 0x114c <_llm_rows.packet_batch.blocks+0x790>
     d98:      	tbnz	w14, #0x4, 0x1158 <_llm_rows.packet_batch.blocks+0x79c>
     d9c:      	tbnz	w14, #0x5, 0x1164 <_llm_rows.packet_batch.blocks+0x7a8>
     da0:      	tbnz	w14, #0x6, 0x1170 <_llm_rows.packet_batch.blocks+0x7b4>
     da4:      	tbnz	w14, #0x7, 0x117c <_llm_rows.packet_batch.blocks+0x7c0>
     da8:      	fmov	w14, s11
     dac:      	add	x13, x10, x8
     db0:      	movi.2d	v15, #0000000000000000
     db4:      	movi.2d	v14, #0000000000000000
     db8:      	tbnz	w14, #0x0, 0x1198 <_llm_rows.packet_batch.blocks+0x7dc>
     dbc:      	and	w14, w14, #0xff
     dc0:      	tbnz	w14, #0x1, 0x11a4 <_llm_rows.packet_batch.blocks+0x7e8>
     dc4:      	tbnz	w14, #0x2, 0x11b0 <_llm_rows.packet_batch.blocks+0x7f4>
     dc8:      	tbnz	w14, #0x3, 0x11bc <_llm_rows.packet_batch.blocks+0x800>
     dcc:      	tbnz	w14, #0x4, 0x11c8 <_llm_rows.packet_batch.blocks+0x80c>
     dd0:      	tbnz	w14, #0x5, 0x11d4 <_llm_rows.packet_batch.blocks+0x818>
     dd4:      	tbnz	w14, #0x6, 0x11e0 <_llm_rows.packet_batch.blocks+0x824>
     dd8:      	tbz	w14, #0x7, 0xde4 <_llm_rows.packet_batch.blocks+0x428>
     ddc:      	add	x13, x13, #0x1c
     de0:      	ld1.s	{ v14 }[3], [x13]
     de4:      	fmul.4s	v2, v13, v16
     de8:      	fmul.4s	v2, v13, v2
     dec:      	fmul.4s	v2, v13, v2
     df0:      	fadd.4s	v2, v13, v2
     df4:      	ldp	q6, q3, [sp, #0xf0]
     df8:      	fmul.4s	v2, v2, v3
     dfc:      	and.16b	v2, v1, v2
     e00:      	fabs.4s	v3, v2
     e04:      	fmul.4s	v4, v2, v2
     e08:      	ldr	q5, [sp, #0xe0]
     e0c:      	fmla.4s	v5, v4, v6
     e10:      	ldr	q6, [sp, #0xd0]
     e14:      	fmla.4s	v6, v4, v5
     e18:      	ldr	q5, [sp, #0xc0]
     e1c:      	fmla.4s	v5, v4, v6
     e20:      	ldp	q7, q6, [sp, #0xa0]
     e24:      	fmla.4s	v6, v4, v5
     e28:      	mov.16b	v5, v17
     e2c:      	fmla.4s	v5, v4, v6
     e30:      	mov.16b	v6, v22
     e34:      	fmla.4s	v6, v4, v5
     e38:      	fmul.4s	v5, v3, v6
     e3c:      	mov.16b	v6, v19
     e40:      	fmla.4s	v6, v4, v7
     e44:      	mov.16b	v20, v18
     e48:      	fmla.4s	v20, v4, v6
     e4c:      	mov.16b	v6, v21
     e50:      	fmla.4s	v6, v4, v20
     e54:      	mov.16b	v20, v23
     e58:      	fmla.4s	v20, v4, v6
     e5c:      	movi.4s	v6, #0x3f, lsl #24
     e60:      	fmla.4s	v6, v4, v20
     e64:      	mov.16b	v20, v22
     e68:      	fmla.4s	v20, v4, v6
     e6c:      	fdiv.4s	v4, v5, v20
     e70:      	ldp	q7, q5, [sp, #0x80]
     e74:      	fcmge.4s	v5, v5, v3
     e78:      	and.16b	v6, v5, v3
     e7c:      	fcmge.4s	v20, v6, v7
     e80:      	fcmge.4s	v24, v26, v6
     e84:      	and.16b	v20, v20, v24
     e88:      	and.16b	v20, v20, v6
     e8c:      	fmul.4s	v24, v20, v27
     e90:      	movi.4s	v7, #0x4b, lsl #24
     e94:      	fadd.4s	v24, v24, v7
     e98:      	movi.4s	v7, #0xcb, lsl #24
     e9c:      	fadd.4s	v24, v24, v7
     ea0:      	fcvtzs.4s	v24, v24
     ea4:      	scvtf.4s	v7, v24
     ea8:      	fmul.4s	v25, v7, v28
     eac:      	fadd.4s	v20, v20, v25
     eb0:      	fmul.4s	v7, v7, v29
     eb4:      	fadd.4s	v7, v20, v7
     eb8:      	fmul.4s	v20, v7, v30
     ebc:      	fadd.4s	v20, v20, v31
     ec0:      	fmul.4s	v20, v7, v20
     ec4:      	fadd.4s	v20, v20, v8
     ec8:      	fmul.4s	v20, v7, v20
     ecc:      	fadd.4s	v20, v20, v9
     ed0:      	fmul.4s	v20, v7, v20
     ed4:      	fadd.4s	v20, v20, v17
     ed8:      	fmul.4s	v20, v7, v20
     edc:      	movi.4s	v25, #0x3f, lsl #24
     ee0:      	fadd.4s	v20, v20, v25
     ee4:      	fmul.4s	v25, v7, v7
     ee8:      	fmul.4s	v20, v25, v20
     eec:      	fadd.4s	v7, v7, v20
     ef0:      	fadd.4s	v7, v7, v22
     ef4:      	movi.2d	v20, #0xffffffffffffffff
     ef8:      	add.4s	v20, v24, v20
     efc:      	sshr.4s	v24, v20, #0x1
     f00:      	shl.4s	v25, v24, #0x17
     f04:      	add.4s	v25, v25, v22
     f08:      	fmul.4s	v7, v7, v25
     f0c:      	movi.4s	v25, #0x3f, lsl #24
     f10:      	sub.4s	v20, v20, v24
     f14:      	shl.4s	v20, v20, #0x17
     f18:      	add.4s	v20, v20, v22
     f1c:      	fmul.4s	v7, v7, v20
     f20:      	fcmgt.4s	v6, v6, v26
     f24:      	ldr	q20, [sp, #0x70]
     f28:      	bsl.16b	v6, v20, v7
     f2c:      	fdiv.4s	v7, v10, v6
     f30:      	fsub.4s	v20, v6, v7
     f34:      	fadd.4s	v6, v6, v7
     f38:      	fdiv.4s	v6, v20, v6
     f3c:      	bsl.16b	v5, v6, v22
     f40:      	fcmge.4s	v3, v22, v3
     f44:      	bsl.16b	v3, v4, v5
     f48:      	mvni.4s	v4, #0x80, lsl #24
     f4c:      	bif.16b	v3, v2, v4
     f50:      	fcmeq.4s	v2, v2, v2
     f54:      	fadd.4s	v3, v3, v22
     f58:      	ldr	q4, [sp, #0x60]
     f5c:      	bsl.16b	v2, v3, v4
     f60:      	fmul.4s	v3, v13, v25
     f64:      	fmul.4s	v2, v3, v2
     f68:      	fadd.4s	v2, v15, v2
     f6c:      	fmov	w14, s11
     f70:      	add	x13, x9, x8
     f74:      	tbnz	w14, #0x0, 0x11f0 <_llm_rows.packet_batch.blocks+0x834>
     f78:      	and	w14, w14, #0xff
     f7c:      	tbnz	w14, #0x1, 0x11fc <_llm_rows.packet_batch.blocks+0x840>
     f80:      	mov.16b	v3, v16
     f84:      	tbnz	w14, #0x2, 0x120c <_llm_rows.packet_batch.blocks+0x850>
     f88:      	tbz	w14, #0x3, 0xf94 <_llm_rows.packet_batch.blocks+0x5d8>
     f8c:      	add	x15, x13, #0xc
     f90:      	st1.s	{ v2 }[3], [x15]
     f94:      	fmul.4s	v2, v12, v3
     f98:      	fmul.4s	v2, v12, v2
     f9c:      	fmul.4s	v2, v12, v2
     fa0:      	fadd.4s	v2, v12, v2
     fa4:      	ldp	q5, q3, [sp, #0xf0]
     fa8:      	fmul.4s	v2, v2, v3
     fac:      	and.16b	v2, v0, v2
     fb0:      	fabs.4s	v13, v2
     fb4:      	fmul.4s	v3, v2, v2
     fb8:      	ldr	q4, [sp, #0xe0]
     fbc:      	fmla.4s	v4, v3, v5
     fc0:      	ldr	q5, [sp, #0xd0]
     fc4:      	fmla.4s	v5, v3, v4
     fc8:      	ldr	q4, [sp, #0xc0]
     fcc:      	fmla.4s	v4, v3, v5
     fd0:      	ldp	q6, q5, [sp, #0xa0]
     fd4:      	fmla.4s	v5, v3, v4
     fd8:      	mov.16b	v4, v17
     fdc:      	fmla.4s	v4, v3, v5
     fe0:      	mov.16b	v5, v22
     fe4:      	fmla.4s	v5, v3, v4
     fe8:      	fmul.4s	v4, v13, v5
     fec:      	mov.16b	v5, v19
     ff0:      	fmla.4s	v5, v3, v6
     ff4:      	mov.16b	v6, v18
     ff8:      	fmla.4s	v6, v3, v5
     ffc:      	mov.16b	v5, v21
    1000:      	fmla.4s	v5, v3, v6
    1004:      	mov.16b	v6, v23
    1008:      	fmla.4s	v6, v3, v5
    100c:      	movi.4s	v5, #0x3f, lsl #24
    1010:      	fmla.4s	v5, v3, v6
    1014:      	mov.16b	v6, v22
    1018:      	fmla.4s	v6, v3, v5
    101c:      	fdiv.4s	v3, v4, v6
    1020:      	ldp	q6, q4, [sp, #0x80]
    1024:      	fcmge.4s	v4, v4, v13
    1028:      	and.16b	v5, v4, v13
    102c:      	fcmge.4s	v6, v5, v6
    1030:      	fcmge.4s	v7, v26, v5
    1034:      	and.16b	v6, v6, v7
    1038:      	and.16b	v6, v6, v5
    103c:      	fmul.4s	v7, v6, v27
    1040:      	movi.4s	v20, #0x4b, lsl #24
    1044:      	fadd.4s	v7, v7, v20
    1048:      	movi.4s	v20, #0xcb, lsl #24
    104c:      	fadd.4s	v7, v7, v20
    1050:      	fcvtzs.4s	v7, v7
    1054:      	scvtf.4s	v20, v7
    1058:      	fmul.4s	v24, v20, v28
    105c:      	fadd.4s	v6, v6, v24
    1060:      	fmul.4s	v20, v20, v29
    1064:      	fadd.4s	v6, v6, v20
    1068:      	fmul.4s	v20, v6, v30
    106c:      	fadd.4s	v20, v20, v31
    1070:      	fmul.4s	v20, v6, v20
    1074:      	fadd.4s	v20, v20, v8
    1078:      	fmul.4s	v20, v6, v20
    107c:      	fadd.4s	v20, v20, v9
    1080:      	fmul.4s	v20, v6, v20
    1084:      	fadd.4s	v20, v20, v17
    1088:      	fmul.4s	v20, v6, v20
    108c:      	fadd.4s	v20, v20, v25
    1090:      	fmul.4s	v24, v6, v6
    1094:      	fmul.4s	v20, v24, v20
    1098:      	fadd.4s	v6, v6, v20
    109c:      	fadd.4s	v6, v6, v22
    10a0:      	movi.2d	v20, #0xffffffffffffffff
    10a4:      	add.4s	v7, v7, v20
    10a8:      	sshr.4s	v20, v7, #0x1
    10ac:      	shl.4s	v24, v20, #0x17
    10b0:      	add.4s	v24, v24, v22
    10b4:      	fmul.4s	v6, v6, v24
    10b8:      	sub.4s	v7, v7, v20
    10bc:      	shl.4s	v7, v7, #0x17
    10c0:      	add.4s	v7, v7, v22
    10c4:      	fmul.4s	v6, v6, v7
    10c8:      	fcmgt.4s	v5, v5, v26
    10cc:      	ldr	q7, [sp, #0x70]
    10d0:      	bsl.16b	v5, v7, v6
    10d4:      	fdiv.4s	v6, v10, v5
    10d8:      	fsub.4s	v7, v5, v6
    10dc:      	fadd.4s	v5, v5, v6
    10e0:      	fdiv.4s	v5, v7, v5
    10e4:      	bsl.16b	v4, v5, v22
    10e8:      	fcmge.4s	v5, v22, v13
    10ec:      	bif.16b	v3, v4, v5
    10f0:      	mvni.4s	v4, #0x80, lsl #24
    10f4:      	bif.16b	v3, v2, v4
    10f8:      	fcmeq.4s	v2, v2, v2
    10fc:      	fadd.4s	v3, v3, v22
    1100:      	ldr	q4, [sp, #0x60]
    1104:      	bsl.16b	v2, v3, v4
    1108:      	fmul.4s	v3, v12, v25
    110c:      	fmul.4s	v2, v3, v2
    1110:      	fadd.4s	v2, v14, v2
    1114:      	tbnz	w14, #0x4, 0x121c <_llm_rows.packet_batch.blocks+0x860>
    1118:      	tbnz	w14, #0x5, 0x1224 <_llm_rows.packet_batch.blocks+0x868>
    111c:      	tbnz	w14, #0x6, 0x1230 <_llm_rows.packet_batch.blocks+0x874>
    1120:      	tbz	w14, #0x7, 0xd6c <_llm_rows.packet_batch.blocks+0x3b0>
    1124:      	b	0x123c <_llm_rows.packet_batch.blocks+0x880>
    1128:      	ldr	s13, [x13]
    112c:      	and	w14, w12, #0xff
    1130:      	tbz	w14, #0x1, 0xd90 <_llm_rows.packet_batch.blocks+0x3d4>
    1134:      	add	x15, x13, #0x4
    1138:      	ld1.s	{ v13 }[1], [x15]
    113c:      	tbz	w14, #0x2, 0xd94 <_llm_rows.packet_batch.blocks+0x3d8>
    1140:      	add	x15, x13, #0x8
    1144:      	ld1.s	{ v13 }[2], [x15]
    1148:      	tbz	w14, #0x3, 0xd98 <_llm_rows.packet_batch.blocks+0x3dc>
    114c:      	add	x15, x13, #0xc
    1150:      	ld1.s	{ v13 }[3], [x15]
    1154:      	tbz	w14, #0x4, 0xd9c <_llm_rows.packet_batch.blocks+0x3e0>
    1158:      	add	x15, x13, #0x10
    115c:      	ld1.s	{ v12 }[0], [x15]
    1160:      	tbz	w14, #0x5, 0xda0 <_llm_rows.packet_batch.blocks+0x3e4>
    1164:      	add	x15, x13, #0x14
    1168:      	ld1.s	{ v12 }[1], [x15]
    116c:      	tbz	w14, #0x6, 0xda4 <_llm_rows.packet_batch.blocks+0x3e8>
    1170:      	add	x15, x13, #0x18
    1174:      	ld1.s	{ v12 }[2], [x15]
    1178:      	tbz	w14, #0x7, 0xda8 <_llm_rows.packet_batch.blocks+0x3ec>
    117c:      	add	x13, x13, #0x1c
    1180:      	ld1.s	{ v12 }[3], [x13]
    1184:      	fmov	w14, s11
    1188:      	add	x13, x10, x8
    118c:      	movi.2d	v15, #0000000000000000
    1190:      	movi.2d	v14, #0000000000000000
    1194:      	tbz	w14, #0x0, 0xdbc <_llm_rows.packet_batch.blocks+0x400>
    1198:      	ldr	s15, [x13]
    119c:      	and	w14, w14, #0xff
    11a0:      	tbz	w14, #0x1, 0xdc4 <_llm_rows.packet_batch.blocks+0x408>
    11a4:      	add	x15, x13, #0x4
    11a8:      	ld1.s	{ v15 }[1], [x15]
    11ac:      	tbz	w14, #0x2, 0xdc8 <_llm_rows.packet_batch.blocks+0x40c>
    11b0:      	add	x15, x13, #0x8
    11b4:      	ld1.s	{ v15 }[2], [x15]
    11b8:      	tbz	w14, #0x3, 0xdcc <_llm_rows.packet_batch.blocks+0x410>
    11bc:      	add	x15, x13, #0xc
    11c0:      	ld1.s	{ v15 }[3], [x15]
    11c4:      	tbz	w14, #0x4, 0xdd0 <_llm_rows.packet_batch.blocks+0x414>
    11c8:      	add	x15, x13, #0x10
    11cc:      	ld1.s	{ v14 }[0], [x15]
    11d0:      	tbz	w14, #0x5, 0xdd4 <_llm_rows.packet_batch.blocks+0x418>
    11d4:      	add	x15, x13, #0x14
    11d8:      	ld1.s	{ v14 }[1], [x15]
    11dc:      	tbz	w14, #0x6, 0xdd8 <_llm_rows.packet_batch.blocks+0x41c>
    11e0:      	add	x15, x13, #0x18
    11e4:      	ld1.s	{ v14 }[2], [x15]
    11e8:      	tbnz	w14, #0x7, 0xddc <_llm_rows.packet_batch.blocks+0x420>
    11ec:      	b	0xde4 <_llm_rows.packet_batch.blocks+0x428>
    11f0:      	str	s2, [x13]
    11f4:      	and	w14, w14, #0xff
    11f8:      	tbz	w14, #0x1, 0xf80 <_llm_rows.packet_batch.blocks+0x5c4>
    11fc:      	add	x15, x13, #0x4
    1200:      	st1.s	{ v2 }[1], [x15]
    1204:      	mov.16b	v3, v16
    1208:      	tbz	w14, #0x2, 0xf88 <_llm_rows.packet_batch.blocks+0x5cc>
    120c:      	add	x15, x13, #0x8
    1210:      	st1.s	{ v2 }[2], [x15]
    1214:      	tbnz	w14, #0x3, 0xf8c <_llm_rows.packet_batch.blocks+0x5d0>
    1218:      	b	0xf94 <_llm_rows.packet_batch.blocks+0x5d8>
    121c:      	str	s2, [x13, #0x10]
    1220:      	tbz	w14, #0x5, 0x111c <_llm_rows.packet_batch.blocks+0x760>
    1224:      	add	x15, x13, #0x14
    1228:      	st1.s	{ v2 }[1], [x15]
    122c:      	tbz	w14, #0x6, 0x1120 <_llm_rows.packet_batch.blocks+0x764>
    1230:      	add	x15, x13, #0x18
    1234:      	st1.s	{ v2 }[2], [x15]
    1238:      	tbz	w14, #0x7, 0xd6c <_llm_rows.packet_batch.blocks+0x3b0>
    123c:      	add	x13, x13, #0x1c
    1240:      	st1.s	{ v2 }[3], [x13]
    1244:      	b	0xd6c <_llm_rows.packet_batch.blocks+0x3b0>
    1248:      	mov	x8, #0x0                ; =0
    124c:      	add	x12, x12, x11
    1250:      	b	0x1274 <_llm_rows.packet_batch.blocks+0x8b8>
    1254:      	add	x13, x23, x8
    1258:      	ldp	q2, q3, [x13]
    125c:      	bit.16b	v3, v14, v0
    1260:      	bit.16b	v2, v13, v1
    1264:      	stp	q2, q3, [x13]
    1268:      	add	x8, x8, #0x20
    126c:      	cmp	x8, #0xc00
    1270:      	b.eq	0x1318 <_llm_rows.packet_batch.blocks+0x95c>
    1274:      	ldr	q2, [sp, #0x50]
    1278:      	and.16b	v2, v12, v2
    127c:      	addv.8h	h11, v2
    1280:      	fmov	w14, s11
    1284:      	add	x13, x12, x8
    1288:      	movi.2d	v13, #0000000000000000
    128c:      	movi.2d	v14, #0000000000000000
    1290:      	tbnz	w14, #0x0, 0x12b8 <_llm_rows.packet_batch.blocks+0x8fc>
    1294:      	and	w14, w14, #0xff
    1298:      	tbnz	w14, #0x1, 0x12c4 <_llm_rows.packet_batch.blocks+0x908>
    129c:      	tbnz	w14, #0x2, 0x12d0 <_llm_rows.packet_batch.blocks+0x914>
    12a0:      	tbnz	w14, #0x3, 0x12dc <_llm_rows.packet_batch.blocks+0x920>
    12a4:      	tbnz	w14, #0x4, 0x12e8 <_llm_rows.packet_batch.blocks+0x92c>
    12a8:      	tbnz	w14, #0x5, 0x12f4 <_llm_rows.packet_batch.blocks+0x938>
    12ac:      	tbnz	w14, #0x6, 0x1300 <_llm_rows.packet_batch.blocks+0x944>
    12b0:      	tbz	w14, #0x7, 0x1254 <_llm_rows.packet_batch.blocks+0x898>
    12b4:      	b	0x130c <_llm_rows.packet_batch.blocks+0x950>
    12b8:      	ldr	s13, [x13]
    12bc:      	and	w14, w14, #0xff
    12c0:      	tbz	w14, #0x1, 0x129c <_llm_rows.packet_batch.blocks+0x8e0>
    12c4:      	add	x15, x13, #0x4
    12c8:      	ld1.s	{ v13 }[1], [x15]
    12cc:      	tbz	w14, #0x2, 0x12a0 <_llm_rows.packet_batch.blocks+0x8e4>
    12d0:      	add	x15, x13, #0x8
    12d4:      	ld1.s	{ v13 }[2], [x15]
    12d8:      	tbz	w14, #0x3, 0x12a4 <_llm_rows.packet_batch.blocks+0x8e8>
    12dc:      	add	x15, x13, #0xc
    12e0:      	ld1.s	{ v13 }[3], [x15]
    12e4:      	tbz	w14, #0x4, 0x12a8 <_llm_rows.packet_batch.blocks+0x8ec>
    12e8:      	add	x15, x13, #0x10
    12ec:      	ld1.s	{ v14 }[0], [x15]
    12f0:      	tbz	w14, #0x5, 0x12ac <_llm_rows.packet_batch.blocks+0x8f0>
    12f4:      	add	x15, x13, #0x14
    12f8:      	ld1.s	{ v14 }[1], [x15]
    12fc:      	tbz	w14, #0x6, 0x12b0 <_llm_rows.packet_batch.blocks+0x8f4>
    1300:      	add	x15, x13, #0x18
    1304:      	ld1.s	{ v14 }[2], [x15]
    1308:      	tbz	w14, #0x7, 0x1254 <_llm_rows.packet_batch.blocks+0x898>
    130c:      	add	x13, x13, #0x1c
    1310:      	ld1.s	{ v14 }[3], [x13]
    1314:      	b	0x1254 <_llm_rows.packet_batch.blocks+0x898>
    1318:      	mov	x8, #0x0                ; =0
    131c:      	add	x10, x10, x11
    1320:      	b	0x1344 <_llm_rows.packet_batch.blocks+0x988>
    1324:      	add	x12, x24, x8
    1328:      	ldp	q2, q3, [x12]
    132c:      	bit.16b	v3, v13, v0
    1330:      	bit.16b	v2, v12, v1
    1334:      	stp	q2, q3, [x12]
    1338:      	add	x8, x8, #0x20
    133c:      	cmp	x8, #0xc00
    1340:      	b.eq	0x13dc <_llm_rows.packet_batch.blocks+0xa20>
    1344:      	fmov	w13, s11
    1348:      	add	x12, x10, x8
    134c:      	movi.2d	v12, #0000000000000000
    1350:      	movi.2d	v13, #0000000000000000
    1354:      	tbnz	w13, #0x0, 0x137c <_llm_rows.packet_batch.blocks+0x9c0>
    1358:      	and	w13, w13, #0xff
    135c:      	tbnz	w13, #0x1, 0x1388 <_llm_rows.packet_batch.blocks+0x9cc>
    1360:      	tbnz	w13, #0x2, 0x1394 <_llm_rows.packet_batch.blocks+0x9d8>
    1364:      	tbnz	w13, #0x3, 0x13a0 <_llm_rows.packet_batch.blocks+0x9e4>
    1368:      	tbnz	w13, #0x4, 0x13ac <_llm_rows.packet_batch.blocks+0x9f0>
    136c:      	tbnz	w13, #0x5, 0x13b8 <_llm_rows.packet_batch.blocks+0x9fc>
    1370:      	tbnz	w13, #0x6, 0x13c4 <_llm_rows.packet_batch.blocks+0xa08>
    1374:      	tbz	w13, #0x7, 0x1324 <_llm_rows.packet_batch.blocks+0x968>
    1378:      	b	0x13d0 <_llm_rows.packet_batch.blocks+0xa14>
    137c:      	ldr	s12, [x12]
    1380:      	and	w13, w13, #0xff
    1384:      	tbz	w13, #0x1, 0x1360 <_llm_rows.packet_batch.blocks+0x9a4>
    1388:      	add	x14, x12, #0x4
    138c:      	ld1.s	{ v12 }[1], [x14]
    1390:      	tbz	w13, #0x2, 0x1364 <_llm_rows.packet_batch.blocks+0x9a8>
    1394:      	add	x14, x12, #0x8
    1398:      	ld1.s	{ v12 }[2], [x14]
    139c:      	tbz	w13, #0x3, 0x1368 <_llm_rows.packet_batch.blocks+0x9ac>
    13a0:      	add	x14, x12, #0xc
    13a4:      	ld1.s	{ v12 }[3], [x14]
    13a8:      	tbz	w13, #0x4, 0x136c <_llm_rows.packet_batch.blocks+0x9b0>
    13ac:      	add	x14, x12, #0x10
    13b0:      	ld1.s	{ v13 }[0], [x14]
    13b4:      	tbz	w13, #0x5, 0x1370 <_llm_rows.packet_batch.blocks+0x9b4>
    13b8:      	add	x14, x12, #0x14
    13bc:      	ld1.s	{ v13 }[1], [x14]
    13c0:      	tbz	w13, #0x6, 0x1374 <_llm_rows.packet_batch.blocks+0x9b8>
    13c4:      	add	x14, x12, #0x18
    13c8:      	ld1.s	{ v13 }[2], [x14]
    13cc:      	tbz	w13, #0x7, 0x1324 <_llm_rows.packet_batch.blocks+0x968>
    13d0:      	add	x12, x12, #0x1c
    13d4:      	ld1.s	{ v13 }[3], [x12]
    13d8:      	b	0x1324 <_llm_rows.packet_batch.blocks+0x968>
    13dc:      	mov	x8, #0x0                ; =0
    13e0:      	add	x9, x9, x11
    13e4:      	b	0x13f4 <_llm_rows.packet_batch.blocks+0xa38>
    13e8:      	add	x8, x8, #0x20
    13ec:      	cmp	x8, #0xc00
    13f0:      	b.eq	0xa5c <_llm_rows.packet_batch.blocks+0xa0>
    13f4:      	add	x10, x23, x8
    13f8:      	ldr	q2, [x10]
    13fc:      	and.16b	v12, v1, v2
    1400:      	fmul.4s	v2, v12, v16
    1404:      	fmul.4s	v2, v12, v2
    1408:      	fmul.4s	v2, v12, v2
    140c:      	fadd.4s	v2, v12, v2
    1410:      	ldp	q5, q3, [sp, #0xf0]
    1414:      	fmul.4s	v2, v2, v3
    1418:      	and.16b	v13, v1, v2
    141c:      	fabs.4s	v2, v13
    1420:      	fmul.4s	v3, v13, v13
    1424:      	ldr	q4, [sp, #0xe0]
    1428:      	fmla.4s	v4, v3, v5
    142c:      	ldr	q5, [sp, #0xd0]
    1430:      	fmla.4s	v5, v3, v4
    1434:      	ldr	q4, [sp, #0xc0]
    1438:      	fmla.4s	v4, v3, v5
    143c:      	ldp	q6, q5, [sp, #0xa0]
    1440:      	fmla.4s	v5, v3, v4
    1444:      	mov.16b	v4, v17
    1448:      	fmla.4s	v4, v3, v5
    144c:      	mov.16b	v5, v22
    1450:      	fmla.4s	v5, v3, v4
    1454:      	fmul.4s	v4, v2, v5
    1458:      	mov.16b	v5, v19
    145c:      	fmla.4s	v5, v3, v6
    1460:      	mov.16b	v6, v18
    1464:      	fmla.4s	v6, v3, v5
    1468:      	mov.16b	v5, v21
    146c:      	fmla.4s	v5, v3, v6
    1470:      	mov.16b	v6, v23
    1474:      	fmla.4s	v6, v3, v5
    1478:      	movi.4s	v5, #0x3f, lsl #24
    147c:      	fmla.4s	v5, v3, v6
    1480:      	mov.16b	v6, v22
    1484:      	fmla.4s	v6, v3, v5
    1488:      	fdiv.4s	v3, v4, v6
    148c:      	ldp	q6, q4, [sp, #0x80]
    1490:      	fcmge.4s	v4, v4, v2
    1494:      	and.16b	v5, v4, v2
    1498:      	fcmge.4s	v6, v5, v6
    149c:      	fcmge.4s	v7, v26, v5
    14a0:      	and.16b	v6, v6, v7
    14a4:      	and.16b	v6, v6, v5
    14a8:      	fmul.4s	v7, v6, v27
    14ac:      	movi.4s	v20, #0x4b, lsl #24
    14b0:      	fadd.4s	v7, v7, v20
    14b4:      	movi.4s	v20, #0xcb, lsl #24
    14b8:      	fadd.4s	v7, v7, v20
    14bc:      	fcvtzs.4s	v7, v7
    14c0:      	scvtf.4s	v20, v7
    14c4:      	fmul.4s	v24, v20, v28
    14c8:      	fadd.4s	v6, v6, v24
    14cc:      	fmul.4s	v20, v20, v29
    14d0:      	fadd.4s	v6, v6, v20
    14d4:      	fmul.4s	v20, v6, v30
    14d8:      	fadd.4s	v20, v20, v31
    14dc:      	fmul.4s	v20, v6, v20
    14e0:      	fadd.4s	v20, v20, v8
    14e4:      	fmul.4s	v20, v6, v20
    14e8:      	fadd.4s	v20, v20, v9
    14ec:      	fmul.4s	v20, v6, v20
    14f0:      	fadd.4s	v20, v20, v17
    14f4:      	fmul.4s	v20, v6, v20
    14f8:      	fadd.4s	v20, v20, v25
    14fc:      	fmul.4s	v24, v6, v6
    1500:      	fmul.4s	v20, v24, v20
    1504:      	fadd.4s	v6, v6, v20
    1508:      	fadd.4s	v6, v6, v22
    150c:      	movi.2d	v20, #0xffffffffffffffff
    1510:      	add.4s	v7, v7, v20
    1514:      	sshr.4s	v20, v7, #0x1
    1518:      	shl.4s	v24, v20, #0x17
    151c:      	add.4s	v24, v24, v22
    1520:      	fmul.4s	v6, v6, v24
    1524:      	sub.4s	v7, v7, v20
    1528:      	shl.4s	v7, v7, #0x17
    152c:      	add.4s	v7, v7, v22
    1530:      	fmul.4s	v6, v6, v7
    1534:      	fcmgt.4s	v5, v5, v26
    1538:      	ldr	q7, [sp, #0x70]
    153c:      	bsl.16b	v5, v7, v6
    1540:      	fdiv.4s	v6, v10, v5
    1544:      	fsub.4s	v7, v5, v6
    1548:      	fadd.4s	v5, v5, v6
    154c:      	fdiv.4s	v5, v7, v5
    1550:      	bsl.16b	v4, v5, v22
    1554:      	fcmge.4s	v2, v22, v2
    1558:      	bsl.16b	v2, v3, v4
    155c:      	mvni.4s	v3, #0x80, lsl #24
    1560:      	bif.16b	v2, v13, v3
    1564:      	fcmeq.4s	v3, v13, v13
    1568:      	fadd.4s	v2, v2, v22
    156c:      	ldr	q4, [sp, #0x60]
    1570:      	bsl.16b	v3, v2, v4
    1574:      	ldr	q2, [x10, #0x10]
    1578:      	fmul.4s	v4, v12, v25
    157c:      	fmul.4s	v3, v4, v3
    1580:      	add	x10, x24, x8
    1584:      	ldp	q4, q12, [x10]
    1588:      	and.16b	v4, v1, v4
    158c:      	fadd.4s	v3, v4, v3
    1590:      	fmov	w11, s11
    1594:      	add	x10, x9, x8
    1598:      	tbnz	w11, #0x0, 0x1750 <_llm_rows.packet_batch.blocks+0xd94>
    159c:      	and	w11, w11, #0xff
    15a0:      	tbnz	w11, #0x1, 0x175c <_llm_rows.packet_batch.blocks+0xda0>
    15a4:      	tbnz	w11, #0x2, 0x1768 <_llm_rows.packet_batch.blocks+0xdac>
    15a8:      	tbz	w11, #0x3, 0x15b4 <_llm_rows.packet_batch.blocks+0xbf8>
    15ac:      	add	x12, x10, #0xc
    15b0:      	st1.s	{ v3 }[3], [x12]
    15b4:      	and.16b	v13, v0, v2
    15b8:      	fmul.4s	v2, v13, v16
    15bc:      	fmul.4s	v2, v13, v2
    15c0:      	fmul.4s	v2, v13, v2
    15c4:      	fadd.4s	v2, v13, v2
    15c8:      	ldp	q5, q3, [sp, #0xf0]
    15cc:      	fmul.4s	v2, v2, v3
    15d0:      	and.16b	v14, v0, v2
    15d4:      	fabs.4s	v2, v14
    15d8:      	fmul.4s	v3, v14, v14
    15dc:      	ldr	q4, [sp, #0xe0]
    15e0:      	fmla.4s	v4, v3, v5
    15e4:      	ldr	q5, [sp, #0xd0]
    15e8:      	fmla.4s	v5, v3, v4
    15ec:      	ldr	q4, [sp, #0xc0]
    15f0:      	fmla.4s	v4, v3, v5
    15f4:      	ldp	q6, q5, [sp, #0xa0]
    15f8:      	fmla.4s	v5, v3, v4
    15fc:      	mov.16b	v4, v17
    1600:      	fmla.4s	v4, v3, v5
    1604:      	mov.16b	v5, v22
    1608:      	fmla.4s	v5, v3, v4
    160c:      	fmul.4s	v4, v2, v5
    1610:      	mov.16b	v5, v19
    1614:      	fmla.4s	v5, v3, v6
    1618:      	mov.16b	v6, v18
    161c:      	fmla.4s	v6, v3, v5
    1620:      	mov.16b	v5, v21
    1624:      	fmla.4s	v5, v3, v6
    1628:      	mov.16b	v6, v23
    162c:      	fmla.4s	v6, v3, v5
    1630:      	movi.4s	v5, #0x3f, lsl #24
    1634:      	fmla.4s	v5, v3, v6
    1638:      	mov.16b	v6, v22
    163c:      	fmla.4s	v6, v3, v5
    1640:      	fdiv.4s	v3, v4, v6
    1644:      	ldp	q6, q4, [sp, #0x80]
    1648:      	fcmge.4s	v4, v4, v2
    164c:      	and.16b	v5, v4, v2
    1650:      	fcmge.4s	v6, v5, v6
    1654:      	fcmge.4s	v7, v26, v5
    1658:      	and.16b	v6, v6, v7
    165c:      	and.16b	v6, v6, v5
    1660:      	fmul.4s	v7, v6, v27
    1664:      	movi.4s	v20, #0x4b, lsl #24
    1668:      	fadd.4s	v7, v7, v20
    166c:      	movi.4s	v20, #0xcb, lsl #24
    1670:      	fadd.4s	v7, v7, v20
    1674:      	fcvtzs.4s	v7, v7
    1678:      	scvtf.4s	v20, v7
    167c:      	fmul.4s	v24, v20, v28
    1680:      	fadd.4s	v6, v6, v24
    1684:      	fmul.4s	v20, v20, v29
    1688:      	fadd.4s	v6, v6, v20
    168c:      	fmul.4s	v20, v6, v30
    1690:      	fadd.4s	v20, v20, v31
    1694:      	fmul.4s	v20, v6, v20
    1698:      	fadd.4s	v20, v20, v8
    169c:      	fmul.4s	v20, v6, v20
    16a0:      	fadd.4s	v20, v20, v9
    16a4:      	fmul.4s	v20, v6, v20
    16a8:      	fadd.4s	v20, v20, v17
    16ac:      	fmul.4s	v20, v6, v20
    16b0:      	fadd.4s	v20, v20, v25
    16b4:      	fmul.4s	v24, v6, v6
    16b8:      	fmul.4s	v20, v24, v20
    16bc:      	fadd.4s	v6, v6, v20
    16c0:      	fadd.4s	v6, v6, v22
    16c4:      	movi.2d	v20, #0xffffffffffffffff
    16c8:      	add.4s	v7, v7, v20
    16cc:      	sshr.4s	v20, v7, #0x1
    16d0:      	shl.4s	v24, v20, #0x17
    16d4:      	add.4s	v24, v24, v22
    16d8:      	fmul.4s	v6, v6, v24
    16dc:      	sub.4s	v7, v7, v20
    16e0:      	shl.4s	v7, v7, #0x17
    16e4:      	add.4s	v7, v7, v22
    16e8:      	fmul.4s	v6, v6, v7
    16ec:      	fcmgt.4s	v5, v5, v26
    16f0:      	ldr	q7, [sp, #0x70]
    16f4:      	bsl.16b	v5, v7, v6
    16f8:      	fdiv.4s	v6, v10, v5
    16fc:      	fsub.4s	v7, v5, v6
    1700:      	fadd.4s	v5, v5, v6
    1704:      	fdiv.4s	v5, v7, v5
    1708:      	bsl.16b	v4, v5, v22
    170c:      	fcmge.4s	v2, v22, v2
    1710:      	bsl.16b	v2, v3, v4
    1714:      	mvni.4s	v3, #0x80, lsl #24
    1718:      	bif.16b	v2, v14, v3
    171c:      	fcmeq.4s	v3, v14, v14
    1720:      	fadd.4s	v2, v2, v22
    1724:      	ldr	q4, [sp, #0x60]
    1728:      	bif.16b	v2, v4, v3
    172c:      	fmul.4s	v3, v13, v25
    1730:      	fmul.4s	v2, v3, v2
    1734:      	and.16b	v3, v0, v12
    1738:      	fadd.4s	v2, v3, v2
    173c:      	tbnz	w11, #0x4, 0x1778 <_llm_rows.packet_batch.blocks+0xdbc>
    1740:      	tbnz	w11, #0x5, 0x1780 <_llm_rows.packet_batch.blocks+0xdc4>
    1744:      	tbnz	w11, #0x6, 0x178c <_llm_rows.packet_batch.blocks+0xdd0>
    1748:      	tbz	w11, #0x7, 0x13e8 <_llm_rows.packet_batch.blocks+0xa2c>
    174c:      	b	0x1798 <_llm_rows.packet_batch.blocks+0xddc>
    1750:      	str	s3, [x10]
    1754:      	and	w11, w11, #0xff
    1758:      	tbz	w11, #0x1, 0x15a4 <_llm_rows.packet_batch.blocks+0xbe8>
    175c:      	add	x12, x10, #0x4
    1760:      	st1.s	{ v3 }[1], [x12]
    1764:      	tbz	w11, #0x2, 0x15a8 <_llm_rows.packet_batch.blocks+0xbec>
    1768:      	add	x12, x10, #0x8
    176c:      	st1.s	{ v3 }[2], [x12]
    1770:      	tbnz	w11, #0x3, 0x15ac <_llm_rows.packet_batch.blocks+0xbf0>
    1774:      	b	0x15b4 <_llm_rows.packet_batch.blocks+0xbf8>
    1778:      	str	s2, [x10, #0x10]
    177c:      	tbz	w11, #0x5, 0x1744 <_llm_rows.packet_batch.blocks+0xd88>
    1780:      	add	x12, x10, #0x14
    1784:      	st1.s	{ v2 }[1], [x12]
    1788:      	tbz	w11, #0x6, 0x1748 <_llm_rows.packet_batch.blocks+0xd8c>
    178c:      	add	x12, x10, #0x18
    1790:      	st1.s	{ v2 }[2], [x12]
    1794:      	tbz	w11, #0x7, 0x13e8 <_llm_rows.packet_batch.blocks+0xa2c>
    1798:      	add	x10, x10, #0x1c
    179c:      	st1.s	{ v2 }[3], [x10]
    17a0:      	b	0x13e8 <_llm_rows.packet_batch.blocks+0xa2c>
    17a4:      	add	sp, sp, #0x1, lsl #12   ; =0x1000
    17a8:      	add	sp, sp, #0x920
    17ac:      	ldp	x29, x30, [sp, #0x90]
    17b0:      	ldp	x20, x19, [sp, #0x80]
    17b4:      	ldp	x22, x21, [sp, #0x70]
    17b8:      	ldp	x24, x23, [sp, #0x60]
    17bc:      	ldp	x26, x25, [sp, #0x50]
    17c0:      	ldp	x28, x27, [sp, #0x40]
    17c4:      	ldp	d9, d8, [sp, #0x30]
    17c8:      	ldp	d11, d10, [sp, #0x20]
    17cc:      	ldp	d13, d12, [sp, #0x10]
    17d0:      	ldp	d15, d14, [sp], #0xa0
    17d4:      	ret

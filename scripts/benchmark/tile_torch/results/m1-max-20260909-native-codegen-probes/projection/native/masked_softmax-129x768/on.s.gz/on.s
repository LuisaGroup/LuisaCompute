
/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/masked_softmax-129x768/on/object/tile_xir_w8_37948_1788936538444963_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0x70]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x22, x21, [sp, #0x40]
      14:      	stp	x20, x19, [sp, #0x50]
      18:      	stp	x29, x30, [sp, #0x60]
      1c:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
      20:      	sub	sp, sp, #0xf00
      24:      	ldr	x8, [x0]
      28:      	ldr	x19, [x0, #0x30]
      2c:      	ldr	w9, [x1]
      30:      	ldr	w10, [x1, #0x24]
      34:      	add	w9, w10, w9, lsl #5
      38:      	lsr	w21, w9, #3
      3c:      	mov	w9, #0xc00              ; =3072
      40:      	umull	x20, w21, w9
      44:      	umaddl	x1, w21, w9, x8
      48:      	add	x0, sp, #0x3, lsl #12   ; =0x3000
      4c:      	add	x0, x0, #0x300
      50:      	mov	w2, #0xc00              ; =3072
      54:      	bl	0x54 <ltmp0+0x54>
      58:      	mov	x8, #0x0                ; =0
      5c:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
      60:      	add	x9, x9, #0xb00
      64:      	adrp	x10, 0x0 <ltmp0>
      68:      	ldr	q0, [x10]
      6c:      	adrp	x10, 0x0 <ltmp0>
      70:      	ldr	q1, [x10]
      74:      	adrp	x10, 0x0 <ltmp0>
      78:      	ldr	q2, [x10]
      7c:      	adrp	x10, 0x0 <ltmp0>
      80:      	ldr	q3, [x10]
      84:      	dup.2d	v4, x8
      88:      	orr.16b	v5, v4, v0
      8c:      	orr.16b	v6, v4, v1
      90:      	orr.16b	v7, v4, v2
      94:      	orr.16b	v4, v4, v3
      98:      	stp	q7, q4, [x9, #0x20]
      9c:      	stp	q5, q6, [x9], #0x40
      a0:      	add	x8, x8, #0x8
      a4:      	cmp	x8, #0x300
      a8:      	b.ne	0x84 <ltmp0+0x84>
      ac:      	mov	x8, #0x0                ; =0
      b0:      	mov	w9, #0xaaab             ; =43691
      b4:      	movk	w9, #0xaaa, lsl #16
      b8:      	umull	x9, w21, w9
      bc:      	lsr	x9, x9, #37
      c0:      	mov	w10, #0x300             ; =768
      c4:      	msub	w9, w9, w10, w21
      c8:      	dup.2s	v0, w9
      cc:      	ushll.2d	v4, v0, #0x0
      d0:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
      d4:      	add	x9, x9, #0xb00
      d8:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
      dc:      	add	x10, x10, #0x800
      e0:      	dup.2d	v5, x10
      e4:      	adrp	x10, 0x0 <ltmp0>
      e8:      	ldr	q0, [x10]
      ec:      	adrp	x10, 0x0 <ltmp0>
      f0:      	ldr	q1, [x10]
      f4:      	adrp	x10, 0x0 <ltmp0>
      f8:      	ldr	q2, [x10]
      fc:      	adrp	x10, 0x0 <ltmp0>
     100:      	ldr	q3, [x10]
     104:      	movi.8b	v6, #0x1
     108:      	dup.2d	v7, x8
     10c:      	add	x10, x9, x8, lsl #6
     110:      	ldp	q17, q16, [x10, #0x20]
     114:      	ldp	q18, q19, [x10]
     118:      	add.2d	v7, v7, v5
     11c:      	add.2d	v20, v7, v1
     120:      	add.2d	v21, v7, v0
     124:      	cmge.2d	v19, v4, v19
     128:      	cmge.2d	v18, v4, v18
     12c:      	uzp1.4s	v18, v18, v19
     130:      	cmge.2d	v17, v4, v17
     134:      	cmge.2d	v16, v4, v16
     138:      	uzp1.4s	v16, v17, v16
     13c:      	uzp1.8h	v16, v18, v16
     140:      	xtn.8b	v16, v16
     144:      	and.8b	v16, v16, v6
     148:      	mov.d	x10, v21[1]
     14c:      	fmov	x11, d21
     150:      	str	b16, [x11]
     154:      	st1.b	{ v16 }[1], [x10]
     158:      	mov.d	x10, v20[1]
     15c:      	fmov	x11, d20
     160:      	st1.b	{ v16 }[2], [x11]
     164:      	st1.b	{ v16 }[3], [x10]
     168:      	add.2d	v17, v7, v2
     16c:      	mov.d	x10, v17[1]
     170:      	fmov	x11, d17
     174:      	st1.b	{ v16 }[4], [x11]
     178:      	add.2d	v7, v7, v3
     17c:      	st1.b	{ v16 }[5], [x10]
     180:      	mov.d	x10, v7[1]
     184:      	fmov	x11, d7
     188:      	st1.b	{ v16 }[6], [x11]
     18c:      	st1.b	{ v16 }[7], [x10]
     190:      	add	x8, x8, #0x1
     194:      	cmp	x8, #0x60
     198:      	b.ne	0x108 <ltmp0+0x108>
     19c:      	mov	x8, #0x0                ; =0
     1a0:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     1a4:      	add	x9, x9, #0x800
     1a8:      	dup.2d	v4, x9
     1ac:      	add	x9, sp, #0x3, lsl #12   ; =0x3000
     1b0:      	add	x9, x9, #0x300
     1b4:      	mov	w10, #0xf2ca            ; =62154
     1b8:      	movk	w10, #0xf149, lsl #16
     1bc:      	dup.4s	v5, w10
     1c0:      	add	x10, sp, #0xc00
     1c4:      	dup.2d	v6, x8
     1c8:      	add.2d	v6, v6, v4
     1cc:      	add.2d	v7, v6, v3
     1d0:      	add.2d	v16, v6, v0
     1d4:      	mov.d	x11, v16[1]
     1d8:      	add.2d	v17, v6, v2
     1dc:      	add.2d	v6, v6, v1
     1e0:      	fmov	x12, d16
     1e4:      	mov.d	x13, v6[1]
     1e8:      	mov.d	x14, v17[1]
     1ec:      	fmov	x15, d6
     1f0:      	ldr	b6, [x12]
     1f4:      	ld1.b	{ v6 }[1], [x11]
     1f8:      	mov.d	x11, v7[1]
     1fc:      	fmov	x12, d17
     200:      	ld1.b	{ v6 }[2], [x15]
     204:      	ld1.b	{ v6 }[3], [x13]
     208:      	fmov	x13, d7
     20c:      	ld1.b	{ v6 }[4], [x12]
     210:      	ld1.b	{ v6 }[5], [x14]
     214:      	ld1.b	{ v6 }[6], [x13]
     218:      	ld1.b	{ v6 }[7], [x11]
     21c:      	cmeq.8b	v6, v6, #0
     220:      	sshll.8h	v6, v6, #0x0
     224:      	sshll2.4s	v7, v6, #0x0
     228:      	sshll.4s	v6, v6, #0x0
     22c:      	lsl	x11, x8, #5
     230:      	add	x12, x9, x11
     234:      	ldp	q17, q16, [x12]
     238:      	bsl.16b	v6, v5, v17
     23c:      	bsl.16b	v7, v5, v16
     240:      	add	x11, x10, x11
     244:      	stp	q6, q7, [x11]
     248:      	add	x8, x8, #0x1
     24c:      	cmp	x8, #0x60
     250:      	b.ne	0x1c4 <ltmp0+0x1c4>
     254:      	ldr	q4, [sp, #0xc10]
     258:      	ldr	q6, [sp, #0xc00]
     25c:      	ldr	q5, [sp, #0xc30]
     260:      	ldr	q17, [sp, #0xc20]
     264:      	ldr	q16, [sp, #0xc50]
     268:      	ldr	q7, [sp, #0xc40]
     26c:      	add	x8, sp, #0xc00
     270:      	add	x8, x8, #0xe0
     274:      	mov	w9, #0x4                ; =4
     278:      	ldr	q18, [sp, #0xc70]
     27c:      	ldr	q19, [sp, #0xc60]
     280:      	ldp	q20, q21, [x8, #-0x60]
     284:      	fmaxnm.4s	v4, v4, v21
     288:      	fmaxnm.4s	v6, v6, v20
     28c:      	ldp	q20, q21, [x8, #-0x40]
     290:      	fmaxnm.4s	v5, v5, v21
     294:      	fmaxnm.4s	v17, v17, v20
     298:      	ldp	q20, q21, [x8, #-0x20]
     29c:      	fmaxnm.4s	v16, v16, v21
     2a0:      	fmaxnm.4s	v7, v7, v20
     2a4:      	ldp	q20, q21, [x8], #0x80
     2a8:      	fmaxnm.4s	v18, v18, v21
     2ac:      	fmaxnm.4s	v19, v19, v20
     2b0:      	cmp	x9, #0x5c
     2b4:      	add	x9, x9, #0x4
     2b8:      	b.lo	0x280 <ltmp0+0x280>
     2bc:      	mov	x8, #0x0                ; =0
     2c0:      	fmaxnm.4s	v6, v6, v17
     2c4:      	fmaxnm.4s	v4, v4, v5
     2c8:      	fmaxnm.4s	v4, v4, v16
     2cc:      	fmaxnm.4s	v5, v6, v7
     2d0:      	fmaxnm.4s	v5, v5, v19
     2d4:      	fmaxnm.4s	v4, v4, v18
     2d8:      	rev64.4s	v6, v4
     2dc:      	rev64.4s	v7, v5
     2e0:      	fmaxnm.4s	v5, v5, v7
     2e4:      	fmaxnm.4s	v4, v4, v6
     2e8:      	ext.16b	v6, v4, v4, #0x8
     2ec:      	ext.16b	v7, v5, v5, #0x8
     2f0:      	fmaxnm.4s	v5, v5, v7
     2f4:      	fmaxnm.4s	v4, v4, v6
     2f8:      	fmaxnm.4s	v4, v5, v4
     2fc:      	mov	w9, #-0x800000          ; =-8388608
     300:      	fmov	s5, w9
     304:      	fmaxnm	s4, s4, s5
     308:      	dup.4s	v4, v4[0]
     30c:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
     310:      	add	x9, x9, #0x800
     314:      	dup.2d	v5, x9
     318:      	mov	w9, #-0x3d300000        ; =-1026555904
     31c:      	dup.4s	v6, w9
     320:      	mov	w9, #0x42c80000         ; =1120403456
     324:      	dup.4s	v7, w9
     328:      	mov	w9, #0xaa3b             ; =43579
     32c:      	movk	w9, #0x3fb8, lsl #16
     330:      	dup.4s	v16, w9
     334:      	add	x9, sp, #0xc00
     338:      	movi.4s	v17, #0x4b, lsl #24
     33c:      	mvni.4s	v18, #0x80, lsl #24
     340:      	mov	w10, #0x7200            ; =29184
     344:      	movk	w10, #0xbf31, lsl #16
     348:      	dup.4s	v19, w10
     34c:      	mov	w10, #0xbe8e            ; =48782
     350:      	movk	w10, #0xb5bf, lsl #16
     354:      	dup.4s	v20, w10
     358:      	mov	w10, #0x2bda            ; =11226
     35c:      	movk	w10, #0x3950, lsl #16
     360:      	dup.4s	v21, w10
     364:      	mov	w10, #0x96c9            ; =38601
     368:      	movk	w10, #0x3ab6, lsl #16
     36c:      	dup.4s	v22, w10
     370:      	mov	w10, #0x88a6            ; =34982
     374:      	movk	w10, #0x3c08, lsl #16
     378:      	dup.4s	v23, w10
     37c:      	mov	w10, #0xaa7a            ; =43642
     380:      	movk	w10, #0x3d2a, lsl #16
     384:      	dup.4s	v24, w10
     388:      	mov	w10, #0xaaab            ; =43691
     38c:      	movk	w10, #0x3e2a, lsl #16
     390:      	dup.4s	v25, w10
     394:      	movi.4s	v26, #0x3f, lsl #24
     398:      	mvni.4s	v27, #0x7f, msl #16
     39c:      	fneg.4s	v27, v27
     3a0:      	mvni.4s	v28, #0x3f, msl #16
     3a4:      	fneg.4s	v28, v28
     3a8:      	mov	x10, sp
     3ac:      	dup.2d	v29, x8
     3b0:      	add.2d	v29, v29, v5
     3b4:      	add.2d	v31, v29, v3
     3b8:      	add.2d	v30, v29, v2
     3bc:      	add.2d	v8, v29, v1
     3c0:      	add.2d	v29, v29, v0
     3c4:      	mov.d	x13, v29[1]
     3c8:      	fmov	x15, d29
     3cc:      	mov.d	x14, v8[1]
     3d0:      	fmov	x16, d8
     3d4:      	mov.d	x11, v30[1]
     3d8:      	fmov	x12, d30
     3dc:      	lsl	x17, x8, #5
     3e0:      	add	x0, x9, x17
     3e4:      	ldp	q29, q30, [x0]
     3e8:      	mov.d	x0, v31[1]
     3ec:      	fsub.4s	v30, v30, v4
     3f0:      	fsub.4s	v29, v29, v4
     3f4:      	fcmge.4s	v8, v29, v6
     3f8:      	fcmge.4s	v9, v30, v6
     3fc:      	fcmge.4s	v10, v7, v29
     400:      	fmov	x1, d31
     404:      	fcmge.4s	v31, v7, v30
     408:      	and.16b	v31, v9, v31
     40c:      	and.16b	v8, v8, v10
     410:      	and.16b	v8, v8, v29
     414:      	and.16b	v31, v31, v30
     418:      	fmul.4s	v9, v31, v16
     41c:      	fmul.4s	v10, v8, v16
     420:      	mov.16b	v11, v18
     424:      	bsl.16b	v11, v17, v10
     428:      	mov.16b	v12, v18
     42c:      	bsl.16b	v12, v17, v9
     430:      	fadd.4s	v9, v9, v12
     434:      	fadd.4s	v10, v10, v11
     438:      	fsub.4s	v10, v10, v11
     43c:      	fsub.4s	v9, v9, v12
     440:      	fcvtzs.4s	v9, v9
     444:      	fcvtzs.4s	v10, v10
     448:      	scvtf.4s	v11, v10
     44c:      	scvtf.4s	v12, v9
     450:      	fmul.4s	v13, v12, v19
     454:      	fmul.4s	v14, v11, v19
     458:      	fadd.4s	v8, v8, v14
     45c:      	fadd.4s	v31, v31, v13
     460:      	fmul.4s	v11, v11, v20
     464:      	fmul.4s	v12, v12, v20
     468:      	fadd.4s	v31, v31, v12
     46c:      	fadd.4s	v8, v8, v11
     470:      	fmul.4s	v11, v8, v21
     474:      	fmul.4s	v12, v31, v21
     478:      	fadd.4s	v12, v12, v22
     47c:      	fadd.4s	v11, v11, v22
     480:      	fmul.4s	v11, v8, v11
     484:      	fmul.4s	v12, v31, v12
     488:      	fadd.4s	v12, v12, v23
     48c:      	fadd.4s	v11, v11, v23
     490:      	fmul.4s	v11, v8, v11
     494:      	fmul.4s	v12, v31, v12
     498:      	fadd.4s	v12, v12, v24
     49c:      	fadd.4s	v11, v11, v24
     4a0:      	fmul.4s	v11, v8, v11
     4a4:      	fmul.4s	v12, v31, v12
     4a8:      	fadd.4s	v12, v12, v25
     4ac:      	fadd.4s	v11, v11, v25
     4b0:      	fmul.4s	v11, v8, v11
     4b4:      	fmul.4s	v12, v31, v12
     4b8:      	fadd.4s	v12, v12, v26
     4bc:      	fadd.4s	v11, v11, v26
     4c0:      	fmul.4s	v13, v31, v31
     4c4:      	fmul.4s	v14, v8, v8
     4c8:      	fmul.4s	v11, v14, v11
     4cc:      	fmul.4s	v12, v13, v12
     4d0:      	fadd.4s	v31, v31, v12
     4d4:      	fadd.4s	v8, v8, v11
     4d8:      	fmov.4s	v11, #1.00000000
     4dc:      	sshr.4s	v12, v10, #0x1
     4e0:      	fadd.4s	v31, v31, v11
     4e4:      	sshr.4s	v13, v9, #0x1
     4e8:      	shl.4s	v14, v13, #0x17
     4ec:      	add.4s	v14, v14, v11
     4f0:      	fmul.4s	v31, v31, v14
     4f4:      	shl.4s	v14, v12, #0x17
     4f8:      	fadd.4s	v8, v8, v11
     4fc:      	add.4s	v14, v14, v11
     500:      	fmul.4s	v8, v8, v14
     504:      	sub.4s	v9, v9, v13
     508:      	sub.4s	v10, v10, v12
     50c:      	shl.4s	v10, v10, #0x17
     510:      	shl.4s	v9, v9, #0x17
     514:      	add.4s	v9, v9, v11
     518:      	add.4s	v10, v10, v11
     51c:      	fmul.4s	v8, v8, v10
     520:      	ldr	b10, [x15]
     524:      	ld1.b	{ v10 }[1], [x13]
     528:      	ld1.b	{ v10 }[2], [x16]
     52c:      	ld1.b	{ v10 }[3], [x14]
     530:      	fmul.4s	v31, v31, v9
     534:      	fcmgt.4s	v9, v6, v30
     538:      	bic.16b	v31, v31, v9
     53c:      	fcmgt.4s	v9, v6, v29
     540:      	bic.16b	v8, v8, v9
     544:      	fcmgt.4s	v9, v29, v7
     548:      	bit.16b	v8, v27, v9
     54c:      	fcmgt.4s	v9, v30, v7
     550:      	bit.16b	v31, v27, v9
     554:      	ld1.b	{ v10 }[4], [x12]
     558:      	ld1.b	{ v10 }[5], [x11]
     55c:      	fcmeq.4s	v30, v30, v30
     560:      	bsl.16b	v30, v31, v28
     564:      	ld1.b	{ v10 }[6], [x1]
     568:      	ld1.b	{ v10 }[7], [x0]
     56c:      	cmeq.8b	v31, v10, #0
     570:      	sshll.8h	v31, v31, #0x0
     574:      	fcmeq.4s	v29, v29, v29
     578:      	bsl.16b	v29, v8, v28
     57c:      	sshll.4s	v8, v31, #0x0
     580:      	bic.16b	v29, v29, v8
     584:      	sshll2.4s	v31, v31, #0x0
     588:      	bic.16b	v30, v30, v31
     58c:      	add	x11, x10, x17
     590:      	stp	q29, q30, [x11]
     594:      	add	x8, x8, #0x1
     598:      	cmp	x8, #0x60
     59c:      	b.ne	0x3ac <ltmp0+0x3ac>
     5a0:      	ldp	q2, q0, [sp]
     5a4:      	ldp	q5, q1, [sp, #0x20]
     5a8:      	ldp	q3, q4, [sp, #0x40]
     5ac:      	mov	x8, sp
     5b0:      	add	x8, x8, #0xe0
     5b4:      	mov	w9, #0x4                ; =4
     5b8:      	ldp	q7, q6, [sp, #0x60]
     5bc:      	ldp	q16, q17, [x8, #-0x60]
     5c0:      	fadd.4s	v0, v0, v17
     5c4:      	fadd.4s	v2, v2, v16
     5c8:      	ldp	q16, q17, [x8, #-0x40]
     5cc:      	fadd.4s	v1, v1, v17
     5d0:      	fadd.4s	v5, v5, v16
     5d4:      	ldp	q16, q17, [x8, #-0x20]
     5d8:      	fadd.4s	v4, v4, v17
     5dc:      	fadd.4s	v3, v3, v16
     5e0:      	ldp	q16, q17, [x8], #0x80
     5e4:      	fadd.4s	v6, v6, v17
     5e8:      	fadd.4s	v7, v7, v16
     5ec:      	cmp	x9, #0x5c
     5f0:      	add	x9, x9, #0x4
     5f4:      	b.lo	0x5bc <ltmp0+0x5bc>
     5f8:      	mov	x8, #0x0                ; =0
     5fc:      	fadd.4s	v2, v2, v5
     600:      	fadd.4s	v0, v0, v1
     604:      	fadd.4s	v0, v0, v4
     608:      	fadd.4s	v1, v2, v3
     60c:      	fadd.4s	v1, v1, v7
     610:      	fadd.4s	v0, v0, v6
     614:      	rev64.4s	v2, v0
     618:      	rev64.4s	v3, v1
     61c:      	fadd.4s	v0, v0, v2
     620:      	dup.4s	v2, v0[2]
     624:      	fadd.4s	v1, v1, v3
     628:      	dup.4s	v3, v1[2]
     62c:      	fadd.4s	v1, v1, v3
     630:      	fadd.4s	v0, v0, v2
     634:      	fadd.4s	v0, v1, v0
     638:      	movi	d1, #0000000000000000
     63c:      	fadd	s0, s0, s1
     640:      	dup.4s	v0, v0[0]
     644:      	add	x9, x19, x20
     648:      	mov	x10, sp
     64c:      	add	x11, x10, x8
     650:      	ldp	q2, q1, [x11]
     654:      	fdiv.4s	v2, v2, v0
     658:      	fdiv.4s	v1, v1, v0
     65c:      	add	x11, x9, x8
     660:      	stp	q2, q1, [x11]
     664:      	add	x8, x8, #0x20
     668:      	cmp	x8, #0xc00
     66c:      	b.ne	0x64c <ltmp0+0x64c>
     670:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
     674:      	add	sp, sp, #0xf00
     678:      	ldp	x29, x30, [sp, #0x60]
     67c:      	ldp	x20, x19, [sp, #0x50]
     680:      	ldp	x22, x21, [sp, #0x40]
     684:      	ldp	d9, d8, [sp, #0x30]
     688:      	ldp	d11, d10, [sp, #0x20]
     68c:      	ldp	d13, d12, [sp, #0x10]
     690:      	ldp	d15, d14, [sp], #0x70
     694:      	ret

0000000000000698 <_llm_rows.packet_batch.blocks>:
     698:      	stp	d15, d14, [sp, #-0xa0]!
     69c:      	stp	d13, d12, [sp, #0x10]
     6a0:      	stp	d11, d10, [sp, #0x20]
     6a4:      	stp	d9, d8, [sp, #0x30]
     6a8:      	stp	x28, x27, [sp, #0x40]
     6ac:      	stp	x26, x25, [sp, #0x50]
     6b0:      	stp	x24, x23, [sp, #0x60]
     6b4:      	stp	x22, x21, [sp, #0x70]
     6b8:      	stp	x20, x19, [sp, #0x80]
     6bc:      	stp	x29, x30, [sp, #0x90]
     6c0:      	sub	sp, sp, #0x4, lsl #12   ; =0x4000
     6c4:      	sub	sp, sp, #0x500
     6c8:      	str	x0, [sp, #0x108]
     6cc:      	cbz	w3, 0x1ac4 <_llm_rows.packet_batch.blocks+0x142c>
     6d0:      	mov	x27, x3
     6d4:      	mov	x20, x2
     6d8:      	mov	w22, #0x0               ; =0
     6dc:      	add	x23, sp, #0x1a0
     6e0:      	add	x8, sp, #0x1, lsl #12   ; =0x1000
     6e4:      	add	x8, x8, #0xe00
     6e8:      	dup.2d	v0, x8
     6ec:      	str	q0, [sp, #0x30]
     6f0:      	add	x24, sp, #0x1, lsl #12  ; =0x1000
     6f4:      	add	x24, x24, #0x200
     6f8:      	add	x9, x24, #0xe0
     6fc:      	add	x8, sp, #0x600
     700:      	add	x8, x8, #0xe0
     704:      	stp	x8, x9, [sp, #0x20]
     708:      	adrp	x8, 0x0 <ltmp0>
     70c:      	ldr	q0, [x8]
     710:      	str	q0, [sp, #0x10]
     714:      	adrp	x8, 0x0 <ltmp0>
     718:      	ldr	q0, [x8]
     71c:      	str	q0, [sp, #0xb0]
     720:      	adrp	x8, 0x0 <ltmp0>
     724:      	ldr	q0, [x8]
     728:      	str	q0, [sp, #0xa0]
     72c:      	add	x25, sp, #0x3, lsl #12  ; =0x3000
     730:      	add	x25, x25, #0x900
     734:      	movi.8b	v8, #0x1
     738:      	movi	d9, #0000000000000000
     73c:      	movi.4s	v10, #0x4b, lsl #24
     740:      	mvni.4s	v11, #0x80, lsl #24
     744:      	movi.4s	v12, #0x3f, lsl #24
     748:      	mvni.4s	v0, #0x7f, msl #16
     74c:      	fneg.4s	v13, v0
     750:      	mvni.4s	v0, #0x3f, msl #16
     754:      	fneg.4s	v14, v0
     758:      	ldp	w9, w8, [x2, #0x2c]
     75c:      	str	w9, [sp, #0x104]
     760:      	str	w8, [sp, #0x100]
     764:      	ldp	w19, w13, [x2]
     768:      	ldp	w28, w8, [x2, #0x8]
     76c:      	str	x8, [sp, #0xf8]
     770:      	stp	q14, q13, [sp, #0xd0]
     774:      	str	w3, [sp, #0x9c]
     778:      	b	0x7c4 <_llm_rows.packet_batch.blocks+0x12c>
     77c:      	mov	w8, #0x18               ; =24
     780:      	str	w8, [x20, #0x24]
     784:      	ldr	w27, [sp, #0x9c]
     788:      	add	w8, w19, #0x1
     78c:      	ldr	w9, [sp, #0x104]
     790:      	cmp	w8, w9
     794:      	cset	w8, eq
     798:      	csinc	w19, wzr, w19, eq
     79c:      	cinc	w9, w13, eq
     7a0:      	ldr	w10, [sp, #0x100]
     7a4:      	cmp	w9, w10
     7a8:      	cset	w10, eq
     7ac:      	ands	w8, w8, w10
     7b0:      	csel	w13, wzr, w9, ne
     7b4:      	add	w28, w28, w8
     7b8:      	add	w22, w22, #0x1
     7bc:      	cmp	w22, w27
     7c0:      	b.eq	0x1ac4 <_llm_rows.packet_batch.blocks+0x142c>
     7c4:      	ubfiz	x8, x19, #5, #32
     7c8:      	ldr	x12, [sp, #0xf8]
     7cc:      	cmp	x8, x12
     7d0:      	csel	x9, x8, xzr, ls
     7d4:      	subs	x10, x12, x9
     7d8:      	cmp	x10, #0x20
     7dc:      	mov	w11, #0x20              ; =32
     7e0:      	csel	x10, x10, x11, lo
     7e4:      	cmp	x12, x9
     7e8:      	stp	w19, w13, [x20]
     7ec:      	str	w28, [x20, #0x8]
     7f0:      	str	wzr, [x20, #0x24]
     7f4:      	ccmp	x8, x12, #0x2, hi
     7f8:      	csel	x21, x10, xzr, ls
     7fc:      	cmp	x21, #0x20
     800:      	b.lo	0x86c <_llm_rows.packet_batch.blocks+0x1d4>
     804:      	ldr	x21, [sp, #0x108]
     808:      	mov	x0, x21
     80c:      	mov	x1, x20
     810:      	mov	x26, x13
     814:      	bl	0x814 <_llm_rows.packet_batch.blocks+0x17c>
     818:      	mov	w8, #0x8                ; =8
     81c:      	str	w8, [x20, #0x24]
     820:      	mov	x0, x21
     824:      	mov	x1, x20
     828:      	bl	0x828 <_llm_rows.packet_batch.blocks+0x190>
     82c:      	mov	w8, #0x10               ; =16
     830:      	str	w8, [x20, #0x24]
     834:      	mov	x0, x21
     838:      	mov	x1, x20
     83c:      	bl	0x83c <_llm_rows.packet_batch.blocks+0x1a4>
     840:      	mov	w8, #0x18               ; =24
     844:      	str	w8, [x20, #0x24]
     848:      	mov	x0, x21
     84c:      	mov	x1, x20
     850:      	bl	0x850 <_llm_rows.packet_batch.blocks+0x1b8>
     854:      	mov	x13, x26
     858:      	ldp	q14, q13, [sp, #0xd0]
     85c:      	movi.4s	v12, #0x3f, lsl #24
     860:      	mvni.4s	v11, #0x80, lsl #24
     864:      	movi.4s	v10, #0x4b, lsl #24
     868:      	b	0x788 <_llm_rows.packet_batch.blocks+0xf0>
     86c:      	lsr	x27, x21, #3
     870:      	cmp	x21, #0x8
     874:      	b.lo	0x900 <_llm_rows.packet_batch.blocks+0x268>
     878:      	str	wzr, [x20, #0x24]
     87c:      	ldr	x0, [sp, #0x108]
     880:      	mov	x1, x20
     884:      	mov	x26, x13
     888:      	bl	0x888 <_llm_rows.packet_batch.blocks+0x1f0>
     88c:      	mov	x13, x26
     890:      	ldp	q14, q13, [sp, #0xd0]
     894:      	movi.4s	v12, #0x3f, lsl #24
     898:      	mvni.4s	v11, #0x80, lsl #24
     89c:      	movi.4s	v10, #0x4b, lsl #24
     8a0:      	cmp	x27, #0x1
     8a4:      	b.eq	0x900 <_llm_rows.packet_batch.blocks+0x268>
     8a8:      	mov	w8, #0x8                ; =8
     8ac:      	str	w8, [x20, #0x24]
     8b0:      	ldr	x0, [sp, #0x108]
     8b4:      	mov	x1, x20
     8b8:      	bl	0x8b8 <_llm_rows.packet_batch.blocks+0x220>
     8bc:      	mov	x13, x26
     8c0:      	ldp	q14, q13, [sp, #0xd0]
     8c4:      	movi.4s	v12, #0x3f, lsl #24
     8c8:      	mvni.4s	v11, #0x80, lsl #24
     8cc:      	movi.4s	v10, #0x4b, lsl #24
     8d0:      	cmp	x27, #0x2
     8d4:      	b.eq	0x900 <_llm_rows.packet_batch.blocks+0x268>
     8d8:      	mov	w8, #0x10               ; =16
     8dc:      	str	w8, [x20, #0x24]
     8e0:      	ldr	x0, [sp, #0x108]
     8e4:      	mov	x1, x20
     8e8:      	bl	0x8e8 <_llm_rows.packet_batch.blocks+0x250>
     8ec:      	mov	x13, x26
     8f0:      	ldp	q14, q13, [sp, #0xd0]
     8f4:      	movi.4s	v12, #0x3f, lsl #24
     8f8:      	mvni.4s	v11, #0x80, lsl #24
     8fc:      	movi.4s	v10, #0x4b, lsl #24
     900:      	and	w8, w21, #0x7
     904:      	cbz	w8, 0x77c <_llm_rows.packet_batch.blocks+0xe4>
     908:      	dup.4s	v3, w8
     90c:      	ldp	q0, q1, [sp, #0xa0]
     910:      	cmhi.4s	v0, v3, v0
     914:      	cmhi.4s	v1, v3, v1
     918:      	uzp1.8h	v7, v1, v0
     91c:      	umaxv.8h	h2, v7
     920:      	fmov	w8, s2
     924:      	tbz	w8, #0x0, 0x77c <_llm_rows.packet_batch.blocks+0xe4>
     928:      	str	w13, [sp, #0x98]
     92c:      	mov	x12, #0x0               ; =0
     930:      	ldr	x9, [sp, #0x108]
     934:      	ldr	x8, [x9, #0x30]
     938:      	str	x8, [sp, #0x90]
     93c:      	ldr	q2, [sp, #0x10]
     940:      	and.16b	v2, v7, v2
     944:      	addv.8h	h2, v2
     948:      	fmov	w8, s2
     94c:      	and	w8, w8, #0xff
     950:      	str	w8, [sp, #0x80]
     954:      	ldr	x8, [x9]
     958:      	ubfiz	w9, w19, #2, #27
     95c:      	orr	w9, w9, w27
     960:      	dup.4s	v4, w9
     964:      	fmov	w10, s3
     968:      	cmp	w10, #0x0
     96c:      	cset	w10, ne
     970:      	str	x10, [sp, #0xc8]
     974:      	mov	w11, #0xc00             ; =3072
     978:      	umull	x9, w9, w11
     97c:      	csel	x9, x9, xzr, ne
     980:      	str	x9, [sp, #0x88]
     984:      	add	x8, x8, x9
     988:      	fmov	w13, s2
     98c:      	adrp	x15, 0x0 <ltmp0>
     990:      	adrp	x16, 0x0 <ltmp0>
     994:      	adrp	x17, 0x0 <ltmp0>
     998:      	adrp	x0, 0x0 <ltmp0>
     99c:      	add	x1, sp, #0x2, lsl #12   ; =0x2000
     9a0:      	add	x1, x1, #0x100
     9a4:      	mov	w2, #0xf2ca             ; =62154
     9a8:      	movk	w2, #0xf149, lsl #16
     9ac:      	b	0x9d0 <_llm_rows.packet_batch.blocks+0x338>
     9b0:      	add	x9, x25, x12
     9b4:      	ldp	q16, q17, [x9]
     9b8:      	bif.16b	v6, v17, v0
     9bc:      	bif.16b	v5, v16, v1
     9c0:      	stp	q5, q6, [x9]
     9c4:      	add	x12, x12, #0x20
     9c8:      	cmp	x12, #0xc00
     9cc:      	b.eq	0xa64 <_llm_rows.packet_batch.blocks+0x3cc>
     9d0:      	add	x9, x8, x12
     9d4:      	movi.2d	v5, #0000000000000000
     9d8:      	movi.2d	v6, #0000000000000000
     9dc:      	tbnz	w13, #0x0, 0xa04 <_llm_rows.packet_batch.blocks+0x36c>
     9e0:      	and	w11, w13, #0xff
     9e4:      	tbnz	w11, #0x1, 0xa10 <_llm_rows.packet_batch.blocks+0x378>
     9e8:      	tbnz	w11, #0x2, 0xa1c <_llm_rows.packet_batch.blocks+0x384>
     9ec:      	tbnz	w11, #0x3, 0xa28 <_llm_rows.packet_batch.blocks+0x390>
     9f0:      	tbnz	w11, #0x4, 0xa34 <_llm_rows.packet_batch.blocks+0x39c>
     9f4:      	tbnz	w11, #0x5, 0xa40 <_llm_rows.packet_batch.blocks+0x3a8>
     9f8:      	tbnz	w11, #0x6, 0xa4c <_llm_rows.packet_batch.blocks+0x3b4>
     9fc:      	tbz	w11, #0x7, 0x9b0 <_llm_rows.packet_batch.blocks+0x318>
     a00:      	b	0xa58 <_llm_rows.packet_batch.blocks+0x3c0>
     a04:      	ldr	s5, [x9]
     a08:      	and	w11, w13, #0xff
     a0c:      	tbz	w11, #0x1, 0x9e8 <_llm_rows.packet_batch.blocks+0x350>
     a10:      	add	x14, x9, #0x4
     a14:      	ld1.s	{ v5 }[1], [x14]
     a18:      	tbz	w11, #0x2, 0x9ec <_llm_rows.packet_batch.blocks+0x354>
     a1c:      	add	x14, x9, #0x8
     a20:      	ld1.s	{ v5 }[2], [x14]
     a24:      	tbz	w11, #0x3, 0x9f0 <_llm_rows.packet_batch.blocks+0x358>
     a28:      	add	x14, x9, #0xc
     a2c:      	ld1.s	{ v5 }[3], [x14]
     a30:      	tbz	w11, #0x4, 0x9f4 <_llm_rows.packet_batch.blocks+0x35c>
     a34:      	add	x14, x9, #0x10
     a38:      	ld1.s	{ v6 }[0], [x14]
     a3c:      	tbz	w11, #0x5, 0x9f8 <_llm_rows.packet_batch.blocks+0x360>
     a40:      	add	x14, x9, #0x14
     a44:      	ld1.s	{ v6 }[1], [x14]
     a48:      	tbz	w11, #0x6, 0x9fc <_llm_rows.packet_batch.blocks+0x364>
     a4c:      	add	x14, x9, #0x18
     a50:      	ld1.s	{ v6 }[2], [x14]
     a54:      	tbz	w11, #0x7, 0x9b0 <_llm_rows.packet_batch.blocks+0x318>
     a58:      	add	x9, x9, #0x1c
     a5c:      	ld1.s	{ v6 }[3], [x9]
     a60:      	b	0x9b0 <_llm_rows.packet_batch.blocks+0x318>
     a64:      	mov	x8, #0x0                ; =0
     a68:      	add	x9, sp, #0x2, lsl #12   ; =0x2000
     a6c:      	add	x9, x9, #0x100
     a70:      	sshll2.2d	v6, v0, #0x0
     a74:      	sshll2.2d	v5, v1, #0x0
     a78:      	sshll.2d	v16, v0, #0x0
     a7c:      	dup.2d	v17, x8
     a80:      	sshll.2d	v18, v1, #0x0
     a84:      	ldr	q19, [x15]
     a88:      	orr.16b	v19, v17, v19
     a8c:      	ldr	q20, [x16]
     a90:      	orr.16b	v20, v17, v20
     a94:      	ldr	q21, [x17]
     a98:      	orr.16b	v21, v17, v21
     a9c:      	ldr	q22, [x0]
     aa0:      	orr.16b	v17, v17, v22
     aa4:      	ldp	q23, q22, [x9, #0x20]
     aa8:      	ldp	q25, q24, [x9]
     aac:      	bif.16b	v17, v25, v18
     ab0:      	bsl.16b	v16, v21, v23
     ab4:      	mov.16b	v18, v5
     ab8:      	bsl.16b	v18, v20, v24
     abc:      	bif.16b	v19, v22, v6
     ac0:      	stp	q16, q19, [x9, #0x20]
     ac4:      	stp	q17, q18, [x9], #0x40
     ac8:      	add	x8, x8, #0x8
     acc:      	cmp	x8, #0x300
     ad0:      	b.ne	0xa70 <_llm_rows.packet_batch.blocks+0x3d8>
     ad4:      	mov	x12, #0x0               ; =0
     ad8:      	sshll.2d	v27, v1, #0x0
     adc:      	sshll.2d	v26, v0, #0x0
     ae0:      	and.16b	v16, v0, v4
     ae4:      	and.16b	v4, v1, v4
     ae8:      	movi.4s	v19, #0x3, lsl #8
     aec:      	and.16b	v17, v0, v19
     af0:      	mvn.16b	v18, v0
     af4:      	sub.4s	v17, v17, v18
     af8:      	and.16b	v18, v1, v19
     afc:      	mvn.16b	v19, v1
     b00:      	sub.4s	v18, v18, v19
     b04:      	mov.s	w8, v18[1]
     b08:      	mov.s	w9, v4[1]
     b0c:      	udiv	w11, w9, w8
     b10:      	msub	w8, w11, w8, w9
     b14:      	mov.s	w9, v18[3]
     b18:      	mov.s	w11, v18[2]
     b1c:      	fmov	w13, s18
     b20:      	mov.s	w14, v4[3]
     b24:      	mov.s	w15, v4[2]
     b28:      	fmov	w16, s4
     b2c:      	udiv	w17, w16, w13
     b30:      	msub	w13, w17, w13, w16
     b34:      	udiv	w16, w14, w9
     b38:      	msub	w9, w16, w9, w14
     b3c:      	udiv	w14, w15, w11
     b40:      	msub	w11, w14, w11, w15
     b44:      	mov.s	w14, v17[1]
     b48:      	mov.s	w15, v16[1]
     b4c:      	udiv	w16, w15, w14
     b50:      	msub	w14, w16, w14, w15
     b54:      	mov.s	w15, v17[3]
     b58:      	mov.s	w16, v16[3]
     b5c:      	udiv	w17, w16, w15
     b60:      	msub	w15, w17, w15, w16
     b64:      	mov.s	w16, v17[2]
     b68:      	mov.s	w17, v16[2]
     b6c:      	udiv	w0, w17, w16
     b70:      	msub	w16, w0, w16, w17
     b74:      	fmov	w17, s17
     b78:      	fmov	w0, s16
     b7c:      	fmov	s4, w16
     b80:      	mov.s	v4[1], w15
     b84:      	udiv	w15, w0, w17
     b88:      	msub	w15, w15, w17, w0
     b8c:      	ushll.2d	v16, v4, #0x0
     b90:      	fmov	s4, w15
     b94:      	mov.s	v4[1], w14
     b98:      	ushll.2d	v17, v4, #0x0
     b9c:      	fmov	s4, w11
     ba0:      	mov.s	v4[1], w9
     ba4:      	fmov	s19, w13
     ba8:      	mov.s	v19[1], w8
     bac:      	ushll.2d	v18, v4, #0x0
     bb0:      	ushll.2d	v19, v19, #0x0
     bb4:      	ldr	q4, [sp, #0x30]
     bb8:      	and.16b	v20, v6, v4
     bbc:      	and.16b	v21, v5, v4
     bc0:      	and.16b	v22, v26, v4
     bc4:      	and.16b	v23, v27, v4
     bc8:      	adrp	x8, 0x0 <ltmp0>
     bcc:      	ldr	q4, [x8]
     bd0:      	and.16b	v24, v6, v4
     bd4:      	adrp	x8, 0x0 <ltmp0>
     bd8:      	ldr	q4, [x8]
     bdc:      	and.16b	v25, v5, v4
     be0:      	adrp	x8, 0x0 <ltmp0>
     be4:      	ldr	q4, [x8]
     be8:      	and.16b	v26, v26, v4
     bec:      	adrp	x8, 0x0 <ltmp0>
     bf0:      	ldr	q4, [x8]
     bf4:      	and.16b	v27, v27, v4
     bf8:      	ldp	q4, q5, [sp, #0xa0]
     bfc:      	cmhs.4s	v4, v4, v3
     c00:      	cmhs.4s	v3, v5, v3
     c04:      	uzp1.8h	v3, v3, v4
     c08:      	xtn.8b	v28, v3
     c0c:      	b	0xc1c <_llm_rows.packet_batch.blocks+0x584>
     c10:      	add	x12, x12, #0x1
     c14:      	cmp	x12, #0x60
     c18:      	b.eq	0xd1c <_llm_rows.packet_batch.blocks+0x684>
     c1c:      	dup.2d	v29, x12
     c20:      	fmov	w8, s2
     c24:      	add	x9, x1, x12, lsl #6
     c28:      	ldp	q4, q3, [x9, #0x20]
     c2c:      	ldp	q5, q6, [x9]
     c30:      	cmge.2d	v6, v18, v6
     c34:      	cmge.2d	v5, v19, v5
     c38:      	uzp1.4s	v5, v5, v6
     c3c:      	cmge.2d	v4, v17, v4
     c40:      	cmge.2d	v3, v16, v3
     c44:      	uzp1.4s	v3, v4, v3
     c48:      	uzp1.8h	v3, v5, v3
     c4c:      	xtn.8b	v3, v3
     c50:      	orr.8b	v5, v28, v3
     c54:      	add.2d	v3, v23, v27
     c58:      	add.2d	v4, v3, v29
     c5c:      	and.8b	v30, v5, v8
     c60:      	tbnz	w8, #0x0, 0xca0 <_llm_rows.packet_batch.blocks+0x608>
     c64:      	and	w8, w8, #0xff
     c68:      	tbnz	w8, #0x1, 0xcb0 <_llm_rows.packet_batch.blocks+0x618>
     c6c:      	add.2d	v4, v21, v25
     c70:      	add.2d	v5, v4, v29
     c74:      	tbnz	w8, #0x2, 0xcc4 <_llm_rows.packet_batch.blocks+0x62c>
     c78:      	tbnz	w8, #0x3, 0xcd0 <_llm_rows.packet_batch.blocks+0x638>
     c7c:      	add.2d	v5, v22, v26
     c80:      	add.2d	v6, v5, v29
     c84:      	tbnz	w8, #0x4, 0xce4 <_llm_rows.packet_batch.blocks+0x64c>
     c88:      	tbnz	w8, #0x5, 0xcf0 <_llm_rows.packet_batch.blocks+0x658>
     c8c:      	add.2d	v6, v20, v24
     c90:      	add.2d	v29, v6, v29
     c94:      	tbnz	w8, #0x6, 0xd04 <_llm_rows.packet_batch.blocks+0x66c>
     c98:      	tbz	w8, #0x7, 0xc10 <_llm_rows.packet_batch.blocks+0x578>
     c9c:      	b	0xd10 <_llm_rows.packet_batch.blocks+0x678>
     ca0:      	fmov	x9, d4
     ca4:      	str	b30, [x9]
     ca8:      	and	w8, w8, #0xff
     cac:      	tbz	w8, #0x1, 0xc6c <_llm_rows.packet_batch.blocks+0x5d4>
     cb0:      	mov.d	x9, v4[1]
     cb4:      	st1.b	{ v30 }[1], [x9]
     cb8:      	add.2d	v4, v21, v25
     cbc:      	add.2d	v5, v4, v29
     cc0:      	tbz	w8, #0x2, 0xc78 <_llm_rows.packet_batch.blocks+0x5e0>
     cc4:      	fmov	x9, d5
     cc8:      	st1.b	{ v30 }[2], [x9]
     ccc:      	tbz	w8, #0x3, 0xc7c <_llm_rows.packet_batch.blocks+0x5e4>
     cd0:      	mov.d	x9, v5[1]
     cd4:      	st1.b	{ v30 }[3], [x9]
     cd8:      	add.2d	v5, v22, v26
     cdc:      	add.2d	v6, v5, v29
     ce0:      	tbz	w8, #0x4, 0xc88 <_llm_rows.packet_batch.blocks+0x5f0>
     ce4:      	fmov	x9, d6
     ce8:      	st1.b	{ v30 }[4], [x9]
     cec:      	tbz	w8, #0x5, 0xc8c <_llm_rows.packet_batch.blocks+0x5f4>
     cf0:      	mov.d	x9, v6[1]
     cf4:      	st1.b	{ v30 }[5], [x9]
     cf8:      	add.2d	v6, v20, v24
     cfc:      	add.2d	v29, v6, v29
     d00:      	tbz	w8, #0x6, 0xc98 <_llm_rows.packet_batch.blocks+0x600>
     d04:      	fmov	x9, d29
     d08:      	st1.b	{ v30 }[6], [x9]
     d0c:      	tbz	w8, #0x7, 0xc10 <_llm_rows.packet_batch.blocks+0x578>
     d10:      	mov.d	x8, v29[1]
     d14:      	st1.b	{ v30 }[7], [x8]
     d18:      	b	0xc10 <_llm_rows.packet_batch.blocks+0x578>
     d1c:      	mov	x8, #0x0                ; =0
     d20:      	b	0xd74 <_llm_rows.packet_batch.blocks+0x6dc>
     d24:      	cmeq.8b	v16, v16, #0
     d28:      	sshll.8h	v16, v16, #0x0
     d2c:      	sshll2.4s	v17, v16, #0x0
     d30:      	sshll.4s	v16, v16, #0x0
     d34:      	lsl	x9, x8, #5
     d38:      	add	x11, x25, x9
     d3c:      	ldp	q18, q19, [x11]
     d40:      	and.16b	v19, v0, v19
     d44:      	dup.4s	v20, w2
     d48:      	and.16b	v18, v1, v18
     d4c:      	bsl.16b	v16, v20, v18
     d50:      	bsl.16b	v17, v20, v19
     d54:      	add	x9, x24, x9
     d58:      	ldp	q18, q19, [x9]
     d5c:      	bif.16b	v17, v19, v0
     d60:      	bif.16b	v16, v18, v1
     d64:      	stp	q16, q17, [x9]
     d68:      	add	x8, x8, #0x1
     d6c:      	cmp	x8, #0x60
     d70:      	b.eq	0xe24 <_llm_rows.packet_batch.blocks+0x78c>
     d74:      	fmov	w9, s2
     d78:      	dup.2d	v17, x8
     d7c:      	add.2d	v18, v3, v17
     d80:      	tbz	w9, #0x0, 0xd98 <_llm_rows.packet_batch.blocks+0x700>
     d84:      	fmov	x11, d18
     d88:      	ldr	b16, [x11]
     d8c:      	and	w9, w9, #0xff
     d90:      	tbnz	w9, #0x1, 0xda4 <_llm_rows.packet_batch.blocks+0x70c>
     d94:      	b	0xdac <_llm_rows.packet_batch.blocks+0x714>
     d98:      	movi.2d	v16, #0000000000000000
     d9c:      	and	w9, w9, #0xff
     da0:      	tbz	w9, #0x1, 0xdac <_llm_rows.packet_batch.blocks+0x714>
     da4:      	mov.d	x11, v18[1]
     da8:      	ld1.b	{ v16 }[1], [x11]
     dac:      	add.2d	v18, v4, v17
     db0:      	tbnz	w9, #0x2, 0xdd4 <_llm_rows.packet_batch.blocks+0x73c>
     db4:      	tbnz	w9, #0x3, 0xde0 <_llm_rows.packet_batch.blocks+0x748>
     db8:      	add.2d	v18, v5, v17
     dbc:      	tbnz	w9, #0x4, 0xdf0 <_llm_rows.packet_batch.blocks+0x758>
     dc0:      	tbnz	w9, #0x5, 0xdfc <_llm_rows.packet_batch.blocks+0x764>
     dc4:      	add.2d	v17, v6, v17
     dc8:      	tbnz	w9, #0x6, 0xe0c <_llm_rows.packet_batch.blocks+0x774>
     dcc:      	tbz	w9, #0x7, 0xd24 <_llm_rows.packet_batch.blocks+0x68c>
     dd0:      	b	0xe18 <_llm_rows.packet_batch.blocks+0x780>
     dd4:      	fmov	x11, d18
     dd8:      	ld1.b	{ v16 }[2], [x11]
     ddc:      	tbz	w9, #0x3, 0xdb8 <_llm_rows.packet_batch.blocks+0x720>
     de0:      	mov.d	x11, v18[1]
     de4:      	ld1.b	{ v16 }[3], [x11]
     de8:      	add.2d	v18, v5, v17
     dec:      	tbz	w9, #0x4, 0xdc0 <_llm_rows.packet_batch.blocks+0x728>
     df0:      	fmov	x11, d18
     df4:      	ld1.b	{ v16 }[4], [x11]
     df8:      	tbz	w9, #0x5, 0xdc4 <_llm_rows.packet_batch.blocks+0x72c>
     dfc:      	mov.d	x11, v18[1]
     e00:      	ld1.b	{ v16 }[5], [x11]
     e04:      	add.2d	v17, v6, v17
     e08:      	tbz	w9, #0x6, 0xdcc <_llm_rows.packet_batch.blocks+0x734>
     e0c:      	fmov	x11, d17
     e10:      	ld1.b	{ v16 }[6], [x11]
     e14:      	tbz	w9, #0x7, 0xd24 <_llm_rows.packet_batch.blocks+0x68c>
     e18:      	mov.d	x9, v17[1]
     e1c:      	ld1.b	{ v16 }[7], [x9]
     e20:      	b	0xd24 <_llm_rows.packet_batch.blocks+0x68c>
     e24:      	str	w28, [sp, #0x64]
     e28:      	str	w22, [sp, #0x74]
     e2c:      	ldr	q16, [x23, #0x1060]
     e30:      	ldr	q17, [x23, #0x1070]
     e34:      	ldr	q18, [x23, #0x1080]
     e38:      	ldr	q19, [x23, #0x1090]
     e3c:      	ldr	q20, [x23, #0x10a0]
     e40:      	ldr	q23, [x23, #0x10b0]
     e44:      	ldr	q24, [x23, #0x10c0]
     e48:      	and.16b	v17, v0, v17
     e4c:      	and.16b	v16, v1, v16
     e50:      	ldr	q25, [x23, #0x10d0]
     e54:      	and.16b	v22, v0, v19
     e58:      	and.16b	v21, v1, v18
     e5c:      	and.16b	v18, v0, v23
     e60:      	and.16b	v23, v1, v20
     e64:      	and.16b	v20, v0, v25
     e68:      	and.16b	v19, v1, v24
     e6c:      	ldr	x8, [sp, #0x28]
     e70:      	mov	w9, #0x4                ; =4
     e74:      	ldp	q24, q25, [x8, #-0x60]
     e78:      	and.16b	v25, v0, v25
     e7c:      	and.16b	v24, v1, v24
     e80:      	fmaxnm.4s	v24, v16, v24
     e84:      	fmaxnm.4s	v25, v17, v25
     e88:      	ldp	q26, q27, [x8, #-0x40]
     e8c:      	and.16b	v27, v0, v27
     e90:      	and.16b	v26, v1, v26
     e94:      	fmaxnm.4s	v26, v21, v26
     e98:      	fmaxnm.4s	v27, v22, v27
     e9c:      	ldp	q28, q29, [x8, #-0x20]
     ea0:      	and.16b	v29, v0, v29
     ea4:      	and.16b	v28, v1, v28
     ea8:      	fmaxnm.4s	v28, v23, v28
     eac:      	fmaxnm.4s	v29, v18, v29
     eb0:      	ldp	q30, q31, [x8], #0x80
     eb4:      	and.16b	v31, v0, v31
     eb8:      	and.16b	v30, v1, v30
     ebc:      	fmaxnm.4s	v30, v19, v30
     ec0:      	fmaxnm.4s	v31, v20, v31
     ec4:      	bit.16b	v17, v25, v0
     ec8:      	bit.16b	v16, v24, v1
     ecc:      	bit.16b	v22, v27, v0
     ed0:      	bit.16b	v21, v26, v1
     ed4:      	bit.16b	v18, v29, v0
     ed8:      	bit.16b	v23, v28, v1
     edc:      	bit.16b	v20, v31, v0
     ee0:      	bit.16b	v19, v30, v1
     ee4:      	cmp	x9, #0x5c
     ee8:      	add	x9, x9, #0x4
     eec:      	b.lo	0xe74 <_llm_rows.packet_batch.blocks+0x7dc>
     ef0:      	mov	x30, #0x0               ; =0
     ef4:      	xtn.8b	v7, v7
     ef8:      	fmaxnm.4s	v17, v17, v22
     efc:      	fmaxnm.4s	v16, v16, v21
     f00:      	fmaxnm.4s	v21, v16, v23
     f04:      	fmaxnm.4s	v16, v17, v18
     f08:      	fmaxnm.4s	v16, v16, v20
     f0c:      	fmaxnm.4s	v17, v21, v19
     f10:      	umov.b	w22, v7[1]
     f14:      	mov	s18, v17[1]
     f18:      	ldr	x25, [sp, #0xc8]
     f1c:      	tst	w25, w22
     f20:      	fcsel	s18, s18, s9, ne
     f24:      	mvn	w8, w22
     f28:      	add	x9, sp, #0x328
     f2c:      	bfxil	x9, x8, #0, #1
     f30:      	str	d7, [x23, #0x188]
     f34:      	ldrb	w9, [x9]
     f38:      	add	x11, sp, #0x5d0
     f3c:      	bfi	x11, x8, #2, #1
     f40:      	str	q17, [x23, #0x430]
     f44:      	str	q16, [x23, #0x440]
     f48:      	ldr	s19, [x11]
     f4c:      	and	w8, w22, #0x1
     f50:      	str	w8, [sp, #0x60]
     f54:      	tst	w8, w9
     f58:      	umov.b	w4, v7[2]
     f5c:      	umov.b	w8, v7[3]
     f60:      	str	x8, [sp, #0x40]
     f64:      	fcsel	s19, s19, s9, ne
     f68:      	ands	w15, w8, #0x1
     f6c:      	mov	w9, #0x1                ; =1
     f70:      	cinc	w8, w9, ne
     f74:      	cinc	w2, w9, eq
     f78:      	mov	w16, #0x4               ; =4
     f7c:      	mov	w13, #0x7               ; =7
     f80:      	csel	w9, w13, w16, ne
     f84:      	str	x9, [sp, #0x78]
     f88:      	ands	w9, w4, #0x1
     f8c:      	stp	w15, w9, [sp, #0x58]
     f90:      	mov	w10, #0x3               ; =3
     f94:      	csinc	w11, w10, wzr, ne
     f98:      	add	x10, sp, #0x328
     f9c:      	orr	x12, x10, x11
     fa0:      	ldrb	w12, [x12]
     fa4:      	add	x14, sp, #0x5b0
     fa8:      	orr	x11, x14, x11, lsl #2
     fac:      	str	q17, [x23, #0x410]
     fb0:      	str	q16, [x23, #0x420]
     fb4:      	ldr	s20, [x11]
     fb8:      	mov	w24, #0x2               ; =2
     fbc:      	csel	w0, wzr, w24, ne
     fc0:      	mov	w28, #0x6               ; =6
     fc4:      	csel	w11, w28, w16, ne
     fc8:      	str	x11, [sp, #0x68]
     fcc:      	tst	w9, w12
     fd0:      	add	x11, sp, #0x328
     fd4:      	bfxil	x11, x8, #0, #3
     fd8:      	ldrb	w11, [x11]
     fdc:      	add	x12, sp, #0x590
     fe0:      	orr	x8, x12, x8, lsl #2
     fe4:      	stp	q17, q16, [x23, #0x3f0]
     fe8:      	ldr	s21, [x8]
     fec:      	fcsel	s20, s20, s9, ne
     ff0:      	umov.b	w1, v7[4]
     ff4:      	umov.b	w8, v7[5]
     ff8:      	umov.b	w9, v7[6]
     ffc:      	tst	w15, w11
    1000:      	umov.b	w26, v7[7]
    1004:      	fcsel	s21, s21, s9, ne
    1008:      	ands	w3, w26, #0x1
    100c:      	csinc	w21, w28, wzr, ne
    1010:      	mov	w12, #0x5               ; =5
    1014:      	csel	w6, w12, w24, ne
    1018:      	ands	w11, w9, #0x1
    101c:      	csinc	w27, w13, wzr, ne
    1020:      	mov	w14, #0x4               ; =4
    1024:      	csel	w7, w14, w24, ne
    1028:      	ands	w15, w8, #0x1
    102c:      	csinc	w16, w14, wzr, ne
    1030:      	csel	w17, w13, w24, ne
    1034:      	ands	w14, w1, #0x1
    1038:      	csinc	w12, w12, wzr, ne
    103c:      	orr	x13, x10, x12
    1040:      	ldrb	w13, [x13]
    1044:      	stp	q17, q16, [x23, #0x3d0]
    1048:      	add	x5, sp, #0x570
    104c:      	ldr	s22, [x5, w12, uxtw #2]
    1050:      	csel	w12, w28, w24, ne
    1054:      	tst	w14, w13
    1058:      	orr	x13, x10, x16
    105c:      	ldrb	w13, [x13]
    1060:      	stp	q17, q16, [x23, #0x3b0]
    1064:      	add	x5, sp, #0x550
    1068:      	ldr	s23, [x5, w16, uxtw #2]
    106c:      	orr	x16, x10, x27
    1070:      	ldrb	w16, [x16]
    1074:      	stp	q17, q16, [x23, #0x390]
    1078:      	add	x5, sp, #0x530
    107c:      	ldr	s24, [x5, w27, uxtw #2]
    1080:      	mov	x27, x8
    1084:      	fcsel	s22, s22, s9, ne
    1088:      	tst	w15, w13
    108c:      	fcsel	s23, s23, s9, ne
    1090:      	tst	w11, w16
    1094:      	orr	x13, x10, x21
    1098:      	ldrb	w13, [x13]
    109c:      	stp	q17, q16, [x23, #0x370]
    10a0:      	add	x16, sp, #0x510
    10a4:      	ldr	s25, [x16, w21, uxtw #2]
    10a8:      	mov	x21, x9
    10ac:      	fcsel	s24, s24, s9, ne
    10b0:      	tst	w3, w13
    10b4:      	fcsel	s25, s25, s9, ne
    10b8:      	mov.s	v18[1], v19[0]
    10bc:      	mov.s	v18[2], v20[0]
    10c0:      	mov.s	v18[3], v21[0]
    10c4:      	mov.s	v22[1], v23[0]
    10c8:      	mov.s	v22[2], v24[0]
    10cc:      	mov.s	v22[3], v25[0]
    10d0:      	fmaxnm.4s	v16, v16, v22
    10d4:      	fmaxnm.4s	v17, v17, v18
    10d8:      	mov	s18, v17[2]
    10dc:      	mov	w13, #0x2               ; =2
    10e0:      	bfxil	w13, w22, #0, #1
    10e4:      	orr	x16, x10, x13
    10e8:      	ldrb	w16, [x16]
    10ec:      	add	x5, sp, #0x4f0
    10f0:      	orr	x13, x5, x13, lsl #2
    10f4:      	stp	q17, q16, [x23, #0x350]
    10f8:      	ldr	s19, [x13]
    10fc:      	tst	w25, w4
    1100:      	fcsel	s18, s18, s9, ne
    1104:      	ldr	w5, [sp, #0x60]
    1108:      	tst	w5, w16
    110c:      	lsr	x13, x0, #1
    1110:      	add	x16, sp, #0x4d0
    1114:      	bfi	x16, x13, #3, #1
    1118:      	orr	x13, x10, x0
    111c:      	ldrb	w13, [x13]
    1120:      	stp	q17, q16, [x23, #0x330]
    1124:      	ldr	s20, [x16]
    1128:      	fcsel	s19, s19, s9, ne
    112c:      	ldr	w0, [sp, #0x5c]
    1130:      	tst	w0, w13
    1134:      	add	x13, sp, #0x328
    1138:      	bfxil	x13, x2, #0, #3
    113c:      	ldrb	w13, [x13]
    1140:      	add	x16, sp, #0x4b0
    1144:      	orr	x9, x16, x2, lsl #2
    1148:      	stp	q17, q16, [x23, #0x310]
    114c:      	ldr	s21, [x9]
    1150:      	fcsel	s20, s20, s9, ne
    1154:      	ldr	w16, [sp, #0x58]
    1158:      	tst	w16, w13
    115c:      	fcsel	s21, s21, s9, ne
    1160:      	orr	x9, x10, x12
    1164:      	ldrb	w9, [x9]
    1168:      	tst	w14, w9
    116c:      	stp	q17, q16, [x23, #0x2f0]
    1170:      	add	x9, sp, #0x490
    1174:      	ldr	s22, [x9, w12, uxtw #2]
    1178:      	orr	x9, x10, x17
    117c:      	ldrb	w9, [x9]
    1180:      	stp	q17, q16, [x23, #0x2d0]
    1184:      	add	x12, sp, #0x470
    1188:      	ldr	s23, [x12, w17, uxtw #2]
    118c:      	fcsel	s22, s22, s9, ne
    1190:      	tst	w15, w9
    1194:      	fcsel	s23, s23, s9, ne
    1198:      	orr	x9, x10, x7
    119c:      	ldrb	w9, [x9]
    11a0:      	tst	w11, w9
    11a4:      	stp	q17, q16, [x23, #0x2b0]
    11a8:      	add	x9, sp, #0x450
    11ac:      	ldr	s24, [x9, w7, uxtw #2]
    11b0:      	fcsel	s24, s24, s9, ne
    11b4:      	orr	x9, x10, x6
    11b8:      	ldrb	w9, [x9]
    11bc:      	stp	q17, q16, [x23, #0x290]
    11c0:      	add	x11, sp, #0x430
    11c4:      	ldr	s25, [x11, w6, uxtw #2]
    11c8:      	tst	w3, w9
    11cc:      	fcsel	s25, s25, s9, ne
    11d0:      	mov.s	v22[1], v23[0]
    11d4:      	mov.s	v22[2], v24[0]
    11d8:      	mov.s	v22[3], v25[0]
    11dc:      	mov.s	v18[1], v19[0]
    11e0:      	mov.s	v18[2], v20[0]
    11e4:      	mov.s	v18[3], v21[0]
    11e8:      	fmaxnm.4s	v17, v17, v18
    11ec:      	fmaxnm.4s	v16, v16, v22
    11f0:      	mov	w8, #0x4                ; =4
    11f4:      	bfxil	w8, w22, #0, #1
    11f8:      	orr	x9, x10, x8
    11fc:      	ldrb	w9, [x9]
    1200:      	stp	q17, q16, [x23, #0x270]
    1204:      	add	x11, sp, #0x410
    1208:      	ldr	s18, [x11, w8, uxtw #2]
    120c:      	mov	x11, x4
    1210:      	tst	w25, w1
    1214:      	fcsel	s19, s16, s9, ne
    1218:      	tst	w5, w9
    121c:      	fcsel	s18, s18, s9, ne
    1220:      	ldr	x12, [sp, #0x68]
    1224:      	orr	x8, x10, x12
    1228:      	ldrb	w8, [x8]
    122c:      	stp	q17, q16, [x23, #0x250]
    1230:      	add	x9, sp, #0x3f0
    1234:      	ldr	s20, [x9, w12, uxtw #2]
    1238:      	tst	w0, w8
    123c:      	fcsel	s20, s20, s9, ne
    1240:      	ldr	x12, [sp, #0x78]
    1244:      	orr	x8, x10, x12
    1248:      	ldrb	w8, [x8]
    124c:      	stp	q17, q16, [x23, #0x230]
    1250:      	add	x9, sp, #0x3d0
    1254:      	ldr	s16, [x9, w12, uxtw #2]
    1258:      	tst	w16, w8
    125c:      	fcsel	s16, s16, s9, ne
    1260:      	str	w22, [sp, #0x78]
    1264:      	ands	w3, w25, w22
    1268:      	mov.s	v19[1], v18[0]
    126c:      	mov.s	v19[2], v20[0]
    1270:      	mov.s	v19[3], v16[0]
    1274:      	fmaxnm.4s	v16, v17, v19
    1278:      	fcsel	s17, s16, s9, ne
    127c:      	ands	w8, w25, w4
    1280:      	str	w8, [sp, #0x5c]
    1284:      	fcsel	s18, s16, s9, ne
    1288:      	str	w1, [sp, #0x68]
    128c:      	ands	w8, w25, w1
    1290:      	str	w8, [sp, #0x60]
    1294:      	fcsel	s19, s16, s9, ne
    1298:      	cmp	w25, #0x0
    129c:      	fcsel	s20, s16, s9, ne
    12a0:      	ldr	x8, [sp, #0x40]
    12a4:      	mov	x6, x8
    12a8:      	ands	w8, w8, w25
    12ac:      	str	w8, [sp, #0x4c]
    12b0:      	fcsel	s21, s16, s9, ne
    12b4:      	ands	w8, w27, w25
    12b8:      	str	w8, [sp, #0x58]
    12bc:      	fcsel	s22, s16, s9, ne
    12c0:      	ands	w8, w21, w25
    12c4:      	str	w8, [sp, #0x54]
    12c8:      	fcsel	s23, s16, s9, ne
    12cc:      	ands	w8, w26, w25
    12d0:      	str	w8, [sp, #0x50]
    12d4:      	fcsel	s16, s16, s9, ne
    12d8:      	mov.s	v20[1], v17[0]
    12dc:      	mov.s	v20[2], v18[0]
    12e0:      	mov.s	v20[3], v21[0]
    12e4:      	mov.s	v19[1], v22[0]
    12e8:      	mov.s	v19[2], v23[0]
    12ec:      	mov.s	v19[3], v16[0]
    12f0:      	ldr	w8, [sp, #0x80]
    12f4:      	rbit	w8, w8
    12f8:      	clz	w8, w8
    12fc:      	stp	q20, q19, [x23, #0x190]
    1300:      	str	x8, [sp, #0x80]
    1304:      	and	x8, x8, #0x7
    1308:      	add	x9, sp, #0x330
    130c:      	ldr	s16, [x9, x8, lsl #2]
    1310:      	mov	w8, #-0x800000          ; =-8388608
    1314:      	fmov	s17, w8
    1318:      	fmaxnm	s16, s16, s17
    131c:      	dup.4s	v16, v16[0]
    1320:      	add	x24, sp, #0x1, lsl #12  ; =0x1000
    1324:      	add	x24, x24, #0x200
    1328:      	add	x10, sp, #0x600
    132c:      	mov	w12, #-0x3d300000       ; =-1026555904
    1330:      	mov	w13, #0x42c80000        ; =1120403456
    1334:      	mov	w14, #0xaa3b            ; =43579
    1338:      	movk	w14, #0x3fb8, lsl #16
    133c:      	mov	w15, #0x7200            ; =29184
    1340:      	movk	w15, #0xbf31, lsl #16
    1344:      	mov	w16, #0xbe8e            ; =48782
    1348:      	movk	w16, #0xb5bf, lsl #16
    134c:      	mov	w17, #0x2bda            ; =11226
    1350:      	movk	w17, #0x3950, lsl #16
    1354:      	mov	w0, #0x96c9             ; =38601
    1358:      	movk	w0, #0x3ab6, lsl #16
    135c:      	mov	w2, #0x88a6             ; =34982
    1360:      	movk	w2, #0x3c08, lsl #16
    1364:      	mov	w4, #0xaa7a             ; =43642
    1368:      	movk	w4, #0x3d2a, lsl #16
    136c:      	mov	w5, #0xaaab             ; =43691
    1370:      	movk	w5, #0x3e2a, lsl #16
    1374:      	ldr	w22, [sp, #0x74]
    1378:      	ldr	w28, [sp, #0x64]
    137c:      	b	0x155c <_llm_rows.packet_batch.blocks+0xec4>
    1380:      	cmeq.8b	v17, v17, #0
    1384:      	sshll.8h	v18, v17, #0x0
    1388:      	sshll2.4s	v17, v18, #0x0
    138c:      	sshll.4s	v18, v18, #0x0
    1390:      	lsl	x8, x30, #5
    1394:      	add	x9, x24, x8
    1398:      	ldp	q20, q19, [x9]
    139c:      	fsub.4s	v20, v20, v16
    13a0:      	fsub.4s	v19, v19, v16
    13a4:      	and.16b	v19, v0, v19
    13a8:      	and.16b	v20, v1, v20
    13ac:      	dup.4s	v21, w12
    13b0:      	fcmge.4s	v23, v20, v21
    13b4:      	fcmge.4s	v24, v19, v21
    13b8:      	dup.4s	v22, w13
    13bc:      	fcmge.4s	v25, v22, v20
    13c0:      	fcmge.4s	v26, v22, v19
    13c4:      	and.16b	v24, v24, v26
    13c8:      	and.16b	v23, v23, v25
    13cc:      	and.16b	v23, v23, v20
    13d0:      	and.16b	v24, v24, v19
    13d4:      	dup.4s	v25, w14
    13d8:      	fmul.4s	v26, v24, v25
    13dc:      	fmul.4s	v25, v23, v25
    13e0:      	mov.16b	v27, v11
    13e4:      	bsl.16b	v27, v10, v25
    13e8:      	mov.16b	v28, v11
    13ec:      	bsl.16b	v28, v10, v26
    13f0:      	fadd.4s	v26, v26, v28
    13f4:      	fadd.4s	v25, v25, v27
    13f8:      	fsub.4s	v25, v25, v27
    13fc:      	fsub.4s	v26, v26, v28
    1400:      	fcvtzs.4s	v26, v26
    1404:      	fcvtzs.4s	v25, v25
    1408:      	scvtf.4s	v27, v25
    140c:      	scvtf.4s	v28, v26
    1410:      	dup.4s	v29, w15
    1414:      	fmul.4s	v30, v28, v29
    1418:      	fmul.4s	v29, v27, v29
    141c:      	fadd.4s	v23, v23, v29
    1420:      	fadd.4s	v24, v24, v30
    1424:      	dup.4s	v29, w16
    1428:      	fmul.4s	v27, v27, v29
    142c:      	fmul.4s	v28, v28, v29
    1430:      	fadd.4s	v24, v24, v28
    1434:      	fadd.4s	v23, v23, v27
    1438:      	dup.4s	v27, w17
    143c:      	fmul.4s	v28, v23, v27
    1440:      	fmul.4s	v27, v24, v27
    1444:      	dup.4s	v29, w0
    1448:      	fadd.4s	v27, v27, v29
    144c:      	fadd.4s	v28, v28, v29
    1450:      	fmul.4s	v28, v23, v28
    1454:      	fmul.4s	v27, v24, v27
    1458:      	dup.4s	v29, w2
    145c:      	fadd.4s	v27, v27, v29
    1460:      	fadd.4s	v28, v28, v29
    1464:      	fmul.4s	v28, v23, v28
    1468:      	fmul.4s	v27, v24, v27
    146c:      	dup.4s	v29, w4
    1470:      	fadd.4s	v27, v27, v29
    1474:      	fadd.4s	v28, v28, v29
    1478:      	fmul.4s	v28, v23, v28
    147c:      	fmul.4s	v27, v24, v27
    1480:      	dup.4s	v29, w5
    1484:      	fadd.4s	v27, v27, v29
    1488:      	fadd.4s	v28, v28, v29
    148c:      	fmul.4s	v28, v23, v28
    1490:      	fmul.4s	v27, v24, v27
    1494:      	fadd.4s	v27, v27, v12
    1498:      	fadd.4s	v28, v28, v12
    149c:      	fmul.4s	v29, v24, v24
    14a0:      	fmul.4s	v30, v23, v23
    14a4:      	fmul.4s	v28, v30, v28
    14a8:      	fmul.4s	v27, v29, v27
    14ac:      	fadd.4s	v24, v24, v27
    14b0:      	fadd.4s	v23, v23, v28
    14b4:      	fmov.4s	v27, #1.00000000
    14b8:      	fadd.4s	v23, v23, v27
    14bc:      	fadd.4s	v24, v24, v27
    14c0:      	sshr.4s	v28, v25, #0x1
    14c4:      	sshr.4s	v29, v26, #0x1
    14c8:      	shl.4s	v30, v29, #0x17
    14cc:      	shl.4s	v31, v28, #0x17
    14d0:      	add.4s	v31, v31, v27
    14d4:      	add.4s	v30, v30, v27
    14d8:      	fmul.4s	v24, v24, v30
    14dc:      	fmul.4s	v23, v23, v31
    14e0:      	sub.4s	v26, v26, v29
    14e4:      	sub.4s	v25, v25, v28
    14e8:      	shl.4s	v25, v25, #0x17
    14ec:      	shl.4s	v26, v26, #0x17
    14f0:      	add.4s	v26, v26, v27
    14f4:      	add.4s	v25, v25, v27
    14f8:      	fmul.4s	v23, v23, v25
    14fc:      	fmul.4s	v24, v24, v26
    1500:      	fcmgt.4s	v25, v21, v19
    1504:      	bic.16b	v24, v24, v25
    1508:      	fcmgt.4s	v21, v21, v20
    150c:      	bic.16b	v21, v23, v21
    1510:      	fcmgt.4s	v23, v19, v22
    1514:      	fcmgt.4s	v22, v20, v22
    1518:      	bit.16b	v21, v13, v22
    151c:      	mov.16b	v22, v23
    1520:      	bsl.16b	v22, v13, v24
    1524:      	fcmeq.4s	v20, v20, v20
    1528:      	fcmeq.4s	v19, v19, v19
    152c:      	bsl.16b	v19, v22, v14
    1530:      	bsl.16b	v20, v21, v14
    1534:      	bic.16b	v18, v20, v18
    1538:      	bic.16b	v17, v19, v17
    153c:      	add	x8, x10, x8
    1540:      	ldp	q19, q20, [x8]
    1544:      	bif.16b	v17, v20, v0
    1548:      	bif.16b	v18, v19, v1
    154c:      	stp	q18, q17, [x8]
    1550:      	add	x30, x30, #0x1
    1554:      	cmp	x30, #0x60
    1558:      	b.eq	0x160c <_llm_rows.packet_batch.blocks+0xf74>
    155c:      	fmov	w8, s2
    1560:      	dup.2d	v18, x30
    1564:      	add.2d	v19, v3, v18
    1568:      	tbz	w8, #0x0, 0x1580 <_llm_rows.packet_batch.blocks+0xee8>
    156c:      	fmov	x9, d19
    1570:      	ldr	b17, [x9]
    1574:      	and	w8, w8, #0xff
    1578:      	tbnz	w8, #0x1, 0x158c <_llm_rows.packet_batch.blocks+0xef4>
    157c:      	b	0x1594 <_llm_rows.packet_batch.blocks+0xefc>
    1580:      	movi.2d	v17, #0000000000000000
    1584:      	and	w8, w8, #0xff
    1588:      	tbz	w8, #0x1, 0x1594 <_llm_rows.packet_batch.blocks+0xefc>
    158c:      	mov.d	x9, v19[1]
    1590:      	ld1.b	{ v17 }[1], [x9]
    1594:      	add.2d	v19, v4, v18
    1598:      	tbnz	w8, #0x2, 0x15bc <_llm_rows.packet_batch.blocks+0xf24>
    159c:      	tbnz	w8, #0x3, 0x15c8 <_llm_rows.packet_batch.blocks+0xf30>
    15a0:      	add.2d	v19, v5, v18
    15a4:      	tbnz	w8, #0x4, 0x15d8 <_llm_rows.packet_batch.blocks+0xf40>
    15a8:      	tbnz	w8, #0x5, 0x15e4 <_llm_rows.packet_batch.blocks+0xf4c>
    15ac:      	add.2d	v18, v6, v18
    15b0:      	tbnz	w8, #0x6, 0x15f4 <_llm_rows.packet_batch.blocks+0xf5c>
    15b4:      	tbz	w8, #0x7, 0x1380 <_llm_rows.packet_batch.blocks+0xce8>
    15b8:      	b	0x1600 <_llm_rows.packet_batch.blocks+0xf68>
    15bc:      	fmov	x9, d19
    15c0:      	ld1.b	{ v17 }[2], [x9]
    15c4:      	tbz	w8, #0x3, 0x15a0 <_llm_rows.packet_batch.blocks+0xf08>
    15c8:      	mov.d	x9, v19[1]
    15cc:      	ld1.b	{ v17 }[3], [x9]
    15d0:      	add.2d	v19, v5, v18
    15d4:      	tbz	w8, #0x4, 0x15a8 <_llm_rows.packet_batch.blocks+0xf10>
    15d8:      	fmov	x9, d19
    15dc:      	ld1.b	{ v17 }[4], [x9]
    15e0:      	tbz	w8, #0x5, 0x15ac <_llm_rows.packet_batch.blocks+0xf14>
    15e4:      	mov.d	x9, v19[1]
    15e8:      	ld1.b	{ v17 }[5], [x9]
    15ec:      	add.2d	v18, v6, v18
    15f0:      	tbz	w8, #0x6, 0x15b4 <_llm_rows.packet_batch.blocks+0xf1c>
    15f4:      	fmov	x9, d18
    15f8:      	ld1.b	{ v17 }[6], [x9]
    15fc:      	tbz	w8, #0x7, 0x1380 <_llm_rows.packet_batch.blocks+0xce8>
    1600:      	mov.d	x8, v18[1]
    1604:      	ld1.b	{ v17 }[7], [x8]
    1608:      	b	0x1380 <_llm_rows.packet_batch.blocks+0xce8>
    160c:      	ldr	q3, [x23, #0x460]
    1610:      	ldr	q4, [x23, #0x470]
    1614:      	ldr	q5, [x23, #0x480]
    1618:      	ldr	q6, [x23, #0x490]
    161c:      	ldr	q16, [x23, #0x4a0]
    1620:      	ldr	q19, [x23, #0x4b0]
    1624:      	ldr	q20, [x23, #0x4c0]
    1628:      	and.16b	v4, v0, v4
    162c:      	and.16b	v3, v1, v3
    1630:      	ldr	q21, [x23, #0x4d0]
    1634:      	and.16b	v18, v0, v6
    1638:      	and.16b	v17, v1, v5
    163c:      	and.16b	v5, v0, v19
    1640:      	and.16b	v19, v1, v16
    1644:      	and.16b	v16, v0, v21
    1648:      	and.16b	v6, v1, v20
    164c:      	ldr	x8, [sp, #0x20]
    1650:      	mov	w9, #0x4                ; =4
    1654:      	ldp	q21, q20, [x8, #-0x60]
    1658:      	fadd.4s	v21, v3, v21
    165c:      	fadd.4s	v20, v4, v20
    1660:      	ldp	q23, q22, [x8, #-0x40]
    1664:      	fadd.4s	v23, v17, v23
    1668:      	fadd.4s	v22, v18, v22
    166c:      	ldp	q25, q24, [x8, #-0x20]
    1670:      	fadd.4s	v25, v19, v25
    1674:      	fadd.4s	v24, v5, v24
    1678:      	ldp	q27, q26, [x8], #0x80
    167c:      	fadd.4s	v27, v6, v27
    1680:      	fadd.4s	v26, v16, v26
    1684:      	bit.16b	v4, v20, v0
    1688:      	bit.16b	v3, v21, v1
    168c:      	bit.16b	v18, v22, v0
    1690:      	bit.16b	v17, v23, v1
    1694:      	bit.16b	v5, v24, v0
    1698:      	bit.16b	v19, v25, v1
    169c:      	bit.16b	v16, v26, v0
    16a0:      	bit.16b	v6, v27, v1
    16a4:      	cmp	x9, #0x5c
    16a8:      	add	x9, x9, #0x4
    16ac:      	b.lo	0x1654 <_llm_rows.packet_batch.blocks+0xfbc>
    16b0:      	mov	x30, #0x0               ; =0
    16b4:      	fadd.4s	v4, v4, v18
    16b8:      	fadd.4s	v3, v3, v17
    16bc:      	fadd.4s	v17, v3, v19
    16c0:      	fadd.4s	v3, v4, v5
    16c4:      	fadd.4s	v3, v3, v16
    16c8:      	fadd.4s	v4, v17, v6
    16cc:      	add	x1, sp, #0x118
    16d0:      	ldr	x25, [sp, #0xc8]
    16d4:      	orr	x8, x1, x25
    16d8:      	str	d7, [sp, #0x118]
    16dc:      	ldrb	w8, [x8]
    16e0:      	add	x9, sp, #0x300
    16e4:      	orr	x9, x9, x25, lsl #2
    16e8:      	stp	q4, q3, [x23, #0x160]
    16ec:      	ldr	s5, [x9]
    16f0:      	tst	w25, w8
    16f4:      	fcsel	s5, s5, s9, ne
    16f8:      	tst	w3, #0x1
    16fc:      	fcsel	s6, s4, s9, ne
    1700:      	ands	w8, w11, #0x1
    1704:      	mov	w7, #0x3                ; =3
    1708:      	csel	w9, w7, wzr, ne
    170c:      	orr	x12, x1, x9
    1710:      	ldrb	w12, [x12]
    1714:      	add	x10, sp, #0x2e0
    1718:      	orr	x9, x10, x9, lsl #2
    171c:      	stp	q4, q3, [x23, #0x140]
    1720:      	ldr	s7, [x9]
    1724:      	tst	w8, w12
    1728:      	fcsel	s7, s7, s9, ne
    172c:      	mov	x11, x6
    1730:      	ands	w2, w11, #0x1
    1734:      	mov	w10, #0x2               ; =2
    1738:      	csel	w8, w10, wzr, ne
    173c:      	orr	x9, x1, x8
    1740:      	ldrb	w9, [x9]
    1744:      	lsr	x8, x8, #1
    1748:      	add	x12, sp, #0x2c0
    174c:      	bfi	x12, x8, #3, #1
    1750:      	stp	q4, q3, [x23, #0x120]
    1754:      	ldr	s16, [x12]
    1758:      	tst	w2, w9
    175c:      	fcsel	s16, s16, s9, ne
    1760:      	cmp	w25, #0x0
    1764:      	csel	w12, w10, wzr, ne
    1768:      	mov	w10, #0x4               ; =4
    176c:      	csel	w16, w10, wzr, ne
    1770:      	ands	w0, w26, #0x1
    1774:      	mov	w26, #0x6               ; =6
    1778:      	csel	w13, w26, wzr, ne
    177c:      	mov	w5, #0x5                ; =5
    1780:      	csel	w8, w5, wzr, ne
    1784:      	ands	w17, w21, #0x1
    1788:      	mov	w14, #0x7               ; =7
    178c:      	csel	w21, w14, wzr, ne
    1790:      	csel	w9, w10, wzr, ne
    1794:      	ands	w15, w27, #0x1
    1798:      	csel	w27, w10, wzr, ne
    179c:      	csel	w4, w14, wzr, ne
    17a0:      	ldr	w10, [sp, #0x68]
    17a4:      	ands	w14, w10, #0x1
    17a8:      	csel	w5, w5, wzr, ne
    17ac:      	orr	x6, x1, x5
    17b0:      	ldrb	w6, [x6]
    17b4:      	stp	q4, q3, [x23, #0x100]
    17b8:      	add	x10, sp, #0x2a0
    17bc:      	ldr	s17, [x10, w5, uxtw #2]
    17c0:      	csel	w5, w26, wzr, ne
    17c4:      	tst	w14, w6
    17c8:      	orr	x6, x1, x27
    17cc:      	ldrb	w6, [x6]
    17d0:      	stp	q4, q3, [x23, #0xe0]
    17d4:      	add	x10, sp, #0x280
    17d8:      	ldr	s18, [x10, w27, uxtw #2]
    17dc:      	orr	x27, x1, x21
    17e0:      	ldrb	w27, [x27]
    17e4:      	stp	q4, q3, [x23, #0xc0]
    17e8:      	add	x10, sp, #0x260
    17ec:      	ldr	s19, [x10, w21, uxtw #2]
    17f0:      	fcsel	s17, s17, s9, ne
    17f4:      	tst	w15, w6
    17f8:      	fcsel	s18, s18, s9, ne
    17fc:      	tst	w17, w27
    1800:      	orr	x6, x1, x13
    1804:      	ldrb	w6, [x6]
    1808:      	stp	q4, q3, [x23, #0xa0]
    180c:      	add	x10, sp, #0x240
    1810:      	ldr	s20, [x10, w13, uxtw #2]
    1814:      	fcsel	s19, s19, s9, ne
    1818:      	tst	w0, w6
    181c:      	fcsel	s20, s20, s9, ne
    1820:      	mov.s	v17[1], v18[0]
    1824:      	mov.s	v17[2], v19[0]
    1828:      	mov.s	v17[3], v20[0]
    182c:      	mov.s	v5[1], v6[0]
    1830:      	mov.s	v5[2], v7[0]
    1834:      	lsr	x13, x12, #1
    1838:      	add	x6, sp, #0x220
    183c:      	bfi	x6, x13, #3, #1
    1840:      	mov.s	v5[3], v16[0]
    1844:      	fadd.4s	v4, v4, v5
    1848:      	fadd.4s	v3, v3, v17
    184c:      	orr	x12, x1, x12
    1850:      	ldrb	w12, [x12]
    1854:      	stp	q4, q3, [x23, #0x80]
    1858:      	ldr	s5, [x6]
    185c:      	tst	w25, w12
    1860:      	fcsel	s5, s5, s9, ne
    1864:      	ldr	w10, [sp, #0x78]
    1868:      	ands	w12, w10, #0x1
    186c:      	csel	w13, w7, wzr, ne
    1870:      	orr	x6, x1, x13
    1874:      	ldrb	w6, [x6]
    1878:      	tst	w12, w6
    187c:      	add	x10, sp, #0x160
    1880:      	orr	x12, x10, x13, lsl #2
    1884:      	stp	q4, q3, [sp, #0x160]
    1888:      	ldr	s6, [x12]
    188c:      	add	x12, sp, #0x118
    1890:      	bfxil	x12, x11, #0, #1
    1894:      	ldrb	w12, [x12]
    1898:      	fcsel	s6, s6, s9, ne
    189c:      	ldr	w13, [sp, #0x5c]
    18a0:      	tst	w13, #0x1
    18a4:      	fcsel	s7, s4, s9, ne
    18a8:      	tst	w2, w12
    18ac:      	add	x12, sp, #0x200
    18b0:      	bfi	x12, x11, #2, #1
    18b4:      	stp	q4, q3, [x23, #0x60]
    18b8:      	ldr	s16, [x12]
    18bc:      	fcsel	s16, s16, s9, ne
    18c0:      	orr	x12, x1, x5
    18c4:      	ldrb	w12, [x12]
    18c8:      	tst	w14, w12
    18cc:      	stp	q4, q3, [x23, #0x40]
    18d0:      	add	x10, sp, #0x1e0
    18d4:      	ldr	s17, [x10, w5, uxtw #2]
    18d8:      	orr	x12, x1, x4
    18dc:      	ldrb	w12, [x12]
    18e0:      	stp	q4, q3, [x23, #0x20]
    18e4:      	add	x10, sp, #0x1c0
    18e8:      	ldr	s18, [x10, w4, uxtw #2]
    18ec:      	fcsel	s17, s17, s9, ne
    18f0:      	tst	w15, w12
    18f4:      	fcsel	s18, s18, s9, ne
    18f8:      	orr	x12, x1, x9
    18fc:      	ldrb	w12, [x12]
    1900:      	stp	q4, q3, [x23]
    1904:      	ldr	s19, [x23, w9, uxtw #2]
    1908:      	tst	w17, w12
    190c:      	fcsel	s19, s19, s9, ne
    1910:      	orr	x9, x1, x8
    1914:      	ldrb	w9, [x9]
    1918:      	stp	q4, q3, [sp, #0x180]
    191c:      	add	x10, sp, #0x180
    1920:      	ldr	s20, [x10, w8, uxtw #2]
    1924:      	tst	w0, w9
    1928:      	fcsel	s20, s20, s9, ne
    192c:      	mov.s	v5[1], v6[0]
    1930:      	mov.s	v5[2], v7[0]
    1934:      	mov.s	v5[3], v16[0]
    1938:      	mov.s	v17[1], v18[0]
    193c:      	mov.s	v17[2], v19[0]
    1940:      	mov.s	v17[3], v20[0]
    1944:      	fadd.4s	v4, v4, v5
    1948:      	fadd.4s	v3, v3, v17
    194c:      	orr	x8, x1, x16
    1950:      	ldrb	w8, [x8]
    1954:      	stp	q4, q3, [sp, #0x140]
    1958:      	add	x9, sp, #0x140
    195c:      	ldr	s3, [x9, w16, uxtw #2]
    1960:      	tst	w25, w8
    1964:      	fcsel	s3, s3, s9, ne
    1968:      	cmp	w25, #0x0
    196c:      	fadd	s3, s4, s3
    1970:      	fcsel	s4, s3, s9, ne
    1974:      	tst	w3, #0x1
    1978:      	fcsel	s5, s3, s9, ne
    197c:      	tst	w13, #0x1
    1980:      	fcsel	s6, s3, s9, ne
    1984:      	ldr	w8, [sp, #0x4c]
    1988:      	tst	w8, #0x1
    198c:      	fcsel	s7, s3, s9, ne
    1990:      	ldr	w8, [sp, #0x60]
    1994:      	tst	w8, #0x1
    1998:      	fcsel	s16, s3, s9, ne
    199c:      	ldp	w8, w9, [sp, #0x54]
    19a0:      	tst	w9, #0x1
    19a4:      	fcsel	s17, s3, s9, ne
    19a8:      	tst	w8, #0x1
    19ac:      	fcsel	s18, s3, s9, ne
    19b0:      	ldr	w8, [sp, #0x50]
    19b4:      	tst	w8, #0x1
    19b8:      	mov.s	v4[1], v5[0]
    19bc:      	mov.s	v4[2], v6[0]
    19c0:      	mov.s	v4[3], v7[0]
    19c4:      	mov.s	v16[1], v17[0]
    19c8:      	mov.s	v16[2], v18[0]
    19cc:      	fcsel	s3, s3, s9, ne
    19d0:      	mov.s	v16[3], v3[0]
    19d4:      	stp	q4, q16, [sp, #0x120]
    19d8:      	ldr	x8, [sp, #0x80]
    19dc:      	and	x8, x8, #0x7
    19e0:      	add	x9, sp, #0x120
    19e4:      	ldr	s3, [x9, x8, lsl #2]
    19e8:      	fadd	s3, s3, s9
    19ec:      	ldp	x9, x8, [sp, #0x88]
    19f0:      	add	x8, x8, x9
    19f4:      	dup.4s	v3, v3[0]
    19f8:      	add	x12, sp, #0x600
    19fc:      	ldr	w13, [sp, #0x98]
    1a00:      	add	x25, sp, #0x3, lsl #12  ; =0x3000
    1a04:      	add	x25, x25, #0x900
    1a08:      	b	0x1a18 <_llm_rows.packet_batch.blocks+0x1380>
    1a0c:      	add	x30, x30, #0x20
    1a10:      	cmp	x30, #0xc00
    1a14:      	b.eq	0x77c <_llm_rows.packet_batch.blocks+0xe4>
    1a18:      	fmov	w10, s2
    1a1c:      	add	x9, x12, x30
    1a20:      	ldp	q5, q4, [x9]
    1a24:      	and.16b	v5, v1, v5
    1a28:      	fdiv.4s	v5, v5, v3
    1a2c:      	add	x9, x8, x30
    1a30:      	tbnz	w10, #0x0, 0x1a60 <_llm_rows.packet_batch.blocks+0x13c8>
    1a34:      	and	w10, w10, #0xff
    1a38:      	tbnz	w10, #0x1, 0x1a6c <_llm_rows.packet_batch.blocks+0x13d4>
    1a3c:      	tbnz	w10, #0x2, 0x1a78 <_llm_rows.packet_batch.blocks+0x13e0>
    1a40:      	tbnz	w10, #0x3, 0x1a84 <_llm_rows.packet_batch.blocks+0x13ec>
    1a44:      	and.16b	v4, v0, v4
    1a48:      	fdiv.4s	v4, v4, v3
    1a4c:      	tbnz	w10, #0x4, 0x1a98 <_llm_rows.packet_batch.blocks+0x1400>
    1a50:      	tbnz	w10, #0x5, 0x1aa0 <_llm_rows.packet_batch.blocks+0x1408>
    1a54:      	tbnz	w10, #0x6, 0x1aac <_llm_rows.packet_batch.blocks+0x1414>
    1a58:      	tbz	w10, #0x7, 0x1a0c <_llm_rows.packet_batch.blocks+0x1374>
    1a5c:      	b	0x1ab8 <_llm_rows.packet_batch.blocks+0x1420>
    1a60:      	str	s5, [x9]
    1a64:      	and	w10, w10, #0xff
    1a68:      	tbz	w10, #0x1, 0x1a3c <_llm_rows.packet_batch.blocks+0x13a4>
    1a6c:      	add	x11, x9, #0x4
    1a70:      	st1.s	{ v5 }[1], [x11]
    1a74:      	tbz	w10, #0x2, 0x1a40 <_llm_rows.packet_batch.blocks+0x13a8>
    1a78:      	add	x11, x9, #0x8
    1a7c:      	st1.s	{ v5 }[2], [x11]
    1a80:      	tbz	w10, #0x3, 0x1a44 <_llm_rows.packet_batch.blocks+0x13ac>
    1a84:      	add	x11, x9, #0xc
    1a88:      	st1.s	{ v5 }[3], [x11]
    1a8c:      	and.16b	v4, v0, v4
    1a90:      	fdiv.4s	v4, v4, v3
    1a94:      	tbz	w10, #0x4, 0x1a50 <_llm_rows.packet_batch.blocks+0x13b8>
    1a98:      	str	s4, [x9, #0x10]
    1a9c:      	tbz	w10, #0x5, 0x1a54 <_llm_rows.packet_batch.blocks+0x13bc>
    1aa0:      	add	x11, x9, #0x14
    1aa4:      	st1.s	{ v4 }[1], [x11]
    1aa8:      	tbz	w10, #0x6, 0x1a58 <_llm_rows.packet_batch.blocks+0x13c0>
    1aac:      	add	x11, x9, #0x18
    1ab0:      	st1.s	{ v4 }[2], [x11]
    1ab4:      	tbz	w10, #0x7, 0x1a0c <_llm_rows.packet_batch.blocks+0x1374>
    1ab8:      	add	x9, x9, #0x1c
    1abc:      	st1.s	{ v4 }[3], [x9]
    1ac0:      	b	0x1a0c <_llm_rows.packet_batch.blocks+0x1374>
    1ac4:      	add	sp, sp, #0x4, lsl #12   ; =0x4000
    1ac8:      	add	sp, sp, #0x500
    1acc:      	ldp	x29, x30, [sp, #0x90]
    1ad0:      	ldp	x20, x19, [sp, #0x80]
    1ad4:      	ldp	x22, x21, [sp, #0x70]
    1ad8:      	ldp	x24, x23, [sp, #0x60]
    1adc:      	ldp	x26, x25, [sp, #0x50]
    1ae0:      	ldp	x28, x27, [sp, #0x40]
    1ae4:      	ldp	d9, d8, [sp, #0x30]
    1ae8:      	ldp	d11, d10, [sp, #0x20]
    1aec:      	ldp	d13, d12, [sp, #0x10]
    1af0:      	ldp	d15, d14, [sp], #0xa0
    1af4:      	ret

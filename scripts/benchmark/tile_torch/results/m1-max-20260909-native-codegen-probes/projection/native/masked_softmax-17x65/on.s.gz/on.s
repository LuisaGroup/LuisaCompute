
/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/masked_softmax-17x65/on/object/tile_xir_w8_37937_1788936537924890_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0x90]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	sub	sp, sp, #0x5f0
      28:      	mov	x11, #0x0               ; =0
      2c:      	ldr	x10, [x0]
      30:      	ldr	w8, [x1]
      34:      	ldr	w9, [x1, #0x24]
      38:      	add	w8, w9, w8, lsl #5
      3c:      	lsr	w9, w8, #3
      40:      	mov	w12, #0x104             ; =260
      44:      	umull	x8, w9, w12
      48:      	umaddl	x12, w9, w12, x10
      4c:      	ldp	q1, q2, [x12, #0xc0]
      50:      	fmov	s0, w9
      54:      	add	x13, sp, #0x4d0
      58:      	stp	q1, q2, [x13, #0xc0]
      5c:      	ldp	q1, q2, [x12, #0xe0]
      60:      	stp	q1, q2, [x13, #0xe0]
      64:      	ldp	q1, q2, [x12, #0x80]
      68:      	stp	q1, q2, [x13, #0x80]
      6c:      	ldp	q1, q2, [x12, #0xa0]
      70:      	stp	q1, q2, [x13, #0xa0]
      74:      	ldp	q1, q2, [x12, #0x40]
      78:      	stp	q1, q2, [x13, #0x40]
      7c:      	ldp	q1, q2, [x12, #0x60]
      80:      	stp	q1, q2, [x13, #0x60]
      84:      	ldp	q1, q2, [x12]
      88:      	stp	q1, q2, [x13]
      8c:      	ldp	q1, q2, [x12, #0x20]
      90:      	stp	q1, q2, [x13, #0x20]
      94:      	add	x9, x8, #0x100
      98:      	ldr	s4, [x10, x9]
      9c:      	str	q4, [x13, #0x100]
      a0:      	movi.2d	v2, #0000000000000000
      a4:      	adrp	x10, 0x0 <ltmp0>
      a8:      	ldr	q1, [x10]
      ac:      	adrp	x10, 0x0 <ltmp0>
      b0:      	ldr	q3, [x10]
      b4:      	adrp	x10, 0x0 <ltmp0>
      b8:      	ldr	q5, [x10]
      bc:      	add	x12, sp, #0x290
      c0:      	adrp	x10, 0x0 <ltmp0>
      c4:      	ldr	q6, [x10]
      c8:      	mov	w13, #0x1               ; =1
      cc:      	movi.2d	v7, #0000000000000000
      d0:      	movi.2d	v16, #0000000000000000
      d4:      	ldr	x10, [x0, #0x30]
      d8:      	movi.2d	v17, #0000000000000000
      dc:      	dup.2d	v18, x13
      e0:      	shl.2d	v19, v2, #0x3
      e4:      	shl.2d	v20, v7, #0x3
      e8:      	shl.2d	v21, v16, #0x3
      ec:      	shl.2d	v22, v17, #0x3
      f0:      	orr.16b	v22, v22, v1
      f4:      	orr.16b	v21, v21, v3
      f8:      	orr.16b	v20, v20, v5
      fc:      	orr.16b	v19, v19, v6
     100:      	add	x11, x12, x11, lsl #6
     104:      	stp	q19, q20, [x11]
     108:      	stp	q21, q22, [x11, #0x20]
     10c:      	add.2d	v16, v16, v18
     110:      	add.2d	v7, v7, v18
     114:      	add.2d	v19, v2, v18
     118:      	add.2d	v17, v17, v18
     11c:      	fmov	x11, d2
     120:      	add	x11, x11, #0x1
     124:      	mov.16b	v2, v19
     128:      	cmp	x11, #0x8
     12c:      	b.lt	0xe0 <ltmp0+0xe0>
     130:      	mov	x12, #0x0               ; =0
     134:      	mov	w11, #0x40              ; =64
     138:      	str	x11, [sp, #0x490]
     13c:      	mov	w11, #0xc0fd            ; =49405
     140:      	movk	w11, #0xfc0f, lsl #16
     144:      	fmov	s1, w11
     148:      	umull2.2d	v2, v0, v1
     14c:      	umull.2d	v1, v0, v1
     150:      	uzp2.4s	v1, v1, v2
     154:      	ushr.4s	v1, v1, #0x6
     158:      	movi.4s	v2, #0x41
     15c:      	mls.4s	v0, v1, v2
     160:      	dup.4s	v0, v0[0]
     164:      	ushll2.2d	v5, v0, #0x0
     168:      	ushll.2d	v7, v0, #0x0
     16c:      	movi.2d	v6, #0000000000000000
     170:      	add	x11, sp, #0x248
     174:      	dup.2d	v16, x11
     178:      	adrp	x11, 0x0 <ltmp0>
     17c:      	ldr	q0, [x11]
     180:      	adrp	x11, 0x0 <ltmp0>
     184:      	ldr	q1, [x11]
     188:      	adrp	x11, 0x0 <ltmp0>
     18c:      	ldr	q2, [x11]
     190:      	mov	w11, #0x1               ; =1
     194:      	dup.2d	v17, x11
     198:      	adrp	x11, 0x0 <ltmp0>
     19c:      	ldr	q3, [x11]
     1a0:      	add	x11, sp, #0x290
     1a4:      	movi.8b	v18, #0x1
     1a8:      	movi.2d	v19, #0000000000000000
     1ac:      	movi.2d	v20, #0000000000000000
     1b0:      	movi.2d	v21, #0000000000000000
     1b4:      	add	x12, x11, x12, lsl #6
     1b8:      	ldp	q23, q22, [x12, #0x20]
     1bc:      	ldp	q24, q25, [x12]
     1c0:      	add.2d	v26, v21, v3
     1c4:      	add.2d	v27, v19, v1
     1c8:      	add.2d	v27, v27, v16
     1cc:      	add.2d	v28, v6, v0
     1d0:      	add.2d	v28, v28, v16
     1d4:      	cmge.2d	v25, v5, v25
     1d8:      	cmge.2d	v24, v7, v24
     1dc:      	uzp1.4s	v24, v24, v25
     1e0:      	cmge.2d	v23, v7, v23
     1e4:      	cmge.2d	v22, v5, v22
     1e8:      	uzp1.4s	v22, v23, v22
     1ec:      	uzp1.8h	v22, v24, v22
     1f0:      	xtn.8b	v22, v22
     1f4:      	and.8b	v22, v22, v18
     1f8:      	mov.d	x12, v28[1]
     1fc:      	fmov	x13, d28
     200:      	str	b22, [x13]
     204:      	st1.b	{ v22 }[1], [x12]
     208:      	mov.d	x12, v27[1]
     20c:      	add.2d	v23, v20, v2
     210:      	fmov	x13, d27
     214:      	st1.b	{ v22 }[2], [x13]
     218:      	st1.b	{ v22 }[3], [x12]
     21c:      	add.2d	v23, v23, v16
     220:      	mov.d	x12, v23[1]
     224:      	fmov	x13, d23
     228:      	st1.b	{ v22 }[4], [x13]
     22c:      	add.2d	v23, v26, v16
     230:      	st1.b	{ v22 }[5], [x12]
     234:      	mov.d	x12, v23[1]
     238:      	fmov	x13, d23
     23c:      	st1.b	{ v22 }[6], [x13]
     240:      	st1.b	{ v22 }[7], [x12]
     244:      	add.2d	v20, v20, v17
     248:      	add.2d	v19, v19, v17
     24c:      	add.2d	v22, v6, v17
     250:      	add.2d	v21, v21, v17
     254:      	fmov	x12, d6
     258:      	add	x12, x12, #0x1
     25c:      	mov.16b	v6, v22
     260:      	cmp	x12, #0x8
     264:      	b.lt	0x1b4 <ltmp0+0x1b4>
     268:      	mov	x11, #0x0               ; =0
     26c:      	add	x12, sp, #0x248
     270:      	dup.2d	v5, x12
     274:      	adrp	x12, 0x0 <ltmp0>
     278:      	ldr	q16, [x12]
     27c:      	adrp	x12, 0x0 <ltmp0>
     280:      	ldr	q6, [x12]
     284:      	add.2d	v6, v5, v6
     288:      	cmgt.2d	v7, v7, v16
     28c:      	xtn.2s	v7, v7
     290:      	uzp1.4h	v7, v7, v0
     294:      	uzp1.8b	v7, v7, v0
     298:      	movi.8b	v16, #0x1
     29c:      	and.8b	v7, v7, v16
     2a0:      	fmov	x12, d6
     2a4:      	str	b7, [x12]
     2a8:      	movi.2d	v7, #0000000000000000
     2ac:      	add	x12, sp, #0x4d0
     2b0:      	mov	w13, #0xf2ca            ; =62154
     2b4:      	movk	w13, #0xf149, lsl #16
     2b8:      	dup.4s	v16, w13
     2bc:      	mov	w13, #0x1               ; =1
     2c0:      	dup.2d	v17, x13
     2c4:      	add	x13, sp, #0x128
     2c8:      	movi.2d	v18, #0000000000000000
     2cc:      	movi.2d	v19, #0000000000000000
     2d0:      	movi.2d	v20, #0000000000000000
     2d4:      	add.2d	v21, v20, v3
     2d8:      	add.2d	v22, v19, v2
     2dc:      	add.2d	v21, v21, v5
     2e0:      	add.2d	v23, v18, v1
     2e4:      	add.2d	v24, v7, v0
     2e8:      	add.2d	v24, v24, v5
     2ec:      	mov.d	x14, v24[1]
     2f0:      	add.2d	v22, v22, v5
     2f4:      	add.2d	v23, v23, v5
     2f8:      	fmov	x15, d24
     2fc:      	mov.d	x16, v23[1]
     300:      	mov.d	x17, v22[1]
     304:      	fmov	x0, d23
     308:      	ldr	b23, [x15]
     30c:      	ld1.b	{ v23 }[1], [x14]
     310:      	mov.d	x14, v21[1]
     314:      	fmov	x15, d22
     318:      	ld1.b	{ v23 }[2], [x0]
     31c:      	ld1.b	{ v23 }[3], [x16]
     320:      	fmov	x16, d21
     324:      	ld1.b	{ v23 }[4], [x15]
     328:      	ld1.b	{ v23 }[5], [x17]
     32c:      	ld1.b	{ v23 }[6], [x16]
     330:      	ld1.b	{ v23 }[7], [x14]
     334:      	cmeq.8b	v21, v23, #0
     338:      	sshll.8h	v21, v21, #0x0
     33c:      	sshll2.4s	v22, v21, #0x0
     340:      	sshll.4s	v21, v21, #0x0
     344:      	lsl	x11, x11, #5
     348:      	add	x14, x12, x11
     34c:      	ldp	q24, q23, [x14]
     350:      	bsl.16b	v21, v16, v24
     354:      	bsl.16b	v22, v16, v23
     358:      	add	x11, x13, x11
     35c:      	add.2d	v19, v19, v17
     360:      	add.2d	v18, v18, v17
     364:      	stp	q21, q22, [x11]
     368:      	add.2d	v21, v7, v17
     36c:      	add.2d	v20, v20, v17
     370:      	fmov	x11, d7
     374:      	add	x11, x11, #0x1
     378:      	mov.16b	v7, v21
     37c:      	cmp	x11, #0x8
     380:      	b.lt	0x2d4 <ltmp0+0x2d4>
     384:      	mov	x7, #0x0                ; =0
     388:      	fmov	x11, d6
     38c:      	ldr	b5, [x11]
     390:      	cmeq.8b	v5, v5, #0
     394:      	sshll.8h	v5, v5, #0x0
     398:      	sshll.4s	v6, v5, #0x0
     39c:      	mov	w11, #0xf2ca            ; =62154
     3a0:      	movk	w11, #0xf149, lsl #16
     3a4:      	dup.4s	v7, w11
     3a8:      	bsl.16b	v6, v7, v4
     3ac:      	add	x11, sp, #0x129
     3b0:      	ldur	q4, [x11, #0xff]
     3b4:      	mov.s	v4[0], v6[0]
     3b8:      	stur	q4, [x11, #0xff]
     3bc:      	add	x11, sp, #0x29
     3c0:      	ldur	q7, [x11, #0xff]
     3c4:      	add	x11, sp, #0x39
     3c8:      	ldur	q16, [x11, #0xff]
     3cc:      	add	x11, sp, #0x59
     3d0:      	ldur	q17, [x11, #0xff]
     3d4:      	add	x11, sp, #0x49
     3d8:      	ldur	q18, [x11, #0xff]
     3dc:      	add	x11, sp, #0x69
     3e0:      	ldur	q19, [x11, #0xff]
     3e4:      	add	x11, sp, #0x79
     3e8:      	ldur	q20, [x11, #0xff]
     3ec:      	add	x11, sp, #0x99
     3f0:      	ldur	q21, [x11, #0xff]
     3f4:      	add	x11, sp, #0x89
     3f8:      	ldur	q22, [x11, #0xff]
     3fc:      	add	x11, sp, #0x119
     400:      	ldur	q23, [x11, #0xff]
     404:      	add	x11, sp, #0x109
     408:      	ldur	q24, [x11, #0xff]
     40c:      	fmaxnm.4s	v22, v22, v24
     410:      	fmaxnm.4s	v21, v21, v23
     414:      	add	x11, sp, #0xe9
     418:      	ldur	q23, [x11, #0xff]
     41c:      	add	x11, sp, #0xf9
     420:      	ldur	q24, [x11, #0xff]
     424:      	fmaxnm.4s	v20, v20, v24
     428:      	fmaxnm.4s	v19, v19, v23
     42c:      	add	x11, sp, #0xd9
     430:      	ldur	q23, [x11, #0xff]
     434:      	add	x11, sp, #0xc9
     438:      	ldur	q24, [x11, #0xff]
     43c:      	fmaxnm.4s	v18, v18, v24
     440:      	fmaxnm.4s	v17, v17, v23
     444:      	add	x11, sp, #0xa9
     448:      	ldur	q23, [x11, #0xff]
     44c:      	add	x11, sp, #0xb9
     450:      	ldur	q24, [x11, #0xff]
     454:      	fmaxnm.4s	v16, v16, v24
     458:      	fmaxnm.4s	v7, v7, v23
     45c:      	movi.2d	v23, #0000000000000000
     460:      	mov.s	v23[0], v6[0]
     464:      	movi.2d	v6, #0000000000000000
     468:      	fmaxnm.4s	v23, v7, v23
     46c:      	mov.s	v7[0], v23[0]
     470:      	fmaxnm.4s	v16, v16, v17
     474:      	fmaxnm.4s	v7, v7, v18
     478:      	fmaxnm.4s	v7, v7, v19
     47c:      	fmaxnm.4s	v16, v16, v20
     480:      	fmaxnm.4s	v16, v16, v21
     484:      	fmaxnm.4s	v7, v7, v22
     488:      	rev64.4s	v17, v7
     48c:      	rev64.4s	v18, v16
     490:      	fmaxnm.4s	v16, v16, v18
     494:      	fmaxnm.4s	v7, v7, v17
     498:      	ext.16b	v17, v7, v7, #0x8
     49c:      	ext.16b	v18, v16, v16, #0x8
     4a0:      	fmaxnm.4s	v16, v16, v18
     4a4:      	fmaxnm.4s	v7, v7, v17
     4a8:      	fmaxnm.4s	v7, v7, v16
     4ac:      	mov	w11, #-0x800000         ; =-8388608
     4b0:      	fmov	s16, w11
     4b4:      	fmaxnm	s7, s7, s16
     4b8:      	dup.4s	v16, v7[0]
     4bc:      	add	x11, sp, #0x248
     4c0:      	add	x12, sp, #0x128
     4c4:      	mov	w13, #-0x3d300000       ; =-1026555904
     4c8:      	mov	w14, #0x42c80000        ; =1120403456
     4cc:      	mov	w15, #0xaa3b            ; =43579
     4d0:      	movk	w15, #0x3fb8, lsl #16
     4d4:      	movi.4s	v17, #0x4b, lsl #24
     4d8:      	mvni.4s	v18, #0x80, lsl #24
     4dc:      	mov	w16, #0x7200            ; =29184
     4e0:      	movk	w16, #0xbf31, lsl #16
     4e4:      	mov	w17, #0xbe8e            ; =48782
     4e8:      	movk	w17, #0xb5bf, lsl #16
     4ec:      	mov	w0, #0x2bda             ; =11226
     4f0:      	movk	w0, #0x3950, lsl #16
     4f4:      	mov	w1, #0x96c9             ; =38601
     4f8:      	movk	w1, #0x3ab6, lsl #16
     4fc:      	mov	w2, #0x88a6             ; =34982
     500:      	movk	w2, #0x3c08, lsl #16
     504:      	mov	w3, #0xaa7a             ; =43642
     508:      	movk	w3, #0x3d2a, lsl #16
     50c:      	mov	w4, #0xaaab             ; =43691
     510:      	movk	w4, #0x3e2a, lsl #16
     514:      	movi.4s	v19, #0x3f, lsl #24
     518:      	mvni.4s	v20, #0x7f, msl #16
     51c:      	fneg.4s	v20, v20
     520:      	mvni.4s	v21, #0x3f, msl #16
     524:      	fneg.4s	v21, v21
     528:      	add	x5, sp, #0x8
     52c:      	mov	w6, #0x1                ; =1
     530:      	movi.2d	v22, #0000000000000000
     534:      	movi.2d	v23, #0000000000000000
     538:      	movi.2d	v24, #0000000000000000
     53c:      	dup.2d	v25, x11
     540:      	add.2d	v26, v24, v3
     544:      	add.2d	v27, v23, v2
     548:      	add.2d	v26, v26, v25
     54c:      	add.2d	v27, v27, v25
     550:      	add.2d	v28, v22, v1
     554:      	add.2d	v29, v6, v0
     558:      	add.2d	v29, v29, v25
     55c:      	mov.d	x20, v29[1]
     560:      	add.2d	v25, v28, v25
     564:      	fmov	x21, d29
     568:      	mov.d	x22, v25[1]
     56c:      	mov.d	x23, v27[1]
     570:      	fmov	x24, d25
     574:      	fmov	x25, d27
     578:      	mov.d	x19, v26[1]
     57c:      	fmov	x26, d26
     580:      	ldr	b25, [x21]
     584:      	ld1.b	{ v25 }[1], [x20]
     588:      	lsl	x7, x7, #5
     58c:      	add	x20, x12, x7
     590:      	ld1.b	{ v25 }[2], [x24]
     594:      	ldp	q27, q26, [x20]
     598:      	fsub.4s	v26, v26, v16
     59c:      	fsub.4s	v27, v27, v16
     5a0:      	ld1.b	{ v25 }[3], [x22]
     5a4:      	dup.4s	v28, w13
     5a8:      	fcmge.4s	v30, v27, v28
     5ac:      	fcmge.4s	v31, v26, v28
     5b0:      	ld1.b	{ v25 }[4], [x25]
     5b4:      	dup.4s	v29, w14
     5b8:      	fcmge.4s	v8, v29, v27
     5bc:      	fcmge.4s	v9, v29, v26
     5c0:      	ld1.b	{ v25 }[5], [x23]
     5c4:      	and.16b	v31, v31, v9
     5c8:      	and.16b	v30, v30, v8
     5cc:      	and.16b	v30, v30, v27
     5d0:      	and.16b	v9, v31, v26
     5d4:      	ld1.b	{ v25 }[6], [x26]
     5d8:      	dup.4s	v31, w15
     5dc:      	fmul.4s	v8, v9, v31
     5e0:      	fmul.4s	v31, v30, v31
     5e4:      	ld1.b	{ v25 }[7], [x19]
     5e8:      	mov.16b	v10, v18
     5ec:      	bsl.16b	v10, v17, v31
     5f0:      	mov.16b	v11, v18
     5f4:      	bsl.16b	v11, v17, v8
     5f8:      	fadd.4s	v8, v8, v11
     5fc:      	fadd.4s	v31, v31, v10
     600:      	fsub.4s	v10, v31, v10
     604:      	cmeq.8b	v25, v25, #0
     608:      	fsub.4s	v31, v8, v11
     60c:      	fcvtzs.4s	v31, v31
     610:      	fcvtzs.4s	v8, v10
     614:      	scvtf.4s	v10, v8
     618:      	scvtf.4s	v11, v31
     61c:      	sshll.8h	v25, v25, #0x0
     620:      	dup.4s	v12, w16
     624:      	fmul.4s	v13, v11, v12
     628:      	fmul.4s	v12, v10, v12
     62c:      	fadd.4s	v12, v30, v12
     630:      	sshll2.4s	v30, v25, #0x0
     634:      	fadd.4s	v9, v9, v13
     638:      	dup.4s	v13, w17
     63c:      	fmul.4s	v10, v10, v13
     640:      	fmul.4s	v11, v11, v13
     644:      	fadd.4s	v9, v9, v11
     648:      	fadd.4s	v10, v12, v10
     64c:      	dup.4s	v11, w0
     650:      	dup.4s	v12, w1
     654:      	fmul.4s	v13, v10, v11
     658:      	fmul.4s	v11, v9, v11
     65c:      	fadd.4s	v11, v11, v12
     660:      	fadd.4s	v12, v13, v12
     664:      	dup.4s	v13, w2
     668:      	fmul.4s	v12, v10, v12
     66c:      	fmul.4s	v11, v9, v11
     670:      	fadd.4s	v11, v11, v13
     674:      	fadd.4s	v12, v12, v13
     678:      	dup.4s	v13, w3
     67c:      	fmul.4s	v12, v10, v12
     680:      	fmul.4s	v11, v9, v11
     684:      	fadd.4s	v11, v11, v13
     688:      	fadd.4s	v12, v12, v13
     68c:      	dup.4s	v13, w4
     690:      	fmul.4s	v12, v10, v12
     694:      	fmul.4s	v11, v9, v11
     698:      	fadd.4s	v11, v11, v13
     69c:      	fadd.4s	v12, v12, v13
     6a0:      	fmul.4s	v12, v10, v12
     6a4:      	fmul.4s	v11, v9, v11
     6a8:      	fadd.4s	v11, v11, v19
     6ac:      	fadd.4s	v12, v12, v19
     6b0:      	fmul.4s	v13, v9, v9
     6b4:      	fmul.4s	v14, v10, v10
     6b8:      	fmul.4s	v12, v14, v12
     6bc:      	fmul.4s	v11, v13, v11
     6c0:      	sshll.4s	v13, v25, #0x0
     6c4:      	fadd.4s	v9, v9, v11
     6c8:      	fadd.4s	v10, v10, v12
     6cc:      	fmov.4s	v25, #1.00000000
     6d0:      	fadd.4s	v10, v10, v25
     6d4:      	sshr.4s	v11, v8, #0x1
     6d8:      	fadd.4s	v9, v9, v25
     6dc:      	sshr.4s	v12, v31, #0x1
     6e0:      	shl.4s	v14, v12, #0x17
     6e4:      	shl.4s	v15, v11, #0x17
     6e8:      	add.4s	v15, v15, v25
     6ec:      	add.4s	v14, v14, v25
     6f0:      	fmul.4s	v9, v9, v14
     6f4:      	sub.4s	v31, v31, v12
     6f8:      	sub.4s	v8, v8, v11
     6fc:      	shl.4s	v8, v8, #0x17
     700:      	shl.4s	v31, v31, #0x17
     704:      	add.4s	v31, v31, v25
     708:      	fmul.4s	v10, v10, v15
     70c:      	add.4s	v8, v8, v25
     710:      	fmul.4s	v8, v10, v8
     714:      	fmul.4s	v31, v9, v31
     718:      	fcmgt.4s	v9, v28, v26
     71c:      	fcmgt.4s	v28, v28, v27
     720:      	bic.16b	v31, v31, v9
     724:      	bic.16b	v28, v8, v28
     728:      	fcmgt.4s	v8, v26, v29
     72c:      	fcmgt.4s	v29, v27, v29
     730:      	bit.16b	v28, v20, v29
     734:      	fcmeq.4s	v27, v27, v27
     738:      	mov.16b	v29, v8
     73c:      	bsl.16b	v29, v20, v31
     740:      	fcmeq.4s	v26, v26, v26
     744:      	bsl.16b	v26, v29, v21
     748:      	bsl.16b	v27, v28, v21
     74c:      	bic.16b	v27, v27, v13
     750:      	add	x7, x5, x7
     754:      	bic.16b	v26, v26, v30
     758:      	dup.2d	v28, x6
     75c:      	add.2d	v23, v23, v28
     760:      	add.2d	v22, v22, v28
     764:      	stp	q27, q26, [x7]
     768:      	add.2d	v26, v6, v28
     76c:      	add.2d	v24, v24, v28
     770:      	fmov	x7, d6
     774:      	add	x7, x7, #0x1
     778:      	mov.16b	v6, v26
     77c:      	cmp	x7, #0x8
     780:      	b.lt	0x53c <ltmp0+0x53c>
     784:      	fsub.4s	v1, v4, v7
     788:      	movi.2d	v0, #0000000000000000
     78c:      	mov.s	v0[0], v1[0]
     790:      	mov	w11, #-0x3d300000       ; =-1026555904
     794:      	dup.4s	v2, w11
     798:      	sshll.4s	v1, v5, #0x0
     79c:      	fcmge.4s	v3, v0, v2
     7a0:      	mov	w11, #0x42c80000        ; =1120403456
     7a4:      	dup.4s	v4, w11
     7a8:      	fcmge.4s	v5, v4, v0
     7ac:      	and.16b	v3, v3, v5
     7b0:      	and.16b	v3, v3, v0
     7b4:      	mov	w11, #0xaa3b            ; =43579
     7b8:      	movk	w11, #0x3fb8, lsl #16
     7bc:      	dup.4s	v5, w11
     7c0:      	fmul.4s	v5, v3, v5
     7c4:      	movi.4s	v6, #0x4b, lsl #24
     7c8:      	mvni.4s	v7, #0x80, lsl #24
     7cc:      	bif.16b	v6, v5, v7
     7d0:      	fadd.4s	v5, v5, v6
     7d4:      	fsub.4s	v5, v5, v6
     7d8:      	fcvtzs.4s	v5, v5
     7dc:      	scvtf.4s	v6, v5
     7e0:      	mov	w11, #0x7200            ; =29184
     7e4:      	movk	w11, #0xbf31, lsl #16
     7e8:      	dup.4s	v7, w11
     7ec:      	fmul.4s	v7, v6, v7
     7f0:      	fadd.4s	v3, v3, v7
     7f4:      	mov	w11, #0xbe8e            ; =48782
     7f8:      	movk	w11, #0xb5bf, lsl #16
     7fc:      	dup.4s	v7, w11
     800:      	fmul.4s	v6, v6, v7
     804:      	fadd.4s	v3, v3, v6
     808:      	mov	w11, #0x2bda            ; =11226
     80c:      	movk	w11, #0x3950, lsl #16
     810:      	dup.4s	v6, w11
     814:      	fmul.4s	v6, v3, v6
     818:      	mov	w11, #0x96c9            ; =38601
     81c:      	movk	w11, #0x3ab6, lsl #16
     820:      	dup.4s	v7, w11
     824:      	fadd.4s	v6, v6, v7
     828:      	fmul.4s	v6, v3, v6
     82c:      	mov	w11, #0x88a6            ; =34982
     830:      	movk	w11, #0x3c08, lsl #16
     834:      	dup.4s	v7, w11
     838:      	fadd.4s	v6, v6, v7
     83c:      	fmul.4s	v6, v3, v6
     840:      	mov	w11, #0xaa7a            ; =43642
     844:      	movk	w11, #0x3d2a, lsl #16
     848:      	dup.4s	v7, w11
     84c:      	fadd.4s	v6, v6, v7
     850:      	fmul.4s	v6, v3, v6
     854:      	mov	w11, #0xaaab            ; =43691
     858:      	movk	w11, #0x3e2a, lsl #16
     85c:      	dup.4s	v7, w11
     860:      	fadd.4s	v6, v6, v7
     864:      	fmul.4s	v6, v3, v6
     868:      	movi.4s	v7, #0x3f, lsl #24
     86c:      	fadd.4s	v6, v6, v7
     870:      	fmul.4s	v7, v3, v3
     874:      	fmul.4s	v6, v7, v6
     878:      	fadd.4s	v3, v3, v6
     87c:      	fadd.4s	v3, v3, v25
     880:      	sshr.4s	v6, v5, #0x1
     884:      	shl.4s	v7, v6, #0x17
     888:      	add.4s	v7, v7, v25
     88c:      	fmul.4s	v3, v3, v7
     890:      	sub.4s	v5, v5, v6
     894:      	shl.4s	v5, v5, #0x17
     898:      	add.4s	v5, v5, v25
     89c:      	fmul.4s	v3, v3, v5
     8a0:      	fcmgt.4s	v2, v2, v0
     8a4:      	bic.16b	v2, v3, v2
     8a8:      	fcmgt.4s	v3, v0, v4
     8ac:      	mvni.4s	v4, #0x7f, msl #16
     8b0:      	fneg.4s	v4, v4
     8b4:      	bit.16b	v2, v4, v3
     8b8:      	fcmeq.4s	v0, v0, v0
     8bc:      	mvni.4s	v3, #0x3f, msl #16
     8c0:      	fneg.4s	v3, v3
     8c4:      	bsl.16b	v0, v2, v3
     8c8:      	bic.16b	v0, v0, v1
     8cc:      	ldur	q3, [sp, #0x8]
     8d0:      	ldur	q4, [sp, #0x18]
     8d4:      	ldur	q5, [sp, #0x28]
     8d8:      	ldur	q6, [sp, #0x38]
     8dc:      	ldur	q7, [sp, #0x48]
     8e0:      	ldur	q16, [sp, #0x58]
     8e4:      	ldur	q17, [sp, #0x68]
     8e8:      	ldur	q18, [sp, #0x78]
     8ec:      	ldur	q1, [sp, #0xe8]
     8f0:      	ldur	q2, [sp, #0xf8]
     8f4:      	fadd.4s	v19, v18, v2
     8f8:      	fadd.4s	v20, v17, v1
     8fc:      	ldur	q21, [sp, #0xc8]
     900:      	ldur	q22, [sp, #0xd8]
     904:      	fadd.4s	v23, v16, v22
     908:      	fadd.4s	v24, v7, v21
     90c:      	ldur	q25, [sp, #0xa8]
     910:      	ldur	q26, [sp, #0xb8]
     914:      	fadd.4s	v27, v6, v26
     918:      	fadd.4s	v28, v5, v25
     91c:      	ldur	q29, [sp, #0x88]
     920:      	ldur	q30, [sp, #0x98]
     924:      	fadd.4s	v31, v4, v30
     928:      	fadd.4s	v8, v3, v29
     92c:      	fadd.4s	v9, v0, v8
     930:      	mov.s	v8[0], v9[0]
     934:      	fadd.4s	v28, v28, v8
     938:      	fadd.4s	v27, v27, v31
     93c:      	fadd.4s	v24, v24, v28
     940:      	fadd.4s	v23, v23, v27
     944:      	fadd.4s	v20, v20, v24
     948:      	fadd.4s	v19, v19, v23
     94c:      	rev64.4s	v23, v20
     950:      	rev64.4s	v24, v19
     954:      	fadd.4s	v20, v20, v23
     958:      	fadd.4s	v19, v19, v24
     95c:      	dup.4s	v23, v20[2]
     960:      	dup.4s	v24, v19[2]
     964:      	fadd.4s	v20, v20, v23
     968:      	fadd.4s	v19, v19, v24
     96c:      	fadd.4s	v19, v20, v19
     970:      	movi	d20, #0000000000000000
     974:      	fadd	s19, s19, s20
     978:      	dup.4s	v20, v19[0]
     97c:      	add	x8, x10, x8
     980:      	fdiv.4s	v3, v3, v20
     984:      	fdiv.4s	v4, v4, v20
     988:      	stp	q3, q4, [x8]
     98c:      	fdiv.4s	v3, v5, v20
     990:      	fdiv.4s	v4, v6, v20
     994:      	stp	q3, q4, [x8, #0x20]
     998:      	fdiv.4s	v3, v7, v20
     99c:      	fdiv.4s	v4, v16, v20
     9a0:      	stp	q3, q4, [x8, #0x40]
     9a4:      	fdiv.4s	v3, v17, v20
     9a8:      	fdiv.4s	v4, v18, v20
     9ac:      	stp	q3, q4, [x8, #0x60]
     9b0:      	fdiv.4s	v3, v29, v20
     9b4:      	fdiv.4s	v4, v30, v20
     9b8:      	stp	q3, q4, [x8, #0x80]
     9bc:      	fdiv.4s	v3, v25, v20
     9c0:      	fdiv.4s	v4, v26, v20
     9c4:      	stp	q3, q4, [x8, #0xa0]
     9c8:      	fdiv.4s	v3, v21, v20
     9cc:      	fdiv.4s	v4, v22, v20
     9d0:      	stp	q3, q4, [x8, #0xc0]
     9d4:      	fdiv.4s	v1, v1, v20
     9d8:      	fdiv.4s	v2, v2, v20
     9dc:      	stp	q1, q2, [x8, #0xe0]
     9e0:      	fdiv.4s	v0, v0, v19
     9e4:      	str	s0, [x10, x9]
     9e8:      	add	sp, sp, #0x5f0
     9ec:      	ldp	x20, x19, [sp, #0x80]
     9f0:      	ldp	x22, x21, [sp, #0x70]
     9f4:      	ldp	x24, x23, [sp, #0x60]
     9f8:      	ldp	x26, x25, [sp, #0x50]
     9fc:      	ldp	x28, x27, [sp, #0x40]
     a00:      	ldp	d9, d8, [sp, #0x30]
     a04:      	ldp	d11, d10, [sp, #0x20]
     a08:      	ldp	d13, d12, [sp, #0x10]
     a0c:      	ldp	d15, d14, [sp], #0x90
     a10:      	ret

0000000000000a14 <_llm_rows.packet_batch.blocks>:
     a14:      	stp	d15, d14, [sp, #-0xa0]!
     a18:      	stp	d13, d12, [sp, #0x10]
     a1c:      	stp	d11, d10, [sp, #0x20]
     a20:      	stp	d9, d8, [sp, #0x30]
     a24:      	stp	x28, x27, [sp, #0x40]
     a28:      	stp	x26, x25, [sp, #0x50]
     a2c:      	stp	x24, x23, [sp, #0x60]
     a30:      	stp	x22, x21, [sp, #0x70]
     a34:      	stp	x20, x19, [sp, #0x80]
     a38:      	stp	x29, x30, [sp, #0x90]
     a3c:      	sub	sp, sp, #0xec0
     a40:      	str	x0, [sp, #0x1e0]
     a44:      	cbz	w3, 0x29fc <_llm_rows.packet_batch.blocks+0x1fe8>
     a48:      	mov	x19, x3
     a4c:      	mov	x20, x2
     a50:      	mov	w22, #0x0               ; =0
     a54:      	add	x23, sp, #0x8d8
     a58:      	add	x8, sp, #0xb18
     a5c:      	dup.2d	v0, x8
     a60:      	str	q0, [sp, #0x20]
     a64:      	adrp	x8, 0x0 <ltmp0>
     a68:      	ldr	q0, [x8]
     a6c:      	str	q0, [sp, #0x10]
     a70:      	adrp	x8, 0x0 <ltmp0>
     a74:      	ldr	q0, [x8]
     a78:      	str	q0, [sp, #0x150]
     a7c:      	adrp	x8, 0x0 <ltmp0>
     a80:      	ldr	q0, [x8]
     a84:      	str	q0, [sp, #0x140]
     a88:      	add	x4, sp, #0xda0
     a8c:      	movi.2s	v8, #0x41
     a90:      	adrp	x16, 0x0 <ltmp0>
     a94:      	adrp	x17, 0x0 <ltmp0>
     a98:      	adrp	x0, 0x0 <ltmp0>
     a9c:      	adrp	x1, 0x0 <ltmp0>
     aa0:      	add	x5, sp, #0xb60
     aa4:      	movi.8b	v14, #0x1
     aa8:      	mvni.4s	v0, #0x7f, msl #16
     aac:      	fneg.4s	v1, v0
     ab0:      	mvni.4s	v0, #0x3f, msl #16
     ab4:      	fneg.4s	v0, v0
     ab8:      	stp	q0, q1, [sp, #0x230]
     abc:      	ldp	w9, w8, [x2, #0x2c]
     ac0:      	str	w9, [sp, #0x1dc]
     ac4:      	str	w8, [sp, #0x1d8]
     ac8:      	add	x26, sp, #0x9f8
     acc:      	ldp	w24, w12, [x2]
     ad0:      	ldp	w21, w8, [x2, #0x8]
     ad4:      	str	x8, [sp, #0x1d0]
     ad8:      	str	w3, [sp, #0x3c]
     adc:      	str	x2, [sp, #0x8]
     ae0:      	b	0xb2c <_llm_rows.packet_batch.blocks+0x118>
     ae4:      	mov	w8, #0x18               ; =24
     ae8:      	str	w8, [x20, #0x24]
     aec:      	add	w8, w24, #0x1
     af0:      	ldr	w9, [sp, #0x1dc]
     af4:      	cmp	w8, w9
     af8:      	cset	w8, eq
     afc:      	csinc	w24, wzr, w24, eq
     b00:      	ldr	w9, [sp, #0x1ec]
     b04:      	cinc	w9, w9, eq
     b08:      	ldr	w10, [sp, #0x1d8]
     b0c:      	cmp	w9, w10
     b10:      	cset	w10, eq
     b14:      	ands	w8, w8, w10
     b18:      	csel	w12, wzr, w9, ne
     b1c:      	add	w21, w21, w8
     b20:      	add	w22, w22, #0x1
     b24:      	cmp	w22, w19
     b28:      	b.eq	0x29fc <_llm_rows.packet_batch.blocks+0x1fe8>
     b2c:      	ubfiz	x8, x24, #5, #32
     b30:      	ldr	x13, [sp, #0x1d0]
     b34:      	cmp	x8, x13
     b38:      	csel	x9, x8, xzr, ls
     b3c:      	subs	x10, x13, x9
     b40:      	cmp	x10, #0x20
     b44:      	mov	w11, #0x20              ; =32
     b48:      	csel	x10, x10, x11, lo
     b4c:      	cmp	x13, x9
     b50:      	stp	w24, w12, [x20]
     b54:      	str	w12, [sp, #0x1ec]
     b58:      	str	w21, [x20, #0x8]
     b5c:      	str	wzr, [x20, #0x24]
     b60:      	ccmp	x8, x13, #0x2, hi
     b64:      	csel	x28, x10, xzr, ls
     b68:      	cmp	x28, #0x20
     b6c:      	b.lo	0xbd8 <_llm_rows.packet_batch.blocks+0x1c4>
     b70:      	ldr	x27, [sp, #0x1e0]
     b74:      	mov	x0, x27
     b78:      	mov	x1, x20
     b7c:      	bl	0xb7c <_llm_rows.packet_batch.blocks+0x168>
     b80:      	mov	w8, #0x8                ; =8
     b84:      	str	w8, [x20, #0x24]
     b88:      	mov	x0, x27
     b8c:      	mov	x1, x20
     b90:      	bl	0xb90 <_llm_rows.packet_batch.blocks+0x17c>
     b94:      	mov	w8, #0x10               ; =16
     b98:      	str	w8, [x20, #0x24]
     b9c:      	mov	x0, x27
     ba0:      	mov	x1, x20
     ba4:      	bl	0xba4 <_llm_rows.packet_batch.blocks+0x190>
     ba8:      	mov	w8, #0x18               ; =24
     bac:      	str	w8, [x20, #0x24]
     bb0:      	mov	x0, x27
     bb4:      	mov	x1, x20
     bb8:      	bl	0xbb8 <_llm_rows.packet_batch.blocks+0x1a4>
     bbc:      	add	x5, sp, #0xb60
     bc0:      	adrp	x1, 0x0 <ltmp0>
     bc4:      	adrp	x0, 0x0 <ltmp0>
     bc8:      	adrp	x17, 0x0 <ltmp0>
     bcc:      	adrp	x16, 0x0 <ltmp0>
     bd0:      	add	x4, sp, #0xda0
     bd4:      	b	0xaec <_llm_rows.packet_batch.blocks+0xd8>
     bd8:      	lsr	x27, x28, #3
     bdc:      	cmp	x28, #0x8
     be0:      	b.lo	0xc74 <_llm_rows.packet_batch.blocks+0x260>
     be4:      	str	wzr, [x20, #0x24]
     be8:      	ldr	x0, [sp, #0x1e0]
     bec:      	mov	x1, x20
     bf0:      	bl	0xbf0 <_llm_rows.packet_batch.blocks+0x1dc>
     bf4:      	add	x5, sp, #0xb60
     bf8:      	adrp	x1, 0x0 <ltmp0>
     bfc:      	adrp	x0, 0x0 <ltmp0>
     c00:      	adrp	x17, 0x0 <ltmp0>
     c04:      	adrp	x16, 0x0 <ltmp0>
     c08:      	add	x4, sp, #0xda0
     c0c:      	cmp	x27, #0x1
     c10:      	b.eq	0xc74 <_llm_rows.packet_batch.blocks+0x260>
     c14:      	mov	w8, #0x8                ; =8
     c18:      	str	w8, [x20, #0x24]
     c1c:      	ldr	x0, [sp, #0x1e0]
     c20:      	mov	x1, x20
     c24:      	bl	0xc24 <_llm_rows.packet_batch.blocks+0x210>
     c28:      	add	x5, sp, #0xb60
     c2c:      	adrp	x1, 0x0 <ltmp0>
     c30:      	adrp	x0, 0x0 <ltmp0>
     c34:      	adrp	x17, 0x0 <ltmp0>
     c38:      	adrp	x16, 0x0 <ltmp0>
     c3c:      	add	x4, sp, #0xda0
     c40:      	cmp	x27, #0x2
     c44:      	b.eq	0xc74 <_llm_rows.packet_batch.blocks+0x260>
     c48:      	mov	w8, #0x10               ; =16
     c4c:      	str	w8, [x20, #0x24]
     c50:      	ldr	x0, [sp, #0x1e0]
     c54:      	mov	x1, x20
     c58:      	bl	0xc58 <_llm_rows.packet_batch.blocks+0x244>
     c5c:      	add	x5, sp, #0xb60
     c60:      	adrp	x1, 0x0 <ltmp0>
     c64:      	adrp	x0, 0x0 <ltmp0>
     c68:      	adrp	x17, 0x0 <ltmp0>
     c6c:      	adrp	x16, 0x0 <ltmp0>
     c70:      	add	x4, sp, #0xda0
     c74:      	and	w8, w28, #0x7
     c78:      	cbz	w8, 0xae4 <_llm_rows.packet_batch.blocks+0xd0>
     c7c:      	dup.4s	v5, w8
     c80:      	ldp	q0, q1, [sp, #0x140]
     c84:      	cmhi.4s	v0, v5, v0
     c88:      	cmhi.4s	v1, v5, v1
     c8c:      	uzp1.8h	v3, v1, v0
     c90:      	umaxv.8h	h2, v3
     c94:      	fmov	w8, s2
     c98:      	tbz	w8, #0x0, 0xae4 <_llm_rows.packet_batch.blocks+0xd0>
     c9c:      	mov	x8, #0x0                ; =0
     ca0:      	ldr	x10, [sp, #0x1e0]
     ca4:      	ldr	x9, [x10]
     ca8:      	ldr	x10, [x10, #0x30]
     cac:      	str	x10, [sp, #0x130]
     cb0:      	ldr	q2, [sp, #0x10]
     cb4:      	str	q3, [sp, #0x190]
     cb8:      	and.16b	v2, v3, v2
     cbc:      	addv.8h	h23, v2
     cc0:      	fmov	w10, s23
     cc4:      	and	w10, w10, #0xff
     cc8:      	str	w10, [sp, #0xc0]
     ccc:      	xtn.4h	v3, v1
     cd0:      	uzp1.8b	v2, v3, v0
     cd4:      	ubfiz	w10, w24, #2, #27
     cd8:      	orr	w11, w10, w27
     cdc:      	dup.4s	v4, w11
     ce0:      	and.16b	v22, v1, v4
     ce4:      	and.16b	v24, v0, v4
     ce8:      	ushll2.2d	v16, v24, #0x0
     cec:      	ushll2.2d	v17, v22, #0x0
     cf0:      	ushll.2d	v18, v24, #0x0
     cf4:      	umov.b	w10, v2[0]
     cf8:      	ushll.2d	v19, v22, #0x0
     cfc:      	mov	w12, #0x104             ; =260
     d00:      	umull	x11, w11, w12
     d04:      	tst	w10, #0x1
     d08:      	csel	x11, x11, xzr, ne
     d0c:      	str	x11, [sp, #0x128]
     d10:      	add	x11, x9, x11
     d14:      	fmov	w12, s23
     d18:      	b	0xd3c <_llm_rows.packet_batch.blocks+0x328>
     d1c:      	add	x13, x4, x8
     d20:      	ldp	q6, q7, [x13]
     d24:      	bif.16b	v4, v7, v0
     d28:      	bif.16b	v2, v6, v1
     d2c:      	stp	q2, q4, [x13]
     d30:      	add	x8, x8, #0x20
     d34:      	cmp	x8, #0x100
     d38:      	b.eq	0xdd0 <_llm_rows.packet_batch.blocks+0x3bc>
     d3c:      	add	x13, x11, x8
     d40:      	movi.2d	v2, #0000000000000000
     d44:      	movi.2d	v4, #0000000000000000
     d48:      	tbnz	w12, #0x0, 0xd70 <_llm_rows.packet_batch.blocks+0x35c>
     d4c:      	and	w14, w12, #0xff
     d50:      	tbnz	w14, #0x1, 0xd7c <_llm_rows.packet_batch.blocks+0x368>
     d54:      	tbnz	w14, #0x2, 0xd88 <_llm_rows.packet_batch.blocks+0x374>
     d58:      	tbnz	w14, #0x3, 0xd94 <_llm_rows.packet_batch.blocks+0x380>
     d5c:      	tbnz	w14, #0x4, 0xda0 <_llm_rows.packet_batch.blocks+0x38c>
     d60:      	tbnz	w14, #0x5, 0xdac <_llm_rows.packet_batch.blocks+0x398>
     d64:      	tbnz	w14, #0x6, 0xdb8 <_llm_rows.packet_batch.blocks+0x3a4>
     d68:      	tbz	w14, #0x7, 0xd1c <_llm_rows.packet_batch.blocks+0x308>
     d6c:      	b	0xdc4 <_llm_rows.packet_batch.blocks+0x3b0>
     d70:      	ldr	s2, [x13]
     d74:      	and	w14, w12, #0xff
     d78:      	tbz	w14, #0x1, 0xd54 <_llm_rows.packet_batch.blocks+0x340>
     d7c:      	add	x15, x13, #0x4
     d80:      	ld1.s	{ v2 }[1], [x15]
     d84:      	tbz	w14, #0x2, 0xd58 <_llm_rows.packet_batch.blocks+0x344>
     d88:      	add	x15, x13, #0x8
     d8c:      	ld1.s	{ v2 }[2], [x15]
     d90:      	tbz	w14, #0x3, 0xd5c <_llm_rows.packet_batch.blocks+0x348>
     d94:      	add	x15, x13, #0xc
     d98:      	ld1.s	{ v2 }[3], [x15]
     d9c:      	tbz	w14, #0x4, 0xd60 <_llm_rows.packet_batch.blocks+0x34c>
     da0:      	add	x15, x13, #0x10
     da4:      	ld1.s	{ v4 }[0], [x15]
     da8:      	tbz	w14, #0x5, 0xd64 <_llm_rows.packet_batch.blocks+0x350>
     dac:      	add	x15, x13, #0x14
     db0:      	ld1.s	{ v4 }[1], [x15]
     db4:      	tbz	w14, #0x6, 0xd68 <_llm_rows.packet_batch.blocks+0x354>
     db8:      	add	x15, x13, #0x18
     dbc:      	ld1.s	{ v4 }[2], [x15]
     dc0:      	tbz	w14, #0x7, 0xd1c <_llm_rows.packet_batch.blocks+0x308>
     dc4:      	add	x13, x13, #0x1c
     dc8:      	ld1.s	{ v4 }[3], [x13]
     dcc:      	b	0xd1c <_llm_rows.packet_batch.blocks+0x308>
     dd0:      	uzp1.8b	v2, v3, v0
     dd4:      	sshll.2d	v4, v1, #0x0
     dd8:      	movi.2d	v15, #0000000000000000
     ddc:      	mov.b	v15[0], v2[0]
     de0:      	adrp	x8, 0x0 <ltmp0>
     de4:      	ldr	d6, [x8]
     de8:      	and.8b	v3, v15, v6
     dec:      	addv.8b	b3, v3
     df0:      	fmov	w8, s3
     df4:      	umaxv.8b	b3, v15
     df8:      	fmov	w11, s3
     dfc:      	rbit	w12, w8
     e00:      	clz	w12, w12
     e04:      	tst	w11, #0x1
     e08:      	csel	w6, w12, wzr, ne
     e0c:      	adrp	x12, 0x0 <ltmp0>
     e10:      	ldr	q7, [x12]
     e14:      	mov	w12, #0x40              ; =64
     e18:      	dup.2d	v28, x12
     e1c:      	mov.16b	v20, v4
     e20:      	bsl.16b	v20, v7, v28
     e24:      	xtn.2s	v3, v19
     e28:      	umlal.2d	v20, v3, v8
     e2c:      	movi.2d	v3, #0000000000000000
     e30:      	mov.b	v3[0], v2[0]
     e34:      	ushll.2d	v2, v3, #0x0
     e38:      	shl.2d	v2, v2, #0x3f
     e3c:      	cmlt.2d	v2, v2, #0
     e40:      	str	q20, [sp, #0x110]
     e44:      	and.16b	v2, v2, v20
     e48:      	movi.2d	v3, #0000000000000000
     e4c:      	str	q3, [sp, #0x8c0]
     e50:      	str	q3, [sp, #0x8b0]
     e54:      	str	q3, [sp, #0x8a0]
     e58:      	str	q2, [sp, #0x890]
     e5c:      	and	x12, x6, #0x7
     e60:      	add	x13, sp, #0x890
     e64:      	ldr	x12, [x13, x12, lsl #3]
     e68:      	sub	x12, x12, x6
     e6c:      	add	x9, x9, x12, lsl #2
     e70:      	movi.2d	v11, #0000000000000000
     e74:      	movi.2d	v12, #0000000000000000
     e78:      	tbnz	w11, #0x0, 0x1610 <_llm_rows.packet_batch.blocks+0xbfc>
     e7c:      	tbnz	w8, #0x1, 0x1618 <_llm_rows.packet_batch.blocks+0xc04>
     e80:      	tbnz	w8, #0x2, 0x1624 <_llm_rows.packet_batch.blocks+0xc10>
     e84:      	tbnz	w8, #0x3, 0x1630 <_llm_rows.packet_batch.blocks+0xc1c>
     e88:      	tbnz	w8, #0x4, 0x163c <_llm_rows.packet_batch.blocks+0xc28>
     e8c:      	tbnz	w8, #0x5, 0x1648 <_llm_rows.packet_batch.blocks+0xc34>
     e90:      	tbnz	w8, #0x6, 0x1654 <_llm_rows.packet_batch.blocks+0xc40>
     e94:      	tbz	w8, #0x7, 0xea0 <_llm_rows.packet_batch.blocks+0x48c>
     e98:      	add	x9, x9, #0x1c
     e9c:      	ld1.s	{ v12 }[3], [x9]
     ea0:      	mov	x9, #0x0                ; =0
     ea4:      	sshll.2d	v2, v0, #0x0
     ea8:      	sshll2.2d	v9, v1, #0x0
     eac:      	sshll2.2d	v10, v0, #0x0
     eb0:      	adrp	x11, 0x0 <ltmp0>
     eb4:      	ldr	q3, [x11]
     eb8:      	and.16b	v3, v10, v3
     ebc:      	adrp	x11, 0x0 <ltmp0>
     ec0:      	ldr	q19, [x11]
     ec4:      	and.16b	v19, v9, v19
     ec8:      	adrp	x11, 0x0 <ltmp0>
     ecc:      	ldr	q20, [x11]
     ed0:      	and.16b	v20, v2, v20
     ed4:      	adrp	x11, 0x0 <ltmp0>
     ed8:      	ldr	q21, [x11]
     edc:      	and.16b	v4, v4, v21
     ee0:      	adrp	x11, 0x0 <ltmp0>
     ee4:      	ldr	q25, [x11]
     ee8:      	mov.16b	v21, v2
     eec:      	bsl.16b	v21, v25, v28
     ef0:      	adrp	x11, 0x0 <ltmp0>
     ef4:      	ldr	q27, [x11]
     ef8:      	mov.16b	v29, v9
     efc:      	bsl.16b	v29, v27, v28
     f00:      	adrp	x11, 0x0 <ltmp0>
     f04:      	ldr	q26, [x11]
     f08:      	bit.16b	v28, v26, v10
     f0c:      	xtn.2s	v2, v18
     f10:      	xtn.2s	v17, v17
     f14:      	xtn.2s	v16, v16
     f18:      	umlal.2d	v28, v16, v8
     f1c:      	umlal.2d	v29, v17, v8
     f20:      	stp	q28, q29, [sp, #0xe0]
     f24:      	umlal.2d	v21, v2, v8
     f28:      	str	q21, [sp, #0x100]
     f2c:      	str	q4, [sp, #0x850]
     f30:      	str	q19, [sp, #0x860]
     f34:      	str	q20, [sp, #0x870]
     f38:      	str	q3, [sp, #0x880]
     f3c:      	and	x11, x6, #0x7
     f40:      	add	x12, sp, #0x850
     f44:      	ldr	x11, [x12, x11, lsl #3]
     f48:      	orr	x11, x11, #0x100
     f4c:      	sub	x11, x11, x6, lsl #2
     f50:      	tst	w8, #0xff
     f54:      	csel	x7, xzr, x11, eq
     f58:      	add	x11, x4, x7
     f5c:      	ldp	q2, q3, [x11]
     f60:      	zip2.8b	v4, v15, v0
     f64:      	ushll.4s	v4, v4, #0x0
     f68:      	shl.4s	v4, v4, #0x1f
     f6c:      	cmlt.4s	v4, v4, #0
     f70:      	bit.16b	v3, v12, v4
     f74:      	zip1.8b	v4, v15, v0
     f78:      	ushll.4s	v4, v4, #0x0
     f7c:      	shl.4s	v4, v4, #0x1f
     f80:      	cmlt.4s	v4, v4, #0
     f84:      	bit.16b	v2, v11, v4
     f88:      	stp	q2, q3, [x11]
     f8c:      	ushll2.2d	v2, v0, #0x0
     f90:      	mov	w11, #0x1               ; =1
     f94:      	dup.2d	v3, x11
     f98:      	and.16b	v30, v2, v3
     f9c:      	ushll2.2d	v2, v1, #0x0
     fa0:      	and.16b	v31, v2, v3
     fa4:      	ushll.2d	v2, v0, #0x0
     fa8:      	and.16b	v13, v2, v3
     fac:      	ushll.2d	v2, v1, #0x0
     fb0:      	and.16b	v28, v2, v3
     fb4:      	movi.2d	v2, #0000000000000000
     fb8:      	and	x12, x10, #0x1
     fbc:      	movi.2d	v3, #0000000000000000
     fc0:      	movi.2d	v4, #0000000000000000
     fc4:      	movi.2d	v16, #0000000000000000
     fc8:      	stp	q31, q30, [sp, #0x280]
     fcc:      	str	q28, [sp, #0x260]
     fd0:      	sshll.2d	v17, v0, #0x0
     fd4:      	sshll.2d	v18, v1, #0x0
     fd8:      	shl.2d	v19, v16, #0x3
     fdc:      	shl.2d	v20, v2, #0x3
     fe0:      	shl.2d	v21, v4, #0x3
     fe4:      	shl.2d	v28, v3, #0x3
     fe8:      	ldr	q29, [x16]
     fec:      	orr.16b	v28, v28, v29
     ff0:      	ldr	q29, [x17]
     ff4:      	orr.16b	v21, v21, v29
     ff8:      	ldr	q29, [x0]
     ffc:      	orr.16b	v20, v20, v29
    1000:      	ldr	q29, [x1]
    1004:      	orr.16b	v19, v19, v29
    1008:      	add	x9, x5, x9, lsl #6
    100c:      	ldp	q30, q29, [x9]
    1010:      	ldp	q31, q8, [x9, #0x20]
    1014:      	bif.16b	v19, v8, v10
    1018:      	bsl.16b	v18, v20, v30
    101c:      	bsl.16b	v17, v21, v31
    1020:      	ldp	q31, q30, [sp, #0x280]
    1024:      	mov.16b	v20, v9
    1028:      	bsl.16b	v20, v28, v29
    102c:      	ldr	q28, [sp, #0x260]
    1030:      	stp	q18, q20, [x9]
    1034:      	stp	q17, q19, [x9, #0x20]
    1038:      	add.2d	v17, v2, v28
    103c:      	add.2d	v3, v3, v31
    1040:      	add.2d	v4, v4, v13
    1044:      	add.2d	v16, v16, v30
    1048:      	fmov	x9, d2
    104c:      	add	x9, x9, x12
    1050:      	mov.16b	v2, v17
    1054:      	cmp	x9, #0x8
    1058:      	b.lt	0xfd0 <_llm_rows.packet_batch.blocks+0x5bc>
    105c:      	mov	x9, #0x0                ; =0
    1060:      	movi.4s	v4, #0x41
    1064:      	and.16b	v2, v1, v4
    1068:      	mvn.16b	v3, v1
    106c:      	sub.4s	v2, v2, v3
    1070:      	and.16b	v3, v0, v4
    1074:      	mvn.16b	v4, v0
    1078:      	sub.4s	v3, v3, v4
    107c:      	mov.s	w11, v3[1]
    1080:      	mov.s	w13, v24[1]
    1084:      	udiv	w14, w13, w11
    1088:      	msub	w13, w14, w11, w13
    108c:      	mov.s	w11, v3[2]
    1090:      	mov.s	w14, v3[3]
    1094:      	fmov	w15, s3
    1098:      	fmov	w16, s24
    109c:      	udiv	w17, w16, w15
    10a0:      	msub	w15, w17, w15, w16
    10a4:      	mov.s	w16, v24[2]
    10a8:      	udiv	w17, w16, w11
    10ac:      	msub	w16, w17, w11, w16
    10b0:      	mov.s	w11, v24[3]
    10b4:      	udiv	w17, w11, w14
    10b8:      	msub	w14, w17, w14, w11
    10bc:      	mov.s	w11, v2[1]
    10c0:      	mov.s	w17, v22[1]
    10c4:      	udiv	w0, w17, w11
    10c8:      	msub	w17, w0, w11, w17
    10cc:      	mov.s	w11, v2[2]
    10d0:      	mov.s	w0, v2[3]
    10d4:      	fmov	w1, s2
    10d8:      	fmov	w2, s22
    10dc:      	udiv	w3, w2, w1
    10e0:      	msub	w1, w3, w1, w2
    10e4:      	mov.s	w2, v22[2]
    10e8:      	udiv	w3, w2, w11
    10ec:      	msub	w11, w3, w11, w2
    10f0:      	mov.s	w2, v22[3]
    10f4:      	udiv	w3, w2, w0
    10f8:      	msub	w0, w3, w0, w2
    10fc:      	tst	w8, #0xff
    1100:      	fmov	s2, w15
    1104:      	mov.s	v2[1], w13
    1108:      	mov.s	v2[2], w16
    110c:      	mov.s	v2[3], w14
    1110:      	fmov	s3, w1
    1114:      	sshll.2d	v19, v0, #0x0
    1118:      	sshll.2d	v18, v1, #0x0
    111c:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5ec>
    1120:      	ldr	q4, [x8]
    1124:      	and.16b	v4, v18, v4
    1128:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5ec>
    112c:      	ldr	q16, [x8]
    1130:      	and.16b	v16, v19, v16
    1134:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5ec>
    1138:      	ldr	q17, [x8]
    113c:      	and.16b	v17, v9, v17
    1140:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5ec>
    1144:      	ldr	q20, [x8]
    1148:      	and.16b	v20, v10, v20
    114c:      	str	q20, [sp, #0x840]
    1150:      	str	q16, [sp, #0x830]
    1154:      	str	q17, [sp, #0x820]
    1158:      	str	q4, [sp, #0x810]
    115c:      	mov.s	v3[1], w17
    1160:      	and	x8, x6, #0x7
    1164:      	add	x13, sp, #0x810
    1168:      	ldr	x8, [x13, x8, lsl #3]
    116c:      	orr	x8, x8, #0x200
    1170:      	sub	x8, x8, x6, lsl #3
    1174:      	csel	x8, xzr, x8, eq
    1178:      	add	x8, x5, x8
    117c:      	ldp	q16, q17, [x8, #0x20]
    1180:      	mov	b4, v15[2]
    1184:      	mov.b	v4[4], v15[3]
    1188:      	ldp	q20, q21, [x8]
    118c:      	ushll.2d	v4, v4, #0x0
    1190:      	shl.2d	v4, v4, #0x3f
    1194:      	cmlt.2d	v4, v4, #0
    1198:      	bsl.16b	v4, v27, v21
    119c:      	mov	b21, v15[0]
    11a0:      	mov.b	v21[4], v15[1]
    11a4:      	ushll.2d	v21, v21, #0x0
    11a8:      	shl.2d	v21, v21, #0x3f
    11ac:      	cmlt.2d	v21, v21, #0
    11b0:      	bif.16b	v7, v20, v21
    11b4:      	mov	b20, v15[6]
    11b8:      	mov.b	v20[4], v15[7]
    11bc:      	ushll.2d	v20, v20, #0x0
    11c0:      	shl.2d	v20, v20, #0x3f
    11c4:      	cmlt.2d	v20, v20, #0
    11c8:      	mov.16b	v22, v20
    11cc:      	bsl.16b	v22, v26, v17
    11d0:      	mov	b17, v15[4]
    11d4:      	mov.b	v17[4], v15[5]
    11d8:      	ushll.2d	v17, v17, #0x0
    11dc:      	shl.2d	v17, v17, #0x3f
    11e0:      	cmlt.2d	v17, v17, #0
    11e4:      	mov.16b	v8, v17
    11e8:      	bsl.16b	v8, v25, v16
    11ec:      	mov.s	v3[2], w11
    11f0:      	mov.s	v3[3], w0
    11f4:      	and.16b	v17, v1, v3
    11f8:      	stp	q8, q22, [x8, #0x20]
    11fc:      	stp	q7, q4, [x8]
    1200:      	and.16b	v16, v0, v2
    1204:      	ushll2.2d	v2, v16, #0x0
    1208:      	ushll2.2d	v3, v17, #0x0
    120c:      	ushll.2d	v16, v16, #0x0
    1210:      	ushll.2d	v17, v17, #0x0
    1214:      	ldr	q20, [sp, #0x20]
    1218:      	and.16b	v25, v10, v20
    121c:      	and.16b	v26, v9, v20
    1220:      	and.16b	v27, v19, v20
    1224:      	and.16b	v29, v18, v20
    1228:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5ec>
    122c:      	ldr	q20, [x8]
    1230:      	str	q10, [sp, #0x1a0]
    1234:      	and.16b	v20, v10, v20
    1238:      	str	q20, [sp, #0x2d0]
    123c:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5ec>
    1240:      	ldr	q20, [x8]
    1244:      	str	q9, [sp, #0x1b0]
    1248:      	and.16b	v20, v9, v20
    124c:      	str	q20, [sp, #0x2c0]
    1250:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5ec>
    1254:      	ldr	q20, [x8]
    1258:      	and.16b	v19, v19, v20
    125c:      	str	q19, [sp, #0x2b0]
    1260:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0x5ec>
    1264:      	ldr	q19, [x8]
    1268:      	and.16b	v18, v18, v19
    126c:      	str	q18, [sp, #0x2a0]
    1270:      	ldp	q18, q19, [sp, #0x140]
    1274:      	cmhs.4s	v18, v18, v5
    1278:      	cmhs.4s	v5, v19, v5
    127c:      	uzp1.8h	v5, v5, v18
    1280:      	xtn.8b	v5, v5
    1284:      	movi.2d	v18, #0000000000000000
    1288:      	movi.2d	v20, #0000000000000000
    128c:      	movi.2d	v21, #0000000000000000
    1290:      	movi.2d	v9, #0000000000000000
    1294:      	mov	w17, #0xf2ca            ; =62154
    1298:      	movk	w17, #0xf149, lsl #16
    129c:      	mov	w0, #0x4                ; =4
    12a0:      	str	q13, [sp, #0x270]
    12a4:      	b	0x12cc <_llm_rows.packet_batch.blocks+0x8b8>
    12a8:      	add.2d	v19, v18, v28
    12ac:      	add.2d	v20, v20, v31
    12b0:      	add.2d	v21, v21, v13
    12b4:      	add.2d	v9, v9, v30
    12b8:      	fmov	x8, d18
    12bc:      	add	x9, x8, x12
    12c0:      	mov.16b	v18, v19
    12c4:      	cmp	x9, #0x8
    12c8:      	b.ge	0x13ec <_llm_rows.packet_batch.blocks+0x9d8>
    12cc:      	fmov	w8, s23
    12d0:      	add	x9, x5, x9, lsl #6
    12d4:      	ldp	q24, q19, [x9, #0x20]
    12d8:      	ldp	q10, q13, [x9]
    12dc:      	cmge.2d	v13, v3, v13
    12e0:      	cmge.2d	v10, v17, v10
    12e4:      	uzp1.4s	v10, v10, v13
    12e8:      	cmge.2d	v24, v16, v24
    12ec:      	cmge.2d	v19, v2, v19
    12f0:      	uzp1.4s	v19, v24, v19
    12f4:      	uzp1.8h	v19, v10, v19
    12f8:      	xtn.8b	v19, v19
    12fc:      	orr.8b	v19, v5, v19
    1300:      	ldr	q24, [sp, #0x2a0]
    1304:      	add.2d	v24, v18, v24
    1308:      	add.2d	v24, v29, v24
    130c:      	and.8b	v19, v19, v14
    1310:      	tbnz	w8, #0x0, 0x1360 <_llm_rows.packet_batch.blocks+0x94c>
    1314:      	and	w8, w8, #0xff
    1318:      	tbnz	w8, #0x1, 0x1370 <_llm_rows.packet_batch.blocks+0x95c>
    131c:      	ldr	q24, [sp, #0x2c0]
    1320:      	add.2d	v24, v20, v24
    1324:      	add.2d	v24, v26, v24
    1328:      	ldr	q13, [sp, #0x270]
    132c:      	tbnz	w8, #0x2, 0x138c <_llm_rows.packet_batch.blocks+0x978>
    1330:      	tbnz	w8, #0x3, 0x1398 <_llm_rows.packet_batch.blocks+0x984>
    1334:      	ldr	q24, [sp, #0x2b0]
    1338:      	add.2d	v24, v21, v24
    133c:      	add.2d	v24, v27, v24
    1340:      	tbnz	w8, #0x4, 0x13b0 <_llm_rows.packet_batch.blocks+0x99c>
    1344:      	tbnz	w8, #0x5, 0x13bc <_llm_rows.packet_batch.blocks+0x9a8>
    1348:      	ldr	q24, [sp, #0x2d0]
    134c:      	add.2d	v24, v9, v24
    1350:      	add.2d	v24, v25, v24
    1354:      	tbnz	w8, #0x6, 0x13d4 <_llm_rows.packet_batch.blocks+0x9c0>
    1358:      	tbz	w8, #0x7, 0x12a8 <_llm_rows.packet_batch.blocks+0x894>
    135c:      	b	0x13e0 <_llm_rows.packet_batch.blocks+0x9cc>
    1360:      	fmov	x9, d24
    1364:      	str	b19, [x9]
    1368:      	and	w8, w8, #0xff
    136c:      	tbz	w8, #0x1, 0x131c <_llm_rows.packet_batch.blocks+0x908>
    1370:      	mov.d	x9, v24[1]
    1374:      	st1.b	{ v19 }[1], [x9]
    1378:      	ldr	q24, [sp, #0x2c0]
    137c:      	add.2d	v24, v20, v24
    1380:      	add.2d	v24, v26, v24
    1384:      	ldr	q13, [sp, #0x270]
    1388:      	tbz	w8, #0x2, 0x1330 <_llm_rows.packet_batch.blocks+0x91c>
    138c:      	fmov	x9, d24
    1390:      	st1.b	{ v19 }[2], [x9]
    1394:      	tbz	w8, #0x3, 0x1334 <_llm_rows.packet_batch.blocks+0x920>
    1398:      	mov.d	x9, v24[1]
    139c:      	st1.b	{ v19 }[3], [x9]
    13a0:      	ldr	q24, [sp, #0x2b0]
    13a4:      	add.2d	v24, v21, v24
    13a8:      	add.2d	v24, v27, v24
    13ac:      	tbz	w8, #0x4, 0x1344 <_llm_rows.packet_batch.blocks+0x930>
    13b0:      	fmov	x9, d24
    13b4:      	st1.b	{ v19 }[4], [x9]
    13b8:      	tbz	w8, #0x5, 0x1348 <_llm_rows.packet_batch.blocks+0x934>
    13bc:      	mov.d	x9, v24[1]
    13c0:      	st1.b	{ v19 }[5], [x9]
    13c4:      	ldr	q24, [sp, #0x2d0]
    13c8:      	add.2d	v24, v9, v24
    13cc:      	add.2d	v24, v25, v24
    13d0:      	tbz	w8, #0x6, 0x1358 <_llm_rows.packet_batch.blocks+0x944>
    13d4:      	fmov	x9, d24
    13d8:      	st1.b	{ v19 }[6], [x9]
    13dc:      	tbz	w8, #0x7, 0x12a8 <_llm_rows.packet_batch.blocks+0x894>
    13e0:      	mov.d	x8, v24[1]
    13e4:      	st1.b	{ v19 }[7], [x8]
    13e8:      	b	0x12a8 <_llm_rows.packet_batch.blocks+0x894>
    13ec:      	cmge.2d	v5, v17, v7
    13f0:      	cmge.2d	v3, v3, v4
    13f4:      	uzp1.4s	v3, v5, v3
    13f8:      	cmge.2d	v4, v16, v8
    13fc:      	cmge.2d	v2, v2, v22
    1400:      	uzp1.4s	v2, v4, v2
    1404:      	uzp1.8h	v2, v3, v2
    1408:      	xtn.8b	v2, v2
    140c:      	shl.8b	v3, v15, #0x7
    1410:      	cmlt.8b	v3, v3, #0
    1414:      	and.8b	v3, v3, v6
    1418:      	addv.8b	b19, v3
    141c:      	fmov	w11, s19
    1420:      	orn.8b	v2, v2, v15
    1424:      	ldr	q3, [sp, #0x2a0]
    1428:      	add.2d	v4, v3, v29
    142c:      	mov	w8, #0x8                ; =8
    1430:      	dup.2d	v3, x8
    1434:      	add.2d	v7, v4, v3
    1438:      	and.8b	v2, v2, v14
    143c:      	tbnz	w11, #0x0, 0x1664 <_llm_rows.packet_batch.blocks+0xc50>
    1440:      	mov.d	x14, v7[1]
    1444:      	tbnz	w11, #0x1, 0x1674 <_llm_rows.packet_batch.blocks+0xc60>
    1448:      	ldr	q4, [sp, #0x2c0]
    144c:      	add.2d	v4, v4, v26
    1450:      	add.2d	v6, v4, v3
    1454:      	tbnz	w11, #0x2, 0x1688 <_llm_rows.packet_batch.blocks+0xc74>
    1458:      	mov.d	x13, v6[1]
    145c:      	tbnz	w11, #0x3, 0x1698 <_llm_rows.packet_batch.blocks+0xc84>
    1460:      	ldr	q4, [sp, #0x2b0]
    1464:      	add.2d	v4, v4, v27
    1468:      	add.2d	v5, v4, v3
    146c:      	tbnz	w11, #0x4, 0x16ac <_llm_rows.packet_batch.blocks+0xc98>
    1470:      	mov.d	x9, v5[1]
    1474:      	tbnz	w11, #0x5, 0x16bc <_llm_rows.packet_batch.blocks+0xca8>
    1478:      	ldr	q4, [sp, #0x2d0]
    147c:      	add.2d	v4, v4, v25
    1480:      	add.2d	v4, v4, v3
    1484:      	tbnz	w11, #0x6, 0x16d0 <_llm_rows.packet_batch.blocks+0xcbc>
    1488:      	mov.d	x8, v4[1]
    148c:      	tbz	w11, #0x7, 0x1494 <_llm_rows.packet_batch.blocks+0xa80>
    1490:      	st1.b	{ v2 }[7], [x8]
    1494:      	mov	x11, #0x0               ; =0
    1498:      	movi.2d	v22, #0000000000000000
    149c:      	movi.2d	v8, #0000000000000000
    14a0:      	movi.2d	v9, #0000000000000000
    14a4:      	movi.2d	v10, #0000000000000000
    14a8:      	b	0x1514 <_llm_rows.packet_batch.blocks+0xb00>
    14ac:      	cmeq.8b	v2, v2, #0
    14b0:      	sshll.8h	v2, v2, #0x0
    14b4:      	sshll2.4s	v3, v2, #0x0
    14b8:      	sshll.4s	v16, v2, #0x0
    14bc:      	lsl	x11, x11, #5
    14c0:      	add	x15, x4, x11
    14c4:      	ldp	q17, q2, [x15]
    14c8:      	and.16b	v18, v0, v2
    14cc:      	dup.4s	v2, w17
    14d0:      	and.16b	v17, v1, v17
    14d4:      	bsl.16b	v16, v2, v17
    14d8:      	bsl.16b	v3, v2, v18
    14dc:      	add	x11, x26, x11
    14e0:      	ldp	q17, q18, [x11]
    14e4:      	bif.16b	v3, v18, v0
    14e8:      	bif.16b	v16, v17, v1
    14ec:      	stp	q16, q3, [x11]
    14f0:      	add.2d	v3, v22, v28
    14f4:      	add.2d	v8, v8, v31
    14f8:      	add.2d	v9, v9, v13
    14fc:      	add.2d	v10, v10, v30
    1500:      	fmov	x11, d22
    1504:      	add	x11, x11, x12
    1508:      	mov.16b	v22, v3
    150c:      	cmp	x11, #0x8
    1510:      	b.ge	0x15f0 <_llm_rows.packet_batch.blocks+0xbdc>
    1514:      	fmov	w15, s23
    1518:      	ldr	q2, [sp, #0x2a0]
    151c:      	add.2d	v2, v22, v2
    1520:      	add.2d	v3, v29, v2
    1524:      	tbz	w15, #0x0, 0x153c <_llm_rows.packet_batch.blocks+0xb28>
    1528:      	fmov	x16, d3
    152c:      	ldr	b2, [x16]
    1530:      	and	w15, w15, #0xff
    1534:      	tbnz	w15, #0x1, 0x1548 <_llm_rows.packet_batch.blocks+0xb34>
    1538:      	b	0x1550 <_llm_rows.packet_batch.blocks+0xb3c>
    153c:      	movi.2d	v2, #0000000000000000
    1540:      	and	w15, w15, #0xff
    1544:      	tbz	w15, #0x1, 0x1550 <_llm_rows.packet_batch.blocks+0xb3c>
    1548:      	mov.d	x16, v3[1]
    154c:      	ld1.b	{ v2 }[1], [x16]
    1550:      	ldr	q3, [sp, #0x2c0]
    1554:      	add.2d	v3, v8, v3
    1558:      	add.2d	v3, v26, v3
    155c:      	tbnz	w15, #0x2, 0x1590 <_llm_rows.packet_batch.blocks+0xb7c>
    1560:      	tbnz	w15, #0x3, 0x159c <_llm_rows.packet_batch.blocks+0xb88>
    1564:      	ldr	q3, [sp, #0x2b0]
    1568:      	add.2d	v3, v9, v3
    156c:      	add.2d	v3, v27, v3
    1570:      	tbnz	w15, #0x4, 0x15b4 <_llm_rows.packet_batch.blocks+0xba0>
    1574:      	tbnz	w15, #0x5, 0x15c0 <_llm_rows.packet_batch.blocks+0xbac>
    1578:      	ldr	q3, [sp, #0x2d0]
    157c:      	add.2d	v3, v10, v3
    1580:      	add.2d	v3, v25, v3
    1584:      	tbnz	w15, #0x6, 0x15d8 <_llm_rows.packet_batch.blocks+0xbc4>
    1588:      	tbz	w15, #0x7, 0x14ac <_llm_rows.packet_batch.blocks+0xa98>
    158c:      	b	0x15e4 <_llm_rows.packet_batch.blocks+0xbd0>
    1590:      	fmov	x16, d3
    1594:      	ld1.b	{ v2 }[2], [x16]
    1598:      	tbz	w15, #0x3, 0x1564 <_llm_rows.packet_batch.blocks+0xb50>
    159c:      	mov.d	x16, v3[1]
    15a0:      	ld1.b	{ v2 }[3], [x16]
    15a4:      	ldr	q3, [sp, #0x2b0]
    15a8:      	add.2d	v3, v9, v3
    15ac:      	add.2d	v3, v27, v3
    15b0:      	tbz	w15, #0x4, 0x1574 <_llm_rows.packet_batch.blocks+0xb60>
    15b4:      	fmov	x16, d3
    15b8:      	ld1.b	{ v2 }[4], [x16]
    15bc:      	tbz	w15, #0x5, 0x1578 <_llm_rows.packet_batch.blocks+0xb64>
    15c0:      	mov.d	x16, v3[1]
    15c4:      	ld1.b	{ v2 }[5], [x16]
    15c8:      	ldr	q3, [sp, #0x2d0]
    15cc:      	add.2d	v3, v10, v3
    15d0:      	add.2d	v3, v25, v3
    15d4:      	tbz	w15, #0x6, 0x1588 <_llm_rows.packet_batch.blocks+0xb74>
    15d8:      	fmov	x16, d3
    15dc:      	ld1.b	{ v2 }[6], [x16]
    15e0:      	tbz	w15, #0x7, 0x14ac <_llm_rows.packet_batch.blocks+0xa98>
    15e4:      	mov.d	x15, v3[1]
    15e8:      	ld1.b	{ v2 }[7], [x15]
    15ec:      	b	0x14ac <_llm_rows.packet_batch.blocks+0xa98>
    15f0:      	str	d19, [sp, #0xd8]
    15f4:      	fmov	w11, s19
    15f8:      	tbz	w11, #0x0, 0x16e4 <_llm_rows.packet_batch.blocks+0xcd0>
    15fc:      	fmov	x15, d7
    1600:      	ldr	b3, [x15]
    1604:      	ldp	q19, q18, [sp, #0x1a0]
    1608:      	tbnz	w11, #0x1, 0x16f0 <_llm_rows.packet_batch.blocks+0xcdc>
    160c:      	b	0x16f4 <_llm_rows.packet_batch.blocks+0xce0>
    1610:      	ldr	s11, [x9]
    1614:      	tbz	w8, #0x1, 0xe80 <_llm_rows.packet_batch.blocks+0x46c>
    1618:      	add	x11, x9, #0x4
    161c:      	ld1.s	{ v11 }[1], [x11]
    1620:      	tbz	w8, #0x2, 0xe84 <_llm_rows.packet_batch.blocks+0x470>
    1624:      	add	x11, x9, #0x8
    1628:      	ld1.s	{ v11 }[2], [x11]
    162c:      	tbz	w8, #0x3, 0xe88 <_llm_rows.packet_batch.blocks+0x474>
    1630:      	add	x11, x9, #0xc
    1634:      	ld1.s	{ v11 }[3], [x11]
    1638:      	tbz	w8, #0x4, 0xe8c <_llm_rows.packet_batch.blocks+0x478>
    163c:      	add	x11, x9, #0x10
    1640:      	ld1.s	{ v12 }[0], [x11]
    1644:      	tbz	w8, #0x5, 0xe90 <_llm_rows.packet_batch.blocks+0x47c>
    1648:      	add	x11, x9, #0x14
    164c:      	ld1.s	{ v12 }[1], [x11]
    1650:      	tbz	w8, #0x6, 0xe94 <_llm_rows.packet_batch.blocks+0x480>
    1654:      	add	x11, x9, #0x18
    1658:      	ld1.s	{ v12 }[2], [x11]
    165c:      	tbnz	w8, #0x7, 0xe98 <_llm_rows.packet_batch.blocks+0x484>
    1660:      	b	0xea0 <_llm_rows.packet_batch.blocks+0x48c>
    1664:      	fmov	x8, d7
    1668:      	str	b2, [x8]
    166c:      	mov.d	x14, v7[1]
    1670:      	tbz	w11, #0x1, 0x1448 <_llm_rows.packet_batch.blocks+0xa34>
    1674:      	st1.b	{ v2 }[1], [x14]
    1678:      	ldr	q4, [sp, #0x2c0]
    167c:      	add.2d	v4, v4, v26
    1680:      	add.2d	v6, v4, v3
    1684:      	tbz	w11, #0x2, 0x1458 <_llm_rows.packet_batch.blocks+0xa44>
    1688:      	fmov	x8, d6
    168c:      	st1.b	{ v2 }[2], [x8]
    1690:      	mov.d	x13, v6[1]
    1694:      	tbz	w11, #0x3, 0x1460 <_llm_rows.packet_batch.blocks+0xa4c>
    1698:      	st1.b	{ v2 }[3], [x13]
    169c:      	ldr	q4, [sp, #0x2b0]
    16a0:      	add.2d	v4, v4, v27
    16a4:      	add.2d	v5, v4, v3
    16a8:      	tbz	w11, #0x4, 0x1470 <_llm_rows.packet_batch.blocks+0xa5c>
    16ac:      	fmov	x8, d5
    16b0:      	st1.b	{ v2 }[4], [x8]
    16b4:      	mov.d	x9, v5[1]
    16b8:      	tbz	w11, #0x5, 0x1478 <_llm_rows.packet_batch.blocks+0xa64>
    16bc:      	st1.b	{ v2 }[5], [x9]
    16c0:      	ldr	q4, [sp, #0x2d0]
    16c4:      	add.2d	v4, v4, v25
    16c8:      	add.2d	v4, v4, v3
    16cc:      	tbz	w11, #0x6, 0x1488 <_llm_rows.packet_batch.blocks+0xa74>
    16d0:      	fmov	x8, d4
    16d4:      	st1.b	{ v2 }[6], [x8]
    16d8:      	mov.d	x8, v4[1]
    16dc:      	tbnz	w11, #0x7, 0x1490 <_llm_rows.packet_batch.blocks+0xa7c>
    16e0:      	b	0x1494 <_llm_rows.packet_batch.blocks+0xa80>
    16e4:      	movi.2d	v3, #0000000000000000
    16e8:      	ldp	q19, q18, [sp, #0x1a0]
    16ec:      	tbz	w11, #0x1, 0x16f4 <_llm_rows.packet_batch.blocks+0xce0>
    16f0:      	ld1.b	{ v3 }[1], [x14]
    16f4:      	tbnz	w11, #0x2, 0x2968 <_llm_rows.packet_batch.blocks+0x1f54>
    16f8:      	tbnz	w11, #0x3, 0x2974 <_llm_rows.packet_batch.blocks+0x1f60>
    16fc:      	tbnz	w11, #0x4, 0x297c <_llm_rows.packet_batch.blocks+0x1f68>
    1700:      	tbnz	w11, #0x5, 0x2988 <_llm_rows.packet_batch.blocks+0x1f74>
    1704:      	tbnz	w11, #0x6, 0x2990 <_llm_rows.packet_batch.blocks+0x1f7c>
    1708:      	stp	q26, q25, [sp, #0x210]
    170c:      	stp	q29, q27, [sp, #0x1f0]
    1710:      	tbz	w11, #0x7, 0x1718 <_llm_rows.packet_batch.blocks+0xd04>
    1714:      	ld1.b	{ v3 }[7], [x8]
    1718:      	str	x24, [sp, #0x88]
    171c:      	str	x6, [sp, #0x120]
    1720:      	str	q23, [sp, #0x250]
    1724:      	str	w21, [sp, #0x138]
    1728:      	str	w22, [sp, #0x13c]
    172c:      	sshll.2d	v4, v1, #0x0
    1730:      	sshll.2d	v5, v0, #0x0
    1734:      	cmeq.8b	v3, v3, #0
    1738:      	sshll.8h	v6, v3, #0x0
    173c:      	sshll.4s	v3, v6, #0x0
    1740:      	str	q6, [sp, #0x60]
    1744:      	sshll2.4s	v6, v6, #0x0
    1748:      	str	q6, [sp, #0xa0]
    174c:      	mov.16b	v7, v6
    1750:      	bsl.16b	v7, v2, v12
    1754:      	mov.16b	v16, v3
    1758:      	bsl.16b	v16, v2, v11
    175c:      	str	x7, [sp, #0xd0]
    1760:      	add	x8, x26, x7
    1764:      	ldp	q3, q2, [x8]
    1768:      	zip1.8b	v6, v15, v0
    176c:      	ushll.4s	v6, v6, #0x0
    1770:      	shl.4s	v6, v6, #0x1f
    1774:      	cmlt.4s	v6, v6, #0
    1778:      	stp	q16, q7, [sp, #0x160]
    177c:      	bit.16b	v3, v16, v6
    1780:      	str	q15, [sp, #0x1c0]
    1784:      	zip2.8b	v6, v15, v0
    1788:      	ushll.4s	v6, v6, #0x0
    178c:      	shl.4s	v6, v6, #0x1f
    1790:      	cmlt.4s	v6, v6, #0
    1794:      	bit.16b	v2, v7, v6
    1798:      	stp	q3, q2, [x8]
    179c:      	dup.2d	v2, x0
    17a0:      	and.16b	v11, v19, v2
    17a4:      	and.16b	v12, v18, v2
    17a8:      	and.16b	v13, v5, v2
    17ac:      	and.16b	v14, v4, v2
    17b0:      	tst	w10, #0x1
    17b4:      	csel	x1, x0, xzr, ne
    17b8:      	ldp	q2, q3, [x23, #0x180]
    17bc:      	and.16b	v5, v0, v3
    17c0:      	and.16b	v4, v1, v2
    17c4:      	ldp	q2, q3, [x23, #0x160]
    17c8:      	and.16b	v6, v0, v3
    17cc:      	and.16b	v3, v1, v2
    17d0:      	ldp	q2, q7, [x23, #0x140]
    17d4:      	and.16b	v7, v0, v7
    17d8:      	and.16b	v2, v1, v2
    17dc:      	ldp	q17, q16, [x23, #0x120]
    17e0:      	and.16b	v16, v0, v16
    17e4:      	mov	x8, x1
    17e8:      	and.16b	v17, v1, v17
    17ec:      	mov.16b	v24, v14
    17f0:      	mov.16b	v20, v12
    17f4:      	mov.16b	v21, v13
    17f8:      	mov.16b	v22, v11
    17fc:      	mov.16b	v30, v18
    1800:      	mov.16b	v31, v19
    1804:      	sshll.2d	v8, v1, #0x0
    1808:      	sshll.2d	v9, v0, #0x0
    180c:      	add	x8, x26, x8, lsl #5
    1810:      	ldp	q18, q19, [x8]
    1814:      	and.16b	v10, v0, v19
    1818:      	and.16b	v18, v1, v18
    181c:      	fmaxnm.4s	v19, v17, v18
    1820:      	fmaxnm.4s	v18, v16, v10
    1824:      	ldp	q10, q15, [x8, #0x20]
    1828:      	and.16b	v15, v0, v15
    182c:      	and.16b	v10, v1, v10
    1830:      	fmaxnm.4s	v10, v2, v10
    1834:      	fmaxnm.4s	v15, v7, v15
    1838:      	ldp	q23, q25, [x8, #0x40]
    183c:      	and.16b	v25, v0, v25
    1840:      	and.16b	v23, v1, v23
    1844:      	fmaxnm.4s	v23, v3, v23
    1848:      	fmaxnm.4s	v25, v6, v25
    184c:      	ldp	q26, q27, [x8, #0x60]
    1850:      	and.16b	v27, v0, v27
    1854:      	and.16b	v26, v1, v26
    1858:      	fmaxnm.4s	v26, v4, v26
    185c:      	fmaxnm.4s	v27, v5, v27
    1860:      	dup.2d	v28, x0
    1864:      	and.16b	v29, v31, v28
    1868:      	add.2d	v22, v22, v29
    186c:      	and.16b	v29, v30, v28
    1870:      	add.2d	v20, v20, v29
    1874:      	and.16b	v29, v9, v28
    1878:      	add.2d	v21, v21, v29
    187c:      	and.16b	v28, v8, v28
    1880:      	add.2d	v28, v24, v28
    1884:      	bit.16b	v16, v18, v0
    1888:      	bit.16b	v17, v19, v1
    188c:      	bit.16b	v7, v15, v0
    1890:      	bit.16b	v2, v10, v1
    1894:      	bit.16b	v6, v25, v0
    1898:      	bit.16b	v3, v23, v1
    189c:      	bit.16b	v5, v27, v0
    18a0:      	bit.16b	v4, v26, v1
    18a4:      	fmov	x8, d24
    18a8:      	add	x9, x8, #0x4
    18ac:      	tst	w10, #0x1
    18b0:      	csel	x8, x9, x8, ne
    18b4:      	mov.16b	v24, v28
    18b8:      	cmp	x8, #0x8
    18bc:      	b.lt	0x1804 <_llm_rows.packet_batch.blocks+0xdf0>
    18c0:      	mov	x8, #0x0                ; =0
    18c4:      	ldr	q20, [sp, #0x190]
    18c8:      	xtn.8b	v24, v20
    18cc:      	ldr	q22, [sp, #0x1c0]
    18d0:      	zip2.8b	v20, v22, v0
    18d4:      	ushll.4s	v20, v20, #0x0
    18d8:      	shl.4s	v20, v20, #0x1f
    18dc:      	cmlt.4s	v20, v20, #0
    18e0:      	ldp	q23, q21, [sp, #0x160]
    18e4:      	and.16b	v21, v20, v21
    18e8:      	zip1.8b	v22, v22, v0
    18ec:      	ushll.4s	v22, v22, #0x0
    18f0:      	shl.4s	v22, v22, #0x1f
    18f4:      	cmlt.4s	v22, v22, #0
    18f8:      	and.16b	v23, v22, v23
    18fc:      	fmaxnm.4s	v17, v17, v23
    1900:      	fmaxnm.4s	v16, v16, v21
    1904:      	and.16b	v16, v20, v16
    1908:      	and.16b	v17, v22, v17
    190c:      	movi.2d	v20, #0000000000000000
    1910:      	mov.b	v20[2], v24[1]
    1914:      	mov.b	v20[4], v24[2]
    1918:      	mov.b	v20[6], v24[3]
    191c:      	ushll.4s	v20, v20, #0x0
    1920:      	shl.4s	v20, v20, #0x1f
    1924:      	cmlt.4s	v20, v20, #0
    1928:      	bit.16b	v17, v19, v20
    192c:      	zip2.8b	v19, v24, v0
    1930:      	ushll.4s	v19, v19, #0x0
    1934:      	shl.4s	v19, v19, #0x1f
    1938:      	cmlt.4s	v19, v19, #0
    193c:      	bit.16b	v16, v18, v19
    1940:      	fmaxnm.4s	v7, v16, v7
    1944:      	fmaxnm.4s	v2, v17, v2
    1948:      	fmaxnm.4s	v3, v2, v3
    194c:      	fmaxnm.4s	v2, v7, v6
    1950:      	fmaxnm.4s	v2, v2, v5
    1954:      	fmaxnm.4s	v3, v3, v4
    1958:      	umov.b	w20, v24[1]
    195c:      	and	w9, w10, w20
    1960:      	str	w9, [sp, #0x4c]
    1964:      	mov	s4, v3[1]
    1968:      	tst	w9, #0x1
    196c:      	movi	d20, #0000000000000000
    1970:      	fcsel	s4, s4, s20, ne
    1974:      	mvn	w9, w20
    1978:      	add	x11, sp, #0x538
    197c:      	bfxil	x11, x9, #0, #1
    1980:      	str	d24, [sp, #0x538]
    1984:      	ldrb	w11, [x11]
    1988:      	add	x13, sp, #0x7e0
    198c:      	bfi	x13, x9, #2, #1
    1990:      	str	q2, [sp, #0x7f0]
    1994:      	str	q3, [sp, #0x7e0]
    1998:      	ldr	s5, [x13]
    199c:      	and	w30, w20, #0x1
    19a0:      	tst	w30, w11
    19a4:      	fcsel	s5, s5, s20, ne
    19a8:      	umov.b	w25, v24[2]
    19ac:      	umov.b	w9, v24[3]
    19b0:      	str	x9, [sp, #0x40]
    19b4:      	ands	w9, w9, #0x1
    19b8:      	str	w9, [sp, #0x84]
    19bc:      	mov	w11, #0x1               ; =1
    19c0:      	cinc	w15, w11, ne
    19c4:      	cinc	w5, w11, eq
    19c8:      	mov	w13, #0x7               ; =7
    19cc:      	csel	w11, w13, w0, ne
    19d0:      	str	x11, [sp, #0xb0]
    19d4:      	ands	w14, w25, #0x1
    19d8:      	mov	w11, #0x3               ; =3
    19dc:      	csinc	w11, w11, wzr, ne
    19e0:      	add	x22, sp, #0x538
    19e4:      	orr	x16, x22, x11
    19e8:      	ldrb	w16, [x16]
    19ec:      	add	x17, sp, #0x7c0
    19f0:      	orr	x11, x17, x11, lsl #2
    19f4:      	str	q2, [sp, #0x7d0]
    19f8:      	str	q3, [sp, #0x7c0]
    19fc:      	ldr	s6, [x11]
    1a00:      	mov	w21, #0x2               ; =2
    1a04:      	mov	w17, #0x4               ; =4
    1a08:      	csel	w0, wzr, w21, ne
    1a0c:      	mov	w24, #0x6               ; =6
    1a10:      	csel	w11, w24, w17, ne
    1a14:      	str	x11, [sp, #0x98]
    1a18:      	tst	w14, w16
    1a1c:      	add	x16, sp, #0x538
    1a20:      	bfxil	x16, x15, #0, #3
    1a24:      	ldrb	w16, [x16]
    1a28:      	add	x2, sp, #0x7a0
    1a2c:      	orr	x15, x2, x15, lsl #2
    1a30:      	str	q2, [sp, #0x7b0]
    1a34:      	str	q3, [sp, #0x7a0]
    1a38:      	ldr	s7, [x15]
    1a3c:      	fcsel	s6, s6, s20, ne
    1a40:      	tst	w9, w16
    1a44:      	umov.b	w11, v24[4]
    1a48:      	umov.b	w6, v24[5]
    1a4c:      	str	w6, [sp, #0x190]
    1a50:      	umov.b	w16, v24[6]
    1a54:      	str	w16, [sp, #0x18c]
    1a58:      	umov.b	w9, v24[7]
    1a5c:      	str	w9, [sp, #0x188]
    1a60:      	fcsel	s7, s7, s20, ne
    1a64:      	ands	w2, w9, #0x1
    1a68:      	csinc	w27, w24, wzr, ne
    1a6c:      	mov	w9, #0x5                ; =5
    1a70:      	csel	w15, w9, w21, ne
    1a74:      	ands	w4, w16, #0x1
    1a78:      	csinc	w28, w13, wzr, ne
    1a7c:      	csel	w3, w17, w21, ne
    1a80:      	ands	w6, w6, #0x1
    1a84:      	csinc	w19, w17, wzr, ne
    1a88:      	csel	w7, w13, w21, ne
    1a8c:      	ands	w16, w11, #0x1
    1a90:      	csinc	w17, w9, wzr, ne
    1a94:      	orr	x13, x22, x17
    1a98:      	ldrb	w13, [x13]
    1a9c:      	str	q2, [sp, #0x790]
    1aa0:      	str	q3, [sp, #0x780]
    1aa4:      	add	x9, sp, #0x780
    1aa8:      	ldr	s16, [x9, w17, uxtw #2]
    1aac:      	csel	w17, w24, w21, ne
    1ab0:      	tst	w16, w13
    1ab4:      	orr	x13, x22, x19
    1ab8:      	ldrb	w13, [x13]
    1abc:      	str	q2, [sp, #0x770]
    1ac0:      	str	q3, [sp, #0x760]
    1ac4:      	add	x9, sp, #0x760
    1ac8:      	ldr	s17, [x9, w19, uxtw #2]
    1acc:      	fcsel	s16, s16, s20, ne
    1ad0:      	tst	w6, w13
    1ad4:      	orr	x13, x22, x28
    1ad8:      	ldrb	w13, [x13]
    1adc:      	str	q2, [sp, #0x750]
    1ae0:      	str	q3, [sp, #0x740]
    1ae4:      	add	x9, sp, #0x740
    1ae8:      	ldr	s18, [x9, w28, uxtw #2]
    1aec:      	fcsel	s17, s17, s20, ne
    1af0:      	tst	w4, w13
    1af4:      	orr	x13, x22, x27
    1af8:      	ldrb	w13, [x13]
    1afc:      	str	q2, [sp, #0x730]
    1b00:      	str	q3, [sp, #0x720]
    1b04:      	add	x9, sp, #0x720
    1b08:      	ldr	s19, [x9, w27, uxtw #2]
    1b0c:      	fcsel	s18, s18, s20, ne
    1b10:      	tst	w2, w13
    1b14:      	mov.s	v4[1], v5[0]
    1b18:      	mov.s	v4[2], v6[0]
    1b1c:      	mov.s	v4[3], v7[0]
    1b20:      	mov.s	v16[1], v17[0]
    1b24:      	fcsel	s5, s19, s20, ne
    1b28:      	mov.s	v16[2], v18[0]
    1b2c:      	mov.s	v16[3], v5[0]
    1b30:      	fmaxnm.4s	v5, v2, v16
    1b34:      	fmaxnm.4s	v2, v3, v4
    1b38:      	and	w21, w10, w25
    1b3c:      	mov	s3, v2[2]
    1b40:      	mov	w13, #0x2               ; =2
    1b44:      	bfxil	w13, w20, #0, #1
    1b48:      	orr	x19, x22, x13
    1b4c:      	ldrb	w19, [x19]
    1b50:      	add	x9, sp, #0x700
    1b54:      	orr	x13, x9, x13, lsl #2
    1b58:      	str	q5, [sp, #0x710]
    1b5c:      	str	q2, [sp, #0x700]
    1b60:      	ldr	s4, [x13]
    1b64:      	tst	w21, #0x1
    1b68:      	fcsel	s3, s3, s20, ne
    1b6c:      	tst	w30, w19
    1b70:      	lsr	x13, x0, #1
    1b74:      	add	x19, sp, #0x6e0
    1b78:      	bfi	x19, x13, #3, #1
    1b7c:      	orr	x13, x22, x0
    1b80:      	ldrb	w13, [x13]
    1b84:      	str	q5, [sp, #0x6f0]
    1b88:      	str	q2, [sp, #0x6e0]
    1b8c:      	ldr	s6, [x19]
    1b90:      	fcsel	s4, s4, s20, ne
    1b94:      	tst	w14, w13
    1b98:      	add	x13, sp, #0x538
    1b9c:      	bfxil	x13, x5, #0, #3
    1ba0:      	ldrb	w13, [x13]
    1ba4:      	add	x9, sp, #0x6c0
    1ba8:      	orr	x0, x9, x5, lsl #2
    1bac:      	str	q5, [sp, #0x6d0]
    1bb0:      	str	q2, [sp, #0x6c0]
    1bb4:      	ldr	s7, [x0]
    1bb8:      	mov	w0, #0x4                ; =4
    1bbc:      	fcsel	s6, s6, s20, ne
    1bc0:      	ldr	w5, [sp, #0x84]
    1bc4:      	tst	w5, w13
    1bc8:      	fcsel	s7, s7, s20, ne
    1bcc:      	orr	x13, x22, x17
    1bd0:      	ldrb	w13, [x13]
    1bd4:      	tst	w16, w13
    1bd8:      	str	q5, [sp, #0x6b0]
    1bdc:      	str	q2, [sp, #0x6a0]
    1be0:      	add	x9, sp, #0x6a0
    1be4:      	ldr	s16, [x9, w17, uxtw #2]
    1be8:      	orr	x13, x22, x7
    1bec:      	ldrb	w13, [x13]
    1bf0:      	str	q5, [sp, #0x690]
    1bf4:      	str	q2, [sp, #0x680]
    1bf8:      	add	x9, sp, #0x680
    1bfc:      	ldr	s17, [x9, w7, uxtw #2]
    1c00:      	fcsel	s16, s16, s20, ne
    1c04:      	tst	w6, w13
    1c08:      	fcsel	s17, s17, s20, ne
    1c0c:      	orr	x13, x22, x3
    1c10:      	ldrb	w13, [x13]
    1c14:      	tst	w4, w13
    1c18:      	str	q5, [sp, #0x670]
    1c1c:      	str	q2, [sp, #0x660]
    1c20:      	add	x9, sp, #0x660
    1c24:      	ldr	s18, [x9, w3, uxtw #2]
    1c28:      	fcsel	s18, s18, s20, ne
    1c2c:      	orr	x13, x22, x15
    1c30:      	ldrb	w13, [x13]
    1c34:      	str	q5, [sp, #0x650]
    1c38:      	str	q2, [sp, #0x640]
    1c3c:      	add	x9, sp, #0x640
    1c40:      	ldr	s19, [x9, w15, uxtw #2]
    1c44:      	tst	w2, w13
    1c48:      	fcsel	s19, s19, s20, ne
    1c4c:      	mov.s	v16[1], v17[0]
    1c50:      	mov.s	v16[2], v18[0]
    1c54:      	mov.s	v16[3], v19[0]
    1c58:      	fmaxnm.4s	v5, v5, v16
    1c5c:      	str	w11, [sp, #0x94]
    1c60:      	and	w16, w10, w11
    1c64:      	mov	x13, x0
    1c68:      	str	w20, [sp, #0xbc]
    1c6c:      	bfxil	w13, w20, #0, #1
    1c70:      	orr	x15, x22, x13
    1c74:      	ldrb	w15, [x15]
    1c78:      	tst	w16, #0x1
    1c7c:      	fcsel	s16, s5, s20, ne
    1c80:      	tst	w30, w15
    1c84:      	mov.s	v3[1], v4[0]
    1c88:      	mov.s	v3[2], v6[0]
    1c8c:      	mov.s	v3[3], v7[0]
    1c90:      	fmaxnm.4s	v2, v2, v3
    1c94:      	str	q5, [sp, #0x630]
    1c98:      	str	q2, [sp, #0x620]
    1c9c:      	add	x9, sp, #0x620
    1ca0:      	ldr	s3, [x9, w13, uxtw #2]
    1ca4:      	fcsel	s3, s3, s20, ne
    1ca8:      	ldr	x11, [sp, #0x98]
    1cac:      	orr	x13, x22, x11
    1cb0:      	ldrb	w13, [x13]
    1cb4:      	str	q5, [sp, #0x610]
    1cb8:      	str	q2, [sp, #0x600]
    1cbc:      	add	x9, sp, #0x600
    1cc0:      	ldr	s4, [x9, w11, uxtw #2]
    1cc4:      	tst	w14, w13
    1cc8:      	fcsel	s4, s4, s20, ne
    1ccc:      	ldr	x13, [sp, #0xb0]
    1cd0:      	orr	x11, x22, x13
    1cd4:      	ldrb	w11, [x11]
    1cd8:      	str	q5, [sp, #0x5f0]
    1cdc:      	str	q2, [sp, #0x5e0]
    1ce0:      	add	x9, sp, #0x5e0
    1ce4:      	ldr	s5, [x9, w13, uxtw #2]
    1ce8:      	tst	w5, w11
    1cec:      	fcsel	s5, s5, s20, ne
    1cf0:      	mov.s	v16[1], v3[0]
    1cf4:      	mov.s	v16[2], v4[0]
    1cf8:      	ldr	w9, [sp, #0x4c]
    1cfc:      	mov	x27, x9
    1d00:      	tst	w9, #0x1
    1d04:      	mov.s	v16[3], v5[0]
    1d08:      	fmaxnm.4s	v2, v2, v16
    1d0c:      	fcsel	s3, s2, s20, ne
    1d10:      	str	w21, [sp, #0xb0]
    1d14:      	tst	w21, #0x1
    1d18:      	fcsel	s4, s2, s20, ne
    1d1c:      	str	w16, [sp, #0x98]
    1d20:      	tst	w16, #0x1
    1d24:      	fcsel	s5, s2, s20, ne
    1d28:      	tst	w10, #0x1
    1d2c:      	ldr	x9, [sp, #0x40]
    1d30:      	mov	x19, x9
    1d34:      	and	w9, w9, w10
    1d38:      	fcsel	s6, s2, s20, ne
    1d3c:      	str	w9, [sp, #0x84]
    1d40:      	tst	w9, #0x1
    1d44:      	fcsel	s7, s2, s20, ne
    1d48:      	ldr	w9, [sp, #0x190]
    1d4c:      	and	w9, w9, w10
    1d50:      	str	w9, [sp, #0x80]
    1d54:      	tst	w9, #0x1
    1d58:      	fcsel	s16, s2, s20, ne
    1d5c:      	ldr	w9, [sp, #0x18c]
    1d60:      	and	w9, w9, w10
    1d64:      	str	w9, [sp, #0x7c]
    1d68:      	tst	w9, #0x1
    1d6c:      	fcsel	s17, s2, s20, ne
    1d70:      	ldr	w9, [sp, #0x188]
    1d74:      	and	w9, w9, w10
    1d78:      	str	w9, [sp, #0x78]
    1d7c:      	tst	w9, #0x1
    1d80:      	mov.s	v6[1], v3[0]
    1d84:      	mov.s	v6[2], v4[0]
    1d88:      	mov.s	v6[3], v7[0]
    1d8c:      	mov.s	v5[1], v16[0]
    1d90:      	fcsel	s2, s2, s20, ne
    1d94:      	mov.s	v5[2], v17[0]
    1d98:      	mov.s	v5[3], v2[0]
    1d9c:      	ldr	w9, [sp, #0xc0]
    1da0:      	rbit	w9, w9
    1da4:      	clz	w9, w9
    1da8:      	str	q5, [sp, #0x550]
    1dac:      	str	q6, [sp, #0x540]
    1db0:      	str	x9, [sp, #0x70]
    1db4:      	and	x9, x9, #0x7
    1db8:      	add	x11, sp, #0x540
    1dbc:      	ldr	s2, [x11, x9, lsl #2]
    1dc0:      	str	q24, [sp, #0xc0]
    1dc4:      	mov.b	v24[0], wzr
    1dc8:      	str	q24, [sp, #0x50]
    1dcc:      	mov	w9, #-0x800000          ; =-8388608
    1dd0:      	fmov	s3, w9
    1dd4:      	fmaxnm	s2, s2, s3
    1dd8:      	dup.4s	v4, v2[0]
    1ddc:      	movi.2d	v8, #0000000000000000
    1de0:      	movi.2d	v22, #0000000000000000
    1de4:      	movi.2d	v15, #0000000000000000
    1de8:      	movi.2d	v5, #0000000000000000
    1dec:      	ldr	w21, [sp, #0x138]
    1df0:      	mov	w13, #-0x3d300000       ; =-1026555904
    1df4:      	mov	w14, #0x42c80000        ; =1120403456
    1df8:      	mov	w15, #0xaa3b            ; =43579
    1dfc:      	movk	w15, #0x3fb8, lsl #16
    1e00:      	mov	w16, #0x7200            ; =29184
    1e04:      	movk	w16, #0xbf31, lsl #16
    1e08:      	mov	w17, #0xbe8e            ; =48782
    1e0c:      	movk	w17, #0xb5bf, lsl #16
    1e10:      	mov	w3, #0x2bda             ; =11226
    1e14:      	movk	w3, #0x3950, lsl #16
    1e18:      	mov	w4, #0x96c9             ; =38601
    1e1c:      	movk	w4, #0x3ab6, lsl #16
    1e20:      	mov	w5, #0x88a6             ; =34982
    1e24:      	movk	w5, #0x3c08, lsl #16
    1e28:      	mov	w6, #0xaa7a             ; =43642
    1e2c:      	movk	w6, #0x3d2a, lsl #16
    1e30:      	mov	w7, #0xaaab             ; =43691
    1e34:      	movk	w7, #0x3e2a, lsl #16
    1e38:      	ldr	x20, [sp, #0x8]
    1e3c:      	ldr	x24, [sp, #0x88]
    1e40:      	b	0x204c <_llm_rows.packet_batch.blocks+0x1638>
    1e44:      	lsl	x8, x8, #5
    1e48:      	add	x9, x26, x8
    1e4c:      	ldp	q3, q2, [x9]
    1e50:      	fsub.4s	v3, v3, v4
    1e54:      	fsub.4s	v2, v2, v4
    1e58:      	and.16b	v24, v0, v2
    1e5c:      	and.16b	v19, v1, v3
    1e60:      	dup.4s	v6, w13
    1e64:      	fcmge.4s	v2, v19, v6
    1e68:      	fcmge.4s	v3, v24, v6
    1e6c:      	dup.4s	v9, w14
    1e70:      	fcmge.4s	v7, v9, v19
    1e74:      	fcmge.4s	v16, v9, v24
    1e78:      	and.16b	v3, v3, v16
    1e7c:      	and.16b	v2, v2, v7
    1e80:      	and.16b	v2, v2, v19
    1e84:      	and.16b	v7, v3, v24
    1e88:      	dup.4s	v3, w15
    1e8c:      	fmul.4s	v16, v7, v3
    1e90:      	fmul.4s	v17, v2, v3
    1e94:      	movi.4s	v20, #0x4b, lsl #24
    1e98:      	mvni.4s	v21, #0x80, lsl #24
    1e9c:      	mov.16b	v18, v21
    1ea0:      	bsl.16b	v18, v20, v17
    1ea4:      	bif.16b	v20, v16, v21
    1ea8:      	fadd.4s	v16, v16, v20
    1eac:      	fadd.4s	v17, v17, v18
    1eb0:      	fsub.4s	v17, v17, v18
    1eb4:      	fsub.4s	v16, v16, v20
    1eb8:      	fcvtzs.4s	v25, v16
    1ebc:      	fcvtzs.4s	v26, v17
    1ec0:      	scvtf.4s	v16, v26
    1ec4:      	scvtf.4s	v17, v25
    1ec8:      	dup.4s	v23, w16
    1ecc:      	fmul.4s	v18, v17, v23
    1ed0:      	fmul.4s	v20, v16, v23
    1ed4:      	fadd.4s	v20, v2, v20
    1ed8:      	fadd.4s	v7, v7, v18
    1edc:      	dup.4s	v2, w17
    1ee0:      	fmul.4s	v16, v16, v2
    1ee4:      	fmul.4s	v17, v17, v2
    1ee8:      	fadd.4s	v7, v7, v17
    1eec:      	fadd.4s	v27, v20, v16
    1ef0:      	dup.4s	v20, w3
    1ef4:      	fmul.4s	v16, v27, v20
    1ef8:      	fmul.4s	v17, v7, v20
    1efc:      	dup.4s	v21, w4
    1f00:      	fadd.4s	v17, v17, v21
    1f04:      	fadd.4s	v16, v16, v21
    1f08:      	fmul.4s	v18, v27, v16
    1f0c:      	fmul.4s	v17, v7, v17
    1f10:      	dup.4s	v16, w5
    1f14:      	fadd.4s	v17, v17, v16
    1f18:      	fadd.4s	v18, v18, v16
    1f1c:      	fmul.4s	v18, v27, v18
    1f20:      	fmul.4s	v28, v7, v17
    1f24:      	dup.4s	v17, w6
    1f28:      	fadd.4s	v28, v28, v17
    1f2c:      	fadd.4s	v18, v18, v17
    1f30:      	fmul.4s	v29, v27, v18
    1f34:      	fmul.4s	v28, v7, v28
    1f38:      	dup.4s	v18, w7
    1f3c:      	fadd.4s	v28, v28, v18
    1f40:      	fadd.4s	v29, v29, v18
    1f44:      	fmul.4s	v29, v27, v29
    1f48:      	fmul.4s	v28, v7, v28
    1f4c:      	movi.4s	v30, #0x3f, lsl #24
    1f50:      	fadd.4s	v28, v28, v30
    1f54:      	fadd.4s	v29, v29, v30
    1f58:      	fmul.4s	v30, v7, v7
    1f5c:      	fmul.4s	v31, v27, v27
    1f60:      	fmul.4s	v29, v31, v29
    1f64:      	fmul.4s	v28, v30, v28
    1f68:      	fadd.4s	v28, v7, v28
    1f6c:      	fadd.4s	v27, v27, v29
    1f70:      	fmov.4s	v7, #1.00000000
    1f74:      	fadd.4s	v27, v27, v7
    1f78:      	fadd.4s	v28, v28, v7
    1f7c:      	sshr.4s	v29, v26, #0x1
    1f80:      	sshr.4s	v30, v25, #0x1
    1f84:      	shl.4s	v31, v30, #0x17
    1f88:      	add.4s	v31, v31, v7
    1f8c:      	fmul.4s	v28, v28, v31
    1f90:      	shl.4s	v31, v29, #0x17
    1f94:      	add.4s	v31, v31, v7
    1f98:      	fmul.4s	v27, v27, v31
    1f9c:      	sub.4s	v25, v25, v30
    1fa0:      	sub.4s	v26, v26, v29
    1fa4:      	shl.4s	v26, v26, #0x17
    1fa8:      	add.4s	v26, v26, v7
    1fac:      	fmul.4s	v26, v27, v26
    1fb0:      	shl.4s	v25, v25, #0x17
    1fb4:      	add.4s	v25, v25, v7
    1fb8:      	fmul.4s	v25, v28, v25
    1fbc:      	fcmgt.4s	v27, v6, v24
    1fc0:      	bic.16b	v25, v25, v27
    1fc4:      	fcmgt.4s	v27, v6, v19
    1fc8:      	bic.16b	v26, v26, v27
    1fcc:      	fcmgt.4s	v27, v19, v9
    1fd0:      	ldr	q28, [sp, #0x240]
    1fd4:      	bit.16b	v26, v28, v27
    1fd8:      	fcmgt.4s	v27, v24, v9
    1fdc:      	bit.16b	v25, v28, v27
    1fe0:      	fcmeq.4s	v24, v24, v24
    1fe4:      	ldr	q27, [sp, #0x230]
    1fe8:      	bsl.16b	v24, v25, v27
    1fec:      	cmeq.8b	v25, v10, #0
    1ff0:      	sshll.8h	v25, v25, #0x0
    1ff4:      	fcmeq.4s	v19, v19, v19
    1ff8:      	bsl.16b	v19, v26, v27
    1ffc:      	sshll.4s	v26, v25, #0x0
    2000:      	bic.16b	v19, v19, v26
    2004:      	sshll2.4s	v25, v25, #0x0
    2008:      	bic.16b	v24, v24, v25
    200c:      	add	x8, x23, x8
    2010:      	ldp	q25, q26, [x8]
    2014:      	bif.16b	v24, v26, v0
    2018:      	bif.16b	v19, v25, v1
    201c:      	stp	q19, q24, [x8]
    2020:      	fmov	x8, d8
    2024:      	ldr	q19, [sp, #0x260]
    2028:      	add.2d	v8, v8, v19
    202c:      	ldp	q19, q24, [sp, #0x270]
    2030:      	add.2d	v22, v22, v24
    2034:      	add.2d	v15, v15, v19
    2038:      	ldr	q19, [sp, #0x290]
    203c:      	add.2d	v5, v5, v19
    2040:      	add	x8, x8, x12
    2044:      	cmp	x8, #0x8
    2048:      	b.ge	0x2140 <_llm_rows.packet_batch.blocks+0x172c>
    204c:      	ldr	q2, [sp, #0x250]
    2050:      	fmov	w9, s2
    2054:      	ldr	q2, [sp, #0x2a0]
    2058:      	add.2d	v2, v8, v2
    205c:      	ldr	q3, [sp, #0x1f0]
    2060:      	add.2d	v2, v3, v2
    2064:      	tbz	w9, #0x0, 0x2084 <_llm_rows.packet_batch.blocks+0x1670>
    2068:      	fmov	x11, d2
    206c:      	ldr	b10, [x11]
    2070:      	ldp	q6, q3, [sp, #0x210]
    2074:      	ldr	q7, [sp, #0x200]
    2078:      	and	w9, w9, #0xff
    207c:      	tbnz	w9, #0x1, 0x2098 <_llm_rows.packet_batch.blocks+0x1684>
    2080:      	b	0x20a0 <_llm_rows.packet_batch.blocks+0x168c>
    2084:      	movi.2d	v10, #0000000000000000
    2088:      	ldp	q6, q3, [sp, #0x210]
    208c:      	ldr	q7, [sp, #0x200]
    2090:      	and	w9, w9, #0xff
    2094:      	tbz	w9, #0x1, 0x20a0 <_llm_rows.packet_batch.blocks+0x168c>
    2098:      	mov.d	x11, v2[1]
    209c:      	ld1.b	{ v10 }[1], [x11]
    20a0:      	ldr	q2, [sp, #0x2c0]
    20a4:      	add.2d	v2, v22, v2
    20a8:      	add.2d	v2, v6, v2
    20ac:      	tbnz	w9, #0x2, 0x20e0 <_llm_rows.packet_batch.blocks+0x16cc>
    20b0:      	tbnz	w9, #0x3, 0x20ec <_llm_rows.packet_batch.blocks+0x16d8>
    20b4:      	ldr	q2, [sp, #0x2b0]
    20b8:      	add.2d	v2, v15, v2
    20bc:      	add.2d	v2, v7, v2
    20c0:      	tbnz	w9, #0x4, 0x2104 <_llm_rows.packet_batch.blocks+0x16f0>
    20c4:      	tbnz	w9, #0x5, 0x2110 <_llm_rows.packet_batch.blocks+0x16fc>
    20c8:      	ldr	q2, [sp, #0x2d0]
    20cc:      	add.2d	v2, v5, v2
    20d0:      	add.2d	v2, v3, v2
    20d4:      	tbnz	w9, #0x6, 0x2128 <_llm_rows.packet_batch.blocks+0x1714>
    20d8:      	tbz	w9, #0x7, 0x1e44 <_llm_rows.packet_batch.blocks+0x1430>
    20dc:      	b	0x2134 <_llm_rows.packet_batch.blocks+0x1720>
    20e0:      	fmov	x11, d2
    20e4:      	ld1.b	{ v10 }[2], [x11]
    20e8:      	tbz	w9, #0x3, 0x20b4 <_llm_rows.packet_batch.blocks+0x16a0>
    20ec:      	mov.d	x11, v2[1]
    20f0:      	ld1.b	{ v10 }[3], [x11]
    20f4:      	ldr	q2, [sp, #0x2b0]
    20f8:      	add.2d	v2, v15, v2
    20fc:      	add.2d	v2, v7, v2
    2100:      	tbz	w9, #0x4, 0x20c4 <_llm_rows.packet_batch.blocks+0x16b0>
    2104:      	fmov	x11, d2
    2108:      	ld1.b	{ v10 }[4], [x11]
    210c:      	tbz	w9, #0x5, 0x20c8 <_llm_rows.packet_batch.blocks+0x16b4>
    2110:      	mov.d	x11, v2[1]
    2114:      	ld1.b	{ v10 }[5], [x11]
    2118:      	ldr	q2, [sp, #0x2d0]
    211c:      	add.2d	v2, v5, v2
    2120:      	add.2d	v2, v3, v2
    2124:      	tbz	w9, #0x6, 0x20d8 <_llm_rows.packet_batch.blocks+0x16c4>
    2128:      	fmov	x11, d2
    212c:      	ld1.b	{ v10 }[6], [x11]
    2130:      	tbz	w9, #0x7, 0x1e44 <_llm_rows.packet_batch.blocks+0x1430>
    2134:      	mov.d	x9, v2[1]
    2138:      	ld1.b	{ v10 }[7], [x9]
    213c:      	b	0x1e44 <_llm_rows.packet_batch.blocks+0x1430>
    2140:      	ldr	q5, [sp, #0x60]
    2144:      	sshll.4s	v5, v5, #0x0
    2148:      	ldp	q22, q19, [sp, #0x160]
    214c:      	fsub.4s	v24, v22, v4
    2150:      	fsub.4s	v19, v19, v4
    2154:      	ldr	q10, [sp, #0x1c0]
    2158:      	zip2.8b	v4, v10, v0
    215c:      	ushll.4s	v4, v4, #0x0
    2160:      	shl.4s	v4, v4, #0x1f
    2164:      	cmlt.4s	v4, v4, #0
    2168:      	and.16b	v22, v4, v19
    216c:      	zip1.8b	v19, v10, v0
    2170:      	ushll.4s	v19, v19, #0x0
    2174:      	shl.4s	v19, v19, #0x1f
    2178:      	cmlt.4s	v19, v19, #0
    217c:      	and.16b	v24, v19, v24
    2180:      	fcmge.4s	v25, v24, v6
    2184:      	fcmge.4s	v26, v22, v6
    2188:      	fcmge.4s	v27, v9, v24
    218c:      	fcmge.4s	v28, v9, v22
    2190:      	and.16b	v26, v26, v28
    2194:      	and.16b	v25, v25, v27
    2198:      	and.16b	v25, v25, v24
    219c:      	and.16b	v26, v26, v22
    21a0:      	fmul.4s	v27, v26, v3
    21a4:      	fmul.4s	v3, v25, v3
    21a8:      	movi.4s	v29, #0x4b, lsl #24
    21ac:      	mvni.4s	v30, #0x80, lsl #24
    21b0:      	mov.16b	v28, v30
    21b4:      	bsl.16b	v28, v29, v3
    21b8:      	bif.16b	v29, v27, v30
    21bc:      	fadd.4s	v27, v27, v29
    21c0:      	fadd.4s	v3, v3, v28
    21c4:      	fsub.4s	v3, v3, v28
    21c8:      	fsub.4s	v27, v27, v29
    21cc:      	fcvtzs.4s	v27, v27
    21d0:      	fcvtzs.4s	v3, v3
    21d4:      	scvtf.4s	v28, v3
    21d8:      	scvtf.4s	v29, v27
    21dc:      	fmul.4s	v30, v29, v23
    21e0:      	fmul.4s	v23, v28, v23
    21e4:      	fadd.4s	v23, v25, v23
    21e8:      	fadd.4s	v25, v26, v30
    21ec:      	fmul.4s	v26, v28, v2
    21f0:      	fmul.4s	v2, v29, v2
    21f4:      	fadd.4s	v2, v25, v2
    21f8:      	fadd.4s	v23, v23, v26
    21fc:      	fmul.4s	v25, v23, v20
    2200:      	fmul.4s	v20, v2, v20
    2204:      	fadd.4s	v20, v20, v21
    2208:      	fadd.4s	v21, v25, v21
    220c:      	fmul.4s	v21, v23, v21
    2210:      	fmul.4s	v20, v2, v20
    2214:      	fadd.4s	v20, v20, v16
    2218:      	fadd.4s	v16, v21, v16
    221c:      	fmul.4s	v16, v23, v16
    2220:      	fmul.4s	v20, v2, v20
    2224:      	fadd.4s	v20, v20, v17
    2228:      	fadd.4s	v16, v16, v17
    222c:      	fmul.4s	v16, v23, v16
    2230:      	fmul.4s	v17, v2, v20
    2234:      	fadd.4s	v17, v17, v18
    2238:      	fadd.4s	v16, v16, v18
    223c:      	fmul.4s	v16, v23, v16
    2240:      	fmul.4s	v17, v2, v17
    2244:      	movi.4s	v18, #0x3f, lsl #24
    2248:      	fadd.4s	v17, v17, v18
    224c:      	fadd.4s	v16, v16, v18
    2250:      	fmul.4s	v18, v2, v2
    2254:      	fmul.4s	v20, v23, v23
    2258:      	fmul.4s	v16, v20, v16
    225c:      	fmul.4s	v17, v18, v17
    2260:      	fadd.4s	v2, v2, v17
    2264:      	fadd.4s	v16, v23, v16
    2268:      	fadd.4s	v16, v16, v7
    226c:      	fadd.4s	v2, v2, v7
    2270:      	sshr.4s	v17, v3, #0x1
    2274:      	sshr.4s	v18, v27, #0x1
    2278:      	shl.4s	v20, v18, #0x17
    227c:      	shl.4s	v21, v17, #0x17
    2280:      	add.4s	v21, v21, v7
    2284:      	add.4s	v20, v20, v7
    2288:      	fmul.4s	v2, v2, v20
    228c:      	fmul.4s	v16, v16, v21
    2290:      	sub.4s	v18, v27, v18
    2294:      	sub.4s	v3, v3, v17
    2298:      	shl.4s	v3, v3, #0x17
    229c:      	shl.4s	v17, v18, #0x17
    22a0:      	add.4s	v17, v17, v7
    22a4:      	add.4s	v3, v3, v7
    22a8:      	fmul.4s	v3, v16, v3
    22ac:      	fmul.4s	v2, v2, v17
    22b0:      	fcmgt.4s	v7, v6, v22
    22b4:      	bic.16b	v2, v2, v7
    22b8:      	fcmgt.4s	v6, v6, v24
    22bc:      	bic.16b	v3, v3, v6
    22c0:      	fcmgt.4s	v6, v22, v9
    22c4:      	fcmgt.4s	v7, v24, v9
    22c8:      	ldp	q16, q17, [sp, #0x230]
    22cc:      	bit.16b	v3, v17, v7
    22d0:      	bit.16b	v2, v17, v6
    22d4:      	fcmeq.4s	v6, v24, v24
    22d8:      	fcmeq.4s	v7, v22, v22
    22dc:      	bif.16b	v2, v16, v7
    22e0:      	bif.16b	v3, v16, v6
    22e4:      	bic.16b	v6, v3, v5
    22e8:      	ldr	q3, [sp, #0xa0]
    22ec:      	bic.16b	v5, v2, v3
    22f0:      	ldr	x8, [sp, #0xd0]
    22f4:      	add	x8, x23, x8
    22f8:      	ldp	q2, q3, [x8]
    22fc:      	bit.16b	v3, v5, v4
    2300:      	bit.16b	v2, v6, v19
    2304:      	stp	q2, q3, [x8]
    2308:      	ldp	q3, q2, [x23, #0x60]
    230c:      	and.16b	v2, v0, v2
    2310:      	and.16b	v3, v1, v3
    2314:      	ldp	q4, q7, [x23, #0x40]
    2318:      	and.16b	v7, v0, v7
    231c:      	and.16b	v4, v1, v4
    2320:      	ldp	q17, q16, [x23, #0x20]
    2324:      	and.16b	v16, v0, v16
    2328:      	and.16b	v17, v1, v17
    232c:      	ldp	q18, q19, [x23]
    2330:      	and.16b	v19, v0, v19
    2334:      	and.16b	v18, v1, v18
    2338:      	ldp	q9, q8, [sp, #0x1a0]
    233c:      	sshll.2d	v22, v1, #0x0
    2340:      	sshll.2d	v23, v0, #0x0
    2344:      	add	x8, x23, x1, lsl #5
    2348:      	ldp	q20, q21, [x8]
    234c:      	fadd.4s	v20, v18, v20
    2350:      	fadd.4s	v21, v19, v21
    2354:      	ldp	q25, q24, [x8, #0x20]
    2358:      	fadd.4s	v25, v17, v25
    235c:      	fadd.4s	v24, v16, v24
    2360:      	ldp	q27, q26, [x8, #0x40]
    2364:      	fadd.4s	v27, v4, v27
    2368:      	fadd.4s	v26, v7, v26
    236c:      	ldp	q29, q28, [x8, #0x60]
    2370:      	fadd.4s	v29, v3, v29
    2374:      	fadd.4s	v28, v2, v28
    2378:      	dup.2d	v30, x0
    237c:      	and.16b	v31, v9, v30
    2380:      	add.2d	v11, v11, v31
    2384:      	and.16b	v31, v8, v30
    2388:      	add.2d	v12, v12, v31
    238c:      	and.16b	v23, v23, v30
    2390:      	add.2d	v13, v13, v23
    2394:      	and.16b	v22, v22, v30
    2398:      	add.2d	v22, v14, v22
    239c:      	bit.16b	v19, v21, v0
    23a0:      	bit.16b	v18, v20, v1
    23a4:      	bit.16b	v16, v24, v0
    23a8:      	bit.16b	v17, v25, v1
    23ac:      	bit.16b	v7, v26, v0
    23b0:      	bit.16b	v4, v27, v1
    23b4:      	bit.16b	v2, v28, v0
    23b8:      	bit.16b	v3, v29, v1
    23bc:      	fmov	x8, d14
    23c0:      	add	x9, x8, #0x4
    23c4:      	tst	w10, #0x1
    23c8:      	csel	x1, x9, x8, ne
    23cc:      	mov.16b	v14, v22
    23d0:      	cmp	x1, #0x8
    23d4:      	b.lt	0x233c <_llm_rows.packet_batch.blocks+0x1928>
    23d8:      	mov	x8, #0x0                ; =0
    23dc:      	fadd.4s	v19, v5, v19
    23e0:      	fadd.4s	v18, v6, v18
    23e4:      	zip1.8b	v22, v10, v0
    23e8:      	ushll.4s	v22, v22, #0x0
    23ec:      	shl.4s	v22, v22, #0x1f
    23f0:      	cmlt.4s	v22, v22, #0
    23f4:      	and.16b	v18, v22, v18
    23f8:      	zip2.8b	v22, v10, v0
    23fc:      	ushll.4s	v22, v22, #0x0
    2400:      	shl.4s	v22, v22, #0x1f
    2404:      	cmlt.4s	v22, v22, #0
    2408:      	and.16b	v19, v22, v19
    240c:      	ldr	q23, [sp, #0x50]
    2410:      	zip2.8b	v22, v23, v0
    2414:      	ushll.4s	v22, v22, #0x0
    2418:      	shl.4s	v22, v22, #0x1f
    241c:      	cmlt.4s	v22, v22, #0
    2420:      	bit.16b	v19, v21, v22
    2424:      	zip1.8b	v21, v23, v0
    2428:      	ushll.4s	v21, v21, #0x0
    242c:      	shl.4s	v21, v21, #0x1f
    2430:      	cmlt.4s	v21, v21, #0
    2434:      	bit.16b	v18, v20, v21
    2438:      	fadd.4s	v17, v17, v18
    243c:      	fadd.4s	v16, v16, v19
    2440:      	fadd.4s	v7, v7, v16
    2444:      	fadd.4s	v4, v4, v17
    2448:      	fadd.4s	v3, v3, v4
    244c:      	fadd.4s	v2, v2, v7
    2450:      	add	x9, sp, #0x328
    2454:      	bfxil	x9, x10, #0, #1
    2458:      	ldr	q4, [sp, #0xc0]
    245c:      	str	d4, [sp, #0x328]
    2460:      	ldrb	w9, [x9]
    2464:      	add	x11, sp, #0x510
    2468:      	bfi	x11, x10, #2, #1
    246c:      	str	q2, [sp, #0x520]
    2470:      	str	q3, [sp, #0x510]
    2474:      	ldr	s4, [x11]
    2478:      	ands	w1, w10, #0x1
    247c:      	mov	w15, #0x2               ; =2
    2480:      	csel	w13, w15, wzr, ne
    2484:      	csel	w30, w0, wzr, ne
    2488:      	tst	w1, w9
    248c:      	movi	d22, #0000000000000000
    2490:      	fcsel	s4, s4, s22, ne
    2494:      	tst	w27, #0x1
    2498:      	fcsel	s7, s3, s22, ne
    249c:      	ands	w9, w25, #0x1
    24a0:      	mov	w11, #0x3               ; =3
    24a4:      	csel	w11, w11, wzr, ne
    24a8:      	add	x28, sp, #0x328
    24ac:      	orr	x14, x28, x11
    24b0:      	ldrb	w14, [x14]
    24b4:      	add	x16, sp, #0x4f0
    24b8:      	orr	x11, x16, x11, lsl #2
    24bc:      	str	q2, [sp, #0x500]
    24c0:      	str	q3, [sp, #0x4f0]
    24c4:      	ldr	s16, [x11]
    24c8:      	tst	w9, w14
    24cc:      	fcsel	s16, s16, s22, ne
    24d0:      	mov	x22, x19
    24d4:      	ands	w14, w22, #0x1
    24d8:      	csel	w9, w15, wzr, ne
    24dc:      	orr	x11, x28, x9
    24e0:      	ldrb	w11, [x11]
    24e4:      	lsr	x9, x9, #1
    24e8:      	add	x15, sp, #0x4d0
    24ec:      	bfi	x15, x9, #3, #1
    24f0:      	str	q2, [sp, #0x4e0]
    24f4:      	str	q3, [sp, #0x4d0]
    24f8:      	ldr	s17, [x15]
    24fc:      	tst	w14, w11
    2500:      	fcsel	s17, s17, s22, ne
    2504:      	ldr	w9, [sp, #0x188]
    2508:      	ands	w11, w9, #0x1
    250c:      	mov	w25, #0x6               ; =6
    2510:      	csel	w16, w25, wzr, ne
    2514:      	mov	w19, #0x5               ; =5
    2518:      	csel	w4, w19, wzr, ne
    251c:      	ldr	w9, [sp, #0x18c]
    2520:      	ands	w6, w9, #0x1
    2524:      	mov	w9, #0x7                ; =7
    2528:      	csel	w17, w9, wzr, ne
    252c:      	csel	w15, w0, wzr, ne
    2530:      	ldr	w0, [sp, #0x190]
    2534:      	ands	w5, w0, #0x1
    2538:      	mov	w0, #0x4                ; =4
    253c:      	csel	w0, w0, wzr, ne
    2540:      	csel	w3, w9, wzr, ne
    2544:      	ldr	w9, [sp, #0x94]
    2548:      	ands	w7, w9, #0x1
    254c:      	csel	w9, w19, wzr, ne
    2550:      	orr	x19, x28, x9
    2554:      	ldrb	w19, [x19]
    2558:      	str	q2, [sp, #0x4c0]
    255c:      	str	q3, [sp, #0x4b0]
    2560:      	add	x2, sp, #0x4b0
    2564:      	ldr	s18, [x2, w9, uxtw #2]
    2568:      	csel	w9, w25, wzr, ne
    256c:      	tst	w7, w19
    2570:      	orr	x19, x28, x0
    2574:      	ldrb	w19, [x19]
    2578:      	str	q2, [sp, #0x4a0]
    257c:      	str	q3, [sp, #0x490]
    2580:      	add	x2, sp, #0x490
    2584:      	ldr	s19, [x2, w0, uxtw #2]
    2588:      	orr	x0, x28, x17
    258c:      	ldrb	w0, [x0]
    2590:      	str	q2, [sp, #0x480]
    2594:      	str	q3, [sp, #0x470]
    2598:      	add	x2, sp, #0x470
    259c:      	ldr	s20, [x2, w17, uxtw #2]
    25a0:      	fcsel	s18, s18, s22, ne
    25a4:      	tst	w5, w19
    25a8:      	fcsel	s19, s19, s22, ne
    25ac:      	tst	w6, w0
    25b0:      	orr	x17, x28, x16
    25b4:      	ldrb	w17, [x17]
    25b8:      	str	q2, [sp, #0x460]
    25bc:      	str	q3, [sp, #0x450]
    25c0:      	add	x0, sp, #0x450
    25c4:      	ldr	s21, [x0, w16, uxtw #2]
    25c8:      	fcsel	s20, s20, s22, ne
    25cc:      	tst	w11, w17
    25d0:      	fcsel	s21, s21, s22, ne
    25d4:      	mov.s	v18[1], v19[0]
    25d8:      	mov.s	v18[2], v20[0]
    25dc:      	mov.s	v18[3], v21[0]
    25e0:      	mov.s	v4[1], v7[0]
    25e4:      	mov.s	v4[2], v16[0]
    25e8:      	lsr	x16, x13, #1
    25ec:      	add	x17, sp, #0x430
    25f0:      	bfi	x17, x16, #3, #1
    25f4:      	mov.s	v4[3], v17[0]
    25f8:      	fadd.4s	v3, v3, v4
    25fc:      	fadd.4s	v2, v2, v18
    2600:      	orr	x13, x28, x13
    2604:      	ldrb	w13, [x13]
    2608:      	str	q2, [sp, #0x440]
    260c:      	str	q3, [sp, #0x430]
    2610:      	ldr	s4, [x17]
    2614:      	tst	w1, w13
    2618:      	fcsel	s4, s4, s22, ne
    261c:      	ldr	w13, [sp, #0xbc]
    2620:      	ands	w13, w13, #0x1
    2624:      	mov	w16, #0x3               ; =3
    2628:      	csel	w16, w16, wzr, ne
    262c:      	orr	x17, x28, x16
    2630:      	ldrb	w17, [x17]
    2634:      	tst	w13, w17
    2638:      	add	x13, sp, #0x370
    263c:      	orr	x13, x13, x16, lsl #2
    2640:      	stp	q3, q2, [sp, #0x370]
    2644:      	ldr	s7, [x13]
    2648:      	add	x13, sp, #0x328
    264c:      	bfxil	x13, x22, #0, #1
    2650:      	ldrb	w13, [x13]
    2654:      	fcsel	s7, s7, s22, ne
    2658:      	ldr	w16, [sp, #0xb0]
    265c:      	tst	w16, #0x1
    2660:      	fcsel	s16, s3, s22, ne
    2664:      	tst	w14, w13
    2668:      	add	x13, sp, #0x410
    266c:      	bfi	x13, x22, #2, #1
    2670:      	str	q2, [sp, #0x420]
    2674:      	str	q3, [sp, #0x410]
    2678:      	ldr	s17, [x13]
    267c:      	fcsel	s17, s17, s22, ne
    2680:      	orr	x13, x28, x9
    2684:      	ldrb	w13, [x13]
    2688:      	tst	w7, w13
    268c:      	stp	q3, q2, [sp, #0x3f0]
    2690:      	add	x13, sp, #0x3f0
    2694:      	ldr	s18, [x13, w9, uxtw #2]
    2698:      	orr	x9, x28, x3
    269c:      	ldrb	w9, [x9]
    26a0:      	stp	q3, q2, [sp, #0x3d0]
    26a4:      	add	x13, sp, #0x3d0
    26a8:      	ldr	s19, [x13, w3, uxtw #2]
    26ac:      	fcsel	s18, s18, s22, ne
    26b0:      	tst	w5, w9
    26b4:      	fcsel	s19, s19, s22, ne
    26b8:      	orr	x9, x28, x15
    26bc:      	ldrb	w9, [x9]
    26c0:      	stp	q3, q2, [sp, #0x3b0]
    26c4:      	add	x13, sp, #0x3b0
    26c8:      	ldr	s20, [x13, w15, uxtw #2]
    26cc:      	tst	w6, w9
    26d0:      	fcsel	s20, s20, s22, ne
    26d4:      	orr	x9, x28, x4
    26d8:      	ldrb	w9, [x9]
    26dc:      	stp	q3, q2, [sp, #0x390]
    26e0:      	add	x13, sp, #0x390
    26e4:      	ldr	s21, [x13, w4, uxtw #2]
    26e8:      	tst	w11, w9
    26ec:      	fcsel	s21, s21, s22, ne
    26f0:      	mov.s	v4[1], v7[0]
    26f4:      	mov.s	v4[2], v16[0]
    26f8:      	mov.s	v4[3], v17[0]
    26fc:      	mov.s	v18[1], v19[0]
    2700:      	mov.s	v18[2], v20[0]
    2704:      	mov.s	v18[3], v21[0]
    2708:      	fadd.4s	v3, v3, v4
    270c:      	fadd.4s	v2, v2, v18
    2710:      	orr	x9, x28, x30
    2714:      	ldrb	w9, [x9]
    2718:      	stp	q3, q2, [sp, #0x350]
    271c:      	add	x11, sp, #0x350
    2720:      	ldr	s2, [x11, w30, uxtw #2]
    2724:      	tst	w1, w9
    2728:      	fcsel	s2, s2, s22, ne
    272c:      	tst	w10, #0x1
    2730:      	fadd	s2, s3, s2
    2734:      	fcsel	s3, s2, s22, ne
    2738:      	tst	w27, #0x1
    273c:      	fcsel	s4, s2, s22, ne
    2740:      	tst	w16, #0x1
    2744:      	fcsel	s7, s2, s22, ne
    2748:      	ldr	w9, [sp, #0x84]
    274c:      	tst	w9, #0x1
    2750:      	fcsel	s16, s2, s22, ne
    2754:      	ldr	w9, [sp, #0x98]
    2758:      	tst	w9, #0x1
    275c:      	fcsel	s17, s2, s22, ne
    2760:      	ldp	w9, w11, [sp, #0x7c]
    2764:      	tst	w11, #0x1
    2768:      	fcsel	s18, s2, s22, ne
    276c:      	tst	w9, #0x1
    2770:      	fcsel	s19, s2, s22, ne
    2774:      	ldr	w9, [sp, #0x78]
    2778:      	tst	w9, #0x1
    277c:      	fcsel	s2, s2, s22, ne
    2780:      	mov.s	v3[1], v4[0]
    2784:      	mov.s	v3[2], v7[0]
    2788:      	mov.s	v3[3], v16[0]
    278c:      	mov.s	v17[1], v18[0]
    2790:      	mov.s	v17[2], v19[0]
    2794:      	mov.s	v17[3], v2[0]
    2798:      	stp	q3, q17, [sp, #0x330]
    279c:      	ldr	x9, [sp, #0x70]
    27a0:      	and	x9, x9, #0x7
    27a4:      	add	x10, sp, #0x330
    27a8:      	ldr	s2, [x10, x9, lsl #2]
    27ac:      	fadd	s2, s2, s22
    27b0:      	dup.4s	v2, v2[0]
    27b4:      	ldp	x9, x13, [sp, #0x128]
    27b8:      	add	x9, x13, x9
    27bc:      	movi.2d	v3, #0000000000000000
    27c0:      	movi.2d	v4, #0000000000000000
    27c4:      	movi.2d	v7, #0000000000000000
    27c8:      	movi.2d	v16, #0000000000000000
    27cc:      	ldr	w19, [sp, #0x3c]
    27d0:      	add	x4, sp, #0xda0
    27d4:      	movi.2s	v8, #0x41
    27d8:      	adrp	x16, 0x2000 <_llm_rows.packet_batch.blocks+0x15ec>
    27dc:      	adrp	x17, 0x2000 <_llm_rows.packet_batch.blocks+0x15ec>
    27e0:      	adrp	x0, 0x2000 <_llm_rows.packet_batch.blocks+0x15ec>
    27e4:      	adrp	x1, 0x2000 <_llm_rows.packet_batch.blocks+0x15ec>
    27e8:      	add	x5, sp, #0xb60
    27ec:      	movi.8b	v14, #0x1
    27f0:      	ldp	q19, q23, [sp, #0x250]
    27f4:      	ldr	x14, [sp, #0x120]
    27f8:      	ldp	q21, q20, [sp, #0x280]
    27fc:      	ldr	q22, [sp, #0x270]
    2800:      	b	0x2828 <_llm_rows.packet_batch.blocks+0x1e14>
    2804:      	add.2d	v17, v3, v23
    2808:      	add.2d	v4, v4, v21
    280c:      	add.2d	v7, v7, v22
    2810:      	add.2d	v16, v16, v20
    2814:      	fmov	x8, d3
    2818:      	add	x8, x8, x12
    281c:      	mov.16b	v3, v17
    2820:      	cmp	x8, #0x8
    2824:      	b.ge	0x28d8 <_llm_rows.packet_batch.blocks+0x1ec4>
    2828:      	fmov	w10, s19
    282c:      	lsl	x8, x8, #5
    2830:      	add	x11, x23, x8
    2834:      	ldp	q18, q17, [x11]
    2838:      	and.16b	v18, v1, v18
    283c:      	fdiv.4s	v18, v18, v2
    2840:      	add	x8, x9, x8
    2844:      	tbnz	w10, #0x0, 0x2874 <_llm_rows.packet_batch.blocks+0x1e60>
    2848:      	and	w10, w10, #0xff
    284c:      	tbnz	w10, #0x1, 0x2880 <_llm_rows.packet_batch.blocks+0x1e6c>
    2850:      	tbnz	w10, #0x2, 0x288c <_llm_rows.packet_batch.blocks+0x1e78>
    2854:      	tbnz	w10, #0x3, 0x2898 <_llm_rows.packet_batch.blocks+0x1e84>
    2858:      	and.16b	v17, v0, v17
    285c:      	fdiv.4s	v17, v17, v2
    2860:      	tbnz	w10, #0x4, 0x28ac <_llm_rows.packet_batch.blocks+0x1e98>
    2864:      	tbnz	w10, #0x5, 0x28b4 <_llm_rows.packet_batch.blocks+0x1ea0>
    2868:      	tbnz	w10, #0x6, 0x28c0 <_llm_rows.packet_batch.blocks+0x1eac>
    286c:      	tbz	w10, #0x7, 0x2804 <_llm_rows.packet_batch.blocks+0x1df0>
    2870:      	b	0x28cc <_llm_rows.packet_batch.blocks+0x1eb8>
    2874:      	str	s18, [x8]
    2878:      	and	w10, w10, #0xff
    287c:      	tbz	w10, #0x1, 0x2850 <_llm_rows.packet_batch.blocks+0x1e3c>
    2880:      	add	x11, x8, #0x4
    2884:      	st1.s	{ v18 }[1], [x11]
    2888:      	tbz	w10, #0x2, 0x2854 <_llm_rows.packet_batch.blocks+0x1e40>
    288c:      	add	x11, x8, #0x8
    2890:      	st1.s	{ v18 }[2], [x11]
    2894:      	tbz	w10, #0x3, 0x2858 <_llm_rows.packet_batch.blocks+0x1e44>
    2898:      	add	x11, x8, #0xc
    289c:      	st1.s	{ v18 }[3], [x11]
    28a0:      	and.16b	v17, v0, v17
    28a4:      	fdiv.4s	v17, v17, v2
    28a8:      	tbz	w10, #0x4, 0x2864 <_llm_rows.packet_batch.blocks+0x1e50>
    28ac:      	str	s17, [x8, #0x10]
    28b0:      	tbz	w10, #0x5, 0x2868 <_llm_rows.packet_batch.blocks+0x1e54>
    28b4:      	add	x11, x8, #0x14
    28b8:      	st1.s	{ v17 }[1], [x11]
    28bc:      	tbz	w10, #0x6, 0x286c <_llm_rows.packet_batch.blocks+0x1e58>
    28c0:      	add	x11, x8, #0x18
    28c4:      	st1.s	{ v17 }[2], [x11]
    28c8:      	tbz	w10, #0x7, 0x2804 <_llm_rows.packet_batch.blocks+0x1df0>
    28cc:      	add	x8, x8, #0x1c
    28d0:      	st1.s	{ v17 }[3], [x8]
    28d4:      	b	0x2804 <_llm_rows.packet_batch.blocks+0x1df0>
    28d8:      	ldr	d0, [sp, #0xd8]
    28dc:      	fmov	w8, s0
    28e0:      	zip1.8b	v0, v10, v0
    28e4:      	ushll.4s	v0, v0, #0x0
    28e8:      	shl.4s	v0, v0, #0x1f
    28ec:      	cmlt.4s	v0, v0, #0
    28f0:      	and.16b	v0, v0, v6
    28f4:      	fdiv.4s	v0, v0, v2
    28f8:      	ldr	q3, [sp, #0x110]
    28fc:      	ldp	q4, q6, [sp, #0xf0]
    2900:      	stp	q3, q4, [sp, #0x2e0]
    2904:      	ldr	q1, [sp, #0xe0]
    2908:      	stp	q6, q1, [sp, #0x300]
    290c:      	and	x9, x14, #0x7
    2910:      	add	x10, sp, #0x2e0
    2914:      	ldr	x9, [x10, x9, lsl #3]
    2918:      	sub	x9, x9, x14
    291c:      	add	x9, x13, x9, lsl #2
    2920:      	tbnz	w8, #0x0, 0x29a8 <_llm_rows.packet_batch.blocks+0x1f94>
    2924:      	ldr	w22, [sp, #0x13c]
    2928:      	tbnz	w8, #0x1, 0x29b4 <_llm_rows.packet_batch.blocks+0x1fa0>
    292c:      	tbnz	w8, #0x2, 0x29c0 <_llm_rows.packet_batch.blocks+0x1fac>
    2930:      	tbz	w8, #0x3, 0x293c <_llm_rows.packet_batch.blocks+0x1f28>
    2934:      	add	x10, x9, #0xc
    2938:      	st1.s	{ v0 }[3], [x10]
    293c:      	zip2.8b	v0, v10, v0
    2940:      	ushll.4s	v0, v0, #0x0
    2944:      	shl.4s	v0, v0, #0x1f
    2948:      	cmlt.4s	v0, v0, #0
    294c:      	and.16b	v0, v0, v5
    2950:      	fdiv.4s	v0, v0, v2
    2954:      	tbnz	w8, #0x4, 0x29d0 <_llm_rows.packet_batch.blocks+0x1fbc>
    2958:      	tbnz	w8, #0x5, 0x29d8 <_llm_rows.packet_batch.blocks+0x1fc4>
    295c:      	tbnz	w8, #0x6, 0x29e4 <_llm_rows.packet_batch.blocks+0x1fd0>
    2960:      	tbz	w8, #0x7, 0xae4 <_llm_rows.packet_batch.blocks+0xd0>
    2964:      	b	0x29f0 <_llm_rows.packet_batch.blocks+0x1fdc>
    2968:      	fmov	x14, d6
    296c:      	ld1.b	{ v3 }[2], [x14]
    2970:      	tbz	w11, #0x3, 0x16fc <_llm_rows.packet_batch.blocks+0xce8>
    2974:      	ld1.b	{ v3 }[3], [x13]
    2978:      	tbz	w11, #0x4, 0x1700 <_llm_rows.packet_batch.blocks+0xcec>
    297c:      	fmov	x13, d5
    2980:      	ld1.b	{ v3 }[4], [x13]
    2984:      	tbz	w11, #0x5, 0x1704 <_llm_rows.packet_batch.blocks+0xcf0>
    2988:      	ld1.b	{ v3 }[5], [x9]
    298c:      	tbz	w11, #0x6, 0x1708 <_llm_rows.packet_batch.blocks+0xcf4>
    2990:      	fmov	x9, d4
    2994:      	ld1.b	{ v3 }[6], [x9]
    2998:      	stp	q26, q25, [sp, #0x210]
    299c:      	stp	q29, q27, [sp, #0x1f0]
    29a0:      	tbnz	w11, #0x7, 0x1714 <_llm_rows.packet_batch.blocks+0xd00>
    29a4:      	b	0x1718 <_llm_rows.packet_batch.blocks+0xd04>
    29a8:      	str	s0, [x9]
    29ac:      	ldr	w22, [sp, #0x13c]
    29b0:      	tbz	w8, #0x1, 0x292c <_llm_rows.packet_batch.blocks+0x1f18>
    29b4:      	add	x10, x9, #0x4
    29b8:      	st1.s	{ v0 }[1], [x10]
    29bc:      	tbz	w8, #0x2, 0x2930 <_llm_rows.packet_batch.blocks+0x1f1c>
    29c0:      	add	x10, x9, #0x8
    29c4:      	st1.s	{ v0 }[2], [x10]
    29c8:      	tbnz	w8, #0x3, 0x2934 <_llm_rows.packet_batch.blocks+0x1f20>
    29cc:      	b	0x293c <_llm_rows.packet_batch.blocks+0x1f28>
    29d0:      	str	s0, [x9, #0x10]
    29d4:      	tbz	w8, #0x5, 0x295c <_llm_rows.packet_batch.blocks+0x1f48>
    29d8:      	add	x10, x9, #0x14
    29dc:      	st1.s	{ v0 }[1], [x10]
    29e0:      	tbz	w8, #0x6, 0x2960 <_llm_rows.packet_batch.blocks+0x1f4c>
    29e4:      	add	x10, x9, #0x18
    29e8:      	st1.s	{ v0 }[2], [x10]
    29ec:      	tbz	w8, #0x7, 0xae4 <_llm_rows.packet_batch.blocks+0xd0>
    29f0:      	add	x8, x9, #0x1c
    29f4:      	st1.s	{ v0 }[3], [x8]
    29f8:      	b	0xae4 <_llm_rows.packet_batch.blocks+0xd0>
    29fc:      	add	sp, sp, #0xec0
    2a00:      	ldp	x29, x30, [sp, #0x90]
    2a04:      	ldp	x20, x19, [sp, #0x80]
    2a08:      	ldp	x22, x21, [sp, #0x70]
    2a0c:      	ldp	x24, x23, [sp, #0x60]
    2a10:      	ldp	x26, x25, [sp, #0x50]
    2a14:      	ldp	x28, x27, [sp, #0x40]
    2a18:      	ldp	d9, d8, [sp, #0x30]
    2a1c:      	ldp	d11, d10, [sp, #0x20]
    2a20:      	ldp	d13, d12, [sp, #0x10]
    2a24:      	ldp	d15, d14, [sp], #0xa0
    2a28:      	ret

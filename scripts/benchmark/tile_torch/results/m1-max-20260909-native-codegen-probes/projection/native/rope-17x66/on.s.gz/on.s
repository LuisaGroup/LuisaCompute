
/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/rope-17x66/on/object/tile_xir_w8_38074_1788936547419897_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	sub	sp, sp, #0x130
       4:      	stp	d15, d14, [sp, #0xe0]
       8:      	stp	d13, d12, [sp, #0xf0]
       c:      	stp	d11, d10, [sp, #0x100]
      10:      	stp	d9, d8, [sp, #0x110]
      14:      	stp	x28, x27, [sp, #0x120]
      18:      	ldr	x10, [x0]
      1c:      	ldr	x11, [x0, #0x10]
      20:      	ldr	x9, [x0, #0x20]
      24:      	ldr	x8, [x0, #0x30]
      28:      	ldr	w12, [x1]
      2c:      	ldr	w13, [x1, #0x24]
      30:      	add	w12, w13, w12, lsl #5
      34:      	lsr	w12, w12, #3
      38:      	subs	x13, x10, x8
      3c:      	lsr	x13, x13, #3
      40:      	mov	w14, #0x230             ; =560
      44:      	ccmp	x13, x14, #0x0, hs
      48:      	cset	w13, hi
      4c:      	subs	x15, x8, x10
      50:      	lsr	x15, x15, #3
      54:      	ccmp	x15, x14, #0x0, hs
      58:      	csinc	w15, w13, wzr, ls
      5c:      	subs	x13, x11, x8
      60:      	lsr	x13, x13, #3
      64:      	ccmp	x13, x14, #0x0, hs
      68:      	cset	w13, hi
      6c:      	subs	x16, x8, x11
      70:      	mov	w17, #0x8c3             ; =2243
      74:      	ccmp	x16, x17, #0x0, hs
      78:      	csinc	w13, w13, wzr, ls
      7c:      	subs	x16, x9, x8
      80:      	lsr	x16, x16, #3
      84:      	ccmp	x16, x14, #0x0, hs
      88:      	cset	w14, hi
      8c:      	subs	x16, x8, x9
      90:      	ccmp	x16, x17, #0x0, hs
      94:      	csinc	w14, w14, wzr, ls
      98:      	add	x2, x12, x12, lsl #5
      9c:      	lsl	x12, x2, #3
      a0:      	add	x16, x10, x12
      a4:      	ldp	q21, q1, [x16]
      a8:      	cmp	w14, #0x1
      ac:      	ccmp	w15, #0x0, #0x4, eq
      b0:      	b.eq	0x298 <ltmp0+0x298>
      b4:      	tbz	w13, #0x0, 0x298 <ltmp0+0x298>
      b8:      	add	x14, x12, #0x84
      bc:      	add	x13, x10, x14
      c0:      	ldp	q0, q2, [x13]
      c4:      	lsl	x13, x2, #2
      c8:      	add	x15, x11, x13
      cc:      	ldp	q3, q4, [x15]
      d0:      	add	x15, x9, x13
      d4:      	ldp	q5, q6, [x15]
      d8:      	fmul.4s	v16, v1, v4
      dc:      	fmul.4s	v17, v21, v3
      e0:      	fmul.4s	v18, v2, v6
      e4:      	fmul.4s	v19, v0, v5
      e8:      	fsub.4s	v17, v17, v19
      ec:      	fsub.4s	v16, v16, v18
      f0:      	add	x15, x8, x12
      f4:      	stp	q17, q16, [x15]
      f8:      	fmul.4s	v1, v1, v6
      fc:      	fmul.4s	v5, v21, v5
     100:      	fmul.4s	v2, v2, v4
     104:      	fmul.4s	v0, v0, v3
     108:      	fadd.4s	v0, v0, v5
     10c:      	fadd.4s	v1, v2, v1
     110:      	add	x14, x8, x14
     114:      	stp	q0, q1, [x14]
     118:      	add	x14, x12, #0x20
     11c:      	add	x15, x10, x14
     120:      	ldp	q0, q1, [x15]
     124:      	add	x15, x12, #0xa4
     128:      	add	x16, x10, x15
     12c:      	ldp	q2, q3, [x16]
     130:      	add	x16, x13, #0x20
     134:      	add	x17, x11, x16
     138:      	ldp	q4, q5, [x17]
     13c:      	add	x16, x9, x16
     140:      	ldp	q6, q7, [x16]
     144:      	fmul.4s	v16, v1, v5
     148:      	fmul.4s	v17, v0, v4
     14c:      	fmul.4s	v18, v3, v7
     150:      	fmul.4s	v19, v2, v6
     154:      	fsub.4s	v17, v17, v19
     158:      	fsub.4s	v16, v16, v18
     15c:      	add	x14, x8, x14
     160:      	stp	q17, q16, [x14]
     164:      	fmul.4s	v1, v1, v7
     168:      	fmul.4s	v0, v0, v6
     16c:      	fmul.4s	v3, v3, v5
     170:      	fmul.4s	v2, v2, v4
     174:      	fadd.4s	v0, v2, v0
     178:      	fadd.4s	v1, v3, v1
     17c:      	add	x14, x8, x15
     180:      	stp	q0, q1, [x14]
     184:      	add	x14, x12, #0x40
     188:      	add	x15, x10, x14
     18c:      	ldp	q0, q1, [x15]
     190:      	add	x15, x12, #0xc4
     194:      	add	x16, x10, x15
     198:      	ldp	q2, q3, [x16]
     19c:      	add	x16, x13, #0x40
     1a0:      	add	x17, x11, x16
     1a4:      	ldp	q4, q5, [x17]
     1a8:      	add	x16, x9, x16
     1ac:      	ldp	q6, q7, [x16]
     1b0:      	fmul.4s	v16, v1, v5
     1b4:      	fmul.4s	v17, v0, v4
     1b8:      	fmul.4s	v18, v3, v7
     1bc:      	fmul.4s	v19, v2, v6
     1c0:      	fsub.4s	v17, v17, v19
     1c4:      	fsub.4s	v16, v16, v18
     1c8:      	add	x14, x8, x14
     1cc:      	stp	q17, q16, [x14]
     1d0:      	fmul.4s	v1, v1, v7
     1d4:      	fmul.4s	v0, v0, v6
     1d8:      	fmul.4s	v3, v3, v5
     1dc:      	fmul.4s	v2, v2, v4
     1e0:      	fadd.4s	v0, v2, v0
     1e4:      	fadd.4s	v1, v3, v1
     1e8:      	add	x14, x8, x15
     1ec:      	stp	q0, q1, [x14]
     1f0:      	add	x14, x12, #0x60
     1f4:      	add	x15, x10, x14
     1f8:      	ldp	q1, q0, [x15]
     1fc:      	add	x15, x12, #0xe4
     200:      	add	x16, x10, x15
     204:      	ldp	q3, q2, [x16]
     208:      	add	x16, x13, #0x60
     20c:      	add	x17, x11, x16
     210:      	ldp	q5, q4, [x17]
     214:      	add	x16, x9, x16
     218:      	ldp	q7, q6, [x16]
     21c:      	fmul.4s	v16, v1, v5
     220:      	fmul.4s	v17, v0, v4
     224:      	fmul.4s	v18, v3, v7
     228:      	fmul.4s	v19, v2, v6
     22c:      	fsub.4s	v17, v17, v19
     230:      	fsub.4s	v16, v16, v18
     234:      	add	x14, x8, x14
     238:      	stp	q16, q17, [x14]
     23c:      	fmul.4s	v1, v1, v7
     240:      	fmul.4s	v0, v0, v6
     244:      	fmul.4s	v3, v3, v5
     248:      	fmul.4s	v2, v2, v4
     24c:      	fadd.4s	v0, v2, v0
     250:      	fadd.4s	v1, v3, v1
     254:      	add	x14, x8, x15
     258:      	stp	q1, q0, [x14]
     25c:      	add	x14, x12, #0x80
     260:      	ldr	s0, [x10, x14]
     264:      	add	x1, x12, #0x104
     268:      	ldr	s1, [x10, x1]
     26c:      	add	x10, x13, #0x80
     270:      	ldr	s2, [x11, x10]
     274:      	ldr	s3, [x9, x10]
     278:      	fmul.4s	v4, v0, v2
     27c:      	fmul.4s	v5, v1, v3
     280:      	fsub.4s	v4, v4, v5
     284:      	str	s4, [x8, x14]
     288:      	fmul.4s	v0, v0, v3
     28c:      	fmul.4s	v1, v1, v2
     290:      	fadd.4s	v0, v1, v0
     294:      	b	0x4c4 <ltmp0+0x4c4>
     298:      	add	x0, x12, #0x20
     29c:      	add	x13, x10, x0
     2a0:      	ldp	q6, q16, [x13]
     2a4:      	add	x17, x12, #0x40
     2a8:      	add	x13, x10, x17
     2ac:      	ldp	q5, q7, [x13]
     2b0:      	stp	q6, q5, [sp, #0x80]
     2b4:      	stp	q16, q7, [sp, #0x40]
     2b8:      	add	x16, x12, #0x60
     2bc:      	add	x1, x10, x16
     2c0:      	add	x15, x12, #0x84
     2c4:      	add	x13, x10, x15
     2c8:      	ldp	q18, q3, [x13]
     2cc:      	str	q3, [sp]
     2d0:      	add	x14, x12, #0xa4
     2d4:      	add	x13, x10, x14
     2d8:      	ldp	q17, q25, [x13]
     2dc:      	stp	q25, q17, [sp, #0x60]
     2e0:      	add	x13, x12, #0xc4
     2e4:      	add	x3, x10, x13
     2e8:      	ldp	q19, q20, [x3]
     2ec:      	stp	q20, q19, [sp, #0xc0]
     2f0:      	lsl	x3, x2, #2
     2f4:      	add	x2, x11, x3
     2f8:      	ldp	q22, q23, [x2]
     2fc:      	add	x2, x3, #0x20
     300:      	add	x4, x11, x2
     304:      	ldp	q27, q28, [x4]
     308:      	stp	q28, q27, [sp, #0xa0]
     30c:      	add	x4, x3, #0x40
     310:      	add	x5, x11, x4
     314:      	add	x6, x9, x3
     318:      	ldp	q29, q9, [x6]
     31c:      	add	x2, x9, x2
     320:      	add	x4, x9, x4
     324:      	ldp	q24, q26, [x2]
     328:      	fmul.4s	v0, v1, v23
     32c:      	fmul.4s	v2, v21, v22
     330:      	fmul.4s	v3, v3, v9
     334:      	fmul.4s	v4, v18, v29
     338:      	fsub.4s	v2, v2, v4
     33c:      	fsub.4s	v0, v0, v3
     340:      	stp	q0, q2, [sp, #0x20]
     344:      	fmul.4s	v0, v16, v28
     348:      	fmul.4s	v3, v6, v27
     34c:      	fmul.4s	v6, v25, v26
     350:      	fmul.4s	v4, v17, v24
     354:      	ldp	q25, q27, [x5]
     358:      	fsub.4s	v2, v3, v4
     35c:      	str	q2, [sp, #0x10]
     360:      	ldp	q30, q11, [x4]
     364:      	fsub.4s	v17, v0, v6
     368:      	fmul.4s	v0, v7, v27
     36c:      	fmul.4s	v3, v5, v25
     370:      	fmul.4s	v6, v20, v11
     374:      	fmul.4s	v28, v19, v30
     378:      	fsub.4s	v16, v3, v28
     37c:      	fsub.4s	v5, v0, v6
     380:      	ldp	q28, q31, [x1]
     384:      	add	x2, x12, #0xe4
     388:      	add	x1, x10, x2
     38c:      	add	x4, x3, #0x60
     390:      	add	x5, x11, x4
     394:      	add	x4, x9, x4
     398:      	ldp	q8, q10, [x5]
     39c:      	fmul.4s	v3, v28, v8
     3a0:      	ldp	q12, q13, [x1]
     3a4:      	ldp	q0, q6, [x4]
     3a8:      	fmul.4s	v14, v12, v0
     3ac:      	fsub.4s	v4, v3, v14
     3b0:      	fmul.4s	v3, v31, v10
     3b4:      	fmul.4s	v14, v13, v6
     3b8:      	fsub.4s	v2, v3, v14
     3bc:      	add	x4, x12, #0x80
     3c0:      	add	x1, x12, #0x104
     3c4:      	add	x3, x3, #0x80
     3c8:      	ldr	s14, [x10, x4]
     3cc:      	ldr	s15, [x11, x3]
     3d0:      	fmul.4s	v7, v14, v15
     3d4:      	ldr	s3, [x10, x1]
     3d8:      	ldr	s20, [x9, x3]
     3dc:      	fmul.4s	v19, v3, v20
     3e0:      	fsub.4s	v7, v7, v19
     3e4:      	fmul.4s	v1, v1, v9
     3e8:      	fmul.4s	v19, v21, v29
     3ec:      	ldr	q21, [sp]
     3f0:      	fmul.4s	v21, v21, v23
     3f4:      	fmul.4s	v22, v18, v22
     3f8:      	add	x9, x8, x12
     3fc:      	ldp	q23, q18, [sp, #0x20]
     400:      	stp	q18, q23, [x9]
     404:      	fadd.4s	v19, v22, v19
     408:      	fadd.4s	v1, v21, v1
     40c:      	ldr	q18, [sp, #0x40]
     410:      	fmul.4s	v21, v18, v26
     414:      	add	x9, x8, x0
     418:      	str	q17, [x9, #0x10]
     41c:      	ldr	q17, [sp, #0x10]
     420:      	str	q17, [x9]
     424:      	ldp	q23, q17, [sp, #0x70]
     428:      	fmul.4s	v17, v17, v24
     42c:      	ldr	q18, [sp, #0xa0]
     430:      	ldr	q22, [sp, #0x60]
     434:      	fmul.4s	v18, v22, v18
     438:      	ldr	q22, [sp, #0xb0]
     43c:      	fmul.4s	v22, v23, v22
     440:      	add	x9, x8, x17
     444:      	stp	q16, q5, [x9]
     448:      	fadd.4s	v5, v22, v17
     44c:      	fadd.4s	v16, v18, v21
     450:      	ldr	q17, [sp, #0x50]
     454:      	fmul.4s	v17, v17, v11
     458:      	add	x9, x8, x16
     45c:      	stp	q4, q2, [x9]
     460:      	ldr	q2, [sp, #0x90]
     464:      	fmul.4s	v2, v2, v30
     468:      	str	s7, [x8, x4]
     46c:      	ldp	q4, q7, [sp, #0xc0]
     470:      	fmul.4s	v4, v4, v27
     474:      	fmul.4s	v7, v7, v25
     478:      	fadd.4s	v2, v7, v2
     47c:      	add	x9, x8, x15
     480:      	stp	q19, q1, [x9]
     484:      	fadd.4s	v1, v4, v17
     488:      	fmul.4s	v4, v31, v6
     48c:      	fmul.4s	v0, v28, v0
     490:      	add	x9, x8, x14
     494:      	stp	q5, q16, [x9]
     498:      	fmul.4s	v5, v13, v10
     49c:      	fmul.4s	v6, v12, v8
     4a0:      	fadd.4s	v6, v6, v0
     4a4:      	add	x9, x8, x13
     4a8:      	stp	q2, q1, [x9]
     4ac:      	fadd.4s	v1, v5, v4
     4b0:      	fmul.4s	v0, v14, v20
     4b4:      	fmul.4s	v2, v3, v15
     4b8:      	fadd.4s	v0, v2, v0
     4bc:      	add	x9, x8, x2
     4c0:      	stp	q6, q1, [x9]
     4c4:      	str	s0, [x8, x1]
     4c8:      	ldp	x28, x27, [sp, #0x120]
     4cc:      	ldp	d9, d8, [sp, #0x110]
     4d0:      	ldp	d11, d10, [sp, #0x100]
     4d4:      	ldp	d13, d12, [sp, #0xf0]
     4d8:      	ldp	d15, d14, [sp, #0xe0]
     4dc:      	add	sp, sp, #0x130
     4e0:      	ret

00000000000004e4 <_llm_rows.packet_batch.blocks>:
     4e4:      	cbz	w3, 0x3828 <_llm_rows.packet_batch.blocks+0x3344>
     4e8:      	stp	d15, d14, [sp, #-0xa0]!
     4ec:      	stp	d13, d12, [sp, #0x10]
     4f0:      	stp	d11, d10, [sp, #0x20]
     4f4:      	stp	d9, d8, [sp, #0x30]
     4f8:      	stp	x28, x27, [sp, #0x40]
     4fc:      	stp	x26, x25, [sp, #0x50]
     500:      	stp	x24, x23, [sp, #0x60]
     504:      	stp	x22, x21, [sp, #0x70]
     508:      	stp	x20, x19, [sp, #0x80]
     50c:      	stp	x29, x30, [sp, #0x90]
     510:      	sub	sp, sp, #0x850
     514:      	mov	x19, x3
     518:      	mov	x20, x2
     51c:      	mov	x21, x0
     520:      	mov	w22, #0x20              ; =32
     524:      	ldp	w8, w27, [x2, #0x2c]
     528:      	str	w8, [sp, #0x24c]
     52c:      	ldp	w24, w23, [x2]
     530:      	ldp	w28, w25, [x2, #0x8]
     534:      	adrp	x8, 0x0 <ltmp0>
     538:      	ldr	q0, [x8]
     53c:      	str	q0, [sp, #0x230]
     540:      	adrp	x8, 0x0 <ltmp0>
     544:      	ldr	q0, [x8]
     548:      	str	q0, [sp, #0x220]
     54c:      	adrp	x8, 0x0 <ltmp0>
     550:      	ldr	q0, [x8]
     554:      	str	q0, [sp, #0x200]
     558:      	adrp	x8, 0x0 <ltmp0>
     55c:      	ldr	q0, [x8]
     560:      	str	q0, [sp, #0x1f0]
     564:      	adrp	x8, 0x0 <ltmp0>
     568:      	ldr	q0, [x8]
     56c:      	str	q0, [sp, #0x1e0]
     570:      	adrp	x8, 0x0 <ltmp0>
     574:      	ldr	q0, [x8]
     578:      	str	q0, [sp, #0x1d0]
     57c:      	adrp	x8, 0x0 <ltmp0>
     580:      	ldr	q0, [x8]
     584:      	str	q0, [sp, #0x1c0]
     588:      	movi.2s	v10, #0x42
     58c:      	movi.2s	v12, #0x21
     590:      	b	0x610 <_llm_rows.packet_batch.blocks+0x12c>
     594:      	mov	x0, x21
     598:      	mov	x1, x20
     59c:      	bl	0x59c <_llm_rows.packet_batch.blocks+0xb8>
     5a0:      	mov	w8, #0x8                ; =8
     5a4:      	str	w8, [x20, #0x24]
     5a8:      	mov	x0, x21
     5ac:      	mov	x1, x20
     5b0:      	bl	0x5b0 <_llm_rows.packet_batch.blocks+0xcc>
     5b4:      	mov	w8, #0x10               ; =16
     5b8:      	str	w8, [x20, #0x24]
     5bc:      	mov	x0, x21
     5c0:      	mov	x1, x20
     5c4:      	bl	0x5c4 <_llm_rows.packet_batch.blocks+0xe0>
     5c8:      	mov	w8, #0x18               ; =24
     5cc:      	str	w8, [x20, #0x24]
     5d0:      	mov	x0, x21
     5d4:      	mov	x1, x20
     5d8:      	bl	0x5d8 <_llm_rows.packet_batch.blocks+0xf4>
     5dc:      	add	w8, w24, #0x1
     5e0:      	ldr	w9, [sp, #0x24c]
     5e4:      	cmp	w8, w9
     5e8:      	cset	w8, eq
     5ec:      	csinc	w24, wzr, w24, eq
     5f0:      	cinc	w9, w23, eq
     5f4:      	cmp	w9, w27
     5f8:      	cset	w10, eq
     5fc:      	ands	w8, w8, w10
     600:      	csel	w23, wzr, w9, ne
     604:      	add	w28, w28, w8
     608:      	subs	w19, w19, #0x1
     60c:      	b.eq	0x37fc <_llm_rows.packet_batch.blocks+0x3318>
     610:      	ubfiz	x8, x24, #5, #32
     614:      	cmp	x8, x25
     618:      	csel	x9, x8, xzr, ls
     61c:      	subs	x10, x25, x9
     620:      	cmp	x10, #0x20
     624:      	csel	x10, x10, x22, lo
     628:      	cmp	x25, x9
     62c:      	stp	w24, w23, [x20]
     630:      	str	w28, [x20, #0x8]
     634:      	str	wzr, [x20, #0x24]
     638:      	ccmp	x8, x25, #0x2, hi
     63c:      	csel	x26, x10, xzr, ls
     640:      	cmp	x26, #0x20
     644:      	b.hs	0x594 <_llm_rows.packet_batch.blocks+0xb0>
     648:      	lsr	x22, x26, #3
     64c:      	cmp	x26, #0x8
     650:      	b.lo	0x69c <_llm_rows.packet_batch.blocks+0x1b8>
     654:      	str	wzr, [x20, #0x24]
     658:      	mov	x0, x21
     65c:      	mov	x1, x20
     660:      	bl	0x660 <_llm_rows.packet_batch.blocks+0x17c>
     664:      	cmp	x22, #0x1
     668:      	b.eq	0x69c <_llm_rows.packet_batch.blocks+0x1b8>
     66c:      	mov	w8, #0x8                ; =8
     670:      	str	w8, [x20, #0x24]
     674:      	mov	x0, x21
     678:      	mov	x1, x20
     67c:      	bl	0x67c <_llm_rows.packet_batch.blocks+0x198>
     680:      	cmp	x22, #0x2
     684:      	b.eq	0x69c <_llm_rows.packet_batch.blocks+0x1b8>
     688:      	mov	w8, #0x10               ; =16
     68c:      	str	w8, [x20, #0x24]
     690:      	mov	x0, x21
     694:      	mov	x1, x20
     698:      	bl	0x698 <_llm_rows.packet_batch.blocks+0x1b4>
     69c:      	and	w8, w26, #0x7
     6a0:      	cbz	w8, 0x37ec <_llm_rows.packet_batch.blocks+0x3308>
     6a4:      	dup.4s	v0, w8
     6a8:      	ldp	q2, q1, [sp, #0x220]
     6ac:      	cmhi.4s	v17, v0, v2
     6b0:      	cmhi.4s	v27, v0, v1
     6b4:      	uzp1.8h	v0, v27, v17
     6b8:      	umaxv.8h	h1, v0
     6bc:      	fmov	w8, s1
     6c0:      	tbz	w8, #0x0, 0x37ec <_llm_rows.packet_batch.blocks+0x3308>
     6c4:      	ldr	x11, [x21]
     6c8:      	ldr	x10, [x21, #0x10]
     6cc:      	ldr	x9, [x21, #0x20]
     6d0:      	ldr	x8, [x21, #0x30]
     6d4:      	sshll.2d	v4, v27, #0x0
     6d8:      	sshll.2d	v3, v17, #0x0
     6dc:      	sshll2.2d	v25, v27, #0x0
     6e0:      	sshll2.2d	v8, v17, #0x0
     6e4:      	ldp	q2, q1, [sp, #0x1f0]
     6e8:      	and.16b	v1, v8, v1
     6ec:      	and.16b	v2, v25, v2
     6f0:      	ldp	q5, q6, [sp, #0x1d0]
     6f4:      	and.16b	v3, v3, v6
     6f8:      	and.16b	v16, v4, v5
     6fc:      	ubfiz	w12, w24, #2, #27
     700:      	orr	w13, w12, w22
     704:      	dup.4s	v4, w13
     708:      	and.16b	v5, v27, v4
     70c:      	and.16b	v4, v17, v4
     710:      	ushll2.2d	v7, v4, #0x0
     714:      	ushll2.2d	v18, v5, #0x0
     718:      	ushll.2d	v19, v4, #0x0
     71c:      	ushll.2d	v4, v5, #0x0
     720:      	subs	x12, x11, x8
     724:      	lsr	x12, x12, #3
     728:      	mov	w16, #0x230             ; =560
     72c:      	ccmp	x12, x16, #0x0, hs
     730:      	cset	w12, hi
     734:      	subs	x14, x8, x11
     738:      	lsr	x14, x14, #3
     73c:      	ccmp	x14, x16, #0x0, hs
     740:      	csinc	w12, w12, wzr, ls
     744:      	subs	x14, x10, x8
     748:      	lsr	x14, x14, #3
     74c:      	ccmp	x14, x16, #0x0, hs
     750:      	cset	w14, hi
     754:      	subs	x15, x8, x10
     758:      	mov	w17, #0x8c3             ; =2243
     75c:      	ccmp	x15, x17, #0x0, hs
     760:      	csinc	w14, w14, wzr, ls
     764:      	subs	x15, x9, x8
     768:      	lsr	x15, x15, #3
     76c:      	ccmp	x15, x16, #0x0, hs
     770:      	cset	w15, hi
     774:      	subs	x16, x8, x9
     778:      	ccmp	x16, x17, #0x0, hs
     77c:      	csinc	w15, w15, wzr, ls
     780:      	xtn.2s	v6, v4
     784:      	xtn.2s	v4, v18
     788:      	xtn.2s	v5, v19
     78c:      	xtn.2s	v7, v7
     790:      	cmp	w15, #0x1
     794:      	b.ne	0x1d94 <_llm_rows.packet_batch.blocks+0x18b0>
     798:      	cbz	w12, 0x1d94 <_llm_rows.packet_batch.blocks+0x18b0>
     79c:      	cbz	w14, 0x1d94 <_llm_rows.packet_batch.blocks+0x18b0>
     7a0:      	ldr	q17, [sp, #0x1c0]
     7a4:      	and.16b	v17, v0, v17
     7a8:      	addv.8h	h17, v17
     7ac:      	fmov	w17, s17
     7b0:      	xtn.8b	v0, v0
     7b4:      	umov.b	w12, v0[0]
     7b8:      	add	x15, x13, x13, lsl #5
     7bc:      	lsl	x14, x15, #3
     7c0:      	tst	w12, #0x1
     7c4:      	csel	x13, x14, xzr, ne
     7c8:      	add	x16, x11, x13
     7cc:      	movi.2d	v19, #0000000000000000
     7d0:      	movi.2d	v18, #0000000000000000
     7d4:      	mov	w4, #0x20               ; =32
     7d8:      	tbz	w17, #0x0, 0x870 <_llm_rows.packet_batch.blocks+0x38c>
     7dc:      	ldr	s19, [x16]
     7e0:      	and	w17, w17, #0xff
     7e4:      	tbnz	w17, #0x1, 0x878 <_llm_rows.packet_batch.blocks+0x394>
     7e8:      	tbz	w17, #0x2, 0x884 <_llm_rows.packet_batch.blocks+0x3a0>
     7ec:      	add	x0, x16, #0x8
     7f0:      	ld1.s	{ v19 }[2], [x0]
     7f4:      	tbnz	w17, #0x3, 0x888 <_llm_rows.packet_batch.blocks+0x3a4>
     7f8:      	tbz	w17, #0x4, 0x894 <_llm_rows.packet_batch.blocks+0x3b0>
     7fc:      	add	x0, x16, #0x10
     800:      	ld1.s	{ v18 }[0], [x0]
     804:      	tbnz	w17, #0x5, 0x898 <_llm_rows.packet_batch.blocks+0x3b4>
     808:      	tbz	w17, #0x6, 0x8a4 <_llm_rows.packet_batch.blocks+0x3c0>
     80c:      	add	x0, x16, #0x18
     810:      	ld1.s	{ v18 }[2], [x0]
     814:      	tbnz	w17, #0x7, 0x8a8 <_llm_rows.packet_batch.blocks+0x3c4>
     818:      	fmov	w0, s17
     81c:      	add	x16, x13, #0x84
     820:      	add	x17, x11, x16
     824:      	movi.2d	v21, #0000000000000000
     828:      	movi.2d	v20, #0000000000000000
     82c:      	tbz	w0, #0x0, 0x8c8 <_llm_rows.packet_batch.blocks+0x3e4>
     830:      	ldr	s21, [x17]
     834:      	and	w0, w0, #0xff
     838:      	tbnz	w0, #0x1, 0x8d0 <_llm_rows.packet_batch.blocks+0x3ec>
     83c:      	tbz	w0, #0x2, 0x8dc <_llm_rows.packet_batch.blocks+0x3f8>
     840:      	add	x1, x17, #0x8
     844:      	ld1.s	{ v21 }[2], [x1]
     848:      	tbnz	w0, #0x3, 0x8e0 <_llm_rows.packet_batch.blocks+0x3fc>
     84c:      	tbz	w0, #0x4, 0x8ec <_llm_rows.packet_batch.blocks+0x408>
     850:      	add	x1, x17, #0x10
     854:      	ld1.s	{ v20 }[0], [x1]
     858:      	tbnz	w0, #0x5, 0x8f0 <_llm_rows.packet_batch.blocks+0x40c>
     85c:      	tbz	w0, #0x6, 0x8fc <_llm_rows.packet_batch.blocks+0x418>
     860:      	add	x1, x17, #0x18
     864:      	ld1.s	{ v20 }[2], [x1]
     868:      	tbnz	w0, #0x7, 0x900 <_llm_rows.packet_batch.blocks+0x41c>
     86c:      	b	0x908 <_llm_rows.packet_batch.blocks+0x424>
     870:      	and	w17, w17, #0xff
     874:      	tbz	w17, #0x1, 0x7e8 <_llm_rows.packet_batch.blocks+0x304>
     878:      	add	x0, x16, #0x4
     87c:      	ld1.s	{ v19 }[1], [x0]
     880:      	tbnz	w17, #0x2, 0x7ec <_llm_rows.packet_batch.blocks+0x308>
     884:      	tbz	w17, #0x3, 0x7f8 <_llm_rows.packet_batch.blocks+0x314>
     888:      	add	x0, x16, #0xc
     88c:      	ld1.s	{ v19 }[3], [x0]
     890:      	tbnz	w17, #0x4, 0x7fc <_llm_rows.packet_batch.blocks+0x318>
     894:      	tbz	w17, #0x5, 0x808 <_llm_rows.packet_batch.blocks+0x324>
     898:      	add	x0, x16, #0x14
     89c:      	ld1.s	{ v18 }[1], [x0]
     8a0:      	tbnz	w17, #0x6, 0x80c <_llm_rows.packet_batch.blocks+0x328>
     8a4:      	tbz	w17, #0x7, 0x818 <_llm_rows.packet_batch.blocks+0x334>
     8a8:      	add	x16, x16, #0x1c
     8ac:      	ld1.s	{ v18 }[3], [x16]
     8b0:      	fmov	w0, s17
     8b4:      	add	x16, x13, #0x84
     8b8:      	add	x17, x11, x16
     8bc:      	movi.2d	v21, #0000000000000000
     8c0:      	movi.2d	v20, #0000000000000000
     8c4:      	tbnz	w0, #0x0, 0x830 <_llm_rows.packet_batch.blocks+0x34c>
     8c8:      	and	w0, w0, #0xff
     8cc:      	tbz	w0, #0x1, 0x83c <_llm_rows.packet_batch.blocks+0x358>
     8d0:      	add	x1, x17, #0x4
     8d4:      	ld1.s	{ v21 }[1], [x1]
     8d8:      	tbnz	w0, #0x2, 0x840 <_llm_rows.packet_batch.blocks+0x35c>
     8dc:      	tbz	w0, #0x3, 0x84c <_llm_rows.packet_batch.blocks+0x368>
     8e0:      	add	x1, x17, #0xc
     8e4:      	ld1.s	{ v21 }[3], [x1]
     8e8:      	tbnz	w0, #0x4, 0x850 <_llm_rows.packet_batch.blocks+0x36c>
     8ec:      	tbz	w0, #0x5, 0x85c <_llm_rows.packet_batch.blocks+0x378>
     8f0:      	add	x1, x17, #0x14
     8f4:      	ld1.s	{ v20 }[1], [x1]
     8f8:      	tbnz	w0, #0x6, 0x860 <_llm_rows.packet_batch.blocks+0x37c>
     8fc:      	tbz	w0, #0x7, 0x908 <_llm_rows.packet_batch.blocks+0x424>
     900:      	add	x17, x17, #0x1c
     904:      	ld1.s	{ v20 }[3], [x17]
     908:      	fmov	w1, s17
     90c:      	lsl	x15, x15, #2
     910:      	tst	w12, #0x1
     914:      	csel	x17, x15, xzr, ne
     918:      	add	x0, x10, x17
     91c:      	movi.2d	v22, #0000000000000000
     920:      	movi.2d	v0, #0000000000000000
     924:      	tbz	w1, #0x0, 0xa70 <_llm_rows.packet_batch.blocks+0x58c>
     928:      	ldr	s22, [x0]
     92c:      	and	w1, w1, #0xff
     930:      	tbnz	w1, #0x1, 0xa78 <_llm_rows.packet_batch.blocks+0x594>
     934:      	tbz	w1, #0x2, 0xa84 <_llm_rows.packet_batch.blocks+0x5a0>
     938:      	add	x2, x0, #0x8
     93c:      	ld1.s	{ v22 }[2], [x2]
     940:      	tbnz	w1, #0x3, 0xa88 <_llm_rows.packet_batch.blocks+0x5a4>
     944:      	tbz	w1, #0x4, 0xa94 <_llm_rows.packet_batch.blocks+0x5b0>
     948:      	add	x2, x0, #0x10
     94c:      	ld1.s	{ v0 }[0], [x2]
     950:      	tbnz	w1, #0x5, 0xa98 <_llm_rows.packet_batch.blocks+0x5b4>
     954:      	tbz	w1, #0x6, 0xaa4 <_llm_rows.packet_batch.blocks+0x5c0>
     958:      	add	x2, x0, #0x18
     95c:      	ld1.s	{ v0 }[2], [x2]
     960:      	tbnz	w1, #0x7, 0xaa8 <_llm_rows.packet_batch.blocks+0x5c4>
     964:      	fmov	w0, s17
     968:      	add	x17, x9, x17
     96c:      	movi.2d	v24, #0000000000000000
     970:      	movi.2d	v23, #0000000000000000
     974:      	tbz	w0, #0x0, 0xac4 <_llm_rows.packet_batch.blocks+0x5e0>
     978:      	ldr	s24, [x17]
     97c:      	and	w0, w0, #0xff
     980:      	tbnz	w0, #0x1, 0xacc <_llm_rows.packet_batch.blocks+0x5e8>
     984:      	tbz	w0, #0x2, 0xad8 <_llm_rows.packet_batch.blocks+0x5f4>
     988:      	add	x1, x17, #0x8
     98c:      	ld1.s	{ v24 }[2], [x1]
     990:      	tbnz	w0, #0x3, 0xadc <_llm_rows.packet_batch.blocks+0x5f8>
     994:      	tbz	w0, #0x4, 0xae8 <_llm_rows.packet_batch.blocks+0x604>
     998:      	add	x1, x17, #0x10
     99c:      	ld1.s	{ v23 }[0], [x1]
     9a0:      	tbnz	w0, #0x5, 0xaec <_llm_rows.packet_batch.blocks+0x608>
     9a4:      	tbz	w0, #0x6, 0xaf8 <_llm_rows.packet_batch.blocks+0x614>
     9a8:      	add	x1, x17, #0x18
     9ac:      	ld1.s	{ v23 }[2], [x1]
     9b0:      	tbnz	w0, #0x7, 0xafc <_llm_rows.packet_batch.blocks+0x618>
     9b4:      	fmov	w0, s17
     9b8:      	fmul.4s	v25, v19, v22
     9bc:      	fmul.4s	v26, v21, v24
     9c0:      	fsub.4s	v25, v25, v26
     9c4:      	add	x17, x8, x13
     9c8:      	tbz	w0, #0x0, 0xb1c <_llm_rows.packet_batch.blocks+0x638>
     9cc:      	str	s25, [x17]
     9d0:      	and	w0, w0, #0xff
     9d4:      	tbnz	w0, #0x1, 0xb24 <_llm_rows.packet_batch.blocks+0x640>
     9d8:      	tbz	w0, #0x2, 0xb30 <_llm_rows.packet_batch.blocks+0x64c>
     9dc:      	add	x1, x17, #0x8
     9e0:      	st1.s	{ v25 }[2], [x1]
     9e4:      	tbnz	w0, #0x3, 0xb34 <_llm_rows.packet_batch.blocks+0x650>
     9e8:      	fmul.4s	v25, v18, v0
     9ec:      	fmul.4s	v26, v20, v23
     9f0:      	fsub.4s	v25, v25, v26
     9f4:      	tbz	w0, #0x4, 0xb4c <_llm_rows.packet_batch.blocks+0x668>
     9f8:      	str	s25, [x17, #0x10]
     9fc:      	tbnz	w0, #0x5, 0xb50 <_llm_rows.packet_batch.blocks+0x66c>
     a00:      	tbz	w0, #0x6, 0xb5c <_llm_rows.packet_batch.blocks+0x678>
     a04:      	add	x1, x17, #0x18
     a08:      	st1.s	{ v25 }[2], [x1]
     a0c:      	tbnz	w0, #0x7, 0xb60 <_llm_rows.packet_batch.blocks+0x67c>
     a10:      	fmov	w17, s17
     a14:      	fmul.4s	v19, v19, v24
     a18:      	fmul.4s	v21, v21, v22
     a1c:      	fadd.4s	v19, v21, v19
     a20:      	add	x16, x8, x16
     a24:      	tbz	w17, #0x0, 0xb80 <_llm_rows.packet_batch.blocks+0x69c>
     a28:      	str	s19, [x16]
     a2c:      	and	w17, w17, #0xff
     a30:      	tbnz	w17, #0x1, 0xb88 <_llm_rows.packet_batch.blocks+0x6a4>
     a34:      	tbz	w17, #0x2, 0xb94 <_llm_rows.packet_batch.blocks+0x6b0>
     a38:      	add	x0, x16, #0x8
     a3c:      	st1.s	{ v19 }[2], [x0]
     a40:      	tbnz	w17, #0x3, 0xb98 <_llm_rows.packet_batch.blocks+0x6b4>
     a44:      	fmul.4s	v18, v18, v23
     a48:      	fmul.4s	v0, v20, v0
     a4c:      	fadd.4s	v0, v0, v18
     a50:      	tbz	w17, #0x4, 0xbb0 <_llm_rows.packet_batch.blocks+0x6cc>
     a54:      	str	s0, [x16, #0x10]
     a58:      	tbnz	w17, #0x5, 0xbb4 <_llm_rows.packet_batch.blocks+0x6d0>
     a5c:      	tbz	w17, #0x6, 0xbc0 <_llm_rows.packet_batch.blocks+0x6dc>
     a60:      	add	x0, x16, #0x18
     a64:      	st1.s	{ v0 }[2], [x0]
     a68:      	tbnz	w17, #0x7, 0xbc4 <_llm_rows.packet_batch.blocks+0x6e0>
     a6c:      	b	0xbcc <_llm_rows.packet_batch.blocks+0x6e8>
     a70:      	and	w1, w1, #0xff
     a74:      	tbz	w1, #0x1, 0x934 <_llm_rows.packet_batch.blocks+0x450>
     a78:      	add	x2, x0, #0x4
     a7c:      	ld1.s	{ v22 }[1], [x2]
     a80:      	tbnz	w1, #0x2, 0x938 <_llm_rows.packet_batch.blocks+0x454>
     a84:      	tbz	w1, #0x3, 0x944 <_llm_rows.packet_batch.blocks+0x460>
     a88:      	add	x2, x0, #0xc
     a8c:      	ld1.s	{ v22 }[3], [x2]
     a90:      	tbnz	w1, #0x4, 0x948 <_llm_rows.packet_batch.blocks+0x464>
     a94:      	tbz	w1, #0x5, 0x954 <_llm_rows.packet_batch.blocks+0x470>
     a98:      	add	x2, x0, #0x14
     a9c:      	ld1.s	{ v0 }[1], [x2]
     aa0:      	tbnz	w1, #0x6, 0x958 <_llm_rows.packet_batch.blocks+0x474>
     aa4:      	tbz	w1, #0x7, 0x964 <_llm_rows.packet_batch.blocks+0x480>
     aa8:      	add	x0, x0, #0x1c
     aac:      	ld1.s	{ v0 }[3], [x0]
     ab0:      	fmov	w0, s17
     ab4:      	add	x17, x9, x17
     ab8:      	movi.2d	v24, #0000000000000000
     abc:      	movi.2d	v23, #0000000000000000
     ac0:      	tbnz	w0, #0x0, 0x978 <_llm_rows.packet_batch.blocks+0x494>
     ac4:      	and	w0, w0, #0xff
     ac8:      	tbz	w0, #0x1, 0x984 <_llm_rows.packet_batch.blocks+0x4a0>
     acc:      	add	x1, x17, #0x4
     ad0:      	ld1.s	{ v24 }[1], [x1]
     ad4:      	tbnz	w0, #0x2, 0x988 <_llm_rows.packet_batch.blocks+0x4a4>
     ad8:      	tbz	w0, #0x3, 0x994 <_llm_rows.packet_batch.blocks+0x4b0>
     adc:      	add	x1, x17, #0xc
     ae0:      	ld1.s	{ v24 }[3], [x1]
     ae4:      	tbnz	w0, #0x4, 0x998 <_llm_rows.packet_batch.blocks+0x4b4>
     ae8:      	tbz	w0, #0x5, 0x9a4 <_llm_rows.packet_batch.blocks+0x4c0>
     aec:      	add	x1, x17, #0x14
     af0:      	ld1.s	{ v23 }[1], [x1]
     af4:      	tbnz	w0, #0x6, 0x9a8 <_llm_rows.packet_batch.blocks+0x4c4>
     af8:      	tbz	w0, #0x7, 0x9b4 <_llm_rows.packet_batch.blocks+0x4d0>
     afc:      	add	x17, x17, #0x1c
     b00:      	ld1.s	{ v23 }[3], [x17]
     b04:      	fmov	w0, s17
     b08:      	fmul.4s	v25, v19, v22
     b0c:      	fmul.4s	v26, v21, v24
     b10:      	fsub.4s	v25, v25, v26
     b14:      	add	x17, x8, x13
     b18:      	tbnz	w0, #0x0, 0x9cc <_llm_rows.packet_batch.blocks+0x4e8>
     b1c:      	and	w0, w0, #0xff
     b20:      	tbz	w0, #0x1, 0x9d8 <_llm_rows.packet_batch.blocks+0x4f4>
     b24:      	add	x1, x17, #0x4
     b28:      	st1.s	{ v25 }[1], [x1]
     b2c:      	tbnz	w0, #0x2, 0x9dc <_llm_rows.packet_batch.blocks+0x4f8>
     b30:      	tbz	w0, #0x3, 0x9e8 <_llm_rows.packet_batch.blocks+0x504>
     b34:      	add	x1, x17, #0xc
     b38:      	st1.s	{ v25 }[3], [x1]
     b3c:      	fmul.4s	v25, v18, v0
     b40:      	fmul.4s	v26, v20, v23
     b44:      	fsub.4s	v25, v25, v26
     b48:      	tbnz	w0, #0x4, 0x9f8 <_llm_rows.packet_batch.blocks+0x514>
     b4c:      	tbz	w0, #0x5, 0xa00 <_llm_rows.packet_batch.blocks+0x51c>
     b50:      	add	x1, x17, #0x14
     b54:      	st1.s	{ v25 }[1], [x1]
     b58:      	tbnz	w0, #0x6, 0xa04 <_llm_rows.packet_batch.blocks+0x520>
     b5c:      	tbz	w0, #0x7, 0xa10 <_llm_rows.packet_batch.blocks+0x52c>
     b60:      	add	x17, x17, #0x1c
     b64:      	st1.s	{ v25 }[3], [x17]
     b68:      	fmov	w17, s17
     b6c:      	fmul.4s	v19, v19, v24
     b70:      	fmul.4s	v21, v21, v22
     b74:      	fadd.4s	v19, v21, v19
     b78:      	add	x16, x8, x16
     b7c:      	tbnz	w17, #0x0, 0xa28 <_llm_rows.packet_batch.blocks+0x544>
     b80:      	and	w17, w17, #0xff
     b84:      	tbz	w17, #0x1, 0xa34 <_llm_rows.packet_batch.blocks+0x550>
     b88:      	add	x0, x16, #0x4
     b8c:      	st1.s	{ v19 }[1], [x0]
     b90:      	tbnz	w17, #0x2, 0xa38 <_llm_rows.packet_batch.blocks+0x554>
     b94:      	tbz	w17, #0x3, 0xa44 <_llm_rows.packet_batch.blocks+0x560>
     b98:      	add	x0, x16, #0xc
     b9c:      	st1.s	{ v19 }[3], [x0]
     ba0:      	fmul.4s	v18, v18, v23
     ba4:      	fmul.4s	v0, v20, v0
     ba8:      	fadd.4s	v0, v0, v18
     bac:      	tbnz	w17, #0x4, 0xa54 <_llm_rows.packet_batch.blocks+0x570>
     bb0:      	tbz	w17, #0x5, 0xa5c <_llm_rows.packet_batch.blocks+0x578>
     bb4:      	add	x0, x16, #0x14
     bb8:      	st1.s	{ v0 }[1], [x0]
     bbc:      	tbnz	w17, #0x6, 0xa60 <_llm_rows.packet_batch.blocks+0x57c>
     bc0:      	tbz	w17, #0x7, 0xbcc <_llm_rows.packet_batch.blocks+0x6e8>
     bc4:      	add	x16, x16, #0x1c
     bc8:      	st1.s	{ v0 }[3], [x16]
     bcc:      	fmov	w0, s17
     bd0:      	add	x16, x14, #0x20
     bd4:      	tst	w12, #0x1
     bd8:      	csel	x16, x16, x4, ne
     bdc:      	add	x17, x11, x16
     be0:      	movi.2d	v19, #0000000000000000
     be4:      	movi.2d	v18, #0000000000000000
     be8:      	tbz	w0, #0x0, 0xc80 <_llm_rows.packet_batch.blocks+0x79c>
     bec:      	ldr	s19, [x17]
     bf0:      	and	w0, w0, #0xff
     bf4:      	tbnz	w0, #0x1, 0xc88 <_llm_rows.packet_batch.blocks+0x7a4>
     bf8:      	tbz	w0, #0x2, 0xc94 <_llm_rows.packet_batch.blocks+0x7b0>
     bfc:      	add	x1, x17, #0x8
     c00:      	ld1.s	{ v19 }[2], [x1]
     c04:      	tbnz	w0, #0x3, 0xc98 <_llm_rows.packet_batch.blocks+0x7b4>
     c08:      	tbz	w0, #0x4, 0xca4 <_llm_rows.packet_batch.blocks+0x7c0>
     c0c:      	add	x1, x17, #0x10
     c10:      	ld1.s	{ v18 }[0], [x1]
     c14:      	tbnz	w0, #0x5, 0xca8 <_llm_rows.packet_batch.blocks+0x7c4>
     c18:      	tbz	w0, #0x6, 0xcb4 <_llm_rows.packet_batch.blocks+0x7d0>
     c1c:      	add	x1, x17, #0x18
     c20:      	ld1.s	{ v18 }[2], [x1]
     c24:      	tbnz	w0, #0x7, 0xcb8 <_llm_rows.packet_batch.blocks+0x7d4>
     c28:      	fmov	w1, s17
     c2c:      	add	x17, x13, #0xa4
     c30:      	add	x0, x11, x17
     c34:      	movi.2d	v21, #0000000000000000
     c38:      	movi.2d	v20, #0000000000000000
     c3c:      	tbz	w1, #0x0, 0xcd8 <_llm_rows.packet_batch.blocks+0x7f4>
     c40:      	ldr	s21, [x0]
     c44:      	and	w1, w1, #0xff
     c48:      	tbnz	w1, #0x1, 0xce0 <_llm_rows.packet_batch.blocks+0x7fc>
     c4c:      	tbz	w1, #0x2, 0xcec <_llm_rows.packet_batch.blocks+0x808>
     c50:      	add	x2, x0, #0x8
     c54:      	ld1.s	{ v21 }[2], [x2]
     c58:      	tbnz	w1, #0x3, 0xcf0 <_llm_rows.packet_batch.blocks+0x80c>
     c5c:      	tbz	w1, #0x4, 0xcfc <_llm_rows.packet_batch.blocks+0x818>
     c60:      	add	x2, x0, #0x10
     c64:      	ld1.s	{ v20 }[0], [x2]
     c68:      	tbnz	w1, #0x5, 0xd00 <_llm_rows.packet_batch.blocks+0x81c>
     c6c:      	tbz	w1, #0x6, 0xd0c <_llm_rows.packet_batch.blocks+0x828>
     c70:      	add	x2, x0, #0x18
     c74:      	ld1.s	{ v20 }[2], [x2]
     c78:      	tbnz	w1, #0x7, 0xd10 <_llm_rows.packet_batch.blocks+0x82c>
     c7c:      	b	0xd18 <_llm_rows.packet_batch.blocks+0x834>
     c80:      	and	w0, w0, #0xff
     c84:      	tbz	w0, #0x1, 0xbf8 <_llm_rows.packet_batch.blocks+0x714>
     c88:      	add	x1, x17, #0x4
     c8c:      	ld1.s	{ v19 }[1], [x1]
     c90:      	tbnz	w0, #0x2, 0xbfc <_llm_rows.packet_batch.blocks+0x718>
     c94:      	tbz	w0, #0x3, 0xc08 <_llm_rows.packet_batch.blocks+0x724>
     c98:      	add	x1, x17, #0xc
     c9c:      	ld1.s	{ v19 }[3], [x1]
     ca0:      	tbnz	w0, #0x4, 0xc0c <_llm_rows.packet_batch.blocks+0x728>
     ca4:      	tbz	w0, #0x5, 0xc18 <_llm_rows.packet_batch.blocks+0x734>
     ca8:      	add	x1, x17, #0x14
     cac:      	ld1.s	{ v18 }[1], [x1]
     cb0:      	tbnz	w0, #0x6, 0xc1c <_llm_rows.packet_batch.blocks+0x738>
     cb4:      	tbz	w0, #0x7, 0xc28 <_llm_rows.packet_batch.blocks+0x744>
     cb8:      	add	x17, x17, #0x1c
     cbc:      	ld1.s	{ v18 }[3], [x17]
     cc0:      	fmov	w1, s17
     cc4:      	add	x17, x13, #0xa4
     cc8:      	add	x0, x11, x17
     ccc:      	movi.2d	v21, #0000000000000000
     cd0:      	movi.2d	v20, #0000000000000000
     cd4:      	tbnz	w1, #0x0, 0xc40 <_llm_rows.packet_batch.blocks+0x75c>
     cd8:      	and	w1, w1, #0xff
     cdc:      	tbz	w1, #0x1, 0xc4c <_llm_rows.packet_batch.blocks+0x768>
     ce0:      	add	x2, x0, #0x4
     ce4:      	ld1.s	{ v21 }[1], [x2]
     ce8:      	tbnz	w1, #0x2, 0xc50 <_llm_rows.packet_batch.blocks+0x76c>
     cec:      	tbz	w1, #0x3, 0xc5c <_llm_rows.packet_batch.blocks+0x778>
     cf0:      	add	x2, x0, #0xc
     cf4:      	ld1.s	{ v21 }[3], [x2]
     cf8:      	tbnz	w1, #0x4, 0xc60 <_llm_rows.packet_batch.blocks+0x77c>
     cfc:      	tbz	w1, #0x5, 0xc6c <_llm_rows.packet_batch.blocks+0x788>
     d00:      	add	x2, x0, #0x14
     d04:      	ld1.s	{ v20 }[1], [x2]
     d08:      	tbnz	w1, #0x6, 0xc70 <_llm_rows.packet_batch.blocks+0x78c>
     d0c:      	tbz	w1, #0x7, 0xd18 <_llm_rows.packet_batch.blocks+0x834>
     d10:      	add	x0, x0, #0x1c
     d14:      	ld1.s	{ v20 }[3], [x0]
     d18:      	fmov	w2, s17
     d1c:      	add	x0, x15, #0x20
     d20:      	tst	w12, #0x1
     d24:      	csel	x0, x0, x4, ne
     d28:      	add	x1, x10, x0
     d2c:      	movi.2d	v22, #0000000000000000
     d30:      	movi.2d	v0, #0000000000000000
     d34:      	tbz	w2, #0x0, 0xe80 <_llm_rows.packet_batch.blocks+0x99c>
     d38:      	ldr	s22, [x1]
     d3c:      	and	w2, w2, #0xff
     d40:      	tbnz	w2, #0x1, 0xe88 <_llm_rows.packet_batch.blocks+0x9a4>
     d44:      	tbz	w2, #0x2, 0xe94 <_llm_rows.packet_batch.blocks+0x9b0>
     d48:      	add	x3, x1, #0x8
     d4c:      	ld1.s	{ v22 }[2], [x3]
     d50:      	tbnz	w2, #0x3, 0xe98 <_llm_rows.packet_batch.blocks+0x9b4>
     d54:      	tbz	w2, #0x4, 0xea4 <_llm_rows.packet_batch.blocks+0x9c0>
     d58:      	add	x3, x1, #0x10
     d5c:      	ld1.s	{ v0 }[0], [x3]
     d60:      	tbnz	w2, #0x5, 0xea8 <_llm_rows.packet_batch.blocks+0x9c4>
     d64:      	tbz	w2, #0x6, 0xeb4 <_llm_rows.packet_batch.blocks+0x9d0>
     d68:      	add	x3, x1, #0x18
     d6c:      	ld1.s	{ v0 }[2], [x3]
     d70:      	tbnz	w2, #0x7, 0xeb8 <_llm_rows.packet_batch.blocks+0x9d4>
     d74:      	fmov	w1, s17
     d78:      	add	x0, x9, x0
     d7c:      	movi.2d	v24, #0000000000000000
     d80:      	movi.2d	v23, #0000000000000000
     d84:      	tbz	w1, #0x0, 0xed4 <_llm_rows.packet_batch.blocks+0x9f0>
     d88:      	ldr	s24, [x0]
     d8c:      	and	w1, w1, #0xff
     d90:      	tbnz	w1, #0x1, 0xedc <_llm_rows.packet_batch.blocks+0x9f8>
     d94:      	tbz	w1, #0x2, 0xee8 <_llm_rows.packet_batch.blocks+0xa04>
     d98:      	add	x2, x0, #0x8
     d9c:      	ld1.s	{ v24 }[2], [x2]
     da0:      	tbnz	w1, #0x3, 0xeec <_llm_rows.packet_batch.blocks+0xa08>
     da4:      	tbz	w1, #0x4, 0xef8 <_llm_rows.packet_batch.blocks+0xa14>
     da8:      	add	x2, x0, #0x10
     dac:      	ld1.s	{ v23 }[0], [x2]
     db0:      	tbnz	w1, #0x5, 0xefc <_llm_rows.packet_batch.blocks+0xa18>
     db4:      	tbz	w1, #0x6, 0xf08 <_llm_rows.packet_batch.blocks+0xa24>
     db8:      	add	x2, x0, #0x18
     dbc:      	ld1.s	{ v23 }[2], [x2]
     dc0:      	tbnz	w1, #0x7, 0xf0c <_llm_rows.packet_batch.blocks+0xa28>
     dc4:      	fmov	w0, s17
     dc8:      	fmul.4s	v25, v19, v22
     dcc:      	fmul.4s	v26, v21, v24
     dd0:      	fsub.4s	v25, v25, v26
     dd4:      	add	x16, x8, x16
     dd8:      	tbz	w0, #0x0, 0xf2c <_llm_rows.packet_batch.blocks+0xa48>
     ddc:      	str	s25, [x16]
     de0:      	and	w0, w0, #0xff
     de4:      	tbnz	w0, #0x1, 0xf34 <_llm_rows.packet_batch.blocks+0xa50>
     de8:      	tbz	w0, #0x2, 0xf40 <_llm_rows.packet_batch.blocks+0xa5c>
     dec:      	add	x1, x16, #0x8
     df0:      	st1.s	{ v25 }[2], [x1]
     df4:      	tbnz	w0, #0x3, 0xf44 <_llm_rows.packet_batch.blocks+0xa60>
     df8:      	fmul.4s	v25, v18, v0
     dfc:      	fmul.4s	v26, v20, v23
     e00:      	fsub.4s	v25, v25, v26
     e04:      	tbz	w0, #0x4, 0xf5c <_llm_rows.packet_batch.blocks+0xa78>
     e08:      	str	s25, [x16, #0x10]
     e0c:      	tbnz	w0, #0x5, 0xf60 <_llm_rows.packet_batch.blocks+0xa7c>
     e10:      	tbz	w0, #0x6, 0xf6c <_llm_rows.packet_batch.blocks+0xa88>
     e14:      	add	x1, x16, #0x18
     e18:      	st1.s	{ v25 }[2], [x1]
     e1c:      	tbnz	w0, #0x7, 0xf70 <_llm_rows.packet_batch.blocks+0xa8c>
     e20:      	fmov	w0, s17
     e24:      	fmul.4s	v19, v19, v24
     e28:      	fmul.4s	v21, v21, v22
     e2c:      	fadd.4s	v19, v21, v19
     e30:      	add	x16, x8, x17
     e34:      	tbz	w0, #0x0, 0xf90 <_llm_rows.packet_batch.blocks+0xaac>
     e38:      	str	s19, [x16]
     e3c:      	and	w17, w0, #0xff
     e40:      	tbnz	w17, #0x1, 0xf98 <_llm_rows.packet_batch.blocks+0xab4>
     e44:      	tbz	w17, #0x2, 0xfa4 <_llm_rows.packet_batch.blocks+0xac0>
     e48:      	add	x0, x16, #0x8
     e4c:      	st1.s	{ v19 }[2], [x0]
     e50:      	tbnz	w17, #0x3, 0xfa8 <_llm_rows.packet_batch.blocks+0xac4>
     e54:      	fmul.4s	v18, v18, v23
     e58:      	fmul.4s	v0, v20, v0
     e5c:      	fadd.4s	v0, v0, v18
     e60:      	tbz	w17, #0x4, 0xfc0 <_llm_rows.packet_batch.blocks+0xadc>
     e64:      	str	s0, [x16, #0x10]
     e68:      	tbnz	w17, #0x5, 0xfc4 <_llm_rows.packet_batch.blocks+0xae0>
     e6c:      	tbz	w17, #0x6, 0xfd0 <_llm_rows.packet_batch.blocks+0xaec>
     e70:      	add	x0, x16, #0x18
     e74:      	st1.s	{ v0 }[2], [x0]
     e78:      	tbnz	w17, #0x7, 0xfd4 <_llm_rows.packet_batch.blocks+0xaf0>
     e7c:      	b	0xfdc <_llm_rows.packet_batch.blocks+0xaf8>
     e80:      	and	w2, w2, #0xff
     e84:      	tbz	w2, #0x1, 0xd44 <_llm_rows.packet_batch.blocks+0x860>
     e88:      	add	x3, x1, #0x4
     e8c:      	ld1.s	{ v22 }[1], [x3]
     e90:      	tbnz	w2, #0x2, 0xd48 <_llm_rows.packet_batch.blocks+0x864>
     e94:      	tbz	w2, #0x3, 0xd54 <_llm_rows.packet_batch.blocks+0x870>
     e98:      	add	x3, x1, #0xc
     e9c:      	ld1.s	{ v22 }[3], [x3]
     ea0:      	tbnz	w2, #0x4, 0xd58 <_llm_rows.packet_batch.blocks+0x874>
     ea4:      	tbz	w2, #0x5, 0xd64 <_llm_rows.packet_batch.blocks+0x880>
     ea8:      	add	x3, x1, #0x14
     eac:      	ld1.s	{ v0 }[1], [x3]
     eb0:      	tbnz	w2, #0x6, 0xd68 <_llm_rows.packet_batch.blocks+0x884>
     eb4:      	tbz	w2, #0x7, 0xd74 <_llm_rows.packet_batch.blocks+0x890>
     eb8:      	add	x1, x1, #0x1c
     ebc:      	ld1.s	{ v0 }[3], [x1]
     ec0:      	fmov	w1, s17
     ec4:      	add	x0, x9, x0
     ec8:      	movi.2d	v24, #0000000000000000
     ecc:      	movi.2d	v23, #0000000000000000
     ed0:      	tbnz	w1, #0x0, 0xd88 <_llm_rows.packet_batch.blocks+0x8a4>
     ed4:      	and	w1, w1, #0xff
     ed8:      	tbz	w1, #0x1, 0xd94 <_llm_rows.packet_batch.blocks+0x8b0>
     edc:      	add	x2, x0, #0x4
     ee0:      	ld1.s	{ v24 }[1], [x2]
     ee4:      	tbnz	w1, #0x2, 0xd98 <_llm_rows.packet_batch.blocks+0x8b4>
     ee8:      	tbz	w1, #0x3, 0xda4 <_llm_rows.packet_batch.blocks+0x8c0>
     eec:      	add	x2, x0, #0xc
     ef0:      	ld1.s	{ v24 }[3], [x2]
     ef4:      	tbnz	w1, #0x4, 0xda8 <_llm_rows.packet_batch.blocks+0x8c4>
     ef8:      	tbz	w1, #0x5, 0xdb4 <_llm_rows.packet_batch.blocks+0x8d0>
     efc:      	add	x2, x0, #0x14
     f00:      	ld1.s	{ v23 }[1], [x2]
     f04:      	tbnz	w1, #0x6, 0xdb8 <_llm_rows.packet_batch.blocks+0x8d4>
     f08:      	tbz	w1, #0x7, 0xdc4 <_llm_rows.packet_batch.blocks+0x8e0>
     f0c:      	add	x0, x0, #0x1c
     f10:      	ld1.s	{ v23 }[3], [x0]
     f14:      	fmov	w0, s17
     f18:      	fmul.4s	v25, v19, v22
     f1c:      	fmul.4s	v26, v21, v24
     f20:      	fsub.4s	v25, v25, v26
     f24:      	add	x16, x8, x16
     f28:      	tbnz	w0, #0x0, 0xddc <_llm_rows.packet_batch.blocks+0x8f8>
     f2c:      	and	w0, w0, #0xff
     f30:      	tbz	w0, #0x1, 0xde8 <_llm_rows.packet_batch.blocks+0x904>
     f34:      	add	x1, x16, #0x4
     f38:      	st1.s	{ v25 }[1], [x1]
     f3c:      	tbnz	w0, #0x2, 0xdec <_llm_rows.packet_batch.blocks+0x908>
     f40:      	tbz	w0, #0x3, 0xdf8 <_llm_rows.packet_batch.blocks+0x914>
     f44:      	add	x1, x16, #0xc
     f48:      	st1.s	{ v25 }[3], [x1]
     f4c:      	fmul.4s	v25, v18, v0
     f50:      	fmul.4s	v26, v20, v23
     f54:      	fsub.4s	v25, v25, v26
     f58:      	tbnz	w0, #0x4, 0xe08 <_llm_rows.packet_batch.blocks+0x924>
     f5c:      	tbz	w0, #0x5, 0xe10 <_llm_rows.packet_batch.blocks+0x92c>
     f60:      	add	x1, x16, #0x14
     f64:      	st1.s	{ v25 }[1], [x1]
     f68:      	tbnz	w0, #0x6, 0xe14 <_llm_rows.packet_batch.blocks+0x930>
     f6c:      	tbz	w0, #0x7, 0xe20 <_llm_rows.packet_batch.blocks+0x93c>
     f70:      	add	x16, x16, #0x1c
     f74:      	st1.s	{ v25 }[3], [x16]
     f78:      	fmov	w0, s17
     f7c:      	fmul.4s	v19, v19, v24
     f80:      	fmul.4s	v21, v21, v22
     f84:      	fadd.4s	v19, v21, v19
     f88:      	add	x16, x8, x17
     f8c:      	tbnz	w0, #0x0, 0xe38 <_llm_rows.packet_batch.blocks+0x954>
     f90:      	and	w17, w0, #0xff
     f94:      	tbz	w17, #0x1, 0xe44 <_llm_rows.packet_batch.blocks+0x960>
     f98:      	add	x0, x16, #0x4
     f9c:      	st1.s	{ v19 }[1], [x0]
     fa0:      	tbnz	w17, #0x2, 0xe48 <_llm_rows.packet_batch.blocks+0x964>
     fa4:      	tbz	w17, #0x3, 0xe54 <_llm_rows.packet_batch.blocks+0x970>
     fa8:      	add	x0, x16, #0xc
     fac:      	st1.s	{ v19 }[3], [x0]
     fb0:      	fmul.4s	v18, v18, v23
     fb4:      	fmul.4s	v0, v20, v0
     fb8:      	fadd.4s	v0, v0, v18
     fbc:      	tbnz	w17, #0x4, 0xe64 <_llm_rows.packet_batch.blocks+0x980>
     fc0:      	tbz	w17, #0x5, 0xe6c <_llm_rows.packet_batch.blocks+0x988>
     fc4:      	add	x0, x16, #0x14
     fc8:      	st1.s	{ v0 }[1], [x0]
     fcc:      	tbnz	w17, #0x6, 0xe70 <_llm_rows.packet_batch.blocks+0x98c>
     fd0:      	tbz	w17, #0x7, 0xfdc <_llm_rows.packet_batch.blocks+0xaf8>
     fd4:      	add	x16, x16, #0x1c
     fd8:      	st1.s	{ v0 }[3], [x16]
     fdc:      	fmov	w0, s17
     fe0:      	add	x16, x14, #0x40
     fe4:      	tst	w12, #0x1
     fe8:      	mov	w17, #0x40              ; =64
     fec:      	csel	x16, x16, x17, ne
     ff0:      	add	x17, x11, x16
     ff4:      	movi.2d	v19, #0000000000000000
     ff8:      	movi.2d	v18, #0000000000000000
     ffc:      	tbz	w0, #0x0, 0x1094 <_llm_rows.packet_batch.blocks+0xbb0>
    1000:      	ldr	s19, [x17]
    1004:      	and	w0, w0, #0xff
    1008:      	tbnz	w0, #0x1, 0x109c <_llm_rows.packet_batch.blocks+0xbb8>
    100c:      	tbz	w0, #0x2, 0x10a8 <_llm_rows.packet_batch.blocks+0xbc4>
    1010:      	add	x1, x17, #0x8
    1014:      	ld1.s	{ v19 }[2], [x1]
    1018:      	tbnz	w0, #0x3, 0x10ac <_llm_rows.packet_batch.blocks+0xbc8>
    101c:      	tbz	w0, #0x4, 0x10b8 <_llm_rows.packet_batch.blocks+0xbd4>
    1020:      	add	x1, x17, #0x10
    1024:      	ld1.s	{ v18 }[0], [x1]
    1028:      	tbnz	w0, #0x5, 0x10bc <_llm_rows.packet_batch.blocks+0xbd8>
    102c:      	tbz	w0, #0x6, 0x10c8 <_llm_rows.packet_batch.blocks+0xbe4>
    1030:      	add	x1, x17, #0x18
    1034:      	ld1.s	{ v18 }[2], [x1]
    1038:      	tbnz	w0, #0x7, 0x10cc <_llm_rows.packet_batch.blocks+0xbe8>
    103c:      	fmov	w1, s17
    1040:      	add	x17, x13, #0xc4
    1044:      	add	x0, x11, x17
    1048:      	movi.2d	v21, #0000000000000000
    104c:      	movi.2d	v20, #0000000000000000
    1050:      	tbz	w1, #0x0, 0x10ec <_llm_rows.packet_batch.blocks+0xc08>
    1054:      	ldr	s21, [x0]
    1058:      	and	w1, w1, #0xff
    105c:      	tbnz	w1, #0x1, 0x10f4 <_llm_rows.packet_batch.blocks+0xc10>
    1060:      	tbz	w1, #0x2, 0x1100 <_llm_rows.packet_batch.blocks+0xc1c>
    1064:      	add	x2, x0, #0x8
    1068:      	ld1.s	{ v21 }[2], [x2]
    106c:      	tbnz	w1, #0x3, 0x1104 <_llm_rows.packet_batch.blocks+0xc20>
    1070:      	tbz	w1, #0x4, 0x1110 <_llm_rows.packet_batch.blocks+0xc2c>
    1074:      	add	x2, x0, #0x10
    1078:      	ld1.s	{ v20 }[0], [x2]
    107c:      	tbnz	w1, #0x5, 0x1114 <_llm_rows.packet_batch.blocks+0xc30>
    1080:      	tbz	w1, #0x6, 0x1120 <_llm_rows.packet_batch.blocks+0xc3c>
    1084:      	add	x2, x0, #0x18
    1088:      	ld1.s	{ v20 }[2], [x2]
    108c:      	tbnz	w1, #0x7, 0x1124 <_llm_rows.packet_batch.blocks+0xc40>
    1090:      	b	0x112c <_llm_rows.packet_batch.blocks+0xc48>
    1094:      	and	w0, w0, #0xff
    1098:      	tbz	w0, #0x1, 0x100c <_llm_rows.packet_batch.blocks+0xb28>
    109c:      	add	x1, x17, #0x4
    10a0:      	ld1.s	{ v19 }[1], [x1]
    10a4:      	tbnz	w0, #0x2, 0x1010 <_llm_rows.packet_batch.blocks+0xb2c>
    10a8:      	tbz	w0, #0x3, 0x101c <_llm_rows.packet_batch.blocks+0xb38>
    10ac:      	add	x1, x17, #0xc
    10b0:      	ld1.s	{ v19 }[3], [x1]
    10b4:      	tbnz	w0, #0x4, 0x1020 <_llm_rows.packet_batch.blocks+0xb3c>
    10b8:      	tbz	w0, #0x5, 0x102c <_llm_rows.packet_batch.blocks+0xb48>
    10bc:      	add	x1, x17, #0x14
    10c0:      	ld1.s	{ v18 }[1], [x1]
    10c4:      	tbnz	w0, #0x6, 0x1030 <_llm_rows.packet_batch.blocks+0xb4c>
    10c8:      	tbz	w0, #0x7, 0x103c <_llm_rows.packet_batch.blocks+0xb58>
    10cc:      	add	x17, x17, #0x1c
    10d0:      	ld1.s	{ v18 }[3], [x17]
    10d4:      	fmov	w1, s17
    10d8:      	add	x17, x13, #0xc4
    10dc:      	add	x0, x11, x17
    10e0:      	movi.2d	v21, #0000000000000000
    10e4:      	movi.2d	v20, #0000000000000000
    10e8:      	tbnz	w1, #0x0, 0x1054 <_llm_rows.packet_batch.blocks+0xb70>
    10ec:      	and	w1, w1, #0xff
    10f0:      	tbz	w1, #0x1, 0x1060 <_llm_rows.packet_batch.blocks+0xb7c>
    10f4:      	add	x2, x0, #0x4
    10f8:      	ld1.s	{ v21 }[1], [x2]
    10fc:      	tbnz	w1, #0x2, 0x1064 <_llm_rows.packet_batch.blocks+0xb80>
    1100:      	tbz	w1, #0x3, 0x1070 <_llm_rows.packet_batch.blocks+0xb8c>
    1104:      	add	x2, x0, #0xc
    1108:      	ld1.s	{ v21 }[3], [x2]
    110c:      	tbnz	w1, #0x4, 0x1074 <_llm_rows.packet_batch.blocks+0xb90>
    1110:      	tbz	w1, #0x5, 0x1080 <_llm_rows.packet_batch.blocks+0xb9c>
    1114:      	add	x2, x0, #0x14
    1118:      	ld1.s	{ v20 }[1], [x2]
    111c:      	tbnz	w1, #0x6, 0x1084 <_llm_rows.packet_batch.blocks+0xba0>
    1120:      	tbz	w1, #0x7, 0x112c <_llm_rows.packet_batch.blocks+0xc48>
    1124:      	add	x0, x0, #0x1c
    1128:      	ld1.s	{ v20 }[3], [x0]
    112c:      	fmov	w2, s17
    1130:      	add	x0, x15, #0x40
    1134:      	tst	w12, #0x1
    1138:      	mov	w1, #0x40               ; =64
    113c:      	csel	x0, x0, x1, ne
    1140:      	add	x1, x10, x0
    1144:      	movi.2d	v22, #0000000000000000
    1148:      	movi.2d	v0, #0000000000000000
    114c:      	tbz	w2, #0x0, 0x1298 <_llm_rows.packet_batch.blocks+0xdb4>
    1150:      	ldr	s22, [x1]
    1154:      	and	w2, w2, #0xff
    1158:      	tbnz	w2, #0x1, 0x12a0 <_llm_rows.packet_batch.blocks+0xdbc>
    115c:      	tbz	w2, #0x2, 0x12ac <_llm_rows.packet_batch.blocks+0xdc8>
    1160:      	add	x3, x1, #0x8
    1164:      	ld1.s	{ v22 }[2], [x3]
    1168:      	tbnz	w2, #0x3, 0x12b0 <_llm_rows.packet_batch.blocks+0xdcc>
    116c:      	tbz	w2, #0x4, 0x12bc <_llm_rows.packet_batch.blocks+0xdd8>
    1170:      	add	x3, x1, #0x10
    1174:      	ld1.s	{ v0 }[0], [x3]
    1178:      	tbnz	w2, #0x5, 0x12c0 <_llm_rows.packet_batch.blocks+0xddc>
    117c:      	tbz	w2, #0x6, 0x12cc <_llm_rows.packet_batch.blocks+0xde8>
    1180:      	add	x3, x1, #0x18
    1184:      	ld1.s	{ v0 }[2], [x3]
    1188:      	tbnz	w2, #0x7, 0x12d0 <_llm_rows.packet_batch.blocks+0xdec>
    118c:      	fmov	w1, s17
    1190:      	add	x0, x9, x0
    1194:      	movi.2d	v24, #0000000000000000
    1198:      	movi.2d	v23, #0000000000000000
    119c:      	tbz	w1, #0x0, 0x12ec <_llm_rows.packet_batch.blocks+0xe08>
    11a0:      	ldr	s24, [x0]
    11a4:      	and	w1, w1, #0xff
    11a8:      	tbnz	w1, #0x1, 0x12f4 <_llm_rows.packet_batch.blocks+0xe10>
    11ac:      	tbz	w1, #0x2, 0x1300 <_llm_rows.packet_batch.blocks+0xe1c>
    11b0:      	add	x2, x0, #0x8
    11b4:      	ld1.s	{ v24 }[2], [x2]
    11b8:      	tbnz	w1, #0x3, 0x1304 <_llm_rows.packet_batch.blocks+0xe20>
    11bc:      	tbz	w1, #0x4, 0x1310 <_llm_rows.packet_batch.blocks+0xe2c>
    11c0:      	add	x2, x0, #0x10
    11c4:      	ld1.s	{ v23 }[0], [x2]
    11c8:      	tbnz	w1, #0x5, 0x1314 <_llm_rows.packet_batch.blocks+0xe30>
    11cc:      	tbz	w1, #0x6, 0x1320 <_llm_rows.packet_batch.blocks+0xe3c>
    11d0:      	add	x2, x0, #0x18
    11d4:      	ld1.s	{ v23 }[2], [x2]
    11d8:      	tbnz	w1, #0x7, 0x1324 <_llm_rows.packet_batch.blocks+0xe40>
    11dc:      	fmov	w0, s17
    11e0:      	fmul.4s	v25, v19, v22
    11e4:      	fmul.4s	v26, v21, v24
    11e8:      	fsub.4s	v25, v25, v26
    11ec:      	add	x16, x8, x16
    11f0:      	tbz	w0, #0x0, 0x1344 <_llm_rows.packet_batch.blocks+0xe60>
    11f4:      	str	s25, [x16]
    11f8:      	and	w0, w0, #0xff
    11fc:      	tbnz	w0, #0x1, 0x134c <_llm_rows.packet_batch.blocks+0xe68>
    1200:      	tbz	w0, #0x2, 0x1358 <_llm_rows.packet_batch.blocks+0xe74>
    1204:      	add	x1, x16, #0x8
    1208:      	st1.s	{ v25 }[2], [x1]
    120c:      	tbnz	w0, #0x3, 0x135c <_llm_rows.packet_batch.blocks+0xe78>
    1210:      	fmul.4s	v25, v18, v0
    1214:      	fmul.4s	v26, v20, v23
    1218:      	fsub.4s	v25, v25, v26
    121c:      	tbz	w0, #0x4, 0x1374 <_llm_rows.packet_batch.blocks+0xe90>
    1220:      	str	s25, [x16, #0x10]
    1224:      	tbnz	w0, #0x5, 0x1378 <_llm_rows.packet_batch.blocks+0xe94>
    1228:      	tbz	w0, #0x6, 0x1384 <_llm_rows.packet_batch.blocks+0xea0>
    122c:      	add	x1, x16, #0x18
    1230:      	st1.s	{ v25 }[2], [x1]
    1234:      	tbnz	w0, #0x7, 0x1388 <_llm_rows.packet_batch.blocks+0xea4>
    1238:      	fmov	w0, s17
    123c:      	fmul.4s	v19, v19, v24
    1240:      	fmul.4s	v21, v21, v22
    1244:      	fadd.4s	v19, v21, v19
    1248:      	add	x16, x8, x17
    124c:      	tbz	w0, #0x0, 0x13a8 <_llm_rows.packet_batch.blocks+0xec4>
    1250:      	str	s19, [x16]
    1254:      	and	w17, w0, #0xff
    1258:      	tbnz	w17, #0x1, 0x13b0 <_llm_rows.packet_batch.blocks+0xecc>
    125c:      	tbz	w17, #0x2, 0x13bc <_llm_rows.packet_batch.blocks+0xed8>
    1260:      	add	x0, x16, #0x8
    1264:      	st1.s	{ v19 }[2], [x0]
    1268:      	tbnz	w17, #0x3, 0x13c0 <_llm_rows.packet_batch.blocks+0xedc>
    126c:      	fmul.4s	v18, v18, v23
    1270:      	fmul.4s	v0, v20, v0
    1274:      	fadd.4s	v0, v0, v18
    1278:      	tbz	w17, #0x4, 0x13d8 <_llm_rows.packet_batch.blocks+0xef4>
    127c:      	str	s0, [x16, #0x10]
    1280:      	tbnz	w17, #0x5, 0x13dc <_llm_rows.packet_batch.blocks+0xef8>
    1284:      	tbz	w17, #0x6, 0x13e8 <_llm_rows.packet_batch.blocks+0xf04>
    1288:      	add	x0, x16, #0x18
    128c:      	st1.s	{ v0 }[2], [x0]
    1290:      	tbnz	w17, #0x7, 0x13ec <_llm_rows.packet_batch.blocks+0xf08>
    1294:      	b	0x13f4 <_llm_rows.packet_batch.blocks+0xf10>
    1298:      	and	w2, w2, #0xff
    129c:      	tbz	w2, #0x1, 0x115c <_llm_rows.packet_batch.blocks+0xc78>
    12a0:      	add	x3, x1, #0x4
    12a4:      	ld1.s	{ v22 }[1], [x3]
    12a8:      	tbnz	w2, #0x2, 0x1160 <_llm_rows.packet_batch.blocks+0xc7c>
    12ac:      	tbz	w2, #0x3, 0x116c <_llm_rows.packet_batch.blocks+0xc88>
    12b0:      	add	x3, x1, #0xc
    12b4:      	ld1.s	{ v22 }[3], [x3]
    12b8:      	tbnz	w2, #0x4, 0x1170 <_llm_rows.packet_batch.blocks+0xc8c>
    12bc:      	tbz	w2, #0x5, 0x117c <_llm_rows.packet_batch.blocks+0xc98>
    12c0:      	add	x3, x1, #0x14
    12c4:      	ld1.s	{ v0 }[1], [x3]
    12c8:      	tbnz	w2, #0x6, 0x1180 <_llm_rows.packet_batch.blocks+0xc9c>
    12cc:      	tbz	w2, #0x7, 0x118c <_llm_rows.packet_batch.blocks+0xca8>
    12d0:      	add	x1, x1, #0x1c
    12d4:      	ld1.s	{ v0 }[3], [x1]
    12d8:      	fmov	w1, s17
    12dc:      	add	x0, x9, x0
    12e0:      	movi.2d	v24, #0000000000000000
    12e4:      	movi.2d	v23, #0000000000000000
    12e8:      	tbnz	w1, #0x0, 0x11a0 <_llm_rows.packet_batch.blocks+0xcbc>
    12ec:      	and	w1, w1, #0xff
    12f0:      	tbz	w1, #0x1, 0x11ac <_llm_rows.packet_batch.blocks+0xcc8>
    12f4:      	add	x2, x0, #0x4
    12f8:      	ld1.s	{ v24 }[1], [x2]
    12fc:      	tbnz	w1, #0x2, 0x11b0 <_llm_rows.packet_batch.blocks+0xccc>
    1300:      	tbz	w1, #0x3, 0x11bc <_llm_rows.packet_batch.blocks+0xcd8>
    1304:      	add	x2, x0, #0xc
    1308:      	ld1.s	{ v24 }[3], [x2]
    130c:      	tbnz	w1, #0x4, 0x11c0 <_llm_rows.packet_batch.blocks+0xcdc>
    1310:      	tbz	w1, #0x5, 0x11cc <_llm_rows.packet_batch.blocks+0xce8>
    1314:      	add	x2, x0, #0x14
    1318:      	ld1.s	{ v23 }[1], [x2]
    131c:      	tbnz	w1, #0x6, 0x11d0 <_llm_rows.packet_batch.blocks+0xcec>
    1320:      	tbz	w1, #0x7, 0x11dc <_llm_rows.packet_batch.blocks+0xcf8>
    1324:      	add	x0, x0, #0x1c
    1328:      	ld1.s	{ v23 }[3], [x0]
    132c:      	fmov	w0, s17
    1330:      	fmul.4s	v25, v19, v22
    1334:      	fmul.4s	v26, v21, v24
    1338:      	fsub.4s	v25, v25, v26
    133c:      	add	x16, x8, x16
    1340:      	tbnz	w0, #0x0, 0x11f4 <_llm_rows.packet_batch.blocks+0xd10>
    1344:      	and	w0, w0, #0xff
    1348:      	tbz	w0, #0x1, 0x1200 <_llm_rows.packet_batch.blocks+0xd1c>
    134c:      	add	x1, x16, #0x4
    1350:      	st1.s	{ v25 }[1], [x1]
    1354:      	tbnz	w0, #0x2, 0x1204 <_llm_rows.packet_batch.blocks+0xd20>
    1358:      	tbz	w0, #0x3, 0x1210 <_llm_rows.packet_batch.blocks+0xd2c>
    135c:      	add	x1, x16, #0xc
    1360:      	st1.s	{ v25 }[3], [x1]
    1364:      	fmul.4s	v25, v18, v0
    1368:      	fmul.4s	v26, v20, v23
    136c:      	fsub.4s	v25, v25, v26
    1370:      	tbnz	w0, #0x4, 0x1220 <_llm_rows.packet_batch.blocks+0xd3c>
    1374:      	tbz	w0, #0x5, 0x1228 <_llm_rows.packet_batch.blocks+0xd44>
    1378:      	add	x1, x16, #0x14
    137c:      	st1.s	{ v25 }[1], [x1]
    1380:      	tbnz	w0, #0x6, 0x122c <_llm_rows.packet_batch.blocks+0xd48>
    1384:      	tbz	w0, #0x7, 0x1238 <_llm_rows.packet_batch.blocks+0xd54>
    1388:      	add	x16, x16, #0x1c
    138c:      	st1.s	{ v25 }[3], [x16]
    1390:      	fmov	w0, s17
    1394:      	fmul.4s	v19, v19, v24
    1398:      	fmul.4s	v21, v21, v22
    139c:      	fadd.4s	v19, v21, v19
    13a0:      	add	x16, x8, x17
    13a4:      	tbnz	w0, #0x0, 0x1250 <_llm_rows.packet_batch.blocks+0xd6c>
    13a8:      	and	w17, w0, #0xff
    13ac:      	tbz	w17, #0x1, 0x125c <_llm_rows.packet_batch.blocks+0xd78>
    13b0:      	add	x0, x16, #0x4
    13b4:      	st1.s	{ v19 }[1], [x0]
    13b8:      	tbnz	w17, #0x2, 0x1260 <_llm_rows.packet_batch.blocks+0xd7c>
    13bc:      	tbz	w17, #0x3, 0x126c <_llm_rows.packet_batch.blocks+0xd88>
    13c0:      	add	x0, x16, #0xc
    13c4:      	st1.s	{ v19 }[3], [x0]
    13c8:      	fmul.4s	v18, v18, v23
    13cc:      	fmul.4s	v0, v20, v0
    13d0:      	fadd.4s	v0, v0, v18
    13d4:      	tbnz	w17, #0x4, 0x127c <_llm_rows.packet_batch.blocks+0xd98>
    13d8:      	tbz	w17, #0x5, 0x1284 <_llm_rows.packet_batch.blocks+0xda0>
    13dc:      	add	x0, x16, #0x14
    13e0:      	st1.s	{ v0 }[1], [x0]
    13e4:      	tbnz	w17, #0x6, 0x1288 <_llm_rows.packet_batch.blocks+0xda4>
    13e8:      	tbz	w17, #0x7, 0x13f4 <_llm_rows.packet_batch.blocks+0xf10>
    13ec:      	add	x16, x16, #0x1c
    13f0:      	st1.s	{ v0 }[3], [x16]
    13f4:      	fmov	w17, s17
    13f8:      	add	x14, x14, #0x60
    13fc:      	tst	w12, #0x1
    1400:      	mov	w16, #0x60              ; =96
    1404:      	csel	x14, x14, x16, ne
    1408:      	add	x16, x11, x14
    140c:      	movi.2d	v19, #0000000000000000
    1410:      	movi.2d	v18, #0000000000000000
    1414:      	tbz	w17, #0x0, 0x14ac <_llm_rows.packet_batch.blocks+0xfc8>
    1418:      	ldr	s19, [x16]
    141c:      	and	w17, w17, #0xff
    1420:      	tbnz	w17, #0x1, 0x14b4 <_llm_rows.packet_batch.blocks+0xfd0>
    1424:      	tbz	w17, #0x2, 0x14c0 <_llm_rows.packet_batch.blocks+0xfdc>
    1428:      	add	x0, x16, #0x8
    142c:      	ld1.s	{ v19 }[2], [x0]
    1430:      	tbnz	w17, #0x3, 0x14c4 <_llm_rows.packet_batch.blocks+0xfe0>
    1434:      	tbz	w17, #0x4, 0x14d0 <_llm_rows.packet_batch.blocks+0xfec>
    1438:      	add	x0, x16, #0x10
    143c:      	ld1.s	{ v18 }[0], [x0]
    1440:      	tbnz	w17, #0x5, 0x14d4 <_llm_rows.packet_batch.blocks+0xff0>
    1444:      	tbz	w17, #0x6, 0x14e0 <_llm_rows.packet_batch.blocks+0xffc>
    1448:      	add	x0, x16, #0x18
    144c:      	ld1.s	{ v18 }[2], [x0]
    1450:      	tbnz	w17, #0x7, 0x14e4 <_llm_rows.packet_batch.blocks+0x1000>
    1454:      	fmov	w17, s17
    1458:      	add	x13, x13, #0xe4
    145c:      	add	x16, x11, x13
    1460:      	movi.2d	v21, #0000000000000000
    1464:      	movi.2d	v20, #0000000000000000
    1468:      	tbz	w17, #0x0, 0x1504 <_llm_rows.packet_batch.blocks+0x1020>
    146c:      	ldr	s21, [x16]
    1470:      	and	w17, w17, #0xff
    1474:      	tbnz	w17, #0x1, 0x150c <_llm_rows.packet_batch.blocks+0x1028>
    1478:      	tbz	w17, #0x2, 0x1518 <_llm_rows.packet_batch.blocks+0x1034>
    147c:      	add	x0, x16, #0x8
    1480:      	ld1.s	{ v21 }[2], [x0]
    1484:      	tbnz	w17, #0x3, 0x151c <_llm_rows.packet_batch.blocks+0x1038>
    1488:      	tbz	w17, #0x4, 0x1528 <_llm_rows.packet_batch.blocks+0x1044>
    148c:      	add	x0, x16, #0x10
    1490:      	ld1.s	{ v20 }[0], [x0]
    1494:      	tbnz	w17, #0x5, 0x152c <_llm_rows.packet_batch.blocks+0x1048>
    1498:      	tbz	w17, #0x6, 0x1538 <_llm_rows.packet_batch.blocks+0x1054>
    149c:      	add	x0, x16, #0x18
    14a0:      	ld1.s	{ v20 }[2], [x0]
    14a4:      	tbnz	w17, #0x7, 0x153c <_llm_rows.packet_batch.blocks+0x1058>
    14a8:      	b	0x1544 <_llm_rows.packet_batch.blocks+0x1060>
    14ac:      	and	w17, w17, #0xff
    14b0:      	tbz	w17, #0x1, 0x1424 <_llm_rows.packet_batch.blocks+0xf40>
    14b4:      	add	x0, x16, #0x4
    14b8:      	ld1.s	{ v19 }[1], [x0]
    14bc:      	tbnz	w17, #0x2, 0x1428 <_llm_rows.packet_batch.blocks+0xf44>
    14c0:      	tbz	w17, #0x3, 0x1434 <_llm_rows.packet_batch.blocks+0xf50>
    14c4:      	add	x0, x16, #0xc
    14c8:      	ld1.s	{ v19 }[3], [x0]
    14cc:      	tbnz	w17, #0x4, 0x1438 <_llm_rows.packet_batch.blocks+0xf54>
    14d0:      	tbz	w17, #0x5, 0x1444 <_llm_rows.packet_batch.blocks+0xf60>
    14d4:      	add	x0, x16, #0x14
    14d8:      	ld1.s	{ v18 }[1], [x0]
    14dc:      	tbnz	w17, #0x6, 0x1448 <_llm_rows.packet_batch.blocks+0xf64>
    14e0:      	tbz	w17, #0x7, 0x1454 <_llm_rows.packet_batch.blocks+0xf70>
    14e4:      	add	x16, x16, #0x1c
    14e8:      	ld1.s	{ v18 }[3], [x16]
    14ec:      	fmov	w17, s17
    14f0:      	add	x13, x13, #0xe4
    14f4:      	add	x16, x11, x13
    14f8:      	movi.2d	v21, #0000000000000000
    14fc:      	movi.2d	v20, #0000000000000000
    1500:      	tbnz	w17, #0x0, 0x146c <_llm_rows.packet_batch.blocks+0xf88>
    1504:      	and	w17, w17, #0xff
    1508:      	tbz	w17, #0x1, 0x1478 <_llm_rows.packet_batch.blocks+0xf94>
    150c:      	add	x0, x16, #0x4
    1510:      	ld1.s	{ v21 }[1], [x0]
    1514:      	tbnz	w17, #0x2, 0x147c <_llm_rows.packet_batch.blocks+0xf98>
    1518:      	tbz	w17, #0x3, 0x1488 <_llm_rows.packet_batch.blocks+0xfa4>
    151c:      	add	x0, x16, #0xc
    1520:      	ld1.s	{ v21 }[3], [x0]
    1524:      	tbnz	w17, #0x4, 0x148c <_llm_rows.packet_batch.blocks+0xfa8>
    1528:      	tbz	w17, #0x5, 0x1498 <_llm_rows.packet_batch.blocks+0xfb4>
    152c:      	add	x0, x16, #0x14
    1530:      	ld1.s	{ v20 }[1], [x0]
    1534:      	tbnz	w17, #0x6, 0x149c <_llm_rows.packet_batch.blocks+0xfb8>
    1538:      	tbz	w17, #0x7, 0x1544 <_llm_rows.packet_batch.blocks+0x1060>
    153c:      	add	x16, x16, #0x1c
    1540:      	ld1.s	{ v20 }[3], [x16]
    1544:      	fmov	w16, s17
    1548:      	add	x15, x15, #0x60
    154c:      	tst	w12, #0x1
    1550:      	mov	w12, #0x60              ; =96
    1554:      	csel	x12, x15, x12, ne
    1558:      	add	x15, x10, x12
    155c:      	movi.2d	v22, #0000000000000000
    1560:      	movi.2d	v0, #0000000000000000
    1564:      	tbz	w16, #0x0, 0x16b0 <_llm_rows.packet_batch.blocks+0x11cc>
    1568:      	ldr	s22, [x15]
    156c:      	and	w16, w16, #0xff
    1570:      	tbnz	w16, #0x1, 0x16b8 <_llm_rows.packet_batch.blocks+0x11d4>
    1574:      	tbz	w16, #0x2, 0x16c4 <_llm_rows.packet_batch.blocks+0x11e0>
    1578:      	add	x17, x15, #0x8
    157c:      	ld1.s	{ v22 }[2], [x17]
    1580:      	tbnz	w16, #0x3, 0x16c8 <_llm_rows.packet_batch.blocks+0x11e4>
    1584:      	tbz	w16, #0x4, 0x16d4 <_llm_rows.packet_batch.blocks+0x11f0>
    1588:      	add	x17, x15, #0x10
    158c:      	ld1.s	{ v0 }[0], [x17]
    1590:      	tbnz	w16, #0x5, 0x16d8 <_llm_rows.packet_batch.blocks+0x11f4>
    1594:      	tbz	w16, #0x6, 0x16e4 <_llm_rows.packet_batch.blocks+0x1200>
    1598:      	add	x17, x15, #0x18
    159c:      	ld1.s	{ v0 }[2], [x17]
    15a0:      	tbnz	w16, #0x7, 0x16e8 <_llm_rows.packet_batch.blocks+0x1204>
    15a4:      	fmov	w15, s17
    15a8:      	add	x12, x9, x12
    15ac:      	movi.2d	v24, #0000000000000000
    15b0:      	movi.2d	v23, #0000000000000000
    15b4:      	tbz	w15, #0x0, 0x1704 <_llm_rows.packet_batch.blocks+0x1220>
    15b8:      	ldr	s24, [x12]
    15bc:      	and	w15, w15, #0xff
    15c0:      	tbnz	w15, #0x1, 0x170c <_llm_rows.packet_batch.blocks+0x1228>
    15c4:      	tbz	w15, #0x2, 0x1718 <_llm_rows.packet_batch.blocks+0x1234>
    15c8:      	add	x16, x12, #0x8
    15cc:      	ld1.s	{ v24 }[2], [x16]
    15d0:      	tbnz	w15, #0x3, 0x171c <_llm_rows.packet_batch.blocks+0x1238>
    15d4:      	tbz	w15, #0x4, 0x1728 <_llm_rows.packet_batch.blocks+0x1244>
    15d8:      	add	x16, x12, #0x10
    15dc:      	ld1.s	{ v23 }[0], [x16]
    15e0:      	tbnz	w15, #0x5, 0x172c <_llm_rows.packet_batch.blocks+0x1248>
    15e4:      	tbz	w15, #0x6, 0x1738 <_llm_rows.packet_batch.blocks+0x1254>
    15e8:      	add	x16, x12, #0x18
    15ec:      	ld1.s	{ v23 }[2], [x16]
    15f0:      	tbnz	w15, #0x7, 0x173c <_llm_rows.packet_batch.blocks+0x1258>
    15f4:      	fmov	w15, s17
    15f8:      	fmul.4s	v25, v19, v22
    15fc:      	fmul.4s	v26, v21, v24
    1600:      	fsub.4s	v25, v25, v26
    1604:      	add	x12, x8, x14
    1608:      	tbz	w15, #0x0, 0x175c <_llm_rows.packet_batch.blocks+0x1278>
    160c:      	str	s25, [x12]
    1610:      	and	w14, w15, #0xff
    1614:      	tbnz	w14, #0x1, 0x1764 <_llm_rows.packet_batch.blocks+0x1280>
    1618:      	tbz	w14, #0x2, 0x1770 <_llm_rows.packet_batch.blocks+0x128c>
    161c:      	add	x15, x12, #0x8
    1620:      	st1.s	{ v25 }[2], [x15]
    1624:      	tbnz	w14, #0x3, 0x1774 <_llm_rows.packet_batch.blocks+0x1290>
    1628:      	fmul.4s	v25, v18, v0
    162c:      	fmul.4s	v26, v20, v23
    1630:      	fsub.4s	v25, v25, v26
    1634:      	tbz	w14, #0x4, 0x178c <_llm_rows.packet_batch.blocks+0x12a8>
    1638:      	str	s25, [x12, #0x10]
    163c:      	tbnz	w14, #0x5, 0x1790 <_llm_rows.packet_batch.blocks+0x12ac>
    1640:      	tbz	w14, #0x6, 0x179c <_llm_rows.packet_batch.blocks+0x12b8>
    1644:      	add	x15, x12, #0x18
    1648:      	st1.s	{ v25 }[2], [x15]
    164c:      	tbnz	w14, #0x7, 0x17a0 <_llm_rows.packet_batch.blocks+0x12bc>
    1650:      	fmov	w14, s17
    1654:      	fmul.4s	v17, v19, v24
    1658:      	fmul.4s	v19, v21, v22
    165c:      	fadd.4s	v17, v19, v17
    1660:      	add	x12, x8, x13
    1664:      	tbz	w14, #0x0, 0x17c0 <_llm_rows.packet_batch.blocks+0x12dc>
    1668:      	str	s17, [x12]
    166c:      	and	w13, w14, #0xff
    1670:      	tbnz	w13, #0x1, 0x17c8 <_llm_rows.packet_batch.blocks+0x12e4>
    1674:      	tbz	w13, #0x2, 0x17d4 <_llm_rows.packet_batch.blocks+0x12f0>
    1678:      	add	x14, x12, #0x8
    167c:      	st1.s	{ v17 }[2], [x14]
    1680:      	tbnz	w13, #0x3, 0x17d8 <_llm_rows.packet_batch.blocks+0x12f4>
    1684:      	fmul.4s	v17, v18, v23
    1688:      	fmul.4s	v0, v20, v0
    168c:      	fadd.4s	v0, v0, v17
    1690:      	tbz	w13, #0x4, 0x17f0 <_llm_rows.packet_batch.blocks+0x130c>
    1694:      	str	s0, [x12, #0x10]
    1698:      	tbnz	w13, #0x5, 0x17f4 <_llm_rows.packet_batch.blocks+0x1310>
    169c:      	tbz	w13, #0x6, 0x1800 <_llm_rows.packet_batch.blocks+0x131c>
    16a0:      	add	x14, x12, #0x18
    16a4:      	st1.s	{ v0 }[2], [x14]
    16a8:      	tbnz	w13, #0x7, 0x1804 <_llm_rows.packet_batch.blocks+0x1320>
    16ac:      	b	0x180c <_llm_rows.packet_batch.blocks+0x1328>
    16b0:      	and	w16, w16, #0xff
    16b4:      	tbz	w16, #0x1, 0x1574 <_llm_rows.packet_batch.blocks+0x1090>
    16b8:      	add	x17, x15, #0x4
    16bc:      	ld1.s	{ v22 }[1], [x17]
    16c0:      	tbnz	w16, #0x2, 0x1578 <_llm_rows.packet_batch.blocks+0x1094>
    16c4:      	tbz	w16, #0x3, 0x1584 <_llm_rows.packet_batch.blocks+0x10a0>
    16c8:      	add	x17, x15, #0xc
    16cc:      	ld1.s	{ v22 }[3], [x17]
    16d0:      	tbnz	w16, #0x4, 0x1588 <_llm_rows.packet_batch.blocks+0x10a4>
    16d4:      	tbz	w16, #0x5, 0x1594 <_llm_rows.packet_batch.blocks+0x10b0>
    16d8:      	add	x17, x15, #0x14
    16dc:      	ld1.s	{ v0 }[1], [x17]
    16e0:      	tbnz	w16, #0x6, 0x1598 <_llm_rows.packet_batch.blocks+0x10b4>
    16e4:      	tbz	w16, #0x7, 0x15a4 <_llm_rows.packet_batch.blocks+0x10c0>
    16e8:      	add	x15, x15, #0x1c
    16ec:      	ld1.s	{ v0 }[3], [x15]
    16f0:      	fmov	w15, s17
    16f4:      	add	x12, x9, x12
    16f8:      	movi.2d	v24, #0000000000000000
    16fc:      	movi.2d	v23, #0000000000000000
    1700:      	tbnz	w15, #0x0, 0x15b8 <_llm_rows.packet_batch.blocks+0x10d4>
    1704:      	and	w15, w15, #0xff
    1708:      	tbz	w15, #0x1, 0x15c4 <_llm_rows.packet_batch.blocks+0x10e0>
    170c:      	add	x16, x12, #0x4
    1710:      	ld1.s	{ v24 }[1], [x16]
    1714:      	tbnz	w15, #0x2, 0x15c8 <_llm_rows.packet_batch.blocks+0x10e4>
    1718:      	tbz	w15, #0x3, 0x15d4 <_llm_rows.packet_batch.blocks+0x10f0>
    171c:      	add	x16, x12, #0xc
    1720:      	ld1.s	{ v24 }[3], [x16]
    1724:      	tbnz	w15, #0x4, 0x15d8 <_llm_rows.packet_batch.blocks+0x10f4>
    1728:      	tbz	w15, #0x5, 0x15e4 <_llm_rows.packet_batch.blocks+0x1100>
    172c:      	add	x16, x12, #0x14
    1730:      	ld1.s	{ v23 }[1], [x16]
    1734:      	tbnz	w15, #0x6, 0x15e8 <_llm_rows.packet_batch.blocks+0x1104>
    1738:      	tbz	w15, #0x7, 0x15f4 <_llm_rows.packet_batch.blocks+0x1110>
    173c:      	add	x12, x12, #0x1c
    1740:      	ld1.s	{ v23 }[3], [x12]
    1744:      	fmov	w15, s17
    1748:      	fmul.4s	v25, v19, v22
    174c:      	fmul.4s	v26, v21, v24
    1750:      	fsub.4s	v25, v25, v26
    1754:      	add	x12, x8, x14
    1758:      	tbnz	w15, #0x0, 0x160c <_llm_rows.packet_batch.blocks+0x1128>
    175c:      	and	w14, w15, #0xff
    1760:      	tbz	w14, #0x1, 0x1618 <_llm_rows.packet_batch.blocks+0x1134>
    1764:      	add	x15, x12, #0x4
    1768:      	st1.s	{ v25 }[1], [x15]
    176c:      	tbnz	w14, #0x2, 0x161c <_llm_rows.packet_batch.blocks+0x1138>
    1770:      	tbz	w14, #0x3, 0x1628 <_llm_rows.packet_batch.blocks+0x1144>
    1774:      	add	x15, x12, #0xc
    1778:      	st1.s	{ v25 }[3], [x15]
    177c:      	fmul.4s	v25, v18, v0
    1780:      	fmul.4s	v26, v20, v23
    1784:      	fsub.4s	v25, v25, v26
    1788:      	tbnz	w14, #0x4, 0x1638 <_llm_rows.packet_batch.blocks+0x1154>
    178c:      	tbz	w14, #0x5, 0x1640 <_llm_rows.packet_batch.blocks+0x115c>
    1790:      	add	x15, x12, #0x14
    1794:      	st1.s	{ v25 }[1], [x15]
    1798:      	tbnz	w14, #0x6, 0x1644 <_llm_rows.packet_batch.blocks+0x1160>
    179c:      	tbz	w14, #0x7, 0x1650 <_llm_rows.packet_batch.blocks+0x116c>
    17a0:      	add	x12, x12, #0x1c
    17a4:      	st1.s	{ v25 }[3], [x12]
    17a8:      	fmov	w14, s17
    17ac:      	fmul.4s	v17, v19, v24
    17b0:      	fmul.4s	v19, v21, v22
    17b4:      	fadd.4s	v17, v19, v17
    17b8:      	add	x12, x8, x13
    17bc:      	tbnz	w14, #0x0, 0x1668 <_llm_rows.packet_batch.blocks+0x1184>
    17c0:      	and	w13, w14, #0xff
    17c4:      	tbz	w13, #0x1, 0x1674 <_llm_rows.packet_batch.blocks+0x1190>
    17c8:      	add	x14, x12, #0x4
    17cc:      	st1.s	{ v17 }[1], [x14]
    17d0:      	tbnz	w13, #0x2, 0x1678 <_llm_rows.packet_batch.blocks+0x1194>
    17d4:      	tbz	w13, #0x3, 0x1684 <_llm_rows.packet_batch.blocks+0x11a0>
    17d8:      	add	x14, x12, #0xc
    17dc:      	st1.s	{ v17 }[3], [x14]
    17e0:      	fmul.4s	v17, v18, v23
    17e4:      	fmul.4s	v0, v20, v0
    17e8:      	fadd.4s	v0, v0, v17
    17ec:      	tbnz	w13, #0x4, 0x1694 <_llm_rows.packet_batch.blocks+0x11b0>
    17f0:      	tbz	w13, #0x5, 0x169c <_llm_rows.packet_batch.blocks+0x11b8>
    17f4:      	add	x14, x12, #0x14
    17f8:      	st1.s	{ v0 }[1], [x14]
    17fc:      	tbnz	w13, #0x6, 0x16a0 <_llm_rows.packet_batch.blocks+0x11bc>
    1800:      	tbz	w13, #0x7, 0x180c <_llm_rows.packet_batch.blocks+0x1328>
    1804:      	add	x12, x12, #0x1c
    1808:      	st1.s	{ v0 }[3], [x12]
    180c:      	umull.2d	v19, v6, v10
    1810:      	xtn.4h	v0, v27
    1814:      	uzp1.8b	v0, v0, v0
    1818:      	movi.2d	v28, #0000000000000000
    181c:      	mov.b	v28[0], v0[0]
    1820:      	adrp	x12, 0x1000 <_llm_rows.packet_batch.blocks+0xb1c>
    1824:      	ldr	d22, [x12]
    1828:      	and.8b	v17, v28, v22
    182c:      	addv.8b	b17, v17
    1830:      	fmov	w13, s17
    1834:      	umaxv.8b	b17, v28
    1838:      	fmov	w15, s17
    183c:      	rbit	w12, w13
    1840:      	clz	w12, w12
    1844:      	tst	w15, #0x1
    1848:      	csel	w12, w12, wzr, ne
    184c:      	dup.2d	v30, x4
    1850:      	orr.16b	v29, v16, v30
    1854:      	add.2d	v18, v19, v29
    1858:      	movi.2d	v17, #0000000000000000
    185c:      	mov.b	v17[0], v0[0]
    1860:      	ushll.2d	v0, v17, #0x0
    1864:      	shl.2d	v0, v0, #0x3f
    1868:      	cmlt.2d	v0, v0, #0
    186c:      	and.16b	v0, v0, v18
    1870:      	movi.2d	v17, #0000000000000000
    1874:      	stp	q17, q17, [sp, #0x370]
    1878:      	stp	q0, q17, [sp, #0x350]
    187c:      	and	x14, x12, #0x7
    1880:      	add	x16, sp, #0x350
    1884:      	ldr	x14, [x16, x14, lsl #3]
    1888:      	sub	x14, x14, x12
    188c:      	add	x14, x11, x14, lsl #2
    1890:      	movi.2d	v0, #0000000000000000
    1894:      	tbz	w15, #0x0, 0x18d4 <_llm_rows.packet_batch.blocks+0x13f0>
    1898:      	ldr	s17, [x14]
    189c:      	tbnz	w13, #0x1, 0x18d8 <_llm_rows.packet_batch.blocks+0x13f4>
    18a0:      	tbz	w13, #0x2, 0x18e4 <_llm_rows.packet_batch.blocks+0x1400>
    18a4:      	add	x15, x14, #0x8
    18a8:      	ld1.s	{ v17 }[2], [x15]
    18ac:      	tbnz	w13, #0x3, 0x18e8 <_llm_rows.packet_batch.blocks+0x1404>
    18b0:      	tbz	w13, #0x4, 0x18f4 <_llm_rows.packet_batch.blocks+0x1410>
    18b4:      	add	x15, x14, #0x10
    18b8:      	ld1.s	{ v0 }[0], [x15]
    18bc:      	tbnz	w13, #0x5, 0x18f8 <_llm_rows.packet_batch.blocks+0x1414>
    18c0:      	tbz	w13, #0x6, 0x1904 <_llm_rows.packet_batch.blocks+0x1420>
    18c4:      	add	x15, x14, #0x18
    18c8:      	ld1.s	{ v0 }[2], [x15]
    18cc:      	tbnz	w13, #0x7, 0x1908 <_llm_rows.packet_batch.blocks+0x1424>
    18d0:      	b	0x1910 <_llm_rows.packet_batch.blocks+0x142c>
    18d4:      	tbz	w13, #0x1, 0x18a0 <_llm_rows.packet_batch.blocks+0x13bc>
    18d8:      	add	x15, x14, #0x4
    18dc:      	ld1.s	{ v17 }[1], [x15]
    18e0:      	tbnz	w13, #0x2, 0x18a4 <_llm_rows.packet_batch.blocks+0x13c0>
    18e4:      	tbz	w13, #0x3, 0x18b0 <_llm_rows.packet_batch.blocks+0x13cc>
    18e8:      	add	x15, x14, #0xc
    18ec:      	ld1.s	{ v17 }[3], [x15]
    18f0:      	tbnz	w13, #0x4, 0x18b4 <_llm_rows.packet_batch.blocks+0x13d0>
    18f4:      	tbz	w13, #0x5, 0x18c0 <_llm_rows.packet_batch.blocks+0x13dc>
    18f8:      	add	x15, x14, #0x14
    18fc:      	ld1.s	{ v0 }[1], [x15]
    1900:      	tbnz	w13, #0x6, 0x18c4 <_llm_rows.packet_batch.blocks+0x13e0>
    1904:      	tbz	w13, #0x7, 0x1910 <_llm_rows.packet_batch.blocks+0x142c>
    1908:      	add	x13, x14, #0x1c
    190c:      	ld1.s	{ v0 }[3], [x13]
    1910:      	umull.2d	v24, v4, v10
    1914:      	umull.2d	v26, v5, v10
    1918:      	umull.2d	v25, v7, v10
    191c:      	add.2d	v21, v16, v19
    1920:      	add.2d	v20, v2, v24
    1924:      	add.2d	v19, v3, v26
    1928:      	add.2d	v16, v1, v25
    192c:      	mov	w13, #0x41              ; =65
    1930:      	dup.2d	v23, x13
    1934:      	add.2d	v16, v16, v23
    1938:      	add.2d	v19, v19, v23
    193c:      	add.2d	v20, v20, v23
    1940:      	mov	b27, v28[0]
    1944:      	mov.b	v27[4], v28[1]
    1948:      	add.2d	v21, v21, v23
    194c:      	ushll.2d	v23, v27, #0x0
    1950:      	shl.2d	v23, v23, #0x3f
    1954:      	cmlt.2d	v23, v23, #0
    1958:      	and.16b	v27, v23, v21
    195c:      	mov	b23, v28[2]
    1960:      	mov.b	v23[4], v28[3]
    1964:      	ushll.2d	v23, v23, #0x0
    1968:      	shl.2d	v23, v23, #0x3f
    196c:      	cmlt.2d	v23, v23, #0
    1970:      	and.16b	v31, v23, v20
    1974:      	mov	b23, v28[4]
    1978:      	mov.b	v23[4], v28[5]
    197c:      	ushll.2d	v23, v23, #0x0
    1980:      	shl.2d	v23, v23, #0x3f
    1984:      	cmlt.2d	v23, v23, #0
    1988:      	and.16b	v8, v23, v19
    198c:      	mov	b23, v28[6]
    1990:      	mov.b	v23[4], v28[7]
    1994:      	ushll.2d	v23, v23, #0x0
    1998:      	shl.2d	v23, v23, #0x3f
    199c:      	cmlt.2d	v23, v23, #0
    19a0:      	and.16b	v9, v23, v16
    19a4:      	shl.8b	v23, v28, #0x7
    19a8:      	cmlt.8b	v23, v23, #0
    19ac:      	and.8b	v22, v23, v22
    19b0:      	addv.8b	b23, v22
    19b4:      	fmov	w13, s23
    19b8:      	stp	q8, q9, [sp, #0x330]
    19bc:      	stp	q27, q31, [sp, #0x310]
    19c0:      	and	x14, x12, #0x7
    19c4:      	add	x15, sp, #0x310
    19c8:      	ldr	x14, [x15, x14, lsl #3]
    19cc:      	sub	x14, x14, x12
    19d0:      	add	x11, x11, x14, lsl #2
    19d4:      	movi.2d	v27, #0000000000000000
    19d8:      	movi.2d	v22, #0000000000000000
    19dc:      	tbz	w13, #0x0, 0x1a1c <_llm_rows.packet_batch.blocks+0x1538>
    19e0:      	ldr	s27, [x11]
    19e4:      	tbnz	w13, #0x1, 0x1a20 <_llm_rows.packet_batch.blocks+0x153c>
    19e8:      	tbz	w13, #0x2, 0x1a2c <_llm_rows.packet_batch.blocks+0x1548>
    19ec:      	add	x14, x11, #0x8
    19f0:      	ld1.s	{ v27 }[2], [x14]
    19f4:      	tbnz	w13, #0x3, 0x1a30 <_llm_rows.packet_batch.blocks+0x154c>
    19f8:      	tbz	w13, #0x4, 0x1a3c <_llm_rows.packet_batch.blocks+0x1558>
    19fc:      	add	x14, x11, #0x10
    1a00:      	ld1.s	{ v22 }[0], [x14]
    1a04:      	tbnz	w13, #0x5, 0x1a40 <_llm_rows.packet_batch.blocks+0x155c>
    1a08:      	tbz	w13, #0x6, 0x1a4c <_llm_rows.packet_batch.blocks+0x1568>
    1a0c:      	add	x14, x11, #0x18
    1a10:      	ld1.s	{ v22 }[2], [x14]
    1a14:      	tbnz	w13, #0x7, 0x1a50 <_llm_rows.packet_batch.blocks+0x156c>
    1a18:      	b	0x1a58 <_llm_rows.packet_batch.blocks+0x1574>
    1a1c:      	tbz	w13, #0x1, 0x19e8 <_llm_rows.packet_batch.blocks+0x1504>
    1a20:      	add	x14, x11, #0x4
    1a24:      	ld1.s	{ v27 }[1], [x14]
    1a28:      	tbnz	w13, #0x2, 0x19ec <_llm_rows.packet_batch.blocks+0x1508>
    1a2c:      	tbz	w13, #0x3, 0x19f8 <_llm_rows.packet_batch.blocks+0x1514>
    1a30:      	add	x14, x11, #0xc
    1a34:      	ld1.s	{ v27 }[3], [x14]
    1a38:      	tbnz	w13, #0x4, 0x19fc <_llm_rows.packet_batch.blocks+0x1518>
    1a3c:      	tbz	w13, #0x5, 0x1a08 <_llm_rows.packet_batch.blocks+0x1524>
    1a40:      	add	x14, x11, #0x14
    1a44:      	ld1.s	{ v22 }[1], [x14]
    1a48:      	tbnz	w13, #0x6, 0x1a0c <_llm_rows.packet_batch.blocks+0x1528>
    1a4c:      	tbz	w13, #0x7, 0x1a58 <_llm_rows.packet_batch.blocks+0x1574>
    1a50:      	add	x11, x11, #0x1c
    1a54:      	ld1.s	{ v22 }[3], [x11]
    1a58:      	umull.2d	v6, v6, v12
    1a5c:      	umull.2d	v31, v4, v12
    1a60:      	umull.2d	v8, v5, v12
    1a64:      	umull.2d	v7, v7, v12
    1a68:      	orr.16b	v4, v1, v30
    1a6c:      	orr.16b	v5, v2, v30
    1a70:      	orr.16b	v3, v3, v30
    1a74:      	add.2d	v1, v7, v4
    1a78:      	add.2d	v2, v8, v3
    1a7c:      	add.2d	v7, v31, v5
    1a80:      	add.2d	v6, v6, v29
    1a84:      	mov	b29, v28[0]
    1a88:      	mov.b	v29[4], v28[1]
    1a8c:      	ushll.2d	v29, v29, #0x0
    1a90:      	shl.2d	v29, v29, #0x3f
    1a94:      	cmlt.2d	v29, v29, #0
    1a98:      	and.16b	v6, v29, v6
    1a9c:      	mov	b29, v28[2]
    1aa0:      	mov.b	v29[4], v28[3]
    1aa4:      	ushll.2d	v29, v29, #0x0
    1aa8:      	shl.2d	v29, v29, #0x3f
    1aac:      	cmlt.2d	v29, v29, #0
    1ab0:      	and.16b	v7, v29, v7
    1ab4:      	mov	b29, v28[4]
    1ab8:      	mov.b	v29[4], v28[5]
    1abc:      	ushll.2d	v29, v29, #0x0
    1ac0:      	shl.2d	v29, v29, #0x3f
    1ac4:      	cmlt.2d	v29, v29, #0
    1ac8:      	mov	b30, v28[6]
    1acc:      	mov.b	v30[4], v28[7]
    1ad0:      	and.16b	v2, v29, v2
    1ad4:      	ushll.2d	v28, v30, #0x0
    1ad8:      	shl.2d	v28, v28, #0x3f
    1adc:      	cmlt.2d	v28, v28, #0
    1ae0:      	and.16b	v1, v28, v1
    1ae4:      	stp	q2, q1, [sp, #0x2f0]
    1ae8:      	stp	q6, q7, [sp, #0x2d0]
    1aec:      	and	x11, x12, #0x7
    1af0:      	add	x13, sp, #0x2d0
    1af4:      	ldr	x11, [x13, x11, lsl #3]
    1af8:      	fmov	w13, s23
    1afc:      	sub	x11, x11, x12
    1b00:      	lsl	x11, x11, #2
    1b04:      	add	x10, x10, x11
    1b08:      	movi.2d	v2, #0000000000000000
    1b0c:      	movi.2d	v1, #0000000000000000
    1b10:      	tbz	w13, #0x0, 0x1b9c <_llm_rows.packet_batch.blocks+0x16b8>
    1b14:      	ldr	s2, [x10]
    1b18:      	tbnz	w13, #0x1, 0x1ba0 <_llm_rows.packet_batch.blocks+0x16bc>
    1b1c:      	tbz	w13, #0x2, 0x1bac <_llm_rows.packet_batch.blocks+0x16c8>
    1b20:      	add	x14, x10, #0x8
    1b24:      	ld1.s	{ v2 }[2], [x14]
    1b28:      	tbnz	w13, #0x3, 0x1bb0 <_llm_rows.packet_batch.blocks+0x16cc>
    1b2c:      	tbz	w13, #0x4, 0x1bbc <_llm_rows.packet_batch.blocks+0x16d8>
    1b30:      	add	x14, x10, #0x10
    1b34:      	ld1.s	{ v1 }[0], [x14]
    1b38:      	tbnz	w13, #0x5, 0x1bc0 <_llm_rows.packet_batch.blocks+0x16dc>
    1b3c:      	tbz	w13, #0x6, 0x1bcc <_llm_rows.packet_batch.blocks+0x16e8>
    1b40:      	add	x14, x10, #0x18
    1b44:      	ld1.s	{ v1 }[2], [x14]
    1b48:      	tbnz	w13, #0x7, 0x1bd0 <_llm_rows.packet_batch.blocks+0x16ec>
    1b4c:      	add	x9, x9, x11
    1b50:      	fmov	w10, s23
    1b54:      	movi.2d	v7, #0000000000000000
    1b58:      	movi.2d	v6, #0000000000000000
    1b5c:      	tbz	w10, #0x0, 0x1bec <_llm_rows.packet_batch.blocks+0x1708>
    1b60:      	ldr	s7, [x9]
    1b64:      	tbnz	w10, #0x1, 0x1bf0 <_llm_rows.packet_batch.blocks+0x170c>
    1b68:      	tbz	w10, #0x2, 0x1bfc <_llm_rows.packet_batch.blocks+0x1718>
    1b6c:      	add	x11, x9, #0x8
    1b70:      	ld1.s	{ v7 }[2], [x11]
    1b74:      	tbnz	w10, #0x3, 0x1c00 <_llm_rows.packet_batch.blocks+0x171c>
    1b78:      	tbz	w10, #0x4, 0x1c0c <_llm_rows.packet_batch.blocks+0x1728>
    1b7c:      	add	x11, x9, #0x10
    1b80:      	ld1.s	{ v6 }[0], [x11]
    1b84:      	tbnz	w10, #0x5, 0x1c10 <_llm_rows.packet_batch.blocks+0x172c>
    1b88:      	tbz	w10, #0x6, 0x1c1c <_llm_rows.packet_batch.blocks+0x1738>
    1b8c:      	add	x11, x9, #0x18
    1b90:      	ld1.s	{ v6 }[2], [x11]
    1b94:      	tbnz	w10, #0x7, 0x1c20 <_llm_rows.packet_batch.blocks+0x173c>
    1b98:      	b	0x1c28 <_llm_rows.packet_batch.blocks+0x1744>
    1b9c:      	tbz	w13, #0x1, 0x1b1c <_llm_rows.packet_batch.blocks+0x1638>
    1ba0:      	add	x14, x10, #0x4
    1ba4:      	ld1.s	{ v2 }[1], [x14]
    1ba8:      	tbnz	w13, #0x2, 0x1b20 <_llm_rows.packet_batch.blocks+0x163c>
    1bac:      	tbz	w13, #0x3, 0x1b2c <_llm_rows.packet_batch.blocks+0x1648>
    1bb0:      	add	x14, x10, #0xc
    1bb4:      	ld1.s	{ v2 }[3], [x14]
    1bb8:      	tbnz	w13, #0x4, 0x1b30 <_llm_rows.packet_batch.blocks+0x164c>
    1bbc:      	tbz	w13, #0x5, 0x1b3c <_llm_rows.packet_batch.blocks+0x1658>
    1bc0:      	add	x14, x10, #0x14
    1bc4:      	ld1.s	{ v1 }[1], [x14]
    1bc8:      	tbnz	w13, #0x6, 0x1b40 <_llm_rows.packet_batch.blocks+0x165c>
    1bcc:      	tbz	w13, #0x7, 0x1b4c <_llm_rows.packet_batch.blocks+0x1668>
    1bd0:      	add	x10, x10, #0x1c
    1bd4:      	ld1.s	{ v1 }[3], [x10]
    1bd8:      	add	x9, x9, x11
    1bdc:      	fmov	w10, s23
    1be0:      	movi.2d	v7, #0000000000000000
    1be4:      	movi.2d	v6, #0000000000000000
    1be8:      	tbnz	w10, #0x0, 0x1b60 <_llm_rows.packet_batch.blocks+0x167c>
    1bec:      	tbz	w10, #0x1, 0x1b68 <_llm_rows.packet_batch.blocks+0x1684>
    1bf0:      	add	x11, x9, #0x4
    1bf4:      	ld1.s	{ v7 }[1], [x11]
    1bf8:      	tbnz	w10, #0x2, 0x1b6c <_llm_rows.packet_batch.blocks+0x1688>
    1bfc:      	tbz	w10, #0x3, 0x1b78 <_llm_rows.packet_batch.blocks+0x1694>
    1c00:      	add	x11, x9, #0xc
    1c04:      	ld1.s	{ v7 }[3], [x11]
    1c08:      	tbnz	w10, #0x4, 0x1b7c <_llm_rows.packet_batch.blocks+0x1698>
    1c0c:      	tbz	w10, #0x5, 0x1b88 <_llm_rows.packet_batch.blocks+0x16a4>
    1c10:      	add	x11, x9, #0x14
    1c14:      	ld1.s	{ v6 }[1], [x11]
    1c18:      	tbnz	w10, #0x6, 0x1b8c <_llm_rows.packet_batch.blocks+0x16a8>
    1c1c:      	tbz	w10, #0x7, 0x1c28 <_llm_rows.packet_batch.blocks+0x1744>
    1c20:      	add	x9, x9, #0x1c
    1c24:      	ld1.s	{ v6 }[3], [x9]
    1c28:      	add.2d	v26, v26, v3
    1c2c:      	add.2d	v5, v24, v5
    1c30:      	add.2d	v4, v25, v4
    1c34:      	fmul.4s	v3, v17, v2
    1c38:      	fmul.4s	v24, v27, v7
    1c3c:      	fsub.4s	v3, v3, v24
    1c40:      	stp	q18, q5, [sp, #0x290]
    1c44:      	stp	q26, q4, [sp, #0x2b0]
    1c48:      	and	x9, x12, #0x7
    1c4c:      	add	x10, sp, #0x290
    1c50:      	ldr	x9, [x10, x9, lsl #3]
    1c54:      	sub	x9, x9, x12
    1c58:      	add	x9, x8, x9, lsl #2
    1c5c:      	fmov	w10, s23
    1c60:      	tbz	w10, #0x0, 0x1ca8 <_llm_rows.packet_batch.blocks+0x17c4>
    1c64:      	str	s3, [x9]
    1c68:      	tbnz	w10, #0x1, 0x1cac <_llm_rows.packet_batch.blocks+0x17c8>
    1c6c:      	tbz	w10, #0x2, 0x1cb8 <_llm_rows.packet_batch.blocks+0x17d4>
    1c70:      	add	x11, x9, #0x8
    1c74:      	st1.s	{ v3 }[2], [x11]
    1c78:      	tbnz	w10, #0x3, 0x1cbc <_llm_rows.packet_batch.blocks+0x17d8>
    1c7c:      	fmul.4s	v3, v0, v1
    1c80:      	fmul.4s	v4, v22, v6
    1c84:      	fsub.4s	v3, v3, v4
    1c88:      	tbz	w10, #0x4, 0x1cd4 <_llm_rows.packet_batch.blocks+0x17f0>
    1c8c:      	str	s3, [x9, #0x10]
    1c90:      	tbnz	w10, #0x5, 0x1cd8 <_llm_rows.packet_batch.blocks+0x17f4>
    1c94:      	tbz	w10, #0x6, 0x1ce4 <_llm_rows.packet_batch.blocks+0x1800>
    1c98:      	add	x11, x9, #0x18
    1c9c:      	st1.s	{ v3 }[2], [x11]
    1ca0:      	tbnz	w10, #0x7, 0x1ce8 <_llm_rows.packet_batch.blocks+0x1804>
    1ca4:      	b	0x1cf0 <_llm_rows.packet_batch.blocks+0x180c>
    1ca8:      	tbz	w10, #0x1, 0x1c6c <_llm_rows.packet_batch.blocks+0x1788>
    1cac:      	add	x11, x9, #0x4
    1cb0:      	st1.s	{ v3 }[1], [x11]
    1cb4:      	tbnz	w10, #0x2, 0x1c70 <_llm_rows.packet_batch.blocks+0x178c>
    1cb8:      	tbz	w10, #0x3, 0x1c7c <_llm_rows.packet_batch.blocks+0x1798>
    1cbc:      	add	x11, x9, #0xc
    1cc0:      	st1.s	{ v3 }[3], [x11]
    1cc4:      	fmul.4s	v3, v0, v1
    1cc8:      	fmul.4s	v4, v22, v6
    1ccc:      	fsub.4s	v3, v3, v4
    1cd0:      	tbnz	w10, #0x4, 0x1c8c <_llm_rows.packet_batch.blocks+0x17a8>
    1cd4:      	tbz	w10, #0x5, 0x1c94 <_llm_rows.packet_batch.blocks+0x17b0>
    1cd8:      	add	x11, x9, #0x14
    1cdc:      	st1.s	{ v3 }[1], [x11]
    1ce0:      	tbnz	w10, #0x6, 0x1c98 <_llm_rows.packet_batch.blocks+0x17b4>
    1ce4:      	tbz	w10, #0x7, 0x1cf0 <_llm_rows.packet_batch.blocks+0x180c>
    1ce8:      	add	x9, x9, #0x1c
    1cec:      	st1.s	{ v3 }[3], [x9]
    1cf0:      	fmul.4s	v3, v17, v7
    1cf4:      	fmul.4s	v2, v27, v2
    1cf8:      	fadd.4s	v2, v2, v3
    1cfc:      	stp	q21, q20, [sp, #0x250]
    1d00:      	stp	q19, q16, [sp, #0x270]
    1d04:      	and	x9, x12, #0x7
    1d08:      	add	x10, sp, #0x250
    1d0c:      	ldr	x9, [x10, x9, lsl #3]
    1d10:      	sub	x9, x9, x12
    1d14:      	add	x8, x8, x9, lsl #2
    1d18:      	fmov	w9, s23
    1d1c:      	tbz	w9, #0x0, 0x1d64 <_llm_rows.packet_batch.blocks+0x1880>
    1d20:      	str	s2, [x8]
    1d24:      	tbnz	w9, #0x1, 0x1d68 <_llm_rows.packet_batch.blocks+0x1884>
    1d28:      	tbz	w9, #0x2, 0x1d74 <_llm_rows.packet_batch.blocks+0x1890>
    1d2c:      	add	x10, x8, #0x8
    1d30:      	st1.s	{ v2 }[2], [x10]
    1d34:      	tbnz	w9, #0x3, 0x1d78 <_llm_rows.packet_batch.blocks+0x1894>
    1d38:      	fmul.4s	v0, v0, v6
    1d3c:      	fmul.4s	v1, v22, v1
    1d40:      	fadd.4s	v0, v1, v0
    1d44:      	tbz	w9, #0x4, 0x37d0 <_llm_rows.packet_batch.blocks+0x32ec>
    1d48:      	str	s0, [x8, #0x10]
    1d4c:      	tbnz	w9, #0x5, 0x37d4 <_llm_rows.packet_batch.blocks+0x32f0>
    1d50:      	tbz	w9, #0x6, 0x37e0 <_llm_rows.packet_batch.blocks+0x32fc>
    1d54:      	add	x10, x8, #0x18
    1d58:      	st1.s	{ v0 }[2], [x10]
    1d5c:      	tbnz	w9, #0x7, 0x37e4 <_llm_rows.packet_batch.blocks+0x3300>
    1d60:      	b	0x37ec <_llm_rows.packet_batch.blocks+0x3308>
    1d64:      	tbz	w9, #0x1, 0x1d28 <_llm_rows.packet_batch.blocks+0x1844>
    1d68:      	add	x10, x8, #0x4
    1d6c:      	st1.s	{ v2 }[1], [x10]
    1d70:      	tbnz	w9, #0x2, 0x1d2c <_llm_rows.packet_batch.blocks+0x1848>
    1d74:      	tbz	w9, #0x3, 0x1d38 <_llm_rows.packet_batch.blocks+0x1854>
    1d78:      	add	x10, x8, #0xc
    1d7c:      	st1.s	{ v2 }[3], [x10]
    1d80:      	fmul.4s	v0, v0, v6
    1d84:      	fmul.4s	v1, v22, v1
    1d88:      	fadd.4s	v0, v1, v0
    1d8c:      	tbz	w9, #0x4, 0x37d0 <_llm_rows.packet_batch.blocks+0x32ec>
    1d90:      	b	0x1d48 <_llm_rows.packet_batch.blocks+0x1864>
    1d94:      	ldr	q18, [sp, #0x1c0]
    1d98:      	and.16b	v18, v0, v18
    1d9c:      	addv.8h	h18, v18
    1da0:      	fmov	w14, s18
    1da4:      	xtn.8b	v0, v0
    1da8:      	umov.b	w12, v0[0]
    1dac:      	add	x7, x13, x13, lsl #5
    1db0:      	lsl	x5, x7, #3
    1db4:      	tst	w12, #0x1
    1db8:      	csel	x26, x5, xzr, ne
    1dbc:      	add	x13, x11, x26
    1dc0:      	movi.2d	v0, #0000000000000000
    1dc4:      	movi.2d	v19, #0000000000000000
    1dc8:      	mov	w16, #0x20              ; =32
    1dcc:      	mov	w22, #0x84              ; =132
    1dd0:      	tbz	w14, #0x0, 0x1e18 <_llm_rows.packet_batch.blocks+0x1934>
    1dd4:      	ldr	s0, [x13]
    1dd8:      	and	w14, w14, #0xff
    1ddc:      	add	x1, sp, #0x7b0
    1de0:      	tbnz	w14, #0x1, 0x1e24 <_llm_rows.packet_batch.blocks+0x1940>
    1de4:      	tbz	w14, #0x2, 0x1e30 <_llm_rows.packet_batch.blocks+0x194c>
    1de8:      	add	x15, x13, #0x8
    1dec:      	ld1.s	{ v0 }[2], [x15]
    1df0:      	tbnz	w14, #0x3, 0x1e34 <_llm_rows.packet_batch.blocks+0x1950>
    1df4:      	tbz	w14, #0x4, 0x1e40 <_llm_rows.packet_batch.blocks+0x195c>
    1df8:      	add	x15, x13, #0x10
    1dfc:      	ld1.s	{ v19 }[0], [x15]
    1e00:      	tbnz	w14, #0x5, 0x1e44 <_llm_rows.packet_batch.blocks+0x1960>
    1e04:      	tbz	w14, #0x6, 0x1e50 <_llm_rows.packet_batch.blocks+0x196c>
    1e08:      	add	x15, x13, #0x18
    1e0c:      	ld1.s	{ v19 }[2], [x15]
    1e10:      	tbnz	w14, #0x7, 0x1e54 <_llm_rows.packet_batch.blocks+0x1970>
    1e14:      	b	0x1e5c <_llm_rows.packet_batch.blocks+0x1978>
    1e18:      	and	w14, w14, #0xff
    1e1c:      	add	x1, sp, #0x7b0
    1e20:      	tbz	w14, #0x1, 0x1de4 <_llm_rows.packet_batch.blocks+0x1900>
    1e24:      	add	x15, x13, #0x4
    1e28:      	ld1.s	{ v0 }[1], [x15]
    1e2c:      	tbnz	w14, #0x2, 0x1de8 <_llm_rows.packet_batch.blocks+0x1904>
    1e30:      	tbz	w14, #0x3, 0x1df4 <_llm_rows.packet_batch.blocks+0x1910>
    1e34:      	add	x15, x13, #0xc
    1e38:      	ld1.s	{ v0 }[3], [x15]
    1e3c:      	tbnz	w14, #0x4, 0x1df8 <_llm_rows.packet_batch.blocks+0x1914>
    1e40:      	tbz	w14, #0x5, 0x1e04 <_llm_rows.packet_batch.blocks+0x1920>
    1e44:      	add	x15, x13, #0x14
    1e48:      	ld1.s	{ v19 }[1], [x15]
    1e4c:      	tbnz	w14, #0x6, 0x1e08 <_llm_rows.packet_batch.blocks+0x1924>
    1e50:      	tbz	w14, #0x7, 0x1e5c <_llm_rows.packet_batch.blocks+0x1978>
    1e54:      	add	x13, x13, #0x1c
    1e58:      	ld1.s	{ v19 }[3], [x13]
    1e5c:      	fmov	w14, s18
    1e60:      	str	q0, [sp, #0x7b0]
    1e64:      	str	q19, [sp, #0x7c0]
    1e68:      	add	x13, x5, #0x20
    1e6c:      	tst	w12, #0x1
    1e70:      	str	x13, [sp, #0x1b0]
    1e74:      	csel	x13, x13, x16, ne
    1e78:      	add	x13, x11, x13
    1e7c:      	movi.2d	v0, #0000000000000000
    1e80:      	movi.2d	v19, #0000000000000000
    1e84:      	tbz	w14, #0x0, 0x1ec8 <_llm_rows.packet_batch.blocks+0x19e4>
    1e88:      	ldr	s0, [x13]
    1e8c:      	and	w14, w14, #0xff
    1e90:      	tbnz	w14, #0x1, 0x1ed0 <_llm_rows.packet_batch.blocks+0x19ec>
    1e94:      	tbz	w14, #0x2, 0x1edc <_llm_rows.packet_batch.blocks+0x19f8>
    1e98:      	add	x15, x13, #0x8
    1e9c:      	ld1.s	{ v0 }[2], [x15]
    1ea0:      	tbnz	w14, #0x3, 0x1ee0 <_llm_rows.packet_batch.blocks+0x19fc>
    1ea4:      	tbz	w14, #0x4, 0x1eec <_llm_rows.packet_batch.blocks+0x1a08>
    1ea8:      	add	x15, x13, #0x10
    1eac:      	ld1.s	{ v19 }[0], [x15]
    1eb0:      	tbnz	w14, #0x5, 0x1ef0 <_llm_rows.packet_batch.blocks+0x1a0c>
    1eb4:      	tbz	w14, #0x6, 0x1efc <_llm_rows.packet_batch.blocks+0x1a18>
    1eb8:      	add	x15, x13, #0x18
    1ebc:      	ld1.s	{ v19 }[2], [x15]
    1ec0:      	tbnz	w14, #0x7, 0x1f00 <_llm_rows.packet_batch.blocks+0x1a1c>
    1ec4:      	b	0x1f08 <_llm_rows.packet_batch.blocks+0x1a24>
    1ec8:      	and	w14, w14, #0xff
    1ecc:      	tbz	w14, #0x1, 0x1e94 <_llm_rows.packet_batch.blocks+0x19b0>
    1ed0:      	add	x15, x13, #0x4
    1ed4:      	ld1.s	{ v0 }[1], [x15]
    1ed8:      	tbnz	w14, #0x2, 0x1e98 <_llm_rows.packet_batch.blocks+0x19b4>
    1edc:      	tbz	w14, #0x3, 0x1ea4 <_llm_rows.packet_batch.blocks+0x19c0>
    1ee0:      	add	x15, x13, #0xc
    1ee4:      	ld1.s	{ v0 }[3], [x15]
    1ee8:      	tbnz	w14, #0x4, 0x1ea8 <_llm_rows.packet_batch.blocks+0x19c4>
    1eec:      	tbz	w14, #0x5, 0x1eb4 <_llm_rows.packet_batch.blocks+0x19d0>
    1ef0:      	add	x15, x13, #0x14
    1ef4:      	ld1.s	{ v19 }[1], [x15]
    1ef8:      	tbnz	w14, #0x6, 0x1eb8 <_llm_rows.packet_batch.blocks+0x19d4>
    1efc:      	tbz	w14, #0x7, 0x1f08 <_llm_rows.packet_batch.blocks+0x1a24>
    1f00:      	add	x13, x13, #0x1c
    1f04:      	ld1.s	{ v19 }[3], [x13]
    1f08:      	fmov	w14, s18
    1f0c:      	str	q0, [sp, #0x7d0]
    1f10:      	str	q19, [sp, #0x7e0]
    1f14:      	add	x15, x5, #0x40
    1f18:      	tst	w12, #0x1
    1f1c:      	mov	w13, #0x40              ; =64
    1f20:      	str	x15, [sp, #0x1a0]
    1f24:      	csel	x13, x15, x13, ne
    1f28:      	add	x13, x11, x13
    1f2c:      	movi.2d	v0, #0000000000000000
    1f30:      	movi.2d	v19, #0000000000000000
    1f34:      	tbz	w14, #0x0, 0x1f78 <_llm_rows.packet_batch.blocks+0x1a94>
    1f38:      	ldr	s0, [x13]
    1f3c:      	and	w14, w14, #0xff
    1f40:      	tbnz	w14, #0x1, 0x1f80 <_llm_rows.packet_batch.blocks+0x1a9c>
    1f44:      	tbz	w14, #0x2, 0x1f8c <_llm_rows.packet_batch.blocks+0x1aa8>
    1f48:      	add	x15, x13, #0x8
    1f4c:      	ld1.s	{ v0 }[2], [x15]
    1f50:      	tbnz	w14, #0x3, 0x1f90 <_llm_rows.packet_batch.blocks+0x1aac>
    1f54:      	tbz	w14, #0x4, 0x1f9c <_llm_rows.packet_batch.blocks+0x1ab8>
    1f58:      	add	x15, x13, #0x10
    1f5c:      	ld1.s	{ v19 }[0], [x15]
    1f60:      	tbnz	w14, #0x5, 0x1fa0 <_llm_rows.packet_batch.blocks+0x1abc>
    1f64:      	tbz	w14, #0x6, 0x1fac <_llm_rows.packet_batch.blocks+0x1ac8>
    1f68:      	add	x15, x13, #0x18
    1f6c:      	ld1.s	{ v19 }[2], [x15]
    1f70:      	tbnz	w14, #0x7, 0x1fb0 <_llm_rows.packet_batch.blocks+0x1acc>
    1f74:      	b	0x1fb8 <_llm_rows.packet_batch.blocks+0x1ad4>
    1f78:      	and	w14, w14, #0xff
    1f7c:      	tbz	w14, #0x1, 0x1f44 <_llm_rows.packet_batch.blocks+0x1a60>
    1f80:      	add	x15, x13, #0x4
    1f84:      	ld1.s	{ v0 }[1], [x15]
    1f88:      	tbnz	w14, #0x2, 0x1f48 <_llm_rows.packet_batch.blocks+0x1a64>
    1f8c:      	tbz	w14, #0x3, 0x1f54 <_llm_rows.packet_batch.blocks+0x1a70>
    1f90:      	add	x15, x13, #0xc
    1f94:      	ld1.s	{ v0 }[3], [x15]
    1f98:      	tbnz	w14, #0x4, 0x1f58 <_llm_rows.packet_batch.blocks+0x1a74>
    1f9c:      	tbz	w14, #0x5, 0x1f64 <_llm_rows.packet_batch.blocks+0x1a80>
    1fa0:      	add	x15, x13, #0x14
    1fa4:      	ld1.s	{ v19 }[1], [x15]
    1fa8:      	tbnz	w14, #0x6, 0x1f68 <_llm_rows.packet_batch.blocks+0x1a84>
    1fac:      	tbz	w14, #0x7, 0x1fb8 <_llm_rows.packet_batch.blocks+0x1ad4>
    1fb0:      	add	x13, x13, #0x1c
    1fb4:      	ld1.s	{ v19 }[3], [x13]
    1fb8:      	fmov	w14, s18
    1fbc:      	str	q0, [sp, #0x7f0]
    1fc0:      	str	q19, [sp, #0x800]
    1fc4:      	add	x17, x5, #0x60
    1fc8:      	tst	w12, #0x1
    1fcc:      	mov	w13, #0x60              ; =96
    1fd0:      	csel	x13, x17, x13, ne
    1fd4:      	add	x13, x11, x13
    1fd8:      	movi.2d	v0, #0000000000000000
    1fdc:      	movi.2d	v19, #0000000000000000
    1fe0:      	tbz	w14, #0x0, 0x2024 <_llm_rows.packet_batch.blocks+0x1b40>
    1fe4:      	ldr	s0, [x13]
    1fe8:      	and	w14, w14, #0xff
    1fec:      	tbnz	w14, #0x1, 0x202c <_llm_rows.packet_batch.blocks+0x1b48>
    1ff0:      	tbz	w14, #0x2, 0x2038 <_llm_rows.packet_batch.blocks+0x1b54>
    1ff4:      	add	x15, x13, #0x8
    1ff8:      	ld1.s	{ v0 }[2], [x15]
    1ffc:      	tbnz	w14, #0x3, 0x203c <_llm_rows.packet_batch.blocks+0x1b58>
    2000:      	tbz	w14, #0x4, 0x2048 <_llm_rows.packet_batch.blocks+0x1b64>
    2004:      	add	x15, x13, #0x10
    2008:      	ld1.s	{ v19 }[0], [x15]
    200c:      	tbnz	w14, #0x5, 0x204c <_llm_rows.packet_batch.blocks+0x1b68>
    2010:      	tbz	w14, #0x6, 0x2058 <_llm_rows.packet_batch.blocks+0x1b74>
    2014:      	add	x15, x13, #0x18
    2018:      	ld1.s	{ v19 }[2], [x15]
    201c:      	tbnz	w14, #0x7, 0x205c <_llm_rows.packet_batch.blocks+0x1b78>
    2020:      	b	0x2064 <_llm_rows.packet_batch.blocks+0x1b80>
    2024:      	and	w14, w14, #0xff
    2028:      	tbz	w14, #0x1, 0x1ff0 <_llm_rows.packet_batch.blocks+0x1b0c>
    202c:      	add	x15, x13, #0x4
    2030:      	ld1.s	{ v0 }[1], [x15]
    2034:      	tbnz	w14, #0x2, 0x1ff4 <_llm_rows.packet_batch.blocks+0x1b10>
    2038:      	tbz	w14, #0x3, 0x2000 <_llm_rows.packet_batch.blocks+0x1b1c>
    203c:      	add	x15, x13, #0xc
    2040:      	ld1.s	{ v0 }[3], [x15]
    2044:      	tbnz	w14, #0x4, 0x2004 <_llm_rows.packet_batch.blocks+0x1b20>
    2048:      	tbz	w14, #0x5, 0x2010 <_llm_rows.packet_batch.blocks+0x1b2c>
    204c:      	add	x15, x13, #0x14
    2050:      	ld1.s	{ v19 }[1], [x15]
    2054:      	tbnz	w14, #0x6, 0x2014 <_llm_rows.packet_batch.blocks+0x1b30>
    2058:      	tbz	w14, #0x7, 0x2064 <_llm_rows.packet_batch.blocks+0x1b80>
    205c:      	add	x13, x13, #0x1c
    2060:      	ld1.s	{ v19 }[3], [x13]
    2064:      	umull.2d	v23, v6, v10
    2068:      	xtn.4h	v20, v27
    206c:      	uzp1.8b	v20, v20, v0
    2070:      	str	q0, [sp, #0x810]
    2074:      	str	q19, [sp, #0x820]
    2078:      	movi.2d	v21, #0000000000000000
    207c:      	mov.b	v21[0], v20[0]
    2080:      	adrp	x13, 0x2000 <_llm_rows.packet_batch.blocks+0x1b1c>
    2084:      	ldr	d26, [x13]
    2088:      	and.8b	v0, v21, v26
    208c:      	addv.8b	b0, v0
    2090:      	fmov	w0, s0
    2094:      	umaxv.8b	b0, v21
    2098:      	fmov	w15, s0
    209c:      	rbit	w13, w0
    20a0:      	clz	w13, w13
    20a4:      	tst	w15, #0x1
    20a8:      	csel	w13, w13, wzr, ne
    20ac:      	dup.2d	v11, x16
    20b0:      	orr.16b	v30, v16, v11
    20b4:      	add.2d	v0, v23, v30
    20b8:      	movi.2d	v19, #0000000000000000
    20bc:      	mov.b	v19[0], v20[0]
    20c0:      	ushll.2d	v19, v19, #0x0
    20c4:      	shl.2d	v19, v19, #0x3f
    20c8:      	cmlt.2d	v19, v19, #0
    20cc:      	and.16b	v0, v19, v0
    20d0:      	movi.2d	v19, #0000000000000000
    20d4:      	str	q19, [sp, #0x5b0]
    20d8:      	str	q19, [sp, #0x5a0]
    20dc:      	str	q19, [sp, #0x590]
    20e0:      	str	q0, [sp, #0x580]
    20e4:      	and	x14, x13, #0x7
    20e8:      	add	x16, sp, #0x580
    20ec:      	ldr	x14, [x16, x14, lsl #3]
    20f0:      	sub	x14, x14, x13
    20f4:      	add	x14, x11, x14, lsl #2
    20f8:      	movi.2d	v0, #0000000000000000
    20fc:      	tbz	w15, #0x0, 0x213c <_llm_rows.packet_batch.blocks+0x1c58>
    2100:      	ldr	s0, [x14]
    2104:      	tbnz	w0, #0x1, 0x2140 <_llm_rows.packet_batch.blocks+0x1c5c>
    2108:      	tbz	w0, #0x2, 0x214c <_llm_rows.packet_batch.blocks+0x1c68>
    210c:      	add	x15, x14, #0x8
    2110:      	ld1.s	{ v0 }[2], [x15]
    2114:      	tbnz	w0, #0x3, 0x2150 <_llm_rows.packet_batch.blocks+0x1c6c>
    2118:      	tbz	w0, #0x4, 0x215c <_llm_rows.packet_batch.blocks+0x1c78>
    211c:      	add	x15, x14, #0x10
    2120:      	ld1.s	{ v19 }[0], [x15]
    2124:      	tbnz	w0, #0x5, 0x2160 <_llm_rows.packet_batch.blocks+0x1c7c>
    2128:      	tbz	w0, #0x6, 0x216c <_llm_rows.packet_batch.blocks+0x1c88>
    212c:      	add	x15, x14, #0x18
    2130:      	ld1.s	{ v19 }[2], [x15]
    2134:      	tbnz	w0, #0x7, 0x2170 <_llm_rows.packet_batch.blocks+0x1c8c>
    2138:      	b	0x2178 <_llm_rows.packet_batch.blocks+0x1c94>
    213c:      	tbz	w0, #0x1, 0x2108 <_llm_rows.packet_batch.blocks+0x1c24>
    2140:      	add	x15, x14, #0x4
    2144:      	ld1.s	{ v0 }[1], [x15]
    2148:      	tbnz	w0, #0x2, 0x210c <_llm_rows.packet_batch.blocks+0x1c28>
    214c:      	tbz	w0, #0x3, 0x2118 <_llm_rows.packet_batch.blocks+0x1c34>
    2150:      	add	x15, x14, #0xc
    2154:      	ld1.s	{ v0 }[3], [x15]
    2158:      	tbnz	w0, #0x4, 0x211c <_llm_rows.packet_batch.blocks+0x1c38>
    215c:      	tbz	w0, #0x5, 0x2128 <_llm_rows.packet_batch.blocks+0x1c44>
    2160:      	add	x15, x14, #0x14
    2164:      	ld1.s	{ v19 }[1], [x15]
    2168:      	tbnz	w0, #0x6, 0x212c <_llm_rows.packet_batch.blocks+0x1c48>
    216c:      	tbz	w0, #0x7, 0x2178 <_llm_rows.packet_batch.blocks+0x1c94>
    2170:      	add	x14, x14, #0x1c
    2174:      	ld1.s	{ v19 }[3], [x14]
    2178:      	fmov	w15, s18
    217c:      	adrp	x14, 0x2000 <_llm_rows.packet_batch.blocks+0x1b1c>
    2180:      	ldr	q20, [x14]
    2184:      	adrp	x14, 0x2000 <_llm_rows.packet_batch.blocks+0x1b1c>
    2188:      	ldr	q22, [x14]
    218c:      	str	q20, [sp, #0x560]
    2190:      	str	q22, [sp, #0x550]
    2194:      	adrp	x14, 0x2000 <_llm_rows.packet_batch.blocks+0x1b1c>
    2198:      	ldr	q20, [x14]
    219c:      	adrp	x14, 0x2000 <_llm_rows.packet_batch.blocks+0x1b1c>
    21a0:      	ldr	q22, [x14]
    21a4:      	str	q20, [sp, #0x540]
    21a8:      	str	q22, [sp, #0x530]
    21ac:      	and	x14, x13, #0x7
    21b0:      	add	x16, sp, #0x530
    21b4:      	ldr	x14, [x16, x14, lsl #3]
    21b8:      	lsl	x3, x13, #2
    21bc:      	sub	x14, x14, x3
    21c0:      	tst	w0, #0xff
    21c4:      	csel	x6, xzr, x14, eq
    21c8:      	add	x14, x1, x6
    21cc:      	ldp	q20, q22, [x14]
    21d0:      	zip2.8b	v24, v21, v0
    21d4:      	ushll.4s	v24, v24, #0x0
    21d8:      	shl.4s	v24, v24, #0x1f
    21dc:      	cmlt.4s	v24, v24, #0
    21e0:      	bif.16b	v19, v22, v24
    21e4:      	zip1.8b	v22, v21, v0
    21e8:      	ushll.4s	v22, v22, #0x0
    21ec:      	shl.4s	v22, v22, #0x1f
    21f0:      	cmlt.4s	v22, v22, #0
    21f4:      	bif.16b	v0, v20, v22
    21f8:      	stp	q0, q19, [x14]
    21fc:      	add	x1, x5, #0x84
    2200:      	tst	w12, #0x1
    2204:      	csel	x14, x1, x22, ne
    2208:      	add	x14, x11, x14
    220c:      	movi.2d	v0, #0000000000000000
    2210:      	movi.2d	v19, #0000000000000000
    2214:      	tbz	w15, #0x0, 0x2258 <_llm_rows.packet_batch.blocks+0x1d74>
    2218:      	ldr	s0, [x14]
    221c:      	and	w15, w15, #0xff
    2220:      	tbnz	w15, #0x1, 0x2260 <_llm_rows.packet_batch.blocks+0x1d7c>
    2224:      	tbz	w15, #0x2, 0x226c <_llm_rows.packet_batch.blocks+0x1d88>
    2228:      	add	x16, x14, #0x8
    222c:      	ld1.s	{ v0 }[2], [x16]
    2230:      	tbnz	w15, #0x3, 0x2270 <_llm_rows.packet_batch.blocks+0x1d8c>
    2234:      	tbz	w15, #0x4, 0x227c <_llm_rows.packet_batch.blocks+0x1d98>
    2238:      	add	x16, x14, #0x10
    223c:      	ld1.s	{ v19 }[0], [x16]
    2240:      	tbnz	w15, #0x5, 0x2280 <_llm_rows.packet_batch.blocks+0x1d9c>
    2244:      	tbz	w15, #0x6, 0x228c <_llm_rows.packet_batch.blocks+0x1da8>
    2248:      	add	x16, x14, #0x18
    224c:      	ld1.s	{ v19 }[2], [x16]
    2250:      	tbnz	w15, #0x7, 0x2290 <_llm_rows.packet_batch.blocks+0x1dac>
    2254:      	b	0x2298 <_llm_rows.packet_batch.blocks+0x1db4>
    2258:      	and	w15, w15, #0xff
    225c:      	tbz	w15, #0x1, 0x2224 <_llm_rows.packet_batch.blocks+0x1d40>
    2260:      	add	x16, x14, #0x4
    2264:      	ld1.s	{ v0 }[1], [x16]
    2268:      	tbnz	w15, #0x2, 0x2228 <_llm_rows.packet_batch.blocks+0x1d44>
    226c:      	tbz	w15, #0x3, 0x2234 <_llm_rows.packet_batch.blocks+0x1d50>
    2270:      	add	x16, x14, #0xc
    2274:      	ld1.s	{ v0 }[3], [x16]
    2278:      	tbnz	w15, #0x4, 0x2238 <_llm_rows.packet_batch.blocks+0x1d54>
    227c:      	tbz	w15, #0x5, 0x2244 <_llm_rows.packet_batch.blocks+0x1d60>
    2280:      	add	x16, x14, #0x14
    2284:      	ld1.s	{ v19 }[1], [x16]
    2288:      	tbnz	w15, #0x6, 0x2248 <_llm_rows.packet_batch.blocks+0x1d64>
    228c:      	tbz	w15, #0x7, 0x2298 <_llm_rows.packet_batch.blocks+0x1db4>
    2290:      	add	x14, x14, #0x1c
    2294:      	ld1.s	{ v19 }[3], [x14]
    2298:      	fmov	w15, s18
    229c:      	str	q0, [sp, #0x710]
    22a0:      	str	q19, [sp, #0x720]
    22a4:      	add	x2, x5, #0xa4
    22a8:      	tst	w12, #0x1
    22ac:      	csel	x14, x2, x22, ne
    22b0:      	add	x14, x11, x14
    22b4:      	movi.2d	v0, #0000000000000000
    22b8:      	movi.2d	v19, #0000000000000000
    22bc:      	tbz	w15, #0x0, 0x2300 <_llm_rows.packet_batch.blocks+0x1e1c>
    22c0:      	ldr	s0, [x14]
    22c4:      	and	w15, w15, #0xff
    22c8:      	tbnz	w15, #0x1, 0x2308 <_llm_rows.packet_batch.blocks+0x1e24>
    22cc:      	tbz	w15, #0x2, 0x2314 <_llm_rows.packet_batch.blocks+0x1e30>
    22d0:      	add	x16, x14, #0x8
    22d4:      	ld1.s	{ v0 }[2], [x16]
    22d8:      	tbnz	w15, #0x3, 0x2318 <_llm_rows.packet_batch.blocks+0x1e34>
    22dc:      	tbz	w15, #0x4, 0x2324 <_llm_rows.packet_batch.blocks+0x1e40>
    22e0:      	add	x16, x14, #0x10
    22e4:      	ld1.s	{ v19 }[0], [x16]
    22e8:      	tbnz	w15, #0x5, 0x2328 <_llm_rows.packet_batch.blocks+0x1e44>
    22ec:      	tbz	w15, #0x6, 0x2334 <_llm_rows.packet_batch.blocks+0x1e50>
    22f0:      	add	x16, x14, #0x18
    22f4:      	ld1.s	{ v19 }[2], [x16]
    22f8:      	tbnz	w15, #0x7, 0x2338 <_llm_rows.packet_batch.blocks+0x1e54>
    22fc:      	b	0x2340 <_llm_rows.packet_batch.blocks+0x1e5c>
    2300:      	and	w15, w15, #0xff
    2304:      	tbz	w15, #0x1, 0x22cc <_llm_rows.packet_batch.blocks+0x1de8>
    2308:      	add	x16, x14, #0x4
    230c:      	ld1.s	{ v0 }[1], [x16]
    2310:      	tbnz	w15, #0x2, 0x22d0 <_llm_rows.packet_batch.blocks+0x1dec>
    2314:      	tbz	w15, #0x3, 0x22dc <_llm_rows.packet_batch.blocks+0x1df8>
    2318:      	add	x16, x14, #0xc
    231c:      	ld1.s	{ v0 }[3], [x16]
    2320:      	tbnz	w15, #0x4, 0x22e0 <_llm_rows.packet_batch.blocks+0x1dfc>
    2324:      	tbz	w15, #0x5, 0x22ec <_llm_rows.packet_batch.blocks+0x1e08>
    2328:      	add	x16, x14, #0x14
    232c:      	ld1.s	{ v19 }[1], [x16]
    2330:      	tbnz	w15, #0x6, 0x22f0 <_llm_rows.packet_batch.blocks+0x1e0c>
    2334:      	tbz	w15, #0x7, 0x2340 <_llm_rows.packet_batch.blocks+0x1e5c>
    2338:      	add	x14, x14, #0x1c
    233c:      	ld1.s	{ v19 }[3], [x14]
    2340:      	fmov	w15, s18
    2344:      	str	q0, [sp, #0x730]
    2348:      	str	q19, [sp, #0x740]
    234c:      	add	x4, x5, #0xc4
    2350:      	tst	w12, #0x1
    2354:      	csel	x14, x4, x22, ne
    2358:      	add	x14, x11, x14
    235c:      	movi.2d	v0, #0000000000000000
    2360:      	movi.2d	v19, #0000000000000000
    2364:      	tbz	w15, #0x0, 0x23a8 <_llm_rows.packet_batch.blocks+0x1ec4>
    2368:      	ldr	s0, [x14]
    236c:      	and	w15, w15, #0xff
    2370:      	tbnz	w15, #0x1, 0x23b0 <_llm_rows.packet_batch.blocks+0x1ecc>
    2374:      	tbz	w15, #0x2, 0x23bc <_llm_rows.packet_batch.blocks+0x1ed8>
    2378:      	add	x16, x14, #0x8
    237c:      	ld1.s	{ v0 }[2], [x16]
    2380:      	tbnz	w15, #0x3, 0x23c0 <_llm_rows.packet_batch.blocks+0x1edc>
    2384:      	tbz	w15, #0x4, 0x23cc <_llm_rows.packet_batch.blocks+0x1ee8>
    2388:      	add	x16, x14, #0x10
    238c:      	ld1.s	{ v19 }[0], [x16]
    2390:      	tbnz	w15, #0x5, 0x23d0 <_llm_rows.packet_batch.blocks+0x1eec>
    2394:      	tbz	w15, #0x6, 0x23dc <_llm_rows.packet_batch.blocks+0x1ef8>
    2398:      	add	x16, x14, #0x18
    239c:      	ld1.s	{ v19 }[2], [x16]
    23a0:      	tbnz	w15, #0x7, 0x23e0 <_llm_rows.packet_batch.blocks+0x1efc>
    23a4:      	b	0x23e8 <_llm_rows.packet_batch.blocks+0x1f04>
    23a8:      	and	w15, w15, #0xff
    23ac:      	tbz	w15, #0x1, 0x2374 <_llm_rows.packet_batch.blocks+0x1e90>
    23b0:      	add	x16, x14, #0x4
    23b4:      	ld1.s	{ v0 }[1], [x16]
    23b8:      	tbnz	w15, #0x2, 0x2378 <_llm_rows.packet_batch.blocks+0x1e94>
    23bc:      	tbz	w15, #0x3, 0x2384 <_llm_rows.packet_batch.blocks+0x1ea0>
    23c0:      	add	x16, x14, #0xc
    23c4:      	ld1.s	{ v0 }[3], [x16]
    23c8:      	tbnz	w15, #0x4, 0x2388 <_llm_rows.packet_batch.blocks+0x1ea4>
    23cc:      	tbz	w15, #0x5, 0x2394 <_llm_rows.packet_batch.blocks+0x1eb0>
    23d0:      	add	x16, x14, #0x14
    23d4:      	ld1.s	{ v19 }[1], [x16]
    23d8:      	tbnz	w15, #0x6, 0x2398 <_llm_rows.packet_batch.blocks+0x1eb4>
    23dc:      	tbz	w15, #0x7, 0x23e8 <_llm_rows.packet_batch.blocks+0x1f04>
    23e0:      	add	x14, x14, #0x1c
    23e4:      	ld1.s	{ v19 }[3], [x14]
    23e8:      	fmov	w15, s18
    23ec:      	str	q0, [sp, #0x750]
    23f0:      	str	q19, [sp, #0x760]
    23f4:      	add	x5, x5, #0xe4
    23f8:      	tst	w12, #0x1
    23fc:      	csel	x14, x5, x22, ne
    2400:      	add	x14, x11, x14
    2404:      	movi.2d	v0, #0000000000000000
    2408:      	movi.2d	v19, #0000000000000000
    240c:      	tbz	w15, #0x0, 0x2458 <_llm_rows.packet_batch.blocks+0x1f74>
    2410:      	ldr	s0, [x14]
    2414:      	and	w15, w15, #0xff
    2418:      	add	x22, sp, #0x710
    241c:      	tbnz	w15, #0x1, 0x2464 <_llm_rows.packet_batch.blocks+0x1f80>
    2420:      	tbz	w15, #0x2, 0x2470 <_llm_rows.packet_batch.blocks+0x1f8c>
    2424:      	add	x16, x14, #0x8
    2428:      	ld1.s	{ v0 }[2], [x16]
    242c:      	tbnz	w15, #0x3, 0x2474 <_llm_rows.packet_batch.blocks+0x1f90>
    2430:      	tbz	w15, #0x4, 0x2480 <_llm_rows.packet_batch.blocks+0x1f9c>
    2434:      	add	x16, x14, #0x10
    2438:      	ld1.s	{ v19 }[0], [x16]
    243c:      	tbnz	w15, #0x5, 0x2484 <_llm_rows.packet_batch.blocks+0x1fa0>
    2440:      	tbz	w15, #0x6, 0x2490 <_llm_rows.packet_batch.blocks+0x1fac>
    2444:      	add	x16, x14, #0x18
    2448:      	ld1.s	{ v19 }[2], [x16]
    244c:      	str	q18, [sp, #0x210]
    2450:      	tbnz	w15, #0x7, 0x2498 <_llm_rows.packet_batch.blocks+0x1fb4>
    2454:      	b	0x24a0 <_llm_rows.packet_batch.blocks+0x1fbc>
    2458:      	and	w15, w15, #0xff
    245c:      	add	x22, sp, #0x710
    2460:      	tbz	w15, #0x1, 0x2420 <_llm_rows.packet_batch.blocks+0x1f3c>
    2464:      	add	x16, x14, #0x4
    2468:      	ld1.s	{ v0 }[1], [x16]
    246c:      	tbnz	w15, #0x2, 0x2424 <_llm_rows.packet_batch.blocks+0x1f40>
    2470:      	tbz	w15, #0x3, 0x2430 <_llm_rows.packet_batch.blocks+0x1f4c>
    2474:      	add	x16, x14, #0xc
    2478:      	ld1.s	{ v0 }[3], [x16]
    247c:      	tbnz	w15, #0x4, 0x2434 <_llm_rows.packet_batch.blocks+0x1f50>
    2480:      	tbz	w15, #0x5, 0x2440 <_llm_rows.packet_batch.blocks+0x1f5c>
    2484:      	add	x16, x14, #0x14
    2488:      	ld1.s	{ v19 }[1], [x16]
    248c:      	tbnz	w15, #0x6, 0x2444 <_llm_rows.packet_batch.blocks+0x1f60>
    2490:      	str	q18, [sp, #0x210]
    2494:      	tbz	w15, #0x7, 0x24a0 <_llm_rows.packet_batch.blocks+0x1fbc>
    2498:      	add	x14, x14, #0x1c
    249c:      	ld1.s	{ v19 }[3], [x14]
    24a0:      	sshll.2d	v29, v27, #0x0
    24a4:      	sshll.2d	v28, v17, #0x0
    24a8:      	umull.2d	v20, v7, v10
    24ac:      	umull.2d	v22, v5, v10
    24b0:      	umull.2d	v24, v4, v10
    24b4:      	and.16b	v15, v25, v24
    24b8:      	mov.16b	v24, v28
    24bc:      	and.16b	v28, v28, v22
    24c0:      	str	q29, [sp, #0x120]
    24c4:      	and.16b	v23, v29, v23
    24c8:      	and.16b	v29, v8, v20
    24cc:      	ldr	q20, [sp, #0x770]
    24d0:      	ldr	q22, [sp, #0x780]
    24d4:      	bif.16b	v19, v22, v17
    24d8:      	bif.16b	v0, v20, v27
    24dc:      	str	q0, [sp, #0x770]
    24e0:      	str	q19, [sp, #0x780]
    24e4:      	stp	q28, q23, [sp, #0x140]
    24e8:      	add.2d	v0, v16, v23
    24ec:      	add.2d	v16, v2, v15
    24f0:      	add.2d	v19, v3, v28
    24f4:      	str	q29, [sp, #0x130]
    24f8:      	add.2d	v20, v1, v29
    24fc:      	mov	w14, #0x41              ; =65
    2500:      	dup.2d	v22, x14
    2504:      	add.2d	v23, v20, v22
    2508:      	add.2d	v20, v19, v22
    250c:      	add.2d	v19, v16, v22
    2510:      	mov	b16, v21[0]
    2514:      	mov.b	v16[4], v21[1]
    2518:      	add.2d	v22, v0, v22
    251c:      	ushll.2d	v0, v16, #0x0
    2520:      	shl.2d	v0, v0, #0x3f
    2524:      	cmlt.2d	v0, v0, #0
    2528:      	stp	q22, q19, [sp, #0x160]
    252c:      	and.16b	v0, v0, v22
    2530:      	mov	b16, v21[2]
    2534:      	mov.b	v16[4], v21[3]
    2538:      	ushll.2d	v16, v16, #0x0
    253c:      	shl.2d	v16, v16, #0x3f
    2540:      	cmlt.2d	v16, v16, #0
    2544:      	and.16b	v16, v16, v19
    2548:      	mov	b19, v21[4]
    254c:      	mov.b	v19[4], v21[5]
    2550:      	ushll.2d	v19, v19, #0x0
    2554:      	shl.2d	v19, v19, #0x3f
    2558:      	cmlt.2d	v19, v19, #0
    255c:      	stp	q20, q23, [sp, #0x180]
    2560:      	and.16b	v19, v19, v20
    2564:      	mov	b20, v21[6]
    2568:      	mov.b	v20[4], v21[7]
    256c:      	ushll.2d	v20, v20, #0x0
    2570:      	shl.2d	v20, v20, #0x3f
    2574:      	cmlt.2d	v20, v20, #0
    2578:      	and.16b	v20, v20, v23
    257c:      	shl.8b	v22, v21, #0x7
    2580:      	cmlt.8b	v22, v22, #0
    2584:      	and.8b	v22, v22, v26
    2588:      	addv.8b	b23, v22
    258c:      	fmov	w14, s23
    2590:      	str	q20, [sp, #0x510]
    2594:      	str	q19, [sp, #0x500]
    2598:      	str	q16, [sp, #0x4f0]
    259c:      	str	q0, [sp, #0x4e0]
    25a0:      	and	x15, x13, #0x7
    25a4:      	add	x16, sp, #0x4e0
    25a8:      	ldr	x15, [x16, x15, lsl #3]
    25ac:      	sub	x15, x15, x13
    25b0:      	add	x11, x11, x15, lsl #2
    25b4:      	movi.2d	v0, #0000000000000000
    25b8:      	movi.2d	v16, #0000000000000000
    25bc:      	tbz	w14, #0x0, 0x2600 <_llm_rows.packet_batch.blocks+0x211c>
    25c0:      	ldr	s0, [x11]
    25c4:      	ldr	q28, [sp, #0x210]
    25c8:      	tbnz	w14, #0x1, 0x2608 <_llm_rows.packet_batch.blocks+0x2124>
    25cc:      	tbz	w14, #0x2, 0x2614 <_llm_rows.packet_batch.blocks+0x2130>
    25d0:      	add	x15, x11, #0x8
    25d4:      	ld1.s	{ v0 }[2], [x15]
    25d8:      	tbnz	w14, #0x3, 0x2618 <_llm_rows.packet_batch.blocks+0x2134>
    25dc:      	tbz	w14, #0x4, 0x2624 <_llm_rows.packet_batch.blocks+0x2140>
    25e0:      	add	x15, x11, #0x10
    25e4:      	ld1.s	{ v16 }[0], [x15]
    25e8:      	tbnz	w14, #0x5, 0x2628 <_llm_rows.packet_batch.blocks+0x2144>
    25ec:      	tbz	w14, #0x6, 0x2634 <_llm_rows.packet_batch.blocks+0x2150>
    25f0:      	add	x15, x11, #0x18
    25f4:      	ld1.s	{ v16 }[2], [x15]
    25f8:      	tbnz	w14, #0x7, 0x2638 <_llm_rows.packet_batch.blocks+0x2154>
    25fc:      	b	0x2640 <_llm_rows.packet_batch.blocks+0x215c>
    2600:      	ldr	q28, [sp, #0x210]
    2604:      	tbz	w14, #0x1, 0x25cc <_llm_rows.packet_batch.blocks+0x20e8>
    2608:      	add	x15, x11, #0x4
    260c:      	ld1.s	{ v0 }[1], [x15]
    2610:      	tbnz	w14, #0x2, 0x25d0 <_llm_rows.packet_batch.blocks+0x20ec>
    2614:      	tbz	w14, #0x3, 0x25dc <_llm_rows.packet_batch.blocks+0x20f8>
    2618:      	add	x15, x11, #0xc
    261c:      	ld1.s	{ v0 }[3], [x15]
    2620:      	tbnz	w14, #0x4, 0x25e0 <_llm_rows.packet_batch.blocks+0x20fc>
    2624:      	tbz	w14, #0x5, 0x25ec <_llm_rows.packet_batch.blocks+0x2108>
    2628:      	add	x15, x11, #0x14
    262c:      	ld1.s	{ v16 }[1], [x15]
    2630:      	tbnz	w14, #0x6, 0x25f0 <_llm_rows.packet_batch.blocks+0x210c>
    2634:      	tbz	w14, #0x7, 0x2640 <_llm_rows.packet_batch.blocks+0x215c>
    2638:      	add	x11, x11, #0x1c
    263c:      	ld1.s	{ v16 }[3], [x11]
    2640:      	fmov	w16, s28
    2644:      	add	x11, x22, x6
    2648:      	ldp	q19, q20, [x11]
    264c:      	zip2.8b	v22, v21, v0
    2650:      	ushll.4s	v22, v22, #0x0
    2654:      	shl.4s	v22, v22, #0x1f
    2658:      	cmlt.4s	v22, v22, #0
    265c:      	bif.16b	v16, v20, v22
    2660:      	zip1.8b	v20, v21, v0
    2664:      	ushll.4s	v20, v20, #0x0
    2668:      	shl.4s	v20, v20, #0x1f
    266c:      	cmlt.4s	v20, v20, #0
    2670:      	bif.16b	v0, v19, v20
    2674:      	stp	q0, q16, [x11]
    2678:      	lsl	x14, x7, #2
    267c:      	tst	w12, #0x1
    2680:      	csel	x11, x14, xzr, ne
    2684:      	add	x15, x10, x11
    2688:      	movi.2d	v0, #0000000000000000
    268c:      	movi.2d	v16, #0000000000000000
    2690:      	tbz	w16, #0x0, 0x26d4 <_llm_rows.packet_batch.blocks+0x21f0>
    2694:      	ldr	s0, [x15]
    2698:      	and	w16, w16, #0xff
    269c:      	tbnz	w16, #0x1, 0x26dc <_llm_rows.packet_batch.blocks+0x21f8>
    26a0:      	tbz	w16, #0x2, 0x26e8 <_llm_rows.packet_batch.blocks+0x2204>
    26a4:      	add	x7, x15, #0x8
    26a8:      	ld1.s	{ v0 }[2], [x7]
    26ac:      	tbnz	w16, #0x3, 0x26ec <_llm_rows.packet_batch.blocks+0x2208>
    26b0:      	tbz	w16, #0x4, 0x26f8 <_llm_rows.packet_batch.blocks+0x2214>
    26b4:      	add	x7, x15, #0x10
    26b8:      	ld1.s	{ v16 }[0], [x7]
    26bc:      	tbnz	w16, #0x5, 0x26fc <_llm_rows.packet_batch.blocks+0x2218>
    26c0:      	tbz	w16, #0x6, 0x2708 <_llm_rows.packet_batch.blocks+0x2224>
    26c4:      	add	x7, x15, #0x18
    26c8:      	ld1.s	{ v16 }[2], [x7]
    26cc:      	tbnz	w16, #0x7, 0x270c <_llm_rows.packet_batch.blocks+0x2228>
    26d0:      	b	0x2714 <_llm_rows.packet_batch.blocks+0x2230>
    26d4:      	and	w16, w16, #0xff
    26d8:      	tbz	w16, #0x1, 0x26a0 <_llm_rows.packet_batch.blocks+0x21bc>
    26dc:      	add	x7, x15, #0x4
    26e0:      	ld1.s	{ v0 }[1], [x7]
    26e4:      	tbnz	w16, #0x2, 0x26a4 <_llm_rows.packet_batch.blocks+0x21c0>
    26e8:      	tbz	w16, #0x3, 0x26b0 <_llm_rows.packet_batch.blocks+0x21cc>
    26ec:      	add	x7, x15, #0xc
    26f0:      	ld1.s	{ v0 }[3], [x7]
    26f4:      	tbnz	w16, #0x4, 0x26b4 <_llm_rows.packet_batch.blocks+0x21d0>
    26f8:      	tbz	w16, #0x5, 0x26c0 <_llm_rows.packet_batch.blocks+0x21dc>
    26fc:      	add	x7, x15, #0x14
    2700:      	ld1.s	{ v16 }[1], [x7]
    2704:      	tbnz	w16, #0x6, 0x26c4 <_llm_rows.packet_batch.blocks+0x21e0>
    2708:      	tbz	w16, #0x7, 0x2714 <_llm_rows.packet_batch.blocks+0x2230>
    270c:      	add	x15, x15, #0x1c
    2710:      	ld1.s	{ v16 }[3], [x15]
    2714:      	fmov	w16, s28
    2718:      	ldr	q19, [sp, #0x670]
    271c:      	ldr	q20, [sp, #0x680]
    2720:      	bif.16b	v16, v20, v17
    2724:      	bif.16b	v0, v19, v27
    2728:      	str	q0, [sp, #0x670]
    272c:      	str	q16, [sp, #0x680]
    2730:      	add	x15, x14, #0x20
    2734:      	tst	w12, #0x1
    2738:      	csel	x7, x15, xzr, ne
    273c:      	add	x15, x10, x7
    2740:      	movi.2d	v0, #0000000000000000
    2744:      	movi.2d	v16, #0000000000000000
    2748:      	tbz	w16, #0x0, 0x278c <_llm_rows.packet_batch.blocks+0x22a8>
    274c:      	ldr	s0, [x15]
    2750:      	and	w16, w16, #0xff
    2754:      	tbnz	w16, #0x1, 0x2794 <_llm_rows.packet_batch.blocks+0x22b0>
    2758:      	tbz	w16, #0x2, 0x27a0 <_llm_rows.packet_batch.blocks+0x22bc>
    275c:      	add	x22, x15, #0x8
    2760:      	ld1.s	{ v0 }[2], [x22]
    2764:      	tbnz	w16, #0x3, 0x27a4 <_llm_rows.packet_batch.blocks+0x22c0>
    2768:      	tbz	w16, #0x4, 0x27b0 <_llm_rows.packet_batch.blocks+0x22cc>
    276c:      	add	x22, x15, #0x10
    2770:      	ld1.s	{ v16 }[0], [x22]
    2774:      	tbnz	w16, #0x5, 0x27b4 <_llm_rows.packet_batch.blocks+0x22d0>
    2778:      	tbz	w16, #0x6, 0x27c0 <_llm_rows.packet_batch.blocks+0x22dc>
    277c:      	add	x22, x15, #0x18
    2780:      	ld1.s	{ v16 }[2], [x22]
    2784:      	tbnz	w16, #0x7, 0x27c4 <_llm_rows.packet_batch.blocks+0x22e0>
    2788:      	b	0x27cc <_llm_rows.packet_batch.blocks+0x22e8>
    278c:      	and	w16, w16, #0xff
    2790:      	tbz	w16, #0x1, 0x2758 <_llm_rows.packet_batch.blocks+0x2274>
    2794:      	add	x22, x15, #0x4
    2798:      	ld1.s	{ v0 }[1], [x22]
    279c:      	tbnz	w16, #0x2, 0x275c <_llm_rows.packet_batch.blocks+0x2278>
    27a0:      	tbz	w16, #0x3, 0x2768 <_llm_rows.packet_batch.blocks+0x2284>
    27a4:      	add	x22, x15, #0xc
    27a8:      	ld1.s	{ v0 }[3], [x22]
    27ac:      	tbnz	w16, #0x4, 0x276c <_llm_rows.packet_batch.blocks+0x2288>
    27b0:      	tbz	w16, #0x5, 0x2778 <_llm_rows.packet_batch.blocks+0x2294>
    27b4:      	add	x22, x15, #0x14
    27b8:      	ld1.s	{ v16 }[1], [x22]
    27bc:      	tbnz	w16, #0x6, 0x277c <_llm_rows.packet_batch.blocks+0x2298>
    27c0:      	tbz	w16, #0x7, 0x27cc <_llm_rows.packet_batch.blocks+0x22e8>
    27c4:      	add	x15, x15, #0x1c
    27c8:      	ld1.s	{ v16 }[3], [x15]
    27cc:      	fmov	w16, s28
    27d0:      	ldr	q19, [sp, #0x690]
    27d4:      	ldr	q20, [sp, #0x6a0]
    27d8:      	bif.16b	v16, v20, v17
    27dc:      	bif.16b	v0, v19, v27
    27e0:      	str	q0, [sp, #0x690]
    27e4:      	str	q16, [sp, #0x6a0]
    27e8:      	add	x15, x14, #0x40
    27ec:      	tst	w12, #0x1
    27f0:      	csel	x30, x15, xzr, ne
    27f4:      	add	x15, x10, x30
    27f8:      	movi.2d	v0, #0000000000000000
    27fc:      	movi.2d	v16, #0000000000000000
    2800:      	tbz	w16, #0x0, 0x2844 <_llm_rows.packet_batch.blocks+0x2360>
    2804:      	ldr	s0, [x15]
    2808:      	and	w16, w16, #0xff
    280c:      	tbnz	w16, #0x1, 0x284c <_llm_rows.packet_batch.blocks+0x2368>
    2810:      	tbz	w16, #0x2, 0x2858 <_llm_rows.packet_batch.blocks+0x2374>
    2814:      	add	x22, x15, #0x8
    2818:      	ld1.s	{ v0 }[2], [x22]
    281c:      	tbnz	w16, #0x3, 0x285c <_llm_rows.packet_batch.blocks+0x2378>
    2820:      	tbz	w16, #0x4, 0x2868 <_llm_rows.packet_batch.blocks+0x2384>
    2824:      	add	x22, x15, #0x10
    2828:      	ld1.s	{ v16 }[0], [x22]
    282c:      	tbnz	w16, #0x5, 0x286c <_llm_rows.packet_batch.blocks+0x2388>
    2830:      	tbz	w16, #0x6, 0x2878 <_llm_rows.packet_batch.blocks+0x2394>
    2834:      	add	x22, x15, #0x18
    2838:      	ld1.s	{ v16 }[2], [x22]
    283c:      	tbnz	w16, #0x7, 0x287c <_llm_rows.packet_batch.blocks+0x2398>
    2840:      	b	0x2884 <_llm_rows.packet_batch.blocks+0x23a0>
    2844:      	and	w16, w16, #0xff
    2848:      	tbz	w16, #0x1, 0x2810 <_llm_rows.packet_batch.blocks+0x232c>
    284c:      	add	x22, x15, #0x4
    2850:      	ld1.s	{ v0 }[1], [x22]
    2854:      	tbnz	w16, #0x2, 0x2814 <_llm_rows.packet_batch.blocks+0x2330>
    2858:      	tbz	w16, #0x3, 0x2820 <_llm_rows.packet_batch.blocks+0x233c>
    285c:      	add	x22, x15, #0xc
    2860:      	ld1.s	{ v0 }[3], [x22]
    2864:      	tbnz	w16, #0x4, 0x2824 <_llm_rows.packet_batch.blocks+0x2340>
    2868:      	tbz	w16, #0x5, 0x2830 <_llm_rows.packet_batch.blocks+0x234c>
    286c:      	add	x22, x15, #0x14
    2870:      	ld1.s	{ v16 }[1], [x22]
    2874:      	tbnz	w16, #0x6, 0x2834 <_llm_rows.packet_batch.blocks+0x2350>
    2878:      	tbz	w16, #0x7, 0x2884 <_llm_rows.packet_batch.blocks+0x23a0>
    287c:      	add	x15, x15, #0x1c
    2880:      	ld1.s	{ v16 }[3], [x15]
    2884:      	fmov	w16, s28
    2888:      	ldr	q19, [sp, #0x6b0]
    288c:      	ldr	q20, [sp, #0x6c0]
    2890:      	bif.16b	v16, v20, v17
    2894:      	bif.16b	v0, v19, v27
    2898:      	str	q0, [sp, #0x6b0]
    289c:      	str	q16, [sp, #0x6c0]
    28a0:      	add	x14, x14, #0x60
    28a4:      	tst	w12, #0x1
    28a8:      	csel	x14, x14, xzr, ne
    28ac:      	add	x15, x10, x14
    28b0:      	movi.2d	v0, #0000000000000000
    28b4:      	movi.2d	v16, #0000000000000000
    28b8:      	tbz	w16, #0x0, 0x28fc <_llm_rows.packet_batch.blocks+0x2418>
    28bc:      	ldr	s0, [x15]
    28c0:      	and	w16, w16, #0xff
    28c4:      	tbnz	w16, #0x1, 0x2904 <_llm_rows.packet_batch.blocks+0x2420>
    28c8:      	tbz	w16, #0x2, 0x2910 <_llm_rows.packet_batch.blocks+0x242c>
    28cc:      	add	x22, x15, #0x8
    28d0:      	ld1.s	{ v0 }[2], [x22]
    28d4:      	tbnz	w16, #0x3, 0x2914 <_llm_rows.packet_batch.blocks+0x2430>
    28d8:      	tbz	w16, #0x4, 0x2920 <_llm_rows.packet_batch.blocks+0x243c>
    28dc:      	add	x22, x15, #0x10
    28e0:      	ld1.s	{ v16 }[0], [x22]
    28e4:      	tbnz	w16, #0x5, 0x2924 <_llm_rows.packet_batch.blocks+0x2440>
    28e8:      	tbz	w16, #0x6, 0x2930 <_llm_rows.packet_batch.blocks+0x244c>
    28ec:      	add	x22, x15, #0x18
    28f0:      	ld1.s	{ v16 }[2], [x22]
    28f4:      	tbnz	w16, #0x7, 0x2934 <_llm_rows.packet_batch.blocks+0x2450>
    28f8:      	b	0x293c <_llm_rows.packet_batch.blocks+0x2458>
    28fc:      	and	w16, w16, #0xff
    2900:      	tbz	w16, #0x1, 0x28c8 <_llm_rows.packet_batch.blocks+0x23e4>
    2904:      	add	x22, x15, #0x4
    2908:      	ld1.s	{ v0 }[1], [x22]
    290c:      	tbnz	w16, #0x2, 0x28cc <_llm_rows.packet_batch.blocks+0x23e8>
    2910:      	tbz	w16, #0x3, 0x28d8 <_llm_rows.packet_batch.blocks+0x23f4>
    2914:      	add	x22, x15, #0xc
    2918:      	ld1.s	{ v0 }[3], [x22]
    291c:      	tbnz	w16, #0x4, 0x28dc <_llm_rows.packet_batch.blocks+0x23f8>
    2920:      	tbz	w16, #0x5, 0x28e8 <_llm_rows.packet_batch.blocks+0x2404>
    2924:      	add	x22, x15, #0x14
    2928:      	ld1.s	{ v16 }[1], [x22]
    292c:      	tbnz	w16, #0x6, 0x28ec <_llm_rows.packet_batch.blocks+0x2408>
    2930:      	tbz	w16, #0x7, 0x293c <_llm_rows.packet_batch.blocks+0x2458>
    2934:      	add	x15, x15, #0x1c
    2938:      	ld1.s	{ v16 }[3], [x15]
    293c:      	orr.16b	v20, v3, v11
    2940:      	orr.16b	v19, v2, v11
    2944:      	orr.16b	v1, v1, v11
    2948:      	sshll.2d	v2, v27, #0x0
    294c:      	sshll.2d	v3, v17, #0x0
    2950:      	umull.2d	v7, v7, v12
    2954:      	umull.2d	v6, v6, v12
    2958:      	umull.2d	v5, v5, v12
    295c:      	umull.2d	v4, v4, v12
    2960:      	and.16b	v4, v25, v4
    2964:      	and.16b	v3, v3, v5
    2968:      	and.16b	v2, v2, v6
    296c:      	and.16b	v5, v8, v7
    2970:      	ldr	q6, [sp, #0x6d0]
    2974:      	ldr	q7, [sp, #0x6e0]
    2978:      	bit.16b	v7, v16, v17
    297c:      	bif.16b	v0, v6, v27
    2980:      	str	q0, [sp, #0x6d0]
    2984:      	str	q7, [sp, #0x6e0]
    2988:      	add.2d	v0, v5, v1
    298c:      	mov.16b	v14, v20
    2990:      	add.2d	v3, v3, v20
    2994:      	mov.16b	v9, v19
    2998:      	add.2d	v4, v4, v19
    299c:      	add.2d	v2, v2, v30
    29a0:      	mov	b5, v21[0]
    29a4:      	mov.b	v5[4], v21[1]
    29a8:      	ushll.2d	v5, v5, #0x0
    29ac:      	shl.2d	v5, v5, #0x3f
    29b0:      	cmlt.2d	v5, v5, #0
    29b4:      	and.16b	v2, v5, v2
    29b8:      	mov	b5, v21[2]
    29bc:      	mov.b	v5[4], v21[3]
    29c0:      	ushll.2d	v5, v5, #0x0
    29c4:      	shl.2d	v5, v5, #0x3f
    29c8:      	cmlt.2d	v5, v5, #0
    29cc:      	and.16b	v4, v5, v4
    29d0:      	mov	b5, v21[4]
    29d4:      	mov.b	v5[4], v21[5]
    29d8:      	ushll.2d	v5, v5, #0x0
    29dc:      	shl.2d	v5, v5, #0x3f
    29e0:      	cmlt.2d	v5, v5, #0
    29e4:      	mov	b6, v21[6]
    29e8:      	mov.b	v6[4], v21[7]
    29ec:      	and.16b	v3, v5, v3
    29f0:      	ushll.2d	v5, v6, #0x0
    29f4:      	shl.2d	v5, v5, #0x3f
    29f8:      	cmlt.2d	v5, v5, #0
    29fc:      	and.16b	v0, v5, v0
    2a00:      	str	q0, [sp, #0x4c0]
    2a04:      	str	q3, [sp, #0x4b0]
    2a08:      	str	q4, [sp, #0x4a0]
    2a0c:      	str	q2, [sp, #0x490]
    2a10:      	and	x15, x13, #0x7
    2a14:      	add	x16, sp, #0x490
    2a18:      	ldr	x15, [x16, x15, lsl #3]
    2a1c:      	fmov	w16, s23
    2a20:      	sub	x15, x15, x13
    2a24:      	lsl	x15, x15, #2
    2a28:      	add	x10, x10, x15
    2a2c:      	movi.2d	v0, #0000000000000000
    2a30:      	movi.2d	v2, #0000000000000000
    2a34:      	tbz	w16, #0x0, 0x2a78 <_llm_rows.packet_batch.blocks+0x2594>
    2a38:      	ldr	s0, [x10]
    2a3c:      	tbnz	w16, #0x1, 0x2a7c <_llm_rows.packet_batch.blocks+0x2598>
    2a40:      	tbz	w16, #0x2, 0x2a88 <_llm_rows.packet_batch.blocks+0x25a4>
    2a44:      	add	x22, x10, #0x8
    2a48:      	ld1.s	{ v0 }[2], [x22]
    2a4c:      	tbnz	w16, #0x3, 0x2a8c <_llm_rows.packet_batch.blocks+0x25a8>
    2a50:      	tbz	w16, #0x4, 0x2a98 <_llm_rows.packet_batch.blocks+0x25b4>
    2a54:      	add	x22, x10, #0x10
    2a58:      	ld1.s	{ v2 }[0], [x22]
    2a5c:      	tbnz	w16, #0x5, 0x2a9c <_llm_rows.packet_batch.blocks+0x25b8>
    2a60:      	tbz	w16, #0x6, 0x2aa8 <_llm_rows.packet_batch.blocks+0x25c4>
    2a64:      	add	x22, x10, #0x18
    2a68:      	ld1.s	{ v2 }[2], [x22]
    2a6c:      	mov	w22, #0x20              ; =32
    2a70:      	tbnz	w16, #0x7, 0x2ab0 <_llm_rows.packet_batch.blocks+0x25cc>
    2a74:      	b	0x2ab8 <_llm_rows.packet_batch.blocks+0x25d4>
    2a78:      	tbz	w16, #0x1, 0x2a40 <_llm_rows.packet_batch.blocks+0x255c>
    2a7c:      	add	x22, x10, #0x4
    2a80:      	ld1.s	{ v0 }[1], [x22]
    2a84:      	tbnz	w16, #0x2, 0x2a44 <_llm_rows.packet_batch.blocks+0x2560>
    2a88:      	tbz	w16, #0x3, 0x2a50 <_llm_rows.packet_batch.blocks+0x256c>
    2a8c:      	add	x22, x10, #0xc
    2a90:      	ld1.s	{ v0 }[3], [x22]
    2a94:      	tbnz	w16, #0x4, 0x2a54 <_llm_rows.packet_batch.blocks+0x2570>
    2a98:      	tbz	w16, #0x5, 0x2a60 <_llm_rows.packet_batch.blocks+0x257c>
    2a9c:      	add	x22, x10, #0x14
    2aa0:      	ld1.s	{ v2 }[1], [x22]
    2aa4:      	tbnz	w16, #0x6, 0x2a64 <_llm_rows.packet_batch.blocks+0x2580>
    2aa8:      	mov	w22, #0x20              ; =32
    2aac:      	tbz	w16, #0x7, 0x2ab8 <_llm_rows.packet_batch.blocks+0x25d4>
    2ab0:      	add	x10, x10, #0x1c
    2ab4:      	ld1.s	{ v2 }[3], [x10]
    2ab8:      	fmov	w16, s28
    2abc:      	add	x10, sp, #0x670
    2ac0:      	add	x10, x10, x6
    2ac4:      	ldp	q3, q4, [x10]
    2ac8:      	zip2.8b	v5, v21, v0
    2acc:      	ushll.4s	v5, v5, #0x0
    2ad0:      	shl.4s	v5, v5, #0x1f
    2ad4:      	cmlt.4s	v5, v5, #0
    2ad8:      	bif.16b	v2, v4, v5
    2adc:      	zip1.8b	v4, v21, v0
    2ae0:      	ushll.4s	v4, v4, #0x0
    2ae4:      	shl.4s	v4, v4, #0x1f
    2ae8:      	cmlt.4s	v4, v4, #0
    2aec:      	bif.16b	v0, v3, v4
    2af0:      	stp	q0, q2, [x10]
    2af4:      	add	x10, x9, x11
    2af8:      	movi.2d	v0, #0000000000000000
    2afc:      	movi.2d	v2, #0000000000000000
    2b00:      	tbz	w16, #0x0, 0x2b44 <_llm_rows.packet_batch.blocks+0x2660>
    2b04:      	ldr	s0, [x10]
    2b08:      	and	w11, w16, #0xff
    2b0c:      	tbnz	w11, #0x1, 0x2b4c <_llm_rows.packet_batch.blocks+0x2668>
    2b10:      	tbz	w11, #0x2, 0x2b58 <_llm_rows.packet_batch.blocks+0x2674>
    2b14:      	add	x16, x10, #0x8
    2b18:      	ld1.s	{ v0 }[2], [x16]
    2b1c:      	tbnz	w11, #0x3, 0x2b5c <_llm_rows.packet_batch.blocks+0x2678>
    2b20:      	tbz	w11, #0x4, 0x2b68 <_llm_rows.packet_batch.blocks+0x2684>
    2b24:      	add	x16, x10, #0x10
    2b28:      	ld1.s	{ v2 }[0], [x16]
    2b2c:      	tbnz	w11, #0x5, 0x2b6c <_llm_rows.packet_batch.blocks+0x2688>
    2b30:      	tbz	w11, #0x6, 0x2b78 <_llm_rows.packet_batch.blocks+0x2694>
    2b34:      	add	x16, x10, #0x18
    2b38:      	ld1.s	{ v2 }[2], [x16]
    2b3c:      	tbnz	w11, #0x7, 0x2b7c <_llm_rows.packet_batch.blocks+0x2698>
    2b40:      	b	0x2b84 <_llm_rows.packet_batch.blocks+0x26a0>
    2b44:      	and	w11, w16, #0xff
    2b48:      	tbz	w11, #0x1, 0x2b10 <_llm_rows.packet_batch.blocks+0x262c>
    2b4c:      	add	x16, x10, #0x4
    2b50:      	ld1.s	{ v0 }[1], [x16]
    2b54:      	tbnz	w11, #0x2, 0x2b14 <_llm_rows.packet_batch.blocks+0x2630>
    2b58:      	tbz	w11, #0x3, 0x2b20 <_llm_rows.packet_batch.blocks+0x263c>
    2b5c:      	add	x16, x10, #0xc
    2b60:      	ld1.s	{ v0 }[3], [x16]
    2b64:      	tbnz	w11, #0x4, 0x2b24 <_llm_rows.packet_batch.blocks+0x2640>
    2b68:      	tbz	w11, #0x5, 0x2b30 <_llm_rows.packet_batch.blocks+0x264c>
    2b6c:      	add	x16, x10, #0x14
    2b70:      	ld1.s	{ v2 }[1], [x16]
    2b74:      	tbnz	w11, #0x6, 0x2b34 <_llm_rows.packet_batch.blocks+0x2650>
    2b78:      	tbz	w11, #0x7, 0x2b84 <_llm_rows.packet_batch.blocks+0x26a0>
    2b7c:      	add	x10, x10, #0x1c
    2b80:      	ld1.s	{ v2 }[3], [x10]
    2b84:      	fmov	w11, s28
    2b88:      	ldr	q3, [sp, #0x5d0]
    2b8c:      	ldr	q4, [sp, #0x5e0]
    2b90:      	bif.16b	v2, v4, v17
    2b94:      	bif.16b	v0, v3, v27
    2b98:      	str	q0, [sp, #0x5d0]
    2b9c:      	str	q2, [sp, #0x5e0]
    2ba0:      	add	x10, x9, x7
    2ba4:      	movi.2d	v0, #0000000000000000
    2ba8:      	movi.2d	v2, #0000000000000000
    2bac:      	tbz	w11, #0x0, 0x2bf0 <_llm_rows.packet_batch.blocks+0x270c>
    2bb0:      	ldr	s0, [x10]
    2bb4:      	and	w11, w11, #0xff
    2bb8:      	tbnz	w11, #0x1, 0x2bf8 <_llm_rows.packet_batch.blocks+0x2714>
    2bbc:      	tbz	w11, #0x2, 0x2c04 <_llm_rows.packet_batch.blocks+0x2720>
    2bc0:      	add	x16, x10, #0x8
    2bc4:      	ld1.s	{ v0 }[2], [x16]
    2bc8:      	tbnz	w11, #0x3, 0x2c08 <_llm_rows.packet_batch.blocks+0x2724>
    2bcc:      	tbz	w11, #0x4, 0x2c14 <_llm_rows.packet_batch.blocks+0x2730>
    2bd0:      	add	x16, x10, #0x10
    2bd4:      	ld1.s	{ v2 }[0], [x16]
    2bd8:      	tbnz	w11, #0x5, 0x2c18 <_llm_rows.packet_batch.blocks+0x2734>
    2bdc:      	tbz	w11, #0x6, 0x2c24 <_llm_rows.packet_batch.blocks+0x2740>
    2be0:      	add	x16, x10, #0x18
    2be4:      	ld1.s	{ v2 }[2], [x16]
    2be8:      	tbnz	w11, #0x7, 0x2c28 <_llm_rows.packet_batch.blocks+0x2744>
    2bec:      	b	0x2c30 <_llm_rows.packet_batch.blocks+0x274c>
    2bf0:      	and	w11, w11, #0xff
    2bf4:      	tbz	w11, #0x1, 0x2bbc <_llm_rows.packet_batch.blocks+0x26d8>
    2bf8:      	add	x16, x10, #0x4
    2bfc:      	ld1.s	{ v0 }[1], [x16]
    2c00:      	tbnz	w11, #0x2, 0x2bc0 <_llm_rows.packet_batch.blocks+0x26dc>
    2c04:      	tbz	w11, #0x3, 0x2bcc <_llm_rows.packet_batch.blocks+0x26e8>
    2c08:      	add	x16, x10, #0xc
    2c0c:      	ld1.s	{ v0 }[3], [x16]
    2c10:      	tbnz	w11, #0x4, 0x2bd0 <_llm_rows.packet_batch.blocks+0x26ec>
    2c14:      	tbz	w11, #0x5, 0x2bdc <_llm_rows.packet_batch.blocks+0x26f8>
    2c18:      	add	x16, x10, #0x14
    2c1c:      	ld1.s	{ v2 }[1], [x16]
    2c20:      	tbnz	w11, #0x6, 0x2be0 <_llm_rows.packet_batch.blocks+0x26fc>
    2c24:      	tbz	w11, #0x7, 0x2c30 <_llm_rows.packet_batch.blocks+0x274c>
    2c28:      	add	x10, x10, #0x1c
    2c2c:      	ld1.s	{ v2 }[3], [x10]
    2c30:      	fmov	w11, s28
    2c34:      	ldr	q3, [sp, #0x5f0]
    2c38:      	ldr	q4, [sp, #0x600]
    2c3c:      	bif.16b	v2, v4, v17
    2c40:      	bif.16b	v0, v3, v27
    2c44:      	str	q0, [sp, #0x5f0]
    2c48:      	str	q2, [sp, #0x600]
    2c4c:      	add	x10, x9, x30
    2c50:      	movi.2d	v0, #0000000000000000
    2c54:      	movi.2d	v2, #0000000000000000
    2c58:      	tbz	w11, #0x0, 0x2c9c <_llm_rows.packet_batch.blocks+0x27b8>
    2c5c:      	ldr	s0, [x10]
    2c60:      	and	w11, w11, #0xff
    2c64:      	tbnz	w11, #0x1, 0x2ca4 <_llm_rows.packet_batch.blocks+0x27c0>
    2c68:      	tbz	w11, #0x2, 0x2cb0 <_llm_rows.packet_batch.blocks+0x27cc>
    2c6c:      	add	x16, x10, #0x8
    2c70:      	ld1.s	{ v0 }[2], [x16]
    2c74:      	tbnz	w11, #0x3, 0x2cb4 <_llm_rows.packet_batch.blocks+0x27d0>
    2c78:      	tbz	w11, #0x4, 0x2cc0 <_llm_rows.packet_batch.blocks+0x27dc>
    2c7c:      	add	x16, x10, #0x10
    2c80:      	ld1.s	{ v2 }[0], [x16]
    2c84:      	tbnz	w11, #0x5, 0x2cc4 <_llm_rows.packet_batch.blocks+0x27e0>
    2c88:      	tbz	w11, #0x6, 0x2cd0 <_llm_rows.packet_batch.blocks+0x27ec>
    2c8c:      	add	x16, x10, #0x18
    2c90:      	ld1.s	{ v2 }[2], [x16]
    2c94:      	tbnz	w11, #0x7, 0x2cd4 <_llm_rows.packet_batch.blocks+0x27f0>
    2c98:      	b	0x2cdc <_llm_rows.packet_batch.blocks+0x27f8>
    2c9c:      	and	w11, w11, #0xff
    2ca0:      	tbz	w11, #0x1, 0x2c68 <_llm_rows.packet_batch.blocks+0x2784>
    2ca4:      	add	x16, x10, #0x4
    2ca8:      	ld1.s	{ v0 }[1], [x16]
    2cac:      	tbnz	w11, #0x2, 0x2c6c <_llm_rows.packet_batch.blocks+0x2788>
    2cb0:      	tbz	w11, #0x3, 0x2c78 <_llm_rows.packet_batch.blocks+0x2794>
    2cb4:      	add	x16, x10, #0xc
    2cb8:      	ld1.s	{ v0 }[3], [x16]
    2cbc:      	tbnz	w11, #0x4, 0x2c7c <_llm_rows.packet_batch.blocks+0x2798>
    2cc0:      	tbz	w11, #0x5, 0x2c88 <_llm_rows.packet_batch.blocks+0x27a4>
    2cc4:      	add	x16, x10, #0x14
    2cc8:      	ld1.s	{ v2 }[1], [x16]
    2ccc:      	tbnz	w11, #0x6, 0x2c8c <_llm_rows.packet_batch.blocks+0x27a8>
    2cd0:      	tbz	w11, #0x7, 0x2cdc <_llm_rows.packet_batch.blocks+0x27f8>
    2cd4:      	add	x10, x10, #0x1c
    2cd8:      	ld1.s	{ v2 }[3], [x10]
    2cdc:      	fmov	w11, s28
    2ce0:      	ldr	q3, [sp, #0x610]
    2ce4:      	ldr	q4, [sp, #0x620]
    2ce8:      	bif.16b	v2, v4, v17
    2cec:      	bif.16b	v0, v3, v27
    2cf0:      	str	q0, [sp, #0x610]
    2cf4:      	str	q2, [sp, #0x620]
    2cf8:      	add	x10, x9, x14
    2cfc:      	movi.2d	v0, #0000000000000000
    2d00:      	movi.2d	v2, #0000000000000000
    2d04:      	tbz	w11, #0x0, 0x2d48 <_llm_rows.packet_batch.blocks+0x2864>
    2d08:      	ldr	s0, [x10]
    2d0c:      	and	w11, w11, #0xff
    2d10:      	tbnz	w11, #0x1, 0x2d50 <_llm_rows.packet_batch.blocks+0x286c>
    2d14:      	tbz	w11, #0x2, 0x2d5c <_llm_rows.packet_batch.blocks+0x2878>
    2d18:      	add	x14, x10, #0x8
    2d1c:      	ld1.s	{ v0 }[2], [x14]
    2d20:      	tbnz	w11, #0x3, 0x2d60 <_llm_rows.packet_batch.blocks+0x287c>
    2d24:      	tbz	w11, #0x4, 0x2d6c <_llm_rows.packet_batch.blocks+0x2888>
    2d28:      	add	x14, x10, #0x10
    2d2c:      	ld1.s	{ v2 }[0], [x14]
    2d30:      	tbnz	w11, #0x5, 0x2d70 <_llm_rows.packet_batch.blocks+0x288c>
    2d34:      	tbz	w11, #0x6, 0x2d7c <_llm_rows.packet_batch.blocks+0x2898>
    2d38:      	add	x14, x10, #0x18
    2d3c:      	ld1.s	{ v2 }[2], [x14]
    2d40:      	tbnz	w11, #0x7, 0x2d80 <_llm_rows.packet_batch.blocks+0x289c>
    2d44:      	b	0x2d88 <_llm_rows.packet_batch.blocks+0x28a4>
    2d48:      	and	w11, w11, #0xff
    2d4c:      	tbz	w11, #0x1, 0x2d14 <_llm_rows.packet_batch.blocks+0x2830>
    2d50:      	add	x14, x10, #0x4
    2d54:      	ld1.s	{ v0 }[1], [x14]
    2d58:      	tbnz	w11, #0x2, 0x2d18 <_llm_rows.packet_batch.blocks+0x2834>
    2d5c:      	tbz	w11, #0x3, 0x2d24 <_llm_rows.packet_batch.blocks+0x2840>
    2d60:      	add	x14, x10, #0xc
    2d64:      	ld1.s	{ v0 }[3], [x14]
    2d68:      	tbnz	w11, #0x4, 0x2d28 <_llm_rows.packet_batch.blocks+0x2844>
    2d6c:      	tbz	w11, #0x5, 0x2d34 <_llm_rows.packet_batch.blocks+0x2850>
    2d70:      	add	x14, x10, #0x14
    2d74:      	ld1.s	{ v2 }[1], [x14]
    2d78:      	tbnz	w11, #0x6, 0x2d38 <_llm_rows.packet_batch.blocks+0x2854>
    2d7c:      	tbz	w11, #0x7, 0x2d88 <_llm_rows.packet_batch.blocks+0x28a4>
    2d80:      	add	x10, x10, #0x1c
    2d84:      	ld1.s	{ v2 }[3], [x10]
    2d88:      	ldr	q3, [sp, #0x630]
    2d8c:      	ldr	q4, [sp, #0x640]
    2d90:      	bif.16b	v2, v4, v17
    2d94:      	bif.16b	v0, v3, v27
    2d98:      	str	q0, [sp, #0x630]
    2d9c:      	str	q2, [sp, #0x640]
    2da0:      	add	x9, x9, x15
    2da4:      	fmov	w10, s23
    2da8:      	movi.2d	v0, #0000000000000000
    2dac:      	movi.2d	v2, #0000000000000000
    2db0:      	tbz	w10, #0x0, 0x2df0 <_llm_rows.packet_batch.blocks+0x290c>
    2db4:      	ldr	s0, [x9]
    2db8:      	tbnz	w10, #0x1, 0x2df4 <_llm_rows.packet_batch.blocks+0x2910>
    2dbc:      	tbz	w10, #0x2, 0x2e00 <_llm_rows.packet_batch.blocks+0x291c>
    2dc0:      	add	x11, x9, #0x8
    2dc4:      	ld1.s	{ v0 }[2], [x11]
    2dc8:      	tbnz	w10, #0x3, 0x2e04 <_llm_rows.packet_batch.blocks+0x2920>
    2dcc:      	tbz	w10, #0x4, 0x2e10 <_llm_rows.packet_batch.blocks+0x292c>
    2dd0:      	add	x11, x9, #0x10
    2dd4:      	ld1.s	{ v2 }[0], [x11]
    2dd8:      	tbnz	w10, #0x5, 0x2e14 <_llm_rows.packet_batch.blocks+0x2930>
    2ddc:      	tbz	w10, #0x6, 0x2e20 <_llm_rows.packet_batch.blocks+0x293c>
    2de0:      	add	x11, x9, #0x18
    2de4:      	ld1.s	{ v2 }[2], [x11]
    2de8:      	tbnz	w10, #0x7, 0x2e24 <_llm_rows.packet_batch.blocks+0x2940>
    2dec:      	b	0x2e2c <_llm_rows.packet_batch.blocks+0x2948>
    2df0:      	tbz	w10, #0x1, 0x2dbc <_llm_rows.packet_batch.blocks+0x28d8>
    2df4:      	add	x11, x9, #0x4
    2df8:      	ld1.s	{ v0 }[1], [x11]
    2dfc:      	tbnz	w10, #0x2, 0x2dc0 <_llm_rows.packet_batch.blocks+0x28dc>
    2e00:      	tbz	w10, #0x3, 0x2dcc <_llm_rows.packet_batch.blocks+0x28e8>
    2e04:      	add	x11, x9, #0xc
    2e08:      	ld1.s	{ v0 }[3], [x11]
    2e0c:      	tbnz	w10, #0x4, 0x2dd0 <_llm_rows.packet_batch.blocks+0x28ec>
    2e10:      	tbz	w10, #0x5, 0x2ddc <_llm_rows.packet_batch.blocks+0x28f8>
    2e14:      	add	x11, x9, #0x14
    2e18:      	ld1.s	{ v2 }[1], [x11]
    2e1c:      	tbnz	w10, #0x6, 0x2de0 <_llm_rows.packet_batch.blocks+0x28fc>
    2e20:      	tbz	w10, #0x7, 0x2e2c <_llm_rows.packet_batch.blocks+0x2948>
    2e24:      	add	x9, x9, #0x1c
    2e28:      	ld1.s	{ v2 }[3], [x9]
    2e2c:      	fmov	w10, s28
    2e30:      	add	x9, sp, #0x5d0
    2e34:      	add	x9, x9, x6
    2e38:      	ldp	q3, q4, [x9]
    2e3c:      	zip2.8b	v5, v21, v0
    2e40:      	ushll.4s	v5, v5, #0x0
    2e44:      	shl.4s	v5, v5, #0x1f
    2e48:      	cmlt.4s	v5, v5, #0
    2e4c:      	bif.16b	v2, v4, v5
    2e50:      	zip1.8b	v4, v21, v0
    2e54:      	ushll.4s	v4, v4, #0x0
    2e58:      	shl.4s	v4, v4, #0x1f
    2e5c:      	cmlt.4s	v4, v4, #0
    2e60:      	bif.16b	v0, v3, v4
    2e64:      	stp	q0, q2, [x9]
    2e68:      	ldr	q3, [sp, #0x7c0]
    2e6c:      	ldr	q0, [sp, #0x7b0]
    2e70:      	ldr	q4, [sp, #0x680]
    2e74:      	ldr	q2, [sp, #0x670]
    2e78:      	stp	q2, q0, [sp, #0xb0]
    2e7c:      	fmul.4s	v0, v0, v2
    2e80:      	ldr	q5, [sp, #0x720]
    2e84:      	ldr	q2, [sp, #0x710]
    2e88:      	ldr	q31, [sp, #0x5e0]
    2e8c:      	ldr	q6, [sp, #0x5d0]
    2e90:      	stp	q6, q2, [sp, #0x90]
    2e94:      	fmul.4s	v2, v2, v6
    2e98:      	fsub.4s	v0, v0, v2
    2e9c:      	and.16b	v0, v27, v0
    2ea0:      	add	x9, x8, x26
    2ea4:      	tbz	w10, #0x0, 0x2ef4 <_llm_rows.packet_batch.blocks+0x2a10>
    2ea8:      	str	s0, [x9]
    2eac:      	and	w10, w10, #0xff
    2eb0:      	tbnz	w10, #0x1, 0x2efc <_llm_rows.packet_batch.blocks+0x2a18>
    2eb4:      	tbz	w10, #0x2, 0x2f08 <_llm_rows.packet_batch.blocks+0x2a24>
    2eb8:      	add	x11, x9, #0x8
    2ebc:      	st1.s	{ v0 }[2], [x11]
    2ec0:      	tbnz	w10, #0x3, 0x2f0c <_llm_rows.packet_batch.blocks+0x2a28>
    2ec4:      	fmul.4s	v0, v3, v4
    2ec8:      	fmul.4s	v2, v5, v31
    2ecc:      	fsub.4s	v0, v0, v2
    2ed0:      	and.16b	v0, v17, v0
    2ed4:      	tbz	w10, #0x4, 0x2f28 <_llm_rows.packet_batch.blocks+0x2a44>
    2ed8:      	str	s0, [x9, #0x10]
    2edc:      	tbnz	w10, #0x5, 0x2f2c <_llm_rows.packet_batch.blocks+0x2a48>
    2ee0:      	tbz	w10, #0x6, 0x2f38 <_llm_rows.packet_batch.blocks+0x2a54>
    2ee4:      	add	x11, x9, #0x18
    2ee8:      	st1.s	{ v0 }[2], [x11]
    2eec:      	tbnz	w10, #0x7, 0x2f3c <_llm_rows.packet_batch.blocks+0x2a58>
    2ef0:      	b	0x2f44 <_llm_rows.packet_batch.blocks+0x2a60>
    2ef4:      	and	w10, w10, #0xff
    2ef8:      	tbz	w10, #0x1, 0x2eb4 <_llm_rows.packet_batch.blocks+0x29d0>
    2efc:      	add	x11, x9, #0x4
    2f00:      	st1.s	{ v0 }[1], [x11]
    2f04:      	tbnz	w10, #0x2, 0x2eb8 <_llm_rows.packet_batch.blocks+0x29d4>
    2f08:      	tbz	w10, #0x3, 0x2ec4 <_llm_rows.packet_batch.blocks+0x29e0>
    2f0c:      	add	x11, x9, #0xc
    2f10:      	st1.s	{ v0 }[3], [x11]
    2f14:      	fmul.4s	v0, v3, v4
    2f18:      	fmul.4s	v2, v5, v31
    2f1c:      	fsub.4s	v0, v0, v2
    2f20:      	and.16b	v0, v17, v0
    2f24:      	tbnz	w10, #0x4, 0x2ed8 <_llm_rows.packet_batch.blocks+0x29f4>
    2f28:      	tbz	w10, #0x5, 0x2ee0 <_llm_rows.packet_batch.blocks+0x29fc>
    2f2c:      	add	x11, x9, #0x14
    2f30:      	st1.s	{ v0 }[1], [x11]
    2f34:      	tbnz	w10, #0x6, 0x2ee4 <_llm_rows.packet_batch.blocks+0x2a00>
    2f38:      	tbz	w10, #0x7, 0x2f44 <_llm_rows.packet_batch.blocks+0x2a60>
    2f3c:      	add	x9, x9, #0x1c
    2f40:      	st1.s	{ v0 }[3], [x9]
    2f44:      	fmov	w10, s28
    2f48:      	tst	w12, #0x1
    2f4c:      	csel	x9, x22, xzr, ne
    2f50:      	add	x14, sp, #0x7b0
    2f54:      	add	x11, x14, x9
    2f58:      	ldp	q0, q6, [x11]
    2f5c:      	add	x16, sp, #0x670
    2f60:      	add	x11, x16, x9
    2f64:      	ldp	q2, q10, [x11]
    2f68:      	str	q0, [sp, #0x80]
    2f6c:      	str	q2, [sp, #0x60]
    2f70:      	fmul.4s	v0, v0, v2
    2f74:      	add	x15, sp, #0x710
    2f78:      	add	x11, x15, x9
    2f7c:      	ldp	q2, q18, [x11]
    2f80:      	add	x6, sp, #0x5d0
    2f84:      	add	x9, x6, x9
    2f88:      	ldp	q7, q20, [x9]
    2f8c:      	stp	q7, q2, [sp, #0x30]
    2f90:      	fmul.4s	v2, v2, v7
    2f94:      	fsub.4s	v0, v0, v2
    2f98:      	and.16b	v0, v27, v0
    2f9c:      	ldr	x9, [sp, #0x1b0]
    2fa0:      	csel	x9, x9, xzr, ne
    2fa4:      	add	x9, x8, x9
    2fa8:      	tbz	w10, #0x0, 0x3000 <_llm_rows.packet_batch.blocks+0x2b1c>
    2fac:      	str	s0, [x9]
    2fb0:      	and	w10, w10, #0xff
    2fb4:      	tbnz	w10, #0x1, 0x3008 <_llm_rows.packet_batch.blocks+0x2b24>
    2fb8:      	tbz	w10, #0x2, 0x3014 <_llm_rows.packet_batch.blocks+0x2b30>
    2fbc:      	add	x11, x9, #0x8
    2fc0:      	st1.s	{ v0 }[2], [x11]
    2fc4:      	tbnz	w10, #0x3, 0x3018 <_llm_rows.packet_batch.blocks+0x2b34>
    2fc8:      	fmul.4s	v0, v6, v10
    2fcc:      	fmul.4s	v2, v18, v20
    2fd0:      	fsub.4s	v0, v0, v2
    2fd4:      	and.16b	v0, v17, v0
    2fd8:      	tbz	w10, #0x4, 0x3034 <_llm_rows.packet_batch.blocks+0x2b50>
    2fdc:      	str	s0, [x9, #0x10]
    2fe0:      	tbnz	w10, #0x5, 0x3038 <_llm_rows.packet_batch.blocks+0x2b54>
    2fe4:      	tbz	w10, #0x6, 0x3044 <_llm_rows.packet_batch.blocks+0x2b60>
    2fe8:      	add	x11, x9, #0x18
    2fec:      	st1.s	{ v0 }[2], [x11]
    2ff0:      	stp	q5, q4, [sp, #0x100]
    2ff4:      	str	q3, [sp, #0x1b0]
    2ff8:      	tbnz	w10, #0x7, 0x3050 <_llm_rows.packet_batch.blocks+0x2b6c>
    2ffc:      	b	0x3058 <_llm_rows.packet_batch.blocks+0x2b74>
    3000:      	and	w10, w10, #0xff
    3004:      	tbz	w10, #0x1, 0x2fb8 <_llm_rows.packet_batch.blocks+0x2ad4>
    3008:      	add	x11, x9, #0x4
    300c:      	st1.s	{ v0 }[1], [x11]
    3010:      	tbnz	w10, #0x2, 0x2fbc <_llm_rows.packet_batch.blocks+0x2ad8>
    3014:      	tbz	w10, #0x3, 0x2fc8 <_llm_rows.packet_batch.blocks+0x2ae4>
    3018:      	add	x11, x9, #0xc
    301c:      	st1.s	{ v0 }[3], [x11]
    3020:      	fmul.4s	v0, v6, v10
    3024:      	fmul.4s	v2, v18, v20
    3028:      	fsub.4s	v0, v0, v2
    302c:      	and.16b	v0, v17, v0
    3030:      	tbnz	w10, #0x4, 0x2fdc <_llm_rows.packet_batch.blocks+0x2af8>
    3034:      	tbz	w10, #0x5, 0x2fe4 <_llm_rows.packet_batch.blocks+0x2b00>
    3038:      	add	x11, x9, #0x14
    303c:      	st1.s	{ v0 }[1], [x11]
    3040:      	tbnz	w10, #0x6, 0x2fe8 <_llm_rows.packet_batch.blocks+0x2b04>
    3044:      	stp	q5, q4, [sp, #0x100]
    3048:      	str	q3, [sp, #0x1b0]
    304c:      	tbz	w10, #0x7, 0x3058 <_llm_rows.packet_batch.blocks+0x2b74>
    3050:      	add	x9, x9, #0x1c
    3054:      	st1.s	{ v0 }[3], [x9]
    3058:      	fmov	w10, s28
    305c:      	tst	w12, #0x1
    3060:      	mov	w9, #0x40               ; =64
    3064:      	csel	x9, x9, xzr, ne
    3068:      	add	x11, x14, x9
    306c:      	ldp	q0, q7, [x11]
    3070:      	add	x11, x16, x9
    3074:      	ldp	q2, q16, [x11]
    3078:      	stp	q2, q0, [sp, #0x10]
    307c:      	fmul.4s	v0, v0, v2
    3080:      	add	x11, x15, x9
    3084:      	ldp	q26, q19, [x11]
    3088:      	add	x9, x6, x9
    308c:      	ldp	q4, q22, [x9]
    3090:      	fmul.4s	v5, v26, v4
    3094:      	fsub.4s	v0, v0, v5
    3098:      	and.16b	v0, v27, v0
    309c:      	ldr	x9, [sp, #0x1a0]
    30a0:      	csel	x9, x9, xzr, ne
    30a4:      	add	x9, x8, x9
    30a8:      	tbz	w10, #0x0, 0x30fc <_llm_rows.packet_batch.blocks+0x2c18>
    30ac:      	str	s0, [x9]
    30b0:      	and	w10, w10, #0xff
    30b4:      	tbnz	w10, #0x1, 0x3104 <_llm_rows.packet_batch.blocks+0x2c20>
    30b8:      	tbz	w10, #0x2, 0x3110 <_llm_rows.packet_batch.blocks+0x2c2c>
    30bc:      	add	x11, x9, #0x8
    30c0:      	st1.s	{ v0 }[2], [x11]
    30c4:      	tbnz	w10, #0x3, 0x3114 <_llm_rows.packet_batch.blocks+0x2c30>
    30c8:      	fmul.4s	v0, v7, v16
    30cc:      	fmul.4s	v5, v19, v22
    30d0:      	fsub.4s	v0, v0, v5
    30d4:      	and.16b	v0, v17, v0
    30d8:      	tbz	w10, #0x4, 0x3130 <_llm_rows.packet_batch.blocks+0x2c4c>
    30dc:      	str	s0, [x9, #0x10]
    30e0:      	tbnz	w10, #0x5, 0x3134 <_llm_rows.packet_batch.blocks+0x2c50>
    30e4:      	tbz	w10, #0x6, 0x3140 <_llm_rows.packet_batch.blocks+0x2c5c>
    30e8:      	add	x11, x9, #0x18
    30ec:      	st1.s	{ v0 }[2], [x11]
    30f0:      	str	q6, [sp, #0x1a0]
    30f4:      	tbnz	w10, #0x7, 0x3148 <_llm_rows.packet_batch.blocks+0x2c64>
    30f8:      	b	0x3150 <_llm_rows.packet_batch.blocks+0x2c6c>
    30fc:      	and	w10, w10, #0xff
    3100:      	tbz	w10, #0x1, 0x30b8 <_llm_rows.packet_batch.blocks+0x2bd4>
    3104:      	add	x11, x9, #0x4
    3108:      	st1.s	{ v0 }[1], [x11]
    310c:      	tbnz	w10, #0x2, 0x30bc <_llm_rows.packet_batch.blocks+0x2bd8>
    3110:      	tbz	w10, #0x3, 0x30c8 <_llm_rows.packet_batch.blocks+0x2be4>
    3114:      	add	x11, x9, #0xc
    3118:      	st1.s	{ v0 }[3], [x11]
    311c:      	fmul.4s	v0, v7, v16
    3120:      	fmul.4s	v5, v19, v22
    3124:      	fsub.4s	v0, v0, v5
    3128:      	and.16b	v0, v17, v0
    312c:      	tbnz	w10, #0x4, 0x30dc <_llm_rows.packet_batch.blocks+0x2bf8>
    3130:      	tbz	w10, #0x5, 0x30e4 <_llm_rows.packet_batch.blocks+0x2c00>
    3134:      	add	x11, x9, #0x14
    3138:      	st1.s	{ v0 }[1], [x11]
    313c:      	tbnz	w10, #0x6, 0x30e8 <_llm_rows.packet_batch.blocks+0x2c04>
    3140:      	str	q6, [sp, #0x1a0]
    3144:      	tbz	w10, #0x7, 0x3150 <_llm_rows.packet_batch.blocks+0x2c6c>
    3148:      	add	x9, x9, #0x1c
    314c:      	st1.s	{ v0 }[3], [x9]
    3150:      	fmov	w10, s28
    3154:      	tst	w12, #0x1
    3158:      	mov	w9, #0x60               ; =96
    315c:      	csel	x9, x9, xzr, ne
    3160:      	add	x11, x14, x9
    3164:      	ldp	q6, q2, [x11]
    3168:      	add	x11, x16, x9
    316c:      	ldp	q11, q3, [x11]
    3170:      	fmul.4s	v0, v6, v11
    3174:      	add	x11, x15, x9
    3178:      	ldp	q12, q28, [x11]
    317c:      	add	x9, x6, x9
    3180:      	ldp	q13, q29, [x9]
    3184:      	fmul.4s	v5, v12, v13
    3188:      	fsub.4s	v0, v0, v5
    318c:      	and.16b	v0, v27, v0
    3190:      	csel	x9, x17, xzr, ne
    3194:      	add	x9, x8, x9
    3198:      	tbz	w10, #0x0, 0x3200 <_llm_rows.packet_batch.blocks+0x2d1c>
    319c:      	str	s0, [x9]
    31a0:      	and	w10, w10, #0xff
    31a4:      	tbnz	w10, #0x1, 0x3208 <_llm_rows.packet_batch.blocks+0x2d24>
    31a8:      	tbz	w10, #0x2, 0x3214 <_llm_rows.packet_batch.blocks+0x2d30>
    31ac:      	add	x11, x9, #0x8
    31b0:      	st1.s	{ v0 }[2], [x11]
    31b4:      	tbnz	w10, #0x3, 0x3218 <_llm_rows.packet_batch.blocks+0x2d34>
    31b8:      	fmul.4s	v0, v2, v3
    31bc:      	fmul.4s	v5, v28, v29
    31c0:      	fsub.4s	v0, v0, v5
    31c4:      	and.16b	v0, v17, v0
    31c8:      	tbz	w10, #0x4, 0x3234 <_llm_rows.packet_batch.blocks+0x2d50>
    31cc:      	str	s0, [x9, #0x10]
    31d0:      	tbnz	w10, #0x5, 0x3238 <_llm_rows.packet_batch.blocks+0x2d54>
    31d4:      	str	q29, [sp, #0x50]
    31d8:      	str	q28, [sp, #0x70]
    31dc:      	tbz	w10, #0x6, 0x324c <_llm_rows.packet_batch.blocks+0x2d68>
    31e0:      	add	x11, x9, #0x18
    31e4:      	st1.s	{ v0 }[2], [x11]
    31e8:      	stp	q22, q16, [sp, #0xd0]
    31ec:      	str	q7, [sp, #0xf0]
    31f0:      	fmov	d29, d23
    31f4:      	mov.16b	v28, v27
    31f8:      	tbnz	w10, #0x7, 0x3260 <_llm_rows.packet_batch.blocks+0x2d7c>
    31fc:      	b	0x3268 <_llm_rows.packet_batch.blocks+0x2d84>
    3200:      	and	w10, w10, #0xff
    3204:      	tbz	w10, #0x1, 0x31a8 <_llm_rows.packet_batch.blocks+0x2cc4>
    3208:      	add	x11, x9, #0x4
    320c:      	st1.s	{ v0 }[1], [x11]
    3210:      	tbnz	w10, #0x2, 0x31ac <_llm_rows.packet_batch.blocks+0x2cc8>
    3214:      	tbz	w10, #0x3, 0x31b8 <_llm_rows.packet_batch.blocks+0x2cd4>
    3218:      	add	x11, x9, #0xc
    321c:      	st1.s	{ v0 }[3], [x11]
    3220:      	fmul.4s	v0, v2, v3
    3224:      	fmul.4s	v5, v28, v29
    3228:      	fsub.4s	v0, v0, v5
    322c:      	and.16b	v0, v17, v0
    3230:      	tbnz	w10, #0x4, 0x31cc <_llm_rows.packet_batch.blocks+0x2ce8>
    3234:      	tbz	w10, #0x5, 0x31d4 <_llm_rows.packet_batch.blocks+0x2cf0>
    3238:      	add	x11, x9, #0x14
    323c:      	st1.s	{ v0 }[1], [x11]
    3240:      	str	q29, [sp, #0x50]
    3244:      	str	q28, [sp, #0x70]
    3248:      	tbnz	w10, #0x6, 0x31e0 <_llm_rows.packet_batch.blocks+0x2cfc>
    324c:      	stp	q22, q16, [sp, #0xd0]
    3250:      	str	q7, [sp, #0xf0]
    3254:      	fmov	d29, d23
    3258:      	mov.16b	v28, v27
    325c:      	tbz	w10, #0x7, 0x3268 <_llm_rows.packet_batch.blocks+0x2d84>
    3260:      	add	x9, x9, #0x1c
    3264:      	st1.s	{ v0 }[3], [x9]
    3268:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x2b1c>
    326c:      	ldr	q0, [x9]
    3270:      	and.16b	v0, v8, v0
    3274:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x2b1c>
    3278:      	ldr	q5, [x9]
    327c:      	and.16b	v5, v25, v5
    3280:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x2b1c>
    3284:      	ldr	q7, [x9]
    3288:      	and.16b	v7, v24, v7
    328c:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x2b1c>
    3290:      	ldr	q16, [x9]
    3294:      	ldp	q23, q22, [sp, #0x120]
    3298:      	and.16b	v16, v23, v16
    329c:      	add.2d	v23, v22, v1
    32a0:      	ldr	q1, [sp, #0x140]
    32a4:      	add.2d	v24, v1, v14
    32a8:      	add.2d	v25, v15, v9
    32ac:      	ldr	q1, [sp, #0x150]
    32b0:      	add.2d	v22, v1, v30
    32b4:      	str	q16, [sp, #0x440]
    32b8:      	str	q5, [sp, #0x450]
    32bc:      	str	q7, [sp, #0x460]
    32c0:      	str	q0, [sp, #0x470]
    32c4:      	ubfiz	x10, x13, #3, #3
    32c8:      	add	x9, sp, #0x440
    32cc:      	ldr	x9, [x9, x10]
    32d0:      	orr	x9, x9, #0x80
    32d4:      	sub	x9, x9, x3
    32d8:      	tst	w0, #0xff
    32dc:      	csel	x9, xzr, x9, eq
    32e0:      	add	x11, x14, x9
    32e4:      	ldp	q14, q1, [x11]
    32e8:      	add	x11, x16, x9
    32ec:      	ldp	q15, q0, [x11]
    32f0:      	fmul.4s	v16, v14, v15
    32f4:      	add	x11, x15, x9
    32f8:      	ldp	q8, q5, [x11]
    32fc:      	add	x9, x6, x9
    3300:      	ldp	q9, q7, [x9]
    3304:      	fmul.4s	v27, v8, v9
    3308:      	fsub.4s	v16, v16, v27
    330c:      	zip1.8b	v27, v21, v0
    3310:      	ushll.4s	v27, v27, #0x0
    3314:      	shl.4s	v27, v27, #0x1f
    3318:      	cmlt.4s	v27, v27, #0
    331c:      	and.16b	v16, v27, v16
    3320:      	fmov	w9, s29
    3324:      	str	q22, [sp, #0x400]
    3328:      	str	q25, [sp, #0x410]
    332c:      	str	q24, [sp, #0x420]
    3330:      	str	q23, [sp, #0x430]
    3334:      	add	x11, sp, #0x400
    3338:      	ldr	x10, [x11, x10]
    333c:      	sub	x10, x10, x13
    3340:      	add	x10, x8, x10, lsl #2
    3344:      	tbz	w9, #0x0, 0x3374 <_llm_rows.packet_batch.blocks+0x2e90>
    3348:      	str	s16, [x10]
    334c:      	mov.16b	v23, v28
    3350:      	tbnz	w9, #0x1, 0x337c <_llm_rows.packet_batch.blocks+0x2e98>
    3354:      	ldr	q25, [sp, #0x210]
    3358:      	mov.16b	v27, v2
    335c:      	mov.16b	v28, v3
    3360:      	tbz	w9, #0x2, 0x3394 <_llm_rows.packet_batch.blocks+0x2eb0>
    3364:      	add	x11, x10, #0x8
    3368:      	st1.s	{ v16 }[2], [x11]
    336c:      	tbnz	w9, #0x3, 0x3398 <_llm_rows.packet_batch.blocks+0x2eb4>
    3370:      	b	0x33a0 <_llm_rows.packet_batch.blocks+0x2ebc>
    3374:      	mov.16b	v23, v28
    3378:      	tbz	w9, #0x1, 0x3354 <_llm_rows.packet_batch.blocks+0x2e70>
    337c:      	add	x11, x10, #0x4
    3380:      	st1.s	{ v16 }[1], [x11]
    3384:      	ldr	q25, [sp, #0x210]
    3388:      	mov.16b	v27, v2
    338c:      	mov.16b	v28, v3
    3390:      	tbnz	w9, #0x2, 0x3364 <_llm_rows.packet_batch.blocks+0x2e80>
    3394:      	tbz	w9, #0x3, 0x33a0 <_llm_rows.packet_batch.blocks+0x2ebc>
    3398:      	add	x11, x10, #0xc
    339c:      	st1.s	{ v16 }[3], [x11]
    33a0:      	fmul.4s	v16, v1, v0
    33a4:      	fmul.4s	v22, v5, v7
    33a8:      	fsub.4s	v16, v16, v22
    33ac:      	zip2.8b	v22, v21, v0
    33b0:      	ushll.4s	v22, v22, #0x0
    33b4:      	shl.4s	v22, v22, #0x1f
    33b8:      	cmlt.4s	v22, v22, #0
    33bc:      	and.16b	v16, v22, v16
    33c0:      	tbz	w9, #0x4, 0x33e0 <_llm_rows.packet_batch.blocks+0x2efc>
    33c4:      	str	s16, [x10, #0x10]
    33c8:      	tbnz	w9, #0x5, 0x33e4 <_llm_rows.packet_batch.blocks+0x2f00>
    33cc:      	tbz	w9, #0x6, 0x33f0 <_llm_rows.packet_batch.blocks+0x2f0c>
    33d0:      	add	x11, x10, #0x18
    33d4:      	st1.s	{ v16 }[2], [x11]
    33d8:      	tbnz	w9, #0x7, 0x33f4 <_llm_rows.packet_batch.blocks+0x2f10>
    33dc:      	b	0x33fc <_llm_rows.packet_batch.blocks+0x2f18>
    33e0:      	tbz	w9, #0x5, 0x33cc <_llm_rows.packet_batch.blocks+0x2ee8>
    33e4:      	add	x11, x10, #0x14
    33e8:      	st1.s	{ v16 }[1], [x11]
    33ec:      	tbnz	w9, #0x6, 0x33d0 <_llm_rows.packet_batch.blocks+0x2eec>
    33f0:      	tbz	w9, #0x7, 0x33fc <_llm_rows.packet_batch.blocks+0x2f18>
    33f4:      	add	x9, x10, #0x1c
    33f8:      	st1.s	{ v16 }[3], [x9]
    33fc:      	fmov	w10, s25
    3400:      	ldp	q22, q16, [sp, #0xb0]
    3404:      	ldp	q3, q2, [sp, #0x90]
    3408:      	fmul.4s	v16, v16, v3
    340c:      	fmul.4s	v22, v22, v2
    3410:      	fadd.4s	v16, v22, v16
    3414:      	and.16b	v16, v23, v16
    3418:      	tst	w12, #0x1
    341c:      	csel	x9, x1, xzr, ne
    3420:      	add	x9, x8, x9
    3424:      	tbz	w10, #0x0, 0x3448 <_llm_rows.packet_batch.blocks+0x2f64>
    3428:      	str	s16, [x9]
    342c:      	and	w10, w10, #0xff
    3430:      	tbnz	w10, #0x1, 0x3450 <_llm_rows.packet_batch.blocks+0x2f6c>
    3434:      	tbz	w10, #0x2, 0x345c <_llm_rows.packet_batch.blocks+0x2f78>
    3438:      	add	x11, x9, #0x8
    343c:      	st1.s	{ v16 }[2], [x11]
    3440:      	tbnz	w10, #0x3, 0x3460 <_llm_rows.packet_batch.blocks+0x2f7c>
    3444:      	b	0x3468 <_llm_rows.packet_batch.blocks+0x2f84>
    3448:      	and	w10, w10, #0xff
    344c:      	tbz	w10, #0x1, 0x3434 <_llm_rows.packet_batch.blocks+0x2f50>
    3450:      	add	x11, x9, #0x4
    3454:      	st1.s	{ v16 }[1], [x11]
    3458:      	tbnz	w10, #0x2, 0x3438 <_llm_rows.packet_batch.blocks+0x2f54>
    345c:      	tbz	w10, #0x3, 0x3468 <_llm_rows.packet_batch.blocks+0x2f84>
    3460:      	add	x11, x9, #0xc
    3464:      	st1.s	{ v16 }[3], [x11]
    3468:      	ldr	q16, [sp, #0x1b0]
    346c:      	fmul.4s	v16, v16, v31
    3470:      	ldp	q24, q22, [sp, #0x100]
    3474:      	fmul.4s	v22, v22, v24
    3478:      	fadd.4s	v16, v22, v16
    347c:      	and.16b	v16, v17, v16
    3480:      	tbz	w10, #0x4, 0x34a4 <_llm_rows.packet_batch.blocks+0x2fc0>
    3484:      	str	s16, [x9, #0x10]
    3488:      	mov.16b	v22, v19
    348c:      	tbnz	w10, #0x5, 0x34ac <_llm_rows.packet_batch.blocks+0x2fc8>
    3490:      	tbz	w10, #0x6, 0x34b8 <_llm_rows.packet_batch.blocks+0x2fd4>
    3494:      	add	x11, x9, #0x18
    3498:      	st1.s	{ v16 }[2], [x11]
    349c:      	tbnz	w10, #0x7, 0x34bc <_llm_rows.packet_batch.blocks+0x2fd8>
    34a0:      	b	0x34c4 <_llm_rows.packet_batch.blocks+0x2fe0>
    34a4:      	mov.16b	v22, v19
    34a8:      	tbz	w10, #0x5, 0x3490 <_llm_rows.packet_batch.blocks+0x2fac>
    34ac:      	add	x11, x9, #0x14
    34b0:      	st1.s	{ v16 }[1], [x11]
    34b4:      	tbnz	w10, #0x6, 0x3494 <_llm_rows.packet_batch.blocks+0x2fb0>
    34b8:      	tbz	w10, #0x7, 0x34c4 <_llm_rows.packet_batch.blocks+0x2fe0>
    34bc:      	add	x9, x9, #0x1c
    34c0:      	st1.s	{ v16 }[3], [x9]
    34c4:      	fmov	w10, s25
    34c8:      	ldr	q2, [sp, #0x80]
    34cc:      	ldr	q3, [sp, #0x30]
    34d0:      	fmul.4s	v16, v2, v3
    34d4:      	ldr	q2, [sp, #0x60]
    34d8:      	ldr	q3, [sp, #0x40]
    34dc:      	fmul.4s	v19, v2, v3
    34e0:      	fadd.4s	v16, v19, v16
    34e4:      	and.16b	v16, v23, v16
    34e8:      	tst	w12, #0x1
    34ec:      	csel	x9, x2, xzr, ne
    34f0:      	add	x9, x8, x9
    34f4:      	tbz	w10, #0x0, 0x3548 <_llm_rows.packet_batch.blocks+0x3064>
    34f8:      	str	s16, [x9]
    34fc:      	and	w10, w10, #0xff
    3500:      	tbnz	w10, #0x1, 0x3550 <_llm_rows.packet_batch.blocks+0x306c>
    3504:      	tbz	w10, #0x2, 0x355c <_llm_rows.packet_batch.blocks+0x3078>
    3508:      	add	x11, x9, #0x8
    350c:      	st1.s	{ v16 }[2], [x11]
    3510:      	tbnz	w10, #0x3, 0x3560 <_llm_rows.packet_batch.blocks+0x307c>
    3514:      	ldr	q16, [sp, #0x1a0]
    3518:      	fmul.4s	v16, v16, v20
    351c:      	fmul.4s	v19, v10, v18
    3520:      	fadd.4s	v16, v19, v16
    3524:      	and.16b	v16, v17, v16
    3528:      	tbz	w10, #0x4, 0x3580 <_llm_rows.packet_batch.blocks+0x309c>
    352c:      	str	s16, [x9, #0x10]
    3530:      	tbnz	w10, #0x5, 0x3584 <_llm_rows.packet_batch.blocks+0x30a0>
    3534:      	tbz	w10, #0x6, 0x3590 <_llm_rows.packet_batch.blocks+0x30ac>
    3538:      	add	x11, x9, #0x18
    353c:      	st1.s	{ v16 }[2], [x11]
    3540:      	tbnz	w10, #0x7, 0x3594 <_llm_rows.packet_batch.blocks+0x30b0>
    3544:      	b	0x359c <_llm_rows.packet_batch.blocks+0x30b8>
    3548:      	and	w10, w10, #0xff
    354c:      	tbz	w10, #0x1, 0x3504 <_llm_rows.packet_batch.blocks+0x3020>
    3550:      	add	x11, x9, #0x4
    3554:      	st1.s	{ v16 }[1], [x11]
    3558:      	tbnz	w10, #0x2, 0x3508 <_llm_rows.packet_batch.blocks+0x3024>
    355c:      	tbz	w10, #0x3, 0x3514 <_llm_rows.packet_batch.blocks+0x3030>
    3560:      	add	x11, x9, #0xc
    3564:      	st1.s	{ v16 }[3], [x11]
    3568:      	ldr	q16, [sp, #0x1a0]
    356c:      	fmul.4s	v16, v16, v20
    3570:      	fmul.4s	v19, v10, v18
    3574:      	fadd.4s	v16, v19, v16
    3578:      	and.16b	v16, v17, v16
    357c:      	tbnz	w10, #0x4, 0x352c <_llm_rows.packet_batch.blocks+0x3048>
    3580:      	tbz	w10, #0x5, 0x3534 <_llm_rows.packet_batch.blocks+0x3050>
    3584:      	add	x11, x9, #0x14
    3588:      	st1.s	{ v16 }[1], [x11]
    358c:      	tbnz	w10, #0x6, 0x3538 <_llm_rows.packet_batch.blocks+0x3054>
    3590:      	tbz	w10, #0x7, 0x359c <_llm_rows.packet_batch.blocks+0x30b8>
    3594:      	add	x9, x9, #0x1c
    3598:      	st1.s	{ v16 }[3], [x9]
    359c:      	fmov	w10, s25
    35a0:      	ldp	q3, q2, [sp, #0x10]
    35a4:      	fmul.4s	v2, v2, v4
    35a8:      	fmul.4s	v3, v3, v26
    35ac:      	fadd.4s	v2, v3, v2
    35b0:      	and.16b	v2, v23, v2
    35b4:      	tst	w12, #0x1
    35b8:      	csel	x9, x4, xzr, ne
    35bc:      	add	x9, x8, x9
    35c0:      	tbz	w10, #0x0, 0x35e8 <_llm_rows.packet_batch.blocks+0x3104>
    35c4:      	str	s2, [x9]
    35c8:      	and	w10, w10, #0xff
    35cc:      	ldr	q3, [sp, #0xe0]
    35d0:      	tbnz	w10, #0x1, 0x35f4 <_llm_rows.packet_batch.blocks+0x3110>
    35d4:      	tbz	w10, #0x2, 0x3600 <_llm_rows.packet_batch.blocks+0x311c>
    35d8:      	add	x11, x9, #0x8
    35dc:      	st1.s	{ v2 }[2], [x11]
    35e0:      	tbnz	w10, #0x3, 0x3604 <_llm_rows.packet_batch.blocks+0x3120>
    35e4:      	b	0x360c <_llm_rows.packet_batch.blocks+0x3128>
    35e8:      	and	w10, w10, #0xff
    35ec:      	ldr	q3, [sp, #0xe0]
    35f0:      	tbz	w10, #0x1, 0x35d4 <_llm_rows.packet_batch.blocks+0x30f0>
    35f4:      	add	x11, x9, #0x4
    35f8:      	st1.s	{ v2 }[1], [x11]
    35fc:      	tbnz	w10, #0x2, 0x35d8 <_llm_rows.packet_batch.blocks+0x30f4>
    3600:      	tbz	w10, #0x3, 0x360c <_llm_rows.packet_batch.blocks+0x3128>
    3604:      	add	x11, x9, #0xc
    3608:      	st1.s	{ v2 }[3], [x11]
    360c:      	ldr	q2, [sp, #0xf0]
    3610:      	ldr	q4, [sp, #0xd0]
    3614:      	fmul.4s	v2, v2, v4
    3618:      	fmul.4s	v3, v3, v22
    361c:      	fadd.4s	v2, v3, v2
    3620:      	and.16b	v2, v17, v2
    3624:      	tbz	w10, #0x4, 0x3644 <_llm_rows.packet_batch.blocks+0x3160>
    3628:      	str	s2, [x9, #0x10]
    362c:      	tbnz	w10, #0x5, 0x3648 <_llm_rows.packet_batch.blocks+0x3164>
    3630:      	tbz	w10, #0x6, 0x3654 <_llm_rows.packet_batch.blocks+0x3170>
    3634:      	add	x11, x9, #0x18
    3638:      	st1.s	{ v2 }[2], [x11]
    363c:      	tbnz	w10, #0x7, 0x3658 <_llm_rows.packet_batch.blocks+0x3174>
    3640:      	b	0x3660 <_llm_rows.packet_batch.blocks+0x317c>
    3644:      	tbz	w10, #0x5, 0x3630 <_llm_rows.packet_batch.blocks+0x314c>
    3648:      	add	x11, x9, #0x14
    364c:      	st1.s	{ v2 }[1], [x11]
    3650:      	tbnz	w10, #0x6, 0x3634 <_llm_rows.packet_batch.blocks+0x3150>
    3654:      	tbz	w10, #0x7, 0x3660 <_llm_rows.packet_batch.blocks+0x317c>
    3658:      	add	x9, x9, #0x1c
    365c:      	st1.s	{ v2 }[3], [x9]
    3660:      	fmov	w10, s25
    3664:      	fmul.4s	v2, v6, v13
    3668:      	fmul.4s	v3, v11, v12
    366c:      	fadd.4s	v2, v3, v2
    3670:      	and.16b	v2, v23, v2
    3674:      	tst	w12, #0x1
    3678:      	csel	x9, x5, xzr, ne
    367c:      	add	x9, x8, x9
    3680:      	tbz	w10, #0x0, 0x36a8 <_llm_rows.packet_batch.blocks+0x31c4>
    3684:      	str	s2, [x9]
    3688:      	and	w10, w10, #0xff
    368c:      	movi.2s	v12, #0x21
    3690:      	tbnz	w10, #0x1, 0x36b4 <_llm_rows.packet_batch.blocks+0x31d0>
    3694:      	tbz	w10, #0x2, 0x36c0 <_llm_rows.packet_batch.blocks+0x31dc>
    3698:      	add	x11, x9, #0x8
    369c:      	st1.s	{ v2 }[2], [x11]
    36a0:      	tbnz	w10, #0x3, 0x36c4 <_llm_rows.packet_batch.blocks+0x31e0>
    36a4:      	b	0x36cc <_llm_rows.packet_batch.blocks+0x31e8>
    36a8:      	and	w10, w10, #0xff
    36ac:      	movi.2s	v12, #0x21
    36b0:      	tbz	w10, #0x1, 0x3694 <_llm_rows.packet_batch.blocks+0x31b0>
    36b4:      	add	x11, x9, #0x4
    36b8:      	st1.s	{ v2 }[1], [x11]
    36bc:      	tbnz	w10, #0x2, 0x3698 <_llm_rows.packet_batch.blocks+0x31b4>
    36c0:      	tbz	w10, #0x3, 0x36cc <_llm_rows.packet_batch.blocks+0x31e8>
    36c4:      	add	x11, x9, #0xc
    36c8:      	st1.s	{ v2 }[3], [x11]
    36cc:      	ldr	q2, [sp, #0x50]
    36d0:      	fmul.4s	v2, v27, v2
    36d4:      	ldr	q3, [sp, #0x70]
    36d8:      	fmul.4s	v3, v28, v3
    36dc:      	fadd.4s	v2, v3, v2
    36e0:      	and.16b	v2, v17, v2
    36e4:      	tbz	w10, #0x4, 0x3708 <_llm_rows.packet_batch.blocks+0x3224>
    36e8:      	str	s2, [x9, #0x10]
    36ec:      	movi.2s	v10, #0x42
    36f0:      	tbnz	w10, #0x5, 0x3710 <_llm_rows.packet_batch.blocks+0x322c>
    36f4:      	tbz	w10, #0x6, 0x371c <_llm_rows.packet_batch.blocks+0x3238>
    36f8:      	add	x11, x9, #0x18
    36fc:      	st1.s	{ v2 }[2], [x11]
    3700:      	tbnz	w10, #0x7, 0x3720 <_llm_rows.packet_batch.blocks+0x323c>
    3704:      	b	0x3728 <_llm_rows.packet_batch.blocks+0x3244>
    3708:      	movi.2s	v10, #0x42
    370c:      	tbz	w10, #0x5, 0x36f4 <_llm_rows.packet_batch.blocks+0x3210>
    3710:      	add	x11, x9, #0x14
    3714:      	st1.s	{ v2 }[1], [x11]
    3718:      	tbnz	w10, #0x6, 0x36f8 <_llm_rows.packet_batch.blocks+0x3214>
    371c:      	tbz	w10, #0x7, 0x3728 <_llm_rows.packet_batch.blocks+0x3244>
    3720:      	add	x9, x9, #0x1c
    3724:      	st1.s	{ v2 }[3], [x9]
    3728:      	fmul.4s	v2, v14, v9
    372c:      	fmul.4s	v3, v15, v8
    3730:      	fadd.4s	v2, v3, v2
    3734:      	zip1.8b	v3, v21, v0
    3738:      	ushll.4s	v3, v3, #0x0
    373c:      	shl.4s	v3, v3, #0x1f
    3740:      	cmlt.4s	v3, v3, #0
    3744:      	and.16b	v2, v3, v2
    3748:      	fmov	w9, s29
    374c:      	ldp	q4, q3, [sp, #0x160]
    3750:      	stp	q4, q3, [sp, #0x3b0]
    3754:      	ldp	q4, q3, [sp, #0x180]
    3758:      	stp	q4, q3, [sp, #0x3d0]
    375c:      	and	x10, x13, #0x7
    3760:      	add	x11, sp, #0x3b0
    3764:      	ldr	x10, [x11, x10, lsl #3]
    3768:      	sub	x10, x10, x13
    376c:      	add	x8, x8, x10, lsl #2
    3770:      	tbz	w9, #0x0, 0x3790 <_llm_rows.packet_batch.blocks+0x32ac>
    3774:      	str	s2, [x8]
    3778:      	tbnz	w9, #0x1, 0x3794 <_llm_rows.packet_batch.blocks+0x32b0>
    377c:      	tbz	w9, #0x2, 0x37a0 <_llm_rows.packet_batch.blocks+0x32bc>
    3780:      	add	x10, x8, #0x8
    3784:      	st1.s	{ v2 }[2], [x10]
    3788:      	tbnz	w9, #0x3, 0x37a4 <_llm_rows.packet_batch.blocks+0x32c0>
    378c:      	b	0x37ac <_llm_rows.packet_batch.blocks+0x32c8>
    3790:      	tbz	w9, #0x1, 0x377c <_llm_rows.packet_batch.blocks+0x3298>
    3794:      	add	x10, x8, #0x4
    3798:      	st1.s	{ v2 }[1], [x10]
    379c:      	tbnz	w9, #0x2, 0x3780 <_llm_rows.packet_batch.blocks+0x329c>
    37a0:      	tbz	w9, #0x3, 0x37ac <_llm_rows.packet_batch.blocks+0x32c8>
    37a4:      	add	x10, x8, #0xc
    37a8:      	st1.s	{ v2 }[3], [x10]
    37ac:      	fmul.4s	v1, v1, v7
    37b0:      	fmul.4s	v0, v0, v5
    37b4:      	fadd.4s	v0, v0, v1
    37b8:      	zip2.8b	v1, v21, v0
    37bc:      	ushll.4s	v1, v1, #0x0
    37c0:      	shl.4s	v1, v1, #0x1f
    37c4:      	cmlt.4s	v1, v1, #0
    37c8:      	and.16b	v0, v1, v0
    37cc:      	tbnz	w9, #0x4, 0x1d48 <_llm_rows.packet_batch.blocks+0x1864>
    37d0:      	tbz	w9, #0x5, 0x1d50 <_llm_rows.packet_batch.blocks+0x186c>
    37d4:      	add	x10, x8, #0x14
    37d8:      	st1.s	{ v0 }[1], [x10]
    37dc:      	tbnz	w9, #0x6, 0x1d54 <_llm_rows.packet_batch.blocks+0x1870>
    37e0:      	tbz	w9, #0x7, 0x37ec <_llm_rows.packet_batch.blocks+0x3308>
    37e4:      	add	x8, x8, #0x1c
    37e8:      	st1.s	{ v0 }[3], [x8]
    37ec:      	mov	w8, #0x18               ; =24
    37f0:      	str	w8, [x20, #0x24]
    37f4:      	mov	w22, #0x20              ; =32
    37f8:      	b	0x5dc <_llm_rows.packet_batch.blocks+0xf8>
    37fc:      	add	sp, sp, #0x850
    3800:      	ldp	x29, x30, [sp, #0x90]
    3804:      	ldp	x20, x19, [sp, #0x80]
    3808:      	ldp	x22, x21, [sp, #0x70]
    380c:      	ldp	x24, x23, [sp, #0x60]
    3810:      	ldp	x26, x25, [sp, #0x50]
    3814:      	ldp	x28, x27, [sp, #0x40]
    3818:      	ldp	d9, d8, [sp, #0x30]
    381c:      	ldp	d11, d10, [sp, #0x20]
    3820:      	ldp	d13, d12, [sp, #0x10]
    3824:      	ldp	d15, d14, [sp], #0xa0
    3828:      	ret
